00007bdc0b3ce69b  nop [rax+rax*1], eax
00007bdc0b3ce6a0  mov rax, [r15+0xF8]
00007bdc0b3ce6a7  lea r14, [rax-0x1B0]
00007bdc0b3ce6ae  mov [r15+0xF8], r14
00007bdc0b3ce6b5  lea rax, [r14+0x1A0]
00007bdc0b3ce6bc  mov r12, [r15+0xA0]
00007bdc0b3ce6c3  mov r11, [r15+0x98]
00007bdc0b3ce6ca  mov [r13+rax*1], r12
00007bdc0b3ce6cf  lea rax, [r14+0x1A8]
00007bdc0b3ce6d6  mov [r13+rax*1], r11
00007bdc0b3ce6db  mov eax, 0x420A30
00007bdc0b3ce6e0  movups xmm1, [r13+rax*1]
00007bdc0b3ce6e6  mov eax, 0x4209C0
00007bdc0b3ce6eb  movups xmm15, [r13+rax*1]
00007bdc0b3ce6f1  mov eax, 0x420A50
00007bdc0b3ce6f6  movups xmm14, [r13+rax*1]
00007bdc0b3ce6fc  mov eax, 0x4209F0
00007bdc0b3ce701  movups xmm13, [r13+rax*1]
00007bdc0b3ce707  mov qword ptr [r15+0x98], 0x430C60
00007bdc0b3ce712  mov eax, 0x420A60
00007bdc0b3ce717  movups xmm12, [r13+rax*1]
00007bdc0b3ce71d  mov eax, 0x430C60
00007bdc0b3ce722  movups [r13+rax*1], xmm1
00007bdc0b3ce728  mov eax, 0x430C70
00007bdc0b3ce72d  movups [r13+rax*1], xmm15
00007bdc0b3ce733  mov eax, 0x430C80
00007bdc0b3ce738  movups [r13+rax*1], xmm14
00007bdc0b3ce73e  mov eax, 0x430C90
00007bdc0b3ce743  movups [r13+rax*1], xmm13
00007bdc0b3ce749  mov eax, 0x4209B0
00007bdc0b3ce74e  movups xmm14, [r13+rax*1]
00007bdc0b3ce754  mov eax, 0x4209A0
00007bdc0b3ce759  movups xmm13, [r13+rax*1]
00007bdc0b3ce75f  mov eax, 0x430D60
00007bdc0b3ce764  movups [r13+rax*1], xmm1
00007bdc0b3ce76a  mov eax, 0x430D70
00007bdc0b3ce76f  movups [r13+rax*1], xmm15
00007bdc0b3ce775  mov eax, 0x430CA0
00007bdc0b3ce77a  movups [r13+rax*1], xmm12
00007bdc0b3ce780  mov eax, 0x430CB0
00007bdc0b3ce785  movups [r13+rax*1], xmm14
00007bdc0b3ce78b  mov eax, 0x420990
00007bdc0b3ce790  movups xmm1, [r13+rax*1]
00007bdc0b3ce796  mov eax, 0x420A00
00007bdc0b3ce79b  movups xmm15, [r13+rax*1]
00007bdc0b3ce7a1  mov eax, 0x430CC0
00007bdc0b3ce7a6  movups [r13+rax*1], xmm13
00007bdc0b3ce7ac  mov eax, 0x430CD0
00007bdc0b3ce7b1  movups [r13+rax*1], xmm1
00007bdc0b3ce7b7  mov eax, 0x420A10
00007bdc0b3ce7bc  movups xmm1, [r13+rax*1]
00007bdc0b3ce7c2  mov eax, 0x4209E0
00007bdc0b3ce7c7  movups xmm14, [r13+rax*1]
00007bdc0b3ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007bdc0b3ce7d5  mov eax, 0x430CE0
00007bdc0b3ce7da  movups [r13+rax*1], xmm15
00007bdc0b3ce7e0  mov eax, 0x430CF0
00007bdc0b3ce7e5  movups [r13+rax*1], xmm1
00007bdc0b3ce7eb  mov eax, 0x420A80
00007bdc0b3ce7f0  movups xmm1, [r13+rax*1]
00007bdc0b3ce7f6  mov eax, 0x420A90
00007bdc0b3ce7fb  movups xmm15, [r13+rax*1]
00007bdc0b3ce801  movaps [r15+0x150], xmm15
00007bdc0b3ce809  mov qword ptr [r15+0xA0], 0x3E8
00007bdc0b3ce814  mov eax, 0x430D00
00007bdc0b3ce819  movups [r13+rax*1], xmm14
00007bdc0b3ce81f  mov eax, 0x430D10
00007bdc0b3ce824  movups [r13+rax*1], xmm1
00007bdc0b3ce82a  mov eax, 0x420A70
00007bdc0b3ce82f  movups xmm1, [r13+rax*1]
00007bdc0b3ce835  mov eax, 0x420A20
00007bdc0b3ce83a  movups xmm14, [r13+rax*1]
00007bdc0b3ce840  movaps [r15+0x140], xmm14
00007bdc0b3ce848  lea rax, [r14+0x150]
00007bdc0b3ce84f  movq xmm13, qword ptr [r15+0x200]
00007bdc0b3ce858  movq xmm12, qword ptr [r15+0x1F0]
00007bdc0b3ce861  movq r12, xmm13
00007bdc0b3ce866  movq r11, xmm12
00007bdc0b3ce86b  mov [r13+rax*1], r12
00007bdc0b3ce870  lea rax, [r14+0x158]
00007bdc0b3ce877  mov [r13+rax*1], r11
00007bdc0b3ce87c  mov eax, 0x430D20
00007bdc0b3ce881  movups [r13+rax*1], xmm15
00007bdc0b3ce887  mov eax, 0x430D30
00007bdc0b3ce88c  movups [r13+rax*1], xmm1
00007bdc0b3ce892  mov eax, 0x420A40
00007bdc0b3ce897  movups xmm1, [r13+rax*1]
00007bdc0b3ce89d  mov eax, 0x420AA8
00007bdc0b3ce8a2  mov r12, [r13+rax*1]
00007bdc0b3ce8a7  movq xmm15, r12
00007bdc0b3ce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007bdc0b3ce8b4  mov eax, 0x430D40
00007bdc0b3ce8b9  movups [r13+rax*1], xmm14
00007bdc0b3ce8bf  mov eax, 0x430D50
00007bdc0b3ce8c4  movups [r13+rax*1], xmm1
00007bdc0b3ce8ca  mov eax, 0x420B10
00007bdc0b3ce8cf  movups xmm1, [r13+rax*1]
00007bdc0b3ce8d5  movq rax, xmm15
00007bdc0b3ce8da  mov r12d, 0x430D80
00007bdc0b3ce8e0  mov [r13+r12*1], rax
00007bdc0b3ce8e5  mov eax, 0x420AF0
00007bdc0b3ce8ea  movups xmm15, [r13+rax*1]
00007bdc0b3ce8f0  mov eax, 0x420B00
00007bdc0b3ce8f5  movups xmm14, [r13+rax*1]
00007bdc0b3ce8fb  lea rax, [r14+0x130]
00007bdc0b3ce902  movups [r13+rax*1], xmm1
00007bdc0b3ce908  lea rax, [r14+0x160]
00007bdc0b3ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007bdc0b3ce918  movq xmm13, qword ptr [r15+0x1D0]
00007bdc0b3ce921  movq r12, xmm1
00007bdc0b3ce926  movq r11, xmm13
00007bdc0b3ce92b  mov [r13+rax*1], r12
00007bdc0b3ce930  lea rax, [r14+0x168]
00007bdc0b3ce937  mov [r13+rax*1], r11
00007bdc0b3ce93c  lea rax, [r14+0x110]
00007bdc0b3ce943  movups [r13+rax*1], xmm15
00007bdc0b3ce949  lea rax, [r14+0x120]
00007bdc0b3ce950  movups [r13+rax*1], xmm14
00007bdc0b3ce956  mov eax, 0x420AB0
00007bdc0b3ce95b  movups xmm1, [r13+rax*1]
00007bdc0b3ce961  mov eax, 0x420AC0
00007bdc0b3ce966  movups xmm15, [r13+rax*1]
00007bdc0b3ce96c  movaps [r15+0x120], xmm15
00007bdc0b3ce974  lea rax, [r14+0x170]
00007bdc0b3ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007bdc0b3ce984  movq xmm13, qword ptr [r15+0x1B0]
00007bdc0b3ce98d  movq r12, xmm14
00007bdc0b3ce992  movq r11, xmm13
00007bdc0b3ce997  mov [r13+rax*1], r12
00007bdc0b3ce99c  lea rax, [r14+0x178]
00007bdc0b3ce9a3  mov [r13+rax*1], r11
00007bdc0b3ce9a8  lea rax, [r14+0x180]
00007bdc0b3ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007bdc0b3ce9b8  movq xmm13, qword ptr [r15+0x190]
00007bdc0b3ce9c1  movq r12, xmm14
00007bdc0b3ce9c6  movq r11, xmm13
00007bdc0b3ce9cb  mov [r13+rax*1], r12
00007bdc0b3ce9d0  lea rax, [r14+0x188]
00007bdc0b3ce9d7  mov [r13+rax*1], r11
00007bdc0b3ce9dc  lea rax, [r14+0xD0]
00007bdc0b3ce9e3  movups [r13+rax*1], xmm1
00007bdc0b3ce9e9  lea rax, [r14+0xE0]
00007bdc0b3ce9f0  movups [r13+rax*1], xmm15
00007bdc0b3ce9f6  mov eax, 0x420AD0
00007bdc0b3ce9fb  movups xmm1, [r13+rax*1]
00007bdc0b3cea01  mov eax, 0x420AE0
00007bdc0b3cea06  movups xmm15, [r13+rax*1]
00007bdc0b3cea0c  movaps [r15+0x110], xmm1
00007bdc0b3cea14  movaps [r15+0x130], xmm15
00007bdc0b3cea1c  lea rax, [r14+0x190]
00007bdc0b3cea23  mov r12, [r15+0xE8]
00007bdc0b3cea2a  mov r11, [r15+0xF0]
00007bdc0b3cea31  mov [r13+rax*1], r12
00007bdc0b3cea36  lea rax, [r14+0x198]
00007bdc0b3cea3d  mov [r13+rax*1], r11
00007bdc0b3cea42  mov eax, 0x430D88
00007bdc0b3cea47  mov r12d, 0x421DF8D3
00007bdc0b3cea4d  mov [r13+rax*1], r12d
00007bdc0b3cea52  lea rax, [r14+0xF0]
00007bdc0b3cea59  movups [r13+rax*1], xmm1
00007bdc0b3cea5f  lea rax, [r14+0x100]
00007bdc0b3cea66  movups [r13+rax*1], xmm15
00007bdc0b3cea6c  lea rax, [r14+0xD0]
00007bdc0b3cea73  mov [r15], rax
00007bdc0b3cea76  mov qword ptr [r15+0x08], 0x430C60
00007bdc0b3cea7e  mov qword ptr [r15+0x10], 0x12C
00007bdc0b3cea86  mov qword ptr [r15+0xF0], 0x410284
00007bdc0b3cea91  mov r14d, [r15+0x320]
00007bdc0b3cea98  mov eax, 0x410284
00007bdc0b3cea9d  mov rcx, 0x7BDC0B3D07C0
00007bdc0b3ceaa7  mov [r15+r14*8+0x328], rax
00007bdc0b3ceaaf  mov [r15+r14*8+0x368], rcx
00007bdc0b3ceab7  add r14d, 0x01
00007bdc0b3ceabb  and r14d, 0x07
00007bdc0b3ceabf  mov [r15+0x320], r14d
00007bdc0b3ceac6  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3ceace  jz 0x00007BDC0B3CED70
00007bdc0b3cead4  nop [rax+rax*1], ax
00007bdc0b3ceadd  nop [rax+rax*1], eax
00007bdc0b3ceae5  mov eax, 0x4106BC
00007bdc0b3ceaea  mov [r15+0x100], rax
00007bdc0b3ceaf1  jmp 0x00007BDC0B1FE110
00007bdc0b3ceaf6  int3
00007bdc0b3ceaf7  call 0x00007BDC0B20BC20
00007bdc0b3ceafc  jmp 0x00007BDC0B3CE6CF
00007bdc0b3ceb01  call 0x00007BDC0B20A9A0
00007bdc0b3ceb06  jmp 0x00007BDC0B3CE6DB
00007bdc0b3ceb0b  call 0x00007BDC0B1FF430
00007bdc0b3ceb10  jmp 0x00007BDC0B3CE6E6
00007bdc0b3ceb15  call 0x00007BDC0B20E760
00007bdc0b3ceb1a  jmp 0x00007BDC0B3CE6F1
00007bdc0b3ceb1f  call 0x00007BDC0B20D4E0
00007bdc0b3ceb24  jmp 0x00007BDC0B3CE6FC
00007bdc0b3ceb29  call 0x00007BDC0B20C260
00007bdc0b3ceb2e  jmp 0x00007BDC0B3CE707
00007bdc0b3ceb33  call 0x00007BDC0B20AFE0
00007bdc0b3ceb38  jmp 0x00007BDC0B3CE71D
00007bdc0b3ceb3d  call 0x00007BDC0B1FF540
00007bdc0b3ceb42  jmp 0x00007BDC0B3CE728
00007bdc0b3ceb47  call 0x00007BDC0B20E880
00007bdc0b3ceb4c  jmp 0x00007BDC0B3CE733
00007bdc0b3ceb51  call 0x00007BDC0B20D600
00007bdc0b3ceb56  jmp 0x00007BDC0B3CE73E
00007bdc0b3ceb5b  call 0x00007BDC0B20C380
00007bdc0b3ceb60  jmp 0x00007BDC0B3CE749
00007bdc0b3ceb65  call 0x00007BDC0B20D4E0
00007bdc0b3ceb6a  jmp 0x00007BDC0B3CE754
00007bdc0b3ceb6f  call 0x00007BDC0B20C260
00007bdc0b3ceb74  jmp 0x00007BDC0B3CE75F
00007bdc0b3ceb79  call 0x00007BDC0B1FF540
00007bdc0b3ceb7e  jmp 0x00007BDC0B3CE76A
00007bdc0b3ceb83  call 0x00007BDC0B20E880
00007bdc0b3ceb88  jmp 0x00007BDC0B3CE775
00007bdc0b3ceb8d  call 0x00007BDC0B20B100
00007bdc0b3ceb92  jmp 0x00007BDC0B3CE780
00007bdc0b3ceb97  call 0x00007BDC0B20D600
00007bdc0b3ceb9c  jmp 0x00007BDC0B3CE78B
00007bdc0b3ceba1  call 0x00007BDC0B1FF430
00007bdc0b3ceba6  jmp 0x00007BDC0B3CE796
00007bdc0b3cebab  call 0x00007BDC0B20E760
00007bdc0b3cebb0  jmp 0x00007BDC0B3CE7A1
00007bdc0b3cebb5  call 0x00007BDC0B20C380
00007bdc0b3cebba  jmp 0x00007BDC0B3CE7AC
00007bdc0b3cebbf  call 0x00007BDC0B1FF540
00007bdc0b3cebc4  jmp 0x00007BDC0B3CE7B7
00007bdc0b3cebc9  call 0x00007BDC0B1FF430
00007bdc0b3cebce  jmp 0x00007BDC0B3CE7C2
00007bdc0b3cebd3  call 0x00007BDC0B20D4E0
00007bdc0b3cebd8  jmp 0x00007BDC0B3CE7CD
00007bdc0b3cebdd  call 0x00007BDC0B20E880
00007bdc0b3cebe2  jmp 0x00007BDC0B3CE7E0
00007bdc0b3cebe7  call 0x00007BDC0B1FF540
00007bdc0b3cebec  jmp 0x00007BDC0B3CE7EB
00007bdc0b3cebf1  call 0x00007BDC0B1FF430
00007bdc0b3cebf6  jmp 0x00007BDC0B3CE7F6
00007bdc0b3cebfb  call 0x00007BDC0B20E760
00007bdc0b3cec00  jmp 0x00007BDC0B3CE801
00007bdc0b3cec05  call 0x00007BDC0B20D600
00007bdc0b3cec0a  jmp 0x00007BDC0B3CE81F
00007bdc0b3cec0f  call 0x00007BDC0B1FF540
00007bdc0b3cec14  jmp 0x00007BDC0B3CE82A
00007bdc0b3cec19  call 0x00007BDC0B1FF430
00007bdc0b3cec1e  jmp 0x00007BDC0B3CE835
00007bdc0b3cec23  call 0x00007BDC0B20D4E0
00007bdc0b3cec28  jmp 0x00007BDC0B3CE840
00007bdc0b3cec2d  call 0x00007BDC0B20BC20
00007bdc0b3cec32  jmp 0x00007BDC0B3CE870
00007bdc0b3cec37  call 0x00007BDC0B20A9A0
00007bdc0b3cec3c  jmp 0x00007BDC0B3CE87C
00007bdc0b3cec41  call 0x00007BDC0B20E880
00007bdc0b3cec46  jmp 0x00007BDC0B3CE887
00007bdc0b3cec4b  call 0x00007BDC0B1FF540
00007bdc0b3cec50  jmp 0x00007BDC0B3CE892
00007bdc0b3cec55  call 0x00007BDC0B1FF430
00007bdc0b3cec5a  jmp 0x00007BDC0B3CE89D
00007bdc0b3cec5f  call 0x00007BDC0B20B720
00007bdc0b3cec64  jmp 0x00007BDC0B3CE8A7
00007bdc0b3cec69  call 0x00007BDC0B20D600
00007bdc0b3cec6e  jmp 0x00007BDC0B3CE8BF
00007bdc0b3cec73  call 0x00007BDC0B1FF540
00007bdc0b3cec78  jmp 0x00007BDC0B3CE8CA
00007bdc0b3cec7d  call 0x00007BDC0B1FF430
00007bdc0b3cec82  jmp 0x00007BDC0B3CE8D5
00007bdc0b3cec87  call 0x00007BDC0B2B4CB0
00007bdc0b3cec8c  jmp 0x00007BDC0B3CE8E5
00007bdc0b3cec91  call 0x00007BDC0B20E760
00007bdc0b3cec96  jmp 0x00007BDC0B3CE8F0
00007bdc0b3cec9b  call 0x00007BDC0B20D4E0
00007bdc0b3ceca0  jmp 0x00007BDC0B3CE8FB
00007bdc0b3ceca5  call 0x00007BDC0B1FF540
00007bdc0b3cecaa  jmp 0x00007BDC0B3CE908
00007bdc0b3cecaf  call 0x00007BDC0B20BC20
00007bdc0b3cecb4  jmp 0x00007BDC0B3CE930
00007bdc0b3cecb9  call 0x00007BDC0B20A9A0
00007bdc0b3cecbe  jmp 0x00007BDC0B3CE93C
00007bdc0b3cecc3  call 0x00007BDC0B20E880
00007bdc0b3cecc8  jmp 0x00007BDC0B3CE949
00007bdc0b3ceccd  call 0x00007BDC0B20D600
00007bdc0b3cecd2  jmp 0x00007BDC0B3CE956
00007bdc0b3cecd7  call 0x00007BDC0B1FF430
00007bdc0b3cecdc  jmp 0x00007BDC0B3CE961
00007bdc0b3cece1  call 0x00007BDC0B20E760
00007bdc0b3cece6  jmp 0x00007BDC0B3CE96C
00007bdc0b3ceceb  call 0x00007BDC0B20BC20
00007bdc0b3cecf0  jmp 0x00007BDC0B3CE99C
00007bdc0b3cecf5  call 0x00007BDC0B20A9A0
00007bdc0b3cecfa  jmp 0x00007BDC0B3CE9A8
00007bdc0b3cecff  call 0x00007BDC0B20BC20
00007bdc0b3ced04  jmp 0x00007BDC0B3CE9D0
00007bdc0b3ced09  call 0x00007BDC0B20A9A0
00007bdc0b3ced0e  jmp 0x00007BDC0B3CE9DC
00007bdc0b3ced13  call 0x00007BDC0B1FF540
00007bdc0b3ced18  jmp 0x00007BDC0B3CE9E9
00007bdc0b3ced1d  call 0x00007BDC0B20E880
00007bdc0b3ced22  jmp 0x00007BDC0B3CE9F6
00007bdc0b3ced27  call 0x00007BDC0B1FF430
00007bdc0b3ced2c  jmp 0x00007BDC0B3CEA01
00007bdc0b3ced31  call 0x00007BDC0B20E760
00007bdc0b3ced36  jmp 0x00007BDC0B3CEA0C
00007bdc0b3ced3b  call 0x00007BDC0B20BC20
00007bdc0b3ced40  jmp 0x00007BDC0B3CEA36
00007bdc0b3ced45  call 0x00007BDC0B20A9A0
00007bdc0b3ced4a  jmp 0x00007BDC0B3CEA42
00007bdc0b3ced4f  call 0x00007BDC0B20BAE0
00007bdc0b3ced54  jmp 0x00007BDC0B3CEA52
00007bdc0b3ced59  call 0x00007BDC0B1FF540
00007bdc0b3ced5e  jmp 0x00007BDC0B3CEA5F
00007bdc0b3ced63  call 0x00007BDC0B20E880
00007bdc0b3ced68  jmp 0x00007BDC0B3CEA6C
00007bdc0b3ced6d  int3
00007bdc0b3ced6e  nop
00007bdc0b3ced70  mov rax, [r15]
00007bdc0b3ced73  lea r14, [rax+0x20]
00007bdc0b3ced77  mov r12, [r13+r14*1]
00007bdc0b3ced7c  mov r14, [r15+0x10]
00007bdc0b3ced80  lea r11, [r12+r14*1]
00007bdc0b3ced84  mov [r15+0x40], r11
00007bdc0b3ced88  lea r12, [rax+0x20]
00007bdc0b3ced8c  mov [r13+r12*1], r11
00007bdc0b3ced91  test r14, r14
00007bdc0b3ced94  setz r14b
00007bdc0b3ced98  movzx r14, r14b
00007bdc0b3ced9c  mov [rsp+0x414], r14b
00007bdc0b3ceda4  cmp byte ptr [rsp+0x414], 0x00
00007bdc0b3cedac  jz 0x00007BDC0B3CEDDE
00007bdc0b3cedae  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cedb6  mov eax, 0x410934
00007bdc0b3cedbb  mov [r15+0x100], rax
00007bdc0b3cedc2  jz 0x00007BDC0B1FE0A0
00007bdc0b3cedc8  nop [rax+rax*1], eax
00007bdc0b3cedcd  mov eax, 0x410934
00007bdc0b3cedd2  mov [r15+0x100], rax
00007bdc0b3cedd9  jmp 0x00007BDC0B1FE110
00007bdc0b3cedde  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cede6  jz 0x00007BDC0B3CEE30
00007bdc0b3cedec  nop [rax+rax*1], ax
00007bdc0b3cedf5  nop [rax+rax*1], eax
00007bdc0b3cedfd  mov eax, 0x4106CC
00007bdc0b3cee02  mov [r15+0x100], rax
00007bdc0b3cee09  jmp 0x00007BDC0B1FE110
00007bdc0b3cee0e  int3
00007bdc0b3cee0f  call 0x00007BDC0B2E27E0
00007bdc0b3cee14  jmp 0x00007BDC0B3CED7C
00007bdc0b3cee19  call 0x00007BDC0B2C0860
00007bdc0b3cee1e  jmp 0x00007BDC0B3CED91
00007bdc0b3cee23  int3
00007bdc0b3cee24  nop [rax+rax*1], ax
00007bdc0b3cee2d  nop [rax], eax
00007bdc0b3cee30  mov rax, [r15+0xF8]
00007bdc0b3cee37  lea r14, [rax-0x150]
00007bdc0b3cee3e  mov [r15+0xF8], r14
00007bdc0b3cee45  mov rax, [r15]
00007bdc0b3cee48  lea r12, [rax+0x68]
00007bdc0b3cee4c  mov r11, [r13+r12*1]
00007bdc0b3cee51  mov [r15+0x88], r11
00007bdc0b3cee58  lea r12, [rax+0x28]
00007bdc0b3cee5c  mov [r15+0x40], r12
00007bdc0b3cee60  mov [r15+0x48], r14
00007bdc0b3cee64  mov qword ptr [r15+0x50], 0x420B20
00007bdc0b3cee6c  lea rax, [r14+0x100]
00007bdc0b3cee73  mov r12, [r15+0xE8]
00007bdc0b3cee7a  mov r11, [r15+0xD8]
00007bdc0b3cee81  mov [r13+rax*1], r12
00007bdc0b3cee86  lea rax, [r14+0x108]
00007bdc0b3cee8d  mov [r13+rax*1], r11
00007bdc0b3cee92  lea rax, [r14+0x110]
00007bdc0b3cee99  mov r12, [r15+0xD0]
00007bdc0b3ceea0  mov r11, [r15+0xC8]
00007bdc0b3ceea7  mov [r13+rax*1], r12
00007bdc0b3ceeac  lea rax, [r14+0x118]
00007bdc0b3ceeb3  mov [r13+rax*1], r11
00007bdc0b3ceeb8  lea rax, [r14+0x120]
00007bdc0b3ceebf  mov r12, [r15+0xC0]
00007bdc0b3ceec6  mov r11, [r15+0xB8]
00007bdc0b3ceecd  mov [r13+rax*1], r12
00007bdc0b3ceed2  lea rax, [r14+0x128]
00007bdc0b3ceed9  mov [r13+rax*1], r11
00007bdc0b3ceede  lea rax, [r14+0x130]
00007bdc0b3ceee5  mov r12, [r15+0xB0]
00007bdc0b3ceeec  mov r11, [r15+0xA8]
00007bdc0b3ceef3  mov [r13+rax*1], r12
00007bdc0b3ceef8  lea rax, [r14+0x138]
00007bdc0b3ceeff  mov [r13+rax*1], r11
00007bdc0b3cef04  lea rax, [r14+0x140]
00007bdc0b3cef0b  mov r12, [r15+0xA0]
00007bdc0b3cef12  mov r11, [r15+0x98]
00007bdc0b3cef19  mov [r13+rax*1], r12
00007bdc0b3cef1e  lea rax, [r14+0x148]
00007bdc0b3cef25  mov [r13+rax*1], r11
00007bdc0b3cef2a  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cef32  jz 0x00007BDC0B3CEFD0
00007bdc0b3cef38  nop [rax+rax*1], ax
00007bdc0b3cef41  nop [rax+rax*1], eax
00007bdc0b3cef49  mov eax, 0x410704
00007bdc0b3cef4e  mov [r15+0x100], rax
00007bdc0b3cef55  jmp 0x00007BDC0B1FE110
00007bdc0b3cef5a  int3
00007bdc0b3cef5b  call 0x00007BDC0B2C0370
00007bdc0b3cef60  jmp 0x00007BDC0B3CEE51
00007bdc0b3cef65  call 0x00007BDC0B20BC20
00007bdc0b3cef6a  jmp 0x00007BDC0B3CEE86
00007bdc0b3cef6f  call 0x00007BDC0B20A9A0
00007bdc0b3cef74  jmp 0x00007BDC0B3CEE92
00007bdc0b3cef79  call 0x00007BDC0B20BC20
00007bdc0b3cef7e  jmp 0x00007BDC0B3CEEAC
00007bdc0b3cef83  call 0x00007BDC0B20A9A0
00007bdc0b3cef88  jmp 0x00007BDC0B3CEEB8
00007bdc0b3cef8d  call 0x00007BDC0B20BC20
00007bdc0b3cef92  jmp 0x00007BDC0B3CEED2
00007bdc0b3cef97  call 0x00007BDC0B20A9A0
00007bdc0b3cef9c  jmp 0x00007BDC0B3CEEDE
00007bdc0b3cefa1  call 0x00007BDC0B20BC20
00007bdc0b3cefa6  jmp 0x00007BDC0B3CEEF8
00007bdc0b3cefab  call 0x00007BDC0B20A9A0
00007bdc0b3cefb0  jmp 0x00007BDC0B3CEF04
00007bdc0b3cefb5  call 0x00007BDC0B20BC20
00007bdc0b3cefba  jmp 0x00007BDC0B3CEF1E
00007bdc0b3cefbf  call 0x00007BDC0B20A9A0
00007bdc0b3cefc4  jmp 0x00007BDC0B3CEF2A
00007bdc0b3cefc9  int3
00007bdc0b3cefca  nop [rax+rax*1], ax
00007bdc0b3cefd0  mov rax, [r15+0x08]
00007bdc0b3cefd4  movzx r14d, byte ptr [r13+rax*1]
00007bdc0b3cefda  movzx r14d, r14b
00007bdc0b3cefde  mov [rsp+0x10], r14d
00007bdc0b3cefe3  mov r14d, r14d
00007bdc0b3cefe6  mov [r15+0x58], r14
00007bdc0b3cefea  lea r14, [rax+0x01]
00007bdc0b3cefee  mov [r15+0x08], r14
00007bdc0b3ceff2  mov rax, [r15+0x88]
00007bdc0b3ceff9  lea r14, [rax+0x01]
00007bdc0b3ceffd  mov r12, [r15]
00007bdc0b3cf000  lea r11, [r12+0x68]
00007bdc0b3cf005  mov [r13+r11*1], r14
00007bdc0b3cf00a  lea r14, [r12+rax*1]
00007bdc0b3cf00e  mov [r15+0x60], r14
00007bdc0b3cf012  lea rax, [r14+0x28]
00007bdc0b3cf016  mov r11d, [rsp+0x10]
00007bdc0b3cf01b  movzx r14d, r11b
00007bdc0b3cf01f  mov [r13+rax*1], r14b
00007bdc0b3cf024  lea rax, [r12+0x68]
00007bdc0b3cf029  mov r14, [r13+rax*1]
00007bdc0b3cf02e  mov [r15+0x88], r14
00007bdc0b3cf035  xor eax, eax
00007bdc0b3cf037  mov r12d, 0x40
00007bdc0b3cf03d  cmp r14, r12
00007bdc0b3cf040  cmc
00007bdc0b3cf041  lahf
00007bdc0b3cf042  seto al
00007bdc0b3cf045  mov [r15+0x108], eax
00007bdc0b3cf04c  mov eax, [r15+0x108]
00007bdc0b3cf053  sahf
00007bdc0b3cf054  jnz 0x00007BDC0B3CF086
00007bdc0b3cf056  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cf05e  jz 0x00007BDC0B3CF170
00007bdc0b3cf064  nop [rax+rax*1], ax
00007bdc0b3cf06d  nop [rax+rax*1], eax
00007bdc0b3cf075  mov eax, 0x410724
00007bdc0b3cf07a  mov [r15+0x100], rax
00007bdc0b3cf081  jmp 0x00007BDC0B1FE110
00007bdc0b3cf086  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cf08e  jz 0x00007BDC0B3CF0E0
00007bdc0b3cf094  nop [rax+rax*1], ax
00007bdc0b3cf09d  nop [rax+rax*1], eax
00007bdc0b3cf0a5  mov eax, 0x4106FC
00007bdc0b3cf0aa  mov [r15+0x100], rax
00007bdc0b3cf0b1  jmp 0x00007BDC0B1FE110
00007bdc0b3cf0b6  int3
00007bdc0b3cf0b7  call 0x00007BDC0B20D860
00007bdc0b3cf0bc  jmp 0x00007BDC0B3CEFDA
00007bdc0b3cf0c1  call 0x00007BDC0B2B36E0
00007bdc0b3cf0c6  jmp 0x00007BDC0B3CF00A
00007bdc0b3cf0cb  call 0x00007BDC0B20DD60
00007bdc0b3cf0d0  jmp 0x00007BDC0B3CF024
00007bdc0b3cf0d5  call 0x00007BDC0B20DC20
00007bdc0b3cf0da  jmp 0x00007BDC0B3CF02E
00007bdc0b3cf0df  int3
00007bdc0b3cf0e0  mov rax, [r15+0x10]
00007bdc0b3cf0e4  lea r14, [rax-0x01]
00007bdc0b3cf0e8  mov [r15+0x10], r14
00007bdc0b3cf0ec  test r14, r14
00007bdc0b3cf0ef  setz r14b
00007bdc0b3cf0f3  movzx r14, r14b
00007bdc0b3cf0f7  mov [rsp+0x414], r14b
00007bdc0b3cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007bdc0b3cf107  jz 0x00007BDC0B3CF139
00007bdc0b3cf109  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cf111  jz 0x00007BDC0B3D0670
00007bdc0b3cf117  nop [rax+rax*1], ax
00007bdc0b3cf120  nop [rax+rax*1], eax
00007bdc0b3cf128  mov eax, 0x41091C
00007bdc0b3cf12d  mov [r15+0x100], rax
00007bdc0b3cf134  jmp 0x00007BDC0B1FE110
00007bdc0b3cf139  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cf141  jz 0x00007BDC0B3CEFD0
00007bdc0b3cf147  nop [rax+rax*1], ax
00007bdc0b3cf150  nop [rax+rax*1], eax
00007bdc0b3cf158  mov eax, 0x410704
00007bdc0b3cf15d  mov [r15+0x100], rax
00007bdc0b3cf164  jmp 0x00007BDC0B1FE110
00007bdc0b3cf169  int3
00007bdc0b3cf16a  int3
00007bdc0b3cf16b  nop [rax+rax*1], eax
00007bdc0b3cf170  mov rax, [r15+0x40]
00007bdc0b3cf174  movzx r14d, byte ptr [r13+rax*1]
00007bdc0b3cf17a  movaps xmm1, [r15+0x110]
00007bdc0b3cf182  pinsrb xmm1, r14d, 0x00
00007bdc0b3cf189  lea r14, [rax+0x01]
00007bdc0b3cf18d  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf193  movaps xmm15, [r15+0x120]
00007bdc0b3cf19b  pinsrb xmm15, r12d, 0x00
00007bdc0b3cf1a2  lea r14, [rax+0x02]
00007bdc0b3cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf1ac  movaps xmm14, [r15+0x130]
00007bdc0b3cf1b4  pinsrb xmm14, r12d, 0x00
00007bdc0b3cf1bb  lea r14, [rax+0x03]
00007bdc0b3cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf1c5  movaps xmm13, [r15+0x140]
00007bdc0b3cf1cd  pinsrb xmm13, r12d, 0x00
00007bdc0b3cf1d4  lea r14, [rax+0x04]
00007bdc0b3cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf1de  pinsrb xmm1, r12d, 0x01
00007bdc0b3cf1e5  lea r14, [rax+0x05]
00007bdc0b3cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf1ef  pinsrb xmm15, r12d, 0x01
00007bdc0b3cf1f6  lea r14, [rax+0x06]
00007bdc0b3cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf200  pinsrb xmm14, r12d, 0x01
00007bdc0b3cf207  lea r14, [rax+0x07]
00007bdc0b3cf20b  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf211  pinsrb xmm13, r12d, 0x01
00007bdc0b3cf218  lea r14, [rax+0x08]
00007bdc0b3cf21c  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf222  pinsrb xmm1, r12d, 0x02
00007bdc0b3cf229  lea r14, [rax+0x09]
00007bdc0b3cf22d  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf233  pinsrb xmm15, r12d, 0x02
00007bdc0b3cf23a  lea r14, [rax+0x0A]
00007bdc0b3cf23e  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf244  pinsrb xmm14, r12d, 0x02
00007bdc0b3cf24b  lea r14, [rax+0x0B]
00007bdc0b3cf24f  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf255  pinsrb xmm13, r12d, 0x02
00007bdc0b3cf25c  lea r14, [rax+0x0C]
00007bdc0b3cf260  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf266  pinsrb xmm1, r12d, 0x03
00007bdc0b3cf26d  lea r14, [rax+0x0D]
00007bdc0b3cf271  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf277  pinsrb xmm15, r12d, 0x03
00007bdc0b3cf27e  lea r14, [rax+0x0E]
00007bdc0b3cf282  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf288  pinsrb xmm14, r12d, 0x03
00007bdc0b3cf28f  lea r14, [rax+0x0F]
00007bdc0b3cf293  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf299  pinsrb xmm13, r12d, 0x03
00007bdc0b3cf2a0  lea r14, [rax+0x10]
00007bdc0b3cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf2aa  pinsrb xmm1, r12d, 0x04
00007bdc0b3cf2b1  lea r14, [rax+0x11]
00007bdc0b3cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf2bb  pinsrb xmm15, r12d, 0x04
00007bdc0b3cf2c2  lea r14, [rax+0x12]
00007bdc0b3cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf2cc  pinsrb xmm14, r12d, 0x04
00007bdc0b3cf2d3  lea r14, [rax+0x13]
00007bdc0b3cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf2dd  pinsrb xmm13, r12d, 0x04
00007bdc0b3cf2e4  lea r14, [rax+0x14]
00007bdc0b3cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf2ee  pinsrb xmm1, r12d, 0x05
00007bdc0b3cf2f5  lea r14, [rax+0x15]
00007bdc0b3cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf2ff  pinsrb xmm15, r12d, 0x05
00007bdc0b3cf306  lea r14, [rax+0x16]
00007bdc0b3cf30a  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf310  pinsrb xmm14, r12d, 0x05
00007bdc0b3cf317  lea r14, [rax+0x17]
00007bdc0b3cf31b  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf321  pinsrb xmm13, r12d, 0x05
00007bdc0b3cf328  lea r14, [rax+0x18]
00007bdc0b3cf32c  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf332  pinsrb xmm1, r12d, 0x06
00007bdc0b3cf339  lea r14, [rax+0x19]
00007bdc0b3cf33d  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf343  pinsrb xmm15, r12d, 0x06
00007bdc0b3cf34a  lea r14, [rax+0x1A]
00007bdc0b3cf34e  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf354  pinsrb xmm14, r12d, 0x06
00007bdc0b3cf35b  lea r14, [rax+0x1B]
00007bdc0b3cf35f  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf365  pinsrb xmm13, r12d, 0x06
00007bdc0b3cf36c  lea r14, [rax+0x1C]
00007bdc0b3cf370  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf376  pinsrb xmm1, r12d, 0x07
00007bdc0b3cf37d  lea r14, [rax+0x1D]
00007bdc0b3cf381  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf387  pinsrb xmm15, r12d, 0x07
00007bdc0b3cf38e  lea r14, [rax+0x1E]
00007bdc0b3cf392  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf398  pinsrb xmm14, r12d, 0x07
00007bdc0b3cf39f  lea r14, [rax+0x1F]
00007bdc0b3cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf3a9  pinsrb xmm13, r12d, 0x07
00007bdc0b3cf3b0  lea r14, [rax+0x20]
00007bdc0b3cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf3ba  pinsrb xmm1, r12d, 0x08
00007bdc0b3cf3c1  lea r14, [rax+0x21]
00007bdc0b3cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf3cb  pinsrb xmm15, r12d, 0x08
00007bdc0b3cf3d2  lea r14, [rax+0x22]
00007bdc0b3cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf3dc  pinsrb xmm14, r12d, 0x08
00007bdc0b3cf3e3  lea r14, [rax+0x23]
00007bdc0b3cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf3ed  pinsrb xmm13, r12d, 0x08
00007bdc0b3cf3f4  lea r14, [rax+0x24]
00007bdc0b3cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf3fe  pinsrb xmm1, r12d, 0x09
00007bdc0b3cf405  lea r14, [rax+0x25]
00007bdc0b3cf409  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf40f  pinsrb xmm15, r12d, 0x09
00007bdc0b3cf416  lea r14, [rax+0x26]
00007bdc0b3cf41a  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf420  pinsrb xmm14, r12d, 0x09
00007bdc0b3cf427  lea r14, [rax+0x27]
00007bdc0b3cf42b  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf431  pinsrb xmm13, r12d, 0x09
00007bdc0b3cf438  lea r14, [rax+0x28]
00007bdc0b3cf43c  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf442  pinsrb xmm1, r12d, 0x0A
00007bdc0b3cf449  lea r14, [rax+0x29]
00007bdc0b3cf44d  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf453  pinsrb xmm15, r12d, 0x0A
00007bdc0b3cf45a  lea r14, [rax+0x2A]
00007bdc0b3cf45e  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf464  pinsrb xmm14, r12d, 0x0A
00007bdc0b3cf46b  lea r14, [rax+0x2B]
00007bdc0b3cf46f  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf475  pinsrb xmm13, r12d, 0x0A
00007bdc0b3cf47c  lea r14, [rax+0x2C]
00007bdc0b3cf480  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf486  pinsrb xmm1, r12d, 0x0B
00007bdc0b3cf48d  lea r14, [rax+0x2D]
00007bdc0b3cf491  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf497  pinsrb xmm15, r12d, 0x0B
00007bdc0b3cf49e  lea r14, [rax+0x2E]
00007bdc0b3cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf4a8  pinsrb xmm14, r12d, 0x0B
00007bdc0b3cf4af  lea r14, [rax+0x2F]
00007bdc0b3cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf4b9  pinsrb xmm13, r12d, 0x0B
00007bdc0b3cf4c0  lea r14, [rax+0x30]
00007bdc0b3cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf4ca  pinsrb xmm1, r12d, 0x0C
00007bdc0b3cf4d1  lea r14, [rax+0x31]
00007bdc0b3cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf4db  pinsrb xmm15, r12d, 0x0C
00007bdc0b3cf4e2  lea r14, [rax+0x32]
00007bdc0b3cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf4ec  pinsrb xmm14, r12d, 0x0C
00007bdc0b3cf4f3  lea r14, [rax+0x33]
00007bdc0b3cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf4fd  pinsrb xmm13, r12d, 0x0C
00007bdc0b3cf504  lea r14, [rax+0x34]
00007bdc0b3cf508  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf50e  pinsrb xmm1, r12d, 0x0D
00007bdc0b3cf515  lea r14, [rax+0x35]
00007bdc0b3cf519  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf51f  pinsrb xmm15, r12d, 0x0D
00007bdc0b3cf526  lea r14, [rax+0x36]
00007bdc0b3cf52a  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf530  pinsrb xmm14, r12d, 0x0D
00007bdc0b3cf537  lea r14, [rax+0x37]
00007bdc0b3cf53b  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf541  pinsrb xmm13, r12d, 0x0D
00007bdc0b3cf548  lea r14, [rax+0x38]
00007bdc0b3cf54c  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf552  pinsrb xmm1, r12d, 0x0E
00007bdc0b3cf559  lea r14, [rax+0x39]
00007bdc0b3cf55d  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf563  pinsrb xmm15, r12d, 0x0E
00007bdc0b3cf56a  lea r14, [rax+0x3A]
00007bdc0b3cf56e  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf574  pinsrb xmm14, r12d, 0x0E
00007bdc0b3cf57b  lea r14, [rax+0x3B]
00007bdc0b3cf57f  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf585  pinsrb xmm13, r12d, 0x0E
00007bdc0b3cf58c  lea r14, [rax+0x3C]
00007bdc0b3cf590  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf596  pinsrb xmm1, r12d, 0x0F
00007bdc0b3cf59d  movaps [r15+0x110], xmm1
00007bdc0b3cf5a5  lea r14, [rax+0x3D]
00007bdc0b3cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf5af  pinsrb xmm15, r12d, 0x0F
00007bdc0b3cf5b6  movaps [r15+0x120], xmm15
00007bdc0b3cf5be  lea r14, [rax+0x3E]
00007bdc0b3cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007bdc0b3cf5c8  pinsrb xmm14, r12d, 0x0F
00007bdc0b3cf5cf  movaps [r15+0x130], xmm14
00007bdc0b3cf5d7  lea r14, [rax+0x3F]
00007bdc0b3cf5db  movzx eax, byte ptr [r13+r14*1]
00007bdc0b3cf5e1  pinsrb xmm13, eax, 0x0F
00007bdc0b3cf5e8  movaps [r15+0x140], xmm13
00007bdc0b3cf5f0  movq xmm1, qword ptr [r15+0x120]
00007bdc0b3cf5f9  pmovzxbw xmm1, xmm1
00007bdc0b3cf5fe  psllw xmm1, 0x00
00007bdc0b3cf603  movaps [r15+0x150], xmm1
00007bdc0b3cf60b  movq xmm1, qword ptr [r15+0x130]
00007bdc0b3cf614  pmovzxbw xmm1, xmm1
00007bdc0b3cf619  psllw xmm1, 0x00
00007bdc0b3cf61e  movaps [r15+0x160], xmm1
00007bdc0b3cf626  movq xmm1, qword ptr [r15+0x110]
00007bdc0b3cf62f  pmovzxbw xmm1, xmm1
00007bdc0b3cf634  psllw xmm1, 0x00
00007bdc0b3cf639  movaps [r15+0x170], xmm1
00007bdc0b3cf641  movaps xmm15, [r15+0x110]
00007bdc0b3cf649  pextrq rax, xmm15, 0x01
00007bdc0b3cf650  movq xmm15, rax
00007bdc0b3cf655  pmovzxbw xmm15, xmm15
00007bdc0b3cf65b  psllw xmm15, 0x00
00007bdc0b3cf661  movaps [r15+0x180], xmm15
00007bdc0b3cf669  movaps xmm14, [r15+0x120]
00007bdc0b3cf671  pextrq rax, xmm14, 0x01
00007bdc0b3cf678  movq xmm14, rax
00007bdc0b3cf67d  pmovzxbw xmm14, xmm14
00007bdc0b3cf683  psllw xmm14, 0x00
00007bdc0b3cf689  movaps [r15+0x210], xmm14
00007bdc0b3cf691  movaps xmm13, [r15+0x130]
00007bdc0b3cf699  pextrq rax, xmm13, 0x01
00007bdc0b3cf6a0  movq xmm13, rax
00007bdc0b3cf6a5  pmovzxbw xmm13, xmm13
00007bdc0b3cf6ab  psllw xmm13, 0x00
00007bdc0b3cf6b1  movaps [r15+0x220], xmm13
00007bdc0b3cf6b9  movq xmm12, qword ptr [r15+0x140]
00007bdc0b3cf6c2  pmovzxbw xmm12, xmm12
00007bdc0b3cf6c8  psllw xmm12, 0x00
00007bdc0b3cf6ce  movaps [r15+0x250], xmm12
00007bdc0b3cf6d6  movaps xmm12, [r15+0x140]
00007bdc0b3cf6de  pextrq rax, xmm12, 0x01
00007bdc0b3cf6e5  movq xmm12, rax
00007bdc0b3cf6ea  pmovzxbw xmm12, xmm12
00007bdc0b3cf6f0  psllw xmm12, 0x00
00007bdc0b3cf6f6  movaps [r15+0x110], xmm12
00007bdc0b3cf6fe  movq xmm11, qword ptr [r15+0x150]
00007bdc0b3cf707  pmovzxwd xmm11, xmm11
00007bdc0b3cf70d  pslld xmm11, 0x10
00007bdc0b3cf713  movq xmm10, qword ptr [r15+0x160]
00007bdc0b3cf71c  pmovzxwd xmm10, xmm10
00007bdc0b3cf722  pslld xmm10, 0x08
00007bdc0b3cf728  pextrq rax, xmm1, 0x01
00007bdc0b3cf72f  movq xmm1, rax
00007bdc0b3cf734  pmovzxwd xmm1, xmm1
00007bdc0b3cf739  pslld xmm1, 0x00
00007bdc0b3cf73e  movaps [r15+0x260], xmm1
00007bdc0b3cf746  pextrq rax, xmm15, 0x01
00007bdc0b3cf74d  movq xmm15, rax
00007bdc0b3cf752  pmovzxwd xmm15, xmm15
00007bdc0b3cf758  pslld xmm15, 0x00
00007bdc0b3cf75e  movaps [r15+0x270], xmm15
00007bdc0b3cf766  movq xmm9, qword ptr [r15+0x170]
00007bdc0b3cf76f  pmovzxwd xmm9, xmm9
00007bdc0b3cf775  pslld xmm9, 0x00
00007bdc0b3cf77b  pextrq rax, xmm14, 0x01
00007bdc0b3cf782  movq xmm14, rax
00007bdc0b3cf787  pmovzxwd xmm14, xmm14
00007bdc0b3cf78d  pslld xmm14, 0x10
00007bdc0b3cf793  movaps [r15+0x280], xmm14
00007bdc0b3cf79b  movq xmm8, qword ptr [r15+0x180]
00007bdc0b3cf7a4  pmovzxwd xmm8, xmm8
00007bdc0b3cf7aa  pslld xmm8, 0x00
00007bdc0b3cf7b0  movq xmm7, qword ptr [r15+0x210]
00007bdc0b3cf7b9  pmovzxwd xmm7, xmm7
00007bdc0b3cf7be  pslld xmm7, 0x10
00007bdc0b3cf7c3  movaps xmm6, [r15+0x150]
00007bdc0b3cf7cb  pextrq rax, xmm6, 0x01
00007bdc0b3cf7d2  movq xmm6, rax
00007bdc0b3cf7d7  pmovzxwd xmm6, xmm6
00007bdc0b3cf7dc  pslld xmm6, 0x10
00007bdc0b3cf7e1  por xmm11, xmm10
00007bdc0b3cf7e6  movaps [r15+0x230], xmm11
00007bdc0b3cf7ee  pextrq rax, xmm13, 0x01
00007bdc0b3cf7f5  movq xmm13, rax
00007bdc0b3cf7fa  pmovzxwd xmm13, xmm13
00007bdc0b3cf800  pslld xmm13, 0x08
00007bdc0b3cf806  movaps [r15+0x240], xmm13
00007bdc0b3cf80e  movq xmm10, qword ptr [r15+0x220]
00007bdc0b3cf817  pmovzxwd xmm10, xmm10
00007bdc0b3cf81d  pslld xmm10, 0x08
00007bdc0b3cf823  movaps xmm5, [r15+0x160]
00007bdc0b3cf82b  pextrq rax, xmm5, 0x01
00007bdc0b3cf832  movq xmm5, rax
00007bdc0b3cf837  pmovzxwd xmm5, xmm5
00007bdc0b3cf83c  pslld xmm5, 0x08
00007bdc0b3cf841  pslld xmm9, 0x18
00007bdc0b3cf847  pslld xmm15, 0x18
00007bdc0b3cf84d  pslld xmm8, 0x18
00007bdc0b3cf853  movq xmm4, qword ptr [r15+0x250]
00007bdc0b3cf85c  pmovzxwd xmm4, xmm4
00007bdc0b3cf861  pslld xmm4, 0x00
00007bdc0b3cf866  por xmm14, xmm13
00007bdc0b3cf86b  por xmm7, xmm10
00007bdc0b3cf870  movaps [r15+0x210], xmm7
00007bdc0b3cf878  pslld xmm1, 0x18
00007bdc0b3cf87d  movaps [r15+0x220], xmm1
00007bdc0b3cf885  por xmm6, xmm5
00007bdc0b3cf889  por xmm11, xmm9
00007bdc0b3cf88e  movaps [r15+0x160], xmm11
00007bdc0b3cf896  pextrq rax, xmm12, 0x01
00007bdc0b3cf89d  movq xmm13, rax
00007bdc0b3cf8a2  pmovzxwd xmm13, xmm13
00007bdc0b3cf8a8  pslld xmm13, 0x00
00007bdc0b3cf8ae  movaps [r15+0x170], xmm13
00007bdc0b3cf8b6  movq xmm12, qword ptr [r15+0x110]
00007bdc0b3cf8bf  pmovzxwd xmm12, xmm12
00007bdc0b3cf8c5  pslld xmm12, 0x00
00007bdc0b3cf8cb  por xmm14, xmm15
00007bdc0b3cf8d0  por xmm7, xmm8
00007bdc0b3cf8d5  movaps xmm15, [r15+0x250]
00007bdc0b3cf8dd  pextrq rax, xmm15, 0x01
00007bdc0b3cf8e4  movq xmm15, rax
00007bdc0b3cf8e9  pmovzxwd xmm15, xmm15
00007bdc0b3cf8ef  pslld xmm15, 0x00
00007bdc0b3cf8f5  movaps [r15+0x180], xmm15
00007bdc0b3cf8fd  por xmm6, xmm1
00007bdc0b3cf901  movaps [r15+0x150], xmm6
00007bdc0b3cf909  por xmm11, xmm4
00007bdc0b3cf90e  movaps [r15+0x140], xmm11
00007bdc0b3cf916  por xmm7, xmm12
00007bdc0b3cf91b  movaps [r15+0x110], xmm7
00007bdc0b3cf923  por xmm14, xmm13
00007bdc0b3cf928  movaps [r15+0x120], xmm14
00007bdc0b3cf930  por xmm6, xmm15
00007bdc0b3cf935  movaps [r15+0x130], xmm6
00007bdc0b3cf93d  mov rax, [r15+0xF8]
00007bdc0b3cf944  lea r14, [rax+0x20]
00007bdc0b3cf948  movups [r13+r14*1], xmm7
00007bdc0b3cf94e  lea r14, [rax+0x30]
00007bdc0b3cf952  movups [r13+r14*1], xmm14
00007bdc0b3cf958  movups [r13+rax*1], xmm11
00007bdc0b3cf95e  lea r14, [rax+0x10]
00007bdc0b3cf962  movups [r13+r14*1], xmm6
00007bdc0b3cf968  mov r14d, [r13+rax*1]
00007bdc0b3cf96d  mov rax, [r15+0x48]
00007bdc0b3cf971  mov [r15+0x68], rax
00007bdc0b3cf975  mov qword ptr [r15+0x58], 0x04
00007bdc0b3cf97d  lea r12, [rax+0x04]
00007bdc0b3cf981  mov r11d, [r13+r12*1]
00007bdc0b3cf986  mov [rsp+0x10], r11d
00007bdc0b3cf98b  mov r11d, r11d
00007bdc0b3cf98e  mov [r15+0x70], r11
00007bdc0b3cf992  lea r12, [rax+0x38]
00007bdc0b3cf996  mov r11d, [r13+r12*1]
00007bdc0b3cf99b  lea r12, [rax+0x24]
00007bdc0b3cf99f  mov r10d, [r13+r12*1]
00007bdc0b3cf9a4  mov [rsp+0x20], r10d
00007bdc0b3cf9a9  mov r10d, r10d
00007bdc0b3cf9ac  mov [r15+0x90], r10
00007bdc0b3cf9b3  mov [rsp+0x30], rax
00007bdc0b3cf9b8  xor eax, eax
00007bdc0b3cf9ba  mov r12d, 0x04
00007bdc0b3cf9c0  mov r10d, 0xC0
00007bdc0b3cf9c6  cmp r12, r10
00007bdc0b3cf9c9  cmc
00007bdc0b3cf9ca  lahf
00007bdc0b3cf9cb  seto al
00007bdc0b3cf9ce  mov [r15+0x108], eax
00007bdc0b3cf9d5  mov eax, [rsp+0x10]
00007bdc0b3cf9d9  mov r12d, [rsp+0x10]
00007bdc0b3cf9de  shrd eax, r12d, 0x07
00007bdc0b3cf9e3  mov [rsp+0x10], r11d
00007bdc0b3cf9e8  mov r10d, [rsp+0x10]
00007bdc0b3cf9ed  shrd r11d, r10d, 0x11
00007bdc0b3cf9f2  mov r9d, [rsp+0x20]
00007bdc0b3cf9f7  lea r8d, [r9d+r14d*1]
00007bdc0b3cf9fc  rorx r14d, r12d, 0x12
00007bdc0b3cfa02  xor eax, r14d
00007bdc0b3cfa05  rorx r14d, r10d, 0x13
00007bdc0b3cfa0b  xor r11d, r14d
00007bdc0b3cfa0e  mov [rsp+0x10], r11d
00007bdc0b3cfa13  mov r11d, r11d
00007bdc0b3cfa16  mov [r15+0x88], r11
00007bdc0b3cfa1d  mov [rsp+0x20], r12d
00007bdc0b3cfa22  shr r12d, 0x03
00007bdc0b3cfa26  xor eax, r12d
00007bdc0b3cfa29  mov [rsp+0x40], eax
00007bdc0b3cfa2d  mov eax, eax
00007bdc0b3cfa2f  mov [r15+0x80], rax
00007bdc0b3cfa36  shr r10d, 0x0A
00007bdc0b3cfa3a  mov eax, [rsp+0x10]
00007bdc0b3cfa3e  xor eax, r10d
00007bdc0b3cfa41  mov [rsp+0x10], eax
00007bdc0b3cfa45  mov eax, eax
00007bdc0b3cfa47  mov [r15+0x78], rax
00007bdc0b3cfa4b  mov eax, [rsp+0x40]
00007bdc0b3cfa4f  lea r14d, [r8d+eax*1]
00007bdc0b3cfa54  mov eax, [rsp+0x10]
00007bdc0b3cfa58  lea r12d, [r14d+eax*1]
00007bdc0b3cfa5d  mov rax, [rsp+0x30]
00007bdc0b3cfa62  lea r14, [rax+0x40]
00007bdc0b3cfa66  mov [r13+r14*1], r12d
00007bdc0b3cfa6b  mov eax, [rsp+0x20]
00007bdc0b3cfa6f  mov eax, eax
00007bdc0b3cfa71  mov [r15+0x60], rax
00007bdc0b3cfa75  mov eax, [r15+0x108]
00007bdc0b3cfa7c  sahf
00007bdc0b3cfa7d  jnz 0x00007BDC0B3CFAAF
00007bdc0b3cfa7f  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cfa87  jz 0x00007BDC0B3CFF70
00007bdc0b3cfa8d  nop [rax+rax*1], ax
00007bdc0b3cfa96  nop [rax+rax*1], eax
00007bdc0b3cfa9e  mov eax, 0x410820
00007bdc0b3cfaa3  mov [r15+0x100], rax
00007bdc0b3cfaaa  jmp 0x00007BDC0B1FE110
00007bdc0b3cfaaf  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cfab7  jz 0x00007BDC0B3CFDC0
00007bdc0b3cfabd  nop [rax+rax*1], ax
00007bdc0b3cfac6  nop [rax+rax*1], eax
00007bdc0b3cface  mov eax, 0x4107D8
00007bdc0b3cfad3  mov [r15+0x100], rax
00007bdc0b3cfada  jmp 0x00007BDC0B1FE110
00007bdc0b3cfadf  int3
00007bdc0b3cfae0  call 0x00007BDC0B20D860
00007bdc0b3cfae5  jmp 0x00007BDC0B3CF17A
00007bdc0b3cfaea  call 0x00007BDC0B2E2420
00007bdc0b3cfaef  jmp 0x00007BDC0B3CF193
00007bdc0b3cfaf4  call 0x00007BDC0B2E2420
00007bdc0b3cfaf9  jmp 0x00007BDC0B3CF1AC
00007bdc0b3cfafe  call 0x00007BDC0B2E2420
00007bdc0b3cfb03  jmp 0x00007BDC0B3CF1C5
00007bdc0b3cfb08  call 0x00007BDC0B2E2420
00007bdc0b3cfb0d  jmp 0x00007BDC0B3CF1DE
00007bdc0b3cfb12  call 0x00007BDC0B2E2420
00007bdc0b3cfb17  jmp 0x00007BDC0B3CF1EF
00007bdc0b3cfb1c  call 0x00007BDC0B2E2420
00007bdc0b3cfb21  jmp 0x00007BDC0B3CF200
00007bdc0b3cfb26  call 0x00007BDC0B2E2420
00007bdc0b3cfb2b  jmp 0x00007BDC0B3CF211
00007bdc0b3cfb30  call 0x00007BDC0B2E2420
00007bdc0b3cfb35  jmp 0x00007BDC0B3CF222
00007bdc0b3cfb3a  call 0x00007BDC0B2E2420
00007bdc0b3cfb3f  jmp 0x00007BDC0B3CF233
00007bdc0b3cfb44  call 0x00007BDC0B2E2420
00007bdc0b3cfb49  jmp 0x00007BDC0B3CF244
00007bdc0b3cfb4e  call 0x00007BDC0B2E2420
00007bdc0b3cfb53  jmp 0x00007BDC0B3CF255
00007bdc0b3cfb58  call 0x00007BDC0B2E2420
00007bdc0b3cfb5d  jmp 0x00007BDC0B3CF266
00007bdc0b3cfb62  call 0x00007BDC0B2E2420
00007bdc0b3cfb67  jmp 0x00007BDC0B3CF277
00007bdc0b3cfb6c  call 0x00007BDC0B2E2420
00007bdc0b3cfb71  jmp 0x00007BDC0B3CF288
00007bdc0b3cfb76  call 0x00007BDC0B2E2420
00007bdc0b3cfb7b  jmp 0x00007BDC0B3CF299
00007bdc0b3cfb80  call 0x00007BDC0B2E2420
00007bdc0b3cfb85  jmp 0x00007BDC0B3CF2AA
00007bdc0b3cfb8a  call 0x00007BDC0B2E2420
00007bdc0b3cfb8f  jmp 0x00007BDC0B3CF2BB
00007bdc0b3cfb94  call 0x00007BDC0B2E2420
00007bdc0b3cfb99  jmp 0x00007BDC0B3CF2CC
00007bdc0b3cfb9e  call 0x00007BDC0B2E2420
00007bdc0b3cfba3  jmp 0x00007BDC0B3CF2DD
00007bdc0b3cfba8  call 0x00007BDC0B2E2420
00007bdc0b3cfbad  jmp 0x00007BDC0B3CF2EE
00007bdc0b3cfbb2  call 0x00007BDC0B2E2420
00007bdc0b3cfbb7  jmp 0x00007BDC0B3CF2FF
00007bdc0b3cfbbc  call 0x00007BDC0B2E2420
00007bdc0b3cfbc1  jmp 0x00007BDC0B3CF310
00007bdc0b3cfbc6  call 0x00007BDC0B2E2420
00007bdc0b3cfbcb  jmp 0x00007BDC0B3CF321
00007bdc0b3cfbd0  call 0x00007BDC0B2E2420
00007bdc0b3cfbd5  jmp 0x00007BDC0B3CF332
00007bdc0b3cfbda  call 0x00007BDC0B2E2420
00007bdc0b3cfbdf  jmp 0x00007BDC0B3CF343
00007bdc0b3cfbe4  call 0x00007BDC0B2E2420
00007bdc0b3cfbe9  jmp 0x00007BDC0B3CF354
00007bdc0b3cfbee  call 0x00007BDC0B2E2420
00007bdc0b3cfbf3  jmp 0x00007BDC0B3CF365
00007bdc0b3cfbf8  call 0x00007BDC0B2E2420
00007bdc0b3cfbfd  jmp 0x00007BDC0B3CF376
00007bdc0b3cfc02  call 0x00007BDC0B2E2420
00007bdc0b3cfc07  jmp 0x00007BDC0B3CF387
00007bdc0b3cfc0c  call 0x00007BDC0B2E2420
00007bdc0b3cfc11  jmp 0x00007BDC0B3CF398
00007bdc0b3cfc16  call 0x00007BDC0B2E2420
00007bdc0b3cfc1b  jmp 0x00007BDC0B3CF3A9
00007bdc0b3cfc20  call 0x00007BDC0B2E2420
00007bdc0b3cfc25  jmp 0x00007BDC0B3CF3BA
00007bdc0b3cfc2a  call 0x00007BDC0B2E2420
00007bdc0b3cfc2f  jmp 0x00007BDC0B3CF3CB
00007bdc0b3cfc34  call 0x00007BDC0B2E2420
00007bdc0b3cfc39  jmp 0x00007BDC0B3CF3DC
00007bdc0b3cfc3e  call 0x00007BDC0B2E2420
00007bdc0b3cfc43  jmp 0x00007BDC0B3CF3ED
00007bdc0b3cfc48  call 0x00007BDC0B2E2420
00007bdc0b3cfc4d  jmp 0x00007BDC0B3CF3FE
00007bdc0b3cfc52  call 0x00007BDC0B2E2420
00007bdc0b3cfc57  jmp 0x00007BDC0B3CF40F
00007bdc0b3cfc5c  call 0x00007BDC0B2E2420
00007bdc0b3cfc61  jmp 0x00007BDC0B3CF420
00007bdc0b3cfc66  call 0x00007BDC0B2E2420
00007bdc0b3cfc6b  jmp 0x00007BDC0B3CF431
00007bdc0b3cfc70  call 0x00007BDC0B2E2420
00007bdc0b3cfc75  jmp 0x00007BDC0B3CF442
00007bdc0b3cfc7a  call 0x00007BDC0B2E2420
00007bdc0b3cfc7f  jmp 0x00007BDC0B3CF453
00007bdc0b3cfc84  call 0x00007BDC0B2E2420
00007bdc0b3cfc89  jmp 0x00007BDC0B3CF464
00007bdc0b3cfc8e  call 0x00007BDC0B2E2420
00007bdc0b3cfc93  jmp 0x00007BDC0B3CF475
00007bdc0b3cfc98  call 0x00007BDC0B2E2420
00007bdc0b3cfc9d  jmp 0x00007BDC0B3CF486
00007bdc0b3cfca2  call 0x00007BDC0B2E2420
00007bdc0b3cfca7  jmp 0x00007BDC0B3CF497
00007bdc0b3cfcac  call 0x00007BDC0B2E2420
00007bdc0b3cfcb1  jmp 0x00007BDC0B3CF4A8
00007bdc0b3cfcb6  call 0x00007BDC0B2E2420
00007bdc0b3cfcbb  jmp 0x00007BDC0B3CF4B9
00007bdc0b3cfcc0  call 0x00007BDC0B2E2420
00007bdc0b3cfcc5  jmp 0x00007BDC0B3CF4CA
00007bdc0b3cfcca  call 0x00007BDC0B2E2420
00007bdc0b3cfccf  jmp 0x00007BDC0B3CF4DB
00007bdc0b3cfcd4  call 0x00007BDC0B2E2420
00007bdc0b3cfcd9  jmp 0x00007BDC0B3CF4EC
00007bdc0b3cfcde  call 0x00007BDC0B2E2420
00007bdc0b3cfce3  jmp 0x00007BDC0B3CF4FD
00007bdc0b3cfce8  call 0x00007BDC0B2E2420
00007bdc0b3cfced  jmp 0x00007BDC0B3CF50E
00007bdc0b3cfcf2  call 0x00007BDC0B2E2420
00007bdc0b3cfcf7  jmp 0x00007BDC0B3CF51F
00007bdc0b3cfcfc  call 0x00007BDC0B2E2420
00007bdc0b3cfd01  jmp 0x00007BDC0B3CF530
00007bdc0b3cfd06  call 0x00007BDC0B2E2420
00007bdc0b3cfd0b  jmp 0x00007BDC0B3CF541
00007bdc0b3cfd10  call 0x00007BDC0B2E2420
00007bdc0b3cfd15  jmp 0x00007BDC0B3CF552
00007bdc0b3cfd1a  call 0x00007BDC0B2E2420
00007bdc0b3cfd1f  jmp 0x00007BDC0B3CF563
00007bdc0b3cfd24  call 0x00007BDC0B2E2420
00007bdc0b3cfd29  jmp 0x00007BDC0B3CF574
00007bdc0b3cfd2e  call 0x00007BDC0B2E2420
00007bdc0b3cfd33  jmp 0x00007BDC0B3CF585
00007bdc0b3cfd38  call 0x00007BDC0B2E2420
00007bdc0b3cfd3d  jmp 0x00007BDC0B3CF596
00007bdc0b3cfd42  call 0x00007BDC0B2E2420
00007bdc0b3cfd47  jmp 0x00007BDC0B3CF5AF
00007bdc0b3cfd4c  call 0x00007BDC0B2E2420
00007bdc0b3cfd51  jmp 0x00007BDC0B3CF5C8
00007bdc0b3cfd56  call 0x00007BDC0B2D5610
00007bdc0b3cfd5b  jmp 0x00007BDC0B3CF5E1
00007bdc0b3cfd60  call 0x00007BDC0B2DC580
00007bdc0b3cfd65  jmp 0x00007BDC0B3CF94E
00007bdc0b3cfd6a  call 0x00007BDC0B2E46C0
00007bdc0b3cfd6f  jmp 0x00007BDC0B3CF958
00007bdc0b3cfd74  call 0x00007BDC0B209E90
00007bdc0b3cfd79  jmp 0x00007BDC0B3CF95E
00007bdc0b3cfd7e  call 0x00007BDC0B2DB310
00007bdc0b3cfd83  jmp 0x00007BDC0B3CF968
00007bdc0b3cfd88  call 0x00007BDC0B20DAE0
00007bdc0b3cfd8d  jmp 0x00007BDC0B3CF96D
00007bdc0b3cfd92  call 0x00007BDC0B2C0230
00007bdc0b3cfd97  jmp 0x00007BDC0B3CF986
00007bdc0b3cfd9c  call 0x00007BDC0B2C0230
00007bdc0b3cfda1  jmp 0x00007BDC0B3CF99B
00007bdc0b3cfda6  call 0x00007BDC0B2BEFC0
00007bdc0b3cfdab  jmp 0x00007BDC0B3CF9A4
00007bdc0b3cfdb0  call 0x00007BDC0B2E2BA0
00007bdc0b3cfdb5  jmp 0x00007BDC0B3CFA6B
00007bdc0b3cfdba  int3
00007bdc0b3cfdbb  nop [rax+rax*1], eax
00007bdc0b3cfdc0  mov rax, [r15+0x48]
00007bdc0b3cfdc4  mov r14, [r15+0x58]
00007bdc0b3cfdc8  lea r12, [rax+r14*1]
00007bdc0b3cfdcc  mov [r15+0x68], r12
00007bdc0b3cfdd0  lea rax, [r14+0x04]
00007bdc0b3cfdd4  mov [r15+0x58], rax
00007bdc0b3cfdd8  lea r14, [r12+0x04]
00007bdc0b3cfddd  mov r11d, [r13+r14*1]
00007bdc0b3cfde2  mov [rsp+0x10], r11d
00007bdc0b3cfde7  mov r11d, r11d
00007bdc0b3cfdea  mov [r15+0x70], r11
00007bdc0b3cfdee  lea r14, [r12+0x38]
00007bdc0b3cfdf3  mov r11d, [r13+r14*1]
00007bdc0b3cfdf8  lea r14, [r12+0x24]
00007bdc0b3cfdfd  mov r10d, [r13+r14*1]
00007bdc0b3cfe02  mov [rsp+0x20], r10d
00007bdc0b3cfe07  mov r10d, r10d
00007bdc0b3cfe0a  mov [r15+0x90], r10
00007bdc0b3cfe11  mov [rsp+0x30], rax
00007bdc0b3cfe16  xor eax, eax
00007bdc0b3cfe18  mov r14, [rsp+0x30]
00007bdc0b3cfe1d  mov r10d, 0xC0
00007bdc0b3cfe23  cmp r14, r10
00007bdc0b3cfe26  cmc
00007bdc0b3cfe27  lahf
00007bdc0b3cfe28  seto al
00007bdc0b3cfe2b  mov [r15+0x108], eax
00007bdc0b3cfe32  mov eax, [rsp+0x10]
00007bdc0b3cfe36  mov r14d, [rsp+0x10]
00007bdc0b3cfe3b  shrd eax, r14d, 0x07
00007bdc0b3cfe40  mov [rsp+0x10], r11d
00007bdc0b3cfe45  mov r10d, [rsp+0x10]
00007bdc0b3cfe4a  shrd r11d, r10d, 0x11
00007bdc0b3cfe4f  mov r9d, [r15+0x60]
00007bdc0b3cfe53  mov r8d, [rsp+0x20]
00007bdc0b3cfe58  lea ebp, [r8d+r9d*1]
00007bdc0b3cfe5d  rorx r9d, r14d, 0x12
00007bdc0b3cfe63  xor eax, r9d
00007bdc0b3cfe66  rorx r9d, r10d, 0x13
00007bdc0b3cfe6c  xor r11d, r9d
00007bdc0b3cfe6f  mov [rsp+0x10], r11d
00007bdc0b3cfe74  mov r11d, r11d
00007bdc0b3cfe77  mov [r15+0x88], r11
00007bdc0b3cfe7e  mov [rsp+0x20], r14d
00007bdc0b3cfe83  shr r14d, 0x03
00007bdc0b3cfe87  xor eax, r14d
00007bdc0b3cfe8a  mov [rsp+0x30], eax
00007bdc0b3cfe8e  mov eax, eax
00007bdc0b3cfe90  mov [r15+0x80], rax
00007bdc0b3cfe97  shr r10d, 0x0A
00007bdc0b3cfe9b  mov eax, [rsp+0x10]
00007bdc0b3cfe9f  xor eax, r10d
00007bdc0b3cfea2  mov [rsp+0x10], eax
00007bdc0b3cfea6  mov eax, eax
00007bdc0b3cfea8  mov [r15+0x78], rax
00007bdc0b3cfeac  mov eax, [rsp+0x30]
00007bdc0b3cfeb0  lea r14d, [ebp+eax*1]
00007bdc0b3cfeb6  mov eax, [rsp+0x10]
00007bdc0b3cfeba  lea r11d, [r14d+eax*1]
00007bdc0b3cfebf  lea rax, [r12+0x40]
00007bdc0b3cfec4  mov [r13+rax*1], r11d
00007bdc0b3cfec9  mov eax, [rsp+0x20]
00007bdc0b3cfecd  mov eax, eax
00007bdc0b3cfecf  mov [r15+0x60], rax
00007bdc0b3cfed3  mov eax, [r15+0x108]
00007bdc0b3cfeda  sahf
00007bdc0b3cfedb  jnz 0x00007BDC0B3CFF0D
00007bdc0b3cfedd  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cfee5  jz 0x00007BDC0B3CFF70
00007bdc0b3cfeeb  nop [rax+rax*1], ax
00007bdc0b3cfef4  nop [rax+rax*1], eax
00007bdc0b3cfefc  mov eax, 0x410820
00007bdc0b3cff01  mov [r15+0x100], rax
00007bdc0b3cff08  jmp 0x00007BDC0B1FE110
00007bdc0b3cff0d  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3cff15  jz 0x00007BDC0B3CFDC0
00007bdc0b3cff1b  nop [rax+rax*1], ax
00007bdc0b3cff24  nop [rax+rax*1], eax
00007bdc0b3cff2c  mov eax, 0x4107D8
00007bdc0b3cff31  mov [r15+0x100], rax
00007bdc0b3cff38  jmp 0x00007BDC0B1FE110
00007bdc0b3cff3d  int3
00007bdc0b3cff3e  call 0x00007BDC0B2E1430
00007bdc0b3cff43  jmp 0x00007BDC0B3CFDE2
00007bdc0b3cff48  call 0x00007BDC0B2E1430
00007bdc0b3cff4d  jmp 0x00007BDC0B3CFDF8
00007bdc0b3cff52  call 0x00007BDC0B2E01C0
00007bdc0b3cff57  jmp 0x00007BDC0B3CFE02
00007bdc0b3cff5c  call 0x00007BDC0B20A860
00007bdc0b3cff61  jmp 0x00007BDC0B3CFEC9
00007bdc0b3cff66  int3
00007bdc0b3cff67  nop [rax+rax*1], ax
00007bdc0b3cff70  mov rax, [r15]
00007bdc0b3cff73  mov r14d, [r13+rax*1]
00007bdc0b3cff78  lea r12, [rax+0x04]
00007bdc0b3cff7c  mov r11d, [r13+r12*1]
00007bdc0b3cff81  mov [rsp+0x10], r14d
00007bdc0b3cff86  mov r14d, r14d
00007bdc0b3cff89  mov [r15+0x78], r14
00007bdc0b3cff8d  mov [rsp+0x20], r11d
00007bdc0b3cff92  mov r11d, r11d
00007bdc0b3cff95  mov [r15+0x80], r11
00007bdc0b3cff9c  lea r14, [rax+0x08]
00007bdc0b3cffa0  mov r12d, [r13+r14*1]
00007bdc0b3cffa5  lea r14, [rax+0x0C]
00007bdc0b3cffa9  mov r11d, [r13+r14*1]
00007bdc0b3cffae  mov [rsp+0x30], r12d
00007bdc0b3cffb3  mov r12d, r12d
00007bdc0b3cffb6  mov [r15+0x70], r12
00007bdc0b3cffba  mov [rsp+0x40], r11d
00007bdc0b3cffbf  mov r11d, r11d
00007bdc0b3cffc2  mov [r15+0x68], r11
00007bdc0b3cffc6  lea r14, [rax+0x18]
00007bdc0b3cffca  mov r12d, [r13+r14*1]
00007bdc0b3cffcf  lea r14, [rax+0x1C]
00007bdc0b3cffd3  mov r11d, [r13+r14*1]
00007bdc0b3cffd8  mov [rsp+0x50], r12d
00007bdc0b3cffdd  mov r12d, r12d
00007bdc0b3cffe0  mov [r15+0x58], r12
00007bdc0b3cffe4  mov [rsp+0x60], r11d
00007bdc0b3cffe9  mov r11d, r11d
00007bdc0b3cffec  mov [r15+0x60], r11
00007bdc0b3cfff0  lea r14, [rax+0x10]
00007bdc0b3cfff4  mov r12d, [r13+r14*1]
00007bdc0b3cfff9  lea r14, [rax+0x14]
00007bdc0b3cfffd  mov eax, [r13+r14*1]
00007bdc0b3d0002  mov [rsp+0x70], r12d
00007bdc0b3d0007  mov r12d, r12d
00007bdc0b3d000a  mov [r15+0x18], r12
00007bdc0b3d000e  mov [rsp+0x80], eax
00007bdc0b3d0015  mov eax, eax
00007bdc0b3d0017  mov [r15+0x90], rax
00007bdc0b3d001e  mov eax, [rsp+0x70]
00007bdc0b3d0022  mov eax, eax
00007bdc0b3d0024  mov [r15+0x30], rax
00007bdc0b3d0028  mov eax, [rsp+0x50]
00007bdc0b3d002c  mov eax, eax
00007bdc0b3d002e  mov [r15+0xA0], rax
00007bdc0b3d0035  mov eax, [rsp+0x30]
00007bdc0b3d0039  mov eax, eax
00007bdc0b3d003b  mov [r15+0x28], rax
00007bdc0b3d003f  mov eax, [rsp+0x20]
00007bdc0b3d0043  mov eax, eax
00007bdc0b3d0045  mov [r15+0x98], rax
00007bdc0b3d004c  mov eax, [rsp+0x10]
00007bdc0b3d0050  mov eax, eax
00007bdc0b3d0052  mov [r15+0x38], rax
00007bdc0b3d0056  mov eax, [rsp+0x70]
00007bdc0b3d005a  mov r14d, [rsp+0x70]
00007bdc0b3d005f  shrd eax, r14d, 0x06
00007bdc0b3d0064  mov [rsp+0x70], r14d
00007bdc0b3d0069  mov r12d, [rsp+0x80]
00007bdc0b3d0071  and r14d, r12d
00007bdc0b3d0074  mov r11d, [rsp+0x10]
00007bdc0b3d0079  mov r10d, [rsp+0x10]
00007bdc0b3d007e  shrd r11d, r10d, 0x02
00007bdc0b3d0083  mov [rsp+0x10], r12d
00007bdc0b3d0088  mov r12d, r12d
00007bdc0b3d008b  mov [r15+0x20], r12
00007bdc0b3d008f  mov r12, [r15+0x50]
00007bdc0b3d0093  mov r9d, [r13+r12*1]
00007bdc0b3d0098  mov r12d, [rsp+0x50]
00007bdc0b3d009d  mov r8d, [rsp+0x70]
00007bdc0b3d00a2  andn ebp, r8d, r12d
00007bdc0b3d00a7  mov edi, [rsp+0x60]
00007bdc0b3d00ab  lea esi, [r14d+edi*1]
00007bdc0b3d00b0  rorx r14d, r8d, 0x0B
00007bdc0b3d00b6  xor eax, r14d
00007bdc0b3d00b9  rorx r14d, r10d, 0x0D
00007bdc0b3d00bf  xor r11d, r14d
00007bdc0b3d00c2  lea edi, [esi+ebp*1]
00007bdc0b3d00c6  mov r14, [r15+0x48]
00007bdc0b3d00ca  mov ebp, [r13+r14*1]
00007bdc0b3d00cf  mov r14d, [rsp+0x30]
00007bdc0b3d00d4  mov esi, [rsp+0x20]
00007bdc0b3d00d8  and r14d, esi
00007bdc0b3d00db  mov [rsp+0x20], r14d
00007bdc0b3d00e0  mov r14d, r14d
00007bdc0b3d00e3  mov [r15+0xD8], r14
00007bdc0b3d00ea  lea r14d, [edi+r9d*1]
00007bdc0b3d00ef  mov r9d, [rsp+0x30]
00007bdc0b3d00f4  xor r9d, esi
00007bdc0b3d00f7  rorx edi, r8d, 0x19
00007bdc0b3d00fd  xor eax, edi
00007bdc0b3d00ff  and r9d, r10d
00007bdc0b3d0102  rorx edi, r10d, 0x16
00007bdc0b3d0108  xor r11d, edi
00007bdc0b3d010b  mov [rsp+0x30], r11d
00007bdc0b3d0110  mov r11d, r11d
00007bdc0b3d0113  mov [r15+0xD0], r11
00007bdc0b3d011a  lea r11d, [r14d+ebp*1]
00007bdc0b3d011f  mov r10d, [rsp+0x20]
00007bdc0b3d0124  xor r9d, r10d
00007bdc0b3d0127  lea r14d, [r11d+eax*1]
00007bdc0b3d012c  mov qword ptr [r15+0x88], 0x04
00007bdc0b3d0137  mov eax, [rsp+0x30]
00007bdc0b3d013b  lea r11d, [r9d+eax*1]
00007bdc0b3d0140  mov eax, [rsp+0x40]
00007bdc0b3d0144  lea r10d, [r14d+eax*1]
00007bdc0b3d0149  mov r10d, r10d
00007bdc0b3d014c  mov [r15+0xB8], r10
00007bdc0b3d0153  xor eax, eax
00007bdc0b3d0155  mov r10d, 0x04
00007bdc0b3d015b  mov r9d, 0x100
00007bdc0b3d0161  cmp r10, r9
00007bdc0b3d0164  cmc
00007bdc0b3d0165  lahf
00007bdc0b3d0166  seto al
00007bdc0b3d0169  mov [r15+0x108], eax
00007bdc0b3d0170  lea eax, [r11d+r14d*1]
00007bdc0b3d0175  mov eax, eax
00007bdc0b3d0177  mov [r15+0xA8], rax
00007bdc0b3d017e  mov r12d, r12d
00007bdc0b3d0181  mov [r15+0xB0], r12
00007bdc0b3d0188  mov eax, [rsp+0x10]
00007bdc0b3d018c  mov eax, eax
00007bdc0b3d018e  mov [r15+0xC0], rax
00007bdc0b3d0195  mov r8d, r8d
00007bdc0b3d0198  mov [r15+0xC8], r8
00007bdc0b3d019f  mov eax, [r15+0x108]
00007bdc0b3d01a6  sahf
00007bdc0b3d01a7  jnz 0x00007BDC0B3D01D9
00007bdc0b3d01a9  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d01b1  jz 0x00007BDC0B3D04A0
00007bdc0b3d01b7  nop [rax+rax*1], ax
00007bdc0b3d01c0  nop [rax+rax*1], eax
00007bdc0b3d01c8  mov eax, 0x4108E0
00007bdc0b3d01cd  mov [r15+0x100], rax
00007bdc0b3d01d4  jmp 0x00007BDC0B1FE110
00007bdc0b3d01d9  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d01e1  jz 0x00007BDC0B3D0270
00007bdc0b3d01e7  nop [rax+rax*1], ax
00007bdc0b3d01f0  nop [rax+rax*1], eax
00007bdc0b3d01f8  mov eax, 0x410854
00007bdc0b3d01fd  mov [r15+0x100], rax
00007bdc0b3d0204  jmp 0x00007BDC0B1FE110
00007bdc0b3d0209  int3
00007bdc0b3d020a  call 0x00007BDC0B20DAE0
00007bdc0b3d020f  jmp 0x00007BDC0B3CFF78
00007bdc0b3d0214  call 0x00007BDC0B2C0230
00007bdc0b3d0219  jmp 0x00007BDC0B3CFF81
00007bdc0b3d021e  call 0x00007BDC0B2E26A0
00007bdc0b3d0223  jmp 0x00007BDC0B3CFFA5
00007bdc0b3d0228  call 0x00007BDC0B2E1430
00007bdc0b3d022d  jmp 0x00007BDC0B3CFFAE
00007bdc0b3d0232  call 0x00007BDC0B2E26A0
00007bdc0b3d0237  jmp 0x00007BDC0B3CFFCF
00007bdc0b3d023c  call 0x00007BDC0B2E1430
00007bdc0b3d0241  jmp 0x00007BDC0B3CFFD8
00007bdc0b3d0246  call 0x00007BDC0B2E26A0
00007bdc0b3d024b  jmp 0x00007BDC0B3CFFF9
00007bdc0b3d0250  call 0x00007BDC0B2D5890
00007bdc0b3d0255  jmp 0x00007BDC0B3D0002
00007bdc0b3d025a  call 0x00007BDC0B2BDD50
00007bdc0b3d025f  jmp 0x00007BDC0B3D0098
00007bdc0b3d0264  call 0x00007BDC0B2DA580
00007bdc0b3d0269  jmp 0x00007BDC0B3D00CF
00007bdc0b3d026e  int3
00007bdc0b3d026f  nop
00007bdc0b3d0270  mov eax, [r15+0xB8]
00007bdc0b3d0277  mov [rsp+0x10], eax
00007bdc0b3d027b  mov eax, eax
00007bdc0b3d027d  mov [r15+0x30], rax
00007bdc0b3d0281  mov eax, [r15+0xC0]
00007bdc0b3d0288  mov [rsp+0x20], eax
00007bdc0b3d028c  mov eax, eax
00007bdc0b3d028e  mov [r15+0xA0], rax
00007bdc0b3d0295  mov eax, [r15+0x28]
00007bdc0b3d0299  mov r14d, [r15+0x98]
00007bdc0b3d02a0  mov [rsp+0x30], r14d
00007bdc0b3d02a5  mov r14d, r14d
00007bdc0b3d02a8  mov [r15+0x28], r14
00007bdc0b3d02ac  mov r14d, [r15+0x38]
00007bdc0b3d02b0  mov [rsp+0x40], r14d
00007bdc0b3d02b5  mov r14d, r14d
00007bdc0b3d02b8  mov [r15+0x98], r14
00007bdc0b3d02bf  mov r14d, [r15+0xA8]
00007bdc0b3d02c6  mov [rsp+0x50], r14d
00007bdc0b3d02cb  mov r14d, r14d
00007bdc0b3d02ce  mov [r15+0x38], r14
00007bdc0b3d02d2  mov r14d, [rsp+0x10]
00007bdc0b3d02d7  mov r12d, [rsp+0x10]
00007bdc0b3d02dc  shrd r14d, r12d, 0x06
00007bdc0b3d02e1  mov r11d, [r15+0xC8]
00007bdc0b3d02e8  mov [rsp+0x10], r12d
00007bdc0b3d02ed  and r12d, r11d
00007bdc0b3d02f0  mov r10d, [rsp+0x50]
00007bdc0b3d02f5  mov r9d, [rsp+0x50]
00007bdc0b3d02fa  shrd r10d, r9d, 0x02
00007bdc0b3d02ff  mov [rsp+0x50], r11d
00007bdc0b3d0304  mov r11d, r11d
00007bdc0b3d0307  mov [r15+0x20], r11
00007bdc0b3d030b  mov r11, [r15+0x88]
00007bdc0b3d0312  mov r8, [r15+0x50]
00007bdc0b3d0316  lea rbp, [r8+r11*1]
00007bdc0b3d031a  mov r8d, [r13+rbp*1]
00007bdc0b3d031f  mov ebp, [rsp+0x20]
00007bdc0b3d0323  mov edi, [rsp+0x10]
00007bdc0b3d0327  andn esi, edi, ebp
00007bdc0b3d032c  mov edx, [r15+0xB0]
00007bdc0b3d0333  lea ecx, [r12d+edx*1]
00007bdc0b3d0338  rorx r12d, edi, 0x0B
00007bdc0b3d033e  xor r14d, r12d
00007bdc0b3d0341  rorx r12d, r9d, 0x0D
00007bdc0b3d0347  xor r10d, r12d
00007bdc0b3d034a  lea r12d, [ecx+esi*1]
00007bdc0b3d034f  mov rsi, [r15+0x48]
00007bdc0b3d0353  lea rdx, [rsi+r11*1]
00007bdc0b3d0357  mov esi, [r13+rdx*1]
00007bdc0b3d035c  mov edx, [rsp+0x30]
00007bdc0b3d0360  mov ecx, [rsp+0x40]
00007bdc0b3d0364  and edx, ecx
00007bdc0b3d0366  mov [rsp+0x10], edx
00007bdc0b3d036a  mov edx, edx
00007bdc0b3d036c  mov [r15+0xD8], rdx
00007bdc0b3d0373  lea edx, [r12d+r8d*1]
00007bdc0b3d0378  mov r12d, [rsp+0x30]
00007bdc0b3d037d  xor r12d, ecx
00007bdc0b3d0380  rorx r8d, edi, 0x19
00007bdc0b3d0386  xor r14d, r8d
00007bdc0b3d0389  and r12d, r9d
00007bdc0b3d038c  rorx r8d, r9d, 0x16
00007bdc0b3d0392  xor r10d, r8d
00007bdc0b3d0395  mov [rsp+0x20], r10d
00007bdc0b3d039a  mov r10d, r10d
00007bdc0b3d039d  mov [r15+0xD0], r10
00007bdc0b3d03a4  lea r10d, [edx+esi*1]
00007bdc0b3d03a9  mov r9d, [rsp+0x10]
00007bdc0b3d03ae  xor r12d, r9d
00007bdc0b3d03b1  lea r9d, [r10d+r14d*1]
00007bdc0b3d03b6  lea r14, [r11+0x04]
00007bdc0b3d03ba  mov [r15+0x88], r14
00007bdc0b3d03c1  mov r11d, [rsp+0x20]
00007bdc0b3d03c6  lea r10d, [r12d+r11d*1]
00007bdc0b3d03cb  lea r11d, [r9d+eax*1]
00007bdc0b3d03d0  mov r11d, r11d
00007bdc0b3d03d3  mov [r15+0xB8], r11
00007bdc0b3d03da  xor eax, eax
00007bdc0b3d03dc  mov r12d, 0x100
00007bdc0b3d03e2  cmp r14, r12
00007bdc0b3d03e5  cmc
00007bdc0b3d03e6  lahf
00007bdc0b3d03e7  seto al
00007bdc0b3d03ea  mov [r15+0x108], eax
00007bdc0b3d03f1  lea eax, [r10d+r9d*1]
00007bdc0b3d03f6  mov eax, eax
00007bdc0b3d03f8  mov [r15+0xA8], rax
00007bdc0b3d03ff  mov ebp, ebp
00007bdc0b3d0401  mov [r15+0xB0], rbp
00007bdc0b3d0408  mov eax, [rsp+0x50]
00007bdc0b3d040c  mov eax, eax
00007bdc0b3d040e  mov [r15+0xC0], rax
00007bdc0b3d0415  mov edi, edi
00007bdc0b3d0417  mov [r15+0xC8], rdi
00007bdc0b3d041e  mov eax, [r15+0x108]
00007bdc0b3d0425  sahf
00007bdc0b3d0426  jnz 0x00007BDC0B3D0458
00007bdc0b3d0428  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0430  jz 0x00007BDC0B3D04A0
00007bdc0b3d0436  nop [rax+rax*1], ax
00007bdc0b3d043f  nop [rax+rax*1], eax
00007bdc0b3d0447  mov eax, 0x4108E0
00007bdc0b3d044c  mov [r15+0x100], rax
00007bdc0b3d0453  jmp 0x00007BDC0B1FE110
00007bdc0b3d0458  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0460  jz 0x00007BDC0B3D0270
00007bdc0b3d0466  nop [rax+rax*1], ax
00007bdc0b3d046f  nop [rax+rax*1], eax
00007bdc0b3d0477  mov eax, 0x410854
00007bdc0b3d047c  mov [r15+0x100], rax
00007bdc0b3d0483  jmp 0x00007BDC0B1FE110
00007bdc0b3d0488  int3
00007bdc0b3d0489  call 0x00007BDC0B249010
00007bdc0b3d048e  jmp 0x00007BDC0B3D031F
00007bdc0b3d0493  call 0x00007BDC0B225930
00007bdc0b3d0498  jmp 0x00007BDC0B3D035C
00007bdc0b3d049d  int3
00007bdc0b3d049e  nop
00007bdc0b3d04a0  mov eax, [r15+0x98]
00007bdc0b3d04a7  mov r14d, [r15+0x70]
00007bdc0b3d04ab  lea r12d, [eax+r14d*1]
00007bdc0b3d04b0  mov eax, [r15+0x28]
00007bdc0b3d04b4  mov r14d, [r15+0x68]
00007bdc0b3d04b8  lea r11d, [eax+r14d*1]
00007bdc0b3d04bd  mov qword ptr [r15+0x88], 0x00
00007bdc0b3d04c8  mov eax, [r15+0xA8]
00007bdc0b3d04cf  mov r14d, [r15+0x78]
00007bdc0b3d04d3  lea r10d, [eax+r14d*1]
00007bdc0b3d04d8  mov [rsp+0x10], r10d
00007bdc0b3d04dd  mov r10d, r10d
00007bdc0b3d04e0  mov [r15+0x78], r10
00007bdc0b3d04e4  mov eax, [r15+0x38]
00007bdc0b3d04e8  mov r14d, [r15+0x80]
00007bdc0b3d04ef  lea r10d, [eax+r14d*1]
00007bdc0b3d04f4  mov [rsp+0x20], r10d
00007bdc0b3d04f9  mov r10d, r10d
00007bdc0b3d04fc  mov [r15+0x80], r10
00007bdc0b3d0503  mov rax, [r15]
00007bdc0b3d0506  lea r14, [rax+0x08]
00007bdc0b3d050a  mov [r13+r14*1], r12d
00007bdc0b3d050f  lea r14, [rax+0x0C]
00007bdc0b3d0513  mov [r13+r14*1], r11d
00007bdc0b3d0518  mov r14d, [r15+0xB8]
00007bdc0b3d051f  mov r12d, [r15+0x18]
00007bdc0b3d0523  lea r11d, [r14d+r12d*1]
00007bdc0b3d0528  mov [rsp+0x30], r11d
00007bdc0b3d052d  mov r11d, r11d
00007bdc0b3d0530  mov [r15+0x68], r11
00007bdc0b3d0534  mov r14d, [r15+0x30]
00007bdc0b3d0538  mov r12d, [r15+0x90]
00007bdc0b3d053f  lea r11d, [r14d+r12d*1]
00007bdc0b3d0544  mov [rsp+0x40], r11d
00007bdc0b3d0549  mov r11d, r11d
00007bdc0b3d054c  mov [r15+0x70], r11
00007bdc0b3d0550  mov r14d, [r15+0x20]
00007bdc0b3d0554  mov r12d, [r15+0x58]
00007bdc0b3d0558  lea r11d, [r14d+r12d*1]
00007bdc0b3d055d  mov [rsp+0x50], r11d
00007bdc0b3d0562  mov r11d, r11d
00007bdc0b3d0565  mov [r15+0x58], r11
00007bdc0b3d0569  mov r14d, [r15+0xA0]
00007bdc0b3d0570  mov r12d, [r15+0x60]
00007bdc0b3d0574  lea r11d, [r14d+r12d*1]
00007bdc0b3d0579  mov [rsp+0x60], r11d
00007bdc0b3d057e  mov r11d, r11d
00007bdc0b3d0581  mov [r15+0x60], r11
00007bdc0b3d0585  mov r14d, [rsp+0x10]
00007bdc0b3d058a  mov [r13+rax*1], r14d
00007bdc0b3d058f  lea r14, [rax+0x04]
00007bdc0b3d0593  mov r12d, [rsp+0x20]
00007bdc0b3d0598  mov [r13+r14*1], r12d
00007bdc0b3d059d  lea r14, [rax+0x10]
00007bdc0b3d05a1  mov r12d, [rsp+0x30]
00007bdc0b3d05a6  mov [r13+r14*1], r12d
00007bdc0b3d05ab  lea r14, [rax+0x14]
00007bdc0b3d05af  mov r12d, [rsp+0x40]
00007bdc0b3d05b4  mov [r13+r14*1], r12d
00007bdc0b3d05b9  lea r14, [rax+0x18]
00007bdc0b3d05bd  mov r12d, [rsp+0x50]
00007bdc0b3d05c2  mov [r13+r14*1], r12d
00007bdc0b3d05c7  lea r14, [rax+0x1C]
00007bdc0b3d05cb  mov r12d, [rsp+0x60]
00007bdc0b3d05d0  mov [r13+r14*1], r12d
00007bdc0b3d05d5  lea r14, [rax+0x68]
00007bdc0b3d05d9  xor eax, eax
00007bdc0b3d05db  mov [r13+r14*1], rax
00007bdc0b3d05e0  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d05e8  jz 0x00007BDC0B3CF0E0
00007bdc0b3d05ee  nop [rax+rax*1], ax
00007bdc0b3d05f7  nop [rax+rax*1], eax
00007bdc0b3d05ff  mov eax, 0x4106FC
00007bdc0b3d0604  mov [r15+0x100], rax
00007bdc0b3d060b  jmp 0x00007BDC0B1FE110
00007bdc0b3d0610  int3
00007bdc0b3d0611  call 0x00007BDC0B2E2BA0
00007bdc0b3d0616  jmp 0x00007BDC0B3D050F
00007bdc0b3d061b  call 0x00007BDC0B2E1920
00007bdc0b3d0620  jmp 0x00007BDC0B3D0518
00007bdc0b3d0625  call 0x00007BDC0B20DFE0
00007bdc0b3d062a  jmp 0x00007BDC0B3D058F
00007bdc0b3d062f  call 0x00007BDC0B2E2BA0
00007bdc0b3d0634  jmp 0x00007BDC0B3D059D
00007bdc0b3d0639  call 0x00007BDC0B2E2BA0
00007bdc0b3d063e  jmp 0x00007BDC0B3D05AB
00007bdc0b3d0643  call 0x00007BDC0B2E2BA0
00007bdc0b3d0648  jmp 0x00007BDC0B3D05B9
00007bdc0b3d064d  call 0x00007BDC0B2E2BA0
00007bdc0b3d0652  jmp 0x00007BDC0B3D05C7
00007bdc0b3d0657  call 0x00007BDC0B2E2BA0
00007bdc0b3d065c  jmp 0x00007BDC0B3D05D5
00007bdc0b3d0661  call 0x00007BDC0B2D5EB0
00007bdc0b3d0666  jmp 0x00007BDC0B3D05E0
00007bdc0b3d066b  int3
00007bdc0b3d066c  nop [rax], eax
00007bdc0b3d0670  mov rax, [r15+0xF8]
00007bdc0b3d0677  lea r14, [rax+0x140]
00007bdc0b3d067e  mov r12, [r13+r14*1]
00007bdc0b3d0683  lea r14, [rax+0x148]
00007bdc0b3d068a  mov r11, [r13+r14*1]
00007bdc0b3d068f  mov [r15+0xA0], r12
00007bdc0b3d0696  mov [r15+0x98], r11
00007bdc0b3d069d  lea r14, [rax+0x130]
00007bdc0b3d06a4  mov r12, [r13+r14*1]
00007bdc0b3d06a9  lea r14, [rax+0x138]
00007bdc0b3d06b0  mov r11, [r13+r14*1]
00007bdc0b3d06b5  mov [r15+0xB0], r12
00007bdc0b3d06bc  mov [r15+0xA8], r11
00007bdc0b3d06c3  lea r14, [rax+0x120]
00007bdc0b3d06ca  mov r12, [r13+r14*1]
00007bdc0b3d06cf  lea r14, [rax+0x128]
00007bdc0b3d06d6  mov r11, [r13+r14*1]
00007bdc0b3d06db  mov [r15+0xC0], r12
00007bdc0b3d06e2  mov [r15+0xB8], r11
00007bdc0b3d06e9  lea r14, [rax+0x110]
00007bdc0b3d06f0  mov r12, [r13+r14*1]
00007bdc0b3d06f5  lea r14, [rax+0x118]
00007bdc0b3d06fc  mov r11, [r13+r14*1]
00007bdc0b3d0701  mov [r15+0xD0], r12
00007bdc0b3d0708  mov [r15+0xC8], r11
00007bdc0b3d070f  lea r14, [rax+0x100]
00007bdc0b3d0716  mov r12, [r13+r14*1]
00007bdc0b3d071b  lea r14, [rax+0x108]
00007bdc0b3d0722  mov r11, [r13+r14*1]
00007bdc0b3d0727  mov [r15+0xE8], r12
00007bdc0b3d072e  mov [r15+0xD8], r11
00007bdc0b3d0735  lea r14, [rax+0x150]
00007bdc0b3d073c  mov [r15+0xF8], r14
00007bdc0b3d0743  mov rax, [r15+0xF0]
00007bdc0b3d074a  mov [r15+0x100], rax
00007bdc0b3d0751  jmp 0x00007BDC0B3CE5C0
00007bdc0b3d0756  int3
00007bdc0b3d0757  call 0x00007BDC0B2E27E0
00007bdc0b3d075c  jmp 0x00007BDC0B3D0683
00007bdc0b3d0761  call 0x00007BDC0B2E1570
00007bdc0b3d0766  jmp 0x00007BDC0B3D068F
00007bdc0b3d076b  call 0x00007BDC0B2E27E0
00007bdc0b3d0770  jmp 0x00007BDC0B3D06A9
00007bdc0b3d0775  call 0x00007BDC0B2E1570
00007bdc0b3d077a  jmp 0x00007BDC0B3D06B5
00007bdc0b3d077f  call 0x00007BDC0B2E27E0
00007bdc0b3d0784  jmp 0x00007BDC0B3D06CF
00007bdc0b3d0789  call 0x00007BDC0B2E1570
00007bdc0b3d078e  jmp 0x00007BDC0B3D06DB
00007bdc0b3d0793  call 0x00007BDC0B2E27E0
00007bdc0b3d0798  jmp 0x00007BDC0B3D06F5
00007bdc0b3d079d  call 0x00007BDC0B2E1570
00007bdc0b3d07a2  jmp 0x00007BDC0B3D0701
00007bdc0b3d07a7  call 0x00007BDC0B2E27E0
00007bdc0b3d07ac  jmp 0x00007BDC0B3D071B
00007bdc0b3d07b1  call 0x00007BDC0B2E1570
00007bdc0b3d07b6  jmp 0x00007BDC0B3D0727
00007bdc0b3d07bb  int3
00007bdc0b3d07bc  nop [rax], eax
00007bdc0b3d07c0  mov eax, [r15+0xA0]
00007bdc0b3d07c7  mov [rsp+0x10], eax
00007bdc0b3d07cb  xor eax, eax
00007bdc0b3d07cd  mov r14d, [rsp+0x10]
00007bdc0b3d07d2  sub r14d, 0x01
00007bdc0b3d07d6  cmc
00007bdc0b3d07d7  lahf
00007bdc0b3d07d8  seto al
00007bdc0b3d07db  mov [r15+0x108], eax
00007bdc0b3d07e2  mov r14d, r14d
00007bdc0b3d07e5  mov [r15+0xA0], r14
00007bdc0b3d07ec  mov eax, [r15+0x108]
00007bdc0b3d07f3  sahf
00007bdc0b3d07f4  jnz 0x00007BDC0B3D0826
00007bdc0b3d07f6  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d07fe  jz 0x00007BDC0B3D0900
00007bdc0b3d0804  nop [rax+rax*1], ax
00007bdc0b3d080d  nop [rax+rax*1], eax
00007bdc0b3d0815  mov eax, 0x41028C
00007bdc0b3d081a  mov [r15+0x100], rax
00007bdc0b3d0821  jmp 0x00007BDC0B1FE110
00007bdc0b3d0826  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d082e  jz 0x00007BDC0B3D0860
00007bdc0b3d0834  nop [rax+rax*1], ax
00007bdc0b3d083d  nop [rax+rax*1], eax
00007bdc0b3d0845  mov eax, 0x410274
00007bdc0b3d084a  mov [r15+0x100], rax
00007bdc0b3d0851  jmp 0x00007BDC0B1FE110
00007bdc0b3d0856  int3
00007bdc0b3d0857  int3
00007bdc0b3d0858  nop [rax+rax*1], eax
00007bdc0b3d0860  mov rax, [r15+0xF8]
00007bdc0b3d0867  lea r14, [rax+0xD0]
00007bdc0b3d086e  mov [r15], r14
00007bdc0b3d0871  mov rax, [r15+0x98]
00007bdc0b3d0878  mov [r15+0x08], rax
00007bdc0b3d087c  mov qword ptr [r15+0x10], 0x12C
00007bdc0b3d0884  mov qword ptr [r15+0xF0], 0x410284
00007bdc0b3d088f  mov r14d, [r15+0x320]
00007bdc0b3d0896  mov eax, 0x410284
00007bdc0b3d089b  mov rcx, 0x7BDC0B3D07C0
00007bdc0b3d08a5  mov [r15+r14*8+0x328], rax
00007bdc0b3d08ad  mov [r15+r14*8+0x368], rcx
00007bdc0b3d08b5  add r14d, 0x01
00007bdc0b3d08b9  and r14d, 0x07
00007bdc0b3d08bd  mov [r15+0x320], r14d
00007bdc0b3d08c4  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d08cc  jz 0x00007BDC0B3CED70
00007bdc0b3d08d2  nop [rax+rax*1], ax
00007bdc0b3d08db  nop [rax+rax*1], eax
00007bdc0b3d08e3  mov eax, 0x4106BC
00007bdc0b3d08e8  mov [r15+0x100], rax
00007bdc0b3d08ef  jmp 0x00007BDC0B1FE110
00007bdc0b3d08f4  int3
00007bdc0b3d08f5  int3
00007bdc0b3d08f6  nop [rax+rax*1], ax
00007bdc0b3d08ff  nop
00007bdc0b3d0900  mov rax, [r15+0xF8]
00007bdc0b3d0907  lea r14, [rax+0xF0]
00007bdc0b3d090e  mov r12, [r13+r14*1]
00007bdc0b3d0913  mov [r15+0x98], r12
00007bdc0b3d091a  mov qword ptr [r15+0x40], 0x80
00007bdc0b3d0922  lea r14, [rax+0xD0]
00007bdc0b3d0929  mov [r15], r14
00007bdc0b3d092c  lea r14, [rax+0x14C]
00007bdc0b3d0933  mov [r15+0x08], r14
00007bdc0b3d0937  mov qword ptr [r15+0x10], 0x01
00007bdc0b3d093f  lea r14, [rax+0x14C]
00007bdc0b3d0946  mov eax, 0x80
00007bdc0b3d094b  mov [r13+r14*1], al
00007bdc0b3d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007bdc0b3d095b  mov r14d, [r15+0x320]
00007bdc0b3d0962  mov eax, 0x4102A8
00007bdc0b3d0967  mov rcx, 0x7BDC0B3D09E0
00007bdc0b3d0971  mov [r15+r14*8+0x328], rax
00007bdc0b3d0979  mov [r15+r14*8+0x368], rcx
00007bdc0b3d0981  add r14d, 0x01
00007bdc0b3d0985  and r14d, 0x07
00007bdc0b3d0989  mov [r15+0x320], r14d
00007bdc0b3d0990  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0998  jz 0x00007BDC0B3CED70
00007bdc0b3d099e  nop [rax+rax*1], ax
00007bdc0b3d09a7  nop [rax+rax*1], eax
00007bdc0b3d09af  mov eax, 0x4106BC
00007bdc0b3d09b4  mov [r15+0x100], rax
00007bdc0b3d09bb  jmp 0x00007BDC0B1FE110
00007bdc0b3d09c0  int3
00007bdc0b3d09c1  call 0x00007BDC0B2E27E0
00007bdc0b3d09c6  jmp 0x00007BDC0B3D0913
00007bdc0b3d09cb  call 0x00007BDC0B2D5AF0
00007bdc0b3d09d0  jmp 0x00007BDC0B3D0950
00007bdc0b3d09d5  int3
00007bdc0b3d09d6  nop [rax+rax*1], ax
00007bdc0b3d09df  nop
00007bdc0b3d09e0  mov rax, [r15+0xF8]
00007bdc0b3d09e7  lea r14, [rax+0x138]
00007bdc0b3d09ee  mov r12, [r13+r14*1]
00007bdc0b3d09f3  mov [r15+0x40], r12
00007bdc0b3d09f7  lea r14, [rax+0x148]
00007bdc0b3d09fe  xor eax, eax
00007bdc0b3d0a00  mov [r13+r14*1], al
00007bdc0b3d0a05  xor eax, eax
00007bdc0b3d0a07  mov r14d, 0x38
00007bdc0b3d0a0d  cmp r12, r14
00007bdc0b3d0a10  cmc
00007bdc0b3d0a11  lahf
00007bdc0b3d0a12  seto al
00007bdc0b3d0a15  mov [r15+0x108], eax
00007bdc0b3d0a1c  mov eax, [r15+0x108]
00007bdc0b3d0a23  sahf
00007bdc0b3d0a24  jz 0x00007BDC0B3D0A56
00007bdc0b3d0a26  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0a2e  jz 0x00007BDC0B3D0AA0
00007bdc0b3d0a34  nop [rax+rax*1], ax
00007bdc0b3d0a3d  nop [rax+rax*1], eax
00007bdc0b3d0a45  mov eax, 0x4102B8
00007bdc0b3d0a4a  mov [r15+0x100], rax
00007bdc0b3d0a51  jmp 0x00007BDC0B1FE110
00007bdc0b3d0a56  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0a5e  jz 0x00007BDC0B3D0BF0
00007bdc0b3d0a64  nop [rax+rax*1], ax
00007bdc0b3d0a6d  nop [rax+rax*1], eax
00007bdc0b3d0a75  mov eax, 0x4102D4
00007bdc0b3d0a7a  mov [r15+0x100], rax
00007bdc0b3d0a81  jmp 0x00007BDC0B1FE110
00007bdc0b3d0a86  int3
00007bdc0b3d0a87  call 0x00007BDC0B2E27E0
00007bdc0b3d0a8c  jmp 0x00007BDC0B3D09F3
00007bdc0b3d0a91  call 0x00007BDC0B2D5AF0
00007bdc0b3d0a96  jmp 0x00007BDC0B3D0A05
00007bdc0b3d0a9b  int3
00007bdc0b3d0a9c  nop [rax], eax
00007bdc0b3d0aa0  mov rax, [r15+0xF8]
00007bdc0b3d0aa7  lea r14, [rax+0xD0]
00007bdc0b3d0aae  mov [r15], r14
00007bdc0b3d0ab1  lea r14, [rax+0x148]
00007bdc0b3d0ab8  mov [r15+0x08], r14
00007bdc0b3d0abc  mov qword ptr [r15+0x10], 0x01
00007bdc0b3d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007bdc0b3d0acf  mov r14d, [r15+0x320]
00007bdc0b3d0ad6  mov eax, 0x4102C8
00007bdc0b3d0adb  mov rcx, 0x7BDC0B3D0B40
00007bdc0b3d0ae5  mov [r15+r14*8+0x328], rax
00007bdc0b3d0aed  mov [r15+r14*8+0x368], rcx
00007bdc0b3d0af5  add r14d, 0x01
00007bdc0b3d0af9  and r14d, 0x07
00007bdc0b3d0afd  mov [r15+0x320], r14d
00007bdc0b3d0b04  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0b0c  jz 0x00007BDC0B3CED70
00007bdc0b3d0b12  nop [rax+rax*1], ax
00007bdc0b3d0b1b  nop [rax+rax*1], eax
00007bdc0b3d0b23  mov eax, 0x4106BC
00007bdc0b3d0b28  mov [r15+0x100], rax
00007bdc0b3d0b2f  jmp 0x00007BDC0B1FE110
00007bdc0b3d0b34  int3
00007bdc0b3d0b35  int3
00007bdc0b3d0b36  nop [rax+rax*1], ax
00007bdc0b3d0b3f  nop
00007bdc0b3d0b40  mov rax, [r15+0xF8]
00007bdc0b3d0b47  lea r14, [rax+0x138]
00007bdc0b3d0b4e  mov rax, [r13+r14*1]
00007bdc0b3d0b53  mov [r15+0x40], rax
00007bdc0b3d0b57  mov [rsp+0x10], rax
00007bdc0b3d0b5c  xor eax, eax
00007bdc0b3d0b5e  mov r14, [rsp+0x10]
00007bdc0b3d0b63  mov r12d, 0x38
00007bdc0b3d0b69  cmp r14, r12
00007bdc0b3d0b6c  cmc
00007bdc0b3d0b6d  lahf
00007bdc0b3d0b6e  seto al
00007bdc0b3d0b71  mov [r15+0x108], eax
00007bdc0b3d0b78  mov eax, [r15+0x108]
00007bdc0b3d0b7f  sahf
00007bdc0b3d0b80  jnz 0x00007BDC0B3D0BB2
00007bdc0b3d0b82  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0b8a  jz 0x00007BDC0B3D0BF0
00007bdc0b3d0b90  nop [rax+rax*1], ax
00007bdc0b3d0b99  nop [rax+rax*1], eax
00007bdc0b3d0ba1  mov eax, 0x4102D4
00007bdc0b3d0ba6  mov [r15+0x100], rax
00007bdc0b3d0bad  jmp 0x00007BDC0B1FE110
00007bdc0b3d0bb2  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0bba  jz 0x00007BDC0B3D0AA0
00007bdc0b3d0bc0  nop [rax+rax*1], ax
00007bdc0b3d0bc9  nop [rax+rax*1], eax
00007bdc0b3d0bd1  mov eax, 0x4102B8
00007bdc0b3d0bd6  mov [r15+0x100], rax
00007bdc0b3d0bdd  jmp 0x00007BDC0B1FE110
00007bdc0b3d0be2  int3
00007bdc0b3d0be3  call 0x00007BDC0B2D59C0
00007bdc0b3d0be8  jmp 0x00007BDC0B3D0B53
00007bdc0b3d0bed  int3
00007bdc0b3d0bee  nop
00007bdc0b3d0bf0  mov rax, [r15+0x98]
00007bdc0b3d0bf7  rorx r14, rax, 0x3D
00007bdc0b3d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007bdc0b3d0c01  mov rax, [r15+0xF8]
00007bdc0b3d0c08  lea r12, [rax+0xD0]
00007bdc0b3d0c0f  mov [r15], r12
00007bdc0b3d0c12  lea r12, [rax+0x140]
00007bdc0b3d0c19  mov [r15+0x08], r12
00007bdc0b3d0c1d  mov qword ptr [r15+0x10], 0x08
00007bdc0b3d0c25  bswap r14
00007bdc0b3d0c28  mov [r15+0x40], r14
00007bdc0b3d0c2c  lea r12, [rax+0x140]
00007bdc0b3d0c33  mov [r13+r12*1], r14
00007bdc0b3d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007bdc0b3d0c43  mov r14d, [r15+0x320]
00007bdc0b3d0c4a  mov eax, 0x4102F0
00007bdc0b3d0c4f  mov rcx, 0x7BDC0B3D0CC0
00007bdc0b3d0c59  mov [r15+r14*8+0x328], rax
00007bdc0b3d0c61  mov [r15+r14*8+0x368], rcx
00007bdc0b3d0c69  add r14d, 0x01
00007bdc0b3d0c6d  and r14d, 0x07
00007bdc0b3d0c71  mov [r15+0x320], r14d
00007bdc0b3d0c78  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0c80  jz 0x00007BDC0B3CED70
00007bdc0b3d0c86  nop [rax+rax*1], ax
00007bdc0b3d0c8f  nop [rax+rax*1], eax
00007bdc0b3d0c97  mov eax, 0x4106BC
00007bdc0b3d0c9c  mov [r15+0x100], rax
00007bdc0b3d0ca3  jmp 0x00007BDC0B1FE110
00007bdc0b3d0ca8  int3
00007bdc0b3d0ca9  call 0x00007BDC0B2C3FE0
00007bdc0b3d0cae  jmp 0x00007BDC0B3D0C38
00007bdc0b3d0cb3  int3
00007bdc0b3d0cb4  nop [rax+rax*1], ax
00007bdc0b3d0cbd  nop [rax], eax
00007bdc0b3d0cc0  mov rax, [r15+0xF8]
00007bdc0b3d0cc7  lea r14, [rax+0xD0]
00007bdc0b3d0cce  mov r12d, [r13+r14*1]
00007bdc0b3d0cd3  lea r14, [rax+0xD4]
00007bdc0b3d0cda  mov r11d, [r13+r14*1]
00007bdc0b3d0cdf  lea r14, [rax+0xD8]
00007bdc0b3d0ce6  mov r10d, [r13+r14*1]
00007bdc0b3d0ceb  lea r14, [rax+0xDC]
00007bdc0b3d0cf2  mov r9d, [r13+r14*1]
00007bdc0b3d0cf7  mov qword ptr [r15+0x48], 0x430C20
00007bdc0b3d0cff  mov qword ptr [r15+0xA0], 0x00
00007bdc0b3d0d0a  bswap r12d
00007bdc0b3d0d0d  bswap r11d
00007bdc0b3d0d10  mov qword ptr [r15+0x98], 0x430D8C
00007bdc0b3d0d1b  mov r14d, 0x430C20
00007bdc0b3d0d21  mov [r13+r14*1], r12d
00007bdc0b3d0d26  mov r14d, 0x430C24
00007bdc0b3d0d2c  mov [r13+r14*1], r11d
00007bdc0b3d0d31  bswap r10d
00007bdc0b3d0d34  bswap r9d
00007bdc0b3d0d37  lea r14, [rax+0xE0]
00007bdc0b3d0d3e  mov r12d, [r13+r14*1]
00007bdc0b3d0d43  lea r14, [rax+0xE4]
00007bdc0b3d0d4a  mov r11d, [r13+r14*1]
00007bdc0b3d0d4f  mov r14d, 0x430C28
00007bdc0b3d0d55  mov [r13+r14*1], r10d
00007bdc0b3d0d5a  mov r14d, 0x430C2C
00007bdc0b3d0d60  mov [r13+r14*1], r9d
00007bdc0b3d0d65  bswap r12d
00007bdc0b3d0d68  bswap r11d
00007bdc0b3d0d6b  mov [rsp+0x10], r11d
00007bdc0b3d0d70  mov r11d, r11d
00007bdc0b3d0d73  mov [r15+0x58], r11
00007bdc0b3d0d77  lea r14, [rax+0xE8]
00007bdc0b3d0d7e  mov r11d, [r13+r14*1]
00007bdc0b3d0d83  lea r14, [rax+0xEC]
00007bdc0b3d0d8a  mov eax, [r13+r14*1]
00007bdc0b3d0d8f  mov [rsp+0x20], eax
00007bdc0b3d0d93  mov eax, eax
00007bdc0b3d0d95  mov [r15+0x60], rax
00007bdc0b3d0d99  mov eax, 0x430C30
00007bdc0b3d0d9e  mov [r13+rax*1], r12d
00007bdc0b3d0da3  mov eax, 0x430C34
00007bdc0b3d0da8  mov r14d, [rsp+0x10]
00007bdc0b3d0dad  mov [r13+rax*1], r14d
00007bdc0b3d0db2  bswap r11d
00007bdc0b3d0db5  mov [rsp+0x10], r11d
00007bdc0b3d0dba  mov r11d, r11d
00007bdc0b3d0dbd  mov [r15+0x40], r11
00007bdc0b3d0dc1  mov eax, [rsp+0x20]
00007bdc0b3d0dc5  bswap eax
00007bdc0b3d0dc7  mov [rsp+0x20], eax
00007bdc0b3d0dcb  mov eax, eax
00007bdc0b3d0dcd  mov [r15+0x50], rax
00007bdc0b3d0dd1  mov eax, 0x430C38
00007bdc0b3d0dd6  mov r14d, [rsp+0x10]
00007bdc0b3d0ddb  mov [r13+rax*1], r14d
00007bdc0b3d0de0  mov eax, 0x430C3C
00007bdc0b3d0de5  mov r14d, [rsp+0x20]
00007bdc0b3d0dea  mov [r13+rax*1], r14d
00007bdc0b3d0def  mov eax, [r15+0xA0]
00007bdc0b3d0df6  lea r14d, [eax+0x11]
00007bdc0b3d0dfb  mov r14d, r14d
00007bdc0b3d0dfe  mov [r15], r14
00007bdc0b3d0e01  mov qword ptr [r15+0xF0], 0x41034C
00007bdc0b3d0e0c  mov r14d, [r15+0x320]
00007bdc0b3d0e13  mov eax, 0x41034C
00007bdc0b3d0e18  mov rcx, 0x7BDC0B3D0F90
00007bdc0b3d0e22  mov [r15+r14*8+0x328], rax
00007bdc0b3d0e2a  mov [r15+r14*8+0x368], rcx
00007bdc0b3d0e32  add r14d, 0x01
00007bdc0b3d0e36  and r14d, 0x07
00007bdc0b3d0e3a  mov [r15+0x320], r14d
00007bdc0b3d0e41  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0e49  jz 0x00007BDC0B3D0F20
00007bdc0b3d0e4f  nop [rax+rax*1], ax
00007bdc0b3d0e58  nop [rax+rax*1], eax
00007bdc0b3d0e60  mov eax, 0x410938
00007bdc0b3d0e65  mov [r15+0x100], rax
00007bdc0b3d0e6c  jmp 0x00007BDC0B1FE110
00007bdc0b3d0e71  int3
00007bdc0b3d0e72  call 0x00007BDC0B2E26A0
00007bdc0b3d0e77  jmp 0x00007BDC0B3D0CD3
00007bdc0b3d0e7c  call 0x00007BDC0B2E1430
00007bdc0b3d0e81  jmp 0x00007BDC0B3D0CDF
00007bdc0b3d0e86  call 0x00007BDC0B2E01C0
00007bdc0b3d0e8b  jmp 0x00007BDC0B3D0CEB
00007bdc0b3d0e90  call 0x00007BDC0B2DEF50
00007bdc0b3d0e95  jmp 0x00007BDC0B3D0CF7
00007bdc0b3d0e9a  call 0x00007BDC0B2E2BA0
00007bdc0b3d0e9f  jmp 0x00007BDC0B3D0D26
00007bdc0b3d0ea4  call 0x00007BDC0B2E1920
00007bdc0b3d0ea9  jmp 0x00007BDC0B3D0D31
00007bdc0b3d0eae  call 0x00007BDC0B2E26A0
00007bdc0b3d0eb3  jmp 0x00007BDC0B3D0D43
00007bdc0b3d0eb8  call 0x00007BDC0B2E1430
00007bdc0b3d0ebd  jmp 0x00007BDC0B3D0D4F
00007bdc0b3d0ec2  call 0x00007BDC0B2E06B0
00007bdc0b3d0ec7  jmp 0x00007BDC0B3D0D5A
00007bdc0b3d0ecc  call 0x00007BDC0B2DF440
00007bdc0b3d0ed1  jmp 0x00007BDC0B3D0D65
00007bdc0b3d0ed6  call 0x00007BDC0B2E1430
00007bdc0b3d0edb  jmp 0x00007BDC0B3D0D83
00007bdc0b3d0ee0  call 0x00007BDC0B2D5890
00007bdc0b3d0ee5  jmp 0x00007BDC0B3D0D8F
00007bdc0b3d0eea  call 0x00007BDC0B20BAE0
00007bdc0b3d0eef  jmp 0x00007BDC0B3D0DA3
00007bdc0b3d0ef4  call 0x00007BDC0B20DFE0
00007bdc0b3d0ef9  jmp 0x00007BDC0B3D0DB2
00007bdc0b3d0efe  call 0x00007BDC0B20DFE0
00007bdc0b3d0f03  jmp 0x00007BDC0B3D0DE0
00007bdc0b3d0f08  call 0x00007BDC0B20DFE0
00007bdc0b3d0f0d  jmp 0x00007BDC0B3D0DEF
00007bdc0b3d0f12  int3
00007bdc0b3d0f13  nop [rax+rax*1], ax
00007bdc0b3d0f1c  nop [rax], eax
00007bdc0b3d0f20  mov eax, [r15]
00007bdc0b3d0f23  mov [rsp+0x10], eax
00007bdc0b3d0f27  shr eax, 0x10
00007bdc0b3d0f2a  mov r14d, [rsp+0x10]
00007bdc0b3d0f2f  xor r14d, eax
00007bdc0b3d0f32  imul r14d, r14d, 0x7FEB352D
00007bdc0b3d0f39  mov eax, 0x846CA68B
00007bdc0b3d0f3e  mov eax, eax
00007bdc0b3d0f40  mov [r15+0x48], rax
00007bdc0b3d0f44  mov [rsp+0x10], r14d
00007bdc0b3d0f49  shr r14d, 0x0F
00007bdc0b3d0f4d  mov eax, [rsp+0x10]
00007bdc0b3d0f51  xor eax, r14d
00007bdc0b3d0f54  imul eax, eax, 0x846CA68B
00007bdc0b3d0f5a  mov [rsp+0x10], eax
00007bdc0b3d0f5e  mov eax, eax
00007bdc0b3d0f60  mov [r15+0x40], rax
00007bdc0b3d0f64  mov eax, [rsp+0x10]
00007bdc0b3d0f68  shr eax, 0x10
00007bdc0b3d0f6b  mov r14d, [rsp+0x10]
00007bdc0b3d0f70  xor r14d, eax
00007bdc0b3d0f73  mov r14d, r14d
00007bdc0b3d0f76  mov [r15], r14
00007bdc0b3d0f79  mov rax, [r15+0xF0]
00007bdc0b3d0f80  mov [r15+0x100], rax
00007bdc0b3d0f87  jmp 0x00007BDC0B3CE5C0
00007bdc0b3d0f8c  int3
00007bdc0b3d0f8d  int3
00007bdc0b3d0f8e  nop
00007bdc0b3d0f90  mov rax, [r15+0xA0]
00007bdc0b3d0f97  mov [rsp+0x10], rax
00007bdc0b3d0f9c  shl rax, 0x02
00007bdc0b3d0fa0  mov r14, [r15+0x98]
00007bdc0b3d0fa7  lea r12, [r14+rax*1]
00007bdc0b3d0fab  mov eax, [r15]
00007bdc0b3d0fae  mov [r13+r12*1], eax
00007bdc0b3d0fb3  mov rax, [rsp+0x10]
00007bdc0b3d0fb8  lea r14, [rax+0x01]
00007bdc0b3d0fbc  mov [r15+0xA0], r14
00007bdc0b3d0fc3  xor eax, eax
00007bdc0b3d0fc5  mov r12d, 0x400
00007bdc0b3d0fcb  cmp r14, r12
00007bdc0b3d0fce  cmc
00007bdc0b3d0fcf  lahf
00007bdc0b3d0fd0  seto al
00007bdc0b3d0fd3  mov [r15+0x108], eax
00007bdc0b3d0fda  mov eax, [r15+0x108]
00007bdc0b3d0fe1  sahf
00007bdc0b3d0fe2  jnz 0x00007BDC0B3D1014
00007bdc0b3d0fe4  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d0fec  jz 0x00007BDC0B3D10E0
00007bdc0b3d0ff2  nop [rax+rax*1], ax
00007bdc0b3d0ffb  nop [rax+rax*1], eax
00007bdc0b3d1003  mov eax, 0x41035C
00007bdc0b3d1008  mov [r15+0x100], rax
00007bdc0b3d100f  jmp 0x00007BDC0B1FE110
00007bdc0b3d1014  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d101c  jz 0x00007BDC0B3D1050
00007bdc0b3d1022  nop [rax+rax*1], ax
00007bdc0b3d102b  nop [rax+rax*1], eax
00007bdc0b3d1033  mov eax, 0x410344
00007bdc0b3d1038  mov [r15+0x100], rax
00007bdc0b3d103f  jmp 0x00007BDC0B1FE110
00007bdc0b3d1044  int3
00007bdc0b3d1045  call 0x00007BDC0B2B4B70
00007bdc0b3d104a  jmp 0x00007BDC0B3D0FB3
00007bdc0b3d104f  int3
00007bdc0b3d1050  mov eax, [r15+0xA0]
00007bdc0b3d1057  lea r14d, [eax+0x11]
00007bdc0b3d105c  mov r14d, r14d
00007bdc0b3d105f  mov [r15], r14
00007bdc0b3d1062  mov qword ptr [r15+0xF0], 0x41034C
00007bdc0b3d106d  mov r14d, [r15+0x320]
00007bdc0b3d1074  mov eax, 0x41034C
00007bdc0b3d1079  mov rcx, 0x7BDC0B3D0F90
00007bdc0b3d1083  mov [r15+r14*8+0x328], rax
00007bdc0b3d108b  mov [r15+r14*8+0x368], rcx
00007bdc0b3d1093  add r14d, 0x01
00007bdc0b3d1097  and r14d, 0x07
00007bdc0b3d109b  mov [r15+0x320], r14d
00007bdc0b3d10a2  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d10aa  jz 0x00007BDC0B3D0F20
00007bdc0b3d10b0  nop [rax+rax*1], ax
00007bdc0b3d10b9  nop [rax+rax*1], eax
00007bdc0b3d10c1  mov eax, 0x410938
00007bdc0b3d10c6  mov [r15+0x100], rax
00007bdc0b3d10cd  jmp 0x00007BDC0B1FE110
00007bdc0b3d10d2  int3
00007bdc0b3d10d3  int3
00007bdc0b3d10d4  nop [rax+rax*1], ax
00007bdc0b3d10dd  nop [rax], eax
00007bdc0b3d10e0  mov qword ptr [r15+0x40], 0x01
00007bdc0b3d10e8  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d10f0  jz 0x00007BDC0B3D1120
00007bdc0b3d10f6  nop [rax+rax*1], ax
00007bdc0b3d10ff  nop [rax+rax*1], eax
00007bdc0b3d1107  mov eax, 0x410378
00007bdc0b3d110c  mov [r15+0x100], rax
00007bdc0b3d1113  jmp 0x00007BDC0B1FE110
00007bdc0b3d1118  int3
00007bdc0b3d1119  int3
00007bdc0b3d111a  nop [rax+rax*1], ax
00007bdc0b3d1120  mov rax, [r15+0x40]
00007bdc0b3d1124  mov [rsp+0x10], rax
00007bdc0b3d1129  shl rax, 0x02
00007bdc0b3d112d  mov r14, [r15+0x98]
00007bdc0b3d1134  lea r12, [r14+rax*1]
00007bdc0b3d1138  mov eax, [r13+r12*1]
00007bdc0b3d113d  mov [rsp+0x20], eax
00007bdc0b3d1141  mov eax, eax
00007bdc0b3d1143  mov [r15+0x48], rax
00007bdc0b3d1147  mov rax, [rsp+0x10]
00007bdc0b3d114c  mov [r15+0x50], rax
00007bdc0b3d1150  mov eax, [r15+0x50]
00007bdc0b3d1154  lea r12d, [eax-0x01]
00007bdc0b3d1159  mov r12d, r12d
00007bdc0b3d115c  mov [r15+0x58], r12
00007bdc0b3d1160  mov rax, [r15+0x58]
00007bdc0b3d1164  mov r12d, eax
00007bdc0b3d1167  mov r12d, r12d
00007bdc0b3d116a  shl r12, 0x02
00007bdc0b3d116e  lea rax, [r14+r12*1]
00007bdc0b3d1172  mov r14d, [r13+rax*1]
00007bdc0b3d1177  mov [rsp+0x10], r14d
00007bdc0b3d117c  mov r14d, r14d
00007bdc0b3d117f  mov [r15+0x60], r14
00007bdc0b3d1183  xor eax, eax
00007bdc0b3d1185  mov r14d, [rsp+0x10]
00007bdc0b3d118a  mov r12d, [rsp+0x20]
00007bdc0b3d118f  cmp r14d, r12d
00007bdc0b3d1192  cmc
00007bdc0b3d1193  lahf
00007bdc0b3d1194  seto al
00007bdc0b3d1197  mov [r15+0x108], eax
00007bdc0b3d119e  mov eax, [r15+0x108]
00007bdc0b3d11a5  sahf
00007bdc0b3d11a6  cmc
00007bdc0b3d11a7  jbe 0x00007BDC0B3D11D9
00007bdc0b3d11a9  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d11b1  jz 0x00007BDC0B3D1220
00007bdc0b3d11b7  nop [rax+rax*1], ax
00007bdc0b3d11c0  nop [rax+rax*1], eax
00007bdc0b3d11c8  mov eax, 0x410390
00007bdc0b3d11cd  mov [r15+0x100], rax
00007bdc0b3d11d4  jmp 0x00007BDC0B1FE110
00007bdc0b3d11d9  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d11e1  jz 0x00007BDC0B3D14C0
00007bdc0b3d11e7  nop [rax+rax*1], ax
00007bdc0b3d11f0  nop [rax+rax*1], eax
00007bdc0b3d11f8  mov eax, 0x410368
00007bdc0b3d11fd  mov [r15+0x100], rax
00007bdc0b3d1204  jmp 0x00007BDC0B1FE110
00007bdc0b3d1209  int3
00007bdc0b3d120a  call 0x00007BDC0B2B4690
00007bdc0b3d120f  jmp 0x00007BDC0B3D113D
00007bdc0b3d1214  call 0x00007BDC0B20DAE0
00007bdc0b3d1219  jmp 0x00007BDC0B3D1177
00007bdc0b3d121e  int3
00007bdc0b3d121f  nop
00007bdc0b3d1220  mov rax, [r15+0x50]
00007bdc0b3d1224  mov [rsp+0x10], rax
00007bdc0b3d1229  shl rax, 0x02
00007bdc0b3d122d  mov r14, [r15+0x98]
00007bdc0b3d1234  lea r12, [r14+rax*1]
00007bdc0b3d1238  mov eax, [r15+0x60]
00007bdc0b3d123c  mov [r13+r12*1], eax
00007bdc0b3d1241  mov rax, [rsp+0x10]
00007bdc0b3d1246  lea r14, [rax-0x01]
00007bdc0b3d124a  mov [r15+0x50], r14
00007bdc0b3d124e  mov rax, [r15+0x58]
00007bdc0b3d1252  test rax, rax
00007bdc0b3d1255  setz al
00007bdc0b3d1258  movzx rax, al
00007bdc0b3d125c  mov [rsp+0x414], al
00007bdc0b3d1263  cmp byte ptr [rsp+0x414], 0x00
00007bdc0b3d126b  jz 0x00007BDC0B3D129D
00007bdc0b3d126d  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d1275  jz 0x00007BDC0B3D12E0
00007bdc0b3d127b  nop [rax+rax*1], ax
00007bdc0b3d1284  nop [rax+rax*1], eax
00007bdc0b3d128c  mov eax, 0x41039C
00007bdc0b3d1291  mov [r15+0x100], rax
00007bdc0b3d1298  jmp 0x00007BDC0B1FE110
00007bdc0b3d129d  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d12a5  jz 0x00007BDC0B3D13E0
00007bdc0b3d12ab  nop [rax+rax*1], ax
00007bdc0b3d12b4  nop [rax+rax*1], eax
00007bdc0b3d12bc  mov eax, 0x410380
00007bdc0b3d12c1  mov [r15+0x100], rax
00007bdc0b3d12c8  jmp 0x00007BDC0B1FE110
00007bdc0b3d12cd  int3
00007bdc0b3d12ce  call 0x00007BDC0B2B4B70
00007bdc0b3d12d3  jmp 0x00007BDC0B3D1241
00007bdc0b3d12d8  int3
00007bdc0b3d12d9  nop [rax], eax
00007bdc0b3d12e0  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d12e8  jz 0x00007BDC0B3D1320
00007bdc0b3d12ee  nop [rax+rax*1], ax
00007bdc0b3d12f7  nop [rax+rax*1], eax
00007bdc0b3d12ff  mov eax, 0x410364
00007bdc0b3d1304  mov [r15+0x100], rax
00007bdc0b3d130b  jmp 0x00007BDC0B1FE110
00007bdc0b3d1310  int3
00007bdc0b3d1311  int3
00007bdc0b3d1312  nop [rax+rax*1], ax
00007bdc0b3d131b  nop [rax+rax*1], eax
00007bdc0b3d1320  mov qword ptr [r15+0x50], 0x00
00007bdc0b3d1328  mov rax, [r15+0x40]
00007bdc0b3d132c  lea r14, [rax+0x01]
00007bdc0b3d1330  mov [r15+0x40], r14
00007bdc0b3d1334  mov rax, [r15+0x98]
00007bdc0b3d133b  mov r12d, [r15+0x48]
00007bdc0b3d133f  mov [r13+rax*1], r12d
00007bdc0b3d1344  xor eax, eax
00007bdc0b3d1346  mov r12d, 0x400
00007bdc0b3d134c  cmp r14, r12
00007bdc0b3d134f  cmc
00007bdc0b3d1350  lahf
00007bdc0b3d1351  seto al
00007bdc0b3d1354  mov [r15+0x108], eax
00007bdc0b3d135b  mov eax, [r15+0x108]
00007bdc0b3d1362  sahf
00007bdc0b3d1363  jz 0x00007BDC0B3D1395
00007bdc0b3d1365  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d136d  jz 0x00007BDC0B3D1120
00007bdc0b3d1373  nop [rax+rax*1], ax
00007bdc0b3d137c  nop [rax+rax*1], eax
00007bdc0b3d1384  mov eax, 0x410378
00007bdc0b3d1389  mov [r15+0x100], rax
00007bdc0b3d1390  jmp 0x00007BDC0B1FE110
00007bdc0b3d1395  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d139d  jz 0x00007BDC0B3D1580
00007bdc0b3d13a3  nop [rax+rax*1], ax
00007bdc0b3d13ac  nop [rax+rax*1], eax
00007bdc0b3d13b4  mov eax, 0x4103A0
00007bdc0b3d13b9  mov [r15+0x100], rax
00007bdc0b3d13c0  jmp 0x00007BDC0B1FE110
00007bdc0b3d13c5  int3
00007bdc0b3d13c6  call 0x00007BDC0B20BAE0
00007bdc0b3d13cb  jmp 0x00007BDC0B3D1344
00007bdc0b3d13d0  int3
00007bdc0b3d13d1  nop [rax+rax*1], ax
00007bdc0b3d13da  nop [rax+rax*1], ax
00007bdc0b3d13e0  mov eax, [r15+0x50]
00007bdc0b3d13e4  lea r14d, [eax-0x01]
00007bdc0b3d13e9  mov r14d, r14d
00007bdc0b3d13ec  mov [r15+0x58], r14
00007bdc0b3d13f0  mov rax, [r15+0x58]
00007bdc0b3d13f4  mov r14d, eax
00007bdc0b3d13f7  mov r14d, r14d
00007bdc0b3d13fa  shl r14, 0x02
00007bdc0b3d13fe  mov rax, [r15+0x98]
00007bdc0b3d1405  lea r12, [rax+r14*1]
00007bdc0b3d1409  mov eax, [r13+r12*1]
00007bdc0b3d140e  mov [rsp+0x10], eax
00007bdc0b3d1412  mov eax, eax
00007bdc0b3d1414  mov [r15+0x60], rax
00007bdc0b3d1418  mov eax, [r15+0x48]
00007bdc0b3d141c  mov [rsp+0x20], eax
00007bdc0b3d1420  xor eax, eax
00007bdc0b3d1422  mov r14d, [rsp+0x10]
00007bdc0b3d1427  mov r12d, [rsp+0x20]
00007bdc0b3d142c  cmp r14d, r12d
00007bdc0b3d142f  cmc
00007bdc0b3d1430  lahf
00007bdc0b3d1431  seto al
00007bdc0b3d1434  mov [r15+0x108], eax
00007bdc0b3d143b  mov eax, [r15+0x108]
00007bdc0b3d1442  sahf
00007bdc0b3d1443  cmc
00007bdc0b3d1444  jbe 0x00007BDC0B3D1476
00007bdc0b3d1446  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d144e  jz 0x00007BDC0B3D1220
00007bdc0b3d1454  nop [rax+rax*1], ax
00007bdc0b3d145d  nop [rax+rax*1], eax
00007bdc0b3d1465  mov eax, 0x410390
00007bdc0b3d146a  mov [r15+0x100], rax
00007bdc0b3d1471  jmp 0x00007BDC0B1FE110
00007bdc0b3d1476  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d147e  jz 0x00007BDC0B3D14C0
00007bdc0b3d1484  nop [rax+rax*1], ax
00007bdc0b3d148d  nop [rax+rax*1], eax
00007bdc0b3d1495  mov eax, 0x410368
00007bdc0b3d149a  mov [r15+0x100], rax
00007bdc0b3d14a1  jmp 0x00007BDC0B1FE110
00007bdc0b3d14a6  int3
00007bdc0b3d14a7  call 0x00007BDC0B2B4690
00007bdc0b3d14ac  jmp 0x00007BDC0B3D140E
00007bdc0b3d14b1  int3
00007bdc0b3d14b2  nop [rax+rax*1], ax
00007bdc0b3d14bb  nop [rax+rax*1], eax
00007bdc0b3d14c0  mov rax, [r15+0x40]
00007bdc0b3d14c4  lea r14, [rax+0x01]
00007bdc0b3d14c8  mov [r15+0x40], r14
00007bdc0b3d14cc  mov rax, [r15+0x50]
00007bdc0b3d14d0  mov r12d, eax
00007bdc0b3d14d3  mov r12d, r12d
00007bdc0b3d14d6  shl r12, 0x02
00007bdc0b3d14da  mov rax, [r15+0x98]
00007bdc0b3d14e1  lea r11, [rax+r12*1]
00007bdc0b3d14e5  mov eax, [r15+0x48]
00007bdc0b3d14e9  mov [r13+r11*1], eax
00007bdc0b3d14ee  xor eax, eax
00007bdc0b3d14f0  mov r12d, 0x400
00007bdc0b3d14f6  cmp r14, r12
00007bdc0b3d14f9  cmc
00007bdc0b3d14fa  lahf
00007bdc0b3d14fb  seto al
00007bdc0b3d14fe  mov [r15+0x108], eax
00007bdc0b3d1505  mov eax, [r15+0x108]
00007bdc0b3d150c  sahf
00007bdc0b3d150d  jz 0x00007BDC0B3D153F
00007bdc0b3d150f  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d1517  jz 0x00007BDC0B3D1120
00007bdc0b3d151d  nop [rax+rax*1], ax
00007bdc0b3d1526  nop [rax+rax*1], eax
00007bdc0b3d152e  mov eax, 0x410378
00007bdc0b3d1533  mov [r15+0x100], rax
00007bdc0b3d153a  jmp 0x00007BDC0B1FE110
00007bdc0b3d153f  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d1547  jz 0x00007BDC0B3D1580
00007bdc0b3d154d  nop [rax+rax*1], ax
00007bdc0b3d1556  nop [rax+rax*1], eax
00007bdc0b3d155e  mov eax, 0x4103A0
00007bdc0b3d1563  mov [r15+0x100], rax
00007bdc0b3d156a  jmp 0x00007BDC0B1FE110
00007bdc0b3d156f  int3
00007bdc0b3d1570  call 0x00007BDC0B2A4270
00007bdc0b3d1575  jmp 0x00007BDC0B3D14EE
00007bdc0b3d157a  int3
00007bdc0b3d157b  nop [rax+rax*1], eax
00007bdc0b3d1580  mov qword ptr [r15+0x40], 0x430000
00007bdc0b3d1588  mov eax, 0x430C40
00007bdc0b3d158d  mov r14, [r13+rax*1]
00007bdc0b3d1592  mov rax, [r15+0x98]
00007bdc0b3d1599  mov r12d, [r13+rax*1]
00007bdc0b3d159e  lea r11, [rax+0x04]
00007bdc0b3d15a2  mov eax, [r13+r11*1]
00007bdc0b3d15a7  mov r12d, r12d
00007bdc0b3d15aa  mov [r15+0x68], r12
00007bdc0b3d15ae  mov eax, eax
00007bdc0b3d15b0  mov [r15+0x60], rax
00007bdc0b3d15b4  mov rax, [r15+0x68]
00007bdc0b3d15b8  mov [r15+0x68], rax
00007bdc0b3d15bc  mov qword ptr [r15+0x58], 0x02
00007bdc0b3d15c4  mov [rsp+0x10], rax
00007bdc0b3d15c9  xor eax, eax
00007bdc0b3d15cb  mov r12d, 0x02
00007bdc0b3d15d1  mov r11d, 0x400
00007bdc0b3d15d7  cmp r12, r11
00007bdc0b3d15da  cmc
00007bdc0b3d15db  lahf
00007bdc0b3d15dc  seto al
00007bdc0b3d15df  mov [r15+0x108], eax
00007bdc0b3d15e6  mov rax, [r15+0x60]
00007bdc0b3d15ea  mov r12d, 0x02
00007bdc0b3d15f0  imul rax, r12
00007bdc0b3d15f4  mov [r15+0x50], rax
00007bdc0b3d15f8  mov rax, [rsp+0x10]
00007bdc0b3d15fd  lea r12, [rax+r14*1]
00007bdc0b3d1601  mov [r15+0x48], r12
00007bdc0b3d1605  mov eax, [r15+0x108]
00007bdc0b3d160c  sahf
00007bdc0b3d160d  jnz 0x00007BDC0B3D163F
00007bdc0b3d160f  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d1617  jz 0x00007BDC0B3D17B0
00007bdc0b3d161d  nop [rax+rax*1], ax
00007bdc0b3d1626  nop [rax+rax*1], eax
00007bdc0b3d162e  mov eax, 0x4103D0
00007bdc0b3d1633  mov [r15+0x100], rax
00007bdc0b3d163a  jmp 0x00007BDC0B1FE110
00007bdc0b3d163f  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d1647  jz 0x00007BDC0B3D1690
00007bdc0b3d164d  nop [rax+rax*1], ax
00007bdc0b3d1656  nop [rax+rax*1], eax
00007bdc0b3d165e  mov eax, 0x4103B0
00007bdc0b3d1663  mov [r15+0x100], rax
00007bdc0b3d166a  jmp 0x00007BDC0B1FE110
00007bdc0b3d166f  int3
00007bdc0b3d1670  call 0x00007BDC0B20DC20
00007bdc0b3d1675  jmp 0x00007BDC0B3D1592
00007bdc0b3d167a  call 0x00007BDC0B20B5E0
00007bdc0b3d167f  jmp 0x00007BDC0B3D159E
00007bdc0b3d1684  call 0x00007BDC0B2A3D90
00007bdc0b3d1689  jmp 0x00007BDC0B3D15A7
00007bdc0b3d168e  int3
00007bdc0b3d168f  nop
00007bdc0b3d1690  mov rax, [r15+0x98]
00007bdc0b3d1697  mov r14, [r15+0x58]
00007bdc0b3d169b  mov [rsp+0x10], r14
00007bdc0b3d16a0  shl r14, 0x02
00007bdc0b3d16a4  lea r12, [rax+r14*1]
00007bdc0b3d16a8  mov eax, [r13+r12*1]
00007bdc0b3d16ad  lea r14, [r12+0x04]
00007bdc0b3d16b2  mov r12d, [r13+r14*1]
00007bdc0b3d16b7  mov eax, eax
00007bdc0b3d16b9  mov [r15+0x68], rax
00007bdc0b3d16bd  mov r12d, r12d
00007bdc0b3d16c0  mov [r15+0x60], r12
00007bdc0b3d16c4  mov rax, [r15+0x68]
00007bdc0b3d16c8  mov [rsp+0x20], rax
00007bdc0b3d16cd  mov r14, [rsp+0x10]
00007bdc0b3d16d2  imul rax, r14
00007bdc0b3d16d6  mov r12, [rsp+0x20]
00007bdc0b3d16db  lea r11, [r12+rax*1]
00007bdc0b3d16df  mov [r15+0x68], r11
00007bdc0b3d16e3  lea rax, [r14+0x02]
00007bdc0b3d16e7  mov [r15+0x58], rax
00007bdc0b3d16eb  mov [rsp+0x10], rax
00007bdc0b3d16f0  xor eax, eax
00007bdc0b3d16f2  mov r14, [rsp+0x10]
00007bdc0b3d16f7  mov r12d, 0x400
00007bdc0b3d16fd  cmp r14, r12
00007bdc0b3d1700  cmc
00007bdc0b3d1701  lahf
00007bdc0b3d1702  seto al
00007bdc0b3d1705  mov [r15+0x108], eax
00007bdc0b3d170c  mov rax, [r15+0x50]
00007bdc0b3d1710  mov r12, [r15+0x60]
00007bdc0b3d1714  imul r14, r12
00007bdc0b3d1718  lea r12, [rax+r14*1]
00007bdc0b3d171c  mov [r15+0x50], r12
00007bdc0b3d1720  mov rax, [r15+0x48]
00007bdc0b3d1724  lea r14, [r11+rax*1]
00007bdc0b3d1728  mov [r15+0x48], r14
00007bdc0b3d172c  mov eax, [r15+0x108]
00007bdc0b3d1733  sahf
00007bdc0b3d1734  jnz 0x00007BDC0B3D1766
00007bdc0b3d1736  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d173e  jz 0x00007BDC0B3D17B0
00007bdc0b3d1744  nop [rax+rax*1], ax
00007bdc0b3d174d  nop [rax+rax*1], eax
00007bdc0b3d1755  mov eax, 0x4103D0
00007bdc0b3d175a  mov [r15+0x100], rax
00007bdc0b3d1761  jmp 0x00007BDC0B1FE110
00007bdc0b3d1766  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d176e  jz 0x00007BDC0B3D1690
00007bdc0b3d1774  nop [rax+rax*1], ax
00007bdc0b3d177d  nop [rax+rax*1], eax
00007bdc0b3d1785  mov eax, 0x4103B0
00007bdc0b3d178a  mov [r15+0x100], rax
00007bdc0b3d1791  jmp 0x00007BDC0B1FE110
00007bdc0b3d1796  int3
00007bdc0b3d1797  call 0x00007BDC0B2B4690
00007bdc0b3d179c  jmp 0x00007BDC0B3D16AD
00007bdc0b3d17a1  call 0x00007BDC0B2E26A0
00007bdc0b3d17a6  jmp 0x00007BDC0B3D16B7
00007bdc0b3d17ab  int3
00007bdc0b3d17ac  nop [rax], eax
00007bdc0b3d17b0  mov qword ptr [r15+0x98], 0x00
00007bdc0b3d17bb  mov rax, [r15+0x50]
00007bdc0b3d17bf  mov r14, [r15+0x48]
00007bdc0b3d17c3  lea r12, [rax+r14*1]
00007bdc0b3d17c7  mov [r15+0x48], r12
00007bdc0b3d17cb  mov rax, [r15+0x40]
00007bdc0b3d17cf  lea r14, [rax+0xC40]
00007bdc0b3d17d6  mov [r13+r14*1], r12
00007bdc0b3d17db  mov qword ptr [r15], 0x01
00007bdc0b3d17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007bdc0b3d17ed  mov r14d, [r15+0x320]
00007bdc0b3d17f4  mov eax, 0x4103E8
00007bdc0b3d17f9  mov rcx, 0x7BDC0B3D1860
00007bdc0b3d1803  mov [r15+r14*8+0x328], rax
00007bdc0b3d180b  mov [r15+r14*8+0x368], rcx
00007bdc0b3d1813  add r14d, 0x01
00007bdc0b3d1817  and r14d, 0x07
00007bdc0b3d181b  mov [r15+0x320], r14d
00007bdc0b3d1822  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d182a  jz 0x00007BDC0B3D0F20
00007bdc0b3d1830  nop [rax+rax*1], ax
00007bdc0b3d1839  nop [rax+rax*1], eax
00007bdc0b3d1841  mov eax, 0x410938
00007bdc0b3d1846  mov [r15+0x100], rax
00007bdc0b3d184d  jmp 0x00007BDC0B1FE110
00007bdc0b3d1852  int3
00007bdc0b3d1853  call 0x00007BDC0B2E2CE0
00007bdc0b3d1858  jmp 0x00007BDC0B3D17DB
00007bdc0b3d185d  int3
00007bdc0b3d185e  nop
00007bdc0b3d1860  mov eax, [r15+0x98]
00007bdc0b3d1867  lea r14d, [eax+0x01]
00007bdc0b3d186c  mov [rsp+0x10], r14d
00007bdc0b3d1871  mov r14d, r14d
00007bdc0b3d1874  mov [r15+0x98], r14
00007bdc0b3d187b  xor eax, eax
00007bdc0b3d187d  mov r14d, [rsp+0x10]
00007bdc0b3d1882  cmp r14d, 0x10000
00007bdc0b3d1889  cmc
00007bdc0b3d188a  lahf
00007bdc0b3d188b  seto al
00007bdc0b3d188e  mov [r15+0x108], eax
00007bdc0b3d1895  mov eax, [r15+0x108]
00007bdc0b3d189c  sahf
00007bdc0b3d189d  jnz 0x00007BDC0B3D18CF
00007bdc0b3d189f  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d18a7  jz 0x00007BDC0B3D19A0
00007bdc0b3d18ad  nop [rax+rax*1], ax
00007bdc0b3d18b6  nop [rax+rax*1], eax
00007bdc0b3d18be  mov eax, 0x4103F4
00007bdc0b3d18c3  mov [r15+0x100], rax
00007bdc0b3d18ca  jmp 0x00007BDC0B1FE110
00007bdc0b3d18cf  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d18d7  jz 0x00007BDC0B3D1910
00007bdc0b3d18dd  nop [rax+rax*1], ax
00007bdc0b3d18e6  nop [rax+rax*1], eax
00007bdc0b3d18ee  mov eax, 0x4103E0
00007bdc0b3d18f3  mov [r15+0x100], rax
00007bdc0b3d18fa  jmp 0x00007BDC0B1FE110
00007bdc0b3d18ff  int3
00007bdc0b3d1900  int3
00007bdc0b3d1901  nop [rax+rax*1], ax
00007bdc0b3d190a  nop [rax+rax*1], ax
00007bdc0b3d1910  mov eax, [r15]
00007bdc0b3d1913  mov r14d, [r15+0x98]
00007bdc0b3d191a  lea r12d, [eax+r14d*1]
00007bdc0b3d191f  mov r12d, r12d
00007bdc0b3d1922  mov [r15], r12
00007bdc0b3d1925  mov qword ptr [r15+0xF0], 0x4103E8
00007bdc0b3d1930  mov r14d, [r15+0x320]
00007bdc0b3d1937  mov eax, 0x4103E8
00007bdc0b3d193c  mov rcx, 0x7BDC0B3D1860
00007bdc0b3d1946  mov [r15+r14*8+0x328], rax
00007bdc0b3d194e  mov [r15+r14*8+0x368], rcx
00007bdc0b3d1956  add r14d, 0x01
00007bdc0b3d195a  and r14d, 0x07
00007bdc0b3d195e  mov [r15+0x320], r14d
00007bdc0b3d1965  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d196d  jz 0x00007BDC0B3D0F20
00007bdc0b3d1973  nop [rax+rax*1], ax
00007bdc0b3d197c  nop [rax+rax*1], eax
00007bdc0b3d1984  mov eax, 0x410938
00007bdc0b3d1989  mov [r15+0x100], rax
00007bdc0b3d1990  jmp 0x00007BDC0B1FE110
00007bdc0b3d1995  int3
00007bdc0b3d1996  int3
00007bdc0b3d1997  nop [rax+rax*1], ax
00007bdc0b3d19a0  vmovaps xmm1, [0x00007BDC0AFFE010]
00007bdc0b3d19a8  movq xmm1, xmm1
00007bdc0b3d19ac  movaps [r15+0x110], xmm1
00007bdc0b3d19b4  mov eax, 0x420AA0
00007bdc0b3d19b9  mov r14, [r13+rax*1]
00007bdc0b3d19be  movq xmm1, r14
00007bdc0b3d19c3  movaps [r15+0x120], xmm1
00007bdc0b3d19cb  vmovaps xmm1, [0x00007BDC0AFFE020]
00007bdc0b3d19d3  movq xmm1, xmm1
00007bdc0b3d19d7  movaps [r15+0x140], xmm1
00007bdc0b3d19df  vmovaps xmm1, [0x00007BDC0AFFE030]
00007bdc0b3d19e7  vpbroadcastq xmm1, xmm1
00007bdc0b3d19ec  movaps [r15+0x150], xmm1
00007bdc0b3d19f4  mov qword ptr [r15+0x40], 0x02
00007bdc0b3d19fc  vmovaps xmm15, [0x00007BDC0AFFE040]
00007bdc0b3d1a04  movq xmm15, xmm15
00007bdc0b3d1a09  movaps [r15+0x160], xmm15
00007bdc0b3d1a11  vmovaps xmm15, [0x00007BDC0AFFE050]
00007bdc0b3d1a19  vpbroadcastq xmm15, xmm15
00007bdc0b3d1a1e  movaps [r15+0x130], xmm15
00007bdc0b3d1a26  mov rax, [r15+0x40]
00007bdc0b3d1a2a  vmovq xmm14, rax
00007bdc0b3d1a2f  vpbroadcastq xmm14, xmm14
00007bdc0b3d1a34  movaps [r15+0x170], xmm14
00007bdc0b3d1a3c  mov eax, 0x4209D0
00007bdc0b3d1a41  movups xmm13, [r13+rax*1]
00007bdc0b3d1a47  mov qword ptr [r15+0x40], 0x431D90
00007bdc0b3d1a4f  mov eax, [r15]
00007bdc0b3d1a52  mov r14d, 0x430C48
00007bdc0b3d1a58  mov [r13+r14*1], eax
00007bdc0b3d1a5d  mov qword ptr [r15+0x50], 0x431F90
00007bdc0b3d1a65  vpmovqd xmm12, xmm13
00007bdc0b3d1a6b  pxor xmm11, xmm11
00007bdc0b3d1a70  punpcklqdq xmm12, xmm11
00007bdc0b3d1a75  movaps [r15+0x210], xmm12
00007bdc0b3d1a7d  movq xmm12, qword ptr [r15+0x140]
00007bdc0b3d1a86  movq xmm11, qword ptr [r15+0x120]
00007bdc0b3d1a8f  psubd xmm12, xmm11
00007bdc0b3d1a94  movq xmm12, xmm12
00007bdc0b3d1a99  paddq xmm13, xmm14
00007bdc0b3d1a9e  movaps [r15+0x180], xmm13
00007bdc0b3d1aa6  movq xmm14, qword ptr [r15+0x160]
00007bdc0b3d1aaf  paddd xmm11, xmm14
00007bdc0b3d1ab4  movq xmm11, xmm11
00007bdc0b3d1ab9  movq xmm11, xmm11
00007bdc0b3d1abe  movaps [r15+0x120], xmm11
00007bdc0b3d1ac6  pmovzxdq xmm12, xmm12
00007bdc0b3d1acc  psllq xmm12, 0x00
00007bdc0b3d1ad2  movq xmm14, qword ptr [r15+0x210]
00007bdc0b3d1adb  movq xmm13, qword ptr [r15+0x110]
00007bdc0b3d1ae4  paddd xmm14, xmm13
00007bdc0b3d1ae9  movq xmm14, xmm14
00007bdc0b3d1aee  vcvtuqq2pd xmm12, xmm12
00007bdc0b3d1af4  pmovzxdq xmm14, xmm14
00007bdc0b3d1afa  psllq xmm14, 0x00
00007bdc0b3d1b00  vcvtuqq2pd xmm14, xmm14
00007bdc0b3d1b06  movaps xmm13, xmm12
00007bdc0b3d1b0a  mulpd xmm13, xmm1
00007bdc0b3d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007bdc0b3d1b15  ptest xmm11, xmm11
00007bdc0b3d1b1b  jnz 0x00007BDC0B3D1C0F
00007bdc0b3d1b21  movaps [r15+0x220], xmm13
00007bdc0b3d1b29  mov eax, 0x431F90
00007bdc0b3d1b2e  movups [r13+rax*1], xmm13
00007bdc0b3d1b34  movaps xmm1, xmm14
00007bdc0b3d1b38  mulpd xmm1, xmm15
00007bdc0b3d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007bdc0b3d1b42  ptest xmm13, xmm13
00007bdc0b3d1b48  jnz 0x00007BDC0B3D1D5C
00007bdc0b3d1b4e  movaps [r15+0x210], xmm1
00007bdc0b3d1b56  mov eax, 0x431D90
00007bdc0b3d1b5b  movups [r13+rax*1], xmm1
00007bdc0b3d1b61  mov qword ptr [r15+0x48], 0x10
00007bdc0b3d1b69  xor eax, eax
00007bdc0b3d1b6b  mov r14d, 0x10
00007bdc0b3d1b71  mov r12d, 0x200
00007bdc0b3d1b77  cmp r14, r12
00007bdc0b3d1b7a  cmc
00007bdc0b3d1b7b  lahf
00007bdc0b3d1b7c  seto al
00007bdc0b3d1b7f  mov [r15+0x108], eax
00007bdc0b3d1b86  mov eax, [r15+0x108]
00007bdc0b3d1b8d  sahf
00007bdc0b3d1b8e  jnz 0x00007BDC0B3D1BC0
00007bdc0b3d1b90  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d1b98  jz 0x00007BDC0B3D2300
00007bdc0b3d1b9e  nop [rax+rax*1], ax
00007bdc0b3d1ba7  nop [rax+rax*1], eax
00007bdc0b3d1baf  mov eax, 0x410480
00007bdc0b3d1bb4  mov [r15+0x100], rax
00007bdc0b3d1bbb  jmp 0x00007BDC0B1FE110
00007bdc0b3d1bc0  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d1bc8  jz 0x00007BDC0B3D1EB0
00007bdc0b3d1bce  nop [rax+rax*1], ax
00007bdc0b3d1bd7  nop [rax+rax*1], eax
00007bdc0b3d1bdf  mov eax, 0x410440
00007bdc0b3d1be4  mov [r15+0x100], rax
00007bdc0b3d1beb  jmp 0x00007BDC0B1FE110
00007bdc0b3d1bf0  int3
00007bdc0b3d1bf1  call 0x00007BDC0B20DC20
00007bdc0b3d1bf6  jmp 0x00007BDC0B3D19BE
00007bdc0b3d1bfb  call 0x00007BDC0B20C260
00007bdc0b3d1c00  jmp 0x00007BDC0B3D1A47
00007bdc0b3d1c05  call 0x00007BDC0B2D5D70
00007bdc0b3d1c0a  jmp 0x00007BDC0B3D1A5D
00007bdc0b3d1c0f  sub rsp, 0x08
00007bdc0b3d1c13  push rax
00007bdc0b3d1c14  push rcx
00007bdc0b3d1c15  push rdx
00007bdc0b3d1c16  push rdi
00007bdc0b3d1c17  push rsi
00007bdc0b3d1c18  push r8
00007bdc0b3d1c1a  push r9
00007bdc0b3d1c1c  push r10
00007bdc0b3d1c1e  push r11
00007bdc0b3d1c20  sub rsp, 0xF0
00007bdc0b3d1c27  vmovaps [rsp], xmm0
00007bdc0b3d1c2c  vmovaps [rsp+0x10], xmm1
00007bdc0b3d1c32  vmovaps [rsp+0x20], xmm2
00007bdc0b3d1c38  vmovaps [rsp+0x30], xmm3
00007bdc0b3d1c3e  vmovaps [rsp+0x40], xmm4
00007bdc0b3d1c44  vmovaps [rsp+0x50], xmm5
00007bdc0b3d1c4a  vmovaps [rsp+0x60], xmm6
00007bdc0b3d1c50  vmovaps [rsp+0x70], xmm7
00007bdc0b3d1c56  vmovaps [rsp+0x80], xmm8
00007bdc0b3d1c5f  vmovaps [rsp+0x90], xmm9
00007bdc0b3d1c68  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d1c71  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d1c7a  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d1c83  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d1c8c  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d1c95  sub rsp, 0x30
00007bdc0b3d1c99  movaps [rsp], xmm13
00007bdc0b3d1c9e  movaps [rsp+0x10], xmm12
00007bdc0b3d1ca4  movaps [rsp+0x20], xmm1
00007bdc0b3d1ca9  lea rdi, [rsp]
00007bdc0b3d1cad  mov esi, 0x00
00007bdc0b3d1cb2  mov rax, 0x62CE440F2530
00007bdc0b3d1cbc  call rax
00007bdc0b3d1cbe  movaps xmm13, [rsp]
00007bdc0b3d1cc3  add rsp, 0x30
00007bdc0b3d1cc7  vmovaps xmm0, [rsp]
00007bdc0b3d1ccc  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d1cd2  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d1cd8  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d1cde  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d1ce4  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d1cea  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d1cf0  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d1cf6  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d1cff  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d1d08  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d1d11  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d1d1a  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d1d23  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d1d2c  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d1d35  add rsp, 0xF0
00007bdc0b3d1d3c  pop r11
00007bdc0b3d1d3e  pop r10
00007bdc0b3d1d40  pop r9
00007bdc0b3d1d42  pop r8
00007bdc0b3d1d44  pop rsi
00007bdc0b3d1d45  pop rdi
00007bdc0b3d1d46  pop rdx
00007bdc0b3d1d47  pop rcx
00007bdc0b3d1d48  pop rax
00007bdc0b3d1d49  add rsp, 0x08
00007bdc0b3d1d4d  jmp 0x00007BDC0B3D1B21
00007bdc0b3d1d52  call 0x00007BDC0B20C380
00007bdc0b3d1d57  jmp 0x00007BDC0B3D1B34
00007bdc0b3d1d5c  sub rsp, 0x08
00007bdc0b3d1d60  push rax
00007bdc0b3d1d61  push rcx
00007bdc0b3d1d62  push rdx
00007bdc0b3d1d63  push rdi
00007bdc0b3d1d64  push rsi
00007bdc0b3d1d65  push r8
00007bdc0b3d1d67  push r9
00007bdc0b3d1d69  push r10
00007bdc0b3d1d6b  push r11
00007bdc0b3d1d6d  sub rsp, 0xF0
00007bdc0b3d1d74  vmovaps [rsp], xmm0
00007bdc0b3d1d79  vmovaps [rsp+0x10], xmm2
00007bdc0b3d1d7f  vmovaps [rsp+0x20], xmm3
00007bdc0b3d1d85  vmovaps [rsp+0x30], xmm4
00007bdc0b3d1d8b  vmovaps [rsp+0x40], xmm5
00007bdc0b3d1d91  vmovaps [rsp+0x50], xmm6
00007bdc0b3d1d97  vmovaps [rsp+0x60], xmm7
00007bdc0b3d1d9d  vmovaps [rsp+0x70], xmm8
00007bdc0b3d1da3  vmovaps [rsp+0x80], xmm9
00007bdc0b3d1dac  vmovaps [rsp+0x90], xmm10
00007bdc0b3d1db5  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d1dbe  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d1dc7  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d1dd0  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d1dd9  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d1de2  sub rsp, 0x30
00007bdc0b3d1de6  movaps [rsp], xmm1
00007bdc0b3d1dea  movaps [rsp+0x10], xmm14
00007bdc0b3d1df0  movaps [rsp+0x20], xmm15
00007bdc0b3d1df6  lea rdi, [rsp]
00007bdc0b3d1dfa  mov esi, 0x00
00007bdc0b3d1dff  mov rax, 0x62CE440F2530
00007bdc0b3d1e09  call rax
00007bdc0b3d1e0b  movaps xmm1, [rsp]
00007bdc0b3d1e0f  add rsp, 0x30
00007bdc0b3d1e13  vmovaps xmm0, [rsp]
00007bdc0b3d1e18  vmovaps xmm2, [rsp+0x10]
00007bdc0b3d1e1e  vmovaps xmm3, [rsp+0x20]
00007bdc0b3d1e24  vmovaps xmm4, [rsp+0x30]
00007bdc0b3d1e2a  vmovaps xmm5, [rsp+0x40]
00007bdc0b3d1e30  vmovaps xmm6, [rsp+0x50]
00007bdc0b3d1e36  vmovaps xmm7, [rsp+0x60]
00007bdc0b3d1e3c  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d1e42  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d1e4b  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d1e54  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d1e5d  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d1e66  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d1e6f  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d1e78  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d1e81  add rsp, 0xF0
00007bdc0b3d1e88  pop r11
00007bdc0b3d1e8a  pop r10
00007bdc0b3d1e8c  pop r9
00007bdc0b3d1e8e  pop r8
00007bdc0b3d1e90  pop rsi
00007bdc0b3d1e91  pop rdi
00007bdc0b3d1e92  pop rdx
00007bdc0b3d1e93  pop rcx
00007bdc0b3d1e94  pop rax
00007bdc0b3d1e95  add rsp, 0x08
00007bdc0b3d1e99  jmp 0x00007BDC0B3D1B4E
00007bdc0b3d1e9e  call 0x00007BDC0B1FF540
00007bdc0b3d1ea3  jmp 0x00007BDC0B3D1B61
00007bdc0b3d1ea8  int3
00007bdc0b3d1ea9  nop [rax], eax
00007bdc0b3d1eb0  movaps xmm1, [r15+0x180]
00007bdc0b3d1eb8  vpmovqd xmm15, xmm1
00007bdc0b3d1ebe  pxor xmm14, xmm14
00007bdc0b3d1ec3  punpcklqdq xmm15, xmm14
00007bdc0b3d1ec8  movaps [r15+0x210], xmm15
00007bdc0b3d1ed0  movq xmm15, qword ptr [r15+0x140]
00007bdc0b3d1ed9  movq xmm14, qword ptr [r15+0x120]
00007bdc0b3d1ee2  psubd xmm15, xmm14
00007bdc0b3d1ee7  movq xmm15, xmm15
00007bdc0b3d1eec  movaps xmm13, [r15+0x170]
00007bdc0b3d1ef4  paddq xmm1, xmm13
00007bdc0b3d1ef9  movaps [r15+0x180], xmm1
00007bdc0b3d1f01  movq xmm1, qword ptr [r15+0x160]
00007bdc0b3d1f0a  paddd xmm14, xmm1
00007bdc0b3d1f0f  movq xmm14, xmm14
00007bdc0b3d1f14  movq xmm14, xmm14
00007bdc0b3d1f19  movaps [r15+0x120], xmm14
00007bdc0b3d1f21  pmovzxdq xmm15, xmm15
00007bdc0b3d1f27  psllq xmm15, 0x00
00007bdc0b3d1f2d  movq xmm1, qword ptr [r15+0x210]
00007bdc0b3d1f36  movq xmm14, qword ptr [r15+0x110]
00007bdc0b3d1f3f  paddd xmm1, xmm14
00007bdc0b3d1f44  movq xmm1, xmm1
00007bdc0b3d1f48  vcvtuqq2pd xmm15, xmm15
00007bdc0b3d1f4e  pmovzxdq xmm1, xmm1
00007bdc0b3d1f53  psllq xmm1, 0x00
00007bdc0b3d1f58  vcvtuqq2pd xmm1, xmm1
00007bdc0b3d1f5e  movaps xmm14, [r15+0x150]
00007bdc0b3d1f66  movaps xmm13, xmm15
00007bdc0b3d1f6a  mulpd xmm13, xmm14
00007bdc0b3d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d1f75  ptest xmm12, xmm12
00007bdc0b3d1f7b  jnz 0x00007BDC0B3D205E
00007bdc0b3d1f81  movaps [r15+0x220], xmm13
00007bdc0b3d1f89  mov rax, [r15+0x48]
00007bdc0b3d1f8d  mov r14, [r15+0x50]
00007bdc0b3d1f91  lea r12, [r14+rax*1]
00007bdc0b3d1f95  movups [r13+r12*1], xmm13
00007bdc0b3d1f9b  movaps xmm15, [r15+0x130]
00007bdc0b3d1fa3  movaps xmm14, xmm1
00007bdc0b3d1fa7  mulpd xmm14, xmm15
00007bdc0b3d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007bdc0b3d1fb2  ptest xmm13, xmm13
00007bdc0b3d1fb8  jnz 0x00007BDC0B3D21AC
00007bdc0b3d1fbe  movaps [r15+0x210], xmm14
00007bdc0b3d1fc6  mov r14, [r15+0x40]
00007bdc0b3d1fca  lea r12, [r14+rax*1]
00007bdc0b3d1fce  movups [r13+r12*1], xmm14
00007bdc0b3d1fd4  lea r14, [rax+0x10]
00007bdc0b3d1fd8  mov [r15+0x48], r14
00007bdc0b3d1fdc  xor eax, eax
00007bdc0b3d1fde  mov r12d, 0x200
00007bdc0b3d1fe4  cmp r14, r12
00007bdc0b3d1fe7  cmc
00007bdc0b3d1fe8  lahf
00007bdc0b3d1fe9  seto al
00007bdc0b3d1fec  mov [r15+0x108], eax
00007bdc0b3d1ff3  mov eax, [r15+0x108]
00007bdc0b3d1ffa  sahf
00007bdc0b3d1ffb  jnz 0x00007BDC0B3D202D
00007bdc0b3d1ffd  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d2005  jz 0x00007BDC0B3D2300
00007bdc0b3d200b  nop [rax+rax*1], ax
00007bdc0b3d2014  nop [rax+rax*1], eax
00007bdc0b3d201c  mov eax, 0x410480
00007bdc0b3d2021  mov [r15+0x100], rax
00007bdc0b3d2028  jmp 0x00007BDC0B1FE110
00007bdc0b3d202d  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d2035  jz 0x00007BDC0B3D1EB0
00007bdc0b3d203b  nop [rax+rax*1], ax
00007bdc0b3d2044  nop [rax+rax*1], eax
00007bdc0b3d204c  mov eax, 0x410440
00007bdc0b3d2051  mov [r15+0x100], rax
00007bdc0b3d2058  jmp 0x00007BDC0B1FE110
00007bdc0b3d205d  int3
00007bdc0b3d205e  sub rsp, 0x08
00007bdc0b3d2062  push rax
00007bdc0b3d2063  push rcx
00007bdc0b3d2064  push rdx
00007bdc0b3d2065  push rdi
00007bdc0b3d2066  push rsi
00007bdc0b3d2067  push r8
00007bdc0b3d2069  push r9
00007bdc0b3d206b  push r10
00007bdc0b3d206d  push r11
00007bdc0b3d206f  sub rsp, 0xF0
00007bdc0b3d2076  vmovaps [rsp], xmm0
00007bdc0b3d207b  vmovaps [rsp+0x10], xmm1
00007bdc0b3d2081  vmovaps [rsp+0x20], xmm2
00007bdc0b3d2087  vmovaps [rsp+0x30], xmm3
00007bdc0b3d208d  vmovaps [rsp+0x40], xmm4
00007bdc0b3d2093  vmovaps [rsp+0x50], xmm5
00007bdc0b3d2099  vmovaps [rsp+0x60], xmm6
00007bdc0b3d209f  vmovaps [rsp+0x70], xmm7
00007bdc0b3d20a5  vmovaps [rsp+0x80], xmm8
00007bdc0b3d20ae  vmovaps [rsp+0x90], xmm9
00007bdc0b3d20b7  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d20c0  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d20c9  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d20d2  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d20db  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d20e4  sub rsp, 0x30
00007bdc0b3d20e8  movaps [rsp], xmm13
00007bdc0b3d20ed  movaps [rsp+0x10], xmm15
00007bdc0b3d20f3  movaps [rsp+0x20], xmm14
00007bdc0b3d20f9  lea rdi, [rsp]
00007bdc0b3d20fd  mov esi, 0x00
00007bdc0b3d2102  mov rax, 0x62CE440F2530
00007bdc0b3d210c  call rax
00007bdc0b3d210e  movaps xmm13, [rsp]
00007bdc0b3d2113  add rsp, 0x30
00007bdc0b3d2117  vmovaps xmm0, [rsp]
00007bdc0b3d211c  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d2122  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d2128  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d212e  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d2134  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d213a  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d2140  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d2146  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d214f  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d2158  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d2161  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d216a  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d2173  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d217c  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d2185  add rsp, 0xF0
00007bdc0b3d218c  pop r11
00007bdc0b3d218e  pop r10
00007bdc0b3d2190  pop r9
00007bdc0b3d2192  pop r8
00007bdc0b3d2194  pop rsi
00007bdc0b3d2195  pop rdi
00007bdc0b3d2196  pop rdx
00007bdc0b3d2197  pop rcx
00007bdc0b3d2198  pop rax
00007bdc0b3d2199  add rsp, 0x08
00007bdc0b3d219d  jmp 0x00007BDC0B3D1F81
00007bdc0b3d21a2  call 0x00007BDC0B2C2240
00007bdc0b3d21a7  jmp 0x00007BDC0B3D1F9B
00007bdc0b3d21ac  sub rsp, 0x08
00007bdc0b3d21b0  push rax
00007bdc0b3d21b1  push rcx
00007bdc0b3d21b2  push rdx
00007bdc0b3d21b3  push rdi
00007bdc0b3d21b4  push rsi
00007bdc0b3d21b5  push r8
00007bdc0b3d21b7  push r9
00007bdc0b3d21b9  push r10
00007bdc0b3d21bb  push r11
00007bdc0b3d21bd  sub rsp, 0xF0
00007bdc0b3d21c4  vmovaps [rsp], xmm0
00007bdc0b3d21c9  vmovaps [rsp+0x10], xmm1
00007bdc0b3d21cf  vmovaps [rsp+0x20], xmm2
00007bdc0b3d21d5  vmovaps [rsp+0x30], xmm3
00007bdc0b3d21db  vmovaps [rsp+0x40], xmm4
00007bdc0b3d21e1  vmovaps [rsp+0x50], xmm5
00007bdc0b3d21e7  vmovaps [rsp+0x60], xmm6
00007bdc0b3d21ed  vmovaps [rsp+0x70], xmm7
00007bdc0b3d21f3  vmovaps [rsp+0x80], xmm8
00007bdc0b3d21fc  vmovaps [rsp+0x90], xmm9
00007bdc0b3d2205  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d220e  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d2217  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d2220  vmovaps [rsp+0xD0], xmm13
00007bdc0b3d2229  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d2232  sub rsp, 0x30
00007bdc0b3d2236  movaps [rsp], xmm14
00007bdc0b3d223b  movaps [rsp+0x10], xmm1
00007bdc0b3d2240  movaps [rsp+0x20], xmm15
00007bdc0b3d2246  lea rdi, [rsp]
00007bdc0b3d224a  mov esi, 0x00
00007bdc0b3d224f  mov rax, 0x62CE440F2530
00007bdc0b3d2259  call rax
00007bdc0b3d225b  movaps xmm14, [rsp]
00007bdc0b3d2260  add rsp, 0x30
00007bdc0b3d2264  vmovaps xmm0, [rsp]
00007bdc0b3d2269  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d226f  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d2275  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d227b  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d2281  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d2287  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d228d  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d2293  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d229c  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d22a5  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d22ae  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d22b7  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d22c0  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3d22c9  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d22d2  add rsp, 0xF0
00007bdc0b3d22d9  pop r11
00007bdc0b3d22db  pop r10
00007bdc0b3d22dd  pop r9
00007bdc0b3d22df  pop r8
00007bdc0b3d22e1  pop rsi
00007bdc0b3d22e2  pop rdi
00007bdc0b3d22e3  pop rdx
00007bdc0b3d22e4  pop rcx
00007bdc0b3d22e5  pop rax
00007bdc0b3d22e6  add rsp, 0x08
00007bdc0b3d22ea  jmp 0x00007BDC0B3D1FBE
00007bdc0b3d22ef  call 0x00007BDC0B2C34C0
00007bdc0b3d22f4  jmp 0x00007BDC0B3D1FD4
00007bdc0b3d22f9  int3
00007bdc0b3d22fa  nop [rax+rax*1], ax
00007bdc0b3d2300  mov rax, [r15+0x50]
00007bdc0b3d2304  movups xmm1, [r13+rax*1]
00007bdc0b3d230a  lea r14, [rax+0x10]
00007bdc0b3d230e  movups xmm15, [r13+r14*1]
00007bdc0b3d2314  mov qword ptr [r15+0x48], 0x00
00007bdc0b3d231c  lea r14, [rax+0x40]
00007bdc0b3d2320  movups xmm14, [r13+r14*1]
00007bdc0b3d2326  lea r14, [rax+0x50]
00007bdc0b3d232a  movups xmm13, [r13+r14*1]
00007bdc0b3d2330  lea r14, [rax+0x80]
00007bdc0b3d2337  movups xmm12, [r13+r14*1]
00007bdc0b3d233d  lea r14, [rax+0x90]
00007bdc0b3d2344  movups xmm11, [r13+r14*1]
00007bdc0b3d234a  mov r14, [r15+0xF8]
00007bdc0b3d2351  movups [r13+r14*1], xmm1
00007bdc0b3d2357  lea r12, [rax+0x20]
00007bdc0b3d235b  movups xmm1, [r13+r12*1]
00007bdc0b3d2361  lea r12, [rax+0x30]
00007bdc0b3d2365  movups xmm10, [r13+r12*1]
00007bdc0b3d236b  lea r12, [rax+0xC0]
00007bdc0b3d2372  movups xmm9, [r13+r12*1]
00007bdc0b3d2378  lea r12, [rax+0xD0]
00007bdc0b3d237f  movups xmm8, [r13+r12*1]
00007bdc0b3d2385  lea r12, [rax+0x100]
00007bdc0b3d238c  movups xmm7, [r13+r12*1]
00007bdc0b3d2392  lea r12, [rax+0x110]
00007bdc0b3d2399  movups xmm6, [r13+r12*1]
00007bdc0b3d239f  lea r12, [rax+0x140]
00007bdc0b3d23a6  movups xmm5, [r13+r12*1]
00007bdc0b3d23ac  lea r12, [rax+0x150]
00007bdc0b3d23b3  movups xmm4, [r13+r12*1]
00007bdc0b3d23b9  lea r12, [r14+0xB0]
00007bdc0b3d23c0  movups [r13+r12*1], xmm10
00007bdc0b3d23c6  lea r12, [r14+0xC0]
00007bdc0b3d23cd  movups [r13+r12*1], xmm1
00007bdc0b3d23d3  lea r12, [rax+0x180]
00007bdc0b3d23da  movups xmm1, [r13+r12*1]
00007bdc0b3d23e0  lea r12, [rax+0x190]
00007bdc0b3d23e7  movups xmm10, [r13+r12*1]
00007bdc0b3d23ed  lea r12, [rax+0x1C0]
00007bdc0b3d23f4  movups xmm3, [r13+r12*1]
00007bdc0b3d23fa  lea r12, [rax+0x1D0]
00007bdc0b3d2401  movups xmm2, [r13+r12*1]
00007bdc0b3d2407  lea r12, [rax+0x60]
00007bdc0b3d240b  vmovaps [rsp+0x10], xmm1
00007bdc0b3d2411  movups xmm1, [r13+r12*1]
00007bdc0b3d2417  lea r12, [rax+0x70]
00007bdc0b3d241b  vmovaps [rsp+0x20], xmm1
00007bdc0b3d2421  movups xmm1, [r13+r12*1]
00007bdc0b3d2427  lea r12, [r14+0x70]
00007bdc0b3d242b  movups [r13+r12*1], xmm10
00007bdc0b3d2431  lea r12, [r14+0x80]
00007bdc0b3d2438  vmovaps xmm10, [rsp+0x10]
00007bdc0b3d243e  movups [r13+r12*1], xmm10
00007bdc0b3d2444  lea r12, [rax+0xA0]
00007bdc0b3d244b  movups xmm10, [r13+r12*1]
00007bdc0b3d2451  lea r12, [rax+0xB0]
00007bdc0b3d2458  vmovaps [rsp+0x10], xmm1
00007bdc0b3d245e  movups xmm1, [r13+r12*1]
00007bdc0b3d2464  lea r12, [r14+0x90]
00007bdc0b3d246b  movups [r13+r12*1], xmm2
00007bdc0b3d2471  lea r12, [r14+0xA0]
00007bdc0b3d2478  movups [r13+r12*1], xmm3
00007bdc0b3d247e  lea r12, [rax+0xE0]
00007bdc0b3d2485  movups xmm3, [r13+r12*1]
00007bdc0b3d248b  lea r12, [rax+0xF0]
00007bdc0b3d2492  movups xmm2, [r13+r12*1]
00007bdc0b3d2498  lea r12, [rax+0x120]
00007bdc0b3d249f  vmovaps [rsp+0x30], xmm1
00007bdc0b3d24a5  movups xmm1, [r13+r12*1]
00007bdc0b3d24ab  lea r12, [rax+0x130]
00007bdc0b3d24b2  vmovaps [rsp+0x40], xmm1
00007bdc0b3d24b8  movups xmm1, [r13+r12*1]
00007bdc0b3d24be  vmovaps [rsp+0x50], xmm1
00007bdc0b3d24c4  vmovaps xmm1, [rsp+0x40]
00007bdc0b3d24ca  movaps [r15+0x190], xmm1
00007bdc0b3d24d2  lea r12, [rax+0x160]
00007bdc0b3d24d9  vmovaps [rsp+0x40], xmm1
00007bdc0b3d24df  movups xmm1, [r13+r12*1]
00007bdc0b3d24e5  lea r12, [rax+0x170]
00007bdc0b3d24ec  vmovaps [rsp+0x60], xmm1
00007bdc0b3d24f2  movups xmm1, [r13+r12*1]
00007bdc0b3d24f8  lea r12, [rax+0x1A0]
00007bdc0b3d24ff  vmovaps [rsp+0x70], xmm1
00007bdc0b3d2505  movups xmm1, [r13+r12*1]
00007bdc0b3d250b  lea r12, [rax+0x1B0]
00007bdc0b3d2512  vmovaps [rsp+0x80], xmm1
00007bdc0b3d251b  movups xmm1, [r13+r12*1]
00007bdc0b3d2521  lea r12, [rax+0x1E0]
00007bdc0b3d2528  vmovaps [rsp+0x90], xmm1
00007bdc0b3d2531  movups xmm1, [r13+r12*1]
00007bdc0b3d2537  lea r12, [rax+0x1F0]
00007bdc0b3d253e  vmovaps [rsp+0xA0], xmm1
00007bdc0b3d2547  movups xmm1, [r13+r12*1]
00007bdc0b3d254d  mov qword ptr [r15+0x50], 0x432190
00007bdc0b3d2555  lea rax, [r14+0x50]
00007bdc0b3d2559  vmovaps [rsp+0xB0], xmm1
00007bdc0b3d2562  vmovaps xmm1, [rsp+0x60]
00007bdc0b3d2568  movups [r13+rax*1], xmm1
00007bdc0b3d256e  lea rax, [r14+0x60]
00007bdc0b3d2572  movups [r13+rax*1], xmm5
00007bdc0b3d2578  lea rax, [r14+0x40]
00007bdc0b3d257c  vmovaps xmm1, [rsp+0x70]
00007bdc0b3d2582  movups [r13+rax*1], xmm1
00007bdc0b3d2588  lea rax, [r14+0x20]
00007bdc0b3d258c  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3d2595  movups [r13+rax*1], xmm1
00007bdc0b3d259b  lea rax, [r14+0x30]
00007bdc0b3d259f  vmovaps xmm1, [rsp+0x90]
00007bdc0b3d25a8  movups [r13+rax*1], xmm1
00007bdc0b3d25ae  lea rax, [r14+0x10]
00007bdc0b3d25b2  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d25bb  movups [r13+rax*1], xmm1
00007bdc0b3d25c1  mov rax, [r15+0x40]
00007bdc0b3d25c5  vxorps xmm1, xmm1, xmm1
00007bdc0b3d25c9  vpbroadcastq xmm1, xmm1
00007bdc0b3d25ce  vxorps xmm5, xmm5, xmm5
00007bdc0b3d25d2  vpbroadcastq xmm5, xmm5
00007bdc0b3d25d7  lea r12, [rax+0x30]
00007bdc0b3d25db  mov r11, [r13+r12*1]
00007bdc0b3d25e0  lea r12, [rax+0x38]
00007bdc0b3d25e4  mov r10, [r13+r12*1]
00007bdc0b3d25e9  vmovaps [rsp+0x60], xmm1
00007bdc0b3d25ef  movq xmm1, r11
00007bdc0b3d25f4  vmovaps [rsp+0x70], xmm1
00007bdc0b3d25fa  movq xmm1, r10
00007bdc0b3d25ff  vmovaps [rsp+0x90], xmm1
00007bdc0b3d2608  vmovaps xmm1, [rsp+0x70]
00007bdc0b3d260e  movq xmm1, xmm1
00007bdc0b3d2612  vmovaps [rsp+0x70], xmm1
00007bdc0b3d2618  vmovaps xmm1, [rsp+0x90]
00007bdc0b3d2621  movq xmm1, xmm1
00007bdc0b3d2625  vmovaps [rsp+0x90], xmm1
00007bdc0b3d262e  movq xmm1, xmm1
00007bdc0b3d2632  movaps [r15+0x270], xmm1
00007bdc0b3d263a  vmovaps [rsp+0xA0], xmm7
00007bdc0b3d2643  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3d264c  por xmm7, xmm1
00007bdc0b3d2650  lea r12, [rax+0x20]
00007bdc0b3d2654  mov r11, [r13+r12*1]
00007bdc0b3d2659  lea r12, [rax+0x28]
00007bdc0b3d265d  mov r10, [r13+r12*1]
00007bdc0b3d2662  movq xmm1, r11
00007bdc0b3d2667  vmovaps [rsp+0xA0], xmm1
00007bdc0b3d2670  movq xmm1, r10
00007bdc0b3d2675  vmovaps [rsp+0xB0], xmm1
00007bdc0b3d267e  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3d2687  movq xmm1, xmm1
00007bdc0b3d268b  vmovaps [rsp+0xA0], xmm1
00007bdc0b3d2694  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d269d  movq xmm1, xmm1
00007bdc0b3d26a1  vmovaps [rsp+0xB0], xmm2
00007bdc0b3d26aa  vmovaps [rsp+0xC0], xmm1
00007bdc0b3d26b3  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d26bc  por xmm2, xmm1
00007bdc0b3d26c0  vmovaps [rsp+0xB0], xmm3
00007bdc0b3d26c9  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d26d2  por xmm3, xmm1
00007bdc0b3d26d6  vmovaps [rsp+0xB0], xmm4
00007bdc0b3d26df  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d26e8  por xmm4, xmm1
00007bdc0b3d26ec  vmovaps [rsp+0xB0], xmm9
00007bdc0b3d26f5  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d26fe  por xmm9, xmm1
00007bdc0b3d2703  lea r12, [rax+0x10]
00007bdc0b3d2707  mov r11, [r13+r12*1]
00007bdc0b3d270c  lea r12, [rax+0x18]
00007bdc0b3d2710  mov r10, [r13+r12*1]
00007bdc0b3d2715  movq xmm1, r11
00007bdc0b3d271a  vmovaps [rsp+0xB0], xmm1
00007bdc0b3d2723  movq xmm1, r10
00007bdc0b3d2728  vmovaps [rsp+0xD0], xmm1
00007bdc0b3d2731  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d273a  movq xmm1, xmm1
00007bdc0b3d273e  vmovaps [rsp+0xB0], xmm1
00007bdc0b3d2747  vmovaps xmm1, [rsp+0xD0]
00007bdc0b3d2750  movq xmm1, xmm1
00007bdc0b3d2754  vmovaps [rsp+0xD0], xmm1
00007bdc0b3d275d  vmovaps xmm1, [rsp+0x80]
00007bdc0b3d2766  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d276f  vmovaps xmm15, [rsp+0x80]
00007bdc0b3d2778  por xmm1, xmm15
00007bdc0b3d277d  vmovaps xmm15, [rsp+0x10]
00007bdc0b3d2783  vmovaps [rsp+0x80], xmm1
00007bdc0b3d278c  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d2792  por xmm15, xmm1
00007bdc0b3d2797  vmovaps xmm1, [rsp+0x20]
00007bdc0b3d279d  vmovaps [rsp+0x10], xmm15
00007bdc0b3d27a3  vmovaps xmm15, [rsp+0x20]
00007bdc0b3d27a9  por xmm1, xmm15
00007bdc0b3d27ae  vmovaps [rsp+0x20], xmm6
00007bdc0b3d27b4  vmovaps xmm15, [rsp+0x20]
00007bdc0b3d27ba  por xmm6, xmm15
00007bdc0b3d27bf  vmovaps [rsp+0x20], xmm11
00007bdc0b3d27c5  vmovaps xmm15, [rsp+0x20]
00007bdc0b3d27cb  por xmm11, xmm15
00007bdc0b3d27d0  vmovaps [rsp+0x20], xmm13
00007bdc0b3d27d6  vmovaps xmm15, [rsp+0x20]
00007bdc0b3d27dc  por xmm13, xmm15
00007bdc0b3d27e1  vmovaps [rsp+0x20], xmm14
00007bdc0b3d27e7  vmovaps xmm15, [rsp+0x20]
00007bdc0b3d27ed  por xmm14, xmm15
00007bdc0b3d27f2  mov r12, [r13+rax*1]
00007bdc0b3d27f7  vmovq xmm15, r12
00007bdc0b3d27fc  vpbroadcastq xmm15, xmm15
00007bdc0b3d2801  vmovaps [rsp+0x20], xmm1
00007bdc0b3d2807  vxorps xmm1, xmm1, xmm1
00007bdc0b3d280b  vpbroadcastq xmm1, xmm1
00007bdc0b3d2810  vmovaps [rsp+0xF0], xmm1
00007bdc0b3d2819  movups xmm1, [r13+r14*1]
00007bdc0b3d281f  vmovaps [rsp+0x100], xmm1
00007bdc0b3d2828  vxorps xmm1, xmm1, xmm1
00007bdc0b3d282c  vpbroadcastq xmm1, xmm1
00007bdc0b3d2831  lea r12, [rax+0x08]
00007bdc0b3d2835  mov rax, [r13+r12*1]
00007bdc0b3d283a  vmovaps [rsp+0x110], xmm1
00007bdc0b3d2843  movq xmm1, rax
00007bdc0b3d2848  movaps [r15+0x240], xmm1
00007bdc0b3d2850  mov qword ptr [r15+0x60], 0x432190
00007bdc0b3d2858  mov qword ptr [r15+0x58], 0x40
00007bdc0b3d2860  vmovaps xmm1, [rsp+0x60]
00007bdc0b3d2866  vmovaps [rsp+0x60], xmm15
00007bdc0b3d286c  vmovaps xmm15, [rsp+0x100]
00007bdc0b3d2875  vmovaps [rsp+0x100], xmm14
00007bdc0b3d287e  vmovaps xmm14, [rsp+0x60]
00007bdc0b3d2884  vmovaps [rsp+0x60], xmm13
00007bdc0b3d288a  vmovaps [rsp+0x120], xmm12
00007bdc0b3d2893  movaps xmm13, xmm1
00007bdc0b3d2897  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d28a2  vptest xmm12, xmm12
00007bdc0b3d28a7  jnz 0x00007BDC0B3D3482
00007bdc0b3d28ad  vmovaps xmm1, [rsp+0xE0]
00007bdc0b3d28b6  movaps xmm15, xmm5
00007bdc0b3d28ba  vfmadd231pd xmm15, xmm1, xmm14
00007bdc0b3d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007bdc0b3d28c5  vptest xmm12, xmm12
00007bdc0b3d28ca  jnz 0x00007BDC0B3D35DB
00007bdc0b3d28d0  vmovaps xmm12, [rsp+0x50]
00007bdc0b3d28d6  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d28dc  por xmm12, xmm5
00007bdc0b3d28e1  vmovaps xmm5, [rsp+0x30]
00007bdc0b3d28e7  vmovaps [rsp+0x50], xmm1
00007bdc0b3d28ed  vmovaps xmm1, [rsp+0x30]
00007bdc0b3d28f3  por xmm5, xmm1
00007bdc0b3d28f7  vmovaps [rsp+0x30], xmm10
00007bdc0b3d28fd  vmovaps xmm1, [rsp+0x30]
00007bdc0b3d2903  por xmm10, xmm1
00007bdc0b3d2908  vmovaps [rsp+0x30], xmm8
00007bdc0b3d290e  vmovaps xmm1, [rsp+0x30]
00007bdc0b3d2914  por xmm8, xmm1
00007bdc0b3d2919  vmovaps xmm1, [rsp+0x120]
00007bdc0b3d2922  vmovaps [rsp+0x30], xmm15
00007bdc0b3d2928  vmovaps xmm15, [rsp+0x120]
00007bdc0b3d2931  por xmm1, xmm15
00007bdc0b3d2936  vmovaps xmm15, [rsp+0x50]
00007bdc0b3d293c  vmovaps [rsp+0xE0], xmm1
00007bdc0b3d2945  vmovaps xmm1, [rsp+0x50]
00007bdc0b3d294b  por xmm15, xmm1
00007bdc0b3d2950  lea rax, [r14+0xC0]
00007bdc0b3d2957  movups xmm1, [r13+rax*1]
00007bdc0b3d295d  xor eax, eax
00007bdc0b3d295f  mov r12d, 0x40
00007bdc0b3d2965  mov r11d, 0x200
00007bdc0b3d296b  cmp r12, r11
00007bdc0b3d296e  cmc
00007bdc0b3d296f  lahf
00007bdc0b3d2970  seto al
00007bdc0b3d2973  mov [r15+0x108], eax
00007bdc0b3d297a  vmovaps [rsp+0x50], xmm1
00007bdc0b3d2980  vmovaps xmm1, [rsp+0xF0]
00007bdc0b3d2989  vmovaps [rsp+0xF0], xmm15
00007bdc0b3d2992  vmovaps xmm15, [rsp+0x50]
00007bdc0b3d2998  vmovaps [rsp+0x50], xmm13
00007bdc0b3d299e  vmovaps [rsp+0x120], xmm12
00007bdc0b3d29a7  movaps xmm13, xmm1
00007bdc0b3d29ab  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d29b6  vptest xmm12, xmm12
00007bdc0b3d29bb  jnz 0x00007BDC0B3D373D
00007bdc0b3d29c1  lea rax, [r14+0xB0]
00007bdc0b3d29c8  movups xmm1, [r13+rax*1]
00007bdc0b3d29ce  vmovaps xmm15, [rsp+0x110]
00007bdc0b3d29d7  vmovaps [rsp+0x110], xmm13
00007bdc0b3d29e0  movaps xmm12, xmm15
00007bdc0b3d29e4  vfmadd231pd xmm12, xmm1, xmm14
00007bdc0b3d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007bdc0b3d29ef  vptest xmm13, xmm13
00007bdc0b3d29f4  jnz 0x00007BDC0B3D38A0
00007bdc0b3d29fa  vmovaps xmm1, [rsp+0x100]
00007bdc0b3d2a03  vmovaps xmm15, [rsp+0x100]
00007bdc0b3d2a0c  por xmm1, xmm15
00007bdc0b3d2a11  movaps [r15+0x210], xmm1
00007bdc0b3d2a19  vmovaps xmm15, [rsp+0x60]
00007bdc0b3d2a1f  vmovaps xmm14, [rsp+0x60]
00007bdc0b3d2a25  por xmm15, xmm14
00007bdc0b3d2a2a  movaps [r15+0x1C0], xmm15
00007bdc0b3d2a32  vmovaps [rsp+0x60], xmm11
00007bdc0b3d2a38  vmovaps xmm14, [rsp+0x60]
00007bdc0b3d2a3e  por xmm11, xmm14
00007bdc0b3d2a43  movaps [r15+0x280], xmm11
00007bdc0b3d2a4b  vmovaps [rsp+0x60], xmm6
00007bdc0b3d2a51  vmovaps xmm14, [rsp+0x60]
00007bdc0b3d2a57  por xmm6, xmm14
00007bdc0b3d2a5c  movaps [r15+0x2A0], xmm6
00007bdc0b3d2a64  vmovaps xmm14, [rsp+0x20]
00007bdc0b3d2a6a  vmovaps xmm13, [rsp+0x20]
00007bdc0b3d2a70  por xmm14, xmm13
00007bdc0b3d2a75  movaps [r15+0x2E0], xmm14
00007bdc0b3d2a7d  vmovaps xmm13, [rsp+0x10]
00007bdc0b3d2a83  vmovaps [rsp+0x20], xmm1
00007bdc0b3d2a89  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d2a8f  por xmm13, xmm1
00007bdc0b3d2a94  movaps [r15+0x1F0], xmm13
00007bdc0b3d2a9c  vmovaps xmm1, [rsp+0xF0]
00007bdc0b3d2aa5  vmovaps [rsp+0x10], xmm15
00007bdc0b3d2aab  vmovaps xmm15, [rsp+0xF0]
00007bdc0b3d2ab4  por xmm1, xmm15
00007bdc0b3d2ab9  movaps [r15+0x250], xmm1
00007bdc0b3d2ac1  vmovaps xmm1, [rsp+0xE0]
00007bdc0b3d2aca  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d2ad3  por xmm1, xmm15
00007bdc0b3d2ad8  movaps [r15+0x260], xmm1
00007bdc0b3d2ae0  vmovaps [rsp+0x60], xmm8
00007bdc0b3d2ae6  vmovaps xmm15, [rsp+0x60]
00007bdc0b3d2aec  por xmm8, xmm15
00007bdc0b3d2af1  movaps [r15+0x290], xmm8
00007bdc0b3d2af9  vmovaps [rsp+0x60], xmm10
00007bdc0b3d2aff  vmovaps xmm15, [rsp+0x60]
00007bdc0b3d2b05  por xmm10, xmm15
00007bdc0b3d2b0a  movaps [r15+0x2C0], xmm10
00007bdc0b3d2b12  movq xmm15, qword ptr [r15+0x240]
00007bdc0b3d2b1b  vmovaps [rsp+0x60], xmm15
00007bdc0b3d2b21  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d2b27  vmovaps [rsp+0xE0], xmm1
00007bdc0b3d2b30  vmovaps xmm1, [rsp+0x50]
00007bdc0b3d2b36  vmovaps [rsp+0x50], xmm15
00007bdc0b3d2b3c  vmovaps xmm15, [rsp+0x20]
00007bdc0b3d2b42  vmovaps [rsp+0x20], xmm14
00007bdc0b3d2b48  vmovaps xmm14, [rsp+0x50]
00007bdc0b3d2b4e  vmovaps [rsp+0x50], xmm13
00007bdc0b3d2b54  vmovaps [rsp+0xF0], xmm12
00007bdc0b3d2b5d  movaps xmm13, xmm1
00007bdc0b3d2b61  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d2b6c  vptest xmm12, xmm12
00007bdc0b3d2b71  jnz 0x00007BDC0B3D39F9
00007bdc0b3d2b77  vmovaps xmm1, [rsp+0x60]
00007bdc0b3d2b7d  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d2b83  vmovaps xmm15, [rsp+0x110]
00007bdc0b3d2b8c  vmovaps xmm14, [rsp+0x20]
00007bdc0b3d2b92  vmovaps [rsp+0x20], xmm13
00007bdc0b3d2b98  movaps xmm12, xmm15
00007bdc0b3d2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007bdc0b3d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007bdc0b3d2ba7  vptest xmm13, xmm13
00007bdc0b3d2bac  jnz 0x00007BDC0B3D3B52
00007bdc0b3d2bb2  vmovaps xmm1, [rsp+0x60]
00007bdc0b3d2bb8  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d2bbe  vmovaps xmm15, [rsp+0x30]
00007bdc0b3d2bc4  vmovaps xmm14, [rsp+0x10]
00007bdc0b3d2bca  vmovaps [rsp+0x10], xmm12
00007bdc0b3d2bd0  movaps xmm13, xmm15
00007bdc0b3d2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007bdc0b3d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d2bdf  vptest xmm12, xmm12
00007bdc0b3d2be4  jnz 0x00007BDC0B3D3CAB
00007bdc0b3d2bea  vmovaps [rsp+0x30], xmm5
00007bdc0b3d2bf0  vmovaps xmm1, [rsp+0x30]
00007bdc0b3d2bf6  por xmm5, xmm1
00007bdc0b3d2bfa  movaps [r15+0x1D0], xmm5
00007bdc0b3d2c02  vmovaps xmm1, [rsp+0x60]
00007bdc0b3d2c08  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d2c0e  vmovaps xmm15, [rsp+0xF0]
00007bdc0b3d2c17  vmovaps xmm14, [rsp+0x50]
00007bdc0b3d2c1d  vmovaps [rsp+0x30], xmm13
00007bdc0b3d2c23  movaps xmm12, xmm15
00007bdc0b3d2c27  vfmadd231pd xmm12, xmm14, xmm1
00007bdc0b3d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007bdc0b3d2c32  vptest xmm13, xmm13
00007bdc0b3d2c37  jnz 0x00007BDC0B3D3E04
00007bdc0b3d2c3d  vmovaps xmm1, [rsp+0x80]
00007bdc0b3d2c46  vmovaps xmm15, [rsp+0x80]
00007bdc0b3d2c4f  por xmm1, xmm15
00007bdc0b3d2c54  movaps [r15+0x200], xmm1
00007bdc0b3d2c5c  vmovaps xmm15, [rsp+0x120]
00007bdc0b3d2c65  vmovaps xmm14, [rsp+0x120]
00007bdc0b3d2c6e  por xmm15, xmm14
00007bdc0b3d2c73  movaps [r15+0x1E0], xmm15
00007bdc0b3d2c7b  vmovaps [rsp+0x50], xmm4
00007bdc0b3d2c81  vmovaps xmm13, [rsp+0x50]
00007bdc0b3d2c87  por xmm4, xmm13
00007bdc0b3d2c8c  movaps [r15+0x2B0], xmm4
00007bdc0b3d2c94  vmovaps [rsp+0x50], xmm3
00007bdc0b3d2c9a  vmovaps xmm13, [rsp+0x50]
00007bdc0b3d2ca0  por xmm3, xmm13
00007bdc0b3d2ca5  movaps [r15+0x300], xmm3
00007bdc0b3d2cad  vmovaps xmm15, [rsp+0xB0]
00007bdc0b3d2cb6  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d2cbc  vmovaps xmm3, [rsp+0x20]
00007bdc0b3d2cc2  vmovaps [rsp+0x20], xmm1
00007bdc0b3d2cc8  vmovaps xmm1, [rsp+0xE0]
00007bdc0b3d2cd1  vmovaps [rsp+0x50], xmm14
00007bdc0b3d2cd7  vmovaps [rsp+0x60], xmm13
00007bdc0b3d2cdd  movaps xmm14, xmm3
00007bdc0b3d2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007bdc0b3d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007bdc0b3d2cec  vptest xmm13, xmm13
00007bdc0b3d2cf1  jnz 0x00007BDC0B3D3F5D
00007bdc0b3d2cf7  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d2d00  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d2d06  vmovaps xmm15, [rsp+0x10]
00007bdc0b3d2d0c  movaps xmm13, xmm15
00007bdc0b3d2d10  vfmadd231pd xmm13, xmm10, xmm1
00007bdc0b3d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007bdc0b3d2d1b  vptest xmm3, xmm3
00007bdc0b3d2d20  jnz 0x00007BDC0B3D40B5
00007bdc0b3d2d26  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d2d2f  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d2d35  vmovaps xmm15, [rsp+0x30]
00007bdc0b3d2d3b  movaps xmm10, xmm15
00007bdc0b3d2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007bdc0b3d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007bdc0b3d2d4a  vptest xmm3, xmm3
00007bdc0b3d2d4f  jnz 0x00007BDC0B3D420E
00007bdc0b3d2d55  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d2d5e  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d2d64  movaps xmm15, xmm12
00007bdc0b3d2d68  vfmadd231pd xmm15, xmm5, xmm1
00007bdc0b3d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007bdc0b3d2d73  vptest xmm11, xmm11
00007bdc0b3d2d78  jnz 0x00007BDC0B3D4367
00007bdc0b3d2d7e  vmovaps [rsp+0x10], xmm9
00007bdc0b3d2d84  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d2d8a  por xmm9, xmm1
00007bdc0b3d2d8f  movaps [r15+0x180], xmm9
00007bdc0b3d2d97  vmovaps [rsp+0x10], xmm2
00007bdc0b3d2d9d  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d2da3  por xmm2, xmm1
00007bdc0b3d2da7  movaps [r15+0x2D0], xmm2
00007bdc0b3d2daf  vmovaps xmm12, [rsp+0xD0]
00007bdc0b3d2db8  vpermilpd xmm12, xmm12, 0x00
00007bdc0b3d2dbe  vmovaps xmm11, [rsp+0x60]
00007bdc0b3d2dc4  movaps xmm5, xmm13
00007bdc0b3d2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007bdc0b3d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007bdc0b3d2dd2  vptest xmm3, xmm3
00007bdc0b3d2dd7  jnz 0x00007BDC0B3D44BF
00007bdc0b3d2ddd  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3d2de6  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3d2dec  movaps xmm12, xmm14
00007bdc0b3d2df0  vfmadd231pd xmm12, xmm9, xmm13
00007bdc0b3d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007bdc0b3d2dfb  vptest xmm11, xmm11
00007bdc0b3d2e00  jnz 0x00007BDC0B3D4617
00007bdc0b3d2e06  lea rax, [r14+0x80]
00007bdc0b3d2e0d  movups xmm14, [r13+rax*1]
00007bdc0b3d2e13  movaps [r15+0x2F0], xmm14
00007bdc0b3d2e1b  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3d2e24  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3d2e2a  movaps xmm11, xmm10
00007bdc0b3d2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007bdc0b3d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007bdc0b3d2e39  vptest xmm9, xmm9
00007bdc0b3d2e3e  jnz 0x00007BDC0B3D477B
00007bdc0b3d2e44  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3d2e4d  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3d2e53  movaps xmm10, xmm15
00007bdc0b3d2e57  vfmadd231pd xmm10, xmm1, xmm13
00007bdc0b3d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007bdc0b3d2e62  vptest xmm9, xmm9
00007bdc0b3d2e67  jnz 0x00007BDC0B3D48D5
00007bdc0b3d2e6d  vmovaps [rsp+0x10], xmm7
00007bdc0b3d2e73  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d2e79  por xmm7, xmm1
00007bdc0b3d2e7d  movaps [r15+0x160], xmm7
00007bdc0b3d2e85  lea rax, [r14+0x40]
00007bdc0b3d2e89  movups xmm1, [r13+rax*1]
00007bdc0b3d2e8f  lea rax, [r14+0x50]
00007bdc0b3d2e93  movups xmm15, [r13+rax*1]
00007bdc0b3d2e99  movaps [r15+0x1B0], xmm1
00007bdc0b3d2ea1  movaps [r15+0x1A0], xmm15
00007bdc0b3d2ea9  vmovaps xmm13, [rsp+0xA0]
00007bdc0b3d2eb2  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3d2eb8  vmovaps xmm9, [rsp+0x40]
00007bdc0b3d2ebe  movaps xmm8, xmm5
00007bdc0b3d2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007bdc0b3d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007bdc0b3d2ecd  vptest xmm3, xmm3
00007bdc0b3d2ed2  jnz 0x00007BDC0B3D4A42
00007bdc0b3d2ed8  vmovaps xmm13, [rsp+0xA0]
00007bdc0b3d2ee1  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3d2ee7  movaps xmm9, xmm12
00007bdc0b3d2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007bdc0b3d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007bdc0b3d2ef6  vptest xmm5, xmm5
00007bdc0b3d2efb  jnz 0x00007BDC0B3D4B9B
00007bdc0b3d2f01  vmovaps xmm13, [rsp+0xA0]
00007bdc0b3d2f0a  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3d2f10  movaps xmm12, xmm11
00007bdc0b3d2f14  vfmadd231pd xmm12, xmm6, xmm13
00007bdc0b3d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007bdc0b3d2f1f  vptest xmm7, xmm7
00007bdc0b3d2f24  jnz 0x00007BDC0B3D4CF4
00007bdc0b3d2f2a  vmovaps xmm13, [rsp+0xA0]
00007bdc0b3d2f33  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3d2f39  vmovaps xmm11, [rsp+0x50]
00007bdc0b3d2f3f  movaps xmm7, xmm10
00007bdc0b3d2f43  vfmadd231pd xmm7, xmm11, xmm13
00007bdc0b3d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007bdc0b3d2f4d  vptest xmm6, xmm6
00007bdc0b3d2f52  jnz 0x00007BDC0B3D4E4D
00007bdc0b3d2f58  lea rax, [r14+0x60]
00007bdc0b3d2f5c  movups xmm13, [r13+rax*1]
00007bdc0b3d2f62  lea rax, [r14+0x70]
00007bdc0b3d2f66  movups xmm11, [r13+rax*1]
00007bdc0b3d2f6c  movaps [r15+0x150], xmm13
00007bdc0b3d2f74  movaps [r15+0x120], xmm11
00007bdc0b3d2f7c  vmovaps xmm10, [rsp+0xC0]
00007bdc0b3d2f85  vpermilpd xmm10, xmm10, 0x00
00007bdc0b3d2f8b  movaps xmm6, xmm8
00007bdc0b3d2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007bdc0b3d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007bdc0b3d2f99  vptest xmm5, xmm5
00007bdc0b3d2f9e  jnz 0x00007BDC0B3D4FB9
00007bdc0b3d2fa4  vmovaps xmm15, [rsp+0xC0]
00007bdc0b3d2fad  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d2fb3  movaps xmm10, xmm9
00007bdc0b3d2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007bdc0b3d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007bdc0b3d2fc2  vptest xmm8, xmm8
00007bdc0b3d2fc7  jnz 0x00007BDC0B3D5111
00007bdc0b3d2fcd  vmovaps xmm15, [rsp+0xC0]
00007bdc0b3d2fd6  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d2fdc  movaps xmm13, xmm12
00007bdc0b3d2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007bdc0b3d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007bdc0b3d2feb  vptest xmm9, xmm9
00007bdc0b3d2ff0  jnz 0x00007BDC0B3D526B
00007bdc0b3d2ff6  vmovaps xmm15, [rsp+0xC0]
00007bdc0b3d2fff  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d3005  movaps xmm12, xmm7
00007bdc0b3d3009  vfmadd231pd xmm12, xmm1, xmm15
00007bdc0b3d300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007bdc0b3d3014  vptest xmm9, xmm9
00007bdc0b3d3019  jnz 0x00007BDC0B3D53C4
00007bdc0b3d301f  lea rax, [r14+0x20]
00007bdc0b3d3023  movups xmm1, [r13+rax*1]
00007bdc0b3d3029  lea rax, [r14+0x30]
00007bdc0b3d302d  movups xmm15, [r13+rax*1]
00007bdc0b3d3033  vmovaps xmm9, [rsp+0x70]
00007bdc0b3d3039  vpermilpd xmm9, xmm9, 0x00
00007bdc0b3d303f  vmovaps xmm8, [rsp+0x20]
00007bdc0b3d3045  movaps xmm7, xmm6
00007bdc0b3d3048  vfmadd231pd xmm7, xmm8, xmm9
00007bdc0b3d304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007bdc0b3d3052  vptest xmm5, xmm5
00007bdc0b3d3057  jnz 0x00007BDC0B3D5530
00007bdc0b3d305d  vmovaps xmm9, [rsp+0x70]
00007bdc0b3d3063  vpermilpd xmm9, xmm9, 0x00
00007bdc0b3d3069  movaps xmm8, xmm10
00007bdc0b3d306d  vfmadd231pd xmm8, xmm14, xmm9
00007bdc0b3d3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007bdc0b3d3078  vptest xmm6, xmm6
00007bdc0b3d307d  jnz 0x00007BDC0B3D5687
00007bdc0b3d3083  vmovaps xmm14, [rsp+0x70]
00007bdc0b3d3089  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3d308f  movaps xmm10, xmm13
00007bdc0b3d3093  vfmadd231pd xmm10, xmm11, xmm14
00007bdc0b3d3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007bdc0b3d309e  vptest xmm9, xmm9
00007bdc0b3d30a3  jnz 0x00007BDC0B3D57E1
00007bdc0b3d30a9  vmovaps xmm14, [rsp+0x70]
00007bdc0b3d30af  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3d30b5  movaps xmm13, xmm12
00007bdc0b3d30b9  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007bdc0b3d30c4  vptest xmm11, xmm11
00007bdc0b3d30c9  jnz 0x00007BDC0B3D593B
00007bdc0b3d30cf  lea rax, [r14+0x90]
00007bdc0b3d30d6  movups xmm15, [r13+rax*1]
00007bdc0b3d30dc  lea rax, [r14+0xA0]
00007bdc0b3d30e3  movups xmm14, [r13+rax*1]
00007bdc0b3d30e9  movaps [r15+0x140], xmm15
00007bdc0b3d30f1  movaps [r15+0x130], xmm14
00007bdc0b3d30f9  vmovaps xmm12, [rsp+0x90]
00007bdc0b3d3102  vpermilpd xmm12, xmm12, 0x00
00007bdc0b3d3108  movaps xmm11, xmm7
00007bdc0b3d310c  vfmadd231pd xmm11, xmm1, xmm12
00007bdc0b3d3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007bdc0b3d3117  vptest xmm9, xmm9
00007bdc0b3d311c  jnz 0x00007BDC0B3D5AA9
00007bdc0b3d3122  movaps [r15+0x220], xmm11
00007bdc0b3d312a  lea rax, [r14+0x10]
00007bdc0b3d312e  movups xmm1, [r13+rax*1]
00007bdc0b3d3134  movaps [r15+0x240], xmm1
00007bdc0b3d313c  vmovaps xmm12, [rsp+0x90]
00007bdc0b3d3145  vpermilpd xmm12, xmm12, 0x00
00007bdc0b3d314b  movaps xmm9, xmm8
00007bdc0b3d314f  vfmadd231pd xmm9, xmm14, xmm12
00007bdc0b3d3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007bdc0b3d315a  vptest xmm7, xmm7
00007bdc0b3d315f  jnz 0x00007BDC0B3D5C0B
00007bdc0b3d3165  movaps [r15+0x110], xmm9
00007bdc0b3d316d  vmovaps xmm14, [rsp+0x90]
00007bdc0b3d3176  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3d317c  movaps xmm12, xmm10
00007bdc0b3d3180  vfmadd231pd xmm12, xmm15, xmm14
00007bdc0b3d3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007bdc0b3d318b  vptest xmm8, xmm8
00007bdc0b3d3190  jnz 0x00007BDC0B3D5D65
00007bdc0b3d3196  movaps [r15+0x170], xmm12
00007bdc0b3d319e  vmovaps xmm15, [rsp+0x90]
00007bdc0b3d31a7  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d31ad  movaps xmm14, xmm13
00007bdc0b3d31b1  vfmadd231pd xmm14, xmm1, xmm15
00007bdc0b3d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007bdc0b3d31bc  vptest xmm10, xmm10
00007bdc0b3d31c1  jnz 0x00007BDC0B3D5EBF
00007bdc0b3d31c7  movaps [r15+0x230], xmm14
00007bdc0b3d31cf  mov eax, 0x432190
00007bdc0b3d31d4  movups [r13+rax*1], xmm9
00007bdc0b3d31da  mov eax, 0x4321A0
00007bdc0b3d31df  movups [r13+rax*1], xmm12
00007bdc0b3d31e5  mov eax, 0x4321B0
00007bdc0b3d31ea  movups [r13+rax*1], xmm11
00007bdc0b3d31f0  mov eax, 0x4321C0
00007bdc0b3d31f5  movups [r13+rax*1], xmm14
00007bdc0b3d31fb  mov eax, [r15+0x108]
00007bdc0b3d3202  sahf
00007bdc0b3d3203  jnz 0x00007BDC0B3D3235
00007bdc0b3d3205  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d320d  jz 0x00007BDC0B3D9950
00007bdc0b3d3213  nop [rax+rax*1], ax
00007bdc0b3d321c  nop [rax+rax*1], eax
00007bdc0b3d3224  mov eax, 0x410664
00007bdc0b3d3229  mov [r15+0x100], rax
00007bdc0b3d3230  jmp 0x00007BDC0B1FE110
00007bdc0b3d3235  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d323d  jz 0x00007BDC0B3D6050
00007bdc0b3d3243  nop [rax+rax*1], ax
00007bdc0b3d324c  nop [rax+rax*1], eax
00007bdc0b3d3254  mov eax, 0x4104F0
00007bdc0b3d3259  mov [r15+0x100], rax
00007bdc0b3d3260  jmp 0x00007BDC0B1FE110
00007bdc0b3d3265  int3
00007bdc0b3d3266  call 0x00007BDC0B1FF430
00007bdc0b3d326b  jmp 0x00007BDC0B3D230A
00007bdc0b3d3270  call 0x00007BDC0B2E5820
00007bdc0b3d3275  jmp 0x00007BDC0B3D2314
00007bdc0b3d327a  call 0x00007BDC0B2E45A0
00007bdc0b3d327f  jmp 0x00007BDC0B3D2326
00007bdc0b3d3284  call 0x00007BDC0B2E3320
00007bdc0b3d3289  jmp 0x00007BDC0B3D2330
00007bdc0b3d328e  call 0x00007BDC0B2E20A0
00007bdc0b3d3293  jmp 0x00007BDC0B3D233D
00007bdc0b3d3298  call 0x00007BDC0B2E0E30
00007bdc0b3d329d  jmp 0x00007BDC0B3D234A
00007bdc0b3d32a2  call 0x00007BDC0B2D6600
00007bdc0b3d32a7  jmp 0x00007BDC0B3D2357
00007bdc0b3d32ac  call 0x00007BDC0B2B52F0
00007bdc0b3d32b1  jmp 0x00007BDC0B3D2361
00007bdc0b3d32b6  call 0x00007BDC0B2BE9C0
00007bdc0b3d32bb  jmp 0x00007BDC0B3D236B
00007bdc0b3d32c0  call 0x00007BDC0B2BD750
00007bdc0b3d32c5  jmp 0x00007BDC0B3D2378
00007bdc0b3d32ca  call 0x00007BDC0B2BC4E0
00007bdc0b3d32cf  jmp 0x00007BDC0B3D2385
00007bdc0b3d32d4  call 0x00007BDC0B2BB270
00007bdc0b3d32d9  jmp 0x00007BDC0B3D2392
00007bdc0b3d32de  call 0x00007BDC0B2BA000
00007bdc0b3d32e3  jmp 0x00007BDC0B3D239F
00007bdc0b3d32e8  call 0x00007BDC0B2B8D90
00007bdc0b3d32ed  jmp 0x00007BDC0B3D23AC
00007bdc0b3d32f2  call 0x00007BDC0B2B8A20
00007bdc0b3d32f7  jmp 0x00007BDC0B3D23B9
00007bdc0b3d32fc  call 0x00007BDC0B2BEAE0
00007bdc0b3d3301  jmp 0x00007BDC0B3D23C6
00007bdc0b3d3306  call 0x00007BDC0B2B5400
00007bdc0b3d330b  jmp 0x00007BDC0B3D23D3
00007bdc0b3d3310  call 0x00007BDC0B2B52F0
00007bdc0b3d3315  jmp 0x00007BDC0B3D23E0
00007bdc0b3d331a  call 0x00007BDC0B2BE9C0
00007bdc0b3d331f  jmp 0x00007BDC0B3D23ED
00007bdc0b3d3324  call 0x00007BDC0B2B77B0
00007bdc0b3d3329  jmp 0x00007BDC0B3D23FA
00007bdc0b3d332e  call 0x00007BDC0B2B6550
00007bdc0b3d3333  jmp 0x00007BDC0B3D2407
00007bdc0b3d3338  call 0x00007BDC0B2B52F0
00007bdc0b3d333d  jmp 0x00007BDC0B3D2417
00007bdc0b3d3342  call 0x00007BDC0B2B52F0
00007bdc0b3d3347  jmp 0x00007BDC0B3D2427
00007bdc0b3d334c  call 0x00007BDC0B2BEAE0
00007bdc0b3d3351  jmp 0x00007BDC0B3D2431
00007bdc0b3d3356  call 0x00007BDC0B2BEAE0
00007bdc0b3d335b  jmp 0x00007BDC0B3D2444
00007bdc0b3d3360  call 0x00007BDC0B2BE9C0
00007bdc0b3d3365  jmp 0x00007BDC0B3D2451
00007bdc0b3d336a  call 0x00007BDC0B2B52F0
00007bdc0b3d336f  jmp 0x00007BDC0B3D2464
00007bdc0b3d3374  call 0x00007BDC0B2B6660
00007bdc0b3d3379  jmp 0x00007BDC0B3D2471
00007bdc0b3d337e  call 0x00007BDC0B2B78C0
00007bdc0b3d3383  jmp 0x00007BDC0B3D247E
00007bdc0b3d3388  call 0x00007BDC0B2B77B0
00007bdc0b3d338d  jmp 0x00007BDC0B3D248B
00007bdc0b3d3392  call 0x00007BDC0B2B6550
00007bdc0b3d3397  jmp 0x00007BDC0B3D2498
00007bdc0b3d339c  call 0x00007BDC0B2B52F0
00007bdc0b3d33a1  jmp 0x00007BDC0B3D24AB
00007bdc0b3d33a6  call 0x00007BDC0B2B52F0
00007bdc0b3d33ab  jmp 0x00007BDC0B3D24BE
00007bdc0b3d33b0  call 0x00007BDC0B2B52F0
00007bdc0b3d33b5  jmp 0x00007BDC0B3D24E5
00007bdc0b3d33ba  call 0x00007BDC0B2B52F0
00007bdc0b3d33bf  jmp 0x00007BDC0B3D24F8
00007bdc0b3d33c4  call 0x00007BDC0B2B52F0
00007bdc0b3d33c9  jmp 0x00007BDC0B3D250B
00007bdc0b3d33ce  call 0x00007BDC0B2B52F0
00007bdc0b3d33d3  jmp 0x00007BDC0B3D2521
00007bdc0b3d33d8  call 0x00007BDC0B2B52F0
00007bdc0b3d33dd  jmp 0x00007BDC0B3D2537
00007bdc0b3d33e2  call 0x00007BDC0B2B52F0
00007bdc0b3d33e7  jmp 0x00007BDC0B3D254D
00007bdc0b3d33ec  call 0x00007BDC0B1FF540
00007bdc0b3d33f1  jmp 0x00007BDC0B3D256E
00007bdc0b3d33f6  call 0x00007BDC0B202FE0
00007bdc0b3d33fb  jmp 0x00007BDC0B3D2578
00007bdc0b3d3400  call 0x00007BDC0B1FF540
00007bdc0b3d3405  jmp 0x00007BDC0B3D2588
00007bdc0b3d340a  call 0x00007BDC0B1FF540
00007bdc0b3d340f  jmp 0x00007BDC0B3D259B
00007bdc0b3d3414  call 0x00007BDC0B1FF540
00007bdc0b3d3419  jmp 0x00007BDC0B3D25AE
00007bdc0b3d341e  call 0x00007BDC0B1FF540
00007bdc0b3d3423  jmp 0x00007BDC0B3D25C1
00007bdc0b3d3428  call 0x00007BDC0B2C0370
00007bdc0b3d342d  jmp 0x00007BDC0B3D25E0
00007bdc0b3d3432  call 0x00007BDC0B2BF100
00007bdc0b3d3437  jmp 0x00007BDC0B3D25E9
00007bdc0b3d343c  call 0x00007BDC0B2C0370
00007bdc0b3d3441  jmp 0x00007BDC0B3D2659
00007bdc0b3d3446  call 0x00007BDC0B2BF100
00007bdc0b3d344b  jmp 0x00007BDC0B3D2662
00007bdc0b3d3450  call 0x00007BDC0B2C0370
00007bdc0b3d3455  jmp 0x00007BDC0B3D270C
00007bdc0b3d345a  call 0x00007BDC0B2BF100
00007bdc0b3d345f  jmp 0x00007BDC0B3D2715
00007bdc0b3d3464  call 0x00007BDC0B20B720
00007bdc0b3d3469  jmp 0x00007BDC0B3D27F7
00007bdc0b3d346e  call 0x00007BDC0B2D64F0
00007bdc0b3d3473  jmp 0x00007BDC0B3D281F
00007bdc0b3d3478  call 0x00007BDC0B2B47C0
00007bdc0b3d347d  jmp 0x00007BDC0B3D283A
00007bdc0b3d3482  sub rsp, 0x08
00007bdc0b3d3486  push rax
00007bdc0b3d3487  push rcx
00007bdc0b3d3488  push rdx
00007bdc0b3d3489  push rdi
00007bdc0b3d348a  push rsi
00007bdc0b3d348b  push r8
00007bdc0b3d348d  push r9
00007bdc0b3d348f  push r10
00007bdc0b3d3491  push r11
00007bdc0b3d3493  sub rsp, 0xF0
00007bdc0b3d349a  vmovaps [rsp], xmm0
00007bdc0b3d349f  vmovaps [rsp+0x10], xmm1
00007bdc0b3d34a5  vmovaps [rsp+0x20], xmm2
00007bdc0b3d34ab  vmovaps [rsp+0x30], xmm3
00007bdc0b3d34b1  vmovaps [rsp+0x40], xmm4
00007bdc0b3d34b7  vmovaps [rsp+0x50], xmm5
00007bdc0b3d34bd  vmovaps [rsp+0x60], xmm6
00007bdc0b3d34c3  vmovaps [rsp+0x70], xmm7
00007bdc0b3d34c9  vmovaps [rsp+0x80], xmm8
00007bdc0b3d34d2  vmovaps [rsp+0x90], xmm9
00007bdc0b3d34db  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d34e4  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d34ed  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d34f6  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d34ff  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d3508  sub rsp, 0x40
00007bdc0b3d350c  lea rdi, [rsp]
00007bdc0b3d3510  lea rsi, [rsp+0x10]
00007bdc0b3d3515  lea rdx, [rsp+0x20]
00007bdc0b3d351a  lea rcx, [rsp+0x30]
00007bdc0b3d351f  mov r8d, 0x00
00007bdc0b3d3525  lea r9, [r15+0x3A8]
00007bdc0b3d352c  movaps [rdi], xmm13
00007bdc0b3d3530  movaps [rsi], xmm1
00007bdc0b3d3533  movaps [rdx], xmm15
00007bdc0b3d3537  movaps [rcx], xmm14
00007bdc0b3d353b  mov rax, 0x62CE440F2A50
00007bdc0b3d3545  call rax
00007bdc0b3d3547  movaps xmm13, [rsp]
00007bdc0b3d354c  add rsp, 0x40
00007bdc0b3d3550  vmovaps xmm0, [rsp]
00007bdc0b3d3555  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d355b  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d3561  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d3567  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d356d  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d3573  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d3579  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d357f  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d3588  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d3591  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d359a  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d35a3  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d35ac  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d35b5  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d35be  add rsp, 0xF0
00007bdc0b3d35c5  pop r11
00007bdc0b3d35c7  pop r10
00007bdc0b3d35c9  pop r9
00007bdc0b3d35cb  pop r8
00007bdc0b3d35cd  pop rsi
00007bdc0b3d35ce  pop rdi
00007bdc0b3d35cf  pop rdx
00007bdc0b3d35d0  pop rcx
00007bdc0b3d35d1  pop rax
00007bdc0b3d35d2  add rsp, 0x08
00007bdc0b3d35d6  jmp 0x00007BDC0B3D28AD
00007bdc0b3d35db  sub rsp, 0x08
00007bdc0b3d35df  push rax
00007bdc0b3d35e0  push rcx
00007bdc0b3d35e1  push rdx
00007bdc0b3d35e2  push rdi
00007bdc0b3d35e3  push rsi
00007bdc0b3d35e4  push r8
00007bdc0b3d35e6  push r9
00007bdc0b3d35e8  push r10
00007bdc0b3d35ea  push r11
00007bdc0b3d35ec  sub rsp, 0xF0
00007bdc0b3d35f3  vmovaps [rsp], xmm0
00007bdc0b3d35f8  vmovaps [rsp+0x10], xmm1
00007bdc0b3d35fe  vmovaps [rsp+0x20], xmm2
00007bdc0b3d3604  vmovaps [rsp+0x30], xmm3
00007bdc0b3d360a  vmovaps [rsp+0x40], xmm4
00007bdc0b3d3610  vmovaps [rsp+0x50], xmm5
00007bdc0b3d3616  vmovaps [rsp+0x60], xmm6
00007bdc0b3d361c  vmovaps [rsp+0x70], xmm7
00007bdc0b3d3622  vmovaps [rsp+0x80], xmm8
00007bdc0b3d362b  vmovaps [rsp+0x90], xmm9
00007bdc0b3d3634  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d363d  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d3646  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d364f  vmovaps [rsp+0xD0], xmm13
00007bdc0b3d3658  vmovaps [rsp+0xE0], xmm14
00007bdc0b3d3661  sub rsp, 0x40
00007bdc0b3d3665  lea rdi, [rsp]
00007bdc0b3d3669  lea rsi, [rsp+0x10]
00007bdc0b3d366e  lea rdx, [rsp+0x20]
00007bdc0b3d3673  lea rcx, [rsp+0x30]
00007bdc0b3d3678  mov r8d, 0x00
00007bdc0b3d367e  lea r9, [r15+0x3A8]
00007bdc0b3d3685  movaps [rdi], xmm15
00007bdc0b3d3689  movaps [rsi], xmm5
00007bdc0b3d368c  movaps [rdx], xmm1
00007bdc0b3d368f  movaps [rcx], xmm14
00007bdc0b3d3693  mov rax, 0x62CE440F2A50
00007bdc0b3d369d  call rax
00007bdc0b3d369f  movaps xmm15, [rsp]
00007bdc0b3d36a4  add rsp, 0x40
00007bdc0b3d36a8  vmovaps xmm0, [rsp]
00007bdc0b3d36ad  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d36b3  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d36b9  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d36bf  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d36c5  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d36cb  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d36d1  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d36d7  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d36e0  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d36e9  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d36f2  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d36fb  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d3704  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3d370d  vmovaps xmm14, [rsp+0xE0]
00007bdc0b3d3716  add rsp, 0xF0
00007bdc0b3d371d  pop r11
00007bdc0b3d371f  pop r10
00007bdc0b3d3721  pop r9
00007bdc0b3d3723  pop r8
00007bdc0b3d3725  pop rsi
00007bdc0b3d3726  pop rdi
00007bdc0b3d3727  pop rdx
00007bdc0b3d3728  pop rcx
00007bdc0b3d3729  pop rax
00007bdc0b3d372a  add rsp, 0x08
00007bdc0b3d372e  jmp 0x00007BDC0B3D28D0
00007bdc0b3d3733  call 0x00007BDC0B1FF430
00007bdc0b3d3738  jmp 0x00007BDC0B3D295D
00007bdc0b3d373d  sub rsp, 0x08
00007bdc0b3d3741  push rax
00007bdc0b3d3742  push rcx
00007bdc0b3d3743  push rdx
00007bdc0b3d3744  push rdi
00007bdc0b3d3745  push rsi
00007bdc0b3d3746  push r8
00007bdc0b3d3748  push r9
00007bdc0b3d374a  push r10
00007bdc0b3d374c  push r11
00007bdc0b3d374e  sub rsp, 0xF0
00007bdc0b3d3755  vmovaps [rsp], xmm0
00007bdc0b3d375a  vmovaps [rsp+0x10], xmm1
00007bdc0b3d3760  vmovaps [rsp+0x20], xmm2
00007bdc0b3d3766  vmovaps [rsp+0x30], xmm3
00007bdc0b3d376c  vmovaps [rsp+0x40], xmm4
00007bdc0b3d3772  vmovaps [rsp+0x50], xmm5
00007bdc0b3d3778  vmovaps [rsp+0x60], xmm6
00007bdc0b3d377e  vmovaps [rsp+0x70], xmm7
00007bdc0b3d3784  vmovaps [rsp+0x80], xmm8
00007bdc0b3d378d  vmovaps [rsp+0x90], xmm9
00007bdc0b3d3796  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d379f  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d37a8  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d37b1  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d37ba  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d37c3  sub rsp, 0x40
00007bdc0b3d37c7  lea rdi, [rsp]
00007bdc0b3d37cb  lea rsi, [rsp+0x10]
00007bdc0b3d37d0  lea rdx, [rsp+0x20]
00007bdc0b3d37d5  lea rcx, [rsp+0x30]
00007bdc0b3d37da  mov r8d, 0x00
00007bdc0b3d37e0  lea r9, [r15+0x3A8]
00007bdc0b3d37e7  movaps [rdi], xmm13
00007bdc0b3d37eb  movaps [rsi], xmm1
00007bdc0b3d37ee  movaps [rdx], xmm15
00007bdc0b3d37f2  movaps [rcx], xmm14
00007bdc0b3d37f6  mov rax, 0x62CE440F2A50
00007bdc0b3d3800  call rax
00007bdc0b3d3802  movaps xmm13, [rsp]
00007bdc0b3d3807  add rsp, 0x40
00007bdc0b3d380b  vmovaps xmm0, [rsp]
00007bdc0b3d3810  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d3816  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d381c  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d3822  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d3828  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d382e  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d3834  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d383a  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d3843  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d384c  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d3855  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d385e  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d3867  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d3870  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d3879  add rsp, 0xF0
00007bdc0b3d3880  pop r11
00007bdc0b3d3882  pop r10
00007bdc0b3d3884  pop r9
00007bdc0b3d3886  pop r8
00007bdc0b3d3888  pop rsi
00007bdc0b3d3889  pop rdi
00007bdc0b3d388a  pop rdx
00007bdc0b3d388b  pop rcx
00007bdc0b3d388c  pop rax
00007bdc0b3d388d  add rsp, 0x08
00007bdc0b3d3891  jmp 0x00007BDC0B3D29C1
00007bdc0b3d3896  call 0x00007BDC0B1FF430
00007bdc0b3d389b  jmp 0x00007BDC0B3D29CE
00007bdc0b3d38a0  sub rsp, 0x08
00007bdc0b3d38a4  push rax
00007bdc0b3d38a5  push rcx
00007bdc0b3d38a6  push rdx
00007bdc0b3d38a7  push rdi
00007bdc0b3d38a8  push rsi
00007bdc0b3d38a9  push r8
00007bdc0b3d38ab  push r9
00007bdc0b3d38ad  push r10
00007bdc0b3d38af  push r11
00007bdc0b3d38b1  sub rsp, 0xF0
00007bdc0b3d38b8  vmovaps [rsp], xmm0
00007bdc0b3d38bd  vmovaps [rsp+0x10], xmm1
00007bdc0b3d38c3  vmovaps [rsp+0x20], xmm2
00007bdc0b3d38c9  vmovaps [rsp+0x30], xmm3
00007bdc0b3d38cf  vmovaps [rsp+0x40], xmm4
00007bdc0b3d38d5  vmovaps [rsp+0x50], xmm5
00007bdc0b3d38db  vmovaps [rsp+0x60], xmm6
00007bdc0b3d38e1  vmovaps [rsp+0x70], xmm7
00007bdc0b3d38e7  vmovaps [rsp+0x80], xmm8
00007bdc0b3d38f0  vmovaps [rsp+0x90], xmm9
00007bdc0b3d38f9  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d3902  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d390b  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d3914  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d391d  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d3926  sub rsp, 0x40
00007bdc0b3d392a  lea rdi, [rsp]
00007bdc0b3d392e  lea rsi, [rsp+0x10]
00007bdc0b3d3933  lea rdx, [rsp+0x20]
00007bdc0b3d3938  lea rcx, [rsp+0x30]
00007bdc0b3d393d  mov r8d, 0x00
00007bdc0b3d3943  lea r9, [r15+0x3A8]
00007bdc0b3d394a  movaps [rdi], xmm12
00007bdc0b3d394e  movaps [rsi], xmm15
00007bdc0b3d3952  movaps [rdx], xmm1
00007bdc0b3d3955  movaps [rcx], xmm14
00007bdc0b3d3959  mov rax, 0x62CE440F2A50
00007bdc0b3d3963  call rax
00007bdc0b3d3965  movaps xmm12, [rsp]
00007bdc0b3d396a  add rsp, 0x40
00007bdc0b3d396e  vmovaps xmm0, [rsp]
00007bdc0b3d3973  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d3979  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d397f  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d3985  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d398b  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d3991  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d3997  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d399d  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d39a6  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d39af  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d39b8  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d39c1  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d39ca  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d39d3  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d39dc  add rsp, 0xF0
00007bdc0b3d39e3  pop r11
00007bdc0b3d39e5  pop r10
00007bdc0b3d39e7  pop r9
00007bdc0b3d39e9  pop r8
00007bdc0b3d39eb  pop rsi
00007bdc0b3d39ec  pop rdi
00007bdc0b3d39ed  pop rdx
00007bdc0b3d39ee  pop rcx
00007bdc0b3d39ef  pop rax
00007bdc0b3d39f0  add rsp, 0x08
00007bdc0b3d39f4  jmp 0x00007BDC0B3D29FA
00007bdc0b3d39f9  sub rsp, 0x08
00007bdc0b3d39fd  push rax
00007bdc0b3d39fe  push rcx
00007bdc0b3d39ff  push rdx
00007bdc0b3d3a00  push rdi
00007bdc0b3d3a01  push rsi
00007bdc0b3d3a02  push r8
00007bdc0b3d3a04  push r9
00007bdc0b3d3a06  push r10
00007bdc0b3d3a08  push r11
00007bdc0b3d3a0a  sub rsp, 0xF0
00007bdc0b3d3a11  vmovaps [rsp], xmm0
00007bdc0b3d3a16  vmovaps [rsp+0x10], xmm1
00007bdc0b3d3a1c  vmovaps [rsp+0x20], xmm2
00007bdc0b3d3a22  vmovaps [rsp+0x30], xmm3
00007bdc0b3d3a28  vmovaps [rsp+0x40], xmm4
00007bdc0b3d3a2e  vmovaps [rsp+0x50], xmm5
00007bdc0b3d3a34  vmovaps [rsp+0x60], xmm6
00007bdc0b3d3a3a  vmovaps [rsp+0x70], xmm7
00007bdc0b3d3a40  vmovaps [rsp+0x80], xmm8
00007bdc0b3d3a49  vmovaps [rsp+0x90], xmm9
00007bdc0b3d3a52  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d3a5b  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d3a64  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d3a6d  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d3a76  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d3a7f  sub rsp, 0x40
00007bdc0b3d3a83  lea rdi, [rsp]
00007bdc0b3d3a87  lea rsi, [rsp+0x10]
00007bdc0b3d3a8c  lea rdx, [rsp+0x20]
00007bdc0b3d3a91  lea rcx, [rsp+0x30]
00007bdc0b3d3a96  mov r8d, 0x00
00007bdc0b3d3a9c  lea r9, [r15+0x3A8]
00007bdc0b3d3aa3  movaps [rdi], xmm13
00007bdc0b3d3aa7  movaps [rsi], xmm1
00007bdc0b3d3aaa  movaps [rdx], xmm15
00007bdc0b3d3aae  movaps [rcx], xmm14
00007bdc0b3d3ab2  mov rax, 0x62CE440F2A50
00007bdc0b3d3abc  call rax
00007bdc0b3d3abe  movaps xmm13, [rsp]
00007bdc0b3d3ac3  add rsp, 0x40
00007bdc0b3d3ac7  vmovaps xmm0, [rsp]
00007bdc0b3d3acc  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d3ad2  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d3ad8  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d3ade  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d3ae4  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d3aea  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d3af0  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d3af6  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d3aff  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d3b08  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d3b11  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d3b1a  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d3b23  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d3b2c  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d3b35  add rsp, 0xF0
00007bdc0b3d3b3c  pop r11
00007bdc0b3d3b3e  pop r10
00007bdc0b3d3b40  pop r9
00007bdc0b3d3b42  pop r8
00007bdc0b3d3b44  pop rsi
00007bdc0b3d3b45  pop rdi
00007bdc0b3d3b46  pop rdx
00007bdc0b3d3b47  pop rcx
00007bdc0b3d3b48  pop rax
00007bdc0b3d3b49  add rsp, 0x08
00007bdc0b3d3b4d  jmp 0x00007BDC0B3D2B77
00007bdc0b3d3b52  sub rsp, 0x08
00007bdc0b3d3b56  push rax
00007bdc0b3d3b57  push rcx
00007bdc0b3d3b58  push rdx
00007bdc0b3d3b59  push rdi
00007bdc0b3d3b5a  push rsi
00007bdc0b3d3b5b  push r8
00007bdc0b3d3b5d  push r9
00007bdc0b3d3b5f  push r10
00007bdc0b3d3b61  push r11
00007bdc0b3d3b63  sub rsp, 0xF0
00007bdc0b3d3b6a  vmovaps [rsp], xmm0
00007bdc0b3d3b6f  vmovaps [rsp+0x10], xmm1
00007bdc0b3d3b75  vmovaps [rsp+0x20], xmm2
00007bdc0b3d3b7b  vmovaps [rsp+0x30], xmm3
00007bdc0b3d3b81  vmovaps [rsp+0x40], xmm4
00007bdc0b3d3b87  vmovaps [rsp+0x50], xmm5
00007bdc0b3d3b8d  vmovaps [rsp+0x60], xmm6
00007bdc0b3d3b93  vmovaps [rsp+0x70], xmm7
00007bdc0b3d3b99  vmovaps [rsp+0x80], xmm8
00007bdc0b3d3ba2  vmovaps [rsp+0x90], xmm9
00007bdc0b3d3bab  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d3bb4  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d3bbd  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d3bc6  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d3bcf  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d3bd8  sub rsp, 0x40
00007bdc0b3d3bdc  lea rdi, [rsp]
00007bdc0b3d3be0  lea rsi, [rsp+0x10]
00007bdc0b3d3be5  lea rdx, [rsp+0x20]
00007bdc0b3d3bea  lea rcx, [rsp+0x30]
00007bdc0b3d3bef  mov r8d, 0x00
00007bdc0b3d3bf5  lea r9, [r15+0x3A8]
00007bdc0b3d3bfc  movaps [rdi], xmm12
00007bdc0b3d3c00  movaps [rsi], xmm15
00007bdc0b3d3c04  movaps [rdx], xmm14
00007bdc0b3d3c08  movaps [rcx], xmm1
00007bdc0b3d3c0b  mov rax, 0x62CE440F2A50
00007bdc0b3d3c15  call rax
00007bdc0b3d3c17  movaps xmm12, [rsp]
00007bdc0b3d3c1c  add rsp, 0x40
00007bdc0b3d3c20  vmovaps xmm0, [rsp]
00007bdc0b3d3c25  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d3c2b  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d3c31  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d3c37  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d3c3d  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d3c43  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d3c49  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d3c4f  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d3c58  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d3c61  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d3c6a  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d3c73  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d3c7c  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d3c85  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d3c8e  add rsp, 0xF0
00007bdc0b3d3c95  pop r11
00007bdc0b3d3c97  pop r10
00007bdc0b3d3c99  pop r9
00007bdc0b3d3c9b  pop r8
00007bdc0b3d3c9d  pop rsi
00007bdc0b3d3c9e  pop rdi
00007bdc0b3d3c9f  pop rdx
00007bdc0b3d3ca0  pop rcx
00007bdc0b3d3ca1  pop rax
00007bdc0b3d3ca2  add rsp, 0x08
00007bdc0b3d3ca6  jmp 0x00007BDC0B3D2BB2
00007bdc0b3d3cab  sub rsp, 0x08
00007bdc0b3d3caf  push rax
00007bdc0b3d3cb0  push rcx
00007bdc0b3d3cb1  push rdx
00007bdc0b3d3cb2  push rdi
00007bdc0b3d3cb3  push rsi
00007bdc0b3d3cb4  push r8
00007bdc0b3d3cb6  push r9
00007bdc0b3d3cb8  push r10
00007bdc0b3d3cba  push r11
00007bdc0b3d3cbc  sub rsp, 0xF0
00007bdc0b3d3cc3  vmovaps [rsp], xmm0
00007bdc0b3d3cc8  vmovaps [rsp+0x10], xmm1
00007bdc0b3d3cce  vmovaps [rsp+0x20], xmm2
00007bdc0b3d3cd4  vmovaps [rsp+0x30], xmm3
00007bdc0b3d3cda  vmovaps [rsp+0x40], xmm4
00007bdc0b3d3ce0  vmovaps [rsp+0x50], xmm5
00007bdc0b3d3ce6  vmovaps [rsp+0x60], xmm6
00007bdc0b3d3cec  vmovaps [rsp+0x70], xmm7
00007bdc0b3d3cf2  vmovaps [rsp+0x80], xmm8
00007bdc0b3d3cfb  vmovaps [rsp+0x90], xmm9
00007bdc0b3d3d04  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d3d0d  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d3d16  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d3d1f  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d3d28  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d3d31  sub rsp, 0x40
00007bdc0b3d3d35  lea rdi, [rsp]
00007bdc0b3d3d39  lea rsi, [rsp+0x10]
00007bdc0b3d3d3e  lea rdx, [rsp+0x20]
00007bdc0b3d3d43  lea rcx, [rsp+0x30]
00007bdc0b3d3d48  mov r8d, 0x00
00007bdc0b3d3d4e  lea r9, [r15+0x3A8]
00007bdc0b3d3d55  movaps [rdi], xmm13
00007bdc0b3d3d59  movaps [rsi], xmm15
00007bdc0b3d3d5d  movaps [rdx], xmm14
00007bdc0b3d3d61  movaps [rcx], xmm1
00007bdc0b3d3d64  mov rax, 0x62CE440F2A50
00007bdc0b3d3d6e  call rax
00007bdc0b3d3d70  movaps xmm13, [rsp]
00007bdc0b3d3d75  add rsp, 0x40
00007bdc0b3d3d79  vmovaps xmm0, [rsp]
00007bdc0b3d3d7e  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d3d84  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d3d8a  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d3d90  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d3d96  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d3d9c  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d3da2  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d3da8  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d3db1  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d3dba  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d3dc3  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d3dcc  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d3dd5  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d3dde  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d3de7  add rsp, 0xF0
00007bdc0b3d3dee  pop r11
00007bdc0b3d3df0  pop r10
00007bdc0b3d3df2  pop r9
00007bdc0b3d3df4  pop r8
00007bdc0b3d3df6  pop rsi
00007bdc0b3d3df7  pop rdi
00007bdc0b3d3df8  pop rdx
00007bdc0b3d3df9  pop rcx
00007bdc0b3d3dfa  pop rax
00007bdc0b3d3dfb  add rsp, 0x08
00007bdc0b3d3dff  jmp 0x00007BDC0B3D2BEA
00007bdc0b3d3e04  sub rsp, 0x08
00007bdc0b3d3e08  push rax
00007bdc0b3d3e09  push rcx
00007bdc0b3d3e0a  push rdx
00007bdc0b3d3e0b  push rdi
00007bdc0b3d3e0c  push rsi
00007bdc0b3d3e0d  push r8
00007bdc0b3d3e0f  push r9
00007bdc0b3d3e11  push r10
00007bdc0b3d3e13  push r11
00007bdc0b3d3e15  sub rsp, 0xF0
00007bdc0b3d3e1c  vmovaps [rsp], xmm0
00007bdc0b3d3e21  vmovaps [rsp+0x10], xmm1
00007bdc0b3d3e27  vmovaps [rsp+0x20], xmm2
00007bdc0b3d3e2d  vmovaps [rsp+0x30], xmm3
00007bdc0b3d3e33  vmovaps [rsp+0x40], xmm4
00007bdc0b3d3e39  vmovaps [rsp+0x50], xmm5
00007bdc0b3d3e3f  vmovaps [rsp+0x60], xmm6
00007bdc0b3d3e45  vmovaps [rsp+0x70], xmm7
00007bdc0b3d3e4b  vmovaps [rsp+0x80], xmm8
00007bdc0b3d3e54  vmovaps [rsp+0x90], xmm9
00007bdc0b3d3e5d  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d3e66  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d3e6f  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d3e78  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d3e81  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d3e8a  sub rsp, 0x40
00007bdc0b3d3e8e  lea rdi, [rsp]
00007bdc0b3d3e92  lea rsi, [rsp+0x10]
00007bdc0b3d3e97  lea rdx, [rsp+0x20]
00007bdc0b3d3e9c  lea rcx, [rsp+0x30]
00007bdc0b3d3ea1  mov r8d, 0x00
00007bdc0b3d3ea7  lea r9, [r15+0x3A8]
00007bdc0b3d3eae  movaps [rdi], xmm12
00007bdc0b3d3eb2  movaps [rsi], xmm15
00007bdc0b3d3eb6  movaps [rdx], xmm14
00007bdc0b3d3eba  movaps [rcx], xmm1
00007bdc0b3d3ebd  mov rax, 0x62CE440F2A50
00007bdc0b3d3ec7  call rax
00007bdc0b3d3ec9  movaps xmm12, [rsp]
00007bdc0b3d3ece  add rsp, 0x40
00007bdc0b3d3ed2  vmovaps xmm0, [rsp]
00007bdc0b3d3ed7  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d3edd  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d3ee3  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d3ee9  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d3eef  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d3ef5  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d3efb  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d3f01  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d3f0a  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d3f13  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d3f1c  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d3f25  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d3f2e  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d3f37  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d3f40  add rsp, 0xF0
00007bdc0b3d3f47  pop r11
00007bdc0b3d3f49  pop r10
00007bdc0b3d3f4b  pop r9
00007bdc0b3d3f4d  pop r8
00007bdc0b3d3f4f  pop rsi
00007bdc0b3d3f50  pop rdi
00007bdc0b3d3f51  pop rdx
00007bdc0b3d3f52  pop rcx
00007bdc0b3d3f53  pop rax
00007bdc0b3d3f54  add rsp, 0x08
00007bdc0b3d3f58  jmp 0x00007BDC0B3D2C3D
00007bdc0b3d3f5d  sub rsp, 0x08
00007bdc0b3d3f61  push rax
00007bdc0b3d3f62  push rcx
00007bdc0b3d3f63  push rdx
00007bdc0b3d3f64  push rdi
00007bdc0b3d3f65  push rsi
00007bdc0b3d3f66  push r8
00007bdc0b3d3f68  push r9
00007bdc0b3d3f6a  push r10
00007bdc0b3d3f6c  push r11
00007bdc0b3d3f6e  sub rsp, 0xF0
00007bdc0b3d3f75  vmovaps [rsp], xmm0
00007bdc0b3d3f7a  vmovaps [rsp+0x10], xmm1
00007bdc0b3d3f80  vmovaps [rsp+0x20], xmm2
00007bdc0b3d3f86  vmovaps [rsp+0x30], xmm3
00007bdc0b3d3f8c  vmovaps [rsp+0x40], xmm4
00007bdc0b3d3f92  vmovaps [rsp+0x50], xmm5
00007bdc0b3d3f98  vmovaps [rsp+0x60], xmm6
00007bdc0b3d3f9e  vmovaps [rsp+0x70], xmm7
00007bdc0b3d3fa4  vmovaps [rsp+0x80], xmm8
00007bdc0b3d3fad  vmovaps [rsp+0x90], xmm9
00007bdc0b3d3fb6  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d3fbf  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d3fc8  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d3fd1  vmovaps [rsp+0xD0], xmm13
00007bdc0b3d3fda  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d3fe3  sub rsp, 0x40
00007bdc0b3d3fe7  lea rdi, [rsp]
00007bdc0b3d3feb  lea rsi, [rsp+0x10]
00007bdc0b3d3ff0  lea rdx, [rsp+0x20]
00007bdc0b3d3ff5  lea rcx, [rsp+0x30]
00007bdc0b3d3ffa  mov r8d, 0x00
00007bdc0b3d4000  lea r9, [r15+0x3A8]
00007bdc0b3d4007  movaps [rdi], xmm14
00007bdc0b3d400b  movaps [rsi], xmm3
00007bdc0b3d400e  movaps [rdx], xmm1
00007bdc0b3d4011  movaps [rcx], xmm15
00007bdc0b3d4015  mov rax, 0x62CE440F2A50
00007bdc0b3d401f  call rax
00007bdc0b3d4021  movaps xmm14, [rsp]
00007bdc0b3d4026  add rsp, 0x40
00007bdc0b3d402a  vmovaps xmm0, [rsp]
00007bdc0b3d402f  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d4035  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d403b  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d4041  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d4047  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d404d  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d4053  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d4059  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d4062  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d406b  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d4074  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d407d  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d4086  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3d408f  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d4098  add rsp, 0xF0
00007bdc0b3d409f  pop r11
00007bdc0b3d40a1  pop r10
00007bdc0b3d40a3  pop r9
00007bdc0b3d40a5  pop r8
00007bdc0b3d40a7  pop rsi
00007bdc0b3d40a8  pop rdi
00007bdc0b3d40a9  pop rdx
00007bdc0b3d40aa  pop rcx
00007bdc0b3d40ab  pop rax
00007bdc0b3d40ac  add rsp, 0x08
00007bdc0b3d40b0  jmp 0x00007BDC0B3D2CF7
00007bdc0b3d40b5  sub rsp, 0x08
00007bdc0b3d40b9  push rax
00007bdc0b3d40ba  push rcx
00007bdc0b3d40bb  push rdx
00007bdc0b3d40bc  push rdi
00007bdc0b3d40bd  push rsi
00007bdc0b3d40be  push r8
00007bdc0b3d40c0  push r9
00007bdc0b3d40c2  push r10
00007bdc0b3d40c4  push r11
00007bdc0b3d40c6  sub rsp, 0xF0
00007bdc0b3d40cd  vmovaps [rsp], xmm0
00007bdc0b3d40d2  vmovaps [rsp+0x10], xmm1
00007bdc0b3d40d8  vmovaps [rsp+0x20], xmm2
00007bdc0b3d40de  vmovaps [rsp+0x30], xmm3
00007bdc0b3d40e4  vmovaps [rsp+0x40], xmm4
00007bdc0b3d40ea  vmovaps [rsp+0x50], xmm5
00007bdc0b3d40f0  vmovaps [rsp+0x60], xmm6
00007bdc0b3d40f6  vmovaps [rsp+0x70], xmm7
00007bdc0b3d40fc  vmovaps [rsp+0x80], xmm8
00007bdc0b3d4105  vmovaps [rsp+0x90], xmm9
00007bdc0b3d410e  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d4117  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d4120  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d4129  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d4132  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d413b  sub rsp, 0x40
00007bdc0b3d413f  lea rdi, [rsp]
00007bdc0b3d4143  lea rsi, [rsp+0x10]
00007bdc0b3d4148  lea rdx, [rsp+0x20]
00007bdc0b3d414d  lea rcx, [rsp+0x30]
00007bdc0b3d4152  mov r8d, 0x00
00007bdc0b3d4158  lea r9, [r15+0x3A8]
00007bdc0b3d415f  movaps [rdi], xmm13
00007bdc0b3d4163  movaps [rsi], xmm15
00007bdc0b3d4167  movaps [rdx], xmm10
00007bdc0b3d416b  movaps [rcx], xmm1
00007bdc0b3d416e  mov rax, 0x62CE440F2A50
00007bdc0b3d4178  call rax
00007bdc0b3d417a  movaps xmm13, [rsp]
00007bdc0b3d417f  add rsp, 0x40
00007bdc0b3d4183  vmovaps xmm0, [rsp]
00007bdc0b3d4188  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d418e  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d4194  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d419a  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d41a0  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d41a6  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d41ac  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d41b2  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d41bb  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d41c4  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d41cd  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d41d6  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d41df  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d41e8  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d41f1  add rsp, 0xF0
00007bdc0b3d41f8  pop r11
00007bdc0b3d41fa  pop r10
00007bdc0b3d41fc  pop r9
00007bdc0b3d41fe  pop r8
00007bdc0b3d4200  pop rsi
00007bdc0b3d4201  pop rdi
00007bdc0b3d4202  pop rdx
00007bdc0b3d4203  pop rcx
00007bdc0b3d4204  pop rax
00007bdc0b3d4205  add rsp, 0x08
00007bdc0b3d4209  jmp 0x00007BDC0B3D2D26
00007bdc0b3d420e  sub rsp, 0x08
00007bdc0b3d4212  push rax
00007bdc0b3d4213  push rcx
00007bdc0b3d4214  push rdx
00007bdc0b3d4215  push rdi
00007bdc0b3d4216  push rsi
00007bdc0b3d4217  push r8
00007bdc0b3d4219  push r9
00007bdc0b3d421b  push r10
00007bdc0b3d421d  push r11
00007bdc0b3d421f  sub rsp, 0xF0
00007bdc0b3d4226  vmovaps [rsp], xmm0
00007bdc0b3d422b  vmovaps [rsp+0x10], xmm1
00007bdc0b3d4231  vmovaps [rsp+0x20], xmm2
00007bdc0b3d4237  vmovaps [rsp+0x30], xmm3
00007bdc0b3d423d  vmovaps [rsp+0x40], xmm4
00007bdc0b3d4243  vmovaps [rsp+0x50], xmm5
00007bdc0b3d4249  vmovaps [rsp+0x60], xmm6
00007bdc0b3d424f  vmovaps [rsp+0x70], xmm7
00007bdc0b3d4255  vmovaps [rsp+0x80], xmm8
00007bdc0b3d425e  vmovaps [rsp+0x90], xmm9
00007bdc0b3d4267  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d4270  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d4279  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d4282  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d428b  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d4294  sub rsp, 0x40
00007bdc0b3d4298  lea rdi, [rsp]
00007bdc0b3d429c  lea rsi, [rsp+0x10]
00007bdc0b3d42a1  lea rdx, [rsp+0x20]
00007bdc0b3d42a6  lea rcx, [rsp+0x30]
00007bdc0b3d42ab  mov r8d, 0x00
00007bdc0b3d42b1  lea r9, [r15+0x3A8]
00007bdc0b3d42b8  movaps [rdi], xmm10
00007bdc0b3d42bc  movaps [rsi], xmm15
00007bdc0b3d42c0  movaps [rdx], xmm11
00007bdc0b3d42c4  movaps [rcx], xmm1
00007bdc0b3d42c7  mov rax, 0x62CE440F2A50
00007bdc0b3d42d1  call rax
00007bdc0b3d42d3  movaps xmm10, [rsp]
00007bdc0b3d42d8  add rsp, 0x40
00007bdc0b3d42dc  vmovaps xmm0, [rsp]
00007bdc0b3d42e1  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d42e7  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d42ed  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d42f3  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d42f9  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d42ff  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d4305  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d430b  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d4314  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d431d  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d4326  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d432f  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d4338  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d4341  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d434a  add rsp, 0xF0
00007bdc0b3d4351  pop r11
00007bdc0b3d4353  pop r10
00007bdc0b3d4355  pop r9
00007bdc0b3d4357  pop r8
00007bdc0b3d4359  pop rsi
00007bdc0b3d435a  pop rdi
00007bdc0b3d435b  pop rdx
00007bdc0b3d435c  pop rcx
00007bdc0b3d435d  pop rax
00007bdc0b3d435e  add rsp, 0x08
00007bdc0b3d4362  jmp 0x00007BDC0B3D2D55
00007bdc0b3d4367  sub rsp, 0x08
00007bdc0b3d436b  push rax
00007bdc0b3d436c  push rcx
00007bdc0b3d436d  push rdx
00007bdc0b3d436e  push rdi
00007bdc0b3d436f  push rsi
00007bdc0b3d4370  push r8
00007bdc0b3d4372  push r9
00007bdc0b3d4374  push r10
00007bdc0b3d4376  push r11
00007bdc0b3d4378  sub rsp, 0xF0
00007bdc0b3d437f  vmovaps [rsp], xmm0
00007bdc0b3d4384  vmovaps [rsp+0x10], xmm1
00007bdc0b3d438a  vmovaps [rsp+0x20], xmm2
00007bdc0b3d4390  vmovaps [rsp+0x30], xmm3
00007bdc0b3d4396  vmovaps [rsp+0x40], xmm4
00007bdc0b3d439c  vmovaps [rsp+0x50], xmm5
00007bdc0b3d43a2  vmovaps [rsp+0x60], xmm6
00007bdc0b3d43a8  vmovaps [rsp+0x70], xmm7
00007bdc0b3d43ae  vmovaps [rsp+0x80], xmm8
00007bdc0b3d43b7  vmovaps [rsp+0x90], xmm9
00007bdc0b3d43c0  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d43c9  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d43d2  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d43db  vmovaps [rsp+0xD0], xmm13
00007bdc0b3d43e4  vmovaps [rsp+0xE0], xmm14
00007bdc0b3d43ed  sub rsp, 0x40
00007bdc0b3d43f1  lea rdi, [rsp]
00007bdc0b3d43f5  lea rsi, [rsp+0x10]
00007bdc0b3d43fa  lea rdx, [rsp+0x20]
00007bdc0b3d43ff  lea rcx, [rsp+0x30]
00007bdc0b3d4404  mov r8d, 0x00
00007bdc0b3d440a  lea r9, [r15+0x3A8]
00007bdc0b3d4411  movaps [rdi], xmm15
00007bdc0b3d4415  movaps [rsi], xmm12
00007bdc0b3d4419  movaps [rdx], xmm5
00007bdc0b3d441c  movaps [rcx], xmm1
00007bdc0b3d441f  mov rax, 0x62CE440F2A50
00007bdc0b3d4429  call rax
00007bdc0b3d442b  movaps xmm15, [rsp]
00007bdc0b3d4430  add rsp, 0x40
00007bdc0b3d4434  vmovaps xmm0, [rsp]
00007bdc0b3d4439  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d443f  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d4445  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d444b  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d4451  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d4457  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d445d  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d4463  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d446c  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d4475  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d447e  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d4487  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d4490  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3d4499  vmovaps xmm14, [rsp+0xE0]
00007bdc0b3d44a2  add rsp, 0xF0
00007bdc0b3d44a9  pop r11
00007bdc0b3d44ab  pop r10
00007bdc0b3d44ad  pop r9
00007bdc0b3d44af  pop r8
00007bdc0b3d44b1  pop rsi
00007bdc0b3d44b2  pop rdi
00007bdc0b3d44b3  pop rdx
00007bdc0b3d44b4  pop rcx
00007bdc0b3d44b5  pop rax
00007bdc0b3d44b6  add rsp, 0x08
00007bdc0b3d44ba  jmp 0x00007BDC0B3D2D7E
00007bdc0b3d44bf  sub rsp, 0x08
00007bdc0b3d44c3  push rax
00007bdc0b3d44c4  push rcx
00007bdc0b3d44c5  push rdx
00007bdc0b3d44c6  push rdi
00007bdc0b3d44c7  push rsi
00007bdc0b3d44c8  push r8
00007bdc0b3d44ca  push r9
00007bdc0b3d44cc  push r10
00007bdc0b3d44ce  push r11
00007bdc0b3d44d0  sub rsp, 0xF0
00007bdc0b3d44d7  vmovaps [rsp], xmm0
00007bdc0b3d44dc  vmovaps [rsp+0x10], xmm1
00007bdc0b3d44e2  vmovaps [rsp+0x20], xmm2
00007bdc0b3d44e8  vmovaps [rsp+0x30], xmm3
00007bdc0b3d44ee  vmovaps [rsp+0x40], xmm4
00007bdc0b3d44f4  vmovaps [rsp+0x50], xmm6
00007bdc0b3d44fa  vmovaps [rsp+0x60], xmm7
00007bdc0b3d4500  vmovaps [rsp+0x70], xmm8
00007bdc0b3d4506  vmovaps [rsp+0x80], xmm9
00007bdc0b3d450f  vmovaps [rsp+0x90], xmm10
00007bdc0b3d4518  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d4521  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d452a  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d4533  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d453c  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d4545  sub rsp, 0x40
00007bdc0b3d4549  lea rdi, [rsp]
00007bdc0b3d454d  lea rsi, [rsp+0x10]
00007bdc0b3d4552  lea rdx, [rsp+0x20]
00007bdc0b3d4557  lea rcx, [rsp+0x30]
00007bdc0b3d455c  mov r8d, 0x00
00007bdc0b3d4562  lea r9, [r15+0x3A8]
00007bdc0b3d4569  movaps [rdi], xmm5
00007bdc0b3d456c  movaps [rsi], xmm13
00007bdc0b3d4570  movaps [rdx], xmm11
00007bdc0b3d4574  movaps [rcx], xmm12
00007bdc0b3d4578  mov rax, 0x62CE440F2A50
00007bdc0b3d4582  call rax
00007bdc0b3d4584  movaps xmm5, [rsp]
00007bdc0b3d4588  add rsp, 0x40
00007bdc0b3d458c  vmovaps xmm0, [rsp]
00007bdc0b3d4591  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d4597  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d459d  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d45a3  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d45a9  vmovaps xmm6, [rsp+0x50]
00007bdc0b3d45af  vmovaps xmm7, [rsp+0x60]
00007bdc0b3d45b5  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d45bb  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d45c4  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d45cd  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d45d6  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d45df  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d45e8  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d45f1  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d45fa  add rsp, 0xF0
00007bdc0b3d4601  pop r11
00007bdc0b3d4603  pop r10
00007bdc0b3d4605  pop r9
00007bdc0b3d4607  pop r8
00007bdc0b3d4609  pop rsi
00007bdc0b3d460a  pop rdi
00007bdc0b3d460b  pop rdx
00007bdc0b3d460c  pop rcx
00007bdc0b3d460d  pop rax
00007bdc0b3d460e  add rsp, 0x08
00007bdc0b3d4612  jmp 0x00007BDC0B3D2DDD
00007bdc0b3d4617  sub rsp, 0x08
00007bdc0b3d461b  push rax
00007bdc0b3d461c  push rcx
00007bdc0b3d461d  push rdx
00007bdc0b3d461e  push rdi
00007bdc0b3d461f  push rsi
00007bdc0b3d4620  push r8
00007bdc0b3d4622  push r9
00007bdc0b3d4624  push r10
00007bdc0b3d4626  push r11
00007bdc0b3d4628  sub rsp, 0xF0
00007bdc0b3d462f  vmovaps [rsp], xmm0
00007bdc0b3d4634  vmovaps [rsp+0x10], xmm1
00007bdc0b3d463a  vmovaps [rsp+0x20], xmm2
00007bdc0b3d4640  vmovaps [rsp+0x30], xmm3
00007bdc0b3d4646  vmovaps [rsp+0x40], xmm4
00007bdc0b3d464c  vmovaps [rsp+0x50], xmm5
00007bdc0b3d4652  vmovaps [rsp+0x60], xmm6
00007bdc0b3d4658  vmovaps [rsp+0x70], xmm7
00007bdc0b3d465e  vmovaps [rsp+0x80], xmm8
00007bdc0b3d4667  vmovaps [rsp+0x90], xmm9
00007bdc0b3d4670  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d4679  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d4682  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d468b  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d4694  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d469d  sub rsp, 0x40
00007bdc0b3d46a1  lea rdi, [rsp]
00007bdc0b3d46a5  lea rsi, [rsp+0x10]
00007bdc0b3d46aa  lea rdx, [rsp+0x20]
00007bdc0b3d46af  lea rcx, [rsp+0x30]
00007bdc0b3d46b4  mov r8d, 0x00
00007bdc0b3d46ba  lea r9, [r15+0x3A8]
00007bdc0b3d46c1  movaps [rdi], xmm12
00007bdc0b3d46c5  movaps [rsi], xmm14
00007bdc0b3d46c9  movaps [rdx], xmm9
00007bdc0b3d46cd  movaps [rcx], xmm13
00007bdc0b3d46d1  mov rax, 0x62CE440F2A50
00007bdc0b3d46db  call rax
00007bdc0b3d46dd  movaps xmm12, [rsp]
00007bdc0b3d46e2  add rsp, 0x40
00007bdc0b3d46e6  vmovaps xmm0, [rsp]
00007bdc0b3d46eb  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d46f1  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d46f7  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d46fd  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d4703  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d4709  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d470f  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d4715  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d471e  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d4727  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d4730  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d4739  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d4742  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d474b  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d4754  add rsp, 0xF0
00007bdc0b3d475b  pop r11
00007bdc0b3d475d  pop r10
00007bdc0b3d475f  pop r9
00007bdc0b3d4761  pop r8
00007bdc0b3d4763  pop rsi
00007bdc0b3d4764  pop rdi
00007bdc0b3d4765  pop rdx
00007bdc0b3d4766  pop rcx
00007bdc0b3d4767  pop rax
00007bdc0b3d4768  add rsp, 0x08
00007bdc0b3d476c  jmp 0x00007BDC0B3D2E06
00007bdc0b3d4771  call 0x00007BDC0B20D4E0
00007bdc0b3d4776  jmp 0x00007BDC0B3D2E13
00007bdc0b3d477b  sub rsp, 0x08
00007bdc0b3d477f  push rax
00007bdc0b3d4780  push rcx
00007bdc0b3d4781  push rdx
00007bdc0b3d4782  push rdi
00007bdc0b3d4783  push rsi
00007bdc0b3d4784  push r8
00007bdc0b3d4786  push r9
00007bdc0b3d4788  push r10
00007bdc0b3d478a  push r11
00007bdc0b3d478c  sub rsp, 0xF0
00007bdc0b3d4793  vmovaps [rsp], xmm0
00007bdc0b3d4798  vmovaps [rsp+0x10], xmm1
00007bdc0b3d479e  vmovaps [rsp+0x20], xmm2
00007bdc0b3d47a4  vmovaps [rsp+0x30], xmm3
00007bdc0b3d47aa  vmovaps [rsp+0x40], xmm4
00007bdc0b3d47b0  vmovaps [rsp+0x50], xmm5
00007bdc0b3d47b6  vmovaps [rsp+0x60], xmm6
00007bdc0b3d47bc  vmovaps [rsp+0x70], xmm7
00007bdc0b3d47c2  vmovaps [rsp+0x80], xmm8
00007bdc0b3d47cb  vmovaps [rsp+0x90], xmm9
00007bdc0b3d47d4  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d47dd  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d47e6  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d47ef  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d47f8  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d4801  sub rsp, 0x40
00007bdc0b3d4805  lea rdi, [rsp]
00007bdc0b3d4809  lea rsi, [rsp+0x10]
00007bdc0b3d480e  lea rdx, [rsp+0x20]
00007bdc0b3d4813  lea rcx, [rsp+0x30]
00007bdc0b3d4818  mov r8d, 0x00
00007bdc0b3d481e  lea r9, [r15+0x3A8]
00007bdc0b3d4825  movaps [rdi], xmm11
00007bdc0b3d4829  movaps [rsi], xmm10
00007bdc0b3d482d  movaps [rdx], xmm8
00007bdc0b3d4831  movaps [rcx], xmm13
00007bdc0b3d4835  mov rax, 0x62CE440F2A50
00007bdc0b3d483f  call rax
00007bdc0b3d4841  movaps xmm11, [rsp]
00007bdc0b3d4846  add rsp, 0x40
00007bdc0b3d484a  vmovaps xmm0, [rsp]
00007bdc0b3d484f  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d4855  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d485b  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d4861  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d4867  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d486d  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d4873  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d4879  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d4882  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d488b  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d4894  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d489d  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d48a6  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d48af  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d48b8  add rsp, 0xF0
00007bdc0b3d48bf  pop r11
00007bdc0b3d48c1  pop r10
00007bdc0b3d48c3  pop r9
00007bdc0b3d48c5  pop r8
00007bdc0b3d48c7  pop rsi
00007bdc0b3d48c8  pop rdi
00007bdc0b3d48c9  pop rdx
00007bdc0b3d48ca  pop rcx
00007bdc0b3d48cb  pop rax
00007bdc0b3d48cc  add rsp, 0x08
00007bdc0b3d48d0  jmp 0x00007BDC0B3D2E44
00007bdc0b3d48d5  sub rsp, 0x08
00007bdc0b3d48d9  push rax
00007bdc0b3d48da  push rcx
00007bdc0b3d48db  push rdx
00007bdc0b3d48dc  push rdi
00007bdc0b3d48dd  push rsi
00007bdc0b3d48de  push r8
00007bdc0b3d48e0  push r9
00007bdc0b3d48e2  push r10
00007bdc0b3d48e4  push r11
00007bdc0b3d48e6  sub rsp, 0xF0
00007bdc0b3d48ed  vmovaps [rsp], xmm0
00007bdc0b3d48f2  vmovaps [rsp+0x10], xmm1
00007bdc0b3d48f8  vmovaps [rsp+0x20], xmm2
00007bdc0b3d48fe  vmovaps [rsp+0x30], xmm3
00007bdc0b3d4904  vmovaps [rsp+0x40], xmm4
00007bdc0b3d490a  vmovaps [rsp+0x50], xmm5
00007bdc0b3d4910  vmovaps [rsp+0x60], xmm6
00007bdc0b3d4916  vmovaps [rsp+0x70], xmm7
00007bdc0b3d491c  vmovaps [rsp+0x80], xmm8
00007bdc0b3d4925  vmovaps [rsp+0x90], xmm9
00007bdc0b3d492e  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d4937  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d4940  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d4949  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d4952  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d495b  sub rsp, 0x40
00007bdc0b3d495f  lea rdi, [rsp]
00007bdc0b3d4963  lea rsi, [rsp+0x10]
00007bdc0b3d4968  lea rdx, [rsp+0x20]
00007bdc0b3d496d  lea rcx, [rsp+0x30]
00007bdc0b3d4972  mov r8d, 0x00
00007bdc0b3d4978  lea r9, [r15+0x3A8]
00007bdc0b3d497f  movaps [rdi], xmm10
00007bdc0b3d4983  movaps [rsi], xmm15
00007bdc0b3d4987  movaps [rdx], xmm1
00007bdc0b3d498a  movaps [rcx], xmm13
00007bdc0b3d498e  mov rax, 0x62CE440F2A50
00007bdc0b3d4998  call rax
00007bdc0b3d499a  movaps xmm10, [rsp]
00007bdc0b3d499f  add rsp, 0x40
00007bdc0b3d49a3  vmovaps xmm0, [rsp]
00007bdc0b3d49a8  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d49ae  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d49b4  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d49ba  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d49c0  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d49c6  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d49cc  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d49d2  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d49db  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d49e4  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d49ed  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d49f6  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d49ff  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d4a08  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d4a11  add rsp, 0xF0
00007bdc0b3d4a18  pop r11
00007bdc0b3d4a1a  pop r10
00007bdc0b3d4a1c  pop r9
00007bdc0b3d4a1e  pop r8
00007bdc0b3d4a20  pop rsi
00007bdc0b3d4a21  pop rdi
00007bdc0b3d4a22  pop rdx
00007bdc0b3d4a23  pop rcx
00007bdc0b3d4a24  pop rax
00007bdc0b3d4a25  add rsp, 0x08
00007bdc0b3d4a29  jmp 0x00007BDC0B3D2E6D
00007bdc0b3d4a2e  call 0x00007BDC0B1FF430
00007bdc0b3d4a33  jmp 0x00007BDC0B3D2E8F
00007bdc0b3d4a38  call 0x00007BDC0B20E760
00007bdc0b3d4a3d  jmp 0x00007BDC0B3D2E99
00007bdc0b3d4a42  sub rsp, 0x08
00007bdc0b3d4a46  push rax
00007bdc0b3d4a47  push rcx
00007bdc0b3d4a48  push rdx
00007bdc0b3d4a49  push rdi
00007bdc0b3d4a4a  push rsi
00007bdc0b3d4a4b  push r8
00007bdc0b3d4a4d  push r9
00007bdc0b3d4a4f  push r10
00007bdc0b3d4a51  push r11
00007bdc0b3d4a53  sub rsp, 0xF0
00007bdc0b3d4a5a  vmovaps [rsp], xmm0
00007bdc0b3d4a5f  vmovaps [rsp+0x10], xmm1
00007bdc0b3d4a65  vmovaps [rsp+0x20], xmm2
00007bdc0b3d4a6b  vmovaps [rsp+0x30], xmm3
00007bdc0b3d4a71  vmovaps [rsp+0x40], xmm4
00007bdc0b3d4a77  vmovaps [rsp+0x50], xmm5
00007bdc0b3d4a7d  vmovaps [rsp+0x60], xmm6
00007bdc0b3d4a83  vmovaps [rsp+0x70], xmm7
00007bdc0b3d4a89  vmovaps [rsp+0x80], xmm9
00007bdc0b3d4a92  vmovaps [rsp+0x90], xmm10
00007bdc0b3d4a9b  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d4aa4  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d4aad  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d4ab6  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d4abf  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d4ac8  sub rsp, 0x40
00007bdc0b3d4acc  lea rdi, [rsp]
00007bdc0b3d4ad0  lea rsi, [rsp+0x10]
00007bdc0b3d4ad5  lea rdx, [rsp+0x20]
00007bdc0b3d4ada  lea rcx, [rsp+0x30]
00007bdc0b3d4adf  mov r8d, 0x00
00007bdc0b3d4ae5  lea r9, [r15+0x3A8]
00007bdc0b3d4aec  movaps [rdi], xmm8
00007bdc0b3d4af0  movaps [rsi], xmm5
00007bdc0b3d4af3  movaps [rdx], xmm9
00007bdc0b3d4af7  movaps [rcx], xmm13
00007bdc0b3d4afb  mov rax, 0x62CE440F2A50
00007bdc0b3d4b05  call rax
00007bdc0b3d4b07  movaps xmm8, [rsp]
00007bdc0b3d4b0c  add rsp, 0x40
00007bdc0b3d4b10  vmovaps xmm0, [rsp]
00007bdc0b3d4b15  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d4b1b  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d4b21  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d4b27  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d4b2d  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d4b33  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d4b39  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d4b3f  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d4b48  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d4b51  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d4b5a  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d4b63  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d4b6c  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d4b75  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d4b7e  add rsp, 0xF0
00007bdc0b3d4b85  pop r11
00007bdc0b3d4b87  pop r10
00007bdc0b3d4b89  pop r9
00007bdc0b3d4b8b  pop r8
00007bdc0b3d4b8d  pop rsi
00007bdc0b3d4b8e  pop rdi
00007bdc0b3d4b8f  pop rdx
00007bdc0b3d4b90  pop rcx
00007bdc0b3d4b91  pop rax
00007bdc0b3d4b92  add rsp, 0x08
00007bdc0b3d4b96  jmp 0x00007BDC0B3D2ED8
00007bdc0b3d4b9b  sub rsp, 0x08
00007bdc0b3d4b9f  push rax
00007bdc0b3d4ba0  push rcx
00007bdc0b3d4ba1  push rdx
00007bdc0b3d4ba2  push rdi
00007bdc0b3d4ba3  push rsi
00007bdc0b3d4ba4  push r8
00007bdc0b3d4ba6  push r9
00007bdc0b3d4ba8  push r10
00007bdc0b3d4baa  push r11
00007bdc0b3d4bac  sub rsp, 0xF0
00007bdc0b3d4bb3  vmovaps [rsp], xmm0
00007bdc0b3d4bb8  vmovaps [rsp+0x10], xmm1
00007bdc0b3d4bbe  vmovaps [rsp+0x20], xmm2
00007bdc0b3d4bc4  vmovaps [rsp+0x30], xmm3
00007bdc0b3d4bca  vmovaps [rsp+0x40], xmm4
00007bdc0b3d4bd0  vmovaps [rsp+0x50], xmm5
00007bdc0b3d4bd6  vmovaps [rsp+0x60], xmm6
00007bdc0b3d4bdc  vmovaps [rsp+0x70], xmm7
00007bdc0b3d4be2  vmovaps [rsp+0x80], xmm8
00007bdc0b3d4beb  vmovaps [rsp+0x90], xmm10
00007bdc0b3d4bf4  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d4bfd  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d4c06  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d4c0f  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d4c18  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d4c21  sub rsp, 0x40
00007bdc0b3d4c25  lea rdi, [rsp]
00007bdc0b3d4c29  lea rsi, [rsp+0x10]
00007bdc0b3d4c2e  lea rdx, [rsp+0x20]
00007bdc0b3d4c33  lea rcx, [rsp+0x30]
00007bdc0b3d4c38  mov r8d, 0x00
00007bdc0b3d4c3e  lea r9, [r15+0x3A8]
00007bdc0b3d4c45  movaps [rdi], xmm9
00007bdc0b3d4c49  movaps [rsi], xmm12
00007bdc0b3d4c4d  movaps [rdx], xmm7
00007bdc0b3d4c50  movaps [rcx], xmm13
00007bdc0b3d4c54  mov rax, 0x62CE440F2A50
00007bdc0b3d4c5e  call rax
00007bdc0b3d4c60  movaps xmm9, [rsp]
00007bdc0b3d4c65  add rsp, 0x40
00007bdc0b3d4c69  vmovaps xmm0, [rsp]
00007bdc0b3d4c6e  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d4c74  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d4c7a  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d4c80  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d4c86  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d4c8c  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d4c92  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d4c98  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d4ca1  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d4caa  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d4cb3  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d4cbc  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d4cc5  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d4cce  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d4cd7  add rsp, 0xF0
00007bdc0b3d4cde  pop r11
00007bdc0b3d4ce0  pop r10
00007bdc0b3d4ce2  pop r9
00007bdc0b3d4ce4  pop r8
00007bdc0b3d4ce6  pop rsi
00007bdc0b3d4ce7  pop rdi
00007bdc0b3d4ce8  pop rdx
00007bdc0b3d4ce9  pop rcx
00007bdc0b3d4cea  pop rax
00007bdc0b3d4ceb  add rsp, 0x08
00007bdc0b3d4cef  jmp 0x00007BDC0B3D2F01
00007bdc0b3d4cf4  sub rsp, 0x08
00007bdc0b3d4cf8  push rax
00007bdc0b3d4cf9  push rcx
00007bdc0b3d4cfa  push rdx
00007bdc0b3d4cfb  push rdi
00007bdc0b3d4cfc  push rsi
00007bdc0b3d4cfd  push r8
00007bdc0b3d4cff  push r9
00007bdc0b3d4d01  push r10
00007bdc0b3d4d03  push r11
00007bdc0b3d4d05  sub rsp, 0xF0
00007bdc0b3d4d0c  vmovaps [rsp], xmm0
00007bdc0b3d4d11  vmovaps [rsp+0x10], xmm1
00007bdc0b3d4d17  vmovaps [rsp+0x20], xmm2
00007bdc0b3d4d1d  vmovaps [rsp+0x30], xmm3
00007bdc0b3d4d23  vmovaps [rsp+0x40], xmm4
00007bdc0b3d4d29  vmovaps [rsp+0x50], xmm5
00007bdc0b3d4d2f  vmovaps [rsp+0x60], xmm6
00007bdc0b3d4d35  vmovaps [rsp+0x70], xmm7
00007bdc0b3d4d3b  vmovaps [rsp+0x80], xmm8
00007bdc0b3d4d44  vmovaps [rsp+0x90], xmm9
00007bdc0b3d4d4d  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d4d56  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d4d5f  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d4d68  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d4d71  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d4d7a  sub rsp, 0x40
00007bdc0b3d4d7e  lea rdi, [rsp]
00007bdc0b3d4d82  lea rsi, [rsp+0x10]
00007bdc0b3d4d87  lea rdx, [rsp+0x20]
00007bdc0b3d4d8c  lea rcx, [rsp+0x30]
00007bdc0b3d4d91  mov r8d, 0x00
00007bdc0b3d4d97  lea r9, [r15+0x3A8]
00007bdc0b3d4d9e  movaps [rdi], xmm12
00007bdc0b3d4da2  movaps [rsi], xmm11
00007bdc0b3d4da6  movaps [rdx], xmm6
00007bdc0b3d4da9  movaps [rcx], xmm13
00007bdc0b3d4dad  mov rax, 0x62CE440F2A50
00007bdc0b3d4db7  call rax
00007bdc0b3d4db9  movaps xmm12, [rsp]
00007bdc0b3d4dbe  add rsp, 0x40
00007bdc0b3d4dc2  vmovaps xmm0, [rsp]
00007bdc0b3d4dc7  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d4dcd  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d4dd3  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d4dd9  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d4ddf  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d4de5  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d4deb  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d4df1  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d4dfa  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d4e03  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d4e0c  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d4e15  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d4e1e  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d4e27  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d4e30  add rsp, 0xF0
00007bdc0b3d4e37  pop r11
00007bdc0b3d4e39  pop r10
00007bdc0b3d4e3b  pop r9
00007bdc0b3d4e3d  pop r8
00007bdc0b3d4e3f  pop rsi
00007bdc0b3d4e40  pop rdi
00007bdc0b3d4e41  pop rdx
00007bdc0b3d4e42  pop rcx
00007bdc0b3d4e43  pop rax
00007bdc0b3d4e44  add rsp, 0x08
00007bdc0b3d4e48  jmp 0x00007BDC0B3D2F2A
00007bdc0b3d4e4d  sub rsp, 0x08
00007bdc0b3d4e51  push rax
00007bdc0b3d4e52  push rcx
00007bdc0b3d4e53  push rdx
00007bdc0b3d4e54  push rdi
00007bdc0b3d4e55  push rsi
00007bdc0b3d4e56  push r8
00007bdc0b3d4e58  push r9
00007bdc0b3d4e5a  push r10
00007bdc0b3d4e5c  push r11
00007bdc0b3d4e5e  sub rsp, 0xF0
00007bdc0b3d4e65  vmovaps [rsp], xmm0
00007bdc0b3d4e6a  vmovaps [rsp+0x10], xmm1
00007bdc0b3d4e70  vmovaps [rsp+0x20], xmm2
00007bdc0b3d4e76  vmovaps [rsp+0x30], xmm3
00007bdc0b3d4e7c  vmovaps [rsp+0x40], xmm4
00007bdc0b3d4e82  vmovaps [rsp+0x50], xmm5
00007bdc0b3d4e88  vmovaps [rsp+0x60], xmm6
00007bdc0b3d4e8e  vmovaps [rsp+0x70], xmm8
00007bdc0b3d4e94  vmovaps [rsp+0x80], xmm9
00007bdc0b3d4e9d  vmovaps [rsp+0x90], xmm10
00007bdc0b3d4ea6  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d4eaf  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d4eb8  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d4ec1  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d4eca  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d4ed3  sub rsp, 0x40
00007bdc0b3d4ed7  lea rdi, [rsp]
00007bdc0b3d4edb  lea rsi, [rsp+0x10]
00007bdc0b3d4ee0  lea rdx, [rsp+0x20]
00007bdc0b3d4ee5  lea rcx, [rsp+0x30]
00007bdc0b3d4eea  mov r8d, 0x00
00007bdc0b3d4ef0  lea r9, [r15+0x3A8]
00007bdc0b3d4ef7  movaps [rdi], xmm7
00007bdc0b3d4efa  movaps [rsi], xmm10
00007bdc0b3d4efe  movaps [rdx], xmm11
00007bdc0b3d4f02  movaps [rcx], xmm13
00007bdc0b3d4f06  mov rax, 0x62CE440F2A50
00007bdc0b3d4f10  call rax
00007bdc0b3d4f12  movaps xmm7, [rsp]
00007bdc0b3d4f16  add rsp, 0x40
00007bdc0b3d4f1a  vmovaps xmm0, [rsp]
00007bdc0b3d4f1f  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d4f25  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d4f2b  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d4f31  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d4f37  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d4f3d  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d4f43  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d4f49  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d4f52  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d4f5b  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d4f64  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d4f6d  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d4f76  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d4f7f  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d4f88  add rsp, 0xF0
00007bdc0b3d4f8f  pop r11
00007bdc0b3d4f91  pop r10
00007bdc0b3d4f93  pop r9
00007bdc0b3d4f95  pop r8
00007bdc0b3d4f97  pop rsi
00007bdc0b3d4f98  pop rdi
00007bdc0b3d4f99  pop rdx
00007bdc0b3d4f9a  pop rcx
00007bdc0b3d4f9b  pop rax
00007bdc0b3d4f9c  add rsp, 0x08
00007bdc0b3d4fa0  jmp 0x00007BDC0B3D2F58
00007bdc0b3d4fa5  call 0x00007BDC0B20C260
00007bdc0b3d4faa  jmp 0x00007BDC0B3D2F62
00007bdc0b3d4faf  call 0x00007BDC0B209D70
00007bdc0b3d4fb4  jmp 0x00007BDC0B3D2F6C
00007bdc0b3d4fb9  sub rsp, 0x08
00007bdc0b3d4fbd  push rax
00007bdc0b3d4fbe  push rcx
00007bdc0b3d4fbf  push rdx
00007bdc0b3d4fc0  push rdi
00007bdc0b3d4fc1  push rsi
00007bdc0b3d4fc2  push r8
00007bdc0b3d4fc4  push r9
00007bdc0b3d4fc6  push r10
00007bdc0b3d4fc8  push r11
00007bdc0b3d4fca  sub rsp, 0xF0
00007bdc0b3d4fd1  vmovaps [rsp], xmm0
00007bdc0b3d4fd6  vmovaps [rsp+0x10], xmm1
00007bdc0b3d4fdc  vmovaps [rsp+0x20], xmm2
00007bdc0b3d4fe2  vmovaps [rsp+0x30], xmm3
00007bdc0b3d4fe8  vmovaps [rsp+0x40], xmm4
00007bdc0b3d4fee  vmovaps [rsp+0x50], xmm5
00007bdc0b3d4ff4  vmovaps [rsp+0x60], xmm7
00007bdc0b3d4ffa  vmovaps [rsp+0x70], xmm8
00007bdc0b3d5000  vmovaps [rsp+0x80], xmm9
00007bdc0b3d5009  vmovaps [rsp+0x90], xmm10
00007bdc0b3d5012  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d501b  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d5024  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d502d  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d5036  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d503f  sub rsp, 0x40
00007bdc0b3d5043  lea rdi, [rsp]
00007bdc0b3d5047  lea rsi, [rsp+0x10]
00007bdc0b3d504c  lea rdx, [rsp+0x20]
00007bdc0b3d5051  lea rcx, [rsp+0x30]
00007bdc0b3d5056  mov r8d, 0x00
00007bdc0b3d505c  lea r9, [r15+0x3A8]
00007bdc0b3d5063  movaps [rdi], xmm6
00007bdc0b3d5066  movaps [rsi], xmm8
00007bdc0b3d506a  movaps [rdx], xmm15
00007bdc0b3d506e  movaps [rcx], xmm10
00007bdc0b3d5072  mov rax, 0x62CE440F2A50
00007bdc0b3d507c  call rax
00007bdc0b3d507e  movaps xmm6, [rsp]
00007bdc0b3d5082  add rsp, 0x40
00007bdc0b3d5086  vmovaps xmm0, [rsp]
00007bdc0b3d508b  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d5091  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d5097  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d509d  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d50a3  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d50a9  vmovaps xmm7, [rsp+0x60]
00007bdc0b3d50af  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d50b5  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d50be  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d50c7  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d50d0  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d50d9  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d50e2  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d50eb  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d50f4  add rsp, 0xF0
00007bdc0b3d50fb  pop r11
00007bdc0b3d50fd  pop r10
00007bdc0b3d50ff  pop r9
00007bdc0b3d5101  pop r8
00007bdc0b3d5103  pop rsi
00007bdc0b3d5104  pop rdi
00007bdc0b3d5105  pop rdx
00007bdc0b3d5106  pop rcx
00007bdc0b3d5107  pop rax
00007bdc0b3d5108  add rsp, 0x08
00007bdc0b3d510c  jmp 0x00007BDC0B3D2FA4
00007bdc0b3d5111  sub rsp, 0x08
00007bdc0b3d5115  push rax
00007bdc0b3d5116  push rcx
00007bdc0b3d5117  push rdx
00007bdc0b3d5118  push rdi
00007bdc0b3d5119  push rsi
00007bdc0b3d511a  push r8
00007bdc0b3d511c  push r9
00007bdc0b3d511e  push r10
00007bdc0b3d5120  push r11
00007bdc0b3d5122  sub rsp, 0xF0
00007bdc0b3d5129  vmovaps [rsp], xmm0
00007bdc0b3d512e  vmovaps [rsp+0x10], xmm1
00007bdc0b3d5134  vmovaps [rsp+0x20], xmm2
00007bdc0b3d513a  vmovaps [rsp+0x30], xmm3
00007bdc0b3d5140  vmovaps [rsp+0x40], xmm4
00007bdc0b3d5146  vmovaps [rsp+0x50], xmm5
00007bdc0b3d514c  vmovaps [rsp+0x60], xmm6
00007bdc0b3d5152  vmovaps [rsp+0x70], xmm7
00007bdc0b3d5158  vmovaps [rsp+0x80], xmm8
00007bdc0b3d5161  vmovaps [rsp+0x90], xmm9
00007bdc0b3d516a  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d5173  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d517c  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d5185  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d518e  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d5197  sub rsp, 0x40
00007bdc0b3d519b  lea rdi, [rsp]
00007bdc0b3d519f  lea rsi, [rsp+0x10]
00007bdc0b3d51a4  lea rdx, [rsp+0x20]
00007bdc0b3d51a9  lea rcx, [rsp+0x30]
00007bdc0b3d51ae  mov r8d, 0x00
00007bdc0b3d51b4  lea r9, [r15+0x3A8]
00007bdc0b3d51bb  movaps [rdi], xmm10
00007bdc0b3d51bf  movaps [rsi], xmm9
00007bdc0b3d51c3  movaps [rdx], xmm13
00007bdc0b3d51c7  movaps [rcx], xmm15
00007bdc0b3d51cb  mov rax, 0x62CE440F2A50
00007bdc0b3d51d5  call rax
00007bdc0b3d51d7  movaps xmm10, [rsp]
00007bdc0b3d51dc  add rsp, 0x40
00007bdc0b3d51e0  vmovaps xmm0, [rsp]
00007bdc0b3d51e5  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d51eb  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d51f1  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d51f7  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d51fd  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d5203  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d5209  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d520f  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d5218  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d5221  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d522a  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d5233  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d523c  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d5245  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d524e  add rsp, 0xF0
00007bdc0b3d5255  pop r11
00007bdc0b3d5257  pop r10
00007bdc0b3d5259  pop r9
00007bdc0b3d525b  pop r8
00007bdc0b3d525d  pop rsi
00007bdc0b3d525e  pop rdi
00007bdc0b3d525f  pop rdx
00007bdc0b3d5260  pop rcx
00007bdc0b3d5261  pop rax
00007bdc0b3d5262  add rsp, 0x08
00007bdc0b3d5266  jmp 0x00007BDC0B3D2FCD
00007bdc0b3d526b  sub rsp, 0x08
00007bdc0b3d526f  push rax
00007bdc0b3d5270  push rcx
00007bdc0b3d5271  push rdx
00007bdc0b3d5272  push rdi
00007bdc0b3d5273  push rsi
00007bdc0b3d5274  push r8
00007bdc0b3d5276  push r9
00007bdc0b3d5278  push r10
00007bdc0b3d527a  push r11
00007bdc0b3d527c  sub rsp, 0xF0
00007bdc0b3d5283  vmovaps [rsp], xmm0
00007bdc0b3d5288  vmovaps [rsp+0x10], xmm1
00007bdc0b3d528e  vmovaps [rsp+0x20], xmm2
00007bdc0b3d5294  vmovaps [rsp+0x30], xmm3
00007bdc0b3d529a  vmovaps [rsp+0x40], xmm4
00007bdc0b3d52a0  vmovaps [rsp+0x50], xmm5
00007bdc0b3d52a6  vmovaps [rsp+0x60], xmm6
00007bdc0b3d52ac  vmovaps [rsp+0x70], xmm7
00007bdc0b3d52b2  vmovaps [rsp+0x80], xmm8
00007bdc0b3d52bb  vmovaps [rsp+0x90], xmm9
00007bdc0b3d52c4  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d52cd  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d52d6  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d52df  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d52e8  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d52f1  sub rsp, 0x40
00007bdc0b3d52f5  lea rdi, [rsp]
00007bdc0b3d52f9  lea rsi, [rsp+0x10]
00007bdc0b3d52fe  lea rdx, [rsp+0x20]
00007bdc0b3d5303  lea rcx, [rsp+0x30]
00007bdc0b3d5308  mov r8d, 0x00
00007bdc0b3d530e  lea r9, [r15+0x3A8]
00007bdc0b3d5315  movaps [rdi], xmm13
00007bdc0b3d5319  movaps [rsi], xmm12
00007bdc0b3d531d  movaps [rdx], xmm4
00007bdc0b3d5320  movaps [rcx], xmm15
00007bdc0b3d5324  mov rax, 0x62CE440F2A50
00007bdc0b3d532e  call rax
00007bdc0b3d5330  movaps xmm13, [rsp]
00007bdc0b3d5335  add rsp, 0x40
00007bdc0b3d5339  vmovaps xmm0, [rsp]
00007bdc0b3d533e  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d5344  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d534a  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d5350  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d5356  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d535c  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d5362  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d5368  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d5371  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d537a  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d5383  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d538c  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d5395  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d539e  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d53a7  add rsp, 0xF0
00007bdc0b3d53ae  pop r11
00007bdc0b3d53b0  pop r10
00007bdc0b3d53b2  pop r9
00007bdc0b3d53b4  pop r8
00007bdc0b3d53b6  pop rsi
00007bdc0b3d53b7  pop rdi
00007bdc0b3d53b8  pop rdx
00007bdc0b3d53b9  pop rcx
00007bdc0b3d53ba  pop rax
00007bdc0b3d53bb  add rsp, 0x08
00007bdc0b3d53bf  jmp 0x00007BDC0B3D2FF6
00007bdc0b3d53c4  sub rsp, 0x08
00007bdc0b3d53c8  push rax
00007bdc0b3d53c9  push rcx
00007bdc0b3d53ca  push rdx
00007bdc0b3d53cb  push rdi
00007bdc0b3d53cc  push rsi
00007bdc0b3d53cd  push r8
00007bdc0b3d53cf  push r9
00007bdc0b3d53d1  push r10
00007bdc0b3d53d3  push r11
00007bdc0b3d53d5  sub rsp, 0xF0
00007bdc0b3d53dc  vmovaps [rsp], xmm0
00007bdc0b3d53e1  vmovaps [rsp+0x10], xmm1
00007bdc0b3d53e7  vmovaps [rsp+0x20], xmm2
00007bdc0b3d53ed  vmovaps [rsp+0x30], xmm3
00007bdc0b3d53f3  vmovaps [rsp+0x40], xmm4
00007bdc0b3d53f9  vmovaps [rsp+0x50], xmm5
00007bdc0b3d53ff  vmovaps [rsp+0x60], xmm6
00007bdc0b3d5405  vmovaps [rsp+0x70], xmm7
00007bdc0b3d540b  vmovaps [rsp+0x80], xmm8
00007bdc0b3d5414  vmovaps [rsp+0x90], xmm9
00007bdc0b3d541d  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d5426  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d542f  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d5438  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d5441  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d544a  sub rsp, 0x40
00007bdc0b3d544e  lea rdi, [rsp]
00007bdc0b3d5452  lea rsi, [rsp+0x10]
00007bdc0b3d5457  lea rdx, [rsp+0x20]
00007bdc0b3d545c  lea rcx, [rsp+0x30]
00007bdc0b3d5461  mov r8d, 0x00
00007bdc0b3d5467  lea r9, [r15+0x3A8]
00007bdc0b3d546e  movaps [rdi], xmm12
00007bdc0b3d5472  movaps [rsi], xmm7
00007bdc0b3d5475  movaps [rdx], xmm1
00007bdc0b3d5478  movaps [rcx], xmm15
00007bdc0b3d547c  mov rax, 0x62CE440F2A50
00007bdc0b3d5486  call rax
00007bdc0b3d5488  movaps xmm12, [rsp]
00007bdc0b3d548d  add rsp, 0x40
00007bdc0b3d5491  vmovaps xmm0, [rsp]
00007bdc0b3d5496  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d549c  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d54a2  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d54a8  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d54ae  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d54b4  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d54ba  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d54c0  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d54c9  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d54d2  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d54db  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d54e4  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d54ed  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d54f6  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d54ff  add rsp, 0xF0
00007bdc0b3d5506  pop r11
00007bdc0b3d5508  pop r10
00007bdc0b3d550a  pop r9
00007bdc0b3d550c  pop r8
00007bdc0b3d550e  pop rsi
00007bdc0b3d550f  pop rdi
00007bdc0b3d5510  pop rdx
00007bdc0b3d5511  pop rcx
00007bdc0b3d5512  pop rax
00007bdc0b3d5513  add rsp, 0x08
00007bdc0b3d5517  jmp 0x00007BDC0B3D301F
00007bdc0b3d551c  call 0x00007BDC0B1FF430
00007bdc0b3d5521  jmp 0x00007BDC0B3D3029
00007bdc0b3d5526  call 0x00007BDC0B20E760
00007bdc0b3d552b  jmp 0x00007BDC0B3D3033
00007bdc0b3d5530  sub rsp, 0x08
00007bdc0b3d5534  push rax
00007bdc0b3d5535  push rcx
00007bdc0b3d5536  push rdx
00007bdc0b3d5537  push rdi
00007bdc0b3d5538  push rsi
00007bdc0b3d5539  push r8
00007bdc0b3d553b  push r9
00007bdc0b3d553d  push r10
00007bdc0b3d553f  push r11
00007bdc0b3d5541  sub rsp, 0xF0
00007bdc0b3d5548  vmovaps [rsp], xmm0
00007bdc0b3d554d  vmovaps [rsp+0x10], xmm1
00007bdc0b3d5553  vmovaps [rsp+0x20], xmm2
00007bdc0b3d5559  vmovaps [rsp+0x30], xmm3
00007bdc0b3d555f  vmovaps [rsp+0x40], xmm4
00007bdc0b3d5565  vmovaps [rsp+0x50], xmm5
00007bdc0b3d556b  vmovaps [rsp+0x60], xmm6
00007bdc0b3d5571  vmovaps [rsp+0x70], xmm8
00007bdc0b3d5577  vmovaps [rsp+0x80], xmm9
00007bdc0b3d5580  vmovaps [rsp+0x90], xmm10
00007bdc0b3d5589  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d5592  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d559b  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d55a4  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d55ad  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d55b6  sub rsp, 0x40
00007bdc0b3d55ba  lea rdi, [rsp]
00007bdc0b3d55be  lea rsi, [rsp+0x10]
00007bdc0b3d55c3  lea rdx, [rsp+0x20]
00007bdc0b3d55c8  lea rcx, [rsp+0x30]
00007bdc0b3d55cd  mov r8d, 0x00
00007bdc0b3d55d3  lea r9, [r15+0x3A8]
00007bdc0b3d55da  movaps [rdi], xmm7
00007bdc0b3d55dd  movaps [rsi], xmm6
00007bdc0b3d55e0  movaps [rdx], xmm8
00007bdc0b3d55e4  movaps [rcx], xmm9
00007bdc0b3d55e8  mov rax, 0x62CE440F2A50
00007bdc0b3d55f2  call rax
00007bdc0b3d55f4  movaps xmm7, [rsp]
00007bdc0b3d55f8  add rsp, 0x40
00007bdc0b3d55fc  vmovaps xmm0, [rsp]
00007bdc0b3d5601  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d5607  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d560d  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d5613  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d5619  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d561f  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d5625  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d562b  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d5634  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d563d  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d5646  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d564f  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d5658  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d5661  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d566a  add rsp, 0xF0
00007bdc0b3d5671  pop r11
00007bdc0b3d5673  pop r10
00007bdc0b3d5675  pop r9
00007bdc0b3d5677  pop r8
00007bdc0b3d5679  pop rsi
00007bdc0b3d567a  pop rdi
00007bdc0b3d567b  pop rdx
00007bdc0b3d567c  pop rcx
00007bdc0b3d567d  pop rax
00007bdc0b3d567e  add rsp, 0x08
00007bdc0b3d5682  jmp 0x00007BDC0B3D305D
00007bdc0b3d5687  sub rsp, 0x08
00007bdc0b3d568b  push rax
00007bdc0b3d568c  push rcx
00007bdc0b3d568d  push rdx
00007bdc0b3d568e  push rdi
00007bdc0b3d568f  push rsi
00007bdc0b3d5690  push r8
00007bdc0b3d5692  push r9
00007bdc0b3d5694  push r10
00007bdc0b3d5696  push r11
00007bdc0b3d5698  sub rsp, 0xF0
00007bdc0b3d569f  vmovaps [rsp], xmm0
00007bdc0b3d56a4  vmovaps [rsp+0x10], xmm1
00007bdc0b3d56aa  vmovaps [rsp+0x20], xmm2
00007bdc0b3d56b0  vmovaps [rsp+0x30], xmm3
00007bdc0b3d56b6  vmovaps [rsp+0x40], xmm4
00007bdc0b3d56bc  vmovaps [rsp+0x50], xmm5
00007bdc0b3d56c2  vmovaps [rsp+0x60], xmm6
00007bdc0b3d56c8  vmovaps [rsp+0x70], xmm7
00007bdc0b3d56ce  vmovaps [rsp+0x80], xmm9
00007bdc0b3d56d7  vmovaps [rsp+0x90], xmm10
00007bdc0b3d56e0  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d56e9  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d56f2  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d56fb  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d5704  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d570d  sub rsp, 0x40
00007bdc0b3d5711  lea rdi, [rsp]
00007bdc0b3d5715  lea rsi, [rsp+0x10]
00007bdc0b3d571a  lea rdx, [rsp+0x20]
00007bdc0b3d571f  lea rcx, [rsp+0x30]
00007bdc0b3d5724  mov r8d, 0x00
00007bdc0b3d572a  lea r9, [r15+0x3A8]
00007bdc0b3d5731  movaps [rdi], xmm8
00007bdc0b3d5735  movaps [rsi], xmm10
00007bdc0b3d5739  movaps [rdx], xmm14
00007bdc0b3d573d  movaps [rcx], xmm9
00007bdc0b3d5741  mov rax, 0x62CE440F2A50
00007bdc0b3d574b  call rax
00007bdc0b3d574d  movaps xmm8, [rsp]
00007bdc0b3d5752  add rsp, 0x40
00007bdc0b3d5756  vmovaps xmm0, [rsp]
00007bdc0b3d575b  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d5761  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d5767  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d576d  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d5773  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d5779  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d577f  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d5785  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d578e  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d5797  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d57a0  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d57a9  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d57b2  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d57bb  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d57c4  add rsp, 0xF0
00007bdc0b3d57cb  pop r11
00007bdc0b3d57cd  pop r10
00007bdc0b3d57cf  pop r9
00007bdc0b3d57d1  pop r8
00007bdc0b3d57d3  pop rsi
00007bdc0b3d57d4  pop rdi
00007bdc0b3d57d5  pop rdx
00007bdc0b3d57d6  pop rcx
00007bdc0b3d57d7  pop rax
00007bdc0b3d57d8  add rsp, 0x08
00007bdc0b3d57dc  jmp 0x00007BDC0B3D3083
00007bdc0b3d57e1  sub rsp, 0x08
00007bdc0b3d57e5  push rax
00007bdc0b3d57e6  push rcx
00007bdc0b3d57e7  push rdx
00007bdc0b3d57e8  push rdi
00007bdc0b3d57e9  push rsi
00007bdc0b3d57ea  push r8
00007bdc0b3d57ec  push r9
00007bdc0b3d57ee  push r10
00007bdc0b3d57f0  push r11
00007bdc0b3d57f2  sub rsp, 0xF0
00007bdc0b3d57f9  vmovaps [rsp], xmm0
00007bdc0b3d57fe  vmovaps [rsp+0x10], xmm1
00007bdc0b3d5804  vmovaps [rsp+0x20], xmm2
00007bdc0b3d580a  vmovaps [rsp+0x30], xmm3
00007bdc0b3d5810  vmovaps [rsp+0x40], xmm4
00007bdc0b3d5816  vmovaps [rsp+0x50], xmm5
00007bdc0b3d581c  vmovaps [rsp+0x60], xmm6
00007bdc0b3d5822  vmovaps [rsp+0x70], xmm7
00007bdc0b3d5828  vmovaps [rsp+0x80], xmm8
00007bdc0b3d5831  vmovaps [rsp+0x90], xmm9
00007bdc0b3d583a  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d5843  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d584c  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d5855  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d585e  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d5867  sub rsp, 0x40
00007bdc0b3d586b  lea rdi, [rsp]
00007bdc0b3d586f  lea rsi, [rsp+0x10]
00007bdc0b3d5874  lea rdx, [rsp+0x20]
00007bdc0b3d5879  lea rcx, [rsp+0x30]
00007bdc0b3d587e  mov r8d, 0x00
00007bdc0b3d5884  lea r9, [r15+0x3A8]
00007bdc0b3d588b  movaps [rdi], xmm10
00007bdc0b3d588f  movaps [rsi], xmm13
00007bdc0b3d5893  movaps [rdx], xmm11
00007bdc0b3d5897  movaps [rcx], xmm14
00007bdc0b3d589b  mov rax, 0x62CE440F2A50
00007bdc0b3d58a5  call rax
00007bdc0b3d58a7  movaps xmm10, [rsp]
00007bdc0b3d58ac  add rsp, 0x40
00007bdc0b3d58b0  vmovaps xmm0, [rsp]
00007bdc0b3d58b5  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d58bb  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d58c1  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d58c7  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d58cd  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d58d3  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d58d9  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d58df  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d58e8  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d58f1  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d58fa  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d5903  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d590c  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d5915  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d591e  add rsp, 0xF0
00007bdc0b3d5925  pop r11
00007bdc0b3d5927  pop r10
00007bdc0b3d5929  pop r9
00007bdc0b3d592b  pop r8
00007bdc0b3d592d  pop rsi
00007bdc0b3d592e  pop rdi
00007bdc0b3d592f  pop rdx
00007bdc0b3d5930  pop rcx
00007bdc0b3d5931  pop rax
00007bdc0b3d5932  add rsp, 0x08
00007bdc0b3d5936  jmp 0x00007BDC0B3D30A9
00007bdc0b3d593b  sub rsp, 0x08
00007bdc0b3d593f  push rax
00007bdc0b3d5940  push rcx
00007bdc0b3d5941  push rdx
00007bdc0b3d5942  push rdi
00007bdc0b3d5943  push rsi
00007bdc0b3d5944  push r8
00007bdc0b3d5946  push r9
00007bdc0b3d5948  push r10
00007bdc0b3d594a  push r11
00007bdc0b3d594c  sub rsp, 0xF0
00007bdc0b3d5953  vmovaps [rsp], xmm0
00007bdc0b3d5958  vmovaps [rsp+0x10], xmm1
00007bdc0b3d595e  vmovaps [rsp+0x20], xmm2
00007bdc0b3d5964  vmovaps [rsp+0x30], xmm3
00007bdc0b3d596a  vmovaps [rsp+0x40], xmm4
00007bdc0b3d5970  vmovaps [rsp+0x50], xmm5
00007bdc0b3d5976  vmovaps [rsp+0x60], xmm6
00007bdc0b3d597c  vmovaps [rsp+0x70], xmm7
00007bdc0b3d5982  vmovaps [rsp+0x80], xmm8
00007bdc0b3d598b  vmovaps [rsp+0x90], xmm9
00007bdc0b3d5994  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d599d  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d59a6  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d59af  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d59b8  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d59c1  sub rsp, 0x40
00007bdc0b3d59c5  lea rdi, [rsp]
00007bdc0b3d59c9  lea rsi, [rsp+0x10]
00007bdc0b3d59ce  lea rdx, [rsp+0x20]
00007bdc0b3d59d3  lea rcx, [rsp+0x30]
00007bdc0b3d59d8  mov r8d, 0x00
00007bdc0b3d59de  lea r9, [r15+0x3A8]
00007bdc0b3d59e5  movaps [rdi], xmm13
00007bdc0b3d59e9  movaps [rsi], xmm12
00007bdc0b3d59ed  movaps [rdx], xmm15
00007bdc0b3d59f1  movaps [rcx], xmm14
00007bdc0b3d59f5  mov rax, 0x62CE440F2A50
00007bdc0b3d59ff  call rax
00007bdc0b3d5a01  movaps xmm13, [rsp]
00007bdc0b3d5a06  add rsp, 0x40
00007bdc0b3d5a0a  vmovaps xmm0, [rsp]
00007bdc0b3d5a0f  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d5a15  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d5a1b  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d5a21  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d5a27  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d5a2d  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d5a33  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d5a39  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d5a42  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d5a4b  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d5a54  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d5a5d  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d5a66  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d5a6f  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d5a78  add rsp, 0xF0
00007bdc0b3d5a7f  pop r11
00007bdc0b3d5a81  pop r10
00007bdc0b3d5a83  pop r9
00007bdc0b3d5a85  pop r8
00007bdc0b3d5a87  pop rsi
00007bdc0b3d5a88  pop rdi
00007bdc0b3d5a89  pop rdx
00007bdc0b3d5a8a  pop rcx
00007bdc0b3d5a8b  pop rax
00007bdc0b3d5a8c  add rsp, 0x08
00007bdc0b3d5a90  jmp 0x00007BDC0B3D30CF
00007bdc0b3d5a95  call 0x00007BDC0B20E760
00007bdc0b3d5a9a  jmp 0x00007BDC0B3D30DC
00007bdc0b3d5a9f  call 0x00007BDC0B20D4E0
00007bdc0b3d5aa4  jmp 0x00007BDC0B3D30E9
00007bdc0b3d5aa9  sub rsp, 0x08
00007bdc0b3d5aad  push rax
00007bdc0b3d5aae  push rcx
00007bdc0b3d5aaf  push rdx
00007bdc0b3d5ab0  push rdi
00007bdc0b3d5ab1  push rsi
00007bdc0b3d5ab2  push r8
00007bdc0b3d5ab4  push r9
00007bdc0b3d5ab6  push r10
00007bdc0b3d5ab8  push r11
00007bdc0b3d5aba  sub rsp, 0xF0
00007bdc0b3d5ac1  vmovaps [rsp], xmm0
00007bdc0b3d5ac6  vmovaps [rsp+0x10], xmm1
00007bdc0b3d5acc  vmovaps [rsp+0x20], xmm2
00007bdc0b3d5ad2  vmovaps [rsp+0x30], xmm3
00007bdc0b3d5ad8  vmovaps [rsp+0x40], xmm4
00007bdc0b3d5ade  vmovaps [rsp+0x50], xmm5
00007bdc0b3d5ae4  vmovaps [rsp+0x60], xmm6
00007bdc0b3d5aea  vmovaps [rsp+0x70], xmm7
00007bdc0b3d5af0  vmovaps [rsp+0x80], xmm8
00007bdc0b3d5af9  vmovaps [rsp+0x90], xmm9
00007bdc0b3d5b02  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d5b0b  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d5b14  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d5b1d  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d5b26  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d5b2f  sub rsp, 0x40
00007bdc0b3d5b33  lea rdi, [rsp]
00007bdc0b3d5b37  lea rsi, [rsp+0x10]
00007bdc0b3d5b3c  lea rdx, [rsp+0x20]
00007bdc0b3d5b41  lea rcx, [rsp+0x30]
00007bdc0b3d5b46  mov r8d, 0x00
00007bdc0b3d5b4c  lea r9, [r15+0x3A8]
00007bdc0b3d5b53  movaps [rdi], xmm11
00007bdc0b3d5b57  movaps [rsi], xmm7
00007bdc0b3d5b5a  movaps [rdx], xmm1
00007bdc0b3d5b5d  movaps [rcx], xmm12
00007bdc0b3d5b61  mov rax, 0x62CE440F2A50
00007bdc0b3d5b6b  call rax
00007bdc0b3d5b6d  movaps xmm11, [rsp]
00007bdc0b3d5b72  add rsp, 0x40
00007bdc0b3d5b76  vmovaps xmm0, [rsp]
00007bdc0b3d5b7b  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d5b81  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d5b87  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d5b8d  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d5b93  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d5b99  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d5b9f  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d5ba5  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d5bae  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d5bb7  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d5bc0  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d5bc9  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d5bd2  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d5bdb  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d5be4  add rsp, 0xF0
00007bdc0b3d5beb  pop r11
00007bdc0b3d5bed  pop r10
00007bdc0b3d5bef  pop r9
00007bdc0b3d5bf1  pop r8
00007bdc0b3d5bf3  pop rsi
00007bdc0b3d5bf4  pop rdi
00007bdc0b3d5bf5  pop rdx
00007bdc0b3d5bf6  pop rcx
00007bdc0b3d5bf7  pop rax
00007bdc0b3d5bf8  add rsp, 0x08
00007bdc0b3d5bfc  jmp 0x00007BDC0B3D3122
00007bdc0b3d5c01  call 0x00007BDC0B1FF430
00007bdc0b3d5c06  jmp 0x00007BDC0B3D3134
00007bdc0b3d5c0b  sub rsp, 0x08
00007bdc0b3d5c0f  push rax
00007bdc0b3d5c10  push rcx
00007bdc0b3d5c11  push rdx
00007bdc0b3d5c12  push rdi
00007bdc0b3d5c13  push rsi
00007bdc0b3d5c14  push r8
00007bdc0b3d5c16  push r9
00007bdc0b3d5c18  push r10
00007bdc0b3d5c1a  push r11
00007bdc0b3d5c1c  sub rsp, 0xF0
00007bdc0b3d5c23  vmovaps [rsp], xmm0
00007bdc0b3d5c28  vmovaps [rsp+0x10], xmm1
00007bdc0b3d5c2e  vmovaps [rsp+0x20], xmm2
00007bdc0b3d5c34  vmovaps [rsp+0x30], xmm3
00007bdc0b3d5c3a  vmovaps [rsp+0x40], xmm4
00007bdc0b3d5c40  vmovaps [rsp+0x50], xmm5
00007bdc0b3d5c46  vmovaps [rsp+0x60], xmm6
00007bdc0b3d5c4c  vmovaps [rsp+0x70], xmm7
00007bdc0b3d5c52  vmovaps [rsp+0x80], xmm8
00007bdc0b3d5c5b  vmovaps [rsp+0x90], xmm10
00007bdc0b3d5c64  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d5c6d  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d5c76  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d5c7f  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d5c88  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d5c91  sub rsp, 0x40
00007bdc0b3d5c95  lea rdi, [rsp]
00007bdc0b3d5c99  lea rsi, [rsp+0x10]
00007bdc0b3d5c9e  lea rdx, [rsp+0x20]
00007bdc0b3d5ca3  lea rcx, [rsp+0x30]
00007bdc0b3d5ca8  mov r8d, 0x00
00007bdc0b3d5cae  lea r9, [r15+0x3A8]
00007bdc0b3d5cb5  movaps [rdi], xmm9
00007bdc0b3d5cb9  movaps [rsi], xmm8
00007bdc0b3d5cbd  movaps [rdx], xmm14
00007bdc0b3d5cc1  movaps [rcx], xmm12
00007bdc0b3d5cc5  mov rax, 0x62CE440F2A50
00007bdc0b3d5ccf  call rax
00007bdc0b3d5cd1  movaps xmm9, [rsp]
00007bdc0b3d5cd6  add rsp, 0x40
00007bdc0b3d5cda  vmovaps xmm0, [rsp]
00007bdc0b3d5cdf  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d5ce5  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d5ceb  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d5cf1  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d5cf7  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d5cfd  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d5d03  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d5d09  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d5d12  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d5d1b  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d5d24  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d5d2d  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d5d36  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d5d3f  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d5d48  add rsp, 0xF0
00007bdc0b3d5d4f  pop r11
00007bdc0b3d5d51  pop r10
00007bdc0b3d5d53  pop r9
00007bdc0b3d5d55  pop r8
00007bdc0b3d5d57  pop rsi
00007bdc0b3d5d58  pop rdi
00007bdc0b3d5d59  pop rdx
00007bdc0b3d5d5a  pop rcx
00007bdc0b3d5d5b  pop rax
00007bdc0b3d5d5c  add rsp, 0x08
00007bdc0b3d5d60  jmp 0x00007BDC0B3D3165
00007bdc0b3d5d65  sub rsp, 0x08
00007bdc0b3d5d69  push rax
00007bdc0b3d5d6a  push rcx
00007bdc0b3d5d6b  push rdx
00007bdc0b3d5d6c  push rdi
00007bdc0b3d5d6d  push rsi
00007bdc0b3d5d6e  push r8
00007bdc0b3d5d70  push r9
00007bdc0b3d5d72  push r10
00007bdc0b3d5d74  push r11
00007bdc0b3d5d76  sub rsp, 0xF0
00007bdc0b3d5d7d  vmovaps [rsp], xmm0
00007bdc0b3d5d82  vmovaps [rsp+0x10], xmm1
00007bdc0b3d5d88  vmovaps [rsp+0x20], xmm2
00007bdc0b3d5d8e  vmovaps [rsp+0x30], xmm3
00007bdc0b3d5d94  vmovaps [rsp+0x40], xmm4
00007bdc0b3d5d9a  vmovaps [rsp+0x50], xmm5
00007bdc0b3d5da0  vmovaps [rsp+0x60], xmm6
00007bdc0b3d5da6  vmovaps [rsp+0x70], xmm7
00007bdc0b3d5dac  vmovaps [rsp+0x80], xmm8
00007bdc0b3d5db5  vmovaps [rsp+0x90], xmm9
00007bdc0b3d5dbe  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d5dc7  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d5dd0  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d5dd9  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d5de2  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d5deb  sub rsp, 0x40
00007bdc0b3d5def  lea rdi, [rsp]
00007bdc0b3d5df3  lea rsi, [rsp+0x10]
00007bdc0b3d5df8  lea rdx, [rsp+0x20]
00007bdc0b3d5dfd  lea rcx, [rsp+0x30]
00007bdc0b3d5e02  mov r8d, 0x00
00007bdc0b3d5e08  lea r9, [r15+0x3A8]
00007bdc0b3d5e0f  movaps [rdi], xmm12
00007bdc0b3d5e13  movaps [rsi], xmm10
00007bdc0b3d5e17  movaps [rdx], xmm15
00007bdc0b3d5e1b  movaps [rcx], xmm14
00007bdc0b3d5e1f  mov rax, 0x62CE440F2A50
00007bdc0b3d5e29  call rax
00007bdc0b3d5e2b  movaps xmm12, [rsp]
00007bdc0b3d5e30  add rsp, 0x40
00007bdc0b3d5e34  vmovaps xmm0, [rsp]
00007bdc0b3d5e39  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d5e3f  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d5e45  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d5e4b  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d5e51  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d5e57  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d5e5d  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d5e63  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d5e6c  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d5e75  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d5e7e  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d5e87  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d5e90  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d5e99  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d5ea2  add rsp, 0xF0
00007bdc0b3d5ea9  pop r11
00007bdc0b3d5eab  pop r10
00007bdc0b3d5ead  pop r9
00007bdc0b3d5eaf  pop r8
00007bdc0b3d5eb1  pop rsi
00007bdc0b3d5eb2  pop rdi
00007bdc0b3d5eb3  pop rdx
00007bdc0b3d5eb4  pop rcx
00007bdc0b3d5eb5  pop rax
00007bdc0b3d5eb6  add rsp, 0x08
00007bdc0b3d5eba  jmp 0x00007BDC0B3D3196
00007bdc0b3d5ebf  sub rsp, 0x08
00007bdc0b3d5ec3  push rax
00007bdc0b3d5ec4  push rcx
00007bdc0b3d5ec5  push rdx
00007bdc0b3d5ec6  push rdi
00007bdc0b3d5ec7  push rsi
00007bdc0b3d5ec8  push r8
00007bdc0b3d5eca  push r9
00007bdc0b3d5ecc  push r10
00007bdc0b3d5ece  push r11
00007bdc0b3d5ed0  sub rsp, 0xF0
00007bdc0b3d5ed7  vmovaps [rsp], xmm0
00007bdc0b3d5edc  vmovaps [rsp+0x10], xmm1
00007bdc0b3d5ee2  vmovaps [rsp+0x20], xmm2
00007bdc0b3d5ee8  vmovaps [rsp+0x30], xmm3
00007bdc0b3d5eee  vmovaps [rsp+0x40], xmm4
00007bdc0b3d5ef4  vmovaps [rsp+0x50], xmm5
00007bdc0b3d5efa  vmovaps [rsp+0x60], xmm6
00007bdc0b3d5f00  vmovaps [rsp+0x70], xmm7
00007bdc0b3d5f06  vmovaps [rsp+0x80], xmm8
00007bdc0b3d5f0f  vmovaps [rsp+0x90], xmm9
00007bdc0b3d5f18  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d5f21  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d5f2a  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d5f33  vmovaps [rsp+0xD0], xmm13
00007bdc0b3d5f3c  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d5f45  sub rsp, 0x40
00007bdc0b3d5f49  lea rdi, [rsp]
00007bdc0b3d5f4d  lea rsi, [rsp+0x10]
00007bdc0b3d5f52  lea rdx, [rsp+0x20]
00007bdc0b3d5f57  lea rcx, [rsp+0x30]
00007bdc0b3d5f5c  mov r8d, 0x00
00007bdc0b3d5f62  lea r9, [r15+0x3A8]
00007bdc0b3d5f69  movaps [rdi], xmm14
00007bdc0b3d5f6d  movaps [rsi], xmm13
00007bdc0b3d5f71  movaps [rdx], xmm1
00007bdc0b3d5f74  movaps [rcx], xmm15
00007bdc0b3d5f78  mov rax, 0x62CE440F2A50
00007bdc0b3d5f82  call rax
00007bdc0b3d5f84  movaps xmm14, [rsp]
00007bdc0b3d5f89  add rsp, 0x40
00007bdc0b3d5f8d  vmovaps xmm0, [rsp]
00007bdc0b3d5f92  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d5f98  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d5f9e  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d5fa4  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d5faa  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d5fb0  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d5fb6  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d5fbc  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d5fc5  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d5fce  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d5fd7  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d5fe0  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d5fe9  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3d5ff2  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d5ffb  add rsp, 0xF0
00007bdc0b3d6002  pop r11
00007bdc0b3d6004  pop r10
00007bdc0b3d6006  pop r9
00007bdc0b3d6008  pop r8
00007bdc0b3d600a  pop rsi
00007bdc0b3d600b  pop rdi
00007bdc0b3d600c  pop rdx
00007bdc0b3d600d  pop rcx
00007bdc0b3d600e  pop rax
00007bdc0b3d600f  add rsp, 0x08
00007bdc0b3d6013  jmp 0x00007BDC0B3D31C7
00007bdc0b3d6018  call 0x00007BDC0B2079B0
00007bdc0b3d601d  jmp 0x00007BDC0B3D31DA
00007bdc0b3d6022  call 0x00007BDC0B20B100
00007bdc0b3d6027  jmp 0x00007BDC0B3D31E5
00007bdc0b3d602c  call 0x00007BDC0B209E90
00007bdc0b3d6031  jmp 0x00007BDC0B3D31F0
00007bdc0b3d6036  call 0x00007BDC0B20D600
00007bdc0b3d603b  jmp 0x00007BDC0B3D31FB
00007bdc0b3d6040  int3
00007bdc0b3d6041  nop [rax+rax*1], ax
00007bdc0b3d604a  nop [rax+rax*1], ax
00007bdc0b3d6050  mov rax, [r15+0x40]
00007bdc0b3d6054  mov r14, [r15+0x58]
00007bdc0b3d6058  lea r12, [rax+r14*1]
00007bdc0b3d605c  vxorps xmm1, xmm1, xmm1
00007bdc0b3d6060  vpbroadcastq xmm1, xmm1
00007bdc0b3d6065  vxorps xmm15, xmm15, xmm15
00007bdc0b3d606a  vpbroadcastq xmm15, xmm15
00007bdc0b3d606f  lea rax, [r12+0x30]
00007bdc0b3d6074  mov r11, [r13+rax*1]
00007bdc0b3d6079  lea rax, [r12+0x38]
00007bdc0b3d607e  mov r10, [r13+rax*1]
00007bdc0b3d6083  movq xmm14, r11
00007bdc0b3d6088  movq xmm13, r10
00007bdc0b3d608d  movq xmm14, xmm14
00007bdc0b3d6092  movq xmm13, xmm13
00007bdc0b3d6097  vmovaps [rsp+0x10], xmm13
00007bdc0b3d609d  movq xmm13, xmm13
00007bdc0b3d60a2  movaps [r15+0x270], xmm13
00007bdc0b3d60aa  movaps xmm13, [r15+0x160]
00007bdc0b3d60b2  vmovaps [rsp+0x20], xmm13
00007bdc0b3d60b8  vmovaps xmm12, [rsp+0x20]
00007bdc0b3d60be  por xmm13, xmm12
00007bdc0b3d60c3  lea rax, [r12+0x20]
00007bdc0b3d60c8  mov r11, [r13+rax*1]
00007bdc0b3d60cd  lea rax, [r12+0x28]
00007bdc0b3d60d2  mov r10, [r13+rax*1]
00007bdc0b3d60d7  movq xmm12, r11
00007bdc0b3d60dc  movq xmm11, r10
00007bdc0b3d60e1  movq xmm12, xmm12
00007bdc0b3d60e6  movq xmm11, xmm11
00007bdc0b3d60eb  movaps xmm10, [r15+0x2D0]
00007bdc0b3d60f3  vmovaps [rsp+0x20], xmm10
00007bdc0b3d60f9  vmovaps xmm9, [rsp+0x20]
00007bdc0b3d60ff  por xmm10, xmm9
00007bdc0b3d6104  movaps xmm9, [r15+0x300]
00007bdc0b3d610c  vmovaps [rsp+0x20], xmm9
00007bdc0b3d6112  vmovaps xmm8, [rsp+0x20]
00007bdc0b3d6118  por xmm9, xmm8
00007bdc0b3d611d  movaps xmm8, [r15+0x2B0]
00007bdc0b3d6125  vmovaps [rsp+0x20], xmm8
00007bdc0b3d612b  vmovaps xmm7, [rsp+0x20]
00007bdc0b3d6131  por xmm8, xmm7
00007bdc0b3d6136  movaps xmm7, [r15+0x180]
00007bdc0b3d613e  vmovaps [rsp+0x20], xmm7
00007bdc0b3d6144  vmovaps xmm6, [rsp+0x20]
00007bdc0b3d614a  por xmm7, xmm6
00007bdc0b3d614e  lea rax, [r12+0x10]
00007bdc0b3d6153  mov r11, [r13+rax*1]
00007bdc0b3d6158  lea rax, [r12+0x18]
00007bdc0b3d615d  mov r10, [r13+rax*1]
00007bdc0b3d6162  movq xmm6, r11
00007bdc0b3d6167  movq xmm5, r10
00007bdc0b3d616c  movq xmm6, xmm6
00007bdc0b3d6170  movq xmm5, xmm5
00007bdc0b3d6174  movaps xmm4, [r15+0x200]
00007bdc0b3d617c  vmovaps [rsp+0x20], xmm4
00007bdc0b3d6182  vmovaps xmm3, [rsp+0x20]
00007bdc0b3d6188  por xmm4, xmm3
00007bdc0b3d618c  movaps xmm3, [r15+0x1F0]
00007bdc0b3d6194  vmovaps [rsp+0x20], xmm3
00007bdc0b3d619a  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d61a0  por xmm3, xmm2
00007bdc0b3d61a4  movaps xmm2, [r15+0x2E0]
00007bdc0b3d61ac  vmovaps [rsp+0x20], xmm2
00007bdc0b3d61b2  vmovaps [rsp+0x30], xmm1
00007bdc0b3d61b8  vmovaps xmm1, [rsp+0x20]
00007bdc0b3d61be  por xmm2, xmm1
00007bdc0b3d61c2  movaps xmm1, [r15+0x2A0]
00007bdc0b3d61ca  vmovaps [rsp+0x20], xmm1
00007bdc0b3d61d0  vmovaps [rsp+0x40], xmm15
00007bdc0b3d61d6  vmovaps xmm15, [rsp+0x20]
00007bdc0b3d61dc  por xmm1, xmm15
00007bdc0b3d61e1  movaps xmm15, [r15+0x280]
00007bdc0b3d61e9  vmovaps [rsp+0x20], xmm15
00007bdc0b3d61ef  vmovaps [rsp+0x50], xmm1
00007bdc0b3d61f5  vmovaps xmm1, [rsp+0x20]
00007bdc0b3d61fb  por xmm15, xmm1
00007bdc0b3d6200  movaps xmm1, [r15+0x1C0]
00007bdc0b3d6208  vmovaps [rsp+0x20], xmm1
00007bdc0b3d620e  vmovaps [rsp+0x60], xmm15
00007bdc0b3d6214  vmovaps xmm15, [rsp+0x20]
00007bdc0b3d621a  por xmm1, xmm15
00007bdc0b3d621f  movaps xmm15, [r15+0x210]
00007bdc0b3d6227  vmovaps [rsp+0x20], xmm15
00007bdc0b3d622d  vmovaps [rsp+0x70], xmm1
00007bdc0b3d6233  vmovaps xmm1, [rsp+0x20]
00007bdc0b3d6239  por xmm15, xmm1
00007bdc0b3d623e  mov rax, [r13+r12*1]
00007bdc0b3d6243  vmovq xmm1, rax
00007bdc0b3d6248  vpbroadcastq xmm1, xmm1
00007bdc0b3d624d  vmovaps [rsp+0x20], xmm1
00007bdc0b3d6253  vxorps xmm1, xmm1, xmm1
00007bdc0b3d6257  vpbroadcastq xmm1, xmm1
00007bdc0b3d625c  mov rax, [r15+0xF8]
00007bdc0b3d6263  vmovaps [rsp+0x80], xmm1
00007bdc0b3d626c  movups xmm1, [r13+rax*1]
00007bdc0b3d6272  vmovaps [rsp+0x90], xmm1
00007bdc0b3d627b  vxorps xmm1, xmm1, xmm1
00007bdc0b3d627f  vpbroadcastq xmm1, xmm1
00007bdc0b3d6284  lea r11, [r12+0x08]
00007bdc0b3d6289  mov r12, [r13+r11*1]
00007bdc0b3d628e  vmovaps [rsp+0xA0], xmm1
00007bdc0b3d6297  movq xmm1, r12
00007bdc0b3d629c  movaps [r15+0x240], xmm1
00007bdc0b3d62a4  mov r12, [r15+0x50]
00007bdc0b3d62a8  lea r11, [r12+r14*1]
00007bdc0b3d62ac  mov [r15+0x60], r11
00007bdc0b3d62b0  lea r12, [r14+0x40]
00007bdc0b3d62b4  mov [r15+0x58], r12
00007bdc0b3d62b8  vmovaps xmm1, [rsp+0x30]
00007bdc0b3d62be  vmovaps [rsp+0x30], xmm15
00007bdc0b3d62c4  vmovaps xmm15, [rsp+0x90]
00007bdc0b3d62cd  vmovaps [rsp+0x90], xmm14
00007bdc0b3d62d6  vmovaps xmm14, [rsp+0x20]
00007bdc0b3d62dc  vmovaps [rsp+0x20], xmm13
00007bdc0b3d62e2  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d62eb  movaps xmm13, xmm1
00007bdc0b3d62ef  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d62fa  vptest xmm12, xmm12
00007bdc0b3d62ff  jnz 0x00007BDC0B3D6D9C
00007bdc0b3d6305  movaps xmm1, [r15+0x250]
00007bdc0b3d630d  vmovaps xmm15, [rsp+0x40]
00007bdc0b3d6313  vmovaps [rsp+0x40], xmm13
00007bdc0b3d6319  movaps xmm12, xmm15
00007bdc0b3d631d  vfmadd231pd xmm12, xmm1, xmm14
00007bdc0b3d6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007bdc0b3d6328  vptest xmm13, xmm13
00007bdc0b3d632d  jnz 0x00007BDC0B3D6EF5
00007bdc0b3d6333  movaps xmm15, [r15+0x1E0]
00007bdc0b3d633b  vmovaps [rsp+0xC0], xmm15
00007bdc0b3d6344  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d634d  por xmm15, xmm13
00007bdc0b3d6352  movaps xmm13, [r15+0x1D0]
00007bdc0b3d635a  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d6363  vmovaps [rsp+0xD0], xmm1
00007bdc0b3d636c  vmovaps xmm1, [rsp+0xC0]
00007bdc0b3d6375  por xmm13, xmm1
00007bdc0b3d637a  movaps xmm1, [r15+0x2C0]
00007bdc0b3d6382  vmovaps [rsp+0xC0], xmm1
00007bdc0b3d638b  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d6394  vmovaps xmm15, [rsp+0xC0]
00007bdc0b3d639d  por xmm1, xmm15
00007bdc0b3d63a2  movaps xmm15, [r15+0x290]
00007bdc0b3d63aa  vmovaps [rsp+0xC0], xmm15
00007bdc0b3d63b3  vmovaps [rsp+0xF0], xmm1
00007bdc0b3d63bc  vmovaps xmm1, [rsp+0xC0]
00007bdc0b3d63c5  por xmm15, xmm1
00007bdc0b3d63ca  movaps xmm1, [r15+0x260]
00007bdc0b3d63d2  vmovaps [rsp+0xC0], xmm1
00007bdc0b3d63db  vmovaps [rsp+0x100], xmm15
00007bdc0b3d63e4  vmovaps xmm15, [rsp+0xC0]
00007bdc0b3d63ed  por xmm1, xmm15
00007bdc0b3d63f2  vmovaps xmm15, [rsp+0xD0]
00007bdc0b3d63fb  vmovaps [rsp+0xC0], xmm1
00007bdc0b3d6404  vmovaps xmm1, [rsp+0xD0]
00007bdc0b3d640d  por xmm15, xmm1
00007bdc0b3d6412  lea r14, [rax+0xC0]
00007bdc0b3d6419  movups xmm1, [r13+r14*1]
00007bdc0b3d641f  mov [rsp+0xD0], rax
00007bdc0b3d6427  xor eax, eax
00007bdc0b3d6429  mov r14d, 0x200
00007bdc0b3d642f  cmp r12, r14
00007bdc0b3d6432  cmc
00007bdc0b3d6433  lahf
00007bdc0b3d6434  seto al
00007bdc0b3d6437  mov [r15+0x108], eax
00007bdc0b3d643e  vmovaps [rsp+0x110], xmm1
00007bdc0b3d6447  vmovaps xmm1, [rsp+0x80]
00007bdc0b3d6450  vmovaps [rsp+0x80], xmm15
00007bdc0b3d6459  vmovaps xmm15, [rsp+0x110]
00007bdc0b3d6462  vmovaps [rsp+0x110], xmm13
00007bdc0b3d646b  vmovaps [rsp+0x120], xmm12
00007bdc0b3d6474  movaps xmm13, xmm1
00007bdc0b3d6478  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d6483  vptest xmm12, xmm12
00007bdc0b3d6488  jnz 0x00007BDC0B3D7058
00007bdc0b3d648e  mov rax, [rsp+0xD0]
00007bdc0b3d6496  lea r14, [rax+0xB0]
00007bdc0b3d649d  movups xmm1, [r13+r14*1]
00007bdc0b3d64a3  vmovaps xmm15, [rsp+0xA0]
00007bdc0b3d64ac  vmovaps [rsp+0xA0], xmm13
00007bdc0b3d64b5  movaps xmm12, xmm15
00007bdc0b3d64b9  vfmadd231pd xmm12, xmm1, xmm14
00007bdc0b3d64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007bdc0b3d64c4  vptest xmm13, xmm13
00007bdc0b3d64c9  jnz 0x00007BDC0B3D71BB
00007bdc0b3d64cf  vmovaps xmm1, [rsp+0x30]
00007bdc0b3d64d5  vmovaps xmm15, [rsp+0x30]
00007bdc0b3d64db  por xmm1, xmm15
00007bdc0b3d64e0  movaps [r15+0x210], xmm1
00007bdc0b3d64e8  vmovaps xmm15, [rsp+0x70]
00007bdc0b3d64ee  vmovaps xmm14, [rsp+0x70]
00007bdc0b3d64f4  por xmm15, xmm14
00007bdc0b3d64f9  movaps [r15+0x1C0], xmm15
00007bdc0b3d6501  vmovaps xmm14, [rsp+0x60]
00007bdc0b3d6507  vmovaps xmm13, [rsp+0x60]
00007bdc0b3d650d  por xmm14, xmm13
00007bdc0b3d6512  movaps [r15+0x280], xmm14
00007bdc0b3d651a  vmovaps xmm13, [rsp+0x50]
00007bdc0b3d6520  vmovaps [rsp+0x30], xmm1
00007bdc0b3d6526  vmovaps xmm1, [rsp+0x50]
00007bdc0b3d652c  por xmm13, xmm1
00007bdc0b3d6531  movaps [r15+0x2A0], xmm13
00007bdc0b3d6539  vmovaps [rsp+0x50], xmm2
00007bdc0b3d653f  vmovaps xmm1, [rsp+0x50]
00007bdc0b3d6545  por xmm2, xmm1
00007bdc0b3d6549  movaps [r15+0x2E0], xmm2
00007bdc0b3d6551  vmovaps [rsp+0x50], xmm3
00007bdc0b3d6557  vmovaps xmm1, [rsp+0x50]
00007bdc0b3d655d  por xmm3, xmm1
00007bdc0b3d6561  movaps [r15+0x1F0], xmm3
00007bdc0b3d6569  vmovaps xmm1, [rsp+0x80]
00007bdc0b3d6572  vmovaps [rsp+0x50], xmm15
00007bdc0b3d6578  vmovaps xmm15, [rsp+0x80]
00007bdc0b3d6581  por xmm1, xmm15
00007bdc0b3d6586  movaps [r15+0x250], xmm1
00007bdc0b3d658e  vmovaps xmm1, [rsp+0xC0]
00007bdc0b3d6597  vmovaps xmm15, [rsp+0xC0]
00007bdc0b3d65a0  por xmm1, xmm15
00007bdc0b3d65a5  movaps [r15+0x260], xmm1
00007bdc0b3d65ad  vmovaps xmm15, [rsp+0x100]
00007bdc0b3d65b6  vmovaps [rsp+0x60], xmm1
00007bdc0b3d65bc  vmovaps xmm1, [rsp+0x100]
00007bdc0b3d65c5  por xmm15, xmm1
00007bdc0b3d65ca  movaps [r15+0x290], xmm15
00007bdc0b3d65d2  vmovaps xmm1, [rsp+0xF0]
00007bdc0b3d65db  vmovaps [rsp+0x70], xmm15
00007bdc0b3d65e1  vmovaps xmm15, [rsp+0xF0]
00007bdc0b3d65ea  por xmm1, xmm15
00007bdc0b3d65ef  movaps [r15+0x2C0], xmm1
00007bdc0b3d65f7  movq xmm15, qword ptr [r15+0x240]
00007bdc0b3d6600  vmovaps [rsp+0x80], xmm15
00007bdc0b3d6609  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d660f  vmovaps [rsp+0xC0], xmm1
00007bdc0b3d6618  vmovaps xmm1, [rsp+0x40]
00007bdc0b3d661e  vmovaps [rsp+0x40], xmm15
00007bdc0b3d6624  vmovaps xmm15, [rsp+0x30]
00007bdc0b3d662a  vmovaps [rsp+0x30], xmm14
00007bdc0b3d6630  vmovaps xmm14, [rsp+0x40]
00007bdc0b3d6636  vmovaps [rsp+0x40], xmm13
00007bdc0b3d663c  vmovaps [rsp+0xD0], xmm12
00007bdc0b3d6645  movaps xmm13, xmm1
00007bdc0b3d6649  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d6654  vptest xmm12, xmm12
00007bdc0b3d6659  jnz 0x00007BDC0B3D7314
00007bdc0b3d665f  vmovaps xmm1, [rsp+0x80]
00007bdc0b3d6668  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d666e  vmovaps xmm15, [rsp+0xA0]
00007bdc0b3d6677  movaps xmm14, xmm15
00007bdc0b3d667b  vfmadd231pd xmm14, xmm2, xmm1
00007bdc0b3d6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007bdc0b3d6686  vptest xmm12, xmm12
00007bdc0b3d668b  jnz 0x00007BDC0B3D746D
00007bdc0b3d6691  vmovaps xmm1, [rsp+0x80]
00007bdc0b3d669a  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d66a0  vmovaps xmm15, [rsp+0x120]
00007bdc0b3d66a9  vmovaps xmm12, [rsp+0x50]
00007bdc0b3d66af  vmovaps [rsp+0x50], xmm14
00007bdc0b3d66b5  movaps xmm2, xmm15
00007bdc0b3d66b9  vfmadd231pd xmm2, xmm12, xmm1
00007bdc0b3d66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007bdc0b3d66c3  vptest xmm14, xmm14
00007bdc0b3d66c8  jnz 0x00007BDC0B3D75C5
00007bdc0b3d66ce  vmovaps xmm1, [rsp+0x110]
00007bdc0b3d66d7  vmovaps xmm15, [rsp+0x110]
00007bdc0b3d66e0  por xmm1, xmm15
00007bdc0b3d66e5  movaps [r15+0x1D0], xmm1
00007bdc0b3d66ed  vmovaps xmm15, [rsp+0x80]
00007bdc0b3d66f6  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d66fc  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d6705  vmovaps [rsp+0x80], xmm1
00007bdc0b3d670e  movaps xmm12, xmm14
00007bdc0b3d6712  vfmadd231pd xmm12, xmm3, xmm15
00007bdc0b3d6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007bdc0b3d671d  vptest xmm1, xmm1
00007bdc0b3d6722  jnz 0x00007BDC0B3D771C
00007bdc0b3d6728  vmovaps [rsp+0xA0], xmm4
00007bdc0b3d6731  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3d673a  por xmm4, xmm1
00007bdc0b3d673e  movaps [r15+0x200], xmm4
00007bdc0b3d6746  vmovaps xmm1, [rsp+0xE0]
00007bdc0b3d674f  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d6758  por xmm1, xmm15
00007bdc0b3d675d  movaps [r15+0x1E0], xmm1
00007bdc0b3d6765  vmovaps [rsp+0xA0], xmm8
00007bdc0b3d676e  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3d6777  por xmm8, xmm1
00007bdc0b3d677c  movaps [r15+0x2B0], xmm8
00007bdc0b3d6784  vmovaps [rsp+0xA0], xmm9
00007bdc0b3d678d  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3d6796  por xmm9, xmm1
00007bdc0b3d679b  movaps [r15+0x300], xmm9
00007bdc0b3d67a3  vmovaps [rsp+0xA0], xmm6
00007bdc0b3d67ac  vpermilpd xmm6, xmm6, 0x00
00007bdc0b3d67b2  vmovaps xmm14, [rsp+0x60]
00007bdc0b3d67b8  movaps xmm9, xmm13
00007bdc0b3d67bc  vfmadd231pd xmm9, xmm14, xmm6
00007bdc0b3d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007bdc0b3d67c7  vptest xmm3, xmm3
00007bdc0b3d67cc  jnz 0x00007BDC0B3D7875
00007bdc0b3d67d2  vmovaps xmm14, [rsp+0xA0]
00007bdc0b3d67db  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3d67e1  vmovaps xmm13, [rsp+0x50]
00007bdc0b3d67e7  vmovaps xmm6, [rsp+0xC0]
00007bdc0b3d67f0  vmovaps [rsp+0x50], xmm1
00007bdc0b3d67f6  movaps xmm3, xmm13
00007bdc0b3d67fa  vfmadd231pd xmm3, xmm6, xmm14
00007bdc0b3d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007bdc0b3d6804  vptest xmm1, xmm1
00007bdc0b3d6809  jnz 0x00007BDC0B3D79CE
00007bdc0b3d680f  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3d6818  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d681e  vmovaps xmm14, [rsp+0x30]
00007bdc0b3d6824  movaps xmm6, xmm2
00007bdc0b3d6827  vfmadd231pd xmm6, xmm14, xmm1
00007bdc0b3d682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007bdc0b3d6831  vptest xmm13, xmm13
00007bdc0b3d6836  jnz 0x00007BDC0B3D7B25
00007bdc0b3d683c  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3d6845  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d684b  vmovaps xmm14, [rsp+0x80]
00007bdc0b3d6854  movaps xmm13, xmm12
00007bdc0b3d6858  vfmadd231pd xmm13, xmm14, xmm1
00007bdc0b3d685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007bdc0b3d6863  vptest xmm2, xmm2
00007bdc0b3d6868  jnz 0x00007BDC0B3D7C7B
00007bdc0b3d686e  vmovaps [rsp+0x30], xmm7
00007bdc0b3d6874  vmovaps xmm1, [rsp+0x30]
00007bdc0b3d687a  por xmm7, xmm1
00007bdc0b3d687e  movaps [r15+0x180], xmm7
00007bdc0b3d6886  vmovaps [rsp+0x30], xmm10
00007bdc0b3d688c  vmovaps xmm1, [rsp+0x30]
00007bdc0b3d6892  por xmm10, xmm1
00007bdc0b3d6897  movaps [r15+0x2D0], xmm10
00007bdc0b3d689f  vmovaps [rsp+0x30], xmm5
00007bdc0b3d68a5  vpermilpd xmm5, xmm5, 0x00
00007bdc0b3d68ab  vmovaps xmm14, [rsp+0x50]
00007bdc0b3d68b1  movaps xmm12, xmm3
00007bdc0b3d68b5  vfmadd231pd xmm12, xmm14, xmm5
00007bdc0b3d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007bdc0b3d68c0  vptest xmm10, xmm10
00007bdc0b3d68c5  jnz 0x00007BDC0B3D7DD4
00007bdc0b3d68cb  vmovaps xmm14, [rsp+0x30]
00007bdc0b3d68d1  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3d68d7  movaps xmm10, xmm9
00007bdc0b3d68db  vfmadd231pd xmm10, xmm7, xmm14
00007bdc0b3d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007bdc0b3d68e6  vptest xmm5, xmm5
00007bdc0b3d68eb  jnz 0x00007BDC0B3D7F2C
00007bdc0b3d68f1  lea r14, [rax+0x80]
00007bdc0b3d68f8  movups xmm14, [r13+r14*1]
00007bdc0b3d68fe  movaps [r15+0x2F0], xmm14
00007bdc0b3d6906  vmovaps xmm9, [rsp+0x30]
00007bdc0b3d690c  vpermilpd xmm9, xmm9, 0x00
00007bdc0b3d6912  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d6918  movaps xmm5, xmm6
00007bdc0b3d691b  vfmadd231pd xmm5, xmm7, xmm9
00007bdc0b3d6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007bdc0b3d6925  vptest xmm3, xmm3
00007bdc0b3d692a  jnz 0x00007BDC0B3D808F
00007bdc0b3d6930  vmovaps xmm9, [rsp+0x30]
00007bdc0b3d6936  vpermilpd xmm9, xmm9, 0x00
00007bdc0b3d693c  movaps xmm7, xmm13
00007bdc0b3d6940  vfmadd231pd xmm7, xmm1, xmm9
00007bdc0b3d6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007bdc0b3d694a  vptest xmm6, xmm6
00007bdc0b3d694f  jnz 0x00007BDC0B3D81E5
00007bdc0b3d6955  vmovaps xmm1, [rsp+0x20]
00007bdc0b3d695b  vmovaps xmm13, [rsp+0x20]
00007bdc0b3d6961  por xmm1, xmm13
00007bdc0b3d6966  movaps [r15+0x160], xmm1
00007bdc0b3d696e  lea r14, [rax+0x40]
00007bdc0b3d6972  movups xmm13, [r13+r14*1]
00007bdc0b3d6978  lea r14, [rax+0x50]
00007bdc0b3d697c  movups xmm9, [r13+r14*1]
00007bdc0b3d6982  movaps [r15+0x1B0], xmm13
00007bdc0b3d698a  movaps [r15+0x1A0], xmm9
00007bdc0b3d6992  movaps xmm6, [r15+0x190]
00007bdc0b3d699a  vmovaps xmm3, [rsp+0xB0]
00007bdc0b3d69a3  vpermilpd xmm3, xmm3, 0x00
00007bdc0b3d69a9  vmovaps [rsp+0x20], xmm1
00007bdc0b3d69af  movaps xmm2, xmm12
00007bdc0b3d69b3  vfmadd231pd xmm2, xmm6, xmm3
00007bdc0b3d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007bdc0b3d69bd  vptest xmm1, xmm1
00007bdc0b3d69c2  jnz 0x00007BDC0B3D8350
00007bdc0b3d69c8  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d69d1  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d69d7  vmovaps xmm12, [rsp+0x20]
00007bdc0b3d69dd  movaps xmm6, xmm10
00007bdc0b3d69e1  vfmadd231pd xmm6, xmm12, xmm1
00007bdc0b3d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007bdc0b3d69eb  vptest xmm3, xmm3
00007bdc0b3d69f0  jnz 0x00007BDC0B3D84A6
00007bdc0b3d69f6  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d69ff  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d6a05  vmovaps xmm12, [rsp+0x40]
00007bdc0b3d6a0b  movaps xmm10, xmm5
00007bdc0b3d6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007bdc0b3d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007bdc0b3d6a1a  vptest xmm3, xmm3
00007bdc0b3d6a1f  jnz 0x00007BDC0B3D85FD
00007bdc0b3d6a25  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3d6a2e  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d6a34  movaps xmm12, xmm7
00007bdc0b3d6a38  vfmadd231pd xmm12, xmm15, xmm1
00007bdc0b3d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007bdc0b3d6a43  vptest xmm5, xmm5
00007bdc0b3d6a48  jnz 0x00007BDC0B3D8755
00007bdc0b3d6a4e  lea r14, [rax+0x60]
00007bdc0b3d6a52  movups xmm1, [r13+r14*1]
00007bdc0b3d6a58  lea r14, [rax+0x70]
00007bdc0b3d6a5c  movups xmm15, [r13+r14*1]
00007bdc0b3d6a62  movaps [r15+0x150], xmm1
00007bdc0b3d6a6a  movaps [r15+0x120], xmm15
00007bdc0b3d6a72  vmovaps [rsp+0x20], xmm11
00007bdc0b3d6a78  vpermilpd xmm11, xmm11, 0x00
00007bdc0b3d6a7e  movaps xmm7, xmm2
00007bdc0b3d6a81  vfmadd231pd xmm7, xmm9, xmm11
00007bdc0b3d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007bdc0b3d6a8b  vptest xmm5, xmm5
00007bdc0b3d6a90  jnz 0x00007BDC0B3D88C1
00007bdc0b3d6a96  vmovaps xmm11, [rsp+0x20]
00007bdc0b3d6a9c  vpermilpd xmm11, xmm11, 0x00
00007bdc0b3d6aa2  movaps xmm9, xmm6
00007bdc0b3d6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007bdc0b3d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007bdc0b3d6ab1  vptest xmm5, xmm5
00007bdc0b3d6ab6  jnz 0x00007BDC0B3D8A18
00007bdc0b3d6abc  vmovaps xmm1, [rsp+0x20]
00007bdc0b3d6ac2  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d6ac8  movaps xmm11, xmm10
00007bdc0b3d6acc  vfmadd231pd xmm11, xmm8, xmm1
00007bdc0b3d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007bdc0b3d6ad7  vptest xmm6, xmm6
00007bdc0b3d6adc  jnz 0x00007BDC0B3D8B70
00007bdc0b3d6ae2  vmovaps xmm1, [rsp+0x20]
00007bdc0b3d6ae8  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d6aee  movaps xmm10, xmm12
00007bdc0b3d6af2  vfmadd231pd xmm10, xmm13, xmm1
00007bdc0b3d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007bdc0b3d6afd  vptest xmm8, xmm8
00007bdc0b3d6b02  jnz 0x00007BDC0B3D8CC9
00007bdc0b3d6b08  lea r14, [rax+0x20]
00007bdc0b3d6b0c  movups xmm1, [r13+r14*1]
00007bdc0b3d6b12  lea r14, [rax+0x30]
00007bdc0b3d6b16  movups xmm13, [r13+r14*1]
00007bdc0b3d6b1c  vmovaps xmm12, [rsp+0x90]
00007bdc0b3d6b25  vpermilpd xmm12, xmm12, 0x00
00007bdc0b3d6b2b  movaps xmm8, xmm7
00007bdc0b3d6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007bdc0b3d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007bdc0b3d6b3a  vptest xmm6, xmm6
00007bdc0b3d6b3f  jnz 0x00007BDC0B3D8E36
00007bdc0b3d6b45  vmovaps xmm12, [rsp+0x90]
00007bdc0b3d6b4e  vpermilpd xmm12, xmm12, 0x00
00007bdc0b3d6b54  movaps xmm7, xmm9
00007bdc0b3d6b58  vfmadd231pd xmm7, xmm14, xmm12
00007bdc0b3d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007bdc0b3d6b62  vptest xmm6, xmm6
00007bdc0b3d6b67  jnz 0x00007BDC0B3D8F8E
00007bdc0b3d6b6d  vmovaps xmm14, [rsp+0x90]
00007bdc0b3d6b76  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3d6b7c  movaps xmm12, xmm11
00007bdc0b3d6b80  vfmadd231pd xmm12, xmm15, xmm14
00007bdc0b3d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007bdc0b3d6b8b  vptest xmm9, xmm9
00007bdc0b3d6b90  jnz 0x00007BDC0B3D90E6
00007bdc0b3d6b96  vmovaps xmm15, [rsp+0x90]
00007bdc0b3d6b9f  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d6ba5  movaps xmm11, xmm10
00007bdc0b3d6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007bdc0b3d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007bdc0b3d6bb4  vptest xmm14, xmm14
00007bdc0b3d6bb9  jnz 0x00007BDC0B3D9240
00007bdc0b3d6bbf  lea r14, [rax+0x90]
00007bdc0b3d6bc6  movups xmm15, [r13+r14*1]
00007bdc0b3d6bcc  lea r14, [rax+0xA0]
00007bdc0b3d6bd3  movups xmm14, [r13+r14*1]
00007bdc0b3d6bd9  movaps [r15+0x140], xmm15
00007bdc0b3d6be1  movaps [r15+0x130], xmm14
00007bdc0b3d6be9  vmovaps xmm13, [rsp+0x10]
00007bdc0b3d6bef  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3d6bf5  movaps xmm10, xmm8
00007bdc0b3d6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007bdc0b3d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007bdc0b3d6c04  vptest xmm9, xmm9
00007bdc0b3d6c09  jnz 0x00007BDC0B3D93AE
00007bdc0b3d6c0f  movaps [r15+0x220], xmm10
00007bdc0b3d6c17  lea r14, [rax+0x10]
00007bdc0b3d6c1b  movups xmm1, [r13+r14*1]
00007bdc0b3d6c21  movaps [r15+0x240], xmm1
00007bdc0b3d6c29  vmovaps xmm13, [rsp+0x10]
00007bdc0b3d6c2f  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3d6c35  movaps xmm9, xmm7
00007bdc0b3d6c39  vfmadd231pd xmm9, xmm14, xmm13
00007bdc0b3d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007bdc0b3d6c44  vptest xmm8, xmm8
00007bdc0b3d6c49  jnz 0x00007BDC0B3D9511
00007bdc0b3d6c4f  movaps [r15+0x110], xmm9
00007bdc0b3d6c57  vmovaps xmm14, [rsp+0x10]
00007bdc0b3d6c5d  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3d6c63  movaps xmm13, xmm12
00007bdc0b3d6c67  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007bdc0b3d6c72  vptest xmm8, xmm8
00007bdc0b3d6c77  jnz 0x00007BDC0B3D966A
00007bdc0b3d6c7d  movaps [r15+0x170], xmm13
00007bdc0b3d6c85  vmovaps xmm15, [rsp+0x10]
00007bdc0b3d6c8b  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d6c91  movaps xmm14, xmm11
00007bdc0b3d6c95  vfmadd231pd xmm14, xmm1, xmm15
00007bdc0b3d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007bdc0b3d6ca0  vptest xmm12, xmm12
00007bdc0b3d6ca5  jnz 0x00007BDC0B3D97C4
00007bdc0b3d6cab  movaps [r15+0x230], xmm14
00007bdc0b3d6cb3  movups [r13+r11*1], xmm9
00007bdc0b3d6cb9  lea rax, [r11+0x10]
00007bdc0b3d6cbd  movups [r13+rax*1], xmm13
00007bdc0b3d6cc3  lea rax, [r11+0x20]
00007bdc0b3d6cc7  movups [r13+rax*1], xmm10
00007bdc0b3d6ccd  lea rax, [r11+0x30]
00007bdc0b3d6cd1  movups [r13+rax*1], xmm14
00007bdc0b3d6cd7  mov eax, [r15+0x108]
00007bdc0b3d6cde  sahf
00007bdc0b3d6cdf  jnz 0x00007BDC0B3D6D11
00007bdc0b3d6ce1  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d6ce9  jz 0x00007BDC0B3D9950
00007bdc0b3d6cef  nop [rax+rax*1], ax
00007bdc0b3d6cf8  nop [rax+rax*1], eax
00007bdc0b3d6d00  mov eax, 0x410664
00007bdc0b3d6d05  mov [r15+0x100], rax
00007bdc0b3d6d0c  jmp 0x00007BDC0B1FE110
00007bdc0b3d6d11  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d6d19  jz 0x00007BDC0B3D6050
00007bdc0b3d6d1f  nop [rax+rax*1], ax
00007bdc0b3d6d28  nop [rax+rax*1], eax
00007bdc0b3d6d30  mov eax, 0x4104F0
00007bdc0b3d6d35  mov [r15+0x100], rax
00007bdc0b3d6d3c  jmp 0x00007BDC0B1FE110
00007bdc0b3d6d41  int3
00007bdc0b3d6d42  call 0x00007BDC0B20A4B0
00007bdc0b3d6d47  jmp 0x00007BDC0B3D6079
00007bdc0b3d6d4c  call 0x00007BDC0B209240
00007bdc0b3d6d51  jmp 0x00007BDC0B3D6083
00007bdc0b3d6d56  call 0x00007BDC0B20A4B0
00007bdc0b3d6d5b  jmp 0x00007BDC0B3D60CD
00007bdc0b3d6d60  call 0x00007BDC0B209240
00007bdc0b3d6d65  jmp 0x00007BDC0B3D60D7
00007bdc0b3d6d6a  call 0x00007BDC0B20A4B0
00007bdc0b3d6d6f  jmp 0x00007BDC0B3D6158
00007bdc0b3d6d74  call 0x00007BDC0B209240
00007bdc0b3d6d79  jmp 0x00007BDC0B3D6162
00007bdc0b3d6d7e  call 0x00007BDC0B2B47C0
00007bdc0b3d6d83  jmp 0x00007BDC0B3D6243
00007bdc0b3d6d88  call 0x00007BDC0B1FF430
00007bdc0b3d6d8d  jmp 0x00007BDC0B3D6272
00007bdc0b3d6d92  call 0x00007BDC0B2B0CE0
00007bdc0b3d6d97  jmp 0x00007BDC0B3D628E
00007bdc0b3d6d9c  sub rsp, 0x08
00007bdc0b3d6da0  push rax
00007bdc0b3d6da1  push rcx
00007bdc0b3d6da2  push rdx
00007bdc0b3d6da3  push rdi
00007bdc0b3d6da4  push rsi
00007bdc0b3d6da5  push r8
00007bdc0b3d6da7  push r9
00007bdc0b3d6da9  push r10
00007bdc0b3d6dab  push r11
00007bdc0b3d6dad  sub rsp, 0xF0
00007bdc0b3d6db4  vmovaps [rsp], xmm0
00007bdc0b3d6db9  vmovaps [rsp+0x10], xmm1
00007bdc0b3d6dbf  vmovaps [rsp+0x20], xmm2
00007bdc0b3d6dc5  vmovaps [rsp+0x30], xmm3
00007bdc0b3d6dcb  vmovaps [rsp+0x40], xmm4
00007bdc0b3d6dd1  vmovaps [rsp+0x50], xmm5
00007bdc0b3d6dd7  vmovaps [rsp+0x60], xmm6
00007bdc0b3d6ddd  vmovaps [rsp+0x70], xmm7
00007bdc0b3d6de3  vmovaps [rsp+0x80], xmm8
00007bdc0b3d6dec  vmovaps [rsp+0x90], xmm9
00007bdc0b3d6df5  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d6dfe  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d6e07  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d6e10  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d6e19  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d6e22  sub rsp, 0x40
00007bdc0b3d6e26  lea rdi, [rsp]
00007bdc0b3d6e2a  lea rsi, [rsp+0x10]
00007bdc0b3d6e2f  lea rdx, [rsp+0x20]
00007bdc0b3d6e34  lea rcx, [rsp+0x30]
00007bdc0b3d6e39  mov r8d, 0x00
00007bdc0b3d6e3f  lea r9, [r15+0x3A8]
00007bdc0b3d6e46  movaps [rdi], xmm13
00007bdc0b3d6e4a  movaps [rsi], xmm1
00007bdc0b3d6e4d  movaps [rdx], xmm15
00007bdc0b3d6e51  movaps [rcx], xmm14
00007bdc0b3d6e55  mov rax, 0x62CE440F2A50
00007bdc0b3d6e5f  call rax
00007bdc0b3d6e61  movaps xmm13, [rsp]
00007bdc0b3d6e66  add rsp, 0x40
00007bdc0b3d6e6a  vmovaps xmm0, [rsp]
00007bdc0b3d6e6f  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d6e75  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d6e7b  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d6e81  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d6e87  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d6e8d  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d6e93  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d6e99  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d6ea2  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d6eab  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d6eb4  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d6ebd  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d6ec6  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d6ecf  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d6ed8  add rsp, 0xF0
00007bdc0b3d6edf  pop r11
00007bdc0b3d6ee1  pop r10
00007bdc0b3d6ee3  pop r9
00007bdc0b3d6ee5  pop r8
00007bdc0b3d6ee7  pop rsi
00007bdc0b3d6ee8  pop rdi
00007bdc0b3d6ee9  pop rdx
00007bdc0b3d6eea  pop rcx
00007bdc0b3d6eeb  pop rax
00007bdc0b3d6eec  add rsp, 0x08
00007bdc0b3d6ef0  jmp 0x00007BDC0B3D6305
00007bdc0b3d6ef5  sub rsp, 0x08
00007bdc0b3d6ef9  push rax
00007bdc0b3d6efa  push rcx
00007bdc0b3d6efb  push rdx
00007bdc0b3d6efc  push rdi
00007bdc0b3d6efd  push rsi
00007bdc0b3d6efe  push r8
00007bdc0b3d6f00  push r9
00007bdc0b3d6f02  push r10
00007bdc0b3d6f04  push r11
00007bdc0b3d6f06  sub rsp, 0xF0
00007bdc0b3d6f0d  vmovaps [rsp], xmm0
00007bdc0b3d6f12  vmovaps [rsp+0x10], xmm1
00007bdc0b3d6f18  vmovaps [rsp+0x20], xmm2
00007bdc0b3d6f1e  vmovaps [rsp+0x30], xmm3
00007bdc0b3d6f24  vmovaps [rsp+0x40], xmm4
00007bdc0b3d6f2a  vmovaps [rsp+0x50], xmm5
00007bdc0b3d6f30  vmovaps [rsp+0x60], xmm6
00007bdc0b3d6f36  vmovaps [rsp+0x70], xmm7
00007bdc0b3d6f3c  vmovaps [rsp+0x80], xmm8
00007bdc0b3d6f45  vmovaps [rsp+0x90], xmm9
00007bdc0b3d6f4e  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d6f57  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d6f60  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d6f69  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d6f72  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d6f7b  sub rsp, 0x40
00007bdc0b3d6f7f  lea rdi, [rsp]
00007bdc0b3d6f83  lea rsi, [rsp+0x10]
00007bdc0b3d6f88  lea rdx, [rsp+0x20]
00007bdc0b3d6f8d  lea rcx, [rsp+0x30]
00007bdc0b3d6f92  mov r8d, 0x00
00007bdc0b3d6f98  lea r9, [r15+0x3A8]
00007bdc0b3d6f9f  movaps [rdi], xmm12
00007bdc0b3d6fa3  movaps [rsi], xmm15
00007bdc0b3d6fa7  movaps [rdx], xmm1
00007bdc0b3d6faa  movaps [rcx], xmm14
00007bdc0b3d6fae  mov rax, 0x62CE440F2A50
00007bdc0b3d6fb8  call rax
00007bdc0b3d6fba  movaps xmm12, [rsp]
00007bdc0b3d6fbf  add rsp, 0x40
00007bdc0b3d6fc3  vmovaps xmm0, [rsp]
00007bdc0b3d6fc8  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d6fce  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d6fd4  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d6fda  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d6fe0  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d6fe6  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d6fec  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d6ff2  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d6ffb  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d7004  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d700d  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d7016  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d701f  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d7028  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d7031  add rsp, 0xF0
00007bdc0b3d7038  pop r11
00007bdc0b3d703a  pop r10
00007bdc0b3d703c  pop r9
00007bdc0b3d703e  pop r8
00007bdc0b3d7040  pop rsi
00007bdc0b3d7041  pop rdi
00007bdc0b3d7042  pop rdx
00007bdc0b3d7043  pop rcx
00007bdc0b3d7044  pop rax
00007bdc0b3d7045  add rsp, 0x08
00007bdc0b3d7049  jmp 0x00007BDC0B3D6333
00007bdc0b3d704e  call 0x00007BDC0B2D64F0
00007bdc0b3d7053  jmp 0x00007BDC0B3D641F
00007bdc0b3d7058  sub rsp, 0x08
00007bdc0b3d705c  push rax
00007bdc0b3d705d  push rcx
00007bdc0b3d705e  push rdx
00007bdc0b3d705f  push rdi
00007bdc0b3d7060  push rsi
00007bdc0b3d7061  push r8
00007bdc0b3d7063  push r9
00007bdc0b3d7065  push r10
00007bdc0b3d7067  push r11
00007bdc0b3d7069  sub rsp, 0xF0
00007bdc0b3d7070  vmovaps [rsp], xmm0
00007bdc0b3d7075  vmovaps [rsp+0x10], xmm1
00007bdc0b3d707b  vmovaps [rsp+0x20], xmm2
00007bdc0b3d7081  vmovaps [rsp+0x30], xmm3
00007bdc0b3d7087  vmovaps [rsp+0x40], xmm4
00007bdc0b3d708d  vmovaps [rsp+0x50], xmm5
00007bdc0b3d7093  vmovaps [rsp+0x60], xmm6
00007bdc0b3d7099  vmovaps [rsp+0x70], xmm7
00007bdc0b3d709f  vmovaps [rsp+0x80], xmm8
00007bdc0b3d70a8  vmovaps [rsp+0x90], xmm9
00007bdc0b3d70b1  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d70ba  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d70c3  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d70cc  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d70d5  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d70de  sub rsp, 0x40
00007bdc0b3d70e2  lea rdi, [rsp]
00007bdc0b3d70e6  lea rsi, [rsp+0x10]
00007bdc0b3d70eb  lea rdx, [rsp+0x20]
00007bdc0b3d70f0  lea rcx, [rsp+0x30]
00007bdc0b3d70f5  mov r8d, 0x00
00007bdc0b3d70fb  lea r9, [r15+0x3A8]
00007bdc0b3d7102  movaps [rdi], xmm13
00007bdc0b3d7106  movaps [rsi], xmm1
00007bdc0b3d7109  movaps [rdx], xmm15
00007bdc0b3d710d  movaps [rcx], xmm14
00007bdc0b3d7111  mov rax, 0x62CE440F2A50
00007bdc0b3d711b  call rax
00007bdc0b3d711d  movaps xmm13, [rsp]
00007bdc0b3d7122  add rsp, 0x40
00007bdc0b3d7126  vmovaps xmm0, [rsp]
00007bdc0b3d712b  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d7131  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d7137  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d713d  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d7143  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d7149  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d714f  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d7155  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d715e  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d7167  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d7170  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d7179  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d7182  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d718b  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d7194  add rsp, 0xF0
00007bdc0b3d719b  pop r11
00007bdc0b3d719d  pop r10
00007bdc0b3d719f  pop r9
00007bdc0b3d71a1  pop r8
00007bdc0b3d71a3  pop rsi
00007bdc0b3d71a4  pop rdi
00007bdc0b3d71a5  pop rdx
00007bdc0b3d71a6  pop rcx
00007bdc0b3d71a7  pop rax
00007bdc0b3d71a8  add rsp, 0x08
00007bdc0b3d71ac  jmp 0x00007BDC0B3D648E
00007bdc0b3d71b1  call 0x00007BDC0B2D64F0
00007bdc0b3d71b6  jmp 0x00007BDC0B3D64A3
00007bdc0b3d71bb  sub rsp, 0x08
00007bdc0b3d71bf  push rax
00007bdc0b3d71c0  push rcx
00007bdc0b3d71c1  push rdx
00007bdc0b3d71c2  push rdi
00007bdc0b3d71c3  push rsi
00007bdc0b3d71c4  push r8
00007bdc0b3d71c6  push r9
00007bdc0b3d71c8  push r10
00007bdc0b3d71ca  push r11
00007bdc0b3d71cc  sub rsp, 0xF0
00007bdc0b3d71d3  vmovaps [rsp], xmm0
00007bdc0b3d71d8  vmovaps [rsp+0x10], xmm1
00007bdc0b3d71de  vmovaps [rsp+0x20], xmm2
00007bdc0b3d71e4  vmovaps [rsp+0x30], xmm3
00007bdc0b3d71ea  vmovaps [rsp+0x40], xmm4
00007bdc0b3d71f0  vmovaps [rsp+0x50], xmm5
00007bdc0b3d71f6  vmovaps [rsp+0x60], xmm6
00007bdc0b3d71fc  vmovaps [rsp+0x70], xmm7
00007bdc0b3d7202  vmovaps [rsp+0x80], xmm8
00007bdc0b3d720b  vmovaps [rsp+0x90], xmm9
00007bdc0b3d7214  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d721d  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d7226  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d722f  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d7238  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d7241  sub rsp, 0x40
00007bdc0b3d7245  lea rdi, [rsp]
00007bdc0b3d7249  lea rsi, [rsp+0x10]
00007bdc0b3d724e  lea rdx, [rsp+0x20]
00007bdc0b3d7253  lea rcx, [rsp+0x30]
00007bdc0b3d7258  mov r8d, 0x00
00007bdc0b3d725e  lea r9, [r15+0x3A8]
00007bdc0b3d7265  movaps [rdi], xmm12
00007bdc0b3d7269  movaps [rsi], xmm15
00007bdc0b3d726d  movaps [rdx], xmm1
00007bdc0b3d7270  movaps [rcx], xmm14
00007bdc0b3d7274  mov rax, 0x62CE440F2A50
00007bdc0b3d727e  call rax
00007bdc0b3d7280  movaps xmm12, [rsp]
00007bdc0b3d7285  add rsp, 0x40
00007bdc0b3d7289  vmovaps xmm0, [rsp]
00007bdc0b3d728e  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d7294  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d729a  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d72a0  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d72a6  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d72ac  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d72b2  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d72b8  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d72c1  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d72ca  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d72d3  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d72dc  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d72e5  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d72ee  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d72f7  add rsp, 0xF0
00007bdc0b3d72fe  pop r11
00007bdc0b3d7300  pop r10
00007bdc0b3d7302  pop r9
00007bdc0b3d7304  pop r8
00007bdc0b3d7306  pop rsi
00007bdc0b3d7307  pop rdi
00007bdc0b3d7308  pop rdx
00007bdc0b3d7309  pop rcx
00007bdc0b3d730a  pop rax
00007bdc0b3d730b  add rsp, 0x08
00007bdc0b3d730f  jmp 0x00007BDC0B3D64CF
00007bdc0b3d7314  sub rsp, 0x08
00007bdc0b3d7318  push rax
00007bdc0b3d7319  push rcx
00007bdc0b3d731a  push rdx
00007bdc0b3d731b  push rdi
00007bdc0b3d731c  push rsi
00007bdc0b3d731d  push r8
00007bdc0b3d731f  push r9
00007bdc0b3d7321  push r10
00007bdc0b3d7323  push r11
00007bdc0b3d7325  sub rsp, 0xF0
00007bdc0b3d732c  vmovaps [rsp], xmm0
00007bdc0b3d7331  vmovaps [rsp+0x10], xmm1
00007bdc0b3d7337  vmovaps [rsp+0x20], xmm2
00007bdc0b3d733d  vmovaps [rsp+0x30], xmm3
00007bdc0b3d7343  vmovaps [rsp+0x40], xmm4
00007bdc0b3d7349  vmovaps [rsp+0x50], xmm5
00007bdc0b3d734f  vmovaps [rsp+0x60], xmm6
00007bdc0b3d7355  vmovaps [rsp+0x70], xmm7
00007bdc0b3d735b  vmovaps [rsp+0x80], xmm8
00007bdc0b3d7364  vmovaps [rsp+0x90], xmm9
00007bdc0b3d736d  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d7376  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d737f  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d7388  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d7391  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d739a  sub rsp, 0x40
00007bdc0b3d739e  lea rdi, [rsp]
00007bdc0b3d73a2  lea rsi, [rsp+0x10]
00007bdc0b3d73a7  lea rdx, [rsp+0x20]
00007bdc0b3d73ac  lea rcx, [rsp+0x30]
00007bdc0b3d73b1  mov r8d, 0x00
00007bdc0b3d73b7  lea r9, [r15+0x3A8]
00007bdc0b3d73be  movaps [rdi], xmm13
00007bdc0b3d73c2  movaps [rsi], xmm1
00007bdc0b3d73c5  movaps [rdx], xmm15
00007bdc0b3d73c9  movaps [rcx], xmm14
00007bdc0b3d73cd  mov rax, 0x62CE440F2A50
00007bdc0b3d73d7  call rax
00007bdc0b3d73d9  movaps xmm13, [rsp]
00007bdc0b3d73de  add rsp, 0x40
00007bdc0b3d73e2  vmovaps xmm0, [rsp]
00007bdc0b3d73e7  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d73ed  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d73f3  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d73f9  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d73ff  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d7405  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d740b  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d7411  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d741a  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d7423  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d742c  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d7435  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d743e  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d7447  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d7450  add rsp, 0xF0
00007bdc0b3d7457  pop r11
00007bdc0b3d7459  pop r10
00007bdc0b3d745b  pop r9
00007bdc0b3d745d  pop r8
00007bdc0b3d745f  pop rsi
00007bdc0b3d7460  pop rdi
00007bdc0b3d7461  pop rdx
00007bdc0b3d7462  pop rcx
00007bdc0b3d7463  pop rax
00007bdc0b3d7464  add rsp, 0x08
00007bdc0b3d7468  jmp 0x00007BDC0B3D665F
00007bdc0b3d746d  sub rsp, 0x08
00007bdc0b3d7471  push rax
00007bdc0b3d7472  push rcx
00007bdc0b3d7473  push rdx
00007bdc0b3d7474  push rdi
00007bdc0b3d7475  push rsi
00007bdc0b3d7476  push r8
00007bdc0b3d7478  push r9
00007bdc0b3d747a  push r10
00007bdc0b3d747c  push r11
00007bdc0b3d747e  sub rsp, 0xF0
00007bdc0b3d7485  vmovaps [rsp], xmm0
00007bdc0b3d748a  vmovaps [rsp+0x10], xmm1
00007bdc0b3d7490  vmovaps [rsp+0x20], xmm2
00007bdc0b3d7496  vmovaps [rsp+0x30], xmm3
00007bdc0b3d749c  vmovaps [rsp+0x40], xmm4
00007bdc0b3d74a2  vmovaps [rsp+0x50], xmm5
00007bdc0b3d74a8  vmovaps [rsp+0x60], xmm6
00007bdc0b3d74ae  vmovaps [rsp+0x70], xmm7
00007bdc0b3d74b4  vmovaps [rsp+0x80], xmm8
00007bdc0b3d74bd  vmovaps [rsp+0x90], xmm9
00007bdc0b3d74c6  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d74cf  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d74d8  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d74e1  vmovaps [rsp+0xD0], xmm13
00007bdc0b3d74ea  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d74f3  sub rsp, 0x40
00007bdc0b3d74f7  lea rdi, [rsp]
00007bdc0b3d74fb  lea rsi, [rsp+0x10]
00007bdc0b3d7500  lea rdx, [rsp+0x20]
00007bdc0b3d7505  lea rcx, [rsp+0x30]
00007bdc0b3d750a  mov r8d, 0x00
00007bdc0b3d7510  lea r9, [r15+0x3A8]
00007bdc0b3d7517  movaps [rdi], xmm14
00007bdc0b3d751b  movaps [rsi], xmm15
00007bdc0b3d751f  movaps [rdx], xmm2
00007bdc0b3d7522  movaps [rcx], xmm1
00007bdc0b3d7525  mov rax, 0x62CE440F2A50
00007bdc0b3d752f  call rax
00007bdc0b3d7531  movaps xmm14, [rsp]
00007bdc0b3d7536  add rsp, 0x40
00007bdc0b3d753a  vmovaps xmm0, [rsp]
00007bdc0b3d753f  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d7545  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d754b  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d7551  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d7557  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d755d  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d7563  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d7569  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d7572  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d757b  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d7584  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d758d  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d7596  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3d759f  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d75a8  add rsp, 0xF0
00007bdc0b3d75af  pop r11
00007bdc0b3d75b1  pop r10
00007bdc0b3d75b3  pop r9
00007bdc0b3d75b5  pop r8
00007bdc0b3d75b7  pop rsi
00007bdc0b3d75b8  pop rdi
00007bdc0b3d75b9  pop rdx
00007bdc0b3d75ba  pop rcx
00007bdc0b3d75bb  pop rax
00007bdc0b3d75bc  add rsp, 0x08
00007bdc0b3d75c0  jmp 0x00007BDC0B3D6691
00007bdc0b3d75c5  sub rsp, 0x08
00007bdc0b3d75c9  push rax
00007bdc0b3d75ca  push rcx
00007bdc0b3d75cb  push rdx
00007bdc0b3d75cc  push rdi
00007bdc0b3d75cd  push rsi
00007bdc0b3d75ce  push r8
00007bdc0b3d75d0  push r9
00007bdc0b3d75d2  push r10
00007bdc0b3d75d4  push r11
00007bdc0b3d75d6  sub rsp, 0xF0
00007bdc0b3d75dd  vmovaps [rsp], xmm0
00007bdc0b3d75e2  vmovaps [rsp+0x10], xmm1
00007bdc0b3d75e8  vmovaps [rsp+0x20], xmm3
00007bdc0b3d75ee  vmovaps [rsp+0x30], xmm4
00007bdc0b3d75f4  vmovaps [rsp+0x40], xmm5
00007bdc0b3d75fa  vmovaps [rsp+0x50], xmm6
00007bdc0b3d7600  vmovaps [rsp+0x60], xmm7
00007bdc0b3d7606  vmovaps [rsp+0x70], xmm8
00007bdc0b3d760c  vmovaps [rsp+0x80], xmm9
00007bdc0b3d7615  vmovaps [rsp+0x90], xmm10
00007bdc0b3d761e  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d7627  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d7630  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d7639  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d7642  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d764b  sub rsp, 0x40
00007bdc0b3d764f  lea rdi, [rsp]
00007bdc0b3d7653  lea rsi, [rsp+0x10]
00007bdc0b3d7658  lea rdx, [rsp+0x20]
00007bdc0b3d765d  lea rcx, [rsp+0x30]
00007bdc0b3d7662  mov r8d, 0x00
00007bdc0b3d7668  lea r9, [r15+0x3A8]
00007bdc0b3d766f  movaps [rdi], xmm2
00007bdc0b3d7672  movaps [rsi], xmm15
00007bdc0b3d7676  movaps [rdx], xmm12
00007bdc0b3d767a  movaps [rcx], xmm1
00007bdc0b3d767d  mov rax, 0x62CE440F2A50
00007bdc0b3d7687  call rax
00007bdc0b3d7689  movaps xmm2, [rsp]
00007bdc0b3d768d  add rsp, 0x40
00007bdc0b3d7691  vmovaps xmm0, [rsp]
00007bdc0b3d7696  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d769c  vmovaps xmm3, [rsp+0x20]
00007bdc0b3d76a2  vmovaps xmm4, [rsp+0x30]
00007bdc0b3d76a8  vmovaps xmm5, [rsp+0x40]
00007bdc0b3d76ae  vmovaps xmm6, [rsp+0x50]
00007bdc0b3d76b4  vmovaps xmm7, [rsp+0x60]
00007bdc0b3d76ba  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d76c0  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d76c9  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d76d2  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d76db  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d76e4  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d76ed  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d76f6  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d76ff  add rsp, 0xF0
00007bdc0b3d7706  pop r11
00007bdc0b3d7708  pop r10
00007bdc0b3d770a  pop r9
00007bdc0b3d770c  pop r8
00007bdc0b3d770e  pop rsi
00007bdc0b3d770f  pop rdi
00007bdc0b3d7710  pop rdx
00007bdc0b3d7711  pop rcx
00007bdc0b3d7712  pop rax
00007bdc0b3d7713  add rsp, 0x08
00007bdc0b3d7717  jmp 0x00007BDC0B3D66CE
00007bdc0b3d771c  sub rsp, 0x08
00007bdc0b3d7720  push rax
00007bdc0b3d7721  push rcx
00007bdc0b3d7722  push rdx
00007bdc0b3d7723  push rdi
00007bdc0b3d7724  push rsi
00007bdc0b3d7725  push r8
00007bdc0b3d7727  push r9
00007bdc0b3d7729  push r10
00007bdc0b3d772b  push r11
00007bdc0b3d772d  sub rsp, 0xF0
00007bdc0b3d7734  vmovaps [rsp], xmm0
00007bdc0b3d7739  vmovaps [rsp+0x10], xmm1
00007bdc0b3d773f  vmovaps [rsp+0x20], xmm2
00007bdc0b3d7745  vmovaps [rsp+0x30], xmm3
00007bdc0b3d774b  vmovaps [rsp+0x40], xmm4
00007bdc0b3d7751  vmovaps [rsp+0x50], xmm5
00007bdc0b3d7757  vmovaps [rsp+0x60], xmm6
00007bdc0b3d775d  vmovaps [rsp+0x70], xmm7
00007bdc0b3d7763  vmovaps [rsp+0x80], xmm8
00007bdc0b3d776c  vmovaps [rsp+0x90], xmm9
00007bdc0b3d7775  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d777e  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d7787  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d7790  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d7799  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d77a2  sub rsp, 0x40
00007bdc0b3d77a6  lea rdi, [rsp]
00007bdc0b3d77aa  lea rsi, [rsp+0x10]
00007bdc0b3d77af  lea rdx, [rsp+0x20]
00007bdc0b3d77b4  lea rcx, [rsp+0x30]
00007bdc0b3d77b9  mov r8d, 0x00
00007bdc0b3d77bf  lea r9, [r15+0x3A8]
00007bdc0b3d77c6  movaps [rdi], xmm12
00007bdc0b3d77ca  movaps [rsi], xmm14
00007bdc0b3d77ce  movaps [rdx], xmm3
00007bdc0b3d77d1  movaps [rcx], xmm15
00007bdc0b3d77d5  mov rax, 0x62CE440F2A50
00007bdc0b3d77df  call rax
00007bdc0b3d77e1  movaps xmm12, [rsp]
00007bdc0b3d77e6  add rsp, 0x40
00007bdc0b3d77ea  vmovaps xmm0, [rsp]
00007bdc0b3d77ef  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d77f5  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d77fb  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d7801  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d7807  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d780d  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d7813  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d7819  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d7822  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d782b  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d7834  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d783d  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d7846  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d784f  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d7858  add rsp, 0xF0
00007bdc0b3d785f  pop r11
00007bdc0b3d7861  pop r10
00007bdc0b3d7863  pop r9
00007bdc0b3d7865  pop r8
00007bdc0b3d7867  pop rsi
00007bdc0b3d7868  pop rdi
00007bdc0b3d7869  pop rdx
00007bdc0b3d786a  pop rcx
00007bdc0b3d786b  pop rax
00007bdc0b3d786c  add rsp, 0x08
00007bdc0b3d7870  jmp 0x00007BDC0B3D6728
00007bdc0b3d7875  sub rsp, 0x08
00007bdc0b3d7879  push rax
00007bdc0b3d787a  push rcx
00007bdc0b3d787b  push rdx
00007bdc0b3d787c  push rdi
00007bdc0b3d787d  push rsi
00007bdc0b3d787e  push r8
00007bdc0b3d7880  push r9
00007bdc0b3d7882  push r10
00007bdc0b3d7884  push r11
00007bdc0b3d7886  sub rsp, 0xF0
00007bdc0b3d788d  vmovaps [rsp], xmm0
00007bdc0b3d7892  vmovaps [rsp+0x10], xmm1
00007bdc0b3d7898  vmovaps [rsp+0x20], xmm2
00007bdc0b3d789e  vmovaps [rsp+0x30], xmm3
00007bdc0b3d78a4  vmovaps [rsp+0x40], xmm4
00007bdc0b3d78aa  vmovaps [rsp+0x50], xmm5
00007bdc0b3d78b0  vmovaps [rsp+0x60], xmm6
00007bdc0b3d78b6  vmovaps [rsp+0x70], xmm7
00007bdc0b3d78bc  vmovaps [rsp+0x80], xmm8
00007bdc0b3d78c5  vmovaps [rsp+0x90], xmm10
00007bdc0b3d78ce  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d78d7  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d78e0  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d78e9  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d78f2  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d78fb  sub rsp, 0x40
00007bdc0b3d78ff  lea rdi, [rsp]
00007bdc0b3d7903  lea rsi, [rsp+0x10]
00007bdc0b3d7908  lea rdx, [rsp+0x20]
00007bdc0b3d790d  lea rcx, [rsp+0x30]
00007bdc0b3d7912  mov r8d, 0x00
00007bdc0b3d7918  lea r9, [r15+0x3A8]
00007bdc0b3d791f  movaps [rdi], xmm9
00007bdc0b3d7923  movaps [rsi], xmm13
00007bdc0b3d7927  movaps [rdx], xmm14
00007bdc0b3d792b  movaps [rcx], xmm6
00007bdc0b3d792e  mov rax, 0x62CE440F2A50
00007bdc0b3d7938  call rax
00007bdc0b3d793a  movaps xmm9, [rsp]
00007bdc0b3d793f  add rsp, 0x40
00007bdc0b3d7943  vmovaps xmm0, [rsp]
00007bdc0b3d7948  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d794e  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d7954  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d795a  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d7960  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d7966  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d796c  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d7972  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d797b  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d7984  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d798d  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d7996  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d799f  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d79a8  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d79b1  add rsp, 0xF0
00007bdc0b3d79b8  pop r11
00007bdc0b3d79ba  pop r10
00007bdc0b3d79bc  pop r9
00007bdc0b3d79be  pop r8
00007bdc0b3d79c0  pop rsi
00007bdc0b3d79c1  pop rdi
00007bdc0b3d79c2  pop rdx
00007bdc0b3d79c3  pop rcx
00007bdc0b3d79c4  pop rax
00007bdc0b3d79c5  add rsp, 0x08
00007bdc0b3d79c9  jmp 0x00007BDC0B3D67D2
00007bdc0b3d79ce  sub rsp, 0x08
00007bdc0b3d79d2  push rax
00007bdc0b3d79d3  push rcx
00007bdc0b3d79d4  push rdx
00007bdc0b3d79d5  push rdi
00007bdc0b3d79d6  push rsi
00007bdc0b3d79d7  push r8
00007bdc0b3d79d9  push r9
00007bdc0b3d79db  push r10
00007bdc0b3d79dd  push r11
00007bdc0b3d79df  sub rsp, 0xF0
00007bdc0b3d79e6  vmovaps [rsp], xmm0
00007bdc0b3d79eb  vmovaps [rsp+0x10], xmm1
00007bdc0b3d79f1  vmovaps [rsp+0x20], xmm2
00007bdc0b3d79f7  vmovaps [rsp+0x30], xmm4
00007bdc0b3d79fd  vmovaps [rsp+0x40], xmm5
00007bdc0b3d7a03  vmovaps [rsp+0x50], xmm6
00007bdc0b3d7a09  vmovaps [rsp+0x60], xmm7
00007bdc0b3d7a0f  vmovaps [rsp+0x70], xmm8
00007bdc0b3d7a15  vmovaps [rsp+0x80], xmm9
00007bdc0b3d7a1e  vmovaps [rsp+0x90], xmm10
00007bdc0b3d7a27  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d7a30  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d7a39  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d7a42  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d7a4b  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d7a54  sub rsp, 0x40
00007bdc0b3d7a58  lea rdi, [rsp]
00007bdc0b3d7a5c  lea rsi, [rsp+0x10]
00007bdc0b3d7a61  lea rdx, [rsp+0x20]
00007bdc0b3d7a66  lea rcx, [rsp+0x30]
00007bdc0b3d7a6b  mov r8d, 0x00
00007bdc0b3d7a71  lea r9, [r15+0x3A8]
00007bdc0b3d7a78  movaps [rdi], xmm3
00007bdc0b3d7a7b  movaps [rsi], xmm13
00007bdc0b3d7a7f  movaps [rdx], xmm6
00007bdc0b3d7a82  movaps [rcx], xmm14
00007bdc0b3d7a86  mov rax, 0x62CE440F2A50
00007bdc0b3d7a90  call rax
00007bdc0b3d7a92  movaps xmm3, [rsp]
00007bdc0b3d7a96  add rsp, 0x40
00007bdc0b3d7a9a  vmovaps xmm0, [rsp]
00007bdc0b3d7a9f  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d7aa5  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d7aab  vmovaps xmm4, [rsp+0x30]
00007bdc0b3d7ab1  vmovaps xmm5, [rsp+0x40]
00007bdc0b3d7ab7  vmovaps xmm6, [rsp+0x50]
00007bdc0b3d7abd  vmovaps xmm7, [rsp+0x60]
00007bdc0b3d7ac3  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d7ac9  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d7ad2  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d7adb  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d7ae4  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d7aed  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d7af6  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d7aff  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d7b08  add rsp, 0xF0
00007bdc0b3d7b0f  pop r11
00007bdc0b3d7b11  pop r10
00007bdc0b3d7b13  pop r9
00007bdc0b3d7b15  pop r8
00007bdc0b3d7b17  pop rsi
00007bdc0b3d7b18  pop rdi
00007bdc0b3d7b19  pop rdx
00007bdc0b3d7b1a  pop rcx
00007bdc0b3d7b1b  pop rax
00007bdc0b3d7b1c  add rsp, 0x08
00007bdc0b3d7b20  jmp 0x00007BDC0B3D680F
00007bdc0b3d7b25  sub rsp, 0x08
00007bdc0b3d7b29  push rax
00007bdc0b3d7b2a  push rcx
00007bdc0b3d7b2b  push rdx
00007bdc0b3d7b2c  push rdi
00007bdc0b3d7b2d  push rsi
00007bdc0b3d7b2e  push r8
00007bdc0b3d7b30  push r9
00007bdc0b3d7b32  push r10
00007bdc0b3d7b34  push r11
00007bdc0b3d7b36  sub rsp, 0xF0
00007bdc0b3d7b3d  vmovaps [rsp], xmm0
00007bdc0b3d7b42  vmovaps [rsp+0x10], xmm1
00007bdc0b3d7b48  vmovaps [rsp+0x20], xmm2
00007bdc0b3d7b4e  vmovaps [rsp+0x30], xmm3
00007bdc0b3d7b54  vmovaps [rsp+0x40], xmm4
00007bdc0b3d7b5a  vmovaps [rsp+0x50], xmm5
00007bdc0b3d7b60  vmovaps [rsp+0x60], xmm7
00007bdc0b3d7b66  vmovaps [rsp+0x70], xmm8
00007bdc0b3d7b6c  vmovaps [rsp+0x80], xmm9
00007bdc0b3d7b75  vmovaps [rsp+0x90], xmm10
00007bdc0b3d7b7e  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d7b87  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d7b90  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d7b99  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d7ba2  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d7bab  sub rsp, 0x40
00007bdc0b3d7baf  lea rdi, [rsp]
00007bdc0b3d7bb3  lea rsi, [rsp+0x10]
00007bdc0b3d7bb8  lea rdx, [rsp+0x20]
00007bdc0b3d7bbd  lea rcx, [rsp+0x30]
00007bdc0b3d7bc2  mov r8d, 0x00
00007bdc0b3d7bc8  lea r9, [r15+0x3A8]
00007bdc0b3d7bcf  movaps [rdi], xmm6
00007bdc0b3d7bd2  movaps [rsi], xmm2
00007bdc0b3d7bd5  movaps [rdx], xmm14
00007bdc0b3d7bd9  movaps [rcx], xmm1
00007bdc0b3d7bdc  mov rax, 0x62CE440F2A50
00007bdc0b3d7be6  call rax
00007bdc0b3d7be8  movaps xmm6, [rsp]
00007bdc0b3d7bec  add rsp, 0x40
00007bdc0b3d7bf0  vmovaps xmm0, [rsp]
00007bdc0b3d7bf5  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d7bfb  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d7c01  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d7c07  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d7c0d  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d7c13  vmovaps xmm7, [rsp+0x60]
00007bdc0b3d7c19  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d7c1f  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d7c28  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d7c31  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d7c3a  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d7c43  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d7c4c  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d7c55  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d7c5e  add rsp, 0xF0
00007bdc0b3d7c65  pop r11
00007bdc0b3d7c67  pop r10
00007bdc0b3d7c69  pop r9
00007bdc0b3d7c6b  pop r8
00007bdc0b3d7c6d  pop rsi
00007bdc0b3d7c6e  pop rdi
00007bdc0b3d7c6f  pop rdx
00007bdc0b3d7c70  pop rcx
00007bdc0b3d7c71  pop rax
00007bdc0b3d7c72  add rsp, 0x08
00007bdc0b3d7c76  jmp 0x00007BDC0B3D683C
00007bdc0b3d7c7b  sub rsp, 0x08
00007bdc0b3d7c7f  push rax
00007bdc0b3d7c80  push rcx
00007bdc0b3d7c81  push rdx
00007bdc0b3d7c82  push rdi
00007bdc0b3d7c83  push rsi
00007bdc0b3d7c84  push r8
00007bdc0b3d7c86  push r9
00007bdc0b3d7c88  push r10
00007bdc0b3d7c8a  push r11
00007bdc0b3d7c8c  sub rsp, 0xF0
00007bdc0b3d7c93  vmovaps [rsp], xmm0
00007bdc0b3d7c98  vmovaps [rsp+0x10], xmm1
00007bdc0b3d7c9e  vmovaps [rsp+0x20], xmm2
00007bdc0b3d7ca4  vmovaps [rsp+0x30], xmm3
00007bdc0b3d7caa  vmovaps [rsp+0x40], xmm4
00007bdc0b3d7cb0  vmovaps [rsp+0x50], xmm5
00007bdc0b3d7cb6  vmovaps [rsp+0x60], xmm6
00007bdc0b3d7cbc  vmovaps [rsp+0x70], xmm7
00007bdc0b3d7cc2  vmovaps [rsp+0x80], xmm8
00007bdc0b3d7ccb  vmovaps [rsp+0x90], xmm9
00007bdc0b3d7cd4  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d7cdd  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d7ce6  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d7cef  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d7cf8  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d7d01  sub rsp, 0x40
00007bdc0b3d7d05  lea rdi, [rsp]
00007bdc0b3d7d09  lea rsi, [rsp+0x10]
00007bdc0b3d7d0e  lea rdx, [rsp+0x20]
00007bdc0b3d7d13  lea rcx, [rsp+0x30]
00007bdc0b3d7d18  mov r8d, 0x00
00007bdc0b3d7d1e  lea r9, [r15+0x3A8]
00007bdc0b3d7d25  movaps [rdi], xmm13
00007bdc0b3d7d29  movaps [rsi], xmm12
00007bdc0b3d7d2d  movaps [rdx], xmm14
00007bdc0b3d7d31  movaps [rcx], xmm1
00007bdc0b3d7d34  mov rax, 0x62CE440F2A50
00007bdc0b3d7d3e  call rax
00007bdc0b3d7d40  movaps xmm13, [rsp]
00007bdc0b3d7d45  add rsp, 0x40
00007bdc0b3d7d49  vmovaps xmm0, [rsp]
00007bdc0b3d7d4e  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d7d54  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d7d5a  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d7d60  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d7d66  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d7d6c  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d7d72  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d7d78  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d7d81  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d7d8a  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d7d93  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d7d9c  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d7da5  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d7dae  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d7db7  add rsp, 0xF0
00007bdc0b3d7dbe  pop r11
00007bdc0b3d7dc0  pop r10
00007bdc0b3d7dc2  pop r9
00007bdc0b3d7dc4  pop r8
00007bdc0b3d7dc6  pop rsi
00007bdc0b3d7dc7  pop rdi
00007bdc0b3d7dc8  pop rdx
00007bdc0b3d7dc9  pop rcx
00007bdc0b3d7dca  pop rax
00007bdc0b3d7dcb  add rsp, 0x08
00007bdc0b3d7dcf  jmp 0x00007BDC0B3D686E
00007bdc0b3d7dd4  sub rsp, 0x08
00007bdc0b3d7dd8  push rax
00007bdc0b3d7dd9  push rcx
00007bdc0b3d7dda  push rdx
00007bdc0b3d7ddb  push rdi
00007bdc0b3d7ddc  push rsi
00007bdc0b3d7ddd  push r8
00007bdc0b3d7ddf  push r9
00007bdc0b3d7de1  push r10
00007bdc0b3d7de3  push r11
00007bdc0b3d7de5  sub rsp, 0xF0
00007bdc0b3d7dec  vmovaps [rsp], xmm0
00007bdc0b3d7df1  vmovaps [rsp+0x10], xmm1
00007bdc0b3d7df7  vmovaps [rsp+0x20], xmm2
00007bdc0b3d7dfd  vmovaps [rsp+0x30], xmm3
00007bdc0b3d7e03  vmovaps [rsp+0x40], xmm4
00007bdc0b3d7e09  vmovaps [rsp+0x50], xmm5
00007bdc0b3d7e0f  vmovaps [rsp+0x60], xmm6
00007bdc0b3d7e15  vmovaps [rsp+0x70], xmm7
00007bdc0b3d7e1b  vmovaps [rsp+0x80], xmm8
00007bdc0b3d7e24  vmovaps [rsp+0x90], xmm9
00007bdc0b3d7e2d  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d7e36  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d7e3f  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d7e48  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d7e51  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d7e5a  sub rsp, 0x40
00007bdc0b3d7e5e  lea rdi, [rsp]
00007bdc0b3d7e62  lea rsi, [rsp+0x10]
00007bdc0b3d7e67  lea rdx, [rsp+0x20]
00007bdc0b3d7e6c  lea rcx, [rsp+0x30]
00007bdc0b3d7e71  mov r8d, 0x00
00007bdc0b3d7e77  lea r9, [r15+0x3A8]
00007bdc0b3d7e7e  movaps [rdi], xmm12
00007bdc0b3d7e82  movaps [rsi], xmm3
00007bdc0b3d7e85  movaps [rdx], xmm14
00007bdc0b3d7e89  movaps [rcx], xmm5
00007bdc0b3d7e8c  mov rax, 0x62CE440F2A50
00007bdc0b3d7e96  call rax
00007bdc0b3d7e98  movaps xmm12, [rsp]
00007bdc0b3d7e9d  add rsp, 0x40
00007bdc0b3d7ea1  vmovaps xmm0, [rsp]
00007bdc0b3d7ea6  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d7eac  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d7eb2  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d7eb8  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d7ebe  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d7ec4  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d7eca  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d7ed0  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d7ed9  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d7ee2  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d7eeb  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d7ef4  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d7efd  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d7f06  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d7f0f  add rsp, 0xF0
00007bdc0b3d7f16  pop r11
00007bdc0b3d7f18  pop r10
00007bdc0b3d7f1a  pop r9
00007bdc0b3d7f1c  pop r8
00007bdc0b3d7f1e  pop rsi
00007bdc0b3d7f1f  pop rdi
00007bdc0b3d7f20  pop rdx
00007bdc0b3d7f21  pop rcx
00007bdc0b3d7f22  pop rax
00007bdc0b3d7f23  add rsp, 0x08
00007bdc0b3d7f27  jmp 0x00007BDC0B3D68CB
00007bdc0b3d7f2c  sub rsp, 0x08
00007bdc0b3d7f30  push rax
00007bdc0b3d7f31  push rcx
00007bdc0b3d7f32  push rdx
00007bdc0b3d7f33  push rdi
00007bdc0b3d7f34  push rsi
00007bdc0b3d7f35  push r8
00007bdc0b3d7f37  push r9
00007bdc0b3d7f39  push r10
00007bdc0b3d7f3b  push r11
00007bdc0b3d7f3d  sub rsp, 0xF0
00007bdc0b3d7f44  vmovaps [rsp], xmm0
00007bdc0b3d7f49  vmovaps [rsp+0x10], xmm1
00007bdc0b3d7f4f  vmovaps [rsp+0x20], xmm2
00007bdc0b3d7f55  vmovaps [rsp+0x30], xmm3
00007bdc0b3d7f5b  vmovaps [rsp+0x40], xmm4
00007bdc0b3d7f61  vmovaps [rsp+0x50], xmm5
00007bdc0b3d7f67  vmovaps [rsp+0x60], xmm6
00007bdc0b3d7f6d  vmovaps [rsp+0x70], xmm7
00007bdc0b3d7f73  vmovaps [rsp+0x80], xmm8
00007bdc0b3d7f7c  vmovaps [rsp+0x90], xmm9
00007bdc0b3d7f85  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d7f8e  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d7f97  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d7fa0  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d7fa9  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d7fb2  sub rsp, 0x40
00007bdc0b3d7fb6  lea rdi, [rsp]
00007bdc0b3d7fba  lea rsi, [rsp+0x10]
00007bdc0b3d7fbf  lea rdx, [rsp+0x20]
00007bdc0b3d7fc4  lea rcx, [rsp+0x30]
00007bdc0b3d7fc9  mov r8d, 0x00
00007bdc0b3d7fcf  lea r9, [r15+0x3A8]
00007bdc0b3d7fd6  movaps [rdi], xmm10
00007bdc0b3d7fda  movaps [rsi], xmm9
00007bdc0b3d7fde  movaps [rdx], xmm7
00007bdc0b3d7fe1  movaps [rcx], xmm14
00007bdc0b3d7fe5  mov rax, 0x62CE440F2A50
00007bdc0b3d7fef  call rax
00007bdc0b3d7ff1  movaps xmm10, [rsp]
00007bdc0b3d7ff6  add rsp, 0x40
00007bdc0b3d7ffa  vmovaps xmm0, [rsp]
00007bdc0b3d7fff  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d8005  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d800b  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d8011  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d8017  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d801d  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d8023  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d8029  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d8032  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d803b  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d8044  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d804d  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d8056  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d805f  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d8068  add rsp, 0xF0
00007bdc0b3d806f  pop r11
00007bdc0b3d8071  pop r10
00007bdc0b3d8073  pop r9
00007bdc0b3d8075  pop r8
00007bdc0b3d8077  pop rsi
00007bdc0b3d8078  pop rdi
00007bdc0b3d8079  pop rdx
00007bdc0b3d807a  pop rcx
00007bdc0b3d807b  pop rax
00007bdc0b3d807c  add rsp, 0x08
00007bdc0b3d8080  jmp 0x00007BDC0B3D68F1
00007bdc0b3d8085  call 0x00007BDC0B2E45A0
00007bdc0b3d808a  jmp 0x00007BDC0B3D68FE
00007bdc0b3d808f  sub rsp, 0x08
00007bdc0b3d8093  push rax
00007bdc0b3d8094  push rcx
00007bdc0b3d8095  push rdx
00007bdc0b3d8096  push rdi
00007bdc0b3d8097  push rsi
00007bdc0b3d8098  push r8
00007bdc0b3d809a  push r9
00007bdc0b3d809c  push r10
00007bdc0b3d809e  push r11
00007bdc0b3d80a0  sub rsp, 0xF0
00007bdc0b3d80a7  vmovaps [rsp], xmm0
00007bdc0b3d80ac  vmovaps [rsp+0x10], xmm1
00007bdc0b3d80b2  vmovaps [rsp+0x20], xmm2
00007bdc0b3d80b8  vmovaps [rsp+0x30], xmm3
00007bdc0b3d80be  vmovaps [rsp+0x40], xmm4
00007bdc0b3d80c4  vmovaps [rsp+0x50], xmm6
00007bdc0b3d80ca  vmovaps [rsp+0x60], xmm7
00007bdc0b3d80d0  vmovaps [rsp+0x70], xmm8
00007bdc0b3d80d6  vmovaps [rsp+0x80], xmm9
00007bdc0b3d80df  vmovaps [rsp+0x90], xmm10
00007bdc0b3d80e8  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d80f1  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d80fa  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d8103  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d810c  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d8115  sub rsp, 0x40
00007bdc0b3d8119  lea rdi, [rsp]
00007bdc0b3d811d  lea rsi, [rsp+0x10]
00007bdc0b3d8122  lea rdx, [rsp+0x20]
00007bdc0b3d8127  lea rcx, [rsp+0x30]
00007bdc0b3d812c  mov r8d, 0x00
00007bdc0b3d8132  lea r9, [r15+0x3A8]
00007bdc0b3d8139  movaps [rdi], xmm5
00007bdc0b3d813c  movaps [rsi], xmm6
00007bdc0b3d813f  movaps [rdx], xmm7
00007bdc0b3d8142  movaps [rcx], xmm9
00007bdc0b3d8146  mov rax, 0x62CE440F2A50
00007bdc0b3d8150  call rax
00007bdc0b3d8152  movaps xmm5, [rsp]
00007bdc0b3d8156  add rsp, 0x40
00007bdc0b3d815a  vmovaps xmm0, [rsp]
00007bdc0b3d815f  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d8165  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d816b  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d8171  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d8177  vmovaps xmm6, [rsp+0x50]
00007bdc0b3d817d  vmovaps xmm7, [rsp+0x60]
00007bdc0b3d8183  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d8189  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d8192  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d819b  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d81a4  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d81ad  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d81b6  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d81bf  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d81c8  add rsp, 0xF0
00007bdc0b3d81cf  pop r11
00007bdc0b3d81d1  pop r10
00007bdc0b3d81d3  pop r9
00007bdc0b3d81d5  pop r8
00007bdc0b3d81d7  pop rsi
00007bdc0b3d81d8  pop rdi
00007bdc0b3d81d9  pop rdx
00007bdc0b3d81da  pop rcx
00007bdc0b3d81db  pop rax
00007bdc0b3d81dc  add rsp, 0x08
00007bdc0b3d81e0  jmp 0x00007BDC0B3D6930
00007bdc0b3d81e5  sub rsp, 0x08
00007bdc0b3d81e9  push rax
00007bdc0b3d81ea  push rcx
00007bdc0b3d81eb  push rdx
00007bdc0b3d81ec  push rdi
00007bdc0b3d81ed  push rsi
00007bdc0b3d81ee  push r8
00007bdc0b3d81f0  push r9
00007bdc0b3d81f2  push r10
00007bdc0b3d81f4  push r11
00007bdc0b3d81f6  sub rsp, 0xF0
00007bdc0b3d81fd  vmovaps [rsp], xmm0
00007bdc0b3d8202  vmovaps [rsp+0x10], xmm1
00007bdc0b3d8208  vmovaps [rsp+0x20], xmm2
00007bdc0b3d820e  vmovaps [rsp+0x30], xmm3
00007bdc0b3d8214  vmovaps [rsp+0x40], xmm4
00007bdc0b3d821a  vmovaps [rsp+0x50], xmm5
00007bdc0b3d8220  vmovaps [rsp+0x60], xmm6
00007bdc0b3d8226  vmovaps [rsp+0x70], xmm8
00007bdc0b3d822c  vmovaps [rsp+0x80], xmm9
00007bdc0b3d8235  vmovaps [rsp+0x90], xmm10
00007bdc0b3d823e  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d8247  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d8250  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d8259  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d8262  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d826b  sub rsp, 0x40
00007bdc0b3d826f  lea rdi, [rsp]
00007bdc0b3d8273  lea rsi, [rsp+0x10]
00007bdc0b3d8278  lea rdx, [rsp+0x20]
00007bdc0b3d827d  lea rcx, [rsp+0x30]
00007bdc0b3d8282  mov r8d, 0x00
00007bdc0b3d8288  lea r9, [r15+0x3A8]
00007bdc0b3d828f  movaps [rdi], xmm7
00007bdc0b3d8292  movaps [rsi], xmm13
00007bdc0b3d8296  movaps [rdx], xmm1
00007bdc0b3d8299  movaps [rcx], xmm9
00007bdc0b3d829d  mov rax, 0x62CE440F2A50
00007bdc0b3d82a7  call rax
00007bdc0b3d82a9  movaps xmm7, [rsp]
00007bdc0b3d82ad  add rsp, 0x40
00007bdc0b3d82b1  vmovaps xmm0, [rsp]
00007bdc0b3d82b6  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d82bc  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d82c2  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d82c8  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d82ce  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d82d4  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d82da  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d82e0  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d82e9  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d82f2  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d82fb  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d8304  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d830d  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d8316  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d831f  add rsp, 0xF0
00007bdc0b3d8326  pop r11
00007bdc0b3d8328  pop r10
00007bdc0b3d832a  pop r9
00007bdc0b3d832c  pop r8
00007bdc0b3d832e  pop rsi
00007bdc0b3d832f  pop rdi
00007bdc0b3d8330  pop rdx
00007bdc0b3d8331  pop rcx
00007bdc0b3d8332  pop rax
00007bdc0b3d8333  add rsp, 0x08
00007bdc0b3d8337  jmp 0x00007BDC0B3D6955
00007bdc0b3d833c  call 0x00007BDC0B2E3320
00007bdc0b3d8341  jmp 0x00007BDC0B3D6978
00007bdc0b3d8346  call 0x00007BDC0B2DE950
00007bdc0b3d834b  jmp 0x00007BDC0B3D6982
00007bdc0b3d8350  sub rsp, 0x08
00007bdc0b3d8354  push rax
00007bdc0b3d8355  push rcx
00007bdc0b3d8356  push rdx
00007bdc0b3d8357  push rdi
00007bdc0b3d8358  push rsi
00007bdc0b3d8359  push r8
00007bdc0b3d835b  push r9
00007bdc0b3d835d  push r10
00007bdc0b3d835f  push r11
00007bdc0b3d8361  sub rsp, 0xF0
00007bdc0b3d8368  vmovaps [rsp], xmm0
00007bdc0b3d836d  vmovaps [rsp+0x10], xmm1
00007bdc0b3d8373  vmovaps [rsp+0x20], xmm3
00007bdc0b3d8379  vmovaps [rsp+0x30], xmm4
00007bdc0b3d837f  vmovaps [rsp+0x40], xmm5
00007bdc0b3d8385  vmovaps [rsp+0x50], xmm6
00007bdc0b3d838b  vmovaps [rsp+0x60], xmm7
00007bdc0b3d8391  vmovaps [rsp+0x70], xmm8
00007bdc0b3d8397  vmovaps [rsp+0x80], xmm9
00007bdc0b3d83a0  vmovaps [rsp+0x90], xmm10
00007bdc0b3d83a9  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d83b2  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d83bb  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d83c4  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d83cd  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d83d6  sub rsp, 0x40
00007bdc0b3d83da  lea rdi, [rsp]
00007bdc0b3d83de  lea rsi, [rsp+0x10]
00007bdc0b3d83e3  lea rdx, [rsp+0x20]
00007bdc0b3d83e8  lea rcx, [rsp+0x30]
00007bdc0b3d83ed  mov r8d, 0x00
00007bdc0b3d83f3  lea r9, [r15+0x3A8]
00007bdc0b3d83fa  movaps [rdi], xmm2
00007bdc0b3d83fd  movaps [rsi], xmm12
00007bdc0b3d8401  movaps [rdx], xmm6
00007bdc0b3d8404  movaps [rcx], xmm3
00007bdc0b3d8407  mov rax, 0x62CE440F2A50
00007bdc0b3d8411  call rax
00007bdc0b3d8413  movaps xmm2, [rsp]
00007bdc0b3d8417  add rsp, 0x40
00007bdc0b3d841b  vmovaps xmm0, [rsp]
00007bdc0b3d8420  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d8426  vmovaps xmm3, [rsp+0x20]
00007bdc0b3d842c  vmovaps xmm4, [rsp+0x30]
00007bdc0b3d8432  vmovaps xmm5, [rsp+0x40]
00007bdc0b3d8438  vmovaps xmm6, [rsp+0x50]
00007bdc0b3d843e  vmovaps xmm7, [rsp+0x60]
00007bdc0b3d8444  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d844a  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d8453  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d845c  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d8465  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d846e  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d8477  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d8480  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d8489  add rsp, 0xF0
00007bdc0b3d8490  pop r11
00007bdc0b3d8492  pop r10
00007bdc0b3d8494  pop r9
00007bdc0b3d8496  pop r8
00007bdc0b3d8498  pop rsi
00007bdc0b3d8499  pop rdi
00007bdc0b3d849a  pop rdx
00007bdc0b3d849b  pop rcx
00007bdc0b3d849c  pop rax
00007bdc0b3d849d  add rsp, 0x08
00007bdc0b3d84a1  jmp 0x00007BDC0B3D69C8
00007bdc0b3d84a6  sub rsp, 0x08
00007bdc0b3d84aa  push rax
00007bdc0b3d84ab  push rcx
00007bdc0b3d84ac  push rdx
00007bdc0b3d84ad  push rdi
00007bdc0b3d84ae  push rsi
00007bdc0b3d84af  push r8
00007bdc0b3d84b1  push r9
00007bdc0b3d84b3  push r10
00007bdc0b3d84b5  push r11
00007bdc0b3d84b7  sub rsp, 0xF0
00007bdc0b3d84be  vmovaps [rsp], xmm0
00007bdc0b3d84c3  vmovaps [rsp+0x10], xmm1
00007bdc0b3d84c9  vmovaps [rsp+0x20], xmm2
00007bdc0b3d84cf  vmovaps [rsp+0x30], xmm3
00007bdc0b3d84d5  vmovaps [rsp+0x40], xmm4
00007bdc0b3d84db  vmovaps [rsp+0x50], xmm5
00007bdc0b3d84e1  vmovaps [rsp+0x60], xmm7
00007bdc0b3d84e7  vmovaps [rsp+0x70], xmm8
00007bdc0b3d84ed  vmovaps [rsp+0x80], xmm9
00007bdc0b3d84f6  vmovaps [rsp+0x90], xmm10
00007bdc0b3d84ff  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d8508  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d8511  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d851a  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d8523  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d852c  sub rsp, 0x40
00007bdc0b3d8530  lea rdi, [rsp]
00007bdc0b3d8534  lea rsi, [rsp+0x10]
00007bdc0b3d8539  lea rdx, [rsp+0x20]
00007bdc0b3d853e  lea rcx, [rsp+0x30]
00007bdc0b3d8543  mov r8d, 0x00
00007bdc0b3d8549  lea r9, [r15+0x3A8]
00007bdc0b3d8550  movaps [rdi], xmm6
00007bdc0b3d8553  movaps [rsi], xmm10
00007bdc0b3d8557  movaps [rdx], xmm12
00007bdc0b3d855b  movaps [rcx], xmm1
00007bdc0b3d855e  mov rax, 0x62CE440F2A50
00007bdc0b3d8568  call rax
00007bdc0b3d856a  movaps xmm6, [rsp]
00007bdc0b3d856e  add rsp, 0x40
00007bdc0b3d8572  vmovaps xmm0, [rsp]
00007bdc0b3d8577  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d857d  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d8583  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d8589  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d858f  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d8595  vmovaps xmm7, [rsp+0x60]
00007bdc0b3d859b  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d85a1  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d85aa  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d85b3  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d85bc  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d85c5  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d85ce  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d85d7  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d85e0  add rsp, 0xF0
00007bdc0b3d85e7  pop r11
00007bdc0b3d85e9  pop r10
00007bdc0b3d85eb  pop r9
00007bdc0b3d85ed  pop r8
00007bdc0b3d85ef  pop rsi
00007bdc0b3d85f0  pop rdi
00007bdc0b3d85f1  pop rdx
00007bdc0b3d85f2  pop rcx
00007bdc0b3d85f3  pop rax
00007bdc0b3d85f4  add rsp, 0x08
00007bdc0b3d85f8  jmp 0x00007BDC0B3D69F6
00007bdc0b3d85fd  sub rsp, 0x08
00007bdc0b3d8601  push rax
00007bdc0b3d8602  push rcx
00007bdc0b3d8603  push rdx
00007bdc0b3d8604  push rdi
00007bdc0b3d8605  push rsi
00007bdc0b3d8606  push r8
00007bdc0b3d8608  push r9
00007bdc0b3d860a  push r10
00007bdc0b3d860c  push r11
00007bdc0b3d860e  sub rsp, 0xF0
00007bdc0b3d8615  vmovaps [rsp], xmm0
00007bdc0b3d861a  vmovaps [rsp+0x10], xmm1
00007bdc0b3d8620  vmovaps [rsp+0x20], xmm2
00007bdc0b3d8626  vmovaps [rsp+0x30], xmm3
00007bdc0b3d862c  vmovaps [rsp+0x40], xmm4
00007bdc0b3d8632  vmovaps [rsp+0x50], xmm5
00007bdc0b3d8638  vmovaps [rsp+0x60], xmm6
00007bdc0b3d863e  vmovaps [rsp+0x70], xmm7
00007bdc0b3d8644  vmovaps [rsp+0x80], xmm8
00007bdc0b3d864d  vmovaps [rsp+0x90], xmm9
00007bdc0b3d8656  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d865f  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d8668  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d8671  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d867a  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d8683  sub rsp, 0x40
00007bdc0b3d8687  lea rdi, [rsp]
00007bdc0b3d868b  lea rsi, [rsp+0x10]
00007bdc0b3d8690  lea rdx, [rsp+0x20]
00007bdc0b3d8695  lea rcx, [rsp+0x30]
00007bdc0b3d869a  mov r8d, 0x00
00007bdc0b3d86a0  lea r9, [r15+0x3A8]
00007bdc0b3d86a7  movaps [rdi], xmm10
00007bdc0b3d86ab  movaps [rsi], xmm5
00007bdc0b3d86ae  movaps [rdx], xmm12
00007bdc0b3d86b2  movaps [rcx], xmm1
00007bdc0b3d86b5  mov rax, 0x62CE440F2A50
00007bdc0b3d86bf  call rax
00007bdc0b3d86c1  movaps xmm10, [rsp]
00007bdc0b3d86c6  add rsp, 0x40
00007bdc0b3d86ca  vmovaps xmm0, [rsp]
00007bdc0b3d86cf  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d86d5  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d86db  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d86e1  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d86e7  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d86ed  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d86f3  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d86f9  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d8702  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d870b  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d8714  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d871d  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d8726  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d872f  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d8738  add rsp, 0xF0
00007bdc0b3d873f  pop r11
00007bdc0b3d8741  pop r10
00007bdc0b3d8743  pop r9
00007bdc0b3d8745  pop r8
00007bdc0b3d8747  pop rsi
00007bdc0b3d8748  pop rdi
00007bdc0b3d8749  pop rdx
00007bdc0b3d874a  pop rcx
00007bdc0b3d874b  pop rax
00007bdc0b3d874c  add rsp, 0x08
00007bdc0b3d8750  jmp 0x00007BDC0B3D6A25
00007bdc0b3d8755  sub rsp, 0x08
00007bdc0b3d8759  push rax
00007bdc0b3d875a  push rcx
00007bdc0b3d875b  push rdx
00007bdc0b3d875c  push rdi
00007bdc0b3d875d  push rsi
00007bdc0b3d875e  push r8
00007bdc0b3d8760  push r9
00007bdc0b3d8762  push r10
00007bdc0b3d8764  push r11
00007bdc0b3d8766  sub rsp, 0xF0
00007bdc0b3d876d  vmovaps [rsp], xmm0
00007bdc0b3d8772  vmovaps [rsp+0x10], xmm1
00007bdc0b3d8778  vmovaps [rsp+0x20], xmm2
00007bdc0b3d877e  vmovaps [rsp+0x30], xmm3
00007bdc0b3d8784  vmovaps [rsp+0x40], xmm4
00007bdc0b3d878a  vmovaps [rsp+0x50], xmm5
00007bdc0b3d8790  vmovaps [rsp+0x60], xmm6
00007bdc0b3d8796  vmovaps [rsp+0x70], xmm7
00007bdc0b3d879c  vmovaps [rsp+0x80], xmm8
00007bdc0b3d87a5  vmovaps [rsp+0x90], xmm9
00007bdc0b3d87ae  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d87b7  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d87c0  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d87c9  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d87d2  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d87db  sub rsp, 0x40
00007bdc0b3d87df  lea rdi, [rsp]
00007bdc0b3d87e3  lea rsi, [rsp+0x10]
00007bdc0b3d87e8  lea rdx, [rsp+0x20]
00007bdc0b3d87ed  lea rcx, [rsp+0x30]
00007bdc0b3d87f2  mov r8d, 0x00
00007bdc0b3d87f8  lea r9, [r15+0x3A8]
00007bdc0b3d87ff  movaps [rdi], xmm12
00007bdc0b3d8803  movaps [rsi], xmm7
00007bdc0b3d8806  movaps [rdx], xmm15
00007bdc0b3d880a  movaps [rcx], xmm1
00007bdc0b3d880d  mov rax, 0x62CE440F2A50
00007bdc0b3d8817  call rax
00007bdc0b3d8819  movaps xmm12, [rsp]
00007bdc0b3d881e  add rsp, 0x40
00007bdc0b3d8822  vmovaps xmm0, [rsp]
00007bdc0b3d8827  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d882d  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d8833  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d8839  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d883f  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d8845  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d884b  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d8851  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d885a  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d8863  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d886c  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d8875  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d887e  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d8887  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d8890  add rsp, 0xF0
00007bdc0b3d8897  pop r11
00007bdc0b3d8899  pop r10
00007bdc0b3d889b  pop r9
00007bdc0b3d889d  pop r8
00007bdc0b3d889f  pop rsi
00007bdc0b3d88a0  pop rdi
00007bdc0b3d88a1  pop rdx
00007bdc0b3d88a2  pop rcx
00007bdc0b3d88a3  pop rax
00007bdc0b3d88a4  add rsp, 0x08
00007bdc0b3d88a8  jmp 0x00007BDC0B3D6A4E
00007bdc0b3d88ad  call 0x00007BDC0B2D64F0
00007bdc0b3d88b2  jmp 0x00007BDC0B3D6A58
00007bdc0b3d88b7  call 0x00007BDC0B2E5820
00007bdc0b3d88bc  jmp 0x00007BDC0B3D6A62
00007bdc0b3d88c1  sub rsp, 0x08
00007bdc0b3d88c5  push rax
00007bdc0b3d88c6  push rcx
00007bdc0b3d88c7  push rdx
00007bdc0b3d88c8  push rdi
00007bdc0b3d88c9  push rsi
00007bdc0b3d88ca  push r8
00007bdc0b3d88cc  push r9
00007bdc0b3d88ce  push r10
00007bdc0b3d88d0  push r11
00007bdc0b3d88d2  sub rsp, 0xF0
00007bdc0b3d88d9  vmovaps [rsp], xmm0
00007bdc0b3d88de  vmovaps [rsp+0x10], xmm1
00007bdc0b3d88e4  vmovaps [rsp+0x20], xmm2
00007bdc0b3d88ea  vmovaps [rsp+0x30], xmm3
00007bdc0b3d88f0  vmovaps [rsp+0x40], xmm4
00007bdc0b3d88f6  vmovaps [rsp+0x50], xmm5
00007bdc0b3d88fc  vmovaps [rsp+0x60], xmm6
00007bdc0b3d8902  vmovaps [rsp+0x70], xmm8
00007bdc0b3d8908  vmovaps [rsp+0x80], xmm9
00007bdc0b3d8911  vmovaps [rsp+0x90], xmm10
00007bdc0b3d891a  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d8923  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d892c  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d8935  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d893e  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d8947  sub rsp, 0x40
00007bdc0b3d894b  lea rdi, [rsp]
00007bdc0b3d894f  lea rsi, [rsp+0x10]
00007bdc0b3d8954  lea rdx, [rsp+0x20]
00007bdc0b3d8959  lea rcx, [rsp+0x30]
00007bdc0b3d895e  mov r8d, 0x00
00007bdc0b3d8964  lea r9, [r15+0x3A8]
00007bdc0b3d896b  movaps [rdi], xmm7
00007bdc0b3d896e  movaps [rsi], xmm2
00007bdc0b3d8971  movaps [rdx], xmm9
00007bdc0b3d8975  movaps [rcx], xmm11
00007bdc0b3d8979  mov rax, 0x62CE440F2A50
00007bdc0b3d8983  call rax
00007bdc0b3d8985  movaps xmm7, [rsp]
00007bdc0b3d8989  add rsp, 0x40
00007bdc0b3d898d  vmovaps xmm0, [rsp]
00007bdc0b3d8992  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d8998  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d899e  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d89a4  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d89aa  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d89b0  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d89b6  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d89bc  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d89c5  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d89ce  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d89d7  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d89e0  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d89e9  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d89f2  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d89fb  add rsp, 0xF0
00007bdc0b3d8a02  pop r11
00007bdc0b3d8a04  pop r10
00007bdc0b3d8a06  pop r9
00007bdc0b3d8a08  pop r8
00007bdc0b3d8a0a  pop rsi
00007bdc0b3d8a0b  pop rdi
00007bdc0b3d8a0c  pop rdx
00007bdc0b3d8a0d  pop rcx
00007bdc0b3d8a0e  pop rax
00007bdc0b3d8a0f  add rsp, 0x08
00007bdc0b3d8a13  jmp 0x00007BDC0B3D6A96
00007bdc0b3d8a18  sub rsp, 0x08
00007bdc0b3d8a1c  push rax
00007bdc0b3d8a1d  push rcx
00007bdc0b3d8a1e  push rdx
00007bdc0b3d8a1f  push rdi
00007bdc0b3d8a20  push rsi
00007bdc0b3d8a21  push r8
00007bdc0b3d8a23  push r9
00007bdc0b3d8a25  push r10
00007bdc0b3d8a27  push r11
00007bdc0b3d8a29  sub rsp, 0xF0
00007bdc0b3d8a30  vmovaps [rsp], xmm0
00007bdc0b3d8a35  vmovaps [rsp+0x10], xmm1
00007bdc0b3d8a3b  vmovaps [rsp+0x20], xmm2
00007bdc0b3d8a41  vmovaps [rsp+0x30], xmm3
00007bdc0b3d8a47  vmovaps [rsp+0x40], xmm4
00007bdc0b3d8a4d  vmovaps [rsp+0x50], xmm5
00007bdc0b3d8a53  vmovaps [rsp+0x60], xmm6
00007bdc0b3d8a59  vmovaps [rsp+0x70], xmm7
00007bdc0b3d8a5f  vmovaps [rsp+0x80], xmm8
00007bdc0b3d8a68  vmovaps [rsp+0x90], xmm10
00007bdc0b3d8a71  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d8a7a  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d8a83  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d8a8c  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d8a95  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d8a9e  sub rsp, 0x40
00007bdc0b3d8aa2  lea rdi, [rsp]
00007bdc0b3d8aa6  lea rsi, [rsp+0x10]
00007bdc0b3d8aab  lea rdx, [rsp+0x20]
00007bdc0b3d8ab0  lea rcx, [rsp+0x30]
00007bdc0b3d8ab5  mov r8d, 0x00
00007bdc0b3d8abb  lea r9, [r15+0x3A8]
00007bdc0b3d8ac2  movaps [rdi], xmm9
00007bdc0b3d8ac6  movaps [rsi], xmm6
00007bdc0b3d8ac9  movaps [rdx], xmm1
00007bdc0b3d8acc  movaps [rcx], xmm11
00007bdc0b3d8ad0  mov rax, 0x62CE440F2A50
00007bdc0b3d8ada  call rax
00007bdc0b3d8adc  movaps xmm9, [rsp]
00007bdc0b3d8ae1  add rsp, 0x40
00007bdc0b3d8ae5  vmovaps xmm0, [rsp]
00007bdc0b3d8aea  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d8af0  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d8af6  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d8afc  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d8b02  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d8b08  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d8b0e  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d8b14  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d8b1d  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d8b26  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d8b2f  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d8b38  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d8b41  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d8b4a  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d8b53  add rsp, 0xF0
00007bdc0b3d8b5a  pop r11
00007bdc0b3d8b5c  pop r10
00007bdc0b3d8b5e  pop r9
00007bdc0b3d8b60  pop r8
00007bdc0b3d8b62  pop rsi
00007bdc0b3d8b63  pop rdi
00007bdc0b3d8b64  pop rdx
00007bdc0b3d8b65  pop rcx
00007bdc0b3d8b66  pop rax
00007bdc0b3d8b67  add rsp, 0x08
00007bdc0b3d8b6b  jmp 0x00007BDC0B3D6ABC
00007bdc0b3d8b70  sub rsp, 0x08
00007bdc0b3d8b74  push rax
00007bdc0b3d8b75  push rcx
00007bdc0b3d8b76  push rdx
00007bdc0b3d8b77  push rdi
00007bdc0b3d8b78  push rsi
00007bdc0b3d8b79  push r8
00007bdc0b3d8b7b  push r9
00007bdc0b3d8b7d  push r10
00007bdc0b3d8b7f  push r11
00007bdc0b3d8b81  sub rsp, 0xF0
00007bdc0b3d8b88  vmovaps [rsp], xmm0
00007bdc0b3d8b8d  vmovaps [rsp+0x10], xmm1
00007bdc0b3d8b93  vmovaps [rsp+0x20], xmm2
00007bdc0b3d8b99  vmovaps [rsp+0x30], xmm3
00007bdc0b3d8b9f  vmovaps [rsp+0x40], xmm4
00007bdc0b3d8ba5  vmovaps [rsp+0x50], xmm5
00007bdc0b3d8bab  vmovaps [rsp+0x60], xmm6
00007bdc0b3d8bb1  vmovaps [rsp+0x70], xmm7
00007bdc0b3d8bb7  vmovaps [rsp+0x80], xmm8
00007bdc0b3d8bc0  vmovaps [rsp+0x90], xmm9
00007bdc0b3d8bc9  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d8bd2  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d8bdb  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d8be4  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d8bed  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d8bf6  sub rsp, 0x40
00007bdc0b3d8bfa  lea rdi, [rsp]
00007bdc0b3d8bfe  lea rsi, [rsp+0x10]
00007bdc0b3d8c03  lea rdx, [rsp+0x20]
00007bdc0b3d8c08  lea rcx, [rsp+0x30]
00007bdc0b3d8c0d  mov r8d, 0x00
00007bdc0b3d8c13  lea r9, [r15+0x3A8]
00007bdc0b3d8c1a  movaps [rdi], xmm11
00007bdc0b3d8c1e  movaps [rsi], xmm10
00007bdc0b3d8c22  movaps [rdx], xmm8
00007bdc0b3d8c26  movaps [rcx], xmm1
00007bdc0b3d8c29  mov rax, 0x62CE440F2A50
00007bdc0b3d8c33  call rax
00007bdc0b3d8c35  movaps xmm11, [rsp]
00007bdc0b3d8c3a  add rsp, 0x40
00007bdc0b3d8c3e  vmovaps xmm0, [rsp]
00007bdc0b3d8c43  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d8c49  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d8c4f  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d8c55  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d8c5b  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d8c61  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d8c67  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d8c6d  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d8c76  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d8c7f  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d8c88  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d8c91  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d8c9a  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d8ca3  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d8cac  add rsp, 0xF0
00007bdc0b3d8cb3  pop r11
00007bdc0b3d8cb5  pop r10
00007bdc0b3d8cb7  pop r9
00007bdc0b3d8cb9  pop r8
00007bdc0b3d8cbb  pop rsi
00007bdc0b3d8cbc  pop rdi
00007bdc0b3d8cbd  pop rdx
00007bdc0b3d8cbe  pop rcx
00007bdc0b3d8cbf  pop rax
00007bdc0b3d8cc0  add rsp, 0x08
00007bdc0b3d8cc4  jmp 0x00007BDC0B3D6AE2
00007bdc0b3d8cc9  sub rsp, 0x08
00007bdc0b3d8ccd  push rax
00007bdc0b3d8cce  push rcx
00007bdc0b3d8ccf  push rdx
00007bdc0b3d8cd0  push rdi
00007bdc0b3d8cd1  push rsi
00007bdc0b3d8cd2  push r8
00007bdc0b3d8cd4  push r9
00007bdc0b3d8cd6  push r10
00007bdc0b3d8cd8  push r11
00007bdc0b3d8cda  sub rsp, 0xF0
00007bdc0b3d8ce1  vmovaps [rsp], xmm0
00007bdc0b3d8ce6  vmovaps [rsp+0x10], xmm1
00007bdc0b3d8cec  vmovaps [rsp+0x20], xmm2
00007bdc0b3d8cf2  vmovaps [rsp+0x30], xmm3
00007bdc0b3d8cf8  vmovaps [rsp+0x40], xmm4
00007bdc0b3d8cfe  vmovaps [rsp+0x50], xmm5
00007bdc0b3d8d04  vmovaps [rsp+0x60], xmm6
00007bdc0b3d8d0a  vmovaps [rsp+0x70], xmm7
00007bdc0b3d8d10  vmovaps [rsp+0x80], xmm8
00007bdc0b3d8d19  vmovaps [rsp+0x90], xmm9
00007bdc0b3d8d22  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d8d2b  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d8d34  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d8d3d  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d8d46  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d8d4f  sub rsp, 0x40
00007bdc0b3d8d53  lea rdi, [rsp]
00007bdc0b3d8d57  lea rsi, [rsp+0x10]
00007bdc0b3d8d5c  lea rdx, [rsp+0x20]
00007bdc0b3d8d61  lea rcx, [rsp+0x30]
00007bdc0b3d8d66  mov r8d, 0x00
00007bdc0b3d8d6c  lea r9, [r15+0x3A8]
00007bdc0b3d8d73  movaps [rdi], xmm10
00007bdc0b3d8d77  movaps [rsi], xmm12
00007bdc0b3d8d7b  movaps [rdx], xmm13
00007bdc0b3d8d7f  movaps [rcx], xmm1
00007bdc0b3d8d82  mov rax, 0x62CE440F2A50
00007bdc0b3d8d8c  call rax
00007bdc0b3d8d8e  movaps xmm10, [rsp]
00007bdc0b3d8d93  add rsp, 0x40
00007bdc0b3d8d97  vmovaps xmm0, [rsp]
00007bdc0b3d8d9c  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d8da2  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d8da8  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d8dae  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d8db4  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d8dba  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d8dc0  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d8dc6  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d8dcf  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d8dd8  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d8de1  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d8dea  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d8df3  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d8dfc  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d8e05  add rsp, 0xF0
00007bdc0b3d8e0c  pop r11
00007bdc0b3d8e0e  pop r10
00007bdc0b3d8e10  pop r9
00007bdc0b3d8e12  pop r8
00007bdc0b3d8e14  pop rsi
00007bdc0b3d8e15  pop rdi
00007bdc0b3d8e16  pop rdx
00007bdc0b3d8e17  pop rcx
00007bdc0b3d8e18  pop rax
00007bdc0b3d8e19  add rsp, 0x08
00007bdc0b3d8e1d  jmp 0x00007BDC0B3D6B08
00007bdc0b3d8e22  call 0x00007BDC0B2D64F0
00007bdc0b3d8e27  jmp 0x00007BDC0B3D6B12
00007bdc0b3d8e2c  call 0x00007BDC0B2E3320
00007bdc0b3d8e31  jmp 0x00007BDC0B3D6B1C
00007bdc0b3d8e36  sub rsp, 0x08
00007bdc0b3d8e3a  push rax
00007bdc0b3d8e3b  push rcx
00007bdc0b3d8e3c  push rdx
00007bdc0b3d8e3d  push rdi
00007bdc0b3d8e3e  push rsi
00007bdc0b3d8e3f  push r8
00007bdc0b3d8e41  push r9
00007bdc0b3d8e43  push r10
00007bdc0b3d8e45  push r11
00007bdc0b3d8e47  sub rsp, 0xF0
00007bdc0b3d8e4e  vmovaps [rsp], xmm0
00007bdc0b3d8e53  vmovaps [rsp+0x10], xmm1
00007bdc0b3d8e59  vmovaps [rsp+0x20], xmm2
00007bdc0b3d8e5f  vmovaps [rsp+0x30], xmm3
00007bdc0b3d8e65  vmovaps [rsp+0x40], xmm4
00007bdc0b3d8e6b  vmovaps [rsp+0x50], xmm5
00007bdc0b3d8e71  vmovaps [rsp+0x60], xmm6
00007bdc0b3d8e77  vmovaps [rsp+0x70], xmm7
00007bdc0b3d8e7d  vmovaps [rsp+0x80], xmm9
00007bdc0b3d8e86  vmovaps [rsp+0x90], xmm10
00007bdc0b3d8e8f  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d8e98  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d8ea1  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d8eaa  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d8eb3  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d8ebc  sub rsp, 0x40
00007bdc0b3d8ec0  lea rdi, [rsp]
00007bdc0b3d8ec4  lea rsi, [rsp+0x10]
00007bdc0b3d8ec9  lea rdx, [rsp+0x20]
00007bdc0b3d8ece  lea rcx, [rsp+0x30]
00007bdc0b3d8ed3  mov r8d, 0x00
00007bdc0b3d8ed9  lea r9, [r15+0x3A8]
00007bdc0b3d8ee0  movaps [rdi], xmm8
00007bdc0b3d8ee4  movaps [rsi], xmm7
00007bdc0b3d8ee7  movaps [rdx], xmm4
00007bdc0b3d8eea  movaps [rcx], xmm12
00007bdc0b3d8eee  mov rax, 0x62CE440F2A50
00007bdc0b3d8ef8  call rax
00007bdc0b3d8efa  movaps xmm8, [rsp]
00007bdc0b3d8eff  add rsp, 0x40
00007bdc0b3d8f03  vmovaps xmm0, [rsp]
00007bdc0b3d8f08  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d8f0e  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d8f14  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d8f1a  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d8f20  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d8f26  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d8f2c  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d8f32  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d8f3b  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d8f44  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d8f4d  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d8f56  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d8f5f  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d8f68  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d8f71  add rsp, 0xF0
00007bdc0b3d8f78  pop r11
00007bdc0b3d8f7a  pop r10
00007bdc0b3d8f7c  pop r9
00007bdc0b3d8f7e  pop r8
00007bdc0b3d8f80  pop rsi
00007bdc0b3d8f81  pop rdi
00007bdc0b3d8f82  pop rdx
00007bdc0b3d8f83  pop rcx
00007bdc0b3d8f84  pop rax
00007bdc0b3d8f85  add rsp, 0x08
00007bdc0b3d8f89  jmp 0x00007BDC0B3D6B45
00007bdc0b3d8f8e  sub rsp, 0x08
00007bdc0b3d8f92  push rax
00007bdc0b3d8f93  push rcx
00007bdc0b3d8f94  push rdx
00007bdc0b3d8f95  push rdi
00007bdc0b3d8f96  push rsi
00007bdc0b3d8f97  push r8
00007bdc0b3d8f99  push r9
00007bdc0b3d8f9b  push r10
00007bdc0b3d8f9d  push r11
00007bdc0b3d8f9f  sub rsp, 0xF0
00007bdc0b3d8fa6  vmovaps [rsp], xmm0
00007bdc0b3d8fab  vmovaps [rsp+0x10], xmm1
00007bdc0b3d8fb1  vmovaps [rsp+0x20], xmm2
00007bdc0b3d8fb7  vmovaps [rsp+0x30], xmm3
00007bdc0b3d8fbd  vmovaps [rsp+0x40], xmm4
00007bdc0b3d8fc3  vmovaps [rsp+0x50], xmm5
00007bdc0b3d8fc9  vmovaps [rsp+0x60], xmm6
00007bdc0b3d8fcf  vmovaps [rsp+0x70], xmm8
00007bdc0b3d8fd5  vmovaps [rsp+0x80], xmm9
00007bdc0b3d8fde  vmovaps [rsp+0x90], xmm10
00007bdc0b3d8fe7  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d8ff0  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d8ff9  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d9002  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d900b  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d9014  sub rsp, 0x40
00007bdc0b3d9018  lea rdi, [rsp]
00007bdc0b3d901c  lea rsi, [rsp+0x10]
00007bdc0b3d9021  lea rdx, [rsp+0x20]
00007bdc0b3d9026  lea rcx, [rsp+0x30]
00007bdc0b3d902b  mov r8d, 0x00
00007bdc0b3d9031  lea r9, [r15+0x3A8]
00007bdc0b3d9038  movaps [rdi], xmm7
00007bdc0b3d903b  movaps [rsi], xmm9
00007bdc0b3d903f  movaps [rdx], xmm14
00007bdc0b3d9043  movaps [rcx], xmm12
00007bdc0b3d9047  mov rax, 0x62CE440F2A50
00007bdc0b3d9051  call rax
00007bdc0b3d9053  movaps xmm7, [rsp]
00007bdc0b3d9057  add rsp, 0x40
00007bdc0b3d905b  vmovaps xmm0, [rsp]
00007bdc0b3d9060  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d9066  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d906c  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d9072  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d9078  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d907e  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d9084  vmovaps xmm8, [rsp+0x70]
00007bdc0b3d908a  vmovaps xmm9, [rsp+0x80]
00007bdc0b3d9093  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d909c  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d90a5  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d90ae  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d90b7  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d90c0  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d90c9  add rsp, 0xF0
00007bdc0b3d90d0  pop r11
00007bdc0b3d90d2  pop r10
00007bdc0b3d90d4  pop r9
00007bdc0b3d90d6  pop r8
00007bdc0b3d90d8  pop rsi
00007bdc0b3d90d9  pop rdi
00007bdc0b3d90da  pop rdx
00007bdc0b3d90db  pop rcx
00007bdc0b3d90dc  pop rax
00007bdc0b3d90dd  add rsp, 0x08
00007bdc0b3d90e1  jmp 0x00007BDC0B3D6B6D
00007bdc0b3d90e6  sub rsp, 0x08
00007bdc0b3d90ea  push rax
00007bdc0b3d90eb  push rcx
00007bdc0b3d90ec  push rdx
00007bdc0b3d90ed  push rdi
00007bdc0b3d90ee  push rsi
00007bdc0b3d90ef  push r8
00007bdc0b3d90f1  push r9
00007bdc0b3d90f3  push r10
00007bdc0b3d90f5  push r11
00007bdc0b3d90f7  sub rsp, 0xF0
00007bdc0b3d90fe  vmovaps [rsp], xmm0
00007bdc0b3d9103  vmovaps [rsp+0x10], xmm1
00007bdc0b3d9109  vmovaps [rsp+0x20], xmm2
00007bdc0b3d910f  vmovaps [rsp+0x30], xmm3
00007bdc0b3d9115  vmovaps [rsp+0x40], xmm4
00007bdc0b3d911b  vmovaps [rsp+0x50], xmm5
00007bdc0b3d9121  vmovaps [rsp+0x60], xmm6
00007bdc0b3d9127  vmovaps [rsp+0x70], xmm7
00007bdc0b3d912d  vmovaps [rsp+0x80], xmm8
00007bdc0b3d9136  vmovaps [rsp+0x90], xmm9
00007bdc0b3d913f  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d9148  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d9151  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d915a  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d9163  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d916c  sub rsp, 0x40
00007bdc0b3d9170  lea rdi, [rsp]
00007bdc0b3d9174  lea rsi, [rsp+0x10]
00007bdc0b3d9179  lea rdx, [rsp+0x20]
00007bdc0b3d917e  lea rcx, [rsp+0x30]
00007bdc0b3d9183  mov r8d, 0x00
00007bdc0b3d9189  lea r9, [r15+0x3A8]
00007bdc0b3d9190  movaps [rdi], xmm12
00007bdc0b3d9194  movaps [rsi], xmm11
00007bdc0b3d9198  movaps [rdx], xmm15
00007bdc0b3d919c  movaps [rcx], xmm14
00007bdc0b3d91a0  mov rax, 0x62CE440F2A50
00007bdc0b3d91aa  call rax
00007bdc0b3d91ac  movaps xmm12, [rsp]
00007bdc0b3d91b1  add rsp, 0x40
00007bdc0b3d91b5  vmovaps xmm0, [rsp]
00007bdc0b3d91ba  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d91c0  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d91c6  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d91cc  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d91d2  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d91d8  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d91de  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d91e4  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d91ed  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d91f6  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d91ff  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d9208  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d9211  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d921a  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d9223  add rsp, 0xF0
00007bdc0b3d922a  pop r11
00007bdc0b3d922c  pop r10
00007bdc0b3d922e  pop r9
00007bdc0b3d9230  pop r8
00007bdc0b3d9232  pop rsi
00007bdc0b3d9233  pop rdi
00007bdc0b3d9234  pop rdx
00007bdc0b3d9235  pop rcx
00007bdc0b3d9236  pop rax
00007bdc0b3d9237  add rsp, 0x08
00007bdc0b3d923b  jmp 0x00007BDC0B3D6B96
00007bdc0b3d9240  sub rsp, 0x08
00007bdc0b3d9244  push rax
00007bdc0b3d9245  push rcx
00007bdc0b3d9246  push rdx
00007bdc0b3d9247  push rdi
00007bdc0b3d9248  push rsi
00007bdc0b3d9249  push r8
00007bdc0b3d924b  push r9
00007bdc0b3d924d  push r10
00007bdc0b3d924f  push r11
00007bdc0b3d9251  sub rsp, 0xF0
00007bdc0b3d9258  vmovaps [rsp], xmm0
00007bdc0b3d925d  vmovaps [rsp+0x10], xmm1
00007bdc0b3d9263  vmovaps [rsp+0x20], xmm2
00007bdc0b3d9269  vmovaps [rsp+0x30], xmm3
00007bdc0b3d926f  vmovaps [rsp+0x40], xmm4
00007bdc0b3d9275  vmovaps [rsp+0x50], xmm5
00007bdc0b3d927b  vmovaps [rsp+0x60], xmm6
00007bdc0b3d9281  vmovaps [rsp+0x70], xmm7
00007bdc0b3d9287  vmovaps [rsp+0x80], xmm8
00007bdc0b3d9290  vmovaps [rsp+0x90], xmm9
00007bdc0b3d9299  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d92a2  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d92ab  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d92b4  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d92bd  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d92c6  sub rsp, 0x40
00007bdc0b3d92ca  lea rdi, [rsp]
00007bdc0b3d92ce  lea rsi, [rsp+0x10]
00007bdc0b3d92d3  lea rdx, [rsp+0x20]
00007bdc0b3d92d8  lea rcx, [rsp+0x30]
00007bdc0b3d92dd  mov r8d, 0x00
00007bdc0b3d92e3  lea r9, [r15+0x3A8]
00007bdc0b3d92ea  movaps [rdi], xmm11
00007bdc0b3d92ee  movaps [rsi], xmm10
00007bdc0b3d92f2  movaps [rdx], xmm13
00007bdc0b3d92f6  movaps [rcx], xmm15
00007bdc0b3d92fa  mov rax, 0x62CE440F2A50
00007bdc0b3d9304  call rax
00007bdc0b3d9306  movaps xmm11, [rsp]
00007bdc0b3d930b  add rsp, 0x40
00007bdc0b3d930f  vmovaps xmm0, [rsp]
00007bdc0b3d9314  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d931a  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d9320  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d9326  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d932c  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d9332  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d9338  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d933e  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d9347  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d9350  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d9359  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d9362  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d936b  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d9374  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d937d  add rsp, 0xF0
00007bdc0b3d9384  pop r11
00007bdc0b3d9386  pop r10
00007bdc0b3d9388  pop r9
00007bdc0b3d938a  pop r8
00007bdc0b3d938c  pop rsi
00007bdc0b3d938d  pop rdi
00007bdc0b3d938e  pop rdx
00007bdc0b3d938f  pop rcx
00007bdc0b3d9390  pop rax
00007bdc0b3d9391  add rsp, 0x08
00007bdc0b3d9395  jmp 0x00007BDC0B3D6BBF
00007bdc0b3d939a  call 0x00007BDC0B2E5820
00007bdc0b3d939f  jmp 0x00007BDC0B3D6BCC
00007bdc0b3d93a4  call 0x00007BDC0B2E45A0
00007bdc0b3d93a9  jmp 0x00007BDC0B3D6BD9
00007bdc0b3d93ae  sub rsp, 0x08
00007bdc0b3d93b2  push rax
00007bdc0b3d93b3  push rcx
00007bdc0b3d93b4  push rdx
00007bdc0b3d93b5  push rdi
00007bdc0b3d93b6  push rsi
00007bdc0b3d93b7  push r8
00007bdc0b3d93b9  push r9
00007bdc0b3d93bb  push r10
00007bdc0b3d93bd  push r11
00007bdc0b3d93bf  sub rsp, 0xF0
00007bdc0b3d93c6  vmovaps [rsp], xmm0
00007bdc0b3d93cb  vmovaps [rsp+0x10], xmm1
00007bdc0b3d93d1  vmovaps [rsp+0x20], xmm2
00007bdc0b3d93d7  vmovaps [rsp+0x30], xmm3
00007bdc0b3d93dd  vmovaps [rsp+0x40], xmm4
00007bdc0b3d93e3  vmovaps [rsp+0x50], xmm5
00007bdc0b3d93e9  vmovaps [rsp+0x60], xmm6
00007bdc0b3d93ef  vmovaps [rsp+0x70], xmm7
00007bdc0b3d93f5  vmovaps [rsp+0x80], xmm8
00007bdc0b3d93fe  vmovaps [rsp+0x90], xmm9
00007bdc0b3d9407  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d9410  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d9419  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d9422  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d942b  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d9434  sub rsp, 0x40
00007bdc0b3d9438  lea rdi, [rsp]
00007bdc0b3d943c  lea rsi, [rsp+0x10]
00007bdc0b3d9441  lea rdx, [rsp+0x20]
00007bdc0b3d9446  lea rcx, [rsp+0x30]
00007bdc0b3d944b  mov r8d, 0x00
00007bdc0b3d9451  lea r9, [r15+0x3A8]
00007bdc0b3d9458  movaps [rdi], xmm10
00007bdc0b3d945c  movaps [rsi], xmm8
00007bdc0b3d9460  movaps [rdx], xmm1
00007bdc0b3d9463  movaps [rcx], xmm13
00007bdc0b3d9467  mov rax, 0x62CE440F2A50
00007bdc0b3d9471  call rax
00007bdc0b3d9473  movaps xmm10, [rsp]
00007bdc0b3d9478  add rsp, 0x40
00007bdc0b3d947c  vmovaps xmm0, [rsp]
00007bdc0b3d9481  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d9487  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d948d  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d9493  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d9499  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d949f  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d94a5  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d94ab  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d94b4  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d94bd  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d94c6  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d94cf  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d94d8  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d94e1  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d94ea  add rsp, 0xF0
00007bdc0b3d94f1  pop r11
00007bdc0b3d94f3  pop r10
00007bdc0b3d94f5  pop r9
00007bdc0b3d94f7  pop r8
00007bdc0b3d94f9  pop rsi
00007bdc0b3d94fa  pop rdi
00007bdc0b3d94fb  pop rdx
00007bdc0b3d94fc  pop rcx
00007bdc0b3d94fd  pop rax
00007bdc0b3d94fe  add rsp, 0x08
00007bdc0b3d9502  jmp 0x00007BDC0B3D6C0F
00007bdc0b3d9507  call 0x00007BDC0B2D64F0
00007bdc0b3d950c  jmp 0x00007BDC0B3D6C21
00007bdc0b3d9511  sub rsp, 0x08
00007bdc0b3d9515  push rax
00007bdc0b3d9516  push rcx
00007bdc0b3d9517  push rdx
00007bdc0b3d9518  push rdi
00007bdc0b3d9519  push rsi
00007bdc0b3d951a  push r8
00007bdc0b3d951c  push r9
00007bdc0b3d951e  push r10
00007bdc0b3d9520  push r11
00007bdc0b3d9522  sub rsp, 0xF0
00007bdc0b3d9529  vmovaps [rsp], xmm0
00007bdc0b3d952e  vmovaps [rsp+0x10], xmm1
00007bdc0b3d9534  vmovaps [rsp+0x20], xmm2
00007bdc0b3d953a  vmovaps [rsp+0x30], xmm3
00007bdc0b3d9540  vmovaps [rsp+0x40], xmm4
00007bdc0b3d9546  vmovaps [rsp+0x50], xmm5
00007bdc0b3d954c  vmovaps [rsp+0x60], xmm6
00007bdc0b3d9552  vmovaps [rsp+0x70], xmm7
00007bdc0b3d9558  vmovaps [rsp+0x80], xmm8
00007bdc0b3d9561  vmovaps [rsp+0x90], xmm10
00007bdc0b3d956a  vmovaps [rsp+0xA0], xmm11
00007bdc0b3d9573  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d957c  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d9585  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d958e  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d9597  sub rsp, 0x40
00007bdc0b3d959b  lea rdi, [rsp]
00007bdc0b3d959f  lea rsi, [rsp+0x10]
00007bdc0b3d95a4  lea rdx, [rsp+0x20]
00007bdc0b3d95a9  lea rcx, [rsp+0x30]
00007bdc0b3d95ae  mov r8d, 0x00
00007bdc0b3d95b4  lea r9, [r15+0x3A8]
00007bdc0b3d95bb  movaps [rdi], xmm9
00007bdc0b3d95bf  movaps [rsi], xmm7
00007bdc0b3d95c2  movaps [rdx], xmm14
00007bdc0b3d95c6  movaps [rcx], xmm13
00007bdc0b3d95ca  mov rax, 0x62CE440F2A50
00007bdc0b3d95d4  call rax
00007bdc0b3d95d6  movaps xmm9, [rsp]
00007bdc0b3d95db  add rsp, 0x40
00007bdc0b3d95df  vmovaps xmm0, [rsp]
00007bdc0b3d95e4  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d95ea  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d95f0  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d95f6  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d95fc  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d9602  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d9608  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d960e  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d9617  vmovaps xmm10, [rsp+0x90]
00007bdc0b3d9620  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3d9629  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3d9632  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d963b  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d9644  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d964d  add rsp, 0xF0
00007bdc0b3d9654  pop r11
00007bdc0b3d9656  pop r10
00007bdc0b3d9658  pop r9
00007bdc0b3d965a  pop r8
00007bdc0b3d965c  pop rsi
00007bdc0b3d965d  pop rdi
00007bdc0b3d965e  pop rdx
00007bdc0b3d965f  pop rcx
00007bdc0b3d9660  pop rax
00007bdc0b3d9661  add rsp, 0x08
00007bdc0b3d9665  jmp 0x00007BDC0B3D6C4F
00007bdc0b3d966a  sub rsp, 0x08
00007bdc0b3d966e  push rax
00007bdc0b3d966f  push rcx
00007bdc0b3d9670  push rdx
00007bdc0b3d9671  push rdi
00007bdc0b3d9672  push rsi
00007bdc0b3d9673  push r8
00007bdc0b3d9675  push r9
00007bdc0b3d9677  push r10
00007bdc0b3d9679  push r11
00007bdc0b3d967b  sub rsp, 0xF0
00007bdc0b3d9682  vmovaps [rsp], xmm0
00007bdc0b3d9687  vmovaps [rsp+0x10], xmm1
00007bdc0b3d968d  vmovaps [rsp+0x20], xmm2
00007bdc0b3d9693  vmovaps [rsp+0x30], xmm3
00007bdc0b3d9699  vmovaps [rsp+0x40], xmm4
00007bdc0b3d969f  vmovaps [rsp+0x50], xmm5
00007bdc0b3d96a5  vmovaps [rsp+0x60], xmm6
00007bdc0b3d96ab  vmovaps [rsp+0x70], xmm7
00007bdc0b3d96b1  vmovaps [rsp+0x80], xmm8
00007bdc0b3d96ba  vmovaps [rsp+0x90], xmm9
00007bdc0b3d96c3  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d96cc  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d96d5  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d96de  vmovaps [rsp+0xD0], xmm14
00007bdc0b3d96e7  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d96f0  sub rsp, 0x40
00007bdc0b3d96f4  lea rdi, [rsp]
00007bdc0b3d96f8  lea rsi, [rsp+0x10]
00007bdc0b3d96fd  lea rdx, [rsp+0x20]
00007bdc0b3d9702  lea rcx, [rsp+0x30]
00007bdc0b3d9707  mov r8d, 0x00
00007bdc0b3d970d  lea r9, [r15+0x3A8]
00007bdc0b3d9714  movaps [rdi], xmm13
00007bdc0b3d9718  movaps [rsi], xmm12
00007bdc0b3d971c  movaps [rdx], xmm15
00007bdc0b3d9720  movaps [rcx], xmm14
00007bdc0b3d9724  mov rax, 0x62CE440F2A50
00007bdc0b3d972e  call rax
00007bdc0b3d9730  movaps xmm13, [rsp]
00007bdc0b3d9735  add rsp, 0x40
00007bdc0b3d9739  vmovaps xmm0, [rsp]
00007bdc0b3d973e  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d9744  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d974a  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d9750  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d9756  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d975c  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d9762  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d9768  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d9771  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d977a  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d9783  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d978c  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d9795  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3d979e  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d97a7  add rsp, 0xF0
00007bdc0b3d97ae  pop r11
00007bdc0b3d97b0  pop r10
00007bdc0b3d97b2  pop r9
00007bdc0b3d97b4  pop r8
00007bdc0b3d97b6  pop rsi
00007bdc0b3d97b7  pop rdi
00007bdc0b3d97b8  pop rdx
00007bdc0b3d97b9  pop rcx
00007bdc0b3d97ba  pop rax
00007bdc0b3d97bb  add rsp, 0x08
00007bdc0b3d97bf  jmp 0x00007BDC0B3D6C7D
00007bdc0b3d97c4  sub rsp, 0x08
00007bdc0b3d97c8  push rax
00007bdc0b3d97c9  push rcx
00007bdc0b3d97ca  push rdx
00007bdc0b3d97cb  push rdi
00007bdc0b3d97cc  push rsi
00007bdc0b3d97cd  push r8
00007bdc0b3d97cf  push r9
00007bdc0b3d97d1  push r10
00007bdc0b3d97d3  push r11
00007bdc0b3d97d5  sub rsp, 0xF0
00007bdc0b3d97dc  vmovaps [rsp], xmm0
00007bdc0b3d97e1  vmovaps [rsp+0x10], xmm1
00007bdc0b3d97e7  vmovaps [rsp+0x20], xmm2
00007bdc0b3d97ed  vmovaps [rsp+0x30], xmm3
00007bdc0b3d97f3  vmovaps [rsp+0x40], xmm4
00007bdc0b3d97f9  vmovaps [rsp+0x50], xmm5
00007bdc0b3d97ff  vmovaps [rsp+0x60], xmm6
00007bdc0b3d9805  vmovaps [rsp+0x70], xmm7
00007bdc0b3d980b  vmovaps [rsp+0x80], xmm8
00007bdc0b3d9814  vmovaps [rsp+0x90], xmm9
00007bdc0b3d981d  vmovaps [rsp+0xA0], xmm10
00007bdc0b3d9826  vmovaps [rsp+0xB0], xmm11
00007bdc0b3d982f  vmovaps [rsp+0xC0], xmm12
00007bdc0b3d9838  vmovaps [rsp+0xD0], xmm13
00007bdc0b3d9841  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d984a  sub rsp, 0x40
00007bdc0b3d984e  lea rdi, [rsp]
00007bdc0b3d9852  lea rsi, [rsp+0x10]
00007bdc0b3d9857  lea rdx, [rsp+0x20]
00007bdc0b3d985c  lea rcx, [rsp+0x30]
00007bdc0b3d9861  mov r8d, 0x00
00007bdc0b3d9867  lea r9, [r15+0x3A8]
00007bdc0b3d986e  movaps [rdi], xmm14
00007bdc0b3d9872  movaps [rsi], xmm11
00007bdc0b3d9876  movaps [rdx], xmm1
00007bdc0b3d9879  movaps [rcx], xmm15
00007bdc0b3d987d  mov rax, 0x62CE440F2A50
00007bdc0b3d9887  call rax
00007bdc0b3d9889  movaps xmm14, [rsp]
00007bdc0b3d988e  add rsp, 0x40
00007bdc0b3d9892  vmovaps xmm0, [rsp]
00007bdc0b3d9897  vmovaps xmm1, [rsp+0x10]
00007bdc0b3d989d  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d98a3  vmovaps xmm3, [rsp+0x30]
00007bdc0b3d98a9  vmovaps xmm4, [rsp+0x40]
00007bdc0b3d98af  vmovaps xmm5, [rsp+0x50]
00007bdc0b3d98b5  vmovaps xmm6, [rsp+0x60]
00007bdc0b3d98bb  vmovaps xmm7, [rsp+0x70]
00007bdc0b3d98c1  vmovaps xmm8, [rsp+0x80]
00007bdc0b3d98ca  vmovaps xmm9, [rsp+0x90]
00007bdc0b3d98d3  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3d98dc  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3d98e5  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3d98ee  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3d98f7  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3d9900  add rsp, 0xF0
00007bdc0b3d9907  pop r11
00007bdc0b3d9909  pop r10
00007bdc0b3d990b  pop r9
00007bdc0b3d990d  pop r8
00007bdc0b3d990f  pop rsi
00007bdc0b3d9910  pop rdi
00007bdc0b3d9911  pop rdx
00007bdc0b3d9912  pop rcx
00007bdc0b3d9913  pop rax
00007bdc0b3d9914  add rsp, 0x08
00007bdc0b3d9918  jmp 0x00007BDC0B3D6CAB
00007bdc0b3d991d  call 0x00007BDC0B2ACF70
00007bdc0b3d9922  jmp 0x00007BDC0B3D6CB9
00007bdc0b3d9927  call 0x00007BDC0B20C380
00007bdc0b3d992c  jmp 0x00007BDC0B3D6CC3
00007bdc0b3d9931  call 0x00007BDC0B208C20
00007bdc0b3d9936  jmp 0x00007BDC0B3D6CCD
00007bdc0b3d993b  call 0x00007BDC0B20D600
00007bdc0b3d9940  jmp 0x00007BDC0B3D6CD7
00007bdc0b3d9945  int3
00007bdc0b3d9946  nop [rax+rax*1], ax
00007bdc0b3d994f  nop
00007bdc0b3d9950  mov eax, [r15+0x48]
00007bdc0b3d9954  lea r14d, [eax+0x01]
00007bdc0b3d9959  mov [rsp+0x10], r14d
00007bdc0b3d995e  mov r14d, r14d
00007bdc0b3d9961  mov [r15+0x48], r14
00007bdc0b3d9965  xor eax, eax
00007bdc0b3d9967  mov r14d, [rsp+0x10]
00007bdc0b3d996c  cmp r14d, 0x1F4
00007bdc0b3d9973  cmc
00007bdc0b3d9974  lahf
00007bdc0b3d9975  seto al
00007bdc0b3d9978  mov [r15+0x108], eax
00007bdc0b3d997f  mov eax, [r15+0x108]
00007bdc0b3d9986  sahf
00007bdc0b3d9987  jnz 0x00007BDC0B3D99B9
00007bdc0b3d9989  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d9991  jz 0x00007BDC0B3DD2E0
00007bdc0b3d9997  nop [rax+rax*1], ax
00007bdc0b3d99a0  nop [rax+rax*1], eax
00007bdc0b3d99a8  mov eax, 0x410670
00007bdc0b3d99ad  mov [r15+0x100], rax
00007bdc0b3d99b4  jmp 0x00007BDC0B1FE110
00007bdc0b3d99b9  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3d99c1  jz 0x00007BDC0B3D99F0
00007bdc0b3d99c7  nop [rax+rax*1], ax
00007bdc0b3d99d0  nop [rax+rax*1], eax
00007bdc0b3d99d8  mov eax, 0x4104EC
00007bdc0b3d99dd  mov [r15+0x100], rax
00007bdc0b3d99e4  jmp 0x00007BDC0B1FE110
00007bdc0b3d99e9  int3
00007bdc0b3d99ea  int3
00007bdc0b3d99eb  nop [rax+rax*1], eax
00007bdc0b3d99f0  mov rax, [r15+0x40]
00007bdc0b3d99f4  vxorps xmm1, xmm1, xmm1
00007bdc0b3d99f8  vpbroadcastq xmm1, xmm1
00007bdc0b3d99fd  vxorps xmm15, xmm15, xmm15
00007bdc0b3d9a02  vpbroadcastq xmm15, xmm15
00007bdc0b3d9a07  lea r14, [rax+0x30]
00007bdc0b3d9a0b  mov r12, [r13+r14*1]
00007bdc0b3d9a10  lea r14, [rax+0x38]
00007bdc0b3d9a14  mov r11, [r13+r14*1]
00007bdc0b3d9a19  movq xmm14, r12
00007bdc0b3d9a1e  movq xmm13, r11
00007bdc0b3d9a23  movq xmm14, xmm14
00007bdc0b3d9a28  movq xmm13, xmm13
00007bdc0b3d9a2d  vmovaps [rsp+0x10], xmm13
00007bdc0b3d9a33  movq xmm13, xmm13
00007bdc0b3d9a38  movaps [r15+0x270], xmm13
00007bdc0b3d9a40  movaps xmm13, [r15+0x160]
00007bdc0b3d9a48  vmovaps [rsp+0x20], xmm13
00007bdc0b3d9a4e  vmovaps xmm12, [rsp+0x20]
00007bdc0b3d9a54  por xmm13, xmm12
00007bdc0b3d9a59  lea r14, [rax+0x20]
00007bdc0b3d9a5d  mov r12, [r13+r14*1]
00007bdc0b3d9a62  lea r14, [rax+0x28]
00007bdc0b3d9a66  mov r11, [r13+r14*1]
00007bdc0b3d9a6b  movq xmm12, r12
00007bdc0b3d9a70  movq xmm11, r11
00007bdc0b3d9a75  movq xmm12, xmm12
00007bdc0b3d9a7a  movq xmm11, xmm11
00007bdc0b3d9a7f  movaps xmm10, [r15+0x2D0]
00007bdc0b3d9a87  vmovaps [rsp+0x20], xmm10
00007bdc0b3d9a8d  vmovaps xmm9, [rsp+0x20]
00007bdc0b3d9a93  por xmm10, xmm9
00007bdc0b3d9a98  movaps xmm9, [r15+0x300]
00007bdc0b3d9aa0  vmovaps [rsp+0x20], xmm9
00007bdc0b3d9aa6  vmovaps xmm8, [rsp+0x20]
00007bdc0b3d9aac  por xmm9, xmm8
00007bdc0b3d9ab1  movaps xmm8, [r15+0x2B0]
00007bdc0b3d9ab9  vmovaps [rsp+0x20], xmm8
00007bdc0b3d9abf  vmovaps xmm7, [rsp+0x20]
00007bdc0b3d9ac5  por xmm8, xmm7
00007bdc0b3d9aca  movaps xmm7, [r15+0x180]
00007bdc0b3d9ad2  vmovaps [rsp+0x20], xmm7
00007bdc0b3d9ad8  vmovaps xmm6, [rsp+0x20]
00007bdc0b3d9ade  por xmm7, xmm6
00007bdc0b3d9ae2  lea r14, [rax+0x10]
00007bdc0b3d9ae6  mov r12, [r13+r14*1]
00007bdc0b3d9aeb  lea r14, [rax+0x18]
00007bdc0b3d9aef  mov r11, [r13+r14*1]
00007bdc0b3d9af4  movq xmm6, r12
00007bdc0b3d9af9  movq xmm5, r11
00007bdc0b3d9afe  movq xmm6, xmm6
00007bdc0b3d9b02  movq xmm5, xmm5
00007bdc0b3d9b06  movaps xmm4, [r15+0x200]
00007bdc0b3d9b0e  vmovaps [rsp+0x20], xmm4
00007bdc0b3d9b14  vmovaps xmm3, [rsp+0x20]
00007bdc0b3d9b1a  por xmm4, xmm3
00007bdc0b3d9b1e  movaps xmm3, [r15+0x1F0]
00007bdc0b3d9b26  vmovaps [rsp+0x20], xmm3
00007bdc0b3d9b2c  vmovaps xmm2, [rsp+0x20]
00007bdc0b3d9b32  por xmm3, xmm2
00007bdc0b3d9b36  movaps xmm2, [r15+0x2E0]
00007bdc0b3d9b3e  vmovaps [rsp+0x20], xmm2
00007bdc0b3d9b44  vmovaps [rsp+0x30], xmm1
00007bdc0b3d9b4a  vmovaps xmm1, [rsp+0x20]
00007bdc0b3d9b50  por xmm2, xmm1
00007bdc0b3d9b54  movaps xmm1, [r15+0x2A0]
00007bdc0b3d9b5c  vmovaps [rsp+0x20], xmm1
00007bdc0b3d9b62  vmovaps [rsp+0x40], xmm15
00007bdc0b3d9b68  vmovaps xmm15, [rsp+0x20]
00007bdc0b3d9b6e  por xmm1, xmm15
00007bdc0b3d9b73  movaps xmm15, [r15+0x280]
00007bdc0b3d9b7b  vmovaps [rsp+0x20], xmm15
00007bdc0b3d9b81  vmovaps [rsp+0x50], xmm1
00007bdc0b3d9b87  vmovaps xmm1, [rsp+0x20]
00007bdc0b3d9b8d  por xmm15, xmm1
00007bdc0b3d9b92  movaps xmm1, [r15+0x1C0]
00007bdc0b3d9b9a  vmovaps [rsp+0x20], xmm1
00007bdc0b3d9ba0  vmovaps [rsp+0x60], xmm15
00007bdc0b3d9ba6  vmovaps xmm15, [rsp+0x20]
00007bdc0b3d9bac  por xmm1, xmm15
00007bdc0b3d9bb1  movaps xmm15, [r15+0x210]
00007bdc0b3d9bb9  vmovaps [rsp+0x20], xmm15
00007bdc0b3d9bbf  vmovaps [rsp+0x70], xmm1
00007bdc0b3d9bc5  vmovaps xmm1, [rsp+0x20]
00007bdc0b3d9bcb  por xmm15, xmm1
00007bdc0b3d9bd0  mov r14, [r13+rax*1]
00007bdc0b3d9bd5  vmovq xmm1, r14
00007bdc0b3d9bda  vpbroadcastq xmm1, xmm1
00007bdc0b3d9bdf  vmovaps [rsp+0x20], xmm1
00007bdc0b3d9be5  vxorps xmm1, xmm1, xmm1
00007bdc0b3d9be9  vpbroadcastq xmm1, xmm1
00007bdc0b3d9bee  mov r14, [r15+0xF8]
00007bdc0b3d9bf5  vmovaps [rsp+0x80], xmm1
00007bdc0b3d9bfe  movups xmm1, [r13+r14*1]
00007bdc0b3d9c04  vmovaps [rsp+0x90], xmm1
00007bdc0b3d9c0d  vxorps xmm1, xmm1, xmm1
00007bdc0b3d9c11  vpbroadcastq xmm1, xmm1
00007bdc0b3d9c16  lea r12, [rax+0x08]
00007bdc0b3d9c1a  mov rax, [r13+r12*1]
00007bdc0b3d9c1f  vmovaps [rsp+0xA0], xmm1
00007bdc0b3d9c28  movq xmm1, rax
00007bdc0b3d9c2d  movaps [r15+0x240], xmm1
00007bdc0b3d9c35  mov rax, [r15+0x50]
00007bdc0b3d9c39  mov [r15+0x60], rax
00007bdc0b3d9c3d  mov qword ptr [r15+0x58], 0x40
00007bdc0b3d9c45  vmovaps xmm1, [rsp+0x30]
00007bdc0b3d9c4b  vmovaps [rsp+0x30], xmm15
00007bdc0b3d9c51  vmovaps xmm15, [rsp+0x90]
00007bdc0b3d9c5a  vmovaps [rsp+0x90], xmm14
00007bdc0b3d9c63  vmovaps xmm14, [rsp+0x20]
00007bdc0b3d9c69  vmovaps [rsp+0x20], xmm13
00007bdc0b3d9c6f  vmovaps [rsp+0xB0], xmm12
00007bdc0b3d9c78  movaps xmm13, xmm1
00007bdc0b3d9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d9c87  vptest xmm12, xmm12
00007bdc0b3d9c8c  jnz 0x00007BDC0B3DA72F
00007bdc0b3d9c92  movaps xmm1, [r15+0x250]
00007bdc0b3d9c9a  vmovaps xmm15, [rsp+0x40]
00007bdc0b3d9ca0  vmovaps [rsp+0x40], xmm13
00007bdc0b3d9ca6  movaps xmm12, xmm15
00007bdc0b3d9caa  vfmadd231pd xmm12, xmm1, xmm14
00007bdc0b3d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007bdc0b3d9cb5  vptest xmm13, xmm13
00007bdc0b3d9cba  jnz 0x00007BDC0B3DA888
00007bdc0b3d9cc0  movaps xmm15, [r15+0x1E0]
00007bdc0b3d9cc8  vmovaps [rsp+0xC0], xmm15
00007bdc0b3d9cd1  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3d9cda  por xmm15, xmm13
00007bdc0b3d9cdf  movaps xmm13, [r15+0x1D0]
00007bdc0b3d9ce7  vmovaps [rsp+0xC0], xmm13
00007bdc0b3d9cf0  vmovaps [rsp+0xD0], xmm1
00007bdc0b3d9cf9  vmovaps xmm1, [rsp+0xC0]
00007bdc0b3d9d02  por xmm13, xmm1
00007bdc0b3d9d07  movaps xmm1, [r15+0x2C0]
00007bdc0b3d9d0f  vmovaps [rsp+0xC0], xmm1
00007bdc0b3d9d18  vmovaps [rsp+0xE0], xmm15
00007bdc0b3d9d21  vmovaps xmm15, [rsp+0xC0]
00007bdc0b3d9d2a  por xmm1, xmm15
00007bdc0b3d9d2f  movaps xmm15, [r15+0x290]
00007bdc0b3d9d37  vmovaps [rsp+0xC0], xmm15
00007bdc0b3d9d40  vmovaps [rsp+0xF0], xmm1
00007bdc0b3d9d49  vmovaps xmm1, [rsp+0xC0]
00007bdc0b3d9d52  por xmm15, xmm1
00007bdc0b3d9d57  movaps xmm1, [r15+0x260]
00007bdc0b3d9d5f  vmovaps [rsp+0xC0], xmm1
00007bdc0b3d9d68  vmovaps [rsp+0x100], xmm15
00007bdc0b3d9d71  vmovaps xmm15, [rsp+0xC0]
00007bdc0b3d9d7a  por xmm1, xmm15
00007bdc0b3d9d7f  vmovaps xmm15, [rsp+0xD0]
00007bdc0b3d9d88  vmovaps [rsp+0xC0], xmm1
00007bdc0b3d9d91  vmovaps xmm1, [rsp+0xD0]
00007bdc0b3d9d9a  por xmm15, xmm1
00007bdc0b3d9d9f  lea r12, [r14+0xC0]
00007bdc0b3d9da6  movups xmm1, [r13+r12*1]
00007bdc0b3d9dac  mov [rsp+0xD0], rax
00007bdc0b3d9db4  xor eax, eax
00007bdc0b3d9db6  mov r12d, 0x40
00007bdc0b3d9dbc  mov r11d, 0x200
00007bdc0b3d9dc2  cmp r12, r11
00007bdc0b3d9dc5  cmc
00007bdc0b3d9dc6  lahf
00007bdc0b3d9dc7  seto al
00007bdc0b3d9dca  mov [r15+0x108], eax
00007bdc0b3d9dd1  vmovaps [rsp+0x110], xmm1
00007bdc0b3d9dda  vmovaps xmm1, [rsp+0x80]
00007bdc0b3d9de3  vmovaps [rsp+0x80], xmm15
00007bdc0b3d9dec  vmovaps xmm15, [rsp+0x110]
00007bdc0b3d9df5  vmovaps [rsp+0x110], xmm13
00007bdc0b3d9dfe  vmovaps [rsp+0x120], xmm12
00007bdc0b3d9e07  movaps xmm13, xmm1
00007bdc0b3d9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d9e16  vptest xmm12, xmm12
00007bdc0b3d9e1b  jnz 0x00007BDC0B3DA9EB
00007bdc0b3d9e21  lea rax, [r14+0xB0]
00007bdc0b3d9e28  movups xmm1, [r13+rax*1]
00007bdc0b3d9e2e  vmovaps xmm15, [rsp+0xA0]
00007bdc0b3d9e37  vmovaps [rsp+0xA0], xmm13
00007bdc0b3d9e40  movaps xmm12, xmm15
00007bdc0b3d9e44  vfmadd231pd xmm12, xmm1, xmm14
00007bdc0b3d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007bdc0b3d9e4f  vptest xmm13, xmm13
00007bdc0b3d9e54  jnz 0x00007BDC0B3DAB4E
00007bdc0b3d9e5a  vmovaps xmm1, [rsp+0x30]
00007bdc0b3d9e60  vmovaps xmm15, [rsp+0x30]
00007bdc0b3d9e66  por xmm1, xmm15
00007bdc0b3d9e6b  movaps [r15+0x210], xmm1
00007bdc0b3d9e73  vmovaps xmm15, [rsp+0x70]
00007bdc0b3d9e79  vmovaps xmm14, [rsp+0x70]
00007bdc0b3d9e7f  por xmm15, xmm14
00007bdc0b3d9e84  movaps [r15+0x1C0], xmm15
00007bdc0b3d9e8c  vmovaps xmm14, [rsp+0x60]
00007bdc0b3d9e92  vmovaps xmm13, [rsp+0x60]
00007bdc0b3d9e98  por xmm14, xmm13
00007bdc0b3d9e9d  movaps [r15+0x280], xmm14
00007bdc0b3d9ea5  vmovaps xmm13, [rsp+0x50]
00007bdc0b3d9eab  vmovaps [rsp+0x30], xmm1
00007bdc0b3d9eb1  vmovaps xmm1, [rsp+0x50]
00007bdc0b3d9eb7  por xmm13, xmm1
00007bdc0b3d9ebc  movaps [r15+0x2A0], xmm13
00007bdc0b3d9ec4  vmovaps [rsp+0x50], xmm2
00007bdc0b3d9eca  vmovaps xmm1, [rsp+0x50]
00007bdc0b3d9ed0  por xmm2, xmm1
00007bdc0b3d9ed4  movaps [r15+0x2E0], xmm2
00007bdc0b3d9edc  vmovaps [rsp+0x50], xmm3
00007bdc0b3d9ee2  vmovaps xmm1, [rsp+0x50]
00007bdc0b3d9ee8  por xmm3, xmm1
00007bdc0b3d9eec  movaps [r15+0x1F0], xmm3
00007bdc0b3d9ef4  vmovaps xmm1, [rsp+0x80]
00007bdc0b3d9efd  vmovaps [rsp+0x50], xmm15
00007bdc0b3d9f03  vmovaps xmm15, [rsp+0x80]
00007bdc0b3d9f0c  por xmm1, xmm15
00007bdc0b3d9f11  movaps [r15+0x250], xmm1
00007bdc0b3d9f19  vmovaps xmm1, [rsp+0xC0]
00007bdc0b3d9f22  vmovaps xmm15, [rsp+0xC0]
00007bdc0b3d9f2b  por xmm1, xmm15
00007bdc0b3d9f30  movaps [r15+0x260], xmm1
00007bdc0b3d9f38  vmovaps xmm15, [rsp+0x100]
00007bdc0b3d9f41  vmovaps [rsp+0x60], xmm1
00007bdc0b3d9f47  vmovaps xmm1, [rsp+0x100]
00007bdc0b3d9f50  por xmm15, xmm1
00007bdc0b3d9f55  movaps [r15+0x290], xmm15
00007bdc0b3d9f5d  vmovaps xmm1, [rsp+0xF0]
00007bdc0b3d9f66  vmovaps [rsp+0x70], xmm15
00007bdc0b3d9f6c  vmovaps xmm15, [rsp+0xF0]
00007bdc0b3d9f75  por xmm1, xmm15
00007bdc0b3d9f7a  movaps [r15+0x2C0], xmm1
00007bdc0b3d9f82  movq xmm15, qword ptr [r15+0x240]
00007bdc0b3d9f8b  vmovaps [rsp+0x80], xmm15
00007bdc0b3d9f94  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3d9f9a  vmovaps [rsp+0xC0], xmm1
00007bdc0b3d9fa3  vmovaps xmm1, [rsp+0x40]
00007bdc0b3d9fa9  vmovaps [rsp+0x40], xmm15
00007bdc0b3d9faf  vmovaps xmm15, [rsp+0x30]
00007bdc0b3d9fb5  vmovaps [rsp+0x30], xmm14
00007bdc0b3d9fbb  vmovaps xmm14, [rsp+0x40]
00007bdc0b3d9fc1  vmovaps [rsp+0x40], xmm13
00007bdc0b3d9fc7  vmovaps [rsp+0xF0], xmm12
00007bdc0b3d9fd0  movaps xmm13, xmm1
00007bdc0b3d9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007bdc0b3d9fdf  vptest xmm12, xmm12
00007bdc0b3d9fe4  jnz 0x00007BDC0B3DACA7
00007bdc0b3d9fea  vmovaps xmm1, [rsp+0x80]
00007bdc0b3d9ff3  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3d9ff9  vmovaps xmm15, [rsp+0xA0]
00007bdc0b3da002  movaps xmm14, xmm15
00007bdc0b3da006  vfmadd231pd xmm14, xmm2, xmm1
00007bdc0b3da00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007bdc0b3da011  vptest xmm12, xmm12
00007bdc0b3da016  jnz 0x00007BDC0B3DAE00
00007bdc0b3da01c  vmovaps xmm1, [rsp+0x80]
00007bdc0b3da025  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3da02b  vmovaps xmm15, [rsp+0x120]
00007bdc0b3da034  vmovaps xmm12, [rsp+0x50]
00007bdc0b3da03a  vmovaps [rsp+0x50], xmm14
00007bdc0b3da040  movaps xmm2, xmm15
00007bdc0b3da044  vfmadd231pd xmm2, xmm12, xmm1
00007bdc0b3da049  vcmppd xmm14, xmm2, xmm2, 0x03
00007bdc0b3da04e  vptest xmm14, xmm14
00007bdc0b3da053  jnz 0x00007BDC0B3DAF58
00007bdc0b3da059  vmovaps xmm1, [rsp+0x110]
00007bdc0b3da062  vmovaps xmm15, [rsp+0x110]
00007bdc0b3da06b  por xmm1, xmm15
00007bdc0b3da070  movaps [r15+0x1D0], xmm1
00007bdc0b3da078  vmovaps xmm15, [rsp+0x80]
00007bdc0b3da081  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3da087  vmovaps xmm14, [rsp+0xF0]
00007bdc0b3da090  vmovaps [rsp+0x80], xmm1
00007bdc0b3da099  movaps xmm12, xmm14
00007bdc0b3da09d  vfmadd231pd xmm12, xmm3, xmm15
00007bdc0b3da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007bdc0b3da0a8  vptest xmm1, xmm1
00007bdc0b3da0ad  jnz 0x00007BDC0B3DB0AF
00007bdc0b3da0b3  vmovaps [rsp+0xA0], xmm4
00007bdc0b3da0bc  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3da0c5  por xmm4, xmm1
00007bdc0b3da0c9  movaps [r15+0x200], xmm4
00007bdc0b3da0d1  vmovaps xmm1, [rsp+0xE0]
00007bdc0b3da0da  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3da0e3  por xmm1, xmm15
00007bdc0b3da0e8  movaps [r15+0x1E0], xmm1
00007bdc0b3da0f0  vmovaps [rsp+0xA0], xmm8
00007bdc0b3da0f9  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3da102  por xmm8, xmm1
00007bdc0b3da107  movaps [r15+0x2B0], xmm8
00007bdc0b3da10f  vmovaps [rsp+0xA0], xmm9
00007bdc0b3da118  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3da121  por xmm9, xmm1
00007bdc0b3da126  movaps [r15+0x300], xmm9
00007bdc0b3da12e  vmovaps [rsp+0xA0], xmm6
00007bdc0b3da137  vpermilpd xmm6, xmm6, 0x00
00007bdc0b3da13d  vmovaps xmm14, [rsp+0x60]
00007bdc0b3da143  movaps xmm9, xmm13
00007bdc0b3da147  vfmadd231pd xmm9, xmm14, xmm6
00007bdc0b3da14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007bdc0b3da152  vptest xmm3, xmm3
00007bdc0b3da157  jnz 0x00007BDC0B3DB208
00007bdc0b3da15d  vmovaps xmm14, [rsp+0xA0]
00007bdc0b3da166  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3da16c  vmovaps xmm13, [rsp+0x50]
00007bdc0b3da172  vmovaps xmm6, [rsp+0xC0]
00007bdc0b3da17b  vmovaps [rsp+0x50], xmm1
00007bdc0b3da181  movaps xmm3, xmm13
00007bdc0b3da185  vfmadd231pd xmm3, xmm6, xmm14
00007bdc0b3da18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007bdc0b3da18f  vptest xmm1, xmm1
00007bdc0b3da194  jnz 0x00007BDC0B3DB361
00007bdc0b3da19a  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3da1a3  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3da1a9  vmovaps xmm14, [rsp+0x30]
00007bdc0b3da1af  movaps xmm6, xmm2
00007bdc0b3da1b2  vfmadd231pd xmm6, xmm14, xmm1
00007bdc0b3da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007bdc0b3da1bc  vptest xmm13, xmm13
00007bdc0b3da1c1  jnz 0x00007BDC0B3DB4B8
00007bdc0b3da1c7  vmovaps xmm1, [rsp+0xA0]
00007bdc0b3da1d0  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3da1d6  vmovaps xmm14, [rsp+0x80]
00007bdc0b3da1df  movaps xmm13, xmm12
00007bdc0b3da1e3  vfmadd231pd xmm13, xmm14, xmm1
00007bdc0b3da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007bdc0b3da1ee  vptest xmm2, xmm2
00007bdc0b3da1f3  jnz 0x00007BDC0B3DB60E
00007bdc0b3da1f9  vmovaps [rsp+0x30], xmm7
00007bdc0b3da1ff  vmovaps xmm1, [rsp+0x30]
00007bdc0b3da205  por xmm7, xmm1
00007bdc0b3da209  movaps [r15+0x180], xmm7
00007bdc0b3da211  vmovaps [rsp+0x30], xmm10
00007bdc0b3da217  vmovaps xmm1, [rsp+0x30]
00007bdc0b3da21d  por xmm10, xmm1
00007bdc0b3da222  movaps [r15+0x2D0], xmm10
00007bdc0b3da22a  vmovaps [rsp+0x30], xmm5
00007bdc0b3da230  vpermilpd xmm5, xmm5, 0x00
00007bdc0b3da236  vmovaps xmm14, [rsp+0x50]
00007bdc0b3da23c  movaps xmm12, xmm3
00007bdc0b3da240  vfmadd231pd xmm12, xmm14, xmm5
00007bdc0b3da245  vcmppd xmm10, xmm12, xmm12, 0x03
00007bdc0b3da24b  vptest xmm10, xmm10
00007bdc0b3da250  jnz 0x00007BDC0B3DB767
00007bdc0b3da256  vmovaps xmm14, [rsp+0x30]
00007bdc0b3da25c  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3da262  movaps xmm10, xmm9
00007bdc0b3da266  vfmadd231pd xmm10, xmm7, xmm14
00007bdc0b3da26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007bdc0b3da271  vptest xmm5, xmm5
00007bdc0b3da276  jnz 0x00007BDC0B3DB8BF
00007bdc0b3da27c  lea rax, [r14+0x80]
00007bdc0b3da283  movups xmm14, [r13+rax*1]
00007bdc0b3da289  movaps [r15+0x2F0], xmm14
00007bdc0b3da291  vmovaps xmm9, [rsp+0x30]
00007bdc0b3da297  vpermilpd xmm9, xmm9, 0x00
00007bdc0b3da29d  vmovaps xmm7, [rsp+0x70]
00007bdc0b3da2a3  movaps xmm5, xmm6
00007bdc0b3da2a6  vfmadd231pd xmm5, xmm7, xmm9
00007bdc0b3da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007bdc0b3da2b0  vptest xmm3, xmm3
00007bdc0b3da2b5  jnz 0x00007BDC0B3DBA22
00007bdc0b3da2bb  vmovaps xmm9, [rsp+0x30]
00007bdc0b3da2c1  vpermilpd xmm9, xmm9, 0x00
00007bdc0b3da2c7  movaps xmm7, xmm13
00007bdc0b3da2cb  vfmadd231pd xmm7, xmm1, xmm9
00007bdc0b3da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007bdc0b3da2d5  vptest xmm6, xmm6
00007bdc0b3da2da  jnz 0x00007BDC0B3DBB78
00007bdc0b3da2e0  vmovaps xmm1, [rsp+0x20]
00007bdc0b3da2e6  vmovaps xmm13, [rsp+0x20]
00007bdc0b3da2ec  por xmm1, xmm13
00007bdc0b3da2f1  movaps [r15+0x160], xmm1
00007bdc0b3da2f9  lea rax, [r14+0x40]
00007bdc0b3da2fd  movups xmm13, [r13+rax*1]
00007bdc0b3da303  lea rax, [r14+0x50]
00007bdc0b3da307  movups xmm9, [r13+rax*1]
00007bdc0b3da30d  movaps [r15+0x1B0], xmm13
00007bdc0b3da315  movaps [r15+0x1A0], xmm9
00007bdc0b3da31d  movaps xmm6, [r15+0x190]
00007bdc0b3da325  vmovaps xmm3, [rsp+0xB0]
00007bdc0b3da32e  vpermilpd xmm3, xmm3, 0x00
00007bdc0b3da334  vmovaps [rsp+0x20], xmm1
00007bdc0b3da33a  movaps xmm2, xmm12
00007bdc0b3da33e  vfmadd231pd xmm2, xmm6, xmm3
00007bdc0b3da343  vcmppd xmm1, xmm2, xmm2, 0x03
00007bdc0b3da348  vptest xmm1, xmm1
00007bdc0b3da34d  jnz 0x00007BDC0B3DBCE3
00007bdc0b3da353  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3da35c  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3da362  vmovaps xmm12, [rsp+0x20]
00007bdc0b3da368  movaps xmm6, xmm10
00007bdc0b3da36c  vfmadd231pd xmm6, xmm12, xmm1
00007bdc0b3da371  vcmppd xmm3, xmm6, xmm6, 0x03
00007bdc0b3da376  vptest xmm3, xmm3
00007bdc0b3da37b  jnz 0x00007BDC0B3DBE39
00007bdc0b3da381  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3da38a  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3da390  vmovaps xmm12, [rsp+0x40]
00007bdc0b3da396  movaps xmm10, xmm5
00007bdc0b3da39a  vfmadd231pd xmm10, xmm12, xmm1
00007bdc0b3da39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007bdc0b3da3a5  vptest xmm3, xmm3
00007bdc0b3da3aa  jnz 0x00007BDC0B3DBF90
00007bdc0b3da3b0  vmovaps xmm1, [rsp+0xB0]
00007bdc0b3da3b9  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3da3bf  movaps xmm12, xmm7
00007bdc0b3da3c3  vfmadd231pd xmm12, xmm15, xmm1
00007bdc0b3da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007bdc0b3da3ce  vptest xmm5, xmm5
00007bdc0b3da3d3  jnz 0x00007BDC0B3DC0E8
00007bdc0b3da3d9  lea rax, [r14+0x60]
00007bdc0b3da3dd  movups xmm1, [r13+rax*1]
00007bdc0b3da3e3  lea rax, [r14+0x70]
00007bdc0b3da3e7  movups xmm15, [r13+rax*1]
00007bdc0b3da3ed  movaps [r15+0x150], xmm1
00007bdc0b3da3f5  movaps [r15+0x120], xmm15
00007bdc0b3da3fd  vmovaps [rsp+0x20], xmm11
00007bdc0b3da403  vpermilpd xmm11, xmm11, 0x00
00007bdc0b3da409  movaps xmm7, xmm2
00007bdc0b3da40c  vfmadd231pd xmm7, xmm9, xmm11
00007bdc0b3da411  vcmppd xmm5, xmm7, xmm7, 0x03
00007bdc0b3da416  vptest xmm5, xmm5
00007bdc0b3da41b  jnz 0x00007BDC0B3DC254
00007bdc0b3da421  vmovaps xmm11, [rsp+0x20]
00007bdc0b3da427  vpermilpd xmm11, xmm11, 0x00
00007bdc0b3da42d  movaps xmm9, xmm6
00007bdc0b3da431  vfmadd231pd xmm9, xmm1, xmm11
00007bdc0b3da436  vcmppd xmm5, xmm9, xmm9, 0x03
00007bdc0b3da43c  vptest xmm5, xmm5
00007bdc0b3da441  jnz 0x00007BDC0B3DC3AB
00007bdc0b3da447  vmovaps xmm1, [rsp+0x20]
00007bdc0b3da44d  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3da453  movaps xmm11, xmm10
00007bdc0b3da457  vfmadd231pd xmm11, xmm8, xmm1
00007bdc0b3da45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007bdc0b3da462  vptest xmm6, xmm6
00007bdc0b3da467  jnz 0x00007BDC0B3DC503
00007bdc0b3da46d  vmovaps xmm1, [rsp+0x20]
00007bdc0b3da473  vpermilpd xmm1, xmm1, 0x00
00007bdc0b3da479  movaps xmm10, xmm12
00007bdc0b3da47d  vfmadd231pd xmm10, xmm13, xmm1
00007bdc0b3da482  vcmppd xmm8, xmm10, xmm10, 0x03
00007bdc0b3da488  vptest xmm8, xmm8
00007bdc0b3da48d  jnz 0x00007BDC0B3DC65C
00007bdc0b3da493  lea rax, [r14+0x20]
00007bdc0b3da497  movups xmm1, [r13+rax*1]
00007bdc0b3da49d  lea rax, [r14+0x30]
00007bdc0b3da4a1  movups xmm13, [r13+rax*1]
00007bdc0b3da4a7  vmovaps xmm12, [rsp+0x90]
00007bdc0b3da4b0  vpermilpd xmm12, xmm12, 0x00
00007bdc0b3da4b6  movaps xmm8, xmm7
00007bdc0b3da4ba  vfmadd231pd xmm8, xmm4, xmm12
00007bdc0b3da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007bdc0b3da4c5  vptest xmm6, xmm6
00007bdc0b3da4ca  jnz 0x00007BDC0B3DC7C9
00007bdc0b3da4d0  vmovaps xmm12, [rsp+0x90]
00007bdc0b3da4d9  vpermilpd xmm12, xmm12, 0x00
00007bdc0b3da4df  movaps xmm7, xmm9
00007bdc0b3da4e3  vfmadd231pd xmm7, xmm14, xmm12
00007bdc0b3da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007bdc0b3da4ed  vptest xmm6, xmm6
00007bdc0b3da4f2  jnz 0x00007BDC0B3DC921
00007bdc0b3da4f8  vmovaps xmm14, [rsp+0x90]
00007bdc0b3da501  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3da507  movaps xmm12, xmm11
00007bdc0b3da50b  vfmadd231pd xmm12, xmm15, xmm14
00007bdc0b3da510  vcmppd xmm9, xmm12, xmm12, 0x03
00007bdc0b3da516  vptest xmm9, xmm9
00007bdc0b3da51b  jnz 0x00007BDC0B3DCA79
00007bdc0b3da521  vmovaps xmm15, [rsp+0x90]
00007bdc0b3da52a  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3da530  movaps xmm11, xmm10
00007bdc0b3da534  vfmadd231pd xmm11, xmm13, xmm15
00007bdc0b3da539  vcmppd xmm14, xmm11, xmm11, 0x03
00007bdc0b3da53f  vptest xmm14, xmm14
00007bdc0b3da544  jnz 0x00007BDC0B3DCBD3
00007bdc0b3da54a  lea rax, [r14+0x90]
00007bdc0b3da551  movups xmm15, [r13+rax*1]
00007bdc0b3da557  lea rax, [r14+0xA0]
00007bdc0b3da55e  movups xmm14, [r13+rax*1]
00007bdc0b3da564  movaps [r15+0x140], xmm15
00007bdc0b3da56c  movaps [r15+0x130], xmm14
00007bdc0b3da574  vmovaps xmm13, [rsp+0x10]
00007bdc0b3da57a  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3da580  movaps xmm10, xmm8
00007bdc0b3da584  vfmadd231pd xmm10, xmm1, xmm13
00007bdc0b3da589  vcmppd xmm9, xmm10, xmm10, 0x03
00007bdc0b3da58f  vptest xmm9, xmm9
00007bdc0b3da594  jnz 0x00007BDC0B3DCD41
00007bdc0b3da59a  movaps [r15+0x220], xmm10
00007bdc0b3da5a2  lea rax, [r14+0x10]
00007bdc0b3da5a6  movups xmm1, [r13+rax*1]
00007bdc0b3da5ac  movaps [r15+0x240], xmm1
00007bdc0b3da5b4  vmovaps xmm13, [rsp+0x10]
00007bdc0b3da5ba  vpermilpd xmm13, xmm13, 0x00
00007bdc0b3da5c0  movaps xmm9, xmm7
00007bdc0b3da5c4  vfmadd231pd xmm9, xmm14, xmm13
00007bdc0b3da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007bdc0b3da5cf  vptest xmm8, xmm8
00007bdc0b3da5d4  jnz 0x00007BDC0B3DCEA4
00007bdc0b3da5da  movaps [r15+0x110], xmm9
00007bdc0b3da5e2  vmovaps xmm14, [rsp+0x10]
00007bdc0b3da5e8  vpermilpd xmm14, xmm14, 0x00
00007bdc0b3da5ee  movaps xmm13, xmm12
00007bdc0b3da5f2  vfmadd231pd xmm13, xmm15, xmm14
00007bdc0b3da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007bdc0b3da5fd  vptest xmm8, xmm8
00007bdc0b3da602  jnz 0x00007BDC0B3DCFFD
00007bdc0b3da608  movaps [r15+0x170], xmm13
00007bdc0b3da610  vmovaps xmm15, [rsp+0x10]
00007bdc0b3da616  vpermilpd xmm15, xmm15, 0x00
00007bdc0b3da61c  movaps xmm14, xmm11
00007bdc0b3da620  vfmadd231pd xmm14, xmm1, xmm15
00007bdc0b3da625  vcmppd xmm12, xmm14, xmm14, 0x03
00007bdc0b3da62b  vptest xmm12, xmm12
00007bdc0b3da630  jnz 0x00007BDC0B3DD157
00007bdc0b3da636  movaps [r15+0x230], xmm14
00007bdc0b3da63e  mov rax, [rsp+0xD0]
00007bdc0b3da646  movups [r13+rax*1], xmm9
00007bdc0b3da64c  lea r14, [rax+0x10]
00007bdc0b3da650  movups [r13+r14*1], xmm13
00007bdc0b3da656  lea r14, [rax+0x20]
00007bdc0b3da65a  movups [r13+r14*1], xmm10
00007bdc0b3da660  lea r14, [rax+0x30]
00007bdc0b3da664  movups [r13+r14*1], xmm14
00007bdc0b3da66a  mov eax, [r15+0x108]
00007bdc0b3da671  sahf
00007bdc0b3da672  jnz 0x00007BDC0B3DA6A4
00007bdc0b3da674  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3da67c  jz 0x00007BDC0B3D9950
00007bdc0b3da682  nop [rax+rax*1], ax
00007bdc0b3da68b  nop [rax+rax*1], eax
00007bdc0b3da693  mov eax, 0x410664
00007bdc0b3da698  mov [r15+0x100], rax
00007bdc0b3da69f  jmp 0x00007BDC0B1FE110
00007bdc0b3da6a4  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3da6ac  jz 0x00007BDC0B3D6050
00007bdc0b3da6b2  nop [rax+rax*1], ax
00007bdc0b3da6bb  nop [rax+rax*1], eax
00007bdc0b3da6c3  mov eax, 0x4104F0
00007bdc0b3da6c8  mov [r15+0x100], rax
00007bdc0b3da6cf  jmp 0x00007BDC0B1FE110
00007bdc0b3da6d4  int3
00007bdc0b3da6d5  call 0x00007BDC0B2E27E0
00007bdc0b3da6da  jmp 0x00007BDC0B3D9A10
00007bdc0b3da6df  call 0x00007BDC0B2E1570
00007bdc0b3da6e4  jmp 0x00007BDC0B3D9A19
00007bdc0b3da6e9  call 0x00007BDC0B2E27E0
00007bdc0b3da6ee  jmp 0x00007BDC0B3D9A62
00007bdc0b3da6f3  call 0x00007BDC0B2E1570
00007bdc0b3da6f8  jmp 0x00007BDC0B3D9A6B
00007bdc0b3da6fd  call 0x00007BDC0B2E27E0
00007bdc0b3da702  jmp 0x00007BDC0B3D9AEB
00007bdc0b3da707  call 0x00007BDC0B2E1570
00007bdc0b3da70c  jmp 0x00007BDC0B3D9AF4
00007bdc0b3da711  call 0x00007BDC0B20DC20
00007bdc0b3da716  jmp 0x00007BDC0B3D9BD5
00007bdc0b3da71b  call 0x00007BDC0B2D64F0
00007bdc0b3da720  jmp 0x00007BDC0B3D9C04
00007bdc0b3da725  call 0x00007BDC0B2B47C0
00007bdc0b3da72a  jmp 0x00007BDC0B3D9C1F
00007bdc0b3da72f  sub rsp, 0x08
00007bdc0b3da733  push rax
00007bdc0b3da734  push rcx
00007bdc0b3da735  push rdx
00007bdc0b3da736  push rdi
00007bdc0b3da737  push rsi
00007bdc0b3da738  push r8
00007bdc0b3da73a  push r9
00007bdc0b3da73c  push r10
00007bdc0b3da73e  push r11
00007bdc0b3da740  sub rsp, 0xF0
00007bdc0b3da747  vmovaps [rsp], xmm0
00007bdc0b3da74c  vmovaps [rsp+0x10], xmm1
00007bdc0b3da752  vmovaps [rsp+0x20], xmm2
00007bdc0b3da758  vmovaps [rsp+0x30], xmm3
00007bdc0b3da75e  vmovaps [rsp+0x40], xmm4
00007bdc0b3da764  vmovaps [rsp+0x50], xmm5
00007bdc0b3da76a  vmovaps [rsp+0x60], xmm6
00007bdc0b3da770  vmovaps [rsp+0x70], xmm7
00007bdc0b3da776  vmovaps [rsp+0x80], xmm8
00007bdc0b3da77f  vmovaps [rsp+0x90], xmm9
00007bdc0b3da788  vmovaps [rsp+0xA0], xmm10
00007bdc0b3da791  vmovaps [rsp+0xB0], xmm11
00007bdc0b3da79a  vmovaps [rsp+0xC0], xmm12
00007bdc0b3da7a3  vmovaps [rsp+0xD0], xmm14
00007bdc0b3da7ac  vmovaps [rsp+0xE0], xmm15
00007bdc0b3da7b5  sub rsp, 0x40
00007bdc0b3da7b9  lea rdi, [rsp]
00007bdc0b3da7bd  lea rsi, [rsp+0x10]
00007bdc0b3da7c2  lea rdx, [rsp+0x20]
00007bdc0b3da7c7  lea rcx, [rsp+0x30]
00007bdc0b3da7cc  mov r8d, 0x00
00007bdc0b3da7d2  lea r9, [r15+0x3A8]
00007bdc0b3da7d9  movaps [rdi], xmm13
00007bdc0b3da7dd  movaps [rsi], xmm1
00007bdc0b3da7e0  movaps [rdx], xmm15
00007bdc0b3da7e4  movaps [rcx], xmm14
00007bdc0b3da7e8  mov rax, 0x62CE440F2A50
00007bdc0b3da7f2  call rax
00007bdc0b3da7f4  movaps xmm13, [rsp]
00007bdc0b3da7f9  add rsp, 0x40
00007bdc0b3da7fd  vmovaps xmm0, [rsp]
00007bdc0b3da802  vmovaps xmm1, [rsp+0x10]
00007bdc0b3da808  vmovaps xmm2, [rsp+0x20]
00007bdc0b3da80e  vmovaps xmm3, [rsp+0x30]
00007bdc0b3da814  vmovaps xmm4, [rsp+0x40]
00007bdc0b3da81a  vmovaps xmm5, [rsp+0x50]
00007bdc0b3da820  vmovaps xmm6, [rsp+0x60]
00007bdc0b3da826  vmovaps xmm7, [rsp+0x70]
00007bdc0b3da82c  vmovaps xmm8, [rsp+0x80]
00007bdc0b3da835  vmovaps xmm9, [rsp+0x90]
00007bdc0b3da83e  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3da847  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3da850  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3da859  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3da862  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3da86b  add rsp, 0xF0
00007bdc0b3da872  pop r11
00007bdc0b3da874  pop r10
00007bdc0b3da876  pop r9
00007bdc0b3da878  pop r8
00007bdc0b3da87a  pop rsi
00007bdc0b3da87b  pop rdi
00007bdc0b3da87c  pop rdx
00007bdc0b3da87d  pop rcx
00007bdc0b3da87e  pop rax
00007bdc0b3da87f  add rsp, 0x08
00007bdc0b3da883  jmp 0x00007BDC0B3D9C92
00007bdc0b3da888  sub rsp, 0x08
00007bdc0b3da88c  push rax
00007bdc0b3da88d  push rcx
00007bdc0b3da88e  push rdx
00007bdc0b3da88f  push rdi
00007bdc0b3da890  push rsi
00007bdc0b3da891  push r8
00007bdc0b3da893  push r9
00007bdc0b3da895  push r10
00007bdc0b3da897  push r11
00007bdc0b3da899  sub rsp, 0xF0
00007bdc0b3da8a0  vmovaps [rsp], xmm0
00007bdc0b3da8a5  vmovaps [rsp+0x10], xmm1
00007bdc0b3da8ab  vmovaps [rsp+0x20], xmm2
00007bdc0b3da8b1  vmovaps [rsp+0x30], xmm3
00007bdc0b3da8b7  vmovaps [rsp+0x40], xmm4
00007bdc0b3da8bd  vmovaps [rsp+0x50], xmm5
00007bdc0b3da8c3  vmovaps [rsp+0x60], xmm6
00007bdc0b3da8c9  vmovaps [rsp+0x70], xmm7
00007bdc0b3da8cf  vmovaps [rsp+0x80], xmm8
00007bdc0b3da8d8  vmovaps [rsp+0x90], xmm9
00007bdc0b3da8e1  vmovaps [rsp+0xA0], xmm10
00007bdc0b3da8ea  vmovaps [rsp+0xB0], xmm11
00007bdc0b3da8f3  vmovaps [rsp+0xC0], xmm13
00007bdc0b3da8fc  vmovaps [rsp+0xD0], xmm14
00007bdc0b3da905  vmovaps [rsp+0xE0], xmm15
00007bdc0b3da90e  sub rsp, 0x40
00007bdc0b3da912  lea rdi, [rsp]
00007bdc0b3da916  lea rsi, [rsp+0x10]
00007bdc0b3da91b  lea rdx, [rsp+0x20]
00007bdc0b3da920  lea rcx, [rsp+0x30]
00007bdc0b3da925  mov r8d, 0x00
00007bdc0b3da92b  lea r9, [r15+0x3A8]
00007bdc0b3da932  movaps [rdi], xmm12
00007bdc0b3da936  movaps [rsi], xmm15
00007bdc0b3da93a  movaps [rdx], xmm1
00007bdc0b3da93d  movaps [rcx], xmm14
00007bdc0b3da941  mov rax, 0x62CE440F2A50
00007bdc0b3da94b  call rax
00007bdc0b3da94d  movaps xmm12, [rsp]
00007bdc0b3da952  add rsp, 0x40
00007bdc0b3da956  vmovaps xmm0, [rsp]
00007bdc0b3da95b  vmovaps xmm1, [rsp+0x10]
00007bdc0b3da961  vmovaps xmm2, [rsp+0x20]
00007bdc0b3da967  vmovaps xmm3, [rsp+0x30]
00007bdc0b3da96d  vmovaps xmm4, [rsp+0x40]
00007bdc0b3da973  vmovaps xmm5, [rsp+0x50]
00007bdc0b3da979  vmovaps xmm6, [rsp+0x60]
00007bdc0b3da97f  vmovaps xmm7, [rsp+0x70]
00007bdc0b3da985  vmovaps xmm8, [rsp+0x80]
00007bdc0b3da98e  vmovaps xmm9, [rsp+0x90]
00007bdc0b3da997  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3da9a0  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3da9a9  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3da9b2  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3da9bb  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3da9c4  add rsp, 0xF0
00007bdc0b3da9cb  pop r11
00007bdc0b3da9cd  pop r10
00007bdc0b3da9cf  pop r9
00007bdc0b3da9d1  pop r8
00007bdc0b3da9d3  pop rsi
00007bdc0b3da9d4  pop rdi
00007bdc0b3da9d5  pop rdx
00007bdc0b3da9d6  pop rcx
00007bdc0b3da9d7  pop rax
00007bdc0b3da9d8  add rsp, 0x08
00007bdc0b3da9dc  jmp 0x00007BDC0B3D9CC0
00007bdc0b3da9e1  call 0x00007BDC0B2B52F0
00007bdc0b3da9e6  jmp 0x00007BDC0B3D9DAC
00007bdc0b3da9eb  sub rsp, 0x08
00007bdc0b3da9ef  push rax
00007bdc0b3da9f0  push rcx
00007bdc0b3da9f1  push rdx
00007bdc0b3da9f2  push rdi
00007bdc0b3da9f3  push rsi
00007bdc0b3da9f4  push r8
00007bdc0b3da9f6  push r9
00007bdc0b3da9f8  push r10
00007bdc0b3da9fa  push r11
00007bdc0b3da9fc  sub rsp, 0xF0
00007bdc0b3daa03  vmovaps [rsp], xmm0
00007bdc0b3daa08  vmovaps [rsp+0x10], xmm1
00007bdc0b3daa0e  vmovaps [rsp+0x20], xmm2
00007bdc0b3daa14  vmovaps [rsp+0x30], xmm3
00007bdc0b3daa1a  vmovaps [rsp+0x40], xmm4
00007bdc0b3daa20  vmovaps [rsp+0x50], xmm5
00007bdc0b3daa26  vmovaps [rsp+0x60], xmm6
00007bdc0b3daa2c  vmovaps [rsp+0x70], xmm7
00007bdc0b3daa32  vmovaps [rsp+0x80], xmm8
00007bdc0b3daa3b  vmovaps [rsp+0x90], xmm9
00007bdc0b3daa44  vmovaps [rsp+0xA0], xmm10
00007bdc0b3daa4d  vmovaps [rsp+0xB0], xmm11
00007bdc0b3daa56  vmovaps [rsp+0xC0], xmm12
00007bdc0b3daa5f  vmovaps [rsp+0xD0], xmm14
00007bdc0b3daa68  vmovaps [rsp+0xE0], xmm15
00007bdc0b3daa71  sub rsp, 0x40
00007bdc0b3daa75  lea rdi, [rsp]
00007bdc0b3daa79  lea rsi, [rsp+0x10]
00007bdc0b3daa7e  lea rdx, [rsp+0x20]
00007bdc0b3daa83  lea rcx, [rsp+0x30]
00007bdc0b3daa88  mov r8d, 0x00
00007bdc0b3daa8e  lea r9, [r15+0x3A8]
00007bdc0b3daa95  movaps [rdi], xmm13
00007bdc0b3daa99  movaps [rsi], xmm1
00007bdc0b3daa9c  movaps [rdx], xmm15
00007bdc0b3daaa0  movaps [rcx], xmm14
00007bdc0b3daaa4  mov rax, 0x62CE440F2A50
00007bdc0b3daaae  call rax
00007bdc0b3daab0  movaps xmm13, [rsp]
00007bdc0b3daab5  add rsp, 0x40
00007bdc0b3daab9  vmovaps xmm0, [rsp]
00007bdc0b3daabe  vmovaps xmm1, [rsp+0x10]
00007bdc0b3daac4  vmovaps xmm2, [rsp+0x20]
00007bdc0b3daaca  vmovaps xmm3, [rsp+0x30]
00007bdc0b3daad0  vmovaps xmm4, [rsp+0x40]
00007bdc0b3daad6  vmovaps xmm5, [rsp+0x50]
00007bdc0b3daadc  vmovaps xmm6, [rsp+0x60]
00007bdc0b3daae2  vmovaps xmm7, [rsp+0x70]
00007bdc0b3daae8  vmovaps xmm8, [rsp+0x80]
00007bdc0b3daaf1  vmovaps xmm9, [rsp+0x90]
00007bdc0b3daafa  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3dab03  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3dab0c  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3dab15  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dab1e  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dab27  add rsp, 0xF0
00007bdc0b3dab2e  pop r11
00007bdc0b3dab30  pop r10
00007bdc0b3dab32  pop r9
00007bdc0b3dab34  pop r8
00007bdc0b3dab36  pop rsi
00007bdc0b3dab37  pop rdi
00007bdc0b3dab38  pop rdx
00007bdc0b3dab39  pop rcx
00007bdc0b3dab3a  pop rax
00007bdc0b3dab3b  add rsp, 0x08
00007bdc0b3dab3f  jmp 0x00007BDC0B3D9E21
00007bdc0b3dab44  call 0x00007BDC0B1FF430
00007bdc0b3dab49  jmp 0x00007BDC0B3D9E2E
00007bdc0b3dab4e  sub rsp, 0x08
00007bdc0b3dab52  push rax
00007bdc0b3dab53  push rcx
00007bdc0b3dab54  push rdx
00007bdc0b3dab55  push rdi
00007bdc0b3dab56  push rsi
00007bdc0b3dab57  push r8
00007bdc0b3dab59  push r9
00007bdc0b3dab5b  push r10
00007bdc0b3dab5d  push r11
00007bdc0b3dab5f  sub rsp, 0xF0
00007bdc0b3dab66  vmovaps [rsp], xmm0
00007bdc0b3dab6b  vmovaps [rsp+0x10], xmm1
00007bdc0b3dab71  vmovaps [rsp+0x20], xmm2
00007bdc0b3dab77  vmovaps [rsp+0x30], xmm3
00007bdc0b3dab7d  vmovaps [rsp+0x40], xmm4
00007bdc0b3dab83  vmovaps [rsp+0x50], xmm5
00007bdc0b3dab89  vmovaps [rsp+0x60], xmm6
00007bdc0b3dab8f  vmovaps [rsp+0x70], xmm7
00007bdc0b3dab95  vmovaps [rsp+0x80], xmm8
00007bdc0b3dab9e  vmovaps [rsp+0x90], xmm9
00007bdc0b3daba7  vmovaps [rsp+0xA0], xmm10
00007bdc0b3dabb0  vmovaps [rsp+0xB0], xmm11
00007bdc0b3dabb9  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dabc2  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dabcb  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dabd4  sub rsp, 0x40
00007bdc0b3dabd8  lea rdi, [rsp]
00007bdc0b3dabdc  lea rsi, [rsp+0x10]
00007bdc0b3dabe1  lea rdx, [rsp+0x20]
00007bdc0b3dabe6  lea rcx, [rsp+0x30]
00007bdc0b3dabeb  mov r8d, 0x00
00007bdc0b3dabf1  lea r9, [r15+0x3A8]
00007bdc0b3dabf8  movaps [rdi], xmm12
00007bdc0b3dabfc  movaps [rsi], xmm15
00007bdc0b3dac00  movaps [rdx], xmm1
00007bdc0b3dac03  movaps [rcx], xmm14
00007bdc0b3dac07  mov rax, 0x62CE440F2A50
00007bdc0b3dac11  call rax
00007bdc0b3dac13  movaps xmm12, [rsp]
00007bdc0b3dac18  add rsp, 0x40
00007bdc0b3dac1c  vmovaps xmm0, [rsp]
00007bdc0b3dac21  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dac27  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dac2d  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dac33  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dac39  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dac3f  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dac45  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dac4b  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dac54  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dac5d  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3dac66  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3dac6f  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dac78  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dac81  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dac8a  add rsp, 0xF0
00007bdc0b3dac91  pop r11
00007bdc0b3dac93  pop r10
00007bdc0b3dac95  pop r9
00007bdc0b3dac97  pop r8
00007bdc0b3dac99  pop rsi
00007bdc0b3dac9a  pop rdi
00007bdc0b3dac9b  pop rdx
00007bdc0b3dac9c  pop rcx
00007bdc0b3dac9d  pop rax
00007bdc0b3dac9e  add rsp, 0x08
00007bdc0b3daca2  jmp 0x00007BDC0B3D9E5A
00007bdc0b3daca7  sub rsp, 0x08
00007bdc0b3dacab  push rax
00007bdc0b3dacac  push rcx
00007bdc0b3dacad  push rdx
00007bdc0b3dacae  push rdi
00007bdc0b3dacaf  push rsi
00007bdc0b3dacb0  push r8
00007bdc0b3dacb2  push r9
00007bdc0b3dacb4  push r10
00007bdc0b3dacb6  push r11
00007bdc0b3dacb8  sub rsp, 0xF0
00007bdc0b3dacbf  vmovaps [rsp], xmm0
00007bdc0b3dacc4  vmovaps [rsp+0x10], xmm1
00007bdc0b3dacca  vmovaps [rsp+0x20], xmm2
00007bdc0b3dacd0  vmovaps [rsp+0x30], xmm3
00007bdc0b3dacd6  vmovaps [rsp+0x40], xmm4
00007bdc0b3dacdc  vmovaps [rsp+0x50], xmm5
00007bdc0b3dace2  vmovaps [rsp+0x60], xmm6
00007bdc0b3dace8  vmovaps [rsp+0x70], xmm7
00007bdc0b3dacee  vmovaps [rsp+0x80], xmm8
00007bdc0b3dacf7  vmovaps [rsp+0x90], xmm9
00007bdc0b3dad00  vmovaps [rsp+0xA0], xmm10
00007bdc0b3dad09  vmovaps [rsp+0xB0], xmm11
00007bdc0b3dad12  vmovaps [rsp+0xC0], xmm12
00007bdc0b3dad1b  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dad24  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dad2d  sub rsp, 0x40
00007bdc0b3dad31  lea rdi, [rsp]
00007bdc0b3dad35  lea rsi, [rsp+0x10]
00007bdc0b3dad3a  lea rdx, [rsp+0x20]
00007bdc0b3dad3f  lea rcx, [rsp+0x30]
00007bdc0b3dad44  mov r8d, 0x00
00007bdc0b3dad4a  lea r9, [r15+0x3A8]
00007bdc0b3dad51  movaps [rdi], xmm13
00007bdc0b3dad55  movaps [rsi], xmm1
00007bdc0b3dad58  movaps [rdx], xmm15
00007bdc0b3dad5c  movaps [rcx], xmm14
00007bdc0b3dad60  mov rax, 0x62CE440F2A50
00007bdc0b3dad6a  call rax
00007bdc0b3dad6c  movaps xmm13, [rsp]
00007bdc0b3dad71  add rsp, 0x40
00007bdc0b3dad75  vmovaps xmm0, [rsp]
00007bdc0b3dad7a  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dad80  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dad86  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dad8c  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dad92  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dad98  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dad9e  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dada4  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dadad  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dadb6  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3dadbf  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3dadc8  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3dadd1  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dadda  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dade3  add rsp, 0xF0
00007bdc0b3dadea  pop r11
00007bdc0b3dadec  pop r10
00007bdc0b3dadee  pop r9
00007bdc0b3dadf0  pop r8
00007bdc0b3dadf2  pop rsi
00007bdc0b3dadf3  pop rdi
00007bdc0b3dadf4  pop rdx
00007bdc0b3dadf5  pop rcx
00007bdc0b3dadf6  pop rax
00007bdc0b3dadf7  add rsp, 0x08
00007bdc0b3dadfb  jmp 0x00007BDC0B3D9FEA
00007bdc0b3dae00  sub rsp, 0x08
00007bdc0b3dae04  push rax
00007bdc0b3dae05  push rcx
00007bdc0b3dae06  push rdx
00007bdc0b3dae07  push rdi
00007bdc0b3dae08  push rsi
00007bdc0b3dae09  push r8
00007bdc0b3dae0b  push r9
00007bdc0b3dae0d  push r10
00007bdc0b3dae0f  push r11
00007bdc0b3dae11  sub rsp, 0xF0
00007bdc0b3dae18  vmovaps [rsp], xmm0
00007bdc0b3dae1d  vmovaps [rsp+0x10], xmm1
00007bdc0b3dae23  vmovaps [rsp+0x20], xmm2
00007bdc0b3dae29  vmovaps [rsp+0x30], xmm3
00007bdc0b3dae2f  vmovaps [rsp+0x40], xmm4
00007bdc0b3dae35  vmovaps [rsp+0x50], xmm5
00007bdc0b3dae3b  vmovaps [rsp+0x60], xmm6
00007bdc0b3dae41  vmovaps [rsp+0x70], xmm7
00007bdc0b3dae47  vmovaps [rsp+0x80], xmm8
00007bdc0b3dae50  vmovaps [rsp+0x90], xmm9
00007bdc0b3dae59  vmovaps [rsp+0xA0], xmm10
00007bdc0b3dae62  vmovaps [rsp+0xB0], xmm11
00007bdc0b3dae6b  vmovaps [rsp+0xC0], xmm12
00007bdc0b3dae74  vmovaps [rsp+0xD0], xmm13
00007bdc0b3dae7d  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dae86  sub rsp, 0x40
00007bdc0b3dae8a  lea rdi, [rsp]
00007bdc0b3dae8e  lea rsi, [rsp+0x10]
00007bdc0b3dae93  lea rdx, [rsp+0x20]
00007bdc0b3dae98  lea rcx, [rsp+0x30]
00007bdc0b3dae9d  mov r8d, 0x00
00007bdc0b3daea3  lea r9, [r15+0x3A8]
00007bdc0b3daeaa  movaps [rdi], xmm14
00007bdc0b3daeae  movaps [rsi], xmm15
00007bdc0b3daeb2  movaps [rdx], xmm2
00007bdc0b3daeb5  movaps [rcx], xmm1
00007bdc0b3daeb8  mov rax, 0x62CE440F2A50
00007bdc0b3daec2  call rax
00007bdc0b3daec4  movaps xmm14, [rsp]
00007bdc0b3daec9  add rsp, 0x40
00007bdc0b3daecd  vmovaps xmm0, [rsp]
00007bdc0b3daed2  vmovaps xmm1, [rsp+0x10]
00007bdc0b3daed8  vmovaps xmm2, [rsp+0x20]
00007bdc0b3daede  vmovaps xmm3, [rsp+0x30]
00007bdc0b3daee4  vmovaps xmm4, [rsp+0x40]
00007bdc0b3daeea  vmovaps xmm5, [rsp+0x50]
00007bdc0b3daef0  vmovaps xmm6, [rsp+0x60]
00007bdc0b3daef6  vmovaps xmm7, [rsp+0x70]
00007bdc0b3daefc  vmovaps xmm8, [rsp+0x80]
00007bdc0b3daf05  vmovaps xmm9, [rsp+0x90]
00007bdc0b3daf0e  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3daf17  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3daf20  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3daf29  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3daf32  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3daf3b  add rsp, 0xF0
00007bdc0b3daf42  pop r11
00007bdc0b3daf44  pop r10
00007bdc0b3daf46  pop r9
00007bdc0b3daf48  pop r8
00007bdc0b3daf4a  pop rsi
00007bdc0b3daf4b  pop rdi
00007bdc0b3daf4c  pop rdx
00007bdc0b3daf4d  pop rcx
00007bdc0b3daf4e  pop rax
00007bdc0b3daf4f  add rsp, 0x08
00007bdc0b3daf53  jmp 0x00007BDC0B3DA01C
00007bdc0b3daf58  sub rsp, 0x08
00007bdc0b3daf5c  push rax
00007bdc0b3daf5d  push rcx
00007bdc0b3daf5e  push rdx
00007bdc0b3daf5f  push rdi
00007bdc0b3daf60  push rsi
00007bdc0b3daf61  push r8
00007bdc0b3daf63  push r9
00007bdc0b3daf65  push r10
00007bdc0b3daf67  push r11
00007bdc0b3daf69  sub rsp, 0xF0
00007bdc0b3daf70  vmovaps [rsp], xmm0
00007bdc0b3daf75  vmovaps [rsp+0x10], xmm1
00007bdc0b3daf7b  vmovaps [rsp+0x20], xmm3
00007bdc0b3daf81  vmovaps [rsp+0x30], xmm4
00007bdc0b3daf87  vmovaps [rsp+0x40], xmm5
00007bdc0b3daf8d  vmovaps [rsp+0x50], xmm6
00007bdc0b3daf93  vmovaps [rsp+0x60], xmm7
00007bdc0b3daf99  vmovaps [rsp+0x70], xmm8
00007bdc0b3daf9f  vmovaps [rsp+0x80], xmm9
00007bdc0b3dafa8  vmovaps [rsp+0x90], xmm10
00007bdc0b3dafb1  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dafba  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dafc3  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dafcc  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dafd5  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dafde  sub rsp, 0x40
00007bdc0b3dafe2  lea rdi, [rsp]
00007bdc0b3dafe6  lea rsi, [rsp+0x10]
00007bdc0b3dafeb  lea rdx, [rsp+0x20]
00007bdc0b3daff0  lea rcx, [rsp+0x30]
00007bdc0b3daff5  mov r8d, 0x00
00007bdc0b3daffb  lea r9, [r15+0x3A8]
00007bdc0b3db002  movaps [rdi], xmm2
00007bdc0b3db005  movaps [rsi], xmm15
00007bdc0b3db009  movaps [rdx], xmm12
00007bdc0b3db00d  movaps [rcx], xmm1
00007bdc0b3db010  mov rax, 0x62CE440F2A50
00007bdc0b3db01a  call rax
00007bdc0b3db01c  movaps xmm2, [rsp]
00007bdc0b3db020  add rsp, 0x40
00007bdc0b3db024  vmovaps xmm0, [rsp]
00007bdc0b3db029  vmovaps xmm1, [rsp+0x10]
00007bdc0b3db02f  vmovaps xmm3, [rsp+0x20]
00007bdc0b3db035  vmovaps xmm4, [rsp+0x30]
00007bdc0b3db03b  vmovaps xmm5, [rsp+0x40]
00007bdc0b3db041  vmovaps xmm6, [rsp+0x50]
00007bdc0b3db047  vmovaps xmm7, [rsp+0x60]
00007bdc0b3db04d  vmovaps xmm8, [rsp+0x70]
00007bdc0b3db053  vmovaps xmm9, [rsp+0x80]
00007bdc0b3db05c  vmovaps xmm10, [rsp+0x90]
00007bdc0b3db065  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3db06e  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3db077  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3db080  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3db089  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3db092  add rsp, 0xF0
00007bdc0b3db099  pop r11
00007bdc0b3db09b  pop r10
00007bdc0b3db09d  pop r9
00007bdc0b3db09f  pop r8
00007bdc0b3db0a1  pop rsi
00007bdc0b3db0a2  pop rdi
00007bdc0b3db0a3  pop rdx
00007bdc0b3db0a4  pop rcx
00007bdc0b3db0a5  pop rax
00007bdc0b3db0a6  add rsp, 0x08
00007bdc0b3db0aa  jmp 0x00007BDC0B3DA059
00007bdc0b3db0af  sub rsp, 0x08
00007bdc0b3db0b3  push rax
00007bdc0b3db0b4  push rcx
00007bdc0b3db0b5  push rdx
00007bdc0b3db0b6  push rdi
00007bdc0b3db0b7  push rsi
00007bdc0b3db0b8  push r8
00007bdc0b3db0ba  push r9
00007bdc0b3db0bc  push r10
00007bdc0b3db0be  push r11
00007bdc0b3db0c0  sub rsp, 0xF0
00007bdc0b3db0c7  vmovaps [rsp], xmm0
00007bdc0b3db0cc  vmovaps [rsp+0x10], xmm1
00007bdc0b3db0d2  vmovaps [rsp+0x20], xmm2
00007bdc0b3db0d8  vmovaps [rsp+0x30], xmm3
00007bdc0b3db0de  vmovaps [rsp+0x40], xmm4
00007bdc0b3db0e4  vmovaps [rsp+0x50], xmm5
00007bdc0b3db0ea  vmovaps [rsp+0x60], xmm6
00007bdc0b3db0f0  vmovaps [rsp+0x70], xmm7
00007bdc0b3db0f6  vmovaps [rsp+0x80], xmm8
00007bdc0b3db0ff  vmovaps [rsp+0x90], xmm9
00007bdc0b3db108  vmovaps [rsp+0xA0], xmm10
00007bdc0b3db111  vmovaps [rsp+0xB0], xmm11
00007bdc0b3db11a  vmovaps [rsp+0xC0], xmm13
00007bdc0b3db123  vmovaps [rsp+0xD0], xmm14
00007bdc0b3db12c  vmovaps [rsp+0xE0], xmm15
00007bdc0b3db135  sub rsp, 0x40
00007bdc0b3db139  lea rdi, [rsp]
00007bdc0b3db13d  lea rsi, [rsp+0x10]
00007bdc0b3db142  lea rdx, [rsp+0x20]
00007bdc0b3db147  lea rcx, [rsp+0x30]
00007bdc0b3db14c  mov r8d, 0x00
00007bdc0b3db152  lea r9, [r15+0x3A8]
00007bdc0b3db159  movaps [rdi], xmm12
00007bdc0b3db15d  movaps [rsi], xmm14
00007bdc0b3db161  movaps [rdx], xmm3
00007bdc0b3db164  movaps [rcx], xmm15
00007bdc0b3db168  mov rax, 0x62CE440F2A50
00007bdc0b3db172  call rax
00007bdc0b3db174  movaps xmm12, [rsp]
00007bdc0b3db179  add rsp, 0x40
00007bdc0b3db17d  vmovaps xmm0, [rsp]
00007bdc0b3db182  vmovaps xmm1, [rsp+0x10]
00007bdc0b3db188  vmovaps xmm2, [rsp+0x20]
00007bdc0b3db18e  vmovaps xmm3, [rsp+0x30]
00007bdc0b3db194  vmovaps xmm4, [rsp+0x40]
00007bdc0b3db19a  vmovaps xmm5, [rsp+0x50]
00007bdc0b3db1a0  vmovaps xmm6, [rsp+0x60]
00007bdc0b3db1a6  vmovaps xmm7, [rsp+0x70]
00007bdc0b3db1ac  vmovaps xmm8, [rsp+0x80]
00007bdc0b3db1b5  vmovaps xmm9, [rsp+0x90]
00007bdc0b3db1be  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3db1c7  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3db1d0  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3db1d9  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3db1e2  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3db1eb  add rsp, 0xF0
00007bdc0b3db1f2  pop r11
00007bdc0b3db1f4  pop r10
00007bdc0b3db1f6  pop r9
00007bdc0b3db1f8  pop r8
00007bdc0b3db1fa  pop rsi
00007bdc0b3db1fb  pop rdi
00007bdc0b3db1fc  pop rdx
00007bdc0b3db1fd  pop rcx
00007bdc0b3db1fe  pop rax
00007bdc0b3db1ff  add rsp, 0x08
00007bdc0b3db203  jmp 0x00007BDC0B3DA0B3
00007bdc0b3db208  sub rsp, 0x08
00007bdc0b3db20c  push rax
00007bdc0b3db20d  push rcx
00007bdc0b3db20e  push rdx
00007bdc0b3db20f  push rdi
00007bdc0b3db210  push rsi
00007bdc0b3db211  push r8
00007bdc0b3db213  push r9
00007bdc0b3db215  push r10
00007bdc0b3db217  push r11
00007bdc0b3db219  sub rsp, 0xF0
00007bdc0b3db220  vmovaps [rsp], xmm0
00007bdc0b3db225  vmovaps [rsp+0x10], xmm1
00007bdc0b3db22b  vmovaps [rsp+0x20], xmm2
00007bdc0b3db231  vmovaps [rsp+0x30], xmm3
00007bdc0b3db237  vmovaps [rsp+0x40], xmm4
00007bdc0b3db23d  vmovaps [rsp+0x50], xmm5
00007bdc0b3db243  vmovaps [rsp+0x60], xmm6
00007bdc0b3db249  vmovaps [rsp+0x70], xmm7
00007bdc0b3db24f  vmovaps [rsp+0x80], xmm8
00007bdc0b3db258  vmovaps [rsp+0x90], xmm10
00007bdc0b3db261  vmovaps [rsp+0xA0], xmm11
00007bdc0b3db26a  vmovaps [rsp+0xB0], xmm12
00007bdc0b3db273  vmovaps [rsp+0xC0], xmm13
00007bdc0b3db27c  vmovaps [rsp+0xD0], xmm14
00007bdc0b3db285  vmovaps [rsp+0xE0], xmm15
00007bdc0b3db28e  sub rsp, 0x40
00007bdc0b3db292  lea rdi, [rsp]
00007bdc0b3db296  lea rsi, [rsp+0x10]
00007bdc0b3db29b  lea rdx, [rsp+0x20]
00007bdc0b3db2a0  lea rcx, [rsp+0x30]
00007bdc0b3db2a5  mov r8d, 0x00
00007bdc0b3db2ab  lea r9, [r15+0x3A8]
00007bdc0b3db2b2  movaps [rdi], xmm9
00007bdc0b3db2b6  movaps [rsi], xmm13
00007bdc0b3db2ba  movaps [rdx], xmm14
00007bdc0b3db2be  movaps [rcx], xmm6
00007bdc0b3db2c1  mov rax, 0x62CE440F2A50
00007bdc0b3db2cb  call rax
00007bdc0b3db2cd  movaps xmm9, [rsp]
00007bdc0b3db2d2  add rsp, 0x40
00007bdc0b3db2d6  vmovaps xmm0, [rsp]
00007bdc0b3db2db  vmovaps xmm1, [rsp+0x10]
00007bdc0b3db2e1  vmovaps xmm2, [rsp+0x20]
00007bdc0b3db2e7  vmovaps xmm3, [rsp+0x30]
00007bdc0b3db2ed  vmovaps xmm4, [rsp+0x40]
00007bdc0b3db2f3  vmovaps xmm5, [rsp+0x50]
00007bdc0b3db2f9  vmovaps xmm6, [rsp+0x60]
00007bdc0b3db2ff  vmovaps xmm7, [rsp+0x70]
00007bdc0b3db305  vmovaps xmm8, [rsp+0x80]
00007bdc0b3db30e  vmovaps xmm10, [rsp+0x90]
00007bdc0b3db317  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3db320  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3db329  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3db332  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3db33b  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3db344  add rsp, 0xF0
00007bdc0b3db34b  pop r11
00007bdc0b3db34d  pop r10
00007bdc0b3db34f  pop r9
00007bdc0b3db351  pop r8
00007bdc0b3db353  pop rsi
00007bdc0b3db354  pop rdi
00007bdc0b3db355  pop rdx
00007bdc0b3db356  pop rcx
00007bdc0b3db357  pop rax
00007bdc0b3db358  add rsp, 0x08
00007bdc0b3db35c  jmp 0x00007BDC0B3DA15D
00007bdc0b3db361  sub rsp, 0x08
00007bdc0b3db365  push rax
00007bdc0b3db366  push rcx
00007bdc0b3db367  push rdx
00007bdc0b3db368  push rdi
00007bdc0b3db369  push rsi
00007bdc0b3db36a  push r8
00007bdc0b3db36c  push r9
00007bdc0b3db36e  push r10
00007bdc0b3db370  push r11
00007bdc0b3db372  sub rsp, 0xF0
00007bdc0b3db379  vmovaps [rsp], xmm0
00007bdc0b3db37e  vmovaps [rsp+0x10], xmm1
00007bdc0b3db384  vmovaps [rsp+0x20], xmm2
00007bdc0b3db38a  vmovaps [rsp+0x30], xmm4
00007bdc0b3db390  vmovaps [rsp+0x40], xmm5
00007bdc0b3db396  vmovaps [rsp+0x50], xmm6
00007bdc0b3db39c  vmovaps [rsp+0x60], xmm7
00007bdc0b3db3a2  vmovaps [rsp+0x70], xmm8
00007bdc0b3db3a8  vmovaps [rsp+0x80], xmm9
00007bdc0b3db3b1  vmovaps [rsp+0x90], xmm10
00007bdc0b3db3ba  vmovaps [rsp+0xA0], xmm11
00007bdc0b3db3c3  vmovaps [rsp+0xB0], xmm12
00007bdc0b3db3cc  vmovaps [rsp+0xC0], xmm13
00007bdc0b3db3d5  vmovaps [rsp+0xD0], xmm14
00007bdc0b3db3de  vmovaps [rsp+0xE0], xmm15
00007bdc0b3db3e7  sub rsp, 0x40
00007bdc0b3db3eb  lea rdi, [rsp]
00007bdc0b3db3ef  lea rsi, [rsp+0x10]
00007bdc0b3db3f4  lea rdx, [rsp+0x20]
00007bdc0b3db3f9  lea rcx, [rsp+0x30]
00007bdc0b3db3fe  mov r8d, 0x00
00007bdc0b3db404  lea r9, [r15+0x3A8]
00007bdc0b3db40b  movaps [rdi], xmm3
00007bdc0b3db40e  movaps [rsi], xmm13
00007bdc0b3db412  movaps [rdx], xmm6
00007bdc0b3db415  movaps [rcx], xmm14
00007bdc0b3db419  mov rax, 0x62CE440F2A50
00007bdc0b3db423  call rax
00007bdc0b3db425  movaps xmm3, [rsp]
00007bdc0b3db429  add rsp, 0x40
00007bdc0b3db42d  vmovaps xmm0, [rsp]
00007bdc0b3db432  vmovaps xmm1, [rsp+0x10]
00007bdc0b3db438  vmovaps xmm2, [rsp+0x20]
00007bdc0b3db43e  vmovaps xmm4, [rsp+0x30]
00007bdc0b3db444  vmovaps xmm5, [rsp+0x40]
00007bdc0b3db44a  vmovaps xmm6, [rsp+0x50]
00007bdc0b3db450  vmovaps xmm7, [rsp+0x60]
00007bdc0b3db456  vmovaps xmm8, [rsp+0x70]
00007bdc0b3db45c  vmovaps xmm9, [rsp+0x80]
00007bdc0b3db465  vmovaps xmm10, [rsp+0x90]
00007bdc0b3db46e  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3db477  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3db480  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3db489  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3db492  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3db49b  add rsp, 0xF0
00007bdc0b3db4a2  pop r11
00007bdc0b3db4a4  pop r10
00007bdc0b3db4a6  pop r9
00007bdc0b3db4a8  pop r8
00007bdc0b3db4aa  pop rsi
00007bdc0b3db4ab  pop rdi
00007bdc0b3db4ac  pop rdx
00007bdc0b3db4ad  pop rcx
00007bdc0b3db4ae  pop rax
00007bdc0b3db4af  add rsp, 0x08
00007bdc0b3db4b3  jmp 0x00007BDC0B3DA19A
00007bdc0b3db4b8  sub rsp, 0x08
00007bdc0b3db4bc  push rax
00007bdc0b3db4bd  push rcx
00007bdc0b3db4be  push rdx
00007bdc0b3db4bf  push rdi
00007bdc0b3db4c0  push rsi
00007bdc0b3db4c1  push r8
00007bdc0b3db4c3  push r9
00007bdc0b3db4c5  push r10
00007bdc0b3db4c7  push r11
00007bdc0b3db4c9  sub rsp, 0xF0
00007bdc0b3db4d0  vmovaps [rsp], xmm0
00007bdc0b3db4d5  vmovaps [rsp+0x10], xmm1
00007bdc0b3db4db  vmovaps [rsp+0x20], xmm2
00007bdc0b3db4e1  vmovaps [rsp+0x30], xmm3
00007bdc0b3db4e7  vmovaps [rsp+0x40], xmm4
00007bdc0b3db4ed  vmovaps [rsp+0x50], xmm5
00007bdc0b3db4f3  vmovaps [rsp+0x60], xmm7
00007bdc0b3db4f9  vmovaps [rsp+0x70], xmm8
00007bdc0b3db4ff  vmovaps [rsp+0x80], xmm9
00007bdc0b3db508  vmovaps [rsp+0x90], xmm10
00007bdc0b3db511  vmovaps [rsp+0xA0], xmm11
00007bdc0b3db51a  vmovaps [rsp+0xB0], xmm12
00007bdc0b3db523  vmovaps [rsp+0xC0], xmm13
00007bdc0b3db52c  vmovaps [rsp+0xD0], xmm14
00007bdc0b3db535  vmovaps [rsp+0xE0], xmm15
00007bdc0b3db53e  sub rsp, 0x40
00007bdc0b3db542  lea rdi, [rsp]
00007bdc0b3db546  lea rsi, [rsp+0x10]
00007bdc0b3db54b  lea rdx, [rsp+0x20]
00007bdc0b3db550  lea rcx, [rsp+0x30]
00007bdc0b3db555  mov r8d, 0x00
00007bdc0b3db55b  lea r9, [r15+0x3A8]
00007bdc0b3db562  movaps [rdi], xmm6
00007bdc0b3db565  movaps [rsi], xmm2
00007bdc0b3db568  movaps [rdx], xmm14
00007bdc0b3db56c  movaps [rcx], xmm1
00007bdc0b3db56f  mov rax, 0x62CE440F2A50
00007bdc0b3db579  call rax
00007bdc0b3db57b  movaps xmm6, [rsp]
00007bdc0b3db57f  add rsp, 0x40
00007bdc0b3db583  vmovaps xmm0, [rsp]
00007bdc0b3db588  vmovaps xmm1, [rsp+0x10]
00007bdc0b3db58e  vmovaps xmm2, [rsp+0x20]
00007bdc0b3db594  vmovaps xmm3, [rsp+0x30]
00007bdc0b3db59a  vmovaps xmm4, [rsp+0x40]
00007bdc0b3db5a0  vmovaps xmm5, [rsp+0x50]
00007bdc0b3db5a6  vmovaps xmm7, [rsp+0x60]
00007bdc0b3db5ac  vmovaps xmm8, [rsp+0x70]
00007bdc0b3db5b2  vmovaps xmm9, [rsp+0x80]
00007bdc0b3db5bb  vmovaps xmm10, [rsp+0x90]
00007bdc0b3db5c4  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3db5cd  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3db5d6  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3db5df  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3db5e8  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3db5f1  add rsp, 0xF0
00007bdc0b3db5f8  pop r11
00007bdc0b3db5fa  pop r10
00007bdc0b3db5fc  pop r9
00007bdc0b3db5fe  pop r8
00007bdc0b3db600  pop rsi
00007bdc0b3db601  pop rdi
00007bdc0b3db602  pop rdx
00007bdc0b3db603  pop rcx
00007bdc0b3db604  pop rax
00007bdc0b3db605  add rsp, 0x08
00007bdc0b3db609  jmp 0x00007BDC0B3DA1C7
00007bdc0b3db60e  sub rsp, 0x08
00007bdc0b3db612  push rax
00007bdc0b3db613  push rcx
00007bdc0b3db614  push rdx
00007bdc0b3db615  push rdi
00007bdc0b3db616  push rsi
00007bdc0b3db617  push r8
00007bdc0b3db619  push r9
00007bdc0b3db61b  push r10
00007bdc0b3db61d  push r11
00007bdc0b3db61f  sub rsp, 0xF0
00007bdc0b3db626  vmovaps [rsp], xmm0
00007bdc0b3db62b  vmovaps [rsp+0x10], xmm1
00007bdc0b3db631  vmovaps [rsp+0x20], xmm2
00007bdc0b3db637  vmovaps [rsp+0x30], xmm3
00007bdc0b3db63d  vmovaps [rsp+0x40], xmm4
00007bdc0b3db643  vmovaps [rsp+0x50], xmm5
00007bdc0b3db649  vmovaps [rsp+0x60], xmm6
00007bdc0b3db64f  vmovaps [rsp+0x70], xmm7
00007bdc0b3db655  vmovaps [rsp+0x80], xmm8
00007bdc0b3db65e  vmovaps [rsp+0x90], xmm9
00007bdc0b3db667  vmovaps [rsp+0xA0], xmm10
00007bdc0b3db670  vmovaps [rsp+0xB0], xmm11
00007bdc0b3db679  vmovaps [rsp+0xC0], xmm12
00007bdc0b3db682  vmovaps [rsp+0xD0], xmm14
00007bdc0b3db68b  vmovaps [rsp+0xE0], xmm15
00007bdc0b3db694  sub rsp, 0x40
00007bdc0b3db698  lea rdi, [rsp]
00007bdc0b3db69c  lea rsi, [rsp+0x10]
00007bdc0b3db6a1  lea rdx, [rsp+0x20]
00007bdc0b3db6a6  lea rcx, [rsp+0x30]
00007bdc0b3db6ab  mov r8d, 0x00
00007bdc0b3db6b1  lea r9, [r15+0x3A8]
00007bdc0b3db6b8  movaps [rdi], xmm13
00007bdc0b3db6bc  movaps [rsi], xmm12
00007bdc0b3db6c0  movaps [rdx], xmm14
00007bdc0b3db6c4  movaps [rcx], xmm1
00007bdc0b3db6c7  mov rax, 0x62CE440F2A50
00007bdc0b3db6d1  call rax
00007bdc0b3db6d3  movaps xmm13, [rsp]
00007bdc0b3db6d8  add rsp, 0x40
00007bdc0b3db6dc  vmovaps xmm0, [rsp]
00007bdc0b3db6e1  vmovaps xmm1, [rsp+0x10]
00007bdc0b3db6e7  vmovaps xmm2, [rsp+0x20]
00007bdc0b3db6ed  vmovaps xmm3, [rsp+0x30]
00007bdc0b3db6f3  vmovaps xmm4, [rsp+0x40]
00007bdc0b3db6f9  vmovaps xmm5, [rsp+0x50]
00007bdc0b3db6ff  vmovaps xmm6, [rsp+0x60]
00007bdc0b3db705  vmovaps xmm7, [rsp+0x70]
00007bdc0b3db70b  vmovaps xmm8, [rsp+0x80]
00007bdc0b3db714  vmovaps xmm9, [rsp+0x90]
00007bdc0b3db71d  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3db726  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3db72f  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3db738  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3db741  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3db74a  add rsp, 0xF0
00007bdc0b3db751  pop r11
00007bdc0b3db753  pop r10
00007bdc0b3db755  pop r9
00007bdc0b3db757  pop r8
00007bdc0b3db759  pop rsi
00007bdc0b3db75a  pop rdi
00007bdc0b3db75b  pop rdx
00007bdc0b3db75c  pop rcx
00007bdc0b3db75d  pop rax
00007bdc0b3db75e  add rsp, 0x08
00007bdc0b3db762  jmp 0x00007BDC0B3DA1F9
00007bdc0b3db767  sub rsp, 0x08
00007bdc0b3db76b  push rax
00007bdc0b3db76c  push rcx
00007bdc0b3db76d  push rdx
00007bdc0b3db76e  push rdi
00007bdc0b3db76f  push rsi
00007bdc0b3db770  push r8
00007bdc0b3db772  push r9
00007bdc0b3db774  push r10
00007bdc0b3db776  push r11
00007bdc0b3db778  sub rsp, 0xF0
00007bdc0b3db77f  vmovaps [rsp], xmm0
00007bdc0b3db784  vmovaps [rsp+0x10], xmm1
00007bdc0b3db78a  vmovaps [rsp+0x20], xmm2
00007bdc0b3db790  vmovaps [rsp+0x30], xmm3
00007bdc0b3db796  vmovaps [rsp+0x40], xmm4
00007bdc0b3db79c  vmovaps [rsp+0x50], xmm5
00007bdc0b3db7a2  vmovaps [rsp+0x60], xmm6
00007bdc0b3db7a8  vmovaps [rsp+0x70], xmm7
00007bdc0b3db7ae  vmovaps [rsp+0x80], xmm8
00007bdc0b3db7b7  vmovaps [rsp+0x90], xmm9
00007bdc0b3db7c0  vmovaps [rsp+0xA0], xmm10
00007bdc0b3db7c9  vmovaps [rsp+0xB0], xmm11
00007bdc0b3db7d2  vmovaps [rsp+0xC0], xmm13
00007bdc0b3db7db  vmovaps [rsp+0xD0], xmm14
00007bdc0b3db7e4  vmovaps [rsp+0xE0], xmm15
00007bdc0b3db7ed  sub rsp, 0x40
00007bdc0b3db7f1  lea rdi, [rsp]
00007bdc0b3db7f5  lea rsi, [rsp+0x10]
00007bdc0b3db7fa  lea rdx, [rsp+0x20]
00007bdc0b3db7ff  lea rcx, [rsp+0x30]
00007bdc0b3db804  mov r8d, 0x00
00007bdc0b3db80a  lea r9, [r15+0x3A8]
00007bdc0b3db811  movaps [rdi], xmm12
00007bdc0b3db815  movaps [rsi], xmm3
00007bdc0b3db818  movaps [rdx], xmm14
00007bdc0b3db81c  movaps [rcx], xmm5
00007bdc0b3db81f  mov rax, 0x62CE440F2A50
00007bdc0b3db829  call rax
00007bdc0b3db82b  movaps xmm12, [rsp]
00007bdc0b3db830  add rsp, 0x40
00007bdc0b3db834  vmovaps xmm0, [rsp]
00007bdc0b3db839  vmovaps xmm1, [rsp+0x10]
00007bdc0b3db83f  vmovaps xmm2, [rsp+0x20]
00007bdc0b3db845  vmovaps xmm3, [rsp+0x30]
00007bdc0b3db84b  vmovaps xmm4, [rsp+0x40]
00007bdc0b3db851  vmovaps xmm5, [rsp+0x50]
00007bdc0b3db857  vmovaps xmm6, [rsp+0x60]
00007bdc0b3db85d  vmovaps xmm7, [rsp+0x70]
00007bdc0b3db863  vmovaps xmm8, [rsp+0x80]
00007bdc0b3db86c  vmovaps xmm9, [rsp+0x90]
00007bdc0b3db875  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3db87e  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3db887  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3db890  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3db899  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3db8a2  add rsp, 0xF0
00007bdc0b3db8a9  pop r11
00007bdc0b3db8ab  pop r10
00007bdc0b3db8ad  pop r9
00007bdc0b3db8af  pop r8
00007bdc0b3db8b1  pop rsi
00007bdc0b3db8b2  pop rdi
00007bdc0b3db8b3  pop rdx
00007bdc0b3db8b4  pop rcx
00007bdc0b3db8b5  pop rax
00007bdc0b3db8b6  add rsp, 0x08
00007bdc0b3db8ba  jmp 0x00007BDC0B3DA256
00007bdc0b3db8bf  sub rsp, 0x08
00007bdc0b3db8c3  push rax
00007bdc0b3db8c4  push rcx
00007bdc0b3db8c5  push rdx
00007bdc0b3db8c6  push rdi
00007bdc0b3db8c7  push rsi
00007bdc0b3db8c8  push r8
00007bdc0b3db8ca  push r9
00007bdc0b3db8cc  push r10
00007bdc0b3db8ce  push r11
00007bdc0b3db8d0  sub rsp, 0xF0
00007bdc0b3db8d7  vmovaps [rsp], xmm0
00007bdc0b3db8dc  vmovaps [rsp+0x10], xmm1
00007bdc0b3db8e2  vmovaps [rsp+0x20], xmm2
00007bdc0b3db8e8  vmovaps [rsp+0x30], xmm3
00007bdc0b3db8ee  vmovaps [rsp+0x40], xmm4
00007bdc0b3db8f4  vmovaps [rsp+0x50], xmm5
00007bdc0b3db8fa  vmovaps [rsp+0x60], xmm6
00007bdc0b3db900  vmovaps [rsp+0x70], xmm7
00007bdc0b3db906  vmovaps [rsp+0x80], xmm8
00007bdc0b3db90f  vmovaps [rsp+0x90], xmm9
00007bdc0b3db918  vmovaps [rsp+0xA0], xmm11
00007bdc0b3db921  vmovaps [rsp+0xB0], xmm12
00007bdc0b3db92a  vmovaps [rsp+0xC0], xmm13
00007bdc0b3db933  vmovaps [rsp+0xD0], xmm14
00007bdc0b3db93c  vmovaps [rsp+0xE0], xmm15
00007bdc0b3db945  sub rsp, 0x40
00007bdc0b3db949  lea rdi, [rsp]
00007bdc0b3db94d  lea rsi, [rsp+0x10]
00007bdc0b3db952  lea rdx, [rsp+0x20]
00007bdc0b3db957  lea rcx, [rsp+0x30]
00007bdc0b3db95c  mov r8d, 0x00
00007bdc0b3db962  lea r9, [r15+0x3A8]
00007bdc0b3db969  movaps [rdi], xmm10
00007bdc0b3db96d  movaps [rsi], xmm9
00007bdc0b3db971  movaps [rdx], xmm7
00007bdc0b3db974  movaps [rcx], xmm14
00007bdc0b3db978  mov rax, 0x62CE440F2A50
00007bdc0b3db982  call rax
00007bdc0b3db984  movaps xmm10, [rsp]
00007bdc0b3db989  add rsp, 0x40
00007bdc0b3db98d  vmovaps xmm0, [rsp]
00007bdc0b3db992  vmovaps xmm1, [rsp+0x10]
00007bdc0b3db998  vmovaps xmm2, [rsp+0x20]
00007bdc0b3db99e  vmovaps xmm3, [rsp+0x30]
00007bdc0b3db9a4  vmovaps xmm4, [rsp+0x40]
00007bdc0b3db9aa  vmovaps xmm5, [rsp+0x50]
00007bdc0b3db9b0  vmovaps xmm6, [rsp+0x60]
00007bdc0b3db9b6  vmovaps xmm7, [rsp+0x70]
00007bdc0b3db9bc  vmovaps xmm8, [rsp+0x80]
00007bdc0b3db9c5  vmovaps xmm9, [rsp+0x90]
00007bdc0b3db9ce  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3db9d7  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3db9e0  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3db9e9  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3db9f2  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3db9fb  add rsp, 0xF0
00007bdc0b3dba02  pop r11
00007bdc0b3dba04  pop r10
00007bdc0b3dba06  pop r9
00007bdc0b3dba08  pop r8
00007bdc0b3dba0a  pop rsi
00007bdc0b3dba0b  pop rdi
00007bdc0b3dba0c  pop rdx
00007bdc0b3dba0d  pop rcx
00007bdc0b3dba0e  pop rax
00007bdc0b3dba0f  add rsp, 0x08
00007bdc0b3dba13  jmp 0x00007BDC0B3DA27C
00007bdc0b3dba18  call 0x00007BDC0B20D4E0
00007bdc0b3dba1d  jmp 0x00007BDC0B3DA289
00007bdc0b3dba22  sub rsp, 0x08
00007bdc0b3dba26  push rax
00007bdc0b3dba27  push rcx
00007bdc0b3dba28  push rdx
00007bdc0b3dba29  push rdi
00007bdc0b3dba2a  push rsi
00007bdc0b3dba2b  push r8
00007bdc0b3dba2d  push r9
00007bdc0b3dba2f  push r10
00007bdc0b3dba31  push r11
00007bdc0b3dba33  sub rsp, 0xF0
00007bdc0b3dba3a  vmovaps [rsp], xmm0
00007bdc0b3dba3f  vmovaps [rsp+0x10], xmm1
00007bdc0b3dba45  vmovaps [rsp+0x20], xmm2
00007bdc0b3dba4b  vmovaps [rsp+0x30], xmm3
00007bdc0b3dba51  vmovaps [rsp+0x40], xmm4
00007bdc0b3dba57  vmovaps [rsp+0x50], xmm6
00007bdc0b3dba5d  vmovaps [rsp+0x60], xmm7
00007bdc0b3dba63  vmovaps [rsp+0x70], xmm8
00007bdc0b3dba69  vmovaps [rsp+0x80], xmm9
00007bdc0b3dba72  vmovaps [rsp+0x90], xmm10
00007bdc0b3dba7b  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dba84  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dba8d  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dba96  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dba9f  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dbaa8  sub rsp, 0x40
00007bdc0b3dbaac  lea rdi, [rsp]
00007bdc0b3dbab0  lea rsi, [rsp+0x10]
00007bdc0b3dbab5  lea rdx, [rsp+0x20]
00007bdc0b3dbaba  lea rcx, [rsp+0x30]
00007bdc0b3dbabf  mov r8d, 0x00
00007bdc0b3dbac5  lea r9, [r15+0x3A8]
00007bdc0b3dbacc  movaps [rdi], xmm5
00007bdc0b3dbacf  movaps [rsi], xmm6
00007bdc0b3dbad2  movaps [rdx], xmm7
00007bdc0b3dbad5  movaps [rcx], xmm9
00007bdc0b3dbad9  mov rax, 0x62CE440F2A50
00007bdc0b3dbae3  call rax
00007bdc0b3dbae5  movaps xmm5, [rsp]
00007bdc0b3dbae9  add rsp, 0x40
00007bdc0b3dbaed  vmovaps xmm0, [rsp]
00007bdc0b3dbaf2  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dbaf8  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dbafe  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dbb04  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dbb0a  vmovaps xmm6, [rsp+0x50]
00007bdc0b3dbb10  vmovaps xmm7, [rsp+0x60]
00007bdc0b3dbb16  vmovaps xmm8, [rsp+0x70]
00007bdc0b3dbb1c  vmovaps xmm9, [rsp+0x80]
00007bdc0b3dbb25  vmovaps xmm10, [rsp+0x90]
00007bdc0b3dbb2e  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dbb37  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dbb40  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dbb49  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dbb52  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dbb5b  add rsp, 0xF0
00007bdc0b3dbb62  pop r11
00007bdc0b3dbb64  pop r10
00007bdc0b3dbb66  pop r9
00007bdc0b3dbb68  pop r8
00007bdc0b3dbb6a  pop rsi
00007bdc0b3dbb6b  pop rdi
00007bdc0b3dbb6c  pop rdx
00007bdc0b3dbb6d  pop rcx
00007bdc0b3dbb6e  pop rax
00007bdc0b3dbb6f  add rsp, 0x08
00007bdc0b3dbb73  jmp 0x00007BDC0B3DA2BB
00007bdc0b3dbb78  sub rsp, 0x08
00007bdc0b3dbb7c  push rax
00007bdc0b3dbb7d  push rcx
00007bdc0b3dbb7e  push rdx
00007bdc0b3dbb7f  push rdi
00007bdc0b3dbb80  push rsi
00007bdc0b3dbb81  push r8
00007bdc0b3dbb83  push r9
00007bdc0b3dbb85  push r10
00007bdc0b3dbb87  push r11
00007bdc0b3dbb89  sub rsp, 0xF0
00007bdc0b3dbb90  vmovaps [rsp], xmm0
00007bdc0b3dbb95  vmovaps [rsp+0x10], xmm1
00007bdc0b3dbb9b  vmovaps [rsp+0x20], xmm2
00007bdc0b3dbba1  vmovaps [rsp+0x30], xmm3
00007bdc0b3dbba7  vmovaps [rsp+0x40], xmm4
00007bdc0b3dbbad  vmovaps [rsp+0x50], xmm5
00007bdc0b3dbbb3  vmovaps [rsp+0x60], xmm6
00007bdc0b3dbbb9  vmovaps [rsp+0x70], xmm8
00007bdc0b3dbbbf  vmovaps [rsp+0x80], xmm9
00007bdc0b3dbbc8  vmovaps [rsp+0x90], xmm10
00007bdc0b3dbbd1  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dbbda  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dbbe3  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dbbec  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dbbf5  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dbbfe  sub rsp, 0x40
00007bdc0b3dbc02  lea rdi, [rsp]
00007bdc0b3dbc06  lea rsi, [rsp+0x10]
00007bdc0b3dbc0b  lea rdx, [rsp+0x20]
00007bdc0b3dbc10  lea rcx, [rsp+0x30]
00007bdc0b3dbc15  mov r8d, 0x00
00007bdc0b3dbc1b  lea r9, [r15+0x3A8]
00007bdc0b3dbc22  movaps [rdi], xmm7
00007bdc0b3dbc25  movaps [rsi], xmm13
00007bdc0b3dbc29  movaps [rdx], xmm1
00007bdc0b3dbc2c  movaps [rcx], xmm9
00007bdc0b3dbc30  mov rax, 0x62CE440F2A50
00007bdc0b3dbc3a  call rax
00007bdc0b3dbc3c  movaps xmm7, [rsp]
00007bdc0b3dbc40  add rsp, 0x40
00007bdc0b3dbc44  vmovaps xmm0, [rsp]
00007bdc0b3dbc49  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dbc4f  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dbc55  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dbc5b  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dbc61  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dbc67  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dbc6d  vmovaps xmm8, [rsp+0x70]
00007bdc0b3dbc73  vmovaps xmm9, [rsp+0x80]
00007bdc0b3dbc7c  vmovaps xmm10, [rsp+0x90]
00007bdc0b3dbc85  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dbc8e  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dbc97  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dbca0  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dbca9  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dbcb2  add rsp, 0xF0
00007bdc0b3dbcb9  pop r11
00007bdc0b3dbcbb  pop r10
00007bdc0b3dbcbd  pop r9
00007bdc0b3dbcbf  pop r8
00007bdc0b3dbcc1  pop rsi
00007bdc0b3dbcc2  pop rdi
00007bdc0b3dbcc3  pop rdx
00007bdc0b3dbcc4  pop rcx
00007bdc0b3dbcc5  pop rax
00007bdc0b3dbcc6  add rsp, 0x08
00007bdc0b3dbcca  jmp 0x00007BDC0B3DA2E0
00007bdc0b3dbccf  call 0x00007BDC0B20C260
00007bdc0b3dbcd4  jmp 0x00007BDC0B3DA303
00007bdc0b3dbcd9  call 0x00007BDC0B207890
00007bdc0b3dbcde  jmp 0x00007BDC0B3DA30D
00007bdc0b3dbce3  sub rsp, 0x08
00007bdc0b3dbce7  push rax
00007bdc0b3dbce8  push rcx
00007bdc0b3dbce9  push rdx
00007bdc0b3dbcea  push rdi
00007bdc0b3dbceb  push rsi
00007bdc0b3dbcec  push r8
00007bdc0b3dbcee  push r9
00007bdc0b3dbcf0  push r10
00007bdc0b3dbcf2  push r11
00007bdc0b3dbcf4  sub rsp, 0xF0
00007bdc0b3dbcfb  vmovaps [rsp], xmm0
00007bdc0b3dbd00  vmovaps [rsp+0x10], xmm1
00007bdc0b3dbd06  vmovaps [rsp+0x20], xmm3
00007bdc0b3dbd0c  vmovaps [rsp+0x30], xmm4
00007bdc0b3dbd12  vmovaps [rsp+0x40], xmm5
00007bdc0b3dbd18  vmovaps [rsp+0x50], xmm6
00007bdc0b3dbd1e  vmovaps [rsp+0x60], xmm7
00007bdc0b3dbd24  vmovaps [rsp+0x70], xmm8
00007bdc0b3dbd2a  vmovaps [rsp+0x80], xmm9
00007bdc0b3dbd33  vmovaps [rsp+0x90], xmm10
00007bdc0b3dbd3c  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dbd45  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dbd4e  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dbd57  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dbd60  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dbd69  sub rsp, 0x40
00007bdc0b3dbd6d  lea rdi, [rsp]
00007bdc0b3dbd71  lea rsi, [rsp+0x10]
00007bdc0b3dbd76  lea rdx, [rsp+0x20]
00007bdc0b3dbd7b  lea rcx, [rsp+0x30]
00007bdc0b3dbd80  mov r8d, 0x00
00007bdc0b3dbd86  lea r9, [r15+0x3A8]
00007bdc0b3dbd8d  movaps [rdi], xmm2
00007bdc0b3dbd90  movaps [rsi], xmm12
00007bdc0b3dbd94  movaps [rdx], xmm6
00007bdc0b3dbd97  movaps [rcx], xmm3
00007bdc0b3dbd9a  mov rax, 0x62CE440F2A50
00007bdc0b3dbda4  call rax
00007bdc0b3dbda6  movaps xmm2, [rsp]
00007bdc0b3dbdaa  add rsp, 0x40
00007bdc0b3dbdae  vmovaps xmm0, [rsp]
00007bdc0b3dbdb3  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dbdb9  vmovaps xmm3, [rsp+0x20]
00007bdc0b3dbdbf  vmovaps xmm4, [rsp+0x30]
00007bdc0b3dbdc5  vmovaps xmm5, [rsp+0x40]
00007bdc0b3dbdcb  vmovaps xmm6, [rsp+0x50]
00007bdc0b3dbdd1  vmovaps xmm7, [rsp+0x60]
00007bdc0b3dbdd7  vmovaps xmm8, [rsp+0x70]
00007bdc0b3dbddd  vmovaps xmm9, [rsp+0x80]
00007bdc0b3dbde6  vmovaps xmm10, [rsp+0x90]
00007bdc0b3dbdef  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dbdf8  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dbe01  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dbe0a  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dbe13  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dbe1c  add rsp, 0xF0
00007bdc0b3dbe23  pop r11
00007bdc0b3dbe25  pop r10
00007bdc0b3dbe27  pop r9
00007bdc0b3dbe29  pop r8
00007bdc0b3dbe2b  pop rsi
00007bdc0b3dbe2c  pop rdi
00007bdc0b3dbe2d  pop rdx
00007bdc0b3dbe2e  pop rcx
00007bdc0b3dbe2f  pop rax
00007bdc0b3dbe30  add rsp, 0x08
00007bdc0b3dbe34  jmp 0x00007BDC0B3DA353
00007bdc0b3dbe39  sub rsp, 0x08
00007bdc0b3dbe3d  push rax
00007bdc0b3dbe3e  push rcx
00007bdc0b3dbe3f  push rdx
00007bdc0b3dbe40  push rdi
00007bdc0b3dbe41  push rsi
00007bdc0b3dbe42  push r8
00007bdc0b3dbe44  push r9
00007bdc0b3dbe46  push r10
00007bdc0b3dbe48  push r11
00007bdc0b3dbe4a  sub rsp, 0xF0
00007bdc0b3dbe51  vmovaps [rsp], xmm0
00007bdc0b3dbe56  vmovaps [rsp+0x10], xmm1
00007bdc0b3dbe5c  vmovaps [rsp+0x20], xmm2
00007bdc0b3dbe62  vmovaps [rsp+0x30], xmm3
00007bdc0b3dbe68  vmovaps [rsp+0x40], xmm4
00007bdc0b3dbe6e  vmovaps [rsp+0x50], xmm5
00007bdc0b3dbe74  vmovaps [rsp+0x60], xmm7
00007bdc0b3dbe7a  vmovaps [rsp+0x70], xmm8
00007bdc0b3dbe80  vmovaps [rsp+0x80], xmm9
00007bdc0b3dbe89  vmovaps [rsp+0x90], xmm10
00007bdc0b3dbe92  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dbe9b  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dbea4  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dbead  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dbeb6  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dbebf  sub rsp, 0x40
00007bdc0b3dbec3  lea rdi, [rsp]
00007bdc0b3dbec7  lea rsi, [rsp+0x10]
00007bdc0b3dbecc  lea rdx, [rsp+0x20]
00007bdc0b3dbed1  lea rcx, [rsp+0x30]
00007bdc0b3dbed6  mov r8d, 0x00
00007bdc0b3dbedc  lea r9, [r15+0x3A8]
00007bdc0b3dbee3  movaps [rdi], xmm6
00007bdc0b3dbee6  movaps [rsi], xmm10
00007bdc0b3dbeea  movaps [rdx], xmm12
00007bdc0b3dbeee  movaps [rcx], xmm1
00007bdc0b3dbef1  mov rax, 0x62CE440F2A50
00007bdc0b3dbefb  call rax
00007bdc0b3dbefd  movaps xmm6, [rsp]
00007bdc0b3dbf01  add rsp, 0x40
00007bdc0b3dbf05  vmovaps xmm0, [rsp]
00007bdc0b3dbf0a  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dbf10  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dbf16  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dbf1c  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dbf22  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dbf28  vmovaps xmm7, [rsp+0x60]
00007bdc0b3dbf2e  vmovaps xmm8, [rsp+0x70]
00007bdc0b3dbf34  vmovaps xmm9, [rsp+0x80]
00007bdc0b3dbf3d  vmovaps xmm10, [rsp+0x90]
00007bdc0b3dbf46  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dbf4f  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dbf58  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dbf61  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dbf6a  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dbf73  add rsp, 0xF0
00007bdc0b3dbf7a  pop r11
00007bdc0b3dbf7c  pop r10
00007bdc0b3dbf7e  pop r9
00007bdc0b3dbf80  pop r8
00007bdc0b3dbf82  pop rsi
00007bdc0b3dbf83  pop rdi
00007bdc0b3dbf84  pop rdx
00007bdc0b3dbf85  pop rcx
00007bdc0b3dbf86  pop rax
00007bdc0b3dbf87  add rsp, 0x08
00007bdc0b3dbf8b  jmp 0x00007BDC0B3DA381
00007bdc0b3dbf90  sub rsp, 0x08
00007bdc0b3dbf94  push rax
00007bdc0b3dbf95  push rcx
00007bdc0b3dbf96  push rdx
00007bdc0b3dbf97  push rdi
00007bdc0b3dbf98  push rsi
00007bdc0b3dbf99  push r8
00007bdc0b3dbf9b  push r9
00007bdc0b3dbf9d  push r10
00007bdc0b3dbf9f  push r11
00007bdc0b3dbfa1  sub rsp, 0xF0
00007bdc0b3dbfa8  vmovaps [rsp], xmm0
00007bdc0b3dbfad  vmovaps [rsp+0x10], xmm1
00007bdc0b3dbfb3  vmovaps [rsp+0x20], xmm2
00007bdc0b3dbfb9  vmovaps [rsp+0x30], xmm3
00007bdc0b3dbfbf  vmovaps [rsp+0x40], xmm4
00007bdc0b3dbfc5  vmovaps [rsp+0x50], xmm5
00007bdc0b3dbfcb  vmovaps [rsp+0x60], xmm6
00007bdc0b3dbfd1  vmovaps [rsp+0x70], xmm7
00007bdc0b3dbfd7  vmovaps [rsp+0x80], xmm8
00007bdc0b3dbfe0  vmovaps [rsp+0x90], xmm9
00007bdc0b3dbfe9  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dbff2  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dbffb  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dc004  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dc00d  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dc016  sub rsp, 0x40
00007bdc0b3dc01a  lea rdi, [rsp]
00007bdc0b3dc01e  lea rsi, [rsp+0x10]
00007bdc0b3dc023  lea rdx, [rsp+0x20]
00007bdc0b3dc028  lea rcx, [rsp+0x30]
00007bdc0b3dc02d  mov r8d, 0x00
00007bdc0b3dc033  lea r9, [r15+0x3A8]
00007bdc0b3dc03a  movaps [rdi], xmm10
00007bdc0b3dc03e  movaps [rsi], xmm5
00007bdc0b3dc041  movaps [rdx], xmm12
00007bdc0b3dc045  movaps [rcx], xmm1
00007bdc0b3dc048  mov rax, 0x62CE440F2A50
00007bdc0b3dc052  call rax
00007bdc0b3dc054  movaps xmm10, [rsp]
00007bdc0b3dc059  add rsp, 0x40
00007bdc0b3dc05d  vmovaps xmm0, [rsp]
00007bdc0b3dc062  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dc068  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dc06e  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dc074  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dc07a  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dc080  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dc086  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dc08c  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dc095  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dc09e  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dc0a7  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dc0b0  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dc0b9  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dc0c2  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dc0cb  add rsp, 0xF0
00007bdc0b3dc0d2  pop r11
00007bdc0b3dc0d4  pop r10
00007bdc0b3dc0d6  pop r9
00007bdc0b3dc0d8  pop r8
00007bdc0b3dc0da  pop rsi
00007bdc0b3dc0db  pop rdi
00007bdc0b3dc0dc  pop rdx
00007bdc0b3dc0dd  pop rcx
00007bdc0b3dc0de  pop rax
00007bdc0b3dc0df  add rsp, 0x08
00007bdc0b3dc0e3  jmp 0x00007BDC0B3DA3B0
00007bdc0b3dc0e8  sub rsp, 0x08
00007bdc0b3dc0ec  push rax
00007bdc0b3dc0ed  push rcx
00007bdc0b3dc0ee  push rdx
00007bdc0b3dc0ef  push rdi
00007bdc0b3dc0f0  push rsi
00007bdc0b3dc0f1  push r8
00007bdc0b3dc0f3  push r9
00007bdc0b3dc0f5  push r10
00007bdc0b3dc0f7  push r11
00007bdc0b3dc0f9  sub rsp, 0xF0
00007bdc0b3dc100  vmovaps [rsp], xmm0
00007bdc0b3dc105  vmovaps [rsp+0x10], xmm1
00007bdc0b3dc10b  vmovaps [rsp+0x20], xmm2
00007bdc0b3dc111  vmovaps [rsp+0x30], xmm3
00007bdc0b3dc117  vmovaps [rsp+0x40], xmm4
00007bdc0b3dc11d  vmovaps [rsp+0x50], xmm5
00007bdc0b3dc123  vmovaps [rsp+0x60], xmm6
00007bdc0b3dc129  vmovaps [rsp+0x70], xmm7
00007bdc0b3dc12f  vmovaps [rsp+0x80], xmm8
00007bdc0b3dc138  vmovaps [rsp+0x90], xmm9
00007bdc0b3dc141  vmovaps [rsp+0xA0], xmm10
00007bdc0b3dc14a  vmovaps [rsp+0xB0], xmm11
00007bdc0b3dc153  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dc15c  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dc165  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dc16e  sub rsp, 0x40
00007bdc0b3dc172  lea rdi, [rsp]
00007bdc0b3dc176  lea rsi, [rsp+0x10]
00007bdc0b3dc17b  lea rdx, [rsp+0x20]
00007bdc0b3dc180  lea rcx, [rsp+0x30]
00007bdc0b3dc185  mov r8d, 0x00
00007bdc0b3dc18b  lea r9, [r15+0x3A8]
00007bdc0b3dc192  movaps [rdi], xmm12
00007bdc0b3dc196  movaps [rsi], xmm7
00007bdc0b3dc199  movaps [rdx], xmm15
00007bdc0b3dc19d  movaps [rcx], xmm1
00007bdc0b3dc1a0  mov rax, 0x62CE440F2A50
00007bdc0b3dc1aa  call rax
00007bdc0b3dc1ac  movaps xmm12, [rsp]
00007bdc0b3dc1b1  add rsp, 0x40
00007bdc0b3dc1b5  vmovaps xmm0, [rsp]
00007bdc0b3dc1ba  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dc1c0  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dc1c6  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dc1cc  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dc1d2  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dc1d8  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dc1de  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dc1e4  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dc1ed  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dc1f6  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3dc1ff  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3dc208  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dc211  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dc21a  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dc223  add rsp, 0xF0
00007bdc0b3dc22a  pop r11
00007bdc0b3dc22c  pop r10
00007bdc0b3dc22e  pop r9
00007bdc0b3dc230  pop r8
00007bdc0b3dc232  pop rsi
00007bdc0b3dc233  pop rdi
00007bdc0b3dc234  pop rdx
00007bdc0b3dc235  pop rcx
00007bdc0b3dc236  pop rax
00007bdc0b3dc237  add rsp, 0x08
00007bdc0b3dc23b  jmp 0x00007BDC0B3DA3D9
00007bdc0b3dc240  call 0x00007BDC0B1FF430
00007bdc0b3dc245  jmp 0x00007BDC0B3DA3E3
00007bdc0b3dc24a  call 0x00007BDC0B20E760
00007bdc0b3dc24f  jmp 0x00007BDC0B3DA3ED
00007bdc0b3dc254  sub rsp, 0x08
00007bdc0b3dc258  push rax
00007bdc0b3dc259  push rcx
00007bdc0b3dc25a  push rdx
00007bdc0b3dc25b  push rdi
00007bdc0b3dc25c  push rsi
00007bdc0b3dc25d  push r8
00007bdc0b3dc25f  push r9
00007bdc0b3dc261  push r10
00007bdc0b3dc263  push r11
00007bdc0b3dc265  sub rsp, 0xF0
00007bdc0b3dc26c  vmovaps [rsp], xmm0
00007bdc0b3dc271  vmovaps [rsp+0x10], xmm1
00007bdc0b3dc277  vmovaps [rsp+0x20], xmm2
00007bdc0b3dc27d  vmovaps [rsp+0x30], xmm3
00007bdc0b3dc283  vmovaps [rsp+0x40], xmm4
00007bdc0b3dc289  vmovaps [rsp+0x50], xmm5
00007bdc0b3dc28f  vmovaps [rsp+0x60], xmm6
00007bdc0b3dc295  vmovaps [rsp+0x70], xmm8
00007bdc0b3dc29b  vmovaps [rsp+0x80], xmm9
00007bdc0b3dc2a4  vmovaps [rsp+0x90], xmm10
00007bdc0b3dc2ad  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dc2b6  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dc2bf  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dc2c8  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dc2d1  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dc2da  sub rsp, 0x40
00007bdc0b3dc2de  lea rdi, [rsp]
00007bdc0b3dc2e2  lea rsi, [rsp+0x10]
00007bdc0b3dc2e7  lea rdx, [rsp+0x20]
00007bdc0b3dc2ec  lea rcx, [rsp+0x30]
00007bdc0b3dc2f1  mov r8d, 0x00
00007bdc0b3dc2f7  lea r9, [r15+0x3A8]
00007bdc0b3dc2fe  movaps [rdi], xmm7
00007bdc0b3dc301  movaps [rsi], xmm2
00007bdc0b3dc304  movaps [rdx], xmm9
00007bdc0b3dc308  movaps [rcx], xmm11
00007bdc0b3dc30c  mov rax, 0x62CE440F2A50
00007bdc0b3dc316  call rax
00007bdc0b3dc318  movaps xmm7, [rsp]
00007bdc0b3dc31c  add rsp, 0x40
00007bdc0b3dc320  vmovaps xmm0, [rsp]
00007bdc0b3dc325  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dc32b  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dc331  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dc337  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dc33d  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dc343  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dc349  vmovaps xmm8, [rsp+0x70]
00007bdc0b3dc34f  vmovaps xmm9, [rsp+0x80]
00007bdc0b3dc358  vmovaps xmm10, [rsp+0x90]
00007bdc0b3dc361  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dc36a  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dc373  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dc37c  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dc385  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dc38e  add rsp, 0xF0
00007bdc0b3dc395  pop r11
00007bdc0b3dc397  pop r10
00007bdc0b3dc399  pop r9
00007bdc0b3dc39b  pop r8
00007bdc0b3dc39d  pop rsi
00007bdc0b3dc39e  pop rdi
00007bdc0b3dc39f  pop rdx
00007bdc0b3dc3a0  pop rcx
00007bdc0b3dc3a1  pop rax
00007bdc0b3dc3a2  add rsp, 0x08
00007bdc0b3dc3a6  jmp 0x00007BDC0B3DA421
00007bdc0b3dc3ab  sub rsp, 0x08
00007bdc0b3dc3af  push rax
00007bdc0b3dc3b0  push rcx
00007bdc0b3dc3b1  push rdx
00007bdc0b3dc3b2  push rdi
00007bdc0b3dc3b3  push rsi
00007bdc0b3dc3b4  push r8
00007bdc0b3dc3b6  push r9
00007bdc0b3dc3b8  push r10
00007bdc0b3dc3ba  push r11
00007bdc0b3dc3bc  sub rsp, 0xF0
00007bdc0b3dc3c3  vmovaps [rsp], xmm0
00007bdc0b3dc3c8  vmovaps [rsp+0x10], xmm1
00007bdc0b3dc3ce  vmovaps [rsp+0x20], xmm2
00007bdc0b3dc3d4  vmovaps [rsp+0x30], xmm3
00007bdc0b3dc3da  vmovaps [rsp+0x40], xmm4
00007bdc0b3dc3e0  vmovaps [rsp+0x50], xmm5
00007bdc0b3dc3e6  vmovaps [rsp+0x60], xmm6
00007bdc0b3dc3ec  vmovaps [rsp+0x70], xmm7
00007bdc0b3dc3f2  vmovaps [rsp+0x80], xmm8
00007bdc0b3dc3fb  vmovaps [rsp+0x90], xmm10
00007bdc0b3dc404  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dc40d  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dc416  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dc41f  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dc428  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dc431  sub rsp, 0x40
00007bdc0b3dc435  lea rdi, [rsp]
00007bdc0b3dc439  lea rsi, [rsp+0x10]
00007bdc0b3dc43e  lea rdx, [rsp+0x20]
00007bdc0b3dc443  lea rcx, [rsp+0x30]
00007bdc0b3dc448  mov r8d, 0x00
00007bdc0b3dc44e  lea r9, [r15+0x3A8]
00007bdc0b3dc455  movaps [rdi], xmm9
00007bdc0b3dc459  movaps [rsi], xmm6
00007bdc0b3dc45c  movaps [rdx], xmm1
00007bdc0b3dc45f  movaps [rcx], xmm11
00007bdc0b3dc463  mov rax, 0x62CE440F2A50
00007bdc0b3dc46d  call rax
00007bdc0b3dc46f  movaps xmm9, [rsp]
00007bdc0b3dc474  add rsp, 0x40
00007bdc0b3dc478  vmovaps xmm0, [rsp]
00007bdc0b3dc47d  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dc483  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dc489  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dc48f  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dc495  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dc49b  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dc4a1  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dc4a7  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dc4b0  vmovaps xmm10, [rsp+0x90]
00007bdc0b3dc4b9  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dc4c2  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dc4cb  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dc4d4  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dc4dd  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dc4e6  add rsp, 0xF0
00007bdc0b3dc4ed  pop r11
00007bdc0b3dc4ef  pop r10
00007bdc0b3dc4f1  pop r9
00007bdc0b3dc4f3  pop r8
00007bdc0b3dc4f5  pop rsi
00007bdc0b3dc4f6  pop rdi
00007bdc0b3dc4f7  pop rdx
00007bdc0b3dc4f8  pop rcx
00007bdc0b3dc4f9  pop rax
00007bdc0b3dc4fa  add rsp, 0x08
00007bdc0b3dc4fe  jmp 0x00007BDC0B3DA447
00007bdc0b3dc503  sub rsp, 0x08
00007bdc0b3dc507  push rax
00007bdc0b3dc508  push rcx
00007bdc0b3dc509  push rdx
00007bdc0b3dc50a  push rdi
00007bdc0b3dc50b  push rsi
00007bdc0b3dc50c  push r8
00007bdc0b3dc50e  push r9
00007bdc0b3dc510  push r10
00007bdc0b3dc512  push r11
00007bdc0b3dc514  sub rsp, 0xF0
00007bdc0b3dc51b  vmovaps [rsp], xmm0
00007bdc0b3dc520  vmovaps [rsp+0x10], xmm1
00007bdc0b3dc526  vmovaps [rsp+0x20], xmm2
00007bdc0b3dc52c  vmovaps [rsp+0x30], xmm3
00007bdc0b3dc532  vmovaps [rsp+0x40], xmm4
00007bdc0b3dc538  vmovaps [rsp+0x50], xmm5
00007bdc0b3dc53e  vmovaps [rsp+0x60], xmm6
00007bdc0b3dc544  vmovaps [rsp+0x70], xmm7
00007bdc0b3dc54a  vmovaps [rsp+0x80], xmm8
00007bdc0b3dc553  vmovaps [rsp+0x90], xmm9
00007bdc0b3dc55c  vmovaps [rsp+0xA0], xmm10
00007bdc0b3dc565  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dc56e  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dc577  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dc580  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dc589  sub rsp, 0x40
00007bdc0b3dc58d  lea rdi, [rsp]
00007bdc0b3dc591  lea rsi, [rsp+0x10]
00007bdc0b3dc596  lea rdx, [rsp+0x20]
00007bdc0b3dc59b  lea rcx, [rsp+0x30]
00007bdc0b3dc5a0  mov r8d, 0x00
00007bdc0b3dc5a6  lea r9, [r15+0x3A8]
00007bdc0b3dc5ad  movaps [rdi], xmm11
00007bdc0b3dc5b1  movaps [rsi], xmm10
00007bdc0b3dc5b5  movaps [rdx], xmm8
00007bdc0b3dc5b9  movaps [rcx], xmm1
00007bdc0b3dc5bc  mov rax, 0x62CE440F2A50
00007bdc0b3dc5c6  call rax
00007bdc0b3dc5c8  movaps xmm11, [rsp]
00007bdc0b3dc5cd  add rsp, 0x40
00007bdc0b3dc5d1  vmovaps xmm0, [rsp]
00007bdc0b3dc5d6  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dc5dc  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dc5e2  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dc5e8  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dc5ee  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dc5f4  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dc5fa  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dc600  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dc609  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dc612  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3dc61b  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dc624  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dc62d  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dc636  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dc63f  add rsp, 0xF0
00007bdc0b3dc646  pop r11
00007bdc0b3dc648  pop r10
00007bdc0b3dc64a  pop r9
00007bdc0b3dc64c  pop r8
00007bdc0b3dc64e  pop rsi
00007bdc0b3dc64f  pop rdi
00007bdc0b3dc650  pop rdx
00007bdc0b3dc651  pop rcx
00007bdc0b3dc652  pop rax
00007bdc0b3dc653  add rsp, 0x08
00007bdc0b3dc657  jmp 0x00007BDC0B3DA46D
00007bdc0b3dc65c  sub rsp, 0x08
00007bdc0b3dc660  push rax
00007bdc0b3dc661  push rcx
00007bdc0b3dc662  push rdx
00007bdc0b3dc663  push rdi
00007bdc0b3dc664  push rsi
00007bdc0b3dc665  push r8
00007bdc0b3dc667  push r9
00007bdc0b3dc669  push r10
00007bdc0b3dc66b  push r11
00007bdc0b3dc66d  sub rsp, 0xF0
00007bdc0b3dc674  vmovaps [rsp], xmm0
00007bdc0b3dc679  vmovaps [rsp+0x10], xmm1
00007bdc0b3dc67f  vmovaps [rsp+0x20], xmm2
00007bdc0b3dc685  vmovaps [rsp+0x30], xmm3
00007bdc0b3dc68b  vmovaps [rsp+0x40], xmm4
00007bdc0b3dc691  vmovaps [rsp+0x50], xmm5
00007bdc0b3dc697  vmovaps [rsp+0x60], xmm6
00007bdc0b3dc69d  vmovaps [rsp+0x70], xmm7
00007bdc0b3dc6a3  vmovaps [rsp+0x80], xmm8
00007bdc0b3dc6ac  vmovaps [rsp+0x90], xmm9
00007bdc0b3dc6b5  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dc6be  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dc6c7  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dc6d0  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dc6d9  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dc6e2  sub rsp, 0x40
00007bdc0b3dc6e6  lea rdi, [rsp]
00007bdc0b3dc6ea  lea rsi, [rsp+0x10]
00007bdc0b3dc6ef  lea rdx, [rsp+0x20]
00007bdc0b3dc6f4  lea rcx, [rsp+0x30]
00007bdc0b3dc6f9  mov r8d, 0x00
00007bdc0b3dc6ff  lea r9, [r15+0x3A8]
00007bdc0b3dc706  movaps [rdi], xmm10
00007bdc0b3dc70a  movaps [rsi], xmm12
00007bdc0b3dc70e  movaps [rdx], xmm13
00007bdc0b3dc712  movaps [rcx], xmm1
00007bdc0b3dc715  mov rax, 0x62CE440F2A50
00007bdc0b3dc71f  call rax
00007bdc0b3dc721  movaps xmm10, [rsp]
00007bdc0b3dc726  add rsp, 0x40
00007bdc0b3dc72a  vmovaps xmm0, [rsp]
00007bdc0b3dc72f  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dc735  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dc73b  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dc741  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dc747  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dc74d  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dc753  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dc759  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dc762  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dc76b  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dc774  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dc77d  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dc786  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dc78f  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dc798  add rsp, 0xF0
00007bdc0b3dc79f  pop r11
00007bdc0b3dc7a1  pop r10
00007bdc0b3dc7a3  pop r9
00007bdc0b3dc7a5  pop r8
00007bdc0b3dc7a7  pop rsi
00007bdc0b3dc7a8  pop rdi
00007bdc0b3dc7a9  pop rdx
00007bdc0b3dc7aa  pop rcx
00007bdc0b3dc7ab  pop rax
00007bdc0b3dc7ac  add rsp, 0x08
00007bdc0b3dc7b0  jmp 0x00007BDC0B3DA493
00007bdc0b3dc7b5  call 0x00007BDC0B1FF430
00007bdc0b3dc7ba  jmp 0x00007BDC0B3DA49D
00007bdc0b3dc7bf  call 0x00007BDC0B20C260
00007bdc0b3dc7c4  jmp 0x00007BDC0B3DA4A7
00007bdc0b3dc7c9  sub rsp, 0x08
00007bdc0b3dc7cd  push rax
00007bdc0b3dc7ce  push rcx
00007bdc0b3dc7cf  push rdx
00007bdc0b3dc7d0  push rdi
00007bdc0b3dc7d1  push rsi
00007bdc0b3dc7d2  push r8
00007bdc0b3dc7d4  push r9
00007bdc0b3dc7d6  push r10
00007bdc0b3dc7d8  push r11
00007bdc0b3dc7da  sub rsp, 0xF0
00007bdc0b3dc7e1  vmovaps [rsp], xmm0
00007bdc0b3dc7e6  vmovaps [rsp+0x10], xmm1
00007bdc0b3dc7ec  vmovaps [rsp+0x20], xmm2
00007bdc0b3dc7f2  vmovaps [rsp+0x30], xmm3
00007bdc0b3dc7f8  vmovaps [rsp+0x40], xmm4
00007bdc0b3dc7fe  vmovaps [rsp+0x50], xmm5
00007bdc0b3dc804  vmovaps [rsp+0x60], xmm6
00007bdc0b3dc80a  vmovaps [rsp+0x70], xmm7
00007bdc0b3dc810  vmovaps [rsp+0x80], xmm9
00007bdc0b3dc819  vmovaps [rsp+0x90], xmm10
00007bdc0b3dc822  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dc82b  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dc834  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dc83d  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dc846  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dc84f  sub rsp, 0x40
00007bdc0b3dc853  lea rdi, [rsp]
00007bdc0b3dc857  lea rsi, [rsp+0x10]
00007bdc0b3dc85c  lea rdx, [rsp+0x20]
00007bdc0b3dc861  lea rcx, [rsp+0x30]
00007bdc0b3dc866  mov r8d, 0x00
00007bdc0b3dc86c  lea r9, [r15+0x3A8]
00007bdc0b3dc873  movaps [rdi], xmm8
00007bdc0b3dc877  movaps [rsi], xmm7
00007bdc0b3dc87a  movaps [rdx], xmm4
00007bdc0b3dc87d  movaps [rcx], xmm12
00007bdc0b3dc881  mov rax, 0x62CE440F2A50
00007bdc0b3dc88b  call rax
00007bdc0b3dc88d  movaps xmm8, [rsp]
00007bdc0b3dc892  add rsp, 0x40
00007bdc0b3dc896  vmovaps xmm0, [rsp]
00007bdc0b3dc89b  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dc8a1  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dc8a7  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dc8ad  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dc8b3  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dc8b9  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dc8bf  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dc8c5  vmovaps xmm9, [rsp+0x80]
00007bdc0b3dc8ce  vmovaps xmm10, [rsp+0x90]
00007bdc0b3dc8d7  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dc8e0  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dc8e9  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dc8f2  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dc8fb  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dc904  add rsp, 0xF0
00007bdc0b3dc90b  pop r11
00007bdc0b3dc90d  pop r10
00007bdc0b3dc90f  pop r9
00007bdc0b3dc911  pop r8
00007bdc0b3dc913  pop rsi
00007bdc0b3dc914  pop rdi
00007bdc0b3dc915  pop rdx
00007bdc0b3dc916  pop rcx
00007bdc0b3dc917  pop rax
00007bdc0b3dc918  add rsp, 0x08
00007bdc0b3dc91c  jmp 0x00007BDC0B3DA4D0
00007bdc0b3dc921  sub rsp, 0x08
00007bdc0b3dc925  push rax
00007bdc0b3dc926  push rcx
00007bdc0b3dc927  push rdx
00007bdc0b3dc928  push rdi
00007bdc0b3dc929  push rsi
00007bdc0b3dc92a  push r8
00007bdc0b3dc92c  push r9
00007bdc0b3dc92e  push r10
00007bdc0b3dc930  push r11
00007bdc0b3dc932  sub rsp, 0xF0
00007bdc0b3dc939  vmovaps [rsp], xmm0
00007bdc0b3dc93e  vmovaps [rsp+0x10], xmm1
00007bdc0b3dc944  vmovaps [rsp+0x20], xmm2
00007bdc0b3dc94a  vmovaps [rsp+0x30], xmm3
00007bdc0b3dc950  vmovaps [rsp+0x40], xmm4
00007bdc0b3dc956  vmovaps [rsp+0x50], xmm5
00007bdc0b3dc95c  vmovaps [rsp+0x60], xmm6
00007bdc0b3dc962  vmovaps [rsp+0x70], xmm8
00007bdc0b3dc968  vmovaps [rsp+0x80], xmm9
00007bdc0b3dc971  vmovaps [rsp+0x90], xmm10
00007bdc0b3dc97a  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dc983  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dc98c  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dc995  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dc99e  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dc9a7  sub rsp, 0x40
00007bdc0b3dc9ab  lea rdi, [rsp]
00007bdc0b3dc9af  lea rsi, [rsp+0x10]
00007bdc0b3dc9b4  lea rdx, [rsp+0x20]
00007bdc0b3dc9b9  lea rcx, [rsp+0x30]
00007bdc0b3dc9be  mov r8d, 0x00
00007bdc0b3dc9c4  lea r9, [r15+0x3A8]
00007bdc0b3dc9cb  movaps [rdi], xmm7
00007bdc0b3dc9ce  movaps [rsi], xmm9
00007bdc0b3dc9d2  movaps [rdx], xmm14
00007bdc0b3dc9d6  movaps [rcx], xmm12
00007bdc0b3dc9da  mov rax, 0x62CE440F2A50
00007bdc0b3dc9e4  call rax
00007bdc0b3dc9e6  movaps xmm7, [rsp]
00007bdc0b3dc9ea  add rsp, 0x40
00007bdc0b3dc9ee  vmovaps xmm0, [rsp]
00007bdc0b3dc9f3  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dc9f9  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dc9ff  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dca05  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dca0b  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dca11  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dca17  vmovaps xmm8, [rsp+0x70]
00007bdc0b3dca1d  vmovaps xmm9, [rsp+0x80]
00007bdc0b3dca26  vmovaps xmm10, [rsp+0x90]
00007bdc0b3dca2f  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dca38  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dca41  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dca4a  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dca53  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dca5c  add rsp, 0xF0
00007bdc0b3dca63  pop r11
00007bdc0b3dca65  pop r10
00007bdc0b3dca67  pop r9
00007bdc0b3dca69  pop r8
00007bdc0b3dca6b  pop rsi
00007bdc0b3dca6c  pop rdi
00007bdc0b3dca6d  pop rdx
00007bdc0b3dca6e  pop rcx
00007bdc0b3dca6f  pop rax
00007bdc0b3dca70  add rsp, 0x08
00007bdc0b3dca74  jmp 0x00007BDC0B3DA4F8
00007bdc0b3dca79  sub rsp, 0x08
00007bdc0b3dca7d  push rax
00007bdc0b3dca7e  push rcx
00007bdc0b3dca7f  push rdx
00007bdc0b3dca80  push rdi
00007bdc0b3dca81  push rsi
00007bdc0b3dca82  push r8
00007bdc0b3dca84  push r9
00007bdc0b3dca86  push r10
00007bdc0b3dca88  push r11
00007bdc0b3dca8a  sub rsp, 0xF0
00007bdc0b3dca91  vmovaps [rsp], xmm0
00007bdc0b3dca96  vmovaps [rsp+0x10], xmm1
00007bdc0b3dca9c  vmovaps [rsp+0x20], xmm2
00007bdc0b3dcaa2  vmovaps [rsp+0x30], xmm3
00007bdc0b3dcaa8  vmovaps [rsp+0x40], xmm4
00007bdc0b3dcaae  vmovaps [rsp+0x50], xmm5
00007bdc0b3dcab4  vmovaps [rsp+0x60], xmm6
00007bdc0b3dcaba  vmovaps [rsp+0x70], xmm7
00007bdc0b3dcac0  vmovaps [rsp+0x80], xmm8
00007bdc0b3dcac9  vmovaps [rsp+0x90], xmm9
00007bdc0b3dcad2  vmovaps [rsp+0xA0], xmm10
00007bdc0b3dcadb  vmovaps [rsp+0xB0], xmm11
00007bdc0b3dcae4  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dcaed  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dcaf6  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dcaff  sub rsp, 0x40
00007bdc0b3dcb03  lea rdi, [rsp]
00007bdc0b3dcb07  lea rsi, [rsp+0x10]
00007bdc0b3dcb0c  lea rdx, [rsp+0x20]
00007bdc0b3dcb11  lea rcx, [rsp+0x30]
00007bdc0b3dcb16  mov r8d, 0x00
00007bdc0b3dcb1c  lea r9, [r15+0x3A8]
00007bdc0b3dcb23  movaps [rdi], xmm12
00007bdc0b3dcb27  movaps [rsi], xmm11
00007bdc0b3dcb2b  movaps [rdx], xmm15
00007bdc0b3dcb2f  movaps [rcx], xmm14
00007bdc0b3dcb33  mov rax, 0x62CE440F2A50
00007bdc0b3dcb3d  call rax
00007bdc0b3dcb3f  movaps xmm12, [rsp]
00007bdc0b3dcb44  add rsp, 0x40
00007bdc0b3dcb48  vmovaps xmm0, [rsp]
00007bdc0b3dcb4d  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dcb53  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dcb59  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dcb5f  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dcb65  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dcb6b  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dcb71  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dcb77  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dcb80  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dcb89  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3dcb92  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3dcb9b  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dcba4  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dcbad  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dcbb6  add rsp, 0xF0
00007bdc0b3dcbbd  pop r11
00007bdc0b3dcbbf  pop r10
00007bdc0b3dcbc1  pop r9
00007bdc0b3dcbc3  pop r8
00007bdc0b3dcbc5  pop rsi
00007bdc0b3dcbc6  pop rdi
00007bdc0b3dcbc7  pop rdx
00007bdc0b3dcbc8  pop rcx
00007bdc0b3dcbc9  pop rax
00007bdc0b3dcbca  add rsp, 0x08
00007bdc0b3dcbce  jmp 0x00007BDC0B3DA521
00007bdc0b3dcbd3  sub rsp, 0x08
00007bdc0b3dcbd7  push rax
00007bdc0b3dcbd8  push rcx
00007bdc0b3dcbd9  push rdx
00007bdc0b3dcbda  push rdi
00007bdc0b3dcbdb  push rsi
00007bdc0b3dcbdc  push r8
00007bdc0b3dcbde  push r9
00007bdc0b3dcbe0  push r10
00007bdc0b3dcbe2  push r11
00007bdc0b3dcbe4  sub rsp, 0xF0
00007bdc0b3dcbeb  vmovaps [rsp], xmm0
00007bdc0b3dcbf0  vmovaps [rsp+0x10], xmm1
00007bdc0b3dcbf6  vmovaps [rsp+0x20], xmm2
00007bdc0b3dcbfc  vmovaps [rsp+0x30], xmm3
00007bdc0b3dcc02  vmovaps [rsp+0x40], xmm4
00007bdc0b3dcc08  vmovaps [rsp+0x50], xmm5
00007bdc0b3dcc0e  vmovaps [rsp+0x60], xmm6
00007bdc0b3dcc14  vmovaps [rsp+0x70], xmm7
00007bdc0b3dcc1a  vmovaps [rsp+0x80], xmm8
00007bdc0b3dcc23  vmovaps [rsp+0x90], xmm9
00007bdc0b3dcc2c  vmovaps [rsp+0xA0], xmm10
00007bdc0b3dcc35  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dcc3e  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dcc47  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dcc50  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dcc59  sub rsp, 0x40
00007bdc0b3dcc5d  lea rdi, [rsp]
00007bdc0b3dcc61  lea rsi, [rsp+0x10]
00007bdc0b3dcc66  lea rdx, [rsp+0x20]
00007bdc0b3dcc6b  lea rcx, [rsp+0x30]
00007bdc0b3dcc70  mov r8d, 0x00
00007bdc0b3dcc76  lea r9, [r15+0x3A8]
00007bdc0b3dcc7d  movaps [rdi], xmm11
00007bdc0b3dcc81  movaps [rsi], xmm10
00007bdc0b3dcc85  movaps [rdx], xmm13
00007bdc0b3dcc89  movaps [rcx], xmm15
00007bdc0b3dcc8d  mov rax, 0x62CE440F2A50
00007bdc0b3dcc97  call rax
00007bdc0b3dcc99  movaps xmm11, [rsp]
00007bdc0b3dcc9e  add rsp, 0x40
00007bdc0b3dcca2  vmovaps xmm0, [rsp]
00007bdc0b3dcca7  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dccad  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dccb3  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dccb9  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dccbf  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dccc5  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dcccb  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dccd1  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dccda  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dcce3  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3dccec  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dccf5  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dccfe  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dcd07  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dcd10  add rsp, 0xF0
00007bdc0b3dcd17  pop r11
00007bdc0b3dcd19  pop r10
00007bdc0b3dcd1b  pop r9
00007bdc0b3dcd1d  pop r8
00007bdc0b3dcd1f  pop rsi
00007bdc0b3dcd20  pop rdi
00007bdc0b3dcd21  pop rdx
00007bdc0b3dcd22  pop rcx
00007bdc0b3dcd23  pop rax
00007bdc0b3dcd24  add rsp, 0x08
00007bdc0b3dcd28  jmp 0x00007BDC0B3DA54A
00007bdc0b3dcd2d  call 0x00007BDC0B20E760
00007bdc0b3dcd32  jmp 0x00007BDC0B3DA557
00007bdc0b3dcd37  call 0x00007BDC0B20D4E0
00007bdc0b3dcd3c  jmp 0x00007BDC0B3DA564
00007bdc0b3dcd41  sub rsp, 0x08
00007bdc0b3dcd45  push rax
00007bdc0b3dcd46  push rcx
00007bdc0b3dcd47  push rdx
00007bdc0b3dcd48  push rdi
00007bdc0b3dcd49  push rsi
00007bdc0b3dcd4a  push r8
00007bdc0b3dcd4c  push r9
00007bdc0b3dcd4e  push r10
00007bdc0b3dcd50  push r11
00007bdc0b3dcd52  sub rsp, 0xF0
00007bdc0b3dcd59  vmovaps [rsp], xmm0
00007bdc0b3dcd5e  vmovaps [rsp+0x10], xmm1
00007bdc0b3dcd64  vmovaps [rsp+0x20], xmm2
00007bdc0b3dcd6a  vmovaps [rsp+0x30], xmm3
00007bdc0b3dcd70  vmovaps [rsp+0x40], xmm4
00007bdc0b3dcd76  vmovaps [rsp+0x50], xmm5
00007bdc0b3dcd7c  vmovaps [rsp+0x60], xmm6
00007bdc0b3dcd82  vmovaps [rsp+0x70], xmm7
00007bdc0b3dcd88  vmovaps [rsp+0x80], xmm8
00007bdc0b3dcd91  vmovaps [rsp+0x90], xmm9
00007bdc0b3dcd9a  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dcda3  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dcdac  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dcdb5  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dcdbe  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dcdc7  sub rsp, 0x40
00007bdc0b3dcdcb  lea rdi, [rsp]
00007bdc0b3dcdcf  lea rsi, [rsp+0x10]
00007bdc0b3dcdd4  lea rdx, [rsp+0x20]
00007bdc0b3dcdd9  lea rcx, [rsp+0x30]
00007bdc0b3dcdde  mov r8d, 0x00
00007bdc0b3dcde4  lea r9, [r15+0x3A8]
00007bdc0b3dcdeb  movaps [rdi], xmm10
00007bdc0b3dcdef  movaps [rsi], xmm8
00007bdc0b3dcdf3  movaps [rdx], xmm1
00007bdc0b3dcdf6  movaps [rcx], xmm13
00007bdc0b3dcdfa  mov rax, 0x62CE440F2A50
00007bdc0b3dce04  call rax
00007bdc0b3dce06  movaps xmm10, [rsp]
00007bdc0b3dce0b  add rsp, 0x40
00007bdc0b3dce0f  vmovaps xmm0, [rsp]
00007bdc0b3dce14  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dce1a  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dce20  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dce26  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dce2c  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dce32  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dce38  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dce3e  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dce47  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dce50  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dce59  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dce62  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dce6b  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dce74  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dce7d  add rsp, 0xF0
00007bdc0b3dce84  pop r11
00007bdc0b3dce86  pop r10
00007bdc0b3dce88  pop r9
00007bdc0b3dce8a  pop r8
00007bdc0b3dce8c  pop rsi
00007bdc0b3dce8d  pop rdi
00007bdc0b3dce8e  pop rdx
00007bdc0b3dce8f  pop rcx
00007bdc0b3dce90  pop rax
00007bdc0b3dce91  add rsp, 0x08
00007bdc0b3dce95  jmp 0x00007BDC0B3DA59A
00007bdc0b3dce9a  call 0x00007BDC0B1FF430
00007bdc0b3dce9f  jmp 0x00007BDC0B3DA5AC
00007bdc0b3dcea4  sub rsp, 0x08
00007bdc0b3dcea8  push rax
00007bdc0b3dcea9  push rcx
00007bdc0b3dceaa  push rdx
00007bdc0b3dceab  push rdi
00007bdc0b3dceac  push rsi
00007bdc0b3dcead  push r8
00007bdc0b3dceaf  push r9
00007bdc0b3dceb1  push r10
00007bdc0b3dceb3  push r11
00007bdc0b3dceb5  sub rsp, 0xF0
00007bdc0b3dcebc  vmovaps [rsp], xmm0
00007bdc0b3dcec1  vmovaps [rsp+0x10], xmm1
00007bdc0b3dcec7  vmovaps [rsp+0x20], xmm2
00007bdc0b3dcecd  vmovaps [rsp+0x30], xmm3
00007bdc0b3dced3  vmovaps [rsp+0x40], xmm4
00007bdc0b3dced9  vmovaps [rsp+0x50], xmm5
00007bdc0b3dcedf  vmovaps [rsp+0x60], xmm6
00007bdc0b3dcee5  vmovaps [rsp+0x70], xmm7
00007bdc0b3dceeb  vmovaps [rsp+0x80], xmm8
00007bdc0b3dcef4  vmovaps [rsp+0x90], xmm10
00007bdc0b3dcefd  vmovaps [rsp+0xA0], xmm11
00007bdc0b3dcf06  vmovaps [rsp+0xB0], xmm12
00007bdc0b3dcf0f  vmovaps [rsp+0xC0], xmm13
00007bdc0b3dcf18  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dcf21  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dcf2a  sub rsp, 0x40
00007bdc0b3dcf2e  lea rdi, [rsp]
00007bdc0b3dcf32  lea rsi, [rsp+0x10]
00007bdc0b3dcf37  lea rdx, [rsp+0x20]
00007bdc0b3dcf3c  lea rcx, [rsp+0x30]
00007bdc0b3dcf41  mov r8d, 0x00
00007bdc0b3dcf47  lea r9, [r15+0x3A8]
00007bdc0b3dcf4e  movaps [rdi], xmm9
00007bdc0b3dcf52  movaps [rsi], xmm7
00007bdc0b3dcf55  movaps [rdx], xmm14
00007bdc0b3dcf59  movaps [rcx], xmm13
00007bdc0b3dcf5d  mov rax, 0x62CE440F2A50
00007bdc0b3dcf67  call rax
00007bdc0b3dcf69  movaps xmm9, [rsp]
00007bdc0b3dcf6e  add rsp, 0x40
00007bdc0b3dcf72  vmovaps xmm0, [rsp]
00007bdc0b3dcf77  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dcf7d  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dcf83  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dcf89  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dcf8f  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dcf95  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dcf9b  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dcfa1  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dcfaa  vmovaps xmm10, [rsp+0x90]
00007bdc0b3dcfb3  vmovaps xmm11, [rsp+0xA0]
00007bdc0b3dcfbc  vmovaps xmm12, [rsp+0xB0]
00007bdc0b3dcfc5  vmovaps xmm13, [rsp+0xC0]
00007bdc0b3dcfce  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dcfd7  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dcfe0  add rsp, 0xF0
00007bdc0b3dcfe7  pop r11
00007bdc0b3dcfe9  pop r10
00007bdc0b3dcfeb  pop r9
00007bdc0b3dcfed  pop r8
00007bdc0b3dcfef  pop rsi
00007bdc0b3dcff0  pop rdi
00007bdc0b3dcff1  pop rdx
00007bdc0b3dcff2  pop rcx
00007bdc0b3dcff3  pop rax
00007bdc0b3dcff4  add rsp, 0x08
00007bdc0b3dcff8  jmp 0x00007BDC0B3DA5DA
00007bdc0b3dcffd  sub rsp, 0x08
00007bdc0b3dd001  push rax
00007bdc0b3dd002  push rcx
00007bdc0b3dd003  push rdx
00007bdc0b3dd004  push rdi
00007bdc0b3dd005  push rsi
00007bdc0b3dd006  push r8
00007bdc0b3dd008  push r9
00007bdc0b3dd00a  push r10
00007bdc0b3dd00c  push r11
00007bdc0b3dd00e  sub rsp, 0xF0
00007bdc0b3dd015  vmovaps [rsp], xmm0
00007bdc0b3dd01a  vmovaps [rsp+0x10], xmm1
00007bdc0b3dd020  vmovaps [rsp+0x20], xmm2
00007bdc0b3dd026  vmovaps [rsp+0x30], xmm3
00007bdc0b3dd02c  vmovaps [rsp+0x40], xmm4
00007bdc0b3dd032  vmovaps [rsp+0x50], xmm5
00007bdc0b3dd038  vmovaps [rsp+0x60], xmm6
00007bdc0b3dd03e  vmovaps [rsp+0x70], xmm7
00007bdc0b3dd044  vmovaps [rsp+0x80], xmm8
00007bdc0b3dd04d  vmovaps [rsp+0x90], xmm9
00007bdc0b3dd056  vmovaps [rsp+0xA0], xmm10
00007bdc0b3dd05f  vmovaps [rsp+0xB0], xmm11
00007bdc0b3dd068  vmovaps [rsp+0xC0], xmm12
00007bdc0b3dd071  vmovaps [rsp+0xD0], xmm14
00007bdc0b3dd07a  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dd083  sub rsp, 0x40
00007bdc0b3dd087  lea rdi, [rsp]
00007bdc0b3dd08b  lea rsi, [rsp+0x10]
00007bdc0b3dd090  lea rdx, [rsp+0x20]
00007bdc0b3dd095  lea rcx, [rsp+0x30]
00007bdc0b3dd09a  mov r8d, 0x00
00007bdc0b3dd0a0  lea r9, [r15+0x3A8]
00007bdc0b3dd0a7  movaps [rdi], xmm13
00007bdc0b3dd0ab  movaps [rsi], xmm12
00007bdc0b3dd0af  movaps [rdx], xmm15
00007bdc0b3dd0b3  movaps [rcx], xmm14
00007bdc0b3dd0b7  mov rax, 0x62CE440F2A50
00007bdc0b3dd0c1  call rax
00007bdc0b3dd0c3  movaps xmm13, [rsp]
00007bdc0b3dd0c8  add rsp, 0x40
00007bdc0b3dd0cc  vmovaps xmm0, [rsp]
00007bdc0b3dd0d1  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dd0d7  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dd0dd  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dd0e3  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dd0e9  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dd0ef  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dd0f5  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dd0fb  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dd104  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dd10d  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3dd116  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3dd11f  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3dd128  vmovaps xmm14, [rsp+0xD0]
00007bdc0b3dd131  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dd13a  add rsp, 0xF0
00007bdc0b3dd141  pop r11
00007bdc0b3dd143  pop r10
00007bdc0b3dd145  pop r9
00007bdc0b3dd147  pop r8
00007bdc0b3dd149  pop rsi
00007bdc0b3dd14a  pop rdi
00007bdc0b3dd14b  pop rdx
00007bdc0b3dd14c  pop rcx
00007bdc0b3dd14d  pop rax
00007bdc0b3dd14e  add rsp, 0x08
00007bdc0b3dd152  jmp 0x00007BDC0B3DA608
00007bdc0b3dd157  sub rsp, 0x08
00007bdc0b3dd15b  push rax
00007bdc0b3dd15c  push rcx
00007bdc0b3dd15d  push rdx
00007bdc0b3dd15e  push rdi
00007bdc0b3dd15f  push rsi
00007bdc0b3dd160  push r8
00007bdc0b3dd162  push r9
00007bdc0b3dd164  push r10
00007bdc0b3dd166  push r11
00007bdc0b3dd168  sub rsp, 0xF0
00007bdc0b3dd16f  vmovaps [rsp], xmm0
00007bdc0b3dd174  vmovaps [rsp+0x10], xmm1
00007bdc0b3dd17a  vmovaps [rsp+0x20], xmm2
00007bdc0b3dd180  vmovaps [rsp+0x30], xmm3
00007bdc0b3dd186  vmovaps [rsp+0x40], xmm4
00007bdc0b3dd18c  vmovaps [rsp+0x50], xmm5
00007bdc0b3dd192  vmovaps [rsp+0x60], xmm6
00007bdc0b3dd198  vmovaps [rsp+0x70], xmm7
00007bdc0b3dd19e  vmovaps [rsp+0x80], xmm8
00007bdc0b3dd1a7  vmovaps [rsp+0x90], xmm9
00007bdc0b3dd1b0  vmovaps [rsp+0xA0], xmm10
00007bdc0b3dd1b9  vmovaps [rsp+0xB0], xmm11
00007bdc0b3dd1c2  vmovaps [rsp+0xC0], xmm12
00007bdc0b3dd1cb  vmovaps [rsp+0xD0], xmm13
00007bdc0b3dd1d4  vmovaps [rsp+0xE0], xmm15
00007bdc0b3dd1dd  sub rsp, 0x40
00007bdc0b3dd1e1  lea rdi, [rsp]
00007bdc0b3dd1e5  lea rsi, [rsp+0x10]
00007bdc0b3dd1ea  lea rdx, [rsp+0x20]
00007bdc0b3dd1ef  lea rcx, [rsp+0x30]
00007bdc0b3dd1f4  mov r8d, 0x00
00007bdc0b3dd1fa  lea r9, [r15+0x3A8]
00007bdc0b3dd201  movaps [rdi], xmm14
00007bdc0b3dd205  movaps [rsi], xmm11
00007bdc0b3dd209  movaps [rdx], xmm1
00007bdc0b3dd20c  movaps [rcx], xmm15
00007bdc0b3dd210  mov rax, 0x62CE440F2A50
00007bdc0b3dd21a  call rax
00007bdc0b3dd21c  movaps xmm14, [rsp]
00007bdc0b3dd221  add rsp, 0x40
00007bdc0b3dd225  vmovaps xmm0, [rsp]
00007bdc0b3dd22a  vmovaps xmm1, [rsp+0x10]
00007bdc0b3dd230  vmovaps xmm2, [rsp+0x20]
00007bdc0b3dd236  vmovaps xmm3, [rsp+0x30]
00007bdc0b3dd23c  vmovaps xmm4, [rsp+0x40]
00007bdc0b3dd242  vmovaps xmm5, [rsp+0x50]
00007bdc0b3dd248  vmovaps xmm6, [rsp+0x60]
00007bdc0b3dd24e  vmovaps xmm7, [rsp+0x70]
00007bdc0b3dd254  vmovaps xmm8, [rsp+0x80]
00007bdc0b3dd25d  vmovaps xmm9, [rsp+0x90]
00007bdc0b3dd266  vmovaps xmm10, [rsp+0xA0]
00007bdc0b3dd26f  vmovaps xmm11, [rsp+0xB0]
00007bdc0b3dd278  vmovaps xmm12, [rsp+0xC0]
00007bdc0b3dd281  vmovaps xmm13, [rsp+0xD0]
00007bdc0b3dd28a  vmovaps xmm15, [rsp+0xE0]
00007bdc0b3dd293  add rsp, 0xF0
00007bdc0b3dd29a  pop r11
00007bdc0b3dd29c  pop r10
00007bdc0b3dd29e  pop r9
00007bdc0b3dd2a0  pop r8
00007bdc0b3dd2a2  pop rsi
00007bdc0b3dd2a3  pop rdi
00007bdc0b3dd2a4  pop rdx
00007bdc0b3dd2a5  pop rcx
00007bdc0b3dd2a6  pop rax
00007bdc0b3dd2a7  add rsp, 0x08
00007bdc0b3dd2ab  jmp 0x00007BDC0B3DA636
00007bdc0b3dd2b0  call 0x00007BDC0B2079B0
00007bdc0b3dd2b5  jmp 0x00007BDC0B3DA64C
00007bdc0b3dd2ba  call 0x00007BDC0B2E3440
00007bdc0b3dd2bf  jmp 0x00007BDC0B3DA656
00007bdc0b3dd2c4  call 0x00007BDC0B2DFCE0
00007bdc0b3dd2c9  jmp 0x00007BDC0B3DA660
00007bdc0b3dd2ce  call 0x00007BDC0B2E46C0
00007bdc0b3dd2d3  jmp 0x00007BDC0B3DA66A
00007bdc0b3dd2d8  int3
00007bdc0b3dd2d9  nop [rax], eax
00007bdc0b3dd2e0  mov qword ptr [r15+0x40], 0x430000
00007bdc0b3dd2e8  mov eax, 0x430C50
00007bdc0b3dd2ed  mov r14, [r13+rax*1]
00007bdc0b3dd2f2  movq xmm1, r14
00007bdc0b3dd2f7  mov rax, [r15+0x50]
00007bdc0b3dd2fb  movups xmm15, [r13+rax*1]
00007bdc0b3dd301  movaps [r15+0x120], xmm15
00007bdc0b3dd309  mov qword ptr [r15+0x48], 0x10
00007bdc0b3dd311  xor eax, eax
00007bdc0b3dd313  mov r14d, 0x10
00007bdc0b3dd319  mov r12d, 0x200
00007bdc0b3dd31f  cmp r14, r12
00007bdc0b3dd322  cmc
00007bdc0b3dd323  lahf
00007bdc0b3dd324  seto al
00007bdc0b3dd327  mov [r15+0x108], eax
00007bdc0b3dd32e  pextrq rax, xmm15, 0x01
00007bdc0b3dd335  movq xmm14, rax
00007bdc0b3dd33a  movaps [r15+0x130], xmm14
00007bdc0b3dd342  movq rax, xmm1
00007bdc0b3dd347  movq r14, xmm15
00007bdc0b3dd34c  vmovq xmm1, rax
00007bdc0b3dd351  vmovq xmm15, r14
00007bdc0b3dd356  movaps xmm13, xmm1
00007bdc0b3dd35a  addsd xmm13, xmm15
00007bdc0b3dd35f  ucomisd xmm13, xmm13
00007bdc0b3dd364  jp 0x00007BDC0B3DD423
00007bdc0b3dd36a  movq xmm13, xmm13
00007bdc0b3dd36f  movq rax, xmm13
00007bdc0b3dd374  movq r14, xmm14
00007bdc0b3dd379  vmovq xmm1, rax
00007bdc0b3dd37e  vmovq xmm15, r14
00007bdc0b3dd383  movaps xmm14, xmm1
00007bdc0b3dd387  addsd xmm14, xmm15
00007bdc0b3dd38c  ucomisd xmm14, xmm14
00007bdc0b3dd391  jp 0x00007BDC0B3DD46B
00007bdc0b3dd397  movq xmm14, xmm14
00007bdc0b3dd39c  movaps [r15+0x110], xmm14
00007bdc0b3dd3a4  mov eax, [r15+0x108]
00007bdc0b3dd3ab  sahf
00007bdc0b3dd3ac  jnz 0x00007BDC0B3DD3DE
00007bdc0b3dd3ae  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3dd3b6  jz 0x00007BDC0B3DD680
00007bdc0b3dd3bc  nop [rax+rax*1], ax
00007bdc0b3dd3c5  nop [rax+rax*1], eax
00007bdc0b3dd3cd  mov eax, 0x410698
00007bdc0b3dd3d2  mov [r15+0x100], rax
00007bdc0b3dd3d9  jmp 0x00007BDC0B1FE110
00007bdc0b3dd3de  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3dd3e6  jz 0x00007BDC0B3DD4C0
00007bdc0b3dd3ec  nop [rax+rax*1], ax
00007bdc0b3dd3f5  nop [rax+rax*1], eax
00007bdc0b3dd3fd  mov eax, 0x41067C
00007bdc0b3dd402  mov [r15+0x100], rax
00007bdc0b3dd409  jmp 0x00007BDC0B1FE110
00007bdc0b3dd40e  int3
00007bdc0b3dd40f  call 0x00007BDC0B20DC20
00007bdc0b3dd414  jmp 0x00007BDC0B3DD2F2
00007bdc0b3dd419  call 0x00007BDC0B20E760
00007bdc0b3dd41e  jmp 0x00007BDC0B3DD301
00007bdc0b3dd423  ucomisd xmm1, xmm15
00007bdc0b3dd428  jp 0x00007BDC0B3DD437
00007bdc0b3dd42a  movaps xmm13, [0x00007BDC0AFFE060]
00007bdc0b3dd432  jmp 0x00007BDC0B3DD36A
00007bdc0b3dd437  vxorps xmm0, xmm1, xmm15
00007bdc0b3dd43c  pextrw eax, xmm0, 0x03
00007bdc0b3dd441  and eax, 0x7FF8
00007bdc0b3dd446  cmp eax, 0x08
00007bdc0b3dd449  jnz 0x00007BDC0B3DD36A
00007bdc0b3dd44f  movq rax, xmm15
00007bdc0b3dd454  shl rax, 0x0D
00007bdc0b3dd458  jbe 0x00007BDC0B3DD36A
00007bdc0b3dd45e  vorps xmm13, xmm15, [0x00007BDC0AFFE070]
00007bdc0b3dd466  jmp 0x00007BDC0B3DD36A
00007bdc0b3dd46b  ucomisd xmm1, xmm15
00007bdc0b3dd470  jp 0x00007BDC0B3DD47F
00007bdc0b3dd472  movaps xmm14, [0x00007BDC0AFFE060]
00007bdc0b3dd47a  jmp 0x00007BDC0B3DD397
00007bdc0b3dd47f  vxorps xmm0, xmm1, xmm15
00007bdc0b3dd484  pextrw eax, xmm0, 0x03
00007bdc0b3dd489  and eax, 0x7FF8
00007bdc0b3dd48e  cmp eax, 0x08
00007bdc0b3dd491  jnz 0x00007BDC0B3DD397
00007bdc0b3dd497  movq rax, xmm15
00007bdc0b3dd49c  shl rax, 0x0D
00007bdc0b3dd4a0  jbe 0x00007BDC0B3DD397
00007bdc0b3dd4a6  vorps xmm14, xmm15, [0x00007BDC0AFFE070]
00007bdc0b3dd4ae  jmp 0x00007BDC0B3DD397
00007bdc0b3dd4b3  int3
00007bdc0b3dd4b4  nop [rax+rax*1], ax
00007bdc0b3dd4bd  nop [rax], eax
00007bdc0b3dd4c0  mov rax, [r15+0x48]
00007bdc0b3dd4c4  mov r14, [r15+0x50]
00007bdc0b3dd4c8  lea r12, [r14+rax*1]
00007bdc0b3dd4cc  movups xmm1, [r13+r12*1]
00007bdc0b3dd4d2  movaps [r15+0x120], xmm1
00007bdc0b3dd4da  lea r14, [rax+0x10]
00007bdc0b3dd4de  mov [r15+0x48], r14
00007bdc0b3dd4e2  xor eax, eax
00007bdc0b3dd4e4  mov r12d, 0x200
00007bdc0b3dd4ea  cmp r14, r12
00007bdc0b3dd4ed  cmc
00007bdc0b3dd4ee  lahf
00007bdc0b3dd4ef  seto al
00007bdc0b3dd4f2  mov [r15+0x108], eax
00007bdc0b3dd4f9  pextrq rax, xmm1, 0x01
00007bdc0b3dd500  movq xmm15, rax
00007bdc0b3dd505  movaps [r15+0x130], xmm15
00007bdc0b3dd50d  movaps xmm14, [r15+0x110]
00007bdc0b3dd515  movq rax, xmm14
00007bdc0b3dd51a  movq r14, xmm1
00007bdc0b3dd51f  vmovq xmm1, rax
00007bdc0b3dd524  vmovq xmm14, r14
00007bdc0b3dd529  movaps xmm13, xmm1
00007bdc0b3dd52d  addsd xmm13, xmm14
00007bdc0b3dd532  ucomisd xmm13, xmm13
00007bdc0b3dd537  jp 0x00007BDC0B3DD5EC
00007bdc0b3dd53d  movq xmm13, xmm13
00007bdc0b3dd542  movq rax, xmm13
00007bdc0b3dd547  movq r14, xmm15
00007bdc0b3dd54c  vmovq xmm1, rax
00007bdc0b3dd551  vmovq xmm15, r14
00007bdc0b3dd556  movaps xmm14, xmm1
00007bdc0b3dd55a  addsd xmm14, xmm15
00007bdc0b3dd55f  ucomisd xmm14, xmm14
00007bdc0b3dd564  jp 0x00007BDC0B3DD634
00007bdc0b3dd56a  movq xmm14, xmm14
00007bdc0b3dd56f  movaps [r15+0x110], xmm14
00007bdc0b3dd577  mov eax, [r15+0x108]
00007bdc0b3dd57e  sahf
00007bdc0b3dd57f  jnz 0x00007BDC0B3DD5B1
00007bdc0b3dd581  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3dd589  jz 0x00007BDC0B3DD680
00007bdc0b3dd58f  nop [rax+rax*1], ax
00007bdc0b3dd598  nop [rax+rax*1], eax
00007bdc0b3dd5a0  mov eax, 0x410698
00007bdc0b3dd5a5  mov [r15+0x100], rax
00007bdc0b3dd5ac  jmp 0x00007BDC0B1FE110
00007bdc0b3dd5b1  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3dd5b9  jz 0x00007BDC0B3DD4C0
00007bdc0b3dd5bf  nop [rax+rax*1], ax
00007bdc0b3dd5c8  nop [rax+rax*1], eax
00007bdc0b3dd5d0  mov eax, 0x41067C
00007bdc0b3dd5d5  mov [r15+0x100], rax
00007bdc0b3dd5dc  jmp 0x00007BDC0B1FE110
00007bdc0b3dd5e1  int3
00007bdc0b3dd5e2  call 0x00007BDC0B2B52F0
00007bdc0b3dd5e7  jmp 0x00007BDC0B3DD4D2
00007bdc0b3dd5ec  ucomisd xmm1, xmm14
00007bdc0b3dd5f1  jp 0x00007BDC0B3DD600
00007bdc0b3dd5f3  movaps xmm13, [0x00007BDC0AFFE060]
00007bdc0b3dd5fb  jmp 0x00007BDC0B3DD53D
00007bdc0b3dd600  vxorps xmm0, xmm1, xmm14
00007bdc0b3dd605  pextrw eax, xmm0, 0x03
00007bdc0b3dd60a  and eax, 0x7FF8
00007bdc0b3dd60f  cmp eax, 0x08
00007bdc0b3dd612  jnz 0x00007BDC0B3DD53D
00007bdc0b3dd618  movq rax, xmm14
00007bdc0b3dd61d  shl rax, 0x0D
00007bdc0b3dd621  jbe 0x00007BDC0B3DD53D
00007bdc0b3dd627  vorps xmm13, xmm14, [0x00007BDC0AFFE070]
00007bdc0b3dd62f  jmp 0x00007BDC0B3DD53D
00007bdc0b3dd634  ucomisd xmm1, xmm15
00007bdc0b3dd639  jp 0x00007BDC0B3DD648
00007bdc0b3dd63b  movaps xmm14, [0x00007BDC0AFFE060]
00007bdc0b3dd643  jmp 0x00007BDC0B3DD56A
00007bdc0b3dd648  vxorps xmm0, xmm1, xmm15
00007bdc0b3dd64d  pextrw eax, xmm0, 0x03
00007bdc0b3dd652  and eax, 0x7FF8
00007bdc0b3dd657  cmp eax, 0x08
00007bdc0b3dd65a  jnz 0x00007BDC0B3DD56A
00007bdc0b3dd660  movq rax, xmm15
00007bdc0b3dd665  shl rax, 0x0D
00007bdc0b3dd669  jbe 0x00007BDC0B3DD56A
00007bdc0b3dd66f  vorps xmm14, xmm15, [0x00007BDC0AFFE070]
00007bdc0b3dd677  jmp 0x00007BDC0B3DD56A
00007bdc0b3dd67c  int3
00007bdc0b3dd67d  nop [rax], eax
00007bdc0b3dd680  mov rax, [r15+0xF8]
00007bdc0b3dd687  lea r14, [rax+0x1A0]
00007bdc0b3dd68e  mov r12, [r13+r14*1]
00007bdc0b3dd693  lea r14, [rax+0x1A8]
00007bdc0b3dd69a  mov r11, [r13+r14*1]
00007bdc0b3dd69f  mov [r15+0xA0], r12
00007bdc0b3dd6a6  mov [r15+0x98], r11
00007bdc0b3dd6ad  mov r14, [r15+0x40]
00007bdc0b3dd6b1  lea r12, [r14+0xC50]
00007bdc0b3dd6b8  movaps xmm1, [r15+0x110]
00007bdc0b3dd6c0  movq r14, xmm1
00007bdc0b3dd6c5  mov [r13+r12*1], r14
00007bdc0b3dd6ca  lea r14, [rax+0x190]
00007bdc0b3dd6d1  mov r12, [r13+r14*1]
00007bdc0b3dd6d6  lea r14, [rax+0x198]
00007bdc0b3dd6dd  mov r11, [r13+r14*1]
00007bdc0b3dd6e2  mov [r15+0xE8], r12
00007bdc0b3dd6e9  mov [r15+0xF0], r11
00007bdc0b3dd6f0  lea r14, [rax+0x180]
00007bdc0b3dd6f7  mov r12, [r13+r14*1]
00007bdc0b3dd6fc  lea r14, [rax+0x188]
00007bdc0b3dd703  mov r10, [r13+r14*1]
00007bdc0b3dd708  movq xmm1, r12
00007bdc0b3dd70d  movq xmm15, r10
00007bdc0b3dd712  movq xmm1, xmm1
00007bdc0b3dd716  movq xmm1, xmm1
00007bdc0b3dd71a  movaps [r15+0x1A0], xmm1
00007bdc0b3dd722  movq xmm15, xmm15
00007bdc0b3dd727  movq xmm15, xmm15
00007bdc0b3dd72c  movaps [r15+0x190], xmm15
00007bdc0b3dd734  lea r14, [rax+0x170]
00007bdc0b3dd73b  mov r12, [r13+r14*1]
00007bdc0b3dd740  lea r14, [rax+0x178]
00007bdc0b3dd747  mov r10, [r13+r14*1]
00007bdc0b3dd74c  movq xmm1, r12
00007bdc0b3dd751  movq xmm15, r10
00007bdc0b3dd756  movq xmm1, xmm1
00007bdc0b3dd75a  movq xmm1, xmm1
00007bdc0b3dd75e  movaps [r15+0x1C0], xmm1
00007bdc0b3dd766  movq xmm15, xmm15
00007bdc0b3dd76b  movq xmm15, xmm15
00007bdc0b3dd770  movaps [r15+0x1B0], xmm15
00007bdc0b3dd778  lea r14, [rax+0x160]
00007bdc0b3dd77f  mov r12, [r13+r14*1]
00007bdc0b3dd784  lea r14, [rax+0x168]
00007bdc0b3dd78b  mov r10, [r13+r14*1]
00007bdc0b3dd790  movq xmm1, r12
00007bdc0b3dd795  movq xmm15, r10
00007bdc0b3dd79a  movq xmm1, xmm1
00007bdc0b3dd79e  movq xmm1, xmm1
00007bdc0b3dd7a2  movaps [r15+0x1E0], xmm1
00007bdc0b3dd7aa  movq xmm15, xmm15
00007bdc0b3dd7af  movq xmm15, xmm15
00007bdc0b3dd7b4  movaps [r15+0x1D0], xmm15
00007bdc0b3dd7bc  lea r14, [rax+0x150]
00007bdc0b3dd7c3  mov r12, [r13+r14*1]
00007bdc0b3dd7c8  lea r14, [rax+0x158]
00007bdc0b3dd7cf  mov r10, [r13+r14*1]
00007bdc0b3dd7d4  movq xmm1, r12
00007bdc0b3dd7d9  movq xmm15, r10
00007bdc0b3dd7de  movq xmm1, xmm1
00007bdc0b3dd7e2  movq xmm1, xmm1
00007bdc0b3dd7e6  movaps [r15+0x200], xmm1
00007bdc0b3dd7ee  movq xmm15, xmm15
00007bdc0b3dd7f3  movq xmm15, xmm15
00007bdc0b3dd7f8  movaps [r15+0x1F0], xmm15
00007bdc0b3dd800  lea r14, [rax+0x1B0]
00007bdc0b3dd807  mov [r15+0xF8], r14
00007bdc0b3dd80e  mov [r15+0x100], r11
00007bdc0b3dd815  jmp 0x00007BDC0B3CE5C0
00007bdc0b3dd81a  int3
00007bdc0b3dd81b  call 0x00007BDC0B2E27E0
00007bdc0b3dd820  jmp 0x00007BDC0B3DD693
00007bdc0b3dd825  call 0x00007BDC0B2E1570
00007bdc0b3dd82a  jmp 0x00007BDC0B3DD69F
00007bdc0b3dd82f  call 0x00007BDC0B2C3FE0
00007bdc0b3dd834  jmp 0x00007BDC0B3DD6CA
00007bdc0b3dd839  call 0x00007BDC0B2E27E0
00007bdc0b3dd83e  jmp 0x00007BDC0B3DD6D6
00007bdc0b3dd843  call 0x00007BDC0B2E1570
00007bdc0b3dd848  jmp 0x00007BDC0B3DD6E2
00007bdc0b3dd84d  call 0x00007BDC0B2E27E0
00007bdc0b3dd852  jmp 0x00007BDC0B3DD6FC
00007bdc0b3dd857  call 0x00007BDC0B2E0300
00007bdc0b3dd85c  jmp 0x00007BDC0B3DD708
00007bdc0b3dd861  call 0x00007BDC0B2E27E0
00007bdc0b3dd866  jmp 0x00007BDC0B3DD740
00007bdc0b3dd86b  call 0x00007BDC0B2E0300
00007bdc0b3dd870  jmp 0x00007BDC0B3DD74C
00007bdc0b3dd875  call 0x00007BDC0B2E27E0
00007bdc0b3dd87a  jmp 0x00007BDC0B3DD784
00007bdc0b3dd87f  call 0x00007BDC0B2E0300
00007bdc0b3dd884  jmp 0x00007BDC0B3DD790
00007bdc0b3dd889  call 0x00007BDC0B2E27E0
00007bdc0b3dd88e  jmp 0x00007BDC0B3DD7C8
00007bdc0b3dd893  call 0x00007BDC0B2E0300
00007bdc0b3dd898  jmp 0x00007BDC0B3DD7D4
00007bdc0b3dd89d  int3
00007bdc0b3dd89e  nop
00007bdc0b3dd8a0  mov qword ptr [r15+0x100], 0x04
00007bdc0b3dd8ab  mov esi, 0x00
00007bdc0b3dd8b0  mov edx, 0x09
00007bdc0b3dd8b5  mov rdi, 0x7FFC539CE990
00007bdc0b3dd8bf  mov rax, 0x62CE43F85970
00007bdc0b3dd8c9  call rax
00007bdc0b3dd8cb  cmp dword ptr [r15+0x318], 0x00
00007bdc0b3dd8d3  jnz 0x00007BDC0B1FE110
00007bdc0b3dd8d9  jmp 0x00007BDC0B1FE0A0
00007bdc0b3dd8de  int3
00007bdc0b3dd8df  int3
