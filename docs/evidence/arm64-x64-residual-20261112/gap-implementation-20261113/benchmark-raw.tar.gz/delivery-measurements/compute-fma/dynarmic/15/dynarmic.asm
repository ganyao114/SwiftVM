000071409bfce69b  nop [rax+rax*1], eax
000071409bfce6a0  mov rax, [r15+0xF8]
000071409bfce6a7  lea r14, [rax-0x1B0]
000071409bfce6ae  mov [r15+0xF8], r14
000071409bfce6b5  lea rax, [r14+0x1A0]
000071409bfce6bc  mov r12, [r15+0xA0]
000071409bfce6c3  mov r11, [r15+0x98]
000071409bfce6ca  mov [r13+rax*1], r12
000071409bfce6cf  lea rax, [r14+0x1A8]
000071409bfce6d6  mov [r13+rax*1], r11
000071409bfce6db  mov eax, 0x420A30
000071409bfce6e0  movups xmm1, [r13+rax*1]
000071409bfce6e6  mov eax, 0x4209C0
000071409bfce6eb  movups xmm15, [r13+rax*1]
000071409bfce6f1  mov eax, 0x420A50
000071409bfce6f6  movups xmm14, [r13+rax*1]
000071409bfce6fc  mov eax, 0x4209F0
000071409bfce701  movups xmm13, [r13+rax*1]
000071409bfce707  mov qword ptr [r15+0x98], 0x430C60
000071409bfce712  mov eax, 0x420A60
000071409bfce717  movups xmm12, [r13+rax*1]
000071409bfce71d  mov eax, 0x430C60
000071409bfce722  movups [r13+rax*1], xmm1
000071409bfce728  mov eax, 0x430C70
000071409bfce72d  movups [r13+rax*1], xmm15
000071409bfce733  mov eax, 0x430C80
000071409bfce738  movups [r13+rax*1], xmm14
000071409bfce73e  mov eax, 0x430C90
000071409bfce743  movups [r13+rax*1], xmm13
000071409bfce749  mov eax, 0x4209B0
000071409bfce74e  movups xmm14, [r13+rax*1]
000071409bfce754  mov eax, 0x4209A0
000071409bfce759  movups xmm13, [r13+rax*1]
000071409bfce75f  mov eax, 0x430D60
000071409bfce764  movups [r13+rax*1], xmm1
000071409bfce76a  mov eax, 0x430D70
000071409bfce76f  movups [r13+rax*1], xmm15
000071409bfce775  mov eax, 0x430CA0
000071409bfce77a  movups [r13+rax*1], xmm12
000071409bfce780  mov eax, 0x430CB0
000071409bfce785  movups [r13+rax*1], xmm14
000071409bfce78b  mov eax, 0x420990
000071409bfce790  movups xmm1, [r13+rax*1]
000071409bfce796  mov eax, 0x420A00
000071409bfce79b  movups xmm15, [r13+rax*1]
000071409bfce7a1  mov eax, 0x430CC0
000071409bfce7a6  movups [r13+rax*1], xmm13
000071409bfce7ac  mov eax, 0x430CD0
000071409bfce7b1  movups [r13+rax*1], xmm1
000071409bfce7b7  mov eax, 0x420A10
000071409bfce7bc  movups xmm1, [r13+rax*1]
000071409bfce7c2  mov eax, 0x4209E0
000071409bfce7c7  movups xmm14, [r13+rax*1]
000071409bfce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000071409bfce7d5  mov eax, 0x430CE0
000071409bfce7da  movups [r13+rax*1], xmm15
000071409bfce7e0  mov eax, 0x430CF0
000071409bfce7e5  movups [r13+rax*1], xmm1
000071409bfce7eb  mov eax, 0x420A80
000071409bfce7f0  movups xmm1, [r13+rax*1]
000071409bfce7f6  mov eax, 0x420A90
000071409bfce7fb  movups xmm15, [r13+rax*1]
000071409bfce801  movaps [r15+0x150], xmm15
000071409bfce809  mov qword ptr [r15+0xA0], 0x3E8
000071409bfce814  mov eax, 0x430D00
000071409bfce819  movups [r13+rax*1], xmm14
000071409bfce81f  mov eax, 0x430D10
000071409bfce824  movups [r13+rax*1], xmm1
000071409bfce82a  mov eax, 0x420A70
000071409bfce82f  movups xmm1, [r13+rax*1]
000071409bfce835  mov eax, 0x420A20
000071409bfce83a  movups xmm14, [r13+rax*1]
000071409bfce840  movaps [r15+0x140], xmm14
000071409bfce848  lea rax, [r14+0x150]
000071409bfce84f  movq xmm13, qword ptr [r15+0x200]
000071409bfce858  movq xmm12, qword ptr [r15+0x1F0]
000071409bfce861  movq r12, xmm13
000071409bfce866  movq r11, xmm12
000071409bfce86b  mov [r13+rax*1], r12
000071409bfce870  lea rax, [r14+0x158]
000071409bfce877  mov [r13+rax*1], r11
000071409bfce87c  mov eax, 0x430D20
000071409bfce881  movups [r13+rax*1], xmm15
000071409bfce887  mov eax, 0x430D30
000071409bfce88c  movups [r13+rax*1], xmm1
000071409bfce892  mov eax, 0x420A40
000071409bfce897  movups xmm1, [r13+rax*1]
000071409bfce89d  mov eax, 0x420AA8
000071409bfce8a2  mov r12, [r13+rax*1]
000071409bfce8a7  movq xmm15, r12
000071409bfce8ac  mov qword ptr [r15+0x40], 0x420AB0
000071409bfce8b4  mov eax, 0x430D40
000071409bfce8b9  movups [r13+rax*1], xmm14
000071409bfce8bf  mov eax, 0x430D50
000071409bfce8c4  movups [r13+rax*1], xmm1
000071409bfce8ca  mov eax, 0x420B10
000071409bfce8cf  movups xmm1, [r13+rax*1]
000071409bfce8d5  movq rax, xmm15
000071409bfce8da  mov r12d, 0x430D80
000071409bfce8e0  mov [r13+r12*1], rax
000071409bfce8e5  mov eax, 0x420AF0
000071409bfce8ea  movups xmm15, [r13+rax*1]
000071409bfce8f0  mov eax, 0x420B00
000071409bfce8f5  movups xmm14, [r13+rax*1]
000071409bfce8fb  lea rax, [r14+0x130]
000071409bfce902  movups [r13+rax*1], xmm1
000071409bfce908  lea rax, [r14+0x160]
000071409bfce90f  movq xmm1, qword ptr [r15+0x1E0]
000071409bfce918  movq xmm13, qword ptr [r15+0x1D0]
000071409bfce921  movq r12, xmm1
000071409bfce926  movq r11, xmm13
000071409bfce92b  mov [r13+rax*1], r12
000071409bfce930  lea rax, [r14+0x168]
000071409bfce937  mov [r13+rax*1], r11
000071409bfce93c  lea rax, [r14+0x110]
000071409bfce943  movups [r13+rax*1], xmm15
000071409bfce949  lea rax, [r14+0x120]
000071409bfce950  movups [r13+rax*1], xmm14
000071409bfce956  mov eax, 0x420AB0
000071409bfce95b  movups xmm1, [r13+rax*1]
000071409bfce961  mov eax, 0x420AC0
000071409bfce966  movups xmm15, [r13+rax*1]
000071409bfce96c  movaps [r15+0x120], xmm15
000071409bfce974  lea rax, [r14+0x170]
000071409bfce97b  movq xmm14, qword ptr [r15+0x1C0]
000071409bfce984  movq xmm13, qword ptr [r15+0x1B0]
000071409bfce98d  movq r12, xmm14
000071409bfce992  movq r11, xmm13
000071409bfce997  mov [r13+rax*1], r12
000071409bfce99c  lea rax, [r14+0x178]
000071409bfce9a3  mov [r13+rax*1], r11
000071409bfce9a8  lea rax, [r14+0x180]
000071409bfce9af  movq xmm14, qword ptr [r15+0x1A0]
000071409bfce9b8  movq xmm13, qword ptr [r15+0x190]
000071409bfce9c1  movq r12, xmm14
000071409bfce9c6  movq r11, xmm13
000071409bfce9cb  mov [r13+rax*1], r12
000071409bfce9d0  lea rax, [r14+0x188]
000071409bfce9d7  mov [r13+rax*1], r11
000071409bfce9dc  lea rax, [r14+0xD0]
000071409bfce9e3  movups [r13+rax*1], xmm1
000071409bfce9e9  lea rax, [r14+0xE0]
000071409bfce9f0  movups [r13+rax*1], xmm15
000071409bfce9f6  mov eax, 0x420AD0
000071409bfce9fb  movups xmm1, [r13+rax*1]
000071409bfcea01  mov eax, 0x420AE0
000071409bfcea06  movups xmm15, [r13+rax*1]
000071409bfcea0c  movaps [r15+0x110], xmm1
000071409bfcea14  movaps [r15+0x130], xmm15
000071409bfcea1c  lea rax, [r14+0x190]
000071409bfcea23  mov r12, [r15+0xE8]
000071409bfcea2a  mov r11, [r15+0xF0]
000071409bfcea31  mov [r13+rax*1], r12
000071409bfcea36  lea rax, [r14+0x198]
000071409bfcea3d  mov [r13+rax*1], r11
000071409bfcea42  mov eax, 0x430D88
000071409bfcea47  mov r12d, 0x421DF8D3
000071409bfcea4d  mov [r13+rax*1], r12d
000071409bfcea52  lea rax, [r14+0xF0]
000071409bfcea59  movups [r13+rax*1], xmm1
000071409bfcea5f  lea rax, [r14+0x100]
000071409bfcea66  movups [r13+rax*1], xmm15
000071409bfcea6c  lea rax, [r14+0xD0]
000071409bfcea73  mov [r15], rax
000071409bfcea76  mov qword ptr [r15+0x08], 0x430C60
000071409bfcea7e  mov qword ptr [r15+0x10], 0x12C
000071409bfcea86  mov qword ptr [r15+0xF0], 0x410284
000071409bfcea91  mov r14d, [r15+0x320]
000071409bfcea98  mov eax, 0x410284
000071409bfcea9d  mov rcx, 0x71409BFD07C0
000071409bfceaa7  mov [r15+r14*8+0x328], rax
000071409bfceaaf  mov [r15+r14*8+0x368], rcx
000071409bfceab7  add r14d, 0x01
000071409bfceabb  and r14d, 0x07
000071409bfceabf  mov [r15+0x320], r14d
000071409bfceac6  cmp dword ptr [r15+0x318], 0x00
000071409bfceace  jz 0x000071409BFCED70
000071409bfcead4  nop [rax+rax*1], ax
000071409bfceadd  nop [rax+rax*1], eax
000071409bfceae5  mov eax, 0x4106BC
000071409bfceaea  mov [r15+0x100], rax
000071409bfceaf1  jmp 0x000071409BDFE110
000071409bfceaf6  int3
000071409bfceaf7  call 0x000071409BE0BC20
000071409bfceafc  jmp 0x000071409BFCE6CF
000071409bfceb01  call 0x000071409BE0A9A0
000071409bfceb06  jmp 0x000071409BFCE6DB
000071409bfceb0b  call 0x000071409BDFF430
000071409bfceb10  jmp 0x000071409BFCE6E6
000071409bfceb15  call 0x000071409BE0E760
000071409bfceb1a  jmp 0x000071409BFCE6F1
000071409bfceb1f  call 0x000071409BE0D4E0
000071409bfceb24  jmp 0x000071409BFCE6FC
000071409bfceb29  call 0x000071409BE0C260
000071409bfceb2e  jmp 0x000071409BFCE707
000071409bfceb33  call 0x000071409BE0AFE0
000071409bfceb38  jmp 0x000071409BFCE71D
000071409bfceb3d  call 0x000071409BDFF540
000071409bfceb42  jmp 0x000071409BFCE728
000071409bfceb47  call 0x000071409BE0E880
000071409bfceb4c  jmp 0x000071409BFCE733
000071409bfceb51  call 0x000071409BE0D600
000071409bfceb56  jmp 0x000071409BFCE73E
000071409bfceb5b  call 0x000071409BE0C380
000071409bfceb60  jmp 0x000071409BFCE749
000071409bfceb65  call 0x000071409BE0D4E0
000071409bfceb6a  jmp 0x000071409BFCE754
000071409bfceb6f  call 0x000071409BE0C260
000071409bfceb74  jmp 0x000071409BFCE75F
000071409bfceb79  call 0x000071409BDFF540
000071409bfceb7e  jmp 0x000071409BFCE76A
000071409bfceb83  call 0x000071409BE0E880
000071409bfceb88  jmp 0x000071409BFCE775
000071409bfceb8d  call 0x000071409BE0B100
000071409bfceb92  jmp 0x000071409BFCE780
000071409bfceb97  call 0x000071409BE0D600
000071409bfceb9c  jmp 0x000071409BFCE78B
000071409bfceba1  call 0x000071409BDFF430
000071409bfceba6  jmp 0x000071409BFCE796
000071409bfcebab  call 0x000071409BE0E760
000071409bfcebb0  jmp 0x000071409BFCE7A1
000071409bfcebb5  call 0x000071409BE0C380
000071409bfcebba  jmp 0x000071409BFCE7AC
000071409bfcebbf  call 0x000071409BDFF540
000071409bfcebc4  jmp 0x000071409BFCE7B7
000071409bfcebc9  call 0x000071409BDFF430
000071409bfcebce  jmp 0x000071409BFCE7C2
000071409bfcebd3  call 0x000071409BE0D4E0
000071409bfcebd8  jmp 0x000071409BFCE7CD
000071409bfcebdd  call 0x000071409BE0E880
000071409bfcebe2  jmp 0x000071409BFCE7E0
000071409bfcebe7  call 0x000071409BDFF540
000071409bfcebec  jmp 0x000071409BFCE7EB
000071409bfcebf1  call 0x000071409BDFF430
000071409bfcebf6  jmp 0x000071409BFCE7F6
000071409bfcebfb  call 0x000071409BE0E760
000071409bfcec00  jmp 0x000071409BFCE801
000071409bfcec05  call 0x000071409BE0D600
000071409bfcec0a  jmp 0x000071409BFCE81F
000071409bfcec0f  call 0x000071409BDFF540
000071409bfcec14  jmp 0x000071409BFCE82A
000071409bfcec19  call 0x000071409BDFF430
000071409bfcec1e  jmp 0x000071409BFCE835
000071409bfcec23  call 0x000071409BE0D4E0
000071409bfcec28  jmp 0x000071409BFCE840
000071409bfcec2d  call 0x000071409BE0BC20
000071409bfcec32  jmp 0x000071409BFCE870
000071409bfcec37  call 0x000071409BE0A9A0
000071409bfcec3c  jmp 0x000071409BFCE87C
000071409bfcec41  call 0x000071409BE0E880
000071409bfcec46  jmp 0x000071409BFCE887
000071409bfcec4b  call 0x000071409BDFF540
000071409bfcec50  jmp 0x000071409BFCE892
000071409bfcec55  call 0x000071409BDFF430
000071409bfcec5a  jmp 0x000071409BFCE89D
000071409bfcec5f  call 0x000071409BE0B720
000071409bfcec64  jmp 0x000071409BFCE8A7
000071409bfcec69  call 0x000071409BE0D600
000071409bfcec6e  jmp 0x000071409BFCE8BF
000071409bfcec73  call 0x000071409BDFF540
000071409bfcec78  jmp 0x000071409BFCE8CA
000071409bfcec7d  call 0x000071409BDFF430
000071409bfcec82  jmp 0x000071409BFCE8D5
000071409bfcec87  call 0x000071409BEB4CB0
000071409bfcec8c  jmp 0x000071409BFCE8E5
000071409bfcec91  call 0x000071409BE0E760
000071409bfcec96  jmp 0x000071409BFCE8F0
000071409bfcec9b  call 0x000071409BE0D4E0
000071409bfceca0  jmp 0x000071409BFCE8FB
000071409bfceca5  call 0x000071409BDFF540
000071409bfcecaa  jmp 0x000071409BFCE908
000071409bfcecaf  call 0x000071409BE0BC20
000071409bfcecb4  jmp 0x000071409BFCE930
000071409bfcecb9  call 0x000071409BE0A9A0
000071409bfcecbe  jmp 0x000071409BFCE93C
000071409bfcecc3  call 0x000071409BE0E880
000071409bfcecc8  jmp 0x000071409BFCE949
000071409bfceccd  call 0x000071409BE0D600
000071409bfcecd2  jmp 0x000071409BFCE956
000071409bfcecd7  call 0x000071409BDFF430
000071409bfcecdc  jmp 0x000071409BFCE961
000071409bfcece1  call 0x000071409BE0E760
000071409bfcece6  jmp 0x000071409BFCE96C
000071409bfceceb  call 0x000071409BE0BC20
000071409bfcecf0  jmp 0x000071409BFCE99C
000071409bfcecf5  call 0x000071409BE0A9A0
000071409bfcecfa  jmp 0x000071409BFCE9A8
000071409bfcecff  call 0x000071409BE0BC20
000071409bfced04  jmp 0x000071409BFCE9D0
000071409bfced09  call 0x000071409BE0A9A0
000071409bfced0e  jmp 0x000071409BFCE9DC
000071409bfced13  call 0x000071409BDFF540
000071409bfced18  jmp 0x000071409BFCE9E9
000071409bfced1d  call 0x000071409BE0E880
000071409bfced22  jmp 0x000071409BFCE9F6
000071409bfced27  call 0x000071409BDFF430
000071409bfced2c  jmp 0x000071409BFCEA01
000071409bfced31  call 0x000071409BE0E760
000071409bfced36  jmp 0x000071409BFCEA0C
000071409bfced3b  call 0x000071409BE0BC20
000071409bfced40  jmp 0x000071409BFCEA36
000071409bfced45  call 0x000071409BE0A9A0
000071409bfced4a  jmp 0x000071409BFCEA42
000071409bfced4f  call 0x000071409BE0BAE0
000071409bfced54  jmp 0x000071409BFCEA52
000071409bfced59  call 0x000071409BDFF540
000071409bfced5e  jmp 0x000071409BFCEA5F
000071409bfced63  call 0x000071409BE0E880
000071409bfced68  jmp 0x000071409BFCEA6C
000071409bfced6d  int3
000071409bfced6e  nop
000071409bfced70  mov rax, [r15]
000071409bfced73  lea r14, [rax+0x20]
000071409bfced77  mov r12, [r13+r14*1]
000071409bfced7c  mov r14, [r15+0x10]
000071409bfced80  lea r11, [r12+r14*1]
000071409bfced84  mov [r15+0x40], r11
000071409bfced88  lea r12, [rax+0x20]
000071409bfced8c  mov [r13+r12*1], r11
000071409bfced91  test r14, r14
000071409bfced94  setz r14b
000071409bfced98  movzx r14, r14b
000071409bfced9c  mov [rsp+0x414], r14b
000071409bfceda4  cmp byte ptr [rsp+0x414], 0x00
000071409bfcedac  jz 0x000071409BFCEDDE
000071409bfcedae  cmp dword ptr [r15+0x318], 0x00
000071409bfcedb6  mov eax, 0x410934
000071409bfcedbb  mov [r15+0x100], rax
000071409bfcedc2  jz 0x000071409BDFE0A0
000071409bfcedc8  nop [rax+rax*1], eax
000071409bfcedcd  mov eax, 0x410934
000071409bfcedd2  mov [r15+0x100], rax
000071409bfcedd9  jmp 0x000071409BDFE110
000071409bfcedde  cmp dword ptr [r15+0x318], 0x00
000071409bfcede6  jz 0x000071409BFCEE30
000071409bfcedec  nop [rax+rax*1], ax
000071409bfcedf5  nop [rax+rax*1], eax
000071409bfcedfd  mov eax, 0x4106CC
000071409bfcee02  mov [r15+0x100], rax
000071409bfcee09  jmp 0x000071409BDFE110
000071409bfcee0e  int3
000071409bfcee0f  call 0x000071409BEE27E0
000071409bfcee14  jmp 0x000071409BFCED7C
000071409bfcee19  call 0x000071409BEC0860
000071409bfcee1e  jmp 0x000071409BFCED91
000071409bfcee23  int3
000071409bfcee24  nop [rax+rax*1], ax
000071409bfcee2d  nop [rax], eax
000071409bfcee30  mov rax, [r15+0xF8]
000071409bfcee37  lea r14, [rax-0x150]
000071409bfcee3e  mov [r15+0xF8], r14
000071409bfcee45  mov rax, [r15]
000071409bfcee48  lea r12, [rax+0x68]
000071409bfcee4c  mov r11, [r13+r12*1]
000071409bfcee51  mov [r15+0x88], r11
000071409bfcee58  lea r12, [rax+0x28]
000071409bfcee5c  mov [r15+0x40], r12
000071409bfcee60  mov [r15+0x48], r14
000071409bfcee64  mov qword ptr [r15+0x50], 0x420B20
000071409bfcee6c  lea rax, [r14+0x100]
000071409bfcee73  mov r12, [r15+0xE8]
000071409bfcee7a  mov r11, [r15+0xD8]
000071409bfcee81  mov [r13+rax*1], r12
000071409bfcee86  lea rax, [r14+0x108]
000071409bfcee8d  mov [r13+rax*1], r11
000071409bfcee92  lea rax, [r14+0x110]
000071409bfcee99  mov r12, [r15+0xD0]
000071409bfceea0  mov r11, [r15+0xC8]
000071409bfceea7  mov [r13+rax*1], r12
000071409bfceeac  lea rax, [r14+0x118]
000071409bfceeb3  mov [r13+rax*1], r11
000071409bfceeb8  lea rax, [r14+0x120]
000071409bfceebf  mov r12, [r15+0xC0]
000071409bfceec6  mov r11, [r15+0xB8]
000071409bfceecd  mov [r13+rax*1], r12
000071409bfceed2  lea rax, [r14+0x128]
000071409bfceed9  mov [r13+rax*1], r11
000071409bfceede  lea rax, [r14+0x130]
000071409bfceee5  mov r12, [r15+0xB0]
000071409bfceeec  mov r11, [r15+0xA8]
000071409bfceef3  mov [r13+rax*1], r12
000071409bfceef8  lea rax, [r14+0x138]
000071409bfceeff  mov [r13+rax*1], r11
000071409bfcef04  lea rax, [r14+0x140]
000071409bfcef0b  mov r12, [r15+0xA0]
000071409bfcef12  mov r11, [r15+0x98]
000071409bfcef19  mov [r13+rax*1], r12
000071409bfcef1e  lea rax, [r14+0x148]
000071409bfcef25  mov [r13+rax*1], r11
000071409bfcef2a  cmp dword ptr [r15+0x318], 0x00
000071409bfcef32  jz 0x000071409BFCEFD0
000071409bfcef38  nop [rax+rax*1], ax
000071409bfcef41  nop [rax+rax*1], eax
000071409bfcef49  mov eax, 0x410704
000071409bfcef4e  mov [r15+0x100], rax
000071409bfcef55  jmp 0x000071409BDFE110
000071409bfcef5a  int3
000071409bfcef5b  call 0x000071409BEC0370
000071409bfcef60  jmp 0x000071409BFCEE51
000071409bfcef65  call 0x000071409BE0BC20
000071409bfcef6a  jmp 0x000071409BFCEE86
000071409bfcef6f  call 0x000071409BE0A9A0
000071409bfcef74  jmp 0x000071409BFCEE92
000071409bfcef79  call 0x000071409BE0BC20
000071409bfcef7e  jmp 0x000071409BFCEEAC
000071409bfcef83  call 0x000071409BE0A9A0
000071409bfcef88  jmp 0x000071409BFCEEB8
000071409bfcef8d  call 0x000071409BE0BC20
000071409bfcef92  jmp 0x000071409BFCEED2
000071409bfcef97  call 0x000071409BE0A9A0
000071409bfcef9c  jmp 0x000071409BFCEEDE
000071409bfcefa1  call 0x000071409BE0BC20
000071409bfcefa6  jmp 0x000071409BFCEEF8
000071409bfcefab  call 0x000071409BE0A9A0
000071409bfcefb0  jmp 0x000071409BFCEF04
000071409bfcefb5  call 0x000071409BE0BC20
000071409bfcefba  jmp 0x000071409BFCEF1E
000071409bfcefbf  call 0x000071409BE0A9A0
000071409bfcefc4  jmp 0x000071409BFCEF2A
000071409bfcefc9  int3
000071409bfcefca  nop [rax+rax*1], ax
000071409bfcefd0  mov rax, [r15+0x08]
000071409bfcefd4  movzx r14d, byte ptr [r13+rax*1]
000071409bfcefda  movzx r14d, r14b
000071409bfcefde  mov [rsp+0x10], r14d
000071409bfcefe3  mov r14d, r14d
000071409bfcefe6  mov [r15+0x58], r14
000071409bfcefea  lea r14, [rax+0x01]
000071409bfcefee  mov [r15+0x08], r14
000071409bfceff2  mov rax, [r15+0x88]
000071409bfceff9  lea r14, [rax+0x01]
000071409bfceffd  mov r12, [r15]
000071409bfcf000  lea r11, [r12+0x68]
000071409bfcf005  mov [r13+r11*1], r14
000071409bfcf00a  lea r14, [r12+rax*1]
000071409bfcf00e  mov [r15+0x60], r14
000071409bfcf012  lea rax, [r14+0x28]
000071409bfcf016  mov r11d, [rsp+0x10]
000071409bfcf01b  movzx r14d, r11b
000071409bfcf01f  mov [r13+rax*1], r14b
000071409bfcf024  lea rax, [r12+0x68]
000071409bfcf029  mov r14, [r13+rax*1]
000071409bfcf02e  mov [r15+0x88], r14
000071409bfcf035  xor eax, eax
000071409bfcf037  mov r12d, 0x40
000071409bfcf03d  cmp r14, r12
000071409bfcf040  cmc
000071409bfcf041  lahf
000071409bfcf042  seto al
000071409bfcf045  mov [r15+0x108], eax
000071409bfcf04c  mov eax, [r15+0x108]
000071409bfcf053  sahf
000071409bfcf054  jnz 0x000071409BFCF086
000071409bfcf056  cmp dword ptr [r15+0x318], 0x00
000071409bfcf05e  jz 0x000071409BFCF170
000071409bfcf064  nop [rax+rax*1], ax
000071409bfcf06d  nop [rax+rax*1], eax
000071409bfcf075  mov eax, 0x410724
000071409bfcf07a  mov [r15+0x100], rax
000071409bfcf081  jmp 0x000071409BDFE110
000071409bfcf086  cmp dword ptr [r15+0x318], 0x00
000071409bfcf08e  jz 0x000071409BFCF0E0
000071409bfcf094  nop [rax+rax*1], ax
000071409bfcf09d  nop [rax+rax*1], eax
000071409bfcf0a5  mov eax, 0x4106FC
000071409bfcf0aa  mov [r15+0x100], rax
000071409bfcf0b1  jmp 0x000071409BDFE110
000071409bfcf0b6  int3
000071409bfcf0b7  call 0x000071409BE0D860
000071409bfcf0bc  jmp 0x000071409BFCEFDA
000071409bfcf0c1  call 0x000071409BEB36E0
000071409bfcf0c6  jmp 0x000071409BFCF00A
000071409bfcf0cb  call 0x000071409BE0DD60
000071409bfcf0d0  jmp 0x000071409BFCF024
000071409bfcf0d5  call 0x000071409BE0DC20
000071409bfcf0da  jmp 0x000071409BFCF02E
000071409bfcf0df  int3
000071409bfcf0e0  mov rax, [r15+0x10]
000071409bfcf0e4  lea r14, [rax-0x01]
000071409bfcf0e8  mov [r15+0x10], r14
000071409bfcf0ec  test r14, r14
000071409bfcf0ef  setz r14b
000071409bfcf0f3  movzx r14, r14b
000071409bfcf0f7  mov [rsp+0x414], r14b
000071409bfcf0ff  cmp byte ptr [rsp+0x414], 0x00
000071409bfcf107  jz 0x000071409BFCF139
000071409bfcf109  cmp dword ptr [r15+0x318], 0x00
000071409bfcf111  jz 0x000071409BFD0670
000071409bfcf117  nop [rax+rax*1], ax
000071409bfcf120  nop [rax+rax*1], eax
000071409bfcf128  mov eax, 0x41091C
000071409bfcf12d  mov [r15+0x100], rax
000071409bfcf134  jmp 0x000071409BDFE110
000071409bfcf139  cmp dword ptr [r15+0x318], 0x00
000071409bfcf141  jz 0x000071409BFCEFD0
000071409bfcf147  nop [rax+rax*1], ax
000071409bfcf150  nop [rax+rax*1], eax
000071409bfcf158  mov eax, 0x410704
000071409bfcf15d  mov [r15+0x100], rax
000071409bfcf164  jmp 0x000071409BDFE110
000071409bfcf169  int3
000071409bfcf16a  int3
000071409bfcf16b  nop [rax+rax*1], eax
000071409bfcf170  mov rax, [r15+0x40]
000071409bfcf174  movzx r14d, byte ptr [r13+rax*1]
000071409bfcf17a  movaps xmm1, [r15+0x110]
000071409bfcf182  pinsrb xmm1, r14d, 0x00
000071409bfcf189  lea r14, [rax+0x01]
000071409bfcf18d  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf193  movaps xmm15, [r15+0x120]
000071409bfcf19b  pinsrb xmm15, r12d, 0x00
000071409bfcf1a2  lea r14, [rax+0x02]
000071409bfcf1a6  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf1ac  movaps xmm14, [r15+0x130]
000071409bfcf1b4  pinsrb xmm14, r12d, 0x00
000071409bfcf1bb  lea r14, [rax+0x03]
000071409bfcf1bf  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf1c5  movaps xmm13, [r15+0x140]
000071409bfcf1cd  pinsrb xmm13, r12d, 0x00
000071409bfcf1d4  lea r14, [rax+0x04]
000071409bfcf1d8  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf1de  pinsrb xmm1, r12d, 0x01
000071409bfcf1e5  lea r14, [rax+0x05]
000071409bfcf1e9  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf1ef  pinsrb xmm15, r12d, 0x01
000071409bfcf1f6  lea r14, [rax+0x06]
000071409bfcf1fa  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf200  pinsrb xmm14, r12d, 0x01
000071409bfcf207  lea r14, [rax+0x07]
000071409bfcf20b  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf211  pinsrb xmm13, r12d, 0x01
000071409bfcf218  lea r14, [rax+0x08]
000071409bfcf21c  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf222  pinsrb xmm1, r12d, 0x02
000071409bfcf229  lea r14, [rax+0x09]
000071409bfcf22d  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf233  pinsrb xmm15, r12d, 0x02
000071409bfcf23a  lea r14, [rax+0x0A]
000071409bfcf23e  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf244  pinsrb xmm14, r12d, 0x02
000071409bfcf24b  lea r14, [rax+0x0B]
000071409bfcf24f  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf255  pinsrb xmm13, r12d, 0x02
000071409bfcf25c  lea r14, [rax+0x0C]
000071409bfcf260  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf266  pinsrb xmm1, r12d, 0x03
000071409bfcf26d  lea r14, [rax+0x0D]
000071409bfcf271  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf277  pinsrb xmm15, r12d, 0x03
000071409bfcf27e  lea r14, [rax+0x0E]
000071409bfcf282  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf288  pinsrb xmm14, r12d, 0x03
000071409bfcf28f  lea r14, [rax+0x0F]
000071409bfcf293  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf299  pinsrb xmm13, r12d, 0x03
000071409bfcf2a0  lea r14, [rax+0x10]
000071409bfcf2a4  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf2aa  pinsrb xmm1, r12d, 0x04
000071409bfcf2b1  lea r14, [rax+0x11]
000071409bfcf2b5  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf2bb  pinsrb xmm15, r12d, 0x04
000071409bfcf2c2  lea r14, [rax+0x12]
000071409bfcf2c6  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf2cc  pinsrb xmm14, r12d, 0x04
000071409bfcf2d3  lea r14, [rax+0x13]
000071409bfcf2d7  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf2dd  pinsrb xmm13, r12d, 0x04
000071409bfcf2e4  lea r14, [rax+0x14]
000071409bfcf2e8  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf2ee  pinsrb xmm1, r12d, 0x05
000071409bfcf2f5  lea r14, [rax+0x15]
000071409bfcf2f9  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf2ff  pinsrb xmm15, r12d, 0x05
000071409bfcf306  lea r14, [rax+0x16]
000071409bfcf30a  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf310  pinsrb xmm14, r12d, 0x05
000071409bfcf317  lea r14, [rax+0x17]
000071409bfcf31b  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf321  pinsrb xmm13, r12d, 0x05
000071409bfcf328  lea r14, [rax+0x18]
000071409bfcf32c  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf332  pinsrb xmm1, r12d, 0x06
000071409bfcf339  lea r14, [rax+0x19]
000071409bfcf33d  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf343  pinsrb xmm15, r12d, 0x06
000071409bfcf34a  lea r14, [rax+0x1A]
000071409bfcf34e  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf354  pinsrb xmm14, r12d, 0x06
000071409bfcf35b  lea r14, [rax+0x1B]
000071409bfcf35f  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf365  pinsrb xmm13, r12d, 0x06
000071409bfcf36c  lea r14, [rax+0x1C]
000071409bfcf370  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf376  pinsrb xmm1, r12d, 0x07
000071409bfcf37d  lea r14, [rax+0x1D]
000071409bfcf381  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf387  pinsrb xmm15, r12d, 0x07
000071409bfcf38e  lea r14, [rax+0x1E]
000071409bfcf392  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf398  pinsrb xmm14, r12d, 0x07
000071409bfcf39f  lea r14, [rax+0x1F]
000071409bfcf3a3  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf3a9  pinsrb xmm13, r12d, 0x07
000071409bfcf3b0  lea r14, [rax+0x20]
000071409bfcf3b4  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf3ba  pinsrb xmm1, r12d, 0x08
000071409bfcf3c1  lea r14, [rax+0x21]
000071409bfcf3c5  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf3cb  pinsrb xmm15, r12d, 0x08
000071409bfcf3d2  lea r14, [rax+0x22]
000071409bfcf3d6  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf3dc  pinsrb xmm14, r12d, 0x08
000071409bfcf3e3  lea r14, [rax+0x23]
000071409bfcf3e7  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf3ed  pinsrb xmm13, r12d, 0x08
000071409bfcf3f4  lea r14, [rax+0x24]
000071409bfcf3f8  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf3fe  pinsrb xmm1, r12d, 0x09
000071409bfcf405  lea r14, [rax+0x25]
000071409bfcf409  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf40f  pinsrb xmm15, r12d, 0x09
000071409bfcf416  lea r14, [rax+0x26]
000071409bfcf41a  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf420  pinsrb xmm14, r12d, 0x09
000071409bfcf427  lea r14, [rax+0x27]
000071409bfcf42b  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf431  pinsrb xmm13, r12d, 0x09
000071409bfcf438  lea r14, [rax+0x28]
000071409bfcf43c  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf442  pinsrb xmm1, r12d, 0x0A
000071409bfcf449  lea r14, [rax+0x29]
000071409bfcf44d  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf453  pinsrb xmm15, r12d, 0x0A
000071409bfcf45a  lea r14, [rax+0x2A]
000071409bfcf45e  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf464  pinsrb xmm14, r12d, 0x0A
000071409bfcf46b  lea r14, [rax+0x2B]
000071409bfcf46f  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf475  pinsrb xmm13, r12d, 0x0A
000071409bfcf47c  lea r14, [rax+0x2C]
000071409bfcf480  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf486  pinsrb xmm1, r12d, 0x0B
000071409bfcf48d  lea r14, [rax+0x2D]
000071409bfcf491  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf497  pinsrb xmm15, r12d, 0x0B
000071409bfcf49e  lea r14, [rax+0x2E]
000071409bfcf4a2  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf4a8  pinsrb xmm14, r12d, 0x0B
000071409bfcf4af  lea r14, [rax+0x2F]
000071409bfcf4b3  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf4b9  pinsrb xmm13, r12d, 0x0B
000071409bfcf4c0  lea r14, [rax+0x30]
000071409bfcf4c4  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf4ca  pinsrb xmm1, r12d, 0x0C
000071409bfcf4d1  lea r14, [rax+0x31]
000071409bfcf4d5  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf4db  pinsrb xmm15, r12d, 0x0C
000071409bfcf4e2  lea r14, [rax+0x32]
000071409bfcf4e6  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf4ec  pinsrb xmm14, r12d, 0x0C
000071409bfcf4f3  lea r14, [rax+0x33]
000071409bfcf4f7  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf4fd  pinsrb xmm13, r12d, 0x0C
000071409bfcf504  lea r14, [rax+0x34]
000071409bfcf508  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf50e  pinsrb xmm1, r12d, 0x0D
000071409bfcf515  lea r14, [rax+0x35]
000071409bfcf519  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf51f  pinsrb xmm15, r12d, 0x0D
000071409bfcf526  lea r14, [rax+0x36]
000071409bfcf52a  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf530  pinsrb xmm14, r12d, 0x0D
000071409bfcf537  lea r14, [rax+0x37]
000071409bfcf53b  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf541  pinsrb xmm13, r12d, 0x0D
000071409bfcf548  lea r14, [rax+0x38]
000071409bfcf54c  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf552  pinsrb xmm1, r12d, 0x0E
000071409bfcf559  lea r14, [rax+0x39]
000071409bfcf55d  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf563  pinsrb xmm15, r12d, 0x0E
000071409bfcf56a  lea r14, [rax+0x3A]
000071409bfcf56e  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf574  pinsrb xmm14, r12d, 0x0E
000071409bfcf57b  lea r14, [rax+0x3B]
000071409bfcf57f  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf585  pinsrb xmm13, r12d, 0x0E
000071409bfcf58c  lea r14, [rax+0x3C]
000071409bfcf590  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf596  pinsrb xmm1, r12d, 0x0F
000071409bfcf59d  movaps [r15+0x110], xmm1
000071409bfcf5a5  lea r14, [rax+0x3D]
000071409bfcf5a9  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf5af  pinsrb xmm15, r12d, 0x0F
000071409bfcf5b6  movaps [r15+0x120], xmm15
000071409bfcf5be  lea r14, [rax+0x3E]
000071409bfcf5c2  movzx r12d, byte ptr [r13+r14*1]
000071409bfcf5c8  pinsrb xmm14, r12d, 0x0F
000071409bfcf5cf  movaps [r15+0x130], xmm14
000071409bfcf5d7  lea r14, [rax+0x3F]
000071409bfcf5db  movzx eax, byte ptr [r13+r14*1]
000071409bfcf5e1  pinsrb xmm13, eax, 0x0F
000071409bfcf5e8  movaps [r15+0x140], xmm13
000071409bfcf5f0  movq xmm1, qword ptr [r15+0x120]
000071409bfcf5f9  pmovzxbw xmm1, xmm1
000071409bfcf5fe  psllw xmm1, 0x00
000071409bfcf603  movaps [r15+0x150], xmm1
000071409bfcf60b  movq xmm1, qword ptr [r15+0x130]
000071409bfcf614  pmovzxbw xmm1, xmm1
000071409bfcf619  psllw xmm1, 0x00
000071409bfcf61e  movaps [r15+0x160], xmm1
000071409bfcf626  movq xmm1, qword ptr [r15+0x110]
000071409bfcf62f  pmovzxbw xmm1, xmm1
000071409bfcf634  psllw xmm1, 0x00
000071409bfcf639  movaps [r15+0x170], xmm1
000071409bfcf641  movaps xmm15, [r15+0x110]
000071409bfcf649  pextrq rax, xmm15, 0x01
000071409bfcf650  movq xmm15, rax
000071409bfcf655  pmovzxbw xmm15, xmm15
000071409bfcf65b  psllw xmm15, 0x00
000071409bfcf661  movaps [r15+0x180], xmm15
000071409bfcf669  movaps xmm14, [r15+0x120]
000071409bfcf671  pextrq rax, xmm14, 0x01
000071409bfcf678  movq xmm14, rax
000071409bfcf67d  pmovzxbw xmm14, xmm14
000071409bfcf683  psllw xmm14, 0x00
000071409bfcf689  movaps [r15+0x210], xmm14
000071409bfcf691  movaps xmm13, [r15+0x130]
000071409bfcf699  pextrq rax, xmm13, 0x01
000071409bfcf6a0  movq xmm13, rax
000071409bfcf6a5  pmovzxbw xmm13, xmm13
000071409bfcf6ab  psllw xmm13, 0x00
000071409bfcf6b1  movaps [r15+0x220], xmm13
000071409bfcf6b9  movq xmm12, qword ptr [r15+0x140]
000071409bfcf6c2  pmovzxbw xmm12, xmm12
000071409bfcf6c8  psllw xmm12, 0x00
000071409bfcf6ce  movaps [r15+0x250], xmm12
000071409bfcf6d6  movaps xmm12, [r15+0x140]
000071409bfcf6de  pextrq rax, xmm12, 0x01
000071409bfcf6e5  movq xmm12, rax
000071409bfcf6ea  pmovzxbw xmm12, xmm12
000071409bfcf6f0  psllw xmm12, 0x00
000071409bfcf6f6  movaps [r15+0x110], xmm12
000071409bfcf6fe  movq xmm11, qword ptr [r15+0x150]
000071409bfcf707  pmovzxwd xmm11, xmm11
000071409bfcf70d  pslld xmm11, 0x10
000071409bfcf713  movq xmm10, qword ptr [r15+0x160]
000071409bfcf71c  pmovzxwd xmm10, xmm10
000071409bfcf722  pslld xmm10, 0x08
000071409bfcf728  pextrq rax, xmm1, 0x01
000071409bfcf72f  movq xmm1, rax
000071409bfcf734  pmovzxwd xmm1, xmm1
000071409bfcf739  pslld xmm1, 0x00
000071409bfcf73e  movaps [r15+0x260], xmm1
000071409bfcf746  pextrq rax, xmm15, 0x01
000071409bfcf74d  movq xmm15, rax
000071409bfcf752  pmovzxwd xmm15, xmm15
000071409bfcf758  pslld xmm15, 0x00
000071409bfcf75e  movaps [r15+0x270], xmm15
000071409bfcf766  movq xmm9, qword ptr [r15+0x170]
000071409bfcf76f  pmovzxwd xmm9, xmm9
000071409bfcf775  pslld xmm9, 0x00
000071409bfcf77b  pextrq rax, xmm14, 0x01
000071409bfcf782  movq xmm14, rax
000071409bfcf787  pmovzxwd xmm14, xmm14
000071409bfcf78d  pslld xmm14, 0x10
000071409bfcf793  movaps [r15+0x280], xmm14
000071409bfcf79b  movq xmm8, qword ptr [r15+0x180]
000071409bfcf7a4  pmovzxwd xmm8, xmm8
000071409bfcf7aa  pslld xmm8, 0x00
000071409bfcf7b0  movq xmm7, qword ptr [r15+0x210]
000071409bfcf7b9  pmovzxwd xmm7, xmm7
000071409bfcf7be  pslld xmm7, 0x10
000071409bfcf7c3  movaps xmm6, [r15+0x150]
000071409bfcf7cb  pextrq rax, xmm6, 0x01
000071409bfcf7d2  movq xmm6, rax
000071409bfcf7d7  pmovzxwd xmm6, xmm6
000071409bfcf7dc  pslld xmm6, 0x10
000071409bfcf7e1  por xmm11, xmm10
000071409bfcf7e6  movaps [r15+0x230], xmm11
000071409bfcf7ee  pextrq rax, xmm13, 0x01
000071409bfcf7f5  movq xmm13, rax
000071409bfcf7fa  pmovzxwd xmm13, xmm13
000071409bfcf800  pslld xmm13, 0x08
000071409bfcf806  movaps [r15+0x240], xmm13
000071409bfcf80e  movq xmm10, qword ptr [r15+0x220]
000071409bfcf817  pmovzxwd xmm10, xmm10
000071409bfcf81d  pslld xmm10, 0x08
000071409bfcf823  movaps xmm5, [r15+0x160]
000071409bfcf82b  pextrq rax, xmm5, 0x01
000071409bfcf832  movq xmm5, rax
000071409bfcf837  pmovzxwd xmm5, xmm5
000071409bfcf83c  pslld xmm5, 0x08
000071409bfcf841  pslld xmm9, 0x18
000071409bfcf847  pslld xmm15, 0x18
000071409bfcf84d  pslld xmm8, 0x18
000071409bfcf853  movq xmm4, qword ptr [r15+0x250]
000071409bfcf85c  pmovzxwd xmm4, xmm4
000071409bfcf861  pslld xmm4, 0x00
000071409bfcf866  por xmm14, xmm13
000071409bfcf86b  por xmm7, xmm10
000071409bfcf870  movaps [r15+0x210], xmm7
000071409bfcf878  pslld xmm1, 0x18
000071409bfcf87d  movaps [r15+0x220], xmm1
000071409bfcf885  por xmm6, xmm5
000071409bfcf889  por xmm11, xmm9
000071409bfcf88e  movaps [r15+0x160], xmm11
000071409bfcf896  pextrq rax, xmm12, 0x01
000071409bfcf89d  movq xmm13, rax
000071409bfcf8a2  pmovzxwd xmm13, xmm13
000071409bfcf8a8  pslld xmm13, 0x00
000071409bfcf8ae  movaps [r15+0x170], xmm13
000071409bfcf8b6  movq xmm12, qword ptr [r15+0x110]
000071409bfcf8bf  pmovzxwd xmm12, xmm12
000071409bfcf8c5  pslld xmm12, 0x00
000071409bfcf8cb  por xmm14, xmm15
000071409bfcf8d0  por xmm7, xmm8
000071409bfcf8d5  movaps xmm15, [r15+0x250]
000071409bfcf8dd  pextrq rax, xmm15, 0x01
000071409bfcf8e4  movq xmm15, rax
000071409bfcf8e9  pmovzxwd xmm15, xmm15
000071409bfcf8ef  pslld xmm15, 0x00
000071409bfcf8f5  movaps [r15+0x180], xmm15
000071409bfcf8fd  por xmm6, xmm1
000071409bfcf901  movaps [r15+0x150], xmm6
000071409bfcf909  por xmm11, xmm4
000071409bfcf90e  movaps [r15+0x140], xmm11
000071409bfcf916  por xmm7, xmm12
000071409bfcf91b  movaps [r15+0x110], xmm7
000071409bfcf923  por xmm14, xmm13
000071409bfcf928  movaps [r15+0x120], xmm14
000071409bfcf930  por xmm6, xmm15
000071409bfcf935  movaps [r15+0x130], xmm6
000071409bfcf93d  mov rax, [r15+0xF8]
000071409bfcf944  lea r14, [rax+0x20]
000071409bfcf948  movups [r13+r14*1], xmm7
000071409bfcf94e  lea r14, [rax+0x30]
000071409bfcf952  movups [r13+r14*1], xmm14
000071409bfcf958  movups [r13+rax*1], xmm11
000071409bfcf95e  lea r14, [rax+0x10]
000071409bfcf962  movups [r13+r14*1], xmm6
000071409bfcf968  mov r14d, [r13+rax*1]
000071409bfcf96d  mov rax, [r15+0x48]
000071409bfcf971  mov [r15+0x68], rax
000071409bfcf975  mov qword ptr [r15+0x58], 0x04
000071409bfcf97d  lea r12, [rax+0x04]
000071409bfcf981  mov r11d, [r13+r12*1]
000071409bfcf986  mov [rsp+0x10], r11d
000071409bfcf98b  mov r11d, r11d
000071409bfcf98e  mov [r15+0x70], r11
000071409bfcf992  lea r12, [rax+0x38]
000071409bfcf996  mov r11d, [r13+r12*1]
000071409bfcf99b  lea r12, [rax+0x24]
000071409bfcf99f  mov r10d, [r13+r12*1]
000071409bfcf9a4  mov [rsp+0x20], r10d
000071409bfcf9a9  mov r10d, r10d
000071409bfcf9ac  mov [r15+0x90], r10
000071409bfcf9b3  mov [rsp+0x30], rax
000071409bfcf9b8  xor eax, eax
000071409bfcf9ba  mov r12d, 0x04
000071409bfcf9c0  mov r10d, 0xC0
000071409bfcf9c6  cmp r12, r10
000071409bfcf9c9  cmc
000071409bfcf9ca  lahf
000071409bfcf9cb  seto al
000071409bfcf9ce  mov [r15+0x108], eax
000071409bfcf9d5  mov eax, [rsp+0x10]
000071409bfcf9d9  mov r12d, [rsp+0x10]
000071409bfcf9de  shrd eax, r12d, 0x07
000071409bfcf9e3  mov [rsp+0x10], r11d
000071409bfcf9e8  mov r10d, [rsp+0x10]
000071409bfcf9ed  shrd r11d, r10d, 0x11
000071409bfcf9f2  mov r9d, [rsp+0x20]
000071409bfcf9f7  lea r8d, [r9d+r14d*1]
000071409bfcf9fc  rorx r14d, r12d, 0x12
000071409bfcfa02  xor eax, r14d
000071409bfcfa05  rorx r14d, r10d, 0x13
000071409bfcfa0b  xor r11d, r14d
000071409bfcfa0e  mov [rsp+0x10], r11d
000071409bfcfa13  mov r11d, r11d
000071409bfcfa16  mov [r15+0x88], r11
000071409bfcfa1d  mov [rsp+0x20], r12d
000071409bfcfa22  shr r12d, 0x03
000071409bfcfa26  xor eax, r12d
000071409bfcfa29  mov [rsp+0x40], eax
000071409bfcfa2d  mov eax, eax
000071409bfcfa2f  mov [r15+0x80], rax
000071409bfcfa36  shr r10d, 0x0A
000071409bfcfa3a  mov eax, [rsp+0x10]
000071409bfcfa3e  xor eax, r10d
000071409bfcfa41  mov [rsp+0x10], eax
000071409bfcfa45  mov eax, eax
000071409bfcfa47  mov [r15+0x78], rax
000071409bfcfa4b  mov eax, [rsp+0x40]
000071409bfcfa4f  lea r14d, [r8d+eax*1]
000071409bfcfa54  mov eax, [rsp+0x10]
000071409bfcfa58  lea r12d, [r14d+eax*1]
000071409bfcfa5d  mov rax, [rsp+0x30]
000071409bfcfa62  lea r14, [rax+0x40]
000071409bfcfa66  mov [r13+r14*1], r12d
000071409bfcfa6b  mov eax, [rsp+0x20]
000071409bfcfa6f  mov eax, eax
000071409bfcfa71  mov [r15+0x60], rax
000071409bfcfa75  mov eax, [r15+0x108]
000071409bfcfa7c  sahf
000071409bfcfa7d  jnz 0x000071409BFCFAAF
000071409bfcfa7f  cmp dword ptr [r15+0x318], 0x00
000071409bfcfa87  jz 0x000071409BFCFF70
000071409bfcfa8d  nop [rax+rax*1], ax
000071409bfcfa96  nop [rax+rax*1], eax
000071409bfcfa9e  mov eax, 0x410820
000071409bfcfaa3  mov [r15+0x100], rax
000071409bfcfaaa  jmp 0x000071409BDFE110
000071409bfcfaaf  cmp dword ptr [r15+0x318], 0x00
000071409bfcfab7  jz 0x000071409BFCFDC0
000071409bfcfabd  nop [rax+rax*1], ax
000071409bfcfac6  nop [rax+rax*1], eax
000071409bfcface  mov eax, 0x4107D8
000071409bfcfad3  mov [r15+0x100], rax
000071409bfcfada  jmp 0x000071409BDFE110
000071409bfcfadf  int3
000071409bfcfae0  call 0x000071409BE0D860
000071409bfcfae5  jmp 0x000071409BFCF17A
000071409bfcfaea  call 0x000071409BEE2420
000071409bfcfaef  jmp 0x000071409BFCF193
000071409bfcfaf4  call 0x000071409BEE2420
000071409bfcfaf9  jmp 0x000071409BFCF1AC
000071409bfcfafe  call 0x000071409BEE2420
000071409bfcfb03  jmp 0x000071409BFCF1C5
000071409bfcfb08  call 0x000071409BEE2420
000071409bfcfb0d  jmp 0x000071409BFCF1DE
000071409bfcfb12  call 0x000071409BEE2420
000071409bfcfb17  jmp 0x000071409BFCF1EF
000071409bfcfb1c  call 0x000071409BEE2420
000071409bfcfb21  jmp 0x000071409BFCF200
000071409bfcfb26  call 0x000071409BEE2420
000071409bfcfb2b  jmp 0x000071409BFCF211
000071409bfcfb30  call 0x000071409BEE2420
000071409bfcfb35  jmp 0x000071409BFCF222
000071409bfcfb3a  call 0x000071409BEE2420
000071409bfcfb3f  jmp 0x000071409BFCF233
000071409bfcfb44  call 0x000071409BEE2420
000071409bfcfb49  jmp 0x000071409BFCF244
000071409bfcfb4e  call 0x000071409BEE2420
000071409bfcfb53  jmp 0x000071409BFCF255
000071409bfcfb58  call 0x000071409BEE2420
000071409bfcfb5d  jmp 0x000071409BFCF266
000071409bfcfb62  call 0x000071409BEE2420
000071409bfcfb67  jmp 0x000071409BFCF277
000071409bfcfb6c  call 0x000071409BEE2420
000071409bfcfb71  jmp 0x000071409BFCF288
000071409bfcfb76  call 0x000071409BEE2420
000071409bfcfb7b  jmp 0x000071409BFCF299
000071409bfcfb80  call 0x000071409BEE2420
000071409bfcfb85  jmp 0x000071409BFCF2AA
000071409bfcfb8a  call 0x000071409BEE2420
000071409bfcfb8f  jmp 0x000071409BFCF2BB
000071409bfcfb94  call 0x000071409BEE2420
000071409bfcfb99  jmp 0x000071409BFCF2CC
000071409bfcfb9e  call 0x000071409BEE2420
000071409bfcfba3  jmp 0x000071409BFCF2DD
000071409bfcfba8  call 0x000071409BEE2420
000071409bfcfbad  jmp 0x000071409BFCF2EE
000071409bfcfbb2  call 0x000071409BEE2420
000071409bfcfbb7  jmp 0x000071409BFCF2FF
000071409bfcfbbc  call 0x000071409BEE2420
000071409bfcfbc1  jmp 0x000071409BFCF310
000071409bfcfbc6  call 0x000071409BEE2420
000071409bfcfbcb  jmp 0x000071409BFCF321
000071409bfcfbd0  call 0x000071409BEE2420
000071409bfcfbd5  jmp 0x000071409BFCF332
000071409bfcfbda  call 0x000071409BEE2420
000071409bfcfbdf  jmp 0x000071409BFCF343
000071409bfcfbe4  call 0x000071409BEE2420
000071409bfcfbe9  jmp 0x000071409BFCF354
000071409bfcfbee  call 0x000071409BEE2420
000071409bfcfbf3  jmp 0x000071409BFCF365
000071409bfcfbf8  call 0x000071409BEE2420
000071409bfcfbfd  jmp 0x000071409BFCF376
000071409bfcfc02  call 0x000071409BEE2420
000071409bfcfc07  jmp 0x000071409BFCF387
000071409bfcfc0c  call 0x000071409BEE2420
000071409bfcfc11  jmp 0x000071409BFCF398
000071409bfcfc16  call 0x000071409BEE2420
000071409bfcfc1b  jmp 0x000071409BFCF3A9
000071409bfcfc20  call 0x000071409BEE2420
000071409bfcfc25  jmp 0x000071409BFCF3BA
000071409bfcfc2a  call 0x000071409BEE2420
000071409bfcfc2f  jmp 0x000071409BFCF3CB
000071409bfcfc34  call 0x000071409BEE2420
000071409bfcfc39  jmp 0x000071409BFCF3DC
000071409bfcfc3e  call 0x000071409BEE2420
000071409bfcfc43  jmp 0x000071409BFCF3ED
000071409bfcfc48  call 0x000071409BEE2420
000071409bfcfc4d  jmp 0x000071409BFCF3FE
000071409bfcfc52  call 0x000071409BEE2420
000071409bfcfc57  jmp 0x000071409BFCF40F
000071409bfcfc5c  call 0x000071409BEE2420
000071409bfcfc61  jmp 0x000071409BFCF420
000071409bfcfc66  call 0x000071409BEE2420
000071409bfcfc6b  jmp 0x000071409BFCF431
000071409bfcfc70  call 0x000071409BEE2420
000071409bfcfc75  jmp 0x000071409BFCF442
000071409bfcfc7a  call 0x000071409BEE2420
000071409bfcfc7f  jmp 0x000071409BFCF453
000071409bfcfc84  call 0x000071409BEE2420
000071409bfcfc89  jmp 0x000071409BFCF464
000071409bfcfc8e  call 0x000071409BEE2420
000071409bfcfc93  jmp 0x000071409BFCF475
000071409bfcfc98  call 0x000071409BEE2420
000071409bfcfc9d  jmp 0x000071409BFCF486
000071409bfcfca2  call 0x000071409BEE2420
000071409bfcfca7  jmp 0x000071409BFCF497
000071409bfcfcac  call 0x000071409BEE2420
000071409bfcfcb1  jmp 0x000071409BFCF4A8
000071409bfcfcb6  call 0x000071409BEE2420
000071409bfcfcbb  jmp 0x000071409BFCF4B9
000071409bfcfcc0  call 0x000071409BEE2420
000071409bfcfcc5  jmp 0x000071409BFCF4CA
000071409bfcfcca  call 0x000071409BEE2420
000071409bfcfccf  jmp 0x000071409BFCF4DB
000071409bfcfcd4  call 0x000071409BEE2420
000071409bfcfcd9  jmp 0x000071409BFCF4EC
000071409bfcfcde  call 0x000071409BEE2420
000071409bfcfce3  jmp 0x000071409BFCF4FD
000071409bfcfce8  call 0x000071409BEE2420
000071409bfcfced  jmp 0x000071409BFCF50E
000071409bfcfcf2  call 0x000071409BEE2420
000071409bfcfcf7  jmp 0x000071409BFCF51F
000071409bfcfcfc  call 0x000071409BEE2420
000071409bfcfd01  jmp 0x000071409BFCF530
000071409bfcfd06  call 0x000071409BEE2420
000071409bfcfd0b  jmp 0x000071409BFCF541
000071409bfcfd10  call 0x000071409BEE2420
000071409bfcfd15  jmp 0x000071409BFCF552
000071409bfcfd1a  call 0x000071409BEE2420
000071409bfcfd1f  jmp 0x000071409BFCF563
000071409bfcfd24  call 0x000071409BEE2420
000071409bfcfd29  jmp 0x000071409BFCF574
000071409bfcfd2e  call 0x000071409BEE2420
000071409bfcfd33  jmp 0x000071409BFCF585
000071409bfcfd38  call 0x000071409BEE2420
000071409bfcfd3d  jmp 0x000071409BFCF596
000071409bfcfd42  call 0x000071409BEE2420
000071409bfcfd47  jmp 0x000071409BFCF5AF
000071409bfcfd4c  call 0x000071409BEE2420
000071409bfcfd51  jmp 0x000071409BFCF5C8
000071409bfcfd56  call 0x000071409BED5610
000071409bfcfd5b  jmp 0x000071409BFCF5E1
000071409bfcfd60  call 0x000071409BEDC580
000071409bfcfd65  jmp 0x000071409BFCF94E
000071409bfcfd6a  call 0x000071409BEE46C0
000071409bfcfd6f  jmp 0x000071409BFCF958
000071409bfcfd74  call 0x000071409BE09E90
000071409bfcfd79  jmp 0x000071409BFCF95E
000071409bfcfd7e  call 0x000071409BEDB310
000071409bfcfd83  jmp 0x000071409BFCF968
000071409bfcfd88  call 0x000071409BE0DAE0
000071409bfcfd8d  jmp 0x000071409BFCF96D
000071409bfcfd92  call 0x000071409BEC0230
000071409bfcfd97  jmp 0x000071409BFCF986
000071409bfcfd9c  call 0x000071409BEC0230
000071409bfcfda1  jmp 0x000071409BFCF99B
000071409bfcfda6  call 0x000071409BEBEFC0
000071409bfcfdab  jmp 0x000071409BFCF9A4
000071409bfcfdb0  call 0x000071409BEE2BA0
000071409bfcfdb5  jmp 0x000071409BFCFA6B
000071409bfcfdba  int3
000071409bfcfdbb  nop [rax+rax*1], eax
000071409bfcfdc0  mov rax, [r15+0x48]
000071409bfcfdc4  mov r14, [r15+0x58]
000071409bfcfdc8  lea r12, [rax+r14*1]
000071409bfcfdcc  mov [r15+0x68], r12
000071409bfcfdd0  lea rax, [r14+0x04]
000071409bfcfdd4  mov [r15+0x58], rax
000071409bfcfdd8  lea r14, [r12+0x04]
000071409bfcfddd  mov r11d, [r13+r14*1]
000071409bfcfde2  mov [rsp+0x10], r11d
000071409bfcfde7  mov r11d, r11d
000071409bfcfdea  mov [r15+0x70], r11
000071409bfcfdee  lea r14, [r12+0x38]
000071409bfcfdf3  mov r11d, [r13+r14*1]
000071409bfcfdf8  lea r14, [r12+0x24]
000071409bfcfdfd  mov r10d, [r13+r14*1]
000071409bfcfe02  mov [rsp+0x20], r10d
000071409bfcfe07  mov r10d, r10d
000071409bfcfe0a  mov [r15+0x90], r10
000071409bfcfe11  mov [rsp+0x30], rax
000071409bfcfe16  xor eax, eax
000071409bfcfe18  mov r14, [rsp+0x30]
000071409bfcfe1d  mov r10d, 0xC0
000071409bfcfe23  cmp r14, r10
000071409bfcfe26  cmc
000071409bfcfe27  lahf
000071409bfcfe28  seto al
000071409bfcfe2b  mov [r15+0x108], eax
000071409bfcfe32  mov eax, [rsp+0x10]
000071409bfcfe36  mov r14d, [rsp+0x10]
000071409bfcfe3b  shrd eax, r14d, 0x07
000071409bfcfe40  mov [rsp+0x10], r11d
000071409bfcfe45  mov r10d, [rsp+0x10]
000071409bfcfe4a  shrd r11d, r10d, 0x11
000071409bfcfe4f  mov r9d, [r15+0x60]
000071409bfcfe53  mov r8d, [rsp+0x20]
000071409bfcfe58  lea ebp, [r8d+r9d*1]
000071409bfcfe5d  rorx r9d, r14d, 0x12
000071409bfcfe63  xor eax, r9d
000071409bfcfe66  rorx r9d, r10d, 0x13
000071409bfcfe6c  xor r11d, r9d
000071409bfcfe6f  mov [rsp+0x10], r11d
000071409bfcfe74  mov r11d, r11d
000071409bfcfe77  mov [r15+0x88], r11
000071409bfcfe7e  mov [rsp+0x20], r14d
000071409bfcfe83  shr r14d, 0x03
000071409bfcfe87  xor eax, r14d
000071409bfcfe8a  mov [rsp+0x30], eax
000071409bfcfe8e  mov eax, eax
000071409bfcfe90  mov [r15+0x80], rax
000071409bfcfe97  shr r10d, 0x0A
000071409bfcfe9b  mov eax, [rsp+0x10]
000071409bfcfe9f  xor eax, r10d
000071409bfcfea2  mov [rsp+0x10], eax
000071409bfcfea6  mov eax, eax
000071409bfcfea8  mov [r15+0x78], rax
000071409bfcfeac  mov eax, [rsp+0x30]
000071409bfcfeb0  lea r14d, [ebp+eax*1]
000071409bfcfeb6  mov eax, [rsp+0x10]
000071409bfcfeba  lea r11d, [r14d+eax*1]
000071409bfcfebf  lea rax, [r12+0x40]
000071409bfcfec4  mov [r13+rax*1], r11d
000071409bfcfec9  mov eax, [rsp+0x20]
000071409bfcfecd  mov eax, eax
000071409bfcfecf  mov [r15+0x60], rax
000071409bfcfed3  mov eax, [r15+0x108]
000071409bfcfeda  sahf
000071409bfcfedb  jnz 0x000071409BFCFF0D
000071409bfcfedd  cmp dword ptr [r15+0x318], 0x00
000071409bfcfee5  jz 0x000071409BFCFF70
000071409bfcfeeb  nop [rax+rax*1], ax
000071409bfcfef4  nop [rax+rax*1], eax
000071409bfcfefc  mov eax, 0x410820
000071409bfcff01  mov [r15+0x100], rax
000071409bfcff08  jmp 0x000071409BDFE110
000071409bfcff0d  cmp dword ptr [r15+0x318], 0x00
000071409bfcff15  jz 0x000071409BFCFDC0
000071409bfcff1b  nop [rax+rax*1], ax
000071409bfcff24  nop [rax+rax*1], eax
000071409bfcff2c  mov eax, 0x4107D8
000071409bfcff31  mov [r15+0x100], rax
000071409bfcff38  jmp 0x000071409BDFE110
000071409bfcff3d  int3
000071409bfcff3e  call 0x000071409BEE1430
000071409bfcff43  jmp 0x000071409BFCFDE2
000071409bfcff48  call 0x000071409BEE1430
000071409bfcff4d  jmp 0x000071409BFCFDF8
000071409bfcff52  call 0x000071409BEE01C0
000071409bfcff57  jmp 0x000071409BFCFE02
000071409bfcff5c  call 0x000071409BE0A860
000071409bfcff61  jmp 0x000071409BFCFEC9
000071409bfcff66  int3
000071409bfcff67  nop [rax+rax*1], ax
000071409bfcff70  mov rax, [r15]
000071409bfcff73  mov r14d, [r13+rax*1]
000071409bfcff78  lea r12, [rax+0x04]
000071409bfcff7c  mov r11d, [r13+r12*1]
000071409bfcff81  mov [rsp+0x10], r14d
000071409bfcff86  mov r14d, r14d
000071409bfcff89  mov [r15+0x78], r14
000071409bfcff8d  mov [rsp+0x20], r11d
000071409bfcff92  mov r11d, r11d
000071409bfcff95  mov [r15+0x80], r11
000071409bfcff9c  lea r14, [rax+0x08]
000071409bfcffa0  mov r12d, [r13+r14*1]
000071409bfcffa5  lea r14, [rax+0x0C]
000071409bfcffa9  mov r11d, [r13+r14*1]
000071409bfcffae  mov [rsp+0x30], r12d
000071409bfcffb3  mov r12d, r12d
000071409bfcffb6  mov [r15+0x70], r12
000071409bfcffba  mov [rsp+0x40], r11d
000071409bfcffbf  mov r11d, r11d
000071409bfcffc2  mov [r15+0x68], r11
000071409bfcffc6  lea r14, [rax+0x18]
000071409bfcffca  mov r12d, [r13+r14*1]
000071409bfcffcf  lea r14, [rax+0x1C]
000071409bfcffd3  mov r11d, [r13+r14*1]
000071409bfcffd8  mov [rsp+0x50], r12d
000071409bfcffdd  mov r12d, r12d
000071409bfcffe0  mov [r15+0x58], r12
000071409bfcffe4  mov [rsp+0x60], r11d
000071409bfcffe9  mov r11d, r11d
000071409bfcffec  mov [r15+0x60], r11
000071409bfcfff0  lea r14, [rax+0x10]
000071409bfcfff4  mov r12d, [r13+r14*1]
000071409bfcfff9  lea r14, [rax+0x14]
000071409bfcfffd  mov eax, [r13+r14*1]
000071409bfd0002  mov [rsp+0x70], r12d
000071409bfd0007  mov r12d, r12d
000071409bfd000a  mov [r15+0x18], r12
000071409bfd000e  mov [rsp+0x80], eax
000071409bfd0015  mov eax, eax
000071409bfd0017  mov [r15+0x90], rax
000071409bfd001e  mov eax, [rsp+0x70]
000071409bfd0022  mov eax, eax
000071409bfd0024  mov [r15+0x30], rax
000071409bfd0028  mov eax, [rsp+0x50]
000071409bfd002c  mov eax, eax
000071409bfd002e  mov [r15+0xA0], rax
000071409bfd0035  mov eax, [rsp+0x30]
000071409bfd0039  mov eax, eax
000071409bfd003b  mov [r15+0x28], rax
000071409bfd003f  mov eax, [rsp+0x20]
000071409bfd0043  mov eax, eax
000071409bfd0045  mov [r15+0x98], rax
000071409bfd004c  mov eax, [rsp+0x10]
000071409bfd0050  mov eax, eax
000071409bfd0052  mov [r15+0x38], rax
000071409bfd0056  mov eax, [rsp+0x70]
000071409bfd005a  mov r14d, [rsp+0x70]
000071409bfd005f  shrd eax, r14d, 0x06
000071409bfd0064  mov [rsp+0x70], r14d
000071409bfd0069  mov r12d, [rsp+0x80]
000071409bfd0071  and r14d, r12d
000071409bfd0074  mov r11d, [rsp+0x10]
000071409bfd0079  mov r10d, [rsp+0x10]
000071409bfd007e  shrd r11d, r10d, 0x02
000071409bfd0083  mov [rsp+0x10], r12d
000071409bfd0088  mov r12d, r12d
000071409bfd008b  mov [r15+0x20], r12
000071409bfd008f  mov r12, [r15+0x50]
000071409bfd0093  mov r9d, [r13+r12*1]
000071409bfd0098  mov r12d, [rsp+0x50]
000071409bfd009d  mov r8d, [rsp+0x70]
000071409bfd00a2  andn ebp, r8d, r12d
000071409bfd00a7  mov edi, [rsp+0x60]
000071409bfd00ab  lea esi, [r14d+edi*1]
000071409bfd00b0  rorx r14d, r8d, 0x0B
000071409bfd00b6  xor eax, r14d
000071409bfd00b9  rorx r14d, r10d, 0x0D
000071409bfd00bf  xor r11d, r14d
000071409bfd00c2  lea edi, [esi+ebp*1]
000071409bfd00c6  mov r14, [r15+0x48]
000071409bfd00ca  mov ebp, [r13+r14*1]
000071409bfd00cf  mov r14d, [rsp+0x30]
000071409bfd00d4  mov esi, [rsp+0x20]
000071409bfd00d8  and r14d, esi
000071409bfd00db  mov [rsp+0x20], r14d
000071409bfd00e0  mov r14d, r14d
000071409bfd00e3  mov [r15+0xD8], r14
000071409bfd00ea  lea r14d, [edi+r9d*1]
000071409bfd00ef  mov r9d, [rsp+0x30]
000071409bfd00f4  xor r9d, esi
000071409bfd00f7  rorx edi, r8d, 0x19
000071409bfd00fd  xor eax, edi
000071409bfd00ff  and r9d, r10d
000071409bfd0102  rorx edi, r10d, 0x16
000071409bfd0108  xor r11d, edi
000071409bfd010b  mov [rsp+0x30], r11d
000071409bfd0110  mov r11d, r11d
000071409bfd0113  mov [r15+0xD0], r11
000071409bfd011a  lea r11d, [r14d+ebp*1]
000071409bfd011f  mov r10d, [rsp+0x20]
000071409bfd0124  xor r9d, r10d
000071409bfd0127  lea r14d, [r11d+eax*1]
000071409bfd012c  mov qword ptr [r15+0x88], 0x04
000071409bfd0137  mov eax, [rsp+0x30]
000071409bfd013b  lea r11d, [r9d+eax*1]
000071409bfd0140  mov eax, [rsp+0x40]
000071409bfd0144  lea r10d, [r14d+eax*1]
000071409bfd0149  mov r10d, r10d
000071409bfd014c  mov [r15+0xB8], r10
000071409bfd0153  xor eax, eax
000071409bfd0155  mov r10d, 0x04
000071409bfd015b  mov r9d, 0x100
000071409bfd0161  cmp r10, r9
000071409bfd0164  cmc
000071409bfd0165  lahf
000071409bfd0166  seto al
000071409bfd0169  mov [r15+0x108], eax
000071409bfd0170  lea eax, [r11d+r14d*1]
000071409bfd0175  mov eax, eax
000071409bfd0177  mov [r15+0xA8], rax
000071409bfd017e  mov r12d, r12d
000071409bfd0181  mov [r15+0xB0], r12
000071409bfd0188  mov eax, [rsp+0x10]
000071409bfd018c  mov eax, eax
000071409bfd018e  mov [r15+0xC0], rax
000071409bfd0195  mov r8d, r8d
000071409bfd0198  mov [r15+0xC8], r8
000071409bfd019f  mov eax, [r15+0x108]
000071409bfd01a6  sahf
000071409bfd01a7  jnz 0x000071409BFD01D9
000071409bfd01a9  cmp dword ptr [r15+0x318], 0x00
000071409bfd01b1  jz 0x000071409BFD04A0
000071409bfd01b7  nop [rax+rax*1], ax
000071409bfd01c0  nop [rax+rax*1], eax
000071409bfd01c8  mov eax, 0x4108E0
000071409bfd01cd  mov [r15+0x100], rax
000071409bfd01d4  jmp 0x000071409BDFE110
000071409bfd01d9  cmp dword ptr [r15+0x318], 0x00
000071409bfd01e1  jz 0x000071409BFD0270
000071409bfd01e7  nop [rax+rax*1], ax
000071409bfd01f0  nop [rax+rax*1], eax
000071409bfd01f8  mov eax, 0x410854
000071409bfd01fd  mov [r15+0x100], rax
000071409bfd0204  jmp 0x000071409BDFE110
000071409bfd0209  int3
000071409bfd020a  call 0x000071409BE0DAE0
000071409bfd020f  jmp 0x000071409BFCFF78
000071409bfd0214  call 0x000071409BEC0230
000071409bfd0219  jmp 0x000071409BFCFF81
000071409bfd021e  call 0x000071409BEE26A0
000071409bfd0223  jmp 0x000071409BFCFFA5
000071409bfd0228  call 0x000071409BEE1430
000071409bfd022d  jmp 0x000071409BFCFFAE
000071409bfd0232  call 0x000071409BEE26A0
000071409bfd0237  jmp 0x000071409BFCFFCF
000071409bfd023c  call 0x000071409BEE1430
000071409bfd0241  jmp 0x000071409BFCFFD8
000071409bfd0246  call 0x000071409BEE26A0
000071409bfd024b  jmp 0x000071409BFCFFF9
000071409bfd0250  call 0x000071409BED5890
000071409bfd0255  jmp 0x000071409BFD0002
000071409bfd025a  call 0x000071409BEBDD50
000071409bfd025f  jmp 0x000071409BFD0098
000071409bfd0264  call 0x000071409BEDA580
000071409bfd0269  jmp 0x000071409BFD00CF
000071409bfd026e  int3
000071409bfd026f  nop
000071409bfd0270  mov eax, [r15+0xB8]
000071409bfd0277  mov [rsp+0x10], eax
000071409bfd027b  mov eax, eax
000071409bfd027d  mov [r15+0x30], rax
000071409bfd0281  mov eax, [r15+0xC0]
000071409bfd0288  mov [rsp+0x20], eax
000071409bfd028c  mov eax, eax
000071409bfd028e  mov [r15+0xA0], rax
000071409bfd0295  mov eax, [r15+0x28]
000071409bfd0299  mov r14d, [r15+0x98]
000071409bfd02a0  mov [rsp+0x30], r14d
000071409bfd02a5  mov r14d, r14d
000071409bfd02a8  mov [r15+0x28], r14
000071409bfd02ac  mov r14d, [r15+0x38]
000071409bfd02b0  mov [rsp+0x40], r14d
000071409bfd02b5  mov r14d, r14d
000071409bfd02b8  mov [r15+0x98], r14
000071409bfd02bf  mov r14d, [r15+0xA8]
000071409bfd02c6  mov [rsp+0x50], r14d
000071409bfd02cb  mov r14d, r14d
000071409bfd02ce  mov [r15+0x38], r14
000071409bfd02d2  mov r14d, [rsp+0x10]
000071409bfd02d7  mov r12d, [rsp+0x10]
000071409bfd02dc  shrd r14d, r12d, 0x06
000071409bfd02e1  mov r11d, [r15+0xC8]
000071409bfd02e8  mov [rsp+0x10], r12d
000071409bfd02ed  and r12d, r11d
000071409bfd02f0  mov r10d, [rsp+0x50]
000071409bfd02f5  mov r9d, [rsp+0x50]
000071409bfd02fa  shrd r10d, r9d, 0x02
000071409bfd02ff  mov [rsp+0x50], r11d
000071409bfd0304  mov r11d, r11d
000071409bfd0307  mov [r15+0x20], r11
000071409bfd030b  mov r11, [r15+0x88]
000071409bfd0312  mov r8, [r15+0x50]
000071409bfd0316  lea rbp, [r8+r11*1]
000071409bfd031a  mov r8d, [r13+rbp*1]
000071409bfd031f  mov ebp, [rsp+0x20]
000071409bfd0323  mov edi, [rsp+0x10]
000071409bfd0327  andn esi, edi, ebp
000071409bfd032c  mov edx, [r15+0xB0]
000071409bfd0333  lea ecx, [r12d+edx*1]
000071409bfd0338  rorx r12d, edi, 0x0B
000071409bfd033e  xor r14d, r12d
000071409bfd0341  rorx r12d, r9d, 0x0D
000071409bfd0347  xor r10d, r12d
000071409bfd034a  lea r12d, [ecx+esi*1]
000071409bfd034f  mov rsi, [r15+0x48]
000071409bfd0353  lea rdx, [rsi+r11*1]
000071409bfd0357  mov esi, [r13+rdx*1]
000071409bfd035c  mov edx, [rsp+0x30]
000071409bfd0360  mov ecx, [rsp+0x40]
000071409bfd0364  and edx, ecx
000071409bfd0366  mov [rsp+0x10], edx
000071409bfd036a  mov edx, edx
000071409bfd036c  mov [r15+0xD8], rdx
000071409bfd0373  lea edx, [r12d+r8d*1]
000071409bfd0378  mov r12d, [rsp+0x30]
000071409bfd037d  xor r12d, ecx
000071409bfd0380  rorx r8d, edi, 0x19
000071409bfd0386  xor r14d, r8d
000071409bfd0389  and r12d, r9d
000071409bfd038c  rorx r8d, r9d, 0x16
000071409bfd0392  xor r10d, r8d
000071409bfd0395  mov [rsp+0x20], r10d
000071409bfd039a  mov r10d, r10d
000071409bfd039d  mov [r15+0xD0], r10
000071409bfd03a4  lea r10d, [edx+esi*1]
000071409bfd03a9  mov r9d, [rsp+0x10]
000071409bfd03ae  xor r12d, r9d
000071409bfd03b1  lea r9d, [r10d+r14d*1]
000071409bfd03b6  lea r14, [r11+0x04]
000071409bfd03ba  mov [r15+0x88], r14
000071409bfd03c1  mov r11d, [rsp+0x20]
000071409bfd03c6  lea r10d, [r12d+r11d*1]
000071409bfd03cb  lea r11d, [r9d+eax*1]
000071409bfd03d0  mov r11d, r11d
000071409bfd03d3  mov [r15+0xB8], r11
000071409bfd03da  xor eax, eax
000071409bfd03dc  mov r12d, 0x100
000071409bfd03e2  cmp r14, r12
000071409bfd03e5  cmc
000071409bfd03e6  lahf
000071409bfd03e7  seto al
000071409bfd03ea  mov [r15+0x108], eax
000071409bfd03f1  lea eax, [r10d+r9d*1]
000071409bfd03f6  mov eax, eax
000071409bfd03f8  mov [r15+0xA8], rax
000071409bfd03ff  mov ebp, ebp
000071409bfd0401  mov [r15+0xB0], rbp
000071409bfd0408  mov eax, [rsp+0x50]
000071409bfd040c  mov eax, eax
000071409bfd040e  mov [r15+0xC0], rax
000071409bfd0415  mov edi, edi
000071409bfd0417  mov [r15+0xC8], rdi
000071409bfd041e  mov eax, [r15+0x108]
000071409bfd0425  sahf
000071409bfd0426  jnz 0x000071409BFD0458
000071409bfd0428  cmp dword ptr [r15+0x318], 0x00
000071409bfd0430  jz 0x000071409BFD04A0
000071409bfd0436  nop [rax+rax*1], ax
000071409bfd043f  nop [rax+rax*1], eax
000071409bfd0447  mov eax, 0x4108E0
000071409bfd044c  mov [r15+0x100], rax
000071409bfd0453  jmp 0x000071409BDFE110
000071409bfd0458  cmp dword ptr [r15+0x318], 0x00
000071409bfd0460  jz 0x000071409BFD0270
000071409bfd0466  nop [rax+rax*1], ax
000071409bfd046f  nop [rax+rax*1], eax
000071409bfd0477  mov eax, 0x410854
000071409bfd047c  mov [r15+0x100], rax
000071409bfd0483  jmp 0x000071409BDFE110
000071409bfd0488  int3
000071409bfd0489  call 0x000071409BE49010
000071409bfd048e  jmp 0x000071409BFD031F
000071409bfd0493  call 0x000071409BE25930
000071409bfd0498  jmp 0x000071409BFD035C
000071409bfd049d  int3
000071409bfd049e  nop
000071409bfd04a0  mov eax, [r15+0x98]
000071409bfd04a7  mov r14d, [r15+0x70]
000071409bfd04ab  lea r12d, [eax+r14d*1]
000071409bfd04b0  mov eax, [r15+0x28]
000071409bfd04b4  mov r14d, [r15+0x68]
000071409bfd04b8  lea r11d, [eax+r14d*1]
000071409bfd04bd  mov qword ptr [r15+0x88], 0x00
000071409bfd04c8  mov eax, [r15+0xA8]
000071409bfd04cf  mov r14d, [r15+0x78]
000071409bfd04d3  lea r10d, [eax+r14d*1]
000071409bfd04d8  mov [rsp+0x10], r10d
000071409bfd04dd  mov r10d, r10d
000071409bfd04e0  mov [r15+0x78], r10
000071409bfd04e4  mov eax, [r15+0x38]
000071409bfd04e8  mov r14d, [r15+0x80]
000071409bfd04ef  lea r10d, [eax+r14d*1]
000071409bfd04f4  mov [rsp+0x20], r10d
000071409bfd04f9  mov r10d, r10d
000071409bfd04fc  mov [r15+0x80], r10
000071409bfd0503  mov rax, [r15]
000071409bfd0506  lea r14, [rax+0x08]
000071409bfd050a  mov [r13+r14*1], r12d
000071409bfd050f  lea r14, [rax+0x0C]
000071409bfd0513  mov [r13+r14*1], r11d
000071409bfd0518  mov r14d, [r15+0xB8]
000071409bfd051f  mov r12d, [r15+0x18]
000071409bfd0523  lea r11d, [r14d+r12d*1]
000071409bfd0528  mov [rsp+0x30], r11d
000071409bfd052d  mov r11d, r11d
000071409bfd0530  mov [r15+0x68], r11
000071409bfd0534  mov r14d, [r15+0x30]
000071409bfd0538  mov r12d, [r15+0x90]
000071409bfd053f  lea r11d, [r14d+r12d*1]
000071409bfd0544  mov [rsp+0x40], r11d
000071409bfd0549  mov r11d, r11d
000071409bfd054c  mov [r15+0x70], r11
000071409bfd0550  mov r14d, [r15+0x20]
000071409bfd0554  mov r12d, [r15+0x58]
000071409bfd0558  lea r11d, [r14d+r12d*1]
000071409bfd055d  mov [rsp+0x50], r11d
000071409bfd0562  mov r11d, r11d
000071409bfd0565  mov [r15+0x58], r11
000071409bfd0569  mov r14d, [r15+0xA0]
000071409bfd0570  mov r12d, [r15+0x60]
000071409bfd0574  lea r11d, [r14d+r12d*1]
000071409bfd0579  mov [rsp+0x60], r11d
000071409bfd057e  mov r11d, r11d
000071409bfd0581  mov [r15+0x60], r11
000071409bfd0585  mov r14d, [rsp+0x10]
000071409bfd058a  mov [r13+rax*1], r14d
000071409bfd058f  lea r14, [rax+0x04]
000071409bfd0593  mov r12d, [rsp+0x20]
000071409bfd0598  mov [r13+r14*1], r12d
000071409bfd059d  lea r14, [rax+0x10]
000071409bfd05a1  mov r12d, [rsp+0x30]
000071409bfd05a6  mov [r13+r14*1], r12d
000071409bfd05ab  lea r14, [rax+0x14]
000071409bfd05af  mov r12d, [rsp+0x40]
000071409bfd05b4  mov [r13+r14*1], r12d
000071409bfd05b9  lea r14, [rax+0x18]
000071409bfd05bd  mov r12d, [rsp+0x50]
000071409bfd05c2  mov [r13+r14*1], r12d
000071409bfd05c7  lea r14, [rax+0x1C]
000071409bfd05cb  mov r12d, [rsp+0x60]
000071409bfd05d0  mov [r13+r14*1], r12d
000071409bfd05d5  lea r14, [rax+0x68]
000071409bfd05d9  xor eax, eax
000071409bfd05db  mov [r13+r14*1], rax
000071409bfd05e0  cmp dword ptr [r15+0x318], 0x00
000071409bfd05e8  jz 0x000071409BFCF0E0
000071409bfd05ee  nop [rax+rax*1], ax
000071409bfd05f7  nop [rax+rax*1], eax
000071409bfd05ff  mov eax, 0x4106FC
000071409bfd0604  mov [r15+0x100], rax
000071409bfd060b  jmp 0x000071409BDFE110
000071409bfd0610  int3
000071409bfd0611  call 0x000071409BEE2BA0
000071409bfd0616  jmp 0x000071409BFD050F
000071409bfd061b  call 0x000071409BEE1920
000071409bfd0620  jmp 0x000071409BFD0518
000071409bfd0625  call 0x000071409BE0DFE0
000071409bfd062a  jmp 0x000071409BFD058F
000071409bfd062f  call 0x000071409BEE2BA0
000071409bfd0634  jmp 0x000071409BFD059D
000071409bfd0639  call 0x000071409BEE2BA0
000071409bfd063e  jmp 0x000071409BFD05AB
000071409bfd0643  call 0x000071409BEE2BA0
000071409bfd0648  jmp 0x000071409BFD05B9
000071409bfd064d  call 0x000071409BEE2BA0
000071409bfd0652  jmp 0x000071409BFD05C7
000071409bfd0657  call 0x000071409BEE2BA0
000071409bfd065c  jmp 0x000071409BFD05D5
000071409bfd0661  call 0x000071409BED5EB0
000071409bfd0666  jmp 0x000071409BFD05E0
000071409bfd066b  int3
000071409bfd066c  nop [rax], eax
000071409bfd0670  mov rax, [r15+0xF8]
000071409bfd0677  lea r14, [rax+0x140]
000071409bfd067e  mov r12, [r13+r14*1]
000071409bfd0683  lea r14, [rax+0x148]
000071409bfd068a  mov r11, [r13+r14*1]
000071409bfd068f  mov [r15+0xA0], r12
000071409bfd0696  mov [r15+0x98], r11
000071409bfd069d  lea r14, [rax+0x130]
000071409bfd06a4  mov r12, [r13+r14*1]
000071409bfd06a9  lea r14, [rax+0x138]
000071409bfd06b0  mov r11, [r13+r14*1]
000071409bfd06b5  mov [r15+0xB0], r12
000071409bfd06bc  mov [r15+0xA8], r11
000071409bfd06c3  lea r14, [rax+0x120]
000071409bfd06ca  mov r12, [r13+r14*1]
000071409bfd06cf  lea r14, [rax+0x128]
000071409bfd06d6  mov r11, [r13+r14*1]
000071409bfd06db  mov [r15+0xC0], r12
000071409bfd06e2  mov [r15+0xB8], r11
000071409bfd06e9  lea r14, [rax+0x110]
000071409bfd06f0  mov r12, [r13+r14*1]
000071409bfd06f5  lea r14, [rax+0x118]
000071409bfd06fc  mov r11, [r13+r14*1]
000071409bfd0701  mov [r15+0xD0], r12
000071409bfd0708  mov [r15+0xC8], r11
000071409bfd070f  lea r14, [rax+0x100]
000071409bfd0716  mov r12, [r13+r14*1]
000071409bfd071b  lea r14, [rax+0x108]
000071409bfd0722  mov r11, [r13+r14*1]
000071409bfd0727  mov [r15+0xE8], r12
000071409bfd072e  mov [r15+0xD8], r11
000071409bfd0735  lea r14, [rax+0x150]
000071409bfd073c  mov [r15+0xF8], r14
000071409bfd0743  mov rax, [r15+0xF0]
000071409bfd074a  mov [r15+0x100], rax
000071409bfd0751  jmp 0x000071409BFCE5C0
000071409bfd0756  int3
000071409bfd0757  call 0x000071409BEE27E0
000071409bfd075c  jmp 0x000071409BFD0683
000071409bfd0761  call 0x000071409BEE1570
000071409bfd0766  jmp 0x000071409BFD068F
000071409bfd076b  call 0x000071409BEE27E0
000071409bfd0770  jmp 0x000071409BFD06A9
000071409bfd0775  call 0x000071409BEE1570
000071409bfd077a  jmp 0x000071409BFD06B5
000071409bfd077f  call 0x000071409BEE27E0
000071409bfd0784  jmp 0x000071409BFD06CF
000071409bfd0789  call 0x000071409BEE1570
000071409bfd078e  jmp 0x000071409BFD06DB
000071409bfd0793  call 0x000071409BEE27E0
000071409bfd0798  jmp 0x000071409BFD06F5
000071409bfd079d  call 0x000071409BEE1570
000071409bfd07a2  jmp 0x000071409BFD0701
000071409bfd07a7  call 0x000071409BEE27E0
000071409bfd07ac  jmp 0x000071409BFD071B
000071409bfd07b1  call 0x000071409BEE1570
000071409bfd07b6  jmp 0x000071409BFD0727
000071409bfd07bb  int3
000071409bfd07bc  nop [rax], eax
000071409bfd07c0  mov eax, [r15+0xA0]
000071409bfd07c7  mov [rsp+0x10], eax
000071409bfd07cb  xor eax, eax
000071409bfd07cd  mov r14d, [rsp+0x10]
000071409bfd07d2  sub r14d, 0x01
000071409bfd07d6  cmc
000071409bfd07d7  lahf
000071409bfd07d8  seto al
000071409bfd07db  mov [r15+0x108], eax
000071409bfd07e2  mov r14d, r14d
000071409bfd07e5  mov [r15+0xA0], r14
000071409bfd07ec  mov eax, [r15+0x108]
000071409bfd07f3  sahf
000071409bfd07f4  jnz 0x000071409BFD0826
000071409bfd07f6  cmp dword ptr [r15+0x318], 0x00
000071409bfd07fe  jz 0x000071409BFD0900
000071409bfd0804  nop [rax+rax*1], ax
000071409bfd080d  nop [rax+rax*1], eax
000071409bfd0815  mov eax, 0x41028C
000071409bfd081a  mov [r15+0x100], rax
000071409bfd0821  jmp 0x000071409BDFE110
000071409bfd0826  cmp dword ptr [r15+0x318], 0x00
000071409bfd082e  jz 0x000071409BFD0860
000071409bfd0834  nop [rax+rax*1], ax
000071409bfd083d  nop [rax+rax*1], eax
000071409bfd0845  mov eax, 0x410274
000071409bfd084a  mov [r15+0x100], rax
000071409bfd0851  jmp 0x000071409BDFE110
000071409bfd0856  int3
000071409bfd0857  int3
000071409bfd0858  nop [rax+rax*1], eax
000071409bfd0860  mov rax, [r15+0xF8]
000071409bfd0867  lea r14, [rax+0xD0]
000071409bfd086e  mov [r15], r14
000071409bfd0871  mov rax, [r15+0x98]
000071409bfd0878  mov [r15+0x08], rax
000071409bfd087c  mov qword ptr [r15+0x10], 0x12C
000071409bfd0884  mov qword ptr [r15+0xF0], 0x410284
000071409bfd088f  mov r14d, [r15+0x320]
000071409bfd0896  mov eax, 0x410284
000071409bfd089b  mov rcx, 0x71409BFD07C0
000071409bfd08a5  mov [r15+r14*8+0x328], rax
000071409bfd08ad  mov [r15+r14*8+0x368], rcx
000071409bfd08b5  add r14d, 0x01
000071409bfd08b9  and r14d, 0x07
000071409bfd08bd  mov [r15+0x320], r14d
000071409bfd08c4  cmp dword ptr [r15+0x318], 0x00
000071409bfd08cc  jz 0x000071409BFCED70
000071409bfd08d2  nop [rax+rax*1], ax
000071409bfd08db  nop [rax+rax*1], eax
000071409bfd08e3  mov eax, 0x4106BC
000071409bfd08e8  mov [r15+0x100], rax
000071409bfd08ef  jmp 0x000071409BDFE110
000071409bfd08f4  int3
000071409bfd08f5  int3
000071409bfd08f6  nop [rax+rax*1], ax
000071409bfd08ff  nop
000071409bfd0900  mov rax, [r15+0xF8]
000071409bfd0907  lea r14, [rax+0xF0]
000071409bfd090e  mov r12, [r13+r14*1]
000071409bfd0913  mov [r15+0x98], r12
000071409bfd091a  mov qword ptr [r15+0x40], 0x80
000071409bfd0922  lea r14, [rax+0xD0]
000071409bfd0929  mov [r15], r14
000071409bfd092c  lea r14, [rax+0x14C]
000071409bfd0933  mov [r15+0x08], r14
000071409bfd0937  mov qword ptr [r15+0x10], 0x01
000071409bfd093f  lea r14, [rax+0x14C]
000071409bfd0946  mov eax, 0x80
000071409bfd094b  mov [r13+r14*1], al
000071409bfd0950  mov qword ptr [r15+0xF0], 0x4102A8
000071409bfd095b  mov r14d, [r15+0x320]
000071409bfd0962  mov eax, 0x4102A8
000071409bfd0967  mov rcx, 0x71409BFD09E0
000071409bfd0971  mov [r15+r14*8+0x328], rax
000071409bfd0979  mov [r15+r14*8+0x368], rcx
000071409bfd0981  add r14d, 0x01
000071409bfd0985  and r14d, 0x07
000071409bfd0989  mov [r15+0x320], r14d
000071409bfd0990  cmp dword ptr [r15+0x318], 0x00
000071409bfd0998  jz 0x000071409BFCED70
000071409bfd099e  nop [rax+rax*1], ax
000071409bfd09a7  nop [rax+rax*1], eax
000071409bfd09af  mov eax, 0x4106BC
000071409bfd09b4  mov [r15+0x100], rax
000071409bfd09bb  jmp 0x000071409BDFE110
000071409bfd09c0  int3
000071409bfd09c1  call 0x000071409BEE27E0
000071409bfd09c6  jmp 0x000071409BFD0913
000071409bfd09cb  call 0x000071409BED5AF0
000071409bfd09d0  jmp 0x000071409BFD0950
000071409bfd09d5  int3
000071409bfd09d6  nop [rax+rax*1], ax
000071409bfd09df  nop
000071409bfd09e0  mov rax, [r15+0xF8]
000071409bfd09e7  lea r14, [rax+0x138]
000071409bfd09ee  mov r12, [r13+r14*1]
000071409bfd09f3  mov [r15+0x40], r12
000071409bfd09f7  lea r14, [rax+0x148]
000071409bfd09fe  xor eax, eax
000071409bfd0a00  mov [r13+r14*1], al
000071409bfd0a05  xor eax, eax
000071409bfd0a07  mov r14d, 0x38
000071409bfd0a0d  cmp r12, r14
000071409bfd0a10  cmc
000071409bfd0a11  lahf
000071409bfd0a12  seto al
000071409bfd0a15  mov [r15+0x108], eax
000071409bfd0a1c  mov eax, [r15+0x108]
000071409bfd0a23  sahf
000071409bfd0a24  jz 0x000071409BFD0A56
000071409bfd0a26  cmp dword ptr [r15+0x318], 0x00
000071409bfd0a2e  jz 0x000071409BFD0AA0
000071409bfd0a34  nop [rax+rax*1], ax
000071409bfd0a3d  nop [rax+rax*1], eax
000071409bfd0a45  mov eax, 0x4102B8
000071409bfd0a4a  mov [r15+0x100], rax
000071409bfd0a51  jmp 0x000071409BDFE110
000071409bfd0a56  cmp dword ptr [r15+0x318], 0x00
000071409bfd0a5e  jz 0x000071409BFD0BF0
000071409bfd0a64  nop [rax+rax*1], ax
000071409bfd0a6d  nop [rax+rax*1], eax
000071409bfd0a75  mov eax, 0x4102D4
000071409bfd0a7a  mov [r15+0x100], rax
000071409bfd0a81  jmp 0x000071409BDFE110
000071409bfd0a86  int3
000071409bfd0a87  call 0x000071409BEE27E0
000071409bfd0a8c  jmp 0x000071409BFD09F3
000071409bfd0a91  call 0x000071409BED5AF0
000071409bfd0a96  jmp 0x000071409BFD0A05
000071409bfd0a9b  int3
000071409bfd0a9c  nop [rax], eax
000071409bfd0aa0  mov rax, [r15+0xF8]
000071409bfd0aa7  lea r14, [rax+0xD0]
000071409bfd0aae  mov [r15], r14
000071409bfd0ab1  lea r14, [rax+0x148]
000071409bfd0ab8  mov [r15+0x08], r14
000071409bfd0abc  mov qword ptr [r15+0x10], 0x01
000071409bfd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000071409bfd0acf  mov r14d, [r15+0x320]
000071409bfd0ad6  mov eax, 0x4102C8
000071409bfd0adb  mov rcx, 0x71409BFD0B40
000071409bfd0ae5  mov [r15+r14*8+0x328], rax
000071409bfd0aed  mov [r15+r14*8+0x368], rcx
000071409bfd0af5  add r14d, 0x01
000071409bfd0af9  and r14d, 0x07
000071409bfd0afd  mov [r15+0x320], r14d
000071409bfd0b04  cmp dword ptr [r15+0x318], 0x00
000071409bfd0b0c  jz 0x000071409BFCED70
000071409bfd0b12  nop [rax+rax*1], ax
000071409bfd0b1b  nop [rax+rax*1], eax
000071409bfd0b23  mov eax, 0x4106BC
000071409bfd0b28  mov [r15+0x100], rax
000071409bfd0b2f  jmp 0x000071409BDFE110
000071409bfd0b34  int3
000071409bfd0b35  int3
000071409bfd0b36  nop [rax+rax*1], ax
000071409bfd0b3f  nop
000071409bfd0b40  mov rax, [r15+0xF8]
000071409bfd0b47  lea r14, [rax+0x138]
000071409bfd0b4e  mov rax, [r13+r14*1]
000071409bfd0b53  mov [r15+0x40], rax
000071409bfd0b57  mov [rsp+0x10], rax
000071409bfd0b5c  xor eax, eax
000071409bfd0b5e  mov r14, [rsp+0x10]
000071409bfd0b63  mov r12d, 0x38
000071409bfd0b69  cmp r14, r12
000071409bfd0b6c  cmc
000071409bfd0b6d  lahf
000071409bfd0b6e  seto al
000071409bfd0b71  mov [r15+0x108], eax
000071409bfd0b78  mov eax, [r15+0x108]
000071409bfd0b7f  sahf
000071409bfd0b80  jnz 0x000071409BFD0BB2
000071409bfd0b82  cmp dword ptr [r15+0x318], 0x00
000071409bfd0b8a  jz 0x000071409BFD0BF0
000071409bfd0b90  nop [rax+rax*1], ax
000071409bfd0b99  nop [rax+rax*1], eax
000071409bfd0ba1  mov eax, 0x4102D4
000071409bfd0ba6  mov [r15+0x100], rax
000071409bfd0bad  jmp 0x000071409BDFE110
000071409bfd0bb2  cmp dword ptr [r15+0x318], 0x00
000071409bfd0bba  jz 0x000071409BFD0AA0
000071409bfd0bc0  nop [rax+rax*1], ax
000071409bfd0bc9  nop [rax+rax*1], eax
000071409bfd0bd1  mov eax, 0x4102B8
000071409bfd0bd6  mov [r15+0x100], rax
000071409bfd0bdd  jmp 0x000071409BDFE110
000071409bfd0be2  int3
000071409bfd0be3  call 0x000071409BED59C0
000071409bfd0be8  jmp 0x000071409BFD0B53
000071409bfd0bed  int3
000071409bfd0bee  nop
000071409bfd0bf0  mov rax, [r15+0x98]
000071409bfd0bf7  rorx r14, rax, 0x3D
000071409bfd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000071409bfd0c01  mov rax, [r15+0xF8]
000071409bfd0c08  lea r12, [rax+0xD0]
000071409bfd0c0f  mov [r15], r12
000071409bfd0c12  lea r12, [rax+0x140]
000071409bfd0c19  mov [r15+0x08], r12
000071409bfd0c1d  mov qword ptr [r15+0x10], 0x08
000071409bfd0c25  bswap r14
000071409bfd0c28  mov [r15+0x40], r14
000071409bfd0c2c  lea r12, [rax+0x140]
000071409bfd0c33  mov [r13+r12*1], r14
000071409bfd0c38  mov qword ptr [r15+0xF0], 0x4102F0
000071409bfd0c43  mov r14d, [r15+0x320]
000071409bfd0c4a  mov eax, 0x4102F0
000071409bfd0c4f  mov rcx, 0x71409BFD0CC0
000071409bfd0c59  mov [r15+r14*8+0x328], rax
000071409bfd0c61  mov [r15+r14*8+0x368], rcx
000071409bfd0c69  add r14d, 0x01
000071409bfd0c6d  and r14d, 0x07
000071409bfd0c71  mov [r15+0x320], r14d
000071409bfd0c78  cmp dword ptr [r15+0x318], 0x00
000071409bfd0c80  jz 0x000071409BFCED70
000071409bfd0c86  nop [rax+rax*1], ax
000071409bfd0c8f  nop [rax+rax*1], eax
000071409bfd0c97  mov eax, 0x4106BC
000071409bfd0c9c  mov [r15+0x100], rax
000071409bfd0ca3  jmp 0x000071409BDFE110
000071409bfd0ca8  int3
000071409bfd0ca9  call 0x000071409BEC3FE0
000071409bfd0cae  jmp 0x000071409BFD0C38
000071409bfd0cb3  int3
000071409bfd0cb4  nop [rax+rax*1], ax
000071409bfd0cbd  nop [rax], eax
000071409bfd0cc0  mov rax, [r15+0xF8]
000071409bfd0cc7  lea r14, [rax+0xD0]
000071409bfd0cce  mov r12d, [r13+r14*1]
000071409bfd0cd3  lea r14, [rax+0xD4]
000071409bfd0cda  mov r11d, [r13+r14*1]
000071409bfd0cdf  lea r14, [rax+0xD8]
000071409bfd0ce6  mov r10d, [r13+r14*1]
000071409bfd0ceb  lea r14, [rax+0xDC]
000071409bfd0cf2  mov r9d, [r13+r14*1]
000071409bfd0cf7  mov qword ptr [r15+0x48], 0x430C20
000071409bfd0cff  mov qword ptr [r15+0xA0], 0x00
000071409bfd0d0a  bswap r12d
000071409bfd0d0d  bswap r11d
000071409bfd0d10  mov qword ptr [r15+0x98], 0x430D8C
000071409bfd0d1b  mov r14d, 0x430C20
000071409bfd0d21  mov [r13+r14*1], r12d
000071409bfd0d26  mov r14d, 0x430C24
000071409bfd0d2c  mov [r13+r14*1], r11d
000071409bfd0d31  bswap r10d
000071409bfd0d34  bswap r9d
000071409bfd0d37  lea r14, [rax+0xE0]
000071409bfd0d3e  mov r12d, [r13+r14*1]
000071409bfd0d43  lea r14, [rax+0xE4]
000071409bfd0d4a  mov r11d, [r13+r14*1]
000071409bfd0d4f  mov r14d, 0x430C28
000071409bfd0d55  mov [r13+r14*1], r10d
000071409bfd0d5a  mov r14d, 0x430C2C
000071409bfd0d60  mov [r13+r14*1], r9d
000071409bfd0d65  bswap r12d
000071409bfd0d68  bswap r11d
000071409bfd0d6b  mov [rsp+0x10], r11d
000071409bfd0d70  mov r11d, r11d
000071409bfd0d73  mov [r15+0x58], r11
000071409bfd0d77  lea r14, [rax+0xE8]
000071409bfd0d7e  mov r11d, [r13+r14*1]
000071409bfd0d83  lea r14, [rax+0xEC]
000071409bfd0d8a  mov eax, [r13+r14*1]
000071409bfd0d8f  mov [rsp+0x20], eax
000071409bfd0d93  mov eax, eax
000071409bfd0d95  mov [r15+0x60], rax
000071409bfd0d99  mov eax, 0x430C30
000071409bfd0d9e  mov [r13+rax*1], r12d
000071409bfd0da3  mov eax, 0x430C34
000071409bfd0da8  mov r14d, [rsp+0x10]
000071409bfd0dad  mov [r13+rax*1], r14d
000071409bfd0db2  bswap r11d
000071409bfd0db5  mov [rsp+0x10], r11d
000071409bfd0dba  mov r11d, r11d
000071409bfd0dbd  mov [r15+0x40], r11
000071409bfd0dc1  mov eax, [rsp+0x20]
000071409bfd0dc5  bswap eax
000071409bfd0dc7  mov [rsp+0x20], eax
000071409bfd0dcb  mov eax, eax
000071409bfd0dcd  mov [r15+0x50], rax
000071409bfd0dd1  mov eax, 0x430C38
000071409bfd0dd6  mov r14d, [rsp+0x10]
000071409bfd0ddb  mov [r13+rax*1], r14d
000071409bfd0de0  mov eax, 0x430C3C
000071409bfd0de5  mov r14d, [rsp+0x20]
000071409bfd0dea  mov [r13+rax*1], r14d
000071409bfd0def  mov eax, [r15+0xA0]
000071409bfd0df6  lea r14d, [eax+0x11]
000071409bfd0dfb  mov r14d, r14d
000071409bfd0dfe  mov [r15], r14
000071409bfd0e01  mov qword ptr [r15+0xF0], 0x41034C
000071409bfd0e0c  mov r14d, [r15+0x320]
000071409bfd0e13  mov eax, 0x41034C
000071409bfd0e18  mov rcx, 0x71409BFD0F90
000071409bfd0e22  mov [r15+r14*8+0x328], rax
000071409bfd0e2a  mov [r15+r14*8+0x368], rcx
000071409bfd0e32  add r14d, 0x01
000071409bfd0e36  and r14d, 0x07
000071409bfd0e3a  mov [r15+0x320], r14d
000071409bfd0e41  cmp dword ptr [r15+0x318], 0x00
000071409bfd0e49  jz 0x000071409BFD0F20
000071409bfd0e4f  nop [rax+rax*1], ax
000071409bfd0e58  nop [rax+rax*1], eax
000071409bfd0e60  mov eax, 0x410938
000071409bfd0e65  mov [r15+0x100], rax
000071409bfd0e6c  jmp 0x000071409BDFE110
000071409bfd0e71  int3
000071409bfd0e72  call 0x000071409BEE26A0
000071409bfd0e77  jmp 0x000071409BFD0CD3
000071409bfd0e7c  call 0x000071409BEE1430
000071409bfd0e81  jmp 0x000071409BFD0CDF
000071409bfd0e86  call 0x000071409BEE01C0
000071409bfd0e8b  jmp 0x000071409BFD0CEB
000071409bfd0e90  call 0x000071409BEDEF50
000071409bfd0e95  jmp 0x000071409BFD0CF7
000071409bfd0e9a  call 0x000071409BEE2BA0
000071409bfd0e9f  jmp 0x000071409BFD0D26
000071409bfd0ea4  call 0x000071409BEE1920
000071409bfd0ea9  jmp 0x000071409BFD0D31
000071409bfd0eae  call 0x000071409BEE26A0
000071409bfd0eb3  jmp 0x000071409BFD0D43
000071409bfd0eb8  call 0x000071409BEE1430
000071409bfd0ebd  jmp 0x000071409BFD0D4F
000071409bfd0ec2  call 0x000071409BEE06B0
000071409bfd0ec7  jmp 0x000071409BFD0D5A
000071409bfd0ecc  call 0x000071409BEDF440
000071409bfd0ed1  jmp 0x000071409BFD0D65
000071409bfd0ed6  call 0x000071409BEE1430
000071409bfd0edb  jmp 0x000071409BFD0D83
000071409bfd0ee0  call 0x000071409BED5890
000071409bfd0ee5  jmp 0x000071409BFD0D8F
000071409bfd0eea  call 0x000071409BE0BAE0
000071409bfd0eef  jmp 0x000071409BFD0DA3
000071409bfd0ef4  call 0x000071409BE0DFE0
000071409bfd0ef9  jmp 0x000071409BFD0DB2
000071409bfd0efe  call 0x000071409BE0DFE0
000071409bfd0f03  jmp 0x000071409BFD0DE0
000071409bfd0f08  call 0x000071409BE0DFE0
000071409bfd0f0d  jmp 0x000071409BFD0DEF
000071409bfd0f12  int3
000071409bfd0f13  nop [rax+rax*1], ax
000071409bfd0f1c  nop [rax], eax
000071409bfd0f20  mov eax, [r15]
000071409bfd0f23  mov [rsp+0x10], eax
000071409bfd0f27  shr eax, 0x10
000071409bfd0f2a  mov r14d, [rsp+0x10]
000071409bfd0f2f  xor r14d, eax
000071409bfd0f32  imul r14d, r14d, 0x7FEB352D
000071409bfd0f39  mov eax, 0x846CA68B
000071409bfd0f3e  mov eax, eax
000071409bfd0f40  mov [r15+0x48], rax
000071409bfd0f44  mov [rsp+0x10], r14d
000071409bfd0f49  shr r14d, 0x0F
000071409bfd0f4d  mov eax, [rsp+0x10]
000071409bfd0f51  xor eax, r14d
000071409bfd0f54  imul eax, eax, 0x846CA68B
000071409bfd0f5a  mov [rsp+0x10], eax
000071409bfd0f5e  mov eax, eax
000071409bfd0f60  mov [r15+0x40], rax
000071409bfd0f64  mov eax, [rsp+0x10]
000071409bfd0f68  shr eax, 0x10
000071409bfd0f6b  mov r14d, [rsp+0x10]
000071409bfd0f70  xor r14d, eax
000071409bfd0f73  mov r14d, r14d
000071409bfd0f76  mov [r15], r14
000071409bfd0f79  mov rax, [r15+0xF0]
000071409bfd0f80  mov [r15+0x100], rax
000071409bfd0f87  jmp 0x000071409BFCE5C0
000071409bfd0f8c  int3
000071409bfd0f8d  int3
000071409bfd0f8e  nop
000071409bfd0f90  mov rax, [r15+0xA0]
000071409bfd0f97  mov [rsp+0x10], rax
000071409bfd0f9c  shl rax, 0x02
000071409bfd0fa0  mov r14, [r15+0x98]
000071409bfd0fa7  lea r12, [r14+rax*1]
000071409bfd0fab  mov eax, [r15]
000071409bfd0fae  mov [r13+r12*1], eax
000071409bfd0fb3  mov rax, [rsp+0x10]
000071409bfd0fb8  lea r14, [rax+0x01]
000071409bfd0fbc  mov [r15+0xA0], r14
000071409bfd0fc3  xor eax, eax
000071409bfd0fc5  mov r12d, 0x400
000071409bfd0fcb  cmp r14, r12
000071409bfd0fce  cmc
000071409bfd0fcf  lahf
000071409bfd0fd0  seto al
000071409bfd0fd3  mov [r15+0x108], eax
000071409bfd0fda  mov eax, [r15+0x108]
000071409bfd0fe1  sahf
000071409bfd0fe2  jnz 0x000071409BFD1014
000071409bfd0fe4  cmp dword ptr [r15+0x318], 0x00
000071409bfd0fec  jz 0x000071409BFD10E0
000071409bfd0ff2  nop [rax+rax*1], ax
000071409bfd0ffb  nop [rax+rax*1], eax
000071409bfd1003  mov eax, 0x41035C
000071409bfd1008  mov [r15+0x100], rax
000071409bfd100f  jmp 0x000071409BDFE110
000071409bfd1014  cmp dword ptr [r15+0x318], 0x00
000071409bfd101c  jz 0x000071409BFD1050
000071409bfd1022  nop [rax+rax*1], ax
000071409bfd102b  nop [rax+rax*1], eax
000071409bfd1033  mov eax, 0x410344
000071409bfd1038  mov [r15+0x100], rax
000071409bfd103f  jmp 0x000071409BDFE110
000071409bfd1044  int3
000071409bfd1045  call 0x000071409BEB4B70
000071409bfd104a  jmp 0x000071409BFD0FB3
000071409bfd104f  int3
000071409bfd1050  mov eax, [r15+0xA0]
000071409bfd1057  lea r14d, [eax+0x11]
000071409bfd105c  mov r14d, r14d
000071409bfd105f  mov [r15], r14
000071409bfd1062  mov qword ptr [r15+0xF0], 0x41034C
000071409bfd106d  mov r14d, [r15+0x320]
000071409bfd1074  mov eax, 0x41034C
000071409bfd1079  mov rcx, 0x71409BFD0F90
000071409bfd1083  mov [r15+r14*8+0x328], rax
000071409bfd108b  mov [r15+r14*8+0x368], rcx
000071409bfd1093  add r14d, 0x01
000071409bfd1097  and r14d, 0x07
000071409bfd109b  mov [r15+0x320], r14d
000071409bfd10a2  cmp dword ptr [r15+0x318], 0x00
000071409bfd10aa  jz 0x000071409BFD0F20
000071409bfd10b0  nop [rax+rax*1], ax
000071409bfd10b9  nop [rax+rax*1], eax
000071409bfd10c1  mov eax, 0x410938
000071409bfd10c6  mov [r15+0x100], rax
000071409bfd10cd  jmp 0x000071409BDFE110
000071409bfd10d2  int3
000071409bfd10d3  int3
000071409bfd10d4  nop [rax+rax*1], ax
000071409bfd10dd  nop [rax], eax
000071409bfd10e0  mov qword ptr [r15+0x40], 0x01
000071409bfd10e8  cmp dword ptr [r15+0x318], 0x00
000071409bfd10f0  jz 0x000071409BFD1120
000071409bfd10f6  nop [rax+rax*1], ax
000071409bfd10ff  nop [rax+rax*1], eax
000071409bfd1107  mov eax, 0x410378
000071409bfd110c  mov [r15+0x100], rax
000071409bfd1113  jmp 0x000071409BDFE110
000071409bfd1118  int3
000071409bfd1119  int3
000071409bfd111a  nop [rax+rax*1], ax
000071409bfd1120  mov rax, [r15+0x40]
000071409bfd1124  mov [rsp+0x10], rax
000071409bfd1129  shl rax, 0x02
000071409bfd112d  mov r14, [r15+0x98]
000071409bfd1134  lea r12, [r14+rax*1]
000071409bfd1138  mov eax, [r13+r12*1]
000071409bfd113d  mov [rsp+0x20], eax
000071409bfd1141  mov eax, eax
000071409bfd1143  mov [r15+0x48], rax
000071409bfd1147  mov rax, [rsp+0x10]
000071409bfd114c  mov [r15+0x50], rax
000071409bfd1150  mov eax, [r15+0x50]
000071409bfd1154  lea r12d, [eax-0x01]
000071409bfd1159  mov r12d, r12d
000071409bfd115c  mov [r15+0x58], r12
000071409bfd1160  mov rax, [r15+0x58]
000071409bfd1164  mov r12d, eax
000071409bfd1167  mov r12d, r12d
000071409bfd116a  shl r12, 0x02
000071409bfd116e  lea rax, [r14+r12*1]
000071409bfd1172  mov r14d, [r13+rax*1]
000071409bfd1177  mov [rsp+0x10], r14d
000071409bfd117c  mov r14d, r14d
000071409bfd117f  mov [r15+0x60], r14
000071409bfd1183  xor eax, eax
000071409bfd1185  mov r14d, [rsp+0x10]
000071409bfd118a  mov r12d, [rsp+0x20]
000071409bfd118f  cmp r14d, r12d
000071409bfd1192  cmc
000071409bfd1193  lahf
000071409bfd1194  seto al
000071409bfd1197  mov [r15+0x108], eax
000071409bfd119e  mov eax, [r15+0x108]
000071409bfd11a5  sahf
000071409bfd11a6  cmc
000071409bfd11a7  jbe 0x000071409BFD11D9
000071409bfd11a9  cmp dword ptr [r15+0x318], 0x00
000071409bfd11b1  jz 0x000071409BFD1220
000071409bfd11b7  nop [rax+rax*1], ax
000071409bfd11c0  nop [rax+rax*1], eax
000071409bfd11c8  mov eax, 0x410390
000071409bfd11cd  mov [r15+0x100], rax
000071409bfd11d4  jmp 0x000071409BDFE110
000071409bfd11d9  cmp dword ptr [r15+0x318], 0x00
000071409bfd11e1  jz 0x000071409BFD14C0
000071409bfd11e7  nop [rax+rax*1], ax
000071409bfd11f0  nop [rax+rax*1], eax
000071409bfd11f8  mov eax, 0x410368
000071409bfd11fd  mov [r15+0x100], rax
000071409bfd1204  jmp 0x000071409BDFE110
000071409bfd1209  int3
000071409bfd120a  call 0x000071409BEB4690
000071409bfd120f  jmp 0x000071409BFD113D
000071409bfd1214  call 0x000071409BE0DAE0
000071409bfd1219  jmp 0x000071409BFD1177
000071409bfd121e  int3
000071409bfd121f  nop
000071409bfd1220  mov rax, [r15+0x50]
000071409bfd1224  mov [rsp+0x10], rax
000071409bfd1229  shl rax, 0x02
000071409bfd122d  mov r14, [r15+0x98]
000071409bfd1234  lea r12, [r14+rax*1]
000071409bfd1238  mov eax, [r15+0x60]
000071409bfd123c  mov [r13+r12*1], eax
000071409bfd1241  mov rax, [rsp+0x10]
000071409bfd1246  lea r14, [rax-0x01]
000071409bfd124a  mov [r15+0x50], r14
000071409bfd124e  mov rax, [r15+0x58]
000071409bfd1252  test rax, rax
000071409bfd1255  setz al
000071409bfd1258  movzx rax, al
000071409bfd125c  mov [rsp+0x414], al
000071409bfd1263  cmp byte ptr [rsp+0x414], 0x00
000071409bfd126b  jz 0x000071409BFD129D
000071409bfd126d  cmp dword ptr [r15+0x318], 0x00
000071409bfd1275  jz 0x000071409BFD12E0
000071409bfd127b  nop [rax+rax*1], ax
000071409bfd1284  nop [rax+rax*1], eax
000071409bfd128c  mov eax, 0x41039C
000071409bfd1291  mov [r15+0x100], rax
000071409bfd1298  jmp 0x000071409BDFE110
000071409bfd129d  cmp dword ptr [r15+0x318], 0x00
000071409bfd12a5  jz 0x000071409BFD13E0
000071409bfd12ab  nop [rax+rax*1], ax
000071409bfd12b4  nop [rax+rax*1], eax
000071409bfd12bc  mov eax, 0x410380
000071409bfd12c1  mov [r15+0x100], rax
000071409bfd12c8  jmp 0x000071409BDFE110
000071409bfd12cd  int3
000071409bfd12ce  call 0x000071409BEB4B70
000071409bfd12d3  jmp 0x000071409BFD1241
000071409bfd12d8  int3
000071409bfd12d9  nop [rax], eax
000071409bfd12e0  cmp dword ptr [r15+0x318], 0x00
000071409bfd12e8  jz 0x000071409BFD1320
000071409bfd12ee  nop [rax+rax*1], ax
000071409bfd12f7  nop [rax+rax*1], eax
000071409bfd12ff  mov eax, 0x410364
000071409bfd1304  mov [r15+0x100], rax
000071409bfd130b  jmp 0x000071409BDFE110
000071409bfd1310  int3
000071409bfd1311  int3
000071409bfd1312  nop [rax+rax*1], ax
000071409bfd131b  nop [rax+rax*1], eax
000071409bfd1320  mov qword ptr [r15+0x50], 0x00
000071409bfd1328  mov rax, [r15+0x40]
000071409bfd132c  lea r14, [rax+0x01]
000071409bfd1330  mov [r15+0x40], r14
000071409bfd1334  mov rax, [r15+0x98]
000071409bfd133b  mov r12d, [r15+0x48]
000071409bfd133f  mov [r13+rax*1], r12d
000071409bfd1344  xor eax, eax
000071409bfd1346  mov r12d, 0x400
000071409bfd134c  cmp r14, r12
000071409bfd134f  cmc
000071409bfd1350  lahf
000071409bfd1351  seto al
000071409bfd1354  mov [r15+0x108], eax
000071409bfd135b  mov eax, [r15+0x108]
000071409bfd1362  sahf
000071409bfd1363  jz 0x000071409BFD1395
000071409bfd1365  cmp dword ptr [r15+0x318], 0x00
000071409bfd136d  jz 0x000071409BFD1120
000071409bfd1373  nop [rax+rax*1], ax
000071409bfd137c  nop [rax+rax*1], eax
000071409bfd1384  mov eax, 0x410378
000071409bfd1389  mov [r15+0x100], rax
000071409bfd1390  jmp 0x000071409BDFE110
000071409bfd1395  cmp dword ptr [r15+0x318], 0x00
000071409bfd139d  jz 0x000071409BFD1580
000071409bfd13a3  nop [rax+rax*1], ax
000071409bfd13ac  nop [rax+rax*1], eax
000071409bfd13b4  mov eax, 0x4103A0
000071409bfd13b9  mov [r15+0x100], rax
000071409bfd13c0  jmp 0x000071409BDFE110
000071409bfd13c5  int3
000071409bfd13c6  call 0x000071409BE0BAE0
000071409bfd13cb  jmp 0x000071409BFD1344
000071409bfd13d0  int3
000071409bfd13d1  nop [rax+rax*1], ax
000071409bfd13da  nop [rax+rax*1], ax
000071409bfd13e0  mov eax, [r15+0x50]
000071409bfd13e4  lea r14d, [eax-0x01]
000071409bfd13e9  mov r14d, r14d
000071409bfd13ec  mov [r15+0x58], r14
000071409bfd13f0  mov rax, [r15+0x58]
000071409bfd13f4  mov r14d, eax
000071409bfd13f7  mov r14d, r14d
000071409bfd13fa  shl r14, 0x02
000071409bfd13fe  mov rax, [r15+0x98]
000071409bfd1405  lea r12, [rax+r14*1]
000071409bfd1409  mov eax, [r13+r12*1]
000071409bfd140e  mov [rsp+0x10], eax
000071409bfd1412  mov eax, eax
000071409bfd1414  mov [r15+0x60], rax
000071409bfd1418  mov eax, [r15+0x48]
000071409bfd141c  mov [rsp+0x20], eax
000071409bfd1420  xor eax, eax
000071409bfd1422  mov r14d, [rsp+0x10]
000071409bfd1427  mov r12d, [rsp+0x20]
000071409bfd142c  cmp r14d, r12d
000071409bfd142f  cmc
000071409bfd1430  lahf
000071409bfd1431  seto al
000071409bfd1434  mov [r15+0x108], eax
000071409bfd143b  mov eax, [r15+0x108]
000071409bfd1442  sahf
000071409bfd1443  cmc
000071409bfd1444  jbe 0x000071409BFD1476
000071409bfd1446  cmp dword ptr [r15+0x318], 0x00
000071409bfd144e  jz 0x000071409BFD1220
000071409bfd1454  nop [rax+rax*1], ax
000071409bfd145d  nop [rax+rax*1], eax
000071409bfd1465  mov eax, 0x410390
000071409bfd146a  mov [r15+0x100], rax
000071409bfd1471  jmp 0x000071409BDFE110
000071409bfd1476  cmp dword ptr [r15+0x318], 0x00
000071409bfd147e  jz 0x000071409BFD14C0
000071409bfd1484  nop [rax+rax*1], ax
000071409bfd148d  nop [rax+rax*1], eax
000071409bfd1495  mov eax, 0x410368
000071409bfd149a  mov [r15+0x100], rax
000071409bfd14a1  jmp 0x000071409BDFE110
000071409bfd14a6  int3
000071409bfd14a7  call 0x000071409BEB4690
000071409bfd14ac  jmp 0x000071409BFD140E
000071409bfd14b1  int3
000071409bfd14b2  nop [rax+rax*1], ax
000071409bfd14bb  nop [rax+rax*1], eax
000071409bfd14c0  mov rax, [r15+0x40]
000071409bfd14c4  lea r14, [rax+0x01]
000071409bfd14c8  mov [r15+0x40], r14
000071409bfd14cc  mov rax, [r15+0x50]
000071409bfd14d0  mov r12d, eax
000071409bfd14d3  mov r12d, r12d
000071409bfd14d6  shl r12, 0x02
000071409bfd14da  mov rax, [r15+0x98]
000071409bfd14e1  lea r11, [rax+r12*1]
000071409bfd14e5  mov eax, [r15+0x48]
000071409bfd14e9  mov [r13+r11*1], eax
000071409bfd14ee  xor eax, eax
000071409bfd14f0  mov r12d, 0x400
000071409bfd14f6  cmp r14, r12
000071409bfd14f9  cmc
000071409bfd14fa  lahf
000071409bfd14fb  seto al
000071409bfd14fe  mov [r15+0x108], eax
000071409bfd1505  mov eax, [r15+0x108]
000071409bfd150c  sahf
000071409bfd150d  jz 0x000071409BFD153F
000071409bfd150f  cmp dword ptr [r15+0x318], 0x00
000071409bfd1517  jz 0x000071409BFD1120
000071409bfd151d  nop [rax+rax*1], ax
000071409bfd1526  nop [rax+rax*1], eax
000071409bfd152e  mov eax, 0x410378
000071409bfd1533  mov [r15+0x100], rax
000071409bfd153a  jmp 0x000071409BDFE110
000071409bfd153f  cmp dword ptr [r15+0x318], 0x00
000071409bfd1547  jz 0x000071409BFD1580
000071409bfd154d  nop [rax+rax*1], ax
000071409bfd1556  nop [rax+rax*1], eax
000071409bfd155e  mov eax, 0x4103A0
000071409bfd1563  mov [r15+0x100], rax
000071409bfd156a  jmp 0x000071409BDFE110
000071409bfd156f  int3
000071409bfd1570  call 0x000071409BEA4270
000071409bfd1575  jmp 0x000071409BFD14EE
000071409bfd157a  int3
000071409bfd157b  nop [rax+rax*1], eax
000071409bfd1580  mov qword ptr [r15+0x40], 0x430000
000071409bfd1588  mov eax, 0x430C40
000071409bfd158d  mov r14, [r13+rax*1]
000071409bfd1592  mov rax, [r15+0x98]
000071409bfd1599  mov r12d, [r13+rax*1]
000071409bfd159e  lea r11, [rax+0x04]
000071409bfd15a2  mov eax, [r13+r11*1]
000071409bfd15a7  mov r12d, r12d
000071409bfd15aa  mov [r15+0x68], r12
000071409bfd15ae  mov eax, eax
000071409bfd15b0  mov [r15+0x60], rax
000071409bfd15b4  mov rax, [r15+0x68]
000071409bfd15b8  mov [r15+0x68], rax
000071409bfd15bc  mov qword ptr [r15+0x58], 0x02
000071409bfd15c4  mov [rsp+0x10], rax
000071409bfd15c9  xor eax, eax
000071409bfd15cb  mov r12d, 0x02
000071409bfd15d1  mov r11d, 0x400
000071409bfd15d7  cmp r12, r11
000071409bfd15da  cmc
000071409bfd15db  lahf
000071409bfd15dc  seto al
000071409bfd15df  mov [r15+0x108], eax
000071409bfd15e6  mov rax, [r15+0x60]
000071409bfd15ea  mov r12d, 0x02
000071409bfd15f0  imul rax, r12
000071409bfd15f4  mov [r15+0x50], rax
000071409bfd15f8  mov rax, [rsp+0x10]
000071409bfd15fd  lea r12, [rax+r14*1]
000071409bfd1601  mov [r15+0x48], r12
000071409bfd1605  mov eax, [r15+0x108]
000071409bfd160c  sahf
000071409bfd160d  jnz 0x000071409BFD163F
000071409bfd160f  cmp dword ptr [r15+0x318], 0x00
000071409bfd1617  jz 0x000071409BFD17B0
000071409bfd161d  nop [rax+rax*1], ax
000071409bfd1626  nop [rax+rax*1], eax
000071409bfd162e  mov eax, 0x4103D0
000071409bfd1633  mov [r15+0x100], rax
000071409bfd163a  jmp 0x000071409BDFE110
000071409bfd163f  cmp dword ptr [r15+0x318], 0x00
000071409bfd1647  jz 0x000071409BFD1690
000071409bfd164d  nop [rax+rax*1], ax
000071409bfd1656  nop [rax+rax*1], eax
000071409bfd165e  mov eax, 0x4103B0
000071409bfd1663  mov [r15+0x100], rax
000071409bfd166a  jmp 0x000071409BDFE110
000071409bfd166f  int3
000071409bfd1670  call 0x000071409BE0DC20
000071409bfd1675  jmp 0x000071409BFD1592
000071409bfd167a  call 0x000071409BE0B5E0
000071409bfd167f  jmp 0x000071409BFD159E
000071409bfd1684  call 0x000071409BEA3D90
000071409bfd1689  jmp 0x000071409BFD15A7
000071409bfd168e  int3
000071409bfd168f  nop
000071409bfd1690  mov rax, [r15+0x98]
000071409bfd1697  mov r14, [r15+0x58]
000071409bfd169b  mov [rsp+0x10], r14
000071409bfd16a0  shl r14, 0x02
000071409bfd16a4  lea r12, [rax+r14*1]
000071409bfd16a8  mov eax, [r13+r12*1]
000071409bfd16ad  lea r14, [r12+0x04]
000071409bfd16b2  mov r12d, [r13+r14*1]
000071409bfd16b7  mov eax, eax
000071409bfd16b9  mov [r15+0x68], rax
000071409bfd16bd  mov r12d, r12d
000071409bfd16c0  mov [r15+0x60], r12
000071409bfd16c4  mov rax, [r15+0x68]
000071409bfd16c8  mov [rsp+0x20], rax
000071409bfd16cd  mov r14, [rsp+0x10]
000071409bfd16d2  imul rax, r14
000071409bfd16d6  mov r12, [rsp+0x20]
000071409bfd16db  lea r11, [r12+rax*1]
000071409bfd16df  mov [r15+0x68], r11
000071409bfd16e3  lea rax, [r14+0x02]
000071409bfd16e7  mov [r15+0x58], rax
000071409bfd16eb  mov [rsp+0x10], rax
000071409bfd16f0  xor eax, eax
000071409bfd16f2  mov r14, [rsp+0x10]
000071409bfd16f7  mov r12d, 0x400
000071409bfd16fd  cmp r14, r12
000071409bfd1700  cmc
000071409bfd1701  lahf
000071409bfd1702  seto al
000071409bfd1705  mov [r15+0x108], eax
000071409bfd170c  mov rax, [r15+0x50]
000071409bfd1710  mov r12, [r15+0x60]
000071409bfd1714  imul r14, r12
000071409bfd1718  lea r12, [rax+r14*1]
000071409bfd171c  mov [r15+0x50], r12
000071409bfd1720  mov rax, [r15+0x48]
000071409bfd1724  lea r14, [r11+rax*1]
000071409bfd1728  mov [r15+0x48], r14
000071409bfd172c  mov eax, [r15+0x108]
000071409bfd1733  sahf
000071409bfd1734  jnz 0x000071409BFD1766
000071409bfd1736  cmp dword ptr [r15+0x318], 0x00
000071409bfd173e  jz 0x000071409BFD17B0
000071409bfd1744  nop [rax+rax*1], ax
000071409bfd174d  nop [rax+rax*1], eax
000071409bfd1755  mov eax, 0x4103D0
000071409bfd175a  mov [r15+0x100], rax
000071409bfd1761  jmp 0x000071409BDFE110
000071409bfd1766  cmp dword ptr [r15+0x318], 0x00
000071409bfd176e  jz 0x000071409BFD1690
000071409bfd1774  nop [rax+rax*1], ax
000071409bfd177d  nop [rax+rax*1], eax
000071409bfd1785  mov eax, 0x4103B0
000071409bfd178a  mov [r15+0x100], rax
000071409bfd1791  jmp 0x000071409BDFE110
000071409bfd1796  int3
000071409bfd1797  call 0x000071409BEB4690
000071409bfd179c  jmp 0x000071409BFD16AD
000071409bfd17a1  call 0x000071409BEE26A0
000071409bfd17a6  jmp 0x000071409BFD16B7
000071409bfd17ab  int3
000071409bfd17ac  nop [rax], eax
000071409bfd17b0  mov qword ptr [r15+0x98], 0x00
000071409bfd17bb  mov rax, [r15+0x50]
000071409bfd17bf  mov r14, [r15+0x48]
000071409bfd17c3  lea r12, [rax+r14*1]
000071409bfd17c7  mov [r15+0x48], r12
000071409bfd17cb  mov rax, [r15+0x40]
000071409bfd17cf  lea r14, [rax+0xC40]
000071409bfd17d6  mov [r13+r14*1], r12
000071409bfd17db  mov qword ptr [r15], 0x01
000071409bfd17e2  mov qword ptr [r15+0xF0], 0x4103E8
000071409bfd17ed  mov r14d, [r15+0x320]
000071409bfd17f4  mov eax, 0x4103E8
000071409bfd17f9  mov rcx, 0x71409BFD1860
000071409bfd1803  mov [r15+r14*8+0x328], rax
000071409bfd180b  mov [r15+r14*8+0x368], rcx
000071409bfd1813  add r14d, 0x01
000071409bfd1817  and r14d, 0x07
000071409bfd181b  mov [r15+0x320], r14d
000071409bfd1822  cmp dword ptr [r15+0x318], 0x00
000071409bfd182a  jz 0x000071409BFD0F20
000071409bfd1830  nop [rax+rax*1], ax
000071409bfd1839  nop [rax+rax*1], eax
000071409bfd1841  mov eax, 0x410938
000071409bfd1846  mov [r15+0x100], rax
000071409bfd184d  jmp 0x000071409BDFE110
000071409bfd1852  int3
000071409bfd1853  call 0x000071409BEE2CE0
000071409bfd1858  jmp 0x000071409BFD17DB
000071409bfd185d  int3
000071409bfd185e  nop
000071409bfd1860  mov eax, [r15+0x98]
000071409bfd1867  lea r14d, [eax+0x01]
000071409bfd186c  mov [rsp+0x10], r14d
000071409bfd1871  mov r14d, r14d
000071409bfd1874  mov [r15+0x98], r14
000071409bfd187b  xor eax, eax
000071409bfd187d  mov r14d, [rsp+0x10]
000071409bfd1882  cmp r14d, 0x10000
000071409bfd1889  cmc
000071409bfd188a  lahf
000071409bfd188b  seto al
000071409bfd188e  mov [r15+0x108], eax
000071409bfd1895  mov eax, [r15+0x108]
000071409bfd189c  sahf
000071409bfd189d  jnz 0x000071409BFD18CF
000071409bfd189f  cmp dword ptr [r15+0x318], 0x00
000071409bfd18a7  jz 0x000071409BFD19A0
000071409bfd18ad  nop [rax+rax*1], ax
000071409bfd18b6  nop [rax+rax*1], eax
000071409bfd18be  mov eax, 0x4103F4
000071409bfd18c3  mov [r15+0x100], rax
000071409bfd18ca  jmp 0x000071409BDFE110
000071409bfd18cf  cmp dword ptr [r15+0x318], 0x00
000071409bfd18d7  jz 0x000071409BFD1910
000071409bfd18dd  nop [rax+rax*1], ax
000071409bfd18e6  nop [rax+rax*1], eax
000071409bfd18ee  mov eax, 0x4103E0
000071409bfd18f3  mov [r15+0x100], rax
000071409bfd18fa  jmp 0x000071409BDFE110
000071409bfd18ff  int3
000071409bfd1900  int3
000071409bfd1901  nop [rax+rax*1], ax
000071409bfd190a  nop [rax+rax*1], ax
000071409bfd1910  mov eax, [r15]
000071409bfd1913  mov r14d, [r15+0x98]
000071409bfd191a  lea r12d, [eax+r14d*1]
000071409bfd191f  mov r12d, r12d
000071409bfd1922  mov [r15], r12
000071409bfd1925  mov qword ptr [r15+0xF0], 0x4103E8
000071409bfd1930  mov r14d, [r15+0x320]
000071409bfd1937  mov eax, 0x4103E8
000071409bfd193c  mov rcx, 0x71409BFD1860
000071409bfd1946  mov [r15+r14*8+0x328], rax
000071409bfd194e  mov [r15+r14*8+0x368], rcx
000071409bfd1956  add r14d, 0x01
000071409bfd195a  and r14d, 0x07
000071409bfd195e  mov [r15+0x320], r14d
000071409bfd1965  cmp dword ptr [r15+0x318], 0x00
000071409bfd196d  jz 0x000071409BFD0F20
000071409bfd1973  nop [rax+rax*1], ax
000071409bfd197c  nop [rax+rax*1], eax
000071409bfd1984  mov eax, 0x410938
000071409bfd1989  mov [r15+0x100], rax
000071409bfd1990  jmp 0x000071409BDFE110
000071409bfd1995  int3
000071409bfd1996  int3
000071409bfd1997  nop [rax+rax*1], ax
000071409bfd19a0  vmovaps xmm1, [0x000071409BBFE010]
000071409bfd19a8  movq xmm1, xmm1
000071409bfd19ac  movaps [r15+0x110], xmm1
000071409bfd19b4  mov eax, 0x420AA0
000071409bfd19b9  mov r14, [r13+rax*1]
000071409bfd19be  movq xmm1, r14
000071409bfd19c3  movaps [r15+0x120], xmm1
000071409bfd19cb  vmovaps xmm1, [0x000071409BBFE020]
000071409bfd19d3  movq xmm1, xmm1
000071409bfd19d7  movaps [r15+0x140], xmm1
000071409bfd19df  vmovaps xmm1, [0x000071409BBFE030]
000071409bfd19e7  vpbroadcastq xmm1, xmm1
000071409bfd19ec  movaps [r15+0x150], xmm1
000071409bfd19f4  mov qword ptr [r15+0x40], 0x02
000071409bfd19fc  vmovaps xmm15, [0x000071409BBFE040]
000071409bfd1a04  movq xmm15, xmm15
000071409bfd1a09  movaps [r15+0x160], xmm15
000071409bfd1a11  vmovaps xmm15, [0x000071409BBFE050]
000071409bfd1a19  vpbroadcastq xmm15, xmm15
000071409bfd1a1e  movaps [r15+0x130], xmm15
000071409bfd1a26  mov rax, [r15+0x40]
000071409bfd1a2a  vmovq xmm14, rax
000071409bfd1a2f  vpbroadcastq xmm14, xmm14
000071409bfd1a34  movaps [r15+0x170], xmm14
000071409bfd1a3c  mov eax, 0x4209D0
000071409bfd1a41  movups xmm13, [r13+rax*1]
000071409bfd1a47  mov qword ptr [r15+0x40], 0x431D90
000071409bfd1a4f  mov eax, [r15]
000071409bfd1a52  mov r14d, 0x430C48
000071409bfd1a58  mov [r13+r14*1], eax
000071409bfd1a5d  mov qword ptr [r15+0x50], 0x431F90
000071409bfd1a65  vpmovqd xmm12, xmm13
000071409bfd1a6b  pxor xmm11, xmm11
000071409bfd1a70  punpcklqdq xmm12, xmm11
000071409bfd1a75  movaps [r15+0x210], xmm12
000071409bfd1a7d  movq xmm12, qword ptr [r15+0x140]
000071409bfd1a86  movq xmm11, qword ptr [r15+0x120]
000071409bfd1a8f  psubd xmm12, xmm11
000071409bfd1a94  movq xmm12, xmm12
000071409bfd1a99  paddq xmm13, xmm14
000071409bfd1a9e  movaps [r15+0x180], xmm13
000071409bfd1aa6  movq xmm14, qword ptr [r15+0x160]
000071409bfd1aaf  paddd xmm11, xmm14
000071409bfd1ab4  movq xmm11, xmm11
000071409bfd1ab9  movq xmm11, xmm11
000071409bfd1abe  movaps [r15+0x120], xmm11
000071409bfd1ac6  pmovzxdq xmm12, xmm12
000071409bfd1acc  psllq xmm12, 0x00
000071409bfd1ad2  movq xmm14, qword ptr [r15+0x210]
000071409bfd1adb  movq xmm13, qword ptr [r15+0x110]
000071409bfd1ae4  paddd xmm14, xmm13
000071409bfd1ae9  movq xmm14, xmm14
000071409bfd1aee  vcvtuqq2pd xmm12, xmm12
000071409bfd1af4  pmovzxdq xmm14, xmm14
000071409bfd1afa  psllq xmm14, 0x00
000071409bfd1b00  vcvtuqq2pd xmm14, xmm14
000071409bfd1b06  movaps xmm13, xmm12
000071409bfd1b0a  mulpd xmm13, xmm1
000071409bfd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000071409bfd1b15  ptest xmm11, xmm11
000071409bfd1b1b  jnz 0x000071409BFD1C0F
000071409bfd1b21  movaps [r15+0x220], xmm13
000071409bfd1b29  mov eax, 0x431F90
000071409bfd1b2e  movups [r13+rax*1], xmm13
000071409bfd1b34  movaps xmm1, xmm14
000071409bfd1b38  mulpd xmm1, xmm15
000071409bfd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000071409bfd1b42  ptest xmm13, xmm13
000071409bfd1b48  jnz 0x000071409BFD1D5C
000071409bfd1b4e  movaps [r15+0x210], xmm1
000071409bfd1b56  mov eax, 0x431D90
000071409bfd1b5b  movups [r13+rax*1], xmm1
000071409bfd1b61  mov qword ptr [r15+0x48], 0x10
000071409bfd1b69  xor eax, eax
000071409bfd1b6b  mov r14d, 0x10
000071409bfd1b71  mov r12d, 0x200
000071409bfd1b77  cmp r14, r12
000071409bfd1b7a  cmc
000071409bfd1b7b  lahf
000071409bfd1b7c  seto al
000071409bfd1b7f  mov [r15+0x108], eax
000071409bfd1b86  mov eax, [r15+0x108]
000071409bfd1b8d  sahf
000071409bfd1b8e  jnz 0x000071409BFD1BC0
000071409bfd1b90  cmp dword ptr [r15+0x318], 0x00
000071409bfd1b98  jz 0x000071409BFD2300
000071409bfd1b9e  nop [rax+rax*1], ax
000071409bfd1ba7  nop [rax+rax*1], eax
000071409bfd1baf  mov eax, 0x410480
000071409bfd1bb4  mov [r15+0x100], rax
000071409bfd1bbb  jmp 0x000071409BDFE110
000071409bfd1bc0  cmp dword ptr [r15+0x318], 0x00
000071409bfd1bc8  jz 0x000071409BFD1EB0
000071409bfd1bce  nop [rax+rax*1], ax
000071409bfd1bd7  nop [rax+rax*1], eax
000071409bfd1bdf  mov eax, 0x410440
000071409bfd1be4  mov [r15+0x100], rax
000071409bfd1beb  jmp 0x000071409BDFE110
000071409bfd1bf0  int3
000071409bfd1bf1  call 0x000071409BE0DC20
000071409bfd1bf6  jmp 0x000071409BFD19BE
000071409bfd1bfb  call 0x000071409BE0C260
000071409bfd1c00  jmp 0x000071409BFD1A47
000071409bfd1c05  call 0x000071409BED5D70
000071409bfd1c0a  jmp 0x000071409BFD1A5D
000071409bfd1c0f  sub rsp, 0x08
000071409bfd1c13  push rax
000071409bfd1c14  push rcx
000071409bfd1c15  push rdx
000071409bfd1c16  push rdi
000071409bfd1c17  push rsi
000071409bfd1c18  push r8
000071409bfd1c1a  push r9
000071409bfd1c1c  push r10
000071409bfd1c1e  push r11
000071409bfd1c20  sub rsp, 0xF0
000071409bfd1c27  vmovaps [rsp], xmm0
000071409bfd1c2c  vmovaps [rsp+0x10], xmm1
000071409bfd1c32  vmovaps [rsp+0x20], xmm2
000071409bfd1c38  vmovaps [rsp+0x30], xmm3
000071409bfd1c3e  vmovaps [rsp+0x40], xmm4
000071409bfd1c44  vmovaps [rsp+0x50], xmm5
000071409bfd1c4a  vmovaps [rsp+0x60], xmm6
000071409bfd1c50  vmovaps [rsp+0x70], xmm7
000071409bfd1c56  vmovaps [rsp+0x80], xmm8
000071409bfd1c5f  vmovaps [rsp+0x90], xmm9
000071409bfd1c68  vmovaps [rsp+0xA0], xmm10
000071409bfd1c71  vmovaps [rsp+0xB0], xmm11
000071409bfd1c7a  vmovaps [rsp+0xC0], xmm12
000071409bfd1c83  vmovaps [rsp+0xD0], xmm14
000071409bfd1c8c  vmovaps [rsp+0xE0], xmm15
000071409bfd1c95  sub rsp, 0x30
000071409bfd1c99  movaps [rsp], xmm13
000071409bfd1c9e  movaps [rsp+0x10], xmm12
000071409bfd1ca4  movaps [rsp+0x20], xmm1
000071409bfd1ca9  lea rdi, [rsp]
000071409bfd1cad  mov esi, 0x00
000071409bfd1cb2  mov rax, 0x6219BEBC2530
000071409bfd1cbc  call rax
000071409bfd1cbe  movaps xmm13, [rsp]
000071409bfd1cc3  add rsp, 0x30
000071409bfd1cc7  vmovaps xmm0, [rsp]
000071409bfd1ccc  vmovaps xmm1, [rsp+0x10]
000071409bfd1cd2  vmovaps xmm2, [rsp+0x20]
000071409bfd1cd8  vmovaps xmm3, [rsp+0x30]
000071409bfd1cde  vmovaps xmm4, [rsp+0x40]
000071409bfd1ce4  vmovaps xmm5, [rsp+0x50]
000071409bfd1cea  vmovaps xmm6, [rsp+0x60]
000071409bfd1cf0  vmovaps xmm7, [rsp+0x70]
000071409bfd1cf6  vmovaps xmm8, [rsp+0x80]
000071409bfd1cff  vmovaps xmm9, [rsp+0x90]
000071409bfd1d08  vmovaps xmm10, [rsp+0xA0]
000071409bfd1d11  vmovaps xmm11, [rsp+0xB0]
000071409bfd1d1a  vmovaps xmm12, [rsp+0xC0]
000071409bfd1d23  vmovaps xmm14, [rsp+0xD0]
000071409bfd1d2c  vmovaps xmm15, [rsp+0xE0]
000071409bfd1d35  add rsp, 0xF0
000071409bfd1d3c  pop r11
000071409bfd1d3e  pop r10
000071409bfd1d40  pop r9
000071409bfd1d42  pop r8
000071409bfd1d44  pop rsi
000071409bfd1d45  pop rdi
000071409bfd1d46  pop rdx
000071409bfd1d47  pop rcx
000071409bfd1d48  pop rax
000071409bfd1d49  add rsp, 0x08
000071409bfd1d4d  jmp 0x000071409BFD1B21
000071409bfd1d52  call 0x000071409BE0C380
000071409bfd1d57  jmp 0x000071409BFD1B34
000071409bfd1d5c  sub rsp, 0x08
000071409bfd1d60  push rax
000071409bfd1d61  push rcx
000071409bfd1d62  push rdx
000071409bfd1d63  push rdi
000071409bfd1d64  push rsi
000071409bfd1d65  push r8
000071409bfd1d67  push r9
000071409bfd1d69  push r10
000071409bfd1d6b  push r11
000071409bfd1d6d  sub rsp, 0xF0
000071409bfd1d74  vmovaps [rsp], xmm0
000071409bfd1d79  vmovaps [rsp+0x10], xmm2
000071409bfd1d7f  vmovaps [rsp+0x20], xmm3
000071409bfd1d85  vmovaps [rsp+0x30], xmm4
000071409bfd1d8b  vmovaps [rsp+0x40], xmm5
000071409bfd1d91  vmovaps [rsp+0x50], xmm6
000071409bfd1d97  vmovaps [rsp+0x60], xmm7
000071409bfd1d9d  vmovaps [rsp+0x70], xmm8
000071409bfd1da3  vmovaps [rsp+0x80], xmm9
000071409bfd1dac  vmovaps [rsp+0x90], xmm10
000071409bfd1db5  vmovaps [rsp+0xA0], xmm11
000071409bfd1dbe  vmovaps [rsp+0xB0], xmm12
000071409bfd1dc7  vmovaps [rsp+0xC0], xmm13
000071409bfd1dd0  vmovaps [rsp+0xD0], xmm14
000071409bfd1dd9  vmovaps [rsp+0xE0], xmm15
000071409bfd1de2  sub rsp, 0x30
000071409bfd1de6  movaps [rsp], xmm1
000071409bfd1dea  movaps [rsp+0x10], xmm14
000071409bfd1df0  movaps [rsp+0x20], xmm15
000071409bfd1df6  lea rdi, [rsp]
000071409bfd1dfa  mov esi, 0x00
000071409bfd1dff  mov rax, 0x6219BEBC2530
000071409bfd1e09  call rax
000071409bfd1e0b  movaps xmm1, [rsp]
000071409bfd1e0f  add rsp, 0x30
000071409bfd1e13  vmovaps xmm0, [rsp]
000071409bfd1e18  vmovaps xmm2, [rsp+0x10]
000071409bfd1e1e  vmovaps xmm3, [rsp+0x20]
000071409bfd1e24  vmovaps xmm4, [rsp+0x30]
000071409bfd1e2a  vmovaps xmm5, [rsp+0x40]
000071409bfd1e30  vmovaps xmm6, [rsp+0x50]
000071409bfd1e36  vmovaps xmm7, [rsp+0x60]
000071409bfd1e3c  vmovaps xmm8, [rsp+0x70]
000071409bfd1e42  vmovaps xmm9, [rsp+0x80]
000071409bfd1e4b  vmovaps xmm10, [rsp+0x90]
000071409bfd1e54  vmovaps xmm11, [rsp+0xA0]
000071409bfd1e5d  vmovaps xmm12, [rsp+0xB0]
000071409bfd1e66  vmovaps xmm13, [rsp+0xC0]
000071409bfd1e6f  vmovaps xmm14, [rsp+0xD0]
000071409bfd1e78  vmovaps xmm15, [rsp+0xE0]
000071409bfd1e81  add rsp, 0xF0
000071409bfd1e88  pop r11
000071409bfd1e8a  pop r10
000071409bfd1e8c  pop r9
000071409bfd1e8e  pop r8
000071409bfd1e90  pop rsi
000071409bfd1e91  pop rdi
000071409bfd1e92  pop rdx
000071409bfd1e93  pop rcx
000071409bfd1e94  pop rax
000071409bfd1e95  add rsp, 0x08
000071409bfd1e99  jmp 0x000071409BFD1B4E
000071409bfd1e9e  call 0x000071409BDFF540
000071409bfd1ea3  jmp 0x000071409BFD1B61
000071409bfd1ea8  int3
000071409bfd1ea9  nop [rax], eax
000071409bfd1eb0  movaps xmm1, [r15+0x180]
000071409bfd1eb8  vpmovqd xmm15, xmm1
000071409bfd1ebe  pxor xmm14, xmm14
000071409bfd1ec3  punpcklqdq xmm15, xmm14
000071409bfd1ec8  movaps [r15+0x210], xmm15
000071409bfd1ed0  movq xmm15, qword ptr [r15+0x140]
000071409bfd1ed9  movq xmm14, qword ptr [r15+0x120]
000071409bfd1ee2  psubd xmm15, xmm14
000071409bfd1ee7  movq xmm15, xmm15
000071409bfd1eec  movaps xmm13, [r15+0x170]
000071409bfd1ef4  paddq xmm1, xmm13
000071409bfd1ef9  movaps [r15+0x180], xmm1
000071409bfd1f01  movq xmm1, qword ptr [r15+0x160]
000071409bfd1f0a  paddd xmm14, xmm1
000071409bfd1f0f  movq xmm14, xmm14
000071409bfd1f14  movq xmm14, xmm14
000071409bfd1f19  movaps [r15+0x120], xmm14
000071409bfd1f21  pmovzxdq xmm15, xmm15
000071409bfd1f27  psllq xmm15, 0x00
000071409bfd1f2d  movq xmm1, qword ptr [r15+0x210]
000071409bfd1f36  movq xmm14, qword ptr [r15+0x110]
000071409bfd1f3f  paddd xmm1, xmm14
000071409bfd1f44  movq xmm1, xmm1
000071409bfd1f48  vcvtuqq2pd xmm15, xmm15
000071409bfd1f4e  pmovzxdq xmm1, xmm1
000071409bfd1f53  psllq xmm1, 0x00
000071409bfd1f58  vcvtuqq2pd xmm1, xmm1
000071409bfd1f5e  movaps xmm14, [r15+0x150]
000071409bfd1f66  movaps xmm13, xmm15
000071409bfd1f6a  mulpd xmm13, xmm14
000071409bfd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd1f75  ptest xmm12, xmm12
000071409bfd1f7b  jnz 0x000071409BFD205E
000071409bfd1f81  movaps [r15+0x220], xmm13
000071409bfd1f89  mov rax, [r15+0x48]
000071409bfd1f8d  mov r14, [r15+0x50]
000071409bfd1f91  lea r12, [r14+rax*1]
000071409bfd1f95  movups [r13+r12*1], xmm13
000071409bfd1f9b  movaps xmm15, [r15+0x130]
000071409bfd1fa3  movaps xmm14, xmm1
000071409bfd1fa7  mulpd xmm14, xmm15
000071409bfd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000071409bfd1fb2  ptest xmm13, xmm13
000071409bfd1fb8  jnz 0x000071409BFD21AC
000071409bfd1fbe  movaps [r15+0x210], xmm14
000071409bfd1fc6  mov r14, [r15+0x40]
000071409bfd1fca  lea r12, [r14+rax*1]
000071409bfd1fce  movups [r13+r12*1], xmm14
000071409bfd1fd4  lea r14, [rax+0x10]
000071409bfd1fd8  mov [r15+0x48], r14
000071409bfd1fdc  xor eax, eax
000071409bfd1fde  mov r12d, 0x200
000071409bfd1fe4  cmp r14, r12
000071409bfd1fe7  cmc
000071409bfd1fe8  lahf
000071409bfd1fe9  seto al
000071409bfd1fec  mov [r15+0x108], eax
000071409bfd1ff3  mov eax, [r15+0x108]
000071409bfd1ffa  sahf
000071409bfd1ffb  jnz 0x000071409BFD202D
000071409bfd1ffd  cmp dword ptr [r15+0x318], 0x00
000071409bfd2005  jz 0x000071409BFD2300
000071409bfd200b  nop [rax+rax*1], ax
000071409bfd2014  nop [rax+rax*1], eax
000071409bfd201c  mov eax, 0x410480
000071409bfd2021  mov [r15+0x100], rax
000071409bfd2028  jmp 0x000071409BDFE110
000071409bfd202d  cmp dword ptr [r15+0x318], 0x00
000071409bfd2035  jz 0x000071409BFD1EB0
000071409bfd203b  nop [rax+rax*1], ax
000071409bfd2044  nop [rax+rax*1], eax
000071409bfd204c  mov eax, 0x410440
000071409bfd2051  mov [r15+0x100], rax
000071409bfd2058  jmp 0x000071409BDFE110
000071409bfd205d  int3
000071409bfd205e  sub rsp, 0x08
000071409bfd2062  push rax
000071409bfd2063  push rcx
000071409bfd2064  push rdx
000071409bfd2065  push rdi
000071409bfd2066  push rsi
000071409bfd2067  push r8
000071409bfd2069  push r9
000071409bfd206b  push r10
000071409bfd206d  push r11
000071409bfd206f  sub rsp, 0xF0
000071409bfd2076  vmovaps [rsp], xmm0
000071409bfd207b  vmovaps [rsp+0x10], xmm1
000071409bfd2081  vmovaps [rsp+0x20], xmm2
000071409bfd2087  vmovaps [rsp+0x30], xmm3
000071409bfd208d  vmovaps [rsp+0x40], xmm4
000071409bfd2093  vmovaps [rsp+0x50], xmm5
000071409bfd2099  vmovaps [rsp+0x60], xmm6
000071409bfd209f  vmovaps [rsp+0x70], xmm7
000071409bfd20a5  vmovaps [rsp+0x80], xmm8
000071409bfd20ae  vmovaps [rsp+0x90], xmm9
000071409bfd20b7  vmovaps [rsp+0xA0], xmm10
000071409bfd20c0  vmovaps [rsp+0xB0], xmm11
000071409bfd20c9  vmovaps [rsp+0xC0], xmm12
000071409bfd20d2  vmovaps [rsp+0xD0], xmm14
000071409bfd20db  vmovaps [rsp+0xE0], xmm15
000071409bfd20e4  sub rsp, 0x30
000071409bfd20e8  movaps [rsp], xmm13
000071409bfd20ed  movaps [rsp+0x10], xmm15
000071409bfd20f3  movaps [rsp+0x20], xmm14
000071409bfd20f9  lea rdi, [rsp]
000071409bfd20fd  mov esi, 0x00
000071409bfd2102  mov rax, 0x6219BEBC2530
000071409bfd210c  call rax
000071409bfd210e  movaps xmm13, [rsp]
000071409bfd2113  add rsp, 0x30
000071409bfd2117  vmovaps xmm0, [rsp]
000071409bfd211c  vmovaps xmm1, [rsp+0x10]
000071409bfd2122  vmovaps xmm2, [rsp+0x20]
000071409bfd2128  vmovaps xmm3, [rsp+0x30]
000071409bfd212e  vmovaps xmm4, [rsp+0x40]
000071409bfd2134  vmovaps xmm5, [rsp+0x50]
000071409bfd213a  vmovaps xmm6, [rsp+0x60]
000071409bfd2140  vmovaps xmm7, [rsp+0x70]
000071409bfd2146  vmovaps xmm8, [rsp+0x80]
000071409bfd214f  vmovaps xmm9, [rsp+0x90]
000071409bfd2158  vmovaps xmm10, [rsp+0xA0]
000071409bfd2161  vmovaps xmm11, [rsp+0xB0]
000071409bfd216a  vmovaps xmm12, [rsp+0xC0]
000071409bfd2173  vmovaps xmm14, [rsp+0xD0]
000071409bfd217c  vmovaps xmm15, [rsp+0xE0]
000071409bfd2185  add rsp, 0xF0
000071409bfd218c  pop r11
000071409bfd218e  pop r10
000071409bfd2190  pop r9
000071409bfd2192  pop r8
000071409bfd2194  pop rsi
000071409bfd2195  pop rdi
000071409bfd2196  pop rdx
000071409bfd2197  pop rcx
000071409bfd2198  pop rax
000071409bfd2199  add rsp, 0x08
000071409bfd219d  jmp 0x000071409BFD1F81
000071409bfd21a2  call 0x000071409BEC2240
000071409bfd21a7  jmp 0x000071409BFD1F9B
000071409bfd21ac  sub rsp, 0x08
000071409bfd21b0  push rax
000071409bfd21b1  push rcx
000071409bfd21b2  push rdx
000071409bfd21b3  push rdi
000071409bfd21b4  push rsi
000071409bfd21b5  push r8
000071409bfd21b7  push r9
000071409bfd21b9  push r10
000071409bfd21bb  push r11
000071409bfd21bd  sub rsp, 0xF0
000071409bfd21c4  vmovaps [rsp], xmm0
000071409bfd21c9  vmovaps [rsp+0x10], xmm1
000071409bfd21cf  vmovaps [rsp+0x20], xmm2
000071409bfd21d5  vmovaps [rsp+0x30], xmm3
000071409bfd21db  vmovaps [rsp+0x40], xmm4
000071409bfd21e1  vmovaps [rsp+0x50], xmm5
000071409bfd21e7  vmovaps [rsp+0x60], xmm6
000071409bfd21ed  vmovaps [rsp+0x70], xmm7
000071409bfd21f3  vmovaps [rsp+0x80], xmm8
000071409bfd21fc  vmovaps [rsp+0x90], xmm9
000071409bfd2205  vmovaps [rsp+0xA0], xmm10
000071409bfd220e  vmovaps [rsp+0xB0], xmm11
000071409bfd2217  vmovaps [rsp+0xC0], xmm12
000071409bfd2220  vmovaps [rsp+0xD0], xmm13
000071409bfd2229  vmovaps [rsp+0xE0], xmm15
000071409bfd2232  sub rsp, 0x30
000071409bfd2236  movaps [rsp], xmm14
000071409bfd223b  movaps [rsp+0x10], xmm1
000071409bfd2240  movaps [rsp+0x20], xmm15
000071409bfd2246  lea rdi, [rsp]
000071409bfd224a  mov esi, 0x00
000071409bfd224f  mov rax, 0x6219BEBC2530
000071409bfd2259  call rax
000071409bfd225b  movaps xmm14, [rsp]
000071409bfd2260  add rsp, 0x30
000071409bfd2264  vmovaps xmm0, [rsp]
000071409bfd2269  vmovaps xmm1, [rsp+0x10]
000071409bfd226f  vmovaps xmm2, [rsp+0x20]
000071409bfd2275  vmovaps xmm3, [rsp+0x30]
000071409bfd227b  vmovaps xmm4, [rsp+0x40]
000071409bfd2281  vmovaps xmm5, [rsp+0x50]
000071409bfd2287  vmovaps xmm6, [rsp+0x60]
000071409bfd228d  vmovaps xmm7, [rsp+0x70]
000071409bfd2293  vmovaps xmm8, [rsp+0x80]
000071409bfd229c  vmovaps xmm9, [rsp+0x90]
000071409bfd22a5  vmovaps xmm10, [rsp+0xA0]
000071409bfd22ae  vmovaps xmm11, [rsp+0xB0]
000071409bfd22b7  vmovaps xmm12, [rsp+0xC0]
000071409bfd22c0  vmovaps xmm13, [rsp+0xD0]
000071409bfd22c9  vmovaps xmm15, [rsp+0xE0]
000071409bfd22d2  add rsp, 0xF0
000071409bfd22d9  pop r11
000071409bfd22db  pop r10
000071409bfd22dd  pop r9
000071409bfd22df  pop r8
000071409bfd22e1  pop rsi
000071409bfd22e2  pop rdi
000071409bfd22e3  pop rdx
000071409bfd22e4  pop rcx
000071409bfd22e5  pop rax
000071409bfd22e6  add rsp, 0x08
000071409bfd22ea  jmp 0x000071409BFD1FBE
000071409bfd22ef  call 0x000071409BEC34C0
000071409bfd22f4  jmp 0x000071409BFD1FD4
000071409bfd22f9  int3
000071409bfd22fa  nop [rax+rax*1], ax
000071409bfd2300  mov rax, [r15+0x50]
000071409bfd2304  movups xmm1, [r13+rax*1]
000071409bfd230a  lea r14, [rax+0x10]
000071409bfd230e  movups xmm15, [r13+r14*1]
000071409bfd2314  mov qword ptr [r15+0x48], 0x00
000071409bfd231c  lea r14, [rax+0x40]
000071409bfd2320  movups xmm14, [r13+r14*1]
000071409bfd2326  lea r14, [rax+0x50]
000071409bfd232a  movups xmm13, [r13+r14*1]
000071409bfd2330  lea r14, [rax+0x80]
000071409bfd2337  movups xmm12, [r13+r14*1]
000071409bfd233d  lea r14, [rax+0x90]
000071409bfd2344  movups xmm11, [r13+r14*1]
000071409bfd234a  mov r14, [r15+0xF8]
000071409bfd2351  movups [r13+r14*1], xmm1
000071409bfd2357  lea r12, [rax+0x20]
000071409bfd235b  movups xmm1, [r13+r12*1]
000071409bfd2361  lea r12, [rax+0x30]
000071409bfd2365  movups xmm10, [r13+r12*1]
000071409bfd236b  lea r12, [rax+0xC0]
000071409bfd2372  movups xmm9, [r13+r12*1]
000071409bfd2378  lea r12, [rax+0xD0]
000071409bfd237f  movups xmm8, [r13+r12*1]
000071409bfd2385  lea r12, [rax+0x100]
000071409bfd238c  movups xmm7, [r13+r12*1]
000071409bfd2392  lea r12, [rax+0x110]
000071409bfd2399  movups xmm6, [r13+r12*1]
000071409bfd239f  lea r12, [rax+0x140]
000071409bfd23a6  movups xmm5, [r13+r12*1]
000071409bfd23ac  lea r12, [rax+0x150]
000071409bfd23b3  movups xmm4, [r13+r12*1]
000071409bfd23b9  lea r12, [r14+0xB0]
000071409bfd23c0  movups [r13+r12*1], xmm10
000071409bfd23c6  lea r12, [r14+0xC0]
000071409bfd23cd  movups [r13+r12*1], xmm1
000071409bfd23d3  lea r12, [rax+0x180]
000071409bfd23da  movups xmm1, [r13+r12*1]
000071409bfd23e0  lea r12, [rax+0x190]
000071409bfd23e7  movups xmm10, [r13+r12*1]
000071409bfd23ed  lea r12, [rax+0x1C0]
000071409bfd23f4  movups xmm3, [r13+r12*1]
000071409bfd23fa  lea r12, [rax+0x1D0]
000071409bfd2401  movups xmm2, [r13+r12*1]
000071409bfd2407  lea r12, [rax+0x60]
000071409bfd240b  vmovaps [rsp+0x10], xmm1
000071409bfd2411  movups xmm1, [r13+r12*1]
000071409bfd2417  lea r12, [rax+0x70]
000071409bfd241b  vmovaps [rsp+0x20], xmm1
000071409bfd2421  movups xmm1, [r13+r12*1]
000071409bfd2427  lea r12, [r14+0x70]
000071409bfd242b  movups [r13+r12*1], xmm10
000071409bfd2431  lea r12, [r14+0x80]
000071409bfd2438  vmovaps xmm10, [rsp+0x10]
000071409bfd243e  movups [r13+r12*1], xmm10
000071409bfd2444  lea r12, [rax+0xA0]
000071409bfd244b  movups xmm10, [r13+r12*1]
000071409bfd2451  lea r12, [rax+0xB0]
000071409bfd2458  vmovaps [rsp+0x10], xmm1
000071409bfd245e  movups xmm1, [r13+r12*1]
000071409bfd2464  lea r12, [r14+0x90]
000071409bfd246b  movups [r13+r12*1], xmm2
000071409bfd2471  lea r12, [r14+0xA0]
000071409bfd2478  movups [r13+r12*1], xmm3
000071409bfd247e  lea r12, [rax+0xE0]
000071409bfd2485  movups xmm3, [r13+r12*1]
000071409bfd248b  lea r12, [rax+0xF0]
000071409bfd2492  movups xmm2, [r13+r12*1]
000071409bfd2498  lea r12, [rax+0x120]
000071409bfd249f  vmovaps [rsp+0x30], xmm1
000071409bfd24a5  movups xmm1, [r13+r12*1]
000071409bfd24ab  lea r12, [rax+0x130]
000071409bfd24b2  vmovaps [rsp+0x40], xmm1
000071409bfd24b8  movups xmm1, [r13+r12*1]
000071409bfd24be  vmovaps [rsp+0x50], xmm1
000071409bfd24c4  vmovaps xmm1, [rsp+0x40]
000071409bfd24ca  movaps [r15+0x190], xmm1
000071409bfd24d2  lea r12, [rax+0x160]
000071409bfd24d9  vmovaps [rsp+0x40], xmm1
000071409bfd24df  movups xmm1, [r13+r12*1]
000071409bfd24e5  lea r12, [rax+0x170]
000071409bfd24ec  vmovaps [rsp+0x60], xmm1
000071409bfd24f2  movups xmm1, [r13+r12*1]
000071409bfd24f8  lea r12, [rax+0x1A0]
000071409bfd24ff  vmovaps [rsp+0x70], xmm1
000071409bfd2505  movups xmm1, [r13+r12*1]
000071409bfd250b  lea r12, [rax+0x1B0]
000071409bfd2512  vmovaps [rsp+0x80], xmm1
000071409bfd251b  movups xmm1, [r13+r12*1]
000071409bfd2521  lea r12, [rax+0x1E0]
000071409bfd2528  vmovaps [rsp+0x90], xmm1
000071409bfd2531  movups xmm1, [r13+r12*1]
000071409bfd2537  lea r12, [rax+0x1F0]
000071409bfd253e  vmovaps [rsp+0xA0], xmm1
000071409bfd2547  movups xmm1, [r13+r12*1]
000071409bfd254d  mov qword ptr [r15+0x50], 0x432190
000071409bfd2555  lea rax, [r14+0x50]
000071409bfd2559  vmovaps [rsp+0xB0], xmm1
000071409bfd2562  vmovaps xmm1, [rsp+0x60]
000071409bfd2568  movups [r13+rax*1], xmm1
000071409bfd256e  lea rax, [r14+0x60]
000071409bfd2572  movups [r13+rax*1], xmm5
000071409bfd2578  lea rax, [r14+0x40]
000071409bfd257c  vmovaps xmm1, [rsp+0x70]
000071409bfd2582  movups [r13+rax*1], xmm1
000071409bfd2588  lea rax, [r14+0x20]
000071409bfd258c  vmovaps xmm1, [rsp+0xA0]
000071409bfd2595  movups [r13+rax*1], xmm1
000071409bfd259b  lea rax, [r14+0x30]
000071409bfd259f  vmovaps xmm1, [rsp+0x90]
000071409bfd25a8  movups [r13+rax*1], xmm1
000071409bfd25ae  lea rax, [r14+0x10]
000071409bfd25b2  vmovaps xmm1, [rsp+0xB0]
000071409bfd25bb  movups [r13+rax*1], xmm1
000071409bfd25c1  mov rax, [r15+0x40]
000071409bfd25c5  vxorps xmm1, xmm1, xmm1
000071409bfd25c9  vpbroadcastq xmm1, xmm1
000071409bfd25ce  vxorps xmm5, xmm5, xmm5
000071409bfd25d2  vpbroadcastq xmm5, xmm5
000071409bfd25d7  lea r12, [rax+0x30]
000071409bfd25db  mov r11, [r13+r12*1]
000071409bfd25e0  lea r12, [rax+0x38]
000071409bfd25e4  mov r10, [r13+r12*1]
000071409bfd25e9  vmovaps [rsp+0x60], xmm1
000071409bfd25ef  movq xmm1, r11
000071409bfd25f4  vmovaps [rsp+0x70], xmm1
000071409bfd25fa  movq xmm1, r10
000071409bfd25ff  vmovaps [rsp+0x90], xmm1
000071409bfd2608  vmovaps xmm1, [rsp+0x70]
000071409bfd260e  movq xmm1, xmm1
000071409bfd2612  vmovaps [rsp+0x70], xmm1
000071409bfd2618  vmovaps xmm1, [rsp+0x90]
000071409bfd2621  movq xmm1, xmm1
000071409bfd2625  vmovaps [rsp+0x90], xmm1
000071409bfd262e  movq xmm1, xmm1
000071409bfd2632  movaps [r15+0x270], xmm1
000071409bfd263a  vmovaps [rsp+0xA0], xmm7
000071409bfd2643  vmovaps xmm1, [rsp+0xA0]
000071409bfd264c  por xmm7, xmm1
000071409bfd2650  lea r12, [rax+0x20]
000071409bfd2654  mov r11, [r13+r12*1]
000071409bfd2659  lea r12, [rax+0x28]
000071409bfd265d  mov r10, [r13+r12*1]
000071409bfd2662  movq xmm1, r11
000071409bfd2667  vmovaps [rsp+0xA0], xmm1
000071409bfd2670  movq xmm1, r10
000071409bfd2675  vmovaps [rsp+0xB0], xmm1
000071409bfd267e  vmovaps xmm1, [rsp+0xA0]
000071409bfd2687  movq xmm1, xmm1
000071409bfd268b  vmovaps [rsp+0xA0], xmm1
000071409bfd2694  vmovaps xmm1, [rsp+0xB0]
000071409bfd269d  movq xmm1, xmm1
000071409bfd26a1  vmovaps [rsp+0xB0], xmm2
000071409bfd26aa  vmovaps [rsp+0xC0], xmm1
000071409bfd26b3  vmovaps xmm1, [rsp+0xB0]
000071409bfd26bc  por xmm2, xmm1
000071409bfd26c0  vmovaps [rsp+0xB0], xmm3
000071409bfd26c9  vmovaps xmm1, [rsp+0xB0]
000071409bfd26d2  por xmm3, xmm1
000071409bfd26d6  vmovaps [rsp+0xB0], xmm4
000071409bfd26df  vmovaps xmm1, [rsp+0xB0]
000071409bfd26e8  por xmm4, xmm1
000071409bfd26ec  vmovaps [rsp+0xB0], xmm9
000071409bfd26f5  vmovaps xmm1, [rsp+0xB0]
000071409bfd26fe  por xmm9, xmm1
000071409bfd2703  lea r12, [rax+0x10]
000071409bfd2707  mov r11, [r13+r12*1]
000071409bfd270c  lea r12, [rax+0x18]
000071409bfd2710  mov r10, [r13+r12*1]
000071409bfd2715  movq xmm1, r11
000071409bfd271a  vmovaps [rsp+0xB0], xmm1
000071409bfd2723  movq xmm1, r10
000071409bfd2728  vmovaps [rsp+0xD0], xmm1
000071409bfd2731  vmovaps xmm1, [rsp+0xB0]
000071409bfd273a  movq xmm1, xmm1
000071409bfd273e  vmovaps [rsp+0xB0], xmm1
000071409bfd2747  vmovaps xmm1, [rsp+0xD0]
000071409bfd2750  movq xmm1, xmm1
000071409bfd2754  vmovaps [rsp+0xD0], xmm1
000071409bfd275d  vmovaps xmm1, [rsp+0x80]
000071409bfd2766  vmovaps [rsp+0xE0], xmm15
000071409bfd276f  vmovaps xmm15, [rsp+0x80]
000071409bfd2778  por xmm1, xmm15
000071409bfd277d  vmovaps xmm15, [rsp+0x10]
000071409bfd2783  vmovaps [rsp+0x80], xmm1
000071409bfd278c  vmovaps xmm1, [rsp+0x10]
000071409bfd2792  por xmm15, xmm1
000071409bfd2797  vmovaps xmm1, [rsp+0x20]
000071409bfd279d  vmovaps [rsp+0x10], xmm15
000071409bfd27a3  vmovaps xmm15, [rsp+0x20]
000071409bfd27a9  por xmm1, xmm15
000071409bfd27ae  vmovaps [rsp+0x20], xmm6
000071409bfd27b4  vmovaps xmm15, [rsp+0x20]
000071409bfd27ba  por xmm6, xmm15
000071409bfd27bf  vmovaps [rsp+0x20], xmm11
000071409bfd27c5  vmovaps xmm15, [rsp+0x20]
000071409bfd27cb  por xmm11, xmm15
000071409bfd27d0  vmovaps [rsp+0x20], xmm13
000071409bfd27d6  vmovaps xmm15, [rsp+0x20]
000071409bfd27dc  por xmm13, xmm15
000071409bfd27e1  vmovaps [rsp+0x20], xmm14
000071409bfd27e7  vmovaps xmm15, [rsp+0x20]
000071409bfd27ed  por xmm14, xmm15
000071409bfd27f2  mov r12, [r13+rax*1]
000071409bfd27f7  vmovq xmm15, r12
000071409bfd27fc  vpbroadcastq xmm15, xmm15
000071409bfd2801  vmovaps [rsp+0x20], xmm1
000071409bfd2807  vxorps xmm1, xmm1, xmm1
000071409bfd280b  vpbroadcastq xmm1, xmm1
000071409bfd2810  vmovaps [rsp+0xF0], xmm1
000071409bfd2819  movups xmm1, [r13+r14*1]
000071409bfd281f  vmovaps [rsp+0x100], xmm1
000071409bfd2828  vxorps xmm1, xmm1, xmm1
000071409bfd282c  vpbroadcastq xmm1, xmm1
000071409bfd2831  lea r12, [rax+0x08]
000071409bfd2835  mov rax, [r13+r12*1]
000071409bfd283a  vmovaps [rsp+0x110], xmm1
000071409bfd2843  movq xmm1, rax
000071409bfd2848  movaps [r15+0x240], xmm1
000071409bfd2850  mov qword ptr [r15+0x60], 0x432190
000071409bfd2858  mov qword ptr [r15+0x58], 0x40
000071409bfd2860  vmovaps xmm1, [rsp+0x60]
000071409bfd2866  vmovaps [rsp+0x60], xmm15
000071409bfd286c  vmovaps xmm15, [rsp+0x100]
000071409bfd2875  vmovaps [rsp+0x100], xmm14
000071409bfd287e  vmovaps xmm14, [rsp+0x60]
000071409bfd2884  vmovaps [rsp+0x60], xmm13
000071409bfd288a  vmovaps [rsp+0x120], xmm12
000071409bfd2893  movaps xmm13, xmm1
000071409bfd2897  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd289c  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd28a2  vptest xmm12, xmm12
000071409bfd28a7  jnz 0x000071409BFD3482
000071409bfd28ad  vmovaps xmm1, [rsp+0xE0]
000071409bfd28b6  movaps xmm15, xmm5
000071409bfd28ba  vfmadd231pd xmm15, xmm1, xmm14
000071409bfd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
000071409bfd28c5  vptest xmm12, xmm12
000071409bfd28ca  jnz 0x000071409BFD35DB
000071409bfd28d0  vmovaps xmm12, [rsp+0x50]
000071409bfd28d6  vmovaps xmm5, [rsp+0x50]
000071409bfd28dc  por xmm12, xmm5
000071409bfd28e1  vmovaps xmm5, [rsp+0x30]
000071409bfd28e7  vmovaps [rsp+0x50], xmm1
000071409bfd28ed  vmovaps xmm1, [rsp+0x30]
000071409bfd28f3  por xmm5, xmm1
000071409bfd28f7  vmovaps [rsp+0x30], xmm10
000071409bfd28fd  vmovaps xmm1, [rsp+0x30]
000071409bfd2903  por xmm10, xmm1
000071409bfd2908  vmovaps [rsp+0x30], xmm8
000071409bfd290e  vmovaps xmm1, [rsp+0x30]
000071409bfd2914  por xmm8, xmm1
000071409bfd2919  vmovaps xmm1, [rsp+0x120]
000071409bfd2922  vmovaps [rsp+0x30], xmm15
000071409bfd2928  vmovaps xmm15, [rsp+0x120]
000071409bfd2931  por xmm1, xmm15
000071409bfd2936  vmovaps xmm15, [rsp+0x50]
000071409bfd293c  vmovaps [rsp+0xE0], xmm1
000071409bfd2945  vmovaps xmm1, [rsp+0x50]
000071409bfd294b  por xmm15, xmm1
000071409bfd2950  lea rax, [r14+0xC0]
000071409bfd2957  movups xmm1, [r13+rax*1]
000071409bfd295d  xor eax, eax
000071409bfd295f  mov r12d, 0x40
000071409bfd2965  mov r11d, 0x200
000071409bfd296b  cmp r12, r11
000071409bfd296e  cmc
000071409bfd296f  lahf
000071409bfd2970  seto al
000071409bfd2973  mov [r15+0x108], eax
000071409bfd297a  vmovaps [rsp+0x50], xmm1
000071409bfd2980  vmovaps xmm1, [rsp+0xF0]
000071409bfd2989  vmovaps [rsp+0xF0], xmm15
000071409bfd2992  vmovaps xmm15, [rsp+0x50]
000071409bfd2998  vmovaps [rsp+0x50], xmm13
000071409bfd299e  vmovaps [rsp+0x120], xmm12
000071409bfd29a7  movaps xmm13, xmm1
000071409bfd29ab  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd29b6  vptest xmm12, xmm12
000071409bfd29bb  jnz 0x000071409BFD373D
000071409bfd29c1  lea rax, [r14+0xB0]
000071409bfd29c8  movups xmm1, [r13+rax*1]
000071409bfd29ce  vmovaps xmm15, [rsp+0x110]
000071409bfd29d7  vmovaps [rsp+0x110], xmm13
000071409bfd29e0  movaps xmm12, xmm15
000071409bfd29e4  vfmadd231pd xmm12, xmm1, xmm14
000071409bfd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
000071409bfd29ef  vptest xmm13, xmm13
000071409bfd29f4  jnz 0x000071409BFD38A0
000071409bfd29fa  vmovaps xmm1, [rsp+0x100]
000071409bfd2a03  vmovaps xmm15, [rsp+0x100]
000071409bfd2a0c  por xmm1, xmm15
000071409bfd2a11  movaps [r15+0x210], xmm1
000071409bfd2a19  vmovaps xmm15, [rsp+0x60]
000071409bfd2a1f  vmovaps xmm14, [rsp+0x60]
000071409bfd2a25  por xmm15, xmm14
000071409bfd2a2a  movaps [r15+0x1C0], xmm15
000071409bfd2a32  vmovaps [rsp+0x60], xmm11
000071409bfd2a38  vmovaps xmm14, [rsp+0x60]
000071409bfd2a3e  por xmm11, xmm14
000071409bfd2a43  movaps [r15+0x280], xmm11
000071409bfd2a4b  vmovaps [rsp+0x60], xmm6
000071409bfd2a51  vmovaps xmm14, [rsp+0x60]
000071409bfd2a57  por xmm6, xmm14
000071409bfd2a5c  movaps [r15+0x2A0], xmm6
000071409bfd2a64  vmovaps xmm14, [rsp+0x20]
000071409bfd2a6a  vmovaps xmm13, [rsp+0x20]
000071409bfd2a70  por xmm14, xmm13
000071409bfd2a75  movaps [r15+0x2E0], xmm14
000071409bfd2a7d  vmovaps xmm13, [rsp+0x10]
000071409bfd2a83  vmovaps [rsp+0x20], xmm1
000071409bfd2a89  vmovaps xmm1, [rsp+0x10]
000071409bfd2a8f  por xmm13, xmm1
000071409bfd2a94  movaps [r15+0x1F0], xmm13
000071409bfd2a9c  vmovaps xmm1, [rsp+0xF0]
000071409bfd2aa5  vmovaps [rsp+0x10], xmm15
000071409bfd2aab  vmovaps xmm15, [rsp+0xF0]
000071409bfd2ab4  por xmm1, xmm15
000071409bfd2ab9  movaps [r15+0x250], xmm1
000071409bfd2ac1  vmovaps xmm1, [rsp+0xE0]
000071409bfd2aca  vmovaps xmm15, [rsp+0xE0]
000071409bfd2ad3  por xmm1, xmm15
000071409bfd2ad8  movaps [r15+0x260], xmm1
000071409bfd2ae0  vmovaps [rsp+0x60], xmm8
000071409bfd2ae6  vmovaps xmm15, [rsp+0x60]
000071409bfd2aec  por xmm8, xmm15
000071409bfd2af1  movaps [r15+0x290], xmm8
000071409bfd2af9  vmovaps [rsp+0x60], xmm10
000071409bfd2aff  vmovaps xmm15, [rsp+0x60]
000071409bfd2b05  por xmm10, xmm15
000071409bfd2b0a  movaps [r15+0x2C0], xmm10
000071409bfd2b12  movq xmm15, qword ptr [r15+0x240]
000071409bfd2b1b  vmovaps [rsp+0x60], xmm15
000071409bfd2b21  vpermilpd xmm15, xmm15, 0x00
000071409bfd2b27  vmovaps [rsp+0xE0], xmm1
000071409bfd2b30  vmovaps xmm1, [rsp+0x50]
000071409bfd2b36  vmovaps [rsp+0x50], xmm15
000071409bfd2b3c  vmovaps xmm15, [rsp+0x20]
000071409bfd2b42  vmovaps [rsp+0x20], xmm14
000071409bfd2b48  vmovaps xmm14, [rsp+0x50]
000071409bfd2b4e  vmovaps [rsp+0x50], xmm13
000071409bfd2b54  vmovaps [rsp+0xF0], xmm12
000071409bfd2b5d  movaps xmm13, xmm1
000071409bfd2b61  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd2b6c  vptest xmm12, xmm12
000071409bfd2b71  jnz 0x000071409BFD39F9
000071409bfd2b77  vmovaps xmm1, [rsp+0x60]
000071409bfd2b7d  vpermilpd xmm1, xmm1, 0x00
000071409bfd2b83  vmovaps xmm15, [rsp+0x110]
000071409bfd2b8c  vmovaps xmm14, [rsp+0x20]
000071409bfd2b92  vmovaps [rsp+0x20], xmm13
000071409bfd2b98  movaps xmm12, xmm15
000071409bfd2b9c  vfmadd231pd xmm12, xmm14, xmm1
000071409bfd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
000071409bfd2ba7  vptest xmm13, xmm13
000071409bfd2bac  jnz 0x000071409BFD3B52
000071409bfd2bb2  vmovaps xmm1, [rsp+0x60]
000071409bfd2bb8  vpermilpd xmm1, xmm1, 0x00
000071409bfd2bbe  vmovaps xmm15, [rsp+0x30]
000071409bfd2bc4  vmovaps xmm14, [rsp+0x10]
000071409bfd2bca  vmovaps [rsp+0x10], xmm12
000071409bfd2bd0  movaps xmm13, xmm15
000071409bfd2bd4  vfmadd231pd xmm13, xmm14, xmm1
000071409bfd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd2bdf  vptest xmm12, xmm12
000071409bfd2be4  jnz 0x000071409BFD3CAB
000071409bfd2bea  vmovaps [rsp+0x30], xmm5
000071409bfd2bf0  vmovaps xmm1, [rsp+0x30]
000071409bfd2bf6  por xmm5, xmm1
000071409bfd2bfa  movaps [r15+0x1D0], xmm5
000071409bfd2c02  vmovaps xmm1, [rsp+0x60]
000071409bfd2c08  vpermilpd xmm1, xmm1, 0x00
000071409bfd2c0e  vmovaps xmm15, [rsp+0xF0]
000071409bfd2c17  vmovaps xmm14, [rsp+0x50]
000071409bfd2c1d  vmovaps [rsp+0x30], xmm13
000071409bfd2c23  movaps xmm12, xmm15
000071409bfd2c27  vfmadd231pd xmm12, xmm14, xmm1
000071409bfd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
000071409bfd2c32  vptest xmm13, xmm13
000071409bfd2c37  jnz 0x000071409BFD3E04
000071409bfd2c3d  vmovaps xmm1, [rsp+0x80]
000071409bfd2c46  vmovaps xmm15, [rsp+0x80]
000071409bfd2c4f  por xmm1, xmm15
000071409bfd2c54  movaps [r15+0x200], xmm1
000071409bfd2c5c  vmovaps xmm15, [rsp+0x120]
000071409bfd2c65  vmovaps xmm14, [rsp+0x120]
000071409bfd2c6e  por xmm15, xmm14
000071409bfd2c73  movaps [r15+0x1E0], xmm15
000071409bfd2c7b  vmovaps [rsp+0x50], xmm4
000071409bfd2c81  vmovaps xmm13, [rsp+0x50]
000071409bfd2c87  por xmm4, xmm13
000071409bfd2c8c  movaps [r15+0x2B0], xmm4
000071409bfd2c94  vmovaps [rsp+0x50], xmm3
000071409bfd2c9a  vmovaps xmm13, [rsp+0x50]
000071409bfd2ca0  por xmm3, xmm13
000071409bfd2ca5  movaps [r15+0x300], xmm3
000071409bfd2cad  vmovaps xmm15, [rsp+0xB0]
000071409bfd2cb6  vpermilpd xmm15, xmm15, 0x00
000071409bfd2cbc  vmovaps xmm3, [rsp+0x20]
000071409bfd2cc2  vmovaps [rsp+0x20], xmm1
000071409bfd2cc8  vmovaps xmm1, [rsp+0xE0]
000071409bfd2cd1  vmovaps [rsp+0x50], xmm14
000071409bfd2cd7  vmovaps [rsp+0x60], xmm13
000071409bfd2cdd  movaps xmm14, xmm3
000071409bfd2ce1  vfmadd231pd xmm14, xmm1, xmm15
000071409bfd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
000071409bfd2cec  vptest xmm13, xmm13
000071409bfd2cf1  jnz 0x000071409BFD3F5D
000071409bfd2cf7  vmovaps xmm1, [rsp+0xB0]
000071409bfd2d00  vpermilpd xmm1, xmm1, 0x00
000071409bfd2d06  vmovaps xmm15, [rsp+0x10]
000071409bfd2d0c  movaps xmm13, xmm15
000071409bfd2d10  vfmadd231pd xmm13, xmm10, xmm1
000071409bfd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
000071409bfd2d1b  vptest xmm3, xmm3
000071409bfd2d20  jnz 0x000071409BFD40B5
000071409bfd2d26  vmovaps xmm1, [rsp+0xB0]
000071409bfd2d2f  vpermilpd xmm1, xmm1, 0x00
000071409bfd2d35  vmovaps xmm15, [rsp+0x30]
000071409bfd2d3b  movaps xmm10, xmm15
000071409bfd2d3f  vfmadd231pd xmm10, xmm11, xmm1
000071409bfd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
000071409bfd2d4a  vptest xmm3, xmm3
000071409bfd2d4f  jnz 0x000071409BFD420E
000071409bfd2d55  vmovaps xmm1, [rsp+0xB0]
000071409bfd2d5e  vpermilpd xmm1, xmm1, 0x00
000071409bfd2d64  movaps xmm15, xmm12
000071409bfd2d68  vfmadd231pd xmm15, xmm5, xmm1
000071409bfd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
000071409bfd2d73  vptest xmm11, xmm11
000071409bfd2d78  jnz 0x000071409BFD4367
000071409bfd2d7e  vmovaps [rsp+0x10], xmm9
000071409bfd2d84  vmovaps xmm1, [rsp+0x10]
000071409bfd2d8a  por xmm9, xmm1
000071409bfd2d8f  movaps [r15+0x180], xmm9
000071409bfd2d97  vmovaps [rsp+0x10], xmm2
000071409bfd2d9d  vmovaps xmm1, [rsp+0x10]
000071409bfd2da3  por xmm2, xmm1
000071409bfd2da7  movaps [r15+0x2D0], xmm2
000071409bfd2daf  vmovaps xmm12, [rsp+0xD0]
000071409bfd2db8  vpermilpd xmm12, xmm12, 0x00
000071409bfd2dbe  vmovaps xmm11, [rsp+0x60]
000071409bfd2dc4  movaps xmm5, xmm13
000071409bfd2dc8  vfmadd231pd xmm5, xmm11, xmm12
000071409bfd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
000071409bfd2dd2  vptest xmm3, xmm3
000071409bfd2dd7  jnz 0x000071409BFD44BF
000071409bfd2ddd  vmovaps xmm13, [rsp+0xD0]
000071409bfd2de6  vpermilpd xmm13, xmm13, 0x00
000071409bfd2dec  movaps xmm12, xmm14
000071409bfd2df0  vfmadd231pd xmm12, xmm9, xmm13
000071409bfd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
000071409bfd2dfb  vptest xmm11, xmm11
000071409bfd2e00  jnz 0x000071409BFD4617
000071409bfd2e06  lea rax, [r14+0x80]
000071409bfd2e0d  movups xmm14, [r13+rax*1]
000071409bfd2e13  movaps [r15+0x2F0], xmm14
000071409bfd2e1b  vmovaps xmm13, [rsp+0xD0]
000071409bfd2e24  vpermilpd xmm13, xmm13, 0x00
000071409bfd2e2a  movaps xmm11, xmm10
000071409bfd2e2e  vfmadd231pd xmm11, xmm8, xmm13
000071409bfd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
000071409bfd2e39  vptest xmm9, xmm9
000071409bfd2e3e  jnz 0x000071409BFD477B
000071409bfd2e44  vmovaps xmm13, [rsp+0xD0]
000071409bfd2e4d  vpermilpd xmm13, xmm13, 0x00
000071409bfd2e53  movaps xmm10, xmm15
000071409bfd2e57  vfmadd231pd xmm10, xmm1, xmm13
000071409bfd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
000071409bfd2e62  vptest xmm9, xmm9
000071409bfd2e67  jnz 0x000071409BFD48D5
000071409bfd2e6d  vmovaps [rsp+0x10], xmm7
000071409bfd2e73  vmovaps xmm1, [rsp+0x10]
000071409bfd2e79  por xmm7, xmm1
000071409bfd2e7d  movaps [r15+0x160], xmm7
000071409bfd2e85  lea rax, [r14+0x40]
000071409bfd2e89  movups xmm1, [r13+rax*1]
000071409bfd2e8f  lea rax, [r14+0x50]
000071409bfd2e93  movups xmm15, [r13+rax*1]
000071409bfd2e99  movaps [r15+0x1B0], xmm1
000071409bfd2ea1  movaps [r15+0x1A0], xmm15
000071409bfd2ea9  vmovaps xmm13, [rsp+0xA0]
000071409bfd2eb2  vpermilpd xmm13, xmm13, 0x00
000071409bfd2eb8  vmovaps xmm9, [rsp+0x40]
000071409bfd2ebe  movaps xmm8, xmm5
000071409bfd2ec2  vfmadd231pd xmm8, xmm9, xmm13
000071409bfd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
000071409bfd2ecd  vptest xmm3, xmm3
000071409bfd2ed2  jnz 0x000071409BFD4A42
000071409bfd2ed8  vmovaps xmm13, [rsp+0xA0]
000071409bfd2ee1  vpermilpd xmm13, xmm13, 0x00
000071409bfd2ee7  movaps xmm9, xmm12
000071409bfd2eeb  vfmadd231pd xmm9, xmm7, xmm13
000071409bfd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
000071409bfd2ef6  vptest xmm5, xmm5
000071409bfd2efb  jnz 0x000071409BFD4B9B
000071409bfd2f01  vmovaps xmm13, [rsp+0xA0]
000071409bfd2f0a  vpermilpd xmm13, xmm13, 0x00
000071409bfd2f10  movaps xmm12, xmm11
000071409bfd2f14  vfmadd231pd xmm12, xmm6, xmm13
000071409bfd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
000071409bfd2f1f  vptest xmm7, xmm7
000071409bfd2f24  jnz 0x000071409BFD4CF4
000071409bfd2f2a  vmovaps xmm13, [rsp+0xA0]
000071409bfd2f33  vpermilpd xmm13, xmm13, 0x00
000071409bfd2f39  vmovaps xmm11, [rsp+0x50]
000071409bfd2f3f  movaps xmm7, xmm10
000071409bfd2f43  vfmadd231pd xmm7, xmm11, xmm13
000071409bfd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
000071409bfd2f4d  vptest xmm6, xmm6
000071409bfd2f52  jnz 0x000071409BFD4E4D
000071409bfd2f58  lea rax, [r14+0x60]
000071409bfd2f5c  movups xmm13, [r13+rax*1]
000071409bfd2f62  lea rax, [r14+0x70]
000071409bfd2f66  movups xmm11, [r13+rax*1]
000071409bfd2f6c  movaps [r15+0x150], xmm13
000071409bfd2f74  movaps [r15+0x120], xmm11
000071409bfd2f7c  vmovaps xmm10, [rsp+0xC0]
000071409bfd2f85  vpermilpd xmm10, xmm10, 0x00
000071409bfd2f8b  movaps xmm6, xmm8
000071409bfd2f8f  vfmadd231pd xmm6, xmm15, xmm10
000071409bfd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
000071409bfd2f99  vptest xmm5, xmm5
000071409bfd2f9e  jnz 0x000071409BFD4FB9
000071409bfd2fa4  vmovaps xmm15, [rsp+0xC0]
000071409bfd2fad  vpermilpd xmm15, xmm15, 0x00
000071409bfd2fb3  movaps xmm10, xmm9
000071409bfd2fb7  vfmadd231pd xmm10, xmm13, xmm15
000071409bfd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
000071409bfd2fc2  vptest xmm8, xmm8
000071409bfd2fc7  jnz 0x000071409BFD5111
000071409bfd2fcd  vmovaps xmm15, [rsp+0xC0]
000071409bfd2fd6  vpermilpd xmm15, xmm15, 0x00
000071409bfd2fdc  movaps xmm13, xmm12
000071409bfd2fe0  vfmadd231pd xmm13, xmm4, xmm15
000071409bfd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
000071409bfd2feb  vptest xmm9, xmm9
000071409bfd2ff0  jnz 0x000071409BFD526B
000071409bfd2ff6  vmovaps xmm15, [rsp+0xC0]
000071409bfd2fff  vpermilpd xmm15, xmm15, 0x00
000071409bfd3005  movaps xmm12, xmm7
000071409bfd3009  vfmadd231pd xmm12, xmm1, xmm15
000071409bfd300e  vcmppd xmm9, xmm12, xmm12, 0x03
000071409bfd3014  vptest xmm9, xmm9
000071409bfd3019  jnz 0x000071409BFD53C4
000071409bfd301f  lea rax, [r14+0x20]
000071409bfd3023  movups xmm1, [r13+rax*1]
000071409bfd3029  lea rax, [r14+0x30]
000071409bfd302d  movups xmm15, [r13+rax*1]
000071409bfd3033  vmovaps xmm9, [rsp+0x70]
000071409bfd3039  vpermilpd xmm9, xmm9, 0x00
000071409bfd303f  vmovaps xmm8, [rsp+0x20]
000071409bfd3045  movaps xmm7, xmm6
000071409bfd3048  vfmadd231pd xmm7, xmm8, xmm9
000071409bfd304d  vcmppd xmm5, xmm7, xmm7, 0x03
000071409bfd3052  vptest xmm5, xmm5
000071409bfd3057  jnz 0x000071409BFD5530
000071409bfd305d  vmovaps xmm9, [rsp+0x70]
000071409bfd3063  vpermilpd xmm9, xmm9, 0x00
000071409bfd3069  movaps xmm8, xmm10
000071409bfd306d  vfmadd231pd xmm8, xmm14, xmm9
000071409bfd3072  vcmppd xmm6, xmm8, xmm8, 0x03
000071409bfd3078  vptest xmm6, xmm6
000071409bfd307d  jnz 0x000071409BFD5687
000071409bfd3083  vmovaps xmm14, [rsp+0x70]
000071409bfd3089  vpermilpd xmm14, xmm14, 0x00
000071409bfd308f  movaps xmm10, xmm13
000071409bfd3093  vfmadd231pd xmm10, xmm11, xmm14
000071409bfd3098  vcmppd xmm9, xmm10, xmm10, 0x03
000071409bfd309e  vptest xmm9, xmm9
000071409bfd30a3  jnz 0x000071409BFD57E1
000071409bfd30a9  vmovaps xmm14, [rsp+0x70]
000071409bfd30af  vpermilpd xmm14, xmm14, 0x00
000071409bfd30b5  movaps xmm13, xmm12
000071409bfd30b9  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd30be  vcmppd xmm11, xmm13, xmm13, 0x03
000071409bfd30c4  vptest xmm11, xmm11
000071409bfd30c9  jnz 0x000071409BFD593B
000071409bfd30cf  lea rax, [r14+0x90]
000071409bfd30d6  movups xmm15, [r13+rax*1]
000071409bfd30dc  lea rax, [r14+0xA0]
000071409bfd30e3  movups xmm14, [r13+rax*1]
000071409bfd30e9  movaps [r15+0x140], xmm15
000071409bfd30f1  movaps [r15+0x130], xmm14
000071409bfd30f9  vmovaps xmm12, [rsp+0x90]
000071409bfd3102  vpermilpd xmm12, xmm12, 0x00
000071409bfd3108  movaps xmm11, xmm7
000071409bfd310c  vfmadd231pd xmm11, xmm1, xmm12
000071409bfd3111  vcmppd xmm9, xmm11, xmm11, 0x03
000071409bfd3117  vptest xmm9, xmm9
000071409bfd311c  jnz 0x000071409BFD5AA9
000071409bfd3122  movaps [r15+0x220], xmm11
000071409bfd312a  lea rax, [r14+0x10]
000071409bfd312e  movups xmm1, [r13+rax*1]
000071409bfd3134  movaps [r15+0x240], xmm1
000071409bfd313c  vmovaps xmm12, [rsp+0x90]
000071409bfd3145  vpermilpd xmm12, xmm12, 0x00
000071409bfd314b  movaps xmm9, xmm8
000071409bfd314f  vfmadd231pd xmm9, xmm14, xmm12
000071409bfd3154  vcmppd xmm7, xmm9, xmm9, 0x03
000071409bfd315a  vptest xmm7, xmm7
000071409bfd315f  jnz 0x000071409BFD5C0B
000071409bfd3165  movaps [r15+0x110], xmm9
000071409bfd316d  vmovaps xmm14, [rsp+0x90]
000071409bfd3176  vpermilpd xmm14, xmm14, 0x00
000071409bfd317c  movaps xmm12, xmm10
000071409bfd3180  vfmadd231pd xmm12, xmm15, xmm14
000071409bfd3185  vcmppd xmm8, xmm12, xmm12, 0x03
000071409bfd318b  vptest xmm8, xmm8
000071409bfd3190  jnz 0x000071409BFD5D65
000071409bfd3196  movaps [r15+0x170], xmm12
000071409bfd319e  vmovaps xmm15, [rsp+0x90]
000071409bfd31a7  vpermilpd xmm15, xmm15, 0x00
000071409bfd31ad  movaps xmm14, xmm13
000071409bfd31b1  vfmadd231pd xmm14, xmm1, xmm15
000071409bfd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
000071409bfd31bc  vptest xmm10, xmm10
000071409bfd31c1  jnz 0x000071409BFD5EBF
000071409bfd31c7  movaps [r15+0x230], xmm14
000071409bfd31cf  mov eax, 0x432190
000071409bfd31d4  movups [r13+rax*1], xmm9
000071409bfd31da  mov eax, 0x4321A0
000071409bfd31df  movups [r13+rax*1], xmm12
000071409bfd31e5  mov eax, 0x4321B0
000071409bfd31ea  movups [r13+rax*1], xmm11
000071409bfd31f0  mov eax, 0x4321C0
000071409bfd31f5  movups [r13+rax*1], xmm14
000071409bfd31fb  mov eax, [r15+0x108]
000071409bfd3202  sahf
000071409bfd3203  jnz 0x000071409BFD3235
000071409bfd3205  cmp dword ptr [r15+0x318], 0x00
000071409bfd320d  jz 0x000071409BFD9950
000071409bfd3213  nop [rax+rax*1], ax
000071409bfd321c  nop [rax+rax*1], eax
000071409bfd3224  mov eax, 0x410664
000071409bfd3229  mov [r15+0x100], rax
000071409bfd3230  jmp 0x000071409BDFE110
000071409bfd3235  cmp dword ptr [r15+0x318], 0x00
000071409bfd323d  jz 0x000071409BFD6050
000071409bfd3243  nop [rax+rax*1], ax
000071409bfd324c  nop [rax+rax*1], eax
000071409bfd3254  mov eax, 0x4104F0
000071409bfd3259  mov [r15+0x100], rax
000071409bfd3260  jmp 0x000071409BDFE110
000071409bfd3265  int3
000071409bfd3266  call 0x000071409BDFF430
000071409bfd326b  jmp 0x000071409BFD230A
000071409bfd3270  call 0x000071409BEE5820
000071409bfd3275  jmp 0x000071409BFD2314
000071409bfd327a  call 0x000071409BEE45A0
000071409bfd327f  jmp 0x000071409BFD2326
000071409bfd3284  call 0x000071409BEE3320
000071409bfd3289  jmp 0x000071409BFD2330
000071409bfd328e  call 0x000071409BEE20A0
000071409bfd3293  jmp 0x000071409BFD233D
000071409bfd3298  call 0x000071409BEE0E30
000071409bfd329d  jmp 0x000071409BFD234A
000071409bfd32a2  call 0x000071409BED6600
000071409bfd32a7  jmp 0x000071409BFD2357
000071409bfd32ac  call 0x000071409BEB52F0
000071409bfd32b1  jmp 0x000071409BFD2361
000071409bfd32b6  call 0x000071409BEBE9C0
000071409bfd32bb  jmp 0x000071409BFD236B
000071409bfd32c0  call 0x000071409BEBD750
000071409bfd32c5  jmp 0x000071409BFD2378
000071409bfd32ca  call 0x000071409BEBC4E0
000071409bfd32cf  jmp 0x000071409BFD2385
000071409bfd32d4  call 0x000071409BEBB270
000071409bfd32d9  jmp 0x000071409BFD2392
000071409bfd32de  call 0x000071409BEBA000
000071409bfd32e3  jmp 0x000071409BFD239F
000071409bfd32e8  call 0x000071409BEB8D90
000071409bfd32ed  jmp 0x000071409BFD23AC
000071409bfd32f2  call 0x000071409BEB8A20
000071409bfd32f7  jmp 0x000071409BFD23B9
000071409bfd32fc  call 0x000071409BEBEAE0
000071409bfd3301  jmp 0x000071409BFD23C6
000071409bfd3306  call 0x000071409BEB5400
000071409bfd330b  jmp 0x000071409BFD23D3
000071409bfd3310  call 0x000071409BEB52F0
000071409bfd3315  jmp 0x000071409BFD23E0
000071409bfd331a  call 0x000071409BEBE9C0
000071409bfd331f  jmp 0x000071409BFD23ED
000071409bfd3324  call 0x000071409BEB77B0
000071409bfd3329  jmp 0x000071409BFD23FA
000071409bfd332e  call 0x000071409BEB6550
000071409bfd3333  jmp 0x000071409BFD2407
000071409bfd3338  call 0x000071409BEB52F0
000071409bfd333d  jmp 0x000071409BFD2417
000071409bfd3342  call 0x000071409BEB52F0
000071409bfd3347  jmp 0x000071409BFD2427
000071409bfd334c  call 0x000071409BEBEAE0
000071409bfd3351  jmp 0x000071409BFD2431
000071409bfd3356  call 0x000071409BEBEAE0
000071409bfd335b  jmp 0x000071409BFD2444
000071409bfd3360  call 0x000071409BEBE9C0
000071409bfd3365  jmp 0x000071409BFD2451
000071409bfd336a  call 0x000071409BEB52F0
000071409bfd336f  jmp 0x000071409BFD2464
000071409bfd3374  call 0x000071409BEB6660
000071409bfd3379  jmp 0x000071409BFD2471
000071409bfd337e  call 0x000071409BEB78C0
000071409bfd3383  jmp 0x000071409BFD247E
000071409bfd3388  call 0x000071409BEB77B0
000071409bfd338d  jmp 0x000071409BFD248B
000071409bfd3392  call 0x000071409BEB6550
000071409bfd3397  jmp 0x000071409BFD2498
000071409bfd339c  call 0x000071409BEB52F0
000071409bfd33a1  jmp 0x000071409BFD24AB
000071409bfd33a6  call 0x000071409BEB52F0
000071409bfd33ab  jmp 0x000071409BFD24BE
000071409bfd33b0  call 0x000071409BEB52F0
000071409bfd33b5  jmp 0x000071409BFD24E5
000071409bfd33ba  call 0x000071409BEB52F0
000071409bfd33bf  jmp 0x000071409BFD24F8
000071409bfd33c4  call 0x000071409BEB52F0
000071409bfd33c9  jmp 0x000071409BFD250B
000071409bfd33ce  call 0x000071409BEB52F0
000071409bfd33d3  jmp 0x000071409BFD2521
000071409bfd33d8  call 0x000071409BEB52F0
000071409bfd33dd  jmp 0x000071409BFD2537
000071409bfd33e2  call 0x000071409BEB52F0
000071409bfd33e7  jmp 0x000071409BFD254D
000071409bfd33ec  call 0x000071409BDFF540
000071409bfd33f1  jmp 0x000071409BFD256E
000071409bfd33f6  call 0x000071409BE02FE0
000071409bfd33fb  jmp 0x000071409BFD2578
000071409bfd3400  call 0x000071409BDFF540
000071409bfd3405  jmp 0x000071409BFD2588
000071409bfd340a  call 0x000071409BDFF540
000071409bfd340f  jmp 0x000071409BFD259B
000071409bfd3414  call 0x000071409BDFF540
000071409bfd3419  jmp 0x000071409BFD25AE
000071409bfd341e  call 0x000071409BDFF540
000071409bfd3423  jmp 0x000071409BFD25C1
000071409bfd3428  call 0x000071409BEC0370
000071409bfd342d  jmp 0x000071409BFD25E0
000071409bfd3432  call 0x000071409BEBF100
000071409bfd3437  jmp 0x000071409BFD25E9
000071409bfd343c  call 0x000071409BEC0370
000071409bfd3441  jmp 0x000071409BFD2659
000071409bfd3446  call 0x000071409BEBF100
000071409bfd344b  jmp 0x000071409BFD2662
000071409bfd3450  call 0x000071409BEC0370
000071409bfd3455  jmp 0x000071409BFD270C
000071409bfd345a  call 0x000071409BEBF100
000071409bfd345f  jmp 0x000071409BFD2715
000071409bfd3464  call 0x000071409BE0B720
000071409bfd3469  jmp 0x000071409BFD27F7
000071409bfd346e  call 0x000071409BED64F0
000071409bfd3473  jmp 0x000071409BFD281F
000071409bfd3478  call 0x000071409BEB47C0
000071409bfd347d  jmp 0x000071409BFD283A
000071409bfd3482  sub rsp, 0x08
000071409bfd3486  push rax
000071409bfd3487  push rcx
000071409bfd3488  push rdx
000071409bfd3489  push rdi
000071409bfd348a  push rsi
000071409bfd348b  push r8
000071409bfd348d  push r9
000071409bfd348f  push r10
000071409bfd3491  push r11
000071409bfd3493  sub rsp, 0xF0
000071409bfd349a  vmovaps [rsp], xmm0
000071409bfd349f  vmovaps [rsp+0x10], xmm1
000071409bfd34a5  vmovaps [rsp+0x20], xmm2
000071409bfd34ab  vmovaps [rsp+0x30], xmm3
000071409bfd34b1  vmovaps [rsp+0x40], xmm4
000071409bfd34b7  vmovaps [rsp+0x50], xmm5
000071409bfd34bd  vmovaps [rsp+0x60], xmm6
000071409bfd34c3  vmovaps [rsp+0x70], xmm7
000071409bfd34c9  vmovaps [rsp+0x80], xmm8
000071409bfd34d2  vmovaps [rsp+0x90], xmm9
000071409bfd34db  vmovaps [rsp+0xA0], xmm10
000071409bfd34e4  vmovaps [rsp+0xB0], xmm11
000071409bfd34ed  vmovaps [rsp+0xC0], xmm12
000071409bfd34f6  vmovaps [rsp+0xD0], xmm14
000071409bfd34ff  vmovaps [rsp+0xE0], xmm15
000071409bfd3508  sub rsp, 0x40
000071409bfd350c  lea rdi, [rsp]
000071409bfd3510  lea rsi, [rsp+0x10]
000071409bfd3515  lea rdx, [rsp+0x20]
000071409bfd351a  lea rcx, [rsp+0x30]
000071409bfd351f  mov r8d, 0x00
000071409bfd3525  lea r9, [r15+0x3A8]
000071409bfd352c  movaps [rdi], xmm13
000071409bfd3530  movaps [rsi], xmm1
000071409bfd3533  movaps [rdx], xmm15
000071409bfd3537  movaps [rcx], xmm14
000071409bfd353b  mov rax, 0x6219BEBC2A50
000071409bfd3545  call rax
000071409bfd3547  movaps xmm13, [rsp]
000071409bfd354c  add rsp, 0x40
000071409bfd3550  vmovaps xmm0, [rsp]
000071409bfd3555  vmovaps xmm1, [rsp+0x10]
000071409bfd355b  vmovaps xmm2, [rsp+0x20]
000071409bfd3561  vmovaps xmm3, [rsp+0x30]
000071409bfd3567  vmovaps xmm4, [rsp+0x40]
000071409bfd356d  vmovaps xmm5, [rsp+0x50]
000071409bfd3573  vmovaps xmm6, [rsp+0x60]
000071409bfd3579  vmovaps xmm7, [rsp+0x70]
000071409bfd357f  vmovaps xmm8, [rsp+0x80]
000071409bfd3588  vmovaps xmm9, [rsp+0x90]
000071409bfd3591  vmovaps xmm10, [rsp+0xA0]
000071409bfd359a  vmovaps xmm11, [rsp+0xB0]
000071409bfd35a3  vmovaps xmm12, [rsp+0xC0]
000071409bfd35ac  vmovaps xmm14, [rsp+0xD0]
000071409bfd35b5  vmovaps xmm15, [rsp+0xE0]
000071409bfd35be  add rsp, 0xF0
000071409bfd35c5  pop r11
000071409bfd35c7  pop r10
000071409bfd35c9  pop r9
000071409bfd35cb  pop r8
000071409bfd35cd  pop rsi
000071409bfd35ce  pop rdi
000071409bfd35cf  pop rdx
000071409bfd35d0  pop rcx
000071409bfd35d1  pop rax
000071409bfd35d2  add rsp, 0x08
000071409bfd35d6  jmp 0x000071409BFD28AD
000071409bfd35db  sub rsp, 0x08
000071409bfd35df  push rax
000071409bfd35e0  push rcx
000071409bfd35e1  push rdx
000071409bfd35e2  push rdi
000071409bfd35e3  push rsi
000071409bfd35e4  push r8
000071409bfd35e6  push r9
000071409bfd35e8  push r10
000071409bfd35ea  push r11
000071409bfd35ec  sub rsp, 0xF0
000071409bfd35f3  vmovaps [rsp], xmm0
000071409bfd35f8  vmovaps [rsp+0x10], xmm1
000071409bfd35fe  vmovaps [rsp+0x20], xmm2
000071409bfd3604  vmovaps [rsp+0x30], xmm3
000071409bfd360a  vmovaps [rsp+0x40], xmm4
000071409bfd3610  vmovaps [rsp+0x50], xmm5
000071409bfd3616  vmovaps [rsp+0x60], xmm6
000071409bfd361c  vmovaps [rsp+0x70], xmm7
000071409bfd3622  vmovaps [rsp+0x80], xmm8
000071409bfd362b  vmovaps [rsp+0x90], xmm9
000071409bfd3634  vmovaps [rsp+0xA0], xmm10
000071409bfd363d  vmovaps [rsp+0xB0], xmm11
000071409bfd3646  vmovaps [rsp+0xC0], xmm12
000071409bfd364f  vmovaps [rsp+0xD0], xmm13
000071409bfd3658  vmovaps [rsp+0xE0], xmm14
000071409bfd3661  sub rsp, 0x40
000071409bfd3665  lea rdi, [rsp]
000071409bfd3669  lea rsi, [rsp+0x10]
000071409bfd366e  lea rdx, [rsp+0x20]
000071409bfd3673  lea rcx, [rsp+0x30]
000071409bfd3678  mov r8d, 0x00
000071409bfd367e  lea r9, [r15+0x3A8]
000071409bfd3685  movaps [rdi], xmm15
000071409bfd3689  movaps [rsi], xmm5
000071409bfd368c  movaps [rdx], xmm1
000071409bfd368f  movaps [rcx], xmm14
000071409bfd3693  mov rax, 0x6219BEBC2A50
000071409bfd369d  call rax
000071409bfd369f  movaps xmm15, [rsp]
000071409bfd36a4  add rsp, 0x40
000071409bfd36a8  vmovaps xmm0, [rsp]
000071409bfd36ad  vmovaps xmm1, [rsp+0x10]
000071409bfd36b3  vmovaps xmm2, [rsp+0x20]
000071409bfd36b9  vmovaps xmm3, [rsp+0x30]
000071409bfd36bf  vmovaps xmm4, [rsp+0x40]
000071409bfd36c5  vmovaps xmm5, [rsp+0x50]
000071409bfd36cb  vmovaps xmm6, [rsp+0x60]
000071409bfd36d1  vmovaps xmm7, [rsp+0x70]
000071409bfd36d7  vmovaps xmm8, [rsp+0x80]
000071409bfd36e0  vmovaps xmm9, [rsp+0x90]
000071409bfd36e9  vmovaps xmm10, [rsp+0xA0]
000071409bfd36f2  vmovaps xmm11, [rsp+0xB0]
000071409bfd36fb  vmovaps xmm12, [rsp+0xC0]
000071409bfd3704  vmovaps xmm13, [rsp+0xD0]
000071409bfd370d  vmovaps xmm14, [rsp+0xE0]
000071409bfd3716  add rsp, 0xF0
000071409bfd371d  pop r11
000071409bfd371f  pop r10
000071409bfd3721  pop r9
000071409bfd3723  pop r8
000071409bfd3725  pop rsi
000071409bfd3726  pop rdi
000071409bfd3727  pop rdx
000071409bfd3728  pop rcx
000071409bfd3729  pop rax
000071409bfd372a  add rsp, 0x08
000071409bfd372e  jmp 0x000071409BFD28D0
000071409bfd3733  call 0x000071409BDFF430
000071409bfd3738  jmp 0x000071409BFD295D
000071409bfd373d  sub rsp, 0x08
000071409bfd3741  push rax
000071409bfd3742  push rcx
000071409bfd3743  push rdx
000071409bfd3744  push rdi
000071409bfd3745  push rsi
000071409bfd3746  push r8
000071409bfd3748  push r9
000071409bfd374a  push r10
000071409bfd374c  push r11
000071409bfd374e  sub rsp, 0xF0
000071409bfd3755  vmovaps [rsp], xmm0
000071409bfd375a  vmovaps [rsp+0x10], xmm1
000071409bfd3760  vmovaps [rsp+0x20], xmm2
000071409bfd3766  vmovaps [rsp+0x30], xmm3
000071409bfd376c  vmovaps [rsp+0x40], xmm4
000071409bfd3772  vmovaps [rsp+0x50], xmm5
000071409bfd3778  vmovaps [rsp+0x60], xmm6
000071409bfd377e  vmovaps [rsp+0x70], xmm7
000071409bfd3784  vmovaps [rsp+0x80], xmm8
000071409bfd378d  vmovaps [rsp+0x90], xmm9
000071409bfd3796  vmovaps [rsp+0xA0], xmm10
000071409bfd379f  vmovaps [rsp+0xB0], xmm11
000071409bfd37a8  vmovaps [rsp+0xC0], xmm12
000071409bfd37b1  vmovaps [rsp+0xD0], xmm14
000071409bfd37ba  vmovaps [rsp+0xE0], xmm15
000071409bfd37c3  sub rsp, 0x40
000071409bfd37c7  lea rdi, [rsp]
000071409bfd37cb  lea rsi, [rsp+0x10]
000071409bfd37d0  lea rdx, [rsp+0x20]
000071409bfd37d5  lea rcx, [rsp+0x30]
000071409bfd37da  mov r8d, 0x00
000071409bfd37e0  lea r9, [r15+0x3A8]
000071409bfd37e7  movaps [rdi], xmm13
000071409bfd37eb  movaps [rsi], xmm1
000071409bfd37ee  movaps [rdx], xmm15
000071409bfd37f2  movaps [rcx], xmm14
000071409bfd37f6  mov rax, 0x6219BEBC2A50
000071409bfd3800  call rax
000071409bfd3802  movaps xmm13, [rsp]
000071409bfd3807  add rsp, 0x40
000071409bfd380b  vmovaps xmm0, [rsp]
000071409bfd3810  vmovaps xmm1, [rsp+0x10]
000071409bfd3816  vmovaps xmm2, [rsp+0x20]
000071409bfd381c  vmovaps xmm3, [rsp+0x30]
000071409bfd3822  vmovaps xmm4, [rsp+0x40]
000071409bfd3828  vmovaps xmm5, [rsp+0x50]
000071409bfd382e  vmovaps xmm6, [rsp+0x60]
000071409bfd3834  vmovaps xmm7, [rsp+0x70]
000071409bfd383a  vmovaps xmm8, [rsp+0x80]
000071409bfd3843  vmovaps xmm9, [rsp+0x90]
000071409bfd384c  vmovaps xmm10, [rsp+0xA0]
000071409bfd3855  vmovaps xmm11, [rsp+0xB0]
000071409bfd385e  vmovaps xmm12, [rsp+0xC0]
000071409bfd3867  vmovaps xmm14, [rsp+0xD0]
000071409bfd3870  vmovaps xmm15, [rsp+0xE0]
000071409bfd3879  add rsp, 0xF0
000071409bfd3880  pop r11
000071409bfd3882  pop r10
000071409bfd3884  pop r9
000071409bfd3886  pop r8
000071409bfd3888  pop rsi
000071409bfd3889  pop rdi
000071409bfd388a  pop rdx
000071409bfd388b  pop rcx
000071409bfd388c  pop rax
000071409bfd388d  add rsp, 0x08
000071409bfd3891  jmp 0x000071409BFD29C1
000071409bfd3896  call 0x000071409BDFF430
000071409bfd389b  jmp 0x000071409BFD29CE
000071409bfd38a0  sub rsp, 0x08
000071409bfd38a4  push rax
000071409bfd38a5  push rcx
000071409bfd38a6  push rdx
000071409bfd38a7  push rdi
000071409bfd38a8  push rsi
000071409bfd38a9  push r8
000071409bfd38ab  push r9
000071409bfd38ad  push r10
000071409bfd38af  push r11
000071409bfd38b1  sub rsp, 0xF0
000071409bfd38b8  vmovaps [rsp], xmm0
000071409bfd38bd  vmovaps [rsp+0x10], xmm1
000071409bfd38c3  vmovaps [rsp+0x20], xmm2
000071409bfd38c9  vmovaps [rsp+0x30], xmm3
000071409bfd38cf  vmovaps [rsp+0x40], xmm4
000071409bfd38d5  vmovaps [rsp+0x50], xmm5
000071409bfd38db  vmovaps [rsp+0x60], xmm6
000071409bfd38e1  vmovaps [rsp+0x70], xmm7
000071409bfd38e7  vmovaps [rsp+0x80], xmm8
000071409bfd38f0  vmovaps [rsp+0x90], xmm9
000071409bfd38f9  vmovaps [rsp+0xA0], xmm10
000071409bfd3902  vmovaps [rsp+0xB0], xmm11
000071409bfd390b  vmovaps [rsp+0xC0], xmm13
000071409bfd3914  vmovaps [rsp+0xD0], xmm14
000071409bfd391d  vmovaps [rsp+0xE0], xmm15
000071409bfd3926  sub rsp, 0x40
000071409bfd392a  lea rdi, [rsp]
000071409bfd392e  lea rsi, [rsp+0x10]
000071409bfd3933  lea rdx, [rsp+0x20]
000071409bfd3938  lea rcx, [rsp+0x30]
000071409bfd393d  mov r8d, 0x00
000071409bfd3943  lea r9, [r15+0x3A8]
000071409bfd394a  movaps [rdi], xmm12
000071409bfd394e  movaps [rsi], xmm15
000071409bfd3952  movaps [rdx], xmm1
000071409bfd3955  movaps [rcx], xmm14
000071409bfd3959  mov rax, 0x6219BEBC2A50
000071409bfd3963  call rax
000071409bfd3965  movaps xmm12, [rsp]
000071409bfd396a  add rsp, 0x40
000071409bfd396e  vmovaps xmm0, [rsp]
000071409bfd3973  vmovaps xmm1, [rsp+0x10]
000071409bfd3979  vmovaps xmm2, [rsp+0x20]
000071409bfd397f  vmovaps xmm3, [rsp+0x30]
000071409bfd3985  vmovaps xmm4, [rsp+0x40]
000071409bfd398b  vmovaps xmm5, [rsp+0x50]
000071409bfd3991  vmovaps xmm6, [rsp+0x60]
000071409bfd3997  vmovaps xmm7, [rsp+0x70]
000071409bfd399d  vmovaps xmm8, [rsp+0x80]
000071409bfd39a6  vmovaps xmm9, [rsp+0x90]
000071409bfd39af  vmovaps xmm10, [rsp+0xA0]
000071409bfd39b8  vmovaps xmm11, [rsp+0xB0]
000071409bfd39c1  vmovaps xmm13, [rsp+0xC0]
000071409bfd39ca  vmovaps xmm14, [rsp+0xD0]
000071409bfd39d3  vmovaps xmm15, [rsp+0xE0]
000071409bfd39dc  add rsp, 0xF0
000071409bfd39e3  pop r11
000071409bfd39e5  pop r10
000071409bfd39e7  pop r9
000071409bfd39e9  pop r8
000071409bfd39eb  pop rsi
000071409bfd39ec  pop rdi
000071409bfd39ed  pop rdx
000071409bfd39ee  pop rcx
000071409bfd39ef  pop rax
000071409bfd39f0  add rsp, 0x08
000071409bfd39f4  jmp 0x000071409BFD29FA
000071409bfd39f9  sub rsp, 0x08
000071409bfd39fd  push rax
000071409bfd39fe  push rcx
000071409bfd39ff  push rdx
000071409bfd3a00  push rdi
000071409bfd3a01  push rsi
000071409bfd3a02  push r8
000071409bfd3a04  push r9
000071409bfd3a06  push r10
000071409bfd3a08  push r11
000071409bfd3a0a  sub rsp, 0xF0
000071409bfd3a11  vmovaps [rsp], xmm0
000071409bfd3a16  vmovaps [rsp+0x10], xmm1
000071409bfd3a1c  vmovaps [rsp+0x20], xmm2
000071409bfd3a22  vmovaps [rsp+0x30], xmm3
000071409bfd3a28  vmovaps [rsp+0x40], xmm4
000071409bfd3a2e  vmovaps [rsp+0x50], xmm5
000071409bfd3a34  vmovaps [rsp+0x60], xmm6
000071409bfd3a3a  vmovaps [rsp+0x70], xmm7
000071409bfd3a40  vmovaps [rsp+0x80], xmm8
000071409bfd3a49  vmovaps [rsp+0x90], xmm9
000071409bfd3a52  vmovaps [rsp+0xA0], xmm10
000071409bfd3a5b  vmovaps [rsp+0xB0], xmm11
000071409bfd3a64  vmovaps [rsp+0xC0], xmm12
000071409bfd3a6d  vmovaps [rsp+0xD0], xmm14
000071409bfd3a76  vmovaps [rsp+0xE0], xmm15
000071409bfd3a7f  sub rsp, 0x40
000071409bfd3a83  lea rdi, [rsp]
000071409bfd3a87  lea rsi, [rsp+0x10]
000071409bfd3a8c  lea rdx, [rsp+0x20]
000071409bfd3a91  lea rcx, [rsp+0x30]
000071409bfd3a96  mov r8d, 0x00
000071409bfd3a9c  lea r9, [r15+0x3A8]
000071409bfd3aa3  movaps [rdi], xmm13
000071409bfd3aa7  movaps [rsi], xmm1
000071409bfd3aaa  movaps [rdx], xmm15
000071409bfd3aae  movaps [rcx], xmm14
000071409bfd3ab2  mov rax, 0x6219BEBC2A50
000071409bfd3abc  call rax
000071409bfd3abe  movaps xmm13, [rsp]
000071409bfd3ac3  add rsp, 0x40
000071409bfd3ac7  vmovaps xmm0, [rsp]
000071409bfd3acc  vmovaps xmm1, [rsp+0x10]
000071409bfd3ad2  vmovaps xmm2, [rsp+0x20]
000071409bfd3ad8  vmovaps xmm3, [rsp+0x30]
000071409bfd3ade  vmovaps xmm4, [rsp+0x40]
000071409bfd3ae4  vmovaps xmm5, [rsp+0x50]
000071409bfd3aea  vmovaps xmm6, [rsp+0x60]
000071409bfd3af0  vmovaps xmm7, [rsp+0x70]
000071409bfd3af6  vmovaps xmm8, [rsp+0x80]
000071409bfd3aff  vmovaps xmm9, [rsp+0x90]
000071409bfd3b08  vmovaps xmm10, [rsp+0xA0]
000071409bfd3b11  vmovaps xmm11, [rsp+0xB0]
000071409bfd3b1a  vmovaps xmm12, [rsp+0xC0]
000071409bfd3b23  vmovaps xmm14, [rsp+0xD0]
000071409bfd3b2c  vmovaps xmm15, [rsp+0xE0]
000071409bfd3b35  add rsp, 0xF0
000071409bfd3b3c  pop r11
000071409bfd3b3e  pop r10
000071409bfd3b40  pop r9
000071409bfd3b42  pop r8
000071409bfd3b44  pop rsi
000071409bfd3b45  pop rdi
000071409bfd3b46  pop rdx
000071409bfd3b47  pop rcx
000071409bfd3b48  pop rax
000071409bfd3b49  add rsp, 0x08
000071409bfd3b4d  jmp 0x000071409BFD2B77
000071409bfd3b52  sub rsp, 0x08
000071409bfd3b56  push rax
000071409bfd3b57  push rcx
000071409bfd3b58  push rdx
000071409bfd3b59  push rdi
000071409bfd3b5a  push rsi
000071409bfd3b5b  push r8
000071409bfd3b5d  push r9
000071409bfd3b5f  push r10
000071409bfd3b61  push r11
000071409bfd3b63  sub rsp, 0xF0
000071409bfd3b6a  vmovaps [rsp], xmm0
000071409bfd3b6f  vmovaps [rsp+0x10], xmm1
000071409bfd3b75  vmovaps [rsp+0x20], xmm2
000071409bfd3b7b  vmovaps [rsp+0x30], xmm3
000071409bfd3b81  vmovaps [rsp+0x40], xmm4
000071409bfd3b87  vmovaps [rsp+0x50], xmm5
000071409bfd3b8d  vmovaps [rsp+0x60], xmm6
000071409bfd3b93  vmovaps [rsp+0x70], xmm7
000071409bfd3b99  vmovaps [rsp+0x80], xmm8
000071409bfd3ba2  vmovaps [rsp+0x90], xmm9
000071409bfd3bab  vmovaps [rsp+0xA0], xmm10
000071409bfd3bb4  vmovaps [rsp+0xB0], xmm11
000071409bfd3bbd  vmovaps [rsp+0xC0], xmm13
000071409bfd3bc6  vmovaps [rsp+0xD0], xmm14
000071409bfd3bcf  vmovaps [rsp+0xE0], xmm15
000071409bfd3bd8  sub rsp, 0x40
000071409bfd3bdc  lea rdi, [rsp]
000071409bfd3be0  lea rsi, [rsp+0x10]
000071409bfd3be5  lea rdx, [rsp+0x20]
000071409bfd3bea  lea rcx, [rsp+0x30]
000071409bfd3bef  mov r8d, 0x00
000071409bfd3bf5  lea r9, [r15+0x3A8]
000071409bfd3bfc  movaps [rdi], xmm12
000071409bfd3c00  movaps [rsi], xmm15
000071409bfd3c04  movaps [rdx], xmm14
000071409bfd3c08  movaps [rcx], xmm1
000071409bfd3c0b  mov rax, 0x6219BEBC2A50
000071409bfd3c15  call rax
000071409bfd3c17  movaps xmm12, [rsp]
000071409bfd3c1c  add rsp, 0x40
000071409bfd3c20  vmovaps xmm0, [rsp]
000071409bfd3c25  vmovaps xmm1, [rsp+0x10]
000071409bfd3c2b  vmovaps xmm2, [rsp+0x20]
000071409bfd3c31  vmovaps xmm3, [rsp+0x30]
000071409bfd3c37  vmovaps xmm4, [rsp+0x40]
000071409bfd3c3d  vmovaps xmm5, [rsp+0x50]
000071409bfd3c43  vmovaps xmm6, [rsp+0x60]
000071409bfd3c49  vmovaps xmm7, [rsp+0x70]
000071409bfd3c4f  vmovaps xmm8, [rsp+0x80]
000071409bfd3c58  vmovaps xmm9, [rsp+0x90]
000071409bfd3c61  vmovaps xmm10, [rsp+0xA0]
000071409bfd3c6a  vmovaps xmm11, [rsp+0xB0]
000071409bfd3c73  vmovaps xmm13, [rsp+0xC0]
000071409bfd3c7c  vmovaps xmm14, [rsp+0xD0]
000071409bfd3c85  vmovaps xmm15, [rsp+0xE0]
000071409bfd3c8e  add rsp, 0xF0
000071409bfd3c95  pop r11
000071409bfd3c97  pop r10
000071409bfd3c99  pop r9
000071409bfd3c9b  pop r8
000071409bfd3c9d  pop rsi
000071409bfd3c9e  pop rdi
000071409bfd3c9f  pop rdx
000071409bfd3ca0  pop rcx
000071409bfd3ca1  pop rax
000071409bfd3ca2  add rsp, 0x08
000071409bfd3ca6  jmp 0x000071409BFD2BB2
000071409bfd3cab  sub rsp, 0x08
000071409bfd3caf  push rax
000071409bfd3cb0  push rcx
000071409bfd3cb1  push rdx
000071409bfd3cb2  push rdi
000071409bfd3cb3  push rsi
000071409bfd3cb4  push r8
000071409bfd3cb6  push r9
000071409bfd3cb8  push r10
000071409bfd3cba  push r11
000071409bfd3cbc  sub rsp, 0xF0
000071409bfd3cc3  vmovaps [rsp], xmm0
000071409bfd3cc8  vmovaps [rsp+0x10], xmm1
000071409bfd3cce  vmovaps [rsp+0x20], xmm2
000071409bfd3cd4  vmovaps [rsp+0x30], xmm3
000071409bfd3cda  vmovaps [rsp+0x40], xmm4
000071409bfd3ce0  vmovaps [rsp+0x50], xmm5
000071409bfd3ce6  vmovaps [rsp+0x60], xmm6
000071409bfd3cec  vmovaps [rsp+0x70], xmm7
000071409bfd3cf2  vmovaps [rsp+0x80], xmm8
000071409bfd3cfb  vmovaps [rsp+0x90], xmm9
000071409bfd3d04  vmovaps [rsp+0xA0], xmm10
000071409bfd3d0d  vmovaps [rsp+0xB0], xmm11
000071409bfd3d16  vmovaps [rsp+0xC0], xmm12
000071409bfd3d1f  vmovaps [rsp+0xD0], xmm14
000071409bfd3d28  vmovaps [rsp+0xE0], xmm15
000071409bfd3d31  sub rsp, 0x40
000071409bfd3d35  lea rdi, [rsp]
000071409bfd3d39  lea rsi, [rsp+0x10]
000071409bfd3d3e  lea rdx, [rsp+0x20]
000071409bfd3d43  lea rcx, [rsp+0x30]
000071409bfd3d48  mov r8d, 0x00
000071409bfd3d4e  lea r9, [r15+0x3A8]
000071409bfd3d55  movaps [rdi], xmm13
000071409bfd3d59  movaps [rsi], xmm15
000071409bfd3d5d  movaps [rdx], xmm14
000071409bfd3d61  movaps [rcx], xmm1
000071409bfd3d64  mov rax, 0x6219BEBC2A50
000071409bfd3d6e  call rax
000071409bfd3d70  movaps xmm13, [rsp]
000071409bfd3d75  add rsp, 0x40
000071409bfd3d79  vmovaps xmm0, [rsp]
000071409bfd3d7e  vmovaps xmm1, [rsp+0x10]
000071409bfd3d84  vmovaps xmm2, [rsp+0x20]
000071409bfd3d8a  vmovaps xmm3, [rsp+0x30]
000071409bfd3d90  vmovaps xmm4, [rsp+0x40]
000071409bfd3d96  vmovaps xmm5, [rsp+0x50]
000071409bfd3d9c  vmovaps xmm6, [rsp+0x60]
000071409bfd3da2  vmovaps xmm7, [rsp+0x70]
000071409bfd3da8  vmovaps xmm8, [rsp+0x80]
000071409bfd3db1  vmovaps xmm9, [rsp+0x90]
000071409bfd3dba  vmovaps xmm10, [rsp+0xA0]
000071409bfd3dc3  vmovaps xmm11, [rsp+0xB0]
000071409bfd3dcc  vmovaps xmm12, [rsp+0xC0]
000071409bfd3dd5  vmovaps xmm14, [rsp+0xD0]
000071409bfd3dde  vmovaps xmm15, [rsp+0xE0]
000071409bfd3de7  add rsp, 0xF0
000071409bfd3dee  pop r11
000071409bfd3df0  pop r10
000071409bfd3df2  pop r9
000071409bfd3df4  pop r8
000071409bfd3df6  pop rsi
000071409bfd3df7  pop rdi
000071409bfd3df8  pop rdx
000071409bfd3df9  pop rcx
000071409bfd3dfa  pop rax
000071409bfd3dfb  add rsp, 0x08
000071409bfd3dff  jmp 0x000071409BFD2BEA
000071409bfd3e04  sub rsp, 0x08
000071409bfd3e08  push rax
000071409bfd3e09  push rcx
000071409bfd3e0a  push rdx
000071409bfd3e0b  push rdi
000071409bfd3e0c  push rsi
000071409bfd3e0d  push r8
000071409bfd3e0f  push r9
000071409bfd3e11  push r10
000071409bfd3e13  push r11
000071409bfd3e15  sub rsp, 0xF0
000071409bfd3e1c  vmovaps [rsp], xmm0
000071409bfd3e21  vmovaps [rsp+0x10], xmm1
000071409bfd3e27  vmovaps [rsp+0x20], xmm2
000071409bfd3e2d  vmovaps [rsp+0x30], xmm3
000071409bfd3e33  vmovaps [rsp+0x40], xmm4
000071409bfd3e39  vmovaps [rsp+0x50], xmm5
000071409bfd3e3f  vmovaps [rsp+0x60], xmm6
000071409bfd3e45  vmovaps [rsp+0x70], xmm7
000071409bfd3e4b  vmovaps [rsp+0x80], xmm8
000071409bfd3e54  vmovaps [rsp+0x90], xmm9
000071409bfd3e5d  vmovaps [rsp+0xA0], xmm10
000071409bfd3e66  vmovaps [rsp+0xB0], xmm11
000071409bfd3e6f  vmovaps [rsp+0xC0], xmm13
000071409bfd3e78  vmovaps [rsp+0xD0], xmm14
000071409bfd3e81  vmovaps [rsp+0xE0], xmm15
000071409bfd3e8a  sub rsp, 0x40
000071409bfd3e8e  lea rdi, [rsp]
000071409bfd3e92  lea rsi, [rsp+0x10]
000071409bfd3e97  lea rdx, [rsp+0x20]
000071409bfd3e9c  lea rcx, [rsp+0x30]
000071409bfd3ea1  mov r8d, 0x00
000071409bfd3ea7  lea r9, [r15+0x3A8]
000071409bfd3eae  movaps [rdi], xmm12
000071409bfd3eb2  movaps [rsi], xmm15
000071409bfd3eb6  movaps [rdx], xmm14
000071409bfd3eba  movaps [rcx], xmm1
000071409bfd3ebd  mov rax, 0x6219BEBC2A50
000071409bfd3ec7  call rax
000071409bfd3ec9  movaps xmm12, [rsp]
000071409bfd3ece  add rsp, 0x40
000071409bfd3ed2  vmovaps xmm0, [rsp]
000071409bfd3ed7  vmovaps xmm1, [rsp+0x10]
000071409bfd3edd  vmovaps xmm2, [rsp+0x20]
000071409bfd3ee3  vmovaps xmm3, [rsp+0x30]
000071409bfd3ee9  vmovaps xmm4, [rsp+0x40]
000071409bfd3eef  vmovaps xmm5, [rsp+0x50]
000071409bfd3ef5  vmovaps xmm6, [rsp+0x60]
000071409bfd3efb  vmovaps xmm7, [rsp+0x70]
000071409bfd3f01  vmovaps xmm8, [rsp+0x80]
000071409bfd3f0a  vmovaps xmm9, [rsp+0x90]
000071409bfd3f13  vmovaps xmm10, [rsp+0xA0]
000071409bfd3f1c  vmovaps xmm11, [rsp+0xB0]
000071409bfd3f25  vmovaps xmm13, [rsp+0xC0]
000071409bfd3f2e  vmovaps xmm14, [rsp+0xD0]
000071409bfd3f37  vmovaps xmm15, [rsp+0xE0]
000071409bfd3f40  add rsp, 0xF0
000071409bfd3f47  pop r11
000071409bfd3f49  pop r10
000071409bfd3f4b  pop r9
000071409bfd3f4d  pop r8
000071409bfd3f4f  pop rsi
000071409bfd3f50  pop rdi
000071409bfd3f51  pop rdx
000071409bfd3f52  pop rcx
000071409bfd3f53  pop rax
000071409bfd3f54  add rsp, 0x08
000071409bfd3f58  jmp 0x000071409BFD2C3D
000071409bfd3f5d  sub rsp, 0x08
000071409bfd3f61  push rax
000071409bfd3f62  push rcx
000071409bfd3f63  push rdx
000071409bfd3f64  push rdi
000071409bfd3f65  push rsi
000071409bfd3f66  push r8
000071409bfd3f68  push r9
000071409bfd3f6a  push r10
000071409bfd3f6c  push r11
000071409bfd3f6e  sub rsp, 0xF0
000071409bfd3f75  vmovaps [rsp], xmm0
000071409bfd3f7a  vmovaps [rsp+0x10], xmm1
000071409bfd3f80  vmovaps [rsp+0x20], xmm2
000071409bfd3f86  vmovaps [rsp+0x30], xmm3
000071409bfd3f8c  vmovaps [rsp+0x40], xmm4
000071409bfd3f92  vmovaps [rsp+0x50], xmm5
000071409bfd3f98  vmovaps [rsp+0x60], xmm6
000071409bfd3f9e  vmovaps [rsp+0x70], xmm7
000071409bfd3fa4  vmovaps [rsp+0x80], xmm8
000071409bfd3fad  vmovaps [rsp+0x90], xmm9
000071409bfd3fb6  vmovaps [rsp+0xA0], xmm10
000071409bfd3fbf  vmovaps [rsp+0xB0], xmm11
000071409bfd3fc8  vmovaps [rsp+0xC0], xmm12
000071409bfd3fd1  vmovaps [rsp+0xD0], xmm13
000071409bfd3fda  vmovaps [rsp+0xE0], xmm15
000071409bfd3fe3  sub rsp, 0x40
000071409bfd3fe7  lea rdi, [rsp]
000071409bfd3feb  lea rsi, [rsp+0x10]
000071409bfd3ff0  lea rdx, [rsp+0x20]
000071409bfd3ff5  lea rcx, [rsp+0x30]
000071409bfd3ffa  mov r8d, 0x00
000071409bfd4000  lea r9, [r15+0x3A8]
000071409bfd4007  movaps [rdi], xmm14
000071409bfd400b  movaps [rsi], xmm3
000071409bfd400e  movaps [rdx], xmm1
000071409bfd4011  movaps [rcx], xmm15
000071409bfd4015  mov rax, 0x6219BEBC2A50
000071409bfd401f  call rax
000071409bfd4021  movaps xmm14, [rsp]
000071409bfd4026  add rsp, 0x40
000071409bfd402a  vmovaps xmm0, [rsp]
000071409bfd402f  vmovaps xmm1, [rsp+0x10]
000071409bfd4035  vmovaps xmm2, [rsp+0x20]
000071409bfd403b  vmovaps xmm3, [rsp+0x30]
000071409bfd4041  vmovaps xmm4, [rsp+0x40]
000071409bfd4047  vmovaps xmm5, [rsp+0x50]
000071409bfd404d  vmovaps xmm6, [rsp+0x60]
000071409bfd4053  vmovaps xmm7, [rsp+0x70]
000071409bfd4059  vmovaps xmm8, [rsp+0x80]
000071409bfd4062  vmovaps xmm9, [rsp+0x90]
000071409bfd406b  vmovaps xmm10, [rsp+0xA0]
000071409bfd4074  vmovaps xmm11, [rsp+0xB0]
000071409bfd407d  vmovaps xmm12, [rsp+0xC0]
000071409bfd4086  vmovaps xmm13, [rsp+0xD0]
000071409bfd408f  vmovaps xmm15, [rsp+0xE0]
000071409bfd4098  add rsp, 0xF0
000071409bfd409f  pop r11
000071409bfd40a1  pop r10
000071409bfd40a3  pop r9
000071409bfd40a5  pop r8
000071409bfd40a7  pop rsi
000071409bfd40a8  pop rdi
000071409bfd40a9  pop rdx
000071409bfd40aa  pop rcx
000071409bfd40ab  pop rax
000071409bfd40ac  add rsp, 0x08
000071409bfd40b0  jmp 0x000071409BFD2CF7
000071409bfd40b5  sub rsp, 0x08
000071409bfd40b9  push rax
000071409bfd40ba  push rcx
000071409bfd40bb  push rdx
000071409bfd40bc  push rdi
000071409bfd40bd  push rsi
000071409bfd40be  push r8
000071409bfd40c0  push r9
000071409bfd40c2  push r10
000071409bfd40c4  push r11
000071409bfd40c6  sub rsp, 0xF0
000071409bfd40cd  vmovaps [rsp], xmm0
000071409bfd40d2  vmovaps [rsp+0x10], xmm1
000071409bfd40d8  vmovaps [rsp+0x20], xmm2
000071409bfd40de  vmovaps [rsp+0x30], xmm3
000071409bfd40e4  vmovaps [rsp+0x40], xmm4
000071409bfd40ea  vmovaps [rsp+0x50], xmm5
000071409bfd40f0  vmovaps [rsp+0x60], xmm6
000071409bfd40f6  vmovaps [rsp+0x70], xmm7
000071409bfd40fc  vmovaps [rsp+0x80], xmm8
000071409bfd4105  vmovaps [rsp+0x90], xmm9
000071409bfd410e  vmovaps [rsp+0xA0], xmm10
000071409bfd4117  vmovaps [rsp+0xB0], xmm11
000071409bfd4120  vmovaps [rsp+0xC0], xmm12
000071409bfd4129  vmovaps [rsp+0xD0], xmm14
000071409bfd4132  vmovaps [rsp+0xE0], xmm15
000071409bfd413b  sub rsp, 0x40
000071409bfd413f  lea rdi, [rsp]
000071409bfd4143  lea rsi, [rsp+0x10]
000071409bfd4148  lea rdx, [rsp+0x20]
000071409bfd414d  lea rcx, [rsp+0x30]
000071409bfd4152  mov r8d, 0x00
000071409bfd4158  lea r9, [r15+0x3A8]
000071409bfd415f  movaps [rdi], xmm13
000071409bfd4163  movaps [rsi], xmm15
000071409bfd4167  movaps [rdx], xmm10
000071409bfd416b  movaps [rcx], xmm1
000071409bfd416e  mov rax, 0x6219BEBC2A50
000071409bfd4178  call rax
000071409bfd417a  movaps xmm13, [rsp]
000071409bfd417f  add rsp, 0x40
000071409bfd4183  vmovaps xmm0, [rsp]
000071409bfd4188  vmovaps xmm1, [rsp+0x10]
000071409bfd418e  vmovaps xmm2, [rsp+0x20]
000071409bfd4194  vmovaps xmm3, [rsp+0x30]
000071409bfd419a  vmovaps xmm4, [rsp+0x40]
000071409bfd41a0  vmovaps xmm5, [rsp+0x50]
000071409bfd41a6  vmovaps xmm6, [rsp+0x60]
000071409bfd41ac  vmovaps xmm7, [rsp+0x70]
000071409bfd41b2  vmovaps xmm8, [rsp+0x80]
000071409bfd41bb  vmovaps xmm9, [rsp+0x90]
000071409bfd41c4  vmovaps xmm10, [rsp+0xA0]
000071409bfd41cd  vmovaps xmm11, [rsp+0xB0]
000071409bfd41d6  vmovaps xmm12, [rsp+0xC0]
000071409bfd41df  vmovaps xmm14, [rsp+0xD0]
000071409bfd41e8  vmovaps xmm15, [rsp+0xE0]
000071409bfd41f1  add rsp, 0xF0
000071409bfd41f8  pop r11
000071409bfd41fa  pop r10
000071409bfd41fc  pop r9
000071409bfd41fe  pop r8
000071409bfd4200  pop rsi
000071409bfd4201  pop rdi
000071409bfd4202  pop rdx
000071409bfd4203  pop rcx
000071409bfd4204  pop rax
000071409bfd4205  add rsp, 0x08
000071409bfd4209  jmp 0x000071409BFD2D26
000071409bfd420e  sub rsp, 0x08
000071409bfd4212  push rax
000071409bfd4213  push rcx
000071409bfd4214  push rdx
000071409bfd4215  push rdi
000071409bfd4216  push rsi
000071409bfd4217  push r8
000071409bfd4219  push r9
000071409bfd421b  push r10
000071409bfd421d  push r11
000071409bfd421f  sub rsp, 0xF0
000071409bfd4226  vmovaps [rsp], xmm0
000071409bfd422b  vmovaps [rsp+0x10], xmm1
000071409bfd4231  vmovaps [rsp+0x20], xmm2
000071409bfd4237  vmovaps [rsp+0x30], xmm3
000071409bfd423d  vmovaps [rsp+0x40], xmm4
000071409bfd4243  vmovaps [rsp+0x50], xmm5
000071409bfd4249  vmovaps [rsp+0x60], xmm6
000071409bfd424f  vmovaps [rsp+0x70], xmm7
000071409bfd4255  vmovaps [rsp+0x80], xmm8
000071409bfd425e  vmovaps [rsp+0x90], xmm9
000071409bfd4267  vmovaps [rsp+0xA0], xmm11
000071409bfd4270  vmovaps [rsp+0xB0], xmm12
000071409bfd4279  vmovaps [rsp+0xC0], xmm13
000071409bfd4282  vmovaps [rsp+0xD0], xmm14
000071409bfd428b  vmovaps [rsp+0xE0], xmm15
000071409bfd4294  sub rsp, 0x40
000071409bfd4298  lea rdi, [rsp]
000071409bfd429c  lea rsi, [rsp+0x10]
000071409bfd42a1  lea rdx, [rsp+0x20]
000071409bfd42a6  lea rcx, [rsp+0x30]
000071409bfd42ab  mov r8d, 0x00
000071409bfd42b1  lea r9, [r15+0x3A8]
000071409bfd42b8  movaps [rdi], xmm10
000071409bfd42bc  movaps [rsi], xmm15
000071409bfd42c0  movaps [rdx], xmm11
000071409bfd42c4  movaps [rcx], xmm1
000071409bfd42c7  mov rax, 0x6219BEBC2A50
000071409bfd42d1  call rax
000071409bfd42d3  movaps xmm10, [rsp]
000071409bfd42d8  add rsp, 0x40
000071409bfd42dc  vmovaps xmm0, [rsp]
000071409bfd42e1  vmovaps xmm1, [rsp+0x10]
000071409bfd42e7  vmovaps xmm2, [rsp+0x20]
000071409bfd42ed  vmovaps xmm3, [rsp+0x30]
000071409bfd42f3  vmovaps xmm4, [rsp+0x40]
000071409bfd42f9  vmovaps xmm5, [rsp+0x50]
000071409bfd42ff  vmovaps xmm6, [rsp+0x60]
000071409bfd4305  vmovaps xmm7, [rsp+0x70]
000071409bfd430b  vmovaps xmm8, [rsp+0x80]
000071409bfd4314  vmovaps xmm9, [rsp+0x90]
000071409bfd431d  vmovaps xmm11, [rsp+0xA0]
000071409bfd4326  vmovaps xmm12, [rsp+0xB0]
000071409bfd432f  vmovaps xmm13, [rsp+0xC0]
000071409bfd4338  vmovaps xmm14, [rsp+0xD0]
000071409bfd4341  vmovaps xmm15, [rsp+0xE0]
000071409bfd434a  add rsp, 0xF0
000071409bfd4351  pop r11
000071409bfd4353  pop r10
000071409bfd4355  pop r9
000071409bfd4357  pop r8
000071409bfd4359  pop rsi
000071409bfd435a  pop rdi
000071409bfd435b  pop rdx
000071409bfd435c  pop rcx
000071409bfd435d  pop rax
000071409bfd435e  add rsp, 0x08
000071409bfd4362  jmp 0x000071409BFD2D55
000071409bfd4367  sub rsp, 0x08
000071409bfd436b  push rax
000071409bfd436c  push rcx
000071409bfd436d  push rdx
000071409bfd436e  push rdi
000071409bfd436f  push rsi
000071409bfd4370  push r8
000071409bfd4372  push r9
000071409bfd4374  push r10
000071409bfd4376  push r11
000071409bfd4378  sub rsp, 0xF0
000071409bfd437f  vmovaps [rsp], xmm0
000071409bfd4384  vmovaps [rsp+0x10], xmm1
000071409bfd438a  vmovaps [rsp+0x20], xmm2
000071409bfd4390  vmovaps [rsp+0x30], xmm3
000071409bfd4396  vmovaps [rsp+0x40], xmm4
000071409bfd439c  vmovaps [rsp+0x50], xmm5
000071409bfd43a2  vmovaps [rsp+0x60], xmm6
000071409bfd43a8  vmovaps [rsp+0x70], xmm7
000071409bfd43ae  vmovaps [rsp+0x80], xmm8
000071409bfd43b7  vmovaps [rsp+0x90], xmm9
000071409bfd43c0  vmovaps [rsp+0xA0], xmm10
000071409bfd43c9  vmovaps [rsp+0xB0], xmm11
000071409bfd43d2  vmovaps [rsp+0xC0], xmm12
000071409bfd43db  vmovaps [rsp+0xD0], xmm13
000071409bfd43e4  vmovaps [rsp+0xE0], xmm14
000071409bfd43ed  sub rsp, 0x40
000071409bfd43f1  lea rdi, [rsp]
000071409bfd43f5  lea rsi, [rsp+0x10]
000071409bfd43fa  lea rdx, [rsp+0x20]
000071409bfd43ff  lea rcx, [rsp+0x30]
000071409bfd4404  mov r8d, 0x00
000071409bfd440a  lea r9, [r15+0x3A8]
000071409bfd4411  movaps [rdi], xmm15
000071409bfd4415  movaps [rsi], xmm12
000071409bfd4419  movaps [rdx], xmm5
000071409bfd441c  movaps [rcx], xmm1
000071409bfd441f  mov rax, 0x6219BEBC2A50
000071409bfd4429  call rax
000071409bfd442b  movaps xmm15, [rsp]
000071409bfd4430  add rsp, 0x40
000071409bfd4434  vmovaps xmm0, [rsp]
000071409bfd4439  vmovaps xmm1, [rsp+0x10]
000071409bfd443f  vmovaps xmm2, [rsp+0x20]
000071409bfd4445  vmovaps xmm3, [rsp+0x30]
000071409bfd444b  vmovaps xmm4, [rsp+0x40]
000071409bfd4451  vmovaps xmm5, [rsp+0x50]
000071409bfd4457  vmovaps xmm6, [rsp+0x60]
000071409bfd445d  vmovaps xmm7, [rsp+0x70]
000071409bfd4463  vmovaps xmm8, [rsp+0x80]
000071409bfd446c  vmovaps xmm9, [rsp+0x90]
000071409bfd4475  vmovaps xmm10, [rsp+0xA0]
000071409bfd447e  vmovaps xmm11, [rsp+0xB0]
000071409bfd4487  vmovaps xmm12, [rsp+0xC0]
000071409bfd4490  vmovaps xmm13, [rsp+0xD0]
000071409bfd4499  vmovaps xmm14, [rsp+0xE0]
000071409bfd44a2  add rsp, 0xF0
000071409bfd44a9  pop r11
000071409bfd44ab  pop r10
000071409bfd44ad  pop r9
000071409bfd44af  pop r8
000071409bfd44b1  pop rsi
000071409bfd44b2  pop rdi
000071409bfd44b3  pop rdx
000071409bfd44b4  pop rcx
000071409bfd44b5  pop rax
000071409bfd44b6  add rsp, 0x08
000071409bfd44ba  jmp 0x000071409BFD2D7E
000071409bfd44bf  sub rsp, 0x08
000071409bfd44c3  push rax
000071409bfd44c4  push rcx
000071409bfd44c5  push rdx
000071409bfd44c6  push rdi
000071409bfd44c7  push rsi
000071409bfd44c8  push r8
000071409bfd44ca  push r9
000071409bfd44cc  push r10
000071409bfd44ce  push r11
000071409bfd44d0  sub rsp, 0xF0
000071409bfd44d7  vmovaps [rsp], xmm0
000071409bfd44dc  vmovaps [rsp+0x10], xmm1
000071409bfd44e2  vmovaps [rsp+0x20], xmm2
000071409bfd44e8  vmovaps [rsp+0x30], xmm3
000071409bfd44ee  vmovaps [rsp+0x40], xmm4
000071409bfd44f4  vmovaps [rsp+0x50], xmm6
000071409bfd44fa  vmovaps [rsp+0x60], xmm7
000071409bfd4500  vmovaps [rsp+0x70], xmm8
000071409bfd4506  vmovaps [rsp+0x80], xmm9
000071409bfd450f  vmovaps [rsp+0x90], xmm10
000071409bfd4518  vmovaps [rsp+0xA0], xmm11
000071409bfd4521  vmovaps [rsp+0xB0], xmm12
000071409bfd452a  vmovaps [rsp+0xC0], xmm13
000071409bfd4533  vmovaps [rsp+0xD0], xmm14
000071409bfd453c  vmovaps [rsp+0xE0], xmm15
000071409bfd4545  sub rsp, 0x40
000071409bfd4549  lea rdi, [rsp]
000071409bfd454d  lea rsi, [rsp+0x10]
000071409bfd4552  lea rdx, [rsp+0x20]
000071409bfd4557  lea rcx, [rsp+0x30]
000071409bfd455c  mov r8d, 0x00
000071409bfd4562  lea r9, [r15+0x3A8]
000071409bfd4569  movaps [rdi], xmm5
000071409bfd456c  movaps [rsi], xmm13
000071409bfd4570  movaps [rdx], xmm11
000071409bfd4574  movaps [rcx], xmm12
000071409bfd4578  mov rax, 0x6219BEBC2A50
000071409bfd4582  call rax
000071409bfd4584  movaps xmm5, [rsp]
000071409bfd4588  add rsp, 0x40
000071409bfd458c  vmovaps xmm0, [rsp]
000071409bfd4591  vmovaps xmm1, [rsp+0x10]
000071409bfd4597  vmovaps xmm2, [rsp+0x20]
000071409bfd459d  vmovaps xmm3, [rsp+0x30]
000071409bfd45a3  vmovaps xmm4, [rsp+0x40]
000071409bfd45a9  vmovaps xmm6, [rsp+0x50]
000071409bfd45af  vmovaps xmm7, [rsp+0x60]
000071409bfd45b5  vmovaps xmm8, [rsp+0x70]
000071409bfd45bb  vmovaps xmm9, [rsp+0x80]
000071409bfd45c4  vmovaps xmm10, [rsp+0x90]
000071409bfd45cd  vmovaps xmm11, [rsp+0xA0]
000071409bfd45d6  vmovaps xmm12, [rsp+0xB0]
000071409bfd45df  vmovaps xmm13, [rsp+0xC0]
000071409bfd45e8  vmovaps xmm14, [rsp+0xD0]
000071409bfd45f1  vmovaps xmm15, [rsp+0xE0]
000071409bfd45fa  add rsp, 0xF0
000071409bfd4601  pop r11
000071409bfd4603  pop r10
000071409bfd4605  pop r9
000071409bfd4607  pop r8
000071409bfd4609  pop rsi
000071409bfd460a  pop rdi
000071409bfd460b  pop rdx
000071409bfd460c  pop rcx
000071409bfd460d  pop rax
000071409bfd460e  add rsp, 0x08
000071409bfd4612  jmp 0x000071409BFD2DDD
000071409bfd4617  sub rsp, 0x08
000071409bfd461b  push rax
000071409bfd461c  push rcx
000071409bfd461d  push rdx
000071409bfd461e  push rdi
000071409bfd461f  push rsi
000071409bfd4620  push r8
000071409bfd4622  push r9
000071409bfd4624  push r10
000071409bfd4626  push r11
000071409bfd4628  sub rsp, 0xF0
000071409bfd462f  vmovaps [rsp], xmm0
000071409bfd4634  vmovaps [rsp+0x10], xmm1
000071409bfd463a  vmovaps [rsp+0x20], xmm2
000071409bfd4640  vmovaps [rsp+0x30], xmm3
000071409bfd4646  vmovaps [rsp+0x40], xmm4
000071409bfd464c  vmovaps [rsp+0x50], xmm5
000071409bfd4652  vmovaps [rsp+0x60], xmm6
000071409bfd4658  vmovaps [rsp+0x70], xmm7
000071409bfd465e  vmovaps [rsp+0x80], xmm8
000071409bfd4667  vmovaps [rsp+0x90], xmm9
000071409bfd4670  vmovaps [rsp+0xA0], xmm10
000071409bfd4679  vmovaps [rsp+0xB0], xmm11
000071409bfd4682  vmovaps [rsp+0xC0], xmm13
000071409bfd468b  vmovaps [rsp+0xD0], xmm14
000071409bfd4694  vmovaps [rsp+0xE0], xmm15
000071409bfd469d  sub rsp, 0x40
000071409bfd46a1  lea rdi, [rsp]
000071409bfd46a5  lea rsi, [rsp+0x10]
000071409bfd46aa  lea rdx, [rsp+0x20]
000071409bfd46af  lea rcx, [rsp+0x30]
000071409bfd46b4  mov r8d, 0x00
000071409bfd46ba  lea r9, [r15+0x3A8]
000071409bfd46c1  movaps [rdi], xmm12
000071409bfd46c5  movaps [rsi], xmm14
000071409bfd46c9  movaps [rdx], xmm9
000071409bfd46cd  movaps [rcx], xmm13
000071409bfd46d1  mov rax, 0x6219BEBC2A50
000071409bfd46db  call rax
000071409bfd46dd  movaps xmm12, [rsp]
000071409bfd46e2  add rsp, 0x40
000071409bfd46e6  vmovaps xmm0, [rsp]
000071409bfd46eb  vmovaps xmm1, [rsp+0x10]
000071409bfd46f1  vmovaps xmm2, [rsp+0x20]
000071409bfd46f7  vmovaps xmm3, [rsp+0x30]
000071409bfd46fd  vmovaps xmm4, [rsp+0x40]
000071409bfd4703  vmovaps xmm5, [rsp+0x50]
000071409bfd4709  vmovaps xmm6, [rsp+0x60]
000071409bfd470f  vmovaps xmm7, [rsp+0x70]
000071409bfd4715  vmovaps xmm8, [rsp+0x80]
000071409bfd471e  vmovaps xmm9, [rsp+0x90]
000071409bfd4727  vmovaps xmm10, [rsp+0xA0]
000071409bfd4730  vmovaps xmm11, [rsp+0xB0]
000071409bfd4739  vmovaps xmm13, [rsp+0xC0]
000071409bfd4742  vmovaps xmm14, [rsp+0xD0]
000071409bfd474b  vmovaps xmm15, [rsp+0xE0]
000071409bfd4754  add rsp, 0xF0
000071409bfd475b  pop r11
000071409bfd475d  pop r10
000071409bfd475f  pop r9
000071409bfd4761  pop r8
000071409bfd4763  pop rsi
000071409bfd4764  pop rdi
000071409bfd4765  pop rdx
000071409bfd4766  pop rcx
000071409bfd4767  pop rax
000071409bfd4768  add rsp, 0x08
000071409bfd476c  jmp 0x000071409BFD2E06
000071409bfd4771  call 0x000071409BE0D4E0
000071409bfd4776  jmp 0x000071409BFD2E13
000071409bfd477b  sub rsp, 0x08
000071409bfd477f  push rax
000071409bfd4780  push rcx
000071409bfd4781  push rdx
000071409bfd4782  push rdi
000071409bfd4783  push rsi
000071409bfd4784  push r8
000071409bfd4786  push r9
000071409bfd4788  push r10
000071409bfd478a  push r11
000071409bfd478c  sub rsp, 0xF0
000071409bfd4793  vmovaps [rsp], xmm0
000071409bfd4798  vmovaps [rsp+0x10], xmm1
000071409bfd479e  vmovaps [rsp+0x20], xmm2
000071409bfd47a4  vmovaps [rsp+0x30], xmm3
000071409bfd47aa  vmovaps [rsp+0x40], xmm4
000071409bfd47b0  vmovaps [rsp+0x50], xmm5
000071409bfd47b6  vmovaps [rsp+0x60], xmm6
000071409bfd47bc  vmovaps [rsp+0x70], xmm7
000071409bfd47c2  vmovaps [rsp+0x80], xmm8
000071409bfd47cb  vmovaps [rsp+0x90], xmm9
000071409bfd47d4  vmovaps [rsp+0xA0], xmm10
000071409bfd47dd  vmovaps [rsp+0xB0], xmm12
000071409bfd47e6  vmovaps [rsp+0xC0], xmm13
000071409bfd47ef  vmovaps [rsp+0xD0], xmm14
000071409bfd47f8  vmovaps [rsp+0xE0], xmm15
000071409bfd4801  sub rsp, 0x40
000071409bfd4805  lea rdi, [rsp]
000071409bfd4809  lea rsi, [rsp+0x10]
000071409bfd480e  lea rdx, [rsp+0x20]
000071409bfd4813  lea rcx, [rsp+0x30]
000071409bfd4818  mov r8d, 0x00
000071409bfd481e  lea r9, [r15+0x3A8]
000071409bfd4825  movaps [rdi], xmm11
000071409bfd4829  movaps [rsi], xmm10
000071409bfd482d  movaps [rdx], xmm8
000071409bfd4831  movaps [rcx], xmm13
000071409bfd4835  mov rax, 0x6219BEBC2A50
000071409bfd483f  call rax
000071409bfd4841  movaps xmm11, [rsp]
000071409bfd4846  add rsp, 0x40
000071409bfd484a  vmovaps xmm0, [rsp]
000071409bfd484f  vmovaps xmm1, [rsp+0x10]
000071409bfd4855  vmovaps xmm2, [rsp+0x20]
000071409bfd485b  vmovaps xmm3, [rsp+0x30]
000071409bfd4861  vmovaps xmm4, [rsp+0x40]
000071409bfd4867  vmovaps xmm5, [rsp+0x50]
000071409bfd486d  vmovaps xmm6, [rsp+0x60]
000071409bfd4873  vmovaps xmm7, [rsp+0x70]
000071409bfd4879  vmovaps xmm8, [rsp+0x80]
000071409bfd4882  vmovaps xmm9, [rsp+0x90]
000071409bfd488b  vmovaps xmm10, [rsp+0xA0]
000071409bfd4894  vmovaps xmm12, [rsp+0xB0]
000071409bfd489d  vmovaps xmm13, [rsp+0xC0]
000071409bfd48a6  vmovaps xmm14, [rsp+0xD0]
000071409bfd48af  vmovaps xmm15, [rsp+0xE0]
000071409bfd48b8  add rsp, 0xF0
000071409bfd48bf  pop r11
000071409bfd48c1  pop r10
000071409bfd48c3  pop r9
000071409bfd48c5  pop r8
000071409bfd48c7  pop rsi
000071409bfd48c8  pop rdi
000071409bfd48c9  pop rdx
000071409bfd48ca  pop rcx
000071409bfd48cb  pop rax
000071409bfd48cc  add rsp, 0x08
000071409bfd48d0  jmp 0x000071409BFD2E44
000071409bfd48d5  sub rsp, 0x08
000071409bfd48d9  push rax
000071409bfd48da  push rcx
000071409bfd48db  push rdx
000071409bfd48dc  push rdi
000071409bfd48dd  push rsi
000071409bfd48de  push r8
000071409bfd48e0  push r9
000071409bfd48e2  push r10
000071409bfd48e4  push r11
000071409bfd48e6  sub rsp, 0xF0
000071409bfd48ed  vmovaps [rsp], xmm0
000071409bfd48f2  vmovaps [rsp+0x10], xmm1
000071409bfd48f8  vmovaps [rsp+0x20], xmm2
000071409bfd48fe  vmovaps [rsp+0x30], xmm3
000071409bfd4904  vmovaps [rsp+0x40], xmm4
000071409bfd490a  vmovaps [rsp+0x50], xmm5
000071409bfd4910  vmovaps [rsp+0x60], xmm6
000071409bfd4916  vmovaps [rsp+0x70], xmm7
000071409bfd491c  vmovaps [rsp+0x80], xmm8
000071409bfd4925  vmovaps [rsp+0x90], xmm9
000071409bfd492e  vmovaps [rsp+0xA0], xmm11
000071409bfd4937  vmovaps [rsp+0xB0], xmm12
000071409bfd4940  vmovaps [rsp+0xC0], xmm13
000071409bfd4949  vmovaps [rsp+0xD0], xmm14
000071409bfd4952  vmovaps [rsp+0xE0], xmm15
000071409bfd495b  sub rsp, 0x40
000071409bfd495f  lea rdi, [rsp]
000071409bfd4963  lea rsi, [rsp+0x10]
000071409bfd4968  lea rdx, [rsp+0x20]
000071409bfd496d  lea rcx, [rsp+0x30]
000071409bfd4972  mov r8d, 0x00
000071409bfd4978  lea r9, [r15+0x3A8]
000071409bfd497f  movaps [rdi], xmm10
000071409bfd4983  movaps [rsi], xmm15
000071409bfd4987  movaps [rdx], xmm1
000071409bfd498a  movaps [rcx], xmm13
000071409bfd498e  mov rax, 0x6219BEBC2A50
000071409bfd4998  call rax
000071409bfd499a  movaps xmm10, [rsp]
000071409bfd499f  add rsp, 0x40
000071409bfd49a3  vmovaps xmm0, [rsp]
000071409bfd49a8  vmovaps xmm1, [rsp+0x10]
000071409bfd49ae  vmovaps xmm2, [rsp+0x20]
000071409bfd49b4  vmovaps xmm3, [rsp+0x30]
000071409bfd49ba  vmovaps xmm4, [rsp+0x40]
000071409bfd49c0  vmovaps xmm5, [rsp+0x50]
000071409bfd49c6  vmovaps xmm6, [rsp+0x60]
000071409bfd49cc  vmovaps xmm7, [rsp+0x70]
000071409bfd49d2  vmovaps xmm8, [rsp+0x80]
000071409bfd49db  vmovaps xmm9, [rsp+0x90]
000071409bfd49e4  vmovaps xmm11, [rsp+0xA0]
000071409bfd49ed  vmovaps xmm12, [rsp+0xB0]
000071409bfd49f6  vmovaps xmm13, [rsp+0xC0]
000071409bfd49ff  vmovaps xmm14, [rsp+0xD0]
000071409bfd4a08  vmovaps xmm15, [rsp+0xE0]
000071409bfd4a11  add rsp, 0xF0
000071409bfd4a18  pop r11
000071409bfd4a1a  pop r10
000071409bfd4a1c  pop r9
000071409bfd4a1e  pop r8
000071409bfd4a20  pop rsi
000071409bfd4a21  pop rdi
000071409bfd4a22  pop rdx
000071409bfd4a23  pop rcx
000071409bfd4a24  pop rax
000071409bfd4a25  add rsp, 0x08
000071409bfd4a29  jmp 0x000071409BFD2E6D
000071409bfd4a2e  call 0x000071409BDFF430
000071409bfd4a33  jmp 0x000071409BFD2E8F
000071409bfd4a38  call 0x000071409BE0E760
000071409bfd4a3d  jmp 0x000071409BFD2E99
000071409bfd4a42  sub rsp, 0x08
000071409bfd4a46  push rax
000071409bfd4a47  push rcx
000071409bfd4a48  push rdx
000071409bfd4a49  push rdi
000071409bfd4a4a  push rsi
000071409bfd4a4b  push r8
000071409bfd4a4d  push r9
000071409bfd4a4f  push r10
000071409bfd4a51  push r11
000071409bfd4a53  sub rsp, 0xF0
000071409bfd4a5a  vmovaps [rsp], xmm0
000071409bfd4a5f  vmovaps [rsp+0x10], xmm1
000071409bfd4a65  vmovaps [rsp+0x20], xmm2
000071409bfd4a6b  vmovaps [rsp+0x30], xmm3
000071409bfd4a71  vmovaps [rsp+0x40], xmm4
000071409bfd4a77  vmovaps [rsp+0x50], xmm5
000071409bfd4a7d  vmovaps [rsp+0x60], xmm6
000071409bfd4a83  vmovaps [rsp+0x70], xmm7
000071409bfd4a89  vmovaps [rsp+0x80], xmm9
000071409bfd4a92  vmovaps [rsp+0x90], xmm10
000071409bfd4a9b  vmovaps [rsp+0xA0], xmm11
000071409bfd4aa4  vmovaps [rsp+0xB0], xmm12
000071409bfd4aad  vmovaps [rsp+0xC0], xmm13
000071409bfd4ab6  vmovaps [rsp+0xD0], xmm14
000071409bfd4abf  vmovaps [rsp+0xE0], xmm15
000071409bfd4ac8  sub rsp, 0x40
000071409bfd4acc  lea rdi, [rsp]
000071409bfd4ad0  lea rsi, [rsp+0x10]
000071409bfd4ad5  lea rdx, [rsp+0x20]
000071409bfd4ada  lea rcx, [rsp+0x30]
000071409bfd4adf  mov r8d, 0x00
000071409bfd4ae5  lea r9, [r15+0x3A8]
000071409bfd4aec  movaps [rdi], xmm8
000071409bfd4af0  movaps [rsi], xmm5
000071409bfd4af3  movaps [rdx], xmm9
000071409bfd4af7  movaps [rcx], xmm13
000071409bfd4afb  mov rax, 0x6219BEBC2A50
000071409bfd4b05  call rax
000071409bfd4b07  movaps xmm8, [rsp]
000071409bfd4b0c  add rsp, 0x40
000071409bfd4b10  vmovaps xmm0, [rsp]
000071409bfd4b15  vmovaps xmm1, [rsp+0x10]
000071409bfd4b1b  vmovaps xmm2, [rsp+0x20]
000071409bfd4b21  vmovaps xmm3, [rsp+0x30]
000071409bfd4b27  vmovaps xmm4, [rsp+0x40]
000071409bfd4b2d  vmovaps xmm5, [rsp+0x50]
000071409bfd4b33  vmovaps xmm6, [rsp+0x60]
000071409bfd4b39  vmovaps xmm7, [rsp+0x70]
000071409bfd4b3f  vmovaps xmm9, [rsp+0x80]
000071409bfd4b48  vmovaps xmm10, [rsp+0x90]
000071409bfd4b51  vmovaps xmm11, [rsp+0xA0]
000071409bfd4b5a  vmovaps xmm12, [rsp+0xB0]
000071409bfd4b63  vmovaps xmm13, [rsp+0xC0]
000071409bfd4b6c  vmovaps xmm14, [rsp+0xD0]
000071409bfd4b75  vmovaps xmm15, [rsp+0xE0]
000071409bfd4b7e  add rsp, 0xF0
000071409bfd4b85  pop r11
000071409bfd4b87  pop r10
000071409bfd4b89  pop r9
000071409bfd4b8b  pop r8
000071409bfd4b8d  pop rsi
000071409bfd4b8e  pop rdi
000071409bfd4b8f  pop rdx
000071409bfd4b90  pop rcx
000071409bfd4b91  pop rax
000071409bfd4b92  add rsp, 0x08
000071409bfd4b96  jmp 0x000071409BFD2ED8
000071409bfd4b9b  sub rsp, 0x08
000071409bfd4b9f  push rax
000071409bfd4ba0  push rcx
000071409bfd4ba1  push rdx
000071409bfd4ba2  push rdi
000071409bfd4ba3  push rsi
000071409bfd4ba4  push r8
000071409bfd4ba6  push r9
000071409bfd4ba8  push r10
000071409bfd4baa  push r11
000071409bfd4bac  sub rsp, 0xF0
000071409bfd4bb3  vmovaps [rsp], xmm0
000071409bfd4bb8  vmovaps [rsp+0x10], xmm1
000071409bfd4bbe  vmovaps [rsp+0x20], xmm2
000071409bfd4bc4  vmovaps [rsp+0x30], xmm3
000071409bfd4bca  vmovaps [rsp+0x40], xmm4
000071409bfd4bd0  vmovaps [rsp+0x50], xmm5
000071409bfd4bd6  vmovaps [rsp+0x60], xmm6
000071409bfd4bdc  vmovaps [rsp+0x70], xmm7
000071409bfd4be2  vmovaps [rsp+0x80], xmm8
000071409bfd4beb  vmovaps [rsp+0x90], xmm10
000071409bfd4bf4  vmovaps [rsp+0xA0], xmm11
000071409bfd4bfd  vmovaps [rsp+0xB0], xmm12
000071409bfd4c06  vmovaps [rsp+0xC0], xmm13
000071409bfd4c0f  vmovaps [rsp+0xD0], xmm14
000071409bfd4c18  vmovaps [rsp+0xE0], xmm15
000071409bfd4c21  sub rsp, 0x40
000071409bfd4c25  lea rdi, [rsp]
000071409bfd4c29  lea rsi, [rsp+0x10]
000071409bfd4c2e  lea rdx, [rsp+0x20]
000071409bfd4c33  lea rcx, [rsp+0x30]
000071409bfd4c38  mov r8d, 0x00
000071409bfd4c3e  lea r9, [r15+0x3A8]
000071409bfd4c45  movaps [rdi], xmm9
000071409bfd4c49  movaps [rsi], xmm12
000071409bfd4c4d  movaps [rdx], xmm7
000071409bfd4c50  movaps [rcx], xmm13
000071409bfd4c54  mov rax, 0x6219BEBC2A50
000071409bfd4c5e  call rax
000071409bfd4c60  movaps xmm9, [rsp]
000071409bfd4c65  add rsp, 0x40
000071409bfd4c69  vmovaps xmm0, [rsp]
000071409bfd4c6e  vmovaps xmm1, [rsp+0x10]
000071409bfd4c74  vmovaps xmm2, [rsp+0x20]
000071409bfd4c7a  vmovaps xmm3, [rsp+0x30]
000071409bfd4c80  vmovaps xmm4, [rsp+0x40]
000071409bfd4c86  vmovaps xmm5, [rsp+0x50]
000071409bfd4c8c  vmovaps xmm6, [rsp+0x60]
000071409bfd4c92  vmovaps xmm7, [rsp+0x70]
000071409bfd4c98  vmovaps xmm8, [rsp+0x80]
000071409bfd4ca1  vmovaps xmm10, [rsp+0x90]
000071409bfd4caa  vmovaps xmm11, [rsp+0xA0]
000071409bfd4cb3  vmovaps xmm12, [rsp+0xB0]
000071409bfd4cbc  vmovaps xmm13, [rsp+0xC0]
000071409bfd4cc5  vmovaps xmm14, [rsp+0xD0]
000071409bfd4cce  vmovaps xmm15, [rsp+0xE0]
000071409bfd4cd7  add rsp, 0xF0
000071409bfd4cde  pop r11
000071409bfd4ce0  pop r10
000071409bfd4ce2  pop r9
000071409bfd4ce4  pop r8
000071409bfd4ce6  pop rsi
000071409bfd4ce7  pop rdi
000071409bfd4ce8  pop rdx
000071409bfd4ce9  pop rcx
000071409bfd4cea  pop rax
000071409bfd4ceb  add rsp, 0x08
000071409bfd4cef  jmp 0x000071409BFD2F01
000071409bfd4cf4  sub rsp, 0x08
000071409bfd4cf8  push rax
000071409bfd4cf9  push rcx
000071409bfd4cfa  push rdx
000071409bfd4cfb  push rdi
000071409bfd4cfc  push rsi
000071409bfd4cfd  push r8
000071409bfd4cff  push r9
000071409bfd4d01  push r10
000071409bfd4d03  push r11
000071409bfd4d05  sub rsp, 0xF0
000071409bfd4d0c  vmovaps [rsp], xmm0
000071409bfd4d11  vmovaps [rsp+0x10], xmm1
000071409bfd4d17  vmovaps [rsp+0x20], xmm2
000071409bfd4d1d  vmovaps [rsp+0x30], xmm3
000071409bfd4d23  vmovaps [rsp+0x40], xmm4
000071409bfd4d29  vmovaps [rsp+0x50], xmm5
000071409bfd4d2f  vmovaps [rsp+0x60], xmm6
000071409bfd4d35  vmovaps [rsp+0x70], xmm7
000071409bfd4d3b  vmovaps [rsp+0x80], xmm8
000071409bfd4d44  vmovaps [rsp+0x90], xmm9
000071409bfd4d4d  vmovaps [rsp+0xA0], xmm10
000071409bfd4d56  vmovaps [rsp+0xB0], xmm11
000071409bfd4d5f  vmovaps [rsp+0xC0], xmm13
000071409bfd4d68  vmovaps [rsp+0xD0], xmm14
000071409bfd4d71  vmovaps [rsp+0xE0], xmm15
000071409bfd4d7a  sub rsp, 0x40
000071409bfd4d7e  lea rdi, [rsp]
000071409bfd4d82  lea rsi, [rsp+0x10]
000071409bfd4d87  lea rdx, [rsp+0x20]
000071409bfd4d8c  lea rcx, [rsp+0x30]
000071409bfd4d91  mov r8d, 0x00
000071409bfd4d97  lea r9, [r15+0x3A8]
000071409bfd4d9e  movaps [rdi], xmm12
000071409bfd4da2  movaps [rsi], xmm11
000071409bfd4da6  movaps [rdx], xmm6
000071409bfd4da9  movaps [rcx], xmm13
000071409bfd4dad  mov rax, 0x6219BEBC2A50
000071409bfd4db7  call rax
000071409bfd4db9  movaps xmm12, [rsp]
000071409bfd4dbe  add rsp, 0x40
000071409bfd4dc2  vmovaps xmm0, [rsp]
000071409bfd4dc7  vmovaps xmm1, [rsp+0x10]
000071409bfd4dcd  vmovaps xmm2, [rsp+0x20]
000071409bfd4dd3  vmovaps xmm3, [rsp+0x30]
000071409bfd4dd9  vmovaps xmm4, [rsp+0x40]
000071409bfd4ddf  vmovaps xmm5, [rsp+0x50]
000071409bfd4de5  vmovaps xmm6, [rsp+0x60]
000071409bfd4deb  vmovaps xmm7, [rsp+0x70]
000071409bfd4df1  vmovaps xmm8, [rsp+0x80]
000071409bfd4dfa  vmovaps xmm9, [rsp+0x90]
000071409bfd4e03  vmovaps xmm10, [rsp+0xA0]
000071409bfd4e0c  vmovaps xmm11, [rsp+0xB0]
000071409bfd4e15  vmovaps xmm13, [rsp+0xC0]
000071409bfd4e1e  vmovaps xmm14, [rsp+0xD0]
000071409bfd4e27  vmovaps xmm15, [rsp+0xE0]
000071409bfd4e30  add rsp, 0xF0
000071409bfd4e37  pop r11
000071409bfd4e39  pop r10
000071409bfd4e3b  pop r9
000071409bfd4e3d  pop r8
000071409bfd4e3f  pop rsi
000071409bfd4e40  pop rdi
000071409bfd4e41  pop rdx
000071409bfd4e42  pop rcx
000071409bfd4e43  pop rax
000071409bfd4e44  add rsp, 0x08
000071409bfd4e48  jmp 0x000071409BFD2F2A
000071409bfd4e4d  sub rsp, 0x08
000071409bfd4e51  push rax
000071409bfd4e52  push rcx
000071409bfd4e53  push rdx
000071409bfd4e54  push rdi
000071409bfd4e55  push rsi
000071409bfd4e56  push r8
000071409bfd4e58  push r9
000071409bfd4e5a  push r10
000071409bfd4e5c  push r11
000071409bfd4e5e  sub rsp, 0xF0
000071409bfd4e65  vmovaps [rsp], xmm0
000071409bfd4e6a  vmovaps [rsp+0x10], xmm1
000071409bfd4e70  vmovaps [rsp+0x20], xmm2
000071409bfd4e76  vmovaps [rsp+0x30], xmm3
000071409bfd4e7c  vmovaps [rsp+0x40], xmm4
000071409bfd4e82  vmovaps [rsp+0x50], xmm5
000071409bfd4e88  vmovaps [rsp+0x60], xmm6
000071409bfd4e8e  vmovaps [rsp+0x70], xmm8
000071409bfd4e94  vmovaps [rsp+0x80], xmm9
000071409bfd4e9d  vmovaps [rsp+0x90], xmm10
000071409bfd4ea6  vmovaps [rsp+0xA0], xmm11
000071409bfd4eaf  vmovaps [rsp+0xB0], xmm12
000071409bfd4eb8  vmovaps [rsp+0xC0], xmm13
000071409bfd4ec1  vmovaps [rsp+0xD0], xmm14
000071409bfd4eca  vmovaps [rsp+0xE0], xmm15
000071409bfd4ed3  sub rsp, 0x40
000071409bfd4ed7  lea rdi, [rsp]
000071409bfd4edb  lea rsi, [rsp+0x10]
000071409bfd4ee0  lea rdx, [rsp+0x20]
000071409bfd4ee5  lea rcx, [rsp+0x30]
000071409bfd4eea  mov r8d, 0x00
000071409bfd4ef0  lea r9, [r15+0x3A8]
000071409bfd4ef7  movaps [rdi], xmm7
000071409bfd4efa  movaps [rsi], xmm10
000071409bfd4efe  movaps [rdx], xmm11
000071409bfd4f02  movaps [rcx], xmm13
000071409bfd4f06  mov rax, 0x6219BEBC2A50
000071409bfd4f10  call rax
000071409bfd4f12  movaps xmm7, [rsp]
000071409bfd4f16  add rsp, 0x40
000071409bfd4f1a  vmovaps xmm0, [rsp]
000071409bfd4f1f  vmovaps xmm1, [rsp+0x10]
000071409bfd4f25  vmovaps xmm2, [rsp+0x20]
000071409bfd4f2b  vmovaps xmm3, [rsp+0x30]
000071409bfd4f31  vmovaps xmm4, [rsp+0x40]
000071409bfd4f37  vmovaps xmm5, [rsp+0x50]
000071409bfd4f3d  vmovaps xmm6, [rsp+0x60]
000071409bfd4f43  vmovaps xmm8, [rsp+0x70]
000071409bfd4f49  vmovaps xmm9, [rsp+0x80]
000071409bfd4f52  vmovaps xmm10, [rsp+0x90]
000071409bfd4f5b  vmovaps xmm11, [rsp+0xA0]
000071409bfd4f64  vmovaps xmm12, [rsp+0xB0]
000071409bfd4f6d  vmovaps xmm13, [rsp+0xC0]
000071409bfd4f76  vmovaps xmm14, [rsp+0xD0]
000071409bfd4f7f  vmovaps xmm15, [rsp+0xE0]
000071409bfd4f88  add rsp, 0xF0
000071409bfd4f8f  pop r11
000071409bfd4f91  pop r10
000071409bfd4f93  pop r9
000071409bfd4f95  pop r8
000071409bfd4f97  pop rsi
000071409bfd4f98  pop rdi
000071409bfd4f99  pop rdx
000071409bfd4f9a  pop rcx
000071409bfd4f9b  pop rax
000071409bfd4f9c  add rsp, 0x08
000071409bfd4fa0  jmp 0x000071409BFD2F58
000071409bfd4fa5  call 0x000071409BE0C260
000071409bfd4faa  jmp 0x000071409BFD2F62
000071409bfd4faf  call 0x000071409BE09D70
000071409bfd4fb4  jmp 0x000071409BFD2F6C
000071409bfd4fb9  sub rsp, 0x08
000071409bfd4fbd  push rax
000071409bfd4fbe  push rcx
000071409bfd4fbf  push rdx
000071409bfd4fc0  push rdi
000071409bfd4fc1  push rsi
000071409bfd4fc2  push r8
000071409bfd4fc4  push r9
000071409bfd4fc6  push r10
000071409bfd4fc8  push r11
000071409bfd4fca  sub rsp, 0xF0
000071409bfd4fd1  vmovaps [rsp], xmm0
000071409bfd4fd6  vmovaps [rsp+0x10], xmm1
000071409bfd4fdc  vmovaps [rsp+0x20], xmm2
000071409bfd4fe2  vmovaps [rsp+0x30], xmm3
000071409bfd4fe8  vmovaps [rsp+0x40], xmm4
000071409bfd4fee  vmovaps [rsp+0x50], xmm5
000071409bfd4ff4  vmovaps [rsp+0x60], xmm7
000071409bfd4ffa  vmovaps [rsp+0x70], xmm8
000071409bfd5000  vmovaps [rsp+0x80], xmm9
000071409bfd5009  vmovaps [rsp+0x90], xmm10
000071409bfd5012  vmovaps [rsp+0xA0], xmm11
000071409bfd501b  vmovaps [rsp+0xB0], xmm12
000071409bfd5024  vmovaps [rsp+0xC0], xmm13
000071409bfd502d  vmovaps [rsp+0xD0], xmm14
000071409bfd5036  vmovaps [rsp+0xE0], xmm15
000071409bfd503f  sub rsp, 0x40
000071409bfd5043  lea rdi, [rsp]
000071409bfd5047  lea rsi, [rsp+0x10]
000071409bfd504c  lea rdx, [rsp+0x20]
000071409bfd5051  lea rcx, [rsp+0x30]
000071409bfd5056  mov r8d, 0x00
000071409bfd505c  lea r9, [r15+0x3A8]
000071409bfd5063  movaps [rdi], xmm6
000071409bfd5066  movaps [rsi], xmm8
000071409bfd506a  movaps [rdx], xmm15
000071409bfd506e  movaps [rcx], xmm10
000071409bfd5072  mov rax, 0x6219BEBC2A50
000071409bfd507c  call rax
000071409bfd507e  movaps xmm6, [rsp]
000071409bfd5082  add rsp, 0x40
000071409bfd5086  vmovaps xmm0, [rsp]
000071409bfd508b  vmovaps xmm1, [rsp+0x10]
000071409bfd5091  vmovaps xmm2, [rsp+0x20]
000071409bfd5097  vmovaps xmm3, [rsp+0x30]
000071409bfd509d  vmovaps xmm4, [rsp+0x40]
000071409bfd50a3  vmovaps xmm5, [rsp+0x50]
000071409bfd50a9  vmovaps xmm7, [rsp+0x60]
000071409bfd50af  vmovaps xmm8, [rsp+0x70]
000071409bfd50b5  vmovaps xmm9, [rsp+0x80]
000071409bfd50be  vmovaps xmm10, [rsp+0x90]
000071409bfd50c7  vmovaps xmm11, [rsp+0xA0]
000071409bfd50d0  vmovaps xmm12, [rsp+0xB0]
000071409bfd50d9  vmovaps xmm13, [rsp+0xC0]
000071409bfd50e2  vmovaps xmm14, [rsp+0xD0]
000071409bfd50eb  vmovaps xmm15, [rsp+0xE0]
000071409bfd50f4  add rsp, 0xF0
000071409bfd50fb  pop r11
000071409bfd50fd  pop r10
000071409bfd50ff  pop r9
000071409bfd5101  pop r8
000071409bfd5103  pop rsi
000071409bfd5104  pop rdi
000071409bfd5105  pop rdx
000071409bfd5106  pop rcx
000071409bfd5107  pop rax
000071409bfd5108  add rsp, 0x08
000071409bfd510c  jmp 0x000071409BFD2FA4
000071409bfd5111  sub rsp, 0x08
000071409bfd5115  push rax
000071409bfd5116  push rcx
000071409bfd5117  push rdx
000071409bfd5118  push rdi
000071409bfd5119  push rsi
000071409bfd511a  push r8
000071409bfd511c  push r9
000071409bfd511e  push r10
000071409bfd5120  push r11
000071409bfd5122  sub rsp, 0xF0
000071409bfd5129  vmovaps [rsp], xmm0
000071409bfd512e  vmovaps [rsp+0x10], xmm1
000071409bfd5134  vmovaps [rsp+0x20], xmm2
000071409bfd513a  vmovaps [rsp+0x30], xmm3
000071409bfd5140  vmovaps [rsp+0x40], xmm4
000071409bfd5146  vmovaps [rsp+0x50], xmm5
000071409bfd514c  vmovaps [rsp+0x60], xmm6
000071409bfd5152  vmovaps [rsp+0x70], xmm7
000071409bfd5158  vmovaps [rsp+0x80], xmm8
000071409bfd5161  vmovaps [rsp+0x90], xmm9
000071409bfd516a  vmovaps [rsp+0xA0], xmm11
000071409bfd5173  vmovaps [rsp+0xB0], xmm12
000071409bfd517c  vmovaps [rsp+0xC0], xmm13
000071409bfd5185  vmovaps [rsp+0xD0], xmm14
000071409bfd518e  vmovaps [rsp+0xE0], xmm15
000071409bfd5197  sub rsp, 0x40
000071409bfd519b  lea rdi, [rsp]
000071409bfd519f  lea rsi, [rsp+0x10]
000071409bfd51a4  lea rdx, [rsp+0x20]
000071409bfd51a9  lea rcx, [rsp+0x30]
000071409bfd51ae  mov r8d, 0x00
000071409bfd51b4  lea r9, [r15+0x3A8]
000071409bfd51bb  movaps [rdi], xmm10
000071409bfd51bf  movaps [rsi], xmm9
000071409bfd51c3  movaps [rdx], xmm13
000071409bfd51c7  movaps [rcx], xmm15
000071409bfd51cb  mov rax, 0x6219BEBC2A50
000071409bfd51d5  call rax
000071409bfd51d7  movaps xmm10, [rsp]
000071409bfd51dc  add rsp, 0x40
000071409bfd51e0  vmovaps xmm0, [rsp]
000071409bfd51e5  vmovaps xmm1, [rsp+0x10]
000071409bfd51eb  vmovaps xmm2, [rsp+0x20]
000071409bfd51f1  vmovaps xmm3, [rsp+0x30]
000071409bfd51f7  vmovaps xmm4, [rsp+0x40]
000071409bfd51fd  vmovaps xmm5, [rsp+0x50]
000071409bfd5203  vmovaps xmm6, [rsp+0x60]
000071409bfd5209  vmovaps xmm7, [rsp+0x70]
000071409bfd520f  vmovaps xmm8, [rsp+0x80]
000071409bfd5218  vmovaps xmm9, [rsp+0x90]
000071409bfd5221  vmovaps xmm11, [rsp+0xA0]
000071409bfd522a  vmovaps xmm12, [rsp+0xB0]
000071409bfd5233  vmovaps xmm13, [rsp+0xC0]
000071409bfd523c  vmovaps xmm14, [rsp+0xD0]
000071409bfd5245  vmovaps xmm15, [rsp+0xE0]
000071409bfd524e  add rsp, 0xF0
000071409bfd5255  pop r11
000071409bfd5257  pop r10
000071409bfd5259  pop r9
000071409bfd525b  pop r8
000071409bfd525d  pop rsi
000071409bfd525e  pop rdi
000071409bfd525f  pop rdx
000071409bfd5260  pop rcx
000071409bfd5261  pop rax
000071409bfd5262  add rsp, 0x08
000071409bfd5266  jmp 0x000071409BFD2FCD
000071409bfd526b  sub rsp, 0x08
000071409bfd526f  push rax
000071409bfd5270  push rcx
000071409bfd5271  push rdx
000071409bfd5272  push rdi
000071409bfd5273  push rsi
000071409bfd5274  push r8
000071409bfd5276  push r9
000071409bfd5278  push r10
000071409bfd527a  push r11
000071409bfd527c  sub rsp, 0xF0
000071409bfd5283  vmovaps [rsp], xmm0
000071409bfd5288  vmovaps [rsp+0x10], xmm1
000071409bfd528e  vmovaps [rsp+0x20], xmm2
000071409bfd5294  vmovaps [rsp+0x30], xmm3
000071409bfd529a  vmovaps [rsp+0x40], xmm4
000071409bfd52a0  vmovaps [rsp+0x50], xmm5
000071409bfd52a6  vmovaps [rsp+0x60], xmm6
000071409bfd52ac  vmovaps [rsp+0x70], xmm7
000071409bfd52b2  vmovaps [rsp+0x80], xmm8
000071409bfd52bb  vmovaps [rsp+0x90], xmm9
000071409bfd52c4  vmovaps [rsp+0xA0], xmm10
000071409bfd52cd  vmovaps [rsp+0xB0], xmm11
000071409bfd52d6  vmovaps [rsp+0xC0], xmm12
000071409bfd52df  vmovaps [rsp+0xD0], xmm14
000071409bfd52e8  vmovaps [rsp+0xE0], xmm15
000071409bfd52f1  sub rsp, 0x40
000071409bfd52f5  lea rdi, [rsp]
000071409bfd52f9  lea rsi, [rsp+0x10]
000071409bfd52fe  lea rdx, [rsp+0x20]
000071409bfd5303  lea rcx, [rsp+0x30]
000071409bfd5308  mov r8d, 0x00
000071409bfd530e  lea r9, [r15+0x3A8]
000071409bfd5315  movaps [rdi], xmm13
000071409bfd5319  movaps [rsi], xmm12
000071409bfd531d  movaps [rdx], xmm4
000071409bfd5320  movaps [rcx], xmm15
000071409bfd5324  mov rax, 0x6219BEBC2A50
000071409bfd532e  call rax
000071409bfd5330  movaps xmm13, [rsp]
000071409bfd5335  add rsp, 0x40
000071409bfd5339  vmovaps xmm0, [rsp]
000071409bfd533e  vmovaps xmm1, [rsp+0x10]
000071409bfd5344  vmovaps xmm2, [rsp+0x20]
000071409bfd534a  vmovaps xmm3, [rsp+0x30]
000071409bfd5350  vmovaps xmm4, [rsp+0x40]
000071409bfd5356  vmovaps xmm5, [rsp+0x50]
000071409bfd535c  vmovaps xmm6, [rsp+0x60]
000071409bfd5362  vmovaps xmm7, [rsp+0x70]
000071409bfd5368  vmovaps xmm8, [rsp+0x80]
000071409bfd5371  vmovaps xmm9, [rsp+0x90]
000071409bfd537a  vmovaps xmm10, [rsp+0xA0]
000071409bfd5383  vmovaps xmm11, [rsp+0xB0]
000071409bfd538c  vmovaps xmm12, [rsp+0xC0]
000071409bfd5395  vmovaps xmm14, [rsp+0xD0]
000071409bfd539e  vmovaps xmm15, [rsp+0xE0]
000071409bfd53a7  add rsp, 0xF0
000071409bfd53ae  pop r11
000071409bfd53b0  pop r10
000071409bfd53b2  pop r9
000071409bfd53b4  pop r8
000071409bfd53b6  pop rsi
000071409bfd53b7  pop rdi
000071409bfd53b8  pop rdx
000071409bfd53b9  pop rcx
000071409bfd53ba  pop rax
000071409bfd53bb  add rsp, 0x08
000071409bfd53bf  jmp 0x000071409BFD2FF6
000071409bfd53c4  sub rsp, 0x08
000071409bfd53c8  push rax
000071409bfd53c9  push rcx
000071409bfd53ca  push rdx
000071409bfd53cb  push rdi
000071409bfd53cc  push rsi
000071409bfd53cd  push r8
000071409bfd53cf  push r9
000071409bfd53d1  push r10
000071409bfd53d3  push r11
000071409bfd53d5  sub rsp, 0xF0
000071409bfd53dc  vmovaps [rsp], xmm0
000071409bfd53e1  vmovaps [rsp+0x10], xmm1
000071409bfd53e7  vmovaps [rsp+0x20], xmm2
000071409bfd53ed  vmovaps [rsp+0x30], xmm3
000071409bfd53f3  vmovaps [rsp+0x40], xmm4
000071409bfd53f9  vmovaps [rsp+0x50], xmm5
000071409bfd53ff  vmovaps [rsp+0x60], xmm6
000071409bfd5405  vmovaps [rsp+0x70], xmm7
000071409bfd540b  vmovaps [rsp+0x80], xmm8
000071409bfd5414  vmovaps [rsp+0x90], xmm9
000071409bfd541d  vmovaps [rsp+0xA0], xmm10
000071409bfd5426  vmovaps [rsp+0xB0], xmm11
000071409bfd542f  vmovaps [rsp+0xC0], xmm13
000071409bfd5438  vmovaps [rsp+0xD0], xmm14
000071409bfd5441  vmovaps [rsp+0xE0], xmm15
000071409bfd544a  sub rsp, 0x40
000071409bfd544e  lea rdi, [rsp]
000071409bfd5452  lea rsi, [rsp+0x10]
000071409bfd5457  lea rdx, [rsp+0x20]
000071409bfd545c  lea rcx, [rsp+0x30]
000071409bfd5461  mov r8d, 0x00
000071409bfd5467  lea r9, [r15+0x3A8]
000071409bfd546e  movaps [rdi], xmm12
000071409bfd5472  movaps [rsi], xmm7
000071409bfd5475  movaps [rdx], xmm1
000071409bfd5478  movaps [rcx], xmm15
000071409bfd547c  mov rax, 0x6219BEBC2A50
000071409bfd5486  call rax
000071409bfd5488  movaps xmm12, [rsp]
000071409bfd548d  add rsp, 0x40
000071409bfd5491  vmovaps xmm0, [rsp]
000071409bfd5496  vmovaps xmm1, [rsp+0x10]
000071409bfd549c  vmovaps xmm2, [rsp+0x20]
000071409bfd54a2  vmovaps xmm3, [rsp+0x30]
000071409bfd54a8  vmovaps xmm4, [rsp+0x40]
000071409bfd54ae  vmovaps xmm5, [rsp+0x50]
000071409bfd54b4  vmovaps xmm6, [rsp+0x60]
000071409bfd54ba  vmovaps xmm7, [rsp+0x70]
000071409bfd54c0  vmovaps xmm8, [rsp+0x80]
000071409bfd54c9  vmovaps xmm9, [rsp+0x90]
000071409bfd54d2  vmovaps xmm10, [rsp+0xA0]
000071409bfd54db  vmovaps xmm11, [rsp+0xB0]
000071409bfd54e4  vmovaps xmm13, [rsp+0xC0]
000071409bfd54ed  vmovaps xmm14, [rsp+0xD0]
000071409bfd54f6  vmovaps xmm15, [rsp+0xE0]
000071409bfd54ff  add rsp, 0xF0
000071409bfd5506  pop r11
000071409bfd5508  pop r10
000071409bfd550a  pop r9
000071409bfd550c  pop r8
000071409bfd550e  pop rsi
000071409bfd550f  pop rdi
000071409bfd5510  pop rdx
000071409bfd5511  pop rcx
000071409bfd5512  pop rax
000071409bfd5513  add rsp, 0x08
000071409bfd5517  jmp 0x000071409BFD301F
000071409bfd551c  call 0x000071409BDFF430
000071409bfd5521  jmp 0x000071409BFD3029
000071409bfd5526  call 0x000071409BE0E760
000071409bfd552b  jmp 0x000071409BFD3033
000071409bfd5530  sub rsp, 0x08
000071409bfd5534  push rax
000071409bfd5535  push rcx
000071409bfd5536  push rdx
000071409bfd5537  push rdi
000071409bfd5538  push rsi
000071409bfd5539  push r8
000071409bfd553b  push r9
000071409bfd553d  push r10
000071409bfd553f  push r11
000071409bfd5541  sub rsp, 0xF0
000071409bfd5548  vmovaps [rsp], xmm0
000071409bfd554d  vmovaps [rsp+0x10], xmm1
000071409bfd5553  vmovaps [rsp+0x20], xmm2
000071409bfd5559  vmovaps [rsp+0x30], xmm3
000071409bfd555f  vmovaps [rsp+0x40], xmm4
000071409bfd5565  vmovaps [rsp+0x50], xmm5
000071409bfd556b  vmovaps [rsp+0x60], xmm6
000071409bfd5571  vmovaps [rsp+0x70], xmm8
000071409bfd5577  vmovaps [rsp+0x80], xmm9
000071409bfd5580  vmovaps [rsp+0x90], xmm10
000071409bfd5589  vmovaps [rsp+0xA0], xmm11
000071409bfd5592  vmovaps [rsp+0xB0], xmm12
000071409bfd559b  vmovaps [rsp+0xC0], xmm13
000071409bfd55a4  vmovaps [rsp+0xD0], xmm14
000071409bfd55ad  vmovaps [rsp+0xE0], xmm15
000071409bfd55b6  sub rsp, 0x40
000071409bfd55ba  lea rdi, [rsp]
000071409bfd55be  lea rsi, [rsp+0x10]
000071409bfd55c3  lea rdx, [rsp+0x20]
000071409bfd55c8  lea rcx, [rsp+0x30]
000071409bfd55cd  mov r8d, 0x00
000071409bfd55d3  lea r9, [r15+0x3A8]
000071409bfd55da  movaps [rdi], xmm7
000071409bfd55dd  movaps [rsi], xmm6
000071409bfd55e0  movaps [rdx], xmm8
000071409bfd55e4  movaps [rcx], xmm9
000071409bfd55e8  mov rax, 0x6219BEBC2A50
000071409bfd55f2  call rax
000071409bfd55f4  movaps xmm7, [rsp]
000071409bfd55f8  add rsp, 0x40
000071409bfd55fc  vmovaps xmm0, [rsp]
000071409bfd5601  vmovaps xmm1, [rsp+0x10]
000071409bfd5607  vmovaps xmm2, [rsp+0x20]
000071409bfd560d  vmovaps xmm3, [rsp+0x30]
000071409bfd5613  vmovaps xmm4, [rsp+0x40]
000071409bfd5619  vmovaps xmm5, [rsp+0x50]
000071409bfd561f  vmovaps xmm6, [rsp+0x60]
000071409bfd5625  vmovaps xmm8, [rsp+0x70]
000071409bfd562b  vmovaps xmm9, [rsp+0x80]
000071409bfd5634  vmovaps xmm10, [rsp+0x90]
000071409bfd563d  vmovaps xmm11, [rsp+0xA0]
000071409bfd5646  vmovaps xmm12, [rsp+0xB0]
000071409bfd564f  vmovaps xmm13, [rsp+0xC0]
000071409bfd5658  vmovaps xmm14, [rsp+0xD0]
000071409bfd5661  vmovaps xmm15, [rsp+0xE0]
000071409bfd566a  add rsp, 0xF0
000071409bfd5671  pop r11
000071409bfd5673  pop r10
000071409bfd5675  pop r9
000071409bfd5677  pop r8
000071409bfd5679  pop rsi
000071409bfd567a  pop rdi
000071409bfd567b  pop rdx
000071409bfd567c  pop rcx
000071409bfd567d  pop rax
000071409bfd567e  add rsp, 0x08
000071409bfd5682  jmp 0x000071409BFD305D
000071409bfd5687  sub rsp, 0x08
000071409bfd568b  push rax
000071409bfd568c  push rcx
000071409bfd568d  push rdx
000071409bfd568e  push rdi
000071409bfd568f  push rsi
000071409bfd5690  push r8
000071409bfd5692  push r9
000071409bfd5694  push r10
000071409bfd5696  push r11
000071409bfd5698  sub rsp, 0xF0
000071409bfd569f  vmovaps [rsp], xmm0
000071409bfd56a4  vmovaps [rsp+0x10], xmm1
000071409bfd56aa  vmovaps [rsp+0x20], xmm2
000071409bfd56b0  vmovaps [rsp+0x30], xmm3
000071409bfd56b6  vmovaps [rsp+0x40], xmm4
000071409bfd56bc  vmovaps [rsp+0x50], xmm5
000071409bfd56c2  vmovaps [rsp+0x60], xmm6
000071409bfd56c8  vmovaps [rsp+0x70], xmm7
000071409bfd56ce  vmovaps [rsp+0x80], xmm9
000071409bfd56d7  vmovaps [rsp+0x90], xmm10
000071409bfd56e0  vmovaps [rsp+0xA0], xmm11
000071409bfd56e9  vmovaps [rsp+0xB0], xmm12
000071409bfd56f2  vmovaps [rsp+0xC0], xmm13
000071409bfd56fb  vmovaps [rsp+0xD0], xmm14
000071409bfd5704  vmovaps [rsp+0xE0], xmm15
000071409bfd570d  sub rsp, 0x40
000071409bfd5711  lea rdi, [rsp]
000071409bfd5715  lea rsi, [rsp+0x10]
000071409bfd571a  lea rdx, [rsp+0x20]
000071409bfd571f  lea rcx, [rsp+0x30]
000071409bfd5724  mov r8d, 0x00
000071409bfd572a  lea r9, [r15+0x3A8]
000071409bfd5731  movaps [rdi], xmm8
000071409bfd5735  movaps [rsi], xmm10
000071409bfd5739  movaps [rdx], xmm14
000071409bfd573d  movaps [rcx], xmm9
000071409bfd5741  mov rax, 0x6219BEBC2A50
000071409bfd574b  call rax
000071409bfd574d  movaps xmm8, [rsp]
000071409bfd5752  add rsp, 0x40
000071409bfd5756  vmovaps xmm0, [rsp]
000071409bfd575b  vmovaps xmm1, [rsp+0x10]
000071409bfd5761  vmovaps xmm2, [rsp+0x20]
000071409bfd5767  vmovaps xmm3, [rsp+0x30]
000071409bfd576d  vmovaps xmm4, [rsp+0x40]
000071409bfd5773  vmovaps xmm5, [rsp+0x50]
000071409bfd5779  vmovaps xmm6, [rsp+0x60]
000071409bfd577f  vmovaps xmm7, [rsp+0x70]
000071409bfd5785  vmovaps xmm9, [rsp+0x80]
000071409bfd578e  vmovaps xmm10, [rsp+0x90]
000071409bfd5797  vmovaps xmm11, [rsp+0xA0]
000071409bfd57a0  vmovaps xmm12, [rsp+0xB0]
000071409bfd57a9  vmovaps xmm13, [rsp+0xC0]
000071409bfd57b2  vmovaps xmm14, [rsp+0xD0]
000071409bfd57bb  vmovaps xmm15, [rsp+0xE0]
000071409bfd57c4  add rsp, 0xF0
000071409bfd57cb  pop r11
000071409bfd57cd  pop r10
000071409bfd57cf  pop r9
000071409bfd57d1  pop r8
000071409bfd57d3  pop rsi
000071409bfd57d4  pop rdi
000071409bfd57d5  pop rdx
000071409bfd57d6  pop rcx
000071409bfd57d7  pop rax
000071409bfd57d8  add rsp, 0x08
000071409bfd57dc  jmp 0x000071409BFD3083
000071409bfd57e1  sub rsp, 0x08
000071409bfd57e5  push rax
000071409bfd57e6  push rcx
000071409bfd57e7  push rdx
000071409bfd57e8  push rdi
000071409bfd57e9  push rsi
000071409bfd57ea  push r8
000071409bfd57ec  push r9
000071409bfd57ee  push r10
000071409bfd57f0  push r11
000071409bfd57f2  sub rsp, 0xF0
000071409bfd57f9  vmovaps [rsp], xmm0
000071409bfd57fe  vmovaps [rsp+0x10], xmm1
000071409bfd5804  vmovaps [rsp+0x20], xmm2
000071409bfd580a  vmovaps [rsp+0x30], xmm3
000071409bfd5810  vmovaps [rsp+0x40], xmm4
000071409bfd5816  vmovaps [rsp+0x50], xmm5
000071409bfd581c  vmovaps [rsp+0x60], xmm6
000071409bfd5822  vmovaps [rsp+0x70], xmm7
000071409bfd5828  vmovaps [rsp+0x80], xmm8
000071409bfd5831  vmovaps [rsp+0x90], xmm9
000071409bfd583a  vmovaps [rsp+0xA0], xmm11
000071409bfd5843  vmovaps [rsp+0xB0], xmm12
000071409bfd584c  vmovaps [rsp+0xC0], xmm13
000071409bfd5855  vmovaps [rsp+0xD0], xmm14
000071409bfd585e  vmovaps [rsp+0xE0], xmm15
000071409bfd5867  sub rsp, 0x40
000071409bfd586b  lea rdi, [rsp]
000071409bfd586f  lea rsi, [rsp+0x10]
000071409bfd5874  lea rdx, [rsp+0x20]
000071409bfd5879  lea rcx, [rsp+0x30]
000071409bfd587e  mov r8d, 0x00
000071409bfd5884  lea r9, [r15+0x3A8]
000071409bfd588b  movaps [rdi], xmm10
000071409bfd588f  movaps [rsi], xmm13
000071409bfd5893  movaps [rdx], xmm11
000071409bfd5897  movaps [rcx], xmm14
000071409bfd589b  mov rax, 0x6219BEBC2A50
000071409bfd58a5  call rax
000071409bfd58a7  movaps xmm10, [rsp]
000071409bfd58ac  add rsp, 0x40
000071409bfd58b0  vmovaps xmm0, [rsp]
000071409bfd58b5  vmovaps xmm1, [rsp+0x10]
000071409bfd58bb  vmovaps xmm2, [rsp+0x20]
000071409bfd58c1  vmovaps xmm3, [rsp+0x30]
000071409bfd58c7  vmovaps xmm4, [rsp+0x40]
000071409bfd58cd  vmovaps xmm5, [rsp+0x50]
000071409bfd58d3  vmovaps xmm6, [rsp+0x60]
000071409bfd58d9  vmovaps xmm7, [rsp+0x70]
000071409bfd58df  vmovaps xmm8, [rsp+0x80]
000071409bfd58e8  vmovaps xmm9, [rsp+0x90]
000071409bfd58f1  vmovaps xmm11, [rsp+0xA0]
000071409bfd58fa  vmovaps xmm12, [rsp+0xB0]
000071409bfd5903  vmovaps xmm13, [rsp+0xC0]
000071409bfd590c  vmovaps xmm14, [rsp+0xD0]
000071409bfd5915  vmovaps xmm15, [rsp+0xE0]
000071409bfd591e  add rsp, 0xF0
000071409bfd5925  pop r11
000071409bfd5927  pop r10
000071409bfd5929  pop r9
000071409bfd592b  pop r8
000071409bfd592d  pop rsi
000071409bfd592e  pop rdi
000071409bfd592f  pop rdx
000071409bfd5930  pop rcx
000071409bfd5931  pop rax
000071409bfd5932  add rsp, 0x08
000071409bfd5936  jmp 0x000071409BFD30A9
000071409bfd593b  sub rsp, 0x08
000071409bfd593f  push rax
000071409bfd5940  push rcx
000071409bfd5941  push rdx
000071409bfd5942  push rdi
000071409bfd5943  push rsi
000071409bfd5944  push r8
000071409bfd5946  push r9
000071409bfd5948  push r10
000071409bfd594a  push r11
000071409bfd594c  sub rsp, 0xF0
000071409bfd5953  vmovaps [rsp], xmm0
000071409bfd5958  vmovaps [rsp+0x10], xmm1
000071409bfd595e  vmovaps [rsp+0x20], xmm2
000071409bfd5964  vmovaps [rsp+0x30], xmm3
000071409bfd596a  vmovaps [rsp+0x40], xmm4
000071409bfd5970  vmovaps [rsp+0x50], xmm5
000071409bfd5976  vmovaps [rsp+0x60], xmm6
000071409bfd597c  vmovaps [rsp+0x70], xmm7
000071409bfd5982  vmovaps [rsp+0x80], xmm8
000071409bfd598b  vmovaps [rsp+0x90], xmm9
000071409bfd5994  vmovaps [rsp+0xA0], xmm10
000071409bfd599d  vmovaps [rsp+0xB0], xmm11
000071409bfd59a6  vmovaps [rsp+0xC0], xmm12
000071409bfd59af  vmovaps [rsp+0xD0], xmm14
000071409bfd59b8  vmovaps [rsp+0xE0], xmm15
000071409bfd59c1  sub rsp, 0x40
000071409bfd59c5  lea rdi, [rsp]
000071409bfd59c9  lea rsi, [rsp+0x10]
000071409bfd59ce  lea rdx, [rsp+0x20]
000071409bfd59d3  lea rcx, [rsp+0x30]
000071409bfd59d8  mov r8d, 0x00
000071409bfd59de  lea r9, [r15+0x3A8]
000071409bfd59e5  movaps [rdi], xmm13
000071409bfd59e9  movaps [rsi], xmm12
000071409bfd59ed  movaps [rdx], xmm15
000071409bfd59f1  movaps [rcx], xmm14
000071409bfd59f5  mov rax, 0x6219BEBC2A50
000071409bfd59ff  call rax
000071409bfd5a01  movaps xmm13, [rsp]
000071409bfd5a06  add rsp, 0x40
000071409bfd5a0a  vmovaps xmm0, [rsp]
000071409bfd5a0f  vmovaps xmm1, [rsp+0x10]
000071409bfd5a15  vmovaps xmm2, [rsp+0x20]
000071409bfd5a1b  vmovaps xmm3, [rsp+0x30]
000071409bfd5a21  vmovaps xmm4, [rsp+0x40]
000071409bfd5a27  vmovaps xmm5, [rsp+0x50]
000071409bfd5a2d  vmovaps xmm6, [rsp+0x60]
000071409bfd5a33  vmovaps xmm7, [rsp+0x70]
000071409bfd5a39  vmovaps xmm8, [rsp+0x80]
000071409bfd5a42  vmovaps xmm9, [rsp+0x90]
000071409bfd5a4b  vmovaps xmm10, [rsp+0xA0]
000071409bfd5a54  vmovaps xmm11, [rsp+0xB0]
000071409bfd5a5d  vmovaps xmm12, [rsp+0xC0]
000071409bfd5a66  vmovaps xmm14, [rsp+0xD0]
000071409bfd5a6f  vmovaps xmm15, [rsp+0xE0]
000071409bfd5a78  add rsp, 0xF0
000071409bfd5a7f  pop r11
000071409bfd5a81  pop r10
000071409bfd5a83  pop r9
000071409bfd5a85  pop r8
000071409bfd5a87  pop rsi
000071409bfd5a88  pop rdi
000071409bfd5a89  pop rdx
000071409bfd5a8a  pop rcx
000071409bfd5a8b  pop rax
000071409bfd5a8c  add rsp, 0x08
000071409bfd5a90  jmp 0x000071409BFD30CF
000071409bfd5a95  call 0x000071409BE0E760
000071409bfd5a9a  jmp 0x000071409BFD30DC
000071409bfd5a9f  call 0x000071409BE0D4E0
000071409bfd5aa4  jmp 0x000071409BFD30E9
000071409bfd5aa9  sub rsp, 0x08
000071409bfd5aad  push rax
000071409bfd5aae  push rcx
000071409bfd5aaf  push rdx
000071409bfd5ab0  push rdi
000071409bfd5ab1  push rsi
000071409bfd5ab2  push r8
000071409bfd5ab4  push r9
000071409bfd5ab6  push r10
000071409bfd5ab8  push r11
000071409bfd5aba  sub rsp, 0xF0
000071409bfd5ac1  vmovaps [rsp], xmm0
000071409bfd5ac6  vmovaps [rsp+0x10], xmm1
000071409bfd5acc  vmovaps [rsp+0x20], xmm2
000071409bfd5ad2  vmovaps [rsp+0x30], xmm3
000071409bfd5ad8  vmovaps [rsp+0x40], xmm4
000071409bfd5ade  vmovaps [rsp+0x50], xmm5
000071409bfd5ae4  vmovaps [rsp+0x60], xmm6
000071409bfd5aea  vmovaps [rsp+0x70], xmm7
000071409bfd5af0  vmovaps [rsp+0x80], xmm8
000071409bfd5af9  vmovaps [rsp+0x90], xmm9
000071409bfd5b02  vmovaps [rsp+0xA0], xmm10
000071409bfd5b0b  vmovaps [rsp+0xB0], xmm12
000071409bfd5b14  vmovaps [rsp+0xC0], xmm13
000071409bfd5b1d  vmovaps [rsp+0xD0], xmm14
000071409bfd5b26  vmovaps [rsp+0xE0], xmm15
000071409bfd5b2f  sub rsp, 0x40
000071409bfd5b33  lea rdi, [rsp]
000071409bfd5b37  lea rsi, [rsp+0x10]
000071409bfd5b3c  lea rdx, [rsp+0x20]
000071409bfd5b41  lea rcx, [rsp+0x30]
000071409bfd5b46  mov r8d, 0x00
000071409bfd5b4c  lea r9, [r15+0x3A8]
000071409bfd5b53  movaps [rdi], xmm11
000071409bfd5b57  movaps [rsi], xmm7
000071409bfd5b5a  movaps [rdx], xmm1
000071409bfd5b5d  movaps [rcx], xmm12
000071409bfd5b61  mov rax, 0x6219BEBC2A50
000071409bfd5b6b  call rax
000071409bfd5b6d  movaps xmm11, [rsp]
000071409bfd5b72  add rsp, 0x40
000071409bfd5b76  vmovaps xmm0, [rsp]
000071409bfd5b7b  vmovaps xmm1, [rsp+0x10]
000071409bfd5b81  vmovaps xmm2, [rsp+0x20]
000071409bfd5b87  vmovaps xmm3, [rsp+0x30]
000071409bfd5b8d  vmovaps xmm4, [rsp+0x40]
000071409bfd5b93  vmovaps xmm5, [rsp+0x50]
000071409bfd5b99  vmovaps xmm6, [rsp+0x60]
000071409bfd5b9f  vmovaps xmm7, [rsp+0x70]
000071409bfd5ba5  vmovaps xmm8, [rsp+0x80]
000071409bfd5bae  vmovaps xmm9, [rsp+0x90]
000071409bfd5bb7  vmovaps xmm10, [rsp+0xA0]
000071409bfd5bc0  vmovaps xmm12, [rsp+0xB0]
000071409bfd5bc9  vmovaps xmm13, [rsp+0xC0]
000071409bfd5bd2  vmovaps xmm14, [rsp+0xD0]
000071409bfd5bdb  vmovaps xmm15, [rsp+0xE0]
000071409bfd5be4  add rsp, 0xF0
000071409bfd5beb  pop r11
000071409bfd5bed  pop r10
000071409bfd5bef  pop r9
000071409bfd5bf1  pop r8
000071409bfd5bf3  pop rsi
000071409bfd5bf4  pop rdi
000071409bfd5bf5  pop rdx
000071409bfd5bf6  pop rcx
000071409bfd5bf7  pop rax
000071409bfd5bf8  add rsp, 0x08
000071409bfd5bfc  jmp 0x000071409BFD3122
000071409bfd5c01  call 0x000071409BDFF430
000071409bfd5c06  jmp 0x000071409BFD3134
000071409bfd5c0b  sub rsp, 0x08
000071409bfd5c0f  push rax
000071409bfd5c10  push rcx
000071409bfd5c11  push rdx
000071409bfd5c12  push rdi
000071409bfd5c13  push rsi
000071409bfd5c14  push r8
000071409bfd5c16  push r9
000071409bfd5c18  push r10
000071409bfd5c1a  push r11
000071409bfd5c1c  sub rsp, 0xF0
000071409bfd5c23  vmovaps [rsp], xmm0
000071409bfd5c28  vmovaps [rsp+0x10], xmm1
000071409bfd5c2e  vmovaps [rsp+0x20], xmm2
000071409bfd5c34  vmovaps [rsp+0x30], xmm3
000071409bfd5c3a  vmovaps [rsp+0x40], xmm4
000071409bfd5c40  vmovaps [rsp+0x50], xmm5
000071409bfd5c46  vmovaps [rsp+0x60], xmm6
000071409bfd5c4c  vmovaps [rsp+0x70], xmm7
000071409bfd5c52  vmovaps [rsp+0x80], xmm8
000071409bfd5c5b  vmovaps [rsp+0x90], xmm10
000071409bfd5c64  vmovaps [rsp+0xA0], xmm11
000071409bfd5c6d  vmovaps [rsp+0xB0], xmm12
000071409bfd5c76  vmovaps [rsp+0xC0], xmm13
000071409bfd5c7f  vmovaps [rsp+0xD0], xmm14
000071409bfd5c88  vmovaps [rsp+0xE0], xmm15
000071409bfd5c91  sub rsp, 0x40
000071409bfd5c95  lea rdi, [rsp]
000071409bfd5c99  lea rsi, [rsp+0x10]
000071409bfd5c9e  lea rdx, [rsp+0x20]
000071409bfd5ca3  lea rcx, [rsp+0x30]
000071409bfd5ca8  mov r8d, 0x00
000071409bfd5cae  lea r9, [r15+0x3A8]
000071409bfd5cb5  movaps [rdi], xmm9
000071409bfd5cb9  movaps [rsi], xmm8
000071409bfd5cbd  movaps [rdx], xmm14
000071409bfd5cc1  movaps [rcx], xmm12
000071409bfd5cc5  mov rax, 0x6219BEBC2A50
000071409bfd5ccf  call rax
000071409bfd5cd1  movaps xmm9, [rsp]
000071409bfd5cd6  add rsp, 0x40
000071409bfd5cda  vmovaps xmm0, [rsp]
000071409bfd5cdf  vmovaps xmm1, [rsp+0x10]
000071409bfd5ce5  vmovaps xmm2, [rsp+0x20]
000071409bfd5ceb  vmovaps xmm3, [rsp+0x30]
000071409bfd5cf1  vmovaps xmm4, [rsp+0x40]
000071409bfd5cf7  vmovaps xmm5, [rsp+0x50]
000071409bfd5cfd  vmovaps xmm6, [rsp+0x60]
000071409bfd5d03  vmovaps xmm7, [rsp+0x70]
000071409bfd5d09  vmovaps xmm8, [rsp+0x80]
000071409bfd5d12  vmovaps xmm10, [rsp+0x90]
000071409bfd5d1b  vmovaps xmm11, [rsp+0xA0]
000071409bfd5d24  vmovaps xmm12, [rsp+0xB0]
000071409bfd5d2d  vmovaps xmm13, [rsp+0xC0]
000071409bfd5d36  vmovaps xmm14, [rsp+0xD0]
000071409bfd5d3f  vmovaps xmm15, [rsp+0xE0]
000071409bfd5d48  add rsp, 0xF0
000071409bfd5d4f  pop r11
000071409bfd5d51  pop r10
000071409bfd5d53  pop r9
000071409bfd5d55  pop r8
000071409bfd5d57  pop rsi
000071409bfd5d58  pop rdi
000071409bfd5d59  pop rdx
000071409bfd5d5a  pop rcx
000071409bfd5d5b  pop rax
000071409bfd5d5c  add rsp, 0x08
000071409bfd5d60  jmp 0x000071409BFD3165
000071409bfd5d65  sub rsp, 0x08
000071409bfd5d69  push rax
000071409bfd5d6a  push rcx
000071409bfd5d6b  push rdx
000071409bfd5d6c  push rdi
000071409bfd5d6d  push rsi
000071409bfd5d6e  push r8
000071409bfd5d70  push r9
000071409bfd5d72  push r10
000071409bfd5d74  push r11
000071409bfd5d76  sub rsp, 0xF0
000071409bfd5d7d  vmovaps [rsp], xmm0
000071409bfd5d82  vmovaps [rsp+0x10], xmm1
000071409bfd5d88  vmovaps [rsp+0x20], xmm2
000071409bfd5d8e  vmovaps [rsp+0x30], xmm3
000071409bfd5d94  vmovaps [rsp+0x40], xmm4
000071409bfd5d9a  vmovaps [rsp+0x50], xmm5
000071409bfd5da0  vmovaps [rsp+0x60], xmm6
000071409bfd5da6  vmovaps [rsp+0x70], xmm7
000071409bfd5dac  vmovaps [rsp+0x80], xmm8
000071409bfd5db5  vmovaps [rsp+0x90], xmm9
000071409bfd5dbe  vmovaps [rsp+0xA0], xmm10
000071409bfd5dc7  vmovaps [rsp+0xB0], xmm11
000071409bfd5dd0  vmovaps [rsp+0xC0], xmm13
000071409bfd5dd9  vmovaps [rsp+0xD0], xmm14
000071409bfd5de2  vmovaps [rsp+0xE0], xmm15
000071409bfd5deb  sub rsp, 0x40
000071409bfd5def  lea rdi, [rsp]
000071409bfd5df3  lea rsi, [rsp+0x10]
000071409bfd5df8  lea rdx, [rsp+0x20]
000071409bfd5dfd  lea rcx, [rsp+0x30]
000071409bfd5e02  mov r8d, 0x00
000071409bfd5e08  lea r9, [r15+0x3A8]
000071409bfd5e0f  movaps [rdi], xmm12
000071409bfd5e13  movaps [rsi], xmm10
000071409bfd5e17  movaps [rdx], xmm15
000071409bfd5e1b  movaps [rcx], xmm14
000071409bfd5e1f  mov rax, 0x6219BEBC2A50
000071409bfd5e29  call rax
000071409bfd5e2b  movaps xmm12, [rsp]
000071409bfd5e30  add rsp, 0x40
000071409bfd5e34  vmovaps xmm0, [rsp]
000071409bfd5e39  vmovaps xmm1, [rsp+0x10]
000071409bfd5e3f  vmovaps xmm2, [rsp+0x20]
000071409bfd5e45  vmovaps xmm3, [rsp+0x30]
000071409bfd5e4b  vmovaps xmm4, [rsp+0x40]
000071409bfd5e51  vmovaps xmm5, [rsp+0x50]
000071409bfd5e57  vmovaps xmm6, [rsp+0x60]
000071409bfd5e5d  vmovaps xmm7, [rsp+0x70]
000071409bfd5e63  vmovaps xmm8, [rsp+0x80]
000071409bfd5e6c  vmovaps xmm9, [rsp+0x90]
000071409bfd5e75  vmovaps xmm10, [rsp+0xA0]
000071409bfd5e7e  vmovaps xmm11, [rsp+0xB0]
000071409bfd5e87  vmovaps xmm13, [rsp+0xC0]
000071409bfd5e90  vmovaps xmm14, [rsp+0xD0]
000071409bfd5e99  vmovaps xmm15, [rsp+0xE0]
000071409bfd5ea2  add rsp, 0xF0
000071409bfd5ea9  pop r11
000071409bfd5eab  pop r10
000071409bfd5ead  pop r9
000071409bfd5eaf  pop r8
000071409bfd5eb1  pop rsi
000071409bfd5eb2  pop rdi
000071409bfd5eb3  pop rdx
000071409bfd5eb4  pop rcx
000071409bfd5eb5  pop rax
000071409bfd5eb6  add rsp, 0x08
000071409bfd5eba  jmp 0x000071409BFD3196
000071409bfd5ebf  sub rsp, 0x08
000071409bfd5ec3  push rax
000071409bfd5ec4  push rcx
000071409bfd5ec5  push rdx
000071409bfd5ec6  push rdi
000071409bfd5ec7  push rsi
000071409bfd5ec8  push r8
000071409bfd5eca  push r9
000071409bfd5ecc  push r10
000071409bfd5ece  push r11
000071409bfd5ed0  sub rsp, 0xF0
000071409bfd5ed7  vmovaps [rsp], xmm0
000071409bfd5edc  vmovaps [rsp+0x10], xmm1
000071409bfd5ee2  vmovaps [rsp+0x20], xmm2
000071409bfd5ee8  vmovaps [rsp+0x30], xmm3
000071409bfd5eee  vmovaps [rsp+0x40], xmm4
000071409bfd5ef4  vmovaps [rsp+0x50], xmm5
000071409bfd5efa  vmovaps [rsp+0x60], xmm6
000071409bfd5f00  vmovaps [rsp+0x70], xmm7
000071409bfd5f06  vmovaps [rsp+0x80], xmm8
000071409bfd5f0f  vmovaps [rsp+0x90], xmm9
000071409bfd5f18  vmovaps [rsp+0xA0], xmm10
000071409bfd5f21  vmovaps [rsp+0xB0], xmm11
000071409bfd5f2a  vmovaps [rsp+0xC0], xmm12
000071409bfd5f33  vmovaps [rsp+0xD0], xmm13
000071409bfd5f3c  vmovaps [rsp+0xE0], xmm15
000071409bfd5f45  sub rsp, 0x40
000071409bfd5f49  lea rdi, [rsp]
000071409bfd5f4d  lea rsi, [rsp+0x10]
000071409bfd5f52  lea rdx, [rsp+0x20]
000071409bfd5f57  lea rcx, [rsp+0x30]
000071409bfd5f5c  mov r8d, 0x00
000071409bfd5f62  lea r9, [r15+0x3A8]
000071409bfd5f69  movaps [rdi], xmm14
000071409bfd5f6d  movaps [rsi], xmm13
000071409bfd5f71  movaps [rdx], xmm1
000071409bfd5f74  movaps [rcx], xmm15
000071409bfd5f78  mov rax, 0x6219BEBC2A50
000071409bfd5f82  call rax
000071409bfd5f84  movaps xmm14, [rsp]
000071409bfd5f89  add rsp, 0x40
000071409bfd5f8d  vmovaps xmm0, [rsp]
000071409bfd5f92  vmovaps xmm1, [rsp+0x10]
000071409bfd5f98  vmovaps xmm2, [rsp+0x20]
000071409bfd5f9e  vmovaps xmm3, [rsp+0x30]
000071409bfd5fa4  vmovaps xmm4, [rsp+0x40]
000071409bfd5faa  vmovaps xmm5, [rsp+0x50]
000071409bfd5fb0  vmovaps xmm6, [rsp+0x60]
000071409bfd5fb6  vmovaps xmm7, [rsp+0x70]
000071409bfd5fbc  vmovaps xmm8, [rsp+0x80]
000071409bfd5fc5  vmovaps xmm9, [rsp+0x90]
000071409bfd5fce  vmovaps xmm10, [rsp+0xA0]
000071409bfd5fd7  vmovaps xmm11, [rsp+0xB0]
000071409bfd5fe0  vmovaps xmm12, [rsp+0xC0]
000071409bfd5fe9  vmovaps xmm13, [rsp+0xD0]
000071409bfd5ff2  vmovaps xmm15, [rsp+0xE0]
000071409bfd5ffb  add rsp, 0xF0
000071409bfd6002  pop r11
000071409bfd6004  pop r10
000071409bfd6006  pop r9
000071409bfd6008  pop r8
000071409bfd600a  pop rsi
000071409bfd600b  pop rdi
000071409bfd600c  pop rdx
000071409bfd600d  pop rcx
000071409bfd600e  pop rax
000071409bfd600f  add rsp, 0x08
000071409bfd6013  jmp 0x000071409BFD31C7
000071409bfd6018  call 0x000071409BE079B0
000071409bfd601d  jmp 0x000071409BFD31DA
000071409bfd6022  call 0x000071409BE0B100
000071409bfd6027  jmp 0x000071409BFD31E5
000071409bfd602c  call 0x000071409BE09E90
000071409bfd6031  jmp 0x000071409BFD31F0
000071409bfd6036  call 0x000071409BE0D600
000071409bfd603b  jmp 0x000071409BFD31FB
000071409bfd6040  int3
000071409bfd6041  nop [rax+rax*1], ax
000071409bfd604a  nop [rax+rax*1], ax
000071409bfd6050  mov rax, [r15+0x40]
000071409bfd6054  mov r14, [r15+0x58]
000071409bfd6058  lea r12, [rax+r14*1]
000071409bfd605c  vxorps xmm1, xmm1, xmm1
000071409bfd6060  vpbroadcastq xmm1, xmm1
000071409bfd6065  vxorps xmm15, xmm15, xmm15
000071409bfd606a  vpbroadcastq xmm15, xmm15
000071409bfd606f  lea rax, [r12+0x30]
000071409bfd6074  mov r11, [r13+rax*1]
000071409bfd6079  lea rax, [r12+0x38]
000071409bfd607e  mov r10, [r13+rax*1]
000071409bfd6083  movq xmm14, r11
000071409bfd6088  movq xmm13, r10
000071409bfd608d  movq xmm14, xmm14
000071409bfd6092  movq xmm13, xmm13
000071409bfd6097  vmovaps [rsp+0x10], xmm13
000071409bfd609d  movq xmm13, xmm13
000071409bfd60a2  movaps [r15+0x270], xmm13
000071409bfd60aa  movaps xmm13, [r15+0x160]
000071409bfd60b2  vmovaps [rsp+0x20], xmm13
000071409bfd60b8  vmovaps xmm12, [rsp+0x20]
000071409bfd60be  por xmm13, xmm12
000071409bfd60c3  lea rax, [r12+0x20]
000071409bfd60c8  mov r11, [r13+rax*1]
000071409bfd60cd  lea rax, [r12+0x28]
000071409bfd60d2  mov r10, [r13+rax*1]
000071409bfd60d7  movq xmm12, r11
000071409bfd60dc  movq xmm11, r10
000071409bfd60e1  movq xmm12, xmm12
000071409bfd60e6  movq xmm11, xmm11
000071409bfd60eb  movaps xmm10, [r15+0x2D0]
000071409bfd60f3  vmovaps [rsp+0x20], xmm10
000071409bfd60f9  vmovaps xmm9, [rsp+0x20]
000071409bfd60ff  por xmm10, xmm9
000071409bfd6104  movaps xmm9, [r15+0x300]
000071409bfd610c  vmovaps [rsp+0x20], xmm9
000071409bfd6112  vmovaps xmm8, [rsp+0x20]
000071409bfd6118  por xmm9, xmm8
000071409bfd611d  movaps xmm8, [r15+0x2B0]
000071409bfd6125  vmovaps [rsp+0x20], xmm8
000071409bfd612b  vmovaps xmm7, [rsp+0x20]
000071409bfd6131  por xmm8, xmm7
000071409bfd6136  movaps xmm7, [r15+0x180]
000071409bfd613e  vmovaps [rsp+0x20], xmm7
000071409bfd6144  vmovaps xmm6, [rsp+0x20]
000071409bfd614a  por xmm7, xmm6
000071409bfd614e  lea rax, [r12+0x10]
000071409bfd6153  mov r11, [r13+rax*1]
000071409bfd6158  lea rax, [r12+0x18]
000071409bfd615d  mov r10, [r13+rax*1]
000071409bfd6162  movq xmm6, r11
000071409bfd6167  movq xmm5, r10
000071409bfd616c  movq xmm6, xmm6
000071409bfd6170  movq xmm5, xmm5
000071409bfd6174  movaps xmm4, [r15+0x200]
000071409bfd617c  vmovaps [rsp+0x20], xmm4
000071409bfd6182  vmovaps xmm3, [rsp+0x20]
000071409bfd6188  por xmm4, xmm3
000071409bfd618c  movaps xmm3, [r15+0x1F0]
000071409bfd6194  vmovaps [rsp+0x20], xmm3
000071409bfd619a  vmovaps xmm2, [rsp+0x20]
000071409bfd61a0  por xmm3, xmm2
000071409bfd61a4  movaps xmm2, [r15+0x2E0]
000071409bfd61ac  vmovaps [rsp+0x20], xmm2
000071409bfd61b2  vmovaps [rsp+0x30], xmm1
000071409bfd61b8  vmovaps xmm1, [rsp+0x20]
000071409bfd61be  por xmm2, xmm1
000071409bfd61c2  movaps xmm1, [r15+0x2A0]
000071409bfd61ca  vmovaps [rsp+0x20], xmm1
000071409bfd61d0  vmovaps [rsp+0x40], xmm15
000071409bfd61d6  vmovaps xmm15, [rsp+0x20]
000071409bfd61dc  por xmm1, xmm15
000071409bfd61e1  movaps xmm15, [r15+0x280]
000071409bfd61e9  vmovaps [rsp+0x20], xmm15
000071409bfd61ef  vmovaps [rsp+0x50], xmm1
000071409bfd61f5  vmovaps xmm1, [rsp+0x20]
000071409bfd61fb  por xmm15, xmm1
000071409bfd6200  movaps xmm1, [r15+0x1C0]
000071409bfd6208  vmovaps [rsp+0x20], xmm1
000071409bfd620e  vmovaps [rsp+0x60], xmm15
000071409bfd6214  vmovaps xmm15, [rsp+0x20]
000071409bfd621a  por xmm1, xmm15
000071409bfd621f  movaps xmm15, [r15+0x210]
000071409bfd6227  vmovaps [rsp+0x20], xmm15
000071409bfd622d  vmovaps [rsp+0x70], xmm1
000071409bfd6233  vmovaps xmm1, [rsp+0x20]
000071409bfd6239  por xmm15, xmm1
000071409bfd623e  mov rax, [r13+r12*1]
000071409bfd6243  vmovq xmm1, rax
000071409bfd6248  vpbroadcastq xmm1, xmm1
000071409bfd624d  vmovaps [rsp+0x20], xmm1
000071409bfd6253  vxorps xmm1, xmm1, xmm1
000071409bfd6257  vpbroadcastq xmm1, xmm1
000071409bfd625c  mov rax, [r15+0xF8]
000071409bfd6263  vmovaps [rsp+0x80], xmm1
000071409bfd626c  movups xmm1, [r13+rax*1]
000071409bfd6272  vmovaps [rsp+0x90], xmm1
000071409bfd627b  vxorps xmm1, xmm1, xmm1
000071409bfd627f  vpbroadcastq xmm1, xmm1
000071409bfd6284  lea r11, [r12+0x08]
000071409bfd6289  mov r12, [r13+r11*1]
000071409bfd628e  vmovaps [rsp+0xA0], xmm1
000071409bfd6297  movq xmm1, r12
000071409bfd629c  movaps [r15+0x240], xmm1
000071409bfd62a4  mov r12, [r15+0x50]
000071409bfd62a8  lea r11, [r12+r14*1]
000071409bfd62ac  mov [r15+0x60], r11
000071409bfd62b0  lea r12, [r14+0x40]
000071409bfd62b4  mov [r15+0x58], r12
000071409bfd62b8  vmovaps xmm1, [rsp+0x30]
000071409bfd62be  vmovaps [rsp+0x30], xmm15
000071409bfd62c4  vmovaps xmm15, [rsp+0x90]
000071409bfd62cd  vmovaps [rsp+0x90], xmm14
000071409bfd62d6  vmovaps xmm14, [rsp+0x20]
000071409bfd62dc  vmovaps [rsp+0x20], xmm13
000071409bfd62e2  vmovaps [rsp+0xB0], xmm12
000071409bfd62eb  movaps xmm13, xmm1
000071409bfd62ef  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd62fa  vptest xmm12, xmm12
000071409bfd62ff  jnz 0x000071409BFD6D9C
000071409bfd6305  movaps xmm1, [r15+0x250]
000071409bfd630d  vmovaps xmm15, [rsp+0x40]
000071409bfd6313  vmovaps [rsp+0x40], xmm13
000071409bfd6319  movaps xmm12, xmm15
000071409bfd631d  vfmadd231pd xmm12, xmm1, xmm14
000071409bfd6322  vcmppd xmm13, xmm12, xmm12, 0x03
000071409bfd6328  vptest xmm13, xmm13
000071409bfd632d  jnz 0x000071409BFD6EF5
000071409bfd6333  movaps xmm15, [r15+0x1E0]
000071409bfd633b  vmovaps [rsp+0xC0], xmm15
000071409bfd6344  vmovaps xmm13, [rsp+0xC0]
000071409bfd634d  por xmm15, xmm13
000071409bfd6352  movaps xmm13, [r15+0x1D0]
000071409bfd635a  vmovaps [rsp+0xC0], xmm13
000071409bfd6363  vmovaps [rsp+0xD0], xmm1
000071409bfd636c  vmovaps xmm1, [rsp+0xC0]
000071409bfd6375  por xmm13, xmm1
000071409bfd637a  movaps xmm1, [r15+0x2C0]
000071409bfd6382  vmovaps [rsp+0xC0], xmm1
000071409bfd638b  vmovaps [rsp+0xE0], xmm15
000071409bfd6394  vmovaps xmm15, [rsp+0xC0]
000071409bfd639d  por xmm1, xmm15
000071409bfd63a2  movaps xmm15, [r15+0x290]
000071409bfd63aa  vmovaps [rsp+0xC0], xmm15
000071409bfd63b3  vmovaps [rsp+0xF0], xmm1
000071409bfd63bc  vmovaps xmm1, [rsp+0xC0]
000071409bfd63c5  por xmm15, xmm1
000071409bfd63ca  movaps xmm1, [r15+0x260]
000071409bfd63d2  vmovaps [rsp+0xC0], xmm1
000071409bfd63db  vmovaps [rsp+0x100], xmm15
000071409bfd63e4  vmovaps xmm15, [rsp+0xC0]
000071409bfd63ed  por xmm1, xmm15
000071409bfd63f2  vmovaps xmm15, [rsp+0xD0]
000071409bfd63fb  vmovaps [rsp+0xC0], xmm1
000071409bfd6404  vmovaps xmm1, [rsp+0xD0]
000071409bfd640d  por xmm15, xmm1
000071409bfd6412  lea r14, [rax+0xC0]
000071409bfd6419  movups xmm1, [r13+r14*1]
000071409bfd641f  mov [rsp+0xD0], rax
000071409bfd6427  xor eax, eax
000071409bfd6429  mov r14d, 0x200
000071409bfd642f  cmp r12, r14
000071409bfd6432  cmc
000071409bfd6433  lahf
000071409bfd6434  seto al
000071409bfd6437  mov [r15+0x108], eax
000071409bfd643e  vmovaps [rsp+0x110], xmm1
000071409bfd6447  vmovaps xmm1, [rsp+0x80]
000071409bfd6450  vmovaps [rsp+0x80], xmm15
000071409bfd6459  vmovaps xmm15, [rsp+0x110]
000071409bfd6462  vmovaps [rsp+0x110], xmm13
000071409bfd646b  vmovaps [rsp+0x120], xmm12
000071409bfd6474  movaps xmm13, xmm1
000071409bfd6478  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd647d  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd6483  vptest xmm12, xmm12
000071409bfd6488  jnz 0x000071409BFD7058
000071409bfd648e  mov rax, [rsp+0xD0]
000071409bfd6496  lea r14, [rax+0xB0]
000071409bfd649d  movups xmm1, [r13+r14*1]
000071409bfd64a3  vmovaps xmm15, [rsp+0xA0]
000071409bfd64ac  vmovaps [rsp+0xA0], xmm13
000071409bfd64b5  movaps xmm12, xmm15
000071409bfd64b9  vfmadd231pd xmm12, xmm1, xmm14
000071409bfd64be  vcmppd xmm13, xmm12, xmm12, 0x03
000071409bfd64c4  vptest xmm13, xmm13
000071409bfd64c9  jnz 0x000071409BFD71BB
000071409bfd64cf  vmovaps xmm1, [rsp+0x30]
000071409bfd64d5  vmovaps xmm15, [rsp+0x30]
000071409bfd64db  por xmm1, xmm15
000071409bfd64e0  movaps [r15+0x210], xmm1
000071409bfd64e8  vmovaps xmm15, [rsp+0x70]
000071409bfd64ee  vmovaps xmm14, [rsp+0x70]
000071409bfd64f4  por xmm15, xmm14
000071409bfd64f9  movaps [r15+0x1C0], xmm15
000071409bfd6501  vmovaps xmm14, [rsp+0x60]
000071409bfd6507  vmovaps xmm13, [rsp+0x60]
000071409bfd650d  por xmm14, xmm13
000071409bfd6512  movaps [r15+0x280], xmm14
000071409bfd651a  vmovaps xmm13, [rsp+0x50]
000071409bfd6520  vmovaps [rsp+0x30], xmm1
000071409bfd6526  vmovaps xmm1, [rsp+0x50]
000071409bfd652c  por xmm13, xmm1
000071409bfd6531  movaps [r15+0x2A0], xmm13
000071409bfd6539  vmovaps [rsp+0x50], xmm2
000071409bfd653f  vmovaps xmm1, [rsp+0x50]
000071409bfd6545  por xmm2, xmm1
000071409bfd6549  movaps [r15+0x2E0], xmm2
000071409bfd6551  vmovaps [rsp+0x50], xmm3
000071409bfd6557  vmovaps xmm1, [rsp+0x50]
000071409bfd655d  por xmm3, xmm1
000071409bfd6561  movaps [r15+0x1F0], xmm3
000071409bfd6569  vmovaps xmm1, [rsp+0x80]
000071409bfd6572  vmovaps [rsp+0x50], xmm15
000071409bfd6578  vmovaps xmm15, [rsp+0x80]
000071409bfd6581  por xmm1, xmm15
000071409bfd6586  movaps [r15+0x250], xmm1
000071409bfd658e  vmovaps xmm1, [rsp+0xC0]
000071409bfd6597  vmovaps xmm15, [rsp+0xC0]
000071409bfd65a0  por xmm1, xmm15
000071409bfd65a5  movaps [r15+0x260], xmm1
000071409bfd65ad  vmovaps xmm15, [rsp+0x100]
000071409bfd65b6  vmovaps [rsp+0x60], xmm1
000071409bfd65bc  vmovaps xmm1, [rsp+0x100]
000071409bfd65c5  por xmm15, xmm1
000071409bfd65ca  movaps [r15+0x290], xmm15
000071409bfd65d2  vmovaps xmm1, [rsp+0xF0]
000071409bfd65db  vmovaps [rsp+0x70], xmm15
000071409bfd65e1  vmovaps xmm15, [rsp+0xF0]
000071409bfd65ea  por xmm1, xmm15
000071409bfd65ef  movaps [r15+0x2C0], xmm1
000071409bfd65f7  movq xmm15, qword ptr [r15+0x240]
000071409bfd6600  vmovaps [rsp+0x80], xmm15
000071409bfd6609  vpermilpd xmm15, xmm15, 0x00
000071409bfd660f  vmovaps [rsp+0xC0], xmm1
000071409bfd6618  vmovaps xmm1, [rsp+0x40]
000071409bfd661e  vmovaps [rsp+0x40], xmm15
000071409bfd6624  vmovaps xmm15, [rsp+0x30]
000071409bfd662a  vmovaps [rsp+0x30], xmm14
000071409bfd6630  vmovaps xmm14, [rsp+0x40]
000071409bfd6636  vmovaps [rsp+0x40], xmm13
000071409bfd663c  vmovaps [rsp+0xD0], xmm12
000071409bfd6645  movaps xmm13, xmm1
000071409bfd6649  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd664e  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd6654  vptest xmm12, xmm12
000071409bfd6659  jnz 0x000071409BFD7314
000071409bfd665f  vmovaps xmm1, [rsp+0x80]
000071409bfd6668  vpermilpd xmm1, xmm1, 0x00
000071409bfd666e  vmovaps xmm15, [rsp+0xA0]
000071409bfd6677  movaps xmm14, xmm15
000071409bfd667b  vfmadd231pd xmm14, xmm2, xmm1
000071409bfd6680  vcmppd xmm12, xmm14, xmm14, 0x03
000071409bfd6686  vptest xmm12, xmm12
000071409bfd668b  jnz 0x000071409BFD746D
000071409bfd6691  vmovaps xmm1, [rsp+0x80]
000071409bfd669a  vpermilpd xmm1, xmm1, 0x00
000071409bfd66a0  vmovaps xmm15, [rsp+0x120]
000071409bfd66a9  vmovaps xmm12, [rsp+0x50]
000071409bfd66af  vmovaps [rsp+0x50], xmm14
000071409bfd66b5  movaps xmm2, xmm15
000071409bfd66b9  vfmadd231pd xmm2, xmm12, xmm1
000071409bfd66be  vcmppd xmm14, xmm2, xmm2, 0x03
000071409bfd66c3  vptest xmm14, xmm14
000071409bfd66c8  jnz 0x000071409BFD75C5
000071409bfd66ce  vmovaps xmm1, [rsp+0x110]
000071409bfd66d7  vmovaps xmm15, [rsp+0x110]
000071409bfd66e0  por xmm1, xmm15
000071409bfd66e5  movaps [r15+0x1D0], xmm1
000071409bfd66ed  vmovaps xmm15, [rsp+0x80]
000071409bfd66f6  vpermilpd xmm15, xmm15, 0x00
000071409bfd66fc  vmovaps xmm14, [rsp+0xD0]
000071409bfd6705  vmovaps [rsp+0x80], xmm1
000071409bfd670e  movaps xmm12, xmm14
000071409bfd6712  vfmadd231pd xmm12, xmm3, xmm15
000071409bfd6717  vcmppd xmm1, xmm12, xmm12, 0x03
000071409bfd671d  vptest xmm1, xmm1
000071409bfd6722  jnz 0x000071409BFD771C
000071409bfd6728  vmovaps [rsp+0xA0], xmm4
000071409bfd6731  vmovaps xmm1, [rsp+0xA0]
000071409bfd673a  por xmm4, xmm1
000071409bfd673e  movaps [r15+0x200], xmm4
000071409bfd6746  vmovaps xmm1, [rsp+0xE0]
000071409bfd674f  vmovaps xmm15, [rsp+0xE0]
000071409bfd6758  por xmm1, xmm15
000071409bfd675d  movaps [r15+0x1E0], xmm1
000071409bfd6765  vmovaps [rsp+0xA0], xmm8
000071409bfd676e  vmovaps xmm1, [rsp+0xA0]
000071409bfd6777  por xmm8, xmm1
000071409bfd677c  movaps [r15+0x2B0], xmm8
000071409bfd6784  vmovaps [rsp+0xA0], xmm9
000071409bfd678d  vmovaps xmm1, [rsp+0xA0]
000071409bfd6796  por xmm9, xmm1
000071409bfd679b  movaps [r15+0x300], xmm9
000071409bfd67a3  vmovaps [rsp+0xA0], xmm6
000071409bfd67ac  vpermilpd xmm6, xmm6, 0x00
000071409bfd67b2  vmovaps xmm14, [rsp+0x60]
000071409bfd67b8  movaps xmm9, xmm13
000071409bfd67bc  vfmadd231pd xmm9, xmm14, xmm6
000071409bfd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
000071409bfd67c7  vptest xmm3, xmm3
000071409bfd67cc  jnz 0x000071409BFD7875
000071409bfd67d2  vmovaps xmm14, [rsp+0xA0]
000071409bfd67db  vpermilpd xmm14, xmm14, 0x00
000071409bfd67e1  vmovaps xmm13, [rsp+0x50]
000071409bfd67e7  vmovaps xmm6, [rsp+0xC0]
000071409bfd67f0  vmovaps [rsp+0x50], xmm1
000071409bfd67f6  movaps xmm3, xmm13
000071409bfd67fa  vfmadd231pd xmm3, xmm6, xmm14
000071409bfd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
000071409bfd6804  vptest xmm1, xmm1
000071409bfd6809  jnz 0x000071409BFD79CE
000071409bfd680f  vmovaps xmm1, [rsp+0xA0]
000071409bfd6818  vpermilpd xmm1, xmm1, 0x00
000071409bfd681e  vmovaps xmm14, [rsp+0x30]
000071409bfd6824  movaps xmm6, xmm2
000071409bfd6827  vfmadd231pd xmm6, xmm14, xmm1
000071409bfd682c  vcmppd xmm13, xmm6, xmm6, 0x03
000071409bfd6831  vptest xmm13, xmm13
000071409bfd6836  jnz 0x000071409BFD7B25
000071409bfd683c  vmovaps xmm1, [rsp+0xA0]
000071409bfd6845  vpermilpd xmm1, xmm1, 0x00
000071409bfd684b  vmovaps xmm14, [rsp+0x80]
000071409bfd6854  movaps xmm13, xmm12
000071409bfd6858  vfmadd231pd xmm13, xmm14, xmm1
000071409bfd685d  vcmppd xmm2, xmm13, xmm13, 0x03
000071409bfd6863  vptest xmm2, xmm2
000071409bfd6868  jnz 0x000071409BFD7C7B
000071409bfd686e  vmovaps [rsp+0x30], xmm7
000071409bfd6874  vmovaps xmm1, [rsp+0x30]
000071409bfd687a  por xmm7, xmm1
000071409bfd687e  movaps [r15+0x180], xmm7
000071409bfd6886  vmovaps [rsp+0x30], xmm10
000071409bfd688c  vmovaps xmm1, [rsp+0x30]
000071409bfd6892  por xmm10, xmm1
000071409bfd6897  movaps [r15+0x2D0], xmm10
000071409bfd689f  vmovaps [rsp+0x30], xmm5
000071409bfd68a5  vpermilpd xmm5, xmm5, 0x00
000071409bfd68ab  vmovaps xmm14, [rsp+0x50]
000071409bfd68b1  movaps xmm12, xmm3
000071409bfd68b5  vfmadd231pd xmm12, xmm14, xmm5
000071409bfd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
000071409bfd68c0  vptest xmm10, xmm10
000071409bfd68c5  jnz 0x000071409BFD7DD4
000071409bfd68cb  vmovaps xmm14, [rsp+0x30]
000071409bfd68d1  vpermilpd xmm14, xmm14, 0x00
000071409bfd68d7  movaps xmm10, xmm9
000071409bfd68db  vfmadd231pd xmm10, xmm7, xmm14
000071409bfd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
000071409bfd68e6  vptest xmm5, xmm5
000071409bfd68eb  jnz 0x000071409BFD7F2C
000071409bfd68f1  lea r14, [rax+0x80]
000071409bfd68f8  movups xmm14, [r13+r14*1]
000071409bfd68fe  movaps [r15+0x2F0], xmm14
000071409bfd6906  vmovaps xmm9, [rsp+0x30]
000071409bfd690c  vpermilpd xmm9, xmm9, 0x00
000071409bfd6912  vmovaps xmm7, [rsp+0x70]
000071409bfd6918  movaps xmm5, xmm6
000071409bfd691b  vfmadd231pd xmm5, xmm7, xmm9
000071409bfd6920  vcmppd xmm3, xmm5, xmm5, 0x03
000071409bfd6925  vptest xmm3, xmm3
000071409bfd692a  jnz 0x000071409BFD808F
000071409bfd6930  vmovaps xmm9, [rsp+0x30]
000071409bfd6936  vpermilpd xmm9, xmm9, 0x00
000071409bfd693c  movaps xmm7, xmm13
000071409bfd6940  vfmadd231pd xmm7, xmm1, xmm9
000071409bfd6945  vcmppd xmm6, xmm7, xmm7, 0x03
000071409bfd694a  vptest xmm6, xmm6
000071409bfd694f  jnz 0x000071409BFD81E5
000071409bfd6955  vmovaps xmm1, [rsp+0x20]
000071409bfd695b  vmovaps xmm13, [rsp+0x20]
000071409bfd6961  por xmm1, xmm13
000071409bfd6966  movaps [r15+0x160], xmm1
000071409bfd696e  lea r14, [rax+0x40]
000071409bfd6972  movups xmm13, [r13+r14*1]
000071409bfd6978  lea r14, [rax+0x50]
000071409bfd697c  movups xmm9, [r13+r14*1]
000071409bfd6982  movaps [r15+0x1B0], xmm13
000071409bfd698a  movaps [r15+0x1A0], xmm9
000071409bfd6992  movaps xmm6, [r15+0x190]
000071409bfd699a  vmovaps xmm3, [rsp+0xB0]
000071409bfd69a3  vpermilpd xmm3, xmm3, 0x00
000071409bfd69a9  vmovaps [rsp+0x20], xmm1
000071409bfd69af  movaps xmm2, xmm12
000071409bfd69b3  vfmadd231pd xmm2, xmm6, xmm3
000071409bfd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
000071409bfd69bd  vptest xmm1, xmm1
000071409bfd69c2  jnz 0x000071409BFD8350
000071409bfd69c8  vmovaps xmm1, [rsp+0xB0]
000071409bfd69d1  vpermilpd xmm1, xmm1, 0x00
000071409bfd69d7  vmovaps xmm12, [rsp+0x20]
000071409bfd69dd  movaps xmm6, xmm10
000071409bfd69e1  vfmadd231pd xmm6, xmm12, xmm1
000071409bfd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
000071409bfd69eb  vptest xmm3, xmm3
000071409bfd69f0  jnz 0x000071409BFD84A6
000071409bfd69f6  vmovaps xmm1, [rsp+0xB0]
000071409bfd69ff  vpermilpd xmm1, xmm1, 0x00
000071409bfd6a05  vmovaps xmm12, [rsp+0x40]
000071409bfd6a0b  movaps xmm10, xmm5
000071409bfd6a0f  vfmadd231pd xmm10, xmm12, xmm1
000071409bfd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
000071409bfd6a1a  vptest xmm3, xmm3
000071409bfd6a1f  jnz 0x000071409BFD85FD
000071409bfd6a25  vmovaps xmm1, [rsp+0xB0]
000071409bfd6a2e  vpermilpd xmm1, xmm1, 0x00
000071409bfd6a34  movaps xmm12, xmm7
000071409bfd6a38  vfmadd231pd xmm12, xmm15, xmm1
000071409bfd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
000071409bfd6a43  vptest xmm5, xmm5
000071409bfd6a48  jnz 0x000071409BFD8755
000071409bfd6a4e  lea r14, [rax+0x60]
000071409bfd6a52  movups xmm1, [r13+r14*1]
000071409bfd6a58  lea r14, [rax+0x70]
000071409bfd6a5c  movups xmm15, [r13+r14*1]
000071409bfd6a62  movaps [r15+0x150], xmm1
000071409bfd6a6a  movaps [r15+0x120], xmm15
000071409bfd6a72  vmovaps [rsp+0x20], xmm11
000071409bfd6a78  vpermilpd xmm11, xmm11, 0x00
000071409bfd6a7e  movaps xmm7, xmm2
000071409bfd6a81  vfmadd231pd xmm7, xmm9, xmm11
000071409bfd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
000071409bfd6a8b  vptest xmm5, xmm5
000071409bfd6a90  jnz 0x000071409BFD88C1
000071409bfd6a96  vmovaps xmm11, [rsp+0x20]
000071409bfd6a9c  vpermilpd xmm11, xmm11, 0x00
000071409bfd6aa2  movaps xmm9, xmm6
000071409bfd6aa6  vfmadd231pd xmm9, xmm1, xmm11
000071409bfd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
000071409bfd6ab1  vptest xmm5, xmm5
000071409bfd6ab6  jnz 0x000071409BFD8A18
000071409bfd6abc  vmovaps xmm1, [rsp+0x20]
000071409bfd6ac2  vpermilpd xmm1, xmm1, 0x00
000071409bfd6ac8  movaps xmm11, xmm10
000071409bfd6acc  vfmadd231pd xmm11, xmm8, xmm1
000071409bfd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
000071409bfd6ad7  vptest xmm6, xmm6
000071409bfd6adc  jnz 0x000071409BFD8B70
000071409bfd6ae2  vmovaps xmm1, [rsp+0x20]
000071409bfd6ae8  vpermilpd xmm1, xmm1, 0x00
000071409bfd6aee  movaps xmm10, xmm12
000071409bfd6af2  vfmadd231pd xmm10, xmm13, xmm1
000071409bfd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
000071409bfd6afd  vptest xmm8, xmm8
000071409bfd6b02  jnz 0x000071409BFD8CC9
000071409bfd6b08  lea r14, [rax+0x20]
000071409bfd6b0c  movups xmm1, [r13+r14*1]
000071409bfd6b12  lea r14, [rax+0x30]
000071409bfd6b16  movups xmm13, [r13+r14*1]
000071409bfd6b1c  vmovaps xmm12, [rsp+0x90]
000071409bfd6b25  vpermilpd xmm12, xmm12, 0x00
000071409bfd6b2b  movaps xmm8, xmm7
000071409bfd6b2f  vfmadd231pd xmm8, xmm4, xmm12
000071409bfd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
000071409bfd6b3a  vptest xmm6, xmm6
000071409bfd6b3f  jnz 0x000071409BFD8E36
000071409bfd6b45  vmovaps xmm12, [rsp+0x90]
000071409bfd6b4e  vpermilpd xmm12, xmm12, 0x00
000071409bfd6b54  movaps xmm7, xmm9
000071409bfd6b58  vfmadd231pd xmm7, xmm14, xmm12
000071409bfd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
000071409bfd6b62  vptest xmm6, xmm6
000071409bfd6b67  jnz 0x000071409BFD8F8E
000071409bfd6b6d  vmovaps xmm14, [rsp+0x90]
000071409bfd6b76  vpermilpd xmm14, xmm14, 0x00
000071409bfd6b7c  movaps xmm12, xmm11
000071409bfd6b80  vfmadd231pd xmm12, xmm15, xmm14
000071409bfd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
000071409bfd6b8b  vptest xmm9, xmm9
000071409bfd6b90  jnz 0x000071409BFD90E6
000071409bfd6b96  vmovaps xmm15, [rsp+0x90]
000071409bfd6b9f  vpermilpd xmm15, xmm15, 0x00
000071409bfd6ba5  movaps xmm11, xmm10
000071409bfd6ba9  vfmadd231pd xmm11, xmm13, xmm15
000071409bfd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
000071409bfd6bb4  vptest xmm14, xmm14
000071409bfd6bb9  jnz 0x000071409BFD9240
000071409bfd6bbf  lea r14, [rax+0x90]
000071409bfd6bc6  movups xmm15, [r13+r14*1]
000071409bfd6bcc  lea r14, [rax+0xA0]
000071409bfd6bd3  movups xmm14, [r13+r14*1]
000071409bfd6bd9  movaps [r15+0x140], xmm15
000071409bfd6be1  movaps [r15+0x130], xmm14
000071409bfd6be9  vmovaps xmm13, [rsp+0x10]
000071409bfd6bef  vpermilpd xmm13, xmm13, 0x00
000071409bfd6bf5  movaps xmm10, xmm8
000071409bfd6bf9  vfmadd231pd xmm10, xmm1, xmm13
000071409bfd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
000071409bfd6c04  vptest xmm9, xmm9
000071409bfd6c09  jnz 0x000071409BFD93AE
000071409bfd6c0f  movaps [r15+0x220], xmm10
000071409bfd6c17  lea r14, [rax+0x10]
000071409bfd6c1b  movups xmm1, [r13+r14*1]
000071409bfd6c21  movaps [r15+0x240], xmm1
000071409bfd6c29  vmovaps xmm13, [rsp+0x10]
000071409bfd6c2f  vpermilpd xmm13, xmm13, 0x00
000071409bfd6c35  movaps xmm9, xmm7
000071409bfd6c39  vfmadd231pd xmm9, xmm14, xmm13
000071409bfd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
000071409bfd6c44  vptest xmm8, xmm8
000071409bfd6c49  jnz 0x000071409BFD9511
000071409bfd6c4f  movaps [r15+0x110], xmm9
000071409bfd6c57  vmovaps xmm14, [rsp+0x10]
000071409bfd6c5d  vpermilpd xmm14, xmm14, 0x00
000071409bfd6c63  movaps xmm13, xmm12
000071409bfd6c67  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
000071409bfd6c72  vptest xmm8, xmm8
000071409bfd6c77  jnz 0x000071409BFD966A
000071409bfd6c7d  movaps [r15+0x170], xmm13
000071409bfd6c85  vmovaps xmm15, [rsp+0x10]
000071409bfd6c8b  vpermilpd xmm15, xmm15, 0x00
000071409bfd6c91  movaps xmm14, xmm11
000071409bfd6c95  vfmadd231pd xmm14, xmm1, xmm15
000071409bfd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
000071409bfd6ca0  vptest xmm12, xmm12
000071409bfd6ca5  jnz 0x000071409BFD97C4
000071409bfd6cab  movaps [r15+0x230], xmm14
000071409bfd6cb3  movups [r13+r11*1], xmm9
000071409bfd6cb9  lea rax, [r11+0x10]
000071409bfd6cbd  movups [r13+rax*1], xmm13
000071409bfd6cc3  lea rax, [r11+0x20]
000071409bfd6cc7  movups [r13+rax*1], xmm10
000071409bfd6ccd  lea rax, [r11+0x30]
000071409bfd6cd1  movups [r13+rax*1], xmm14
000071409bfd6cd7  mov eax, [r15+0x108]
000071409bfd6cde  sahf
000071409bfd6cdf  jnz 0x000071409BFD6D11
000071409bfd6ce1  cmp dword ptr [r15+0x318], 0x00
000071409bfd6ce9  jz 0x000071409BFD9950
000071409bfd6cef  nop [rax+rax*1], ax
000071409bfd6cf8  nop [rax+rax*1], eax
000071409bfd6d00  mov eax, 0x410664
000071409bfd6d05  mov [r15+0x100], rax
000071409bfd6d0c  jmp 0x000071409BDFE110
000071409bfd6d11  cmp dword ptr [r15+0x318], 0x00
000071409bfd6d19  jz 0x000071409BFD6050
000071409bfd6d1f  nop [rax+rax*1], ax
000071409bfd6d28  nop [rax+rax*1], eax
000071409bfd6d30  mov eax, 0x4104F0
000071409bfd6d35  mov [r15+0x100], rax
000071409bfd6d3c  jmp 0x000071409BDFE110
000071409bfd6d41  int3
000071409bfd6d42  call 0x000071409BE0A4B0
000071409bfd6d47  jmp 0x000071409BFD6079
000071409bfd6d4c  call 0x000071409BE09240
000071409bfd6d51  jmp 0x000071409BFD6083
000071409bfd6d56  call 0x000071409BE0A4B0
000071409bfd6d5b  jmp 0x000071409BFD60CD
000071409bfd6d60  call 0x000071409BE09240
000071409bfd6d65  jmp 0x000071409BFD60D7
000071409bfd6d6a  call 0x000071409BE0A4B0
000071409bfd6d6f  jmp 0x000071409BFD6158
000071409bfd6d74  call 0x000071409BE09240
000071409bfd6d79  jmp 0x000071409BFD6162
000071409bfd6d7e  call 0x000071409BEB47C0
000071409bfd6d83  jmp 0x000071409BFD6243
000071409bfd6d88  call 0x000071409BDFF430
000071409bfd6d8d  jmp 0x000071409BFD6272
000071409bfd6d92  call 0x000071409BEB0CE0
000071409bfd6d97  jmp 0x000071409BFD628E
000071409bfd6d9c  sub rsp, 0x08
000071409bfd6da0  push rax
000071409bfd6da1  push rcx
000071409bfd6da2  push rdx
000071409bfd6da3  push rdi
000071409bfd6da4  push rsi
000071409bfd6da5  push r8
000071409bfd6da7  push r9
000071409bfd6da9  push r10
000071409bfd6dab  push r11
000071409bfd6dad  sub rsp, 0xF0
000071409bfd6db4  vmovaps [rsp], xmm0
000071409bfd6db9  vmovaps [rsp+0x10], xmm1
000071409bfd6dbf  vmovaps [rsp+0x20], xmm2
000071409bfd6dc5  vmovaps [rsp+0x30], xmm3
000071409bfd6dcb  vmovaps [rsp+0x40], xmm4
000071409bfd6dd1  vmovaps [rsp+0x50], xmm5
000071409bfd6dd7  vmovaps [rsp+0x60], xmm6
000071409bfd6ddd  vmovaps [rsp+0x70], xmm7
000071409bfd6de3  vmovaps [rsp+0x80], xmm8
000071409bfd6dec  vmovaps [rsp+0x90], xmm9
000071409bfd6df5  vmovaps [rsp+0xA0], xmm10
000071409bfd6dfe  vmovaps [rsp+0xB0], xmm11
000071409bfd6e07  vmovaps [rsp+0xC0], xmm12
000071409bfd6e10  vmovaps [rsp+0xD0], xmm14
000071409bfd6e19  vmovaps [rsp+0xE0], xmm15
000071409bfd6e22  sub rsp, 0x40
000071409bfd6e26  lea rdi, [rsp]
000071409bfd6e2a  lea rsi, [rsp+0x10]
000071409bfd6e2f  lea rdx, [rsp+0x20]
000071409bfd6e34  lea rcx, [rsp+0x30]
000071409bfd6e39  mov r8d, 0x00
000071409bfd6e3f  lea r9, [r15+0x3A8]
000071409bfd6e46  movaps [rdi], xmm13
000071409bfd6e4a  movaps [rsi], xmm1
000071409bfd6e4d  movaps [rdx], xmm15
000071409bfd6e51  movaps [rcx], xmm14
000071409bfd6e55  mov rax, 0x6219BEBC2A50
000071409bfd6e5f  call rax
000071409bfd6e61  movaps xmm13, [rsp]
000071409bfd6e66  add rsp, 0x40
000071409bfd6e6a  vmovaps xmm0, [rsp]
000071409bfd6e6f  vmovaps xmm1, [rsp+0x10]
000071409bfd6e75  vmovaps xmm2, [rsp+0x20]
000071409bfd6e7b  vmovaps xmm3, [rsp+0x30]
000071409bfd6e81  vmovaps xmm4, [rsp+0x40]
000071409bfd6e87  vmovaps xmm5, [rsp+0x50]
000071409bfd6e8d  vmovaps xmm6, [rsp+0x60]
000071409bfd6e93  vmovaps xmm7, [rsp+0x70]
000071409bfd6e99  vmovaps xmm8, [rsp+0x80]
000071409bfd6ea2  vmovaps xmm9, [rsp+0x90]
000071409bfd6eab  vmovaps xmm10, [rsp+0xA0]
000071409bfd6eb4  vmovaps xmm11, [rsp+0xB0]
000071409bfd6ebd  vmovaps xmm12, [rsp+0xC0]
000071409bfd6ec6  vmovaps xmm14, [rsp+0xD0]
000071409bfd6ecf  vmovaps xmm15, [rsp+0xE0]
000071409bfd6ed8  add rsp, 0xF0
000071409bfd6edf  pop r11
000071409bfd6ee1  pop r10
000071409bfd6ee3  pop r9
000071409bfd6ee5  pop r8
000071409bfd6ee7  pop rsi
000071409bfd6ee8  pop rdi
000071409bfd6ee9  pop rdx
000071409bfd6eea  pop rcx
000071409bfd6eeb  pop rax
000071409bfd6eec  add rsp, 0x08
000071409bfd6ef0  jmp 0x000071409BFD6305
000071409bfd6ef5  sub rsp, 0x08
000071409bfd6ef9  push rax
000071409bfd6efa  push rcx
000071409bfd6efb  push rdx
000071409bfd6efc  push rdi
000071409bfd6efd  push rsi
000071409bfd6efe  push r8
000071409bfd6f00  push r9
000071409bfd6f02  push r10
000071409bfd6f04  push r11
000071409bfd6f06  sub rsp, 0xF0
000071409bfd6f0d  vmovaps [rsp], xmm0
000071409bfd6f12  vmovaps [rsp+0x10], xmm1
000071409bfd6f18  vmovaps [rsp+0x20], xmm2
000071409bfd6f1e  vmovaps [rsp+0x30], xmm3
000071409bfd6f24  vmovaps [rsp+0x40], xmm4
000071409bfd6f2a  vmovaps [rsp+0x50], xmm5
000071409bfd6f30  vmovaps [rsp+0x60], xmm6
000071409bfd6f36  vmovaps [rsp+0x70], xmm7
000071409bfd6f3c  vmovaps [rsp+0x80], xmm8
000071409bfd6f45  vmovaps [rsp+0x90], xmm9
000071409bfd6f4e  vmovaps [rsp+0xA0], xmm10
000071409bfd6f57  vmovaps [rsp+0xB0], xmm11
000071409bfd6f60  vmovaps [rsp+0xC0], xmm13
000071409bfd6f69  vmovaps [rsp+0xD0], xmm14
000071409bfd6f72  vmovaps [rsp+0xE0], xmm15
000071409bfd6f7b  sub rsp, 0x40
000071409bfd6f7f  lea rdi, [rsp]
000071409bfd6f83  lea rsi, [rsp+0x10]
000071409bfd6f88  lea rdx, [rsp+0x20]
000071409bfd6f8d  lea rcx, [rsp+0x30]
000071409bfd6f92  mov r8d, 0x00
000071409bfd6f98  lea r9, [r15+0x3A8]
000071409bfd6f9f  movaps [rdi], xmm12
000071409bfd6fa3  movaps [rsi], xmm15
000071409bfd6fa7  movaps [rdx], xmm1
000071409bfd6faa  movaps [rcx], xmm14
000071409bfd6fae  mov rax, 0x6219BEBC2A50
000071409bfd6fb8  call rax
000071409bfd6fba  movaps xmm12, [rsp]
000071409bfd6fbf  add rsp, 0x40
000071409bfd6fc3  vmovaps xmm0, [rsp]
000071409bfd6fc8  vmovaps xmm1, [rsp+0x10]
000071409bfd6fce  vmovaps xmm2, [rsp+0x20]
000071409bfd6fd4  vmovaps xmm3, [rsp+0x30]
000071409bfd6fda  vmovaps xmm4, [rsp+0x40]
000071409bfd6fe0  vmovaps xmm5, [rsp+0x50]
000071409bfd6fe6  vmovaps xmm6, [rsp+0x60]
000071409bfd6fec  vmovaps xmm7, [rsp+0x70]
000071409bfd6ff2  vmovaps xmm8, [rsp+0x80]
000071409bfd6ffb  vmovaps xmm9, [rsp+0x90]
000071409bfd7004  vmovaps xmm10, [rsp+0xA0]
000071409bfd700d  vmovaps xmm11, [rsp+0xB0]
000071409bfd7016  vmovaps xmm13, [rsp+0xC0]
000071409bfd701f  vmovaps xmm14, [rsp+0xD0]
000071409bfd7028  vmovaps xmm15, [rsp+0xE0]
000071409bfd7031  add rsp, 0xF0
000071409bfd7038  pop r11
000071409bfd703a  pop r10
000071409bfd703c  pop r9
000071409bfd703e  pop r8
000071409bfd7040  pop rsi
000071409bfd7041  pop rdi
000071409bfd7042  pop rdx
000071409bfd7043  pop rcx
000071409bfd7044  pop rax
000071409bfd7045  add rsp, 0x08
000071409bfd7049  jmp 0x000071409BFD6333
000071409bfd704e  call 0x000071409BED64F0
000071409bfd7053  jmp 0x000071409BFD641F
000071409bfd7058  sub rsp, 0x08
000071409bfd705c  push rax
000071409bfd705d  push rcx
000071409bfd705e  push rdx
000071409bfd705f  push rdi
000071409bfd7060  push rsi
000071409bfd7061  push r8
000071409bfd7063  push r9
000071409bfd7065  push r10
000071409bfd7067  push r11
000071409bfd7069  sub rsp, 0xF0
000071409bfd7070  vmovaps [rsp], xmm0
000071409bfd7075  vmovaps [rsp+0x10], xmm1
000071409bfd707b  vmovaps [rsp+0x20], xmm2
000071409bfd7081  vmovaps [rsp+0x30], xmm3
000071409bfd7087  vmovaps [rsp+0x40], xmm4
000071409bfd708d  vmovaps [rsp+0x50], xmm5
000071409bfd7093  vmovaps [rsp+0x60], xmm6
000071409bfd7099  vmovaps [rsp+0x70], xmm7
000071409bfd709f  vmovaps [rsp+0x80], xmm8
000071409bfd70a8  vmovaps [rsp+0x90], xmm9
000071409bfd70b1  vmovaps [rsp+0xA0], xmm10
000071409bfd70ba  vmovaps [rsp+0xB0], xmm11
000071409bfd70c3  vmovaps [rsp+0xC0], xmm12
000071409bfd70cc  vmovaps [rsp+0xD0], xmm14
000071409bfd70d5  vmovaps [rsp+0xE0], xmm15
000071409bfd70de  sub rsp, 0x40
000071409bfd70e2  lea rdi, [rsp]
000071409bfd70e6  lea rsi, [rsp+0x10]
000071409bfd70eb  lea rdx, [rsp+0x20]
000071409bfd70f0  lea rcx, [rsp+0x30]
000071409bfd70f5  mov r8d, 0x00
000071409bfd70fb  lea r9, [r15+0x3A8]
000071409bfd7102  movaps [rdi], xmm13
000071409bfd7106  movaps [rsi], xmm1
000071409bfd7109  movaps [rdx], xmm15
000071409bfd710d  movaps [rcx], xmm14
000071409bfd7111  mov rax, 0x6219BEBC2A50
000071409bfd711b  call rax
000071409bfd711d  movaps xmm13, [rsp]
000071409bfd7122  add rsp, 0x40
000071409bfd7126  vmovaps xmm0, [rsp]
000071409bfd712b  vmovaps xmm1, [rsp+0x10]
000071409bfd7131  vmovaps xmm2, [rsp+0x20]
000071409bfd7137  vmovaps xmm3, [rsp+0x30]
000071409bfd713d  vmovaps xmm4, [rsp+0x40]
000071409bfd7143  vmovaps xmm5, [rsp+0x50]
000071409bfd7149  vmovaps xmm6, [rsp+0x60]
000071409bfd714f  vmovaps xmm7, [rsp+0x70]
000071409bfd7155  vmovaps xmm8, [rsp+0x80]
000071409bfd715e  vmovaps xmm9, [rsp+0x90]
000071409bfd7167  vmovaps xmm10, [rsp+0xA0]
000071409bfd7170  vmovaps xmm11, [rsp+0xB0]
000071409bfd7179  vmovaps xmm12, [rsp+0xC0]
000071409bfd7182  vmovaps xmm14, [rsp+0xD0]
000071409bfd718b  vmovaps xmm15, [rsp+0xE0]
000071409bfd7194  add rsp, 0xF0
000071409bfd719b  pop r11
000071409bfd719d  pop r10
000071409bfd719f  pop r9
000071409bfd71a1  pop r8
000071409bfd71a3  pop rsi
000071409bfd71a4  pop rdi
000071409bfd71a5  pop rdx
000071409bfd71a6  pop rcx
000071409bfd71a7  pop rax
000071409bfd71a8  add rsp, 0x08
000071409bfd71ac  jmp 0x000071409BFD648E
000071409bfd71b1  call 0x000071409BED64F0
000071409bfd71b6  jmp 0x000071409BFD64A3
000071409bfd71bb  sub rsp, 0x08
000071409bfd71bf  push rax
000071409bfd71c0  push rcx
000071409bfd71c1  push rdx
000071409bfd71c2  push rdi
000071409bfd71c3  push rsi
000071409bfd71c4  push r8
000071409bfd71c6  push r9
000071409bfd71c8  push r10
000071409bfd71ca  push r11
000071409bfd71cc  sub rsp, 0xF0
000071409bfd71d3  vmovaps [rsp], xmm0
000071409bfd71d8  vmovaps [rsp+0x10], xmm1
000071409bfd71de  vmovaps [rsp+0x20], xmm2
000071409bfd71e4  vmovaps [rsp+0x30], xmm3
000071409bfd71ea  vmovaps [rsp+0x40], xmm4
000071409bfd71f0  vmovaps [rsp+0x50], xmm5
000071409bfd71f6  vmovaps [rsp+0x60], xmm6
000071409bfd71fc  vmovaps [rsp+0x70], xmm7
000071409bfd7202  vmovaps [rsp+0x80], xmm8
000071409bfd720b  vmovaps [rsp+0x90], xmm9
000071409bfd7214  vmovaps [rsp+0xA0], xmm10
000071409bfd721d  vmovaps [rsp+0xB0], xmm11
000071409bfd7226  vmovaps [rsp+0xC0], xmm13
000071409bfd722f  vmovaps [rsp+0xD0], xmm14
000071409bfd7238  vmovaps [rsp+0xE0], xmm15
000071409bfd7241  sub rsp, 0x40
000071409bfd7245  lea rdi, [rsp]
000071409bfd7249  lea rsi, [rsp+0x10]
000071409bfd724e  lea rdx, [rsp+0x20]
000071409bfd7253  lea rcx, [rsp+0x30]
000071409bfd7258  mov r8d, 0x00
000071409bfd725e  lea r9, [r15+0x3A8]
000071409bfd7265  movaps [rdi], xmm12
000071409bfd7269  movaps [rsi], xmm15
000071409bfd726d  movaps [rdx], xmm1
000071409bfd7270  movaps [rcx], xmm14
000071409bfd7274  mov rax, 0x6219BEBC2A50
000071409bfd727e  call rax
000071409bfd7280  movaps xmm12, [rsp]
000071409bfd7285  add rsp, 0x40
000071409bfd7289  vmovaps xmm0, [rsp]
000071409bfd728e  vmovaps xmm1, [rsp+0x10]
000071409bfd7294  vmovaps xmm2, [rsp+0x20]
000071409bfd729a  vmovaps xmm3, [rsp+0x30]
000071409bfd72a0  vmovaps xmm4, [rsp+0x40]
000071409bfd72a6  vmovaps xmm5, [rsp+0x50]
000071409bfd72ac  vmovaps xmm6, [rsp+0x60]
000071409bfd72b2  vmovaps xmm7, [rsp+0x70]
000071409bfd72b8  vmovaps xmm8, [rsp+0x80]
000071409bfd72c1  vmovaps xmm9, [rsp+0x90]
000071409bfd72ca  vmovaps xmm10, [rsp+0xA0]
000071409bfd72d3  vmovaps xmm11, [rsp+0xB0]
000071409bfd72dc  vmovaps xmm13, [rsp+0xC0]
000071409bfd72e5  vmovaps xmm14, [rsp+0xD0]
000071409bfd72ee  vmovaps xmm15, [rsp+0xE0]
000071409bfd72f7  add rsp, 0xF0
000071409bfd72fe  pop r11
000071409bfd7300  pop r10
000071409bfd7302  pop r9
000071409bfd7304  pop r8
000071409bfd7306  pop rsi
000071409bfd7307  pop rdi
000071409bfd7308  pop rdx
000071409bfd7309  pop rcx
000071409bfd730a  pop rax
000071409bfd730b  add rsp, 0x08
000071409bfd730f  jmp 0x000071409BFD64CF
000071409bfd7314  sub rsp, 0x08
000071409bfd7318  push rax
000071409bfd7319  push rcx
000071409bfd731a  push rdx
000071409bfd731b  push rdi
000071409bfd731c  push rsi
000071409bfd731d  push r8
000071409bfd731f  push r9
000071409bfd7321  push r10
000071409bfd7323  push r11
000071409bfd7325  sub rsp, 0xF0
000071409bfd732c  vmovaps [rsp], xmm0
000071409bfd7331  vmovaps [rsp+0x10], xmm1
000071409bfd7337  vmovaps [rsp+0x20], xmm2
000071409bfd733d  vmovaps [rsp+0x30], xmm3
000071409bfd7343  vmovaps [rsp+0x40], xmm4
000071409bfd7349  vmovaps [rsp+0x50], xmm5
000071409bfd734f  vmovaps [rsp+0x60], xmm6
000071409bfd7355  vmovaps [rsp+0x70], xmm7
000071409bfd735b  vmovaps [rsp+0x80], xmm8
000071409bfd7364  vmovaps [rsp+0x90], xmm9
000071409bfd736d  vmovaps [rsp+0xA0], xmm10
000071409bfd7376  vmovaps [rsp+0xB0], xmm11
000071409bfd737f  vmovaps [rsp+0xC0], xmm12
000071409bfd7388  vmovaps [rsp+0xD0], xmm14
000071409bfd7391  vmovaps [rsp+0xE0], xmm15
000071409bfd739a  sub rsp, 0x40
000071409bfd739e  lea rdi, [rsp]
000071409bfd73a2  lea rsi, [rsp+0x10]
000071409bfd73a7  lea rdx, [rsp+0x20]
000071409bfd73ac  lea rcx, [rsp+0x30]
000071409bfd73b1  mov r8d, 0x00
000071409bfd73b7  lea r9, [r15+0x3A8]
000071409bfd73be  movaps [rdi], xmm13
000071409bfd73c2  movaps [rsi], xmm1
000071409bfd73c5  movaps [rdx], xmm15
000071409bfd73c9  movaps [rcx], xmm14
000071409bfd73cd  mov rax, 0x6219BEBC2A50
000071409bfd73d7  call rax
000071409bfd73d9  movaps xmm13, [rsp]
000071409bfd73de  add rsp, 0x40
000071409bfd73e2  vmovaps xmm0, [rsp]
000071409bfd73e7  vmovaps xmm1, [rsp+0x10]
000071409bfd73ed  vmovaps xmm2, [rsp+0x20]
000071409bfd73f3  vmovaps xmm3, [rsp+0x30]
000071409bfd73f9  vmovaps xmm4, [rsp+0x40]
000071409bfd73ff  vmovaps xmm5, [rsp+0x50]
000071409bfd7405  vmovaps xmm6, [rsp+0x60]
000071409bfd740b  vmovaps xmm7, [rsp+0x70]
000071409bfd7411  vmovaps xmm8, [rsp+0x80]
000071409bfd741a  vmovaps xmm9, [rsp+0x90]
000071409bfd7423  vmovaps xmm10, [rsp+0xA0]
000071409bfd742c  vmovaps xmm11, [rsp+0xB0]
000071409bfd7435  vmovaps xmm12, [rsp+0xC0]
000071409bfd743e  vmovaps xmm14, [rsp+0xD0]
000071409bfd7447  vmovaps xmm15, [rsp+0xE0]
000071409bfd7450  add rsp, 0xF0
000071409bfd7457  pop r11
000071409bfd7459  pop r10
000071409bfd745b  pop r9
000071409bfd745d  pop r8
000071409bfd745f  pop rsi
000071409bfd7460  pop rdi
000071409bfd7461  pop rdx
000071409bfd7462  pop rcx
000071409bfd7463  pop rax
000071409bfd7464  add rsp, 0x08
000071409bfd7468  jmp 0x000071409BFD665F
000071409bfd746d  sub rsp, 0x08
000071409bfd7471  push rax
000071409bfd7472  push rcx
000071409bfd7473  push rdx
000071409bfd7474  push rdi
000071409bfd7475  push rsi
000071409bfd7476  push r8
000071409bfd7478  push r9
000071409bfd747a  push r10
000071409bfd747c  push r11
000071409bfd747e  sub rsp, 0xF0
000071409bfd7485  vmovaps [rsp], xmm0
000071409bfd748a  vmovaps [rsp+0x10], xmm1
000071409bfd7490  vmovaps [rsp+0x20], xmm2
000071409bfd7496  vmovaps [rsp+0x30], xmm3
000071409bfd749c  vmovaps [rsp+0x40], xmm4
000071409bfd74a2  vmovaps [rsp+0x50], xmm5
000071409bfd74a8  vmovaps [rsp+0x60], xmm6
000071409bfd74ae  vmovaps [rsp+0x70], xmm7
000071409bfd74b4  vmovaps [rsp+0x80], xmm8
000071409bfd74bd  vmovaps [rsp+0x90], xmm9
000071409bfd74c6  vmovaps [rsp+0xA0], xmm10
000071409bfd74cf  vmovaps [rsp+0xB0], xmm11
000071409bfd74d8  vmovaps [rsp+0xC0], xmm12
000071409bfd74e1  vmovaps [rsp+0xD0], xmm13
000071409bfd74ea  vmovaps [rsp+0xE0], xmm15
000071409bfd74f3  sub rsp, 0x40
000071409bfd74f7  lea rdi, [rsp]
000071409bfd74fb  lea rsi, [rsp+0x10]
000071409bfd7500  lea rdx, [rsp+0x20]
000071409bfd7505  lea rcx, [rsp+0x30]
000071409bfd750a  mov r8d, 0x00
000071409bfd7510  lea r9, [r15+0x3A8]
000071409bfd7517  movaps [rdi], xmm14
000071409bfd751b  movaps [rsi], xmm15
000071409bfd751f  movaps [rdx], xmm2
000071409bfd7522  movaps [rcx], xmm1
000071409bfd7525  mov rax, 0x6219BEBC2A50
000071409bfd752f  call rax
000071409bfd7531  movaps xmm14, [rsp]
000071409bfd7536  add rsp, 0x40
000071409bfd753a  vmovaps xmm0, [rsp]
000071409bfd753f  vmovaps xmm1, [rsp+0x10]
000071409bfd7545  vmovaps xmm2, [rsp+0x20]
000071409bfd754b  vmovaps xmm3, [rsp+0x30]
000071409bfd7551  vmovaps xmm4, [rsp+0x40]
000071409bfd7557  vmovaps xmm5, [rsp+0x50]
000071409bfd755d  vmovaps xmm6, [rsp+0x60]
000071409bfd7563  vmovaps xmm7, [rsp+0x70]
000071409bfd7569  vmovaps xmm8, [rsp+0x80]
000071409bfd7572  vmovaps xmm9, [rsp+0x90]
000071409bfd757b  vmovaps xmm10, [rsp+0xA0]
000071409bfd7584  vmovaps xmm11, [rsp+0xB0]
000071409bfd758d  vmovaps xmm12, [rsp+0xC0]
000071409bfd7596  vmovaps xmm13, [rsp+0xD0]
000071409bfd759f  vmovaps xmm15, [rsp+0xE0]
000071409bfd75a8  add rsp, 0xF0
000071409bfd75af  pop r11
000071409bfd75b1  pop r10
000071409bfd75b3  pop r9
000071409bfd75b5  pop r8
000071409bfd75b7  pop rsi
000071409bfd75b8  pop rdi
000071409bfd75b9  pop rdx
000071409bfd75ba  pop rcx
000071409bfd75bb  pop rax
000071409bfd75bc  add rsp, 0x08
000071409bfd75c0  jmp 0x000071409BFD6691
000071409bfd75c5  sub rsp, 0x08
000071409bfd75c9  push rax
000071409bfd75ca  push rcx
000071409bfd75cb  push rdx
000071409bfd75cc  push rdi
000071409bfd75cd  push rsi
000071409bfd75ce  push r8
000071409bfd75d0  push r9
000071409bfd75d2  push r10
000071409bfd75d4  push r11
000071409bfd75d6  sub rsp, 0xF0
000071409bfd75dd  vmovaps [rsp], xmm0
000071409bfd75e2  vmovaps [rsp+0x10], xmm1
000071409bfd75e8  vmovaps [rsp+0x20], xmm3
000071409bfd75ee  vmovaps [rsp+0x30], xmm4
000071409bfd75f4  vmovaps [rsp+0x40], xmm5
000071409bfd75fa  vmovaps [rsp+0x50], xmm6
000071409bfd7600  vmovaps [rsp+0x60], xmm7
000071409bfd7606  vmovaps [rsp+0x70], xmm8
000071409bfd760c  vmovaps [rsp+0x80], xmm9
000071409bfd7615  vmovaps [rsp+0x90], xmm10
000071409bfd761e  vmovaps [rsp+0xA0], xmm11
000071409bfd7627  vmovaps [rsp+0xB0], xmm12
000071409bfd7630  vmovaps [rsp+0xC0], xmm13
000071409bfd7639  vmovaps [rsp+0xD0], xmm14
000071409bfd7642  vmovaps [rsp+0xE0], xmm15
000071409bfd764b  sub rsp, 0x40
000071409bfd764f  lea rdi, [rsp]
000071409bfd7653  lea rsi, [rsp+0x10]
000071409bfd7658  lea rdx, [rsp+0x20]
000071409bfd765d  lea rcx, [rsp+0x30]
000071409bfd7662  mov r8d, 0x00
000071409bfd7668  lea r9, [r15+0x3A8]
000071409bfd766f  movaps [rdi], xmm2
000071409bfd7672  movaps [rsi], xmm15
000071409bfd7676  movaps [rdx], xmm12
000071409bfd767a  movaps [rcx], xmm1
000071409bfd767d  mov rax, 0x6219BEBC2A50
000071409bfd7687  call rax
000071409bfd7689  movaps xmm2, [rsp]
000071409bfd768d  add rsp, 0x40
000071409bfd7691  vmovaps xmm0, [rsp]
000071409bfd7696  vmovaps xmm1, [rsp+0x10]
000071409bfd769c  vmovaps xmm3, [rsp+0x20]
000071409bfd76a2  vmovaps xmm4, [rsp+0x30]
000071409bfd76a8  vmovaps xmm5, [rsp+0x40]
000071409bfd76ae  vmovaps xmm6, [rsp+0x50]
000071409bfd76b4  vmovaps xmm7, [rsp+0x60]
000071409bfd76ba  vmovaps xmm8, [rsp+0x70]
000071409bfd76c0  vmovaps xmm9, [rsp+0x80]
000071409bfd76c9  vmovaps xmm10, [rsp+0x90]
000071409bfd76d2  vmovaps xmm11, [rsp+0xA0]
000071409bfd76db  vmovaps xmm12, [rsp+0xB0]
000071409bfd76e4  vmovaps xmm13, [rsp+0xC0]
000071409bfd76ed  vmovaps xmm14, [rsp+0xD0]
000071409bfd76f6  vmovaps xmm15, [rsp+0xE0]
000071409bfd76ff  add rsp, 0xF0
000071409bfd7706  pop r11
000071409bfd7708  pop r10
000071409bfd770a  pop r9
000071409bfd770c  pop r8
000071409bfd770e  pop rsi
000071409bfd770f  pop rdi
000071409bfd7710  pop rdx
000071409bfd7711  pop rcx
000071409bfd7712  pop rax
000071409bfd7713  add rsp, 0x08
000071409bfd7717  jmp 0x000071409BFD66CE
000071409bfd771c  sub rsp, 0x08
000071409bfd7720  push rax
000071409bfd7721  push rcx
000071409bfd7722  push rdx
000071409bfd7723  push rdi
000071409bfd7724  push rsi
000071409bfd7725  push r8
000071409bfd7727  push r9
000071409bfd7729  push r10
000071409bfd772b  push r11
000071409bfd772d  sub rsp, 0xF0
000071409bfd7734  vmovaps [rsp], xmm0
000071409bfd7739  vmovaps [rsp+0x10], xmm1
000071409bfd773f  vmovaps [rsp+0x20], xmm2
000071409bfd7745  vmovaps [rsp+0x30], xmm3
000071409bfd774b  vmovaps [rsp+0x40], xmm4
000071409bfd7751  vmovaps [rsp+0x50], xmm5
000071409bfd7757  vmovaps [rsp+0x60], xmm6
000071409bfd775d  vmovaps [rsp+0x70], xmm7
000071409bfd7763  vmovaps [rsp+0x80], xmm8
000071409bfd776c  vmovaps [rsp+0x90], xmm9
000071409bfd7775  vmovaps [rsp+0xA0], xmm10
000071409bfd777e  vmovaps [rsp+0xB0], xmm11
000071409bfd7787  vmovaps [rsp+0xC0], xmm13
000071409bfd7790  vmovaps [rsp+0xD0], xmm14
000071409bfd7799  vmovaps [rsp+0xE0], xmm15
000071409bfd77a2  sub rsp, 0x40
000071409bfd77a6  lea rdi, [rsp]
000071409bfd77aa  lea rsi, [rsp+0x10]
000071409bfd77af  lea rdx, [rsp+0x20]
000071409bfd77b4  lea rcx, [rsp+0x30]
000071409bfd77b9  mov r8d, 0x00
000071409bfd77bf  lea r9, [r15+0x3A8]
000071409bfd77c6  movaps [rdi], xmm12
000071409bfd77ca  movaps [rsi], xmm14
000071409bfd77ce  movaps [rdx], xmm3
000071409bfd77d1  movaps [rcx], xmm15
000071409bfd77d5  mov rax, 0x6219BEBC2A50
000071409bfd77df  call rax
000071409bfd77e1  movaps xmm12, [rsp]
000071409bfd77e6  add rsp, 0x40
000071409bfd77ea  vmovaps xmm0, [rsp]
000071409bfd77ef  vmovaps xmm1, [rsp+0x10]
000071409bfd77f5  vmovaps xmm2, [rsp+0x20]
000071409bfd77fb  vmovaps xmm3, [rsp+0x30]
000071409bfd7801  vmovaps xmm4, [rsp+0x40]
000071409bfd7807  vmovaps xmm5, [rsp+0x50]
000071409bfd780d  vmovaps xmm6, [rsp+0x60]
000071409bfd7813  vmovaps xmm7, [rsp+0x70]
000071409bfd7819  vmovaps xmm8, [rsp+0x80]
000071409bfd7822  vmovaps xmm9, [rsp+0x90]
000071409bfd782b  vmovaps xmm10, [rsp+0xA0]
000071409bfd7834  vmovaps xmm11, [rsp+0xB0]
000071409bfd783d  vmovaps xmm13, [rsp+0xC0]
000071409bfd7846  vmovaps xmm14, [rsp+0xD0]
000071409bfd784f  vmovaps xmm15, [rsp+0xE0]
000071409bfd7858  add rsp, 0xF0
000071409bfd785f  pop r11
000071409bfd7861  pop r10
000071409bfd7863  pop r9
000071409bfd7865  pop r8
000071409bfd7867  pop rsi
000071409bfd7868  pop rdi
000071409bfd7869  pop rdx
000071409bfd786a  pop rcx
000071409bfd786b  pop rax
000071409bfd786c  add rsp, 0x08
000071409bfd7870  jmp 0x000071409BFD6728
000071409bfd7875  sub rsp, 0x08
000071409bfd7879  push rax
000071409bfd787a  push rcx
000071409bfd787b  push rdx
000071409bfd787c  push rdi
000071409bfd787d  push rsi
000071409bfd787e  push r8
000071409bfd7880  push r9
000071409bfd7882  push r10
000071409bfd7884  push r11
000071409bfd7886  sub rsp, 0xF0
000071409bfd788d  vmovaps [rsp], xmm0
000071409bfd7892  vmovaps [rsp+0x10], xmm1
000071409bfd7898  vmovaps [rsp+0x20], xmm2
000071409bfd789e  vmovaps [rsp+0x30], xmm3
000071409bfd78a4  vmovaps [rsp+0x40], xmm4
000071409bfd78aa  vmovaps [rsp+0x50], xmm5
000071409bfd78b0  vmovaps [rsp+0x60], xmm6
000071409bfd78b6  vmovaps [rsp+0x70], xmm7
000071409bfd78bc  vmovaps [rsp+0x80], xmm8
000071409bfd78c5  vmovaps [rsp+0x90], xmm10
000071409bfd78ce  vmovaps [rsp+0xA0], xmm11
000071409bfd78d7  vmovaps [rsp+0xB0], xmm12
000071409bfd78e0  vmovaps [rsp+0xC0], xmm13
000071409bfd78e9  vmovaps [rsp+0xD0], xmm14
000071409bfd78f2  vmovaps [rsp+0xE0], xmm15
000071409bfd78fb  sub rsp, 0x40
000071409bfd78ff  lea rdi, [rsp]
000071409bfd7903  lea rsi, [rsp+0x10]
000071409bfd7908  lea rdx, [rsp+0x20]
000071409bfd790d  lea rcx, [rsp+0x30]
000071409bfd7912  mov r8d, 0x00
000071409bfd7918  lea r9, [r15+0x3A8]
000071409bfd791f  movaps [rdi], xmm9
000071409bfd7923  movaps [rsi], xmm13
000071409bfd7927  movaps [rdx], xmm14
000071409bfd792b  movaps [rcx], xmm6
000071409bfd792e  mov rax, 0x6219BEBC2A50
000071409bfd7938  call rax
000071409bfd793a  movaps xmm9, [rsp]
000071409bfd793f  add rsp, 0x40
000071409bfd7943  vmovaps xmm0, [rsp]
000071409bfd7948  vmovaps xmm1, [rsp+0x10]
000071409bfd794e  vmovaps xmm2, [rsp+0x20]
000071409bfd7954  vmovaps xmm3, [rsp+0x30]
000071409bfd795a  vmovaps xmm4, [rsp+0x40]
000071409bfd7960  vmovaps xmm5, [rsp+0x50]
000071409bfd7966  vmovaps xmm6, [rsp+0x60]
000071409bfd796c  vmovaps xmm7, [rsp+0x70]
000071409bfd7972  vmovaps xmm8, [rsp+0x80]
000071409bfd797b  vmovaps xmm10, [rsp+0x90]
000071409bfd7984  vmovaps xmm11, [rsp+0xA0]
000071409bfd798d  vmovaps xmm12, [rsp+0xB0]
000071409bfd7996  vmovaps xmm13, [rsp+0xC0]
000071409bfd799f  vmovaps xmm14, [rsp+0xD0]
000071409bfd79a8  vmovaps xmm15, [rsp+0xE0]
000071409bfd79b1  add rsp, 0xF0
000071409bfd79b8  pop r11
000071409bfd79ba  pop r10
000071409bfd79bc  pop r9
000071409bfd79be  pop r8
000071409bfd79c0  pop rsi
000071409bfd79c1  pop rdi
000071409bfd79c2  pop rdx
000071409bfd79c3  pop rcx
000071409bfd79c4  pop rax
000071409bfd79c5  add rsp, 0x08
000071409bfd79c9  jmp 0x000071409BFD67D2
000071409bfd79ce  sub rsp, 0x08
000071409bfd79d2  push rax
000071409bfd79d3  push rcx
000071409bfd79d4  push rdx
000071409bfd79d5  push rdi
000071409bfd79d6  push rsi
000071409bfd79d7  push r8
000071409bfd79d9  push r9
000071409bfd79db  push r10
000071409bfd79dd  push r11
000071409bfd79df  sub rsp, 0xF0
000071409bfd79e6  vmovaps [rsp], xmm0
000071409bfd79eb  vmovaps [rsp+0x10], xmm1
000071409bfd79f1  vmovaps [rsp+0x20], xmm2
000071409bfd79f7  vmovaps [rsp+0x30], xmm4
000071409bfd79fd  vmovaps [rsp+0x40], xmm5
000071409bfd7a03  vmovaps [rsp+0x50], xmm6
000071409bfd7a09  vmovaps [rsp+0x60], xmm7
000071409bfd7a0f  vmovaps [rsp+0x70], xmm8
000071409bfd7a15  vmovaps [rsp+0x80], xmm9
000071409bfd7a1e  vmovaps [rsp+0x90], xmm10
000071409bfd7a27  vmovaps [rsp+0xA0], xmm11
000071409bfd7a30  vmovaps [rsp+0xB0], xmm12
000071409bfd7a39  vmovaps [rsp+0xC0], xmm13
000071409bfd7a42  vmovaps [rsp+0xD0], xmm14
000071409bfd7a4b  vmovaps [rsp+0xE0], xmm15
000071409bfd7a54  sub rsp, 0x40
000071409bfd7a58  lea rdi, [rsp]
000071409bfd7a5c  lea rsi, [rsp+0x10]
000071409bfd7a61  lea rdx, [rsp+0x20]
000071409bfd7a66  lea rcx, [rsp+0x30]
000071409bfd7a6b  mov r8d, 0x00
000071409bfd7a71  lea r9, [r15+0x3A8]
000071409bfd7a78  movaps [rdi], xmm3
000071409bfd7a7b  movaps [rsi], xmm13
000071409bfd7a7f  movaps [rdx], xmm6
000071409bfd7a82  movaps [rcx], xmm14
000071409bfd7a86  mov rax, 0x6219BEBC2A50
000071409bfd7a90  call rax
000071409bfd7a92  movaps xmm3, [rsp]
000071409bfd7a96  add rsp, 0x40
000071409bfd7a9a  vmovaps xmm0, [rsp]
000071409bfd7a9f  vmovaps xmm1, [rsp+0x10]
000071409bfd7aa5  vmovaps xmm2, [rsp+0x20]
000071409bfd7aab  vmovaps xmm4, [rsp+0x30]
000071409bfd7ab1  vmovaps xmm5, [rsp+0x40]
000071409bfd7ab7  vmovaps xmm6, [rsp+0x50]
000071409bfd7abd  vmovaps xmm7, [rsp+0x60]
000071409bfd7ac3  vmovaps xmm8, [rsp+0x70]
000071409bfd7ac9  vmovaps xmm9, [rsp+0x80]
000071409bfd7ad2  vmovaps xmm10, [rsp+0x90]
000071409bfd7adb  vmovaps xmm11, [rsp+0xA0]
000071409bfd7ae4  vmovaps xmm12, [rsp+0xB0]
000071409bfd7aed  vmovaps xmm13, [rsp+0xC0]
000071409bfd7af6  vmovaps xmm14, [rsp+0xD0]
000071409bfd7aff  vmovaps xmm15, [rsp+0xE0]
000071409bfd7b08  add rsp, 0xF0
000071409bfd7b0f  pop r11
000071409bfd7b11  pop r10
000071409bfd7b13  pop r9
000071409bfd7b15  pop r8
000071409bfd7b17  pop rsi
000071409bfd7b18  pop rdi
000071409bfd7b19  pop rdx
000071409bfd7b1a  pop rcx
000071409bfd7b1b  pop rax
000071409bfd7b1c  add rsp, 0x08
000071409bfd7b20  jmp 0x000071409BFD680F
000071409bfd7b25  sub rsp, 0x08
000071409bfd7b29  push rax
000071409bfd7b2a  push rcx
000071409bfd7b2b  push rdx
000071409bfd7b2c  push rdi
000071409bfd7b2d  push rsi
000071409bfd7b2e  push r8
000071409bfd7b30  push r9
000071409bfd7b32  push r10
000071409bfd7b34  push r11
000071409bfd7b36  sub rsp, 0xF0
000071409bfd7b3d  vmovaps [rsp], xmm0
000071409bfd7b42  vmovaps [rsp+0x10], xmm1
000071409bfd7b48  vmovaps [rsp+0x20], xmm2
000071409bfd7b4e  vmovaps [rsp+0x30], xmm3
000071409bfd7b54  vmovaps [rsp+0x40], xmm4
000071409bfd7b5a  vmovaps [rsp+0x50], xmm5
000071409bfd7b60  vmovaps [rsp+0x60], xmm7
000071409bfd7b66  vmovaps [rsp+0x70], xmm8
000071409bfd7b6c  vmovaps [rsp+0x80], xmm9
000071409bfd7b75  vmovaps [rsp+0x90], xmm10
000071409bfd7b7e  vmovaps [rsp+0xA0], xmm11
000071409bfd7b87  vmovaps [rsp+0xB0], xmm12
000071409bfd7b90  vmovaps [rsp+0xC0], xmm13
000071409bfd7b99  vmovaps [rsp+0xD0], xmm14
000071409bfd7ba2  vmovaps [rsp+0xE0], xmm15
000071409bfd7bab  sub rsp, 0x40
000071409bfd7baf  lea rdi, [rsp]
000071409bfd7bb3  lea rsi, [rsp+0x10]
000071409bfd7bb8  lea rdx, [rsp+0x20]
000071409bfd7bbd  lea rcx, [rsp+0x30]
000071409bfd7bc2  mov r8d, 0x00
000071409bfd7bc8  lea r9, [r15+0x3A8]
000071409bfd7bcf  movaps [rdi], xmm6
000071409bfd7bd2  movaps [rsi], xmm2
000071409bfd7bd5  movaps [rdx], xmm14
000071409bfd7bd9  movaps [rcx], xmm1
000071409bfd7bdc  mov rax, 0x6219BEBC2A50
000071409bfd7be6  call rax
000071409bfd7be8  movaps xmm6, [rsp]
000071409bfd7bec  add rsp, 0x40
000071409bfd7bf0  vmovaps xmm0, [rsp]
000071409bfd7bf5  vmovaps xmm1, [rsp+0x10]
000071409bfd7bfb  vmovaps xmm2, [rsp+0x20]
000071409bfd7c01  vmovaps xmm3, [rsp+0x30]
000071409bfd7c07  vmovaps xmm4, [rsp+0x40]
000071409bfd7c0d  vmovaps xmm5, [rsp+0x50]
000071409bfd7c13  vmovaps xmm7, [rsp+0x60]
000071409bfd7c19  vmovaps xmm8, [rsp+0x70]
000071409bfd7c1f  vmovaps xmm9, [rsp+0x80]
000071409bfd7c28  vmovaps xmm10, [rsp+0x90]
000071409bfd7c31  vmovaps xmm11, [rsp+0xA0]
000071409bfd7c3a  vmovaps xmm12, [rsp+0xB0]
000071409bfd7c43  vmovaps xmm13, [rsp+0xC0]
000071409bfd7c4c  vmovaps xmm14, [rsp+0xD0]
000071409bfd7c55  vmovaps xmm15, [rsp+0xE0]
000071409bfd7c5e  add rsp, 0xF0
000071409bfd7c65  pop r11
000071409bfd7c67  pop r10
000071409bfd7c69  pop r9
000071409bfd7c6b  pop r8
000071409bfd7c6d  pop rsi
000071409bfd7c6e  pop rdi
000071409bfd7c6f  pop rdx
000071409bfd7c70  pop rcx
000071409bfd7c71  pop rax
000071409bfd7c72  add rsp, 0x08
000071409bfd7c76  jmp 0x000071409BFD683C
000071409bfd7c7b  sub rsp, 0x08
000071409bfd7c7f  push rax
000071409bfd7c80  push rcx
000071409bfd7c81  push rdx
000071409bfd7c82  push rdi
000071409bfd7c83  push rsi
000071409bfd7c84  push r8
000071409bfd7c86  push r9
000071409bfd7c88  push r10
000071409bfd7c8a  push r11
000071409bfd7c8c  sub rsp, 0xF0
000071409bfd7c93  vmovaps [rsp], xmm0
000071409bfd7c98  vmovaps [rsp+0x10], xmm1
000071409bfd7c9e  vmovaps [rsp+0x20], xmm2
000071409bfd7ca4  vmovaps [rsp+0x30], xmm3
000071409bfd7caa  vmovaps [rsp+0x40], xmm4
000071409bfd7cb0  vmovaps [rsp+0x50], xmm5
000071409bfd7cb6  vmovaps [rsp+0x60], xmm6
000071409bfd7cbc  vmovaps [rsp+0x70], xmm7
000071409bfd7cc2  vmovaps [rsp+0x80], xmm8
000071409bfd7ccb  vmovaps [rsp+0x90], xmm9
000071409bfd7cd4  vmovaps [rsp+0xA0], xmm10
000071409bfd7cdd  vmovaps [rsp+0xB0], xmm11
000071409bfd7ce6  vmovaps [rsp+0xC0], xmm12
000071409bfd7cef  vmovaps [rsp+0xD0], xmm14
000071409bfd7cf8  vmovaps [rsp+0xE0], xmm15
000071409bfd7d01  sub rsp, 0x40
000071409bfd7d05  lea rdi, [rsp]
000071409bfd7d09  lea rsi, [rsp+0x10]
000071409bfd7d0e  lea rdx, [rsp+0x20]
000071409bfd7d13  lea rcx, [rsp+0x30]
000071409bfd7d18  mov r8d, 0x00
000071409bfd7d1e  lea r9, [r15+0x3A8]
000071409bfd7d25  movaps [rdi], xmm13
000071409bfd7d29  movaps [rsi], xmm12
000071409bfd7d2d  movaps [rdx], xmm14
000071409bfd7d31  movaps [rcx], xmm1
000071409bfd7d34  mov rax, 0x6219BEBC2A50
000071409bfd7d3e  call rax
000071409bfd7d40  movaps xmm13, [rsp]
000071409bfd7d45  add rsp, 0x40
000071409bfd7d49  vmovaps xmm0, [rsp]
000071409bfd7d4e  vmovaps xmm1, [rsp+0x10]
000071409bfd7d54  vmovaps xmm2, [rsp+0x20]
000071409bfd7d5a  vmovaps xmm3, [rsp+0x30]
000071409bfd7d60  vmovaps xmm4, [rsp+0x40]
000071409bfd7d66  vmovaps xmm5, [rsp+0x50]
000071409bfd7d6c  vmovaps xmm6, [rsp+0x60]
000071409bfd7d72  vmovaps xmm7, [rsp+0x70]
000071409bfd7d78  vmovaps xmm8, [rsp+0x80]
000071409bfd7d81  vmovaps xmm9, [rsp+0x90]
000071409bfd7d8a  vmovaps xmm10, [rsp+0xA0]
000071409bfd7d93  vmovaps xmm11, [rsp+0xB0]
000071409bfd7d9c  vmovaps xmm12, [rsp+0xC0]
000071409bfd7da5  vmovaps xmm14, [rsp+0xD0]
000071409bfd7dae  vmovaps xmm15, [rsp+0xE0]
000071409bfd7db7  add rsp, 0xF0
000071409bfd7dbe  pop r11
000071409bfd7dc0  pop r10
000071409bfd7dc2  pop r9
000071409bfd7dc4  pop r8
000071409bfd7dc6  pop rsi
000071409bfd7dc7  pop rdi
000071409bfd7dc8  pop rdx
000071409bfd7dc9  pop rcx
000071409bfd7dca  pop rax
000071409bfd7dcb  add rsp, 0x08
000071409bfd7dcf  jmp 0x000071409BFD686E
000071409bfd7dd4  sub rsp, 0x08
000071409bfd7dd8  push rax
000071409bfd7dd9  push rcx
000071409bfd7dda  push rdx
000071409bfd7ddb  push rdi
000071409bfd7ddc  push rsi
000071409bfd7ddd  push r8
000071409bfd7ddf  push r9
000071409bfd7de1  push r10
000071409bfd7de3  push r11
000071409bfd7de5  sub rsp, 0xF0
000071409bfd7dec  vmovaps [rsp], xmm0
000071409bfd7df1  vmovaps [rsp+0x10], xmm1
000071409bfd7df7  vmovaps [rsp+0x20], xmm2
000071409bfd7dfd  vmovaps [rsp+0x30], xmm3
000071409bfd7e03  vmovaps [rsp+0x40], xmm4
000071409bfd7e09  vmovaps [rsp+0x50], xmm5
000071409bfd7e0f  vmovaps [rsp+0x60], xmm6
000071409bfd7e15  vmovaps [rsp+0x70], xmm7
000071409bfd7e1b  vmovaps [rsp+0x80], xmm8
000071409bfd7e24  vmovaps [rsp+0x90], xmm9
000071409bfd7e2d  vmovaps [rsp+0xA0], xmm10
000071409bfd7e36  vmovaps [rsp+0xB0], xmm11
000071409bfd7e3f  vmovaps [rsp+0xC0], xmm13
000071409bfd7e48  vmovaps [rsp+0xD0], xmm14
000071409bfd7e51  vmovaps [rsp+0xE0], xmm15
000071409bfd7e5a  sub rsp, 0x40
000071409bfd7e5e  lea rdi, [rsp]
000071409bfd7e62  lea rsi, [rsp+0x10]
000071409bfd7e67  lea rdx, [rsp+0x20]
000071409bfd7e6c  lea rcx, [rsp+0x30]
000071409bfd7e71  mov r8d, 0x00
000071409bfd7e77  lea r9, [r15+0x3A8]
000071409bfd7e7e  movaps [rdi], xmm12
000071409bfd7e82  movaps [rsi], xmm3
000071409bfd7e85  movaps [rdx], xmm14
000071409bfd7e89  movaps [rcx], xmm5
000071409bfd7e8c  mov rax, 0x6219BEBC2A50
000071409bfd7e96  call rax
000071409bfd7e98  movaps xmm12, [rsp]
000071409bfd7e9d  add rsp, 0x40
000071409bfd7ea1  vmovaps xmm0, [rsp]
000071409bfd7ea6  vmovaps xmm1, [rsp+0x10]
000071409bfd7eac  vmovaps xmm2, [rsp+0x20]
000071409bfd7eb2  vmovaps xmm3, [rsp+0x30]
000071409bfd7eb8  vmovaps xmm4, [rsp+0x40]
000071409bfd7ebe  vmovaps xmm5, [rsp+0x50]
000071409bfd7ec4  vmovaps xmm6, [rsp+0x60]
000071409bfd7eca  vmovaps xmm7, [rsp+0x70]
000071409bfd7ed0  vmovaps xmm8, [rsp+0x80]
000071409bfd7ed9  vmovaps xmm9, [rsp+0x90]
000071409bfd7ee2  vmovaps xmm10, [rsp+0xA0]
000071409bfd7eeb  vmovaps xmm11, [rsp+0xB0]
000071409bfd7ef4  vmovaps xmm13, [rsp+0xC0]
000071409bfd7efd  vmovaps xmm14, [rsp+0xD0]
000071409bfd7f06  vmovaps xmm15, [rsp+0xE0]
000071409bfd7f0f  add rsp, 0xF0
000071409bfd7f16  pop r11
000071409bfd7f18  pop r10
000071409bfd7f1a  pop r9
000071409bfd7f1c  pop r8
000071409bfd7f1e  pop rsi
000071409bfd7f1f  pop rdi
000071409bfd7f20  pop rdx
000071409bfd7f21  pop rcx
000071409bfd7f22  pop rax
000071409bfd7f23  add rsp, 0x08
000071409bfd7f27  jmp 0x000071409BFD68CB
000071409bfd7f2c  sub rsp, 0x08
000071409bfd7f30  push rax
000071409bfd7f31  push rcx
000071409bfd7f32  push rdx
000071409bfd7f33  push rdi
000071409bfd7f34  push rsi
000071409bfd7f35  push r8
000071409bfd7f37  push r9
000071409bfd7f39  push r10
000071409bfd7f3b  push r11
000071409bfd7f3d  sub rsp, 0xF0
000071409bfd7f44  vmovaps [rsp], xmm0
000071409bfd7f49  vmovaps [rsp+0x10], xmm1
000071409bfd7f4f  vmovaps [rsp+0x20], xmm2
000071409bfd7f55  vmovaps [rsp+0x30], xmm3
000071409bfd7f5b  vmovaps [rsp+0x40], xmm4
000071409bfd7f61  vmovaps [rsp+0x50], xmm5
000071409bfd7f67  vmovaps [rsp+0x60], xmm6
000071409bfd7f6d  vmovaps [rsp+0x70], xmm7
000071409bfd7f73  vmovaps [rsp+0x80], xmm8
000071409bfd7f7c  vmovaps [rsp+0x90], xmm9
000071409bfd7f85  vmovaps [rsp+0xA0], xmm11
000071409bfd7f8e  vmovaps [rsp+0xB0], xmm12
000071409bfd7f97  vmovaps [rsp+0xC0], xmm13
000071409bfd7fa0  vmovaps [rsp+0xD0], xmm14
000071409bfd7fa9  vmovaps [rsp+0xE0], xmm15
000071409bfd7fb2  sub rsp, 0x40
000071409bfd7fb6  lea rdi, [rsp]
000071409bfd7fba  lea rsi, [rsp+0x10]
000071409bfd7fbf  lea rdx, [rsp+0x20]
000071409bfd7fc4  lea rcx, [rsp+0x30]
000071409bfd7fc9  mov r8d, 0x00
000071409bfd7fcf  lea r9, [r15+0x3A8]
000071409bfd7fd6  movaps [rdi], xmm10
000071409bfd7fda  movaps [rsi], xmm9
000071409bfd7fde  movaps [rdx], xmm7
000071409bfd7fe1  movaps [rcx], xmm14
000071409bfd7fe5  mov rax, 0x6219BEBC2A50
000071409bfd7fef  call rax
000071409bfd7ff1  movaps xmm10, [rsp]
000071409bfd7ff6  add rsp, 0x40
000071409bfd7ffa  vmovaps xmm0, [rsp]
000071409bfd7fff  vmovaps xmm1, [rsp+0x10]
000071409bfd8005  vmovaps xmm2, [rsp+0x20]
000071409bfd800b  vmovaps xmm3, [rsp+0x30]
000071409bfd8011  vmovaps xmm4, [rsp+0x40]
000071409bfd8017  vmovaps xmm5, [rsp+0x50]
000071409bfd801d  vmovaps xmm6, [rsp+0x60]
000071409bfd8023  vmovaps xmm7, [rsp+0x70]
000071409bfd8029  vmovaps xmm8, [rsp+0x80]
000071409bfd8032  vmovaps xmm9, [rsp+0x90]
000071409bfd803b  vmovaps xmm11, [rsp+0xA0]
000071409bfd8044  vmovaps xmm12, [rsp+0xB0]
000071409bfd804d  vmovaps xmm13, [rsp+0xC0]
000071409bfd8056  vmovaps xmm14, [rsp+0xD0]
000071409bfd805f  vmovaps xmm15, [rsp+0xE0]
000071409bfd8068  add rsp, 0xF0
000071409bfd806f  pop r11
000071409bfd8071  pop r10
000071409bfd8073  pop r9
000071409bfd8075  pop r8
000071409bfd8077  pop rsi
000071409bfd8078  pop rdi
000071409bfd8079  pop rdx
000071409bfd807a  pop rcx
000071409bfd807b  pop rax
000071409bfd807c  add rsp, 0x08
000071409bfd8080  jmp 0x000071409BFD68F1
000071409bfd8085  call 0x000071409BEE45A0
000071409bfd808a  jmp 0x000071409BFD68FE
000071409bfd808f  sub rsp, 0x08
000071409bfd8093  push rax
000071409bfd8094  push rcx
000071409bfd8095  push rdx
000071409bfd8096  push rdi
000071409bfd8097  push rsi
000071409bfd8098  push r8
000071409bfd809a  push r9
000071409bfd809c  push r10
000071409bfd809e  push r11
000071409bfd80a0  sub rsp, 0xF0
000071409bfd80a7  vmovaps [rsp], xmm0
000071409bfd80ac  vmovaps [rsp+0x10], xmm1
000071409bfd80b2  vmovaps [rsp+0x20], xmm2
000071409bfd80b8  vmovaps [rsp+0x30], xmm3
000071409bfd80be  vmovaps [rsp+0x40], xmm4
000071409bfd80c4  vmovaps [rsp+0x50], xmm6
000071409bfd80ca  vmovaps [rsp+0x60], xmm7
000071409bfd80d0  vmovaps [rsp+0x70], xmm8
000071409bfd80d6  vmovaps [rsp+0x80], xmm9
000071409bfd80df  vmovaps [rsp+0x90], xmm10
000071409bfd80e8  vmovaps [rsp+0xA0], xmm11
000071409bfd80f1  vmovaps [rsp+0xB0], xmm12
000071409bfd80fa  vmovaps [rsp+0xC0], xmm13
000071409bfd8103  vmovaps [rsp+0xD0], xmm14
000071409bfd810c  vmovaps [rsp+0xE0], xmm15
000071409bfd8115  sub rsp, 0x40
000071409bfd8119  lea rdi, [rsp]
000071409bfd811d  lea rsi, [rsp+0x10]
000071409bfd8122  lea rdx, [rsp+0x20]
000071409bfd8127  lea rcx, [rsp+0x30]
000071409bfd812c  mov r8d, 0x00
000071409bfd8132  lea r9, [r15+0x3A8]
000071409bfd8139  movaps [rdi], xmm5
000071409bfd813c  movaps [rsi], xmm6
000071409bfd813f  movaps [rdx], xmm7
000071409bfd8142  movaps [rcx], xmm9
000071409bfd8146  mov rax, 0x6219BEBC2A50
000071409bfd8150  call rax
000071409bfd8152  movaps xmm5, [rsp]
000071409bfd8156  add rsp, 0x40
000071409bfd815a  vmovaps xmm0, [rsp]
000071409bfd815f  vmovaps xmm1, [rsp+0x10]
000071409bfd8165  vmovaps xmm2, [rsp+0x20]
000071409bfd816b  vmovaps xmm3, [rsp+0x30]
000071409bfd8171  vmovaps xmm4, [rsp+0x40]
000071409bfd8177  vmovaps xmm6, [rsp+0x50]
000071409bfd817d  vmovaps xmm7, [rsp+0x60]
000071409bfd8183  vmovaps xmm8, [rsp+0x70]
000071409bfd8189  vmovaps xmm9, [rsp+0x80]
000071409bfd8192  vmovaps xmm10, [rsp+0x90]
000071409bfd819b  vmovaps xmm11, [rsp+0xA0]
000071409bfd81a4  vmovaps xmm12, [rsp+0xB0]
000071409bfd81ad  vmovaps xmm13, [rsp+0xC0]
000071409bfd81b6  vmovaps xmm14, [rsp+0xD0]
000071409bfd81bf  vmovaps xmm15, [rsp+0xE0]
000071409bfd81c8  add rsp, 0xF0
000071409bfd81cf  pop r11
000071409bfd81d1  pop r10
000071409bfd81d3  pop r9
000071409bfd81d5  pop r8
000071409bfd81d7  pop rsi
000071409bfd81d8  pop rdi
000071409bfd81d9  pop rdx
000071409bfd81da  pop rcx
000071409bfd81db  pop rax
000071409bfd81dc  add rsp, 0x08
000071409bfd81e0  jmp 0x000071409BFD6930
000071409bfd81e5  sub rsp, 0x08
000071409bfd81e9  push rax
000071409bfd81ea  push rcx
000071409bfd81eb  push rdx
000071409bfd81ec  push rdi
000071409bfd81ed  push rsi
000071409bfd81ee  push r8
000071409bfd81f0  push r9
000071409bfd81f2  push r10
000071409bfd81f4  push r11
000071409bfd81f6  sub rsp, 0xF0
000071409bfd81fd  vmovaps [rsp], xmm0
000071409bfd8202  vmovaps [rsp+0x10], xmm1
000071409bfd8208  vmovaps [rsp+0x20], xmm2
000071409bfd820e  vmovaps [rsp+0x30], xmm3
000071409bfd8214  vmovaps [rsp+0x40], xmm4
000071409bfd821a  vmovaps [rsp+0x50], xmm5
000071409bfd8220  vmovaps [rsp+0x60], xmm6
000071409bfd8226  vmovaps [rsp+0x70], xmm8
000071409bfd822c  vmovaps [rsp+0x80], xmm9
000071409bfd8235  vmovaps [rsp+0x90], xmm10
000071409bfd823e  vmovaps [rsp+0xA0], xmm11
000071409bfd8247  vmovaps [rsp+0xB0], xmm12
000071409bfd8250  vmovaps [rsp+0xC0], xmm13
000071409bfd8259  vmovaps [rsp+0xD0], xmm14
000071409bfd8262  vmovaps [rsp+0xE0], xmm15
000071409bfd826b  sub rsp, 0x40
000071409bfd826f  lea rdi, [rsp]
000071409bfd8273  lea rsi, [rsp+0x10]
000071409bfd8278  lea rdx, [rsp+0x20]
000071409bfd827d  lea rcx, [rsp+0x30]
000071409bfd8282  mov r8d, 0x00
000071409bfd8288  lea r9, [r15+0x3A8]
000071409bfd828f  movaps [rdi], xmm7
000071409bfd8292  movaps [rsi], xmm13
000071409bfd8296  movaps [rdx], xmm1
000071409bfd8299  movaps [rcx], xmm9
000071409bfd829d  mov rax, 0x6219BEBC2A50
000071409bfd82a7  call rax
000071409bfd82a9  movaps xmm7, [rsp]
000071409bfd82ad  add rsp, 0x40
000071409bfd82b1  vmovaps xmm0, [rsp]
000071409bfd82b6  vmovaps xmm1, [rsp+0x10]
000071409bfd82bc  vmovaps xmm2, [rsp+0x20]
000071409bfd82c2  vmovaps xmm3, [rsp+0x30]
000071409bfd82c8  vmovaps xmm4, [rsp+0x40]
000071409bfd82ce  vmovaps xmm5, [rsp+0x50]
000071409bfd82d4  vmovaps xmm6, [rsp+0x60]
000071409bfd82da  vmovaps xmm8, [rsp+0x70]
000071409bfd82e0  vmovaps xmm9, [rsp+0x80]
000071409bfd82e9  vmovaps xmm10, [rsp+0x90]
000071409bfd82f2  vmovaps xmm11, [rsp+0xA0]
000071409bfd82fb  vmovaps xmm12, [rsp+0xB0]
000071409bfd8304  vmovaps xmm13, [rsp+0xC0]
000071409bfd830d  vmovaps xmm14, [rsp+0xD0]
000071409bfd8316  vmovaps xmm15, [rsp+0xE0]
000071409bfd831f  add rsp, 0xF0
000071409bfd8326  pop r11
000071409bfd8328  pop r10
000071409bfd832a  pop r9
000071409bfd832c  pop r8
000071409bfd832e  pop rsi
000071409bfd832f  pop rdi
000071409bfd8330  pop rdx
000071409bfd8331  pop rcx
000071409bfd8332  pop rax
000071409bfd8333  add rsp, 0x08
000071409bfd8337  jmp 0x000071409BFD6955
000071409bfd833c  call 0x000071409BEE3320
000071409bfd8341  jmp 0x000071409BFD6978
000071409bfd8346  call 0x000071409BEDE950
000071409bfd834b  jmp 0x000071409BFD6982
000071409bfd8350  sub rsp, 0x08
000071409bfd8354  push rax
000071409bfd8355  push rcx
000071409bfd8356  push rdx
000071409bfd8357  push rdi
000071409bfd8358  push rsi
000071409bfd8359  push r8
000071409bfd835b  push r9
000071409bfd835d  push r10
000071409bfd835f  push r11
000071409bfd8361  sub rsp, 0xF0
000071409bfd8368  vmovaps [rsp], xmm0
000071409bfd836d  vmovaps [rsp+0x10], xmm1
000071409bfd8373  vmovaps [rsp+0x20], xmm3
000071409bfd8379  vmovaps [rsp+0x30], xmm4
000071409bfd837f  vmovaps [rsp+0x40], xmm5
000071409bfd8385  vmovaps [rsp+0x50], xmm6
000071409bfd838b  vmovaps [rsp+0x60], xmm7
000071409bfd8391  vmovaps [rsp+0x70], xmm8
000071409bfd8397  vmovaps [rsp+0x80], xmm9
000071409bfd83a0  vmovaps [rsp+0x90], xmm10
000071409bfd83a9  vmovaps [rsp+0xA0], xmm11
000071409bfd83b2  vmovaps [rsp+0xB0], xmm12
000071409bfd83bb  vmovaps [rsp+0xC0], xmm13
000071409bfd83c4  vmovaps [rsp+0xD0], xmm14
000071409bfd83cd  vmovaps [rsp+0xE0], xmm15
000071409bfd83d6  sub rsp, 0x40
000071409bfd83da  lea rdi, [rsp]
000071409bfd83de  lea rsi, [rsp+0x10]
000071409bfd83e3  lea rdx, [rsp+0x20]
000071409bfd83e8  lea rcx, [rsp+0x30]
000071409bfd83ed  mov r8d, 0x00
000071409bfd83f3  lea r9, [r15+0x3A8]
000071409bfd83fa  movaps [rdi], xmm2
000071409bfd83fd  movaps [rsi], xmm12
000071409bfd8401  movaps [rdx], xmm6
000071409bfd8404  movaps [rcx], xmm3
000071409bfd8407  mov rax, 0x6219BEBC2A50
000071409bfd8411  call rax
000071409bfd8413  movaps xmm2, [rsp]
000071409bfd8417  add rsp, 0x40
000071409bfd841b  vmovaps xmm0, [rsp]
000071409bfd8420  vmovaps xmm1, [rsp+0x10]
000071409bfd8426  vmovaps xmm3, [rsp+0x20]
000071409bfd842c  vmovaps xmm4, [rsp+0x30]
000071409bfd8432  vmovaps xmm5, [rsp+0x40]
000071409bfd8438  vmovaps xmm6, [rsp+0x50]
000071409bfd843e  vmovaps xmm7, [rsp+0x60]
000071409bfd8444  vmovaps xmm8, [rsp+0x70]
000071409bfd844a  vmovaps xmm9, [rsp+0x80]
000071409bfd8453  vmovaps xmm10, [rsp+0x90]
000071409bfd845c  vmovaps xmm11, [rsp+0xA0]
000071409bfd8465  vmovaps xmm12, [rsp+0xB0]
000071409bfd846e  vmovaps xmm13, [rsp+0xC0]
000071409bfd8477  vmovaps xmm14, [rsp+0xD0]
000071409bfd8480  vmovaps xmm15, [rsp+0xE0]
000071409bfd8489  add rsp, 0xF0
000071409bfd8490  pop r11
000071409bfd8492  pop r10
000071409bfd8494  pop r9
000071409bfd8496  pop r8
000071409bfd8498  pop rsi
000071409bfd8499  pop rdi
000071409bfd849a  pop rdx
000071409bfd849b  pop rcx
000071409bfd849c  pop rax
000071409bfd849d  add rsp, 0x08
000071409bfd84a1  jmp 0x000071409BFD69C8
000071409bfd84a6  sub rsp, 0x08
000071409bfd84aa  push rax
000071409bfd84ab  push rcx
000071409bfd84ac  push rdx
000071409bfd84ad  push rdi
000071409bfd84ae  push rsi
000071409bfd84af  push r8
000071409bfd84b1  push r9
000071409bfd84b3  push r10
000071409bfd84b5  push r11
000071409bfd84b7  sub rsp, 0xF0
000071409bfd84be  vmovaps [rsp], xmm0
000071409bfd84c3  vmovaps [rsp+0x10], xmm1
000071409bfd84c9  vmovaps [rsp+0x20], xmm2
000071409bfd84cf  vmovaps [rsp+0x30], xmm3
000071409bfd84d5  vmovaps [rsp+0x40], xmm4
000071409bfd84db  vmovaps [rsp+0x50], xmm5
000071409bfd84e1  vmovaps [rsp+0x60], xmm7
000071409bfd84e7  vmovaps [rsp+0x70], xmm8
000071409bfd84ed  vmovaps [rsp+0x80], xmm9
000071409bfd84f6  vmovaps [rsp+0x90], xmm10
000071409bfd84ff  vmovaps [rsp+0xA0], xmm11
000071409bfd8508  vmovaps [rsp+0xB0], xmm12
000071409bfd8511  vmovaps [rsp+0xC0], xmm13
000071409bfd851a  vmovaps [rsp+0xD0], xmm14
000071409bfd8523  vmovaps [rsp+0xE0], xmm15
000071409bfd852c  sub rsp, 0x40
000071409bfd8530  lea rdi, [rsp]
000071409bfd8534  lea rsi, [rsp+0x10]
000071409bfd8539  lea rdx, [rsp+0x20]
000071409bfd853e  lea rcx, [rsp+0x30]
000071409bfd8543  mov r8d, 0x00
000071409bfd8549  lea r9, [r15+0x3A8]
000071409bfd8550  movaps [rdi], xmm6
000071409bfd8553  movaps [rsi], xmm10
000071409bfd8557  movaps [rdx], xmm12
000071409bfd855b  movaps [rcx], xmm1
000071409bfd855e  mov rax, 0x6219BEBC2A50
000071409bfd8568  call rax
000071409bfd856a  movaps xmm6, [rsp]
000071409bfd856e  add rsp, 0x40
000071409bfd8572  vmovaps xmm0, [rsp]
000071409bfd8577  vmovaps xmm1, [rsp+0x10]
000071409bfd857d  vmovaps xmm2, [rsp+0x20]
000071409bfd8583  vmovaps xmm3, [rsp+0x30]
000071409bfd8589  vmovaps xmm4, [rsp+0x40]
000071409bfd858f  vmovaps xmm5, [rsp+0x50]
000071409bfd8595  vmovaps xmm7, [rsp+0x60]
000071409bfd859b  vmovaps xmm8, [rsp+0x70]
000071409bfd85a1  vmovaps xmm9, [rsp+0x80]
000071409bfd85aa  vmovaps xmm10, [rsp+0x90]
000071409bfd85b3  vmovaps xmm11, [rsp+0xA0]
000071409bfd85bc  vmovaps xmm12, [rsp+0xB0]
000071409bfd85c5  vmovaps xmm13, [rsp+0xC0]
000071409bfd85ce  vmovaps xmm14, [rsp+0xD0]
000071409bfd85d7  vmovaps xmm15, [rsp+0xE0]
000071409bfd85e0  add rsp, 0xF0
000071409bfd85e7  pop r11
000071409bfd85e9  pop r10
000071409bfd85eb  pop r9
000071409bfd85ed  pop r8
000071409bfd85ef  pop rsi
000071409bfd85f0  pop rdi
000071409bfd85f1  pop rdx
000071409bfd85f2  pop rcx
000071409bfd85f3  pop rax
000071409bfd85f4  add rsp, 0x08
000071409bfd85f8  jmp 0x000071409BFD69F6
000071409bfd85fd  sub rsp, 0x08
000071409bfd8601  push rax
000071409bfd8602  push rcx
000071409bfd8603  push rdx
000071409bfd8604  push rdi
000071409bfd8605  push rsi
000071409bfd8606  push r8
000071409bfd8608  push r9
000071409bfd860a  push r10
000071409bfd860c  push r11
000071409bfd860e  sub rsp, 0xF0
000071409bfd8615  vmovaps [rsp], xmm0
000071409bfd861a  vmovaps [rsp+0x10], xmm1
000071409bfd8620  vmovaps [rsp+0x20], xmm2
000071409bfd8626  vmovaps [rsp+0x30], xmm3
000071409bfd862c  vmovaps [rsp+0x40], xmm4
000071409bfd8632  vmovaps [rsp+0x50], xmm5
000071409bfd8638  vmovaps [rsp+0x60], xmm6
000071409bfd863e  vmovaps [rsp+0x70], xmm7
000071409bfd8644  vmovaps [rsp+0x80], xmm8
000071409bfd864d  vmovaps [rsp+0x90], xmm9
000071409bfd8656  vmovaps [rsp+0xA0], xmm11
000071409bfd865f  vmovaps [rsp+0xB0], xmm12
000071409bfd8668  vmovaps [rsp+0xC0], xmm13
000071409bfd8671  vmovaps [rsp+0xD0], xmm14
000071409bfd867a  vmovaps [rsp+0xE0], xmm15
000071409bfd8683  sub rsp, 0x40
000071409bfd8687  lea rdi, [rsp]
000071409bfd868b  lea rsi, [rsp+0x10]
000071409bfd8690  lea rdx, [rsp+0x20]
000071409bfd8695  lea rcx, [rsp+0x30]
000071409bfd869a  mov r8d, 0x00
000071409bfd86a0  lea r9, [r15+0x3A8]
000071409bfd86a7  movaps [rdi], xmm10
000071409bfd86ab  movaps [rsi], xmm5
000071409bfd86ae  movaps [rdx], xmm12
000071409bfd86b2  movaps [rcx], xmm1
000071409bfd86b5  mov rax, 0x6219BEBC2A50
000071409bfd86bf  call rax
000071409bfd86c1  movaps xmm10, [rsp]
000071409bfd86c6  add rsp, 0x40
000071409bfd86ca  vmovaps xmm0, [rsp]
000071409bfd86cf  vmovaps xmm1, [rsp+0x10]
000071409bfd86d5  vmovaps xmm2, [rsp+0x20]
000071409bfd86db  vmovaps xmm3, [rsp+0x30]
000071409bfd86e1  vmovaps xmm4, [rsp+0x40]
000071409bfd86e7  vmovaps xmm5, [rsp+0x50]
000071409bfd86ed  vmovaps xmm6, [rsp+0x60]
000071409bfd86f3  vmovaps xmm7, [rsp+0x70]
000071409bfd86f9  vmovaps xmm8, [rsp+0x80]
000071409bfd8702  vmovaps xmm9, [rsp+0x90]
000071409bfd870b  vmovaps xmm11, [rsp+0xA0]
000071409bfd8714  vmovaps xmm12, [rsp+0xB0]
000071409bfd871d  vmovaps xmm13, [rsp+0xC0]
000071409bfd8726  vmovaps xmm14, [rsp+0xD0]
000071409bfd872f  vmovaps xmm15, [rsp+0xE0]
000071409bfd8738  add rsp, 0xF0
000071409bfd873f  pop r11
000071409bfd8741  pop r10
000071409bfd8743  pop r9
000071409bfd8745  pop r8
000071409bfd8747  pop rsi
000071409bfd8748  pop rdi
000071409bfd8749  pop rdx
000071409bfd874a  pop rcx
000071409bfd874b  pop rax
000071409bfd874c  add rsp, 0x08
000071409bfd8750  jmp 0x000071409BFD6A25
000071409bfd8755  sub rsp, 0x08
000071409bfd8759  push rax
000071409bfd875a  push rcx
000071409bfd875b  push rdx
000071409bfd875c  push rdi
000071409bfd875d  push rsi
000071409bfd875e  push r8
000071409bfd8760  push r9
000071409bfd8762  push r10
000071409bfd8764  push r11
000071409bfd8766  sub rsp, 0xF0
000071409bfd876d  vmovaps [rsp], xmm0
000071409bfd8772  vmovaps [rsp+0x10], xmm1
000071409bfd8778  vmovaps [rsp+0x20], xmm2
000071409bfd877e  vmovaps [rsp+0x30], xmm3
000071409bfd8784  vmovaps [rsp+0x40], xmm4
000071409bfd878a  vmovaps [rsp+0x50], xmm5
000071409bfd8790  vmovaps [rsp+0x60], xmm6
000071409bfd8796  vmovaps [rsp+0x70], xmm7
000071409bfd879c  vmovaps [rsp+0x80], xmm8
000071409bfd87a5  vmovaps [rsp+0x90], xmm9
000071409bfd87ae  vmovaps [rsp+0xA0], xmm10
000071409bfd87b7  vmovaps [rsp+0xB0], xmm11
000071409bfd87c0  vmovaps [rsp+0xC0], xmm13
000071409bfd87c9  vmovaps [rsp+0xD0], xmm14
000071409bfd87d2  vmovaps [rsp+0xE0], xmm15
000071409bfd87db  sub rsp, 0x40
000071409bfd87df  lea rdi, [rsp]
000071409bfd87e3  lea rsi, [rsp+0x10]
000071409bfd87e8  lea rdx, [rsp+0x20]
000071409bfd87ed  lea rcx, [rsp+0x30]
000071409bfd87f2  mov r8d, 0x00
000071409bfd87f8  lea r9, [r15+0x3A8]
000071409bfd87ff  movaps [rdi], xmm12
000071409bfd8803  movaps [rsi], xmm7
000071409bfd8806  movaps [rdx], xmm15
000071409bfd880a  movaps [rcx], xmm1
000071409bfd880d  mov rax, 0x6219BEBC2A50
000071409bfd8817  call rax
000071409bfd8819  movaps xmm12, [rsp]
000071409bfd881e  add rsp, 0x40
000071409bfd8822  vmovaps xmm0, [rsp]
000071409bfd8827  vmovaps xmm1, [rsp+0x10]
000071409bfd882d  vmovaps xmm2, [rsp+0x20]
000071409bfd8833  vmovaps xmm3, [rsp+0x30]
000071409bfd8839  vmovaps xmm4, [rsp+0x40]
000071409bfd883f  vmovaps xmm5, [rsp+0x50]
000071409bfd8845  vmovaps xmm6, [rsp+0x60]
000071409bfd884b  vmovaps xmm7, [rsp+0x70]
000071409bfd8851  vmovaps xmm8, [rsp+0x80]
000071409bfd885a  vmovaps xmm9, [rsp+0x90]
000071409bfd8863  vmovaps xmm10, [rsp+0xA0]
000071409bfd886c  vmovaps xmm11, [rsp+0xB0]
000071409bfd8875  vmovaps xmm13, [rsp+0xC0]
000071409bfd887e  vmovaps xmm14, [rsp+0xD0]
000071409bfd8887  vmovaps xmm15, [rsp+0xE0]
000071409bfd8890  add rsp, 0xF0
000071409bfd8897  pop r11
000071409bfd8899  pop r10
000071409bfd889b  pop r9
000071409bfd889d  pop r8
000071409bfd889f  pop rsi
000071409bfd88a0  pop rdi
000071409bfd88a1  pop rdx
000071409bfd88a2  pop rcx
000071409bfd88a3  pop rax
000071409bfd88a4  add rsp, 0x08
000071409bfd88a8  jmp 0x000071409BFD6A4E
000071409bfd88ad  call 0x000071409BED64F0
000071409bfd88b2  jmp 0x000071409BFD6A58
000071409bfd88b7  call 0x000071409BEE5820
000071409bfd88bc  jmp 0x000071409BFD6A62
000071409bfd88c1  sub rsp, 0x08
000071409bfd88c5  push rax
000071409bfd88c6  push rcx
000071409bfd88c7  push rdx
000071409bfd88c8  push rdi
000071409bfd88c9  push rsi
000071409bfd88ca  push r8
000071409bfd88cc  push r9
000071409bfd88ce  push r10
000071409bfd88d0  push r11
000071409bfd88d2  sub rsp, 0xF0
000071409bfd88d9  vmovaps [rsp], xmm0
000071409bfd88de  vmovaps [rsp+0x10], xmm1
000071409bfd88e4  vmovaps [rsp+0x20], xmm2
000071409bfd88ea  vmovaps [rsp+0x30], xmm3
000071409bfd88f0  vmovaps [rsp+0x40], xmm4
000071409bfd88f6  vmovaps [rsp+0x50], xmm5
000071409bfd88fc  vmovaps [rsp+0x60], xmm6
000071409bfd8902  vmovaps [rsp+0x70], xmm8
000071409bfd8908  vmovaps [rsp+0x80], xmm9
000071409bfd8911  vmovaps [rsp+0x90], xmm10
000071409bfd891a  vmovaps [rsp+0xA0], xmm11
000071409bfd8923  vmovaps [rsp+0xB0], xmm12
000071409bfd892c  vmovaps [rsp+0xC0], xmm13
000071409bfd8935  vmovaps [rsp+0xD0], xmm14
000071409bfd893e  vmovaps [rsp+0xE0], xmm15
000071409bfd8947  sub rsp, 0x40
000071409bfd894b  lea rdi, [rsp]
000071409bfd894f  lea rsi, [rsp+0x10]
000071409bfd8954  lea rdx, [rsp+0x20]
000071409bfd8959  lea rcx, [rsp+0x30]
000071409bfd895e  mov r8d, 0x00
000071409bfd8964  lea r9, [r15+0x3A8]
000071409bfd896b  movaps [rdi], xmm7
000071409bfd896e  movaps [rsi], xmm2
000071409bfd8971  movaps [rdx], xmm9
000071409bfd8975  movaps [rcx], xmm11
000071409bfd8979  mov rax, 0x6219BEBC2A50
000071409bfd8983  call rax
000071409bfd8985  movaps xmm7, [rsp]
000071409bfd8989  add rsp, 0x40
000071409bfd898d  vmovaps xmm0, [rsp]
000071409bfd8992  vmovaps xmm1, [rsp+0x10]
000071409bfd8998  vmovaps xmm2, [rsp+0x20]
000071409bfd899e  vmovaps xmm3, [rsp+0x30]
000071409bfd89a4  vmovaps xmm4, [rsp+0x40]
000071409bfd89aa  vmovaps xmm5, [rsp+0x50]
000071409bfd89b0  vmovaps xmm6, [rsp+0x60]
000071409bfd89b6  vmovaps xmm8, [rsp+0x70]
000071409bfd89bc  vmovaps xmm9, [rsp+0x80]
000071409bfd89c5  vmovaps xmm10, [rsp+0x90]
000071409bfd89ce  vmovaps xmm11, [rsp+0xA0]
000071409bfd89d7  vmovaps xmm12, [rsp+0xB0]
000071409bfd89e0  vmovaps xmm13, [rsp+0xC0]
000071409bfd89e9  vmovaps xmm14, [rsp+0xD0]
000071409bfd89f2  vmovaps xmm15, [rsp+0xE0]
000071409bfd89fb  add rsp, 0xF0
000071409bfd8a02  pop r11
000071409bfd8a04  pop r10
000071409bfd8a06  pop r9
000071409bfd8a08  pop r8
000071409bfd8a0a  pop rsi
000071409bfd8a0b  pop rdi
000071409bfd8a0c  pop rdx
000071409bfd8a0d  pop rcx
000071409bfd8a0e  pop rax
000071409bfd8a0f  add rsp, 0x08
000071409bfd8a13  jmp 0x000071409BFD6A96
000071409bfd8a18  sub rsp, 0x08
000071409bfd8a1c  push rax
000071409bfd8a1d  push rcx
000071409bfd8a1e  push rdx
000071409bfd8a1f  push rdi
000071409bfd8a20  push rsi
000071409bfd8a21  push r8
000071409bfd8a23  push r9
000071409bfd8a25  push r10
000071409bfd8a27  push r11
000071409bfd8a29  sub rsp, 0xF0
000071409bfd8a30  vmovaps [rsp], xmm0
000071409bfd8a35  vmovaps [rsp+0x10], xmm1
000071409bfd8a3b  vmovaps [rsp+0x20], xmm2
000071409bfd8a41  vmovaps [rsp+0x30], xmm3
000071409bfd8a47  vmovaps [rsp+0x40], xmm4
000071409bfd8a4d  vmovaps [rsp+0x50], xmm5
000071409bfd8a53  vmovaps [rsp+0x60], xmm6
000071409bfd8a59  vmovaps [rsp+0x70], xmm7
000071409bfd8a5f  vmovaps [rsp+0x80], xmm8
000071409bfd8a68  vmovaps [rsp+0x90], xmm10
000071409bfd8a71  vmovaps [rsp+0xA0], xmm11
000071409bfd8a7a  vmovaps [rsp+0xB0], xmm12
000071409bfd8a83  vmovaps [rsp+0xC0], xmm13
000071409bfd8a8c  vmovaps [rsp+0xD0], xmm14
000071409bfd8a95  vmovaps [rsp+0xE0], xmm15
000071409bfd8a9e  sub rsp, 0x40
000071409bfd8aa2  lea rdi, [rsp]
000071409bfd8aa6  lea rsi, [rsp+0x10]
000071409bfd8aab  lea rdx, [rsp+0x20]
000071409bfd8ab0  lea rcx, [rsp+0x30]
000071409bfd8ab5  mov r8d, 0x00
000071409bfd8abb  lea r9, [r15+0x3A8]
000071409bfd8ac2  movaps [rdi], xmm9
000071409bfd8ac6  movaps [rsi], xmm6
000071409bfd8ac9  movaps [rdx], xmm1
000071409bfd8acc  movaps [rcx], xmm11
000071409bfd8ad0  mov rax, 0x6219BEBC2A50
000071409bfd8ada  call rax
000071409bfd8adc  movaps xmm9, [rsp]
000071409bfd8ae1  add rsp, 0x40
000071409bfd8ae5  vmovaps xmm0, [rsp]
000071409bfd8aea  vmovaps xmm1, [rsp+0x10]
000071409bfd8af0  vmovaps xmm2, [rsp+0x20]
000071409bfd8af6  vmovaps xmm3, [rsp+0x30]
000071409bfd8afc  vmovaps xmm4, [rsp+0x40]
000071409bfd8b02  vmovaps xmm5, [rsp+0x50]
000071409bfd8b08  vmovaps xmm6, [rsp+0x60]
000071409bfd8b0e  vmovaps xmm7, [rsp+0x70]
000071409bfd8b14  vmovaps xmm8, [rsp+0x80]
000071409bfd8b1d  vmovaps xmm10, [rsp+0x90]
000071409bfd8b26  vmovaps xmm11, [rsp+0xA0]
000071409bfd8b2f  vmovaps xmm12, [rsp+0xB0]
000071409bfd8b38  vmovaps xmm13, [rsp+0xC0]
000071409bfd8b41  vmovaps xmm14, [rsp+0xD0]
000071409bfd8b4a  vmovaps xmm15, [rsp+0xE0]
000071409bfd8b53  add rsp, 0xF0
000071409bfd8b5a  pop r11
000071409bfd8b5c  pop r10
000071409bfd8b5e  pop r9
000071409bfd8b60  pop r8
000071409bfd8b62  pop rsi
000071409bfd8b63  pop rdi
000071409bfd8b64  pop rdx
000071409bfd8b65  pop rcx
000071409bfd8b66  pop rax
000071409bfd8b67  add rsp, 0x08
000071409bfd8b6b  jmp 0x000071409BFD6ABC
000071409bfd8b70  sub rsp, 0x08
000071409bfd8b74  push rax
000071409bfd8b75  push rcx
000071409bfd8b76  push rdx
000071409bfd8b77  push rdi
000071409bfd8b78  push rsi
000071409bfd8b79  push r8
000071409bfd8b7b  push r9
000071409bfd8b7d  push r10
000071409bfd8b7f  push r11
000071409bfd8b81  sub rsp, 0xF0
000071409bfd8b88  vmovaps [rsp], xmm0
000071409bfd8b8d  vmovaps [rsp+0x10], xmm1
000071409bfd8b93  vmovaps [rsp+0x20], xmm2
000071409bfd8b99  vmovaps [rsp+0x30], xmm3
000071409bfd8b9f  vmovaps [rsp+0x40], xmm4
000071409bfd8ba5  vmovaps [rsp+0x50], xmm5
000071409bfd8bab  vmovaps [rsp+0x60], xmm6
000071409bfd8bb1  vmovaps [rsp+0x70], xmm7
000071409bfd8bb7  vmovaps [rsp+0x80], xmm8
000071409bfd8bc0  vmovaps [rsp+0x90], xmm9
000071409bfd8bc9  vmovaps [rsp+0xA0], xmm10
000071409bfd8bd2  vmovaps [rsp+0xB0], xmm12
000071409bfd8bdb  vmovaps [rsp+0xC0], xmm13
000071409bfd8be4  vmovaps [rsp+0xD0], xmm14
000071409bfd8bed  vmovaps [rsp+0xE0], xmm15
000071409bfd8bf6  sub rsp, 0x40
000071409bfd8bfa  lea rdi, [rsp]
000071409bfd8bfe  lea rsi, [rsp+0x10]
000071409bfd8c03  lea rdx, [rsp+0x20]
000071409bfd8c08  lea rcx, [rsp+0x30]
000071409bfd8c0d  mov r8d, 0x00
000071409bfd8c13  lea r9, [r15+0x3A8]
000071409bfd8c1a  movaps [rdi], xmm11
000071409bfd8c1e  movaps [rsi], xmm10
000071409bfd8c22  movaps [rdx], xmm8
000071409bfd8c26  movaps [rcx], xmm1
000071409bfd8c29  mov rax, 0x6219BEBC2A50
000071409bfd8c33  call rax
000071409bfd8c35  movaps xmm11, [rsp]
000071409bfd8c3a  add rsp, 0x40
000071409bfd8c3e  vmovaps xmm0, [rsp]
000071409bfd8c43  vmovaps xmm1, [rsp+0x10]
000071409bfd8c49  vmovaps xmm2, [rsp+0x20]
000071409bfd8c4f  vmovaps xmm3, [rsp+0x30]
000071409bfd8c55  vmovaps xmm4, [rsp+0x40]
000071409bfd8c5b  vmovaps xmm5, [rsp+0x50]
000071409bfd8c61  vmovaps xmm6, [rsp+0x60]
000071409bfd8c67  vmovaps xmm7, [rsp+0x70]
000071409bfd8c6d  vmovaps xmm8, [rsp+0x80]
000071409bfd8c76  vmovaps xmm9, [rsp+0x90]
000071409bfd8c7f  vmovaps xmm10, [rsp+0xA0]
000071409bfd8c88  vmovaps xmm12, [rsp+0xB0]
000071409bfd8c91  vmovaps xmm13, [rsp+0xC0]
000071409bfd8c9a  vmovaps xmm14, [rsp+0xD0]
000071409bfd8ca3  vmovaps xmm15, [rsp+0xE0]
000071409bfd8cac  add rsp, 0xF0
000071409bfd8cb3  pop r11
000071409bfd8cb5  pop r10
000071409bfd8cb7  pop r9
000071409bfd8cb9  pop r8
000071409bfd8cbb  pop rsi
000071409bfd8cbc  pop rdi
000071409bfd8cbd  pop rdx
000071409bfd8cbe  pop rcx
000071409bfd8cbf  pop rax
000071409bfd8cc0  add rsp, 0x08
000071409bfd8cc4  jmp 0x000071409BFD6AE2
000071409bfd8cc9  sub rsp, 0x08
000071409bfd8ccd  push rax
000071409bfd8cce  push rcx
000071409bfd8ccf  push rdx
000071409bfd8cd0  push rdi
000071409bfd8cd1  push rsi
000071409bfd8cd2  push r8
000071409bfd8cd4  push r9
000071409bfd8cd6  push r10
000071409bfd8cd8  push r11
000071409bfd8cda  sub rsp, 0xF0
000071409bfd8ce1  vmovaps [rsp], xmm0
000071409bfd8ce6  vmovaps [rsp+0x10], xmm1
000071409bfd8cec  vmovaps [rsp+0x20], xmm2
000071409bfd8cf2  vmovaps [rsp+0x30], xmm3
000071409bfd8cf8  vmovaps [rsp+0x40], xmm4
000071409bfd8cfe  vmovaps [rsp+0x50], xmm5
000071409bfd8d04  vmovaps [rsp+0x60], xmm6
000071409bfd8d0a  vmovaps [rsp+0x70], xmm7
000071409bfd8d10  vmovaps [rsp+0x80], xmm8
000071409bfd8d19  vmovaps [rsp+0x90], xmm9
000071409bfd8d22  vmovaps [rsp+0xA0], xmm11
000071409bfd8d2b  vmovaps [rsp+0xB0], xmm12
000071409bfd8d34  vmovaps [rsp+0xC0], xmm13
000071409bfd8d3d  vmovaps [rsp+0xD0], xmm14
000071409bfd8d46  vmovaps [rsp+0xE0], xmm15
000071409bfd8d4f  sub rsp, 0x40
000071409bfd8d53  lea rdi, [rsp]
000071409bfd8d57  lea rsi, [rsp+0x10]
000071409bfd8d5c  lea rdx, [rsp+0x20]
000071409bfd8d61  lea rcx, [rsp+0x30]
000071409bfd8d66  mov r8d, 0x00
000071409bfd8d6c  lea r9, [r15+0x3A8]
000071409bfd8d73  movaps [rdi], xmm10
000071409bfd8d77  movaps [rsi], xmm12
000071409bfd8d7b  movaps [rdx], xmm13
000071409bfd8d7f  movaps [rcx], xmm1
000071409bfd8d82  mov rax, 0x6219BEBC2A50
000071409bfd8d8c  call rax
000071409bfd8d8e  movaps xmm10, [rsp]
000071409bfd8d93  add rsp, 0x40
000071409bfd8d97  vmovaps xmm0, [rsp]
000071409bfd8d9c  vmovaps xmm1, [rsp+0x10]
000071409bfd8da2  vmovaps xmm2, [rsp+0x20]
000071409bfd8da8  vmovaps xmm3, [rsp+0x30]
000071409bfd8dae  vmovaps xmm4, [rsp+0x40]
000071409bfd8db4  vmovaps xmm5, [rsp+0x50]
000071409bfd8dba  vmovaps xmm6, [rsp+0x60]
000071409bfd8dc0  vmovaps xmm7, [rsp+0x70]
000071409bfd8dc6  vmovaps xmm8, [rsp+0x80]
000071409bfd8dcf  vmovaps xmm9, [rsp+0x90]
000071409bfd8dd8  vmovaps xmm11, [rsp+0xA0]
000071409bfd8de1  vmovaps xmm12, [rsp+0xB0]
000071409bfd8dea  vmovaps xmm13, [rsp+0xC0]
000071409bfd8df3  vmovaps xmm14, [rsp+0xD0]
000071409bfd8dfc  vmovaps xmm15, [rsp+0xE0]
000071409bfd8e05  add rsp, 0xF0
000071409bfd8e0c  pop r11
000071409bfd8e0e  pop r10
000071409bfd8e10  pop r9
000071409bfd8e12  pop r8
000071409bfd8e14  pop rsi
000071409bfd8e15  pop rdi
000071409bfd8e16  pop rdx
000071409bfd8e17  pop rcx
000071409bfd8e18  pop rax
000071409bfd8e19  add rsp, 0x08
000071409bfd8e1d  jmp 0x000071409BFD6B08
000071409bfd8e22  call 0x000071409BED64F0
000071409bfd8e27  jmp 0x000071409BFD6B12
000071409bfd8e2c  call 0x000071409BEE3320
000071409bfd8e31  jmp 0x000071409BFD6B1C
000071409bfd8e36  sub rsp, 0x08
000071409bfd8e3a  push rax
000071409bfd8e3b  push rcx
000071409bfd8e3c  push rdx
000071409bfd8e3d  push rdi
000071409bfd8e3e  push rsi
000071409bfd8e3f  push r8
000071409bfd8e41  push r9
000071409bfd8e43  push r10
000071409bfd8e45  push r11
000071409bfd8e47  sub rsp, 0xF0
000071409bfd8e4e  vmovaps [rsp], xmm0
000071409bfd8e53  vmovaps [rsp+0x10], xmm1
000071409bfd8e59  vmovaps [rsp+0x20], xmm2
000071409bfd8e5f  vmovaps [rsp+0x30], xmm3
000071409bfd8e65  vmovaps [rsp+0x40], xmm4
000071409bfd8e6b  vmovaps [rsp+0x50], xmm5
000071409bfd8e71  vmovaps [rsp+0x60], xmm6
000071409bfd8e77  vmovaps [rsp+0x70], xmm7
000071409bfd8e7d  vmovaps [rsp+0x80], xmm9
000071409bfd8e86  vmovaps [rsp+0x90], xmm10
000071409bfd8e8f  vmovaps [rsp+0xA0], xmm11
000071409bfd8e98  vmovaps [rsp+0xB0], xmm12
000071409bfd8ea1  vmovaps [rsp+0xC0], xmm13
000071409bfd8eaa  vmovaps [rsp+0xD0], xmm14
000071409bfd8eb3  vmovaps [rsp+0xE0], xmm15
000071409bfd8ebc  sub rsp, 0x40
000071409bfd8ec0  lea rdi, [rsp]
000071409bfd8ec4  lea rsi, [rsp+0x10]
000071409bfd8ec9  lea rdx, [rsp+0x20]
000071409bfd8ece  lea rcx, [rsp+0x30]
000071409bfd8ed3  mov r8d, 0x00
000071409bfd8ed9  lea r9, [r15+0x3A8]
000071409bfd8ee0  movaps [rdi], xmm8
000071409bfd8ee4  movaps [rsi], xmm7
000071409bfd8ee7  movaps [rdx], xmm4
000071409bfd8eea  movaps [rcx], xmm12
000071409bfd8eee  mov rax, 0x6219BEBC2A50
000071409bfd8ef8  call rax
000071409bfd8efa  movaps xmm8, [rsp]
000071409bfd8eff  add rsp, 0x40
000071409bfd8f03  vmovaps xmm0, [rsp]
000071409bfd8f08  vmovaps xmm1, [rsp+0x10]
000071409bfd8f0e  vmovaps xmm2, [rsp+0x20]
000071409bfd8f14  vmovaps xmm3, [rsp+0x30]
000071409bfd8f1a  vmovaps xmm4, [rsp+0x40]
000071409bfd8f20  vmovaps xmm5, [rsp+0x50]
000071409bfd8f26  vmovaps xmm6, [rsp+0x60]
000071409bfd8f2c  vmovaps xmm7, [rsp+0x70]
000071409bfd8f32  vmovaps xmm9, [rsp+0x80]
000071409bfd8f3b  vmovaps xmm10, [rsp+0x90]
000071409bfd8f44  vmovaps xmm11, [rsp+0xA0]
000071409bfd8f4d  vmovaps xmm12, [rsp+0xB0]
000071409bfd8f56  vmovaps xmm13, [rsp+0xC0]
000071409bfd8f5f  vmovaps xmm14, [rsp+0xD0]
000071409bfd8f68  vmovaps xmm15, [rsp+0xE0]
000071409bfd8f71  add rsp, 0xF0
000071409bfd8f78  pop r11
000071409bfd8f7a  pop r10
000071409bfd8f7c  pop r9
000071409bfd8f7e  pop r8
000071409bfd8f80  pop rsi
000071409bfd8f81  pop rdi
000071409bfd8f82  pop rdx
000071409bfd8f83  pop rcx
000071409bfd8f84  pop rax
000071409bfd8f85  add rsp, 0x08
000071409bfd8f89  jmp 0x000071409BFD6B45
000071409bfd8f8e  sub rsp, 0x08
000071409bfd8f92  push rax
000071409bfd8f93  push rcx
000071409bfd8f94  push rdx
000071409bfd8f95  push rdi
000071409bfd8f96  push rsi
000071409bfd8f97  push r8
000071409bfd8f99  push r9
000071409bfd8f9b  push r10
000071409bfd8f9d  push r11
000071409bfd8f9f  sub rsp, 0xF0
000071409bfd8fa6  vmovaps [rsp], xmm0
000071409bfd8fab  vmovaps [rsp+0x10], xmm1
000071409bfd8fb1  vmovaps [rsp+0x20], xmm2
000071409bfd8fb7  vmovaps [rsp+0x30], xmm3
000071409bfd8fbd  vmovaps [rsp+0x40], xmm4
000071409bfd8fc3  vmovaps [rsp+0x50], xmm5
000071409bfd8fc9  vmovaps [rsp+0x60], xmm6
000071409bfd8fcf  vmovaps [rsp+0x70], xmm8
000071409bfd8fd5  vmovaps [rsp+0x80], xmm9
000071409bfd8fde  vmovaps [rsp+0x90], xmm10
000071409bfd8fe7  vmovaps [rsp+0xA0], xmm11
000071409bfd8ff0  vmovaps [rsp+0xB0], xmm12
000071409bfd8ff9  vmovaps [rsp+0xC0], xmm13
000071409bfd9002  vmovaps [rsp+0xD0], xmm14
000071409bfd900b  vmovaps [rsp+0xE0], xmm15
000071409bfd9014  sub rsp, 0x40
000071409bfd9018  lea rdi, [rsp]
000071409bfd901c  lea rsi, [rsp+0x10]
000071409bfd9021  lea rdx, [rsp+0x20]
000071409bfd9026  lea rcx, [rsp+0x30]
000071409bfd902b  mov r8d, 0x00
000071409bfd9031  lea r9, [r15+0x3A8]
000071409bfd9038  movaps [rdi], xmm7
000071409bfd903b  movaps [rsi], xmm9
000071409bfd903f  movaps [rdx], xmm14
000071409bfd9043  movaps [rcx], xmm12
000071409bfd9047  mov rax, 0x6219BEBC2A50
000071409bfd9051  call rax
000071409bfd9053  movaps xmm7, [rsp]
000071409bfd9057  add rsp, 0x40
000071409bfd905b  vmovaps xmm0, [rsp]
000071409bfd9060  vmovaps xmm1, [rsp+0x10]
000071409bfd9066  vmovaps xmm2, [rsp+0x20]
000071409bfd906c  vmovaps xmm3, [rsp+0x30]
000071409bfd9072  vmovaps xmm4, [rsp+0x40]
000071409bfd9078  vmovaps xmm5, [rsp+0x50]
000071409bfd907e  vmovaps xmm6, [rsp+0x60]
000071409bfd9084  vmovaps xmm8, [rsp+0x70]
000071409bfd908a  vmovaps xmm9, [rsp+0x80]
000071409bfd9093  vmovaps xmm10, [rsp+0x90]
000071409bfd909c  vmovaps xmm11, [rsp+0xA0]
000071409bfd90a5  vmovaps xmm12, [rsp+0xB0]
000071409bfd90ae  vmovaps xmm13, [rsp+0xC0]
000071409bfd90b7  vmovaps xmm14, [rsp+0xD0]
000071409bfd90c0  vmovaps xmm15, [rsp+0xE0]
000071409bfd90c9  add rsp, 0xF0
000071409bfd90d0  pop r11
000071409bfd90d2  pop r10
000071409bfd90d4  pop r9
000071409bfd90d6  pop r8
000071409bfd90d8  pop rsi
000071409bfd90d9  pop rdi
000071409bfd90da  pop rdx
000071409bfd90db  pop rcx
000071409bfd90dc  pop rax
000071409bfd90dd  add rsp, 0x08
000071409bfd90e1  jmp 0x000071409BFD6B6D
000071409bfd90e6  sub rsp, 0x08
000071409bfd90ea  push rax
000071409bfd90eb  push rcx
000071409bfd90ec  push rdx
000071409bfd90ed  push rdi
000071409bfd90ee  push rsi
000071409bfd90ef  push r8
000071409bfd90f1  push r9
000071409bfd90f3  push r10
000071409bfd90f5  push r11
000071409bfd90f7  sub rsp, 0xF0
000071409bfd90fe  vmovaps [rsp], xmm0
000071409bfd9103  vmovaps [rsp+0x10], xmm1
000071409bfd9109  vmovaps [rsp+0x20], xmm2
000071409bfd910f  vmovaps [rsp+0x30], xmm3
000071409bfd9115  vmovaps [rsp+0x40], xmm4
000071409bfd911b  vmovaps [rsp+0x50], xmm5
000071409bfd9121  vmovaps [rsp+0x60], xmm6
000071409bfd9127  vmovaps [rsp+0x70], xmm7
000071409bfd912d  vmovaps [rsp+0x80], xmm8
000071409bfd9136  vmovaps [rsp+0x90], xmm9
000071409bfd913f  vmovaps [rsp+0xA0], xmm10
000071409bfd9148  vmovaps [rsp+0xB0], xmm11
000071409bfd9151  vmovaps [rsp+0xC0], xmm13
000071409bfd915a  vmovaps [rsp+0xD0], xmm14
000071409bfd9163  vmovaps [rsp+0xE0], xmm15
000071409bfd916c  sub rsp, 0x40
000071409bfd9170  lea rdi, [rsp]
000071409bfd9174  lea rsi, [rsp+0x10]
000071409bfd9179  lea rdx, [rsp+0x20]
000071409bfd917e  lea rcx, [rsp+0x30]
000071409bfd9183  mov r8d, 0x00
000071409bfd9189  lea r9, [r15+0x3A8]
000071409bfd9190  movaps [rdi], xmm12
000071409bfd9194  movaps [rsi], xmm11
000071409bfd9198  movaps [rdx], xmm15
000071409bfd919c  movaps [rcx], xmm14
000071409bfd91a0  mov rax, 0x6219BEBC2A50
000071409bfd91aa  call rax
000071409bfd91ac  movaps xmm12, [rsp]
000071409bfd91b1  add rsp, 0x40
000071409bfd91b5  vmovaps xmm0, [rsp]
000071409bfd91ba  vmovaps xmm1, [rsp+0x10]
000071409bfd91c0  vmovaps xmm2, [rsp+0x20]
000071409bfd91c6  vmovaps xmm3, [rsp+0x30]
000071409bfd91cc  vmovaps xmm4, [rsp+0x40]
000071409bfd91d2  vmovaps xmm5, [rsp+0x50]
000071409bfd91d8  vmovaps xmm6, [rsp+0x60]
000071409bfd91de  vmovaps xmm7, [rsp+0x70]
000071409bfd91e4  vmovaps xmm8, [rsp+0x80]
000071409bfd91ed  vmovaps xmm9, [rsp+0x90]
000071409bfd91f6  vmovaps xmm10, [rsp+0xA0]
000071409bfd91ff  vmovaps xmm11, [rsp+0xB0]
000071409bfd9208  vmovaps xmm13, [rsp+0xC0]
000071409bfd9211  vmovaps xmm14, [rsp+0xD0]
000071409bfd921a  vmovaps xmm15, [rsp+0xE0]
000071409bfd9223  add rsp, 0xF0
000071409bfd922a  pop r11
000071409bfd922c  pop r10
000071409bfd922e  pop r9
000071409bfd9230  pop r8
000071409bfd9232  pop rsi
000071409bfd9233  pop rdi
000071409bfd9234  pop rdx
000071409bfd9235  pop rcx
000071409bfd9236  pop rax
000071409bfd9237  add rsp, 0x08
000071409bfd923b  jmp 0x000071409BFD6B96
000071409bfd9240  sub rsp, 0x08
000071409bfd9244  push rax
000071409bfd9245  push rcx
000071409bfd9246  push rdx
000071409bfd9247  push rdi
000071409bfd9248  push rsi
000071409bfd9249  push r8
000071409bfd924b  push r9
000071409bfd924d  push r10
000071409bfd924f  push r11
000071409bfd9251  sub rsp, 0xF0
000071409bfd9258  vmovaps [rsp], xmm0
000071409bfd925d  vmovaps [rsp+0x10], xmm1
000071409bfd9263  vmovaps [rsp+0x20], xmm2
000071409bfd9269  vmovaps [rsp+0x30], xmm3
000071409bfd926f  vmovaps [rsp+0x40], xmm4
000071409bfd9275  vmovaps [rsp+0x50], xmm5
000071409bfd927b  vmovaps [rsp+0x60], xmm6
000071409bfd9281  vmovaps [rsp+0x70], xmm7
000071409bfd9287  vmovaps [rsp+0x80], xmm8
000071409bfd9290  vmovaps [rsp+0x90], xmm9
000071409bfd9299  vmovaps [rsp+0xA0], xmm10
000071409bfd92a2  vmovaps [rsp+0xB0], xmm12
000071409bfd92ab  vmovaps [rsp+0xC0], xmm13
000071409bfd92b4  vmovaps [rsp+0xD0], xmm14
000071409bfd92bd  vmovaps [rsp+0xE0], xmm15
000071409bfd92c6  sub rsp, 0x40
000071409bfd92ca  lea rdi, [rsp]
000071409bfd92ce  lea rsi, [rsp+0x10]
000071409bfd92d3  lea rdx, [rsp+0x20]
000071409bfd92d8  lea rcx, [rsp+0x30]
000071409bfd92dd  mov r8d, 0x00
000071409bfd92e3  lea r9, [r15+0x3A8]
000071409bfd92ea  movaps [rdi], xmm11
000071409bfd92ee  movaps [rsi], xmm10
000071409bfd92f2  movaps [rdx], xmm13
000071409bfd92f6  movaps [rcx], xmm15
000071409bfd92fa  mov rax, 0x6219BEBC2A50
000071409bfd9304  call rax
000071409bfd9306  movaps xmm11, [rsp]
000071409bfd930b  add rsp, 0x40
000071409bfd930f  vmovaps xmm0, [rsp]
000071409bfd9314  vmovaps xmm1, [rsp+0x10]
000071409bfd931a  vmovaps xmm2, [rsp+0x20]
000071409bfd9320  vmovaps xmm3, [rsp+0x30]
000071409bfd9326  vmovaps xmm4, [rsp+0x40]
000071409bfd932c  vmovaps xmm5, [rsp+0x50]
000071409bfd9332  vmovaps xmm6, [rsp+0x60]
000071409bfd9338  vmovaps xmm7, [rsp+0x70]
000071409bfd933e  vmovaps xmm8, [rsp+0x80]
000071409bfd9347  vmovaps xmm9, [rsp+0x90]
000071409bfd9350  vmovaps xmm10, [rsp+0xA0]
000071409bfd9359  vmovaps xmm12, [rsp+0xB0]
000071409bfd9362  vmovaps xmm13, [rsp+0xC0]
000071409bfd936b  vmovaps xmm14, [rsp+0xD0]
000071409bfd9374  vmovaps xmm15, [rsp+0xE0]
000071409bfd937d  add rsp, 0xF0
000071409bfd9384  pop r11
000071409bfd9386  pop r10
000071409bfd9388  pop r9
000071409bfd938a  pop r8
000071409bfd938c  pop rsi
000071409bfd938d  pop rdi
000071409bfd938e  pop rdx
000071409bfd938f  pop rcx
000071409bfd9390  pop rax
000071409bfd9391  add rsp, 0x08
000071409bfd9395  jmp 0x000071409BFD6BBF
000071409bfd939a  call 0x000071409BEE5820
000071409bfd939f  jmp 0x000071409BFD6BCC
000071409bfd93a4  call 0x000071409BEE45A0
000071409bfd93a9  jmp 0x000071409BFD6BD9
000071409bfd93ae  sub rsp, 0x08
000071409bfd93b2  push rax
000071409bfd93b3  push rcx
000071409bfd93b4  push rdx
000071409bfd93b5  push rdi
000071409bfd93b6  push rsi
000071409bfd93b7  push r8
000071409bfd93b9  push r9
000071409bfd93bb  push r10
000071409bfd93bd  push r11
000071409bfd93bf  sub rsp, 0xF0
000071409bfd93c6  vmovaps [rsp], xmm0
000071409bfd93cb  vmovaps [rsp+0x10], xmm1
000071409bfd93d1  vmovaps [rsp+0x20], xmm2
000071409bfd93d7  vmovaps [rsp+0x30], xmm3
000071409bfd93dd  vmovaps [rsp+0x40], xmm4
000071409bfd93e3  vmovaps [rsp+0x50], xmm5
000071409bfd93e9  vmovaps [rsp+0x60], xmm6
000071409bfd93ef  vmovaps [rsp+0x70], xmm7
000071409bfd93f5  vmovaps [rsp+0x80], xmm8
000071409bfd93fe  vmovaps [rsp+0x90], xmm9
000071409bfd9407  vmovaps [rsp+0xA0], xmm11
000071409bfd9410  vmovaps [rsp+0xB0], xmm12
000071409bfd9419  vmovaps [rsp+0xC0], xmm13
000071409bfd9422  vmovaps [rsp+0xD0], xmm14
000071409bfd942b  vmovaps [rsp+0xE0], xmm15
000071409bfd9434  sub rsp, 0x40
000071409bfd9438  lea rdi, [rsp]
000071409bfd943c  lea rsi, [rsp+0x10]
000071409bfd9441  lea rdx, [rsp+0x20]
000071409bfd9446  lea rcx, [rsp+0x30]
000071409bfd944b  mov r8d, 0x00
000071409bfd9451  lea r9, [r15+0x3A8]
000071409bfd9458  movaps [rdi], xmm10
000071409bfd945c  movaps [rsi], xmm8
000071409bfd9460  movaps [rdx], xmm1
000071409bfd9463  movaps [rcx], xmm13
000071409bfd9467  mov rax, 0x6219BEBC2A50
000071409bfd9471  call rax
000071409bfd9473  movaps xmm10, [rsp]
000071409bfd9478  add rsp, 0x40
000071409bfd947c  vmovaps xmm0, [rsp]
000071409bfd9481  vmovaps xmm1, [rsp+0x10]
000071409bfd9487  vmovaps xmm2, [rsp+0x20]
000071409bfd948d  vmovaps xmm3, [rsp+0x30]
000071409bfd9493  vmovaps xmm4, [rsp+0x40]
000071409bfd9499  vmovaps xmm5, [rsp+0x50]
000071409bfd949f  vmovaps xmm6, [rsp+0x60]
000071409bfd94a5  vmovaps xmm7, [rsp+0x70]
000071409bfd94ab  vmovaps xmm8, [rsp+0x80]
000071409bfd94b4  vmovaps xmm9, [rsp+0x90]
000071409bfd94bd  vmovaps xmm11, [rsp+0xA0]
000071409bfd94c6  vmovaps xmm12, [rsp+0xB0]
000071409bfd94cf  vmovaps xmm13, [rsp+0xC0]
000071409bfd94d8  vmovaps xmm14, [rsp+0xD0]
000071409bfd94e1  vmovaps xmm15, [rsp+0xE0]
000071409bfd94ea  add rsp, 0xF0
000071409bfd94f1  pop r11
000071409bfd94f3  pop r10
000071409bfd94f5  pop r9
000071409bfd94f7  pop r8
000071409bfd94f9  pop rsi
000071409bfd94fa  pop rdi
000071409bfd94fb  pop rdx
000071409bfd94fc  pop rcx
000071409bfd94fd  pop rax
000071409bfd94fe  add rsp, 0x08
000071409bfd9502  jmp 0x000071409BFD6C0F
000071409bfd9507  call 0x000071409BED64F0
000071409bfd950c  jmp 0x000071409BFD6C21
000071409bfd9511  sub rsp, 0x08
000071409bfd9515  push rax
000071409bfd9516  push rcx
000071409bfd9517  push rdx
000071409bfd9518  push rdi
000071409bfd9519  push rsi
000071409bfd951a  push r8
000071409bfd951c  push r9
000071409bfd951e  push r10
000071409bfd9520  push r11
000071409bfd9522  sub rsp, 0xF0
000071409bfd9529  vmovaps [rsp], xmm0
000071409bfd952e  vmovaps [rsp+0x10], xmm1
000071409bfd9534  vmovaps [rsp+0x20], xmm2
000071409bfd953a  vmovaps [rsp+0x30], xmm3
000071409bfd9540  vmovaps [rsp+0x40], xmm4
000071409bfd9546  vmovaps [rsp+0x50], xmm5
000071409bfd954c  vmovaps [rsp+0x60], xmm6
000071409bfd9552  vmovaps [rsp+0x70], xmm7
000071409bfd9558  vmovaps [rsp+0x80], xmm8
000071409bfd9561  vmovaps [rsp+0x90], xmm10
000071409bfd956a  vmovaps [rsp+0xA0], xmm11
000071409bfd9573  vmovaps [rsp+0xB0], xmm12
000071409bfd957c  vmovaps [rsp+0xC0], xmm13
000071409bfd9585  vmovaps [rsp+0xD0], xmm14
000071409bfd958e  vmovaps [rsp+0xE0], xmm15
000071409bfd9597  sub rsp, 0x40
000071409bfd959b  lea rdi, [rsp]
000071409bfd959f  lea rsi, [rsp+0x10]
000071409bfd95a4  lea rdx, [rsp+0x20]
000071409bfd95a9  lea rcx, [rsp+0x30]
000071409bfd95ae  mov r8d, 0x00
000071409bfd95b4  lea r9, [r15+0x3A8]
000071409bfd95bb  movaps [rdi], xmm9
000071409bfd95bf  movaps [rsi], xmm7
000071409bfd95c2  movaps [rdx], xmm14
000071409bfd95c6  movaps [rcx], xmm13
000071409bfd95ca  mov rax, 0x6219BEBC2A50
000071409bfd95d4  call rax
000071409bfd95d6  movaps xmm9, [rsp]
000071409bfd95db  add rsp, 0x40
000071409bfd95df  vmovaps xmm0, [rsp]
000071409bfd95e4  vmovaps xmm1, [rsp+0x10]
000071409bfd95ea  vmovaps xmm2, [rsp+0x20]
000071409bfd95f0  vmovaps xmm3, [rsp+0x30]
000071409bfd95f6  vmovaps xmm4, [rsp+0x40]
000071409bfd95fc  vmovaps xmm5, [rsp+0x50]
000071409bfd9602  vmovaps xmm6, [rsp+0x60]
000071409bfd9608  vmovaps xmm7, [rsp+0x70]
000071409bfd960e  vmovaps xmm8, [rsp+0x80]
000071409bfd9617  vmovaps xmm10, [rsp+0x90]
000071409bfd9620  vmovaps xmm11, [rsp+0xA0]
000071409bfd9629  vmovaps xmm12, [rsp+0xB0]
000071409bfd9632  vmovaps xmm13, [rsp+0xC0]
000071409bfd963b  vmovaps xmm14, [rsp+0xD0]
000071409bfd9644  vmovaps xmm15, [rsp+0xE0]
000071409bfd964d  add rsp, 0xF0
000071409bfd9654  pop r11
000071409bfd9656  pop r10
000071409bfd9658  pop r9
000071409bfd965a  pop r8
000071409bfd965c  pop rsi
000071409bfd965d  pop rdi
000071409bfd965e  pop rdx
000071409bfd965f  pop rcx
000071409bfd9660  pop rax
000071409bfd9661  add rsp, 0x08
000071409bfd9665  jmp 0x000071409BFD6C4F
000071409bfd966a  sub rsp, 0x08
000071409bfd966e  push rax
000071409bfd966f  push rcx
000071409bfd9670  push rdx
000071409bfd9671  push rdi
000071409bfd9672  push rsi
000071409bfd9673  push r8
000071409bfd9675  push r9
000071409bfd9677  push r10
000071409bfd9679  push r11
000071409bfd967b  sub rsp, 0xF0
000071409bfd9682  vmovaps [rsp], xmm0
000071409bfd9687  vmovaps [rsp+0x10], xmm1
000071409bfd968d  vmovaps [rsp+0x20], xmm2
000071409bfd9693  vmovaps [rsp+0x30], xmm3
000071409bfd9699  vmovaps [rsp+0x40], xmm4
000071409bfd969f  vmovaps [rsp+0x50], xmm5
000071409bfd96a5  vmovaps [rsp+0x60], xmm6
000071409bfd96ab  vmovaps [rsp+0x70], xmm7
000071409bfd96b1  vmovaps [rsp+0x80], xmm8
000071409bfd96ba  vmovaps [rsp+0x90], xmm9
000071409bfd96c3  vmovaps [rsp+0xA0], xmm10
000071409bfd96cc  vmovaps [rsp+0xB0], xmm11
000071409bfd96d5  vmovaps [rsp+0xC0], xmm12
000071409bfd96de  vmovaps [rsp+0xD0], xmm14
000071409bfd96e7  vmovaps [rsp+0xE0], xmm15
000071409bfd96f0  sub rsp, 0x40
000071409bfd96f4  lea rdi, [rsp]
000071409bfd96f8  lea rsi, [rsp+0x10]
000071409bfd96fd  lea rdx, [rsp+0x20]
000071409bfd9702  lea rcx, [rsp+0x30]
000071409bfd9707  mov r8d, 0x00
000071409bfd970d  lea r9, [r15+0x3A8]
000071409bfd9714  movaps [rdi], xmm13
000071409bfd9718  movaps [rsi], xmm12
000071409bfd971c  movaps [rdx], xmm15
000071409bfd9720  movaps [rcx], xmm14
000071409bfd9724  mov rax, 0x6219BEBC2A50
000071409bfd972e  call rax
000071409bfd9730  movaps xmm13, [rsp]
000071409bfd9735  add rsp, 0x40
000071409bfd9739  vmovaps xmm0, [rsp]
000071409bfd973e  vmovaps xmm1, [rsp+0x10]
000071409bfd9744  vmovaps xmm2, [rsp+0x20]
000071409bfd974a  vmovaps xmm3, [rsp+0x30]
000071409bfd9750  vmovaps xmm4, [rsp+0x40]
000071409bfd9756  vmovaps xmm5, [rsp+0x50]
000071409bfd975c  vmovaps xmm6, [rsp+0x60]
000071409bfd9762  vmovaps xmm7, [rsp+0x70]
000071409bfd9768  vmovaps xmm8, [rsp+0x80]
000071409bfd9771  vmovaps xmm9, [rsp+0x90]
000071409bfd977a  vmovaps xmm10, [rsp+0xA0]
000071409bfd9783  vmovaps xmm11, [rsp+0xB0]
000071409bfd978c  vmovaps xmm12, [rsp+0xC0]
000071409bfd9795  vmovaps xmm14, [rsp+0xD0]
000071409bfd979e  vmovaps xmm15, [rsp+0xE0]
000071409bfd97a7  add rsp, 0xF0
000071409bfd97ae  pop r11
000071409bfd97b0  pop r10
000071409bfd97b2  pop r9
000071409bfd97b4  pop r8
000071409bfd97b6  pop rsi
000071409bfd97b7  pop rdi
000071409bfd97b8  pop rdx
000071409bfd97b9  pop rcx
000071409bfd97ba  pop rax
000071409bfd97bb  add rsp, 0x08
000071409bfd97bf  jmp 0x000071409BFD6C7D
000071409bfd97c4  sub rsp, 0x08
000071409bfd97c8  push rax
000071409bfd97c9  push rcx
000071409bfd97ca  push rdx
000071409bfd97cb  push rdi
000071409bfd97cc  push rsi
000071409bfd97cd  push r8
000071409bfd97cf  push r9
000071409bfd97d1  push r10
000071409bfd97d3  push r11
000071409bfd97d5  sub rsp, 0xF0
000071409bfd97dc  vmovaps [rsp], xmm0
000071409bfd97e1  vmovaps [rsp+0x10], xmm1
000071409bfd97e7  vmovaps [rsp+0x20], xmm2
000071409bfd97ed  vmovaps [rsp+0x30], xmm3
000071409bfd97f3  vmovaps [rsp+0x40], xmm4
000071409bfd97f9  vmovaps [rsp+0x50], xmm5
000071409bfd97ff  vmovaps [rsp+0x60], xmm6
000071409bfd9805  vmovaps [rsp+0x70], xmm7
000071409bfd980b  vmovaps [rsp+0x80], xmm8
000071409bfd9814  vmovaps [rsp+0x90], xmm9
000071409bfd981d  vmovaps [rsp+0xA0], xmm10
000071409bfd9826  vmovaps [rsp+0xB0], xmm11
000071409bfd982f  vmovaps [rsp+0xC0], xmm12
000071409bfd9838  vmovaps [rsp+0xD0], xmm13
000071409bfd9841  vmovaps [rsp+0xE0], xmm15
000071409bfd984a  sub rsp, 0x40
000071409bfd984e  lea rdi, [rsp]
000071409bfd9852  lea rsi, [rsp+0x10]
000071409bfd9857  lea rdx, [rsp+0x20]
000071409bfd985c  lea rcx, [rsp+0x30]
000071409bfd9861  mov r8d, 0x00
000071409bfd9867  lea r9, [r15+0x3A8]
000071409bfd986e  movaps [rdi], xmm14
000071409bfd9872  movaps [rsi], xmm11
000071409bfd9876  movaps [rdx], xmm1
000071409bfd9879  movaps [rcx], xmm15
000071409bfd987d  mov rax, 0x6219BEBC2A50
000071409bfd9887  call rax
000071409bfd9889  movaps xmm14, [rsp]
000071409bfd988e  add rsp, 0x40
000071409bfd9892  vmovaps xmm0, [rsp]
000071409bfd9897  vmovaps xmm1, [rsp+0x10]
000071409bfd989d  vmovaps xmm2, [rsp+0x20]
000071409bfd98a3  vmovaps xmm3, [rsp+0x30]
000071409bfd98a9  vmovaps xmm4, [rsp+0x40]
000071409bfd98af  vmovaps xmm5, [rsp+0x50]
000071409bfd98b5  vmovaps xmm6, [rsp+0x60]
000071409bfd98bb  vmovaps xmm7, [rsp+0x70]
000071409bfd98c1  vmovaps xmm8, [rsp+0x80]
000071409bfd98ca  vmovaps xmm9, [rsp+0x90]
000071409bfd98d3  vmovaps xmm10, [rsp+0xA0]
000071409bfd98dc  vmovaps xmm11, [rsp+0xB0]
000071409bfd98e5  vmovaps xmm12, [rsp+0xC0]
000071409bfd98ee  vmovaps xmm13, [rsp+0xD0]
000071409bfd98f7  vmovaps xmm15, [rsp+0xE0]
000071409bfd9900  add rsp, 0xF0
000071409bfd9907  pop r11
000071409bfd9909  pop r10
000071409bfd990b  pop r9
000071409bfd990d  pop r8
000071409bfd990f  pop rsi
000071409bfd9910  pop rdi
000071409bfd9911  pop rdx
000071409bfd9912  pop rcx
000071409bfd9913  pop rax
000071409bfd9914  add rsp, 0x08
000071409bfd9918  jmp 0x000071409BFD6CAB
000071409bfd991d  call 0x000071409BEACF70
000071409bfd9922  jmp 0x000071409BFD6CB9
000071409bfd9927  call 0x000071409BE0C380
000071409bfd992c  jmp 0x000071409BFD6CC3
000071409bfd9931  call 0x000071409BE08C20
000071409bfd9936  jmp 0x000071409BFD6CCD
000071409bfd993b  call 0x000071409BE0D600
000071409bfd9940  jmp 0x000071409BFD6CD7
000071409bfd9945  int3
000071409bfd9946  nop [rax+rax*1], ax
000071409bfd994f  nop
000071409bfd9950  mov eax, [r15+0x48]
000071409bfd9954  lea r14d, [eax+0x01]
000071409bfd9959  mov [rsp+0x10], r14d
000071409bfd995e  mov r14d, r14d
000071409bfd9961  mov [r15+0x48], r14
000071409bfd9965  xor eax, eax
000071409bfd9967  mov r14d, [rsp+0x10]
000071409bfd996c  cmp r14d, 0x1F4
000071409bfd9973  cmc
000071409bfd9974  lahf
000071409bfd9975  seto al
000071409bfd9978  mov [r15+0x108], eax
000071409bfd997f  mov eax, [r15+0x108]
000071409bfd9986  sahf
000071409bfd9987  jnz 0x000071409BFD99B9
000071409bfd9989  cmp dword ptr [r15+0x318], 0x00
000071409bfd9991  jz 0x000071409BFDD2E0
000071409bfd9997  nop [rax+rax*1], ax
000071409bfd99a0  nop [rax+rax*1], eax
000071409bfd99a8  mov eax, 0x410670
000071409bfd99ad  mov [r15+0x100], rax
000071409bfd99b4  jmp 0x000071409BDFE110
000071409bfd99b9  cmp dword ptr [r15+0x318], 0x00
000071409bfd99c1  jz 0x000071409BFD99F0
000071409bfd99c7  nop [rax+rax*1], ax
000071409bfd99d0  nop [rax+rax*1], eax
000071409bfd99d8  mov eax, 0x4104EC
000071409bfd99dd  mov [r15+0x100], rax
000071409bfd99e4  jmp 0x000071409BDFE110
000071409bfd99e9  int3
000071409bfd99ea  int3
000071409bfd99eb  nop [rax+rax*1], eax
000071409bfd99f0  mov rax, [r15+0x40]
000071409bfd99f4  vxorps xmm1, xmm1, xmm1
000071409bfd99f8  vpbroadcastq xmm1, xmm1
000071409bfd99fd  vxorps xmm15, xmm15, xmm15
000071409bfd9a02  vpbroadcastq xmm15, xmm15
000071409bfd9a07  lea r14, [rax+0x30]
000071409bfd9a0b  mov r12, [r13+r14*1]
000071409bfd9a10  lea r14, [rax+0x38]
000071409bfd9a14  mov r11, [r13+r14*1]
000071409bfd9a19  movq xmm14, r12
000071409bfd9a1e  movq xmm13, r11
000071409bfd9a23  movq xmm14, xmm14
000071409bfd9a28  movq xmm13, xmm13
000071409bfd9a2d  vmovaps [rsp+0x10], xmm13
000071409bfd9a33  movq xmm13, xmm13
000071409bfd9a38  movaps [r15+0x270], xmm13
000071409bfd9a40  movaps xmm13, [r15+0x160]
000071409bfd9a48  vmovaps [rsp+0x20], xmm13
000071409bfd9a4e  vmovaps xmm12, [rsp+0x20]
000071409bfd9a54  por xmm13, xmm12
000071409bfd9a59  lea r14, [rax+0x20]
000071409bfd9a5d  mov r12, [r13+r14*1]
000071409bfd9a62  lea r14, [rax+0x28]
000071409bfd9a66  mov r11, [r13+r14*1]
000071409bfd9a6b  movq xmm12, r12
000071409bfd9a70  movq xmm11, r11
000071409bfd9a75  movq xmm12, xmm12
000071409bfd9a7a  movq xmm11, xmm11
000071409bfd9a7f  movaps xmm10, [r15+0x2D0]
000071409bfd9a87  vmovaps [rsp+0x20], xmm10
000071409bfd9a8d  vmovaps xmm9, [rsp+0x20]
000071409bfd9a93  por xmm10, xmm9
000071409bfd9a98  movaps xmm9, [r15+0x300]
000071409bfd9aa0  vmovaps [rsp+0x20], xmm9
000071409bfd9aa6  vmovaps xmm8, [rsp+0x20]
000071409bfd9aac  por xmm9, xmm8
000071409bfd9ab1  movaps xmm8, [r15+0x2B0]
000071409bfd9ab9  vmovaps [rsp+0x20], xmm8
000071409bfd9abf  vmovaps xmm7, [rsp+0x20]
000071409bfd9ac5  por xmm8, xmm7
000071409bfd9aca  movaps xmm7, [r15+0x180]
000071409bfd9ad2  vmovaps [rsp+0x20], xmm7
000071409bfd9ad8  vmovaps xmm6, [rsp+0x20]
000071409bfd9ade  por xmm7, xmm6
000071409bfd9ae2  lea r14, [rax+0x10]
000071409bfd9ae6  mov r12, [r13+r14*1]
000071409bfd9aeb  lea r14, [rax+0x18]
000071409bfd9aef  mov r11, [r13+r14*1]
000071409bfd9af4  movq xmm6, r12
000071409bfd9af9  movq xmm5, r11
000071409bfd9afe  movq xmm6, xmm6
000071409bfd9b02  movq xmm5, xmm5
000071409bfd9b06  movaps xmm4, [r15+0x200]
000071409bfd9b0e  vmovaps [rsp+0x20], xmm4
000071409bfd9b14  vmovaps xmm3, [rsp+0x20]
000071409bfd9b1a  por xmm4, xmm3
000071409bfd9b1e  movaps xmm3, [r15+0x1F0]
000071409bfd9b26  vmovaps [rsp+0x20], xmm3
000071409bfd9b2c  vmovaps xmm2, [rsp+0x20]
000071409bfd9b32  por xmm3, xmm2
000071409bfd9b36  movaps xmm2, [r15+0x2E0]
000071409bfd9b3e  vmovaps [rsp+0x20], xmm2
000071409bfd9b44  vmovaps [rsp+0x30], xmm1
000071409bfd9b4a  vmovaps xmm1, [rsp+0x20]
000071409bfd9b50  por xmm2, xmm1
000071409bfd9b54  movaps xmm1, [r15+0x2A0]
000071409bfd9b5c  vmovaps [rsp+0x20], xmm1
000071409bfd9b62  vmovaps [rsp+0x40], xmm15
000071409bfd9b68  vmovaps xmm15, [rsp+0x20]
000071409bfd9b6e  por xmm1, xmm15
000071409bfd9b73  movaps xmm15, [r15+0x280]
000071409bfd9b7b  vmovaps [rsp+0x20], xmm15
000071409bfd9b81  vmovaps [rsp+0x50], xmm1
000071409bfd9b87  vmovaps xmm1, [rsp+0x20]
000071409bfd9b8d  por xmm15, xmm1
000071409bfd9b92  movaps xmm1, [r15+0x1C0]
000071409bfd9b9a  vmovaps [rsp+0x20], xmm1
000071409bfd9ba0  vmovaps [rsp+0x60], xmm15
000071409bfd9ba6  vmovaps xmm15, [rsp+0x20]
000071409bfd9bac  por xmm1, xmm15
000071409bfd9bb1  movaps xmm15, [r15+0x210]
000071409bfd9bb9  vmovaps [rsp+0x20], xmm15
000071409bfd9bbf  vmovaps [rsp+0x70], xmm1
000071409bfd9bc5  vmovaps xmm1, [rsp+0x20]
000071409bfd9bcb  por xmm15, xmm1
000071409bfd9bd0  mov r14, [r13+rax*1]
000071409bfd9bd5  vmovq xmm1, r14
000071409bfd9bda  vpbroadcastq xmm1, xmm1
000071409bfd9bdf  vmovaps [rsp+0x20], xmm1
000071409bfd9be5  vxorps xmm1, xmm1, xmm1
000071409bfd9be9  vpbroadcastq xmm1, xmm1
000071409bfd9bee  mov r14, [r15+0xF8]
000071409bfd9bf5  vmovaps [rsp+0x80], xmm1
000071409bfd9bfe  movups xmm1, [r13+r14*1]
000071409bfd9c04  vmovaps [rsp+0x90], xmm1
000071409bfd9c0d  vxorps xmm1, xmm1, xmm1
000071409bfd9c11  vpbroadcastq xmm1, xmm1
000071409bfd9c16  lea r12, [rax+0x08]
000071409bfd9c1a  mov rax, [r13+r12*1]
000071409bfd9c1f  vmovaps [rsp+0xA0], xmm1
000071409bfd9c28  movq xmm1, rax
000071409bfd9c2d  movaps [r15+0x240], xmm1
000071409bfd9c35  mov rax, [r15+0x50]
000071409bfd9c39  mov [r15+0x60], rax
000071409bfd9c3d  mov qword ptr [r15+0x58], 0x40
000071409bfd9c45  vmovaps xmm1, [rsp+0x30]
000071409bfd9c4b  vmovaps [rsp+0x30], xmm15
000071409bfd9c51  vmovaps xmm15, [rsp+0x90]
000071409bfd9c5a  vmovaps [rsp+0x90], xmm14
000071409bfd9c63  vmovaps xmm14, [rsp+0x20]
000071409bfd9c69  vmovaps [rsp+0x20], xmm13
000071409bfd9c6f  vmovaps [rsp+0xB0], xmm12
000071409bfd9c78  movaps xmm13, xmm1
000071409bfd9c7c  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd9c87  vptest xmm12, xmm12
000071409bfd9c8c  jnz 0x000071409BFDA72F
000071409bfd9c92  movaps xmm1, [r15+0x250]
000071409bfd9c9a  vmovaps xmm15, [rsp+0x40]
000071409bfd9ca0  vmovaps [rsp+0x40], xmm13
000071409bfd9ca6  movaps xmm12, xmm15
000071409bfd9caa  vfmadd231pd xmm12, xmm1, xmm14
000071409bfd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
000071409bfd9cb5  vptest xmm13, xmm13
000071409bfd9cba  jnz 0x000071409BFDA888
000071409bfd9cc0  movaps xmm15, [r15+0x1E0]
000071409bfd9cc8  vmovaps [rsp+0xC0], xmm15
000071409bfd9cd1  vmovaps xmm13, [rsp+0xC0]
000071409bfd9cda  por xmm15, xmm13
000071409bfd9cdf  movaps xmm13, [r15+0x1D0]
000071409bfd9ce7  vmovaps [rsp+0xC0], xmm13
000071409bfd9cf0  vmovaps [rsp+0xD0], xmm1
000071409bfd9cf9  vmovaps xmm1, [rsp+0xC0]
000071409bfd9d02  por xmm13, xmm1
000071409bfd9d07  movaps xmm1, [r15+0x2C0]
000071409bfd9d0f  vmovaps [rsp+0xC0], xmm1
000071409bfd9d18  vmovaps [rsp+0xE0], xmm15
000071409bfd9d21  vmovaps xmm15, [rsp+0xC0]
000071409bfd9d2a  por xmm1, xmm15
000071409bfd9d2f  movaps xmm15, [r15+0x290]
000071409bfd9d37  vmovaps [rsp+0xC0], xmm15
000071409bfd9d40  vmovaps [rsp+0xF0], xmm1
000071409bfd9d49  vmovaps xmm1, [rsp+0xC0]
000071409bfd9d52  por xmm15, xmm1
000071409bfd9d57  movaps xmm1, [r15+0x260]
000071409bfd9d5f  vmovaps [rsp+0xC0], xmm1
000071409bfd9d68  vmovaps [rsp+0x100], xmm15
000071409bfd9d71  vmovaps xmm15, [rsp+0xC0]
000071409bfd9d7a  por xmm1, xmm15
000071409bfd9d7f  vmovaps xmm15, [rsp+0xD0]
000071409bfd9d88  vmovaps [rsp+0xC0], xmm1
000071409bfd9d91  vmovaps xmm1, [rsp+0xD0]
000071409bfd9d9a  por xmm15, xmm1
000071409bfd9d9f  lea r12, [r14+0xC0]
000071409bfd9da6  movups xmm1, [r13+r12*1]
000071409bfd9dac  mov [rsp+0xD0], rax
000071409bfd9db4  xor eax, eax
000071409bfd9db6  mov r12d, 0x40
000071409bfd9dbc  mov r11d, 0x200
000071409bfd9dc2  cmp r12, r11
000071409bfd9dc5  cmc
000071409bfd9dc6  lahf
000071409bfd9dc7  seto al
000071409bfd9dca  mov [r15+0x108], eax
000071409bfd9dd1  vmovaps [rsp+0x110], xmm1
000071409bfd9dda  vmovaps xmm1, [rsp+0x80]
000071409bfd9de3  vmovaps [rsp+0x80], xmm15
000071409bfd9dec  vmovaps xmm15, [rsp+0x110]
000071409bfd9df5  vmovaps [rsp+0x110], xmm13
000071409bfd9dfe  vmovaps [rsp+0x120], xmm12
000071409bfd9e07  movaps xmm13, xmm1
000071409bfd9e0b  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd9e16  vptest xmm12, xmm12
000071409bfd9e1b  jnz 0x000071409BFDA9EB
000071409bfd9e21  lea rax, [r14+0xB0]
000071409bfd9e28  movups xmm1, [r13+rax*1]
000071409bfd9e2e  vmovaps xmm15, [rsp+0xA0]
000071409bfd9e37  vmovaps [rsp+0xA0], xmm13
000071409bfd9e40  movaps xmm12, xmm15
000071409bfd9e44  vfmadd231pd xmm12, xmm1, xmm14
000071409bfd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
000071409bfd9e4f  vptest xmm13, xmm13
000071409bfd9e54  jnz 0x000071409BFDAB4E
000071409bfd9e5a  vmovaps xmm1, [rsp+0x30]
000071409bfd9e60  vmovaps xmm15, [rsp+0x30]
000071409bfd9e66  por xmm1, xmm15
000071409bfd9e6b  movaps [r15+0x210], xmm1
000071409bfd9e73  vmovaps xmm15, [rsp+0x70]
000071409bfd9e79  vmovaps xmm14, [rsp+0x70]
000071409bfd9e7f  por xmm15, xmm14
000071409bfd9e84  movaps [r15+0x1C0], xmm15
000071409bfd9e8c  vmovaps xmm14, [rsp+0x60]
000071409bfd9e92  vmovaps xmm13, [rsp+0x60]
000071409bfd9e98  por xmm14, xmm13
000071409bfd9e9d  movaps [r15+0x280], xmm14
000071409bfd9ea5  vmovaps xmm13, [rsp+0x50]
000071409bfd9eab  vmovaps [rsp+0x30], xmm1
000071409bfd9eb1  vmovaps xmm1, [rsp+0x50]
000071409bfd9eb7  por xmm13, xmm1
000071409bfd9ebc  movaps [r15+0x2A0], xmm13
000071409bfd9ec4  vmovaps [rsp+0x50], xmm2
000071409bfd9eca  vmovaps xmm1, [rsp+0x50]
000071409bfd9ed0  por xmm2, xmm1
000071409bfd9ed4  movaps [r15+0x2E0], xmm2
000071409bfd9edc  vmovaps [rsp+0x50], xmm3
000071409bfd9ee2  vmovaps xmm1, [rsp+0x50]
000071409bfd9ee8  por xmm3, xmm1
000071409bfd9eec  movaps [r15+0x1F0], xmm3
000071409bfd9ef4  vmovaps xmm1, [rsp+0x80]
000071409bfd9efd  vmovaps [rsp+0x50], xmm15
000071409bfd9f03  vmovaps xmm15, [rsp+0x80]
000071409bfd9f0c  por xmm1, xmm15
000071409bfd9f11  movaps [r15+0x250], xmm1
000071409bfd9f19  vmovaps xmm1, [rsp+0xC0]
000071409bfd9f22  vmovaps xmm15, [rsp+0xC0]
000071409bfd9f2b  por xmm1, xmm15
000071409bfd9f30  movaps [r15+0x260], xmm1
000071409bfd9f38  vmovaps xmm15, [rsp+0x100]
000071409bfd9f41  vmovaps [rsp+0x60], xmm1
000071409bfd9f47  vmovaps xmm1, [rsp+0x100]
000071409bfd9f50  por xmm15, xmm1
000071409bfd9f55  movaps [r15+0x290], xmm15
000071409bfd9f5d  vmovaps xmm1, [rsp+0xF0]
000071409bfd9f66  vmovaps [rsp+0x70], xmm15
000071409bfd9f6c  vmovaps xmm15, [rsp+0xF0]
000071409bfd9f75  por xmm1, xmm15
000071409bfd9f7a  movaps [r15+0x2C0], xmm1
000071409bfd9f82  movq xmm15, qword ptr [r15+0x240]
000071409bfd9f8b  vmovaps [rsp+0x80], xmm15
000071409bfd9f94  vpermilpd xmm15, xmm15, 0x00
000071409bfd9f9a  vmovaps [rsp+0xC0], xmm1
000071409bfd9fa3  vmovaps xmm1, [rsp+0x40]
000071409bfd9fa9  vmovaps [rsp+0x40], xmm15
000071409bfd9faf  vmovaps xmm15, [rsp+0x30]
000071409bfd9fb5  vmovaps [rsp+0x30], xmm14
000071409bfd9fbb  vmovaps xmm14, [rsp+0x40]
000071409bfd9fc1  vmovaps [rsp+0x40], xmm13
000071409bfd9fc7  vmovaps [rsp+0xF0], xmm12
000071409bfd9fd0  movaps xmm13, xmm1
000071409bfd9fd4  vfmadd231pd xmm13, xmm15, xmm14
000071409bfd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
000071409bfd9fdf  vptest xmm12, xmm12
000071409bfd9fe4  jnz 0x000071409BFDACA7
000071409bfd9fea  vmovaps xmm1, [rsp+0x80]
000071409bfd9ff3  vpermilpd xmm1, xmm1, 0x00
000071409bfd9ff9  vmovaps xmm15, [rsp+0xA0]
000071409bfda002  movaps xmm14, xmm15
000071409bfda006  vfmadd231pd xmm14, xmm2, xmm1
000071409bfda00b  vcmppd xmm12, xmm14, xmm14, 0x03
000071409bfda011  vptest xmm12, xmm12
000071409bfda016  jnz 0x000071409BFDAE00
000071409bfda01c  vmovaps xmm1, [rsp+0x80]
000071409bfda025  vpermilpd xmm1, xmm1, 0x00
000071409bfda02b  vmovaps xmm15, [rsp+0x120]
000071409bfda034  vmovaps xmm12, [rsp+0x50]
000071409bfda03a  vmovaps [rsp+0x50], xmm14
000071409bfda040  movaps xmm2, xmm15
000071409bfda044  vfmadd231pd xmm2, xmm12, xmm1
000071409bfda049  vcmppd xmm14, xmm2, xmm2, 0x03
000071409bfda04e  vptest xmm14, xmm14
000071409bfda053  jnz 0x000071409BFDAF58
000071409bfda059  vmovaps xmm1, [rsp+0x110]
000071409bfda062  vmovaps xmm15, [rsp+0x110]
000071409bfda06b  por xmm1, xmm15
000071409bfda070  movaps [r15+0x1D0], xmm1
000071409bfda078  vmovaps xmm15, [rsp+0x80]
000071409bfda081  vpermilpd xmm15, xmm15, 0x00
000071409bfda087  vmovaps xmm14, [rsp+0xF0]
000071409bfda090  vmovaps [rsp+0x80], xmm1
000071409bfda099  movaps xmm12, xmm14
000071409bfda09d  vfmadd231pd xmm12, xmm3, xmm15
000071409bfda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
000071409bfda0a8  vptest xmm1, xmm1
000071409bfda0ad  jnz 0x000071409BFDB0AF
000071409bfda0b3  vmovaps [rsp+0xA0], xmm4
000071409bfda0bc  vmovaps xmm1, [rsp+0xA0]
000071409bfda0c5  por xmm4, xmm1
000071409bfda0c9  movaps [r15+0x200], xmm4
000071409bfda0d1  vmovaps xmm1, [rsp+0xE0]
000071409bfda0da  vmovaps xmm15, [rsp+0xE0]
000071409bfda0e3  por xmm1, xmm15
000071409bfda0e8  movaps [r15+0x1E0], xmm1
000071409bfda0f0  vmovaps [rsp+0xA0], xmm8
000071409bfda0f9  vmovaps xmm1, [rsp+0xA0]
000071409bfda102  por xmm8, xmm1
000071409bfda107  movaps [r15+0x2B0], xmm8
000071409bfda10f  vmovaps [rsp+0xA0], xmm9
000071409bfda118  vmovaps xmm1, [rsp+0xA0]
000071409bfda121  por xmm9, xmm1
000071409bfda126  movaps [r15+0x300], xmm9
000071409bfda12e  vmovaps [rsp+0xA0], xmm6
000071409bfda137  vpermilpd xmm6, xmm6, 0x00
000071409bfda13d  vmovaps xmm14, [rsp+0x60]
000071409bfda143  movaps xmm9, xmm13
000071409bfda147  vfmadd231pd xmm9, xmm14, xmm6
000071409bfda14c  vcmppd xmm3, xmm9, xmm9, 0x03
000071409bfda152  vptest xmm3, xmm3
000071409bfda157  jnz 0x000071409BFDB208
000071409bfda15d  vmovaps xmm14, [rsp+0xA0]
000071409bfda166  vpermilpd xmm14, xmm14, 0x00
000071409bfda16c  vmovaps xmm13, [rsp+0x50]
000071409bfda172  vmovaps xmm6, [rsp+0xC0]
000071409bfda17b  vmovaps [rsp+0x50], xmm1
000071409bfda181  movaps xmm3, xmm13
000071409bfda185  vfmadd231pd xmm3, xmm6, xmm14
000071409bfda18a  vcmppd xmm1, xmm3, xmm3, 0x03
000071409bfda18f  vptest xmm1, xmm1
000071409bfda194  jnz 0x000071409BFDB361
000071409bfda19a  vmovaps xmm1, [rsp+0xA0]
000071409bfda1a3  vpermilpd xmm1, xmm1, 0x00
000071409bfda1a9  vmovaps xmm14, [rsp+0x30]
000071409bfda1af  movaps xmm6, xmm2
000071409bfda1b2  vfmadd231pd xmm6, xmm14, xmm1
000071409bfda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
000071409bfda1bc  vptest xmm13, xmm13
000071409bfda1c1  jnz 0x000071409BFDB4B8
000071409bfda1c7  vmovaps xmm1, [rsp+0xA0]
000071409bfda1d0  vpermilpd xmm1, xmm1, 0x00
000071409bfda1d6  vmovaps xmm14, [rsp+0x80]
000071409bfda1df  movaps xmm13, xmm12
000071409bfda1e3  vfmadd231pd xmm13, xmm14, xmm1
000071409bfda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
000071409bfda1ee  vptest xmm2, xmm2
000071409bfda1f3  jnz 0x000071409BFDB60E
000071409bfda1f9  vmovaps [rsp+0x30], xmm7
000071409bfda1ff  vmovaps xmm1, [rsp+0x30]
000071409bfda205  por xmm7, xmm1
000071409bfda209  movaps [r15+0x180], xmm7
000071409bfda211  vmovaps [rsp+0x30], xmm10
000071409bfda217  vmovaps xmm1, [rsp+0x30]
000071409bfda21d  por xmm10, xmm1
000071409bfda222  movaps [r15+0x2D0], xmm10
000071409bfda22a  vmovaps [rsp+0x30], xmm5
000071409bfda230  vpermilpd xmm5, xmm5, 0x00
000071409bfda236  vmovaps xmm14, [rsp+0x50]
000071409bfda23c  movaps xmm12, xmm3
000071409bfda240  vfmadd231pd xmm12, xmm14, xmm5
000071409bfda245  vcmppd xmm10, xmm12, xmm12, 0x03
000071409bfda24b  vptest xmm10, xmm10
000071409bfda250  jnz 0x000071409BFDB767
000071409bfda256  vmovaps xmm14, [rsp+0x30]
000071409bfda25c  vpermilpd xmm14, xmm14, 0x00
000071409bfda262  movaps xmm10, xmm9
000071409bfda266  vfmadd231pd xmm10, xmm7, xmm14
000071409bfda26b  vcmppd xmm5, xmm10, xmm10, 0x03
000071409bfda271  vptest xmm5, xmm5
000071409bfda276  jnz 0x000071409BFDB8BF
000071409bfda27c  lea rax, [r14+0x80]
000071409bfda283  movups xmm14, [r13+rax*1]
000071409bfda289  movaps [r15+0x2F0], xmm14
000071409bfda291  vmovaps xmm9, [rsp+0x30]
000071409bfda297  vpermilpd xmm9, xmm9, 0x00
000071409bfda29d  vmovaps xmm7, [rsp+0x70]
000071409bfda2a3  movaps xmm5, xmm6
000071409bfda2a6  vfmadd231pd xmm5, xmm7, xmm9
000071409bfda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
000071409bfda2b0  vptest xmm3, xmm3
000071409bfda2b5  jnz 0x000071409BFDBA22
000071409bfda2bb  vmovaps xmm9, [rsp+0x30]
000071409bfda2c1  vpermilpd xmm9, xmm9, 0x00
000071409bfda2c7  movaps xmm7, xmm13
000071409bfda2cb  vfmadd231pd xmm7, xmm1, xmm9
000071409bfda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
000071409bfda2d5  vptest xmm6, xmm6
000071409bfda2da  jnz 0x000071409BFDBB78
000071409bfda2e0  vmovaps xmm1, [rsp+0x20]
000071409bfda2e6  vmovaps xmm13, [rsp+0x20]
000071409bfda2ec  por xmm1, xmm13
000071409bfda2f1  movaps [r15+0x160], xmm1
000071409bfda2f9  lea rax, [r14+0x40]
000071409bfda2fd  movups xmm13, [r13+rax*1]
000071409bfda303  lea rax, [r14+0x50]
000071409bfda307  movups xmm9, [r13+rax*1]
000071409bfda30d  movaps [r15+0x1B0], xmm13
000071409bfda315  movaps [r15+0x1A0], xmm9
000071409bfda31d  movaps xmm6, [r15+0x190]
000071409bfda325  vmovaps xmm3, [rsp+0xB0]
000071409bfda32e  vpermilpd xmm3, xmm3, 0x00
000071409bfda334  vmovaps [rsp+0x20], xmm1
000071409bfda33a  movaps xmm2, xmm12
000071409bfda33e  vfmadd231pd xmm2, xmm6, xmm3
000071409bfda343  vcmppd xmm1, xmm2, xmm2, 0x03
000071409bfda348  vptest xmm1, xmm1
000071409bfda34d  jnz 0x000071409BFDBCE3
000071409bfda353  vmovaps xmm1, [rsp+0xB0]
000071409bfda35c  vpermilpd xmm1, xmm1, 0x00
000071409bfda362  vmovaps xmm12, [rsp+0x20]
000071409bfda368  movaps xmm6, xmm10
000071409bfda36c  vfmadd231pd xmm6, xmm12, xmm1
000071409bfda371  vcmppd xmm3, xmm6, xmm6, 0x03
000071409bfda376  vptest xmm3, xmm3
000071409bfda37b  jnz 0x000071409BFDBE39
000071409bfda381  vmovaps xmm1, [rsp+0xB0]
000071409bfda38a  vpermilpd xmm1, xmm1, 0x00
000071409bfda390  vmovaps xmm12, [rsp+0x40]
000071409bfda396  movaps xmm10, xmm5
000071409bfda39a  vfmadd231pd xmm10, xmm12, xmm1
000071409bfda39f  vcmppd xmm3, xmm10, xmm10, 0x03
000071409bfda3a5  vptest xmm3, xmm3
000071409bfda3aa  jnz 0x000071409BFDBF90
000071409bfda3b0  vmovaps xmm1, [rsp+0xB0]
000071409bfda3b9  vpermilpd xmm1, xmm1, 0x00
000071409bfda3bf  movaps xmm12, xmm7
000071409bfda3c3  vfmadd231pd xmm12, xmm15, xmm1
000071409bfda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
000071409bfda3ce  vptest xmm5, xmm5
000071409bfda3d3  jnz 0x000071409BFDC0E8
000071409bfda3d9  lea rax, [r14+0x60]
000071409bfda3dd  movups xmm1, [r13+rax*1]
000071409bfda3e3  lea rax, [r14+0x70]
000071409bfda3e7  movups xmm15, [r13+rax*1]
000071409bfda3ed  movaps [r15+0x150], xmm1
000071409bfda3f5  movaps [r15+0x120], xmm15
000071409bfda3fd  vmovaps [rsp+0x20], xmm11
000071409bfda403  vpermilpd xmm11, xmm11, 0x00
000071409bfda409  movaps xmm7, xmm2
000071409bfda40c  vfmadd231pd xmm7, xmm9, xmm11
000071409bfda411  vcmppd xmm5, xmm7, xmm7, 0x03
000071409bfda416  vptest xmm5, xmm5
000071409bfda41b  jnz 0x000071409BFDC254
000071409bfda421  vmovaps xmm11, [rsp+0x20]
000071409bfda427  vpermilpd xmm11, xmm11, 0x00
000071409bfda42d  movaps xmm9, xmm6
000071409bfda431  vfmadd231pd xmm9, xmm1, xmm11
000071409bfda436  vcmppd xmm5, xmm9, xmm9, 0x03
000071409bfda43c  vptest xmm5, xmm5
000071409bfda441  jnz 0x000071409BFDC3AB
000071409bfda447  vmovaps xmm1, [rsp+0x20]
000071409bfda44d  vpermilpd xmm1, xmm1, 0x00
000071409bfda453  movaps xmm11, xmm10
000071409bfda457  vfmadd231pd xmm11, xmm8, xmm1
000071409bfda45c  vcmppd xmm6, xmm11, xmm11, 0x03
000071409bfda462  vptest xmm6, xmm6
000071409bfda467  jnz 0x000071409BFDC503
000071409bfda46d  vmovaps xmm1, [rsp+0x20]
000071409bfda473  vpermilpd xmm1, xmm1, 0x00
000071409bfda479  movaps xmm10, xmm12
000071409bfda47d  vfmadd231pd xmm10, xmm13, xmm1
000071409bfda482  vcmppd xmm8, xmm10, xmm10, 0x03
000071409bfda488  vptest xmm8, xmm8
000071409bfda48d  jnz 0x000071409BFDC65C
000071409bfda493  lea rax, [r14+0x20]
000071409bfda497  movups xmm1, [r13+rax*1]
000071409bfda49d  lea rax, [r14+0x30]
000071409bfda4a1  movups xmm13, [r13+rax*1]
000071409bfda4a7  vmovaps xmm12, [rsp+0x90]
000071409bfda4b0  vpermilpd xmm12, xmm12, 0x00
000071409bfda4b6  movaps xmm8, xmm7
000071409bfda4ba  vfmadd231pd xmm8, xmm4, xmm12
000071409bfda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
000071409bfda4c5  vptest xmm6, xmm6
000071409bfda4ca  jnz 0x000071409BFDC7C9
000071409bfda4d0  vmovaps xmm12, [rsp+0x90]
000071409bfda4d9  vpermilpd xmm12, xmm12, 0x00
000071409bfda4df  movaps xmm7, xmm9
000071409bfda4e3  vfmadd231pd xmm7, xmm14, xmm12
000071409bfda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
000071409bfda4ed  vptest xmm6, xmm6
000071409bfda4f2  jnz 0x000071409BFDC921
000071409bfda4f8  vmovaps xmm14, [rsp+0x90]
000071409bfda501  vpermilpd xmm14, xmm14, 0x00
000071409bfda507  movaps xmm12, xmm11
000071409bfda50b  vfmadd231pd xmm12, xmm15, xmm14
000071409bfda510  vcmppd xmm9, xmm12, xmm12, 0x03
000071409bfda516  vptest xmm9, xmm9
000071409bfda51b  jnz 0x000071409BFDCA79
000071409bfda521  vmovaps xmm15, [rsp+0x90]
000071409bfda52a  vpermilpd xmm15, xmm15, 0x00
000071409bfda530  movaps xmm11, xmm10
000071409bfda534  vfmadd231pd xmm11, xmm13, xmm15
000071409bfda539  vcmppd xmm14, xmm11, xmm11, 0x03
000071409bfda53f  vptest xmm14, xmm14
000071409bfda544  jnz 0x000071409BFDCBD3
000071409bfda54a  lea rax, [r14+0x90]
000071409bfda551  movups xmm15, [r13+rax*1]
000071409bfda557  lea rax, [r14+0xA0]
000071409bfda55e  movups xmm14, [r13+rax*1]
000071409bfda564  movaps [r15+0x140], xmm15
000071409bfda56c  movaps [r15+0x130], xmm14
000071409bfda574  vmovaps xmm13, [rsp+0x10]
000071409bfda57a  vpermilpd xmm13, xmm13, 0x00
000071409bfda580  movaps xmm10, xmm8
000071409bfda584  vfmadd231pd xmm10, xmm1, xmm13
000071409bfda589  vcmppd xmm9, xmm10, xmm10, 0x03
000071409bfda58f  vptest xmm9, xmm9
000071409bfda594  jnz 0x000071409BFDCD41
000071409bfda59a  movaps [r15+0x220], xmm10
000071409bfda5a2  lea rax, [r14+0x10]
000071409bfda5a6  movups xmm1, [r13+rax*1]
000071409bfda5ac  movaps [r15+0x240], xmm1
000071409bfda5b4  vmovaps xmm13, [rsp+0x10]
000071409bfda5ba  vpermilpd xmm13, xmm13, 0x00
000071409bfda5c0  movaps xmm9, xmm7
000071409bfda5c4  vfmadd231pd xmm9, xmm14, xmm13
000071409bfda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
000071409bfda5cf  vptest xmm8, xmm8
000071409bfda5d4  jnz 0x000071409BFDCEA4
000071409bfda5da  movaps [r15+0x110], xmm9
000071409bfda5e2  vmovaps xmm14, [rsp+0x10]
000071409bfda5e8  vpermilpd xmm14, xmm14, 0x00
000071409bfda5ee  movaps xmm13, xmm12
000071409bfda5f2  vfmadd231pd xmm13, xmm15, xmm14
000071409bfda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
000071409bfda5fd  vptest xmm8, xmm8
000071409bfda602  jnz 0x000071409BFDCFFD
000071409bfda608  movaps [r15+0x170], xmm13
000071409bfda610  vmovaps xmm15, [rsp+0x10]
000071409bfda616  vpermilpd xmm15, xmm15, 0x00
000071409bfda61c  movaps xmm14, xmm11
000071409bfda620  vfmadd231pd xmm14, xmm1, xmm15
000071409bfda625  vcmppd xmm12, xmm14, xmm14, 0x03
000071409bfda62b  vptest xmm12, xmm12
000071409bfda630  jnz 0x000071409BFDD157
000071409bfda636  movaps [r15+0x230], xmm14
000071409bfda63e  mov rax, [rsp+0xD0]
000071409bfda646  movups [r13+rax*1], xmm9
000071409bfda64c  lea r14, [rax+0x10]
000071409bfda650  movups [r13+r14*1], xmm13
000071409bfda656  lea r14, [rax+0x20]
000071409bfda65a  movups [r13+r14*1], xmm10
000071409bfda660  lea r14, [rax+0x30]
000071409bfda664  movups [r13+r14*1], xmm14
000071409bfda66a  mov eax, [r15+0x108]
000071409bfda671  sahf
000071409bfda672  jnz 0x000071409BFDA6A4
000071409bfda674  cmp dword ptr [r15+0x318], 0x00
000071409bfda67c  jz 0x000071409BFD9950
000071409bfda682  nop [rax+rax*1], ax
000071409bfda68b  nop [rax+rax*1], eax
000071409bfda693  mov eax, 0x410664
000071409bfda698  mov [r15+0x100], rax
000071409bfda69f  jmp 0x000071409BDFE110
000071409bfda6a4  cmp dword ptr [r15+0x318], 0x00
000071409bfda6ac  jz 0x000071409BFD6050
000071409bfda6b2  nop [rax+rax*1], ax
000071409bfda6bb  nop [rax+rax*1], eax
000071409bfda6c3  mov eax, 0x4104F0
000071409bfda6c8  mov [r15+0x100], rax
000071409bfda6cf  jmp 0x000071409BDFE110
000071409bfda6d4  int3
000071409bfda6d5  call 0x000071409BEE27E0
000071409bfda6da  jmp 0x000071409BFD9A10
000071409bfda6df  call 0x000071409BEE1570
000071409bfda6e4  jmp 0x000071409BFD9A19
000071409bfda6e9  call 0x000071409BEE27E0
000071409bfda6ee  jmp 0x000071409BFD9A62
000071409bfda6f3  call 0x000071409BEE1570
000071409bfda6f8  jmp 0x000071409BFD9A6B
000071409bfda6fd  call 0x000071409BEE27E0
000071409bfda702  jmp 0x000071409BFD9AEB
000071409bfda707  call 0x000071409BEE1570
000071409bfda70c  jmp 0x000071409BFD9AF4
000071409bfda711  call 0x000071409BE0DC20
000071409bfda716  jmp 0x000071409BFD9BD5
000071409bfda71b  call 0x000071409BED64F0
000071409bfda720  jmp 0x000071409BFD9C04
000071409bfda725  call 0x000071409BEB47C0
000071409bfda72a  jmp 0x000071409BFD9C1F
000071409bfda72f  sub rsp, 0x08
000071409bfda733  push rax
000071409bfda734  push rcx
000071409bfda735  push rdx
000071409bfda736  push rdi
000071409bfda737  push rsi
000071409bfda738  push r8
000071409bfda73a  push r9
000071409bfda73c  push r10
000071409bfda73e  push r11
000071409bfda740  sub rsp, 0xF0
000071409bfda747  vmovaps [rsp], xmm0
000071409bfda74c  vmovaps [rsp+0x10], xmm1
000071409bfda752  vmovaps [rsp+0x20], xmm2
000071409bfda758  vmovaps [rsp+0x30], xmm3
000071409bfda75e  vmovaps [rsp+0x40], xmm4
000071409bfda764  vmovaps [rsp+0x50], xmm5
000071409bfda76a  vmovaps [rsp+0x60], xmm6
000071409bfda770  vmovaps [rsp+0x70], xmm7
000071409bfda776  vmovaps [rsp+0x80], xmm8
000071409bfda77f  vmovaps [rsp+0x90], xmm9
000071409bfda788  vmovaps [rsp+0xA0], xmm10
000071409bfda791  vmovaps [rsp+0xB0], xmm11
000071409bfda79a  vmovaps [rsp+0xC0], xmm12
000071409bfda7a3  vmovaps [rsp+0xD0], xmm14
000071409bfda7ac  vmovaps [rsp+0xE0], xmm15
000071409bfda7b5  sub rsp, 0x40
000071409bfda7b9  lea rdi, [rsp]
000071409bfda7bd  lea rsi, [rsp+0x10]
000071409bfda7c2  lea rdx, [rsp+0x20]
000071409bfda7c7  lea rcx, [rsp+0x30]
000071409bfda7cc  mov r8d, 0x00
000071409bfda7d2  lea r9, [r15+0x3A8]
000071409bfda7d9  movaps [rdi], xmm13
000071409bfda7dd  movaps [rsi], xmm1
000071409bfda7e0  movaps [rdx], xmm15
000071409bfda7e4  movaps [rcx], xmm14
000071409bfda7e8  mov rax, 0x6219BEBC2A50
000071409bfda7f2  call rax
000071409bfda7f4  movaps xmm13, [rsp]
000071409bfda7f9  add rsp, 0x40
000071409bfda7fd  vmovaps xmm0, [rsp]
000071409bfda802  vmovaps xmm1, [rsp+0x10]
000071409bfda808  vmovaps xmm2, [rsp+0x20]
000071409bfda80e  vmovaps xmm3, [rsp+0x30]
000071409bfda814  vmovaps xmm4, [rsp+0x40]
000071409bfda81a  vmovaps xmm5, [rsp+0x50]
000071409bfda820  vmovaps xmm6, [rsp+0x60]
000071409bfda826  vmovaps xmm7, [rsp+0x70]
000071409bfda82c  vmovaps xmm8, [rsp+0x80]
000071409bfda835  vmovaps xmm9, [rsp+0x90]
000071409bfda83e  vmovaps xmm10, [rsp+0xA0]
000071409bfda847  vmovaps xmm11, [rsp+0xB0]
000071409bfda850  vmovaps xmm12, [rsp+0xC0]
000071409bfda859  vmovaps xmm14, [rsp+0xD0]
000071409bfda862  vmovaps xmm15, [rsp+0xE0]
000071409bfda86b  add rsp, 0xF0
000071409bfda872  pop r11
000071409bfda874  pop r10
000071409bfda876  pop r9
000071409bfda878  pop r8
000071409bfda87a  pop rsi
000071409bfda87b  pop rdi
000071409bfda87c  pop rdx
000071409bfda87d  pop rcx
000071409bfda87e  pop rax
000071409bfda87f  add rsp, 0x08
000071409bfda883  jmp 0x000071409BFD9C92
000071409bfda888  sub rsp, 0x08
000071409bfda88c  push rax
000071409bfda88d  push rcx
000071409bfda88e  push rdx
000071409bfda88f  push rdi
000071409bfda890  push rsi
000071409bfda891  push r8
000071409bfda893  push r9
000071409bfda895  push r10
000071409bfda897  push r11
000071409bfda899  sub rsp, 0xF0
000071409bfda8a0  vmovaps [rsp], xmm0
000071409bfda8a5  vmovaps [rsp+0x10], xmm1
000071409bfda8ab  vmovaps [rsp+0x20], xmm2
000071409bfda8b1  vmovaps [rsp+0x30], xmm3
000071409bfda8b7  vmovaps [rsp+0x40], xmm4
000071409bfda8bd  vmovaps [rsp+0x50], xmm5
000071409bfda8c3  vmovaps [rsp+0x60], xmm6
000071409bfda8c9  vmovaps [rsp+0x70], xmm7
000071409bfda8cf  vmovaps [rsp+0x80], xmm8
000071409bfda8d8  vmovaps [rsp+0x90], xmm9
000071409bfda8e1  vmovaps [rsp+0xA0], xmm10
000071409bfda8ea  vmovaps [rsp+0xB0], xmm11
000071409bfda8f3  vmovaps [rsp+0xC0], xmm13
000071409bfda8fc  vmovaps [rsp+0xD0], xmm14
000071409bfda905  vmovaps [rsp+0xE0], xmm15
000071409bfda90e  sub rsp, 0x40
000071409bfda912  lea rdi, [rsp]
000071409bfda916  lea rsi, [rsp+0x10]
000071409bfda91b  lea rdx, [rsp+0x20]
000071409bfda920  lea rcx, [rsp+0x30]
000071409bfda925  mov r8d, 0x00
000071409bfda92b  lea r9, [r15+0x3A8]
000071409bfda932  movaps [rdi], xmm12
000071409bfda936  movaps [rsi], xmm15
000071409bfda93a  movaps [rdx], xmm1
000071409bfda93d  movaps [rcx], xmm14
000071409bfda941  mov rax, 0x6219BEBC2A50
000071409bfda94b  call rax
000071409bfda94d  movaps xmm12, [rsp]
000071409bfda952  add rsp, 0x40
000071409bfda956  vmovaps xmm0, [rsp]
000071409bfda95b  vmovaps xmm1, [rsp+0x10]
000071409bfda961  vmovaps xmm2, [rsp+0x20]
000071409bfda967  vmovaps xmm3, [rsp+0x30]
000071409bfda96d  vmovaps xmm4, [rsp+0x40]
000071409bfda973  vmovaps xmm5, [rsp+0x50]
000071409bfda979  vmovaps xmm6, [rsp+0x60]
000071409bfda97f  vmovaps xmm7, [rsp+0x70]
000071409bfda985  vmovaps xmm8, [rsp+0x80]
000071409bfda98e  vmovaps xmm9, [rsp+0x90]
000071409bfda997  vmovaps xmm10, [rsp+0xA0]
000071409bfda9a0  vmovaps xmm11, [rsp+0xB0]
000071409bfda9a9  vmovaps xmm13, [rsp+0xC0]
000071409bfda9b2  vmovaps xmm14, [rsp+0xD0]
000071409bfda9bb  vmovaps xmm15, [rsp+0xE0]
000071409bfda9c4  add rsp, 0xF0
000071409bfda9cb  pop r11
000071409bfda9cd  pop r10
000071409bfda9cf  pop r9
000071409bfda9d1  pop r8
000071409bfda9d3  pop rsi
000071409bfda9d4  pop rdi
000071409bfda9d5  pop rdx
000071409bfda9d6  pop rcx
000071409bfda9d7  pop rax
000071409bfda9d8  add rsp, 0x08
000071409bfda9dc  jmp 0x000071409BFD9CC0
000071409bfda9e1  call 0x000071409BEB52F0
000071409bfda9e6  jmp 0x000071409BFD9DAC
000071409bfda9eb  sub rsp, 0x08
000071409bfda9ef  push rax
000071409bfda9f0  push rcx
000071409bfda9f1  push rdx
000071409bfda9f2  push rdi
000071409bfda9f3  push rsi
000071409bfda9f4  push r8
000071409bfda9f6  push r9
000071409bfda9f8  push r10
000071409bfda9fa  push r11
000071409bfda9fc  sub rsp, 0xF0
000071409bfdaa03  vmovaps [rsp], xmm0
000071409bfdaa08  vmovaps [rsp+0x10], xmm1
000071409bfdaa0e  vmovaps [rsp+0x20], xmm2
000071409bfdaa14  vmovaps [rsp+0x30], xmm3
000071409bfdaa1a  vmovaps [rsp+0x40], xmm4
000071409bfdaa20  vmovaps [rsp+0x50], xmm5
000071409bfdaa26  vmovaps [rsp+0x60], xmm6
000071409bfdaa2c  vmovaps [rsp+0x70], xmm7
000071409bfdaa32  vmovaps [rsp+0x80], xmm8
000071409bfdaa3b  vmovaps [rsp+0x90], xmm9
000071409bfdaa44  vmovaps [rsp+0xA0], xmm10
000071409bfdaa4d  vmovaps [rsp+0xB0], xmm11
000071409bfdaa56  vmovaps [rsp+0xC0], xmm12
000071409bfdaa5f  vmovaps [rsp+0xD0], xmm14
000071409bfdaa68  vmovaps [rsp+0xE0], xmm15
000071409bfdaa71  sub rsp, 0x40
000071409bfdaa75  lea rdi, [rsp]
000071409bfdaa79  lea rsi, [rsp+0x10]
000071409bfdaa7e  lea rdx, [rsp+0x20]
000071409bfdaa83  lea rcx, [rsp+0x30]
000071409bfdaa88  mov r8d, 0x00
000071409bfdaa8e  lea r9, [r15+0x3A8]
000071409bfdaa95  movaps [rdi], xmm13
000071409bfdaa99  movaps [rsi], xmm1
000071409bfdaa9c  movaps [rdx], xmm15
000071409bfdaaa0  movaps [rcx], xmm14
000071409bfdaaa4  mov rax, 0x6219BEBC2A50
000071409bfdaaae  call rax
000071409bfdaab0  movaps xmm13, [rsp]
000071409bfdaab5  add rsp, 0x40
000071409bfdaab9  vmovaps xmm0, [rsp]
000071409bfdaabe  vmovaps xmm1, [rsp+0x10]
000071409bfdaac4  vmovaps xmm2, [rsp+0x20]
000071409bfdaaca  vmovaps xmm3, [rsp+0x30]
000071409bfdaad0  vmovaps xmm4, [rsp+0x40]
000071409bfdaad6  vmovaps xmm5, [rsp+0x50]
000071409bfdaadc  vmovaps xmm6, [rsp+0x60]
000071409bfdaae2  vmovaps xmm7, [rsp+0x70]
000071409bfdaae8  vmovaps xmm8, [rsp+0x80]
000071409bfdaaf1  vmovaps xmm9, [rsp+0x90]
000071409bfdaafa  vmovaps xmm10, [rsp+0xA0]
000071409bfdab03  vmovaps xmm11, [rsp+0xB0]
000071409bfdab0c  vmovaps xmm12, [rsp+0xC0]
000071409bfdab15  vmovaps xmm14, [rsp+0xD0]
000071409bfdab1e  vmovaps xmm15, [rsp+0xE0]
000071409bfdab27  add rsp, 0xF0
000071409bfdab2e  pop r11
000071409bfdab30  pop r10
000071409bfdab32  pop r9
000071409bfdab34  pop r8
000071409bfdab36  pop rsi
000071409bfdab37  pop rdi
000071409bfdab38  pop rdx
000071409bfdab39  pop rcx
000071409bfdab3a  pop rax
000071409bfdab3b  add rsp, 0x08
000071409bfdab3f  jmp 0x000071409BFD9E21
000071409bfdab44  call 0x000071409BDFF430
000071409bfdab49  jmp 0x000071409BFD9E2E
000071409bfdab4e  sub rsp, 0x08
000071409bfdab52  push rax
000071409bfdab53  push rcx
000071409bfdab54  push rdx
000071409bfdab55  push rdi
000071409bfdab56  push rsi
000071409bfdab57  push r8
000071409bfdab59  push r9
000071409bfdab5b  push r10
000071409bfdab5d  push r11
000071409bfdab5f  sub rsp, 0xF0
000071409bfdab66  vmovaps [rsp], xmm0
000071409bfdab6b  vmovaps [rsp+0x10], xmm1
000071409bfdab71  vmovaps [rsp+0x20], xmm2
000071409bfdab77  vmovaps [rsp+0x30], xmm3
000071409bfdab7d  vmovaps [rsp+0x40], xmm4
000071409bfdab83  vmovaps [rsp+0x50], xmm5
000071409bfdab89  vmovaps [rsp+0x60], xmm6
000071409bfdab8f  vmovaps [rsp+0x70], xmm7
000071409bfdab95  vmovaps [rsp+0x80], xmm8
000071409bfdab9e  vmovaps [rsp+0x90], xmm9
000071409bfdaba7  vmovaps [rsp+0xA0], xmm10
000071409bfdabb0  vmovaps [rsp+0xB0], xmm11
000071409bfdabb9  vmovaps [rsp+0xC0], xmm13
000071409bfdabc2  vmovaps [rsp+0xD0], xmm14
000071409bfdabcb  vmovaps [rsp+0xE0], xmm15
000071409bfdabd4  sub rsp, 0x40
000071409bfdabd8  lea rdi, [rsp]
000071409bfdabdc  lea rsi, [rsp+0x10]
000071409bfdabe1  lea rdx, [rsp+0x20]
000071409bfdabe6  lea rcx, [rsp+0x30]
000071409bfdabeb  mov r8d, 0x00
000071409bfdabf1  lea r9, [r15+0x3A8]
000071409bfdabf8  movaps [rdi], xmm12
000071409bfdabfc  movaps [rsi], xmm15
000071409bfdac00  movaps [rdx], xmm1
000071409bfdac03  movaps [rcx], xmm14
000071409bfdac07  mov rax, 0x6219BEBC2A50
000071409bfdac11  call rax
000071409bfdac13  movaps xmm12, [rsp]
000071409bfdac18  add rsp, 0x40
000071409bfdac1c  vmovaps xmm0, [rsp]
000071409bfdac21  vmovaps xmm1, [rsp+0x10]
000071409bfdac27  vmovaps xmm2, [rsp+0x20]
000071409bfdac2d  vmovaps xmm3, [rsp+0x30]
000071409bfdac33  vmovaps xmm4, [rsp+0x40]
000071409bfdac39  vmovaps xmm5, [rsp+0x50]
000071409bfdac3f  vmovaps xmm6, [rsp+0x60]
000071409bfdac45  vmovaps xmm7, [rsp+0x70]
000071409bfdac4b  vmovaps xmm8, [rsp+0x80]
000071409bfdac54  vmovaps xmm9, [rsp+0x90]
000071409bfdac5d  vmovaps xmm10, [rsp+0xA0]
000071409bfdac66  vmovaps xmm11, [rsp+0xB0]
000071409bfdac6f  vmovaps xmm13, [rsp+0xC0]
000071409bfdac78  vmovaps xmm14, [rsp+0xD0]
000071409bfdac81  vmovaps xmm15, [rsp+0xE0]
000071409bfdac8a  add rsp, 0xF0
000071409bfdac91  pop r11
000071409bfdac93  pop r10
000071409bfdac95  pop r9
000071409bfdac97  pop r8
000071409bfdac99  pop rsi
000071409bfdac9a  pop rdi
000071409bfdac9b  pop rdx
000071409bfdac9c  pop rcx
000071409bfdac9d  pop rax
000071409bfdac9e  add rsp, 0x08
000071409bfdaca2  jmp 0x000071409BFD9E5A
000071409bfdaca7  sub rsp, 0x08
000071409bfdacab  push rax
000071409bfdacac  push rcx
000071409bfdacad  push rdx
000071409bfdacae  push rdi
000071409bfdacaf  push rsi
000071409bfdacb0  push r8
000071409bfdacb2  push r9
000071409bfdacb4  push r10
000071409bfdacb6  push r11
000071409bfdacb8  sub rsp, 0xF0
000071409bfdacbf  vmovaps [rsp], xmm0
000071409bfdacc4  vmovaps [rsp+0x10], xmm1
000071409bfdacca  vmovaps [rsp+0x20], xmm2
000071409bfdacd0  vmovaps [rsp+0x30], xmm3
000071409bfdacd6  vmovaps [rsp+0x40], xmm4
000071409bfdacdc  vmovaps [rsp+0x50], xmm5
000071409bfdace2  vmovaps [rsp+0x60], xmm6
000071409bfdace8  vmovaps [rsp+0x70], xmm7
000071409bfdacee  vmovaps [rsp+0x80], xmm8
000071409bfdacf7  vmovaps [rsp+0x90], xmm9
000071409bfdad00  vmovaps [rsp+0xA0], xmm10
000071409bfdad09  vmovaps [rsp+0xB0], xmm11
000071409bfdad12  vmovaps [rsp+0xC0], xmm12
000071409bfdad1b  vmovaps [rsp+0xD0], xmm14
000071409bfdad24  vmovaps [rsp+0xE0], xmm15
000071409bfdad2d  sub rsp, 0x40
000071409bfdad31  lea rdi, [rsp]
000071409bfdad35  lea rsi, [rsp+0x10]
000071409bfdad3a  lea rdx, [rsp+0x20]
000071409bfdad3f  lea rcx, [rsp+0x30]
000071409bfdad44  mov r8d, 0x00
000071409bfdad4a  lea r9, [r15+0x3A8]
000071409bfdad51  movaps [rdi], xmm13
000071409bfdad55  movaps [rsi], xmm1
000071409bfdad58  movaps [rdx], xmm15
000071409bfdad5c  movaps [rcx], xmm14
000071409bfdad60  mov rax, 0x6219BEBC2A50
000071409bfdad6a  call rax
000071409bfdad6c  movaps xmm13, [rsp]
000071409bfdad71  add rsp, 0x40
000071409bfdad75  vmovaps xmm0, [rsp]
000071409bfdad7a  vmovaps xmm1, [rsp+0x10]
000071409bfdad80  vmovaps xmm2, [rsp+0x20]
000071409bfdad86  vmovaps xmm3, [rsp+0x30]
000071409bfdad8c  vmovaps xmm4, [rsp+0x40]
000071409bfdad92  vmovaps xmm5, [rsp+0x50]
000071409bfdad98  vmovaps xmm6, [rsp+0x60]
000071409bfdad9e  vmovaps xmm7, [rsp+0x70]
000071409bfdada4  vmovaps xmm8, [rsp+0x80]
000071409bfdadad  vmovaps xmm9, [rsp+0x90]
000071409bfdadb6  vmovaps xmm10, [rsp+0xA0]
000071409bfdadbf  vmovaps xmm11, [rsp+0xB0]
000071409bfdadc8  vmovaps xmm12, [rsp+0xC0]
000071409bfdadd1  vmovaps xmm14, [rsp+0xD0]
000071409bfdadda  vmovaps xmm15, [rsp+0xE0]
000071409bfdade3  add rsp, 0xF0
000071409bfdadea  pop r11
000071409bfdadec  pop r10
000071409bfdadee  pop r9
000071409bfdadf0  pop r8
000071409bfdadf2  pop rsi
000071409bfdadf3  pop rdi
000071409bfdadf4  pop rdx
000071409bfdadf5  pop rcx
000071409bfdadf6  pop rax
000071409bfdadf7  add rsp, 0x08
000071409bfdadfb  jmp 0x000071409BFD9FEA
000071409bfdae00  sub rsp, 0x08
000071409bfdae04  push rax
000071409bfdae05  push rcx
000071409bfdae06  push rdx
000071409bfdae07  push rdi
000071409bfdae08  push rsi
000071409bfdae09  push r8
000071409bfdae0b  push r9
000071409bfdae0d  push r10
000071409bfdae0f  push r11
000071409bfdae11  sub rsp, 0xF0
000071409bfdae18  vmovaps [rsp], xmm0
000071409bfdae1d  vmovaps [rsp+0x10], xmm1
000071409bfdae23  vmovaps [rsp+0x20], xmm2
000071409bfdae29  vmovaps [rsp+0x30], xmm3
000071409bfdae2f  vmovaps [rsp+0x40], xmm4
000071409bfdae35  vmovaps [rsp+0x50], xmm5
000071409bfdae3b  vmovaps [rsp+0x60], xmm6
000071409bfdae41  vmovaps [rsp+0x70], xmm7
000071409bfdae47  vmovaps [rsp+0x80], xmm8
000071409bfdae50  vmovaps [rsp+0x90], xmm9
000071409bfdae59  vmovaps [rsp+0xA0], xmm10
000071409bfdae62  vmovaps [rsp+0xB0], xmm11
000071409bfdae6b  vmovaps [rsp+0xC0], xmm12
000071409bfdae74  vmovaps [rsp+0xD0], xmm13
000071409bfdae7d  vmovaps [rsp+0xE0], xmm15
000071409bfdae86  sub rsp, 0x40
000071409bfdae8a  lea rdi, [rsp]
000071409bfdae8e  lea rsi, [rsp+0x10]
000071409bfdae93  lea rdx, [rsp+0x20]
000071409bfdae98  lea rcx, [rsp+0x30]
000071409bfdae9d  mov r8d, 0x00
000071409bfdaea3  lea r9, [r15+0x3A8]
000071409bfdaeaa  movaps [rdi], xmm14
000071409bfdaeae  movaps [rsi], xmm15
000071409bfdaeb2  movaps [rdx], xmm2
000071409bfdaeb5  movaps [rcx], xmm1
000071409bfdaeb8  mov rax, 0x6219BEBC2A50
000071409bfdaec2  call rax
000071409bfdaec4  movaps xmm14, [rsp]
000071409bfdaec9  add rsp, 0x40
000071409bfdaecd  vmovaps xmm0, [rsp]
000071409bfdaed2  vmovaps xmm1, [rsp+0x10]
000071409bfdaed8  vmovaps xmm2, [rsp+0x20]
000071409bfdaede  vmovaps xmm3, [rsp+0x30]
000071409bfdaee4  vmovaps xmm4, [rsp+0x40]
000071409bfdaeea  vmovaps xmm5, [rsp+0x50]
000071409bfdaef0  vmovaps xmm6, [rsp+0x60]
000071409bfdaef6  vmovaps xmm7, [rsp+0x70]
000071409bfdaefc  vmovaps xmm8, [rsp+0x80]
000071409bfdaf05  vmovaps xmm9, [rsp+0x90]
000071409bfdaf0e  vmovaps xmm10, [rsp+0xA0]
000071409bfdaf17  vmovaps xmm11, [rsp+0xB0]
000071409bfdaf20  vmovaps xmm12, [rsp+0xC0]
000071409bfdaf29  vmovaps xmm13, [rsp+0xD0]
000071409bfdaf32  vmovaps xmm15, [rsp+0xE0]
000071409bfdaf3b  add rsp, 0xF0
000071409bfdaf42  pop r11
000071409bfdaf44  pop r10
000071409bfdaf46  pop r9
000071409bfdaf48  pop r8
000071409bfdaf4a  pop rsi
000071409bfdaf4b  pop rdi
000071409bfdaf4c  pop rdx
000071409bfdaf4d  pop rcx
000071409bfdaf4e  pop rax
000071409bfdaf4f  add rsp, 0x08
000071409bfdaf53  jmp 0x000071409BFDA01C
000071409bfdaf58  sub rsp, 0x08
000071409bfdaf5c  push rax
000071409bfdaf5d  push rcx
000071409bfdaf5e  push rdx
000071409bfdaf5f  push rdi
000071409bfdaf60  push rsi
000071409bfdaf61  push r8
000071409bfdaf63  push r9
000071409bfdaf65  push r10
000071409bfdaf67  push r11
000071409bfdaf69  sub rsp, 0xF0
000071409bfdaf70  vmovaps [rsp], xmm0
000071409bfdaf75  vmovaps [rsp+0x10], xmm1
000071409bfdaf7b  vmovaps [rsp+0x20], xmm3
000071409bfdaf81  vmovaps [rsp+0x30], xmm4
000071409bfdaf87  vmovaps [rsp+0x40], xmm5
000071409bfdaf8d  vmovaps [rsp+0x50], xmm6
000071409bfdaf93  vmovaps [rsp+0x60], xmm7
000071409bfdaf99  vmovaps [rsp+0x70], xmm8
000071409bfdaf9f  vmovaps [rsp+0x80], xmm9
000071409bfdafa8  vmovaps [rsp+0x90], xmm10
000071409bfdafb1  vmovaps [rsp+0xA0], xmm11
000071409bfdafba  vmovaps [rsp+0xB0], xmm12
000071409bfdafc3  vmovaps [rsp+0xC0], xmm13
000071409bfdafcc  vmovaps [rsp+0xD0], xmm14
000071409bfdafd5  vmovaps [rsp+0xE0], xmm15
000071409bfdafde  sub rsp, 0x40
000071409bfdafe2  lea rdi, [rsp]
000071409bfdafe6  lea rsi, [rsp+0x10]
000071409bfdafeb  lea rdx, [rsp+0x20]
000071409bfdaff0  lea rcx, [rsp+0x30]
000071409bfdaff5  mov r8d, 0x00
000071409bfdaffb  lea r9, [r15+0x3A8]
000071409bfdb002  movaps [rdi], xmm2
000071409bfdb005  movaps [rsi], xmm15
000071409bfdb009  movaps [rdx], xmm12
000071409bfdb00d  movaps [rcx], xmm1
000071409bfdb010  mov rax, 0x6219BEBC2A50
000071409bfdb01a  call rax
000071409bfdb01c  movaps xmm2, [rsp]
000071409bfdb020  add rsp, 0x40
000071409bfdb024  vmovaps xmm0, [rsp]
000071409bfdb029  vmovaps xmm1, [rsp+0x10]
000071409bfdb02f  vmovaps xmm3, [rsp+0x20]
000071409bfdb035  vmovaps xmm4, [rsp+0x30]
000071409bfdb03b  vmovaps xmm5, [rsp+0x40]
000071409bfdb041  vmovaps xmm6, [rsp+0x50]
000071409bfdb047  vmovaps xmm7, [rsp+0x60]
000071409bfdb04d  vmovaps xmm8, [rsp+0x70]
000071409bfdb053  vmovaps xmm9, [rsp+0x80]
000071409bfdb05c  vmovaps xmm10, [rsp+0x90]
000071409bfdb065  vmovaps xmm11, [rsp+0xA0]
000071409bfdb06e  vmovaps xmm12, [rsp+0xB0]
000071409bfdb077  vmovaps xmm13, [rsp+0xC0]
000071409bfdb080  vmovaps xmm14, [rsp+0xD0]
000071409bfdb089  vmovaps xmm15, [rsp+0xE0]
000071409bfdb092  add rsp, 0xF0
000071409bfdb099  pop r11
000071409bfdb09b  pop r10
000071409bfdb09d  pop r9
000071409bfdb09f  pop r8
000071409bfdb0a1  pop rsi
000071409bfdb0a2  pop rdi
000071409bfdb0a3  pop rdx
000071409bfdb0a4  pop rcx
000071409bfdb0a5  pop rax
000071409bfdb0a6  add rsp, 0x08
000071409bfdb0aa  jmp 0x000071409BFDA059
000071409bfdb0af  sub rsp, 0x08
000071409bfdb0b3  push rax
000071409bfdb0b4  push rcx
000071409bfdb0b5  push rdx
000071409bfdb0b6  push rdi
000071409bfdb0b7  push rsi
000071409bfdb0b8  push r8
000071409bfdb0ba  push r9
000071409bfdb0bc  push r10
000071409bfdb0be  push r11
000071409bfdb0c0  sub rsp, 0xF0
000071409bfdb0c7  vmovaps [rsp], xmm0
000071409bfdb0cc  vmovaps [rsp+0x10], xmm1
000071409bfdb0d2  vmovaps [rsp+0x20], xmm2
000071409bfdb0d8  vmovaps [rsp+0x30], xmm3
000071409bfdb0de  vmovaps [rsp+0x40], xmm4
000071409bfdb0e4  vmovaps [rsp+0x50], xmm5
000071409bfdb0ea  vmovaps [rsp+0x60], xmm6
000071409bfdb0f0  vmovaps [rsp+0x70], xmm7
000071409bfdb0f6  vmovaps [rsp+0x80], xmm8
000071409bfdb0ff  vmovaps [rsp+0x90], xmm9
000071409bfdb108  vmovaps [rsp+0xA0], xmm10
000071409bfdb111  vmovaps [rsp+0xB0], xmm11
000071409bfdb11a  vmovaps [rsp+0xC0], xmm13
000071409bfdb123  vmovaps [rsp+0xD0], xmm14
000071409bfdb12c  vmovaps [rsp+0xE0], xmm15
000071409bfdb135  sub rsp, 0x40
000071409bfdb139  lea rdi, [rsp]
000071409bfdb13d  lea rsi, [rsp+0x10]
000071409bfdb142  lea rdx, [rsp+0x20]
000071409bfdb147  lea rcx, [rsp+0x30]
000071409bfdb14c  mov r8d, 0x00
000071409bfdb152  lea r9, [r15+0x3A8]
000071409bfdb159  movaps [rdi], xmm12
000071409bfdb15d  movaps [rsi], xmm14
000071409bfdb161  movaps [rdx], xmm3
000071409bfdb164  movaps [rcx], xmm15
000071409bfdb168  mov rax, 0x6219BEBC2A50
000071409bfdb172  call rax
000071409bfdb174  movaps xmm12, [rsp]
000071409bfdb179  add rsp, 0x40
000071409bfdb17d  vmovaps xmm0, [rsp]
000071409bfdb182  vmovaps xmm1, [rsp+0x10]
000071409bfdb188  vmovaps xmm2, [rsp+0x20]
000071409bfdb18e  vmovaps xmm3, [rsp+0x30]
000071409bfdb194  vmovaps xmm4, [rsp+0x40]
000071409bfdb19a  vmovaps xmm5, [rsp+0x50]
000071409bfdb1a0  vmovaps xmm6, [rsp+0x60]
000071409bfdb1a6  vmovaps xmm7, [rsp+0x70]
000071409bfdb1ac  vmovaps xmm8, [rsp+0x80]
000071409bfdb1b5  vmovaps xmm9, [rsp+0x90]
000071409bfdb1be  vmovaps xmm10, [rsp+0xA0]
000071409bfdb1c7  vmovaps xmm11, [rsp+0xB0]
000071409bfdb1d0  vmovaps xmm13, [rsp+0xC0]
000071409bfdb1d9  vmovaps xmm14, [rsp+0xD0]
000071409bfdb1e2  vmovaps xmm15, [rsp+0xE0]
000071409bfdb1eb  add rsp, 0xF0
000071409bfdb1f2  pop r11
000071409bfdb1f4  pop r10
000071409bfdb1f6  pop r9
000071409bfdb1f8  pop r8
000071409bfdb1fa  pop rsi
000071409bfdb1fb  pop rdi
000071409bfdb1fc  pop rdx
000071409bfdb1fd  pop rcx
000071409bfdb1fe  pop rax
000071409bfdb1ff  add rsp, 0x08
000071409bfdb203  jmp 0x000071409BFDA0B3
000071409bfdb208  sub rsp, 0x08
000071409bfdb20c  push rax
000071409bfdb20d  push rcx
000071409bfdb20e  push rdx
000071409bfdb20f  push rdi
000071409bfdb210  push rsi
000071409bfdb211  push r8
000071409bfdb213  push r9
000071409bfdb215  push r10
000071409bfdb217  push r11
000071409bfdb219  sub rsp, 0xF0
000071409bfdb220  vmovaps [rsp], xmm0
000071409bfdb225  vmovaps [rsp+0x10], xmm1
000071409bfdb22b  vmovaps [rsp+0x20], xmm2
000071409bfdb231  vmovaps [rsp+0x30], xmm3
000071409bfdb237  vmovaps [rsp+0x40], xmm4
000071409bfdb23d  vmovaps [rsp+0x50], xmm5
000071409bfdb243  vmovaps [rsp+0x60], xmm6
000071409bfdb249  vmovaps [rsp+0x70], xmm7
000071409bfdb24f  vmovaps [rsp+0x80], xmm8
000071409bfdb258  vmovaps [rsp+0x90], xmm10
000071409bfdb261  vmovaps [rsp+0xA0], xmm11
000071409bfdb26a  vmovaps [rsp+0xB0], xmm12
000071409bfdb273  vmovaps [rsp+0xC0], xmm13
000071409bfdb27c  vmovaps [rsp+0xD0], xmm14
000071409bfdb285  vmovaps [rsp+0xE0], xmm15
000071409bfdb28e  sub rsp, 0x40
000071409bfdb292  lea rdi, [rsp]
000071409bfdb296  lea rsi, [rsp+0x10]
000071409bfdb29b  lea rdx, [rsp+0x20]
000071409bfdb2a0  lea rcx, [rsp+0x30]
000071409bfdb2a5  mov r8d, 0x00
000071409bfdb2ab  lea r9, [r15+0x3A8]
000071409bfdb2b2  movaps [rdi], xmm9
000071409bfdb2b6  movaps [rsi], xmm13
000071409bfdb2ba  movaps [rdx], xmm14
000071409bfdb2be  movaps [rcx], xmm6
000071409bfdb2c1  mov rax, 0x6219BEBC2A50
000071409bfdb2cb  call rax
000071409bfdb2cd  movaps xmm9, [rsp]
000071409bfdb2d2  add rsp, 0x40
000071409bfdb2d6  vmovaps xmm0, [rsp]
000071409bfdb2db  vmovaps xmm1, [rsp+0x10]
000071409bfdb2e1  vmovaps xmm2, [rsp+0x20]
000071409bfdb2e7  vmovaps xmm3, [rsp+0x30]
000071409bfdb2ed  vmovaps xmm4, [rsp+0x40]
000071409bfdb2f3  vmovaps xmm5, [rsp+0x50]
000071409bfdb2f9  vmovaps xmm6, [rsp+0x60]
000071409bfdb2ff  vmovaps xmm7, [rsp+0x70]
000071409bfdb305  vmovaps xmm8, [rsp+0x80]
000071409bfdb30e  vmovaps xmm10, [rsp+0x90]
000071409bfdb317  vmovaps xmm11, [rsp+0xA0]
000071409bfdb320  vmovaps xmm12, [rsp+0xB0]
000071409bfdb329  vmovaps xmm13, [rsp+0xC0]
000071409bfdb332  vmovaps xmm14, [rsp+0xD0]
000071409bfdb33b  vmovaps xmm15, [rsp+0xE0]
000071409bfdb344  add rsp, 0xF0
000071409bfdb34b  pop r11
000071409bfdb34d  pop r10
000071409bfdb34f  pop r9
000071409bfdb351  pop r8
000071409bfdb353  pop rsi
000071409bfdb354  pop rdi
000071409bfdb355  pop rdx
000071409bfdb356  pop rcx
000071409bfdb357  pop rax
000071409bfdb358  add rsp, 0x08
000071409bfdb35c  jmp 0x000071409BFDA15D
000071409bfdb361  sub rsp, 0x08
000071409bfdb365  push rax
000071409bfdb366  push rcx
000071409bfdb367  push rdx
000071409bfdb368  push rdi
000071409bfdb369  push rsi
000071409bfdb36a  push r8
000071409bfdb36c  push r9
000071409bfdb36e  push r10
000071409bfdb370  push r11
000071409bfdb372  sub rsp, 0xF0
000071409bfdb379  vmovaps [rsp], xmm0
000071409bfdb37e  vmovaps [rsp+0x10], xmm1
000071409bfdb384  vmovaps [rsp+0x20], xmm2
000071409bfdb38a  vmovaps [rsp+0x30], xmm4
000071409bfdb390  vmovaps [rsp+0x40], xmm5
000071409bfdb396  vmovaps [rsp+0x50], xmm6
000071409bfdb39c  vmovaps [rsp+0x60], xmm7
000071409bfdb3a2  vmovaps [rsp+0x70], xmm8
000071409bfdb3a8  vmovaps [rsp+0x80], xmm9
000071409bfdb3b1  vmovaps [rsp+0x90], xmm10
000071409bfdb3ba  vmovaps [rsp+0xA0], xmm11
000071409bfdb3c3  vmovaps [rsp+0xB0], xmm12
000071409bfdb3cc  vmovaps [rsp+0xC0], xmm13
000071409bfdb3d5  vmovaps [rsp+0xD0], xmm14
000071409bfdb3de  vmovaps [rsp+0xE0], xmm15
000071409bfdb3e7  sub rsp, 0x40
000071409bfdb3eb  lea rdi, [rsp]
000071409bfdb3ef  lea rsi, [rsp+0x10]
000071409bfdb3f4  lea rdx, [rsp+0x20]
000071409bfdb3f9  lea rcx, [rsp+0x30]
000071409bfdb3fe  mov r8d, 0x00
000071409bfdb404  lea r9, [r15+0x3A8]
000071409bfdb40b  movaps [rdi], xmm3
000071409bfdb40e  movaps [rsi], xmm13
000071409bfdb412  movaps [rdx], xmm6
000071409bfdb415  movaps [rcx], xmm14
000071409bfdb419  mov rax, 0x6219BEBC2A50
000071409bfdb423  call rax
000071409bfdb425  movaps xmm3, [rsp]
000071409bfdb429  add rsp, 0x40
000071409bfdb42d  vmovaps xmm0, [rsp]
000071409bfdb432  vmovaps xmm1, [rsp+0x10]
000071409bfdb438  vmovaps xmm2, [rsp+0x20]
000071409bfdb43e  vmovaps xmm4, [rsp+0x30]
000071409bfdb444  vmovaps xmm5, [rsp+0x40]
000071409bfdb44a  vmovaps xmm6, [rsp+0x50]
000071409bfdb450  vmovaps xmm7, [rsp+0x60]
000071409bfdb456  vmovaps xmm8, [rsp+0x70]
000071409bfdb45c  vmovaps xmm9, [rsp+0x80]
000071409bfdb465  vmovaps xmm10, [rsp+0x90]
000071409bfdb46e  vmovaps xmm11, [rsp+0xA0]
000071409bfdb477  vmovaps xmm12, [rsp+0xB0]
000071409bfdb480  vmovaps xmm13, [rsp+0xC0]
000071409bfdb489  vmovaps xmm14, [rsp+0xD0]
000071409bfdb492  vmovaps xmm15, [rsp+0xE0]
000071409bfdb49b  add rsp, 0xF0
000071409bfdb4a2  pop r11
000071409bfdb4a4  pop r10
000071409bfdb4a6  pop r9
000071409bfdb4a8  pop r8
000071409bfdb4aa  pop rsi
000071409bfdb4ab  pop rdi
000071409bfdb4ac  pop rdx
000071409bfdb4ad  pop rcx
000071409bfdb4ae  pop rax
000071409bfdb4af  add rsp, 0x08
000071409bfdb4b3  jmp 0x000071409BFDA19A
000071409bfdb4b8  sub rsp, 0x08
000071409bfdb4bc  push rax
000071409bfdb4bd  push rcx
000071409bfdb4be  push rdx
000071409bfdb4bf  push rdi
000071409bfdb4c0  push rsi
000071409bfdb4c1  push r8
000071409bfdb4c3  push r9
000071409bfdb4c5  push r10
000071409bfdb4c7  push r11
000071409bfdb4c9  sub rsp, 0xF0
000071409bfdb4d0  vmovaps [rsp], xmm0
000071409bfdb4d5  vmovaps [rsp+0x10], xmm1
000071409bfdb4db  vmovaps [rsp+0x20], xmm2
000071409bfdb4e1  vmovaps [rsp+0x30], xmm3
000071409bfdb4e7  vmovaps [rsp+0x40], xmm4
000071409bfdb4ed  vmovaps [rsp+0x50], xmm5
000071409bfdb4f3  vmovaps [rsp+0x60], xmm7
000071409bfdb4f9  vmovaps [rsp+0x70], xmm8
000071409bfdb4ff  vmovaps [rsp+0x80], xmm9
000071409bfdb508  vmovaps [rsp+0x90], xmm10
000071409bfdb511  vmovaps [rsp+0xA0], xmm11
000071409bfdb51a  vmovaps [rsp+0xB0], xmm12
000071409bfdb523  vmovaps [rsp+0xC0], xmm13
000071409bfdb52c  vmovaps [rsp+0xD0], xmm14
000071409bfdb535  vmovaps [rsp+0xE0], xmm15
000071409bfdb53e  sub rsp, 0x40
000071409bfdb542  lea rdi, [rsp]
000071409bfdb546  lea rsi, [rsp+0x10]
000071409bfdb54b  lea rdx, [rsp+0x20]
000071409bfdb550  lea rcx, [rsp+0x30]
000071409bfdb555  mov r8d, 0x00
000071409bfdb55b  lea r9, [r15+0x3A8]
000071409bfdb562  movaps [rdi], xmm6
000071409bfdb565  movaps [rsi], xmm2
000071409bfdb568  movaps [rdx], xmm14
000071409bfdb56c  movaps [rcx], xmm1
000071409bfdb56f  mov rax, 0x6219BEBC2A50
000071409bfdb579  call rax
000071409bfdb57b  movaps xmm6, [rsp]
000071409bfdb57f  add rsp, 0x40
000071409bfdb583  vmovaps xmm0, [rsp]
000071409bfdb588  vmovaps xmm1, [rsp+0x10]
000071409bfdb58e  vmovaps xmm2, [rsp+0x20]
000071409bfdb594  vmovaps xmm3, [rsp+0x30]
000071409bfdb59a  vmovaps xmm4, [rsp+0x40]
000071409bfdb5a0  vmovaps xmm5, [rsp+0x50]
000071409bfdb5a6  vmovaps xmm7, [rsp+0x60]
000071409bfdb5ac  vmovaps xmm8, [rsp+0x70]
000071409bfdb5b2  vmovaps xmm9, [rsp+0x80]
000071409bfdb5bb  vmovaps xmm10, [rsp+0x90]
000071409bfdb5c4  vmovaps xmm11, [rsp+0xA0]
000071409bfdb5cd  vmovaps xmm12, [rsp+0xB0]
000071409bfdb5d6  vmovaps xmm13, [rsp+0xC0]
000071409bfdb5df  vmovaps xmm14, [rsp+0xD0]
000071409bfdb5e8  vmovaps xmm15, [rsp+0xE0]
000071409bfdb5f1  add rsp, 0xF0
000071409bfdb5f8  pop r11
000071409bfdb5fa  pop r10
000071409bfdb5fc  pop r9
000071409bfdb5fe  pop r8
000071409bfdb600  pop rsi
000071409bfdb601  pop rdi
000071409bfdb602  pop rdx
000071409bfdb603  pop rcx
000071409bfdb604  pop rax
000071409bfdb605  add rsp, 0x08
000071409bfdb609  jmp 0x000071409BFDA1C7
000071409bfdb60e  sub rsp, 0x08
000071409bfdb612  push rax
000071409bfdb613  push rcx
000071409bfdb614  push rdx
000071409bfdb615  push rdi
000071409bfdb616  push rsi
000071409bfdb617  push r8
000071409bfdb619  push r9
000071409bfdb61b  push r10
000071409bfdb61d  push r11
000071409bfdb61f  sub rsp, 0xF0
000071409bfdb626  vmovaps [rsp], xmm0
000071409bfdb62b  vmovaps [rsp+0x10], xmm1
000071409bfdb631  vmovaps [rsp+0x20], xmm2
000071409bfdb637  vmovaps [rsp+0x30], xmm3
000071409bfdb63d  vmovaps [rsp+0x40], xmm4
000071409bfdb643  vmovaps [rsp+0x50], xmm5
000071409bfdb649  vmovaps [rsp+0x60], xmm6
000071409bfdb64f  vmovaps [rsp+0x70], xmm7
000071409bfdb655  vmovaps [rsp+0x80], xmm8
000071409bfdb65e  vmovaps [rsp+0x90], xmm9
000071409bfdb667  vmovaps [rsp+0xA0], xmm10
000071409bfdb670  vmovaps [rsp+0xB0], xmm11
000071409bfdb679  vmovaps [rsp+0xC0], xmm12
000071409bfdb682  vmovaps [rsp+0xD0], xmm14
000071409bfdb68b  vmovaps [rsp+0xE0], xmm15
000071409bfdb694  sub rsp, 0x40
000071409bfdb698  lea rdi, [rsp]
000071409bfdb69c  lea rsi, [rsp+0x10]
000071409bfdb6a1  lea rdx, [rsp+0x20]
000071409bfdb6a6  lea rcx, [rsp+0x30]
000071409bfdb6ab  mov r8d, 0x00
000071409bfdb6b1  lea r9, [r15+0x3A8]
000071409bfdb6b8  movaps [rdi], xmm13
000071409bfdb6bc  movaps [rsi], xmm12
000071409bfdb6c0  movaps [rdx], xmm14
000071409bfdb6c4  movaps [rcx], xmm1
000071409bfdb6c7  mov rax, 0x6219BEBC2A50
000071409bfdb6d1  call rax
000071409bfdb6d3  movaps xmm13, [rsp]
000071409bfdb6d8  add rsp, 0x40
000071409bfdb6dc  vmovaps xmm0, [rsp]
000071409bfdb6e1  vmovaps xmm1, [rsp+0x10]
000071409bfdb6e7  vmovaps xmm2, [rsp+0x20]
000071409bfdb6ed  vmovaps xmm3, [rsp+0x30]
000071409bfdb6f3  vmovaps xmm4, [rsp+0x40]
000071409bfdb6f9  vmovaps xmm5, [rsp+0x50]
000071409bfdb6ff  vmovaps xmm6, [rsp+0x60]
000071409bfdb705  vmovaps xmm7, [rsp+0x70]
000071409bfdb70b  vmovaps xmm8, [rsp+0x80]
000071409bfdb714  vmovaps xmm9, [rsp+0x90]
000071409bfdb71d  vmovaps xmm10, [rsp+0xA0]
000071409bfdb726  vmovaps xmm11, [rsp+0xB0]
000071409bfdb72f  vmovaps xmm12, [rsp+0xC0]
000071409bfdb738  vmovaps xmm14, [rsp+0xD0]
000071409bfdb741  vmovaps xmm15, [rsp+0xE0]
000071409bfdb74a  add rsp, 0xF0
000071409bfdb751  pop r11
000071409bfdb753  pop r10
000071409bfdb755  pop r9
000071409bfdb757  pop r8
000071409bfdb759  pop rsi
000071409bfdb75a  pop rdi
000071409bfdb75b  pop rdx
000071409bfdb75c  pop rcx
000071409bfdb75d  pop rax
000071409bfdb75e  add rsp, 0x08
000071409bfdb762  jmp 0x000071409BFDA1F9
000071409bfdb767  sub rsp, 0x08
000071409bfdb76b  push rax
000071409bfdb76c  push rcx
000071409bfdb76d  push rdx
000071409bfdb76e  push rdi
000071409bfdb76f  push rsi
000071409bfdb770  push r8
000071409bfdb772  push r9
000071409bfdb774  push r10
000071409bfdb776  push r11
000071409bfdb778  sub rsp, 0xF0
000071409bfdb77f  vmovaps [rsp], xmm0
000071409bfdb784  vmovaps [rsp+0x10], xmm1
000071409bfdb78a  vmovaps [rsp+0x20], xmm2
000071409bfdb790  vmovaps [rsp+0x30], xmm3
000071409bfdb796  vmovaps [rsp+0x40], xmm4
000071409bfdb79c  vmovaps [rsp+0x50], xmm5
000071409bfdb7a2  vmovaps [rsp+0x60], xmm6
000071409bfdb7a8  vmovaps [rsp+0x70], xmm7
000071409bfdb7ae  vmovaps [rsp+0x80], xmm8
000071409bfdb7b7  vmovaps [rsp+0x90], xmm9
000071409bfdb7c0  vmovaps [rsp+0xA0], xmm10
000071409bfdb7c9  vmovaps [rsp+0xB0], xmm11
000071409bfdb7d2  vmovaps [rsp+0xC0], xmm13
000071409bfdb7db  vmovaps [rsp+0xD0], xmm14
000071409bfdb7e4  vmovaps [rsp+0xE0], xmm15
000071409bfdb7ed  sub rsp, 0x40
000071409bfdb7f1  lea rdi, [rsp]
000071409bfdb7f5  lea rsi, [rsp+0x10]
000071409bfdb7fa  lea rdx, [rsp+0x20]
000071409bfdb7ff  lea rcx, [rsp+0x30]
000071409bfdb804  mov r8d, 0x00
000071409bfdb80a  lea r9, [r15+0x3A8]
000071409bfdb811  movaps [rdi], xmm12
000071409bfdb815  movaps [rsi], xmm3
000071409bfdb818  movaps [rdx], xmm14
000071409bfdb81c  movaps [rcx], xmm5
000071409bfdb81f  mov rax, 0x6219BEBC2A50
000071409bfdb829  call rax
000071409bfdb82b  movaps xmm12, [rsp]
000071409bfdb830  add rsp, 0x40
000071409bfdb834  vmovaps xmm0, [rsp]
000071409bfdb839  vmovaps xmm1, [rsp+0x10]
000071409bfdb83f  vmovaps xmm2, [rsp+0x20]
000071409bfdb845  vmovaps xmm3, [rsp+0x30]
000071409bfdb84b  vmovaps xmm4, [rsp+0x40]
000071409bfdb851  vmovaps xmm5, [rsp+0x50]
000071409bfdb857  vmovaps xmm6, [rsp+0x60]
000071409bfdb85d  vmovaps xmm7, [rsp+0x70]
000071409bfdb863  vmovaps xmm8, [rsp+0x80]
000071409bfdb86c  vmovaps xmm9, [rsp+0x90]
000071409bfdb875  vmovaps xmm10, [rsp+0xA0]
000071409bfdb87e  vmovaps xmm11, [rsp+0xB0]
000071409bfdb887  vmovaps xmm13, [rsp+0xC0]
000071409bfdb890  vmovaps xmm14, [rsp+0xD0]
000071409bfdb899  vmovaps xmm15, [rsp+0xE0]
000071409bfdb8a2  add rsp, 0xF0
000071409bfdb8a9  pop r11
000071409bfdb8ab  pop r10
000071409bfdb8ad  pop r9
000071409bfdb8af  pop r8
000071409bfdb8b1  pop rsi
000071409bfdb8b2  pop rdi
000071409bfdb8b3  pop rdx
000071409bfdb8b4  pop rcx
000071409bfdb8b5  pop rax
000071409bfdb8b6  add rsp, 0x08
000071409bfdb8ba  jmp 0x000071409BFDA256
000071409bfdb8bf  sub rsp, 0x08
000071409bfdb8c3  push rax
000071409bfdb8c4  push rcx
000071409bfdb8c5  push rdx
000071409bfdb8c6  push rdi
000071409bfdb8c7  push rsi
000071409bfdb8c8  push r8
000071409bfdb8ca  push r9
000071409bfdb8cc  push r10
000071409bfdb8ce  push r11
000071409bfdb8d0  sub rsp, 0xF0
000071409bfdb8d7  vmovaps [rsp], xmm0
000071409bfdb8dc  vmovaps [rsp+0x10], xmm1
000071409bfdb8e2  vmovaps [rsp+0x20], xmm2
000071409bfdb8e8  vmovaps [rsp+0x30], xmm3
000071409bfdb8ee  vmovaps [rsp+0x40], xmm4
000071409bfdb8f4  vmovaps [rsp+0x50], xmm5
000071409bfdb8fa  vmovaps [rsp+0x60], xmm6
000071409bfdb900  vmovaps [rsp+0x70], xmm7
000071409bfdb906  vmovaps [rsp+0x80], xmm8
000071409bfdb90f  vmovaps [rsp+0x90], xmm9
000071409bfdb918  vmovaps [rsp+0xA0], xmm11
000071409bfdb921  vmovaps [rsp+0xB0], xmm12
000071409bfdb92a  vmovaps [rsp+0xC0], xmm13
000071409bfdb933  vmovaps [rsp+0xD0], xmm14
000071409bfdb93c  vmovaps [rsp+0xE0], xmm15
000071409bfdb945  sub rsp, 0x40
000071409bfdb949  lea rdi, [rsp]
000071409bfdb94d  lea rsi, [rsp+0x10]
000071409bfdb952  lea rdx, [rsp+0x20]
000071409bfdb957  lea rcx, [rsp+0x30]
000071409bfdb95c  mov r8d, 0x00
000071409bfdb962  lea r9, [r15+0x3A8]
000071409bfdb969  movaps [rdi], xmm10
000071409bfdb96d  movaps [rsi], xmm9
000071409bfdb971  movaps [rdx], xmm7
000071409bfdb974  movaps [rcx], xmm14
000071409bfdb978  mov rax, 0x6219BEBC2A50
000071409bfdb982  call rax
000071409bfdb984  movaps xmm10, [rsp]
000071409bfdb989  add rsp, 0x40
000071409bfdb98d  vmovaps xmm0, [rsp]
000071409bfdb992  vmovaps xmm1, [rsp+0x10]
000071409bfdb998  vmovaps xmm2, [rsp+0x20]
000071409bfdb99e  vmovaps xmm3, [rsp+0x30]
000071409bfdb9a4  vmovaps xmm4, [rsp+0x40]
000071409bfdb9aa  vmovaps xmm5, [rsp+0x50]
000071409bfdb9b0  vmovaps xmm6, [rsp+0x60]
000071409bfdb9b6  vmovaps xmm7, [rsp+0x70]
000071409bfdb9bc  vmovaps xmm8, [rsp+0x80]
000071409bfdb9c5  vmovaps xmm9, [rsp+0x90]
000071409bfdb9ce  vmovaps xmm11, [rsp+0xA0]
000071409bfdb9d7  vmovaps xmm12, [rsp+0xB0]
000071409bfdb9e0  vmovaps xmm13, [rsp+0xC0]
000071409bfdb9e9  vmovaps xmm14, [rsp+0xD0]
000071409bfdb9f2  vmovaps xmm15, [rsp+0xE0]
000071409bfdb9fb  add rsp, 0xF0
000071409bfdba02  pop r11
000071409bfdba04  pop r10
000071409bfdba06  pop r9
000071409bfdba08  pop r8
000071409bfdba0a  pop rsi
000071409bfdba0b  pop rdi
000071409bfdba0c  pop rdx
000071409bfdba0d  pop rcx
000071409bfdba0e  pop rax
000071409bfdba0f  add rsp, 0x08
000071409bfdba13  jmp 0x000071409BFDA27C
000071409bfdba18  call 0x000071409BE0D4E0
000071409bfdba1d  jmp 0x000071409BFDA289
000071409bfdba22  sub rsp, 0x08
000071409bfdba26  push rax
000071409bfdba27  push rcx
000071409bfdba28  push rdx
000071409bfdba29  push rdi
000071409bfdba2a  push rsi
000071409bfdba2b  push r8
000071409bfdba2d  push r9
000071409bfdba2f  push r10
000071409bfdba31  push r11
000071409bfdba33  sub rsp, 0xF0
000071409bfdba3a  vmovaps [rsp], xmm0
000071409bfdba3f  vmovaps [rsp+0x10], xmm1
000071409bfdba45  vmovaps [rsp+0x20], xmm2
000071409bfdba4b  vmovaps [rsp+0x30], xmm3
000071409bfdba51  vmovaps [rsp+0x40], xmm4
000071409bfdba57  vmovaps [rsp+0x50], xmm6
000071409bfdba5d  vmovaps [rsp+0x60], xmm7
000071409bfdba63  vmovaps [rsp+0x70], xmm8
000071409bfdba69  vmovaps [rsp+0x80], xmm9
000071409bfdba72  vmovaps [rsp+0x90], xmm10
000071409bfdba7b  vmovaps [rsp+0xA0], xmm11
000071409bfdba84  vmovaps [rsp+0xB0], xmm12
000071409bfdba8d  vmovaps [rsp+0xC0], xmm13
000071409bfdba96  vmovaps [rsp+0xD0], xmm14
000071409bfdba9f  vmovaps [rsp+0xE0], xmm15
000071409bfdbaa8  sub rsp, 0x40
000071409bfdbaac  lea rdi, [rsp]
000071409bfdbab0  lea rsi, [rsp+0x10]
000071409bfdbab5  lea rdx, [rsp+0x20]
000071409bfdbaba  lea rcx, [rsp+0x30]
000071409bfdbabf  mov r8d, 0x00
000071409bfdbac5  lea r9, [r15+0x3A8]
000071409bfdbacc  movaps [rdi], xmm5
000071409bfdbacf  movaps [rsi], xmm6
000071409bfdbad2  movaps [rdx], xmm7
000071409bfdbad5  movaps [rcx], xmm9
000071409bfdbad9  mov rax, 0x6219BEBC2A50
000071409bfdbae3  call rax
000071409bfdbae5  movaps xmm5, [rsp]
000071409bfdbae9  add rsp, 0x40
000071409bfdbaed  vmovaps xmm0, [rsp]
000071409bfdbaf2  vmovaps xmm1, [rsp+0x10]
000071409bfdbaf8  vmovaps xmm2, [rsp+0x20]
000071409bfdbafe  vmovaps xmm3, [rsp+0x30]
000071409bfdbb04  vmovaps xmm4, [rsp+0x40]
000071409bfdbb0a  vmovaps xmm6, [rsp+0x50]
000071409bfdbb10  vmovaps xmm7, [rsp+0x60]
000071409bfdbb16  vmovaps xmm8, [rsp+0x70]
000071409bfdbb1c  vmovaps xmm9, [rsp+0x80]
000071409bfdbb25  vmovaps xmm10, [rsp+0x90]
000071409bfdbb2e  vmovaps xmm11, [rsp+0xA0]
000071409bfdbb37  vmovaps xmm12, [rsp+0xB0]
000071409bfdbb40  vmovaps xmm13, [rsp+0xC0]
000071409bfdbb49  vmovaps xmm14, [rsp+0xD0]
000071409bfdbb52  vmovaps xmm15, [rsp+0xE0]
000071409bfdbb5b  add rsp, 0xF0
000071409bfdbb62  pop r11
000071409bfdbb64  pop r10
000071409bfdbb66  pop r9
000071409bfdbb68  pop r8
000071409bfdbb6a  pop rsi
000071409bfdbb6b  pop rdi
000071409bfdbb6c  pop rdx
000071409bfdbb6d  pop rcx
000071409bfdbb6e  pop rax
000071409bfdbb6f  add rsp, 0x08
000071409bfdbb73  jmp 0x000071409BFDA2BB
000071409bfdbb78  sub rsp, 0x08
000071409bfdbb7c  push rax
000071409bfdbb7d  push rcx
000071409bfdbb7e  push rdx
000071409bfdbb7f  push rdi
000071409bfdbb80  push rsi
000071409bfdbb81  push r8
000071409bfdbb83  push r9
000071409bfdbb85  push r10
000071409bfdbb87  push r11
000071409bfdbb89  sub rsp, 0xF0
000071409bfdbb90  vmovaps [rsp], xmm0
000071409bfdbb95  vmovaps [rsp+0x10], xmm1
000071409bfdbb9b  vmovaps [rsp+0x20], xmm2
000071409bfdbba1  vmovaps [rsp+0x30], xmm3
000071409bfdbba7  vmovaps [rsp+0x40], xmm4
000071409bfdbbad  vmovaps [rsp+0x50], xmm5
000071409bfdbbb3  vmovaps [rsp+0x60], xmm6
000071409bfdbbb9  vmovaps [rsp+0x70], xmm8
000071409bfdbbbf  vmovaps [rsp+0x80], xmm9
000071409bfdbbc8  vmovaps [rsp+0x90], xmm10
000071409bfdbbd1  vmovaps [rsp+0xA0], xmm11
000071409bfdbbda  vmovaps [rsp+0xB0], xmm12
000071409bfdbbe3  vmovaps [rsp+0xC0], xmm13
000071409bfdbbec  vmovaps [rsp+0xD0], xmm14
000071409bfdbbf5  vmovaps [rsp+0xE0], xmm15
000071409bfdbbfe  sub rsp, 0x40
000071409bfdbc02  lea rdi, [rsp]
000071409bfdbc06  lea rsi, [rsp+0x10]
000071409bfdbc0b  lea rdx, [rsp+0x20]
000071409bfdbc10  lea rcx, [rsp+0x30]
000071409bfdbc15  mov r8d, 0x00
000071409bfdbc1b  lea r9, [r15+0x3A8]
000071409bfdbc22  movaps [rdi], xmm7
000071409bfdbc25  movaps [rsi], xmm13
000071409bfdbc29  movaps [rdx], xmm1
000071409bfdbc2c  movaps [rcx], xmm9
000071409bfdbc30  mov rax, 0x6219BEBC2A50
000071409bfdbc3a  call rax
000071409bfdbc3c  movaps xmm7, [rsp]
000071409bfdbc40  add rsp, 0x40
000071409bfdbc44  vmovaps xmm0, [rsp]
000071409bfdbc49  vmovaps xmm1, [rsp+0x10]
000071409bfdbc4f  vmovaps xmm2, [rsp+0x20]
000071409bfdbc55  vmovaps xmm3, [rsp+0x30]
000071409bfdbc5b  vmovaps xmm4, [rsp+0x40]
000071409bfdbc61  vmovaps xmm5, [rsp+0x50]
000071409bfdbc67  vmovaps xmm6, [rsp+0x60]
000071409bfdbc6d  vmovaps xmm8, [rsp+0x70]
000071409bfdbc73  vmovaps xmm9, [rsp+0x80]
000071409bfdbc7c  vmovaps xmm10, [rsp+0x90]
000071409bfdbc85  vmovaps xmm11, [rsp+0xA0]
000071409bfdbc8e  vmovaps xmm12, [rsp+0xB0]
000071409bfdbc97  vmovaps xmm13, [rsp+0xC0]
000071409bfdbca0  vmovaps xmm14, [rsp+0xD0]
000071409bfdbca9  vmovaps xmm15, [rsp+0xE0]
000071409bfdbcb2  add rsp, 0xF0
000071409bfdbcb9  pop r11
000071409bfdbcbb  pop r10
000071409bfdbcbd  pop r9
000071409bfdbcbf  pop r8
000071409bfdbcc1  pop rsi
000071409bfdbcc2  pop rdi
000071409bfdbcc3  pop rdx
000071409bfdbcc4  pop rcx
000071409bfdbcc5  pop rax
000071409bfdbcc6  add rsp, 0x08
000071409bfdbcca  jmp 0x000071409BFDA2E0
000071409bfdbccf  call 0x000071409BE0C260
000071409bfdbcd4  jmp 0x000071409BFDA303
000071409bfdbcd9  call 0x000071409BE07890
000071409bfdbcde  jmp 0x000071409BFDA30D
000071409bfdbce3  sub rsp, 0x08
000071409bfdbce7  push rax
000071409bfdbce8  push rcx
000071409bfdbce9  push rdx
000071409bfdbcea  push rdi
000071409bfdbceb  push rsi
000071409bfdbcec  push r8
000071409bfdbcee  push r9
000071409bfdbcf0  push r10
000071409bfdbcf2  push r11
000071409bfdbcf4  sub rsp, 0xF0
000071409bfdbcfb  vmovaps [rsp], xmm0
000071409bfdbd00  vmovaps [rsp+0x10], xmm1
000071409bfdbd06  vmovaps [rsp+0x20], xmm3
000071409bfdbd0c  vmovaps [rsp+0x30], xmm4
000071409bfdbd12  vmovaps [rsp+0x40], xmm5
000071409bfdbd18  vmovaps [rsp+0x50], xmm6
000071409bfdbd1e  vmovaps [rsp+0x60], xmm7
000071409bfdbd24  vmovaps [rsp+0x70], xmm8
000071409bfdbd2a  vmovaps [rsp+0x80], xmm9
000071409bfdbd33  vmovaps [rsp+0x90], xmm10
000071409bfdbd3c  vmovaps [rsp+0xA0], xmm11
000071409bfdbd45  vmovaps [rsp+0xB0], xmm12
000071409bfdbd4e  vmovaps [rsp+0xC0], xmm13
000071409bfdbd57  vmovaps [rsp+0xD0], xmm14
000071409bfdbd60  vmovaps [rsp+0xE0], xmm15
000071409bfdbd69  sub rsp, 0x40
000071409bfdbd6d  lea rdi, [rsp]
000071409bfdbd71  lea rsi, [rsp+0x10]
000071409bfdbd76  lea rdx, [rsp+0x20]
000071409bfdbd7b  lea rcx, [rsp+0x30]
000071409bfdbd80  mov r8d, 0x00
000071409bfdbd86  lea r9, [r15+0x3A8]
000071409bfdbd8d  movaps [rdi], xmm2
000071409bfdbd90  movaps [rsi], xmm12
000071409bfdbd94  movaps [rdx], xmm6
000071409bfdbd97  movaps [rcx], xmm3
000071409bfdbd9a  mov rax, 0x6219BEBC2A50
000071409bfdbda4  call rax
000071409bfdbda6  movaps xmm2, [rsp]
000071409bfdbdaa  add rsp, 0x40
000071409bfdbdae  vmovaps xmm0, [rsp]
000071409bfdbdb3  vmovaps xmm1, [rsp+0x10]
000071409bfdbdb9  vmovaps xmm3, [rsp+0x20]
000071409bfdbdbf  vmovaps xmm4, [rsp+0x30]
000071409bfdbdc5  vmovaps xmm5, [rsp+0x40]
000071409bfdbdcb  vmovaps xmm6, [rsp+0x50]
000071409bfdbdd1  vmovaps xmm7, [rsp+0x60]
000071409bfdbdd7  vmovaps xmm8, [rsp+0x70]
000071409bfdbddd  vmovaps xmm9, [rsp+0x80]
000071409bfdbde6  vmovaps xmm10, [rsp+0x90]
000071409bfdbdef  vmovaps xmm11, [rsp+0xA0]
000071409bfdbdf8  vmovaps xmm12, [rsp+0xB0]
000071409bfdbe01  vmovaps xmm13, [rsp+0xC0]
000071409bfdbe0a  vmovaps xmm14, [rsp+0xD0]
000071409bfdbe13  vmovaps xmm15, [rsp+0xE0]
000071409bfdbe1c  add rsp, 0xF0
000071409bfdbe23  pop r11
000071409bfdbe25  pop r10
000071409bfdbe27  pop r9
000071409bfdbe29  pop r8
000071409bfdbe2b  pop rsi
000071409bfdbe2c  pop rdi
000071409bfdbe2d  pop rdx
000071409bfdbe2e  pop rcx
000071409bfdbe2f  pop rax
000071409bfdbe30  add rsp, 0x08
000071409bfdbe34  jmp 0x000071409BFDA353
000071409bfdbe39  sub rsp, 0x08
000071409bfdbe3d  push rax
000071409bfdbe3e  push rcx
000071409bfdbe3f  push rdx
000071409bfdbe40  push rdi
000071409bfdbe41  push rsi
000071409bfdbe42  push r8
000071409bfdbe44  push r9
000071409bfdbe46  push r10
000071409bfdbe48  push r11
000071409bfdbe4a  sub rsp, 0xF0
000071409bfdbe51  vmovaps [rsp], xmm0
000071409bfdbe56  vmovaps [rsp+0x10], xmm1
000071409bfdbe5c  vmovaps [rsp+0x20], xmm2
000071409bfdbe62  vmovaps [rsp+0x30], xmm3
000071409bfdbe68  vmovaps [rsp+0x40], xmm4
000071409bfdbe6e  vmovaps [rsp+0x50], xmm5
000071409bfdbe74  vmovaps [rsp+0x60], xmm7
000071409bfdbe7a  vmovaps [rsp+0x70], xmm8
000071409bfdbe80  vmovaps [rsp+0x80], xmm9
000071409bfdbe89  vmovaps [rsp+0x90], xmm10
000071409bfdbe92  vmovaps [rsp+0xA0], xmm11
000071409bfdbe9b  vmovaps [rsp+0xB0], xmm12
000071409bfdbea4  vmovaps [rsp+0xC0], xmm13
000071409bfdbead  vmovaps [rsp+0xD0], xmm14
000071409bfdbeb6  vmovaps [rsp+0xE0], xmm15
000071409bfdbebf  sub rsp, 0x40
000071409bfdbec3  lea rdi, [rsp]
000071409bfdbec7  lea rsi, [rsp+0x10]
000071409bfdbecc  lea rdx, [rsp+0x20]
000071409bfdbed1  lea rcx, [rsp+0x30]
000071409bfdbed6  mov r8d, 0x00
000071409bfdbedc  lea r9, [r15+0x3A8]
000071409bfdbee3  movaps [rdi], xmm6
000071409bfdbee6  movaps [rsi], xmm10
000071409bfdbeea  movaps [rdx], xmm12
000071409bfdbeee  movaps [rcx], xmm1
000071409bfdbef1  mov rax, 0x6219BEBC2A50
000071409bfdbefb  call rax
000071409bfdbefd  movaps xmm6, [rsp]
000071409bfdbf01  add rsp, 0x40
000071409bfdbf05  vmovaps xmm0, [rsp]
000071409bfdbf0a  vmovaps xmm1, [rsp+0x10]
000071409bfdbf10  vmovaps xmm2, [rsp+0x20]
000071409bfdbf16  vmovaps xmm3, [rsp+0x30]
000071409bfdbf1c  vmovaps xmm4, [rsp+0x40]
000071409bfdbf22  vmovaps xmm5, [rsp+0x50]
000071409bfdbf28  vmovaps xmm7, [rsp+0x60]
000071409bfdbf2e  vmovaps xmm8, [rsp+0x70]
000071409bfdbf34  vmovaps xmm9, [rsp+0x80]
000071409bfdbf3d  vmovaps xmm10, [rsp+0x90]
000071409bfdbf46  vmovaps xmm11, [rsp+0xA0]
000071409bfdbf4f  vmovaps xmm12, [rsp+0xB0]
000071409bfdbf58  vmovaps xmm13, [rsp+0xC0]
000071409bfdbf61  vmovaps xmm14, [rsp+0xD0]
000071409bfdbf6a  vmovaps xmm15, [rsp+0xE0]
000071409bfdbf73  add rsp, 0xF0
000071409bfdbf7a  pop r11
000071409bfdbf7c  pop r10
000071409bfdbf7e  pop r9
000071409bfdbf80  pop r8
000071409bfdbf82  pop rsi
000071409bfdbf83  pop rdi
000071409bfdbf84  pop rdx
000071409bfdbf85  pop rcx
000071409bfdbf86  pop rax
000071409bfdbf87  add rsp, 0x08
000071409bfdbf8b  jmp 0x000071409BFDA381
000071409bfdbf90  sub rsp, 0x08
000071409bfdbf94  push rax
000071409bfdbf95  push rcx
000071409bfdbf96  push rdx
000071409bfdbf97  push rdi
000071409bfdbf98  push rsi
000071409bfdbf99  push r8
000071409bfdbf9b  push r9
000071409bfdbf9d  push r10
000071409bfdbf9f  push r11
000071409bfdbfa1  sub rsp, 0xF0
000071409bfdbfa8  vmovaps [rsp], xmm0
000071409bfdbfad  vmovaps [rsp+0x10], xmm1
000071409bfdbfb3  vmovaps [rsp+0x20], xmm2
000071409bfdbfb9  vmovaps [rsp+0x30], xmm3
000071409bfdbfbf  vmovaps [rsp+0x40], xmm4
000071409bfdbfc5  vmovaps [rsp+0x50], xmm5
000071409bfdbfcb  vmovaps [rsp+0x60], xmm6
000071409bfdbfd1  vmovaps [rsp+0x70], xmm7
000071409bfdbfd7  vmovaps [rsp+0x80], xmm8
000071409bfdbfe0  vmovaps [rsp+0x90], xmm9
000071409bfdbfe9  vmovaps [rsp+0xA0], xmm11
000071409bfdbff2  vmovaps [rsp+0xB0], xmm12
000071409bfdbffb  vmovaps [rsp+0xC0], xmm13
000071409bfdc004  vmovaps [rsp+0xD0], xmm14
000071409bfdc00d  vmovaps [rsp+0xE0], xmm15
000071409bfdc016  sub rsp, 0x40
000071409bfdc01a  lea rdi, [rsp]
000071409bfdc01e  lea rsi, [rsp+0x10]
000071409bfdc023  lea rdx, [rsp+0x20]
000071409bfdc028  lea rcx, [rsp+0x30]
000071409bfdc02d  mov r8d, 0x00
000071409bfdc033  lea r9, [r15+0x3A8]
000071409bfdc03a  movaps [rdi], xmm10
000071409bfdc03e  movaps [rsi], xmm5
000071409bfdc041  movaps [rdx], xmm12
000071409bfdc045  movaps [rcx], xmm1
000071409bfdc048  mov rax, 0x6219BEBC2A50
000071409bfdc052  call rax
000071409bfdc054  movaps xmm10, [rsp]
000071409bfdc059  add rsp, 0x40
000071409bfdc05d  vmovaps xmm0, [rsp]
000071409bfdc062  vmovaps xmm1, [rsp+0x10]
000071409bfdc068  vmovaps xmm2, [rsp+0x20]
000071409bfdc06e  vmovaps xmm3, [rsp+0x30]
000071409bfdc074  vmovaps xmm4, [rsp+0x40]
000071409bfdc07a  vmovaps xmm5, [rsp+0x50]
000071409bfdc080  vmovaps xmm6, [rsp+0x60]
000071409bfdc086  vmovaps xmm7, [rsp+0x70]
000071409bfdc08c  vmovaps xmm8, [rsp+0x80]
000071409bfdc095  vmovaps xmm9, [rsp+0x90]
000071409bfdc09e  vmovaps xmm11, [rsp+0xA0]
000071409bfdc0a7  vmovaps xmm12, [rsp+0xB0]
000071409bfdc0b0  vmovaps xmm13, [rsp+0xC0]
000071409bfdc0b9  vmovaps xmm14, [rsp+0xD0]
000071409bfdc0c2  vmovaps xmm15, [rsp+0xE0]
000071409bfdc0cb  add rsp, 0xF0
000071409bfdc0d2  pop r11
000071409bfdc0d4  pop r10
000071409bfdc0d6  pop r9
000071409bfdc0d8  pop r8
000071409bfdc0da  pop rsi
000071409bfdc0db  pop rdi
000071409bfdc0dc  pop rdx
000071409bfdc0dd  pop rcx
000071409bfdc0de  pop rax
000071409bfdc0df  add rsp, 0x08
000071409bfdc0e3  jmp 0x000071409BFDA3B0
000071409bfdc0e8  sub rsp, 0x08
000071409bfdc0ec  push rax
000071409bfdc0ed  push rcx
000071409bfdc0ee  push rdx
000071409bfdc0ef  push rdi
000071409bfdc0f0  push rsi
000071409bfdc0f1  push r8
000071409bfdc0f3  push r9
000071409bfdc0f5  push r10
000071409bfdc0f7  push r11
000071409bfdc0f9  sub rsp, 0xF0
000071409bfdc100  vmovaps [rsp], xmm0
000071409bfdc105  vmovaps [rsp+0x10], xmm1
000071409bfdc10b  vmovaps [rsp+0x20], xmm2
000071409bfdc111  vmovaps [rsp+0x30], xmm3
000071409bfdc117  vmovaps [rsp+0x40], xmm4
000071409bfdc11d  vmovaps [rsp+0x50], xmm5
000071409bfdc123  vmovaps [rsp+0x60], xmm6
000071409bfdc129  vmovaps [rsp+0x70], xmm7
000071409bfdc12f  vmovaps [rsp+0x80], xmm8
000071409bfdc138  vmovaps [rsp+0x90], xmm9
000071409bfdc141  vmovaps [rsp+0xA0], xmm10
000071409bfdc14a  vmovaps [rsp+0xB0], xmm11
000071409bfdc153  vmovaps [rsp+0xC0], xmm13
000071409bfdc15c  vmovaps [rsp+0xD0], xmm14
000071409bfdc165  vmovaps [rsp+0xE0], xmm15
000071409bfdc16e  sub rsp, 0x40
000071409bfdc172  lea rdi, [rsp]
000071409bfdc176  lea rsi, [rsp+0x10]
000071409bfdc17b  lea rdx, [rsp+0x20]
000071409bfdc180  lea rcx, [rsp+0x30]
000071409bfdc185  mov r8d, 0x00
000071409bfdc18b  lea r9, [r15+0x3A8]
000071409bfdc192  movaps [rdi], xmm12
000071409bfdc196  movaps [rsi], xmm7
000071409bfdc199  movaps [rdx], xmm15
000071409bfdc19d  movaps [rcx], xmm1
000071409bfdc1a0  mov rax, 0x6219BEBC2A50
000071409bfdc1aa  call rax
000071409bfdc1ac  movaps xmm12, [rsp]
000071409bfdc1b1  add rsp, 0x40
000071409bfdc1b5  vmovaps xmm0, [rsp]
000071409bfdc1ba  vmovaps xmm1, [rsp+0x10]
000071409bfdc1c0  vmovaps xmm2, [rsp+0x20]
000071409bfdc1c6  vmovaps xmm3, [rsp+0x30]
000071409bfdc1cc  vmovaps xmm4, [rsp+0x40]
000071409bfdc1d2  vmovaps xmm5, [rsp+0x50]
000071409bfdc1d8  vmovaps xmm6, [rsp+0x60]
000071409bfdc1de  vmovaps xmm7, [rsp+0x70]
000071409bfdc1e4  vmovaps xmm8, [rsp+0x80]
000071409bfdc1ed  vmovaps xmm9, [rsp+0x90]
000071409bfdc1f6  vmovaps xmm10, [rsp+0xA0]
000071409bfdc1ff  vmovaps xmm11, [rsp+0xB0]
000071409bfdc208  vmovaps xmm13, [rsp+0xC0]
000071409bfdc211  vmovaps xmm14, [rsp+0xD0]
000071409bfdc21a  vmovaps xmm15, [rsp+0xE0]
000071409bfdc223  add rsp, 0xF0
000071409bfdc22a  pop r11
000071409bfdc22c  pop r10
000071409bfdc22e  pop r9
000071409bfdc230  pop r8
000071409bfdc232  pop rsi
000071409bfdc233  pop rdi
000071409bfdc234  pop rdx
000071409bfdc235  pop rcx
000071409bfdc236  pop rax
000071409bfdc237  add rsp, 0x08
000071409bfdc23b  jmp 0x000071409BFDA3D9
000071409bfdc240  call 0x000071409BDFF430
000071409bfdc245  jmp 0x000071409BFDA3E3
000071409bfdc24a  call 0x000071409BE0E760
000071409bfdc24f  jmp 0x000071409BFDA3ED
000071409bfdc254  sub rsp, 0x08
000071409bfdc258  push rax
000071409bfdc259  push rcx
000071409bfdc25a  push rdx
000071409bfdc25b  push rdi
000071409bfdc25c  push rsi
000071409bfdc25d  push r8
000071409bfdc25f  push r9
000071409bfdc261  push r10
000071409bfdc263  push r11
000071409bfdc265  sub rsp, 0xF0
000071409bfdc26c  vmovaps [rsp], xmm0
000071409bfdc271  vmovaps [rsp+0x10], xmm1
000071409bfdc277  vmovaps [rsp+0x20], xmm2
000071409bfdc27d  vmovaps [rsp+0x30], xmm3
000071409bfdc283  vmovaps [rsp+0x40], xmm4
000071409bfdc289  vmovaps [rsp+0x50], xmm5
000071409bfdc28f  vmovaps [rsp+0x60], xmm6
000071409bfdc295  vmovaps [rsp+0x70], xmm8
000071409bfdc29b  vmovaps [rsp+0x80], xmm9
000071409bfdc2a4  vmovaps [rsp+0x90], xmm10
000071409bfdc2ad  vmovaps [rsp+0xA0], xmm11
000071409bfdc2b6  vmovaps [rsp+0xB0], xmm12
000071409bfdc2bf  vmovaps [rsp+0xC0], xmm13
000071409bfdc2c8  vmovaps [rsp+0xD0], xmm14
000071409bfdc2d1  vmovaps [rsp+0xE0], xmm15
000071409bfdc2da  sub rsp, 0x40
000071409bfdc2de  lea rdi, [rsp]
000071409bfdc2e2  lea rsi, [rsp+0x10]
000071409bfdc2e7  lea rdx, [rsp+0x20]
000071409bfdc2ec  lea rcx, [rsp+0x30]
000071409bfdc2f1  mov r8d, 0x00
000071409bfdc2f7  lea r9, [r15+0x3A8]
000071409bfdc2fe  movaps [rdi], xmm7
000071409bfdc301  movaps [rsi], xmm2
000071409bfdc304  movaps [rdx], xmm9
000071409bfdc308  movaps [rcx], xmm11
000071409bfdc30c  mov rax, 0x6219BEBC2A50
000071409bfdc316  call rax
000071409bfdc318  movaps xmm7, [rsp]
000071409bfdc31c  add rsp, 0x40
000071409bfdc320  vmovaps xmm0, [rsp]
000071409bfdc325  vmovaps xmm1, [rsp+0x10]
000071409bfdc32b  vmovaps xmm2, [rsp+0x20]
000071409bfdc331  vmovaps xmm3, [rsp+0x30]
000071409bfdc337  vmovaps xmm4, [rsp+0x40]
000071409bfdc33d  vmovaps xmm5, [rsp+0x50]
000071409bfdc343  vmovaps xmm6, [rsp+0x60]
000071409bfdc349  vmovaps xmm8, [rsp+0x70]
000071409bfdc34f  vmovaps xmm9, [rsp+0x80]
000071409bfdc358  vmovaps xmm10, [rsp+0x90]
000071409bfdc361  vmovaps xmm11, [rsp+0xA0]
000071409bfdc36a  vmovaps xmm12, [rsp+0xB0]
000071409bfdc373  vmovaps xmm13, [rsp+0xC0]
000071409bfdc37c  vmovaps xmm14, [rsp+0xD0]
000071409bfdc385  vmovaps xmm15, [rsp+0xE0]
000071409bfdc38e  add rsp, 0xF0
000071409bfdc395  pop r11
000071409bfdc397  pop r10
000071409bfdc399  pop r9
000071409bfdc39b  pop r8
000071409bfdc39d  pop rsi
000071409bfdc39e  pop rdi
000071409bfdc39f  pop rdx
000071409bfdc3a0  pop rcx
000071409bfdc3a1  pop rax
000071409bfdc3a2  add rsp, 0x08
000071409bfdc3a6  jmp 0x000071409BFDA421
000071409bfdc3ab  sub rsp, 0x08
000071409bfdc3af  push rax
000071409bfdc3b0  push rcx
000071409bfdc3b1  push rdx
000071409bfdc3b2  push rdi
000071409bfdc3b3  push rsi
000071409bfdc3b4  push r8
000071409bfdc3b6  push r9
000071409bfdc3b8  push r10
000071409bfdc3ba  push r11
000071409bfdc3bc  sub rsp, 0xF0
000071409bfdc3c3  vmovaps [rsp], xmm0
000071409bfdc3c8  vmovaps [rsp+0x10], xmm1
000071409bfdc3ce  vmovaps [rsp+0x20], xmm2
000071409bfdc3d4  vmovaps [rsp+0x30], xmm3
000071409bfdc3da  vmovaps [rsp+0x40], xmm4
000071409bfdc3e0  vmovaps [rsp+0x50], xmm5
000071409bfdc3e6  vmovaps [rsp+0x60], xmm6
000071409bfdc3ec  vmovaps [rsp+0x70], xmm7
000071409bfdc3f2  vmovaps [rsp+0x80], xmm8
000071409bfdc3fb  vmovaps [rsp+0x90], xmm10
000071409bfdc404  vmovaps [rsp+0xA0], xmm11
000071409bfdc40d  vmovaps [rsp+0xB0], xmm12
000071409bfdc416  vmovaps [rsp+0xC0], xmm13
000071409bfdc41f  vmovaps [rsp+0xD0], xmm14
000071409bfdc428  vmovaps [rsp+0xE0], xmm15
000071409bfdc431  sub rsp, 0x40
000071409bfdc435  lea rdi, [rsp]
000071409bfdc439  lea rsi, [rsp+0x10]
000071409bfdc43e  lea rdx, [rsp+0x20]
000071409bfdc443  lea rcx, [rsp+0x30]
000071409bfdc448  mov r8d, 0x00
000071409bfdc44e  lea r9, [r15+0x3A8]
000071409bfdc455  movaps [rdi], xmm9
000071409bfdc459  movaps [rsi], xmm6
000071409bfdc45c  movaps [rdx], xmm1
000071409bfdc45f  movaps [rcx], xmm11
000071409bfdc463  mov rax, 0x6219BEBC2A50
000071409bfdc46d  call rax
000071409bfdc46f  movaps xmm9, [rsp]
000071409bfdc474  add rsp, 0x40
000071409bfdc478  vmovaps xmm0, [rsp]
000071409bfdc47d  vmovaps xmm1, [rsp+0x10]
000071409bfdc483  vmovaps xmm2, [rsp+0x20]
000071409bfdc489  vmovaps xmm3, [rsp+0x30]
000071409bfdc48f  vmovaps xmm4, [rsp+0x40]
000071409bfdc495  vmovaps xmm5, [rsp+0x50]
000071409bfdc49b  vmovaps xmm6, [rsp+0x60]
000071409bfdc4a1  vmovaps xmm7, [rsp+0x70]
000071409bfdc4a7  vmovaps xmm8, [rsp+0x80]
000071409bfdc4b0  vmovaps xmm10, [rsp+0x90]
000071409bfdc4b9  vmovaps xmm11, [rsp+0xA0]
000071409bfdc4c2  vmovaps xmm12, [rsp+0xB0]
000071409bfdc4cb  vmovaps xmm13, [rsp+0xC0]
000071409bfdc4d4  vmovaps xmm14, [rsp+0xD0]
000071409bfdc4dd  vmovaps xmm15, [rsp+0xE0]
000071409bfdc4e6  add rsp, 0xF0
000071409bfdc4ed  pop r11
000071409bfdc4ef  pop r10
000071409bfdc4f1  pop r9
000071409bfdc4f3  pop r8
000071409bfdc4f5  pop rsi
000071409bfdc4f6  pop rdi
000071409bfdc4f7  pop rdx
000071409bfdc4f8  pop rcx
000071409bfdc4f9  pop rax
000071409bfdc4fa  add rsp, 0x08
000071409bfdc4fe  jmp 0x000071409BFDA447
000071409bfdc503  sub rsp, 0x08
000071409bfdc507  push rax
000071409bfdc508  push rcx
000071409bfdc509  push rdx
000071409bfdc50a  push rdi
000071409bfdc50b  push rsi
000071409bfdc50c  push r8
000071409bfdc50e  push r9
000071409bfdc510  push r10
000071409bfdc512  push r11
000071409bfdc514  sub rsp, 0xF0
000071409bfdc51b  vmovaps [rsp], xmm0
000071409bfdc520  vmovaps [rsp+0x10], xmm1
000071409bfdc526  vmovaps [rsp+0x20], xmm2
000071409bfdc52c  vmovaps [rsp+0x30], xmm3
000071409bfdc532  vmovaps [rsp+0x40], xmm4
000071409bfdc538  vmovaps [rsp+0x50], xmm5
000071409bfdc53e  vmovaps [rsp+0x60], xmm6
000071409bfdc544  vmovaps [rsp+0x70], xmm7
000071409bfdc54a  vmovaps [rsp+0x80], xmm8
000071409bfdc553  vmovaps [rsp+0x90], xmm9
000071409bfdc55c  vmovaps [rsp+0xA0], xmm10
000071409bfdc565  vmovaps [rsp+0xB0], xmm12
000071409bfdc56e  vmovaps [rsp+0xC0], xmm13
000071409bfdc577  vmovaps [rsp+0xD0], xmm14
000071409bfdc580  vmovaps [rsp+0xE0], xmm15
000071409bfdc589  sub rsp, 0x40
000071409bfdc58d  lea rdi, [rsp]
000071409bfdc591  lea rsi, [rsp+0x10]
000071409bfdc596  lea rdx, [rsp+0x20]
000071409bfdc59b  lea rcx, [rsp+0x30]
000071409bfdc5a0  mov r8d, 0x00
000071409bfdc5a6  lea r9, [r15+0x3A8]
000071409bfdc5ad  movaps [rdi], xmm11
000071409bfdc5b1  movaps [rsi], xmm10
000071409bfdc5b5  movaps [rdx], xmm8
000071409bfdc5b9  movaps [rcx], xmm1
000071409bfdc5bc  mov rax, 0x6219BEBC2A50
000071409bfdc5c6  call rax
000071409bfdc5c8  movaps xmm11, [rsp]
000071409bfdc5cd  add rsp, 0x40
000071409bfdc5d1  vmovaps xmm0, [rsp]
000071409bfdc5d6  vmovaps xmm1, [rsp+0x10]
000071409bfdc5dc  vmovaps xmm2, [rsp+0x20]
000071409bfdc5e2  vmovaps xmm3, [rsp+0x30]
000071409bfdc5e8  vmovaps xmm4, [rsp+0x40]
000071409bfdc5ee  vmovaps xmm5, [rsp+0x50]
000071409bfdc5f4  vmovaps xmm6, [rsp+0x60]
000071409bfdc5fa  vmovaps xmm7, [rsp+0x70]
000071409bfdc600  vmovaps xmm8, [rsp+0x80]
000071409bfdc609  vmovaps xmm9, [rsp+0x90]
000071409bfdc612  vmovaps xmm10, [rsp+0xA0]
000071409bfdc61b  vmovaps xmm12, [rsp+0xB0]
000071409bfdc624  vmovaps xmm13, [rsp+0xC0]
000071409bfdc62d  vmovaps xmm14, [rsp+0xD0]
000071409bfdc636  vmovaps xmm15, [rsp+0xE0]
000071409bfdc63f  add rsp, 0xF0
000071409bfdc646  pop r11
000071409bfdc648  pop r10
000071409bfdc64a  pop r9
000071409bfdc64c  pop r8
000071409bfdc64e  pop rsi
000071409bfdc64f  pop rdi
000071409bfdc650  pop rdx
000071409bfdc651  pop rcx
000071409bfdc652  pop rax
000071409bfdc653  add rsp, 0x08
000071409bfdc657  jmp 0x000071409BFDA46D
000071409bfdc65c  sub rsp, 0x08
000071409bfdc660  push rax
000071409bfdc661  push rcx
000071409bfdc662  push rdx
000071409bfdc663  push rdi
000071409bfdc664  push rsi
000071409bfdc665  push r8
000071409bfdc667  push r9
000071409bfdc669  push r10
000071409bfdc66b  push r11
000071409bfdc66d  sub rsp, 0xF0
000071409bfdc674  vmovaps [rsp], xmm0
000071409bfdc679  vmovaps [rsp+0x10], xmm1
000071409bfdc67f  vmovaps [rsp+0x20], xmm2
000071409bfdc685  vmovaps [rsp+0x30], xmm3
000071409bfdc68b  vmovaps [rsp+0x40], xmm4
000071409bfdc691  vmovaps [rsp+0x50], xmm5
000071409bfdc697  vmovaps [rsp+0x60], xmm6
000071409bfdc69d  vmovaps [rsp+0x70], xmm7
000071409bfdc6a3  vmovaps [rsp+0x80], xmm8
000071409bfdc6ac  vmovaps [rsp+0x90], xmm9
000071409bfdc6b5  vmovaps [rsp+0xA0], xmm11
000071409bfdc6be  vmovaps [rsp+0xB0], xmm12
000071409bfdc6c7  vmovaps [rsp+0xC0], xmm13
000071409bfdc6d0  vmovaps [rsp+0xD0], xmm14
000071409bfdc6d9  vmovaps [rsp+0xE0], xmm15
000071409bfdc6e2  sub rsp, 0x40
000071409bfdc6e6  lea rdi, [rsp]
000071409bfdc6ea  lea rsi, [rsp+0x10]
000071409bfdc6ef  lea rdx, [rsp+0x20]
000071409bfdc6f4  lea rcx, [rsp+0x30]
000071409bfdc6f9  mov r8d, 0x00
000071409bfdc6ff  lea r9, [r15+0x3A8]
000071409bfdc706  movaps [rdi], xmm10
000071409bfdc70a  movaps [rsi], xmm12
000071409bfdc70e  movaps [rdx], xmm13
000071409bfdc712  movaps [rcx], xmm1
000071409bfdc715  mov rax, 0x6219BEBC2A50
000071409bfdc71f  call rax
000071409bfdc721  movaps xmm10, [rsp]
000071409bfdc726  add rsp, 0x40
000071409bfdc72a  vmovaps xmm0, [rsp]
000071409bfdc72f  vmovaps xmm1, [rsp+0x10]
000071409bfdc735  vmovaps xmm2, [rsp+0x20]
000071409bfdc73b  vmovaps xmm3, [rsp+0x30]
000071409bfdc741  vmovaps xmm4, [rsp+0x40]
000071409bfdc747  vmovaps xmm5, [rsp+0x50]
000071409bfdc74d  vmovaps xmm6, [rsp+0x60]
000071409bfdc753  vmovaps xmm7, [rsp+0x70]
000071409bfdc759  vmovaps xmm8, [rsp+0x80]
000071409bfdc762  vmovaps xmm9, [rsp+0x90]
000071409bfdc76b  vmovaps xmm11, [rsp+0xA0]
000071409bfdc774  vmovaps xmm12, [rsp+0xB0]
000071409bfdc77d  vmovaps xmm13, [rsp+0xC0]
000071409bfdc786  vmovaps xmm14, [rsp+0xD0]
000071409bfdc78f  vmovaps xmm15, [rsp+0xE0]
000071409bfdc798  add rsp, 0xF0
000071409bfdc79f  pop r11
000071409bfdc7a1  pop r10
000071409bfdc7a3  pop r9
000071409bfdc7a5  pop r8
000071409bfdc7a7  pop rsi
000071409bfdc7a8  pop rdi
000071409bfdc7a9  pop rdx
000071409bfdc7aa  pop rcx
000071409bfdc7ab  pop rax
000071409bfdc7ac  add rsp, 0x08
000071409bfdc7b0  jmp 0x000071409BFDA493
000071409bfdc7b5  call 0x000071409BDFF430
000071409bfdc7ba  jmp 0x000071409BFDA49D
000071409bfdc7bf  call 0x000071409BE0C260
000071409bfdc7c4  jmp 0x000071409BFDA4A7
000071409bfdc7c9  sub rsp, 0x08
000071409bfdc7cd  push rax
000071409bfdc7ce  push rcx
000071409bfdc7cf  push rdx
000071409bfdc7d0  push rdi
000071409bfdc7d1  push rsi
000071409bfdc7d2  push r8
000071409bfdc7d4  push r9
000071409bfdc7d6  push r10
000071409bfdc7d8  push r11
000071409bfdc7da  sub rsp, 0xF0
000071409bfdc7e1  vmovaps [rsp], xmm0
000071409bfdc7e6  vmovaps [rsp+0x10], xmm1
000071409bfdc7ec  vmovaps [rsp+0x20], xmm2
000071409bfdc7f2  vmovaps [rsp+0x30], xmm3
000071409bfdc7f8  vmovaps [rsp+0x40], xmm4
000071409bfdc7fe  vmovaps [rsp+0x50], xmm5
000071409bfdc804  vmovaps [rsp+0x60], xmm6
000071409bfdc80a  vmovaps [rsp+0x70], xmm7
000071409bfdc810  vmovaps [rsp+0x80], xmm9
000071409bfdc819  vmovaps [rsp+0x90], xmm10
000071409bfdc822  vmovaps [rsp+0xA0], xmm11
000071409bfdc82b  vmovaps [rsp+0xB0], xmm12
000071409bfdc834  vmovaps [rsp+0xC0], xmm13
000071409bfdc83d  vmovaps [rsp+0xD0], xmm14
000071409bfdc846  vmovaps [rsp+0xE0], xmm15
000071409bfdc84f  sub rsp, 0x40
000071409bfdc853  lea rdi, [rsp]
000071409bfdc857  lea rsi, [rsp+0x10]
000071409bfdc85c  lea rdx, [rsp+0x20]
000071409bfdc861  lea rcx, [rsp+0x30]
000071409bfdc866  mov r8d, 0x00
000071409bfdc86c  lea r9, [r15+0x3A8]
000071409bfdc873  movaps [rdi], xmm8
000071409bfdc877  movaps [rsi], xmm7
000071409bfdc87a  movaps [rdx], xmm4
000071409bfdc87d  movaps [rcx], xmm12
000071409bfdc881  mov rax, 0x6219BEBC2A50
000071409bfdc88b  call rax
000071409bfdc88d  movaps xmm8, [rsp]
000071409bfdc892  add rsp, 0x40
000071409bfdc896  vmovaps xmm0, [rsp]
000071409bfdc89b  vmovaps xmm1, [rsp+0x10]
000071409bfdc8a1  vmovaps xmm2, [rsp+0x20]
000071409bfdc8a7  vmovaps xmm3, [rsp+0x30]
000071409bfdc8ad  vmovaps xmm4, [rsp+0x40]
000071409bfdc8b3  vmovaps xmm5, [rsp+0x50]
000071409bfdc8b9  vmovaps xmm6, [rsp+0x60]
000071409bfdc8bf  vmovaps xmm7, [rsp+0x70]
000071409bfdc8c5  vmovaps xmm9, [rsp+0x80]
000071409bfdc8ce  vmovaps xmm10, [rsp+0x90]
000071409bfdc8d7  vmovaps xmm11, [rsp+0xA0]
000071409bfdc8e0  vmovaps xmm12, [rsp+0xB0]
000071409bfdc8e9  vmovaps xmm13, [rsp+0xC0]
000071409bfdc8f2  vmovaps xmm14, [rsp+0xD0]
000071409bfdc8fb  vmovaps xmm15, [rsp+0xE0]
000071409bfdc904  add rsp, 0xF0
000071409bfdc90b  pop r11
000071409bfdc90d  pop r10
000071409bfdc90f  pop r9
000071409bfdc911  pop r8
000071409bfdc913  pop rsi
000071409bfdc914  pop rdi
000071409bfdc915  pop rdx
000071409bfdc916  pop rcx
000071409bfdc917  pop rax
000071409bfdc918  add rsp, 0x08
000071409bfdc91c  jmp 0x000071409BFDA4D0
000071409bfdc921  sub rsp, 0x08
000071409bfdc925  push rax
000071409bfdc926  push rcx
000071409bfdc927  push rdx
000071409bfdc928  push rdi
000071409bfdc929  push rsi
000071409bfdc92a  push r8
000071409bfdc92c  push r9
000071409bfdc92e  push r10
000071409bfdc930  push r11
000071409bfdc932  sub rsp, 0xF0
000071409bfdc939  vmovaps [rsp], xmm0
000071409bfdc93e  vmovaps [rsp+0x10], xmm1
000071409bfdc944  vmovaps [rsp+0x20], xmm2
000071409bfdc94a  vmovaps [rsp+0x30], xmm3
000071409bfdc950  vmovaps [rsp+0x40], xmm4
000071409bfdc956  vmovaps [rsp+0x50], xmm5
000071409bfdc95c  vmovaps [rsp+0x60], xmm6
000071409bfdc962  vmovaps [rsp+0x70], xmm8
000071409bfdc968  vmovaps [rsp+0x80], xmm9
000071409bfdc971  vmovaps [rsp+0x90], xmm10
000071409bfdc97a  vmovaps [rsp+0xA0], xmm11
000071409bfdc983  vmovaps [rsp+0xB0], xmm12
000071409bfdc98c  vmovaps [rsp+0xC0], xmm13
000071409bfdc995  vmovaps [rsp+0xD0], xmm14
000071409bfdc99e  vmovaps [rsp+0xE0], xmm15
000071409bfdc9a7  sub rsp, 0x40
000071409bfdc9ab  lea rdi, [rsp]
000071409bfdc9af  lea rsi, [rsp+0x10]
000071409bfdc9b4  lea rdx, [rsp+0x20]
000071409bfdc9b9  lea rcx, [rsp+0x30]
000071409bfdc9be  mov r8d, 0x00
000071409bfdc9c4  lea r9, [r15+0x3A8]
000071409bfdc9cb  movaps [rdi], xmm7
000071409bfdc9ce  movaps [rsi], xmm9
000071409bfdc9d2  movaps [rdx], xmm14
000071409bfdc9d6  movaps [rcx], xmm12
000071409bfdc9da  mov rax, 0x6219BEBC2A50
000071409bfdc9e4  call rax
000071409bfdc9e6  movaps xmm7, [rsp]
000071409bfdc9ea  add rsp, 0x40
000071409bfdc9ee  vmovaps xmm0, [rsp]
000071409bfdc9f3  vmovaps xmm1, [rsp+0x10]
000071409bfdc9f9  vmovaps xmm2, [rsp+0x20]
000071409bfdc9ff  vmovaps xmm3, [rsp+0x30]
000071409bfdca05  vmovaps xmm4, [rsp+0x40]
000071409bfdca0b  vmovaps xmm5, [rsp+0x50]
000071409bfdca11  vmovaps xmm6, [rsp+0x60]
000071409bfdca17  vmovaps xmm8, [rsp+0x70]
000071409bfdca1d  vmovaps xmm9, [rsp+0x80]
000071409bfdca26  vmovaps xmm10, [rsp+0x90]
000071409bfdca2f  vmovaps xmm11, [rsp+0xA0]
000071409bfdca38  vmovaps xmm12, [rsp+0xB0]
000071409bfdca41  vmovaps xmm13, [rsp+0xC0]
000071409bfdca4a  vmovaps xmm14, [rsp+0xD0]
000071409bfdca53  vmovaps xmm15, [rsp+0xE0]
000071409bfdca5c  add rsp, 0xF0
000071409bfdca63  pop r11
000071409bfdca65  pop r10
000071409bfdca67  pop r9
000071409bfdca69  pop r8
000071409bfdca6b  pop rsi
000071409bfdca6c  pop rdi
000071409bfdca6d  pop rdx
000071409bfdca6e  pop rcx
000071409bfdca6f  pop rax
000071409bfdca70  add rsp, 0x08
000071409bfdca74  jmp 0x000071409BFDA4F8
000071409bfdca79  sub rsp, 0x08
000071409bfdca7d  push rax
000071409bfdca7e  push rcx
000071409bfdca7f  push rdx
000071409bfdca80  push rdi
000071409bfdca81  push rsi
000071409bfdca82  push r8
000071409bfdca84  push r9
000071409bfdca86  push r10
000071409bfdca88  push r11
000071409bfdca8a  sub rsp, 0xF0
000071409bfdca91  vmovaps [rsp], xmm0
000071409bfdca96  vmovaps [rsp+0x10], xmm1
000071409bfdca9c  vmovaps [rsp+0x20], xmm2
000071409bfdcaa2  vmovaps [rsp+0x30], xmm3
000071409bfdcaa8  vmovaps [rsp+0x40], xmm4
000071409bfdcaae  vmovaps [rsp+0x50], xmm5
000071409bfdcab4  vmovaps [rsp+0x60], xmm6
000071409bfdcaba  vmovaps [rsp+0x70], xmm7
000071409bfdcac0  vmovaps [rsp+0x80], xmm8
000071409bfdcac9  vmovaps [rsp+0x90], xmm9
000071409bfdcad2  vmovaps [rsp+0xA0], xmm10
000071409bfdcadb  vmovaps [rsp+0xB0], xmm11
000071409bfdcae4  vmovaps [rsp+0xC0], xmm13
000071409bfdcaed  vmovaps [rsp+0xD0], xmm14
000071409bfdcaf6  vmovaps [rsp+0xE0], xmm15
000071409bfdcaff  sub rsp, 0x40
000071409bfdcb03  lea rdi, [rsp]
000071409bfdcb07  lea rsi, [rsp+0x10]
000071409bfdcb0c  lea rdx, [rsp+0x20]
000071409bfdcb11  lea rcx, [rsp+0x30]
000071409bfdcb16  mov r8d, 0x00
000071409bfdcb1c  lea r9, [r15+0x3A8]
000071409bfdcb23  movaps [rdi], xmm12
000071409bfdcb27  movaps [rsi], xmm11
000071409bfdcb2b  movaps [rdx], xmm15
000071409bfdcb2f  movaps [rcx], xmm14
000071409bfdcb33  mov rax, 0x6219BEBC2A50
000071409bfdcb3d  call rax
000071409bfdcb3f  movaps xmm12, [rsp]
000071409bfdcb44  add rsp, 0x40
000071409bfdcb48  vmovaps xmm0, [rsp]
000071409bfdcb4d  vmovaps xmm1, [rsp+0x10]
000071409bfdcb53  vmovaps xmm2, [rsp+0x20]
000071409bfdcb59  vmovaps xmm3, [rsp+0x30]
000071409bfdcb5f  vmovaps xmm4, [rsp+0x40]
000071409bfdcb65  vmovaps xmm5, [rsp+0x50]
000071409bfdcb6b  vmovaps xmm6, [rsp+0x60]
000071409bfdcb71  vmovaps xmm7, [rsp+0x70]
000071409bfdcb77  vmovaps xmm8, [rsp+0x80]
000071409bfdcb80  vmovaps xmm9, [rsp+0x90]
000071409bfdcb89  vmovaps xmm10, [rsp+0xA0]
000071409bfdcb92  vmovaps xmm11, [rsp+0xB0]
000071409bfdcb9b  vmovaps xmm13, [rsp+0xC0]
000071409bfdcba4  vmovaps xmm14, [rsp+0xD0]
000071409bfdcbad  vmovaps xmm15, [rsp+0xE0]
000071409bfdcbb6  add rsp, 0xF0
000071409bfdcbbd  pop r11
000071409bfdcbbf  pop r10
000071409bfdcbc1  pop r9
000071409bfdcbc3  pop r8
000071409bfdcbc5  pop rsi
000071409bfdcbc6  pop rdi
000071409bfdcbc7  pop rdx
000071409bfdcbc8  pop rcx
000071409bfdcbc9  pop rax
000071409bfdcbca  add rsp, 0x08
000071409bfdcbce  jmp 0x000071409BFDA521
000071409bfdcbd3  sub rsp, 0x08
000071409bfdcbd7  push rax
000071409bfdcbd8  push rcx
000071409bfdcbd9  push rdx
000071409bfdcbda  push rdi
000071409bfdcbdb  push rsi
000071409bfdcbdc  push r8
000071409bfdcbde  push r9
000071409bfdcbe0  push r10
000071409bfdcbe2  push r11
000071409bfdcbe4  sub rsp, 0xF0
000071409bfdcbeb  vmovaps [rsp], xmm0
000071409bfdcbf0  vmovaps [rsp+0x10], xmm1
000071409bfdcbf6  vmovaps [rsp+0x20], xmm2
000071409bfdcbfc  vmovaps [rsp+0x30], xmm3
000071409bfdcc02  vmovaps [rsp+0x40], xmm4
000071409bfdcc08  vmovaps [rsp+0x50], xmm5
000071409bfdcc0e  vmovaps [rsp+0x60], xmm6
000071409bfdcc14  vmovaps [rsp+0x70], xmm7
000071409bfdcc1a  vmovaps [rsp+0x80], xmm8
000071409bfdcc23  vmovaps [rsp+0x90], xmm9
000071409bfdcc2c  vmovaps [rsp+0xA0], xmm10
000071409bfdcc35  vmovaps [rsp+0xB0], xmm12
000071409bfdcc3e  vmovaps [rsp+0xC0], xmm13
000071409bfdcc47  vmovaps [rsp+0xD0], xmm14
000071409bfdcc50  vmovaps [rsp+0xE0], xmm15
000071409bfdcc59  sub rsp, 0x40
000071409bfdcc5d  lea rdi, [rsp]
000071409bfdcc61  lea rsi, [rsp+0x10]
000071409bfdcc66  lea rdx, [rsp+0x20]
000071409bfdcc6b  lea rcx, [rsp+0x30]
000071409bfdcc70  mov r8d, 0x00
000071409bfdcc76  lea r9, [r15+0x3A8]
000071409bfdcc7d  movaps [rdi], xmm11
000071409bfdcc81  movaps [rsi], xmm10
000071409bfdcc85  movaps [rdx], xmm13
000071409bfdcc89  movaps [rcx], xmm15
000071409bfdcc8d  mov rax, 0x6219BEBC2A50
000071409bfdcc97  call rax
000071409bfdcc99  movaps xmm11, [rsp]
000071409bfdcc9e  add rsp, 0x40
000071409bfdcca2  vmovaps xmm0, [rsp]
000071409bfdcca7  vmovaps xmm1, [rsp+0x10]
000071409bfdccad  vmovaps xmm2, [rsp+0x20]
000071409bfdccb3  vmovaps xmm3, [rsp+0x30]
000071409bfdccb9  vmovaps xmm4, [rsp+0x40]
000071409bfdccbf  vmovaps xmm5, [rsp+0x50]
000071409bfdccc5  vmovaps xmm6, [rsp+0x60]
000071409bfdcccb  vmovaps xmm7, [rsp+0x70]
000071409bfdccd1  vmovaps xmm8, [rsp+0x80]
000071409bfdccda  vmovaps xmm9, [rsp+0x90]
000071409bfdcce3  vmovaps xmm10, [rsp+0xA0]
000071409bfdccec  vmovaps xmm12, [rsp+0xB0]
000071409bfdccf5  vmovaps xmm13, [rsp+0xC0]
000071409bfdccfe  vmovaps xmm14, [rsp+0xD0]
000071409bfdcd07  vmovaps xmm15, [rsp+0xE0]
000071409bfdcd10  add rsp, 0xF0
000071409bfdcd17  pop r11
000071409bfdcd19  pop r10
000071409bfdcd1b  pop r9
000071409bfdcd1d  pop r8
000071409bfdcd1f  pop rsi
000071409bfdcd20  pop rdi
000071409bfdcd21  pop rdx
000071409bfdcd22  pop rcx
000071409bfdcd23  pop rax
000071409bfdcd24  add rsp, 0x08
000071409bfdcd28  jmp 0x000071409BFDA54A
000071409bfdcd2d  call 0x000071409BE0E760
000071409bfdcd32  jmp 0x000071409BFDA557
000071409bfdcd37  call 0x000071409BE0D4E0
000071409bfdcd3c  jmp 0x000071409BFDA564
000071409bfdcd41  sub rsp, 0x08
000071409bfdcd45  push rax
000071409bfdcd46  push rcx
000071409bfdcd47  push rdx
000071409bfdcd48  push rdi
000071409bfdcd49  push rsi
000071409bfdcd4a  push r8
000071409bfdcd4c  push r9
000071409bfdcd4e  push r10
000071409bfdcd50  push r11
000071409bfdcd52  sub rsp, 0xF0
000071409bfdcd59  vmovaps [rsp], xmm0
000071409bfdcd5e  vmovaps [rsp+0x10], xmm1
000071409bfdcd64  vmovaps [rsp+0x20], xmm2
000071409bfdcd6a  vmovaps [rsp+0x30], xmm3
000071409bfdcd70  vmovaps [rsp+0x40], xmm4
000071409bfdcd76  vmovaps [rsp+0x50], xmm5
000071409bfdcd7c  vmovaps [rsp+0x60], xmm6
000071409bfdcd82  vmovaps [rsp+0x70], xmm7
000071409bfdcd88  vmovaps [rsp+0x80], xmm8
000071409bfdcd91  vmovaps [rsp+0x90], xmm9
000071409bfdcd9a  vmovaps [rsp+0xA0], xmm11
000071409bfdcda3  vmovaps [rsp+0xB0], xmm12
000071409bfdcdac  vmovaps [rsp+0xC0], xmm13
000071409bfdcdb5  vmovaps [rsp+0xD0], xmm14
000071409bfdcdbe  vmovaps [rsp+0xE0], xmm15
000071409bfdcdc7  sub rsp, 0x40
000071409bfdcdcb  lea rdi, [rsp]
000071409bfdcdcf  lea rsi, [rsp+0x10]
000071409bfdcdd4  lea rdx, [rsp+0x20]
000071409bfdcdd9  lea rcx, [rsp+0x30]
000071409bfdcdde  mov r8d, 0x00
000071409bfdcde4  lea r9, [r15+0x3A8]
000071409bfdcdeb  movaps [rdi], xmm10
000071409bfdcdef  movaps [rsi], xmm8
000071409bfdcdf3  movaps [rdx], xmm1
000071409bfdcdf6  movaps [rcx], xmm13
000071409bfdcdfa  mov rax, 0x6219BEBC2A50
000071409bfdce04  call rax
000071409bfdce06  movaps xmm10, [rsp]
000071409bfdce0b  add rsp, 0x40
000071409bfdce0f  vmovaps xmm0, [rsp]
000071409bfdce14  vmovaps xmm1, [rsp+0x10]
000071409bfdce1a  vmovaps xmm2, [rsp+0x20]
000071409bfdce20  vmovaps xmm3, [rsp+0x30]
000071409bfdce26  vmovaps xmm4, [rsp+0x40]
000071409bfdce2c  vmovaps xmm5, [rsp+0x50]
000071409bfdce32  vmovaps xmm6, [rsp+0x60]
000071409bfdce38  vmovaps xmm7, [rsp+0x70]
000071409bfdce3e  vmovaps xmm8, [rsp+0x80]
000071409bfdce47  vmovaps xmm9, [rsp+0x90]
000071409bfdce50  vmovaps xmm11, [rsp+0xA0]
000071409bfdce59  vmovaps xmm12, [rsp+0xB0]
000071409bfdce62  vmovaps xmm13, [rsp+0xC0]
000071409bfdce6b  vmovaps xmm14, [rsp+0xD0]
000071409bfdce74  vmovaps xmm15, [rsp+0xE0]
000071409bfdce7d  add rsp, 0xF0
000071409bfdce84  pop r11
000071409bfdce86  pop r10
000071409bfdce88  pop r9
000071409bfdce8a  pop r8
000071409bfdce8c  pop rsi
000071409bfdce8d  pop rdi
000071409bfdce8e  pop rdx
000071409bfdce8f  pop rcx
000071409bfdce90  pop rax
000071409bfdce91  add rsp, 0x08
000071409bfdce95  jmp 0x000071409BFDA59A
000071409bfdce9a  call 0x000071409BDFF430
000071409bfdce9f  jmp 0x000071409BFDA5AC
000071409bfdcea4  sub rsp, 0x08
000071409bfdcea8  push rax
000071409bfdcea9  push rcx
000071409bfdceaa  push rdx
000071409bfdceab  push rdi
000071409bfdceac  push rsi
000071409bfdcead  push r8
000071409bfdceaf  push r9
000071409bfdceb1  push r10
000071409bfdceb3  push r11
000071409bfdceb5  sub rsp, 0xF0
000071409bfdcebc  vmovaps [rsp], xmm0
000071409bfdcec1  vmovaps [rsp+0x10], xmm1
000071409bfdcec7  vmovaps [rsp+0x20], xmm2
000071409bfdcecd  vmovaps [rsp+0x30], xmm3
000071409bfdced3  vmovaps [rsp+0x40], xmm4
000071409bfdced9  vmovaps [rsp+0x50], xmm5
000071409bfdcedf  vmovaps [rsp+0x60], xmm6
000071409bfdcee5  vmovaps [rsp+0x70], xmm7
000071409bfdceeb  vmovaps [rsp+0x80], xmm8
000071409bfdcef4  vmovaps [rsp+0x90], xmm10
000071409bfdcefd  vmovaps [rsp+0xA0], xmm11
000071409bfdcf06  vmovaps [rsp+0xB0], xmm12
000071409bfdcf0f  vmovaps [rsp+0xC0], xmm13
000071409bfdcf18  vmovaps [rsp+0xD0], xmm14
000071409bfdcf21  vmovaps [rsp+0xE0], xmm15
000071409bfdcf2a  sub rsp, 0x40
000071409bfdcf2e  lea rdi, [rsp]
000071409bfdcf32  lea rsi, [rsp+0x10]
000071409bfdcf37  lea rdx, [rsp+0x20]
000071409bfdcf3c  lea rcx, [rsp+0x30]
000071409bfdcf41  mov r8d, 0x00
000071409bfdcf47  lea r9, [r15+0x3A8]
000071409bfdcf4e  movaps [rdi], xmm9
000071409bfdcf52  movaps [rsi], xmm7
000071409bfdcf55  movaps [rdx], xmm14
000071409bfdcf59  movaps [rcx], xmm13
000071409bfdcf5d  mov rax, 0x6219BEBC2A50
000071409bfdcf67  call rax
000071409bfdcf69  movaps xmm9, [rsp]
000071409bfdcf6e  add rsp, 0x40
000071409bfdcf72  vmovaps xmm0, [rsp]
000071409bfdcf77  vmovaps xmm1, [rsp+0x10]
000071409bfdcf7d  vmovaps xmm2, [rsp+0x20]
000071409bfdcf83  vmovaps xmm3, [rsp+0x30]
000071409bfdcf89  vmovaps xmm4, [rsp+0x40]
000071409bfdcf8f  vmovaps xmm5, [rsp+0x50]
000071409bfdcf95  vmovaps xmm6, [rsp+0x60]
000071409bfdcf9b  vmovaps xmm7, [rsp+0x70]
000071409bfdcfa1  vmovaps xmm8, [rsp+0x80]
000071409bfdcfaa  vmovaps xmm10, [rsp+0x90]
000071409bfdcfb3  vmovaps xmm11, [rsp+0xA0]
000071409bfdcfbc  vmovaps xmm12, [rsp+0xB0]
000071409bfdcfc5  vmovaps xmm13, [rsp+0xC0]
000071409bfdcfce  vmovaps xmm14, [rsp+0xD0]
000071409bfdcfd7  vmovaps xmm15, [rsp+0xE0]
000071409bfdcfe0  add rsp, 0xF0
000071409bfdcfe7  pop r11
000071409bfdcfe9  pop r10
000071409bfdcfeb  pop r9
000071409bfdcfed  pop r8
000071409bfdcfef  pop rsi
000071409bfdcff0  pop rdi
000071409bfdcff1  pop rdx
000071409bfdcff2  pop rcx
000071409bfdcff3  pop rax
000071409bfdcff4  add rsp, 0x08
000071409bfdcff8  jmp 0x000071409BFDA5DA
000071409bfdcffd  sub rsp, 0x08
000071409bfdd001  push rax
000071409bfdd002  push rcx
000071409bfdd003  push rdx
000071409bfdd004  push rdi
000071409bfdd005  push rsi
000071409bfdd006  push r8
000071409bfdd008  push r9
000071409bfdd00a  push r10
000071409bfdd00c  push r11
000071409bfdd00e  sub rsp, 0xF0
000071409bfdd015  vmovaps [rsp], xmm0
000071409bfdd01a  vmovaps [rsp+0x10], xmm1
000071409bfdd020  vmovaps [rsp+0x20], xmm2
000071409bfdd026  vmovaps [rsp+0x30], xmm3
000071409bfdd02c  vmovaps [rsp+0x40], xmm4
000071409bfdd032  vmovaps [rsp+0x50], xmm5
000071409bfdd038  vmovaps [rsp+0x60], xmm6
000071409bfdd03e  vmovaps [rsp+0x70], xmm7
000071409bfdd044  vmovaps [rsp+0x80], xmm8
000071409bfdd04d  vmovaps [rsp+0x90], xmm9
000071409bfdd056  vmovaps [rsp+0xA0], xmm10
000071409bfdd05f  vmovaps [rsp+0xB0], xmm11
000071409bfdd068  vmovaps [rsp+0xC0], xmm12
000071409bfdd071  vmovaps [rsp+0xD0], xmm14
000071409bfdd07a  vmovaps [rsp+0xE0], xmm15
000071409bfdd083  sub rsp, 0x40
000071409bfdd087  lea rdi, [rsp]
000071409bfdd08b  lea rsi, [rsp+0x10]
000071409bfdd090  lea rdx, [rsp+0x20]
000071409bfdd095  lea rcx, [rsp+0x30]
000071409bfdd09a  mov r8d, 0x00
000071409bfdd0a0  lea r9, [r15+0x3A8]
000071409bfdd0a7  movaps [rdi], xmm13
000071409bfdd0ab  movaps [rsi], xmm12
000071409bfdd0af  movaps [rdx], xmm15
000071409bfdd0b3  movaps [rcx], xmm14
000071409bfdd0b7  mov rax, 0x6219BEBC2A50
000071409bfdd0c1  call rax
000071409bfdd0c3  movaps xmm13, [rsp]
000071409bfdd0c8  add rsp, 0x40
000071409bfdd0cc  vmovaps xmm0, [rsp]
000071409bfdd0d1  vmovaps xmm1, [rsp+0x10]
000071409bfdd0d7  vmovaps xmm2, [rsp+0x20]
000071409bfdd0dd  vmovaps xmm3, [rsp+0x30]
000071409bfdd0e3  vmovaps xmm4, [rsp+0x40]
000071409bfdd0e9  vmovaps xmm5, [rsp+0x50]
000071409bfdd0ef  vmovaps xmm6, [rsp+0x60]
000071409bfdd0f5  vmovaps xmm7, [rsp+0x70]
000071409bfdd0fb  vmovaps xmm8, [rsp+0x80]
000071409bfdd104  vmovaps xmm9, [rsp+0x90]
000071409bfdd10d  vmovaps xmm10, [rsp+0xA0]
000071409bfdd116  vmovaps xmm11, [rsp+0xB0]
000071409bfdd11f  vmovaps xmm12, [rsp+0xC0]
000071409bfdd128  vmovaps xmm14, [rsp+0xD0]
000071409bfdd131  vmovaps xmm15, [rsp+0xE0]
000071409bfdd13a  add rsp, 0xF0
000071409bfdd141  pop r11
000071409bfdd143  pop r10
000071409bfdd145  pop r9
000071409bfdd147  pop r8
000071409bfdd149  pop rsi
000071409bfdd14a  pop rdi
000071409bfdd14b  pop rdx
000071409bfdd14c  pop rcx
000071409bfdd14d  pop rax
000071409bfdd14e  add rsp, 0x08
000071409bfdd152  jmp 0x000071409BFDA608
000071409bfdd157  sub rsp, 0x08
000071409bfdd15b  push rax
000071409bfdd15c  push rcx
000071409bfdd15d  push rdx
000071409bfdd15e  push rdi
000071409bfdd15f  push rsi
000071409bfdd160  push r8
000071409bfdd162  push r9
000071409bfdd164  push r10
000071409bfdd166  push r11
000071409bfdd168  sub rsp, 0xF0
000071409bfdd16f  vmovaps [rsp], xmm0
000071409bfdd174  vmovaps [rsp+0x10], xmm1
000071409bfdd17a  vmovaps [rsp+0x20], xmm2
000071409bfdd180  vmovaps [rsp+0x30], xmm3
000071409bfdd186  vmovaps [rsp+0x40], xmm4
000071409bfdd18c  vmovaps [rsp+0x50], xmm5
000071409bfdd192  vmovaps [rsp+0x60], xmm6
000071409bfdd198  vmovaps [rsp+0x70], xmm7
000071409bfdd19e  vmovaps [rsp+0x80], xmm8
000071409bfdd1a7  vmovaps [rsp+0x90], xmm9
000071409bfdd1b0  vmovaps [rsp+0xA0], xmm10
000071409bfdd1b9  vmovaps [rsp+0xB0], xmm11
000071409bfdd1c2  vmovaps [rsp+0xC0], xmm12
000071409bfdd1cb  vmovaps [rsp+0xD0], xmm13
000071409bfdd1d4  vmovaps [rsp+0xE0], xmm15
000071409bfdd1dd  sub rsp, 0x40
000071409bfdd1e1  lea rdi, [rsp]
000071409bfdd1e5  lea rsi, [rsp+0x10]
000071409bfdd1ea  lea rdx, [rsp+0x20]
000071409bfdd1ef  lea rcx, [rsp+0x30]
000071409bfdd1f4  mov r8d, 0x00
000071409bfdd1fa  lea r9, [r15+0x3A8]
000071409bfdd201  movaps [rdi], xmm14
000071409bfdd205  movaps [rsi], xmm11
000071409bfdd209  movaps [rdx], xmm1
000071409bfdd20c  movaps [rcx], xmm15
000071409bfdd210  mov rax, 0x6219BEBC2A50
000071409bfdd21a  call rax
000071409bfdd21c  movaps xmm14, [rsp]
000071409bfdd221  add rsp, 0x40
000071409bfdd225  vmovaps xmm0, [rsp]
000071409bfdd22a  vmovaps xmm1, [rsp+0x10]
000071409bfdd230  vmovaps xmm2, [rsp+0x20]
000071409bfdd236  vmovaps xmm3, [rsp+0x30]
000071409bfdd23c  vmovaps xmm4, [rsp+0x40]
000071409bfdd242  vmovaps xmm5, [rsp+0x50]
000071409bfdd248  vmovaps xmm6, [rsp+0x60]
000071409bfdd24e  vmovaps xmm7, [rsp+0x70]
000071409bfdd254  vmovaps xmm8, [rsp+0x80]
000071409bfdd25d  vmovaps xmm9, [rsp+0x90]
000071409bfdd266  vmovaps xmm10, [rsp+0xA0]
000071409bfdd26f  vmovaps xmm11, [rsp+0xB0]
000071409bfdd278  vmovaps xmm12, [rsp+0xC0]
000071409bfdd281  vmovaps xmm13, [rsp+0xD0]
000071409bfdd28a  vmovaps xmm15, [rsp+0xE0]
000071409bfdd293  add rsp, 0xF0
000071409bfdd29a  pop r11
000071409bfdd29c  pop r10
000071409bfdd29e  pop r9
000071409bfdd2a0  pop r8
000071409bfdd2a2  pop rsi
000071409bfdd2a3  pop rdi
000071409bfdd2a4  pop rdx
000071409bfdd2a5  pop rcx
000071409bfdd2a6  pop rax
000071409bfdd2a7  add rsp, 0x08
000071409bfdd2ab  jmp 0x000071409BFDA636
000071409bfdd2b0  call 0x000071409BE079B0
000071409bfdd2b5  jmp 0x000071409BFDA64C
000071409bfdd2ba  call 0x000071409BEE3440
000071409bfdd2bf  jmp 0x000071409BFDA656
000071409bfdd2c4  call 0x000071409BEDFCE0
000071409bfdd2c9  jmp 0x000071409BFDA660
000071409bfdd2ce  call 0x000071409BEE46C0
000071409bfdd2d3  jmp 0x000071409BFDA66A
000071409bfdd2d8  int3
000071409bfdd2d9  nop [rax], eax
000071409bfdd2e0  mov qword ptr [r15+0x40], 0x430000
000071409bfdd2e8  mov eax, 0x430C50
000071409bfdd2ed  mov r14, [r13+rax*1]
000071409bfdd2f2  movq xmm1, r14
000071409bfdd2f7  mov rax, [r15+0x50]
000071409bfdd2fb  movups xmm15, [r13+rax*1]
000071409bfdd301  movaps [r15+0x120], xmm15
000071409bfdd309  mov qword ptr [r15+0x48], 0x10
000071409bfdd311  xor eax, eax
000071409bfdd313  mov r14d, 0x10
000071409bfdd319  mov r12d, 0x200
000071409bfdd31f  cmp r14, r12
000071409bfdd322  cmc
000071409bfdd323  lahf
000071409bfdd324  seto al
000071409bfdd327  mov [r15+0x108], eax
000071409bfdd32e  pextrq rax, xmm15, 0x01
000071409bfdd335  movq xmm14, rax
000071409bfdd33a  movaps [r15+0x130], xmm14
000071409bfdd342  movq rax, xmm1
000071409bfdd347  movq r14, xmm15
000071409bfdd34c  vmovq xmm1, rax
000071409bfdd351  vmovq xmm15, r14
000071409bfdd356  movaps xmm13, xmm1
000071409bfdd35a  addsd xmm13, xmm15
000071409bfdd35f  ucomisd xmm13, xmm13
000071409bfdd364  jp 0x000071409BFDD423
000071409bfdd36a  movq xmm13, xmm13
000071409bfdd36f  movq rax, xmm13
000071409bfdd374  movq r14, xmm14
000071409bfdd379  vmovq xmm1, rax
000071409bfdd37e  vmovq xmm15, r14
000071409bfdd383  movaps xmm14, xmm1
000071409bfdd387  addsd xmm14, xmm15
000071409bfdd38c  ucomisd xmm14, xmm14
000071409bfdd391  jp 0x000071409BFDD46B
000071409bfdd397  movq xmm14, xmm14
000071409bfdd39c  movaps [r15+0x110], xmm14
000071409bfdd3a4  mov eax, [r15+0x108]
000071409bfdd3ab  sahf
000071409bfdd3ac  jnz 0x000071409BFDD3DE
000071409bfdd3ae  cmp dword ptr [r15+0x318], 0x00
000071409bfdd3b6  jz 0x000071409BFDD680
000071409bfdd3bc  nop [rax+rax*1], ax
000071409bfdd3c5  nop [rax+rax*1], eax
000071409bfdd3cd  mov eax, 0x410698
000071409bfdd3d2  mov [r15+0x100], rax
000071409bfdd3d9  jmp 0x000071409BDFE110
000071409bfdd3de  cmp dword ptr [r15+0x318], 0x00
000071409bfdd3e6  jz 0x000071409BFDD4C0
000071409bfdd3ec  nop [rax+rax*1], ax
000071409bfdd3f5  nop [rax+rax*1], eax
000071409bfdd3fd  mov eax, 0x41067C
000071409bfdd402  mov [r15+0x100], rax
000071409bfdd409  jmp 0x000071409BDFE110
000071409bfdd40e  int3
000071409bfdd40f  call 0x000071409BE0DC20
000071409bfdd414  jmp 0x000071409BFDD2F2
000071409bfdd419  call 0x000071409BE0E760
000071409bfdd41e  jmp 0x000071409BFDD301
000071409bfdd423  ucomisd xmm1, xmm15
000071409bfdd428  jp 0x000071409BFDD437
000071409bfdd42a  movaps xmm13, [0x000071409BBFE060]
000071409bfdd432  jmp 0x000071409BFDD36A
000071409bfdd437  vxorps xmm0, xmm1, xmm15
000071409bfdd43c  pextrw eax, xmm0, 0x03
000071409bfdd441  and eax, 0x7FF8
000071409bfdd446  cmp eax, 0x08
000071409bfdd449  jnz 0x000071409BFDD36A
000071409bfdd44f  movq rax, xmm15
000071409bfdd454  shl rax, 0x0D
000071409bfdd458  jbe 0x000071409BFDD36A
000071409bfdd45e  vorps xmm13, xmm15, [0x000071409BBFE070]
000071409bfdd466  jmp 0x000071409BFDD36A
000071409bfdd46b  ucomisd xmm1, xmm15
000071409bfdd470  jp 0x000071409BFDD47F
000071409bfdd472  movaps xmm14, [0x000071409BBFE060]
000071409bfdd47a  jmp 0x000071409BFDD397
000071409bfdd47f  vxorps xmm0, xmm1, xmm15
000071409bfdd484  pextrw eax, xmm0, 0x03
000071409bfdd489  and eax, 0x7FF8
000071409bfdd48e  cmp eax, 0x08
000071409bfdd491  jnz 0x000071409BFDD397
000071409bfdd497  movq rax, xmm15
000071409bfdd49c  shl rax, 0x0D
000071409bfdd4a0  jbe 0x000071409BFDD397
000071409bfdd4a6  vorps xmm14, xmm15, [0x000071409BBFE070]
000071409bfdd4ae  jmp 0x000071409BFDD397
000071409bfdd4b3  int3
000071409bfdd4b4  nop [rax+rax*1], ax
000071409bfdd4bd  nop [rax], eax
000071409bfdd4c0  mov rax, [r15+0x48]
000071409bfdd4c4  mov r14, [r15+0x50]
000071409bfdd4c8  lea r12, [r14+rax*1]
000071409bfdd4cc  movups xmm1, [r13+r12*1]
000071409bfdd4d2  movaps [r15+0x120], xmm1
000071409bfdd4da  lea r14, [rax+0x10]
000071409bfdd4de  mov [r15+0x48], r14
000071409bfdd4e2  xor eax, eax
000071409bfdd4e4  mov r12d, 0x200
000071409bfdd4ea  cmp r14, r12
000071409bfdd4ed  cmc
000071409bfdd4ee  lahf
000071409bfdd4ef  seto al
000071409bfdd4f2  mov [r15+0x108], eax
000071409bfdd4f9  pextrq rax, xmm1, 0x01
000071409bfdd500  movq xmm15, rax
000071409bfdd505  movaps [r15+0x130], xmm15
000071409bfdd50d  movaps xmm14, [r15+0x110]
000071409bfdd515  movq rax, xmm14
000071409bfdd51a  movq r14, xmm1
000071409bfdd51f  vmovq xmm1, rax
000071409bfdd524  vmovq xmm14, r14
000071409bfdd529  movaps xmm13, xmm1
000071409bfdd52d  addsd xmm13, xmm14
000071409bfdd532  ucomisd xmm13, xmm13
000071409bfdd537  jp 0x000071409BFDD5EC
000071409bfdd53d  movq xmm13, xmm13
000071409bfdd542  movq rax, xmm13
000071409bfdd547  movq r14, xmm15
000071409bfdd54c  vmovq xmm1, rax
000071409bfdd551  vmovq xmm15, r14
000071409bfdd556  movaps xmm14, xmm1
000071409bfdd55a  addsd xmm14, xmm15
000071409bfdd55f  ucomisd xmm14, xmm14
000071409bfdd564  jp 0x000071409BFDD634
000071409bfdd56a  movq xmm14, xmm14
000071409bfdd56f  movaps [r15+0x110], xmm14
000071409bfdd577  mov eax, [r15+0x108]
000071409bfdd57e  sahf
000071409bfdd57f  jnz 0x000071409BFDD5B1
000071409bfdd581  cmp dword ptr [r15+0x318], 0x00
000071409bfdd589  jz 0x000071409BFDD680
000071409bfdd58f  nop [rax+rax*1], ax
000071409bfdd598  nop [rax+rax*1], eax
000071409bfdd5a0  mov eax, 0x410698
000071409bfdd5a5  mov [r15+0x100], rax
000071409bfdd5ac  jmp 0x000071409BDFE110
000071409bfdd5b1  cmp dword ptr [r15+0x318], 0x00
000071409bfdd5b9  jz 0x000071409BFDD4C0
000071409bfdd5bf  nop [rax+rax*1], ax
000071409bfdd5c8  nop [rax+rax*1], eax
000071409bfdd5d0  mov eax, 0x41067C
000071409bfdd5d5  mov [r15+0x100], rax
000071409bfdd5dc  jmp 0x000071409BDFE110
000071409bfdd5e1  int3
000071409bfdd5e2  call 0x000071409BEB52F0
000071409bfdd5e7  jmp 0x000071409BFDD4D2
000071409bfdd5ec  ucomisd xmm1, xmm14
000071409bfdd5f1  jp 0x000071409BFDD600
000071409bfdd5f3  movaps xmm13, [0x000071409BBFE060]
000071409bfdd5fb  jmp 0x000071409BFDD53D
000071409bfdd600  vxorps xmm0, xmm1, xmm14
000071409bfdd605  pextrw eax, xmm0, 0x03
000071409bfdd60a  and eax, 0x7FF8
000071409bfdd60f  cmp eax, 0x08
000071409bfdd612  jnz 0x000071409BFDD53D
000071409bfdd618  movq rax, xmm14
000071409bfdd61d  shl rax, 0x0D
000071409bfdd621  jbe 0x000071409BFDD53D
000071409bfdd627  vorps xmm13, xmm14, [0x000071409BBFE070]
000071409bfdd62f  jmp 0x000071409BFDD53D
000071409bfdd634  ucomisd xmm1, xmm15
000071409bfdd639  jp 0x000071409BFDD648
000071409bfdd63b  movaps xmm14, [0x000071409BBFE060]
000071409bfdd643  jmp 0x000071409BFDD56A
000071409bfdd648  vxorps xmm0, xmm1, xmm15
000071409bfdd64d  pextrw eax, xmm0, 0x03
000071409bfdd652  and eax, 0x7FF8
000071409bfdd657  cmp eax, 0x08
000071409bfdd65a  jnz 0x000071409BFDD56A
000071409bfdd660  movq rax, xmm15
000071409bfdd665  shl rax, 0x0D
000071409bfdd669  jbe 0x000071409BFDD56A
000071409bfdd66f  vorps xmm14, xmm15, [0x000071409BBFE070]
000071409bfdd677  jmp 0x000071409BFDD56A
000071409bfdd67c  int3
000071409bfdd67d  nop [rax], eax
000071409bfdd680  mov rax, [r15+0xF8]
000071409bfdd687  lea r14, [rax+0x1A0]
000071409bfdd68e  mov r12, [r13+r14*1]
000071409bfdd693  lea r14, [rax+0x1A8]
000071409bfdd69a  mov r11, [r13+r14*1]
000071409bfdd69f  mov [r15+0xA0], r12
000071409bfdd6a6  mov [r15+0x98], r11
000071409bfdd6ad  mov r14, [r15+0x40]
000071409bfdd6b1  lea r12, [r14+0xC50]
000071409bfdd6b8  movaps xmm1, [r15+0x110]
000071409bfdd6c0  movq r14, xmm1
000071409bfdd6c5  mov [r13+r12*1], r14
000071409bfdd6ca  lea r14, [rax+0x190]
000071409bfdd6d1  mov r12, [r13+r14*1]
000071409bfdd6d6  lea r14, [rax+0x198]
000071409bfdd6dd  mov r11, [r13+r14*1]
000071409bfdd6e2  mov [r15+0xE8], r12
000071409bfdd6e9  mov [r15+0xF0], r11
000071409bfdd6f0  lea r14, [rax+0x180]
000071409bfdd6f7  mov r12, [r13+r14*1]
000071409bfdd6fc  lea r14, [rax+0x188]
000071409bfdd703  mov r10, [r13+r14*1]
000071409bfdd708  movq xmm1, r12
000071409bfdd70d  movq xmm15, r10
000071409bfdd712  movq xmm1, xmm1
000071409bfdd716  movq xmm1, xmm1
000071409bfdd71a  movaps [r15+0x1A0], xmm1
000071409bfdd722  movq xmm15, xmm15
000071409bfdd727  movq xmm15, xmm15
000071409bfdd72c  movaps [r15+0x190], xmm15
000071409bfdd734  lea r14, [rax+0x170]
000071409bfdd73b  mov r12, [r13+r14*1]
000071409bfdd740  lea r14, [rax+0x178]
000071409bfdd747  mov r10, [r13+r14*1]
000071409bfdd74c  movq xmm1, r12
000071409bfdd751  movq xmm15, r10
000071409bfdd756  movq xmm1, xmm1
000071409bfdd75a  movq xmm1, xmm1
000071409bfdd75e  movaps [r15+0x1C0], xmm1
000071409bfdd766  movq xmm15, xmm15
000071409bfdd76b  movq xmm15, xmm15
000071409bfdd770  movaps [r15+0x1B0], xmm15
000071409bfdd778  lea r14, [rax+0x160]
000071409bfdd77f  mov r12, [r13+r14*1]
000071409bfdd784  lea r14, [rax+0x168]
000071409bfdd78b  mov r10, [r13+r14*1]
000071409bfdd790  movq xmm1, r12
000071409bfdd795  movq xmm15, r10
000071409bfdd79a  movq xmm1, xmm1
000071409bfdd79e  movq xmm1, xmm1
000071409bfdd7a2  movaps [r15+0x1E0], xmm1
000071409bfdd7aa  movq xmm15, xmm15
000071409bfdd7af  movq xmm15, xmm15
000071409bfdd7b4  movaps [r15+0x1D0], xmm15
000071409bfdd7bc  lea r14, [rax+0x150]
000071409bfdd7c3  mov r12, [r13+r14*1]
000071409bfdd7c8  lea r14, [rax+0x158]
000071409bfdd7cf  mov r10, [r13+r14*1]
000071409bfdd7d4  movq xmm1, r12
000071409bfdd7d9  movq xmm15, r10
000071409bfdd7de  movq xmm1, xmm1
000071409bfdd7e2  movq xmm1, xmm1
000071409bfdd7e6  movaps [r15+0x200], xmm1
000071409bfdd7ee  movq xmm15, xmm15
000071409bfdd7f3  movq xmm15, xmm15
000071409bfdd7f8  movaps [r15+0x1F0], xmm15
000071409bfdd800  lea r14, [rax+0x1B0]
000071409bfdd807  mov [r15+0xF8], r14
000071409bfdd80e  mov [r15+0x100], r11
000071409bfdd815  jmp 0x000071409BFCE5C0
000071409bfdd81a  int3
000071409bfdd81b  call 0x000071409BEE27E0
000071409bfdd820  jmp 0x000071409BFDD693
000071409bfdd825  call 0x000071409BEE1570
000071409bfdd82a  jmp 0x000071409BFDD69F
000071409bfdd82f  call 0x000071409BEC3FE0
000071409bfdd834  jmp 0x000071409BFDD6CA
000071409bfdd839  call 0x000071409BEE27E0
000071409bfdd83e  jmp 0x000071409BFDD6D6
000071409bfdd843  call 0x000071409BEE1570
000071409bfdd848  jmp 0x000071409BFDD6E2
000071409bfdd84d  call 0x000071409BEE27E0
000071409bfdd852  jmp 0x000071409BFDD6FC
000071409bfdd857  call 0x000071409BEE0300
000071409bfdd85c  jmp 0x000071409BFDD708
000071409bfdd861  call 0x000071409BEE27E0
000071409bfdd866  jmp 0x000071409BFDD740
000071409bfdd86b  call 0x000071409BEE0300
000071409bfdd870  jmp 0x000071409BFDD74C
000071409bfdd875  call 0x000071409BEE27E0
000071409bfdd87a  jmp 0x000071409BFDD784
000071409bfdd87f  call 0x000071409BEE0300
000071409bfdd884  jmp 0x000071409BFDD790
000071409bfdd889  call 0x000071409BEE27E0
000071409bfdd88e  jmp 0x000071409BFDD7C8
000071409bfdd893  call 0x000071409BEE0300
000071409bfdd898  jmp 0x000071409BFDD7D4
000071409bfdd89d  int3
000071409bfdd89e  nop
000071409bfdd8a0  mov qword ptr [r15+0x100], 0x04
000071409bfdd8ab  mov esi, 0x00
000071409bfdd8b0  mov edx, 0x09
000071409bfdd8b5  mov rdi, 0x7FFF8974AFF0
000071409bfdd8bf  mov rax, 0x6219BEA55970
000071409bfdd8c9  call rax
000071409bfdd8cb  cmp dword ptr [r15+0x318], 0x00
000071409bfdd8d3  jnz 0x000071409BDFE110
000071409bfdd8d9  jmp 0x000071409BDFE0A0
000071409bfdd8de  int3
000071409bfdd8df  int3
