0000782c7ffce69b  nop [rax+rax*1], eax
0000782c7ffce6a0  mov rax, [r15+0xF8]
0000782c7ffce6a7  lea r14, [rax-0x1B0]
0000782c7ffce6ae  mov [r15+0xF8], r14
0000782c7ffce6b5  lea rax, [r14+0x1A0]
0000782c7ffce6bc  mov r12, [r15+0xA0]
0000782c7ffce6c3  mov r11, [r15+0x98]
0000782c7ffce6ca  mov [r13+rax*1], r12
0000782c7ffce6cf  lea rax, [r14+0x1A8]
0000782c7ffce6d6  mov [r13+rax*1], r11
0000782c7ffce6db  mov eax, 0x420A30
0000782c7ffce6e0  movups xmm1, [r13+rax*1]
0000782c7ffce6e6  mov eax, 0x4209C0
0000782c7ffce6eb  movups xmm15, [r13+rax*1]
0000782c7ffce6f1  mov eax, 0x420A50
0000782c7ffce6f6  movups xmm14, [r13+rax*1]
0000782c7ffce6fc  mov eax, 0x4209F0
0000782c7ffce701  movups xmm13, [r13+rax*1]
0000782c7ffce707  mov qword ptr [r15+0x98], 0x430C60
0000782c7ffce712  mov eax, 0x420A60
0000782c7ffce717  movups xmm12, [r13+rax*1]
0000782c7ffce71d  mov eax, 0x430C60
0000782c7ffce722  movups [r13+rax*1], xmm1
0000782c7ffce728  mov eax, 0x430C70
0000782c7ffce72d  movups [r13+rax*1], xmm15
0000782c7ffce733  mov eax, 0x430C80
0000782c7ffce738  movups [r13+rax*1], xmm14
0000782c7ffce73e  mov eax, 0x430C90
0000782c7ffce743  movups [r13+rax*1], xmm13
0000782c7ffce749  mov eax, 0x4209B0
0000782c7ffce74e  movups xmm14, [r13+rax*1]
0000782c7ffce754  mov eax, 0x4209A0
0000782c7ffce759  movups xmm13, [r13+rax*1]
0000782c7ffce75f  mov eax, 0x430D60
0000782c7ffce764  movups [r13+rax*1], xmm1
0000782c7ffce76a  mov eax, 0x430D70
0000782c7ffce76f  movups [r13+rax*1], xmm15
0000782c7ffce775  mov eax, 0x430CA0
0000782c7ffce77a  movups [r13+rax*1], xmm12
0000782c7ffce780  mov eax, 0x430CB0
0000782c7ffce785  movups [r13+rax*1], xmm14
0000782c7ffce78b  mov eax, 0x420990
0000782c7ffce790  movups xmm1, [r13+rax*1]
0000782c7ffce796  mov eax, 0x420A00
0000782c7ffce79b  movups xmm15, [r13+rax*1]
0000782c7ffce7a1  mov eax, 0x430CC0
0000782c7ffce7a6  movups [r13+rax*1], xmm13
0000782c7ffce7ac  mov eax, 0x430CD0
0000782c7ffce7b1  movups [r13+rax*1], xmm1
0000782c7ffce7b7  mov eax, 0x420A10
0000782c7ffce7bc  movups xmm1, [r13+rax*1]
0000782c7ffce7c2  mov eax, 0x4209E0
0000782c7ffce7c7  movups xmm14, [r13+rax*1]
0000782c7ffce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000782c7ffce7d5  mov eax, 0x430CE0
0000782c7ffce7da  movups [r13+rax*1], xmm15
0000782c7ffce7e0  mov eax, 0x430CF0
0000782c7ffce7e5  movups [r13+rax*1], xmm1
0000782c7ffce7eb  mov eax, 0x420A80
0000782c7ffce7f0  movups xmm1, [r13+rax*1]
0000782c7ffce7f6  mov eax, 0x420A90
0000782c7ffce7fb  movups xmm15, [r13+rax*1]
0000782c7ffce801  movaps [r15+0x150], xmm15
0000782c7ffce809  mov qword ptr [r15+0xA0], 0x3E8
0000782c7ffce814  mov eax, 0x430D00
0000782c7ffce819  movups [r13+rax*1], xmm14
0000782c7ffce81f  mov eax, 0x430D10
0000782c7ffce824  movups [r13+rax*1], xmm1
0000782c7ffce82a  mov eax, 0x420A70
0000782c7ffce82f  movups xmm1, [r13+rax*1]
0000782c7ffce835  mov eax, 0x420A20
0000782c7ffce83a  movups xmm14, [r13+rax*1]
0000782c7ffce840  movaps [r15+0x140], xmm14
0000782c7ffce848  lea rax, [r14+0x150]
0000782c7ffce84f  movq xmm13, qword ptr [r15+0x200]
0000782c7ffce858  movq xmm12, qword ptr [r15+0x1F0]
0000782c7ffce861  movq r12, xmm13
0000782c7ffce866  movq r11, xmm12
0000782c7ffce86b  mov [r13+rax*1], r12
0000782c7ffce870  lea rax, [r14+0x158]
0000782c7ffce877  mov [r13+rax*1], r11
0000782c7ffce87c  mov eax, 0x430D20
0000782c7ffce881  movups [r13+rax*1], xmm15
0000782c7ffce887  mov eax, 0x430D30
0000782c7ffce88c  movups [r13+rax*1], xmm1
0000782c7ffce892  mov eax, 0x420A40
0000782c7ffce897  movups xmm1, [r13+rax*1]
0000782c7ffce89d  mov eax, 0x420AA8
0000782c7ffce8a2  mov r12, [r13+rax*1]
0000782c7ffce8a7  movq xmm15, r12
0000782c7ffce8ac  mov qword ptr [r15+0x40], 0x420AB0
0000782c7ffce8b4  mov eax, 0x430D40
0000782c7ffce8b9  movups [r13+rax*1], xmm14
0000782c7ffce8bf  mov eax, 0x430D50
0000782c7ffce8c4  movups [r13+rax*1], xmm1
0000782c7ffce8ca  mov eax, 0x420B10
0000782c7ffce8cf  movups xmm1, [r13+rax*1]
0000782c7ffce8d5  movq rax, xmm15
0000782c7ffce8da  mov r12d, 0x430D80
0000782c7ffce8e0  mov [r13+r12*1], rax
0000782c7ffce8e5  mov eax, 0x420AF0
0000782c7ffce8ea  movups xmm15, [r13+rax*1]
0000782c7ffce8f0  mov eax, 0x420B00
0000782c7ffce8f5  movups xmm14, [r13+rax*1]
0000782c7ffce8fb  lea rax, [r14+0x130]
0000782c7ffce902  movups [r13+rax*1], xmm1
0000782c7ffce908  lea rax, [r14+0x160]
0000782c7ffce90f  movq xmm1, qword ptr [r15+0x1E0]
0000782c7ffce918  movq xmm13, qword ptr [r15+0x1D0]
0000782c7ffce921  movq r12, xmm1
0000782c7ffce926  movq r11, xmm13
0000782c7ffce92b  mov [r13+rax*1], r12
0000782c7ffce930  lea rax, [r14+0x168]
0000782c7ffce937  mov [r13+rax*1], r11
0000782c7ffce93c  lea rax, [r14+0x110]
0000782c7ffce943  movups [r13+rax*1], xmm15
0000782c7ffce949  lea rax, [r14+0x120]
0000782c7ffce950  movups [r13+rax*1], xmm14
0000782c7ffce956  mov eax, 0x420AB0
0000782c7ffce95b  movups xmm1, [r13+rax*1]
0000782c7ffce961  mov eax, 0x420AC0
0000782c7ffce966  movups xmm15, [r13+rax*1]
0000782c7ffce96c  movaps [r15+0x120], xmm15
0000782c7ffce974  lea rax, [r14+0x170]
0000782c7ffce97b  movq xmm14, qword ptr [r15+0x1C0]
0000782c7ffce984  movq xmm13, qword ptr [r15+0x1B0]
0000782c7ffce98d  movq r12, xmm14
0000782c7ffce992  movq r11, xmm13
0000782c7ffce997  mov [r13+rax*1], r12
0000782c7ffce99c  lea rax, [r14+0x178]
0000782c7ffce9a3  mov [r13+rax*1], r11
0000782c7ffce9a8  lea rax, [r14+0x180]
0000782c7ffce9af  movq xmm14, qword ptr [r15+0x1A0]
0000782c7ffce9b8  movq xmm13, qword ptr [r15+0x190]
0000782c7ffce9c1  movq r12, xmm14
0000782c7ffce9c6  movq r11, xmm13
0000782c7ffce9cb  mov [r13+rax*1], r12
0000782c7ffce9d0  lea rax, [r14+0x188]
0000782c7ffce9d7  mov [r13+rax*1], r11
0000782c7ffce9dc  lea rax, [r14+0xD0]
0000782c7ffce9e3  movups [r13+rax*1], xmm1
0000782c7ffce9e9  lea rax, [r14+0xE0]
0000782c7ffce9f0  movups [r13+rax*1], xmm15
0000782c7ffce9f6  mov eax, 0x420AD0
0000782c7ffce9fb  movups xmm1, [r13+rax*1]
0000782c7ffcea01  mov eax, 0x420AE0
0000782c7ffcea06  movups xmm15, [r13+rax*1]
0000782c7ffcea0c  movaps [r15+0x110], xmm1
0000782c7ffcea14  movaps [r15+0x130], xmm15
0000782c7ffcea1c  lea rax, [r14+0x190]
0000782c7ffcea23  mov r12, [r15+0xE8]
0000782c7ffcea2a  mov r11, [r15+0xF0]
0000782c7ffcea31  mov [r13+rax*1], r12
0000782c7ffcea36  lea rax, [r14+0x198]
0000782c7ffcea3d  mov [r13+rax*1], r11
0000782c7ffcea42  mov eax, 0x430D88
0000782c7ffcea47  mov r12d, 0x421DF8D3
0000782c7ffcea4d  mov [r13+rax*1], r12d
0000782c7ffcea52  lea rax, [r14+0xF0]
0000782c7ffcea59  movups [r13+rax*1], xmm1
0000782c7ffcea5f  lea rax, [r14+0x100]
0000782c7ffcea66  movups [r13+rax*1], xmm15
0000782c7ffcea6c  lea rax, [r14+0xD0]
0000782c7ffcea73  mov [r15], rax
0000782c7ffcea76  mov qword ptr [r15+0x08], 0x430C60
0000782c7ffcea7e  mov qword ptr [r15+0x10], 0x12C
0000782c7ffcea86  mov qword ptr [r15+0xF0], 0x410284
0000782c7ffcea91  mov r14d, [r15+0x320]
0000782c7ffcea98  mov eax, 0x410284
0000782c7ffcea9d  mov rcx, 0x782C7FFD07C0
0000782c7ffceaa7  mov [r15+r14*8+0x328], rax
0000782c7ffceaaf  mov [r15+r14*8+0x368], rcx
0000782c7ffceab7  add r14d, 0x01
0000782c7ffceabb  and r14d, 0x07
0000782c7ffceabf  mov [r15+0x320], r14d
0000782c7ffceac6  cmp dword ptr [r15+0x318], 0x00
0000782c7ffceace  jz 0x0000782C7FFCED70
0000782c7ffcead4  nop [rax+rax*1], ax
0000782c7ffceadd  nop [rax+rax*1], eax
0000782c7ffceae5  mov eax, 0x4106BC
0000782c7ffceaea  mov [r15+0x100], rax
0000782c7ffceaf1  jmp 0x0000782C7FDFE110
0000782c7ffceaf6  int3
0000782c7ffceaf7  call 0x0000782C7FE0BC20
0000782c7ffceafc  jmp 0x0000782C7FFCE6CF
0000782c7ffceb01  call 0x0000782C7FE0A9A0
0000782c7ffceb06  jmp 0x0000782C7FFCE6DB
0000782c7ffceb0b  call 0x0000782C7FDFF430
0000782c7ffceb10  jmp 0x0000782C7FFCE6E6
0000782c7ffceb15  call 0x0000782C7FE0E760
0000782c7ffceb1a  jmp 0x0000782C7FFCE6F1
0000782c7ffceb1f  call 0x0000782C7FE0D4E0
0000782c7ffceb24  jmp 0x0000782C7FFCE6FC
0000782c7ffceb29  call 0x0000782C7FE0C260
0000782c7ffceb2e  jmp 0x0000782C7FFCE707
0000782c7ffceb33  call 0x0000782C7FE0AFE0
0000782c7ffceb38  jmp 0x0000782C7FFCE71D
0000782c7ffceb3d  call 0x0000782C7FDFF540
0000782c7ffceb42  jmp 0x0000782C7FFCE728
0000782c7ffceb47  call 0x0000782C7FE0E880
0000782c7ffceb4c  jmp 0x0000782C7FFCE733
0000782c7ffceb51  call 0x0000782C7FE0D600
0000782c7ffceb56  jmp 0x0000782C7FFCE73E
0000782c7ffceb5b  call 0x0000782C7FE0C380
0000782c7ffceb60  jmp 0x0000782C7FFCE749
0000782c7ffceb65  call 0x0000782C7FE0D4E0
0000782c7ffceb6a  jmp 0x0000782C7FFCE754
0000782c7ffceb6f  call 0x0000782C7FE0C260
0000782c7ffceb74  jmp 0x0000782C7FFCE75F
0000782c7ffceb79  call 0x0000782C7FDFF540
0000782c7ffceb7e  jmp 0x0000782C7FFCE76A
0000782c7ffceb83  call 0x0000782C7FE0E880
0000782c7ffceb88  jmp 0x0000782C7FFCE775
0000782c7ffceb8d  call 0x0000782C7FE0B100
0000782c7ffceb92  jmp 0x0000782C7FFCE780
0000782c7ffceb97  call 0x0000782C7FE0D600
0000782c7ffceb9c  jmp 0x0000782C7FFCE78B
0000782c7ffceba1  call 0x0000782C7FDFF430
0000782c7ffceba6  jmp 0x0000782C7FFCE796
0000782c7ffcebab  call 0x0000782C7FE0E760
0000782c7ffcebb0  jmp 0x0000782C7FFCE7A1
0000782c7ffcebb5  call 0x0000782C7FE0C380
0000782c7ffcebba  jmp 0x0000782C7FFCE7AC
0000782c7ffcebbf  call 0x0000782C7FDFF540
0000782c7ffcebc4  jmp 0x0000782C7FFCE7B7
0000782c7ffcebc9  call 0x0000782C7FDFF430
0000782c7ffcebce  jmp 0x0000782C7FFCE7C2
0000782c7ffcebd3  call 0x0000782C7FE0D4E0
0000782c7ffcebd8  jmp 0x0000782C7FFCE7CD
0000782c7ffcebdd  call 0x0000782C7FE0E880
0000782c7ffcebe2  jmp 0x0000782C7FFCE7E0
0000782c7ffcebe7  call 0x0000782C7FDFF540
0000782c7ffcebec  jmp 0x0000782C7FFCE7EB
0000782c7ffcebf1  call 0x0000782C7FDFF430
0000782c7ffcebf6  jmp 0x0000782C7FFCE7F6
0000782c7ffcebfb  call 0x0000782C7FE0E760
0000782c7ffcec00  jmp 0x0000782C7FFCE801
0000782c7ffcec05  call 0x0000782C7FE0D600
0000782c7ffcec0a  jmp 0x0000782C7FFCE81F
0000782c7ffcec0f  call 0x0000782C7FDFF540
0000782c7ffcec14  jmp 0x0000782C7FFCE82A
0000782c7ffcec19  call 0x0000782C7FDFF430
0000782c7ffcec1e  jmp 0x0000782C7FFCE835
0000782c7ffcec23  call 0x0000782C7FE0D4E0
0000782c7ffcec28  jmp 0x0000782C7FFCE840
0000782c7ffcec2d  call 0x0000782C7FE0BC20
0000782c7ffcec32  jmp 0x0000782C7FFCE870
0000782c7ffcec37  call 0x0000782C7FE0A9A0
0000782c7ffcec3c  jmp 0x0000782C7FFCE87C
0000782c7ffcec41  call 0x0000782C7FE0E880
0000782c7ffcec46  jmp 0x0000782C7FFCE887
0000782c7ffcec4b  call 0x0000782C7FDFF540
0000782c7ffcec50  jmp 0x0000782C7FFCE892
0000782c7ffcec55  call 0x0000782C7FDFF430
0000782c7ffcec5a  jmp 0x0000782C7FFCE89D
0000782c7ffcec5f  call 0x0000782C7FE0B720
0000782c7ffcec64  jmp 0x0000782C7FFCE8A7
0000782c7ffcec69  call 0x0000782C7FE0D600
0000782c7ffcec6e  jmp 0x0000782C7FFCE8BF
0000782c7ffcec73  call 0x0000782C7FDFF540
0000782c7ffcec78  jmp 0x0000782C7FFCE8CA
0000782c7ffcec7d  call 0x0000782C7FDFF430
0000782c7ffcec82  jmp 0x0000782C7FFCE8D5
0000782c7ffcec87  call 0x0000782C7FEB4CB0
0000782c7ffcec8c  jmp 0x0000782C7FFCE8E5
0000782c7ffcec91  call 0x0000782C7FE0E760
0000782c7ffcec96  jmp 0x0000782C7FFCE8F0
0000782c7ffcec9b  call 0x0000782C7FE0D4E0
0000782c7ffceca0  jmp 0x0000782C7FFCE8FB
0000782c7ffceca5  call 0x0000782C7FDFF540
0000782c7ffcecaa  jmp 0x0000782C7FFCE908
0000782c7ffcecaf  call 0x0000782C7FE0BC20
0000782c7ffcecb4  jmp 0x0000782C7FFCE930
0000782c7ffcecb9  call 0x0000782C7FE0A9A0
0000782c7ffcecbe  jmp 0x0000782C7FFCE93C
0000782c7ffcecc3  call 0x0000782C7FE0E880
0000782c7ffcecc8  jmp 0x0000782C7FFCE949
0000782c7ffceccd  call 0x0000782C7FE0D600
0000782c7ffcecd2  jmp 0x0000782C7FFCE956
0000782c7ffcecd7  call 0x0000782C7FDFF430
0000782c7ffcecdc  jmp 0x0000782C7FFCE961
0000782c7ffcece1  call 0x0000782C7FE0E760
0000782c7ffcece6  jmp 0x0000782C7FFCE96C
0000782c7ffceceb  call 0x0000782C7FE0BC20
0000782c7ffcecf0  jmp 0x0000782C7FFCE99C
0000782c7ffcecf5  call 0x0000782C7FE0A9A0
0000782c7ffcecfa  jmp 0x0000782C7FFCE9A8
0000782c7ffcecff  call 0x0000782C7FE0BC20
0000782c7ffced04  jmp 0x0000782C7FFCE9D0
0000782c7ffced09  call 0x0000782C7FE0A9A0
0000782c7ffced0e  jmp 0x0000782C7FFCE9DC
0000782c7ffced13  call 0x0000782C7FDFF540
0000782c7ffced18  jmp 0x0000782C7FFCE9E9
0000782c7ffced1d  call 0x0000782C7FE0E880
0000782c7ffced22  jmp 0x0000782C7FFCE9F6
0000782c7ffced27  call 0x0000782C7FDFF430
0000782c7ffced2c  jmp 0x0000782C7FFCEA01
0000782c7ffced31  call 0x0000782C7FE0E760
0000782c7ffced36  jmp 0x0000782C7FFCEA0C
0000782c7ffced3b  call 0x0000782C7FE0BC20
0000782c7ffced40  jmp 0x0000782C7FFCEA36
0000782c7ffced45  call 0x0000782C7FE0A9A0
0000782c7ffced4a  jmp 0x0000782C7FFCEA42
0000782c7ffced4f  call 0x0000782C7FE0BAE0
0000782c7ffced54  jmp 0x0000782C7FFCEA52
0000782c7ffced59  call 0x0000782C7FDFF540
0000782c7ffced5e  jmp 0x0000782C7FFCEA5F
0000782c7ffced63  call 0x0000782C7FE0E880
0000782c7ffced68  jmp 0x0000782C7FFCEA6C
0000782c7ffced6d  int3
0000782c7ffced6e  nop
0000782c7ffced70  mov rax, [r15]
0000782c7ffced73  lea r14, [rax+0x20]
0000782c7ffced77  mov r12, [r13+r14*1]
0000782c7ffced7c  mov r14, [r15+0x10]
0000782c7ffced80  lea r11, [r12+r14*1]
0000782c7ffced84  mov [r15+0x40], r11
0000782c7ffced88  lea r12, [rax+0x20]
0000782c7ffced8c  mov [r13+r12*1], r11
0000782c7ffced91  test r14, r14
0000782c7ffced94  setz r14b
0000782c7ffced98  movzx r14, r14b
0000782c7ffced9c  mov [rsp+0x414], r14b
0000782c7ffceda4  cmp byte ptr [rsp+0x414], 0x00
0000782c7ffcedac  jz 0x0000782C7FFCEDDE
0000782c7ffcedae  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcedb6  mov eax, 0x410934
0000782c7ffcedbb  mov [r15+0x100], rax
0000782c7ffcedc2  jz 0x0000782C7FDFE0A0
0000782c7ffcedc8  nop [rax+rax*1], eax
0000782c7ffcedcd  mov eax, 0x410934
0000782c7ffcedd2  mov [r15+0x100], rax
0000782c7ffcedd9  jmp 0x0000782C7FDFE110
0000782c7ffcedde  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcede6  jz 0x0000782C7FFCEE30
0000782c7ffcedec  nop [rax+rax*1], ax
0000782c7ffcedf5  nop [rax+rax*1], eax
0000782c7ffcedfd  mov eax, 0x4106CC
0000782c7ffcee02  mov [r15+0x100], rax
0000782c7ffcee09  jmp 0x0000782C7FDFE110
0000782c7ffcee0e  int3
0000782c7ffcee0f  call 0x0000782C7FEE27E0
0000782c7ffcee14  jmp 0x0000782C7FFCED7C
0000782c7ffcee19  call 0x0000782C7FEC0860
0000782c7ffcee1e  jmp 0x0000782C7FFCED91
0000782c7ffcee23  int3
0000782c7ffcee24  nop [rax+rax*1], ax
0000782c7ffcee2d  nop [rax], eax
0000782c7ffcee30  mov rax, [r15+0xF8]
0000782c7ffcee37  lea r14, [rax-0x150]
0000782c7ffcee3e  mov [r15+0xF8], r14
0000782c7ffcee45  mov rax, [r15]
0000782c7ffcee48  lea r12, [rax+0x68]
0000782c7ffcee4c  mov r11, [r13+r12*1]
0000782c7ffcee51  mov [r15+0x88], r11
0000782c7ffcee58  lea r12, [rax+0x28]
0000782c7ffcee5c  mov [r15+0x40], r12
0000782c7ffcee60  mov [r15+0x48], r14
0000782c7ffcee64  mov qword ptr [r15+0x50], 0x420B20
0000782c7ffcee6c  lea rax, [r14+0x100]
0000782c7ffcee73  mov r12, [r15+0xE8]
0000782c7ffcee7a  mov r11, [r15+0xD8]
0000782c7ffcee81  mov [r13+rax*1], r12
0000782c7ffcee86  lea rax, [r14+0x108]
0000782c7ffcee8d  mov [r13+rax*1], r11
0000782c7ffcee92  lea rax, [r14+0x110]
0000782c7ffcee99  mov r12, [r15+0xD0]
0000782c7ffceea0  mov r11, [r15+0xC8]
0000782c7ffceea7  mov [r13+rax*1], r12
0000782c7ffceeac  lea rax, [r14+0x118]
0000782c7ffceeb3  mov [r13+rax*1], r11
0000782c7ffceeb8  lea rax, [r14+0x120]
0000782c7ffceebf  mov r12, [r15+0xC0]
0000782c7ffceec6  mov r11, [r15+0xB8]
0000782c7ffceecd  mov [r13+rax*1], r12
0000782c7ffceed2  lea rax, [r14+0x128]
0000782c7ffceed9  mov [r13+rax*1], r11
0000782c7ffceede  lea rax, [r14+0x130]
0000782c7ffceee5  mov r12, [r15+0xB0]
0000782c7ffceeec  mov r11, [r15+0xA8]
0000782c7ffceef3  mov [r13+rax*1], r12
0000782c7ffceef8  lea rax, [r14+0x138]
0000782c7ffceeff  mov [r13+rax*1], r11
0000782c7ffcef04  lea rax, [r14+0x140]
0000782c7ffcef0b  mov r12, [r15+0xA0]
0000782c7ffcef12  mov r11, [r15+0x98]
0000782c7ffcef19  mov [r13+rax*1], r12
0000782c7ffcef1e  lea rax, [r14+0x148]
0000782c7ffcef25  mov [r13+rax*1], r11
0000782c7ffcef2a  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcef32  jz 0x0000782C7FFCEFD0
0000782c7ffcef38  nop [rax+rax*1], ax
0000782c7ffcef41  nop [rax+rax*1], eax
0000782c7ffcef49  mov eax, 0x410704
0000782c7ffcef4e  mov [r15+0x100], rax
0000782c7ffcef55  jmp 0x0000782C7FDFE110
0000782c7ffcef5a  int3
0000782c7ffcef5b  call 0x0000782C7FEC0370
0000782c7ffcef60  jmp 0x0000782C7FFCEE51
0000782c7ffcef65  call 0x0000782C7FE0BC20
0000782c7ffcef6a  jmp 0x0000782C7FFCEE86
0000782c7ffcef6f  call 0x0000782C7FE0A9A0
0000782c7ffcef74  jmp 0x0000782C7FFCEE92
0000782c7ffcef79  call 0x0000782C7FE0BC20
0000782c7ffcef7e  jmp 0x0000782C7FFCEEAC
0000782c7ffcef83  call 0x0000782C7FE0A9A0
0000782c7ffcef88  jmp 0x0000782C7FFCEEB8
0000782c7ffcef8d  call 0x0000782C7FE0BC20
0000782c7ffcef92  jmp 0x0000782C7FFCEED2
0000782c7ffcef97  call 0x0000782C7FE0A9A0
0000782c7ffcef9c  jmp 0x0000782C7FFCEEDE
0000782c7ffcefa1  call 0x0000782C7FE0BC20
0000782c7ffcefa6  jmp 0x0000782C7FFCEEF8
0000782c7ffcefab  call 0x0000782C7FE0A9A0
0000782c7ffcefb0  jmp 0x0000782C7FFCEF04
0000782c7ffcefb5  call 0x0000782C7FE0BC20
0000782c7ffcefba  jmp 0x0000782C7FFCEF1E
0000782c7ffcefbf  call 0x0000782C7FE0A9A0
0000782c7ffcefc4  jmp 0x0000782C7FFCEF2A
0000782c7ffcefc9  int3
0000782c7ffcefca  nop [rax+rax*1], ax
0000782c7ffcefd0  mov rax, [r15+0x08]
0000782c7ffcefd4  movzx r14d, byte ptr [r13+rax*1]
0000782c7ffcefda  movzx r14d, r14b
0000782c7ffcefde  mov [rsp+0x10], r14d
0000782c7ffcefe3  mov r14d, r14d
0000782c7ffcefe6  mov [r15+0x58], r14
0000782c7ffcefea  lea r14, [rax+0x01]
0000782c7ffcefee  mov [r15+0x08], r14
0000782c7ffceff2  mov rax, [r15+0x88]
0000782c7ffceff9  lea r14, [rax+0x01]
0000782c7ffceffd  mov r12, [r15]
0000782c7ffcf000  lea r11, [r12+0x68]
0000782c7ffcf005  mov [r13+r11*1], r14
0000782c7ffcf00a  lea r14, [r12+rax*1]
0000782c7ffcf00e  mov [r15+0x60], r14
0000782c7ffcf012  lea rax, [r14+0x28]
0000782c7ffcf016  mov r11d, [rsp+0x10]
0000782c7ffcf01b  movzx r14d, r11b
0000782c7ffcf01f  mov [r13+rax*1], r14b
0000782c7ffcf024  lea rax, [r12+0x68]
0000782c7ffcf029  mov r14, [r13+rax*1]
0000782c7ffcf02e  mov [r15+0x88], r14
0000782c7ffcf035  xor eax, eax
0000782c7ffcf037  mov r12d, 0x40
0000782c7ffcf03d  cmp r14, r12
0000782c7ffcf040  cmc
0000782c7ffcf041  lahf
0000782c7ffcf042  seto al
0000782c7ffcf045  mov [r15+0x108], eax
0000782c7ffcf04c  mov eax, [r15+0x108]
0000782c7ffcf053  sahf
0000782c7ffcf054  jnz 0x0000782C7FFCF086
0000782c7ffcf056  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcf05e  jz 0x0000782C7FFCF170
0000782c7ffcf064  nop [rax+rax*1], ax
0000782c7ffcf06d  nop [rax+rax*1], eax
0000782c7ffcf075  mov eax, 0x410724
0000782c7ffcf07a  mov [r15+0x100], rax
0000782c7ffcf081  jmp 0x0000782C7FDFE110
0000782c7ffcf086  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcf08e  jz 0x0000782C7FFCF0E0
0000782c7ffcf094  nop [rax+rax*1], ax
0000782c7ffcf09d  nop [rax+rax*1], eax
0000782c7ffcf0a5  mov eax, 0x4106FC
0000782c7ffcf0aa  mov [r15+0x100], rax
0000782c7ffcf0b1  jmp 0x0000782C7FDFE110
0000782c7ffcf0b6  int3
0000782c7ffcf0b7  call 0x0000782C7FE0D860
0000782c7ffcf0bc  jmp 0x0000782C7FFCEFDA
0000782c7ffcf0c1  call 0x0000782C7FEB36E0
0000782c7ffcf0c6  jmp 0x0000782C7FFCF00A
0000782c7ffcf0cb  call 0x0000782C7FE0DD60
0000782c7ffcf0d0  jmp 0x0000782C7FFCF024
0000782c7ffcf0d5  call 0x0000782C7FE0DC20
0000782c7ffcf0da  jmp 0x0000782C7FFCF02E
0000782c7ffcf0df  int3
0000782c7ffcf0e0  mov rax, [r15+0x10]
0000782c7ffcf0e4  lea r14, [rax-0x01]
0000782c7ffcf0e8  mov [r15+0x10], r14
0000782c7ffcf0ec  test r14, r14
0000782c7ffcf0ef  setz r14b
0000782c7ffcf0f3  movzx r14, r14b
0000782c7ffcf0f7  mov [rsp+0x414], r14b
0000782c7ffcf0ff  cmp byte ptr [rsp+0x414], 0x00
0000782c7ffcf107  jz 0x0000782C7FFCF139
0000782c7ffcf109  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcf111  jz 0x0000782C7FFD0670
0000782c7ffcf117  nop [rax+rax*1], ax
0000782c7ffcf120  nop [rax+rax*1], eax
0000782c7ffcf128  mov eax, 0x41091C
0000782c7ffcf12d  mov [r15+0x100], rax
0000782c7ffcf134  jmp 0x0000782C7FDFE110
0000782c7ffcf139  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcf141  jz 0x0000782C7FFCEFD0
0000782c7ffcf147  nop [rax+rax*1], ax
0000782c7ffcf150  nop [rax+rax*1], eax
0000782c7ffcf158  mov eax, 0x410704
0000782c7ffcf15d  mov [r15+0x100], rax
0000782c7ffcf164  jmp 0x0000782C7FDFE110
0000782c7ffcf169  int3
0000782c7ffcf16a  int3
0000782c7ffcf16b  nop [rax+rax*1], eax
0000782c7ffcf170  mov rax, [r15+0x40]
0000782c7ffcf174  movzx r14d, byte ptr [r13+rax*1]
0000782c7ffcf17a  movaps xmm1, [r15+0x110]
0000782c7ffcf182  pinsrb xmm1, r14d, 0x00
0000782c7ffcf189  lea r14, [rax+0x01]
0000782c7ffcf18d  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf193  movaps xmm15, [r15+0x120]
0000782c7ffcf19b  pinsrb xmm15, r12d, 0x00
0000782c7ffcf1a2  lea r14, [rax+0x02]
0000782c7ffcf1a6  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf1ac  movaps xmm14, [r15+0x130]
0000782c7ffcf1b4  pinsrb xmm14, r12d, 0x00
0000782c7ffcf1bb  lea r14, [rax+0x03]
0000782c7ffcf1bf  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf1c5  movaps xmm13, [r15+0x140]
0000782c7ffcf1cd  pinsrb xmm13, r12d, 0x00
0000782c7ffcf1d4  lea r14, [rax+0x04]
0000782c7ffcf1d8  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf1de  pinsrb xmm1, r12d, 0x01
0000782c7ffcf1e5  lea r14, [rax+0x05]
0000782c7ffcf1e9  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf1ef  pinsrb xmm15, r12d, 0x01
0000782c7ffcf1f6  lea r14, [rax+0x06]
0000782c7ffcf1fa  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf200  pinsrb xmm14, r12d, 0x01
0000782c7ffcf207  lea r14, [rax+0x07]
0000782c7ffcf20b  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf211  pinsrb xmm13, r12d, 0x01
0000782c7ffcf218  lea r14, [rax+0x08]
0000782c7ffcf21c  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf222  pinsrb xmm1, r12d, 0x02
0000782c7ffcf229  lea r14, [rax+0x09]
0000782c7ffcf22d  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf233  pinsrb xmm15, r12d, 0x02
0000782c7ffcf23a  lea r14, [rax+0x0A]
0000782c7ffcf23e  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf244  pinsrb xmm14, r12d, 0x02
0000782c7ffcf24b  lea r14, [rax+0x0B]
0000782c7ffcf24f  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf255  pinsrb xmm13, r12d, 0x02
0000782c7ffcf25c  lea r14, [rax+0x0C]
0000782c7ffcf260  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf266  pinsrb xmm1, r12d, 0x03
0000782c7ffcf26d  lea r14, [rax+0x0D]
0000782c7ffcf271  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf277  pinsrb xmm15, r12d, 0x03
0000782c7ffcf27e  lea r14, [rax+0x0E]
0000782c7ffcf282  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf288  pinsrb xmm14, r12d, 0x03
0000782c7ffcf28f  lea r14, [rax+0x0F]
0000782c7ffcf293  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf299  pinsrb xmm13, r12d, 0x03
0000782c7ffcf2a0  lea r14, [rax+0x10]
0000782c7ffcf2a4  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf2aa  pinsrb xmm1, r12d, 0x04
0000782c7ffcf2b1  lea r14, [rax+0x11]
0000782c7ffcf2b5  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf2bb  pinsrb xmm15, r12d, 0x04
0000782c7ffcf2c2  lea r14, [rax+0x12]
0000782c7ffcf2c6  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf2cc  pinsrb xmm14, r12d, 0x04
0000782c7ffcf2d3  lea r14, [rax+0x13]
0000782c7ffcf2d7  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf2dd  pinsrb xmm13, r12d, 0x04
0000782c7ffcf2e4  lea r14, [rax+0x14]
0000782c7ffcf2e8  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf2ee  pinsrb xmm1, r12d, 0x05
0000782c7ffcf2f5  lea r14, [rax+0x15]
0000782c7ffcf2f9  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf2ff  pinsrb xmm15, r12d, 0x05
0000782c7ffcf306  lea r14, [rax+0x16]
0000782c7ffcf30a  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf310  pinsrb xmm14, r12d, 0x05
0000782c7ffcf317  lea r14, [rax+0x17]
0000782c7ffcf31b  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf321  pinsrb xmm13, r12d, 0x05
0000782c7ffcf328  lea r14, [rax+0x18]
0000782c7ffcf32c  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf332  pinsrb xmm1, r12d, 0x06
0000782c7ffcf339  lea r14, [rax+0x19]
0000782c7ffcf33d  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf343  pinsrb xmm15, r12d, 0x06
0000782c7ffcf34a  lea r14, [rax+0x1A]
0000782c7ffcf34e  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf354  pinsrb xmm14, r12d, 0x06
0000782c7ffcf35b  lea r14, [rax+0x1B]
0000782c7ffcf35f  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf365  pinsrb xmm13, r12d, 0x06
0000782c7ffcf36c  lea r14, [rax+0x1C]
0000782c7ffcf370  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf376  pinsrb xmm1, r12d, 0x07
0000782c7ffcf37d  lea r14, [rax+0x1D]
0000782c7ffcf381  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf387  pinsrb xmm15, r12d, 0x07
0000782c7ffcf38e  lea r14, [rax+0x1E]
0000782c7ffcf392  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf398  pinsrb xmm14, r12d, 0x07
0000782c7ffcf39f  lea r14, [rax+0x1F]
0000782c7ffcf3a3  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf3a9  pinsrb xmm13, r12d, 0x07
0000782c7ffcf3b0  lea r14, [rax+0x20]
0000782c7ffcf3b4  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf3ba  pinsrb xmm1, r12d, 0x08
0000782c7ffcf3c1  lea r14, [rax+0x21]
0000782c7ffcf3c5  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf3cb  pinsrb xmm15, r12d, 0x08
0000782c7ffcf3d2  lea r14, [rax+0x22]
0000782c7ffcf3d6  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf3dc  pinsrb xmm14, r12d, 0x08
0000782c7ffcf3e3  lea r14, [rax+0x23]
0000782c7ffcf3e7  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf3ed  pinsrb xmm13, r12d, 0x08
0000782c7ffcf3f4  lea r14, [rax+0x24]
0000782c7ffcf3f8  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf3fe  pinsrb xmm1, r12d, 0x09
0000782c7ffcf405  lea r14, [rax+0x25]
0000782c7ffcf409  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf40f  pinsrb xmm15, r12d, 0x09
0000782c7ffcf416  lea r14, [rax+0x26]
0000782c7ffcf41a  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf420  pinsrb xmm14, r12d, 0x09
0000782c7ffcf427  lea r14, [rax+0x27]
0000782c7ffcf42b  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf431  pinsrb xmm13, r12d, 0x09
0000782c7ffcf438  lea r14, [rax+0x28]
0000782c7ffcf43c  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf442  pinsrb xmm1, r12d, 0x0A
0000782c7ffcf449  lea r14, [rax+0x29]
0000782c7ffcf44d  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf453  pinsrb xmm15, r12d, 0x0A
0000782c7ffcf45a  lea r14, [rax+0x2A]
0000782c7ffcf45e  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf464  pinsrb xmm14, r12d, 0x0A
0000782c7ffcf46b  lea r14, [rax+0x2B]
0000782c7ffcf46f  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf475  pinsrb xmm13, r12d, 0x0A
0000782c7ffcf47c  lea r14, [rax+0x2C]
0000782c7ffcf480  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf486  pinsrb xmm1, r12d, 0x0B
0000782c7ffcf48d  lea r14, [rax+0x2D]
0000782c7ffcf491  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf497  pinsrb xmm15, r12d, 0x0B
0000782c7ffcf49e  lea r14, [rax+0x2E]
0000782c7ffcf4a2  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf4a8  pinsrb xmm14, r12d, 0x0B
0000782c7ffcf4af  lea r14, [rax+0x2F]
0000782c7ffcf4b3  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf4b9  pinsrb xmm13, r12d, 0x0B
0000782c7ffcf4c0  lea r14, [rax+0x30]
0000782c7ffcf4c4  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf4ca  pinsrb xmm1, r12d, 0x0C
0000782c7ffcf4d1  lea r14, [rax+0x31]
0000782c7ffcf4d5  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf4db  pinsrb xmm15, r12d, 0x0C
0000782c7ffcf4e2  lea r14, [rax+0x32]
0000782c7ffcf4e6  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf4ec  pinsrb xmm14, r12d, 0x0C
0000782c7ffcf4f3  lea r14, [rax+0x33]
0000782c7ffcf4f7  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf4fd  pinsrb xmm13, r12d, 0x0C
0000782c7ffcf504  lea r14, [rax+0x34]
0000782c7ffcf508  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf50e  pinsrb xmm1, r12d, 0x0D
0000782c7ffcf515  lea r14, [rax+0x35]
0000782c7ffcf519  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf51f  pinsrb xmm15, r12d, 0x0D
0000782c7ffcf526  lea r14, [rax+0x36]
0000782c7ffcf52a  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf530  pinsrb xmm14, r12d, 0x0D
0000782c7ffcf537  lea r14, [rax+0x37]
0000782c7ffcf53b  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf541  pinsrb xmm13, r12d, 0x0D
0000782c7ffcf548  lea r14, [rax+0x38]
0000782c7ffcf54c  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf552  pinsrb xmm1, r12d, 0x0E
0000782c7ffcf559  lea r14, [rax+0x39]
0000782c7ffcf55d  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf563  pinsrb xmm15, r12d, 0x0E
0000782c7ffcf56a  lea r14, [rax+0x3A]
0000782c7ffcf56e  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf574  pinsrb xmm14, r12d, 0x0E
0000782c7ffcf57b  lea r14, [rax+0x3B]
0000782c7ffcf57f  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf585  pinsrb xmm13, r12d, 0x0E
0000782c7ffcf58c  lea r14, [rax+0x3C]
0000782c7ffcf590  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf596  pinsrb xmm1, r12d, 0x0F
0000782c7ffcf59d  movaps [r15+0x110], xmm1
0000782c7ffcf5a5  lea r14, [rax+0x3D]
0000782c7ffcf5a9  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf5af  pinsrb xmm15, r12d, 0x0F
0000782c7ffcf5b6  movaps [r15+0x120], xmm15
0000782c7ffcf5be  lea r14, [rax+0x3E]
0000782c7ffcf5c2  movzx r12d, byte ptr [r13+r14*1]
0000782c7ffcf5c8  pinsrb xmm14, r12d, 0x0F
0000782c7ffcf5cf  movaps [r15+0x130], xmm14
0000782c7ffcf5d7  lea r14, [rax+0x3F]
0000782c7ffcf5db  movzx eax, byte ptr [r13+r14*1]
0000782c7ffcf5e1  pinsrb xmm13, eax, 0x0F
0000782c7ffcf5e8  movaps [r15+0x140], xmm13
0000782c7ffcf5f0  movq xmm1, qword ptr [r15+0x120]
0000782c7ffcf5f9  pmovzxbw xmm1, xmm1
0000782c7ffcf5fe  psllw xmm1, 0x00
0000782c7ffcf603  movaps [r15+0x150], xmm1
0000782c7ffcf60b  movq xmm1, qword ptr [r15+0x130]
0000782c7ffcf614  pmovzxbw xmm1, xmm1
0000782c7ffcf619  psllw xmm1, 0x00
0000782c7ffcf61e  movaps [r15+0x160], xmm1
0000782c7ffcf626  movq xmm1, qword ptr [r15+0x110]
0000782c7ffcf62f  pmovzxbw xmm1, xmm1
0000782c7ffcf634  psllw xmm1, 0x00
0000782c7ffcf639  movaps [r15+0x170], xmm1
0000782c7ffcf641  movaps xmm15, [r15+0x110]
0000782c7ffcf649  pextrq rax, xmm15, 0x01
0000782c7ffcf650  movq xmm15, rax
0000782c7ffcf655  pmovzxbw xmm15, xmm15
0000782c7ffcf65b  psllw xmm15, 0x00
0000782c7ffcf661  movaps [r15+0x180], xmm15
0000782c7ffcf669  movaps xmm14, [r15+0x120]
0000782c7ffcf671  pextrq rax, xmm14, 0x01
0000782c7ffcf678  movq xmm14, rax
0000782c7ffcf67d  pmovzxbw xmm14, xmm14
0000782c7ffcf683  psllw xmm14, 0x00
0000782c7ffcf689  movaps [r15+0x210], xmm14
0000782c7ffcf691  movaps xmm13, [r15+0x130]
0000782c7ffcf699  pextrq rax, xmm13, 0x01
0000782c7ffcf6a0  movq xmm13, rax
0000782c7ffcf6a5  pmovzxbw xmm13, xmm13
0000782c7ffcf6ab  psllw xmm13, 0x00
0000782c7ffcf6b1  movaps [r15+0x220], xmm13
0000782c7ffcf6b9  movq xmm12, qword ptr [r15+0x140]
0000782c7ffcf6c2  pmovzxbw xmm12, xmm12
0000782c7ffcf6c8  psllw xmm12, 0x00
0000782c7ffcf6ce  movaps [r15+0x250], xmm12
0000782c7ffcf6d6  movaps xmm12, [r15+0x140]
0000782c7ffcf6de  pextrq rax, xmm12, 0x01
0000782c7ffcf6e5  movq xmm12, rax
0000782c7ffcf6ea  pmovzxbw xmm12, xmm12
0000782c7ffcf6f0  psllw xmm12, 0x00
0000782c7ffcf6f6  movaps [r15+0x110], xmm12
0000782c7ffcf6fe  movq xmm11, qword ptr [r15+0x150]
0000782c7ffcf707  pmovzxwd xmm11, xmm11
0000782c7ffcf70d  pslld xmm11, 0x10
0000782c7ffcf713  movq xmm10, qword ptr [r15+0x160]
0000782c7ffcf71c  pmovzxwd xmm10, xmm10
0000782c7ffcf722  pslld xmm10, 0x08
0000782c7ffcf728  pextrq rax, xmm1, 0x01
0000782c7ffcf72f  movq xmm1, rax
0000782c7ffcf734  pmovzxwd xmm1, xmm1
0000782c7ffcf739  pslld xmm1, 0x00
0000782c7ffcf73e  movaps [r15+0x260], xmm1
0000782c7ffcf746  pextrq rax, xmm15, 0x01
0000782c7ffcf74d  movq xmm15, rax
0000782c7ffcf752  pmovzxwd xmm15, xmm15
0000782c7ffcf758  pslld xmm15, 0x00
0000782c7ffcf75e  movaps [r15+0x270], xmm15
0000782c7ffcf766  movq xmm9, qword ptr [r15+0x170]
0000782c7ffcf76f  pmovzxwd xmm9, xmm9
0000782c7ffcf775  pslld xmm9, 0x00
0000782c7ffcf77b  pextrq rax, xmm14, 0x01
0000782c7ffcf782  movq xmm14, rax
0000782c7ffcf787  pmovzxwd xmm14, xmm14
0000782c7ffcf78d  pslld xmm14, 0x10
0000782c7ffcf793  movaps [r15+0x280], xmm14
0000782c7ffcf79b  movq xmm8, qword ptr [r15+0x180]
0000782c7ffcf7a4  pmovzxwd xmm8, xmm8
0000782c7ffcf7aa  pslld xmm8, 0x00
0000782c7ffcf7b0  movq xmm7, qword ptr [r15+0x210]
0000782c7ffcf7b9  pmovzxwd xmm7, xmm7
0000782c7ffcf7be  pslld xmm7, 0x10
0000782c7ffcf7c3  movaps xmm6, [r15+0x150]
0000782c7ffcf7cb  pextrq rax, xmm6, 0x01
0000782c7ffcf7d2  movq xmm6, rax
0000782c7ffcf7d7  pmovzxwd xmm6, xmm6
0000782c7ffcf7dc  pslld xmm6, 0x10
0000782c7ffcf7e1  por xmm11, xmm10
0000782c7ffcf7e6  movaps [r15+0x230], xmm11
0000782c7ffcf7ee  pextrq rax, xmm13, 0x01
0000782c7ffcf7f5  movq xmm13, rax
0000782c7ffcf7fa  pmovzxwd xmm13, xmm13
0000782c7ffcf800  pslld xmm13, 0x08
0000782c7ffcf806  movaps [r15+0x240], xmm13
0000782c7ffcf80e  movq xmm10, qword ptr [r15+0x220]
0000782c7ffcf817  pmovzxwd xmm10, xmm10
0000782c7ffcf81d  pslld xmm10, 0x08
0000782c7ffcf823  movaps xmm5, [r15+0x160]
0000782c7ffcf82b  pextrq rax, xmm5, 0x01
0000782c7ffcf832  movq xmm5, rax
0000782c7ffcf837  pmovzxwd xmm5, xmm5
0000782c7ffcf83c  pslld xmm5, 0x08
0000782c7ffcf841  pslld xmm9, 0x18
0000782c7ffcf847  pslld xmm15, 0x18
0000782c7ffcf84d  pslld xmm8, 0x18
0000782c7ffcf853  movq xmm4, qword ptr [r15+0x250]
0000782c7ffcf85c  pmovzxwd xmm4, xmm4
0000782c7ffcf861  pslld xmm4, 0x00
0000782c7ffcf866  por xmm14, xmm13
0000782c7ffcf86b  por xmm7, xmm10
0000782c7ffcf870  movaps [r15+0x210], xmm7
0000782c7ffcf878  pslld xmm1, 0x18
0000782c7ffcf87d  movaps [r15+0x220], xmm1
0000782c7ffcf885  por xmm6, xmm5
0000782c7ffcf889  por xmm11, xmm9
0000782c7ffcf88e  movaps [r15+0x160], xmm11
0000782c7ffcf896  pextrq rax, xmm12, 0x01
0000782c7ffcf89d  movq xmm13, rax
0000782c7ffcf8a2  pmovzxwd xmm13, xmm13
0000782c7ffcf8a8  pslld xmm13, 0x00
0000782c7ffcf8ae  movaps [r15+0x170], xmm13
0000782c7ffcf8b6  movq xmm12, qword ptr [r15+0x110]
0000782c7ffcf8bf  pmovzxwd xmm12, xmm12
0000782c7ffcf8c5  pslld xmm12, 0x00
0000782c7ffcf8cb  por xmm14, xmm15
0000782c7ffcf8d0  por xmm7, xmm8
0000782c7ffcf8d5  movaps xmm15, [r15+0x250]
0000782c7ffcf8dd  pextrq rax, xmm15, 0x01
0000782c7ffcf8e4  movq xmm15, rax
0000782c7ffcf8e9  pmovzxwd xmm15, xmm15
0000782c7ffcf8ef  pslld xmm15, 0x00
0000782c7ffcf8f5  movaps [r15+0x180], xmm15
0000782c7ffcf8fd  por xmm6, xmm1
0000782c7ffcf901  movaps [r15+0x150], xmm6
0000782c7ffcf909  por xmm11, xmm4
0000782c7ffcf90e  movaps [r15+0x140], xmm11
0000782c7ffcf916  por xmm7, xmm12
0000782c7ffcf91b  movaps [r15+0x110], xmm7
0000782c7ffcf923  por xmm14, xmm13
0000782c7ffcf928  movaps [r15+0x120], xmm14
0000782c7ffcf930  por xmm6, xmm15
0000782c7ffcf935  movaps [r15+0x130], xmm6
0000782c7ffcf93d  mov rax, [r15+0xF8]
0000782c7ffcf944  lea r14, [rax+0x20]
0000782c7ffcf948  movups [r13+r14*1], xmm7
0000782c7ffcf94e  lea r14, [rax+0x30]
0000782c7ffcf952  movups [r13+r14*1], xmm14
0000782c7ffcf958  movups [r13+rax*1], xmm11
0000782c7ffcf95e  lea r14, [rax+0x10]
0000782c7ffcf962  movups [r13+r14*1], xmm6
0000782c7ffcf968  mov r14d, [r13+rax*1]
0000782c7ffcf96d  mov rax, [r15+0x48]
0000782c7ffcf971  mov [r15+0x68], rax
0000782c7ffcf975  mov qword ptr [r15+0x58], 0x04
0000782c7ffcf97d  lea r12, [rax+0x04]
0000782c7ffcf981  mov r11d, [r13+r12*1]
0000782c7ffcf986  mov [rsp+0x10], r11d
0000782c7ffcf98b  mov r11d, r11d
0000782c7ffcf98e  mov [r15+0x70], r11
0000782c7ffcf992  lea r12, [rax+0x38]
0000782c7ffcf996  mov r11d, [r13+r12*1]
0000782c7ffcf99b  lea r12, [rax+0x24]
0000782c7ffcf99f  mov r10d, [r13+r12*1]
0000782c7ffcf9a4  mov [rsp+0x20], r10d
0000782c7ffcf9a9  mov r10d, r10d
0000782c7ffcf9ac  mov [r15+0x90], r10
0000782c7ffcf9b3  mov [rsp+0x30], rax
0000782c7ffcf9b8  xor eax, eax
0000782c7ffcf9ba  mov r12d, 0x04
0000782c7ffcf9c0  mov r10d, 0xC0
0000782c7ffcf9c6  cmp r12, r10
0000782c7ffcf9c9  cmc
0000782c7ffcf9ca  lahf
0000782c7ffcf9cb  seto al
0000782c7ffcf9ce  mov [r15+0x108], eax
0000782c7ffcf9d5  mov eax, [rsp+0x10]
0000782c7ffcf9d9  mov r12d, [rsp+0x10]
0000782c7ffcf9de  shrd eax, r12d, 0x07
0000782c7ffcf9e3  mov [rsp+0x10], r11d
0000782c7ffcf9e8  mov r10d, [rsp+0x10]
0000782c7ffcf9ed  shrd r11d, r10d, 0x11
0000782c7ffcf9f2  mov r9d, [rsp+0x20]
0000782c7ffcf9f7  lea r8d, [r9d+r14d*1]
0000782c7ffcf9fc  rorx r14d, r12d, 0x12
0000782c7ffcfa02  xor eax, r14d
0000782c7ffcfa05  rorx r14d, r10d, 0x13
0000782c7ffcfa0b  xor r11d, r14d
0000782c7ffcfa0e  mov [rsp+0x10], r11d
0000782c7ffcfa13  mov r11d, r11d
0000782c7ffcfa16  mov [r15+0x88], r11
0000782c7ffcfa1d  mov [rsp+0x20], r12d
0000782c7ffcfa22  shr r12d, 0x03
0000782c7ffcfa26  xor eax, r12d
0000782c7ffcfa29  mov [rsp+0x40], eax
0000782c7ffcfa2d  mov eax, eax
0000782c7ffcfa2f  mov [r15+0x80], rax
0000782c7ffcfa36  shr r10d, 0x0A
0000782c7ffcfa3a  mov eax, [rsp+0x10]
0000782c7ffcfa3e  xor eax, r10d
0000782c7ffcfa41  mov [rsp+0x10], eax
0000782c7ffcfa45  mov eax, eax
0000782c7ffcfa47  mov [r15+0x78], rax
0000782c7ffcfa4b  mov eax, [rsp+0x40]
0000782c7ffcfa4f  lea r14d, [r8d+eax*1]
0000782c7ffcfa54  mov eax, [rsp+0x10]
0000782c7ffcfa58  lea r12d, [r14d+eax*1]
0000782c7ffcfa5d  mov rax, [rsp+0x30]
0000782c7ffcfa62  lea r14, [rax+0x40]
0000782c7ffcfa66  mov [r13+r14*1], r12d
0000782c7ffcfa6b  mov eax, [rsp+0x20]
0000782c7ffcfa6f  mov eax, eax
0000782c7ffcfa71  mov [r15+0x60], rax
0000782c7ffcfa75  mov eax, [r15+0x108]
0000782c7ffcfa7c  sahf
0000782c7ffcfa7d  jnz 0x0000782C7FFCFAAF
0000782c7ffcfa7f  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcfa87  jz 0x0000782C7FFCFF70
0000782c7ffcfa8d  nop [rax+rax*1], ax
0000782c7ffcfa96  nop [rax+rax*1], eax
0000782c7ffcfa9e  mov eax, 0x410820
0000782c7ffcfaa3  mov [r15+0x100], rax
0000782c7ffcfaaa  jmp 0x0000782C7FDFE110
0000782c7ffcfaaf  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcfab7  jz 0x0000782C7FFCFDC0
0000782c7ffcfabd  nop [rax+rax*1], ax
0000782c7ffcfac6  nop [rax+rax*1], eax
0000782c7ffcface  mov eax, 0x4107D8
0000782c7ffcfad3  mov [r15+0x100], rax
0000782c7ffcfada  jmp 0x0000782C7FDFE110
0000782c7ffcfadf  int3
0000782c7ffcfae0  call 0x0000782C7FE0D860
0000782c7ffcfae5  jmp 0x0000782C7FFCF17A
0000782c7ffcfaea  call 0x0000782C7FEE2420
0000782c7ffcfaef  jmp 0x0000782C7FFCF193
0000782c7ffcfaf4  call 0x0000782C7FEE2420
0000782c7ffcfaf9  jmp 0x0000782C7FFCF1AC
0000782c7ffcfafe  call 0x0000782C7FEE2420
0000782c7ffcfb03  jmp 0x0000782C7FFCF1C5
0000782c7ffcfb08  call 0x0000782C7FEE2420
0000782c7ffcfb0d  jmp 0x0000782C7FFCF1DE
0000782c7ffcfb12  call 0x0000782C7FEE2420
0000782c7ffcfb17  jmp 0x0000782C7FFCF1EF
0000782c7ffcfb1c  call 0x0000782C7FEE2420
0000782c7ffcfb21  jmp 0x0000782C7FFCF200
0000782c7ffcfb26  call 0x0000782C7FEE2420
0000782c7ffcfb2b  jmp 0x0000782C7FFCF211
0000782c7ffcfb30  call 0x0000782C7FEE2420
0000782c7ffcfb35  jmp 0x0000782C7FFCF222
0000782c7ffcfb3a  call 0x0000782C7FEE2420
0000782c7ffcfb3f  jmp 0x0000782C7FFCF233
0000782c7ffcfb44  call 0x0000782C7FEE2420
0000782c7ffcfb49  jmp 0x0000782C7FFCF244
0000782c7ffcfb4e  call 0x0000782C7FEE2420
0000782c7ffcfb53  jmp 0x0000782C7FFCF255
0000782c7ffcfb58  call 0x0000782C7FEE2420
0000782c7ffcfb5d  jmp 0x0000782C7FFCF266
0000782c7ffcfb62  call 0x0000782C7FEE2420
0000782c7ffcfb67  jmp 0x0000782C7FFCF277
0000782c7ffcfb6c  call 0x0000782C7FEE2420
0000782c7ffcfb71  jmp 0x0000782C7FFCF288
0000782c7ffcfb76  call 0x0000782C7FEE2420
0000782c7ffcfb7b  jmp 0x0000782C7FFCF299
0000782c7ffcfb80  call 0x0000782C7FEE2420
0000782c7ffcfb85  jmp 0x0000782C7FFCF2AA
0000782c7ffcfb8a  call 0x0000782C7FEE2420
0000782c7ffcfb8f  jmp 0x0000782C7FFCF2BB
0000782c7ffcfb94  call 0x0000782C7FEE2420
0000782c7ffcfb99  jmp 0x0000782C7FFCF2CC
0000782c7ffcfb9e  call 0x0000782C7FEE2420
0000782c7ffcfba3  jmp 0x0000782C7FFCF2DD
0000782c7ffcfba8  call 0x0000782C7FEE2420
0000782c7ffcfbad  jmp 0x0000782C7FFCF2EE
0000782c7ffcfbb2  call 0x0000782C7FEE2420
0000782c7ffcfbb7  jmp 0x0000782C7FFCF2FF
0000782c7ffcfbbc  call 0x0000782C7FEE2420
0000782c7ffcfbc1  jmp 0x0000782C7FFCF310
0000782c7ffcfbc6  call 0x0000782C7FEE2420
0000782c7ffcfbcb  jmp 0x0000782C7FFCF321
0000782c7ffcfbd0  call 0x0000782C7FEE2420
0000782c7ffcfbd5  jmp 0x0000782C7FFCF332
0000782c7ffcfbda  call 0x0000782C7FEE2420
0000782c7ffcfbdf  jmp 0x0000782C7FFCF343
0000782c7ffcfbe4  call 0x0000782C7FEE2420
0000782c7ffcfbe9  jmp 0x0000782C7FFCF354
0000782c7ffcfbee  call 0x0000782C7FEE2420
0000782c7ffcfbf3  jmp 0x0000782C7FFCF365
0000782c7ffcfbf8  call 0x0000782C7FEE2420
0000782c7ffcfbfd  jmp 0x0000782C7FFCF376
0000782c7ffcfc02  call 0x0000782C7FEE2420
0000782c7ffcfc07  jmp 0x0000782C7FFCF387
0000782c7ffcfc0c  call 0x0000782C7FEE2420
0000782c7ffcfc11  jmp 0x0000782C7FFCF398
0000782c7ffcfc16  call 0x0000782C7FEE2420
0000782c7ffcfc1b  jmp 0x0000782C7FFCF3A9
0000782c7ffcfc20  call 0x0000782C7FEE2420
0000782c7ffcfc25  jmp 0x0000782C7FFCF3BA
0000782c7ffcfc2a  call 0x0000782C7FEE2420
0000782c7ffcfc2f  jmp 0x0000782C7FFCF3CB
0000782c7ffcfc34  call 0x0000782C7FEE2420
0000782c7ffcfc39  jmp 0x0000782C7FFCF3DC
0000782c7ffcfc3e  call 0x0000782C7FEE2420
0000782c7ffcfc43  jmp 0x0000782C7FFCF3ED
0000782c7ffcfc48  call 0x0000782C7FEE2420
0000782c7ffcfc4d  jmp 0x0000782C7FFCF3FE
0000782c7ffcfc52  call 0x0000782C7FEE2420
0000782c7ffcfc57  jmp 0x0000782C7FFCF40F
0000782c7ffcfc5c  call 0x0000782C7FEE2420
0000782c7ffcfc61  jmp 0x0000782C7FFCF420
0000782c7ffcfc66  call 0x0000782C7FEE2420
0000782c7ffcfc6b  jmp 0x0000782C7FFCF431
0000782c7ffcfc70  call 0x0000782C7FEE2420
0000782c7ffcfc75  jmp 0x0000782C7FFCF442
0000782c7ffcfc7a  call 0x0000782C7FEE2420
0000782c7ffcfc7f  jmp 0x0000782C7FFCF453
0000782c7ffcfc84  call 0x0000782C7FEE2420
0000782c7ffcfc89  jmp 0x0000782C7FFCF464
0000782c7ffcfc8e  call 0x0000782C7FEE2420
0000782c7ffcfc93  jmp 0x0000782C7FFCF475
0000782c7ffcfc98  call 0x0000782C7FEE2420
0000782c7ffcfc9d  jmp 0x0000782C7FFCF486
0000782c7ffcfca2  call 0x0000782C7FEE2420
0000782c7ffcfca7  jmp 0x0000782C7FFCF497
0000782c7ffcfcac  call 0x0000782C7FEE2420
0000782c7ffcfcb1  jmp 0x0000782C7FFCF4A8
0000782c7ffcfcb6  call 0x0000782C7FEE2420
0000782c7ffcfcbb  jmp 0x0000782C7FFCF4B9
0000782c7ffcfcc0  call 0x0000782C7FEE2420
0000782c7ffcfcc5  jmp 0x0000782C7FFCF4CA
0000782c7ffcfcca  call 0x0000782C7FEE2420
0000782c7ffcfccf  jmp 0x0000782C7FFCF4DB
0000782c7ffcfcd4  call 0x0000782C7FEE2420
0000782c7ffcfcd9  jmp 0x0000782C7FFCF4EC
0000782c7ffcfcde  call 0x0000782C7FEE2420
0000782c7ffcfce3  jmp 0x0000782C7FFCF4FD
0000782c7ffcfce8  call 0x0000782C7FEE2420
0000782c7ffcfced  jmp 0x0000782C7FFCF50E
0000782c7ffcfcf2  call 0x0000782C7FEE2420
0000782c7ffcfcf7  jmp 0x0000782C7FFCF51F
0000782c7ffcfcfc  call 0x0000782C7FEE2420
0000782c7ffcfd01  jmp 0x0000782C7FFCF530
0000782c7ffcfd06  call 0x0000782C7FEE2420
0000782c7ffcfd0b  jmp 0x0000782C7FFCF541
0000782c7ffcfd10  call 0x0000782C7FEE2420
0000782c7ffcfd15  jmp 0x0000782C7FFCF552
0000782c7ffcfd1a  call 0x0000782C7FEE2420
0000782c7ffcfd1f  jmp 0x0000782C7FFCF563
0000782c7ffcfd24  call 0x0000782C7FEE2420
0000782c7ffcfd29  jmp 0x0000782C7FFCF574
0000782c7ffcfd2e  call 0x0000782C7FEE2420
0000782c7ffcfd33  jmp 0x0000782C7FFCF585
0000782c7ffcfd38  call 0x0000782C7FEE2420
0000782c7ffcfd3d  jmp 0x0000782C7FFCF596
0000782c7ffcfd42  call 0x0000782C7FEE2420
0000782c7ffcfd47  jmp 0x0000782C7FFCF5AF
0000782c7ffcfd4c  call 0x0000782C7FEE2420
0000782c7ffcfd51  jmp 0x0000782C7FFCF5C8
0000782c7ffcfd56  call 0x0000782C7FED5610
0000782c7ffcfd5b  jmp 0x0000782C7FFCF5E1
0000782c7ffcfd60  call 0x0000782C7FEDC580
0000782c7ffcfd65  jmp 0x0000782C7FFCF94E
0000782c7ffcfd6a  call 0x0000782C7FEE46C0
0000782c7ffcfd6f  jmp 0x0000782C7FFCF958
0000782c7ffcfd74  call 0x0000782C7FE09E90
0000782c7ffcfd79  jmp 0x0000782C7FFCF95E
0000782c7ffcfd7e  call 0x0000782C7FEDB310
0000782c7ffcfd83  jmp 0x0000782C7FFCF968
0000782c7ffcfd88  call 0x0000782C7FE0DAE0
0000782c7ffcfd8d  jmp 0x0000782C7FFCF96D
0000782c7ffcfd92  call 0x0000782C7FEC0230
0000782c7ffcfd97  jmp 0x0000782C7FFCF986
0000782c7ffcfd9c  call 0x0000782C7FEC0230
0000782c7ffcfda1  jmp 0x0000782C7FFCF99B
0000782c7ffcfda6  call 0x0000782C7FEBEFC0
0000782c7ffcfdab  jmp 0x0000782C7FFCF9A4
0000782c7ffcfdb0  call 0x0000782C7FEE2BA0
0000782c7ffcfdb5  jmp 0x0000782C7FFCFA6B
0000782c7ffcfdba  int3
0000782c7ffcfdbb  nop [rax+rax*1], eax
0000782c7ffcfdc0  mov rax, [r15+0x48]
0000782c7ffcfdc4  mov r14, [r15+0x58]
0000782c7ffcfdc8  lea r12, [rax+r14*1]
0000782c7ffcfdcc  mov [r15+0x68], r12
0000782c7ffcfdd0  lea rax, [r14+0x04]
0000782c7ffcfdd4  mov [r15+0x58], rax
0000782c7ffcfdd8  lea r14, [r12+0x04]
0000782c7ffcfddd  mov r11d, [r13+r14*1]
0000782c7ffcfde2  mov [rsp+0x10], r11d
0000782c7ffcfde7  mov r11d, r11d
0000782c7ffcfdea  mov [r15+0x70], r11
0000782c7ffcfdee  lea r14, [r12+0x38]
0000782c7ffcfdf3  mov r11d, [r13+r14*1]
0000782c7ffcfdf8  lea r14, [r12+0x24]
0000782c7ffcfdfd  mov r10d, [r13+r14*1]
0000782c7ffcfe02  mov [rsp+0x20], r10d
0000782c7ffcfe07  mov r10d, r10d
0000782c7ffcfe0a  mov [r15+0x90], r10
0000782c7ffcfe11  mov [rsp+0x30], rax
0000782c7ffcfe16  xor eax, eax
0000782c7ffcfe18  mov r14, [rsp+0x30]
0000782c7ffcfe1d  mov r10d, 0xC0
0000782c7ffcfe23  cmp r14, r10
0000782c7ffcfe26  cmc
0000782c7ffcfe27  lahf
0000782c7ffcfe28  seto al
0000782c7ffcfe2b  mov [r15+0x108], eax
0000782c7ffcfe32  mov eax, [rsp+0x10]
0000782c7ffcfe36  mov r14d, [rsp+0x10]
0000782c7ffcfe3b  shrd eax, r14d, 0x07
0000782c7ffcfe40  mov [rsp+0x10], r11d
0000782c7ffcfe45  mov r10d, [rsp+0x10]
0000782c7ffcfe4a  shrd r11d, r10d, 0x11
0000782c7ffcfe4f  mov r9d, [r15+0x60]
0000782c7ffcfe53  mov r8d, [rsp+0x20]
0000782c7ffcfe58  lea ebp, [r8d+r9d*1]
0000782c7ffcfe5d  rorx r9d, r14d, 0x12
0000782c7ffcfe63  xor eax, r9d
0000782c7ffcfe66  rorx r9d, r10d, 0x13
0000782c7ffcfe6c  xor r11d, r9d
0000782c7ffcfe6f  mov [rsp+0x10], r11d
0000782c7ffcfe74  mov r11d, r11d
0000782c7ffcfe77  mov [r15+0x88], r11
0000782c7ffcfe7e  mov [rsp+0x20], r14d
0000782c7ffcfe83  shr r14d, 0x03
0000782c7ffcfe87  xor eax, r14d
0000782c7ffcfe8a  mov [rsp+0x30], eax
0000782c7ffcfe8e  mov eax, eax
0000782c7ffcfe90  mov [r15+0x80], rax
0000782c7ffcfe97  shr r10d, 0x0A
0000782c7ffcfe9b  mov eax, [rsp+0x10]
0000782c7ffcfe9f  xor eax, r10d
0000782c7ffcfea2  mov [rsp+0x10], eax
0000782c7ffcfea6  mov eax, eax
0000782c7ffcfea8  mov [r15+0x78], rax
0000782c7ffcfeac  mov eax, [rsp+0x30]
0000782c7ffcfeb0  lea r14d, [ebp+eax*1]
0000782c7ffcfeb6  mov eax, [rsp+0x10]
0000782c7ffcfeba  lea r11d, [r14d+eax*1]
0000782c7ffcfebf  lea rax, [r12+0x40]
0000782c7ffcfec4  mov [r13+rax*1], r11d
0000782c7ffcfec9  mov eax, [rsp+0x20]
0000782c7ffcfecd  mov eax, eax
0000782c7ffcfecf  mov [r15+0x60], rax
0000782c7ffcfed3  mov eax, [r15+0x108]
0000782c7ffcfeda  sahf
0000782c7ffcfedb  jnz 0x0000782C7FFCFF0D
0000782c7ffcfedd  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcfee5  jz 0x0000782C7FFCFF70
0000782c7ffcfeeb  nop [rax+rax*1], ax
0000782c7ffcfef4  nop [rax+rax*1], eax
0000782c7ffcfefc  mov eax, 0x410820
0000782c7ffcff01  mov [r15+0x100], rax
0000782c7ffcff08  jmp 0x0000782C7FDFE110
0000782c7ffcff0d  cmp dword ptr [r15+0x318], 0x00
0000782c7ffcff15  jz 0x0000782C7FFCFDC0
0000782c7ffcff1b  nop [rax+rax*1], ax
0000782c7ffcff24  nop [rax+rax*1], eax
0000782c7ffcff2c  mov eax, 0x4107D8
0000782c7ffcff31  mov [r15+0x100], rax
0000782c7ffcff38  jmp 0x0000782C7FDFE110
0000782c7ffcff3d  int3
0000782c7ffcff3e  call 0x0000782C7FEE1430
0000782c7ffcff43  jmp 0x0000782C7FFCFDE2
0000782c7ffcff48  call 0x0000782C7FEE1430
0000782c7ffcff4d  jmp 0x0000782C7FFCFDF8
0000782c7ffcff52  call 0x0000782C7FEE01C0
0000782c7ffcff57  jmp 0x0000782C7FFCFE02
0000782c7ffcff5c  call 0x0000782C7FE0A860
0000782c7ffcff61  jmp 0x0000782C7FFCFEC9
0000782c7ffcff66  int3
0000782c7ffcff67  nop [rax+rax*1], ax
0000782c7ffcff70  mov rax, [r15]
0000782c7ffcff73  mov r14d, [r13+rax*1]
0000782c7ffcff78  lea r12, [rax+0x04]
0000782c7ffcff7c  mov r11d, [r13+r12*1]
0000782c7ffcff81  mov [rsp+0x10], r14d
0000782c7ffcff86  mov r14d, r14d
0000782c7ffcff89  mov [r15+0x78], r14
0000782c7ffcff8d  mov [rsp+0x20], r11d
0000782c7ffcff92  mov r11d, r11d
0000782c7ffcff95  mov [r15+0x80], r11
0000782c7ffcff9c  lea r14, [rax+0x08]
0000782c7ffcffa0  mov r12d, [r13+r14*1]
0000782c7ffcffa5  lea r14, [rax+0x0C]
0000782c7ffcffa9  mov r11d, [r13+r14*1]
0000782c7ffcffae  mov [rsp+0x30], r12d
0000782c7ffcffb3  mov r12d, r12d
0000782c7ffcffb6  mov [r15+0x70], r12
0000782c7ffcffba  mov [rsp+0x40], r11d
0000782c7ffcffbf  mov r11d, r11d
0000782c7ffcffc2  mov [r15+0x68], r11
0000782c7ffcffc6  lea r14, [rax+0x18]
0000782c7ffcffca  mov r12d, [r13+r14*1]
0000782c7ffcffcf  lea r14, [rax+0x1C]
0000782c7ffcffd3  mov r11d, [r13+r14*1]
0000782c7ffcffd8  mov [rsp+0x50], r12d
0000782c7ffcffdd  mov r12d, r12d
0000782c7ffcffe0  mov [r15+0x58], r12
0000782c7ffcffe4  mov [rsp+0x60], r11d
0000782c7ffcffe9  mov r11d, r11d
0000782c7ffcffec  mov [r15+0x60], r11
0000782c7ffcfff0  lea r14, [rax+0x10]
0000782c7ffcfff4  mov r12d, [r13+r14*1]
0000782c7ffcfff9  lea r14, [rax+0x14]
0000782c7ffcfffd  mov eax, [r13+r14*1]
0000782c7ffd0002  mov [rsp+0x70], r12d
0000782c7ffd0007  mov r12d, r12d
0000782c7ffd000a  mov [r15+0x18], r12
0000782c7ffd000e  mov [rsp+0x80], eax
0000782c7ffd0015  mov eax, eax
0000782c7ffd0017  mov [r15+0x90], rax
0000782c7ffd001e  mov eax, [rsp+0x70]
0000782c7ffd0022  mov eax, eax
0000782c7ffd0024  mov [r15+0x30], rax
0000782c7ffd0028  mov eax, [rsp+0x50]
0000782c7ffd002c  mov eax, eax
0000782c7ffd002e  mov [r15+0xA0], rax
0000782c7ffd0035  mov eax, [rsp+0x30]
0000782c7ffd0039  mov eax, eax
0000782c7ffd003b  mov [r15+0x28], rax
0000782c7ffd003f  mov eax, [rsp+0x20]
0000782c7ffd0043  mov eax, eax
0000782c7ffd0045  mov [r15+0x98], rax
0000782c7ffd004c  mov eax, [rsp+0x10]
0000782c7ffd0050  mov eax, eax
0000782c7ffd0052  mov [r15+0x38], rax
0000782c7ffd0056  mov eax, [rsp+0x70]
0000782c7ffd005a  mov r14d, [rsp+0x70]
0000782c7ffd005f  shrd eax, r14d, 0x06
0000782c7ffd0064  mov [rsp+0x70], r14d
0000782c7ffd0069  mov r12d, [rsp+0x80]
0000782c7ffd0071  and r14d, r12d
0000782c7ffd0074  mov r11d, [rsp+0x10]
0000782c7ffd0079  mov r10d, [rsp+0x10]
0000782c7ffd007e  shrd r11d, r10d, 0x02
0000782c7ffd0083  mov [rsp+0x10], r12d
0000782c7ffd0088  mov r12d, r12d
0000782c7ffd008b  mov [r15+0x20], r12
0000782c7ffd008f  mov r12, [r15+0x50]
0000782c7ffd0093  mov r9d, [r13+r12*1]
0000782c7ffd0098  mov r12d, [rsp+0x50]
0000782c7ffd009d  mov r8d, [rsp+0x70]
0000782c7ffd00a2  andn ebp, r8d, r12d
0000782c7ffd00a7  mov edi, [rsp+0x60]
0000782c7ffd00ab  lea esi, [r14d+edi*1]
0000782c7ffd00b0  rorx r14d, r8d, 0x0B
0000782c7ffd00b6  xor eax, r14d
0000782c7ffd00b9  rorx r14d, r10d, 0x0D
0000782c7ffd00bf  xor r11d, r14d
0000782c7ffd00c2  lea edi, [esi+ebp*1]
0000782c7ffd00c6  mov r14, [r15+0x48]
0000782c7ffd00ca  mov ebp, [r13+r14*1]
0000782c7ffd00cf  mov r14d, [rsp+0x30]
0000782c7ffd00d4  mov esi, [rsp+0x20]
0000782c7ffd00d8  and r14d, esi
0000782c7ffd00db  mov [rsp+0x20], r14d
0000782c7ffd00e0  mov r14d, r14d
0000782c7ffd00e3  mov [r15+0xD8], r14
0000782c7ffd00ea  lea r14d, [edi+r9d*1]
0000782c7ffd00ef  mov r9d, [rsp+0x30]
0000782c7ffd00f4  xor r9d, esi
0000782c7ffd00f7  rorx edi, r8d, 0x19
0000782c7ffd00fd  xor eax, edi
0000782c7ffd00ff  and r9d, r10d
0000782c7ffd0102  rorx edi, r10d, 0x16
0000782c7ffd0108  xor r11d, edi
0000782c7ffd010b  mov [rsp+0x30], r11d
0000782c7ffd0110  mov r11d, r11d
0000782c7ffd0113  mov [r15+0xD0], r11
0000782c7ffd011a  lea r11d, [r14d+ebp*1]
0000782c7ffd011f  mov r10d, [rsp+0x20]
0000782c7ffd0124  xor r9d, r10d
0000782c7ffd0127  lea r14d, [r11d+eax*1]
0000782c7ffd012c  mov qword ptr [r15+0x88], 0x04
0000782c7ffd0137  mov eax, [rsp+0x30]
0000782c7ffd013b  lea r11d, [r9d+eax*1]
0000782c7ffd0140  mov eax, [rsp+0x40]
0000782c7ffd0144  lea r10d, [r14d+eax*1]
0000782c7ffd0149  mov r10d, r10d
0000782c7ffd014c  mov [r15+0xB8], r10
0000782c7ffd0153  xor eax, eax
0000782c7ffd0155  mov r10d, 0x04
0000782c7ffd015b  mov r9d, 0x100
0000782c7ffd0161  cmp r10, r9
0000782c7ffd0164  cmc
0000782c7ffd0165  lahf
0000782c7ffd0166  seto al
0000782c7ffd0169  mov [r15+0x108], eax
0000782c7ffd0170  lea eax, [r11d+r14d*1]
0000782c7ffd0175  mov eax, eax
0000782c7ffd0177  mov [r15+0xA8], rax
0000782c7ffd017e  mov r12d, r12d
0000782c7ffd0181  mov [r15+0xB0], r12
0000782c7ffd0188  mov eax, [rsp+0x10]
0000782c7ffd018c  mov eax, eax
0000782c7ffd018e  mov [r15+0xC0], rax
0000782c7ffd0195  mov r8d, r8d
0000782c7ffd0198  mov [r15+0xC8], r8
0000782c7ffd019f  mov eax, [r15+0x108]
0000782c7ffd01a6  sahf
0000782c7ffd01a7  jnz 0x0000782C7FFD01D9
0000782c7ffd01a9  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd01b1  jz 0x0000782C7FFD04A0
0000782c7ffd01b7  nop [rax+rax*1], ax
0000782c7ffd01c0  nop [rax+rax*1], eax
0000782c7ffd01c8  mov eax, 0x4108E0
0000782c7ffd01cd  mov [r15+0x100], rax
0000782c7ffd01d4  jmp 0x0000782C7FDFE110
0000782c7ffd01d9  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd01e1  jz 0x0000782C7FFD0270
0000782c7ffd01e7  nop [rax+rax*1], ax
0000782c7ffd01f0  nop [rax+rax*1], eax
0000782c7ffd01f8  mov eax, 0x410854
0000782c7ffd01fd  mov [r15+0x100], rax
0000782c7ffd0204  jmp 0x0000782C7FDFE110
0000782c7ffd0209  int3
0000782c7ffd020a  call 0x0000782C7FE0DAE0
0000782c7ffd020f  jmp 0x0000782C7FFCFF78
0000782c7ffd0214  call 0x0000782C7FEC0230
0000782c7ffd0219  jmp 0x0000782C7FFCFF81
0000782c7ffd021e  call 0x0000782C7FEE26A0
0000782c7ffd0223  jmp 0x0000782C7FFCFFA5
0000782c7ffd0228  call 0x0000782C7FEE1430
0000782c7ffd022d  jmp 0x0000782C7FFCFFAE
0000782c7ffd0232  call 0x0000782C7FEE26A0
0000782c7ffd0237  jmp 0x0000782C7FFCFFCF
0000782c7ffd023c  call 0x0000782C7FEE1430
0000782c7ffd0241  jmp 0x0000782C7FFCFFD8
0000782c7ffd0246  call 0x0000782C7FEE26A0
0000782c7ffd024b  jmp 0x0000782C7FFCFFF9
0000782c7ffd0250  call 0x0000782C7FED5890
0000782c7ffd0255  jmp 0x0000782C7FFD0002
0000782c7ffd025a  call 0x0000782C7FEBDD50
0000782c7ffd025f  jmp 0x0000782C7FFD0098
0000782c7ffd0264  call 0x0000782C7FEDA580
0000782c7ffd0269  jmp 0x0000782C7FFD00CF
0000782c7ffd026e  int3
0000782c7ffd026f  nop
0000782c7ffd0270  mov eax, [r15+0xB8]
0000782c7ffd0277  mov [rsp+0x10], eax
0000782c7ffd027b  mov eax, eax
0000782c7ffd027d  mov [r15+0x30], rax
0000782c7ffd0281  mov eax, [r15+0xC0]
0000782c7ffd0288  mov [rsp+0x20], eax
0000782c7ffd028c  mov eax, eax
0000782c7ffd028e  mov [r15+0xA0], rax
0000782c7ffd0295  mov eax, [r15+0x28]
0000782c7ffd0299  mov r14d, [r15+0x98]
0000782c7ffd02a0  mov [rsp+0x30], r14d
0000782c7ffd02a5  mov r14d, r14d
0000782c7ffd02a8  mov [r15+0x28], r14
0000782c7ffd02ac  mov r14d, [r15+0x38]
0000782c7ffd02b0  mov [rsp+0x40], r14d
0000782c7ffd02b5  mov r14d, r14d
0000782c7ffd02b8  mov [r15+0x98], r14
0000782c7ffd02bf  mov r14d, [r15+0xA8]
0000782c7ffd02c6  mov [rsp+0x50], r14d
0000782c7ffd02cb  mov r14d, r14d
0000782c7ffd02ce  mov [r15+0x38], r14
0000782c7ffd02d2  mov r14d, [rsp+0x10]
0000782c7ffd02d7  mov r12d, [rsp+0x10]
0000782c7ffd02dc  shrd r14d, r12d, 0x06
0000782c7ffd02e1  mov r11d, [r15+0xC8]
0000782c7ffd02e8  mov [rsp+0x10], r12d
0000782c7ffd02ed  and r12d, r11d
0000782c7ffd02f0  mov r10d, [rsp+0x50]
0000782c7ffd02f5  mov r9d, [rsp+0x50]
0000782c7ffd02fa  shrd r10d, r9d, 0x02
0000782c7ffd02ff  mov [rsp+0x50], r11d
0000782c7ffd0304  mov r11d, r11d
0000782c7ffd0307  mov [r15+0x20], r11
0000782c7ffd030b  mov r11, [r15+0x88]
0000782c7ffd0312  mov r8, [r15+0x50]
0000782c7ffd0316  lea rbp, [r8+r11*1]
0000782c7ffd031a  mov r8d, [r13+rbp*1]
0000782c7ffd031f  mov ebp, [rsp+0x20]
0000782c7ffd0323  mov edi, [rsp+0x10]
0000782c7ffd0327  andn esi, edi, ebp
0000782c7ffd032c  mov edx, [r15+0xB0]
0000782c7ffd0333  lea ecx, [r12d+edx*1]
0000782c7ffd0338  rorx r12d, edi, 0x0B
0000782c7ffd033e  xor r14d, r12d
0000782c7ffd0341  rorx r12d, r9d, 0x0D
0000782c7ffd0347  xor r10d, r12d
0000782c7ffd034a  lea r12d, [ecx+esi*1]
0000782c7ffd034f  mov rsi, [r15+0x48]
0000782c7ffd0353  lea rdx, [rsi+r11*1]
0000782c7ffd0357  mov esi, [r13+rdx*1]
0000782c7ffd035c  mov edx, [rsp+0x30]
0000782c7ffd0360  mov ecx, [rsp+0x40]
0000782c7ffd0364  and edx, ecx
0000782c7ffd0366  mov [rsp+0x10], edx
0000782c7ffd036a  mov edx, edx
0000782c7ffd036c  mov [r15+0xD8], rdx
0000782c7ffd0373  lea edx, [r12d+r8d*1]
0000782c7ffd0378  mov r12d, [rsp+0x30]
0000782c7ffd037d  xor r12d, ecx
0000782c7ffd0380  rorx r8d, edi, 0x19
0000782c7ffd0386  xor r14d, r8d
0000782c7ffd0389  and r12d, r9d
0000782c7ffd038c  rorx r8d, r9d, 0x16
0000782c7ffd0392  xor r10d, r8d
0000782c7ffd0395  mov [rsp+0x20], r10d
0000782c7ffd039a  mov r10d, r10d
0000782c7ffd039d  mov [r15+0xD0], r10
0000782c7ffd03a4  lea r10d, [edx+esi*1]
0000782c7ffd03a9  mov r9d, [rsp+0x10]
0000782c7ffd03ae  xor r12d, r9d
0000782c7ffd03b1  lea r9d, [r10d+r14d*1]
0000782c7ffd03b6  lea r14, [r11+0x04]
0000782c7ffd03ba  mov [r15+0x88], r14
0000782c7ffd03c1  mov r11d, [rsp+0x20]
0000782c7ffd03c6  lea r10d, [r12d+r11d*1]
0000782c7ffd03cb  lea r11d, [r9d+eax*1]
0000782c7ffd03d0  mov r11d, r11d
0000782c7ffd03d3  mov [r15+0xB8], r11
0000782c7ffd03da  xor eax, eax
0000782c7ffd03dc  mov r12d, 0x100
0000782c7ffd03e2  cmp r14, r12
0000782c7ffd03e5  cmc
0000782c7ffd03e6  lahf
0000782c7ffd03e7  seto al
0000782c7ffd03ea  mov [r15+0x108], eax
0000782c7ffd03f1  lea eax, [r10d+r9d*1]
0000782c7ffd03f6  mov eax, eax
0000782c7ffd03f8  mov [r15+0xA8], rax
0000782c7ffd03ff  mov ebp, ebp
0000782c7ffd0401  mov [r15+0xB0], rbp
0000782c7ffd0408  mov eax, [rsp+0x50]
0000782c7ffd040c  mov eax, eax
0000782c7ffd040e  mov [r15+0xC0], rax
0000782c7ffd0415  mov edi, edi
0000782c7ffd0417  mov [r15+0xC8], rdi
0000782c7ffd041e  mov eax, [r15+0x108]
0000782c7ffd0425  sahf
0000782c7ffd0426  jnz 0x0000782C7FFD0458
0000782c7ffd0428  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0430  jz 0x0000782C7FFD04A0
0000782c7ffd0436  nop [rax+rax*1], ax
0000782c7ffd043f  nop [rax+rax*1], eax
0000782c7ffd0447  mov eax, 0x4108E0
0000782c7ffd044c  mov [r15+0x100], rax
0000782c7ffd0453  jmp 0x0000782C7FDFE110
0000782c7ffd0458  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0460  jz 0x0000782C7FFD0270
0000782c7ffd0466  nop [rax+rax*1], ax
0000782c7ffd046f  nop [rax+rax*1], eax
0000782c7ffd0477  mov eax, 0x410854
0000782c7ffd047c  mov [r15+0x100], rax
0000782c7ffd0483  jmp 0x0000782C7FDFE110
0000782c7ffd0488  int3
0000782c7ffd0489  call 0x0000782C7FE49010
0000782c7ffd048e  jmp 0x0000782C7FFD031F
0000782c7ffd0493  call 0x0000782C7FE25930
0000782c7ffd0498  jmp 0x0000782C7FFD035C
0000782c7ffd049d  int3
0000782c7ffd049e  nop
0000782c7ffd04a0  mov eax, [r15+0x98]
0000782c7ffd04a7  mov r14d, [r15+0x70]
0000782c7ffd04ab  lea r12d, [eax+r14d*1]
0000782c7ffd04b0  mov eax, [r15+0x28]
0000782c7ffd04b4  mov r14d, [r15+0x68]
0000782c7ffd04b8  lea r11d, [eax+r14d*1]
0000782c7ffd04bd  mov qword ptr [r15+0x88], 0x00
0000782c7ffd04c8  mov eax, [r15+0xA8]
0000782c7ffd04cf  mov r14d, [r15+0x78]
0000782c7ffd04d3  lea r10d, [eax+r14d*1]
0000782c7ffd04d8  mov [rsp+0x10], r10d
0000782c7ffd04dd  mov r10d, r10d
0000782c7ffd04e0  mov [r15+0x78], r10
0000782c7ffd04e4  mov eax, [r15+0x38]
0000782c7ffd04e8  mov r14d, [r15+0x80]
0000782c7ffd04ef  lea r10d, [eax+r14d*1]
0000782c7ffd04f4  mov [rsp+0x20], r10d
0000782c7ffd04f9  mov r10d, r10d
0000782c7ffd04fc  mov [r15+0x80], r10
0000782c7ffd0503  mov rax, [r15]
0000782c7ffd0506  lea r14, [rax+0x08]
0000782c7ffd050a  mov [r13+r14*1], r12d
0000782c7ffd050f  lea r14, [rax+0x0C]
0000782c7ffd0513  mov [r13+r14*1], r11d
0000782c7ffd0518  mov r14d, [r15+0xB8]
0000782c7ffd051f  mov r12d, [r15+0x18]
0000782c7ffd0523  lea r11d, [r14d+r12d*1]
0000782c7ffd0528  mov [rsp+0x30], r11d
0000782c7ffd052d  mov r11d, r11d
0000782c7ffd0530  mov [r15+0x68], r11
0000782c7ffd0534  mov r14d, [r15+0x30]
0000782c7ffd0538  mov r12d, [r15+0x90]
0000782c7ffd053f  lea r11d, [r14d+r12d*1]
0000782c7ffd0544  mov [rsp+0x40], r11d
0000782c7ffd0549  mov r11d, r11d
0000782c7ffd054c  mov [r15+0x70], r11
0000782c7ffd0550  mov r14d, [r15+0x20]
0000782c7ffd0554  mov r12d, [r15+0x58]
0000782c7ffd0558  lea r11d, [r14d+r12d*1]
0000782c7ffd055d  mov [rsp+0x50], r11d
0000782c7ffd0562  mov r11d, r11d
0000782c7ffd0565  mov [r15+0x58], r11
0000782c7ffd0569  mov r14d, [r15+0xA0]
0000782c7ffd0570  mov r12d, [r15+0x60]
0000782c7ffd0574  lea r11d, [r14d+r12d*1]
0000782c7ffd0579  mov [rsp+0x60], r11d
0000782c7ffd057e  mov r11d, r11d
0000782c7ffd0581  mov [r15+0x60], r11
0000782c7ffd0585  mov r14d, [rsp+0x10]
0000782c7ffd058a  mov [r13+rax*1], r14d
0000782c7ffd058f  lea r14, [rax+0x04]
0000782c7ffd0593  mov r12d, [rsp+0x20]
0000782c7ffd0598  mov [r13+r14*1], r12d
0000782c7ffd059d  lea r14, [rax+0x10]
0000782c7ffd05a1  mov r12d, [rsp+0x30]
0000782c7ffd05a6  mov [r13+r14*1], r12d
0000782c7ffd05ab  lea r14, [rax+0x14]
0000782c7ffd05af  mov r12d, [rsp+0x40]
0000782c7ffd05b4  mov [r13+r14*1], r12d
0000782c7ffd05b9  lea r14, [rax+0x18]
0000782c7ffd05bd  mov r12d, [rsp+0x50]
0000782c7ffd05c2  mov [r13+r14*1], r12d
0000782c7ffd05c7  lea r14, [rax+0x1C]
0000782c7ffd05cb  mov r12d, [rsp+0x60]
0000782c7ffd05d0  mov [r13+r14*1], r12d
0000782c7ffd05d5  lea r14, [rax+0x68]
0000782c7ffd05d9  xor eax, eax
0000782c7ffd05db  mov [r13+r14*1], rax
0000782c7ffd05e0  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd05e8  jz 0x0000782C7FFCF0E0
0000782c7ffd05ee  nop [rax+rax*1], ax
0000782c7ffd05f7  nop [rax+rax*1], eax
0000782c7ffd05ff  mov eax, 0x4106FC
0000782c7ffd0604  mov [r15+0x100], rax
0000782c7ffd060b  jmp 0x0000782C7FDFE110
0000782c7ffd0610  int3
0000782c7ffd0611  call 0x0000782C7FEE2BA0
0000782c7ffd0616  jmp 0x0000782C7FFD050F
0000782c7ffd061b  call 0x0000782C7FEE1920
0000782c7ffd0620  jmp 0x0000782C7FFD0518
0000782c7ffd0625  call 0x0000782C7FE0DFE0
0000782c7ffd062a  jmp 0x0000782C7FFD058F
0000782c7ffd062f  call 0x0000782C7FEE2BA0
0000782c7ffd0634  jmp 0x0000782C7FFD059D
0000782c7ffd0639  call 0x0000782C7FEE2BA0
0000782c7ffd063e  jmp 0x0000782C7FFD05AB
0000782c7ffd0643  call 0x0000782C7FEE2BA0
0000782c7ffd0648  jmp 0x0000782C7FFD05B9
0000782c7ffd064d  call 0x0000782C7FEE2BA0
0000782c7ffd0652  jmp 0x0000782C7FFD05C7
0000782c7ffd0657  call 0x0000782C7FEE2BA0
0000782c7ffd065c  jmp 0x0000782C7FFD05D5
0000782c7ffd0661  call 0x0000782C7FED5EB0
0000782c7ffd0666  jmp 0x0000782C7FFD05E0
0000782c7ffd066b  int3
0000782c7ffd066c  nop [rax], eax
0000782c7ffd0670  mov rax, [r15+0xF8]
0000782c7ffd0677  lea r14, [rax+0x140]
0000782c7ffd067e  mov r12, [r13+r14*1]
0000782c7ffd0683  lea r14, [rax+0x148]
0000782c7ffd068a  mov r11, [r13+r14*1]
0000782c7ffd068f  mov [r15+0xA0], r12
0000782c7ffd0696  mov [r15+0x98], r11
0000782c7ffd069d  lea r14, [rax+0x130]
0000782c7ffd06a4  mov r12, [r13+r14*1]
0000782c7ffd06a9  lea r14, [rax+0x138]
0000782c7ffd06b0  mov r11, [r13+r14*1]
0000782c7ffd06b5  mov [r15+0xB0], r12
0000782c7ffd06bc  mov [r15+0xA8], r11
0000782c7ffd06c3  lea r14, [rax+0x120]
0000782c7ffd06ca  mov r12, [r13+r14*1]
0000782c7ffd06cf  lea r14, [rax+0x128]
0000782c7ffd06d6  mov r11, [r13+r14*1]
0000782c7ffd06db  mov [r15+0xC0], r12
0000782c7ffd06e2  mov [r15+0xB8], r11
0000782c7ffd06e9  lea r14, [rax+0x110]
0000782c7ffd06f0  mov r12, [r13+r14*1]
0000782c7ffd06f5  lea r14, [rax+0x118]
0000782c7ffd06fc  mov r11, [r13+r14*1]
0000782c7ffd0701  mov [r15+0xD0], r12
0000782c7ffd0708  mov [r15+0xC8], r11
0000782c7ffd070f  lea r14, [rax+0x100]
0000782c7ffd0716  mov r12, [r13+r14*1]
0000782c7ffd071b  lea r14, [rax+0x108]
0000782c7ffd0722  mov r11, [r13+r14*1]
0000782c7ffd0727  mov [r15+0xE8], r12
0000782c7ffd072e  mov [r15+0xD8], r11
0000782c7ffd0735  lea r14, [rax+0x150]
0000782c7ffd073c  mov [r15+0xF8], r14
0000782c7ffd0743  mov rax, [r15+0xF0]
0000782c7ffd074a  mov [r15+0x100], rax
0000782c7ffd0751  jmp 0x0000782C7FFCE5C0
0000782c7ffd0756  int3
0000782c7ffd0757  call 0x0000782C7FEE27E0
0000782c7ffd075c  jmp 0x0000782C7FFD0683
0000782c7ffd0761  call 0x0000782C7FEE1570
0000782c7ffd0766  jmp 0x0000782C7FFD068F
0000782c7ffd076b  call 0x0000782C7FEE27E0
0000782c7ffd0770  jmp 0x0000782C7FFD06A9
0000782c7ffd0775  call 0x0000782C7FEE1570
0000782c7ffd077a  jmp 0x0000782C7FFD06B5
0000782c7ffd077f  call 0x0000782C7FEE27E0
0000782c7ffd0784  jmp 0x0000782C7FFD06CF
0000782c7ffd0789  call 0x0000782C7FEE1570
0000782c7ffd078e  jmp 0x0000782C7FFD06DB
0000782c7ffd0793  call 0x0000782C7FEE27E0
0000782c7ffd0798  jmp 0x0000782C7FFD06F5
0000782c7ffd079d  call 0x0000782C7FEE1570
0000782c7ffd07a2  jmp 0x0000782C7FFD0701
0000782c7ffd07a7  call 0x0000782C7FEE27E0
0000782c7ffd07ac  jmp 0x0000782C7FFD071B
0000782c7ffd07b1  call 0x0000782C7FEE1570
0000782c7ffd07b6  jmp 0x0000782C7FFD0727
0000782c7ffd07bb  int3
0000782c7ffd07bc  nop [rax], eax
0000782c7ffd07c0  mov eax, [r15+0xA0]
0000782c7ffd07c7  mov [rsp+0x10], eax
0000782c7ffd07cb  xor eax, eax
0000782c7ffd07cd  mov r14d, [rsp+0x10]
0000782c7ffd07d2  sub r14d, 0x01
0000782c7ffd07d6  cmc
0000782c7ffd07d7  lahf
0000782c7ffd07d8  seto al
0000782c7ffd07db  mov [r15+0x108], eax
0000782c7ffd07e2  mov r14d, r14d
0000782c7ffd07e5  mov [r15+0xA0], r14
0000782c7ffd07ec  mov eax, [r15+0x108]
0000782c7ffd07f3  sahf
0000782c7ffd07f4  jnz 0x0000782C7FFD0826
0000782c7ffd07f6  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd07fe  jz 0x0000782C7FFD0900
0000782c7ffd0804  nop [rax+rax*1], ax
0000782c7ffd080d  nop [rax+rax*1], eax
0000782c7ffd0815  mov eax, 0x41028C
0000782c7ffd081a  mov [r15+0x100], rax
0000782c7ffd0821  jmp 0x0000782C7FDFE110
0000782c7ffd0826  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd082e  jz 0x0000782C7FFD0860
0000782c7ffd0834  nop [rax+rax*1], ax
0000782c7ffd083d  nop [rax+rax*1], eax
0000782c7ffd0845  mov eax, 0x410274
0000782c7ffd084a  mov [r15+0x100], rax
0000782c7ffd0851  jmp 0x0000782C7FDFE110
0000782c7ffd0856  int3
0000782c7ffd0857  int3
0000782c7ffd0858  nop [rax+rax*1], eax
0000782c7ffd0860  mov rax, [r15+0xF8]
0000782c7ffd0867  lea r14, [rax+0xD0]
0000782c7ffd086e  mov [r15], r14
0000782c7ffd0871  mov rax, [r15+0x98]
0000782c7ffd0878  mov [r15+0x08], rax
0000782c7ffd087c  mov qword ptr [r15+0x10], 0x12C
0000782c7ffd0884  mov qword ptr [r15+0xF0], 0x410284
0000782c7ffd088f  mov r14d, [r15+0x320]
0000782c7ffd0896  mov eax, 0x410284
0000782c7ffd089b  mov rcx, 0x782C7FFD07C0
0000782c7ffd08a5  mov [r15+r14*8+0x328], rax
0000782c7ffd08ad  mov [r15+r14*8+0x368], rcx
0000782c7ffd08b5  add r14d, 0x01
0000782c7ffd08b9  and r14d, 0x07
0000782c7ffd08bd  mov [r15+0x320], r14d
0000782c7ffd08c4  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd08cc  jz 0x0000782C7FFCED70
0000782c7ffd08d2  nop [rax+rax*1], ax
0000782c7ffd08db  nop [rax+rax*1], eax
0000782c7ffd08e3  mov eax, 0x4106BC
0000782c7ffd08e8  mov [r15+0x100], rax
0000782c7ffd08ef  jmp 0x0000782C7FDFE110
0000782c7ffd08f4  int3
0000782c7ffd08f5  int3
0000782c7ffd08f6  nop [rax+rax*1], ax
0000782c7ffd08ff  nop
0000782c7ffd0900  mov rax, [r15+0xF8]
0000782c7ffd0907  lea r14, [rax+0xF0]
0000782c7ffd090e  mov r12, [r13+r14*1]
0000782c7ffd0913  mov [r15+0x98], r12
0000782c7ffd091a  mov qword ptr [r15+0x40], 0x80
0000782c7ffd0922  lea r14, [rax+0xD0]
0000782c7ffd0929  mov [r15], r14
0000782c7ffd092c  lea r14, [rax+0x14C]
0000782c7ffd0933  mov [r15+0x08], r14
0000782c7ffd0937  mov qword ptr [r15+0x10], 0x01
0000782c7ffd093f  lea r14, [rax+0x14C]
0000782c7ffd0946  mov eax, 0x80
0000782c7ffd094b  mov [r13+r14*1], al
0000782c7ffd0950  mov qword ptr [r15+0xF0], 0x4102A8
0000782c7ffd095b  mov r14d, [r15+0x320]
0000782c7ffd0962  mov eax, 0x4102A8
0000782c7ffd0967  mov rcx, 0x782C7FFD09E0
0000782c7ffd0971  mov [r15+r14*8+0x328], rax
0000782c7ffd0979  mov [r15+r14*8+0x368], rcx
0000782c7ffd0981  add r14d, 0x01
0000782c7ffd0985  and r14d, 0x07
0000782c7ffd0989  mov [r15+0x320], r14d
0000782c7ffd0990  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0998  jz 0x0000782C7FFCED70
0000782c7ffd099e  nop [rax+rax*1], ax
0000782c7ffd09a7  nop [rax+rax*1], eax
0000782c7ffd09af  mov eax, 0x4106BC
0000782c7ffd09b4  mov [r15+0x100], rax
0000782c7ffd09bb  jmp 0x0000782C7FDFE110
0000782c7ffd09c0  int3
0000782c7ffd09c1  call 0x0000782C7FEE27E0
0000782c7ffd09c6  jmp 0x0000782C7FFD0913
0000782c7ffd09cb  call 0x0000782C7FED5AF0
0000782c7ffd09d0  jmp 0x0000782C7FFD0950
0000782c7ffd09d5  int3
0000782c7ffd09d6  nop [rax+rax*1], ax
0000782c7ffd09df  nop
0000782c7ffd09e0  mov rax, [r15+0xF8]
0000782c7ffd09e7  lea r14, [rax+0x138]
0000782c7ffd09ee  mov r12, [r13+r14*1]
0000782c7ffd09f3  mov [r15+0x40], r12
0000782c7ffd09f7  lea r14, [rax+0x148]
0000782c7ffd09fe  xor eax, eax
0000782c7ffd0a00  mov [r13+r14*1], al
0000782c7ffd0a05  xor eax, eax
0000782c7ffd0a07  mov r14d, 0x38
0000782c7ffd0a0d  cmp r12, r14
0000782c7ffd0a10  cmc
0000782c7ffd0a11  lahf
0000782c7ffd0a12  seto al
0000782c7ffd0a15  mov [r15+0x108], eax
0000782c7ffd0a1c  mov eax, [r15+0x108]
0000782c7ffd0a23  sahf
0000782c7ffd0a24  jz 0x0000782C7FFD0A56
0000782c7ffd0a26  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0a2e  jz 0x0000782C7FFD0AA0
0000782c7ffd0a34  nop [rax+rax*1], ax
0000782c7ffd0a3d  nop [rax+rax*1], eax
0000782c7ffd0a45  mov eax, 0x4102B8
0000782c7ffd0a4a  mov [r15+0x100], rax
0000782c7ffd0a51  jmp 0x0000782C7FDFE110
0000782c7ffd0a56  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0a5e  jz 0x0000782C7FFD0BF0
0000782c7ffd0a64  nop [rax+rax*1], ax
0000782c7ffd0a6d  nop [rax+rax*1], eax
0000782c7ffd0a75  mov eax, 0x4102D4
0000782c7ffd0a7a  mov [r15+0x100], rax
0000782c7ffd0a81  jmp 0x0000782C7FDFE110
0000782c7ffd0a86  int3
0000782c7ffd0a87  call 0x0000782C7FEE27E0
0000782c7ffd0a8c  jmp 0x0000782C7FFD09F3
0000782c7ffd0a91  call 0x0000782C7FED5AF0
0000782c7ffd0a96  jmp 0x0000782C7FFD0A05
0000782c7ffd0a9b  int3
0000782c7ffd0a9c  nop [rax], eax
0000782c7ffd0aa0  mov rax, [r15+0xF8]
0000782c7ffd0aa7  lea r14, [rax+0xD0]
0000782c7ffd0aae  mov [r15], r14
0000782c7ffd0ab1  lea r14, [rax+0x148]
0000782c7ffd0ab8  mov [r15+0x08], r14
0000782c7ffd0abc  mov qword ptr [r15+0x10], 0x01
0000782c7ffd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
0000782c7ffd0acf  mov r14d, [r15+0x320]
0000782c7ffd0ad6  mov eax, 0x4102C8
0000782c7ffd0adb  mov rcx, 0x782C7FFD0B40
0000782c7ffd0ae5  mov [r15+r14*8+0x328], rax
0000782c7ffd0aed  mov [r15+r14*8+0x368], rcx
0000782c7ffd0af5  add r14d, 0x01
0000782c7ffd0af9  and r14d, 0x07
0000782c7ffd0afd  mov [r15+0x320], r14d
0000782c7ffd0b04  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0b0c  jz 0x0000782C7FFCED70
0000782c7ffd0b12  nop [rax+rax*1], ax
0000782c7ffd0b1b  nop [rax+rax*1], eax
0000782c7ffd0b23  mov eax, 0x4106BC
0000782c7ffd0b28  mov [r15+0x100], rax
0000782c7ffd0b2f  jmp 0x0000782C7FDFE110
0000782c7ffd0b34  int3
0000782c7ffd0b35  int3
0000782c7ffd0b36  nop [rax+rax*1], ax
0000782c7ffd0b3f  nop
0000782c7ffd0b40  mov rax, [r15+0xF8]
0000782c7ffd0b47  lea r14, [rax+0x138]
0000782c7ffd0b4e  mov rax, [r13+r14*1]
0000782c7ffd0b53  mov [r15+0x40], rax
0000782c7ffd0b57  mov [rsp+0x10], rax
0000782c7ffd0b5c  xor eax, eax
0000782c7ffd0b5e  mov r14, [rsp+0x10]
0000782c7ffd0b63  mov r12d, 0x38
0000782c7ffd0b69  cmp r14, r12
0000782c7ffd0b6c  cmc
0000782c7ffd0b6d  lahf
0000782c7ffd0b6e  seto al
0000782c7ffd0b71  mov [r15+0x108], eax
0000782c7ffd0b78  mov eax, [r15+0x108]
0000782c7ffd0b7f  sahf
0000782c7ffd0b80  jnz 0x0000782C7FFD0BB2
0000782c7ffd0b82  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0b8a  jz 0x0000782C7FFD0BF0
0000782c7ffd0b90  nop [rax+rax*1], ax
0000782c7ffd0b99  nop [rax+rax*1], eax
0000782c7ffd0ba1  mov eax, 0x4102D4
0000782c7ffd0ba6  mov [r15+0x100], rax
0000782c7ffd0bad  jmp 0x0000782C7FDFE110
0000782c7ffd0bb2  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0bba  jz 0x0000782C7FFD0AA0
0000782c7ffd0bc0  nop [rax+rax*1], ax
0000782c7ffd0bc9  nop [rax+rax*1], eax
0000782c7ffd0bd1  mov eax, 0x4102B8
0000782c7ffd0bd6  mov [r15+0x100], rax
0000782c7ffd0bdd  jmp 0x0000782C7FDFE110
0000782c7ffd0be2  int3
0000782c7ffd0be3  call 0x0000782C7FED59C0
0000782c7ffd0be8  jmp 0x0000782C7FFD0B53
0000782c7ffd0bed  int3
0000782c7ffd0bee  nop
0000782c7ffd0bf0  mov rax, [r15+0x98]
0000782c7ffd0bf7  rorx r14, rax, 0x3D
0000782c7ffd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
0000782c7ffd0c01  mov rax, [r15+0xF8]
0000782c7ffd0c08  lea r12, [rax+0xD0]
0000782c7ffd0c0f  mov [r15], r12
0000782c7ffd0c12  lea r12, [rax+0x140]
0000782c7ffd0c19  mov [r15+0x08], r12
0000782c7ffd0c1d  mov qword ptr [r15+0x10], 0x08
0000782c7ffd0c25  bswap r14
0000782c7ffd0c28  mov [r15+0x40], r14
0000782c7ffd0c2c  lea r12, [rax+0x140]
0000782c7ffd0c33  mov [r13+r12*1], r14
0000782c7ffd0c38  mov qword ptr [r15+0xF0], 0x4102F0
0000782c7ffd0c43  mov r14d, [r15+0x320]
0000782c7ffd0c4a  mov eax, 0x4102F0
0000782c7ffd0c4f  mov rcx, 0x782C7FFD0CC0
0000782c7ffd0c59  mov [r15+r14*8+0x328], rax
0000782c7ffd0c61  mov [r15+r14*8+0x368], rcx
0000782c7ffd0c69  add r14d, 0x01
0000782c7ffd0c6d  and r14d, 0x07
0000782c7ffd0c71  mov [r15+0x320], r14d
0000782c7ffd0c78  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0c80  jz 0x0000782C7FFCED70
0000782c7ffd0c86  nop [rax+rax*1], ax
0000782c7ffd0c8f  nop [rax+rax*1], eax
0000782c7ffd0c97  mov eax, 0x4106BC
0000782c7ffd0c9c  mov [r15+0x100], rax
0000782c7ffd0ca3  jmp 0x0000782C7FDFE110
0000782c7ffd0ca8  int3
0000782c7ffd0ca9  call 0x0000782C7FEC3FE0
0000782c7ffd0cae  jmp 0x0000782C7FFD0C38
0000782c7ffd0cb3  int3
0000782c7ffd0cb4  nop [rax+rax*1], ax
0000782c7ffd0cbd  nop [rax], eax
0000782c7ffd0cc0  mov rax, [r15+0xF8]
0000782c7ffd0cc7  lea r14, [rax+0xD0]
0000782c7ffd0cce  mov r12d, [r13+r14*1]
0000782c7ffd0cd3  lea r14, [rax+0xD4]
0000782c7ffd0cda  mov r11d, [r13+r14*1]
0000782c7ffd0cdf  lea r14, [rax+0xD8]
0000782c7ffd0ce6  mov r10d, [r13+r14*1]
0000782c7ffd0ceb  lea r14, [rax+0xDC]
0000782c7ffd0cf2  mov r9d, [r13+r14*1]
0000782c7ffd0cf7  mov qword ptr [r15+0x48], 0x430C20
0000782c7ffd0cff  mov qword ptr [r15+0xA0], 0x00
0000782c7ffd0d0a  bswap r12d
0000782c7ffd0d0d  bswap r11d
0000782c7ffd0d10  mov qword ptr [r15+0x98], 0x430D8C
0000782c7ffd0d1b  mov r14d, 0x430C20
0000782c7ffd0d21  mov [r13+r14*1], r12d
0000782c7ffd0d26  mov r14d, 0x430C24
0000782c7ffd0d2c  mov [r13+r14*1], r11d
0000782c7ffd0d31  bswap r10d
0000782c7ffd0d34  bswap r9d
0000782c7ffd0d37  lea r14, [rax+0xE0]
0000782c7ffd0d3e  mov r12d, [r13+r14*1]
0000782c7ffd0d43  lea r14, [rax+0xE4]
0000782c7ffd0d4a  mov r11d, [r13+r14*1]
0000782c7ffd0d4f  mov r14d, 0x430C28
0000782c7ffd0d55  mov [r13+r14*1], r10d
0000782c7ffd0d5a  mov r14d, 0x430C2C
0000782c7ffd0d60  mov [r13+r14*1], r9d
0000782c7ffd0d65  bswap r12d
0000782c7ffd0d68  bswap r11d
0000782c7ffd0d6b  mov [rsp+0x10], r11d
0000782c7ffd0d70  mov r11d, r11d
0000782c7ffd0d73  mov [r15+0x58], r11
0000782c7ffd0d77  lea r14, [rax+0xE8]
0000782c7ffd0d7e  mov r11d, [r13+r14*1]
0000782c7ffd0d83  lea r14, [rax+0xEC]
0000782c7ffd0d8a  mov eax, [r13+r14*1]
0000782c7ffd0d8f  mov [rsp+0x20], eax
0000782c7ffd0d93  mov eax, eax
0000782c7ffd0d95  mov [r15+0x60], rax
0000782c7ffd0d99  mov eax, 0x430C30
0000782c7ffd0d9e  mov [r13+rax*1], r12d
0000782c7ffd0da3  mov eax, 0x430C34
0000782c7ffd0da8  mov r14d, [rsp+0x10]
0000782c7ffd0dad  mov [r13+rax*1], r14d
0000782c7ffd0db2  bswap r11d
0000782c7ffd0db5  mov [rsp+0x10], r11d
0000782c7ffd0dba  mov r11d, r11d
0000782c7ffd0dbd  mov [r15+0x40], r11
0000782c7ffd0dc1  mov eax, [rsp+0x20]
0000782c7ffd0dc5  bswap eax
0000782c7ffd0dc7  mov [rsp+0x20], eax
0000782c7ffd0dcb  mov eax, eax
0000782c7ffd0dcd  mov [r15+0x50], rax
0000782c7ffd0dd1  mov eax, 0x430C38
0000782c7ffd0dd6  mov r14d, [rsp+0x10]
0000782c7ffd0ddb  mov [r13+rax*1], r14d
0000782c7ffd0de0  mov eax, 0x430C3C
0000782c7ffd0de5  mov r14d, [rsp+0x20]
0000782c7ffd0dea  mov [r13+rax*1], r14d
0000782c7ffd0def  mov eax, [r15+0xA0]
0000782c7ffd0df6  lea r14d, [eax+0x11]
0000782c7ffd0dfb  mov r14d, r14d
0000782c7ffd0dfe  mov [r15], r14
0000782c7ffd0e01  mov qword ptr [r15+0xF0], 0x41034C
0000782c7ffd0e0c  mov r14d, [r15+0x320]
0000782c7ffd0e13  mov eax, 0x41034C
0000782c7ffd0e18  mov rcx, 0x782C7FFD0F90
0000782c7ffd0e22  mov [r15+r14*8+0x328], rax
0000782c7ffd0e2a  mov [r15+r14*8+0x368], rcx
0000782c7ffd0e32  add r14d, 0x01
0000782c7ffd0e36  and r14d, 0x07
0000782c7ffd0e3a  mov [r15+0x320], r14d
0000782c7ffd0e41  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0e49  jz 0x0000782C7FFD0F20
0000782c7ffd0e4f  nop [rax+rax*1], ax
0000782c7ffd0e58  nop [rax+rax*1], eax
0000782c7ffd0e60  mov eax, 0x410938
0000782c7ffd0e65  mov [r15+0x100], rax
0000782c7ffd0e6c  jmp 0x0000782C7FDFE110
0000782c7ffd0e71  int3
0000782c7ffd0e72  call 0x0000782C7FEE26A0
0000782c7ffd0e77  jmp 0x0000782C7FFD0CD3
0000782c7ffd0e7c  call 0x0000782C7FEE1430
0000782c7ffd0e81  jmp 0x0000782C7FFD0CDF
0000782c7ffd0e86  call 0x0000782C7FEE01C0
0000782c7ffd0e8b  jmp 0x0000782C7FFD0CEB
0000782c7ffd0e90  call 0x0000782C7FEDEF50
0000782c7ffd0e95  jmp 0x0000782C7FFD0CF7
0000782c7ffd0e9a  call 0x0000782C7FEE2BA0
0000782c7ffd0e9f  jmp 0x0000782C7FFD0D26
0000782c7ffd0ea4  call 0x0000782C7FEE1920
0000782c7ffd0ea9  jmp 0x0000782C7FFD0D31
0000782c7ffd0eae  call 0x0000782C7FEE26A0
0000782c7ffd0eb3  jmp 0x0000782C7FFD0D43
0000782c7ffd0eb8  call 0x0000782C7FEE1430
0000782c7ffd0ebd  jmp 0x0000782C7FFD0D4F
0000782c7ffd0ec2  call 0x0000782C7FEE06B0
0000782c7ffd0ec7  jmp 0x0000782C7FFD0D5A
0000782c7ffd0ecc  call 0x0000782C7FEDF440
0000782c7ffd0ed1  jmp 0x0000782C7FFD0D65
0000782c7ffd0ed6  call 0x0000782C7FEE1430
0000782c7ffd0edb  jmp 0x0000782C7FFD0D83
0000782c7ffd0ee0  call 0x0000782C7FED5890
0000782c7ffd0ee5  jmp 0x0000782C7FFD0D8F
0000782c7ffd0eea  call 0x0000782C7FE0BAE0
0000782c7ffd0eef  jmp 0x0000782C7FFD0DA3
0000782c7ffd0ef4  call 0x0000782C7FE0DFE0
0000782c7ffd0ef9  jmp 0x0000782C7FFD0DB2
0000782c7ffd0efe  call 0x0000782C7FE0DFE0
0000782c7ffd0f03  jmp 0x0000782C7FFD0DE0
0000782c7ffd0f08  call 0x0000782C7FE0DFE0
0000782c7ffd0f0d  jmp 0x0000782C7FFD0DEF
0000782c7ffd0f12  int3
0000782c7ffd0f13  nop [rax+rax*1], ax
0000782c7ffd0f1c  nop [rax], eax
0000782c7ffd0f20  mov eax, [r15]
0000782c7ffd0f23  mov [rsp+0x10], eax
0000782c7ffd0f27  shr eax, 0x10
0000782c7ffd0f2a  mov r14d, [rsp+0x10]
0000782c7ffd0f2f  xor r14d, eax
0000782c7ffd0f32  imul r14d, r14d, 0x7FEB352D
0000782c7ffd0f39  mov eax, 0x846CA68B
0000782c7ffd0f3e  mov eax, eax
0000782c7ffd0f40  mov [r15+0x48], rax
0000782c7ffd0f44  mov [rsp+0x10], r14d
0000782c7ffd0f49  shr r14d, 0x0F
0000782c7ffd0f4d  mov eax, [rsp+0x10]
0000782c7ffd0f51  xor eax, r14d
0000782c7ffd0f54  imul eax, eax, 0x846CA68B
0000782c7ffd0f5a  mov [rsp+0x10], eax
0000782c7ffd0f5e  mov eax, eax
0000782c7ffd0f60  mov [r15+0x40], rax
0000782c7ffd0f64  mov eax, [rsp+0x10]
0000782c7ffd0f68  shr eax, 0x10
0000782c7ffd0f6b  mov r14d, [rsp+0x10]
0000782c7ffd0f70  xor r14d, eax
0000782c7ffd0f73  mov r14d, r14d
0000782c7ffd0f76  mov [r15], r14
0000782c7ffd0f79  mov rax, [r15+0xF0]
0000782c7ffd0f80  mov [r15+0x100], rax
0000782c7ffd0f87  jmp 0x0000782C7FFCE5C0
0000782c7ffd0f8c  int3
0000782c7ffd0f8d  int3
0000782c7ffd0f8e  nop
0000782c7ffd0f90  mov rax, [r15+0xA0]
0000782c7ffd0f97  mov [rsp+0x10], rax
0000782c7ffd0f9c  shl rax, 0x02
0000782c7ffd0fa0  mov r14, [r15+0x98]
0000782c7ffd0fa7  lea r12, [r14+rax*1]
0000782c7ffd0fab  mov eax, [r15]
0000782c7ffd0fae  mov [r13+r12*1], eax
0000782c7ffd0fb3  mov rax, [rsp+0x10]
0000782c7ffd0fb8  lea r14, [rax+0x01]
0000782c7ffd0fbc  mov [r15+0xA0], r14
0000782c7ffd0fc3  xor eax, eax
0000782c7ffd0fc5  mov r12d, 0x400
0000782c7ffd0fcb  cmp r14, r12
0000782c7ffd0fce  cmc
0000782c7ffd0fcf  lahf
0000782c7ffd0fd0  seto al
0000782c7ffd0fd3  mov [r15+0x108], eax
0000782c7ffd0fda  mov eax, [r15+0x108]
0000782c7ffd0fe1  sahf
0000782c7ffd0fe2  jnz 0x0000782C7FFD1014
0000782c7ffd0fe4  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd0fec  jz 0x0000782C7FFD10E0
0000782c7ffd0ff2  nop [rax+rax*1], ax
0000782c7ffd0ffb  nop [rax+rax*1], eax
0000782c7ffd1003  mov eax, 0x41035C
0000782c7ffd1008  mov [r15+0x100], rax
0000782c7ffd100f  jmp 0x0000782C7FDFE110
0000782c7ffd1014  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd101c  jz 0x0000782C7FFD1050
0000782c7ffd1022  nop [rax+rax*1], ax
0000782c7ffd102b  nop [rax+rax*1], eax
0000782c7ffd1033  mov eax, 0x410344
0000782c7ffd1038  mov [r15+0x100], rax
0000782c7ffd103f  jmp 0x0000782C7FDFE110
0000782c7ffd1044  int3
0000782c7ffd1045  call 0x0000782C7FEB4B70
0000782c7ffd104a  jmp 0x0000782C7FFD0FB3
0000782c7ffd104f  int3
0000782c7ffd1050  mov eax, [r15+0xA0]
0000782c7ffd1057  lea r14d, [eax+0x11]
0000782c7ffd105c  mov r14d, r14d
0000782c7ffd105f  mov [r15], r14
0000782c7ffd1062  mov qword ptr [r15+0xF0], 0x41034C
0000782c7ffd106d  mov r14d, [r15+0x320]
0000782c7ffd1074  mov eax, 0x41034C
0000782c7ffd1079  mov rcx, 0x782C7FFD0F90
0000782c7ffd1083  mov [r15+r14*8+0x328], rax
0000782c7ffd108b  mov [r15+r14*8+0x368], rcx
0000782c7ffd1093  add r14d, 0x01
0000782c7ffd1097  and r14d, 0x07
0000782c7ffd109b  mov [r15+0x320], r14d
0000782c7ffd10a2  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd10aa  jz 0x0000782C7FFD0F20
0000782c7ffd10b0  nop [rax+rax*1], ax
0000782c7ffd10b9  nop [rax+rax*1], eax
0000782c7ffd10c1  mov eax, 0x410938
0000782c7ffd10c6  mov [r15+0x100], rax
0000782c7ffd10cd  jmp 0x0000782C7FDFE110
0000782c7ffd10d2  int3
0000782c7ffd10d3  int3
0000782c7ffd10d4  nop [rax+rax*1], ax
0000782c7ffd10dd  nop [rax], eax
0000782c7ffd10e0  mov qword ptr [r15+0x40], 0x01
0000782c7ffd10e8  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd10f0  jz 0x0000782C7FFD1120
0000782c7ffd10f6  nop [rax+rax*1], ax
0000782c7ffd10ff  nop [rax+rax*1], eax
0000782c7ffd1107  mov eax, 0x410378
0000782c7ffd110c  mov [r15+0x100], rax
0000782c7ffd1113  jmp 0x0000782C7FDFE110
0000782c7ffd1118  int3
0000782c7ffd1119  int3
0000782c7ffd111a  nop [rax+rax*1], ax
0000782c7ffd1120  mov rax, [r15+0x40]
0000782c7ffd1124  mov [rsp+0x10], rax
0000782c7ffd1129  shl rax, 0x02
0000782c7ffd112d  mov r14, [r15+0x98]
0000782c7ffd1134  lea r12, [r14+rax*1]
0000782c7ffd1138  mov eax, [r13+r12*1]
0000782c7ffd113d  mov [rsp+0x20], eax
0000782c7ffd1141  mov eax, eax
0000782c7ffd1143  mov [r15+0x48], rax
0000782c7ffd1147  mov rax, [rsp+0x10]
0000782c7ffd114c  mov [r15+0x50], rax
0000782c7ffd1150  mov eax, [r15+0x50]
0000782c7ffd1154  lea r12d, [eax-0x01]
0000782c7ffd1159  mov r12d, r12d
0000782c7ffd115c  mov [r15+0x58], r12
0000782c7ffd1160  mov rax, [r15+0x58]
0000782c7ffd1164  mov r12d, eax
0000782c7ffd1167  mov r12d, r12d
0000782c7ffd116a  shl r12, 0x02
0000782c7ffd116e  lea rax, [r14+r12*1]
0000782c7ffd1172  mov r14d, [r13+rax*1]
0000782c7ffd1177  mov [rsp+0x10], r14d
0000782c7ffd117c  mov r14d, r14d
0000782c7ffd117f  mov [r15+0x60], r14
0000782c7ffd1183  xor eax, eax
0000782c7ffd1185  mov r14d, [rsp+0x10]
0000782c7ffd118a  mov r12d, [rsp+0x20]
0000782c7ffd118f  cmp r14d, r12d
0000782c7ffd1192  cmc
0000782c7ffd1193  lahf
0000782c7ffd1194  seto al
0000782c7ffd1197  mov [r15+0x108], eax
0000782c7ffd119e  mov eax, [r15+0x108]
0000782c7ffd11a5  sahf
0000782c7ffd11a6  cmc
0000782c7ffd11a7  jbe 0x0000782C7FFD11D9
0000782c7ffd11a9  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd11b1  jz 0x0000782C7FFD1220
0000782c7ffd11b7  nop [rax+rax*1], ax
0000782c7ffd11c0  nop [rax+rax*1], eax
0000782c7ffd11c8  mov eax, 0x410390
0000782c7ffd11cd  mov [r15+0x100], rax
0000782c7ffd11d4  jmp 0x0000782C7FDFE110
0000782c7ffd11d9  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd11e1  jz 0x0000782C7FFD14C0
0000782c7ffd11e7  nop [rax+rax*1], ax
0000782c7ffd11f0  nop [rax+rax*1], eax
0000782c7ffd11f8  mov eax, 0x410368
0000782c7ffd11fd  mov [r15+0x100], rax
0000782c7ffd1204  jmp 0x0000782C7FDFE110
0000782c7ffd1209  int3
0000782c7ffd120a  call 0x0000782C7FEB4690
0000782c7ffd120f  jmp 0x0000782C7FFD113D
0000782c7ffd1214  call 0x0000782C7FE0DAE0
0000782c7ffd1219  jmp 0x0000782C7FFD1177
0000782c7ffd121e  int3
0000782c7ffd121f  nop
0000782c7ffd1220  mov rax, [r15+0x50]
0000782c7ffd1224  mov [rsp+0x10], rax
0000782c7ffd1229  shl rax, 0x02
0000782c7ffd122d  mov r14, [r15+0x98]
0000782c7ffd1234  lea r12, [r14+rax*1]
0000782c7ffd1238  mov eax, [r15+0x60]
0000782c7ffd123c  mov [r13+r12*1], eax
0000782c7ffd1241  mov rax, [rsp+0x10]
0000782c7ffd1246  lea r14, [rax-0x01]
0000782c7ffd124a  mov [r15+0x50], r14
0000782c7ffd124e  mov rax, [r15+0x58]
0000782c7ffd1252  test rax, rax
0000782c7ffd1255  setz al
0000782c7ffd1258  movzx rax, al
0000782c7ffd125c  mov [rsp+0x414], al
0000782c7ffd1263  cmp byte ptr [rsp+0x414], 0x00
0000782c7ffd126b  jz 0x0000782C7FFD129D
0000782c7ffd126d  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd1275  jz 0x0000782C7FFD12E0
0000782c7ffd127b  nop [rax+rax*1], ax
0000782c7ffd1284  nop [rax+rax*1], eax
0000782c7ffd128c  mov eax, 0x41039C
0000782c7ffd1291  mov [r15+0x100], rax
0000782c7ffd1298  jmp 0x0000782C7FDFE110
0000782c7ffd129d  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd12a5  jz 0x0000782C7FFD13E0
0000782c7ffd12ab  nop [rax+rax*1], ax
0000782c7ffd12b4  nop [rax+rax*1], eax
0000782c7ffd12bc  mov eax, 0x410380
0000782c7ffd12c1  mov [r15+0x100], rax
0000782c7ffd12c8  jmp 0x0000782C7FDFE110
0000782c7ffd12cd  int3
0000782c7ffd12ce  call 0x0000782C7FEB4B70
0000782c7ffd12d3  jmp 0x0000782C7FFD1241
0000782c7ffd12d8  int3
0000782c7ffd12d9  nop [rax], eax
0000782c7ffd12e0  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd12e8  jz 0x0000782C7FFD1320
0000782c7ffd12ee  nop [rax+rax*1], ax
0000782c7ffd12f7  nop [rax+rax*1], eax
0000782c7ffd12ff  mov eax, 0x410364
0000782c7ffd1304  mov [r15+0x100], rax
0000782c7ffd130b  jmp 0x0000782C7FDFE110
0000782c7ffd1310  int3
0000782c7ffd1311  int3
0000782c7ffd1312  nop [rax+rax*1], ax
0000782c7ffd131b  nop [rax+rax*1], eax
0000782c7ffd1320  mov qword ptr [r15+0x50], 0x00
0000782c7ffd1328  mov rax, [r15+0x40]
0000782c7ffd132c  lea r14, [rax+0x01]
0000782c7ffd1330  mov [r15+0x40], r14
0000782c7ffd1334  mov rax, [r15+0x98]
0000782c7ffd133b  mov r12d, [r15+0x48]
0000782c7ffd133f  mov [r13+rax*1], r12d
0000782c7ffd1344  xor eax, eax
0000782c7ffd1346  mov r12d, 0x400
0000782c7ffd134c  cmp r14, r12
0000782c7ffd134f  cmc
0000782c7ffd1350  lahf
0000782c7ffd1351  seto al
0000782c7ffd1354  mov [r15+0x108], eax
0000782c7ffd135b  mov eax, [r15+0x108]
0000782c7ffd1362  sahf
0000782c7ffd1363  jz 0x0000782C7FFD1395
0000782c7ffd1365  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd136d  jz 0x0000782C7FFD1120
0000782c7ffd1373  nop [rax+rax*1], ax
0000782c7ffd137c  nop [rax+rax*1], eax
0000782c7ffd1384  mov eax, 0x410378
0000782c7ffd1389  mov [r15+0x100], rax
0000782c7ffd1390  jmp 0x0000782C7FDFE110
0000782c7ffd1395  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd139d  jz 0x0000782C7FFD1580
0000782c7ffd13a3  nop [rax+rax*1], ax
0000782c7ffd13ac  nop [rax+rax*1], eax
0000782c7ffd13b4  mov eax, 0x4103A0
0000782c7ffd13b9  mov [r15+0x100], rax
0000782c7ffd13c0  jmp 0x0000782C7FDFE110
0000782c7ffd13c5  int3
0000782c7ffd13c6  call 0x0000782C7FE0BAE0
0000782c7ffd13cb  jmp 0x0000782C7FFD1344
0000782c7ffd13d0  int3
0000782c7ffd13d1  nop [rax+rax*1], ax
0000782c7ffd13da  nop [rax+rax*1], ax
0000782c7ffd13e0  mov eax, [r15+0x50]
0000782c7ffd13e4  lea r14d, [eax-0x01]
0000782c7ffd13e9  mov r14d, r14d
0000782c7ffd13ec  mov [r15+0x58], r14
0000782c7ffd13f0  mov rax, [r15+0x58]
0000782c7ffd13f4  mov r14d, eax
0000782c7ffd13f7  mov r14d, r14d
0000782c7ffd13fa  shl r14, 0x02
0000782c7ffd13fe  mov rax, [r15+0x98]
0000782c7ffd1405  lea r12, [rax+r14*1]
0000782c7ffd1409  mov eax, [r13+r12*1]
0000782c7ffd140e  mov [rsp+0x10], eax
0000782c7ffd1412  mov eax, eax
0000782c7ffd1414  mov [r15+0x60], rax
0000782c7ffd1418  mov eax, [r15+0x48]
0000782c7ffd141c  mov [rsp+0x20], eax
0000782c7ffd1420  xor eax, eax
0000782c7ffd1422  mov r14d, [rsp+0x10]
0000782c7ffd1427  mov r12d, [rsp+0x20]
0000782c7ffd142c  cmp r14d, r12d
0000782c7ffd142f  cmc
0000782c7ffd1430  lahf
0000782c7ffd1431  seto al
0000782c7ffd1434  mov [r15+0x108], eax
0000782c7ffd143b  mov eax, [r15+0x108]
0000782c7ffd1442  sahf
0000782c7ffd1443  cmc
0000782c7ffd1444  jbe 0x0000782C7FFD1476
0000782c7ffd1446  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd144e  jz 0x0000782C7FFD1220
0000782c7ffd1454  nop [rax+rax*1], ax
0000782c7ffd145d  nop [rax+rax*1], eax
0000782c7ffd1465  mov eax, 0x410390
0000782c7ffd146a  mov [r15+0x100], rax
0000782c7ffd1471  jmp 0x0000782C7FDFE110
0000782c7ffd1476  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd147e  jz 0x0000782C7FFD14C0
0000782c7ffd1484  nop [rax+rax*1], ax
0000782c7ffd148d  nop [rax+rax*1], eax
0000782c7ffd1495  mov eax, 0x410368
0000782c7ffd149a  mov [r15+0x100], rax
0000782c7ffd14a1  jmp 0x0000782C7FDFE110
0000782c7ffd14a6  int3
0000782c7ffd14a7  call 0x0000782C7FEB4690
0000782c7ffd14ac  jmp 0x0000782C7FFD140E
0000782c7ffd14b1  int3
0000782c7ffd14b2  nop [rax+rax*1], ax
0000782c7ffd14bb  nop [rax+rax*1], eax
0000782c7ffd14c0  mov rax, [r15+0x40]
0000782c7ffd14c4  lea r14, [rax+0x01]
0000782c7ffd14c8  mov [r15+0x40], r14
0000782c7ffd14cc  mov rax, [r15+0x50]
0000782c7ffd14d0  mov r12d, eax
0000782c7ffd14d3  mov r12d, r12d
0000782c7ffd14d6  shl r12, 0x02
0000782c7ffd14da  mov rax, [r15+0x98]
0000782c7ffd14e1  lea r11, [rax+r12*1]
0000782c7ffd14e5  mov eax, [r15+0x48]
0000782c7ffd14e9  mov [r13+r11*1], eax
0000782c7ffd14ee  xor eax, eax
0000782c7ffd14f0  mov r12d, 0x400
0000782c7ffd14f6  cmp r14, r12
0000782c7ffd14f9  cmc
0000782c7ffd14fa  lahf
0000782c7ffd14fb  seto al
0000782c7ffd14fe  mov [r15+0x108], eax
0000782c7ffd1505  mov eax, [r15+0x108]
0000782c7ffd150c  sahf
0000782c7ffd150d  jz 0x0000782C7FFD153F
0000782c7ffd150f  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd1517  jz 0x0000782C7FFD1120
0000782c7ffd151d  nop [rax+rax*1], ax
0000782c7ffd1526  nop [rax+rax*1], eax
0000782c7ffd152e  mov eax, 0x410378
0000782c7ffd1533  mov [r15+0x100], rax
0000782c7ffd153a  jmp 0x0000782C7FDFE110
0000782c7ffd153f  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd1547  jz 0x0000782C7FFD1580
0000782c7ffd154d  nop [rax+rax*1], ax
0000782c7ffd1556  nop [rax+rax*1], eax
0000782c7ffd155e  mov eax, 0x4103A0
0000782c7ffd1563  mov [r15+0x100], rax
0000782c7ffd156a  jmp 0x0000782C7FDFE110
0000782c7ffd156f  int3
0000782c7ffd1570  call 0x0000782C7FEA4270
0000782c7ffd1575  jmp 0x0000782C7FFD14EE
0000782c7ffd157a  int3
0000782c7ffd157b  nop [rax+rax*1], eax
0000782c7ffd1580  mov qword ptr [r15+0x40], 0x430000
0000782c7ffd1588  mov eax, 0x430C40
0000782c7ffd158d  mov r14, [r13+rax*1]
0000782c7ffd1592  mov rax, [r15+0x98]
0000782c7ffd1599  mov r12d, [r13+rax*1]
0000782c7ffd159e  lea r11, [rax+0x04]
0000782c7ffd15a2  mov eax, [r13+r11*1]
0000782c7ffd15a7  mov r12d, r12d
0000782c7ffd15aa  mov [r15+0x68], r12
0000782c7ffd15ae  mov eax, eax
0000782c7ffd15b0  mov [r15+0x60], rax
0000782c7ffd15b4  mov rax, [r15+0x68]
0000782c7ffd15b8  mov [r15+0x68], rax
0000782c7ffd15bc  mov qword ptr [r15+0x58], 0x02
0000782c7ffd15c4  mov [rsp+0x10], rax
0000782c7ffd15c9  xor eax, eax
0000782c7ffd15cb  mov r12d, 0x02
0000782c7ffd15d1  mov r11d, 0x400
0000782c7ffd15d7  cmp r12, r11
0000782c7ffd15da  cmc
0000782c7ffd15db  lahf
0000782c7ffd15dc  seto al
0000782c7ffd15df  mov [r15+0x108], eax
0000782c7ffd15e6  mov rax, [r15+0x60]
0000782c7ffd15ea  mov r12d, 0x02
0000782c7ffd15f0  imul rax, r12
0000782c7ffd15f4  mov [r15+0x50], rax
0000782c7ffd15f8  mov rax, [rsp+0x10]
0000782c7ffd15fd  lea r12, [rax+r14*1]
0000782c7ffd1601  mov [r15+0x48], r12
0000782c7ffd1605  mov eax, [r15+0x108]
0000782c7ffd160c  sahf
0000782c7ffd160d  jnz 0x0000782C7FFD163F
0000782c7ffd160f  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd1617  jz 0x0000782C7FFD17B0
0000782c7ffd161d  nop [rax+rax*1], ax
0000782c7ffd1626  nop [rax+rax*1], eax
0000782c7ffd162e  mov eax, 0x4103D0
0000782c7ffd1633  mov [r15+0x100], rax
0000782c7ffd163a  jmp 0x0000782C7FDFE110
0000782c7ffd163f  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd1647  jz 0x0000782C7FFD1690
0000782c7ffd164d  nop [rax+rax*1], ax
0000782c7ffd1656  nop [rax+rax*1], eax
0000782c7ffd165e  mov eax, 0x4103B0
0000782c7ffd1663  mov [r15+0x100], rax
0000782c7ffd166a  jmp 0x0000782C7FDFE110
0000782c7ffd166f  int3
0000782c7ffd1670  call 0x0000782C7FE0DC20
0000782c7ffd1675  jmp 0x0000782C7FFD1592
0000782c7ffd167a  call 0x0000782C7FE0B5E0
0000782c7ffd167f  jmp 0x0000782C7FFD159E
0000782c7ffd1684  call 0x0000782C7FEA3D90
0000782c7ffd1689  jmp 0x0000782C7FFD15A7
0000782c7ffd168e  int3
0000782c7ffd168f  nop
0000782c7ffd1690  mov rax, [r15+0x98]
0000782c7ffd1697  mov r14, [r15+0x58]
0000782c7ffd169b  mov [rsp+0x10], r14
0000782c7ffd16a0  shl r14, 0x02
0000782c7ffd16a4  lea r12, [rax+r14*1]
0000782c7ffd16a8  mov eax, [r13+r12*1]
0000782c7ffd16ad  lea r14, [r12+0x04]
0000782c7ffd16b2  mov r12d, [r13+r14*1]
0000782c7ffd16b7  mov eax, eax
0000782c7ffd16b9  mov [r15+0x68], rax
0000782c7ffd16bd  mov r12d, r12d
0000782c7ffd16c0  mov [r15+0x60], r12
0000782c7ffd16c4  mov rax, [r15+0x68]
0000782c7ffd16c8  mov [rsp+0x20], rax
0000782c7ffd16cd  mov r14, [rsp+0x10]
0000782c7ffd16d2  imul rax, r14
0000782c7ffd16d6  mov r12, [rsp+0x20]
0000782c7ffd16db  lea r11, [r12+rax*1]
0000782c7ffd16df  mov [r15+0x68], r11
0000782c7ffd16e3  lea rax, [r14+0x02]
0000782c7ffd16e7  mov [r15+0x58], rax
0000782c7ffd16eb  mov [rsp+0x10], rax
0000782c7ffd16f0  xor eax, eax
0000782c7ffd16f2  mov r14, [rsp+0x10]
0000782c7ffd16f7  mov r12d, 0x400
0000782c7ffd16fd  cmp r14, r12
0000782c7ffd1700  cmc
0000782c7ffd1701  lahf
0000782c7ffd1702  seto al
0000782c7ffd1705  mov [r15+0x108], eax
0000782c7ffd170c  mov rax, [r15+0x50]
0000782c7ffd1710  mov r12, [r15+0x60]
0000782c7ffd1714  imul r14, r12
0000782c7ffd1718  lea r12, [rax+r14*1]
0000782c7ffd171c  mov [r15+0x50], r12
0000782c7ffd1720  mov rax, [r15+0x48]
0000782c7ffd1724  lea r14, [r11+rax*1]
0000782c7ffd1728  mov [r15+0x48], r14
0000782c7ffd172c  mov eax, [r15+0x108]
0000782c7ffd1733  sahf
0000782c7ffd1734  jnz 0x0000782C7FFD1766
0000782c7ffd1736  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd173e  jz 0x0000782C7FFD17B0
0000782c7ffd1744  nop [rax+rax*1], ax
0000782c7ffd174d  nop [rax+rax*1], eax
0000782c7ffd1755  mov eax, 0x4103D0
0000782c7ffd175a  mov [r15+0x100], rax
0000782c7ffd1761  jmp 0x0000782C7FDFE110
0000782c7ffd1766  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd176e  jz 0x0000782C7FFD1690
0000782c7ffd1774  nop [rax+rax*1], ax
0000782c7ffd177d  nop [rax+rax*1], eax
0000782c7ffd1785  mov eax, 0x4103B0
0000782c7ffd178a  mov [r15+0x100], rax
0000782c7ffd1791  jmp 0x0000782C7FDFE110
0000782c7ffd1796  int3
0000782c7ffd1797  call 0x0000782C7FEB4690
0000782c7ffd179c  jmp 0x0000782C7FFD16AD
0000782c7ffd17a1  call 0x0000782C7FEE26A0
0000782c7ffd17a6  jmp 0x0000782C7FFD16B7
0000782c7ffd17ab  int3
0000782c7ffd17ac  nop [rax], eax
0000782c7ffd17b0  mov qword ptr [r15+0x98], 0x00
0000782c7ffd17bb  mov rax, [r15+0x50]
0000782c7ffd17bf  mov r14, [r15+0x48]
0000782c7ffd17c3  lea r12, [rax+r14*1]
0000782c7ffd17c7  mov [r15+0x48], r12
0000782c7ffd17cb  mov rax, [r15+0x40]
0000782c7ffd17cf  lea r14, [rax+0xC40]
0000782c7ffd17d6  mov [r13+r14*1], r12
0000782c7ffd17db  mov qword ptr [r15], 0x01
0000782c7ffd17e2  mov qword ptr [r15+0xF0], 0x4103E8
0000782c7ffd17ed  mov r14d, [r15+0x320]
0000782c7ffd17f4  mov eax, 0x4103E8
0000782c7ffd17f9  mov rcx, 0x782C7FFD1860
0000782c7ffd1803  mov [r15+r14*8+0x328], rax
0000782c7ffd180b  mov [r15+r14*8+0x368], rcx
0000782c7ffd1813  add r14d, 0x01
0000782c7ffd1817  and r14d, 0x07
0000782c7ffd181b  mov [r15+0x320], r14d
0000782c7ffd1822  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd182a  jz 0x0000782C7FFD0F20
0000782c7ffd1830  nop [rax+rax*1], ax
0000782c7ffd1839  nop [rax+rax*1], eax
0000782c7ffd1841  mov eax, 0x410938
0000782c7ffd1846  mov [r15+0x100], rax
0000782c7ffd184d  jmp 0x0000782C7FDFE110
0000782c7ffd1852  int3
0000782c7ffd1853  call 0x0000782C7FEE2CE0
0000782c7ffd1858  jmp 0x0000782C7FFD17DB
0000782c7ffd185d  int3
0000782c7ffd185e  nop
0000782c7ffd1860  mov eax, [r15+0x98]
0000782c7ffd1867  lea r14d, [eax+0x01]
0000782c7ffd186c  mov [rsp+0x10], r14d
0000782c7ffd1871  mov r14d, r14d
0000782c7ffd1874  mov [r15+0x98], r14
0000782c7ffd187b  xor eax, eax
0000782c7ffd187d  mov r14d, [rsp+0x10]
0000782c7ffd1882  cmp r14d, 0x10000
0000782c7ffd1889  cmc
0000782c7ffd188a  lahf
0000782c7ffd188b  seto al
0000782c7ffd188e  mov [r15+0x108], eax
0000782c7ffd1895  mov eax, [r15+0x108]
0000782c7ffd189c  sahf
0000782c7ffd189d  jnz 0x0000782C7FFD18CF
0000782c7ffd189f  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd18a7  jz 0x0000782C7FFD19A0
0000782c7ffd18ad  nop [rax+rax*1], ax
0000782c7ffd18b6  nop [rax+rax*1], eax
0000782c7ffd18be  mov eax, 0x4103F4
0000782c7ffd18c3  mov [r15+0x100], rax
0000782c7ffd18ca  jmp 0x0000782C7FDFE110
0000782c7ffd18cf  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd18d7  jz 0x0000782C7FFD1910
0000782c7ffd18dd  nop [rax+rax*1], ax
0000782c7ffd18e6  nop [rax+rax*1], eax
0000782c7ffd18ee  mov eax, 0x4103E0
0000782c7ffd18f3  mov [r15+0x100], rax
0000782c7ffd18fa  jmp 0x0000782C7FDFE110
0000782c7ffd18ff  int3
0000782c7ffd1900  int3
0000782c7ffd1901  nop [rax+rax*1], ax
0000782c7ffd190a  nop [rax+rax*1], ax
0000782c7ffd1910  mov eax, [r15]
0000782c7ffd1913  mov r14d, [r15+0x98]
0000782c7ffd191a  lea r12d, [eax+r14d*1]
0000782c7ffd191f  mov r12d, r12d
0000782c7ffd1922  mov [r15], r12
0000782c7ffd1925  mov qword ptr [r15+0xF0], 0x4103E8
0000782c7ffd1930  mov r14d, [r15+0x320]
0000782c7ffd1937  mov eax, 0x4103E8
0000782c7ffd193c  mov rcx, 0x782C7FFD1860
0000782c7ffd1946  mov [r15+r14*8+0x328], rax
0000782c7ffd194e  mov [r15+r14*8+0x368], rcx
0000782c7ffd1956  add r14d, 0x01
0000782c7ffd195a  and r14d, 0x07
0000782c7ffd195e  mov [r15+0x320], r14d
0000782c7ffd1965  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd196d  jz 0x0000782C7FFD0F20
0000782c7ffd1973  nop [rax+rax*1], ax
0000782c7ffd197c  nop [rax+rax*1], eax
0000782c7ffd1984  mov eax, 0x410938
0000782c7ffd1989  mov [r15+0x100], rax
0000782c7ffd1990  jmp 0x0000782C7FDFE110
0000782c7ffd1995  int3
0000782c7ffd1996  int3
0000782c7ffd1997  nop [rax+rax*1], ax
0000782c7ffd19a0  vmovaps xmm1, [0x0000782C7FBFE010]
0000782c7ffd19a8  movq xmm1, xmm1
0000782c7ffd19ac  movaps [r15+0x110], xmm1
0000782c7ffd19b4  mov eax, 0x420AA0
0000782c7ffd19b9  mov r14, [r13+rax*1]
0000782c7ffd19be  movq xmm1, r14
0000782c7ffd19c3  movaps [r15+0x120], xmm1
0000782c7ffd19cb  vmovaps xmm1, [0x0000782C7FBFE020]
0000782c7ffd19d3  movq xmm1, xmm1
0000782c7ffd19d7  movaps [r15+0x140], xmm1
0000782c7ffd19df  vmovaps xmm1, [0x0000782C7FBFE030]
0000782c7ffd19e7  vpbroadcastq xmm1, xmm1
0000782c7ffd19ec  movaps [r15+0x150], xmm1
0000782c7ffd19f4  mov qword ptr [r15+0x40], 0x02
0000782c7ffd19fc  vmovaps xmm15, [0x0000782C7FBFE040]
0000782c7ffd1a04  movq xmm15, xmm15
0000782c7ffd1a09  movaps [r15+0x160], xmm15
0000782c7ffd1a11  vmovaps xmm15, [0x0000782C7FBFE050]
0000782c7ffd1a19  vpbroadcastq xmm15, xmm15
0000782c7ffd1a1e  movaps [r15+0x130], xmm15
0000782c7ffd1a26  mov rax, [r15+0x40]
0000782c7ffd1a2a  vmovq xmm14, rax
0000782c7ffd1a2f  vpbroadcastq xmm14, xmm14
0000782c7ffd1a34  movaps [r15+0x170], xmm14
0000782c7ffd1a3c  mov eax, 0x4209D0
0000782c7ffd1a41  movups xmm13, [r13+rax*1]
0000782c7ffd1a47  mov qword ptr [r15+0x40], 0x431D90
0000782c7ffd1a4f  mov eax, [r15]
0000782c7ffd1a52  mov r14d, 0x430C48
0000782c7ffd1a58  mov [r13+r14*1], eax
0000782c7ffd1a5d  mov qword ptr [r15+0x50], 0x431F90
0000782c7ffd1a65  vpmovqd xmm12, xmm13
0000782c7ffd1a6b  pxor xmm11, xmm11
0000782c7ffd1a70  punpcklqdq xmm12, xmm11
0000782c7ffd1a75  movaps [r15+0x210], xmm12
0000782c7ffd1a7d  movq xmm12, qword ptr [r15+0x140]
0000782c7ffd1a86  movq xmm11, qword ptr [r15+0x120]
0000782c7ffd1a8f  psubd xmm12, xmm11
0000782c7ffd1a94  movq xmm12, xmm12
0000782c7ffd1a99  paddq xmm13, xmm14
0000782c7ffd1a9e  movaps [r15+0x180], xmm13
0000782c7ffd1aa6  movq xmm14, qword ptr [r15+0x160]
0000782c7ffd1aaf  paddd xmm11, xmm14
0000782c7ffd1ab4  movq xmm11, xmm11
0000782c7ffd1ab9  movq xmm11, xmm11
0000782c7ffd1abe  movaps [r15+0x120], xmm11
0000782c7ffd1ac6  pmovzxdq xmm12, xmm12
0000782c7ffd1acc  psllq xmm12, 0x00
0000782c7ffd1ad2  movq xmm14, qword ptr [r15+0x210]
0000782c7ffd1adb  movq xmm13, qword ptr [r15+0x110]
0000782c7ffd1ae4  paddd xmm14, xmm13
0000782c7ffd1ae9  movq xmm14, xmm14
0000782c7ffd1aee  vcvtuqq2pd xmm12, xmm12
0000782c7ffd1af4  pmovzxdq xmm14, xmm14
0000782c7ffd1afa  psllq xmm14, 0x00
0000782c7ffd1b00  vcvtuqq2pd xmm14, xmm14
0000782c7ffd1b06  movaps xmm13, xmm12
0000782c7ffd1b0a  mulpd xmm13, xmm1
0000782c7ffd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
0000782c7ffd1b15  ptest xmm11, xmm11
0000782c7ffd1b1b  jnz 0x0000782C7FFD1C0F
0000782c7ffd1b21  movaps [r15+0x220], xmm13
0000782c7ffd1b29  mov eax, 0x431F90
0000782c7ffd1b2e  movups [r13+rax*1], xmm13
0000782c7ffd1b34  movaps xmm1, xmm14
0000782c7ffd1b38  mulpd xmm1, xmm15
0000782c7ffd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
0000782c7ffd1b42  ptest xmm13, xmm13
0000782c7ffd1b48  jnz 0x0000782C7FFD1D5C
0000782c7ffd1b4e  movaps [r15+0x210], xmm1
0000782c7ffd1b56  mov eax, 0x431D90
0000782c7ffd1b5b  movups [r13+rax*1], xmm1
0000782c7ffd1b61  mov qword ptr [r15+0x48], 0x10
0000782c7ffd1b69  xor eax, eax
0000782c7ffd1b6b  mov r14d, 0x10
0000782c7ffd1b71  mov r12d, 0x200
0000782c7ffd1b77  cmp r14, r12
0000782c7ffd1b7a  cmc
0000782c7ffd1b7b  lahf
0000782c7ffd1b7c  seto al
0000782c7ffd1b7f  mov [r15+0x108], eax
0000782c7ffd1b86  mov eax, [r15+0x108]
0000782c7ffd1b8d  sahf
0000782c7ffd1b8e  jnz 0x0000782C7FFD1BC0
0000782c7ffd1b90  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd1b98  jz 0x0000782C7FFD2300
0000782c7ffd1b9e  nop [rax+rax*1], ax
0000782c7ffd1ba7  nop [rax+rax*1], eax
0000782c7ffd1baf  mov eax, 0x410480
0000782c7ffd1bb4  mov [r15+0x100], rax
0000782c7ffd1bbb  jmp 0x0000782C7FDFE110
0000782c7ffd1bc0  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd1bc8  jz 0x0000782C7FFD1EB0
0000782c7ffd1bce  nop [rax+rax*1], ax
0000782c7ffd1bd7  nop [rax+rax*1], eax
0000782c7ffd1bdf  mov eax, 0x410440
0000782c7ffd1be4  mov [r15+0x100], rax
0000782c7ffd1beb  jmp 0x0000782C7FDFE110
0000782c7ffd1bf0  int3
0000782c7ffd1bf1  call 0x0000782C7FE0DC20
0000782c7ffd1bf6  jmp 0x0000782C7FFD19BE
0000782c7ffd1bfb  call 0x0000782C7FE0C260
0000782c7ffd1c00  jmp 0x0000782C7FFD1A47
0000782c7ffd1c05  call 0x0000782C7FED5D70
0000782c7ffd1c0a  jmp 0x0000782C7FFD1A5D
0000782c7ffd1c0f  sub rsp, 0x08
0000782c7ffd1c13  push rax
0000782c7ffd1c14  push rcx
0000782c7ffd1c15  push rdx
0000782c7ffd1c16  push rdi
0000782c7ffd1c17  push rsi
0000782c7ffd1c18  push r8
0000782c7ffd1c1a  push r9
0000782c7ffd1c1c  push r10
0000782c7ffd1c1e  push r11
0000782c7ffd1c20  sub rsp, 0xF0
0000782c7ffd1c27  vmovaps [rsp], xmm0
0000782c7ffd1c2c  vmovaps [rsp+0x10], xmm1
0000782c7ffd1c32  vmovaps [rsp+0x20], xmm2
0000782c7ffd1c38  vmovaps [rsp+0x30], xmm3
0000782c7ffd1c3e  vmovaps [rsp+0x40], xmm4
0000782c7ffd1c44  vmovaps [rsp+0x50], xmm5
0000782c7ffd1c4a  vmovaps [rsp+0x60], xmm6
0000782c7ffd1c50  vmovaps [rsp+0x70], xmm7
0000782c7ffd1c56  vmovaps [rsp+0x80], xmm8
0000782c7ffd1c5f  vmovaps [rsp+0x90], xmm9
0000782c7ffd1c68  vmovaps [rsp+0xA0], xmm10
0000782c7ffd1c71  vmovaps [rsp+0xB0], xmm11
0000782c7ffd1c7a  vmovaps [rsp+0xC0], xmm12
0000782c7ffd1c83  vmovaps [rsp+0xD0], xmm14
0000782c7ffd1c8c  vmovaps [rsp+0xE0], xmm15
0000782c7ffd1c95  sub rsp, 0x30
0000782c7ffd1c99  movaps [rsp], xmm13
0000782c7ffd1c9e  movaps [rsp+0x10], xmm12
0000782c7ffd1ca4  movaps [rsp+0x20], xmm1
0000782c7ffd1ca9  lea rdi, [rsp]
0000782c7ffd1cad  mov esi, 0x00
0000782c7ffd1cb2  mov rax, 0x5AE5BFFB5530
0000782c7ffd1cbc  call rax
0000782c7ffd1cbe  movaps xmm13, [rsp]
0000782c7ffd1cc3  add rsp, 0x30
0000782c7ffd1cc7  vmovaps xmm0, [rsp]
0000782c7ffd1ccc  vmovaps xmm1, [rsp+0x10]
0000782c7ffd1cd2  vmovaps xmm2, [rsp+0x20]
0000782c7ffd1cd8  vmovaps xmm3, [rsp+0x30]
0000782c7ffd1cde  vmovaps xmm4, [rsp+0x40]
0000782c7ffd1ce4  vmovaps xmm5, [rsp+0x50]
0000782c7ffd1cea  vmovaps xmm6, [rsp+0x60]
0000782c7ffd1cf0  vmovaps xmm7, [rsp+0x70]
0000782c7ffd1cf6  vmovaps xmm8, [rsp+0x80]
0000782c7ffd1cff  vmovaps xmm9, [rsp+0x90]
0000782c7ffd1d08  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd1d11  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd1d1a  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd1d23  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd1d2c  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd1d35  add rsp, 0xF0
0000782c7ffd1d3c  pop r11
0000782c7ffd1d3e  pop r10
0000782c7ffd1d40  pop r9
0000782c7ffd1d42  pop r8
0000782c7ffd1d44  pop rsi
0000782c7ffd1d45  pop rdi
0000782c7ffd1d46  pop rdx
0000782c7ffd1d47  pop rcx
0000782c7ffd1d48  pop rax
0000782c7ffd1d49  add rsp, 0x08
0000782c7ffd1d4d  jmp 0x0000782C7FFD1B21
0000782c7ffd1d52  call 0x0000782C7FE0C380
0000782c7ffd1d57  jmp 0x0000782C7FFD1B34
0000782c7ffd1d5c  sub rsp, 0x08
0000782c7ffd1d60  push rax
0000782c7ffd1d61  push rcx
0000782c7ffd1d62  push rdx
0000782c7ffd1d63  push rdi
0000782c7ffd1d64  push rsi
0000782c7ffd1d65  push r8
0000782c7ffd1d67  push r9
0000782c7ffd1d69  push r10
0000782c7ffd1d6b  push r11
0000782c7ffd1d6d  sub rsp, 0xF0
0000782c7ffd1d74  vmovaps [rsp], xmm0
0000782c7ffd1d79  vmovaps [rsp+0x10], xmm2
0000782c7ffd1d7f  vmovaps [rsp+0x20], xmm3
0000782c7ffd1d85  vmovaps [rsp+0x30], xmm4
0000782c7ffd1d8b  vmovaps [rsp+0x40], xmm5
0000782c7ffd1d91  vmovaps [rsp+0x50], xmm6
0000782c7ffd1d97  vmovaps [rsp+0x60], xmm7
0000782c7ffd1d9d  vmovaps [rsp+0x70], xmm8
0000782c7ffd1da3  vmovaps [rsp+0x80], xmm9
0000782c7ffd1dac  vmovaps [rsp+0x90], xmm10
0000782c7ffd1db5  vmovaps [rsp+0xA0], xmm11
0000782c7ffd1dbe  vmovaps [rsp+0xB0], xmm12
0000782c7ffd1dc7  vmovaps [rsp+0xC0], xmm13
0000782c7ffd1dd0  vmovaps [rsp+0xD0], xmm14
0000782c7ffd1dd9  vmovaps [rsp+0xE0], xmm15
0000782c7ffd1de2  sub rsp, 0x30
0000782c7ffd1de6  movaps [rsp], xmm1
0000782c7ffd1dea  movaps [rsp+0x10], xmm14
0000782c7ffd1df0  movaps [rsp+0x20], xmm15
0000782c7ffd1df6  lea rdi, [rsp]
0000782c7ffd1dfa  mov esi, 0x00
0000782c7ffd1dff  mov rax, 0x5AE5BFFB5530
0000782c7ffd1e09  call rax
0000782c7ffd1e0b  movaps xmm1, [rsp]
0000782c7ffd1e0f  add rsp, 0x30
0000782c7ffd1e13  vmovaps xmm0, [rsp]
0000782c7ffd1e18  vmovaps xmm2, [rsp+0x10]
0000782c7ffd1e1e  vmovaps xmm3, [rsp+0x20]
0000782c7ffd1e24  vmovaps xmm4, [rsp+0x30]
0000782c7ffd1e2a  vmovaps xmm5, [rsp+0x40]
0000782c7ffd1e30  vmovaps xmm6, [rsp+0x50]
0000782c7ffd1e36  vmovaps xmm7, [rsp+0x60]
0000782c7ffd1e3c  vmovaps xmm8, [rsp+0x70]
0000782c7ffd1e42  vmovaps xmm9, [rsp+0x80]
0000782c7ffd1e4b  vmovaps xmm10, [rsp+0x90]
0000782c7ffd1e54  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd1e5d  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd1e66  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd1e6f  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd1e78  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd1e81  add rsp, 0xF0
0000782c7ffd1e88  pop r11
0000782c7ffd1e8a  pop r10
0000782c7ffd1e8c  pop r9
0000782c7ffd1e8e  pop r8
0000782c7ffd1e90  pop rsi
0000782c7ffd1e91  pop rdi
0000782c7ffd1e92  pop rdx
0000782c7ffd1e93  pop rcx
0000782c7ffd1e94  pop rax
0000782c7ffd1e95  add rsp, 0x08
0000782c7ffd1e99  jmp 0x0000782C7FFD1B4E
0000782c7ffd1e9e  call 0x0000782C7FDFF540
0000782c7ffd1ea3  jmp 0x0000782C7FFD1B61
0000782c7ffd1ea8  int3
0000782c7ffd1ea9  nop [rax], eax
0000782c7ffd1eb0  movaps xmm1, [r15+0x180]
0000782c7ffd1eb8  vpmovqd xmm15, xmm1
0000782c7ffd1ebe  pxor xmm14, xmm14
0000782c7ffd1ec3  punpcklqdq xmm15, xmm14
0000782c7ffd1ec8  movaps [r15+0x210], xmm15
0000782c7ffd1ed0  movq xmm15, qword ptr [r15+0x140]
0000782c7ffd1ed9  movq xmm14, qword ptr [r15+0x120]
0000782c7ffd1ee2  psubd xmm15, xmm14
0000782c7ffd1ee7  movq xmm15, xmm15
0000782c7ffd1eec  movaps xmm13, [r15+0x170]
0000782c7ffd1ef4  paddq xmm1, xmm13
0000782c7ffd1ef9  movaps [r15+0x180], xmm1
0000782c7ffd1f01  movq xmm1, qword ptr [r15+0x160]
0000782c7ffd1f0a  paddd xmm14, xmm1
0000782c7ffd1f0f  movq xmm14, xmm14
0000782c7ffd1f14  movq xmm14, xmm14
0000782c7ffd1f19  movaps [r15+0x120], xmm14
0000782c7ffd1f21  pmovzxdq xmm15, xmm15
0000782c7ffd1f27  psllq xmm15, 0x00
0000782c7ffd1f2d  movq xmm1, qword ptr [r15+0x210]
0000782c7ffd1f36  movq xmm14, qword ptr [r15+0x110]
0000782c7ffd1f3f  paddd xmm1, xmm14
0000782c7ffd1f44  movq xmm1, xmm1
0000782c7ffd1f48  vcvtuqq2pd xmm15, xmm15
0000782c7ffd1f4e  pmovzxdq xmm1, xmm1
0000782c7ffd1f53  psllq xmm1, 0x00
0000782c7ffd1f58  vcvtuqq2pd xmm1, xmm1
0000782c7ffd1f5e  movaps xmm14, [r15+0x150]
0000782c7ffd1f66  movaps xmm13, xmm15
0000782c7ffd1f6a  mulpd xmm13, xmm14
0000782c7ffd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd1f75  ptest xmm12, xmm12
0000782c7ffd1f7b  jnz 0x0000782C7FFD205E
0000782c7ffd1f81  movaps [r15+0x220], xmm13
0000782c7ffd1f89  mov rax, [r15+0x48]
0000782c7ffd1f8d  mov r14, [r15+0x50]
0000782c7ffd1f91  lea r12, [r14+rax*1]
0000782c7ffd1f95  movups [r13+r12*1], xmm13
0000782c7ffd1f9b  movaps xmm15, [r15+0x130]
0000782c7ffd1fa3  movaps xmm14, xmm1
0000782c7ffd1fa7  mulpd xmm14, xmm15
0000782c7ffd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
0000782c7ffd1fb2  ptest xmm13, xmm13
0000782c7ffd1fb8  jnz 0x0000782C7FFD21AC
0000782c7ffd1fbe  movaps [r15+0x210], xmm14
0000782c7ffd1fc6  mov r14, [r15+0x40]
0000782c7ffd1fca  lea r12, [r14+rax*1]
0000782c7ffd1fce  movups [r13+r12*1], xmm14
0000782c7ffd1fd4  lea r14, [rax+0x10]
0000782c7ffd1fd8  mov [r15+0x48], r14
0000782c7ffd1fdc  xor eax, eax
0000782c7ffd1fde  mov r12d, 0x200
0000782c7ffd1fe4  cmp r14, r12
0000782c7ffd1fe7  cmc
0000782c7ffd1fe8  lahf
0000782c7ffd1fe9  seto al
0000782c7ffd1fec  mov [r15+0x108], eax
0000782c7ffd1ff3  mov eax, [r15+0x108]
0000782c7ffd1ffa  sahf
0000782c7ffd1ffb  jnz 0x0000782C7FFD202D
0000782c7ffd1ffd  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd2005  jz 0x0000782C7FFD2300
0000782c7ffd200b  nop [rax+rax*1], ax
0000782c7ffd2014  nop [rax+rax*1], eax
0000782c7ffd201c  mov eax, 0x410480
0000782c7ffd2021  mov [r15+0x100], rax
0000782c7ffd2028  jmp 0x0000782C7FDFE110
0000782c7ffd202d  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd2035  jz 0x0000782C7FFD1EB0
0000782c7ffd203b  nop [rax+rax*1], ax
0000782c7ffd2044  nop [rax+rax*1], eax
0000782c7ffd204c  mov eax, 0x410440
0000782c7ffd2051  mov [r15+0x100], rax
0000782c7ffd2058  jmp 0x0000782C7FDFE110
0000782c7ffd205d  int3
0000782c7ffd205e  sub rsp, 0x08
0000782c7ffd2062  push rax
0000782c7ffd2063  push rcx
0000782c7ffd2064  push rdx
0000782c7ffd2065  push rdi
0000782c7ffd2066  push rsi
0000782c7ffd2067  push r8
0000782c7ffd2069  push r9
0000782c7ffd206b  push r10
0000782c7ffd206d  push r11
0000782c7ffd206f  sub rsp, 0xF0
0000782c7ffd2076  vmovaps [rsp], xmm0
0000782c7ffd207b  vmovaps [rsp+0x10], xmm1
0000782c7ffd2081  vmovaps [rsp+0x20], xmm2
0000782c7ffd2087  vmovaps [rsp+0x30], xmm3
0000782c7ffd208d  vmovaps [rsp+0x40], xmm4
0000782c7ffd2093  vmovaps [rsp+0x50], xmm5
0000782c7ffd2099  vmovaps [rsp+0x60], xmm6
0000782c7ffd209f  vmovaps [rsp+0x70], xmm7
0000782c7ffd20a5  vmovaps [rsp+0x80], xmm8
0000782c7ffd20ae  vmovaps [rsp+0x90], xmm9
0000782c7ffd20b7  vmovaps [rsp+0xA0], xmm10
0000782c7ffd20c0  vmovaps [rsp+0xB0], xmm11
0000782c7ffd20c9  vmovaps [rsp+0xC0], xmm12
0000782c7ffd20d2  vmovaps [rsp+0xD0], xmm14
0000782c7ffd20db  vmovaps [rsp+0xE0], xmm15
0000782c7ffd20e4  sub rsp, 0x30
0000782c7ffd20e8  movaps [rsp], xmm13
0000782c7ffd20ed  movaps [rsp+0x10], xmm15
0000782c7ffd20f3  movaps [rsp+0x20], xmm14
0000782c7ffd20f9  lea rdi, [rsp]
0000782c7ffd20fd  mov esi, 0x00
0000782c7ffd2102  mov rax, 0x5AE5BFFB5530
0000782c7ffd210c  call rax
0000782c7ffd210e  movaps xmm13, [rsp]
0000782c7ffd2113  add rsp, 0x30
0000782c7ffd2117  vmovaps xmm0, [rsp]
0000782c7ffd211c  vmovaps xmm1, [rsp+0x10]
0000782c7ffd2122  vmovaps xmm2, [rsp+0x20]
0000782c7ffd2128  vmovaps xmm3, [rsp+0x30]
0000782c7ffd212e  vmovaps xmm4, [rsp+0x40]
0000782c7ffd2134  vmovaps xmm5, [rsp+0x50]
0000782c7ffd213a  vmovaps xmm6, [rsp+0x60]
0000782c7ffd2140  vmovaps xmm7, [rsp+0x70]
0000782c7ffd2146  vmovaps xmm8, [rsp+0x80]
0000782c7ffd214f  vmovaps xmm9, [rsp+0x90]
0000782c7ffd2158  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd2161  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd216a  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd2173  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd217c  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd2185  add rsp, 0xF0
0000782c7ffd218c  pop r11
0000782c7ffd218e  pop r10
0000782c7ffd2190  pop r9
0000782c7ffd2192  pop r8
0000782c7ffd2194  pop rsi
0000782c7ffd2195  pop rdi
0000782c7ffd2196  pop rdx
0000782c7ffd2197  pop rcx
0000782c7ffd2198  pop rax
0000782c7ffd2199  add rsp, 0x08
0000782c7ffd219d  jmp 0x0000782C7FFD1F81
0000782c7ffd21a2  call 0x0000782C7FEC2240
0000782c7ffd21a7  jmp 0x0000782C7FFD1F9B
0000782c7ffd21ac  sub rsp, 0x08
0000782c7ffd21b0  push rax
0000782c7ffd21b1  push rcx
0000782c7ffd21b2  push rdx
0000782c7ffd21b3  push rdi
0000782c7ffd21b4  push rsi
0000782c7ffd21b5  push r8
0000782c7ffd21b7  push r9
0000782c7ffd21b9  push r10
0000782c7ffd21bb  push r11
0000782c7ffd21bd  sub rsp, 0xF0
0000782c7ffd21c4  vmovaps [rsp], xmm0
0000782c7ffd21c9  vmovaps [rsp+0x10], xmm1
0000782c7ffd21cf  vmovaps [rsp+0x20], xmm2
0000782c7ffd21d5  vmovaps [rsp+0x30], xmm3
0000782c7ffd21db  vmovaps [rsp+0x40], xmm4
0000782c7ffd21e1  vmovaps [rsp+0x50], xmm5
0000782c7ffd21e7  vmovaps [rsp+0x60], xmm6
0000782c7ffd21ed  vmovaps [rsp+0x70], xmm7
0000782c7ffd21f3  vmovaps [rsp+0x80], xmm8
0000782c7ffd21fc  vmovaps [rsp+0x90], xmm9
0000782c7ffd2205  vmovaps [rsp+0xA0], xmm10
0000782c7ffd220e  vmovaps [rsp+0xB0], xmm11
0000782c7ffd2217  vmovaps [rsp+0xC0], xmm12
0000782c7ffd2220  vmovaps [rsp+0xD0], xmm13
0000782c7ffd2229  vmovaps [rsp+0xE0], xmm15
0000782c7ffd2232  sub rsp, 0x30
0000782c7ffd2236  movaps [rsp], xmm14
0000782c7ffd223b  movaps [rsp+0x10], xmm1
0000782c7ffd2240  movaps [rsp+0x20], xmm15
0000782c7ffd2246  lea rdi, [rsp]
0000782c7ffd224a  mov esi, 0x00
0000782c7ffd224f  mov rax, 0x5AE5BFFB5530
0000782c7ffd2259  call rax
0000782c7ffd225b  movaps xmm14, [rsp]
0000782c7ffd2260  add rsp, 0x30
0000782c7ffd2264  vmovaps xmm0, [rsp]
0000782c7ffd2269  vmovaps xmm1, [rsp+0x10]
0000782c7ffd226f  vmovaps xmm2, [rsp+0x20]
0000782c7ffd2275  vmovaps xmm3, [rsp+0x30]
0000782c7ffd227b  vmovaps xmm4, [rsp+0x40]
0000782c7ffd2281  vmovaps xmm5, [rsp+0x50]
0000782c7ffd2287  vmovaps xmm6, [rsp+0x60]
0000782c7ffd228d  vmovaps xmm7, [rsp+0x70]
0000782c7ffd2293  vmovaps xmm8, [rsp+0x80]
0000782c7ffd229c  vmovaps xmm9, [rsp+0x90]
0000782c7ffd22a5  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd22ae  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd22b7  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd22c0  vmovaps xmm13, [rsp+0xD0]
0000782c7ffd22c9  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd22d2  add rsp, 0xF0
0000782c7ffd22d9  pop r11
0000782c7ffd22db  pop r10
0000782c7ffd22dd  pop r9
0000782c7ffd22df  pop r8
0000782c7ffd22e1  pop rsi
0000782c7ffd22e2  pop rdi
0000782c7ffd22e3  pop rdx
0000782c7ffd22e4  pop rcx
0000782c7ffd22e5  pop rax
0000782c7ffd22e6  add rsp, 0x08
0000782c7ffd22ea  jmp 0x0000782C7FFD1FBE
0000782c7ffd22ef  call 0x0000782C7FEC34C0
0000782c7ffd22f4  jmp 0x0000782C7FFD1FD4
0000782c7ffd22f9  int3
0000782c7ffd22fa  nop [rax+rax*1], ax
0000782c7ffd2300  mov rax, [r15+0x50]
0000782c7ffd2304  movups xmm1, [r13+rax*1]
0000782c7ffd230a  lea r14, [rax+0x10]
0000782c7ffd230e  movups xmm15, [r13+r14*1]
0000782c7ffd2314  mov qword ptr [r15+0x48], 0x00
0000782c7ffd231c  lea r14, [rax+0x40]
0000782c7ffd2320  movups xmm14, [r13+r14*1]
0000782c7ffd2326  lea r14, [rax+0x50]
0000782c7ffd232a  movups xmm13, [r13+r14*1]
0000782c7ffd2330  lea r14, [rax+0x80]
0000782c7ffd2337  movups xmm12, [r13+r14*1]
0000782c7ffd233d  lea r14, [rax+0x90]
0000782c7ffd2344  movups xmm11, [r13+r14*1]
0000782c7ffd234a  mov r14, [r15+0xF8]
0000782c7ffd2351  movups [r13+r14*1], xmm1
0000782c7ffd2357  lea r12, [rax+0x20]
0000782c7ffd235b  movups xmm1, [r13+r12*1]
0000782c7ffd2361  lea r12, [rax+0x30]
0000782c7ffd2365  movups xmm10, [r13+r12*1]
0000782c7ffd236b  lea r12, [rax+0xC0]
0000782c7ffd2372  movups xmm9, [r13+r12*1]
0000782c7ffd2378  lea r12, [rax+0xD0]
0000782c7ffd237f  movups xmm8, [r13+r12*1]
0000782c7ffd2385  lea r12, [rax+0x100]
0000782c7ffd238c  movups xmm7, [r13+r12*1]
0000782c7ffd2392  lea r12, [rax+0x110]
0000782c7ffd2399  movups xmm6, [r13+r12*1]
0000782c7ffd239f  lea r12, [rax+0x140]
0000782c7ffd23a6  movups xmm5, [r13+r12*1]
0000782c7ffd23ac  lea r12, [rax+0x150]
0000782c7ffd23b3  movups xmm4, [r13+r12*1]
0000782c7ffd23b9  lea r12, [r14+0xB0]
0000782c7ffd23c0  movups [r13+r12*1], xmm10
0000782c7ffd23c6  lea r12, [r14+0xC0]
0000782c7ffd23cd  movups [r13+r12*1], xmm1
0000782c7ffd23d3  lea r12, [rax+0x180]
0000782c7ffd23da  movups xmm1, [r13+r12*1]
0000782c7ffd23e0  lea r12, [rax+0x190]
0000782c7ffd23e7  movups xmm10, [r13+r12*1]
0000782c7ffd23ed  lea r12, [rax+0x1C0]
0000782c7ffd23f4  movups xmm3, [r13+r12*1]
0000782c7ffd23fa  lea r12, [rax+0x1D0]
0000782c7ffd2401  movups xmm2, [r13+r12*1]
0000782c7ffd2407  lea r12, [rax+0x60]
0000782c7ffd240b  vmovaps [rsp+0x10], xmm1
0000782c7ffd2411  movups xmm1, [r13+r12*1]
0000782c7ffd2417  lea r12, [rax+0x70]
0000782c7ffd241b  vmovaps [rsp+0x20], xmm1
0000782c7ffd2421  movups xmm1, [r13+r12*1]
0000782c7ffd2427  lea r12, [r14+0x70]
0000782c7ffd242b  movups [r13+r12*1], xmm10
0000782c7ffd2431  lea r12, [r14+0x80]
0000782c7ffd2438  vmovaps xmm10, [rsp+0x10]
0000782c7ffd243e  movups [r13+r12*1], xmm10
0000782c7ffd2444  lea r12, [rax+0xA0]
0000782c7ffd244b  movups xmm10, [r13+r12*1]
0000782c7ffd2451  lea r12, [rax+0xB0]
0000782c7ffd2458  vmovaps [rsp+0x10], xmm1
0000782c7ffd245e  movups xmm1, [r13+r12*1]
0000782c7ffd2464  lea r12, [r14+0x90]
0000782c7ffd246b  movups [r13+r12*1], xmm2
0000782c7ffd2471  lea r12, [r14+0xA0]
0000782c7ffd2478  movups [r13+r12*1], xmm3
0000782c7ffd247e  lea r12, [rax+0xE0]
0000782c7ffd2485  movups xmm3, [r13+r12*1]
0000782c7ffd248b  lea r12, [rax+0xF0]
0000782c7ffd2492  movups xmm2, [r13+r12*1]
0000782c7ffd2498  lea r12, [rax+0x120]
0000782c7ffd249f  vmovaps [rsp+0x30], xmm1
0000782c7ffd24a5  movups xmm1, [r13+r12*1]
0000782c7ffd24ab  lea r12, [rax+0x130]
0000782c7ffd24b2  vmovaps [rsp+0x40], xmm1
0000782c7ffd24b8  movups xmm1, [r13+r12*1]
0000782c7ffd24be  vmovaps [rsp+0x50], xmm1
0000782c7ffd24c4  vmovaps xmm1, [rsp+0x40]
0000782c7ffd24ca  movaps [r15+0x190], xmm1
0000782c7ffd24d2  lea r12, [rax+0x160]
0000782c7ffd24d9  vmovaps [rsp+0x40], xmm1
0000782c7ffd24df  movups xmm1, [r13+r12*1]
0000782c7ffd24e5  lea r12, [rax+0x170]
0000782c7ffd24ec  vmovaps [rsp+0x60], xmm1
0000782c7ffd24f2  movups xmm1, [r13+r12*1]
0000782c7ffd24f8  lea r12, [rax+0x1A0]
0000782c7ffd24ff  vmovaps [rsp+0x70], xmm1
0000782c7ffd2505  movups xmm1, [r13+r12*1]
0000782c7ffd250b  lea r12, [rax+0x1B0]
0000782c7ffd2512  vmovaps [rsp+0x80], xmm1
0000782c7ffd251b  movups xmm1, [r13+r12*1]
0000782c7ffd2521  lea r12, [rax+0x1E0]
0000782c7ffd2528  vmovaps [rsp+0x90], xmm1
0000782c7ffd2531  movups xmm1, [r13+r12*1]
0000782c7ffd2537  lea r12, [rax+0x1F0]
0000782c7ffd253e  vmovaps [rsp+0xA0], xmm1
0000782c7ffd2547  movups xmm1, [r13+r12*1]
0000782c7ffd254d  mov qword ptr [r15+0x50], 0x432190
0000782c7ffd2555  lea rax, [r14+0x50]
0000782c7ffd2559  vmovaps [rsp+0xB0], xmm1
0000782c7ffd2562  vmovaps xmm1, [rsp+0x60]
0000782c7ffd2568  movups [r13+rax*1], xmm1
0000782c7ffd256e  lea rax, [r14+0x60]
0000782c7ffd2572  movups [r13+rax*1], xmm5
0000782c7ffd2578  lea rax, [r14+0x40]
0000782c7ffd257c  vmovaps xmm1, [rsp+0x70]
0000782c7ffd2582  movups [r13+rax*1], xmm1
0000782c7ffd2588  lea rax, [r14+0x20]
0000782c7ffd258c  vmovaps xmm1, [rsp+0xA0]
0000782c7ffd2595  movups [r13+rax*1], xmm1
0000782c7ffd259b  lea rax, [r14+0x30]
0000782c7ffd259f  vmovaps xmm1, [rsp+0x90]
0000782c7ffd25a8  movups [r13+rax*1], xmm1
0000782c7ffd25ae  lea rax, [r14+0x10]
0000782c7ffd25b2  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd25bb  movups [r13+rax*1], xmm1
0000782c7ffd25c1  mov rax, [r15+0x40]
0000782c7ffd25c5  vxorps xmm1, xmm1, xmm1
0000782c7ffd25c9  vpbroadcastq xmm1, xmm1
0000782c7ffd25ce  vxorps xmm5, xmm5, xmm5
0000782c7ffd25d2  vpbroadcastq xmm5, xmm5
0000782c7ffd25d7  lea r12, [rax+0x30]
0000782c7ffd25db  mov r11, [r13+r12*1]
0000782c7ffd25e0  lea r12, [rax+0x38]
0000782c7ffd25e4  mov r10, [r13+r12*1]
0000782c7ffd25e9  vmovaps [rsp+0x60], xmm1
0000782c7ffd25ef  movq xmm1, r11
0000782c7ffd25f4  vmovaps [rsp+0x70], xmm1
0000782c7ffd25fa  movq xmm1, r10
0000782c7ffd25ff  vmovaps [rsp+0x90], xmm1
0000782c7ffd2608  vmovaps xmm1, [rsp+0x70]
0000782c7ffd260e  movq xmm1, xmm1
0000782c7ffd2612  vmovaps [rsp+0x70], xmm1
0000782c7ffd2618  vmovaps xmm1, [rsp+0x90]
0000782c7ffd2621  movq xmm1, xmm1
0000782c7ffd2625  vmovaps [rsp+0x90], xmm1
0000782c7ffd262e  movq xmm1, xmm1
0000782c7ffd2632  movaps [r15+0x270], xmm1
0000782c7ffd263a  vmovaps [rsp+0xA0], xmm7
0000782c7ffd2643  vmovaps xmm1, [rsp+0xA0]
0000782c7ffd264c  por xmm7, xmm1
0000782c7ffd2650  lea r12, [rax+0x20]
0000782c7ffd2654  mov r11, [r13+r12*1]
0000782c7ffd2659  lea r12, [rax+0x28]
0000782c7ffd265d  mov r10, [r13+r12*1]
0000782c7ffd2662  movq xmm1, r11
0000782c7ffd2667  vmovaps [rsp+0xA0], xmm1
0000782c7ffd2670  movq xmm1, r10
0000782c7ffd2675  vmovaps [rsp+0xB0], xmm1
0000782c7ffd267e  vmovaps xmm1, [rsp+0xA0]
0000782c7ffd2687  movq xmm1, xmm1
0000782c7ffd268b  vmovaps [rsp+0xA0], xmm1
0000782c7ffd2694  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd269d  movq xmm1, xmm1
0000782c7ffd26a1  vmovaps [rsp+0xB0], xmm2
0000782c7ffd26aa  vmovaps [rsp+0xC0], xmm1
0000782c7ffd26b3  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd26bc  por xmm2, xmm1
0000782c7ffd26c0  vmovaps [rsp+0xB0], xmm3
0000782c7ffd26c9  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd26d2  por xmm3, xmm1
0000782c7ffd26d6  vmovaps [rsp+0xB0], xmm4
0000782c7ffd26df  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd26e8  por xmm4, xmm1
0000782c7ffd26ec  vmovaps [rsp+0xB0], xmm9
0000782c7ffd26f5  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd26fe  por xmm9, xmm1
0000782c7ffd2703  lea r12, [rax+0x10]
0000782c7ffd2707  mov r11, [r13+r12*1]
0000782c7ffd270c  lea r12, [rax+0x18]
0000782c7ffd2710  mov r10, [r13+r12*1]
0000782c7ffd2715  movq xmm1, r11
0000782c7ffd271a  vmovaps [rsp+0xB0], xmm1
0000782c7ffd2723  movq xmm1, r10
0000782c7ffd2728  vmovaps [rsp+0xD0], xmm1
0000782c7ffd2731  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd273a  movq xmm1, xmm1
0000782c7ffd273e  vmovaps [rsp+0xB0], xmm1
0000782c7ffd2747  vmovaps xmm1, [rsp+0xD0]
0000782c7ffd2750  movq xmm1, xmm1
0000782c7ffd2754  vmovaps [rsp+0xD0], xmm1
0000782c7ffd275d  vmovaps xmm1, [rsp+0x80]
0000782c7ffd2766  vmovaps [rsp+0xE0], xmm15
0000782c7ffd276f  vmovaps xmm15, [rsp+0x80]
0000782c7ffd2778  por xmm1, xmm15
0000782c7ffd277d  vmovaps xmm15, [rsp+0x10]
0000782c7ffd2783  vmovaps [rsp+0x80], xmm1
0000782c7ffd278c  vmovaps xmm1, [rsp+0x10]
0000782c7ffd2792  por xmm15, xmm1
0000782c7ffd2797  vmovaps xmm1, [rsp+0x20]
0000782c7ffd279d  vmovaps [rsp+0x10], xmm15
0000782c7ffd27a3  vmovaps xmm15, [rsp+0x20]
0000782c7ffd27a9  por xmm1, xmm15
0000782c7ffd27ae  vmovaps [rsp+0x20], xmm6
0000782c7ffd27b4  vmovaps xmm15, [rsp+0x20]
0000782c7ffd27ba  por xmm6, xmm15
0000782c7ffd27bf  vmovaps [rsp+0x20], xmm11
0000782c7ffd27c5  vmovaps xmm15, [rsp+0x20]
0000782c7ffd27cb  por xmm11, xmm15
0000782c7ffd27d0  vmovaps [rsp+0x20], xmm13
0000782c7ffd27d6  vmovaps xmm15, [rsp+0x20]
0000782c7ffd27dc  por xmm13, xmm15
0000782c7ffd27e1  vmovaps [rsp+0x20], xmm14
0000782c7ffd27e7  vmovaps xmm15, [rsp+0x20]
0000782c7ffd27ed  por xmm14, xmm15
0000782c7ffd27f2  mov r12, [r13+rax*1]
0000782c7ffd27f7  vmovq xmm15, r12
0000782c7ffd27fc  vpbroadcastq xmm15, xmm15
0000782c7ffd2801  vmovaps [rsp+0x20], xmm1
0000782c7ffd2807  vxorps xmm1, xmm1, xmm1
0000782c7ffd280b  vpbroadcastq xmm1, xmm1
0000782c7ffd2810  vmovaps [rsp+0xF0], xmm1
0000782c7ffd2819  movups xmm1, [r13+r14*1]
0000782c7ffd281f  vmovaps [rsp+0x100], xmm1
0000782c7ffd2828  vxorps xmm1, xmm1, xmm1
0000782c7ffd282c  vpbroadcastq xmm1, xmm1
0000782c7ffd2831  lea r12, [rax+0x08]
0000782c7ffd2835  mov rax, [r13+r12*1]
0000782c7ffd283a  vmovaps [rsp+0x110], xmm1
0000782c7ffd2843  movq xmm1, rax
0000782c7ffd2848  movaps [r15+0x240], xmm1
0000782c7ffd2850  mov qword ptr [r15+0x60], 0x432190
0000782c7ffd2858  mov qword ptr [r15+0x58], 0x40
0000782c7ffd2860  vmovaps xmm1, [rsp+0x60]
0000782c7ffd2866  vmovaps [rsp+0x60], xmm15
0000782c7ffd286c  vmovaps xmm15, [rsp+0x100]
0000782c7ffd2875  vmovaps [rsp+0x100], xmm14
0000782c7ffd287e  vmovaps xmm14, [rsp+0x60]
0000782c7ffd2884  vmovaps [rsp+0x60], xmm13
0000782c7ffd288a  vmovaps [rsp+0x120], xmm12
0000782c7ffd2893  movaps xmm13, xmm1
0000782c7ffd2897  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd289c  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd28a2  vptest xmm12, xmm12
0000782c7ffd28a7  jnz 0x0000782C7FFD3482
0000782c7ffd28ad  vmovaps xmm1, [rsp+0xE0]
0000782c7ffd28b6  movaps xmm15, xmm5
0000782c7ffd28ba  vfmadd231pd xmm15, xmm1, xmm14
0000782c7ffd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
0000782c7ffd28c5  vptest xmm12, xmm12
0000782c7ffd28ca  jnz 0x0000782C7FFD35DB
0000782c7ffd28d0  vmovaps xmm12, [rsp+0x50]
0000782c7ffd28d6  vmovaps xmm5, [rsp+0x50]
0000782c7ffd28dc  por xmm12, xmm5
0000782c7ffd28e1  vmovaps xmm5, [rsp+0x30]
0000782c7ffd28e7  vmovaps [rsp+0x50], xmm1
0000782c7ffd28ed  vmovaps xmm1, [rsp+0x30]
0000782c7ffd28f3  por xmm5, xmm1
0000782c7ffd28f7  vmovaps [rsp+0x30], xmm10
0000782c7ffd28fd  vmovaps xmm1, [rsp+0x30]
0000782c7ffd2903  por xmm10, xmm1
0000782c7ffd2908  vmovaps [rsp+0x30], xmm8
0000782c7ffd290e  vmovaps xmm1, [rsp+0x30]
0000782c7ffd2914  por xmm8, xmm1
0000782c7ffd2919  vmovaps xmm1, [rsp+0x120]
0000782c7ffd2922  vmovaps [rsp+0x30], xmm15
0000782c7ffd2928  vmovaps xmm15, [rsp+0x120]
0000782c7ffd2931  por xmm1, xmm15
0000782c7ffd2936  vmovaps xmm15, [rsp+0x50]
0000782c7ffd293c  vmovaps [rsp+0xE0], xmm1
0000782c7ffd2945  vmovaps xmm1, [rsp+0x50]
0000782c7ffd294b  por xmm15, xmm1
0000782c7ffd2950  lea rax, [r14+0xC0]
0000782c7ffd2957  movups xmm1, [r13+rax*1]
0000782c7ffd295d  xor eax, eax
0000782c7ffd295f  mov r12d, 0x40
0000782c7ffd2965  mov r11d, 0x200
0000782c7ffd296b  cmp r12, r11
0000782c7ffd296e  cmc
0000782c7ffd296f  lahf
0000782c7ffd2970  seto al
0000782c7ffd2973  mov [r15+0x108], eax
0000782c7ffd297a  vmovaps [rsp+0x50], xmm1
0000782c7ffd2980  vmovaps xmm1, [rsp+0xF0]
0000782c7ffd2989  vmovaps [rsp+0xF0], xmm15
0000782c7ffd2992  vmovaps xmm15, [rsp+0x50]
0000782c7ffd2998  vmovaps [rsp+0x50], xmm13
0000782c7ffd299e  vmovaps [rsp+0x120], xmm12
0000782c7ffd29a7  movaps xmm13, xmm1
0000782c7ffd29ab  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd29b6  vptest xmm12, xmm12
0000782c7ffd29bb  jnz 0x0000782C7FFD373D
0000782c7ffd29c1  lea rax, [r14+0xB0]
0000782c7ffd29c8  movups xmm1, [r13+rax*1]
0000782c7ffd29ce  vmovaps xmm15, [rsp+0x110]
0000782c7ffd29d7  vmovaps [rsp+0x110], xmm13
0000782c7ffd29e0  movaps xmm12, xmm15
0000782c7ffd29e4  vfmadd231pd xmm12, xmm1, xmm14
0000782c7ffd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
0000782c7ffd29ef  vptest xmm13, xmm13
0000782c7ffd29f4  jnz 0x0000782C7FFD38A0
0000782c7ffd29fa  vmovaps xmm1, [rsp+0x100]
0000782c7ffd2a03  vmovaps xmm15, [rsp+0x100]
0000782c7ffd2a0c  por xmm1, xmm15
0000782c7ffd2a11  movaps [r15+0x210], xmm1
0000782c7ffd2a19  vmovaps xmm15, [rsp+0x60]
0000782c7ffd2a1f  vmovaps xmm14, [rsp+0x60]
0000782c7ffd2a25  por xmm15, xmm14
0000782c7ffd2a2a  movaps [r15+0x1C0], xmm15
0000782c7ffd2a32  vmovaps [rsp+0x60], xmm11
0000782c7ffd2a38  vmovaps xmm14, [rsp+0x60]
0000782c7ffd2a3e  por xmm11, xmm14
0000782c7ffd2a43  movaps [r15+0x280], xmm11
0000782c7ffd2a4b  vmovaps [rsp+0x60], xmm6
0000782c7ffd2a51  vmovaps xmm14, [rsp+0x60]
0000782c7ffd2a57  por xmm6, xmm14
0000782c7ffd2a5c  movaps [r15+0x2A0], xmm6
0000782c7ffd2a64  vmovaps xmm14, [rsp+0x20]
0000782c7ffd2a6a  vmovaps xmm13, [rsp+0x20]
0000782c7ffd2a70  por xmm14, xmm13
0000782c7ffd2a75  movaps [r15+0x2E0], xmm14
0000782c7ffd2a7d  vmovaps xmm13, [rsp+0x10]
0000782c7ffd2a83  vmovaps [rsp+0x20], xmm1
0000782c7ffd2a89  vmovaps xmm1, [rsp+0x10]
0000782c7ffd2a8f  por xmm13, xmm1
0000782c7ffd2a94  movaps [r15+0x1F0], xmm13
0000782c7ffd2a9c  vmovaps xmm1, [rsp+0xF0]
0000782c7ffd2aa5  vmovaps [rsp+0x10], xmm15
0000782c7ffd2aab  vmovaps xmm15, [rsp+0xF0]
0000782c7ffd2ab4  por xmm1, xmm15
0000782c7ffd2ab9  movaps [r15+0x250], xmm1
0000782c7ffd2ac1  vmovaps xmm1, [rsp+0xE0]
0000782c7ffd2aca  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd2ad3  por xmm1, xmm15
0000782c7ffd2ad8  movaps [r15+0x260], xmm1
0000782c7ffd2ae0  vmovaps [rsp+0x60], xmm8
0000782c7ffd2ae6  vmovaps xmm15, [rsp+0x60]
0000782c7ffd2aec  por xmm8, xmm15
0000782c7ffd2af1  movaps [r15+0x290], xmm8
0000782c7ffd2af9  vmovaps [rsp+0x60], xmm10
0000782c7ffd2aff  vmovaps xmm15, [rsp+0x60]
0000782c7ffd2b05  por xmm10, xmm15
0000782c7ffd2b0a  movaps [r15+0x2C0], xmm10
0000782c7ffd2b12  movq xmm15, qword ptr [r15+0x240]
0000782c7ffd2b1b  vmovaps [rsp+0x60], xmm15
0000782c7ffd2b21  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd2b27  vmovaps [rsp+0xE0], xmm1
0000782c7ffd2b30  vmovaps xmm1, [rsp+0x50]
0000782c7ffd2b36  vmovaps [rsp+0x50], xmm15
0000782c7ffd2b3c  vmovaps xmm15, [rsp+0x20]
0000782c7ffd2b42  vmovaps [rsp+0x20], xmm14
0000782c7ffd2b48  vmovaps xmm14, [rsp+0x50]
0000782c7ffd2b4e  vmovaps [rsp+0x50], xmm13
0000782c7ffd2b54  vmovaps [rsp+0xF0], xmm12
0000782c7ffd2b5d  movaps xmm13, xmm1
0000782c7ffd2b61  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd2b6c  vptest xmm12, xmm12
0000782c7ffd2b71  jnz 0x0000782C7FFD39F9
0000782c7ffd2b77  vmovaps xmm1, [rsp+0x60]
0000782c7ffd2b7d  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd2b83  vmovaps xmm15, [rsp+0x110]
0000782c7ffd2b8c  vmovaps xmm14, [rsp+0x20]
0000782c7ffd2b92  vmovaps [rsp+0x20], xmm13
0000782c7ffd2b98  movaps xmm12, xmm15
0000782c7ffd2b9c  vfmadd231pd xmm12, xmm14, xmm1
0000782c7ffd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
0000782c7ffd2ba7  vptest xmm13, xmm13
0000782c7ffd2bac  jnz 0x0000782C7FFD3B52
0000782c7ffd2bb2  vmovaps xmm1, [rsp+0x60]
0000782c7ffd2bb8  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd2bbe  vmovaps xmm15, [rsp+0x30]
0000782c7ffd2bc4  vmovaps xmm14, [rsp+0x10]
0000782c7ffd2bca  vmovaps [rsp+0x10], xmm12
0000782c7ffd2bd0  movaps xmm13, xmm15
0000782c7ffd2bd4  vfmadd231pd xmm13, xmm14, xmm1
0000782c7ffd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd2bdf  vptest xmm12, xmm12
0000782c7ffd2be4  jnz 0x0000782C7FFD3CAB
0000782c7ffd2bea  vmovaps [rsp+0x30], xmm5
0000782c7ffd2bf0  vmovaps xmm1, [rsp+0x30]
0000782c7ffd2bf6  por xmm5, xmm1
0000782c7ffd2bfa  movaps [r15+0x1D0], xmm5
0000782c7ffd2c02  vmovaps xmm1, [rsp+0x60]
0000782c7ffd2c08  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd2c0e  vmovaps xmm15, [rsp+0xF0]
0000782c7ffd2c17  vmovaps xmm14, [rsp+0x50]
0000782c7ffd2c1d  vmovaps [rsp+0x30], xmm13
0000782c7ffd2c23  movaps xmm12, xmm15
0000782c7ffd2c27  vfmadd231pd xmm12, xmm14, xmm1
0000782c7ffd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
0000782c7ffd2c32  vptest xmm13, xmm13
0000782c7ffd2c37  jnz 0x0000782C7FFD3E04
0000782c7ffd2c3d  vmovaps xmm1, [rsp+0x80]
0000782c7ffd2c46  vmovaps xmm15, [rsp+0x80]
0000782c7ffd2c4f  por xmm1, xmm15
0000782c7ffd2c54  movaps [r15+0x200], xmm1
0000782c7ffd2c5c  vmovaps xmm15, [rsp+0x120]
0000782c7ffd2c65  vmovaps xmm14, [rsp+0x120]
0000782c7ffd2c6e  por xmm15, xmm14
0000782c7ffd2c73  movaps [r15+0x1E0], xmm15
0000782c7ffd2c7b  vmovaps [rsp+0x50], xmm4
0000782c7ffd2c81  vmovaps xmm13, [rsp+0x50]
0000782c7ffd2c87  por xmm4, xmm13
0000782c7ffd2c8c  movaps [r15+0x2B0], xmm4
0000782c7ffd2c94  vmovaps [rsp+0x50], xmm3
0000782c7ffd2c9a  vmovaps xmm13, [rsp+0x50]
0000782c7ffd2ca0  por xmm3, xmm13
0000782c7ffd2ca5  movaps [r15+0x300], xmm3
0000782c7ffd2cad  vmovaps xmm15, [rsp+0xB0]
0000782c7ffd2cb6  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd2cbc  vmovaps xmm3, [rsp+0x20]
0000782c7ffd2cc2  vmovaps [rsp+0x20], xmm1
0000782c7ffd2cc8  vmovaps xmm1, [rsp+0xE0]
0000782c7ffd2cd1  vmovaps [rsp+0x50], xmm14
0000782c7ffd2cd7  vmovaps [rsp+0x60], xmm13
0000782c7ffd2cdd  movaps xmm14, xmm3
0000782c7ffd2ce1  vfmadd231pd xmm14, xmm1, xmm15
0000782c7ffd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
0000782c7ffd2cec  vptest xmm13, xmm13
0000782c7ffd2cf1  jnz 0x0000782C7FFD3F5D
0000782c7ffd2cf7  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd2d00  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd2d06  vmovaps xmm15, [rsp+0x10]
0000782c7ffd2d0c  movaps xmm13, xmm15
0000782c7ffd2d10  vfmadd231pd xmm13, xmm10, xmm1
0000782c7ffd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
0000782c7ffd2d1b  vptest xmm3, xmm3
0000782c7ffd2d20  jnz 0x0000782C7FFD40B5
0000782c7ffd2d26  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd2d2f  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd2d35  vmovaps xmm15, [rsp+0x30]
0000782c7ffd2d3b  movaps xmm10, xmm15
0000782c7ffd2d3f  vfmadd231pd xmm10, xmm11, xmm1
0000782c7ffd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
0000782c7ffd2d4a  vptest xmm3, xmm3
0000782c7ffd2d4f  jnz 0x0000782C7FFD420E
0000782c7ffd2d55  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd2d5e  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd2d64  movaps xmm15, xmm12
0000782c7ffd2d68  vfmadd231pd xmm15, xmm5, xmm1
0000782c7ffd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
0000782c7ffd2d73  vptest xmm11, xmm11
0000782c7ffd2d78  jnz 0x0000782C7FFD4367
0000782c7ffd2d7e  vmovaps [rsp+0x10], xmm9
0000782c7ffd2d84  vmovaps xmm1, [rsp+0x10]
0000782c7ffd2d8a  por xmm9, xmm1
0000782c7ffd2d8f  movaps [r15+0x180], xmm9
0000782c7ffd2d97  vmovaps [rsp+0x10], xmm2
0000782c7ffd2d9d  vmovaps xmm1, [rsp+0x10]
0000782c7ffd2da3  por xmm2, xmm1
0000782c7ffd2da7  movaps [r15+0x2D0], xmm2
0000782c7ffd2daf  vmovaps xmm12, [rsp+0xD0]
0000782c7ffd2db8  vpermilpd xmm12, xmm12, 0x00
0000782c7ffd2dbe  vmovaps xmm11, [rsp+0x60]
0000782c7ffd2dc4  movaps xmm5, xmm13
0000782c7ffd2dc8  vfmadd231pd xmm5, xmm11, xmm12
0000782c7ffd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
0000782c7ffd2dd2  vptest xmm3, xmm3
0000782c7ffd2dd7  jnz 0x0000782C7FFD44BF
0000782c7ffd2ddd  vmovaps xmm13, [rsp+0xD0]
0000782c7ffd2de6  vpermilpd xmm13, xmm13, 0x00
0000782c7ffd2dec  movaps xmm12, xmm14
0000782c7ffd2df0  vfmadd231pd xmm12, xmm9, xmm13
0000782c7ffd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
0000782c7ffd2dfb  vptest xmm11, xmm11
0000782c7ffd2e00  jnz 0x0000782C7FFD4617
0000782c7ffd2e06  lea rax, [r14+0x80]
0000782c7ffd2e0d  movups xmm14, [r13+rax*1]
0000782c7ffd2e13  movaps [r15+0x2F0], xmm14
0000782c7ffd2e1b  vmovaps xmm13, [rsp+0xD0]
0000782c7ffd2e24  vpermilpd xmm13, xmm13, 0x00
0000782c7ffd2e2a  movaps xmm11, xmm10
0000782c7ffd2e2e  vfmadd231pd xmm11, xmm8, xmm13
0000782c7ffd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
0000782c7ffd2e39  vptest xmm9, xmm9
0000782c7ffd2e3e  jnz 0x0000782C7FFD477B
0000782c7ffd2e44  vmovaps xmm13, [rsp+0xD0]
0000782c7ffd2e4d  vpermilpd xmm13, xmm13, 0x00
0000782c7ffd2e53  movaps xmm10, xmm15
0000782c7ffd2e57  vfmadd231pd xmm10, xmm1, xmm13
0000782c7ffd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
0000782c7ffd2e62  vptest xmm9, xmm9
0000782c7ffd2e67  jnz 0x0000782C7FFD48D5
0000782c7ffd2e6d  vmovaps [rsp+0x10], xmm7
0000782c7ffd2e73  vmovaps xmm1, [rsp+0x10]
0000782c7ffd2e79  por xmm7, xmm1
0000782c7ffd2e7d  movaps [r15+0x160], xmm7
0000782c7ffd2e85  lea rax, [r14+0x40]
0000782c7ffd2e89  movups xmm1, [r13+rax*1]
0000782c7ffd2e8f  lea rax, [r14+0x50]
0000782c7ffd2e93  movups xmm15, [r13+rax*1]
0000782c7ffd2e99  movaps [r15+0x1B0], xmm1
0000782c7ffd2ea1  movaps [r15+0x1A0], xmm15
0000782c7ffd2ea9  vmovaps xmm13, [rsp+0xA0]
0000782c7ffd2eb2  vpermilpd xmm13, xmm13, 0x00
0000782c7ffd2eb8  vmovaps xmm9, [rsp+0x40]
0000782c7ffd2ebe  movaps xmm8, xmm5
0000782c7ffd2ec2  vfmadd231pd xmm8, xmm9, xmm13
0000782c7ffd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
0000782c7ffd2ecd  vptest xmm3, xmm3
0000782c7ffd2ed2  jnz 0x0000782C7FFD4A42
0000782c7ffd2ed8  vmovaps xmm13, [rsp+0xA0]
0000782c7ffd2ee1  vpermilpd xmm13, xmm13, 0x00
0000782c7ffd2ee7  movaps xmm9, xmm12
0000782c7ffd2eeb  vfmadd231pd xmm9, xmm7, xmm13
0000782c7ffd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
0000782c7ffd2ef6  vptest xmm5, xmm5
0000782c7ffd2efb  jnz 0x0000782C7FFD4B9B
0000782c7ffd2f01  vmovaps xmm13, [rsp+0xA0]
0000782c7ffd2f0a  vpermilpd xmm13, xmm13, 0x00
0000782c7ffd2f10  movaps xmm12, xmm11
0000782c7ffd2f14  vfmadd231pd xmm12, xmm6, xmm13
0000782c7ffd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
0000782c7ffd2f1f  vptest xmm7, xmm7
0000782c7ffd2f24  jnz 0x0000782C7FFD4CF4
0000782c7ffd2f2a  vmovaps xmm13, [rsp+0xA0]
0000782c7ffd2f33  vpermilpd xmm13, xmm13, 0x00
0000782c7ffd2f39  vmovaps xmm11, [rsp+0x50]
0000782c7ffd2f3f  movaps xmm7, xmm10
0000782c7ffd2f43  vfmadd231pd xmm7, xmm11, xmm13
0000782c7ffd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
0000782c7ffd2f4d  vptest xmm6, xmm6
0000782c7ffd2f52  jnz 0x0000782C7FFD4E4D
0000782c7ffd2f58  lea rax, [r14+0x60]
0000782c7ffd2f5c  movups xmm13, [r13+rax*1]
0000782c7ffd2f62  lea rax, [r14+0x70]
0000782c7ffd2f66  movups xmm11, [r13+rax*1]
0000782c7ffd2f6c  movaps [r15+0x150], xmm13
0000782c7ffd2f74  movaps [r15+0x120], xmm11
0000782c7ffd2f7c  vmovaps xmm10, [rsp+0xC0]
0000782c7ffd2f85  vpermilpd xmm10, xmm10, 0x00
0000782c7ffd2f8b  movaps xmm6, xmm8
0000782c7ffd2f8f  vfmadd231pd xmm6, xmm15, xmm10
0000782c7ffd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
0000782c7ffd2f99  vptest xmm5, xmm5
0000782c7ffd2f9e  jnz 0x0000782C7FFD4FB9
0000782c7ffd2fa4  vmovaps xmm15, [rsp+0xC0]
0000782c7ffd2fad  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd2fb3  movaps xmm10, xmm9
0000782c7ffd2fb7  vfmadd231pd xmm10, xmm13, xmm15
0000782c7ffd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
0000782c7ffd2fc2  vptest xmm8, xmm8
0000782c7ffd2fc7  jnz 0x0000782C7FFD5111
0000782c7ffd2fcd  vmovaps xmm15, [rsp+0xC0]
0000782c7ffd2fd6  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd2fdc  movaps xmm13, xmm12
0000782c7ffd2fe0  vfmadd231pd xmm13, xmm4, xmm15
0000782c7ffd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
0000782c7ffd2feb  vptest xmm9, xmm9
0000782c7ffd2ff0  jnz 0x0000782C7FFD526B
0000782c7ffd2ff6  vmovaps xmm15, [rsp+0xC0]
0000782c7ffd2fff  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd3005  movaps xmm12, xmm7
0000782c7ffd3009  vfmadd231pd xmm12, xmm1, xmm15
0000782c7ffd300e  vcmppd xmm9, xmm12, xmm12, 0x03
0000782c7ffd3014  vptest xmm9, xmm9
0000782c7ffd3019  jnz 0x0000782C7FFD53C4
0000782c7ffd301f  lea rax, [r14+0x20]
0000782c7ffd3023  movups xmm1, [r13+rax*1]
0000782c7ffd3029  lea rax, [r14+0x30]
0000782c7ffd302d  movups xmm15, [r13+rax*1]
0000782c7ffd3033  vmovaps xmm9, [rsp+0x70]
0000782c7ffd3039  vpermilpd xmm9, xmm9, 0x00
0000782c7ffd303f  vmovaps xmm8, [rsp+0x20]
0000782c7ffd3045  movaps xmm7, xmm6
0000782c7ffd3048  vfmadd231pd xmm7, xmm8, xmm9
0000782c7ffd304d  vcmppd xmm5, xmm7, xmm7, 0x03
0000782c7ffd3052  vptest xmm5, xmm5
0000782c7ffd3057  jnz 0x0000782C7FFD5530
0000782c7ffd305d  vmovaps xmm9, [rsp+0x70]
0000782c7ffd3063  vpermilpd xmm9, xmm9, 0x00
0000782c7ffd3069  movaps xmm8, xmm10
0000782c7ffd306d  vfmadd231pd xmm8, xmm14, xmm9
0000782c7ffd3072  vcmppd xmm6, xmm8, xmm8, 0x03
0000782c7ffd3078  vptest xmm6, xmm6
0000782c7ffd307d  jnz 0x0000782C7FFD5687
0000782c7ffd3083  vmovaps xmm14, [rsp+0x70]
0000782c7ffd3089  vpermilpd xmm14, xmm14, 0x00
0000782c7ffd308f  movaps xmm10, xmm13
0000782c7ffd3093  vfmadd231pd xmm10, xmm11, xmm14
0000782c7ffd3098  vcmppd xmm9, xmm10, xmm10, 0x03
0000782c7ffd309e  vptest xmm9, xmm9
0000782c7ffd30a3  jnz 0x0000782C7FFD57E1
0000782c7ffd30a9  vmovaps xmm14, [rsp+0x70]
0000782c7ffd30af  vpermilpd xmm14, xmm14, 0x00
0000782c7ffd30b5  movaps xmm13, xmm12
0000782c7ffd30b9  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd30be  vcmppd xmm11, xmm13, xmm13, 0x03
0000782c7ffd30c4  vptest xmm11, xmm11
0000782c7ffd30c9  jnz 0x0000782C7FFD593B
0000782c7ffd30cf  lea rax, [r14+0x90]
0000782c7ffd30d6  movups xmm15, [r13+rax*1]
0000782c7ffd30dc  lea rax, [r14+0xA0]
0000782c7ffd30e3  movups xmm14, [r13+rax*1]
0000782c7ffd30e9  movaps [r15+0x140], xmm15
0000782c7ffd30f1  movaps [r15+0x130], xmm14
0000782c7ffd30f9  vmovaps xmm12, [rsp+0x90]
0000782c7ffd3102  vpermilpd xmm12, xmm12, 0x00
0000782c7ffd3108  movaps xmm11, xmm7
0000782c7ffd310c  vfmadd231pd xmm11, xmm1, xmm12
0000782c7ffd3111  vcmppd xmm9, xmm11, xmm11, 0x03
0000782c7ffd3117  vptest xmm9, xmm9
0000782c7ffd311c  jnz 0x0000782C7FFD5AA9
0000782c7ffd3122  movaps [r15+0x220], xmm11
0000782c7ffd312a  lea rax, [r14+0x10]
0000782c7ffd312e  movups xmm1, [r13+rax*1]
0000782c7ffd3134  movaps [r15+0x240], xmm1
0000782c7ffd313c  vmovaps xmm12, [rsp+0x90]
0000782c7ffd3145  vpermilpd xmm12, xmm12, 0x00
0000782c7ffd314b  movaps xmm9, xmm8
0000782c7ffd314f  vfmadd231pd xmm9, xmm14, xmm12
0000782c7ffd3154  vcmppd xmm7, xmm9, xmm9, 0x03
0000782c7ffd315a  vptest xmm7, xmm7
0000782c7ffd315f  jnz 0x0000782C7FFD5C0B
0000782c7ffd3165  movaps [r15+0x110], xmm9
0000782c7ffd316d  vmovaps xmm14, [rsp+0x90]
0000782c7ffd3176  vpermilpd xmm14, xmm14, 0x00
0000782c7ffd317c  movaps xmm12, xmm10
0000782c7ffd3180  vfmadd231pd xmm12, xmm15, xmm14
0000782c7ffd3185  vcmppd xmm8, xmm12, xmm12, 0x03
0000782c7ffd318b  vptest xmm8, xmm8
0000782c7ffd3190  jnz 0x0000782C7FFD5D65
0000782c7ffd3196  movaps [r15+0x170], xmm12
0000782c7ffd319e  vmovaps xmm15, [rsp+0x90]
0000782c7ffd31a7  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd31ad  movaps xmm14, xmm13
0000782c7ffd31b1  vfmadd231pd xmm14, xmm1, xmm15
0000782c7ffd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
0000782c7ffd31bc  vptest xmm10, xmm10
0000782c7ffd31c1  jnz 0x0000782C7FFD5EBF
0000782c7ffd31c7  movaps [r15+0x230], xmm14
0000782c7ffd31cf  mov eax, 0x432190
0000782c7ffd31d4  movups [r13+rax*1], xmm9
0000782c7ffd31da  mov eax, 0x4321A0
0000782c7ffd31df  movups [r13+rax*1], xmm12
0000782c7ffd31e5  mov eax, 0x4321B0
0000782c7ffd31ea  movups [r13+rax*1], xmm11
0000782c7ffd31f0  mov eax, 0x4321C0
0000782c7ffd31f5  movups [r13+rax*1], xmm14
0000782c7ffd31fb  mov eax, [r15+0x108]
0000782c7ffd3202  sahf
0000782c7ffd3203  jnz 0x0000782C7FFD3235
0000782c7ffd3205  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd320d  jz 0x0000782C7FFD9950
0000782c7ffd3213  nop [rax+rax*1], ax
0000782c7ffd321c  nop [rax+rax*1], eax
0000782c7ffd3224  mov eax, 0x410664
0000782c7ffd3229  mov [r15+0x100], rax
0000782c7ffd3230  jmp 0x0000782C7FDFE110
0000782c7ffd3235  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd323d  jz 0x0000782C7FFD6050
0000782c7ffd3243  nop [rax+rax*1], ax
0000782c7ffd324c  nop [rax+rax*1], eax
0000782c7ffd3254  mov eax, 0x4104F0
0000782c7ffd3259  mov [r15+0x100], rax
0000782c7ffd3260  jmp 0x0000782C7FDFE110
0000782c7ffd3265  int3
0000782c7ffd3266  call 0x0000782C7FDFF430
0000782c7ffd326b  jmp 0x0000782C7FFD230A
0000782c7ffd3270  call 0x0000782C7FEE5820
0000782c7ffd3275  jmp 0x0000782C7FFD2314
0000782c7ffd327a  call 0x0000782C7FEE45A0
0000782c7ffd327f  jmp 0x0000782C7FFD2326
0000782c7ffd3284  call 0x0000782C7FEE3320
0000782c7ffd3289  jmp 0x0000782C7FFD2330
0000782c7ffd328e  call 0x0000782C7FEE20A0
0000782c7ffd3293  jmp 0x0000782C7FFD233D
0000782c7ffd3298  call 0x0000782C7FEE0E30
0000782c7ffd329d  jmp 0x0000782C7FFD234A
0000782c7ffd32a2  call 0x0000782C7FED6600
0000782c7ffd32a7  jmp 0x0000782C7FFD2357
0000782c7ffd32ac  call 0x0000782C7FEB52F0
0000782c7ffd32b1  jmp 0x0000782C7FFD2361
0000782c7ffd32b6  call 0x0000782C7FEBE9C0
0000782c7ffd32bb  jmp 0x0000782C7FFD236B
0000782c7ffd32c0  call 0x0000782C7FEBD750
0000782c7ffd32c5  jmp 0x0000782C7FFD2378
0000782c7ffd32ca  call 0x0000782C7FEBC4E0
0000782c7ffd32cf  jmp 0x0000782C7FFD2385
0000782c7ffd32d4  call 0x0000782C7FEBB270
0000782c7ffd32d9  jmp 0x0000782C7FFD2392
0000782c7ffd32de  call 0x0000782C7FEBA000
0000782c7ffd32e3  jmp 0x0000782C7FFD239F
0000782c7ffd32e8  call 0x0000782C7FEB8D90
0000782c7ffd32ed  jmp 0x0000782C7FFD23AC
0000782c7ffd32f2  call 0x0000782C7FEB8A20
0000782c7ffd32f7  jmp 0x0000782C7FFD23B9
0000782c7ffd32fc  call 0x0000782C7FEBEAE0
0000782c7ffd3301  jmp 0x0000782C7FFD23C6
0000782c7ffd3306  call 0x0000782C7FEB5400
0000782c7ffd330b  jmp 0x0000782C7FFD23D3
0000782c7ffd3310  call 0x0000782C7FEB52F0
0000782c7ffd3315  jmp 0x0000782C7FFD23E0
0000782c7ffd331a  call 0x0000782C7FEBE9C0
0000782c7ffd331f  jmp 0x0000782C7FFD23ED
0000782c7ffd3324  call 0x0000782C7FEB77B0
0000782c7ffd3329  jmp 0x0000782C7FFD23FA
0000782c7ffd332e  call 0x0000782C7FEB6550
0000782c7ffd3333  jmp 0x0000782C7FFD2407
0000782c7ffd3338  call 0x0000782C7FEB52F0
0000782c7ffd333d  jmp 0x0000782C7FFD2417
0000782c7ffd3342  call 0x0000782C7FEB52F0
0000782c7ffd3347  jmp 0x0000782C7FFD2427
0000782c7ffd334c  call 0x0000782C7FEBEAE0
0000782c7ffd3351  jmp 0x0000782C7FFD2431
0000782c7ffd3356  call 0x0000782C7FEBEAE0
0000782c7ffd335b  jmp 0x0000782C7FFD2444
0000782c7ffd3360  call 0x0000782C7FEBE9C0
0000782c7ffd3365  jmp 0x0000782C7FFD2451
0000782c7ffd336a  call 0x0000782C7FEB52F0
0000782c7ffd336f  jmp 0x0000782C7FFD2464
0000782c7ffd3374  call 0x0000782C7FEB6660
0000782c7ffd3379  jmp 0x0000782C7FFD2471
0000782c7ffd337e  call 0x0000782C7FEB78C0
0000782c7ffd3383  jmp 0x0000782C7FFD247E
0000782c7ffd3388  call 0x0000782C7FEB77B0
0000782c7ffd338d  jmp 0x0000782C7FFD248B
0000782c7ffd3392  call 0x0000782C7FEB6550
0000782c7ffd3397  jmp 0x0000782C7FFD2498
0000782c7ffd339c  call 0x0000782C7FEB52F0
0000782c7ffd33a1  jmp 0x0000782C7FFD24AB
0000782c7ffd33a6  call 0x0000782C7FEB52F0
0000782c7ffd33ab  jmp 0x0000782C7FFD24BE
0000782c7ffd33b0  call 0x0000782C7FEB52F0
0000782c7ffd33b5  jmp 0x0000782C7FFD24E5
0000782c7ffd33ba  call 0x0000782C7FEB52F0
0000782c7ffd33bf  jmp 0x0000782C7FFD24F8
0000782c7ffd33c4  call 0x0000782C7FEB52F0
0000782c7ffd33c9  jmp 0x0000782C7FFD250B
0000782c7ffd33ce  call 0x0000782C7FEB52F0
0000782c7ffd33d3  jmp 0x0000782C7FFD2521
0000782c7ffd33d8  call 0x0000782C7FEB52F0
0000782c7ffd33dd  jmp 0x0000782C7FFD2537
0000782c7ffd33e2  call 0x0000782C7FEB52F0
0000782c7ffd33e7  jmp 0x0000782C7FFD254D
0000782c7ffd33ec  call 0x0000782C7FDFF540
0000782c7ffd33f1  jmp 0x0000782C7FFD256E
0000782c7ffd33f6  call 0x0000782C7FE02FE0
0000782c7ffd33fb  jmp 0x0000782C7FFD2578
0000782c7ffd3400  call 0x0000782C7FDFF540
0000782c7ffd3405  jmp 0x0000782C7FFD2588
0000782c7ffd340a  call 0x0000782C7FDFF540
0000782c7ffd340f  jmp 0x0000782C7FFD259B
0000782c7ffd3414  call 0x0000782C7FDFF540
0000782c7ffd3419  jmp 0x0000782C7FFD25AE
0000782c7ffd341e  call 0x0000782C7FDFF540
0000782c7ffd3423  jmp 0x0000782C7FFD25C1
0000782c7ffd3428  call 0x0000782C7FEC0370
0000782c7ffd342d  jmp 0x0000782C7FFD25E0
0000782c7ffd3432  call 0x0000782C7FEBF100
0000782c7ffd3437  jmp 0x0000782C7FFD25E9
0000782c7ffd343c  call 0x0000782C7FEC0370
0000782c7ffd3441  jmp 0x0000782C7FFD2659
0000782c7ffd3446  call 0x0000782C7FEBF100
0000782c7ffd344b  jmp 0x0000782C7FFD2662
0000782c7ffd3450  call 0x0000782C7FEC0370
0000782c7ffd3455  jmp 0x0000782C7FFD270C
0000782c7ffd345a  call 0x0000782C7FEBF100
0000782c7ffd345f  jmp 0x0000782C7FFD2715
0000782c7ffd3464  call 0x0000782C7FE0B720
0000782c7ffd3469  jmp 0x0000782C7FFD27F7
0000782c7ffd346e  call 0x0000782C7FED64F0
0000782c7ffd3473  jmp 0x0000782C7FFD281F
0000782c7ffd3478  call 0x0000782C7FEB47C0
0000782c7ffd347d  jmp 0x0000782C7FFD283A
0000782c7ffd3482  sub rsp, 0x08
0000782c7ffd3486  push rax
0000782c7ffd3487  push rcx
0000782c7ffd3488  push rdx
0000782c7ffd3489  push rdi
0000782c7ffd348a  push rsi
0000782c7ffd348b  push r8
0000782c7ffd348d  push r9
0000782c7ffd348f  push r10
0000782c7ffd3491  push r11
0000782c7ffd3493  sub rsp, 0xF0
0000782c7ffd349a  vmovaps [rsp], xmm0
0000782c7ffd349f  vmovaps [rsp+0x10], xmm1
0000782c7ffd34a5  vmovaps [rsp+0x20], xmm2
0000782c7ffd34ab  vmovaps [rsp+0x30], xmm3
0000782c7ffd34b1  vmovaps [rsp+0x40], xmm4
0000782c7ffd34b7  vmovaps [rsp+0x50], xmm5
0000782c7ffd34bd  vmovaps [rsp+0x60], xmm6
0000782c7ffd34c3  vmovaps [rsp+0x70], xmm7
0000782c7ffd34c9  vmovaps [rsp+0x80], xmm8
0000782c7ffd34d2  vmovaps [rsp+0x90], xmm9
0000782c7ffd34db  vmovaps [rsp+0xA0], xmm10
0000782c7ffd34e4  vmovaps [rsp+0xB0], xmm11
0000782c7ffd34ed  vmovaps [rsp+0xC0], xmm12
0000782c7ffd34f6  vmovaps [rsp+0xD0], xmm14
0000782c7ffd34ff  vmovaps [rsp+0xE0], xmm15
0000782c7ffd3508  sub rsp, 0x40
0000782c7ffd350c  lea rdi, [rsp]
0000782c7ffd3510  lea rsi, [rsp+0x10]
0000782c7ffd3515  lea rdx, [rsp+0x20]
0000782c7ffd351a  lea rcx, [rsp+0x30]
0000782c7ffd351f  mov r8d, 0x00
0000782c7ffd3525  lea r9, [r15+0x3A8]
0000782c7ffd352c  movaps [rdi], xmm13
0000782c7ffd3530  movaps [rsi], xmm1
0000782c7ffd3533  movaps [rdx], xmm15
0000782c7ffd3537  movaps [rcx], xmm14
0000782c7ffd353b  mov rax, 0x5AE5BFFB5A50
0000782c7ffd3545  call rax
0000782c7ffd3547  movaps xmm13, [rsp]
0000782c7ffd354c  add rsp, 0x40
0000782c7ffd3550  vmovaps xmm0, [rsp]
0000782c7ffd3555  vmovaps xmm1, [rsp+0x10]
0000782c7ffd355b  vmovaps xmm2, [rsp+0x20]
0000782c7ffd3561  vmovaps xmm3, [rsp+0x30]
0000782c7ffd3567  vmovaps xmm4, [rsp+0x40]
0000782c7ffd356d  vmovaps xmm5, [rsp+0x50]
0000782c7ffd3573  vmovaps xmm6, [rsp+0x60]
0000782c7ffd3579  vmovaps xmm7, [rsp+0x70]
0000782c7ffd357f  vmovaps xmm8, [rsp+0x80]
0000782c7ffd3588  vmovaps xmm9, [rsp+0x90]
0000782c7ffd3591  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd359a  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd35a3  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd35ac  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd35b5  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd35be  add rsp, 0xF0
0000782c7ffd35c5  pop r11
0000782c7ffd35c7  pop r10
0000782c7ffd35c9  pop r9
0000782c7ffd35cb  pop r8
0000782c7ffd35cd  pop rsi
0000782c7ffd35ce  pop rdi
0000782c7ffd35cf  pop rdx
0000782c7ffd35d0  pop rcx
0000782c7ffd35d1  pop rax
0000782c7ffd35d2  add rsp, 0x08
0000782c7ffd35d6  jmp 0x0000782C7FFD28AD
0000782c7ffd35db  sub rsp, 0x08
0000782c7ffd35df  push rax
0000782c7ffd35e0  push rcx
0000782c7ffd35e1  push rdx
0000782c7ffd35e2  push rdi
0000782c7ffd35e3  push rsi
0000782c7ffd35e4  push r8
0000782c7ffd35e6  push r9
0000782c7ffd35e8  push r10
0000782c7ffd35ea  push r11
0000782c7ffd35ec  sub rsp, 0xF0
0000782c7ffd35f3  vmovaps [rsp], xmm0
0000782c7ffd35f8  vmovaps [rsp+0x10], xmm1
0000782c7ffd35fe  vmovaps [rsp+0x20], xmm2
0000782c7ffd3604  vmovaps [rsp+0x30], xmm3
0000782c7ffd360a  vmovaps [rsp+0x40], xmm4
0000782c7ffd3610  vmovaps [rsp+0x50], xmm5
0000782c7ffd3616  vmovaps [rsp+0x60], xmm6
0000782c7ffd361c  vmovaps [rsp+0x70], xmm7
0000782c7ffd3622  vmovaps [rsp+0x80], xmm8
0000782c7ffd362b  vmovaps [rsp+0x90], xmm9
0000782c7ffd3634  vmovaps [rsp+0xA0], xmm10
0000782c7ffd363d  vmovaps [rsp+0xB0], xmm11
0000782c7ffd3646  vmovaps [rsp+0xC0], xmm12
0000782c7ffd364f  vmovaps [rsp+0xD0], xmm13
0000782c7ffd3658  vmovaps [rsp+0xE0], xmm14
0000782c7ffd3661  sub rsp, 0x40
0000782c7ffd3665  lea rdi, [rsp]
0000782c7ffd3669  lea rsi, [rsp+0x10]
0000782c7ffd366e  lea rdx, [rsp+0x20]
0000782c7ffd3673  lea rcx, [rsp+0x30]
0000782c7ffd3678  mov r8d, 0x00
0000782c7ffd367e  lea r9, [r15+0x3A8]
0000782c7ffd3685  movaps [rdi], xmm15
0000782c7ffd3689  movaps [rsi], xmm5
0000782c7ffd368c  movaps [rdx], xmm1
0000782c7ffd368f  movaps [rcx], xmm14
0000782c7ffd3693  mov rax, 0x5AE5BFFB5A50
0000782c7ffd369d  call rax
0000782c7ffd369f  movaps xmm15, [rsp]
0000782c7ffd36a4  add rsp, 0x40
0000782c7ffd36a8  vmovaps xmm0, [rsp]
0000782c7ffd36ad  vmovaps xmm1, [rsp+0x10]
0000782c7ffd36b3  vmovaps xmm2, [rsp+0x20]
0000782c7ffd36b9  vmovaps xmm3, [rsp+0x30]
0000782c7ffd36bf  vmovaps xmm4, [rsp+0x40]
0000782c7ffd36c5  vmovaps xmm5, [rsp+0x50]
0000782c7ffd36cb  vmovaps xmm6, [rsp+0x60]
0000782c7ffd36d1  vmovaps xmm7, [rsp+0x70]
0000782c7ffd36d7  vmovaps xmm8, [rsp+0x80]
0000782c7ffd36e0  vmovaps xmm9, [rsp+0x90]
0000782c7ffd36e9  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd36f2  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd36fb  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd3704  vmovaps xmm13, [rsp+0xD0]
0000782c7ffd370d  vmovaps xmm14, [rsp+0xE0]
0000782c7ffd3716  add rsp, 0xF0
0000782c7ffd371d  pop r11
0000782c7ffd371f  pop r10
0000782c7ffd3721  pop r9
0000782c7ffd3723  pop r8
0000782c7ffd3725  pop rsi
0000782c7ffd3726  pop rdi
0000782c7ffd3727  pop rdx
0000782c7ffd3728  pop rcx
0000782c7ffd3729  pop rax
0000782c7ffd372a  add rsp, 0x08
0000782c7ffd372e  jmp 0x0000782C7FFD28D0
0000782c7ffd3733  call 0x0000782C7FDFF430
0000782c7ffd3738  jmp 0x0000782C7FFD295D
0000782c7ffd373d  sub rsp, 0x08
0000782c7ffd3741  push rax
0000782c7ffd3742  push rcx
0000782c7ffd3743  push rdx
0000782c7ffd3744  push rdi
0000782c7ffd3745  push rsi
0000782c7ffd3746  push r8
0000782c7ffd3748  push r9
0000782c7ffd374a  push r10
0000782c7ffd374c  push r11
0000782c7ffd374e  sub rsp, 0xF0
0000782c7ffd3755  vmovaps [rsp], xmm0
0000782c7ffd375a  vmovaps [rsp+0x10], xmm1
0000782c7ffd3760  vmovaps [rsp+0x20], xmm2
0000782c7ffd3766  vmovaps [rsp+0x30], xmm3
0000782c7ffd376c  vmovaps [rsp+0x40], xmm4
0000782c7ffd3772  vmovaps [rsp+0x50], xmm5
0000782c7ffd3778  vmovaps [rsp+0x60], xmm6
0000782c7ffd377e  vmovaps [rsp+0x70], xmm7
0000782c7ffd3784  vmovaps [rsp+0x80], xmm8
0000782c7ffd378d  vmovaps [rsp+0x90], xmm9
0000782c7ffd3796  vmovaps [rsp+0xA0], xmm10
0000782c7ffd379f  vmovaps [rsp+0xB0], xmm11
0000782c7ffd37a8  vmovaps [rsp+0xC0], xmm12
0000782c7ffd37b1  vmovaps [rsp+0xD0], xmm14
0000782c7ffd37ba  vmovaps [rsp+0xE0], xmm15
0000782c7ffd37c3  sub rsp, 0x40
0000782c7ffd37c7  lea rdi, [rsp]
0000782c7ffd37cb  lea rsi, [rsp+0x10]
0000782c7ffd37d0  lea rdx, [rsp+0x20]
0000782c7ffd37d5  lea rcx, [rsp+0x30]
0000782c7ffd37da  mov r8d, 0x00
0000782c7ffd37e0  lea r9, [r15+0x3A8]
0000782c7ffd37e7  movaps [rdi], xmm13
0000782c7ffd37eb  movaps [rsi], xmm1
0000782c7ffd37ee  movaps [rdx], xmm15
0000782c7ffd37f2  movaps [rcx], xmm14
0000782c7ffd37f6  mov rax, 0x5AE5BFFB5A50
0000782c7ffd3800  call rax
0000782c7ffd3802  movaps xmm13, [rsp]
0000782c7ffd3807  add rsp, 0x40
0000782c7ffd380b  vmovaps xmm0, [rsp]
0000782c7ffd3810  vmovaps xmm1, [rsp+0x10]
0000782c7ffd3816  vmovaps xmm2, [rsp+0x20]
0000782c7ffd381c  vmovaps xmm3, [rsp+0x30]
0000782c7ffd3822  vmovaps xmm4, [rsp+0x40]
0000782c7ffd3828  vmovaps xmm5, [rsp+0x50]
0000782c7ffd382e  vmovaps xmm6, [rsp+0x60]
0000782c7ffd3834  vmovaps xmm7, [rsp+0x70]
0000782c7ffd383a  vmovaps xmm8, [rsp+0x80]
0000782c7ffd3843  vmovaps xmm9, [rsp+0x90]
0000782c7ffd384c  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd3855  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd385e  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd3867  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd3870  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd3879  add rsp, 0xF0
0000782c7ffd3880  pop r11
0000782c7ffd3882  pop r10
0000782c7ffd3884  pop r9
0000782c7ffd3886  pop r8
0000782c7ffd3888  pop rsi
0000782c7ffd3889  pop rdi
0000782c7ffd388a  pop rdx
0000782c7ffd388b  pop rcx
0000782c7ffd388c  pop rax
0000782c7ffd388d  add rsp, 0x08
0000782c7ffd3891  jmp 0x0000782C7FFD29C1
0000782c7ffd3896  call 0x0000782C7FDFF430
0000782c7ffd389b  jmp 0x0000782C7FFD29CE
0000782c7ffd38a0  sub rsp, 0x08
0000782c7ffd38a4  push rax
0000782c7ffd38a5  push rcx
0000782c7ffd38a6  push rdx
0000782c7ffd38a7  push rdi
0000782c7ffd38a8  push rsi
0000782c7ffd38a9  push r8
0000782c7ffd38ab  push r9
0000782c7ffd38ad  push r10
0000782c7ffd38af  push r11
0000782c7ffd38b1  sub rsp, 0xF0
0000782c7ffd38b8  vmovaps [rsp], xmm0
0000782c7ffd38bd  vmovaps [rsp+0x10], xmm1
0000782c7ffd38c3  vmovaps [rsp+0x20], xmm2
0000782c7ffd38c9  vmovaps [rsp+0x30], xmm3
0000782c7ffd38cf  vmovaps [rsp+0x40], xmm4
0000782c7ffd38d5  vmovaps [rsp+0x50], xmm5
0000782c7ffd38db  vmovaps [rsp+0x60], xmm6
0000782c7ffd38e1  vmovaps [rsp+0x70], xmm7
0000782c7ffd38e7  vmovaps [rsp+0x80], xmm8
0000782c7ffd38f0  vmovaps [rsp+0x90], xmm9
0000782c7ffd38f9  vmovaps [rsp+0xA0], xmm10
0000782c7ffd3902  vmovaps [rsp+0xB0], xmm11
0000782c7ffd390b  vmovaps [rsp+0xC0], xmm13
0000782c7ffd3914  vmovaps [rsp+0xD0], xmm14
0000782c7ffd391d  vmovaps [rsp+0xE0], xmm15
0000782c7ffd3926  sub rsp, 0x40
0000782c7ffd392a  lea rdi, [rsp]
0000782c7ffd392e  lea rsi, [rsp+0x10]
0000782c7ffd3933  lea rdx, [rsp+0x20]
0000782c7ffd3938  lea rcx, [rsp+0x30]
0000782c7ffd393d  mov r8d, 0x00
0000782c7ffd3943  lea r9, [r15+0x3A8]
0000782c7ffd394a  movaps [rdi], xmm12
0000782c7ffd394e  movaps [rsi], xmm15
0000782c7ffd3952  movaps [rdx], xmm1
0000782c7ffd3955  movaps [rcx], xmm14
0000782c7ffd3959  mov rax, 0x5AE5BFFB5A50
0000782c7ffd3963  call rax
0000782c7ffd3965  movaps xmm12, [rsp]
0000782c7ffd396a  add rsp, 0x40
0000782c7ffd396e  vmovaps xmm0, [rsp]
0000782c7ffd3973  vmovaps xmm1, [rsp+0x10]
0000782c7ffd3979  vmovaps xmm2, [rsp+0x20]
0000782c7ffd397f  vmovaps xmm3, [rsp+0x30]
0000782c7ffd3985  vmovaps xmm4, [rsp+0x40]
0000782c7ffd398b  vmovaps xmm5, [rsp+0x50]
0000782c7ffd3991  vmovaps xmm6, [rsp+0x60]
0000782c7ffd3997  vmovaps xmm7, [rsp+0x70]
0000782c7ffd399d  vmovaps xmm8, [rsp+0x80]
0000782c7ffd39a6  vmovaps xmm9, [rsp+0x90]
0000782c7ffd39af  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd39b8  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd39c1  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd39ca  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd39d3  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd39dc  add rsp, 0xF0
0000782c7ffd39e3  pop r11
0000782c7ffd39e5  pop r10
0000782c7ffd39e7  pop r9
0000782c7ffd39e9  pop r8
0000782c7ffd39eb  pop rsi
0000782c7ffd39ec  pop rdi
0000782c7ffd39ed  pop rdx
0000782c7ffd39ee  pop rcx
0000782c7ffd39ef  pop rax
0000782c7ffd39f0  add rsp, 0x08
0000782c7ffd39f4  jmp 0x0000782C7FFD29FA
0000782c7ffd39f9  sub rsp, 0x08
0000782c7ffd39fd  push rax
0000782c7ffd39fe  push rcx
0000782c7ffd39ff  push rdx
0000782c7ffd3a00  push rdi
0000782c7ffd3a01  push rsi
0000782c7ffd3a02  push r8
0000782c7ffd3a04  push r9
0000782c7ffd3a06  push r10
0000782c7ffd3a08  push r11
0000782c7ffd3a0a  sub rsp, 0xF0
0000782c7ffd3a11  vmovaps [rsp], xmm0
0000782c7ffd3a16  vmovaps [rsp+0x10], xmm1
0000782c7ffd3a1c  vmovaps [rsp+0x20], xmm2
0000782c7ffd3a22  vmovaps [rsp+0x30], xmm3
0000782c7ffd3a28  vmovaps [rsp+0x40], xmm4
0000782c7ffd3a2e  vmovaps [rsp+0x50], xmm5
0000782c7ffd3a34  vmovaps [rsp+0x60], xmm6
0000782c7ffd3a3a  vmovaps [rsp+0x70], xmm7
0000782c7ffd3a40  vmovaps [rsp+0x80], xmm8
0000782c7ffd3a49  vmovaps [rsp+0x90], xmm9
0000782c7ffd3a52  vmovaps [rsp+0xA0], xmm10
0000782c7ffd3a5b  vmovaps [rsp+0xB0], xmm11
0000782c7ffd3a64  vmovaps [rsp+0xC0], xmm12
0000782c7ffd3a6d  vmovaps [rsp+0xD0], xmm14
0000782c7ffd3a76  vmovaps [rsp+0xE0], xmm15
0000782c7ffd3a7f  sub rsp, 0x40
0000782c7ffd3a83  lea rdi, [rsp]
0000782c7ffd3a87  lea rsi, [rsp+0x10]
0000782c7ffd3a8c  lea rdx, [rsp+0x20]
0000782c7ffd3a91  lea rcx, [rsp+0x30]
0000782c7ffd3a96  mov r8d, 0x00
0000782c7ffd3a9c  lea r9, [r15+0x3A8]
0000782c7ffd3aa3  movaps [rdi], xmm13
0000782c7ffd3aa7  movaps [rsi], xmm1
0000782c7ffd3aaa  movaps [rdx], xmm15
0000782c7ffd3aae  movaps [rcx], xmm14
0000782c7ffd3ab2  mov rax, 0x5AE5BFFB5A50
0000782c7ffd3abc  call rax
0000782c7ffd3abe  movaps xmm13, [rsp]
0000782c7ffd3ac3  add rsp, 0x40
0000782c7ffd3ac7  vmovaps xmm0, [rsp]
0000782c7ffd3acc  vmovaps xmm1, [rsp+0x10]
0000782c7ffd3ad2  vmovaps xmm2, [rsp+0x20]
0000782c7ffd3ad8  vmovaps xmm3, [rsp+0x30]
0000782c7ffd3ade  vmovaps xmm4, [rsp+0x40]
0000782c7ffd3ae4  vmovaps xmm5, [rsp+0x50]
0000782c7ffd3aea  vmovaps xmm6, [rsp+0x60]
0000782c7ffd3af0  vmovaps xmm7, [rsp+0x70]
0000782c7ffd3af6  vmovaps xmm8, [rsp+0x80]
0000782c7ffd3aff  vmovaps xmm9, [rsp+0x90]
0000782c7ffd3b08  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd3b11  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd3b1a  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd3b23  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd3b2c  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd3b35  add rsp, 0xF0
0000782c7ffd3b3c  pop r11
0000782c7ffd3b3e  pop r10
0000782c7ffd3b40  pop r9
0000782c7ffd3b42  pop r8
0000782c7ffd3b44  pop rsi
0000782c7ffd3b45  pop rdi
0000782c7ffd3b46  pop rdx
0000782c7ffd3b47  pop rcx
0000782c7ffd3b48  pop rax
0000782c7ffd3b49  add rsp, 0x08
0000782c7ffd3b4d  jmp 0x0000782C7FFD2B77
0000782c7ffd3b52  sub rsp, 0x08
0000782c7ffd3b56  push rax
0000782c7ffd3b57  push rcx
0000782c7ffd3b58  push rdx
0000782c7ffd3b59  push rdi
0000782c7ffd3b5a  push rsi
0000782c7ffd3b5b  push r8
0000782c7ffd3b5d  push r9
0000782c7ffd3b5f  push r10
0000782c7ffd3b61  push r11
0000782c7ffd3b63  sub rsp, 0xF0
0000782c7ffd3b6a  vmovaps [rsp], xmm0
0000782c7ffd3b6f  vmovaps [rsp+0x10], xmm1
0000782c7ffd3b75  vmovaps [rsp+0x20], xmm2
0000782c7ffd3b7b  vmovaps [rsp+0x30], xmm3
0000782c7ffd3b81  vmovaps [rsp+0x40], xmm4
0000782c7ffd3b87  vmovaps [rsp+0x50], xmm5
0000782c7ffd3b8d  vmovaps [rsp+0x60], xmm6
0000782c7ffd3b93  vmovaps [rsp+0x70], xmm7
0000782c7ffd3b99  vmovaps [rsp+0x80], xmm8
0000782c7ffd3ba2  vmovaps [rsp+0x90], xmm9
0000782c7ffd3bab  vmovaps [rsp+0xA0], xmm10
0000782c7ffd3bb4  vmovaps [rsp+0xB0], xmm11
0000782c7ffd3bbd  vmovaps [rsp+0xC0], xmm13
0000782c7ffd3bc6  vmovaps [rsp+0xD0], xmm14
0000782c7ffd3bcf  vmovaps [rsp+0xE0], xmm15
0000782c7ffd3bd8  sub rsp, 0x40
0000782c7ffd3bdc  lea rdi, [rsp]
0000782c7ffd3be0  lea rsi, [rsp+0x10]
0000782c7ffd3be5  lea rdx, [rsp+0x20]
0000782c7ffd3bea  lea rcx, [rsp+0x30]
0000782c7ffd3bef  mov r8d, 0x00
0000782c7ffd3bf5  lea r9, [r15+0x3A8]
0000782c7ffd3bfc  movaps [rdi], xmm12
0000782c7ffd3c00  movaps [rsi], xmm15
0000782c7ffd3c04  movaps [rdx], xmm14
0000782c7ffd3c08  movaps [rcx], xmm1
0000782c7ffd3c0b  mov rax, 0x5AE5BFFB5A50
0000782c7ffd3c15  call rax
0000782c7ffd3c17  movaps xmm12, [rsp]
0000782c7ffd3c1c  add rsp, 0x40
0000782c7ffd3c20  vmovaps xmm0, [rsp]
0000782c7ffd3c25  vmovaps xmm1, [rsp+0x10]
0000782c7ffd3c2b  vmovaps xmm2, [rsp+0x20]
0000782c7ffd3c31  vmovaps xmm3, [rsp+0x30]
0000782c7ffd3c37  vmovaps xmm4, [rsp+0x40]
0000782c7ffd3c3d  vmovaps xmm5, [rsp+0x50]
0000782c7ffd3c43  vmovaps xmm6, [rsp+0x60]
0000782c7ffd3c49  vmovaps xmm7, [rsp+0x70]
0000782c7ffd3c4f  vmovaps xmm8, [rsp+0x80]
0000782c7ffd3c58  vmovaps xmm9, [rsp+0x90]
0000782c7ffd3c61  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd3c6a  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd3c73  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd3c7c  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd3c85  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd3c8e  add rsp, 0xF0
0000782c7ffd3c95  pop r11
0000782c7ffd3c97  pop r10
0000782c7ffd3c99  pop r9
0000782c7ffd3c9b  pop r8
0000782c7ffd3c9d  pop rsi
0000782c7ffd3c9e  pop rdi
0000782c7ffd3c9f  pop rdx
0000782c7ffd3ca0  pop rcx
0000782c7ffd3ca1  pop rax
0000782c7ffd3ca2  add rsp, 0x08
0000782c7ffd3ca6  jmp 0x0000782C7FFD2BB2
0000782c7ffd3cab  sub rsp, 0x08
0000782c7ffd3caf  push rax
0000782c7ffd3cb0  push rcx
0000782c7ffd3cb1  push rdx
0000782c7ffd3cb2  push rdi
0000782c7ffd3cb3  push rsi
0000782c7ffd3cb4  push r8
0000782c7ffd3cb6  push r9
0000782c7ffd3cb8  push r10
0000782c7ffd3cba  push r11
0000782c7ffd3cbc  sub rsp, 0xF0
0000782c7ffd3cc3  vmovaps [rsp], xmm0
0000782c7ffd3cc8  vmovaps [rsp+0x10], xmm1
0000782c7ffd3cce  vmovaps [rsp+0x20], xmm2
0000782c7ffd3cd4  vmovaps [rsp+0x30], xmm3
0000782c7ffd3cda  vmovaps [rsp+0x40], xmm4
0000782c7ffd3ce0  vmovaps [rsp+0x50], xmm5
0000782c7ffd3ce6  vmovaps [rsp+0x60], xmm6
0000782c7ffd3cec  vmovaps [rsp+0x70], xmm7
0000782c7ffd3cf2  vmovaps [rsp+0x80], xmm8
0000782c7ffd3cfb  vmovaps [rsp+0x90], xmm9
0000782c7ffd3d04  vmovaps [rsp+0xA0], xmm10
0000782c7ffd3d0d  vmovaps [rsp+0xB0], xmm11
0000782c7ffd3d16  vmovaps [rsp+0xC0], xmm12
0000782c7ffd3d1f  vmovaps [rsp+0xD0], xmm14
0000782c7ffd3d28  vmovaps [rsp+0xE0], xmm15
0000782c7ffd3d31  sub rsp, 0x40
0000782c7ffd3d35  lea rdi, [rsp]
0000782c7ffd3d39  lea rsi, [rsp+0x10]
0000782c7ffd3d3e  lea rdx, [rsp+0x20]
0000782c7ffd3d43  lea rcx, [rsp+0x30]
0000782c7ffd3d48  mov r8d, 0x00
0000782c7ffd3d4e  lea r9, [r15+0x3A8]
0000782c7ffd3d55  movaps [rdi], xmm13
0000782c7ffd3d59  movaps [rsi], xmm15
0000782c7ffd3d5d  movaps [rdx], xmm14
0000782c7ffd3d61  movaps [rcx], xmm1
0000782c7ffd3d64  mov rax, 0x5AE5BFFB5A50
0000782c7ffd3d6e  call rax
0000782c7ffd3d70  movaps xmm13, [rsp]
0000782c7ffd3d75  add rsp, 0x40
0000782c7ffd3d79  vmovaps xmm0, [rsp]
0000782c7ffd3d7e  vmovaps xmm1, [rsp+0x10]
0000782c7ffd3d84  vmovaps xmm2, [rsp+0x20]
0000782c7ffd3d8a  vmovaps xmm3, [rsp+0x30]
0000782c7ffd3d90  vmovaps xmm4, [rsp+0x40]
0000782c7ffd3d96  vmovaps xmm5, [rsp+0x50]
0000782c7ffd3d9c  vmovaps xmm6, [rsp+0x60]
0000782c7ffd3da2  vmovaps xmm7, [rsp+0x70]
0000782c7ffd3da8  vmovaps xmm8, [rsp+0x80]
0000782c7ffd3db1  vmovaps xmm9, [rsp+0x90]
0000782c7ffd3dba  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd3dc3  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd3dcc  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd3dd5  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd3dde  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd3de7  add rsp, 0xF0
0000782c7ffd3dee  pop r11
0000782c7ffd3df0  pop r10
0000782c7ffd3df2  pop r9
0000782c7ffd3df4  pop r8
0000782c7ffd3df6  pop rsi
0000782c7ffd3df7  pop rdi
0000782c7ffd3df8  pop rdx
0000782c7ffd3df9  pop rcx
0000782c7ffd3dfa  pop rax
0000782c7ffd3dfb  add rsp, 0x08
0000782c7ffd3dff  jmp 0x0000782C7FFD2BEA
0000782c7ffd3e04  sub rsp, 0x08
0000782c7ffd3e08  push rax
0000782c7ffd3e09  push rcx
0000782c7ffd3e0a  push rdx
0000782c7ffd3e0b  push rdi
0000782c7ffd3e0c  push rsi
0000782c7ffd3e0d  push r8
0000782c7ffd3e0f  push r9
0000782c7ffd3e11  push r10
0000782c7ffd3e13  push r11
0000782c7ffd3e15  sub rsp, 0xF0
0000782c7ffd3e1c  vmovaps [rsp], xmm0
0000782c7ffd3e21  vmovaps [rsp+0x10], xmm1
0000782c7ffd3e27  vmovaps [rsp+0x20], xmm2
0000782c7ffd3e2d  vmovaps [rsp+0x30], xmm3
0000782c7ffd3e33  vmovaps [rsp+0x40], xmm4
0000782c7ffd3e39  vmovaps [rsp+0x50], xmm5
0000782c7ffd3e3f  vmovaps [rsp+0x60], xmm6
0000782c7ffd3e45  vmovaps [rsp+0x70], xmm7
0000782c7ffd3e4b  vmovaps [rsp+0x80], xmm8
0000782c7ffd3e54  vmovaps [rsp+0x90], xmm9
0000782c7ffd3e5d  vmovaps [rsp+0xA0], xmm10
0000782c7ffd3e66  vmovaps [rsp+0xB0], xmm11
0000782c7ffd3e6f  vmovaps [rsp+0xC0], xmm13
0000782c7ffd3e78  vmovaps [rsp+0xD0], xmm14
0000782c7ffd3e81  vmovaps [rsp+0xE0], xmm15
0000782c7ffd3e8a  sub rsp, 0x40
0000782c7ffd3e8e  lea rdi, [rsp]
0000782c7ffd3e92  lea rsi, [rsp+0x10]
0000782c7ffd3e97  lea rdx, [rsp+0x20]
0000782c7ffd3e9c  lea rcx, [rsp+0x30]
0000782c7ffd3ea1  mov r8d, 0x00
0000782c7ffd3ea7  lea r9, [r15+0x3A8]
0000782c7ffd3eae  movaps [rdi], xmm12
0000782c7ffd3eb2  movaps [rsi], xmm15
0000782c7ffd3eb6  movaps [rdx], xmm14
0000782c7ffd3eba  movaps [rcx], xmm1
0000782c7ffd3ebd  mov rax, 0x5AE5BFFB5A50
0000782c7ffd3ec7  call rax
0000782c7ffd3ec9  movaps xmm12, [rsp]
0000782c7ffd3ece  add rsp, 0x40
0000782c7ffd3ed2  vmovaps xmm0, [rsp]
0000782c7ffd3ed7  vmovaps xmm1, [rsp+0x10]
0000782c7ffd3edd  vmovaps xmm2, [rsp+0x20]
0000782c7ffd3ee3  vmovaps xmm3, [rsp+0x30]
0000782c7ffd3ee9  vmovaps xmm4, [rsp+0x40]
0000782c7ffd3eef  vmovaps xmm5, [rsp+0x50]
0000782c7ffd3ef5  vmovaps xmm6, [rsp+0x60]
0000782c7ffd3efb  vmovaps xmm7, [rsp+0x70]
0000782c7ffd3f01  vmovaps xmm8, [rsp+0x80]
0000782c7ffd3f0a  vmovaps xmm9, [rsp+0x90]
0000782c7ffd3f13  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd3f1c  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd3f25  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd3f2e  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd3f37  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd3f40  add rsp, 0xF0
0000782c7ffd3f47  pop r11
0000782c7ffd3f49  pop r10
0000782c7ffd3f4b  pop r9
0000782c7ffd3f4d  pop r8
0000782c7ffd3f4f  pop rsi
0000782c7ffd3f50  pop rdi
0000782c7ffd3f51  pop rdx
0000782c7ffd3f52  pop rcx
0000782c7ffd3f53  pop rax
0000782c7ffd3f54  add rsp, 0x08
0000782c7ffd3f58  jmp 0x0000782C7FFD2C3D
0000782c7ffd3f5d  sub rsp, 0x08
0000782c7ffd3f61  push rax
0000782c7ffd3f62  push rcx
0000782c7ffd3f63  push rdx
0000782c7ffd3f64  push rdi
0000782c7ffd3f65  push rsi
0000782c7ffd3f66  push r8
0000782c7ffd3f68  push r9
0000782c7ffd3f6a  push r10
0000782c7ffd3f6c  push r11
0000782c7ffd3f6e  sub rsp, 0xF0
0000782c7ffd3f75  vmovaps [rsp], xmm0
0000782c7ffd3f7a  vmovaps [rsp+0x10], xmm1
0000782c7ffd3f80  vmovaps [rsp+0x20], xmm2
0000782c7ffd3f86  vmovaps [rsp+0x30], xmm3
0000782c7ffd3f8c  vmovaps [rsp+0x40], xmm4
0000782c7ffd3f92  vmovaps [rsp+0x50], xmm5
0000782c7ffd3f98  vmovaps [rsp+0x60], xmm6
0000782c7ffd3f9e  vmovaps [rsp+0x70], xmm7
0000782c7ffd3fa4  vmovaps [rsp+0x80], xmm8
0000782c7ffd3fad  vmovaps [rsp+0x90], xmm9
0000782c7ffd3fb6  vmovaps [rsp+0xA0], xmm10
0000782c7ffd3fbf  vmovaps [rsp+0xB0], xmm11
0000782c7ffd3fc8  vmovaps [rsp+0xC0], xmm12
0000782c7ffd3fd1  vmovaps [rsp+0xD0], xmm13
0000782c7ffd3fda  vmovaps [rsp+0xE0], xmm15
0000782c7ffd3fe3  sub rsp, 0x40
0000782c7ffd3fe7  lea rdi, [rsp]
0000782c7ffd3feb  lea rsi, [rsp+0x10]
0000782c7ffd3ff0  lea rdx, [rsp+0x20]
0000782c7ffd3ff5  lea rcx, [rsp+0x30]
0000782c7ffd3ffa  mov r8d, 0x00
0000782c7ffd4000  lea r9, [r15+0x3A8]
0000782c7ffd4007  movaps [rdi], xmm14
0000782c7ffd400b  movaps [rsi], xmm3
0000782c7ffd400e  movaps [rdx], xmm1
0000782c7ffd4011  movaps [rcx], xmm15
0000782c7ffd4015  mov rax, 0x5AE5BFFB5A50
0000782c7ffd401f  call rax
0000782c7ffd4021  movaps xmm14, [rsp]
0000782c7ffd4026  add rsp, 0x40
0000782c7ffd402a  vmovaps xmm0, [rsp]
0000782c7ffd402f  vmovaps xmm1, [rsp+0x10]
0000782c7ffd4035  vmovaps xmm2, [rsp+0x20]
0000782c7ffd403b  vmovaps xmm3, [rsp+0x30]
0000782c7ffd4041  vmovaps xmm4, [rsp+0x40]
0000782c7ffd4047  vmovaps xmm5, [rsp+0x50]
0000782c7ffd404d  vmovaps xmm6, [rsp+0x60]
0000782c7ffd4053  vmovaps xmm7, [rsp+0x70]
0000782c7ffd4059  vmovaps xmm8, [rsp+0x80]
0000782c7ffd4062  vmovaps xmm9, [rsp+0x90]
0000782c7ffd406b  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd4074  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd407d  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd4086  vmovaps xmm13, [rsp+0xD0]
0000782c7ffd408f  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd4098  add rsp, 0xF0
0000782c7ffd409f  pop r11
0000782c7ffd40a1  pop r10
0000782c7ffd40a3  pop r9
0000782c7ffd40a5  pop r8
0000782c7ffd40a7  pop rsi
0000782c7ffd40a8  pop rdi
0000782c7ffd40a9  pop rdx
0000782c7ffd40aa  pop rcx
0000782c7ffd40ab  pop rax
0000782c7ffd40ac  add rsp, 0x08
0000782c7ffd40b0  jmp 0x0000782C7FFD2CF7
0000782c7ffd40b5  sub rsp, 0x08
0000782c7ffd40b9  push rax
0000782c7ffd40ba  push rcx
0000782c7ffd40bb  push rdx
0000782c7ffd40bc  push rdi
0000782c7ffd40bd  push rsi
0000782c7ffd40be  push r8
0000782c7ffd40c0  push r9
0000782c7ffd40c2  push r10
0000782c7ffd40c4  push r11
0000782c7ffd40c6  sub rsp, 0xF0
0000782c7ffd40cd  vmovaps [rsp], xmm0
0000782c7ffd40d2  vmovaps [rsp+0x10], xmm1
0000782c7ffd40d8  vmovaps [rsp+0x20], xmm2
0000782c7ffd40de  vmovaps [rsp+0x30], xmm3
0000782c7ffd40e4  vmovaps [rsp+0x40], xmm4
0000782c7ffd40ea  vmovaps [rsp+0x50], xmm5
0000782c7ffd40f0  vmovaps [rsp+0x60], xmm6
0000782c7ffd40f6  vmovaps [rsp+0x70], xmm7
0000782c7ffd40fc  vmovaps [rsp+0x80], xmm8
0000782c7ffd4105  vmovaps [rsp+0x90], xmm9
0000782c7ffd410e  vmovaps [rsp+0xA0], xmm10
0000782c7ffd4117  vmovaps [rsp+0xB0], xmm11
0000782c7ffd4120  vmovaps [rsp+0xC0], xmm12
0000782c7ffd4129  vmovaps [rsp+0xD0], xmm14
0000782c7ffd4132  vmovaps [rsp+0xE0], xmm15
0000782c7ffd413b  sub rsp, 0x40
0000782c7ffd413f  lea rdi, [rsp]
0000782c7ffd4143  lea rsi, [rsp+0x10]
0000782c7ffd4148  lea rdx, [rsp+0x20]
0000782c7ffd414d  lea rcx, [rsp+0x30]
0000782c7ffd4152  mov r8d, 0x00
0000782c7ffd4158  lea r9, [r15+0x3A8]
0000782c7ffd415f  movaps [rdi], xmm13
0000782c7ffd4163  movaps [rsi], xmm15
0000782c7ffd4167  movaps [rdx], xmm10
0000782c7ffd416b  movaps [rcx], xmm1
0000782c7ffd416e  mov rax, 0x5AE5BFFB5A50
0000782c7ffd4178  call rax
0000782c7ffd417a  movaps xmm13, [rsp]
0000782c7ffd417f  add rsp, 0x40
0000782c7ffd4183  vmovaps xmm0, [rsp]
0000782c7ffd4188  vmovaps xmm1, [rsp+0x10]
0000782c7ffd418e  vmovaps xmm2, [rsp+0x20]
0000782c7ffd4194  vmovaps xmm3, [rsp+0x30]
0000782c7ffd419a  vmovaps xmm4, [rsp+0x40]
0000782c7ffd41a0  vmovaps xmm5, [rsp+0x50]
0000782c7ffd41a6  vmovaps xmm6, [rsp+0x60]
0000782c7ffd41ac  vmovaps xmm7, [rsp+0x70]
0000782c7ffd41b2  vmovaps xmm8, [rsp+0x80]
0000782c7ffd41bb  vmovaps xmm9, [rsp+0x90]
0000782c7ffd41c4  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd41cd  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd41d6  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd41df  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd41e8  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd41f1  add rsp, 0xF0
0000782c7ffd41f8  pop r11
0000782c7ffd41fa  pop r10
0000782c7ffd41fc  pop r9
0000782c7ffd41fe  pop r8
0000782c7ffd4200  pop rsi
0000782c7ffd4201  pop rdi
0000782c7ffd4202  pop rdx
0000782c7ffd4203  pop rcx
0000782c7ffd4204  pop rax
0000782c7ffd4205  add rsp, 0x08
0000782c7ffd4209  jmp 0x0000782C7FFD2D26
0000782c7ffd420e  sub rsp, 0x08
0000782c7ffd4212  push rax
0000782c7ffd4213  push rcx
0000782c7ffd4214  push rdx
0000782c7ffd4215  push rdi
0000782c7ffd4216  push rsi
0000782c7ffd4217  push r8
0000782c7ffd4219  push r9
0000782c7ffd421b  push r10
0000782c7ffd421d  push r11
0000782c7ffd421f  sub rsp, 0xF0
0000782c7ffd4226  vmovaps [rsp], xmm0
0000782c7ffd422b  vmovaps [rsp+0x10], xmm1
0000782c7ffd4231  vmovaps [rsp+0x20], xmm2
0000782c7ffd4237  vmovaps [rsp+0x30], xmm3
0000782c7ffd423d  vmovaps [rsp+0x40], xmm4
0000782c7ffd4243  vmovaps [rsp+0x50], xmm5
0000782c7ffd4249  vmovaps [rsp+0x60], xmm6
0000782c7ffd424f  vmovaps [rsp+0x70], xmm7
0000782c7ffd4255  vmovaps [rsp+0x80], xmm8
0000782c7ffd425e  vmovaps [rsp+0x90], xmm9
0000782c7ffd4267  vmovaps [rsp+0xA0], xmm11
0000782c7ffd4270  vmovaps [rsp+0xB0], xmm12
0000782c7ffd4279  vmovaps [rsp+0xC0], xmm13
0000782c7ffd4282  vmovaps [rsp+0xD0], xmm14
0000782c7ffd428b  vmovaps [rsp+0xE0], xmm15
0000782c7ffd4294  sub rsp, 0x40
0000782c7ffd4298  lea rdi, [rsp]
0000782c7ffd429c  lea rsi, [rsp+0x10]
0000782c7ffd42a1  lea rdx, [rsp+0x20]
0000782c7ffd42a6  lea rcx, [rsp+0x30]
0000782c7ffd42ab  mov r8d, 0x00
0000782c7ffd42b1  lea r9, [r15+0x3A8]
0000782c7ffd42b8  movaps [rdi], xmm10
0000782c7ffd42bc  movaps [rsi], xmm15
0000782c7ffd42c0  movaps [rdx], xmm11
0000782c7ffd42c4  movaps [rcx], xmm1
0000782c7ffd42c7  mov rax, 0x5AE5BFFB5A50
0000782c7ffd42d1  call rax
0000782c7ffd42d3  movaps xmm10, [rsp]
0000782c7ffd42d8  add rsp, 0x40
0000782c7ffd42dc  vmovaps xmm0, [rsp]
0000782c7ffd42e1  vmovaps xmm1, [rsp+0x10]
0000782c7ffd42e7  vmovaps xmm2, [rsp+0x20]
0000782c7ffd42ed  vmovaps xmm3, [rsp+0x30]
0000782c7ffd42f3  vmovaps xmm4, [rsp+0x40]
0000782c7ffd42f9  vmovaps xmm5, [rsp+0x50]
0000782c7ffd42ff  vmovaps xmm6, [rsp+0x60]
0000782c7ffd4305  vmovaps xmm7, [rsp+0x70]
0000782c7ffd430b  vmovaps xmm8, [rsp+0x80]
0000782c7ffd4314  vmovaps xmm9, [rsp+0x90]
0000782c7ffd431d  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd4326  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd432f  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd4338  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd4341  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd434a  add rsp, 0xF0
0000782c7ffd4351  pop r11
0000782c7ffd4353  pop r10
0000782c7ffd4355  pop r9
0000782c7ffd4357  pop r8
0000782c7ffd4359  pop rsi
0000782c7ffd435a  pop rdi
0000782c7ffd435b  pop rdx
0000782c7ffd435c  pop rcx
0000782c7ffd435d  pop rax
0000782c7ffd435e  add rsp, 0x08
0000782c7ffd4362  jmp 0x0000782C7FFD2D55
0000782c7ffd4367  sub rsp, 0x08
0000782c7ffd436b  push rax
0000782c7ffd436c  push rcx
0000782c7ffd436d  push rdx
0000782c7ffd436e  push rdi
0000782c7ffd436f  push rsi
0000782c7ffd4370  push r8
0000782c7ffd4372  push r9
0000782c7ffd4374  push r10
0000782c7ffd4376  push r11
0000782c7ffd4378  sub rsp, 0xF0
0000782c7ffd437f  vmovaps [rsp], xmm0
0000782c7ffd4384  vmovaps [rsp+0x10], xmm1
0000782c7ffd438a  vmovaps [rsp+0x20], xmm2
0000782c7ffd4390  vmovaps [rsp+0x30], xmm3
0000782c7ffd4396  vmovaps [rsp+0x40], xmm4
0000782c7ffd439c  vmovaps [rsp+0x50], xmm5
0000782c7ffd43a2  vmovaps [rsp+0x60], xmm6
0000782c7ffd43a8  vmovaps [rsp+0x70], xmm7
0000782c7ffd43ae  vmovaps [rsp+0x80], xmm8
0000782c7ffd43b7  vmovaps [rsp+0x90], xmm9
0000782c7ffd43c0  vmovaps [rsp+0xA0], xmm10
0000782c7ffd43c9  vmovaps [rsp+0xB0], xmm11
0000782c7ffd43d2  vmovaps [rsp+0xC0], xmm12
0000782c7ffd43db  vmovaps [rsp+0xD0], xmm13
0000782c7ffd43e4  vmovaps [rsp+0xE0], xmm14
0000782c7ffd43ed  sub rsp, 0x40
0000782c7ffd43f1  lea rdi, [rsp]
0000782c7ffd43f5  lea rsi, [rsp+0x10]
0000782c7ffd43fa  lea rdx, [rsp+0x20]
0000782c7ffd43ff  lea rcx, [rsp+0x30]
0000782c7ffd4404  mov r8d, 0x00
0000782c7ffd440a  lea r9, [r15+0x3A8]
0000782c7ffd4411  movaps [rdi], xmm15
0000782c7ffd4415  movaps [rsi], xmm12
0000782c7ffd4419  movaps [rdx], xmm5
0000782c7ffd441c  movaps [rcx], xmm1
0000782c7ffd441f  mov rax, 0x5AE5BFFB5A50
0000782c7ffd4429  call rax
0000782c7ffd442b  movaps xmm15, [rsp]
0000782c7ffd4430  add rsp, 0x40
0000782c7ffd4434  vmovaps xmm0, [rsp]
0000782c7ffd4439  vmovaps xmm1, [rsp+0x10]
0000782c7ffd443f  vmovaps xmm2, [rsp+0x20]
0000782c7ffd4445  vmovaps xmm3, [rsp+0x30]
0000782c7ffd444b  vmovaps xmm4, [rsp+0x40]
0000782c7ffd4451  vmovaps xmm5, [rsp+0x50]
0000782c7ffd4457  vmovaps xmm6, [rsp+0x60]
0000782c7ffd445d  vmovaps xmm7, [rsp+0x70]
0000782c7ffd4463  vmovaps xmm8, [rsp+0x80]
0000782c7ffd446c  vmovaps xmm9, [rsp+0x90]
0000782c7ffd4475  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd447e  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd4487  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd4490  vmovaps xmm13, [rsp+0xD0]
0000782c7ffd4499  vmovaps xmm14, [rsp+0xE0]
0000782c7ffd44a2  add rsp, 0xF0
0000782c7ffd44a9  pop r11
0000782c7ffd44ab  pop r10
0000782c7ffd44ad  pop r9
0000782c7ffd44af  pop r8
0000782c7ffd44b1  pop rsi
0000782c7ffd44b2  pop rdi
0000782c7ffd44b3  pop rdx
0000782c7ffd44b4  pop rcx
0000782c7ffd44b5  pop rax
0000782c7ffd44b6  add rsp, 0x08
0000782c7ffd44ba  jmp 0x0000782C7FFD2D7E
0000782c7ffd44bf  sub rsp, 0x08
0000782c7ffd44c3  push rax
0000782c7ffd44c4  push rcx
0000782c7ffd44c5  push rdx
0000782c7ffd44c6  push rdi
0000782c7ffd44c7  push rsi
0000782c7ffd44c8  push r8
0000782c7ffd44ca  push r9
0000782c7ffd44cc  push r10
0000782c7ffd44ce  push r11
0000782c7ffd44d0  sub rsp, 0xF0
0000782c7ffd44d7  vmovaps [rsp], xmm0
0000782c7ffd44dc  vmovaps [rsp+0x10], xmm1
0000782c7ffd44e2  vmovaps [rsp+0x20], xmm2
0000782c7ffd44e8  vmovaps [rsp+0x30], xmm3
0000782c7ffd44ee  vmovaps [rsp+0x40], xmm4
0000782c7ffd44f4  vmovaps [rsp+0x50], xmm6
0000782c7ffd44fa  vmovaps [rsp+0x60], xmm7
0000782c7ffd4500  vmovaps [rsp+0x70], xmm8
0000782c7ffd4506  vmovaps [rsp+0x80], xmm9
0000782c7ffd450f  vmovaps [rsp+0x90], xmm10
0000782c7ffd4518  vmovaps [rsp+0xA0], xmm11
0000782c7ffd4521  vmovaps [rsp+0xB0], xmm12
0000782c7ffd452a  vmovaps [rsp+0xC0], xmm13
0000782c7ffd4533  vmovaps [rsp+0xD0], xmm14
0000782c7ffd453c  vmovaps [rsp+0xE0], xmm15
0000782c7ffd4545  sub rsp, 0x40
0000782c7ffd4549  lea rdi, [rsp]
0000782c7ffd454d  lea rsi, [rsp+0x10]
0000782c7ffd4552  lea rdx, [rsp+0x20]
0000782c7ffd4557  lea rcx, [rsp+0x30]
0000782c7ffd455c  mov r8d, 0x00
0000782c7ffd4562  lea r9, [r15+0x3A8]
0000782c7ffd4569  movaps [rdi], xmm5
0000782c7ffd456c  movaps [rsi], xmm13
0000782c7ffd4570  movaps [rdx], xmm11
0000782c7ffd4574  movaps [rcx], xmm12
0000782c7ffd4578  mov rax, 0x5AE5BFFB5A50
0000782c7ffd4582  call rax
0000782c7ffd4584  movaps xmm5, [rsp]
0000782c7ffd4588  add rsp, 0x40
0000782c7ffd458c  vmovaps xmm0, [rsp]
0000782c7ffd4591  vmovaps xmm1, [rsp+0x10]
0000782c7ffd4597  vmovaps xmm2, [rsp+0x20]
0000782c7ffd459d  vmovaps xmm3, [rsp+0x30]
0000782c7ffd45a3  vmovaps xmm4, [rsp+0x40]
0000782c7ffd45a9  vmovaps xmm6, [rsp+0x50]
0000782c7ffd45af  vmovaps xmm7, [rsp+0x60]
0000782c7ffd45b5  vmovaps xmm8, [rsp+0x70]
0000782c7ffd45bb  vmovaps xmm9, [rsp+0x80]
0000782c7ffd45c4  vmovaps xmm10, [rsp+0x90]
0000782c7ffd45cd  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd45d6  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd45df  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd45e8  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd45f1  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd45fa  add rsp, 0xF0
0000782c7ffd4601  pop r11
0000782c7ffd4603  pop r10
0000782c7ffd4605  pop r9
0000782c7ffd4607  pop r8
0000782c7ffd4609  pop rsi
0000782c7ffd460a  pop rdi
0000782c7ffd460b  pop rdx
0000782c7ffd460c  pop rcx
0000782c7ffd460d  pop rax
0000782c7ffd460e  add rsp, 0x08
0000782c7ffd4612  jmp 0x0000782C7FFD2DDD
0000782c7ffd4617  sub rsp, 0x08
0000782c7ffd461b  push rax
0000782c7ffd461c  push rcx
0000782c7ffd461d  push rdx
0000782c7ffd461e  push rdi
0000782c7ffd461f  push rsi
0000782c7ffd4620  push r8
0000782c7ffd4622  push r9
0000782c7ffd4624  push r10
0000782c7ffd4626  push r11
0000782c7ffd4628  sub rsp, 0xF0
0000782c7ffd462f  vmovaps [rsp], xmm0
0000782c7ffd4634  vmovaps [rsp+0x10], xmm1
0000782c7ffd463a  vmovaps [rsp+0x20], xmm2
0000782c7ffd4640  vmovaps [rsp+0x30], xmm3
0000782c7ffd4646  vmovaps [rsp+0x40], xmm4
0000782c7ffd464c  vmovaps [rsp+0x50], xmm5
0000782c7ffd4652  vmovaps [rsp+0x60], xmm6
0000782c7ffd4658  vmovaps [rsp+0x70], xmm7
0000782c7ffd465e  vmovaps [rsp+0x80], xmm8
0000782c7ffd4667  vmovaps [rsp+0x90], xmm9
0000782c7ffd4670  vmovaps [rsp+0xA0], xmm10
0000782c7ffd4679  vmovaps [rsp+0xB0], xmm11
0000782c7ffd4682  vmovaps [rsp+0xC0], xmm13
0000782c7ffd468b  vmovaps [rsp+0xD0], xmm14
0000782c7ffd4694  vmovaps [rsp+0xE0], xmm15
0000782c7ffd469d  sub rsp, 0x40
0000782c7ffd46a1  lea rdi, [rsp]
0000782c7ffd46a5  lea rsi, [rsp+0x10]
0000782c7ffd46aa  lea rdx, [rsp+0x20]
0000782c7ffd46af  lea rcx, [rsp+0x30]
0000782c7ffd46b4  mov r8d, 0x00
0000782c7ffd46ba  lea r9, [r15+0x3A8]
0000782c7ffd46c1  movaps [rdi], xmm12
0000782c7ffd46c5  movaps [rsi], xmm14
0000782c7ffd46c9  movaps [rdx], xmm9
0000782c7ffd46cd  movaps [rcx], xmm13
0000782c7ffd46d1  mov rax, 0x5AE5BFFB5A50
0000782c7ffd46db  call rax
0000782c7ffd46dd  movaps xmm12, [rsp]
0000782c7ffd46e2  add rsp, 0x40
0000782c7ffd46e6  vmovaps xmm0, [rsp]
0000782c7ffd46eb  vmovaps xmm1, [rsp+0x10]
0000782c7ffd46f1  vmovaps xmm2, [rsp+0x20]
0000782c7ffd46f7  vmovaps xmm3, [rsp+0x30]
0000782c7ffd46fd  vmovaps xmm4, [rsp+0x40]
0000782c7ffd4703  vmovaps xmm5, [rsp+0x50]
0000782c7ffd4709  vmovaps xmm6, [rsp+0x60]
0000782c7ffd470f  vmovaps xmm7, [rsp+0x70]
0000782c7ffd4715  vmovaps xmm8, [rsp+0x80]
0000782c7ffd471e  vmovaps xmm9, [rsp+0x90]
0000782c7ffd4727  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd4730  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd4739  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd4742  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd474b  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd4754  add rsp, 0xF0
0000782c7ffd475b  pop r11
0000782c7ffd475d  pop r10
0000782c7ffd475f  pop r9
0000782c7ffd4761  pop r8
0000782c7ffd4763  pop rsi
0000782c7ffd4764  pop rdi
0000782c7ffd4765  pop rdx
0000782c7ffd4766  pop rcx
0000782c7ffd4767  pop rax
0000782c7ffd4768  add rsp, 0x08
0000782c7ffd476c  jmp 0x0000782C7FFD2E06
0000782c7ffd4771  call 0x0000782C7FE0D4E0
0000782c7ffd4776  jmp 0x0000782C7FFD2E13
0000782c7ffd477b  sub rsp, 0x08
0000782c7ffd477f  push rax
0000782c7ffd4780  push rcx
0000782c7ffd4781  push rdx
0000782c7ffd4782  push rdi
0000782c7ffd4783  push rsi
0000782c7ffd4784  push r8
0000782c7ffd4786  push r9
0000782c7ffd4788  push r10
0000782c7ffd478a  push r11
0000782c7ffd478c  sub rsp, 0xF0
0000782c7ffd4793  vmovaps [rsp], xmm0
0000782c7ffd4798  vmovaps [rsp+0x10], xmm1
0000782c7ffd479e  vmovaps [rsp+0x20], xmm2
0000782c7ffd47a4  vmovaps [rsp+0x30], xmm3
0000782c7ffd47aa  vmovaps [rsp+0x40], xmm4
0000782c7ffd47b0  vmovaps [rsp+0x50], xmm5
0000782c7ffd47b6  vmovaps [rsp+0x60], xmm6
0000782c7ffd47bc  vmovaps [rsp+0x70], xmm7
0000782c7ffd47c2  vmovaps [rsp+0x80], xmm8
0000782c7ffd47cb  vmovaps [rsp+0x90], xmm9
0000782c7ffd47d4  vmovaps [rsp+0xA0], xmm10
0000782c7ffd47dd  vmovaps [rsp+0xB0], xmm12
0000782c7ffd47e6  vmovaps [rsp+0xC0], xmm13
0000782c7ffd47ef  vmovaps [rsp+0xD0], xmm14
0000782c7ffd47f8  vmovaps [rsp+0xE0], xmm15
0000782c7ffd4801  sub rsp, 0x40
0000782c7ffd4805  lea rdi, [rsp]
0000782c7ffd4809  lea rsi, [rsp+0x10]
0000782c7ffd480e  lea rdx, [rsp+0x20]
0000782c7ffd4813  lea rcx, [rsp+0x30]
0000782c7ffd4818  mov r8d, 0x00
0000782c7ffd481e  lea r9, [r15+0x3A8]
0000782c7ffd4825  movaps [rdi], xmm11
0000782c7ffd4829  movaps [rsi], xmm10
0000782c7ffd482d  movaps [rdx], xmm8
0000782c7ffd4831  movaps [rcx], xmm13
0000782c7ffd4835  mov rax, 0x5AE5BFFB5A50
0000782c7ffd483f  call rax
0000782c7ffd4841  movaps xmm11, [rsp]
0000782c7ffd4846  add rsp, 0x40
0000782c7ffd484a  vmovaps xmm0, [rsp]
0000782c7ffd484f  vmovaps xmm1, [rsp+0x10]
0000782c7ffd4855  vmovaps xmm2, [rsp+0x20]
0000782c7ffd485b  vmovaps xmm3, [rsp+0x30]
0000782c7ffd4861  vmovaps xmm4, [rsp+0x40]
0000782c7ffd4867  vmovaps xmm5, [rsp+0x50]
0000782c7ffd486d  vmovaps xmm6, [rsp+0x60]
0000782c7ffd4873  vmovaps xmm7, [rsp+0x70]
0000782c7ffd4879  vmovaps xmm8, [rsp+0x80]
0000782c7ffd4882  vmovaps xmm9, [rsp+0x90]
0000782c7ffd488b  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd4894  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd489d  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd48a6  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd48af  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd48b8  add rsp, 0xF0
0000782c7ffd48bf  pop r11
0000782c7ffd48c1  pop r10
0000782c7ffd48c3  pop r9
0000782c7ffd48c5  pop r8
0000782c7ffd48c7  pop rsi
0000782c7ffd48c8  pop rdi
0000782c7ffd48c9  pop rdx
0000782c7ffd48ca  pop rcx
0000782c7ffd48cb  pop rax
0000782c7ffd48cc  add rsp, 0x08
0000782c7ffd48d0  jmp 0x0000782C7FFD2E44
0000782c7ffd48d5  sub rsp, 0x08
0000782c7ffd48d9  push rax
0000782c7ffd48da  push rcx
0000782c7ffd48db  push rdx
0000782c7ffd48dc  push rdi
0000782c7ffd48dd  push rsi
0000782c7ffd48de  push r8
0000782c7ffd48e0  push r9
0000782c7ffd48e2  push r10
0000782c7ffd48e4  push r11
0000782c7ffd48e6  sub rsp, 0xF0
0000782c7ffd48ed  vmovaps [rsp], xmm0
0000782c7ffd48f2  vmovaps [rsp+0x10], xmm1
0000782c7ffd48f8  vmovaps [rsp+0x20], xmm2
0000782c7ffd48fe  vmovaps [rsp+0x30], xmm3
0000782c7ffd4904  vmovaps [rsp+0x40], xmm4
0000782c7ffd490a  vmovaps [rsp+0x50], xmm5
0000782c7ffd4910  vmovaps [rsp+0x60], xmm6
0000782c7ffd4916  vmovaps [rsp+0x70], xmm7
0000782c7ffd491c  vmovaps [rsp+0x80], xmm8
0000782c7ffd4925  vmovaps [rsp+0x90], xmm9
0000782c7ffd492e  vmovaps [rsp+0xA0], xmm11
0000782c7ffd4937  vmovaps [rsp+0xB0], xmm12
0000782c7ffd4940  vmovaps [rsp+0xC0], xmm13
0000782c7ffd4949  vmovaps [rsp+0xD0], xmm14
0000782c7ffd4952  vmovaps [rsp+0xE0], xmm15
0000782c7ffd495b  sub rsp, 0x40
0000782c7ffd495f  lea rdi, [rsp]
0000782c7ffd4963  lea rsi, [rsp+0x10]
0000782c7ffd4968  lea rdx, [rsp+0x20]
0000782c7ffd496d  lea rcx, [rsp+0x30]
0000782c7ffd4972  mov r8d, 0x00
0000782c7ffd4978  lea r9, [r15+0x3A8]
0000782c7ffd497f  movaps [rdi], xmm10
0000782c7ffd4983  movaps [rsi], xmm15
0000782c7ffd4987  movaps [rdx], xmm1
0000782c7ffd498a  movaps [rcx], xmm13
0000782c7ffd498e  mov rax, 0x5AE5BFFB5A50
0000782c7ffd4998  call rax
0000782c7ffd499a  movaps xmm10, [rsp]
0000782c7ffd499f  add rsp, 0x40
0000782c7ffd49a3  vmovaps xmm0, [rsp]
0000782c7ffd49a8  vmovaps xmm1, [rsp+0x10]
0000782c7ffd49ae  vmovaps xmm2, [rsp+0x20]
0000782c7ffd49b4  vmovaps xmm3, [rsp+0x30]
0000782c7ffd49ba  vmovaps xmm4, [rsp+0x40]
0000782c7ffd49c0  vmovaps xmm5, [rsp+0x50]
0000782c7ffd49c6  vmovaps xmm6, [rsp+0x60]
0000782c7ffd49cc  vmovaps xmm7, [rsp+0x70]
0000782c7ffd49d2  vmovaps xmm8, [rsp+0x80]
0000782c7ffd49db  vmovaps xmm9, [rsp+0x90]
0000782c7ffd49e4  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd49ed  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd49f6  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd49ff  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd4a08  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd4a11  add rsp, 0xF0
0000782c7ffd4a18  pop r11
0000782c7ffd4a1a  pop r10
0000782c7ffd4a1c  pop r9
0000782c7ffd4a1e  pop r8
0000782c7ffd4a20  pop rsi
0000782c7ffd4a21  pop rdi
0000782c7ffd4a22  pop rdx
0000782c7ffd4a23  pop rcx
0000782c7ffd4a24  pop rax
0000782c7ffd4a25  add rsp, 0x08
0000782c7ffd4a29  jmp 0x0000782C7FFD2E6D
0000782c7ffd4a2e  call 0x0000782C7FDFF430
0000782c7ffd4a33  jmp 0x0000782C7FFD2E8F
0000782c7ffd4a38  call 0x0000782C7FE0E760
0000782c7ffd4a3d  jmp 0x0000782C7FFD2E99
0000782c7ffd4a42  sub rsp, 0x08
0000782c7ffd4a46  push rax
0000782c7ffd4a47  push rcx
0000782c7ffd4a48  push rdx
0000782c7ffd4a49  push rdi
0000782c7ffd4a4a  push rsi
0000782c7ffd4a4b  push r8
0000782c7ffd4a4d  push r9
0000782c7ffd4a4f  push r10
0000782c7ffd4a51  push r11
0000782c7ffd4a53  sub rsp, 0xF0
0000782c7ffd4a5a  vmovaps [rsp], xmm0
0000782c7ffd4a5f  vmovaps [rsp+0x10], xmm1
0000782c7ffd4a65  vmovaps [rsp+0x20], xmm2
0000782c7ffd4a6b  vmovaps [rsp+0x30], xmm3
0000782c7ffd4a71  vmovaps [rsp+0x40], xmm4
0000782c7ffd4a77  vmovaps [rsp+0x50], xmm5
0000782c7ffd4a7d  vmovaps [rsp+0x60], xmm6
0000782c7ffd4a83  vmovaps [rsp+0x70], xmm7
0000782c7ffd4a89  vmovaps [rsp+0x80], xmm9
0000782c7ffd4a92  vmovaps [rsp+0x90], xmm10
0000782c7ffd4a9b  vmovaps [rsp+0xA0], xmm11
0000782c7ffd4aa4  vmovaps [rsp+0xB0], xmm12
0000782c7ffd4aad  vmovaps [rsp+0xC0], xmm13
0000782c7ffd4ab6  vmovaps [rsp+0xD0], xmm14
0000782c7ffd4abf  vmovaps [rsp+0xE0], xmm15
0000782c7ffd4ac8  sub rsp, 0x40
0000782c7ffd4acc  lea rdi, [rsp]
0000782c7ffd4ad0  lea rsi, [rsp+0x10]
0000782c7ffd4ad5  lea rdx, [rsp+0x20]
0000782c7ffd4ada  lea rcx, [rsp+0x30]
0000782c7ffd4adf  mov r8d, 0x00
0000782c7ffd4ae5  lea r9, [r15+0x3A8]
0000782c7ffd4aec  movaps [rdi], xmm8
0000782c7ffd4af0  movaps [rsi], xmm5
0000782c7ffd4af3  movaps [rdx], xmm9
0000782c7ffd4af7  movaps [rcx], xmm13
0000782c7ffd4afb  mov rax, 0x5AE5BFFB5A50
0000782c7ffd4b05  call rax
0000782c7ffd4b07  movaps xmm8, [rsp]
0000782c7ffd4b0c  add rsp, 0x40
0000782c7ffd4b10  vmovaps xmm0, [rsp]
0000782c7ffd4b15  vmovaps xmm1, [rsp+0x10]
0000782c7ffd4b1b  vmovaps xmm2, [rsp+0x20]
0000782c7ffd4b21  vmovaps xmm3, [rsp+0x30]
0000782c7ffd4b27  vmovaps xmm4, [rsp+0x40]
0000782c7ffd4b2d  vmovaps xmm5, [rsp+0x50]
0000782c7ffd4b33  vmovaps xmm6, [rsp+0x60]
0000782c7ffd4b39  vmovaps xmm7, [rsp+0x70]
0000782c7ffd4b3f  vmovaps xmm9, [rsp+0x80]
0000782c7ffd4b48  vmovaps xmm10, [rsp+0x90]
0000782c7ffd4b51  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd4b5a  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd4b63  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd4b6c  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd4b75  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd4b7e  add rsp, 0xF0
0000782c7ffd4b85  pop r11
0000782c7ffd4b87  pop r10
0000782c7ffd4b89  pop r9
0000782c7ffd4b8b  pop r8
0000782c7ffd4b8d  pop rsi
0000782c7ffd4b8e  pop rdi
0000782c7ffd4b8f  pop rdx
0000782c7ffd4b90  pop rcx
0000782c7ffd4b91  pop rax
0000782c7ffd4b92  add rsp, 0x08
0000782c7ffd4b96  jmp 0x0000782C7FFD2ED8
0000782c7ffd4b9b  sub rsp, 0x08
0000782c7ffd4b9f  push rax
0000782c7ffd4ba0  push rcx
0000782c7ffd4ba1  push rdx
0000782c7ffd4ba2  push rdi
0000782c7ffd4ba3  push rsi
0000782c7ffd4ba4  push r8
0000782c7ffd4ba6  push r9
0000782c7ffd4ba8  push r10
0000782c7ffd4baa  push r11
0000782c7ffd4bac  sub rsp, 0xF0
0000782c7ffd4bb3  vmovaps [rsp], xmm0
0000782c7ffd4bb8  vmovaps [rsp+0x10], xmm1
0000782c7ffd4bbe  vmovaps [rsp+0x20], xmm2
0000782c7ffd4bc4  vmovaps [rsp+0x30], xmm3
0000782c7ffd4bca  vmovaps [rsp+0x40], xmm4
0000782c7ffd4bd0  vmovaps [rsp+0x50], xmm5
0000782c7ffd4bd6  vmovaps [rsp+0x60], xmm6
0000782c7ffd4bdc  vmovaps [rsp+0x70], xmm7
0000782c7ffd4be2  vmovaps [rsp+0x80], xmm8
0000782c7ffd4beb  vmovaps [rsp+0x90], xmm10
0000782c7ffd4bf4  vmovaps [rsp+0xA0], xmm11
0000782c7ffd4bfd  vmovaps [rsp+0xB0], xmm12
0000782c7ffd4c06  vmovaps [rsp+0xC0], xmm13
0000782c7ffd4c0f  vmovaps [rsp+0xD0], xmm14
0000782c7ffd4c18  vmovaps [rsp+0xE0], xmm15
0000782c7ffd4c21  sub rsp, 0x40
0000782c7ffd4c25  lea rdi, [rsp]
0000782c7ffd4c29  lea rsi, [rsp+0x10]
0000782c7ffd4c2e  lea rdx, [rsp+0x20]
0000782c7ffd4c33  lea rcx, [rsp+0x30]
0000782c7ffd4c38  mov r8d, 0x00
0000782c7ffd4c3e  lea r9, [r15+0x3A8]
0000782c7ffd4c45  movaps [rdi], xmm9
0000782c7ffd4c49  movaps [rsi], xmm12
0000782c7ffd4c4d  movaps [rdx], xmm7
0000782c7ffd4c50  movaps [rcx], xmm13
0000782c7ffd4c54  mov rax, 0x5AE5BFFB5A50
0000782c7ffd4c5e  call rax
0000782c7ffd4c60  movaps xmm9, [rsp]
0000782c7ffd4c65  add rsp, 0x40
0000782c7ffd4c69  vmovaps xmm0, [rsp]
0000782c7ffd4c6e  vmovaps xmm1, [rsp+0x10]
0000782c7ffd4c74  vmovaps xmm2, [rsp+0x20]
0000782c7ffd4c7a  vmovaps xmm3, [rsp+0x30]
0000782c7ffd4c80  vmovaps xmm4, [rsp+0x40]
0000782c7ffd4c86  vmovaps xmm5, [rsp+0x50]
0000782c7ffd4c8c  vmovaps xmm6, [rsp+0x60]
0000782c7ffd4c92  vmovaps xmm7, [rsp+0x70]
0000782c7ffd4c98  vmovaps xmm8, [rsp+0x80]
0000782c7ffd4ca1  vmovaps xmm10, [rsp+0x90]
0000782c7ffd4caa  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd4cb3  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd4cbc  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd4cc5  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd4cce  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd4cd7  add rsp, 0xF0
0000782c7ffd4cde  pop r11
0000782c7ffd4ce0  pop r10
0000782c7ffd4ce2  pop r9
0000782c7ffd4ce4  pop r8
0000782c7ffd4ce6  pop rsi
0000782c7ffd4ce7  pop rdi
0000782c7ffd4ce8  pop rdx
0000782c7ffd4ce9  pop rcx
0000782c7ffd4cea  pop rax
0000782c7ffd4ceb  add rsp, 0x08
0000782c7ffd4cef  jmp 0x0000782C7FFD2F01
0000782c7ffd4cf4  sub rsp, 0x08
0000782c7ffd4cf8  push rax
0000782c7ffd4cf9  push rcx
0000782c7ffd4cfa  push rdx
0000782c7ffd4cfb  push rdi
0000782c7ffd4cfc  push rsi
0000782c7ffd4cfd  push r8
0000782c7ffd4cff  push r9
0000782c7ffd4d01  push r10
0000782c7ffd4d03  push r11
0000782c7ffd4d05  sub rsp, 0xF0
0000782c7ffd4d0c  vmovaps [rsp], xmm0
0000782c7ffd4d11  vmovaps [rsp+0x10], xmm1
0000782c7ffd4d17  vmovaps [rsp+0x20], xmm2
0000782c7ffd4d1d  vmovaps [rsp+0x30], xmm3
0000782c7ffd4d23  vmovaps [rsp+0x40], xmm4
0000782c7ffd4d29  vmovaps [rsp+0x50], xmm5
0000782c7ffd4d2f  vmovaps [rsp+0x60], xmm6
0000782c7ffd4d35  vmovaps [rsp+0x70], xmm7
0000782c7ffd4d3b  vmovaps [rsp+0x80], xmm8
0000782c7ffd4d44  vmovaps [rsp+0x90], xmm9
0000782c7ffd4d4d  vmovaps [rsp+0xA0], xmm10
0000782c7ffd4d56  vmovaps [rsp+0xB0], xmm11
0000782c7ffd4d5f  vmovaps [rsp+0xC0], xmm13
0000782c7ffd4d68  vmovaps [rsp+0xD0], xmm14
0000782c7ffd4d71  vmovaps [rsp+0xE0], xmm15
0000782c7ffd4d7a  sub rsp, 0x40
0000782c7ffd4d7e  lea rdi, [rsp]
0000782c7ffd4d82  lea rsi, [rsp+0x10]
0000782c7ffd4d87  lea rdx, [rsp+0x20]
0000782c7ffd4d8c  lea rcx, [rsp+0x30]
0000782c7ffd4d91  mov r8d, 0x00
0000782c7ffd4d97  lea r9, [r15+0x3A8]
0000782c7ffd4d9e  movaps [rdi], xmm12
0000782c7ffd4da2  movaps [rsi], xmm11
0000782c7ffd4da6  movaps [rdx], xmm6
0000782c7ffd4da9  movaps [rcx], xmm13
0000782c7ffd4dad  mov rax, 0x5AE5BFFB5A50
0000782c7ffd4db7  call rax
0000782c7ffd4db9  movaps xmm12, [rsp]
0000782c7ffd4dbe  add rsp, 0x40
0000782c7ffd4dc2  vmovaps xmm0, [rsp]
0000782c7ffd4dc7  vmovaps xmm1, [rsp+0x10]
0000782c7ffd4dcd  vmovaps xmm2, [rsp+0x20]
0000782c7ffd4dd3  vmovaps xmm3, [rsp+0x30]
0000782c7ffd4dd9  vmovaps xmm4, [rsp+0x40]
0000782c7ffd4ddf  vmovaps xmm5, [rsp+0x50]
0000782c7ffd4de5  vmovaps xmm6, [rsp+0x60]
0000782c7ffd4deb  vmovaps xmm7, [rsp+0x70]
0000782c7ffd4df1  vmovaps xmm8, [rsp+0x80]
0000782c7ffd4dfa  vmovaps xmm9, [rsp+0x90]
0000782c7ffd4e03  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd4e0c  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd4e15  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd4e1e  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd4e27  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd4e30  add rsp, 0xF0
0000782c7ffd4e37  pop r11
0000782c7ffd4e39  pop r10
0000782c7ffd4e3b  pop r9
0000782c7ffd4e3d  pop r8
0000782c7ffd4e3f  pop rsi
0000782c7ffd4e40  pop rdi
0000782c7ffd4e41  pop rdx
0000782c7ffd4e42  pop rcx
0000782c7ffd4e43  pop rax
0000782c7ffd4e44  add rsp, 0x08
0000782c7ffd4e48  jmp 0x0000782C7FFD2F2A
0000782c7ffd4e4d  sub rsp, 0x08
0000782c7ffd4e51  push rax
0000782c7ffd4e52  push rcx
0000782c7ffd4e53  push rdx
0000782c7ffd4e54  push rdi
0000782c7ffd4e55  push rsi
0000782c7ffd4e56  push r8
0000782c7ffd4e58  push r9
0000782c7ffd4e5a  push r10
0000782c7ffd4e5c  push r11
0000782c7ffd4e5e  sub rsp, 0xF0
0000782c7ffd4e65  vmovaps [rsp], xmm0
0000782c7ffd4e6a  vmovaps [rsp+0x10], xmm1
0000782c7ffd4e70  vmovaps [rsp+0x20], xmm2
0000782c7ffd4e76  vmovaps [rsp+0x30], xmm3
0000782c7ffd4e7c  vmovaps [rsp+0x40], xmm4
0000782c7ffd4e82  vmovaps [rsp+0x50], xmm5
0000782c7ffd4e88  vmovaps [rsp+0x60], xmm6
0000782c7ffd4e8e  vmovaps [rsp+0x70], xmm8
0000782c7ffd4e94  vmovaps [rsp+0x80], xmm9
0000782c7ffd4e9d  vmovaps [rsp+0x90], xmm10
0000782c7ffd4ea6  vmovaps [rsp+0xA0], xmm11
0000782c7ffd4eaf  vmovaps [rsp+0xB0], xmm12
0000782c7ffd4eb8  vmovaps [rsp+0xC0], xmm13
0000782c7ffd4ec1  vmovaps [rsp+0xD0], xmm14
0000782c7ffd4eca  vmovaps [rsp+0xE0], xmm15
0000782c7ffd4ed3  sub rsp, 0x40
0000782c7ffd4ed7  lea rdi, [rsp]
0000782c7ffd4edb  lea rsi, [rsp+0x10]
0000782c7ffd4ee0  lea rdx, [rsp+0x20]
0000782c7ffd4ee5  lea rcx, [rsp+0x30]
0000782c7ffd4eea  mov r8d, 0x00
0000782c7ffd4ef0  lea r9, [r15+0x3A8]
0000782c7ffd4ef7  movaps [rdi], xmm7
0000782c7ffd4efa  movaps [rsi], xmm10
0000782c7ffd4efe  movaps [rdx], xmm11
0000782c7ffd4f02  movaps [rcx], xmm13
0000782c7ffd4f06  mov rax, 0x5AE5BFFB5A50
0000782c7ffd4f10  call rax
0000782c7ffd4f12  movaps xmm7, [rsp]
0000782c7ffd4f16  add rsp, 0x40
0000782c7ffd4f1a  vmovaps xmm0, [rsp]
0000782c7ffd4f1f  vmovaps xmm1, [rsp+0x10]
0000782c7ffd4f25  vmovaps xmm2, [rsp+0x20]
0000782c7ffd4f2b  vmovaps xmm3, [rsp+0x30]
0000782c7ffd4f31  vmovaps xmm4, [rsp+0x40]
0000782c7ffd4f37  vmovaps xmm5, [rsp+0x50]
0000782c7ffd4f3d  vmovaps xmm6, [rsp+0x60]
0000782c7ffd4f43  vmovaps xmm8, [rsp+0x70]
0000782c7ffd4f49  vmovaps xmm9, [rsp+0x80]
0000782c7ffd4f52  vmovaps xmm10, [rsp+0x90]
0000782c7ffd4f5b  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd4f64  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd4f6d  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd4f76  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd4f7f  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd4f88  add rsp, 0xF0
0000782c7ffd4f8f  pop r11
0000782c7ffd4f91  pop r10
0000782c7ffd4f93  pop r9
0000782c7ffd4f95  pop r8
0000782c7ffd4f97  pop rsi
0000782c7ffd4f98  pop rdi
0000782c7ffd4f99  pop rdx
0000782c7ffd4f9a  pop rcx
0000782c7ffd4f9b  pop rax
0000782c7ffd4f9c  add rsp, 0x08
0000782c7ffd4fa0  jmp 0x0000782C7FFD2F58
0000782c7ffd4fa5  call 0x0000782C7FE0C260
0000782c7ffd4faa  jmp 0x0000782C7FFD2F62
0000782c7ffd4faf  call 0x0000782C7FE09D70
0000782c7ffd4fb4  jmp 0x0000782C7FFD2F6C
0000782c7ffd4fb9  sub rsp, 0x08
0000782c7ffd4fbd  push rax
0000782c7ffd4fbe  push rcx
0000782c7ffd4fbf  push rdx
0000782c7ffd4fc0  push rdi
0000782c7ffd4fc1  push rsi
0000782c7ffd4fc2  push r8
0000782c7ffd4fc4  push r9
0000782c7ffd4fc6  push r10
0000782c7ffd4fc8  push r11
0000782c7ffd4fca  sub rsp, 0xF0
0000782c7ffd4fd1  vmovaps [rsp], xmm0
0000782c7ffd4fd6  vmovaps [rsp+0x10], xmm1
0000782c7ffd4fdc  vmovaps [rsp+0x20], xmm2
0000782c7ffd4fe2  vmovaps [rsp+0x30], xmm3
0000782c7ffd4fe8  vmovaps [rsp+0x40], xmm4
0000782c7ffd4fee  vmovaps [rsp+0x50], xmm5
0000782c7ffd4ff4  vmovaps [rsp+0x60], xmm7
0000782c7ffd4ffa  vmovaps [rsp+0x70], xmm8
0000782c7ffd5000  vmovaps [rsp+0x80], xmm9
0000782c7ffd5009  vmovaps [rsp+0x90], xmm10
0000782c7ffd5012  vmovaps [rsp+0xA0], xmm11
0000782c7ffd501b  vmovaps [rsp+0xB0], xmm12
0000782c7ffd5024  vmovaps [rsp+0xC0], xmm13
0000782c7ffd502d  vmovaps [rsp+0xD0], xmm14
0000782c7ffd5036  vmovaps [rsp+0xE0], xmm15
0000782c7ffd503f  sub rsp, 0x40
0000782c7ffd5043  lea rdi, [rsp]
0000782c7ffd5047  lea rsi, [rsp+0x10]
0000782c7ffd504c  lea rdx, [rsp+0x20]
0000782c7ffd5051  lea rcx, [rsp+0x30]
0000782c7ffd5056  mov r8d, 0x00
0000782c7ffd505c  lea r9, [r15+0x3A8]
0000782c7ffd5063  movaps [rdi], xmm6
0000782c7ffd5066  movaps [rsi], xmm8
0000782c7ffd506a  movaps [rdx], xmm15
0000782c7ffd506e  movaps [rcx], xmm10
0000782c7ffd5072  mov rax, 0x5AE5BFFB5A50
0000782c7ffd507c  call rax
0000782c7ffd507e  movaps xmm6, [rsp]
0000782c7ffd5082  add rsp, 0x40
0000782c7ffd5086  vmovaps xmm0, [rsp]
0000782c7ffd508b  vmovaps xmm1, [rsp+0x10]
0000782c7ffd5091  vmovaps xmm2, [rsp+0x20]
0000782c7ffd5097  vmovaps xmm3, [rsp+0x30]
0000782c7ffd509d  vmovaps xmm4, [rsp+0x40]
0000782c7ffd50a3  vmovaps xmm5, [rsp+0x50]
0000782c7ffd50a9  vmovaps xmm7, [rsp+0x60]
0000782c7ffd50af  vmovaps xmm8, [rsp+0x70]
0000782c7ffd50b5  vmovaps xmm9, [rsp+0x80]
0000782c7ffd50be  vmovaps xmm10, [rsp+0x90]
0000782c7ffd50c7  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd50d0  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd50d9  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd50e2  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd50eb  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd50f4  add rsp, 0xF0
0000782c7ffd50fb  pop r11
0000782c7ffd50fd  pop r10
0000782c7ffd50ff  pop r9
0000782c7ffd5101  pop r8
0000782c7ffd5103  pop rsi
0000782c7ffd5104  pop rdi
0000782c7ffd5105  pop rdx
0000782c7ffd5106  pop rcx
0000782c7ffd5107  pop rax
0000782c7ffd5108  add rsp, 0x08
0000782c7ffd510c  jmp 0x0000782C7FFD2FA4
0000782c7ffd5111  sub rsp, 0x08
0000782c7ffd5115  push rax
0000782c7ffd5116  push rcx
0000782c7ffd5117  push rdx
0000782c7ffd5118  push rdi
0000782c7ffd5119  push rsi
0000782c7ffd511a  push r8
0000782c7ffd511c  push r9
0000782c7ffd511e  push r10
0000782c7ffd5120  push r11
0000782c7ffd5122  sub rsp, 0xF0
0000782c7ffd5129  vmovaps [rsp], xmm0
0000782c7ffd512e  vmovaps [rsp+0x10], xmm1
0000782c7ffd5134  vmovaps [rsp+0x20], xmm2
0000782c7ffd513a  vmovaps [rsp+0x30], xmm3
0000782c7ffd5140  vmovaps [rsp+0x40], xmm4
0000782c7ffd5146  vmovaps [rsp+0x50], xmm5
0000782c7ffd514c  vmovaps [rsp+0x60], xmm6
0000782c7ffd5152  vmovaps [rsp+0x70], xmm7
0000782c7ffd5158  vmovaps [rsp+0x80], xmm8
0000782c7ffd5161  vmovaps [rsp+0x90], xmm9
0000782c7ffd516a  vmovaps [rsp+0xA0], xmm11
0000782c7ffd5173  vmovaps [rsp+0xB0], xmm12
0000782c7ffd517c  vmovaps [rsp+0xC0], xmm13
0000782c7ffd5185  vmovaps [rsp+0xD0], xmm14
0000782c7ffd518e  vmovaps [rsp+0xE0], xmm15
0000782c7ffd5197  sub rsp, 0x40
0000782c7ffd519b  lea rdi, [rsp]
0000782c7ffd519f  lea rsi, [rsp+0x10]
0000782c7ffd51a4  lea rdx, [rsp+0x20]
0000782c7ffd51a9  lea rcx, [rsp+0x30]
0000782c7ffd51ae  mov r8d, 0x00
0000782c7ffd51b4  lea r9, [r15+0x3A8]
0000782c7ffd51bb  movaps [rdi], xmm10
0000782c7ffd51bf  movaps [rsi], xmm9
0000782c7ffd51c3  movaps [rdx], xmm13
0000782c7ffd51c7  movaps [rcx], xmm15
0000782c7ffd51cb  mov rax, 0x5AE5BFFB5A50
0000782c7ffd51d5  call rax
0000782c7ffd51d7  movaps xmm10, [rsp]
0000782c7ffd51dc  add rsp, 0x40
0000782c7ffd51e0  vmovaps xmm0, [rsp]
0000782c7ffd51e5  vmovaps xmm1, [rsp+0x10]
0000782c7ffd51eb  vmovaps xmm2, [rsp+0x20]
0000782c7ffd51f1  vmovaps xmm3, [rsp+0x30]
0000782c7ffd51f7  vmovaps xmm4, [rsp+0x40]
0000782c7ffd51fd  vmovaps xmm5, [rsp+0x50]
0000782c7ffd5203  vmovaps xmm6, [rsp+0x60]
0000782c7ffd5209  vmovaps xmm7, [rsp+0x70]
0000782c7ffd520f  vmovaps xmm8, [rsp+0x80]
0000782c7ffd5218  vmovaps xmm9, [rsp+0x90]
0000782c7ffd5221  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd522a  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd5233  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd523c  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd5245  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd524e  add rsp, 0xF0
0000782c7ffd5255  pop r11
0000782c7ffd5257  pop r10
0000782c7ffd5259  pop r9
0000782c7ffd525b  pop r8
0000782c7ffd525d  pop rsi
0000782c7ffd525e  pop rdi
0000782c7ffd525f  pop rdx
0000782c7ffd5260  pop rcx
0000782c7ffd5261  pop rax
0000782c7ffd5262  add rsp, 0x08
0000782c7ffd5266  jmp 0x0000782C7FFD2FCD
0000782c7ffd526b  sub rsp, 0x08
0000782c7ffd526f  push rax
0000782c7ffd5270  push rcx
0000782c7ffd5271  push rdx
0000782c7ffd5272  push rdi
0000782c7ffd5273  push rsi
0000782c7ffd5274  push r8
0000782c7ffd5276  push r9
0000782c7ffd5278  push r10
0000782c7ffd527a  push r11
0000782c7ffd527c  sub rsp, 0xF0
0000782c7ffd5283  vmovaps [rsp], xmm0
0000782c7ffd5288  vmovaps [rsp+0x10], xmm1
0000782c7ffd528e  vmovaps [rsp+0x20], xmm2
0000782c7ffd5294  vmovaps [rsp+0x30], xmm3
0000782c7ffd529a  vmovaps [rsp+0x40], xmm4
0000782c7ffd52a0  vmovaps [rsp+0x50], xmm5
0000782c7ffd52a6  vmovaps [rsp+0x60], xmm6
0000782c7ffd52ac  vmovaps [rsp+0x70], xmm7
0000782c7ffd52b2  vmovaps [rsp+0x80], xmm8
0000782c7ffd52bb  vmovaps [rsp+0x90], xmm9
0000782c7ffd52c4  vmovaps [rsp+0xA0], xmm10
0000782c7ffd52cd  vmovaps [rsp+0xB0], xmm11
0000782c7ffd52d6  vmovaps [rsp+0xC0], xmm12
0000782c7ffd52df  vmovaps [rsp+0xD0], xmm14
0000782c7ffd52e8  vmovaps [rsp+0xE0], xmm15
0000782c7ffd52f1  sub rsp, 0x40
0000782c7ffd52f5  lea rdi, [rsp]
0000782c7ffd52f9  lea rsi, [rsp+0x10]
0000782c7ffd52fe  lea rdx, [rsp+0x20]
0000782c7ffd5303  lea rcx, [rsp+0x30]
0000782c7ffd5308  mov r8d, 0x00
0000782c7ffd530e  lea r9, [r15+0x3A8]
0000782c7ffd5315  movaps [rdi], xmm13
0000782c7ffd5319  movaps [rsi], xmm12
0000782c7ffd531d  movaps [rdx], xmm4
0000782c7ffd5320  movaps [rcx], xmm15
0000782c7ffd5324  mov rax, 0x5AE5BFFB5A50
0000782c7ffd532e  call rax
0000782c7ffd5330  movaps xmm13, [rsp]
0000782c7ffd5335  add rsp, 0x40
0000782c7ffd5339  vmovaps xmm0, [rsp]
0000782c7ffd533e  vmovaps xmm1, [rsp+0x10]
0000782c7ffd5344  vmovaps xmm2, [rsp+0x20]
0000782c7ffd534a  vmovaps xmm3, [rsp+0x30]
0000782c7ffd5350  vmovaps xmm4, [rsp+0x40]
0000782c7ffd5356  vmovaps xmm5, [rsp+0x50]
0000782c7ffd535c  vmovaps xmm6, [rsp+0x60]
0000782c7ffd5362  vmovaps xmm7, [rsp+0x70]
0000782c7ffd5368  vmovaps xmm8, [rsp+0x80]
0000782c7ffd5371  vmovaps xmm9, [rsp+0x90]
0000782c7ffd537a  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd5383  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd538c  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd5395  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd539e  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd53a7  add rsp, 0xF0
0000782c7ffd53ae  pop r11
0000782c7ffd53b0  pop r10
0000782c7ffd53b2  pop r9
0000782c7ffd53b4  pop r8
0000782c7ffd53b6  pop rsi
0000782c7ffd53b7  pop rdi
0000782c7ffd53b8  pop rdx
0000782c7ffd53b9  pop rcx
0000782c7ffd53ba  pop rax
0000782c7ffd53bb  add rsp, 0x08
0000782c7ffd53bf  jmp 0x0000782C7FFD2FF6
0000782c7ffd53c4  sub rsp, 0x08
0000782c7ffd53c8  push rax
0000782c7ffd53c9  push rcx
0000782c7ffd53ca  push rdx
0000782c7ffd53cb  push rdi
0000782c7ffd53cc  push rsi
0000782c7ffd53cd  push r8
0000782c7ffd53cf  push r9
0000782c7ffd53d1  push r10
0000782c7ffd53d3  push r11
0000782c7ffd53d5  sub rsp, 0xF0
0000782c7ffd53dc  vmovaps [rsp], xmm0
0000782c7ffd53e1  vmovaps [rsp+0x10], xmm1
0000782c7ffd53e7  vmovaps [rsp+0x20], xmm2
0000782c7ffd53ed  vmovaps [rsp+0x30], xmm3
0000782c7ffd53f3  vmovaps [rsp+0x40], xmm4
0000782c7ffd53f9  vmovaps [rsp+0x50], xmm5
0000782c7ffd53ff  vmovaps [rsp+0x60], xmm6
0000782c7ffd5405  vmovaps [rsp+0x70], xmm7
0000782c7ffd540b  vmovaps [rsp+0x80], xmm8
0000782c7ffd5414  vmovaps [rsp+0x90], xmm9
0000782c7ffd541d  vmovaps [rsp+0xA0], xmm10
0000782c7ffd5426  vmovaps [rsp+0xB0], xmm11
0000782c7ffd542f  vmovaps [rsp+0xC0], xmm13
0000782c7ffd5438  vmovaps [rsp+0xD0], xmm14
0000782c7ffd5441  vmovaps [rsp+0xE0], xmm15
0000782c7ffd544a  sub rsp, 0x40
0000782c7ffd544e  lea rdi, [rsp]
0000782c7ffd5452  lea rsi, [rsp+0x10]
0000782c7ffd5457  lea rdx, [rsp+0x20]
0000782c7ffd545c  lea rcx, [rsp+0x30]
0000782c7ffd5461  mov r8d, 0x00
0000782c7ffd5467  lea r9, [r15+0x3A8]
0000782c7ffd546e  movaps [rdi], xmm12
0000782c7ffd5472  movaps [rsi], xmm7
0000782c7ffd5475  movaps [rdx], xmm1
0000782c7ffd5478  movaps [rcx], xmm15
0000782c7ffd547c  mov rax, 0x5AE5BFFB5A50
0000782c7ffd5486  call rax
0000782c7ffd5488  movaps xmm12, [rsp]
0000782c7ffd548d  add rsp, 0x40
0000782c7ffd5491  vmovaps xmm0, [rsp]
0000782c7ffd5496  vmovaps xmm1, [rsp+0x10]
0000782c7ffd549c  vmovaps xmm2, [rsp+0x20]
0000782c7ffd54a2  vmovaps xmm3, [rsp+0x30]
0000782c7ffd54a8  vmovaps xmm4, [rsp+0x40]
0000782c7ffd54ae  vmovaps xmm5, [rsp+0x50]
0000782c7ffd54b4  vmovaps xmm6, [rsp+0x60]
0000782c7ffd54ba  vmovaps xmm7, [rsp+0x70]
0000782c7ffd54c0  vmovaps xmm8, [rsp+0x80]
0000782c7ffd54c9  vmovaps xmm9, [rsp+0x90]
0000782c7ffd54d2  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd54db  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd54e4  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd54ed  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd54f6  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd54ff  add rsp, 0xF0
0000782c7ffd5506  pop r11
0000782c7ffd5508  pop r10
0000782c7ffd550a  pop r9
0000782c7ffd550c  pop r8
0000782c7ffd550e  pop rsi
0000782c7ffd550f  pop rdi
0000782c7ffd5510  pop rdx
0000782c7ffd5511  pop rcx
0000782c7ffd5512  pop rax
0000782c7ffd5513  add rsp, 0x08
0000782c7ffd5517  jmp 0x0000782C7FFD301F
0000782c7ffd551c  call 0x0000782C7FDFF430
0000782c7ffd5521  jmp 0x0000782C7FFD3029
0000782c7ffd5526  call 0x0000782C7FE0E760
0000782c7ffd552b  jmp 0x0000782C7FFD3033
0000782c7ffd5530  sub rsp, 0x08
0000782c7ffd5534  push rax
0000782c7ffd5535  push rcx
0000782c7ffd5536  push rdx
0000782c7ffd5537  push rdi
0000782c7ffd5538  push rsi
0000782c7ffd5539  push r8
0000782c7ffd553b  push r9
0000782c7ffd553d  push r10
0000782c7ffd553f  push r11
0000782c7ffd5541  sub rsp, 0xF0
0000782c7ffd5548  vmovaps [rsp], xmm0
0000782c7ffd554d  vmovaps [rsp+0x10], xmm1
0000782c7ffd5553  vmovaps [rsp+0x20], xmm2
0000782c7ffd5559  vmovaps [rsp+0x30], xmm3
0000782c7ffd555f  vmovaps [rsp+0x40], xmm4
0000782c7ffd5565  vmovaps [rsp+0x50], xmm5
0000782c7ffd556b  vmovaps [rsp+0x60], xmm6
0000782c7ffd5571  vmovaps [rsp+0x70], xmm8
0000782c7ffd5577  vmovaps [rsp+0x80], xmm9
0000782c7ffd5580  vmovaps [rsp+0x90], xmm10
0000782c7ffd5589  vmovaps [rsp+0xA0], xmm11
0000782c7ffd5592  vmovaps [rsp+0xB0], xmm12
0000782c7ffd559b  vmovaps [rsp+0xC0], xmm13
0000782c7ffd55a4  vmovaps [rsp+0xD0], xmm14
0000782c7ffd55ad  vmovaps [rsp+0xE0], xmm15
0000782c7ffd55b6  sub rsp, 0x40
0000782c7ffd55ba  lea rdi, [rsp]
0000782c7ffd55be  lea rsi, [rsp+0x10]
0000782c7ffd55c3  lea rdx, [rsp+0x20]
0000782c7ffd55c8  lea rcx, [rsp+0x30]
0000782c7ffd55cd  mov r8d, 0x00
0000782c7ffd55d3  lea r9, [r15+0x3A8]
0000782c7ffd55da  movaps [rdi], xmm7
0000782c7ffd55dd  movaps [rsi], xmm6
0000782c7ffd55e0  movaps [rdx], xmm8
0000782c7ffd55e4  movaps [rcx], xmm9
0000782c7ffd55e8  mov rax, 0x5AE5BFFB5A50
0000782c7ffd55f2  call rax
0000782c7ffd55f4  movaps xmm7, [rsp]
0000782c7ffd55f8  add rsp, 0x40
0000782c7ffd55fc  vmovaps xmm0, [rsp]
0000782c7ffd5601  vmovaps xmm1, [rsp+0x10]
0000782c7ffd5607  vmovaps xmm2, [rsp+0x20]
0000782c7ffd560d  vmovaps xmm3, [rsp+0x30]
0000782c7ffd5613  vmovaps xmm4, [rsp+0x40]
0000782c7ffd5619  vmovaps xmm5, [rsp+0x50]
0000782c7ffd561f  vmovaps xmm6, [rsp+0x60]
0000782c7ffd5625  vmovaps xmm8, [rsp+0x70]
0000782c7ffd562b  vmovaps xmm9, [rsp+0x80]
0000782c7ffd5634  vmovaps xmm10, [rsp+0x90]
0000782c7ffd563d  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd5646  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd564f  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd5658  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd5661  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd566a  add rsp, 0xF0
0000782c7ffd5671  pop r11
0000782c7ffd5673  pop r10
0000782c7ffd5675  pop r9
0000782c7ffd5677  pop r8
0000782c7ffd5679  pop rsi
0000782c7ffd567a  pop rdi
0000782c7ffd567b  pop rdx
0000782c7ffd567c  pop rcx
0000782c7ffd567d  pop rax
0000782c7ffd567e  add rsp, 0x08
0000782c7ffd5682  jmp 0x0000782C7FFD305D
0000782c7ffd5687  sub rsp, 0x08
0000782c7ffd568b  push rax
0000782c7ffd568c  push rcx
0000782c7ffd568d  push rdx
0000782c7ffd568e  push rdi
0000782c7ffd568f  push rsi
0000782c7ffd5690  push r8
0000782c7ffd5692  push r9
0000782c7ffd5694  push r10
0000782c7ffd5696  push r11
0000782c7ffd5698  sub rsp, 0xF0
0000782c7ffd569f  vmovaps [rsp], xmm0
0000782c7ffd56a4  vmovaps [rsp+0x10], xmm1
0000782c7ffd56aa  vmovaps [rsp+0x20], xmm2
0000782c7ffd56b0  vmovaps [rsp+0x30], xmm3
0000782c7ffd56b6  vmovaps [rsp+0x40], xmm4
0000782c7ffd56bc  vmovaps [rsp+0x50], xmm5
0000782c7ffd56c2  vmovaps [rsp+0x60], xmm6
0000782c7ffd56c8  vmovaps [rsp+0x70], xmm7
0000782c7ffd56ce  vmovaps [rsp+0x80], xmm9
0000782c7ffd56d7  vmovaps [rsp+0x90], xmm10
0000782c7ffd56e0  vmovaps [rsp+0xA0], xmm11
0000782c7ffd56e9  vmovaps [rsp+0xB0], xmm12
0000782c7ffd56f2  vmovaps [rsp+0xC0], xmm13
0000782c7ffd56fb  vmovaps [rsp+0xD0], xmm14
0000782c7ffd5704  vmovaps [rsp+0xE0], xmm15
0000782c7ffd570d  sub rsp, 0x40
0000782c7ffd5711  lea rdi, [rsp]
0000782c7ffd5715  lea rsi, [rsp+0x10]
0000782c7ffd571a  lea rdx, [rsp+0x20]
0000782c7ffd571f  lea rcx, [rsp+0x30]
0000782c7ffd5724  mov r8d, 0x00
0000782c7ffd572a  lea r9, [r15+0x3A8]
0000782c7ffd5731  movaps [rdi], xmm8
0000782c7ffd5735  movaps [rsi], xmm10
0000782c7ffd5739  movaps [rdx], xmm14
0000782c7ffd573d  movaps [rcx], xmm9
0000782c7ffd5741  mov rax, 0x5AE5BFFB5A50
0000782c7ffd574b  call rax
0000782c7ffd574d  movaps xmm8, [rsp]
0000782c7ffd5752  add rsp, 0x40
0000782c7ffd5756  vmovaps xmm0, [rsp]
0000782c7ffd575b  vmovaps xmm1, [rsp+0x10]
0000782c7ffd5761  vmovaps xmm2, [rsp+0x20]
0000782c7ffd5767  vmovaps xmm3, [rsp+0x30]
0000782c7ffd576d  vmovaps xmm4, [rsp+0x40]
0000782c7ffd5773  vmovaps xmm5, [rsp+0x50]
0000782c7ffd5779  vmovaps xmm6, [rsp+0x60]
0000782c7ffd577f  vmovaps xmm7, [rsp+0x70]
0000782c7ffd5785  vmovaps xmm9, [rsp+0x80]
0000782c7ffd578e  vmovaps xmm10, [rsp+0x90]
0000782c7ffd5797  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd57a0  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd57a9  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd57b2  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd57bb  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd57c4  add rsp, 0xF0
0000782c7ffd57cb  pop r11
0000782c7ffd57cd  pop r10
0000782c7ffd57cf  pop r9
0000782c7ffd57d1  pop r8
0000782c7ffd57d3  pop rsi
0000782c7ffd57d4  pop rdi
0000782c7ffd57d5  pop rdx
0000782c7ffd57d6  pop rcx
0000782c7ffd57d7  pop rax
0000782c7ffd57d8  add rsp, 0x08
0000782c7ffd57dc  jmp 0x0000782C7FFD3083
0000782c7ffd57e1  sub rsp, 0x08
0000782c7ffd57e5  push rax
0000782c7ffd57e6  push rcx
0000782c7ffd57e7  push rdx
0000782c7ffd57e8  push rdi
0000782c7ffd57e9  push rsi
0000782c7ffd57ea  push r8
0000782c7ffd57ec  push r9
0000782c7ffd57ee  push r10
0000782c7ffd57f0  push r11
0000782c7ffd57f2  sub rsp, 0xF0
0000782c7ffd57f9  vmovaps [rsp], xmm0
0000782c7ffd57fe  vmovaps [rsp+0x10], xmm1
0000782c7ffd5804  vmovaps [rsp+0x20], xmm2
0000782c7ffd580a  vmovaps [rsp+0x30], xmm3
0000782c7ffd5810  vmovaps [rsp+0x40], xmm4
0000782c7ffd5816  vmovaps [rsp+0x50], xmm5
0000782c7ffd581c  vmovaps [rsp+0x60], xmm6
0000782c7ffd5822  vmovaps [rsp+0x70], xmm7
0000782c7ffd5828  vmovaps [rsp+0x80], xmm8
0000782c7ffd5831  vmovaps [rsp+0x90], xmm9
0000782c7ffd583a  vmovaps [rsp+0xA0], xmm11
0000782c7ffd5843  vmovaps [rsp+0xB0], xmm12
0000782c7ffd584c  vmovaps [rsp+0xC0], xmm13
0000782c7ffd5855  vmovaps [rsp+0xD0], xmm14
0000782c7ffd585e  vmovaps [rsp+0xE0], xmm15
0000782c7ffd5867  sub rsp, 0x40
0000782c7ffd586b  lea rdi, [rsp]
0000782c7ffd586f  lea rsi, [rsp+0x10]
0000782c7ffd5874  lea rdx, [rsp+0x20]
0000782c7ffd5879  lea rcx, [rsp+0x30]
0000782c7ffd587e  mov r8d, 0x00
0000782c7ffd5884  lea r9, [r15+0x3A8]
0000782c7ffd588b  movaps [rdi], xmm10
0000782c7ffd588f  movaps [rsi], xmm13
0000782c7ffd5893  movaps [rdx], xmm11
0000782c7ffd5897  movaps [rcx], xmm14
0000782c7ffd589b  mov rax, 0x5AE5BFFB5A50
0000782c7ffd58a5  call rax
0000782c7ffd58a7  movaps xmm10, [rsp]
0000782c7ffd58ac  add rsp, 0x40
0000782c7ffd58b0  vmovaps xmm0, [rsp]
0000782c7ffd58b5  vmovaps xmm1, [rsp+0x10]
0000782c7ffd58bb  vmovaps xmm2, [rsp+0x20]
0000782c7ffd58c1  vmovaps xmm3, [rsp+0x30]
0000782c7ffd58c7  vmovaps xmm4, [rsp+0x40]
0000782c7ffd58cd  vmovaps xmm5, [rsp+0x50]
0000782c7ffd58d3  vmovaps xmm6, [rsp+0x60]
0000782c7ffd58d9  vmovaps xmm7, [rsp+0x70]
0000782c7ffd58df  vmovaps xmm8, [rsp+0x80]
0000782c7ffd58e8  vmovaps xmm9, [rsp+0x90]
0000782c7ffd58f1  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd58fa  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd5903  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd590c  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd5915  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd591e  add rsp, 0xF0
0000782c7ffd5925  pop r11
0000782c7ffd5927  pop r10
0000782c7ffd5929  pop r9
0000782c7ffd592b  pop r8
0000782c7ffd592d  pop rsi
0000782c7ffd592e  pop rdi
0000782c7ffd592f  pop rdx
0000782c7ffd5930  pop rcx
0000782c7ffd5931  pop rax
0000782c7ffd5932  add rsp, 0x08
0000782c7ffd5936  jmp 0x0000782C7FFD30A9
0000782c7ffd593b  sub rsp, 0x08
0000782c7ffd593f  push rax
0000782c7ffd5940  push rcx
0000782c7ffd5941  push rdx
0000782c7ffd5942  push rdi
0000782c7ffd5943  push rsi
0000782c7ffd5944  push r8
0000782c7ffd5946  push r9
0000782c7ffd5948  push r10
0000782c7ffd594a  push r11
0000782c7ffd594c  sub rsp, 0xF0
0000782c7ffd5953  vmovaps [rsp], xmm0
0000782c7ffd5958  vmovaps [rsp+0x10], xmm1
0000782c7ffd595e  vmovaps [rsp+0x20], xmm2
0000782c7ffd5964  vmovaps [rsp+0x30], xmm3
0000782c7ffd596a  vmovaps [rsp+0x40], xmm4
0000782c7ffd5970  vmovaps [rsp+0x50], xmm5
0000782c7ffd5976  vmovaps [rsp+0x60], xmm6
0000782c7ffd597c  vmovaps [rsp+0x70], xmm7
0000782c7ffd5982  vmovaps [rsp+0x80], xmm8
0000782c7ffd598b  vmovaps [rsp+0x90], xmm9
0000782c7ffd5994  vmovaps [rsp+0xA0], xmm10
0000782c7ffd599d  vmovaps [rsp+0xB0], xmm11
0000782c7ffd59a6  vmovaps [rsp+0xC0], xmm12
0000782c7ffd59af  vmovaps [rsp+0xD0], xmm14
0000782c7ffd59b8  vmovaps [rsp+0xE0], xmm15
0000782c7ffd59c1  sub rsp, 0x40
0000782c7ffd59c5  lea rdi, [rsp]
0000782c7ffd59c9  lea rsi, [rsp+0x10]
0000782c7ffd59ce  lea rdx, [rsp+0x20]
0000782c7ffd59d3  lea rcx, [rsp+0x30]
0000782c7ffd59d8  mov r8d, 0x00
0000782c7ffd59de  lea r9, [r15+0x3A8]
0000782c7ffd59e5  movaps [rdi], xmm13
0000782c7ffd59e9  movaps [rsi], xmm12
0000782c7ffd59ed  movaps [rdx], xmm15
0000782c7ffd59f1  movaps [rcx], xmm14
0000782c7ffd59f5  mov rax, 0x5AE5BFFB5A50
0000782c7ffd59ff  call rax
0000782c7ffd5a01  movaps xmm13, [rsp]
0000782c7ffd5a06  add rsp, 0x40
0000782c7ffd5a0a  vmovaps xmm0, [rsp]
0000782c7ffd5a0f  vmovaps xmm1, [rsp+0x10]
0000782c7ffd5a15  vmovaps xmm2, [rsp+0x20]
0000782c7ffd5a1b  vmovaps xmm3, [rsp+0x30]
0000782c7ffd5a21  vmovaps xmm4, [rsp+0x40]
0000782c7ffd5a27  vmovaps xmm5, [rsp+0x50]
0000782c7ffd5a2d  vmovaps xmm6, [rsp+0x60]
0000782c7ffd5a33  vmovaps xmm7, [rsp+0x70]
0000782c7ffd5a39  vmovaps xmm8, [rsp+0x80]
0000782c7ffd5a42  vmovaps xmm9, [rsp+0x90]
0000782c7ffd5a4b  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd5a54  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd5a5d  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd5a66  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd5a6f  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd5a78  add rsp, 0xF0
0000782c7ffd5a7f  pop r11
0000782c7ffd5a81  pop r10
0000782c7ffd5a83  pop r9
0000782c7ffd5a85  pop r8
0000782c7ffd5a87  pop rsi
0000782c7ffd5a88  pop rdi
0000782c7ffd5a89  pop rdx
0000782c7ffd5a8a  pop rcx
0000782c7ffd5a8b  pop rax
0000782c7ffd5a8c  add rsp, 0x08
0000782c7ffd5a90  jmp 0x0000782C7FFD30CF
0000782c7ffd5a95  call 0x0000782C7FE0E760
0000782c7ffd5a9a  jmp 0x0000782C7FFD30DC
0000782c7ffd5a9f  call 0x0000782C7FE0D4E0
0000782c7ffd5aa4  jmp 0x0000782C7FFD30E9
0000782c7ffd5aa9  sub rsp, 0x08
0000782c7ffd5aad  push rax
0000782c7ffd5aae  push rcx
0000782c7ffd5aaf  push rdx
0000782c7ffd5ab0  push rdi
0000782c7ffd5ab1  push rsi
0000782c7ffd5ab2  push r8
0000782c7ffd5ab4  push r9
0000782c7ffd5ab6  push r10
0000782c7ffd5ab8  push r11
0000782c7ffd5aba  sub rsp, 0xF0
0000782c7ffd5ac1  vmovaps [rsp], xmm0
0000782c7ffd5ac6  vmovaps [rsp+0x10], xmm1
0000782c7ffd5acc  vmovaps [rsp+0x20], xmm2
0000782c7ffd5ad2  vmovaps [rsp+0x30], xmm3
0000782c7ffd5ad8  vmovaps [rsp+0x40], xmm4
0000782c7ffd5ade  vmovaps [rsp+0x50], xmm5
0000782c7ffd5ae4  vmovaps [rsp+0x60], xmm6
0000782c7ffd5aea  vmovaps [rsp+0x70], xmm7
0000782c7ffd5af0  vmovaps [rsp+0x80], xmm8
0000782c7ffd5af9  vmovaps [rsp+0x90], xmm9
0000782c7ffd5b02  vmovaps [rsp+0xA0], xmm10
0000782c7ffd5b0b  vmovaps [rsp+0xB0], xmm12
0000782c7ffd5b14  vmovaps [rsp+0xC0], xmm13
0000782c7ffd5b1d  vmovaps [rsp+0xD0], xmm14
0000782c7ffd5b26  vmovaps [rsp+0xE0], xmm15
0000782c7ffd5b2f  sub rsp, 0x40
0000782c7ffd5b33  lea rdi, [rsp]
0000782c7ffd5b37  lea rsi, [rsp+0x10]
0000782c7ffd5b3c  lea rdx, [rsp+0x20]
0000782c7ffd5b41  lea rcx, [rsp+0x30]
0000782c7ffd5b46  mov r8d, 0x00
0000782c7ffd5b4c  lea r9, [r15+0x3A8]
0000782c7ffd5b53  movaps [rdi], xmm11
0000782c7ffd5b57  movaps [rsi], xmm7
0000782c7ffd5b5a  movaps [rdx], xmm1
0000782c7ffd5b5d  movaps [rcx], xmm12
0000782c7ffd5b61  mov rax, 0x5AE5BFFB5A50
0000782c7ffd5b6b  call rax
0000782c7ffd5b6d  movaps xmm11, [rsp]
0000782c7ffd5b72  add rsp, 0x40
0000782c7ffd5b76  vmovaps xmm0, [rsp]
0000782c7ffd5b7b  vmovaps xmm1, [rsp+0x10]
0000782c7ffd5b81  vmovaps xmm2, [rsp+0x20]
0000782c7ffd5b87  vmovaps xmm3, [rsp+0x30]
0000782c7ffd5b8d  vmovaps xmm4, [rsp+0x40]
0000782c7ffd5b93  vmovaps xmm5, [rsp+0x50]
0000782c7ffd5b99  vmovaps xmm6, [rsp+0x60]
0000782c7ffd5b9f  vmovaps xmm7, [rsp+0x70]
0000782c7ffd5ba5  vmovaps xmm8, [rsp+0x80]
0000782c7ffd5bae  vmovaps xmm9, [rsp+0x90]
0000782c7ffd5bb7  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd5bc0  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd5bc9  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd5bd2  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd5bdb  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd5be4  add rsp, 0xF0
0000782c7ffd5beb  pop r11
0000782c7ffd5bed  pop r10
0000782c7ffd5bef  pop r9
0000782c7ffd5bf1  pop r8
0000782c7ffd5bf3  pop rsi
0000782c7ffd5bf4  pop rdi
0000782c7ffd5bf5  pop rdx
0000782c7ffd5bf6  pop rcx
0000782c7ffd5bf7  pop rax
0000782c7ffd5bf8  add rsp, 0x08
0000782c7ffd5bfc  jmp 0x0000782C7FFD3122
0000782c7ffd5c01  call 0x0000782C7FDFF430
0000782c7ffd5c06  jmp 0x0000782C7FFD3134
0000782c7ffd5c0b  sub rsp, 0x08
0000782c7ffd5c0f  push rax
0000782c7ffd5c10  push rcx
0000782c7ffd5c11  push rdx
0000782c7ffd5c12  push rdi
0000782c7ffd5c13  push rsi
0000782c7ffd5c14  push r8
0000782c7ffd5c16  push r9
0000782c7ffd5c18  push r10
0000782c7ffd5c1a  push r11
0000782c7ffd5c1c  sub rsp, 0xF0
0000782c7ffd5c23  vmovaps [rsp], xmm0
0000782c7ffd5c28  vmovaps [rsp+0x10], xmm1
0000782c7ffd5c2e  vmovaps [rsp+0x20], xmm2
0000782c7ffd5c34  vmovaps [rsp+0x30], xmm3
0000782c7ffd5c3a  vmovaps [rsp+0x40], xmm4
0000782c7ffd5c40  vmovaps [rsp+0x50], xmm5
0000782c7ffd5c46  vmovaps [rsp+0x60], xmm6
0000782c7ffd5c4c  vmovaps [rsp+0x70], xmm7
0000782c7ffd5c52  vmovaps [rsp+0x80], xmm8
0000782c7ffd5c5b  vmovaps [rsp+0x90], xmm10
0000782c7ffd5c64  vmovaps [rsp+0xA0], xmm11
0000782c7ffd5c6d  vmovaps [rsp+0xB0], xmm12
0000782c7ffd5c76  vmovaps [rsp+0xC0], xmm13
0000782c7ffd5c7f  vmovaps [rsp+0xD0], xmm14
0000782c7ffd5c88  vmovaps [rsp+0xE0], xmm15
0000782c7ffd5c91  sub rsp, 0x40
0000782c7ffd5c95  lea rdi, [rsp]
0000782c7ffd5c99  lea rsi, [rsp+0x10]
0000782c7ffd5c9e  lea rdx, [rsp+0x20]
0000782c7ffd5ca3  lea rcx, [rsp+0x30]
0000782c7ffd5ca8  mov r8d, 0x00
0000782c7ffd5cae  lea r9, [r15+0x3A8]
0000782c7ffd5cb5  movaps [rdi], xmm9
0000782c7ffd5cb9  movaps [rsi], xmm8
0000782c7ffd5cbd  movaps [rdx], xmm14
0000782c7ffd5cc1  movaps [rcx], xmm12
0000782c7ffd5cc5  mov rax, 0x5AE5BFFB5A50
0000782c7ffd5ccf  call rax
0000782c7ffd5cd1  movaps xmm9, [rsp]
0000782c7ffd5cd6  add rsp, 0x40
0000782c7ffd5cda  vmovaps xmm0, [rsp]
0000782c7ffd5cdf  vmovaps xmm1, [rsp+0x10]
0000782c7ffd5ce5  vmovaps xmm2, [rsp+0x20]
0000782c7ffd5ceb  vmovaps xmm3, [rsp+0x30]
0000782c7ffd5cf1  vmovaps xmm4, [rsp+0x40]
0000782c7ffd5cf7  vmovaps xmm5, [rsp+0x50]
0000782c7ffd5cfd  vmovaps xmm6, [rsp+0x60]
0000782c7ffd5d03  vmovaps xmm7, [rsp+0x70]
0000782c7ffd5d09  vmovaps xmm8, [rsp+0x80]
0000782c7ffd5d12  vmovaps xmm10, [rsp+0x90]
0000782c7ffd5d1b  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd5d24  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd5d2d  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd5d36  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd5d3f  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd5d48  add rsp, 0xF0
0000782c7ffd5d4f  pop r11
0000782c7ffd5d51  pop r10
0000782c7ffd5d53  pop r9
0000782c7ffd5d55  pop r8
0000782c7ffd5d57  pop rsi
0000782c7ffd5d58  pop rdi
0000782c7ffd5d59  pop rdx
0000782c7ffd5d5a  pop rcx
0000782c7ffd5d5b  pop rax
0000782c7ffd5d5c  add rsp, 0x08
0000782c7ffd5d60  jmp 0x0000782C7FFD3165
0000782c7ffd5d65  sub rsp, 0x08
0000782c7ffd5d69  push rax
0000782c7ffd5d6a  push rcx
0000782c7ffd5d6b  push rdx
0000782c7ffd5d6c  push rdi
0000782c7ffd5d6d  push rsi
0000782c7ffd5d6e  push r8
0000782c7ffd5d70  push r9
0000782c7ffd5d72  push r10
0000782c7ffd5d74  push r11
0000782c7ffd5d76  sub rsp, 0xF0
0000782c7ffd5d7d  vmovaps [rsp], xmm0
0000782c7ffd5d82  vmovaps [rsp+0x10], xmm1
0000782c7ffd5d88  vmovaps [rsp+0x20], xmm2
0000782c7ffd5d8e  vmovaps [rsp+0x30], xmm3
0000782c7ffd5d94  vmovaps [rsp+0x40], xmm4
0000782c7ffd5d9a  vmovaps [rsp+0x50], xmm5
0000782c7ffd5da0  vmovaps [rsp+0x60], xmm6
0000782c7ffd5da6  vmovaps [rsp+0x70], xmm7
0000782c7ffd5dac  vmovaps [rsp+0x80], xmm8
0000782c7ffd5db5  vmovaps [rsp+0x90], xmm9
0000782c7ffd5dbe  vmovaps [rsp+0xA0], xmm10
0000782c7ffd5dc7  vmovaps [rsp+0xB0], xmm11
0000782c7ffd5dd0  vmovaps [rsp+0xC0], xmm13
0000782c7ffd5dd9  vmovaps [rsp+0xD0], xmm14
0000782c7ffd5de2  vmovaps [rsp+0xE0], xmm15
0000782c7ffd5deb  sub rsp, 0x40
0000782c7ffd5def  lea rdi, [rsp]
0000782c7ffd5df3  lea rsi, [rsp+0x10]
0000782c7ffd5df8  lea rdx, [rsp+0x20]
0000782c7ffd5dfd  lea rcx, [rsp+0x30]
0000782c7ffd5e02  mov r8d, 0x00
0000782c7ffd5e08  lea r9, [r15+0x3A8]
0000782c7ffd5e0f  movaps [rdi], xmm12
0000782c7ffd5e13  movaps [rsi], xmm10
0000782c7ffd5e17  movaps [rdx], xmm15
0000782c7ffd5e1b  movaps [rcx], xmm14
0000782c7ffd5e1f  mov rax, 0x5AE5BFFB5A50
0000782c7ffd5e29  call rax
0000782c7ffd5e2b  movaps xmm12, [rsp]
0000782c7ffd5e30  add rsp, 0x40
0000782c7ffd5e34  vmovaps xmm0, [rsp]
0000782c7ffd5e39  vmovaps xmm1, [rsp+0x10]
0000782c7ffd5e3f  vmovaps xmm2, [rsp+0x20]
0000782c7ffd5e45  vmovaps xmm3, [rsp+0x30]
0000782c7ffd5e4b  vmovaps xmm4, [rsp+0x40]
0000782c7ffd5e51  vmovaps xmm5, [rsp+0x50]
0000782c7ffd5e57  vmovaps xmm6, [rsp+0x60]
0000782c7ffd5e5d  vmovaps xmm7, [rsp+0x70]
0000782c7ffd5e63  vmovaps xmm8, [rsp+0x80]
0000782c7ffd5e6c  vmovaps xmm9, [rsp+0x90]
0000782c7ffd5e75  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd5e7e  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd5e87  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd5e90  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd5e99  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd5ea2  add rsp, 0xF0
0000782c7ffd5ea9  pop r11
0000782c7ffd5eab  pop r10
0000782c7ffd5ead  pop r9
0000782c7ffd5eaf  pop r8
0000782c7ffd5eb1  pop rsi
0000782c7ffd5eb2  pop rdi
0000782c7ffd5eb3  pop rdx
0000782c7ffd5eb4  pop rcx
0000782c7ffd5eb5  pop rax
0000782c7ffd5eb6  add rsp, 0x08
0000782c7ffd5eba  jmp 0x0000782C7FFD3196
0000782c7ffd5ebf  sub rsp, 0x08
0000782c7ffd5ec3  push rax
0000782c7ffd5ec4  push rcx
0000782c7ffd5ec5  push rdx
0000782c7ffd5ec6  push rdi
0000782c7ffd5ec7  push rsi
0000782c7ffd5ec8  push r8
0000782c7ffd5eca  push r9
0000782c7ffd5ecc  push r10
0000782c7ffd5ece  push r11
0000782c7ffd5ed0  sub rsp, 0xF0
0000782c7ffd5ed7  vmovaps [rsp], xmm0
0000782c7ffd5edc  vmovaps [rsp+0x10], xmm1
0000782c7ffd5ee2  vmovaps [rsp+0x20], xmm2
0000782c7ffd5ee8  vmovaps [rsp+0x30], xmm3
0000782c7ffd5eee  vmovaps [rsp+0x40], xmm4
0000782c7ffd5ef4  vmovaps [rsp+0x50], xmm5
0000782c7ffd5efa  vmovaps [rsp+0x60], xmm6
0000782c7ffd5f00  vmovaps [rsp+0x70], xmm7
0000782c7ffd5f06  vmovaps [rsp+0x80], xmm8
0000782c7ffd5f0f  vmovaps [rsp+0x90], xmm9
0000782c7ffd5f18  vmovaps [rsp+0xA0], xmm10
0000782c7ffd5f21  vmovaps [rsp+0xB0], xmm11
0000782c7ffd5f2a  vmovaps [rsp+0xC0], xmm12
0000782c7ffd5f33  vmovaps [rsp+0xD0], xmm13
0000782c7ffd5f3c  vmovaps [rsp+0xE0], xmm15
0000782c7ffd5f45  sub rsp, 0x40
0000782c7ffd5f49  lea rdi, [rsp]
0000782c7ffd5f4d  lea rsi, [rsp+0x10]
0000782c7ffd5f52  lea rdx, [rsp+0x20]
0000782c7ffd5f57  lea rcx, [rsp+0x30]
0000782c7ffd5f5c  mov r8d, 0x00
0000782c7ffd5f62  lea r9, [r15+0x3A8]
0000782c7ffd5f69  movaps [rdi], xmm14
0000782c7ffd5f6d  movaps [rsi], xmm13
0000782c7ffd5f71  movaps [rdx], xmm1
0000782c7ffd5f74  movaps [rcx], xmm15
0000782c7ffd5f78  mov rax, 0x5AE5BFFB5A50
0000782c7ffd5f82  call rax
0000782c7ffd5f84  movaps xmm14, [rsp]
0000782c7ffd5f89  add rsp, 0x40
0000782c7ffd5f8d  vmovaps xmm0, [rsp]
0000782c7ffd5f92  vmovaps xmm1, [rsp+0x10]
0000782c7ffd5f98  vmovaps xmm2, [rsp+0x20]
0000782c7ffd5f9e  vmovaps xmm3, [rsp+0x30]
0000782c7ffd5fa4  vmovaps xmm4, [rsp+0x40]
0000782c7ffd5faa  vmovaps xmm5, [rsp+0x50]
0000782c7ffd5fb0  vmovaps xmm6, [rsp+0x60]
0000782c7ffd5fb6  vmovaps xmm7, [rsp+0x70]
0000782c7ffd5fbc  vmovaps xmm8, [rsp+0x80]
0000782c7ffd5fc5  vmovaps xmm9, [rsp+0x90]
0000782c7ffd5fce  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd5fd7  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd5fe0  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd5fe9  vmovaps xmm13, [rsp+0xD0]
0000782c7ffd5ff2  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd5ffb  add rsp, 0xF0
0000782c7ffd6002  pop r11
0000782c7ffd6004  pop r10
0000782c7ffd6006  pop r9
0000782c7ffd6008  pop r8
0000782c7ffd600a  pop rsi
0000782c7ffd600b  pop rdi
0000782c7ffd600c  pop rdx
0000782c7ffd600d  pop rcx
0000782c7ffd600e  pop rax
0000782c7ffd600f  add rsp, 0x08
0000782c7ffd6013  jmp 0x0000782C7FFD31C7
0000782c7ffd6018  call 0x0000782C7FE079B0
0000782c7ffd601d  jmp 0x0000782C7FFD31DA
0000782c7ffd6022  call 0x0000782C7FE0B100
0000782c7ffd6027  jmp 0x0000782C7FFD31E5
0000782c7ffd602c  call 0x0000782C7FE09E90
0000782c7ffd6031  jmp 0x0000782C7FFD31F0
0000782c7ffd6036  call 0x0000782C7FE0D600
0000782c7ffd603b  jmp 0x0000782C7FFD31FB
0000782c7ffd6040  int3
0000782c7ffd6041  nop [rax+rax*1], ax
0000782c7ffd604a  nop [rax+rax*1], ax
0000782c7ffd6050  mov rax, [r15+0x40]
0000782c7ffd6054  mov r14, [r15+0x58]
0000782c7ffd6058  lea r12, [rax+r14*1]
0000782c7ffd605c  vxorps xmm1, xmm1, xmm1
0000782c7ffd6060  vpbroadcastq xmm1, xmm1
0000782c7ffd6065  vxorps xmm15, xmm15, xmm15
0000782c7ffd606a  vpbroadcastq xmm15, xmm15
0000782c7ffd606f  lea rax, [r12+0x30]
0000782c7ffd6074  mov r11, [r13+rax*1]
0000782c7ffd6079  lea rax, [r12+0x38]
0000782c7ffd607e  mov r10, [r13+rax*1]
0000782c7ffd6083  movq xmm14, r11
0000782c7ffd6088  movq xmm13, r10
0000782c7ffd608d  movq xmm14, xmm14
0000782c7ffd6092  movq xmm13, xmm13
0000782c7ffd6097  vmovaps [rsp+0x10], xmm13
0000782c7ffd609d  movq xmm13, xmm13
0000782c7ffd60a2  movaps [r15+0x270], xmm13
0000782c7ffd60aa  movaps xmm13, [r15+0x160]
0000782c7ffd60b2  vmovaps [rsp+0x20], xmm13
0000782c7ffd60b8  vmovaps xmm12, [rsp+0x20]
0000782c7ffd60be  por xmm13, xmm12
0000782c7ffd60c3  lea rax, [r12+0x20]
0000782c7ffd60c8  mov r11, [r13+rax*1]
0000782c7ffd60cd  lea rax, [r12+0x28]
0000782c7ffd60d2  mov r10, [r13+rax*1]
0000782c7ffd60d7  movq xmm12, r11
0000782c7ffd60dc  movq xmm11, r10
0000782c7ffd60e1  movq xmm12, xmm12
0000782c7ffd60e6  movq xmm11, xmm11
0000782c7ffd60eb  movaps xmm10, [r15+0x2D0]
0000782c7ffd60f3  vmovaps [rsp+0x20], xmm10
0000782c7ffd60f9  vmovaps xmm9, [rsp+0x20]
0000782c7ffd60ff  por xmm10, xmm9
0000782c7ffd6104  movaps xmm9, [r15+0x300]
0000782c7ffd610c  vmovaps [rsp+0x20], xmm9
0000782c7ffd6112  vmovaps xmm8, [rsp+0x20]
0000782c7ffd6118  por xmm9, xmm8
0000782c7ffd611d  movaps xmm8, [r15+0x2B0]
0000782c7ffd6125  vmovaps [rsp+0x20], xmm8
0000782c7ffd612b  vmovaps xmm7, [rsp+0x20]
0000782c7ffd6131  por xmm8, xmm7
0000782c7ffd6136  movaps xmm7, [r15+0x180]
0000782c7ffd613e  vmovaps [rsp+0x20], xmm7
0000782c7ffd6144  vmovaps xmm6, [rsp+0x20]
0000782c7ffd614a  por xmm7, xmm6
0000782c7ffd614e  lea rax, [r12+0x10]
0000782c7ffd6153  mov r11, [r13+rax*1]
0000782c7ffd6158  lea rax, [r12+0x18]
0000782c7ffd615d  mov r10, [r13+rax*1]
0000782c7ffd6162  movq xmm6, r11
0000782c7ffd6167  movq xmm5, r10
0000782c7ffd616c  movq xmm6, xmm6
0000782c7ffd6170  movq xmm5, xmm5
0000782c7ffd6174  movaps xmm4, [r15+0x200]
0000782c7ffd617c  vmovaps [rsp+0x20], xmm4
0000782c7ffd6182  vmovaps xmm3, [rsp+0x20]
0000782c7ffd6188  por xmm4, xmm3
0000782c7ffd618c  movaps xmm3, [r15+0x1F0]
0000782c7ffd6194  vmovaps [rsp+0x20], xmm3
0000782c7ffd619a  vmovaps xmm2, [rsp+0x20]
0000782c7ffd61a0  por xmm3, xmm2
0000782c7ffd61a4  movaps xmm2, [r15+0x2E0]
0000782c7ffd61ac  vmovaps [rsp+0x20], xmm2
0000782c7ffd61b2  vmovaps [rsp+0x30], xmm1
0000782c7ffd61b8  vmovaps xmm1, [rsp+0x20]
0000782c7ffd61be  por xmm2, xmm1
0000782c7ffd61c2  movaps xmm1, [r15+0x2A0]
0000782c7ffd61ca  vmovaps [rsp+0x20], xmm1
0000782c7ffd61d0  vmovaps [rsp+0x40], xmm15
0000782c7ffd61d6  vmovaps xmm15, [rsp+0x20]
0000782c7ffd61dc  por xmm1, xmm15
0000782c7ffd61e1  movaps xmm15, [r15+0x280]
0000782c7ffd61e9  vmovaps [rsp+0x20], xmm15
0000782c7ffd61ef  vmovaps [rsp+0x50], xmm1
0000782c7ffd61f5  vmovaps xmm1, [rsp+0x20]
0000782c7ffd61fb  por xmm15, xmm1
0000782c7ffd6200  movaps xmm1, [r15+0x1C0]
0000782c7ffd6208  vmovaps [rsp+0x20], xmm1
0000782c7ffd620e  vmovaps [rsp+0x60], xmm15
0000782c7ffd6214  vmovaps xmm15, [rsp+0x20]
0000782c7ffd621a  por xmm1, xmm15
0000782c7ffd621f  movaps xmm15, [r15+0x210]
0000782c7ffd6227  vmovaps [rsp+0x20], xmm15
0000782c7ffd622d  vmovaps [rsp+0x70], xmm1
0000782c7ffd6233  vmovaps xmm1, [rsp+0x20]
0000782c7ffd6239  por xmm15, xmm1
0000782c7ffd623e  mov rax, [r13+r12*1]
0000782c7ffd6243  vmovq xmm1, rax
0000782c7ffd6248  vpbroadcastq xmm1, xmm1
0000782c7ffd624d  vmovaps [rsp+0x20], xmm1
0000782c7ffd6253  vxorps xmm1, xmm1, xmm1
0000782c7ffd6257  vpbroadcastq xmm1, xmm1
0000782c7ffd625c  mov rax, [r15+0xF8]
0000782c7ffd6263  vmovaps [rsp+0x80], xmm1
0000782c7ffd626c  movups xmm1, [r13+rax*1]
0000782c7ffd6272  vmovaps [rsp+0x90], xmm1
0000782c7ffd627b  vxorps xmm1, xmm1, xmm1
0000782c7ffd627f  vpbroadcastq xmm1, xmm1
0000782c7ffd6284  lea r11, [r12+0x08]
0000782c7ffd6289  mov r12, [r13+r11*1]
0000782c7ffd628e  vmovaps [rsp+0xA0], xmm1
0000782c7ffd6297  movq xmm1, r12
0000782c7ffd629c  movaps [r15+0x240], xmm1
0000782c7ffd62a4  mov r12, [r15+0x50]
0000782c7ffd62a8  lea r11, [r12+r14*1]
0000782c7ffd62ac  mov [r15+0x60], r11
0000782c7ffd62b0  lea r12, [r14+0x40]
0000782c7ffd62b4  mov [r15+0x58], r12
0000782c7ffd62b8  vmovaps xmm1, [rsp+0x30]
0000782c7ffd62be  vmovaps [rsp+0x30], xmm15
0000782c7ffd62c4  vmovaps xmm15, [rsp+0x90]
0000782c7ffd62cd  vmovaps [rsp+0x90], xmm14
0000782c7ffd62d6  vmovaps xmm14, [rsp+0x20]
0000782c7ffd62dc  vmovaps [rsp+0x20], xmm13
0000782c7ffd62e2  vmovaps [rsp+0xB0], xmm12
0000782c7ffd62eb  movaps xmm13, xmm1
0000782c7ffd62ef  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd62fa  vptest xmm12, xmm12
0000782c7ffd62ff  jnz 0x0000782C7FFD6D9C
0000782c7ffd6305  movaps xmm1, [r15+0x250]
0000782c7ffd630d  vmovaps xmm15, [rsp+0x40]
0000782c7ffd6313  vmovaps [rsp+0x40], xmm13
0000782c7ffd6319  movaps xmm12, xmm15
0000782c7ffd631d  vfmadd231pd xmm12, xmm1, xmm14
0000782c7ffd6322  vcmppd xmm13, xmm12, xmm12, 0x03
0000782c7ffd6328  vptest xmm13, xmm13
0000782c7ffd632d  jnz 0x0000782C7FFD6EF5
0000782c7ffd6333  movaps xmm15, [r15+0x1E0]
0000782c7ffd633b  vmovaps [rsp+0xC0], xmm15
0000782c7ffd6344  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd634d  por xmm15, xmm13
0000782c7ffd6352  movaps xmm13, [r15+0x1D0]
0000782c7ffd635a  vmovaps [rsp+0xC0], xmm13
0000782c7ffd6363  vmovaps [rsp+0xD0], xmm1
0000782c7ffd636c  vmovaps xmm1, [rsp+0xC0]
0000782c7ffd6375  por xmm13, xmm1
0000782c7ffd637a  movaps xmm1, [r15+0x2C0]
0000782c7ffd6382  vmovaps [rsp+0xC0], xmm1
0000782c7ffd638b  vmovaps [rsp+0xE0], xmm15
0000782c7ffd6394  vmovaps xmm15, [rsp+0xC0]
0000782c7ffd639d  por xmm1, xmm15
0000782c7ffd63a2  movaps xmm15, [r15+0x290]
0000782c7ffd63aa  vmovaps [rsp+0xC0], xmm15
0000782c7ffd63b3  vmovaps [rsp+0xF0], xmm1
0000782c7ffd63bc  vmovaps xmm1, [rsp+0xC0]
0000782c7ffd63c5  por xmm15, xmm1
0000782c7ffd63ca  movaps xmm1, [r15+0x260]
0000782c7ffd63d2  vmovaps [rsp+0xC0], xmm1
0000782c7ffd63db  vmovaps [rsp+0x100], xmm15
0000782c7ffd63e4  vmovaps xmm15, [rsp+0xC0]
0000782c7ffd63ed  por xmm1, xmm15
0000782c7ffd63f2  vmovaps xmm15, [rsp+0xD0]
0000782c7ffd63fb  vmovaps [rsp+0xC0], xmm1
0000782c7ffd6404  vmovaps xmm1, [rsp+0xD0]
0000782c7ffd640d  por xmm15, xmm1
0000782c7ffd6412  lea r14, [rax+0xC0]
0000782c7ffd6419  movups xmm1, [r13+r14*1]
0000782c7ffd641f  mov [rsp+0xD0], rax
0000782c7ffd6427  xor eax, eax
0000782c7ffd6429  mov r14d, 0x200
0000782c7ffd642f  cmp r12, r14
0000782c7ffd6432  cmc
0000782c7ffd6433  lahf
0000782c7ffd6434  seto al
0000782c7ffd6437  mov [r15+0x108], eax
0000782c7ffd643e  vmovaps [rsp+0x110], xmm1
0000782c7ffd6447  vmovaps xmm1, [rsp+0x80]
0000782c7ffd6450  vmovaps [rsp+0x80], xmm15
0000782c7ffd6459  vmovaps xmm15, [rsp+0x110]
0000782c7ffd6462  vmovaps [rsp+0x110], xmm13
0000782c7ffd646b  vmovaps [rsp+0x120], xmm12
0000782c7ffd6474  movaps xmm13, xmm1
0000782c7ffd6478  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd647d  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd6483  vptest xmm12, xmm12
0000782c7ffd6488  jnz 0x0000782C7FFD7058
0000782c7ffd648e  mov rax, [rsp+0xD0]
0000782c7ffd6496  lea r14, [rax+0xB0]
0000782c7ffd649d  movups xmm1, [r13+r14*1]
0000782c7ffd64a3  vmovaps xmm15, [rsp+0xA0]
0000782c7ffd64ac  vmovaps [rsp+0xA0], xmm13
0000782c7ffd64b5  movaps xmm12, xmm15
0000782c7ffd64b9  vfmadd231pd xmm12, xmm1, xmm14
0000782c7ffd64be  vcmppd xmm13, xmm12, xmm12, 0x03
0000782c7ffd64c4  vptest xmm13, xmm13
0000782c7ffd64c9  jnz 0x0000782C7FFD71BB
0000782c7ffd64cf  vmovaps xmm1, [rsp+0x30]
0000782c7ffd64d5  vmovaps xmm15, [rsp+0x30]
0000782c7ffd64db  por xmm1, xmm15
0000782c7ffd64e0  movaps [r15+0x210], xmm1
0000782c7ffd64e8  vmovaps xmm15, [rsp+0x70]
0000782c7ffd64ee  vmovaps xmm14, [rsp+0x70]
0000782c7ffd64f4  por xmm15, xmm14
0000782c7ffd64f9  movaps [r15+0x1C0], xmm15
0000782c7ffd6501  vmovaps xmm14, [rsp+0x60]
0000782c7ffd6507  vmovaps xmm13, [rsp+0x60]
0000782c7ffd650d  por xmm14, xmm13
0000782c7ffd6512  movaps [r15+0x280], xmm14
0000782c7ffd651a  vmovaps xmm13, [rsp+0x50]
0000782c7ffd6520  vmovaps [rsp+0x30], xmm1
0000782c7ffd6526  vmovaps xmm1, [rsp+0x50]
0000782c7ffd652c  por xmm13, xmm1
0000782c7ffd6531  movaps [r15+0x2A0], xmm13
0000782c7ffd6539  vmovaps [rsp+0x50], xmm2
0000782c7ffd653f  vmovaps xmm1, [rsp+0x50]
0000782c7ffd6545  por xmm2, xmm1
0000782c7ffd6549  movaps [r15+0x2E0], xmm2
0000782c7ffd6551  vmovaps [rsp+0x50], xmm3
0000782c7ffd6557  vmovaps xmm1, [rsp+0x50]
0000782c7ffd655d  por xmm3, xmm1
0000782c7ffd6561  movaps [r15+0x1F0], xmm3
0000782c7ffd6569  vmovaps xmm1, [rsp+0x80]
0000782c7ffd6572  vmovaps [rsp+0x50], xmm15
0000782c7ffd6578  vmovaps xmm15, [rsp+0x80]
0000782c7ffd6581  por xmm1, xmm15
0000782c7ffd6586  movaps [r15+0x250], xmm1
0000782c7ffd658e  vmovaps xmm1, [rsp+0xC0]
0000782c7ffd6597  vmovaps xmm15, [rsp+0xC0]
0000782c7ffd65a0  por xmm1, xmm15
0000782c7ffd65a5  movaps [r15+0x260], xmm1
0000782c7ffd65ad  vmovaps xmm15, [rsp+0x100]
0000782c7ffd65b6  vmovaps [rsp+0x60], xmm1
0000782c7ffd65bc  vmovaps xmm1, [rsp+0x100]
0000782c7ffd65c5  por xmm15, xmm1
0000782c7ffd65ca  movaps [r15+0x290], xmm15
0000782c7ffd65d2  vmovaps xmm1, [rsp+0xF0]
0000782c7ffd65db  vmovaps [rsp+0x70], xmm15
0000782c7ffd65e1  vmovaps xmm15, [rsp+0xF0]
0000782c7ffd65ea  por xmm1, xmm15
0000782c7ffd65ef  movaps [r15+0x2C0], xmm1
0000782c7ffd65f7  movq xmm15, qword ptr [r15+0x240]
0000782c7ffd6600  vmovaps [rsp+0x80], xmm15
0000782c7ffd6609  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd660f  vmovaps [rsp+0xC0], xmm1
0000782c7ffd6618  vmovaps xmm1, [rsp+0x40]
0000782c7ffd661e  vmovaps [rsp+0x40], xmm15
0000782c7ffd6624  vmovaps xmm15, [rsp+0x30]
0000782c7ffd662a  vmovaps [rsp+0x30], xmm14
0000782c7ffd6630  vmovaps xmm14, [rsp+0x40]
0000782c7ffd6636  vmovaps [rsp+0x40], xmm13
0000782c7ffd663c  vmovaps [rsp+0xD0], xmm12
0000782c7ffd6645  movaps xmm13, xmm1
0000782c7ffd6649  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd664e  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd6654  vptest xmm12, xmm12
0000782c7ffd6659  jnz 0x0000782C7FFD7314
0000782c7ffd665f  vmovaps xmm1, [rsp+0x80]
0000782c7ffd6668  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd666e  vmovaps xmm15, [rsp+0xA0]
0000782c7ffd6677  movaps xmm14, xmm15
0000782c7ffd667b  vfmadd231pd xmm14, xmm2, xmm1
0000782c7ffd6680  vcmppd xmm12, xmm14, xmm14, 0x03
0000782c7ffd6686  vptest xmm12, xmm12
0000782c7ffd668b  jnz 0x0000782C7FFD746D
0000782c7ffd6691  vmovaps xmm1, [rsp+0x80]
0000782c7ffd669a  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd66a0  vmovaps xmm15, [rsp+0x120]
0000782c7ffd66a9  vmovaps xmm12, [rsp+0x50]
0000782c7ffd66af  vmovaps [rsp+0x50], xmm14
0000782c7ffd66b5  movaps xmm2, xmm15
0000782c7ffd66b9  vfmadd231pd xmm2, xmm12, xmm1
0000782c7ffd66be  vcmppd xmm14, xmm2, xmm2, 0x03
0000782c7ffd66c3  vptest xmm14, xmm14
0000782c7ffd66c8  jnz 0x0000782C7FFD75C5
0000782c7ffd66ce  vmovaps xmm1, [rsp+0x110]
0000782c7ffd66d7  vmovaps xmm15, [rsp+0x110]
0000782c7ffd66e0  por xmm1, xmm15
0000782c7ffd66e5  movaps [r15+0x1D0], xmm1
0000782c7ffd66ed  vmovaps xmm15, [rsp+0x80]
0000782c7ffd66f6  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd66fc  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd6705  vmovaps [rsp+0x80], xmm1
0000782c7ffd670e  movaps xmm12, xmm14
0000782c7ffd6712  vfmadd231pd xmm12, xmm3, xmm15
0000782c7ffd6717  vcmppd xmm1, xmm12, xmm12, 0x03
0000782c7ffd671d  vptest xmm1, xmm1
0000782c7ffd6722  jnz 0x0000782C7FFD771C
0000782c7ffd6728  vmovaps [rsp+0xA0], xmm4
0000782c7ffd6731  vmovaps xmm1, [rsp+0xA0]
0000782c7ffd673a  por xmm4, xmm1
0000782c7ffd673e  movaps [r15+0x200], xmm4
0000782c7ffd6746  vmovaps xmm1, [rsp+0xE0]
0000782c7ffd674f  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd6758  por xmm1, xmm15
0000782c7ffd675d  movaps [r15+0x1E0], xmm1
0000782c7ffd6765  vmovaps [rsp+0xA0], xmm8
0000782c7ffd676e  vmovaps xmm1, [rsp+0xA0]
0000782c7ffd6777  por xmm8, xmm1
0000782c7ffd677c  movaps [r15+0x2B0], xmm8
0000782c7ffd6784  vmovaps [rsp+0xA0], xmm9
0000782c7ffd678d  vmovaps xmm1, [rsp+0xA0]
0000782c7ffd6796  por xmm9, xmm1
0000782c7ffd679b  movaps [r15+0x300], xmm9
0000782c7ffd67a3  vmovaps [rsp+0xA0], xmm6
0000782c7ffd67ac  vpermilpd xmm6, xmm6, 0x00
0000782c7ffd67b2  vmovaps xmm14, [rsp+0x60]
0000782c7ffd67b8  movaps xmm9, xmm13
0000782c7ffd67bc  vfmadd231pd xmm9, xmm14, xmm6
0000782c7ffd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
0000782c7ffd67c7  vptest xmm3, xmm3
0000782c7ffd67cc  jnz 0x0000782C7FFD7875
0000782c7ffd67d2  vmovaps xmm14, [rsp+0xA0]
0000782c7ffd67db  vpermilpd xmm14, xmm14, 0x00
0000782c7ffd67e1  vmovaps xmm13, [rsp+0x50]
0000782c7ffd67e7  vmovaps xmm6, [rsp+0xC0]
0000782c7ffd67f0  vmovaps [rsp+0x50], xmm1
0000782c7ffd67f6  movaps xmm3, xmm13
0000782c7ffd67fa  vfmadd231pd xmm3, xmm6, xmm14
0000782c7ffd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
0000782c7ffd6804  vptest xmm1, xmm1
0000782c7ffd6809  jnz 0x0000782C7FFD79CE
0000782c7ffd680f  vmovaps xmm1, [rsp+0xA0]
0000782c7ffd6818  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd681e  vmovaps xmm14, [rsp+0x30]
0000782c7ffd6824  movaps xmm6, xmm2
0000782c7ffd6827  vfmadd231pd xmm6, xmm14, xmm1
0000782c7ffd682c  vcmppd xmm13, xmm6, xmm6, 0x03
0000782c7ffd6831  vptest xmm13, xmm13
0000782c7ffd6836  jnz 0x0000782C7FFD7B25
0000782c7ffd683c  vmovaps xmm1, [rsp+0xA0]
0000782c7ffd6845  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd684b  vmovaps xmm14, [rsp+0x80]
0000782c7ffd6854  movaps xmm13, xmm12
0000782c7ffd6858  vfmadd231pd xmm13, xmm14, xmm1
0000782c7ffd685d  vcmppd xmm2, xmm13, xmm13, 0x03
0000782c7ffd6863  vptest xmm2, xmm2
0000782c7ffd6868  jnz 0x0000782C7FFD7C7B
0000782c7ffd686e  vmovaps [rsp+0x30], xmm7
0000782c7ffd6874  vmovaps xmm1, [rsp+0x30]
0000782c7ffd687a  por xmm7, xmm1
0000782c7ffd687e  movaps [r15+0x180], xmm7
0000782c7ffd6886  vmovaps [rsp+0x30], xmm10
0000782c7ffd688c  vmovaps xmm1, [rsp+0x30]
0000782c7ffd6892  por xmm10, xmm1
0000782c7ffd6897  movaps [r15+0x2D0], xmm10
0000782c7ffd689f  vmovaps [rsp+0x30], xmm5
0000782c7ffd68a5  vpermilpd xmm5, xmm5, 0x00
0000782c7ffd68ab  vmovaps xmm14, [rsp+0x50]
0000782c7ffd68b1  movaps xmm12, xmm3
0000782c7ffd68b5  vfmadd231pd xmm12, xmm14, xmm5
0000782c7ffd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
0000782c7ffd68c0  vptest xmm10, xmm10
0000782c7ffd68c5  jnz 0x0000782C7FFD7DD4
0000782c7ffd68cb  vmovaps xmm14, [rsp+0x30]
0000782c7ffd68d1  vpermilpd xmm14, xmm14, 0x00
0000782c7ffd68d7  movaps xmm10, xmm9
0000782c7ffd68db  vfmadd231pd xmm10, xmm7, xmm14
0000782c7ffd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
0000782c7ffd68e6  vptest xmm5, xmm5
0000782c7ffd68eb  jnz 0x0000782C7FFD7F2C
0000782c7ffd68f1  lea r14, [rax+0x80]
0000782c7ffd68f8  movups xmm14, [r13+r14*1]
0000782c7ffd68fe  movaps [r15+0x2F0], xmm14
0000782c7ffd6906  vmovaps xmm9, [rsp+0x30]
0000782c7ffd690c  vpermilpd xmm9, xmm9, 0x00
0000782c7ffd6912  vmovaps xmm7, [rsp+0x70]
0000782c7ffd6918  movaps xmm5, xmm6
0000782c7ffd691b  vfmadd231pd xmm5, xmm7, xmm9
0000782c7ffd6920  vcmppd xmm3, xmm5, xmm5, 0x03
0000782c7ffd6925  vptest xmm3, xmm3
0000782c7ffd692a  jnz 0x0000782C7FFD808F
0000782c7ffd6930  vmovaps xmm9, [rsp+0x30]
0000782c7ffd6936  vpermilpd xmm9, xmm9, 0x00
0000782c7ffd693c  movaps xmm7, xmm13
0000782c7ffd6940  vfmadd231pd xmm7, xmm1, xmm9
0000782c7ffd6945  vcmppd xmm6, xmm7, xmm7, 0x03
0000782c7ffd694a  vptest xmm6, xmm6
0000782c7ffd694f  jnz 0x0000782C7FFD81E5
0000782c7ffd6955  vmovaps xmm1, [rsp+0x20]
0000782c7ffd695b  vmovaps xmm13, [rsp+0x20]
0000782c7ffd6961  por xmm1, xmm13
0000782c7ffd6966  movaps [r15+0x160], xmm1
0000782c7ffd696e  lea r14, [rax+0x40]
0000782c7ffd6972  movups xmm13, [r13+r14*1]
0000782c7ffd6978  lea r14, [rax+0x50]
0000782c7ffd697c  movups xmm9, [r13+r14*1]
0000782c7ffd6982  movaps [r15+0x1B0], xmm13
0000782c7ffd698a  movaps [r15+0x1A0], xmm9
0000782c7ffd6992  movaps xmm6, [r15+0x190]
0000782c7ffd699a  vmovaps xmm3, [rsp+0xB0]
0000782c7ffd69a3  vpermilpd xmm3, xmm3, 0x00
0000782c7ffd69a9  vmovaps [rsp+0x20], xmm1
0000782c7ffd69af  movaps xmm2, xmm12
0000782c7ffd69b3  vfmadd231pd xmm2, xmm6, xmm3
0000782c7ffd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
0000782c7ffd69bd  vptest xmm1, xmm1
0000782c7ffd69c2  jnz 0x0000782C7FFD8350
0000782c7ffd69c8  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd69d1  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd69d7  vmovaps xmm12, [rsp+0x20]
0000782c7ffd69dd  movaps xmm6, xmm10
0000782c7ffd69e1  vfmadd231pd xmm6, xmm12, xmm1
0000782c7ffd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
0000782c7ffd69eb  vptest xmm3, xmm3
0000782c7ffd69f0  jnz 0x0000782C7FFD84A6
0000782c7ffd69f6  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd69ff  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd6a05  vmovaps xmm12, [rsp+0x40]
0000782c7ffd6a0b  movaps xmm10, xmm5
0000782c7ffd6a0f  vfmadd231pd xmm10, xmm12, xmm1
0000782c7ffd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
0000782c7ffd6a1a  vptest xmm3, xmm3
0000782c7ffd6a1f  jnz 0x0000782C7FFD85FD
0000782c7ffd6a25  vmovaps xmm1, [rsp+0xB0]
0000782c7ffd6a2e  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd6a34  movaps xmm12, xmm7
0000782c7ffd6a38  vfmadd231pd xmm12, xmm15, xmm1
0000782c7ffd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
0000782c7ffd6a43  vptest xmm5, xmm5
0000782c7ffd6a48  jnz 0x0000782C7FFD8755
0000782c7ffd6a4e  lea r14, [rax+0x60]
0000782c7ffd6a52  movups xmm1, [r13+r14*1]
0000782c7ffd6a58  lea r14, [rax+0x70]
0000782c7ffd6a5c  movups xmm15, [r13+r14*1]
0000782c7ffd6a62  movaps [r15+0x150], xmm1
0000782c7ffd6a6a  movaps [r15+0x120], xmm15
0000782c7ffd6a72  vmovaps [rsp+0x20], xmm11
0000782c7ffd6a78  vpermilpd xmm11, xmm11, 0x00
0000782c7ffd6a7e  movaps xmm7, xmm2
0000782c7ffd6a81  vfmadd231pd xmm7, xmm9, xmm11
0000782c7ffd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
0000782c7ffd6a8b  vptest xmm5, xmm5
0000782c7ffd6a90  jnz 0x0000782C7FFD88C1
0000782c7ffd6a96  vmovaps xmm11, [rsp+0x20]
0000782c7ffd6a9c  vpermilpd xmm11, xmm11, 0x00
0000782c7ffd6aa2  movaps xmm9, xmm6
0000782c7ffd6aa6  vfmadd231pd xmm9, xmm1, xmm11
0000782c7ffd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
0000782c7ffd6ab1  vptest xmm5, xmm5
0000782c7ffd6ab6  jnz 0x0000782C7FFD8A18
0000782c7ffd6abc  vmovaps xmm1, [rsp+0x20]
0000782c7ffd6ac2  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd6ac8  movaps xmm11, xmm10
0000782c7ffd6acc  vfmadd231pd xmm11, xmm8, xmm1
0000782c7ffd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
0000782c7ffd6ad7  vptest xmm6, xmm6
0000782c7ffd6adc  jnz 0x0000782C7FFD8B70
0000782c7ffd6ae2  vmovaps xmm1, [rsp+0x20]
0000782c7ffd6ae8  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd6aee  movaps xmm10, xmm12
0000782c7ffd6af2  vfmadd231pd xmm10, xmm13, xmm1
0000782c7ffd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
0000782c7ffd6afd  vptest xmm8, xmm8
0000782c7ffd6b02  jnz 0x0000782C7FFD8CC9
0000782c7ffd6b08  lea r14, [rax+0x20]
0000782c7ffd6b0c  movups xmm1, [r13+r14*1]
0000782c7ffd6b12  lea r14, [rax+0x30]
0000782c7ffd6b16  movups xmm13, [r13+r14*1]
0000782c7ffd6b1c  vmovaps xmm12, [rsp+0x90]
0000782c7ffd6b25  vpermilpd xmm12, xmm12, 0x00
0000782c7ffd6b2b  movaps xmm8, xmm7
0000782c7ffd6b2f  vfmadd231pd xmm8, xmm4, xmm12
0000782c7ffd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
0000782c7ffd6b3a  vptest xmm6, xmm6
0000782c7ffd6b3f  jnz 0x0000782C7FFD8E36
0000782c7ffd6b45  vmovaps xmm12, [rsp+0x90]
0000782c7ffd6b4e  vpermilpd xmm12, xmm12, 0x00
0000782c7ffd6b54  movaps xmm7, xmm9
0000782c7ffd6b58  vfmadd231pd xmm7, xmm14, xmm12
0000782c7ffd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
0000782c7ffd6b62  vptest xmm6, xmm6
0000782c7ffd6b67  jnz 0x0000782C7FFD8F8E
0000782c7ffd6b6d  vmovaps xmm14, [rsp+0x90]
0000782c7ffd6b76  vpermilpd xmm14, xmm14, 0x00
0000782c7ffd6b7c  movaps xmm12, xmm11
0000782c7ffd6b80  vfmadd231pd xmm12, xmm15, xmm14
0000782c7ffd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
0000782c7ffd6b8b  vptest xmm9, xmm9
0000782c7ffd6b90  jnz 0x0000782C7FFD90E6
0000782c7ffd6b96  vmovaps xmm15, [rsp+0x90]
0000782c7ffd6b9f  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd6ba5  movaps xmm11, xmm10
0000782c7ffd6ba9  vfmadd231pd xmm11, xmm13, xmm15
0000782c7ffd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
0000782c7ffd6bb4  vptest xmm14, xmm14
0000782c7ffd6bb9  jnz 0x0000782C7FFD9240
0000782c7ffd6bbf  lea r14, [rax+0x90]
0000782c7ffd6bc6  movups xmm15, [r13+r14*1]
0000782c7ffd6bcc  lea r14, [rax+0xA0]
0000782c7ffd6bd3  movups xmm14, [r13+r14*1]
0000782c7ffd6bd9  movaps [r15+0x140], xmm15
0000782c7ffd6be1  movaps [r15+0x130], xmm14
0000782c7ffd6be9  vmovaps xmm13, [rsp+0x10]
0000782c7ffd6bef  vpermilpd xmm13, xmm13, 0x00
0000782c7ffd6bf5  movaps xmm10, xmm8
0000782c7ffd6bf9  vfmadd231pd xmm10, xmm1, xmm13
0000782c7ffd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
0000782c7ffd6c04  vptest xmm9, xmm9
0000782c7ffd6c09  jnz 0x0000782C7FFD93AE
0000782c7ffd6c0f  movaps [r15+0x220], xmm10
0000782c7ffd6c17  lea r14, [rax+0x10]
0000782c7ffd6c1b  movups xmm1, [r13+r14*1]
0000782c7ffd6c21  movaps [r15+0x240], xmm1
0000782c7ffd6c29  vmovaps xmm13, [rsp+0x10]
0000782c7ffd6c2f  vpermilpd xmm13, xmm13, 0x00
0000782c7ffd6c35  movaps xmm9, xmm7
0000782c7ffd6c39  vfmadd231pd xmm9, xmm14, xmm13
0000782c7ffd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
0000782c7ffd6c44  vptest xmm8, xmm8
0000782c7ffd6c49  jnz 0x0000782C7FFD9511
0000782c7ffd6c4f  movaps [r15+0x110], xmm9
0000782c7ffd6c57  vmovaps xmm14, [rsp+0x10]
0000782c7ffd6c5d  vpermilpd xmm14, xmm14, 0x00
0000782c7ffd6c63  movaps xmm13, xmm12
0000782c7ffd6c67  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
0000782c7ffd6c72  vptest xmm8, xmm8
0000782c7ffd6c77  jnz 0x0000782C7FFD966A
0000782c7ffd6c7d  movaps [r15+0x170], xmm13
0000782c7ffd6c85  vmovaps xmm15, [rsp+0x10]
0000782c7ffd6c8b  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd6c91  movaps xmm14, xmm11
0000782c7ffd6c95  vfmadd231pd xmm14, xmm1, xmm15
0000782c7ffd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
0000782c7ffd6ca0  vptest xmm12, xmm12
0000782c7ffd6ca5  jnz 0x0000782C7FFD97C4
0000782c7ffd6cab  movaps [r15+0x230], xmm14
0000782c7ffd6cb3  movups [r13+r11*1], xmm9
0000782c7ffd6cb9  lea rax, [r11+0x10]
0000782c7ffd6cbd  movups [r13+rax*1], xmm13
0000782c7ffd6cc3  lea rax, [r11+0x20]
0000782c7ffd6cc7  movups [r13+rax*1], xmm10
0000782c7ffd6ccd  lea rax, [r11+0x30]
0000782c7ffd6cd1  movups [r13+rax*1], xmm14
0000782c7ffd6cd7  mov eax, [r15+0x108]
0000782c7ffd6cde  sahf
0000782c7ffd6cdf  jnz 0x0000782C7FFD6D11
0000782c7ffd6ce1  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd6ce9  jz 0x0000782C7FFD9950
0000782c7ffd6cef  nop [rax+rax*1], ax
0000782c7ffd6cf8  nop [rax+rax*1], eax
0000782c7ffd6d00  mov eax, 0x410664
0000782c7ffd6d05  mov [r15+0x100], rax
0000782c7ffd6d0c  jmp 0x0000782C7FDFE110
0000782c7ffd6d11  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd6d19  jz 0x0000782C7FFD6050
0000782c7ffd6d1f  nop [rax+rax*1], ax
0000782c7ffd6d28  nop [rax+rax*1], eax
0000782c7ffd6d30  mov eax, 0x4104F0
0000782c7ffd6d35  mov [r15+0x100], rax
0000782c7ffd6d3c  jmp 0x0000782C7FDFE110
0000782c7ffd6d41  int3
0000782c7ffd6d42  call 0x0000782C7FE0A4B0
0000782c7ffd6d47  jmp 0x0000782C7FFD6079
0000782c7ffd6d4c  call 0x0000782C7FE09240
0000782c7ffd6d51  jmp 0x0000782C7FFD6083
0000782c7ffd6d56  call 0x0000782C7FE0A4B0
0000782c7ffd6d5b  jmp 0x0000782C7FFD60CD
0000782c7ffd6d60  call 0x0000782C7FE09240
0000782c7ffd6d65  jmp 0x0000782C7FFD60D7
0000782c7ffd6d6a  call 0x0000782C7FE0A4B0
0000782c7ffd6d6f  jmp 0x0000782C7FFD6158
0000782c7ffd6d74  call 0x0000782C7FE09240
0000782c7ffd6d79  jmp 0x0000782C7FFD6162
0000782c7ffd6d7e  call 0x0000782C7FEB47C0
0000782c7ffd6d83  jmp 0x0000782C7FFD6243
0000782c7ffd6d88  call 0x0000782C7FDFF430
0000782c7ffd6d8d  jmp 0x0000782C7FFD6272
0000782c7ffd6d92  call 0x0000782C7FEB0CE0
0000782c7ffd6d97  jmp 0x0000782C7FFD628E
0000782c7ffd6d9c  sub rsp, 0x08
0000782c7ffd6da0  push rax
0000782c7ffd6da1  push rcx
0000782c7ffd6da2  push rdx
0000782c7ffd6da3  push rdi
0000782c7ffd6da4  push rsi
0000782c7ffd6da5  push r8
0000782c7ffd6da7  push r9
0000782c7ffd6da9  push r10
0000782c7ffd6dab  push r11
0000782c7ffd6dad  sub rsp, 0xF0
0000782c7ffd6db4  vmovaps [rsp], xmm0
0000782c7ffd6db9  vmovaps [rsp+0x10], xmm1
0000782c7ffd6dbf  vmovaps [rsp+0x20], xmm2
0000782c7ffd6dc5  vmovaps [rsp+0x30], xmm3
0000782c7ffd6dcb  vmovaps [rsp+0x40], xmm4
0000782c7ffd6dd1  vmovaps [rsp+0x50], xmm5
0000782c7ffd6dd7  vmovaps [rsp+0x60], xmm6
0000782c7ffd6ddd  vmovaps [rsp+0x70], xmm7
0000782c7ffd6de3  vmovaps [rsp+0x80], xmm8
0000782c7ffd6dec  vmovaps [rsp+0x90], xmm9
0000782c7ffd6df5  vmovaps [rsp+0xA0], xmm10
0000782c7ffd6dfe  vmovaps [rsp+0xB0], xmm11
0000782c7ffd6e07  vmovaps [rsp+0xC0], xmm12
0000782c7ffd6e10  vmovaps [rsp+0xD0], xmm14
0000782c7ffd6e19  vmovaps [rsp+0xE0], xmm15
0000782c7ffd6e22  sub rsp, 0x40
0000782c7ffd6e26  lea rdi, [rsp]
0000782c7ffd6e2a  lea rsi, [rsp+0x10]
0000782c7ffd6e2f  lea rdx, [rsp+0x20]
0000782c7ffd6e34  lea rcx, [rsp+0x30]
0000782c7ffd6e39  mov r8d, 0x00
0000782c7ffd6e3f  lea r9, [r15+0x3A8]
0000782c7ffd6e46  movaps [rdi], xmm13
0000782c7ffd6e4a  movaps [rsi], xmm1
0000782c7ffd6e4d  movaps [rdx], xmm15
0000782c7ffd6e51  movaps [rcx], xmm14
0000782c7ffd6e55  mov rax, 0x5AE5BFFB5A50
0000782c7ffd6e5f  call rax
0000782c7ffd6e61  movaps xmm13, [rsp]
0000782c7ffd6e66  add rsp, 0x40
0000782c7ffd6e6a  vmovaps xmm0, [rsp]
0000782c7ffd6e6f  vmovaps xmm1, [rsp+0x10]
0000782c7ffd6e75  vmovaps xmm2, [rsp+0x20]
0000782c7ffd6e7b  vmovaps xmm3, [rsp+0x30]
0000782c7ffd6e81  vmovaps xmm4, [rsp+0x40]
0000782c7ffd6e87  vmovaps xmm5, [rsp+0x50]
0000782c7ffd6e8d  vmovaps xmm6, [rsp+0x60]
0000782c7ffd6e93  vmovaps xmm7, [rsp+0x70]
0000782c7ffd6e99  vmovaps xmm8, [rsp+0x80]
0000782c7ffd6ea2  vmovaps xmm9, [rsp+0x90]
0000782c7ffd6eab  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd6eb4  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd6ebd  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd6ec6  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd6ecf  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd6ed8  add rsp, 0xF0
0000782c7ffd6edf  pop r11
0000782c7ffd6ee1  pop r10
0000782c7ffd6ee3  pop r9
0000782c7ffd6ee5  pop r8
0000782c7ffd6ee7  pop rsi
0000782c7ffd6ee8  pop rdi
0000782c7ffd6ee9  pop rdx
0000782c7ffd6eea  pop rcx
0000782c7ffd6eeb  pop rax
0000782c7ffd6eec  add rsp, 0x08
0000782c7ffd6ef0  jmp 0x0000782C7FFD6305
0000782c7ffd6ef5  sub rsp, 0x08
0000782c7ffd6ef9  push rax
0000782c7ffd6efa  push rcx
0000782c7ffd6efb  push rdx
0000782c7ffd6efc  push rdi
0000782c7ffd6efd  push rsi
0000782c7ffd6efe  push r8
0000782c7ffd6f00  push r9
0000782c7ffd6f02  push r10
0000782c7ffd6f04  push r11
0000782c7ffd6f06  sub rsp, 0xF0
0000782c7ffd6f0d  vmovaps [rsp], xmm0
0000782c7ffd6f12  vmovaps [rsp+0x10], xmm1
0000782c7ffd6f18  vmovaps [rsp+0x20], xmm2
0000782c7ffd6f1e  vmovaps [rsp+0x30], xmm3
0000782c7ffd6f24  vmovaps [rsp+0x40], xmm4
0000782c7ffd6f2a  vmovaps [rsp+0x50], xmm5
0000782c7ffd6f30  vmovaps [rsp+0x60], xmm6
0000782c7ffd6f36  vmovaps [rsp+0x70], xmm7
0000782c7ffd6f3c  vmovaps [rsp+0x80], xmm8
0000782c7ffd6f45  vmovaps [rsp+0x90], xmm9
0000782c7ffd6f4e  vmovaps [rsp+0xA0], xmm10
0000782c7ffd6f57  vmovaps [rsp+0xB0], xmm11
0000782c7ffd6f60  vmovaps [rsp+0xC0], xmm13
0000782c7ffd6f69  vmovaps [rsp+0xD0], xmm14
0000782c7ffd6f72  vmovaps [rsp+0xE0], xmm15
0000782c7ffd6f7b  sub rsp, 0x40
0000782c7ffd6f7f  lea rdi, [rsp]
0000782c7ffd6f83  lea rsi, [rsp+0x10]
0000782c7ffd6f88  lea rdx, [rsp+0x20]
0000782c7ffd6f8d  lea rcx, [rsp+0x30]
0000782c7ffd6f92  mov r8d, 0x00
0000782c7ffd6f98  lea r9, [r15+0x3A8]
0000782c7ffd6f9f  movaps [rdi], xmm12
0000782c7ffd6fa3  movaps [rsi], xmm15
0000782c7ffd6fa7  movaps [rdx], xmm1
0000782c7ffd6faa  movaps [rcx], xmm14
0000782c7ffd6fae  mov rax, 0x5AE5BFFB5A50
0000782c7ffd6fb8  call rax
0000782c7ffd6fba  movaps xmm12, [rsp]
0000782c7ffd6fbf  add rsp, 0x40
0000782c7ffd6fc3  vmovaps xmm0, [rsp]
0000782c7ffd6fc8  vmovaps xmm1, [rsp+0x10]
0000782c7ffd6fce  vmovaps xmm2, [rsp+0x20]
0000782c7ffd6fd4  vmovaps xmm3, [rsp+0x30]
0000782c7ffd6fda  vmovaps xmm4, [rsp+0x40]
0000782c7ffd6fe0  vmovaps xmm5, [rsp+0x50]
0000782c7ffd6fe6  vmovaps xmm6, [rsp+0x60]
0000782c7ffd6fec  vmovaps xmm7, [rsp+0x70]
0000782c7ffd6ff2  vmovaps xmm8, [rsp+0x80]
0000782c7ffd6ffb  vmovaps xmm9, [rsp+0x90]
0000782c7ffd7004  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd700d  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd7016  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd701f  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd7028  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd7031  add rsp, 0xF0
0000782c7ffd7038  pop r11
0000782c7ffd703a  pop r10
0000782c7ffd703c  pop r9
0000782c7ffd703e  pop r8
0000782c7ffd7040  pop rsi
0000782c7ffd7041  pop rdi
0000782c7ffd7042  pop rdx
0000782c7ffd7043  pop rcx
0000782c7ffd7044  pop rax
0000782c7ffd7045  add rsp, 0x08
0000782c7ffd7049  jmp 0x0000782C7FFD6333
0000782c7ffd704e  call 0x0000782C7FED64F0
0000782c7ffd7053  jmp 0x0000782C7FFD641F
0000782c7ffd7058  sub rsp, 0x08
0000782c7ffd705c  push rax
0000782c7ffd705d  push rcx
0000782c7ffd705e  push rdx
0000782c7ffd705f  push rdi
0000782c7ffd7060  push rsi
0000782c7ffd7061  push r8
0000782c7ffd7063  push r9
0000782c7ffd7065  push r10
0000782c7ffd7067  push r11
0000782c7ffd7069  sub rsp, 0xF0
0000782c7ffd7070  vmovaps [rsp], xmm0
0000782c7ffd7075  vmovaps [rsp+0x10], xmm1
0000782c7ffd707b  vmovaps [rsp+0x20], xmm2
0000782c7ffd7081  vmovaps [rsp+0x30], xmm3
0000782c7ffd7087  vmovaps [rsp+0x40], xmm4
0000782c7ffd708d  vmovaps [rsp+0x50], xmm5
0000782c7ffd7093  vmovaps [rsp+0x60], xmm6
0000782c7ffd7099  vmovaps [rsp+0x70], xmm7
0000782c7ffd709f  vmovaps [rsp+0x80], xmm8
0000782c7ffd70a8  vmovaps [rsp+0x90], xmm9
0000782c7ffd70b1  vmovaps [rsp+0xA0], xmm10
0000782c7ffd70ba  vmovaps [rsp+0xB0], xmm11
0000782c7ffd70c3  vmovaps [rsp+0xC0], xmm12
0000782c7ffd70cc  vmovaps [rsp+0xD0], xmm14
0000782c7ffd70d5  vmovaps [rsp+0xE0], xmm15
0000782c7ffd70de  sub rsp, 0x40
0000782c7ffd70e2  lea rdi, [rsp]
0000782c7ffd70e6  lea rsi, [rsp+0x10]
0000782c7ffd70eb  lea rdx, [rsp+0x20]
0000782c7ffd70f0  lea rcx, [rsp+0x30]
0000782c7ffd70f5  mov r8d, 0x00
0000782c7ffd70fb  lea r9, [r15+0x3A8]
0000782c7ffd7102  movaps [rdi], xmm13
0000782c7ffd7106  movaps [rsi], xmm1
0000782c7ffd7109  movaps [rdx], xmm15
0000782c7ffd710d  movaps [rcx], xmm14
0000782c7ffd7111  mov rax, 0x5AE5BFFB5A50
0000782c7ffd711b  call rax
0000782c7ffd711d  movaps xmm13, [rsp]
0000782c7ffd7122  add rsp, 0x40
0000782c7ffd7126  vmovaps xmm0, [rsp]
0000782c7ffd712b  vmovaps xmm1, [rsp+0x10]
0000782c7ffd7131  vmovaps xmm2, [rsp+0x20]
0000782c7ffd7137  vmovaps xmm3, [rsp+0x30]
0000782c7ffd713d  vmovaps xmm4, [rsp+0x40]
0000782c7ffd7143  vmovaps xmm5, [rsp+0x50]
0000782c7ffd7149  vmovaps xmm6, [rsp+0x60]
0000782c7ffd714f  vmovaps xmm7, [rsp+0x70]
0000782c7ffd7155  vmovaps xmm8, [rsp+0x80]
0000782c7ffd715e  vmovaps xmm9, [rsp+0x90]
0000782c7ffd7167  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd7170  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd7179  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd7182  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd718b  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd7194  add rsp, 0xF0
0000782c7ffd719b  pop r11
0000782c7ffd719d  pop r10
0000782c7ffd719f  pop r9
0000782c7ffd71a1  pop r8
0000782c7ffd71a3  pop rsi
0000782c7ffd71a4  pop rdi
0000782c7ffd71a5  pop rdx
0000782c7ffd71a6  pop rcx
0000782c7ffd71a7  pop rax
0000782c7ffd71a8  add rsp, 0x08
0000782c7ffd71ac  jmp 0x0000782C7FFD648E
0000782c7ffd71b1  call 0x0000782C7FED64F0
0000782c7ffd71b6  jmp 0x0000782C7FFD64A3
0000782c7ffd71bb  sub rsp, 0x08
0000782c7ffd71bf  push rax
0000782c7ffd71c0  push rcx
0000782c7ffd71c1  push rdx
0000782c7ffd71c2  push rdi
0000782c7ffd71c3  push rsi
0000782c7ffd71c4  push r8
0000782c7ffd71c6  push r9
0000782c7ffd71c8  push r10
0000782c7ffd71ca  push r11
0000782c7ffd71cc  sub rsp, 0xF0
0000782c7ffd71d3  vmovaps [rsp], xmm0
0000782c7ffd71d8  vmovaps [rsp+0x10], xmm1
0000782c7ffd71de  vmovaps [rsp+0x20], xmm2
0000782c7ffd71e4  vmovaps [rsp+0x30], xmm3
0000782c7ffd71ea  vmovaps [rsp+0x40], xmm4
0000782c7ffd71f0  vmovaps [rsp+0x50], xmm5
0000782c7ffd71f6  vmovaps [rsp+0x60], xmm6
0000782c7ffd71fc  vmovaps [rsp+0x70], xmm7
0000782c7ffd7202  vmovaps [rsp+0x80], xmm8
0000782c7ffd720b  vmovaps [rsp+0x90], xmm9
0000782c7ffd7214  vmovaps [rsp+0xA0], xmm10
0000782c7ffd721d  vmovaps [rsp+0xB0], xmm11
0000782c7ffd7226  vmovaps [rsp+0xC0], xmm13
0000782c7ffd722f  vmovaps [rsp+0xD0], xmm14
0000782c7ffd7238  vmovaps [rsp+0xE0], xmm15
0000782c7ffd7241  sub rsp, 0x40
0000782c7ffd7245  lea rdi, [rsp]
0000782c7ffd7249  lea rsi, [rsp+0x10]
0000782c7ffd724e  lea rdx, [rsp+0x20]
0000782c7ffd7253  lea rcx, [rsp+0x30]
0000782c7ffd7258  mov r8d, 0x00
0000782c7ffd725e  lea r9, [r15+0x3A8]
0000782c7ffd7265  movaps [rdi], xmm12
0000782c7ffd7269  movaps [rsi], xmm15
0000782c7ffd726d  movaps [rdx], xmm1
0000782c7ffd7270  movaps [rcx], xmm14
0000782c7ffd7274  mov rax, 0x5AE5BFFB5A50
0000782c7ffd727e  call rax
0000782c7ffd7280  movaps xmm12, [rsp]
0000782c7ffd7285  add rsp, 0x40
0000782c7ffd7289  vmovaps xmm0, [rsp]
0000782c7ffd728e  vmovaps xmm1, [rsp+0x10]
0000782c7ffd7294  vmovaps xmm2, [rsp+0x20]
0000782c7ffd729a  vmovaps xmm3, [rsp+0x30]
0000782c7ffd72a0  vmovaps xmm4, [rsp+0x40]
0000782c7ffd72a6  vmovaps xmm5, [rsp+0x50]
0000782c7ffd72ac  vmovaps xmm6, [rsp+0x60]
0000782c7ffd72b2  vmovaps xmm7, [rsp+0x70]
0000782c7ffd72b8  vmovaps xmm8, [rsp+0x80]
0000782c7ffd72c1  vmovaps xmm9, [rsp+0x90]
0000782c7ffd72ca  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd72d3  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd72dc  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd72e5  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd72ee  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd72f7  add rsp, 0xF0
0000782c7ffd72fe  pop r11
0000782c7ffd7300  pop r10
0000782c7ffd7302  pop r9
0000782c7ffd7304  pop r8
0000782c7ffd7306  pop rsi
0000782c7ffd7307  pop rdi
0000782c7ffd7308  pop rdx
0000782c7ffd7309  pop rcx
0000782c7ffd730a  pop rax
0000782c7ffd730b  add rsp, 0x08
0000782c7ffd730f  jmp 0x0000782C7FFD64CF
0000782c7ffd7314  sub rsp, 0x08
0000782c7ffd7318  push rax
0000782c7ffd7319  push rcx
0000782c7ffd731a  push rdx
0000782c7ffd731b  push rdi
0000782c7ffd731c  push rsi
0000782c7ffd731d  push r8
0000782c7ffd731f  push r9
0000782c7ffd7321  push r10
0000782c7ffd7323  push r11
0000782c7ffd7325  sub rsp, 0xF0
0000782c7ffd732c  vmovaps [rsp], xmm0
0000782c7ffd7331  vmovaps [rsp+0x10], xmm1
0000782c7ffd7337  vmovaps [rsp+0x20], xmm2
0000782c7ffd733d  vmovaps [rsp+0x30], xmm3
0000782c7ffd7343  vmovaps [rsp+0x40], xmm4
0000782c7ffd7349  vmovaps [rsp+0x50], xmm5
0000782c7ffd734f  vmovaps [rsp+0x60], xmm6
0000782c7ffd7355  vmovaps [rsp+0x70], xmm7
0000782c7ffd735b  vmovaps [rsp+0x80], xmm8
0000782c7ffd7364  vmovaps [rsp+0x90], xmm9
0000782c7ffd736d  vmovaps [rsp+0xA0], xmm10
0000782c7ffd7376  vmovaps [rsp+0xB0], xmm11
0000782c7ffd737f  vmovaps [rsp+0xC0], xmm12
0000782c7ffd7388  vmovaps [rsp+0xD0], xmm14
0000782c7ffd7391  vmovaps [rsp+0xE0], xmm15
0000782c7ffd739a  sub rsp, 0x40
0000782c7ffd739e  lea rdi, [rsp]
0000782c7ffd73a2  lea rsi, [rsp+0x10]
0000782c7ffd73a7  lea rdx, [rsp+0x20]
0000782c7ffd73ac  lea rcx, [rsp+0x30]
0000782c7ffd73b1  mov r8d, 0x00
0000782c7ffd73b7  lea r9, [r15+0x3A8]
0000782c7ffd73be  movaps [rdi], xmm13
0000782c7ffd73c2  movaps [rsi], xmm1
0000782c7ffd73c5  movaps [rdx], xmm15
0000782c7ffd73c9  movaps [rcx], xmm14
0000782c7ffd73cd  mov rax, 0x5AE5BFFB5A50
0000782c7ffd73d7  call rax
0000782c7ffd73d9  movaps xmm13, [rsp]
0000782c7ffd73de  add rsp, 0x40
0000782c7ffd73e2  vmovaps xmm0, [rsp]
0000782c7ffd73e7  vmovaps xmm1, [rsp+0x10]
0000782c7ffd73ed  vmovaps xmm2, [rsp+0x20]
0000782c7ffd73f3  vmovaps xmm3, [rsp+0x30]
0000782c7ffd73f9  vmovaps xmm4, [rsp+0x40]
0000782c7ffd73ff  vmovaps xmm5, [rsp+0x50]
0000782c7ffd7405  vmovaps xmm6, [rsp+0x60]
0000782c7ffd740b  vmovaps xmm7, [rsp+0x70]
0000782c7ffd7411  vmovaps xmm8, [rsp+0x80]
0000782c7ffd741a  vmovaps xmm9, [rsp+0x90]
0000782c7ffd7423  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd742c  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd7435  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd743e  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd7447  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd7450  add rsp, 0xF0
0000782c7ffd7457  pop r11
0000782c7ffd7459  pop r10
0000782c7ffd745b  pop r9
0000782c7ffd745d  pop r8
0000782c7ffd745f  pop rsi
0000782c7ffd7460  pop rdi
0000782c7ffd7461  pop rdx
0000782c7ffd7462  pop rcx
0000782c7ffd7463  pop rax
0000782c7ffd7464  add rsp, 0x08
0000782c7ffd7468  jmp 0x0000782C7FFD665F
0000782c7ffd746d  sub rsp, 0x08
0000782c7ffd7471  push rax
0000782c7ffd7472  push rcx
0000782c7ffd7473  push rdx
0000782c7ffd7474  push rdi
0000782c7ffd7475  push rsi
0000782c7ffd7476  push r8
0000782c7ffd7478  push r9
0000782c7ffd747a  push r10
0000782c7ffd747c  push r11
0000782c7ffd747e  sub rsp, 0xF0
0000782c7ffd7485  vmovaps [rsp], xmm0
0000782c7ffd748a  vmovaps [rsp+0x10], xmm1
0000782c7ffd7490  vmovaps [rsp+0x20], xmm2
0000782c7ffd7496  vmovaps [rsp+0x30], xmm3
0000782c7ffd749c  vmovaps [rsp+0x40], xmm4
0000782c7ffd74a2  vmovaps [rsp+0x50], xmm5
0000782c7ffd74a8  vmovaps [rsp+0x60], xmm6
0000782c7ffd74ae  vmovaps [rsp+0x70], xmm7
0000782c7ffd74b4  vmovaps [rsp+0x80], xmm8
0000782c7ffd74bd  vmovaps [rsp+0x90], xmm9
0000782c7ffd74c6  vmovaps [rsp+0xA0], xmm10
0000782c7ffd74cf  vmovaps [rsp+0xB0], xmm11
0000782c7ffd74d8  vmovaps [rsp+0xC0], xmm12
0000782c7ffd74e1  vmovaps [rsp+0xD0], xmm13
0000782c7ffd74ea  vmovaps [rsp+0xE0], xmm15
0000782c7ffd74f3  sub rsp, 0x40
0000782c7ffd74f7  lea rdi, [rsp]
0000782c7ffd74fb  lea rsi, [rsp+0x10]
0000782c7ffd7500  lea rdx, [rsp+0x20]
0000782c7ffd7505  lea rcx, [rsp+0x30]
0000782c7ffd750a  mov r8d, 0x00
0000782c7ffd7510  lea r9, [r15+0x3A8]
0000782c7ffd7517  movaps [rdi], xmm14
0000782c7ffd751b  movaps [rsi], xmm15
0000782c7ffd751f  movaps [rdx], xmm2
0000782c7ffd7522  movaps [rcx], xmm1
0000782c7ffd7525  mov rax, 0x5AE5BFFB5A50
0000782c7ffd752f  call rax
0000782c7ffd7531  movaps xmm14, [rsp]
0000782c7ffd7536  add rsp, 0x40
0000782c7ffd753a  vmovaps xmm0, [rsp]
0000782c7ffd753f  vmovaps xmm1, [rsp+0x10]
0000782c7ffd7545  vmovaps xmm2, [rsp+0x20]
0000782c7ffd754b  vmovaps xmm3, [rsp+0x30]
0000782c7ffd7551  vmovaps xmm4, [rsp+0x40]
0000782c7ffd7557  vmovaps xmm5, [rsp+0x50]
0000782c7ffd755d  vmovaps xmm6, [rsp+0x60]
0000782c7ffd7563  vmovaps xmm7, [rsp+0x70]
0000782c7ffd7569  vmovaps xmm8, [rsp+0x80]
0000782c7ffd7572  vmovaps xmm9, [rsp+0x90]
0000782c7ffd757b  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd7584  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd758d  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd7596  vmovaps xmm13, [rsp+0xD0]
0000782c7ffd759f  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd75a8  add rsp, 0xF0
0000782c7ffd75af  pop r11
0000782c7ffd75b1  pop r10
0000782c7ffd75b3  pop r9
0000782c7ffd75b5  pop r8
0000782c7ffd75b7  pop rsi
0000782c7ffd75b8  pop rdi
0000782c7ffd75b9  pop rdx
0000782c7ffd75ba  pop rcx
0000782c7ffd75bb  pop rax
0000782c7ffd75bc  add rsp, 0x08
0000782c7ffd75c0  jmp 0x0000782C7FFD6691
0000782c7ffd75c5  sub rsp, 0x08
0000782c7ffd75c9  push rax
0000782c7ffd75ca  push rcx
0000782c7ffd75cb  push rdx
0000782c7ffd75cc  push rdi
0000782c7ffd75cd  push rsi
0000782c7ffd75ce  push r8
0000782c7ffd75d0  push r9
0000782c7ffd75d2  push r10
0000782c7ffd75d4  push r11
0000782c7ffd75d6  sub rsp, 0xF0
0000782c7ffd75dd  vmovaps [rsp], xmm0
0000782c7ffd75e2  vmovaps [rsp+0x10], xmm1
0000782c7ffd75e8  vmovaps [rsp+0x20], xmm3
0000782c7ffd75ee  vmovaps [rsp+0x30], xmm4
0000782c7ffd75f4  vmovaps [rsp+0x40], xmm5
0000782c7ffd75fa  vmovaps [rsp+0x50], xmm6
0000782c7ffd7600  vmovaps [rsp+0x60], xmm7
0000782c7ffd7606  vmovaps [rsp+0x70], xmm8
0000782c7ffd760c  vmovaps [rsp+0x80], xmm9
0000782c7ffd7615  vmovaps [rsp+0x90], xmm10
0000782c7ffd761e  vmovaps [rsp+0xA0], xmm11
0000782c7ffd7627  vmovaps [rsp+0xB0], xmm12
0000782c7ffd7630  vmovaps [rsp+0xC0], xmm13
0000782c7ffd7639  vmovaps [rsp+0xD0], xmm14
0000782c7ffd7642  vmovaps [rsp+0xE0], xmm15
0000782c7ffd764b  sub rsp, 0x40
0000782c7ffd764f  lea rdi, [rsp]
0000782c7ffd7653  lea rsi, [rsp+0x10]
0000782c7ffd7658  lea rdx, [rsp+0x20]
0000782c7ffd765d  lea rcx, [rsp+0x30]
0000782c7ffd7662  mov r8d, 0x00
0000782c7ffd7668  lea r9, [r15+0x3A8]
0000782c7ffd766f  movaps [rdi], xmm2
0000782c7ffd7672  movaps [rsi], xmm15
0000782c7ffd7676  movaps [rdx], xmm12
0000782c7ffd767a  movaps [rcx], xmm1
0000782c7ffd767d  mov rax, 0x5AE5BFFB5A50
0000782c7ffd7687  call rax
0000782c7ffd7689  movaps xmm2, [rsp]
0000782c7ffd768d  add rsp, 0x40
0000782c7ffd7691  vmovaps xmm0, [rsp]
0000782c7ffd7696  vmovaps xmm1, [rsp+0x10]
0000782c7ffd769c  vmovaps xmm3, [rsp+0x20]
0000782c7ffd76a2  vmovaps xmm4, [rsp+0x30]
0000782c7ffd76a8  vmovaps xmm5, [rsp+0x40]
0000782c7ffd76ae  vmovaps xmm6, [rsp+0x50]
0000782c7ffd76b4  vmovaps xmm7, [rsp+0x60]
0000782c7ffd76ba  vmovaps xmm8, [rsp+0x70]
0000782c7ffd76c0  vmovaps xmm9, [rsp+0x80]
0000782c7ffd76c9  vmovaps xmm10, [rsp+0x90]
0000782c7ffd76d2  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd76db  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd76e4  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd76ed  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd76f6  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd76ff  add rsp, 0xF0
0000782c7ffd7706  pop r11
0000782c7ffd7708  pop r10
0000782c7ffd770a  pop r9
0000782c7ffd770c  pop r8
0000782c7ffd770e  pop rsi
0000782c7ffd770f  pop rdi
0000782c7ffd7710  pop rdx
0000782c7ffd7711  pop rcx
0000782c7ffd7712  pop rax
0000782c7ffd7713  add rsp, 0x08
0000782c7ffd7717  jmp 0x0000782C7FFD66CE
0000782c7ffd771c  sub rsp, 0x08
0000782c7ffd7720  push rax
0000782c7ffd7721  push rcx
0000782c7ffd7722  push rdx
0000782c7ffd7723  push rdi
0000782c7ffd7724  push rsi
0000782c7ffd7725  push r8
0000782c7ffd7727  push r9
0000782c7ffd7729  push r10
0000782c7ffd772b  push r11
0000782c7ffd772d  sub rsp, 0xF0
0000782c7ffd7734  vmovaps [rsp], xmm0
0000782c7ffd7739  vmovaps [rsp+0x10], xmm1
0000782c7ffd773f  vmovaps [rsp+0x20], xmm2
0000782c7ffd7745  vmovaps [rsp+0x30], xmm3
0000782c7ffd774b  vmovaps [rsp+0x40], xmm4
0000782c7ffd7751  vmovaps [rsp+0x50], xmm5
0000782c7ffd7757  vmovaps [rsp+0x60], xmm6
0000782c7ffd775d  vmovaps [rsp+0x70], xmm7
0000782c7ffd7763  vmovaps [rsp+0x80], xmm8
0000782c7ffd776c  vmovaps [rsp+0x90], xmm9
0000782c7ffd7775  vmovaps [rsp+0xA0], xmm10
0000782c7ffd777e  vmovaps [rsp+0xB0], xmm11
0000782c7ffd7787  vmovaps [rsp+0xC0], xmm13
0000782c7ffd7790  vmovaps [rsp+0xD0], xmm14
0000782c7ffd7799  vmovaps [rsp+0xE0], xmm15
0000782c7ffd77a2  sub rsp, 0x40
0000782c7ffd77a6  lea rdi, [rsp]
0000782c7ffd77aa  lea rsi, [rsp+0x10]
0000782c7ffd77af  lea rdx, [rsp+0x20]
0000782c7ffd77b4  lea rcx, [rsp+0x30]
0000782c7ffd77b9  mov r8d, 0x00
0000782c7ffd77bf  lea r9, [r15+0x3A8]
0000782c7ffd77c6  movaps [rdi], xmm12
0000782c7ffd77ca  movaps [rsi], xmm14
0000782c7ffd77ce  movaps [rdx], xmm3
0000782c7ffd77d1  movaps [rcx], xmm15
0000782c7ffd77d5  mov rax, 0x5AE5BFFB5A50
0000782c7ffd77df  call rax
0000782c7ffd77e1  movaps xmm12, [rsp]
0000782c7ffd77e6  add rsp, 0x40
0000782c7ffd77ea  vmovaps xmm0, [rsp]
0000782c7ffd77ef  vmovaps xmm1, [rsp+0x10]
0000782c7ffd77f5  vmovaps xmm2, [rsp+0x20]
0000782c7ffd77fb  vmovaps xmm3, [rsp+0x30]
0000782c7ffd7801  vmovaps xmm4, [rsp+0x40]
0000782c7ffd7807  vmovaps xmm5, [rsp+0x50]
0000782c7ffd780d  vmovaps xmm6, [rsp+0x60]
0000782c7ffd7813  vmovaps xmm7, [rsp+0x70]
0000782c7ffd7819  vmovaps xmm8, [rsp+0x80]
0000782c7ffd7822  vmovaps xmm9, [rsp+0x90]
0000782c7ffd782b  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd7834  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd783d  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd7846  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd784f  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd7858  add rsp, 0xF0
0000782c7ffd785f  pop r11
0000782c7ffd7861  pop r10
0000782c7ffd7863  pop r9
0000782c7ffd7865  pop r8
0000782c7ffd7867  pop rsi
0000782c7ffd7868  pop rdi
0000782c7ffd7869  pop rdx
0000782c7ffd786a  pop rcx
0000782c7ffd786b  pop rax
0000782c7ffd786c  add rsp, 0x08
0000782c7ffd7870  jmp 0x0000782C7FFD6728
0000782c7ffd7875  sub rsp, 0x08
0000782c7ffd7879  push rax
0000782c7ffd787a  push rcx
0000782c7ffd787b  push rdx
0000782c7ffd787c  push rdi
0000782c7ffd787d  push rsi
0000782c7ffd787e  push r8
0000782c7ffd7880  push r9
0000782c7ffd7882  push r10
0000782c7ffd7884  push r11
0000782c7ffd7886  sub rsp, 0xF0
0000782c7ffd788d  vmovaps [rsp], xmm0
0000782c7ffd7892  vmovaps [rsp+0x10], xmm1
0000782c7ffd7898  vmovaps [rsp+0x20], xmm2
0000782c7ffd789e  vmovaps [rsp+0x30], xmm3
0000782c7ffd78a4  vmovaps [rsp+0x40], xmm4
0000782c7ffd78aa  vmovaps [rsp+0x50], xmm5
0000782c7ffd78b0  vmovaps [rsp+0x60], xmm6
0000782c7ffd78b6  vmovaps [rsp+0x70], xmm7
0000782c7ffd78bc  vmovaps [rsp+0x80], xmm8
0000782c7ffd78c5  vmovaps [rsp+0x90], xmm10
0000782c7ffd78ce  vmovaps [rsp+0xA0], xmm11
0000782c7ffd78d7  vmovaps [rsp+0xB0], xmm12
0000782c7ffd78e0  vmovaps [rsp+0xC0], xmm13
0000782c7ffd78e9  vmovaps [rsp+0xD0], xmm14
0000782c7ffd78f2  vmovaps [rsp+0xE0], xmm15
0000782c7ffd78fb  sub rsp, 0x40
0000782c7ffd78ff  lea rdi, [rsp]
0000782c7ffd7903  lea rsi, [rsp+0x10]
0000782c7ffd7908  lea rdx, [rsp+0x20]
0000782c7ffd790d  lea rcx, [rsp+0x30]
0000782c7ffd7912  mov r8d, 0x00
0000782c7ffd7918  lea r9, [r15+0x3A8]
0000782c7ffd791f  movaps [rdi], xmm9
0000782c7ffd7923  movaps [rsi], xmm13
0000782c7ffd7927  movaps [rdx], xmm14
0000782c7ffd792b  movaps [rcx], xmm6
0000782c7ffd792e  mov rax, 0x5AE5BFFB5A50
0000782c7ffd7938  call rax
0000782c7ffd793a  movaps xmm9, [rsp]
0000782c7ffd793f  add rsp, 0x40
0000782c7ffd7943  vmovaps xmm0, [rsp]
0000782c7ffd7948  vmovaps xmm1, [rsp+0x10]
0000782c7ffd794e  vmovaps xmm2, [rsp+0x20]
0000782c7ffd7954  vmovaps xmm3, [rsp+0x30]
0000782c7ffd795a  vmovaps xmm4, [rsp+0x40]
0000782c7ffd7960  vmovaps xmm5, [rsp+0x50]
0000782c7ffd7966  vmovaps xmm6, [rsp+0x60]
0000782c7ffd796c  vmovaps xmm7, [rsp+0x70]
0000782c7ffd7972  vmovaps xmm8, [rsp+0x80]
0000782c7ffd797b  vmovaps xmm10, [rsp+0x90]
0000782c7ffd7984  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd798d  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd7996  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd799f  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd79a8  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd79b1  add rsp, 0xF0
0000782c7ffd79b8  pop r11
0000782c7ffd79ba  pop r10
0000782c7ffd79bc  pop r9
0000782c7ffd79be  pop r8
0000782c7ffd79c0  pop rsi
0000782c7ffd79c1  pop rdi
0000782c7ffd79c2  pop rdx
0000782c7ffd79c3  pop rcx
0000782c7ffd79c4  pop rax
0000782c7ffd79c5  add rsp, 0x08
0000782c7ffd79c9  jmp 0x0000782C7FFD67D2
0000782c7ffd79ce  sub rsp, 0x08
0000782c7ffd79d2  push rax
0000782c7ffd79d3  push rcx
0000782c7ffd79d4  push rdx
0000782c7ffd79d5  push rdi
0000782c7ffd79d6  push rsi
0000782c7ffd79d7  push r8
0000782c7ffd79d9  push r9
0000782c7ffd79db  push r10
0000782c7ffd79dd  push r11
0000782c7ffd79df  sub rsp, 0xF0
0000782c7ffd79e6  vmovaps [rsp], xmm0
0000782c7ffd79eb  vmovaps [rsp+0x10], xmm1
0000782c7ffd79f1  vmovaps [rsp+0x20], xmm2
0000782c7ffd79f7  vmovaps [rsp+0x30], xmm4
0000782c7ffd79fd  vmovaps [rsp+0x40], xmm5
0000782c7ffd7a03  vmovaps [rsp+0x50], xmm6
0000782c7ffd7a09  vmovaps [rsp+0x60], xmm7
0000782c7ffd7a0f  vmovaps [rsp+0x70], xmm8
0000782c7ffd7a15  vmovaps [rsp+0x80], xmm9
0000782c7ffd7a1e  vmovaps [rsp+0x90], xmm10
0000782c7ffd7a27  vmovaps [rsp+0xA0], xmm11
0000782c7ffd7a30  vmovaps [rsp+0xB0], xmm12
0000782c7ffd7a39  vmovaps [rsp+0xC0], xmm13
0000782c7ffd7a42  vmovaps [rsp+0xD0], xmm14
0000782c7ffd7a4b  vmovaps [rsp+0xE0], xmm15
0000782c7ffd7a54  sub rsp, 0x40
0000782c7ffd7a58  lea rdi, [rsp]
0000782c7ffd7a5c  lea rsi, [rsp+0x10]
0000782c7ffd7a61  lea rdx, [rsp+0x20]
0000782c7ffd7a66  lea rcx, [rsp+0x30]
0000782c7ffd7a6b  mov r8d, 0x00
0000782c7ffd7a71  lea r9, [r15+0x3A8]
0000782c7ffd7a78  movaps [rdi], xmm3
0000782c7ffd7a7b  movaps [rsi], xmm13
0000782c7ffd7a7f  movaps [rdx], xmm6
0000782c7ffd7a82  movaps [rcx], xmm14
0000782c7ffd7a86  mov rax, 0x5AE5BFFB5A50
0000782c7ffd7a90  call rax
0000782c7ffd7a92  movaps xmm3, [rsp]
0000782c7ffd7a96  add rsp, 0x40
0000782c7ffd7a9a  vmovaps xmm0, [rsp]
0000782c7ffd7a9f  vmovaps xmm1, [rsp+0x10]
0000782c7ffd7aa5  vmovaps xmm2, [rsp+0x20]
0000782c7ffd7aab  vmovaps xmm4, [rsp+0x30]
0000782c7ffd7ab1  vmovaps xmm5, [rsp+0x40]
0000782c7ffd7ab7  vmovaps xmm6, [rsp+0x50]
0000782c7ffd7abd  vmovaps xmm7, [rsp+0x60]
0000782c7ffd7ac3  vmovaps xmm8, [rsp+0x70]
0000782c7ffd7ac9  vmovaps xmm9, [rsp+0x80]
0000782c7ffd7ad2  vmovaps xmm10, [rsp+0x90]
0000782c7ffd7adb  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd7ae4  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd7aed  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd7af6  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd7aff  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd7b08  add rsp, 0xF0
0000782c7ffd7b0f  pop r11
0000782c7ffd7b11  pop r10
0000782c7ffd7b13  pop r9
0000782c7ffd7b15  pop r8
0000782c7ffd7b17  pop rsi
0000782c7ffd7b18  pop rdi
0000782c7ffd7b19  pop rdx
0000782c7ffd7b1a  pop rcx
0000782c7ffd7b1b  pop rax
0000782c7ffd7b1c  add rsp, 0x08
0000782c7ffd7b20  jmp 0x0000782C7FFD680F
0000782c7ffd7b25  sub rsp, 0x08
0000782c7ffd7b29  push rax
0000782c7ffd7b2a  push rcx
0000782c7ffd7b2b  push rdx
0000782c7ffd7b2c  push rdi
0000782c7ffd7b2d  push rsi
0000782c7ffd7b2e  push r8
0000782c7ffd7b30  push r9
0000782c7ffd7b32  push r10
0000782c7ffd7b34  push r11
0000782c7ffd7b36  sub rsp, 0xF0
0000782c7ffd7b3d  vmovaps [rsp], xmm0
0000782c7ffd7b42  vmovaps [rsp+0x10], xmm1
0000782c7ffd7b48  vmovaps [rsp+0x20], xmm2
0000782c7ffd7b4e  vmovaps [rsp+0x30], xmm3
0000782c7ffd7b54  vmovaps [rsp+0x40], xmm4
0000782c7ffd7b5a  vmovaps [rsp+0x50], xmm5
0000782c7ffd7b60  vmovaps [rsp+0x60], xmm7
0000782c7ffd7b66  vmovaps [rsp+0x70], xmm8
0000782c7ffd7b6c  vmovaps [rsp+0x80], xmm9
0000782c7ffd7b75  vmovaps [rsp+0x90], xmm10
0000782c7ffd7b7e  vmovaps [rsp+0xA0], xmm11
0000782c7ffd7b87  vmovaps [rsp+0xB0], xmm12
0000782c7ffd7b90  vmovaps [rsp+0xC0], xmm13
0000782c7ffd7b99  vmovaps [rsp+0xD0], xmm14
0000782c7ffd7ba2  vmovaps [rsp+0xE0], xmm15
0000782c7ffd7bab  sub rsp, 0x40
0000782c7ffd7baf  lea rdi, [rsp]
0000782c7ffd7bb3  lea rsi, [rsp+0x10]
0000782c7ffd7bb8  lea rdx, [rsp+0x20]
0000782c7ffd7bbd  lea rcx, [rsp+0x30]
0000782c7ffd7bc2  mov r8d, 0x00
0000782c7ffd7bc8  lea r9, [r15+0x3A8]
0000782c7ffd7bcf  movaps [rdi], xmm6
0000782c7ffd7bd2  movaps [rsi], xmm2
0000782c7ffd7bd5  movaps [rdx], xmm14
0000782c7ffd7bd9  movaps [rcx], xmm1
0000782c7ffd7bdc  mov rax, 0x5AE5BFFB5A50
0000782c7ffd7be6  call rax
0000782c7ffd7be8  movaps xmm6, [rsp]
0000782c7ffd7bec  add rsp, 0x40
0000782c7ffd7bf0  vmovaps xmm0, [rsp]
0000782c7ffd7bf5  vmovaps xmm1, [rsp+0x10]
0000782c7ffd7bfb  vmovaps xmm2, [rsp+0x20]
0000782c7ffd7c01  vmovaps xmm3, [rsp+0x30]
0000782c7ffd7c07  vmovaps xmm4, [rsp+0x40]
0000782c7ffd7c0d  vmovaps xmm5, [rsp+0x50]
0000782c7ffd7c13  vmovaps xmm7, [rsp+0x60]
0000782c7ffd7c19  vmovaps xmm8, [rsp+0x70]
0000782c7ffd7c1f  vmovaps xmm9, [rsp+0x80]
0000782c7ffd7c28  vmovaps xmm10, [rsp+0x90]
0000782c7ffd7c31  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd7c3a  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd7c43  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd7c4c  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd7c55  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd7c5e  add rsp, 0xF0
0000782c7ffd7c65  pop r11
0000782c7ffd7c67  pop r10
0000782c7ffd7c69  pop r9
0000782c7ffd7c6b  pop r8
0000782c7ffd7c6d  pop rsi
0000782c7ffd7c6e  pop rdi
0000782c7ffd7c6f  pop rdx
0000782c7ffd7c70  pop rcx
0000782c7ffd7c71  pop rax
0000782c7ffd7c72  add rsp, 0x08
0000782c7ffd7c76  jmp 0x0000782C7FFD683C
0000782c7ffd7c7b  sub rsp, 0x08
0000782c7ffd7c7f  push rax
0000782c7ffd7c80  push rcx
0000782c7ffd7c81  push rdx
0000782c7ffd7c82  push rdi
0000782c7ffd7c83  push rsi
0000782c7ffd7c84  push r8
0000782c7ffd7c86  push r9
0000782c7ffd7c88  push r10
0000782c7ffd7c8a  push r11
0000782c7ffd7c8c  sub rsp, 0xF0
0000782c7ffd7c93  vmovaps [rsp], xmm0
0000782c7ffd7c98  vmovaps [rsp+0x10], xmm1
0000782c7ffd7c9e  vmovaps [rsp+0x20], xmm2
0000782c7ffd7ca4  vmovaps [rsp+0x30], xmm3
0000782c7ffd7caa  vmovaps [rsp+0x40], xmm4
0000782c7ffd7cb0  vmovaps [rsp+0x50], xmm5
0000782c7ffd7cb6  vmovaps [rsp+0x60], xmm6
0000782c7ffd7cbc  vmovaps [rsp+0x70], xmm7
0000782c7ffd7cc2  vmovaps [rsp+0x80], xmm8
0000782c7ffd7ccb  vmovaps [rsp+0x90], xmm9
0000782c7ffd7cd4  vmovaps [rsp+0xA0], xmm10
0000782c7ffd7cdd  vmovaps [rsp+0xB0], xmm11
0000782c7ffd7ce6  vmovaps [rsp+0xC0], xmm12
0000782c7ffd7cef  vmovaps [rsp+0xD0], xmm14
0000782c7ffd7cf8  vmovaps [rsp+0xE0], xmm15
0000782c7ffd7d01  sub rsp, 0x40
0000782c7ffd7d05  lea rdi, [rsp]
0000782c7ffd7d09  lea rsi, [rsp+0x10]
0000782c7ffd7d0e  lea rdx, [rsp+0x20]
0000782c7ffd7d13  lea rcx, [rsp+0x30]
0000782c7ffd7d18  mov r8d, 0x00
0000782c7ffd7d1e  lea r9, [r15+0x3A8]
0000782c7ffd7d25  movaps [rdi], xmm13
0000782c7ffd7d29  movaps [rsi], xmm12
0000782c7ffd7d2d  movaps [rdx], xmm14
0000782c7ffd7d31  movaps [rcx], xmm1
0000782c7ffd7d34  mov rax, 0x5AE5BFFB5A50
0000782c7ffd7d3e  call rax
0000782c7ffd7d40  movaps xmm13, [rsp]
0000782c7ffd7d45  add rsp, 0x40
0000782c7ffd7d49  vmovaps xmm0, [rsp]
0000782c7ffd7d4e  vmovaps xmm1, [rsp+0x10]
0000782c7ffd7d54  vmovaps xmm2, [rsp+0x20]
0000782c7ffd7d5a  vmovaps xmm3, [rsp+0x30]
0000782c7ffd7d60  vmovaps xmm4, [rsp+0x40]
0000782c7ffd7d66  vmovaps xmm5, [rsp+0x50]
0000782c7ffd7d6c  vmovaps xmm6, [rsp+0x60]
0000782c7ffd7d72  vmovaps xmm7, [rsp+0x70]
0000782c7ffd7d78  vmovaps xmm8, [rsp+0x80]
0000782c7ffd7d81  vmovaps xmm9, [rsp+0x90]
0000782c7ffd7d8a  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd7d93  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd7d9c  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd7da5  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd7dae  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd7db7  add rsp, 0xF0
0000782c7ffd7dbe  pop r11
0000782c7ffd7dc0  pop r10
0000782c7ffd7dc2  pop r9
0000782c7ffd7dc4  pop r8
0000782c7ffd7dc6  pop rsi
0000782c7ffd7dc7  pop rdi
0000782c7ffd7dc8  pop rdx
0000782c7ffd7dc9  pop rcx
0000782c7ffd7dca  pop rax
0000782c7ffd7dcb  add rsp, 0x08
0000782c7ffd7dcf  jmp 0x0000782C7FFD686E
0000782c7ffd7dd4  sub rsp, 0x08
0000782c7ffd7dd8  push rax
0000782c7ffd7dd9  push rcx
0000782c7ffd7dda  push rdx
0000782c7ffd7ddb  push rdi
0000782c7ffd7ddc  push rsi
0000782c7ffd7ddd  push r8
0000782c7ffd7ddf  push r9
0000782c7ffd7de1  push r10
0000782c7ffd7de3  push r11
0000782c7ffd7de5  sub rsp, 0xF0
0000782c7ffd7dec  vmovaps [rsp], xmm0
0000782c7ffd7df1  vmovaps [rsp+0x10], xmm1
0000782c7ffd7df7  vmovaps [rsp+0x20], xmm2
0000782c7ffd7dfd  vmovaps [rsp+0x30], xmm3
0000782c7ffd7e03  vmovaps [rsp+0x40], xmm4
0000782c7ffd7e09  vmovaps [rsp+0x50], xmm5
0000782c7ffd7e0f  vmovaps [rsp+0x60], xmm6
0000782c7ffd7e15  vmovaps [rsp+0x70], xmm7
0000782c7ffd7e1b  vmovaps [rsp+0x80], xmm8
0000782c7ffd7e24  vmovaps [rsp+0x90], xmm9
0000782c7ffd7e2d  vmovaps [rsp+0xA0], xmm10
0000782c7ffd7e36  vmovaps [rsp+0xB0], xmm11
0000782c7ffd7e3f  vmovaps [rsp+0xC0], xmm13
0000782c7ffd7e48  vmovaps [rsp+0xD0], xmm14
0000782c7ffd7e51  vmovaps [rsp+0xE0], xmm15
0000782c7ffd7e5a  sub rsp, 0x40
0000782c7ffd7e5e  lea rdi, [rsp]
0000782c7ffd7e62  lea rsi, [rsp+0x10]
0000782c7ffd7e67  lea rdx, [rsp+0x20]
0000782c7ffd7e6c  lea rcx, [rsp+0x30]
0000782c7ffd7e71  mov r8d, 0x00
0000782c7ffd7e77  lea r9, [r15+0x3A8]
0000782c7ffd7e7e  movaps [rdi], xmm12
0000782c7ffd7e82  movaps [rsi], xmm3
0000782c7ffd7e85  movaps [rdx], xmm14
0000782c7ffd7e89  movaps [rcx], xmm5
0000782c7ffd7e8c  mov rax, 0x5AE5BFFB5A50
0000782c7ffd7e96  call rax
0000782c7ffd7e98  movaps xmm12, [rsp]
0000782c7ffd7e9d  add rsp, 0x40
0000782c7ffd7ea1  vmovaps xmm0, [rsp]
0000782c7ffd7ea6  vmovaps xmm1, [rsp+0x10]
0000782c7ffd7eac  vmovaps xmm2, [rsp+0x20]
0000782c7ffd7eb2  vmovaps xmm3, [rsp+0x30]
0000782c7ffd7eb8  vmovaps xmm4, [rsp+0x40]
0000782c7ffd7ebe  vmovaps xmm5, [rsp+0x50]
0000782c7ffd7ec4  vmovaps xmm6, [rsp+0x60]
0000782c7ffd7eca  vmovaps xmm7, [rsp+0x70]
0000782c7ffd7ed0  vmovaps xmm8, [rsp+0x80]
0000782c7ffd7ed9  vmovaps xmm9, [rsp+0x90]
0000782c7ffd7ee2  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd7eeb  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd7ef4  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd7efd  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd7f06  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd7f0f  add rsp, 0xF0
0000782c7ffd7f16  pop r11
0000782c7ffd7f18  pop r10
0000782c7ffd7f1a  pop r9
0000782c7ffd7f1c  pop r8
0000782c7ffd7f1e  pop rsi
0000782c7ffd7f1f  pop rdi
0000782c7ffd7f20  pop rdx
0000782c7ffd7f21  pop rcx
0000782c7ffd7f22  pop rax
0000782c7ffd7f23  add rsp, 0x08
0000782c7ffd7f27  jmp 0x0000782C7FFD68CB
0000782c7ffd7f2c  sub rsp, 0x08
0000782c7ffd7f30  push rax
0000782c7ffd7f31  push rcx
0000782c7ffd7f32  push rdx
0000782c7ffd7f33  push rdi
0000782c7ffd7f34  push rsi
0000782c7ffd7f35  push r8
0000782c7ffd7f37  push r9
0000782c7ffd7f39  push r10
0000782c7ffd7f3b  push r11
0000782c7ffd7f3d  sub rsp, 0xF0
0000782c7ffd7f44  vmovaps [rsp], xmm0
0000782c7ffd7f49  vmovaps [rsp+0x10], xmm1
0000782c7ffd7f4f  vmovaps [rsp+0x20], xmm2
0000782c7ffd7f55  vmovaps [rsp+0x30], xmm3
0000782c7ffd7f5b  vmovaps [rsp+0x40], xmm4
0000782c7ffd7f61  vmovaps [rsp+0x50], xmm5
0000782c7ffd7f67  vmovaps [rsp+0x60], xmm6
0000782c7ffd7f6d  vmovaps [rsp+0x70], xmm7
0000782c7ffd7f73  vmovaps [rsp+0x80], xmm8
0000782c7ffd7f7c  vmovaps [rsp+0x90], xmm9
0000782c7ffd7f85  vmovaps [rsp+0xA0], xmm11
0000782c7ffd7f8e  vmovaps [rsp+0xB0], xmm12
0000782c7ffd7f97  vmovaps [rsp+0xC0], xmm13
0000782c7ffd7fa0  vmovaps [rsp+0xD0], xmm14
0000782c7ffd7fa9  vmovaps [rsp+0xE0], xmm15
0000782c7ffd7fb2  sub rsp, 0x40
0000782c7ffd7fb6  lea rdi, [rsp]
0000782c7ffd7fba  lea rsi, [rsp+0x10]
0000782c7ffd7fbf  lea rdx, [rsp+0x20]
0000782c7ffd7fc4  lea rcx, [rsp+0x30]
0000782c7ffd7fc9  mov r8d, 0x00
0000782c7ffd7fcf  lea r9, [r15+0x3A8]
0000782c7ffd7fd6  movaps [rdi], xmm10
0000782c7ffd7fda  movaps [rsi], xmm9
0000782c7ffd7fde  movaps [rdx], xmm7
0000782c7ffd7fe1  movaps [rcx], xmm14
0000782c7ffd7fe5  mov rax, 0x5AE5BFFB5A50
0000782c7ffd7fef  call rax
0000782c7ffd7ff1  movaps xmm10, [rsp]
0000782c7ffd7ff6  add rsp, 0x40
0000782c7ffd7ffa  vmovaps xmm0, [rsp]
0000782c7ffd7fff  vmovaps xmm1, [rsp+0x10]
0000782c7ffd8005  vmovaps xmm2, [rsp+0x20]
0000782c7ffd800b  vmovaps xmm3, [rsp+0x30]
0000782c7ffd8011  vmovaps xmm4, [rsp+0x40]
0000782c7ffd8017  vmovaps xmm5, [rsp+0x50]
0000782c7ffd801d  vmovaps xmm6, [rsp+0x60]
0000782c7ffd8023  vmovaps xmm7, [rsp+0x70]
0000782c7ffd8029  vmovaps xmm8, [rsp+0x80]
0000782c7ffd8032  vmovaps xmm9, [rsp+0x90]
0000782c7ffd803b  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd8044  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd804d  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd8056  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd805f  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd8068  add rsp, 0xF0
0000782c7ffd806f  pop r11
0000782c7ffd8071  pop r10
0000782c7ffd8073  pop r9
0000782c7ffd8075  pop r8
0000782c7ffd8077  pop rsi
0000782c7ffd8078  pop rdi
0000782c7ffd8079  pop rdx
0000782c7ffd807a  pop rcx
0000782c7ffd807b  pop rax
0000782c7ffd807c  add rsp, 0x08
0000782c7ffd8080  jmp 0x0000782C7FFD68F1
0000782c7ffd8085  call 0x0000782C7FEE45A0
0000782c7ffd808a  jmp 0x0000782C7FFD68FE
0000782c7ffd808f  sub rsp, 0x08
0000782c7ffd8093  push rax
0000782c7ffd8094  push rcx
0000782c7ffd8095  push rdx
0000782c7ffd8096  push rdi
0000782c7ffd8097  push rsi
0000782c7ffd8098  push r8
0000782c7ffd809a  push r9
0000782c7ffd809c  push r10
0000782c7ffd809e  push r11
0000782c7ffd80a0  sub rsp, 0xF0
0000782c7ffd80a7  vmovaps [rsp], xmm0
0000782c7ffd80ac  vmovaps [rsp+0x10], xmm1
0000782c7ffd80b2  vmovaps [rsp+0x20], xmm2
0000782c7ffd80b8  vmovaps [rsp+0x30], xmm3
0000782c7ffd80be  vmovaps [rsp+0x40], xmm4
0000782c7ffd80c4  vmovaps [rsp+0x50], xmm6
0000782c7ffd80ca  vmovaps [rsp+0x60], xmm7
0000782c7ffd80d0  vmovaps [rsp+0x70], xmm8
0000782c7ffd80d6  vmovaps [rsp+0x80], xmm9
0000782c7ffd80df  vmovaps [rsp+0x90], xmm10
0000782c7ffd80e8  vmovaps [rsp+0xA0], xmm11
0000782c7ffd80f1  vmovaps [rsp+0xB0], xmm12
0000782c7ffd80fa  vmovaps [rsp+0xC0], xmm13
0000782c7ffd8103  vmovaps [rsp+0xD0], xmm14
0000782c7ffd810c  vmovaps [rsp+0xE0], xmm15
0000782c7ffd8115  sub rsp, 0x40
0000782c7ffd8119  lea rdi, [rsp]
0000782c7ffd811d  lea rsi, [rsp+0x10]
0000782c7ffd8122  lea rdx, [rsp+0x20]
0000782c7ffd8127  lea rcx, [rsp+0x30]
0000782c7ffd812c  mov r8d, 0x00
0000782c7ffd8132  lea r9, [r15+0x3A8]
0000782c7ffd8139  movaps [rdi], xmm5
0000782c7ffd813c  movaps [rsi], xmm6
0000782c7ffd813f  movaps [rdx], xmm7
0000782c7ffd8142  movaps [rcx], xmm9
0000782c7ffd8146  mov rax, 0x5AE5BFFB5A50
0000782c7ffd8150  call rax
0000782c7ffd8152  movaps xmm5, [rsp]
0000782c7ffd8156  add rsp, 0x40
0000782c7ffd815a  vmovaps xmm0, [rsp]
0000782c7ffd815f  vmovaps xmm1, [rsp+0x10]
0000782c7ffd8165  vmovaps xmm2, [rsp+0x20]
0000782c7ffd816b  vmovaps xmm3, [rsp+0x30]
0000782c7ffd8171  vmovaps xmm4, [rsp+0x40]
0000782c7ffd8177  vmovaps xmm6, [rsp+0x50]
0000782c7ffd817d  vmovaps xmm7, [rsp+0x60]
0000782c7ffd8183  vmovaps xmm8, [rsp+0x70]
0000782c7ffd8189  vmovaps xmm9, [rsp+0x80]
0000782c7ffd8192  vmovaps xmm10, [rsp+0x90]
0000782c7ffd819b  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd81a4  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd81ad  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd81b6  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd81bf  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd81c8  add rsp, 0xF0
0000782c7ffd81cf  pop r11
0000782c7ffd81d1  pop r10
0000782c7ffd81d3  pop r9
0000782c7ffd81d5  pop r8
0000782c7ffd81d7  pop rsi
0000782c7ffd81d8  pop rdi
0000782c7ffd81d9  pop rdx
0000782c7ffd81da  pop rcx
0000782c7ffd81db  pop rax
0000782c7ffd81dc  add rsp, 0x08
0000782c7ffd81e0  jmp 0x0000782C7FFD6930
0000782c7ffd81e5  sub rsp, 0x08
0000782c7ffd81e9  push rax
0000782c7ffd81ea  push rcx
0000782c7ffd81eb  push rdx
0000782c7ffd81ec  push rdi
0000782c7ffd81ed  push rsi
0000782c7ffd81ee  push r8
0000782c7ffd81f0  push r9
0000782c7ffd81f2  push r10
0000782c7ffd81f4  push r11
0000782c7ffd81f6  sub rsp, 0xF0
0000782c7ffd81fd  vmovaps [rsp], xmm0
0000782c7ffd8202  vmovaps [rsp+0x10], xmm1
0000782c7ffd8208  vmovaps [rsp+0x20], xmm2
0000782c7ffd820e  vmovaps [rsp+0x30], xmm3
0000782c7ffd8214  vmovaps [rsp+0x40], xmm4
0000782c7ffd821a  vmovaps [rsp+0x50], xmm5
0000782c7ffd8220  vmovaps [rsp+0x60], xmm6
0000782c7ffd8226  vmovaps [rsp+0x70], xmm8
0000782c7ffd822c  vmovaps [rsp+0x80], xmm9
0000782c7ffd8235  vmovaps [rsp+0x90], xmm10
0000782c7ffd823e  vmovaps [rsp+0xA0], xmm11
0000782c7ffd8247  vmovaps [rsp+0xB0], xmm12
0000782c7ffd8250  vmovaps [rsp+0xC0], xmm13
0000782c7ffd8259  vmovaps [rsp+0xD0], xmm14
0000782c7ffd8262  vmovaps [rsp+0xE0], xmm15
0000782c7ffd826b  sub rsp, 0x40
0000782c7ffd826f  lea rdi, [rsp]
0000782c7ffd8273  lea rsi, [rsp+0x10]
0000782c7ffd8278  lea rdx, [rsp+0x20]
0000782c7ffd827d  lea rcx, [rsp+0x30]
0000782c7ffd8282  mov r8d, 0x00
0000782c7ffd8288  lea r9, [r15+0x3A8]
0000782c7ffd828f  movaps [rdi], xmm7
0000782c7ffd8292  movaps [rsi], xmm13
0000782c7ffd8296  movaps [rdx], xmm1
0000782c7ffd8299  movaps [rcx], xmm9
0000782c7ffd829d  mov rax, 0x5AE5BFFB5A50
0000782c7ffd82a7  call rax
0000782c7ffd82a9  movaps xmm7, [rsp]
0000782c7ffd82ad  add rsp, 0x40
0000782c7ffd82b1  vmovaps xmm0, [rsp]
0000782c7ffd82b6  vmovaps xmm1, [rsp+0x10]
0000782c7ffd82bc  vmovaps xmm2, [rsp+0x20]
0000782c7ffd82c2  vmovaps xmm3, [rsp+0x30]
0000782c7ffd82c8  vmovaps xmm4, [rsp+0x40]
0000782c7ffd82ce  vmovaps xmm5, [rsp+0x50]
0000782c7ffd82d4  vmovaps xmm6, [rsp+0x60]
0000782c7ffd82da  vmovaps xmm8, [rsp+0x70]
0000782c7ffd82e0  vmovaps xmm9, [rsp+0x80]
0000782c7ffd82e9  vmovaps xmm10, [rsp+0x90]
0000782c7ffd82f2  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd82fb  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd8304  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd830d  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd8316  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd831f  add rsp, 0xF0
0000782c7ffd8326  pop r11
0000782c7ffd8328  pop r10
0000782c7ffd832a  pop r9
0000782c7ffd832c  pop r8
0000782c7ffd832e  pop rsi
0000782c7ffd832f  pop rdi
0000782c7ffd8330  pop rdx
0000782c7ffd8331  pop rcx
0000782c7ffd8332  pop rax
0000782c7ffd8333  add rsp, 0x08
0000782c7ffd8337  jmp 0x0000782C7FFD6955
0000782c7ffd833c  call 0x0000782C7FEE3320
0000782c7ffd8341  jmp 0x0000782C7FFD6978
0000782c7ffd8346  call 0x0000782C7FEDE950
0000782c7ffd834b  jmp 0x0000782C7FFD6982
0000782c7ffd8350  sub rsp, 0x08
0000782c7ffd8354  push rax
0000782c7ffd8355  push rcx
0000782c7ffd8356  push rdx
0000782c7ffd8357  push rdi
0000782c7ffd8358  push rsi
0000782c7ffd8359  push r8
0000782c7ffd835b  push r9
0000782c7ffd835d  push r10
0000782c7ffd835f  push r11
0000782c7ffd8361  sub rsp, 0xF0
0000782c7ffd8368  vmovaps [rsp], xmm0
0000782c7ffd836d  vmovaps [rsp+0x10], xmm1
0000782c7ffd8373  vmovaps [rsp+0x20], xmm3
0000782c7ffd8379  vmovaps [rsp+0x30], xmm4
0000782c7ffd837f  vmovaps [rsp+0x40], xmm5
0000782c7ffd8385  vmovaps [rsp+0x50], xmm6
0000782c7ffd838b  vmovaps [rsp+0x60], xmm7
0000782c7ffd8391  vmovaps [rsp+0x70], xmm8
0000782c7ffd8397  vmovaps [rsp+0x80], xmm9
0000782c7ffd83a0  vmovaps [rsp+0x90], xmm10
0000782c7ffd83a9  vmovaps [rsp+0xA0], xmm11
0000782c7ffd83b2  vmovaps [rsp+0xB0], xmm12
0000782c7ffd83bb  vmovaps [rsp+0xC0], xmm13
0000782c7ffd83c4  vmovaps [rsp+0xD0], xmm14
0000782c7ffd83cd  vmovaps [rsp+0xE0], xmm15
0000782c7ffd83d6  sub rsp, 0x40
0000782c7ffd83da  lea rdi, [rsp]
0000782c7ffd83de  lea rsi, [rsp+0x10]
0000782c7ffd83e3  lea rdx, [rsp+0x20]
0000782c7ffd83e8  lea rcx, [rsp+0x30]
0000782c7ffd83ed  mov r8d, 0x00
0000782c7ffd83f3  lea r9, [r15+0x3A8]
0000782c7ffd83fa  movaps [rdi], xmm2
0000782c7ffd83fd  movaps [rsi], xmm12
0000782c7ffd8401  movaps [rdx], xmm6
0000782c7ffd8404  movaps [rcx], xmm3
0000782c7ffd8407  mov rax, 0x5AE5BFFB5A50
0000782c7ffd8411  call rax
0000782c7ffd8413  movaps xmm2, [rsp]
0000782c7ffd8417  add rsp, 0x40
0000782c7ffd841b  vmovaps xmm0, [rsp]
0000782c7ffd8420  vmovaps xmm1, [rsp+0x10]
0000782c7ffd8426  vmovaps xmm3, [rsp+0x20]
0000782c7ffd842c  vmovaps xmm4, [rsp+0x30]
0000782c7ffd8432  vmovaps xmm5, [rsp+0x40]
0000782c7ffd8438  vmovaps xmm6, [rsp+0x50]
0000782c7ffd843e  vmovaps xmm7, [rsp+0x60]
0000782c7ffd8444  vmovaps xmm8, [rsp+0x70]
0000782c7ffd844a  vmovaps xmm9, [rsp+0x80]
0000782c7ffd8453  vmovaps xmm10, [rsp+0x90]
0000782c7ffd845c  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd8465  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd846e  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd8477  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd8480  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd8489  add rsp, 0xF0
0000782c7ffd8490  pop r11
0000782c7ffd8492  pop r10
0000782c7ffd8494  pop r9
0000782c7ffd8496  pop r8
0000782c7ffd8498  pop rsi
0000782c7ffd8499  pop rdi
0000782c7ffd849a  pop rdx
0000782c7ffd849b  pop rcx
0000782c7ffd849c  pop rax
0000782c7ffd849d  add rsp, 0x08
0000782c7ffd84a1  jmp 0x0000782C7FFD69C8
0000782c7ffd84a6  sub rsp, 0x08
0000782c7ffd84aa  push rax
0000782c7ffd84ab  push rcx
0000782c7ffd84ac  push rdx
0000782c7ffd84ad  push rdi
0000782c7ffd84ae  push rsi
0000782c7ffd84af  push r8
0000782c7ffd84b1  push r9
0000782c7ffd84b3  push r10
0000782c7ffd84b5  push r11
0000782c7ffd84b7  sub rsp, 0xF0
0000782c7ffd84be  vmovaps [rsp], xmm0
0000782c7ffd84c3  vmovaps [rsp+0x10], xmm1
0000782c7ffd84c9  vmovaps [rsp+0x20], xmm2
0000782c7ffd84cf  vmovaps [rsp+0x30], xmm3
0000782c7ffd84d5  vmovaps [rsp+0x40], xmm4
0000782c7ffd84db  vmovaps [rsp+0x50], xmm5
0000782c7ffd84e1  vmovaps [rsp+0x60], xmm7
0000782c7ffd84e7  vmovaps [rsp+0x70], xmm8
0000782c7ffd84ed  vmovaps [rsp+0x80], xmm9
0000782c7ffd84f6  vmovaps [rsp+0x90], xmm10
0000782c7ffd84ff  vmovaps [rsp+0xA0], xmm11
0000782c7ffd8508  vmovaps [rsp+0xB0], xmm12
0000782c7ffd8511  vmovaps [rsp+0xC0], xmm13
0000782c7ffd851a  vmovaps [rsp+0xD0], xmm14
0000782c7ffd8523  vmovaps [rsp+0xE0], xmm15
0000782c7ffd852c  sub rsp, 0x40
0000782c7ffd8530  lea rdi, [rsp]
0000782c7ffd8534  lea rsi, [rsp+0x10]
0000782c7ffd8539  lea rdx, [rsp+0x20]
0000782c7ffd853e  lea rcx, [rsp+0x30]
0000782c7ffd8543  mov r8d, 0x00
0000782c7ffd8549  lea r9, [r15+0x3A8]
0000782c7ffd8550  movaps [rdi], xmm6
0000782c7ffd8553  movaps [rsi], xmm10
0000782c7ffd8557  movaps [rdx], xmm12
0000782c7ffd855b  movaps [rcx], xmm1
0000782c7ffd855e  mov rax, 0x5AE5BFFB5A50
0000782c7ffd8568  call rax
0000782c7ffd856a  movaps xmm6, [rsp]
0000782c7ffd856e  add rsp, 0x40
0000782c7ffd8572  vmovaps xmm0, [rsp]
0000782c7ffd8577  vmovaps xmm1, [rsp+0x10]
0000782c7ffd857d  vmovaps xmm2, [rsp+0x20]
0000782c7ffd8583  vmovaps xmm3, [rsp+0x30]
0000782c7ffd8589  vmovaps xmm4, [rsp+0x40]
0000782c7ffd858f  vmovaps xmm5, [rsp+0x50]
0000782c7ffd8595  vmovaps xmm7, [rsp+0x60]
0000782c7ffd859b  vmovaps xmm8, [rsp+0x70]
0000782c7ffd85a1  vmovaps xmm9, [rsp+0x80]
0000782c7ffd85aa  vmovaps xmm10, [rsp+0x90]
0000782c7ffd85b3  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd85bc  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd85c5  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd85ce  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd85d7  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd85e0  add rsp, 0xF0
0000782c7ffd85e7  pop r11
0000782c7ffd85e9  pop r10
0000782c7ffd85eb  pop r9
0000782c7ffd85ed  pop r8
0000782c7ffd85ef  pop rsi
0000782c7ffd85f0  pop rdi
0000782c7ffd85f1  pop rdx
0000782c7ffd85f2  pop rcx
0000782c7ffd85f3  pop rax
0000782c7ffd85f4  add rsp, 0x08
0000782c7ffd85f8  jmp 0x0000782C7FFD69F6
0000782c7ffd85fd  sub rsp, 0x08
0000782c7ffd8601  push rax
0000782c7ffd8602  push rcx
0000782c7ffd8603  push rdx
0000782c7ffd8604  push rdi
0000782c7ffd8605  push rsi
0000782c7ffd8606  push r8
0000782c7ffd8608  push r9
0000782c7ffd860a  push r10
0000782c7ffd860c  push r11
0000782c7ffd860e  sub rsp, 0xF0
0000782c7ffd8615  vmovaps [rsp], xmm0
0000782c7ffd861a  vmovaps [rsp+0x10], xmm1
0000782c7ffd8620  vmovaps [rsp+0x20], xmm2
0000782c7ffd8626  vmovaps [rsp+0x30], xmm3
0000782c7ffd862c  vmovaps [rsp+0x40], xmm4
0000782c7ffd8632  vmovaps [rsp+0x50], xmm5
0000782c7ffd8638  vmovaps [rsp+0x60], xmm6
0000782c7ffd863e  vmovaps [rsp+0x70], xmm7
0000782c7ffd8644  vmovaps [rsp+0x80], xmm8
0000782c7ffd864d  vmovaps [rsp+0x90], xmm9
0000782c7ffd8656  vmovaps [rsp+0xA0], xmm11
0000782c7ffd865f  vmovaps [rsp+0xB0], xmm12
0000782c7ffd8668  vmovaps [rsp+0xC0], xmm13
0000782c7ffd8671  vmovaps [rsp+0xD0], xmm14
0000782c7ffd867a  vmovaps [rsp+0xE0], xmm15
0000782c7ffd8683  sub rsp, 0x40
0000782c7ffd8687  lea rdi, [rsp]
0000782c7ffd868b  lea rsi, [rsp+0x10]
0000782c7ffd8690  lea rdx, [rsp+0x20]
0000782c7ffd8695  lea rcx, [rsp+0x30]
0000782c7ffd869a  mov r8d, 0x00
0000782c7ffd86a0  lea r9, [r15+0x3A8]
0000782c7ffd86a7  movaps [rdi], xmm10
0000782c7ffd86ab  movaps [rsi], xmm5
0000782c7ffd86ae  movaps [rdx], xmm12
0000782c7ffd86b2  movaps [rcx], xmm1
0000782c7ffd86b5  mov rax, 0x5AE5BFFB5A50
0000782c7ffd86bf  call rax
0000782c7ffd86c1  movaps xmm10, [rsp]
0000782c7ffd86c6  add rsp, 0x40
0000782c7ffd86ca  vmovaps xmm0, [rsp]
0000782c7ffd86cf  vmovaps xmm1, [rsp+0x10]
0000782c7ffd86d5  vmovaps xmm2, [rsp+0x20]
0000782c7ffd86db  vmovaps xmm3, [rsp+0x30]
0000782c7ffd86e1  vmovaps xmm4, [rsp+0x40]
0000782c7ffd86e7  vmovaps xmm5, [rsp+0x50]
0000782c7ffd86ed  vmovaps xmm6, [rsp+0x60]
0000782c7ffd86f3  vmovaps xmm7, [rsp+0x70]
0000782c7ffd86f9  vmovaps xmm8, [rsp+0x80]
0000782c7ffd8702  vmovaps xmm9, [rsp+0x90]
0000782c7ffd870b  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd8714  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd871d  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd8726  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd872f  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd8738  add rsp, 0xF0
0000782c7ffd873f  pop r11
0000782c7ffd8741  pop r10
0000782c7ffd8743  pop r9
0000782c7ffd8745  pop r8
0000782c7ffd8747  pop rsi
0000782c7ffd8748  pop rdi
0000782c7ffd8749  pop rdx
0000782c7ffd874a  pop rcx
0000782c7ffd874b  pop rax
0000782c7ffd874c  add rsp, 0x08
0000782c7ffd8750  jmp 0x0000782C7FFD6A25
0000782c7ffd8755  sub rsp, 0x08
0000782c7ffd8759  push rax
0000782c7ffd875a  push rcx
0000782c7ffd875b  push rdx
0000782c7ffd875c  push rdi
0000782c7ffd875d  push rsi
0000782c7ffd875e  push r8
0000782c7ffd8760  push r9
0000782c7ffd8762  push r10
0000782c7ffd8764  push r11
0000782c7ffd8766  sub rsp, 0xF0
0000782c7ffd876d  vmovaps [rsp], xmm0
0000782c7ffd8772  vmovaps [rsp+0x10], xmm1
0000782c7ffd8778  vmovaps [rsp+0x20], xmm2
0000782c7ffd877e  vmovaps [rsp+0x30], xmm3
0000782c7ffd8784  vmovaps [rsp+0x40], xmm4
0000782c7ffd878a  vmovaps [rsp+0x50], xmm5
0000782c7ffd8790  vmovaps [rsp+0x60], xmm6
0000782c7ffd8796  vmovaps [rsp+0x70], xmm7
0000782c7ffd879c  vmovaps [rsp+0x80], xmm8
0000782c7ffd87a5  vmovaps [rsp+0x90], xmm9
0000782c7ffd87ae  vmovaps [rsp+0xA0], xmm10
0000782c7ffd87b7  vmovaps [rsp+0xB0], xmm11
0000782c7ffd87c0  vmovaps [rsp+0xC0], xmm13
0000782c7ffd87c9  vmovaps [rsp+0xD0], xmm14
0000782c7ffd87d2  vmovaps [rsp+0xE0], xmm15
0000782c7ffd87db  sub rsp, 0x40
0000782c7ffd87df  lea rdi, [rsp]
0000782c7ffd87e3  lea rsi, [rsp+0x10]
0000782c7ffd87e8  lea rdx, [rsp+0x20]
0000782c7ffd87ed  lea rcx, [rsp+0x30]
0000782c7ffd87f2  mov r8d, 0x00
0000782c7ffd87f8  lea r9, [r15+0x3A8]
0000782c7ffd87ff  movaps [rdi], xmm12
0000782c7ffd8803  movaps [rsi], xmm7
0000782c7ffd8806  movaps [rdx], xmm15
0000782c7ffd880a  movaps [rcx], xmm1
0000782c7ffd880d  mov rax, 0x5AE5BFFB5A50
0000782c7ffd8817  call rax
0000782c7ffd8819  movaps xmm12, [rsp]
0000782c7ffd881e  add rsp, 0x40
0000782c7ffd8822  vmovaps xmm0, [rsp]
0000782c7ffd8827  vmovaps xmm1, [rsp+0x10]
0000782c7ffd882d  vmovaps xmm2, [rsp+0x20]
0000782c7ffd8833  vmovaps xmm3, [rsp+0x30]
0000782c7ffd8839  vmovaps xmm4, [rsp+0x40]
0000782c7ffd883f  vmovaps xmm5, [rsp+0x50]
0000782c7ffd8845  vmovaps xmm6, [rsp+0x60]
0000782c7ffd884b  vmovaps xmm7, [rsp+0x70]
0000782c7ffd8851  vmovaps xmm8, [rsp+0x80]
0000782c7ffd885a  vmovaps xmm9, [rsp+0x90]
0000782c7ffd8863  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd886c  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd8875  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd887e  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd8887  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd8890  add rsp, 0xF0
0000782c7ffd8897  pop r11
0000782c7ffd8899  pop r10
0000782c7ffd889b  pop r9
0000782c7ffd889d  pop r8
0000782c7ffd889f  pop rsi
0000782c7ffd88a0  pop rdi
0000782c7ffd88a1  pop rdx
0000782c7ffd88a2  pop rcx
0000782c7ffd88a3  pop rax
0000782c7ffd88a4  add rsp, 0x08
0000782c7ffd88a8  jmp 0x0000782C7FFD6A4E
0000782c7ffd88ad  call 0x0000782C7FED64F0
0000782c7ffd88b2  jmp 0x0000782C7FFD6A58
0000782c7ffd88b7  call 0x0000782C7FEE5820
0000782c7ffd88bc  jmp 0x0000782C7FFD6A62
0000782c7ffd88c1  sub rsp, 0x08
0000782c7ffd88c5  push rax
0000782c7ffd88c6  push rcx
0000782c7ffd88c7  push rdx
0000782c7ffd88c8  push rdi
0000782c7ffd88c9  push rsi
0000782c7ffd88ca  push r8
0000782c7ffd88cc  push r9
0000782c7ffd88ce  push r10
0000782c7ffd88d0  push r11
0000782c7ffd88d2  sub rsp, 0xF0
0000782c7ffd88d9  vmovaps [rsp], xmm0
0000782c7ffd88de  vmovaps [rsp+0x10], xmm1
0000782c7ffd88e4  vmovaps [rsp+0x20], xmm2
0000782c7ffd88ea  vmovaps [rsp+0x30], xmm3
0000782c7ffd88f0  vmovaps [rsp+0x40], xmm4
0000782c7ffd88f6  vmovaps [rsp+0x50], xmm5
0000782c7ffd88fc  vmovaps [rsp+0x60], xmm6
0000782c7ffd8902  vmovaps [rsp+0x70], xmm8
0000782c7ffd8908  vmovaps [rsp+0x80], xmm9
0000782c7ffd8911  vmovaps [rsp+0x90], xmm10
0000782c7ffd891a  vmovaps [rsp+0xA0], xmm11
0000782c7ffd8923  vmovaps [rsp+0xB0], xmm12
0000782c7ffd892c  vmovaps [rsp+0xC0], xmm13
0000782c7ffd8935  vmovaps [rsp+0xD0], xmm14
0000782c7ffd893e  vmovaps [rsp+0xE0], xmm15
0000782c7ffd8947  sub rsp, 0x40
0000782c7ffd894b  lea rdi, [rsp]
0000782c7ffd894f  lea rsi, [rsp+0x10]
0000782c7ffd8954  lea rdx, [rsp+0x20]
0000782c7ffd8959  lea rcx, [rsp+0x30]
0000782c7ffd895e  mov r8d, 0x00
0000782c7ffd8964  lea r9, [r15+0x3A8]
0000782c7ffd896b  movaps [rdi], xmm7
0000782c7ffd896e  movaps [rsi], xmm2
0000782c7ffd8971  movaps [rdx], xmm9
0000782c7ffd8975  movaps [rcx], xmm11
0000782c7ffd8979  mov rax, 0x5AE5BFFB5A50
0000782c7ffd8983  call rax
0000782c7ffd8985  movaps xmm7, [rsp]
0000782c7ffd8989  add rsp, 0x40
0000782c7ffd898d  vmovaps xmm0, [rsp]
0000782c7ffd8992  vmovaps xmm1, [rsp+0x10]
0000782c7ffd8998  vmovaps xmm2, [rsp+0x20]
0000782c7ffd899e  vmovaps xmm3, [rsp+0x30]
0000782c7ffd89a4  vmovaps xmm4, [rsp+0x40]
0000782c7ffd89aa  vmovaps xmm5, [rsp+0x50]
0000782c7ffd89b0  vmovaps xmm6, [rsp+0x60]
0000782c7ffd89b6  vmovaps xmm8, [rsp+0x70]
0000782c7ffd89bc  vmovaps xmm9, [rsp+0x80]
0000782c7ffd89c5  vmovaps xmm10, [rsp+0x90]
0000782c7ffd89ce  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd89d7  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd89e0  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd89e9  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd89f2  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd89fb  add rsp, 0xF0
0000782c7ffd8a02  pop r11
0000782c7ffd8a04  pop r10
0000782c7ffd8a06  pop r9
0000782c7ffd8a08  pop r8
0000782c7ffd8a0a  pop rsi
0000782c7ffd8a0b  pop rdi
0000782c7ffd8a0c  pop rdx
0000782c7ffd8a0d  pop rcx
0000782c7ffd8a0e  pop rax
0000782c7ffd8a0f  add rsp, 0x08
0000782c7ffd8a13  jmp 0x0000782C7FFD6A96
0000782c7ffd8a18  sub rsp, 0x08
0000782c7ffd8a1c  push rax
0000782c7ffd8a1d  push rcx
0000782c7ffd8a1e  push rdx
0000782c7ffd8a1f  push rdi
0000782c7ffd8a20  push rsi
0000782c7ffd8a21  push r8
0000782c7ffd8a23  push r9
0000782c7ffd8a25  push r10
0000782c7ffd8a27  push r11
0000782c7ffd8a29  sub rsp, 0xF0
0000782c7ffd8a30  vmovaps [rsp], xmm0
0000782c7ffd8a35  vmovaps [rsp+0x10], xmm1
0000782c7ffd8a3b  vmovaps [rsp+0x20], xmm2
0000782c7ffd8a41  vmovaps [rsp+0x30], xmm3
0000782c7ffd8a47  vmovaps [rsp+0x40], xmm4
0000782c7ffd8a4d  vmovaps [rsp+0x50], xmm5
0000782c7ffd8a53  vmovaps [rsp+0x60], xmm6
0000782c7ffd8a59  vmovaps [rsp+0x70], xmm7
0000782c7ffd8a5f  vmovaps [rsp+0x80], xmm8
0000782c7ffd8a68  vmovaps [rsp+0x90], xmm10
0000782c7ffd8a71  vmovaps [rsp+0xA0], xmm11
0000782c7ffd8a7a  vmovaps [rsp+0xB0], xmm12
0000782c7ffd8a83  vmovaps [rsp+0xC0], xmm13
0000782c7ffd8a8c  vmovaps [rsp+0xD0], xmm14
0000782c7ffd8a95  vmovaps [rsp+0xE0], xmm15
0000782c7ffd8a9e  sub rsp, 0x40
0000782c7ffd8aa2  lea rdi, [rsp]
0000782c7ffd8aa6  lea rsi, [rsp+0x10]
0000782c7ffd8aab  lea rdx, [rsp+0x20]
0000782c7ffd8ab0  lea rcx, [rsp+0x30]
0000782c7ffd8ab5  mov r8d, 0x00
0000782c7ffd8abb  lea r9, [r15+0x3A8]
0000782c7ffd8ac2  movaps [rdi], xmm9
0000782c7ffd8ac6  movaps [rsi], xmm6
0000782c7ffd8ac9  movaps [rdx], xmm1
0000782c7ffd8acc  movaps [rcx], xmm11
0000782c7ffd8ad0  mov rax, 0x5AE5BFFB5A50
0000782c7ffd8ada  call rax
0000782c7ffd8adc  movaps xmm9, [rsp]
0000782c7ffd8ae1  add rsp, 0x40
0000782c7ffd8ae5  vmovaps xmm0, [rsp]
0000782c7ffd8aea  vmovaps xmm1, [rsp+0x10]
0000782c7ffd8af0  vmovaps xmm2, [rsp+0x20]
0000782c7ffd8af6  vmovaps xmm3, [rsp+0x30]
0000782c7ffd8afc  vmovaps xmm4, [rsp+0x40]
0000782c7ffd8b02  vmovaps xmm5, [rsp+0x50]
0000782c7ffd8b08  vmovaps xmm6, [rsp+0x60]
0000782c7ffd8b0e  vmovaps xmm7, [rsp+0x70]
0000782c7ffd8b14  vmovaps xmm8, [rsp+0x80]
0000782c7ffd8b1d  vmovaps xmm10, [rsp+0x90]
0000782c7ffd8b26  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd8b2f  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd8b38  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd8b41  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd8b4a  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd8b53  add rsp, 0xF0
0000782c7ffd8b5a  pop r11
0000782c7ffd8b5c  pop r10
0000782c7ffd8b5e  pop r9
0000782c7ffd8b60  pop r8
0000782c7ffd8b62  pop rsi
0000782c7ffd8b63  pop rdi
0000782c7ffd8b64  pop rdx
0000782c7ffd8b65  pop rcx
0000782c7ffd8b66  pop rax
0000782c7ffd8b67  add rsp, 0x08
0000782c7ffd8b6b  jmp 0x0000782C7FFD6ABC
0000782c7ffd8b70  sub rsp, 0x08
0000782c7ffd8b74  push rax
0000782c7ffd8b75  push rcx
0000782c7ffd8b76  push rdx
0000782c7ffd8b77  push rdi
0000782c7ffd8b78  push rsi
0000782c7ffd8b79  push r8
0000782c7ffd8b7b  push r9
0000782c7ffd8b7d  push r10
0000782c7ffd8b7f  push r11
0000782c7ffd8b81  sub rsp, 0xF0
0000782c7ffd8b88  vmovaps [rsp], xmm0
0000782c7ffd8b8d  vmovaps [rsp+0x10], xmm1
0000782c7ffd8b93  vmovaps [rsp+0x20], xmm2
0000782c7ffd8b99  vmovaps [rsp+0x30], xmm3
0000782c7ffd8b9f  vmovaps [rsp+0x40], xmm4
0000782c7ffd8ba5  vmovaps [rsp+0x50], xmm5
0000782c7ffd8bab  vmovaps [rsp+0x60], xmm6
0000782c7ffd8bb1  vmovaps [rsp+0x70], xmm7
0000782c7ffd8bb7  vmovaps [rsp+0x80], xmm8
0000782c7ffd8bc0  vmovaps [rsp+0x90], xmm9
0000782c7ffd8bc9  vmovaps [rsp+0xA0], xmm10
0000782c7ffd8bd2  vmovaps [rsp+0xB0], xmm12
0000782c7ffd8bdb  vmovaps [rsp+0xC0], xmm13
0000782c7ffd8be4  vmovaps [rsp+0xD0], xmm14
0000782c7ffd8bed  vmovaps [rsp+0xE0], xmm15
0000782c7ffd8bf6  sub rsp, 0x40
0000782c7ffd8bfa  lea rdi, [rsp]
0000782c7ffd8bfe  lea rsi, [rsp+0x10]
0000782c7ffd8c03  lea rdx, [rsp+0x20]
0000782c7ffd8c08  lea rcx, [rsp+0x30]
0000782c7ffd8c0d  mov r8d, 0x00
0000782c7ffd8c13  lea r9, [r15+0x3A8]
0000782c7ffd8c1a  movaps [rdi], xmm11
0000782c7ffd8c1e  movaps [rsi], xmm10
0000782c7ffd8c22  movaps [rdx], xmm8
0000782c7ffd8c26  movaps [rcx], xmm1
0000782c7ffd8c29  mov rax, 0x5AE5BFFB5A50
0000782c7ffd8c33  call rax
0000782c7ffd8c35  movaps xmm11, [rsp]
0000782c7ffd8c3a  add rsp, 0x40
0000782c7ffd8c3e  vmovaps xmm0, [rsp]
0000782c7ffd8c43  vmovaps xmm1, [rsp+0x10]
0000782c7ffd8c49  vmovaps xmm2, [rsp+0x20]
0000782c7ffd8c4f  vmovaps xmm3, [rsp+0x30]
0000782c7ffd8c55  vmovaps xmm4, [rsp+0x40]
0000782c7ffd8c5b  vmovaps xmm5, [rsp+0x50]
0000782c7ffd8c61  vmovaps xmm6, [rsp+0x60]
0000782c7ffd8c67  vmovaps xmm7, [rsp+0x70]
0000782c7ffd8c6d  vmovaps xmm8, [rsp+0x80]
0000782c7ffd8c76  vmovaps xmm9, [rsp+0x90]
0000782c7ffd8c7f  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd8c88  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd8c91  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd8c9a  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd8ca3  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd8cac  add rsp, 0xF0
0000782c7ffd8cb3  pop r11
0000782c7ffd8cb5  pop r10
0000782c7ffd8cb7  pop r9
0000782c7ffd8cb9  pop r8
0000782c7ffd8cbb  pop rsi
0000782c7ffd8cbc  pop rdi
0000782c7ffd8cbd  pop rdx
0000782c7ffd8cbe  pop rcx
0000782c7ffd8cbf  pop rax
0000782c7ffd8cc0  add rsp, 0x08
0000782c7ffd8cc4  jmp 0x0000782C7FFD6AE2
0000782c7ffd8cc9  sub rsp, 0x08
0000782c7ffd8ccd  push rax
0000782c7ffd8cce  push rcx
0000782c7ffd8ccf  push rdx
0000782c7ffd8cd0  push rdi
0000782c7ffd8cd1  push rsi
0000782c7ffd8cd2  push r8
0000782c7ffd8cd4  push r9
0000782c7ffd8cd6  push r10
0000782c7ffd8cd8  push r11
0000782c7ffd8cda  sub rsp, 0xF0
0000782c7ffd8ce1  vmovaps [rsp], xmm0
0000782c7ffd8ce6  vmovaps [rsp+0x10], xmm1
0000782c7ffd8cec  vmovaps [rsp+0x20], xmm2
0000782c7ffd8cf2  vmovaps [rsp+0x30], xmm3
0000782c7ffd8cf8  vmovaps [rsp+0x40], xmm4
0000782c7ffd8cfe  vmovaps [rsp+0x50], xmm5
0000782c7ffd8d04  vmovaps [rsp+0x60], xmm6
0000782c7ffd8d0a  vmovaps [rsp+0x70], xmm7
0000782c7ffd8d10  vmovaps [rsp+0x80], xmm8
0000782c7ffd8d19  vmovaps [rsp+0x90], xmm9
0000782c7ffd8d22  vmovaps [rsp+0xA0], xmm11
0000782c7ffd8d2b  vmovaps [rsp+0xB0], xmm12
0000782c7ffd8d34  vmovaps [rsp+0xC0], xmm13
0000782c7ffd8d3d  vmovaps [rsp+0xD0], xmm14
0000782c7ffd8d46  vmovaps [rsp+0xE0], xmm15
0000782c7ffd8d4f  sub rsp, 0x40
0000782c7ffd8d53  lea rdi, [rsp]
0000782c7ffd8d57  lea rsi, [rsp+0x10]
0000782c7ffd8d5c  lea rdx, [rsp+0x20]
0000782c7ffd8d61  lea rcx, [rsp+0x30]
0000782c7ffd8d66  mov r8d, 0x00
0000782c7ffd8d6c  lea r9, [r15+0x3A8]
0000782c7ffd8d73  movaps [rdi], xmm10
0000782c7ffd8d77  movaps [rsi], xmm12
0000782c7ffd8d7b  movaps [rdx], xmm13
0000782c7ffd8d7f  movaps [rcx], xmm1
0000782c7ffd8d82  mov rax, 0x5AE5BFFB5A50
0000782c7ffd8d8c  call rax
0000782c7ffd8d8e  movaps xmm10, [rsp]
0000782c7ffd8d93  add rsp, 0x40
0000782c7ffd8d97  vmovaps xmm0, [rsp]
0000782c7ffd8d9c  vmovaps xmm1, [rsp+0x10]
0000782c7ffd8da2  vmovaps xmm2, [rsp+0x20]
0000782c7ffd8da8  vmovaps xmm3, [rsp+0x30]
0000782c7ffd8dae  vmovaps xmm4, [rsp+0x40]
0000782c7ffd8db4  vmovaps xmm5, [rsp+0x50]
0000782c7ffd8dba  vmovaps xmm6, [rsp+0x60]
0000782c7ffd8dc0  vmovaps xmm7, [rsp+0x70]
0000782c7ffd8dc6  vmovaps xmm8, [rsp+0x80]
0000782c7ffd8dcf  vmovaps xmm9, [rsp+0x90]
0000782c7ffd8dd8  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd8de1  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd8dea  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd8df3  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd8dfc  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd8e05  add rsp, 0xF0
0000782c7ffd8e0c  pop r11
0000782c7ffd8e0e  pop r10
0000782c7ffd8e10  pop r9
0000782c7ffd8e12  pop r8
0000782c7ffd8e14  pop rsi
0000782c7ffd8e15  pop rdi
0000782c7ffd8e16  pop rdx
0000782c7ffd8e17  pop rcx
0000782c7ffd8e18  pop rax
0000782c7ffd8e19  add rsp, 0x08
0000782c7ffd8e1d  jmp 0x0000782C7FFD6B08
0000782c7ffd8e22  call 0x0000782C7FED64F0
0000782c7ffd8e27  jmp 0x0000782C7FFD6B12
0000782c7ffd8e2c  call 0x0000782C7FEE3320
0000782c7ffd8e31  jmp 0x0000782C7FFD6B1C
0000782c7ffd8e36  sub rsp, 0x08
0000782c7ffd8e3a  push rax
0000782c7ffd8e3b  push rcx
0000782c7ffd8e3c  push rdx
0000782c7ffd8e3d  push rdi
0000782c7ffd8e3e  push rsi
0000782c7ffd8e3f  push r8
0000782c7ffd8e41  push r9
0000782c7ffd8e43  push r10
0000782c7ffd8e45  push r11
0000782c7ffd8e47  sub rsp, 0xF0
0000782c7ffd8e4e  vmovaps [rsp], xmm0
0000782c7ffd8e53  vmovaps [rsp+0x10], xmm1
0000782c7ffd8e59  vmovaps [rsp+0x20], xmm2
0000782c7ffd8e5f  vmovaps [rsp+0x30], xmm3
0000782c7ffd8e65  vmovaps [rsp+0x40], xmm4
0000782c7ffd8e6b  vmovaps [rsp+0x50], xmm5
0000782c7ffd8e71  vmovaps [rsp+0x60], xmm6
0000782c7ffd8e77  vmovaps [rsp+0x70], xmm7
0000782c7ffd8e7d  vmovaps [rsp+0x80], xmm9
0000782c7ffd8e86  vmovaps [rsp+0x90], xmm10
0000782c7ffd8e8f  vmovaps [rsp+0xA0], xmm11
0000782c7ffd8e98  vmovaps [rsp+0xB0], xmm12
0000782c7ffd8ea1  vmovaps [rsp+0xC0], xmm13
0000782c7ffd8eaa  vmovaps [rsp+0xD0], xmm14
0000782c7ffd8eb3  vmovaps [rsp+0xE0], xmm15
0000782c7ffd8ebc  sub rsp, 0x40
0000782c7ffd8ec0  lea rdi, [rsp]
0000782c7ffd8ec4  lea rsi, [rsp+0x10]
0000782c7ffd8ec9  lea rdx, [rsp+0x20]
0000782c7ffd8ece  lea rcx, [rsp+0x30]
0000782c7ffd8ed3  mov r8d, 0x00
0000782c7ffd8ed9  lea r9, [r15+0x3A8]
0000782c7ffd8ee0  movaps [rdi], xmm8
0000782c7ffd8ee4  movaps [rsi], xmm7
0000782c7ffd8ee7  movaps [rdx], xmm4
0000782c7ffd8eea  movaps [rcx], xmm12
0000782c7ffd8eee  mov rax, 0x5AE5BFFB5A50
0000782c7ffd8ef8  call rax
0000782c7ffd8efa  movaps xmm8, [rsp]
0000782c7ffd8eff  add rsp, 0x40
0000782c7ffd8f03  vmovaps xmm0, [rsp]
0000782c7ffd8f08  vmovaps xmm1, [rsp+0x10]
0000782c7ffd8f0e  vmovaps xmm2, [rsp+0x20]
0000782c7ffd8f14  vmovaps xmm3, [rsp+0x30]
0000782c7ffd8f1a  vmovaps xmm4, [rsp+0x40]
0000782c7ffd8f20  vmovaps xmm5, [rsp+0x50]
0000782c7ffd8f26  vmovaps xmm6, [rsp+0x60]
0000782c7ffd8f2c  vmovaps xmm7, [rsp+0x70]
0000782c7ffd8f32  vmovaps xmm9, [rsp+0x80]
0000782c7ffd8f3b  vmovaps xmm10, [rsp+0x90]
0000782c7ffd8f44  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd8f4d  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd8f56  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd8f5f  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd8f68  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd8f71  add rsp, 0xF0
0000782c7ffd8f78  pop r11
0000782c7ffd8f7a  pop r10
0000782c7ffd8f7c  pop r9
0000782c7ffd8f7e  pop r8
0000782c7ffd8f80  pop rsi
0000782c7ffd8f81  pop rdi
0000782c7ffd8f82  pop rdx
0000782c7ffd8f83  pop rcx
0000782c7ffd8f84  pop rax
0000782c7ffd8f85  add rsp, 0x08
0000782c7ffd8f89  jmp 0x0000782C7FFD6B45
0000782c7ffd8f8e  sub rsp, 0x08
0000782c7ffd8f92  push rax
0000782c7ffd8f93  push rcx
0000782c7ffd8f94  push rdx
0000782c7ffd8f95  push rdi
0000782c7ffd8f96  push rsi
0000782c7ffd8f97  push r8
0000782c7ffd8f99  push r9
0000782c7ffd8f9b  push r10
0000782c7ffd8f9d  push r11
0000782c7ffd8f9f  sub rsp, 0xF0
0000782c7ffd8fa6  vmovaps [rsp], xmm0
0000782c7ffd8fab  vmovaps [rsp+0x10], xmm1
0000782c7ffd8fb1  vmovaps [rsp+0x20], xmm2
0000782c7ffd8fb7  vmovaps [rsp+0x30], xmm3
0000782c7ffd8fbd  vmovaps [rsp+0x40], xmm4
0000782c7ffd8fc3  vmovaps [rsp+0x50], xmm5
0000782c7ffd8fc9  vmovaps [rsp+0x60], xmm6
0000782c7ffd8fcf  vmovaps [rsp+0x70], xmm8
0000782c7ffd8fd5  vmovaps [rsp+0x80], xmm9
0000782c7ffd8fde  vmovaps [rsp+0x90], xmm10
0000782c7ffd8fe7  vmovaps [rsp+0xA0], xmm11
0000782c7ffd8ff0  vmovaps [rsp+0xB0], xmm12
0000782c7ffd8ff9  vmovaps [rsp+0xC0], xmm13
0000782c7ffd9002  vmovaps [rsp+0xD0], xmm14
0000782c7ffd900b  vmovaps [rsp+0xE0], xmm15
0000782c7ffd9014  sub rsp, 0x40
0000782c7ffd9018  lea rdi, [rsp]
0000782c7ffd901c  lea rsi, [rsp+0x10]
0000782c7ffd9021  lea rdx, [rsp+0x20]
0000782c7ffd9026  lea rcx, [rsp+0x30]
0000782c7ffd902b  mov r8d, 0x00
0000782c7ffd9031  lea r9, [r15+0x3A8]
0000782c7ffd9038  movaps [rdi], xmm7
0000782c7ffd903b  movaps [rsi], xmm9
0000782c7ffd903f  movaps [rdx], xmm14
0000782c7ffd9043  movaps [rcx], xmm12
0000782c7ffd9047  mov rax, 0x5AE5BFFB5A50
0000782c7ffd9051  call rax
0000782c7ffd9053  movaps xmm7, [rsp]
0000782c7ffd9057  add rsp, 0x40
0000782c7ffd905b  vmovaps xmm0, [rsp]
0000782c7ffd9060  vmovaps xmm1, [rsp+0x10]
0000782c7ffd9066  vmovaps xmm2, [rsp+0x20]
0000782c7ffd906c  vmovaps xmm3, [rsp+0x30]
0000782c7ffd9072  vmovaps xmm4, [rsp+0x40]
0000782c7ffd9078  vmovaps xmm5, [rsp+0x50]
0000782c7ffd907e  vmovaps xmm6, [rsp+0x60]
0000782c7ffd9084  vmovaps xmm8, [rsp+0x70]
0000782c7ffd908a  vmovaps xmm9, [rsp+0x80]
0000782c7ffd9093  vmovaps xmm10, [rsp+0x90]
0000782c7ffd909c  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd90a5  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd90ae  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd90b7  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd90c0  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd90c9  add rsp, 0xF0
0000782c7ffd90d0  pop r11
0000782c7ffd90d2  pop r10
0000782c7ffd90d4  pop r9
0000782c7ffd90d6  pop r8
0000782c7ffd90d8  pop rsi
0000782c7ffd90d9  pop rdi
0000782c7ffd90da  pop rdx
0000782c7ffd90db  pop rcx
0000782c7ffd90dc  pop rax
0000782c7ffd90dd  add rsp, 0x08
0000782c7ffd90e1  jmp 0x0000782C7FFD6B6D
0000782c7ffd90e6  sub rsp, 0x08
0000782c7ffd90ea  push rax
0000782c7ffd90eb  push rcx
0000782c7ffd90ec  push rdx
0000782c7ffd90ed  push rdi
0000782c7ffd90ee  push rsi
0000782c7ffd90ef  push r8
0000782c7ffd90f1  push r9
0000782c7ffd90f3  push r10
0000782c7ffd90f5  push r11
0000782c7ffd90f7  sub rsp, 0xF0
0000782c7ffd90fe  vmovaps [rsp], xmm0
0000782c7ffd9103  vmovaps [rsp+0x10], xmm1
0000782c7ffd9109  vmovaps [rsp+0x20], xmm2
0000782c7ffd910f  vmovaps [rsp+0x30], xmm3
0000782c7ffd9115  vmovaps [rsp+0x40], xmm4
0000782c7ffd911b  vmovaps [rsp+0x50], xmm5
0000782c7ffd9121  vmovaps [rsp+0x60], xmm6
0000782c7ffd9127  vmovaps [rsp+0x70], xmm7
0000782c7ffd912d  vmovaps [rsp+0x80], xmm8
0000782c7ffd9136  vmovaps [rsp+0x90], xmm9
0000782c7ffd913f  vmovaps [rsp+0xA0], xmm10
0000782c7ffd9148  vmovaps [rsp+0xB0], xmm11
0000782c7ffd9151  vmovaps [rsp+0xC0], xmm13
0000782c7ffd915a  vmovaps [rsp+0xD0], xmm14
0000782c7ffd9163  vmovaps [rsp+0xE0], xmm15
0000782c7ffd916c  sub rsp, 0x40
0000782c7ffd9170  lea rdi, [rsp]
0000782c7ffd9174  lea rsi, [rsp+0x10]
0000782c7ffd9179  lea rdx, [rsp+0x20]
0000782c7ffd917e  lea rcx, [rsp+0x30]
0000782c7ffd9183  mov r8d, 0x00
0000782c7ffd9189  lea r9, [r15+0x3A8]
0000782c7ffd9190  movaps [rdi], xmm12
0000782c7ffd9194  movaps [rsi], xmm11
0000782c7ffd9198  movaps [rdx], xmm15
0000782c7ffd919c  movaps [rcx], xmm14
0000782c7ffd91a0  mov rax, 0x5AE5BFFB5A50
0000782c7ffd91aa  call rax
0000782c7ffd91ac  movaps xmm12, [rsp]
0000782c7ffd91b1  add rsp, 0x40
0000782c7ffd91b5  vmovaps xmm0, [rsp]
0000782c7ffd91ba  vmovaps xmm1, [rsp+0x10]
0000782c7ffd91c0  vmovaps xmm2, [rsp+0x20]
0000782c7ffd91c6  vmovaps xmm3, [rsp+0x30]
0000782c7ffd91cc  vmovaps xmm4, [rsp+0x40]
0000782c7ffd91d2  vmovaps xmm5, [rsp+0x50]
0000782c7ffd91d8  vmovaps xmm6, [rsp+0x60]
0000782c7ffd91de  vmovaps xmm7, [rsp+0x70]
0000782c7ffd91e4  vmovaps xmm8, [rsp+0x80]
0000782c7ffd91ed  vmovaps xmm9, [rsp+0x90]
0000782c7ffd91f6  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd91ff  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd9208  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd9211  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd921a  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd9223  add rsp, 0xF0
0000782c7ffd922a  pop r11
0000782c7ffd922c  pop r10
0000782c7ffd922e  pop r9
0000782c7ffd9230  pop r8
0000782c7ffd9232  pop rsi
0000782c7ffd9233  pop rdi
0000782c7ffd9234  pop rdx
0000782c7ffd9235  pop rcx
0000782c7ffd9236  pop rax
0000782c7ffd9237  add rsp, 0x08
0000782c7ffd923b  jmp 0x0000782C7FFD6B96
0000782c7ffd9240  sub rsp, 0x08
0000782c7ffd9244  push rax
0000782c7ffd9245  push rcx
0000782c7ffd9246  push rdx
0000782c7ffd9247  push rdi
0000782c7ffd9248  push rsi
0000782c7ffd9249  push r8
0000782c7ffd924b  push r9
0000782c7ffd924d  push r10
0000782c7ffd924f  push r11
0000782c7ffd9251  sub rsp, 0xF0
0000782c7ffd9258  vmovaps [rsp], xmm0
0000782c7ffd925d  vmovaps [rsp+0x10], xmm1
0000782c7ffd9263  vmovaps [rsp+0x20], xmm2
0000782c7ffd9269  vmovaps [rsp+0x30], xmm3
0000782c7ffd926f  vmovaps [rsp+0x40], xmm4
0000782c7ffd9275  vmovaps [rsp+0x50], xmm5
0000782c7ffd927b  vmovaps [rsp+0x60], xmm6
0000782c7ffd9281  vmovaps [rsp+0x70], xmm7
0000782c7ffd9287  vmovaps [rsp+0x80], xmm8
0000782c7ffd9290  vmovaps [rsp+0x90], xmm9
0000782c7ffd9299  vmovaps [rsp+0xA0], xmm10
0000782c7ffd92a2  vmovaps [rsp+0xB0], xmm12
0000782c7ffd92ab  vmovaps [rsp+0xC0], xmm13
0000782c7ffd92b4  vmovaps [rsp+0xD0], xmm14
0000782c7ffd92bd  vmovaps [rsp+0xE0], xmm15
0000782c7ffd92c6  sub rsp, 0x40
0000782c7ffd92ca  lea rdi, [rsp]
0000782c7ffd92ce  lea rsi, [rsp+0x10]
0000782c7ffd92d3  lea rdx, [rsp+0x20]
0000782c7ffd92d8  lea rcx, [rsp+0x30]
0000782c7ffd92dd  mov r8d, 0x00
0000782c7ffd92e3  lea r9, [r15+0x3A8]
0000782c7ffd92ea  movaps [rdi], xmm11
0000782c7ffd92ee  movaps [rsi], xmm10
0000782c7ffd92f2  movaps [rdx], xmm13
0000782c7ffd92f6  movaps [rcx], xmm15
0000782c7ffd92fa  mov rax, 0x5AE5BFFB5A50
0000782c7ffd9304  call rax
0000782c7ffd9306  movaps xmm11, [rsp]
0000782c7ffd930b  add rsp, 0x40
0000782c7ffd930f  vmovaps xmm0, [rsp]
0000782c7ffd9314  vmovaps xmm1, [rsp+0x10]
0000782c7ffd931a  vmovaps xmm2, [rsp+0x20]
0000782c7ffd9320  vmovaps xmm3, [rsp+0x30]
0000782c7ffd9326  vmovaps xmm4, [rsp+0x40]
0000782c7ffd932c  vmovaps xmm5, [rsp+0x50]
0000782c7ffd9332  vmovaps xmm6, [rsp+0x60]
0000782c7ffd9338  vmovaps xmm7, [rsp+0x70]
0000782c7ffd933e  vmovaps xmm8, [rsp+0x80]
0000782c7ffd9347  vmovaps xmm9, [rsp+0x90]
0000782c7ffd9350  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd9359  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd9362  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd936b  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd9374  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd937d  add rsp, 0xF0
0000782c7ffd9384  pop r11
0000782c7ffd9386  pop r10
0000782c7ffd9388  pop r9
0000782c7ffd938a  pop r8
0000782c7ffd938c  pop rsi
0000782c7ffd938d  pop rdi
0000782c7ffd938e  pop rdx
0000782c7ffd938f  pop rcx
0000782c7ffd9390  pop rax
0000782c7ffd9391  add rsp, 0x08
0000782c7ffd9395  jmp 0x0000782C7FFD6BBF
0000782c7ffd939a  call 0x0000782C7FEE5820
0000782c7ffd939f  jmp 0x0000782C7FFD6BCC
0000782c7ffd93a4  call 0x0000782C7FEE45A0
0000782c7ffd93a9  jmp 0x0000782C7FFD6BD9
0000782c7ffd93ae  sub rsp, 0x08
0000782c7ffd93b2  push rax
0000782c7ffd93b3  push rcx
0000782c7ffd93b4  push rdx
0000782c7ffd93b5  push rdi
0000782c7ffd93b6  push rsi
0000782c7ffd93b7  push r8
0000782c7ffd93b9  push r9
0000782c7ffd93bb  push r10
0000782c7ffd93bd  push r11
0000782c7ffd93bf  sub rsp, 0xF0
0000782c7ffd93c6  vmovaps [rsp], xmm0
0000782c7ffd93cb  vmovaps [rsp+0x10], xmm1
0000782c7ffd93d1  vmovaps [rsp+0x20], xmm2
0000782c7ffd93d7  vmovaps [rsp+0x30], xmm3
0000782c7ffd93dd  vmovaps [rsp+0x40], xmm4
0000782c7ffd93e3  vmovaps [rsp+0x50], xmm5
0000782c7ffd93e9  vmovaps [rsp+0x60], xmm6
0000782c7ffd93ef  vmovaps [rsp+0x70], xmm7
0000782c7ffd93f5  vmovaps [rsp+0x80], xmm8
0000782c7ffd93fe  vmovaps [rsp+0x90], xmm9
0000782c7ffd9407  vmovaps [rsp+0xA0], xmm11
0000782c7ffd9410  vmovaps [rsp+0xB0], xmm12
0000782c7ffd9419  vmovaps [rsp+0xC0], xmm13
0000782c7ffd9422  vmovaps [rsp+0xD0], xmm14
0000782c7ffd942b  vmovaps [rsp+0xE0], xmm15
0000782c7ffd9434  sub rsp, 0x40
0000782c7ffd9438  lea rdi, [rsp]
0000782c7ffd943c  lea rsi, [rsp+0x10]
0000782c7ffd9441  lea rdx, [rsp+0x20]
0000782c7ffd9446  lea rcx, [rsp+0x30]
0000782c7ffd944b  mov r8d, 0x00
0000782c7ffd9451  lea r9, [r15+0x3A8]
0000782c7ffd9458  movaps [rdi], xmm10
0000782c7ffd945c  movaps [rsi], xmm8
0000782c7ffd9460  movaps [rdx], xmm1
0000782c7ffd9463  movaps [rcx], xmm13
0000782c7ffd9467  mov rax, 0x5AE5BFFB5A50
0000782c7ffd9471  call rax
0000782c7ffd9473  movaps xmm10, [rsp]
0000782c7ffd9478  add rsp, 0x40
0000782c7ffd947c  vmovaps xmm0, [rsp]
0000782c7ffd9481  vmovaps xmm1, [rsp+0x10]
0000782c7ffd9487  vmovaps xmm2, [rsp+0x20]
0000782c7ffd948d  vmovaps xmm3, [rsp+0x30]
0000782c7ffd9493  vmovaps xmm4, [rsp+0x40]
0000782c7ffd9499  vmovaps xmm5, [rsp+0x50]
0000782c7ffd949f  vmovaps xmm6, [rsp+0x60]
0000782c7ffd94a5  vmovaps xmm7, [rsp+0x70]
0000782c7ffd94ab  vmovaps xmm8, [rsp+0x80]
0000782c7ffd94b4  vmovaps xmm9, [rsp+0x90]
0000782c7ffd94bd  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd94c6  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd94cf  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd94d8  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd94e1  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd94ea  add rsp, 0xF0
0000782c7ffd94f1  pop r11
0000782c7ffd94f3  pop r10
0000782c7ffd94f5  pop r9
0000782c7ffd94f7  pop r8
0000782c7ffd94f9  pop rsi
0000782c7ffd94fa  pop rdi
0000782c7ffd94fb  pop rdx
0000782c7ffd94fc  pop rcx
0000782c7ffd94fd  pop rax
0000782c7ffd94fe  add rsp, 0x08
0000782c7ffd9502  jmp 0x0000782C7FFD6C0F
0000782c7ffd9507  call 0x0000782C7FED64F0
0000782c7ffd950c  jmp 0x0000782C7FFD6C21
0000782c7ffd9511  sub rsp, 0x08
0000782c7ffd9515  push rax
0000782c7ffd9516  push rcx
0000782c7ffd9517  push rdx
0000782c7ffd9518  push rdi
0000782c7ffd9519  push rsi
0000782c7ffd951a  push r8
0000782c7ffd951c  push r9
0000782c7ffd951e  push r10
0000782c7ffd9520  push r11
0000782c7ffd9522  sub rsp, 0xF0
0000782c7ffd9529  vmovaps [rsp], xmm0
0000782c7ffd952e  vmovaps [rsp+0x10], xmm1
0000782c7ffd9534  vmovaps [rsp+0x20], xmm2
0000782c7ffd953a  vmovaps [rsp+0x30], xmm3
0000782c7ffd9540  vmovaps [rsp+0x40], xmm4
0000782c7ffd9546  vmovaps [rsp+0x50], xmm5
0000782c7ffd954c  vmovaps [rsp+0x60], xmm6
0000782c7ffd9552  vmovaps [rsp+0x70], xmm7
0000782c7ffd9558  vmovaps [rsp+0x80], xmm8
0000782c7ffd9561  vmovaps [rsp+0x90], xmm10
0000782c7ffd956a  vmovaps [rsp+0xA0], xmm11
0000782c7ffd9573  vmovaps [rsp+0xB0], xmm12
0000782c7ffd957c  vmovaps [rsp+0xC0], xmm13
0000782c7ffd9585  vmovaps [rsp+0xD0], xmm14
0000782c7ffd958e  vmovaps [rsp+0xE0], xmm15
0000782c7ffd9597  sub rsp, 0x40
0000782c7ffd959b  lea rdi, [rsp]
0000782c7ffd959f  lea rsi, [rsp+0x10]
0000782c7ffd95a4  lea rdx, [rsp+0x20]
0000782c7ffd95a9  lea rcx, [rsp+0x30]
0000782c7ffd95ae  mov r8d, 0x00
0000782c7ffd95b4  lea r9, [r15+0x3A8]
0000782c7ffd95bb  movaps [rdi], xmm9
0000782c7ffd95bf  movaps [rsi], xmm7
0000782c7ffd95c2  movaps [rdx], xmm14
0000782c7ffd95c6  movaps [rcx], xmm13
0000782c7ffd95ca  mov rax, 0x5AE5BFFB5A50
0000782c7ffd95d4  call rax
0000782c7ffd95d6  movaps xmm9, [rsp]
0000782c7ffd95db  add rsp, 0x40
0000782c7ffd95df  vmovaps xmm0, [rsp]
0000782c7ffd95e4  vmovaps xmm1, [rsp+0x10]
0000782c7ffd95ea  vmovaps xmm2, [rsp+0x20]
0000782c7ffd95f0  vmovaps xmm3, [rsp+0x30]
0000782c7ffd95f6  vmovaps xmm4, [rsp+0x40]
0000782c7ffd95fc  vmovaps xmm5, [rsp+0x50]
0000782c7ffd9602  vmovaps xmm6, [rsp+0x60]
0000782c7ffd9608  vmovaps xmm7, [rsp+0x70]
0000782c7ffd960e  vmovaps xmm8, [rsp+0x80]
0000782c7ffd9617  vmovaps xmm10, [rsp+0x90]
0000782c7ffd9620  vmovaps xmm11, [rsp+0xA0]
0000782c7ffd9629  vmovaps xmm12, [rsp+0xB0]
0000782c7ffd9632  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd963b  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd9644  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd964d  add rsp, 0xF0
0000782c7ffd9654  pop r11
0000782c7ffd9656  pop r10
0000782c7ffd9658  pop r9
0000782c7ffd965a  pop r8
0000782c7ffd965c  pop rsi
0000782c7ffd965d  pop rdi
0000782c7ffd965e  pop rdx
0000782c7ffd965f  pop rcx
0000782c7ffd9660  pop rax
0000782c7ffd9661  add rsp, 0x08
0000782c7ffd9665  jmp 0x0000782C7FFD6C4F
0000782c7ffd966a  sub rsp, 0x08
0000782c7ffd966e  push rax
0000782c7ffd966f  push rcx
0000782c7ffd9670  push rdx
0000782c7ffd9671  push rdi
0000782c7ffd9672  push rsi
0000782c7ffd9673  push r8
0000782c7ffd9675  push r9
0000782c7ffd9677  push r10
0000782c7ffd9679  push r11
0000782c7ffd967b  sub rsp, 0xF0
0000782c7ffd9682  vmovaps [rsp], xmm0
0000782c7ffd9687  vmovaps [rsp+0x10], xmm1
0000782c7ffd968d  vmovaps [rsp+0x20], xmm2
0000782c7ffd9693  vmovaps [rsp+0x30], xmm3
0000782c7ffd9699  vmovaps [rsp+0x40], xmm4
0000782c7ffd969f  vmovaps [rsp+0x50], xmm5
0000782c7ffd96a5  vmovaps [rsp+0x60], xmm6
0000782c7ffd96ab  vmovaps [rsp+0x70], xmm7
0000782c7ffd96b1  vmovaps [rsp+0x80], xmm8
0000782c7ffd96ba  vmovaps [rsp+0x90], xmm9
0000782c7ffd96c3  vmovaps [rsp+0xA0], xmm10
0000782c7ffd96cc  vmovaps [rsp+0xB0], xmm11
0000782c7ffd96d5  vmovaps [rsp+0xC0], xmm12
0000782c7ffd96de  vmovaps [rsp+0xD0], xmm14
0000782c7ffd96e7  vmovaps [rsp+0xE0], xmm15
0000782c7ffd96f0  sub rsp, 0x40
0000782c7ffd96f4  lea rdi, [rsp]
0000782c7ffd96f8  lea rsi, [rsp+0x10]
0000782c7ffd96fd  lea rdx, [rsp+0x20]
0000782c7ffd9702  lea rcx, [rsp+0x30]
0000782c7ffd9707  mov r8d, 0x00
0000782c7ffd970d  lea r9, [r15+0x3A8]
0000782c7ffd9714  movaps [rdi], xmm13
0000782c7ffd9718  movaps [rsi], xmm12
0000782c7ffd971c  movaps [rdx], xmm15
0000782c7ffd9720  movaps [rcx], xmm14
0000782c7ffd9724  mov rax, 0x5AE5BFFB5A50
0000782c7ffd972e  call rax
0000782c7ffd9730  movaps xmm13, [rsp]
0000782c7ffd9735  add rsp, 0x40
0000782c7ffd9739  vmovaps xmm0, [rsp]
0000782c7ffd973e  vmovaps xmm1, [rsp+0x10]
0000782c7ffd9744  vmovaps xmm2, [rsp+0x20]
0000782c7ffd974a  vmovaps xmm3, [rsp+0x30]
0000782c7ffd9750  vmovaps xmm4, [rsp+0x40]
0000782c7ffd9756  vmovaps xmm5, [rsp+0x50]
0000782c7ffd975c  vmovaps xmm6, [rsp+0x60]
0000782c7ffd9762  vmovaps xmm7, [rsp+0x70]
0000782c7ffd9768  vmovaps xmm8, [rsp+0x80]
0000782c7ffd9771  vmovaps xmm9, [rsp+0x90]
0000782c7ffd977a  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd9783  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd978c  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd9795  vmovaps xmm14, [rsp+0xD0]
0000782c7ffd979e  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd97a7  add rsp, 0xF0
0000782c7ffd97ae  pop r11
0000782c7ffd97b0  pop r10
0000782c7ffd97b2  pop r9
0000782c7ffd97b4  pop r8
0000782c7ffd97b6  pop rsi
0000782c7ffd97b7  pop rdi
0000782c7ffd97b8  pop rdx
0000782c7ffd97b9  pop rcx
0000782c7ffd97ba  pop rax
0000782c7ffd97bb  add rsp, 0x08
0000782c7ffd97bf  jmp 0x0000782C7FFD6C7D
0000782c7ffd97c4  sub rsp, 0x08
0000782c7ffd97c8  push rax
0000782c7ffd97c9  push rcx
0000782c7ffd97ca  push rdx
0000782c7ffd97cb  push rdi
0000782c7ffd97cc  push rsi
0000782c7ffd97cd  push r8
0000782c7ffd97cf  push r9
0000782c7ffd97d1  push r10
0000782c7ffd97d3  push r11
0000782c7ffd97d5  sub rsp, 0xF0
0000782c7ffd97dc  vmovaps [rsp], xmm0
0000782c7ffd97e1  vmovaps [rsp+0x10], xmm1
0000782c7ffd97e7  vmovaps [rsp+0x20], xmm2
0000782c7ffd97ed  vmovaps [rsp+0x30], xmm3
0000782c7ffd97f3  vmovaps [rsp+0x40], xmm4
0000782c7ffd97f9  vmovaps [rsp+0x50], xmm5
0000782c7ffd97ff  vmovaps [rsp+0x60], xmm6
0000782c7ffd9805  vmovaps [rsp+0x70], xmm7
0000782c7ffd980b  vmovaps [rsp+0x80], xmm8
0000782c7ffd9814  vmovaps [rsp+0x90], xmm9
0000782c7ffd981d  vmovaps [rsp+0xA0], xmm10
0000782c7ffd9826  vmovaps [rsp+0xB0], xmm11
0000782c7ffd982f  vmovaps [rsp+0xC0], xmm12
0000782c7ffd9838  vmovaps [rsp+0xD0], xmm13
0000782c7ffd9841  vmovaps [rsp+0xE0], xmm15
0000782c7ffd984a  sub rsp, 0x40
0000782c7ffd984e  lea rdi, [rsp]
0000782c7ffd9852  lea rsi, [rsp+0x10]
0000782c7ffd9857  lea rdx, [rsp+0x20]
0000782c7ffd985c  lea rcx, [rsp+0x30]
0000782c7ffd9861  mov r8d, 0x00
0000782c7ffd9867  lea r9, [r15+0x3A8]
0000782c7ffd986e  movaps [rdi], xmm14
0000782c7ffd9872  movaps [rsi], xmm11
0000782c7ffd9876  movaps [rdx], xmm1
0000782c7ffd9879  movaps [rcx], xmm15
0000782c7ffd987d  mov rax, 0x5AE5BFFB5A50
0000782c7ffd9887  call rax
0000782c7ffd9889  movaps xmm14, [rsp]
0000782c7ffd988e  add rsp, 0x40
0000782c7ffd9892  vmovaps xmm0, [rsp]
0000782c7ffd9897  vmovaps xmm1, [rsp+0x10]
0000782c7ffd989d  vmovaps xmm2, [rsp+0x20]
0000782c7ffd98a3  vmovaps xmm3, [rsp+0x30]
0000782c7ffd98a9  vmovaps xmm4, [rsp+0x40]
0000782c7ffd98af  vmovaps xmm5, [rsp+0x50]
0000782c7ffd98b5  vmovaps xmm6, [rsp+0x60]
0000782c7ffd98bb  vmovaps xmm7, [rsp+0x70]
0000782c7ffd98c1  vmovaps xmm8, [rsp+0x80]
0000782c7ffd98ca  vmovaps xmm9, [rsp+0x90]
0000782c7ffd98d3  vmovaps xmm10, [rsp+0xA0]
0000782c7ffd98dc  vmovaps xmm11, [rsp+0xB0]
0000782c7ffd98e5  vmovaps xmm12, [rsp+0xC0]
0000782c7ffd98ee  vmovaps xmm13, [rsp+0xD0]
0000782c7ffd98f7  vmovaps xmm15, [rsp+0xE0]
0000782c7ffd9900  add rsp, 0xF0
0000782c7ffd9907  pop r11
0000782c7ffd9909  pop r10
0000782c7ffd990b  pop r9
0000782c7ffd990d  pop r8
0000782c7ffd990f  pop rsi
0000782c7ffd9910  pop rdi
0000782c7ffd9911  pop rdx
0000782c7ffd9912  pop rcx
0000782c7ffd9913  pop rax
0000782c7ffd9914  add rsp, 0x08
0000782c7ffd9918  jmp 0x0000782C7FFD6CAB
0000782c7ffd991d  call 0x0000782C7FEACF70
0000782c7ffd9922  jmp 0x0000782C7FFD6CB9
0000782c7ffd9927  call 0x0000782C7FE0C380
0000782c7ffd992c  jmp 0x0000782C7FFD6CC3
0000782c7ffd9931  call 0x0000782C7FE08C20
0000782c7ffd9936  jmp 0x0000782C7FFD6CCD
0000782c7ffd993b  call 0x0000782C7FE0D600
0000782c7ffd9940  jmp 0x0000782C7FFD6CD7
0000782c7ffd9945  int3
0000782c7ffd9946  nop [rax+rax*1], ax
0000782c7ffd994f  nop
0000782c7ffd9950  mov eax, [r15+0x48]
0000782c7ffd9954  lea r14d, [eax+0x01]
0000782c7ffd9959  mov [rsp+0x10], r14d
0000782c7ffd995e  mov r14d, r14d
0000782c7ffd9961  mov [r15+0x48], r14
0000782c7ffd9965  xor eax, eax
0000782c7ffd9967  mov r14d, [rsp+0x10]
0000782c7ffd996c  cmp r14d, 0x1F4
0000782c7ffd9973  cmc
0000782c7ffd9974  lahf
0000782c7ffd9975  seto al
0000782c7ffd9978  mov [r15+0x108], eax
0000782c7ffd997f  mov eax, [r15+0x108]
0000782c7ffd9986  sahf
0000782c7ffd9987  jnz 0x0000782C7FFD99B9
0000782c7ffd9989  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd9991  jz 0x0000782C7FFDD2E0
0000782c7ffd9997  nop [rax+rax*1], ax
0000782c7ffd99a0  nop [rax+rax*1], eax
0000782c7ffd99a8  mov eax, 0x410670
0000782c7ffd99ad  mov [r15+0x100], rax
0000782c7ffd99b4  jmp 0x0000782C7FDFE110
0000782c7ffd99b9  cmp dword ptr [r15+0x318], 0x00
0000782c7ffd99c1  jz 0x0000782C7FFD99F0
0000782c7ffd99c7  nop [rax+rax*1], ax
0000782c7ffd99d0  nop [rax+rax*1], eax
0000782c7ffd99d8  mov eax, 0x4104EC
0000782c7ffd99dd  mov [r15+0x100], rax
0000782c7ffd99e4  jmp 0x0000782C7FDFE110
0000782c7ffd99e9  int3
0000782c7ffd99ea  int3
0000782c7ffd99eb  nop [rax+rax*1], eax
0000782c7ffd99f0  mov rax, [r15+0x40]
0000782c7ffd99f4  vxorps xmm1, xmm1, xmm1
0000782c7ffd99f8  vpbroadcastq xmm1, xmm1
0000782c7ffd99fd  vxorps xmm15, xmm15, xmm15
0000782c7ffd9a02  vpbroadcastq xmm15, xmm15
0000782c7ffd9a07  lea r14, [rax+0x30]
0000782c7ffd9a0b  mov r12, [r13+r14*1]
0000782c7ffd9a10  lea r14, [rax+0x38]
0000782c7ffd9a14  mov r11, [r13+r14*1]
0000782c7ffd9a19  movq xmm14, r12
0000782c7ffd9a1e  movq xmm13, r11
0000782c7ffd9a23  movq xmm14, xmm14
0000782c7ffd9a28  movq xmm13, xmm13
0000782c7ffd9a2d  vmovaps [rsp+0x10], xmm13
0000782c7ffd9a33  movq xmm13, xmm13
0000782c7ffd9a38  movaps [r15+0x270], xmm13
0000782c7ffd9a40  movaps xmm13, [r15+0x160]
0000782c7ffd9a48  vmovaps [rsp+0x20], xmm13
0000782c7ffd9a4e  vmovaps xmm12, [rsp+0x20]
0000782c7ffd9a54  por xmm13, xmm12
0000782c7ffd9a59  lea r14, [rax+0x20]
0000782c7ffd9a5d  mov r12, [r13+r14*1]
0000782c7ffd9a62  lea r14, [rax+0x28]
0000782c7ffd9a66  mov r11, [r13+r14*1]
0000782c7ffd9a6b  movq xmm12, r12
0000782c7ffd9a70  movq xmm11, r11
0000782c7ffd9a75  movq xmm12, xmm12
0000782c7ffd9a7a  movq xmm11, xmm11
0000782c7ffd9a7f  movaps xmm10, [r15+0x2D0]
0000782c7ffd9a87  vmovaps [rsp+0x20], xmm10
0000782c7ffd9a8d  vmovaps xmm9, [rsp+0x20]
0000782c7ffd9a93  por xmm10, xmm9
0000782c7ffd9a98  movaps xmm9, [r15+0x300]
0000782c7ffd9aa0  vmovaps [rsp+0x20], xmm9
0000782c7ffd9aa6  vmovaps xmm8, [rsp+0x20]
0000782c7ffd9aac  por xmm9, xmm8
0000782c7ffd9ab1  movaps xmm8, [r15+0x2B0]
0000782c7ffd9ab9  vmovaps [rsp+0x20], xmm8
0000782c7ffd9abf  vmovaps xmm7, [rsp+0x20]
0000782c7ffd9ac5  por xmm8, xmm7
0000782c7ffd9aca  movaps xmm7, [r15+0x180]
0000782c7ffd9ad2  vmovaps [rsp+0x20], xmm7
0000782c7ffd9ad8  vmovaps xmm6, [rsp+0x20]
0000782c7ffd9ade  por xmm7, xmm6
0000782c7ffd9ae2  lea r14, [rax+0x10]
0000782c7ffd9ae6  mov r12, [r13+r14*1]
0000782c7ffd9aeb  lea r14, [rax+0x18]
0000782c7ffd9aef  mov r11, [r13+r14*1]
0000782c7ffd9af4  movq xmm6, r12
0000782c7ffd9af9  movq xmm5, r11
0000782c7ffd9afe  movq xmm6, xmm6
0000782c7ffd9b02  movq xmm5, xmm5
0000782c7ffd9b06  movaps xmm4, [r15+0x200]
0000782c7ffd9b0e  vmovaps [rsp+0x20], xmm4
0000782c7ffd9b14  vmovaps xmm3, [rsp+0x20]
0000782c7ffd9b1a  por xmm4, xmm3
0000782c7ffd9b1e  movaps xmm3, [r15+0x1F0]
0000782c7ffd9b26  vmovaps [rsp+0x20], xmm3
0000782c7ffd9b2c  vmovaps xmm2, [rsp+0x20]
0000782c7ffd9b32  por xmm3, xmm2
0000782c7ffd9b36  movaps xmm2, [r15+0x2E0]
0000782c7ffd9b3e  vmovaps [rsp+0x20], xmm2
0000782c7ffd9b44  vmovaps [rsp+0x30], xmm1
0000782c7ffd9b4a  vmovaps xmm1, [rsp+0x20]
0000782c7ffd9b50  por xmm2, xmm1
0000782c7ffd9b54  movaps xmm1, [r15+0x2A0]
0000782c7ffd9b5c  vmovaps [rsp+0x20], xmm1
0000782c7ffd9b62  vmovaps [rsp+0x40], xmm15
0000782c7ffd9b68  vmovaps xmm15, [rsp+0x20]
0000782c7ffd9b6e  por xmm1, xmm15
0000782c7ffd9b73  movaps xmm15, [r15+0x280]
0000782c7ffd9b7b  vmovaps [rsp+0x20], xmm15
0000782c7ffd9b81  vmovaps [rsp+0x50], xmm1
0000782c7ffd9b87  vmovaps xmm1, [rsp+0x20]
0000782c7ffd9b8d  por xmm15, xmm1
0000782c7ffd9b92  movaps xmm1, [r15+0x1C0]
0000782c7ffd9b9a  vmovaps [rsp+0x20], xmm1
0000782c7ffd9ba0  vmovaps [rsp+0x60], xmm15
0000782c7ffd9ba6  vmovaps xmm15, [rsp+0x20]
0000782c7ffd9bac  por xmm1, xmm15
0000782c7ffd9bb1  movaps xmm15, [r15+0x210]
0000782c7ffd9bb9  vmovaps [rsp+0x20], xmm15
0000782c7ffd9bbf  vmovaps [rsp+0x70], xmm1
0000782c7ffd9bc5  vmovaps xmm1, [rsp+0x20]
0000782c7ffd9bcb  por xmm15, xmm1
0000782c7ffd9bd0  mov r14, [r13+rax*1]
0000782c7ffd9bd5  vmovq xmm1, r14
0000782c7ffd9bda  vpbroadcastq xmm1, xmm1
0000782c7ffd9bdf  vmovaps [rsp+0x20], xmm1
0000782c7ffd9be5  vxorps xmm1, xmm1, xmm1
0000782c7ffd9be9  vpbroadcastq xmm1, xmm1
0000782c7ffd9bee  mov r14, [r15+0xF8]
0000782c7ffd9bf5  vmovaps [rsp+0x80], xmm1
0000782c7ffd9bfe  movups xmm1, [r13+r14*1]
0000782c7ffd9c04  vmovaps [rsp+0x90], xmm1
0000782c7ffd9c0d  vxorps xmm1, xmm1, xmm1
0000782c7ffd9c11  vpbroadcastq xmm1, xmm1
0000782c7ffd9c16  lea r12, [rax+0x08]
0000782c7ffd9c1a  mov rax, [r13+r12*1]
0000782c7ffd9c1f  vmovaps [rsp+0xA0], xmm1
0000782c7ffd9c28  movq xmm1, rax
0000782c7ffd9c2d  movaps [r15+0x240], xmm1
0000782c7ffd9c35  mov rax, [r15+0x50]
0000782c7ffd9c39  mov [r15+0x60], rax
0000782c7ffd9c3d  mov qword ptr [r15+0x58], 0x40
0000782c7ffd9c45  vmovaps xmm1, [rsp+0x30]
0000782c7ffd9c4b  vmovaps [rsp+0x30], xmm15
0000782c7ffd9c51  vmovaps xmm15, [rsp+0x90]
0000782c7ffd9c5a  vmovaps [rsp+0x90], xmm14
0000782c7ffd9c63  vmovaps xmm14, [rsp+0x20]
0000782c7ffd9c69  vmovaps [rsp+0x20], xmm13
0000782c7ffd9c6f  vmovaps [rsp+0xB0], xmm12
0000782c7ffd9c78  movaps xmm13, xmm1
0000782c7ffd9c7c  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd9c87  vptest xmm12, xmm12
0000782c7ffd9c8c  jnz 0x0000782C7FFDA72F
0000782c7ffd9c92  movaps xmm1, [r15+0x250]
0000782c7ffd9c9a  vmovaps xmm15, [rsp+0x40]
0000782c7ffd9ca0  vmovaps [rsp+0x40], xmm13
0000782c7ffd9ca6  movaps xmm12, xmm15
0000782c7ffd9caa  vfmadd231pd xmm12, xmm1, xmm14
0000782c7ffd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
0000782c7ffd9cb5  vptest xmm13, xmm13
0000782c7ffd9cba  jnz 0x0000782C7FFDA888
0000782c7ffd9cc0  movaps xmm15, [r15+0x1E0]
0000782c7ffd9cc8  vmovaps [rsp+0xC0], xmm15
0000782c7ffd9cd1  vmovaps xmm13, [rsp+0xC0]
0000782c7ffd9cda  por xmm15, xmm13
0000782c7ffd9cdf  movaps xmm13, [r15+0x1D0]
0000782c7ffd9ce7  vmovaps [rsp+0xC0], xmm13
0000782c7ffd9cf0  vmovaps [rsp+0xD0], xmm1
0000782c7ffd9cf9  vmovaps xmm1, [rsp+0xC0]
0000782c7ffd9d02  por xmm13, xmm1
0000782c7ffd9d07  movaps xmm1, [r15+0x2C0]
0000782c7ffd9d0f  vmovaps [rsp+0xC0], xmm1
0000782c7ffd9d18  vmovaps [rsp+0xE0], xmm15
0000782c7ffd9d21  vmovaps xmm15, [rsp+0xC0]
0000782c7ffd9d2a  por xmm1, xmm15
0000782c7ffd9d2f  movaps xmm15, [r15+0x290]
0000782c7ffd9d37  vmovaps [rsp+0xC0], xmm15
0000782c7ffd9d40  vmovaps [rsp+0xF0], xmm1
0000782c7ffd9d49  vmovaps xmm1, [rsp+0xC0]
0000782c7ffd9d52  por xmm15, xmm1
0000782c7ffd9d57  movaps xmm1, [r15+0x260]
0000782c7ffd9d5f  vmovaps [rsp+0xC0], xmm1
0000782c7ffd9d68  vmovaps [rsp+0x100], xmm15
0000782c7ffd9d71  vmovaps xmm15, [rsp+0xC0]
0000782c7ffd9d7a  por xmm1, xmm15
0000782c7ffd9d7f  vmovaps xmm15, [rsp+0xD0]
0000782c7ffd9d88  vmovaps [rsp+0xC0], xmm1
0000782c7ffd9d91  vmovaps xmm1, [rsp+0xD0]
0000782c7ffd9d9a  por xmm15, xmm1
0000782c7ffd9d9f  lea r12, [r14+0xC0]
0000782c7ffd9da6  movups xmm1, [r13+r12*1]
0000782c7ffd9dac  mov [rsp+0xD0], rax
0000782c7ffd9db4  xor eax, eax
0000782c7ffd9db6  mov r12d, 0x40
0000782c7ffd9dbc  mov r11d, 0x200
0000782c7ffd9dc2  cmp r12, r11
0000782c7ffd9dc5  cmc
0000782c7ffd9dc6  lahf
0000782c7ffd9dc7  seto al
0000782c7ffd9dca  mov [r15+0x108], eax
0000782c7ffd9dd1  vmovaps [rsp+0x110], xmm1
0000782c7ffd9dda  vmovaps xmm1, [rsp+0x80]
0000782c7ffd9de3  vmovaps [rsp+0x80], xmm15
0000782c7ffd9dec  vmovaps xmm15, [rsp+0x110]
0000782c7ffd9df5  vmovaps [rsp+0x110], xmm13
0000782c7ffd9dfe  vmovaps [rsp+0x120], xmm12
0000782c7ffd9e07  movaps xmm13, xmm1
0000782c7ffd9e0b  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd9e16  vptest xmm12, xmm12
0000782c7ffd9e1b  jnz 0x0000782C7FFDA9EB
0000782c7ffd9e21  lea rax, [r14+0xB0]
0000782c7ffd9e28  movups xmm1, [r13+rax*1]
0000782c7ffd9e2e  vmovaps xmm15, [rsp+0xA0]
0000782c7ffd9e37  vmovaps [rsp+0xA0], xmm13
0000782c7ffd9e40  movaps xmm12, xmm15
0000782c7ffd9e44  vfmadd231pd xmm12, xmm1, xmm14
0000782c7ffd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
0000782c7ffd9e4f  vptest xmm13, xmm13
0000782c7ffd9e54  jnz 0x0000782C7FFDAB4E
0000782c7ffd9e5a  vmovaps xmm1, [rsp+0x30]
0000782c7ffd9e60  vmovaps xmm15, [rsp+0x30]
0000782c7ffd9e66  por xmm1, xmm15
0000782c7ffd9e6b  movaps [r15+0x210], xmm1
0000782c7ffd9e73  vmovaps xmm15, [rsp+0x70]
0000782c7ffd9e79  vmovaps xmm14, [rsp+0x70]
0000782c7ffd9e7f  por xmm15, xmm14
0000782c7ffd9e84  movaps [r15+0x1C0], xmm15
0000782c7ffd9e8c  vmovaps xmm14, [rsp+0x60]
0000782c7ffd9e92  vmovaps xmm13, [rsp+0x60]
0000782c7ffd9e98  por xmm14, xmm13
0000782c7ffd9e9d  movaps [r15+0x280], xmm14
0000782c7ffd9ea5  vmovaps xmm13, [rsp+0x50]
0000782c7ffd9eab  vmovaps [rsp+0x30], xmm1
0000782c7ffd9eb1  vmovaps xmm1, [rsp+0x50]
0000782c7ffd9eb7  por xmm13, xmm1
0000782c7ffd9ebc  movaps [r15+0x2A0], xmm13
0000782c7ffd9ec4  vmovaps [rsp+0x50], xmm2
0000782c7ffd9eca  vmovaps xmm1, [rsp+0x50]
0000782c7ffd9ed0  por xmm2, xmm1
0000782c7ffd9ed4  movaps [r15+0x2E0], xmm2
0000782c7ffd9edc  vmovaps [rsp+0x50], xmm3
0000782c7ffd9ee2  vmovaps xmm1, [rsp+0x50]
0000782c7ffd9ee8  por xmm3, xmm1
0000782c7ffd9eec  movaps [r15+0x1F0], xmm3
0000782c7ffd9ef4  vmovaps xmm1, [rsp+0x80]
0000782c7ffd9efd  vmovaps [rsp+0x50], xmm15
0000782c7ffd9f03  vmovaps xmm15, [rsp+0x80]
0000782c7ffd9f0c  por xmm1, xmm15
0000782c7ffd9f11  movaps [r15+0x250], xmm1
0000782c7ffd9f19  vmovaps xmm1, [rsp+0xC0]
0000782c7ffd9f22  vmovaps xmm15, [rsp+0xC0]
0000782c7ffd9f2b  por xmm1, xmm15
0000782c7ffd9f30  movaps [r15+0x260], xmm1
0000782c7ffd9f38  vmovaps xmm15, [rsp+0x100]
0000782c7ffd9f41  vmovaps [rsp+0x60], xmm1
0000782c7ffd9f47  vmovaps xmm1, [rsp+0x100]
0000782c7ffd9f50  por xmm15, xmm1
0000782c7ffd9f55  movaps [r15+0x290], xmm15
0000782c7ffd9f5d  vmovaps xmm1, [rsp+0xF0]
0000782c7ffd9f66  vmovaps [rsp+0x70], xmm15
0000782c7ffd9f6c  vmovaps xmm15, [rsp+0xF0]
0000782c7ffd9f75  por xmm1, xmm15
0000782c7ffd9f7a  movaps [r15+0x2C0], xmm1
0000782c7ffd9f82  movq xmm15, qword ptr [r15+0x240]
0000782c7ffd9f8b  vmovaps [rsp+0x80], xmm15
0000782c7ffd9f94  vpermilpd xmm15, xmm15, 0x00
0000782c7ffd9f9a  vmovaps [rsp+0xC0], xmm1
0000782c7ffd9fa3  vmovaps xmm1, [rsp+0x40]
0000782c7ffd9fa9  vmovaps [rsp+0x40], xmm15
0000782c7ffd9faf  vmovaps xmm15, [rsp+0x30]
0000782c7ffd9fb5  vmovaps [rsp+0x30], xmm14
0000782c7ffd9fbb  vmovaps xmm14, [rsp+0x40]
0000782c7ffd9fc1  vmovaps [rsp+0x40], xmm13
0000782c7ffd9fc7  vmovaps [rsp+0xF0], xmm12
0000782c7ffd9fd0  movaps xmm13, xmm1
0000782c7ffd9fd4  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000782c7ffd9fdf  vptest xmm12, xmm12
0000782c7ffd9fe4  jnz 0x0000782C7FFDACA7
0000782c7ffd9fea  vmovaps xmm1, [rsp+0x80]
0000782c7ffd9ff3  vpermilpd xmm1, xmm1, 0x00
0000782c7ffd9ff9  vmovaps xmm15, [rsp+0xA0]
0000782c7ffda002  movaps xmm14, xmm15
0000782c7ffda006  vfmadd231pd xmm14, xmm2, xmm1
0000782c7ffda00b  vcmppd xmm12, xmm14, xmm14, 0x03
0000782c7ffda011  vptest xmm12, xmm12
0000782c7ffda016  jnz 0x0000782C7FFDAE00
0000782c7ffda01c  vmovaps xmm1, [rsp+0x80]
0000782c7ffda025  vpermilpd xmm1, xmm1, 0x00
0000782c7ffda02b  vmovaps xmm15, [rsp+0x120]
0000782c7ffda034  vmovaps xmm12, [rsp+0x50]
0000782c7ffda03a  vmovaps [rsp+0x50], xmm14
0000782c7ffda040  movaps xmm2, xmm15
0000782c7ffda044  vfmadd231pd xmm2, xmm12, xmm1
0000782c7ffda049  vcmppd xmm14, xmm2, xmm2, 0x03
0000782c7ffda04e  vptest xmm14, xmm14
0000782c7ffda053  jnz 0x0000782C7FFDAF58
0000782c7ffda059  vmovaps xmm1, [rsp+0x110]
0000782c7ffda062  vmovaps xmm15, [rsp+0x110]
0000782c7ffda06b  por xmm1, xmm15
0000782c7ffda070  movaps [r15+0x1D0], xmm1
0000782c7ffda078  vmovaps xmm15, [rsp+0x80]
0000782c7ffda081  vpermilpd xmm15, xmm15, 0x00
0000782c7ffda087  vmovaps xmm14, [rsp+0xF0]
0000782c7ffda090  vmovaps [rsp+0x80], xmm1
0000782c7ffda099  movaps xmm12, xmm14
0000782c7ffda09d  vfmadd231pd xmm12, xmm3, xmm15
0000782c7ffda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
0000782c7ffda0a8  vptest xmm1, xmm1
0000782c7ffda0ad  jnz 0x0000782C7FFDB0AF
0000782c7ffda0b3  vmovaps [rsp+0xA0], xmm4
0000782c7ffda0bc  vmovaps xmm1, [rsp+0xA0]
0000782c7ffda0c5  por xmm4, xmm1
0000782c7ffda0c9  movaps [r15+0x200], xmm4
0000782c7ffda0d1  vmovaps xmm1, [rsp+0xE0]
0000782c7ffda0da  vmovaps xmm15, [rsp+0xE0]
0000782c7ffda0e3  por xmm1, xmm15
0000782c7ffda0e8  movaps [r15+0x1E0], xmm1
0000782c7ffda0f0  vmovaps [rsp+0xA0], xmm8
0000782c7ffda0f9  vmovaps xmm1, [rsp+0xA0]
0000782c7ffda102  por xmm8, xmm1
0000782c7ffda107  movaps [r15+0x2B0], xmm8
0000782c7ffda10f  vmovaps [rsp+0xA0], xmm9
0000782c7ffda118  vmovaps xmm1, [rsp+0xA0]
0000782c7ffda121  por xmm9, xmm1
0000782c7ffda126  movaps [r15+0x300], xmm9
0000782c7ffda12e  vmovaps [rsp+0xA0], xmm6
0000782c7ffda137  vpermilpd xmm6, xmm6, 0x00
0000782c7ffda13d  vmovaps xmm14, [rsp+0x60]
0000782c7ffda143  movaps xmm9, xmm13
0000782c7ffda147  vfmadd231pd xmm9, xmm14, xmm6
0000782c7ffda14c  vcmppd xmm3, xmm9, xmm9, 0x03
0000782c7ffda152  vptest xmm3, xmm3
0000782c7ffda157  jnz 0x0000782C7FFDB208
0000782c7ffda15d  vmovaps xmm14, [rsp+0xA0]
0000782c7ffda166  vpermilpd xmm14, xmm14, 0x00
0000782c7ffda16c  vmovaps xmm13, [rsp+0x50]
0000782c7ffda172  vmovaps xmm6, [rsp+0xC0]
0000782c7ffda17b  vmovaps [rsp+0x50], xmm1
0000782c7ffda181  movaps xmm3, xmm13
0000782c7ffda185  vfmadd231pd xmm3, xmm6, xmm14
0000782c7ffda18a  vcmppd xmm1, xmm3, xmm3, 0x03
0000782c7ffda18f  vptest xmm1, xmm1
0000782c7ffda194  jnz 0x0000782C7FFDB361
0000782c7ffda19a  vmovaps xmm1, [rsp+0xA0]
0000782c7ffda1a3  vpermilpd xmm1, xmm1, 0x00
0000782c7ffda1a9  vmovaps xmm14, [rsp+0x30]
0000782c7ffda1af  movaps xmm6, xmm2
0000782c7ffda1b2  vfmadd231pd xmm6, xmm14, xmm1
0000782c7ffda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
0000782c7ffda1bc  vptest xmm13, xmm13
0000782c7ffda1c1  jnz 0x0000782C7FFDB4B8
0000782c7ffda1c7  vmovaps xmm1, [rsp+0xA0]
0000782c7ffda1d0  vpermilpd xmm1, xmm1, 0x00
0000782c7ffda1d6  vmovaps xmm14, [rsp+0x80]
0000782c7ffda1df  movaps xmm13, xmm12
0000782c7ffda1e3  vfmadd231pd xmm13, xmm14, xmm1
0000782c7ffda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
0000782c7ffda1ee  vptest xmm2, xmm2
0000782c7ffda1f3  jnz 0x0000782C7FFDB60E
0000782c7ffda1f9  vmovaps [rsp+0x30], xmm7
0000782c7ffda1ff  vmovaps xmm1, [rsp+0x30]
0000782c7ffda205  por xmm7, xmm1
0000782c7ffda209  movaps [r15+0x180], xmm7
0000782c7ffda211  vmovaps [rsp+0x30], xmm10
0000782c7ffda217  vmovaps xmm1, [rsp+0x30]
0000782c7ffda21d  por xmm10, xmm1
0000782c7ffda222  movaps [r15+0x2D0], xmm10
0000782c7ffda22a  vmovaps [rsp+0x30], xmm5
0000782c7ffda230  vpermilpd xmm5, xmm5, 0x00
0000782c7ffda236  vmovaps xmm14, [rsp+0x50]
0000782c7ffda23c  movaps xmm12, xmm3
0000782c7ffda240  vfmadd231pd xmm12, xmm14, xmm5
0000782c7ffda245  vcmppd xmm10, xmm12, xmm12, 0x03
0000782c7ffda24b  vptest xmm10, xmm10
0000782c7ffda250  jnz 0x0000782C7FFDB767
0000782c7ffda256  vmovaps xmm14, [rsp+0x30]
0000782c7ffda25c  vpermilpd xmm14, xmm14, 0x00
0000782c7ffda262  movaps xmm10, xmm9
0000782c7ffda266  vfmadd231pd xmm10, xmm7, xmm14
0000782c7ffda26b  vcmppd xmm5, xmm10, xmm10, 0x03
0000782c7ffda271  vptest xmm5, xmm5
0000782c7ffda276  jnz 0x0000782C7FFDB8BF
0000782c7ffda27c  lea rax, [r14+0x80]
0000782c7ffda283  movups xmm14, [r13+rax*1]
0000782c7ffda289  movaps [r15+0x2F0], xmm14
0000782c7ffda291  vmovaps xmm9, [rsp+0x30]
0000782c7ffda297  vpermilpd xmm9, xmm9, 0x00
0000782c7ffda29d  vmovaps xmm7, [rsp+0x70]
0000782c7ffda2a3  movaps xmm5, xmm6
0000782c7ffda2a6  vfmadd231pd xmm5, xmm7, xmm9
0000782c7ffda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
0000782c7ffda2b0  vptest xmm3, xmm3
0000782c7ffda2b5  jnz 0x0000782C7FFDBA22
0000782c7ffda2bb  vmovaps xmm9, [rsp+0x30]
0000782c7ffda2c1  vpermilpd xmm9, xmm9, 0x00
0000782c7ffda2c7  movaps xmm7, xmm13
0000782c7ffda2cb  vfmadd231pd xmm7, xmm1, xmm9
0000782c7ffda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
0000782c7ffda2d5  vptest xmm6, xmm6
0000782c7ffda2da  jnz 0x0000782C7FFDBB78
0000782c7ffda2e0  vmovaps xmm1, [rsp+0x20]
0000782c7ffda2e6  vmovaps xmm13, [rsp+0x20]
0000782c7ffda2ec  por xmm1, xmm13
0000782c7ffda2f1  movaps [r15+0x160], xmm1
0000782c7ffda2f9  lea rax, [r14+0x40]
0000782c7ffda2fd  movups xmm13, [r13+rax*1]
0000782c7ffda303  lea rax, [r14+0x50]
0000782c7ffda307  movups xmm9, [r13+rax*1]
0000782c7ffda30d  movaps [r15+0x1B0], xmm13
0000782c7ffda315  movaps [r15+0x1A0], xmm9
0000782c7ffda31d  movaps xmm6, [r15+0x190]
0000782c7ffda325  vmovaps xmm3, [rsp+0xB0]
0000782c7ffda32e  vpermilpd xmm3, xmm3, 0x00
0000782c7ffda334  vmovaps [rsp+0x20], xmm1
0000782c7ffda33a  movaps xmm2, xmm12
0000782c7ffda33e  vfmadd231pd xmm2, xmm6, xmm3
0000782c7ffda343  vcmppd xmm1, xmm2, xmm2, 0x03
0000782c7ffda348  vptest xmm1, xmm1
0000782c7ffda34d  jnz 0x0000782C7FFDBCE3
0000782c7ffda353  vmovaps xmm1, [rsp+0xB0]
0000782c7ffda35c  vpermilpd xmm1, xmm1, 0x00
0000782c7ffda362  vmovaps xmm12, [rsp+0x20]
0000782c7ffda368  movaps xmm6, xmm10
0000782c7ffda36c  vfmadd231pd xmm6, xmm12, xmm1
0000782c7ffda371  vcmppd xmm3, xmm6, xmm6, 0x03
0000782c7ffda376  vptest xmm3, xmm3
0000782c7ffda37b  jnz 0x0000782C7FFDBE39
0000782c7ffda381  vmovaps xmm1, [rsp+0xB0]
0000782c7ffda38a  vpermilpd xmm1, xmm1, 0x00
0000782c7ffda390  vmovaps xmm12, [rsp+0x40]
0000782c7ffda396  movaps xmm10, xmm5
0000782c7ffda39a  vfmadd231pd xmm10, xmm12, xmm1
0000782c7ffda39f  vcmppd xmm3, xmm10, xmm10, 0x03
0000782c7ffda3a5  vptest xmm3, xmm3
0000782c7ffda3aa  jnz 0x0000782C7FFDBF90
0000782c7ffda3b0  vmovaps xmm1, [rsp+0xB0]
0000782c7ffda3b9  vpermilpd xmm1, xmm1, 0x00
0000782c7ffda3bf  movaps xmm12, xmm7
0000782c7ffda3c3  vfmadd231pd xmm12, xmm15, xmm1
0000782c7ffda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
0000782c7ffda3ce  vptest xmm5, xmm5
0000782c7ffda3d3  jnz 0x0000782C7FFDC0E8
0000782c7ffda3d9  lea rax, [r14+0x60]
0000782c7ffda3dd  movups xmm1, [r13+rax*1]
0000782c7ffda3e3  lea rax, [r14+0x70]
0000782c7ffda3e7  movups xmm15, [r13+rax*1]
0000782c7ffda3ed  movaps [r15+0x150], xmm1
0000782c7ffda3f5  movaps [r15+0x120], xmm15
0000782c7ffda3fd  vmovaps [rsp+0x20], xmm11
0000782c7ffda403  vpermilpd xmm11, xmm11, 0x00
0000782c7ffda409  movaps xmm7, xmm2
0000782c7ffda40c  vfmadd231pd xmm7, xmm9, xmm11
0000782c7ffda411  vcmppd xmm5, xmm7, xmm7, 0x03
0000782c7ffda416  vptest xmm5, xmm5
0000782c7ffda41b  jnz 0x0000782C7FFDC254
0000782c7ffda421  vmovaps xmm11, [rsp+0x20]
0000782c7ffda427  vpermilpd xmm11, xmm11, 0x00
0000782c7ffda42d  movaps xmm9, xmm6
0000782c7ffda431  vfmadd231pd xmm9, xmm1, xmm11
0000782c7ffda436  vcmppd xmm5, xmm9, xmm9, 0x03
0000782c7ffda43c  vptest xmm5, xmm5
0000782c7ffda441  jnz 0x0000782C7FFDC3AB
0000782c7ffda447  vmovaps xmm1, [rsp+0x20]
0000782c7ffda44d  vpermilpd xmm1, xmm1, 0x00
0000782c7ffda453  movaps xmm11, xmm10
0000782c7ffda457  vfmadd231pd xmm11, xmm8, xmm1
0000782c7ffda45c  vcmppd xmm6, xmm11, xmm11, 0x03
0000782c7ffda462  vptest xmm6, xmm6
0000782c7ffda467  jnz 0x0000782C7FFDC503
0000782c7ffda46d  vmovaps xmm1, [rsp+0x20]
0000782c7ffda473  vpermilpd xmm1, xmm1, 0x00
0000782c7ffda479  movaps xmm10, xmm12
0000782c7ffda47d  vfmadd231pd xmm10, xmm13, xmm1
0000782c7ffda482  vcmppd xmm8, xmm10, xmm10, 0x03
0000782c7ffda488  vptest xmm8, xmm8
0000782c7ffda48d  jnz 0x0000782C7FFDC65C
0000782c7ffda493  lea rax, [r14+0x20]
0000782c7ffda497  movups xmm1, [r13+rax*1]
0000782c7ffda49d  lea rax, [r14+0x30]
0000782c7ffda4a1  movups xmm13, [r13+rax*1]
0000782c7ffda4a7  vmovaps xmm12, [rsp+0x90]
0000782c7ffda4b0  vpermilpd xmm12, xmm12, 0x00
0000782c7ffda4b6  movaps xmm8, xmm7
0000782c7ffda4ba  vfmadd231pd xmm8, xmm4, xmm12
0000782c7ffda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
0000782c7ffda4c5  vptest xmm6, xmm6
0000782c7ffda4ca  jnz 0x0000782C7FFDC7C9
0000782c7ffda4d0  vmovaps xmm12, [rsp+0x90]
0000782c7ffda4d9  vpermilpd xmm12, xmm12, 0x00
0000782c7ffda4df  movaps xmm7, xmm9
0000782c7ffda4e3  vfmadd231pd xmm7, xmm14, xmm12
0000782c7ffda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
0000782c7ffda4ed  vptest xmm6, xmm6
0000782c7ffda4f2  jnz 0x0000782C7FFDC921
0000782c7ffda4f8  vmovaps xmm14, [rsp+0x90]
0000782c7ffda501  vpermilpd xmm14, xmm14, 0x00
0000782c7ffda507  movaps xmm12, xmm11
0000782c7ffda50b  vfmadd231pd xmm12, xmm15, xmm14
0000782c7ffda510  vcmppd xmm9, xmm12, xmm12, 0x03
0000782c7ffda516  vptest xmm9, xmm9
0000782c7ffda51b  jnz 0x0000782C7FFDCA79
0000782c7ffda521  vmovaps xmm15, [rsp+0x90]
0000782c7ffda52a  vpermilpd xmm15, xmm15, 0x00
0000782c7ffda530  movaps xmm11, xmm10
0000782c7ffda534  vfmadd231pd xmm11, xmm13, xmm15
0000782c7ffda539  vcmppd xmm14, xmm11, xmm11, 0x03
0000782c7ffda53f  vptest xmm14, xmm14
0000782c7ffda544  jnz 0x0000782C7FFDCBD3
0000782c7ffda54a  lea rax, [r14+0x90]
0000782c7ffda551  movups xmm15, [r13+rax*1]
0000782c7ffda557  lea rax, [r14+0xA0]
0000782c7ffda55e  movups xmm14, [r13+rax*1]
0000782c7ffda564  movaps [r15+0x140], xmm15
0000782c7ffda56c  movaps [r15+0x130], xmm14
0000782c7ffda574  vmovaps xmm13, [rsp+0x10]
0000782c7ffda57a  vpermilpd xmm13, xmm13, 0x00
0000782c7ffda580  movaps xmm10, xmm8
0000782c7ffda584  vfmadd231pd xmm10, xmm1, xmm13
0000782c7ffda589  vcmppd xmm9, xmm10, xmm10, 0x03
0000782c7ffda58f  vptest xmm9, xmm9
0000782c7ffda594  jnz 0x0000782C7FFDCD41
0000782c7ffda59a  movaps [r15+0x220], xmm10
0000782c7ffda5a2  lea rax, [r14+0x10]
0000782c7ffda5a6  movups xmm1, [r13+rax*1]
0000782c7ffda5ac  movaps [r15+0x240], xmm1
0000782c7ffda5b4  vmovaps xmm13, [rsp+0x10]
0000782c7ffda5ba  vpermilpd xmm13, xmm13, 0x00
0000782c7ffda5c0  movaps xmm9, xmm7
0000782c7ffda5c4  vfmadd231pd xmm9, xmm14, xmm13
0000782c7ffda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
0000782c7ffda5cf  vptest xmm8, xmm8
0000782c7ffda5d4  jnz 0x0000782C7FFDCEA4
0000782c7ffda5da  movaps [r15+0x110], xmm9
0000782c7ffda5e2  vmovaps xmm14, [rsp+0x10]
0000782c7ffda5e8  vpermilpd xmm14, xmm14, 0x00
0000782c7ffda5ee  movaps xmm13, xmm12
0000782c7ffda5f2  vfmadd231pd xmm13, xmm15, xmm14
0000782c7ffda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
0000782c7ffda5fd  vptest xmm8, xmm8
0000782c7ffda602  jnz 0x0000782C7FFDCFFD
0000782c7ffda608  movaps [r15+0x170], xmm13
0000782c7ffda610  vmovaps xmm15, [rsp+0x10]
0000782c7ffda616  vpermilpd xmm15, xmm15, 0x00
0000782c7ffda61c  movaps xmm14, xmm11
0000782c7ffda620  vfmadd231pd xmm14, xmm1, xmm15
0000782c7ffda625  vcmppd xmm12, xmm14, xmm14, 0x03
0000782c7ffda62b  vptest xmm12, xmm12
0000782c7ffda630  jnz 0x0000782C7FFDD157
0000782c7ffda636  movaps [r15+0x230], xmm14
0000782c7ffda63e  mov rax, [rsp+0xD0]
0000782c7ffda646  movups [r13+rax*1], xmm9
0000782c7ffda64c  lea r14, [rax+0x10]
0000782c7ffda650  movups [r13+r14*1], xmm13
0000782c7ffda656  lea r14, [rax+0x20]
0000782c7ffda65a  movups [r13+r14*1], xmm10
0000782c7ffda660  lea r14, [rax+0x30]
0000782c7ffda664  movups [r13+r14*1], xmm14
0000782c7ffda66a  mov eax, [r15+0x108]
0000782c7ffda671  sahf
0000782c7ffda672  jnz 0x0000782C7FFDA6A4
0000782c7ffda674  cmp dword ptr [r15+0x318], 0x00
0000782c7ffda67c  jz 0x0000782C7FFD9950
0000782c7ffda682  nop [rax+rax*1], ax
0000782c7ffda68b  nop [rax+rax*1], eax
0000782c7ffda693  mov eax, 0x410664
0000782c7ffda698  mov [r15+0x100], rax
0000782c7ffda69f  jmp 0x0000782C7FDFE110
0000782c7ffda6a4  cmp dword ptr [r15+0x318], 0x00
0000782c7ffda6ac  jz 0x0000782C7FFD6050
0000782c7ffda6b2  nop [rax+rax*1], ax
0000782c7ffda6bb  nop [rax+rax*1], eax
0000782c7ffda6c3  mov eax, 0x4104F0
0000782c7ffda6c8  mov [r15+0x100], rax
0000782c7ffda6cf  jmp 0x0000782C7FDFE110
0000782c7ffda6d4  int3
0000782c7ffda6d5  call 0x0000782C7FEE27E0
0000782c7ffda6da  jmp 0x0000782C7FFD9A10
0000782c7ffda6df  call 0x0000782C7FEE1570
0000782c7ffda6e4  jmp 0x0000782C7FFD9A19
0000782c7ffda6e9  call 0x0000782C7FEE27E0
0000782c7ffda6ee  jmp 0x0000782C7FFD9A62
0000782c7ffda6f3  call 0x0000782C7FEE1570
0000782c7ffda6f8  jmp 0x0000782C7FFD9A6B
0000782c7ffda6fd  call 0x0000782C7FEE27E0
0000782c7ffda702  jmp 0x0000782C7FFD9AEB
0000782c7ffda707  call 0x0000782C7FEE1570
0000782c7ffda70c  jmp 0x0000782C7FFD9AF4
0000782c7ffda711  call 0x0000782C7FE0DC20
0000782c7ffda716  jmp 0x0000782C7FFD9BD5
0000782c7ffda71b  call 0x0000782C7FED64F0
0000782c7ffda720  jmp 0x0000782C7FFD9C04
0000782c7ffda725  call 0x0000782C7FEB47C0
0000782c7ffda72a  jmp 0x0000782C7FFD9C1F
0000782c7ffda72f  sub rsp, 0x08
0000782c7ffda733  push rax
0000782c7ffda734  push rcx
0000782c7ffda735  push rdx
0000782c7ffda736  push rdi
0000782c7ffda737  push rsi
0000782c7ffda738  push r8
0000782c7ffda73a  push r9
0000782c7ffda73c  push r10
0000782c7ffda73e  push r11
0000782c7ffda740  sub rsp, 0xF0
0000782c7ffda747  vmovaps [rsp], xmm0
0000782c7ffda74c  vmovaps [rsp+0x10], xmm1
0000782c7ffda752  vmovaps [rsp+0x20], xmm2
0000782c7ffda758  vmovaps [rsp+0x30], xmm3
0000782c7ffda75e  vmovaps [rsp+0x40], xmm4
0000782c7ffda764  vmovaps [rsp+0x50], xmm5
0000782c7ffda76a  vmovaps [rsp+0x60], xmm6
0000782c7ffda770  vmovaps [rsp+0x70], xmm7
0000782c7ffda776  vmovaps [rsp+0x80], xmm8
0000782c7ffda77f  vmovaps [rsp+0x90], xmm9
0000782c7ffda788  vmovaps [rsp+0xA0], xmm10
0000782c7ffda791  vmovaps [rsp+0xB0], xmm11
0000782c7ffda79a  vmovaps [rsp+0xC0], xmm12
0000782c7ffda7a3  vmovaps [rsp+0xD0], xmm14
0000782c7ffda7ac  vmovaps [rsp+0xE0], xmm15
0000782c7ffda7b5  sub rsp, 0x40
0000782c7ffda7b9  lea rdi, [rsp]
0000782c7ffda7bd  lea rsi, [rsp+0x10]
0000782c7ffda7c2  lea rdx, [rsp+0x20]
0000782c7ffda7c7  lea rcx, [rsp+0x30]
0000782c7ffda7cc  mov r8d, 0x00
0000782c7ffda7d2  lea r9, [r15+0x3A8]
0000782c7ffda7d9  movaps [rdi], xmm13
0000782c7ffda7dd  movaps [rsi], xmm1
0000782c7ffda7e0  movaps [rdx], xmm15
0000782c7ffda7e4  movaps [rcx], xmm14
0000782c7ffda7e8  mov rax, 0x5AE5BFFB5A50
0000782c7ffda7f2  call rax
0000782c7ffda7f4  movaps xmm13, [rsp]
0000782c7ffda7f9  add rsp, 0x40
0000782c7ffda7fd  vmovaps xmm0, [rsp]
0000782c7ffda802  vmovaps xmm1, [rsp+0x10]
0000782c7ffda808  vmovaps xmm2, [rsp+0x20]
0000782c7ffda80e  vmovaps xmm3, [rsp+0x30]
0000782c7ffda814  vmovaps xmm4, [rsp+0x40]
0000782c7ffda81a  vmovaps xmm5, [rsp+0x50]
0000782c7ffda820  vmovaps xmm6, [rsp+0x60]
0000782c7ffda826  vmovaps xmm7, [rsp+0x70]
0000782c7ffda82c  vmovaps xmm8, [rsp+0x80]
0000782c7ffda835  vmovaps xmm9, [rsp+0x90]
0000782c7ffda83e  vmovaps xmm10, [rsp+0xA0]
0000782c7ffda847  vmovaps xmm11, [rsp+0xB0]
0000782c7ffda850  vmovaps xmm12, [rsp+0xC0]
0000782c7ffda859  vmovaps xmm14, [rsp+0xD0]
0000782c7ffda862  vmovaps xmm15, [rsp+0xE0]
0000782c7ffda86b  add rsp, 0xF0
0000782c7ffda872  pop r11
0000782c7ffda874  pop r10
0000782c7ffda876  pop r9
0000782c7ffda878  pop r8
0000782c7ffda87a  pop rsi
0000782c7ffda87b  pop rdi
0000782c7ffda87c  pop rdx
0000782c7ffda87d  pop rcx
0000782c7ffda87e  pop rax
0000782c7ffda87f  add rsp, 0x08
0000782c7ffda883  jmp 0x0000782C7FFD9C92
0000782c7ffda888  sub rsp, 0x08
0000782c7ffda88c  push rax
0000782c7ffda88d  push rcx
0000782c7ffda88e  push rdx
0000782c7ffda88f  push rdi
0000782c7ffda890  push rsi
0000782c7ffda891  push r8
0000782c7ffda893  push r9
0000782c7ffda895  push r10
0000782c7ffda897  push r11
0000782c7ffda899  sub rsp, 0xF0
0000782c7ffda8a0  vmovaps [rsp], xmm0
0000782c7ffda8a5  vmovaps [rsp+0x10], xmm1
0000782c7ffda8ab  vmovaps [rsp+0x20], xmm2
0000782c7ffda8b1  vmovaps [rsp+0x30], xmm3
0000782c7ffda8b7  vmovaps [rsp+0x40], xmm4
0000782c7ffda8bd  vmovaps [rsp+0x50], xmm5
0000782c7ffda8c3  vmovaps [rsp+0x60], xmm6
0000782c7ffda8c9  vmovaps [rsp+0x70], xmm7
0000782c7ffda8cf  vmovaps [rsp+0x80], xmm8
0000782c7ffda8d8  vmovaps [rsp+0x90], xmm9
0000782c7ffda8e1  vmovaps [rsp+0xA0], xmm10
0000782c7ffda8ea  vmovaps [rsp+0xB0], xmm11
0000782c7ffda8f3  vmovaps [rsp+0xC0], xmm13
0000782c7ffda8fc  vmovaps [rsp+0xD0], xmm14
0000782c7ffda905  vmovaps [rsp+0xE0], xmm15
0000782c7ffda90e  sub rsp, 0x40
0000782c7ffda912  lea rdi, [rsp]
0000782c7ffda916  lea rsi, [rsp+0x10]
0000782c7ffda91b  lea rdx, [rsp+0x20]
0000782c7ffda920  lea rcx, [rsp+0x30]
0000782c7ffda925  mov r8d, 0x00
0000782c7ffda92b  lea r9, [r15+0x3A8]
0000782c7ffda932  movaps [rdi], xmm12
0000782c7ffda936  movaps [rsi], xmm15
0000782c7ffda93a  movaps [rdx], xmm1
0000782c7ffda93d  movaps [rcx], xmm14
0000782c7ffda941  mov rax, 0x5AE5BFFB5A50
0000782c7ffda94b  call rax
0000782c7ffda94d  movaps xmm12, [rsp]
0000782c7ffda952  add rsp, 0x40
0000782c7ffda956  vmovaps xmm0, [rsp]
0000782c7ffda95b  vmovaps xmm1, [rsp+0x10]
0000782c7ffda961  vmovaps xmm2, [rsp+0x20]
0000782c7ffda967  vmovaps xmm3, [rsp+0x30]
0000782c7ffda96d  vmovaps xmm4, [rsp+0x40]
0000782c7ffda973  vmovaps xmm5, [rsp+0x50]
0000782c7ffda979  vmovaps xmm6, [rsp+0x60]
0000782c7ffda97f  vmovaps xmm7, [rsp+0x70]
0000782c7ffda985  vmovaps xmm8, [rsp+0x80]
0000782c7ffda98e  vmovaps xmm9, [rsp+0x90]
0000782c7ffda997  vmovaps xmm10, [rsp+0xA0]
0000782c7ffda9a0  vmovaps xmm11, [rsp+0xB0]
0000782c7ffda9a9  vmovaps xmm13, [rsp+0xC0]
0000782c7ffda9b2  vmovaps xmm14, [rsp+0xD0]
0000782c7ffda9bb  vmovaps xmm15, [rsp+0xE0]
0000782c7ffda9c4  add rsp, 0xF0
0000782c7ffda9cb  pop r11
0000782c7ffda9cd  pop r10
0000782c7ffda9cf  pop r9
0000782c7ffda9d1  pop r8
0000782c7ffda9d3  pop rsi
0000782c7ffda9d4  pop rdi
0000782c7ffda9d5  pop rdx
0000782c7ffda9d6  pop rcx
0000782c7ffda9d7  pop rax
0000782c7ffda9d8  add rsp, 0x08
0000782c7ffda9dc  jmp 0x0000782C7FFD9CC0
0000782c7ffda9e1  call 0x0000782C7FEB52F0
0000782c7ffda9e6  jmp 0x0000782C7FFD9DAC
0000782c7ffda9eb  sub rsp, 0x08
0000782c7ffda9ef  push rax
0000782c7ffda9f0  push rcx
0000782c7ffda9f1  push rdx
0000782c7ffda9f2  push rdi
0000782c7ffda9f3  push rsi
0000782c7ffda9f4  push r8
0000782c7ffda9f6  push r9
0000782c7ffda9f8  push r10
0000782c7ffda9fa  push r11
0000782c7ffda9fc  sub rsp, 0xF0
0000782c7ffdaa03  vmovaps [rsp], xmm0
0000782c7ffdaa08  vmovaps [rsp+0x10], xmm1
0000782c7ffdaa0e  vmovaps [rsp+0x20], xmm2
0000782c7ffdaa14  vmovaps [rsp+0x30], xmm3
0000782c7ffdaa1a  vmovaps [rsp+0x40], xmm4
0000782c7ffdaa20  vmovaps [rsp+0x50], xmm5
0000782c7ffdaa26  vmovaps [rsp+0x60], xmm6
0000782c7ffdaa2c  vmovaps [rsp+0x70], xmm7
0000782c7ffdaa32  vmovaps [rsp+0x80], xmm8
0000782c7ffdaa3b  vmovaps [rsp+0x90], xmm9
0000782c7ffdaa44  vmovaps [rsp+0xA0], xmm10
0000782c7ffdaa4d  vmovaps [rsp+0xB0], xmm11
0000782c7ffdaa56  vmovaps [rsp+0xC0], xmm12
0000782c7ffdaa5f  vmovaps [rsp+0xD0], xmm14
0000782c7ffdaa68  vmovaps [rsp+0xE0], xmm15
0000782c7ffdaa71  sub rsp, 0x40
0000782c7ffdaa75  lea rdi, [rsp]
0000782c7ffdaa79  lea rsi, [rsp+0x10]
0000782c7ffdaa7e  lea rdx, [rsp+0x20]
0000782c7ffdaa83  lea rcx, [rsp+0x30]
0000782c7ffdaa88  mov r8d, 0x00
0000782c7ffdaa8e  lea r9, [r15+0x3A8]
0000782c7ffdaa95  movaps [rdi], xmm13
0000782c7ffdaa99  movaps [rsi], xmm1
0000782c7ffdaa9c  movaps [rdx], xmm15
0000782c7ffdaaa0  movaps [rcx], xmm14
0000782c7ffdaaa4  mov rax, 0x5AE5BFFB5A50
0000782c7ffdaaae  call rax
0000782c7ffdaab0  movaps xmm13, [rsp]
0000782c7ffdaab5  add rsp, 0x40
0000782c7ffdaab9  vmovaps xmm0, [rsp]
0000782c7ffdaabe  vmovaps xmm1, [rsp+0x10]
0000782c7ffdaac4  vmovaps xmm2, [rsp+0x20]
0000782c7ffdaaca  vmovaps xmm3, [rsp+0x30]
0000782c7ffdaad0  vmovaps xmm4, [rsp+0x40]
0000782c7ffdaad6  vmovaps xmm5, [rsp+0x50]
0000782c7ffdaadc  vmovaps xmm6, [rsp+0x60]
0000782c7ffdaae2  vmovaps xmm7, [rsp+0x70]
0000782c7ffdaae8  vmovaps xmm8, [rsp+0x80]
0000782c7ffdaaf1  vmovaps xmm9, [rsp+0x90]
0000782c7ffdaafa  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdab03  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdab0c  vmovaps xmm12, [rsp+0xC0]
0000782c7ffdab15  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdab1e  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdab27  add rsp, 0xF0
0000782c7ffdab2e  pop r11
0000782c7ffdab30  pop r10
0000782c7ffdab32  pop r9
0000782c7ffdab34  pop r8
0000782c7ffdab36  pop rsi
0000782c7ffdab37  pop rdi
0000782c7ffdab38  pop rdx
0000782c7ffdab39  pop rcx
0000782c7ffdab3a  pop rax
0000782c7ffdab3b  add rsp, 0x08
0000782c7ffdab3f  jmp 0x0000782C7FFD9E21
0000782c7ffdab44  call 0x0000782C7FDFF430
0000782c7ffdab49  jmp 0x0000782C7FFD9E2E
0000782c7ffdab4e  sub rsp, 0x08
0000782c7ffdab52  push rax
0000782c7ffdab53  push rcx
0000782c7ffdab54  push rdx
0000782c7ffdab55  push rdi
0000782c7ffdab56  push rsi
0000782c7ffdab57  push r8
0000782c7ffdab59  push r9
0000782c7ffdab5b  push r10
0000782c7ffdab5d  push r11
0000782c7ffdab5f  sub rsp, 0xF0
0000782c7ffdab66  vmovaps [rsp], xmm0
0000782c7ffdab6b  vmovaps [rsp+0x10], xmm1
0000782c7ffdab71  vmovaps [rsp+0x20], xmm2
0000782c7ffdab77  vmovaps [rsp+0x30], xmm3
0000782c7ffdab7d  vmovaps [rsp+0x40], xmm4
0000782c7ffdab83  vmovaps [rsp+0x50], xmm5
0000782c7ffdab89  vmovaps [rsp+0x60], xmm6
0000782c7ffdab8f  vmovaps [rsp+0x70], xmm7
0000782c7ffdab95  vmovaps [rsp+0x80], xmm8
0000782c7ffdab9e  vmovaps [rsp+0x90], xmm9
0000782c7ffdaba7  vmovaps [rsp+0xA0], xmm10
0000782c7ffdabb0  vmovaps [rsp+0xB0], xmm11
0000782c7ffdabb9  vmovaps [rsp+0xC0], xmm13
0000782c7ffdabc2  vmovaps [rsp+0xD0], xmm14
0000782c7ffdabcb  vmovaps [rsp+0xE0], xmm15
0000782c7ffdabd4  sub rsp, 0x40
0000782c7ffdabd8  lea rdi, [rsp]
0000782c7ffdabdc  lea rsi, [rsp+0x10]
0000782c7ffdabe1  lea rdx, [rsp+0x20]
0000782c7ffdabe6  lea rcx, [rsp+0x30]
0000782c7ffdabeb  mov r8d, 0x00
0000782c7ffdabf1  lea r9, [r15+0x3A8]
0000782c7ffdabf8  movaps [rdi], xmm12
0000782c7ffdabfc  movaps [rsi], xmm15
0000782c7ffdac00  movaps [rdx], xmm1
0000782c7ffdac03  movaps [rcx], xmm14
0000782c7ffdac07  mov rax, 0x5AE5BFFB5A50
0000782c7ffdac11  call rax
0000782c7ffdac13  movaps xmm12, [rsp]
0000782c7ffdac18  add rsp, 0x40
0000782c7ffdac1c  vmovaps xmm0, [rsp]
0000782c7ffdac21  vmovaps xmm1, [rsp+0x10]
0000782c7ffdac27  vmovaps xmm2, [rsp+0x20]
0000782c7ffdac2d  vmovaps xmm3, [rsp+0x30]
0000782c7ffdac33  vmovaps xmm4, [rsp+0x40]
0000782c7ffdac39  vmovaps xmm5, [rsp+0x50]
0000782c7ffdac3f  vmovaps xmm6, [rsp+0x60]
0000782c7ffdac45  vmovaps xmm7, [rsp+0x70]
0000782c7ffdac4b  vmovaps xmm8, [rsp+0x80]
0000782c7ffdac54  vmovaps xmm9, [rsp+0x90]
0000782c7ffdac5d  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdac66  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdac6f  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdac78  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdac81  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdac8a  add rsp, 0xF0
0000782c7ffdac91  pop r11
0000782c7ffdac93  pop r10
0000782c7ffdac95  pop r9
0000782c7ffdac97  pop r8
0000782c7ffdac99  pop rsi
0000782c7ffdac9a  pop rdi
0000782c7ffdac9b  pop rdx
0000782c7ffdac9c  pop rcx
0000782c7ffdac9d  pop rax
0000782c7ffdac9e  add rsp, 0x08
0000782c7ffdaca2  jmp 0x0000782C7FFD9E5A
0000782c7ffdaca7  sub rsp, 0x08
0000782c7ffdacab  push rax
0000782c7ffdacac  push rcx
0000782c7ffdacad  push rdx
0000782c7ffdacae  push rdi
0000782c7ffdacaf  push rsi
0000782c7ffdacb0  push r8
0000782c7ffdacb2  push r9
0000782c7ffdacb4  push r10
0000782c7ffdacb6  push r11
0000782c7ffdacb8  sub rsp, 0xF0
0000782c7ffdacbf  vmovaps [rsp], xmm0
0000782c7ffdacc4  vmovaps [rsp+0x10], xmm1
0000782c7ffdacca  vmovaps [rsp+0x20], xmm2
0000782c7ffdacd0  vmovaps [rsp+0x30], xmm3
0000782c7ffdacd6  vmovaps [rsp+0x40], xmm4
0000782c7ffdacdc  vmovaps [rsp+0x50], xmm5
0000782c7ffdace2  vmovaps [rsp+0x60], xmm6
0000782c7ffdace8  vmovaps [rsp+0x70], xmm7
0000782c7ffdacee  vmovaps [rsp+0x80], xmm8
0000782c7ffdacf7  vmovaps [rsp+0x90], xmm9
0000782c7ffdad00  vmovaps [rsp+0xA0], xmm10
0000782c7ffdad09  vmovaps [rsp+0xB0], xmm11
0000782c7ffdad12  vmovaps [rsp+0xC0], xmm12
0000782c7ffdad1b  vmovaps [rsp+0xD0], xmm14
0000782c7ffdad24  vmovaps [rsp+0xE0], xmm15
0000782c7ffdad2d  sub rsp, 0x40
0000782c7ffdad31  lea rdi, [rsp]
0000782c7ffdad35  lea rsi, [rsp+0x10]
0000782c7ffdad3a  lea rdx, [rsp+0x20]
0000782c7ffdad3f  lea rcx, [rsp+0x30]
0000782c7ffdad44  mov r8d, 0x00
0000782c7ffdad4a  lea r9, [r15+0x3A8]
0000782c7ffdad51  movaps [rdi], xmm13
0000782c7ffdad55  movaps [rsi], xmm1
0000782c7ffdad58  movaps [rdx], xmm15
0000782c7ffdad5c  movaps [rcx], xmm14
0000782c7ffdad60  mov rax, 0x5AE5BFFB5A50
0000782c7ffdad6a  call rax
0000782c7ffdad6c  movaps xmm13, [rsp]
0000782c7ffdad71  add rsp, 0x40
0000782c7ffdad75  vmovaps xmm0, [rsp]
0000782c7ffdad7a  vmovaps xmm1, [rsp+0x10]
0000782c7ffdad80  vmovaps xmm2, [rsp+0x20]
0000782c7ffdad86  vmovaps xmm3, [rsp+0x30]
0000782c7ffdad8c  vmovaps xmm4, [rsp+0x40]
0000782c7ffdad92  vmovaps xmm5, [rsp+0x50]
0000782c7ffdad98  vmovaps xmm6, [rsp+0x60]
0000782c7ffdad9e  vmovaps xmm7, [rsp+0x70]
0000782c7ffdada4  vmovaps xmm8, [rsp+0x80]
0000782c7ffdadad  vmovaps xmm9, [rsp+0x90]
0000782c7ffdadb6  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdadbf  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdadc8  vmovaps xmm12, [rsp+0xC0]
0000782c7ffdadd1  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdadda  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdade3  add rsp, 0xF0
0000782c7ffdadea  pop r11
0000782c7ffdadec  pop r10
0000782c7ffdadee  pop r9
0000782c7ffdadf0  pop r8
0000782c7ffdadf2  pop rsi
0000782c7ffdadf3  pop rdi
0000782c7ffdadf4  pop rdx
0000782c7ffdadf5  pop rcx
0000782c7ffdadf6  pop rax
0000782c7ffdadf7  add rsp, 0x08
0000782c7ffdadfb  jmp 0x0000782C7FFD9FEA
0000782c7ffdae00  sub rsp, 0x08
0000782c7ffdae04  push rax
0000782c7ffdae05  push rcx
0000782c7ffdae06  push rdx
0000782c7ffdae07  push rdi
0000782c7ffdae08  push rsi
0000782c7ffdae09  push r8
0000782c7ffdae0b  push r9
0000782c7ffdae0d  push r10
0000782c7ffdae0f  push r11
0000782c7ffdae11  sub rsp, 0xF0
0000782c7ffdae18  vmovaps [rsp], xmm0
0000782c7ffdae1d  vmovaps [rsp+0x10], xmm1
0000782c7ffdae23  vmovaps [rsp+0x20], xmm2
0000782c7ffdae29  vmovaps [rsp+0x30], xmm3
0000782c7ffdae2f  vmovaps [rsp+0x40], xmm4
0000782c7ffdae35  vmovaps [rsp+0x50], xmm5
0000782c7ffdae3b  vmovaps [rsp+0x60], xmm6
0000782c7ffdae41  vmovaps [rsp+0x70], xmm7
0000782c7ffdae47  vmovaps [rsp+0x80], xmm8
0000782c7ffdae50  vmovaps [rsp+0x90], xmm9
0000782c7ffdae59  vmovaps [rsp+0xA0], xmm10
0000782c7ffdae62  vmovaps [rsp+0xB0], xmm11
0000782c7ffdae6b  vmovaps [rsp+0xC0], xmm12
0000782c7ffdae74  vmovaps [rsp+0xD0], xmm13
0000782c7ffdae7d  vmovaps [rsp+0xE0], xmm15
0000782c7ffdae86  sub rsp, 0x40
0000782c7ffdae8a  lea rdi, [rsp]
0000782c7ffdae8e  lea rsi, [rsp+0x10]
0000782c7ffdae93  lea rdx, [rsp+0x20]
0000782c7ffdae98  lea rcx, [rsp+0x30]
0000782c7ffdae9d  mov r8d, 0x00
0000782c7ffdaea3  lea r9, [r15+0x3A8]
0000782c7ffdaeaa  movaps [rdi], xmm14
0000782c7ffdaeae  movaps [rsi], xmm15
0000782c7ffdaeb2  movaps [rdx], xmm2
0000782c7ffdaeb5  movaps [rcx], xmm1
0000782c7ffdaeb8  mov rax, 0x5AE5BFFB5A50
0000782c7ffdaec2  call rax
0000782c7ffdaec4  movaps xmm14, [rsp]
0000782c7ffdaec9  add rsp, 0x40
0000782c7ffdaecd  vmovaps xmm0, [rsp]
0000782c7ffdaed2  vmovaps xmm1, [rsp+0x10]
0000782c7ffdaed8  vmovaps xmm2, [rsp+0x20]
0000782c7ffdaede  vmovaps xmm3, [rsp+0x30]
0000782c7ffdaee4  vmovaps xmm4, [rsp+0x40]
0000782c7ffdaeea  vmovaps xmm5, [rsp+0x50]
0000782c7ffdaef0  vmovaps xmm6, [rsp+0x60]
0000782c7ffdaef6  vmovaps xmm7, [rsp+0x70]
0000782c7ffdaefc  vmovaps xmm8, [rsp+0x80]
0000782c7ffdaf05  vmovaps xmm9, [rsp+0x90]
0000782c7ffdaf0e  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdaf17  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdaf20  vmovaps xmm12, [rsp+0xC0]
0000782c7ffdaf29  vmovaps xmm13, [rsp+0xD0]
0000782c7ffdaf32  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdaf3b  add rsp, 0xF0
0000782c7ffdaf42  pop r11
0000782c7ffdaf44  pop r10
0000782c7ffdaf46  pop r9
0000782c7ffdaf48  pop r8
0000782c7ffdaf4a  pop rsi
0000782c7ffdaf4b  pop rdi
0000782c7ffdaf4c  pop rdx
0000782c7ffdaf4d  pop rcx
0000782c7ffdaf4e  pop rax
0000782c7ffdaf4f  add rsp, 0x08
0000782c7ffdaf53  jmp 0x0000782C7FFDA01C
0000782c7ffdaf58  sub rsp, 0x08
0000782c7ffdaf5c  push rax
0000782c7ffdaf5d  push rcx
0000782c7ffdaf5e  push rdx
0000782c7ffdaf5f  push rdi
0000782c7ffdaf60  push rsi
0000782c7ffdaf61  push r8
0000782c7ffdaf63  push r9
0000782c7ffdaf65  push r10
0000782c7ffdaf67  push r11
0000782c7ffdaf69  sub rsp, 0xF0
0000782c7ffdaf70  vmovaps [rsp], xmm0
0000782c7ffdaf75  vmovaps [rsp+0x10], xmm1
0000782c7ffdaf7b  vmovaps [rsp+0x20], xmm3
0000782c7ffdaf81  vmovaps [rsp+0x30], xmm4
0000782c7ffdaf87  vmovaps [rsp+0x40], xmm5
0000782c7ffdaf8d  vmovaps [rsp+0x50], xmm6
0000782c7ffdaf93  vmovaps [rsp+0x60], xmm7
0000782c7ffdaf99  vmovaps [rsp+0x70], xmm8
0000782c7ffdaf9f  vmovaps [rsp+0x80], xmm9
0000782c7ffdafa8  vmovaps [rsp+0x90], xmm10
0000782c7ffdafb1  vmovaps [rsp+0xA0], xmm11
0000782c7ffdafba  vmovaps [rsp+0xB0], xmm12
0000782c7ffdafc3  vmovaps [rsp+0xC0], xmm13
0000782c7ffdafcc  vmovaps [rsp+0xD0], xmm14
0000782c7ffdafd5  vmovaps [rsp+0xE0], xmm15
0000782c7ffdafde  sub rsp, 0x40
0000782c7ffdafe2  lea rdi, [rsp]
0000782c7ffdafe6  lea rsi, [rsp+0x10]
0000782c7ffdafeb  lea rdx, [rsp+0x20]
0000782c7ffdaff0  lea rcx, [rsp+0x30]
0000782c7ffdaff5  mov r8d, 0x00
0000782c7ffdaffb  lea r9, [r15+0x3A8]
0000782c7ffdb002  movaps [rdi], xmm2
0000782c7ffdb005  movaps [rsi], xmm15
0000782c7ffdb009  movaps [rdx], xmm12
0000782c7ffdb00d  movaps [rcx], xmm1
0000782c7ffdb010  mov rax, 0x5AE5BFFB5A50
0000782c7ffdb01a  call rax
0000782c7ffdb01c  movaps xmm2, [rsp]
0000782c7ffdb020  add rsp, 0x40
0000782c7ffdb024  vmovaps xmm0, [rsp]
0000782c7ffdb029  vmovaps xmm1, [rsp+0x10]
0000782c7ffdb02f  vmovaps xmm3, [rsp+0x20]
0000782c7ffdb035  vmovaps xmm4, [rsp+0x30]
0000782c7ffdb03b  vmovaps xmm5, [rsp+0x40]
0000782c7ffdb041  vmovaps xmm6, [rsp+0x50]
0000782c7ffdb047  vmovaps xmm7, [rsp+0x60]
0000782c7ffdb04d  vmovaps xmm8, [rsp+0x70]
0000782c7ffdb053  vmovaps xmm9, [rsp+0x80]
0000782c7ffdb05c  vmovaps xmm10, [rsp+0x90]
0000782c7ffdb065  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdb06e  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdb077  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdb080  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdb089  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdb092  add rsp, 0xF0
0000782c7ffdb099  pop r11
0000782c7ffdb09b  pop r10
0000782c7ffdb09d  pop r9
0000782c7ffdb09f  pop r8
0000782c7ffdb0a1  pop rsi
0000782c7ffdb0a2  pop rdi
0000782c7ffdb0a3  pop rdx
0000782c7ffdb0a4  pop rcx
0000782c7ffdb0a5  pop rax
0000782c7ffdb0a6  add rsp, 0x08
0000782c7ffdb0aa  jmp 0x0000782C7FFDA059
0000782c7ffdb0af  sub rsp, 0x08
0000782c7ffdb0b3  push rax
0000782c7ffdb0b4  push rcx
0000782c7ffdb0b5  push rdx
0000782c7ffdb0b6  push rdi
0000782c7ffdb0b7  push rsi
0000782c7ffdb0b8  push r8
0000782c7ffdb0ba  push r9
0000782c7ffdb0bc  push r10
0000782c7ffdb0be  push r11
0000782c7ffdb0c0  sub rsp, 0xF0
0000782c7ffdb0c7  vmovaps [rsp], xmm0
0000782c7ffdb0cc  vmovaps [rsp+0x10], xmm1
0000782c7ffdb0d2  vmovaps [rsp+0x20], xmm2
0000782c7ffdb0d8  vmovaps [rsp+0x30], xmm3
0000782c7ffdb0de  vmovaps [rsp+0x40], xmm4
0000782c7ffdb0e4  vmovaps [rsp+0x50], xmm5
0000782c7ffdb0ea  vmovaps [rsp+0x60], xmm6
0000782c7ffdb0f0  vmovaps [rsp+0x70], xmm7
0000782c7ffdb0f6  vmovaps [rsp+0x80], xmm8
0000782c7ffdb0ff  vmovaps [rsp+0x90], xmm9
0000782c7ffdb108  vmovaps [rsp+0xA0], xmm10
0000782c7ffdb111  vmovaps [rsp+0xB0], xmm11
0000782c7ffdb11a  vmovaps [rsp+0xC0], xmm13
0000782c7ffdb123  vmovaps [rsp+0xD0], xmm14
0000782c7ffdb12c  vmovaps [rsp+0xE0], xmm15
0000782c7ffdb135  sub rsp, 0x40
0000782c7ffdb139  lea rdi, [rsp]
0000782c7ffdb13d  lea rsi, [rsp+0x10]
0000782c7ffdb142  lea rdx, [rsp+0x20]
0000782c7ffdb147  lea rcx, [rsp+0x30]
0000782c7ffdb14c  mov r8d, 0x00
0000782c7ffdb152  lea r9, [r15+0x3A8]
0000782c7ffdb159  movaps [rdi], xmm12
0000782c7ffdb15d  movaps [rsi], xmm14
0000782c7ffdb161  movaps [rdx], xmm3
0000782c7ffdb164  movaps [rcx], xmm15
0000782c7ffdb168  mov rax, 0x5AE5BFFB5A50
0000782c7ffdb172  call rax
0000782c7ffdb174  movaps xmm12, [rsp]
0000782c7ffdb179  add rsp, 0x40
0000782c7ffdb17d  vmovaps xmm0, [rsp]
0000782c7ffdb182  vmovaps xmm1, [rsp+0x10]
0000782c7ffdb188  vmovaps xmm2, [rsp+0x20]
0000782c7ffdb18e  vmovaps xmm3, [rsp+0x30]
0000782c7ffdb194  vmovaps xmm4, [rsp+0x40]
0000782c7ffdb19a  vmovaps xmm5, [rsp+0x50]
0000782c7ffdb1a0  vmovaps xmm6, [rsp+0x60]
0000782c7ffdb1a6  vmovaps xmm7, [rsp+0x70]
0000782c7ffdb1ac  vmovaps xmm8, [rsp+0x80]
0000782c7ffdb1b5  vmovaps xmm9, [rsp+0x90]
0000782c7ffdb1be  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdb1c7  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdb1d0  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdb1d9  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdb1e2  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdb1eb  add rsp, 0xF0
0000782c7ffdb1f2  pop r11
0000782c7ffdb1f4  pop r10
0000782c7ffdb1f6  pop r9
0000782c7ffdb1f8  pop r8
0000782c7ffdb1fa  pop rsi
0000782c7ffdb1fb  pop rdi
0000782c7ffdb1fc  pop rdx
0000782c7ffdb1fd  pop rcx
0000782c7ffdb1fe  pop rax
0000782c7ffdb1ff  add rsp, 0x08
0000782c7ffdb203  jmp 0x0000782C7FFDA0B3
0000782c7ffdb208  sub rsp, 0x08
0000782c7ffdb20c  push rax
0000782c7ffdb20d  push rcx
0000782c7ffdb20e  push rdx
0000782c7ffdb20f  push rdi
0000782c7ffdb210  push rsi
0000782c7ffdb211  push r8
0000782c7ffdb213  push r9
0000782c7ffdb215  push r10
0000782c7ffdb217  push r11
0000782c7ffdb219  sub rsp, 0xF0
0000782c7ffdb220  vmovaps [rsp], xmm0
0000782c7ffdb225  vmovaps [rsp+0x10], xmm1
0000782c7ffdb22b  vmovaps [rsp+0x20], xmm2
0000782c7ffdb231  vmovaps [rsp+0x30], xmm3
0000782c7ffdb237  vmovaps [rsp+0x40], xmm4
0000782c7ffdb23d  vmovaps [rsp+0x50], xmm5
0000782c7ffdb243  vmovaps [rsp+0x60], xmm6
0000782c7ffdb249  vmovaps [rsp+0x70], xmm7
0000782c7ffdb24f  vmovaps [rsp+0x80], xmm8
0000782c7ffdb258  vmovaps [rsp+0x90], xmm10
0000782c7ffdb261  vmovaps [rsp+0xA0], xmm11
0000782c7ffdb26a  vmovaps [rsp+0xB0], xmm12
0000782c7ffdb273  vmovaps [rsp+0xC0], xmm13
0000782c7ffdb27c  vmovaps [rsp+0xD0], xmm14
0000782c7ffdb285  vmovaps [rsp+0xE0], xmm15
0000782c7ffdb28e  sub rsp, 0x40
0000782c7ffdb292  lea rdi, [rsp]
0000782c7ffdb296  lea rsi, [rsp+0x10]
0000782c7ffdb29b  lea rdx, [rsp+0x20]
0000782c7ffdb2a0  lea rcx, [rsp+0x30]
0000782c7ffdb2a5  mov r8d, 0x00
0000782c7ffdb2ab  lea r9, [r15+0x3A8]
0000782c7ffdb2b2  movaps [rdi], xmm9
0000782c7ffdb2b6  movaps [rsi], xmm13
0000782c7ffdb2ba  movaps [rdx], xmm14
0000782c7ffdb2be  movaps [rcx], xmm6
0000782c7ffdb2c1  mov rax, 0x5AE5BFFB5A50
0000782c7ffdb2cb  call rax
0000782c7ffdb2cd  movaps xmm9, [rsp]
0000782c7ffdb2d2  add rsp, 0x40
0000782c7ffdb2d6  vmovaps xmm0, [rsp]
0000782c7ffdb2db  vmovaps xmm1, [rsp+0x10]
0000782c7ffdb2e1  vmovaps xmm2, [rsp+0x20]
0000782c7ffdb2e7  vmovaps xmm3, [rsp+0x30]
0000782c7ffdb2ed  vmovaps xmm4, [rsp+0x40]
0000782c7ffdb2f3  vmovaps xmm5, [rsp+0x50]
0000782c7ffdb2f9  vmovaps xmm6, [rsp+0x60]
0000782c7ffdb2ff  vmovaps xmm7, [rsp+0x70]
0000782c7ffdb305  vmovaps xmm8, [rsp+0x80]
0000782c7ffdb30e  vmovaps xmm10, [rsp+0x90]
0000782c7ffdb317  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdb320  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdb329  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdb332  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdb33b  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdb344  add rsp, 0xF0
0000782c7ffdb34b  pop r11
0000782c7ffdb34d  pop r10
0000782c7ffdb34f  pop r9
0000782c7ffdb351  pop r8
0000782c7ffdb353  pop rsi
0000782c7ffdb354  pop rdi
0000782c7ffdb355  pop rdx
0000782c7ffdb356  pop rcx
0000782c7ffdb357  pop rax
0000782c7ffdb358  add rsp, 0x08
0000782c7ffdb35c  jmp 0x0000782C7FFDA15D
0000782c7ffdb361  sub rsp, 0x08
0000782c7ffdb365  push rax
0000782c7ffdb366  push rcx
0000782c7ffdb367  push rdx
0000782c7ffdb368  push rdi
0000782c7ffdb369  push rsi
0000782c7ffdb36a  push r8
0000782c7ffdb36c  push r9
0000782c7ffdb36e  push r10
0000782c7ffdb370  push r11
0000782c7ffdb372  sub rsp, 0xF0
0000782c7ffdb379  vmovaps [rsp], xmm0
0000782c7ffdb37e  vmovaps [rsp+0x10], xmm1
0000782c7ffdb384  vmovaps [rsp+0x20], xmm2
0000782c7ffdb38a  vmovaps [rsp+0x30], xmm4
0000782c7ffdb390  vmovaps [rsp+0x40], xmm5
0000782c7ffdb396  vmovaps [rsp+0x50], xmm6
0000782c7ffdb39c  vmovaps [rsp+0x60], xmm7
0000782c7ffdb3a2  vmovaps [rsp+0x70], xmm8
0000782c7ffdb3a8  vmovaps [rsp+0x80], xmm9
0000782c7ffdb3b1  vmovaps [rsp+0x90], xmm10
0000782c7ffdb3ba  vmovaps [rsp+0xA0], xmm11
0000782c7ffdb3c3  vmovaps [rsp+0xB0], xmm12
0000782c7ffdb3cc  vmovaps [rsp+0xC0], xmm13
0000782c7ffdb3d5  vmovaps [rsp+0xD0], xmm14
0000782c7ffdb3de  vmovaps [rsp+0xE0], xmm15
0000782c7ffdb3e7  sub rsp, 0x40
0000782c7ffdb3eb  lea rdi, [rsp]
0000782c7ffdb3ef  lea rsi, [rsp+0x10]
0000782c7ffdb3f4  lea rdx, [rsp+0x20]
0000782c7ffdb3f9  lea rcx, [rsp+0x30]
0000782c7ffdb3fe  mov r8d, 0x00
0000782c7ffdb404  lea r9, [r15+0x3A8]
0000782c7ffdb40b  movaps [rdi], xmm3
0000782c7ffdb40e  movaps [rsi], xmm13
0000782c7ffdb412  movaps [rdx], xmm6
0000782c7ffdb415  movaps [rcx], xmm14
0000782c7ffdb419  mov rax, 0x5AE5BFFB5A50
0000782c7ffdb423  call rax
0000782c7ffdb425  movaps xmm3, [rsp]
0000782c7ffdb429  add rsp, 0x40
0000782c7ffdb42d  vmovaps xmm0, [rsp]
0000782c7ffdb432  vmovaps xmm1, [rsp+0x10]
0000782c7ffdb438  vmovaps xmm2, [rsp+0x20]
0000782c7ffdb43e  vmovaps xmm4, [rsp+0x30]
0000782c7ffdb444  vmovaps xmm5, [rsp+0x40]
0000782c7ffdb44a  vmovaps xmm6, [rsp+0x50]
0000782c7ffdb450  vmovaps xmm7, [rsp+0x60]
0000782c7ffdb456  vmovaps xmm8, [rsp+0x70]
0000782c7ffdb45c  vmovaps xmm9, [rsp+0x80]
0000782c7ffdb465  vmovaps xmm10, [rsp+0x90]
0000782c7ffdb46e  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdb477  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdb480  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdb489  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdb492  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdb49b  add rsp, 0xF0
0000782c7ffdb4a2  pop r11
0000782c7ffdb4a4  pop r10
0000782c7ffdb4a6  pop r9
0000782c7ffdb4a8  pop r8
0000782c7ffdb4aa  pop rsi
0000782c7ffdb4ab  pop rdi
0000782c7ffdb4ac  pop rdx
0000782c7ffdb4ad  pop rcx
0000782c7ffdb4ae  pop rax
0000782c7ffdb4af  add rsp, 0x08
0000782c7ffdb4b3  jmp 0x0000782C7FFDA19A
0000782c7ffdb4b8  sub rsp, 0x08
0000782c7ffdb4bc  push rax
0000782c7ffdb4bd  push rcx
0000782c7ffdb4be  push rdx
0000782c7ffdb4bf  push rdi
0000782c7ffdb4c0  push rsi
0000782c7ffdb4c1  push r8
0000782c7ffdb4c3  push r9
0000782c7ffdb4c5  push r10
0000782c7ffdb4c7  push r11
0000782c7ffdb4c9  sub rsp, 0xF0
0000782c7ffdb4d0  vmovaps [rsp], xmm0
0000782c7ffdb4d5  vmovaps [rsp+0x10], xmm1
0000782c7ffdb4db  vmovaps [rsp+0x20], xmm2
0000782c7ffdb4e1  vmovaps [rsp+0x30], xmm3
0000782c7ffdb4e7  vmovaps [rsp+0x40], xmm4
0000782c7ffdb4ed  vmovaps [rsp+0x50], xmm5
0000782c7ffdb4f3  vmovaps [rsp+0x60], xmm7
0000782c7ffdb4f9  vmovaps [rsp+0x70], xmm8
0000782c7ffdb4ff  vmovaps [rsp+0x80], xmm9
0000782c7ffdb508  vmovaps [rsp+0x90], xmm10
0000782c7ffdb511  vmovaps [rsp+0xA0], xmm11
0000782c7ffdb51a  vmovaps [rsp+0xB0], xmm12
0000782c7ffdb523  vmovaps [rsp+0xC0], xmm13
0000782c7ffdb52c  vmovaps [rsp+0xD0], xmm14
0000782c7ffdb535  vmovaps [rsp+0xE0], xmm15
0000782c7ffdb53e  sub rsp, 0x40
0000782c7ffdb542  lea rdi, [rsp]
0000782c7ffdb546  lea rsi, [rsp+0x10]
0000782c7ffdb54b  lea rdx, [rsp+0x20]
0000782c7ffdb550  lea rcx, [rsp+0x30]
0000782c7ffdb555  mov r8d, 0x00
0000782c7ffdb55b  lea r9, [r15+0x3A8]
0000782c7ffdb562  movaps [rdi], xmm6
0000782c7ffdb565  movaps [rsi], xmm2
0000782c7ffdb568  movaps [rdx], xmm14
0000782c7ffdb56c  movaps [rcx], xmm1
0000782c7ffdb56f  mov rax, 0x5AE5BFFB5A50
0000782c7ffdb579  call rax
0000782c7ffdb57b  movaps xmm6, [rsp]
0000782c7ffdb57f  add rsp, 0x40
0000782c7ffdb583  vmovaps xmm0, [rsp]
0000782c7ffdb588  vmovaps xmm1, [rsp+0x10]
0000782c7ffdb58e  vmovaps xmm2, [rsp+0x20]
0000782c7ffdb594  vmovaps xmm3, [rsp+0x30]
0000782c7ffdb59a  vmovaps xmm4, [rsp+0x40]
0000782c7ffdb5a0  vmovaps xmm5, [rsp+0x50]
0000782c7ffdb5a6  vmovaps xmm7, [rsp+0x60]
0000782c7ffdb5ac  vmovaps xmm8, [rsp+0x70]
0000782c7ffdb5b2  vmovaps xmm9, [rsp+0x80]
0000782c7ffdb5bb  vmovaps xmm10, [rsp+0x90]
0000782c7ffdb5c4  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdb5cd  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdb5d6  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdb5df  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdb5e8  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdb5f1  add rsp, 0xF0
0000782c7ffdb5f8  pop r11
0000782c7ffdb5fa  pop r10
0000782c7ffdb5fc  pop r9
0000782c7ffdb5fe  pop r8
0000782c7ffdb600  pop rsi
0000782c7ffdb601  pop rdi
0000782c7ffdb602  pop rdx
0000782c7ffdb603  pop rcx
0000782c7ffdb604  pop rax
0000782c7ffdb605  add rsp, 0x08
0000782c7ffdb609  jmp 0x0000782C7FFDA1C7
0000782c7ffdb60e  sub rsp, 0x08
0000782c7ffdb612  push rax
0000782c7ffdb613  push rcx
0000782c7ffdb614  push rdx
0000782c7ffdb615  push rdi
0000782c7ffdb616  push rsi
0000782c7ffdb617  push r8
0000782c7ffdb619  push r9
0000782c7ffdb61b  push r10
0000782c7ffdb61d  push r11
0000782c7ffdb61f  sub rsp, 0xF0
0000782c7ffdb626  vmovaps [rsp], xmm0
0000782c7ffdb62b  vmovaps [rsp+0x10], xmm1
0000782c7ffdb631  vmovaps [rsp+0x20], xmm2
0000782c7ffdb637  vmovaps [rsp+0x30], xmm3
0000782c7ffdb63d  vmovaps [rsp+0x40], xmm4
0000782c7ffdb643  vmovaps [rsp+0x50], xmm5
0000782c7ffdb649  vmovaps [rsp+0x60], xmm6
0000782c7ffdb64f  vmovaps [rsp+0x70], xmm7
0000782c7ffdb655  vmovaps [rsp+0x80], xmm8
0000782c7ffdb65e  vmovaps [rsp+0x90], xmm9
0000782c7ffdb667  vmovaps [rsp+0xA0], xmm10
0000782c7ffdb670  vmovaps [rsp+0xB0], xmm11
0000782c7ffdb679  vmovaps [rsp+0xC0], xmm12
0000782c7ffdb682  vmovaps [rsp+0xD0], xmm14
0000782c7ffdb68b  vmovaps [rsp+0xE0], xmm15
0000782c7ffdb694  sub rsp, 0x40
0000782c7ffdb698  lea rdi, [rsp]
0000782c7ffdb69c  lea rsi, [rsp+0x10]
0000782c7ffdb6a1  lea rdx, [rsp+0x20]
0000782c7ffdb6a6  lea rcx, [rsp+0x30]
0000782c7ffdb6ab  mov r8d, 0x00
0000782c7ffdb6b1  lea r9, [r15+0x3A8]
0000782c7ffdb6b8  movaps [rdi], xmm13
0000782c7ffdb6bc  movaps [rsi], xmm12
0000782c7ffdb6c0  movaps [rdx], xmm14
0000782c7ffdb6c4  movaps [rcx], xmm1
0000782c7ffdb6c7  mov rax, 0x5AE5BFFB5A50
0000782c7ffdb6d1  call rax
0000782c7ffdb6d3  movaps xmm13, [rsp]
0000782c7ffdb6d8  add rsp, 0x40
0000782c7ffdb6dc  vmovaps xmm0, [rsp]
0000782c7ffdb6e1  vmovaps xmm1, [rsp+0x10]
0000782c7ffdb6e7  vmovaps xmm2, [rsp+0x20]
0000782c7ffdb6ed  vmovaps xmm3, [rsp+0x30]
0000782c7ffdb6f3  vmovaps xmm4, [rsp+0x40]
0000782c7ffdb6f9  vmovaps xmm5, [rsp+0x50]
0000782c7ffdb6ff  vmovaps xmm6, [rsp+0x60]
0000782c7ffdb705  vmovaps xmm7, [rsp+0x70]
0000782c7ffdb70b  vmovaps xmm8, [rsp+0x80]
0000782c7ffdb714  vmovaps xmm9, [rsp+0x90]
0000782c7ffdb71d  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdb726  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdb72f  vmovaps xmm12, [rsp+0xC0]
0000782c7ffdb738  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdb741  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdb74a  add rsp, 0xF0
0000782c7ffdb751  pop r11
0000782c7ffdb753  pop r10
0000782c7ffdb755  pop r9
0000782c7ffdb757  pop r8
0000782c7ffdb759  pop rsi
0000782c7ffdb75a  pop rdi
0000782c7ffdb75b  pop rdx
0000782c7ffdb75c  pop rcx
0000782c7ffdb75d  pop rax
0000782c7ffdb75e  add rsp, 0x08
0000782c7ffdb762  jmp 0x0000782C7FFDA1F9
0000782c7ffdb767  sub rsp, 0x08
0000782c7ffdb76b  push rax
0000782c7ffdb76c  push rcx
0000782c7ffdb76d  push rdx
0000782c7ffdb76e  push rdi
0000782c7ffdb76f  push rsi
0000782c7ffdb770  push r8
0000782c7ffdb772  push r9
0000782c7ffdb774  push r10
0000782c7ffdb776  push r11
0000782c7ffdb778  sub rsp, 0xF0
0000782c7ffdb77f  vmovaps [rsp], xmm0
0000782c7ffdb784  vmovaps [rsp+0x10], xmm1
0000782c7ffdb78a  vmovaps [rsp+0x20], xmm2
0000782c7ffdb790  vmovaps [rsp+0x30], xmm3
0000782c7ffdb796  vmovaps [rsp+0x40], xmm4
0000782c7ffdb79c  vmovaps [rsp+0x50], xmm5
0000782c7ffdb7a2  vmovaps [rsp+0x60], xmm6
0000782c7ffdb7a8  vmovaps [rsp+0x70], xmm7
0000782c7ffdb7ae  vmovaps [rsp+0x80], xmm8
0000782c7ffdb7b7  vmovaps [rsp+0x90], xmm9
0000782c7ffdb7c0  vmovaps [rsp+0xA0], xmm10
0000782c7ffdb7c9  vmovaps [rsp+0xB0], xmm11
0000782c7ffdb7d2  vmovaps [rsp+0xC0], xmm13
0000782c7ffdb7db  vmovaps [rsp+0xD0], xmm14
0000782c7ffdb7e4  vmovaps [rsp+0xE0], xmm15
0000782c7ffdb7ed  sub rsp, 0x40
0000782c7ffdb7f1  lea rdi, [rsp]
0000782c7ffdb7f5  lea rsi, [rsp+0x10]
0000782c7ffdb7fa  lea rdx, [rsp+0x20]
0000782c7ffdb7ff  lea rcx, [rsp+0x30]
0000782c7ffdb804  mov r8d, 0x00
0000782c7ffdb80a  lea r9, [r15+0x3A8]
0000782c7ffdb811  movaps [rdi], xmm12
0000782c7ffdb815  movaps [rsi], xmm3
0000782c7ffdb818  movaps [rdx], xmm14
0000782c7ffdb81c  movaps [rcx], xmm5
0000782c7ffdb81f  mov rax, 0x5AE5BFFB5A50
0000782c7ffdb829  call rax
0000782c7ffdb82b  movaps xmm12, [rsp]
0000782c7ffdb830  add rsp, 0x40
0000782c7ffdb834  vmovaps xmm0, [rsp]
0000782c7ffdb839  vmovaps xmm1, [rsp+0x10]
0000782c7ffdb83f  vmovaps xmm2, [rsp+0x20]
0000782c7ffdb845  vmovaps xmm3, [rsp+0x30]
0000782c7ffdb84b  vmovaps xmm4, [rsp+0x40]
0000782c7ffdb851  vmovaps xmm5, [rsp+0x50]
0000782c7ffdb857  vmovaps xmm6, [rsp+0x60]
0000782c7ffdb85d  vmovaps xmm7, [rsp+0x70]
0000782c7ffdb863  vmovaps xmm8, [rsp+0x80]
0000782c7ffdb86c  vmovaps xmm9, [rsp+0x90]
0000782c7ffdb875  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdb87e  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdb887  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdb890  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdb899  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdb8a2  add rsp, 0xF0
0000782c7ffdb8a9  pop r11
0000782c7ffdb8ab  pop r10
0000782c7ffdb8ad  pop r9
0000782c7ffdb8af  pop r8
0000782c7ffdb8b1  pop rsi
0000782c7ffdb8b2  pop rdi
0000782c7ffdb8b3  pop rdx
0000782c7ffdb8b4  pop rcx
0000782c7ffdb8b5  pop rax
0000782c7ffdb8b6  add rsp, 0x08
0000782c7ffdb8ba  jmp 0x0000782C7FFDA256
0000782c7ffdb8bf  sub rsp, 0x08
0000782c7ffdb8c3  push rax
0000782c7ffdb8c4  push rcx
0000782c7ffdb8c5  push rdx
0000782c7ffdb8c6  push rdi
0000782c7ffdb8c7  push rsi
0000782c7ffdb8c8  push r8
0000782c7ffdb8ca  push r9
0000782c7ffdb8cc  push r10
0000782c7ffdb8ce  push r11
0000782c7ffdb8d0  sub rsp, 0xF0
0000782c7ffdb8d7  vmovaps [rsp], xmm0
0000782c7ffdb8dc  vmovaps [rsp+0x10], xmm1
0000782c7ffdb8e2  vmovaps [rsp+0x20], xmm2
0000782c7ffdb8e8  vmovaps [rsp+0x30], xmm3
0000782c7ffdb8ee  vmovaps [rsp+0x40], xmm4
0000782c7ffdb8f4  vmovaps [rsp+0x50], xmm5
0000782c7ffdb8fa  vmovaps [rsp+0x60], xmm6
0000782c7ffdb900  vmovaps [rsp+0x70], xmm7
0000782c7ffdb906  vmovaps [rsp+0x80], xmm8
0000782c7ffdb90f  vmovaps [rsp+0x90], xmm9
0000782c7ffdb918  vmovaps [rsp+0xA0], xmm11
0000782c7ffdb921  vmovaps [rsp+0xB0], xmm12
0000782c7ffdb92a  vmovaps [rsp+0xC0], xmm13
0000782c7ffdb933  vmovaps [rsp+0xD0], xmm14
0000782c7ffdb93c  vmovaps [rsp+0xE0], xmm15
0000782c7ffdb945  sub rsp, 0x40
0000782c7ffdb949  lea rdi, [rsp]
0000782c7ffdb94d  lea rsi, [rsp+0x10]
0000782c7ffdb952  lea rdx, [rsp+0x20]
0000782c7ffdb957  lea rcx, [rsp+0x30]
0000782c7ffdb95c  mov r8d, 0x00
0000782c7ffdb962  lea r9, [r15+0x3A8]
0000782c7ffdb969  movaps [rdi], xmm10
0000782c7ffdb96d  movaps [rsi], xmm9
0000782c7ffdb971  movaps [rdx], xmm7
0000782c7ffdb974  movaps [rcx], xmm14
0000782c7ffdb978  mov rax, 0x5AE5BFFB5A50
0000782c7ffdb982  call rax
0000782c7ffdb984  movaps xmm10, [rsp]
0000782c7ffdb989  add rsp, 0x40
0000782c7ffdb98d  vmovaps xmm0, [rsp]
0000782c7ffdb992  vmovaps xmm1, [rsp+0x10]
0000782c7ffdb998  vmovaps xmm2, [rsp+0x20]
0000782c7ffdb99e  vmovaps xmm3, [rsp+0x30]
0000782c7ffdb9a4  vmovaps xmm4, [rsp+0x40]
0000782c7ffdb9aa  vmovaps xmm5, [rsp+0x50]
0000782c7ffdb9b0  vmovaps xmm6, [rsp+0x60]
0000782c7ffdb9b6  vmovaps xmm7, [rsp+0x70]
0000782c7ffdb9bc  vmovaps xmm8, [rsp+0x80]
0000782c7ffdb9c5  vmovaps xmm9, [rsp+0x90]
0000782c7ffdb9ce  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdb9d7  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdb9e0  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdb9e9  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdb9f2  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdb9fb  add rsp, 0xF0
0000782c7ffdba02  pop r11
0000782c7ffdba04  pop r10
0000782c7ffdba06  pop r9
0000782c7ffdba08  pop r8
0000782c7ffdba0a  pop rsi
0000782c7ffdba0b  pop rdi
0000782c7ffdba0c  pop rdx
0000782c7ffdba0d  pop rcx
0000782c7ffdba0e  pop rax
0000782c7ffdba0f  add rsp, 0x08
0000782c7ffdba13  jmp 0x0000782C7FFDA27C
0000782c7ffdba18  call 0x0000782C7FE0D4E0
0000782c7ffdba1d  jmp 0x0000782C7FFDA289
0000782c7ffdba22  sub rsp, 0x08
0000782c7ffdba26  push rax
0000782c7ffdba27  push rcx
0000782c7ffdba28  push rdx
0000782c7ffdba29  push rdi
0000782c7ffdba2a  push rsi
0000782c7ffdba2b  push r8
0000782c7ffdba2d  push r9
0000782c7ffdba2f  push r10
0000782c7ffdba31  push r11
0000782c7ffdba33  sub rsp, 0xF0
0000782c7ffdba3a  vmovaps [rsp], xmm0
0000782c7ffdba3f  vmovaps [rsp+0x10], xmm1
0000782c7ffdba45  vmovaps [rsp+0x20], xmm2
0000782c7ffdba4b  vmovaps [rsp+0x30], xmm3
0000782c7ffdba51  vmovaps [rsp+0x40], xmm4
0000782c7ffdba57  vmovaps [rsp+0x50], xmm6
0000782c7ffdba5d  vmovaps [rsp+0x60], xmm7
0000782c7ffdba63  vmovaps [rsp+0x70], xmm8
0000782c7ffdba69  vmovaps [rsp+0x80], xmm9
0000782c7ffdba72  vmovaps [rsp+0x90], xmm10
0000782c7ffdba7b  vmovaps [rsp+0xA0], xmm11
0000782c7ffdba84  vmovaps [rsp+0xB0], xmm12
0000782c7ffdba8d  vmovaps [rsp+0xC0], xmm13
0000782c7ffdba96  vmovaps [rsp+0xD0], xmm14
0000782c7ffdba9f  vmovaps [rsp+0xE0], xmm15
0000782c7ffdbaa8  sub rsp, 0x40
0000782c7ffdbaac  lea rdi, [rsp]
0000782c7ffdbab0  lea rsi, [rsp+0x10]
0000782c7ffdbab5  lea rdx, [rsp+0x20]
0000782c7ffdbaba  lea rcx, [rsp+0x30]
0000782c7ffdbabf  mov r8d, 0x00
0000782c7ffdbac5  lea r9, [r15+0x3A8]
0000782c7ffdbacc  movaps [rdi], xmm5
0000782c7ffdbacf  movaps [rsi], xmm6
0000782c7ffdbad2  movaps [rdx], xmm7
0000782c7ffdbad5  movaps [rcx], xmm9
0000782c7ffdbad9  mov rax, 0x5AE5BFFB5A50
0000782c7ffdbae3  call rax
0000782c7ffdbae5  movaps xmm5, [rsp]
0000782c7ffdbae9  add rsp, 0x40
0000782c7ffdbaed  vmovaps xmm0, [rsp]
0000782c7ffdbaf2  vmovaps xmm1, [rsp+0x10]
0000782c7ffdbaf8  vmovaps xmm2, [rsp+0x20]
0000782c7ffdbafe  vmovaps xmm3, [rsp+0x30]
0000782c7ffdbb04  vmovaps xmm4, [rsp+0x40]
0000782c7ffdbb0a  vmovaps xmm6, [rsp+0x50]
0000782c7ffdbb10  vmovaps xmm7, [rsp+0x60]
0000782c7ffdbb16  vmovaps xmm8, [rsp+0x70]
0000782c7ffdbb1c  vmovaps xmm9, [rsp+0x80]
0000782c7ffdbb25  vmovaps xmm10, [rsp+0x90]
0000782c7ffdbb2e  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdbb37  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdbb40  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdbb49  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdbb52  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdbb5b  add rsp, 0xF0
0000782c7ffdbb62  pop r11
0000782c7ffdbb64  pop r10
0000782c7ffdbb66  pop r9
0000782c7ffdbb68  pop r8
0000782c7ffdbb6a  pop rsi
0000782c7ffdbb6b  pop rdi
0000782c7ffdbb6c  pop rdx
0000782c7ffdbb6d  pop rcx
0000782c7ffdbb6e  pop rax
0000782c7ffdbb6f  add rsp, 0x08
0000782c7ffdbb73  jmp 0x0000782C7FFDA2BB
0000782c7ffdbb78  sub rsp, 0x08
0000782c7ffdbb7c  push rax
0000782c7ffdbb7d  push rcx
0000782c7ffdbb7e  push rdx
0000782c7ffdbb7f  push rdi
0000782c7ffdbb80  push rsi
0000782c7ffdbb81  push r8
0000782c7ffdbb83  push r9
0000782c7ffdbb85  push r10
0000782c7ffdbb87  push r11
0000782c7ffdbb89  sub rsp, 0xF0
0000782c7ffdbb90  vmovaps [rsp], xmm0
0000782c7ffdbb95  vmovaps [rsp+0x10], xmm1
0000782c7ffdbb9b  vmovaps [rsp+0x20], xmm2
0000782c7ffdbba1  vmovaps [rsp+0x30], xmm3
0000782c7ffdbba7  vmovaps [rsp+0x40], xmm4
0000782c7ffdbbad  vmovaps [rsp+0x50], xmm5
0000782c7ffdbbb3  vmovaps [rsp+0x60], xmm6
0000782c7ffdbbb9  vmovaps [rsp+0x70], xmm8
0000782c7ffdbbbf  vmovaps [rsp+0x80], xmm9
0000782c7ffdbbc8  vmovaps [rsp+0x90], xmm10
0000782c7ffdbbd1  vmovaps [rsp+0xA0], xmm11
0000782c7ffdbbda  vmovaps [rsp+0xB0], xmm12
0000782c7ffdbbe3  vmovaps [rsp+0xC0], xmm13
0000782c7ffdbbec  vmovaps [rsp+0xD0], xmm14
0000782c7ffdbbf5  vmovaps [rsp+0xE0], xmm15
0000782c7ffdbbfe  sub rsp, 0x40
0000782c7ffdbc02  lea rdi, [rsp]
0000782c7ffdbc06  lea rsi, [rsp+0x10]
0000782c7ffdbc0b  lea rdx, [rsp+0x20]
0000782c7ffdbc10  lea rcx, [rsp+0x30]
0000782c7ffdbc15  mov r8d, 0x00
0000782c7ffdbc1b  lea r9, [r15+0x3A8]
0000782c7ffdbc22  movaps [rdi], xmm7
0000782c7ffdbc25  movaps [rsi], xmm13
0000782c7ffdbc29  movaps [rdx], xmm1
0000782c7ffdbc2c  movaps [rcx], xmm9
0000782c7ffdbc30  mov rax, 0x5AE5BFFB5A50
0000782c7ffdbc3a  call rax
0000782c7ffdbc3c  movaps xmm7, [rsp]
0000782c7ffdbc40  add rsp, 0x40
0000782c7ffdbc44  vmovaps xmm0, [rsp]
0000782c7ffdbc49  vmovaps xmm1, [rsp+0x10]
0000782c7ffdbc4f  vmovaps xmm2, [rsp+0x20]
0000782c7ffdbc55  vmovaps xmm3, [rsp+0x30]
0000782c7ffdbc5b  vmovaps xmm4, [rsp+0x40]
0000782c7ffdbc61  vmovaps xmm5, [rsp+0x50]
0000782c7ffdbc67  vmovaps xmm6, [rsp+0x60]
0000782c7ffdbc6d  vmovaps xmm8, [rsp+0x70]
0000782c7ffdbc73  vmovaps xmm9, [rsp+0x80]
0000782c7ffdbc7c  vmovaps xmm10, [rsp+0x90]
0000782c7ffdbc85  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdbc8e  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdbc97  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdbca0  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdbca9  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdbcb2  add rsp, 0xF0
0000782c7ffdbcb9  pop r11
0000782c7ffdbcbb  pop r10
0000782c7ffdbcbd  pop r9
0000782c7ffdbcbf  pop r8
0000782c7ffdbcc1  pop rsi
0000782c7ffdbcc2  pop rdi
0000782c7ffdbcc3  pop rdx
0000782c7ffdbcc4  pop rcx
0000782c7ffdbcc5  pop rax
0000782c7ffdbcc6  add rsp, 0x08
0000782c7ffdbcca  jmp 0x0000782C7FFDA2E0
0000782c7ffdbccf  call 0x0000782C7FE0C260
0000782c7ffdbcd4  jmp 0x0000782C7FFDA303
0000782c7ffdbcd9  call 0x0000782C7FE07890
0000782c7ffdbcde  jmp 0x0000782C7FFDA30D
0000782c7ffdbce3  sub rsp, 0x08
0000782c7ffdbce7  push rax
0000782c7ffdbce8  push rcx
0000782c7ffdbce9  push rdx
0000782c7ffdbcea  push rdi
0000782c7ffdbceb  push rsi
0000782c7ffdbcec  push r8
0000782c7ffdbcee  push r9
0000782c7ffdbcf0  push r10
0000782c7ffdbcf2  push r11
0000782c7ffdbcf4  sub rsp, 0xF0
0000782c7ffdbcfb  vmovaps [rsp], xmm0
0000782c7ffdbd00  vmovaps [rsp+0x10], xmm1
0000782c7ffdbd06  vmovaps [rsp+0x20], xmm3
0000782c7ffdbd0c  vmovaps [rsp+0x30], xmm4
0000782c7ffdbd12  vmovaps [rsp+0x40], xmm5
0000782c7ffdbd18  vmovaps [rsp+0x50], xmm6
0000782c7ffdbd1e  vmovaps [rsp+0x60], xmm7
0000782c7ffdbd24  vmovaps [rsp+0x70], xmm8
0000782c7ffdbd2a  vmovaps [rsp+0x80], xmm9
0000782c7ffdbd33  vmovaps [rsp+0x90], xmm10
0000782c7ffdbd3c  vmovaps [rsp+0xA0], xmm11
0000782c7ffdbd45  vmovaps [rsp+0xB0], xmm12
0000782c7ffdbd4e  vmovaps [rsp+0xC0], xmm13
0000782c7ffdbd57  vmovaps [rsp+0xD0], xmm14
0000782c7ffdbd60  vmovaps [rsp+0xE0], xmm15
0000782c7ffdbd69  sub rsp, 0x40
0000782c7ffdbd6d  lea rdi, [rsp]
0000782c7ffdbd71  lea rsi, [rsp+0x10]
0000782c7ffdbd76  lea rdx, [rsp+0x20]
0000782c7ffdbd7b  lea rcx, [rsp+0x30]
0000782c7ffdbd80  mov r8d, 0x00
0000782c7ffdbd86  lea r9, [r15+0x3A8]
0000782c7ffdbd8d  movaps [rdi], xmm2
0000782c7ffdbd90  movaps [rsi], xmm12
0000782c7ffdbd94  movaps [rdx], xmm6
0000782c7ffdbd97  movaps [rcx], xmm3
0000782c7ffdbd9a  mov rax, 0x5AE5BFFB5A50
0000782c7ffdbda4  call rax
0000782c7ffdbda6  movaps xmm2, [rsp]
0000782c7ffdbdaa  add rsp, 0x40
0000782c7ffdbdae  vmovaps xmm0, [rsp]
0000782c7ffdbdb3  vmovaps xmm1, [rsp+0x10]
0000782c7ffdbdb9  vmovaps xmm3, [rsp+0x20]
0000782c7ffdbdbf  vmovaps xmm4, [rsp+0x30]
0000782c7ffdbdc5  vmovaps xmm5, [rsp+0x40]
0000782c7ffdbdcb  vmovaps xmm6, [rsp+0x50]
0000782c7ffdbdd1  vmovaps xmm7, [rsp+0x60]
0000782c7ffdbdd7  vmovaps xmm8, [rsp+0x70]
0000782c7ffdbddd  vmovaps xmm9, [rsp+0x80]
0000782c7ffdbde6  vmovaps xmm10, [rsp+0x90]
0000782c7ffdbdef  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdbdf8  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdbe01  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdbe0a  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdbe13  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdbe1c  add rsp, 0xF0
0000782c7ffdbe23  pop r11
0000782c7ffdbe25  pop r10
0000782c7ffdbe27  pop r9
0000782c7ffdbe29  pop r8
0000782c7ffdbe2b  pop rsi
0000782c7ffdbe2c  pop rdi
0000782c7ffdbe2d  pop rdx
0000782c7ffdbe2e  pop rcx
0000782c7ffdbe2f  pop rax
0000782c7ffdbe30  add rsp, 0x08
0000782c7ffdbe34  jmp 0x0000782C7FFDA353
0000782c7ffdbe39  sub rsp, 0x08
0000782c7ffdbe3d  push rax
0000782c7ffdbe3e  push rcx
0000782c7ffdbe3f  push rdx
0000782c7ffdbe40  push rdi
0000782c7ffdbe41  push rsi
0000782c7ffdbe42  push r8
0000782c7ffdbe44  push r9
0000782c7ffdbe46  push r10
0000782c7ffdbe48  push r11
0000782c7ffdbe4a  sub rsp, 0xF0
0000782c7ffdbe51  vmovaps [rsp], xmm0
0000782c7ffdbe56  vmovaps [rsp+0x10], xmm1
0000782c7ffdbe5c  vmovaps [rsp+0x20], xmm2
0000782c7ffdbe62  vmovaps [rsp+0x30], xmm3
0000782c7ffdbe68  vmovaps [rsp+0x40], xmm4
0000782c7ffdbe6e  vmovaps [rsp+0x50], xmm5
0000782c7ffdbe74  vmovaps [rsp+0x60], xmm7
0000782c7ffdbe7a  vmovaps [rsp+0x70], xmm8
0000782c7ffdbe80  vmovaps [rsp+0x80], xmm9
0000782c7ffdbe89  vmovaps [rsp+0x90], xmm10
0000782c7ffdbe92  vmovaps [rsp+0xA0], xmm11
0000782c7ffdbe9b  vmovaps [rsp+0xB0], xmm12
0000782c7ffdbea4  vmovaps [rsp+0xC0], xmm13
0000782c7ffdbead  vmovaps [rsp+0xD0], xmm14
0000782c7ffdbeb6  vmovaps [rsp+0xE0], xmm15
0000782c7ffdbebf  sub rsp, 0x40
0000782c7ffdbec3  lea rdi, [rsp]
0000782c7ffdbec7  lea rsi, [rsp+0x10]
0000782c7ffdbecc  lea rdx, [rsp+0x20]
0000782c7ffdbed1  lea rcx, [rsp+0x30]
0000782c7ffdbed6  mov r8d, 0x00
0000782c7ffdbedc  lea r9, [r15+0x3A8]
0000782c7ffdbee3  movaps [rdi], xmm6
0000782c7ffdbee6  movaps [rsi], xmm10
0000782c7ffdbeea  movaps [rdx], xmm12
0000782c7ffdbeee  movaps [rcx], xmm1
0000782c7ffdbef1  mov rax, 0x5AE5BFFB5A50
0000782c7ffdbefb  call rax
0000782c7ffdbefd  movaps xmm6, [rsp]
0000782c7ffdbf01  add rsp, 0x40
0000782c7ffdbf05  vmovaps xmm0, [rsp]
0000782c7ffdbf0a  vmovaps xmm1, [rsp+0x10]
0000782c7ffdbf10  vmovaps xmm2, [rsp+0x20]
0000782c7ffdbf16  vmovaps xmm3, [rsp+0x30]
0000782c7ffdbf1c  vmovaps xmm4, [rsp+0x40]
0000782c7ffdbf22  vmovaps xmm5, [rsp+0x50]
0000782c7ffdbf28  vmovaps xmm7, [rsp+0x60]
0000782c7ffdbf2e  vmovaps xmm8, [rsp+0x70]
0000782c7ffdbf34  vmovaps xmm9, [rsp+0x80]
0000782c7ffdbf3d  vmovaps xmm10, [rsp+0x90]
0000782c7ffdbf46  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdbf4f  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdbf58  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdbf61  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdbf6a  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdbf73  add rsp, 0xF0
0000782c7ffdbf7a  pop r11
0000782c7ffdbf7c  pop r10
0000782c7ffdbf7e  pop r9
0000782c7ffdbf80  pop r8
0000782c7ffdbf82  pop rsi
0000782c7ffdbf83  pop rdi
0000782c7ffdbf84  pop rdx
0000782c7ffdbf85  pop rcx
0000782c7ffdbf86  pop rax
0000782c7ffdbf87  add rsp, 0x08
0000782c7ffdbf8b  jmp 0x0000782C7FFDA381
0000782c7ffdbf90  sub rsp, 0x08
0000782c7ffdbf94  push rax
0000782c7ffdbf95  push rcx
0000782c7ffdbf96  push rdx
0000782c7ffdbf97  push rdi
0000782c7ffdbf98  push rsi
0000782c7ffdbf99  push r8
0000782c7ffdbf9b  push r9
0000782c7ffdbf9d  push r10
0000782c7ffdbf9f  push r11
0000782c7ffdbfa1  sub rsp, 0xF0
0000782c7ffdbfa8  vmovaps [rsp], xmm0
0000782c7ffdbfad  vmovaps [rsp+0x10], xmm1
0000782c7ffdbfb3  vmovaps [rsp+0x20], xmm2
0000782c7ffdbfb9  vmovaps [rsp+0x30], xmm3
0000782c7ffdbfbf  vmovaps [rsp+0x40], xmm4
0000782c7ffdbfc5  vmovaps [rsp+0x50], xmm5
0000782c7ffdbfcb  vmovaps [rsp+0x60], xmm6
0000782c7ffdbfd1  vmovaps [rsp+0x70], xmm7
0000782c7ffdbfd7  vmovaps [rsp+0x80], xmm8
0000782c7ffdbfe0  vmovaps [rsp+0x90], xmm9
0000782c7ffdbfe9  vmovaps [rsp+0xA0], xmm11
0000782c7ffdbff2  vmovaps [rsp+0xB0], xmm12
0000782c7ffdbffb  vmovaps [rsp+0xC0], xmm13
0000782c7ffdc004  vmovaps [rsp+0xD0], xmm14
0000782c7ffdc00d  vmovaps [rsp+0xE0], xmm15
0000782c7ffdc016  sub rsp, 0x40
0000782c7ffdc01a  lea rdi, [rsp]
0000782c7ffdc01e  lea rsi, [rsp+0x10]
0000782c7ffdc023  lea rdx, [rsp+0x20]
0000782c7ffdc028  lea rcx, [rsp+0x30]
0000782c7ffdc02d  mov r8d, 0x00
0000782c7ffdc033  lea r9, [r15+0x3A8]
0000782c7ffdc03a  movaps [rdi], xmm10
0000782c7ffdc03e  movaps [rsi], xmm5
0000782c7ffdc041  movaps [rdx], xmm12
0000782c7ffdc045  movaps [rcx], xmm1
0000782c7ffdc048  mov rax, 0x5AE5BFFB5A50
0000782c7ffdc052  call rax
0000782c7ffdc054  movaps xmm10, [rsp]
0000782c7ffdc059  add rsp, 0x40
0000782c7ffdc05d  vmovaps xmm0, [rsp]
0000782c7ffdc062  vmovaps xmm1, [rsp+0x10]
0000782c7ffdc068  vmovaps xmm2, [rsp+0x20]
0000782c7ffdc06e  vmovaps xmm3, [rsp+0x30]
0000782c7ffdc074  vmovaps xmm4, [rsp+0x40]
0000782c7ffdc07a  vmovaps xmm5, [rsp+0x50]
0000782c7ffdc080  vmovaps xmm6, [rsp+0x60]
0000782c7ffdc086  vmovaps xmm7, [rsp+0x70]
0000782c7ffdc08c  vmovaps xmm8, [rsp+0x80]
0000782c7ffdc095  vmovaps xmm9, [rsp+0x90]
0000782c7ffdc09e  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdc0a7  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdc0b0  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdc0b9  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdc0c2  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdc0cb  add rsp, 0xF0
0000782c7ffdc0d2  pop r11
0000782c7ffdc0d4  pop r10
0000782c7ffdc0d6  pop r9
0000782c7ffdc0d8  pop r8
0000782c7ffdc0da  pop rsi
0000782c7ffdc0db  pop rdi
0000782c7ffdc0dc  pop rdx
0000782c7ffdc0dd  pop rcx
0000782c7ffdc0de  pop rax
0000782c7ffdc0df  add rsp, 0x08
0000782c7ffdc0e3  jmp 0x0000782C7FFDA3B0
0000782c7ffdc0e8  sub rsp, 0x08
0000782c7ffdc0ec  push rax
0000782c7ffdc0ed  push rcx
0000782c7ffdc0ee  push rdx
0000782c7ffdc0ef  push rdi
0000782c7ffdc0f0  push rsi
0000782c7ffdc0f1  push r8
0000782c7ffdc0f3  push r9
0000782c7ffdc0f5  push r10
0000782c7ffdc0f7  push r11
0000782c7ffdc0f9  sub rsp, 0xF0
0000782c7ffdc100  vmovaps [rsp], xmm0
0000782c7ffdc105  vmovaps [rsp+0x10], xmm1
0000782c7ffdc10b  vmovaps [rsp+0x20], xmm2
0000782c7ffdc111  vmovaps [rsp+0x30], xmm3
0000782c7ffdc117  vmovaps [rsp+0x40], xmm4
0000782c7ffdc11d  vmovaps [rsp+0x50], xmm5
0000782c7ffdc123  vmovaps [rsp+0x60], xmm6
0000782c7ffdc129  vmovaps [rsp+0x70], xmm7
0000782c7ffdc12f  vmovaps [rsp+0x80], xmm8
0000782c7ffdc138  vmovaps [rsp+0x90], xmm9
0000782c7ffdc141  vmovaps [rsp+0xA0], xmm10
0000782c7ffdc14a  vmovaps [rsp+0xB0], xmm11
0000782c7ffdc153  vmovaps [rsp+0xC0], xmm13
0000782c7ffdc15c  vmovaps [rsp+0xD0], xmm14
0000782c7ffdc165  vmovaps [rsp+0xE0], xmm15
0000782c7ffdc16e  sub rsp, 0x40
0000782c7ffdc172  lea rdi, [rsp]
0000782c7ffdc176  lea rsi, [rsp+0x10]
0000782c7ffdc17b  lea rdx, [rsp+0x20]
0000782c7ffdc180  lea rcx, [rsp+0x30]
0000782c7ffdc185  mov r8d, 0x00
0000782c7ffdc18b  lea r9, [r15+0x3A8]
0000782c7ffdc192  movaps [rdi], xmm12
0000782c7ffdc196  movaps [rsi], xmm7
0000782c7ffdc199  movaps [rdx], xmm15
0000782c7ffdc19d  movaps [rcx], xmm1
0000782c7ffdc1a0  mov rax, 0x5AE5BFFB5A50
0000782c7ffdc1aa  call rax
0000782c7ffdc1ac  movaps xmm12, [rsp]
0000782c7ffdc1b1  add rsp, 0x40
0000782c7ffdc1b5  vmovaps xmm0, [rsp]
0000782c7ffdc1ba  vmovaps xmm1, [rsp+0x10]
0000782c7ffdc1c0  vmovaps xmm2, [rsp+0x20]
0000782c7ffdc1c6  vmovaps xmm3, [rsp+0x30]
0000782c7ffdc1cc  vmovaps xmm4, [rsp+0x40]
0000782c7ffdc1d2  vmovaps xmm5, [rsp+0x50]
0000782c7ffdc1d8  vmovaps xmm6, [rsp+0x60]
0000782c7ffdc1de  vmovaps xmm7, [rsp+0x70]
0000782c7ffdc1e4  vmovaps xmm8, [rsp+0x80]
0000782c7ffdc1ed  vmovaps xmm9, [rsp+0x90]
0000782c7ffdc1f6  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdc1ff  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdc208  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdc211  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdc21a  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdc223  add rsp, 0xF0
0000782c7ffdc22a  pop r11
0000782c7ffdc22c  pop r10
0000782c7ffdc22e  pop r9
0000782c7ffdc230  pop r8
0000782c7ffdc232  pop rsi
0000782c7ffdc233  pop rdi
0000782c7ffdc234  pop rdx
0000782c7ffdc235  pop rcx
0000782c7ffdc236  pop rax
0000782c7ffdc237  add rsp, 0x08
0000782c7ffdc23b  jmp 0x0000782C7FFDA3D9
0000782c7ffdc240  call 0x0000782C7FDFF430
0000782c7ffdc245  jmp 0x0000782C7FFDA3E3
0000782c7ffdc24a  call 0x0000782C7FE0E760
0000782c7ffdc24f  jmp 0x0000782C7FFDA3ED
0000782c7ffdc254  sub rsp, 0x08
0000782c7ffdc258  push rax
0000782c7ffdc259  push rcx
0000782c7ffdc25a  push rdx
0000782c7ffdc25b  push rdi
0000782c7ffdc25c  push rsi
0000782c7ffdc25d  push r8
0000782c7ffdc25f  push r9
0000782c7ffdc261  push r10
0000782c7ffdc263  push r11
0000782c7ffdc265  sub rsp, 0xF0
0000782c7ffdc26c  vmovaps [rsp], xmm0
0000782c7ffdc271  vmovaps [rsp+0x10], xmm1
0000782c7ffdc277  vmovaps [rsp+0x20], xmm2
0000782c7ffdc27d  vmovaps [rsp+0x30], xmm3
0000782c7ffdc283  vmovaps [rsp+0x40], xmm4
0000782c7ffdc289  vmovaps [rsp+0x50], xmm5
0000782c7ffdc28f  vmovaps [rsp+0x60], xmm6
0000782c7ffdc295  vmovaps [rsp+0x70], xmm8
0000782c7ffdc29b  vmovaps [rsp+0x80], xmm9
0000782c7ffdc2a4  vmovaps [rsp+0x90], xmm10
0000782c7ffdc2ad  vmovaps [rsp+0xA0], xmm11
0000782c7ffdc2b6  vmovaps [rsp+0xB0], xmm12
0000782c7ffdc2bf  vmovaps [rsp+0xC0], xmm13
0000782c7ffdc2c8  vmovaps [rsp+0xD0], xmm14
0000782c7ffdc2d1  vmovaps [rsp+0xE0], xmm15
0000782c7ffdc2da  sub rsp, 0x40
0000782c7ffdc2de  lea rdi, [rsp]
0000782c7ffdc2e2  lea rsi, [rsp+0x10]
0000782c7ffdc2e7  lea rdx, [rsp+0x20]
0000782c7ffdc2ec  lea rcx, [rsp+0x30]
0000782c7ffdc2f1  mov r8d, 0x00
0000782c7ffdc2f7  lea r9, [r15+0x3A8]
0000782c7ffdc2fe  movaps [rdi], xmm7
0000782c7ffdc301  movaps [rsi], xmm2
0000782c7ffdc304  movaps [rdx], xmm9
0000782c7ffdc308  movaps [rcx], xmm11
0000782c7ffdc30c  mov rax, 0x5AE5BFFB5A50
0000782c7ffdc316  call rax
0000782c7ffdc318  movaps xmm7, [rsp]
0000782c7ffdc31c  add rsp, 0x40
0000782c7ffdc320  vmovaps xmm0, [rsp]
0000782c7ffdc325  vmovaps xmm1, [rsp+0x10]
0000782c7ffdc32b  vmovaps xmm2, [rsp+0x20]
0000782c7ffdc331  vmovaps xmm3, [rsp+0x30]
0000782c7ffdc337  vmovaps xmm4, [rsp+0x40]
0000782c7ffdc33d  vmovaps xmm5, [rsp+0x50]
0000782c7ffdc343  vmovaps xmm6, [rsp+0x60]
0000782c7ffdc349  vmovaps xmm8, [rsp+0x70]
0000782c7ffdc34f  vmovaps xmm9, [rsp+0x80]
0000782c7ffdc358  vmovaps xmm10, [rsp+0x90]
0000782c7ffdc361  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdc36a  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdc373  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdc37c  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdc385  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdc38e  add rsp, 0xF0
0000782c7ffdc395  pop r11
0000782c7ffdc397  pop r10
0000782c7ffdc399  pop r9
0000782c7ffdc39b  pop r8
0000782c7ffdc39d  pop rsi
0000782c7ffdc39e  pop rdi
0000782c7ffdc39f  pop rdx
0000782c7ffdc3a0  pop rcx
0000782c7ffdc3a1  pop rax
0000782c7ffdc3a2  add rsp, 0x08
0000782c7ffdc3a6  jmp 0x0000782C7FFDA421
0000782c7ffdc3ab  sub rsp, 0x08
0000782c7ffdc3af  push rax
0000782c7ffdc3b0  push rcx
0000782c7ffdc3b1  push rdx
0000782c7ffdc3b2  push rdi
0000782c7ffdc3b3  push rsi
0000782c7ffdc3b4  push r8
0000782c7ffdc3b6  push r9
0000782c7ffdc3b8  push r10
0000782c7ffdc3ba  push r11
0000782c7ffdc3bc  sub rsp, 0xF0
0000782c7ffdc3c3  vmovaps [rsp], xmm0
0000782c7ffdc3c8  vmovaps [rsp+0x10], xmm1
0000782c7ffdc3ce  vmovaps [rsp+0x20], xmm2
0000782c7ffdc3d4  vmovaps [rsp+0x30], xmm3
0000782c7ffdc3da  vmovaps [rsp+0x40], xmm4
0000782c7ffdc3e0  vmovaps [rsp+0x50], xmm5
0000782c7ffdc3e6  vmovaps [rsp+0x60], xmm6
0000782c7ffdc3ec  vmovaps [rsp+0x70], xmm7
0000782c7ffdc3f2  vmovaps [rsp+0x80], xmm8
0000782c7ffdc3fb  vmovaps [rsp+0x90], xmm10
0000782c7ffdc404  vmovaps [rsp+0xA0], xmm11
0000782c7ffdc40d  vmovaps [rsp+0xB0], xmm12
0000782c7ffdc416  vmovaps [rsp+0xC0], xmm13
0000782c7ffdc41f  vmovaps [rsp+0xD0], xmm14
0000782c7ffdc428  vmovaps [rsp+0xE0], xmm15
0000782c7ffdc431  sub rsp, 0x40
0000782c7ffdc435  lea rdi, [rsp]
0000782c7ffdc439  lea rsi, [rsp+0x10]
0000782c7ffdc43e  lea rdx, [rsp+0x20]
0000782c7ffdc443  lea rcx, [rsp+0x30]
0000782c7ffdc448  mov r8d, 0x00
0000782c7ffdc44e  lea r9, [r15+0x3A8]
0000782c7ffdc455  movaps [rdi], xmm9
0000782c7ffdc459  movaps [rsi], xmm6
0000782c7ffdc45c  movaps [rdx], xmm1
0000782c7ffdc45f  movaps [rcx], xmm11
0000782c7ffdc463  mov rax, 0x5AE5BFFB5A50
0000782c7ffdc46d  call rax
0000782c7ffdc46f  movaps xmm9, [rsp]
0000782c7ffdc474  add rsp, 0x40
0000782c7ffdc478  vmovaps xmm0, [rsp]
0000782c7ffdc47d  vmovaps xmm1, [rsp+0x10]
0000782c7ffdc483  vmovaps xmm2, [rsp+0x20]
0000782c7ffdc489  vmovaps xmm3, [rsp+0x30]
0000782c7ffdc48f  vmovaps xmm4, [rsp+0x40]
0000782c7ffdc495  vmovaps xmm5, [rsp+0x50]
0000782c7ffdc49b  vmovaps xmm6, [rsp+0x60]
0000782c7ffdc4a1  vmovaps xmm7, [rsp+0x70]
0000782c7ffdc4a7  vmovaps xmm8, [rsp+0x80]
0000782c7ffdc4b0  vmovaps xmm10, [rsp+0x90]
0000782c7ffdc4b9  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdc4c2  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdc4cb  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdc4d4  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdc4dd  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdc4e6  add rsp, 0xF0
0000782c7ffdc4ed  pop r11
0000782c7ffdc4ef  pop r10
0000782c7ffdc4f1  pop r9
0000782c7ffdc4f3  pop r8
0000782c7ffdc4f5  pop rsi
0000782c7ffdc4f6  pop rdi
0000782c7ffdc4f7  pop rdx
0000782c7ffdc4f8  pop rcx
0000782c7ffdc4f9  pop rax
0000782c7ffdc4fa  add rsp, 0x08
0000782c7ffdc4fe  jmp 0x0000782C7FFDA447
0000782c7ffdc503  sub rsp, 0x08
0000782c7ffdc507  push rax
0000782c7ffdc508  push rcx
0000782c7ffdc509  push rdx
0000782c7ffdc50a  push rdi
0000782c7ffdc50b  push rsi
0000782c7ffdc50c  push r8
0000782c7ffdc50e  push r9
0000782c7ffdc510  push r10
0000782c7ffdc512  push r11
0000782c7ffdc514  sub rsp, 0xF0
0000782c7ffdc51b  vmovaps [rsp], xmm0
0000782c7ffdc520  vmovaps [rsp+0x10], xmm1
0000782c7ffdc526  vmovaps [rsp+0x20], xmm2
0000782c7ffdc52c  vmovaps [rsp+0x30], xmm3
0000782c7ffdc532  vmovaps [rsp+0x40], xmm4
0000782c7ffdc538  vmovaps [rsp+0x50], xmm5
0000782c7ffdc53e  vmovaps [rsp+0x60], xmm6
0000782c7ffdc544  vmovaps [rsp+0x70], xmm7
0000782c7ffdc54a  vmovaps [rsp+0x80], xmm8
0000782c7ffdc553  vmovaps [rsp+0x90], xmm9
0000782c7ffdc55c  vmovaps [rsp+0xA0], xmm10
0000782c7ffdc565  vmovaps [rsp+0xB0], xmm12
0000782c7ffdc56e  vmovaps [rsp+0xC0], xmm13
0000782c7ffdc577  vmovaps [rsp+0xD0], xmm14
0000782c7ffdc580  vmovaps [rsp+0xE0], xmm15
0000782c7ffdc589  sub rsp, 0x40
0000782c7ffdc58d  lea rdi, [rsp]
0000782c7ffdc591  lea rsi, [rsp+0x10]
0000782c7ffdc596  lea rdx, [rsp+0x20]
0000782c7ffdc59b  lea rcx, [rsp+0x30]
0000782c7ffdc5a0  mov r8d, 0x00
0000782c7ffdc5a6  lea r9, [r15+0x3A8]
0000782c7ffdc5ad  movaps [rdi], xmm11
0000782c7ffdc5b1  movaps [rsi], xmm10
0000782c7ffdc5b5  movaps [rdx], xmm8
0000782c7ffdc5b9  movaps [rcx], xmm1
0000782c7ffdc5bc  mov rax, 0x5AE5BFFB5A50
0000782c7ffdc5c6  call rax
0000782c7ffdc5c8  movaps xmm11, [rsp]
0000782c7ffdc5cd  add rsp, 0x40
0000782c7ffdc5d1  vmovaps xmm0, [rsp]
0000782c7ffdc5d6  vmovaps xmm1, [rsp+0x10]
0000782c7ffdc5dc  vmovaps xmm2, [rsp+0x20]
0000782c7ffdc5e2  vmovaps xmm3, [rsp+0x30]
0000782c7ffdc5e8  vmovaps xmm4, [rsp+0x40]
0000782c7ffdc5ee  vmovaps xmm5, [rsp+0x50]
0000782c7ffdc5f4  vmovaps xmm6, [rsp+0x60]
0000782c7ffdc5fa  vmovaps xmm7, [rsp+0x70]
0000782c7ffdc600  vmovaps xmm8, [rsp+0x80]
0000782c7ffdc609  vmovaps xmm9, [rsp+0x90]
0000782c7ffdc612  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdc61b  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdc624  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdc62d  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdc636  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdc63f  add rsp, 0xF0
0000782c7ffdc646  pop r11
0000782c7ffdc648  pop r10
0000782c7ffdc64a  pop r9
0000782c7ffdc64c  pop r8
0000782c7ffdc64e  pop rsi
0000782c7ffdc64f  pop rdi
0000782c7ffdc650  pop rdx
0000782c7ffdc651  pop rcx
0000782c7ffdc652  pop rax
0000782c7ffdc653  add rsp, 0x08
0000782c7ffdc657  jmp 0x0000782C7FFDA46D
0000782c7ffdc65c  sub rsp, 0x08
0000782c7ffdc660  push rax
0000782c7ffdc661  push rcx
0000782c7ffdc662  push rdx
0000782c7ffdc663  push rdi
0000782c7ffdc664  push rsi
0000782c7ffdc665  push r8
0000782c7ffdc667  push r9
0000782c7ffdc669  push r10
0000782c7ffdc66b  push r11
0000782c7ffdc66d  sub rsp, 0xF0
0000782c7ffdc674  vmovaps [rsp], xmm0
0000782c7ffdc679  vmovaps [rsp+0x10], xmm1
0000782c7ffdc67f  vmovaps [rsp+0x20], xmm2
0000782c7ffdc685  vmovaps [rsp+0x30], xmm3
0000782c7ffdc68b  vmovaps [rsp+0x40], xmm4
0000782c7ffdc691  vmovaps [rsp+0x50], xmm5
0000782c7ffdc697  vmovaps [rsp+0x60], xmm6
0000782c7ffdc69d  vmovaps [rsp+0x70], xmm7
0000782c7ffdc6a3  vmovaps [rsp+0x80], xmm8
0000782c7ffdc6ac  vmovaps [rsp+0x90], xmm9
0000782c7ffdc6b5  vmovaps [rsp+0xA0], xmm11
0000782c7ffdc6be  vmovaps [rsp+0xB0], xmm12
0000782c7ffdc6c7  vmovaps [rsp+0xC0], xmm13
0000782c7ffdc6d0  vmovaps [rsp+0xD0], xmm14
0000782c7ffdc6d9  vmovaps [rsp+0xE0], xmm15
0000782c7ffdc6e2  sub rsp, 0x40
0000782c7ffdc6e6  lea rdi, [rsp]
0000782c7ffdc6ea  lea rsi, [rsp+0x10]
0000782c7ffdc6ef  lea rdx, [rsp+0x20]
0000782c7ffdc6f4  lea rcx, [rsp+0x30]
0000782c7ffdc6f9  mov r8d, 0x00
0000782c7ffdc6ff  lea r9, [r15+0x3A8]
0000782c7ffdc706  movaps [rdi], xmm10
0000782c7ffdc70a  movaps [rsi], xmm12
0000782c7ffdc70e  movaps [rdx], xmm13
0000782c7ffdc712  movaps [rcx], xmm1
0000782c7ffdc715  mov rax, 0x5AE5BFFB5A50
0000782c7ffdc71f  call rax
0000782c7ffdc721  movaps xmm10, [rsp]
0000782c7ffdc726  add rsp, 0x40
0000782c7ffdc72a  vmovaps xmm0, [rsp]
0000782c7ffdc72f  vmovaps xmm1, [rsp+0x10]
0000782c7ffdc735  vmovaps xmm2, [rsp+0x20]
0000782c7ffdc73b  vmovaps xmm3, [rsp+0x30]
0000782c7ffdc741  vmovaps xmm4, [rsp+0x40]
0000782c7ffdc747  vmovaps xmm5, [rsp+0x50]
0000782c7ffdc74d  vmovaps xmm6, [rsp+0x60]
0000782c7ffdc753  vmovaps xmm7, [rsp+0x70]
0000782c7ffdc759  vmovaps xmm8, [rsp+0x80]
0000782c7ffdc762  vmovaps xmm9, [rsp+0x90]
0000782c7ffdc76b  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdc774  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdc77d  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdc786  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdc78f  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdc798  add rsp, 0xF0
0000782c7ffdc79f  pop r11
0000782c7ffdc7a1  pop r10
0000782c7ffdc7a3  pop r9
0000782c7ffdc7a5  pop r8
0000782c7ffdc7a7  pop rsi
0000782c7ffdc7a8  pop rdi
0000782c7ffdc7a9  pop rdx
0000782c7ffdc7aa  pop rcx
0000782c7ffdc7ab  pop rax
0000782c7ffdc7ac  add rsp, 0x08
0000782c7ffdc7b0  jmp 0x0000782C7FFDA493
0000782c7ffdc7b5  call 0x0000782C7FDFF430
0000782c7ffdc7ba  jmp 0x0000782C7FFDA49D
0000782c7ffdc7bf  call 0x0000782C7FE0C260
0000782c7ffdc7c4  jmp 0x0000782C7FFDA4A7
0000782c7ffdc7c9  sub rsp, 0x08
0000782c7ffdc7cd  push rax
0000782c7ffdc7ce  push rcx
0000782c7ffdc7cf  push rdx
0000782c7ffdc7d0  push rdi
0000782c7ffdc7d1  push rsi
0000782c7ffdc7d2  push r8
0000782c7ffdc7d4  push r9
0000782c7ffdc7d6  push r10
0000782c7ffdc7d8  push r11
0000782c7ffdc7da  sub rsp, 0xF0
0000782c7ffdc7e1  vmovaps [rsp], xmm0
0000782c7ffdc7e6  vmovaps [rsp+0x10], xmm1
0000782c7ffdc7ec  vmovaps [rsp+0x20], xmm2
0000782c7ffdc7f2  vmovaps [rsp+0x30], xmm3
0000782c7ffdc7f8  vmovaps [rsp+0x40], xmm4
0000782c7ffdc7fe  vmovaps [rsp+0x50], xmm5
0000782c7ffdc804  vmovaps [rsp+0x60], xmm6
0000782c7ffdc80a  vmovaps [rsp+0x70], xmm7
0000782c7ffdc810  vmovaps [rsp+0x80], xmm9
0000782c7ffdc819  vmovaps [rsp+0x90], xmm10
0000782c7ffdc822  vmovaps [rsp+0xA0], xmm11
0000782c7ffdc82b  vmovaps [rsp+0xB0], xmm12
0000782c7ffdc834  vmovaps [rsp+0xC0], xmm13
0000782c7ffdc83d  vmovaps [rsp+0xD0], xmm14
0000782c7ffdc846  vmovaps [rsp+0xE0], xmm15
0000782c7ffdc84f  sub rsp, 0x40
0000782c7ffdc853  lea rdi, [rsp]
0000782c7ffdc857  lea rsi, [rsp+0x10]
0000782c7ffdc85c  lea rdx, [rsp+0x20]
0000782c7ffdc861  lea rcx, [rsp+0x30]
0000782c7ffdc866  mov r8d, 0x00
0000782c7ffdc86c  lea r9, [r15+0x3A8]
0000782c7ffdc873  movaps [rdi], xmm8
0000782c7ffdc877  movaps [rsi], xmm7
0000782c7ffdc87a  movaps [rdx], xmm4
0000782c7ffdc87d  movaps [rcx], xmm12
0000782c7ffdc881  mov rax, 0x5AE5BFFB5A50
0000782c7ffdc88b  call rax
0000782c7ffdc88d  movaps xmm8, [rsp]
0000782c7ffdc892  add rsp, 0x40
0000782c7ffdc896  vmovaps xmm0, [rsp]
0000782c7ffdc89b  vmovaps xmm1, [rsp+0x10]
0000782c7ffdc8a1  vmovaps xmm2, [rsp+0x20]
0000782c7ffdc8a7  vmovaps xmm3, [rsp+0x30]
0000782c7ffdc8ad  vmovaps xmm4, [rsp+0x40]
0000782c7ffdc8b3  vmovaps xmm5, [rsp+0x50]
0000782c7ffdc8b9  vmovaps xmm6, [rsp+0x60]
0000782c7ffdc8bf  vmovaps xmm7, [rsp+0x70]
0000782c7ffdc8c5  vmovaps xmm9, [rsp+0x80]
0000782c7ffdc8ce  vmovaps xmm10, [rsp+0x90]
0000782c7ffdc8d7  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdc8e0  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdc8e9  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdc8f2  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdc8fb  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdc904  add rsp, 0xF0
0000782c7ffdc90b  pop r11
0000782c7ffdc90d  pop r10
0000782c7ffdc90f  pop r9
0000782c7ffdc911  pop r8
0000782c7ffdc913  pop rsi
0000782c7ffdc914  pop rdi
0000782c7ffdc915  pop rdx
0000782c7ffdc916  pop rcx
0000782c7ffdc917  pop rax
0000782c7ffdc918  add rsp, 0x08
0000782c7ffdc91c  jmp 0x0000782C7FFDA4D0
0000782c7ffdc921  sub rsp, 0x08
0000782c7ffdc925  push rax
0000782c7ffdc926  push rcx
0000782c7ffdc927  push rdx
0000782c7ffdc928  push rdi
0000782c7ffdc929  push rsi
0000782c7ffdc92a  push r8
0000782c7ffdc92c  push r9
0000782c7ffdc92e  push r10
0000782c7ffdc930  push r11
0000782c7ffdc932  sub rsp, 0xF0
0000782c7ffdc939  vmovaps [rsp], xmm0
0000782c7ffdc93e  vmovaps [rsp+0x10], xmm1
0000782c7ffdc944  vmovaps [rsp+0x20], xmm2
0000782c7ffdc94a  vmovaps [rsp+0x30], xmm3
0000782c7ffdc950  vmovaps [rsp+0x40], xmm4
0000782c7ffdc956  vmovaps [rsp+0x50], xmm5
0000782c7ffdc95c  vmovaps [rsp+0x60], xmm6
0000782c7ffdc962  vmovaps [rsp+0x70], xmm8
0000782c7ffdc968  vmovaps [rsp+0x80], xmm9
0000782c7ffdc971  vmovaps [rsp+0x90], xmm10
0000782c7ffdc97a  vmovaps [rsp+0xA0], xmm11
0000782c7ffdc983  vmovaps [rsp+0xB0], xmm12
0000782c7ffdc98c  vmovaps [rsp+0xC0], xmm13
0000782c7ffdc995  vmovaps [rsp+0xD0], xmm14
0000782c7ffdc99e  vmovaps [rsp+0xE0], xmm15
0000782c7ffdc9a7  sub rsp, 0x40
0000782c7ffdc9ab  lea rdi, [rsp]
0000782c7ffdc9af  lea rsi, [rsp+0x10]
0000782c7ffdc9b4  lea rdx, [rsp+0x20]
0000782c7ffdc9b9  lea rcx, [rsp+0x30]
0000782c7ffdc9be  mov r8d, 0x00
0000782c7ffdc9c4  lea r9, [r15+0x3A8]
0000782c7ffdc9cb  movaps [rdi], xmm7
0000782c7ffdc9ce  movaps [rsi], xmm9
0000782c7ffdc9d2  movaps [rdx], xmm14
0000782c7ffdc9d6  movaps [rcx], xmm12
0000782c7ffdc9da  mov rax, 0x5AE5BFFB5A50
0000782c7ffdc9e4  call rax
0000782c7ffdc9e6  movaps xmm7, [rsp]
0000782c7ffdc9ea  add rsp, 0x40
0000782c7ffdc9ee  vmovaps xmm0, [rsp]
0000782c7ffdc9f3  vmovaps xmm1, [rsp+0x10]
0000782c7ffdc9f9  vmovaps xmm2, [rsp+0x20]
0000782c7ffdc9ff  vmovaps xmm3, [rsp+0x30]
0000782c7ffdca05  vmovaps xmm4, [rsp+0x40]
0000782c7ffdca0b  vmovaps xmm5, [rsp+0x50]
0000782c7ffdca11  vmovaps xmm6, [rsp+0x60]
0000782c7ffdca17  vmovaps xmm8, [rsp+0x70]
0000782c7ffdca1d  vmovaps xmm9, [rsp+0x80]
0000782c7ffdca26  vmovaps xmm10, [rsp+0x90]
0000782c7ffdca2f  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdca38  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdca41  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdca4a  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdca53  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdca5c  add rsp, 0xF0
0000782c7ffdca63  pop r11
0000782c7ffdca65  pop r10
0000782c7ffdca67  pop r9
0000782c7ffdca69  pop r8
0000782c7ffdca6b  pop rsi
0000782c7ffdca6c  pop rdi
0000782c7ffdca6d  pop rdx
0000782c7ffdca6e  pop rcx
0000782c7ffdca6f  pop rax
0000782c7ffdca70  add rsp, 0x08
0000782c7ffdca74  jmp 0x0000782C7FFDA4F8
0000782c7ffdca79  sub rsp, 0x08
0000782c7ffdca7d  push rax
0000782c7ffdca7e  push rcx
0000782c7ffdca7f  push rdx
0000782c7ffdca80  push rdi
0000782c7ffdca81  push rsi
0000782c7ffdca82  push r8
0000782c7ffdca84  push r9
0000782c7ffdca86  push r10
0000782c7ffdca88  push r11
0000782c7ffdca8a  sub rsp, 0xF0
0000782c7ffdca91  vmovaps [rsp], xmm0
0000782c7ffdca96  vmovaps [rsp+0x10], xmm1
0000782c7ffdca9c  vmovaps [rsp+0x20], xmm2
0000782c7ffdcaa2  vmovaps [rsp+0x30], xmm3
0000782c7ffdcaa8  vmovaps [rsp+0x40], xmm4
0000782c7ffdcaae  vmovaps [rsp+0x50], xmm5
0000782c7ffdcab4  vmovaps [rsp+0x60], xmm6
0000782c7ffdcaba  vmovaps [rsp+0x70], xmm7
0000782c7ffdcac0  vmovaps [rsp+0x80], xmm8
0000782c7ffdcac9  vmovaps [rsp+0x90], xmm9
0000782c7ffdcad2  vmovaps [rsp+0xA0], xmm10
0000782c7ffdcadb  vmovaps [rsp+0xB0], xmm11
0000782c7ffdcae4  vmovaps [rsp+0xC0], xmm13
0000782c7ffdcaed  vmovaps [rsp+0xD0], xmm14
0000782c7ffdcaf6  vmovaps [rsp+0xE0], xmm15
0000782c7ffdcaff  sub rsp, 0x40
0000782c7ffdcb03  lea rdi, [rsp]
0000782c7ffdcb07  lea rsi, [rsp+0x10]
0000782c7ffdcb0c  lea rdx, [rsp+0x20]
0000782c7ffdcb11  lea rcx, [rsp+0x30]
0000782c7ffdcb16  mov r8d, 0x00
0000782c7ffdcb1c  lea r9, [r15+0x3A8]
0000782c7ffdcb23  movaps [rdi], xmm12
0000782c7ffdcb27  movaps [rsi], xmm11
0000782c7ffdcb2b  movaps [rdx], xmm15
0000782c7ffdcb2f  movaps [rcx], xmm14
0000782c7ffdcb33  mov rax, 0x5AE5BFFB5A50
0000782c7ffdcb3d  call rax
0000782c7ffdcb3f  movaps xmm12, [rsp]
0000782c7ffdcb44  add rsp, 0x40
0000782c7ffdcb48  vmovaps xmm0, [rsp]
0000782c7ffdcb4d  vmovaps xmm1, [rsp+0x10]
0000782c7ffdcb53  vmovaps xmm2, [rsp+0x20]
0000782c7ffdcb59  vmovaps xmm3, [rsp+0x30]
0000782c7ffdcb5f  vmovaps xmm4, [rsp+0x40]
0000782c7ffdcb65  vmovaps xmm5, [rsp+0x50]
0000782c7ffdcb6b  vmovaps xmm6, [rsp+0x60]
0000782c7ffdcb71  vmovaps xmm7, [rsp+0x70]
0000782c7ffdcb77  vmovaps xmm8, [rsp+0x80]
0000782c7ffdcb80  vmovaps xmm9, [rsp+0x90]
0000782c7ffdcb89  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdcb92  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdcb9b  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdcba4  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdcbad  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdcbb6  add rsp, 0xF0
0000782c7ffdcbbd  pop r11
0000782c7ffdcbbf  pop r10
0000782c7ffdcbc1  pop r9
0000782c7ffdcbc3  pop r8
0000782c7ffdcbc5  pop rsi
0000782c7ffdcbc6  pop rdi
0000782c7ffdcbc7  pop rdx
0000782c7ffdcbc8  pop rcx
0000782c7ffdcbc9  pop rax
0000782c7ffdcbca  add rsp, 0x08
0000782c7ffdcbce  jmp 0x0000782C7FFDA521
0000782c7ffdcbd3  sub rsp, 0x08
0000782c7ffdcbd7  push rax
0000782c7ffdcbd8  push rcx
0000782c7ffdcbd9  push rdx
0000782c7ffdcbda  push rdi
0000782c7ffdcbdb  push rsi
0000782c7ffdcbdc  push r8
0000782c7ffdcbde  push r9
0000782c7ffdcbe0  push r10
0000782c7ffdcbe2  push r11
0000782c7ffdcbe4  sub rsp, 0xF0
0000782c7ffdcbeb  vmovaps [rsp], xmm0
0000782c7ffdcbf0  vmovaps [rsp+0x10], xmm1
0000782c7ffdcbf6  vmovaps [rsp+0x20], xmm2
0000782c7ffdcbfc  vmovaps [rsp+0x30], xmm3
0000782c7ffdcc02  vmovaps [rsp+0x40], xmm4
0000782c7ffdcc08  vmovaps [rsp+0x50], xmm5
0000782c7ffdcc0e  vmovaps [rsp+0x60], xmm6
0000782c7ffdcc14  vmovaps [rsp+0x70], xmm7
0000782c7ffdcc1a  vmovaps [rsp+0x80], xmm8
0000782c7ffdcc23  vmovaps [rsp+0x90], xmm9
0000782c7ffdcc2c  vmovaps [rsp+0xA0], xmm10
0000782c7ffdcc35  vmovaps [rsp+0xB0], xmm12
0000782c7ffdcc3e  vmovaps [rsp+0xC0], xmm13
0000782c7ffdcc47  vmovaps [rsp+0xD0], xmm14
0000782c7ffdcc50  vmovaps [rsp+0xE0], xmm15
0000782c7ffdcc59  sub rsp, 0x40
0000782c7ffdcc5d  lea rdi, [rsp]
0000782c7ffdcc61  lea rsi, [rsp+0x10]
0000782c7ffdcc66  lea rdx, [rsp+0x20]
0000782c7ffdcc6b  lea rcx, [rsp+0x30]
0000782c7ffdcc70  mov r8d, 0x00
0000782c7ffdcc76  lea r9, [r15+0x3A8]
0000782c7ffdcc7d  movaps [rdi], xmm11
0000782c7ffdcc81  movaps [rsi], xmm10
0000782c7ffdcc85  movaps [rdx], xmm13
0000782c7ffdcc89  movaps [rcx], xmm15
0000782c7ffdcc8d  mov rax, 0x5AE5BFFB5A50
0000782c7ffdcc97  call rax
0000782c7ffdcc99  movaps xmm11, [rsp]
0000782c7ffdcc9e  add rsp, 0x40
0000782c7ffdcca2  vmovaps xmm0, [rsp]
0000782c7ffdcca7  vmovaps xmm1, [rsp+0x10]
0000782c7ffdccad  vmovaps xmm2, [rsp+0x20]
0000782c7ffdccb3  vmovaps xmm3, [rsp+0x30]
0000782c7ffdccb9  vmovaps xmm4, [rsp+0x40]
0000782c7ffdccbf  vmovaps xmm5, [rsp+0x50]
0000782c7ffdccc5  vmovaps xmm6, [rsp+0x60]
0000782c7ffdcccb  vmovaps xmm7, [rsp+0x70]
0000782c7ffdccd1  vmovaps xmm8, [rsp+0x80]
0000782c7ffdccda  vmovaps xmm9, [rsp+0x90]
0000782c7ffdcce3  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdccec  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdccf5  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdccfe  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdcd07  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdcd10  add rsp, 0xF0
0000782c7ffdcd17  pop r11
0000782c7ffdcd19  pop r10
0000782c7ffdcd1b  pop r9
0000782c7ffdcd1d  pop r8
0000782c7ffdcd1f  pop rsi
0000782c7ffdcd20  pop rdi
0000782c7ffdcd21  pop rdx
0000782c7ffdcd22  pop rcx
0000782c7ffdcd23  pop rax
0000782c7ffdcd24  add rsp, 0x08
0000782c7ffdcd28  jmp 0x0000782C7FFDA54A
0000782c7ffdcd2d  call 0x0000782C7FE0E760
0000782c7ffdcd32  jmp 0x0000782C7FFDA557
0000782c7ffdcd37  call 0x0000782C7FE0D4E0
0000782c7ffdcd3c  jmp 0x0000782C7FFDA564
0000782c7ffdcd41  sub rsp, 0x08
0000782c7ffdcd45  push rax
0000782c7ffdcd46  push rcx
0000782c7ffdcd47  push rdx
0000782c7ffdcd48  push rdi
0000782c7ffdcd49  push rsi
0000782c7ffdcd4a  push r8
0000782c7ffdcd4c  push r9
0000782c7ffdcd4e  push r10
0000782c7ffdcd50  push r11
0000782c7ffdcd52  sub rsp, 0xF0
0000782c7ffdcd59  vmovaps [rsp], xmm0
0000782c7ffdcd5e  vmovaps [rsp+0x10], xmm1
0000782c7ffdcd64  vmovaps [rsp+0x20], xmm2
0000782c7ffdcd6a  vmovaps [rsp+0x30], xmm3
0000782c7ffdcd70  vmovaps [rsp+0x40], xmm4
0000782c7ffdcd76  vmovaps [rsp+0x50], xmm5
0000782c7ffdcd7c  vmovaps [rsp+0x60], xmm6
0000782c7ffdcd82  vmovaps [rsp+0x70], xmm7
0000782c7ffdcd88  vmovaps [rsp+0x80], xmm8
0000782c7ffdcd91  vmovaps [rsp+0x90], xmm9
0000782c7ffdcd9a  vmovaps [rsp+0xA0], xmm11
0000782c7ffdcda3  vmovaps [rsp+0xB0], xmm12
0000782c7ffdcdac  vmovaps [rsp+0xC0], xmm13
0000782c7ffdcdb5  vmovaps [rsp+0xD0], xmm14
0000782c7ffdcdbe  vmovaps [rsp+0xE0], xmm15
0000782c7ffdcdc7  sub rsp, 0x40
0000782c7ffdcdcb  lea rdi, [rsp]
0000782c7ffdcdcf  lea rsi, [rsp+0x10]
0000782c7ffdcdd4  lea rdx, [rsp+0x20]
0000782c7ffdcdd9  lea rcx, [rsp+0x30]
0000782c7ffdcdde  mov r8d, 0x00
0000782c7ffdcde4  lea r9, [r15+0x3A8]
0000782c7ffdcdeb  movaps [rdi], xmm10
0000782c7ffdcdef  movaps [rsi], xmm8
0000782c7ffdcdf3  movaps [rdx], xmm1
0000782c7ffdcdf6  movaps [rcx], xmm13
0000782c7ffdcdfa  mov rax, 0x5AE5BFFB5A50
0000782c7ffdce04  call rax
0000782c7ffdce06  movaps xmm10, [rsp]
0000782c7ffdce0b  add rsp, 0x40
0000782c7ffdce0f  vmovaps xmm0, [rsp]
0000782c7ffdce14  vmovaps xmm1, [rsp+0x10]
0000782c7ffdce1a  vmovaps xmm2, [rsp+0x20]
0000782c7ffdce20  vmovaps xmm3, [rsp+0x30]
0000782c7ffdce26  vmovaps xmm4, [rsp+0x40]
0000782c7ffdce2c  vmovaps xmm5, [rsp+0x50]
0000782c7ffdce32  vmovaps xmm6, [rsp+0x60]
0000782c7ffdce38  vmovaps xmm7, [rsp+0x70]
0000782c7ffdce3e  vmovaps xmm8, [rsp+0x80]
0000782c7ffdce47  vmovaps xmm9, [rsp+0x90]
0000782c7ffdce50  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdce59  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdce62  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdce6b  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdce74  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdce7d  add rsp, 0xF0
0000782c7ffdce84  pop r11
0000782c7ffdce86  pop r10
0000782c7ffdce88  pop r9
0000782c7ffdce8a  pop r8
0000782c7ffdce8c  pop rsi
0000782c7ffdce8d  pop rdi
0000782c7ffdce8e  pop rdx
0000782c7ffdce8f  pop rcx
0000782c7ffdce90  pop rax
0000782c7ffdce91  add rsp, 0x08
0000782c7ffdce95  jmp 0x0000782C7FFDA59A
0000782c7ffdce9a  call 0x0000782C7FDFF430
0000782c7ffdce9f  jmp 0x0000782C7FFDA5AC
0000782c7ffdcea4  sub rsp, 0x08
0000782c7ffdcea8  push rax
0000782c7ffdcea9  push rcx
0000782c7ffdceaa  push rdx
0000782c7ffdceab  push rdi
0000782c7ffdceac  push rsi
0000782c7ffdcead  push r8
0000782c7ffdceaf  push r9
0000782c7ffdceb1  push r10
0000782c7ffdceb3  push r11
0000782c7ffdceb5  sub rsp, 0xF0
0000782c7ffdcebc  vmovaps [rsp], xmm0
0000782c7ffdcec1  vmovaps [rsp+0x10], xmm1
0000782c7ffdcec7  vmovaps [rsp+0x20], xmm2
0000782c7ffdcecd  vmovaps [rsp+0x30], xmm3
0000782c7ffdced3  vmovaps [rsp+0x40], xmm4
0000782c7ffdced9  vmovaps [rsp+0x50], xmm5
0000782c7ffdcedf  vmovaps [rsp+0x60], xmm6
0000782c7ffdcee5  vmovaps [rsp+0x70], xmm7
0000782c7ffdceeb  vmovaps [rsp+0x80], xmm8
0000782c7ffdcef4  vmovaps [rsp+0x90], xmm10
0000782c7ffdcefd  vmovaps [rsp+0xA0], xmm11
0000782c7ffdcf06  vmovaps [rsp+0xB0], xmm12
0000782c7ffdcf0f  vmovaps [rsp+0xC0], xmm13
0000782c7ffdcf18  vmovaps [rsp+0xD0], xmm14
0000782c7ffdcf21  vmovaps [rsp+0xE0], xmm15
0000782c7ffdcf2a  sub rsp, 0x40
0000782c7ffdcf2e  lea rdi, [rsp]
0000782c7ffdcf32  lea rsi, [rsp+0x10]
0000782c7ffdcf37  lea rdx, [rsp+0x20]
0000782c7ffdcf3c  lea rcx, [rsp+0x30]
0000782c7ffdcf41  mov r8d, 0x00
0000782c7ffdcf47  lea r9, [r15+0x3A8]
0000782c7ffdcf4e  movaps [rdi], xmm9
0000782c7ffdcf52  movaps [rsi], xmm7
0000782c7ffdcf55  movaps [rdx], xmm14
0000782c7ffdcf59  movaps [rcx], xmm13
0000782c7ffdcf5d  mov rax, 0x5AE5BFFB5A50
0000782c7ffdcf67  call rax
0000782c7ffdcf69  movaps xmm9, [rsp]
0000782c7ffdcf6e  add rsp, 0x40
0000782c7ffdcf72  vmovaps xmm0, [rsp]
0000782c7ffdcf77  vmovaps xmm1, [rsp+0x10]
0000782c7ffdcf7d  vmovaps xmm2, [rsp+0x20]
0000782c7ffdcf83  vmovaps xmm3, [rsp+0x30]
0000782c7ffdcf89  vmovaps xmm4, [rsp+0x40]
0000782c7ffdcf8f  vmovaps xmm5, [rsp+0x50]
0000782c7ffdcf95  vmovaps xmm6, [rsp+0x60]
0000782c7ffdcf9b  vmovaps xmm7, [rsp+0x70]
0000782c7ffdcfa1  vmovaps xmm8, [rsp+0x80]
0000782c7ffdcfaa  vmovaps xmm10, [rsp+0x90]
0000782c7ffdcfb3  vmovaps xmm11, [rsp+0xA0]
0000782c7ffdcfbc  vmovaps xmm12, [rsp+0xB0]
0000782c7ffdcfc5  vmovaps xmm13, [rsp+0xC0]
0000782c7ffdcfce  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdcfd7  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdcfe0  add rsp, 0xF0
0000782c7ffdcfe7  pop r11
0000782c7ffdcfe9  pop r10
0000782c7ffdcfeb  pop r9
0000782c7ffdcfed  pop r8
0000782c7ffdcfef  pop rsi
0000782c7ffdcff0  pop rdi
0000782c7ffdcff1  pop rdx
0000782c7ffdcff2  pop rcx
0000782c7ffdcff3  pop rax
0000782c7ffdcff4  add rsp, 0x08
0000782c7ffdcff8  jmp 0x0000782C7FFDA5DA
0000782c7ffdcffd  sub rsp, 0x08
0000782c7ffdd001  push rax
0000782c7ffdd002  push rcx
0000782c7ffdd003  push rdx
0000782c7ffdd004  push rdi
0000782c7ffdd005  push rsi
0000782c7ffdd006  push r8
0000782c7ffdd008  push r9
0000782c7ffdd00a  push r10
0000782c7ffdd00c  push r11
0000782c7ffdd00e  sub rsp, 0xF0
0000782c7ffdd015  vmovaps [rsp], xmm0
0000782c7ffdd01a  vmovaps [rsp+0x10], xmm1
0000782c7ffdd020  vmovaps [rsp+0x20], xmm2
0000782c7ffdd026  vmovaps [rsp+0x30], xmm3
0000782c7ffdd02c  vmovaps [rsp+0x40], xmm4
0000782c7ffdd032  vmovaps [rsp+0x50], xmm5
0000782c7ffdd038  vmovaps [rsp+0x60], xmm6
0000782c7ffdd03e  vmovaps [rsp+0x70], xmm7
0000782c7ffdd044  vmovaps [rsp+0x80], xmm8
0000782c7ffdd04d  vmovaps [rsp+0x90], xmm9
0000782c7ffdd056  vmovaps [rsp+0xA0], xmm10
0000782c7ffdd05f  vmovaps [rsp+0xB0], xmm11
0000782c7ffdd068  vmovaps [rsp+0xC0], xmm12
0000782c7ffdd071  vmovaps [rsp+0xD0], xmm14
0000782c7ffdd07a  vmovaps [rsp+0xE0], xmm15
0000782c7ffdd083  sub rsp, 0x40
0000782c7ffdd087  lea rdi, [rsp]
0000782c7ffdd08b  lea rsi, [rsp+0x10]
0000782c7ffdd090  lea rdx, [rsp+0x20]
0000782c7ffdd095  lea rcx, [rsp+0x30]
0000782c7ffdd09a  mov r8d, 0x00
0000782c7ffdd0a0  lea r9, [r15+0x3A8]
0000782c7ffdd0a7  movaps [rdi], xmm13
0000782c7ffdd0ab  movaps [rsi], xmm12
0000782c7ffdd0af  movaps [rdx], xmm15
0000782c7ffdd0b3  movaps [rcx], xmm14
0000782c7ffdd0b7  mov rax, 0x5AE5BFFB5A50
0000782c7ffdd0c1  call rax
0000782c7ffdd0c3  movaps xmm13, [rsp]
0000782c7ffdd0c8  add rsp, 0x40
0000782c7ffdd0cc  vmovaps xmm0, [rsp]
0000782c7ffdd0d1  vmovaps xmm1, [rsp+0x10]
0000782c7ffdd0d7  vmovaps xmm2, [rsp+0x20]
0000782c7ffdd0dd  vmovaps xmm3, [rsp+0x30]
0000782c7ffdd0e3  vmovaps xmm4, [rsp+0x40]
0000782c7ffdd0e9  vmovaps xmm5, [rsp+0x50]
0000782c7ffdd0ef  vmovaps xmm6, [rsp+0x60]
0000782c7ffdd0f5  vmovaps xmm7, [rsp+0x70]
0000782c7ffdd0fb  vmovaps xmm8, [rsp+0x80]
0000782c7ffdd104  vmovaps xmm9, [rsp+0x90]
0000782c7ffdd10d  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdd116  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdd11f  vmovaps xmm12, [rsp+0xC0]
0000782c7ffdd128  vmovaps xmm14, [rsp+0xD0]
0000782c7ffdd131  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdd13a  add rsp, 0xF0
0000782c7ffdd141  pop r11
0000782c7ffdd143  pop r10
0000782c7ffdd145  pop r9
0000782c7ffdd147  pop r8
0000782c7ffdd149  pop rsi
0000782c7ffdd14a  pop rdi
0000782c7ffdd14b  pop rdx
0000782c7ffdd14c  pop rcx
0000782c7ffdd14d  pop rax
0000782c7ffdd14e  add rsp, 0x08
0000782c7ffdd152  jmp 0x0000782C7FFDA608
0000782c7ffdd157  sub rsp, 0x08
0000782c7ffdd15b  push rax
0000782c7ffdd15c  push rcx
0000782c7ffdd15d  push rdx
0000782c7ffdd15e  push rdi
0000782c7ffdd15f  push rsi
0000782c7ffdd160  push r8
0000782c7ffdd162  push r9
0000782c7ffdd164  push r10
0000782c7ffdd166  push r11
0000782c7ffdd168  sub rsp, 0xF0
0000782c7ffdd16f  vmovaps [rsp], xmm0
0000782c7ffdd174  vmovaps [rsp+0x10], xmm1
0000782c7ffdd17a  vmovaps [rsp+0x20], xmm2
0000782c7ffdd180  vmovaps [rsp+0x30], xmm3
0000782c7ffdd186  vmovaps [rsp+0x40], xmm4
0000782c7ffdd18c  vmovaps [rsp+0x50], xmm5
0000782c7ffdd192  vmovaps [rsp+0x60], xmm6
0000782c7ffdd198  vmovaps [rsp+0x70], xmm7
0000782c7ffdd19e  vmovaps [rsp+0x80], xmm8
0000782c7ffdd1a7  vmovaps [rsp+0x90], xmm9
0000782c7ffdd1b0  vmovaps [rsp+0xA0], xmm10
0000782c7ffdd1b9  vmovaps [rsp+0xB0], xmm11
0000782c7ffdd1c2  vmovaps [rsp+0xC0], xmm12
0000782c7ffdd1cb  vmovaps [rsp+0xD0], xmm13
0000782c7ffdd1d4  vmovaps [rsp+0xE0], xmm15
0000782c7ffdd1dd  sub rsp, 0x40
0000782c7ffdd1e1  lea rdi, [rsp]
0000782c7ffdd1e5  lea rsi, [rsp+0x10]
0000782c7ffdd1ea  lea rdx, [rsp+0x20]
0000782c7ffdd1ef  lea rcx, [rsp+0x30]
0000782c7ffdd1f4  mov r8d, 0x00
0000782c7ffdd1fa  lea r9, [r15+0x3A8]
0000782c7ffdd201  movaps [rdi], xmm14
0000782c7ffdd205  movaps [rsi], xmm11
0000782c7ffdd209  movaps [rdx], xmm1
0000782c7ffdd20c  movaps [rcx], xmm15
0000782c7ffdd210  mov rax, 0x5AE5BFFB5A50
0000782c7ffdd21a  call rax
0000782c7ffdd21c  movaps xmm14, [rsp]
0000782c7ffdd221  add rsp, 0x40
0000782c7ffdd225  vmovaps xmm0, [rsp]
0000782c7ffdd22a  vmovaps xmm1, [rsp+0x10]
0000782c7ffdd230  vmovaps xmm2, [rsp+0x20]
0000782c7ffdd236  vmovaps xmm3, [rsp+0x30]
0000782c7ffdd23c  vmovaps xmm4, [rsp+0x40]
0000782c7ffdd242  vmovaps xmm5, [rsp+0x50]
0000782c7ffdd248  vmovaps xmm6, [rsp+0x60]
0000782c7ffdd24e  vmovaps xmm7, [rsp+0x70]
0000782c7ffdd254  vmovaps xmm8, [rsp+0x80]
0000782c7ffdd25d  vmovaps xmm9, [rsp+0x90]
0000782c7ffdd266  vmovaps xmm10, [rsp+0xA0]
0000782c7ffdd26f  vmovaps xmm11, [rsp+0xB0]
0000782c7ffdd278  vmovaps xmm12, [rsp+0xC0]
0000782c7ffdd281  vmovaps xmm13, [rsp+0xD0]
0000782c7ffdd28a  vmovaps xmm15, [rsp+0xE0]
0000782c7ffdd293  add rsp, 0xF0
0000782c7ffdd29a  pop r11
0000782c7ffdd29c  pop r10
0000782c7ffdd29e  pop r9
0000782c7ffdd2a0  pop r8
0000782c7ffdd2a2  pop rsi
0000782c7ffdd2a3  pop rdi
0000782c7ffdd2a4  pop rdx
0000782c7ffdd2a5  pop rcx
0000782c7ffdd2a6  pop rax
0000782c7ffdd2a7  add rsp, 0x08
0000782c7ffdd2ab  jmp 0x0000782C7FFDA636
0000782c7ffdd2b0  call 0x0000782C7FE079B0
0000782c7ffdd2b5  jmp 0x0000782C7FFDA64C
0000782c7ffdd2ba  call 0x0000782C7FEE3440
0000782c7ffdd2bf  jmp 0x0000782C7FFDA656
0000782c7ffdd2c4  call 0x0000782C7FEDFCE0
0000782c7ffdd2c9  jmp 0x0000782C7FFDA660
0000782c7ffdd2ce  call 0x0000782C7FEE46C0
0000782c7ffdd2d3  jmp 0x0000782C7FFDA66A
0000782c7ffdd2d8  int3
0000782c7ffdd2d9  nop [rax], eax
0000782c7ffdd2e0  mov qword ptr [r15+0x40], 0x430000
0000782c7ffdd2e8  mov eax, 0x430C50
0000782c7ffdd2ed  mov r14, [r13+rax*1]
0000782c7ffdd2f2  movq xmm1, r14
0000782c7ffdd2f7  mov rax, [r15+0x50]
0000782c7ffdd2fb  movups xmm15, [r13+rax*1]
0000782c7ffdd301  movaps [r15+0x120], xmm15
0000782c7ffdd309  mov qword ptr [r15+0x48], 0x10
0000782c7ffdd311  xor eax, eax
0000782c7ffdd313  mov r14d, 0x10
0000782c7ffdd319  mov r12d, 0x200
0000782c7ffdd31f  cmp r14, r12
0000782c7ffdd322  cmc
0000782c7ffdd323  lahf
0000782c7ffdd324  seto al
0000782c7ffdd327  mov [r15+0x108], eax
0000782c7ffdd32e  pextrq rax, xmm15, 0x01
0000782c7ffdd335  movq xmm14, rax
0000782c7ffdd33a  movaps [r15+0x130], xmm14
0000782c7ffdd342  movq rax, xmm1
0000782c7ffdd347  movq r14, xmm15
0000782c7ffdd34c  vmovq xmm1, rax
0000782c7ffdd351  vmovq xmm15, r14
0000782c7ffdd356  movaps xmm13, xmm1
0000782c7ffdd35a  addsd xmm13, xmm15
0000782c7ffdd35f  ucomisd xmm13, xmm13
0000782c7ffdd364  jp 0x0000782C7FFDD423
0000782c7ffdd36a  movq xmm13, xmm13
0000782c7ffdd36f  movq rax, xmm13
0000782c7ffdd374  movq r14, xmm14
0000782c7ffdd379  vmovq xmm1, rax
0000782c7ffdd37e  vmovq xmm15, r14
0000782c7ffdd383  movaps xmm14, xmm1
0000782c7ffdd387  addsd xmm14, xmm15
0000782c7ffdd38c  ucomisd xmm14, xmm14
0000782c7ffdd391  jp 0x0000782C7FFDD46B
0000782c7ffdd397  movq xmm14, xmm14
0000782c7ffdd39c  movaps [r15+0x110], xmm14
0000782c7ffdd3a4  mov eax, [r15+0x108]
0000782c7ffdd3ab  sahf
0000782c7ffdd3ac  jnz 0x0000782C7FFDD3DE
0000782c7ffdd3ae  cmp dword ptr [r15+0x318], 0x00
0000782c7ffdd3b6  jz 0x0000782C7FFDD680
0000782c7ffdd3bc  nop [rax+rax*1], ax
0000782c7ffdd3c5  nop [rax+rax*1], eax
0000782c7ffdd3cd  mov eax, 0x410698
0000782c7ffdd3d2  mov [r15+0x100], rax
0000782c7ffdd3d9  jmp 0x0000782C7FDFE110
0000782c7ffdd3de  cmp dword ptr [r15+0x318], 0x00
0000782c7ffdd3e6  jz 0x0000782C7FFDD4C0
0000782c7ffdd3ec  nop [rax+rax*1], ax
0000782c7ffdd3f5  nop [rax+rax*1], eax
0000782c7ffdd3fd  mov eax, 0x41067C
0000782c7ffdd402  mov [r15+0x100], rax
0000782c7ffdd409  jmp 0x0000782C7FDFE110
0000782c7ffdd40e  int3
0000782c7ffdd40f  call 0x0000782C7FE0DC20
0000782c7ffdd414  jmp 0x0000782C7FFDD2F2
0000782c7ffdd419  call 0x0000782C7FE0E760
0000782c7ffdd41e  jmp 0x0000782C7FFDD301
0000782c7ffdd423  ucomisd xmm1, xmm15
0000782c7ffdd428  jp 0x0000782C7FFDD437
0000782c7ffdd42a  movaps xmm13, [0x0000782C7FBFE060]
0000782c7ffdd432  jmp 0x0000782C7FFDD36A
0000782c7ffdd437  vxorps xmm0, xmm1, xmm15
0000782c7ffdd43c  pextrw eax, xmm0, 0x03
0000782c7ffdd441  and eax, 0x7FF8
0000782c7ffdd446  cmp eax, 0x08
0000782c7ffdd449  jnz 0x0000782C7FFDD36A
0000782c7ffdd44f  movq rax, xmm15
0000782c7ffdd454  shl rax, 0x0D
0000782c7ffdd458  jbe 0x0000782C7FFDD36A
0000782c7ffdd45e  vorps xmm13, xmm15, [0x0000782C7FBFE070]
0000782c7ffdd466  jmp 0x0000782C7FFDD36A
0000782c7ffdd46b  ucomisd xmm1, xmm15
0000782c7ffdd470  jp 0x0000782C7FFDD47F
0000782c7ffdd472  movaps xmm14, [0x0000782C7FBFE060]
0000782c7ffdd47a  jmp 0x0000782C7FFDD397
0000782c7ffdd47f  vxorps xmm0, xmm1, xmm15
0000782c7ffdd484  pextrw eax, xmm0, 0x03
0000782c7ffdd489  and eax, 0x7FF8
0000782c7ffdd48e  cmp eax, 0x08
0000782c7ffdd491  jnz 0x0000782C7FFDD397
0000782c7ffdd497  movq rax, xmm15
0000782c7ffdd49c  shl rax, 0x0D
0000782c7ffdd4a0  jbe 0x0000782C7FFDD397
0000782c7ffdd4a6  vorps xmm14, xmm15, [0x0000782C7FBFE070]
0000782c7ffdd4ae  jmp 0x0000782C7FFDD397
0000782c7ffdd4b3  int3
0000782c7ffdd4b4  nop [rax+rax*1], ax
0000782c7ffdd4bd  nop [rax], eax
0000782c7ffdd4c0  mov rax, [r15+0x48]
0000782c7ffdd4c4  mov r14, [r15+0x50]
0000782c7ffdd4c8  lea r12, [r14+rax*1]
0000782c7ffdd4cc  movups xmm1, [r13+r12*1]
0000782c7ffdd4d2  movaps [r15+0x120], xmm1
0000782c7ffdd4da  lea r14, [rax+0x10]
0000782c7ffdd4de  mov [r15+0x48], r14
0000782c7ffdd4e2  xor eax, eax
0000782c7ffdd4e4  mov r12d, 0x200
0000782c7ffdd4ea  cmp r14, r12
0000782c7ffdd4ed  cmc
0000782c7ffdd4ee  lahf
0000782c7ffdd4ef  seto al
0000782c7ffdd4f2  mov [r15+0x108], eax
0000782c7ffdd4f9  pextrq rax, xmm1, 0x01
0000782c7ffdd500  movq xmm15, rax
0000782c7ffdd505  movaps [r15+0x130], xmm15
0000782c7ffdd50d  movaps xmm14, [r15+0x110]
0000782c7ffdd515  movq rax, xmm14
0000782c7ffdd51a  movq r14, xmm1
0000782c7ffdd51f  vmovq xmm1, rax
0000782c7ffdd524  vmovq xmm14, r14
0000782c7ffdd529  movaps xmm13, xmm1
0000782c7ffdd52d  addsd xmm13, xmm14
0000782c7ffdd532  ucomisd xmm13, xmm13
0000782c7ffdd537  jp 0x0000782C7FFDD5EC
0000782c7ffdd53d  movq xmm13, xmm13
0000782c7ffdd542  movq rax, xmm13
0000782c7ffdd547  movq r14, xmm15
0000782c7ffdd54c  vmovq xmm1, rax
0000782c7ffdd551  vmovq xmm15, r14
0000782c7ffdd556  movaps xmm14, xmm1
0000782c7ffdd55a  addsd xmm14, xmm15
0000782c7ffdd55f  ucomisd xmm14, xmm14
0000782c7ffdd564  jp 0x0000782C7FFDD634
0000782c7ffdd56a  movq xmm14, xmm14
0000782c7ffdd56f  movaps [r15+0x110], xmm14
0000782c7ffdd577  mov eax, [r15+0x108]
0000782c7ffdd57e  sahf
0000782c7ffdd57f  jnz 0x0000782C7FFDD5B1
0000782c7ffdd581  cmp dword ptr [r15+0x318], 0x00
0000782c7ffdd589  jz 0x0000782C7FFDD680
0000782c7ffdd58f  nop [rax+rax*1], ax
0000782c7ffdd598  nop [rax+rax*1], eax
0000782c7ffdd5a0  mov eax, 0x410698
0000782c7ffdd5a5  mov [r15+0x100], rax
0000782c7ffdd5ac  jmp 0x0000782C7FDFE110
0000782c7ffdd5b1  cmp dword ptr [r15+0x318], 0x00
0000782c7ffdd5b9  jz 0x0000782C7FFDD4C0
0000782c7ffdd5bf  nop [rax+rax*1], ax
0000782c7ffdd5c8  nop [rax+rax*1], eax
0000782c7ffdd5d0  mov eax, 0x41067C
0000782c7ffdd5d5  mov [r15+0x100], rax
0000782c7ffdd5dc  jmp 0x0000782C7FDFE110
0000782c7ffdd5e1  int3
0000782c7ffdd5e2  call 0x0000782C7FEB52F0
0000782c7ffdd5e7  jmp 0x0000782C7FFDD4D2
0000782c7ffdd5ec  ucomisd xmm1, xmm14
0000782c7ffdd5f1  jp 0x0000782C7FFDD600
0000782c7ffdd5f3  movaps xmm13, [0x0000782C7FBFE060]
0000782c7ffdd5fb  jmp 0x0000782C7FFDD53D
0000782c7ffdd600  vxorps xmm0, xmm1, xmm14
0000782c7ffdd605  pextrw eax, xmm0, 0x03
0000782c7ffdd60a  and eax, 0x7FF8
0000782c7ffdd60f  cmp eax, 0x08
0000782c7ffdd612  jnz 0x0000782C7FFDD53D
0000782c7ffdd618  movq rax, xmm14
0000782c7ffdd61d  shl rax, 0x0D
0000782c7ffdd621  jbe 0x0000782C7FFDD53D
0000782c7ffdd627  vorps xmm13, xmm14, [0x0000782C7FBFE070]
0000782c7ffdd62f  jmp 0x0000782C7FFDD53D
0000782c7ffdd634  ucomisd xmm1, xmm15
0000782c7ffdd639  jp 0x0000782C7FFDD648
0000782c7ffdd63b  movaps xmm14, [0x0000782C7FBFE060]
0000782c7ffdd643  jmp 0x0000782C7FFDD56A
0000782c7ffdd648  vxorps xmm0, xmm1, xmm15
0000782c7ffdd64d  pextrw eax, xmm0, 0x03
0000782c7ffdd652  and eax, 0x7FF8
0000782c7ffdd657  cmp eax, 0x08
0000782c7ffdd65a  jnz 0x0000782C7FFDD56A
0000782c7ffdd660  movq rax, xmm15
0000782c7ffdd665  shl rax, 0x0D
0000782c7ffdd669  jbe 0x0000782C7FFDD56A
0000782c7ffdd66f  vorps xmm14, xmm15, [0x0000782C7FBFE070]
0000782c7ffdd677  jmp 0x0000782C7FFDD56A
0000782c7ffdd67c  int3
0000782c7ffdd67d  nop [rax], eax
0000782c7ffdd680  mov rax, [r15+0xF8]
0000782c7ffdd687  lea r14, [rax+0x1A0]
0000782c7ffdd68e  mov r12, [r13+r14*1]
0000782c7ffdd693  lea r14, [rax+0x1A8]
0000782c7ffdd69a  mov r11, [r13+r14*1]
0000782c7ffdd69f  mov [r15+0xA0], r12
0000782c7ffdd6a6  mov [r15+0x98], r11
0000782c7ffdd6ad  mov r14, [r15+0x40]
0000782c7ffdd6b1  lea r12, [r14+0xC50]
0000782c7ffdd6b8  movaps xmm1, [r15+0x110]
0000782c7ffdd6c0  movq r14, xmm1
0000782c7ffdd6c5  mov [r13+r12*1], r14
0000782c7ffdd6ca  lea r14, [rax+0x190]
0000782c7ffdd6d1  mov r12, [r13+r14*1]
0000782c7ffdd6d6  lea r14, [rax+0x198]
0000782c7ffdd6dd  mov r11, [r13+r14*1]
0000782c7ffdd6e2  mov [r15+0xE8], r12
0000782c7ffdd6e9  mov [r15+0xF0], r11
0000782c7ffdd6f0  lea r14, [rax+0x180]
0000782c7ffdd6f7  mov r12, [r13+r14*1]
0000782c7ffdd6fc  lea r14, [rax+0x188]
0000782c7ffdd703  mov r10, [r13+r14*1]
0000782c7ffdd708  movq xmm1, r12
0000782c7ffdd70d  movq xmm15, r10
0000782c7ffdd712  movq xmm1, xmm1
0000782c7ffdd716  movq xmm1, xmm1
0000782c7ffdd71a  movaps [r15+0x1A0], xmm1
0000782c7ffdd722  movq xmm15, xmm15
0000782c7ffdd727  movq xmm15, xmm15
0000782c7ffdd72c  movaps [r15+0x190], xmm15
0000782c7ffdd734  lea r14, [rax+0x170]
0000782c7ffdd73b  mov r12, [r13+r14*1]
0000782c7ffdd740  lea r14, [rax+0x178]
0000782c7ffdd747  mov r10, [r13+r14*1]
0000782c7ffdd74c  movq xmm1, r12
0000782c7ffdd751  movq xmm15, r10
0000782c7ffdd756  movq xmm1, xmm1
0000782c7ffdd75a  movq xmm1, xmm1
0000782c7ffdd75e  movaps [r15+0x1C0], xmm1
0000782c7ffdd766  movq xmm15, xmm15
0000782c7ffdd76b  movq xmm15, xmm15
0000782c7ffdd770  movaps [r15+0x1B0], xmm15
0000782c7ffdd778  lea r14, [rax+0x160]
0000782c7ffdd77f  mov r12, [r13+r14*1]
0000782c7ffdd784  lea r14, [rax+0x168]
0000782c7ffdd78b  mov r10, [r13+r14*1]
0000782c7ffdd790  movq xmm1, r12
0000782c7ffdd795  movq xmm15, r10
0000782c7ffdd79a  movq xmm1, xmm1
0000782c7ffdd79e  movq xmm1, xmm1
0000782c7ffdd7a2  movaps [r15+0x1E0], xmm1
0000782c7ffdd7aa  movq xmm15, xmm15
0000782c7ffdd7af  movq xmm15, xmm15
0000782c7ffdd7b4  movaps [r15+0x1D0], xmm15
0000782c7ffdd7bc  lea r14, [rax+0x150]
0000782c7ffdd7c3  mov r12, [r13+r14*1]
0000782c7ffdd7c8  lea r14, [rax+0x158]
0000782c7ffdd7cf  mov r10, [r13+r14*1]
0000782c7ffdd7d4  movq xmm1, r12
0000782c7ffdd7d9  movq xmm15, r10
0000782c7ffdd7de  movq xmm1, xmm1
0000782c7ffdd7e2  movq xmm1, xmm1
0000782c7ffdd7e6  movaps [r15+0x200], xmm1
0000782c7ffdd7ee  movq xmm15, xmm15
0000782c7ffdd7f3  movq xmm15, xmm15
0000782c7ffdd7f8  movaps [r15+0x1F0], xmm15
0000782c7ffdd800  lea r14, [rax+0x1B0]
0000782c7ffdd807  mov [r15+0xF8], r14
0000782c7ffdd80e  mov [r15+0x100], r11
0000782c7ffdd815  jmp 0x0000782C7FFCE5C0
0000782c7ffdd81a  int3
0000782c7ffdd81b  call 0x0000782C7FEE27E0
0000782c7ffdd820  jmp 0x0000782C7FFDD693
0000782c7ffdd825  call 0x0000782C7FEE1570
0000782c7ffdd82a  jmp 0x0000782C7FFDD69F
0000782c7ffdd82f  call 0x0000782C7FEC3FE0
0000782c7ffdd834  jmp 0x0000782C7FFDD6CA
0000782c7ffdd839  call 0x0000782C7FEE27E0
0000782c7ffdd83e  jmp 0x0000782C7FFDD6D6
0000782c7ffdd843  call 0x0000782C7FEE1570
0000782c7ffdd848  jmp 0x0000782C7FFDD6E2
0000782c7ffdd84d  call 0x0000782C7FEE27E0
0000782c7ffdd852  jmp 0x0000782C7FFDD6FC
0000782c7ffdd857  call 0x0000782C7FEE0300
0000782c7ffdd85c  jmp 0x0000782C7FFDD708
0000782c7ffdd861  call 0x0000782C7FEE27E0
0000782c7ffdd866  jmp 0x0000782C7FFDD740
0000782c7ffdd86b  call 0x0000782C7FEE0300
0000782c7ffdd870  jmp 0x0000782C7FFDD74C
0000782c7ffdd875  call 0x0000782C7FEE27E0
0000782c7ffdd87a  jmp 0x0000782C7FFDD784
0000782c7ffdd87f  call 0x0000782C7FEE0300
0000782c7ffdd884  jmp 0x0000782C7FFDD790
0000782c7ffdd889  call 0x0000782C7FEE27E0
0000782c7ffdd88e  jmp 0x0000782C7FFDD7C8
0000782c7ffdd893  call 0x0000782C7FEE0300
0000782c7ffdd898  jmp 0x0000782C7FFDD7D4
0000782c7ffdd89d  int3
0000782c7ffdd89e  nop
0000782c7ffdd8a0  mov qword ptr [r15+0x100], 0x04
0000782c7ffdd8ab  mov esi, 0x00
0000782c7ffdd8b0  mov edx, 0x09
0000782c7ffdd8b5  mov rdi, 0x7FFD4EEC99F0
0000782c7ffdd8bf  mov rax, 0x5AE5BFE48970
0000782c7ffdd8c9  call rax
0000782c7ffdd8cb  cmp dword ptr [r15+0x318], 0x00
0000782c7ffdd8d3  jnz 0x0000782C7FDFE110
0000782c7ffdd8d9  jmp 0x0000782C7FDFE0A0
0000782c7ffdd8de  int3
0000782c7ffdd8df  int3
