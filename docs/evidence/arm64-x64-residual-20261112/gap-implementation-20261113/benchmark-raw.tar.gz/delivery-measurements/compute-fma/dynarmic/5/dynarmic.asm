000074267fbce69b  nop [rax+rax*1], eax
000074267fbce6a0  mov rax, [r15+0xF8]
000074267fbce6a7  lea r14, [rax-0x1B0]
000074267fbce6ae  mov [r15+0xF8], r14
000074267fbce6b5  lea rax, [r14+0x1A0]
000074267fbce6bc  mov r12, [r15+0xA0]
000074267fbce6c3  mov r11, [r15+0x98]
000074267fbce6ca  mov [r13+rax*1], r12
000074267fbce6cf  lea rax, [r14+0x1A8]
000074267fbce6d6  mov [r13+rax*1], r11
000074267fbce6db  mov eax, 0x420A30
000074267fbce6e0  movups xmm1, [r13+rax*1]
000074267fbce6e6  mov eax, 0x4209C0
000074267fbce6eb  movups xmm15, [r13+rax*1]
000074267fbce6f1  mov eax, 0x420A50
000074267fbce6f6  movups xmm14, [r13+rax*1]
000074267fbce6fc  mov eax, 0x4209F0
000074267fbce701  movups xmm13, [r13+rax*1]
000074267fbce707  mov qword ptr [r15+0x98], 0x430C60
000074267fbce712  mov eax, 0x420A60
000074267fbce717  movups xmm12, [r13+rax*1]
000074267fbce71d  mov eax, 0x430C60
000074267fbce722  movups [r13+rax*1], xmm1
000074267fbce728  mov eax, 0x430C70
000074267fbce72d  movups [r13+rax*1], xmm15
000074267fbce733  mov eax, 0x430C80
000074267fbce738  movups [r13+rax*1], xmm14
000074267fbce73e  mov eax, 0x430C90
000074267fbce743  movups [r13+rax*1], xmm13
000074267fbce749  mov eax, 0x4209B0
000074267fbce74e  movups xmm14, [r13+rax*1]
000074267fbce754  mov eax, 0x4209A0
000074267fbce759  movups xmm13, [r13+rax*1]
000074267fbce75f  mov eax, 0x430D60
000074267fbce764  movups [r13+rax*1], xmm1
000074267fbce76a  mov eax, 0x430D70
000074267fbce76f  movups [r13+rax*1], xmm15
000074267fbce775  mov eax, 0x430CA0
000074267fbce77a  movups [r13+rax*1], xmm12
000074267fbce780  mov eax, 0x430CB0
000074267fbce785  movups [r13+rax*1], xmm14
000074267fbce78b  mov eax, 0x420990
000074267fbce790  movups xmm1, [r13+rax*1]
000074267fbce796  mov eax, 0x420A00
000074267fbce79b  movups xmm15, [r13+rax*1]
000074267fbce7a1  mov eax, 0x430CC0
000074267fbce7a6  movups [r13+rax*1], xmm13
000074267fbce7ac  mov eax, 0x430CD0
000074267fbce7b1  movups [r13+rax*1], xmm1
000074267fbce7b7  mov eax, 0x420A10
000074267fbce7bc  movups xmm1, [r13+rax*1]
000074267fbce7c2  mov eax, 0x4209E0
000074267fbce7c7  movups xmm14, [r13+rax*1]
000074267fbce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000074267fbce7d5  mov eax, 0x430CE0
000074267fbce7da  movups [r13+rax*1], xmm15
000074267fbce7e0  mov eax, 0x430CF0
000074267fbce7e5  movups [r13+rax*1], xmm1
000074267fbce7eb  mov eax, 0x420A80
000074267fbce7f0  movups xmm1, [r13+rax*1]
000074267fbce7f6  mov eax, 0x420A90
000074267fbce7fb  movups xmm15, [r13+rax*1]
000074267fbce801  movaps [r15+0x150], xmm15
000074267fbce809  mov qword ptr [r15+0xA0], 0x3E8
000074267fbce814  mov eax, 0x430D00
000074267fbce819  movups [r13+rax*1], xmm14
000074267fbce81f  mov eax, 0x430D10
000074267fbce824  movups [r13+rax*1], xmm1
000074267fbce82a  mov eax, 0x420A70
000074267fbce82f  movups xmm1, [r13+rax*1]
000074267fbce835  mov eax, 0x420A20
000074267fbce83a  movups xmm14, [r13+rax*1]
000074267fbce840  movaps [r15+0x140], xmm14
000074267fbce848  lea rax, [r14+0x150]
000074267fbce84f  movq xmm13, qword ptr [r15+0x200]
000074267fbce858  movq xmm12, qword ptr [r15+0x1F0]
000074267fbce861  movq r12, xmm13
000074267fbce866  movq r11, xmm12
000074267fbce86b  mov [r13+rax*1], r12
000074267fbce870  lea rax, [r14+0x158]
000074267fbce877  mov [r13+rax*1], r11
000074267fbce87c  mov eax, 0x430D20
000074267fbce881  movups [r13+rax*1], xmm15
000074267fbce887  mov eax, 0x430D30
000074267fbce88c  movups [r13+rax*1], xmm1
000074267fbce892  mov eax, 0x420A40
000074267fbce897  movups xmm1, [r13+rax*1]
000074267fbce89d  mov eax, 0x420AA8
000074267fbce8a2  mov r12, [r13+rax*1]
000074267fbce8a7  movq xmm15, r12
000074267fbce8ac  mov qword ptr [r15+0x40], 0x420AB0
000074267fbce8b4  mov eax, 0x430D40
000074267fbce8b9  movups [r13+rax*1], xmm14
000074267fbce8bf  mov eax, 0x430D50
000074267fbce8c4  movups [r13+rax*1], xmm1
000074267fbce8ca  mov eax, 0x420B10
000074267fbce8cf  movups xmm1, [r13+rax*1]
000074267fbce8d5  movq rax, xmm15
000074267fbce8da  mov r12d, 0x430D80
000074267fbce8e0  mov [r13+r12*1], rax
000074267fbce8e5  mov eax, 0x420AF0
000074267fbce8ea  movups xmm15, [r13+rax*1]
000074267fbce8f0  mov eax, 0x420B00
000074267fbce8f5  movups xmm14, [r13+rax*1]
000074267fbce8fb  lea rax, [r14+0x130]
000074267fbce902  movups [r13+rax*1], xmm1
000074267fbce908  lea rax, [r14+0x160]
000074267fbce90f  movq xmm1, qword ptr [r15+0x1E0]
000074267fbce918  movq xmm13, qword ptr [r15+0x1D0]
000074267fbce921  movq r12, xmm1
000074267fbce926  movq r11, xmm13
000074267fbce92b  mov [r13+rax*1], r12
000074267fbce930  lea rax, [r14+0x168]
000074267fbce937  mov [r13+rax*1], r11
000074267fbce93c  lea rax, [r14+0x110]
000074267fbce943  movups [r13+rax*1], xmm15
000074267fbce949  lea rax, [r14+0x120]
000074267fbce950  movups [r13+rax*1], xmm14
000074267fbce956  mov eax, 0x420AB0
000074267fbce95b  movups xmm1, [r13+rax*1]
000074267fbce961  mov eax, 0x420AC0
000074267fbce966  movups xmm15, [r13+rax*1]
000074267fbce96c  movaps [r15+0x120], xmm15
000074267fbce974  lea rax, [r14+0x170]
000074267fbce97b  movq xmm14, qword ptr [r15+0x1C0]
000074267fbce984  movq xmm13, qword ptr [r15+0x1B0]
000074267fbce98d  movq r12, xmm14
000074267fbce992  movq r11, xmm13
000074267fbce997  mov [r13+rax*1], r12
000074267fbce99c  lea rax, [r14+0x178]
000074267fbce9a3  mov [r13+rax*1], r11
000074267fbce9a8  lea rax, [r14+0x180]
000074267fbce9af  movq xmm14, qword ptr [r15+0x1A0]
000074267fbce9b8  movq xmm13, qword ptr [r15+0x190]
000074267fbce9c1  movq r12, xmm14
000074267fbce9c6  movq r11, xmm13
000074267fbce9cb  mov [r13+rax*1], r12
000074267fbce9d0  lea rax, [r14+0x188]
000074267fbce9d7  mov [r13+rax*1], r11
000074267fbce9dc  lea rax, [r14+0xD0]
000074267fbce9e3  movups [r13+rax*1], xmm1
000074267fbce9e9  lea rax, [r14+0xE0]
000074267fbce9f0  movups [r13+rax*1], xmm15
000074267fbce9f6  mov eax, 0x420AD0
000074267fbce9fb  movups xmm1, [r13+rax*1]
000074267fbcea01  mov eax, 0x420AE0
000074267fbcea06  movups xmm15, [r13+rax*1]
000074267fbcea0c  movaps [r15+0x110], xmm1
000074267fbcea14  movaps [r15+0x130], xmm15
000074267fbcea1c  lea rax, [r14+0x190]
000074267fbcea23  mov r12, [r15+0xE8]
000074267fbcea2a  mov r11, [r15+0xF0]
000074267fbcea31  mov [r13+rax*1], r12
000074267fbcea36  lea rax, [r14+0x198]
000074267fbcea3d  mov [r13+rax*1], r11
000074267fbcea42  mov eax, 0x430D88
000074267fbcea47  mov r12d, 0x421DF8D3
000074267fbcea4d  mov [r13+rax*1], r12d
000074267fbcea52  lea rax, [r14+0xF0]
000074267fbcea59  movups [r13+rax*1], xmm1
000074267fbcea5f  lea rax, [r14+0x100]
000074267fbcea66  movups [r13+rax*1], xmm15
000074267fbcea6c  lea rax, [r14+0xD0]
000074267fbcea73  mov [r15], rax
000074267fbcea76  mov qword ptr [r15+0x08], 0x430C60
000074267fbcea7e  mov qword ptr [r15+0x10], 0x12C
000074267fbcea86  mov qword ptr [r15+0xF0], 0x410284
000074267fbcea91  mov r14d, [r15+0x320]
000074267fbcea98  mov eax, 0x410284
000074267fbcea9d  mov rcx, 0x74267FBD07C0
000074267fbceaa7  mov [r15+r14*8+0x328], rax
000074267fbceaaf  mov [r15+r14*8+0x368], rcx
000074267fbceab7  add r14d, 0x01
000074267fbceabb  and r14d, 0x07
000074267fbceabf  mov [r15+0x320], r14d
000074267fbceac6  cmp dword ptr [r15+0x318], 0x00
000074267fbceace  jz 0x000074267FBCED70
000074267fbcead4  nop [rax+rax*1], ax
000074267fbceadd  nop [rax+rax*1], eax
000074267fbceae5  mov eax, 0x4106BC
000074267fbceaea  mov [r15+0x100], rax
000074267fbceaf1  jmp 0x000074267F9FE110
000074267fbceaf6  int3
000074267fbceaf7  call 0x000074267FA0BC20
000074267fbceafc  jmp 0x000074267FBCE6CF
000074267fbceb01  call 0x000074267FA0A9A0
000074267fbceb06  jmp 0x000074267FBCE6DB
000074267fbceb0b  call 0x000074267F9FF430
000074267fbceb10  jmp 0x000074267FBCE6E6
000074267fbceb15  call 0x000074267FA0E760
000074267fbceb1a  jmp 0x000074267FBCE6F1
000074267fbceb1f  call 0x000074267FA0D4E0
000074267fbceb24  jmp 0x000074267FBCE6FC
000074267fbceb29  call 0x000074267FA0C260
000074267fbceb2e  jmp 0x000074267FBCE707
000074267fbceb33  call 0x000074267FA0AFE0
000074267fbceb38  jmp 0x000074267FBCE71D
000074267fbceb3d  call 0x000074267F9FF540
000074267fbceb42  jmp 0x000074267FBCE728
000074267fbceb47  call 0x000074267FA0E880
000074267fbceb4c  jmp 0x000074267FBCE733
000074267fbceb51  call 0x000074267FA0D600
000074267fbceb56  jmp 0x000074267FBCE73E
000074267fbceb5b  call 0x000074267FA0C380
000074267fbceb60  jmp 0x000074267FBCE749
000074267fbceb65  call 0x000074267FA0D4E0
000074267fbceb6a  jmp 0x000074267FBCE754
000074267fbceb6f  call 0x000074267FA0C260
000074267fbceb74  jmp 0x000074267FBCE75F
000074267fbceb79  call 0x000074267F9FF540
000074267fbceb7e  jmp 0x000074267FBCE76A
000074267fbceb83  call 0x000074267FA0E880
000074267fbceb88  jmp 0x000074267FBCE775
000074267fbceb8d  call 0x000074267FA0B100
000074267fbceb92  jmp 0x000074267FBCE780
000074267fbceb97  call 0x000074267FA0D600
000074267fbceb9c  jmp 0x000074267FBCE78B
000074267fbceba1  call 0x000074267F9FF430
000074267fbceba6  jmp 0x000074267FBCE796
000074267fbcebab  call 0x000074267FA0E760
000074267fbcebb0  jmp 0x000074267FBCE7A1
000074267fbcebb5  call 0x000074267FA0C380
000074267fbcebba  jmp 0x000074267FBCE7AC
000074267fbcebbf  call 0x000074267F9FF540
000074267fbcebc4  jmp 0x000074267FBCE7B7
000074267fbcebc9  call 0x000074267F9FF430
000074267fbcebce  jmp 0x000074267FBCE7C2
000074267fbcebd3  call 0x000074267FA0D4E0
000074267fbcebd8  jmp 0x000074267FBCE7CD
000074267fbcebdd  call 0x000074267FA0E880
000074267fbcebe2  jmp 0x000074267FBCE7E0
000074267fbcebe7  call 0x000074267F9FF540
000074267fbcebec  jmp 0x000074267FBCE7EB
000074267fbcebf1  call 0x000074267F9FF430
000074267fbcebf6  jmp 0x000074267FBCE7F6
000074267fbcebfb  call 0x000074267FA0E760
000074267fbcec00  jmp 0x000074267FBCE801
000074267fbcec05  call 0x000074267FA0D600
000074267fbcec0a  jmp 0x000074267FBCE81F
000074267fbcec0f  call 0x000074267F9FF540
000074267fbcec14  jmp 0x000074267FBCE82A
000074267fbcec19  call 0x000074267F9FF430
000074267fbcec1e  jmp 0x000074267FBCE835
000074267fbcec23  call 0x000074267FA0D4E0
000074267fbcec28  jmp 0x000074267FBCE840
000074267fbcec2d  call 0x000074267FA0BC20
000074267fbcec32  jmp 0x000074267FBCE870
000074267fbcec37  call 0x000074267FA0A9A0
000074267fbcec3c  jmp 0x000074267FBCE87C
000074267fbcec41  call 0x000074267FA0E880
000074267fbcec46  jmp 0x000074267FBCE887
000074267fbcec4b  call 0x000074267F9FF540
000074267fbcec50  jmp 0x000074267FBCE892
000074267fbcec55  call 0x000074267F9FF430
000074267fbcec5a  jmp 0x000074267FBCE89D
000074267fbcec5f  call 0x000074267FA0B720
000074267fbcec64  jmp 0x000074267FBCE8A7
000074267fbcec69  call 0x000074267FA0D600
000074267fbcec6e  jmp 0x000074267FBCE8BF
000074267fbcec73  call 0x000074267F9FF540
000074267fbcec78  jmp 0x000074267FBCE8CA
000074267fbcec7d  call 0x000074267F9FF430
000074267fbcec82  jmp 0x000074267FBCE8D5
000074267fbcec87  call 0x000074267FAB4CB0
000074267fbcec8c  jmp 0x000074267FBCE8E5
000074267fbcec91  call 0x000074267FA0E760
000074267fbcec96  jmp 0x000074267FBCE8F0
000074267fbcec9b  call 0x000074267FA0D4E0
000074267fbceca0  jmp 0x000074267FBCE8FB
000074267fbceca5  call 0x000074267F9FF540
000074267fbcecaa  jmp 0x000074267FBCE908
000074267fbcecaf  call 0x000074267FA0BC20
000074267fbcecb4  jmp 0x000074267FBCE930
000074267fbcecb9  call 0x000074267FA0A9A0
000074267fbcecbe  jmp 0x000074267FBCE93C
000074267fbcecc3  call 0x000074267FA0E880
000074267fbcecc8  jmp 0x000074267FBCE949
000074267fbceccd  call 0x000074267FA0D600
000074267fbcecd2  jmp 0x000074267FBCE956
000074267fbcecd7  call 0x000074267F9FF430
000074267fbcecdc  jmp 0x000074267FBCE961
000074267fbcece1  call 0x000074267FA0E760
000074267fbcece6  jmp 0x000074267FBCE96C
000074267fbceceb  call 0x000074267FA0BC20
000074267fbcecf0  jmp 0x000074267FBCE99C
000074267fbcecf5  call 0x000074267FA0A9A0
000074267fbcecfa  jmp 0x000074267FBCE9A8
000074267fbcecff  call 0x000074267FA0BC20
000074267fbced04  jmp 0x000074267FBCE9D0
000074267fbced09  call 0x000074267FA0A9A0
000074267fbced0e  jmp 0x000074267FBCE9DC
000074267fbced13  call 0x000074267F9FF540
000074267fbced18  jmp 0x000074267FBCE9E9
000074267fbced1d  call 0x000074267FA0E880
000074267fbced22  jmp 0x000074267FBCE9F6
000074267fbced27  call 0x000074267F9FF430
000074267fbced2c  jmp 0x000074267FBCEA01
000074267fbced31  call 0x000074267FA0E760
000074267fbced36  jmp 0x000074267FBCEA0C
000074267fbced3b  call 0x000074267FA0BC20
000074267fbced40  jmp 0x000074267FBCEA36
000074267fbced45  call 0x000074267FA0A9A0
000074267fbced4a  jmp 0x000074267FBCEA42
000074267fbced4f  call 0x000074267FA0BAE0
000074267fbced54  jmp 0x000074267FBCEA52
000074267fbced59  call 0x000074267F9FF540
000074267fbced5e  jmp 0x000074267FBCEA5F
000074267fbced63  call 0x000074267FA0E880
000074267fbced68  jmp 0x000074267FBCEA6C
000074267fbced6d  int3
000074267fbced6e  nop
000074267fbced70  mov rax, [r15]
000074267fbced73  lea r14, [rax+0x20]
000074267fbced77  mov r12, [r13+r14*1]
000074267fbced7c  mov r14, [r15+0x10]
000074267fbced80  lea r11, [r12+r14*1]
000074267fbced84  mov [r15+0x40], r11
000074267fbced88  lea r12, [rax+0x20]
000074267fbced8c  mov [r13+r12*1], r11
000074267fbced91  test r14, r14
000074267fbced94  setz r14b
000074267fbced98  movzx r14, r14b
000074267fbced9c  mov [rsp+0x414], r14b
000074267fbceda4  cmp byte ptr [rsp+0x414], 0x00
000074267fbcedac  jz 0x000074267FBCEDDE
000074267fbcedae  cmp dword ptr [r15+0x318], 0x00
000074267fbcedb6  mov eax, 0x410934
000074267fbcedbb  mov [r15+0x100], rax
000074267fbcedc2  jz 0x000074267F9FE0A0
000074267fbcedc8  nop [rax+rax*1], eax
000074267fbcedcd  mov eax, 0x410934
000074267fbcedd2  mov [r15+0x100], rax
000074267fbcedd9  jmp 0x000074267F9FE110
000074267fbcedde  cmp dword ptr [r15+0x318], 0x00
000074267fbcede6  jz 0x000074267FBCEE30
000074267fbcedec  nop [rax+rax*1], ax
000074267fbcedf5  nop [rax+rax*1], eax
000074267fbcedfd  mov eax, 0x4106CC
000074267fbcee02  mov [r15+0x100], rax
000074267fbcee09  jmp 0x000074267F9FE110
000074267fbcee0e  int3
000074267fbcee0f  call 0x000074267FAE27E0
000074267fbcee14  jmp 0x000074267FBCED7C
000074267fbcee19  call 0x000074267FAC0860
000074267fbcee1e  jmp 0x000074267FBCED91
000074267fbcee23  int3
000074267fbcee24  nop [rax+rax*1], ax
000074267fbcee2d  nop [rax], eax
000074267fbcee30  mov rax, [r15+0xF8]
000074267fbcee37  lea r14, [rax-0x150]
000074267fbcee3e  mov [r15+0xF8], r14
000074267fbcee45  mov rax, [r15]
000074267fbcee48  lea r12, [rax+0x68]
000074267fbcee4c  mov r11, [r13+r12*1]
000074267fbcee51  mov [r15+0x88], r11
000074267fbcee58  lea r12, [rax+0x28]
000074267fbcee5c  mov [r15+0x40], r12
000074267fbcee60  mov [r15+0x48], r14
000074267fbcee64  mov qword ptr [r15+0x50], 0x420B20
000074267fbcee6c  lea rax, [r14+0x100]
000074267fbcee73  mov r12, [r15+0xE8]
000074267fbcee7a  mov r11, [r15+0xD8]
000074267fbcee81  mov [r13+rax*1], r12
000074267fbcee86  lea rax, [r14+0x108]
000074267fbcee8d  mov [r13+rax*1], r11
000074267fbcee92  lea rax, [r14+0x110]
000074267fbcee99  mov r12, [r15+0xD0]
000074267fbceea0  mov r11, [r15+0xC8]
000074267fbceea7  mov [r13+rax*1], r12
000074267fbceeac  lea rax, [r14+0x118]
000074267fbceeb3  mov [r13+rax*1], r11
000074267fbceeb8  lea rax, [r14+0x120]
000074267fbceebf  mov r12, [r15+0xC0]
000074267fbceec6  mov r11, [r15+0xB8]
000074267fbceecd  mov [r13+rax*1], r12
000074267fbceed2  lea rax, [r14+0x128]
000074267fbceed9  mov [r13+rax*1], r11
000074267fbceede  lea rax, [r14+0x130]
000074267fbceee5  mov r12, [r15+0xB0]
000074267fbceeec  mov r11, [r15+0xA8]
000074267fbceef3  mov [r13+rax*1], r12
000074267fbceef8  lea rax, [r14+0x138]
000074267fbceeff  mov [r13+rax*1], r11
000074267fbcef04  lea rax, [r14+0x140]
000074267fbcef0b  mov r12, [r15+0xA0]
000074267fbcef12  mov r11, [r15+0x98]
000074267fbcef19  mov [r13+rax*1], r12
000074267fbcef1e  lea rax, [r14+0x148]
000074267fbcef25  mov [r13+rax*1], r11
000074267fbcef2a  cmp dword ptr [r15+0x318], 0x00
000074267fbcef32  jz 0x000074267FBCEFD0
000074267fbcef38  nop [rax+rax*1], ax
000074267fbcef41  nop [rax+rax*1], eax
000074267fbcef49  mov eax, 0x410704
000074267fbcef4e  mov [r15+0x100], rax
000074267fbcef55  jmp 0x000074267F9FE110
000074267fbcef5a  int3
000074267fbcef5b  call 0x000074267FAC0370
000074267fbcef60  jmp 0x000074267FBCEE51
000074267fbcef65  call 0x000074267FA0BC20
000074267fbcef6a  jmp 0x000074267FBCEE86
000074267fbcef6f  call 0x000074267FA0A9A0
000074267fbcef74  jmp 0x000074267FBCEE92
000074267fbcef79  call 0x000074267FA0BC20
000074267fbcef7e  jmp 0x000074267FBCEEAC
000074267fbcef83  call 0x000074267FA0A9A0
000074267fbcef88  jmp 0x000074267FBCEEB8
000074267fbcef8d  call 0x000074267FA0BC20
000074267fbcef92  jmp 0x000074267FBCEED2
000074267fbcef97  call 0x000074267FA0A9A0
000074267fbcef9c  jmp 0x000074267FBCEEDE
000074267fbcefa1  call 0x000074267FA0BC20
000074267fbcefa6  jmp 0x000074267FBCEEF8
000074267fbcefab  call 0x000074267FA0A9A0
000074267fbcefb0  jmp 0x000074267FBCEF04
000074267fbcefb5  call 0x000074267FA0BC20
000074267fbcefba  jmp 0x000074267FBCEF1E
000074267fbcefbf  call 0x000074267FA0A9A0
000074267fbcefc4  jmp 0x000074267FBCEF2A
000074267fbcefc9  int3
000074267fbcefca  nop [rax+rax*1], ax
000074267fbcefd0  mov rax, [r15+0x08]
000074267fbcefd4  movzx r14d, byte ptr [r13+rax*1]
000074267fbcefda  movzx r14d, r14b
000074267fbcefde  mov [rsp+0x10], r14d
000074267fbcefe3  mov r14d, r14d
000074267fbcefe6  mov [r15+0x58], r14
000074267fbcefea  lea r14, [rax+0x01]
000074267fbcefee  mov [r15+0x08], r14
000074267fbceff2  mov rax, [r15+0x88]
000074267fbceff9  lea r14, [rax+0x01]
000074267fbceffd  mov r12, [r15]
000074267fbcf000  lea r11, [r12+0x68]
000074267fbcf005  mov [r13+r11*1], r14
000074267fbcf00a  lea r14, [r12+rax*1]
000074267fbcf00e  mov [r15+0x60], r14
000074267fbcf012  lea rax, [r14+0x28]
000074267fbcf016  mov r11d, [rsp+0x10]
000074267fbcf01b  movzx r14d, r11b
000074267fbcf01f  mov [r13+rax*1], r14b
000074267fbcf024  lea rax, [r12+0x68]
000074267fbcf029  mov r14, [r13+rax*1]
000074267fbcf02e  mov [r15+0x88], r14
000074267fbcf035  xor eax, eax
000074267fbcf037  mov r12d, 0x40
000074267fbcf03d  cmp r14, r12
000074267fbcf040  cmc
000074267fbcf041  lahf
000074267fbcf042  seto al
000074267fbcf045  mov [r15+0x108], eax
000074267fbcf04c  mov eax, [r15+0x108]
000074267fbcf053  sahf
000074267fbcf054  jnz 0x000074267FBCF086
000074267fbcf056  cmp dword ptr [r15+0x318], 0x00
000074267fbcf05e  jz 0x000074267FBCF170
000074267fbcf064  nop [rax+rax*1], ax
000074267fbcf06d  nop [rax+rax*1], eax
000074267fbcf075  mov eax, 0x410724
000074267fbcf07a  mov [r15+0x100], rax
000074267fbcf081  jmp 0x000074267F9FE110
000074267fbcf086  cmp dword ptr [r15+0x318], 0x00
000074267fbcf08e  jz 0x000074267FBCF0E0
000074267fbcf094  nop [rax+rax*1], ax
000074267fbcf09d  nop [rax+rax*1], eax
000074267fbcf0a5  mov eax, 0x4106FC
000074267fbcf0aa  mov [r15+0x100], rax
000074267fbcf0b1  jmp 0x000074267F9FE110
000074267fbcf0b6  int3
000074267fbcf0b7  call 0x000074267FA0D860
000074267fbcf0bc  jmp 0x000074267FBCEFDA
000074267fbcf0c1  call 0x000074267FAB36E0
000074267fbcf0c6  jmp 0x000074267FBCF00A
000074267fbcf0cb  call 0x000074267FA0DD60
000074267fbcf0d0  jmp 0x000074267FBCF024
000074267fbcf0d5  call 0x000074267FA0DC20
000074267fbcf0da  jmp 0x000074267FBCF02E
000074267fbcf0df  int3
000074267fbcf0e0  mov rax, [r15+0x10]
000074267fbcf0e4  lea r14, [rax-0x01]
000074267fbcf0e8  mov [r15+0x10], r14
000074267fbcf0ec  test r14, r14
000074267fbcf0ef  setz r14b
000074267fbcf0f3  movzx r14, r14b
000074267fbcf0f7  mov [rsp+0x414], r14b
000074267fbcf0ff  cmp byte ptr [rsp+0x414], 0x00
000074267fbcf107  jz 0x000074267FBCF139
000074267fbcf109  cmp dword ptr [r15+0x318], 0x00
000074267fbcf111  jz 0x000074267FBD0670
000074267fbcf117  nop [rax+rax*1], ax
000074267fbcf120  nop [rax+rax*1], eax
000074267fbcf128  mov eax, 0x41091C
000074267fbcf12d  mov [r15+0x100], rax
000074267fbcf134  jmp 0x000074267F9FE110
000074267fbcf139  cmp dword ptr [r15+0x318], 0x00
000074267fbcf141  jz 0x000074267FBCEFD0
000074267fbcf147  nop [rax+rax*1], ax
000074267fbcf150  nop [rax+rax*1], eax
000074267fbcf158  mov eax, 0x410704
000074267fbcf15d  mov [r15+0x100], rax
000074267fbcf164  jmp 0x000074267F9FE110
000074267fbcf169  int3
000074267fbcf16a  int3
000074267fbcf16b  nop [rax+rax*1], eax
000074267fbcf170  mov rax, [r15+0x40]
000074267fbcf174  movzx r14d, byte ptr [r13+rax*1]
000074267fbcf17a  movaps xmm1, [r15+0x110]
000074267fbcf182  pinsrb xmm1, r14d, 0x00
000074267fbcf189  lea r14, [rax+0x01]
000074267fbcf18d  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf193  movaps xmm15, [r15+0x120]
000074267fbcf19b  pinsrb xmm15, r12d, 0x00
000074267fbcf1a2  lea r14, [rax+0x02]
000074267fbcf1a6  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf1ac  movaps xmm14, [r15+0x130]
000074267fbcf1b4  pinsrb xmm14, r12d, 0x00
000074267fbcf1bb  lea r14, [rax+0x03]
000074267fbcf1bf  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf1c5  movaps xmm13, [r15+0x140]
000074267fbcf1cd  pinsrb xmm13, r12d, 0x00
000074267fbcf1d4  lea r14, [rax+0x04]
000074267fbcf1d8  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf1de  pinsrb xmm1, r12d, 0x01
000074267fbcf1e5  lea r14, [rax+0x05]
000074267fbcf1e9  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf1ef  pinsrb xmm15, r12d, 0x01
000074267fbcf1f6  lea r14, [rax+0x06]
000074267fbcf1fa  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf200  pinsrb xmm14, r12d, 0x01
000074267fbcf207  lea r14, [rax+0x07]
000074267fbcf20b  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf211  pinsrb xmm13, r12d, 0x01
000074267fbcf218  lea r14, [rax+0x08]
000074267fbcf21c  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf222  pinsrb xmm1, r12d, 0x02
000074267fbcf229  lea r14, [rax+0x09]
000074267fbcf22d  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf233  pinsrb xmm15, r12d, 0x02
000074267fbcf23a  lea r14, [rax+0x0A]
000074267fbcf23e  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf244  pinsrb xmm14, r12d, 0x02
000074267fbcf24b  lea r14, [rax+0x0B]
000074267fbcf24f  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf255  pinsrb xmm13, r12d, 0x02
000074267fbcf25c  lea r14, [rax+0x0C]
000074267fbcf260  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf266  pinsrb xmm1, r12d, 0x03
000074267fbcf26d  lea r14, [rax+0x0D]
000074267fbcf271  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf277  pinsrb xmm15, r12d, 0x03
000074267fbcf27e  lea r14, [rax+0x0E]
000074267fbcf282  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf288  pinsrb xmm14, r12d, 0x03
000074267fbcf28f  lea r14, [rax+0x0F]
000074267fbcf293  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf299  pinsrb xmm13, r12d, 0x03
000074267fbcf2a0  lea r14, [rax+0x10]
000074267fbcf2a4  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf2aa  pinsrb xmm1, r12d, 0x04
000074267fbcf2b1  lea r14, [rax+0x11]
000074267fbcf2b5  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf2bb  pinsrb xmm15, r12d, 0x04
000074267fbcf2c2  lea r14, [rax+0x12]
000074267fbcf2c6  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf2cc  pinsrb xmm14, r12d, 0x04
000074267fbcf2d3  lea r14, [rax+0x13]
000074267fbcf2d7  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf2dd  pinsrb xmm13, r12d, 0x04
000074267fbcf2e4  lea r14, [rax+0x14]
000074267fbcf2e8  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf2ee  pinsrb xmm1, r12d, 0x05
000074267fbcf2f5  lea r14, [rax+0x15]
000074267fbcf2f9  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf2ff  pinsrb xmm15, r12d, 0x05
000074267fbcf306  lea r14, [rax+0x16]
000074267fbcf30a  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf310  pinsrb xmm14, r12d, 0x05
000074267fbcf317  lea r14, [rax+0x17]
000074267fbcf31b  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf321  pinsrb xmm13, r12d, 0x05
000074267fbcf328  lea r14, [rax+0x18]
000074267fbcf32c  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf332  pinsrb xmm1, r12d, 0x06
000074267fbcf339  lea r14, [rax+0x19]
000074267fbcf33d  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf343  pinsrb xmm15, r12d, 0x06
000074267fbcf34a  lea r14, [rax+0x1A]
000074267fbcf34e  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf354  pinsrb xmm14, r12d, 0x06
000074267fbcf35b  lea r14, [rax+0x1B]
000074267fbcf35f  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf365  pinsrb xmm13, r12d, 0x06
000074267fbcf36c  lea r14, [rax+0x1C]
000074267fbcf370  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf376  pinsrb xmm1, r12d, 0x07
000074267fbcf37d  lea r14, [rax+0x1D]
000074267fbcf381  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf387  pinsrb xmm15, r12d, 0x07
000074267fbcf38e  lea r14, [rax+0x1E]
000074267fbcf392  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf398  pinsrb xmm14, r12d, 0x07
000074267fbcf39f  lea r14, [rax+0x1F]
000074267fbcf3a3  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf3a9  pinsrb xmm13, r12d, 0x07
000074267fbcf3b0  lea r14, [rax+0x20]
000074267fbcf3b4  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf3ba  pinsrb xmm1, r12d, 0x08
000074267fbcf3c1  lea r14, [rax+0x21]
000074267fbcf3c5  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf3cb  pinsrb xmm15, r12d, 0x08
000074267fbcf3d2  lea r14, [rax+0x22]
000074267fbcf3d6  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf3dc  pinsrb xmm14, r12d, 0x08
000074267fbcf3e3  lea r14, [rax+0x23]
000074267fbcf3e7  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf3ed  pinsrb xmm13, r12d, 0x08
000074267fbcf3f4  lea r14, [rax+0x24]
000074267fbcf3f8  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf3fe  pinsrb xmm1, r12d, 0x09
000074267fbcf405  lea r14, [rax+0x25]
000074267fbcf409  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf40f  pinsrb xmm15, r12d, 0x09
000074267fbcf416  lea r14, [rax+0x26]
000074267fbcf41a  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf420  pinsrb xmm14, r12d, 0x09
000074267fbcf427  lea r14, [rax+0x27]
000074267fbcf42b  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf431  pinsrb xmm13, r12d, 0x09
000074267fbcf438  lea r14, [rax+0x28]
000074267fbcf43c  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf442  pinsrb xmm1, r12d, 0x0A
000074267fbcf449  lea r14, [rax+0x29]
000074267fbcf44d  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf453  pinsrb xmm15, r12d, 0x0A
000074267fbcf45a  lea r14, [rax+0x2A]
000074267fbcf45e  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf464  pinsrb xmm14, r12d, 0x0A
000074267fbcf46b  lea r14, [rax+0x2B]
000074267fbcf46f  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf475  pinsrb xmm13, r12d, 0x0A
000074267fbcf47c  lea r14, [rax+0x2C]
000074267fbcf480  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf486  pinsrb xmm1, r12d, 0x0B
000074267fbcf48d  lea r14, [rax+0x2D]
000074267fbcf491  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf497  pinsrb xmm15, r12d, 0x0B
000074267fbcf49e  lea r14, [rax+0x2E]
000074267fbcf4a2  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf4a8  pinsrb xmm14, r12d, 0x0B
000074267fbcf4af  lea r14, [rax+0x2F]
000074267fbcf4b3  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf4b9  pinsrb xmm13, r12d, 0x0B
000074267fbcf4c0  lea r14, [rax+0x30]
000074267fbcf4c4  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf4ca  pinsrb xmm1, r12d, 0x0C
000074267fbcf4d1  lea r14, [rax+0x31]
000074267fbcf4d5  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf4db  pinsrb xmm15, r12d, 0x0C
000074267fbcf4e2  lea r14, [rax+0x32]
000074267fbcf4e6  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf4ec  pinsrb xmm14, r12d, 0x0C
000074267fbcf4f3  lea r14, [rax+0x33]
000074267fbcf4f7  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf4fd  pinsrb xmm13, r12d, 0x0C
000074267fbcf504  lea r14, [rax+0x34]
000074267fbcf508  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf50e  pinsrb xmm1, r12d, 0x0D
000074267fbcf515  lea r14, [rax+0x35]
000074267fbcf519  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf51f  pinsrb xmm15, r12d, 0x0D
000074267fbcf526  lea r14, [rax+0x36]
000074267fbcf52a  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf530  pinsrb xmm14, r12d, 0x0D
000074267fbcf537  lea r14, [rax+0x37]
000074267fbcf53b  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf541  pinsrb xmm13, r12d, 0x0D
000074267fbcf548  lea r14, [rax+0x38]
000074267fbcf54c  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf552  pinsrb xmm1, r12d, 0x0E
000074267fbcf559  lea r14, [rax+0x39]
000074267fbcf55d  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf563  pinsrb xmm15, r12d, 0x0E
000074267fbcf56a  lea r14, [rax+0x3A]
000074267fbcf56e  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf574  pinsrb xmm14, r12d, 0x0E
000074267fbcf57b  lea r14, [rax+0x3B]
000074267fbcf57f  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf585  pinsrb xmm13, r12d, 0x0E
000074267fbcf58c  lea r14, [rax+0x3C]
000074267fbcf590  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf596  pinsrb xmm1, r12d, 0x0F
000074267fbcf59d  movaps [r15+0x110], xmm1
000074267fbcf5a5  lea r14, [rax+0x3D]
000074267fbcf5a9  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf5af  pinsrb xmm15, r12d, 0x0F
000074267fbcf5b6  movaps [r15+0x120], xmm15
000074267fbcf5be  lea r14, [rax+0x3E]
000074267fbcf5c2  movzx r12d, byte ptr [r13+r14*1]
000074267fbcf5c8  pinsrb xmm14, r12d, 0x0F
000074267fbcf5cf  movaps [r15+0x130], xmm14
000074267fbcf5d7  lea r14, [rax+0x3F]
000074267fbcf5db  movzx eax, byte ptr [r13+r14*1]
000074267fbcf5e1  pinsrb xmm13, eax, 0x0F
000074267fbcf5e8  movaps [r15+0x140], xmm13
000074267fbcf5f0  movq xmm1, qword ptr [r15+0x120]
000074267fbcf5f9  pmovzxbw xmm1, xmm1
000074267fbcf5fe  psllw xmm1, 0x00
000074267fbcf603  movaps [r15+0x150], xmm1
000074267fbcf60b  movq xmm1, qword ptr [r15+0x130]
000074267fbcf614  pmovzxbw xmm1, xmm1
000074267fbcf619  psllw xmm1, 0x00
000074267fbcf61e  movaps [r15+0x160], xmm1
000074267fbcf626  movq xmm1, qword ptr [r15+0x110]
000074267fbcf62f  pmovzxbw xmm1, xmm1
000074267fbcf634  psllw xmm1, 0x00
000074267fbcf639  movaps [r15+0x170], xmm1
000074267fbcf641  movaps xmm15, [r15+0x110]
000074267fbcf649  pextrq rax, xmm15, 0x01
000074267fbcf650  movq xmm15, rax
000074267fbcf655  pmovzxbw xmm15, xmm15
000074267fbcf65b  psllw xmm15, 0x00
000074267fbcf661  movaps [r15+0x180], xmm15
000074267fbcf669  movaps xmm14, [r15+0x120]
000074267fbcf671  pextrq rax, xmm14, 0x01
000074267fbcf678  movq xmm14, rax
000074267fbcf67d  pmovzxbw xmm14, xmm14
000074267fbcf683  psllw xmm14, 0x00
000074267fbcf689  movaps [r15+0x210], xmm14
000074267fbcf691  movaps xmm13, [r15+0x130]
000074267fbcf699  pextrq rax, xmm13, 0x01
000074267fbcf6a0  movq xmm13, rax
000074267fbcf6a5  pmovzxbw xmm13, xmm13
000074267fbcf6ab  psllw xmm13, 0x00
000074267fbcf6b1  movaps [r15+0x220], xmm13
000074267fbcf6b9  movq xmm12, qword ptr [r15+0x140]
000074267fbcf6c2  pmovzxbw xmm12, xmm12
000074267fbcf6c8  psllw xmm12, 0x00
000074267fbcf6ce  movaps [r15+0x250], xmm12
000074267fbcf6d6  movaps xmm12, [r15+0x140]
000074267fbcf6de  pextrq rax, xmm12, 0x01
000074267fbcf6e5  movq xmm12, rax
000074267fbcf6ea  pmovzxbw xmm12, xmm12
000074267fbcf6f0  psllw xmm12, 0x00
000074267fbcf6f6  movaps [r15+0x110], xmm12
000074267fbcf6fe  movq xmm11, qword ptr [r15+0x150]
000074267fbcf707  pmovzxwd xmm11, xmm11
000074267fbcf70d  pslld xmm11, 0x10
000074267fbcf713  movq xmm10, qword ptr [r15+0x160]
000074267fbcf71c  pmovzxwd xmm10, xmm10
000074267fbcf722  pslld xmm10, 0x08
000074267fbcf728  pextrq rax, xmm1, 0x01
000074267fbcf72f  movq xmm1, rax
000074267fbcf734  pmovzxwd xmm1, xmm1
000074267fbcf739  pslld xmm1, 0x00
000074267fbcf73e  movaps [r15+0x260], xmm1
000074267fbcf746  pextrq rax, xmm15, 0x01
000074267fbcf74d  movq xmm15, rax
000074267fbcf752  pmovzxwd xmm15, xmm15
000074267fbcf758  pslld xmm15, 0x00
000074267fbcf75e  movaps [r15+0x270], xmm15
000074267fbcf766  movq xmm9, qword ptr [r15+0x170]
000074267fbcf76f  pmovzxwd xmm9, xmm9
000074267fbcf775  pslld xmm9, 0x00
000074267fbcf77b  pextrq rax, xmm14, 0x01
000074267fbcf782  movq xmm14, rax
000074267fbcf787  pmovzxwd xmm14, xmm14
000074267fbcf78d  pslld xmm14, 0x10
000074267fbcf793  movaps [r15+0x280], xmm14
000074267fbcf79b  movq xmm8, qword ptr [r15+0x180]
000074267fbcf7a4  pmovzxwd xmm8, xmm8
000074267fbcf7aa  pslld xmm8, 0x00
000074267fbcf7b0  movq xmm7, qword ptr [r15+0x210]
000074267fbcf7b9  pmovzxwd xmm7, xmm7
000074267fbcf7be  pslld xmm7, 0x10
000074267fbcf7c3  movaps xmm6, [r15+0x150]
000074267fbcf7cb  pextrq rax, xmm6, 0x01
000074267fbcf7d2  movq xmm6, rax
000074267fbcf7d7  pmovzxwd xmm6, xmm6
000074267fbcf7dc  pslld xmm6, 0x10
000074267fbcf7e1  por xmm11, xmm10
000074267fbcf7e6  movaps [r15+0x230], xmm11
000074267fbcf7ee  pextrq rax, xmm13, 0x01
000074267fbcf7f5  movq xmm13, rax
000074267fbcf7fa  pmovzxwd xmm13, xmm13
000074267fbcf800  pslld xmm13, 0x08
000074267fbcf806  movaps [r15+0x240], xmm13
000074267fbcf80e  movq xmm10, qword ptr [r15+0x220]
000074267fbcf817  pmovzxwd xmm10, xmm10
000074267fbcf81d  pslld xmm10, 0x08
000074267fbcf823  movaps xmm5, [r15+0x160]
000074267fbcf82b  pextrq rax, xmm5, 0x01
000074267fbcf832  movq xmm5, rax
000074267fbcf837  pmovzxwd xmm5, xmm5
000074267fbcf83c  pslld xmm5, 0x08
000074267fbcf841  pslld xmm9, 0x18
000074267fbcf847  pslld xmm15, 0x18
000074267fbcf84d  pslld xmm8, 0x18
000074267fbcf853  movq xmm4, qword ptr [r15+0x250]
000074267fbcf85c  pmovzxwd xmm4, xmm4
000074267fbcf861  pslld xmm4, 0x00
000074267fbcf866  por xmm14, xmm13
000074267fbcf86b  por xmm7, xmm10
000074267fbcf870  movaps [r15+0x210], xmm7
000074267fbcf878  pslld xmm1, 0x18
000074267fbcf87d  movaps [r15+0x220], xmm1
000074267fbcf885  por xmm6, xmm5
000074267fbcf889  por xmm11, xmm9
000074267fbcf88e  movaps [r15+0x160], xmm11
000074267fbcf896  pextrq rax, xmm12, 0x01
000074267fbcf89d  movq xmm13, rax
000074267fbcf8a2  pmovzxwd xmm13, xmm13
000074267fbcf8a8  pslld xmm13, 0x00
000074267fbcf8ae  movaps [r15+0x170], xmm13
000074267fbcf8b6  movq xmm12, qword ptr [r15+0x110]
000074267fbcf8bf  pmovzxwd xmm12, xmm12
000074267fbcf8c5  pslld xmm12, 0x00
000074267fbcf8cb  por xmm14, xmm15
000074267fbcf8d0  por xmm7, xmm8
000074267fbcf8d5  movaps xmm15, [r15+0x250]
000074267fbcf8dd  pextrq rax, xmm15, 0x01
000074267fbcf8e4  movq xmm15, rax
000074267fbcf8e9  pmovzxwd xmm15, xmm15
000074267fbcf8ef  pslld xmm15, 0x00
000074267fbcf8f5  movaps [r15+0x180], xmm15
000074267fbcf8fd  por xmm6, xmm1
000074267fbcf901  movaps [r15+0x150], xmm6
000074267fbcf909  por xmm11, xmm4
000074267fbcf90e  movaps [r15+0x140], xmm11
000074267fbcf916  por xmm7, xmm12
000074267fbcf91b  movaps [r15+0x110], xmm7
000074267fbcf923  por xmm14, xmm13
000074267fbcf928  movaps [r15+0x120], xmm14
000074267fbcf930  por xmm6, xmm15
000074267fbcf935  movaps [r15+0x130], xmm6
000074267fbcf93d  mov rax, [r15+0xF8]
000074267fbcf944  lea r14, [rax+0x20]
000074267fbcf948  movups [r13+r14*1], xmm7
000074267fbcf94e  lea r14, [rax+0x30]
000074267fbcf952  movups [r13+r14*1], xmm14
000074267fbcf958  movups [r13+rax*1], xmm11
000074267fbcf95e  lea r14, [rax+0x10]
000074267fbcf962  movups [r13+r14*1], xmm6
000074267fbcf968  mov r14d, [r13+rax*1]
000074267fbcf96d  mov rax, [r15+0x48]
000074267fbcf971  mov [r15+0x68], rax
000074267fbcf975  mov qword ptr [r15+0x58], 0x04
000074267fbcf97d  lea r12, [rax+0x04]
000074267fbcf981  mov r11d, [r13+r12*1]
000074267fbcf986  mov [rsp+0x10], r11d
000074267fbcf98b  mov r11d, r11d
000074267fbcf98e  mov [r15+0x70], r11
000074267fbcf992  lea r12, [rax+0x38]
000074267fbcf996  mov r11d, [r13+r12*1]
000074267fbcf99b  lea r12, [rax+0x24]
000074267fbcf99f  mov r10d, [r13+r12*1]
000074267fbcf9a4  mov [rsp+0x20], r10d
000074267fbcf9a9  mov r10d, r10d
000074267fbcf9ac  mov [r15+0x90], r10
000074267fbcf9b3  mov [rsp+0x30], rax
000074267fbcf9b8  xor eax, eax
000074267fbcf9ba  mov r12d, 0x04
000074267fbcf9c0  mov r10d, 0xC0
000074267fbcf9c6  cmp r12, r10
000074267fbcf9c9  cmc
000074267fbcf9ca  lahf
000074267fbcf9cb  seto al
000074267fbcf9ce  mov [r15+0x108], eax
000074267fbcf9d5  mov eax, [rsp+0x10]
000074267fbcf9d9  mov r12d, [rsp+0x10]
000074267fbcf9de  shrd eax, r12d, 0x07
000074267fbcf9e3  mov [rsp+0x10], r11d
000074267fbcf9e8  mov r10d, [rsp+0x10]
000074267fbcf9ed  shrd r11d, r10d, 0x11
000074267fbcf9f2  mov r9d, [rsp+0x20]
000074267fbcf9f7  lea r8d, [r9d+r14d*1]
000074267fbcf9fc  rorx r14d, r12d, 0x12
000074267fbcfa02  xor eax, r14d
000074267fbcfa05  rorx r14d, r10d, 0x13
000074267fbcfa0b  xor r11d, r14d
000074267fbcfa0e  mov [rsp+0x10], r11d
000074267fbcfa13  mov r11d, r11d
000074267fbcfa16  mov [r15+0x88], r11
000074267fbcfa1d  mov [rsp+0x20], r12d
000074267fbcfa22  shr r12d, 0x03
000074267fbcfa26  xor eax, r12d
000074267fbcfa29  mov [rsp+0x40], eax
000074267fbcfa2d  mov eax, eax
000074267fbcfa2f  mov [r15+0x80], rax
000074267fbcfa36  shr r10d, 0x0A
000074267fbcfa3a  mov eax, [rsp+0x10]
000074267fbcfa3e  xor eax, r10d
000074267fbcfa41  mov [rsp+0x10], eax
000074267fbcfa45  mov eax, eax
000074267fbcfa47  mov [r15+0x78], rax
000074267fbcfa4b  mov eax, [rsp+0x40]
000074267fbcfa4f  lea r14d, [r8d+eax*1]
000074267fbcfa54  mov eax, [rsp+0x10]
000074267fbcfa58  lea r12d, [r14d+eax*1]
000074267fbcfa5d  mov rax, [rsp+0x30]
000074267fbcfa62  lea r14, [rax+0x40]
000074267fbcfa66  mov [r13+r14*1], r12d
000074267fbcfa6b  mov eax, [rsp+0x20]
000074267fbcfa6f  mov eax, eax
000074267fbcfa71  mov [r15+0x60], rax
000074267fbcfa75  mov eax, [r15+0x108]
000074267fbcfa7c  sahf
000074267fbcfa7d  jnz 0x000074267FBCFAAF
000074267fbcfa7f  cmp dword ptr [r15+0x318], 0x00
000074267fbcfa87  jz 0x000074267FBCFF70
000074267fbcfa8d  nop [rax+rax*1], ax
000074267fbcfa96  nop [rax+rax*1], eax
000074267fbcfa9e  mov eax, 0x410820
000074267fbcfaa3  mov [r15+0x100], rax
000074267fbcfaaa  jmp 0x000074267F9FE110
000074267fbcfaaf  cmp dword ptr [r15+0x318], 0x00
000074267fbcfab7  jz 0x000074267FBCFDC0
000074267fbcfabd  nop [rax+rax*1], ax
000074267fbcfac6  nop [rax+rax*1], eax
000074267fbcface  mov eax, 0x4107D8
000074267fbcfad3  mov [r15+0x100], rax
000074267fbcfada  jmp 0x000074267F9FE110
000074267fbcfadf  int3
000074267fbcfae0  call 0x000074267FA0D860
000074267fbcfae5  jmp 0x000074267FBCF17A
000074267fbcfaea  call 0x000074267FAE2420
000074267fbcfaef  jmp 0x000074267FBCF193
000074267fbcfaf4  call 0x000074267FAE2420
000074267fbcfaf9  jmp 0x000074267FBCF1AC
000074267fbcfafe  call 0x000074267FAE2420
000074267fbcfb03  jmp 0x000074267FBCF1C5
000074267fbcfb08  call 0x000074267FAE2420
000074267fbcfb0d  jmp 0x000074267FBCF1DE
000074267fbcfb12  call 0x000074267FAE2420
000074267fbcfb17  jmp 0x000074267FBCF1EF
000074267fbcfb1c  call 0x000074267FAE2420
000074267fbcfb21  jmp 0x000074267FBCF200
000074267fbcfb26  call 0x000074267FAE2420
000074267fbcfb2b  jmp 0x000074267FBCF211
000074267fbcfb30  call 0x000074267FAE2420
000074267fbcfb35  jmp 0x000074267FBCF222
000074267fbcfb3a  call 0x000074267FAE2420
000074267fbcfb3f  jmp 0x000074267FBCF233
000074267fbcfb44  call 0x000074267FAE2420
000074267fbcfb49  jmp 0x000074267FBCF244
000074267fbcfb4e  call 0x000074267FAE2420
000074267fbcfb53  jmp 0x000074267FBCF255
000074267fbcfb58  call 0x000074267FAE2420
000074267fbcfb5d  jmp 0x000074267FBCF266
000074267fbcfb62  call 0x000074267FAE2420
000074267fbcfb67  jmp 0x000074267FBCF277
000074267fbcfb6c  call 0x000074267FAE2420
000074267fbcfb71  jmp 0x000074267FBCF288
000074267fbcfb76  call 0x000074267FAE2420
000074267fbcfb7b  jmp 0x000074267FBCF299
000074267fbcfb80  call 0x000074267FAE2420
000074267fbcfb85  jmp 0x000074267FBCF2AA
000074267fbcfb8a  call 0x000074267FAE2420
000074267fbcfb8f  jmp 0x000074267FBCF2BB
000074267fbcfb94  call 0x000074267FAE2420
000074267fbcfb99  jmp 0x000074267FBCF2CC
000074267fbcfb9e  call 0x000074267FAE2420
000074267fbcfba3  jmp 0x000074267FBCF2DD
000074267fbcfba8  call 0x000074267FAE2420
000074267fbcfbad  jmp 0x000074267FBCF2EE
000074267fbcfbb2  call 0x000074267FAE2420
000074267fbcfbb7  jmp 0x000074267FBCF2FF
000074267fbcfbbc  call 0x000074267FAE2420
000074267fbcfbc1  jmp 0x000074267FBCF310
000074267fbcfbc6  call 0x000074267FAE2420
000074267fbcfbcb  jmp 0x000074267FBCF321
000074267fbcfbd0  call 0x000074267FAE2420
000074267fbcfbd5  jmp 0x000074267FBCF332
000074267fbcfbda  call 0x000074267FAE2420
000074267fbcfbdf  jmp 0x000074267FBCF343
000074267fbcfbe4  call 0x000074267FAE2420
000074267fbcfbe9  jmp 0x000074267FBCF354
000074267fbcfbee  call 0x000074267FAE2420
000074267fbcfbf3  jmp 0x000074267FBCF365
000074267fbcfbf8  call 0x000074267FAE2420
000074267fbcfbfd  jmp 0x000074267FBCF376
000074267fbcfc02  call 0x000074267FAE2420
000074267fbcfc07  jmp 0x000074267FBCF387
000074267fbcfc0c  call 0x000074267FAE2420
000074267fbcfc11  jmp 0x000074267FBCF398
000074267fbcfc16  call 0x000074267FAE2420
000074267fbcfc1b  jmp 0x000074267FBCF3A9
000074267fbcfc20  call 0x000074267FAE2420
000074267fbcfc25  jmp 0x000074267FBCF3BA
000074267fbcfc2a  call 0x000074267FAE2420
000074267fbcfc2f  jmp 0x000074267FBCF3CB
000074267fbcfc34  call 0x000074267FAE2420
000074267fbcfc39  jmp 0x000074267FBCF3DC
000074267fbcfc3e  call 0x000074267FAE2420
000074267fbcfc43  jmp 0x000074267FBCF3ED
000074267fbcfc48  call 0x000074267FAE2420
000074267fbcfc4d  jmp 0x000074267FBCF3FE
000074267fbcfc52  call 0x000074267FAE2420
000074267fbcfc57  jmp 0x000074267FBCF40F
000074267fbcfc5c  call 0x000074267FAE2420
000074267fbcfc61  jmp 0x000074267FBCF420
000074267fbcfc66  call 0x000074267FAE2420
000074267fbcfc6b  jmp 0x000074267FBCF431
000074267fbcfc70  call 0x000074267FAE2420
000074267fbcfc75  jmp 0x000074267FBCF442
000074267fbcfc7a  call 0x000074267FAE2420
000074267fbcfc7f  jmp 0x000074267FBCF453
000074267fbcfc84  call 0x000074267FAE2420
000074267fbcfc89  jmp 0x000074267FBCF464
000074267fbcfc8e  call 0x000074267FAE2420
000074267fbcfc93  jmp 0x000074267FBCF475
000074267fbcfc98  call 0x000074267FAE2420
000074267fbcfc9d  jmp 0x000074267FBCF486
000074267fbcfca2  call 0x000074267FAE2420
000074267fbcfca7  jmp 0x000074267FBCF497
000074267fbcfcac  call 0x000074267FAE2420
000074267fbcfcb1  jmp 0x000074267FBCF4A8
000074267fbcfcb6  call 0x000074267FAE2420
000074267fbcfcbb  jmp 0x000074267FBCF4B9
000074267fbcfcc0  call 0x000074267FAE2420
000074267fbcfcc5  jmp 0x000074267FBCF4CA
000074267fbcfcca  call 0x000074267FAE2420
000074267fbcfccf  jmp 0x000074267FBCF4DB
000074267fbcfcd4  call 0x000074267FAE2420
000074267fbcfcd9  jmp 0x000074267FBCF4EC
000074267fbcfcde  call 0x000074267FAE2420
000074267fbcfce3  jmp 0x000074267FBCF4FD
000074267fbcfce8  call 0x000074267FAE2420
000074267fbcfced  jmp 0x000074267FBCF50E
000074267fbcfcf2  call 0x000074267FAE2420
000074267fbcfcf7  jmp 0x000074267FBCF51F
000074267fbcfcfc  call 0x000074267FAE2420
000074267fbcfd01  jmp 0x000074267FBCF530
000074267fbcfd06  call 0x000074267FAE2420
000074267fbcfd0b  jmp 0x000074267FBCF541
000074267fbcfd10  call 0x000074267FAE2420
000074267fbcfd15  jmp 0x000074267FBCF552
000074267fbcfd1a  call 0x000074267FAE2420
000074267fbcfd1f  jmp 0x000074267FBCF563
000074267fbcfd24  call 0x000074267FAE2420
000074267fbcfd29  jmp 0x000074267FBCF574
000074267fbcfd2e  call 0x000074267FAE2420
000074267fbcfd33  jmp 0x000074267FBCF585
000074267fbcfd38  call 0x000074267FAE2420
000074267fbcfd3d  jmp 0x000074267FBCF596
000074267fbcfd42  call 0x000074267FAE2420
000074267fbcfd47  jmp 0x000074267FBCF5AF
000074267fbcfd4c  call 0x000074267FAE2420
000074267fbcfd51  jmp 0x000074267FBCF5C8
000074267fbcfd56  call 0x000074267FAD5610
000074267fbcfd5b  jmp 0x000074267FBCF5E1
000074267fbcfd60  call 0x000074267FADC580
000074267fbcfd65  jmp 0x000074267FBCF94E
000074267fbcfd6a  call 0x000074267FAE46C0
000074267fbcfd6f  jmp 0x000074267FBCF958
000074267fbcfd74  call 0x000074267FA09E90
000074267fbcfd79  jmp 0x000074267FBCF95E
000074267fbcfd7e  call 0x000074267FADB310
000074267fbcfd83  jmp 0x000074267FBCF968
000074267fbcfd88  call 0x000074267FA0DAE0
000074267fbcfd8d  jmp 0x000074267FBCF96D
000074267fbcfd92  call 0x000074267FAC0230
000074267fbcfd97  jmp 0x000074267FBCF986
000074267fbcfd9c  call 0x000074267FAC0230
000074267fbcfda1  jmp 0x000074267FBCF99B
000074267fbcfda6  call 0x000074267FABEFC0
000074267fbcfdab  jmp 0x000074267FBCF9A4
000074267fbcfdb0  call 0x000074267FAE2BA0
000074267fbcfdb5  jmp 0x000074267FBCFA6B
000074267fbcfdba  int3
000074267fbcfdbb  nop [rax+rax*1], eax
000074267fbcfdc0  mov rax, [r15+0x48]
000074267fbcfdc4  mov r14, [r15+0x58]
000074267fbcfdc8  lea r12, [rax+r14*1]
000074267fbcfdcc  mov [r15+0x68], r12
000074267fbcfdd0  lea rax, [r14+0x04]
000074267fbcfdd4  mov [r15+0x58], rax
000074267fbcfdd8  lea r14, [r12+0x04]
000074267fbcfddd  mov r11d, [r13+r14*1]
000074267fbcfde2  mov [rsp+0x10], r11d
000074267fbcfde7  mov r11d, r11d
000074267fbcfdea  mov [r15+0x70], r11
000074267fbcfdee  lea r14, [r12+0x38]
000074267fbcfdf3  mov r11d, [r13+r14*1]
000074267fbcfdf8  lea r14, [r12+0x24]
000074267fbcfdfd  mov r10d, [r13+r14*1]
000074267fbcfe02  mov [rsp+0x20], r10d
000074267fbcfe07  mov r10d, r10d
000074267fbcfe0a  mov [r15+0x90], r10
000074267fbcfe11  mov [rsp+0x30], rax
000074267fbcfe16  xor eax, eax
000074267fbcfe18  mov r14, [rsp+0x30]
000074267fbcfe1d  mov r10d, 0xC0
000074267fbcfe23  cmp r14, r10
000074267fbcfe26  cmc
000074267fbcfe27  lahf
000074267fbcfe28  seto al
000074267fbcfe2b  mov [r15+0x108], eax
000074267fbcfe32  mov eax, [rsp+0x10]
000074267fbcfe36  mov r14d, [rsp+0x10]
000074267fbcfe3b  shrd eax, r14d, 0x07
000074267fbcfe40  mov [rsp+0x10], r11d
000074267fbcfe45  mov r10d, [rsp+0x10]
000074267fbcfe4a  shrd r11d, r10d, 0x11
000074267fbcfe4f  mov r9d, [r15+0x60]
000074267fbcfe53  mov r8d, [rsp+0x20]
000074267fbcfe58  lea ebp, [r8d+r9d*1]
000074267fbcfe5d  rorx r9d, r14d, 0x12
000074267fbcfe63  xor eax, r9d
000074267fbcfe66  rorx r9d, r10d, 0x13
000074267fbcfe6c  xor r11d, r9d
000074267fbcfe6f  mov [rsp+0x10], r11d
000074267fbcfe74  mov r11d, r11d
000074267fbcfe77  mov [r15+0x88], r11
000074267fbcfe7e  mov [rsp+0x20], r14d
000074267fbcfe83  shr r14d, 0x03
000074267fbcfe87  xor eax, r14d
000074267fbcfe8a  mov [rsp+0x30], eax
000074267fbcfe8e  mov eax, eax
000074267fbcfe90  mov [r15+0x80], rax
000074267fbcfe97  shr r10d, 0x0A
000074267fbcfe9b  mov eax, [rsp+0x10]
000074267fbcfe9f  xor eax, r10d
000074267fbcfea2  mov [rsp+0x10], eax
000074267fbcfea6  mov eax, eax
000074267fbcfea8  mov [r15+0x78], rax
000074267fbcfeac  mov eax, [rsp+0x30]
000074267fbcfeb0  lea r14d, [ebp+eax*1]
000074267fbcfeb6  mov eax, [rsp+0x10]
000074267fbcfeba  lea r11d, [r14d+eax*1]
000074267fbcfebf  lea rax, [r12+0x40]
000074267fbcfec4  mov [r13+rax*1], r11d
000074267fbcfec9  mov eax, [rsp+0x20]
000074267fbcfecd  mov eax, eax
000074267fbcfecf  mov [r15+0x60], rax
000074267fbcfed3  mov eax, [r15+0x108]
000074267fbcfeda  sahf
000074267fbcfedb  jnz 0x000074267FBCFF0D
000074267fbcfedd  cmp dword ptr [r15+0x318], 0x00
000074267fbcfee5  jz 0x000074267FBCFF70
000074267fbcfeeb  nop [rax+rax*1], ax
000074267fbcfef4  nop [rax+rax*1], eax
000074267fbcfefc  mov eax, 0x410820
000074267fbcff01  mov [r15+0x100], rax
000074267fbcff08  jmp 0x000074267F9FE110
000074267fbcff0d  cmp dword ptr [r15+0x318], 0x00
000074267fbcff15  jz 0x000074267FBCFDC0
000074267fbcff1b  nop [rax+rax*1], ax
000074267fbcff24  nop [rax+rax*1], eax
000074267fbcff2c  mov eax, 0x4107D8
000074267fbcff31  mov [r15+0x100], rax
000074267fbcff38  jmp 0x000074267F9FE110
000074267fbcff3d  int3
000074267fbcff3e  call 0x000074267FAE1430
000074267fbcff43  jmp 0x000074267FBCFDE2
000074267fbcff48  call 0x000074267FAE1430
000074267fbcff4d  jmp 0x000074267FBCFDF8
000074267fbcff52  call 0x000074267FAE01C0
000074267fbcff57  jmp 0x000074267FBCFE02
000074267fbcff5c  call 0x000074267FA0A860
000074267fbcff61  jmp 0x000074267FBCFEC9
000074267fbcff66  int3
000074267fbcff67  nop [rax+rax*1], ax
000074267fbcff70  mov rax, [r15]
000074267fbcff73  mov r14d, [r13+rax*1]
000074267fbcff78  lea r12, [rax+0x04]
000074267fbcff7c  mov r11d, [r13+r12*1]
000074267fbcff81  mov [rsp+0x10], r14d
000074267fbcff86  mov r14d, r14d
000074267fbcff89  mov [r15+0x78], r14
000074267fbcff8d  mov [rsp+0x20], r11d
000074267fbcff92  mov r11d, r11d
000074267fbcff95  mov [r15+0x80], r11
000074267fbcff9c  lea r14, [rax+0x08]
000074267fbcffa0  mov r12d, [r13+r14*1]
000074267fbcffa5  lea r14, [rax+0x0C]
000074267fbcffa9  mov r11d, [r13+r14*1]
000074267fbcffae  mov [rsp+0x30], r12d
000074267fbcffb3  mov r12d, r12d
000074267fbcffb6  mov [r15+0x70], r12
000074267fbcffba  mov [rsp+0x40], r11d
000074267fbcffbf  mov r11d, r11d
000074267fbcffc2  mov [r15+0x68], r11
000074267fbcffc6  lea r14, [rax+0x18]
000074267fbcffca  mov r12d, [r13+r14*1]
000074267fbcffcf  lea r14, [rax+0x1C]
000074267fbcffd3  mov r11d, [r13+r14*1]
000074267fbcffd8  mov [rsp+0x50], r12d
000074267fbcffdd  mov r12d, r12d
000074267fbcffe0  mov [r15+0x58], r12
000074267fbcffe4  mov [rsp+0x60], r11d
000074267fbcffe9  mov r11d, r11d
000074267fbcffec  mov [r15+0x60], r11
000074267fbcfff0  lea r14, [rax+0x10]
000074267fbcfff4  mov r12d, [r13+r14*1]
000074267fbcfff9  lea r14, [rax+0x14]
000074267fbcfffd  mov eax, [r13+r14*1]
000074267fbd0002  mov [rsp+0x70], r12d
000074267fbd0007  mov r12d, r12d
000074267fbd000a  mov [r15+0x18], r12
000074267fbd000e  mov [rsp+0x80], eax
000074267fbd0015  mov eax, eax
000074267fbd0017  mov [r15+0x90], rax
000074267fbd001e  mov eax, [rsp+0x70]
000074267fbd0022  mov eax, eax
000074267fbd0024  mov [r15+0x30], rax
000074267fbd0028  mov eax, [rsp+0x50]
000074267fbd002c  mov eax, eax
000074267fbd002e  mov [r15+0xA0], rax
000074267fbd0035  mov eax, [rsp+0x30]
000074267fbd0039  mov eax, eax
000074267fbd003b  mov [r15+0x28], rax
000074267fbd003f  mov eax, [rsp+0x20]
000074267fbd0043  mov eax, eax
000074267fbd0045  mov [r15+0x98], rax
000074267fbd004c  mov eax, [rsp+0x10]
000074267fbd0050  mov eax, eax
000074267fbd0052  mov [r15+0x38], rax
000074267fbd0056  mov eax, [rsp+0x70]
000074267fbd005a  mov r14d, [rsp+0x70]
000074267fbd005f  shrd eax, r14d, 0x06
000074267fbd0064  mov [rsp+0x70], r14d
000074267fbd0069  mov r12d, [rsp+0x80]
000074267fbd0071  and r14d, r12d
000074267fbd0074  mov r11d, [rsp+0x10]
000074267fbd0079  mov r10d, [rsp+0x10]
000074267fbd007e  shrd r11d, r10d, 0x02
000074267fbd0083  mov [rsp+0x10], r12d
000074267fbd0088  mov r12d, r12d
000074267fbd008b  mov [r15+0x20], r12
000074267fbd008f  mov r12, [r15+0x50]
000074267fbd0093  mov r9d, [r13+r12*1]
000074267fbd0098  mov r12d, [rsp+0x50]
000074267fbd009d  mov r8d, [rsp+0x70]
000074267fbd00a2  andn ebp, r8d, r12d
000074267fbd00a7  mov edi, [rsp+0x60]
000074267fbd00ab  lea esi, [r14d+edi*1]
000074267fbd00b0  rorx r14d, r8d, 0x0B
000074267fbd00b6  xor eax, r14d
000074267fbd00b9  rorx r14d, r10d, 0x0D
000074267fbd00bf  xor r11d, r14d
000074267fbd00c2  lea edi, [esi+ebp*1]
000074267fbd00c6  mov r14, [r15+0x48]
000074267fbd00ca  mov ebp, [r13+r14*1]
000074267fbd00cf  mov r14d, [rsp+0x30]
000074267fbd00d4  mov esi, [rsp+0x20]
000074267fbd00d8  and r14d, esi
000074267fbd00db  mov [rsp+0x20], r14d
000074267fbd00e0  mov r14d, r14d
000074267fbd00e3  mov [r15+0xD8], r14
000074267fbd00ea  lea r14d, [edi+r9d*1]
000074267fbd00ef  mov r9d, [rsp+0x30]
000074267fbd00f4  xor r9d, esi
000074267fbd00f7  rorx edi, r8d, 0x19
000074267fbd00fd  xor eax, edi
000074267fbd00ff  and r9d, r10d
000074267fbd0102  rorx edi, r10d, 0x16
000074267fbd0108  xor r11d, edi
000074267fbd010b  mov [rsp+0x30], r11d
000074267fbd0110  mov r11d, r11d
000074267fbd0113  mov [r15+0xD0], r11
000074267fbd011a  lea r11d, [r14d+ebp*1]
000074267fbd011f  mov r10d, [rsp+0x20]
000074267fbd0124  xor r9d, r10d
000074267fbd0127  lea r14d, [r11d+eax*1]
000074267fbd012c  mov qword ptr [r15+0x88], 0x04
000074267fbd0137  mov eax, [rsp+0x30]
000074267fbd013b  lea r11d, [r9d+eax*1]
000074267fbd0140  mov eax, [rsp+0x40]
000074267fbd0144  lea r10d, [r14d+eax*1]
000074267fbd0149  mov r10d, r10d
000074267fbd014c  mov [r15+0xB8], r10
000074267fbd0153  xor eax, eax
000074267fbd0155  mov r10d, 0x04
000074267fbd015b  mov r9d, 0x100
000074267fbd0161  cmp r10, r9
000074267fbd0164  cmc
000074267fbd0165  lahf
000074267fbd0166  seto al
000074267fbd0169  mov [r15+0x108], eax
000074267fbd0170  lea eax, [r11d+r14d*1]
000074267fbd0175  mov eax, eax
000074267fbd0177  mov [r15+0xA8], rax
000074267fbd017e  mov r12d, r12d
000074267fbd0181  mov [r15+0xB0], r12
000074267fbd0188  mov eax, [rsp+0x10]
000074267fbd018c  mov eax, eax
000074267fbd018e  mov [r15+0xC0], rax
000074267fbd0195  mov r8d, r8d
000074267fbd0198  mov [r15+0xC8], r8
000074267fbd019f  mov eax, [r15+0x108]
000074267fbd01a6  sahf
000074267fbd01a7  jnz 0x000074267FBD01D9
000074267fbd01a9  cmp dword ptr [r15+0x318], 0x00
000074267fbd01b1  jz 0x000074267FBD04A0
000074267fbd01b7  nop [rax+rax*1], ax
000074267fbd01c0  nop [rax+rax*1], eax
000074267fbd01c8  mov eax, 0x4108E0
000074267fbd01cd  mov [r15+0x100], rax
000074267fbd01d4  jmp 0x000074267F9FE110
000074267fbd01d9  cmp dword ptr [r15+0x318], 0x00
000074267fbd01e1  jz 0x000074267FBD0270
000074267fbd01e7  nop [rax+rax*1], ax
000074267fbd01f0  nop [rax+rax*1], eax
000074267fbd01f8  mov eax, 0x410854
000074267fbd01fd  mov [r15+0x100], rax
000074267fbd0204  jmp 0x000074267F9FE110
000074267fbd0209  int3
000074267fbd020a  call 0x000074267FA0DAE0
000074267fbd020f  jmp 0x000074267FBCFF78
000074267fbd0214  call 0x000074267FAC0230
000074267fbd0219  jmp 0x000074267FBCFF81
000074267fbd021e  call 0x000074267FAE26A0
000074267fbd0223  jmp 0x000074267FBCFFA5
000074267fbd0228  call 0x000074267FAE1430
000074267fbd022d  jmp 0x000074267FBCFFAE
000074267fbd0232  call 0x000074267FAE26A0
000074267fbd0237  jmp 0x000074267FBCFFCF
000074267fbd023c  call 0x000074267FAE1430
000074267fbd0241  jmp 0x000074267FBCFFD8
000074267fbd0246  call 0x000074267FAE26A0
000074267fbd024b  jmp 0x000074267FBCFFF9
000074267fbd0250  call 0x000074267FAD5890
000074267fbd0255  jmp 0x000074267FBD0002
000074267fbd025a  call 0x000074267FABDD50
000074267fbd025f  jmp 0x000074267FBD0098
000074267fbd0264  call 0x000074267FADA580
000074267fbd0269  jmp 0x000074267FBD00CF
000074267fbd026e  int3
000074267fbd026f  nop
000074267fbd0270  mov eax, [r15+0xB8]
000074267fbd0277  mov [rsp+0x10], eax
000074267fbd027b  mov eax, eax
000074267fbd027d  mov [r15+0x30], rax
000074267fbd0281  mov eax, [r15+0xC0]
000074267fbd0288  mov [rsp+0x20], eax
000074267fbd028c  mov eax, eax
000074267fbd028e  mov [r15+0xA0], rax
000074267fbd0295  mov eax, [r15+0x28]
000074267fbd0299  mov r14d, [r15+0x98]
000074267fbd02a0  mov [rsp+0x30], r14d
000074267fbd02a5  mov r14d, r14d
000074267fbd02a8  mov [r15+0x28], r14
000074267fbd02ac  mov r14d, [r15+0x38]
000074267fbd02b0  mov [rsp+0x40], r14d
000074267fbd02b5  mov r14d, r14d
000074267fbd02b8  mov [r15+0x98], r14
000074267fbd02bf  mov r14d, [r15+0xA8]
000074267fbd02c6  mov [rsp+0x50], r14d
000074267fbd02cb  mov r14d, r14d
000074267fbd02ce  mov [r15+0x38], r14
000074267fbd02d2  mov r14d, [rsp+0x10]
000074267fbd02d7  mov r12d, [rsp+0x10]
000074267fbd02dc  shrd r14d, r12d, 0x06
000074267fbd02e1  mov r11d, [r15+0xC8]
000074267fbd02e8  mov [rsp+0x10], r12d
000074267fbd02ed  and r12d, r11d
000074267fbd02f0  mov r10d, [rsp+0x50]
000074267fbd02f5  mov r9d, [rsp+0x50]
000074267fbd02fa  shrd r10d, r9d, 0x02
000074267fbd02ff  mov [rsp+0x50], r11d
000074267fbd0304  mov r11d, r11d
000074267fbd0307  mov [r15+0x20], r11
000074267fbd030b  mov r11, [r15+0x88]
000074267fbd0312  mov r8, [r15+0x50]
000074267fbd0316  lea rbp, [r8+r11*1]
000074267fbd031a  mov r8d, [r13+rbp*1]
000074267fbd031f  mov ebp, [rsp+0x20]
000074267fbd0323  mov edi, [rsp+0x10]
000074267fbd0327  andn esi, edi, ebp
000074267fbd032c  mov edx, [r15+0xB0]
000074267fbd0333  lea ecx, [r12d+edx*1]
000074267fbd0338  rorx r12d, edi, 0x0B
000074267fbd033e  xor r14d, r12d
000074267fbd0341  rorx r12d, r9d, 0x0D
000074267fbd0347  xor r10d, r12d
000074267fbd034a  lea r12d, [ecx+esi*1]
000074267fbd034f  mov rsi, [r15+0x48]
000074267fbd0353  lea rdx, [rsi+r11*1]
000074267fbd0357  mov esi, [r13+rdx*1]
000074267fbd035c  mov edx, [rsp+0x30]
000074267fbd0360  mov ecx, [rsp+0x40]
000074267fbd0364  and edx, ecx
000074267fbd0366  mov [rsp+0x10], edx
000074267fbd036a  mov edx, edx
000074267fbd036c  mov [r15+0xD8], rdx
000074267fbd0373  lea edx, [r12d+r8d*1]
000074267fbd0378  mov r12d, [rsp+0x30]
000074267fbd037d  xor r12d, ecx
000074267fbd0380  rorx r8d, edi, 0x19
000074267fbd0386  xor r14d, r8d
000074267fbd0389  and r12d, r9d
000074267fbd038c  rorx r8d, r9d, 0x16
000074267fbd0392  xor r10d, r8d
000074267fbd0395  mov [rsp+0x20], r10d
000074267fbd039a  mov r10d, r10d
000074267fbd039d  mov [r15+0xD0], r10
000074267fbd03a4  lea r10d, [edx+esi*1]
000074267fbd03a9  mov r9d, [rsp+0x10]
000074267fbd03ae  xor r12d, r9d
000074267fbd03b1  lea r9d, [r10d+r14d*1]
000074267fbd03b6  lea r14, [r11+0x04]
000074267fbd03ba  mov [r15+0x88], r14
000074267fbd03c1  mov r11d, [rsp+0x20]
000074267fbd03c6  lea r10d, [r12d+r11d*1]
000074267fbd03cb  lea r11d, [r9d+eax*1]
000074267fbd03d0  mov r11d, r11d
000074267fbd03d3  mov [r15+0xB8], r11
000074267fbd03da  xor eax, eax
000074267fbd03dc  mov r12d, 0x100
000074267fbd03e2  cmp r14, r12
000074267fbd03e5  cmc
000074267fbd03e6  lahf
000074267fbd03e7  seto al
000074267fbd03ea  mov [r15+0x108], eax
000074267fbd03f1  lea eax, [r10d+r9d*1]
000074267fbd03f6  mov eax, eax
000074267fbd03f8  mov [r15+0xA8], rax
000074267fbd03ff  mov ebp, ebp
000074267fbd0401  mov [r15+0xB0], rbp
000074267fbd0408  mov eax, [rsp+0x50]
000074267fbd040c  mov eax, eax
000074267fbd040e  mov [r15+0xC0], rax
000074267fbd0415  mov edi, edi
000074267fbd0417  mov [r15+0xC8], rdi
000074267fbd041e  mov eax, [r15+0x108]
000074267fbd0425  sahf
000074267fbd0426  jnz 0x000074267FBD0458
000074267fbd0428  cmp dword ptr [r15+0x318], 0x00
000074267fbd0430  jz 0x000074267FBD04A0
000074267fbd0436  nop [rax+rax*1], ax
000074267fbd043f  nop [rax+rax*1], eax
000074267fbd0447  mov eax, 0x4108E0
000074267fbd044c  mov [r15+0x100], rax
000074267fbd0453  jmp 0x000074267F9FE110
000074267fbd0458  cmp dword ptr [r15+0x318], 0x00
000074267fbd0460  jz 0x000074267FBD0270
000074267fbd0466  nop [rax+rax*1], ax
000074267fbd046f  nop [rax+rax*1], eax
000074267fbd0477  mov eax, 0x410854
000074267fbd047c  mov [r15+0x100], rax
000074267fbd0483  jmp 0x000074267F9FE110
000074267fbd0488  int3
000074267fbd0489  call 0x000074267FA49010
000074267fbd048e  jmp 0x000074267FBD031F
000074267fbd0493  call 0x000074267FA25930
000074267fbd0498  jmp 0x000074267FBD035C
000074267fbd049d  int3
000074267fbd049e  nop
000074267fbd04a0  mov eax, [r15+0x98]
000074267fbd04a7  mov r14d, [r15+0x70]
000074267fbd04ab  lea r12d, [eax+r14d*1]
000074267fbd04b0  mov eax, [r15+0x28]
000074267fbd04b4  mov r14d, [r15+0x68]
000074267fbd04b8  lea r11d, [eax+r14d*1]
000074267fbd04bd  mov qword ptr [r15+0x88], 0x00
000074267fbd04c8  mov eax, [r15+0xA8]
000074267fbd04cf  mov r14d, [r15+0x78]
000074267fbd04d3  lea r10d, [eax+r14d*1]
000074267fbd04d8  mov [rsp+0x10], r10d
000074267fbd04dd  mov r10d, r10d
000074267fbd04e0  mov [r15+0x78], r10
000074267fbd04e4  mov eax, [r15+0x38]
000074267fbd04e8  mov r14d, [r15+0x80]
000074267fbd04ef  lea r10d, [eax+r14d*1]
000074267fbd04f4  mov [rsp+0x20], r10d
000074267fbd04f9  mov r10d, r10d
000074267fbd04fc  mov [r15+0x80], r10
000074267fbd0503  mov rax, [r15]
000074267fbd0506  lea r14, [rax+0x08]
000074267fbd050a  mov [r13+r14*1], r12d
000074267fbd050f  lea r14, [rax+0x0C]
000074267fbd0513  mov [r13+r14*1], r11d
000074267fbd0518  mov r14d, [r15+0xB8]
000074267fbd051f  mov r12d, [r15+0x18]
000074267fbd0523  lea r11d, [r14d+r12d*1]
000074267fbd0528  mov [rsp+0x30], r11d
000074267fbd052d  mov r11d, r11d
000074267fbd0530  mov [r15+0x68], r11
000074267fbd0534  mov r14d, [r15+0x30]
000074267fbd0538  mov r12d, [r15+0x90]
000074267fbd053f  lea r11d, [r14d+r12d*1]
000074267fbd0544  mov [rsp+0x40], r11d
000074267fbd0549  mov r11d, r11d
000074267fbd054c  mov [r15+0x70], r11
000074267fbd0550  mov r14d, [r15+0x20]
000074267fbd0554  mov r12d, [r15+0x58]
000074267fbd0558  lea r11d, [r14d+r12d*1]
000074267fbd055d  mov [rsp+0x50], r11d
000074267fbd0562  mov r11d, r11d
000074267fbd0565  mov [r15+0x58], r11
000074267fbd0569  mov r14d, [r15+0xA0]
000074267fbd0570  mov r12d, [r15+0x60]
000074267fbd0574  lea r11d, [r14d+r12d*1]
000074267fbd0579  mov [rsp+0x60], r11d
000074267fbd057e  mov r11d, r11d
000074267fbd0581  mov [r15+0x60], r11
000074267fbd0585  mov r14d, [rsp+0x10]
000074267fbd058a  mov [r13+rax*1], r14d
000074267fbd058f  lea r14, [rax+0x04]
000074267fbd0593  mov r12d, [rsp+0x20]
000074267fbd0598  mov [r13+r14*1], r12d
000074267fbd059d  lea r14, [rax+0x10]
000074267fbd05a1  mov r12d, [rsp+0x30]
000074267fbd05a6  mov [r13+r14*1], r12d
000074267fbd05ab  lea r14, [rax+0x14]
000074267fbd05af  mov r12d, [rsp+0x40]
000074267fbd05b4  mov [r13+r14*1], r12d
000074267fbd05b9  lea r14, [rax+0x18]
000074267fbd05bd  mov r12d, [rsp+0x50]
000074267fbd05c2  mov [r13+r14*1], r12d
000074267fbd05c7  lea r14, [rax+0x1C]
000074267fbd05cb  mov r12d, [rsp+0x60]
000074267fbd05d0  mov [r13+r14*1], r12d
000074267fbd05d5  lea r14, [rax+0x68]
000074267fbd05d9  xor eax, eax
000074267fbd05db  mov [r13+r14*1], rax
000074267fbd05e0  cmp dword ptr [r15+0x318], 0x00
000074267fbd05e8  jz 0x000074267FBCF0E0
000074267fbd05ee  nop [rax+rax*1], ax
000074267fbd05f7  nop [rax+rax*1], eax
000074267fbd05ff  mov eax, 0x4106FC
000074267fbd0604  mov [r15+0x100], rax
000074267fbd060b  jmp 0x000074267F9FE110
000074267fbd0610  int3
000074267fbd0611  call 0x000074267FAE2BA0
000074267fbd0616  jmp 0x000074267FBD050F
000074267fbd061b  call 0x000074267FAE1920
000074267fbd0620  jmp 0x000074267FBD0518
000074267fbd0625  call 0x000074267FA0DFE0
000074267fbd062a  jmp 0x000074267FBD058F
000074267fbd062f  call 0x000074267FAE2BA0
000074267fbd0634  jmp 0x000074267FBD059D
000074267fbd0639  call 0x000074267FAE2BA0
000074267fbd063e  jmp 0x000074267FBD05AB
000074267fbd0643  call 0x000074267FAE2BA0
000074267fbd0648  jmp 0x000074267FBD05B9
000074267fbd064d  call 0x000074267FAE2BA0
000074267fbd0652  jmp 0x000074267FBD05C7
000074267fbd0657  call 0x000074267FAE2BA0
000074267fbd065c  jmp 0x000074267FBD05D5
000074267fbd0661  call 0x000074267FAD5EB0
000074267fbd0666  jmp 0x000074267FBD05E0
000074267fbd066b  int3
000074267fbd066c  nop [rax], eax
000074267fbd0670  mov rax, [r15+0xF8]
000074267fbd0677  lea r14, [rax+0x140]
000074267fbd067e  mov r12, [r13+r14*1]
000074267fbd0683  lea r14, [rax+0x148]
000074267fbd068a  mov r11, [r13+r14*1]
000074267fbd068f  mov [r15+0xA0], r12
000074267fbd0696  mov [r15+0x98], r11
000074267fbd069d  lea r14, [rax+0x130]
000074267fbd06a4  mov r12, [r13+r14*1]
000074267fbd06a9  lea r14, [rax+0x138]
000074267fbd06b0  mov r11, [r13+r14*1]
000074267fbd06b5  mov [r15+0xB0], r12
000074267fbd06bc  mov [r15+0xA8], r11
000074267fbd06c3  lea r14, [rax+0x120]
000074267fbd06ca  mov r12, [r13+r14*1]
000074267fbd06cf  lea r14, [rax+0x128]
000074267fbd06d6  mov r11, [r13+r14*1]
000074267fbd06db  mov [r15+0xC0], r12
000074267fbd06e2  mov [r15+0xB8], r11
000074267fbd06e9  lea r14, [rax+0x110]
000074267fbd06f0  mov r12, [r13+r14*1]
000074267fbd06f5  lea r14, [rax+0x118]
000074267fbd06fc  mov r11, [r13+r14*1]
000074267fbd0701  mov [r15+0xD0], r12
000074267fbd0708  mov [r15+0xC8], r11
000074267fbd070f  lea r14, [rax+0x100]
000074267fbd0716  mov r12, [r13+r14*1]
000074267fbd071b  lea r14, [rax+0x108]
000074267fbd0722  mov r11, [r13+r14*1]
000074267fbd0727  mov [r15+0xE8], r12
000074267fbd072e  mov [r15+0xD8], r11
000074267fbd0735  lea r14, [rax+0x150]
000074267fbd073c  mov [r15+0xF8], r14
000074267fbd0743  mov rax, [r15+0xF0]
000074267fbd074a  mov [r15+0x100], rax
000074267fbd0751  jmp 0x000074267FBCE5C0
000074267fbd0756  int3
000074267fbd0757  call 0x000074267FAE27E0
000074267fbd075c  jmp 0x000074267FBD0683
000074267fbd0761  call 0x000074267FAE1570
000074267fbd0766  jmp 0x000074267FBD068F
000074267fbd076b  call 0x000074267FAE27E0
000074267fbd0770  jmp 0x000074267FBD06A9
000074267fbd0775  call 0x000074267FAE1570
000074267fbd077a  jmp 0x000074267FBD06B5
000074267fbd077f  call 0x000074267FAE27E0
000074267fbd0784  jmp 0x000074267FBD06CF
000074267fbd0789  call 0x000074267FAE1570
000074267fbd078e  jmp 0x000074267FBD06DB
000074267fbd0793  call 0x000074267FAE27E0
000074267fbd0798  jmp 0x000074267FBD06F5
000074267fbd079d  call 0x000074267FAE1570
000074267fbd07a2  jmp 0x000074267FBD0701
000074267fbd07a7  call 0x000074267FAE27E0
000074267fbd07ac  jmp 0x000074267FBD071B
000074267fbd07b1  call 0x000074267FAE1570
000074267fbd07b6  jmp 0x000074267FBD0727
000074267fbd07bb  int3
000074267fbd07bc  nop [rax], eax
000074267fbd07c0  mov eax, [r15+0xA0]
000074267fbd07c7  mov [rsp+0x10], eax
000074267fbd07cb  xor eax, eax
000074267fbd07cd  mov r14d, [rsp+0x10]
000074267fbd07d2  sub r14d, 0x01
000074267fbd07d6  cmc
000074267fbd07d7  lahf
000074267fbd07d8  seto al
000074267fbd07db  mov [r15+0x108], eax
000074267fbd07e2  mov r14d, r14d
000074267fbd07e5  mov [r15+0xA0], r14
000074267fbd07ec  mov eax, [r15+0x108]
000074267fbd07f3  sahf
000074267fbd07f4  jnz 0x000074267FBD0826
000074267fbd07f6  cmp dword ptr [r15+0x318], 0x00
000074267fbd07fe  jz 0x000074267FBD0900
000074267fbd0804  nop [rax+rax*1], ax
000074267fbd080d  nop [rax+rax*1], eax
000074267fbd0815  mov eax, 0x41028C
000074267fbd081a  mov [r15+0x100], rax
000074267fbd0821  jmp 0x000074267F9FE110
000074267fbd0826  cmp dword ptr [r15+0x318], 0x00
000074267fbd082e  jz 0x000074267FBD0860
000074267fbd0834  nop [rax+rax*1], ax
000074267fbd083d  nop [rax+rax*1], eax
000074267fbd0845  mov eax, 0x410274
000074267fbd084a  mov [r15+0x100], rax
000074267fbd0851  jmp 0x000074267F9FE110
000074267fbd0856  int3
000074267fbd0857  int3
000074267fbd0858  nop [rax+rax*1], eax
000074267fbd0860  mov rax, [r15+0xF8]
000074267fbd0867  lea r14, [rax+0xD0]
000074267fbd086e  mov [r15], r14
000074267fbd0871  mov rax, [r15+0x98]
000074267fbd0878  mov [r15+0x08], rax
000074267fbd087c  mov qword ptr [r15+0x10], 0x12C
000074267fbd0884  mov qword ptr [r15+0xF0], 0x410284
000074267fbd088f  mov r14d, [r15+0x320]
000074267fbd0896  mov eax, 0x410284
000074267fbd089b  mov rcx, 0x74267FBD07C0
000074267fbd08a5  mov [r15+r14*8+0x328], rax
000074267fbd08ad  mov [r15+r14*8+0x368], rcx
000074267fbd08b5  add r14d, 0x01
000074267fbd08b9  and r14d, 0x07
000074267fbd08bd  mov [r15+0x320], r14d
000074267fbd08c4  cmp dword ptr [r15+0x318], 0x00
000074267fbd08cc  jz 0x000074267FBCED70
000074267fbd08d2  nop [rax+rax*1], ax
000074267fbd08db  nop [rax+rax*1], eax
000074267fbd08e3  mov eax, 0x4106BC
000074267fbd08e8  mov [r15+0x100], rax
000074267fbd08ef  jmp 0x000074267F9FE110
000074267fbd08f4  int3
000074267fbd08f5  int3
000074267fbd08f6  nop [rax+rax*1], ax
000074267fbd08ff  nop
000074267fbd0900  mov rax, [r15+0xF8]
000074267fbd0907  lea r14, [rax+0xF0]
000074267fbd090e  mov r12, [r13+r14*1]
000074267fbd0913  mov [r15+0x98], r12
000074267fbd091a  mov qword ptr [r15+0x40], 0x80
000074267fbd0922  lea r14, [rax+0xD0]
000074267fbd0929  mov [r15], r14
000074267fbd092c  lea r14, [rax+0x14C]
000074267fbd0933  mov [r15+0x08], r14
000074267fbd0937  mov qword ptr [r15+0x10], 0x01
000074267fbd093f  lea r14, [rax+0x14C]
000074267fbd0946  mov eax, 0x80
000074267fbd094b  mov [r13+r14*1], al
000074267fbd0950  mov qword ptr [r15+0xF0], 0x4102A8
000074267fbd095b  mov r14d, [r15+0x320]
000074267fbd0962  mov eax, 0x4102A8
000074267fbd0967  mov rcx, 0x74267FBD09E0
000074267fbd0971  mov [r15+r14*8+0x328], rax
000074267fbd0979  mov [r15+r14*8+0x368], rcx
000074267fbd0981  add r14d, 0x01
000074267fbd0985  and r14d, 0x07
000074267fbd0989  mov [r15+0x320], r14d
000074267fbd0990  cmp dword ptr [r15+0x318], 0x00
000074267fbd0998  jz 0x000074267FBCED70
000074267fbd099e  nop [rax+rax*1], ax
000074267fbd09a7  nop [rax+rax*1], eax
000074267fbd09af  mov eax, 0x4106BC
000074267fbd09b4  mov [r15+0x100], rax
000074267fbd09bb  jmp 0x000074267F9FE110
000074267fbd09c0  int3
000074267fbd09c1  call 0x000074267FAE27E0
000074267fbd09c6  jmp 0x000074267FBD0913
000074267fbd09cb  call 0x000074267FAD5AF0
000074267fbd09d0  jmp 0x000074267FBD0950
000074267fbd09d5  int3
000074267fbd09d6  nop [rax+rax*1], ax
000074267fbd09df  nop
000074267fbd09e0  mov rax, [r15+0xF8]
000074267fbd09e7  lea r14, [rax+0x138]
000074267fbd09ee  mov r12, [r13+r14*1]
000074267fbd09f3  mov [r15+0x40], r12
000074267fbd09f7  lea r14, [rax+0x148]
000074267fbd09fe  xor eax, eax
000074267fbd0a00  mov [r13+r14*1], al
000074267fbd0a05  xor eax, eax
000074267fbd0a07  mov r14d, 0x38
000074267fbd0a0d  cmp r12, r14
000074267fbd0a10  cmc
000074267fbd0a11  lahf
000074267fbd0a12  seto al
000074267fbd0a15  mov [r15+0x108], eax
000074267fbd0a1c  mov eax, [r15+0x108]
000074267fbd0a23  sahf
000074267fbd0a24  jz 0x000074267FBD0A56
000074267fbd0a26  cmp dword ptr [r15+0x318], 0x00
000074267fbd0a2e  jz 0x000074267FBD0AA0
000074267fbd0a34  nop [rax+rax*1], ax
000074267fbd0a3d  nop [rax+rax*1], eax
000074267fbd0a45  mov eax, 0x4102B8
000074267fbd0a4a  mov [r15+0x100], rax
000074267fbd0a51  jmp 0x000074267F9FE110
000074267fbd0a56  cmp dword ptr [r15+0x318], 0x00
000074267fbd0a5e  jz 0x000074267FBD0BF0
000074267fbd0a64  nop [rax+rax*1], ax
000074267fbd0a6d  nop [rax+rax*1], eax
000074267fbd0a75  mov eax, 0x4102D4
000074267fbd0a7a  mov [r15+0x100], rax
000074267fbd0a81  jmp 0x000074267F9FE110
000074267fbd0a86  int3
000074267fbd0a87  call 0x000074267FAE27E0
000074267fbd0a8c  jmp 0x000074267FBD09F3
000074267fbd0a91  call 0x000074267FAD5AF0
000074267fbd0a96  jmp 0x000074267FBD0A05
000074267fbd0a9b  int3
000074267fbd0a9c  nop [rax], eax
000074267fbd0aa0  mov rax, [r15+0xF8]
000074267fbd0aa7  lea r14, [rax+0xD0]
000074267fbd0aae  mov [r15], r14
000074267fbd0ab1  lea r14, [rax+0x148]
000074267fbd0ab8  mov [r15+0x08], r14
000074267fbd0abc  mov qword ptr [r15+0x10], 0x01
000074267fbd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000074267fbd0acf  mov r14d, [r15+0x320]
000074267fbd0ad6  mov eax, 0x4102C8
000074267fbd0adb  mov rcx, 0x74267FBD0B40
000074267fbd0ae5  mov [r15+r14*8+0x328], rax
000074267fbd0aed  mov [r15+r14*8+0x368], rcx
000074267fbd0af5  add r14d, 0x01
000074267fbd0af9  and r14d, 0x07
000074267fbd0afd  mov [r15+0x320], r14d
000074267fbd0b04  cmp dword ptr [r15+0x318], 0x00
000074267fbd0b0c  jz 0x000074267FBCED70
000074267fbd0b12  nop [rax+rax*1], ax
000074267fbd0b1b  nop [rax+rax*1], eax
000074267fbd0b23  mov eax, 0x4106BC
000074267fbd0b28  mov [r15+0x100], rax
000074267fbd0b2f  jmp 0x000074267F9FE110
000074267fbd0b34  int3
000074267fbd0b35  int3
000074267fbd0b36  nop [rax+rax*1], ax
000074267fbd0b3f  nop
000074267fbd0b40  mov rax, [r15+0xF8]
000074267fbd0b47  lea r14, [rax+0x138]
000074267fbd0b4e  mov rax, [r13+r14*1]
000074267fbd0b53  mov [r15+0x40], rax
000074267fbd0b57  mov [rsp+0x10], rax
000074267fbd0b5c  xor eax, eax
000074267fbd0b5e  mov r14, [rsp+0x10]
000074267fbd0b63  mov r12d, 0x38
000074267fbd0b69  cmp r14, r12
000074267fbd0b6c  cmc
000074267fbd0b6d  lahf
000074267fbd0b6e  seto al
000074267fbd0b71  mov [r15+0x108], eax
000074267fbd0b78  mov eax, [r15+0x108]
000074267fbd0b7f  sahf
000074267fbd0b80  jnz 0x000074267FBD0BB2
000074267fbd0b82  cmp dword ptr [r15+0x318], 0x00
000074267fbd0b8a  jz 0x000074267FBD0BF0
000074267fbd0b90  nop [rax+rax*1], ax
000074267fbd0b99  nop [rax+rax*1], eax
000074267fbd0ba1  mov eax, 0x4102D4
000074267fbd0ba6  mov [r15+0x100], rax
000074267fbd0bad  jmp 0x000074267F9FE110
000074267fbd0bb2  cmp dword ptr [r15+0x318], 0x00
000074267fbd0bba  jz 0x000074267FBD0AA0
000074267fbd0bc0  nop [rax+rax*1], ax
000074267fbd0bc9  nop [rax+rax*1], eax
000074267fbd0bd1  mov eax, 0x4102B8
000074267fbd0bd6  mov [r15+0x100], rax
000074267fbd0bdd  jmp 0x000074267F9FE110
000074267fbd0be2  int3
000074267fbd0be3  call 0x000074267FAD59C0
000074267fbd0be8  jmp 0x000074267FBD0B53
000074267fbd0bed  int3
000074267fbd0bee  nop
000074267fbd0bf0  mov rax, [r15+0x98]
000074267fbd0bf7  rorx r14, rax, 0x3D
000074267fbd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000074267fbd0c01  mov rax, [r15+0xF8]
000074267fbd0c08  lea r12, [rax+0xD0]
000074267fbd0c0f  mov [r15], r12
000074267fbd0c12  lea r12, [rax+0x140]
000074267fbd0c19  mov [r15+0x08], r12
000074267fbd0c1d  mov qword ptr [r15+0x10], 0x08
000074267fbd0c25  bswap r14
000074267fbd0c28  mov [r15+0x40], r14
000074267fbd0c2c  lea r12, [rax+0x140]
000074267fbd0c33  mov [r13+r12*1], r14
000074267fbd0c38  mov qword ptr [r15+0xF0], 0x4102F0
000074267fbd0c43  mov r14d, [r15+0x320]
000074267fbd0c4a  mov eax, 0x4102F0
000074267fbd0c4f  mov rcx, 0x74267FBD0CC0
000074267fbd0c59  mov [r15+r14*8+0x328], rax
000074267fbd0c61  mov [r15+r14*8+0x368], rcx
000074267fbd0c69  add r14d, 0x01
000074267fbd0c6d  and r14d, 0x07
000074267fbd0c71  mov [r15+0x320], r14d
000074267fbd0c78  cmp dword ptr [r15+0x318], 0x00
000074267fbd0c80  jz 0x000074267FBCED70
000074267fbd0c86  nop [rax+rax*1], ax
000074267fbd0c8f  nop [rax+rax*1], eax
000074267fbd0c97  mov eax, 0x4106BC
000074267fbd0c9c  mov [r15+0x100], rax
000074267fbd0ca3  jmp 0x000074267F9FE110
000074267fbd0ca8  int3
000074267fbd0ca9  call 0x000074267FAC3FE0
000074267fbd0cae  jmp 0x000074267FBD0C38
000074267fbd0cb3  int3
000074267fbd0cb4  nop [rax+rax*1], ax
000074267fbd0cbd  nop [rax], eax
000074267fbd0cc0  mov rax, [r15+0xF8]
000074267fbd0cc7  lea r14, [rax+0xD0]
000074267fbd0cce  mov r12d, [r13+r14*1]
000074267fbd0cd3  lea r14, [rax+0xD4]
000074267fbd0cda  mov r11d, [r13+r14*1]
000074267fbd0cdf  lea r14, [rax+0xD8]
000074267fbd0ce6  mov r10d, [r13+r14*1]
000074267fbd0ceb  lea r14, [rax+0xDC]
000074267fbd0cf2  mov r9d, [r13+r14*1]
000074267fbd0cf7  mov qword ptr [r15+0x48], 0x430C20
000074267fbd0cff  mov qword ptr [r15+0xA0], 0x00
000074267fbd0d0a  bswap r12d
000074267fbd0d0d  bswap r11d
000074267fbd0d10  mov qword ptr [r15+0x98], 0x430D8C
000074267fbd0d1b  mov r14d, 0x430C20
000074267fbd0d21  mov [r13+r14*1], r12d
000074267fbd0d26  mov r14d, 0x430C24
000074267fbd0d2c  mov [r13+r14*1], r11d
000074267fbd0d31  bswap r10d
000074267fbd0d34  bswap r9d
000074267fbd0d37  lea r14, [rax+0xE0]
000074267fbd0d3e  mov r12d, [r13+r14*1]
000074267fbd0d43  lea r14, [rax+0xE4]
000074267fbd0d4a  mov r11d, [r13+r14*1]
000074267fbd0d4f  mov r14d, 0x430C28
000074267fbd0d55  mov [r13+r14*1], r10d
000074267fbd0d5a  mov r14d, 0x430C2C
000074267fbd0d60  mov [r13+r14*1], r9d
000074267fbd0d65  bswap r12d
000074267fbd0d68  bswap r11d
000074267fbd0d6b  mov [rsp+0x10], r11d
000074267fbd0d70  mov r11d, r11d
000074267fbd0d73  mov [r15+0x58], r11
000074267fbd0d77  lea r14, [rax+0xE8]
000074267fbd0d7e  mov r11d, [r13+r14*1]
000074267fbd0d83  lea r14, [rax+0xEC]
000074267fbd0d8a  mov eax, [r13+r14*1]
000074267fbd0d8f  mov [rsp+0x20], eax
000074267fbd0d93  mov eax, eax
000074267fbd0d95  mov [r15+0x60], rax
000074267fbd0d99  mov eax, 0x430C30
000074267fbd0d9e  mov [r13+rax*1], r12d
000074267fbd0da3  mov eax, 0x430C34
000074267fbd0da8  mov r14d, [rsp+0x10]
000074267fbd0dad  mov [r13+rax*1], r14d
000074267fbd0db2  bswap r11d
000074267fbd0db5  mov [rsp+0x10], r11d
000074267fbd0dba  mov r11d, r11d
000074267fbd0dbd  mov [r15+0x40], r11
000074267fbd0dc1  mov eax, [rsp+0x20]
000074267fbd0dc5  bswap eax
000074267fbd0dc7  mov [rsp+0x20], eax
000074267fbd0dcb  mov eax, eax
000074267fbd0dcd  mov [r15+0x50], rax
000074267fbd0dd1  mov eax, 0x430C38
000074267fbd0dd6  mov r14d, [rsp+0x10]
000074267fbd0ddb  mov [r13+rax*1], r14d
000074267fbd0de0  mov eax, 0x430C3C
000074267fbd0de5  mov r14d, [rsp+0x20]
000074267fbd0dea  mov [r13+rax*1], r14d
000074267fbd0def  mov eax, [r15+0xA0]
000074267fbd0df6  lea r14d, [eax+0x11]
000074267fbd0dfb  mov r14d, r14d
000074267fbd0dfe  mov [r15], r14
000074267fbd0e01  mov qword ptr [r15+0xF0], 0x41034C
000074267fbd0e0c  mov r14d, [r15+0x320]
000074267fbd0e13  mov eax, 0x41034C
000074267fbd0e18  mov rcx, 0x74267FBD0F90
000074267fbd0e22  mov [r15+r14*8+0x328], rax
000074267fbd0e2a  mov [r15+r14*8+0x368], rcx
000074267fbd0e32  add r14d, 0x01
000074267fbd0e36  and r14d, 0x07
000074267fbd0e3a  mov [r15+0x320], r14d
000074267fbd0e41  cmp dword ptr [r15+0x318], 0x00
000074267fbd0e49  jz 0x000074267FBD0F20
000074267fbd0e4f  nop [rax+rax*1], ax
000074267fbd0e58  nop [rax+rax*1], eax
000074267fbd0e60  mov eax, 0x410938
000074267fbd0e65  mov [r15+0x100], rax
000074267fbd0e6c  jmp 0x000074267F9FE110
000074267fbd0e71  int3
000074267fbd0e72  call 0x000074267FAE26A0
000074267fbd0e77  jmp 0x000074267FBD0CD3
000074267fbd0e7c  call 0x000074267FAE1430
000074267fbd0e81  jmp 0x000074267FBD0CDF
000074267fbd0e86  call 0x000074267FAE01C0
000074267fbd0e8b  jmp 0x000074267FBD0CEB
000074267fbd0e90  call 0x000074267FADEF50
000074267fbd0e95  jmp 0x000074267FBD0CF7
000074267fbd0e9a  call 0x000074267FAE2BA0
000074267fbd0e9f  jmp 0x000074267FBD0D26
000074267fbd0ea4  call 0x000074267FAE1920
000074267fbd0ea9  jmp 0x000074267FBD0D31
000074267fbd0eae  call 0x000074267FAE26A0
000074267fbd0eb3  jmp 0x000074267FBD0D43
000074267fbd0eb8  call 0x000074267FAE1430
000074267fbd0ebd  jmp 0x000074267FBD0D4F
000074267fbd0ec2  call 0x000074267FAE06B0
000074267fbd0ec7  jmp 0x000074267FBD0D5A
000074267fbd0ecc  call 0x000074267FADF440
000074267fbd0ed1  jmp 0x000074267FBD0D65
000074267fbd0ed6  call 0x000074267FAE1430
000074267fbd0edb  jmp 0x000074267FBD0D83
000074267fbd0ee0  call 0x000074267FAD5890
000074267fbd0ee5  jmp 0x000074267FBD0D8F
000074267fbd0eea  call 0x000074267FA0BAE0
000074267fbd0eef  jmp 0x000074267FBD0DA3
000074267fbd0ef4  call 0x000074267FA0DFE0
000074267fbd0ef9  jmp 0x000074267FBD0DB2
000074267fbd0efe  call 0x000074267FA0DFE0
000074267fbd0f03  jmp 0x000074267FBD0DE0
000074267fbd0f08  call 0x000074267FA0DFE0
000074267fbd0f0d  jmp 0x000074267FBD0DEF
000074267fbd0f12  int3
000074267fbd0f13  nop [rax+rax*1], ax
000074267fbd0f1c  nop [rax], eax
000074267fbd0f20  mov eax, [r15]
000074267fbd0f23  mov [rsp+0x10], eax
000074267fbd0f27  shr eax, 0x10
000074267fbd0f2a  mov r14d, [rsp+0x10]
000074267fbd0f2f  xor r14d, eax
000074267fbd0f32  imul r14d, r14d, 0x7FEB352D
000074267fbd0f39  mov eax, 0x846CA68B
000074267fbd0f3e  mov eax, eax
000074267fbd0f40  mov [r15+0x48], rax
000074267fbd0f44  mov [rsp+0x10], r14d
000074267fbd0f49  shr r14d, 0x0F
000074267fbd0f4d  mov eax, [rsp+0x10]
000074267fbd0f51  xor eax, r14d
000074267fbd0f54  imul eax, eax, 0x846CA68B
000074267fbd0f5a  mov [rsp+0x10], eax
000074267fbd0f5e  mov eax, eax
000074267fbd0f60  mov [r15+0x40], rax
000074267fbd0f64  mov eax, [rsp+0x10]
000074267fbd0f68  shr eax, 0x10
000074267fbd0f6b  mov r14d, [rsp+0x10]
000074267fbd0f70  xor r14d, eax
000074267fbd0f73  mov r14d, r14d
000074267fbd0f76  mov [r15], r14
000074267fbd0f79  mov rax, [r15+0xF0]
000074267fbd0f80  mov [r15+0x100], rax
000074267fbd0f87  jmp 0x000074267FBCE5C0
000074267fbd0f8c  int3
000074267fbd0f8d  int3
000074267fbd0f8e  nop
000074267fbd0f90  mov rax, [r15+0xA0]
000074267fbd0f97  mov [rsp+0x10], rax
000074267fbd0f9c  shl rax, 0x02
000074267fbd0fa0  mov r14, [r15+0x98]
000074267fbd0fa7  lea r12, [r14+rax*1]
000074267fbd0fab  mov eax, [r15]
000074267fbd0fae  mov [r13+r12*1], eax
000074267fbd0fb3  mov rax, [rsp+0x10]
000074267fbd0fb8  lea r14, [rax+0x01]
000074267fbd0fbc  mov [r15+0xA0], r14
000074267fbd0fc3  xor eax, eax
000074267fbd0fc5  mov r12d, 0x400
000074267fbd0fcb  cmp r14, r12
000074267fbd0fce  cmc
000074267fbd0fcf  lahf
000074267fbd0fd0  seto al
000074267fbd0fd3  mov [r15+0x108], eax
000074267fbd0fda  mov eax, [r15+0x108]
000074267fbd0fe1  sahf
000074267fbd0fe2  jnz 0x000074267FBD1014
000074267fbd0fe4  cmp dword ptr [r15+0x318], 0x00
000074267fbd0fec  jz 0x000074267FBD10E0
000074267fbd0ff2  nop [rax+rax*1], ax
000074267fbd0ffb  nop [rax+rax*1], eax
000074267fbd1003  mov eax, 0x41035C
000074267fbd1008  mov [r15+0x100], rax
000074267fbd100f  jmp 0x000074267F9FE110
000074267fbd1014  cmp dword ptr [r15+0x318], 0x00
000074267fbd101c  jz 0x000074267FBD1050
000074267fbd1022  nop [rax+rax*1], ax
000074267fbd102b  nop [rax+rax*1], eax
000074267fbd1033  mov eax, 0x410344
000074267fbd1038  mov [r15+0x100], rax
000074267fbd103f  jmp 0x000074267F9FE110
000074267fbd1044  int3
000074267fbd1045  call 0x000074267FAB4B70
000074267fbd104a  jmp 0x000074267FBD0FB3
000074267fbd104f  int3
000074267fbd1050  mov eax, [r15+0xA0]
000074267fbd1057  lea r14d, [eax+0x11]
000074267fbd105c  mov r14d, r14d
000074267fbd105f  mov [r15], r14
000074267fbd1062  mov qword ptr [r15+0xF0], 0x41034C
000074267fbd106d  mov r14d, [r15+0x320]
000074267fbd1074  mov eax, 0x41034C
000074267fbd1079  mov rcx, 0x74267FBD0F90
000074267fbd1083  mov [r15+r14*8+0x328], rax
000074267fbd108b  mov [r15+r14*8+0x368], rcx
000074267fbd1093  add r14d, 0x01
000074267fbd1097  and r14d, 0x07
000074267fbd109b  mov [r15+0x320], r14d
000074267fbd10a2  cmp dword ptr [r15+0x318], 0x00
000074267fbd10aa  jz 0x000074267FBD0F20
000074267fbd10b0  nop [rax+rax*1], ax
000074267fbd10b9  nop [rax+rax*1], eax
000074267fbd10c1  mov eax, 0x410938
000074267fbd10c6  mov [r15+0x100], rax
000074267fbd10cd  jmp 0x000074267F9FE110
000074267fbd10d2  int3
000074267fbd10d3  int3
000074267fbd10d4  nop [rax+rax*1], ax
000074267fbd10dd  nop [rax], eax
000074267fbd10e0  mov qword ptr [r15+0x40], 0x01
000074267fbd10e8  cmp dword ptr [r15+0x318], 0x00
000074267fbd10f0  jz 0x000074267FBD1120
000074267fbd10f6  nop [rax+rax*1], ax
000074267fbd10ff  nop [rax+rax*1], eax
000074267fbd1107  mov eax, 0x410378
000074267fbd110c  mov [r15+0x100], rax
000074267fbd1113  jmp 0x000074267F9FE110
000074267fbd1118  int3
000074267fbd1119  int3
000074267fbd111a  nop [rax+rax*1], ax
000074267fbd1120  mov rax, [r15+0x40]
000074267fbd1124  mov [rsp+0x10], rax
000074267fbd1129  shl rax, 0x02
000074267fbd112d  mov r14, [r15+0x98]
000074267fbd1134  lea r12, [r14+rax*1]
000074267fbd1138  mov eax, [r13+r12*1]
000074267fbd113d  mov [rsp+0x20], eax
000074267fbd1141  mov eax, eax
000074267fbd1143  mov [r15+0x48], rax
000074267fbd1147  mov rax, [rsp+0x10]
000074267fbd114c  mov [r15+0x50], rax
000074267fbd1150  mov eax, [r15+0x50]
000074267fbd1154  lea r12d, [eax-0x01]
000074267fbd1159  mov r12d, r12d
000074267fbd115c  mov [r15+0x58], r12
000074267fbd1160  mov rax, [r15+0x58]
000074267fbd1164  mov r12d, eax
000074267fbd1167  mov r12d, r12d
000074267fbd116a  shl r12, 0x02
000074267fbd116e  lea rax, [r14+r12*1]
000074267fbd1172  mov r14d, [r13+rax*1]
000074267fbd1177  mov [rsp+0x10], r14d
000074267fbd117c  mov r14d, r14d
000074267fbd117f  mov [r15+0x60], r14
000074267fbd1183  xor eax, eax
000074267fbd1185  mov r14d, [rsp+0x10]
000074267fbd118a  mov r12d, [rsp+0x20]
000074267fbd118f  cmp r14d, r12d
000074267fbd1192  cmc
000074267fbd1193  lahf
000074267fbd1194  seto al
000074267fbd1197  mov [r15+0x108], eax
000074267fbd119e  mov eax, [r15+0x108]
000074267fbd11a5  sahf
000074267fbd11a6  cmc
000074267fbd11a7  jbe 0x000074267FBD11D9
000074267fbd11a9  cmp dword ptr [r15+0x318], 0x00
000074267fbd11b1  jz 0x000074267FBD1220
000074267fbd11b7  nop [rax+rax*1], ax
000074267fbd11c0  nop [rax+rax*1], eax
000074267fbd11c8  mov eax, 0x410390
000074267fbd11cd  mov [r15+0x100], rax
000074267fbd11d4  jmp 0x000074267F9FE110
000074267fbd11d9  cmp dword ptr [r15+0x318], 0x00
000074267fbd11e1  jz 0x000074267FBD14C0
000074267fbd11e7  nop [rax+rax*1], ax
000074267fbd11f0  nop [rax+rax*1], eax
000074267fbd11f8  mov eax, 0x410368
000074267fbd11fd  mov [r15+0x100], rax
000074267fbd1204  jmp 0x000074267F9FE110
000074267fbd1209  int3
000074267fbd120a  call 0x000074267FAB4690
000074267fbd120f  jmp 0x000074267FBD113D
000074267fbd1214  call 0x000074267FA0DAE0
000074267fbd1219  jmp 0x000074267FBD1177
000074267fbd121e  int3
000074267fbd121f  nop
000074267fbd1220  mov rax, [r15+0x50]
000074267fbd1224  mov [rsp+0x10], rax
000074267fbd1229  shl rax, 0x02
000074267fbd122d  mov r14, [r15+0x98]
000074267fbd1234  lea r12, [r14+rax*1]
000074267fbd1238  mov eax, [r15+0x60]
000074267fbd123c  mov [r13+r12*1], eax
000074267fbd1241  mov rax, [rsp+0x10]
000074267fbd1246  lea r14, [rax-0x01]
000074267fbd124a  mov [r15+0x50], r14
000074267fbd124e  mov rax, [r15+0x58]
000074267fbd1252  test rax, rax
000074267fbd1255  setz al
000074267fbd1258  movzx rax, al
000074267fbd125c  mov [rsp+0x414], al
000074267fbd1263  cmp byte ptr [rsp+0x414], 0x00
000074267fbd126b  jz 0x000074267FBD129D
000074267fbd126d  cmp dword ptr [r15+0x318], 0x00
000074267fbd1275  jz 0x000074267FBD12E0
000074267fbd127b  nop [rax+rax*1], ax
000074267fbd1284  nop [rax+rax*1], eax
000074267fbd128c  mov eax, 0x41039C
000074267fbd1291  mov [r15+0x100], rax
000074267fbd1298  jmp 0x000074267F9FE110
000074267fbd129d  cmp dword ptr [r15+0x318], 0x00
000074267fbd12a5  jz 0x000074267FBD13E0
000074267fbd12ab  nop [rax+rax*1], ax
000074267fbd12b4  nop [rax+rax*1], eax
000074267fbd12bc  mov eax, 0x410380
000074267fbd12c1  mov [r15+0x100], rax
000074267fbd12c8  jmp 0x000074267F9FE110
000074267fbd12cd  int3
000074267fbd12ce  call 0x000074267FAB4B70
000074267fbd12d3  jmp 0x000074267FBD1241
000074267fbd12d8  int3
000074267fbd12d9  nop [rax], eax
000074267fbd12e0  cmp dword ptr [r15+0x318], 0x00
000074267fbd12e8  jz 0x000074267FBD1320
000074267fbd12ee  nop [rax+rax*1], ax
000074267fbd12f7  nop [rax+rax*1], eax
000074267fbd12ff  mov eax, 0x410364
000074267fbd1304  mov [r15+0x100], rax
000074267fbd130b  jmp 0x000074267F9FE110
000074267fbd1310  int3
000074267fbd1311  int3
000074267fbd1312  nop [rax+rax*1], ax
000074267fbd131b  nop [rax+rax*1], eax
000074267fbd1320  mov qword ptr [r15+0x50], 0x00
000074267fbd1328  mov rax, [r15+0x40]
000074267fbd132c  lea r14, [rax+0x01]
000074267fbd1330  mov [r15+0x40], r14
000074267fbd1334  mov rax, [r15+0x98]
000074267fbd133b  mov r12d, [r15+0x48]
000074267fbd133f  mov [r13+rax*1], r12d
000074267fbd1344  xor eax, eax
000074267fbd1346  mov r12d, 0x400
000074267fbd134c  cmp r14, r12
000074267fbd134f  cmc
000074267fbd1350  lahf
000074267fbd1351  seto al
000074267fbd1354  mov [r15+0x108], eax
000074267fbd135b  mov eax, [r15+0x108]
000074267fbd1362  sahf
000074267fbd1363  jz 0x000074267FBD1395
000074267fbd1365  cmp dword ptr [r15+0x318], 0x00
000074267fbd136d  jz 0x000074267FBD1120
000074267fbd1373  nop [rax+rax*1], ax
000074267fbd137c  nop [rax+rax*1], eax
000074267fbd1384  mov eax, 0x410378
000074267fbd1389  mov [r15+0x100], rax
000074267fbd1390  jmp 0x000074267F9FE110
000074267fbd1395  cmp dword ptr [r15+0x318], 0x00
000074267fbd139d  jz 0x000074267FBD1580
000074267fbd13a3  nop [rax+rax*1], ax
000074267fbd13ac  nop [rax+rax*1], eax
000074267fbd13b4  mov eax, 0x4103A0
000074267fbd13b9  mov [r15+0x100], rax
000074267fbd13c0  jmp 0x000074267F9FE110
000074267fbd13c5  int3
000074267fbd13c6  call 0x000074267FA0BAE0
000074267fbd13cb  jmp 0x000074267FBD1344
000074267fbd13d0  int3
000074267fbd13d1  nop [rax+rax*1], ax
000074267fbd13da  nop [rax+rax*1], ax
000074267fbd13e0  mov eax, [r15+0x50]
000074267fbd13e4  lea r14d, [eax-0x01]
000074267fbd13e9  mov r14d, r14d
000074267fbd13ec  mov [r15+0x58], r14
000074267fbd13f0  mov rax, [r15+0x58]
000074267fbd13f4  mov r14d, eax
000074267fbd13f7  mov r14d, r14d
000074267fbd13fa  shl r14, 0x02
000074267fbd13fe  mov rax, [r15+0x98]
000074267fbd1405  lea r12, [rax+r14*1]
000074267fbd1409  mov eax, [r13+r12*1]
000074267fbd140e  mov [rsp+0x10], eax
000074267fbd1412  mov eax, eax
000074267fbd1414  mov [r15+0x60], rax
000074267fbd1418  mov eax, [r15+0x48]
000074267fbd141c  mov [rsp+0x20], eax
000074267fbd1420  xor eax, eax
000074267fbd1422  mov r14d, [rsp+0x10]
000074267fbd1427  mov r12d, [rsp+0x20]
000074267fbd142c  cmp r14d, r12d
000074267fbd142f  cmc
000074267fbd1430  lahf
000074267fbd1431  seto al
000074267fbd1434  mov [r15+0x108], eax
000074267fbd143b  mov eax, [r15+0x108]
000074267fbd1442  sahf
000074267fbd1443  cmc
000074267fbd1444  jbe 0x000074267FBD1476
000074267fbd1446  cmp dword ptr [r15+0x318], 0x00
000074267fbd144e  jz 0x000074267FBD1220
000074267fbd1454  nop [rax+rax*1], ax
000074267fbd145d  nop [rax+rax*1], eax
000074267fbd1465  mov eax, 0x410390
000074267fbd146a  mov [r15+0x100], rax
000074267fbd1471  jmp 0x000074267F9FE110
000074267fbd1476  cmp dword ptr [r15+0x318], 0x00
000074267fbd147e  jz 0x000074267FBD14C0
000074267fbd1484  nop [rax+rax*1], ax
000074267fbd148d  nop [rax+rax*1], eax
000074267fbd1495  mov eax, 0x410368
000074267fbd149a  mov [r15+0x100], rax
000074267fbd14a1  jmp 0x000074267F9FE110
000074267fbd14a6  int3
000074267fbd14a7  call 0x000074267FAB4690
000074267fbd14ac  jmp 0x000074267FBD140E
000074267fbd14b1  int3
000074267fbd14b2  nop [rax+rax*1], ax
000074267fbd14bb  nop [rax+rax*1], eax
000074267fbd14c0  mov rax, [r15+0x40]
000074267fbd14c4  lea r14, [rax+0x01]
000074267fbd14c8  mov [r15+0x40], r14
000074267fbd14cc  mov rax, [r15+0x50]
000074267fbd14d0  mov r12d, eax
000074267fbd14d3  mov r12d, r12d
000074267fbd14d6  shl r12, 0x02
000074267fbd14da  mov rax, [r15+0x98]
000074267fbd14e1  lea r11, [rax+r12*1]
000074267fbd14e5  mov eax, [r15+0x48]
000074267fbd14e9  mov [r13+r11*1], eax
000074267fbd14ee  xor eax, eax
000074267fbd14f0  mov r12d, 0x400
000074267fbd14f6  cmp r14, r12
000074267fbd14f9  cmc
000074267fbd14fa  lahf
000074267fbd14fb  seto al
000074267fbd14fe  mov [r15+0x108], eax
000074267fbd1505  mov eax, [r15+0x108]
000074267fbd150c  sahf
000074267fbd150d  jz 0x000074267FBD153F
000074267fbd150f  cmp dword ptr [r15+0x318], 0x00
000074267fbd1517  jz 0x000074267FBD1120
000074267fbd151d  nop [rax+rax*1], ax
000074267fbd1526  nop [rax+rax*1], eax
000074267fbd152e  mov eax, 0x410378
000074267fbd1533  mov [r15+0x100], rax
000074267fbd153a  jmp 0x000074267F9FE110
000074267fbd153f  cmp dword ptr [r15+0x318], 0x00
000074267fbd1547  jz 0x000074267FBD1580
000074267fbd154d  nop [rax+rax*1], ax
000074267fbd1556  nop [rax+rax*1], eax
000074267fbd155e  mov eax, 0x4103A0
000074267fbd1563  mov [r15+0x100], rax
000074267fbd156a  jmp 0x000074267F9FE110
000074267fbd156f  int3
000074267fbd1570  call 0x000074267FAA4270
000074267fbd1575  jmp 0x000074267FBD14EE
000074267fbd157a  int3
000074267fbd157b  nop [rax+rax*1], eax
000074267fbd1580  mov qword ptr [r15+0x40], 0x430000
000074267fbd1588  mov eax, 0x430C40
000074267fbd158d  mov r14, [r13+rax*1]
000074267fbd1592  mov rax, [r15+0x98]
000074267fbd1599  mov r12d, [r13+rax*1]
000074267fbd159e  lea r11, [rax+0x04]
000074267fbd15a2  mov eax, [r13+r11*1]
000074267fbd15a7  mov r12d, r12d
000074267fbd15aa  mov [r15+0x68], r12
000074267fbd15ae  mov eax, eax
000074267fbd15b0  mov [r15+0x60], rax
000074267fbd15b4  mov rax, [r15+0x68]
000074267fbd15b8  mov [r15+0x68], rax
000074267fbd15bc  mov qword ptr [r15+0x58], 0x02
000074267fbd15c4  mov [rsp+0x10], rax
000074267fbd15c9  xor eax, eax
000074267fbd15cb  mov r12d, 0x02
000074267fbd15d1  mov r11d, 0x400
000074267fbd15d7  cmp r12, r11
000074267fbd15da  cmc
000074267fbd15db  lahf
000074267fbd15dc  seto al
000074267fbd15df  mov [r15+0x108], eax
000074267fbd15e6  mov rax, [r15+0x60]
000074267fbd15ea  mov r12d, 0x02
000074267fbd15f0  imul rax, r12
000074267fbd15f4  mov [r15+0x50], rax
000074267fbd15f8  mov rax, [rsp+0x10]
000074267fbd15fd  lea r12, [rax+r14*1]
000074267fbd1601  mov [r15+0x48], r12
000074267fbd1605  mov eax, [r15+0x108]
000074267fbd160c  sahf
000074267fbd160d  jnz 0x000074267FBD163F
000074267fbd160f  cmp dword ptr [r15+0x318], 0x00
000074267fbd1617  jz 0x000074267FBD17B0
000074267fbd161d  nop [rax+rax*1], ax
000074267fbd1626  nop [rax+rax*1], eax
000074267fbd162e  mov eax, 0x4103D0
000074267fbd1633  mov [r15+0x100], rax
000074267fbd163a  jmp 0x000074267F9FE110
000074267fbd163f  cmp dword ptr [r15+0x318], 0x00
000074267fbd1647  jz 0x000074267FBD1690
000074267fbd164d  nop [rax+rax*1], ax
000074267fbd1656  nop [rax+rax*1], eax
000074267fbd165e  mov eax, 0x4103B0
000074267fbd1663  mov [r15+0x100], rax
000074267fbd166a  jmp 0x000074267F9FE110
000074267fbd166f  int3
000074267fbd1670  call 0x000074267FA0DC20
000074267fbd1675  jmp 0x000074267FBD1592
000074267fbd167a  call 0x000074267FA0B5E0
000074267fbd167f  jmp 0x000074267FBD159E
000074267fbd1684  call 0x000074267FAA3D90
000074267fbd1689  jmp 0x000074267FBD15A7
000074267fbd168e  int3
000074267fbd168f  nop
000074267fbd1690  mov rax, [r15+0x98]
000074267fbd1697  mov r14, [r15+0x58]
000074267fbd169b  mov [rsp+0x10], r14
000074267fbd16a0  shl r14, 0x02
000074267fbd16a4  lea r12, [rax+r14*1]
000074267fbd16a8  mov eax, [r13+r12*1]
000074267fbd16ad  lea r14, [r12+0x04]
000074267fbd16b2  mov r12d, [r13+r14*1]
000074267fbd16b7  mov eax, eax
000074267fbd16b9  mov [r15+0x68], rax
000074267fbd16bd  mov r12d, r12d
000074267fbd16c0  mov [r15+0x60], r12
000074267fbd16c4  mov rax, [r15+0x68]
000074267fbd16c8  mov [rsp+0x20], rax
000074267fbd16cd  mov r14, [rsp+0x10]
000074267fbd16d2  imul rax, r14
000074267fbd16d6  mov r12, [rsp+0x20]
000074267fbd16db  lea r11, [r12+rax*1]
000074267fbd16df  mov [r15+0x68], r11
000074267fbd16e3  lea rax, [r14+0x02]
000074267fbd16e7  mov [r15+0x58], rax
000074267fbd16eb  mov [rsp+0x10], rax
000074267fbd16f0  xor eax, eax
000074267fbd16f2  mov r14, [rsp+0x10]
000074267fbd16f7  mov r12d, 0x400
000074267fbd16fd  cmp r14, r12
000074267fbd1700  cmc
000074267fbd1701  lahf
000074267fbd1702  seto al
000074267fbd1705  mov [r15+0x108], eax
000074267fbd170c  mov rax, [r15+0x50]
000074267fbd1710  mov r12, [r15+0x60]
000074267fbd1714  imul r14, r12
000074267fbd1718  lea r12, [rax+r14*1]
000074267fbd171c  mov [r15+0x50], r12
000074267fbd1720  mov rax, [r15+0x48]
000074267fbd1724  lea r14, [r11+rax*1]
000074267fbd1728  mov [r15+0x48], r14
000074267fbd172c  mov eax, [r15+0x108]
000074267fbd1733  sahf
000074267fbd1734  jnz 0x000074267FBD1766
000074267fbd1736  cmp dword ptr [r15+0x318], 0x00
000074267fbd173e  jz 0x000074267FBD17B0
000074267fbd1744  nop [rax+rax*1], ax
000074267fbd174d  nop [rax+rax*1], eax
000074267fbd1755  mov eax, 0x4103D0
000074267fbd175a  mov [r15+0x100], rax
000074267fbd1761  jmp 0x000074267F9FE110
000074267fbd1766  cmp dword ptr [r15+0x318], 0x00
000074267fbd176e  jz 0x000074267FBD1690
000074267fbd1774  nop [rax+rax*1], ax
000074267fbd177d  nop [rax+rax*1], eax
000074267fbd1785  mov eax, 0x4103B0
000074267fbd178a  mov [r15+0x100], rax
000074267fbd1791  jmp 0x000074267F9FE110
000074267fbd1796  int3
000074267fbd1797  call 0x000074267FAB4690
000074267fbd179c  jmp 0x000074267FBD16AD
000074267fbd17a1  call 0x000074267FAE26A0
000074267fbd17a6  jmp 0x000074267FBD16B7
000074267fbd17ab  int3
000074267fbd17ac  nop [rax], eax
000074267fbd17b0  mov qword ptr [r15+0x98], 0x00
000074267fbd17bb  mov rax, [r15+0x50]
000074267fbd17bf  mov r14, [r15+0x48]
000074267fbd17c3  lea r12, [rax+r14*1]
000074267fbd17c7  mov [r15+0x48], r12
000074267fbd17cb  mov rax, [r15+0x40]
000074267fbd17cf  lea r14, [rax+0xC40]
000074267fbd17d6  mov [r13+r14*1], r12
000074267fbd17db  mov qword ptr [r15], 0x01
000074267fbd17e2  mov qword ptr [r15+0xF0], 0x4103E8
000074267fbd17ed  mov r14d, [r15+0x320]
000074267fbd17f4  mov eax, 0x4103E8
000074267fbd17f9  mov rcx, 0x74267FBD1860
000074267fbd1803  mov [r15+r14*8+0x328], rax
000074267fbd180b  mov [r15+r14*8+0x368], rcx
000074267fbd1813  add r14d, 0x01
000074267fbd1817  and r14d, 0x07
000074267fbd181b  mov [r15+0x320], r14d
000074267fbd1822  cmp dword ptr [r15+0x318], 0x00
000074267fbd182a  jz 0x000074267FBD0F20
000074267fbd1830  nop [rax+rax*1], ax
000074267fbd1839  nop [rax+rax*1], eax
000074267fbd1841  mov eax, 0x410938
000074267fbd1846  mov [r15+0x100], rax
000074267fbd184d  jmp 0x000074267F9FE110
000074267fbd1852  int3
000074267fbd1853  call 0x000074267FAE2CE0
000074267fbd1858  jmp 0x000074267FBD17DB
000074267fbd185d  int3
000074267fbd185e  nop
000074267fbd1860  mov eax, [r15+0x98]
000074267fbd1867  lea r14d, [eax+0x01]
000074267fbd186c  mov [rsp+0x10], r14d
000074267fbd1871  mov r14d, r14d
000074267fbd1874  mov [r15+0x98], r14
000074267fbd187b  xor eax, eax
000074267fbd187d  mov r14d, [rsp+0x10]
000074267fbd1882  cmp r14d, 0x10000
000074267fbd1889  cmc
000074267fbd188a  lahf
000074267fbd188b  seto al
000074267fbd188e  mov [r15+0x108], eax
000074267fbd1895  mov eax, [r15+0x108]
000074267fbd189c  sahf
000074267fbd189d  jnz 0x000074267FBD18CF
000074267fbd189f  cmp dword ptr [r15+0x318], 0x00
000074267fbd18a7  jz 0x000074267FBD19A0
000074267fbd18ad  nop [rax+rax*1], ax
000074267fbd18b6  nop [rax+rax*1], eax
000074267fbd18be  mov eax, 0x4103F4
000074267fbd18c3  mov [r15+0x100], rax
000074267fbd18ca  jmp 0x000074267F9FE110
000074267fbd18cf  cmp dword ptr [r15+0x318], 0x00
000074267fbd18d7  jz 0x000074267FBD1910
000074267fbd18dd  nop [rax+rax*1], ax
000074267fbd18e6  nop [rax+rax*1], eax
000074267fbd18ee  mov eax, 0x4103E0
000074267fbd18f3  mov [r15+0x100], rax
000074267fbd18fa  jmp 0x000074267F9FE110
000074267fbd18ff  int3
000074267fbd1900  int3
000074267fbd1901  nop [rax+rax*1], ax
000074267fbd190a  nop [rax+rax*1], ax
000074267fbd1910  mov eax, [r15]
000074267fbd1913  mov r14d, [r15+0x98]
000074267fbd191a  lea r12d, [eax+r14d*1]
000074267fbd191f  mov r12d, r12d
000074267fbd1922  mov [r15], r12
000074267fbd1925  mov qword ptr [r15+0xF0], 0x4103E8
000074267fbd1930  mov r14d, [r15+0x320]
000074267fbd1937  mov eax, 0x4103E8
000074267fbd193c  mov rcx, 0x74267FBD1860
000074267fbd1946  mov [r15+r14*8+0x328], rax
000074267fbd194e  mov [r15+r14*8+0x368], rcx
000074267fbd1956  add r14d, 0x01
000074267fbd195a  and r14d, 0x07
000074267fbd195e  mov [r15+0x320], r14d
000074267fbd1965  cmp dword ptr [r15+0x318], 0x00
000074267fbd196d  jz 0x000074267FBD0F20
000074267fbd1973  nop [rax+rax*1], ax
000074267fbd197c  nop [rax+rax*1], eax
000074267fbd1984  mov eax, 0x410938
000074267fbd1989  mov [r15+0x100], rax
000074267fbd1990  jmp 0x000074267F9FE110
000074267fbd1995  int3
000074267fbd1996  int3
000074267fbd1997  nop [rax+rax*1], ax
000074267fbd19a0  vmovaps xmm1, [0x000074267F7FE010]
000074267fbd19a8  movq xmm1, xmm1
000074267fbd19ac  movaps [r15+0x110], xmm1
000074267fbd19b4  mov eax, 0x420AA0
000074267fbd19b9  mov r14, [r13+rax*1]
000074267fbd19be  movq xmm1, r14
000074267fbd19c3  movaps [r15+0x120], xmm1
000074267fbd19cb  vmovaps xmm1, [0x000074267F7FE020]
000074267fbd19d3  movq xmm1, xmm1
000074267fbd19d7  movaps [r15+0x140], xmm1
000074267fbd19df  vmovaps xmm1, [0x000074267F7FE030]
000074267fbd19e7  vpbroadcastq xmm1, xmm1
000074267fbd19ec  movaps [r15+0x150], xmm1
000074267fbd19f4  mov qword ptr [r15+0x40], 0x02
000074267fbd19fc  vmovaps xmm15, [0x000074267F7FE040]
000074267fbd1a04  movq xmm15, xmm15
000074267fbd1a09  movaps [r15+0x160], xmm15
000074267fbd1a11  vmovaps xmm15, [0x000074267F7FE050]
000074267fbd1a19  vpbroadcastq xmm15, xmm15
000074267fbd1a1e  movaps [r15+0x130], xmm15
000074267fbd1a26  mov rax, [r15+0x40]
000074267fbd1a2a  vmovq xmm14, rax
000074267fbd1a2f  vpbroadcastq xmm14, xmm14
000074267fbd1a34  movaps [r15+0x170], xmm14
000074267fbd1a3c  mov eax, 0x4209D0
000074267fbd1a41  movups xmm13, [r13+rax*1]
000074267fbd1a47  mov qword ptr [r15+0x40], 0x431D90
000074267fbd1a4f  mov eax, [r15]
000074267fbd1a52  mov r14d, 0x430C48
000074267fbd1a58  mov [r13+r14*1], eax
000074267fbd1a5d  mov qword ptr [r15+0x50], 0x431F90
000074267fbd1a65  vpmovqd xmm12, xmm13
000074267fbd1a6b  pxor xmm11, xmm11
000074267fbd1a70  punpcklqdq xmm12, xmm11
000074267fbd1a75  movaps [r15+0x210], xmm12
000074267fbd1a7d  movq xmm12, qword ptr [r15+0x140]
000074267fbd1a86  movq xmm11, qword ptr [r15+0x120]
000074267fbd1a8f  psubd xmm12, xmm11
000074267fbd1a94  movq xmm12, xmm12
000074267fbd1a99  paddq xmm13, xmm14
000074267fbd1a9e  movaps [r15+0x180], xmm13
000074267fbd1aa6  movq xmm14, qword ptr [r15+0x160]
000074267fbd1aaf  paddd xmm11, xmm14
000074267fbd1ab4  movq xmm11, xmm11
000074267fbd1ab9  movq xmm11, xmm11
000074267fbd1abe  movaps [r15+0x120], xmm11
000074267fbd1ac6  pmovzxdq xmm12, xmm12
000074267fbd1acc  psllq xmm12, 0x00
000074267fbd1ad2  movq xmm14, qword ptr [r15+0x210]
000074267fbd1adb  movq xmm13, qword ptr [r15+0x110]
000074267fbd1ae4  paddd xmm14, xmm13
000074267fbd1ae9  movq xmm14, xmm14
000074267fbd1aee  vcvtuqq2pd xmm12, xmm12
000074267fbd1af4  pmovzxdq xmm14, xmm14
000074267fbd1afa  psllq xmm14, 0x00
000074267fbd1b00  vcvtuqq2pd xmm14, xmm14
000074267fbd1b06  movaps xmm13, xmm12
000074267fbd1b0a  mulpd xmm13, xmm1
000074267fbd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000074267fbd1b15  ptest xmm11, xmm11
000074267fbd1b1b  jnz 0x000074267FBD1C0F
000074267fbd1b21  movaps [r15+0x220], xmm13
000074267fbd1b29  mov eax, 0x431F90
000074267fbd1b2e  movups [r13+rax*1], xmm13
000074267fbd1b34  movaps xmm1, xmm14
000074267fbd1b38  mulpd xmm1, xmm15
000074267fbd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000074267fbd1b42  ptest xmm13, xmm13
000074267fbd1b48  jnz 0x000074267FBD1D5C
000074267fbd1b4e  movaps [r15+0x210], xmm1
000074267fbd1b56  mov eax, 0x431D90
000074267fbd1b5b  movups [r13+rax*1], xmm1
000074267fbd1b61  mov qword ptr [r15+0x48], 0x10
000074267fbd1b69  xor eax, eax
000074267fbd1b6b  mov r14d, 0x10
000074267fbd1b71  mov r12d, 0x200
000074267fbd1b77  cmp r14, r12
000074267fbd1b7a  cmc
000074267fbd1b7b  lahf
000074267fbd1b7c  seto al
000074267fbd1b7f  mov [r15+0x108], eax
000074267fbd1b86  mov eax, [r15+0x108]
000074267fbd1b8d  sahf
000074267fbd1b8e  jnz 0x000074267FBD1BC0
000074267fbd1b90  cmp dword ptr [r15+0x318], 0x00
000074267fbd1b98  jz 0x000074267FBD2300
000074267fbd1b9e  nop [rax+rax*1], ax
000074267fbd1ba7  nop [rax+rax*1], eax
000074267fbd1baf  mov eax, 0x410480
000074267fbd1bb4  mov [r15+0x100], rax
000074267fbd1bbb  jmp 0x000074267F9FE110
000074267fbd1bc0  cmp dword ptr [r15+0x318], 0x00
000074267fbd1bc8  jz 0x000074267FBD1EB0
000074267fbd1bce  nop [rax+rax*1], ax
000074267fbd1bd7  nop [rax+rax*1], eax
000074267fbd1bdf  mov eax, 0x410440
000074267fbd1be4  mov [r15+0x100], rax
000074267fbd1beb  jmp 0x000074267F9FE110
000074267fbd1bf0  int3
000074267fbd1bf1  call 0x000074267FA0DC20
000074267fbd1bf6  jmp 0x000074267FBD19BE
000074267fbd1bfb  call 0x000074267FA0C260
000074267fbd1c00  jmp 0x000074267FBD1A47
000074267fbd1c05  call 0x000074267FAD5D70
000074267fbd1c0a  jmp 0x000074267FBD1A5D
000074267fbd1c0f  sub rsp, 0x08
000074267fbd1c13  push rax
000074267fbd1c14  push rcx
000074267fbd1c15  push rdx
000074267fbd1c16  push rdi
000074267fbd1c17  push rsi
000074267fbd1c18  push r8
000074267fbd1c1a  push r9
000074267fbd1c1c  push r10
000074267fbd1c1e  push r11
000074267fbd1c20  sub rsp, 0xF0
000074267fbd1c27  vmovaps [rsp], xmm0
000074267fbd1c2c  vmovaps [rsp+0x10], xmm1
000074267fbd1c32  vmovaps [rsp+0x20], xmm2
000074267fbd1c38  vmovaps [rsp+0x30], xmm3
000074267fbd1c3e  vmovaps [rsp+0x40], xmm4
000074267fbd1c44  vmovaps [rsp+0x50], xmm5
000074267fbd1c4a  vmovaps [rsp+0x60], xmm6
000074267fbd1c50  vmovaps [rsp+0x70], xmm7
000074267fbd1c56  vmovaps [rsp+0x80], xmm8
000074267fbd1c5f  vmovaps [rsp+0x90], xmm9
000074267fbd1c68  vmovaps [rsp+0xA0], xmm10
000074267fbd1c71  vmovaps [rsp+0xB0], xmm11
000074267fbd1c7a  vmovaps [rsp+0xC0], xmm12
000074267fbd1c83  vmovaps [rsp+0xD0], xmm14
000074267fbd1c8c  vmovaps [rsp+0xE0], xmm15
000074267fbd1c95  sub rsp, 0x30
000074267fbd1c99  movaps [rsp], xmm13
000074267fbd1c9e  movaps [rsp+0x10], xmm12
000074267fbd1ca4  movaps [rsp+0x20], xmm1
000074267fbd1ca9  lea rdi, [rsp]
000074267fbd1cad  mov esi, 0x00
000074267fbd1cb2  mov rax, 0x56D4E47AE530
000074267fbd1cbc  call rax
000074267fbd1cbe  movaps xmm13, [rsp]
000074267fbd1cc3  add rsp, 0x30
000074267fbd1cc7  vmovaps xmm0, [rsp]
000074267fbd1ccc  vmovaps xmm1, [rsp+0x10]
000074267fbd1cd2  vmovaps xmm2, [rsp+0x20]
000074267fbd1cd8  vmovaps xmm3, [rsp+0x30]
000074267fbd1cde  vmovaps xmm4, [rsp+0x40]
000074267fbd1ce4  vmovaps xmm5, [rsp+0x50]
000074267fbd1cea  vmovaps xmm6, [rsp+0x60]
000074267fbd1cf0  vmovaps xmm7, [rsp+0x70]
000074267fbd1cf6  vmovaps xmm8, [rsp+0x80]
000074267fbd1cff  vmovaps xmm9, [rsp+0x90]
000074267fbd1d08  vmovaps xmm10, [rsp+0xA0]
000074267fbd1d11  vmovaps xmm11, [rsp+0xB0]
000074267fbd1d1a  vmovaps xmm12, [rsp+0xC0]
000074267fbd1d23  vmovaps xmm14, [rsp+0xD0]
000074267fbd1d2c  vmovaps xmm15, [rsp+0xE0]
000074267fbd1d35  add rsp, 0xF0
000074267fbd1d3c  pop r11
000074267fbd1d3e  pop r10
000074267fbd1d40  pop r9
000074267fbd1d42  pop r8
000074267fbd1d44  pop rsi
000074267fbd1d45  pop rdi
000074267fbd1d46  pop rdx
000074267fbd1d47  pop rcx
000074267fbd1d48  pop rax
000074267fbd1d49  add rsp, 0x08
000074267fbd1d4d  jmp 0x000074267FBD1B21
000074267fbd1d52  call 0x000074267FA0C380
000074267fbd1d57  jmp 0x000074267FBD1B34
000074267fbd1d5c  sub rsp, 0x08
000074267fbd1d60  push rax
000074267fbd1d61  push rcx
000074267fbd1d62  push rdx
000074267fbd1d63  push rdi
000074267fbd1d64  push rsi
000074267fbd1d65  push r8
000074267fbd1d67  push r9
000074267fbd1d69  push r10
000074267fbd1d6b  push r11
000074267fbd1d6d  sub rsp, 0xF0
000074267fbd1d74  vmovaps [rsp], xmm0
000074267fbd1d79  vmovaps [rsp+0x10], xmm2
000074267fbd1d7f  vmovaps [rsp+0x20], xmm3
000074267fbd1d85  vmovaps [rsp+0x30], xmm4
000074267fbd1d8b  vmovaps [rsp+0x40], xmm5
000074267fbd1d91  vmovaps [rsp+0x50], xmm6
000074267fbd1d97  vmovaps [rsp+0x60], xmm7
000074267fbd1d9d  vmovaps [rsp+0x70], xmm8
000074267fbd1da3  vmovaps [rsp+0x80], xmm9
000074267fbd1dac  vmovaps [rsp+0x90], xmm10
000074267fbd1db5  vmovaps [rsp+0xA0], xmm11
000074267fbd1dbe  vmovaps [rsp+0xB0], xmm12
000074267fbd1dc7  vmovaps [rsp+0xC0], xmm13
000074267fbd1dd0  vmovaps [rsp+0xD0], xmm14
000074267fbd1dd9  vmovaps [rsp+0xE0], xmm15
000074267fbd1de2  sub rsp, 0x30
000074267fbd1de6  movaps [rsp], xmm1
000074267fbd1dea  movaps [rsp+0x10], xmm14
000074267fbd1df0  movaps [rsp+0x20], xmm15
000074267fbd1df6  lea rdi, [rsp]
000074267fbd1dfa  mov esi, 0x00
000074267fbd1dff  mov rax, 0x56D4E47AE530
000074267fbd1e09  call rax
000074267fbd1e0b  movaps xmm1, [rsp]
000074267fbd1e0f  add rsp, 0x30
000074267fbd1e13  vmovaps xmm0, [rsp]
000074267fbd1e18  vmovaps xmm2, [rsp+0x10]
000074267fbd1e1e  vmovaps xmm3, [rsp+0x20]
000074267fbd1e24  vmovaps xmm4, [rsp+0x30]
000074267fbd1e2a  vmovaps xmm5, [rsp+0x40]
000074267fbd1e30  vmovaps xmm6, [rsp+0x50]
000074267fbd1e36  vmovaps xmm7, [rsp+0x60]
000074267fbd1e3c  vmovaps xmm8, [rsp+0x70]
000074267fbd1e42  vmovaps xmm9, [rsp+0x80]
000074267fbd1e4b  vmovaps xmm10, [rsp+0x90]
000074267fbd1e54  vmovaps xmm11, [rsp+0xA0]
000074267fbd1e5d  vmovaps xmm12, [rsp+0xB0]
000074267fbd1e66  vmovaps xmm13, [rsp+0xC0]
000074267fbd1e6f  vmovaps xmm14, [rsp+0xD0]
000074267fbd1e78  vmovaps xmm15, [rsp+0xE0]
000074267fbd1e81  add rsp, 0xF0
000074267fbd1e88  pop r11
000074267fbd1e8a  pop r10
000074267fbd1e8c  pop r9
000074267fbd1e8e  pop r8
000074267fbd1e90  pop rsi
000074267fbd1e91  pop rdi
000074267fbd1e92  pop rdx
000074267fbd1e93  pop rcx
000074267fbd1e94  pop rax
000074267fbd1e95  add rsp, 0x08
000074267fbd1e99  jmp 0x000074267FBD1B4E
000074267fbd1e9e  call 0x000074267F9FF540
000074267fbd1ea3  jmp 0x000074267FBD1B61
000074267fbd1ea8  int3
000074267fbd1ea9  nop [rax], eax
000074267fbd1eb0  movaps xmm1, [r15+0x180]
000074267fbd1eb8  vpmovqd xmm15, xmm1
000074267fbd1ebe  pxor xmm14, xmm14
000074267fbd1ec3  punpcklqdq xmm15, xmm14
000074267fbd1ec8  movaps [r15+0x210], xmm15
000074267fbd1ed0  movq xmm15, qword ptr [r15+0x140]
000074267fbd1ed9  movq xmm14, qword ptr [r15+0x120]
000074267fbd1ee2  psubd xmm15, xmm14
000074267fbd1ee7  movq xmm15, xmm15
000074267fbd1eec  movaps xmm13, [r15+0x170]
000074267fbd1ef4  paddq xmm1, xmm13
000074267fbd1ef9  movaps [r15+0x180], xmm1
000074267fbd1f01  movq xmm1, qword ptr [r15+0x160]
000074267fbd1f0a  paddd xmm14, xmm1
000074267fbd1f0f  movq xmm14, xmm14
000074267fbd1f14  movq xmm14, xmm14
000074267fbd1f19  movaps [r15+0x120], xmm14
000074267fbd1f21  pmovzxdq xmm15, xmm15
000074267fbd1f27  psllq xmm15, 0x00
000074267fbd1f2d  movq xmm1, qword ptr [r15+0x210]
000074267fbd1f36  movq xmm14, qword ptr [r15+0x110]
000074267fbd1f3f  paddd xmm1, xmm14
000074267fbd1f44  movq xmm1, xmm1
000074267fbd1f48  vcvtuqq2pd xmm15, xmm15
000074267fbd1f4e  pmovzxdq xmm1, xmm1
000074267fbd1f53  psllq xmm1, 0x00
000074267fbd1f58  vcvtuqq2pd xmm1, xmm1
000074267fbd1f5e  movaps xmm14, [r15+0x150]
000074267fbd1f66  movaps xmm13, xmm15
000074267fbd1f6a  mulpd xmm13, xmm14
000074267fbd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd1f75  ptest xmm12, xmm12
000074267fbd1f7b  jnz 0x000074267FBD205E
000074267fbd1f81  movaps [r15+0x220], xmm13
000074267fbd1f89  mov rax, [r15+0x48]
000074267fbd1f8d  mov r14, [r15+0x50]
000074267fbd1f91  lea r12, [r14+rax*1]
000074267fbd1f95  movups [r13+r12*1], xmm13
000074267fbd1f9b  movaps xmm15, [r15+0x130]
000074267fbd1fa3  movaps xmm14, xmm1
000074267fbd1fa7  mulpd xmm14, xmm15
000074267fbd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000074267fbd1fb2  ptest xmm13, xmm13
000074267fbd1fb8  jnz 0x000074267FBD21AC
000074267fbd1fbe  movaps [r15+0x210], xmm14
000074267fbd1fc6  mov r14, [r15+0x40]
000074267fbd1fca  lea r12, [r14+rax*1]
000074267fbd1fce  movups [r13+r12*1], xmm14
000074267fbd1fd4  lea r14, [rax+0x10]
000074267fbd1fd8  mov [r15+0x48], r14
000074267fbd1fdc  xor eax, eax
000074267fbd1fde  mov r12d, 0x200
000074267fbd1fe4  cmp r14, r12
000074267fbd1fe7  cmc
000074267fbd1fe8  lahf
000074267fbd1fe9  seto al
000074267fbd1fec  mov [r15+0x108], eax
000074267fbd1ff3  mov eax, [r15+0x108]
000074267fbd1ffa  sahf
000074267fbd1ffb  jnz 0x000074267FBD202D
000074267fbd1ffd  cmp dword ptr [r15+0x318], 0x00
000074267fbd2005  jz 0x000074267FBD2300
000074267fbd200b  nop [rax+rax*1], ax
000074267fbd2014  nop [rax+rax*1], eax
000074267fbd201c  mov eax, 0x410480
000074267fbd2021  mov [r15+0x100], rax
000074267fbd2028  jmp 0x000074267F9FE110
000074267fbd202d  cmp dword ptr [r15+0x318], 0x00
000074267fbd2035  jz 0x000074267FBD1EB0
000074267fbd203b  nop [rax+rax*1], ax
000074267fbd2044  nop [rax+rax*1], eax
000074267fbd204c  mov eax, 0x410440
000074267fbd2051  mov [r15+0x100], rax
000074267fbd2058  jmp 0x000074267F9FE110
000074267fbd205d  int3
000074267fbd205e  sub rsp, 0x08
000074267fbd2062  push rax
000074267fbd2063  push rcx
000074267fbd2064  push rdx
000074267fbd2065  push rdi
000074267fbd2066  push rsi
000074267fbd2067  push r8
000074267fbd2069  push r9
000074267fbd206b  push r10
000074267fbd206d  push r11
000074267fbd206f  sub rsp, 0xF0
000074267fbd2076  vmovaps [rsp], xmm0
000074267fbd207b  vmovaps [rsp+0x10], xmm1
000074267fbd2081  vmovaps [rsp+0x20], xmm2
000074267fbd2087  vmovaps [rsp+0x30], xmm3
000074267fbd208d  vmovaps [rsp+0x40], xmm4
000074267fbd2093  vmovaps [rsp+0x50], xmm5
000074267fbd2099  vmovaps [rsp+0x60], xmm6
000074267fbd209f  vmovaps [rsp+0x70], xmm7
000074267fbd20a5  vmovaps [rsp+0x80], xmm8
000074267fbd20ae  vmovaps [rsp+0x90], xmm9
000074267fbd20b7  vmovaps [rsp+0xA0], xmm10
000074267fbd20c0  vmovaps [rsp+0xB0], xmm11
000074267fbd20c9  vmovaps [rsp+0xC0], xmm12
000074267fbd20d2  vmovaps [rsp+0xD0], xmm14
000074267fbd20db  vmovaps [rsp+0xE0], xmm15
000074267fbd20e4  sub rsp, 0x30
000074267fbd20e8  movaps [rsp], xmm13
000074267fbd20ed  movaps [rsp+0x10], xmm15
000074267fbd20f3  movaps [rsp+0x20], xmm14
000074267fbd20f9  lea rdi, [rsp]
000074267fbd20fd  mov esi, 0x00
000074267fbd2102  mov rax, 0x56D4E47AE530
000074267fbd210c  call rax
000074267fbd210e  movaps xmm13, [rsp]
000074267fbd2113  add rsp, 0x30
000074267fbd2117  vmovaps xmm0, [rsp]
000074267fbd211c  vmovaps xmm1, [rsp+0x10]
000074267fbd2122  vmovaps xmm2, [rsp+0x20]
000074267fbd2128  vmovaps xmm3, [rsp+0x30]
000074267fbd212e  vmovaps xmm4, [rsp+0x40]
000074267fbd2134  vmovaps xmm5, [rsp+0x50]
000074267fbd213a  vmovaps xmm6, [rsp+0x60]
000074267fbd2140  vmovaps xmm7, [rsp+0x70]
000074267fbd2146  vmovaps xmm8, [rsp+0x80]
000074267fbd214f  vmovaps xmm9, [rsp+0x90]
000074267fbd2158  vmovaps xmm10, [rsp+0xA0]
000074267fbd2161  vmovaps xmm11, [rsp+0xB0]
000074267fbd216a  vmovaps xmm12, [rsp+0xC0]
000074267fbd2173  vmovaps xmm14, [rsp+0xD0]
000074267fbd217c  vmovaps xmm15, [rsp+0xE0]
000074267fbd2185  add rsp, 0xF0
000074267fbd218c  pop r11
000074267fbd218e  pop r10
000074267fbd2190  pop r9
000074267fbd2192  pop r8
000074267fbd2194  pop rsi
000074267fbd2195  pop rdi
000074267fbd2196  pop rdx
000074267fbd2197  pop rcx
000074267fbd2198  pop rax
000074267fbd2199  add rsp, 0x08
000074267fbd219d  jmp 0x000074267FBD1F81
000074267fbd21a2  call 0x000074267FAC2240
000074267fbd21a7  jmp 0x000074267FBD1F9B
000074267fbd21ac  sub rsp, 0x08
000074267fbd21b0  push rax
000074267fbd21b1  push rcx
000074267fbd21b2  push rdx
000074267fbd21b3  push rdi
000074267fbd21b4  push rsi
000074267fbd21b5  push r8
000074267fbd21b7  push r9
000074267fbd21b9  push r10
000074267fbd21bb  push r11
000074267fbd21bd  sub rsp, 0xF0
000074267fbd21c4  vmovaps [rsp], xmm0
000074267fbd21c9  vmovaps [rsp+0x10], xmm1
000074267fbd21cf  vmovaps [rsp+0x20], xmm2
000074267fbd21d5  vmovaps [rsp+0x30], xmm3
000074267fbd21db  vmovaps [rsp+0x40], xmm4
000074267fbd21e1  vmovaps [rsp+0x50], xmm5
000074267fbd21e7  vmovaps [rsp+0x60], xmm6
000074267fbd21ed  vmovaps [rsp+0x70], xmm7
000074267fbd21f3  vmovaps [rsp+0x80], xmm8
000074267fbd21fc  vmovaps [rsp+0x90], xmm9
000074267fbd2205  vmovaps [rsp+0xA0], xmm10
000074267fbd220e  vmovaps [rsp+0xB0], xmm11
000074267fbd2217  vmovaps [rsp+0xC0], xmm12
000074267fbd2220  vmovaps [rsp+0xD0], xmm13
000074267fbd2229  vmovaps [rsp+0xE0], xmm15
000074267fbd2232  sub rsp, 0x30
000074267fbd2236  movaps [rsp], xmm14
000074267fbd223b  movaps [rsp+0x10], xmm1
000074267fbd2240  movaps [rsp+0x20], xmm15
000074267fbd2246  lea rdi, [rsp]
000074267fbd224a  mov esi, 0x00
000074267fbd224f  mov rax, 0x56D4E47AE530
000074267fbd2259  call rax
000074267fbd225b  movaps xmm14, [rsp]
000074267fbd2260  add rsp, 0x30
000074267fbd2264  vmovaps xmm0, [rsp]
000074267fbd2269  vmovaps xmm1, [rsp+0x10]
000074267fbd226f  vmovaps xmm2, [rsp+0x20]
000074267fbd2275  vmovaps xmm3, [rsp+0x30]
000074267fbd227b  vmovaps xmm4, [rsp+0x40]
000074267fbd2281  vmovaps xmm5, [rsp+0x50]
000074267fbd2287  vmovaps xmm6, [rsp+0x60]
000074267fbd228d  vmovaps xmm7, [rsp+0x70]
000074267fbd2293  vmovaps xmm8, [rsp+0x80]
000074267fbd229c  vmovaps xmm9, [rsp+0x90]
000074267fbd22a5  vmovaps xmm10, [rsp+0xA0]
000074267fbd22ae  vmovaps xmm11, [rsp+0xB0]
000074267fbd22b7  vmovaps xmm12, [rsp+0xC0]
000074267fbd22c0  vmovaps xmm13, [rsp+0xD0]
000074267fbd22c9  vmovaps xmm15, [rsp+0xE0]
000074267fbd22d2  add rsp, 0xF0
000074267fbd22d9  pop r11
000074267fbd22db  pop r10
000074267fbd22dd  pop r9
000074267fbd22df  pop r8
000074267fbd22e1  pop rsi
000074267fbd22e2  pop rdi
000074267fbd22e3  pop rdx
000074267fbd22e4  pop rcx
000074267fbd22e5  pop rax
000074267fbd22e6  add rsp, 0x08
000074267fbd22ea  jmp 0x000074267FBD1FBE
000074267fbd22ef  call 0x000074267FAC34C0
000074267fbd22f4  jmp 0x000074267FBD1FD4
000074267fbd22f9  int3
000074267fbd22fa  nop [rax+rax*1], ax
000074267fbd2300  mov rax, [r15+0x50]
000074267fbd2304  movups xmm1, [r13+rax*1]
000074267fbd230a  lea r14, [rax+0x10]
000074267fbd230e  movups xmm15, [r13+r14*1]
000074267fbd2314  mov qword ptr [r15+0x48], 0x00
000074267fbd231c  lea r14, [rax+0x40]
000074267fbd2320  movups xmm14, [r13+r14*1]
000074267fbd2326  lea r14, [rax+0x50]
000074267fbd232a  movups xmm13, [r13+r14*1]
000074267fbd2330  lea r14, [rax+0x80]
000074267fbd2337  movups xmm12, [r13+r14*1]
000074267fbd233d  lea r14, [rax+0x90]
000074267fbd2344  movups xmm11, [r13+r14*1]
000074267fbd234a  mov r14, [r15+0xF8]
000074267fbd2351  movups [r13+r14*1], xmm1
000074267fbd2357  lea r12, [rax+0x20]
000074267fbd235b  movups xmm1, [r13+r12*1]
000074267fbd2361  lea r12, [rax+0x30]
000074267fbd2365  movups xmm10, [r13+r12*1]
000074267fbd236b  lea r12, [rax+0xC0]
000074267fbd2372  movups xmm9, [r13+r12*1]
000074267fbd2378  lea r12, [rax+0xD0]
000074267fbd237f  movups xmm8, [r13+r12*1]
000074267fbd2385  lea r12, [rax+0x100]
000074267fbd238c  movups xmm7, [r13+r12*1]
000074267fbd2392  lea r12, [rax+0x110]
000074267fbd2399  movups xmm6, [r13+r12*1]
000074267fbd239f  lea r12, [rax+0x140]
000074267fbd23a6  movups xmm5, [r13+r12*1]
000074267fbd23ac  lea r12, [rax+0x150]
000074267fbd23b3  movups xmm4, [r13+r12*1]
000074267fbd23b9  lea r12, [r14+0xB0]
000074267fbd23c0  movups [r13+r12*1], xmm10
000074267fbd23c6  lea r12, [r14+0xC0]
000074267fbd23cd  movups [r13+r12*1], xmm1
000074267fbd23d3  lea r12, [rax+0x180]
000074267fbd23da  movups xmm1, [r13+r12*1]
000074267fbd23e0  lea r12, [rax+0x190]
000074267fbd23e7  movups xmm10, [r13+r12*1]
000074267fbd23ed  lea r12, [rax+0x1C0]
000074267fbd23f4  movups xmm3, [r13+r12*1]
000074267fbd23fa  lea r12, [rax+0x1D0]
000074267fbd2401  movups xmm2, [r13+r12*1]
000074267fbd2407  lea r12, [rax+0x60]
000074267fbd240b  vmovaps [rsp+0x10], xmm1
000074267fbd2411  movups xmm1, [r13+r12*1]
000074267fbd2417  lea r12, [rax+0x70]
000074267fbd241b  vmovaps [rsp+0x20], xmm1
000074267fbd2421  movups xmm1, [r13+r12*1]
000074267fbd2427  lea r12, [r14+0x70]
000074267fbd242b  movups [r13+r12*1], xmm10
000074267fbd2431  lea r12, [r14+0x80]
000074267fbd2438  vmovaps xmm10, [rsp+0x10]
000074267fbd243e  movups [r13+r12*1], xmm10
000074267fbd2444  lea r12, [rax+0xA0]
000074267fbd244b  movups xmm10, [r13+r12*1]
000074267fbd2451  lea r12, [rax+0xB0]
000074267fbd2458  vmovaps [rsp+0x10], xmm1
000074267fbd245e  movups xmm1, [r13+r12*1]
000074267fbd2464  lea r12, [r14+0x90]
000074267fbd246b  movups [r13+r12*1], xmm2
000074267fbd2471  lea r12, [r14+0xA0]
000074267fbd2478  movups [r13+r12*1], xmm3
000074267fbd247e  lea r12, [rax+0xE0]
000074267fbd2485  movups xmm3, [r13+r12*1]
000074267fbd248b  lea r12, [rax+0xF0]
000074267fbd2492  movups xmm2, [r13+r12*1]
000074267fbd2498  lea r12, [rax+0x120]
000074267fbd249f  vmovaps [rsp+0x30], xmm1
000074267fbd24a5  movups xmm1, [r13+r12*1]
000074267fbd24ab  lea r12, [rax+0x130]
000074267fbd24b2  vmovaps [rsp+0x40], xmm1
000074267fbd24b8  movups xmm1, [r13+r12*1]
000074267fbd24be  vmovaps [rsp+0x50], xmm1
000074267fbd24c4  vmovaps xmm1, [rsp+0x40]
000074267fbd24ca  movaps [r15+0x190], xmm1
000074267fbd24d2  lea r12, [rax+0x160]
000074267fbd24d9  vmovaps [rsp+0x40], xmm1
000074267fbd24df  movups xmm1, [r13+r12*1]
000074267fbd24e5  lea r12, [rax+0x170]
000074267fbd24ec  vmovaps [rsp+0x60], xmm1
000074267fbd24f2  movups xmm1, [r13+r12*1]
000074267fbd24f8  lea r12, [rax+0x1A0]
000074267fbd24ff  vmovaps [rsp+0x70], xmm1
000074267fbd2505  movups xmm1, [r13+r12*1]
000074267fbd250b  lea r12, [rax+0x1B0]
000074267fbd2512  vmovaps [rsp+0x80], xmm1
000074267fbd251b  movups xmm1, [r13+r12*1]
000074267fbd2521  lea r12, [rax+0x1E0]
000074267fbd2528  vmovaps [rsp+0x90], xmm1
000074267fbd2531  movups xmm1, [r13+r12*1]
000074267fbd2537  lea r12, [rax+0x1F0]
000074267fbd253e  vmovaps [rsp+0xA0], xmm1
000074267fbd2547  movups xmm1, [r13+r12*1]
000074267fbd254d  mov qword ptr [r15+0x50], 0x432190
000074267fbd2555  lea rax, [r14+0x50]
000074267fbd2559  vmovaps [rsp+0xB0], xmm1
000074267fbd2562  vmovaps xmm1, [rsp+0x60]
000074267fbd2568  movups [r13+rax*1], xmm1
000074267fbd256e  lea rax, [r14+0x60]
000074267fbd2572  movups [r13+rax*1], xmm5
000074267fbd2578  lea rax, [r14+0x40]
000074267fbd257c  vmovaps xmm1, [rsp+0x70]
000074267fbd2582  movups [r13+rax*1], xmm1
000074267fbd2588  lea rax, [r14+0x20]
000074267fbd258c  vmovaps xmm1, [rsp+0xA0]
000074267fbd2595  movups [r13+rax*1], xmm1
000074267fbd259b  lea rax, [r14+0x30]
000074267fbd259f  vmovaps xmm1, [rsp+0x90]
000074267fbd25a8  movups [r13+rax*1], xmm1
000074267fbd25ae  lea rax, [r14+0x10]
000074267fbd25b2  vmovaps xmm1, [rsp+0xB0]
000074267fbd25bb  movups [r13+rax*1], xmm1
000074267fbd25c1  mov rax, [r15+0x40]
000074267fbd25c5  vxorps xmm1, xmm1, xmm1
000074267fbd25c9  vpbroadcastq xmm1, xmm1
000074267fbd25ce  vxorps xmm5, xmm5, xmm5
000074267fbd25d2  vpbroadcastq xmm5, xmm5
000074267fbd25d7  lea r12, [rax+0x30]
000074267fbd25db  mov r11, [r13+r12*1]
000074267fbd25e0  lea r12, [rax+0x38]
000074267fbd25e4  mov r10, [r13+r12*1]
000074267fbd25e9  vmovaps [rsp+0x60], xmm1
000074267fbd25ef  movq xmm1, r11
000074267fbd25f4  vmovaps [rsp+0x70], xmm1
000074267fbd25fa  movq xmm1, r10
000074267fbd25ff  vmovaps [rsp+0x90], xmm1
000074267fbd2608  vmovaps xmm1, [rsp+0x70]
000074267fbd260e  movq xmm1, xmm1
000074267fbd2612  vmovaps [rsp+0x70], xmm1
000074267fbd2618  vmovaps xmm1, [rsp+0x90]
000074267fbd2621  movq xmm1, xmm1
000074267fbd2625  vmovaps [rsp+0x90], xmm1
000074267fbd262e  movq xmm1, xmm1
000074267fbd2632  movaps [r15+0x270], xmm1
000074267fbd263a  vmovaps [rsp+0xA0], xmm7
000074267fbd2643  vmovaps xmm1, [rsp+0xA0]
000074267fbd264c  por xmm7, xmm1
000074267fbd2650  lea r12, [rax+0x20]
000074267fbd2654  mov r11, [r13+r12*1]
000074267fbd2659  lea r12, [rax+0x28]
000074267fbd265d  mov r10, [r13+r12*1]
000074267fbd2662  movq xmm1, r11
000074267fbd2667  vmovaps [rsp+0xA0], xmm1
000074267fbd2670  movq xmm1, r10
000074267fbd2675  vmovaps [rsp+0xB0], xmm1
000074267fbd267e  vmovaps xmm1, [rsp+0xA0]
000074267fbd2687  movq xmm1, xmm1
000074267fbd268b  vmovaps [rsp+0xA0], xmm1
000074267fbd2694  vmovaps xmm1, [rsp+0xB0]
000074267fbd269d  movq xmm1, xmm1
000074267fbd26a1  vmovaps [rsp+0xB0], xmm2
000074267fbd26aa  vmovaps [rsp+0xC0], xmm1
000074267fbd26b3  vmovaps xmm1, [rsp+0xB0]
000074267fbd26bc  por xmm2, xmm1
000074267fbd26c0  vmovaps [rsp+0xB0], xmm3
000074267fbd26c9  vmovaps xmm1, [rsp+0xB0]
000074267fbd26d2  por xmm3, xmm1
000074267fbd26d6  vmovaps [rsp+0xB0], xmm4
000074267fbd26df  vmovaps xmm1, [rsp+0xB0]
000074267fbd26e8  por xmm4, xmm1
000074267fbd26ec  vmovaps [rsp+0xB0], xmm9
000074267fbd26f5  vmovaps xmm1, [rsp+0xB0]
000074267fbd26fe  por xmm9, xmm1
000074267fbd2703  lea r12, [rax+0x10]
000074267fbd2707  mov r11, [r13+r12*1]
000074267fbd270c  lea r12, [rax+0x18]
000074267fbd2710  mov r10, [r13+r12*1]
000074267fbd2715  movq xmm1, r11
000074267fbd271a  vmovaps [rsp+0xB0], xmm1
000074267fbd2723  movq xmm1, r10
000074267fbd2728  vmovaps [rsp+0xD0], xmm1
000074267fbd2731  vmovaps xmm1, [rsp+0xB0]
000074267fbd273a  movq xmm1, xmm1
000074267fbd273e  vmovaps [rsp+0xB0], xmm1
000074267fbd2747  vmovaps xmm1, [rsp+0xD0]
000074267fbd2750  movq xmm1, xmm1
000074267fbd2754  vmovaps [rsp+0xD0], xmm1
000074267fbd275d  vmovaps xmm1, [rsp+0x80]
000074267fbd2766  vmovaps [rsp+0xE0], xmm15
000074267fbd276f  vmovaps xmm15, [rsp+0x80]
000074267fbd2778  por xmm1, xmm15
000074267fbd277d  vmovaps xmm15, [rsp+0x10]
000074267fbd2783  vmovaps [rsp+0x80], xmm1
000074267fbd278c  vmovaps xmm1, [rsp+0x10]
000074267fbd2792  por xmm15, xmm1
000074267fbd2797  vmovaps xmm1, [rsp+0x20]
000074267fbd279d  vmovaps [rsp+0x10], xmm15
000074267fbd27a3  vmovaps xmm15, [rsp+0x20]
000074267fbd27a9  por xmm1, xmm15
000074267fbd27ae  vmovaps [rsp+0x20], xmm6
000074267fbd27b4  vmovaps xmm15, [rsp+0x20]
000074267fbd27ba  por xmm6, xmm15
000074267fbd27bf  vmovaps [rsp+0x20], xmm11
000074267fbd27c5  vmovaps xmm15, [rsp+0x20]
000074267fbd27cb  por xmm11, xmm15
000074267fbd27d0  vmovaps [rsp+0x20], xmm13
000074267fbd27d6  vmovaps xmm15, [rsp+0x20]
000074267fbd27dc  por xmm13, xmm15
000074267fbd27e1  vmovaps [rsp+0x20], xmm14
000074267fbd27e7  vmovaps xmm15, [rsp+0x20]
000074267fbd27ed  por xmm14, xmm15
000074267fbd27f2  mov r12, [r13+rax*1]
000074267fbd27f7  vmovq xmm15, r12
000074267fbd27fc  vpbroadcastq xmm15, xmm15
000074267fbd2801  vmovaps [rsp+0x20], xmm1
000074267fbd2807  vxorps xmm1, xmm1, xmm1
000074267fbd280b  vpbroadcastq xmm1, xmm1
000074267fbd2810  vmovaps [rsp+0xF0], xmm1
000074267fbd2819  movups xmm1, [r13+r14*1]
000074267fbd281f  vmovaps [rsp+0x100], xmm1
000074267fbd2828  vxorps xmm1, xmm1, xmm1
000074267fbd282c  vpbroadcastq xmm1, xmm1
000074267fbd2831  lea r12, [rax+0x08]
000074267fbd2835  mov rax, [r13+r12*1]
000074267fbd283a  vmovaps [rsp+0x110], xmm1
000074267fbd2843  movq xmm1, rax
000074267fbd2848  movaps [r15+0x240], xmm1
000074267fbd2850  mov qword ptr [r15+0x60], 0x432190
000074267fbd2858  mov qword ptr [r15+0x58], 0x40
000074267fbd2860  vmovaps xmm1, [rsp+0x60]
000074267fbd2866  vmovaps [rsp+0x60], xmm15
000074267fbd286c  vmovaps xmm15, [rsp+0x100]
000074267fbd2875  vmovaps [rsp+0x100], xmm14
000074267fbd287e  vmovaps xmm14, [rsp+0x60]
000074267fbd2884  vmovaps [rsp+0x60], xmm13
000074267fbd288a  vmovaps [rsp+0x120], xmm12
000074267fbd2893  movaps xmm13, xmm1
000074267fbd2897  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd289c  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd28a2  vptest xmm12, xmm12
000074267fbd28a7  jnz 0x000074267FBD3482
000074267fbd28ad  vmovaps xmm1, [rsp+0xE0]
000074267fbd28b6  movaps xmm15, xmm5
000074267fbd28ba  vfmadd231pd xmm15, xmm1, xmm14
000074267fbd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
000074267fbd28c5  vptest xmm12, xmm12
000074267fbd28ca  jnz 0x000074267FBD35DB
000074267fbd28d0  vmovaps xmm12, [rsp+0x50]
000074267fbd28d6  vmovaps xmm5, [rsp+0x50]
000074267fbd28dc  por xmm12, xmm5
000074267fbd28e1  vmovaps xmm5, [rsp+0x30]
000074267fbd28e7  vmovaps [rsp+0x50], xmm1
000074267fbd28ed  vmovaps xmm1, [rsp+0x30]
000074267fbd28f3  por xmm5, xmm1
000074267fbd28f7  vmovaps [rsp+0x30], xmm10
000074267fbd28fd  vmovaps xmm1, [rsp+0x30]
000074267fbd2903  por xmm10, xmm1
000074267fbd2908  vmovaps [rsp+0x30], xmm8
000074267fbd290e  vmovaps xmm1, [rsp+0x30]
000074267fbd2914  por xmm8, xmm1
000074267fbd2919  vmovaps xmm1, [rsp+0x120]
000074267fbd2922  vmovaps [rsp+0x30], xmm15
000074267fbd2928  vmovaps xmm15, [rsp+0x120]
000074267fbd2931  por xmm1, xmm15
000074267fbd2936  vmovaps xmm15, [rsp+0x50]
000074267fbd293c  vmovaps [rsp+0xE0], xmm1
000074267fbd2945  vmovaps xmm1, [rsp+0x50]
000074267fbd294b  por xmm15, xmm1
000074267fbd2950  lea rax, [r14+0xC0]
000074267fbd2957  movups xmm1, [r13+rax*1]
000074267fbd295d  xor eax, eax
000074267fbd295f  mov r12d, 0x40
000074267fbd2965  mov r11d, 0x200
000074267fbd296b  cmp r12, r11
000074267fbd296e  cmc
000074267fbd296f  lahf
000074267fbd2970  seto al
000074267fbd2973  mov [r15+0x108], eax
000074267fbd297a  vmovaps [rsp+0x50], xmm1
000074267fbd2980  vmovaps xmm1, [rsp+0xF0]
000074267fbd2989  vmovaps [rsp+0xF0], xmm15
000074267fbd2992  vmovaps xmm15, [rsp+0x50]
000074267fbd2998  vmovaps [rsp+0x50], xmm13
000074267fbd299e  vmovaps [rsp+0x120], xmm12
000074267fbd29a7  movaps xmm13, xmm1
000074267fbd29ab  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd29b6  vptest xmm12, xmm12
000074267fbd29bb  jnz 0x000074267FBD373D
000074267fbd29c1  lea rax, [r14+0xB0]
000074267fbd29c8  movups xmm1, [r13+rax*1]
000074267fbd29ce  vmovaps xmm15, [rsp+0x110]
000074267fbd29d7  vmovaps [rsp+0x110], xmm13
000074267fbd29e0  movaps xmm12, xmm15
000074267fbd29e4  vfmadd231pd xmm12, xmm1, xmm14
000074267fbd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
000074267fbd29ef  vptest xmm13, xmm13
000074267fbd29f4  jnz 0x000074267FBD38A0
000074267fbd29fa  vmovaps xmm1, [rsp+0x100]
000074267fbd2a03  vmovaps xmm15, [rsp+0x100]
000074267fbd2a0c  por xmm1, xmm15
000074267fbd2a11  movaps [r15+0x210], xmm1
000074267fbd2a19  vmovaps xmm15, [rsp+0x60]
000074267fbd2a1f  vmovaps xmm14, [rsp+0x60]
000074267fbd2a25  por xmm15, xmm14
000074267fbd2a2a  movaps [r15+0x1C0], xmm15
000074267fbd2a32  vmovaps [rsp+0x60], xmm11
000074267fbd2a38  vmovaps xmm14, [rsp+0x60]
000074267fbd2a3e  por xmm11, xmm14
000074267fbd2a43  movaps [r15+0x280], xmm11
000074267fbd2a4b  vmovaps [rsp+0x60], xmm6
000074267fbd2a51  vmovaps xmm14, [rsp+0x60]
000074267fbd2a57  por xmm6, xmm14
000074267fbd2a5c  movaps [r15+0x2A0], xmm6
000074267fbd2a64  vmovaps xmm14, [rsp+0x20]
000074267fbd2a6a  vmovaps xmm13, [rsp+0x20]
000074267fbd2a70  por xmm14, xmm13
000074267fbd2a75  movaps [r15+0x2E0], xmm14
000074267fbd2a7d  vmovaps xmm13, [rsp+0x10]
000074267fbd2a83  vmovaps [rsp+0x20], xmm1
000074267fbd2a89  vmovaps xmm1, [rsp+0x10]
000074267fbd2a8f  por xmm13, xmm1
000074267fbd2a94  movaps [r15+0x1F0], xmm13
000074267fbd2a9c  vmovaps xmm1, [rsp+0xF0]
000074267fbd2aa5  vmovaps [rsp+0x10], xmm15
000074267fbd2aab  vmovaps xmm15, [rsp+0xF0]
000074267fbd2ab4  por xmm1, xmm15
000074267fbd2ab9  movaps [r15+0x250], xmm1
000074267fbd2ac1  vmovaps xmm1, [rsp+0xE0]
000074267fbd2aca  vmovaps xmm15, [rsp+0xE0]
000074267fbd2ad3  por xmm1, xmm15
000074267fbd2ad8  movaps [r15+0x260], xmm1
000074267fbd2ae0  vmovaps [rsp+0x60], xmm8
000074267fbd2ae6  vmovaps xmm15, [rsp+0x60]
000074267fbd2aec  por xmm8, xmm15
000074267fbd2af1  movaps [r15+0x290], xmm8
000074267fbd2af9  vmovaps [rsp+0x60], xmm10
000074267fbd2aff  vmovaps xmm15, [rsp+0x60]
000074267fbd2b05  por xmm10, xmm15
000074267fbd2b0a  movaps [r15+0x2C0], xmm10
000074267fbd2b12  movq xmm15, qword ptr [r15+0x240]
000074267fbd2b1b  vmovaps [rsp+0x60], xmm15
000074267fbd2b21  vpermilpd xmm15, xmm15, 0x00
000074267fbd2b27  vmovaps [rsp+0xE0], xmm1
000074267fbd2b30  vmovaps xmm1, [rsp+0x50]
000074267fbd2b36  vmovaps [rsp+0x50], xmm15
000074267fbd2b3c  vmovaps xmm15, [rsp+0x20]
000074267fbd2b42  vmovaps [rsp+0x20], xmm14
000074267fbd2b48  vmovaps xmm14, [rsp+0x50]
000074267fbd2b4e  vmovaps [rsp+0x50], xmm13
000074267fbd2b54  vmovaps [rsp+0xF0], xmm12
000074267fbd2b5d  movaps xmm13, xmm1
000074267fbd2b61  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd2b6c  vptest xmm12, xmm12
000074267fbd2b71  jnz 0x000074267FBD39F9
000074267fbd2b77  vmovaps xmm1, [rsp+0x60]
000074267fbd2b7d  vpermilpd xmm1, xmm1, 0x00
000074267fbd2b83  vmovaps xmm15, [rsp+0x110]
000074267fbd2b8c  vmovaps xmm14, [rsp+0x20]
000074267fbd2b92  vmovaps [rsp+0x20], xmm13
000074267fbd2b98  movaps xmm12, xmm15
000074267fbd2b9c  vfmadd231pd xmm12, xmm14, xmm1
000074267fbd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
000074267fbd2ba7  vptest xmm13, xmm13
000074267fbd2bac  jnz 0x000074267FBD3B52
000074267fbd2bb2  vmovaps xmm1, [rsp+0x60]
000074267fbd2bb8  vpermilpd xmm1, xmm1, 0x00
000074267fbd2bbe  vmovaps xmm15, [rsp+0x30]
000074267fbd2bc4  vmovaps xmm14, [rsp+0x10]
000074267fbd2bca  vmovaps [rsp+0x10], xmm12
000074267fbd2bd0  movaps xmm13, xmm15
000074267fbd2bd4  vfmadd231pd xmm13, xmm14, xmm1
000074267fbd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd2bdf  vptest xmm12, xmm12
000074267fbd2be4  jnz 0x000074267FBD3CAB
000074267fbd2bea  vmovaps [rsp+0x30], xmm5
000074267fbd2bf0  vmovaps xmm1, [rsp+0x30]
000074267fbd2bf6  por xmm5, xmm1
000074267fbd2bfa  movaps [r15+0x1D0], xmm5
000074267fbd2c02  vmovaps xmm1, [rsp+0x60]
000074267fbd2c08  vpermilpd xmm1, xmm1, 0x00
000074267fbd2c0e  vmovaps xmm15, [rsp+0xF0]
000074267fbd2c17  vmovaps xmm14, [rsp+0x50]
000074267fbd2c1d  vmovaps [rsp+0x30], xmm13
000074267fbd2c23  movaps xmm12, xmm15
000074267fbd2c27  vfmadd231pd xmm12, xmm14, xmm1
000074267fbd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
000074267fbd2c32  vptest xmm13, xmm13
000074267fbd2c37  jnz 0x000074267FBD3E04
000074267fbd2c3d  vmovaps xmm1, [rsp+0x80]
000074267fbd2c46  vmovaps xmm15, [rsp+0x80]
000074267fbd2c4f  por xmm1, xmm15
000074267fbd2c54  movaps [r15+0x200], xmm1
000074267fbd2c5c  vmovaps xmm15, [rsp+0x120]
000074267fbd2c65  vmovaps xmm14, [rsp+0x120]
000074267fbd2c6e  por xmm15, xmm14
000074267fbd2c73  movaps [r15+0x1E0], xmm15
000074267fbd2c7b  vmovaps [rsp+0x50], xmm4
000074267fbd2c81  vmovaps xmm13, [rsp+0x50]
000074267fbd2c87  por xmm4, xmm13
000074267fbd2c8c  movaps [r15+0x2B0], xmm4
000074267fbd2c94  vmovaps [rsp+0x50], xmm3
000074267fbd2c9a  vmovaps xmm13, [rsp+0x50]
000074267fbd2ca0  por xmm3, xmm13
000074267fbd2ca5  movaps [r15+0x300], xmm3
000074267fbd2cad  vmovaps xmm15, [rsp+0xB0]
000074267fbd2cb6  vpermilpd xmm15, xmm15, 0x00
000074267fbd2cbc  vmovaps xmm3, [rsp+0x20]
000074267fbd2cc2  vmovaps [rsp+0x20], xmm1
000074267fbd2cc8  vmovaps xmm1, [rsp+0xE0]
000074267fbd2cd1  vmovaps [rsp+0x50], xmm14
000074267fbd2cd7  vmovaps [rsp+0x60], xmm13
000074267fbd2cdd  movaps xmm14, xmm3
000074267fbd2ce1  vfmadd231pd xmm14, xmm1, xmm15
000074267fbd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
000074267fbd2cec  vptest xmm13, xmm13
000074267fbd2cf1  jnz 0x000074267FBD3F5D
000074267fbd2cf7  vmovaps xmm1, [rsp+0xB0]
000074267fbd2d00  vpermilpd xmm1, xmm1, 0x00
000074267fbd2d06  vmovaps xmm15, [rsp+0x10]
000074267fbd2d0c  movaps xmm13, xmm15
000074267fbd2d10  vfmadd231pd xmm13, xmm10, xmm1
000074267fbd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
000074267fbd2d1b  vptest xmm3, xmm3
000074267fbd2d20  jnz 0x000074267FBD40B5
000074267fbd2d26  vmovaps xmm1, [rsp+0xB0]
000074267fbd2d2f  vpermilpd xmm1, xmm1, 0x00
000074267fbd2d35  vmovaps xmm15, [rsp+0x30]
000074267fbd2d3b  movaps xmm10, xmm15
000074267fbd2d3f  vfmadd231pd xmm10, xmm11, xmm1
000074267fbd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
000074267fbd2d4a  vptest xmm3, xmm3
000074267fbd2d4f  jnz 0x000074267FBD420E
000074267fbd2d55  vmovaps xmm1, [rsp+0xB0]
000074267fbd2d5e  vpermilpd xmm1, xmm1, 0x00
000074267fbd2d64  movaps xmm15, xmm12
000074267fbd2d68  vfmadd231pd xmm15, xmm5, xmm1
000074267fbd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
000074267fbd2d73  vptest xmm11, xmm11
000074267fbd2d78  jnz 0x000074267FBD4367
000074267fbd2d7e  vmovaps [rsp+0x10], xmm9
000074267fbd2d84  vmovaps xmm1, [rsp+0x10]
000074267fbd2d8a  por xmm9, xmm1
000074267fbd2d8f  movaps [r15+0x180], xmm9
000074267fbd2d97  vmovaps [rsp+0x10], xmm2
000074267fbd2d9d  vmovaps xmm1, [rsp+0x10]
000074267fbd2da3  por xmm2, xmm1
000074267fbd2da7  movaps [r15+0x2D0], xmm2
000074267fbd2daf  vmovaps xmm12, [rsp+0xD0]
000074267fbd2db8  vpermilpd xmm12, xmm12, 0x00
000074267fbd2dbe  vmovaps xmm11, [rsp+0x60]
000074267fbd2dc4  movaps xmm5, xmm13
000074267fbd2dc8  vfmadd231pd xmm5, xmm11, xmm12
000074267fbd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
000074267fbd2dd2  vptest xmm3, xmm3
000074267fbd2dd7  jnz 0x000074267FBD44BF
000074267fbd2ddd  vmovaps xmm13, [rsp+0xD0]
000074267fbd2de6  vpermilpd xmm13, xmm13, 0x00
000074267fbd2dec  movaps xmm12, xmm14
000074267fbd2df0  vfmadd231pd xmm12, xmm9, xmm13
000074267fbd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
000074267fbd2dfb  vptest xmm11, xmm11
000074267fbd2e00  jnz 0x000074267FBD4617
000074267fbd2e06  lea rax, [r14+0x80]
000074267fbd2e0d  movups xmm14, [r13+rax*1]
000074267fbd2e13  movaps [r15+0x2F0], xmm14
000074267fbd2e1b  vmovaps xmm13, [rsp+0xD0]
000074267fbd2e24  vpermilpd xmm13, xmm13, 0x00
000074267fbd2e2a  movaps xmm11, xmm10
000074267fbd2e2e  vfmadd231pd xmm11, xmm8, xmm13
000074267fbd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
000074267fbd2e39  vptest xmm9, xmm9
000074267fbd2e3e  jnz 0x000074267FBD477B
000074267fbd2e44  vmovaps xmm13, [rsp+0xD0]
000074267fbd2e4d  vpermilpd xmm13, xmm13, 0x00
000074267fbd2e53  movaps xmm10, xmm15
000074267fbd2e57  vfmadd231pd xmm10, xmm1, xmm13
000074267fbd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
000074267fbd2e62  vptest xmm9, xmm9
000074267fbd2e67  jnz 0x000074267FBD48D5
000074267fbd2e6d  vmovaps [rsp+0x10], xmm7
000074267fbd2e73  vmovaps xmm1, [rsp+0x10]
000074267fbd2e79  por xmm7, xmm1
000074267fbd2e7d  movaps [r15+0x160], xmm7
000074267fbd2e85  lea rax, [r14+0x40]
000074267fbd2e89  movups xmm1, [r13+rax*1]
000074267fbd2e8f  lea rax, [r14+0x50]
000074267fbd2e93  movups xmm15, [r13+rax*1]
000074267fbd2e99  movaps [r15+0x1B0], xmm1
000074267fbd2ea1  movaps [r15+0x1A0], xmm15
000074267fbd2ea9  vmovaps xmm13, [rsp+0xA0]
000074267fbd2eb2  vpermilpd xmm13, xmm13, 0x00
000074267fbd2eb8  vmovaps xmm9, [rsp+0x40]
000074267fbd2ebe  movaps xmm8, xmm5
000074267fbd2ec2  vfmadd231pd xmm8, xmm9, xmm13
000074267fbd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
000074267fbd2ecd  vptest xmm3, xmm3
000074267fbd2ed2  jnz 0x000074267FBD4A42
000074267fbd2ed8  vmovaps xmm13, [rsp+0xA0]
000074267fbd2ee1  vpermilpd xmm13, xmm13, 0x00
000074267fbd2ee7  movaps xmm9, xmm12
000074267fbd2eeb  vfmadd231pd xmm9, xmm7, xmm13
000074267fbd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
000074267fbd2ef6  vptest xmm5, xmm5
000074267fbd2efb  jnz 0x000074267FBD4B9B
000074267fbd2f01  vmovaps xmm13, [rsp+0xA0]
000074267fbd2f0a  vpermilpd xmm13, xmm13, 0x00
000074267fbd2f10  movaps xmm12, xmm11
000074267fbd2f14  vfmadd231pd xmm12, xmm6, xmm13
000074267fbd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
000074267fbd2f1f  vptest xmm7, xmm7
000074267fbd2f24  jnz 0x000074267FBD4CF4
000074267fbd2f2a  vmovaps xmm13, [rsp+0xA0]
000074267fbd2f33  vpermilpd xmm13, xmm13, 0x00
000074267fbd2f39  vmovaps xmm11, [rsp+0x50]
000074267fbd2f3f  movaps xmm7, xmm10
000074267fbd2f43  vfmadd231pd xmm7, xmm11, xmm13
000074267fbd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
000074267fbd2f4d  vptest xmm6, xmm6
000074267fbd2f52  jnz 0x000074267FBD4E4D
000074267fbd2f58  lea rax, [r14+0x60]
000074267fbd2f5c  movups xmm13, [r13+rax*1]
000074267fbd2f62  lea rax, [r14+0x70]
000074267fbd2f66  movups xmm11, [r13+rax*1]
000074267fbd2f6c  movaps [r15+0x150], xmm13
000074267fbd2f74  movaps [r15+0x120], xmm11
000074267fbd2f7c  vmovaps xmm10, [rsp+0xC0]
000074267fbd2f85  vpermilpd xmm10, xmm10, 0x00
000074267fbd2f8b  movaps xmm6, xmm8
000074267fbd2f8f  vfmadd231pd xmm6, xmm15, xmm10
000074267fbd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
000074267fbd2f99  vptest xmm5, xmm5
000074267fbd2f9e  jnz 0x000074267FBD4FB9
000074267fbd2fa4  vmovaps xmm15, [rsp+0xC0]
000074267fbd2fad  vpermilpd xmm15, xmm15, 0x00
000074267fbd2fb3  movaps xmm10, xmm9
000074267fbd2fb7  vfmadd231pd xmm10, xmm13, xmm15
000074267fbd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
000074267fbd2fc2  vptest xmm8, xmm8
000074267fbd2fc7  jnz 0x000074267FBD5111
000074267fbd2fcd  vmovaps xmm15, [rsp+0xC0]
000074267fbd2fd6  vpermilpd xmm15, xmm15, 0x00
000074267fbd2fdc  movaps xmm13, xmm12
000074267fbd2fe0  vfmadd231pd xmm13, xmm4, xmm15
000074267fbd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
000074267fbd2feb  vptest xmm9, xmm9
000074267fbd2ff0  jnz 0x000074267FBD526B
000074267fbd2ff6  vmovaps xmm15, [rsp+0xC0]
000074267fbd2fff  vpermilpd xmm15, xmm15, 0x00
000074267fbd3005  movaps xmm12, xmm7
000074267fbd3009  vfmadd231pd xmm12, xmm1, xmm15
000074267fbd300e  vcmppd xmm9, xmm12, xmm12, 0x03
000074267fbd3014  vptest xmm9, xmm9
000074267fbd3019  jnz 0x000074267FBD53C4
000074267fbd301f  lea rax, [r14+0x20]
000074267fbd3023  movups xmm1, [r13+rax*1]
000074267fbd3029  lea rax, [r14+0x30]
000074267fbd302d  movups xmm15, [r13+rax*1]
000074267fbd3033  vmovaps xmm9, [rsp+0x70]
000074267fbd3039  vpermilpd xmm9, xmm9, 0x00
000074267fbd303f  vmovaps xmm8, [rsp+0x20]
000074267fbd3045  movaps xmm7, xmm6
000074267fbd3048  vfmadd231pd xmm7, xmm8, xmm9
000074267fbd304d  vcmppd xmm5, xmm7, xmm7, 0x03
000074267fbd3052  vptest xmm5, xmm5
000074267fbd3057  jnz 0x000074267FBD5530
000074267fbd305d  vmovaps xmm9, [rsp+0x70]
000074267fbd3063  vpermilpd xmm9, xmm9, 0x00
000074267fbd3069  movaps xmm8, xmm10
000074267fbd306d  vfmadd231pd xmm8, xmm14, xmm9
000074267fbd3072  vcmppd xmm6, xmm8, xmm8, 0x03
000074267fbd3078  vptest xmm6, xmm6
000074267fbd307d  jnz 0x000074267FBD5687
000074267fbd3083  vmovaps xmm14, [rsp+0x70]
000074267fbd3089  vpermilpd xmm14, xmm14, 0x00
000074267fbd308f  movaps xmm10, xmm13
000074267fbd3093  vfmadd231pd xmm10, xmm11, xmm14
000074267fbd3098  vcmppd xmm9, xmm10, xmm10, 0x03
000074267fbd309e  vptest xmm9, xmm9
000074267fbd30a3  jnz 0x000074267FBD57E1
000074267fbd30a9  vmovaps xmm14, [rsp+0x70]
000074267fbd30af  vpermilpd xmm14, xmm14, 0x00
000074267fbd30b5  movaps xmm13, xmm12
000074267fbd30b9  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd30be  vcmppd xmm11, xmm13, xmm13, 0x03
000074267fbd30c4  vptest xmm11, xmm11
000074267fbd30c9  jnz 0x000074267FBD593B
000074267fbd30cf  lea rax, [r14+0x90]
000074267fbd30d6  movups xmm15, [r13+rax*1]
000074267fbd30dc  lea rax, [r14+0xA0]
000074267fbd30e3  movups xmm14, [r13+rax*1]
000074267fbd30e9  movaps [r15+0x140], xmm15
000074267fbd30f1  movaps [r15+0x130], xmm14
000074267fbd30f9  vmovaps xmm12, [rsp+0x90]
000074267fbd3102  vpermilpd xmm12, xmm12, 0x00
000074267fbd3108  movaps xmm11, xmm7
000074267fbd310c  vfmadd231pd xmm11, xmm1, xmm12
000074267fbd3111  vcmppd xmm9, xmm11, xmm11, 0x03
000074267fbd3117  vptest xmm9, xmm9
000074267fbd311c  jnz 0x000074267FBD5AA9
000074267fbd3122  movaps [r15+0x220], xmm11
000074267fbd312a  lea rax, [r14+0x10]
000074267fbd312e  movups xmm1, [r13+rax*1]
000074267fbd3134  movaps [r15+0x240], xmm1
000074267fbd313c  vmovaps xmm12, [rsp+0x90]
000074267fbd3145  vpermilpd xmm12, xmm12, 0x00
000074267fbd314b  movaps xmm9, xmm8
000074267fbd314f  vfmadd231pd xmm9, xmm14, xmm12
000074267fbd3154  vcmppd xmm7, xmm9, xmm9, 0x03
000074267fbd315a  vptest xmm7, xmm7
000074267fbd315f  jnz 0x000074267FBD5C0B
000074267fbd3165  movaps [r15+0x110], xmm9
000074267fbd316d  vmovaps xmm14, [rsp+0x90]
000074267fbd3176  vpermilpd xmm14, xmm14, 0x00
000074267fbd317c  movaps xmm12, xmm10
000074267fbd3180  vfmadd231pd xmm12, xmm15, xmm14
000074267fbd3185  vcmppd xmm8, xmm12, xmm12, 0x03
000074267fbd318b  vptest xmm8, xmm8
000074267fbd3190  jnz 0x000074267FBD5D65
000074267fbd3196  movaps [r15+0x170], xmm12
000074267fbd319e  vmovaps xmm15, [rsp+0x90]
000074267fbd31a7  vpermilpd xmm15, xmm15, 0x00
000074267fbd31ad  movaps xmm14, xmm13
000074267fbd31b1  vfmadd231pd xmm14, xmm1, xmm15
000074267fbd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
000074267fbd31bc  vptest xmm10, xmm10
000074267fbd31c1  jnz 0x000074267FBD5EBF
000074267fbd31c7  movaps [r15+0x230], xmm14
000074267fbd31cf  mov eax, 0x432190
000074267fbd31d4  movups [r13+rax*1], xmm9
000074267fbd31da  mov eax, 0x4321A0
000074267fbd31df  movups [r13+rax*1], xmm12
000074267fbd31e5  mov eax, 0x4321B0
000074267fbd31ea  movups [r13+rax*1], xmm11
000074267fbd31f0  mov eax, 0x4321C0
000074267fbd31f5  movups [r13+rax*1], xmm14
000074267fbd31fb  mov eax, [r15+0x108]
000074267fbd3202  sahf
000074267fbd3203  jnz 0x000074267FBD3235
000074267fbd3205  cmp dword ptr [r15+0x318], 0x00
000074267fbd320d  jz 0x000074267FBD9950
000074267fbd3213  nop [rax+rax*1], ax
000074267fbd321c  nop [rax+rax*1], eax
000074267fbd3224  mov eax, 0x410664
000074267fbd3229  mov [r15+0x100], rax
000074267fbd3230  jmp 0x000074267F9FE110
000074267fbd3235  cmp dword ptr [r15+0x318], 0x00
000074267fbd323d  jz 0x000074267FBD6050
000074267fbd3243  nop [rax+rax*1], ax
000074267fbd324c  nop [rax+rax*1], eax
000074267fbd3254  mov eax, 0x4104F0
000074267fbd3259  mov [r15+0x100], rax
000074267fbd3260  jmp 0x000074267F9FE110
000074267fbd3265  int3
000074267fbd3266  call 0x000074267F9FF430
000074267fbd326b  jmp 0x000074267FBD230A
000074267fbd3270  call 0x000074267FAE5820
000074267fbd3275  jmp 0x000074267FBD2314
000074267fbd327a  call 0x000074267FAE45A0
000074267fbd327f  jmp 0x000074267FBD2326
000074267fbd3284  call 0x000074267FAE3320
000074267fbd3289  jmp 0x000074267FBD2330
000074267fbd328e  call 0x000074267FAE20A0
000074267fbd3293  jmp 0x000074267FBD233D
000074267fbd3298  call 0x000074267FAE0E30
000074267fbd329d  jmp 0x000074267FBD234A
000074267fbd32a2  call 0x000074267FAD6600
000074267fbd32a7  jmp 0x000074267FBD2357
000074267fbd32ac  call 0x000074267FAB52F0
000074267fbd32b1  jmp 0x000074267FBD2361
000074267fbd32b6  call 0x000074267FABE9C0
000074267fbd32bb  jmp 0x000074267FBD236B
000074267fbd32c0  call 0x000074267FABD750
000074267fbd32c5  jmp 0x000074267FBD2378
000074267fbd32ca  call 0x000074267FABC4E0
000074267fbd32cf  jmp 0x000074267FBD2385
000074267fbd32d4  call 0x000074267FABB270
000074267fbd32d9  jmp 0x000074267FBD2392
000074267fbd32de  call 0x000074267FABA000
000074267fbd32e3  jmp 0x000074267FBD239F
000074267fbd32e8  call 0x000074267FAB8D90
000074267fbd32ed  jmp 0x000074267FBD23AC
000074267fbd32f2  call 0x000074267FAB8A20
000074267fbd32f7  jmp 0x000074267FBD23B9
000074267fbd32fc  call 0x000074267FABEAE0
000074267fbd3301  jmp 0x000074267FBD23C6
000074267fbd3306  call 0x000074267FAB5400
000074267fbd330b  jmp 0x000074267FBD23D3
000074267fbd3310  call 0x000074267FAB52F0
000074267fbd3315  jmp 0x000074267FBD23E0
000074267fbd331a  call 0x000074267FABE9C0
000074267fbd331f  jmp 0x000074267FBD23ED
000074267fbd3324  call 0x000074267FAB77B0
000074267fbd3329  jmp 0x000074267FBD23FA
000074267fbd332e  call 0x000074267FAB6550
000074267fbd3333  jmp 0x000074267FBD2407
000074267fbd3338  call 0x000074267FAB52F0
000074267fbd333d  jmp 0x000074267FBD2417
000074267fbd3342  call 0x000074267FAB52F0
000074267fbd3347  jmp 0x000074267FBD2427
000074267fbd334c  call 0x000074267FABEAE0
000074267fbd3351  jmp 0x000074267FBD2431
000074267fbd3356  call 0x000074267FABEAE0
000074267fbd335b  jmp 0x000074267FBD2444
000074267fbd3360  call 0x000074267FABE9C0
000074267fbd3365  jmp 0x000074267FBD2451
000074267fbd336a  call 0x000074267FAB52F0
000074267fbd336f  jmp 0x000074267FBD2464
000074267fbd3374  call 0x000074267FAB6660
000074267fbd3379  jmp 0x000074267FBD2471
000074267fbd337e  call 0x000074267FAB78C0
000074267fbd3383  jmp 0x000074267FBD247E
000074267fbd3388  call 0x000074267FAB77B0
000074267fbd338d  jmp 0x000074267FBD248B
000074267fbd3392  call 0x000074267FAB6550
000074267fbd3397  jmp 0x000074267FBD2498
000074267fbd339c  call 0x000074267FAB52F0
000074267fbd33a1  jmp 0x000074267FBD24AB
000074267fbd33a6  call 0x000074267FAB52F0
000074267fbd33ab  jmp 0x000074267FBD24BE
000074267fbd33b0  call 0x000074267FAB52F0
000074267fbd33b5  jmp 0x000074267FBD24E5
000074267fbd33ba  call 0x000074267FAB52F0
000074267fbd33bf  jmp 0x000074267FBD24F8
000074267fbd33c4  call 0x000074267FAB52F0
000074267fbd33c9  jmp 0x000074267FBD250B
000074267fbd33ce  call 0x000074267FAB52F0
000074267fbd33d3  jmp 0x000074267FBD2521
000074267fbd33d8  call 0x000074267FAB52F0
000074267fbd33dd  jmp 0x000074267FBD2537
000074267fbd33e2  call 0x000074267FAB52F0
000074267fbd33e7  jmp 0x000074267FBD254D
000074267fbd33ec  call 0x000074267F9FF540
000074267fbd33f1  jmp 0x000074267FBD256E
000074267fbd33f6  call 0x000074267FA02FE0
000074267fbd33fb  jmp 0x000074267FBD2578
000074267fbd3400  call 0x000074267F9FF540
000074267fbd3405  jmp 0x000074267FBD2588
000074267fbd340a  call 0x000074267F9FF540
000074267fbd340f  jmp 0x000074267FBD259B
000074267fbd3414  call 0x000074267F9FF540
000074267fbd3419  jmp 0x000074267FBD25AE
000074267fbd341e  call 0x000074267F9FF540
000074267fbd3423  jmp 0x000074267FBD25C1
000074267fbd3428  call 0x000074267FAC0370
000074267fbd342d  jmp 0x000074267FBD25E0
000074267fbd3432  call 0x000074267FABF100
000074267fbd3437  jmp 0x000074267FBD25E9
000074267fbd343c  call 0x000074267FAC0370
000074267fbd3441  jmp 0x000074267FBD2659
000074267fbd3446  call 0x000074267FABF100
000074267fbd344b  jmp 0x000074267FBD2662
000074267fbd3450  call 0x000074267FAC0370
000074267fbd3455  jmp 0x000074267FBD270C
000074267fbd345a  call 0x000074267FABF100
000074267fbd345f  jmp 0x000074267FBD2715
000074267fbd3464  call 0x000074267FA0B720
000074267fbd3469  jmp 0x000074267FBD27F7
000074267fbd346e  call 0x000074267FAD64F0
000074267fbd3473  jmp 0x000074267FBD281F
000074267fbd3478  call 0x000074267FAB47C0
000074267fbd347d  jmp 0x000074267FBD283A
000074267fbd3482  sub rsp, 0x08
000074267fbd3486  push rax
000074267fbd3487  push rcx
000074267fbd3488  push rdx
000074267fbd3489  push rdi
000074267fbd348a  push rsi
000074267fbd348b  push r8
000074267fbd348d  push r9
000074267fbd348f  push r10
000074267fbd3491  push r11
000074267fbd3493  sub rsp, 0xF0
000074267fbd349a  vmovaps [rsp], xmm0
000074267fbd349f  vmovaps [rsp+0x10], xmm1
000074267fbd34a5  vmovaps [rsp+0x20], xmm2
000074267fbd34ab  vmovaps [rsp+0x30], xmm3
000074267fbd34b1  vmovaps [rsp+0x40], xmm4
000074267fbd34b7  vmovaps [rsp+0x50], xmm5
000074267fbd34bd  vmovaps [rsp+0x60], xmm6
000074267fbd34c3  vmovaps [rsp+0x70], xmm7
000074267fbd34c9  vmovaps [rsp+0x80], xmm8
000074267fbd34d2  vmovaps [rsp+0x90], xmm9
000074267fbd34db  vmovaps [rsp+0xA0], xmm10
000074267fbd34e4  vmovaps [rsp+0xB0], xmm11
000074267fbd34ed  vmovaps [rsp+0xC0], xmm12
000074267fbd34f6  vmovaps [rsp+0xD0], xmm14
000074267fbd34ff  vmovaps [rsp+0xE0], xmm15
000074267fbd3508  sub rsp, 0x40
000074267fbd350c  lea rdi, [rsp]
000074267fbd3510  lea rsi, [rsp+0x10]
000074267fbd3515  lea rdx, [rsp+0x20]
000074267fbd351a  lea rcx, [rsp+0x30]
000074267fbd351f  mov r8d, 0x00
000074267fbd3525  lea r9, [r15+0x3A8]
000074267fbd352c  movaps [rdi], xmm13
000074267fbd3530  movaps [rsi], xmm1
000074267fbd3533  movaps [rdx], xmm15
000074267fbd3537  movaps [rcx], xmm14
000074267fbd353b  mov rax, 0x56D4E47AEA50
000074267fbd3545  call rax
000074267fbd3547  movaps xmm13, [rsp]
000074267fbd354c  add rsp, 0x40
000074267fbd3550  vmovaps xmm0, [rsp]
000074267fbd3555  vmovaps xmm1, [rsp+0x10]
000074267fbd355b  vmovaps xmm2, [rsp+0x20]
000074267fbd3561  vmovaps xmm3, [rsp+0x30]
000074267fbd3567  vmovaps xmm4, [rsp+0x40]
000074267fbd356d  vmovaps xmm5, [rsp+0x50]
000074267fbd3573  vmovaps xmm6, [rsp+0x60]
000074267fbd3579  vmovaps xmm7, [rsp+0x70]
000074267fbd357f  vmovaps xmm8, [rsp+0x80]
000074267fbd3588  vmovaps xmm9, [rsp+0x90]
000074267fbd3591  vmovaps xmm10, [rsp+0xA0]
000074267fbd359a  vmovaps xmm11, [rsp+0xB0]
000074267fbd35a3  vmovaps xmm12, [rsp+0xC0]
000074267fbd35ac  vmovaps xmm14, [rsp+0xD0]
000074267fbd35b5  vmovaps xmm15, [rsp+0xE0]
000074267fbd35be  add rsp, 0xF0
000074267fbd35c5  pop r11
000074267fbd35c7  pop r10
000074267fbd35c9  pop r9
000074267fbd35cb  pop r8
000074267fbd35cd  pop rsi
000074267fbd35ce  pop rdi
000074267fbd35cf  pop rdx
000074267fbd35d0  pop rcx
000074267fbd35d1  pop rax
000074267fbd35d2  add rsp, 0x08
000074267fbd35d6  jmp 0x000074267FBD28AD
000074267fbd35db  sub rsp, 0x08
000074267fbd35df  push rax
000074267fbd35e0  push rcx
000074267fbd35e1  push rdx
000074267fbd35e2  push rdi
000074267fbd35e3  push rsi
000074267fbd35e4  push r8
000074267fbd35e6  push r9
000074267fbd35e8  push r10
000074267fbd35ea  push r11
000074267fbd35ec  sub rsp, 0xF0
000074267fbd35f3  vmovaps [rsp], xmm0
000074267fbd35f8  vmovaps [rsp+0x10], xmm1
000074267fbd35fe  vmovaps [rsp+0x20], xmm2
000074267fbd3604  vmovaps [rsp+0x30], xmm3
000074267fbd360a  vmovaps [rsp+0x40], xmm4
000074267fbd3610  vmovaps [rsp+0x50], xmm5
000074267fbd3616  vmovaps [rsp+0x60], xmm6
000074267fbd361c  vmovaps [rsp+0x70], xmm7
000074267fbd3622  vmovaps [rsp+0x80], xmm8
000074267fbd362b  vmovaps [rsp+0x90], xmm9
000074267fbd3634  vmovaps [rsp+0xA0], xmm10
000074267fbd363d  vmovaps [rsp+0xB0], xmm11
000074267fbd3646  vmovaps [rsp+0xC0], xmm12
000074267fbd364f  vmovaps [rsp+0xD0], xmm13
000074267fbd3658  vmovaps [rsp+0xE0], xmm14
000074267fbd3661  sub rsp, 0x40
000074267fbd3665  lea rdi, [rsp]
000074267fbd3669  lea rsi, [rsp+0x10]
000074267fbd366e  lea rdx, [rsp+0x20]
000074267fbd3673  lea rcx, [rsp+0x30]
000074267fbd3678  mov r8d, 0x00
000074267fbd367e  lea r9, [r15+0x3A8]
000074267fbd3685  movaps [rdi], xmm15
000074267fbd3689  movaps [rsi], xmm5
000074267fbd368c  movaps [rdx], xmm1
000074267fbd368f  movaps [rcx], xmm14
000074267fbd3693  mov rax, 0x56D4E47AEA50
000074267fbd369d  call rax
000074267fbd369f  movaps xmm15, [rsp]
000074267fbd36a4  add rsp, 0x40
000074267fbd36a8  vmovaps xmm0, [rsp]
000074267fbd36ad  vmovaps xmm1, [rsp+0x10]
000074267fbd36b3  vmovaps xmm2, [rsp+0x20]
000074267fbd36b9  vmovaps xmm3, [rsp+0x30]
000074267fbd36bf  vmovaps xmm4, [rsp+0x40]
000074267fbd36c5  vmovaps xmm5, [rsp+0x50]
000074267fbd36cb  vmovaps xmm6, [rsp+0x60]
000074267fbd36d1  vmovaps xmm7, [rsp+0x70]
000074267fbd36d7  vmovaps xmm8, [rsp+0x80]
000074267fbd36e0  vmovaps xmm9, [rsp+0x90]
000074267fbd36e9  vmovaps xmm10, [rsp+0xA0]
000074267fbd36f2  vmovaps xmm11, [rsp+0xB0]
000074267fbd36fb  vmovaps xmm12, [rsp+0xC0]
000074267fbd3704  vmovaps xmm13, [rsp+0xD0]
000074267fbd370d  vmovaps xmm14, [rsp+0xE0]
000074267fbd3716  add rsp, 0xF0
000074267fbd371d  pop r11
000074267fbd371f  pop r10
000074267fbd3721  pop r9
000074267fbd3723  pop r8
000074267fbd3725  pop rsi
000074267fbd3726  pop rdi
000074267fbd3727  pop rdx
000074267fbd3728  pop rcx
000074267fbd3729  pop rax
000074267fbd372a  add rsp, 0x08
000074267fbd372e  jmp 0x000074267FBD28D0
000074267fbd3733  call 0x000074267F9FF430
000074267fbd3738  jmp 0x000074267FBD295D
000074267fbd373d  sub rsp, 0x08
000074267fbd3741  push rax
000074267fbd3742  push rcx
000074267fbd3743  push rdx
000074267fbd3744  push rdi
000074267fbd3745  push rsi
000074267fbd3746  push r8
000074267fbd3748  push r9
000074267fbd374a  push r10
000074267fbd374c  push r11
000074267fbd374e  sub rsp, 0xF0
000074267fbd3755  vmovaps [rsp], xmm0
000074267fbd375a  vmovaps [rsp+0x10], xmm1
000074267fbd3760  vmovaps [rsp+0x20], xmm2
000074267fbd3766  vmovaps [rsp+0x30], xmm3
000074267fbd376c  vmovaps [rsp+0x40], xmm4
000074267fbd3772  vmovaps [rsp+0x50], xmm5
000074267fbd3778  vmovaps [rsp+0x60], xmm6
000074267fbd377e  vmovaps [rsp+0x70], xmm7
000074267fbd3784  vmovaps [rsp+0x80], xmm8
000074267fbd378d  vmovaps [rsp+0x90], xmm9
000074267fbd3796  vmovaps [rsp+0xA0], xmm10
000074267fbd379f  vmovaps [rsp+0xB0], xmm11
000074267fbd37a8  vmovaps [rsp+0xC0], xmm12
000074267fbd37b1  vmovaps [rsp+0xD0], xmm14
000074267fbd37ba  vmovaps [rsp+0xE0], xmm15
000074267fbd37c3  sub rsp, 0x40
000074267fbd37c7  lea rdi, [rsp]
000074267fbd37cb  lea rsi, [rsp+0x10]
000074267fbd37d0  lea rdx, [rsp+0x20]
000074267fbd37d5  lea rcx, [rsp+0x30]
000074267fbd37da  mov r8d, 0x00
000074267fbd37e0  lea r9, [r15+0x3A8]
000074267fbd37e7  movaps [rdi], xmm13
000074267fbd37eb  movaps [rsi], xmm1
000074267fbd37ee  movaps [rdx], xmm15
000074267fbd37f2  movaps [rcx], xmm14
000074267fbd37f6  mov rax, 0x56D4E47AEA50
000074267fbd3800  call rax
000074267fbd3802  movaps xmm13, [rsp]
000074267fbd3807  add rsp, 0x40
000074267fbd380b  vmovaps xmm0, [rsp]
000074267fbd3810  vmovaps xmm1, [rsp+0x10]
000074267fbd3816  vmovaps xmm2, [rsp+0x20]
000074267fbd381c  vmovaps xmm3, [rsp+0x30]
000074267fbd3822  vmovaps xmm4, [rsp+0x40]
000074267fbd3828  vmovaps xmm5, [rsp+0x50]
000074267fbd382e  vmovaps xmm6, [rsp+0x60]
000074267fbd3834  vmovaps xmm7, [rsp+0x70]
000074267fbd383a  vmovaps xmm8, [rsp+0x80]
000074267fbd3843  vmovaps xmm9, [rsp+0x90]
000074267fbd384c  vmovaps xmm10, [rsp+0xA0]
000074267fbd3855  vmovaps xmm11, [rsp+0xB0]
000074267fbd385e  vmovaps xmm12, [rsp+0xC0]
000074267fbd3867  vmovaps xmm14, [rsp+0xD0]
000074267fbd3870  vmovaps xmm15, [rsp+0xE0]
000074267fbd3879  add rsp, 0xF0
000074267fbd3880  pop r11
000074267fbd3882  pop r10
000074267fbd3884  pop r9
000074267fbd3886  pop r8
000074267fbd3888  pop rsi
000074267fbd3889  pop rdi
000074267fbd388a  pop rdx
000074267fbd388b  pop rcx
000074267fbd388c  pop rax
000074267fbd388d  add rsp, 0x08
000074267fbd3891  jmp 0x000074267FBD29C1
000074267fbd3896  call 0x000074267F9FF430
000074267fbd389b  jmp 0x000074267FBD29CE
000074267fbd38a0  sub rsp, 0x08
000074267fbd38a4  push rax
000074267fbd38a5  push rcx
000074267fbd38a6  push rdx
000074267fbd38a7  push rdi
000074267fbd38a8  push rsi
000074267fbd38a9  push r8
000074267fbd38ab  push r9
000074267fbd38ad  push r10
000074267fbd38af  push r11
000074267fbd38b1  sub rsp, 0xF0
000074267fbd38b8  vmovaps [rsp], xmm0
000074267fbd38bd  vmovaps [rsp+0x10], xmm1
000074267fbd38c3  vmovaps [rsp+0x20], xmm2
000074267fbd38c9  vmovaps [rsp+0x30], xmm3
000074267fbd38cf  vmovaps [rsp+0x40], xmm4
000074267fbd38d5  vmovaps [rsp+0x50], xmm5
000074267fbd38db  vmovaps [rsp+0x60], xmm6
000074267fbd38e1  vmovaps [rsp+0x70], xmm7
000074267fbd38e7  vmovaps [rsp+0x80], xmm8
000074267fbd38f0  vmovaps [rsp+0x90], xmm9
000074267fbd38f9  vmovaps [rsp+0xA0], xmm10
000074267fbd3902  vmovaps [rsp+0xB0], xmm11
000074267fbd390b  vmovaps [rsp+0xC0], xmm13
000074267fbd3914  vmovaps [rsp+0xD0], xmm14
000074267fbd391d  vmovaps [rsp+0xE0], xmm15
000074267fbd3926  sub rsp, 0x40
000074267fbd392a  lea rdi, [rsp]
000074267fbd392e  lea rsi, [rsp+0x10]
000074267fbd3933  lea rdx, [rsp+0x20]
000074267fbd3938  lea rcx, [rsp+0x30]
000074267fbd393d  mov r8d, 0x00
000074267fbd3943  lea r9, [r15+0x3A8]
000074267fbd394a  movaps [rdi], xmm12
000074267fbd394e  movaps [rsi], xmm15
000074267fbd3952  movaps [rdx], xmm1
000074267fbd3955  movaps [rcx], xmm14
000074267fbd3959  mov rax, 0x56D4E47AEA50
000074267fbd3963  call rax
000074267fbd3965  movaps xmm12, [rsp]
000074267fbd396a  add rsp, 0x40
000074267fbd396e  vmovaps xmm0, [rsp]
000074267fbd3973  vmovaps xmm1, [rsp+0x10]
000074267fbd3979  vmovaps xmm2, [rsp+0x20]
000074267fbd397f  vmovaps xmm3, [rsp+0x30]
000074267fbd3985  vmovaps xmm4, [rsp+0x40]
000074267fbd398b  vmovaps xmm5, [rsp+0x50]
000074267fbd3991  vmovaps xmm6, [rsp+0x60]
000074267fbd3997  vmovaps xmm7, [rsp+0x70]
000074267fbd399d  vmovaps xmm8, [rsp+0x80]
000074267fbd39a6  vmovaps xmm9, [rsp+0x90]
000074267fbd39af  vmovaps xmm10, [rsp+0xA0]
000074267fbd39b8  vmovaps xmm11, [rsp+0xB0]
000074267fbd39c1  vmovaps xmm13, [rsp+0xC0]
000074267fbd39ca  vmovaps xmm14, [rsp+0xD0]
000074267fbd39d3  vmovaps xmm15, [rsp+0xE0]
000074267fbd39dc  add rsp, 0xF0
000074267fbd39e3  pop r11
000074267fbd39e5  pop r10
000074267fbd39e7  pop r9
000074267fbd39e9  pop r8
000074267fbd39eb  pop rsi
000074267fbd39ec  pop rdi
000074267fbd39ed  pop rdx
000074267fbd39ee  pop rcx
000074267fbd39ef  pop rax
000074267fbd39f0  add rsp, 0x08
000074267fbd39f4  jmp 0x000074267FBD29FA
000074267fbd39f9  sub rsp, 0x08
000074267fbd39fd  push rax
000074267fbd39fe  push rcx
000074267fbd39ff  push rdx
000074267fbd3a00  push rdi
000074267fbd3a01  push rsi
000074267fbd3a02  push r8
000074267fbd3a04  push r9
000074267fbd3a06  push r10
000074267fbd3a08  push r11
000074267fbd3a0a  sub rsp, 0xF0
000074267fbd3a11  vmovaps [rsp], xmm0
000074267fbd3a16  vmovaps [rsp+0x10], xmm1
000074267fbd3a1c  vmovaps [rsp+0x20], xmm2
000074267fbd3a22  vmovaps [rsp+0x30], xmm3
000074267fbd3a28  vmovaps [rsp+0x40], xmm4
000074267fbd3a2e  vmovaps [rsp+0x50], xmm5
000074267fbd3a34  vmovaps [rsp+0x60], xmm6
000074267fbd3a3a  vmovaps [rsp+0x70], xmm7
000074267fbd3a40  vmovaps [rsp+0x80], xmm8
000074267fbd3a49  vmovaps [rsp+0x90], xmm9
000074267fbd3a52  vmovaps [rsp+0xA0], xmm10
000074267fbd3a5b  vmovaps [rsp+0xB0], xmm11
000074267fbd3a64  vmovaps [rsp+0xC0], xmm12
000074267fbd3a6d  vmovaps [rsp+0xD0], xmm14
000074267fbd3a76  vmovaps [rsp+0xE0], xmm15
000074267fbd3a7f  sub rsp, 0x40
000074267fbd3a83  lea rdi, [rsp]
000074267fbd3a87  lea rsi, [rsp+0x10]
000074267fbd3a8c  lea rdx, [rsp+0x20]
000074267fbd3a91  lea rcx, [rsp+0x30]
000074267fbd3a96  mov r8d, 0x00
000074267fbd3a9c  lea r9, [r15+0x3A8]
000074267fbd3aa3  movaps [rdi], xmm13
000074267fbd3aa7  movaps [rsi], xmm1
000074267fbd3aaa  movaps [rdx], xmm15
000074267fbd3aae  movaps [rcx], xmm14
000074267fbd3ab2  mov rax, 0x56D4E47AEA50
000074267fbd3abc  call rax
000074267fbd3abe  movaps xmm13, [rsp]
000074267fbd3ac3  add rsp, 0x40
000074267fbd3ac7  vmovaps xmm0, [rsp]
000074267fbd3acc  vmovaps xmm1, [rsp+0x10]
000074267fbd3ad2  vmovaps xmm2, [rsp+0x20]
000074267fbd3ad8  vmovaps xmm3, [rsp+0x30]
000074267fbd3ade  vmovaps xmm4, [rsp+0x40]
000074267fbd3ae4  vmovaps xmm5, [rsp+0x50]
000074267fbd3aea  vmovaps xmm6, [rsp+0x60]
000074267fbd3af0  vmovaps xmm7, [rsp+0x70]
000074267fbd3af6  vmovaps xmm8, [rsp+0x80]
000074267fbd3aff  vmovaps xmm9, [rsp+0x90]
000074267fbd3b08  vmovaps xmm10, [rsp+0xA0]
000074267fbd3b11  vmovaps xmm11, [rsp+0xB0]
000074267fbd3b1a  vmovaps xmm12, [rsp+0xC0]
000074267fbd3b23  vmovaps xmm14, [rsp+0xD0]
000074267fbd3b2c  vmovaps xmm15, [rsp+0xE0]
000074267fbd3b35  add rsp, 0xF0
000074267fbd3b3c  pop r11
000074267fbd3b3e  pop r10
000074267fbd3b40  pop r9
000074267fbd3b42  pop r8
000074267fbd3b44  pop rsi
000074267fbd3b45  pop rdi
000074267fbd3b46  pop rdx
000074267fbd3b47  pop rcx
000074267fbd3b48  pop rax
000074267fbd3b49  add rsp, 0x08
000074267fbd3b4d  jmp 0x000074267FBD2B77
000074267fbd3b52  sub rsp, 0x08
000074267fbd3b56  push rax
000074267fbd3b57  push rcx
000074267fbd3b58  push rdx
000074267fbd3b59  push rdi
000074267fbd3b5a  push rsi
000074267fbd3b5b  push r8
000074267fbd3b5d  push r9
000074267fbd3b5f  push r10
000074267fbd3b61  push r11
000074267fbd3b63  sub rsp, 0xF0
000074267fbd3b6a  vmovaps [rsp], xmm0
000074267fbd3b6f  vmovaps [rsp+0x10], xmm1
000074267fbd3b75  vmovaps [rsp+0x20], xmm2
000074267fbd3b7b  vmovaps [rsp+0x30], xmm3
000074267fbd3b81  vmovaps [rsp+0x40], xmm4
000074267fbd3b87  vmovaps [rsp+0x50], xmm5
000074267fbd3b8d  vmovaps [rsp+0x60], xmm6
000074267fbd3b93  vmovaps [rsp+0x70], xmm7
000074267fbd3b99  vmovaps [rsp+0x80], xmm8
000074267fbd3ba2  vmovaps [rsp+0x90], xmm9
000074267fbd3bab  vmovaps [rsp+0xA0], xmm10
000074267fbd3bb4  vmovaps [rsp+0xB0], xmm11
000074267fbd3bbd  vmovaps [rsp+0xC0], xmm13
000074267fbd3bc6  vmovaps [rsp+0xD0], xmm14
000074267fbd3bcf  vmovaps [rsp+0xE0], xmm15
000074267fbd3bd8  sub rsp, 0x40
000074267fbd3bdc  lea rdi, [rsp]
000074267fbd3be0  lea rsi, [rsp+0x10]
000074267fbd3be5  lea rdx, [rsp+0x20]
000074267fbd3bea  lea rcx, [rsp+0x30]
000074267fbd3bef  mov r8d, 0x00
000074267fbd3bf5  lea r9, [r15+0x3A8]
000074267fbd3bfc  movaps [rdi], xmm12
000074267fbd3c00  movaps [rsi], xmm15
000074267fbd3c04  movaps [rdx], xmm14
000074267fbd3c08  movaps [rcx], xmm1
000074267fbd3c0b  mov rax, 0x56D4E47AEA50
000074267fbd3c15  call rax
000074267fbd3c17  movaps xmm12, [rsp]
000074267fbd3c1c  add rsp, 0x40
000074267fbd3c20  vmovaps xmm0, [rsp]
000074267fbd3c25  vmovaps xmm1, [rsp+0x10]
000074267fbd3c2b  vmovaps xmm2, [rsp+0x20]
000074267fbd3c31  vmovaps xmm3, [rsp+0x30]
000074267fbd3c37  vmovaps xmm4, [rsp+0x40]
000074267fbd3c3d  vmovaps xmm5, [rsp+0x50]
000074267fbd3c43  vmovaps xmm6, [rsp+0x60]
000074267fbd3c49  vmovaps xmm7, [rsp+0x70]
000074267fbd3c4f  vmovaps xmm8, [rsp+0x80]
000074267fbd3c58  vmovaps xmm9, [rsp+0x90]
000074267fbd3c61  vmovaps xmm10, [rsp+0xA0]
000074267fbd3c6a  vmovaps xmm11, [rsp+0xB0]
000074267fbd3c73  vmovaps xmm13, [rsp+0xC0]
000074267fbd3c7c  vmovaps xmm14, [rsp+0xD0]
000074267fbd3c85  vmovaps xmm15, [rsp+0xE0]
000074267fbd3c8e  add rsp, 0xF0
000074267fbd3c95  pop r11
000074267fbd3c97  pop r10
000074267fbd3c99  pop r9
000074267fbd3c9b  pop r8
000074267fbd3c9d  pop rsi
000074267fbd3c9e  pop rdi
000074267fbd3c9f  pop rdx
000074267fbd3ca0  pop rcx
000074267fbd3ca1  pop rax
000074267fbd3ca2  add rsp, 0x08
000074267fbd3ca6  jmp 0x000074267FBD2BB2
000074267fbd3cab  sub rsp, 0x08
000074267fbd3caf  push rax
000074267fbd3cb0  push rcx
000074267fbd3cb1  push rdx
000074267fbd3cb2  push rdi
000074267fbd3cb3  push rsi
000074267fbd3cb4  push r8
000074267fbd3cb6  push r9
000074267fbd3cb8  push r10
000074267fbd3cba  push r11
000074267fbd3cbc  sub rsp, 0xF0
000074267fbd3cc3  vmovaps [rsp], xmm0
000074267fbd3cc8  vmovaps [rsp+0x10], xmm1
000074267fbd3cce  vmovaps [rsp+0x20], xmm2
000074267fbd3cd4  vmovaps [rsp+0x30], xmm3
000074267fbd3cda  vmovaps [rsp+0x40], xmm4
000074267fbd3ce0  vmovaps [rsp+0x50], xmm5
000074267fbd3ce6  vmovaps [rsp+0x60], xmm6
000074267fbd3cec  vmovaps [rsp+0x70], xmm7
000074267fbd3cf2  vmovaps [rsp+0x80], xmm8
000074267fbd3cfb  vmovaps [rsp+0x90], xmm9
000074267fbd3d04  vmovaps [rsp+0xA0], xmm10
000074267fbd3d0d  vmovaps [rsp+0xB0], xmm11
000074267fbd3d16  vmovaps [rsp+0xC0], xmm12
000074267fbd3d1f  vmovaps [rsp+0xD0], xmm14
000074267fbd3d28  vmovaps [rsp+0xE0], xmm15
000074267fbd3d31  sub rsp, 0x40
000074267fbd3d35  lea rdi, [rsp]
000074267fbd3d39  lea rsi, [rsp+0x10]
000074267fbd3d3e  lea rdx, [rsp+0x20]
000074267fbd3d43  lea rcx, [rsp+0x30]
000074267fbd3d48  mov r8d, 0x00
000074267fbd3d4e  lea r9, [r15+0x3A8]
000074267fbd3d55  movaps [rdi], xmm13
000074267fbd3d59  movaps [rsi], xmm15
000074267fbd3d5d  movaps [rdx], xmm14
000074267fbd3d61  movaps [rcx], xmm1
000074267fbd3d64  mov rax, 0x56D4E47AEA50
000074267fbd3d6e  call rax
000074267fbd3d70  movaps xmm13, [rsp]
000074267fbd3d75  add rsp, 0x40
000074267fbd3d79  vmovaps xmm0, [rsp]
000074267fbd3d7e  vmovaps xmm1, [rsp+0x10]
000074267fbd3d84  vmovaps xmm2, [rsp+0x20]
000074267fbd3d8a  vmovaps xmm3, [rsp+0x30]
000074267fbd3d90  vmovaps xmm4, [rsp+0x40]
000074267fbd3d96  vmovaps xmm5, [rsp+0x50]
000074267fbd3d9c  vmovaps xmm6, [rsp+0x60]
000074267fbd3da2  vmovaps xmm7, [rsp+0x70]
000074267fbd3da8  vmovaps xmm8, [rsp+0x80]
000074267fbd3db1  vmovaps xmm9, [rsp+0x90]
000074267fbd3dba  vmovaps xmm10, [rsp+0xA0]
000074267fbd3dc3  vmovaps xmm11, [rsp+0xB0]
000074267fbd3dcc  vmovaps xmm12, [rsp+0xC0]
000074267fbd3dd5  vmovaps xmm14, [rsp+0xD0]
000074267fbd3dde  vmovaps xmm15, [rsp+0xE0]
000074267fbd3de7  add rsp, 0xF0
000074267fbd3dee  pop r11
000074267fbd3df0  pop r10
000074267fbd3df2  pop r9
000074267fbd3df4  pop r8
000074267fbd3df6  pop rsi
000074267fbd3df7  pop rdi
000074267fbd3df8  pop rdx
000074267fbd3df9  pop rcx
000074267fbd3dfa  pop rax
000074267fbd3dfb  add rsp, 0x08
000074267fbd3dff  jmp 0x000074267FBD2BEA
000074267fbd3e04  sub rsp, 0x08
000074267fbd3e08  push rax
000074267fbd3e09  push rcx
000074267fbd3e0a  push rdx
000074267fbd3e0b  push rdi
000074267fbd3e0c  push rsi
000074267fbd3e0d  push r8
000074267fbd3e0f  push r9
000074267fbd3e11  push r10
000074267fbd3e13  push r11
000074267fbd3e15  sub rsp, 0xF0
000074267fbd3e1c  vmovaps [rsp], xmm0
000074267fbd3e21  vmovaps [rsp+0x10], xmm1
000074267fbd3e27  vmovaps [rsp+0x20], xmm2
000074267fbd3e2d  vmovaps [rsp+0x30], xmm3
000074267fbd3e33  vmovaps [rsp+0x40], xmm4
000074267fbd3e39  vmovaps [rsp+0x50], xmm5
000074267fbd3e3f  vmovaps [rsp+0x60], xmm6
000074267fbd3e45  vmovaps [rsp+0x70], xmm7
000074267fbd3e4b  vmovaps [rsp+0x80], xmm8
000074267fbd3e54  vmovaps [rsp+0x90], xmm9
000074267fbd3e5d  vmovaps [rsp+0xA0], xmm10
000074267fbd3e66  vmovaps [rsp+0xB0], xmm11
000074267fbd3e6f  vmovaps [rsp+0xC0], xmm13
000074267fbd3e78  vmovaps [rsp+0xD0], xmm14
000074267fbd3e81  vmovaps [rsp+0xE0], xmm15
000074267fbd3e8a  sub rsp, 0x40
000074267fbd3e8e  lea rdi, [rsp]
000074267fbd3e92  lea rsi, [rsp+0x10]
000074267fbd3e97  lea rdx, [rsp+0x20]
000074267fbd3e9c  lea rcx, [rsp+0x30]
000074267fbd3ea1  mov r8d, 0x00
000074267fbd3ea7  lea r9, [r15+0x3A8]
000074267fbd3eae  movaps [rdi], xmm12
000074267fbd3eb2  movaps [rsi], xmm15
000074267fbd3eb6  movaps [rdx], xmm14
000074267fbd3eba  movaps [rcx], xmm1
000074267fbd3ebd  mov rax, 0x56D4E47AEA50
000074267fbd3ec7  call rax
000074267fbd3ec9  movaps xmm12, [rsp]
000074267fbd3ece  add rsp, 0x40
000074267fbd3ed2  vmovaps xmm0, [rsp]
000074267fbd3ed7  vmovaps xmm1, [rsp+0x10]
000074267fbd3edd  vmovaps xmm2, [rsp+0x20]
000074267fbd3ee3  vmovaps xmm3, [rsp+0x30]
000074267fbd3ee9  vmovaps xmm4, [rsp+0x40]
000074267fbd3eef  vmovaps xmm5, [rsp+0x50]
000074267fbd3ef5  vmovaps xmm6, [rsp+0x60]
000074267fbd3efb  vmovaps xmm7, [rsp+0x70]
000074267fbd3f01  vmovaps xmm8, [rsp+0x80]
000074267fbd3f0a  vmovaps xmm9, [rsp+0x90]
000074267fbd3f13  vmovaps xmm10, [rsp+0xA0]
000074267fbd3f1c  vmovaps xmm11, [rsp+0xB0]
000074267fbd3f25  vmovaps xmm13, [rsp+0xC0]
000074267fbd3f2e  vmovaps xmm14, [rsp+0xD0]
000074267fbd3f37  vmovaps xmm15, [rsp+0xE0]
000074267fbd3f40  add rsp, 0xF0
000074267fbd3f47  pop r11
000074267fbd3f49  pop r10
000074267fbd3f4b  pop r9
000074267fbd3f4d  pop r8
000074267fbd3f4f  pop rsi
000074267fbd3f50  pop rdi
000074267fbd3f51  pop rdx
000074267fbd3f52  pop rcx
000074267fbd3f53  pop rax
000074267fbd3f54  add rsp, 0x08
000074267fbd3f58  jmp 0x000074267FBD2C3D
000074267fbd3f5d  sub rsp, 0x08
000074267fbd3f61  push rax
000074267fbd3f62  push rcx
000074267fbd3f63  push rdx
000074267fbd3f64  push rdi
000074267fbd3f65  push rsi
000074267fbd3f66  push r8
000074267fbd3f68  push r9
000074267fbd3f6a  push r10
000074267fbd3f6c  push r11
000074267fbd3f6e  sub rsp, 0xF0
000074267fbd3f75  vmovaps [rsp], xmm0
000074267fbd3f7a  vmovaps [rsp+0x10], xmm1
000074267fbd3f80  vmovaps [rsp+0x20], xmm2
000074267fbd3f86  vmovaps [rsp+0x30], xmm3
000074267fbd3f8c  vmovaps [rsp+0x40], xmm4
000074267fbd3f92  vmovaps [rsp+0x50], xmm5
000074267fbd3f98  vmovaps [rsp+0x60], xmm6
000074267fbd3f9e  vmovaps [rsp+0x70], xmm7
000074267fbd3fa4  vmovaps [rsp+0x80], xmm8
000074267fbd3fad  vmovaps [rsp+0x90], xmm9
000074267fbd3fb6  vmovaps [rsp+0xA0], xmm10
000074267fbd3fbf  vmovaps [rsp+0xB0], xmm11
000074267fbd3fc8  vmovaps [rsp+0xC0], xmm12
000074267fbd3fd1  vmovaps [rsp+0xD0], xmm13
000074267fbd3fda  vmovaps [rsp+0xE0], xmm15
000074267fbd3fe3  sub rsp, 0x40
000074267fbd3fe7  lea rdi, [rsp]
000074267fbd3feb  lea rsi, [rsp+0x10]
000074267fbd3ff0  lea rdx, [rsp+0x20]
000074267fbd3ff5  lea rcx, [rsp+0x30]
000074267fbd3ffa  mov r8d, 0x00
000074267fbd4000  lea r9, [r15+0x3A8]
000074267fbd4007  movaps [rdi], xmm14
000074267fbd400b  movaps [rsi], xmm3
000074267fbd400e  movaps [rdx], xmm1
000074267fbd4011  movaps [rcx], xmm15
000074267fbd4015  mov rax, 0x56D4E47AEA50
000074267fbd401f  call rax
000074267fbd4021  movaps xmm14, [rsp]
000074267fbd4026  add rsp, 0x40
000074267fbd402a  vmovaps xmm0, [rsp]
000074267fbd402f  vmovaps xmm1, [rsp+0x10]
000074267fbd4035  vmovaps xmm2, [rsp+0x20]
000074267fbd403b  vmovaps xmm3, [rsp+0x30]
000074267fbd4041  vmovaps xmm4, [rsp+0x40]
000074267fbd4047  vmovaps xmm5, [rsp+0x50]
000074267fbd404d  vmovaps xmm6, [rsp+0x60]
000074267fbd4053  vmovaps xmm7, [rsp+0x70]
000074267fbd4059  vmovaps xmm8, [rsp+0x80]
000074267fbd4062  vmovaps xmm9, [rsp+0x90]
000074267fbd406b  vmovaps xmm10, [rsp+0xA0]
000074267fbd4074  vmovaps xmm11, [rsp+0xB0]
000074267fbd407d  vmovaps xmm12, [rsp+0xC0]
000074267fbd4086  vmovaps xmm13, [rsp+0xD0]
000074267fbd408f  vmovaps xmm15, [rsp+0xE0]
000074267fbd4098  add rsp, 0xF0
000074267fbd409f  pop r11
000074267fbd40a1  pop r10
000074267fbd40a3  pop r9
000074267fbd40a5  pop r8
000074267fbd40a7  pop rsi
000074267fbd40a8  pop rdi
000074267fbd40a9  pop rdx
000074267fbd40aa  pop rcx
000074267fbd40ab  pop rax
000074267fbd40ac  add rsp, 0x08
000074267fbd40b0  jmp 0x000074267FBD2CF7
000074267fbd40b5  sub rsp, 0x08
000074267fbd40b9  push rax
000074267fbd40ba  push rcx
000074267fbd40bb  push rdx
000074267fbd40bc  push rdi
000074267fbd40bd  push rsi
000074267fbd40be  push r8
000074267fbd40c0  push r9
000074267fbd40c2  push r10
000074267fbd40c4  push r11
000074267fbd40c6  sub rsp, 0xF0
000074267fbd40cd  vmovaps [rsp], xmm0
000074267fbd40d2  vmovaps [rsp+0x10], xmm1
000074267fbd40d8  vmovaps [rsp+0x20], xmm2
000074267fbd40de  vmovaps [rsp+0x30], xmm3
000074267fbd40e4  vmovaps [rsp+0x40], xmm4
000074267fbd40ea  vmovaps [rsp+0x50], xmm5
000074267fbd40f0  vmovaps [rsp+0x60], xmm6
000074267fbd40f6  vmovaps [rsp+0x70], xmm7
000074267fbd40fc  vmovaps [rsp+0x80], xmm8
000074267fbd4105  vmovaps [rsp+0x90], xmm9
000074267fbd410e  vmovaps [rsp+0xA0], xmm10
000074267fbd4117  vmovaps [rsp+0xB0], xmm11
000074267fbd4120  vmovaps [rsp+0xC0], xmm12
000074267fbd4129  vmovaps [rsp+0xD0], xmm14
000074267fbd4132  vmovaps [rsp+0xE0], xmm15
000074267fbd413b  sub rsp, 0x40
000074267fbd413f  lea rdi, [rsp]
000074267fbd4143  lea rsi, [rsp+0x10]
000074267fbd4148  lea rdx, [rsp+0x20]
000074267fbd414d  lea rcx, [rsp+0x30]
000074267fbd4152  mov r8d, 0x00
000074267fbd4158  lea r9, [r15+0x3A8]
000074267fbd415f  movaps [rdi], xmm13
000074267fbd4163  movaps [rsi], xmm15
000074267fbd4167  movaps [rdx], xmm10
000074267fbd416b  movaps [rcx], xmm1
000074267fbd416e  mov rax, 0x56D4E47AEA50
000074267fbd4178  call rax
000074267fbd417a  movaps xmm13, [rsp]
000074267fbd417f  add rsp, 0x40
000074267fbd4183  vmovaps xmm0, [rsp]
000074267fbd4188  vmovaps xmm1, [rsp+0x10]
000074267fbd418e  vmovaps xmm2, [rsp+0x20]
000074267fbd4194  vmovaps xmm3, [rsp+0x30]
000074267fbd419a  vmovaps xmm4, [rsp+0x40]
000074267fbd41a0  vmovaps xmm5, [rsp+0x50]
000074267fbd41a6  vmovaps xmm6, [rsp+0x60]
000074267fbd41ac  vmovaps xmm7, [rsp+0x70]
000074267fbd41b2  vmovaps xmm8, [rsp+0x80]
000074267fbd41bb  vmovaps xmm9, [rsp+0x90]
000074267fbd41c4  vmovaps xmm10, [rsp+0xA0]
000074267fbd41cd  vmovaps xmm11, [rsp+0xB0]
000074267fbd41d6  vmovaps xmm12, [rsp+0xC0]
000074267fbd41df  vmovaps xmm14, [rsp+0xD0]
000074267fbd41e8  vmovaps xmm15, [rsp+0xE0]
000074267fbd41f1  add rsp, 0xF0
000074267fbd41f8  pop r11
000074267fbd41fa  pop r10
000074267fbd41fc  pop r9
000074267fbd41fe  pop r8
000074267fbd4200  pop rsi
000074267fbd4201  pop rdi
000074267fbd4202  pop rdx
000074267fbd4203  pop rcx
000074267fbd4204  pop rax
000074267fbd4205  add rsp, 0x08
000074267fbd4209  jmp 0x000074267FBD2D26
000074267fbd420e  sub rsp, 0x08
000074267fbd4212  push rax
000074267fbd4213  push rcx
000074267fbd4214  push rdx
000074267fbd4215  push rdi
000074267fbd4216  push rsi
000074267fbd4217  push r8
000074267fbd4219  push r9
000074267fbd421b  push r10
000074267fbd421d  push r11
000074267fbd421f  sub rsp, 0xF0
000074267fbd4226  vmovaps [rsp], xmm0
000074267fbd422b  vmovaps [rsp+0x10], xmm1
000074267fbd4231  vmovaps [rsp+0x20], xmm2
000074267fbd4237  vmovaps [rsp+0x30], xmm3
000074267fbd423d  vmovaps [rsp+0x40], xmm4
000074267fbd4243  vmovaps [rsp+0x50], xmm5
000074267fbd4249  vmovaps [rsp+0x60], xmm6
000074267fbd424f  vmovaps [rsp+0x70], xmm7
000074267fbd4255  vmovaps [rsp+0x80], xmm8
000074267fbd425e  vmovaps [rsp+0x90], xmm9
000074267fbd4267  vmovaps [rsp+0xA0], xmm11
000074267fbd4270  vmovaps [rsp+0xB0], xmm12
000074267fbd4279  vmovaps [rsp+0xC0], xmm13
000074267fbd4282  vmovaps [rsp+0xD0], xmm14
000074267fbd428b  vmovaps [rsp+0xE0], xmm15
000074267fbd4294  sub rsp, 0x40
000074267fbd4298  lea rdi, [rsp]
000074267fbd429c  lea rsi, [rsp+0x10]
000074267fbd42a1  lea rdx, [rsp+0x20]
000074267fbd42a6  lea rcx, [rsp+0x30]
000074267fbd42ab  mov r8d, 0x00
000074267fbd42b1  lea r9, [r15+0x3A8]
000074267fbd42b8  movaps [rdi], xmm10
000074267fbd42bc  movaps [rsi], xmm15
000074267fbd42c0  movaps [rdx], xmm11
000074267fbd42c4  movaps [rcx], xmm1
000074267fbd42c7  mov rax, 0x56D4E47AEA50
000074267fbd42d1  call rax
000074267fbd42d3  movaps xmm10, [rsp]
000074267fbd42d8  add rsp, 0x40
000074267fbd42dc  vmovaps xmm0, [rsp]
000074267fbd42e1  vmovaps xmm1, [rsp+0x10]
000074267fbd42e7  vmovaps xmm2, [rsp+0x20]
000074267fbd42ed  vmovaps xmm3, [rsp+0x30]
000074267fbd42f3  vmovaps xmm4, [rsp+0x40]
000074267fbd42f9  vmovaps xmm5, [rsp+0x50]
000074267fbd42ff  vmovaps xmm6, [rsp+0x60]
000074267fbd4305  vmovaps xmm7, [rsp+0x70]
000074267fbd430b  vmovaps xmm8, [rsp+0x80]
000074267fbd4314  vmovaps xmm9, [rsp+0x90]
000074267fbd431d  vmovaps xmm11, [rsp+0xA0]
000074267fbd4326  vmovaps xmm12, [rsp+0xB0]
000074267fbd432f  vmovaps xmm13, [rsp+0xC0]
000074267fbd4338  vmovaps xmm14, [rsp+0xD0]
000074267fbd4341  vmovaps xmm15, [rsp+0xE0]
000074267fbd434a  add rsp, 0xF0
000074267fbd4351  pop r11
000074267fbd4353  pop r10
000074267fbd4355  pop r9
000074267fbd4357  pop r8
000074267fbd4359  pop rsi
000074267fbd435a  pop rdi
000074267fbd435b  pop rdx
000074267fbd435c  pop rcx
000074267fbd435d  pop rax
000074267fbd435e  add rsp, 0x08
000074267fbd4362  jmp 0x000074267FBD2D55
000074267fbd4367  sub rsp, 0x08
000074267fbd436b  push rax
000074267fbd436c  push rcx
000074267fbd436d  push rdx
000074267fbd436e  push rdi
000074267fbd436f  push rsi
000074267fbd4370  push r8
000074267fbd4372  push r9
000074267fbd4374  push r10
000074267fbd4376  push r11
000074267fbd4378  sub rsp, 0xF0
000074267fbd437f  vmovaps [rsp], xmm0
000074267fbd4384  vmovaps [rsp+0x10], xmm1
000074267fbd438a  vmovaps [rsp+0x20], xmm2
000074267fbd4390  vmovaps [rsp+0x30], xmm3
000074267fbd4396  vmovaps [rsp+0x40], xmm4
000074267fbd439c  vmovaps [rsp+0x50], xmm5
000074267fbd43a2  vmovaps [rsp+0x60], xmm6
000074267fbd43a8  vmovaps [rsp+0x70], xmm7
000074267fbd43ae  vmovaps [rsp+0x80], xmm8
000074267fbd43b7  vmovaps [rsp+0x90], xmm9
000074267fbd43c0  vmovaps [rsp+0xA0], xmm10
000074267fbd43c9  vmovaps [rsp+0xB0], xmm11
000074267fbd43d2  vmovaps [rsp+0xC0], xmm12
000074267fbd43db  vmovaps [rsp+0xD0], xmm13
000074267fbd43e4  vmovaps [rsp+0xE0], xmm14
000074267fbd43ed  sub rsp, 0x40
000074267fbd43f1  lea rdi, [rsp]
000074267fbd43f5  lea rsi, [rsp+0x10]
000074267fbd43fa  lea rdx, [rsp+0x20]
000074267fbd43ff  lea rcx, [rsp+0x30]
000074267fbd4404  mov r8d, 0x00
000074267fbd440a  lea r9, [r15+0x3A8]
000074267fbd4411  movaps [rdi], xmm15
000074267fbd4415  movaps [rsi], xmm12
000074267fbd4419  movaps [rdx], xmm5
000074267fbd441c  movaps [rcx], xmm1
000074267fbd441f  mov rax, 0x56D4E47AEA50
000074267fbd4429  call rax
000074267fbd442b  movaps xmm15, [rsp]
000074267fbd4430  add rsp, 0x40
000074267fbd4434  vmovaps xmm0, [rsp]
000074267fbd4439  vmovaps xmm1, [rsp+0x10]
000074267fbd443f  vmovaps xmm2, [rsp+0x20]
000074267fbd4445  vmovaps xmm3, [rsp+0x30]
000074267fbd444b  vmovaps xmm4, [rsp+0x40]
000074267fbd4451  vmovaps xmm5, [rsp+0x50]
000074267fbd4457  vmovaps xmm6, [rsp+0x60]
000074267fbd445d  vmovaps xmm7, [rsp+0x70]
000074267fbd4463  vmovaps xmm8, [rsp+0x80]
000074267fbd446c  vmovaps xmm9, [rsp+0x90]
000074267fbd4475  vmovaps xmm10, [rsp+0xA0]
000074267fbd447e  vmovaps xmm11, [rsp+0xB0]
000074267fbd4487  vmovaps xmm12, [rsp+0xC0]
000074267fbd4490  vmovaps xmm13, [rsp+0xD0]
000074267fbd4499  vmovaps xmm14, [rsp+0xE0]
000074267fbd44a2  add rsp, 0xF0
000074267fbd44a9  pop r11
000074267fbd44ab  pop r10
000074267fbd44ad  pop r9
000074267fbd44af  pop r8
000074267fbd44b1  pop rsi
000074267fbd44b2  pop rdi
000074267fbd44b3  pop rdx
000074267fbd44b4  pop rcx
000074267fbd44b5  pop rax
000074267fbd44b6  add rsp, 0x08
000074267fbd44ba  jmp 0x000074267FBD2D7E
000074267fbd44bf  sub rsp, 0x08
000074267fbd44c3  push rax
000074267fbd44c4  push rcx
000074267fbd44c5  push rdx
000074267fbd44c6  push rdi
000074267fbd44c7  push rsi
000074267fbd44c8  push r8
000074267fbd44ca  push r9
000074267fbd44cc  push r10
000074267fbd44ce  push r11
000074267fbd44d0  sub rsp, 0xF0
000074267fbd44d7  vmovaps [rsp], xmm0
000074267fbd44dc  vmovaps [rsp+0x10], xmm1
000074267fbd44e2  vmovaps [rsp+0x20], xmm2
000074267fbd44e8  vmovaps [rsp+0x30], xmm3
000074267fbd44ee  vmovaps [rsp+0x40], xmm4
000074267fbd44f4  vmovaps [rsp+0x50], xmm6
000074267fbd44fa  vmovaps [rsp+0x60], xmm7
000074267fbd4500  vmovaps [rsp+0x70], xmm8
000074267fbd4506  vmovaps [rsp+0x80], xmm9
000074267fbd450f  vmovaps [rsp+0x90], xmm10
000074267fbd4518  vmovaps [rsp+0xA0], xmm11
000074267fbd4521  vmovaps [rsp+0xB0], xmm12
000074267fbd452a  vmovaps [rsp+0xC0], xmm13
000074267fbd4533  vmovaps [rsp+0xD0], xmm14
000074267fbd453c  vmovaps [rsp+0xE0], xmm15
000074267fbd4545  sub rsp, 0x40
000074267fbd4549  lea rdi, [rsp]
000074267fbd454d  lea rsi, [rsp+0x10]
000074267fbd4552  lea rdx, [rsp+0x20]
000074267fbd4557  lea rcx, [rsp+0x30]
000074267fbd455c  mov r8d, 0x00
000074267fbd4562  lea r9, [r15+0x3A8]
000074267fbd4569  movaps [rdi], xmm5
000074267fbd456c  movaps [rsi], xmm13
000074267fbd4570  movaps [rdx], xmm11
000074267fbd4574  movaps [rcx], xmm12
000074267fbd4578  mov rax, 0x56D4E47AEA50
000074267fbd4582  call rax
000074267fbd4584  movaps xmm5, [rsp]
000074267fbd4588  add rsp, 0x40
000074267fbd458c  vmovaps xmm0, [rsp]
000074267fbd4591  vmovaps xmm1, [rsp+0x10]
000074267fbd4597  vmovaps xmm2, [rsp+0x20]
000074267fbd459d  vmovaps xmm3, [rsp+0x30]
000074267fbd45a3  vmovaps xmm4, [rsp+0x40]
000074267fbd45a9  vmovaps xmm6, [rsp+0x50]
000074267fbd45af  vmovaps xmm7, [rsp+0x60]
000074267fbd45b5  vmovaps xmm8, [rsp+0x70]
000074267fbd45bb  vmovaps xmm9, [rsp+0x80]
000074267fbd45c4  vmovaps xmm10, [rsp+0x90]
000074267fbd45cd  vmovaps xmm11, [rsp+0xA0]
000074267fbd45d6  vmovaps xmm12, [rsp+0xB0]
000074267fbd45df  vmovaps xmm13, [rsp+0xC0]
000074267fbd45e8  vmovaps xmm14, [rsp+0xD0]
000074267fbd45f1  vmovaps xmm15, [rsp+0xE0]
000074267fbd45fa  add rsp, 0xF0
000074267fbd4601  pop r11
000074267fbd4603  pop r10
000074267fbd4605  pop r9
000074267fbd4607  pop r8
000074267fbd4609  pop rsi
000074267fbd460a  pop rdi
000074267fbd460b  pop rdx
000074267fbd460c  pop rcx
000074267fbd460d  pop rax
000074267fbd460e  add rsp, 0x08
000074267fbd4612  jmp 0x000074267FBD2DDD
000074267fbd4617  sub rsp, 0x08
000074267fbd461b  push rax
000074267fbd461c  push rcx
000074267fbd461d  push rdx
000074267fbd461e  push rdi
000074267fbd461f  push rsi
000074267fbd4620  push r8
000074267fbd4622  push r9
000074267fbd4624  push r10
000074267fbd4626  push r11
000074267fbd4628  sub rsp, 0xF0
000074267fbd462f  vmovaps [rsp], xmm0
000074267fbd4634  vmovaps [rsp+0x10], xmm1
000074267fbd463a  vmovaps [rsp+0x20], xmm2
000074267fbd4640  vmovaps [rsp+0x30], xmm3
000074267fbd4646  vmovaps [rsp+0x40], xmm4
000074267fbd464c  vmovaps [rsp+0x50], xmm5
000074267fbd4652  vmovaps [rsp+0x60], xmm6
000074267fbd4658  vmovaps [rsp+0x70], xmm7
000074267fbd465e  vmovaps [rsp+0x80], xmm8
000074267fbd4667  vmovaps [rsp+0x90], xmm9
000074267fbd4670  vmovaps [rsp+0xA0], xmm10
000074267fbd4679  vmovaps [rsp+0xB0], xmm11
000074267fbd4682  vmovaps [rsp+0xC0], xmm13
000074267fbd468b  vmovaps [rsp+0xD0], xmm14
000074267fbd4694  vmovaps [rsp+0xE0], xmm15
000074267fbd469d  sub rsp, 0x40
000074267fbd46a1  lea rdi, [rsp]
000074267fbd46a5  lea rsi, [rsp+0x10]
000074267fbd46aa  lea rdx, [rsp+0x20]
000074267fbd46af  lea rcx, [rsp+0x30]
000074267fbd46b4  mov r8d, 0x00
000074267fbd46ba  lea r9, [r15+0x3A8]
000074267fbd46c1  movaps [rdi], xmm12
000074267fbd46c5  movaps [rsi], xmm14
000074267fbd46c9  movaps [rdx], xmm9
000074267fbd46cd  movaps [rcx], xmm13
000074267fbd46d1  mov rax, 0x56D4E47AEA50
000074267fbd46db  call rax
000074267fbd46dd  movaps xmm12, [rsp]
000074267fbd46e2  add rsp, 0x40
000074267fbd46e6  vmovaps xmm0, [rsp]
000074267fbd46eb  vmovaps xmm1, [rsp+0x10]
000074267fbd46f1  vmovaps xmm2, [rsp+0x20]
000074267fbd46f7  vmovaps xmm3, [rsp+0x30]
000074267fbd46fd  vmovaps xmm4, [rsp+0x40]
000074267fbd4703  vmovaps xmm5, [rsp+0x50]
000074267fbd4709  vmovaps xmm6, [rsp+0x60]
000074267fbd470f  vmovaps xmm7, [rsp+0x70]
000074267fbd4715  vmovaps xmm8, [rsp+0x80]
000074267fbd471e  vmovaps xmm9, [rsp+0x90]
000074267fbd4727  vmovaps xmm10, [rsp+0xA0]
000074267fbd4730  vmovaps xmm11, [rsp+0xB0]
000074267fbd4739  vmovaps xmm13, [rsp+0xC0]
000074267fbd4742  vmovaps xmm14, [rsp+0xD0]
000074267fbd474b  vmovaps xmm15, [rsp+0xE0]
000074267fbd4754  add rsp, 0xF0
000074267fbd475b  pop r11
000074267fbd475d  pop r10
000074267fbd475f  pop r9
000074267fbd4761  pop r8
000074267fbd4763  pop rsi
000074267fbd4764  pop rdi
000074267fbd4765  pop rdx
000074267fbd4766  pop rcx
000074267fbd4767  pop rax
000074267fbd4768  add rsp, 0x08
000074267fbd476c  jmp 0x000074267FBD2E06
000074267fbd4771  call 0x000074267FA0D4E0
000074267fbd4776  jmp 0x000074267FBD2E13
000074267fbd477b  sub rsp, 0x08
000074267fbd477f  push rax
000074267fbd4780  push rcx
000074267fbd4781  push rdx
000074267fbd4782  push rdi
000074267fbd4783  push rsi
000074267fbd4784  push r8
000074267fbd4786  push r9
000074267fbd4788  push r10
000074267fbd478a  push r11
000074267fbd478c  sub rsp, 0xF0
000074267fbd4793  vmovaps [rsp], xmm0
000074267fbd4798  vmovaps [rsp+0x10], xmm1
000074267fbd479e  vmovaps [rsp+0x20], xmm2
000074267fbd47a4  vmovaps [rsp+0x30], xmm3
000074267fbd47aa  vmovaps [rsp+0x40], xmm4
000074267fbd47b0  vmovaps [rsp+0x50], xmm5
000074267fbd47b6  vmovaps [rsp+0x60], xmm6
000074267fbd47bc  vmovaps [rsp+0x70], xmm7
000074267fbd47c2  vmovaps [rsp+0x80], xmm8
000074267fbd47cb  vmovaps [rsp+0x90], xmm9
000074267fbd47d4  vmovaps [rsp+0xA0], xmm10
000074267fbd47dd  vmovaps [rsp+0xB0], xmm12
000074267fbd47e6  vmovaps [rsp+0xC0], xmm13
000074267fbd47ef  vmovaps [rsp+0xD0], xmm14
000074267fbd47f8  vmovaps [rsp+0xE0], xmm15
000074267fbd4801  sub rsp, 0x40
000074267fbd4805  lea rdi, [rsp]
000074267fbd4809  lea rsi, [rsp+0x10]
000074267fbd480e  lea rdx, [rsp+0x20]
000074267fbd4813  lea rcx, [rsp+0x30]
000074267fbd4818  mov r8d, 0x00
000074267fbd481e  lea r9, [r15+0x3A8]
000074267fbd4825  movaps [rdi], xmm11
000074267fbd4829  movaps [rsi], xmm10
000074267fbd482d  movaps [rdx], xmm8
000074267fbd4831  movaps [rcx], xmm13
000074267fbd4835  mov rax, 0x56D4E47AEA50
000074267fbd483f  call rax
000074267fbd4841  movaps xmm11, [rsp]
000074267fbd4846  add rsp, 0x40
000074267fbd484a  vmovaps xmm0, [rsp]
000074267fbd484f  vmovaps xmm1, [rsp+0x10]
000074267fbd4855  vmovaps xmm2, [rsp+0x20]
000074267fbd485b  vmovaps xmm3, [rsp+0x30]
000074267fbd4861  vmovaps xmm4, [rsp+0x40]
000074267fbd4867  vmovaps xmm5, [rsp+0x50]
000074267fbd486d  vmovaps xmm6, [rsp+0x60]
000074267fbd4873  vmovaps xmm7, [rsp+0x70]
000074267fbd4879  vmovaps xmm8, [rsp+0x80]
000074267fbd4882  vmovaps xmm9, [rsp+0x90]
000074267fbd488b  vmovaps xmm10, [rsp+0xA0]
000074267fbd4894  vmovaps xmm12, [rsp+0xB0]
000074267fbd489d  vmovaps xmm13, [rsp+0xC0]
000074267fbd48a6  vmovaps xmm14, [rsp+0xD0]
000074267fbd48af  vmovaps xmm15, [rsp+0xE0]
000074267fbd48b8  add rsp, 0xF0
000074267fbd48bf  pop r11
000074267fbd48c1  pop r10
000074267fbd48c3  pop r9
000074267fbd48c5  pop r8
000074267fbd48c7  pop rsi
000074267fbd48c8  pop rdi
000074267fbd48c9  pop rdx
000074267fbd48ca  pop rcx
000074267fbd48cb  pop rax
000074267fbd48cc  add rsp, 0x08
000074267fbd48d0  jmp 0x000074267FBD2E44
000074267fbd48d5  sub rsp, 0x08
000074267fbd48d9  push rax
000074267fbd48da  push rcx
000074267fbd48db  push rdx
000074267fbd48dc  push rdi
000074267fbd48dd  push rsi
000074267fbd48de  push r8
000074267fbd48e0  push r9
000074267fbd48e2  push r10
000074267fbd48e4  push r11
000074267fbd48e6  sub rsp, 0xF0
000074267fbd48ed  vmovaps [rsp], xmm0
000074267fbd48f2  vmovaps [rsp+0x10], xmm1
000074267fbd48f8  vmovaps [rsp+0x20], xmm2
000074267fbd48fe  vmovaps [rsp+0x30], xmm3
000074267fbd4904  vmovaps [rsp+0x40], xmm4
000074267fbd490a  vmovaps [rsp+0x50], xmm5
000074267fbd4910  vmovaps [rsp+0x60], xmm6
000074267fbd4916  vmovaps [rsp+0x70], xmm7
000074267fbd491c  vmovaps [rsp+0x80], xmm8
000074267fbd4925  vmovaps [rsp+0x90], xmm9
000074267fbd492e  vmovaps [rsp+0xA0], xmm11
000074267fbd4937  vmovaps [rsp+0xB0], xmm12
000074267fbd4940  vmovaps [rsp+0xC0], xmm13
000074267fbd4949  vmovaps [rsp+0xD0], xmm14
000074267fbd4952  vmovaps [rsp+0xE0], xmm15
000074267fbd495b  sub rsp, 0x40
000074267fbd495f  lea rdi, [rsp]
000074267fbd4963  lea rsi, [rsp+0x10]
000074267fbd4968  lea rdx, [rsp+0x20]
000074267fbd496d  lea rcx, [rsp+0x30]
000074267fbd4972  mov r8d, 0x00
000074267fbd4978  lea r9, [r15+0x3A8]
000074267fbd497f  movaps [rdi], xmm10
000074267fbd4983  movaps [rsi], xmm15
000074267fbd4987  movaps [rdx], xmm1
000074267fbd498a  movaps [rcx], xmm13
000074267fbd498e  mov rax, 0x56D4E47AEA50
000074267fbd4998  call rax
000074267fbd499a  movaps xmm10, [rsp]
000074267fbd499f  add rsp, 0x40
000074267fbd49a3  vmovaps xmm0, [rsp]
000074267fbd49a8  vmovaps xmm1, [rsp+0x10]
000074267fbd49ae  vmovaps xmm2, [rsp+0x20]
000074267fbd49b4  vmovaps xmm3, [rsp+0x30]
000074267fbd49ba  vmovaps xmm4, [rsp+0x40]
000074267fbd49c0  vmovaps xmm5, [rsp+0x50]
000074267fbd49c6  vmovaps xmm6, [rsp+0x60]
000074267fbd49cc  vmovaps xmm7, [rsp+0x70]
000074267fbd49d2  vmovaps xmm8, [rsp+0x80]
000074267fbd49db  vmovaps xmm9, [rsp+0x90]
000074267fbd49e4  vmovaps xmm11, [rsp+0xA0]
000074267fbd49ed  vmovaps xmm12, [rsp+0xB0]
000074267fbd49f6  vmovaps xmm13, [rsp+0xC0]
000074267fbd49ff  vmovaps xmm14, [rsp+0xD0]
000074267fbd4a08  vmovaps xmm15, [rsp+0xE0]
000074267fbd4a11  add rsp, 0xF0
000074267fbd4a18  pop r11
000074267fbd4a1a  pop r10
000074267fbd4a1c  pop r9
000074267fbd4a1e  pop r8
000074267fbd4a20  pop rsi
000074267fbd4a21  pop rdi
000074267fbd4a22  pop rdx
000074267fbd4a23  pop rcx
000074267fbd4a24  pop rax
000074267fbd4a25  add rsp, 0x08
000074267fbd4a29  jmp 0x000074267FBD2E6D
000074267fbd4a2e  call 0x000074267F9FF430
000074267fbd4a33  jmp 0x000074267FBD2E8F
000074267fbd4a38  call 0x000074267FA0E760
000074267fbd4a3d  jmp 0x000074267FBD2E99
000074267fbd4a42  sub rsp, 0x08
000074267fbd4a46  push rax
000074267fbd4a47  push rcx
000074267fbd4a48  push rdx
000074267fbd4a49  push rdi
000074267fbd4a4a  push rsi
000074267fbd4a4b  push r8
000074267fbd4a4d  push r9
000074267fbd4a4f  push r10
000074267fbd4a51  push r11
000074267fbd4a53  sub rsp, 0xF0
000074267fbd4a5a  vmovaps [rsp], xmm0
000074267fbd4a5f  vmovaps [rsp+0x10], xmm1
000074267fbd4a65  vmovaps [rsp+0x20], xmm2
000074267fbd4a6b  vmovaps [rsp+0x30], xmm3
000074267fbd4a71  vmovaps [rsp+0x40], xmm4
000074267fbd4a77  vmovaps [rsp+0x50], xmm5
000074267fbd4a7d  vmovaps [rsp+0x60], xmm6
000074267fbd4a83  vmovaps [rsp+0x70], xmm7
000074267fbd4a89  vmovaps [rsp+0x80], xmm9
000074267fbd4a92  vmovaps [rsp+0x90], xmm10
000074267fbd4a9b  vmovaps [rsp+0xA0], xmm11
000074267fbd4aa4  vmovaps [rsp+0xB0], xmm12
000074267fbd4aad  vmovaps [rsp+0xC0], xmm13
000074267fbd4ab6  vmovaps [rsp+0xD0], xmm14
000074267fbd4abf  vmovaps [rsp+0xE0], xmm15
000074267fbd4ac8  sub rsp, 0x40
000074267fbd4acc  lea rdi, [rsp]
000074267fbd4ad0  lea rsi, [rsp+0x10]
000074267fbd4ad5  lea rdx, [rsp+0x20]
000074267fbd4ada  lea rcx, [rsp+0x30]
000074267fbd4adf  mov r8d, 0x00
000074267fbd4ae5  lea r9, [r15+0x3A8]
000074267fbd4aec  movaps [rdi], xmm8
000074267fbd4af0  movaps [rsi], xmm5
000074267fbd4af3  movaps [rdx], xmm9
000074267fbd4af7  movaps [rcx], xmm13
000074267fbd4afb  mov rax, 0x56D4E47AEA50
000074267fbd4b05  call rax
000074267fbd4b07  movaps xmm8, [rsp]
000074267fbd4b0c  add rsp, 0x40
000074267fbd4b10  vmovaps xmm0, [rsp]
000074267fbd4b15  vmovaps xmm1, [rsp+0x10]
000074267fbd4b1b  vmovaps xmm2, [rsp+0x20]
000074267fbd4b21  vmovaps xmm3, [rsp+0x30]
000074267fbd4b27  vmovaps xmm4, [rsp+0x40]
000074267fbd4b2d  vmovaps xmm5, [rsp+0x50]
000074267fbd4b33  vmovaps xmm6, [rsp+0x60]
000074267fbd4b39  vmovaps xmm7, [rsp+0x70]
000074267fbd4b3f  vmovaps xmm9, [rsp+0x80]
000074267fbd4b48  vmovaps xmm10, [rsp+0x90]
000074267fbd4b51  vmovaps xmm11, [rsp+0xA0]
000074267fbd4b5a  vmovaps xmm12, [rsp+0xB0]
000074267fbd4b63  vmovaps xmm13, [rsp+0xC0]
000074267fbd4b6c  vmovaps xmm14, [rsp+0xD0]
000074267fbd4b75  vmovaps xmm15, [rsp+0xE0]
000074267fbd4b7e  add rsp, 0xF0
000074267fbd4b85  pop r11
000074267fbd4b87  pop r10
000074267fbd4b89  pop r9
000074267fbd4b8b  pop r8
000074267fbd4b8d  pop rsi
000074267fbd4b8e  pop rdi
000074267fbd4b8f  pop rdx
000074267fbd4b90  pop rcx
000074267fbd4b91  pop rax
000074267fbd4b92  add rsp, 0x08
000074267fbd4b96  jmp 0x000074267FBD2ED8
000074267fbd4b9b  sub rsp, 0x08
000074267fbd4b9f  push rax
000074267fbd4ba0  push rcx
000074267fbd4ba1  push rdx
000074267fbd4ba2  push rdi
000074267fbd4ba3  push rsi
000074267fbd4ba4  push r8
000074267fbd4ba6  push r9
000074267fbd4ba8  push r10
000074267fbd4baa  push r11
000074267fbd4bac  sub rsp, 0xF0
000074267fbd4bb3  vmovaps [rsp], xmm0
000074267fbd4bb8  vmovaps [rsp+0x10], xmm1
000074267fbd4bbe  vmovaps [rsp+0x20], xmm2
000074267fbd4bc4  vmovaps [rsp+0x30], xmm3
000074267fbd4bca  vmovaps [rsp+0x40], xmm4
000074267fbd4bd0  vmovaps [rsp+0x50], xmm5
000074267fbd4bd6  vmovaps [rsp+0x60], xmm6
000074267fbd4bdc  vmovaps [rsp+0x70], xmm7
000074267fbd4be2  vmovaps [rsp+0x80], xmm8
000074267fbd4beb  vmovaps [rsp+0x90], xmm10
000074267fbd4bf4  vmovaps [rsp+0xA0], xmm11
000074267fbd4bfd  vmovaps [rsp+0xB0], xmm12
000074267fbd4c06  vmovaps [rsp+0xC0], xmm13
000074267fbd4c0f  vmovaps [rsp+0xD0], xmm14
000074267fbd4c18  vmovaps [rsp+0xE0], xmm15
000074267fbd4c21  sub rsp, 0x40
000074267fbd4c25  lea rdi, [rsp]
000074267fbd4c29  lea rsi, [rsp+0x10]
000074267fbd4c2e  lea rdx, [rsp+0x20]
000074267fbd4c33  lea rcx, [rsp+0x30]
000074267fbd4c38  mov r8d, 0x00
000074267fbd4c3e  lea r9, [r15+0x3A8]
000074267fbd4c45  movaps [rdi], xmm9
000074267fbd4c49  movaps [rsi], xmm12
000074267fbd4c4d  movaps [rdx], xmm7
000074267fbd4c50  movaps [rcx], xmm13
000074267fbd4c54  mov rax, 0x56D4E47AEA50
000074267fbd4c5e  call rax
000074267fbd4c60  movaps xmm9, [rsp]
000074267fbd4c65  add rsp, 0x40
000074267fbd4c69  vmovaps xmm0, [rsp]
000074267fbd4c6e  vmovaps xmm1, [rsp+0x10]
000074267fbd4c74  vmovaps xmm2, [rsp+0x20]
000074267fbd4c7a  vmovaps xmm3, [rsp+0x30]
000074267fbd4c80  vmovaps xmm4, [rsp+0x40]
000074267fbd4c86  vmovaps xmm5, [rsp+0x50]
000074267fbd4c8c  vmovaps xmm6, [rsp+0x60]
000074267fbd4c92  vmovaps xmm7, [rsp+0x70]
000074267fbd4c98  vmovaps xmm8, [rsp+0x80]
000074267fbd4ca1  vmovaps xmm10, [rsp+0x90]
000074267fbd4caa  vmovaps xmm11, [rsp+0xA0]
000074267fbd4cb3  vmovaps xmm12, [rsp+0xB0]
000074267fbd4cbc  vmovaps xmm13, [rsp+0xC0]
000074267fbd4cc5  vmovaps xmm14, [rsp+0xD0]
000074267fbd4cce  vmovaps xmm15, [rsp+0xE0]
000074267fbd4cd7  add rsp, 0xF0
000074267fbd4cde  pop r11
000074267fbd4ce0  pop r10
000074267fbd4ce2  pop r9
000074267fbd4ce4  pop r8
000074267fbd4ce6  pop rsi
000074267fbd4ce7  pop rdi
000074267fbd4ce8  pop rdx
000074267fbd4ce9  pop rcx
000074267fbd4cea  pop rax
000074267fbd4ceb  add rsp, 0x08
000074267fbd4cef  jmp 0x000074267FBD2F01
000074267fbd4cf4  sub rsp, 0x08
000074267fbd4cf8  push rax
000074267fbd4cf9  push rcx
000074267fbd4cfa  push rdx
000074267fbd4cfb  push rdi
000074267fbd4cfc  push rsi
000074267fbd4cfd  push r8
000074267fbd4cff  push r9
000074267fbd4d01  push r10
000074267fbd4d03  push r11
000074267fbd4d05  sub rsp, 0xF0
000074267fbd4d0c  vmovaps [rsp], xmm0
000074267fbd4d11  vmovaps [rsp+0x10], xmm1
000074267fbd4d17  vmovaps [rsp+0x20], xmm2
000074267fbd4d1d  vmovaps [rsp+0x30], xmm3
000074267fbd4d23  vmovaps [rsp+0x40], xmm4
000074267fbd4d29  vmovaps [rsp+0x50], xmm5
000074267fbd4d2f  vmovaps [rsp+0x60], xmm6
000074267fbd4d35  vmovaps [rsp+0x70], xmm7
000074267fbd4d3b  vmovaps [rsp+0x80], xmm8
000074267fbd4d44  vmovaps [rsp+0x90], xmm9
000074267fbd4d4d  vmovaps [rsp+0xA0], xmm10
000074267fbd4d56  vmovaps [rsp+0xB0], xmm11
000074267fbd4d5f  vmovaps [rsp+0xC0], xmm13
000074267fbd4d68  vmovaps [rsp+0xD0], xmm14
000074267fbd4d71  vmovaps [rsp+0xE0], xmm15
000074267fbd4d7a  sub rsp, 0x40
000074267fbd4d7e  lea rdi, [rsp]
000074267fbd4d82  lea rsi, [rsp+0x10]
000074267fbd4d87  lea rdx, [rsp+0x20]
000074267fbd4d8c  lea rcx, [rsp+0x30]
000074267fbd4d91  mov r8d, 0x00
000074267fbd4d97  lea r9, [r15+0x3A8]
000074267fbd4d9e  movaps [rdi], xmm12
000074267fbd4da2  movaps [rsi], xmm11
000074267fbd4da6  movaps [rdx], xmm6
000074267fbd4da9  movaps [rcx], xmm13
000074267fbd4dad  mov rax, 0x56D4E47AEA50
000074267fbd4db7  call rax
000074267fbd4db9  movaps xmm12, [rsp]
000074267fbd4dbe  add rsp, 0x40
000074267fbd4dc2  vmovaps xmm0, [rsp]
000074267fbd4dc7  vmovaps xmm1, [rsp+0x10]
000074267fbd4dcd  vmovaps xmm2, [rsp+0x20]
000074267fbd4dd3  vmovaps xmm3, [rsp+0x30]
000074267fbd4dd9  vmovaps xmm4, [rsp+0x40]
000074267fbd4ddf  vmovaps xmm5, [rsp+0x50]
000074267fbd4de5  vmovaps xmm6, [rsp+0x60]
000074267fbd4deb  vmovaps xmm7, [rsp+0x70]
000074267fbd4df1  vmovaps xmm8, [rsp+0x80]
000074267fbd4dfa  vmovaps xmm9, [rsp+0x90]
000074267fbd4e03  vmovaps xmm10, [rsp+0xA0]
000074267fbd4e0c  vmovaps xmm11, [rsp+0xB0]
000074267fbd4e15  vmovaps xmm13, [rsp+0xC0]
000074267fbd4e1e  vmovaps xmm14, [rsp+0xD0]
000074267fbd4e27  vmovaps xmm15, [rsp+0xE0]
000074267fbd4e30  add rsp, 0xF0
000074267fbd4e37  pop r11
000074267fbd4e39  pop r10
000074267fbd4e3b  pop r9
000074267fbd4e3d  pop r8
000074267fbd4e3f  pop rsi
000074267fbd4e40  pop rdi
000074267fbd4e41  pop rdx
000074267fbd4e42  pop rcx
000074267fbd4e43  pop rax
000074267fbd4e44  add rsp, 0x08
000074267fbd4e48  jmp 0x000074267FBD2F2A
000074267fbd4e4d  sub rsp, 0x08
000074267fbd4e51  push rax
000074267fbd4e52  push rcx
000074267fbd4e53  push rdx
000074267fbd4e54  push rdi
000074267fbd4e55  push rsi
000074267fbd4e56  push r8
000074267fbd4e58  push r9
000074267fbd4e5a  push r10
000074267fbd4e5c  push r11
000074267fbd4e5e  sub rsp, 0xF0
000074267fbd4e65  vmovaps [rsp], xmm0
000074267fbd4e6a  vmovaps [rsp+0x10], xmm1
000074267fbd4e70  vmovaps [rsp+0x20], xmm2
000074267fbd4e76  vmovaps [rsp+0x30], xmm3
000074267fbd4e7c  vmovaps [rsp+0x40], xmm4
000074267fbd4e82  vmovaps [rsp+0x50], xmm5
000074267fbd4e88  vmovaps [rsp+0x60], xmm6
000074267fbd4e8e  vmovaps [rsp+0x70], xmm8
000074267fbd4e94  vmovaps [rsp+0x80], xmm9
000074267fbd4e9d  vmovaps [rsp+0x90], xmm10
000074267fbd4ea6  vmovaps [rsp+0xA0], xmm11
000074267fbd4eaf  vmovaps [rsp+0xB0], xmm12
000074267fbd4eb8  vmovaps [rsp+0xC0], xmm13
000074267fbd4ec1  vmovaps [rsp+0xD0], xmm14
000074267fbd4eca  vmovaps [rsp+0xE0], xmm15
000074267fbd4ed3  sub rsp, 0x40
000074267fbd4ed7  lea rdi, [rsp]
000074267fbd4edb  lea rsi, [rsp+0x10]
000074267fbd4ee0  lea rdx, [rsp+0x20]
000074267fbd4ee5  lea rcx, [rsp+0x30]
000074267fbd4eea  mov r8d, 0x00
000074267fbd4ef0  lea r9, [r15+0x3A8]
000074267fbd4ef7  movaps [rdi], xmm7
000074267fbd4efa  movaps [rsi], xmm10
000074267fbd4efe  movaps [rdx], xmm11
000074267fbd4f02  movaps [rcx], xmm13
000074267fbd4f06  mov rax, 0x56D4E47AEA50
000074267fbd4f10  call rax
000074267fbd4f12  movaps xmm7, [rsp]
000074267fbd4f16  add rsp, 0x40
000074267fbd4f1a  vmovaps xmm0, [rsp]
000074267fbd4f1f  vmovaps xmm1, [rsp+0x10]
000074267fbd4f25  vmovaps xmm2, [rsp+0x20]
000074267fbd4f2b  vmovaps xmm3, [rsp+0x30]
000074267fbd4f31  vmovaps xmm4, [rsp+0x40]
000074267fbd4f37  vmovaps xmm5, [rsp+0x50]
000074267fbd4f3d  vmovaps xmm6, [rsp+0x60]
000074267fbd4f43  vmovaps xmm8, [rsp+0x70]
000074267fbd4f49  vmovaps xmm9, [rsp+0x80]
000074267fbd4f52  vmovaps xmm10, [rsp+0x90]
000074267fbd4f5b  vmovaps xmm11, [rsp+0xA0]
000074267fbd4f64  vmovaps xmm12, [rsp+0xB0]
000074267fbd4f6d  vmovaps xmm13, [rsp+0xC0]
000074267fbd4f76  vmovaps xmm14, [rsp+0xD0]
000074267fbd4f7f  vmovaps xmm15, [rsp+0xE0]
000074267fbd4f88  add rsp, 0xF0
000074267fbd4f8f  pop r11
000074267fbd4f91  pop r10
000074267fbd4f93  pop r9
000074267fbd4f95  pop r8
000074267fbd4f97  pop rsi
000074267fbd4f98  pop rdi
000074267fbd4f99  pop rdx
000074267fbd4f9a  pop rcx
000074267fbd4f9b  pop rax
000074267fbd4f9c  add rsp, 0x08
000074267fbd4fa0  jmp 0x000074267FBD2F58
000074267fbd4fa5  call 0x000074267FA0C260
000074267fbd4faa  jmp 0x000074267FBD2F62
000074267fbd4faf  call 0x000074267FA09D70
000074267fbd4fb4  jmp 0x000074267FBD2F6C
000074267fbd4fb9  sub rsp, 0x08
000074267fbd4fbd  push rax
000074267fbd4fbe  push rcx
000074267fbd4fbf  push rdx
000074267fbd4fc0  push rdi
000074267fbd4fc1  push rsi
000074267fbd4fc2  push r8
000074267fbd4fc4  push r9
000074267fbd4fc6  push r10
000074267fbd4fc8  push r11
000074267fbd4fca  sub rsp, 0xF0
000074267fbd4fd1  vmovaps [rsp], xmm0
000074267fbd4fd6  vmovaps [rsp+0x10], xmm1
000074267fbd4fdc  vmovaps [rsp+0x20], xmm2
000074267fbd4fe2  vmovaps [rsp+0x30], xmm3
000074267fbd4fe8  vmovaps [rsp+0x40], xmm4
000074267fbd4fee  vmovaps [rsp+0x50], xmm5
000074267fbd4ff4  vmovaps [rsp+0x60], xmm7
000074267fbd4ffa  vmovaps [rsp+0x70], xmm8
000074267fbd5000  vmovaps [rsp+0x80], xmm9
000074267fbd5009  vmovaps [rsp+0x90], xmm10
000074267fbd5012  vmovaps [rsp+0xA0], xmm11
000074267fbd501b  vmovaps [rsp+0xB0], xmm12
000074267fbd5024  vmovaps [rsp+0xC0], xmm13
000074267fbd502d  vmovaps [rsp+0xD0], xmm14
000074267fbd5036  vmovaps [rsp+0xE0], xmm15
000074267fbd503f  sub rsp, 0x40
000074267fbd5043  lea rdi, [rsp]
000074267fbd5047  lea rsi, [rsp+0x10]
000074267fbd504c  lea rdx, [rsp+0x20]
000074267fbd5051  lea rcx, [rsp+0x30]
000074267fbd5056  mov r8d, 0x00
000074267fbd505c  lea r9, [r15+0x3A8]
000074267fbd5063  movaps [rdi], xmm6
000074267fbd5066  movaps [rsi], xmm8
000074267fbd506a  movaps [rdx], xmm15
000074267fbd506e  movaps [rcx], xmm10
000074267fbd5072  mov rax, 0x56D4E47AEA50
000074267fbd507c  call rax
000074267fbd507e  movaps xmm6, [rsp]
000074267fbd5082  add rsp, 0x40
000074267fbd5086  vmovaps xmm0, [rsp]
000074267fbd508b  vmovaps xmm1, [rsp+0x10]
000074267fbd5091  vmovaps xmm2, [rsp+0x20]
000074267fbd5097  vmovaps xmm3, [rsp+0x30]
000074267fbd509d  vmovaps xmm4, [rsp+0x40]
000074267fbd50a3  vmovaps xmm5, [rsp+0x50]
000074267fbd50a9  vmovaps xmm7, [rsp+0x60]
000074267fbd50af  vmovaps xmm8, [rsp+0x70]
000074267fbd50b5  vmovaps xmm9, [rsp+0x80]
000074267fbd50be  vmovaps xmm10, [rsp+0x90]
000074267fbd50c7  vmovaps xmm11, [rsp+0xA0]
000074267fbd50d0  vmovaps xmm12, [rsp+0xB0]
000074267fbd50d9  vmovaps xmm13, [rsp+0xC0]
000074267fbd50e2  vmovaps xmm14, [rsp+0xD0]
000074267fbd50eb  vmovaps xmm15, [rsp+0xE0]
000074267fbd50f4  add rsp, 0xF0
000074267fbd50fb  pop r11
000074267fbd50fd  pop r10
000074267fbd50ff  pop r9
000074267fbd5101  pop r8
000074267fbd5103  pop rsi
000074267fbd5104  pop rdi
000074267fbd5105  pop rdx
000074267fbd5106  pop rcx
000074267fbd5107  pop rax
000074267fbd5108  add rsp, 0x08
000074267fbd510c  jmp 0x000074267FBD2FA4
000074267fbd5111  sub rsp, 0x08
000074267fbd5115  push rax
000074267fbd5116  push rcx
000074267fbd5117  push rdx
000074267fbd5118  push rdi
000074267fbd5119  push rsi
000074267fbd511a  push r8
000074267fbd511c  push r9
000074267fbd511e  push r10
000074267fbd5120  push r11
000074267fbd5122  sub rsp, 0xF0
000074267fbd5129  vmovaps [rsp], xmm0
000074267fbd512e  vmovaps [rsp+0x10], xmm1
000074267fbd5134  vmovaps [rsp+0x20], xmm2
000074267fbd513a  vmovaps [rsp+0x30], xmm3
000074267fbd5140  vmovaps [rsp+0x40], xmm4
000074267fbd5146  vmovaps [rsp+0x50], xmm5
000074267fbd514c  vmovaps [rsp+0x60], xmm6
000074267fbd5152  vmovaps [rsp+0x70], xmm7
000074267fbd5158  vmovaps [rsp+0x80], xmm8
000074267fbd5161  vmovaps [rsp+0x90], xmm9
000074267fbd516a  vmovaps [rsp+0xA0], xmm11
000074267fbd5173  vmovaps [rsp+0xB0], xmm12
000074267fbd517c  vmovaps [rsp+0xC0], xmm13
000074267fbd5185  vmovaps [rsp+0xD0], xmm14
000074267fbd518e  vmovaps [rsp+0xE0], xmm15
000074267fbd5197  sub rsp, 0x40
000074267fbd519b  lea rdi, [rsp]
000074267fbd519f  lea rsi, [rsp+0x10]
000074267fbd51a4  lea rdx, [rsp+0x20]
000074267fbd51a9  lea rcx, [rsp+0x30]
000074267fbd51ae  mov r8d, 0x00
000074267fbd51b4  lea r9, [r15+0x3A8]
000074267fbd51bb  movaps [rdi], xmm10
000074267fbd51bf  movaps [rsi], xmm9
000074267fbd51c3  movaps [rdx], xmm13
000074267fbd51c7  movaps [rcx], xmm15
000074267fbd51cb  mov rax, 0x56D4E47AEA50
000074267fbd51d5  call rax
000074267fbd51d7  movaps xmm10, [rsp]
000074267fbd51dc  add rsp, 0x40
000074267fbd51e0  vmovaps xmm0, [rsp]
000074267fbd51e5  vmovaps xmm1, [rsp+0x10]
000074267fbd51eb  vmovaps xmm2, [rsp+0x20]
000074267fbd51f1  vmovaps xmm3, [rsp+0x30]
000074267fbd51f7  vmovaps xmm4, [rsp+0x40]
000074267fbd51fd  vmovaps xmm5, [rsp+0x50]
000074267fbd5203  vmovaps xmm6, [rsp+0x60]
000074267fbd5209  vmovaps xmm7, [rsp+0x70]
000074267fbd520f  vmovaps xmm8, [rsp+0x80]
000074267fbd5218  vmovaps xmm9, [rsp+0x90]
000074267fbd5221  vmovaps xmm11, [rsp+0xA0]
000074267fbd522a  vmovaps xmm12, [rsp+0xB0]
000074267fbd5233  vmovaps xmm13, [rsp+0xC0]
000074267fbd523c  vmovaps xmm14, [rsp+0xD0]
000074267fbd5245  vmovaps xmm15, [rsp+0xE0]
000074267fbd524e  add rsp, 0xF0
000074267fbd5255  pop r11
000074267fbd5257  pop r10
000074267fbd5259  pop r9
000074267fbd525b  pop r8
000074267fbd525d  pop rsi
000074267fbd525e  pop rdi
000074267fbd525f  pop rdx
000074267fbd5260  pop rcx
000074267fbd5261  pop rax
000074267fbd5262  add rsp, 0x08
000074267fbd5266  jmp 0x000074267FBD2FCD
000074267fbd526b  sub rsp, 0x08
000074267fbd526f  push rax
000074267fbd5270  push rcx
000074267fbd5271  push rdx
000074267fbd5272  push rdi
000074267fbd5273  push rsi
000074267fbd5274  push r8
000074267fbd5276  push r9
000074267fbd5278  push r10
000074267fbd527a  push r11
000074267fbd527c  sub rsp, 0xF0
000074267fbd5283  vmovaps [rsp], xmm0
000074267fbd5288  vmovaps [rsp+0x10], xmm1
000074267fbd528e  vmovaps [rsp+0x20], xmm2
000074267fbd5294  vmovaps [rsp+0x30], xmm3
000074267fbd529a  vmovaps [rsp+0x40], xmm4
000074267fbd52a0  vmovaps [rsp+0x50], xmm5
000074267fbd52a6  vmovaps [rsp+0x60], xmm6
000074267fbd52ac  vmovaps [rsp+0x70], xmm7
000074267fbd52b2  vmovaps [rsp+0x80], xmm8
000074267fbd52bb  vmovaps [rsp+0x90], xmm9
000074267fbd52c4  vmovaps [rsp+0xA0], xmm10
000074267fbd52cd  vmovaps [rsp+0xB0], xmm11
000074267fbd52d6  vmovaps [rsp+0xC0], xmm12
000074267fbd52df  vmovaps [rsp+0xD0], xmm14
000074267fbd52e8  vmovaps [rsp+0xE0], xmm15
000074267fbd52f1  sub rsp, 0x40
000074267fbd52f5  lea rdi, [rsp]
000074267fbd52f9  lea rsi, [rsp+0x10]
000074267fbd52fe  lea rdx, [rsp+0x20]
000074267fbd5303  lea rcx, [rsp+0x30]
000074267fbd5308  mov r8d, 0x00
000074267fbd530e  lea r9, [r15+0x3A8]
000074267fbd5315  movaps [rdi], xmm13
000074267fbd5319  movaps [rsi], xmm12
000074267fbd531d  movaps [rdx], xmm4
000074267fbd5320  movaps [rcx], xmm15
000074267fbd5324  mov rax, 0x56D4E47AEA50
000074267fbd532e  call rax
000074267fbd5330  movaps xmm13, [rsp]
000074267fbd5335  add rsp, 0x40
000074267fbd5339  vmovaps xmm0, [rsp]
000074267fbd533e  vmovaps xmm1, [rsp+0x10]
000074267fbd5344  vmovaps xmm2, [rsp+0x20]
000074267fbd534a  vmovaps xmm3, [rsp+0x30]
000074267fbd5350  vmovaps xmm4, [rsp+0x40]
000074267fbd5356  vmovaps xmm5, [rsp+0x50]
000074267fbd535c  vmovaps xmm6, [rsp+0x60]
000074267fbd5362  vmovaps xmm7, [rsp+0x70]
000074267fbd5368  vmovaps xmm8, [rsp+0x80]
000074267fbd5371  vmovaps xmm9, [rsp+0x90]
000074267fbd537a  vmovaps xmm10, [rsp+0xA0]
000074267fbd5383  vmovaps xmm11, [rsp+0xB0]
000074267fbd538c  vmovaps xmm12, [rsp+0xC0]
000074267fbd5395  vmovaps xmm14, [rsp+0xD0]
000074267fbd539e  vmovaps xmm15, [rsp+0xE0]
000074267fbd53a7  add rsp, 0xF0
000074267fbd53ae  pop r11
000074267fbd53b0  pop r10
000074267fbd53b2  pop r9
000074267fbd53b4  pop r8
000074267fbd53b6  pop rsi
000074267fbd53b7  pop rdi
000074267fbd53b8  pop rdx
000074267fbd53b9  pop rcx
000074267fbd53ba  pop rax
000074267fbd53bb  add rsp, 0x08
000074267fbd53bf  jmp 0x000074267FBD2FF6
000074267fbd53c4  sub rsp, 0x08
000074267fbd53c8  push rax
000074267fbd53c9  push rcx
000074267fbd53ca  push rdx
000074267fbd53cb  push rdi
000074267fbd53cc  push rsi
000074267fbd53cd  push r8
000074267fbd53cf  push r9
000074267fbd53d1  push r10
000074267fbd53d3  push r11
000074267fbd53d5  sub rsp, 0xF0
000074267fbd53dc  vmovaps [rsp], xmm0
000074267fbd53e1  vmovaps [rsp+0x10], xmm1
000074267fbd53e7  vmovaps [rsp+0x20], xmm2
000074267fbd53ed  vmovaps [rsp+0x30], xmm3
000074267fbd53f3  vmovaps [rsp+0x40], xmm4
000074267fbd53f9  vmovaps [rsp+0x50], xmm5
000074267fbd53ff  vmovaps [rsp+0x60], xmm6
000074267fbd5405  vmovaps [rsp+0x70], xmm7
000074267fbd540b  vmovaps [rsp+0x80], xmm8
000074267fbd5414  vmovaps [rsp+0x90], xmm9
000074267fbd541d  vmovaps [rsp+0xA0], xmm10
000074267fbd5426  vmovaps [rsp+0xB0], xmm11
000074267fbd542f  vmovaps [rsp+0xC0], xmm13
000074267fbd5438  vmovaps [rsp+0xD0], xmm14
000074267fbd5441  vmovaps [rsp+0xE0], xmm15
000074267fbd544a  sub rsp, 0x40
000074267fbd544e  lea rdi, [rsp]
000074267fbd5452  lea rsi, [rsp+0x10]
000074267fbd5457  lea rdx, [rsp+0x20]
000074267fbd545c  lea rcx, [rsp+0x30]
000074267fbd5461  mov r8d, 0x00
000074267fbd5467  lea r9, [r15+0x3A8]
000074267fbd546e  movaps [rdi], xmm12
000074267fbd5472  movaps [rsi], xmm7
000074267fbd5475  movaps [rdx], xmm1
000074267fbd5478  movaps [rcx], xmm15
000074267fbd547c  mov rax, 0x56D4E47AEA50
000074267fbd5486  call rax
000074267fbd5488  movaps xmm12, [rsp]
000074267fbd548d  add rsp, 0x40
000074267fbd5491  vmovaps xmm0, [rsp]
000074267fbd5496  vmovaps xmm1, [rsp+0x10]
000074267fbd549c  vmovaps xmm2, [rsp+0x20]
000074267fbd54a2  vmovaps xmm3, [rsp+0x30]
000074267fbd54a8  vmovaps xmm4, [rsp+0x40]
000074267fbd54ae  vmovaps xmm5, [rsp+0x50]
000074267fbd54b4  vmovaps xmm6, [rsp+0x60]
000074267fbd54ba  vmovaps xmm7, [rsp+0x70]
000074267fbd54c0  vmovaps xmm8, [rsp+0x80]
000074267fbd54c9  vmovaps xmm9, [rsp+0x90]
000074267fbd54d2  vmovaps xmm10, [rsp+0xA0]
000074267fbd54db  vmovaps xmm11, [rsp+0xB0]
000074267fbd54e4  vmovaps xmm13, [rsp+0xC0]
000074267fbd54ed  vmovaps xmm14, [rsp+0xD0]
000074267fbd54f6  vmovaps xmm15, [rsp+0xE0]
000074267fbd54ff  add rsp, 0xF0
000074267fbd5506  pop r11
000074267fbd5508  pop r10
000074267fbd550a  pop r9
000074267fbd550c  pop r8
000074267fbd550e  pop rsi
000074267fbd550f  pop rdi
000074267fbd5510  pop rdx
000074267fbd5511  pop rcx
000074267fbd5512  pop rax
000074267fbd5513  add rsp, 0x08
000074267fbd5517  jmp 0x000074267FBD301F
000074267fbd551c  call 0x000074267F9FF430
000074267fbd5521  jmp 0x000074267FBD3029
000074267fbd5526  call 0x000074267FA0E760
000074267fbd552b  jmp 0x000074267FBD3033
000074267fbd5530  sub rsp, 0x08
000074267fbd5534  push rax
000074267fbd5535  push rcx
000074267fbd5536  push rdx
000074267fbd5537  push rdi
000074267fbd5538  push rsi
000074267fbd5539  push r8
000074267fbd553b  push r9
000074267fbd553d  push r10
000074267fbd553f  push r11
000074267fbd5541  sub rsp, 0xF0
000074267fbd5548  vmovaps [rsp], xmm0
000074267fbd554d  vmovaps [rsp+0x10], xmm1
000074267fbd5553  vmovaps [rsp+0x20], xmm2
000074267fbd5559  vmovaps [rsp+0x30], xmm3
000074267fbd555f  vmovaps [rsp+0x40], xmm4
000074267fbd5565  vmovaps [rsp+0x50], xmm5
000074267fbd556b  vmovaps [rsp+0x60], xmm6
000074267fbd5571  vmovaps [rsp+0x70], xmm8
000074267fbd5577  vmovaps [rsp+0x80], xmm9
000074267fbd5580  vmovaps [rsp+0x90], xmm10
000074267fbd5589  vmovaps [rsp+0xA0], xmm11
000074267fbd5592  vmovaps [rsp+0xB0], xmm12
000074267fbd559b  vmovaps [rsp+0xC0], xmm13
000074267fbd55a4  vmovaps [rsp+0xD0], xmm14
000074267fbd55ad  vmovaps [rsp+0xE0], xmm15
000074267fbd55b6  sub rsp, 0x40
000074267fbd55ba  lea rdi, [rsp]
000074267fbd55be  lea rsi, [rsp+0x10]
000074267fbd55c3  lea rdx, [rsp+0x20]
000074267fbd55c8  lea rcx, [rsp+0x30]
000074267fbd55cd  mov r8d, 0x00
000074267fbd55d3  lea r9, [r15+0x3A8]
000074267fbd55da  movaps [rdi], xmm7
000074267fbd55dd  movaps [rsi], xmm6
000074267fbd55e0  movaps [rdx], xmm8
000074267fbd55e4  movaps [rcx], xmm9
000074267fbd55e8  mov rax, 0x56D4E47AEA50
000074267fbd55f2  call rax
000074267fbd55f4  movaps xmm7, [rsp]
000074267fbd55f8  add rsp, 0x40
000074267fbd55fc  vmovaps xmm0, [rsp]
000074267fbd5601  vmovaps xmm1, [rsp+0x10]
000074267fbd5607  vmovaps xmm2, [rsp+0x20]
000074267fbd560d  vmovaps xmm3, [rsp+0x30]
000074267fbd5613  vmovaps xmm4, [rsp+0x40]
000074267fbd5619  vmovaps xmm5, [rsp+0x50]
000074267fbd561f  vmovaps xmm6, [rsp+0x60]
000074267fbd5625  vmovaps xmm8, [rsp+0x70]
000074267fbd562b  vmovaps xmm9, [rsp+0x80]
000074267fbd5634  vmovaps xmm10, [rsp+0x90]
000074267fbd563d  vmovaps xmm11, [rsp+0xA0]
000074267fbd5646  vmovaps xmm12, [rsp+0xB0]
000074267fbd564f  vmovaps xmm13, [rsp+0xC0]
000074267fbd5658  vmovaps xmm14, [rsp+0xD0]
000074267fbd5661  vmovaps xmm15, [rsp+0xE0]
000074267fbd566a  add rsp, 0xF0
000074267fbd5671  pop r11
000074267fbd5673  pop r10
000074267fbd5675  pop r9
000074267fbd5677  pop r8
000074267fbd5679  pop rsi
000074267fbd567a  pop rdi
000074267fbd567b  pop rdx
000074267fbd567c  pop rcx
000074267fbd567d  pop rax
000074267fbd567e  add rsp, 0x08
000074267fbd5682  jmp 0x000074267FBD305D
000074267fbd5687  sub rsp, 0x08
000074267fbd568b  push rax
000074267fbd568c  push rcx
000074267fbd568d  push rdx
000074267fbd568e  push rdi
000074267fbd568f  push rsi
000074267fbd5690  push r8
000074267fbd5692  push r9
000074267fbd5694  push r10
000074267fbd5696  push r11
000074267fbd5698  sub rsp, 0xF0
000074267fbd569f  vmovaps [rsp], xmm0
000074267fbd56a4  vmovaps [rsp+0x10], xmm1
000074267fbd56aa  vmovaps [rsp+0x20], xmm2
000074267fbd56b0  vmovaps [rsp+0x30], xmm3
000074267fbd56b6  vmovaps [rsp+0x40], xmm4
000074267fbd56bc  vmovaps [rsp+0x50], xmm5
000074267fbd56c2  vmovaps [rsp+0x60], xmm6
000074267fbd56c8  vmovaps [rsp+0x70], xmm7
000074267fbd56ce  vmovaps [rsp+0x80], xmm9
000074267fbd56d7  vmovaps [rsp+0x90], xmm10
000074267fbd56e0  vmovaps [rsp+0xA0], xmm11
000074267fbd56e9  vmovaps [rsp+0xB0], xmm12
000074267fbd56f2  vmovaps [rsp+0xC0], xmm13
000074267fbd56fb  vmovaps [rsp+0xD0], xmm14
000074267fbd5704  vmovaps [rsp+0xE0], xmm15
000074267fbd570d  sub rsp, 0x40
000074267fbd5711  lea rdi, [rsp]
000074267fbd5715  lea rsi, [rsp+0x10]
000074267fbd571a  lea rdx, [rsp+0x20]
000074267fbd571f  lea rcx, [rsp+0x30]
000074267fbd5724  mov r8d, 0x00
000074267fbd572a  lea r9, [r15+0x3A8]
000074267fbd5731  movaps [rdi], xmm8
000074267fbd5735  movaps [rsi], xmm10
000074267fbd5739  movaps [rdx], xmm14
000074267fbd573d  movaps [rcx], xmm9
000074267fbd5741  mov rax, 0x56D4E47AEA50
000074267fbd574b  call rax
000074267fbd574d  movaps xmm8, [rsp]
000074267fbd5752  add rsp, 0x40
000074267fbd5756  vmovaps xmm0, [rsp]
000074267fbd575b  vmovaps xmm1, [rsp+0x10]
000074267fbd5761  vmovaps xmm2, [rsp+0x20]
000074267fbd5767  vmovaps xmm3, [rsp+0x30]
000074267fbd576d  vmovaps xmm4, [rsp+0x40]
000074267fbd5773  vmovaps xmm5, [rsp+0x50]
000074267fbd5779  vmovaps xmm6, [rsp+0x60]
000074267fbd577f  vmovaps xmm7, [rsp+0x70]
000074267fbd5785  vmovaps xmm9, [rsp+0x80]
000074267fbd578e  vmovaps xmm10, [rsp+0x90]
000074267fbd5797  vmovaps xmm11, [rsp+0xA0]
000074267fbd57a0  vmovaps xmm12, [rsp+0xB0]
000074267fbd57a9  vmovaps xmm13, [rsp+0xC0]
000074267fbd57b2  vmovaps xmm14, [rsp+0xD0]
000074267fbd57bb  vmovaps xmm15, [rsp+0xE0]
000074267fbd57c4  add rsp, 0xF0
000074267fbd57cb  pop r11
000074267fbd57cd  pop r10
000074267fbd57cf  pop r9
000074267fbd57d1  pop r8
000074267fbd57d3  pop rsi
000074267fbd57d4  pop rdi
000074267fbd57d5  pop rdx
000074267fbd57d6  pop rcx
000074267fbd57d7  pop rax
000074267fbd57d8  add rsp, 0x08
000074267fbd57dc  jmp 0x000074267FBD3083
000074267fbd57e1  sub rsp, 0x08
000074267fbd57e5  push rax
000074267fbd57e6  push rcx
000074267fbd57e7  push rdx
000074267fbd57e8  push rdi
000074267fbd57e9  push rsi
000074267fbd57ea  push r8
000074267fbd57ec  push r9
000074267fbd57ee  push r10
000074267fbd57f0  push r11
000074267fbd57f2  sub rsp, 0xF0
000074267fbd57f9  vmovaps [rsp], xmm0
000074267fbd57fe  vmovaps [rsp+0x10], xmm1
000074267fbd5804  vmovaps [rsp+0x20], xmm2
000074267fbd580a  vmovaps [rsp+0x30], xmm3
000074267fbd5810  vmovaps [rsp+0x40], xmm4
000074267fbd5816  vmovaps [rsp+0x50], xmm5
000074267fbd581c  vmovaps [rsp+0x60], xmm6
000074267fbd5822  vmovaps [rsp+0x70], xmm7
000074267fbd5828  vmovaps [rsp+0x80], xmm8
000074267fbd5831  vmovaps [rsp+0x90], xmm9
000074267fbd583a  vmovaps [rsp+0xA0], xmm11
000074267fbd5843  vmovaps [rsp+0xB0], xmm12
000074267fbd584c  vmovaps [rsp+0xC0], xmm13
000074267fbd5855  vmovaps [rsp+0xD0], xmm14
000074267fbd585e  vmovaps [rsp+0xE0], xmm15
000074267fbd5867  sub rsp, 0x40
000074267fbd586b  lea rdi, [rsp]
000074267fbd586f  lea rsi, [rsp+0x10]
000074267fbd5874  lea rdx, [rsp+0x20]
000074267fbd5879  lea rcx, [rsp+0x30]
000074267fbd587e  mov r8d, 0x00
000074267fbd5884  lea r9, [r15+0x3A8]
000074267fbd588b  movaps [rdi], xmm10
000074267fbd588f  movaps [rsi], xmm13
000074267fbd5893  movaps [rdx], xmm11
000074267fbd5897  movaps [rcx], xmm14
000074267fbd589b  mov rax, 0x56D4E47AEA50
000074267fbd58a5  call rax
000074267fbd58a7  movaps xmm10, [rsp]
000074267fbd58ac  add rsp, 0x40
000074267fbd58b0  vmovaps xmm0, [rsp]
000074267fbd58b5  vmovaps xmm1, [rsp+0x10]
000074267fbd58bb  vmovaps xmm2, [rsp+0x20]
000074267fbd58c1  vmovaps xmm3, [rsp+0x30]
000074267fbd58c7  vmovaps xmm4, [rsp+0x40]
000074267fbd58cd  vmovaps xmm5, [rsp+0x50]
000074267fbd58d3  vmovaps xmm6, [rsp+0x60]
000074267fbd58d9  vmovaps xmm7, [rsp+0x70]
000074267fbd58df  vmovaps xmm8, [rsp+0x80]
000074267fbd58e8  vmovaps xmm9, [rsp+0x90]
000074267fbd58f1  vmovaps xmm11, [rsp+0xA0]
000074267fbd58fa  vmovaps xmm12, [rsp+0xB0]
000074267fbd5903  vmovaps xmm13, [rsp+0xC0]
000074267fbd590c  vmovaps xmm14, [rsp+0xD0]
000074267fbd5915  vmovaps xmm15, [rsp+0xE0]
000074267fbd591e  add rsp, 0xF0
000074267fbd5925  pop r11
000074267fbd5927  pop r10
000074267fbd5929  pop r9
000074267fbd592b  pop r8
000074267fbd592d  pop rsi
000074267fbd592e  pop rdi
000074267fbd592f  pop rdx
000074267fbd5930  pop rcx
000074267fbd5931  pop rax
000074267fbd5932  add rsp, 0x08
000074267fbd5936  jmp 0x000074267FBD30A9
000074267fbd593b  sub rsp, 0x08
000074267fbd593f  push rax
000074267fbd5940  push rcx
000074267fbd5941  push rdx
000074267fbd5942  push rdi
000074267fbd5943  push rsi
000074267fbd5944  push r8
000074267fbd5946  push r9
000074267fbd5948  push r10
000074267fbd594a  push r11
000074267fbd594c  sub rsp, 0xF0
000074267fbd5953  vmovaps [rsp], xmm0
000074267fbd5958  vmovaps [rsp+0x10], xmm1
000074267fbd595e  vmovaps [rsp+0x20], xmm2
000074267fbd5964  vmovaps [rsp+0x30], xmm3
000074267fbd596a  vmovaps [rsp+0x40], xmm4
000074267fbd5970  vmovaps [rsp+0x50], xmm5
000074267fbd5976  vmovaps [rsp+0x60], xmm6
000074267fbd597c  vmovaps [rsp+0x70], xmm7
000074267fbd5982  vmovaps [rsp+0x80], xmm8
000074267fbd598b  vmovaps [rsp+0x90], xmm9
000074267fbd5994  vmovaps [rsp+0xA0], xmm10
000074267fbd599d  vmovaps [rsp+0xB0], xmm11
000074267fbd59a6  vmovaps [rsp+0xC0], xmm12
000074267fbd59af  vmovaps [rsp+0xD0], xmm14
000074267fbd59b8  vmovaps [rsp+0xE0], xmm15
000074267fbd59c1  sub rsp, 0x40
000074267fbd59c5  lea rdi, [rsp]
000074267fbd59c9  lea rsi, [rsp+0x10]
000074267fbd59ce  lea rdx, [rsp+0x20]
000074267fbd59d3  lea rcx, [rsp+0x30]
000074267fbd59d8  mov r8d, 0x00
000074267fbd59de  lea r9, [r15+0x3A8]
000074267fbd59e5  movaps [rdi], xmm13
000074267fbd59e9  movaps [rsi], xmm12
000074267fbd59ed  movaps [rdx], xmm15
000074267fbd59f1  movaps [rcx], xmm14
000074267fbd59f5  mov rax, 0x56D4E47AEA50
000074267fbd59ff  call rax
000074267fbd5a01  movaps xmm13, [rsp]
000074267fbd5a06  add rsp, 0x40
000074267fbd5a0a  vmovaps xmm0, [rsp]
000074267fbd5a0f  vmovaps xmm1, [rsp+0x10]
000074267fbd5a15  vmovaps xmm2, [rsp+0x20]
000074267fbd5a1b  vmovaps xmm3, [rsp+0x30]
000074267fbd5a21  vmovaps xmm4, [rsp+0x40]
000074267fbd5a27  vmovaps xmm5, [rsp+0x50]
000074267fbd5a2d  vmovaps xmm6, [rsp+0x60]
000074267fbd5a33  vmovaps xmm7, [rsp+0x70]
000074267fbd5a39  vmovaps xmm8, [rsp+0x80]
000074267fbd5a42  vmovaps xmm9, [rsp+0x90]
000074267fbd5a4b  vmovaps xmm10, [rsp+0xA0]
000074267fbd5a54  vmovaps xmm11, [rsp+0xB0]
000074267fbd5a5d  vmovaps xmm12, [rsp+0xC0]
000074267fbd5a66  vmovaps xmm14, [rsp+0xD0]
000074267fbd5a6f  vmovaps xmm15, [rsp+0xE0]
000074267fbd5a78  add rsp, 0xF0
000074267fbd5a7f  pop r11
000074267fbd5a81  pop r10
000074267fbd5a83  pop r9
000074267fbd5a85  pop r8
000074267fbd5a87  pop rsi
000074267fbd5a88  pop rdi
000074267fbd5a89  pop rdx
000074267fbd5a8a  pop rcx
000074267fbd5a8b  pop rax
000074267fbd5a8c  add rsp, 0x08
000074267fbd5a90  jmp 0x000074267FBD30CF
000074267fbd5a95  call 0x000074267FA0E760
000074267fbd5a9a  jmp 0x000074267FBD30DC
000074267fbd5a9f  call 0x000074267FA0D4E0
000074267fbd5aa4  jmp 0x000074267FBD30E9
000074267fbd5aa9  sub rsp, 0x08
000074267fbd5aad  push rax
000074267fbd5aae  push rcx
000074267fbd5aaf  push rdx
000074267fbd5ab0  push rdi
000074267fbd5ab1  push rsi
000074267fbd5ab2  push r8
000074267fbd5ab4  push r9
000074267fbd5ab6  push r10
000074267fbd5ab8  push r11
000074267fbd5aba  sub rsp, 0xF0
000074267fbd5ac1  vmovaps [rsp], xmm0
000074267fbd5ac6  vmovaps [rsp+0x10], xmm1
000074267fbd5acc  vmovaps [rsp+0x20], xmm2
000074267fbd5ad2  vmovaps [rsp+0x30], xmm3
000074267fbd5ad8  vmovaps [rsp+0x40], xmm4
000074267fbd5ade  vmovaps [rsp+0x50], xmm5
000074267fbd5ae4  vmovaps [rsp+0x60], xmm6
000074267fbd5aea  vmovaps [rsp+0x70], xmm7
000074267fbd5af0  vmovaps [rsp+0x80], xmm8
000074267fbd5af9  vmovaps [rsp+0x90], xmm9
000074267fbd5b02  vmovaps [rsp+0xA0], xmm10
000074267fbd5b0b  vmovaps [rsp+0xB0], xmm12
000074267fbd5b14  vmovaps [rsp+0xC0], xmm13
000074267fbd5b1d  vmovaps [rsp+0xD0], xmm14
000074267fbd5b26  vmovaps [rsp+0xE0], xmm15
000074267fbd5b2f  sub rsp, 0x40
000074267fbd5b33  lea rdi, [rsp]
000074267fbd5b37  lea rsi, [rsp+0x10]
000074267fbd5b3c  lea rdx, [rsp+0x20]
000074267fbd5b41  lea rcx, [rsp+0x30]
000074267fbd5b46  mov r8d, 0x00
000074267fbd5b4c  lea r9, [r15+0x3A8]
000074267fbd5b53  movaps [rdi], xmm11
000074267fbd5b57  movaps [rsi], xmm7
000074267fbd5b5a  movaps [rdx], xmm1
000074267fbd5b5d  movaps [rcx], xmm12
000074267fbd5b61  mov rax, 0x56D4E47AEA50
000074267fbd5b6b  call rax
000074267fbd5b6d  movaps xmm11, [rsp]
000074267fbd5b72  add rsp, 0x40
000074267fbd5b76  vmovaps xmm0, [rsp]
000074267fbd5b7b  vmovaps xmm1, [rsp+0x10]
000074267fbd5b81  vmovaps xmm2, [rsp+0x20]
000074267fbd5b87  vmovaps xmm3, [rsp+0x30]
000074267fbd5b8d  vmovaps xmm4, [rsp+0x40]
000074267fbd5b93  vmovaps xmm5, [rsp+0x50]
000074267fbd5b99  vmovaps xmm6, [rsp+0x60]
000074267fbd5b9f  vmovaps xmm7, [rsp+0x70]
000074267fbd5ba5  vmovaps xmm8, [rsp+0x80]
000074267fbd5bae  vmovaps xmm9, [rsp+0x90]
000074267fbd5bb7  vmovaps xmm10, [rsp+0xA0]
000074267fbd5bc0  vmovaps xmm12, [rsp+0xB0]
000074267fbd5bc9  vmovaps xmm13, [rsp+0xC0]
000074267fbd5bd2  vmovaps xmm14, [rsp+0xD0]
000074267fbd5bdb  vmovaps xmm15, [rsp+0xE0]
000074267fbd5be4  add rsp, 0xF0
000074267fbd5beb  pop r11
000074267fbd5bed  pop r10
000074267fbd5bef  pop r9
000074267fbd5bf1  pop r8
000074267fbd5bf3  pop rsi
000074267fbd5bf4  pop rdi
000074267fbd5bf5  pop rdx
000074267fbd5bf6  pop rcx
000074267fbd5bf7  pop rax
000074267fbd5bf8  add rsp, 0x08
000074267fbd5bfc  jmp 0x000074267FBD3122
000074267fbd5c01  call 0x000074267F9FF430
000074267fbd5c06  jmp 0x000074267FBD3134
000074267fbd5c0b  sub rsp, 0x08
000074267fbd5c0f  push rax
000074267fbd5c10  push rcx
000074267fbd5c11  push rdx
000074267fbd5c12  push rdi
000074267fbd5c13  push rsi
000074267fbd5c14  push r8
000074267fbd5c16  push r9
000074267fbd5c18  push r10
000074267fbd5c1a  push r11
000074267fbd5c1c  sub rsp, 0xF0
000074267fbd5c23  vmovaps [rsp], xmm0
000074267fbd5c28  vmovaps [rsp+0x10], xmm1
000074267fbd5c2e  vmovaps [rsp+0x20], xmm2
000074267fbd5c34  vmovaps [rsp+0x30], xmm3
000074267fbd5c3a  vmovaps [rsp+0x40], xmm4
000074267fbd5c40  vmovaps [rsp+0x50], xmm5
000074267fbd5c46  vmovaps [rsp+0x60], xmm6
000074267fbd5c4c  vmovaps [rsp+0x70], xmm7
000074267fbd5c52  vmovaps [rsp+0x80], xmm8
000074267fbd5c5b  vmovaps [rsp+0x90], xmm10
000074267fbd5c64  vmovaps [rsp+0xA0], xmm11
000074267fbd5c6d  vmovaps [rsp+0xB0], xmm12
000074267fbd5c76  vmovaps [rsp+0xC0], xmm13
000074267fbd5c7f  vmovaps [rsp+0xD0], xmm14
000074267fbd5c88  vmovaps [rsp+0xE0], xmm15
000074267fbd5c91  sub rsp, 0x40
000074267fbd5c95  lea rdi, [rsp]
000074267fbd5c99  lea rsi, [rsp+0x10]
000074267fbd5c9e  lea rdx, [rsp+0x20]
000074267fbd5ca3  lea rcx, [rsp+0x30]
000074267fbd5ca8  mov r8d, 0x00
000074267fbd5cae  lea r9, [r15+0x3A8]
000074267fbd5cb5  movaps [rdi], xmm9
000074267fbd5cb9  movaps [rsi], xmm8
000074267fbd5cbd  movaps [rdx], xmm14
000074267fbd5cc1  movaps [rcx], xmm12
000074267fbd5cc5  mov rax, 0x56D4E47AEA50
000074267fbd5ccf  call rax
000074267fbd5cd1  movaps xmm9, [rsp]
000074267fbd5cd6  add rsp, 0x40
000074267fbd5cda  vmovaps xmm0, [rsp]
000074267fbd5cdf  vmovaps xmm1, [rsp+0x10]
000074267fbd5ce5  vmovaps xmm2, [rsp+0x20]
000074267fbd5ceb  vmovaps xmm3, [rsp+0x30]
000074267fbd5cf1  vmovaps xmm4, [rsp+0x40]
000074267fbd5cf7  vmovaps xmm5, [rsp+0x50]
000074267fbd5cfd  vmovaps xmm6, [rsp+0x60]
000074267fbd5d03  vmovaps xmm7, [rsp+0x70]
000074267fbd5d09  vmovaps xmm8, [rsp+0x80]
000074267fbd5d12  vmovaps xmm10, [rsp+0x90]
000074267fbd5d1b  vmovaps xmm11, [rsp+0xA0]
000074267fbd5d24  vmovaps xmm12, [rsp+0xB0]
000074267fbd5d2d  vmovaps xmm13, [rsp+0xC0]
000074267fbd5d36  vmovaps xmm14, [rsp+0xD0]
000074267fbd5d3f  vmovaps xmm15, [rsp+0xE0]
000074267fbd5d48  add rsp, 0xF0
000074267fbd5d4f  pop r11
000074267fbd5d51  pop r10
000074267fbd5d53  pop r9
000074267fbd5d55  pop r8
000074267fbd5d57  pop rsi
000074267fbd5d58  pop rdi
000074267fbd5d59  pop rdx
000074267fbd5d5a  pop rcx
000074267fbd5d5b  pop rax
000074267fbd5d5c  add rsp, 0x08
000074267fbd5d60  jmp 0x000074267FBD3165
000074267fbd5d65  sub rsp, 0x08
000074267fbd5d69  push rax
000074267fbd5d6a  push rcx
000074267fbd5d6b  push rdx
000074267fbd5d6c  push rdi
000074267fbd5d6d  push rsi
000074267fbd5d6e  push r8
000074267fbd5d70  push r9
000074267fbd5d72  push r10
000074267fbd5d74  push r11
000074267fbd5d76  sub rsp, 0xF0
000074267fbd5d7d  vmovaps [rsp], xmm0
000074267fbd5d82  vmovaps [rsp+0x10], xmm1
000074267fbd5d88  vmovaps [rsp+0x20], xmm2
000074267fbd5d8e  vmovaps [rsp+0x30], xmm3
000074267fbd5d94  vmovaps [rsp+0x40], xmm4
000074267fbd5d9a  vmovaps [rsp+0x50], xmm5
000074267fbd5da0  vmovaps [rsp+0x60], xmm6
000074267fbd5da6  vmovaps [rsp+0x70], xmm7
000074267fbd5dac  vmovaps [rsp+0x80], xmm8
000074267fbd5db5  vmovaps [rsp+0x90], xmm9
000074267fbd5dbe  vmovaps [rsp+0xA0], xmm10
000074267fbd5dc7  vmovaps [rsp+0xB0], xmm11
000074267fbd5dd0  vmovaps [rsp+0xC0], xmm13
000074267fbd5dd9  vmovaps [rsp+0xD0], xmm14
000074267fbd5de2  vmovaps [rsp+0xE0], xmm15
000074267fbd5deb  sub rsp, 0x40
000074267fbd5def  lea rdi, [rsp]
000074267fbd5df3  lea rsi, [rsp+0x10]
000074267fbd5df8  lea rdx, [rsp+0x20]
000074267fbd5dfd  lea rcx, [rsp+0x30]
000074267fbd5e02  mov r8d, 0x00
000074267fbd5e08  lea r9, [r15+0x3A8]
000074267fbd5e0f  movaps [rdi], xmm12
000074267fbd5e13  movaps [rsi], xmm10
000074267fbd5e17  movaps [rdx], xmm15
000074267fbd5e1b  movaps [rcx], xmm14
000074267fbd5e1f  mov rax, 0x56D4E47AEA50
000074267fbd5e29  call rax
000074267fbd5e2b  movaps xmm12, [rsp]
000074267fbd5e30  add rsp, 0x40
000074267fbd5e34  vmovaps xmm0, [rsp]
000074267fbd5e39  vmovaps xmm1, [rsp+0x10]
000074267fbd5e3f  vmovaps xmm2, [rsp+0x20]
000074267fbd5e45  vmovaps xmm3, [rsp+0x30]
000074267fbd5e4b  vmovaps xmm4, [rsp+0x40]
000074267fbd5e51  vmovaps xmm5, [rsp+0x50]
000074267fbd5e57  vmovaps xmm6, [rsp+0x60]
000074267fbd5e5d  vmovaps xmm7, [rsp+0x70]
000074267fbd5e63  vmovaps xmm8, [rsp+0x80]
000074267fbd5e6c  vmovaps xmm9, [rsp+0x90]
000074267fbd5e75  vmovaps xmm10, [rsp+0xA0]
000074267fbd5e7e  vmovaps xmm11, [rsp+0xB0]
000074267fbd5e87  vmovaps xmm13, [rsp+0xC0]
000074267fbd5e90  vmovaps xmm14, [rsp+0xD0]
000074267fbd5e99  vmovaps xmm15, [rsp+0xE0]
000074267fbd5ea2  add rsp, 0xF0
000074267fbd5ea9  pop r11
000074267fbd5eab  pop r10
000074267fbd5ead  pop r9
000074267fbd5eaf  pop r8
000074267fbd5eb1  pop rsi
000074267fbd5eb2  pop rdi
000074267fbd5eb3  pop rdx
000074267fbd5eb4  pop rcx
000074267fbd5eb5  pop rax
000074267fbd5eb6  add rsp, 0x08
000074267fbd5eba  jmp 0x000074267FBD3196
000074267fbd5ebf  sub rsp, 0x08
000074267fbd5ec3  push rax
000074267fbd5ec4  push rcx
000074267fbd5ec5  push rdx
000074267fbd5ec6  push rdi
000074267fbd5ec7  push rsi
000074267fbd5ec8  push r8
000074267fbd5eca  push r9
000074267fbd5ecc  push r10
000074267fbd5ece  push r11
000074267fbd5ed0  sub rsp, 0xF0
000074267fbd5ed7  vmovaps [rsp], xmm0
000074267fbd5edc  vmovaps [rsp+0x10], xmm1
000074267fbd5ee2  vmovaps [rsp+0x20], xmm2
000074267fbd5ee8  vmovaps [rsp+0x30], xmm3
000074267fbd5eee  vmovaps [rsp+0x40], xmm4
000074267fbd5ef4  vmovaps [rsp+0x50], xmm5
000074267fbd5efa  vmovaps [rsp+0x60], xmm6
000074267fbd5f00  vmovaps [rsp+0x70], xmm7
000074267fbd5f06  vmovaps [rsp+0x80], xmm8
000074267fbd5f0f  vmovaps [rsp+0x90], xmm9
000074267fbd5f18  vmovaps [rsp+0xA0], xmm10
000074267fbd5f21  vmovaps [rsp+0xB0], xmm11
000074267fbd5f2a  vmovaps [rsp+0xC0], xmm12
000074267fbd5f33  vmovaps [rsp+0xD0], xmm13
000074267fbd5f3c  vmovaps [rsp+0xE0], xmm15
000074267fbd5f45  sub rsp, 0x40
000074267fbd5f49  lea rdi, [rsp]
000074267fbd5f4d  lea rsi, [rsp+0x10]
000074267fbd5f52  lea rdx, [rsp+0x20]
000074267fbd5f57  lea rcx, [rsp+0x30]
000074267fbd5f5c  mov r8d, 0x00
000074267fbd5f62  lea r9, [r15+0x3A8]
000074267fbd5f69  movaps [rdi], xmm14
000074267fbd5f6d  movaps [rsi], xmm13
000074267fbd5f71  movaps [rdx], xmm1
000074267fbd5f74  movaps [rcx], xmm15
000074267fbd5f78  mov rax, 0x56D4E47AEA50
000074267fbd5f82  call rax
000074267fbd5f84  movaps xmm14, [rsp]
000074267fbd5f89  add rsp, 0x40
000074267fbd5f8d  vmovaps xmm0, [rsp]
000074267fbd5f92  vmovaps xmm1, [rsp+0x10]
000074267fbd5f98  vmovaps xmm2, [rsp+0x20]
000074267fbd5f9e  vmovaps xmm3, [rsp+0x30]
000074267fbd5fa4  vmovaps xmm4, [rsp+0x40]
000074267fbd5faa  vmovaps xmm5, [rsp+0x50]
000074267fbd5fb0  vmovaps xmm6, [rsp+0x60]
000074267fbd5fb6  vmovaps xmm7, [rsp+0x70]
000074267fbd5fbc  vmovaps xmm8, [rsp+0x80]
000074267fbd5fc5  vmovaps xmm9, [rsp+0x90]
000074267fbd5fce  vmovaps xmm10, [rsp+0xA0]
000074267fbd5fd7  vmovaps xmm11, [rsp+0xB0]
000074267fbd5fe0  vmovaps xmm12, [rsp+0xC0]
000074267fbd5fe9  vmovaps xmm13, [rsp+0xD0]
000074267fbd5ff2  vmovaps xmm15, [rsp+0xE0]
000074267fbd5ffb  add rsp, 0xF0
000074267fbd6002  pop r11
000074267fbd6004  pop r10
000074267fbd6006  pop r9
000074267fbd6008  pop r8
000074267fbd600a  pop rsi
000074267fbd600b  pop rdi
000074267fbd600c  pop rdx
000074267fbd600d  pop rcx
000074267fbd600e  pop rax
000074267fbd600f  add rsp, 0x08
000074267fbd6013  jmp 0x000074267FBD31C7
000074267fbd6018  call 0x000074267FA079B0
000074267fbd601d  jmp 0x000074267FBD31DA
000074267fbd6022  call 0x000074267FA0B100
000074267fbd6027  jmp 0x000074267FBD31E5
000074267fbd602c  call 0x000074267FA09E90
000074267fbd6031  jmp 0x000074267FBD31F0
000074267fbd6036  call 0x000074267FA0D600
000074267fbd603b  jmp 0x000074267FBD31FB
000074267fbd6040  int3
000074267fbd6041  nop [rax+rax*1], ax
000074267fbd604a  nop [rax+rax*1], ax
000074267fbd6050  mov rax, [r15+0x40]
000074267fbd6054  mov r14, [r15+0x58]
000074267fbd6058  lea r12, [rax+r14*1]
000074267fbd605c  vxorps xmm1, xmm1, xmm1
000074267fbd6060  vpbroadcastq xmm1, xmm1
000074267fbd6065  vxorps xmm15, xmm15, xmm15
000074267fbd606a  vpbroadcastq xmm15, xmm15
000074267fbd606f  lea rax, [r12+0x30]
000074267fbd6074  mov r11, [r13+rax*1]
000074267fbd6079  lea rax, [r12+0x38]
000074267fbd607e  mov r10, [r13+rax*1]
000074267fbd6083  movq xmm14, r11
000074267fbd6088  movq xmm13, r10
000074267fbd608d  movq xmm14, xmm14
000074267fbd6092  movq xmm13, xmm13
000074267fbd6097  vmovaps [rsp+0x10], xmm13
000074267fbd609d  movq xmm13, xmm13
000074267fbd60a2  movaps [r15+0x270], xmm13
000074267fbd60aa  movaps xmm13, [r15+0x160]
000074267fbd60b2  vmovaps [rsp+0x20], xmm13
000074267fbd60b8  vmovaps xmm12, [rsp+0x20]
000074267fbd60be  por xmm13, xmm12
000074267fbd60c3  lea rax, [r12+0x20]
000074267fbd60c8  mov r11, [r13+rax*1]
000074267fbd60cd  lea rax, [r12+0x28]
000074267fbd60d2  mov r10, [r13+rax*1]
000074267fbd60d7  movq xmm12, r11
000074267fbd60dc  movq xmm11, r10
000074267fbd60e1  movq xmm12, xmm12
000074267fbd60e6  movq xmm11, xmm11
000074267fbd60eb  movaps xmm10, [r15+0x2D0]
000074267fbd60f3  vmovaps [rsp+0x20], xmm10
000074267fbd60f9  vmovaps xmm9, [rsp+0x20]
000074267fbd60ff  por xmm10, xmm9
000074267fbd6104  movaps xmm9, [r15+0x300]
000074267fbd610c  vmovaps [rsp+0x20], xmm9
000074267fbd6112  vmovaps xmm8, [rsp+0x20]
000074267fbd6118  por xmm9, xmm8
000074267fbd611d  movaps xmm8, [r15+0x2B0]
000074267fbd6125  vmovaps [rsp+0x20], xmm8
000074267fbd612b  vmovaps xmm7, [rsp+0x20]
000074267fbd6131  por xmm8, xmm7
000074267fbd6136  movaps xmm7, [r15+0x180]
000074267fbd613e  vmovaps [rsp+0x20], xmm7
000074267fbd6144  vmovaps xmm6, [rsp+0x20]
000074267fbd614a  por xmm7, xmm6
000074267fbd614e  lea rax, [r12+0x10]
000074267fbd6153  mov r11, [r13+rax*1]
000074267fbd6158  lea rax, [r12+0x18]
000074267fbd615d  mov r10, [r13+rax*1]
000074267fbd6162  movq xmm6, r11
000074267fbd6167  movq xmm5, r10
000074267fbd616c  movq xmm6, xmm6
000074267fbd6170  movq xmm5, xmm5
000074267fbd6174  movaps xmm4, [r15+0x200]
000074267fbd617c  vmovaps [rsp+0x20], xmm4
000074267fbd6182  vmovaps xmm3, [rsp+0x20]
000074267fbd6188  por xmm4, xmm3
000074267fbd618c  movaps xmm3, [r15+0x1F0]
000074267fbd6194  vmovaps [rsp+0x20], xmm3
000074267fbd619a  vmovaps xmm2, [rsp+0x20]
000074267fbd61a0  por xmm3, xmm2
000074267fbd61a4  movaps xmm2, [r15+0x2E0]
000074267fbd61ac  vmovaps [rsp+0x20], xmm2
000074267fbd61b2  vmovaps [rsp+0x30], xmm1
000074267fbd61b8  vmovaps xmm1, [rsp+0x20]
000074267fbd61be  por xmm2, xmm1
000074267fbd61c2  movaps xmm1, [r15+0x2A0]
000074267fbd61ca  vmovaps [rsp+0x20], xmm1
000074267fbd61d0  vmovaps [rsp+0x40], xmm15
000074267fbd61d6  vmovaps xmm15, [rsp+0x20]
000074267fbd61dc  por xmm1, xmm15
000074267fbd61e1  movaps xmm15, [r15+0x280]
000074267fbd61e9  vmovaps [rsp+0x20], xmm15
000074267fbd61ef  vmovaps [rsp+0x50], xmm1
000074267fbd61f5  vmovaps xmm1, [rsp+0x20]
000074267fbd61fb  por xmm15, xmm1
000074267fbd6200  movaps xmm1, [r15+0x1C0]
000074267fbd6208  vmovaps [rsp+0x20], xmm1
000074267fbd620e  vmovaps [rsp+0x60], xmm15
000074267fbd6214  vmovaps xmm15, [rsp+0x20]
000074267fbd621a  por xmm1, xmm15
000074267fbd621f  movaps xmm15, [r15+0x210]
000074267fbd6227  vmovaps [rsp+0x20], xmm15
000074267fbd622d  vmovaps [rsp+0x70], xmm1
000074267fbd6233  vmovaps xmm1, [rsp+0x20]
000074267fbd6239  por xmm15, xmm1
000074267fbd623e  mov rax, [r13+r12*1]
000074267fbd6243  vmovq xmm1, rax
000074267fbd6248  vpbroadcastq xmm1, xmm1
000074267fbd624d  vmovaps [rsp+0x20], xmm1
000074267fbd6253  vxorps xmm1, xmm1, xmm1
000074267fbd6257  vpbroadcastq xmm1, xmm1
000074267fbd625c  mov rax, [r15+0xF8]
000074267fbd6263  vmovaps [rsp+0x80], xmm1
000074267fbd626c  movups xmm1, [r13+rax*1]
000074267fbd6272  vmovaps [rsp+0x90], xmm1
000074267fbd627b  vxorps xmm1, xmm1, xmm1
000074267fbd627f  vpbroadcastq xmm1, xmm1
000074267fbd6284  lea r11, [r12+0x08]
000074267fbd6289  mov r12, [r13+r11*1]
000074267fbd628e  vmovaps [rsp+0xA0], xmm1
000074267fbd6297  movq xmm1, r12
000074267fbd629c  movaps [r15+0x240], xmm1
000074267fbd62a4  mov r12, [r15+0x50]
000074267fbd62a8  lea r11, [r12+r14*1]
000074267fbd62ac  mov [r15+0x60], r11
000074267fbd62b0  lea r12, [r14+0x40]
000074267fbd62b4  mov [r15+0x58], r12
000074267fbd62b8  vmovaps xmm1, [rsp+0x30]
000074267fbd62be  vmovaps [rsp+0x30], xmm15
000074267fbd62c4  vmovaps xmm15, [rsp+0x90]
000074267fbd62cd  vmovaps [rsp+0x90], xmm14
000074267fbd62d6  vmovaps xmm14, [rsp+0x20]
000074267fbd62dc  vmovaps [rsp+0x20], xmm13
000074267fbd62e2  vmovaps [rsp+0xB0], xmm12
000074267fbd62eb  movaps xmm13, xmm1
000074267fbd62ef  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd62fa  vptest xmm12, xmm12
000074267fbd62ff  jnz 0x000074267FBD6D9C
000074267fbd6305  movaps xmm1, [r15+0x250]
000074267fbd630d  vmovaps xmm15, [rsp+0x40]
000074267fbd6313  vmovaps [rsp+0x40], xmm13
000074267fbd6319  movaps xmm12, xmm15
000074267fbd631d  vfmadd231pd xmm12, xmm1, xmm14
000074267fbd6322  vcmppd xmm13, xmm12, xmm12, 0x03
000074267fbd6328  vptest xmm13, xmm13
000074267fbd632d  jnz 0x000074267FBD6EF5
000074267fbd6333  movaps xmm15, [r15+0x1E0]
000074267fbd633b  vmovaps [rsp+0xC0], xmm15
000074267fbd6344  vmovaps xmm13, [rsp+0xC0]
000074267fbd634d  por xmm15, xmm13
000074267fbd6352  movaps xmm13, [r15+0x1D0]
000074267fbd635a  vmovaps [rsp+0xC0], xmm13
000074267fbd6363  vmovaps [rsp+0xD0], xmm1
000074267fbd636c  vmovaps xmm1, [rsp+0xC0]
000074267fbd6375  por xmm13, xmm1
000074267fbd637a  movaps xmm1, [r15+0x2C0]
000074267fbd6382  vmovaps [rsp+0xC0], xmm1
000074267fbd638b  vmovaps [rsp+0xE0], xmm15
000074267fbd6394  vmovaps xmm15, [rsp+0xC0]
000074267fbd639d  por xmm1, xmm15
000074267fbd63a2  movaps xmm15, [r15+0x290]
000074267fbd63aa  vmovaps [rsp+0xC0], xmm15
000074267fbd63b3  vmovaps [rsp+0xF0], xmm1
000074267fbd63bc  vmovaps xmm1, [rsp+0xC0]
000074267fbd63c5  por xmm15, xmm1
000074267fbd63ca  movaps xmm1, [r15+0x260]
000074267fbd63d2  vmovaps [rsp+0xC0], xmm1
000074267fbd63db  vmovaps [rsp+0x100], xmm15
000074267fbd63e4  vmovaps xmm15, [rsp+0xC0]
000074267fbd63ed  por xmm1, xmm15
000074267fbd63f2  vmovaps xmm15, [rsp+0xD0]
000074267fbd63fb  vmovaps [rsp+0xC0], xmm1
000074267fbd6404  vmovaps xmm1, [rsp+0xD0]
000074267fbd640d  por xmm15, xmm1
000074267fbd6412  lea r14, [rax+0xC0]
000074267fbd6419  movups xmm1, [r13+r14*1]
000074267fbd641f  mov [rsp+0xD0], rax
000074267fbd6427  xor eax, eax
000074267fbd6429  mov r14d, 0x200
000074267fbd642f  cmp r12, r14
000074267fbd6432  cmc
000074267fbd6433  lahf
000074267fbd6434  seto al
000074267fbd6437  mov [r15+0x108], eax
000074267fbd643e  vmovaps [rsp+0x110], xmm1
000074267fbd6447  vmovaps xmm1, [rsp+0x80]
000074267fbd6450  vmovaps [rsp+0x80], xmm15
000074267fbd6459  vmovaps xmm15, [rsp+0x110]
000074267fbd6462  vmovaps [rsp+0x110], xmm13
000074267fbd646b  vmovaps [rsp+0x120], xmm12
000074267fbd6474  movaps xmm13, xmm1
000074267fbd6478  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd647d  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd6483  vptest xmm12, xmm12
000074267fbd6488  jnz 0x000074267FBD7058
000074267fbd648e  mov rax, [rsp+0xD0]
000074267fbd6496  lea r14, [rax+0xB0]
000074267fbd649d  movups xmm1, [r13+r14*1]
000074267fbd64a3  vmovaps xmm15, [rsp+0xA0]
000074267fbd64ac  vmovaps [rsp+0xA0], xmm13
000074267fbd64b5  movaps xmm12, xmm15
000074267fbd64b9  vfmadd231pd xmm12, xmm1, xmm14
000074267fbd64be  vcmppd xmm13, xmm12, xmm12, 0x03
000074267fbd64c4  vptest xmm13, xmm13
000074267fbd64c9  jnz 0x000074267FBD71BB
000074267fbd64cf  vmovaps xmm1, [rsp+0x30]
000074267fbd64d5  vmovaps xmm15, [rsp+0x30]
000074267fbd64db  por xmm1, xmm15
000074267fbd64e0  movaps [r15+0x210], xmm1
000074267fbd64e8  vmovaps xmm15, [rsp+0x70]
000074267fbd64ee  vmovaps xmm14, [rsp+0x70]
000074267fbd64f4  por xmm15, xmm14
000074267fbd64f9  movaps [r15+0x1C0], xmm15
000074267fbd6501  vmovaps xmm14, [rsp+0x60]
000074267fbd6507  vmovaps xmm13, [rsp+0x60]
000074267fbd650d  por xmm14, xmm13
000074267fbd6512  movaps [r15+0x280], xmm14
000074267fbd651a  vmovaps xmm13, [rsp+0x50]
000074267fbd6520  vmovaps [rsp+0x30], xmm1
000074267fbd6526  vmovaps xmm1, [rsp+0x50]
000074267fbd652c  por xmm13, xmm1
000074267fbd6531  movaps [r15+0x2A0], xmm13
000074267fbd6539  vmovaps [rsp+0x50], xmm2
000074267fbd653f  vmovaps xmm1, [rsp+0x50]
000074267fbd6545  por xmm2, xmm1
000074267fbd6549  movaps [r15+0x2E0], xmm2
000074267fbd6551  vmovaps [rsp+0x50], xmm3
000074267fbd6557  vmovaps xmm1, [rsp+0x50]
000074267fbd655d  por xmm3, xmm1
000074267fbd6561  movaps [r15+0x1F0], xmm3
000074267fbd6569  vmovaps xmm1, [rsp+0x80]
000074267fbd6572  vmovaps [rsp+0x50], xmm15
000074267fbd6578  vmovaps xmm15, [rsp+0x80]
000074267fbd6581  por xmm1, xmm15
000074267fbd6586  movaps [r15+0x250], xmm1
000074267fbd658e  vmovaps xmm1, [rsp+0xC0]
000074267fbd6597  vmovaps xmm15, [rsp+0xC0]
000074267fbd65a0  por xmm1, xmm15
000074267fbd65a5  movaps [r15+0x260], xmm1
000074267fbd65ad  vmovaps xmm15, [rsp+0x100]
000074267fbd65b6  vmovaps [rsp+0x60], xmm1
000074267fbd65bc  vmovaps xmm1, [rsp+0x100]
000074267fbd65c5  por xmm15, xmm1
000074267fbd65ca  movaps [r15+0x290], xmm15
000074267fbd65d2  vmovaps xmm1, [rsp+0xF0]
000074267fbd65db  vmovaps [rsp+0x70], xmm15
000074267fbd65e1  vmovaps xmm15, [rsp+0xF0]
000074267fbd65ea  por xmm1, xmm15
000074267fbd65ef  movaps [r15+0x2C0], xmm1
000074267fbd65f7  movq xmm15, qword ptr [r15+0x240]
000074267fbd6600  vmovaps [rsp+0x80], xmm15
000074267fbd6609  vpermilpd xmm15, xmm15, 0x00
000074267fbd660f  vmovaps [rsp+0xC0], xmm1
000074267fbd6618  vmovaps xmm1, [rsp+0x40]
000074267fbd661e  vmovaps [rsp+0x40], xmm15
000074267fbd6624  vmovaps xmm15, [rsp+0x30]
000074267fbd662a  vmovaps [rsp+0x30], xmm14
000074267fbd6630  vmovaps xmm14, [rsp+0x40]
000074267fbd6636  vmovaps [rsp+0x40], xmm13
000074267fbd663c  vmovaps [rsp+0xD0], xmm12
000074267fbd6645  movaps xmm13, xmm1
000074267fbd6649  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd664e  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd6654  vptest xmm12, xmm12
000074267fbd6659  jnz 0x000074267FBD7314
000074267fbd665f  vmovaps xmm1, [rsp+0x80]
000074267fbd6668  vpermilpd xmm1, xmm1, 0x00
000074267fbd666e  vmovaps xmm15, [rsp+0xA0]
000074267fbd6677  movaps xmm14, xmm15
000074267fbd667b  vfmadd231pd xmm14, xmm2, xmm1
000074267fbd6680  vcmppd xmm12, xmm14, xmm14, 0x03
000074267fbd6686  vptest xmm12, xmm12
000074267fbd668b  jnz 0x000074267FBD746D
000074267fbd6691  vmovaps xmm1, [rsp+0x80]
000074267fbd669a  vpermilpd xmm1, xmm1, 0x00
000074267fbd66a0  vmovaps xmm15, [rsp+0x120]
000074267fbd66a9  vmovaps xmm12, [rsp+0x50]
000074267fbd66af  vmovaps [rsp+0x50], xmm14
000074267fbd66b5  movaps xmm2, xmm15
000074267fbd66b9  vfmadd231pd xmm2, xmm12, xmm1
000074267fbd66be  vcmppd xmm14, xmm2, xmm2, 0x03
000074267fbd66c3  vptest xmm14, xmm14
000074267fbd66c8  jnz 0x000074267FBD75C5
000074267fbd66ce  vmovaps xmm1, [rsp+0x110]
000074267fbd66d7  vmovaps xmm15, [rsp+0x110]
000074267fbd66e0  por xmm1, xmm15
000074267fbd66e5  movaps [r15+0x1D0], xmm1
000074267fbd66ed  vmovaps xmm15, [rsp+0x80]
000074267fbd66f6  vpermilpd xmm15, xmm15, 0x00
000074267fbd66fc  vmovaps xmm14, [rsp+0xD0]
000074267fbd6705  vmovaps [rsp+0x80], xmm1
000074267fbd670e  movaps xmm12, xmm14
000074267fbd6712  vfmadd231pd xmm12, xmm3, xmm15
000074267fbd6717  vcmppd xmm1, xmm12, xmm12, 0x03
000074267fbd671d  vptest xmm1, xmm1
000074267fbd6722  jnz 0x000074267FBD771C
000074267fbd6728  vmovaps [rsp+0xA0], xmm4
000074267fbd6731  vmovaps xmm1, [rsp+0xA0]
000074267fbd673a  por xmm4, xmm1
000074267fbd673e  movaps [r15+0x200], xmm4
000074267fbd6746  vmovaps xmm1, [rsp+0xE0]
000074267fbd674f  vmovaps xmm15, [rsp+0xE0]
000074267fbd6758  por xmm1, xmm15
000074267fbd675d  movaps [r15+0x1E0], xmm1
000074267fbd6765  vmovaps [rsp+0xA0], xmm8
000074267fbd676e  vmovaps xmm1, [rsp+0xA0]
000074267fbd6777  por xmm8, xmm1
000074267fbd677c  movaps [r15+0x2B0], xmm8
000074267fbd6784  vmovaps [rsp+0xA0], xmm9
000074267fbd678d  vmovaps xmm1, [rsp+0xA0]
000074267fbd6796  por xmm9, xmm1
000074267fbd679b  movaps [r15+0x300], xmm9
000074267fbd67a3  vmovaps [rsp+0xA0], xmm6
000074267fbd67ac  vpermilpd xmm6, xmm6, 0x00
000074267fbd67b2  vmovaps xmm14, [rsp+0x60]
000074267fbd67b8  movaps xmm9, xmm13
000074267fbd67bc  vfmadd231pd xmm9, xmm14, xmm6
000074267fbd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
000074267fbd67c7  vptest xmm3, xmm3
000074267fbd67cc  jnz 0x000074267FBD7875
000074267fbd67d2  vmovaps xmm14, [rsp+0xA0]
000074267fbd67db  vpermilpd xmm14, xmm14, 0x00
000074267fbd67e1  vmovaps xmm13, [rsp+0x50]
000074267fbd67e7  vmovaps xmm6, [rsp+0xC0]
000074267fbd67f0  vmovaps [rsp+0x50], xmm1
000074267fbd67f6  movaps xmm3, xmm13
000074267fbd67fa  vfmadd231pd xmm3, xmm6, xmm14
000074267fbd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
000074267fbd6804  vptest xmm1, xmm1
000074267fbd6809  jnz 0x000074267FBD79CE
000074267fbd680f  vmovaps xmm1, [rsp+0xA0]
000074267fbd6818  vpermilpd xmm1, xmm1, 0x00
000074267fbd681e  vmovaps xmm14, [rsp+0x30]
000074267fbd6824  movaps xmm6, xmm2
000074267fbd6827  vfmadd231pd xmm6, xmm14, xmm1
000074267fbd682c  vcmppd xmm13, xmm6, xmm6, 0x03
000074267fbd6831  vptest xmm13, xmm13
000074267fbd6836  jnz 0x000074267FBD7B25
000074267fbd683c  vmovaps xmm1, [rsp+0xA0]
000074267fbd6845  vpermilpd xmm1, xmm1, 0x00
000074267fbd684b  vmovaps xmm14, [rsp+0x80]
000074267fbd6854  movaps xmm13, xmm12
000074267fbd6858  vfmadd231pd xmm13, xmm14, xmm1
000074267fbd685d  vcmppd xmm2, xmm13, xmm13, 0x03
000074267fbd6863  vptest xmm2, xmm2
000074267fbd6868  jnz 0x000074267FBD7C7B
000074267fbd686e  vmovaps [rsp+0x30], xmm7
000074267fbd6874  vmovaps xmm1, [rsp+0x30]
000074267fbd687a  por xmm7, xmm1
000074267fbd687e  movaps [r15+0x180], xmm7
000074267fbd6886  vmovaps [rsp+0x30], xmm10
000074267fbd688c  vmovaps xmm1, [rsp+0x30]
000074267fbd6892  por xmm10, xmm1
000074267fbd6897  movaps [r15+0x2D0], xmm10
000074267fbd689f  vmovaps [rsp+0x30], xmm5
000074267fbd68a5  vpermilpd xmm5, xmm5, 0x00
000074267fbd68ab  vmovaps xmm14, [rsp+0x50]
000074267fbd68b1  movaps xmm12, xmm3
000074267fbd68b5  vfmadd231pd xmm12, xmm14, xmm5
000074267fbd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
000074267fbd68c0  vptest xmm10, xmm10
000074267fbd68c5  jnz 0x000074267FBD7DD4
000074267fbd68cb  vmovaps xmm14, [rsp+0x30]
000074267fbd68d1  vpermilpd xmm14, xmm14, 0x00
000074267fbd68d7  movaps xmm10, xmm9
000074267fbd68db  vfmadd231pd xmm10, xmm7, xmm14
000074267fbd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
000074267fbd68e6  vptest xmm5, xmm5
000074267fbd68eb  jnz 0x000074267FBD7F2C
000074267fbd68f1  lea r14, [rax+0x80]
000074267fbd68f8  movups xmm14, [r13+r14*1]
000074267fbd68fe  movaps [r15+0x2F0], xmm14
000074267fbd6906  vmovaps xmm9, [rsp+0x30]
000074267fbd690c  vpermilpd xmm9, xmm9, 0x00
000074267fbd6912  vmovaps xmm7, [rsp+0x70]
000074267fbd6918  movaps xmm5, xmm6
000074267fbd691b  vfmadd231pd xmm5, xmm7, xmm9
000074267fbd6920  vcmppd xmm3, xmm5, xmm5, 0x03
000074267fbd6925  vptest xmm3, xmm3
000074267fbd692a  jnz 0x000074267FBD808F
000074267fbd6930  vmovaps xmm9, [rsp+0x30]
000074267fbd6936  vpermilpd xmm9, xmm9, 0x00
000074267fbd693c  movaps xmm7, xmm13
000074267fbd6940  vfmadd231pd xmm7, xmm1, xmm9
000074267fbd6945  vcmppd xmm6, xmm7, xmm7, 0x03
000074267fbd694a  vptest xmm6, xmm6
000074267fbd694f  jnz 0x000074267FBD81E5
000074267fbd6955  vmovaps xmm1, [rsp+0x20]
000074267fbd695b  vmovaps xmm13, [rsp+0x20]
000074267fbd6961  por xmm1, xmm13
000074267fbd6966  movaps [r15+0x160], xmm1
000074267fbd696e  lea r14, [rax+0x40]
000074267fbd6972  movups xmm13, [r13+r14*1]
000074267fbd6978  lea r14, [rax+0x50]
000074267fbd697c  movups xmm9, [r13+r14*1]
000074267fbd6982  movaps [r15+0x1B0], xmm13
000074267fbd698a  movaps [r15+0x1A0], xmm9
000074267fbd6992  movaps xmm6, [r15+0x190]
000074267fbd699a  vmovaps xmm3, [rsp+0xB0]
000074267fbd69a3  vpermilpd xmm3, xmm3, 0x00
000074267fbd69a9  vmovaps [rsp+0x20], xmm1
000074267fbd69af  movaps xmm2, xmm12
000074267fbd69b3  vfmadd231pd xmm2, xmm6, xmm3
000074267fbd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
000074267fbd69bd  vptest xmm1, xmm1
000074267fbd69c2  jnz 0x000074267FBD8350
000074267fbd69c8  vmovaps xmm1, [rsp+0xB0]
000074267fbd69d1  vpermilpd xmm1, xmm1, 0x00
000074267fbd69d7  vmovaps xmm12, [rsp+0x20]
000074267fbd69dd  movaps xmm6, xmm10
000074267fbd69e1  vfmadd231pd xmm6, xmm12, xmm1
000074267fbd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
000074267fbd69eb  vptest xmm3, xmm3
000074267fbd69f0  jnz 0x000074267FBD84A6
000074267fbd69f6  vmovaps xmm1, [rsp+0xB0]
000074267fbd69ff  vpermilpd xmm1, xmm1, 0x00
000074267fbd6a05  vmovaps xmm12, [rsp+0x40]
000074267fbd6a0b  movaps xmm10, xmm5
000074267fbd6a0f  vfmadd231pd xmm10, xmm12, xmm1
000074267fbd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
000074267fbd6a1a  vptest xmm3, xmm3
000074267fbd6a1f  jnz 0x000074267FBD85FD
000074267fbd6a25  vmovaps xmm1, [rsp+0xB0]
000074267fbd6a2e  vpermilpd xmm1, xmm1, 0x00
000074267fbd6a34  movaps xmm12, xmm7
000074267fbd6a38  vfmadd231pd xmm12, xmm15, xmm1
000074267fbd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
000074267fbd6a43  vptest xmm5, xmm5
000074267fbd6a48  jnz 0x000074267FBD8755
000074267fbd6a4e  lea r14, [rax+0x60]
000074267fbd6a52  movups xmm1, [r13+r14*1]
000074267fbd6a58  lea r14, [rax+0x70]
000074267fbd6a5c  movups xmm15, [r13+r14*1]
000074267fbd6a62  movaps [r15+0x150], xmm1
000074267fbd6a6a  movaps [r15+0x120], xmm15
000074267fbd6a72  vmovaps [rsp+0x20], xmm11
000074267fbd6a78  vpermilpd xmm11, xmm11, 0x00
000074267fbd6a7e  movaps xmm7, xmm2
000074267fbd6a81  vfmadd231pd xmm7, xmm9, xmm11
000074267fbd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
000074267fbd6a8b  vptest xmm5, xmm5
000074267fbd6a90  jnz 0x000074267FBD88C1
000074267fbd6a96  vmovaps xmm11, [rsp+0x20]
000074267fbd6a9c  vpermilpd xmm11, xmm11, 0x00
000074267fbd6aa2  movaps xmm9, xmm6
000074267fbd6aa6  vfmadd231pd xmm9, xmm1, xmm11
000074267fbd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
000074267fbd6ab1  vptest xmm5, xmm5
000074267fbd6ab6  jnz 0x000074267FBD8A18
000074267fbd6abc  vmovaps xmm1, [rsp+0x20]
000074267fbd6ac2  vpermilpd xmm1, xmm1, 0x00
000074267fbd6ac8  movaps xmm11, xmm10
000074267fbd6acc  vfmadd231pd xmm11, xmm8, xmm1
000074267fbd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
000074267fbd6ad7  vptest xmm6, xmm6
000074267fbd6adc  jnz 0x000074267FBD8B70
000074267fbd6ae2  vmovaps xmm1, [rsp+0x20]
000074267fbd6ae8  vpermilpd xmm1, xmm1, 0x00
000074267fbd6aee  movaps xmm10, xmm12
000074267fbd6af2  vfmadd231pd xmm10, xmm13, xmm1
000074267fbd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
000074267fbd6afd  vptest xmm8, xmm8
000074267fbd6b02  jnz 0x000074267FBD8CC9
000074267fbd6b08  lea r14, [rax+0x20]
000074267fbd6b0c  movups xmm1, [r13+r14*1]
000074267fbd6b12  lea r14, [rax+0x30]
000074267fbd6b16  movups xmm13, [r13+r14*1]
000074267fbd6b1c  vmovaps xmm12, [rsp+0x90]
000074267fbd6b25  vpermilpd xmm12, xmm12, 0x00
000074267fbd6b2b  movaps xmm8, xmm7
000074267fbd6b2f  vfmadd231pd xmm8, xmm4, xmm12
000074267fbd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
000074267fbd6b3a  vptest xmm6, xmm6
000074267fbd6b3f  jnz 0x000074267FBD8E36
000074267fbd6b45  vmovaps xmm12, [rsp+0x90]
000074267fbd6b4e  vpermilpd xmm12, xmm12, 0x00
000074267fbd6b54  movaps xmm7, xmm9
000074267fbd6b58  vfmadd231pd xmm7, xmm14, xmm12
000074267fbd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
000074267fbd6b62  vptest xmm6, xmm6
000074267fbd6b67  jnz 0x000074267FBD8F8E
000074267fbd6b6d  vmovaps xmm14, [rsp+0x90]
000074267fbd6b76  vpermilpd xmm14, xmm14, 0x00
000074267fbd6b7c  movaps xmm12, xmm11
000074267fbd6b80  vfmadd231pd xmm12, xmm15, xmm14
000074267fbd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
000074267fbd6b8b  vptest xmm9, xmm9
000074267fbd6b90  jnz 0x000074267FBD90E6
000074267fbd6b96  vmovaps xmm15, [rsp+0x90]
000074267fbd6b9f  vpermilpd xmm15, xmm15, 0x00
000074267fbd6ba5  movaps xmm11, xmm10
000074267fbd6ba9  vfmadd231pd xmm11, xmm13, xmm15
000074267fbd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
000074267fbd6bb4  vptest xmm14, xmm14
000074267fbd6bb9  jnz 0x000074267FBD9240
000074267fbd6bbf  lea r14, [rax+0x90]
000074267fbd6bc6  movups xmm15, [r13+r14*1]
000074267fbd6bcc  lea r14, [rax+0xA0]
000074267fbd6bd3  movups xmm14, [r13+r14*1]
000074267fbd6bd9  movaps [r15+0x140], xmm15
000074267fbd6be1  movaps [r15+0x130], xmm14
000074267fbd6be9  vmovaps xmm13, [rsp+0x10]
000074267fbd6bef  vpermilpd xmm13, xmm13, 0x00
000074267fbd6bf5  movaps xmm10, xmm8
000074267fbd6bf9  vfmadd231pd xmm10, xmm1, xmm13
000074267fbd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
000074267fbd6c04  vptest xmm9, xmm9
000074267fbd6c09  jnz 0x000074267FBD93AE
000074267fbd6c0f  movaps [r15+0x220], xmm10
000074267fbd6c17  lea r14, [rax+0x10]
000074267fbd6c1b  movups xmm1, [r13+r14*1]
000074267fbd6c21  movaps [r15+0x240], xmm1
000074267fbd6c29  vmovaps xmm13, [rsp+0x10]
000074267fbd6c2f  vpermilpd xmm13, xmm13, 0x00
000074267fbd6c35  movaps xmm9, xmm7
000074267fbd6c39  vfmadd231pd xmm9, xmm14, xmm13
000074267fbd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
000074267fbd6c44  vptest xmm8, xmm8
000074267fbd6c49  jnz 0x000074267FBD9511
000074267fbd6c4f  movaps [r15+0x110], xmm9
000074267fbd6c57  vmovaps xmm14, [rsp+0x10]
000074267fbd6c5d  vpermilpd xmm14, xmm14, 0x00
000074267fbd6c63  movaps xmm13, xmm12
000074267fbd6c67  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
000074267fbd6c72  vptest xmm8, xmm8
000074267fbd6c77  jnz 0x000074267FBD966A
000074267fbd6c7d  movaps [r15+0x170], xmm13
000074267fbd6c85  vmovaps xmm15, [rsp+0x10]
000074267fbd6c8b  vpermilpd xmm15, xmm15, 0x00
000074267fbd6c91  movaps xmm14, xmm11
000074267fbd6c95  vfmadd231pd xmm14, xmm1, xmm15
000074267fbd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
000074267fbd6ca0  vptest xmm12, xmm12
000074267fbd6ca5  jnz 0x000074267FBD97C4
000074267fbd6cab  movaps [r15+0x230], xmm14
000074267fbd6cb3  movups [r13+r11*1], xmm9
000074267fbd6cb9  lea rax, [r11+0x10]
000074267fbd6cbd  movups [r13+rax*1], xmm13
000074267fbd6cc3  lea rax, [r11+0x20]
000074267fbd6cc7  movups [r13+rax*1], xmm10
000074267fbd6ccd  lea rax, [r11+0x30]
000074267fbd6cd1  movups [r13+rax*1], xmm14
000074267fbd6cd7  mov eax, [r15+0x108]
000074267fbd6cde  sahf
000074267fbd6cdf  jnz 0x000074267FBD6D11
000074267fbd6ce1  cmp dword ptr [r15+0x318], 0x00
000074267fbd6ce9  jz 0x000074267FBD9950
000074267fbd6cef  nop [rax+rax*1], ax
000074267fbd6cf8  nop [rax+rax*1], eax
000074267fbd6d00  mov eax, 0x410664
000074267fbd6d05  mov [r15+0x100], rax
000074267fbd6d0c  jmp 0x000074267F9FE110
000074267fbd6d11  cmp dword ptr [r15+0x318], 0x00
000074267fbd6d19  jz 0x000074267FBD6050
000074267fbd6d1f  nop [rax+rax*1], ax
000074267fbd6d28  nop [rax+rax*1], eax
000074267fbd6d30  mov eax, 0x4104F0
000074267fbd6d35  mov [r15+0x100], rax
000074267fbd6d3c  jmp 0x000074267F9FE110
000074267fbd6d41  int3
000074267fbd6d42  call 0x000074267FA0A4B0
000074267fbd6d47  jmp 0x000074267FBD6079
000074267fbd6d4c  call 0x000074267FA09240
000074267fbd6d51  jmp 0x000074267FBD6083
000074267fbd6d56  call 0x000074267FA0A4B0
000074267fbd6d5b  jmp 0x000074267FBD60CD
000074267fbd6d60  call 0x000074267FA09240
000074267fbd6d65  jmp 0x000074267FBD60D7
000074267fbd6d6a  call 0x000074267FA0A4B0
000074267fbd6d6f  jmp 0x000074267FBD6158
000074267fbd6d74  call 0x000074267FA09240
000074267fbd6d79  jmp 0x000074267FBD6162
000074267fbd6d7e  call 0x000074267FAB47C0
000074267fbd6d83  jmp 0x000074267FBD6243
000074267fbd6d88  call 0x000074267F9FF430
000074267fbd6d8d  jmp 0x000074267FBD6272
000074267fbd6d92  call 0x000074267FAB0CE0
000074267fbd6d97  jmp 0x000074267FBD628E
000074267fbd6d9c  sub rsp, 0x08
000074267fbd6da0  push rax
000074267fbd6da1  push rcx
000074267fbd6da2  push rdx
000074267fbd6da3  push rdi
000074267fbd6da4  push rsi
000074267fbd6da5  push r8
000074267fbd6da7  push r9
000074267fbd6da9  push r10
000074267fbd6dab  push r11
000074267fbd6dad  sub rsp, 0xF0
000074267fbd6db4  vmovaps [rsp], xmm0
000074267fbd6db9  vmovaps [rsp+0x10], xmm1
000074267fbd6dbf  vmovaps [rsp+0x20], xmm2
000074267fbd6dc5  vmovaps [rsp+0x30], xmm3
000074267fbd6dcb  vmovaps [rsp+0x40], xmm4
000074267fbd6dd1  vmovaps [rsp+0x50], xmm5
000074267fbd6dd7  vmovaps [rsp+0x60], xmm6
000074267fbd6ddd  vmovaps [rsp+0x70], xmm7
000074267fbd6de3  vmovaps [rsp+0x80], xmm8
000074267fbd6dec  vmovaps [rsp+0x90], xmm9
000074267fbd6df5  vmovaps [rsp+0xA0], xmm10
000074267fbd6dfe  vmovaps [rsp+0xB0], xmm11
000074267fbd6e07  vmovaps [rsp+0xC0], xmm12
000074267fbd6e10  vmovaps [rsp+0xD0], xmm14
000074267fbd6e19  vmovaps [rsp+0xE0], xmm15
000074267fbd6e22  sub rsp, 0x40
000074267fbd6e26  lea rdi, [rsp]
000074267fbd6e2a  lea rsi, [rsp+0x10]
000074267fbd6e2f  lea rdx, [rsp+0x20]
000074267fbd6e34  lea rcx, [rsp+0x30]
000074267fbd6e39  mov r8d, 0x00
000074267fbd6e3f  lea r9, [r15+0x3A8]
000074267fbd6e46  movaps [rdi], xmm13
000074267fbd6e4a  movaps [rsi], xmm1
000074267fbd6e4d  movaps [rdx], xmm15
000074267fbd6e51  movaps [rcx], xmm14
000074267fbd6e55  mov rax, 0x56D4E47AEA50
000074267fbd6e5f  call rax
000074267fbd6e61  movaps xmm13, [rsp]
000074267fbd6e66  add rsp, 0x40
000074267fbd6e6a  vmovaps xmm0, [rsp]
000074267fbd6e6f  vmovaps xmm1, [rsp+0x10]
000074267fbd6e75  vmovaps xmm2, [rsp+0x20]
000074267fbd6e7b  vmovaps xmm3, [rsp+0x30]
000074267fbd6e81  vmovaps xmm4, [rsp+0x40]
000074267fbd6e87  vmovaps xmm5, [rsp+0x50]
000074267fbd6e8d  vmovaps xmm6, [rsp+0x60]
000074267fbd6e93  vmovaps xmm7, [rsp+0x70]
000074267fbd6e99  vmovaps xmm8, [rsp+0x80]
000074267fbd6ea2  vmovaps xmm9, [rsp+0x90]
000074267fbd6eab  vmovaps xmm10, [rsp+0xA0]
000074267fbd6eb4  vmovaps xmm11, [rsp+0xB0]
000074267fbd6ebd  vmovaps xmm12, [rsp+0xC0]
000074267fbd6ec6  vmovaps xmm14, [rsp+0xD0]
000074267fbd6ecf  vmovaps xmm15, [rsp+0xE0]
000074267fbd6ed8  add rsp, 0xF0
000074267fbd6edf  pop r11
000074267fbd6ee1  pop r10
000074267fbd6ee3  pop r9
000074267fbd6ee5  pop r8
000074267fbd6ee7  pop rsi
000074267fbd6ee8  pop rdi
000074267fbd6ee9  pop rdx
000074267fbd6eea  pop rcx
000074267fbd6eeb  pop rax
000074267fbd6eec  add rsp, 0x08
000074267fbd6ef0  jmp 0x000074267FBD6305
000074267fbd6ef5  sub rsp, 0x08
000074267fbd6ef9  push rax
000074267fbd6efa  push rcx
000074267fbd6efb  push rdx
000074267fbd6efc  push rdi
000074267fbd6efd  push rsi
000074267fbd6efe  push r8
000074267fbd6f00  push r9
000074267fbd6f02  push r10
000074267fbd6f04  push r11
000074267fbd6f06  sub rsp, 0xF0
000074267fbd6f0d  vmovaps [rsp], xmm0
000074267fbd6f12  vmovaps [rsp+0x10], xmm1
000074267fbd6f18  vmovaps [rsp+0x20], xmm2
000074267fbd6f1e  vmovaps [rsp+0x30], xmm3
000074267fbd6f24  vmovaps [rsp+0x40], xmm4
000074267fbd6f2a  vmovaps [rsp+0x50], xmm5
000074267fbd6f30  vmovaps [rsp+0x60], xmm6
000074267fbd6f36  vmovaps [rsp+0x70], xmm7
000074267fbd6f3c  vmovaps [rsp+0x80], xmm8
000074267fbd6f45  vmovaps [rsp+0x90], xmm9
000074267fbd6f4e  vmovaps [rsp+0xA0], xmm10
000074267fbd6f57  vmovaps [rsp+0xB0], xmm11
000074267fbd6f60  vmovaps [rsp+0xC0], xmm13
000074267fbd6f69  vmovaps [rsp+0xD0], xmm14
000074267fbd6f72  vmovaps [rsp+0xE0], xmm15
000074267fbd6f7b  sub rsp, 0x40
000074267fbd6f7f  lea rdi, [rsp]
000074267fbd6f83  lea rsi, [rsp+0x10]
000074267fbd6f88  lea rdx, [rsp+0x20]
000074267fbd6f8d  lea rcx, [rsp+0x30]
000074267fbd6f92  mov r8d, 0x00
000074267fbd6f98  lea r9, [r15+0x3A8]
000074267fbd6f9f  movaps [rdi], xmm12
000074267fbd6fa3  movaps [rsi], xmm15
000074267fbd6fa7  movaps [rdx], xmm1
000074267fbd6faa  movaps [rcx], xmm14
000074267fbd6fae  mov rax, 0x56D4E47AEA50
000074267fbd6fb8  call rax
000074267fbd6fba  movaps xmm12, [rsp]
000074267fbd6fbf  add rsp, 0x40
000074267fbd6fc3  vmovaps xmm0, [rsp]
000074267fbd6fc8  vmovaps xmm1, [rsp+0x10]
000074267fbd6fce  vmovaps xmm2, [rsp+0x20]
000074267fbd6fd4  vmovaps xmm3, [rsp+0x30]
000074267fbd6fda  vmovaps xmm4, [rsp+0x40]
000074267fbd6fe0  vmovaps xmm5, [rsp+0x50]
000074267fbd6fe6  vmovaps xmm6, [rsp+0x60]
000074267fbd6fec  vmovaps xmm7, [rsp+0x70]
000074267fbd6ff2  vmovaps xmm8, [rsp+0x80]
000074267fbd6ffb  vmovaps xmm9, [rsp+0x90]
000074267fbd7004  vmovaps xmm10, [rsp+0xA0]
000074267fbd700d  vmovaps xmm11, [rsp+0xB0]
000074267fbd7016  vmovaps xmm13, [rsp+0xC0]
000074267fbd701f  vmovaps xmm14, [rsp+0xD0]
000074267fbd7028  vmovaps xmm15, [rsp+0xE0]
000074267fbd7031  add rsp, 0xF0
000074267fbd7038  pop r11
000074267fbd703a  pop r10
000074267fbd703c  pop r9
000074267fbd703e  pop r8
000074267fbd7040  pop rsi
000074267fbd7041  pop rdi
000074267fbd7042  pop rdx
000074267fbd7043  pop rcx
000074267fbd7044  pop rax
000074267fbd7045  add rsp, 0x08
000074267fbd7049  jmp 0x000074267FBD6333
000074267fbd704e  call 0x000074267FAD64F0
000074267fbd7053  jmp 0x000074267FBD641F
000074267fbd7058  sub rsp, 0x08
000074267fbd705c  push rax
000074267fbd705d  push rcx
000074267fbd705e  push rdx
000074267fbd705f  push rdi
000074267fbd7060  push rsi
000074267fbd7061  push r8
000074267fbd7063  push r9
000074267fbd7065  push r10
000074267fbd7067  push r11
000074267fbd7069  sub rsp, 0xF0
000074267fbd7070  vmovaps [rsp], xmm0
000074267fbd7075  vmovaps [rsp+0x10], xmm1
000074267fbd707b  vmovaps [rsp+0x20], xmm2
000074267fbd7081  vmovaps [rsp+0x30], xmm3
000074267fbd7087  vmovaps [rsp+0x40], xmm4
000074267fbd708d  vmovaps [rsp+0x50], xmm5
000074267fbd7093  vmovaps [rsp+0x60], xmm6
000074267fbd7099  vmovaps [rsp+0x70], xmm7
000074267fbd709f  vmovaps [rsp+0x80], xmm8
000074267fbd70a8  vmovaps [rsp+0x90], xmm9
000074267fbd70b1  vmovaps [rsp+0xA0], xmm10
000074267fbd70ba  vmovaps [rsp+0xB0], xmm11
000074267fbd70c3  vmovaps [rsp+0xC0], xmm12
000074267fbd70cc  vmovaps [rsp+0xD0], xmm14
000074267fbd70d5  vmovaps [rsp+0xE0], xmm15
000074267fbd70de  sub rsp, 0x40
000074267fbd70e2  lea rdi, [rsp]
000074267fbd70e6  lea rsi, [rsp+0x10]
000074267fbd70eb  lea rdx, [rsp+0x20]
000074267fbd70f0  lea rcx, [rsp+0x30]
000074267fbd70f5  mov r8d, 0x00
000074267fbd70fb  lea r9, [r15+0x3A8]
000074267fbd7102  movaps [rdi], xmm13
000074267fbd7106  movaps [rsi], xmm1
000074267fbd7109  movaps [rdx], xmm15
000074267fbd710d  movaps [rcx], xmm14
000074267fbd7111  mov rax, 0x56D4E47AEA50
000074267fbd711b  call rax
000074267fbd711d  movaps xmm13, [rsp]
000074267fbd7122  add rsp, 0x40
000074267fbd7126  vmovaps xmm0, [rsp]
000074267fbd712b  vmovaps xmm1, [rsp+0x10]
000074267fbd7131  vmovaps xmm2, [rsp+0x20]
000074267fbd7137  vmovaps xmm3, [rsp+0x30]
000074267fbd713d  vmovaps xmm4, [rsp+0x40]
000074267fbd7143  vmovaps xmm5, [rsp+0x50]
000074267fbd7149  vmovaps xmm6, [rsp+0x60]
000074267fbd714f  vmovaps xmm7, [rsp+0x70]
000074267fbd7155  vmovaps xmm8, [rsp+0x80]
000074267fbd715e  vmovaps xmm9, [rsp+0x90]
000074267fbd7167  vmovaps xmm10, [rsp+0xA0]
000074267fbd7170  vmovaps xmm11, [rsp+0xB0]
000074267fbd7179  vmovaps xmm12, [rsp+0xC0]
000074267fbd7182  vmovaps xmm14, [rsp+0xD0]
000074267fbd718b  vmovaps xmm15, [rsp+0xE0]
000074267fbd7194  add rsp, 0xF0
000074267fbd719b  pop r11
000074267fbd719d  pop r10
000074267fbd719f  pop r9
000074267fbd71a1  pop r8
000074267fbd71a3  pop rsi
000074267fbd71a4  pop rdi
000074267fbd71a5  pop rdx
000074267fbd71a6  pop rcx
000074267fbd71a7  pop rax
000074267fbd71a8  add rsp, 0x08
000074267fbd71ac  jmp 0x000074267FBD648E
000074267fbd71b1  call 0x000074267FAD64F0
000074267fbd71b6  jmp 0x000074267FBD64A3
000074267fbd71bb  sub rsp, 0x08
000074267fbd71bf  push rax
000074267fbd71c0  push rcx
000074267fbd71c1  push rdx
000074267fbd71c2  push rdi
000074267fbd71c3  push rsi
000074267fbd71c4  push r8
000074267fbd71c6  push r9
000074267fbd71c8  push r10
000074267fbd71ca  push r11
000074267fbd71cc  sub rsp, 0xF0
000074267fbd71d3  vmovaps [rsp], xmm0
000074267fbd71d8  vmovaps [rsp+0x10], xmm1
000074267fbd71de  vmovaps [rsp+0x20], xmm2
000074267fbd71e4  vmovaps [rsp+0x30], xmm3
000074267fbd71ea  vmovaps [rsp+0x40], xmm4
000074267fbd71f0  vmovaps [rsp+0x50], xmm5
000074267fbd71f6  vmovaps [rsp+0x60], xmm6
000074267fbd71fc  vmovaps [rsp+0x70], xmm7
000074267fbd7202  vmovaps [rsp+0x80], xmm8
000074267fbd720b  vmovaps [rsp+0x90], xmm9
000074267fbd7214  vmovaps [rsp+0xA0], xmm10
000074267fbd721d  vmovaps [rsp+0xB0], xmm11
000074267fbd7226  vmovaps [rsp+0xC0], xmm13
000074267fbd722f  vmovaps [rsp+0xD0], xmm14
000074267fbd7238  vmovaps [rsp+0xE0], xmm15
000074267fbd7241  sub rsp, 0x40
000074267fbd7245  lea rdi, [rsp]
000074267fbd7249  lea rsi, [rsp+0x10]
000074267fbd724e  lea rdx, [rsp+0x20]
000074267fbd7253  lea rcx, [rsp+0x30]
000074267fbd7258  mov r8d, 0x00
000074267fbd725e  lea r9, [r15+0x3A8]
000074267fbd7265  movaps [rdi], xmm12
000074267fbd7269  movaps [rsi], xmm15
000074267fbd726d  movaps [rdx], xmm1
000074267fbd7270  movaps [rcx], xmm14
000074267fbd7274  mov rax, 0x56D4E47AEA50
000074267fbd727e  call rax
000074267fbd7280  movaps xmm12, [rsp]
000074267fbd7285  add rsp, 0x40
000074267fbd7289  vmovaps xmm0, [rsp]
000074267fbd728e  vmovaps xmm1, [rsp+0x10]
000074267fbd7294  vmovaps xmm2, [rsp+0x20]
000074267fbd729a  vmovaps xmm3, [rsp+0x30]
000074267fbd72a0  vmovaps xmm4, [rsp+0x40]
000074267fbd72a6  vmovaps xmm5, [rsp+0x50]
000074267fbd72ac  vmovaps xmm6, [rsp+0x60]
000074267fbd72b2  vmovaps xmm7, [rsp+0x70]
000074267fbd72b8  vmovaps xmm8, [rsp+0x80]
000074267fbd72c1  vmovaps xmm9, [rsp+0x90]
000074267fbd72ca  vmovaps xmm10, [rsp+0xA0]
000074267fbd72d3  vmovaps xmm11, [rsp+0xB0]
000074267fbd72dc  vmovaps xmm13, [rsp+0xC0]
000074267fbd72e5  vmovaps xmm14, [rsp+0xD0]
000074267fbd72ee  vmovaps xmm15, [rsp+0xE0]
000074267fbd72f7  add rsp, 0xF0
000074267fbd72fe  pop r11
000074267fbd7300  pop r10
000074267fbd7302  pop r9
000074267fbd7304  pop r8
000074267fbd7306  pop rsi
000074267fbd7307  pop rdi
000074267fbd7308  pop rdx
000074267fbd7309  pop rcx
000074267fbd730a  pop rax
000074267fbd730b  add rsp, 0x08
000074267fbd730f  jmp 0x000074267FBD64CF
000074267fbd7314  sub rsp, 0x08
000074267fbd7318  push rax
000074267fbd7319  push rcx
000074267fbd731a  push rdx
000074267fbd731b  push rdi
000074267fbd731c  push rsi
000074267fbd731d  push r8
000074267fbd731f  push r9
000074267fbd7321  push r10
000074267fbd7323  push r11
000074267fbd7325  sub rsp, 0xF0
000074267fbd732c  vmovaps [rsp], xmm0
000074267fbd7331  vmovaps [rsp+0x10], xmm1
000074267fbd7337  vmovaps [rsp+0x20], xmm2
000074267fbd733d  vmovaps [rsp+0x30], xmm3
000074267fbd7343  vmovaps [rsp+0x40], xmm4
000074267fbd7349  vmovaps [rsp+0x50], xmm5
000074267fbd734f  vmovaps [rsp+0x60], xmm6
000074267fbd7355  vmovaps [rsp+0x70], xmm7
000074267fbd735b  vmovaps [rsp+0x80], xmm8
000074267fbd7364  vmovaps [rsp+0x90], xmm9
000074267fbd736d  vmovaps [rsp+0xA0], xmm10
000074267fbd7376  vmovaps [rsp+0xB0], xmm11
000074267fbd737f  vmovaps [rsp+0xC0], xmm12
000074267fbd7388  vmovaps [rsp+0xD0], xmm14
000074267fbd7391  vmovaps [rsp+0xE0], xmm15
000074267fbd739a  sub rsp, 0x40
000074267fbd739e  lea rdi, [rsp]
000074267fbd73a2  lea rsi, [rsp+0x10]
000074267fbd73a7  lea rdx, [rsp+0x20]
000074267fbd73ac  lea rcx, [rsp+0x30]
000074267fbd73b1  mov r8d, 0x00
000074267fbd73b7  lea r9, [r15+0x3A8]
000074267fbd73be  movaps [rdi], xmm13
000074267fbd73c2  movaps [rsi], xmm1
000074267fbd73c5  movaps [rdx], xmm15
000074267fbd73c9  movaps [rcx], xmm14
000074267fbd73cd  mov rax, 0x56D4E47AEA50
000074267fbd73d7  call rax
000074267fbd73d9  movaps xmm13, [rsp]
000074267fbd73de  add rsp, 0x40
000074267fbd73e2  vmovaps xmm0, [rsp]
000074267fbd73e7  vmovaps xmm1, [rsp+0x10]
000074267fbd73ed  vmovaps xmm2, [rsp+0x20]
000074267fbd73f3  vmovaps xmm3, [rsp+0x30]
000074267fbd73f9  vmovaps xmm4, [rsp+0x40]
000074267fbd73ff  vmovaps xmm5, [rsp+0x50]
000074267fbd7405  vmovaps xmm6, [rsp+0x60]
000074267fbd740b  vmovaps xmm7, [rsp+0x70]
000074267fbd7411  vmovaps xmm8, [rsp+0x80]
000074267fbd741a  vmovaps xmm9, [rsp+0x90]
000074267fbd7423  vmovaps xmm10, [rsp+0xA0]
000074267fbd742c  vmovaps xmm11, [rsp+0xB0]
000074267fbd7435  vmovaps xmm12, [rsp+0xC0]
000074267fbd743e  vmovaps xmm14, [rsp+0xD0]
000074267fbd7447  vmovaps xmm15, [rsp+0xE0]
000074267fbd7450  add rsp, 0xF0
000074267fbd7457  pop r11
000074267fbd7459  pop r10
000074267fbd745b  pop r9
000074267fbd745d  pop r8
000074267fbd745f  pop rsi
000074267fbd7460  pop rdi
000074267fbd7461  pop rdx
000074267fbd7462  pop rcx
000074267fbd7463  pop rax
000074267fbd7464  add rsp, 0x08
000074267fbd7468  jmp 0x000074267FBD665F
000074267fbd746d  sub rsp, 0x08
000074267fbd7471  push rax
000074267fbd7472  push rcx
000074267fbd7473  push rdx
000074267fbd7474  push rdi
000074267fbd7475  push rsi
000074267fbd7476  push r8
000074267fbd7478  push r9
000074267fbd747a  push r10
000074267fbd747c  push r11
000074267fbd747e  sub rsp, 0xF0
000074267fbd7485  vmovaps [rsp], xmm0
000074267fbd748a  vmovaps [rsp+0x10], xmm1
000074267fbd7490  vmovaps [rsp+0x20], xmm2
000074267fbd7496  vmovaps [rsp+0x30], xmm3
000074267fbd749c  vmovaps [rsp+0x40], xmm4
000074267fbd74a2  vmovaps [rsp+0x50], xmm5
000074267fbd74a8  vmovaps [rsp+0x60], xmm6
000074267fbd74ae  vmovaps [rsp+0x70], xmm7
000074267fbd74b4  vmovaps [rsp+0x80], xmm8
000074267fbd74bd  vmovaps [rsp+0x90], xmm9
000074267fbd74c6  vmovaps [rsp+0xA0], xmm10
000074267fbd74cf  vmovaps [rsp+0xB0], xmm11
000074267fbd74d8  vmovaps [rsp+0xC0], xmm12
000074267fbd74e1  vmovaps [rsp+0xD0], xmm13
000074267fbd74ea  vmovaps [rsp+0xE0], xmm15
000074267fbd74f3  sub rsp, 0x40
000074267fbd74f7  lea rdi, [rsp]
000074267fbd74fb  lea rsi, [rsp+0x10]
000074267fbd7500  lea rdx, [rsp+0x20]
000074267fbd7505  lea rcx, [rsp+0x30]
000074267fbd750a  mov r8d, 0x00
000074267fbd7510  lea r9, [r15+0x3A8]
000074267fbd7517  movaps [rdi], xmm14
000074267fbd751b  movaps [rsi], xmm15
000074267fbd751f  movaps [rdx], xmm2
000074267fbd7522  movaps [rcx], xmm1
000074267fbd7525  mov rax, 0x56D4E47AEA50
000074267fbd752f  call rax
000074267fbd7531  movaps xmm14, [rsp]
000074267fbd7536  add rsp, 0x40
000074267fbd753a  vmovaps xmm0, [rsp]
000074267fbd753f  vmovaps xmm1, [rsp+0x10]
000074267fbd7545  vmovaps xmm2, [rsp+0x20]
000074267fbd754b  vmovaps xmm3, [rsp+0x30]
000074267fbd7551  vmovaps xmm4, [rsp+0x40]
000074267fbd7557  vmovaps xmm5, [rsp+0x50]
000074267fbd755d  vmovaps xmm6, [rsp+0x60]
000074267fbd7563  vmovaps xmm7, [rsp+0x70]
000074267fbd7569  vmovaps xmm8, [rsp+0x80]
000074267fbd7572  vmovaps xmm9, [rsp+0x90]
000074267fbd757b  vmovaps xmm10, [rsp+0xA0]
000074267fbd7584  vmovaps xmm11, [rsp+0xB0]
000074267fbd758d  vmovaps xmm12, [rsp+0xC0]
000074267fbd7596  vmovaps xmm13, [rsp+0xD0]
000074267fbd759f  vmovaps xmm15, [rsp+0xE0]
000074267fbd75a8  add rsp, 0xF0
000074267fbd75af  pop r11
000074267fbd75b1  pop r10
000074267fbd75b3  pop r9
000074267fbd75b5  pop r8
000074267fbd75b7  pop rsi
000074267fbd75b8  pop rdi
000074267fbd75b9  pop rdx
000074267fbd75ba  pop rcx
000074267fbd75bb  pop rax
000074267fbd75bc  add rsp, 0x08
000074267fbd75c0  jmp 0x000074267FBD6691
000074267fbd75c5  sub rsp, 0x08
000074267fbd75c9  push rax
000074267fbd75ca  push rcx
000074267fbd75cb  push rdx
000074267fbd75cc  push rdi
000074267fbd75cd  push rsi
000074267fbd75ce  push r8
000074267fbd75d0  push r9
000074267fbd75d2  push r10
000074267fbd75d4  push r11
000074267fbd75d6  sub rsp, 0xF0
000074267fbd75dd  vmovaps [rsp], xmm0
000074267fbd75e2  vmovaps [rsp+0x10], xmm1
000074267fbd75e8  vmovaps [rsp+0x20], xmm3
000074267fbd75ee  vmovaps [rsp+0x30], xmm4
000074267fbd75f4  vmovaps [rsp+0x40], xmm5
000074267fbd75fa  vmovaps [rsp+0x50], xmm6
000074267fbd7600  vmovaps [rsp+0x60], xmm7
000074267fbd7606  vmovaps [rsp+0x70], xmm8
000074267fbd760c  vmovaps [rsp+0x80], xmm9
000074267fbd7615  vmovaps [rsp+0x90], xmm10
000074267fbd761e  vmovaps [rsp+0xA0], xmm11
000074267fbd7627  vmovaps [rsp+0xB0], xmm12
000074267fbd7630  vmovaps [rsp+0xC0], xmm13
000074267fbd7639  vmovaps [rsp+0xD0], xmm14
000074267fbd7642  vmovaps [rsp+0xE0], xmm15
000074267fbd764b  sub rsp, 0x40
000074267fbd764f  lea rdi, [rsp]
000074267fbd7653  lea rsi, [rsp+0x10]
000074267fbd7658  lea rdx, [rsp+0x20]
000074267fbd765d  lea rcx, [rsp+0x30]
000074267fbd7662  mov r8d, 0x00
000074267fbd7668  lea r9, [r15+0x3A8]
000074267fbd766f  movaps [rdi], xmm2
000074267fbd7672  movaps [rsi], xmm15
000074267fbd7676  movaps [rdx], xmm12
000074267fbd767a  movaps [rcx], xmm1
000074267fbd767d  mov rax, 0x56D4E47AEA50
000074267fbd7687  call rax
000074267fbd7689  movaps xmm2, [rsp]
000074267fbd768d  add rsp, 0x40
000074267fbd7691  vmovaps xmm0, [rsp]
000074267fbd7696  vmovaps xmm1, [rsp+0x10]
000074267fbd769c  vmovaps xmm3, [rsp+0x20]
000074267fbd76a2  vmovaps xmm4, [rsp+0x30]
000074267fbd76a8  vmovaps xmm5, [rsp+0x40]
000074267fbd76ae  vmovaps xmm6, [rsp+0x50]
000074267fbd76b4  vmovaps xmm7, [rsp+0x60]
000074267fbd76ba  vmovaps xmm8, [rsp+0x70]
000074267fbd76c0  vmovaps xmm9, [rsp+0x80]
000074267fbd76c9  vmovaps xmm10, [rsp+0x90]
000074267fbd76d2  vmovaps xmm11, [rsp+0xA0]
000074267fbd76db  vmovaps xmm12, [rsp+0xB0]
000074267fbd76e4  vmovaps xmm13, [rsp+0xC0]
000074267fbd76ed  vmovaps xmm14, [rsp+0xD0]
000074267fbd76f6  vmovaps xmm15, [rsp+0xE0]
000074267fbd76ff  add rsp, 0xF0
000074267fbd7706  pop r11
000074267fbd7708  pop r10
000074267fbd770a  pop r9
000074267fbd770c  pop r8
000074267fbd770e  pop rsi
000074267fbd770f  pop rdi
000074267fbd7710  pop rdx
000074267fbd7711  pop rcx
000074267fbd7712  pop rax
000074267fbd7713  add rsp, 0x08
000074267fbd7717  jmp 0x000074267FBD66CE
000074267fbd771c  sub rsp, 0x08
000074267fbd7720  push rax
000074267fbd7721  push rcx
000074267fbd7722  push rdx
000074267fbd7723  push rdi
000074267fbd7724  push rsi
000074267fbd7725  push r8
000074267fbd7727  push r9
000074267fbd7729  push r10
000074267fbd772b  push r11
000074267fbd772d  sub rsp, 0xF0
000074267fbd7734  vmovaps [rsp], xmm0
000074267fbd7739  vmovaps [rsp+0x10], xmm1
000074267fbd773f  vmovaps [rsp+0x20], xmm2
000074267fbd7745  vmovaps [rsp+0x30], xmm3
000074267fbd774b  vmovaps [rsp+0x40], xmm4
000074267fbd7751  vmovaps [rsp+0x50], xmm5
000074267fbd7757  vmovaps [rsp+0x60], xmm6
000074267fbd775d  vmovaps [rsp+0x70], xmm7
000074267fbd7763  vmovaps [rsp+0x80], xmm8
000074267fbd776c  vmovaps [rsp+0x90], xmm9
000074267fbd7775  vmovaps [rsp+0xA0], xmm10
000074267fbd777e  vmovaps [rsp+0xB0], xmm11
000074267fbd7787  vmovaps [rsp+0xC0], xmm13
000074267fbd7790  vmovaps [rsp+0xD0], xmm14
000074267fbd7799  vmovaps [rsp+0xE0], xmm15
000074267fbd77a2  sub rsp, 0x40
000074267fbd77a6  lea rdi, [rsp]
000074267fbd77aa  lea rsi, [rsp+0x10]
000074267fbd77af  lea rdx, [rsp+0x20]
000074267fbd77b4  lea rcx, [rsp+0x30]
000074267fbd77b9  mov r8d, 0x00
000074267fbd77bf  lea r9, [r15+0x3A8]
000074267fbd77c6  movaps [rdi], xmm12
000074267fbd77ca  movaps [rsi], xmm14
000074267fbd77ce  movaps [rdx], xmm3
000074267fbd77d1  movaps [rcx], xmm15
000074267fbd77d5  mov rax, 0x56D4E47AEA50
000074267fbd77df  call rax
000074267fbd77e1  movaps xmm12, [rsp]
000074267fbd77e6  add rsp, 0x40
000074267fbd77ea  vmovaps xmm0, [rsp]
000074267fbd77ef  vmovaps xmm1, [rsp+0x10]
000074267fbd77f5  vmovaps xmm2, [rsp+0x20]
000074267fbd77fb  vmovaps xmm3, [rsp+0x30]
000074267fbd7801  vmovaps xmm4, [rsp+0x40]
000074267fbd7807  vmovaps xmm5, [rsp+0x50]
000074267fbd780d  vmovaps xmm6, [rsp+0x60]
000074267fbd7813  vmovaps xmm7, [rsp+0x70]
000074267fbd7819  vmovaps xmm8, [rsp+0x80]
000074267fbd7822  vmovaps xmm9, [rsp+0x90]
000074267fbd782b  vmovaps xmm10, [rsp+0xA0]
000074267fbd7834  vmovaps xmm11, [rsp+0xB0]
000074267fbd783d  vmovaps xmm13, [rsp+0xC0]
000074267fbd7846  vmovaps xmm14, [rsp+0xD0]
000074267fbd784f  vmovaps xmm15, [rsp+0xE0]
000074267fbd7858  add rsp, 0xF0
000074267fbd785f  pop r11
000074267fbd7861  pop r10
000074267fbd7863  pop r9
000074267fbd7865  pop r8
000074267fbd7867  pop rsi
000074267fbd7868  pop rdi
000074267fbd7869  pop rdx
000074267fbd786a  pop rcx
000074267fbd786b  pop rax
000074267fbd786c  add rsp, 0x08
000074267fbd7870  jmp 0x000074267FBD6728
000074267fbd7875  sub rsp, 0x08
000074267fbd7879  push rax
000074267fbd787a  push rcx
000074267fbd787b  push rdx
000074267fbd787c  push rdi
000074267fbd787d  push rsi
000074267fbd787e  push r8
000074267fbd7880  push r9
000074267fbd7882  push r10
000074267fbd7884  push r11
000074267fbd7886  sub rsp, 0xF0
000074267fbd788d  vmovaps [rsp], xmm0
000074267fbd7892  vmovaps [rsp+0x10], xmm1
000074267fbd7898  vmovaps [rsp+0x20], xmm2
000074267fbd789e  vmovaps [rsp+0x30], xmm3
000074267fbd78a4  vmovaps [rsp+0x40], xmm4
000074267fbd78aa  vmovaps [rsp+0x50], xmm5
000074267fbd78b0  vmovaps [rsp+0x60], xmm6
000074267fbd78b6  vmovaps [rsp+0x70], xmm7
000074267fbd78bc  vmovaps [rsp+0x80], xmm8
000074267fbd78c5  vmovaps [rsp+0x90], xmm10
000074267fbd78ce  vmovaps [rsp+0xA0], xmm11
000074267fbd78d7  vmovaps [rsp+0xB0], xmm12
000074267fbd78e0  vmovaps [rsp+0xC0], xmm13
000074267fbd78e9  vmovaps [rsp+0xD0], xmm14
000074267fbd78f2  vmovaps [rsp+0xE0], xmm15
000074267fbd78fb  sub rsp, 0x40
000074267fbd78ff  lea rdi, [rsp]
000074267fbd7903  lea rsi, [rsp+0x10]
000074267fbd7908  lea rdx, [rsp+0x20]
000074267fbd790d  lea rcx, [rsp+0x30]
000074267fbd7912  mov r8d, 0x00
000074267fbd7918  lea r9, [r15+0x3A8]
000074267fbd791f  movaps [rdi], xmm9
000074267fbd7923  movaps [rsi], xmm13
000074267fbd7927  movaps [rdx], xmm14
000074267fbd792b  movaps [rcx], xmm6
000074267fbd792e  mov rax, 0x56D4E47AEA50
000074267fbd7938  call rax
000074267fbd793a  movaps xmm9, [rsp]
000074267fbd793f  add rsp, 0x40
000074267fbd7943  vmovaps xmm0, [rsp]
000074267fbd7948  vmovaps xmm1, [rsp+0x10]
000074267fbd794e  vmovaps xmm2, [rsp+0x20]
000074267fbd7954  vmovaps xmm3, [rsp+0x30]
000074267fbd795a  vmovaps xmm4, [rsp+0x40]
000074267fbd7960  vmovaps xmm5, [rsp+0x50]
000074267fbd7966  vmovaps xmm6, [rsp+0x60]
000074267fbd796c  vmovaps xmm7, [rsp+0x70]
000074267fbd7972  vmovaps xmm8, [rsp+0x80]
000074267fbd797b  vmovaps xmm10, [rsp+0x90]
000074267fbd7984  vmovaps xmm11, [rsp+0xA0]
000074267fbd798d  vmovaps xmm12, [rsp+0xB0]
000074267fbd7996  vmovaps xmm13, [rsp+0xC0]
000074267fbd799f  vmovaps xmm14, [rsp+0xD0]
000074267fbd79a8  vmovaps xmm15, [rsp+0xE0]
000074267fbd79b1  add rsp, 0xF0
000074267fbd79b8  pop r11
000074267fbd79ba  pop r10
000074267fbd79bc  pop r9
000074267fbd79be  pop r8
000074267fbd79c0  pop rsi
000074267fbd79c1  pop rdi
000074267fbd79c2  pop rdx
000074267fbd79c3  pop rcx
000074267fbd79c4  pop rax
000074267fbd79c5  add rsp, 0x08
000074267fbd79c9  jmp 0x000074267FBD67D2
000074267fbd79ce  sub rsp, 0x08
000074267fbd79d2  push rax
000074267fbd79d3  push rcx
000074267fbd79d4  push rdx
000074267fbd79d5  push rdi
000074267fbd79d6  push rsi
000074267fbd79d7  push r8
000074267fbd79d9  push r9
000074267fbd79db  push r10
000074267fbd79dd  push r11
000074267fbd79df  sub rsp, 0xF0
000074267fbd79e6  vmovaps [rsp], xmm0
000074267fbd79eb  vmovaps [rsp+0x10], xmm1
000074267fbd79f1  vmovaps [rsp+0x20], xmm2
000074267fbd79f7  vmovaps [rsp+0x30], xmm4
000074267fbd79fd  vmovaps [rsp+0x40], xmm5
000074267fbd7a03  vmovaps [rsp+0x50], xmm6
000074267fbd7a09  vmovaps [rsp+0x60], xmm7
000074267fbd7a0f  vmovaps [rsp+0x70], xmm8
000074267fbd7a15  vmovaps [rsp+0x80], xmm9
000074267fbd7a1e  vmovaps [rsp+0x90], xmm10
000074267fbd7a27  vmovaps [rsp+0xA0], xmm11
000074267fbd7a30  vmovaps [rsp+0xB0], xmm12
000074267fbd7a39  vmovaps [rsp+0xC0], xmm13
000074267fbd7a42  vmovaps [rsp+0xD0], xmm14
000074267fbd7a4b  vmovaps [rsp+0xE0], xmm15
000074267fbd7a54  sub rsp, 0x40
000074267fbd7a58  lea rdi, [rsp]
000074267fbd7a5c  lea rsi, [rsp+0x10]
000074267fbd7a61  lea rdx, [rsp+0x20]
000074267fbd7a66  lea rcx, [rsp+0x30]
000074267fbd7a6b  mov r8d, 0x00
000074267fbd7a71  lea r9, [r15+0x3A8]
000074267fbd7a78  movaps [rdi], xmm3
000074267fbd7a7b  movaps [rsi], xmm13
000074267fbd7a7f  movaps [rdx], xmm6
000074267fbd7a82  movaps [rcx], xmm14
000074267fbd7a86  mov rax, 0x56D4E47AEA50
000074267fbd7a90  call rax
000074267fbd7a92  movaps xmm3, [rsp]
000074267fbd7a96  add rsp, 0x40
000074267fbd7a9a  vmovaps xmm0, [rsp]
000074267fbd7a9f  vmovaps xmm1, [rsp+0x10]
000074267fbd7aa5  vmovaps xmm2, [rsp+0x20]
000074267fbd7aab  vmovaps xmm4, [rsp+0x30]
000074267fbd7ab1  vmovaps xmm5, [rsp+0x40]
000074267fbd7ab7  vmovaps xmm6, [rsp+0x50]
000074267fbd7abd  vmovaps xmm7, [rsp+0x60]
000074267fbd7ac3  vmovaps xmm8, [rsp+0x70]
000074267fbd7ac9  vmovaps xmm9, [rsp+0x80]
000074267fbd7ad2  vmovaps xmm10, [rsp+0x90]
000074267fbd7adb  vmovaps xmm11, [rsp+0xA0]
000074267fbd7ae4  vmovaps xmm12, [rsp+0xB0]
000074267fbd7aed  vmovaps xmm13, [rsp+0xC0]
000074267fbd7af6  vmovaps xmm14, [rsp+0xD0]
000074267fbd7aff  vmovaps xmm15, [rsp+0xE0]
000074267fbd7b08  add rsp, 0xF0
000074267fbd7b0f  pop r11
000074267fbd7b11  pop r10
000074267fbd7b13  pop r9
000074267fbd7b15  pop r8
000074267fbd7b17  pop rsi
000074267fbd7b18  pop rdi
000074267fbd7b19  pop rdx
000074267fbd7b1a  pop rcx
000074267fbd7b1b  pop rax
000074267fbd7b1c  add rsp, 0x08
000074267fbd7b20  jmp 0x000074267FBD680F
000074267fbd7b25  sub rsp, 0x08
000074267fbd7b29  push rax
000074267fbd7b2a  push rcx
000074267fbd7b2b  push rdx
000074267fbd7b2c  push rdi
000074267fbd7b2d  push rsi
000074267fbd7b2e  push r8
000074267fbd7b30  push r9
000074267fbd7b32  push r10
000074267fbd7b34  push r11
000074267fbd7b36  sub rsp, 0xF0
000074267fbd7b3d  vmovaps [rsp], xmm0
000074267fbd7b42  vmovaps [rsp+0x10], xmm1
000074267fbd7b48  vmovaps [rsp+0x20], xmm2
000074267fbd7b4e  vmovaps [rsp+0x30], xmm3
000074267fbd7b54  vmovaps [rsp+0x40], xmm4
000074267fbd7b5a  vmovaps [rsp+0x50], xmm5
000074267fbd7b60  vmovaps [rsp+0x60], xmm7
000074267fbd7b66  vmovaps [rsp+0x70], xmm8
000074267fbd7b6c  vmovaps [rsp+0x80], xmm9
000074267fbd7b75  vmovaps [rsp+0x90], xmm10
000074267fbd7b7e  vmovaps [rsp+0xA0], xmm11
000074267fbd7b87  vmovaps [rsp+0xB0], xmm12
000074267fbd7b90  vmovaps [rsp+0xC0], xmm13
000074267fbd7b99  vmovaps [rsp+0xD0], xmm14
000074267fbd7ba2  vmovaps [rsp+0xE0], xmm15
000074267fbd7bab  sub rsp, 0x40
000074267fbd7baf  lea rdi, [rsp]
000074267fbd7bb3  lea rsi, [rsp+0x10]
000074267fbd7bb8  lea rdx, [rsp+0x20]
000074267fbd7bbd  lea rcx, [rsp+0x30]
000074267fbd7bc2  mov r8d, 0x00
000074267fbd7bc8  lea r9, [r15+0x3A8]
000074267fbd7bcf  movaps [rdi], xmm6
000074267fbd7bd2  movaps [rsi], xmm2
000074267fbd7bd5  movaps [rdx], xmm14
000074267fbd7bd9  movaps [rcx], xmm1
000074267fbd7bdc  mov rax, 0x56D4E47AEA50
000074267fbd7be6  call rax
000074267fbd7be8  movaps xmm6, [rsp]
000074267fbd7bec  add rsp, 0x40
000074267fbd7bf0  vmovaps xmm0, [rsp]
000074267fbd7bf5  vmovaps xmm1, [rsp+0x10]
000074267fbd7bfb  vmovaps xmm2, [rsp+0x20]
000074267fbd7c01  vmovaps xmm3, [rsp+0x30]
000074267fbd7c07  vmovaps xmm4, [rsp+0x40]
000074267fbd7c0d  vmovaps xmm5, [rsp+0x50]
000074267fbd7c13  vmovaps xmm7, [rsp+0x60]
000074267fbd7c19  vmovaps xmm8, [rsp+0x70]
000074267fbd7c1f  vmovaps xmm9, [rsp+0x80]
000074267fbd7c28  vmovaps xmm10, [rsp+0x90]
000074267fbd7c31  vmovaps xmm11, [rsp+0xA0]
000074267fbd7c3a  vmovaps xmm12, [rsp+0xB0]
000074267fbd7c43  vmovaps xmm13, [rsp+0xC0]
000074267fbd7c4c  vmovaps xmm14, [rsp+0xD0]
000074267fbd7c55  vmovaps xmm15, [rsp+0xE0]
000074267fbd7c5e  add rsp, 0xF0
000074267fbd7c65  pop r11
000074267fbd7c67  pop r10
000074267fbd7c69  pop r9
000074267fbd7c6b  pop r8
000074267fbd7c6d  pop rsi
000074267fbd7c6e  pop rdi
000074267fbd7c6f  pop rdx
000074267fbd7c70  pop rcx
000074267fbd7c71  pop rax
000074267fbd7c72  add rsp, 0x08
000074267fbd7c76  jmp 0x000074267FBD683C
000074267fbd7c7b  sub rsp, 0x08
000074267fbd7c7f  push rax
000074267fbd7c80  push rcx
000074267fbd7c81  push rdx
000074267fbd7c82  push rdi
000074267fbd7c83  push rsi
000074267fbd7c84  push r8
000074267fbd7c86  push r9
000074267fbd7c88  push r10
000074267fbd7c8a  push r11
000074267fbd7c8c  sub rsp, 0xF0
000074267fbd7c93  vmovaps [rsp], xmm0
000074267fbd7c98  vmovaps [rsp+0x10], xmm1
000074267fbd7c9e  vmovaps [rsp+0x20], xmm2
000074267fbd7ca4  vmovaps [rsp+0x30], xmm3
000074267fbd7caa  vmovaps [rsp+0x40], xmm4
000074267fbd7cb0  vmovaps [rsp+0x50], xmm5
000074267fbd7cb6  vmovaps [rsp+0x60], xmm6
000074267fbd7cbc  vmovaps [rsp+0x70], xmm7
000074267fbd7cc2  vmovaps [rsp+0x80], xmm8
000074267fbd7ccb  vmovaps [rsp+0x90], xmm9
000074267fbd7cd4  vmovaps [rsp+0xA0], xmm10
000074267fbd7cdd  vmovaps [rsp+0xB0], xmm11
000074267fbd7ce6  vmovaps [rsp+0xC0], xmm12
000074267fbd7cef  vmovaps [rsp+0xD0], xmm14
000074267fbd7cf8  vmovaps [rsp+0xE0], xmm15
000074267fbd7d01  sub rsp, 0x40
000074267fbd7d05  lea rdi, [rsp]
000074267fbd7d09  lea rsi, [rsp+0x10]
000074267fbd7d0e  lea rdx, [rsp+0x20]
000074267fbd7d13  lea rcx, [rsp+0x30]
000074267fbd7d18  mov r8d, 0x00
000074267fbd7d1e  lea r9, [r15+0x3A8]
000074267fbd7d25  movaps [rdi], xmm13
000074267fbd7d29  movaps [rsi], xmm12
000074267fbd7d2d  movaps [rdx], xmm14
000074267fbd7d31  movaps [rcx], xmm1
000074267fbd7d34  mov rax, 0x56D4E47AEA50
000074267fbd7d3e  call rax
000074267fbd7d40  movaps xmm13, [rsp]
000074267fbd7d45  add rsp, 0x40
000074267fbd7d49  vmovaps xmm0, [rsp]
000074267fbd7d4e  vmovaps xmm1, [rsp+0x10]
000074267fbd7d54  vmovaps xmm2, [rsp+0x20]
000074267fbd7d5a  vmovaps xmm3, [rsp+0x30]
000074267fbd7d60  vmovaps xmm4, [rsp+0x40]
000074267fbd7d66  vmovaps xmm5, [rsp+0x50]
000074267fbd7d6c  vmovaps xmm6, [rsp+0x60]
000074267fbd7d72  vmovaps xmm7, [rsp+0x70]
000074267fbd7d78  vmovaps xmm8, [rsp+0x80]
000074267fbd7d81  vmovaps xmm9, [rsp+0x90]
000074267fbd7d8a  vmovaps xmm10, [rsp+0xA0]
000074267fbd7d93  vmovaps xmm11, [rsp+0xB0]
000074267fbd7d9c  vmovaps xmm12, [rsp+0xC0]
000074267fbd7da5  vmovaps xmm14, [rsp+0xD0]
000074267fbd7dae  vmovaps xmm15, [rsp+0xE0]
000074267fbd7db7  add rsp, 0xF0
000074267fbd7dbe  pop r11
000074267fbd7dc0  pop r10
000074267fbd7dc2  pop r9
000074267fbd7dc4  pop r8
000074267fbd7dc6  pop rsi
000074267fbd7dc7  pop rdi
000074267fbd7dc8  pop rdx
000074267fbd7dc9  pop rcx
000074267fbd7dca  pop rax
000074267fbd7dcb  add rsp, 0x08
000074267fbd7dcf  jmp 0x000074267FBD686E
000074267fbd7dd4  sub rsp, 0x08
000074267fbd7dd8  push rax
000074267fbd7dd9  push rcx
000074267fbd7dda  push rdx
000074267fbd7ddb  push rdi
000074267fbd7ddc  push rsi
000074267fbd7ddd  push r8
000074267fbd7ddf  push r9
000074267fbd7de1  push r10
000074267fbd7de3  push r11
000074267fbd7de5  sub rsp, 0xF0
000074267fbd7dec  vmovaps [rsp], xmm0
000074267fbd7df1  vmovaps [rsp+0x10], xmm1
000074267fbd7df7  vmovaps [rsp+0x20], xmm2
000074267fbd7dfd  vmovaps [rsp+0x30], xmm3
000074267fbd7e03  vmovaps [rsp+0x40], xmm4
000074267fbd7e09  vmovaps [rsp+0x50], xmm5
000074267fbd7e0f  vmovaps [rsp+0x60], xmm6
000074267fbd7e15  vmovaps [rsp+0x70], xmm7
000074267fbd7e1b  vmovaps [rsp+0x80], xmm8
000074267fbd7e24  vmovaps [rsp+0x90], xmm9
000074267fbd7e2d  vmovaps [rsp+0xA0], xmm10
000074267fbd7e36  vmovaps [rsp+0xB0], xmm11
000074267fbd7e3f  vmovaps [rsp+0xC0], xmm13
000074267fbd7e48  vmovaps [rsp+0xD0], xmm14
000074267fbd7e51  vmovaps [rsp+0xE0], xmm15
000074267fbd7e5a  sub rsp, 0x40
000074267fbd7e5e  lea rdi, [rsp]
000074267fbd7e62  lea rsi, [rsp+0x10]
000074267fbd7e67  lea rdx, [rsp+0x20]
000074267fbd7e6c  lea rcx, [rsp+0x30]
000074267fbd7e71  mov r8d, 0x00
000074267fbd7e77  lea r9, [r15+0x3A8]
000074267fbd7e7e  movaps [rdi], xmm12
000074267fbd7e82  movaps [rsi], xmm3
000074267fbd7e85  movaps [rdx], xmm14
000074267fbd7e89  movaps [rcx], xmm5
000074267fbd7e8c  mov rax, 0x56D4E47AEA50
000074267fbd7e96  call rax
000074267fbd7e98  movaps xmm12, [rsp]
000074267fbd7e9d  add rsp, 0x40
000074267fbd7ea1  vmovaps xmm0, [rsp]
000074267fbd7ea6  vmovaps xmm1, [rsp+0x10]
000074267fbd7eac  vmovaps xmm2, [rsp+0x20]
000074267fbd7eb2  vmovaps xmm3, [rsp+0x30]
000074267fbd7eb8  vmovaps xmm4, [rsp+0x40]
000074267fbd7ebe  vmovaps xmm5, [rsp+0x50]
000074267fbd7ec4  vmovaps xmm6, [rsp+0x60]
000074267fbd7eca  vmovaps xmm7, [rsp+0x70]
000074267fbd7ed0  vmovaps xmm8, [rsp+0x80]
000074267fbd7ed9  vmovaps xmm9, [rsp+0x90]
000074267fbd7ee2  vmovaps xmm10, [rsp+0xA0]
000074267fbd7eeb  vmovaps xmm11, [rsp+0xB0]
000074267fbd7ef4  vmovaps xmm13, [rsp+0xC0]
000074267fbd7efd  vmovaps xmm14, [rsp+0xD0]
000074267fbd7f06  vmovaps xmm15, [rsp+0xE0]
000074267fbd7f0f  add rsp, 0xF0
000074267fbd7f16  pop r11
000074267fbd7f18  pop r10
000074267fbd7f1a  pop r9
000074267fbd7f1c  pop r8
000074267fbd7f1e  pop rsi
000074267fbd7f1f  pop rdi
000074267fbd7f20  pop rdx
000074267fbd7f21  pop rcx
000074267fbd7f22  pop rax
000074267fbd7f23  add rsp, 0x08
000074267fbd7f27  jmp 0x000074267FBD68CB
000074267fbd7f2c  sub rsp, 0x08
000074267fbd7f30  push rax
000074267fbd7f31  push rcx
000074267fbd7f32  push rdx
000074267fbd7f33  push rdi
000074267fbd7f34  push rsi
000074267fbd7f35  push r8
000074267fbd7f37  push r9
000074267fbd7f39  push r10
000074267fbd7f3b  push r11
000074267fbd7f3d  sub rsp, 0xF0
000074267fbd7f44  vmovaps [rsp], xmm0
000074267fbd7f49  vmovaps [rsp+0x10], xmm1
000074267fbd7f4f  vmovaps [rsp+0x20], xmm2
000074267fbd7f55  vmovaps [rsp+0x30], xmm3
000074267fbd7f5b  vmovaps [rsp+0x40], xmm4
000074267fbd7f61  vmovaps [rsp+0x50], xmm5
000074267fbd7f67  vmovaps [rsp+0x60], xmm6
000074267fbd7f6d  vmovaps [rsp+0x70], xmm7
000074267fbd7f73  vmovaps [rsp+0x80], xmm8
000074267fbd7f7c  vmovaps [rsp+0x90], xmm9
000074267fbd7f85  vmovaps [rsp+0xA0], xmm11
000074267fbd7f8e  vmovaps [rsp+0xB0], xmm12
000074267fbd7f97  vmovaps [rsp+0xC0], xmm13
000074267fbd7fa0  vmovaps [rsp+0xD0], xmm14
000074267fbd7fa9  vmovaps [rsp+0xE0], xmm15
000074267fbd7fb2  sub rsp, 0x40
000074267fbd7fb6  lea rdi, [rsp]
000074267fbd7fba  lea rsi, [rsp+0x10]
000074267fbd7fbf  lea rdx, [rsp+0x20]
000074267fbd7fc4  lea rcx, [rsp+0x30]
000074267fbd7fc9  mov r8d, 0x00
000074267fbd7fcf  lea r9, [r15+0x3A8]
000074267fbd7fd6  movaps [rdi], xmm10
000074267fbd7fda  movaps [rsi], xmm9
000074267fbd7fde  movaps [rdx], xmm7
000074267fbd7fe1  movaps [rcx], xmm14
000074267fbd7fe5  mov rax, 0x56D4E47AEA50
000074267fbd7fef  call rax
000074267fbd7ff1  movaps xmm10, [rsp]
000074267fbd7ff6  add rsp, 0x40
000074267fbd7ffa  vmovaps xmm0, [rsp]
000074267fbd7fff  vmovaps xmm1, [rsp+0x10]
000074267fbd8005  vmovaps xmm2, [rsp+0x20]
000074267fbd800b  vmovaps xmm3, [rsp+0x30]
000074267fbd8011  vmovaps xmm4, [rsp+0x40]
000074267fbd8017  vmovaps xmm5, [rsp+0x50]
000074267fbd801d  vmovaps xmm6, [rsp+0x60]
000074267fbd8023  vmovaps xmm7, [rsp+0x70]
000074267fbd8029  vmovaps xmm8, [rsp+0x80]
000074267fbd8032  vmovaps xmm9, [rsp+0x90]
000074267fbd803b  vmovaps xmm11, [rsp+0xA0]
000074267fbd8044  vmovaps xmm12, [rsp+0xB0]
000074267fbd804d  vmovaps xmm13, [rsp+0xC0]
000074267fbd8056  vmovaps xmm14, [rsp+0xD0]
000074267fbd805f  vmovaps xmm15, [rsp+0xE0]
000074267fbd8068  add rsp, 0xF0
000074267fbd806f  pop r11
000074267fbd8071  pop r10
000074267fbd8073  pop r9
000074267fbd8075  pop r8
000074267fbd8077  pop rsi
000074267fbd8078  pop rdi
000074267fbd8079  pop rdx
000074267fbd807a  pop rcx
000074267fbd807b  pop rax
000074267fbd807c  add rsp, 0x08
000074267fbd8080  jmp 0x000074267FBD68F1
000074267fbd8085  call 0x000074267FAE45A0
000074267fbd808a  jmp 0x000074267FBD68FE
000074267fbd808f  sub rsp, 0x08
000074267fbd8093  push rax
000074267fbd8094  push rcx
000074267fbd8095  push rdx
000074267fbd8096  push rdi
000074267fbd8097  push rsi
000074267fbd8098  push r8
000074267fbd809a  push r9
000074267fbd809c  push r10
000074267fbd809e  push r11
000074267fbd80a0  sub rsp, 0xF0
000074267fbd80a7  vmovaps [rsp], xmm0
000074267fbd80ac  vmovaps [rsp+0x10], xmm1
000074267fbd80b2  vmovaps [rsp+0x20], xmm2
000074267fbd80b8  vmovaps [rsp+0x30], xmm3
000074267fbd80be  vmovaps [rsp+0x40], xmm4
000074267fbd80c4  vmovaps [rsp+0x50], xmm6
000074267fbd80ca  vmovaps [rsp+0x60], xmm7
000074267fbd80d0  vmovaps [rsp+0x70], xmm8
000074267fbd80d6  vmovaps [rsp+0x80], xmm9
000074267fbd80df  vmovaps [rsp+0x90], xmm10
000074267fbd80e8  vmovaps [rsp+0xA0], xmm11
000074267fbd80f1  vmovaps [rsp+0xB0], xmm12
000074267fbd80fa  vmovaps [rsp+0xC0], xmm13
000074267fbd8103  vmovaps [rsp+0xD0], xmm14
000074267fbd810c  vmovaps [rsp+0xE0], xmm15
000074267fbd8115  sub rsp, 0x40
000074267fbd8119  lea rdi, [rsp]
000074267fbd811d  lea rsi, [rsp+0x10]
000074267fbd8122  lea rdx, [rsp+0x20]
000074267fbd8127  lea rcx, [rsp+0x30]
000074267fbd812c  mov r8d, 0x00
000074267fbd8132  lea r9, [r15+0x3A8]
000074267fbd8139  movaps [rdi], xmm5
000074267fbd813c  movaps [rsi], xmm6
000074267fbd813f  movaps [rdx], xmm7
000074267fbd8142  movaps [rcx], xmm9
000074267fbd8146  mov rax, 0x56D4E47AEA50
000074267fbd8150  call rax
000074267fbd8152  movaps xmm5, [rsp]
000074267fbd8156  add rsp, 0x40
000074267fbd815a  vmovaps xmm0, [rsp]
000074267fbd815f  vmovaps xmm1, [rsp+0x10]
000074267fbd8165  vmovaps xmm2, [rsp+0x20]
000074267fbd816b  vmovaps xmm3, [rsp+0x30]
000074267fbd8171  vmovaps xmm4, [rsp+0x40]
000074267fbd8177  vmovaps xmm6, [rsp+0x50]
000074267fbd817d  vmovaps xmm7, [rsp+0x60]
000074267fbd8183  vmovaps xmm8, [rsp+0x70]
000074267fbd8189  vmovaps xmm9, [rsp+0x80]
000074267fbd8192  vmovaps xmm10, [rsp+0x90]
000074267fbd819b  vmovaps xmm11, [rsp+0xA0]
000074267fbd81a4  vmovaps xmm12, [rsp+0xB0]
000074267fbd81ad  vmovaps xmm13, [rsp+0xC0]
000074267fbd81b6  vmovaps xmm14, [rsp+0xD0]
000074267fbd81bf  vmovaps xmm15, [rsp+0xE0]
000074267fbd81c8  add rsp, 0xF0
000074267fbd81cf  pop r11
000074267fbd81d1  pop r10
000074267fbd81d3  pop r9
000074267fbd81d5  pop r8
000074267fbd81d7  pop rsi
000074267fbd81d8  pop rdi
000074267fbd81d9  pop rdx
000074267fbd81da  pop rcx
000074267fbd81db  pop rax
000074267fbd81dc  add rsp, 0x08
000074267fbd81e0  jmp 0x000074267FBD6930
000074267fbd81e5  sub rsp, 0x08
000074267fbd81e9  push rax
000074267fbd81ea  push rcx
000074267fbd81eb  push rdx
000074267fbd81ec  push rdi
000074267fbd81ed  push rsi
000074267fbd81ee  push r8
000074267fbd81f0  push r9
000074267fbd81f2  push r10
000074267fbd81f4  push r11
000074267fbd81f6  sub rsp, 0xF0
000074267fbd81fd  vmovaps [rsp], xmm0
000074267fbd8202  vmovaps [rsp+0x10], xmm1
000074267fbd8208  vmovaps [rsp+0x20], xmm2
000074267fbd820e  vmovaps [rsp+0x30], xmm3
000074267fbd8214  vmovaps [rsp+0x40], xmm4
000074267fbd821a  vmovaps [rsp+0x50], xmm5
000074267fbd8220  vmovaps [rsp+0x60], xmm6
000074267fbd8226  vmovaps [rsp+0x70], xmm8
000074267fbd822c  vmovaps [rsp+0x80], xmm9
000074267fbd8235  vmovaps [rsp+0x90], xmm10
000074267fbd823e  vmovaps [rsp+0xA0], xmm11
000074267fbd8247  vmovaps [rsp+0xB0], xmm12
000074267fbd8250  vmovaps [rsp+0xC0], xmm13
000074267fbd8259  vmovaps [rsp+0xD0], xmm14
000074267fbd8262  vmovaps [rsp+0xE0], xmm15
000074267fbd826b  sub rsp, 0x40
000074267fbd826f  lea rdi, [rsp]
000074267fbd8273  lea rsi, [rsp+0x10]
000074267fbd8278  lea rdx, [rsp+0x20]
000074267fbd827d  lea rcx, [rsp+0x30]
000074267fbd8282  mov r8d, 0x00
000074267fbd8288  lea r9, [r15+0x3A8]
000074267fbd828f  movaps [rdi], xmm7
000074267fbd8292  movaps [rsi], xmm13
000074267fbd8296  movaps [rdx], xmm1
000074267fbd8299  movaps [rcx], xmm9
000074267fbd829d  mov rax, 0x56D4E47AEA50
000074267fbd82a7  call rax
000074267fbd82a9  movaps xmm7, [rsp]
000074267fbd82ad  add rsp, 0x40
000074267fbd82b1  vmovaps xmm0, [rsp]
000074267fbd82b6  vmovaps xmm1, [rsp+0x10]
000074267fbd82bc  vmovaps xmm2, [rsp+0x20]
000074267fbd82c2  vmovaps xmm3, [rsp+0x30]
000074267fbd82c8  vmovaps xmm4, [rsp+0x40]
000074267fbd82ce  vmovaps xmm5, [rsp+0x50]
000074267fbd82d4  vmovaps xmm6, [rsp+0x60]
000074267fbd82da  vmovaps xmm8, [rsp+0x70]
000074267fbd82e0  vmovaps xmm9, [rsp+0x80]
000074267fbd82e9  vmovaps xmm10, [rsp+0x90]
000074267fbd82f2  vmovaps xmm11, [rsp+0xA0]
000074267fbd82fb  vmovaps xmm12, [rsp+0xB0]
000074267fbd8304  vmovaps xmm13, [rsp+0xC0]
000074267fbd830d  vmovaps xmm14, [rsp+0xD0]
000074267fbd8316  vmovaps xmm15, [rsp+0xE0]
000074267fbd831f  add rsp, 0xF0
000074267fbd8326  pop r11
000074267fbd8328  pop r10
000074267fbd832a  pop r9
000074267fbd832c  pop r8
000074267fbd832e  pop rsi
000074267fbd832f  pop rdi
000074267fbd8330  pop rdx
000074267fbd8331  pop rcx
000074267fbd8332  pop rax
000074267fbd8333  add rsp, 0x08
000074267fbd8337  jmp 0x000074267FBD6955
000074267fbd833c  call 0x000074267FAE3320
000074267fbd8341  jmp 0x000074267FBD6978
000074267fbd8346  call 0x000074267FADE950
000074267fbd834b  jmp 0x000074267FBD6982
000074267fbd8350  sub rsp, 0x08
000074267fbd8354  push rax
000074267fbd8355  push rcx
000074267fbd8356  push rdx
000074267fbd8357  push rdi
000074267fbd8358  push rsi
000074267fbd8359  push r8
000074267fbd835b  push r9
000074267fbd835d  push r10
000074267fbd835f  push r11
000074267fbd8361  sub rsp, 0xF0
000074267fbd8368  vmovaps [rsp], xmm0
000074267fbd836d  vmovaps [rsp+0x10], xmm1
000074267fbd8373  vmovaps [rsp+0x20], xmm3
000074267fbd8379  vmovaps [rsp+0x30], xmm4
000074267fbd837f  vmovaps [rsp+0x40], xmm5
000074267fbd8385  vmovaps [rsp+0x50], xmm6
000074267fbd838b  vmovaps [rsp+0x60], xmm7
000074267fbd8391  vmovaps [rsp+0x70], xmm8
000074267fbd8397  vmovaps [rsp+0x80], xmm9
000074267fbd83a0  vmovaps [rsp+0x90], xmm10
000074267fbd83a9  vmovaps [rsp+0xA0], xmm11
000074267fbd83b2  vmovaps [rsp+0xB0], xmm12
000074267fbd83bb  vmovaps [rsp+0xC0], xmm13
000074267fbd83c4  vmovaps [rsp+0xD0], xmm14
000074267fbd83cd  vmovaps [rsp+0xE0], xmm15
000074267fbd83d6  sub rsp, 0x40
000074267fbd83da  lea rdi, [rsp]
000074267fbd83de  lea rsi, [rsp+0x10]
000074267fbd83e3  lea rdx, [rsp+0x20]
000074267fbd83e8  lea rcx, [rsp+0x30]
000074267fbd83ed  mov r8d, 0x00
000074267fbd83f3  lea r9, [r15+0x3A8]
000074267fbd83fa  movaps [rdi], xmm2
000074267fbd83fd  movaps [rsi], xmm12
000074267fbd8401  movaps [rdx], xmm6
000074267fbd8404  movaps [rcx], xmm3
000074267fbd8407  mov rax, 0x56D4E47AEA50
000074267fbd8411  call rax
000074267fbd8413  movaps xmm2, [rsp]
000074267fbd8417  add rsp, 0x40
000074267fbd841b  vmovaps xmm0, [rsp]
000074267fbd8420  vmovaps xmm1, [rsp+0x10]
000074267fbd8426  vmovaps xmm3, [rsp+0x20]
000074267fbd842c  vmovaps xmm4, [rsp+0x30]
000074267fbd8432  vmovaps xmm5, [rsp+0x40]
000074267fbd8438  vmovaps xmm6, [rsp+0x50]
000074267fbd843e  vmovaps xmm7, [rsp+0x60]
000074267fbd8444  vmovaps xmm8, [rsp+0x70]
000074267fbd844a  vmovaps xmm9, [rsp+0x80]
000074267fbd8453  vmovaps xmm10, [rsp+0x90]
000074267fbd845c  vmovaps xmm11, [rsp+0xA0]
000074267fbd8465  vmovaps xmm12, [rsp+0xB0]
000074267fbd846e  vmovaps xmm13, [rsp+0xC0]
000074267fbd8477  vmovaps xmm14, [rsp+0xD0]
000074267fbd8480  vmovaps xmm15, [rsp+0xE0]
000074267fbd8489  add rsp, 0xF0
000074267fbd8490  pop r11
000074267fbd8492  pop r10
000074267fbd8494  pop r9
000074267fbd8496  pop r8
000074267fbd8498  pop rsi
000074267fbd8499  pop rdi
000074267fbd849a  pop rdx
000074267fbd849b  pop rcx
000074267fbd849c  pop rax
000074267fbd849d  add rsp, 0x08
000074267fbd84a1  jmp 0x000074267FBD69C8
000074267fbd84a6  sub rsp, 0x08
000074267fbd84aa  push rax
000074267fbd84ab  push rcx
000074267fbd84ac  push rdx
000074267fbd84ad  push rdi
000074267fbd84ae  push rsi
000074267fbd84af  push r8
000074267fbd84b1  push r9
000074267fbd84b3  push r10
000074267fbd84b5  push r11
000074267fbd84b7  sub rsp, 0xF0
000074267fbd84be  vmovaps [rsp], xmm0
000074267fbd84c3  vmovaps [rsp+0x10], xmm1
000074267fbd84c9  vmovaps [rsp+0x20], xmm2
000074267fbd84cf  vmovaps [rsp+0x30], xmm3
000074267fbd84d5  vmovaps [rsp+0x40], xmm4
000074267fbd84db  vmovaps [rsp+0x50], xmm5
000074267fbd84e1  vmovaps [rsp+0x60], xmm7
000074267fbd84e7  vmovaps [rsp+0x70], xmm8
000074267fbd84ed  vmovaps [rsp+0x80], xmm9
000074267fbd84f6  vmovaps [rsp+0x90], xmm10
000074267fbd84ff  vmovaps [rsp+0xA0], xmm11
000074267fbd8508  vmovaps [rsp+0xB0], xmm12
000074267fbd8511  vmovaps [rsp+0xC0], xmm13
000074267fbd851a  vmovaps [rsp+0xD0], xmm14
000074267fbd8523  vmovaps [rsp+0xE0], xmm15
000074267fbd852c  sub rsp, 0x40
000074267fbd8530  lea rdi, [rsp]
000074267fbd8534  lea rsi, [rsp+0x10]
000074267fbd8539  lea rdx, [rsp+0x20]
000074267fbd853e  lea rcx, [rsp+0x30]
000074267fbd8543  mov r8d, 0x00
000074267fbd8549  lea r9, [r15+0x3A8]
000074267fbd8550  movaps [rdi], xmm6
000074267fbd8553  movaps [rsi], xmm10
000074267fbd8557  movaps [rdx], xmm12
000074267fbd855b  movaps [rcx], xmm1
000074267fbd855e  mov rax, 0x56D4E47AEA50
000074267fbd8568  call rax
000074267fbd856a  movaps xmm6, [rsp]
000074267fbd856e  add rsp, 0x40
000074267fbd8572  vmovaps xmm0, [rsp]
000074267fbd8577  vmovaps xmm1, [rsp+0x10]
000074267fbd857d  vmovaps xmm2, [rsp+0x20]
000074267fbd8583  vmovaps xmm3, [rsp+0x30]
000074267fbd8589  vmovaps xmm4, [rsp+0x40]
000074267fbd858f  vmovaps xmm5, [rsp+0x50]
000074267fbd8595  vmovaps xmm7, [rsp+0x60]
000074267fbd859b  vmovaps xmm8, [rsp+0x70]
000074267fbd85a1  vmovaps xmm9, [rsp+0x80]
000074267fbd85aa  vmovaps xmm10, [rsp+0x90]
000074267fbd85b3  vmovaps xmm11, [rsp+0xA0]
000074267fbd85bc  vmovaps xmm12, [rsp+0xB0]
000074267fbd85c5  vmovaps xmm13, [rsp+0xC0]
000074267fbd85ce  vmovaps xmm14, [rsp+0xD0]
000074267fbd85d7  vmovaps xmm15, [rsp+0xE0]
000074267fbd85e0  add rsp, 0xF0
000074267fbd85e7  pop r11
000074267fbd85e9  pop r10
000074267fbd85eb  pop r9
000074267fbd85ed  pop r8
000074267fbd85ef  pop rsi
000074267fbd85f0  pop rdi
000074267fbd85f1  pop rdx
000074267fbd85f2  pop rcx
000074267fbd85f3  pop rax
000074267fbd85f4  add rsp, 0x08
000074267fbd85f8  jmp 0x000074267FBD69F6
000074267fbd85fd  sub rsp, 0x08
000074267fbd8601  push rax
000074267fbd8602  push rcx
000074267fbd8603  push rdx
000074267fbd8604  push rdi
000074267fbd8605  push rsi
000074267fbd8606  push r8
000074267fbd8608  push r9
000074267fbd860a  push r10
000074267fbd860c  push r11
000074267fbd860e  sub rsp, 0xF0
000074267fbd8615  vmovaps [rsp], xmm0
000074267fbd861a  vmovaps [rsp+0x10], xmm1
000074267fbd8620  vmovaps [rsp+0x20], xmm2
000074267fbd8626  vmovaps [rsp+0x30], xmm3
000074267fbd862c  vmovaps [rsp+0x40], xmm4
000074267fbd8632  vmovaps [rsp+0x50], xmm5
000074267fbd8638  vmovaps [rsp+0x60], xmm6
000074267fbd863e  vmovaps [rsp+0x70], xmm7
000074267fbd8644  vmovaps [rsp+0x80], xmm8
000074267fbd864d  vmovaps [rsp+0x90], xmm9
000074267fbd8656  vmovaps [rsp+0xA0], xmm11
000074267fbd865f  vmovaps [rsp+0xB0], xmm12
000074267fbd8668  vmovaps [rsp+0xC0], xmm13
000074267fbd8671  vmovaps [rsp+0xD0], xmm14
000074267fbd867a  vmovaps [rsp+0xE0], xmm15
000074267fbd8683  sub rsp, 0x40
000074267fbd8687  lea rdi, [rsp]
000074267fbd868b  lea rsi, [rsp+0x10]
000074267fbd8690  lea rdx, [rsp+0x20]
000074267fbd8695  lea rcx, [rsp+0x30]
000074267fbd869a  mov r8d, 0x00
000074267fbd86a0  lea r9, [r15+0x3A8]
000074267fbd86a7  movaps [rdi], xmm10
000074267fbd86ab  movaps [rsi], xmm5
000074267fbd86ae  movaps [rdx], xmm12
000074267fbd86b2  movaps [rcx], xmm1
000074267fbd86b5  mov rax, 0x56D4E47AEA50
000074267fbd86bf  call rax
000074267fbd86c1  movaps xmm10, [rsp]
000074267fbd86c6  add rsp, 0x40
000074267fbd86ca  vmovaps xmm0, [rsp]
000074267fbd86cf  vmovaps xmm1, [rsp+0x10]
000074267fbd86d5  vmovaps xmm2, [rsp+0x20]
000074267fbd86db  vmovaps xmm3, [rsp+0x30]
000074267fbd86e1  vmovaps xmm4, [rsp+0x40]
000074267fbd86e7  vmovaps xmm5, [rsp+0x50]
000074267fbd86ed  vmovaps xmm6, [rsp+0x60]
000074267fbd86f3  vmovaps xmm7, [rsp+0x70]
000074267fbd86f9  vmovaps xmm8, [rsp+0x80]
000074267fbd8702  vmovaps xmm9, [rsp+0x90]
000074267fbd870b  vmovaps xmm11, [rsp+0xA0]
000074267fbd8714  vmovaps xmm12, [rsp+0xB0]
000074267fbd871d  vmovaps xmm13, [rsp+0xC0]
000074267fbd8726  vmovaps xmm14, [rsp+0xD0]
000074267fbd872f  vmovaps xmm15, [rsp+0xE0]
000074267fbd8738  add rsp, 0xF0
000074267fbd873f  pop r11
000074267fbd8741  pop r10
000074267fbd8743  pop r9
000074267fbd8745  pop r8
000074267fbd8747  pop rsi
000074267fbd8748  pop rdi
000074267fbd8749  pop rdx
000074267fbd874a  pop rcx
000074267fbd874b  pop rax
000074267fbd874c  add rsp, 0x08
000074267fbd8750  jmp 0x000074267FBD6A25
000074267fbd8755  sub rsp, 0x08
000074267fbd8759  push rax
000074267fbd875a  push rcx
000074267fbd875b  push rdx
000074267fbd875c  push rdi
000074267fbd875d  push rsi
000074267fbd875e  push r8
000074267fbd8760  push r9
000074267fbd8762  push r10
000074267fbd8764  push r11
000074267fbd8766  sub rsp, 0xF0
000074267fbd876d  vmovaps [rsp], xmm0
000074267fbd8772  vmovaps [rsp+0x10], xmm1
000074267fbd8778  vmovaps [rsp+0x20], xmm2
000074267fbd877e  vmovaps [rsp+0x30], xmm3
000074267fbd8784  vmovaps [rsp+0x40], xmm4
000074267fbd878a  vmovaps [rsp+0x50], xmm5
000074267fbd8790  vmovaps [rsp+0x60], xmm6
000074267fbd8796  vmovaps [rsp+0x70], xmm7
000074267fbd879c  vmovaps [rsp+0x80], xmm8
000074267fbd87a5  vmovaps [rsp+0x90], xmm9
000074267fbd87ae  vmovaps [rsp+0xA0], xmm10
000074267fbd87b7  vmovaps [rsp+0xB0], xmm11
000074267fbd87c0  vmovaps [rsp+0xC0], xmm13
000074267fbd87c9  vmovaps [rsp+0xD0], xmm14
000074267fbd87d2  vmovaps [rsp+0xE0], xmm15
000074267fbd87db  sub rsp, 0x40
000074267fbd87df  lea rdi, [rsp]
000074267fbd87e3  lea rsi, [rsp+0x10]
000074267fbd87e8  lea rdx, [rsp+0x20]
000074267fbd87ed  lea rcx, [rsp+0x30]
000074267fbd87f2  mov r8d, 0x00
000074267fbd87f8  lea r9, [r15+0x3A8]
000074267fbd87ff  movaps [rdi], xmm12
000074267fbd8803  movaps [rsi], xmm7
000074267fbd8806  movaps [rdx], xmm15
000074267fbd880a  movaps [rcx], xmm1
000074267fbd880d  mov rax, 0x56D4E47AEA50
000074267fbd8817  call rax
000074267fbd8819  movaps xmm12, [rsp]
000074267fbd881e  add rsp, 0x40
000074267fbd8822  vmovaps xmm0, [rsp]
000074267fbd8827  vmovaps xmm1, [rsp+0x10]
000074267fbd882d  vmovaps xmm2, [rsp+0x20]
000074267fbd8833  vmovaps xmm3, [rsp+0x30]
000074267fbd8839  vmovaps xmm4, [rsp+0x40]
000074267fbd883f  vmovaps xmm5, [rsp+0x50]
000074267fbd8845  vmovaps xmm6, [rsp+0x60]
000074267fbd884b  vmovaps xmm7, [rsp+0x70]
000074267fbd8851  vmovaps xmm8, [rsp+0x80]
000074267fbd885a  vmovaps xmm9, [rsp+0x90]
000074267fbd8863  vmovaps xmm10, [rsp+0xA0]
000074267fbd886c  vmovaps xmm11, [rsp+0xB0]
000074267fbd8875  vmovaps xmm13, [rsp+0xC0]
000074267fbd887e  vmovaps xmm14, [rsp+0xD0]
000074267fbd8887  vmovaps xmm15, [rsp+0xE0]
000074267fbd8890  add rsp, 0xF0
000074267fbd8897  pop r11
000074267fbd8899  pop r10
000074267fbd889b  pop r9
000074267fbd889d  pop r8
000074267fbd889f  pop rsi
000074267fbd88a0  pop rdi
000074267fbd88a1  pop rdx
000074267fbd88a2  pop rcx
000074267fbd88a3  pop rax
000074267fbd88a4  add rsp, 0x08
000074267fbd88a8  jmp 0x000074267FBD6A4E
000074267fbd88ad  call 0x000074267FAD64F0
000074267fbd88b2  jmp 0x000074267FBD6A58
000074267fbd88b7  call 0x000074267FAE5820
000074267fbd88bc  jmp 0x000074267FBD6A62
000074267fbd88c1  sub rsp, 0x08
000074267fbd88c5  push rax
000074267fbd88c6  push rcx
000074267fbd88c7  push rdx
000074267fbd88c8  push rdi
000074267fbd88c9  push rsi
000074267fbd88ca  push r8
000074267fbd88cc  push r9
000074267fbd88ce  push r10
000074267fbd88d0  push r11
000074267fbd88d2  sub rsp, 0xF0
000074267fbd88d9  vmovaps [rsp], xmm0
000074267fbd88de  vmovaps [rsp+0x10], xmm1
000074267fbd88e4  vmovaps [rsp+0x20], xmm2
000074267fbd88ea  vmovaps [rsp+0x30], xmm3
000074267fbd88f0  vmovaps [rsp+0x40], xmm4
000074267fbd88f6  vmovaps [rsp+0x50], xmm5
000074267fbd88fc  vmovaps [rsp+0x60], xmm6
000074267fbd8902  vmovaps [rsp+0x70], xmm8
000074267fbd8908  vmovaps [rsp+0x80], xmm9
000074267fbd8911  vmovaps [rsp+0x90], xmm10
000074267fbd891a  vmovaps [rsp+0xA0], xmm11
000074267fbd8923  vmovaps [rsp+0xB0], xmm12
000074267fbd892c  vmovaps [rsp+0xC0], xmm13
000074267fbd8935  vmovaps [rsp+0xD0], xmm14
000074267fbd893e  vmovaps [rsp+0xE0], xmm15
000074267fbd8947  sub rsp, 0x40
000074267fbd894b  lea rdi, [rsp]
000074267fbd894f  lea rsi, [rsp+0x10]
000074267fbd8954  lea rdx, [rsp+0x20]
000074267fbd8959  lea rcx, [rsp+0x30]
000074267fbd895e  mov r8d, 0x00
000074267fbd8964  lea r9, [r15+0x3A8]
000074267fbd896b  movaps [rdi], xmm7
000074267fbd896e  movaps [rsi], xmm2
000074267fbd8971  movaps [rdx], xmm9
000074267fbd8975  movaps [rcx], xmm11
000074267fbd8979  mov rax, 0x56D4E47AEA50
000074267fbd8983  call rax
000074267fbd8985  movaps xmm7, [rsp]
000074267fbd8989  add rsp, 0x40
000074267fbd898d  vmovaps xmm0, [rsp]
000074267fbd8992  vmovaps xmm1, [rsp+0x10]
000074267fbd8998  vmovaps xmm2, [rsp+0x20]
000074267fbd899e  vmovaps xmm3, [rsp+0x30]
000074267fbd89a4  vmovaps xmm4, [rsp+0x40]
000074267fbd89aa  vmovaps xmm5, [rsp+0x50]
000074267fbd89b0  vmovaps xmm6, [rsp+0x60]
000074267fbd89b6  vmovaps xmm8, [rsp+0x70]
000074267fbd89bc  vmovaps xmm9, [rsp+0x80]
000074267fbd89c5  vmovaps xmm10, [rsp+0x90]
000074267fbd89ce  vmovaps xmm11, [rsp+0xA0]
000074267fbd89d7  vmovaps xmm12, [rsp+0xB0]
000074267fbd89e0  vmovaps xmm13, [rsp+0xC0]
000074267fbd89e9  vmovaps xmm14, [rsp+0xD0]
000074267fbd89f2  vmovaps xmm15, [rsp+0xE0]
000074267fbd89fb  add rsp, 0xF0
000074267fbd8a02  pop r11
000074267fbd8a04  pop r10
000074267fbd8a06  pop r9
000074267fbd8a08  pop r8
000074267fbd8a0a  pop rsi
000074267fbd8a0b  pop rdi
000074267fbd8a0c  pop rdx
000074267fbd8a0d  pop rcx
000074267fbd8a0e  pop rax
000074267fbd8a0f  add rsp, 0x08
000074267fbd8a13  jmp 0x000074267FBD6A96
000074267fbd8a18  sub rsp, 0x08
000074267fbd8a1c  push rax
000074267fbd8a1d  push rcx
000074267fbd8a1e  push rdx
000074267fbd8a1f  push rdi
000074267fbd8a20  push rsi
000074267fbd8a21  push r8
000074267fbd8a23  push r9
000074267fbd8a25  push r10
000074267fbd8a27  push r11
000074267fbd8a29  sub rsp, 0xF0
000074267fbd8a30  vmovaps [rsp], xmm0
000074267fbd8a35  vmovaps [rsp+0x10], xmm1
000074267fbd8a3b  vmovaps [rsp+0x20], xmm2
000074267fbd8a41  vmovaps [rsp+0x30], xmm3
000074267fbd8a47  vmovaps [rsp+0x40], xmm4
000074267fbd8a4d  vmovaps [rsp+0x50], xmm5
000074267fbd8a53  vmovaps [rsp+0x60], xmm6
000074267fbd8a59  vmovaps [rsp+0x70], xmm7
000074267fbd8a5f  vmovaps [rsp+0x80], xmm8
000074267fbd8a68  vmovaps [rsp+0x90], xmm10
000074267fbd8a71  vmovaps [rsp+0xA0], xmm11
000074267fbd8a7a  vmovaps [rsp+0xB0], xmm12
000074267fbd8a83  vmovaps [rsp+0xC0], xmm13
000074267fbd8a8c  vmovaps [rsp+0xD0], xmm14
000074267fbd8a95  vmovaps [rsp+0xE0], xmm15
000074267fbd8a9e  sub rsp, 0x40
000074267fbd8aa2  lea rdi, [rsp]
000074267fbd8aa6  lea rsi, [rsp+0x10]
000074267fbd8aab  lea rdx, [rsp+0x20]
000074267fbd8ab0  lea rcx, [rsp+0x30]
000074267fbd8ab5  mov r8d, 0x00
000074267fbd8abb  lea r9, [r15+0x3A8]
000074267fbd8ac2  movaps [rdi], xmm9
000074267fbd8ac6  movaps [rsi], xmm6
000074267fbd8ac9  movaps [rdx], xmm1
000074267fbd8acc  movaps [rcx], xmm11
000074267fbd8ad0  mov rax, 0x56D4E47AEA50
000074267fbd8ada  call rax
000074267fbd8adc  movaps xmm9, [rsp]
000074267fbd8ae1  add rsp, 0x40
000074267fbd8ae5  vmovaps xmm0, [rsp]
000074267fbd8aea  vmovaps xmm1, [rsp+0x10]
000074267fbd8af0  vmovaps xmm2, [rsp+0x20]
000074267fbd8af6  vmovaps xmm3, [rsp+0x30]
000074267fbd8afc  vmovaps xmm4, [rsp+0x40]
000074267fbd8b02  vmovaps xmm5, [rsp+0x50]
000074267fbd8b08  vmovaps xmm6, [rsp+0x60]
000074267fbd8b0e  vmovaps xmm7, [rsp+0x70]
000074267fbd8b14  vmovaps xmm8, [rsp+0x80]
000074267fbd8b1d  vmovaps xmm10, [rsp+0x90]
000074267fbd8b26  vmovaps xmm11, [rsp+0xA0]
000074267fbd8b2f  vmovaps xmm12, [rsp+0xB0]
000074267fbd8b38  vmovaps xmm13, [rsp+0xC0]
000074267fbd8b41  vmovaps xmm14, [rsp+0xD0]
000074267fbd8b4a  vmovaps xmm15, [rsp+0xE0]
000074267fbd8b53  add rsp, 0xF0
000074267fbd8b5a  pop r11
000074267fbd8b5c  pop r10
000074267fbd8b5e  pop r9
000074267fbd8b60  pop r8
000074267fbd8b62  pop rsi
000074267fbd8b63  pop rdi
000074267fbd8b64  pop rdx
000074267fbd8b65  pop rcx
000074267fbd8b66  pop rax
000074267fbd8b67  add rsp, 0x08
000074267fbd8b6b  jmp 0x000074267FBD6ABC
000074267fbd8b70  sub rsp, 0x08
000074267fbd8b74  push rax
000074267fbd8b75  push rcx
000074267fbd8b76  push rdx
000074267fbd8b77  push rdi
000074267fbd8b78  push rsi
000074267fbd8b79  push r8
000074267fbd8b7b  push r9
000074267fbd8b7d  push r10
000074267fbd8b7f  push r11
000074267fbd8b81  sub rsp, 0xF0
000074267fbd8b88  vmovaps [rsp], xmm0
000074267fbd8b8d  vmovaps [rsp+0x10], xmm1
000074267fbd8b93  vmovaps [rsp+0x20], xmm2
000074267fbd8b99  vmovaps [rsp+0x30], xmm3
000074267fbd8b9f  vmovaps [rsp+0x40], xmm4
000074267fbd8ba5  vmovaps [rsp+0x50], xmm5
000074267fbd8bab  vmovaps [rsp+0x60], xmm6
000074267fbd8bb1  vmovaps [rsp+0x70], xmm7
000074267fbd8bb7  vmovaps [rsp+0x80], xmm8
000074267fbd8bc0  vmovaps [rsp+0x90], xmm9
000074267fbd8bc9  vmovaps [rsp+0xA0], xmm10
000074267fbd8bd2  vmovaps [rsp+0xB0], xmm12
000074267fbd8bdb  vmovaps [rsp+0xC0], xmm13
000074267fbd8be4  vmovaps [rsp+0xD0], xmm14
000074267fbd8bed  vmovaps [rsp+0xE0], xmm15
000074267fbd8bf6  sub rsp, 0x40
000074267fbd8bfa  lea rdi, [rsp]
000074267fbd8bfe  lea rsi, [rsp+0x10]
000074267fbd8c03  lea rdx, [rsp+0x20]
000074267fbd8c08  lea rcx, [rsp+0x30]
000074267fbd8c0d  mov r8d, 0x00
000074267fbd8c13  lea r9, [r15+0x3A8]
000074267fbd8c1a  movaps [rdi], xmm11
000074267fbd8c1e  movaps [rsi], xmm10
000074267fbd8c22  movaps [rdx], xmm8
000074267fbd8c26  movaps [rcx], xmm1
000074267fbd8c29  mov rax, 0x56D4E47AEA50
000074267fbd8c33  call rax
000074267fbd8c35  movaps xmm11, [rsp]
000074267fbd8c3a  add rsp, 0x40
000074267fbd8c3e  vmovaps xmm0, [rsp]
000074267fbd8c43  vmovaps xmm1, [rsp+0x10]
000074267fbd8c49  vmovaps xmm2, [rsp+0x20]
000074267fbd8c4f  vmovaps xmm3, [rsp+0x30]
000074267fbd8c55  vmovaps xmm4, [rsp+0x40]
000074267fbd8c5b  vmovaps xmm5, [rsp+0x50]
000074267fbd8c61  vmovaps xmm6, [rsp+0x60]
000074267fbd8c67  vmovaps xmm7, [rsp+0x70]
000074267fbd8c6d  vmovaps xmm8, [rsp+0x80]
000074267fbd8c76  vmovaps xmm9, [rsp+0x90]
000074267fbd8c7f  vmovaps xmm10, [rsp+0xA0]
000074267fbd8c88  vmovaps xmm12, [rsp+0xB0]
000074267fbd8c91  vmovaps xmm13, [rsp+0xC0]
000074267fbd8c9a  vmovaps xmm14, [rsp+0xD0]
000074267fbd8ca3  vmovaps xmm15, [rsp+0xE0]
000074267fbd8cac  add rsp, 0xF0
000074267fbd8cb3  pop r11
000074267fbd8cb5  pop r10
000074267fbd8cb7  pop r9
000074267fbd8cb9  pop r8
000074267fbd8cbb  pop rsi
000074267fbd8cbc  pop rdi
000074267fbd8cbd  pop rdx
000074267fbd8cbe  pop rcx
000074267fbd8cbf  pop rax
000074267fbd8cc0  add rsp, 0x08
000074267fbd8cc4  jmp 0x000074267FBD6AE2
000074267fbd8cc9  sub rsp, 0x08
000074267fbd8ccd  push rax
000074267fbd8cce  push rcx
000074267fbd8ccf  push rdx
000074267fbd8cd0  push rdi
000074267fbd8cd1  push rsi
000074267fbd8cd2  push r8
000074267fbd8cd4  push r9
000074267fbd8cd6  push r10
000074267fbd8cd8  push r11
000074267fbd8cda  sub rsp, 0xF0
000074267fbd8ce1  vmovaps [rsp], xmm0
000074267fbd8ce6  vmovaps [rsp+0x10], xmm1
000074267fbd8cec  vmovaps [rsp+0x20], xmm2
000074267fbd8cf2  vmovaps [rsp+0x30], xmm3
000074267fbd8cf8  vmovaps [rsp+0x40], xmm4
000074267fbd8cfe  vmovaps [rsp+0x50], xmm5
000074267fbd8d04  vmovaps [rsp+0x60], xmm6
000074267fbd8d0a  vmovaps [rsp+0x70], xmm7
000074267fbd8d10  vmovaps [rsp+0x80], xmm8
000074267fbd8d19  vmovaps [rsp+0x90], xmm9
000074267fbd8d22  vmovaps [rsp+0xA0], xmm11
000074267fbd8d2b  vmovaps [rsp+0xB0], xmm12
000074267fbd8d34  vmovaps [rsp+0xC0], xmm13
000074267fbd8d3d  vmovaps [rsp+0xD0], xmm14
000074267fbd8d46  vmovaps [rsp+0xE0], xmm15
000074267fbd8d4f  sub rsp, 0x40
000074267fbd8d53  lea rdi, [rsp]
000074267fbd8d57  lea rsi, [rsp+0x10]
000074267fbd8d5c  lea rdx, [rsp+0x20]
000074267fbd8d61  lea rcx, [rsp+0x30]
000074267fbd8d66  mov r8d, 0x00
000074267fbd8d6c  lea r9, [r15+0x3A8]
000074267fbd8d73  movaps [rdi], xmm10
000074267fbd8d77  movaps [rsi], xmm12
000074267fbd8d7b  movaps [rdx], xmm13
000074267fbd8d7f  movaps [rcx], xmm1
000074267fbd8d82  mov rax, 0x56D4E47AEA50
000074267fbd8d8c  call rax
000074267fbd8d8e  movaps xmm10, [rsp]
000074267fbd8d93  add rsp, 0x40
000074267fbd8d97  vmovaps xmm0, [rsp]
000074267fbd8d9c  vmovaps xmm1, [rsp+0x10]
000074267fbd8da2  vmovaps xmm2, [rsp+0x20]
000074267fbd8da8  vmovaps xmm3, [rsp+0x30]
000074267fbd8dae  vmovaps xmm4, [rsp+0x40]
000074267fbd8db4  vmovaps xmm5, [rsp+0x50]
000074267fbd8dba  vmovaps xmm6, [rsp+0x60]
000074267fbd8dc0  vmovaps xmm7, [rsp+0x70]
000074267fbd8dc6  vmovaps xmm8, [rsp+0x80]
000074267fbd8dcf  vmovaps xmm9, [rsp+0x90]
000074267fbd8dd8  vmovaps xmm11, [rsp+0xA0]
000074267fbd8de1  vmovaps xmm12, [rsp+0xB0]
000074267fbd8dea  vmovaps xmm13, [rsp+0xC0]
000074267fbd8df3  vmovaps xmm14, [rsp+0xD0]
000074267fbd8dfc  vmovaps xmm15, [rsp+0xE0]
000074267fbd8e05  add rsp, 0xF0
000074267fbd8e0c  pop r11
000074267fbd8e0e  pop r10
000074267fbd8e10  pop r9
000074267fbd8e12  pop r8
000074267fbd8e14  pop rsi
000074267fbd8e15  pop rdi
000074267fbd8e16  pop rdx
000074267fbd8e17  pop rcx
000074267fbd8e18  pop rax
000074267fbd8e19  add rsp, 0x08
000074267fbd8e1d  jmp 0x000074267FBD6B08
000074267fbd8e22  call 0x000074267FAD64F0
000074267fbd8e27  jmp 0x000074267FBD6B12
000074267fbd8e2c  call 0x000074267FAE3320
000074267fbd8e31  jmp 0x000074267FBD6B1C
000074267fbd8e36  sub rsp, 0x08
000074267fbd8e3a  push rax
000074267fbd8e3b  push rcx
000074267fbd8e3c  push rdx
000074267fbd8e3d  push rdi
000074267fbd8e3e  push rsi
000074267fbd8e3f  push r8
000074267fbd8e41  push r9
000074267fbd8e43  push r10
000074267fbd8e45  push r11
000074267fbd8e47  sub rsp, 0xF0
000074267fbd8e4e  vmovaps [rsp], xmm0
000074267fbd8e53  vmovaps [rsp+0x10], xmm1
000074267fbd8e59  vmovaps [rsp+0x20], xmm2
000074267fbd8e5f  vmovaps [rsp+0x30], xmm3
000074267fbd8e65  vmovaps [rsp+0x40], xmm4
000074267fbd8e6b  vmovaps [rsp+0x50], xmm5
000074267fbd8e71  vmovaps [rsp+0x60], xmm6
000074267fbd8e77  vmovaps [rsp+0x70], xmm7
000074267fbd8e7d  vmovaps [rsp+0x80], xmm9
000074267fbd8e86  vmovaps [rsp+0x90], xmm10
000074267fbd8e8f  vmovaps [rsp+0xA0], xmm11
000074267fbd8e98  vmovaps [rsp+0xB0], xmm12
000074267fbd8ea1  vmovaps [rsp+0xC0], xmm13
000074267fbd8eaa  vmovaps [rsp+0xD0], xmm14
000074267fbd8eb3  vmovaps [rsp+0xE0], xmm15
000074267fbd8ebc  sub rsp, 0x40
000074267fbd8ec0  lea rdi, [rsp]
000074267fbd8ec4  lea rsi, [rsp+0x10]
000074267fbd8ec9  lea rdx, [rsp+0x20]
000074267fbd8ece  lea rcx, [rsp+0x30]
000074267fbd8ed3  mov r8d, 0x00
000074267fbd8ed9  lea r9, [r15+0x3A8]
000074267fbd8ee0  movaps [rdi], xmm8
000074267fbd8ee4  movaps [rsi], xmm7
000074267fbd8ee7  movaps [rdx], xmm4
000074267fbd8eea  movaps [rcx], xmm12
000074267fbd8eee  mov rax, 0x56D4E47AEA50
000074267fbd8ef8  call rax
000074267fbd8efa  movaps xmm8, [rsp]
000074267fbd8eff  add rsp, 0x40
000074267fbd8f03  vmovaps xmm0, [rsp]
000074267fbd8f08  vmovaps xmm1, [rsp+0x10]
000074267fbd8f0e  vmovaps xmm2, [rsp+0x20]
000074267fbd8f14  vmovaps xmm3, [rsp+0x30]
000074267fbd8f1a  vmovaps xmm4, [rsp+0x40]
000074267fbd8f20  vmovaps xmm5, [rsp+0x50]
000074267fbd8f26  vmovaps xmm6, [rsp+0x60]
000074267fbd8f2c  vmovaps xmm7, [rsp+0x70]
000074267fbd8f32  vmovaps xmm9, [rsp+0x80]
000074267fbd8f3b  vmovaps xmm10, [rsp+0x90]
000074267fbd8f44  vmovaps xmm11, [rsp+0xA0]
000074267fbd8f4d  vmovaps xmm12, [rsp+0xB0]
000074267fbd8f56  vmovaps xmm13, [rsp+0xC0]
000074267fbd8f5f  vmovaps xmm14, [rsp+0xD0]
000074267fbd8f68  vmovaps xmm15, [rsp+0xE0]
000074267fbd8f71  add rsp, 0xF0
000074267fbd8f78  pop r11
000074267fbd8f7a  pop r10
000074267fbd8f7c  pop r9
000074267fbd8f7e  pop r8
000074267fbd8f80  pop rsi
000074267fbd8f81  pop rdi
000074267fbd8f82  pop rdx
000074267fbd8f83  pop rcx
000074267fbd8f84  pop rax
000074267fbd8f85  add rsp, 0x08
000074267fbd8f89  jmp 0x000074267FBD6B45
000074267fbd8f8e  sub rsp, 0x08
000074267fbd8f92  push rax
000074267fbd8f93  push rcx
000074267fbd8f94  push rdx
000074267fbd8f95  push rdi
000074267fbd8f96  push rsi
000074267fbd8f97  push r8
000074267fbd8f99  push r9
000074267fbd8f9b  push r10
000074267fbd8f9d  push r11
000074267fbd8f9f  sub rsp, 0xF0
000074267fbd8fa6  vmovaps [rsp], xmm0
000074267fbd8fab  vmovaps [rsp+0x10], xmm1
000074267fbd8fb1  vmovaps [rsp+0x20], xmm2
000074267fbd8fb7  vmovaps [rsp+0x30], xmm3
000074267fbd8fbd  vmovaps [rsp+0x40], xmm4
000074267fbd8fc3  vmovaps [rsp+0x50], xmm5
000074267fbd8fc9  vmovaps [rsp+0x60], xmm6
000074267fbd8fcf  vmovaps [rsp+0x70], xmm8
000074267fbd8fd5  vmovaps [rsp+0x80], xmm9
000074267fbd8fde  vmovaps [rsp+0x90], xmm10
000074267fbd8fe7  vmovaps [rsp+0xA0], xmm11
000074267fbd8ff0  vmovaps [rsp+0xB0], xmm12
000074267fbd8ff9  vmovaps [rsp+0xC0], xmm13
000074267fbd9002  vmovaps [rsp+0xD0], xmm14
000074267fbd900b  vmovaps [rsp+0xE0], xmm15
000074267fbd9014  sub rsp, 0x40
000074267fbd9018  lea rdi, [rsp]
000074267fbd901c  lea rsi, [rsp+0x10]
000074267fbd9021  lea rdx, [rsp+0x20]
000074267fbd9026  lea rcx, [rsp+0x30]
000074267fbd902b  mov r8d, 0x00
000074267fbd9031  lea r9, [r15+0x3A8]
000074267fbd9038  movaps [rdi], xmm7
000074267fbd903b  movaps [rsi], xmm9
000074267fbd903f  movaps [rdx], xmm14
000074267fbd9043  movaps [rcx], xmm12
000074267fbd9047  mov rax, 0x56D4E47AEA50
000074267fbd9051  call rax
000074267fbd9053  movaps xmm7, [rsp]
000074267fbd9057  add rsp, 0x40
000074267fbd905b  vmovaps xmm0, [rsp]
000074267fbd9060  vmovaps xmm1, [rsp+0x10]
000074267fbd9066  vmovaps xmm2, [rsp+0x20]
000074267fbd906c  vmovaps xmm3, [rsp+0x30]
000074267fbd9072  vmovaps xmm4, [rsp+0x40]
000074267fbd9078  vmovaps xmm5, [rsp+0x50]
000074267fbd907e  vmovaps xmm6, [rsp+0x60]
000074267fbd9084  vmovaps xmm8, [rsp+0x70]
000074267fbd908a  vmovaps xmm9, [rsp+0x80]
000074267fbd9093  vmovaps xmm10, [rsp+0x90]
000074267fbd909c  vmovaps xmm11, [rsp+0xA0]
000074267fbd90a5  vmovaps xmm12, [rsp+0xB0]
000074267fbd90ae  vmovaps xmm13, [rsp+0xC0]
000074267fbd90b7  vmovaps xmm14, [rsp+0xD0]
000074267fbd90c0  vmovaps xmm15, [rsp+0xE0]
000074267fbd90c9  add rsp, 0xF0
000074267fbd90d0  pop r11
000074267fbd90d2  pop r10
000074267fbd90d4  pop r9
000074267fbd90d6  pop r8
000074267fbd90d8  pop rsi
000074267fbd90d9  pop rdi
000074267fbd90da  pop rdx
000074267fbd90db  pop rcx
000074267fbd90dc  pop rax
000074267fbd90dd  add rsp, 0x08
000074267fbd90e1  jmp 0x000074267FBD6B6D
000074267fbd90e6  sub rsp, 0x08
000074267fbd90ea  push rax
000074267fbd90eb  push rcx
000074267fbd90ec  push rdx
000074267fbd90ed  push rdi
000074267fbd90ee  push rsi
000074267fbd90ef  push r8
000074267fbd90f1  push r9
000074267fbd90f3  push r10
000074267fbd90f5  push r11
000074267fbd90f7  sub rsp, 0xF0
000074267fbd90fe  vmovaps [rsp], xmm0
000074267fbd9103  vmovaps [rsp+0x10], xmm1
000074267fbd9109  vmovaps [rsp+0x20], xmm2
000074267fbd910f  vmovaps [rsp+0x30], xmm3
000074267fbd9115  vmovaps [rsp+0x40], xmm4
000074267fbd911b  vmovaps [rsp+0x50], xmm5
000074267fbd9121  vmovaps [rsp+0x60], xmm6
000074267fbd9127  vmovaps [rsp+0x70], xmm7
000074267fbd912d  vmovaps [rsp+0x80], xmm8
000074267fbd9136  vmovaps [rsp+0x90], xmm9
000074267fbd913f  vmovaps [rsp+0xA0], xmm10
000074267fbd9148  vmovaps [rsp+0xB0], xmm11
000074267fbd9151  vmovaps [rsp+0xC0], xmm13
000074267fbd915a  vmovaps [rsp+0xD0], xmm14
000074267fbd9163  vmovaps [rsp+0xE0], xmm15
000074267fbd916c  sub rsp, 0x40
000074267fbd9170  lea rdi, [rsp]
000074267fbd9174  lea rsi, [rsp+0x10]
000074267fbd9179  lea rdx, [rsp+0x20]
000074267fbd917e  lea rcx, [rsp+0x30]
000074267fbd9183  mov r8d, 0x00
000074267fbd9189  lea r9, [r15+0x3A8]
000074267fbd9190  movaps [rdi], xmm12
000074267fbd9194  movaps [rsi], xmm11
000074267fbd9198  movaps [rdx], xmm15
000074267fbd919c  movaps [rcx], xmm14
000074267fbd91a0  mov rax, 0x56D4E47AEA50
000074267fbd91aa  call rax
000074267fbd91ac  movaps xmm12, [rsp]
000074267fbd91b1  add rsp, 0x40
000074267fbd91b5  vmovaps xmm0, [rsp]
000074267fbd91ba  vmovaps xmm1, [rsp+0x10]
000074267fbd91c0  vmovaps xmm2, [rsp+0x20]
000074267fbd91c6  vmovaps xmm3, [rsp+0x30]
000074267fbd91cc  vmovaps xmm4, [rsp+0x40]
000074267fbd91d2  vmovaps xmm5, [rsp+0x50]
000074267fbd91d8  vmovaps xmm6, [rsp+0x60]
000074267fbd91de  vmovaps xmm7, [rsp+0x70]
000074267fbd91e4  vmovaps xmm8, [rsp+0x80]
000074267fbd91ed  vmovaps xmm9, [rsp+0x90]
000074267fbd91f6  vmovaps xmm10, [rsp+0xA0]
000074267fbd91ff  vmovaps xmm11, [rsp+0xB0]
000074267fbd9208  vmovaps xmm13, [rsp+0xC0]
000074267fbd9211  vmovaps xmm14, [rsp+0xD0]
000074267fbd921a  vmovaps xmm15, [rsp+0xE0]
000074267fbd9223  add rsp, 0xF0
000074267fbd922a  pop r11
000074267fbd922c  pop r10
000074267fbd922e  pop r9
000074267fbd9230  pop r8
000074267fbd9232  pop rsi
000074267fbd9233  pop rdi
000074267fbd9234  pop rdx
000074267fbd9235  pop rcx
000074267fbd9236  pop rax
000074267fbd9237  add rsp, 0x08
000074267fbd923b  jmp 0x000074267FBD6B96
000074267fbd9240  sub rsp, 0x08
000074267fbd9244  push rax
000074267fbd9245  push rcx
000074267fbd9246  push rdx
000074267fbd9247  push rdi
000074267fbd9248  push rsi
000074267fbd9249  push r8
000074267fbd924b  push r9
000074267fbd924d  push r10
000074267fbd924f  push r11
000074267fbd9251  sub rsp, 0xF0
000074267fbd9258  vmovaps [rsp], xmm0
000074267fbd925d  vmovaps [rsp+0x10], xmm1
000074267fbd9263  vmovaps [rsp+0x20], xmm2
000074267fbd9269  vmovaps [rsp+0x30], xmm3
000074267fbd926f  vmovaps [rsp+0x40], xmm4
000074267fbd9275  vmovaps [rsp+0x50], xmm5
000074267fbd927b  vmovaps [rsp+0x60], xmm6
000074267fbd9281  vmovaps [rsp+0x70], xmm7
000074267fbd9287  vmovaps [rsp+0x80], xmm8
000074267fbd9290  vmovaps [rsp+0x90], xmm9
000074267fbd9299  vmovaps [rsp+0xA0], xmm10
000074267fbd92a2  vmovaps [rsp+0xB0], xmm12
000074267fbd92ab  vmovaps [rsp+0xC0], xmm13
000074267fbd92b4  vmovaps [rsp+0xD0], xmm14
000074267fbd92bd  vmovaps [rsp+0xE0], xmm15
000074267fbd92c6  sub rsp, 0x40
000074267fbd92ca  lea rdi, [rsp]
000074267fbd92ce  lea rsi, [rsp+0x10]
000074267fbd92d3  lea rdx, [rsp+0x20]
000074267fbd92d8  lea rcx, [rsp+0x30]
000074267fbd92dd  mov r8d, 0x00
000074267fbd92e3  lea r9, [r15+0x3A8]
000074267fbd92ea  movaps [rdi], xmm11
000074267fbd92ee  movaps [rsi], xmm10
000074267fbd92f2  movaps [rdx], xmm13
000074267fbd92f6  movaps [rcx], xmm15
000074267fbd92fa  mov rax, 0x56D4E47AEA50
000074267fbd9304  call rax
000074267fbd9306  movaps xmm11, [rsp]
000074267fbd930b  add rsp, 0x40
000074267fbd930f  vmovaps xmm0, [rsp]
000074267fbd9314  vmovaps xmm1, [rsp+0x10]
000074267fbd931a  vmovaps xmm2, [rsp+0x20]
000074267fbd9320  vmovaps xmm3, [rsp+0x30]
000074267fbd9326  vmovaps xmm4, [rsp+0x40]
000074267fbd932c  vmovaps xmm5, [rsp+0x50]
000074267fbd9332  vmovaps xmm6, [rsp+0x60]
000074267fbd9338  vmovaps xmm7, [rsp+0x70]
000074267fbd933e  vmovaps xmm8, [rsp+0x80]
000074267fbd9347  vmovaps xmm9, [rsp+0x90]
000074267fbd9350  vmovaps xmm10, [rsp+0xA0]
000074267fbd9359  vmovaps xmm12, [rsp+0xB0]
000074267fbd9362  vmovaps xmm13, [rsp+0xC0]
000074267fbd936b  vmovaps xmm14, [rsp+0xD0]
000074267fbd9374  vmovaps xmm15, [rsp+0xE0]
000074267fbd937d  add rsp, 0xF0
000074267fbd9384  pop r11
000074267fbd9386  pop r10
000074267fbd9388  pop r9
000074267fbd938a  pop r8
000074267fbd938c  pop rsi
000074267fbd938d  pop rdi
000074267fbd938e  pop rdx
000074267fbd938f  pop rcx
000074267fbd9390  pop rax
000074267fbd9391  add rsp, 0x08
000074267fbd9395  jmp 0x000074267FBD6BBF
000074267fbd939a  call 0x000074267FAE5820
000074267fbd939f  jmp 0x000074267FBD6BCC
000074267fbd93a4  call 0x000074267FAE45A0
000074267fbd93a9  jmp 0x000074267FBD6BD9
000074267fbd93ae  sub rsp, 0x08
000074267fbd93b2  push rax
000074267fbd93b3  push rcx
000074267fbd93b4  push rdx
000074267fbd93b5  push rdi
000074267fbd93b6  push rsi
000074267fbd93b7  push r8
000074267fbd93b9  push r9
000074267fbd93bb  push r10
000074267fbd93bd  push r11
000074267fbd93bf  sub rsp, 0xF0
000074267fbd93c6  vmovaps [rsp], xmm0
000074267fbd93cb  vmovaps [rsp+0x10], xmm1
000074267fbd93d1  vmovaps [rsp+0x20], xmm2
000074267fbd93d7  vmovaps [rsp+0x30], xmm3
000074267fbd93dd  vmovaps [rsp+0x40], xmm4
000074267fbd93e3  vmovaps [rsp+0x50], xmm5
000074267fbd93e9  vmovaps [rsp+0x60], xmm6
000074267fbd93ef  vmovaps [rsp+0x70], xmm7
000074267fbd93f5  vmovaps [rsp+0x80], xmm8
000074267fbd93fe  vmovaps [rsp+0x90], xmm9
000074267fbd9407  vmovaps [rsp+0xA0], xmm11
000074267fbd9410  vmovaps [rsp+0xB0], xmm12
000074267fbd9419  vmovaps [rsp+0xC0], xmm13
000074267fbd9422  vmovaps [rsp+0xD0], xmm14
000074267fbd942b  vmovaps [rsp+0xE0], xmm15
000074267fbd9434  sub rsp, 0x40
000074267fbd9438  lea rdi, [rsp]
000074267fbd943c  lea rsi, [rsp+0x10]
000074267fbd9441  lea rdx, [rsp+0x20]
000074267fbd9446  lea rcx, [rsp+0x30]
000074267fbd944b  mov r8d, 0x00
000074267fbd9451  lea r9, [r15+0x3A8]
000074267fbd9458  movaps [rdi], xmm10
000074267fbd945c  movaps [rsi], xmm8
000074267fbd9460  movaps [rdx], xmm1
000074267fbd9463  movaps [rcx], xmm13
000074267fbd9467  mov rax, 0x56D4E47AEA50
000074267fbd9471  call rax
000074267fbd9473  movaps xmm10, [rsp]
000074267fbd9478  add rsp, 0x40
000074267fbd947c  vmovaps xmm0, [rsp]
000074267fbd9481  vmovaps xmm1, [rsp+0x10]
000074267fbd9487  vmovaps xmm2, [rsp+0x20]
000074267fbd948d  vmovaps xmm3, [rsp+0x30]
000074267fbd9493  vmovaps xmm4, [rsp+0x40]
000074267fbd9499  vmovaps xmm5, [rsp+0x50]
000074267fbd949f  vmovaps xmm6, [rsp+0x60]
000074267fbd94a5  vmovaps xmm7, [rsp+0x70]
000074267fbd94ab  vmovaps xmm8, [rsp+0x80]
000074267fbd94b4  vmovaps xmm9, [rsp+0x90]
000074267fbd94bd  vmovaps xmm11, [rsp+0xA0]
000074267fbd94c6  vmovaps xmm12, [rsp+0xB0]
000074267fbd94cf  vmovaps xmm13, [rsp+0xC0]
000074267fbd94d8  vmovaps xmm14, [rsp+0xD0]
000074267fbd94e1  vmovaps xmm15, [rsp+0xE0]
000074267fbd94ea  add rsp, 0xF0
000074267fbd94f1  pop r11
000074267fbd94f3  pop r10
000074267fbd94f5  pop r9
000074267fbd94f7  pop r8
000074267fbd94f9  pop rsi
000074267fbd94fa  pop rdi
000074267fbd94fb  pop rdx
000074267fbd94fc  pop rcx
000074267fbd94fd  pop rax
000074267fbd94fe  add rsp, 0x08
000074267fbd9502  jmp 0x000074267FBD6C0F
000074267fbd9507  call 0x000074267FAD64F0
000074267fbd950c  jmp 0x000074267FBD6C21
000074267fbd9511  sub rsp, 0x08
000074267fbd9515  push rax
000074267fbd9516  push rcx
000074267fbd9517  push rdx
000074267fbd9518  push rdi
000074267fbd9519  push rsi
000074267fbd951a  push r8
000074267fbd951c  push r9
000074267fbd951e  push r10
000074267fbd9520  push r11
000074267fbd9522  sub rsp, 0xF0
000074267fbd9529  vmovaps [rsp], xmm0
000074267fbd952e  vmovaps [rsp+0x10], xmm1
000074267fbd9534  vmovaps [rsp+0x20], xmm2
000074267fbd953a  vmovaps [rsp+0x30], xmm3
000074267fbd9540  vmovaps [rsp+0x40], xmm4
000074267fbd9546  vmovaps [rsp+0x50], xmm5
000074267fbd954c  vmovaps [rsp+0x60], xmm6
000074267fbd9552  vmovaps [rsp+0x70], xmm7
000074267fbd9558  vmovaps [rsp+0x80], xmm8
000074267fbd9561  vmovaps [rsp+0x90], xmm10
000074267fbd956a  vmovaps [rsp+0xA0], xmm11
000074267fbd9573  vmovaps [rsp+0xB0], xmm12
000074267fbd957c  vmovaps [rsp+0xC0], xmm13
000074267fbd9585  vmovaps [rsp+0xD0], xmm14
000074267fbd958e  vmovaps [rsp+0xE0], xmm15
000074267fbd9597  sub rsp, 0x40
000074267fbd959b  lea rdi, [rsp]
000074267fbd959f  lea rsi, [rsp+0x10]
000074267fbd95a4  lea rdx, [rsp+0x20]
000074267fbd95a9  lea rcx, [rsp+0x30]
000074267fbd95ae  mov r8d, 0x00
000074267fbd95b4  lea r9, [r15+0x3A8]
000074267fbd95bb  movaps [rdi], xmm9
000074267fbd95bf  movaps [rsi], xmm7
000074267fbd95c2  movaps [rdx], xmm14
000074267fbd95c6  movaps [rcx], xmm13
000074267fbd95ca  mov rax, 0x56D4E47AEA50
000074267fbd95d4  call rax
000074267fbd95d6  movaps xmm9, [rsp]
000074267fbd95db  add rsp, 0x40
000074267fbd95df  vmovaps xmm0, [rsp]
000074267fbd95e4  vmovaps xmm1, [rsp+0x10]
000074267fbd95ea  vmovaps xmm2, [rsp+0x20]
000074267fbd95f0  vmovaps xmm3, [rsp+0x30]
000074267fbd95f6  vmovaps xmm4, [rsp+0x40]
000074267fbd95fc  vmovaps xmm5, [rsp+0x50]
000074267fbd9602  vmovaps xmm6, [rsp+0x60]
000074267fbd9608  vmovaps xmm7, [rsp+0x70]
000074267fbd960e  vmovaps xmm8, [rsp+0x80]
000074267fbd9617  vmovaps xmm10, [rsp+0x90]
000074267fbd9620  vmovaps xmm11, [rsp+0xA0]
000074267fbd9629  vmovaps xmm12, [rsp+0xB0]
000074267fbd9632  vmovaps xmm13, [rsp+0xC0]
000074267fbd963b  vmovaps xmm14, [rsp+0xD0]
000074267fbd9644  vmovaps xmm15, [rsp+0xE0]
000074267fbd964d  add rsp, 0xF0
000074267fbd9654  pop r11
000074267fbd9656  pop r10
000074267fbd9658  pop r9
000074267fbd965a  pop r8
000074267fbd965c  pop rsi
000074267fbd965d  pop rdi
000074267fbd965e  pop rdx
000074267fbd965f  pop rcx
000074267fbd9660  pop rax
000074267fbd9661  add rsp, 0x08
000074267fbd9665  jmp 0x000074267FBD6C4F
000074267fbd966a  sub rsp, 0x08
000074267fbd966e  push rax
000074267fbd966f  push rcx
000074267fbd9670  push rdx
000074267fbd9671  push rdi
000074267fbd9672  push rsi
000074267fbd9673  push r8
000074267fbd9675  push r9
000074267fbd9677  push r10
000074267fbd9679  push r11
000074267fbd967b  sub rsp, 0xF0
000074267fbd9682  vmovaps [rsp], xmm0
000074267fbd9687  vmovaps [rsp+0x10], xmm1
000074267fbd968d  vmovaps [rsp+0x20], xmm2
000074267fbd9693  vmovaps [rsp+0x30], xmm3
000074267fbd9699  vmovaps [rsp+0x40], xmm4
000074267fbd969f  vmovaps [rsp+0x50], xmm5
000074267fbd96a5  vmovaps [rsp+0x60], xmm6
000074267fbd96ab  vmovaps [rsp+0x70], xmm7
000074267fbd96b1  vmovaps [rsp+0x80], xmm8
000074267fbd96ba  vmovaps [rsp+0x90], xmm9
000074267fbd96c3  vmovaps [rsp+0xA0], xmm10
000074267fbd96cc  vmovaps [rsp+0xB0], xmm11
000074267fbd96d5  vmovaps [rsp+0xC0], xmm12
000074267fbd96de  vmovaps [rsp+0xD0], xmm14
000074267fbd96e7  vmovaps [rsp+0xE0], xmm15
000074267fbd96f0  sub rsp, 0x40
000074267fbd96f4  lea rdi, [rsp]
000074267fbd96f8  lea rsi, [rsp+0x10]
000074267fbd96fd  lea rdx, [rsp+0x20]
000074267fbd9702  lea rcx, [rsp+0x30]
000074267fbd9707  mov r8d, 0x00
000074267fbd970d  lea r9, [r15+0x3A8]
000074267fbd9714  movaps [rdi], xmm13
000074267fbd9718  movaps [rsi], xmm12
000074267fbd971c  movaps [rdx], xmm15
000074267fbd9720  movaps [rcx], xmm14
000074267fbd9724  mov rax, 0x56D4E47AEA50
000074267fbd972e  call rax
000074267fbd9730  movaps xmm13, [rsp]
000074267fbd9735  add rsp, 0x40
000074267fbd9739  vmovaps xmm0, [rsp]
000074267fbd973e  vmovaps xmm1, [rsp+0x10]
000074267fbd9744  vmovaps xmm2, [rsp+0x20]
000074267fbd974a  vmovaps xmm3, [rsp+0x30]
000074267fbd9750  vmovaps xmm4, [rsp+0x40]
000074267fbd9756  vmovaps xmm5, [rsp+0x50]
000074267fbd975c  vmovaps xmm6, [rsp+0x60]
000074267fbd9762  vmovaps xmm7, [rsp+0x70]
000074267fbd9768  vmovaps xmm8, [rsp+0x80]
000074267fbd9771  vmovaps xmm9, [rsp+0x90]
000074267fbd977a  vmovaps xmm10, [rsp+0xA0]
000074267fbd9783  vmovaps xmm11, [rsp+0xB0]
000074267fbd978c  vmovaps xmm12, [rsp+0xC0]
000074267fbd9795  vmovaps xmm14, [rsp+0xD0]
000074267fbd979e  vmovaps xmm15, [rsp+0xE0]
000074267fbd97a7  add rsp, 0xF0
000074267fbd97ae  pop r11
000074267fbd97b0  pop r10
000074267fbd97b2  pop r9
000074267fbd97b4  pop r8
000074267fbd97b6  pop rsi
000074267fbd97b7  pop rdi
000074267fbd97b8  pop rdx
000074267fbd97b9  pop rcx
000074267fbd97ba  pop rax
000074267fbd97bb  add rsp, 0x08
000074267fbd97bf  jmp 0x000074267FBD6C7D
000074267fbd97c4  sub rsp, 0x08
000074267fbd97c8  push rax
000074267fbd97c9  push rcx
000074267fbd97ca  push rdx
000074267fbd97cb  push rdi
000074267fbd97cc  push rsi
000074267fbd97cd  push r8
000074267fbd97cf  push r9
000074267fbd97d1  push r10
000074267fbd97d3  push r11
000074267fbd97d5  sub rsp, 0xF0
000074267fbd97dc  vmovaps [rsp], xmm0
000074267fbd97e1  vmovaps [rsp+0x10], xmm1
000074267fbd97e7  vmovaps [rsp+0x20], xmm2
000074267fbd97ed  vmovaps [rsp+0x30], xmm3
000074267fbd97f3  vmovaps [rsp+0x40], xmm4
000074267fbd97f9  vmovaps [rsp+0x50], xmm5
000074267fbd97ff  vmovaps [rsp+0x60], xmm6
000074267fbd9805  vmovaps [rsp+0x70], xmm7
000074267fbd980b  vmovaps [rsp+0x80], xmm8
000074267fbd9814  vmovaps [rsp+0x90], xmm9
000074267fbd981d  vmovaps [rsp+0xA0], xmm10
000074267fbd9826  vmovaps [rsp+0xB0], xmm11
000074267fbd982f  vmovaps [rsp+0xC0], xmm12
000074267fbd9838  vmovaps [rsp+0xD0], xmm13
000074267fbd9841  vmovaps [rsp+0xE0], xmm15
000074267fbd984a  sub rsp, 0x40
000074267fbd984e  lea rdi, [rsp]
000074267fbd9852  lea rsi, [rsp+0x10]
000074267fbd9857  lea rdx, [rsp+0x20]
000074267fbd985c  lea rcx, [rsp+0x30]
000074267fbd9861  mov r8d, 0x00
000074267fbd9867  lea r9, [r15+0x3A8]
000074267fbd986e  movaps [rdi], xmm14
000074267fbd9872  movaps [rsi], xmm11
000074267fbd9876  movaps [rdx], xmm1
000074267fbd9879  movaps [rcx], xmm15
000074267fbd987d  mov rax, 0x56D4E47AEA50
000074267fbd9887  call rax
000074267fbd9889  movaps xmm14, [rsp]
000074267fbd988e  add rsp, 0x40
000074267fbd9892  vmovaps xmm0, [rsp]
000074267fbd9897  vmovaps xmm1, [rsp+0x10]
000074267fbd989d  vmovaps xmm2, [rsp+0x20]
000074267fbd98a3  vmovaps xmm3, [rsp+0x30]
000074267fbd98a9  vmovaps xmm4, [rsp+0x40]
000074267fbd98af  vmovaps xmm5, [rsp+0x50]
000074267fbd98b5  vmovaps xmm6, [rsp+0x60]
000074267fbd98bb  vmovaps xmm7, [rsp+0x70]
000074267fbd98c1  vmovaps xmm8, [rsp+0x80]
000074267fbd98ca  vmovaps xmm9, [rsp+0x90]
000074267fbd98d3  vmovaps xmm10, [rsp+0xA0]
000074267fbd98dc  vmovaps xmm11, [rsp+0xB0]
000074267fbd98e5  vmovaps xmm12, [rsp+0xC0]
000074267fbd98ee  vmovaps xmm13, [rsp+0xD0]
000074267fbd98f7  vmovaps xmm15, [rsp+0xE0]
000074267fbd9900  add rsp, 0xF0
000074267fbd9907  pop r11
000074267fbd9909  pop r10
000074267fbd990b  pop r9
000074267fbd990d  pop r8
000074267fbd990f  pop rsi
000074267fbd9910  pop rdi
000074267fbd9911  pop rdx
000074267fbd9912  pop rcx
000074267fbd9913  pop rax
000074267fbd9914  add rsp, 0x08
000074267fbd9918  jmp 0x000074267FBD6CAB
000074267fbd991d  call 0x000074267FAACF70
000074267fbd9922  jmp 0x000074267FBD6CB9
000074267fbd9927  call 0x000074267FA0C380
000074267fbd992c  jmp 0x000074267FBD6CC3
000074267fbd9931  call 0x000074267FA08C20
000074267fbd9936  jmp 0x000074267FBD6CCD
000074267fbd993b  call 0x000074267FA0D600
000074267fbd9940  jmp 0x000074267FBD6CD7
000074267fbd9945  int3
000074267fbd9946  nop [rax+rax*1], ax
000074267fbd994f  nop
000074267fbd9950  mov eax, [r15+0x48]
000074267fbd9954  lea r14d, [eax+0x01]
000074267fbd9959  mov [rsp+0x10], r14d
000074267fbd995e  mov r14d, r14d
000074267fbd9961  mov [r15+0x48], r14
000074267fbd9965  xor eax, eax
000074267fbd9967  mov r14d, [rsp+0x10]
000074267fbd996c  cmp r14d, 0x1F4
000074267fbd9973  cmc
000074267fbd9974  lahf
000074267fbd9975  seto al
000074267fbd9978  mov [r15+0x108], eax
000074267fbd997f  mov eax, [r15+0x108]
000074267fbd9986  sahf
000074267fbd9987  jnz 0x000074267FBD99B9
000074267fbd9989  cmp dword ptr [r15+0x318], 0x00
000074267fbd9991  jz 0x000074267FBDD2E0
000074267fbd9997  nop [rax+rax*1], ax
000074267fbd99a0  nop [rax+rax*1], eax
000074267fbd99a8  mov eax, 0x410670
000074267fbd99ad  mov [r15+0x100], rax
000074267fbd99b4  jmp 0x000074267F9FE110
000074267fbd99b9  cmp dword ptr [r15+0x318], 0x00
000074267fbd99c1  jz 0x000074267FBD99F0
000074267fbd99c7  nop [rax+rax*1], ax
000074267fbd99d0  nop [rax+rax*1], eax
000074267fbd99d8  mov eax, 0x4104EC
000074267fbd99dd  mov [r15+0x100], rax
000074267fbd99e4  jmp 0x000074267F9FE110
000074267fbd99e9  int3
000074267fbd99ea  int3
000074267fbd99eb  nop [rax+rax*1], eax
000074267fbd99f0  mov rax, [r15+0x40]
000074267fbd99f4  vxorps xmm1, xmm1, xmm1
000074267fbd99f8  vpbroadcastq xmm1, xmm1
000074267fbd99fd  vxorps xmm15, xmm15, xmm15
000074267fbd9a02  vpbroadcastq xmm15, xmm15
000074267fbd9a07  lea r14, [rax+0x30]
000074267fbd9a0b  mov r12, [r13+r14*1]
000074267fbd9a10  lea r14, [rax+0x38]
000074267fbd9a14  mov r11, [r13+r14*1]
000074267fbd9a19  movq xmm14, r12
000074267fbd9a1e  movq xmm13, r11
000074267fbd9a23  movq xmm14, xmm14
000074267fbd9a28  movq xmm13, xmm13
000074267fbd9a2d  vmovaps [rsp+0x10], xmm13
000074267fbd9a33  movq xmm13, xmm13
000074267fbd9a38  movaps [r15+0x270], xmm13
000074267fbd9a40  movaps xmm13, [r15+0x160]
000074267fbd9a48  vmovaps [rsp+0x20], xmm13
000074267fbd9a4e  vmovaps xmm12, [rsp+0x20]
000074267fbd9a54  por xmm13, xmm12
000074267fbd9a59  lea r14, [rax+0x20]
000074267fbd9a5d  mov r12, [r13+r14*1]
000074267fbd9a62  lea r14, [rax+0x28]
000074267fbd9a66  mov r11, [r13+r14*1]
000074267fbd9a6b  movq xmm12, r12
000074267fbd9a70  movq xmm11, r11
000074267fbd9a75  movq xmm12, xmm12
000074267fbd9a7a  movq xmm11, xmm11
000074267fbd9a7f  movaps xmm10, [r15+0x2D0]
000074267fbd9a87  vmovaps [rsp+0x20], xmm10
000074267fbd9a8d  vmovaps xmm9, [rsp+0x20]
000074267fbd9a93  por xmm10, xmm9
000074267fbd9a98  movaps xmm9, [r15+0x300]
000074267fbd9aa0  vmovaps [rsp+0x20], xmm9
000074267fbd9aa6  vmovaps xmm8, [rsp+0x20]
000074267fbd9aac  por xmm9, xmm8
000074267fbd9ab1  movaps xmm8, [r15+0x2B0]
000074267fbd9ab9  vmovaps [rsp+0x20], xmm8
000074267fbd9abf  vmovaps xmm7, [rsp+0x20]
000074267fbd9ac5  por xmm8, xmm7
000074267fbd9aca  movaps xmm7, [r15+0x180]
000074267fbd9ad2  vmovaps [rsp+0x20], xmm7
000074267fbd9ad8  vmovaps xmm6, [rsp+0x20]
000074267fbd9ade  por xmm7, xmm6
000074267fbd9ae2  lea r14, [rax+0x10]
000074267fbd9ae6  mov r12, [r13+r14*1]
000074267fbd9aeb  lea r14, [rax+0x18]
000074267fbd9aef  mov r11, [r13+r14*1]
000074267fbd9af4  movq xmm6, r12
000074267fbd9af9  movq xmm5, r11
000074267fbd9afe  movq xmm6, xmm6
000074267fbd9b02  movq xmm5, xmm5
000074267fbd9b06  movaps xmm4, [r15+0x200]
000074267fbd9b0e  vmovaps [rsp+0x20], xmm4
000074267fbd9b14  vmovaps xmm3, [rsp+0x20]
000074267fbd9b1a  por xmm4, xmm3
000074267fbd9b1e  movaps xmm3, [r15+0x1F0]
000074267fbd9b26  vmovaps [rsp+0x20], xmm3
000074267fbd9b2c  vmovaps xmm2, [rsp+0x20]
000074267fbd9b32  por xmm3, xmm2
000074267fbd9b36  movaps xmm2, [r15+0x2E0]
000074267fbd9b3e  vmovaps [rsp+0x20], xmm2
000074267fbd9b44  vmovaps [rsp+0x30], xmm1
000074267fbd9b4a  vmovaps xmm1, [rsp+0x20]
000074267fbd9b50  por xmm2, xmm1
000074267fbd9b54  movaps xmm1, [r15+0x2A0]
000074267fbd9b5c  vmovaps [rsp+0x20], xmm1
000074267fbd9b62  vmovaps [rsp+0x40], xmm15
000074267fbd9b68  vmovaps xmm15, [rsp+0x20]
000074267fbd9b6e  por xmm1, xmm15
000074267fbd9b73  movaps xmm15, [r15+0x280]
000074267fbd9b7b  vmovaps [rsp+0x20], xmm15
000074267fbd9b81  vmovaps [rsp+0x50], xmm1
000074267fbd9b87  vmovaps xmm1, [rsp+0x20]
000074267fbd9b8d  por xmm15, xmm1
000074267fbd9b92  movaps xmm1, [r15+0x1C0]
000074267fbd9b9a  vmovaps [rsp+0x20], xmm1
000074267fbd9ba0  vmovaps [rsp+0x60], xmm15
000074267fbd9ba6  vmovaps xmm15, [rsp+0x20]
000074267fbd9bac  por xmm1, xmm15
000074267fbd9bb1  movaps xmm15, [r15+0x210]
000074267fbd9bb9  vmovaps [rsp+0x20], xmm15
000074267fbd9bbf  vmovaps [rsp+0x70], xmm1
000074267fbd9bc5  vmovaps xmm1, [rsp+0x20]
000074267fbd9bcb  por xmm15, xmm1
000074267fbd9bd0  mov r14, [r13+rax*1]
000074267fbd9bd5  vmovq xmm1, r14
000074267fbd9bda  vpbroadcastq xmm1, xmm1
000074267fbd9bdf  vmovaps [rsp+0x20], xmm1
000074267fbd9be5  vxorps xmm1, xmm1, xmm1
000074267fbd9be9  vpbroadcastq xmm1, xmm1
000074267fbd9bee  mov r14, [r15+0xF8]
000074267fbd9bf5  vmovaps [rsp+0x80], xmm1
000074267fbd9bfe  movups xmm1, [r13+r14*1]
000074267fbd9c04  vmovaps [rsp+0x90], xmm1
000074267fbd9c0d  vxorps xmm1, xmm1, xmm1
000074267fbd9c11  vpbroadcastq xmm1, xmm1
000074267fbd9c16  lea r12, [rax+0x08]
000074267fbd9c1a  mov rax, [r13+r12*1]
000074267fbd9c1f  vmovaps [rsp+0xA0], xmm1
000074267fbd9c28  movq xmm1, rax
000074267fbd9c2d  movaps [r15+0x240], xmm1
000074267fbd9c35  mov rax, [r15+0x50]
000074267fbd9c39  mov [r15+0x60], rax
000074267fbd9c3d  mov qword ptr [r15+0x58], 0x40
000074267fbd9c45  vmovaps xmm1, [rsp+0x30]
000074267fbd9c4b  vmovaps [rsp+0x30], xmm15
000074267fbd9c51  vmovaps xmm15, [rsp+0x90]
000074267fbd9c5a  vmovaps [rsp+0x90], xmm14
000074267fbd9c63  vmovaps xmm14, [rsp+0x20]
000074267fbd9c69  vmovaps [rsp+0x20], xmm13
000074267fbd9c6f  vmovaps [rsp+0xB0], xmm12
000074267fbd9c78  movaps xmm13, xmm1
000074267fbd9c7c  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd9c87  vptest xmm12, xmm12
000074267fbd9c8c  jnz 0x000074267FBDA72F
000074267fbd9c92  movaps xmm1, [r15+0x250]
000074267fbd9c9a  vmovaps xmm15, [rsp+0x40]
000074267fbd9ca0  vmovaps [rsp+0x40], xmm13
000074267fbd9ca6  movaps xmm12, xmm15
000074267fbd9caa  vfmadd231pd xmm12, xmm1, xmm14
000074267fbd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
000074267fbd9cb5  vptest xmm13, xmm13
000074267fbd9cba  jnz 0x000074267FBDA888
000074267fbd9cc0  movaps xmm15, [r15+0x1E0]
000074267fbd9cc8  vmovaps [rsp+0xC0], xmm15
000074267fbd9cd1  vmovaps xmm13, [rsp+0xC0]
000074267fbd9cda  por xmm15, xmm13
000074267fbd9cdf  movaps xmm13, [r15+0x1D0]
000074267fbd9ce7  vmovaps [rsp+0xC0], xmm13
000074267fbd9cf0  vmovaps [rsp+0xD0], xmm1
000074267fbd9cf9  vmovaps xmm1, [rsp+0xC0]
000074267fbd9d02  por xmm13, xmm1
000074267fbd9d07  movaps xmm1, [r15+0x2C0]
000074267fbd9d0f  vmovaps [rsp+0xC0], xmm1
000074267fbd9d18  vmovaps [rsp+0xE0], xmm15
000074267fbd9d21  vmovaps xmm15, [rsp+0xC0]
000074267fbd9d2a  por xmm1, xmm15
000074267fbd9d2f  movaps xmm15, [r15+0x290]
000074267fbd9d37  vmovaps [rsp+0xC0], xmm15
000074267fbd9d40  vmovaps [rsp+0xF0], xmm1
000074267fbd9d49  vmovaps xmm1, [rsp+0xC0]
000074267fbd9d52  por xmm15, xmm1
000074267fbd9d57  movaps xmm1, [r15+0x260]
000074267fbd9d5f  vmovaps [rsp+0xC0], xmm1
000074267fbd9d68  vmovaps [rsp+0x100], xmm15
000074267fbd9d71  vmovaps xmm15, [rsp+0xC0]
000074267fbd9d7a  por xmm1, xmm15
000074267fbd9d7f  vmovaps xmm15, [rsp+0xD0]
000074267fbd9d88  vmovaps [rsp+0xC0], xmm1
000074267fbd9d91  vmovaps xmm1, [rsp+0xD0]
000074267fbd9d9a  por xmm15, xmm1
000074267fbd9d9f  lea r12, [r14+0xC0]
000074267fbd9da6  movups xmm1, [r13+r12*1]
000074267fbd9dac  mov [rsp+0xD0], rax
000074267fbd9db4  xor eax, eax
000074267fbd9db6  mov r12d, 0x40
000074267fbd9dbc  mov r11d, 0x200
000074267fbd9dc2  cmp r12, r11
000074267fbd9dc5  cmc
000074267fbd9dc6  lahf
000074267fbd9dc7  seto al
000074267fbd9dca  mov [r15+0x108], eax
000074267fbd9dd1  vmovaps [rsp+0x110], xmm1
000074267fbd9dda  vmovaps xmm1, [rsp+0x80]
000074267fbd9de3  vmovaps [rsp+0x80], xmm15
000074267fbd9dec  vmovaps xmm15, [rsp+0x110]
000074267fbd9df5  vmovaps [rsp+0x110], xmm13
000074267fbd9dfe  vmovaps [rsp+0x120], xmm12
000074267fbd9e07  movaps xmm13, xmm1
000074267fbd9e0b  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd9e16  vptest xmm12, xmm12
000074267fbd9e1b  jnz 0x000074267FBDA9EB
000074267fbd9e21  lea rax, [r14+0xB0]
000074267fbd9e28  movups xmm1, [r13+rax*1]
000074267fbd9e2e  vmovaps xmm15, [rsp+0xA0]
000074267fbd9e37  vmovaps [rsp+0xA0], xmm13
000074267fbd9e40  movaps xmm12, xmm15
000074267fbd9e44  vfmadd231pd xmm12, xmm1, xmm14
000074267fbd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
000074267fbd9e4f  vptest xmm13, xmm13
000074267fbd9e54  jnz 0x000074267FBDAB4E
000074267fbd9e5a  vmovaps xmm1, [rsp+0x30]
000074267fbd9e60  vmovaps xmm15, [rsp+0x30]
000074267fbd9e66  por xmm1, xmm15
000074267fbd9e6b  movaps [r15+0x210], xmm1
000074267fbd9e73  vmovaps xmm15, [rsp+0x70]
000074267fbd9e79  vmovaps xmm14, [rsp+0x70]
000074267fbd9e7f  por xmm15, xmm14
000074267fbd9e84  movaps [r15+0x1C0], xmm15
000074267fbd9e8c  vmovaps xmm14, [rsp+0x60]
000074267fbd9e92  vmovaps xmm13, [rsp+0x60]
000074267fbd9e98  por xmm14, xmm13
000074267fbd9e9d  movaps [r15+0x280], xmm14
000074267fbd9ea5  vmovaps xmm13, [rsp+0x50]
000074267fbd9eab  vmovaps [rsp+0x30], xmm1
000074267fbd9eb1  vmovaps xmm1, [rsp+0x50]
000074267fbd9eb7  por xmm13, xmm1
000074267fbd9ebc  movaps [r15+0x2A0], xmm13
000074267fbd9ec4  vmovaps [rsp+0x50], xmm2
000074267fbd9eca  vmovaps xmm1, [rsp+0x50]
000074267fbd9ed0  por xmm2, xmm1
000074267fbd9ed4  movaps [r15+0x2E0], xmm2
000074267fbd9edc  vmovaps [rsp+0x50], xmm3
000074267fbd9ee2  vmovaps xmm1, [rsp+0x50]
000074267fbd9ee8  por xmm3, xmm1
000074267fbd9eec  movaps [r15+0x1F0], xmm3
000074267fbd9ef4  vmovaps xmm1, [rsp+0x80]
000074267fbd9efd  vmovaps [rsp+0x50], xmm15
000074267fbd9f03  vmovaps xmm15, [rsp+0x80]
000074267fbd9f0c  por xmm1, xmm15
000074267fbd9f11  movaps [r15+0x250], xmm1
000074267fbd9f19  vmovaps xmm1, [rsp+0xC0]
000074267fbd9f22  vmovaps xmm15, [rsp+0xC0]
000074267fbd9f2b  por xmm1, xmm15
000074267fbd9f30  movaps [r15+0x260], xmm1
000074267fbd9f38  vmovaps xmm15, [rsp+0x100]
000074267fbd9f41  vmovaps [rsp+0x60], xmm1
000074267fbd9f47  vmovaps xmm1, [rsp+0x100]
000074267fbd9f50  por xmm15, xmm1
000074267fbd9f55  movaps [r15+0x290], xmm15
000074267fbd9f5d  vmovaps xmm1, [rsp+0xF0]
000074267fbd9f66  vmovaps [rsp+0x70], xmm15
000074267fbd9f6c  vmovaps xmm15, [rsp+0xF0]
000074267fbd9f75  por xmm1, xmm15
000074267fbd9f7a  movaps [r15+0x2C0], xmm1
000074267fbd9f82  movq xmm15, qword ptr [r15+0x240]
000074267fbd9f8b  vmovaps [rsp+0x80], xmm15
000074267fbd9f94  vpermilpd xmm15, xmm15, 0x00
000074267fbd9f9a  vmovaps [rsp+0xC0], xmm1
000074267fbd9fa3  vmovaps xmm1, [rsp+0x40]
000074267fbd9fa9  vmovaps [rsp+0x40], xmm15
000074267fbd9faf  vmovaps xmm15, [rsp+0x30]
000074267fbd9fb5  vmovaps [rsp+0x30], xmm14
000074267fbd9fbb  vmovaps xmm14, [rsp+0x40]
000074267fbd9fc1  vmovaps [rsp+0x40], xmm13
000074267fbd9fc7  vmovaps [rsp+0xF0], xmm12
000074267fbd9fd0  movaps xmm13, xmm1
000074267fbd9fd4  vfmadd231pd xmm13, xmm15, xmm14
000074267fbd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
000074267fbd9fdf  vptest xmm12, xmm12
000074267fbd9fe4  jnz 0x000074267FBDACA7
000074267fbd9fea  vmovaps xmm1, [rsp+0x80]
000074267fbd9ff3  vpermilpd xmm1, xmm1, 0x00
000074267fbd9ff9  vmovaps xmm15, [rsp+0xA0]
000074267fbda002  movaps xmm14, xmm15
000074267fbda006  vfmadd231pd xmm14, xmm2, xmm1
000074267fbda00b  vcmppd xmm12, xmm14, xmm14, 0x03
000074267fbda011  vptest xmm12, xmm12
000074267fbda016  jnz 0x000074267FBDAE00
000074267fbda01c  vmovaps xmm1, [rsp+0x80]
000074267fbda025  vpermilpd xmm1, xmm1, 0x00
000074267fbda02b  vmovaps xmm15, [rsp+0x120]
000074267fbda034  vmovaps xmm12, [rsp+0x50]
000074267fbda03a  vmovaps [rsp+0x50], xmm14
000074267fbda040  movaps xmm2, xmm15
000074267fbda044  vfmadd231pd xmm2, xmm12, xmm1
000074267fbda049  vcmppd xmm14, xmm2, xmm2, 0x03
000074267fbda04e  vptest xmm14, xmm14
000074267fbda053  jnz 0x000074267FBDAF58
000074267fbda059  vmovaps xmm1, [rsp+0x110]
000074267fbda062  vmovaps xmm15, [rsp+0x110]
000074267fbda06b  por xmm1, xmm15
000074267fbda070  movaps [r15+0x1D0], xmm1
000074267fbda078  vmovaps xmm15, [rsp+0x80]
000074267fbda081  vpermilpd xmm15, xmm15, 0x00
000074267fbda087  vmovaps xmm14, [rsp+0xF0]
000074267fbda090  vmovaps [rsp+0x80], xmm1
000074267fbda099  movaps xmm12, xmm14
000074267fbda09d  vfmadd231pd xmm12, xmm3, xmm15
000074267fbda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
000074267fbda0a8  vptest xmm1, xmm1
000074267fbda0ad  jnz 0x000074267FBDB0AF
000074267fbda0b3  vmovaps [rsp+0xA0], xmm4
000074267fbda0bc  vmovaps xmm1, [rsp+0xA0]
000074267fbda0c5  por xmm4, xmm1
000074267fbda0c9  movaps [r15+0x200], xmm4
000074267fbda0d1  vmovaps xmm1, [rsp+0xE0]
000074267fbda0da  vmovaps xmm15, [rsp+0xE0]
000074267fbda0e3  por xmm1, xmm15
000074267fbda0e8  movaps [r15+0x1E0], xmm1
000074267fbda0f0  vmovaps [rsp+0xA0], xmm8
000074267fbda0f9  vmovaps xmm1, [rsp+0xA0]
000074267fbda102  por xmm8, xmm1
000074267fbda107  movaps [r15+0x2B0], xmm8
000074267fbda10f  vmovaps [rsp+0xA0], xmm9
000074267fbda118  vmovaps xmm1, [rsp+0xA0]
000074267fbda121  por xmm9, xmm1
000074267fbda126  movaps [r15+0x300], xmm9
000074267fbda12e  vmovaps [rsp+0xA0], xmm6
000074267fbda137  vpermilpd xmm6, xmm6, 0x00
000074267fbda13d  vmovaps xmm14, [rsp+0x60]
000074267fbda143  movaps xmm9, xmm13
000074267fbda147  vfmadd231pd xmm9, xmm14, xmm6
000074267fbda14c  vcmppd xmm3, xmm9, xmm9, 0x03
000074267fbda152  vptest xmm3, xmm3
000074267fbda157  jnz 0x000074267FBDB208
000074267fbda15d  vmovaps xmm14, [rsp+0xA0]
000074267fbda166  vpermilpd xmm14, xmm14, 0x00
000074267fbda16c  vmovaps xmm13, [rsp+0x50]
000074267fbda172  vmovaps xmm6, [rsp+0xC0]
000074267fbda17b  vmovaps [rsp+0x50], xmm1
000074267fbda181  movaps xmm3, xmm13
000074267fbda185  vfmadd231pd xmm3, xmm6, xmm14
000074267fbda18a  vcmppd xmm1, xmm3, xmm3, 0x03
000074267fbda18f  vptest xmm1, xmm1
000074267fbda194  jnz 0x000074267FBDB361
000074267fbda19a  vmovaps xmm1, [rsp+0xA0]
000074267fbda1a3  vpermilpd xmm1, xmm1, 0x00
000074267fbda1a9  vmovaps xmm14, [rsp+0x30]
000074267fbda1af  movaps xmm6, xmm2
000074267fbda1b2  vfmadd231pd xmm6, xmm14, xmm1
000074267fbda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
000074267fbda1bc  vptest xmm13, xmm13
000074267fbda1c1  jnz 0x000074267FBDB4B8
000074267fbda1c7  vmovaps xmm1, [rsp+0xA0]
000074267fbda1d0  vpermilpd xmm1, xmm1, 0x00
000074267fbda1d6  vmovaps xmm14, [rsp+0x80]
000074267fbda1df  movaps xmm13, xmm12
000074267fbda1e3  vfmadd231pd xmm13, xmm14, xmm1
000074267fbda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
000074267fbda1ee  vptest xmm2, xmm2
000074267fbda1f3  jnz 0x000074267FBDB60E
000074267fbda1f9  vmovaps [rsp+0x30], xmm7
000074267fbda1ff  vmovaps xmm1, [rsp+0x30]
000074267fbda205  por xmm7, xmm1
000074267fbda209  movaps [r15+0x180], xmm7
000074267fbda211  vmovaps [rsp+0x30], xmm10
000074267fbda217  vmovaps xmm1, [rsp+0x30]
000074267fbda21d  por xmm10, xmm1
000074267fbda222  movaps [r15+0x2D0], xmm10
000074267fbda22a  vmovaps [rsp+0x30], xmm5
000074267fbda230  vpermilpd xmm5, xmm5, 0x00
000074267fbda236  vmovaps xmm14, [rsp+0x50]
000074267fbda23c  movaps xmm12, xmm3
000074267fbda240  vfmadd231pd xmm12, xmm14, xmm5
000074267fbda245  vcmppd xmm10, xmm12, xmm12, 0x03
000074267fbda24b  vptest xmm10, xmm10
000074267fbda250  jnz 0x000074267FBDB767
000074267fbda256  vmovaps xmm14, [rsp+0x30]
000074267fbda25c  vpermilpd xmm14, xmm14, 0x00
000074267fbda262  movaps xmm10, xmm9
000074267fbda266  vfmadd231pd xmm10, xmm7, xmm14
000074267fbda26b  vcmppd xmm5, xmm10, xmm10, 0x03
000074267fbda271  vptest xmm5, xmm5
000074267fbda276  jnz 0x000074267FBDB8BF
000074267fbda27c  lea rax, [r14+0x80]
000074267fbda283  movups xmm14, [r13+rax*1]
000074267fbda289  movaps [r15+0x2F0], xmm14
000074267fbda291  vmovaps xmm9, [rsp+0x30]
000074267fbda297  vpermilpd xmm9, xmm9, 0x00
000074267fbda29d  vmovaps xmm7, [rsp+0x70]
000074267fbda2a3  movaps xmm5, xmm6
000074267fbda2a6  vfmadd231pd xmm5, xmm7, xmm9
000074267fbda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
000074267fbda2b0  vptest xmm3, xmm3
000074267fbda2b5  jnz 0x000074267FBDBA22
000074267fbda2bb  vmovaps xmm9, [rsp+0x30]
000074267fbda2c1  vpermilpd xmm9, xmm9, 0x00
000074267fbda2c7  movaps xmm7, xmm13
000074267fbda2cb  vfmadd231pd xmm7, xmm1, xmm9
000074267fbda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
000074267fbda2d5  vptest xmm6, xmm6
000074267fbda2da  jnz 0x000074267FBDBB78
000074267fbda2e0  vmovaps xmm1, [rsp+0x20]
000074267fbda2e6  vmovaps xmm13, [rsp+0x20]
000074267fbda2ec  por xmm1, xmm13
000074267fbda2f1  movaps [r15+0x160], xmm1
000074267fbda2f9  lea rax, [r14+0x40]
000074267fbda2fd  movups xmm13, [r13+rax*1]
000074267fbda303  lea rax, [r14+0x50]
000074267fbda307  movups xmm9, [r13+rax*1]
000074267fbda30d  movaps [r15+0x1B0], xmm13
000074267fbda315  movaps [r15+0x1A0], xmm9
000074267fbda31d  movaps xmm6, [r15+0x190]
000074267fbda325  vmovaps xmm3, [rsp+0xB0]
000074267fbda32e  vpermilpd xmm3, xmm3, 0x00
000074267fbda334  vmovaps [rsp+0x20], xmm1
000074267fbda33a  movaps xmm2, xmm12
000074267fbda33e  vfmadd231pd xmm2, xmm6, xmm3
000074267fbda343  vcmppd xmm1, xmm2, xmm2, 0x03
000074267fbda348  vptest xmm1, xmm1
000074267fbda34d  jnz 0x000074267FBDBCE3
000074267fbda353  vmovaps xmm1, [rsp+0xB0]
000074267fbda35c  vpermilpd xmm1, xmm1, 0x00
000074267fbda362  vmovaps xmm12, [rsp+0x20]
000074267fbda368  movaps xmm6, xmm10
000074267fbda36c  vfmadd231pd xmm6, xmm12, xmm1
000074267fbda371  vcmppd xmm3, xmm6, xmm6, 0x03
000074267fbda376  vptest xmm3, xmm3
000074267fbda37b  jnz 0x000074267FBDBE39
000074267fbda381  vmovaps xmm1, [rsp+0xB0]
000074267fbda38a  vpermilpd xmm1, xmm1, 0x00
000074267fbda390  vmovaps xmm12, [rsp+0x40]
000074267fbda396  movaps xmm10, xmm5
000074267fbda39a  vfmadd231pd xmm10, xmm12, xmm1
000074267fbda39f  vcmppd xmm3, xmm10, xmm10, 0x03
000074267fbda3a5  vptest xmm3, xmm3
000074267fbda3aa  jnz 0x000074267FBDBF90
000074267fbda3b0  vmovaps xmm1, [rsp+0xB0]
000074267fbda3b9  vpermilpd xmm1, xmm1, 0x00
000074267fbda3bf  movaps xmm12, xmm7
000074267fbda3c3  vfmadd231pd xmm12, xmm15, xmm1
000074267fbda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
000074267fbda3ce  vptest xmm5, xmm5
000074267fbda3d3  jnz 0x000074267FBDC0E8
000074267fbda3d9  lea rax, [r14+0x60]
000074267fbda3dd  movups xmm1, [r13+rax*1]
000074267fbda3e3  lea rax, [r14+0x70]
000074267fbda3e7  movups xmm15, [r13+rax*1]
000074267fbda3ed  movaps [r15+0x150], xmm1
000074267fbda3f5  movaps [r15+0x120], xmm15
000074267fbda3fd  vmovaps [rsp+0x20], xmm11
000074267fbda403  vpermilpd xmm11, xmm11, 0x00
000074267fbda409  movaps xmm7, xmm2
000074267fbda40c  vfmadd231pd xmm7, xmm9, xmm11
000074267fbda411  vcmppd xmm5, xmm7, xmm7, 0x03
000074267fbda416  vptest xmm5, xmm5
000074267fbda41b  jnz 0x000074267FBDC254
000074267fbda421  vmovaps xmm11, [rsp+0x20]
000074267fbda427  vpermilpd xmm11, xmm11, 0x00
000074267fbda42d  movaps xmm9, xmm6
000074267fbda431  vfmadd231pd xmm9, xmm1, xmm11
000074267fbda436  vcmppd xmm5, xmm9, xmm9, 0x03
000074267fbda43c  vptest xmm5, xmm5
000074267fbda441  jnz 0x000074267FBDC3AB
000074267fbda447  vmovaps xmm1, [rsp+0x20]
000074267fbda44d  vpermilpd xmm1, xmm1, 0x00
000074267fbda453  movaps xmm11, xmm10
000074267fbda457  vfmadd231pd xmm11, xmm8, xmm1
000074267fbda45c  vcmppd xmm6, xmm11, xmm11, 0x03
000074267fbda462  vptest xmm6, xmm6
000074267fbda467  jnz 0x000074267FBDC503
000074267fbda46d  vmovaps xmm1, [rsp+0x20]
000074267fbda473  vpermilpd xmm1, xmm1, 0x00
000074267fbda479  movaps xmm10, xmm12
000074267fbda47d  vfmadd231pd xmm10, xmm13, xmm1
000074267fbda482  vcmppd xmm8, xmm10, xmm10, 0x03
000074267fbda488  vptest xmm8, xmm8
000074267fbda48d  jnz 0x000074267FBDC65C
000074267fbda493  lea rax, [r14+0x20]
000074267fbda497  movups xmm1, [r13+rax*1]
000074267fbda49d  lea rax, [r14+0x30]
000074267fbda4a1  movups xmm13, [r13+rax*1]
000074267fbda4a7  vmovaps xmm12, [rsp+0x90]
000074267fbda4b0  vpermilpd xmm12, xmm12, 0x00
000074267fbda4b6  movaps xmm8, xmm7
000074267fbda4ba  vfmadd231pd xmm8, xmm4, xmm12
000074267fbda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
000074267fbda4c5  vptest xmm6, xmm6
000074267fbda4ca  jnz 0x000074267FBDC7C9
000074267fbda4d0  vmovaps xmm12, [rsp+0x90]
000074267fbda4d9  vpermilpd xmm12, xmm12, 0x00
000074267fbda4df  movaps xmm7, xmm9
000074267fbda4e3  vfmadd231pd xmm7, xmm14, xmm12
000074267fbda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
000074267fbda4ed  vptest xmm6, xmm6
000074267fbda4f2  jnz 0x000074267FBDC921
000074267fbda4f8  vmovaps xmm14, [rsp+0x90]
000074267fbda501  vpermilpd xmm14, xmm14, 0x00
000074267fbda507  movaps xmm12, xmm11
000074267fbda50b  vfmadd231pd xmm12, xmm15, xmm14
000074267fbda510  vcmppd xmm9, xmm12, xmm12, 0x03
000074267fbda516  vptest xmm9, xmm9
000074267fbda51b  jnz 0x000074267FBDCA79
000074267fbda521  vmovaps xmm15, [rsp+0x90]
000074267fbda52a  vpermilpd xmm15, xmm15, 0x00
000074267fbda530  movaps xmm11, xmm10
000074267fbda534  vfmadd231pd xmm11, xmm13, xmm15
000074267fbda539  vcmppd xmm14, xmm11, xmm11, 0x03
000074267fbda53f  vptest xmm14, xmm14
000074267fbda544  jnz 0x000074267FBDCBD3
000074267fbda54a  lea rax, [r14+0x90]
000074267fbda551  movups xmm15, [r13+rax*1]
000074267fbda557  lea rax, [r14+0xA0]
000074267fbda55e  movups xmm14, [r13+rax*1]
000074267fbda564  movaps [r15+0x140], xmm15
000074267fbda56c  movaps [r15+0x130], xmm14
000074267fbda574  vmovaps xmm13, [rsp+0x10]
000074267fbda57a  vpermilpd xmm13, xmm13, 0x00
000074267fbda580  movaps xmm10, xmm8
000074267fbda584  vfmadd231pd xmm10, xmm1, xmm13
000074267fbda589  vcmppd xmm9, xmm10, xmm10, 0x03
000074267fbda58f  vptest xmm9, xmm9
000074267fbda594  jnz 0x000074267FBDCD41
000074267fbda59a  movaps [r15+0x220], xmm10
000074267fbda5a2  lea rax, [r14+0x10]
000074267fbda5a6  movups xmm1, [r13+rax*1]
000074267fbda5ac  movaps [r15+0x240], xmm1
000074267fbda5b4  vmovaps xmm13, [rsp+0x10]
000074267fbda5ba  vpermilpd xmm13, xmm13, 0x00
000074267fbda5c0  movaps xmm9, xmm7
000074267fbda5c4  vfmadd231pd xmm9, xmm14, xmm13
000074267fbda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
000074267fbda5cf  vptest xmm8, xmm8
000074267fbda5d4  jnz 0x000074267FBDCEA4
000074267fbda5da  movaps [r15+0x110], xmm9
000074267fbda5e2  vmovaps xmm14, [rsp+0x10]
000074267fbda5e8  vpermilpd xmm14, xmm14, 0x00
000074267fbda5ee  movaps xmm13, xmm12
000074267fbda5f2  vfmadd231pd xmm13, xmm15, xmm14
000074267fbda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
000074267fbda5fd  vptest xmm8, xmm8
000074267fbda602  jnz 0x000074267FBDCFFD
000074267fbda608  movaps [r15+0x170], xmm13
000074267fbda610  vmovaps xmm15, [rsp+0x10]
000074267fbda616  vpermilpd xmm15, xmm15, 0x00
000074267fbda61c  movaps xmm14, xmm11
000074267fbda620  vfmadd231pd xmm14, xmm1, xmm15
000074267fbda625  vcmppd xmm12, xmm14, xmm14, 0x03
000074267fbda62b  vptest xmm12, xmm12
000074267fbda630  jnz 0x000074267FBDD157
000074267fbda636  movaps [r15+0x230], xmm14
000074267fbda63e  mov rax, [rsp+0xD0]
000074267fbda646  movups [r13+rax*1], xmm9
000074267fbda64c  lea r14, [rax+0x10]
000074267fbda650  movups [r13+r14*1], xmm13
000074267fbda656  lea r14, [rax+0x20]
000074267fbda65a  movups [r13+r14*1], xmm10
000074267fbda660  lea r14, [rax+0x30]
000074267fbda664  movups [r13+r14*1], xmm14
000074267fbda66a  mov eax, [r15+0x108]
000074267fbda671  sahf
000074267fbda672  jnz 0x000074267FBDA6A4
000074267fbda674  cmp dword ptr [r15+0x318], 0x00
000074267fbda67c  jz 0x000074267FBD9950
000074267fbda682  nop [rax+rax*1], ax
000074267fbda68b  nop [rax+rax*1], eax
000074267fbda693  mov eax, 0x410664
000074267fbda698  mov [r15+0x100], rax
000074267fbda69f  jmp 0x000074267F9FE110
000074267fbda6a4  cmp dword ptr [r15+0x318], 0x00
000074267fbda6ac  jz 0x000074267FBD6050
000074267fbda6b2  nop [rax+rax*1], ax
000074267fbda6bb  nop [rax+rax*1], eax
000074267fbda6c3  mov eax, 0x4104F0
000074267fbda6c8  mov [r15+0x100], rax
000074267fbda6cf  jmp 0x000074267F9FE110
000074267fbda6d4  int3
000074267fbda6d5  call 0x000074267FAE27E0
000074267fbda6da  jmp 0x000074267FBD9A10
000074267fbda6df  call 0x000074267FAE1570
000074267fbda6e4  jmp 0x000074267FBD9A19
000074267fbda6e9  call 0x000074267FAE27E0
000074267fbda6ee  jmp 0x000074267FBD9A62
000074267fbda6f3  call 0x000074267FAE1570
000074267fbda6f8  jmp 0x000074267FBD9A6B
000074267fbda6fd  call 0x000074267FAE27E0
000074267fbda702  jmp 0x000074267FBD9AEB
000074267fbda707  call 0x000074267FAE1570
000074267fbda70c  jmp 0x000074267FBD9AF4
000074267fbda711  call 0x000074267FA0DC20
000074267fbda716  jmp 0x000074267FBD9BD5
000074267fbda71b  call 0x000074267FAD64F0
000074267fbda720  jmp 0x000074267FBD9C04
000074267fbda725  call 0x000074267FAB47C0
000074267fbda72a  jmp 0x000074267FBD9C1F
000074267fbda72f  sub rsp, 0x08
000074267fbda733  push rax
000074267fbda734  push rcx
000074267fbda735  push rdx
000074267fbda736  push rdi
000074267fbda737  push rsi
000074267fbda738  push r8
000074267fbda73a  push r9
000074267fbda73c  push r10
000074267fbda73e  push r11
000074267fbda740  sub rsp, 0xF0
000074267fbda747  vmovaps [rsp], xmm0
000074267fbda74c  vmovaps [rsp+0x10], xmm1
000074267fbda752  vmovaps [rsp+0x20], xmm2
000074267fbda758  vmovaps [rsp+0x30], xmm3
000074267fbda75e  vmovaps [rsp+0x40], xmm4
000074267fbda764  vmovaps [rsp+0x50], xmm5
000074267fbda76a  vmovaps [rsp+0x60], xmm6
000074267fbda770  vmovaps [rsp+0x70], xmm7
000074267fbda776  vmovaps [rsp+0x80], xmm8
000074267fbda77f  vmovaps [rsp+0x90], xmm9
000074267fbda788  vmovaps [rsp+0xA0], xmm10
000074267fbda791  vmovaps [rsp+0xB0], xmm11
000074267fbda79a  vmovaps [rsp+0xC0], xmm12
000074267fbda7a3  vmovaps [rsp+0xD0], xmm14
000074267fbda7ac  vmovaps [rsp+0xE0], xmm15
000074267fbda7b5  sub rsp, 0x40
000074267fbda7b9  lea rdi, [rsp]
000074267fbda7bd  lea rsi, [rsp+0x10]
000074267fbda7c2  lea rdx, [rsp+0x20]
000074267fbda7c7  lea rcx, [rsp+0x30]
000074267fbda7cc  mov r8d, 0x00
000074267fbda7d2  lea r9, [r15+0x3A8]
000074267fbda7d9  movaps [rdi], xmm13
000074267fbda7dd  movaps [rsi], xmm1
000074267fbda7e0  movaps [rdx], xmm15
000074267fbda7e4  movaps [rcx], xmm14
000074267fbda7e8  mov rax, 0x56D4E47AEA50
000074267fbda7f2  call rax
000074267fbda7f4  movaps xmm13, [rsp]
000074267fbda7f9  add rsp, 0x40
000074267fbda7fd  vmovaps xmm0, [rsp]
000074267fbda802  vmovaps xmm1, [rsp+0x10]
000074267fbda808  vmovaps xmm2, [rsp+0x20]
000074267fbda80e  vmovaps xmm3, [rsp+0x30]
000074267fbda814  vmovaps xmm4, [rsp+0x40]
000074267fbda81a  vmovaps xmm5, [rsp+0x50]
000074267fbda820  vmovaps xmm6, [rsp+0x60]
000074267fbda826  vmovaps xmm7, [rsp+0x70]
000074267fbda82c  vmovaps xmm8, [rsp+0x80]
000074267fbda835  vmovaps xmm9, [rsp+0x90]
000074267fbda83e  vmovaps xmm10, [rsp+0xA0]
000074267fbda847  vmovaps xmm11, [rsp+0xB0]
000074267fbda850  vmovaps xmm12, [rsp+0xC0]
000074267fbda859  vmovaps xmm14, [rsp+0xD0]
000074267fbda862  vmovaps xmm15, [rsp+0xE0]
000074267fbda86b  add rsp, 0xF0
000074267fbda872  pop r11
000074267fbda874  pop r10
000074267fbda876  pop r9
000074267fbda878  pop r8
000074267fbda87a  pop rsi
000074267fbda87b  pop rdi
000074267fbda87c  pop rdx
000074267fbda87d  pop rcx
000074267fbda87e  pop rax
000074267fbda87f  add rsp, 0x08
000074267fbda883  jmp 0x000074267FBD9C92
000074267fbda888  sub rsp, 0x08
000074267fbda88c  push rax
000074267fbda88d  push rcx
000074267fbda88e  push rdx
000074267fbda88f  push rdi
000074267fbda890  push rsi
000074267fbda891  push r8
000074267fbda893  push r9
000074267fbda895  push r10
000074267fbda897  push r11
000074267fbda899  sub rsp, 0xF0
000074267fbda8a0  vmovaps [rsp], xmm0
000074267fbda8a5  vmovaps [rsp+0x10], xmm1
000074267fbda8ab  vmovaps [rsp+0x20], xmm2
000074267fbda8b1  vmovaps [rsp+0x30], xmm3
000074267fbda8b7  vmovaps [rsp+0x40], xmm4
000074267fbda8bd  vmovaps [rsp+0x50], xmm5
000074267fbda8c3  vmovaps [rsp+0x60], xmm6
000074267fbda8c9  vmovaps [rsp+0x70], xmm7
000074267fbda8cf  vmovaps [rsp+0x80], xmm8
000074267fbda8d8  vmovaps [rsp+0x90], xmm9
000074267fbda8e1  vmovaps [rsp+0xA0], xmm10
000074267fbda8ea  vmovaps [rsp+0xB0], xmm11
000074267fbda8f3  vmovaps [rsp+0xC0], xmm13
000074267fbda8fc  vmovaps [rsp+0xD0], xmm14
000074267fbda905  vmovaps [rsp+0xE0], xmm15
000074267fbda90e  sub rsp, 0x40
000074267fbda912  lea rdi, [rsp]
000074267fbda916  lea rsi, [rsp+0x10]
000074267fbda91b  lea rdx, [rsp+0x20]
000074267fbda920  lea rcx, [rsp+0x30]
000074267fbda925  mov r8d, 0x00
000074267fbda92b  lea r9, [r15+0x3A8]
000074267fbda932  movaps [rdi], xmm12
000074267fbda936  movaps [rsi], xmm15
000074267fbda93a  movaps [rdx], xmm1
000074267fbda93d  movaps [rcx], xmm14
000074267fbda941  mov rax, 0x56D4E47AEA50
000074267fbda94b  call rax
000074267fbda94d  movaps xmm12, [rsp]
000074267fbda952  add rsp, 0x40
000074267fbda956  vmovaps xmm0, [rsp]
000074267fbda95b  vmovaps xmm1, [rsp+0x10]
000074267fbda961  vmovaps xmm2, [rsp+0x20]
000074267fbda967  vmovaps xmm3, [rsp+0x30]
000074267fbda96d  vmovaps xmm4, [rsp+0x40]
000074267fbda973  vmovaps xmm5, [rsp+0x50]
000074267fbda979  vmovaps xmm6, [rsp+0x60]
000074267fbda97f  vmovaps xmm7, [rsp+0x70]
000074267fbda985  vmovaps xmm8, [rsp+0x80]
000074267fbda98e  vmovaps xmm9, [rsp+0x90]
000074267fbda997  vmovaps xmm10, [rsp+0xA0]
000074267fbda9a0  vmovaps xmm11, [rsp+0xB0]
000074267fbda9a9  vmovaps xmm13, [rsp+0xC0]
000074267fbda9b2  vmovaps xmm14, [rsp+0xD0]
000074267fbda9bb  vmovaps xmm15, [rsp+0xE0]
000074267fbda9c4  add rsp, 0xF0
000074267fbda9cb  pop r11
000074267fbda9cd  pop r10
000074267fbda9cf  pop r9
000074267fbda9d1  pop r8
000074267fbda9d3  pop rsi
000074267fbda9d4  pop rdi
000074267fbda9d5  pop rdx
000074267fbda9d6  pop rcx
000074267fbda9d7  pop rax
000074267fbda9d8  add rsp, 0x08
000074267fbda9dc  jmp 0x000074267FBD9CC0
000074267fbda9e1  call 0x000074267FAB52F0
000074267fbda9e6  jmp 0x000074267FBD9DAC
000074267fbda9eb  sub rsp, 0x08
000074267fbda9ef  push rax
000074267fbda9f0  push rcx
000074267fbda9f1  push rdx
000074267fbda9f2  push rdi
000074267fbda9f3  push rsi
000074267fbda9f4  push r8
000074267fbda9f6  push r9
000074267fbda9f8  push r10
000074267fbda9fa  push r11
000074267fbda9fc  sub rsp, 0xF0
000074267fbdaa03  vmovaps [rsp], xmm0
000074267fbdaa08  vmovaps [rsp+0x10], xmm1
000074267fbdaa0e  vmovaps [rsp+0x20], xmm2
000074267fbdaa14  vmovaps [rsp+0x30], xmm3
000074267fbdaa1a  vmovaps [rsp+0x40], xmm4
000074267fbdaa20  vmovaps [rsp+0x50], xmm5
000074267fbdaa26  vmovaps [rsp+0x60], xmm6
000074267fbdaa2c  vmovaps [rsp+0x70], xmm7
000074267fbdaa32  vmovaps [rsp+0x80], xmm8
000074267fbdaa3b  vmovaps [rsp+0x90], xmm9
000074267fbdaa44  vmovaps [rsp+0xA0], xmm10
000074267fbdaa4d  vmovaps [rsp+0xB0], xmm11
000074267fbdaa56  vmovaps [rsp+0xC0], xmm12
000074267fbdaa5f  vmovaps [rsp+0xD0], xmm14
000074267fbdaa68  vmovaps [rsp+0xE0], xmm15
000074267fbdaa71  sub rsp, 0x40
000074267fbdaa75  lea rdi, [rsp]
000074267fbdaa79  lea rsi, [rsp+0x10]
000074267fbdaa7e  lea rdx, [rsp+0x20]
000074267fbdaa83  lea rcx, [rsp+0x30]
000074267fbdaa88  mov r8d, 0x00
000074267fbdaa8e  lea r9, [r15+0x3A8]
000074267fbdaa95  movaps [rdi], xmm13
000074267fbdaa99  movaps [rsi], xmm1
000074267fbdaa9c  movaps [rdx], xmm15
000074267fbdaaa0  movaps [rcx], xmm14
000074267fbdaaa4  mov rax, 0x56D4E47AEA50
000074267fbdaaae  call rax
000074267fbdaab0  movaps xmm13, [rsp]
000074267fbdaab5  add rsp, 0x40
000074267fbdaab9  vmovaps xmm0, [rsp]
000074267fbdaabe  vmovaps xmm1, [rsp+0x10]
000074267fbdaac4  vmovaps xmm2, [rsp+0x20]
000074267fbdaaca  vmovaps xmm3, [rsp+0x30]
000074267fbdaad0  vmovaps xmm4, [rsp+0x40]
000074267fbdaad6  vmovaps xmm5, [rsp+0x50]
000074267fbdaadc  vmovaps xmm6, [rsp+0x60]
000074267fbdaae2  vmovaps xmm7, [rsp+0x70]
000074267fbdaae8  vmovaps xmm8, [rsp+0x80]
000074267fbdaaf1  vmovaps xmm9, [rsp+0x90]
000074267fbdaafa  vmovaps xmm10, [rsp+0xA0]
000074267fbdab03  vmovaps xmm11, [rsp+0xB0]
000074267fbdab0c  vmovaps xmm12, [rsp+0xC0]
000074267fbdab15  vmovaps xmm14, [rsp+0xD0]
000074267fbdab1e  vmovaps xmm15, [rsp+0xE0]
000074267fbdab27  add rsp, 0xF0
000074267fbdab2e  pop r11
000074267fbdab30  pop r10
000074267fbdab32  pop r9
000074267fbdab34  pop r8
000074267fbdab36  pop rsi
000074267fbdab37  pop rdi
000074267fbdab38  pop rdx
000074267fbdab39  pop rcx
000074267fbdab3a  pop rax
000074267fbdab3b  add rsp, 0x08
000074267fbdab3f  jmp 0x000074267FBD9E21
000074267fbdab44  call 0x000074267F9FF430
000074267fbdab49  jmp 0x000074267FBD9E2E
000074267fbdab4e  sub rsp, 0x08
000074267fbdab52  push rax
000074267fbdab53  push rcx
000074267fbdab54  push rdx
000074267fbdab55  push rdi
000074267fbdab56  push rsi
000074267fbdab57  push r8
000074267fbdab59  push r9
000074267fbdab5b  push r10
000074267fbdab5d  push r11
000074267fbdab5f  sub rsp, 0xF0
000074267fbdab66  vmovaps [rsp], xmm0
000074267fbdab6b  vmovaps [rsp+0x10], xmm1
000074267fbdab71  vmovaps [rsp+0x20], xmm2
000074267fbdab77  vmovaps [rsp+0x30], xmm3
000074267fbdab7d  vmovaps [rsp+0x40], xmm4
000074267fbdab83  vmovaps [rsp+0x50], xmm5
000074267fbdab89  vmovaps [rsp+0x60], xmm6
000074267fbdab8f  vmovaps [rsp+0x70], xmm7
000074267fbdab95  vmovaps [rsp+0x80], xmm8
000074267fbdab9e  vmovaps [rsp+0x90], xmm9
000074267fbdaba7  vmovaps [rsp+0xA0], xmm10
000074267fbdabb0  vmovaps [rsp+0xB0], xmm11
000074267fbdabb9  vmovaps [rsp+0xC0], xmm13
000074267fbdabc2  vmovaps [rsp+0xD0], xmm14
000074267fbdabcb  vmovaps [rsp+0xE0], xmm15
000074267fbdabd4  sub rsp, 0x40
000074267fbdabd8  lea rdi, [rsp]
000074267fbdabdc  lea rsi, [rsp+0x10]
000074267fbdabe1  lea rdx, [rsp+0x20]
000074267fbdabe6  lea rcx, [rsp+0x30]
000074267fbdabeb  mov r8d, 0x00
000074267fbdabf1  lea r9, [r15+0x3A8]
000074267fbdabf8  movaps [rdi], xmm12
000074267fbdabfc  movaps [rsi], xmm15
000074267fbdac00  movaps [rdx], xmm1
000074267fbdac03  movaps [rcx], xmm14
000074267fbdac07  mov rax, 0x56D4E47AEA50
000074267fbdac11  call rax
000074267fbdac13  movaps xmm12, [rsp]
000074267fbdac18  add rsp, 0x40
000074267fbdac1c  vmovaps xmm0, [rsp]
000074267fbdac21  vmovaps xmm1, [rsp+0x10]
000074267fbdac27  vmovaps xmm2, [rsp+0x20]
000074267fbdac2d  vmovaps xmm3, [rsp+0x30]
000074267fbdac33  vmovaps xmm4, [rsp+0x40]
000074267fbdac39  vmovaps xmm5, [rsp+0x50]
000074267fbdac3f  vmovaps xmm6, [rsp+0x60]
000074267fbdac45  vmovaps xmm7, [rsp+0x70]
000074267fbdac4b  vmovaps xmm8, [rsp+0x80]
000074267fbdac54  vmovaps xmm9, [rsp+0x90]
000074267fbdac5d  vmovaps xmm10, [rsp+0xA0]
000074267fbdac66  vmovaps xmm11, [rsp+0xB0]
000074267fbdac6f  vmovaps xmm13, [rsp+0xC0]
000074267fbdac78  vmovaps xmm14, [rsp+0xD0]
000074267fbdac81  vmovaps xmm15, [rsp+0xE0]
000074267fbdac8a  add rsp, 0xF0
000074267fbdac91  pop r11
000074267fbdac93  pop r10
000074267fbdac95  pop r9
000074267fbdac97  pop r8
000074267fbdac99  pop rsi
000074267fbdac9a  pop rdi
000074267fbdac9b  pop rdx
000074267fbdac9c  pop rcx
000074267fbdac9d  pop rax
000074267fbdac9e  add rsp, 0x08
000074267fbdaca2  jmp 0x000074267FBD9E5A
000074267fbdaca7  sub rsp, 0x08
000074267fbdacab  push rax
000074267fbdacac  push rcx
000074267fbdacad  push rdx
000074267fbdacae  push rdi
000074267fbdacaf  push rsi
000074267fbdacb0  push r8
000074267fbdacb2  push r9
000074267fbdacb4  push r10
000074267fbdacb6  push r11
000074267fbdacb8  sub rsp, 0xF0
000074267fbdacbf  vmovaps [rsp], xmm0
000074267fbdacc4  vmovaps [rsp+0x10], xmm1
000074267fbdacca  vmovaps [rsp+0x20], xmm2
000074267fbdacd0  vmovaps [rsp+0x30], xmm3
000074267fbdacd6  vmovaps [rsp+0x40], xmm4
000074267fbdacdc  vmovaps [rsp+0x50], xmm5
000074267fbdace2  vmovaps [rsp+0x60], xmm6
000074267fbdace8  vmovaps [rsp+0x70], xmm7
000074267fbdacee  vmovaps [rsp+0x80], xmm8
000074267fbdacf7  vmovaps [rsp+0x90], xmm9
000074267fbdad00  vmovaps [rsp+0xA0], xmm10
000074267fbdad09  vmovaps [rsp+0xB0], xmm11
000074267fbdad12  vmovaps [rsp+0xC0], xmm12
000074267fbdad1b  vmovaps [rsp+0xD0], xmm14
000074267fbdad24  vmovaps [rsp+0xE0], xmm15
000074267fbdad2d  sub rsp, 0x40
000074267fbdad31  lea rdi, [rsp]
000074267fbdad35  lea rsi, [rsp+0x10]
000074267fbdad3a  lea rdx, [rsp+0x20]
000074267fbdad3f  lea rcx, [rsp+0x30]
000074267fbdad44  mov r8d, 0x00
000074267fbdad4a  lea r9, [r15+0x3A8]
000074267fbdad51  movaps [rdi], xmm13
000074267fbdad55  movaps [rsi], xmm1
000074267fbdad58  movaps [rdx], xmm15
000074267fbdad5c  movaps [rcx], xmm14
000074267fbdad60  mov rax, 0x56D4E47AEA50
000074267fbdad6a  call rax
000074267fbdad6c  movaps xmm13, [rsp]
000074267fbdad71  add rsp, 0x40
000074267fbdad75  vmovaps xmm0, [rsp]
000074267fbdad7a  vmovaps xmm1, [rsp+0x10]
000074267fbdad80  vmovaps xmm2, [rsp+0x20]
000074267fbdad86  vmovaps xmm3, [rsp+0x30]
000074267fbdad8c  vmovaps xmm4, [rsp+0x40]
000074267fbdad92  vmovaps xmm5, [rsp+0x50]
000074267fbdad98  vmovaps xmm6, [rsp+0x60]
000074267fbdad9e  vmovaps xmm7, [rsp+0x70]
000074267fbdada4  vmovaps xmm8, [rsp+0x80]
000074267fbdadad  vmovaps xmm9, [rsp+0x90]
000074267fbdadb6  vmovaps xmm10, [rsp+0xA0]
000074267fbdadbf  vmovaps xmm11, [rsp+0xB0]
000074267fbdadc8  vmovaps xmm12, [rsp+0xC0]
000074267fbdadd1  vmovaps xmm14, [rsp+0xD0]
000074267fbdadda  vmovaps xmm15, [rsp+0xE0]
000074267fbdade3  add rsp, 0xF0
000074267fbdadea  pop r11
000074267fbdadec  pop r10
000074267fbdadee  pop r9
000074267fbdadf0  pop r8
000074267fbdadf2  pop rsi
000074267fbdadf3  pop rdi
000074267fbdadf4  pop rdx
000074267fbdadf5  pop rcx
000074267fbdadf6  pop rax
000074267fbdadf7  add rsp, 0x08
000074267fbdadfb  jmp 0x000074267FBD9FEA
000074267fbdae00  sub rsp, 0x08
000074267fbdae04  push rax
000074267fbdae05  push rcx
000074267fbdae06  push rdx
000074267fbdae07  push rdi
000074267fbdae08  push rsi
000074267fbdae09  push r8
000074267fbdae0b  push r9
000074267fbdae0d  push r10
000074267fbdae0f  push r11
000074267fbdae11  sub rsp, 0xF0
000074267fbdae18  vmovaps [rsp], xmm0
000074267fbdae1d  vmovaps [rsp+0x10], xmm1
000074267fbdae23  vmovaps [rsp+0x20], xmm2
000074267fbdae29  vmovaps [rsp+0x30], xmm3
000074267fbdae2f  vmovaps [rsp+0x40], xmm4
000074267fbdae35  vmovaps [rsp+0x50], xmm5
000074267fbdae3b  vmovaps [rsp+0x60], xmm6
000074267fbdae41  vmovaps [rsp+0x70], xmm7
000074267fbdae47  vmovaps [rsp+0x80], xmm8
000074267fbdae50  vmovaps [rsp+0x90], xmm9
000074267fbdae59  vmovaps [rsp+0xA0], xmm10
000074267fbdae62  vmovaps [rsp+0xB0], xmm11
000074267fbdae6b  vmovaps [rsp+0xC0], xmm12
000074267fbdae74  vmovaps [rsp+0xD0], xmm13
000074267fbdae7d  vmovaps [rsp+0xE0], xmm15
000074267fbdae86  sub rsp, 0x40
000074267fbdae8a  lea rdi, [rsp]
000074267fbdae8e  lea rsi, [rsp+0x10]
000074267fbdae93  lea rdx, [rsp+0x20]
000074267fbdae98  lea rcx, [rsp+0x30]
000074267fbdae9d  mov r8d, 0x00
000074267fbdaea3  lea r9, [r15+0x3A8]
000074267fbdaeaa  movaps [rdi], xmm14
000074267fbdaeae  movaps [rsi], xmm15
000074267fbdaeb2  movaps [rdx], xmm2
000074267fbdaeb5  movaps [rcx], xmm1
000074267fbdaeb8  mov rax, 0x56D4E47AEA50
000074267fbdaec2  call rax
000074267fbdaec4  movaps xmm14, [rsp]
000074267fbdaec9  add rsp, 0x40
000074267fbdaecd  vmovaps xmm0, [rsp]
000074267fbdaed2  vmovaps xmm1, [rsp+0x10]
000074267fbdaed8  vmovaps xmm2, [rsp+0x20]
000074267fbdaede  vmovaps xmm3, [rsp+0x30]
000074267fbdaee4  vmovaps xmm4, [rsp+0x40]
000074267fbdaeea  vmovaps xmm5, [rsp+0x50]
000074267fbdaef0  vmovaps xmm6, [rsp+0x60]
000074267fbdaef6  vmovaps xmm7, [rsp+0x70]
000074267fbdaefc  vmovaps xmm8, [rsp+0x80]
000074267fbdaf05  vmovaps xmm9, [rsp+0x90]
000074267fbdaf0e  vmovaps xmm10, [rsp+0xA0]
000074267fbdaf17  vmovaps xmm11, [rsp+0xB0]
000074267fbdaf20  vmovaps xmm12, [rsp+0xC0]
000074267fbdaf29  vmovaps xmm13, [rsp+0xD0]
000074267fbdaf32  vmovaps xmm15, [rsp+0xE0]
000074267fbdaf3b  add rsp, 0xF0
000074267fbdaf42  pop r11
000074267fbdaf44  pop r10
000074267fbdaf46  pop r9
000074267fbdaf48  pop r8
000074267fbdaf4a  pop rsi
000074267fbdaf4b  pop rdi
000074267fbdaf4c  pop rdx
000074267fbdaf4d  pop rcx
000074267fbdaf4e  pop rax
000074267fbdaf4f  add rsp, 0x08
000074267fbdaf53  jmp 0x000074267FBDA01C
000074267fbdaf58  sub rsp, 0x08
000074267fbdaf5c  push rax
000074267fbdaf5d  push rcx
000074267fbdaf5e  push rdx
000074267fbdaf5f  push rdi
000074267fbdaf60  push rsi
000074267fbdaf61  push r8
000074267fbdaf63  push r9
000074267fbdaf65  push r10
000074267fbdaf67  push r11
000074267fbdaf69  sub rsp, 0xF0
000074267fbdaf70  vmovaps [rsp], xmm0
000074267fbdaf75  vmovaps [rsp+0x10], xmm1
000074267fbdaf7b  vmovaps [rsp+0x20], xmm3
000074267fbdaf81  vmovaps [rsp+0x30], xmm4
000074267fbdaf87  vmovaps [rsp+0x40], xmm5
000074267fbdaf8d  vmovaps [rsp+0x50], xmm6
000074267fbdaf93  vmovaps [rsp+0x60], xmm7
000074267fbdaf99  vmovaps [rsp+0x70], xmm8
000074267fbdaf9f  vmovaps [rsp+0x80], xmm9
000074267fbdafa8  vmovaps [rsp+0x90], xmm10
000074267fbdafb1  vmovaps [rsp+0xA0], xmm11
000074267fbdafba  vmovaps [rsp+0xB0], xmm12
000074267fbdafc3  vmovaps [rsp+0xC0], xmm13
000074267fbdafcc  vmovaps [rsp+0xD0], xmm14
000074267fbdafd5  vmovaps [rsp+0xE0], xmm15
000074267fbdafde  sub rsp, 0x40
000074267fbdafe2  lea rdi, [rsp]
000074267fbdafe6  lea rsi, [rsp+0x10]
000074267fbdafeb  lea rdx, [rsp+0x20]
000074267fbdaff0  lea rcx, [rsp+0x30]
000074267fbdaff5  mov r8d, 0x00
000074267fbdaffb  lea r9, [r15+0x3A8]
000074267fbdb002  movaps [rdi], xmm2
000074267fbdb005  movaps [rsi], xmm15
000074267fbdb009  movaps [rdx], xmm12
000074267fbdb00d  movaps [rcx], xmm1
000074267fbdb010  mov rax, 0x56D4E47AEA50
000074267fbdb01a  call rax
000074267fbdb01c  movaps xmm2, [rsp]
000074267fbdb020  add rsp, 0x40
000074267fbdb024  vmovaps xmm0, [rsp]
000074267fbdb029  vmovaps xmm1, [rsp+0x10]
000074267fbdb02f  vmovaps xmm3, [rsp+0x20]
000074267fbdb035  vmovaps xmm4, [rsp+0x30]
000074267fbdb03b  vmovaps xmm5, [rsp+0x40]
000074267fbdb041  vmovaps xmm6, [rsp+0x50]
000074267fbdb047  vmovaps xmm7, [rsp+0x60]
000074267fbdb04d  vmovaps xmm8, [rsp+0x70]
000074267fbdb053  vmovaps xmm9, [rsp+0x80]
000074267fbdb05c  vmovaps xmm10, [rsp+0x90]
000074267fbdb065  vmovaps xmm11, [rsp+0xA0]
000074267fbdb06e  vmovaps xmm12, [rsp+0xB0]
000074267fbdb077  vmovaps xmm13, [rsp+0xC0]
000074267fbdb080  vmovaps xmm14, [rsp+0xD0]
000074267fbdb089  vmovaps xmm15, [rsp+0xE0]
000074267fbdb092  add rsp, 0xF0
000074267fbdb099  pop r11
000074267fbdb09b  pop r10
000074267fbdb09d  pop r9
000074267fbdb09f  pop r8
000074267fbdb0a1  pop rsi
000074267fbdb0a2  pop rdi
000074267fbdb0a3  pop rdx
000074267fbdb0a4  pop rcx
000074267fbdb0a5  pop rax
000074267fbdb0a6  add rsp, 0x08
000074267fbdb0aa  jmp 0x000074267FBDA059
000074267fbdb0af  sub rsp, 0x08
000074267fbdb0b3  push rax
000074267fbdb0b4  push rcx
000074267fbdb0b5  push rdx
000074267fbdb0b6  push rdi
000074267fbdb0b7  push rsi
000074267fbdb0b8  push r8
000074267fbdb0ba  push r9
000074267fbdb0bc  push r10
000074267fbdb0be  push r11
000074267fbdb0c0  sub rsp, 0xF0
000074267fbdb0c7  vmovaps [rsp], xmm0
000074267fbdb0cc  vmovaps [rsp+0x10], xmm1
000074267fbdb0d2  vmovaps [rsp+0x20], xmm2
000074267fbdb0d8  vmovaps [rsp+0x30], xmm3
000074267fbdb0de  vmovaps [rsp+0x40], xmm4
000074267fbdb0e4  vmovaps [rsp+0x50], xmm5
000074267fbdb0ea  vmovaps [rsp+0x60], xmm6
000074267fbdb0f0  vmovaps [rsp+0x70], xmm7
000074267fbdb0f6  vmovaps [rsp+0x80], xmm8
000074267fbdb0ff  vmovaps [rsp+0x90], xmm9
000074267fbdb108  vmovaps [rsp+0xA0], xmm10
000074267fbdb111  vmovaps [rsp+0xB0], xmm11
000074267fbdb11a  vmovaps [rsp+0xC0], xmm13
000074267fbdb123  vmovaps [rsp+0xD0], xmm14
000074267fbdb12c  vmovaps [rsp+0xE0], xmm15
000074267fbdb135  sub rsp, 0x40
000074267fbdb139  lea rdi, [rsp]
000074267fbdb13d  lea rsi, [rsp+0x10]
000074267fbdb142  lea rdx, [rsp+0x20]
000074267fbdb147  lea rcx, [rsp+0x30]
000074267fbdb14c  mov r8d, 0x00
000074267fbdb152  lea r9, [r15+0x3A8]
000074267fbdb159  movaps [rdi], xmm12
000074267fbdb15d  movaps [rsi], xmm14
000074267fbdb161  movaps [rdx], xmm3
000074267fbdb164  movaps [rcx], xmm15
000074267fbdb168  mov rax, 0x56D4E47AEA50
000074267fbdb172  call rax
000074267fbdb174  movaps xmm12, [rsp]
000074267fbdb179  add rsp, 0x40
000074267fbdb17d  vmovaps xmm0, [rsp]
000074267fbdb182  vmovaps xmm1, [rsp+0x10]
000074267fbdb188  vmovaps xmm2, [rsp+0x20]
000074267fbdb18e  vmovaps xmm3, [rsp+0x30]
000074267fbdb194  vmovaps xmm4, [rsp+0x40]
000074267fbdb19a  vmovaps xmm5, [rsp+0x50]
000074267fbdb1a0  vmovaps xmm6, [rsp+0x60]
000074267fbdb1a6  vmovaps xmm7, [rsp+0x70]
000074267fbdb1ac  vmovaps xmm8, [rsp+0x80]
000074267fbdb1b5  vmovaps xmm9, [rsp+0x90]
000074267fbdb1be  vmovaps xmm10, [rsp+0xA0]
000074267fbdb1c7  vmovaps xmm11, [rsp+0xB0]
000074267fbdb1d0  vmovaps xmm13, [rsp+0xC0]
000074267fbdb1d9  vmovaps xmm14, [rsp+0xD0]
000074267fbdb1e2  vmovaps xmm15, [rsp+0xE0]
000074267fbdb1eb  add rsp, 0xF0
000074267fbdb1f2  pop r11
000074267fbdb1f4  pop r10
000074267fbdb1f6  pop r9
000074267fbdb1f8  pop r8
000074267fbdb1fa  pop rsi
000074267fbdb1fb  pop rdi
000074267fbdb1fc  pop rdx
000074267fbdb1fd  pop rcx
000074267fbdb1fe  pop rax
000074267fbdb1ff  add rsp, 0x08
000074267fbdb203  jmp 0x000074267FBDA0B3
000074267fbdb208  sub rsp, 0x08
000074267fbdb20c  push rax
000074267fbdb20d  push rcx
000074267fbdb20e  push rdx
000074267fbdb20f  push rdi
000074267fbdb210  push rsi
000074267fbdb211  push r8
000074267fbdb213  push r9
000074267fbdb215  push r10
000074267fbdb217  push r11
000074267fbdb219  sub rsp, 0xF0
000074267fbdb220  vmovaps [rsp], xmm0
000074267fbdb225  vmovaps [rsp+0x10], xmm1
000074267fbdb22b  vmovaps [rsp+0x20], xmm2
000074267fbdb231  vmovaps [rsp+0x30], xmm3
000074267fbdb237  vmovaps [rsp+0x40], xmm4
000074267fbdb23d  vmovaps [rsp+0x50], xmm5
000074267fbdb243  vmovaps [rsp+0x60], xmm6
000074267fbdb249  vmovaps [rsp+0x70], xmm7
000074267fbdb24f  vmovaps [rsp+0x80], xmm8
000074267fbdb258  vmovaps [rsp+0x90], xmm10
000074267fbdb261  vmovaps [rsp+0xA0], xmm11
000074267fbdb26a  vmovaps [rsp+0xB0], xmm12
000074267fbdb273  vmovaps [rsp+0xC0], xmm13
000074267fbdb27c  vmovaps [rsp+0xD0], xmm14
000074267fbdb285  vmovaps [rsp+0xE0], xmm15
000074267fbdb28e  sub rsp, 0x40
000074267fbdb292  lea rdi, [rsp]
000074267fbdb296  lea rsi, [rsp+0x10]
000074267fbdb29b  lea rdx, [rsp+0x20]
000074267fbdb2a0  lea rcx, [rsp+0x30]
000074267fbdb2a5  mov r8d, 0x00
000074267fbdb2ab  lea r9, [r15+0x3A8]
000074267fbdb2b2  movaps [rdi], xmm9
000074267fbdb2b6  movaps [rsi], xmm13
000074267fbdb2ba  movaps [rdx], xmm14
000074267fbdb2be  movaps [rcx], xmm6
000074267fbdb2c1  mov rax, 0x56D4E47AEA50
000074267fbdb2cb  call rax
000074267fbdb2cd  movaps xmm9, [rsp]
000074267fbdb2d2  add rsp, 0x40
000074267fbdb2d6  vmovaps xmm0, [rsp]
000074267fbdb2db  vmovaps xmm1, [rsp+0x10]
000074267fbdb2e1  vmovaps xmm2, [rsp+0x20]
000074267fbdb2e7  vmovaps xmm3, [rsp+0x30]
000074267fbdb2ed  vmovaps xmm4, [rsp+0x40]
000074267fbdb2f3  vmovaps xmm5, [rsp+0x50]
000074267fbdb2f9  vmovaps xmm6, [rsp+0x60]
000074267fbdb2ff  vmovaps xmm7, [rsp+0x70]
000074267fbdb305  vmovaps xmm8, [rsp+0x80]
000074267fbdb30e  vmovaps xmm10, [rsp+0x90]
000074267fbdb317  vmovaps xmm11, [rsp+0xA0]
000074267fbdb320  vmovaps xmm12, [rsp+0xB0]
000074267fbdb329  vmovaps xmm13, [rsp+0xC0]
000074267fbdb332  vmovaps xmm14, [rsp+0xD0]
000074267fbdb33b  vmovaps xmm15, [rsp+0xE0]
000074267fbdb344  add rsp, 0xF0
000074267fbdb34b  pop r11
000074267fbdb34d  pop r10
000074267fbdb34f  pop r9
000074267fbdb351  pop r8
000074267fbdb353  pop rsi
000074267fbdb354  pop rdi
000074267fbdb355  pop rdx
000074267fbdb356  pop rcx
000074267fbdb357  pop rax
000074267fbdb358  add rsp, 0x08
000074267fbdb35c  jmp 0x000074267FBDA15D
000074267fbdb361  sub rsp, 0x08
000074267fbdb365  push rax
000074267fbdb366  push rcx
000074267fbdb367  push rdx
000074267fbdb368  push rdi
000074267fbdb369  push rsi
000074267fbdb36a  push r8
000074267fbdb36c  push r9
000074267fbdb36e  push r10
000074267fbdb370  push r11
000074267fbdb372  sub rsp, 0xF0
000074267fbdb379  vmovaps [rsp], xmm0
000074267fbdb37e  vmovaps [rsp+0x10], xmm1
000074267fbdb384  vmovaps [rsp+0x20], xmm2
000074267fbdb38a  vmovaps [rsp+0x30], xmm4
000074267fbdb390  vmovaps [rsp+0x40], xmm5
000074267fbdb396  vmovaps [rsp+0x50], xmm6
000074267fbdb39c  vmovaps [rsp+0x60], xmm7
000074267fbdb3a2  vmovaps [rsp+0x70], xmm8
000074267fbdb3a8  vmovaps [rsp+0x80], xmm9
000074267fbdb3b1  vmovaps [rsp+0x90], xmm10
000074267fbdb3ba  vmovaps [rsp+0xA0], xmm11
000074267fbdb3c3  vmovaps [rsp+0xB0], xmm12
000074267fbdb3cc  vmovaps [rsp+0xC0], xmm13
000074267fbdb3d5  vmovaps [rsp+0xD0], xmm14
000074267fbdb3de  vmovaps [rsp+0xE0], xmm15
000074267fbdb3e7  sub rsp, 0x40
000074267fbdb3eb  lea rdi, [rsp]
000074267fbdb3ef  lea rsi, [rsp+0x10]
000074267fbdb3f4  lea rdx, [rsp+0x20]
000074267fbdb3f9  lea rcx, [rsp+0x30]
000074267fbdb3fe  mov r8d, 0x00
000074267fbdb404  lea r9, [r15+0x3A8]
000074267fbdb40b  movaps [rdi], xmm3
000074267fbdb40e  movaps [rsi], xmm13
000074267fbdb412  movaps [rdx], xmm6
000074267fbdb415  movaps [rcx], xmm14
000074267fbdb419  mov rax, 0x56D4E47AEA50
000074267fbdb423  call rax
000074267fbdb425  movaps xmm3, [rsp]
000074267fbdb429  add rsp, 0x40
000074267fbdb42d  vmovaps xmm0, [rsp]
000074267fbdb432  vmovaps xmm1, [rsp+0x10]
000074267fbdb438  vmovaps xmm2, [rsp+0x20]
000074267fbdb43e  vmovaps xmm4, [rsp+0x30]
000074267fbdb444  vmovaps xmm5, [rsp+0x40]
000074267fbdb44a  vmovaps xmm6, [rsp+0x50]
000074267fbdb450  vmovaps xmm7, [rsp+0x60]
000074267fbdb456  vmovaps xmm8, [rsp+0x70]
000074267fbdb45c  vmovaps xmm9, [rsp+0x80]
000074267fbdb465  vmovaps xmm10, [rsp+0x90]
000074267fbdb46e  vmovaps xmm11, [rsp+0xA0]
000074267fbdb477  vmovaps xmm12, [rsp+0xB0]
000074267fbdb480  vmovaps xmm13, [rsp+0xC0]
000074267fbdb489  vmovaps xmm14, [rsp+0xD0]
000074267fbdb492  vmovaps xmm15, [rsp+0xE0]
000074267fbdb49b  add rsp, 0xF0
000074267fbdb4a2  pop r11
000074267fbdb4a4  pop r10
000074267fbdb4a6  pop r9
000074267fbdb4a8  pop r8
000074267fbdb4aa  pop rsi
000074267fbdb4ab  pop rdi
000074267fbdb4ac  pop rdx
000074267fbdb4ad  pop rcx
000074267fbdb4ae  pop rax
000074267fbdb4af  add rsp, 0x08
000074267fbdb4b3  jmp 0x000074267FBDA19A
000074267fbdb4b8  sub rsp, 0x08
000074267fbdb4bc  push rax
000074267fbdb4bd  push rcx
000074267fbdb4be  push rdx
000074267fbdb4bf  push rdi
000074267fbdb4c0  push rsi
000074267fbdb4c1  push r8
000074267fbdb4c3  push r9
000074267fbdb4c5  push r10
000074267fbdb4c7  push r11
000074267fbdb4c9  sub rsp, 0xF0
000074267fbdb4d0  vmovaps [rsp], xmm0
000074267fbdb4d5  vmovaps [rsp+0x10], xmm1
000074267fbdb4db  vmovaps [rsp+0x20], xmm2
000074267fbdb4e1  vmovaps [rsp+0x30], xmm3
000074267fbdb4e7  vmovaps [rsp+0x40], xmm4
000074267fbdb4ed  vmovaps [rsp+0x50], xmm5
000074267fbdb4f3  vmovaps [rsp+0x60], xmm7
000074267fbdb4f9  vmovaps [rsp+0x70], xmm8
000074267fbdb4ff  vmovaps [rsp+0x80], xmm9
000074267fbdb508  vmovaps [rsp+0x90], xmm10
000074267fbdb511  vmovaps [rsp+0xA0], xmm11
000074267fbdb51a  vmovaps [rsp+0xB0], xmm12
000074267fbdb523  vmovaps [rsp+0xC0], xmm13
000074267fbdb52c  vmovaps [rsp+0xD0], xmm14
000074267fbdb535  vmovaps [rsp+0xE0], xmm15
000074267fbdb53e  sub rsp, 0x40
000074267fbdb542  lea rdi, [rsp]
000074267fbdb546  lea rsi, [rsp+0x10]
000074267fbdb54b  lea rdx, [rsp+0x20]
000074267fbdb550  lea rcx, [rsp+0x30]
000074267fbdb555  mov r8d, 0x00
000074267fbdb55b  lea r9, [r15+0x3A8]
000074267fbdb562  movaps [rdi], xmm6
000074267fbdb565  movaps [rsi], xmm2
000074267fbdb568  movaps [rdx], xmm14
000074267fbdb56c  movaps [rcx], xmm1
000074267fbdb56f  mov rax, 0x56D4E47AEA50
000074267fbdb579  call rax
000074267fbdb57b  movaps xmm6, [rsp]
000074267fbdb57f  add rsp, 0x40
000074267fbdb583  vmovaps xmm0, [rsp]
000074267fbdb588  vmovaps xmm1, [rsp+0x10]
000074267fbdb58e  vmovaps xmm2, [rsp+0x20]
000074267fbdb594  vmovaps xmm3, [rsp+0x30]
000074267fbdb59a  vmovaps xmm4, [rsp+0x40]
000074267fbdb5a0  vmovaps xmm5, [rsp+0x50]
000074267fbdb5a6  vmovaps xmm7, [rsp+0x60]
000074267fbdb5ac  vmovaps xmm8, [rsp+0x70]
000074267fbdb5b2  vmovaps xmm9, [rsp+0x80]
000074267fbdb5bb  vmovaps xmm10, [rsp+0x90]
000074267fbdb5c4  vmovaps xmm11, [rsp+0xA0]
000074267fbdb5cd  vmovaps xmm12, [rsp+0xB0]
000074267fbdb5d6  vmovaps xmm13, [rsp+0xC0]
000074267fbdb5df  vmovaps xmm14, [rsp+0xD0]
000074267fbdb5e8  vmovaps xmm15, [rsp+0xE0]
000074267fbdb5f1  add rsp, 0xF0
000074267fbdb5f8  pop r11
000074267fbdb5fa  pop r10
000074267fbdb5fc  pop r9
000074267fbdb5fe  pop r8
000074267fbdb600  pop rsi
000074267fbdb601  pop rdi
000074267fbdb602  pop rdx
000074267fbdb603  pop rcx
000074267fbdb604  pop rax
000074267fbdb605  add rsp, 0x08
000074267fbdb609  jmp 0x000074267FBDA1C7
000074267fbdb60e  sub rsp, 0x08
000074267fbdb612  push rax
000074267fbdb613  push rcx
000074267fbdb614  push rdx
000074267fbdb615  push rdi
000074267fbdb616  push rsi
000074267fbdb617  push r8
000074267fbdb619  push r9
000074267fbdb61b  push r10
000074267fbdb61d  push r11
000074267fbdb61f  sub rsp, 0xF0
000074267fbdb626  vmovaps [rsp], xmm0
000074267fbdb62b  vmovaps [rsp+0x10], xmm1
000074267fbdb631  vmovaps [rsp+0x20], xmm2
000074267fbdb637  vmovaps [rsp+0x30], xmm3
000074267fbdb63d  vmovaps [rsp+0x40], xmm4
000074267fbdb643  vmovaps [rsp+0x50], xmm5
000074267fbdb649  vmovaps [rsp+0x60], xmm6
000074267fbdb64f  vmovaps [rsp+0x70], xmm7
000074267fbdb655  vmovaps [rsp+0x80], xmm8
000074267fbdb65e  vmovaps [rsp+0x90], xmm9
000074267fbdb667  vmovaps [rsp+0xA0], xmm10
000074267fbdb670  vmovaps [rsp+0xB0], xmm11
000074267fbdb679  vmovaps [rsp+0xC0], xmm12
000074267fbdb682  vmovaps [rsp+0xD0], xmm14
000074267fbdb68b  vmovaps [rsp+0xE0], xmm15
000074267fbdb694  sub rsp, 0x40
000074267fbdb698  lea rdi, [rsp]
000074267fbdb69c  lea rsi, [rsp+0x10]
000074267fbdb6a1  lea rdx, [rsp+0x20]
000074267fbdb6a6  lea rcx, [rsp+0x30]
000074267fbdb6ab  mov r8d, 0x00
000074267fbdb6b1  lea r9, [r15+0x3A8]
000074267fbdb6b8  movaps [rdi], xmm13
000074267fbdb6bc  movaps [rsi], xmm12
000074267fbdb6c0  movaps [rdx], xmm14
000074267fbdb6c4  movaps [rcx], xmm1
000074267fbdb6c7  mov rax, 0x56D4E47AEA50
000074267fbdb6d1  call rax
000074267fbdb6d3  movaps xmm13, [rsp]
000074267fbdb6d8  add rsp, 0x40
000074267fbdb6dc  vmovaps xmm0, [rsp]
000074267fbdb6e1  vmovaps xmm1, [rsp+0x10]
000074267fbdb6e7  vmovaps xmm2, [rsp+0x20]
000074267fbdb6ed  vmovaps xmm3, [rsp+0x30]
000074267fbdb6f3  vmovaps xmm4, [rsp+0x40]
000074267fbdb6f9  vmovaps xmm5, [rsp+0x50]
000074267fbdb6ff  vmovaps xmm6, [rsp+0x60]
000074267fbdb705  vmovaps xmm7, [rsp+0x70]
000074267fbdb70b  vmovaps xmm8, [rsp+0x80]
000074267fbdb714  vmovaps xmm9, [rsp+0x90]
000074267fbdb71d  vmovaps xmm10, [rsp+0xA0]
000074267fbdb726  vmovaps xmm11, [rsp+0xB0]
000074267fbdb72f  vmovaps xmm12, [rsp+0xC0]
000074267fbdb738  vmovaps xmm14, [rsp+0xD0]
000074267fbdb741  vmovaps xmm15, [rsp+0xE0]
000074267fbdb74a  add rsp, 0xF0
000074267fbdb751  pop r11
000074267fbdb753  pop r10
000074267fbdb755  pop r9
000074267fbdb757  pop r8
000074267fbdb759  pop rsi
000074267fbdb75a  pop rdi
000074267fbdb75b  pop rdx
000074267fbdb75c  pop rcx
000074267fbdb75d  pop rax
000074267fbdb75e  add rsp, 0x08
000074267fbdb762  jmp 0x000074267FBDA1F9
000074267fbdb767  sub rsp, 0x08
000074267fbdb76b  push rax
000074267fbdb76c  push rcx
000074267fbdb76d  push rdx
000074267fbdb76e  push rdi
000074267fbdb76f  push rsi
000074267fbdb770  push r8
000074267fbdb772  push r9
000074267fbdb774  push r10
000074267fbdb776  push r11
000074267fbdb778  sub rsp, 0xF0
000074267fbdb77f  vmovaps [rsp], xmm0
000074267fbdb784  vmovaps [rsp+0x10], xmm1
000074267fbdb78a  vmovaps [rsp+0x20], xmm2
000074267fbdb790  vmovaps [rsp+0x30], xmm3
000074267fbdb796  vmovaps [rsp+0x40], xmm4
000074267fbdb79c  vmovaps [rsp+0x50], xmm5
000074267fbdb7a2  vmovaps [rsp+0x60], xmm6
000074267fbdb7a8  vmovaps [rsp+0x70], xmm7
000074267fbdb7ae  vmovaps [rsp+0x80], xmm8
000074267fbdb7b7  vmovaps [rsp+0x90], xmm9
000074267fbdb7c0  vmovaps [rsp+0xA0], xmm10
000074267fbdb7c9  vmovaps [rsp+0xB0], xmm11
000074267fbdb7d2  vmovaps [rsp+0xC0], xmm13
000074267fbdb7db  vmovaps [rsp+0xD0], xmm14
000074267fbdb7e4  vmovaps [rsp+0xE0], xmm15
000074267fbdb7ed  sub rsp, 0x40
000074267fbdb7f1  lea rdi, [rsp]
000074267fbdb7f5  lea rsi, [rsp+0x10]
000074267fbdb7fa  lea rdx, [rsp+0x20]
000074267fbdb7ff  lea rcx, [rsp+0x30]
000074267fbdb804  mov r8d, 0x00
000074267fbdb80a  lea r9, [r15+0x3A8]
000074267fbdb811  movaps [rdi], xmm12
000074267fbdb815  movaps [rsi], xmm3
000074267fbdb818  movaps [rdx], xmm14
000074267fbdb81c  movaps [rcx], xmm5
000074267fbdb81f  mov rax, 0x56D4E47AEA50
000074267fbdb829  call rax
000074267fbdb82b  movaps xmm12, [rsp]
000074267fbdb830  add rsp, 0x40
000074267fbdb834  vmovaps xmm0, [rsp]
000074267fbdb839  vmovaps xmm1, [rsp+0x10]
000074267fbdb83f  vmovaps xmm2, [rsp+0x20]
000074267fbdb845  vmovaps xmm3, [rsp+0x30]
000074267fbdb84b  vmovaps xmm4, [rsp+0x40]
000074267fbdb851  vmovaps xmm5, [rsp+0x50]
000074267fbdb857  vmovaps xmm6, [rsp+0x60]
000074267fbdb85d  vmovaps xmm7, [rsp+0x70]
000074267fbdb863  vmovaps xmm8, [rsp+0x80]
000074267fbdb86c  vmovaps xmm9, [rsp+0x90]
000074267fbdb875  vmovaps xmm10, [rsp+0xA0]
000074267fbdb87e  vmovaps xmm11, [rsp+0xB0]
000074267fbdb887  vmovaps xmm13, [rsp+0xC0]
000074267fbdb890  vmovaps xmm14, [rsp+0xD0]
000074267fbdb899  vmovaps xmm15, [rsp+0xE0]
000074267fbdb8a2  add rsp, 0xF0
000074267fbdb8a9  pop r11
000074267fbdb8ab  pop r10
000074267fbdb8ad  pop r9
000074267fbdb8af  pop r8
000074267fbdb8b1  pop rsi
000074267fbdb8b2  pop rdi
000074267fbdb8b3  pop rdx
000074267fbdb8b4  pop rcx
000074267fbdb8b5  pop rax
000074267fbdb8b6  add rsp, 0x08
000074267fbdb8ba  jmp 0x000074267FBDA256
000074267fbdb8bf  sub rsp, 0x08
000074267fbdb8c3  push rax
000074267fbdb8c4  push rcx
000074267fbdb8c5  push rdx
000074267fbdb8c6  push rdi
000074267fbdb8c7  push rsi
000074267fbdb8c8  push r8
000074267fbdb8ca  push r9
000074267fbdb8cc  push r10
000074267fbdb8ce  push r11
000074267fbdb8d0  sub rsp, 0xF0
000074267fbdb8d7  vmovaps [rsp], xmm0
000074267fbdb8dc  vmovaps [rsp+0x10], xmm1
000074267fbdb8e2  vmovaps [rsp+0x20], xmm2
000074267fbdb8e8  vmovaps [rsp+0x30], xmm3
000074267fbdb8ee  vmovaps [rsp+0x40], xmm4
000074267fbdb8f4  vmovaps [rsp+0x50], xmm5
000074267fbdb8fa  vmovaps [rsp+0x60], xmm6
000074267fbdb900  vmovaps [rsp+0x70], xmm7
000074267fbdb906  vmovaps [rsp+0x80], xmm8
000074267fbdb90f  vmovaps [rsp+0x90], xmm9
000074267fbdb918  vmovaps [rsp+0xA0], xmm11
000074267fbdb921  vmovaps [rsp+0xB0], xmm12
000074267fbdb92a  vmovaps [rsp+0xC0], xmm13
000074267fbdb933  vmovaps [rsp+0xD0], xmm14
000074267fbdb93c  vmovaps [rsp+0xE0], xmm15
000074267fbdb945  sub rsp, 0x40
000074267fbdb949  lea rdi, [rsp]
000074267fbdb94d  lea rsi, [rsp+0x10]
000074267fbdb952  lea rdx, [rsp+0x20]
000074267fbdb957  lea rcx, [rsp+0x30]
000074267fbdb95c  mov r8d, 0x00
000074267fbdb962  lea r9, [r15+0x3A8]
000074267fbdb969  movaps [rdi], xmm10
000074267fbdb96d  movaps [rsi], xmm9
000074267fbdb971  movaps [rdx], xmm7
000074267fbdb974  movaps [rcx], xmm14
000074267fbdb978  mov rax, 0x56D4E47AEA50
000074267fbdb982  call rax
000074267fbdb984  movaps xmm10, [rsp]
000074267fbdb989  add rsp, 0x40
000074267fbdb98d  vmovaps xmm0, [rsp]
000074267fbdb992  vmovaps xmm1, [rsp+0x10]
000074267fbdb998  vmovaps xmm2, [rsp+0x20]
000074267fbdb99e  vmovaps xmm3, [rsp+0x30]
000074267fbdb9a4  vmovaps xmm4, [rsp+0x40]
000074267fbdb9aa  vmovaps xmm5, [rsp+0x50]
000074267fbdb9b0  vmovaps xmm6, [rsp+0x60]
000074267fbdb9b6  vmovaps xmm7, [rsp+0x70]
000074267fbdb9bc  vmovaps xmm8, [rsp+0x80]
000074267fbdb9c5  vmovaps xmm9, [rsp+0x90]
000074267fbdb9ce  vmovaps xmm11, [rsp+0xA0]
000074267fbdb9d7  vmovaps xmm12, [rsp+0xB0]
000074267fbdb9e0  vmovaps xmm13, [rsp+0xC0]
000074267fbdb9e9  vmovaps xmm14, [rsp+0xD0]
000074267fbdb9f2  vmovaps xmm15, [rsp+0xE0]
000074267fbdb9fb  add rsp, 0xF0
000074267fbdba02  pop r11
000074267fbdba04  pop r10
000074267fbdba06  pop r9
000074267fbdba08  pop r8
000074267fbdba0a  pop rsi
000074267fbdba0b  pop rdi
000074267fbdba0c  pop rdx
000074267fbdba0d  pop rcx
000074267fbdba0e  pop rax
000074267fbdba0f  add rsp, 0x08
000074267fbdba13  jmp 0x000074267FBDA27C
000074267fbdba18  call 0x000074267FA0D4E0
000074267fbdba1d  jmp 0x000074267FBDA289
000074267fbdba22  sub rsp, 0x08
000074267fbdba26  push rax
000074267fbdba27  push rcx
000074267fbdba28  push rdx
000074267fbdba29  push rdi
000074267fbdba2a  push rsi
000074267fbdba2b  push r8
000074267fbdba2d  push r9
000074267fbdba2f  push r10
000074267fbdba31  push r11
000074267fbdba33  sub rsp, 0xF0
000074267fbdba3a  vmovaps [rsp], xmm0
000074267fbdba3f  vmovaps [rsp+0x10], xmm1
000074267fbdba45  vmovaps [rsp+0x20], xmm2
000074267fbdba4b  vmovaps [rsp+0x30], xmm3
000074267fbdba51  vmovaps [rsp+0x40], xmm4
000074267fbdba57  vmovaps [rsp+0x50], xmm6
000074267fbdba5d  vmovaps [rsp+0x60], xmm7
000074267fbdba63  vmovaps [rsp+0x70], xmm8
000074267fbdba69  vmovaps [rsp+0x80], xmm9
000074267fbdba72  vmovaps [rsp+0x90], xmm10
000074267fbdba7b  vmovaps [rsp+0xA0], xmm11
000074267fbdba84  vmovaps [rsp+0xB0], xmm12
000074267fbdba8d  vmovaps [rsp+0xC0], xmm13
000074267fbdba96  vmovaps [rsp+0xD0], xmm14
000074267fbdba9f  vmovaps [rsp+0xE0], xmm15
000074267fbdbaa8  sub rsp, 0x40
000074267fbdbaac  lea rdi, [rsp]
000074267fbdbab0  lea rsi, [rsp+0x10]
000074267fbdbab5  lea rdx, [rsp+0x20]
000074267fbdbaba  lea rcx, [rsp+0x30]
000074267fbdbabf  mov r8d, 0x00
000074267fbdbac5  lea r9, [r15+0x3A8]
000074267fbdbacc  movaps [rdi], xmm5
000074267fbdbacf  movaps [rsi], xmm6
000074267fbdbad2  movaps [rdx], xmm7
000074267fbdbad5  movaps [rcx], xmm9
000074267fbdbad9  mov rax, 0x56D4E47AEA50
000074267fbdbae3  call rax
000074267fbdbae5  movaps xmm5, [rsp]
000074267fbdbae9  add rsp, 0x40
000074267fbdbaed  vmovaps xmm0, [rsp]
000074267fbdbaf2  vmovaps xmm1, [rsp+0x10]
000074267fbdbaf8  vmovaps xmm2, [rsp+0x20]
000074267fbdbafe  vmovaps xmm3, [rsp+0x30]
000074267fbdbb04  vmovaps xmm4, [rsp+0x40]
000074267fbdbb0a  vmovaps xmm6, [rsp+0x50]
000074267fbdbb10  vmovaps xmm7, [rsp+0x60]
000074267fbdbb16  vmovaps xmm8, [rsp+0x70]
000074267fbdbb1c  vmovaps xmm9, [rsp+0x80]
000074267fbdbb25  vmovaps xmm10, [rsp+0x90]
000074267fbdbb2e  vmovaps xmm11, [rsp+0xA0]
000074267fbdbb37  vmovaps xmm12, [rsp+0xB0]
000074267fbdbb40  vmovaps xmm13, [rsp+0xC0]
000074267fbdbb49  vmovaps xmm14, [rsp+0xD0]
000074267fbdbb52  vmovaps xmm15, [rsp+0xE0]
000074267fbdbb5b  add rsp, 0xF0
000074267fbdbb62  pop r11
000074267fbdbb64  pop r10
000074267fbdbb66  pop r9
000074267fbdbb68  pop r8
000074267fbdbb6a  pop rsi
000074267fbdbb6b  pop rdi
000074267fbdbb6c  pop rdx
000074267fbdbb6d  pop rcx
000074267fbdbb6e  pop rax
000074267fbdbb6f  add rsp, 0x08
000074267fbdbb73  jmp 0x000074267FBDA2BB
000074267fbdbb78  sub rsp, 0x08
000074267fbdbb7c  push rax
000074267fbdbb7d  push rcx
000074267fbdbb7e  push rdx
000074267fbdbb7f  push rdi
000074267fbdbb80  push rsi
000074267fbdbb81  push r8
000074267fbdbb83  push r9
000074267fbdbb85  push r10
000074267fbdbb87  push r11
000074267fbdbb89  sub rsp, 0xF0
000074267fbdbb90  vmovaps [rsp], xmm0
000074267fbdbb95  vmovaps [rsp+0x10], xmm1
000074267fbdbb9b  vmovaps [rsp+0x20], xmm2
000074267fbdbba1  vmovaps [rsp+0x30], xmm3
000074267fbdbba7  vmovaps [rsp+0x40], xmm4
000074267fbdbbad  vmovaps [rsp+0x50], xmm5
000074267fbdbbb3  vmovaps [rsp+0x60], xmm6
000074267fbdbbb9  vmovaps [rsp+0x70], xmm8
000074267fbdbbbf  vmovaps [rsp+0x80], xmm9
000074267fbdbbc8  vmovaps [rsp+0x90], xmm10
000074267fbdbbd1  vmovaps [rsp+0xA0], xmm11
000074267fbdbbda  vmovaps [rsp+0xB0], xmm12
000074267fbdbbe3  vmovaps [rsp+0xC0], xmm13
000074267fbdbbec  vmovaps [rsp+0xD0], xmm14
000074267fbdbbf5  vmovaps [rsp+0xE0], xmm15
000074267fbdbbfe  sub rsp, 0x40
000074267fbdbc02  lea rdi, [rsp]
000074267fbdbc06  lea rsi, [rsp+0x10]
000074267fbdbc0b  lea rdx, [rsp+0x20]
000074267fbdbc10  lea rcx, [rsp+0x30]
000074267fbdbc15  mov r8d, 0x00
000074267fbdbc1b  lea r9, [r15+0x3A8]
000074267fbdbc22  movaps [rdi], xmm7
000074267fbdbc25  movaps [rsi], xmm13
000074267fbdbc29  movaps [rdx], xmm1
000074267fbdbc2c  movaps [rcx], xmm9
000074267fbdbc30  mov rax, 0x56D4E47AEA50
000074267fbdbc3a  call rax
000074267fbdbc3c  movaps xmm7, [rsp]
000074267fbdbc40  add rsp, 0x40
000074267fbdbc44  vmovaps xmm0, [rsp]
000074267fbdbc49  vmovaps xmm1, [rsp+0x10]
000074267fbdbc4f  vmovaps xmm2, [rsp+0x20]
000074267fbdbc55  vmovaps xmm3, [rsp+0x30]
000074267fbdbc5b  vmovaps xmm4, [rsp+0x40]
000074267fbdbc61  vmovaps xmm5, [rsp+0x50]
000074267fbdbc67  vmovaps xmm6, [rsp+0x60]
000074267fbdbc6d  vmovaps xmm8, [rsp+0x70]
000074267fbdbc73  vmovaps xmm9, [rsp+0x80]
000074267fbdbc7c  vmovaps xmm10, [rsp+0x90]
000074267fbdbc85  vmovaps xmm11, [rsp+0xA0]
000074267fbdbc8e  vmovaps xmm12, [rsp+0xB0]
000074267fbdbc97  vmovaps xmm13, [rsp+0xC0]
000074267fbdbca0  vmovaps xmm14, [rsp+0xD0]
000074267fbdbca9  vmovaps xmm15, [rsp+0xE0]
000074267fbdbcb2  add rsp, 0xF0
000074267fbdbcb9  pop r11
000074267fbdbcbb  pop r10
000074267fbdbcbd  pop r9
000074267fbdbcbf  pop r8
000074267fbdbcc1  pop rsi
000074267fbdbcc2  pop rdi
000074267fbdbcc3  pop rdx
000074267fbdbcc4  pop rcx
000074267fbdbcc5  pop rax
000074267fbdbcc6  add rsp, 0x08
000074267fbdbcca  jmp 0x000074267FBDA2E0
000074267fbdbccf  call 0x000074267FA0C260
000074267fbdbcd4  jmp 0x000074267FBDA303
000074267fbdbcd9  call 0x000074267FA07890
000074267fbdbcde  jmp 0x000074267FBDA30D
000074267fbdbce3  sub rsp, 0x08
000074267fbdbce7  push rax
000074267fbdbce8  push rcx
000074267fbdbce9  push rdx
000074267fbdbcea  push rdi
000074267fbdbceb  push rsi
000074267fbdbcec  push r8
000074267fbdbcee  push r9
000074267fbdbcf0  push r10
000074267fbdbcf2  push r11
000074267fbdbcf4  sub rsp, 0xF0
000074267fbdbcfb  vmovaps [rsp], xmm0
000074267fbdbd00  vmovaps [rsp+0x10], xmm1
000074267fbdbd06  vmovaps [rsp+0x20], xmm3
000074267fbdbd0c  vmovaps [rsp+0x30], xmm4
000074267fbdbd12  vmovaps [rsp+0x40], xmm5
000074267fbdbd18  vmovaps [rsp+0x50], xmm6
000074267fbdbd1e  vmovaps [rsp+0x60], xmm7
000074267fbdbd24  vmovaps [rsp+0x70], xmm8
000074267fbdbd2a  vmovaps [rsp+0x80], xmm9
000074267fbdbd33  vmovaps [rsp+0x90], xmm10
000074267fbdbd3c  vmovaps [rsp+0xA0], xmm11
000074267fbdbd45  vmovaps [rsp+0xB0], xmm12
000074267fbdbd4e  vmovaps [rsp+0xC0], xmm13
000074267fbdbd57  vmovaps [rsp+0xD0], xmm14
000074267fbdbd60  vmovaps [rsp+0xE0], xmm15
000074267fbdbd69  sub rsp, 0x40
000074267fbdbd6d  lea rdi, [rsp]
000074267fbdbd71  lea rsi, [rsp+0x10]
000074267fbdbd76  lea rdx, [rsp+0x20]
000074267fbdbd7b  lea rcx, [rsp+0x30]
000074267fbdbd80  mov r8d, 0x00
000074267fbdbd86  lea r9, [r15+0x3A8]
000074267fbdbd8d  movaps [rdi], xmm2
000074267fbdbd90  movaps [rsi], xmm12
000074267fbdbd94  movaps [rdx], xmm6
000074267fbdbd97  movaps [rcx], xmm3
000074267fbdbd9a  mov rax, 0x56D4E47AEA50
000074267fbdbda4  call rax
000074267fbdbda6  movaps xmm2, [rsp]
000074267fbdbdaa  add rsp, 0x40
000074267fbdbdae  vmovaps xmm0, [rsp]
000074267fbdbdb3  vmovaps xmm1, [rsp+0x10]
000074267fbdbdb9  vmovaps xmm3, [rsp+0x20]
000074267fbdbdbf  vmovaps xmm4, [rsp+0x30]
000074267fbdbdc5  vmovaps xmm5, [rsp+0x40]
000074267fbdbdcb  vmovaps xmm6, [rsp+0x50]
000074267fbdbdd1  vmovaps xmm7, [rsp+0x60]
000074267fbdbdd7  vmovaps xmm8, [rsp+0x70]
000074267fbdbddd  vmovaps xmm9, [rsp+0x80]
000074267fbdbde6  vmovaps xmm10, [rsp+0x90]
000074267fbdbdef  vmovaps xmm11, [rsp+0xA0]
000074267fbdbdf8  vmovaps xmm12, [rsp+0xB0]
000074267fbdbe01  vmovaps xmm13, [rsp+0xC0]
000074267fbdbe0a  vmovaps xmm14, [rsp+0xD0]
000074267fbdbe13  vmovaps xmm15, [rsp+0xE0]
000074267fbdbe1c  add rsp, 0xF0
000074267fbdbe23  pop r11
000074267fbdbe25  pop r10
000074267fbdbe27  pop r9
000074267fbdbe29  pop r8
000074267fbdbe2b  pop rsi
000074267fbdbe2c  pop rdi
000074267fbdbe2d  pop rdx
000074267fbdbe2e  pop rcx
000074267fbdbe2f  pop rax
000074267fbdbe30  add rsp, 0x08
000074267fbdbe34  jmp 0x000074267FBDA353
000074267fbdbe39  sub rsp, 0x08
000074267fbdbe3d  push rax
000074267fbdbe3e  push rcx
000074267fbdbe3f  push rdx
000074267fbdbe40  push rdi
000074267fbdbe41  push rsi
000074267fbdbe42  push r8
000074267fbdbe44  push r9
000074267fbdbe46  push r10
000074267fbdbe48  push r11
000074267fbdbe4a  sub rsp, 0xF0
000074267fbdbe51  vmovaps [rsp], xmm0
000074267fbdbe56  vmovaps [rsp+0x10], xmm1
000074267fbdbe5c  vmovaps [rsp+0x20], xmm2
000074267fbdbe62  vmovaps [rsp+0x30], xmm3
000074267fbdbe68  vmovaps [rsp+0x40], xmm4
000074267fbdbe6e  vmovaps [rsp+0x50], xmm5
000074267fbdbe74  vmovaps [rsp+0x60], xmm7
000074267fbdbe7a  vmovaps [rsp+0x70], xmm8
000074267fbdbe80  vmovaps [rsp+0x80], xmm9
000074267fbdbe89  vmovaps [rsp+0x90], xmm10
000074267fbdbe92  vmovaps [rsp+0xA0], xmm11
000074267fbdbe9b  vmovaps [rsp+0xB0], xmm12
000074267fbdbea4  vmovaps [rsp+0xC0], xmm13
000074267fbdbead  vmovaps [rsp+0xD0], xmm14
000074267fbdbeb6  vmovaps [rsp+0xE0], xmm15
000074267fbdbebf  sub rsp, 0x40
000074267fbdbec3  lea rdi, [rsp]
000074267fbdbec7  lea rsi, [rsp+0x10]
000074267fbdbecc  lea rdx, [rsp+0x20]
000074267fbdbed1  lea rcx, [rsp+0x30]
000074267fbdbed6  mov r8d, 0x00
000074267fbdbedc  lea r9, [r15+0x3A8]
000074267fbdbee3  movaps [rdi], xmm6
000074267fbdbee6  movaps [rsi], xmm10
000074267fbdbeea  movaps [rdx], xmm12
000074267fbdbeee  movaps [rcx], xmm1
000074267fbdbef1  mov rax, 0x56D4E47AEA50
000074267fbdbefb  call rax
000074267fbdbefd  movaps xmm6, [rsp]
000074267fbdbf01  add rsp, 0x40
000074267fbdbf05  vmovaps xmm0, [rsp]
000074267fbdbf0a  vmovaps xmm1, [rsp+0x10]
000074267fbdbf10  vmovaps xmm2, [rsp+0x20]
000074267fbdbf16  vmovaps xmm3, [rsp+0x30]
000074267fbdbf1c  vmovaps xmm4, [rsp+0x40]
000074267fbdbf22  vmovaps xmm5, [rsp+0x50]
000074267fbdbf28  vmovaps xmm7, [rsp+0x60]
000074267fbdbf2e  vmovaps xmm8, [rsp+0x70]
000074267fbdbf34  vmovaps xmm9, [rsp+0x80]
000074267fbdbf3d  vmovaps xmm10, [rsp+0x90]
000074267fbdbf46  vmovaps xmm11, [rsp+0xA0]
000074267fbdbf4f  vmovaps xmm12, [rsp+0xB0]
000074267fbdbf58  vmovaps xmm13, [rsp+0xC0]
000074267fbdbf61  vmovaps xmm14, [rsp+0xD0]
000074267fbdbf6a  vmovaps xmm15, [rsp+0xE0]
000074267fbdbf73  add rsp, 0xF0
000074267fbdbf7a  pop r11
000074267fbdbf7c  pop r10
000074267fbdbf7e  pop r9
000074267fbdbf80  pop r8
000074267fbdbf82  pop rsi
000074267fbdbf83  pop rdi
000074267fbdbf84  pop rdx
000074267fbdbf85  pop rcx
000074267fbdbf86  pop rax
000074267fbdbf87  add rsp, 0x08
000074267fbdbf8b  jmp 0x000074267FBDA381
000074267fbdbf90  sub rsp, 0x08
000074267fbdbf94  push rax
000074267fbdbf95  push rcx
000074267fbdbf96  push rdx
000074267fbdbf97  push rdi
000074267fbdbf98  push rsi
000074267fbdbf99  push r8
000074267fbdbf9b  push r9
000074267fbdbf9d  push r10
000074267fbdbf9f  push r11
000074267fbdbfa1  sub rsp, 0xF0
000074267fbdbfa8  vmovaps [rsp], xmm0
000074267fbdbfad  vmovaps [rsp+0x10], xmm1
000074267fbdbfb3  vmovaps [rsp+0x20], xmm2
000074267fbdbfb9  vmovaps [rsp+0x30], xmm3
000074267fbdbfbf  vmovaps [rsp+0x40], xmm4
000074267fbdbfc5  vmovaps [rsp+0x50], xmm5
000074267fbdbfcb  vmovaps [rsp+0x60], xmm6
000074267fbdbfd1  vmovaps [rsp+0x70], xmm7
000074267fbdbfd7  vmovaps [rsp+0x80], xmm8
000074267fbdbfe0  vmovaps [rsp+0x90], xmm9
000074267fbdbfe9  vmovaps [rsp+0xA0], xmm11
000074267fbdbff2  vmovaps [rsp+0xB0], xmm12
000074267fbdbffb  vmovaps [rsp+0xC0], xmm13
000074267fbdc004  vmovaps [rsp+0xD0], xmm14
000074267fbdc00d  vmovaps [rsp+0xE0], xmm15
000074267fbdc016  sub rsp, 0x40
000074267fbdc01a  lea rdi, [rsp]
000074267fbdc01e  lea rsi, [rsp+0x10]
000074267fbdc023  lea rdx, [rsp+0x20]
000074267fbdc028  lea rcx, [rsp+0x30]
000074267fbdc02d  mov r8d, 0x00
000074267fbdc033  lea r9, [r15+0x3A8]
000074267fbdc03a  movaps [rdi], xmm10
000074267fbdc03e  movaps [rsi], xmm5
000074267fbdc041  movaps [rdx], xmm12
000074267fbdc045  movaps [rcx], xmm1
000074267fbdc048  mov rax, 0x56D4E47AEA50
000074267fbdc052  call rax
000074267fbdc054  movaps xmm10, [rsp]
000074267fbdc059  add rsp, 0x40
000074267fbdc05d  vmovaps xmm0, [rsp]
000074267fbdc062  vmovaps xmm1, [rsp+0x10]
000074267fbdc068  vmovaps xmm2, [rsp+0x20]
000074267fbdc06e  vmovaps xmm3, [rsp+0x30]
000074267fbdc074  vmovaps xmm4, [rsp+0x40]
000074267fbdc07a  vmovaps xmm5, [rsp+0x50]
000074267fbdc080  vmovaps xmm6, [rsp+0x60]
000074267fbdc086  vmovaps xmm7, [rsp+0x70]
000074267fbdc08c  vmovaps xmm8, [rsp+0x80]
000074267fbdc095  vmovaps xmm9, [rsp+0x90]
000074267fbdc09e  vmovaps xmm11, [rsp+0xA0]
000074267fbdc0a7  vmovaps xmm12, [rsp+0xB0]
000074267fbdc0b0  vmovaps xmm13, [rsp+0xC0]
000074267fbdc0b9  vmovaps xmm14, [rsp+0xD0]
000074267fbdc0c2  vmovaps xmm15, [rsp+0xE0]
000074267fbdc0cb  add rsp, 0xF0
000074267fbdc0d2  pop r11
000074267fbdc0d4  pop r10
000074267fbdc0d6  pop r9
000074267fbdc0d8  pop r8
000074267fbdc0da  pop rsi
000074267fbdc0db  pop rdi
000074267fbdc0dc  pop rdx
000074267fbdc0dd  pop rcx
000074267fbdc0de  pop rax
000074267fbdc0df  add rsp, 0x08
000074267fbdc0e3  jmp 0x000074267FBDA3B0
000074267fbdc0e8  sub rsp, 0x08
000074267fbdc0ec  push rax
000074267fbdc0ed  push rcx
000074267fbdc0ee  push rdx
000074267fbdc0ef  push rdi
000074267fbdc0f0  push rsi
000074267fbdc0f1  push r8
000074267fbdc0f3  push r9
000074267fbdc0f5  push r10
000074267fbdc0f7  push r11
000074267fbdc0f9  sub rsp, 0xF0
000074267fbdc100  vmovaps [rsp], xmm0
000074267fbdc105  vmovaps [rsp+0x10], xmm1
000074267fbdc10b  vmovaps [rsp+0x20], xmm2
000074267fbdc111  vmovaps [rsp+0x30], xmm3
000074267fbdc117  vmovaps [rsp+0x40], xmm4
000074267fbdc11d  vmovaps [rsp+0x50], xmm5
000074267fbdc123  vmovaps [rsp+0x60], xmm6
000074267fbdc129  vmovaps [rsp+0x70], xmm7
000074267fbdc12f  vmovaps [rsp+0x80], xmm8
000074267fbdc138  vmovaps [rsp+0x90], xmm9
000074267fbdc141  vmovaps [rsp+0xA0], xmm10
000074267fbdc14a  vmovaps [rsp+0xB0], xmm11
000074267fbdc153  vmovaps [rsp+0xC0], xmm13
000074267fbdc15c  vmovaps [rsp+0xD0], xmm14
000074267fbdc165  vmovaps [rsp+0xE0], xmm15
000074267fbdc16e  sub rsp, 0x40
000074267fbdc172  lea rdi, [rsp]
000074267fbdc176  lea rsi, [rsp+0x10]
000074267fbdc17b  lea rdx, [rsp+0x20]
000074267fbdc180  lea rcx, [rsp+0x30]
000074267fbdc185  mov r8d, 0x00
000074267fbdc18b  lea r9, [r15+0x3A8]
000074267fbdc192  movaps [rdi], xmm12
000074267fbdc196  movaps [rsi], xmm7
000074267fbdc199  movaps [rdx], xmm15
000074267fbdc19d  movaps [rcx], xmm1
000074267fbdc1a0  mov rax, 0x56D4E47AEA50
000074267fbdc1aa  call rax
000074267fbdc1ac  movaps xmm12, [rsp]
000074267fbdc1b1  add rsp, 0x40
000074267fbdc1b5  vmovaps xmm0, [rsp]
000074267fbdc1ba  vmovaps xmm1, [rsp+0x10]
000074267fbdc1c0  vmovaps xmm2, [rsp+0x20]
000074267fbdc1c6  vmovaps xmm3, [rsp+0x30]
000074267fbdc1cc  vmovaps xmm4, [rsp+0x40]
000074267fbdc1d2  vmovaps xmm5, [rsp+0x50]
000074267fbdc1d8  vmovaps xmm6, [rsp+0x60]
000074267fbdc1de  vmovaps xmm7, [rsp+0x70]
000074267fbdc1e4  vmovaps xmm8, [rsp+0x80]
000074267fbdc1ed  vmovaps xmm9, [rsp+0x90]
000074267fbdc1f6  vmovaps xmm10, [rsp+0xA0]
000074267fbdc1ff  vmovaps xmm11, [rsp+0xB0]
000074267fbdc208  vmovaps xmm13, [rsp+0xC0]
000074267fbdc211  vmovaps xmm14, [rsp+0xD0]
000074267fbdc21a  vmovaps xmm15, [rsp+0xE0]
000074267fbdc223  add rsp, 0xF0
000074267fbdc22a  pop r11
000074267fbdc22c  pop r10
000074267fbdc22e  pop r9
000074267fbdc230  pop r8
000074267fbdc232  pop rsi
000074267fbdc233  pop rdi
000074267fbdc234  pop rdx
000074267fbdc235  pop rcx
000074267fbdc236  pop rax
000074267fbdc237  add rsp, 0x08
000074267fbdc23b  jmp 0x000074267FBDA3D9
000074267fbdc240  call 0x000074267F9FF430
000074267fbdc245  jmp 0x000074267FBDA3E3
000074267fbdc24a  call 0x000074267FA0E760
000074267fbdc24f  jmp 0x000074267FBDA3ED
000074267fbdc254  sub rsp, 0x08
000074267fbdc258  push rax
000074267fbdc259  push rcx
000074267fbdc25a  push rdx
000074267fbdc25b  push rdi
000074267fbdc25c  push rsi
000074267fbdc25d  push r8
000074267fbdc25f  push r9
000074267fbdc261  push r10
000074267fbdc263  push r11
000074267fbdc265  sub rsp, 0xF0
000074267fbdc26c  vmovaps [rsp], xmm0
000074267fbdc271  vmovaps [rsp+0x10], xmm1
000074267fbdc277  vmovaps [rsp+0x20], xmm2
000074267fbdc27d  vmovaps [rsp+0x30], xmm3
000074267fbdc283  vmovaps [rsp+0x40], xmm4
000074267fbdc289  vmovaps [rsp+0x50], xmm5
000074267fbdc28f  vmovaps [rsp+0x60], xmm6
000074267fbdc295  vmovaps [rsp+0x70], xmm8
000074267fbdc29b  vmovaps [rsp+0x80], xmm9
000074267fbdc2a4  vmovaps [rsp+0x90], xmm10
000074267fbdc2ad  vmovaps [rsp+0xA0], xmm11
000074267fbdc2b6  vmovaps [rsp+0xB0], xmm12
000074267fbdc2bf  vmovaps [rsp+0xC0], xmm13
000074267fbdc2c8  vmovaps [rsp+0xD0], xmm14
000074267fbdc2d1  vmovaps [rsp+0xE0], xmm15
000074267fbdc2da  sub rsp, 0x40
000074267fbdc2de  lea rdi, [rsp]
000074267fbdc2e2  lea rsi, [rsp+0x10]
000074267fbdc2e7  lea rdx, [rsp+0x20]
000074267fbdc2ec  lea rcx, [rsp+0x30]
000074267fbdc2f1  mov r8d, 0x00
000074267fbdc2f7  lea r9, [r15+0x3A8]
000074267fbdc2fe  movaps [rdi], xmm7
000074267fbdc301  movaps [rsi], xmm2
000074267fbdc304  movaps [rdx], xmm9
000074267fbdc308  movaps [rcx], xmm11
000074267fbdc30c  mov rax, 0x56D4E47AEA50
000074267fbdc316  call rax
000074267fbdc318  movaps xmm7, [rsp]
000074267fbdc31c  add rsp, 0x40
000074267fbdc320  vmovaps xmm0, [rsp]
000074267fbdc325  vmovaps xmm1, [rsp+0x10]
000074267fbdc32b  vmovaps xmm2, [rsp+0x20]
000074267fbdc331  vmovaps xmm3, [rsp+0x30]
000074267fbdc337  vmovaps xmm4, [rsp+0x40]
000074267fbdc33d  vmovaps xmm5, [rsp+0x50]
000074267fbdc343  vmovaps xmm6, [rsp+0x60]
000074267fbdc349  vmovaps xmm8, [rsp+0x70]
000074267fbdc34f  vmovaps xmm9, [rsp+0x80]
000074267fbdc358  vmovaps xmm10, [rsp+0x90]
000074267fbdc361  vmovaps xmm11, [rsp+0xA0]
000074267fbdc36a  vmovaps xmm12, [rsp+0xB0]
000074267fbdc373  vmovaps xmm13, [rsp+0xC0]
000074267fbdc37c  vmovaps xmm14, [rsp+0xD0]
000074267fbdc385  vmovaps xmm15, [rsp+0xE0]
000074267fbdc38e  add rsp, 0xF0
000074267fbdc395  pop r11
000074267fbdc397  pop r10
000074267fbdc399  pop r9
000074267fbdc39b  pop r8
000074267fbdc39d  pop rsi
000074267fbdc39e  pop rdi
000074267fbdc39f  pop rdx
000074267fbdc3a0  pop rcx
000074267fbdc3a1  pop rax
000074267fbdc3a2  add rsp, 0x08
000074267fbdc3a6  jmp 0x000074267FBDA421
000074267fbdc3ab  sub rsp, 0x08
000074267fbdc3af  push rax
000074267fbdc3b0  push rcx
000074267fbdc3b1  push rdx
000074267fbdc3b2  push rdi
000074267fbdc3b3  push rsi
000074267fbdc3b4  push r8
000074267fbdc3b6  push r9
000074267fbdc3b8  push r10
000074267fbdc3ba  push r11
000074267fbdc3bc  sub rsp, 0xF0
000074267fbdc3c3  vmovaps [rsp], xmm0
000074267fbdc3c8  vmovaps [rsp+0x10], xmm1
000074267fbdc3ce  vmovaps [rsp+0x20], xmm2
000074267fbdc3d4  vmovaps [rsp+0x30], xmm3
000074267fbdc3da  vmovaps [rsp+0x40], xmm4
000074267fbdc3e0  vmovaps [rsp+0x50], xmm5
000074267fbdc3e6  vmovaps [rsp+0x60], xmm6
000074267fbdc3ec  vmovaps [rsp+0x70], xmm7
000074267fbdc3f2  vmovaps [rsp+0x80], xmm8
000074267fbdc3fb  vmovaps [rsp+0x90], xmm10
000074267fbdc404  vmovaps [rsp+0xA0], xmm11
000074267fbdc40d  vmovaps [rsp+0xB0], xmm12
000074267fbdc416  vmovaps [rsp+0xC0], xmm13
000074267fbdc41f  vmovaps [rsp+0xD0], xmm14
000074267fbdc428  vmovaps [rsp+0xE0], xmm15
000074267fbdc431  sub rsp, 0x40
000074267fbdc435  lea rdi, [rsp]
000074267fbdc439  lea rsi, [rsp+0x10]
000074267fbdc43e  lea rdx, [rsp+0x20]
000074267fbdc443  lea rcx, [rsp+0x30]
000074267fbdc448  mov r8d, 0x00
000074267fbdc44e  lea r9, [r15+0x3A8]
000074267fbdc455  movaps [rdi], xmm9
000074267fbdc459  movaps [rsi], xmm6
000074267fbdc45c  movaps [rdx], xmm1
000074267fbdc45f  movaps [rcx], xmm11
000074267fbdc463  mov rax, 0x56D4E47AEA50
000074267fbdc46d  call rax
000074267fbdc46f  movaps xmm9, [rsp]
000074267fbdc474  add rsp, 0x40
000074267fbdc478  vmovaps xmm0, [rsp]
000074267fbdc47d  vmovaps xmm1, [rsp+0x10]
000074267fbdc483  vmovaps xmm2, [rsp+0x20]
000074267fbdc489  vmovaps xmm3, [rsp+0x30]
000074267fbdc48f  vmovaps xmm4, [rsp+0x40]
000074267fbdc495  vmovaps xmm5, [rsp+0x50]
000074267fbdc49b  vmovaps xmm6, [rsp+0x60]
000074267fbdc4a1  vmovaps xmm7, [rsp+0x70]
000074267fbdc4a7  vmovaps xmm8, [rsp+0x80]
000074267fbdc4b0  vmovaps xmm10, [rsp+0x90]
000074267fbdc4b9  vmovaps xmm11, [rsp+0xA0]
000074267fbdc4c2  vmovaps xmm12, [rsp+0xB0]
000074267fbdc4cb  vmovaps xmm13, [rsp+0xC0]
000074267fbdc4d4  vmovaps xmm14, [rsp+0xD0]
000074267fbdc4dd  vmovaps xmm15, [rsp+0xE0]
000074267fbdc4e6  add rsp, 0xF0
000074267fbdc4ed  pop r11
000074267fbdc4ef  pop r10
000074267fbdc4f1  pop r9
000074267fbdc4f3  pop r8
000074267fbdc4f5  pop rsi
000074267fbdc4f6  pop rdi
000074267fbdc4f7  pop rdx
000074267fbdc4f8  pop rcx
000074267fbdc4f9  pop rax
000074267fbdc4fa  add rsp, 0x08
000074267fbdc4fe  jmp 0x000074267FBDA447
000074267fbdc503  sub rsp, 0x08
000074267fbdc507  push rax
000074267fbdc508  push rcx
000074267fbdc509  push rdx
000074267fbdc50a  push rdi
000074267fbdc50b  push rsi
000074267fbdc50c  push r8
000074267fbdc50e  push r9
000074267fbdc510  push r10
000074267fbdc512  push r11
000074267fbdc514  sub rsp, 0xF0
000074267fbdc51b  vmovaps [rsp], xmm0
000074267fbdc520  vmovaps [rsp+0x10], xmm1
000074267fbdc526  vmovaps [rsp+0x20], xmm2
000074267fbdc52c  vmovaps [rsp+0x30], xmm3
000074267fbdc532  vmovaps [rsp+0x40], xmm4
000074267fbdc538  vmovaps [rsp+0x50], xmm5
000074267fbdc53e  vmovaps [rsp+0x60], xmm6
000074267fbdc544  vmovaps [rsp+0x70], xmm7
000074267fbdc54a  vmovaps [rsp+0x80], xmm8
000074267fbdc553  vmovaps [rsp+0x90], xmm9
000074267fbdc55c  vmovaps [rsp+0xA0], xmm10
000074267fbdc565  vmovaps [rsp+0xB0], xmm12
000074267fbdc56e  vmovaps [rsp+0xC0], xmm13
000074267fbdc577  vmovaps [rsp+0xD0], xmm14
000074267fbdc580  vmovaps [rsp+0xE0], xmm15
000074267fbdc589  sub rsp, 0x40
000074267fbdc58d  lea rdi, [rsp]
000074267fbdc591  lea rsi, [rsp+0x10]
000074267fbdc596  lea rdx, [rsp+0x20]
000074267fbdc59b  lea rcx, [rsp+0x30]
000074267fbdc5a0  mov r8d, 0x00
000074267fbdc5a6  lea r9, [r15+0x3A8]
000074267fbdc5ad  movaps [rdi], xmm11
000074267fbdc5b1  movaps [rsi], xmm10
000074267fbdc5b5  movaps [rdx], xmm8
000074267fbdc5b9  movaps [rcx], xmm1
000074267fbdc5bc  mov rax, 0x56D4E47AEA50
000074267fbdc5c6  call rax
000074267fbdc5c8  movaps xmm11, [rsp]
000074267fbdc5cd  add rsp, 0x40
000074267fbdc5d1  vmovaps xmm0, [rsp]
000074267fbdc5d6  vmovaps xmm1, [rsp+0x10]
000074267fbdc5dc  vmovaps xmm2, [rsp+0x20]
000074267fbdc5e2  vmovaps xmm3, [rsp+0x30]
000074267fbdc5e8  vmovaps xmm4, [rsp+0x40]
000074267fbdc5ee  vmovaps xmm5, [rsp+0x50]
000074267fbdc5f4  vmovaps xmm6, [rsp+0x60]
000074267fbdc5fa  vmovaps xmm7, [rsp+0x70]
000074267fbdc600  vmovaps xmm8, [rsp+0x80]
000074267fbdc609  vmovaps xmm9, [rsp+0x90]
000074267fbdc612  vmovaps xmm10, [rsp+0xA0]
000074267fbdc61b  vmovaps xmm12, [rsp+0xB0]
000074267fbdc624  vmovaps xmm13, [rsp+0xC0]
000074267fbdc62d  vmovaps xmm14, [rsp+0xD0]
000074267fbdc636  vmovaps xmm15, [rsp+0xE0]
000074267fbdc63f  add rsp, 0xF0
000074267fbdc646  pop r11
000074267fbdc648  pop r10
000074267fbdc64a  pop r9
000074267fbdc64c  pop r8
000074267fbdc64e  pop rsi
000074267fbdc64f  pop rdi
000074267fbdc650  pop rdx
000074267fbdc651  pop rcx
000074267fbdc652  pop rax
000074267fbdc653  add rsp, 0x08
000074267fbdc657  jmp 0x000074267FBDA46D
000074267fbdc65c  sub rsp, 0x08
000074267fbdc660  push rax
000074267fbdc661  push rcx
000074267fbdc662  push rdx
000074267fbdc663  push rdi
000074267fbdc664  push rsi
000074267fbdc665  push r8
000074267fbdc667  push r9
000074267fbdc669  push r10
000074267fbdc66b  push r11
000074267fbdc66d  sub rsp, 0xF0
000074267fbdc674  vmovaps [rsp], xmm0
000074267fbdc679  vmovaps [rsp+0x10], xmm1
000074267fbdc67f  vmovaps [rsp+0x20], xmm2
000074267fbdc685  vmovaps [rsp+0x30], xmm3
000074267fbdc68b  vmovaps [rsp+0x40], xmm4
000074267fbdc691  vmovaps [rsp+0x50], xmm5
000074267fbdc697  vmovaps [rsp+0x60], xmm6
000074267fbdc69d  vmovaps [rsp+0x70], xmm7
000074267fbdc6a3  vmovaps [rsp+0x80], xmm8
000074267fbdc6ac  vmovaps [rsp+0x90], xmm9
000074267fbdc6b5  vmovaps [rsp+0xA0], xmm11
000074267fbdc6be  vmovaps [rsp+0xB0], xmm12
000074267fbdc6c7  vmovaps [rsp+0xC0], xmm13
000074267fbdc6d0  vmovaps [rsp+0xD0], xmm14
000074267fbdc6d9  vmovaps [rsp+0xE0], xmm15
000074267fbdc6e2  sub rsp, 0x40
000074267fbdc6e6  lea rdi, [rsp]
000074267fbdc6ea  lea rsi, [rsp+0x10]
000074267fbdc6ef  lea rdx, [rsp+0x20]
000074267fbdc6f4  lea rcx, [rsp+0x30]
000074267fbdc6f9  mov r8d, 0x00
000074267fbdc6ff  lea r9, [r15+0x3A8]
000074267fbdc706  movaps [rdi], xmm10
000074267fbdc70a  movaps [rsi], xmm12
000074267fbdc70e  movaps [rdx], xmm13
000074267fbdc712  movaps [rcx], xmm1
000074267fbdc715  mov rax, 0x56D4E47AEA50
000074267fbdc71f  call rax
000074267fbdc721  movaps xmm10, [rsp]
000074267fbdc726  add rsp, 0x40
000074267fbdc72a  vmovaps xmm0, [rsp]
000074267fbdc72f  vmovaps xmm1, [rsp+0x10]
000074267fbdc735  vmovaps xmm2, [rsp+0x20]
000074267fbdc73b  vmovaps xmm3, [rsp+0x30]
000074267fbdc741  vmovaps xmm4, [rsp+0x40]
000074267fbdc747  vmovaps xmm5, [rsp+0x50]
000074267fbdc74d  vmovaps xmm6, [rsp+0x60]
000074267fbdc753  vmovaps xmm7, [rsp+0x70]
000074267fbdc759  vmovaps xmm8, [rsp+0x80]
000074267fbdc762  vmovaps xmm9, [rsp+0x90]
000074267fbdc76b  vmovaps xmm11, [rsp+0xA0]
000074267fbdc774  vmovaps xmm12, [rsp+0xB0]
000074267fbdc77d  vmovaps xmm13, [rsp+0xC0]
000074267fbdc786  vmovaps xmm14, [rsp+0xD0]
000074267fbdc78f  vmovaps xmm15, [rsp+0xE0]
000074267fbdc798  add rsp, 0xF0
000074267fbdc79f  pop r11
000074267fbdc7a1  pop r10
000074267fbdc7a3  pop r9
000074267fbdc7a5  pop r8
000074267fbdc7a7  pop rsi
000074267fbdc7a8  pop rdi
000074267fbdc7a9  pop rdx
000074267fbdc7aa  pop rcx
000074267fbdc7ab  pop rax
000074267fbdc7ac  add rsp, 0x08
000074267fbdc7b0  jmp 0x000074267FBDA493
000074267fbdc7b5  call 0x000074267F9FF430
000074267fbdc7ba  jmp 0x000074267FBDA49D
000074267fbdc7bf  call 0x000074267FA0C260
000074267fbdc7c4  jmp 0x000074267FBDA4A7
000074267fbdc7c9  sub rsp, 0x08
000074267fbdc7cd  push rax
000074267fbdc7ce  push rcx
000074267fbdc7cf  push rdx
000074267fbdc7d0  push rdi
000074267fbdc7d1  push rsi
000074267fbdc7d2  push r8
000074267fbdc7d4  push r9
000074267fbdc7d6  push r10
000074267fbdc7d8  push r11
000074267fbdc7da  sub rsp, 0xF0
000074267fbdc7e1  vmovaps [rsp], xmm0
000074267fbdc7e6  vmovaps [rsp+0x10], xmm1
000074267fbdc7ec  vmovaps [rsp+0x20], xmm2
000074267fbdc7f2  vmovaps [rsp+0x30], xmm3
000074267fbdc7f8  vmovaps [rsp+0x40], xmm4
000074267fbdc7fe  vmovaps [rsp+0x50], xmm5
000074267fbdc804  vmovaps [rsp+0x60], xmm6
000074267fbdc80a  vmovaps [rsp+0x70], xmm7
000074267fbdc810  vmovaps [rsp+0x80], xmm9
000074267fbdc819  vmovaps [rsp+0x90], xmm10
000074267fbdc822  vmovaps [rsp+0xA0], xmm11
000074267fbdc82b  vmovaps [rsp+0xB0], xmm12
000074267fbdc834  vmovaps [rsp+0xC0], xmm13
000074267fbdc83d  vmovaps [rsp+0xD0], xmm14
000074267fbdc846  vmovaps [rsp+0xE0], xmm15
000074267fbdc84f  sub rsp, 0x40
000074267fbdc853  lea rdi, [rsp]
000074267fbdc857  lea rsi, [rsp+0x10]
000074267fbdc85c  lea rdx, [rsp+0x20]
000074267fbdc861  lea rcx, [rsp+0x30]
000074267fbdc866  mov r8d, 0x00
000074267fbdc86c  lea r9, [r15+0x3A8]
000074267fbdc873  movaps [rdi], xmm8
000074267fbdc877  movaps [rsi], xmm7
000074267fbdc87a  movaps [rdx], xmm4
000074267fbdc87d  movaps [rcx], xmm12
000074267fbdc881  mov rax, 0x56D4E47AEA50
000074267fbdc88b  call rax
000074267fbdc88d  movaps xmm8, [rsp]
000074267fbdc892  add rsp, 0x40
000074267fbdc896  vmovaps xmm0, [rsp]
000074267fbdc89b  vmovaps xmm1, [rsp+0x10]
000074267fbdc8a1  vmovaps xmm2, [rsp+0x20]
000074267fbdc8a7  vmovaps xmm3, [rsp+0x30]
000074267fbdc8ad  vmovaps xmm4, [rsp+0x40]
000074267fbdc8b3  vmovaps xmm5, [rsp+0x50]
000074267fbdc8b9  vmovaps xmm6, [rsp+0x60]
000074267fbdc8bf  vmovaps xmm7, [rsp+0x70]
000074267fbdc8c5  vmovaps xmm9, [rsp+0x80]
000074267fbdc8ce  vmovaps xmm10, [rsp+0x90]
000074267fbdc8d7  vmovaps xmm11, [rsp+0xA0]
000074267fbdc8e0  vmovaps xmm12, [rsp+0xB0]
000074267fbdc8e9  vmovaps xmm13, [rsp+0xC0]
000074267fbdc8f2  vmovaps xmm14, [rsp+0xD0]
000074267fbdc8fb  vmovaps xmm15, [rsp+0xE0]
000074267fbdc904  add rsp, 0xF0
000074267fbdc90b  pop r11
000074267fbdc90d  pop r10
000074267fbdc90f  pop r9
000074267fbdc911  pop r8
000074267fbdc913  pop rsi
000074267fbdc914  pop rdi
000074267fbdc915  pop rdx
000074267fbdc916  pop rcx
000074267fbdc917  pop rax
000074267fbdc918  add rsp, 0x08
000074267fbdc91c  jmp 0x000074267FBDA4D0
000074267fbdc921  sub rsp, 0x08
000074267fbdc925  push rax
000074267fbdc926  push rcx
000074267fbdc927  push rdx
000074267fbdc928  push rdi
000074267fbdc929  push rsi
000074267fbdc92a  push r8
000074267fbdc92c  push r9
000074267fbdc92e  push r10
000074267fbdc930  push r11
000074267fbdc932  sub rsp, 0xF0
000074267fbdc939  vmovaps [rsp], xmm0
000074267fbdc93e  vmovaps [rsp+0x10], xmm1
000074267fbdc944  vmovaps [rsp+0x20], xmm2
000074267fbdc94a  vmovaps [rsp+0x30], xmm3
000074267fbdc950  vmovaps [rsp+0x40], xmm4
000074267fbdc956  vmovaps [rsp+0x50], xmm5
000074267fbdc95c  vmovaps [rsp+0x60], xmm6
000074267fbdc962  vmovaps [rsp+0x70], xmm8
000074267fbdc968  vmovaps [rsp+0x80], xmm9
000074267fbdc971  vmovaps [rsp+0x90], xmm10
000074267fbdc97a  vmovaps [rsp+0xA0], xmm11
000074267fbdc983  vmovaps [rsp+0xB0], xmm12
000074267fbdc98c  vmovaps [rsp+0xC0], xmm13
000074267fbdc995  vmovaps [rsp+0xD0], xmm14
000074267fbdc99e  vmovaps [rsp+0xE0], xmm15
000074267fbdc9a7  sub rsp, 0x40
000074267fbdc9ab  lea rdi, [rsp]
000074267fbdc9af  lea rsi, [rsp+0x10]
000074267fbdc9b4  lea rdx, [rsp+0x20]
000074267fbdc9b9  lea rcx, [rsp+0x30]
000074267fbdc9be  mov r8d, 0x00
000074267fbdc9c4  lea r9, [r15+0x3A8]
000074267fbdc9cb  movaps [rdi], xmm7
000074267fbdc9ce  movaps [rsi], xmm9
000074267fbdc9d2  movaps [rdx], xmm14
000074267fbdc9d6  movaps [rcx], xmm12
000074267fbdc9da  mov rax, 0x56D4E47AEA50
000074267fbdc9e4  call rax
000074267fbdc9e6  movaps xmm7, [rsp]
000074267fbdc9ea  add rsp, 0x40
000074267fbdc9ee  vmovaps xmm0, [rsp]
000074267fbdc9f3  vmovaps xmm1, [rsp+0x10]
000074267fbdc9f9  vmovaps xmm2, [rsp+0x20]
000074267fbdc9ff  vmovaps xmm3, [rsp+0x30]
000074267fbdca05  vmovaps xmm4, [rsp+0x40]
000074267fbdca0b  vmovaps xmm5, [rsp+0x50]
000074267fbdca11  vmovaps xmm6, [rsp+0x60]
000074267fbdca17  vmovaps xmm8, [rsp+0x70]
000074267fbdca1d  vmovaps xmm9, [rsp+0x80]
000074267fbdca26  vmovaps xmm10, [rsp+0x90]
000074267fbdca2f  vmovaps xmm11, [rsp+0xA0]
000074267fbdca38  vmovaps xmm12, [rsp+0xB0]
000074267fbdca41  vmovaps xmm13, [rsp+0xC0]
000074267fbdca4a  vmovaps xmm14, [rsp+0xD0]
000074267fbdca53  vmovaps xmm15, [rsp+0xE0]
000074267fbdca5c  add rsp, 0xF0
000074267fbdca63  pop r11
000074267fbdca65  pop r10
000074267fbdca67  pop r9
000074267fbdca69  pop r8
000074267fbdca6b  pop rsi
000074267fbdca6c  pop rdi
000074267fbdca6d  pop rdx
000074267fbdca6e  pop rcx
000074267fbdca6f  pop rax
000074267fbdca70  add rsp, 0x08
000074267fbdca74  jmp 0x000074267FBDA4F8
000074267fbdca79  sub rsp, 0x08
000074267fbdca7d  push rax
000074267fbdca7e  push rcx
000074267fbdca7f  push rdx
000074267fbdca80  push rdi
000074267fbdca81  push rsi
000074267fbdca82  push r8
000074267fbdca84  push r9
000074267fbdca86  push r10
000074267fbdca88  push r11
000074267fbdca8a  sub rsp, 0xF0
000074267fbdca91  vmovaps [rsp], xmm0
000074267fbdca96  vmovaps [rsp+0x10], xmm1
000074267fbdca9c  vmovaps [rsp+0x20], xmm2
000074267fbdcaa2  vmovaps [rsp+0x30], xmm3
000074267fbdcaa8  vmovaps [rsp+0x40], xmm4
000074267fbdcaae  vmovaps [rsp+0x50], xmm5
000074267fbdcab4  vmovaps [rsp+0x60], xmm6
000074267fbdcaba  vmovaps [rsp+0x70], xmm7
000074267fbdcac0  vmovaps [rsp+0x80], xmm8
000074267fbdcac9  vmovaps [rsp+0x90], xmm9
000074267fbdcad2  vmovaps [rsp+0xA0], xmm10
000074267fbdcadb  vmovaps [rsp+0xB0], xmm11
000074267fbdcae4  vmovaps [rsp+0xC0], xmm13
000074267fbdcaed  vmovaps [rsp+0xD0], xmm14
000074267fbdcaf6  vmovaps [rsp+0xE0], xmm15
000074267fbdcaff  sub rsp, 0x40
000074267fbdcb03  lea rdi, [rsp]
000074267fbdcb07  lea rsi, [rsp+0x10]
000074267fbdcb0c  lea rdx, [rsp+0x20]
000074267fbdcb11  lea rcx, [rsp+0x30]
000074267fbdcb16  mov r8d, 0x00
000074267fbdcb1c  lea r9, [r15+0x3A8]
000074267fbdcb23  movaps [rdi], xmm12
000074267fbdcb27  movaps [rsi], xmm11
000074267fbdcb2b  movaps [rdx], xmm15
000074267fbdcb2f  movaps [rcx], xmm14
000074267fbdcb33  mov rax, 0x56D4E47AEA50
000074267fbdcb3d  call rax
000074267fbdcb3f  movaps xmm12, [rsp]
000074267fbdcb44  add rsp, 0x40
000074267fbdcb48  vmovaps xmm0, [rsp]
000074267fbdcb4d  vmovaps xmm1, [rsp+0x10]
000074267fbdcb53  vmovaps xmm2, [rsp+0x20]
000074267fbdcb59  vmovaps xmm3, [rsp+0x30]
000074267fbdcb5f  vmovaps xmm4, [rsp+0x40]
000074267fbdcb65  vmovaps xmm5, [rsp+0x50]
000074267fbdcb6b  vmovaps xmm6, [rsp+0x60]
000074267fbdcb71  vmovaps xmm7, [rsp+0x70]
000074267fbdcb77  vmovaps xmm8, [rsp+0x80]
000074267fbdcb80  vmovaps xmm9, [rsp+0x90]
000074267fbdcb89  vmovaps xmm10, [rsp+0xA0]
000074267fbdcb92  vmovaps xmm11, [rsp+0xB0]
000074267fbdcb9b  vmovaps xmm13, [rsp+0xC0]
000074267fbdcba4  vmovaps xmm14, [rsp+0xD0]
000074267fbdcbad  vmovaps xmm15, [rsp+0xE0]
000074267fbdcbb6  add rsp, 0xF0
000074267fbdcbbd  pop r11
000074267fbdcbbf  pop r10
000074267fbdcbc1  pop r9
000074267fbdcbc3  pop r8
000074267fbdcbc5  pop rsi
000074267fbdcbc6  pop rdi
000074267fbdcbc7  pop rdx
000074267fbdcbc8  pop rcx
000074267fbdcbc9  pop rax
000074267fbdcbca  add rsp, 0x08
000074267fbdcbce  jmp 0x000074267FBDA521
000074267fbdcbd3  sub rsp, 0x08
000074267fbdcbd7  push rax
000074267fbdcbd8  push rcx
000074267fbdcbd9  push rdx
000074267fbdcbda  push rdi
000074267fbdcbdb  push rsi
000074267fbdcbdc  push r8
000074267fbdcbde  push r9
000074267fbdcbe0  push r10
000074267fbdcbe2  push r11
000074267fbdcbe4  sub rsp, 0xF0
000074267fbdcbeb  vmovaps [rsp], xmm0
000074267fbdcbf0  vmovaps [rsp+0x10], xmm1
000074267fbdcbf6  vmovaps [rsp+0x20], xmm2
000074267fbdcbfc  vmovaps [rsp+0x30], xmm3
000074267fbdcc02  vmovaps [rsp+0x40], xmm4
000074267fbdcc08  vmovaps [rsp+0x50], xmm5
000074267fbdcc0e  vmovaps [rsp+0x60], xmm6
000074267fbdcc14  vmovaps [rsp+0x70], xmm7
000074267fbdcc1a  vmovaps [rsp+0x80], xmm8
000074267fbdcc23  vmovaps [rsp+0x90], xmm9
000074267fbdcc2c  vmovaps [rsp+0xA0], xmm10
000074267fbdcc35  vmovaps [rsp+0xB0], xmm12
000074267fbdcc3e  vmovaps [rsp+0xC0], xmm13
000074267fbdcc47  vmovaps [rsp+0xD0], xmm14
000074267fbdcc50  vmovaps [rsp+0xE0], xmm15
000074267fbdcc59  sub rsp, 0x40
000074267fbdcc5d  lea rdi, [rsp]
000074267fbdcc61  lea rsi, [rsp+0x10]
000074267fbdcc66  lea rdx, [rsp+0x20]
000074267fbdcc6b  lea rcx, [rsp+0x30]
000074267fbdcc70  mov r8d, 0x00
000074267fbdcc76  lea r9, [r15+0x3A8]
000074267fbdcc7d  movaps [rdi], xmm11
000074267fbdcc81  movaps [rsi], xmm10
000074267fbdcc85  movaps [rdx], xmm13
000074267fbdcc89  movaps [rcx], xmm15
000074267fbdcc8d  mov rax, 0x56D4E47AEA50
000074267fbdcc97  call rax
000074267fbdcc99  movaps xmm11, [rsp]
000074267fbdcc9e  add rsp, 0x40
000074267fbdcca2  vmovaps xmm0, [rsp]
000074267fbdcca7  vmovaps xmm1, [rsp+0x10]
000074267fbdccad  vmovaps xmm2, [rsp+0x20]
000074267fbdccb3  vmovaps xmm3, [rsp+0x30]
000074267fbdccb9  vmovaps xmm4, [rsp+0x40]
000074267fbdccbf  vmovaps xmm5, [rsp+0x50]
000074267fbdccc5  vmovaps xmm6, [rsp+0x60]
000074267fbdcccb  vmovaps xmm7, [rsp+0x70]
000074267fbdccd1  vmovaps xmm8, [rsp+0x80]
000074267fbdccda  vmovaps xmm9, [rsp+0x90]
000074267fbdcce3  vmovaps xmm10, [rsp+0xA0]
000074267fbdccec  vmovaps xmm12, [rsp+0xB0]
000074267fbdccf5  vmovaps xmm13, [rsp+0xC0]
000074267fbdccfe  vmovaps xmm14, [rsp+0xD0]
000074267fbdcd07  vmovaps xmm15, [rsp+0xE0]
000074267fbdcd10  add rsp, 0xF0
000074267fbdcd17  pop r11
000074267fbdcd19  pop r10
000074267fbdcd1b  pop r9
000074267fbdcd1d  pop r8
000074267fbdcd1f  pop rsi
000074267fbdcd20  pop rdi
000074267fbdcd21  pop rdx
000074267fbdcd22  pop rcx
000074267fbdcd23  pop rax
000074267fbdcd24  add rsp, 0x08
000074267fbdcd28  jmp 0x000074267FBDA54A
000074267fbdcd2d  call 0x000074267FA0E760
000074267fbdcd32  jmp 0x000074267FBDA557
000074267fbdcd37  call 0x000074267FA0D4E0
000074267fbdcd3c  jmp 0x000074267FBDA564
000074267fbdcd41  sub rsp, 0x08
000074267fbdcd45  push rax
000074267fbdcd46  push rcx
000074267fbdcd47  push rdx
000074267fbdcd48  push rdi
000074267fbdcd49  push rsi
000074267fbdcd4a  push r8
000074267fbdcd4c  push r9
000074267fbdcd4e  push r10
000074267fbdcd50  push r11
000074267fbdcd52  sub rsp, 0xF0
000074267fbdcd59  vmovaps [rsp], xmm0
000074267fbdcd5e  vmovaps [rsp+0x10], xmm1
000074267fbdcd64  vmovaps [rsp+0x20], xmm2
000074267fbdcd6a  vmovaps [rsp+0x30], xmm3
000074267fbdcd70  vmovaps [rsp+0x40], xmm4
000074267fbdcd76  vmovaps [rsp+0x50], xmm5
000074267fbdcd7c  vmovaps [rsp+0x60], xmm6
000074267fbdcd82  vmovaps [rsp+0x70], xmm7
000074267fbdcd88  vmovaps [rsp+0x80], xmm8
000074267fbdcd91  vmovaps [rsp+0x90], xmm9
000074267fbdcd9a  vmovaps [rsp+0xA0], xmm11
000074267fbdcda3  vmovaps [rsp+0xB0], xmm12
000074267fbdcdac  vmovaps [rsp+0xC0], xmm13
000074267fbdcdb5  vmovaps [rsp+0xD0], xmm14
000074267fbdcdbe  vmovaps [rsp+0xE0], xmm15
000074267fbdcdc7  sub rsp, 0x40
000074267fbdcdcb  lea rdi, [rsp]
000074267fbdcdcf  lea rsi, [rsp+0x10]
000074267fbdcdd4  lea rdx, [rsp+0x20]
000074267fbdcdd9  lea rcx, [rsp+0x30]
000074267fbdcdde  mov r8d, 0x00
000074267fbdcde4  lea r9, [r15+0x3A8]
000074267fbdcdeb  movaps [rdi], xmm10
000074267fbdcdef  movaps [rsi], xmm8
000074267fbdcdf3  movaps [rdx], xmm1
000074267fbdcdf6  movaps [rcx], xmm13
000074267fbdcdfa  mov rax, 0x56D4E47AEA50
000074267fbdce04  call rax
000074267fbdce06  movaps xmm10, [rsp]
000074267fbdce0b  add rsp, 0x40
000074267fbdce0f  vmovaps xmm0, [rsp]
000074267fbdce14  vmovaps xmm1, [rsp+0x10]
000074267fbdce1a  vmovaps xmm2, [rsp+0x20]
000074267fbdce20  vmovaps xmm3, [rsp+0x30]
000074267fbdce26  vmovaps xmm4, [rsp+0x40]
000074267fbdce2c  vmovaps xmm5, [rsp+0x50]
000074267fbdce32  vmovaps xmm6, [rsp+0x60]
000074267fbdce38  vmovaps xmm7, [rsp+0x70]
000074267fbdce3e  vmovaps xmm8, [rsp+0x80]
000074267fbdce47  vmovaps xmm9, [rsp+0x90]
000074267fbdce50  vmovaps xmm11, [rsp+0xA0]
000074267fbdce59  vmovaps xmm12, [rsp+0xB0]
000074267fbdce62  vmovaps xmm13, [rsp+0xC0]
000074267fbdce6b  vmovaps xmm14, [rsp+0xD0]
000074267fbdce74  vmovaps xmm15, [rsp+0xE0]
000074267fbdce7d  add rsp, 0xF0
000074267fbdce84  pop r11
000074267fbdce86  pop r10
000074267fbdce88  pop r9
000074267fbdce8a  pop r8
000074267fbdce8c  pop rsi
000074267fbdce8d  pop rdi
000074267fbdce8e  pop rdx
000074267fbdce8f  pop rcx
000074267fbdce90  pop rax
000074267fbdce91  add rsp, 0x08
000074267fbdce95  jmp 0x000074267FBDA59A
000074267fbdce9a  call 0x000074267F9FF430
000074267fbdce9f  jmp 0x000074267FBDA5AC
000074267fbdcea4  sub rsp, 0x08
000074267fbdcea8  push rax
000074267fbdcea9  push rcx
000074267fbdceaa  push rdx
000074267fbdceab  push rdi
000074267fbdceac  push rsi
000074267fbdcead  push r8
000074267fbdceaf  push r9
000074267fbdceb1  push r10
000074267fbdceb3  push r11
000074267fbdceb5  sub rsp, 0xF0
000074267fbdcebc  vmovaps [rsp], xmm0
000074267fbdcec1  vmovaps [rsp+0x10], xmm1
000074267fbdcec7  vmovaps [rsp+0x20], xmm2
000074267fbdcecd  vmovaps [rsp+0x30], xmm3
000074267fbdced3  vmovaps [rsp+0x40], xmm4
000074267fbdced9  vmovaps [rsp+0x50], xmm5
000074267fbdcedf  vmovaps [rsp+0x60], xmm6
000074267fbdcee5  vmovaps [rsp+0x70], xmm7
000074267fbdceeb  vmovaps [rsp+0x80], xmm8
000074267fbdcef4  vmovaps [rsp+0x90], xmm10
000074267fbdcefd  vmovaps [rsp+0xA0], xmm11
000074267fbdcf06  vmovaps [rsp+0xB0], xmm12
000074267fbdcf0f  vmovaps [rsp+0xC0], xmm13
000074267fbdcf18  vmovaps [rsp+0xD0], xmm14
000074267fbdcf21  vmovaps [rsp+0xE0], xmm15
000074267fbdcf2a  sub rsp, 0x40
000074267fbdcf2e  lea rdi, [rsp]
000074267fbdcf32  lea rsi, [rsp+0x10]
000074267fbdcf37  lea rdx, [rsp+0x20]
000074267fbdcf3c  lea rcx, [rsp+0x30]
000074267fbdcf41  mov r8d, 0x00
000074267fbdcf47  lea r9, [r15+0x3A8]
000074267fbdcf4e  movaps [rdi], xmm9
000074267fbdcf52  movaps [rsi], xmm7
000074267fbdcf55  movaps [rdx], xmm14
000074267fbdcf59  movaps [rcx], xmm13
000074267fbdcf5d  mov rax, 0x56D4E47AEA50
000074267fbdcf67  call rax
000074267fbdcf69  movaps xmm9, [rsp]
000074267fbdcf6e  add rsp, 0x40
000074267fbdcf72  vmovaps xmm0, [rsp]
000074267fbdcf77  vmovaps xmm1, [rsp+0x10]
000074267fbdcf7d  vmovaps xmm2, [rsp+0x20]
000074267fbdcf83  vmovaps xmm3, [rsp+0x30]
000074267fbdcf89  vmovaps xmm4, [rsp+0x40]
000074267fbdcf8f  vmovaps xmm5, [rsp+0x50]
000074267fbdcf95  vmovaps xmm6, [rsp+0x60]
000074267fbdcf9b  vmovaps xmm7, [rsp+0x70]
000074267fbdcfa1  vmovaps xmm8, [rsp+0x80]
000074267fbdcfaa  vmovaps xmm10, [rsp+0x90]
000074267fbdcfb3  vmovaps xmm11, [rsp+0xA0]
000074267fbdcfbc  vmovaps xmm12, [rsp+0xB0]
000074267fbdcfc5  vmovaps xmm13, [rsp+0xC0]
000074267fbdcfce  vmovaps xmm14, [rsp+0xD0]
000074267fbdcfd7  vmovaps xmm15, [rsp+0xE0]
000074267fbdcfe0  add rsp, 0xF0
000074267fbdcfe7  pop r11
000074267fbdcfe9  pop r10
000074267fbdcfeb  pop r9
000074267fbdcfed  pop r8
000074267fbdcfef  pop rsi
000074267fbdcff0  pop rdi
000074267fbdcff1  pop rdx
000074267fbdcff2  pop rcx
000074267fbdcff3  pop rax
000074267fbdcff4  add rsp, 0x08
000074267fbdcff8  jmp 0x000074267FBDA5DA
000074267fbdcffd  sub rsp, 0x08
000074267fbdd001  push rax
000074267fbdd002  push rcx
000074267fbdd003  push rdx
000074267fbdd004  push rdi
000074267fbdd005  push rsi
000074267fbdd006  push r8
000074267fbdd008  push r9
000074267fbdd00a  push r10
000074267fbdd00c  push r11
000074267fbdd00e  sub rsp, 0xF0
000074267fbdd015  vmovaps [rsp], xmm0
000074267fbdd01a  vmovaps [rsp+0x10], xmm1
000074267fbdd020  vmovaps [rsp+0x20], xmm2
000074267fbdd026  vmovaps [rsp+0x30], xmm3
000074267fbdd02c  vmovaps [rsp+0x40], xmm4
000074267fbdd032  vmovaps [rsp+0x50], xmm5
000074267fbdd038  vmovaps [rsp+0x60], xmm6
000074267fbdd03e  vmovaps [rsp+0x70], xmm7
000074267fbdd044  vmovaps [rsp+0x80], xmm8
000074267fbdd04d  vmovaps [rsp+0x90], xmm9
000074267fbdd056  vmovaps [rsp+0xA0], xmm10
000074267fbdd05f  vmovaps [rsp+0xB0], xmm11
000074267fbdd068  vmovaps [rsp+0xC0], xmm12
000074267fbdd071  vmovaps [rsp+0xD0], xmm14
000074267fbdd07a  vmovaps [rsp+0xE0], xmm15
000074267fbdd083  sub rsp, 0x40
000074267fbdd087  lea rdi, [rsp]
000074267fbdd08b  lea rsi, [rsp+0x10]
000074267fbdd090  lea rdx, [rsp+0x20]
000074267fbdd095  lea rcx, [rsp+0x30]
000074267fbdd09a  mov r8d, 0x00
000074267fbdd0a0  lea r9, [r15+0x3A8]
000074267fbdd0a7  movaps [rdi], xmm13
000074267fbdd0ab  movaps [rsi], xmm12
000074267fbdd0af  movaps [rdx], xmm15
000074267fbdd0b3  movaps [rcx], xmm14
000074267fbdd0b7  mov rax, 0x56D4E47AEA50
000074267fbdd0c1  call rax
000074267fbdd0c3  movaps xmm13, [rsp]
000074267fbdd0c8  add rsp, 0x40
000074267fbdd0cc  vmovaps xmm0, [rsp]
000074267fbdd0d1  vmovaps xmm1, [rsp+0x10]
000074267fbdd0d7  vmovaps xmm2, [rsp+0x20]
000074267fbdd0dd  vmovaps xmm3, [rsp+0x30]
000074267fbdd0e3  vmovaps xmm4, [rsp+0x40]
000074267fbdd0e9  vmovaps xmm5, [rsp+0x50]
000074267fbdd0ef  vmovaps xmm6, [rsp+0x60]
000074267fbdd0f5  vmovaps xmm7, [rsp+0x70]
000074267fbdd0fb  vmovaps xmm8, [rsp+0x80]
000074267fbdd104  vmovaps xmm9, [rsp+0x90]
000074267fbdd10d  vmovaps xmm10, [rsp+0xA0]
000074267fbdd116  vmovaps xmm11, [rsp+0xB0]
000074267fbdd11f  vmovaps xmm12, [rsp+0xC0]
000074267fbdd128  vmovaps xmm14, [rsp+0xD0]
000074267fbdd131  vmovaps xmm15, [rsp+0xE0]
000074267fbdd13a  add rsp, 0xF0
000074267fbdd141  pop r11
000074267fbdd143  pop r10
000074267fbdd145  pop r9
000074267fbdd147  pop r8
000074267fbdd149  pop rsi
000074267fbdd14a  pop rdi
000074267fbdd14b  pop rdx
000074267fbdd14c  pop rcx
000074267fbdd14d  pop rax
000074267fbdd14e  add rsp, 0x08
000074267fbdd152  jmp 0x000074267FBDA608
000074267fbdd157  sub rsp, 0x08
000074267fbdd15b  push rax
000074267fbdd15c  push rcx
000074267fbdd15d  push rdx
000074267fbdd15e  push rdi
000074267fbdd15f  push rsi
000074267fbdd160  push r8
000074267fbdd162  push r9
000074267fbdd164  push r10
000074267fbdd166  push r11
000074267fbdd168  sub rsp, 0xF0
000074267fbdd16f  vmovaps [rsp], xmm0
000074267fbdd174  vmovaps [rsp+0x10], xmm1
000074267fbdd17a  vmovaps [rsp+0x20], xmm2
000074267fbdd180  vmovaps [rsp+0x30], xmm3
000074267fbdd186  vmovaps [rsp+0x40], xmm4
000074267fbdd18c  vmovaps [rsp+0x50], xmm5
000074267fbdd192  vmovaps [rsp+0x60], xmm6
000074267fbdd198  vmovaps [rsp+0x70], xmm7
000074267fbdd19e  vmovaps [rsp+0x80], xmm8
000074267fbdd1a7  vmovaps [rsp+0x90], xmm9
000074267fbdd1b0  vmovaps [rsp+0xA0], xmm10
000074267fbdd1b9  vmovaps [rsp+0xB0], xmm11
000074267fbdd1c2  vmovaps [rsp+0xC0], xmm12
000074267fbdd1cb  vmovaps [rsp+0xD0], xmm13
000074267fbdd1d4  vmovaps [rsp+0xE0], xmm15
000074267fbdd1dd  sub rsp, 0x40
000074267fbdd1e1  lea rdi, [rsp]
000074267fbdd1e5  lea rsi, [rsp+0x10]
000074267fbdd1ea  lea rdx, [rsp+0x20]
000074267fbdd1ef  lea rcx, [rsp+0x30]
000074267fbdd1f4  mov r8d, 0x00
000074267fbdd1fa  lea r9, [r15+0x3A8]
000074267fbdd201  movaps [rdi], xmm14
000074267fbdd205  movaps [rsi], xmm11
000074267fbdd209  movaps [rdx], xmm1
000074267fbdd20c  movaps [rcx], xmm15
000074267fbdd210  mov rax, 0x56D4E47AEA50
000074267fbdd21a  call rax
000074267fbdd21c  movaps xmm14, [rsp]
000074267fbdd221  add rsp, 0x40
000074267fbdd225  vmovaps xmm0, [rsp]
000074267fbdd22a  vmovaps xmm1, [rsp+0x10]
000074267fbdd230  vmovaps xmm2, [rsp+0x20]
000074267fbdd236  vmovaps xmm3, [rsp+0x30]
000074267fbdd23c  vmovaps xmm4, [rsp+0x40]
000074267fbdd242  vmovaps xmm5, [rsp+0x50]
000074267fbdd248  vmovaps xmm6, [rsp+0x60]
000074267fbdd24e  vmovaps xmm7, [rsp+0x70]
000074267fbdd254  vmovaps xmm8, [rsp+0x80]
000074267fbdd25d  vmovaps xmm9, [rsp+0x90]
000074267fbdd266  vmovaps xmm10, [rsp+0xA0]
000074267fbdd26f  vmovaps xmm11, [rsp+0xB0]
000074267fbdd278  vmovaps xmm12, [rsp+0xC0]
000074267fbdd281  vmovaps xmm13, [rsp+0xD0]
000074267fbdd28a  vmovaps xmm15, [rsp+0xE0]
000074267fbdd293  add rsp, 0xF0
000074267fbdd29a  pop r11
000074267fbdd29c  pop r10
000074267fbdd29e  pop r9
000074267fbdd2a0  pop r8
000074267fbdd2a2  pop rsi
000074267fbdd2a3  pop rdi
000074267fbdd2a4  pop rdx
000074267fbdd2a5  pop rcx
000074267fbdd2a6  pop rax
000074267fbdd2a7  add rsp, 0x08
000074267fbdd2ab  jmp 0x000074267FBDA636
000074267fbdd2b0  call 0x000074267FA079B0
000074267fbdd2b5  jmp 0x000074267FBDA64C
000074267fbdd2ba  call 0x000074267FAE3440
000074267fbdd2bf  jmp 0x000074267FBDA656
000074267fbdd2c4  call 0x000074267FADFCE0
000074267fbdd2c9  jmp 0x000074267FBDA660
000074267fbdd2ce  call 0x000074267FAE46C0
000074267fbdd2d3  jmp 0x000074267FBDA66A
000074267fbdd2d8  int3
000074267fbdd2d9  nop [rax], eax
000074267fbdd2e0  mov qword ptr [r15+0x40], 0x430000
000074267fbdd2e8  mov eax, 0x430C50
000074267fbdd2ed  mov r14, [r13+rax*1]
000074267fbdd2f2  movq xmm1, r14
000074267fbdd2f7  mov rax, [r15+0x50]
000074267fbdd2fb  movups xmm15, [r13+rax*1]
000074267fbdd301  movaps [r15+0x120], xmm15
000074267fbdd309  mov qword ptr [r15+0x48], 0x10
000074267fbdd311  xor eax, eax
000074267fbdd313  mov r14d, 0x10
000074267fbdd319  mov r12d, 0x200
000074267fbdd31f  cmp r14, r12
000074267fbdd322  cmc
000074267fbdd323  lahf
000074267fbdd324  seto al
000074267fbdd327  mov [r15+0x108], eax
000074267fbdd32e  pextrq rax, xmm15, 0x01
000074267fbdd335  movq xmm14, rax
000074267fbdd33a  movaps [r15+0x130], xmm14
000074267fbdd342  movq rax, xmm1
000074267fbdd347  movq r14, xmm15
000074267fbdd34c  vmovq xmm1, rax
000074267fbdd351  vmovq xmm15, r14
000074267fbdd356  movaps xmm13, xmm1
000074267fbdd35a  addsd xmm13, xmm15
000074267fbdd35f  ucomisd xmm13, xmm13
000074267fbdd364  jp 0x000074267FBDD423
000074267fbdd36a  movq xmm13, xmm13
000074267fbdd36f  movq rax, xmm13
000074267fbdd374  movq r14, xmm14
000074267fbdd379  vmovq xmm1, rax
000074267fbdd37e  vmovq xmm15, r14
000074267fbdd383  movaps xmm14, xmm1
000074267fbdd387  addsd xmm14, xmm15
000074267fbdd38c  ucomisd xmm14, xmm14
000074267fbdd391  jp 0x000074267FBDD46B
000074267fbdd397  movq xmm14, xmm14
000074267fbdd39c  movaps [r15+0x110], xmm14
000074267fbdd3a4  mov eax, [r15+0x108]
000074267fbdd3ab  sahf
000074267fbdd3ac  jnz 0x000074267FBDD3DE
000074267fbdd3ae  cmp dword ptr [r15+0x318], 0x00
000074267fbdd3b6  jz 0x000074267FBDD680
000074267fbdd3bc  nop [rax+rax*1], ax
000074267fbdd3c5  nop [rax+rax*1], eax
000074267fbdd3cd  mov eax, 0x410698
000074267fbdd3d2  mov [r15+0x100], rax
000074267fbdd3d9  jmp 0x000074267F9FE110
000074267fbdd3de  cmp dword ptr [r15+0x318], 0x00
000074267fbdd3e6  jz 0x000074267FBDD4C0
000074267fbdd3ec  nop [rax+rax*1], ax
000074267fbdd3f5  nop [rax+rax*1], eax
000074267fbdd3fd  mov eax, 0x41067C
000074267fbdd402  mov [r15+0x100], rax
000074267fbdd409  jmp 0x000074267F9FE110
000074267fbdd40e  int3
000074267fbdd40f  call 0x000074267FA0DC20
000074267fbdd414  jmp 0x000074267FBDD2F2
000074267fbdd419  call 0x000074267FA0E760
000074267fbdd41e  jmp 0x000074267FBDD301
000074267fbdd423  ucomisd xmm1, xmm15
000074267fbdd428  jp 0x000074267FBDD437
000074267fbdd42a  movaps xmm13, [0x000074267F7FE060]
000074267fbdd432  jmp 0x000074267FBDD36A
000074267fbdd437  vxorps xmm0, xmm1, xmm15
000074267fbdd43c  pextrw eax, xmm0, 0x03
000074267fbdd441  and eax, 0x7FF8
000074267fbdd446  cmp eax, 0x08
000074267fbdd449  jnz 0x000074267FBDD36A
000074267fbdd44f  movq rax, xmm15
000074267fbdd454  shl rax, 0x0D
000074267fbdd458  jbe 0x000074267FBDD36A
000074267fbdd45e  vorps xmm13, xmm15, [0x000074267F7FE070]
000074267fbdd466  jmp 0x000074267FBDD36A
000074267fbdd46b  ucomisd xmm1, xmm15
000074267fbdd470  jp 0x000074267FBDD47F
000074267fbdd472  movaps xmm14, [0x000074267F7FE060]
000074267fbdd47a  jmp 0x000074267FBDD397
000074267fbdd47f  vxorps xmm0, xmm1, xmm15
000074267fbdd484  pextrw eax, xmm0, 0x03
000074267fbdd489  and eax, 0x7FF8
000074267fbdd48e  cmp eax, 0x08
000074267fbdd491  jnz 0x000074267FBDD397
000074267fbdd497  movq rax, xmm15
000074267fbdd49c  shl rax, 0x0D
000074267fbdd4a0  jbe 0x000074267FBDD397
000074267fbdd4a6  vorps xmm14, xmm15, [0x000074267F7FE070]
000074267fbdd4ae  jmp 0x000074267FBDD397
000074267fbdd4b3  int3
000074267fbdd4b4  nop [rax+rax*1], ax
000074267fbdd4bd  nop [rax], eax
000074267fbdd4c0  mov rax, [r15+0x48]
000074267fbdd4c4  mov r14, [r15+0x50]
000074267fbdd4c8  lea r12, [r14+rax*1]
000074267fbdd4cc  movups xmm1, [r13+r12*1]
000074267fbdd4d2  movaps [r15+0x120], xmm1
000074267fbdd4da  lea r14, [rax+0x10]
000074267fbdd4de  mov [r15+0x48], r14
000074267fbdd4e2  xor eax, eax
000074267fbdd4e4  mov r12d, 0x200
000074267fbdd4ea  cmp r14, r12
000074267fbdd4ed  cmc
000074267fbdd4ee  lahf
000074267fbdd4ef  seto al
000074267fbdd4f2  mov [r15+0x108], eax
000074267fbdd4f9  pextrq rax, xmm1, 0x01
000074267fbdd500  movq xmm15, rax
000074267fbdd505  movaps [r15+0x130], xmm15
000074267fbdd50d  movaps xmm14, [r15+0x110]
000074267fbdd515  movq rax, xmm14
000074267fbdd51a  movq r14, xmm1
000074267fbdd51f  vmovq xmm1, rax
000074267fbdd524  vmovq xmm14, r14
000074267fbdd529  movaps xmm13, xmm1
000074267fbdd52d  addsd xmm13, xmm14
000074267fbdd532  ucomisd xmm13, xmm13
000074267fbdd537  jp 0x000074267FBDD5EC
000074267fbdd53d  movq xmm13, xmm13
000074267fbdd542  movq rax, xmm13
000074267fbdd547  movq r14, xmm15
000074267fbdd54c  vmovq xmm1, rax
000074267fbdd551  vmovq xmm15, r14
000074267fbdd556  movaps xmm14, xmm1
000074267fbdd55a  addsd xmm14, xmm15
000074267fbdd55f  ucomisd xmm14, xmm14
000074267fbdd564  jp 0x000074267FBDD634
000074267fbdd56a  movq xmm14, xmm14
000074267fbdd56f  movaps [r15+0x110], xmm14
000074267fbdd577  mov eax, [r15+0x108]
000074267fbdd57e  sahf
000074267fbdd57f  jnz 0x000074267FBDD5B1
000074267fbdd581  cmp dword ptr [r15+0x318], 0x00
000074267fbdd589  jz 0x000074267FBDD680
000074267fbdd58f  nop [rax+rax*1], ax
000074267fbdd598  nop [rax+rax*1], eax
000074267fbdd5a0  mov eax, 0x410698
000074267fbdd5a5  mov [r15+0x100], rax
000074267fbdd5ac  jmp 0x000074267F9FE110
000074267fbdd5b1  cmp dword ptr [r15+0x318], 0x00
000074267fbdd5b9  jz 0x000074267FBDD4C0
000074267fbdd5bf  nop [rax+rax*1], ax
000074267fbdd5c8  nop [rax+rax*1], eax
000074267fbdd5d0  mov eax, 0x41067C
000074267fbdd5d5  mov [r15+0x100], rax
000074267fbdd5dc  jmp 0x000074267F9FE110
000074267fbdd5e1  int3
000074267fbdd5e2  call 0x000074267FAB52F0
000074267fbdd5e7  jmp 0x000074267FBDD4D2
000074267fbdd5ec  ucomisd xmm1, xmm14
000074267fbdd5f1  jp 0x000074267FBDD600
000074267fbdd5f3  movaps xmm13, [0x000074267F7FE060]
000074267fbdd5fb  jmp 0x000074267FBDD53D
000074267fbdd600  vxorps xmm0, xmm1, xmm14
000074267fbdd605  pextrw eax, xmm0, 0x03
000074267fbdd60a  and eax, 0x7FF8
000074267fbdd60f  cmp eax, 0x08
000074267fbdd612  jnz 0x000074267FBDD53D
000074267fbdd618  movq rax, xmm14
000074267fbdd61d  shl rax, 0x0D
000074267fbdd621  jbe 0x000074267FBDD53D
000074267fbdd627  vorps xmm13, xmm14, [0x000074267F7FE070]
000074267fbdd62f  jmp 0x000074267FBDD53D
000074267fbdd634  ucomisd xmm1, xmm15
000074267fbdd639  jp 0x000074267FBDD648
000074267fbdd63b  movaps xmm14, [0x000074267F7FE060]
000074267fbdd643  jmp 0x000074267FBDD56A
000074267fbdd648  vxorps xmm0, xmm1, xmm15
000074267fbdd64d  pextrw eax, xmm0, 0x03
000074267fbdd652  and eax, 0x7FF8
000074267fbdd657  cmp eax, 0x08
000074267fbdd65a  jnz 0x000074267FBDD56A
000074267fbdd660  movq rax, xmm15
000074267fbdd665  shl rax, 0x0D
000074267fbdd669  jbe 0x000074267FBDD56A
000074267fbdd66f  vorps xmm14, xmm15, [0x000074267F7FE070]
000074267fbdd677  jmp 0x000074267FBDD56A
000074267fbdd67c  int3
000074267fbdd67d  nop [rax], eax
000074267fbdd680  mov rax, [r15+0xF8]
000074267fbdd687  lea r14, [rax+0x1A0]
000074267fbdd68e  mov r12, [r13+r14*1]
000074267fbdd693  lea r14, [rax+0x1A8]
000074267fbdd69a  mov r11, [r13+r14*1]
000074267fbdd69f  mov [r15+0xA0], r12
000074267fbdd6a6  mov [r15+0x98], r11
000074267fbdd6ad  mov r14, [r15+0x40]
000074267fbdd6b1  lea r12, [r14+0xC50]
000074267fbdd6b8  movaps xmm1, [r15+0x110]
000074267fbdd6c0  movq r14, xmm1
000074267fbdd6c5  mov [r13+r12*1], r14
000074267fbdd6ca  lea r14, [rax+0x190]
000074267fbdd6d1  mov r12, [r13+r14*1]
000074267fbdd6d6  lea r14, [rax+0x198]
000074267fbdd6dd  mov r11, [r13+r14*1]
000074267fbdd6e2  mov [r15+0xE8], r12
000074267fbdd6e9  mov [r15+0xF0], r11
000074267fbdd6f0  lea r14, [rax+0x180]
000074267fbdd6f7  mov r12, [r13+r14*1]
000074267fbdd6fc  lea r14, [rax+0x188]
000074267fbdd703  mov r10, [r13+r14*1]
000074267fbdd708  movq xmm1, r12
000074267fbdd70d  movq xmm15, r10
000074267fbdd712  movq xmm1, xmm1
000074267fbdd716  movq xmm1, xmm1
000074267fbdd71a  movaps [r15+0x1A0], xmm1
000074267fbdd722  movq xmm15, xmm15
000074267fbdd727  movq xmm15, xmm15
000074267fbdd72c  movaps [r15+0x190], xmm15
000074267fbdd734  lea r14, [rax+0x170]
000074267fbdd73b  mov r12, [r13+r14*1]
000074267fbdd740  lea r14, [rax+0x178]
000074267fbdd747  mov r10, [r13+r14*1]
000074267fbdd74c  movq xmm1, r12
000074267fbdd751  movq xmm15, r10
000074267fbdd756  movq xmm1, xmm1
000074267fbdd75a  movq xmm1, xmm1
000074267fbdd75e  movaps [r15+0x1C0], xmm1
000074267fbdd766  movq xmm15, xmm15
000074267fbdd76b  movq xmm15, xmm15
000074267fbdd770  movaps [r15+0x1B0], xmm15
000074267fbdd778  lea r14, [rax+0x160]
000074267fbdd77f  mov r12, [r13+r14*1]
000074267fbdd784  lea r14, [rax+0x168]
000074267fbdd78b  mov r10, [r13+r14*1]
000074267fbdd790  movq xmm1, r12
000074267fbdd795  movq xmm15, r10
000074267fbdd79a  movq xmm1, xmm1
000074267fbdd79e  movq xmm1, xmm1
000074267fbdd7a2  movaps [r15+0x1E0], xmm1
000074267fbdd7aa  movq xmm15, xmm15
000074267fbdd7af  movq xmm15, xmm15
000074267fbdd7b4  movaps [r15+0x1D0], xmm15
000074267fbdd7bc  lea r14, [rax+0x150]
000074267fbdd7c3  mov r12, [r13+r14*1]
000074267fbdd7c8  lea r14, [rax+0x158]
000074267fbdd7cf  mov r10, [r13+r14*1]
000074267fbdd7d4  movq xmm1, r12
000074267fbdd7d9  movq xmm15, r10
000074267fbdd7de  movq xmm1, xmm1
000074267fbdd7e2  movq xmm1, xmm1
000074267fbdd7e6  movaps [r15+0x200], xmm1
000074267fbdd7ee  movq xmm15, xmm15
000074267fbdd7f3  movq xmm15, xmm15
000074267fbdd7f8  movaps [r15+0x1F0], xmm15
000074267fbdd800  lea r14, [rax+0x1B0]
000074267fbdd807  mov [r15+0xF8], r14
000074267fbdd80e  mov [r15+0x100], r11
000074267fbdd815  jmp 0x000074267FBCE5C0
000074267fbdd81a  int3
000074267fbdd81b  call 0x000074267FAE27E0
000074267fbdd820  jmp 0x000074267FBDD693
000074267fbdd825  call 0x000074267FAE1570
000074267fbdd82a  jmp 0x000074267FBDD69F
000074267fbdd82f  call 0x000074267FAC3FE0
000074267fbdd834  jmp 0x000074267FBDD6CA
000074267fbdd839  call 0x000074267FAE27E0
000074267fbdd83e  jmp 0x000074267FBDD6D6
000074267fbdd843  call 0x000074267FAE1570
000074267fbdd848  jmp 0x000074267FBDD6E2
000074267fbdd84d  call 0x000074267FAE27E0
000074267fbdd852  jmp 0x000074267FBDD6FC
000074267fbdd857  call 0x000074267FAE0300
000074267fbdd85c  jmp 0x000074267FBDD708
000074267fbdd861  call 0x000074267FAE27E0
000074267fbdd866  jmp 0x000074267FBDD740
000074267fbdd86b  call 0x000074267FAE0300
000074267fbdd870  jmp 0x000074267FBDD74C
000074267fbdd875  call 0x000074267FAE27E0
000074267fbdd87a  jmp 0x000074267FBDD784
000074267fbdd87f  call 0x000074267FAE0300
000074267fbdd884  jmp 0x000074267FBDD790
000074267fbdd889  call 0x000074267FAE27E0
000074267fbdd88e  jmp 0x000074267FBDD7C8
000074267fbdd893  call 0x000074267FAE0300
000074267fbdd898  jmp 0x000074267FBDD7D4
000074267fbdd89d  int3
000074267fbdd89e  nop
000074267fbdd8a0  mov qword ptr [r15+0x100], 0x04
000074267fbdd8ab  mov esi, 0x00
000074267fbdd8b0  mov edx, 0x09
000074267fbdd8b5  mov rdi, 0x7FFD16A03990
000074267fbdd8bf  mov rax, 0x56D4E4641970
000074267fbdd8c9  call rax
000074267fbdd8cb  cmp dword ptr [r15+0x318], 0x00
000074267fbdd8d3  jnz 0x000074267F9FE110
000074267fbdd8d9  jmp 0x000074267F9FE0A0
000074267fbdd8de  int3
000074267fbdd8df  int3
