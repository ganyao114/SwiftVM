00007ac9d05ce69b  nop [rax+rax*1], eax
00007ac9d05ce6a0  mov rax, [r15+0xF8]
00007ac9d05ce6a7  lea r14, [rax-0x1B0]
00007ac9d05ce6ae  mov [r15+0xF8], r14
00007ac9d05ce6b5  lea rax, [r14+0x1A0]
00007ac9d05ce6bc  mov r12, [r15+0xA0]
00007ac9d05ce6c3  mov r11, [r15+0x98]
00007ac9d05ce6ca  mov [r13+rax*1], r12
00007ac9d05ce6cf  lea rax, [r14+0x1A8]
00007ac9d05ce6d6  mov [r13+rax*1], r11
00007ac9d05ce6db  mov eax, 0x420A30
00007ac9d05ce6e0  movups xmm1, [r13+rax*1]
00007ac9d05ce6e6  mov eax, 0x4209C0
00007ac9d05ce6eb  movups xmm15, [r13+rax*1]
00007ac9d05ce6f1  mov eax, 0x420A50
00007ac9d05ce6f6  movups xmm14, [r13+rax*1]
00007ac9d05ce6fc  mov eax, 0x4209F0
00007ac9d05ce701  movups xmm13, [r13+rax*1]
00007ac9d05ce707  mov qword ptr [r15+0x98], 0x430C60
00007ac9d05ce712  mov eax, 0x420A60
00007ac9d05ce717  movups xmm12, [r13+rax*1]
00007ac9d05ce71d  mov eax, 0x430C60
00007ac9d05ce722  movups [r13+rax*1], xmm1
00007ac9d05ce728  mov eax, 0x430C70
00007ac9d05ce72d  movups [r13+rax*1], xmm15
00007ac9d05ce733  mov eax, 0x430C80
00007ac9d05ce738  movups [r13+rax*1], xmm14
00007ac9d05ce73e  mov eax, 0x430C90
00007ac9d05ce743  movups [r13+rax*1], xmm13
00007ac9d05ce749  mov eax, 0x4209B0
00007ac9d05ce74e  movups xmm14, [r13+rax*1]
00007ac9d05ce754  mov eax, 0x4209A0
00007ac9d05ce759  movups xmm13, [r13+rax*1]
00007ac9d05ce75f  mov eax, 0x430D60
00007ac9d05ce764  movups [r13+rax*1], xmm1
00007ac9d05ce76a  mov eax, 0x430D70
00007ac9d05ce76f  movups [r13+rax*1], xmm15
00007ac9d05ce775  mov eax, 0x430CA0
00007ac9d05ce77a  movups [r13+rax*1], xmm12
00007ac9d05ce780  mov eax, 0x430CB0
00007ac9d05ce785  movups [r13+rax*1], xmm14
00007ac9d05ce78b  mov eax, 0x420990
00007ac9d05ce790  movups xmm1, [r13+rax*1]
00007ac9d05ce796  mov eax, 0x420A00
00007ac9d05ce79b  movups xmm15, [r13+rax*1]
00007ac9d05ce7a1  mov eax, 0x430CC0
00007ac9d05ce7a6  movups [r13+rax*1], xmm13
00007ac9d05ce7ac  mov eax, 0x430CD0
00007ac9d05ce7b1  movups [r13+rax*1], xmm1
00007ac9d05ce7b7  mov eax, 0x420A10
00007ac9d05ce7bc  movups xmm1, [r13+rax*1]
00007ac9d05ce7c2  mov eax, 0x4209E0
00007ac9d05ce7c7  movups xmm14, [r13+rax*1]
00007ac9d05ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007ac9d05ce7d5  mov eax, 0x430CE0
00007ac9d05ce7da  movups [r13+rax*1], xmm15
00007ac9d05ce7e0  mov eax, 0x430CF0
00007ac9d05ce7e5  movups [r13+rax*1], xmm1
00007ac9d05ce7eb  mov eax, 0x420A80
00007ac9d05ce7f0  movups xmm1, [r13+rax*1]
00007ac9d05ce7f6  mov eax, 0x420A90
00007ac9d05ce7fb  movups xmm15, [r13+rax*1]
00007ac9d05ce801  movaps [r15+0x150], xmm15
00007ac9d05ce809  mov qword ptr [r15+0xA0], 0x3E8
00007ac9d05ce814  mov eax, 0x430D00
00007ac9d05ce819  movups [r13+rax*1], xmm14
00007ac9d05ce81f  mov eax, 0x430D10
00007ac9d05ce824  movups [r13+rax*1], xmm1
00007ac9d05ce82a  mov eax, 0x420A70
00007ac9d05ce82f  movups xmm1, [r13+rax*1]
00007ac9d05ce835  mov eax, 0x420A20
00007ac9d05ce83a  movups xmm14, [r13+rax*1]
00007ac9d05ce840  movaps [r15+0x140], xmm14
00007ac9d05ce848  lea rax, [r14+0x150]
00007ac9d05ce84f  movq xmm13, qword ptr [r15+0x200]
00007ac9d05ce858  movq xmm12, qword ptr [r15+0x1F0]
00007ac9d05ce861  movq r12, xmm13
00007ac9d05ce866  movq r11, xmm12
00007ac9d05ce86b  mov [r13+rax*1], r12
00007ac9d05ce870  lea rax, [r14+0x158]
00007ac9d05ce877  mov [r13+rax*1], r11
00007ac9d05ce87c  mov eax, 0x430D20
00007ac9d05ce881  movups [r13+rax*1], xmm15
00007ac9d05ce887  mov eax, 0x430D30
00007ac9d05ce88c  movups [r13+rax*1], xmm1
00007ac9d05ce892  mov eax, 0x420A40
00007ac9d05ce897  movups xmm1, [r13+rax*1]
00007ac9d05ce89d  mov eax, 0x420AA8
00007ac9d05ce8a2  mov r12, [r13+rax*1]
00007ac9d05ce8a7  movq xmm15, r12
00007ac9d05ce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007ac9d05ce8b4  mov eax, 0x430D40
00007ac9d05ce8b9  movups [r13+rax*1], xmm14
00007ac9d05ce8bf  mov eax, 0x430D50
00007ac9d05ce8c4  movups [r13+rax*1], xmm1
00007ac9d05ce8ca  mov eax, 0x420B10
00007ac9d05ce8cf  movups xmm1, [r13+rax*1]
00007ac9d05ce8d5  movq rax, xmm15
00007ac9d05ce8da  mov r12d, 0x430D80
00007ac9d05ce8e0  mov [r13+r12*1], rax
00007ac9d05ce8e5  mov eax, 0x420AF0
00007ac9d05ce8ea  movups xmm15, [r13+rax*1]
00007ac9d05ce8f0  mov eax, 0x420B00
00007ac9d05ce8f5  movups xmm14, [r13+rax*1]
00007ac9d05ce8fb  lea rax, [r14+0x130]
00007ac9d05ce902  movups [r13+rax*1], xmm1
00007ac9d05ce908  lea rax, [r14+0x160]
00007ac9d05ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007ac9d05ce918  movq xmm13, qword ptr [r15+0x1D0]
00007ac9d05ce921  movq r12, xmm1
00007ac9d05ce926  movq r11, xmm13
00007ac9d05ce92b  mov [r13+rax*1], r12
00007ac9d05ce930  lea rax, [r14+0x168]
00007ac9d05ce937  mov [r13+rax*1], r11
00007ac9d05ce93c  lea rax, [r14+0x110]
00007ac9d05ce943  movups [r13+rax*1], xmm15
00007ac9d05ce949  lea rax, [r14+0x120]
00007ac9d05ce950  movups [r13+rax*1], xmm14
00007ac9d05ce956  mov eax, 0x420AB0
00007ac9d05ce95b  movups xmm1, [r13+rax*1]
00007ac9d05ce961  mov eax, 0x420AC0
00007ac9d05ce966  movups xmm15, [r13+rax*1]
00007ac9d05ce96c  movaps [r15+0x120], xmm15
00007ac9d05ce974  lea rax, [r14+0x170]
00007ac9d05ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007ac9d05ce984  movq xmm13, qword ptr [r15+0x1B0]
00007ac9d05ce98d  movq r12, xmm14
00007ac9d05ce992  movq r11, xmm13
00007ac9d05ce997  mov [r13+rax*1], r12
00007ac9d05ce99c  lea rax, [r14+0x178]
00007ac9d05ce9a3  mov [r13+rax*1], r11
00007ac9d05ce9a8  lea rax, [r14+0x180]
00007ac9d05ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007ac9d05ce9b8  movq xmm13, qword ptr [r15+0x190]
00007ac9d05ce9c1  movq r12, xmm14
00007ac9d05ce9c6  movq r11, xmm13
00007ac9d05ce9cb  mov [r13+rax*1], r12
00007ac9d05ce9d0  lea rax, [r14+0x188]
00007ac9d05ce9d7  mov [r13+rax*1], r11
00007ac9d05ce9dc  lea rax, [r14+0xD0]
00007ac9d05ce9e3  movups [r13+rax*1], xmm1
00007ac9d05ce9e9  lea rax, [r14+0xE0]
00007ac9d05ce9f0  movups [r13+rax*1], xmm15
00007ac9d05ce9f6  mov eax, 0x420AD0
00007ac9d05ce9fb  movups xmm1, [r13+rax*1]
00007ac9d05cea01  mov eax, 0x420AE0
00007ac9d05cea06  movups xmm15, [r13+rax*1]
00007ac9d05cea0c  movaps [r15+0x110], xmm1
00007ac9d05cea14  movaps [r15+0x130], xmm15
00007ac9d05cea1c  lea rax, [r14+0x190]
00007ac9d05cea23  mov r12, [r15+0xE8]
00007ac9d05cea2a  mov r11, [r15+0xF0]
00007ac9d05cea31  mov [r13+rax*1], r12
00007ac9d05cea36  lea rax, [r14+0x198]
00007ac9d05cea3d  mov [r13+rax*1], r11
00007ac9d05cea42  mov eax, 0x430D88
00007ac9d05cea47  mov r12d, 0x421DF8D3
00007ac9d05cea4d  mov [r13+rax*1], r12d
00007ac9d05cea52  lea rax, [r14+0xF0]
00007ac9d05cea59  movups [r13+rax*1], xmm1
00007ac9d05cea5f  lea rax, [r14+0x100]
00007ac9d05cea66  movups [r13+rax*1], xmm15
00007ac9d05cea6c  lea rax, [r14+0xD0]
00007ac9d05cea73  mov [r15], rax
00007ac9d05cea76  mov qword ptr [r15+0x08], 0x430C60
00007ac9d05cea7e  mov qword ptr [r15+0x10], 0x12C
00007ac9d05cea86  mov qword ptr [r15+0xF0], 0x410284
00007ac9d05cea91  mov r14d, [r15+0x320]
00007ac9d05cea98  mov eax, 0x410284
00007ac9d05cea9d  mov rcx, 0x7AC9D05D07C0
00007ac9d05ceaa7  mov [r15+r14*8+0x328], rax
00007ac9d05ceaaf  mov [r15+r14*8+0x368], rcx
00007ac9d05ceab7  add r14d, 0x01
00007ac9d05ceabb  and r14d, 0x07
00007ac9d05ceabf  mov [r15+0x320], r14d
00007ac9d05ceac6  cmp dword ptr [r15+0x318], 0x00
00007ac9d05ceace  jz 0x00007AC9D05CED70
00007ac9d05cead4  nop [rax+rax*1], ax
00007ac9d05ceadd  nop [rax+rax*1], eax
00007ac9d05ceae5  mov eax, 0x4106BC
00007ac9d05ceaea  mov [r15+0x100], rax
00007ac9d05ceaf1  jmp 0x00007AC9D03FE110
00007ac9d05ceaf6  int3
00007ac9d05ceaf7  call 0x00007AC9D040BC20
00007ac9d05ceafc  jmp 0x00007AC9D05CE6CF
00007ac9d05ceb01  call 0x00007AC9D040A9A0
00007ac9d05ceb06  jmp 0x00007AC9D05CE6DB
00007ac9d05ceb0b  call 0x00007AC9D03FF430
00007ac9d05ceb10  jmp 0x00007AC9D05CE6E6
00007ac9d05ceb15  call 0x00007AC9D040E760
00007ac9d05ceb1a  jmp 0x00007AC9D05CE6F1
00007ac9d05ceb1f  call 0x00007AC9D040D4E0
00007ac9d05ceb24  jmp 0x00007AC9D05CE6FC
00007ac9d05ceb29  call 0x00007AC9D040C260
00007ac9d05ceb2e  jmp 0x00007AC9D05CE707
00007ac9d05ceb33  call 0x00007AC9D040AFE0
00007ac9d05ceb38  jmp 0x00007AC9D05CE71D
00007ac9d05ceb3d  call 0x00007AC9D03FF540
00007ac9d05ceb42  jmp 0x00007AC9D05CE728
00007ac9d05ceb47  call 0x00007AC9D040E880
00007ac9d05ceb4c  jmp 0x00007AC9D05CE733
00007ac9d05ceb51  call 0x00007AC9D040D600
00007ac9d05ceb56  jmp 0x00007AC9D05CE73E
00007ac9d05ceb5b  call 0x00007AC9D040C380
00007ac9d05ceb60  jmp 0x00007AC9D05CE749
00007ac9d05ceb65  call 0x00007AC9D040D4E0
00007ac9d05ceb6a  jmp 0x00007AC9D05CE754
00007ac9d05ceb6f  call 0x00007AC9D040C260
00007ac9d05ceb74  jmp 0x00007AC9D05CE75F
00007ac9d05ceb79  call 0x00007AC9D03FF540
00007ac9d05ceb7e  jmp 0x00007AC9D05CE76A
00007ac9d05ceb83  call 0x00007AC9D040E880
00007ac9d05ceb88  jmp 0x00007AC9D05CE775
00007ac9d05ceb8d  call 0x00007AC9D040B100
00007ac9d05ceb92  jmp 0x00007AC9D05CE780
00007ac9d05ceb97  call 0x00007AC9D040D600
00007ac9d05ceb9c  jmp 0x00007AC9D05CE78B
00007ac9d05ceba1  call 0x00007AC9D03FF430
00007ac9d05ceba6  jmp 0x00007AC9D05CE796
00007ac9d05cebab  call 0x00007AC9D040E760
00007ac9d05cebb0  jmp 0x00007AC9D05CE7A1
00007ac9d05cebb5  call 0x00007AC9D040C380
00007ac9d05cebba  jmp 0x00007AC9D05CE7AC
00007ac9d05cebbf  call 0x00007AC9D03FF540
00007ac9d05cebc4  jmp 0x00007AC9D05CE7B7
00007ac9d05cebc9  call 0x00007AC9D03FF430
00007ac9d05cebce  jmp 0x00007AC9D05CE7C2
00007ac9d05cebd3  call 0x00007AC9D040D4E0
00007ac9d05cebd8  jmp 0x00007AC9D05CE7CD
00007ac9d05cebdd  call 0x00007AC9D040E880
00007ac9d05cebe2  jmp 0x00007AC9D05CE7E0
00007ac9d05cebe7  call 0x00007AC9D03FF540
00007ac9d05cebec  jmp 0x00007AC9D05CE7EB
00007ac9d05cebf1  call 0x00007AC9D03FF430
00007ac9d05cebf6  jmp 0x00007AC9D05CE7F6
00007ac9d05cebfb  call 0x00007AC9D040E760
00007ac9d05cec00  jmp 0x00007AC9D05CE801
00007ac9d05cec05  call 0x00007AC9D040D600
00007ac9d05cec0a  jmp 0x00007AC9D05CE81F
00007ac9d05cec0f  call 0x00007AC9D03FF540
00007ac9d05cec14  jmp 0x00007AC9D05CE82A
00007ac9d05cec19  call 0x00007AC9D03FF430
00007ac9d05cec1e  jmp 0x00007AC9D05CE835
00007ac9d05cec23  call 0x00007AC9D040D4E0
00007ac9d05cec28  jmp 0x00007AC9D05CE840
00007ac9d05cec2d  call 0x00007AC9D040BC20
00007ac9d05cec32  jmp 0x00007AC9D05CE870
00007ac9d05cec37  call 0x00007AC9D040A9A0
00007ac9d05cec3c  jmp 0x00007AC9D05CE87C
00007ac9d05cec41  call 0x00007AC9D040E880
00007ac9d05cec46  jmp 0x00007AC9D05CE887
00007ac9d05cec4b  call 0x00007AC9D03FF540
00007ac9d05cec50  jmp 0x00007AC9D05CE892
00007ac9d05cec55  call 0x00007AC9D03FF430
00007ac9d05cec5a  jmp 0x00007AC9D05CE89D
00007ac9d05cec5f  call 0x00007AC9D040B720
00007ac9d05cec64  jmp 0x00007AC9D05CE8A7
00007ac9d05cec69  call 0x00007AC9D040D600
00007ac9d05cec6e  jmp 0x00007AC9D05CE8BF
00007ac9d05cec73  call 0x00007AC9D03FF540
00007ac9d05cec78  jmp 0x00007AC9D05CE8CA
00007ac9d05cec7d  call 0x00007AC9D03FF430
00007ac9d05cec82  jmp 0x00007AC9D05CE8D5
00007ac9d05cec87  call 0x00007AC9D04B4CB0
00007ac9d05cec8c  jmp 0x00007AC9D05CE8E5
00007ac9d05cec91  call 0x00007AC9D040E760
00007ac9d05cec96  jmp 0x00007AC9D05CE8F0
00007ac9d05cec9b  call 0x00007AC9D040D4E0
00007ac9d05ceca0  jmp 0x00007AC9D05CE8FB
00007ac9d05ceca5  call 0x00007AC9D03FF540
00007ac9d05cecaa  jmp 0x00007AC9D05CE908
00007ac9d05cecaf  call 0x00007AC9D040BC20
00007ac9d05cecb4  jmp 0x00007AC9D05CE930
00007ac9d05cecb9  call 0x00007AC9D040A9A0
00007ac9d05cecbe  jmp 0x00007AC9D05CE93C
00007ac9d05cecc3  call 0x00007AC9D040E880
00007ac9d05cecc8  jmp 0x00007AC9D05CE949
00007ac9d05ceccd  call 0x00007AC9D040D600
00007ac9d05cecd2  jmp 0x00007AC9D05CE956
00007ac9d05cecd7  call 0x00007AC9D03FF430
00007ac9d05cecdc  jmp 0x00007AC9D05CE961
00007ac9d05cece1  call 0x00007AC9D040E760
00007ac9d05cece6  jmp 0x00007AC9D05CE96C
00007ac9d05ceceb  call 0x00007AC9D040BC20
00007ac9d05cecf0  jmp 0x00007AC9D05CE99C
00007ac9d05cecf5  call 0x00007AC9D040A9A0
00007ac9d05cecfa  jmp 0x00007AC9D05CE9A8
00007ac9d05cecff  call 0x00007AC9D040BC20
00007ac9d05ced04  jmp 0x00007AC9D05CE9D0
00007ac9d05ced09  call 0x00007AC9D040A9A0
00007ac9d05ced0e  jmp 0x00007AC9D05CE9DC
00007ac9d05ced13  call 0x00007AC9D03FF540
00007ac9d05ced18  jmp 0x00007AC9D05CE9E9
00007ac9d05ced1d  call 0x00007AC9D040E880
00007ac9d05ced22  jmp 0x00007AC9D05CE9F6
00007ac9d05ced27  call 0x00007AC9D03FF430
00007ac9d05ced2c  jmp 0x00007AC9D05CEA01
00007ac9d05ced31  call 0x00007AC9D040E760
00007ac9d05ced36  jmp 0x00007AC9D05CEA0C
00007ac9d05ced3b  call 0x00007AC9D040BC20
00007ac9d05ced40  jmp 0x00007AC9D05CEA36
00007ac9d05ced45  call 0x00007AC9D040A9A0
00007ac9d05ced4a  jmp 0x00007AC9D05CEA42
00007ac9d05ced4f  call 0x00007AC9D040BAE0
00007ac9d05ced54  jmp 0x00007AC9D05CEA52
00007ac9d05ced59  call 0x00007AC9D03FF540
00007ac9d05ced5e  jmp 0x00007AC9D05CEA5F
00007ac9d05ced63  call 0x00007AC9D040E880
00007ac9d05ced68  jmp 0x00007AC9D05CEA6C
00007ac9d05ced6d  int3
00007ac9d05ced6e  nop
00007ac9d05ced70  mov rax, [r15]
00007ac9d05ced73  lea r14, [rax+0x20]
00007ac9d05ced77  mov r12, [r13+r14*1]
00007ac9d05ced7c  mov r14, [r15+0x10]
00007ac9d05ced80  lea r11, [r12+r14*1]
00007ac9d05ced84  mov [r15+0x40], r11
00007ac9d05ced88  lea r12, [rax+0x20]
00007ac9d05ced8c  mov [r13+r12*1], r11
00007ac9d05ced91  test r14, r14
00007ac9d05ced94  setz r14b
00007ac9d05ced98  movzx r14, r14b
00007ac9d05ced9c  mov [rsp+0x414], r14b
00007ac9d05ceda4  cmp byte ptr [rsp+0x414], 0x00
00007ac9d05cedac  jz 0x00007AC9D05CEDDE
00007ac9d05cedae  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cedb6  mov eax, 0x410934
00007ac9d05cedbb  mov [r15+0x100], rax
00007ac9d05cedc2  jz 0x00007AC9D03FE0A0
00007ac9d05cedc8  nop [rax+rax*1], eax
00007ac9d05cedcd  mov eax, 0x410934
00007ac9d05cedd2  mov [r15+0x100], rax
00007ac9d05cedd9  jmp 0x00007AC9D03FE110
00007ac9d05cedde  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cede6  jz 0x00007AC9D05CEE30
00007ac9d05cedec  nop [rax+rax*1], ax
00007ac9d05cedf5  nop [rax+rax*1], eax
00007ac9d05cedfd  mov eax, 0x4106CC
00007ac9d05cee02  mov [r15+0x100], rax
00007ac9d05cee09  jmp 0x00007AC9D03FE110
00007ac9d05cee0e  int3
00007ac9d05cee0f  call 0x00007AC9D04E27E0
00007ac9d05cee14  jmp 0x00007AC9D05CED7C
00007ac9d05cee19  call 0x00007AC9D04C0860
00007ac9d05cee1e  jmp 0x00007AC9D05CED91
00007ac9d05cee23  int3
00007ac9d05cee24  nop [rax+rax*1], ax
00007ac9d05cee2d  nop [rax], eax
00007ac9d05cee30  mov rax, [r15+0xF8]
00007ac9d05cee37  lea r14, [rax-0x150]
00007ac9d05cee3e  mov [r15+0xF8], r14
00007ac9d05cee45  mov rax, [r15]
00007ac9d05cee48  lea r12, [rax+0x68]
00007ac9d05cee4c  mov r11, [r13+r12*1]
00007ac9d05cee51  mov [r15+0x88], r11
00007ac9d05cee58  lea r12, [rax+0x28]
00007ac9d05cee5c  mov [r15+0x40], r12
00007ac9d05cee60  mov [r15+0x48], r14
00007ac9d05cee64  mov qword ptr [r15+0x50], 0x420B20
00007ac9d05cee6c  lea rax, [r14+0x100]
00007ac9d05cee73  mov r12, [r15+0xE8]
00007ac9d05cee7a  mov r11, [r15+0xD8]
00007ac9d05cee81  mov [r13+rax*1], r12
00007ac9d05cee86  lea rax, [r14+0x108]
00007ac9d05cee8d  mov [r13+rax*1], r11
00007ac9d05cee92  lea rax, [r14+0x110]
00007ac9d05cee99  mov r12, [r15+0xD0]
00007ac9d05ceea0  mov r11, [r15+0xC8]
00007ac9d05ceea7  mov [r13+rax*1], r12
00007ac9d05ceeac  lea rax, [r14+0x118]
00007ac9d05ceeb3  mov [r13+rax*1], r11
00007ac9d05ceeb8  lea rax, [r14+0x120]
00007ac9d05ceebf  mov r12, [r15+0xC0]
00007ac9d05ceec6  mov r11, [r15+0xB8]
00007ac9d05ceecd  mov [r13+rax*1], r12
00007ac9d05ceed2  lea rax, [r14+0x128]
00007ac9d05ceed9  mov [r13+rax*1], r11
00007ac9d05ceede  lea rax, [r14+0x130]
00007ac9d05ceee5  mov r12, [r15+0xB0]
00007ac9d05ceeec  mov r11, [r15+0xA8]
00007ac9d05ceef3  mov [r13+rax*1], r12
00007ac9d05ceef8  lea rax, [r14+0x138]
00007ac9d05ceeff  mov [r13+rax*1], r11
00007ac9d05cef04  lea rax, [r14+0x140]
00007ac9d05cef0b  mov r12, [r15+0xA0]
00007ac9d05cef12  mov r11, [r15+0x98]
00007ac9d05cef19  mov [r13+rax*1], r12
00007ac9d05cef1e  lea rax, [r14+0x148]
00007ac9d05cef25  mov [r13+rax*1], r11
00007ac9d05cef2a  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cef32  jz 0x00007AC9D05CEFD0
00007ac9d05cef38  nop [rax+rax*1], ax
00007ac9d05cef41  nop [rax+rax*1], eax
00007ac9d05cef49  mov eax, 0x410704
00007ac9d05cef4e  mov [r15+0x100], rax
00007ac9d05cef55  jmp 0x00007AC9D03FE110
00007ac9d05cef5a  int3
00007ac9d05cef5b  call 0x00007AC9D04C0370
00007ac9d05cef60  jmp 0x00007AC9D05CEE51
00007ac9d05cef65  call 0x00007AC9D040BC20
00007ac9d05cef6a  jmp 0x00007AC9D05CEE86
00007ac9d05cef6f  call 0x00007AC9D040A9A0
00007ac9d05cef74  jmp 0x00007AC9D05CEE92
00007ac9d05cef79  call 0x00007AC9D040BC20
00007ac9d05cef7e  jmp 0x00007AC9D05CEEAC
00007ac9d05cef83  call 0x00007AC9D040A9A0
00007ac9d05cef88  jmp 0x00007AC9D05CEEB8
00007ac9d05cef8d  call 0x00007AC9D040BC20
00007ac9d05cef92  jmp 0x00007AC9D05CEED2
00007ac9d05cef97  call 0x00007AC9D040A9A0
00007ac9d05cef9c  jmp 0x00007AC9D05CEEDE
00007ac9d05cefa1  call 0x00007AC9D040BC20
00007ac9d05cefa6  jmp 0x00007AC9D05CEEF8
00007ac9d05cefab  call 0x00007AC9D040A9A0
00007ac9d05cefb0  jmp 0x00007AC9D05CEF04
00007ac9d05cefb5  call 0x00007AC9D040BC20
00007ac9d05cefba  jmp 0x00007AC9D05CEF1E
00007ac9d05cefbf  call 0x00007AC9D040A9A0
00007ac9d05cefc4  jmp 0x00007AC9D05CEF2A
00007ac9d05cefc9  int3
00007ac9d05cefca  nop [rax+rax*1], ax
00007ac9d05cefd0  mov rax, [r15+0x08]
00007ac9d05cefd4  movzx r14d, byte ptr [r13+rax*1]
00007ac9d05cefda  movzx r14d, r14b
00007ac9d05cefde  mov [rsp+0x10], r14d
00007ac9d05cefe3  mov r14d, r14d
00007ac9d05cefe6  mov [r15+0x58], r14
00007ac9d05cefea  lea r14, [rax+0x01]
00007ac9d05cefee  mov [r15+0x08], r14
00007ac9d05ceff2  mov rax, [r15+0x88]
00007ac9d05ceff9  lea r14, [rax+0x01]
00007ac9d05ceffd  mov r12, [r15]
00007ac9d05cf000  lea r11, [r12+0x68]
00007ac9d05cf005  mov [r13+r11*1], r14
00007ac9d05cf00a  lea r14, [r12+rax*1]
00007ac9d05cf00e  mov [r15+0x60], r14
00007ac9d05cf012  lea rax, [r14+0x28]
00007ac9d05cf016  mov r11d, [rsp+0x10]
00007ac9d05cf01b  movzx r14d, r11b
00007ac9d05cf01f  mov [r13+rax*1], r14b
00007ac9d05cf024  lea rax, [r12+0x68]
00007ac9d05cf029  mov r14, [r13+rax*1]
00007ac9d05cf02e  mov [r15+0x88], r14
00007ac9d05cf035  xor eax, eax
00007ac9d05cf037  mov r12d, 0x40
00007ac9d05cf03d  cmp r14, r12
00007ac9d05cf040  cmc
00007ac9d05cf041  lahf
00007ac9d05cf042  seto al
00007ac9d05cf045  mov [r15+0x108], eax
00007ac9d05cf04c  mov eax, [r15+0x108]
00007ac9d05cf053  sahf
00007ac9d05cf054  jnz 0x00007AC9D05CF086
00007ac9d05cf056  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cf05e  jz 0x00007AC9D05CF170
00007ac9d05cf064  nop [rax+rax*1], ax
00007ac9d05cf06d  nop [rax+rax*1], eax
00007ac9d05cf075  mov eax, 0x410724
00007ac9d05cf07a  mov [r15+0x100], rax
00007ac9d05cf081  jmp 0x00007AC9D03FE110
00007ac9d05cf086  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cf08e  jz 0x00007AC9D05CF0E0
00007ac9d05cf094  nop [rax+rax*1], ax
00007ac9d05cf09d  nop [rax+rax*1], eax
00007ac9d05cf0a5  mov eax, 0x4106FC
00007ac9d05cf0aa  mov [r15+0x100], rax
00007ac9d05cf0b1  jmp 0x00007AC9D03FE110
00007ac9d05cf0b6  int3
00007ac9d05cf0b7  call 0x00007AC9D040D860
00007ac9d05cf0bc  jmp 0x00007AC9D05CEFDA
00007ac9d05cf0c1  call 0x00007AC9D04B36E0
00007ac9d05cf0c6  jmp 0x00007AC9D05CF00A
00007ac9d05cf0cb  call 0x00007AC9D040DD60
00007ac9d05cf0d0  jmp 0x00007AC9D05CF024
00007ac9d05cf0d5  call 0x00007AC9D040DC20
00007ac9d05cf0da  jmp 0x00007AC9D05CF02E
00007ac9d05cf0df  int3
00007ac9d05cf0e0  mov rax, [r15+0x10]
00007ac9d05cf0e4  lea r14, [rax-0x01]
00007ac9d05cf0e8  mov [r15+0x10], r14
00007ac9d05cf0ec  test r14, r14
00007ac9d05cf0ef  setz r14b
00007ac9d05cf0f3  movzx r14, r14b
00007ac9d05cf0f7  mov [rsp+0x414], r14b
00007ac9d05cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007ac9d05cf107  jz 0x00007AC9D05CF139
00007ac9d05cf109  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cf111  jz 0x00007AC9D05D0670
00007ac9d05cf117  nop [rax+rax*1], ax
00007ac9d05cf120  nop [rax+rax*1], eax
00007ac9d05cf128  mov eax, 0x41091C
00007ac9d05cf12d  mov [r15+0x100], rax
00007ac9d05cf134  jmp 0x00007AC9D03FE110
00007ac9d05cf139  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cf141  jz 0x00007AC9D05CEFD0
00007ac9d05cf147  nop [rax+rax*1], ax
00007ac9d05cf150  nop [rax+rax*1], eax
00007ac9d05cf158  mov eax, 0x410704
00007ac9d05cf15d  mov [r15+0x100], rax
00007ac9d05cf164  jmp 0x00007AC9D03FE110
00007ac9d05cf169  int3
00007ac9d05cf16a  int3
00007ac9d05cf16b  nop [rax+rax*1], eax
00007ac9d05cf170  mov rax, [r15+0x40]
00007ac9d05cf174  movzx r14d, byte ptr [r13+rax*1]
00007ac9d05cf17a  movaps xmm1, [r15+0x110]
00007ac9d05cf182  pinsrb xmm1, r14d, 0x00
00007ac9d05cf189  lea r14, [rax+0x01]
00007ac9d05cf18d  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf193  movaps xmm15, [r15+0x120]
00007ac9d05cf19b  pinsrb xmm15, r12d, 0x00
00007ac9d05cf1a2  lea r14, [rax+0x02]
00007ac9d05cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf1ac  movaps xmm14, [r15+0x130]
00007ac9d05cf1b4  pinsrb xmm14, r12d, 0x00
00007ac9d05cf1bb  lea r14, [rax+0x03]
00007ac9d05cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf1c5  movaps xmm13, [r15+0x140]
00007ac9d05cf1cd  pinsrb xmm13, r12d, 0x00
00007ac9d05cf1d4  lea r14, [rax+0x04]
00007ac9d05cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf1de  pinsrb xmm1, r12d, 0x01
00007ac9d05cf1e5  lea r14, [rax+0x05]
00007ac9d05cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf1ef  pinsrb xmm15, r12d, 0x01
00007ac9d05cf1f6  lea r14, [rax+0x06]
00007ac9d05cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf200  pinsrb xmm14, r12d, 0x01
00007ac9d05cf207  lea r14, [rax+0x07]
00007ac9d05cf20b  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf211  pinsrb xmm13, r12d, 0x01
00007ac9d05cf218  lea r14, [rax+0x08]
00007ac9d05cf21c  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf222  pinsrb xmm1, r12d, 0x02
00007ac9d05cf229  lea r14, [rax+0x09]
00007ac9d05cf22d  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf233  pinsrb xmm15, r12d, 0x02
00007ac9d05cf23a  lea r14, [rax+0x0A]
00007ac9d05cf23e  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf244  pinsrb xmm14, r12d, 0x02
00007ac9d05cf24b  lea r14, [rax+0x0B]
00007ac9d05cf24f  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf255  pinsrb xmm13, r12d, 0x02
00007ac9d05cf25c  lea r14, [rax+0x0C]
00007ac9d05cf260  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf266  pinsrb xmm1, r12d, 0x03
00007ac9d05cf26d  lea r14, [rax+0x0D]
00007ac9d05cf271  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf277  pinsrb xmm15, r12d, 0x03
00007ac9d05cf27e  lea r14, [rax+0x0E]
00007ac9d05cf282  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf288  pinsrb xmm14, r12d, 0x03
00007ac9d05cf28f  lea r14, [rax+0x0F]
00007ac9d05cf293  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf299  pinsrb xmm13, r12d, 0x03
00007ac9d05cf2a0  lea r14, [rax+0x10]
00007ac9d05cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf2aa  pinsrb xmm1, r12d, 0x04
00007ac9d05cf2b1  lea r14, [rax+0x11]
00007ac9d05cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf2bb  pinsrb xmm15, r12d, 0x04
00007ac9d05cf2c2  lea r14, [rax+0x12]
00007ac9d05cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf2cc  pinsrb xmm14, r12d, 0x04
00007ac9d05cf2d3  lea r14, [rax+0x13]
00007ac9d05cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf2dd  pinsrb xmm13, r12d, 0x04
00007ac9d05cf2e4  lea r14, [rax+0x14]
00007ac9d05cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf2ee  pinsrb xmm1, r12d, 0x05
00007ac9d05cf2f5  lea r14, [rax+0x15]
00007ac9d05cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf2ff  pinsrb xmm15, r12d, 0x05
00007ac9d05cf306  lea r14, [rax+0x16]
00007ac9d05cf30a  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf310  pinsrb xmm14, r12d, 0x05
00007ac9d05cf317  lea r14, [rax+0x17]
00007ac9d05cf31b  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf321  pinsrb xmm13, r12d, 0x05
00007ac9d05cf328  lea r14, [rax+0x18]
00007ac9d05cf32c  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf332  pinsrb xmm1, r12d, 0x06
00007ac9d05cf339  lea r14, [rax+0x19]
00007ac9d05cf33d  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf343  pinsrb xmm15, r12d, 0x06
00007ac9d05cf34a  lea r14, [rax+0x1A]
00007ac9d05cf34e  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf354  pinsrb xmm14, r12d, 0x06
00007ac9d05cf35b  lea r14, [rax+0x1B]
00007ac9d05cf35f  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf365  pinsrb xmm13, r12d, 0x06
00007ac9d05cf36c  lea r14, [rax+0x1C]
00007ac9d05cf370  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf376  pinsrb xmm1, r12d, 0x07
00007ac9d05cf37d  lea r14, [rax+0x1D]
00007ac9d05cf381  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf387  pinsrb xmm15, r12d, 0x07
00007ac9d05cf38e  lea r14, [rax+0x1E]
00007ac9d05cf392  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf398  pinsrb xmm14, r12d, 0x07
00007ac9d05cf39f  lea r14, [rax+0x1F]
00007ac9d05cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf3a9  pinsrb xmm13, r12d, 0x07
00007ac9d05cf3b0  lea r14, [rax+0x20]
00007ac9d05cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf3ba  pinsrb xmm1, r12d, 0x08
00007ac9d05cf3c1  lea r14, [rax+0x21]
00007ac9d05cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf3cb  pinsrb xmm15, r12d, 0x08
00007ac9d05cf3d2  lea r14, [rax+0x22]
00007ac9d05cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf3dc  pinsrb xmm14, r12d, 0x08
00007ac9d05cf3e3  lea r14, [rax+0x23]
00007ac9d05cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf3ed  pinsrb xmm13, r12d, 0x08
00007ac9d05cf3f4  lea r14, [rax+0x24]
00007ac9d05cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf3fe  pinsrb xmm1, r12d, 0x09
00007ac9d05cf405  lea r14, [rax+0x25]
00007ac9d05cf409  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf40f  pinsrb xmm15, r12d, 0x09
00007ac9d05cf416  lea r14, [rax+0x26]
00007ac9d05cf41a  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf420  pinsrb xmm14, r12d, 0x09
00007ac9d05cf427  lea r14, [rax+0x27]
00007ac9d05cf42b  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf431  pinsrb xmm13, r12d, 0x09
00007ac9d05cf438  lea r14, [rax+0x28]
00007ac9d05cf43c  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf442  pinsrb xmm1, r12d, 0x0A
00007ac9d05cf449  lea r14, [rax+0x29]
00007ac9d05cf44d  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf453  pinsrb xmm15, r12d, 0x0A
00007ac9d05cf45a  lea r14, [rax+0x2A]
00007ac9d05cf45e  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf464  pinsrb xmm14, r12d, 0x0A
00007ac9d05cf46b  lea r14, [rax+0x2B]
00007ac9d05cf46f  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf475  pinsrb xmm13, r12d, 0x0A
00007ac9d05cf47c  lea r14, [rax+0x2C]
00007ac9d05cf480  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf486  pinsrb xmm1, r12d, 0x0B
00007ac9d05cf48d  lea r14, [rax+0x2D]
00007ac9d05cf491  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf497  pinsrb xmm15, r12d, 0x0B
00007ac9d05cf49e  lea r14, [rax+0x2E]
00007ac9d05cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf4a8  pinsrb xmm14, r12d, 0x0B
00007ac9d05cf4af  lea r14, [rax+0x2F]
00007ac9d05cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf4b9  pinsrb xmm13, r12d, 0x0B
00007ac9d05cf4c0  lea r14, [rax+0x30]
00007ac9d05cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf4ca  pinsrb xmm1, r12d, 0x0C
00007ac9d05cf4d1  lea r14, [rax+0x31]
00007ac9d05cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf4db  pinsrb xmm15, r12d, 0x0C
00007ac9d05cf4e2  lea r14, [rax+0x32]
00007ac9d05cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf4ec  pinsrb xmm14, r12d, 0x0C
00007ac9d05cf4f3  lea r14, [rax+0x33]
00007ac9d05cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf4fd  pinsrb xmm13, r12d, 0x0C
00007ac9d05cf504  lea r14, [rax+0x34]
00007ac9d05cf508  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf50e  pinsrb xmm1, r12d, 0x0D
00007ac9d05cf515  lea r14, [rax+0x35]
00007ac9d05cf519  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf51f  pinsrb xmm15, r12d, 0x0D
00007ac9d05cf526  lea r14, [rax+0x36]
00007ac9d05cf52a  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf530  pinsrb xmm14, r12d, 0x0D
00007ac9d05cf537  lea r14, [rax+0x37]
00007ac9d05cf53b  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf541  pinsrb xmm13, r12d, 0x0D
00007ac9d05cf548  lea r14, [rax+0x38]
00007ac9d05cf54c  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf552  pinsrb xmm1, r12d, 0x0E
00007ac9d05cf559  lea r14, [rax+0x39]
00007ac9d05cf55d  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf563  pinsrb xmm15, r12d, 0x0E
00007ac9d05cf56a  lea r14, [rax+0x3A]
00007ac9d05cf56e  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf574  pinsrb xmm14, r12d, 0x0E
00007ac9d05cf57b  lea r14, [rax+0x3B]
00007ac9d05cf57f  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf585  pinsrb xmm13, r12d, 0x0E
00007ac9d05cf58c  lea r14, [rax+0x3C]
00007ac9d05cf590  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf596  pinsrb xmm1, r12d, 0x0F
00007ac9d05cf59d  movaps [r15+0x110], xmm1
00007ac9d05cf5a5  lea r14, [rax+0x3D]
00007ac9d05cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf5af  pinsrb xmm15, r12d, 0x0F
00007ac9d05cf5b6  movaps [r15+0x120], xmm15
00007ac9d05cf5be  lea r14, [rax+0x3E]
00007ac9d05cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007ac9d05cf5c8  pinsrb xmm14, r12d, 0x0F
00007ac9d05cf5cf  movaps [r15+0x130], xmm14
00007ac9d05cf5d7  lea r14, [rax+0x3F]
00007ac9d05cf5db  movzx eax, byte ptr [r13+r14*1]
00007ac9d05cf5e1  pinsrb xmm13, eax, 0x0F
00007ac9d05cf5e8  movaps [r15+0x140], xmm13
00007ac9d05cf5f0  movq xmm1, qword ptr [r15+0x120]
00007ac9d05cf5f9  pmovzxbw xmm1, xmm1
00007ac9d05cf5fe  psllw xmm1, 0x00
00007ac9d05cf603  movaps [r15+0x150], xmm1
00007ac9d05cf60b  movq xmm1, qword ptr [r15+0x130]
00007ac9d05cf614  pmovzxbw xmm1, xmm1
00007ac9d05cf619  psllw xmm1, 0x00
00007ac9d05cf61e  movaps [r15+0x160], xmm1
00007ac9d05cf626  movq xmm1, qword ptr [r15+0x110]
00007ac9d05cf62f  pmovzxbw xmm1, xmm1
00007ac9d05cf634  psllw xmm1, 0x00
00007ac9d05cf639  movaps [r15+0x170], xmm1
00007ac9d05cf641  movaps xmm15, [r15+0x110]
00007ac9d05cf649  pextrq rax, xmm15, 0x01
00007ac9d05cf650  movq xmm15, rax
00007ac9d05cf655  pmovzxbw xmm15, xmm15
00007ac9d05cf65b  psllw xmm15, 0x00
00007ac9d05cf661  movaps [r15+0x180], xmm15
00007ac9d05cf669  movaps xmm14, [r15+0x120]
00007ac9d05cf671  pextrq rax, xmm14, 0x01
00007ac9d05cf678  movq xmm14, rax
00007ac9d05cf67d  pmovzxbw xmm14, xmm14
00007ac9d05cf683  psllw xmm14, 0x00
00007ac9d05cf689  movaps [r15+0x210], xmm14
00007ac9d05cf691  movaps xmm13, [r15+0x130]
00007ac9d05cf699  pextrq rax, xmm13, 0x01
00007ac9d05cf6a0  movq xmm13, rax
00007ac9d05cf6a5  pmovzxbw xmm13, xmm13
00007ac9d05cf6ab  psllw xmm13, 0x00
00007ac9d05cf6b1  movaps [r15+0x220], xmm13
00007ac9d05cf6b9  movq xmm12, qword ptr [r15+0x140]
00007ac9d05cf6c2  pmovzxbw xmm12, xmm12
00007ac9d05cf6c8  psllw xmm12, 0x00
00007ac9d05cf6ce  movaps [r15+0x250], xmm12
00007ac9d05cf6d6  movaps xmm12, [r15+0x140]
00007ac9d05cf6de  pextrq rax, xmm12, 0x01
00007ac9d05cf6e5  movq xmm12, rax
00007ac9d05cf6ea  pmovzxbw xmm12, xmm12
00007ac9d05cf6f0  psllw xmm12, 0x00
00007ac9d05cf6f6  movaps [r15+0x110], xmm12
00007ac9d05cf6fe  movq xmm11, qword ptr [r15+0x150]
00007ac9d05cf707  pmovzxwd xmm11, xmm11
00007ac9d05cf70d  pslld xmm11, 0x10
00007ac9d05cf713  movq xmm10, qword ptr [r15+0x160]
00007ac9d05cf71c  pmovzxwd xmm10, xmm10
00007ac9d05cf722  pslld xmm10, 0x08
00007ac9d05cf728  pextrq rax, xmm1, 0x01
00007ac9d05cf72f  movq xmm1, rax
00007ac9d05cf734  pmovzxwd xmm1, xmm1
00007ac9d05cf739  pslld xmm1, 0x00
00007ac9d05cf73e  movaps [r15+0x260], xmm1
00007ac9d05cf746  pextrq rax, xmm15, 0x01
00007ac9d05cf74d  movq xmm15, rax
00007ac9d05cf752  pmovzxwd xmm15, xmm15
00007ac9d05cf758  pslld xmm15, 0x00
00007ac9d05cf75e  movaps [r15+0x270], xmm15
00007ac9d05cf766  movq xmm9, qword ptr [r15+0x170]
00007ac9d05cf76f  pmovzxwd xmm9, xmm9
00007ac9d05cf775  pslld xmm9, 0x00
00007ac9d05cf77b  pextrq rax, xmm14, 0x01
00007ac9d05cf782  movq xmm14, rax
00007ac9d05cf787  pmovzxwd xmm14, xmm14
00007ac9d05cf78d  pslld xmm14, 0x10
00007ac9d05cf793  movaps [r15+0x280], xmm14
00007ac9d05cf79b  movq xmm8, qword ptr [r15+0x180]
00007ac9d05cf7a4  pmovzxwd xmm8, xmm8
00007ac9d05cf7aa  pslld xmm8, 0x00
00007ac9d05cf7b0  movq xmm7, qword ptr [r15+0x210]
00007ac9d05cf7b9  pmovzxwd xmm7, xmm7
00007ac9d05cf7be  pslld xmm7, 0x10
00007ac9d05cf7c3  movaps xmm6, [r15+0x150]
00007ac9d05cf7cb  pextrq rax, xmm6, 0x01
00007ac9d05cf7d2  movq xmm6, rax
00007ac9d05cf7d7  pmovzxwd xmm6, xmm6
00007ac9d05cf7dc  pslld xmm6, 0x10
00007ac9d05cf7e1  por xmm11, xmm10
00007ac9d05cf7e6  movaps [r15+0x230], xmm11
00007ac9d05cf7ee  pextrq rax, xmm13, 0x01
00007ac9d05cf7f5  movq xmm13, rax
00007ac9d05cf7fa  pmovzxwd xmm13, xmm13
00007ac9d05cf800  pslld xmm13, 0x08
00007ac9d05cf806  movaps [r15+0x240], xmm13
00007ac9d05cf80e  movq xmm10, qword ptr [r15+0x220]
00007ac9d05cf817  pmovzxwd xmm10, xmm10
00007ac9d05cf81d  pslld xmm10, 0x08
00007ac9d05cf823  movaps xmm5, [r15+0x160]
00007ac9d05cf82b  pextrq rax, xmm5, 0x01
00007ac9d05cf832  movq xmm5, rax
00007ac9d05cf837  pmovzxwd xmm5, xmm5
00007ac9d05cf83c  pslld xmm5, 0x08
00007ac9d05cf841  pslld xmm9, 0x18
00007ac9d05cf847  pslld xmm15, 0x18
00007ac9d05cf84d  pslld xmm8, 0x18
00007ac9d05cf853  movq xmm4, qword ptr [r15+0x250]
00007ac9d05cf85c  pmovzxwd xmm4, xmm4
00007ac9d05cf861  pslld xmm4, 0x00
00007ac9d05cf866  por xmm14, xmm13
00007ac9d05cf86b  por xmm7, xmm10
00007ac9d05cf870  movaps [r15+0x210], xmm7
00007ac9d05cf878  pslld xmm1, 0x18
00007ac9d05cf87d  movaps [r15+0x220], xmm1
00007ac9d05cf885  por xmm6, xmm5
00007ac9d05cf889  por xmm11, xmm9
00007ac9d05cf88e  movaps [r15+0x160], xmm11
00007ac9d05cf896  pextrq rax, xmm12, 0x01
00007ac9d05cf89d  movq xmm13, rax
00007ac9d05cf8a2  pmovzxwd xmm13, xmm13
00007ac9d05cf8a8  pslld xmm13, 0x00
00007ac9d05cf8ae  movaps [r15+0x170], xmm13
00007ac9d05cf8b6  movq xmm12, qword ptr [r15+0x110]
00007ac9d05cf8bf  pmovzxwd xmm12, xmm12
00007ac9d05cf8c5  pslld xmm12, 0x00
00007ac9d05cf8cb  por xmm14, xmm15
00007ac9d05cf8d0  por xmm7, xmm8
00007ac9d05cf8d5  movaps xmm15, [r15+0x250]
00007ac9d05cf8dd  pextrq rax, xmm15, 0x01
00007ac9d05cf8e4  movq xmm15, rax
00007ac9d05cf8e9  pmovzxwd xmm15, xmm15
00007ac9d05cf8ef  pslld xmm15, 0x00
00007ac9d05cf8f5  movaps [r15+0x180], xmm15
00007ac9d05cf8fd  por xmm6, xmm1
00007ac9d05cf901  movaps [r15+0x150], xmm6
00007ac9d05cf909  por xmm11, xmm4
00007ac9d05cf90e  movaps [r15+0x140], xmm11
00007ac9d05cf916  por xmm7, xmm12
00007ac9d05cf91b  movaps [r15+0x110], xmm7
00007ac9d05cf923  por xmm14, xmm13
00007ac9d05cf928  movaps [r15+0x120], xmm14
00007ac9d05cf930  por xmm6, xmm15
00007ac9d05cf935  movaps [r15+0x130], xmm6
00007ac9d05cf93d  mov rax, [r15+0xF8]
00007ac9d05cf944  lea r14, [rax+0x20]
00007ac9d05cf948  movups [r13+r14*1], xmm7
00007ac9d05cf94e  lea r14, [rax+0x30]
00007ac9d05cf952  movups [r13+r14*1], xmm14
00007ac9d05cf958  movups [r13+rax*1], xmm11
00007ac9d05cf95e  lea r14, [rax+0x10]
00007ac9d05cf962  movups [r13+r14*1], xmm6
00007ac9d05cf968  mov r14d, [r13+rax*1]
00007ac9d05cf96d  mov rax, [r15+0x48]
00007ac9d05cf971  mov [r15+0x68], rax
00007ac9d05cf975  mov qword ptr [r15+0x58], 0x04
00007ac9d05cf97d  lea r12, [rax+0x04]
00007ac9d05cf981  mov r11d, [r13+r12*1]
00007ac9d05cf986  mov [rsp+0x10], r11d
00007ac9d05cf98b  mov r11d, r11d
00007ac9d05cf98e  mov [r15+0x70], r11
00007ac9d05cf992  lea r12, [rax+0x38]
00007ac9d05cf996  mov r11d, [r13+r12*1]
00007ac9d05cf99b  lea r12, [rax+0x24]
00007ac9d05cf99f  mov r10d, [r13+r12*1]
00007ac9d05cf9a4  mov [rsp+0x20], r10d
00007ac9d05cf9a9  mov r10d, r10d
00007ac9d05cf9ac  mov [r15+0x90], r10
00007ac9d05cf9b3  mov [rsp+0x30], rax
00007ac9d05cf9b8  xor eax, eax
00007ac9d05cf9ba  mov r12d, 0x04
00007ac9d05cf9c0  mov r10d, 0xC0
00007ac9d05cf9c6  cmp r12, r10
00007ac9d05cf9c9  cmc
00007ac9d05cf9ca  lahf
00007ac9d05cf9cb  seto al
00007ac9d05cf9ce  mov [r15+0x108], eax
00007ac9d05cf9d5  mov eax, [rsp+0x10]
00007ac9d05cf9d9  mov r12d, [rsp+0x10]
00007ac9d05cf9de  shrd eax, r12d, 0x07
00007ac9d05cf9e3  mov [rsp+0x10], r11d
00007ac9d05cf9e8  mov r10d, [rsp+0x10]
00007ac9d05cf9ed  shrd r11d, r10d, 0x11
00007ac9d05cf9f2  mov r9d, [rsp+0x20]
00007ac9d05cf9f7  lea r8d, [r9d+r14d*1]
00007ac9d05cf9fc  rorx r14d, r12d, 0x12
00007ac9d05cfa02  xor eax, r14d
00007ac9d05cfa05  rorx r14d, r10d, 0x13
00007ac9d05cfa0b  xor r11d, r14d
00007ac9d05cfa0e  mov [rsp+0x10], r11d
00007ac9d05cfa13  mov r11d, r11d
00007ac9d05cfa16  mov [r15+0x88], r11
00007ac9d05cfa1d  mov [rsp+0x20], r12d
00007ac9d05cfa22  shr r12d, 0x03
00007ac9d05cfa26  xor eax, r12d
00007ac9d05cfa29  mov [rsp+0x40], eax
00007ac9d05cfa2d  mov eax, eax
00007ac9d05cfa2f  mov [r15+0x80], rax
00007ac9d05cfa36  shr r10d, 0x0A
00007ac9d05cfa3a  mov eax, [rsp+0x10]
00007ac9d05cfa3e  xor eax, r10d
00007ac9d05cfa41  mov [rsp+0x10], eax
00007ac9d05cfa45  mov eax, eax
00007ac9d05cfa47  mov [r15+0x78], rax
00007ac9d05cfa4b  mov eax, [rsp+0x40]
00007ac9d05cfa4f  lea r14d, [r8d+eax*1]
00007ac9d05cfa54  mov eax, [rsp+0x10]
00007ac9d05cfa58  lea r12d, [r14d+eax*1]
00007ac9d05cfa5d  mov rax, [rsp+0x30]
00007ac9d05cfa62  lea r14, [rax+0x40]
00007ac9d05cfa66  mov [r13+r14*1], r12d
00007ac9d05cfa6b  mov eax, [rsp+0x20]
00007ac9d05cfa6f  mov eax, eax
00007ac9d05cfa71  mov [r15+0x60], rax
00007ac9d05cfa75  mov eax, [r15+0x108]
00007ac9d05cfa7c  sahf
00007ac9d05cfa7d  jnz 0x00007AC9D05CFAAF
00007ac9d05cfa7f  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cfa87  jz 0x00007AC9D05CFF70
00007ac9d05cfa8d  nop [rax+rax*1], ax
00007ac9d05cfa96  nop [rax+rax*1], eax
00007ac9d05cfa9e  mov eax, 0x410820
00007ac9d05cfaa3  mov [r15+0x100], rax
00007ac9d05cfaaa  jmp 0x00007AC9D03FE110
00007ac9d05cfaaf  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cfab7  jz 0x00007AC9D05CFDC0
00007ac9d05cfabd  nop [rax+rax*1], ax
00007ac9d05cfac6  nop [rax+rax*1], eax
00007ac9d05cface  mov eax, 0x4107D8
00007ac9d05cfad3  mov [r15+0x100], rax
00007ac9d05cfada  jmp 0x00007AC9D03FE110
00007ac9d05cfadf  int3
00007ac9d05cfae0  call 0x00007AC9D040D860
00007ac9d05cfae5  jmp 0x00007AC9D05CF17A
00007ac9d05cfaea  call 0x00007AC9D04E2420
00007ac9d05cfaef  jmp 0x00007AC9D05CF193
00007ac9d05cfaf4  call 0x00007AC9D04E2420
00007ac9d05cfaf9  jmp 0x00007AC9D05CF1AC
00007ac9d05cfafe  call 0x00007AC9D04E2420
00007ac9d05cfb03  jmp 0x00007AC9D05CF1C5
00007ac9d05cfb08  call 0x00007AC9D04E2420
00007ac9d05cfb0d  jmp 0x00007AC9D05CF1DE
00007ac9d05cfb12  call 0x00007AC9D04E2420
00007ac9d05cfb17  jmp 0x00007AC9D05CF1EF
00007ac9d05cfb1c  call 0x00007AC9D04E2420
00007ac9d05cfb21  jmp 0x00007AC9D05CF200
00007ac9d05cfb26  call 0x00007AC9D04E2420
00007ac9d05cfb2b  jmp 0x00007AC9D05CF211
00007ac9d05cfb30  call 0x00007AC9D04E2420
00007ac9d05cfb35  jmp 0x00007AC9D05CF222
00007ac9d05cfb3a  call 0x00007AC9D04E2420
00007ac9d05cfb3f  jmp 0x00007AC9D05CF233
00007ac9d05cfb44  call 0x00007AC9D04E2420
00007ac9d05cfb49  jmp 0x00007AC9D05CF244
00007ac9d05cfb4e  call 0x00007AC9D04E2420
00007ac9d05cfb53  jmp 0x00007AC9D05CF255
00007ac9d05cfb58  call 0x00007AC9D04E2420
00007ac9d05cfb5d  jmp 0x00007AC9D05CF266
00007ac9d05cfb62  call 0x00007AC9D04E2420
00007ac9d05cfb67  jmp 0x00007AC9D05CF277
00007ac9d05cfb6c  call 0x00007AC9D04E2420
00007ac9d05cfb71  jmp 0x00007AC9D05CF288
00007ac9d05cfb76  call 0x00007AC9D04E2420
00007ac9d05cfb7b  jmp 0x00007AC9D05CF299
00007ac9d05cfb80  call 0x00007AC9D04E2420
00007ac9d05cfb85  jmp 0x00007AC9D05CF2AA
00007ac9d05cfb8a  call 0x00007AC9D04E2420
00007ac9d05cfb8f  jmp 0x00007AC9D05CF2BB
00007ac9d05cfb94  call 0x00007AC9D04E2420
00007ac9d05cfb99  jmp 0x00007AC9D05CF2CC
00007ac9d05cfb9e  call 0x00007AC9D04E2420
00007ac9d05cfba3  jmp 0x00007AC9D05CF2DD
00007ac9d05cfba8  call 0x00007AC9D04E2420
00007ac9d05cfbad  jmp 0x00007AC9D05CF2EE
00007ac9d05cfbb2  call 0x00007AC9D04E2420
00007ac9d05cfbb7  jmp 0x00007AC9D05CF2FF
00007ac9d05cfbbc  call 0x00007AC9D04E2420
00007ac9d05cfbc1  jmp 0x00007AC9D05CF310
00007ac9d05cfbc6  call 0x00007AC9D04E2420
00007ac9d05cfbcb  jmp 0x00007AC9D05CF321
00007ac9d05cfbd0  call 0x00007AC9D04E2420
00007ac9d05cfbd5  jmp 0x00007AC9D05CF332
00007ac9d05cfbda  call 0x00007AC9D04E2420
00007ac9d05cfbdf  jmp 0x00007AC9D05CF343
00007ac9d05cfbe4  call 0x00007AC9D04E2420
00007ac9d05cfbe9  jmp 0x00007AC9D05CF354
00007ac9d05cfbee  call 0x00007AC9D04E2420
00007ac9d05cfbf3  jmp 0x00007AC9D05CF365
00007ac9d05cfbf8  call 0x00007AC9D04E2420
00007ac9d05cfbfd  jmp 0x00007AC9D05CF376
00007ac9d05cfc02  call 0x00007AC9D04E2420
00007ac9d05cfc07  jmp 0x00007AC9D05CF387
00007ac9d05cfc0c  call 0x00007AC9D04E2420
00007ac9d05cfc11  jmp 0x00007AC9D05CF398
00007ac9d05cfc16  call 0x00007AC9D04E2420
00007ac9d05cfc1b  jmp 0x00007AC9D05CF3A9
00007ac9d05cfc20  call 0x00007AC9D04E2420
00007ac9d05cfc25  jmp 0x00007AC9D05CF3BA
00007ac9d05cfc2a  call 0x00007AC9D04E2420
00007ac9d05cfc2f  jmp 0x00007AC9D05CF3CB
00007ac9d05cfc34  call 0x00007AC9D04E2420
00007ac9d05cfc39  jmp 0x00007AC9D05CF3DC
00007ac9d05cfc3e  call 0x00007AC9D04E2420
00007ac9d05cfc43  jmp 0x00007AC9D05CF3ED
00007ac9d05cfc48  call 0x00007AC9D04E2420
00007ac9d05cfc4d  jmp 0x00007AC9D05CF3FE
00007ac9d05cfc52  call 0x00007AC9D04E2420
00007ac9d05cfc57  jmp 0x00007AC9D05CF40F
00007ac9d05cfc5c  call 0x00007AC9D04E2420
00007ac9d05cfc61  jmp 0x00007AC9D05CF420
00007ac9d05cfc66  call 0x00007AC9D04E2420
00007ac9d05cfc6b  jmp 0x00007AC9D05CF431
00007ac9d05cfc70  call 0x00007AC9D04E2420
00007ac9d05cfc75  jmp 0x00007AC9D05CF442
00007ac9d05cfc7a  call 0x00007AC9D04E2420
00007ac9d05cfc7f  jmp 0x00007AC9D05CF453
00007ac9d05cfc84  call 0x00007AC9D04E2420
00007ac9d05cfc89  jmp 0x00007AC9D05CF464
00007ac9d05cfc8e  call 0x00007AC9D04E2420
00007ac9d05cfc93  jmp 0x00007AC9D05CF475
00007ac9d05cfc98  call 0x00007AC9D04E2420
00007ac9d05cfc9d  jmp 0x00007AC9D05CF486
00007ac9d05cfca2  call 0x00007AC9D04E2420
00007ac9d05cfca7  jmp 0x00007AC9D05CF497
00007ac9d05cfcac  call 0x00007AC9D04E2420
00007ac9d05cfcb1  jmp 0x00007AC9D05CF4A8
00007ac9d05cfcb6  call 0x00007AC9D04E2420
00007ac9d05cfcbb  jmp 0x00007AC9D05CF4B9
00007ac9d05cfcc0  call 0x00007AC9D04E2420
00007ac9d05cfcc5  jmp 0x00007AC9D05CF4CA
00007ac9d05cfcca  call 0x00007AC9D04E2420
00007ac9d05cfccf  jmp 0x00007AC9D05CF4DB
00007ac9d05cfcd4  call 0x00007AC9D04E2420
00007ac9d05cfcd9  jmp 0x00007AC9D05CF4EC
00007ac9d05cfcde  call 0x00007AC9D04E2420
00007ac9d05cfce3  jmp 0x00007AC9D05CF4FD
00007ac9d05cfce8  call 0x00007AC9D04E2420
00007ac9d05cfced  jmp 0x00007AC9D05CF50E
00007ac9d05cfcf2  call 0x00007AC9D04E2420
00007ac9d05cfcf7  jmp 0x00007AC9D05CF51F
00007ac9d05cfcfc  call 0x00007AC9D04E2420
00007ac9d05cfd01  jmp 0x00007AC9D05CF530
00007ac9d05cfd06  call 0x00007AC9D04E2420
00007ac9d05cfd0b  jmp 0x00007AC9D05CF541
00007ac9d05cfd10  call 0x00007AC9D04E2420
00007ac9d05cfd15  jmp 0x00007AC9D05CF552
00007ac9d05cfd1a  call 0x00007AC9D04E2420
00007ac9d05cfd1f  jmp 0x00007AC9D05CF563
00007ac9d05cfd24  call 0x00007AC9D04E2420
00007ac9d05cfd29  jmp 0x00007AC9D05CF574
00007ac9d05cfd2e  call 0x00007AC9D04E2420
00007ac9d05cfd33  jmp 0x00007AC9D05CF585
00007ac9d05cfd38  call 0x00007AC9D04E2420
00007ac9d05cfd3d  jmp 0x00007AC9D05CF596
00007ac9d05cfd42  call 0x00007AC9D04E2420
00007ac9d05cfd47  jmp 0x00007AC9D05CF5AF
00007ac9d05cfd4c  call 0x00007AC9D04E2420
00007ac9d05cfd51  jmp 0x00007AC9D05CF5C8
00007ac9d05cfd56  call 0x00007AC9D04D5610
00007ac9d05cfd5b  jmp 0x00007AC9D05CF5E1
00007ac9d05cfd60  call 0x00007AC9D04DC580
00007ac9d05cfd65  jmp 0x00007AC9D05CF94E
00007ac9d05cfd6a  call 0x00007AC9D04E46C0
00007ac9d05cfd6f  jmp 0x00007AC9D05CF958
00007ac9d05cfd74  call 0x00007AC9D0409E90
00007ac9d05cfd79  jmp 0x00007AC9D05CF95E
00007ac9d05cfd7e  call 0x00007AC9D04DB310
00007ac9d05cfd83  jmp 0x00007AC9D05CF968
00007ac9d05cfd88  call 0x00007AC9D040DAE0
00007ac9d05cfd8d  jmp 0x00007AC9D05CF96D
00007ac9d05cfd92  call 0x00007AC9D04C0230
00007ac9d05cfd97  jmp 0x00007AC9D05CF986
00007ac9d05cfd9c  call 0x00007AC9D04C0230
00007ac9d05cfda1  jmp 0x00007AC9D05CF99B
00007ac9d05cfda6  call 0x00007AC9D04BEFC0
00007ac9d05cfdab  jmp 0x00007AC9D05CF9A4
00007ac9d05cfdb0  call 0x00007AC9D04E2BA0
00007ac9d05cfdb5  jmp 0x00007AC9D05CFA6B
00007ac9d05cfdba  int3
00007ac9d05cfdbb  nop [rax+rax*1], eax
00007ac9d05cfdc0  mov rax, [r15+0x48]
00007ac9d05cfdc4  mov r14, [r15+0x58]
00007ac9d05cfdc8  lea r12, [rax+r14*1]
00007ac9d05cfdcc  mov [r15+0x68], r12
00007ac9d05cfdd0  lea rax, [r14+0x04]
00007ac9d05cfdd4  mov [r15+0x58], rax
00007ac9d05cfdd8  lea r14, [r12+0x04]
00007ac9d05cfddd  mov r11d, [r13+r14*1]
00007ac9d05cfde2  mov [rsp+0x10], r11d
00007ac9d05cfde7  mov r11d, r11d
00007ac9d05cfdea  mov [r15+0x70], r11
00007ac9d05cfdee  lea r14, [r12+0x38]
00007ac9d05cfdf3  mov r11d, [r13+r14*1]
00007ac9d05cfdf8  lea r14, [r12+0x24]
00007ac9d05cfdfd  mov r10d, [r13+r14*1]
00007ac9d05cfe02  mov [rsp+0x20], r10d
00007ac9d05cfe07  mov r10d, r10d
00007ac9d05cfe0a  mov [r15+0x90], r10
00007ac9d05cfe11  mov [rsp+0x30], rax
00007ac9d05cfe16  xor eax, eax
00007ac9d05cfe18  mov r14, [rsp+0x30]
00007ac9d05cfe1d  mov r10d, 0xC0
00007ac9d05cfe23  cmp r14, r10
00007ac9d05cfe26  cmc
00007ac9d05cfe27  lahf
00007ac9d05cfe28  seto al
00007ac9d05cfe2b  mov [r15+0x108], eax
00007ac9d05cfe32  mov eax, [rsp+0x10]
00007ac9d05cfe36  mov r14d, [rsp+0x10]
00007ac9d05cfe3b  shrd eax, r14d, 0x07
00007ac9d05cfe40  mov [rsp+0x10], r11d
00007ac9d05cfe45  mov r10d, [rsp+0x10]
00007ac9d05cfe4a  shrd r11d, r10d, 0x11
00007ac9d05cfe4f  mov r9d, [r15+0x60]
00007ac9d05cfe53  mov r8d, [rsp+0x20]
00007ac9d05cfe58  lea ebp, [r8d+r9d*1]
00007ac9d05cfe5d  rorx r9d, r14d, 0x12
00007ac9d05cfe63  xor eax, r9d
00007ac9d05cfe66  rorx r9d, r10d, 0x13
00007ac9d05cfe6c  xor r11d, r9d
00007ac9d05cfe6f  mov [rsp+0x10], r11d
00007ac9d05cfe74  mov r11d, r11d
00007ac9d05cfe77  mov [r15+0x88], r11
00007ac9d05cfe7e  mov [rsp+0x20], r14d
00007ac9d05cfe83  shr r14d, 0x03
00007ac9d05cfe87  xor eax, r14d
00007ac9d05cfe8a  mov [rsp+0x30], eax
00007ac9d05cfe8e  mov eax, eax
00007ac9d05cfe90  mov [r15+0x80], rax
00007ac9d05cfe97  shr r10d, 0x0A
00007ac9d05cfe9b  mov eax, [rsp+0x10]
00007ac9d05cfe9f  xor eax, r10d
00007ac9d05cfea2  mov [rsp+0x10], eax
00007ac9d05cfea6  mov eax, eax
00007ac9d05cfea8  mov [r15+0x78], rax
00007ac9d05cfeac  mov eax, [rsp+0x30]
00007ac9d05cfeb0  lea r14d, [ebp+eax*1]
00007ac9d05cfeb6  mov eax, [rsp+0x10]
00007ac9d05cfeba  lea r11d, [r14d+eax*1]
00007ac9d05cfebf  lea rax, [r12+0x40]
00007ac9d05cfec4  mov [r13+rax*1], r11d
00007ac9d05cfec9  mov eax, [rsp+0x20]
00007ac9d05cfecd  mov eax, eax
00007ac9d05cfecf  mov [r15+0x60], rax
00007ac9d05cfed3  mov eax, [r15+0x108]
00007ac9d05cfeda  sahf
00007ac9d05cfedb  jnz 0x00007AC9D05CFF0D
00007ac9d05cfedd  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cfee5  jz 0x00007AC9D05CFF70
00007ac9d05cfeeb  nop [rax+rax*1], ax
00007ac9d05cfef4  nop [rax+rax*1], eax
00007ac9d05cfefc  mov eax, 0x410820
00007ac9d05cff01  mov [r15+0x100], rax
00007ac9d05cff08  jmp 0x00007AC9D03FE110
00007ac9d05cff0d  cmp dword ptr [r15+0x318], 0x00
00007ac9d05cff15  jz 0x00007AC9D05CFDC0
00007ac9d05cff1b  nop [rax+rax*1], ax
00007ac9d05cff24  nop [rax+rax*1], eax
00007ac9d05cff2c  mov eax, 0x4107D8
00007ac9d05cff31  mov [r15+0x100], rax
00007ac9d05cff38  jmp 0x00007AC9D03FE110
00007ac9d05cff3d  int3
00007ac9d05cff3e  call 0x00007AC9D04E1430
00007ac9d05cff43  jmp 0x00007AC9D05CFDE2
00007ac9d05cff48  call 0x00007AC9D04E1430
00007ac9d05cff4d  jmp 0x00007AC9D05CFDF8
00007ac9d05cff52  call 0x00007AC9D04E01C0
00007ac9d05cff57  jmp 0x00007AC9D05CFE02
00007ac9d05cff5c  call 0x00007AC9D040A860
00007ac9d05cff61  jmp 0x00007AC9D05CFEC9
00007ac9d05cff66  int3
00007ac9d05cff67  nop [rax+rax*1], ax
00007ac9d05cff70  mov rax, [r15]
00007ac9d05cff73  mov r14d, [r13+rax*1]
00007ac9d05cff78  lea r12, [rax+0x04]
00007ac9d05cff7c  mov r11d, [r13+r12*1]
00007ac9d05cff81  mov [rsp+0x10], r14d
00007ac9d05cff86  mov r14d, r14d
00007ac9d05cff89  mov [r15+0x78], r14
00007ac9d05cff8d  mov [rsp+0x20], r11d
00007ac9d05cff92  mov r11d, r11d
00007ac9d05cff95  mov [r15+0x80], r11
00007ac9d05cff9c  lea r14, [rax+0x08]
00007ac9d05cffa0  mov r12d, [r13+r14*1]
00007ac9d05cffa5  lea r14, [rax+0x0C]
00007ac9d05cffa9  mov r11d, [r13+r14*1]
00007ac9d05cffae  mov [rsp+0x30], r12d
00007ac9d05cffb3  mov r12d, r12d
00007ac9d05cffb6  mov [r15+0x70], r12
00007ac9d05cffba  mov [rsp+0x40], r11d
00007ac9d05cffbf  mov r11d, r11d
00007ac9d05cffc2  mov [r15+0x68], r11
00007ac9d05cffc6  lea r14, [rax+0x18]
00007ac9d05cffca  mov r12d, [r13+r14*1]
00007ac9d05cffcf  lea r14, [rax+0x1C]
00007ac9d05cffd3  mov r11d, [r13+r14*1]
00007ac9d05cffd8  mov [rsp+0x50], r12d
00007ac9d05cffdd  mov r12d, r12d
00007ac9d05cffe0  mov [r15+0x58], r12
00007ac9d05cffe4  mov [rsp+0x60], r11d
00007ac9d05cffe9  mov r11d, r11d
00007ac9d05cffec  mov [r15+0x60], r11
00007ac9d05cfff0  lea r14, [rax+0x10]
00007ac9d05cfff4  mov r12d, [r13+r14*1]
00007ac9d05cfff9  lea r14, [rax+0x14]
00007ac9d05cfffd  mov eax, [r13+r14*1]
00007ac9d05d0002  mov [rsp+0x70], r12d
00007ac9d05d0007  mov r12d, r12d
00007ac9d05d000a  mov [r15+0x18], r12
00007ac9d05d000e  mov [rsp+0x80], eax
00007ac9d05d0015  mov eax, eax
00007ac9d05d0017  mov [r15+0x90], rax
00007ac9d05d001e  mov eax, [rsp+0x70]
00007ac9d05d0022  mov eax, eax
00007ac9d05d0024  mov [r15+0x30], rax
00007ac9d05d0028  mov eax, [rsp+0x50]
00007ac9d05d002c  mov eax, eax
00007ac9d05d002e  mov [r15+0xA0], rax
00007ac9d05d0035  mov eax, [rsp+0x30]
00007ac9d05d0039  mov eax, eax
00007ac9d05d003b  mov [r15+0x28], rax
00007ac9d05d003f  mov eax, [rsp+0x20]
00007ac9d05d0043  mov eax, eax
00007ac9d05d0045  mov [r15+0x98], rax
00007ac9d05d004c  mov eax, [rsp+0x10]
00007ac9d05d0050  mov eax, eax
00007ac9d05d0052  mov [r15+0x38], rax
00007ac9d05d0056  mov eax, [rsp+0x70]
00007ac9d05d005a  mov r14d, [rsp+0x70]
00007ac9d05d005f  shrd eax, r14d, 0x06
00007ac9d05d0064  mov [rsp+0x70], r14d
00007ac9d05d0069  mov r12d, [rsp+0x80]
00007ac9d05d0071  and r14d, r12d
00007ac9d05d0074  mov r11d, [rsp+0x10]
00007ac9d05d0079  mov r10d, [rsp+0x10]
00007ac9d05d007e  shrd r11d, r10d, 0x02
00007ac9d05d0083  mov [rsp+0x10], r12d
00007ac9d05d0088  mov r12d, r12d
00007ac9d05d008b  mov [r15+0x20], r12
00007ac9d05d008f  mov r12, [r15+0x50]
00007ac9d05d0093  mov r9d, [r13+r12*1]
00007ac9d05d0098  mov r12d, [rsp+0x50]
00007ac9d05d009d  mov r8d, [rsp+0x70]
00007ac9d05d00a2  andn ebp, r8d, r12d
00007ac9d05d00a7  mov edi, [rsp+0x60]
00007ac9d05d00ab  lea esi, [r14d+edi*1]
00007ac9d05d00b0  rorx r14d, r8d, 0x0B
00007ac9d05d00b6  xor eax, r14d
00007ac9d05d00b9  rorx r14d, r10d, 0x0D
00007ac9d05d00bf  xor r11d, r14d
00007ac9d05d00c2  lea edi, [esi+ebp*1]
00007ac9d05d00c6  mov r14, [r15+0x48]
00007ac9d05d00ca  mov ebp, [r13+r14*1]
00007ac9d05d00cf  mov r14d, [rsp+0x30]
00007ac9d05d00d4  mov esi, [rsp+0x20]
00007ac9d05d00d8  and r14d, esi
00007ac9d05d00db  mov [rsp+0x20], r14d
00007ac9d05d00e0  mov r14d, r14d
00007ac9d05d00e3  mov [r15+0xD8], r14
00007ac9d05d00ea  lea r14d, [edi+r9d*1]
00007ac9d05d00ef  mov r9d, [rsp+0x30]
00007ac9d05d00f4  xor r9d, esi
00007ac9d05d00f7  rorx edi, r8d, 0x19
00007ac9d05d00fd  xor eax, edi
00007ac9d05d00ff  and r9d, r10d
00007ac9d05d0102  rorx edi, r10d, 0x16
00007ac9d05d0108  xor r11d, edi
00007ac9d05d010b  mov [rsp+0x30], r11d
00007ac9d05d0110  mov r11d, r11d
00007ac9d05d0113  mov [r15+0xD0], r11
00007ac9d05d011a  lea r11d, [r14d+ebp*1]
00007ac9d05d011f  mov r10d, [rsp+0x20]
00007ac9d05d0124  xor r9d, r10d
00007ac9d05d0127  lea r14d, [r11d+eax*1]
00007ac9d05d012c  mov qword ptr [r15+0x88], 0x04
00007ac9d05d0137  mov eax, [rsp+0x30]
00007ac9d05d013b  lea r11d, [r9d+eax*1]
00007ac9d05d0140  mov eax, [rsp+0x40]
00007ac9d05d0144  lea r10d, [r14d+eax*1]
00007ac9d05d0149  mov r10d, r10d
00007ac9d05d014c  mov [r15+0xB8], r10
00007ac9d05d0153  xor eax, eax
00007ac9d05d0155  mov r10d, 0x04
00007ac9d05d015b  mov r9d, 0x100
00007ac9d05d0161  cmp r10, r9
00007ac9d05d0164  cmc
00007ac9d05d0165  lahf
00007ac9d05d0166  seto al
00007ac9d05d0169  mov [r15+0x108], eax
00007ac9d05d0170  lea eax, [r11d+r14d*1]
00007ac9d05d0175  mov eax, eax
00007ac9d05d0177  mov [r15+0xA8], rax
00007ac9d05d017e  mov r12d, r12d
00007ac9d05d0181  mov [r15+0xB0], r12
00007ac9d05d0188  mov eax, [rsp+0x10]
00007ac9d05d018c  mov eax, eax
00007ac9d05d018e  mov [r15+0xC0], rax
00007ac9d05d0195  mov r8d, r8d
00007ac9d05d0198  mov [r15+0xC8], r8
00007ac9d05d019f  mov eax, [r15+0x108]
00007ac9d05d01a6  sahf
00007ac9d05d01a7  jnz 0x00007AC9D05D01D9
00007ac9d05d01a9  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d01b1  jz 0x00007AC9D05D04A0
00007ac9d05d01b7  nop [rax+rax*1], ax
00007ac9d05d01c0  nop [rax+rax*1], eax
00007ac9d05d01c8  mov eax, 0x4108E0
00007ac9d05d01cd  mov [r15+0x100], rax
00007ac9d05d01d4  jmp 0x00007AC9D03FE110
00007ac9d05d01d9  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d01e1  jz 0x00007AC9D05D0270
00007ac9d05d01e7  nop [rax+rax*1], ax
00007ac9d05d01f0  nop [rax+rax*1], eax
00007ac9d05d01f8  mov eax, 0x410854
00007ac9d05d01fd  mov [r15+0x100], rax
00007ac9d05d0204  jmp 0x00007AC9D03FE110
00007ac9d05d0209  int3
00007ac9d05d020a  call 0x00007AC9D040DAE0
00007ac9d05d020f  jmp 0x00007AC9D05CFF78
00007ac9d05d0214  call 0x00007AC9D04C0230
00007ac9d05d0219  jmp 0x00007AC9D05CFF81
00007ac9d05d021e  call 0x00007AC9D04E26A0
00007ac9d05d0223  jmp 0x00007AC9D05CFFA5
00007ac9d05d0228  call 0x00007AC9D04E1430
00007ac9d05d022d  jmp 0x00007AC9D05CFFAE
00007ac9d05d0232  call 0x00007AC9D04E26A0
00007ac9d05d0237  jmp 0x00007AC9D05CFFCF
00007ac9d05d023c  call 0x00007AC9D04E1430
00007ac9d05d0241  jmp 0x00007AC9D05CFFD8
00007ac9d05d0246  call 0x00007AC9D04E26A0
00007ac9d05d024b  jmp 0x00007AC9D05CFFF9
00007ac9d05d0250  call 0x00007AC9D04D5890
00007ac9d05d0255  jmp 0x00007AC9D05D0002
00007ac9d05d025a  call 0x00007AC9D04BDD50
00007ac9d05d025f  jmp 0x00007AC9D05D0098
00007ac9d05d0264  call 0x00007AC9D04DA580
00007ac9d05d0269  jmp 0x00007AC9D05D00CF
00007ac9d05d026e  int3
00007ac9d05d026f  nop
00007ac9d05d0270  mov eax, [r15+0xB8]
00007ac9d05d0277  mov [rsp+0x10], eax
00007ac9d05d027b  mov eax, eax
00007ac9d05d027d  mov [r15+0x30], rax
00007ac9d05d0281  mov eax, [r15+0xC0]
00007ac9d05d0288  mov [rsp+0x20], eax
00007ac9d05d028c  mov eax, eax
00007ac9d05d028e  mov [r15+0xA0], rax
00007ac9d05d0295  mov eax, [r15+0x28]
00007ac9d05d0299  mov r14d, [r15+0x98]
00007ac9d05d02a0  mov [rsp+0x30], r14d
00007ac9d05d02a5  mov r14d, r14d
00007ac9d05d02a8  mov [r15+0x28], r14
00007ac9d05d02ac  mov r14d, [r15+0x38]
00007ac9d05d02b0  mov [rsp+0x40], r14d
00007ac9d05d02b5  mov r14d, r14d
00007ac9d05d02b8  mov [r15+0x98], r14
00007ac9d05d02bf  mov r14d, [r15+0xA8]
00007ac9d05d02c6  mov [rsp+0x50], r14d
00007ac9d05d02cb  mov r14d, r14d
00007ac9d05d02ce  mov [r15+0x38], r14
00007ac9d05d02d2  mov r14d, [rsp+0x10]
00007ac9d05d02d7  mov r12d, [rsp+0x10]
00007ac9d05d02dc  shrd r14d, r12d, 0x06
00007ac9d05d02e1  mov r11d, [r15+0xC8]
00007ac9d05d02e8  mov [rsp+0x10], r12d
00007ac9d05d02ed  and r12d, r11d
00007ac9d05d02f0  mov r10d, [rsp+0x50]
00007ac9d05d02f5  mov r9d, [rsp+0x50]
00007ac9d05d02fa  shrd r10d, r9d, 0x02
00007ac9d05d02ff  mov [rsp+0x50], r11d
00007ac9d05d0304  mov r11d, r11d
00007ac9d05d0307  mov [r15+0x20], r11
00007ac9d05d030b  mov r11, [r15+0x88]
00007ac9d05d0312  mov r8, [r15+0x50]
00007ac9d05d0316  lea rbp, [r8+r11*1]
00007ac9d05d031a  mov r8d, [r13+rbp*1]
00007ac9d05d031f  mov ebp, [rsp+0x20]
00007ac9d05d0323  mov edi, [rsp+0x10]
00007ac9d05d0327  andn esi, edi, ebp
00007ac9d05d032c  mov edx, [r15+0xB0]
00007ac9d05d0333  lea ecx, [r12d+edx*1]
00007ac9d05d0338  rorx r12d, edi, 0x0B
00007ac9d05d033e  xor r14d, r12d
00007ac9d05d0341  rorx r12d, r9d, 0x0D
00007ac9d05d0347  xor r10d, r12d
00007ac9d05d034a  lea r12d, [ecx+esi*1]
00007ac9d05d034f  mov rsi, [r15+0x48]
00007ac9d05d0353  lea rdx, [rsi+r11*1]
00007ac9d05d0357  mov esi, [r13+rdx*1]
00007ac9d05d035c  mov edx, [rsp+0x30]
00007ac9d05d0360  mov ecx, [rsp+0x40]
00007ac9d05d0364  and edx, ecx
00007ac9d05d0366  mov [rsp+0x10], edx
00007ac9d05d036a  mov edx, edx
00007ac9d05d036c  mov [r15+0xD8], rdx
00007ac9d05d0373  lea edx, [r12d+r8d*1]
00007ac9d05d0378  mov r12d, [rsp+0x30]
00007ac9d05d037d  xor r12d, ecx
00007ac9d05d0380  rorx r8d, edi, 0x19
00007ac9d05d0386  xor r14d, r8d
00007ac9d05d0389  and r12d, r9d
00007ac9d05d038c  rorx r8d, r9d, 0x16
00007ac9d05d0392  xor r10d, r8d
00007ac9d05d0395  mov [rsp+0x20], r10d
00007ac9d05d039a  mov r10d, r10d
00007ac9d05d039d  mov [r15+0xD0], r10
00007ac9d05d03a4  lea r10d, [edx+esi*1]
00007ac9d05d03a9  mov r9d, [rsp+0x10]
00007ac9d05d03ae  xor r12d, r9d
00007ac9d05d03b1  lea r9d, [r10d+r14d*1]
00007ac9d05d03b6  lea r14, [r11+0x04]
00007ac9d05d03ba  mov [r15+0x88], r14
00007ac9d05d03c1  mov r11d, [rsp+0x20]
00007ac9d05d03c6  lea r10d, [r12d+r11d*1]
00007ac9d05d03cb  lea r11d, [r9d+eax*1]
00007ac9d05d03d0  mov r11d, r11d
00007ac9d05d03d3  mov [r15+0xB8], r11
00007ac9d05d03da  xor eax, eax
00007ac9d05d03dc  mov r12d, 0x100
00007ac9d05d03e2  cmp r14, r12
00007ac9d05d03e5  cmc
00007ac9d05d03e6  lahf
00007ac9d05d03e7  seto al
00007ac9d05d03ea  mov [r15+0x108], eax
00007ac9d05d03f1  lea eax, [r10d+r9d*1]
00007ac9d05d03f6  mov eax, eax
00007ac9d05d03f8  mov [r15+0xA8], rax
00007ac9d05d03ff  mov ebp, ebp
00007ac9d05d0401  mov [r15+0xB0], rbp
00007ac9d05d0408  mov eax, [rsp+0x50]
00007ac9d05d040c  mov eax, eax
00007ac9d05d040e  mov [r15+0xC0], rax
00007ac9d05d0415  mov edi, edi
00007ac9d05d0417  mov [r15+0xC8], rdi
00007ac9d05d041e  mov eax, [r15+0x108]
00007ac9d05d0425  sahf
00007ac9d05d0426  jnz 0x00007AC9D05D0458
00007ac9d05d0428  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0430  jz 0x00007AC9D05D04A0
00007ac9d05d0436  nop [rax+rax*1], ax
00007ac9d05d043f  nop [rax+rax*1], eax
00007ac9d05d0447  mov eax, 0x4108E0
00007ac9d05d044c  mov [r15+0x100], rax
00007ac9d05d0453  jmp 0x00007AC9D03FE110
00007ac9d05d0458  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0460  jz 0x00007AC9D05D0270
00007ac9d05d0466  nop [rax+rax*1], ax
00007ac9d05d046f  nop [rax+rax*1], eax
00007ac9d05d0477  mov eax, 0x410854
00007ac9d05d047c  mov [r15+0x100], rax
00007ac9d05d0483  jmp 0x00007AC9D03FE110
00007ac9d05d0488  int3
00007ac9d05d0489  call 0x00007AC9D0449010
00007ac9d05d048e  jmp 0x00007AC9D05D031F
00007ac9d05d0493  call 0x00007AC9D0425930
00007ac9d05d0498  jmp 0x00007AC9D05D035C
00007ac9d05d049d  int3
00007ac9d05d049e  nop
00007ac9d05d04a0  mov eax, [r15+0x98]
00007ac9d05d04a7  mov r14d, [r15+0x70]
00007ac9d05d04ab  lea r12d, [eax+r14d*1]
00007ac9d05d04b0  mov eax, [r15+0x28]
00007ac9d05d04b4  mov r14d, [r15+0x68]
00007ac9d05d04b8  lea r11d, [eax+r14d*1]
00007ac9d05d04bd  mov qword ptr [r15+0x88], 0x00
00007ac9d05d04c8  mov eax, [r15+0xA8]
00007ac9d05d04cf  mov r14d, [r15+0x78]
00007ac9d05d04d3  lea r10d, [eax+r14d*1]
00007ac9d05d04d8  mov [rsp+0x10], r10d
00007ac9d05d04dd  mov r10d, r10d
00007ac9d05d04e0  mov [r15+0x78], r10
00007ac9d05d04e4  mov eax, [r15+0x38]
00007ac9d05d04e8  mov r14d, [r15+0x80]
00007ac9d05d04ef  lea r10d, [eax+r14d*1]
00007ac9d05d04f4  mov [rsp+0x20], r10d
00007ac9d05d04f9  mov r10d, r10d
00007ac9d05d04fc  mov [r15+0x80], r10
00007ac9d05d0503  mov rax, [r15]
00007ac9d05d0506  lea r14, [rax+0x08]
00007ac9d05d050a  mov [r13+r14*1], r12d
00007ac9d05d050f  lea r14, [rax+0x0C]
00007ac9d05d0513  mov [r13+r14*1], r11d
00007ac9d05d0518  mov r14d, [r15+0xB8]
00007ac9d05d051f  mov r12d, [r15+0x18]
00007ac9d05d0523  lea r11d, [r14d+r12d*1]
00007ac9d05d0528  mov [rsp+0x30], r11d
00007ac9d05d052d  mov r11d, r11d
00007ac9d05d0530  mov [r15+0x68], r11
00007ac9d05d0534  mov r14d, [r15+0x30]
00007ac9d05d0538  mov r12d, [r15+0x90]
00007ac9d05d053f  lea r11d, [r14d+r12d*1]
00007ac9d05d0544  mov [rsp+0x40], r11d
00007ac9d05d0549  mov r11d, r11d
00007ac9d05d054c  mov [r15+0x70], r11
00007ac9d05d0550  mov r14d, [r15+0x20]
00007ac9d05d0554  mov r12d, [r15+0x58]
00007ac9d05d0558  lea r11d, [r14d+r12d*1]
00007ac9d05d055d  mov [rsp+0x50], r11d
00007ac9d05d0562  mov r11d, r11d
00007ac9d05d0565  mov [r15+0x58], r11
00007ac9d05d0569  mov r14d, [r15+0xA0]
00007ac9d05d0570  mov r12d, [r15+0x60]
00007ac9d05d0574  lea r11d, [r14d+r12d*1]
00007ac9d05d0579  mov [rsp+0x60], r11d
00007ac9d05d057e  mov r11d, r11d
00007ac9d05d0581  mov [r15+0x60], r11
00007ac9d05d0585  mov r14d, [rsp+0x10]
00007ac9d05d058a  mov [r13+rax*1], r14d
00007ac9d05d058f  lea r14, [rax+0x04]
00007ac9d05d0593  mov r12d, [rsp+0x20]
00007ac9d05d0598  mov [r13+r14*1], r12d
00007ac9d05d059d  lea r14, [rax+0x10]
00007ac9d05d05a1  mov r12d, [rsp+0x30]
00007ac9d05d05a6  mov [r13+r14*1], r12d
00007ac9d05d05ab  lea r14, [rax+0x14]
00007ac9d05d05af  mov r12d, [rsp+0x40]
00007ac9d05d05b4  mov [r13+r14*1], r12d
00007ac9d05d05b9  lea r14, [rax+0x18]
00007ac9d05d05bd  mov r12d, [rsp+0x50]
00007ac9d05d05c2  mov [r13+r14*1], r12d
00007ac9d05d05c7  lea r14, [rax+0x1C]
00007ac9d05d05cb  mov r12d, [rsp+0x60]
00007ac9d05d05d0  mov [r13+r14*1], r12d
00007ac9d05d05d5  lea r14, [rax+0x68]
00007ac9d05d05d9  xor eax, eax
00007ac9d05d05db  mov [r13+r14*1], rax
00007ac9d05d05e0  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d05e8  jz 0x00007AC9D05CF0E0
00007ac9d05d05ee  nop [rax+rax*1], ax
00007ac9d05d05f7  nop [rax+rax*1], eax
00007ac9d05d05ff  mov eax, 0x4106FC
00007ac9d05d0604  mov [r15+0x100], rax
00007ac9d05d060b  jmp 0x00007AC9D03FE110
00007ac9d05d0610  int3
00007ac9d05d0611  call 0x00007AC9D04E2BA0
00007ac9d05d0616  jmp 0x00007AC9D05D050F
00007ac9d05d061b  call 0x00007AC9D04E1920
00007ac9d05d0620  jmp 0x00007AC9D05D0518
00007ac9d05d0625  call 0x00007AC9D040DFE0
00007ac9d05d062a  jmp 0x00007AC9D05D058F
00007ac9d05d062f  call 0x00007AC9D04E2BA0
00007ac9d05d0634  jmp 0x00007AC9D05D059D
00007ac9d05d0639  call 0x00007AC9D04E2BA0
00007ac9d05d063e  jmp 0x00007AC9D05D05AB
00007ac9d05d0643  call 0x00007AC9D04E2BA0
00007ac9d05d0648  jmp 0x00007AC9D05D05B9
00007ac9d05d064d  call 0x00007AC9D04E2BA0
00007ac9d05d0652  jmp 0x00007AC9D05D05C7
00007ac9d05d0657  call 0x00007AC9D04E2BA0
00007ac9d05d065c  jmp 0x00007AC9D05D05D5
00007ac9d05d0661  call 0x00007AC9D04D5EB0
00007ac9d05d0666  jmp 0x00007AC9D05D05E0
00007ac9d05d066b  int3
00007ac9d05d066c  nop [rax], eax
00007ac9d05d0670  mov rax, [r15+0xF8]
00007ac9d05d0677  lea r14, [rax+0x140]
00007ac9d05d067e  mov r12, [r13+r14*1]
00007ac9d05d0683  lea r14, [rax+0x148]
00007ac9d05d068a  mov r11, [r13+r14*1]
00007ac9d05d068f  mov [r15+0xA0], r12
00007ac9d05d0696  mov [r15+0x98], r11
00007ac9d05d069d  lea r14, [rax+0x130]
00007ac9d05d06a4  mov r12, [r13+r14*1]
00007ac9d05d06a9  lea r14, [rax+0x138]
00007ac9d05d06b0  mov r11, [r13+r14*1]
00007ac9d05d06b5  mov [r15+0xB0], r12
00007ac9d05d06bc  mov [r15+0xA8], r11
00007ac9d05d06c3  lea r14, [rax+0x120]
00007ac9d05d06ca  mov r12, [r13+r14*1]
00007ac9d05d06cf  lea r14, [rax+0x128]
00007ac9d05d06d6  mov r11, [r13+r14*1]
00007ac9d05d06db  mov [r15+0xC0], r12
00007ac9d05d06e2  mov [r15+0xB8], r11
00007ac9d05d06e9  lea r14, [rax+0x110]
00007ac9d05d06f0  mov r12, [r13+r14*1]
00007ac9d05d06f5  lea r14, [rax+0x118]
00007ac9d05d06fc  mov r11, [r13+r14*1]
00007ac9d05d0701  mov [r15+0xD0], r12
00007ac9d05d0708  mov [r15+0xC8], r11
00007ac9d05d070f  lea r14, [rax+0x100]
00007ac9d05d0716  mov r12, [r13+r14*1]
00007ac9d05d071b  lea r14, [rax+0x108]
00007ac9d05d0722  mov r11, [r13+r14*1]
00007ac9d05d0727  mov [r15+0xE8], r12
00007ac9d05d072e  mov [r15+0xD8], r11
00007ac9d05d0735  lea r14, [rax+0x150]
00007ac9d05d073c  mov [r15+0xF8], r14
00007ac9d05d0743  mov rax, [r15+0xF0]
00007ac9d05d074a  mov [r15+0x100], rax
00007ac9d05d0751  jmp 0x00007AC9D05CE5C0
00007ac9d05d0756  int3
00007ac9d05d0757  call 0x00007AC9D04E27E0
00007ac9d05d075c  jmp 0x00007AC9D05D0683
00007ac9d05d0761  call 0x00007AC9D04E1570
00007ac9d05d0766  jmp 0x00007AC9D05D068F
00007ac9d05d076b  call 0x00007AC9D04E27E0
00007ac9d05d0770  jmp 0x00007AC9D05D06A9
00007ac9d05d0775  call 0x00007AC9D04E1570
00007ac9d05d077a  jmp 0x00007AC9D05D06B5
00007ac9d05d077f  call 0x00007AC9D04E27E0
00007ac9d05d0784  jmp 0x00007AC9D05D06CF
00007ac9d05d0789  call 0x00007AC9D04E1570
00007ac9d05d078e  jmp 0x00007AC9D05D06DB
00007ac9d05d0793  call 0x00007AC9D04E27E0
00007ac9d05d0798  jmp 0x00007AC9D05D06F5
00007ac9d05d079d  call 0x00007AC9D04E1570
00007ac9d05d07a2  jmp 0x00007AC9D05D0701
00007ac9d05d07a7  call 0x00007AC9D04E27E0
00007ac9d05d07ac  jmp 0x00007AC9D05D071B
00007ac9d05d07b1  call 0x00007AC9D04E1570
00007ac9d05d07b6  jmp 0x00007AC9D05D0727
00007ac9d05d07bb  int3
00007ac9d05d07bc  nop [rax], eax
00007ac9d05d07c0  mov eax, [r15+0xA0]
00007ac9d05d07c7  mov [rsp+0x10], eax
00007ac9d05d07cb  xor eax, eax
00007ac9d05d07cd  mov r14d, [rsp+0x10]
00007ac9d05d07d2  sub r14d, 0x01
00007ac9d05d07d6  cmc
00007ac9d05d07d7  lahf
00007ac9d05d07d8  seto al
00007ac9d05d07db  mov [r15+0x108], eax
00007ac9d05d07e2  mov r14d, r14d
00007ac9d05d07e5  mov [r15+0xA0], r14
00007ac9d05d07ec  mov eax, [r15+0x108]
00007ac9d05d07f3  sahf
00007ac9d05d07f4  jnz 0x00007AC9D05D0826
00007ac9d05d07f6  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d07fe  jz 0x00007AC9D05D0900
00007ac9d05d0804  nop [rax+rax*1], ax
00007ac9d05d080d  nop [rax+rax*1], eax
00007ac9d05d0815  mov eax, 0x41028C
00007ac9d05d081a  mov [r15+0x100], rax
00007ac9d05d0821  jmp 0x00007AC9D03FE110
00007ac9d05d0826  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d082e  jz 0x00007AC9D05D0860
00007ac9d05d0834  nop [rax+rax*1], ax
00007ac9d05d083d  nop [rax+rax*1], eax
00007ac9d05d0845  mov eax, 0x410274
00007ac9d05d084a  mov [r15+0x100], rax
00007ac9d05d0851  jmp 0x00007AC9D03FE110
00007ac9d05d0856  int3
00007ac9d05d0857  int3
00007ac9d05d0858  nop [rax+rax*1], eax
00007ac9d05d0860  mov rax, [r15+0xF8]
00007ac9d05d0867  lea r14, [rax+0xD0]
00007ac9d05d086e  mov [r15], r14
00007ac9d05d0871  mov rax, [r15+0x98]
00007ac9d05d0878  mov [r15+0x08], rax
00007ac9d05d087c  mov qword ptr [r15+0x10], 0x12C
00007ac9d05d0884  mov qword ptr [r15+0xF0], 0x410284
00007ac9d05d088f  mov r14d, [r15+0x320]
00007ac9d05d0896  mov eax, 0x410284
00007ac9d05d089b  mov rcx, 0x7AC9D05D07C0
00007ac9d05d08a5  mov [r15+r14*8+0x328], rax
00007ac9d05d08ad  mov [r15+r14*8+0x368], rcx
00007ac9d05d08b5  add r14d, 0x01
00007ac9d05d08b9  and r14d, 0x07
00007ac9d05d08bd  mov [r15+0x320], r14d
00007ac9d05d08c4  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d08cc  jz 0x00007AC9D05CED70
00007ac9d05d08d2  nop [rax+rax*1], ax
00007ac9d05d08db  nop [rax+rax*1], eax
00007ac9d05d08e3  mov eax, 0x4106BC
00007ac9d05d08e8  mov [r15+0x100], rax
00007ac9d05d08ef  jmp 0x00007AC9D03FE110
00007ac9d05d08f4  int3
00007ac9d05d08f5  int3
00007ac9d05d08f6  nop [rax+rax*1], ax
00007ac9d05d08ff  nop
00007ac9d05d0900  mov rax, [r15+0xF8]
00007ac9d05d0907  lea r14, [rax+0xF0]
00007ac9d05d090e  mov r12, [r13+r14*1]
00007ac9d05d0913  mov [r15+0x98], r12
00007ac9d05d091a  mov qword ptr [r15+0x40], 0x80
00007ac9d05d0922  lea r14, [rax+0xD0]
00007ac9d05d0929  mov [r15], r14
00007ac9d05d092c  lea r14, [rax+0x14C]
00007ac9d05d0933  mov [r15+0x08], r14
00007ac9d05d0937  mov qword ptr [r15+0x10], 0x01
00007ac9d05d093f  lea r14, [rax+0x14C]
00007ac9d05d0946  mov eax, 0x80
00007ac9d05d094b  mov [r13+r14*1], al
00007ac9d05d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007ac9d05d095b  mov r14d, [r15+0x320]
00007ac9d05d0962  mov eax, 0x4102A8
00007ac9d05d0967  mov rcx, 0x7AC9D05D09E0
00007ac9d05d0971  mov [r15+r14*8+0x328], rax
00007ac9d05d0979  mov [r15+r14*8+0x368], rcx
00007ac9d05d0981  add r14d, 0x01
00007ac9d05d0985  and r14d, 0x07
00007ac9d05d0989  mov [r15+0x320], r14d
00007ac9d05d0990  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0998  jz 0x00007AC9D05CED70
00007ac9d05d099e  nop [rax+rax*1], ax
00007ac9d05d09a7  nop [rax+rax*1], eax
00007ac9d05d09af  mov eax, 0x4106BC
00007ac9d05d09b4  mov [r15+0x100], rax
00007ac9d05d09bb  jmp 0x00007AC9D03FE110
00007ac9d05d09c0  int3
00007ac9d05d09c1  call 0x00007AC9D04E27E0
00007ac9d05d09c6  jmp 0x00007AC9D05D0913
00007ac9d05d09cb  call 0x00007AC9D04D5AF0
00007ac9d05d09d0  jmp 0x00007AC9D05D0950
00007ac9d05d09d5  int3
00007ac9d05d09d6  nop [rax+rax*1], ax
00007ac9d05d09df  nop
00007ac9d05d09e0  mov rax, [r15+0xF8]
00007ac9d05d09e7  lea r14, [rax+0x138]
00007ac9d05d09ee  mov r12, [r13+r14*1]
00007ac9d05d09f3  mov [r15+0x40], r12
00007ac9d05d09f7  lea r14, [rax+0x148]
00007ac9d05d09fe  xor eax, eax
00007ac9d05d0a00  mov [r13+r14*1], al
00007ac9d05d0a05  xor eax, eax
00007ac9d05d0a07  mov r14d, 0x38
00007ac9d05d0a0d  cmp r12, r14
00007ac9d05d0a10  cmc
00007ac9d05d0a11  lahf
00007ac9d05d0a12  seto al
00007ac9d05d0a15  mov [r15+0x108], eax
00007ac9d05d0a1c  mov eax, [r15+0x108]
00007ac9d05d0a23  sahf
00007ac9d05d0a24  jz 0x00007AC9D05D0A56
00007ac9d05d0a26  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0a2e  jz 0x00007AC9D05D0AA0
00007ac9d05d0a34  nop [rax+rax*1], ax
00007ac9d05d0a3d  nop [rax+rax*1], eax
00007ac9d05d0a45  mov eax, 0x4102B8
00007ac9d05d0a4a  mov [r15+0x100], rax
00007ac9d05d0a51  jmp 0x00007AC9D03FE110
00007ac9d05d0a56  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0a5e  jz 0x00007AC9D05D0BF0
00007ac9d05d0a64  nop [rax+rax*1], ax
00007ac9d05d0a6d  nop [rax+rax*1], eax
00007ac9d05d0a75  mov eax, 0x4102D4
00007ac9d05d0a7a  mov [r15+0x100], rax
00007ac9d05d0a81  jmp 0x00007AC9D03FE110
00007ac9d05d0a86  int3
00007ac9d05d0a87  call 0x00007AC9D04E27E0
00007ac9d05d0a8c  jmp 0x00007AC9D05D09F3
00007ac9d05d0a91  call 0x00007AC9D04D5AF0
00007ac9d05d0a96  jmp 0x00007AC9D05D0A05
00007ac9d05d0a9b  int3
00007ac9d05d0a9c  nop [rax], eax
00007ac9d05d0aa0  mov rax, [r15+0xF8]
00007ac9d05d0aa7  lea r14, [rax+0xD0]
00007ac9d05d0aae  mov [r15], r14
00007ac9d05d0ab1  lea r14, [rax+0x148]
00007ac9d05d0ab8  mov [r15+0x08], r14
00007ac9d05d0abc  mov qword ptr [r15+0x10], 0x01
00007ac9d05d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007ac9d05d0acf  mov r14d, [r15+0x320]
00007ac9d05d0ad6  mov eax, 0x4102C8
00007ac9d05d0adb  mov rcx, 0x7AC9D05D0B40
00007ac9d05d0ae5  mov [r15+r14*8+0x328], rax
00007ac9d05d0aed  mov [r15+r14*8+0x368], rcx
00007ac9d05d0af5  add r14d, 0x01
00007ac9d05d0af9  and r14d, 0x07
00007ac9d05d0afd  mov [r15+0x320], r14d
00007ac9d05d0b04  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0b0c  jz 0x00007AC9D05CED70
00007ac9d05d0b12  nop [rax+rax*1], ax
00007ac9d05d0b1b  nop [rax+rax*1], eax
00007ac9d05d0b23  mov eax, 0x4106BC
00007ac9d05d0b28  mov [r15+0x100], rax
00007ac9d05d0b2f  jmp 0x00007AC9D03FE110
00007ac9d05d0b34  int3
00007ac9d05d0b35  int3
00007ac9d05d0b36  nop [rax+rax*1], ax
00007ac9d05d0b3f  nop
00007ac9d05d0b40  mov rax, [r15+0xF8]
00007ac9d05d0b47  lea r14, [rax+0x138]
00007ac9d05d0b4e  mov rax, [r13+r14*1]
00007ac9d05d0b53  mov [r15+0x40], rax
00007ac9d05d0b57  mov [rsp+0x10], rax
00007ac9d05d0b5c  xor eax, eax
00007ac9d05d0b5e  mov r14, [rsp+0x10]
00007ac9d05d0b63  mov r12d, 0x38
00007ac9d05d0b69  cmp r14, r12
00007ac9d05d0b6c  cmc
00007ac9d05d0b6d  lahf
00007ac9d05d0b6e  seto al
00007ac9d05d0b71  mov [r15+0x108], eax
00007ac9d05d0b78  mov eax, [r15+0x108]
00007ac9d05d0b7f  sahf
00007ac9d05d0b80  jnz 0x00007AC9D05D0BB2
00007ac9d05d0b82  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0b8a  jz 0x00007AC9D05D0BF0
00007ac9d05d0b90  nop [rax+rax*1], ax
00007ac9d05d0b99  nop [rax+rax*1], eax
00007ac9d05d0ba1  mov eax, 0x4102D4
00007ac9d05d0ba6  mov [r15+0x100], rax
00007ac9d05d0bad  jmp 0x00007AC9D03FE110
00007ac9d05d0bb2  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0bba  jz 0x00007AC9D05D0AA0
00007ac9d05d0bc0  nop [rax+rax*1], ax
00007ac9d05d0bc9  nop [rax+rax*1], eax
00007ac9d05d0bd1  mov eax, 0x4102B8
00007ac9d05d0bd6  mov [r15+0x100], rax
00007ac9d05d0bdd  jmp 0x00007AC9D03FE110
00007ac9d05d0be2  int3
00007ac9d05d0be3  call 0x00007AC9D04D59C0
00007ac9d05d0be8  jmp 0x00007AC9D05D0B53
00007ac9d05d0bed  int3
00007ac9d05d0bee  nop
00007ac9d05d0bf0  mov rax, [r15+0x98]
00007ac9d05d0bf7  rorx r14, rax, 0x3D
00007ac9d05d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007ac9d05d0c01  mov rax, [r15+0xF8]
00007ac9d05d0c08  lea r12, [rax+0xD0]
00007ac9d05d0c0f  mov [r15], r12
00007ac9d05d0c12  lea r12, [rax+0x140]
00007ac9d05d0c19  mov [r15+0x08], r12
00007ac9d05d0c1d  mov qword ptr [r15+0x10], 0x08
00007ac9d05d0c25  bswap r14
00007ac9d05d0c28  mov [r15+0x40], r14
00007ac9d05d0c2c  lea r12, [rax+0x140]
00007ac9d05d0c33  mov [r13+r12*1], r14
00007ac9d05d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007ac9d05d0c43  mov r14d, [r15+0x320]
00007ac9d05d0c4a  mov eax, 0x4102F0
00007ac9d05d0c4f  mov rcx, 0x7AC9D05D0CC0
00007ac9d05d0c59  mov [r15+r14*8+0x328], rax
00007ac9d05d0c61  mov [r15+r14*8+0x368], rcx
00007ac9d05d0c69  add r14d, 0x01
00007ac9d05d0c6d  and r14d, 0x07
00007ac9d05d0c71  mov [r15+0x320], r14d
00007ac9d05d0c78  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0c80  jz 0x00007AC9D05CED70
00007ac9d05d0c86  nop [rax+rax*1], ax
00007ac9d05d0c8f  nop [rax+rax*1], eax
00007ac9d05d0c97  mov eax, 0x4106BC
00007ac9d05d0c9c  mov [r15+0x100], rax
00007ac9d05d0ca3  jmp 0x00007AC9D03FE110
00007ac9d05d0ca8  int3
00007ac9d05d0ca9  call 0x00007AC9D04C3FE0
00007ac9d05d0cae  jmp 0x00007AC9D05D0C38
00007ac9d05d0cb3  int3
00007ac9d05d0cb4  nop [rax+rax*1], ax
00007ac9d05d0cbd  nop [rax], eax
00007ac9d05d0cc0  mov rax, [r15+0xF8]
00007ac9d05d0cc7  lea r14, [rax+0xD0]
00007ac9d05d0cce  mov r12d, [r13+r14*1]
00007ac9d05d0cd3  lea r14, [rax+0xD4]
00007ac9d05d0cda  mov r11d, [r13+r14*1]
00007ac9d05d0cdf  lea r14, [rax+0xD8]
00007ac9d05d0ce6  mov r10d, [r13+r14*1]
00007ac9d05d0ceb  lea r14, [rax+0xDC]
00007ac9d05d0cf2  mov r9d, [r13+r14*1]
00007ac9d05d0cf7  mov qword ptr [r15+0x48], 0x430C20
00007ac9d05d0cff  mov qword ptr [r15+0xA0], 0x00
00007ac9d05d0d0a  bswap r12d
00007ac9d05d0d0d  bswap r11d
00007ac9d05d0d10  mov qword ptr [r15+0x98], 0x430D8C
00007ac9d05d0d1b  mov r14d, 0x430C20
00007ac9d05d0d21  mov [r13+r14*1], r12d
00007ac9d05d0d26  mov r14d, 0x430C24
00007ac9d05d0d2c  mov [r13+r14*1], r11d
00007ac9d05d0d31  bswap r10d
00007ac9d05d0d34  bswap r9d
00007ac9d05d0d37  lea r14, [rax+0xE0]
00007ac9d05d0d3e  mov r12d, [r13+r14*1]
00007ac9d05d0d43  lea r14, [rax+0xE4]
00007ac9d05d0d4a  mov r11d, [r13+r14*1]
00007ac9d05d0d4f  mov r14d, 0x430C28
00007ac9d05d0d55  mov [r13+r14*1], r10d
00007ac9d05d0d5a  mov r14d, 0x430C2C
00007ac9d05d0d60  mov [r13+r14*1], r9d
00007ac9d05d0d65  bswap r12d
00007ac9d05d0d68  bswap r11d
00007ac9d05d0d6b  mov [rsp+0x10], r11d
00007ac9d05d0d70  mov r11d, r11d
00007ac9d05d0d73  mov [r15+0x58], r11
00007ac9d05d0d77  lea r14, [rax+0xE8]
00007ac9d05d0d7e  mov r11d, [r13+r14*1]
00007ac9d05d0d83  lea r14, [rax+0xEC]
00007ac9d05d0d8a  mov eax, [r13+r14*1]
00007ac9d05d0d8f  mov [rsp+0x20], eax
00007ac9d05d0d93  mov eax, eax
00007ac9d05d0d95  mov [r15+0x60], rax
00007ac9d05d0d99  mov eax, 0x430C30
00007ac9d05d0d9e  mov [r13+rax*1], r12d
00007ac9d05d0da3  mov eax, 0x430C34
00007ac9d05d0da8  mov r14d, [rsp+0x10]
00007ac9d05d0dad  mov [r13+rax*1], r14d
00007ac9d05d0db2  bswap r11d
00007ac9d05d0db5  mov [rsp+0x10], r11d
00007ac9d05d0dba  mov r11d, r11d
00007ac9d05d0dbd  mov [r15+0x40], r11
00007ac9d05d0dc1  mov eax, [rsp+0x20]
00007ac9d05d0dc5  bswap eax
00007ac9d05d0dc7  mov [rsp+0x20], eax
00007ac9d05d0dcb  mov eax, eax
00007ac9d05d0dcd  mov [r15+0x50], rax
00007ac9d05d0dd1  mov eax, 0x430C38
00007ac9d05d0dd6  mov r14d, [rsp+0x10]
00007ac9d05d0ddb  mov [r13+rax*1], r14d
00007ac9d05d0de0  mov eax, 0x430C3C
00007ac9d05d0de5  mov r14d, [rsp+0x20]
00007ac9d05d0dea  mov [r13+rax*1], r14d
00007ac9d05d0def  mov eax, [r15+0xA0]
00007ac9d05d0df6  lea r14d, [eax+0x11]
00007ac9d05d0dfb  mov r14d, r14d
00007ac9d05d0dfe  mov [r15], r14
00007ac9d05d0e01  mov qword ptr [r15+0xF0], 0x41034C
00007ac9d05d0e0c  mov r14d, [r15+0x320]
00007ac9d05d0e13  mov eax, 0x41034C
00007ac9d05d0e18  mov rcx, 0x7AC9D05D0F90
00007ac9d05d0e22  mov [r15+r14*8+0x328], rax
00007ac9d05d0e2a  mov [r15+r14*8+0x368], rcx
00007ac9d05d0e32  add r14d, 0x01
00007ac9d05d0e36  and r14d, 0x07
00007ac9d05d0e3a  mov [r15+0x320], r14d
00007ac9d05d0e41  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0e49  jz 0x00007AC9D05D0F20
00007ac9d05d0e4f  nop [rax+rax*1], ax
00007ac9d05d0e58  nop [rax+rax*1], eax
00007ac9d05d0e60  mov eax, 0x410938
00007ac9d05d0e65  mov [r15+0x100], rax
00007ac9d05d0e6c  jmp 0x00007AC9D03FE110
00007ac9d05d0e71  int3
00007ac9d05d0e72  call 0x00007AC9D04E26A0
00007ac9d05d0e77  jmp 0x00007AC9D05D0CD3
00007ac9d05d0e7c  call 0x00007AC9D04E1430
00007ac9d05d0e81  jmp 0x00007AC9D05D0CDF
00007ac9d05d0e86  call 0x00007AC9D04E01C0
00007ac9d05d0e8b  jmp 0x00007AC9D05D0CEB
00007ac9d05d0e90  call 0x00007AC9D04DEF50
00007ac9d05d0e95  jmp 0x00007AC9D05D0CF7
00007ac9d05d0e9a  call 0x00007AC9D04E2BA0
00007ac9d05d0e9f  jmp 0x00007AC9D05D0D26
00007ac9d05d0ea4  call 0x00007AC9D04E1920
00007ac9d05d0ea9  jmp 0x00007AC9D05D0D31
00007ac9d05d0eae  call 0x00007AC9D04E26A0
00007ac9d05d0eb3  jmp 0x00007AC9D05D0D43
00007ac9d05d0eb8  call 0x00007AC9D04E1430
00007ac9d05d0ebd  jmp 0x00007AC9D05D0D4F
00007ac9d05d0ec2  call 0x00007AC9D04E06B0
00007ac9d05d0ec7  jmp 0x00007AC9D05D0D5A
00007ac9d05d0ecc  call 0x00007AC9D04DF440
00007ac9d05d0ed1  jmp 0x00007AC9D05D0D65
00007ac9d05d0ed6  call 0x00007AC9D04E1430
00007ac9d05d0edb  jmp 0x00007AC9D05D0D83
00007ac9d05d0ee0  call 0x00007AC9D04D5890
00007ac9d05d0ee5  jmp 0x00007AC9D05D0D8F
00007ac9d05d0eea  call 0x00007AC9D040BAE0
00007ac9d05d0eef  jmp 0x00007AC9D05D0DA3
00007ac9d05d0ef4  call 0x00007AC9D040DFE0
00007ac9d05d0ef9  jmp 0x00007AC9D05D0DB2
00007ac9d05d0efe  call 0x00007AC9D040DFE0
00007ac9d05d0f03  jmp 0x00007AC9D05D0DE0
00007ac9d05d0f08  call 0x00007AC9D040DFE0
00007ac9d05d0f0d  jmp 0x00007AC9D05D0DEF
00007ac9d05d0f12  int3
00007ac9d05d0f13  nop [rax+rax*1], ax
00007ac9d05d0f1c  nop [rax], eax
00007ac9d05d0f20  mov eax, [r15]
00007ac9d05d0f23  mov [rsp+0x10], eax
00007ac9d05d0f27  shr eax, 0x10
00007ac9d05d0f2a  mov r14d, [rsp+0x10]
00007ac9d05d0f2f  xor r14d, eax
00007ac9d05d0f32  imul r14d, r14d, 0x7FEB352D
00007ac9d05d0f39  mov eax, 0x846CA68B
00007ac9d05d0f3e  mov eax, eax
00007ac9d05d0f40  mov [r15+0x48], rax
00007ac9d05d0f44  mov [rsp+0x10], r14d
00007ac9d05d0f49  shr r14d, 0x0F
00007ac9d05d0f4d  mov eax, [rsp+0x10]
00007ac9d05d0f51  xor eax, r14d
00007ac9d05d0f54  imul eax, eax, 0x846CA68B
00007ac9d05d0f5a  mov [rsp+0x10], eax
00007ac9d05d0f5e  mov eax, eax
00007ac9d05d0f60  mov [r15+0x40], rax
00007ac9d05d0f64  mov eax, [rsp+0x10]
00007ac9d05d0f68  shr eax, 0x10
00007ac9d05d0f6b  mov r14d, [rsp+0x10]
00007ac9d05d0f70  xor r14d, eax
00007ac9d05d0f73  mov r14d, r14d
00007ac9d05d0f76  mov [r15], r14
00007ac9d05d0f79  mov rax, [r15+0xF0]
00007ac9d05d0f80  mov [r15+0x100], rax
00007ac9d05d0f87  jmp 0x00007AC9D05CE5C0
00007ac9d05d0f8c  int3
00007ac9d05d0f8d  int3
00007ac9d05d0f8e  nop
00007ac9d05d0f90  mov rax, [r15+0xA0]
00007ac9d05d0f97  mov [rsp+0x10], rax
00007ac9d05d0f9c  shl rax, 0x02
00007ac9d05d0fa0  mov r14, [r15+0x98]
00007ac9d05d0fa7  lea r12, [r14+rax*1]
00007ac9d05d0fab  mov eax, [r15]
00007ac9d05d0fae  mov [r13+r12*1], eax
00007ac9d05d0fb3  mov rax, [rsp+0x10]
00007ac9d05d0fb8  lea r14, [rax+0x01]
00007ac9d05d0fbc  mov [r15+0xA0], r14
00007ac9d05d0fc3  xor eax, eax
00007ac9d05d0fc5  mov r12d, 0x400
00007ac9d05d0fcb  cmp r14, r12
00007ac9d05d0fce  cmc
00007ac9d05d0fcf  lahf
00007ac9d05d0fd0  seto al
00007ac9d05d0fd3  mov [r15+0x108], eax
00007ac9d05d0fda  mov eax, [r15+0x108]
00007ac9d05d0fe1  sahf
00007ac9d05d0fe2  jnz 0x00007AC9D05D1014
00007ac9d05d0fe4  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d0fec  jz 0x00007AC9D05D10E0
00007ac9d05d0ff2  nop [rax+rax*1], ax
00007ac9d05d0ffb  nop [rax+rax*1], eax
00007ac9d05d1003  mov eax, 0x41035C
00007ac9d05d1008  mov [r15+0x100], rax
00007ac9d05d100f  jmp 0x00007AC9D03FE110
00007ac9d05d1014  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d101c  jz 0x00007AC9D05D1050
00007ac9d05d1022  nop [rax+rax*1], ax
00007ac9d05d102b  nop [rax+rax*1], eax
00007ac9d05d1033  mov eax, 0x410344
00007ac9d05d1038  mov [r15+0x100], rax
00007ac9d05d103f  jmp 0x00007AC9D03FE110
00007ac9d05d1044  int3
00007ac9d05d1045  call 0x00007AC9D04B4B70
00007ac9d05d104a  jmp 0x00007AC9D05D0FB3
00007ac9d05d104f  int3
00007ac9d05d1050  mov eax, [r15+0xA0]
00007ac9d05d1057  lea r14d, [eax+0x11]
00007ac9d05d105c  mov r14d, r14d
00007ac9d05d105f  mov [r15], r14
00007ac9d05d1062  mov qword ptr [r15+0xF0], 0x41034C
00007ac9d05d106d  mov r14d, [r15+0x320]
00007ac9d05d1074  mov eax, 0x41034C
00007ac9d05d1079  mov rcx, 0x7AC9D05D0F90
00007ac9d05d1083  mov [r15+r14*8+0x328], rax
00007ac9d05d108b  mov [r15+r14*8+0x368], rcx
00007ac9d05d1093  add r14d, 0x01
00007ac9d05d1097  and r14d, 0x07
00007ac9d05d109b  mov [r15+0x320], r14d
00007ac9d05d10a2  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d10aa  jz 0x00007AC9D05D0F20
00007ac9d05d10b0  nop [rax+rax*1], ax
00007ac9d05d10b9  nop [rax+rax*1], eax
00007ac9d05d10c1  mov eax, 0x410938
00007ac9d05d10c6  mov [r15+0x100], rax
00007ac9d05d10cd  jmp 0x00007AC9D03FE110
00007ac9d05d10d2  int3
00007ac9d05d10d3  int3
00007ac9d05d10d4  nop [rax+rax*1], ax
00007ac9d05d10dd  nop [rax], eax
00007ac9d05d10e0  mov qword ptr [r15+0x40], 0x01
00007ac9d05d10e8  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d10f0  jz 0x00007AC9D05D1120
00007ac9d05d10f6  nop [rax+rax*1], ax
00007ac9d05d10ff  nop [rax+rax*1], eax
00007ac9d05d1107  mov eax, 0x410378
00007ac9d05d110c  mov [r15+0x100], rax
00007ac9d05d1113  jmp 0x00007AC9D03FE110
00007ac9d05d1118  int3
00007ac9d05d1119  int3
00007ac9d05d111a  nop [rax+rax*1], ax
00007ac9d05d1120  mov rax, [r15+0x40]
00007ac9d05d1124  mov [rsp+0x10], rax
00007ac9d05d1129  shl rax, 0x02
00007ac9d05d112d  mov r14, [r15+0x98]
00007ac9d05d1134  lea r12, [r14+rax*1]
00007ac9d05d1138  mov eax, [r13+r12*1]
00007ac9d05d113d  mov [rsp+0x20], eax
00007ac9d05d1141  mov eax, eax
00007ac9d05d1143  mov [r15+0x48], rax
00007ac9d05d1147  mov rax, [rsp+0x10]
00007ac9d05d114c  mov [r15+0x50], rax
00007ac9d05d1150  mov eax, [r15+0x50]
00007ac9d05d1154  lea r12d, [eax-0x01]
00007ac9d05d1159  mov r12d, r12d
00007ac9d05d115c  mov [r15+0x58], r12
00007ac9d05d1160  mov rax, [r15+0x58]
00007ac9d05d1164  mov r12d, eax
00007ac9d05d1167  mov r12d, r12d
00007ac9d05d116a  shl r12, 0x02
00007ac9d05d116e  lea rax, [r14+r12*1]
00007ac9d05d1172  mov r14d, [r13+rax*1]
00007ac9d05d1177  mov [rsp+0x10], r14d
00007ac9d05d117c  mov r14d, r14d
00007ac9d05d117f  mov [r15+0x60], r14
00007ac9d05d1183  xor eax, eax
00007ac9d05d1185  mov r14d, [rsp+0x10]
00007ac9d05d118a  mov r12d, [rsp+0x20]
00007ac9d05d118f  cmp r14d, r12d
00007ac9d05d1192  cmc
00007ac9d05d1193  lahf
00007ac9d05d1194  seto al
00007ac9d05d1197  mov [r15+0x108], eax
00007ac9d05d119e  mov eax, [r15+0x108]
00007ac9d05d11a5  sahf
00007ac9d05d11a6  cmc
00007ac9d05d11a7  jbe 0x00007AC9D05D11D9
00007ac9d05d11a9  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d11b1  jz 0x00007AC9D05D1220
00007ac9d05d11b7  nop [rax+rax*1], ax
00007ac9d05d11c0  nop [rax+rax*1], eax
00007ac9d05d11c8  mov eax, 0x410390
00007ac9d05d11cd  mov [r15+0x100], rax
00007ac9d05d11d4  jmp 0x00007AC9D03FE110
00007ac9d05d11d9  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d11e1  jz 0x00007AC9D05D14C0
00007ac9d05d11e7  nop [rax+rax*1], ax
00007ac9d05d11f0  nop [rax+rax*1], eax
00007ac9d05d11f8  mov eax, 0x410368
00007ac9d05d11fd  mov [r15+0x100], rax
00007ac9d05d1204  jmp 0x00007AC9D03FE110
00007ac9d05d1209  int3
00007ac9d05d120a  call 0x00007AC9D04B4690
00007ac9d05d120f  jmp 0x00007AC9D05D113D
00007ac9d05d1214  call 0x00007AC9D040DAE0
00007ac9d05d1219  jmp 0x00007AC9D05D1177
00007ac9d05d121e  int3
00007ac9d05d121f  nop
00007ac9d05d1220  mov rax, [r15+0x50]
00007ac9d05d1224  mov [rsp+0x10], rax
00007ac9d05d1229  shl rax, 0x02
00007ac9d05d122d  mov r14, [r15+0x98]
00007ac9d05d1234  lea r12, [r14+rax*1]
00007ac9d05d1238  mov eax, [r15+0x60]
00007ac9d05d123c  mov [r13+r12*1], eax
00007ac9d05d1241  mov rax, [rsp+0x10]
00007ac9d05d1246  lea r14, [rax-0x01]
00007ac9d05d124a  mov [r15+0x50], r14
00007ac9d05d124e  mov rax, [r15+0x58]
00007ac9d05d1252  test rax, rax
00007ac9d05d1255  setz al
00007ac9d05d1258  movzx rax, al
00007ac9d05d125c  mov [rsp+0x414], al
00007ac9d05d1263  cmp byte ptr [rsp+0x414], 0x00
00007ac9d05d126b  jz 0x00007AC9D05D129D
00007ac9d05d126d  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d1275  jz 0x00007AC9D05D12E0
00007ac9d05d127b  nop [rax+rax*1], ax
00007ac9d05d1284  nop [rax+rax*1], eax
00007ac9d05d128c  mov eax, 0x41039C
00007ac9d05d1291  mov [r15+0x100], rax
00007ac9d05d1298  jmp 0x00007AC9D03FE110
00007ac9d05d129d  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d12a5  jz 0x00007AC9D05D13E0
00007ac9d05d12ab  nop [rax+rax*1], ax
00007ac9d05d12b4  nop [rax+rax*1], eax
00007ac9d05d12bc  mov eax, 0x410380
00007ac9d05d12c1  mov [r15+0x100], rax
00007ac9d05d12c8  jmp 0x00007AC9D03FE110
00007ac9d05d12cd  int3
00007ac9d05d12ce  call 0x00007AC9D04B4B70
00007ac9d05d12d3  jmp 0x00007AC9D05D1241
00007ac9d05d12d8  int3
00007ac9d05d12d9  nop [rax], eax
00007ac9d05d12e0  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d12e8  jz 0x00007AC9D05D1320
00007ac9d05d12ee  nop [rax+rax*1], ax
00007ac9d05d12f7  nop [rax+rax*1], eax
00007ac9d05d12ff  mov eax, 0x410364
00007ac9d05d1304  mov [r15+0x100], rax
00007ac9d05d130b  jmp 0x00007AC9D03FE110
00007ac9d05d1310  int3
00007ac9d05d1311  int3
00007ac9d05d1312  nop [rax+rax*1], ax
00007ac9d05d131b  nop [rax+rax*1], eax
00007ac9d05d1320  mov qword ptr [r15+0x50], 0x00
00007ac9d05d1328  mov rax, [r15+0x40]
00007ac9d05d132c  lea r14, [rax+0x01]
00007ac9d05d1330  mov [r15+0x40], r14
00007ac9d05d1334  mov rax, [r15+0x98]
00007ac9d05d133b  mov r12d, [r15+0x48]
00007ac9d05d133f  mov [r13+rax*1], r12d
00007ac9d05d1344  xor eax, eax
00007ac9d05d1346  mov r12d, 0x400
00007ac9d05d134c  cmp r14, r12
00007ac9d05d134f  cmc
00007ac9d05d1350  lahf
00007ac9d05d1351  seto al
00007ac9d05d1354  mov [r15+0x108], eax
00007ac9d05d135b  mov eax, [r15+0x108]
00007ac9d05d1362  sahf
00007ac9d05d1363  jz 0x00007AC9D05D1395
00007ac9d05d1365  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d136d  jz 0x00007AC9D05D1120
00007ac9d05d1373  nop [rax+rax*1], ax
00007ac9d05d137c  nop [rax+rax*1], eax
00007ac9d05d1384  mov eax, 0x410378
00007ac9d05d1389  mov [r15+0x100], rax
00007ac9d05d1390  jmp 0x00007AC9D03FE110
00007ac9d05d1395  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d139d  jz 0x00007AC9D05D1580
00007ac9d05d13a3  nop [rax+rax*1], ax
00007ac9d05d13ac  nop [rax+rax*1], eax
00007ac9d05d13b4  mov eax, 0x4103A0
00007ac9d05d13b9  mov [r15+0x100], rax
00007ac9d05d13c0  jmp 0x00007AC9D03FE110
00007ac9d05d13c5  int3
00007ac9d05d13c6  call 0x00007AC9D040BAE0
00007ac9d05d13cb  jmp 0x00007AC9D05D1344
00007ac9d05d13d0  int3
00007ac9d05d13d1  nop [rax+rax*1], ax
00007ac9d05d13da  nop [rax+rax*1], ax
00007ac9d05d13e0  mov eax, [r15+0x50]
00007ac9d05d13e4  lea r14d, [eax-0x01]
00007ac9d05d13e9  mov r14d, r14d
00007ac9d05d13ec  mov [r15+0x58], r14
00007ac9d05d13f0  mov rax, [r15+0x58]
00007ac9d05d13f4  mov r14d, eax
00007ac9d05d13f7  mov r14d, r14d
00007ac9d05d13fa  shl r14, 0x02
00007ac9d05d13fe  mov rax, [r15+0x98]
00007ac9d05d1405  lea r12, [rax+r14*1]
00007ac9d05d1409  mov eax, [r13+r12*1]
00007ac9d05d140e  mov [rsp+0x10], eax
00007ac9d05d1412  mov eax, eax
00007ac9d05d1414  mov [r15+0x60], rax
00007ac9d05d1418  mov eax, [r15+0x48]
00007ac9d05d141c  mov [rsp+0x20], eax
00007ac9d05d1420  xor eax, eax
00007ac9d05d1422  mov r14d, [rsp+0x10]
00007ac9d05d1427  mov r12d, [rsp+0x20]
00007ac9d05d142c  cmp r14d, r12d
00007ac9d05d142f  cmc
00007ac9d05d1430  lahf
00007ac9d05d1431  seto al
00007ac9d05d1434  mov [r15+0x108], eax
00007ac9d05d143b  mov eax, [r15+0x108]
00007ac9d05d1442  sahf
00007ac9d05d1443  cmc
00007ac9d05d1444  jbe 0x00007AC9D05D1476
00007ac9d05d1446  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d144e  jz 0x00007AC9D05D1220
00007ac9d05d1454  nop [rax+rax*1], ax
00007ac9d05d145d  nop [rax+rax*1], eax
00007ac9d05d1465  mov eax, 0x410390
00007ac9d05d146a  mov [r15+0x100], rax
00007ac9d05d1471  jmp 0x00007AC9D03FE110
00007ac9d05d1476  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d147e  jz 0x00007AC9D05D14C0
00007ac9d05d1484  nop [rax+rax*1], ax
00007ac9d05d148d  nop [rax+rax*1], eax
00007ac9d05d1495  mov eax, 0x410368
00007ac9d05d149a  mov [r15+0x100], rax
00007ac9d05d14a1  jmp 0x00007AC9D03FE110
00007ac9d05d14a6  int3
00007ac9d05d14a7  call 0x00007AC9D04B4690
00007ac9d05d14ac  jmp 0x00007AC9D05D140E
00007ac9d05d14b1  int3
00007ac9d05d14b2  nop [rax+rax*1], ax
00007ac9d05d14bb  nop [rax+rax*1], eax
00007ac9d05d14c0  mov rax, [r15+0x40]
00007ac9d05d14c4  lea r14, [rax+0x01]
00007ac9d05d14c8  mov [r15+0x40], r14
00007ac9d05d14cc  mov rax, [r15+0x50]
00007ac9d05d14d0  mov r12d, eax
00007ac9d05d14d3  mov r12d, r12d
00007ac9d05d14d6  shl r12, 0x02
00007ac9d05d14da  mov rax, [r15+0x98]
00007ac9d05d14e1  lea r11, [rax+r12*1]
00007ac9d05d14e5  mov eax, [r15+0x48]
00007ac9d05d14e9  mov [r13+r11*1], eax
00007ac9d05d14ee  xor eax, eax
00007ac9d05d14f0  mov r12d, 0x400
00007ac9d05d14f6  cmp r14, r12
00007ac9d05d14f9  cmc
00007ac9d05d14fa  lahf
00007ac9d05d14fb  seto al
00007ac9d05d14fe  mov [r15+0x108], eax
00007ac9d05d1505  mov eax, [r15+0x108]
00007ac9d05d150c  sahf
00007ac9d05d150d  jz 0x00007AC9D05D153F
00007ac9d05d150f  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d1517  jz 0x00007AC9D05D1120
00007ac9d05d151d  nop [rax+rax*1], ax
00007ac9d05d1526  nop [rax+rax*1], eax
00007ac9d05d152e  mov eax, 0x410378
00007ac9d05d1533  mov [r15+0x100], rax
00007ac9d05d153a  jmp 0x00007AC9D03FE110
00007ac9d05d153f  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d1547  jz 0x00007AC9D05D1580
00007ac9d05d154d  nop [rax+rax*1], ax
00007ac9d05d1556  nop [rax+rax*1], eax
00007ac9d05d155e  mov eax, 0x4103A0
00007ac9d05d1563  mov [r15+0x100], rax
00007ac9d05d156a  jmp 0x00007AC9D03FE110
00007ac9d05d156f  int3
00007ac9d05d1570  call 0x00007AC9D04A4270
00007ac9d05d1575  jmp 0x00007AC9D05D14EE
00007ac9d05d157a  int3
00007ac9d05d157b  nop [rax+rax*1], eax
00007ac9d05d1580  mov qword ptr [r15+0x40], 0x430000
00007ac9d05d1588  mov eax, 0x430C40
00007ac9d05d158d  mov r14, [r13+rax*1]
00007ac9d05d1592  mov rax, [r15+0x98]
00007ac9d05d1599  mov r12d, [r13+rax*1]
00007ac9d05d159e  lea r11, [rax+0x04]
00007ac9d05d15a2  mov eax, [r13+r11*1]
00007ac9d05d15a7  mov r12d, r12d
00007ac9d05d15aa  mov [r15+0x68], r12
00007ac9d05d15ae  mov eax, eax
00007ac9d05d15b0  mov [r15+0x60], rax
00007ac9d05d15b4  mov rax, [r15+0x68]
00007ac9d05d15b8  mov [r15+0x68], rax
00007ac9d05d15bc  mov qword ptr [r15+0x58], 0x02
00007ac9d05d15c4  mov [rsp+0x10], rax
00007ac9d05d15c9  xor eax, eax
00007ac9d05d15cb  mov r12d, 0x02
00007ac9d05d15d1  mov r11d, 0x400
00007ac9d05d15d7  cmp r12, r11
00007ac9d05d15da  cmc
00007ac9d05d15db  lahf
00007ac9d05d15dc  seto al
00007ac9d05d15df  mov [r15+0x108], eax
00007ac9d05d15e6  mov rax, [r15+0x60]
00007ac9d05d15ea  mov r12d, 0x02
00007ac9d05d15f0  imul rax, r12
00007ac9d05d15f4  mov [r15+0x50], rax
00007ac9d05d15f8  mov rax, [rsp+0x10]
00007ac9d05d15fd  lea r12, [rax+r14*1]
00007ac9d05d1601  mov [r15+0x48], r12
00007ac9d05d1605  mov eax, [r15+0x108]
00007ac9d05d160c  sahf
00007ac9d05d160d  jnz 0x00007AC9D05D163F
00007ac9d05d160f  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d1617  jz 0x00007AC9D05D17B0
00007ac9d05d161d  nop [rax+rax*1], ax
00007ac9d05d1626  nop [rax+rax*1], eax
00007ac9d05d162e  mov eax, 0x4103D0
00007ac9d05d1633  mov [r15+0x100], rax
00007ac9d05d163a  jmp 0x00007AC9D03FE110
00007ac9d05d163f  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d1647  jz 0x00007AC9D05D1690
00007ac9d05d164d  nop [rax+rax*1], ax
00007ac9d05d1656  nop [rax+rax*1], eax
00007ac9d05d165e  mov eax, 0x4103B0
00007ac9d05d1663  mov [r15+0x100], rax
00007ac9d05d166a  jmp 0x00007AC9D03FE110
00007ac9d05d166f  int3
00007ac9d05d1670  call 0x00007AC9D040DC20
00007ac9d05d1675  jmp 0x00007AC9D05D1592
00007ac9d05d167a  call 0x00007AC9D040B5E0
00007ac9d05d167f  jmp 0x00007AC9D05D159E
00007ac9d05d1684  call 0x00007AC9D04A3D90
00007ac9d05d1689  jmp 0x00007AC9D05D15A7
00007ac9d05d168e  int3
00007ac9d05d168f  nop
00007ac9d05d1690  mov rax, [r15+0x98]
00007ac9d05d1697  mov r14, [r15+0x58]
00007ac9d05d169b  mov [rsp+0x10], r14
00007ac9d05d16a0  shl r14, 0x02
00007ac9d05d16a4  lea r12, [rax+r14*1]
00007ac9d05d16a8  mov eax, [r13+r12*1]
00007ac9d05d16ad  lea r14, [r12+0x04]
00007ac9d05d16b2  mov r12d, [r13+r14*1]
00007ac9d05d16b7  mov eax, eax
00007ac9d05d16b9  mov [r15+0x68], rax
00007ac9d05d16bd  mov r12d, r12d
00007ac9d05d16c0  mov [r15+0x60], r12
00007ac9d05d16c4  mov rax, [r15+0x68]
00007ac9d05d16c8  mov [rsp+0x20], rax
00007ac9d05d16cd  mov r14, [rsp+0x10]
00007ac9d05d16d2  imul rax, r14
00007ac9d05d16d6  mov r12, [rsp+0x20]
00007ac9d05d16db  lea r11, [r12+rax*1]
00007ac9d05d16df  mov [r15+0x68], r11
00007ac9d05d16e3  lea rax, [r14+0x02]
00007ac9d05d16e7  mov [r15+0x58], rax
00007ac9d05d16eb  mov [rsp+0x10], rax
00007ac9d05d16f0  xor eax, eax
00007ac9d05d16f2  mov r14, [rsp+0x10]
00007ac9d05d16f7  mov r12d, 0x400
00007ac9d05d16fd  cmp r14, r12
00007ac9d05d1700  cmc
00007ac9d05d1701  lahf
00007ac9d05d1702  seto al
00007ac9d05d1705  mov [r15+0x108], eax
00007ac9d05d170c  mov rax, [r15+0x50]
00007ac9d05d1710  mov r12, [r15+0x60]
00007ac9d05d1714  imul r14, r12
00007ac9d05d1718  lea r12, [rax+r14*1]
00007ac9d05d171c  mov [r15+0x50], r12
00007ac9d05d1720  mov rax, [r15+0x48]
00007ac9d05d1724  lea r14, [r11+rax*1]
00007ac9d05d1728  mov [r15+0x48], r14
00007ac9d05d172c  mov eax, [r15+0x108]
00007ac9d05d1733  sahf
00007ac9d05d1734  jnz 0x00007AC9D05D1766
00007ac9d05d1736  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d173e  jz 0x00007AC9D05D17B0
00007ac9d05d1744  nop [rax+rax*1], ax
00007ac9d05d174d  nop [rax+rax*1], eax
00007ac9d05d1755  mov eax, 0x4103D0
00007ac9d05d175a  mov [r15+0x100], rax
00007ac9d05d1761  jmp 0x00007AC9D03FE110
00007ac9d05d1766  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d176e  jz 0x00007AC9D05D1690
00007ac9d05d1774  nop [rax+rax*1], ax
00007ac9d05d177d  nop [rax+rax*1], eax
00007ac9d05d1785  mov eax, 0x4103B0
00007ac9d05d178a  mov [r15+0x100], rax
00007ac9d05d1791  jmp 0x00007AC9D03FE110
00007ac9d05d1796  int3
00007ac9d05d1797  call 0x00007AC9D04B4690
00007ac9d05d179c  jmp 0x00007AC9D05D16AD
00007ac9d05d17a1  call 0x00007AC9D04E26A0
00007ac9d05d17a6  jmp 0x00007AC9D05D16B7
00007ac9d05d17ab  int3
00007ac9d05d17ac  nop [rax], eax
00007ac9d05d17b0  mov qword ptr [r15+0x98], 0x00
00007ac9d05d17bb  mov rax, [r15+0x50]
00007ac9d05d17bf  mov r14, [r15+0x48]
00007ac9d05d17c3  lea r12, [rax+r14*1]
00007ac9d05d17c7  mov [r15+0x48], r12
00007ac9d05d17cb  mov rax, [r15+0x40]
00007ac9d05d17cf  lea r14, [rax+0xC40]
00007ac9d05d17d6  mov [r13+r14*1], r12
00007ac9d05d17db  mov qword ptr [r15], 0x01
00007ac9d05d17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007ac9d05d17ed  mov r14d, [r15+0x320]
00007ac9d05d17f4  mov eax, 0x4103E8
00007ac9d05d17f9  mov rcx, 0x7AC9D05D1860
00007ac9d05d1803  mov [r15+r14*8+0x328], rax
00007ac9d05d180b  mov [r15+r14*8+0x368], rcx
00007ac9d05d1813  add r14d, 0x01
00007ac9d05d1817  and r14d, 0x07
00007ac9d05d181b  mov [r15+0x320], r14d
00007ac9d05d1822  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d182a  jz 0x00007AC9D05D0F20
00007ac9d05d1830  nop [rax+rax*1], ax
00007ac9d05d1839  nop [rax+rax*1], eax
00007ac9d05d1841  mov eax, 0x410938
00007ac9d05d1846  mov [r15+0x100], rax
00007ac9d05d184d  jmp 0x00007AC9D03FE110
00007ac9d05d1852  int3
00007ac9d05d1853  call 0x00007AC9D04E2CE0
00007ac9d05d1858  jmp 0x00007AC9D05D17DB
00007ac9d05d185d  int3
00007ac9d05d185e  nop
00007ac9d05d1860  mov eax, [r15+0x98]
00007ac9d05d1867  lea r14d, [eax+0x01]
00007ac9d05d186c  mov [rsp+0x10], r14d
00007ac9d05d1871  mov r14d, r14d
00007ac9d05d1874  mov [r15+0x98], r14
00007ac9d05d187b  xor eax, eax
00007ac9d05d187d  mov r14d, [rsp+0x10]
00007ac9d05d1882  cmp r14d, 0x10000
00007ac9d05d1889  cmc
00007ac9d05d188a  lahf
00007ac9d05d188b  seto al
00007ac9d05d188e  mov [r15+0x108], eax
00007ac9d05d1895  mov eax, [r15+0x108]
00007ac9d05d189c  sahf
00007ac9d05d189d  jnz 0x00007AC9D05D18CF
00007ac9d05d189f  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d18a7  jz 0x00007AC9D05D19A0
00007ac9d05d18ad  nop [rax+rax*1], ax
00007ac9d05d18b6  nop [rax+rax*1], eax
00007ac9d05d18be  mov eax, 0x4103F4
00007ac9d05d18c3  mov [r15+0x100], rax
00007ac9d05d18ca  jmp 0x00007AC9D03FE110
00007ac9d05d18cf  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d18d7  jz 0x00007AC9D05D1910
00007ac9d05d18dd  nop [rax+rax*1], ax
00007ac9d05d18e6  nop [rax+rax*1], eax
00007ac9d05d18ee  mov eax, 0x4103E0
00007ac9d05d18f3  mov [r15+0x100], rax
00007ac9d05d18fa  jmp 0x00007AC9D03FE110
00007ac9d05d18ff  int3
00007ac9d05d1900  int3
00007ac9d05d1901  nop [rax+rax*1], ax
00007ac9d05d190a  nop [rax+rax*1], ax
00007ac9d05d1910  mov eax, [r15]
00007ac9d05d1913  mov r14d, [r15+0x98]
00007ac9d05d191a  lea r12d, [eax+r14d*1]
00007ac9d05d191f  mov r12d, r12d
00007ac9d05d1922  mov [r15], r12
00007ac9d05d1925  mov qword ptr [r15+0xF0], 0x4103E8
00007ac9d05d1930  mov r14d, [r15+0x320]
00007ac9d05d1937  mov eax, 0x4103E8
00007ac9d05d193c  mov rcx, 0x7AC9D05D1860
00007ac9d05d1946  mov [r15+r14*8+0x328], rax
00007ac9d05d194e  mov [r15+r14*8+0x368], rcx
00007ac9d05d1956  add r14d, 0x01
00007ac9d05d195a  and r14d, 0x07
00007ac9d05d195e  mov [r15+0x320], r14d
00007ac9d05d1965  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d196d  jz 0x00007AC9D05D0F20
00007ac9d05d1973  nop [rax+rax*1], ax
00007ac9d05d197c  nop [rax+rax*1], eax
00007ac9d05d1984  mov eax, 0x410938
00007ac9d05d1989  mov [r15+0x100], rax
00007ac9d05d1990  jmp 0x00007AC9D03FE110
00007ac9d05d1995  int3
00007ac9d05d1996  int3
00007ac9d05d1997  nop [rax+rax*1], ax
00007ac9d05d19a0  vmovaps xmm1, [0x00007AC9D01FE010]
00007ac9d05d19a8  movq xmm1, xmm1
00007ac9d05d19ac  movaps [r15+0x110], xmm1
00007ac9d05d19b4  mov eax, 0x420AA0
00007ac9d05d19b9  mov r14, [r13+rax*1]
00007ac9d05d19be  movq xmm1, r14
00007ac9d05d19c3  movaps [r15+0x120], xmm1
00007ac9d05d19cb  vmovaps xmm1, [0x00007AC9D01FE020]
00007ac9d05d19d3  movq xmm1, xmm1
00007ac9d05d19d7  movaps [r15+0x140], xmm1
00007ac9d05d19df  vmovaps xmm1, [0x00007AC9D01FE030]
00007ac9d05d19e7  vpbroadcastq xmm1, xmm1
00007ac9d05d19ec  movaps [r15+0x150], xmm1
00007ac9d05d19f4  mov qword ptr [r15+0x40], 0x02
00007ac9d05d19fc  vmovaps xmm15, [0x00007AC9D01FE040]
00007ac9d05d1a04  movq xmm15, xmm15
00007ac9d05d1a09  movaps [r15+0x160], xmm15
00007ac9d05d1a11  vmovaps xmm15, [0x00007AC9D01FE050]
00007ac9d05d1a19  vpbroadcastq xmm15, xmm15
00007ac9d05d1a1e  movaps [r15+0x130], xmm15
00007ac9d05d1a26  mov rax, [r15+0x40]
00007ac9d05d1a2a  vmovq xmm14, rax
00007ac9d05d1a2f  vpbroadcastq xmm14, xmm14
00007ac9d05d1a34  movaps [r15+0x170], xmm14
00007ac9d05d1a3c  mov eax, 0x4209D0
00007ac9d05d1a41  movups xmm13, [r13+rax*1]
00007ac9d05d1a47  mov qword ptr [r15+0x40], 0x431D90
00007ac9d05d1a4f  mov eax, [r15]
00007ac9d05d1a52  mov r14d, 0x430C48
00007ac9d05d1a58  mov [r13+r14*1], eax
00007ac9d05d1a5d  mov qword ptr [r15+0x50], 0x431F90
00007ac9d05d1a65  vpmovqd xmm12, xmm13
00007ac9d05d1a6b  pxor xmm11, xmm11
00007ac9d05d1a70  punpcklqdq xmm12, xmm11
00007ac9d05d1a75  movaps [r15+0x210], xmm12
00007ac9d05d1a7d  movq xmm12, qword ptr [r15+0x140]
00007ac9d05d1a86  movq xmm11, qword ptr [r15+0x120]
00007ac9d05d1a8f  psubd xmm12, xmm11
00007ac9d05d1a94  movq xmm12, xmm12
00007ac9d05d1a99  paddq xmm13, xmm14
00007ac9d05d1a9e  movaps [r15+0x180], xmm13
00007ac9d05d1aa6  movq xmm14, qword ptr [r15+0x160]
00007ac9d05d1aaf  paddd xmm11, xmm14
00007ac9d05d1ab4  movq xmm11, xmm11
00007ac9d05d1ab9  movq xmm11, xmm11
00007ac9d05d1abe  movaps [r15+0x120], xmm11
00007ac9d05d1ac6  pmovzxdq xmm12, xmm12
00007ac9d05d1acc  psllq xmm12, 0x00
00007ac9d05d1ad2  movq xmm14, qword ptr [r15+0x210]
00007ac9d05d1adb  movq xmm13, qword ptr [r15+0x110]
00007ac9d05d1ae4  paddd xmm14, xmm13
00007ac9d05d1ae9  movq xmm14, xmm14
00007ac9d05d1aee  vcvtuqq2pd xmm12, xmm12
00007ac9d05d1af4  pmovzxdq xmm14, xmm14
00007ac9d05d1afa  psllq xmm14, 0x00
00007ac9d05d1b00  vcvtuqq2pd xmm14, xmm14
00007ac9d05d1b06  movaps xmm13, xmm12
00007ac9d05d1b0a  mulpd xmm13, xmm1
00007ac9d05d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007ac9d05d1b15  ptest xmm11, xmm11
00007ac9d05d1b1b  jnz 0x00007AC9D05D1C0F
00007ac9d05d1b21  movaps [r15+0x220], xmm13
00007ac9d05d1b29  mov eax, 0x431F90
00007ac9d05d1b2e  movups [r13+rax*1], xmm13
00007ac9d05d1b34  movaps xmm1, xmm14
00007ac9d05d1b38  mulpd xmm1, xmm15
00007ac9d05d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007ac9d05d1b42  ptest xmm13, xmm13
00007ac9d05d1b48  jnz 0x00007AC9D05D1D5C
00007ac9d05d1b4e  movaps [r15+0x210], xmm1
00007ac9d05d1b56  mov eax, 0x431D90
00007ac9d05d1b5b  movups [r13+rax*1], xmm1
00007ac9d05d1b61  mov qword ptr [r15+0x48], 0x10
00007ac9d05d1b69  xor eax, eax
00007ac9d05d1b6b  mov r14d, 0x10
00007ac9d05d1b71  mov r12d, 0x200
00007ac9d05d1b77  cmp r14, r12
00007ac9d05d1b7a  cmc
00007ac9d05d1b7b  lahf
00007ac9d05d1b7c  seto al
00007ac9d05d1b7f  mov [r15+0x108], eax
00007ac9d05d1b86  mov eax, [r15+0x108]
00007ac9d05d1b8d  sahf
00007ac9d05d1b8e  jnz 0x00007AC9D05D1BC0
00007ac9d05d1b90  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d1b98  jz 0x00007AC9D05D2300
00007ac9d05d1b9e  nop [rax+rax*1], ax
00007ac9d05d1ba7  nop [rax+rax*1], eax
00007ac9d05d1baf  mov eax, 0x410480
00007ac9d05d1bb4  mov [r15+0x100], rax
00007ac9d05d1bbb  jmp 0x00007AC9D03FE110
00007ac9d05d1bc0  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d1bc8  jz 0x00007AC9D05D1EB0
00007ac9d05d1bce  nop [rax+rax*1], ax
00007ac9d05d1bd7  nop [rax+rax*1], eax
00007ac9d05d1bdf  mov eax, 0x410440
00007ac9d05d1be4  mov [r15+0x100], rax
00007ac9d05d1beb  jmp 0x00007AC9D03FE110
00007ac9d05d1bf0  int3
00007ac9d05d1bf1  call 0x00007AC9D040DC20
00007ac9d05d1bf6  jmp 0x00007AC9D05D19BE
00007ac9d05d1bfb  call 0x00007AC9D040C260
00007ac9d05d1c00  jmp 0x00007AC9D05D1A47
00007ac9d05d1c05  call 0x00007AC9D04D5D70
00007ac9d05d1c0a  jmp 0x00007AC9D05D1A5D
00007ac9d05d1c0f  sub rsp, 0x08
00007ac9d05d1c13  push rax
00007ac9d05d1c14  push rcx
00007ac9d05d1c15  push rdx
00007ac9d05d1c16  push rdi
00007ac9d05d1c17  push rsi
00007ac9d05d1c18  push r8
00007ac9d05d1c1a  push r9
00007ac9d05d1c1c  push r10
00007ac9d05d1c1e  push r11
00007ac9d05d1c20  sub rsp, 0xF0
00007ac9d05d1c27  vmovaps [rsp], xmm0
00007ac9d05d1c2c  vmovaps [rsp+0x10], xmm1
00007ac9d05d1c32  vmovaps [rsp+0x20], xmm2
00007ac9d05d1c38  vmovaps [rsp+0x30], xmm3
00007ac9d05d1c3e  vmovaps [rsp+0x40], xmm4
00007ac9d05d1c44  vmovaps [rsp+0x50], xmm5
00007ac9d05d1c4a  vmovaps [rsp+0x60], xmm6
00007ac9d05d1c50  vmovaps [rsp+0x70], xmm7
00007ac9d05d1c56  vmovaps [rsp+0x80], xmm8
00007ac9d05d1c5f  vmovaps [rsp+0x90], xmm9
00007ac9d05d1c68  vmovaps [rsp+0xA0], xmm10
00007ac9d05d1c71  vmovaps [rsp+0xB0], xmm11
00007ac9d05d1c7a  vmovaps [rsp+0xC0], xmm12
00007ac9d05d1c83  vmovaps [rsp+0xD0], xmm14
00007ac9d05d1c8c  vmovaps [rsp+0xE0], xmm15
00007ac9d05d1c95  sub rsp, 0x30
00007ac9d05d1c99  movaps [rsp], xmm13
00007ac9d05d1c9e  movaps [rsp+0x10], xmm12
00007ac9d05d1ca4  movaps [rsp+0x20], xmm1
00007ac9d05d1ca9  lea rdi, [rsp]
00007ac9d05d1cad  mov esi, 0x00
00007ac9d05d1cb2  mov rax, 0x569AF9F93530
00007ac9d05d1cbc  call rax
00007ac9d05d1cbe  movaps xmm13, [rsp]
00007ac9d05d1cc3  add rsp, 0x30
00007ac9d05d1cc7  vmovaps xmm0, [rsp]
00007ac9d05d1ccc  vmovaps xmm1, [rsp+0x10]
00007ac9d05d1cd2  vmovaps xmm2, [rsp+0x20]
00007ac9d05d1cd8  vmovaps xmm3, [rsp+0x30]
00007ac9d05d1cde  vmovaps xmm4, [rsp+0x40]
00007ac9d05d1ce4  vmovaps xmm5, [rsp+0x50]
00007ac9d05d1cea  vmovaps xmm6, [rsp+0x60]
00007ac9d05d1cf0  vmovaps xmm7, [rsp+0x70]
00007ac9d05d1cf6  vmovaps xmm8, [rsp+0x80]
00007ac9d05d1cff  vmovaps xmm9, [rsp+0x90]
00007ac9d05d1d08  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d1d11  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d1d1a  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d1d23  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d1d2c  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d1d35  add rsp, 0xF0
00007ac9d05d1d3c  pop r11
00007ac9d05d1d3e  pop r10
00007ac9d05d1d40  pop r9
00007ac9d05d1d42  pop r8
00007ac9d05d1d44  pop rsi
00007ac9d05d1d45  pop rdi
00007ac9d05d1d46  pop rdx
00007ac9d05d1d47  pop rcx
00007ac9d05d1d48  pop rax
00007ac9d05d1d49  add rsp, 0x08
00007ac9d05d1d4d  jmp 0x00007AC9D05D1B21
00007ac9d05d1d52  call 0x00007AC9D040C380
00007ac9d05d1d57  jmp 0x00007AC9D05D1B34
00007ac9d05d1d5c  sub rsp, 0x08
00007ac9d05d1d60  push rax
00007ac9d05d1d61  push rcx
00007ac9d05d1d62  push rdx
00007ac9d05d1d63  push rdi
00007ac9d05d1d64  push rsi
00007ac9d05d1d65  push r8
00007ac9d05d1d67  push r9
00007ac9d05d1d69  push r10
00007ac9d05d1d6b  push r11
00007ac9d05d1d6d  sub rsp, 0xF0
00007ac9d05d1d74  vmovaps [rsp], xmm0
00007ac9d05d1d79  vmovaps [rsp+0x10], xmm2
00007ac9d05d1d7f  vmovaps [rsp+0x20], xmm3
00007ac9d05d1d85  vmovaps [rsp+0x30], xmm4
00007ac9d05d1d8b  vmovaps [rsp+0x40], xmm5
00007ac9d05d1d91  vmovaps [rsp+0x50], xmm6
00007ac9d05d1d97  vmovaps [rsp+0x60], xmm7
00007ac9d05d1d9d  vmovaps [rsp+0x70], xmm8
00007ac9d05d1da3  vmovaps [rsp+0x80], xmm9
00007ac9d05d1dac  vmovaps [rsp+0x90], xmm10
00007ac9d05d1db5  vmovaps [rsp+0xA0], xmm11
00007ac9d05d1dbe  vmovaps [rsp+0xB0], xmm12
00007ac9d05d1dc7  vmovaps [rsp+0xC0], xmm13
00007ac9d05d1dd0  vmovaps [rsp+0xD0], xmm14
00007ac9d05d1dd9  vmovaps [rsp+0xE0], xmm15
00007ac9d05d1de2  sub rsp, 0x30
00007ac9d05d1de6  movaps [rsp], xmm1
00007ac9d05d1dea  movaps [rsp+0x10], xmm14
00007ac9d05d1df0  movaps [rsp+0x20], xmm15
00007ac9d05d1df6  lea rdi, [rsp]
00007ac9d05d1dfa  mov esi, 0x00
00007ac9d05d1dff  mov rax, 0x569AF9F93530
00007ac9d05d1e09  call rax
00007ac9d05d1e0b  movaps xmm1, [rsp]
00007ac9d05d1e0f  add rsp, 0x30
00007ac9d05d1e13  vmovaps xmm0, [rsp]
00007ac9d05d1e18  vmovaps xmm2, [rsp+0x10]
00007ac9d05d1e1e  vmovaps xmm3, [rsp+0x20]
00007ac9d05d1e24  vmovaps xmm4, [rsp+0x30]
00007ac9d05d1e2a  vmovaps xmm5, [rsp+0x40]
00007ac9d05d1e30  vmovaps xmm6, [rsp+0x50]
00007ac9d05d1e36  vmovaps xmm7, [rsp+0x60]
00007ac9d05d1e3c  vmovaps xmm8, [rsp+0x70]
00007ac9d05d1e42  vmovaps xmm9, [rsp+0x80]
00007ac9d05d1e4b  vmovaps xmm10, [rsp+0x90]
00007ac9d05d1e54  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d1e5d  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d1e66  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d1e6f  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d1e78  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d1e81  add rsp, 0xF0
00007ac9d05d1e88  pop r11
00007ac9d05d1e8a  pop r10
00007ac9d05d1e8c  pop r9
00007ac9d05d1e8e  pop r8
00007ac9d05d1e90  pop rsi
00007ac9d05d1e91  pop rdi
00007ac9d05d1e92  pop rdx
00007ac9d05d1e93  pop rcx
00007ac9d05d1e94  pop rax
00007ac9d05d1e95  add rsp, 0x08
00007ac9d05d1e99  jmp 0x00007AC9D05D1B4E
00007ac9d05d1e9e  call 0x00007AC9D03FF540
00007ac9d05d1ea3  jmp 0x00007AC9D05D1B61
00007ac9d05d1ea8  int3
00007ac9d05d1ea9  nop [rax], eax
00007ac9d05d1eb0  movaps xmm1, [r15+0x180]
00007ac9d05d1eb8  vpmovqd xmm15, xmm1
00007ac9d05d1ebe  pxor xmm14, xmm14
00007ac9d05d1ec3  punpcklqdq xmm15, xmm14
00007ac9d05d1ec8  movaps [r15+0x210], xmm15
00007ac9d05d1ed0  movq xmm15, qword ptr [r15+0x140]
00007ac9d05d1ed9  movq xmm14, qword ptr [r15+0x120]
00007ac9d05d1ee2  psubd xmm15, xmm14
00007ac9d05d1ee7  movq xmm15, xmm15
00007ac9d05d1eec  movaps xmm13, [r15+0x170]
00007ac9d05d1ef4  paddq xmm1, xmm13
00007ac9d05d1ef9  movaps [r15+0x180], xmm1
00007ac9d05d1f01  movq xmm1, qword ptr [r15+0x160]
00007ac9d05d1f0a  paddd xmm14, xmm1
00007ac9d05d1f0f  movq xmm14, xmm14
00007ac9d05d1f14  movq xmm14, xmm14
00007ac9d05d1f19  movaps [r15+0x120], xmm14
00007ac9d05d1f21  pmovzxdq xmm15, xmm15
00007ac9d05d1f27  psllq xmm15, 0x00
00007ac9d05d1f2d  movq xmm1, qword ptr [r15+0x210]
00007ac9d05d1f36  movq xmm14, qword ptr [r15+0x110]
00007ac9d05d1f3f  paddd xmm1, xmm14
00007ac9d05d1f44  movq xmm1, xmm1
00007ac9d05d1f48  vcvtuqq2pd xmm15, xmm15
00007ac9d05d1f4e  pmovzxdq xmm1, xmm1
00007ac9d05d1f53  psllq xmm1, 0x00
00007ac9d05d1f58  vcvtuqq2pd xmm1, xmm1
00007ac9d05d1f5e  movaps xmm14, [r15+0x150]
00007ac9d05d1f66  movaps xmm13, xmm15
00007ac9d05d1f6a  mulpd xmm13, xmm14
00007ac9d05d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d1f75  ptest xmm12, xmm12
00007ac9d05d1f7b  jnz 0x00007AC9D05D205E
00007ac9d05d1f81  movaps [r15+0x220], xmm13
00007ac9d05d1f89  mov rax, [r15+0x48]
00007ac9d05d1f8d  mov r14, [r15+0x50]
00007ac9d05d1f91  lea r12, [r14+rax*1]
00007ac9d05d1f95  movups [r13+r12*1], xmm13
00007ac9d05d1f9b  movaps xmm15, [r15+0x130]
00007ac9d05d1fa3  movaps xmm14, xmm1
00007ac9d05d1fa7  mulpd xmm14, xmm15
00007ac9d05d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007ac9d05d1fb2  ptest xmm13, xmm13
00007ac9d05d1fb8  jnz 0x00007AC9D05D21AC
00007ac9d05d1fbe  movaps [r15+0x210], xmm14
00007ac9d05d1fc6  mov r14, [r15+0x40]
00007ac9d05d1fca  lea r12, [r14+rax*1]
00007ac9d05d1fce  movups [r13+r12*1], xmm14
00007ac9d05d1fd4  lea r14, [rax+0x10]
00007ac9d05d1fd8  mov [r15+0x48], r14
00007ac9d05d1fdc  xor eax, eax
00007ac9d05d1fde  mov r12d, 0x200
00007ac9d05d1fe4  cmp r14, r12
00007ac9d05d1fe7  cmc
00007ac9d05d1fe8  lahf
00007ac9d05d1fe9  seto al
00007ac9d05d1fec  mov [r15+0x108], eax
00007ac9d05d1ff3  mov eax, [r15+0x108]
00007ac9d05d1ffa  sahf
00007ac9d05d1ffb  jnz 0x00007AC9D05D202D
00007ac9d05d1ffd  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d2005  jz 0x00007AC9D05D2300
00007ac9d05d200b  nop [rax+rax*1], ax
00007ac9d05d2014  nop [rax+rax*1], eax
00007ac9d05d201c  mov eax, 0x410480
00007ac9d05d2021  mov [r15+0x100], rax
00007ac9d05d2028  jmp 0x00007AC9D03FE110
00007ac9d05d202d  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d2035  jz 0x00007AC9D05D1EB0
00007ac9d05d203b  nop [rax+rax*1], ax
00007ac9d05d2044  nop [rax+rax*1], eax
00007ac9d05d204c  mov eax, 0x410440
00007ac9d05d2051  mov [r15+0x100], rax
00007ac9d05d2058  jmp 0x00007AC9D03FE110
00007ac9d05d205d  int3
00007ac9d05d205e  sub rsp, 0x08
00007ac9d05d2062  push rax
00007ac9d05d2063  push rcx
00007ac9d05d2064  push rdx
00007ac9d05d2065  push rdi
00007ac9d05d2066  push rsi
00007ac9d05d2067  push r8
00007ac9d05d2069  push r9
00007ac9d05d206b  push r10
00007ac9d05d206d  push r11
00007ac9d05d206f  sub rsp, 0xF0
00007ac9d05d2076  vmovaps [rsp], xmm0
00007ac9d05d207b  vmovaps [rsp+0x10], xmm1
00007ac9d05d2081  vmovaps [rsp+0x20], xmm2
00007ac9d05d2087  vmovaps [rsp+0x30], xmm3
00007ac9d05d208d  vmovaps [rsp+0x40], xmm4
00007ac9d05d2093  vmovaps [rsp+0x50], xmm5
00007ac9d05d2099  vmovaps [rsp+0x60], xmm6
00007ac9d05d209f  vmovaps [rsp+0x70], xmm7
00007ac9d05d20a5  vmovaps [rsp+0x80], xmm8
00007ac9d05d20ae  vmovaps [rsp+0x90], xmm9
00007ac9d05d20b7  vmovaps [rsp+0xA0], xmm10
00007ac9d05d20c0  vmovaps [rsp+0xB0], xmm11
00007ac9d05d20c9  vmovaps [rsp+0xC0], xmm12
00007ac9d05d20d2  vmovaps [rsp+0xD0], xmm14
00007ac9d05d20db  vmovaps [rsp+0xE0], xmm15
00007ac9d05d20e4  sub rsp, 0x30
00007ac9d05d20e8  movaps [rsp], xmm13
00007ac9d05d20ed  movaps [rsp+0x10], xmm15
00007ac9d05d20f3  movaps [rsp+0x20], xmm14
00007ac9d05d20f9  lea rdi, [rsp]
00007ac9d05d20fd  mov esi, 0x00
00007ac9d05d2102  mov rax, 0x569AF9F93530
00007ac9d05d210c  call rax
00007ac9d05d210e  movaps xmm13, [rsp]
00007ac9d05d2113  add rsp, 0x30
00007ac9d05d2117  vmovaps xmm0, [rsp]
00007ac9d05d211c  vmovaps xmm1, [rsp+0x10]
00007ac9d05d2122  vmovaps xmm2, [rsp+0x20]
00007ac9d05d2128  vmovaps xmm3, [rsp+0x30]
00007ac9d05d212e  vmovaps xmm4, [rsp+0x40]
00007ac9d05d2134  vmovaps xmm5, [rsp+0x50]
00007ac9d05d213a  vmovaps xmm6, [rsp+0x60]
00007ac9d05d2140  vmovaps xmm7, [rsp+0x70]
00007ac9d05d2146  vmovaps xmm8, [rsp+0x80]
00007ac9d05d214f  vmovaps xmm9, [rsp+0x90]
00007ac9d05d2158  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d2161  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d216a  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d2173  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d217c  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d2185  add rsp, 0xF0
00007ac9d05d218c  pop r11
00007ac9d05d218e  pop r10
00007ac9d05d2190  pop r9
00007ac9d05d2192  pop r8
00007ac9d05d2194  pop rsi
00007ac9d05d2195  pop rdi
00007ac9d05d2196  pop rdx
00007ac9d05d2197  pop rcx
00007ac9d05d2198  pop rax
00007ac9d05d2199  add rsp, 0x08
00007ac9d05d219d  jmp 0x00007AC9D05D1F81
00007ac9d05d21a2  call 0x00007AC9D04C2240
00007ac9d05d21a7  jmp 0x00007AC9D05D1F9B
00007ac9d05d21ac  sub rsp, 0x08
00007ac9d05d21b0  push rax
00007ac9d05d21b1  push rcx
00007ac9d05d21b2  push rdx
00007ac9d05d21b3  push rdi
00007ac9d05d21b4  push rsi
00007ac9d05d21b5  push r8
00007ac9d05d21b7  push r9
00007ac9d05d21b9  push r10
00007ac9d05d21bb  push r11
00007ac9d05d21bd  sub rsp, 0xF0
00007ac9d05d21c4  vmovaps [rsp], xmm0
00007ac9d05d21c9  vmovaps [rsp+0x10], xmm1
00007ac9d05d21cf  vmovaps [rsp+0x20], xmm2
00007ac9d05d21d5  vmovaps [rsp+0x30], xmm3
00007ac9d05d21db  vmovaps [rsp+0x40], xmm4
00007ac9d05d21e1  vmovaps [rsp+0x50], xmm5
00007ac9d05d21e7  vmovaps [rsp+0x60], xmm6
00007ac9d05d21ed  vmovaps [rsp+0x70], xmm7
00007ac9d05d21f3  vmovaps [rsp+0x80], xmm8
00007ac9d05d21fc  vmovaps [rsp+0x90], xmm9
00007ac9d05d2205  vmovaps [rsp+0xA0], xmm10
00007ac9d05d220e  vmovaps [rsp+0xB0], xmm11
00007ac9d05d2217  vmovaps [rsp+0xC0], xmm12
00007ac9d05d2220  vmovaps [rsp+0xD0], xmm13
00007ac9d05d2229  vmovaps [rsp+0xE0], xmm15
00007ac9d05d2232  sub rsp, 0x30
00007ac9d05d2236  movaps [rsp], xmm14
00007ac9d05d223b  movaps [rsp+0x10], xmm1
00007ac9d05d2240  movaps [rsp+0x20], xmm15
00007ac9d05d2246  lea rdi, [rsp]
00007ac9d05d224a  mov esi, 0x00
00007ac9d05d224f  mov rax, 0x569AF9F93530
00007ac9d05d2259  call rax
00007ac9d05d225b  movaps xmm14, [rsp]
00007ac9d05d2260  add rsp, 0x30
00007ac9d05d2264  vmovaps xmm0, [rsp]
00007ac9d05d2269  vmovaps xmm1, [rsp+0x10]
00007ac9d05d226f  vmovaps xmm2, [rsp+0x20]
00007ac9d05d2275  vmovaps xmm3, [rsp+0x30]
00007ac9d05d227b  vmovaps xmm4, [rsp+0x40]
00007ac9d05d2281  vmovaps xmm5, [rsp+0x50]
00007ac9d05d2287  vmovaps xmm6, [rsp+0x60]
00007ac9d05d228d  vmovaps xmm7, [rsp+0x70]
00007ac9d05d2293  vmovaps xmm8, [rsp+0x80]
00007ac9d05d229c  vmovaps xmm9, [rsp+0x90]
00007ac9d05d22a5  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d22ae  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d22b7  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d22c0  vmovaps xmm13, [rsp+0xD0]
00007ac9d05d22c9  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d22d2  add rsp, 0xF0
00007ac9d05d22d9  pop r11
00007ac9d05d22db  pop r10
00007ac9d05d22dd  pop r9
00007ac9d05d22df  pop r8
00007ac9d05d22e1  pop rsi
00007ac9d05d22e2  pop rdi
00007ac9d05d22e3  pop rdx
00007ac9d05d22e4  pop rcx
00007ac9d05d22e5  pop rax
00007ac9d05d22e6  add rsp, 0x08
00007ac9d05d22ea  jmp 0x00007AC9D05D1FBE
00007ac9d05d22ef  call 0x00007AC9D04C34C0
00007ac9d05d22f4  jmp 0x00007AC9D05D1FD4
00007ac9d05d22f9  int3
00007ac9d05d22fa  nop [rax+rax*1], ax
00007ac9d05d2300  mov rax, [r15+0x50]
00007ac9d05d2304  movups xmm1, [r13+rax*1]
00007ac9d05d230a  lea r14, [rax+0x10]
00007ac9d05d230e  movups xmm15, [r13+r14*1]
00007ac9d05d2314  mov qword ptr [r15+0x48], 0x00
00007ac9d05d231c  lea r14, [rax+0x40]
00007ac9d05d2320  movups xmm14, [r13+r14*1]
00007ac9d05d2326  lea r14, [rax+0x50]
00007ac9d05d232a  movups xmm13, [r13+r14*1]
00007ac9d05d2330  lea r14, [rax+0x80]
00007ac9d05d2337  movups xmm12, [r13+r14*1]
00007ac9d05d233d  lea r14, [rax+0x90]
00007ac9d05d2344  movups xmm11, [r13+r14*1]
00007ac9d05d234a  mov r14, [r15+0xF8]
00007ac9d05d2351  movups [r13+r14*1], xmm1
00007ac9d05d2357  lea r12, [rax+0x20]
00007ac9d05d235b  movups xmm1, [r13+r12*1]
00007ac9d05d2361  lea r12, [rax+0x30]
00007ac9d05d2365  movups xmm10, [r13+r12*1]
00007ac9d05d236b  lea r12, [rax+0xC0]
00007ac9d05d2372  movups xmm9, [r13+r12*1]
00007ac9d05d2378  lea r12, [rax+0xD0]
00007ac9d05d237f  movups xmm8, [r13+r12*1]
00007ac9d05d2385  lea r12, [rax+0x100]
00007ac9d05d238c  movups xmm7, [r13+r12*1]
00007ac9d05d2392  lea r12, [rax+0x110]
00007ac9d05d2399  movups xmm6, [r13+r12*1]
00007ac9d05d239f  lea r12, [rax+0x140]
00007ac9d05d23a6  movups xmm5, [r13+r12*1]
00007ac9d05d23ac  lea r12, [rax+0x150]
00007ac9d05d23b3  movups xmm4, [r13+r12*1]
00007ac9d05d23b9  lea r12, [r14+0xB0]
00007ac9d05d23c0  movups [r13+r12*1], xmm10
00007ac9d05d23c6  lea r12, [r14+0xC0]
00007ac9d05d23cd  movups [r13+r12*1], xmm1
00007ac9d05d23d3  lea r12, [rax+0x180]
00007ac9d05d23da  movups xmm1, [r13+r12*1]
00007ac9d05d23e0  lea r12, [rax+0x190]
00007ac9d05d23e7  movups xmm10, [r13+r12*1]
00007ac9d05d23ed  lea r12, [rax+0x1C0]
00007ac9d05d23f4  movups xmm3, [r13+r12*1]
00007ac9d05d23fa  lea r12, [rax+0x1D0]
00007ac9d05d2401  movups xmm2, [r13+r12*1]
00007ac9d05d2407  lea r12, [rax+0x60]
00007ac9d05d240b  vmovaps [rsp+0x10], xmm1
00007ac9d05d2411  movups xmm1, [r13+r12*1]
00007ac9d05d2417  lea r12, [rax+0x70]
00007ac9d05d241b  vmovaps [rsp+0x20], xmm1
00007ac9d05d2421  movups xmm1, [r13+r12*1]
00007ac9d05d2427  lea r12, [r14+0x70]
00007ac9d05d242b  movups [r13+r12*1], xmm10
00007ac9d05d2431  lea r12, [r14+0x80]
00007ac9d05d2438  vmovaps xmm10, [rsp+0x10]
00007ac9d05d243e  movups [r13+r12*1], xmm10
00007ac9d05d2444  lea r12, [rax+0xA0]
00007ac9d05d244b  movups xmm10, [r13+r12*1]
00007ac9d05d2451  lea r12, [rax+0xB0]
00007ac9d05d2458  vmovaps [rsp+0x10], xmm1
00007ac9d05d245e  movups xmm1, [r13+r12*1]
00007ac9d05d2464  lea r12, [r14+0x90]
00007ac9d05d246b  movups [r13+r12*1], xmm2
00007ac9d05d2471  lea r12, [r14+0xA0]
00007ac9d05d2478  movups [r13+r12*1], xmm3
00007ac9d05d247e  lea r12, [rax+0xE0]
00007ac9d05d2485  movups xmm3, [r13+r12*1]
00007ac9d05d248b  lea r12, [rax+0xF0]
00007ac9d05d2492  movups xmm2, [r13+r12*1]
00007ac9d05d2498  lea r12, [rax+0x120]
00007ac9d05d249f  vmovaps [rsp+0x30], xmm1
00007ac9d05d24a5  movups xmm1, [r13+r12*1]
00007ac9d05d24ab  lea r12, [rax+0x130]
00007ac9d05d24b2  vmovaps [rsp+0x40], xmm1
00007ac9d05d24b8  movups xmm1, [r13+r12*1]
00007ac9d05d24be  vmovaps [rsp+0x50], xmm1
00007ac9d05d24c4  vmovaps xmm1, [rsp+0x40]
00007ac9d05d24ca  movaps [r15+0x190], xmm1
00007ac9d05d24d2  lea r12, [rax+0x160]
00007ac9d05d24d9  vmovaps [rsp+0x40], xmm1
00007ac9d05d24df  movups xmm1, [r13+r12*1]
00007ac9d05d24e5  lea r12, [rax+0x170]
00007ac9d05d24ec  vmovaps [rsp+0x60], xmm1
00007ac9d05d24f2  movups xmm1, [r13+r12*1]
00007ac9d05d24f8  lea r12, [rax+0x1A0]
00007ac9d05d24ff  vmovaps [rsp+0x70], xmm1
00007ac9d05d2505  movups xmm1, [r13+r12*1]
00007ac9d05d250b  lea r12, [rax+0x1B0]
00007ac9d05d2512  vmovaps [rsp+0x80], xmm1
00007ac9d05d251b  movups xmm1, [r13+r12*1]
00007ac9d05d2521  lea r12, [rax+0x1E0]
00007ac9d05d2528  vmovaps [rsp+0x90], xmm1
00007ac9d05d2531  movups xmm1, [r13+r12*1]
00007ac9d05d2537  lea r12, [rax+0x1F0]
00007ac9d05d253e  vmovaps [rsp+0xA0], xmm1
00007ac9d05d2547  movups xmm1, [r13+r12*1]
00007ac9d05d254d  mov qword ptr [r15+0x50], 0x432190
00007ac9d05d2555  lea rax, [r14+0x50]
00007ac9d05d2559  vmovaps [rsp+0xB0], xmm1
00007ac9d05d2562  vmovaps xmm1, [rsp+0x60]
00007ac9d05d2568  movups [r13+rax*1], xmm1
00007ac9d05d256e  lea rax, [r14+0x60]
00007ac9d05d2572  movups [r13+rax*1], xmm5
00007ac9d05d2578  lea rax, [r14+0x40]
00007ac9d05d257c  vmovaps xmm1, [rsp+0x70]
00007ac9d05d2582  movups [r13+rax*1], xmm1
00007ac9d05d2588  lea rax, [r14+0x20]
00007ac9d05d258c  vmovaps xmm1, [rsp+0xA0]
00007ac9d05d2595  movups [r13+rax*1], xmm1
00007ac9d05d259b  lea rax, [r14+0x30]
00007ac9d05d259f  vmovaps xmm1, [rsp+0x90]
00007ac9d05d25a8  movups [r13+rax*1], xmm1
00007ac9d05d25ae  lea rax, [r14+0x10]
00007ac9d05d25b2  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d25bb  movups [r13+rax*1], xmm1
00007ac9d05d25c1  mov rax, [r15+0x40]
00007ac9d05d25c5  vxorps xmm1, xmm1, xmm1
00007ac9d05d25c9  vpbroadcastq xmm1, xmm1
00007ac9d05d25ce  vxorps xmm5, xmm5, xmm5
00007ac9d05d25d2  vpbroadcastq xmm5, xmm5
00007ac9d05d25d7  lea r12, [rax+0x30]
00007ac9d05d25db  mov r11, [r13+r12*1]
00007ac9d05d25e0  lea r12, [rax+0x38]
00007ac9d05d25e4  mov r10, [r13+r12*1]
00007ac9d05d25e9  vmovaps [rsp+0x60], xmm1
00007ac9d05d25ef  movq xmm1, r11
00007ac9d05d25f4  vmovaps [rsp+0x70], xmm1
00007ac9d05d25fa  movq xmm1, r10
00007ac9d05d25ff  vmovaps [rsp+0x90], xmm1
00007ac9d05d2608  vmovaps xmm1, [rsp+0x70]
00007ac9d05d260e  movq xmm1, xmm1
00007ac9d05d2612  vmovaps [rsp+0x70], xmm1
00007ac9d05d2618  vmovaps xmm1, [rsp+0x90]
00007ac9d05d2621  movq xmm1, xmm1
00007ac9d05d2625  vmovaps [rsp+0x90], xmm1
00007ac9d05d262e  movq xmm1, xmm1
00007ac9d05d2632  movaps [r15+0x270], xmm1
00007ac9d05d263a  vmovaps [rsp+0xA0], xmm7
00007ac9d05d2643  vmovaps xmm1, [rsp+0xA0]
00007ac9d05d264c  por xmm7, xmm1
00007ac9d05d2650  lea r12, [rax+0x20]
00007ac9d05d2654  mov r11, [r13+r12*1]
00007ac9d05d2659  lea r12, [rax+0x28]
00007ac9d05d265d  mov r10, [r13+r12*1]
00007ac9d05d2662  movq xmm1, r11
00007ac9d05d2667  vmovaps [rsp+0xA0], xmm1
00007ac9d05d2670  movq xmm1, r10
00007ac9d05d2675  vmovaps [rsp+0xB0], xmm1
00007ac9d05d267e  vmovaps xmm1, [rsp+0xA0]
00007ac9d05d2687  movq xmm1, xmm1
00007ac9d05d268b  vmovaps [rsp+0xA0], xmm1
00007ac9d05d2694  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d269d  movq xmm1, xmm1
00007ac9d05d26a1  vmovaps [rsp+0xB0], xmm2
00007ac9d05d26aa  vmovaps [rsp+0xC0], xmm1
00007ac9d05d26b3  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d26bc  por xmm2, xmm1
00007ac9d05d26c0  vmovaps [rsp+0xB0], xmm3
00007ac9d05d26c9  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d26d2  por xmm3, xmm1
00007ac9d05d26d6  vmovaps [rsp+0xB0], xmm4
00007ac9d05d26df  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d26e8  por xmm4, xmm1
00007ac9d05d26ec  vmovaps [rsp+0xB0], xmm9
00007ac9d05d26f5  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d26fe  por xmm9, xmm1
00007ac9d05d2703  lea r12, [rax+0x10]
00007ac9d05d2707  mov r11, [r13+r12*1]
00007ac9d05d270c  lea r12, [rax+0x18]
00007ac9d05d2710  mov r10, [r13+r12*1]
00007ac9d05d2715  movq xmm1, r11
00007ac9d05d271a  vmovaps [rsp+0xB0], xmm1
00007ac9d05d2723  movq xmm1, r10
00007ac9d05d2728  vmovaps [rsp+0xD0], xmm1
00007ac9d05d2731  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d273a  movq xmm1, xmm1
00007ac9d05d273e  vmovaps [rsp+0xB0], xmm1
00007ac9d05d2747  vmovaps xmm1, [rsp+0xD0]
00007ac9d05d2750  movq xmm1, xmm1
00007ac9d05d2754  vmovaps [rsp+0xD0], xmm1
00007ac9d05d275d  vmovaps xmm1, [rsp+0x80]
00007ac9d05d2766  vmovaps [rsp+0xE0], xmm15
00007ac9d05d276f  vmovaps xmm15, [rsp+0x80]
00007ac9d05d2778  por xmm1, xmm15
00007ac9d05d277d  vmovaps xmm15, [rsp+0x10]
00007ac9d05d2783  vmovaps [rsp+0x80], xmm1
00007ac9d05d278c  vmovaps xmm1, [rsp+0x10]
00007ac9d05d2792  por xmm15, xmm1
00007ac9d05d2797  vmovaps xmm1, [rsp+0x20]
00007ac9d05d279d  vmovaps [rsp+0x10], xmm15
00007ac9d05d27a3  vmovaps xmm15, [rsp+0x20]
00007ac9d05d27a9  por xmm1, xmm15
00007ac9d05d27ae  vmovaps [rsp+0x20], xmm6
00007ac9d05d27b4  vmovaps xmm15, [rsp+0x20]
00007ac9d05d27ba  por xmm6, xmm15
00007ac9d05d27bf  vmovaps [rsp+0x20], xmm11
00007ac9d05d27c5  vmovaps xmm15, [rsp+0x20]
00007ac9d05d27cb  por xmm11, xmm15
00007ac9d05d27d0  vmovaps [rsp+0x20], xmm13
00007ac9d05d27d6  vmovaps xmm15, [rsp+0x20]
00007ac9d05d27dc  por xmm13, xmm15
00007ac9d05d27e1  vmovaps [rsp+0x20], xmm14
00007ac9d05d27e7  vmovaps xmm15, [rsp+0x20]
00007ac9d05d27ed  por xmm14, xmm15
00007ac9d05d27f2  mov r12, [r13+rax*1]
00007ac9d05d27f7  vmovq xmm15, r12
00007ac9d05d27fc  vpbroadcastq xmm15, xmm15
00007ac9d05d2801  vmovaps [rsp+0x20], xmm1
00007ac9d05d2807  vxorps xmm1, xmm1, xmm1
00007ac9d05d280b  vpbroadcastq xmm1, xmm1
00007ac9d05d2810  vmovaps [rsp+0xF0], xmm1
00007ac9d05d2819  movups xmm1, [r13+r14*1]
00007ac9d05d281f  vmovaps [rsp+0x100], xmm1
00007ac9d05d2828  vxorps xmm1, xmm1, xmm1
00007ac9d05d282c  vpbroadcastq xmm1, xmm1
00007ac9d05d2831  lea r12, [rax+0x08]
00007ac9d05d2835  mov rax, [r13+r12*1]
00007ac9d05d283a  vmovaps [rsp+0x110], xmm1
00007ac9d05d2843  movq xmm1, rax
00007ac9d05d2848  movaps [r15+0x240], xmm1
00007ac9d05d2850  mov qword ptr [r15+0x60], 0x432190
00007ac9d05d2858  mov qword ptr [r15+0x58], 0x40
00007ac9d05d2860  vmovaps xmm1, [rsp+0x60]
00007ac9d05d2866  vmovaps [rsp+0x60], xmm15
00007ac9d05d286c  vmovaps xmm15, [rsp+0x100]
00007ac9d05d2875  vmovaps [rsp+0x100], xmm14
00007ac9d05d287e  vmovaps xmm14, [rsp+0x60]
00007ac9d05d2884  vmovaps [rsp+0x60], xmm13
00007ac9d05d288a  vmovaps [rsp+0x120], xmm12
00007ac9d05d2893  movaps xmm13, xmm1
00007ac9d05d2897  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d28a2  vptest xmm12, xmm12
00007ac9d05d28a7  jnz 0x00007AC9D05D3482
00007ac9d05d28ad  vmovaps xmm1, [rsp+0xE0]
00007ac9d05d28b6  movaps xmm15, xmm5
00007ac9d05d28ba  vfmadd231pd xmm15, xmm1, xmm14
00007ac9d05d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007ac9d05d28c5  vptest xmm12, xmm12
00007ac9d05d28ca  jnz 0x00007AC9D05D35DB
00007ac9d05d28d0  vmovaps xmm12, [rsp+0x50]
00007ac9d05d28d6  vmovaps xmm5, [rsp+0x50]
00007ac9d05d28dc  por xmm12, xmm5
00007ac9d05d28e1  vmovaps xmm5, [rsp+0x30]
00007ac9d05d28e7  vmovaps [rsp+0x50], xmm1
00007ac9d05d28ed  vmovaps xmm1, [rsp+0x30]
00007ac9d05d28f3  por xmm5, xmm1
00007ac9d05d28f7  vmovaps [rsp+0x30], xmm10
00007ac9d05d28fd  vmovaps xmm1, [rsp+0x30]
00007ac9d05d2903  por xmm10, xmm1
00007ac9d05d2908  vmovaps [rsp+0x30], xmm8
00007ac9d05d290e  vmovaps xmm1, [rsp+0x30]
00007ac9d05d2914  por xmm8, xmm1
00007ac9d05d2919  vmovaps xmm1, [rsp+0x120]
00007ac9d05d2922  vmovaps [rsp+0x30], xmm15
00007ac9d05d2928  vmovaps xmm15, [rsp+0x120]
00007ac9d05d2931  por xmm1, xmm15
00007ac9d05d2936  vmovaps xmm15, [rsp+0x50]
00007ac9d05d293c  vmovaps [rsp+0xE0], xmm1
00007ac9d05d2945  vmovaps xmm1, [rsp+0x50]
00007ac9d05d294b  por xmm15, xmm1
00007ac9d05d2950  lea rax, [r14+0xC0]
00007ac9d05d2957  movups xmm1, [r13+rax*1]
00007ac9d05d295d  xor eax, eax
00007ac9d05d295f  mov r12d, 0x40
00007ac9d05d2965  mov r11d, 0x200
00007ac9d05d296b  cmp r12, r11
00007ac9d05d296e  cmc
00007ac9d05d296f  lahf
00007ac9d05d2970  seto al
00007ac9d05d2973  mov [r15+0x108], eax
00007ac9d05d297a  vmovaps [rsp+0x50], xmm1
00007ac9d05d2980  vmovaps xmm1, [rsp+0xF0]
00007ac9d05d2989  vmovaps [rsp+0xF0], xmm15
00007ac9d05d2992  vmovaps xmm15, [rsp+0x50]
00007ac9d05d2998  vmovaps [rsp+0x50], xmm13
00007ac9d05d299e  vmovaps [rsp+0x120], xmm12
00007ac9d05d29a7  movaps xmm13, xmm1
00007ac9d05d29ab  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d29b6  vptest xmm12, xmm12
00007ac9d05d29bb  jnz 0x00007AC9D05D373D
00007ac9d05d29c1  lea rax, [r14+0xB0]
00007ac9d05d29c8  movups xmm1, [r13+rax*1]
00007ac9d05d29ce  vmovaps xmm15, [rsp+0x110]
00007ac9d05d29d7  vmovaps [rsp+0x110], xmm13
00007ac9d05d29e0  movaps xmm12, xmm15
00007ac9d05d29e4  vfmadd231pd xmm12, xmm1, xmm14
00007ac9d05d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007ac9d05d29ef  vptest xmm13, xmm13
00007ac9d05d29f4  jnz 0x00007AC9D05D38A0
00007ac9d05d29fa  vmovaps xmm1, [rsp+0x100]
00007ac9d05d2a03  vmovaps xmm15, [rsp+0x100]
00007ac9d05d2a0c  por xmm1, xmm15
00007ac9d05d2a11  movaps [r15+0x210], xmm1
00007ac9d05d2a19  vmovaps xmm15, [rsp+0x60]
00007ac9d05d2a1f  vmovaps xmm14, [rsp+0x60]
00007ac9d05d2a25  por xmm15, xmm14
00007ac9d05d2a2a  movaps [r15+0x1C0], xmm15
00007ac9d05d2a32  vmovaps [rsp+0x60], xmm11
00007ac9d05d2a38  vmovaps xmm14, [rsp+0x60]
00007ac9d05d2a3e  por xmm11, xmm14
00007ac9d05d2a43  movaps [r15+0x280], xmm11
00007ac9d05d2a4b  vmovaps [rsp+0x60], xmm6
00007ac9d05d2a51  vmovaps xmm14, [rsp+0x60]
00007ac9d05d2a57  por xmm6, xmm14
00007ac9d05d2a5c  movaps [r15+0x2A0], xmm6
00007ac9d05d2a64  vmovaps xmm14, [rsp+0x20]
00007ac9d05d2a6a  vmovaps xmm13, [rsp+0x20]
00007ac9d05d2a70  por xmm14, xmm13
00007ac9d05d2a75  movaps [r15+0x2E0], xmm14
00007ac9d05d2a7d  vmovaps xmm13, [rsp+0x10]
00007ac9d05d2a83  vmovaps [rsp+0x20], xmm1
00007ac9d05d2a89  vmovaps xmm1, [rsp+0x10]
00007ac9d05d2a8f  por xmm13, xmm1
00007ac9d05d2a94  movaps [r15+0x1F0], xmm13
00007ac9d05d2a9c  vmovaps xmm1, [rsp+0xF0]
00007ac9d05d2aa5  vmovaps [rsp+0x10], xmm15
00007ac9d05d2aab  vmovaps xmm15, [rsp+0xF0]
00007ac9d05d2ab4  por xmm1, xmm15
00007ac9d05d2ab9  movaps [r15+0x250], xmm1
00007ac9d05d2ac1  vmovaps xmm1, [rsp+0xE0]
00007ac9d05d2aca  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d2ad3  por xmm1, xmm15
00007ac9d05d2ad8  movaps [r15+0x260], xmm1
00007ac9d05d2ae0  vmovaps [rsp+0x60], xmm8
00007ac9d05d2ae6  vmovaps xmm15, [rsp+0x60]
00007ac9d05d2aec  por xmm8, xmm15
00007ac9d05d2af1  movaps [r15+0x290], xmm8
00007ac9d05d2af9  vmovaps [rsp+0x60], xmm10
00007ac9d05d2aff  vmovaps xmm15, [rsp+0x60]
00007ac9d05d2b05  por xmm10, xmm15
00007ac9d05d2b0a  movaps [r15+0x2C0], xmm10
00007ac9d05d2b12  movq xmm15, qword ptr [r15+0x240]
00007ac9d05d2b1b  vmovaps [rsp+0x60], xmm15
00007ac9d05d2b21  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d2b27  vmovaps [rsp+0xE0], xmm1
00007ac9d05d2b30  vmovaps xmm1, [rsp+0x50]
00007ac9d05d2b36  vmovaps [rsp+0x50], xmm15
00007ac9d05d2b3c  vmovaps xmm15, [rsp+0x20]
00007ac9d05d2b42  vmovaps [rsp+0x20], xmm14
00007ac9d05d2b48  vmovaps xmm14, [rsp+0x50]
00007ac9d05d2b4e  vmovaps [rsp+0x50], xmm13
00007ac9d05d2b54  vmovaps [rsp+0xF0], xmm12
00007ac9d05d2b5d  movaps xmm13, xmm1
00007ac9d05d2b61  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d2b6c  vptest xmm12, xmm12
00007ac9d05d2b71  jnz 0x00007AC9D05D39F9
00007ac9d05d2b77  vmovaps xmm1, [rsp+0x60]
00007ac9d05d2b7d  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d2b83  vmovaps xmm15, [rsp+0x110]
00007ac9d05d2b8c  vmovaps xmm14, [rsp+0x20]
00007ac9d05d2b92  vmovaps [rsp+0x20], xmm13
00007ac9d05d2b98  movaps xmm12, xmm15
00007ac9d05d2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007ac9d05d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007ac9d05d2ba7  vptest xmm13, xmm13
00007ac9d05d2bac  jnz 0x00007AC9D05D3B52
00007ac9d05d2bb2  vmovaps xmm1, [rsp+0x60]
00007ac9d05d2bb8  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d2bbe  vmovaps xmm15, [rsp+0x30]
00007ac9d05d2bc4  vmovaps xmm14, [rsp+0x10]
00007ac9d05d2bca  vmovaps [rsp+0x10], xmm12
00007ac9d05d2bd0  movaps xmm13, xmm15
00007ac9d05d2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007ac9d05d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d2bdf  vptest xmm12, xmm12
00007ac9d05d2be4  jnz 0x00007AC9D05D3CAB
00007ac9d05d2bea  vmovaps [rsp+0x30], xmm5
00007ac9d05d2bf0  vmovaps xmm1, [rsp+0x30]
00007ac9d05d2bf6  por xmm5, xmm1
00007ac9d05d2bfa  movaps [r15+0x1D0], xmm5
00007ac9d05d2c02  vmovaps xmm1, [rsp+0x60]
00007ac9d05d2c08  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d2c0e  vmovaps xmm15, [rsp+0xF0]
00007ac9d05d2c17  vmovaps xmm14, [rsp+0x50]
00007ac9d05d2c1d  vmovaps [rsp+0x30], xmm13
00007ac9d05d2c23  movaps xmm12, xmm15
00007ac9d05d2c27  vfmadd231pd xmm12, xmm14, xmm1
00007ac9d05d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007ac9d05d2c32  vptest xmm13, xmm13
00007ac9d05d2c37  jnz 0x00007AC9D05D3E04
00007ac9d05d2c3d  vmovaps xmm1, [rsp+0x80]
00007ac9d05d2c46  vmovaps xmm15, [rsp+0x80]
00007ac9d05d2c4f  por xmm1, xmm15
00007ac9d05d2c54  movaps [r15+0x200], xmm1
00007ac9d05d2c5c  vmovaps xmm15, [rsp+0x120]
00007ac9d05d2c65  vmovaps xmm14, [rsp+0x120]
00007ac9d05d2c6e  por xmm15, xmm14
00007ac9d05d2c73  movaps [r15+0x1E0], xmm15
00007ac9d05d2c7b  vmovaps [rsp+0x50], xmm4
00007ac9d05d2c81  vmovaps xmm13, [rsp+0x50]
00007ac9d05d2c87  por xmm4, xmm13
00007ac9d05d2c8c  movaps [r15+0x2B0], xmm4
00007ac9d05d2c94  vmovaps [rsp+0x50], xmm3
00007ac9d05d2c9a  vmovaps xmm13, [rsp+0x50]
00007ac9d05d2ca0  por xmm3, xmm13
00007ac9d05d2ca5  movaps [r15+0x300], xmm3
00007ac9d05d2cad  vmovaps xmm15, [rsp+0xB0]
00007ac9d05d2cb6  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d2cbc  vmovaps xmm3, [rsp+0x20]
00007ac9d05d2cc2  vmovaps [rsp+0x20], xmm1
00007ac9d05d2cc8  vmovaps xmm1, [rsp+0xE0]
00007ac9d05d2cd1  vmovaps [rsp+0x50], xmm14
00007ac9d05d2cd7  vmovaps [rsp+0x60], xmm13
00007ac9d05d2cdd  movaps xmm14, xmm3
00007ac9d05d2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007ac9d05d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007ac9d05d2cec  vptest xmm13, xmm13
00007ac9d05d2cf1  jnz 0x00007AC9D05D3F5D
00007ac9d05d2cf7  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d2d00  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d2d06  vmovaps xmm15, [rsp+0x10]
00007ac9d05d2d0c  movaps xmm13, xmm15
00007ac9d05d2d10  vfmadd231pd xmm13, xmm10, xmm1
00007ac9d05d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007ac9d05d2d1b  vptest xmm3, xmm3
00007ac9d05d2d20  jnz 0x00007AC9D05D40B5
00007ac9d05d2d26  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d2d2f  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d2d35  vmovaps xmm15, [rsp+0x30]
00007ac9d05d2d3b  movaps xmm10, xmm15
00007ac9d05d2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007ac9d05d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007ac9d05d2d4a  vptest xmm3, xmm3
00007ac9d05d2d4f  jnz 0x00007AC9D05D420E
00007ac9d05d2d55  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d2d5e  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d2d64  movaps xmm15, xmm12
00007ac9d05d2d68  vfmadd231pd xmm15, xmm5, xmm1
00007ac9d05d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007ac9d05d2d73  vptest xmm11, xmm11
00007ac9d05d2d78  jnz 0x00007AC9D05D4367
00007ac9d05d2d7e  vmovaps [rsp+0x10], xmm9
00007ac9d05d2d84  vmovaps xmm1, [rsp+0x10]
00007ac9d05d2d8a  por xmm9, xmm1
00007ac9d05d2d8f  movaps [r15+0x180], xmm9
00007ac9d05d2d97  vmovaps [rsp+0x10], xmm2
00007ac9d05d2d9d  vmovaps xmm1, [rsp+0x10]
00007ac9d05d2da3  por xmm2, xmm1
00007ac9d05d2da7  movaps [r15+0x2D0], xmm2
00007ac9d05d2daf  vmovaps xmm12, [rsp+0xD0]
00007ac9d05d2db8  vpermilpd xmm12, xmm12, 0x00
00007ac9d05d2dbe  vmovaps xmm11, [rsp+0x60]
00007ac9d05d2dc4  movaps xmm5, xmm13
00007ac9d05d2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007ac9d05d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007ac9d05d2dd2  vptest xmm3, xmm3
00007ac9d05d2dd7  jnz 0x00007AC9D05D44BF
00007ac9d05d2ddd  vmovaps xmm13, [rsp+0xD0]
00007ac9d05d2de6  vpermilpd xmm13, xmm13, 0x00
00007ac9d05d2dec  movaps xmm12, xmm14
00007ac9d05d2df0  vfmadd231pd xmm12, xmm9, xmm13
00007ac9d05d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007ac9d05d2dfb  vptest xmm11, xmm11
00007ac9d05d2e00  jnz 0x00007AC9D05D4617
00007ac9d05d2e06  lea rax, [r14+0x80]
00007ac9d05d2e0d  movups xmm14, [r13+rax*1]
00007ac9d05d2e13  movaps [r15+0x2F0], xmm14
00007ac9d05d2e1b  vmovaps xmm13, [rsp+0xD0]
00007ac9d05d2e24  vpermilpd xmm13, xmm13, 0x00
00007ac9d05d2e2a  movaps xmm11, xmm10
00007ac9d05d2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007ac9d05d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007ac9d05d2e39  vptest xmm9, xmm9
00007ac9d05d2e3e  jnz 0x00007AC9D05D477B
00007ac9d05d2e44  vmovaps xmm13, [rsp+0xD0]
00007ac9d05d2e4d  vpermilpd xmm13, xmm13, 0x00
00007ac9d05d2e53  movaps xmm10, xmm15
00007ac9d05d2e57  vfmadd231pd xmm10, xmm1, xmm13
00007ac9d05d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007ac9d05d2e62  vptest xmm9, xmm9
00007ac9d05d2e67  jnz 0x00007AC9D05D48D5
00007ac9d05d2e6d  vmovaps [rsp+0x10], xmm7
00007ac9d05d2e73  vmovaps xmm1, [rsp+0x10]
00007ac9d05d2e79  por xmm7, xmm1
00007ac9d05d2e7d  movaps [r15+0x160], xmm7
00007ac9d05d2e85  lea rax, [r14+0x40]
00007ac9d05d2e89  movups xmm1, [r13+rax*1]
00007ac9d05d2e8f  lea rax, [r14+0x50]
00007ac9d05d2e93  movups xmm15, [r13+rax*1]
00007ac9d05d2e99  movaps [r15+0x1B0], xmm1
00007ac9d05d2ea1  movaps [r15+0x1A0], xmm15
00007ac9d05d2ea9  vmovaps xmm13, [rsp+0xA0]
00007ac9d05d2eb2  vpermilpd xmm13, xmm13, 0x00
00007ac9d05d2eb8  vmovaps xmm9, [rsp+0x40]
00007ac9d05d2ebe  movaps xmm8, xmm5
00007ac9d05d2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007ac9d05d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007ac9d05d2ecd  vptest xmm3, xmm3
00007ac9d05d2ed2  jnz 0x00007AC9D05D4A42
00007ac9d05d2ed8  vmovaps xmm13, [rsp+0xA0]
00007ac9d05d2ee1  vpermilpd xmm13, xmm13, 0x00
00007ac9d05d2ee7  movaps xmm9, xmm12
00007ac9d05d2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007ac9d05d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007ac9d05d2ef6  vptest xmm5, xmm5
00007ac9d05d2efb  jnz 0x00007AC9D05D4B9B
00007ac9d05d2f01  vmovaps xmm13, [rsp+0xA0]
00007ac9d05d2f0a  vpermilpd xmm13, xmm13, 0x00
00007ac9d05d2f10  movaps xmm12, xmm11
00007ac9d05d2f14  vfmadd231pd xmm12, xmm6, xmm13
00007ac9d05d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007ac9d05d2f1f  vptest xmm7, xmm7
00007ac9d05d2f24  jnz 0x00007AC9D05D4CF4
00007ac9d05d2f2a  vmovaps xmm13, [rsp+0xA0]
00007ac9d05d2f33  vpermilpd xmm13, xmm13, 0x00
00007ac9d05d2f39  vmovaps xmm11, [rsp+0x50]
00007ac9d05d2f3f  movaps xmm7, xmm10
00007ac9d05d2f43  vfmadd231pd xmm7, xmm11, xmm13
00007ac9d05d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007ac9d05d2f4d  vptest xmm6, xmm6
00007ac9d05d2f52  jnz 0x00007AC9D05D4E4D
00007ac9d05d2f58  lea rax, [r14+0x60]
00007ac9d05d2f5c  movups xmm13, [r13+rax*1]
00007ac9d05d2f62  lea rax, [r14+0x70]
00007ac9d05d2f66  movups xmm11, [r13+rax*1]
00007ac9d05d2f6c  movaps [r15+0x150], xmm13
00007ac9d05d2f74  movaps [r15+0x120], xmm11
00007ac9d05d2f7c  vmovaps xmm10, [rsp+0xC0]
00007ac9d05d2f85  vpermilpd xmm10, xmm10, 0x00
00007ac9d05d2f8b  movaps xmm6, xmm8
00007ac9d05d2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007ac9d05d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007ac9d05d2f99  vptest xmm5, xmm5
00007ac9d05d2f9e  jnz 0x00007AC9D05D4FB9
00007ac9d05d2fa4  vmovaps xmm15, [rsp+0xC0]
00007ac9d05d2fad  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d2fb3  movaps xmm10, xmm9
00007ac9d05d2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007ac9d05d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007ac9d05d2fc2  vptest xmm8, xmm8
00007ac9d05d2fc7  jnz 0x00007AC9D05D5111
00007ac9d05d2fcd  vmovaps xmm15, [rsp+0xC0]
00007ac9d05d2fd6  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d2fdc  movaps xmm13, xmm12
00007ac9d05d2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007ac9d05d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007ac9d05d2feb  vptest xmm9, xmm9
00007ac9d05d2ff0  jnz 0x00007AC9D05D526B
00007ac9d05d2ff6  vmovaps xmm15, [rsp+0xC0]
00007ac9d05d2fff  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d3005  movaps xmm12, xmm7
00007ac9d05d3009  vfmadd231pd xmm12, xmm1, xmm15
00007ac9d05d300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007ac9d05d3014  vptest xmm9, xmm9
00007ac9d05d3019  jnz 0x00007AC9D05D53C4
00007ac9d05d301f  lea rax, [r14+0x20]
00007ac9d05d3023  movups xmm1, [r13+rax*1]
00007ac9d05d3029  lea rax, [r14+0x30]
00007ac9d05d302d  movups xmm15, [r13+rax*1]
00007ac9d05d3033  vmovaps xmm9, [rsp+0x70]
00007ac9d05d3039  vpermilpd xmm9, xmm9, 0x00
00007ac9d05d303f  vmovaps xmm8, [rsp+0x20]
00007ac9d05d3045  movaps xmm7, xmm6
00007ac9d05d3048  vfmadd231pd xmm7, xmm8, xmm9
00007ac9d05d304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007ac9d05d3052  vptest xmm5, xmm5
00007ac9d05d3057  jnz 0x00007AC9D05D5530
00007ac9d05d305d  vmovaps xmm9, [rsp+0x70]
00007ac9d05d3063  vpermilpd xmm9, xmm9, 0x00
00007ac9d05d3069  movaps xmm8, xmm10
00007ac9d05d306d  vfmadd231pd xmm8, xmm14, xmm9
00007ac9d05d3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007ac9d05d3078  vptest xmm6, xmm6
00007ac9d05d307d  jnz 0x00007AC9D05D5687
00007ac9d05d3083  vmovaps xmm14, [rsp+0x70]
00007ac9d05d3089  vpermilpd xmm14, xmm14, 0x00
00007ac9d05d308f  movaps xmm10, xmm13
00007ac9d05d3093  vfmadd231pd xmm10, xmm11, xmm14
00007ac9d05d3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007ac9d05d309e  vptest xmm9, xmm9
00007ac9d05d30a3  jnz 0x00007AC9D05D57E1
00007ac9d05d30a9  vmovaps xmm14, [rsp+0x70]
00007ac9d05d30af  vpermilpd xmm14, xmm14, 0x00
00007ac9d05d30b5  movaps xmm13, xmm12
00007ac9d05d30b9  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007ac9d05d30c4  vptest xmm11, xmm11
00007ac9d05d30c9  jnz 0x00007AC9D05D593B
00007ac9d05d30cf  lea rax, [r14+0x90]
00007ac9d05d30d6  movups xmm15, [r13+rax*1]
00007ac9d05d30dc  lea rax, [r14+0xA0]
00007ac9d05d30e3  movups xmm14, [r13+rax*1]
00007ac9d05d30e9  movaps [r15+0x140], xmm15
00007ac9d05d30f1  movaps [r15+0x130], xmm14
00007ac9d05d30f9  vmovaps xmm12, [rsp+0x90]
00007ac9d05d3102  vpermilpd xmm12, xmm12, 0x00
00007ac9d05d3108  movaps xmm11, xmm7
00007ac9d05d310c  vfmadd231pd xmm11, xmm1, xmm12
00007ac9d05d3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007ac9d05d3117  vptest xmm9, xmm9
00007ac9d05d311c  jnz 0x00007AC9D05D5AA9
00007ac9d05d3122  movaps [r15+0x220], xmm11
00007ac9d05d312a  lea rax, [r14+0x10]
00007ac9d05d312e  movups xmm1, [r13+rax*1]
00007ac9d05d3134  movaps [r15+0x240], xmm1
00007ac9d05d313c  vmovaps xmm12, [rsp+0x90]
00007ac9d05d3145  vpermilpd xmm12, xmm12, 0x00
00007ac9d05d314b  movaps xmm9, xmm8
00007ac9d05d314f  vfmadd231pd xmm9, xmm14, xmm12
00007ac9d05d3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007ac9d05d315a  vptest xmm7, xmm7
00007ac9d05d315f  jnz 0x00007AC9D05D5C0B
00007ac9d05d3165  movaps [r15+0x110], xmm9
00007ac9d05d316d  vmovaps xmm14, [rsp+0x90]
00007ac9d05d3176  vpermilpd xmm14, xmm14, 0x00
00007ac9d05d317c  movaps xmm12, xmm10
00007ac9d05d3180  vfmadd231pd xmm12, xmm15, xmm14
00007ac9d05d3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007ac9d05d318b  vptest xmm8, xmm8
00007ac9d05d3190  jnz 0x00007AC9D05D5D65
00007ac9d05d3196  movaps [r15+0x170], xmm12
00007ac9d05d319e  vmovaps xmm15, [rsp+0x90]
00007ac9d05d31a7  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d31ad  movaps xmm14, xmm13
00007ac9d05d31b1  vfmadd231pd xmm14, xmm1, xmm15
00007ac9d05d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007ac9d05d31bc  vptest xmm10, xmm10
00007ac9d05d31c1  jnz 0x00007AC9D05D5EBF
00007ac9d05d31c7  movaps [r15+0x230], xmm14
00007ac9d05d31cf  mov eax, 0x432190
00007ac9d05d31d4  movups [r13+rax*1], xmm9
00007ac9d05d31da  mov eax, 0x4321A0
00007ac9d05d31df  movups [r13+rax*1], xmm12
00007ac9d05d31e5  mov eax, 0x4321B0
00007ac9d05d31ea  movups [r13+rax*1], xmm11
00007ac9d05d31f0  mov eax, 0x4321C0
00007ac9d05d31f5  movups [r13+rax*1], xmm14
00007ac9d05d31fb  mov eax, [r15+0x108]
00007ac9d05d3202  sahf
00007ac9d05d3203  jnz 0x00007AC9D05D3235
00007ac9d05d3205  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d320d  jz 0x00007AC9D05D9950
00007ac9d05d3213  nop [rax+rax*1], ax
00007ac9d05d321c  nop [rax+rax*1], eax
00007ac9d05d3224  mov eax, 0x410664
00007ac9d05d3229  mov [r15+0x100], rax
00007ac9d05d3230  jmp 0x00007AC9D03FE110
00007ac9d05d3235  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d323d  jz 0x00007AC9D05D6050
00007ac9d05d3243  nop [rax+rax*1], ax
00007ac9d05d324c  nop [rax+rax*1], eax
00007ac9d05d3254  mov eax, 0x4104F0
00007ac9d05d3259  mov [r15+0x100], rax
00007ac9d05d3260  jmp 0x00007AC9D03FE110
00007ac9d05d3265  int3
00007ac9d05d3266  call 0x00007AC9D03FF430
00007ac9d05d326b  jmp 0x00007AC9D05D230A
00007ac9d05d3270  call 0x00007AC9D04E5820
00007ac9d05d3275  jmp 0x00007AC9D05D2314
00007ac9d05d327a  call 0x00007AC9D04E45A0
00007ac9d05d327f  jmp 0x00007AC9D05D2326
00007ac9d05d3284  call 0x00007AC9D04E3320
00007ac9d05d3289  jmp 0x00007AC9D05D2330
00007ac9d05d328e  call 0x00007AC9D04E20A0
00007ac9d05d3293  jmp 0x00007AC9D05D233D
00007ac9d05d3298  call 0x00007AC9D04E0E30
00007ac9d05d329d  jmp 0x00007AC9D05D234A
00007ac9d05d32a2  call 0x00007AC9D04D6600
00007ac9d05d32a7  jmp 0x00007AC9D05D2357
00007ac9d05d32ac  call 0x00007AC9D04B52F0
00007ac9d05d32b1  jmp 0x00007AC9D05D2361
00007ac9d05d32b6  call 0x00007AC9D04BE9C0
00007ac9d05d32bb  jmp 0x00007AC9D05D236B
00007ac9d05d32c0  call 0x00007AC9D04BD750
00007ac9d05d32c5  jmp 0x00007AC9D05D2378
00007ac9d05d32ca  call 0x00007AC9D04BC4E0
00007ac9d05d32cf  jmp 0x00007AC9D05D2385
00007ac9d05d32d4  call 0x00007AC9D04BB270
00007ac9d05d32d9  jmp 0x00007AC9D05D2392
00007ac9d05d32de  call 0x00007AC9D04BA000
00007ac9d05d32e3  jmp 0x00007AC9D05D239F
00007ac9d05d32e8  call 0x00007AC9D04B8D90
00007ac9d05d32ed  jmp 0x00007AC9D05D23AC
00007ac9d05d32f2  call 0x00007AC9D04B8A20
00007ac9d05d32f7  jmp 0x00007AC9D05D23B9
00007ac9d05d32fc  call 0x00007AC9D04BEAE0
00007ac9d05d3301  jmp 0x00007AC9D05D23C6
00007ac9d05d3306  call 0x00007AC9D04B5400
00007ac9d05d330b  jmp 0x00007AC9D05D23D3
00007ac9d05d3310  call 0x00007AC9D04B52F0
00007ac9d05d3315  jmp 0x00007AC9D05D23E0
00007ac9d05d331a  call 0x00007AC9D04BE9C0
00007ac9d05d331f  jmp 0x00007AC9D05D23ED
00007ac9d05d3324  call 0x00007AC9D04B77B0
00007ac9d05d3329  jmp 0x00007AC9D05D23FA
00007ac9d05d332e  call 0x00007AC9D04B6550
00007ac9d05d3333  jmp 0x00007AC9D05D2407
00007ac9d05d3338  call 0x00007AC9D04B52F0
00007ac9d05d333d  jmp 0x00007AC9D05D2417
00007ac9d05d3342  call 0x00007AC9D04B52F0
00007ac9d05d3347  jmp 0x00007AC9D05D2427
00007ac9d05d334c  call 0x00007AC9D04BEAE0
00007ac9d05d3351  jmp 0x00007AC9D05D2431
00007ac9d05d3356  call 0x00007AC9D04BEAE0
00007ac9d05d335b  jmp 0x00007AC9D05D2444
00007ac9d05d3360  call 0x00007AC9D04BE9C0
00007ac9d05d3365  jmp 0x00007AC9D05D2451
00007ac9d05d336a  call 0x00007AC9D04B52F0
00007ac9d05d336f  jmp 0x00007AC9D05D2464
00007ac9d05d3374  call 0x00007AC9D04B6660
00007ac9d05d3379  jmp 0x00007AC9D05D2471
00007ac9d05d337e  call 0x00007AC9D04B78C0
00007ac9d05d3383  jmp 0x00007AC9D05D247E
00007ac9d05d3388  call 0x00007AC9D04B77B0
00007ac9d05d338d  jmp 0x00007AC9D05D248B
00007ac9d05d3392  call 0x00007AC9D04B6550
00007ac9d05d3397  jmp 0x00007AC9D05D2498
00007ac9d05d339c  call 0x00007AC9D04B52F0
00007ac9d05d33a1  jmp 0x00007AC9D05D24AB
00007ac9d05d33a6  call 0x00007AC9D04B52F0
00007ac9d05d33ab  jmp 0x00007AC9D05D24BE
00007ac9d05d33b0  call 0x00007AC9D04B52F0
00007ac9d05d33b5  jmp 0x00007AC9D05D24E5
00007ac9d05d33ba  call 0x00007AC9D04B52F0
00007ac9d05d33bf  jmp 0x00007AC9D05D24F8
00007ac9d05d33c4  call 0x00007AC9D04B52F0
00007ac9d05d33c9  jmp 0x00007AC9D05D250B
00007ac9d05d33ce  call 0x00007AC9D04B52F0
00007ac9d05d33d3  jmp 0x00007AC9D05D2521
00007ac9d05d33d8  call 0x00007AC9D04B52F0
00007ac9d05d33dd  jmp 0x00007AC9D05D2537
00007ac9d05d33e2  call 0x00007AC9D04B52F0
00007ac9d05d33e7  jmp 0x00007AC9D05D254D
00007ac9d05d33ec  call 0x00007AC9D03FF540
00007ac9d05d33f1  jmp 0x00007AC9D05D256E
00007ac9d05d33f6  call 0x00007AC9D0402FE0
00007ac9d05d33fb  jmp 0x00007AC9D05D2578
00007ac9d05d3400  call 0x00007AC9D03FF540
00007ac9d05d3405  jmp 0x00007AC9D05D2588
00007ac9d05d340a  call 0x00007AC9D03FF540
00007ac9d05d340f  jmp 0x00007AC9D05D259B
00007ac9d05d3414  call 0x00007AC9D03FF540
00007ac9d05d3419  jmp 0x00007AC9D05D25AE
00007ac9d05d341e  call 0x00007AC9D03FF540
00007ac9d05d3423  jmp 0x00007AC9D05D25C1
00007ac9d05d3428  call 0x00007AC9D04C0370
00007ac9d05d342d  jmp 0x00007AC9D05D25E0
00007ac9d05d3432  call 0x00007AC9D04BF100
00007ac9d05d3437  jmp 0x00007AC9D05D25E9
00007ac9d05d343c  call 0x00007AC9D04C0370
00007ac9d05d3441  jmp 0x00007AC9D05D2659
00007ac9d05d3446  call 0x00007AC9D04BF100
00007ac9d05d344b  jmp 0x00007AC9D05D2662
00007ac9d05d3450  call 0x00007AC9D04C0370
00007ac9d05d3455  jmp 0x00007AC9D05D270C
00007ac9d05d345a  call 0x00007AC9D04BF100
00007ac9d05d345f  jmp 0x00007AC9D05D2715
00007ac9d05d3464  call 0x00007AC9D040B720
00007ac9d05d3469  jmp 0x00007AC9D05D27F7
00007ac9d05d346e  call 0x00007AC9D04D64F0
00007ac9d05d3473  jmp 0x00007AC9D05D281F
00007ac9d05d3478  call 0x00007AC9D04B47C0
00007ac9d05d347d  jmp 0x00007AC9D05D283A
00007ac9d05d3482  sub rsp, 0x08
00007ac9d05d3486  push rax
00007ac9d05d3487  push rcx
00007ac9d05d3488  push rdx
00007ac9d05d3489  push rdi
00007ac9d05d348a  push rsi
00007ac9d05d348b  push r8
00007ac9d05d348d  push r9
00007ac9d05d348f  push r10
00007ac9d05d3491  push r11
00007ac9d05d3493  sub rsp, 0xF0
00007ac9d05d349a  vmovaps [rsp], xmm0
00007ac9d05d349f  vmovaps [rsp+0x10], xmm1
00007ac9d05d34a5  vmovaps [rsp+0x20], xmm2
00007ac9d05d34ab  vmovaps [rsp+0x30], xmm3
00007ac9d05d34b1  vmovaps [rsp+0x40], xmm4
00007ac9d05d34b7  vmovaps [rsp+0x50], xmm5
00007ac9d05d34bd  vmovaps [rsp+0x60], xmm6
00007ac9d05d34c3  vmovaps [rsp+0x70], xmm7
00007ac9d05d34c9  vmovaps [rsp+0x80], xmm8
00007ac9d05d34d2  vmovaps [rsp+0x90], xmm9
00007ac9d05d34db  vmovaps [rsp+0xA0], xmm10
00007ac9d05d34e4  vmovaps [rsp+0xB0], xmm11
00007ac9d05d34ed  vmovaps [rsp+0xC0], xmm12
00007ac9d05d34f6  vmovaps [rsp+0xD0], xmm14
00007ac9d05d34ff  vmovaps [rsp+0xE0], xmm15
00007ac9d05d3508  sub rsp, 0x40
00007ac9d05d350c  lea rdi, [rsp]
00007ac9d05d3510  lea rsi, [rsp+0x10]
00007ac9d05d3515  lea rdx, [rsp+0x20]
00007ac9d05d351a  lea rcx, [rsp+0x30]
00007ac9d05d351f  mov r8d, 0x00
00007ac9d05d3525  lea r9, [r15+0x3A8]
00007ac9d05d352c  movaps [rdi], xmm13
00007ac9d05d3530  movaps [rsi], xmm1
00007ac9d05d3533  movaps [rdx], xmm15
00007ac9d05d3537  movaps [rcx], xmm14
00007ac9d05d353b  mov rax, 0x569AF9F93A50
00007ac9d05d3545  call rax
00007ac9d05d3547  movaps xmm13, [rsp]
00007ac9d05d354c  add rsp, 0x40
00007ac9d05d3550  vmovaps xmm0, [rsp]
00007ac9d05d3555  vmovaps xmm1, [rsp+0x10]
00007ac9d05d355b  vmovaps xmm2, [rsp+0x20]
00007ac9d05d3561  vmovaps xmm3, [rsp+0x30]
00007ac9d05d3567  vmovaps xmm4, [rsp+0x40]
00007ac9d05d356d  vmovaps xmm5, [rsp+0x50]
00007ac9d05d3573  vmovaps xmm6, [rsp+0x60]
00007ac9d05d3579  vmovaps xmm7, [rsp+0x70]
00007ac9d05d357f  vmovaps xmm8, [rsp+0x80]
00007ac9d05d3588  vmovaps xmm9, [rsp+0x90]
00007ac9d05d3591  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d359a  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d35a3  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d35ac  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d35b5  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d35be  add rsp, 0xF0
00007ac9d05d35c5  pop r11
00007ac9d05d35c7  pop r10
00007ac9d05d35c9  pop r9
00007ac9d05d35cb  pop r8
00007ac9d05d35cd  pop rsi
00007ac9d05d35ce  pop rdi
00007ac9d05d35cf  pop rdx
00007ac9d05d35d0  pop rcx
00007ac9d05d35d1  pop rax
00007ac9d05d35d2  add rsp, 0x08
00007ac9d05d35d6  jmp 0x00007AC9D05D28AD
00007ac9d05d35db  sub rsp, 0x08
00007ac9d05d35df  push rax
00007ac9d05d35e0  push rcx
00007ac9d05d35e1  push rdx
00007ac9d05d35e2  push rdi
00007ac9d05d35e3  push rsi
00007ac9d05d35e4  push r8
00007ac9d05d35e6  push r9
00007ac9d05d35e8  push r10
00007ac9d05d35ea  push r11
00007ac9d05d35ec  sub rsp, 0xF0
00007ac9d05d35f3  vmovaps [rsp], xmm0
00007ac9d05d35f8  vmovaps [rsp+0x10], xmm1
00007ac9d05d35fe  vmovaps [rsp+0x20], xmm2
00007ac9d05d3604  vmovaps [rsp+0x30], xmm3
00007ac9d05d360a  vmovaps [rsp+0x40], xmm4
00007ac9d05d3610  vmovaps [rsp+0x50], xmm5
00007ac9d05d3616  vmovaps [rsp+0x60], xmm6
00007ac9d05d361c  vmovaps [rsp+0x70], xmm7
00007ac9d05d3622  vmovaps [rsp+0x80], xmm8
00007ac9d05d362b  vmovaps [rsp+0x90], xmm9
00007ac9d05d3634  vmovaps [rsp+0xA0], xmm10
00007ac9d05d363d  vmovaps [rsp+0xB0], xmm11
00007ac9d05d3646  vmovaps [rsp+0xC0], xmm12
00007ac9d05d364f  vmovaps [rsp+0xD0], xmm13
00007ac9d05d3658  vmovaps [rsp+0xE0], xmm14
00007ac9d05d3661  sub rsp, 0x40
00007ac9d05d3665  lea rdi, [rsp]
00007ac9d05d3669  lea rsi, [rsp+0x10]
00007ac9d05d366e  lea rdx, [rsp+0x20]
00007ac9d05d3673  lea rcx, [rsp+0x30]
00007ac9d05d3678  mov r8d, 0x00
00007ac9d05d367e  lea r9, [r15+0x3A8]
00007ac9d05d3685  movaps [rdi], xmm15
00007ac9d05d3689  movaps [rsi], xmm5
00007ac9d05d368c  movaps [rdx], xmm1
00007ac9d05d368f  movaps [rcx], xmm14
00007ac9d05d3693  mov rax, 0x569AF9F93A50
00007ac9d05d369d  call rax
00007ac9d05d369f  movaps xmm15, [rsp]
00007ac9d05d36a4  add rsp, 0x40
00007ac9d05d36a8  vmovaps xmm0, [rsp]
00007ac9d05d36ad  vmovaps xmm1, [rsp+0x10]
00007ac9d05d36b3  vmovaps xmm2, [rsp+0x20]
00007ac9d05d36b9  vmovaps xmm3, [rsp+0x30]
00007ac9d05d36bf  vmovaps xmm4, [rsp+0x40]
00007ac9d05d36c5  vmovaps xmm5, [rsp+0x50]
00007ac9d05d36cb  vmovaps xmm6, [rsp+0x60]
00007ac9d05d36d1  vmovaps xmm7, [rsp+0x70]
00007ac9d05d36d7  vmovaps xmm8, [rsp+0x80]
00007ac9d05d36e0  vmovaps xmm9, [rsp+0x90]
00007ac9d05d36e9  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d36f2  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d36fb  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d3704  vmovaps xmm13, [rsp+0xD0]
00007ac9d05d370d  vmovaps xmm14, [rsp+0xE0]
00007ac9d05d3716  add rsp, 0xF0
00007ac9d05d371d  pop r11
00007ac9d05d371f  pop r10
00007ac9d05d3721  pop r9
00007ac9d05d3723  pop r8
00007ac9d05d3725  pop rsi
00007ac9d05d3726  pop rdi
00007ac9d05d3727  pop rdx
00007ac9d05d3728  pop rcx
00007ac9d05d3729  pop rax
00007ac9d05d372a  add rsp, 0x08
00007ac9d05d372e  jmp 0x00007AC9D05D28D0
00007ac9d05d3733  call 0x00007AC9D03FF430
00007ac9d05d3738  jmp 0x00007AC9D05D295D
00007ac9d05d373d  sub rsp, 0x08
00007ac9d05d3741  push rax
00007ac9d05d3742  push rcx
00007ac9d05d3743  push rdx
00007ac9d05d3744  push rdi
00007ac9d05d3745  push rsi
00007ac9d05d3746  push r8
00007ac9d05d3748  push r9
00007ac9d05d374a  push r10
00007ac9d05d374c  push r11
00007ac9d05d374e  sub rsp, 0xF0
00007ac9d05d3755  vmovaps [rsp], xmm0
00007ac9d05d375a  vmovaps [rsp+0x10], xmm1
00007ac9d05d3760  vmovaps [rsp+0x20], xmm2
00007ac9d05d3766  vmovaps [rsp+0x30], xmm3
00007ac9d05d376c  vmovaps [rsp+0x40], xmm4
00007ac9d05d3772  vmovaps [rsp+0x50], xmm5
00007ac9d05d3778  vmovaps [rsp+0x60], xmm6
00007ac9d05d377e  vmovaps [rsp+0x70], xmm7
00007ac9d05d3784  vmovaps [rsp+0x80], xmm8
00007ac9d05d378d  vmovaps [rsp+0x90], xmm9
00007ac9d05d3796  vmovaps [rsp+0xA0], xmm10
00007ac9d05d379f  vmovaps [rsp+0xB0], xmm11
00007ac9d05d37a8  vmovaps [rsp+0xC0], xmm12
00007ac9d05d37b1  vmovaps [rsp+0xD0], xmm14
00007ac9d05d37ba  vmovaps [rsp+0xE0], xmm15
00007ac9d05d37c3  sub rsp, 0x40
00007ac9d05d37c7  lea rdi, [rsp]
00007ac9d05d37cb  lea rsi, [rsp+0x10]
00007ac9d05d37d0  lea rdx, [rsp+0x20]
00007ac9d05d37d5  lea rcx, [rsp+0x30]
00007ac9d05d37da  mov r8d, 0x00
00007ac9d05d37e0  lea r9, [r15+0x3A8]
00007ac9d05d37e7  movaps [rdi], xmm13
00007ac9d05d37eb  movaps [rsi], xmm1
00007ac9d05d37ee  movaps [rdx], xmm15
00007ac9d05d37f2  movaps [rcx], xmm14
00007ac9d05d37f6  mov rax, 0x569AF9F93A50
00007ac9d05d3800  call rax
00007ac9d05d3802  movaps xmm13, [rsp]
00007ac9d05d3807  add rsp, 0x40
00007ac9d05d380b  vmovaps xmm0, [rsp]
00007ac9d05d3810  vmovaps xmm1, [rsp+0x10]
00007ac9d05d3816  vmovaps xmm2, [rsp+0x20]
00007ac9d05d381c  vmovaps xmm3, [rsp+0x30]
00007ac9d05d3822  vmovaps xmm4, [rsp+0x40]
00007ac9d05d3828  vmovaps xmm5, [rsp+0x50]
00007ac9d05d382e  vmovaps xmm6, [rsp+0x60]
00007ac9d05d3834  vmovaps xmm7, [rsp+0x70]
00007ac9d05d383a  vmovaps xmm8, [rsp+0x80]
00007ac9d05d3843  vmovaps xmm9, [rsp+0x90]
00007ac9d05d384c  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d3855  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d385e  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d3867  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d3870  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d3879  add rsp, 0xF0
00007ac9d05d3880  pop r11
00007ac9d05d3882  pop r10
00007ac9d05d3884  pop r9
00007ac9d05d3886  pop r8
00007ac9d05d3888  pop rsi
00007ac9d05d3889  pop rdi
00007ac9d05d388a  pop rdx
00007ac9d05d388b  pop rcx
00007ac9d05d388c  pop rax
00007ac9d05d388d  add rsp, 0x08
00007ac9d05d3891  jmp 0x00007AC9D05D29C1
00007ac9d05d3896  call 0x00007AC9D03FF430
00007ac9d05d389b  jmp 0x00007AC9D05D29CE
00007ac9d05d38a0  sub rsp, 0x08
00007ac9d05d38a4  push rax
00007ac9d05d38a5  push rcx
00007ac9d05d38a6  push rdx
00007ac9d05d38a7  push rdi
00007ac9d05d38a8  push rsi
00007ac9d05d38a9  push r8
00007ac9d05d38ab  push r9
00007ac9d05d38ad  push r10
00007ac9d05d38af  push r11
00007ac9d05d38b1  sub rsp, 0xF0
00007ac9d05d38b8  vmovaps [rsp], xmm0
00007ac9d05d38bd  vmovaps [rsp+0x10], xmm1
00007ac9d05d38c3  vmovaps [rsp+0x20], xmm2
00007ac9d05d38c9  vmovaps [rsp+0x30], xmm3
00007ac9d05d38cf  vmovaps [rsp+0x40], xmm4
00007ac9d05d38d5  vmovaps [rsp+0x50], xmm5
00007ac9d05d38db  vmovaps [rsp+0x60], xmm6
00007ac9d05d38e1  vmovaps [rsp+0x70], xmm7
00007ac9d05d38e7  vmovaps [rsp+0x80], xmm8
00007ac9d05d38f0  vmovaps [rsp+0x90], xmm9
00007ac9d05d38f9  vmovaps [rsp+0xA0], xmm10
00007ac9d05d3902  vmovaps [rsp+0xB0], xmm11
00007ac9d05d390b  vmovaps [rsp+0xC0], xmm13
00007ac9d05d3914  vmovaps [rsp+0xD0], xmm14
00007ac9d05d391d  vmovaps [rsp+0xE0], xmm15
00007ac9d05d3926  sub rsp, 0x40
00007ac9d05d392a  lea rdi, [rsp]
00007ac9d05d392e  lea rsi, [rsp+0x10]
00007ac9d05d3933  lea rdx, [rsp+0x20]
00007ac9d05d3938  lea rcx, [rsp+0x30]
00007ac9d05d393d  mov r8d, 0x00
00007ac9d05d3943  lea r9, [r15+0x3A8]
00007ac9d05d394a  movaps [rdi], xmm12
00007ac9d05d394e  movaps [rsi], xmm15
00007ac9d05d3952  movaps [rdx], xmm1
00007ac9d05d3955  movaps [rcx], xmm14
00007ac9d05d3959  mov rax, 0x569AF9F93A50
00007ac9d05d3963  call rax
00007ac9d05d3965  movaps xmm12, [rsp]
00007ac9d05d396a  add rsp, 0x40
00007ac9d05d396e  vmovaps xmm0, [rsp]
00007ac9d05d3973  vmovaps xmm1, [rsp+0x10]
00007ac9d05d3979  vmovaps xmm2, [rsp+0x20]
00007ac9d05d397f  vmovaps xmm3, [rsp+0x30]
00007ac9d05d3985  vmovaps xmm4, [rsp+0x40]
00007ac9d05d398b  vmovaps xmm5, [rsp+0x50]
00007ac9d05d3991  vmovaps xmm6, [rsp+0x60]
00007ac9d05d3997  vmovaps xmm7, [rsp+0x70]
00007ac9d05d399d  vmovaps xmm8, [rsp+0x80]
00007ac9d05d39a6  vmovaps xmm9, [rsp+0x90]
00007ac9d05d39af  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d39b8  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d39c1  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d39ca  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d39d3  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d39dc  add rsp, 0xF0
00007ac9d05d39e3  pop r11
00007ac9d05d39e5  pop r10
00007ac9d05d39e7  pop r9
00007ac9d05d39e9  pop r8
00007ac9d05d39eb  pop rsi
00007ac9d05d39ec  pop rdi
00007ac9d05d39ed  pop rdx
00007ac9d05d39ee  pop rcx
00007ac9d05d39ef  pop rax
00007ac9d05d39f0  add rsp, 0x08
00007ac9d05d39f4  jmp 0x00007AC9D05D29FA
00007ac9d05d39f9  sub rsp, 0x08
00007ac9d05d39fd  push rax
00007ac9d05d39fe  push rcx
00007ac9d05d39ff  push rdx
00007ac9d05d3a00  push rdi
00007ac9d05d3a01  push rsi
00007ac9d05d3a02  push r8
00007ac9d05d3a04  push r9
00007ac9d05d3a06  push r10
00007ac9d05d3a08  push r11
00007ac9d05d3a0a  sub rsp, 0xF0
00007ac9d05d3a11  vmovaps [rsp], xmm0
00007ac9d05d3a16  vmovaps [rsp+0x10], xmm1
00007ac9d05d3a1c  vmovaps [rsp+0x20], xmm2
00007ac9d05d3a22  vmovaps [rsp+0x30], xmm3
00007ac9d05d3a28  vmovaps [rsp+0x40], xmm4
00007ac9d05d3a2e  vmovaps [rsp+0x50], xmm5
00007ac9d05d3a34  vmovaps [rsp+0x60], xmm6
00007ac9d05d3a3a  vmovaps [rsp+0x70], xmm7
00007ac9d05d3a40  vmovaps [rsp+0x80], xmm8
00007ac9d05d3a49  vmovaps [rsp+0x90], xmm9
00007ac9d05d3a52  vmovaps [rsp+0xA0], xmm10
00007ac9d05d3a5b  vmovaps [rsp+0xB0], xmm11
00007ac9d05d3a64  vmovaps [rsp+0xC0], xmm12
00007ac9d05d3a6d  vmovaps [rsp+0xD0], xmm14
00007ac9d05d3a76  vmovaps [rsp+0xE0], xmm15
00007ac9d05d3a7f  sub rsp, 0x40
00007ac9d05d3a83  lea rdi, [rsp]
00007ac9d05d3a87  lea rsi, [rsp+0x10]
00007ac9d05d3a8c  lea rdx, [rsp+0x20]
00007ac9d05d3a91  lea rcx, [rsp+0x30]
00007ac9d05d3a96  mov r8d, 0x00
00007ac9d05d3a9c  lea r9, [r15+0x3A8]
00007ac9d05d3aa3  movaps [rdi], xmm13
00007ac9d05d3aa7  movaps [rsi], xmm1
00007ac9d05d3aaa  movaps [rdx], xmm15
00007ac9d05d3aae  movaps [rcx], xmm14
00007ac9d05d3ab2  mov rax, 0x569AF9F93A50
00007ac9d05d3abc  call rax
00007ac9d05d3abe  movaps xmm13, [rsp]
00007ac9d05d3ac3  add rsp, 0x40
00007ac9d05d3ac7  vmovaps xmm0, [rsp]
00007ac9d05d3acc  vmovaps xmm1, [rsp+0x10]
00007ac9d05d3ad2  vmovaps xmm2, [rsp+0x20]
00007ac9d05d3ad8  vmovaps xmm3, [rsp+0x30]
00007ac9d05d3ade  vmovaps xmm4, [rsp+0x40]
00007ac9d05d3ae4  vmovaps xmm5, [rsp+0x50]
00007ac9d05d3aea  vmovaps xmm6, [rsp+0x60]
00007ac9d05d3af0  vmovaps xmm7, [rsp+0x70]
00007ac9d05d3af6  vmovaps xmm8, [rsp+0x80]
00007ac9d05d3aff  vmovaps xmm9, [rsp+0x90]
00007ac9d05d3b08  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d3b11  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d3b1a  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d3b23  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d3b2c  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d3b35  add rsp, 0xF0
00007ac9d05d3b3c  pop r11
00007ac9d05d3b3e  pop r10
00007ac9d05d3b40  pop r9
00007ac9d05d3b42  pop r8
00007ac9d05d3b44  pop rsi
00007ac9d05d3b45  pop rdi
00007ac9d05d3b46  pop rdx
00007ac9d05d3b47  pop rcx
00007ac9d05d3b48  pop rax
00007ac9d05d3b49  add rsp, 0x08
00007ac9d05d3b4d  jmp 0x00007AC9D05D2B77
00007ac9d05d3b52  sub rsp, 0x08
00007ac9d05d3b56  push rax
00007ac9d05d3b57  push rcx
00007ac9d05d3b58  push rdx
00007ac9d05d3b59  push rdi
00007ac9d05d3b5a  push rsi
00007ac9d05d3b5b  push r8
00007ac9d05d3b5d  push r9
00007ac9d05d3b5f  push r10
00007ac9d05d3b61  push r11
00007ac9d05d3b63  sub rsp, 0xF0
00007ac9d05d3b6a  vmovaps [rsp], xmm0
00007ac9d05d3b6f  vmovaps [rsp+0x10], xmm1
00007ac9d05d3b75  vmovaps [rsp+0x20], xmm2
00007ac9d05d3b7b  vmovaps [rsp+0x30], xmm3
00007ac9d05d3b81  vmovaps [rsp+0x40], xmm4
00007ac9d05d3b87  vmovaps [rsp+0x50], xmm5
00007ac9d05d3b8d  vmovaps [rsp+0x60], xmm6
00007ac9d05d3b93  vmovaps [rsp+0x70], xmm7
00007ac9d05d3b99  vmovaps [rsp+0x80], xmm8
00007ac9d05d3ba2  vmovaps [rsp+0x90], xmm9
00007ac9d05d3bab  vmovaps [rsp+0xA0], xmm10
00007ac9d05d3bb4  vmovaps [rsp+0xB0], xmm11
00007ac9d05d3bbd  vmovaps [rsp+0xC0], xmm13
00007ac9d05d3bc6  vmovaps [rsp+0xD0], xmm14
00007ac9d05d3bcf  vmovaps [rsp+0xE0], xmm15
00007ac9d05d3bd8  sub rsp, 0x40
00007ac9d05d3bdc  lea rdi, [rsp]
00007ac9d05d3be0  lea rsi, [rsp+0x10]
00007ac9d05d3be5  lea rdx, [rsp+0x20]
00007ac9d05d3bea  lea rcx, [rsp+0x30]
00007ac9d05d3bef  mov r8d, 0x00
00007ac9d05d3bf5  lea r9, [r15+0x3A8]
00007ac9d05d3bfc  movaps [rdi], xmm12
00007ac9d05d3c00  movaps [rsi], xmm15
00007ac9d05d3c04  movaps [rdx], xmm14
00007ac9d05d3c08  movaps [rcx], xmm1
00007ac9d05d3c0b  mov rax, 0x569AF9F93A50
00007ac9d05d3c15  call rax
00007ac9d05d3c17  movaps xmm12, [rsp]
00007ac9d05d3c1c  add rsp, 0x40
00007ac9d05d3c20  vmovaps xmm0, [rsp]
00007ac9d05d3c25  vmovaps xmm1, [rsp+0x10]
00007ac9d05d3c2b  vmovaps xmm2, [rsp+0x20]
00007ac9d05d3c31  vmovaps xmm3, [rsp+0x30]
00007ac9d05d3c37  vmovaps xmm4, [rsp+0x40]
00007ac9d05d3c3d  vmovaps xmm5, [rsp+0x50]
00007ac9d05d3c43  vmovaps xmm6, [rsp+0x60]
00007ac9d05d3c49  vmovaps xmm7, [rsp+0x70]
00007ac9d05d3c4f  vmovaps xmm8, [rsp+0x80]
00007ac9d05d3c58  vmovaps xmm9, [rsp+0x90]
00007ac9d05d3c61  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d3c6a  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d3c73  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d3c7c  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d3c85  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d3c8e  add rsp, 0xF0
00007ac9d05d3c95  pop r11
00007ac9d05d3c97  pop r10
00007ac9d05d3c99  pop r9
00007ac9d05d3c9b  pop r8
00007ac9d05d3c9d  pop rsi
00007ac9d05d3c9e  pop rdi
00007ac9d05d3c9f  pop rdx
00007ac9d05d3ca0  pop rcx
00007ac9d05d3ca1  pop rax
00007ac9d05d3ca2  add rsp, 0x08
00007ac9d05d3ca6  jmp 0x00007AC9D05D2BB2
00007ac9d05d3cab  sub rsp, 0x08
00007ac9d05d3caf  push rax
00007ac9d05d3cb0  push rcx
00007ac9d05d3cb1  push rdx
00007ac9d05d3cb2  push rdi
00007ac9d05d3cb3  push rsi
00007ac9d05d3cb4  push r8
00007ac9d05d3cb6  push r9
00007ac9d05d3cb8  push r10
00007ac9d05d3cba  push r11
00007ac9d05d3cbc  sub rsp, 0xF0
00007ac9d05d3cc3  vmovaps [rsp], xmm0
00007ac9d05d3cc8  vmovaps [rsp+0x10], xmm1
00007ac9d05d3cce  vmovaps [rsp+0x20], xmm2
00007ac9d05d3cd4  vmovaps [rsp+0x30], xmm3
00007ac9d05d3cda  vmovaps [rsp+0x40], xmm4
00007ac9d05d3ce0  vmovaps [rsp+0x50], xmm5
00007ac9d05d3ce6  vmovaps [rsp+0x60], xmm6
00007ac9d05d3cec  vmovaps [rsp+0x70], xmm7
00007ac9d05d3cf2  vmovaps [rsp+0x80], xmm8
00007ac9d05d3cfb  vmovaps [rsp+0x90], xmm9
00007ac9d05d3d04  vmovaps [rsp+0xA0], xmm10
00007ac9d05d3d0d  vmovaps [rsp+0xB0], xmm11
00007ac9d05d3d16  vmovaps [rsp+0xC0], xmm12
00007ac9d05d3d1f  vmovaps [rsp+0xD0], xmm14
00007ac9d05d3d28  vmovaps [rsp+0xE0], xmm15
00007ac9d05d3d31  sub rsp, 0x40
00007ac9d05d3d35  lea rdi, [rsp]
00007ac9d05d3d39  lea rsi, [rsp+0x10]
00007ac9d05d3d3e  lea rdx, [rsp+0x20]
00007ac9d05d3d43  lea rcx, [rsp+0x30]
00007ac9d05d3d48  mov r8d, 0x00
00007ac9d05d3d4e  lea r9, [r15+0x3A8]
00007ac9d05d3d55  movaps [rdi], xmm13
00007ac9d05d3d59  movaps [rsi], xmm15
00007ac9d05d3d5d  movaps [rdx], xmm14
00007ac9d05d3d61  movaps [rcx], xmm1
00007ac9d05d3d64  mov rax, 0x569AF9F93A50
00007ac9d05d3d6e  call rax
00007ac9d05d3d70  movaps xmm13, [rsp]
00007ac9d05d3d75  add rsp, 0x40
00007ac9d05d3d79  vmovaps xmm0, [rsp]
00007ac9d05d3d7e  vmovaps xmm1, [rsp+0x10]
00007ac9d05d3d84  vmovaps xmm2, [rsp+0x20]
00007ac9d05d3d8a  vmovaps xmm3, [rsp+0x30]
00007ac9d05d3d90  vmovaps xmm4, [rsp+0x40]
00007ac9d05d3d96  vmovaps xmm5, [rsp+0x50]
00007ac9d05d3d9c  vmovaps xmm6, [rsp+0x60]
00007ac9d05d3da2  vmovaps xmm7, [rsp+0x70]
00007ac9d05d3da8  vmovaps xmm8, [rsp+0x80]
00007ac9d05d3db1  vmovaps xmm9, [rsp+0x90]
00007ac9d05d3dba  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d3dc3  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d3dcc  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d3dd5  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d3dde  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d3de7  add rsp, 0xF0
00007ac9d05d3dee  pop r11
00007ac9d05d3df0  pop r10
00007ac9d05d3df2  pop r9
00007ac9d05d3df4  pop r8
00007ac9d05d3df6  pop rsi
00007ac9d05d3df7  pop rdi
00007ac9d05d3df8  pop rdx
00007ac9d05d3df9  pop rcx
00007ac9d05d3dfa  pop rax
00007ac9d05d3dfb  add rsp, 0x08
00007ac9d05d3dff  jmp 0x00007AC9D05D2BEA
00007ac9d05d3e04  sub rsp, 0x08
00007ac9d05d3e08  push rax
00007ac9d05d3e09  push rcx
00007ac9d05d3e0a  push rdx
00007ac9d05d3e0b  push rdi
00007ac9d05d3e0c  push rsi
00007ac9d05d3e0d  push r8
00007ac9d05d3e0f  push r9
00007ac9d05d3e11  push r10
00007ac9d05d3e13  push r11
00007ac9d05d3e15  sub rsp, 0xF0
00007ac9d05d3e1c  vmovaps [rsp], xmm0
00007ac9d05d3e21  vmovaps [rsp+0x10], xmm1
00007ac9d05d3e27  vmovaps [rsp+0x20], xmm2
00007ac9d05d3e2d  vmovaps [rsp+0x30], xmm3
00007ac9d05d3e33  vmovaps [rsp+0x40], xmm4
00007ac9d05d3e39  vmovaps [rsp+0x50], xmm5
00007ac9d05d3e3f  vmovaps [rsp+0x60], xmm6
00007ac9d05d3e45  vmovaps [rsp+0x70], xmm7
00007ac9d05d3e4b  vmovaps [rsp+0x80], xmm8
00007ac9d05d3e54  vmovaps [rsp+0x90], xmm9
00007ac9d05d3e5d  vmovaps [rsp+0xA0], xmm10
00007ac9d05d3e66  vmovaps [rsp+0xB0], xmm11
00007ac9d05d3e6f  vmovaps [rsp+0xC0], xmm13
00007ac9d05d3e78  vmovaps [rsp+0xD0], xmm14
00007ac9d05d3e81  vmovaps [rsp+0xE0], xmm15
00007ac9d05d3e8a  sub rsp, 0x40
00007ac9d05d3e8e  lea rdi, [rsp]
00007ac9d05d3e92  lea rsi, [rsp+0x10]
00007ac9d05d3e97  lea rdx, [rsp+0x20]
00007ac9d05d3e9c  lea rcx, [rsp+0x30]
00007ac9d05d3ea1  mov r8d, 0x00
00007ac9d05d3ea7  lea r9, [r15+0x3A8]
00007ac9d05d3eae  movaps [rdi], xmm12
00007ac9d05d3eb2  movaps [rsi], xmm15
00007ac9d05d3eb6  movaps [rdx], xmm14
00007ac9d05d3eba  movaps [rcx], xmm1
00007ac9d05d3ebd  mov rax, 0x569AF9F93A50
00007ac9d05d3ec7  call rax
00007ac9d05d3ec9  movaps xmm12, [rsp]
00007ac9d05d3ece  add rsp, 0x40
00007ac9d05d3ed2  vmovaps xmm0, [rsp]
00007ac9d05d3ed7  vmovaps xmm1, [rsp+0x10]
00007ac9d05d3edd  vmovaps xmm2, [rsp+0x20]
00007ac9d05d3ee3  vmovaps xmm3, [rsp+0x30]
00007ac9d05d3ee9  vmovaps xmm4, [rsp+0x40]
00007ac9d05d3eef  vmovaps xmm5, [rsp+0x50]
00007ac9d05d3ef5  vmovaps xmm6, [rsp+0x60]
00007ac9d05d3efb  vmovaps xmm7, [rsp+0x70]
00007ac9d05d3f01  vmovaps xmm8, [rsp+0x80]
00007ac9d05d3f0a  vmovaps xmm9, [rsp+0x90]
00007ac9d05d3f13  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d3f1c  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d3f25  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d3f2e  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d3f37  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d3f40  add rsp, 0xF0
00007ac9d05d3f47  pop r11
00007ac9d05d3f49  pop r10
00007ac9d05d3f4b  pop r9
00007ac9d05d3f4d  pop r8
00007ac9d05d3f4f  pop rsi
00007ac9d05d3f50  pop rdi
00007ac9d05d3f51  pop rdx
00007ac9d05d3f52  pop rcx
00007ac9d05d3f53  pop rax
00007ac9d05d3f54  add rsp, 0x08
00007ac9d05d3f58  jmp 0x00007AC9D05D2C3D
00007ac9d05d3f5d  sub rsp, 0x08
00007ac9d05d3f61  push rax
00007ac9d05d3f62  push rcx
00007ac9d05d3f63  push rdx
00007ac9d05d3f64  push rdi
00007ac9d05d3f65  push rsi
00007ac9d05d3f66  push r8
00007ac9d05d3f68  push r9
00007ac9d05d3f6a  push r10
00007ac9d05d3f6c  push r11
00007ac9d05d3f6e  sub rsp, 0xF0
00007ac9d05d3f75  vmovaps [rsp], xmm0
00007ac9d05d3f7a  vmovaps [rsp+0x10], xmm1
00007ac9d05d3f80  vmovaps [rsp+0x20], xmm2
00007ac9d05d3f86  vmovaps [rsp+0x30], xmm3
00007ac9d05d3f8c  vmovaps [rsp+0x40], xmm4
00007ac9d05d3f92  vmovaps [rsp+0x50], xmm5
00007ac9d05d3f98  vmovaps [rsp+0x60], xmm6
00007ac9d05d3f9e  vmovaps [rsp+0x70], xmm7
00007ac9d05d3fa4  vmovaps [rsp+0x80], xmm8
00007ac9d05d3fad  vmovaps [rsp+0x90], xmm9
00007ac9d05d3fb6  vmovaps [rsp+0xA0], xmm10
00007ac9d05d3fbf  vmovaps [rsp+0xB0], xmm11
00007ac9d05d3fc8  vmovaps [rsp+0xC0], xmm12
00007ac9d05d3fd1  vmovaps [rsp+0xD0], xmm13
00007ac9d05d3fda  vmovaps [rsp+0xE0], xmm15
00007ac9d05d3fe3  sub rsp, 0x40
00007ac9d05d3fe7  lea rdi, [rsp]
00007ac9d05d3feb  lea rsi, [rsp+0x10]
00007ac9d05d3ff0  lea rdx, [rsp+0x20]
00007ac9d05d3ff5  lea rcx, [rsp+0x30]
00007ac9d05d3ffa  mov r8d, 0x00
00007ac9d05d4000  lea r9, [r15+0x3A8]
00007ac9d05d4007  movaps [rdi], xmm14
00007ac9d05d400b  movaps [rsi], xmm3
00007ac9d05d400e  movaps [rdx], xmm1
00007ac9d05d4011  movaps [rcx], xmm15
00007ac9d05d4015  mov rax, 0x569AF9F93A50
00007ac9d05d401f  call rax
00007ac9d05d4021  movaps xmm14, [rsp]
00007ac9d05d4026  add rsp, 0x40
00007ac9d05d402a  vmovaps xmm0, [rsp]
00007ac9d05d402f  vmovaps xmm1, [rsp+0x10]
00007ac9d05d4035  vmovaps xmm2, [rsp+0x20]
00007ac9d05d403b  vmovaps xmm3, [rsp+0x30]
00007ac9d05d4041  vmovaps xmm4, [rsp+0x40]
00007ac9d05d4047  vmovaps xmm5, [rsp+0x50]
00007ac9d05d404d  vmovaps xmm6, [rsp+0x60]
00007ac9d05d4053  vmovaps xmm7, [rsp+0x70]
00007ac9d05d4059  vmovaps xmm8, [rsp+0x80]
00007ac9d05d4062  vmovaps xmm9, [rsp+0x90]
00007ac9d05d406b  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d4074  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d407d  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d4086  vmovaps xmm13, [rsp+0xD0]
00007ac9d05d408f  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d4098  add rsp, 0xF0
00007ac9d05d409f  pop r11
00007ac9d05d40a1  pop r10
00007ac9d05d40a3  pop r9
00007ac9d05d40a5  pop r8
00007ac9d05d40a7  pop rsi
00007ac9d05d40a8  pop rdi
00007ac9d05d40a9  pop rdx
00007ac9d05d40aa  pop rcx
00007ac9d05d40ab  pop rax
00007ac9d05d40ac  add rsp, 0x08
00007ac9d05d40b0  jmp 0x00007AC9D05D2CF7
00007ac9d05d40b5  sub rsp, 0x08
00007ac9d05d40b9  push rax
00007ac9d05d40ba  push rcx
00007ac9d05d40bb  push rdx
00007ac9d05d40bc  push rdi
00007ac9d05d40bd  push rsi
00007ac9d05d40be  push r8
00007ac9d05d40c0  push r9
00007ac9d05d40c2  push r10
00007ac9d05d40c4  push r11
00007ac9d05d40c6  sub rsp, 0xF0
00007ac9d05d40cd  vmovaps [rsp], xmm0
00007ac9d05d40d2  vmovaps [rsp+0x10], xmm1
00007ac9d05d40d8  vmovaps [rsp+0x20], xmm2
00007ac9d05d40de  vmovaps [rsp+0x30], xmm3
00007ac9d05d40e4  vmovaps [rsp+0x40], xmm4
00007ac9d05d40ea  vmovaps [rsp+0x50], xmm5
00007ac9d05d40f0  vmovaps [rsp+0x60], xmm6
00007ac9d05d40f6  vmovaps [rsp+0x70], xmm7
00007ac9d05d40fc  vmovaps [rsp+0x80], xmm8
00007ac9d05d4105  vmovaps [rsp+0x90], xmm9
00007ac9d05d410e  vmovaps [rsp+0xA0], xmm10
00007ac9d05d4117  vmovaps [rsp+0xB0], xmm11
00007ac9d05d4120  vmovaps [rsp+0xC0], xmm12
00007ac9d05d4129  vmovaps [rsp+0xD0], xmm14
00007ac9d05d4132  vmovaps [rsp+0xE0], xmm15
00007ac9d05d413b  sub rsp, 0x40
00007ac9d05d413f  lea rdi, [rsp]
00007ac9d05d4143  lea rsi, [rsp+0x10]
00007ac9d05d4148  lea rdx, [rsp+0x20]
00007ac9d05d414d  lea rcx, [rsp+0x30]
00007ac9d05d4152  mov r8d, 0x00
00007ac9d05d4158  lea r9, [r15+0x3A8]
00007ac9d05d415f  movaps [rdi], xmm13
00007ac9d05d4163  movaps [rsi], xmm15
00007ac9d05d4167  movaps [rdx], xmm10
00007ac9d05d416b  movaps [rcx], xmm1
00007ac9d05d416e  mov rax, 0x569AF9F93A50
00007ac9d05d4178  call rax
00007ac9d05d417a  movaps xmm13, [rsp]
00007ac9d05d417f  add rsp, 0x40
00007ac9d05d4183  vmovaps xmm0, [rsp]
00007ac9d05d4188  vmovaps xmm1, [rsp+0x10]
00007ac9d05d418e  vmovaps xmm2, [rsp+0x20]
00007ac9d05d4194  vmovaps xmm3, [rsp+0x30]
00007ac9d05d419a  vmovaps xmm4, [rsp+0x40]
00007ac9d05d41a0  vmovaps xmm5, [rsp+0x50]
00007ac9d05d41a6  vmovaps xmm6, [rsp+0x60]
00007ac9d05d41ac  vmovaps xmm7, [rsp+0x70]
00007ac9d05d41b2  vmovaps xmm8, [rsp+0x80]
00007ac9d05d41bb  vmovaps xmm9, [rsp+0x90]
00007ac9d05d41c4  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d41cd  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d41d6  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d41df  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d41e8  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d41f1  add rsp, 0xF0
00007ac9d05d41f8  pop r11
00007ac9d05d41fa  pop r10
00007ac9d05d41fc  pop r9
00007ac9d05d41fe  pop r8
00007ac9d05d4200  pop rsi
00007ac9d05d4201  pop rdi
00007ac9d05d4202  pop rdx
00007ac9d05d4203  pop rcx
00007ac9d05d4204  pop rax
00007ac9d05d4205  add rsp, 0x08
00007ac9d05d4209  jmp 0x00007AC9D05D2D26
00007ac9d05d420e  sub rsp, 0x08
00007ac9d05d4212  push rax
00007ac9d05d4213  push rcx
00007ac9d05d4214  push rdx
00007ac9d05d4215  push rdi
00007ac9d05d4216  push rsi
00007ac9d05d4217  push r8
00007ac9d05d4219  push r9
00007ac9d05d421b  push r10
00007ac9d05d421d  push r11
00007ac9d05d421f  sub rsp, 0xF0
00007ac9d05d4226  vmovaps [rsp], xmm0
00007ac9d05d422b  vmovaps [rsp+0x10], xmm1
00007ac9d05d4231  vmovaps [rsp+0x20], xmm2
00007ac9d05d4237  vmovaps [rsp+0x30], xmm3
00007ac9d05d423d  vmovaps [rsp+0x40], xmm4
00007ac9d05d4243  vmovaps [rsp+0x50], xmm5
00007ac9d05d4249  vmovaps [rsp+0x60], xmm6
00007ac9d05d424f  vmovaps [rsp+0x70], xmm7
00007ac9d05d4255  vmovaps [rsp+0x80], xmm8
00007ac9d05d425e  vmovaps [rsp+0x90], xmm9
00007ac9d05d4267  vmovaps [rsp+0xA0], xmm11
00007ac9d05d4270  vmovaps [rsp+0xB0], xmm12
00007ac9d05d4279  vmovaps [rsp+0xC0], xmm13
00007ac9d05d4282  vmovaps [rsp+0xD0], xmm14
00007ac9d05d428b  vmovaps [rsp+0xE0], xmm15
00007ac9d05d4294  sub rsp, 0x40
00007ac9d05d4298  lea rdi, [rsp]
00007ac9d05d429c  lea rsi, [rsp+0x10]
00007ac9d05d42a1  lea rdx, [rsp+0x20]
00007ac9d05d42a6  lea rcx, [rsp+0x30]
00007ac9d05d42ab  mov r8d, 0x00
00007ac9d05d42b1  lea r9, [r15+0x3A8]
00007ac9d05d42b8  movaps [rdi], xmm10
00007ac9d05d42bc  movaps [rsi], xmm15
00007ac9d05d42c0  movaps [rdx], xmm11
00007ac9d05d42c4  movaps [rcx], xmm1
00007ac9d05d42c7  mov rax, 0x569AF9F93A50
00007ac9d05d42d1  call rax
00007ac9d05d42d3  movaps xmm10, [rsp]
00007ac9d05d42d8  add rsp, 0x40
00007ac9d05d42dc  vmovaps xmm0, [rsp]
00007ac9d05d42e1  vmovaps xmm1, [rsp+0x10]
00007ac9d05d42e7  vmovaps xmm2, [rsp+0x20]
00007ac9d05d42ed  vmovaps xmm3, [rsp+0x30]
00007ac9d05d42f3  vmovaps xmm4, [rsp+0x40]
00007ac9d05d42f9  vmovaps xmm5, [rsp+0x50]
00007ac9d05d42ff  vmovaps xmm6, [rsp+0x60]
00007ac9d05d4305  vmovaps xmm7, [rsp+0x70]
00007ac9d05d430b  vmovaps xmm8, [rsp+0x80]
00007ac9d05d4314  vmovaps xmm9, [rsp+0x90]
00007ac9d05d431d  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d4326  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d432f  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d4338  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d4341  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d434a  add rsp, 0xF0
00007ac9d05d4351  pop r11
00007ac9d05d4353  pop r10
00007ac9d05d4355  pop r9
00007ac9d05d4357  pop r8
00007ac9d05d4359  pop rsi
00007ac9d05d435a  pop rdi
00007ac9d05d435b  pop rdx
00007ac9d05d435c  pop rcx
00007ac9d05d435d  pop rax
00007ac9d05d435e  add rsp, 0x08
00007ac9d05d4362  jmp 0x00007AC9D05D2D55
00007ac9d05d4367  sub rsp, 0x08
00007ac9d05d436b  push rax
00007ac9d05d436c  push rcx
00007ac9d05d436d  push rdx
00007ac9d05d436e  push rdi
00007ac9d05d436f  push rsi
00007ac9d05d4370  push r8
00007ac9d05d4372  push r9
00007ac9d05d4374  push r10
00007ac9d05d4376  push r11
00007ac9d05d4378  sub rsp, 0xF0
00007ac9d05d437f  vmovaps [rsp], xmm0
00007ac9d05d4384  vmovaps [rsp+0x10], xmm1
00007ac9d05d438a  vmovaps [rsp+0x20], xmm2
00007ac9d05d4390  vmovaps [rsp+0x30], xmm3
00007ac9d05d4396  vmovaps [rsp+0x40], xmm4
00007ac9d05d439c  vmovaps [rsp+0x50], xmm5
00007ac9d05d43a2  vmovaps [rsp+0x60], xmm6
00007ac9d05d43a8  vmovaps [rsp+0x70], xmm7
00007ac9d05d43ae  vmovaps [rsp+0x80], xmm8
00007ac9d05d43b7  vmovaps [rsp+0x90], xmm9
00007ac9d05d43c0  vmovaps [rsp+0xA0], xmm10
00007ac9d05d43c9  vmovaps [rsp+0xB0], xmm11
00007ac9d05d43d2  vmovaps [rsp+0xC0], xmm12
00007ac9d05d43db  vmovaps [rsp+0xD0], xmm13
00007ac9d05d43e4  vmovaps [rsp+0xE0], xmm14
00007ac9d05d43ed  sub rsp, 0x40
00007ac9d05d43f1  lea rdi, [rsp]
00007ac9d05d43f5  lea rsi, [rsp+0x10]
00007ac9d05d43fa  lea rdx, [rsp+0x20]
00007ac9d05d43ff  lea rcx, [rsp+0x30]
00007ac9d05d4404  mov r8d, 0x00
00007ac9d05d440a  lea r9, [r15+0x3A8]
00007ac9d05d4411  movaps [rdi], xmm15
00007ac9d05d4415  movaps [rsi], xmm12
00007ac9d05d4419  movaps [rdx], xmm5
00007ac9d05d441c  movaps [rcx], xmm1
00007ac9d05d441f  mov rax, 0x569AF9F93A50
00007ac9d05d4429  call rax
00007ac9d05d442b  movaps xmm15, [rsp]
00007ac9d05d4430  add rsp, 0x40
00007ac9d05d4434  vmovaps xmm0, [rsp]
00007ac9d05d4439  vmovaps xmm1, [rsp+0x10]
00007ac9d05d443f  vmovaps xmm2, [rsp+0x20]
00007ac9d05d4445  vmovaps xmm3, [rsp+0x30]
00007ac9d05d444b  vmovaps xmm4, [rsp+0x40]
00007ac9d05d4451  vmovaps xmm5, [rsp+0x50]
00007ac9d05d4457  vmovaps xmm6, [rsp+0x60]
00007ac9d05d445d  vmovaps xmm7, [rsp+0x70]
00007ac9d05d4463  vmovaps xmm8, [rsp+0x80]
00007ac9d05d446c  vmovaps xmm9, [rsp+0x90]
00007ac9d05d4475  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d447e  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d4487  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d4490  vmovaps xmm13, [rsp+0xD0]
00007ac9d05d4499  vmovaps xmm14, [rsp+0xE0]
00007ac9d05d44a2  add rsp, 0xF0
00007ac9d05d44a9  pop r11
00007ac9d05d44ab  pop r10
00007ac9d05d44ad  pop r9
00007ac9d05d44af  pop r8
00007ac9d05d44b1  pop rsi
00007ac9d05d44b2  pop rdi
00007ac9d05d44b3  pop rdx
00007ac9d05d44b4  pop rcx
00007ac9d05d44b5  pop rax
00007ac9d05d44b6  add rsp, 0x08
00007ac9d05d44ba  jmp 0x00007AC9D05D2D7E
00007ac9d05d44bf  sub rsp, 0x08
00007ac9d05d44c3  push rax
00007ac9d05d44c4  push rcx
00007ac9d05d44c5  push rdx
00007ac9d05d44c6  push rdi
00007ac9d05d44c7  push rsi
00007ac9d05d44c8  push r8
00007ac9d05d44ca  push r9
00007ac9d05d44cc  push r10
00007ac9d05d44ce  push r11
00007ac9d05d44d0  sub rsp, 0xF0
00007ac9d05d44d7  vmovaps [rsp], xmm0
00007ac9d05d44dc  vmovaps [rsp+0x10], xmm1
00007ac9d05d44e2  vmovaps [rsp+0x20], xmm2
00007ac9d05d44e8  vmovaps [rsp+0x30], xmm3
00007ac9d05d44ee  vmovaps [rsp+0x40], xmm4
00007ac9d05d44f4  vmovaps [rsp+0x50], xmm6
00007ac9d05d44fa  vmovaps [rsp+0x60], xmm7
00007ac9d05d4500  vmovaps [rsp+0x70], xmm8
00007ac9d05d4506  vmovaps [rsp+0x80], xmm9
00007ac9d05d450f  vmovaps [rsp+0x90], xmm10
00007ac9d05d4518  vmovaps [rsp+0xA0], xmm11
00007ac9d05d4521  vmovaps [rsp+0xB0], xmm12
00007ac9d05d452a  vmovaps [rsp+0xC0], xmm13
00007ac9d05d4533  vmovaps [rsp+0xD0], xmm14
00007ac9d05d453c  vmovaps [rsp+0xE0], xmm15
00007ac9d05d4545  sub rsp, 0x40
00007ac9d05d4549  lea rdi, [rsp]
00007ac9d05d454d  lea rsi, [rsp+0x10]
00007ac9d05d4552  lea rdx, [rsp+0x20]
00007ac9d05d4557  lea rcx, [rsp+0x30]
00007ac9d05d455c  mov r8d, 0x00
00007ac9d05d4562  lea r9, [r15+0x3A8]
00007ac9d05d4569  movaps [rdi], xmm5
00007ac9d05d456c  movaps [rsi], xmm13
00007ac9d05d4570  movaps [rdx], xmm11
00007ac9d05d4574  movaps [rcx], xmm12
00007ac9d05d4578  mov rax, 0x569AF9F93A50
00007ac9d05d4582  call rax
00007ac9d05d4584  movaps xmm5, [rsp]
00007ac9d05d4588  add rsp, 0x40
00007ac9d05d458c  vmovaps xmm0, [rsp]
00007ac9d05d4591  vmovaps xmm1, [rsp+0x10]
00007ac9d05d4597  vmovaps xmm2, [rsp+0x20]
00007ac9d05d459d  vmovaps xmm3, [rsp+0x30]
00007ac9d05d45a3  vmovaps xmm4, [rsp+0x40]
00007ac9d05d45a9  vmovaps xmm6, [rsp+0x50]
00007ac9d05d45af  vmovaps xmm7, [rsp+0x60]
00007ac9d05d45b5  vmovaps xmm8, [rsp+0x70]
00007ac9d05d45bb  vmovaps xmm9, [rsp+0x80]
00007ac9d05d45c4  vmovaps xmm10, [rsp+0x90]
00007ac9d05d45cd  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d45d6  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d45df  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d45e8  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d45f1  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d45fa  add rsp, 0xF0
00007ac9d05d4601  pop r11
00007ac9d05d4603  pop r10
00007ac9d05d4605  pop r9
00007ac9d05d4607  pop r8
00007ac9d05d4609  pop rsi
00007ac9d05d460a  pop rdi
00007ac9d05d460b  pop rdx
00007ac9d05d460c  pop rcx
00007ac9d05d460d  pop rax
00007ac9d05d460e  add rsp, 0x08
00007ac9d05d4612  jmp 0x00007AC9D05D2DDD
00007ac9d05d4617  sub rsp, 0x08
00007ac9d05d461b  push rax
00007ac9d05d461c  push rcx
00007ac9d05d461d  push rdx
00007ac9d05d461e  push rdi
00007ac9d05d461f  push rsi
00007ac9d05d4620  push r8
00007ac9d05d4622  push r9
00007ac9d05d4624  push r10
00007ac9d05d4626  push r11
00007ac9d05d4628  sub rsp, 0xF0
00007ac9d05d462f  vmovaps [rsp], xmm0
00007ac9d05d4634  vmovaps [rsp+0x10], xmm1
00007ac9d05d463a  vmovaps [rsp+0x20], xmm2
00007ac9d05d4640  vmovaps [rsp+0x30], xmm3
00007ac9d05d4646  vmovaps [rsp+0x40], xmm4
00007ac9d05d464c  vmovaps [rsp+0x50], xmm5
00007ac9d05d4652  vmovaps [rsp+0x60], xmm6
00007ac9d05d4658  vmovaps [rsp+0x70], xmm7
00007ac9d05d465e  vmovaps [rsp+0x80], xmm8
00007ac9d05d4667  vmovaps [rsp+0x90], xmm9
00007ac9d05d4670  vmovaps [rsp+0xA0], xmm10
00007ac9d05d4679  vmovaps [rsp+0xB0], xmm11
00007ac9d05d4682  vmovaps [rsp+0xC0], xmm13
00007ac9d05d468b  vmovaps [rsp+0xD0], xmm14
00007ac9d05d4694  vmovaps [rsp+0xE0], xmm15
00007ac9d05d469d  sub rsp, 0x40
00007ac9d05d46a1  lea rdi, [rsp]
00007ac9d05d46a5  lea rsi, [rsp+0x10]
00007ac9d05d46aa  lea rdx, [rsp+0x20]
00007ac9d05d46af  lea rcx, [rsp+0x30]
00007ac9d05d46b4  mov r8d, 0x00
00007ac9d05d46ba  lea r9, [r15+0x3A8]
00007ac9d05d46c1  movaps [rdi], xmm12
00007ac9d05d46c5  movaps [rsi], xmm14
00007ac9d05d46c9  movaps [rdx], xmm9
00007ac9d05d46cd  movaps [rcx], xmm13
00007ac9d05d46d1  mov rax, 0x569AF9F93A50
00007ac9d05d46db  call rax
00007ac9d05d46dd  movaps xmm12, [rsp]
00007ac9d05d46e2  add rsp, 0x40
00007ac9d05d46e6  vmovaps xmm0, [rsp]
00007ac9d05d46eb  vmovaps xmm1, [rsp+0x10]
00007ac9d05d46f1  vmovaps xmm2, [rsp+0x20]
00007ac9d05d46f7  vmovaps xmm3, [rsp+0x30]
00007ac9d05d46fd  vmovaps xmm4, [rsp+0x40]
00007ac9d05d4703  vmovaps xmm5, [rsp+0x50]
00007ac9d05d4709  vmovaps xmm6, [rsp+0x60]
00007ac9d05d470f  vmovaps xmm7, [rsp+0x70]
00007ac9d05d4715  vmovaps xmm8, [rsp+0x80]
00007ac9d05d471e  vmovaps xmm9, [rsp+0x90]
00007ac9d05d4727  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d4730  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d4739  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d4742  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d474b  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d4754  add rsp, 0xF0
00007ac9d05d475b  pop r11
00007ac9d05d475d  pop r10
00007ac9d05d475f  pop r9
00007ac9d05d4761  pop r8
00007ac9d05d4763  pop rsi
00007ac9d05d4764  pop rdi
00007ac9d05d4765  pop rdx
00007ac9d05d4766  pop rcx
00007ac9d05d4767  pop rax
00007ac9d05d4768  add rsp, 0x08
00007ac9d05d476c  jmp 0x00007AC9D05D2E06
00007ac9d05d4771  call 0x00007AC9D040D4E0
00007ac9d05d4776  jmp 0x00007AC9D05D2E13
00007ac9d05d477b  sub rsp, 0x08
00007ac9d05d477f  push rax
00007ac9d05d4780  push rcx
00007ac9d05d4781  push rdx
00007ac9d05d4782  push rdi
00007ac9d05d4783  push rsi
00007ac9d05d4784  push r8
00007ac9d05d4786  push r9
00007ac9d05d4788  push r10
00007ac9d05d478a  push r11
00007ac9d05d478c  sub rsp, 0xF0
00007ac9d05d4793  vmovaps [rsp], xmm0
00007ac9d05d4798  vmovaps [rsp+0x10], xmm1
00007ac9d05d479e  vmovaps [rsp+0x20], xmm2
00007ac9d05d47a4  vmovaps [rsp+0x30], xmm3
00007ac9d05d47aa  vmovaps [rsp+0x40], xmm4
00007ac9d05d47b0  vmovaps [rsp+0x50], xmm5
00007ac9d05d47b6  vmovaps [rsp+0x60], xmm6
00007ac9d05d47bc  vmovaps [rsp+0x70], xmm7
00007ac9d05d47c2  vmovaps [rsp+0x80], xmm8
00007ac9d05d47cb  vmovaps [rsp+0x90], xmm9
00007ac9d05d47d4  vmovaps [rsp+0xA0], xmm10
00007ac9d05d47dd  vmovaps [rsp+0xB0], xmm12
00007ac9d05d47e6  vmovaps [rsp+0xC0], xmm13
00007ac9d05d47ef  vmovaps [rsp+0xD0], xmm14
00007ac9d05d47f8  vmovaps [rsp+0xE0], xmm15
00007ac9d05d4801  sub rsp, 0x40
00007ac9d05d4805  lea rdi, [rsp]
00007ac9d05d4809  lea rsi, [rsp+0x10]
00007ac9d05d480e  lea rdx, [rsp+0x20]
00007ac9d05d4813  lea rcx, [rsp+0x30]
00007ac9d05d4818  mov r8d, 0x00
00007ac9d05d481e  lea r9, [r15+0x3A8]
00007ac9d05d4825  movaps [rdi], xmm11
00007ac9d05d4829  movaps [rsi], xmm10
00007ac9d05d482d  movaps [rdx], xmm8
00007ac9d05d4831  movaps [rcx], xmm13
00007ac9d05d4835  mov rax, 0x569AF9F93A50
00007ac9d05d483f  call rax
00007ac9d05d4841  movaps xmm11, [rsp]
00007ac9d05d4846  add rsp, 0x40
00007ac9d05d484a  vmovaps xmm0, [rsp]
00007ac9d05d484f  vmovaps xmm1, [rsp+0x10]
00007ac9d05d4855  vmovaps xmm2, [rsp+0x20]
00007ac9d05d485b  vmovaps xmm3, [rsp+0x30]
00007ac9d05d4861  vmovaps xmm4, [rsp+0x40]
00007ac9d05d4867  vmovaps xmm5, [rsp+0x50]
00007ac9d05d486d  vmovaps xmm6, [rsp+0x60]
00007ac9d05d4873  vmovaps xmm7, [rsp+0x70]
00007ac9d05d4879  vmovaps xmm8, [rsp+0x80]
00007ac9d05d4882  vmovaps xmm9, [rsp+0x90]
00007ac9d05d488b  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d4894  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d489d  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d48a6  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d48af  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d48b8  add rsp, 0xF0
00007ac9d05d48bf  pop r11
00007ac9d05d48c1  pop r10
00007ac9d05d48c3  pop r9
00007ac9d05d48c5  pop r8
00007ac9d05d48c7  pop rsi
00007ac9d05d48c8  pop rdi
00007ac9d05d48c9  pop rdx
00007ac9d05d48ca  pop rcx
00007ac9d05d48cb  pop rax
00007ac9d05d48cc  add rsp, 0x08
00007ac9d05d48d0  jmp 0x00007AC9D05D2E44
00007ac9d05d48d5  sub rsp, 0x08
00007ac9d05d48d9  push rax
00007ac9d05d48da  push rcx
00007ac9d05d48db  push rdx
00007ac9d05d48dc  push rdi
00007ac9d05d48dd  push rsi
00007ac9d05d48de  push r8
00007ac9d05d48e0  push r9
00007ac9d05d48e2  push r10
00007ac9d05d48e4  push r11
00007ac9d05d48e6  sub rsp, 0xF0
00007ac9d05d48ed  vmovaps [rsp], xmm0
00007ac9d05d48f2  vmovaps [rsp+0x10], xmm1
00007ac9d05d48f8  vmovaps [rsp+0x20], xmm2
00007ac9d05d48fe  vmovaps [rsp+0x30], xmm3
00007ac9d05d4904  vmovaps [rsp+0x40], xmm4
00007ac9d05d490a  vmovaps [rsp+0x50], xmm5
00007ac9d05d4910  vmovaps [rsp+0x60], xmm6
00007ac9d05d4916  vmovaps [rsp+0x70], xmm7
00007ac9d05d491c  vmovaps [rsp+0x80], xmm8
00007ac9d05d4925  vmovaps [rsp+0x90], xmm9
00007ac9d05d492e  vmovaps [rsp+0xA0], xmm11
00007ac9d05d4937  vmovaps [rsp+0xB0], xmm12
00007ac9d05d4940  vmovaps [rsp+0xC0], xmm13
00007ac9d05d4949  vmovaps [rsp+0xD0], xmm14
00007ac9d05d4952  vmovaps [rsp+0xE0], xmm15
00007ac9d05d495b  sub rsp, 0x40
00007ac9d05d495f  lea rdi, [rsp]
00007ac9d05d4963  lea rsi, [rsp+0x10]
00007ac9d05d4968  lea rdx, [rsp+0x20]
00007ac9d05d496d  lea rcx, [rsp+0x30]
00007ac9d05d4972  mov r8d, 0x00
00007ac9d05d4978  lea r9, [r15+0x3A8]
00007ac9d05d497f  movaps [rdi], xmm10
00007ac9d05d4983  movaps [rsi], xmm15
00007ac9d05d4987  movaps [rdx], xmm1
00007ac9d05d498a  movaps [rcx], xmm13
00007ac9d05d498e  mov rax, 0x569AF9F93A50
00007ac9d05d4998  call rax
00007ac9d05d499a  movaps xmm10, [rsp]
00007ac9d05d499f  add rsp, 0x40
00007ac9d05d49a3  vmovaps xmm0, [rsp]
00007ac9d05d49a8  vmovaps xmm1, [rsp+0x10]
00007ac9d05d49ae  vmovaps xmm2, [rsp+0x20]
00007ac9d05d49b4  vmovaps xmm3, [rsp+0x30]
00007ac9d05d49ba  vmovaps xmm4, [rsp+0x40]
00007ac9d05d49c0  vmovaps xmm5, [rsp+0x50]
00007ac9d05d49c6  vmovaps xmm6, [rsp+0x60]
00007ac9d05d49cc  vmovaps xmm7, [rsp+0x70]
00007ac9d05d49d2  vmovaps xmm8, [rsp+0x80]
00007ac9d05d49db  vmovaps xmm9, [rsp+0x90]
00007ac9d05d49e4  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d49ed  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d49f6  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d49ff  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d4a08  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d4a11  add rsp, 0xF0
00007ac9d05d4a18  pop r11
00007ac9d05d4a1a  pop r10
00007ac9d05d4a1c  pop r9
00007ac9d05d4a1e  pop r8
00007ac9d05d4a20  pop rsi
00007ac9d05d4a21  pop rdi
00007ac9d05d4a22  pop rdx
00007ac9d05d4a23  pop rcx
00007ac9d05d4a24  pop rax
00007ac9d05d4a25  add rsp, 0x08
00007ac9d05d4a29  jmp 0x00007AC9D05D2E6D
00007ac9d05d4a2e  call 0x00007AC9D03FF430
00007ac9d05d4a33  jmp 0x00007AC9D05D2E8F
00007ac9d05d4a38  call 0x00007AC9D040E760
00007ac9d05d4a3d  jmp 0x00007AC9D05D2E99
00007ac9d05d4a42  sub rsp, 0x08
00007ac9d05d4a46  push rax
00007ac9d05d4a47  push rcx
00007ac9d05d4a48  push rdx
00007ac9d05d4a49  push rdi
00007ac9d05d4a4a  push rsi
00007ac9d05d4a4b  push r8
00007ac9d05d4a4d  push r9
00007ac9d05d4a4f  push r10
00007ac9d05d4a51  push r11
00007ac9d05d4a53  sub rsp, 0xF0
00007ac9d05d4a5a  vmovaps [rsp], xmm0
00007ac9d05d4a5f  vmovaps [rsp+0x10], xmm1
00007ac9d05d4a65  vmovaps [rsp+0x20], xmm2
00007ac9d05d4a6b  vmovaps [rsp+0x30], xmm3
00007ac9d05d4a71  vmovaps [rsp+0x40], xmm4
00007ac9d05d4a77  vmovaps [rsp+0x50], xmm5
00007ac9d05d4a7d  vmovaps [rsp+0x60], xmm6
00007ac9d05d4a83  vmovaps [rsp+0x70], xmm7
00007ac9d05d4a89  vmovaps [rsp+0x80], xmm9
00007ac9d05d4a92  vmovaps [rsp+0x90], xmm10
00007ac9d05d4a9b  vmovaps [rsp+0xA0], xmm11
00007ac9d05d4aa4  vmovaps [rsp+0xB0], xmm12
00007ac9d05d4aad  vmovaps [rsp+0xC0], xmm13
00007ac9d05d4ab6  vmovaps [rsp+0xD0], xmm14
00007ac9d05d4abf  vmovaps [rsp+0xE0], xmm15
00007ac9d05d4ac8  sub rsp, 0x40
00007ac9d05d4acc  lea rdi, [rsp]
00007ac9d05d4ad0  lea rsi, [rsp+0x10]
00007ac9d05d4ad5  lea rdx, [rsp+0x20]
00007ac9d05d4ada  lea rcx, [rsp+0x30]
00007ac9d05d4adf  mov r8d, 0x00
00007ac9d05d4ae5  lea r9, [r15+0x3A8]
00007ac9d05d4aec  movaps [rdi], xmm8
00007ac9d05d4af0  movaps [rsi], xmm5
00007ac9d05d4af3  movaps [rdx], xmm9
00007ac9d05d4af7  movaps [rcx], xmm13
00007ac9d05d4afb  mov rax, 0x569AF9F93A50
00007ac9d05d4b05  call rax
00007ac9d05d4b07  movaps xmm8, [rsp]
00007ac9d05d4b0c  add rsp, 0x40
00007ac9d05d4b10  vmovaps xmm0, [rsp]
00007ac9d05d4b15  vmovaps xmm1, [rsp+0x10]
00007ac9d05d4b1b  vmovaps xmm2, [rsp+0x20]
00007ac9d05d4b21  vmovaps xmm3, [rsp+0x30]
00007ac9d05d4b27  vmovaps xmm4, [rsp+0x40]
00007ac9d05d4b2d  vmovaps xmm5, [rsp+0x50]
00007ac9d05d4b33  vmovaps xmm6, [rsp+0x60]
00007ac9d05d4b39  vmovaps xmm7, [rsp+0x70]
00007ac9d05d4b3f  vmovaps xmm9, [rsp+0x80]
00007ac9d05d4b48  vmovaps xmm10, [rsp+0x90]
00007ac9d05d4b51  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d4b5a  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d4b63  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d4b6c  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d4b75  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d4b7e  add rsp, 0xF0
00007ac9d05d4b85  pop r11
00007ac9d05d4b87  pop r10
00007ac9d05d4b89  pop r9
00007ac9d05d4b8b  pop r8
00007ac9d05d4b8d  pop rsi
00007ac9d05d4b8e  pop rdi
00007ac9d05d4b8f  pop rdx
00007ac9d05d4b90  pop rcx
00007ac9d05d4b91  pop rax
00007ac9d05d4b92  add rsp, 0x08
00007ac9d05d4b96  jmp 0x00007AC9D05D2ED8
00007ac9d05d4b9b  sub rsp, 0x08
00007ac9d05d4b9f  push rax
00007ac9d05d4ba0  push rcx
00007ac9d05d4ba1  push rdx
00007ac9d05d4ba2  push rdi
00007ac9d05d4ba3  push rsi
00007ac9d05d4ba4  push r8
00007ac9d05d4ba6  push r9
00007ac9d05d4ba8  push r10
00007ac9d05d4baa  push r11
00007ac9d05d4bac  sub rsp, 0xF0
00007ac9d05d4bb3  vmovaps [rsp], xmm0
00007ac9d05d4bb8  vmovaps [rsp+0x10], xmm1
00007ac9d05d4bbe  vmovaps [rsp+0x20], xmm2
00007ac9d05d4bc4  vmovaps [rsp+0x30], xmm3
00007ac9d05d4bca  vmovaps [rsp+0x40], xmm4
00007ac9d05d4bd0  vmovaps [rsp+0x50], xmm5
00007ac9d05d4bd6  vmovaps [rsp+0x60], xmm6
00007ac9d05d4bdc  vmovaps [rsp+0x70], xmm7
00007ac9d05d4be2  vmovaps [rsp+0x80], xmm8
00007ac9d05d4beb  vmovaps [rsp+0x90], xmm10
00007ac9d05d4bf4  vmovaps [rsp+0xA0], xmm11
00007ac9d05d4bfd  vmovaps [rsp+0xB0], xmm12
00007ac9d05d4c06  vmovaps [rsp+0xC0], xmm13
00007ac9d05d4c0f  vmovaps [rsp+0xD0], xmm14
00007ac9d05d4c18  vmovaps [rsp+0xE0], xmm15
00007ac9d05d4c21  sub rsp, 0x40
00007ac9d05d4c25  lea rdi, [rsp]
00007ac9d05d4c29  lea rsi, [rsp+0x10]
00007ac9d05d4c2e  lea rdx, [rsp+0x20]
00007ac9d05d4c33  lea rcx, [rsp+0x30]
00007ac9d05d4c38  mov r8d, 0x00
00007ac9d05d4c3e  lea r9, [r15+0x3A8]
00007ac9d05d4c45  movaps [rdi], xmm9
00007ac9d05d4c49  movaps [rsi], xmm12
00007ac9d05d4c4d  movaps [rdx], xmm7
00007ac9d05d4c50  movaps [rcx], xmm13
00007ac9d05d4c54  mov rax, 0x569AF9F93A50
00007ac9d05d4c5e  call rax
00007ac9d05d4c60  movaps xmm9, [rsp]
00007ac9d05d4c65  add rsp, 0x40
00007ac9d05d4c69  vmovaps xmm0, [rsp]
00007ac9d05d4c6e  vmovaps xmm1, [rsp+0x10]
00007ac9d05d4c74  vmovaps xmm2, [rsp+0x20]
00007ac9d05d4c7a  vmovaps xmm3, [rsp+0x30]
00007ac9d05d4c80  vmovaps xmm4, [rsp+0x40]
00007ac9d05d4c86  vmovaps xmm5, [rsp+0x50]
00007ac9d05d4c8c  vmovaps xmm6, [rsp+0x60]
00007ac9d05d4c92  vmovaps xmm7, [rsp+0x70]
00007ac9d05d4c98  vmovaps xmm8, [rsp+0x80]
00007ac9d05d4ca1  vmovaps xmm10, [rsp+0x90]
00007ac9d05d4caa  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d4cb3  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d4cbc  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d4cc5  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d4cce  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d4cd7  add rsp, 0xF0
00007ac9d05d4cde  pop r11
00007ac9d05d4ce0  pop r10
00007ac9d05d4ce2  pop r9
00007ac9d05d4ce4  pop r8
00007ac9d05d4ce6  pop rsi
00007ac9d05d4ce7  pop rdi
00007ac9d05d4ce8  pop rdx
00007ac9d05d4ce9  pop rcx
00007ac9d05d4cea  pop rax
00007ac9d05d4ceb  add rsp, 0x08
00007ac9d05d4cef  jmp 0x00007AC9D05D2F01
00007ac9d05d4cf4  sub rsp, 0x08
00007ac9d05d4cf8  push rax
00007ac9d05d4cf9  push rcx
00007ac9d05d4cfa  push rdx
00007ac9d05d4cfb  push rdi
00007ac9d05d4cfc  push rsi
00007ac9d05d4cfd  push r8
00007ac9d05d4cff  push r9
00007ac9d05d4d01  push r10
00007ac9d05d4d03  push r11
00007ac9d05d4d05  sub rsp, 0xF0
00007ac9d05d4d0c  vmovaps [rsp], xmm0
00007ac9d05d4d11  vmovaps [rsp+0x10], xmm1
00007ac9d05d4d17  vmovaps [rsp+0x20], xmm2
00007ac9d05d4d1d  vmovaps [rsp+0x30], xmm3
00007ac9d05d4d23  vmovaps [rsp+0x40], xmm4
00007ac9d05d4d29  vmovaps [rsp+0x50], xmm5
00007ac9d05d4d2f  vmovaps [rsp+0x60], xmm6
00007ac9d05d4d35  vmovaps [rsp+0x70], xmm7
00007ac9d05d4d3b  vmovaps [rsp+0x80], xmm8
00007ac9d05d4d44  vmovaps [rsp+0x90], xmm9
00007ac9d05d4d4d  vmovaps [rsp+0xA0], xmm10
00007ac9d05d4d56  vmovaps [rsp+0xB0], xmm11
00007ac9d05d4d5f  vmovaps [rsp+0xC0], xmm13
00007ac9d05d4d68  vmovaps [rsp+0xD0], xmm14
00007ac9d05d4d71  vmovaps [rsp+0xE0], xmm15
00007ac9d05d4d7a  sub rsp, 0x40
00007ac9d05d4d7e  lea rdi, [rsp]
00007ac9d05d4d82  lea rsi, [rsp+0x10]
00007ac9d05d4d87  lea rdx, [rsp+0x20]
00007ac9d05d4d8c  lea rcx, [rsp+0x30]
00007ac9d05d4d91  mov r8d, 0x00
00007ac9d05d4d97  lea r9, [r15+0x3A8]
00007ac9d05d4d9e  movaps [rdi], xmm12
00007ac9d05d4da2  movaps [rsi], xmm11
00007ac9d05d4da6  movaps [rdx], xmm6
00007ac9d05d4da9  movaps [rcx], xmm13
00007ac9d05d4dad  mov rax, 0x569AF9F93A50
00007ac9d05d4db7  call rax
00007ac9d05d4db9  movaps xmm12, [rsp]
00007ac9d05d4dbe  add rsp, 0x40
00007ac9d05d4dc2  vmovaps xmm0, [rsp]
00007ac9d05d4dc7  vmovaps xmm1, [rsp+0x10]
00007ac9d05d4dcd  vmovaps xmm2, [rsp+0x20]
00007ac9d05d4dd3  vmovaps xmm3, [rsp+0x30]
00007ac9d05d4dd9  vmovaps xmm4, [rsp+0x40]
00007ac9d05d4ddf  vmovaps xmm5, [rsp+0x50]
00007ac9d05d4de5  vmovaps xmm6, [rsp+0x60]
00007ac9d05d4deb  vmovaps xmm7, [rsp+0x70]
00007ac9d05d4df1  vmovaps xmm8, [rsp+0x80]
00007ac9d05d4dfa  vmovaps xmm9, [rsp+0x90]
00007ac9d05d4e03  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d4e0c  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d4e15  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d4e1e  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d4e27  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d4e30  add rsp, 0xF0
00007ac9d05d4e37  pop r11
00007ac9d05d4e39  pop r10
00007ac9d05d4e3b  pop r9
00007ac9d05d4e3d  pop r8
00007ac9d05d4e3f  pop rsi
00007ac9d05d4e40  pop rdi
00007ac9d05d4e41  pop rdx
00007ac9d05d4e42  pop rcx
00007ac9d05d4e43  pop rax
00007ac9d05d4e44  add rsp, 0x08
00007ac9d05d4e48  jmp 0x00007AC9D05D2F2A
00007ac9d05d4e4d  sub rsp, 0x08
00007ac9d05d4e51  push rax
00007ac9d05d4e52  push rcx
00007ac9d05d4e53  push rdx
00007ac9d05d4e54  push rdi
00007ac9d05d4e55  push rsi
00007ac9d05d4e56  push r8
00007ac9d05d4e58  push r9
00007ac9d05d4e5a  push r10
00007ac9d05d4e5c  push r11
00007ac9d05d4e5e  sub rsp, 0xF0
00007ac9d05d4e65  vmovaps [rsp], xmm0
00007ac9d05d4e6a  vmovaps [rsp+0x10], xmm1
00007ac9d05d4e70  vmovaps [rsp+0x20], xmm2
00007ac9d05d4e76  vmovaps [rsp+0x30], xmm3
00007ac9d05d4e7c  vmovaps [rsp+0x40], xmm4
00007ac9d05d4e82  vmovaps [rsp+0x50], xmm5
00007ac9d05d4e88  vmovaps [rsp+0x60], xmm6
00007ac9d05d4e8e  vmovaps [rsp+0x70], xmm8
00007ac9d05d4e94  vmovaps [rsp+0x80], xmm9
00007ac9d05d4e9d  vmovaps [rsp+0x90], xmm10
00007ac9d05d4ea6  vmovaps [rsp+0xA0], xmm11
00007ac9d05d4eaf  vmovaps [rsp+0xB0], xmm12
00007ac9d05d4eb8  vmovaps [rsp+0xC0], xmm13
00007ac9d05d4ec1  vmovaps [rsp+0xD0], xmm14
00007ac9d05d4eca  vmovaps [rsp+0xE0], xmm15
00007ac9d05d4ed3  sub rsp, 0x40
00007ac9d05d4ed7  lea rdi, [rsp]
00007ac9d05d4edb  lea rsi, [rsp+0x10]
00007ac9d05d4ee0  lea rdx, [rsp+0x20]
00007ac9d05d4ee5  lea rcx, [rsp+0x30]
00007ac9d05d4eea  mov r8d, 0x00
00007ac9d05d4ef0  lea r9, [r15+0x3A8]
00007ac9d05d4ef7  movaps [rdi], xmm7
00007ac9d05d4efa  movaps [rsi], xmm10
00007ac9d05d4efe  movaps [rdx], xmm11
00007ac9d05d4f02  movaps [rcx], xmm13
00007ac9d05d4f06  mov rax, 0x569AF9F93A50
00007ac9d05d4f10  call rax
00007ac9d05d4f12  movaps xmm7, [rsp]
00007ac9d05d4f16  add rsp, 0x40
00007ac9d05d4f1a  vmovaps xmm0, [rsp]
00007ac9d05d4f1f  vmovaps xmm1, [rsp+0x10]
00007ac9d05d4f25  vmovaps xmm2, [rsp+0x20]
00007ac9d05d4f2b  vmovaps xmm3, [rsp+0x30]
00007ac9d05d4f31  vmovaps xmm4, [rsp+0x40]
00007ac9d05d4f37  vmovaps xmm5, [rsp+0x50]
00007ac9d05d4f3d  vmovaps xmm6, [rsp+0x60]
00007ac9d05d4f43  vmovaps xmm8, [rsp+0x70]
00007ac9d05d4f49  vmovaps xmm9, [rsp+0x80]
00007ac9d05d4f52  vmovaps xmm10, [rsp+0x90]
00007ac9d05d4f5b  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d4f64  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d4f6d  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d4f76  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d4f7f  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d4f88  add rsp, 0xF0
00007ac9d05d4f8f  pop r11
00007ac9d05d4f91  pop r10
00007ac9d05d4f93  pop r9
00007ac9d05d4f95  pop r8
00007ac9d05d4f97  pop rsi
00007ac9d05d4f98  pop rdi
00007ac9d05d4f99  pop rdx
00007ac9d05d4f9a  pop rcx
00007ac9d05d4f9b  pop rax
00007ac9d05d4f9c  add rsp, 0x08
00007ac9d05d4fa0  jmp 0x00007AC9D05D2F58
00007ac9d05d4fa5  call 0x00007AC9D040C260
00007ac9d05d4faa  jmp 0x00007AC9D05D2F62
00007ac9d05d4faf  call 0x00007AC9D0409D70
00007ac9d05d4fb4  jmp 0x00007AC9D05D2F6C
00007ac9d05d4fb9  sub rsp, 0x08
00007ac9d05d4fbd  push rax
00007ac9d05d4fbe  push rcx
00007ac9d05d4fbf  push rdx
00007ac9d05d4fc0  push rdi
00007ac9d05d4fc1  push rsi
00007ac9d05d4fc2  push r8
00007ac9d05d4fc4  push r9
00007ac9d05d4fc6  push r10
00007ac9d05d4fc8  push r11
00007ac9d05d4fca  sub rsp, 0xF0
00007ac9d05d4fd1  vmovaps [rsp], xmm0
00007ac9d05d4fd6  vmovaps [rsp+0x10], xmm1
00007ac9d05d4fdc  vmovaps [rsp+0x20], xmm2
00007ac9d05d4fe2  vmovaps [rsp+0x30], xmm3
00007ac9d05d4fe8  vmovaps [rsp+0x40], xmm4
00007ac9d05d4fee  vmovaps [rsp+0x50], xmm5
00007ac9d05d4ff4  vmovaps [rsp+0x60], xmm7
00007ac9d05d4ffa  vmovaps [rsp+0x70], xmm8
00007ac9d05d5000  vmovaps [rsp+0x80], xmm9
00007ac9d05d5009  vmovaps [rsp+0x90], xmm10
00007ac9d05d5012  vmovaps [rsp+0xA0], xmm11
00007ac9d05d501b  vmovaps [rsp+0xB0], xmm12
00007ac9d05d5024  vmovaps [rsp+0xC0], xmm13
00007ac9d05d502d  vmovaps [rsp+0xD0], xmm14
00007ac9d05d5036  vmovaps [rsp+0xE0], xmm15
00007ac9d05d503f  sub rsp, 0x40
00007ac9d05d5043  lea rdi, [rsp]
00007ac9d05d5047  lea rsi, [rsp+0x10]
00007ac9d05d504c  lea rdx, [rsp+0x20]
00007ac9d05d5051  lea rcx, [rsp+0x30]
00007ac9d05d5056  mov r8d, 0x00
00007ac9d05d505c  lea r9, [r15+0x3A8]
00007ac9d05d5063  movaps [rdi], xmm6
00007ac9d05d5066  movaps [rsi], xmm8
00007ac9d05d506a  movaps [rdx], xmm15
00007ac9d05d506e  movaps [rcx], xmm10
00007ac9d05d5072  mov rax, 0x569AF9F93A50
00007ac9d05d507c  call rax
00007ac9d05d507e  movaps xmm6, [rsp]
00007ac9d05d5082  add rsp, 0x40
00007ac9d05d5086  vmovaps xmm0, [rsp]
00007ac9d05d508b  vmovaps xmm1, [rsp+0x10]
00007ac9d05d5091  vmovaps xmm2, [rsp+0x20]
00007ac9d05d5097  vmovaps xmm3, [rsp+0x30]
00007ac9d05d509d  vmovaps xmm4, [rsp+0x40]
00007ac9d05d50a3  vmovaps xmm5, [rsp+0x50]
00007ac9d05d50a9  vmovaps xmm7, [rsp+0x60]
00007ac9d05d50af  vmovaps xmm8, [rsp+0x70]
00007ac9d05d50b5  vmovaps xmm9, [rsp+0x80]
00007ac9d05d50be  vmovaps xmm10, [rsp+0x90]
00007ac9d05d50c7  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d50d0  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d50d9  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d50e2  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d50eb  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d50f4  add rsp, 0xF0
00007ac9d05d50fb  pop r11
00007ac9d05d50fd  pop r10
00007ac9d05d50ff  pop r9
00007ac9d05d5101  pop r8
00007ac9d05d5103  pop rsi
00007ac9d05d5104  pop rdi
00007ac9d05d5105  pop rdx
00007ac9d05d5106  pop rcx
00007ac9d05d5107  pop rax
00007ac9d05d5108  add rsp, 0x08
00007ac9d05d510c  jmp 0x00007AC9D05D2FA4
00007ac9d05d5111  sub rsp, 0x08
00007ac9d05d5115  push rax
00007ac9d05d5116  push rcx
00007ac9d05d5117  push rdx
00007ac9d05d5118  push rdi
00007ac9d05d5119  push rsi
00007ac9d05d511a  push r8
00007ac9d05d511c  push r9
00007ac9d05d511e  push r10
00007ac9d05d5120  push r11
00007ac9d05d5122  sub rsp, 0xF0
00007ac9d05d5129  vmovaps [rsp], xmm0
00007ac9d05d512e  vmovaps [rsp+0x10], xmm1
00007ac9d05d5134  vmovaps [rsp+0x20], xmm2
00007ac9d05d513a  vmovaps [rsp+0x30], xmm3
00007ac9d05d5140  vmovaps [rsp+0x40], xmm4
00007ac9d05d5146  vmovaps [rsp+0x50], xmm5
00007ac9d05d514c  vmovaps [rsp+0x60], xmm6
00007ac9d05d5152  vmovaps [rsp+0x70], xmm7
00007ac9d05d5158  vmovaps [rsp+0x80], xmm8
00007ac9d05d5161  vmovaps [rsp+0x90], xmm9
00007ac9d05d516a  vmovaps [rsp+0xA0], xmm11
00007ac9d05d5173  vmovaps [rsp+0xB0], xmm12
00007ac9d05d517c  vmovaps [rsp+0xC0], xmm13
00007ac9d05d5185  vmovaps [rsp+0xD0], xmm14
00007ac9d05d518e  vmovaps [rsp+0xE0], xmm15
00007ac9d05d5197  sub rsp, 0x40
00007ac9d05d519b  lea rdi, [rsp]
00007ac9d05d519f  lea rsi, [rsp+0x10]
00007ac9d05d51a4  lea rdx, [rsp+0x20]
00007ac9d05d51a9  lea rcx, [rsp+0x30]
00007ac9d05d51ae  mov r8d, 0x00
00007ac9d05d51b4  lea r9, [r15+0x3A8]
00007ac9d05d51bb  movaps [rdi], xmm10
00007ac9d05d51bf  movaps [rsi], xmm9
00007ac9d05d51c3  movaps [rdx], xmm13
00007ac9d05d51c7  movaps [rcx], xmm15
00007ac9d05d51cb  mov rax, 0x569AF9F93A50
00007ac9d05d51d5  call rax
00007ac9d05d51d7  movaps xmm10, [rsp]
00007ac9d05d51dc  add rsp, 0x40
00007ac9d05d51e0  vmovaps xmm0, [rsp]
00007ac9d05d51e5  vmovaps xmm1, [rsp+0x10]
00007ac9d05d51eb  vmovaps xmm2, [rsp+0x20]
00007ac9d05d51f1  vmovaps xmm3, [rsp+0x30]
00007ac9d05d51f7  vmovaps xmm4, [rsp+0x40]
00007ac9d05d51fd  vmovaps xmm5, [rsp+0x50]
00007ac9d05d5203  vmovaps xmm6, [rsp+0x60]
00007ac9d05d5209  vmovaps xmm7, [rsp+0x70]
00007ac9d05d520f  vmovaps xmm8, [rsp+0x80]
00007ac9d05d5218  vmovaps xmm9, [rsp+0x90]
00007ac9d05d5221  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d522a  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d5233  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d523c  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d5245  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d524e  add rsp, 0xF0
00007ac9d05d5255  pop r11
00007ac9d05d5257  pop r10
00007ac9d05d5259  pop r9
00007ac9d05d525b  pop r8
00007ac9d05d525d  pop rsi
00007ac9d05d525e  pop rdi
00007ac9d05d525f  pop rdx
00007ac9d05d5260  pop rcx
00007ac9d05d5261  pop rax
00007ac9d05d5262  add rsp, 0x08
00007ac9d05d5266  jmp 0x00007AC9D05D2FCD
00007ac9d05d526b  sub rsp, 0x08
00007ac9d05d526f  push rax
00007ac9d05d5270  push rcx
00007ac9d05d5271  push rdx
00007ac9d05d5272  push rdi
00007ac9d05d5273  push rsi
00007ac9d05d5274  push r8
00007ac9d05d5276  push r9
00007ac9d05d5278  push r10
00007ac9d05d527a  push r11
00007ac9d05d527c  sub rsp, 0xF0
00007ac9d05d5283  vmovaps [rsp], xmm0
00007ac9d05d5288  vmovaps [rsp+0x10], xmm1
00007ac9d05d528e  vmovaps [rsp+0x20], xmm2
00007ac9d05d5294  vmovaps [rsp+0x30], xmm3
00007ac9d05d529a  vmovaps [rsp+0x40], xmm4
00007ac9d05d52a0  vmovaps [rsp+0x50], xmm5
00007ac9d05d52a6  vmovaps [rsp+0x60], xmm6
00007ac9d05d52ac  vmovaps [rsp+0x70], xmm7
00007ac9d05d52b2  vmovaps [rsp+0x80], xmm8
00007ac9d05d52bb  vmovaps [rsp+0x90], xmm9
00007ac9d05d52c4  vmovaps [rsp+0xA0], xmm10
00007ac9d05d52cd  vmovaps [rsp+0xB0], xmm11
00007ac9d05d52d6  vmovaps [rsp+0xC0], xmm12
00007ac9d05d52df  vmovaps [rsp+0xD0], xmm14
00007ac9d05d52e8  vmovaps [rsp+0xE0], xmm15
00007ac9d05d52f1  sub rsp, 0x40
00007ac9d05d52f5  lea rdi, [rsp]
00007ac9d05d52f9  lea rsi, [rsp+0x10]
00007ac9d05d52fe  lea rdx, [rsp+0x20]
00007ac9d05d5303  lea rcx, [rsp+0x30]
00007ac9d05d5308  mov r8d, 0x00
00007ac9d05d530e  lea r9, [r15+0x3A8]
00007ac9d05d5315  movaps [rdi], xmm13
00007ac9d05d5319  movaps [rsi], xmm12
00007ac9d05d531d  movaps [rdx], xmm4
00007ac9d05d5320  movaps [rcx], xmm15
00007ac9d05d5324  mov rax, 0x569AF9F93A50
00007ac9d05d532e  call rax
00007ac9d05d5330  movaps xmm13, [rsp]
00007ac9d05d5335  add rsp, 0x40
00007ac9d05d5339  vmovaps xmm0, [rsp]
00007ac9d05d533e  vmovaps xmm1, [rsp+0x10]
00007ac9d05d5344  vmovaps xmm2, [rsp+0x20]
00007ac9d05d534a  vmovaps xmm3, [rsp+0x30]
00007ac9d05d5350  vmovaps xmm4, [rsp+0x40]
00007ac9d05d5356  vmovaps xmm5, [rsp+0x50]
00007ac9d05d535c  vmovaps xmm6, [rsp+0x60]
00007ac9d05d5362  vmovaps xmm7, [rsp+0x70]
00007ac9d05d5368  vmovaps xmm8, [rsp+0x80]
00007ac9d05d5371  vmovaps xmm9, [rsp+0x90]
00007ac9d05d537a  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d5383  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d538c  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d5395  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d539e  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d53a7  add rsp, 0xF0
00007ac9d05d53ae  pop r11
00007ac9d05d53b0  pop r10
00007ac9d05d53b2  pop r9
00007ac9d05d53b4  pop r8
00007ac9d05d53b6  pop rsi
00007ac9d05d53b7  pop rdi
00007ac9d05d53b8  pop rdx
00007ac9d05d53b9  pop rcx
00007ac9d05d53ba  pop rax
00007ac9d05d53bb  add rsp, 0x08
00007ac9d05d53bf  jmp 0x00007AC9D05D2FF6
00007ac9d05d53c4  sub rsp, 0x08
00007ac9d05d53c8  push rax
00007ac9d05d53c9  push rcx
00007ac9d05d53ca  push rdx
00007ac9d05d53cb  push rdi
00007ac9d05d53cc  push rsi
00007ac9d05d53cd  push r8
00007ac9d05d53cf  push r9
00007ac9d05d53d1  push r10
00007ac9d05d53d3  push r11
00007ac9d05d53d5  sub rsp, 0xF0
00007ac9d05d53dc  vmovaps [rsp], xmm0
00007ac9d05d53e1  vmovaps [rsp+0x10], xmm1
00007ac9d05d53e7  vmovaps [rsp+0x20], xmm2
00007ac9d05d53ed  vmovaps [rsp+0x30], xmm3
00007ac9d05d53f3  vmovaps [rsp+0x40], xmm4
00007ac9d05d53f9  vmovaps [rsp+0x50], xmm5
00007ac9d05d53ff  vmovaps [rsp+0x60], xmm6
00007ac9d05d5405  vmovaps [rsp+0x70], xmm7
00007ac9d05d540b  vmovaps [rsp+0x80], xmm8
00007ac9d05d5414  vmovaps [rsp+0x90], xmm9
00007ac9d05d541d  vmovaps [rsp+0xA0], xmm10
00007ac9d05d5426  vmovaps [rsp+0xB0], xmm11
00007ac9d05d542f  vmovaps [rsp+0xC0], xmm13
00007ac9d05d5438  vmovaps [rsp+0xD0], xmm14
00007ac9d05d5441  vmovaps [rsp+0xE0], xmm15
00007ac9d05d544a  sub rsp, 0x40
00007ac9d05d544e  lea rdi, [rsp]
00007ac9d05d5452  lea rsi, [rsp+0x10]
00007ac9d05d5457  lea rdx, [rsp+0x20]
00007ac9d05d545c  lea rcx, [rsp+0x30]
00007ac9d05d5461  mov r8d, 0x00
00007ac9d05d5467  lea r9, [r15+0x3A8]
00007ac9d05d546e  movaps [rdi], xmm12
00007ac9d05d5472  movaps [rsi], xmm7
00007ac9d05d5475  movaps [rdx], xmm1
00007ac9d05d5478  movaps [rcx], xmm15
00007ac9d05d547c  mov rax, 0x569AF9F93A50
00007ac9d05d5486  call rax
00007ac9d05d5488  movaps xmm12, [rsp]
00007ac9d05d548d  add rsp, 0x40
00007ac9d05d5491  vmovaps xmm0, [rsp]
00007ac9d05d5496  vmovaps xmm1, [rsp+0x10]
00007ac9d05d549c  vmovaps xmm2, [rsp+0x20]
00007ac9d05d54a2  vmovaps xmm3, [rsp+0x30]
00007ac9d05d54a8  vmovaps xmm4, [rsp+0x40]
00007ac9d05d54ae  vmovaps xmm5, [rsp+0x50]
00007ac9d05d54b4  vmovaps xmm6, [rsp+0x60]
00007ac9d05d54ba  vmovaps xmm7, [rsp+0x70]
00007ac9d05d54c0  vmovaps xmm8, [rsp+0x80]
00007ac9d05d54c9  vmovaps xmm9, [rsp+0x90]
00007ac9d05d54d2  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d54db  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d54e4  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d54ed  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d54f6  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d54ff  add rsp, 0xF0
00007ac9d05d5506  pop r11
00007ac9d05d5508  pop r10
00007ac9d05d550a  pop r9
00007ac9d05d550c  pop r8
00007ac9d05d550e  pop rsi
00007ac9d05d550f  pop rdi
00007ac9d05d5510  pop rdx
00007ac9d05d5511  pop rcx
00007ac9d05d5512  pop rax
00007ac9d05d5513  add rsp, 0x08
00007ac9d05d5517  jmp 0x00007AC9D05D301F
00007ac9d05d551c  call 0x00007AC9D03FF430
00007ac9d05d5521  jmp 0x00007AC9D05D3029
00007ac9d05d5526  call 0x00007AC9D040E760
00007ac9d05d552b  jmp 0x00007AC9D05D3033
00007ac9d05d5530  sub rsp, 0x08
00007ac9d05d5534  push rax
00007ac9d05d5535  push rcx
00007ac9d05d5536  push rdx
00007ac9d05d5537  push rdi
00007ac9d05d5538  push rsi
00007ac9d05d5539  push r8
00007ac9d05d553b  push r9
00007ac9d05d553d  push r10
00007ac9d05d553f  push r11
00007ac9d05d5541  sub rsp, 0xF0
00007ac9d05d5548  vmovaps [rsp], xmm0
00007ac9d05d554d  vmovaps [rsp+0x10], xmm1
00007ac9d05d5553  vmovaps [rsp+0x20], xmm2
00007ac9d05d5559  vmovaps [rsp+0x30], xmm3
00007ac9d05d555f  vmovaps [rsp+0x40], xmm4
00007ac9d05d5565  vmovaps [rsp+0x50], xmm5
00007ac9d05d556b  vmovaps [rsp+0x60], xmm6
00007ac9d05d5571  vmovaps [rsp+0x70], xmm8
00007ac9d05d5577  vmovaps [rsp+0x80], xmm9
00007ac9d05d5580  vmovaps [rsp+0x90], xmm10
00007ac9d05d5589  vmovaps [rsp+0xA0], xmm11
00007ac9d05d5592  vmovaps [rsp+0xB0], xmm12
00007ac9d05d559b  vmovaps [rsp+0xC0], xmm13
00007ac9d05d55a4  vmovaps [rsp+0xD0], xmm14
00007ac9d05d55ad  vmovaps [rsp+0xE0], xmm15
00007ac9d05d55b6  sub rsp, 0x40
00007ac9d05d55ba  lea rdi, [rsp]
00007ac9d05d55be  lea rsi, [rsp+0x10]
00007ac9d05d55c3  lea rdx, [rsp+0x20]
00007ac9d05d55c8  lea rcx, [rsp+0x30]
00007ac9d05d55cd  mov r8d, 0x00
00007ac9d05d55d3  lea r9, [r15+0x3A8]
00007ac9d05d55da  movaps [rdi], xmm7
00007ac9d05d55dd  movaps [rsi], xmm6
00007ac9d05d55e0  movaps [rdx], xmm8
00007ac9d05d55e4  movaps [rcx], xmm9
00007ac9d05d55e8  mov rax, 0x569AF9F93A50
00007ac9d05d55f2  call rax
00007ac9d05d55f4  movaps xmm7, [rsp]
00007ac9d05d55f8  add rsp, 0x40
00007ac9d05d55fc  vmovaps xmm0, [rsp]
00007ac9d05d5601  vmovaps xmm1, [rsp+0x10]
00007ac9d05d5607  vmovaps xmm2, [rsp+0x20]
00007ac9d05d560d  vmovaps xmm3, [rsp+0x30]
00007ac9d05d5613  vmovaps xmm4, [rsp+0x40]
00007ac9d05d5619  vmovaps xmm5, [rsp+0x50]
00007ac9d05d561f  vmovaps xmm6, [rsp+0x60]
00007ac9d05d5625  vmovaps xmm8, [rsp+0x70]
00007ac9d05d562b  vmovaps xmm9, [rsp+0x80]
00007ac9d05d5634  vmovaps xmm10, [rsp+0x90]
00007ac9d05d563d  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d5646  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d564f  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d5658  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d5661  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d566a  add rsp, 0xF0
00007ac9d05d5671  pop r11
00007ac9d05d5673  pop r10
00007ac9d05d5675  pop r9
00007ac9d05d5677  pop r8
00007ac9d05d5679  pop rsi
00007ac9d05d567a  pop rdi
00007ac9d05d567b  pop rdx
00007ac9d05d567c  pop rcx
00007ac9d05d567d  pop rax
00007ac9d05d567e  add rsp, 0x08
00007ac9d05d5682  jmp 0x00007AC9D05D305D
00007ac9d05d5687  sub rsp, 0x08
00007ac9d05d568b  push rax
00007ac9d05d568c  push rcx
00007ac9d05d568d  push rdx
00007ac9d05d568e  push rdi
00007ac9d05d568f  push rsi
00007ac9d05d5690  push r8
00007ac9d05d5692  push r9
00007ac9d05d5694  push r10
00007ac9d05d5696  push r11
00007ac9d05d5698  sub rsp, 0xF0
00007ac9d05d569f  vmovaps [rsp], xmm0
00007ac9d05d56a4  vmovaps [rsp+0x10], xmm1
00007ac9d05d56aa  vmovaps [rsp+0x20], xmm2
00007ac9d05d56b0  vmovaps [rsp+0x30], xmm3
00007ac9d05d56b6  vmovaps [rsp+0x40], xmm4
00007ac9d05d56bc  vmovaps [rsp+0x50], xmm5
00007ac9d05d56c2  vmovaps [rsp+0x60], xmm6
00007ac9d05d56c8  vmovaps [rsp+0x70], xmm7
00007ac9d05d56ce  vmovaps [rsp+0x80], xmm9
00007ac9d05d56d7  vmovaps [rsp+0x90], xmm10
00007ac9d05d56e0  vmovaps [rsp+0xA0], xmm11
00007ac9d05d56e9  vmovaps [rsp+0xB0], xmm12
00007ac9d05d56f2  vmovaps [rsp+0xC0], xmm13
00007ac9d05d56fb  vmovaps [rsp+0xD0], xmm14
00007ac9d05d5704  vmovaps [rsp+0xE0], xmm15
00007ac9d05d570d  sub rsp, 0x40
00007ac9d05d5711  lea rdi, [rsp]
00007ac9d05d5715  lea rsi, [rsp+0x10]
00007ac9d05d571a  lea rdx, [rsp+0x20]
00007ac9d05d571f  lea rcx, [rsp+0x30]
00007ac9d05d5724  mov r8d, 0x00
00007ac9d05d572a  lea r9, [r15+0x3A8]
00007ac9d05d5731  movaps [rdi], xmm8
00007ac9d05d5735  movaps [rsi], xmm10
00007ac9d05d5739  movaps [rdx], xmm14
00007ac9d05d573d  movaps [rcx], xmm9
00007ac9d05d5741  mov rax, 0x569AF9F93A50
00007ac9d05d574b  call rax
00007ac9d05d574d  movaps xmm8, [rsp]
00007ac9d05d5752  add rsp, 0x40
00007ac9d05d5756  vmovaps xmm0, [rsp]
00007ac9d05d575b  vmovaps xmm1, [rsp+0x10]
00007ac9d05d5761  vmovaps xmm2, [rsp+0x20]
00007ac9d05d5767  vmovaps xmm3, [rsp+0x30]
00007ac9d05d576d  vmovaps xmm4, [rsp+0x40]
00007ac9d05d5773  vmovaps xmm5, [rsp+0x50]
00007ac9d05d5779  vmovaps xmm6, [rsp+0x60]
00007ac9d05d577f  vmovaps xmm7, [rsp+0x70]
00007ac9d05d5785  vmovaps xmm9, [rsp+0x80]
00007ac9d05d578e  vmovaps xmm10, [rsp+0x90]
00007ac9d05d5797  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d57a0  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d57a9  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d57b2  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d57bb  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d57c4  add rsp, 0xF0
00007ac9d05d57cb  pop r11
00007ac9d05d57cd  pop r10
00007ac9d05d57cf  pop r9
00007ac9d05d57d1  pop r8
00007ac9d05d57d3  pop rsi
00007ac9d05d57d4  pop rdi
00007ac9d05d57d5  pop rdx
00007ac9d05d57d6  pop rcx
00007ac9d05d57d7  pop rax
00007ac9d05d57d8  add rsp, 0x08
00007ac9d05d57dc  jmp 0x00007AC9D05D3083
00007ac9d05d57e1  sub rsp, 0x08
00007ac9d05d57e5  push rax
00007ac9d05d57e6  push rcx
00007ac9d05d57e7  push rdx
00007ac9d05d57e8  push rdi
00007ac9d05d57e9  push rsi
00007ac9d05d57ea  push r8
00007ac9d05d57ec  push r9
00007ac9d05d57ee  push r10
00007ac9d05d57f0  push r11
00007ac9d05d57f2  sub rsp, 0xF0
00007ac9d05d57f9  vmovaps [rsp], xmm0
00007ac9d05d57fe  vmovaps [rsp+0x10], xmm1
00007ac9d05d5804  vmovaps [rsp+0x20], xmm2
00007ac9d05d580a  vmovaps [rsp+0x30], xmm3
00007ac9d05d5810  vmovaps [rsp+0x40], xmm4
00007ac9d05d5816  vmovaps [rsp+0x50], xmm5
00007ac9d05d581c  vmovaps [rsp+0x60], xmm6
00007ac9d05d5822  vmovaps [rsp+0x70], xmm7
00007ac9d05d5828  vmovaps [rsp+0x80], xmm8
00007ac9d05d5831  vmovaps [rsp+0x90], xmm9
00007ac9d05d583a  vmovaps [rsp+0xA0], xmm11
00007ac9d05d5843  vmovaps [rsp+0xB0], xmm12
00007ac9d05d584c  vmovaps [rsp+0xC0], xmm13
00007ac9d05d5855  vmovaps [rsp+0xD0], xmm14
00007ac9d05d585e  vmovaps [rsp+0xE0], xmm15
00007ac9d05d5867  sub rsp, 0x40
00007ac9d05d586b  lea rdi, [rsp]
00007ac9d05d586f  lea rsi, [rsp+0x10]
00007ac9d05d5874  lea rdx, [rsp+0x20]
00007ac9d05d5879  lea rcx, [rsp+0x30]
00007ac9d05d587e  mov r8d, 0x00
00007ac9d05d5884  lea r9, [r15+0x3A8]
00007ac9d05d588b  movaps [rdi], xmm10
00007ac9d05d588f  movaps [rsi], xmm13
00007ac9d05d5893  movaps [rdx], xmm11
00007ac9d05d5897  movaps [rcx], xmm14
00007ac9d05d589b  mov rax, 0x569AF9F93A50
00007ac9d05d58a5  call rax
00007ac9d05d58a7  movaps xmm10, [rsp]
00007ac9d05d58ac  add rsp, 0x40
00007ac9d05d58b0  vmovaps xmm0, [rsp]
00007ac9d05d58b5  vmovaps xmm1, [rsp+0x10]
00007ac9d05d58bb  vmovaps xmm2, [rsp+0x20]
00007ac9d05d58c1  vmovaps xmm3, [rsp+0x30]
00007ac9d05d58c7  vmovaps xmm4, [rsp+0x40]
00007ac9d05d58cd  vmovaps xmm5, [rsp+0x50]
00007ac9d05d58d3  vmovaps xmm6, [rsp+0x60]
00007ac9d05d58d9  vmovaps xmm7, [rsp+0x70]
00007ac9d05d58df  vmovaps xmm8, [rsp+0x80]
00007ac9d05d58e8  vmovaps xmm9, [rsp+0x90]
00007ac9d05d58f1  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d58fa  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d5903  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d590c  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d5915  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d591e  add rsp, 0xF0
00007ac9d05d5925  pop r11
00007ac9d05d5927  pop r10
00007ac9d05d5929  pop r9
00007ac9d05d592b  pop r8
00007ac9d05d592d  pop rsi
00007ac9d05d592e  pop rdi
00007ac9d05d592f  pop rdx
00007ac9d05d5930  pop rcx
00007ac9d05d5931  pop rax
00007ac9d05d5932  add rsp, 0x08
00007ac9d05d5936  jmp 0x00007AC9D05D30A9
00007ac9d05d593b  sub rsp, 0x08
00007ac9d05d593f  push rax
00007ac9d05d5940  push rcx
00007ac9d05d5941  push rdx
00007ac9d05d5942  push rdi
00007ac9d05d5943  push rsi
00007ac9d05d5944  push r8
00007ac9d05d5946  push r9
00007ac9d05d5948  push r10
00007ac9d05d594a  push r11
00007ac9d05d594c  sub rsp, 0xF0
00007ac9d05d5953  vmovaps [rsp], xmm0
00007ac9d05d5958  vmovaps [rsp+0x10], xmm1
00007ac9d05d595e  vmovaps [rsp+0x20], xmm2
00007ac9d05d5964  vmovaps [rsp+0x30], xmm3
00007ac9d05d596a  vmovaps [rsp+0x40], xmm4
00007ac9d05d5970  vmovaps [rsp+0x50], xmm5
00007ac9d05d5976  vmovaps [rsp+0x60], xmm6
00007ac9d05d597c  vmovaps [rsp+0x70], xmm7
00007ac9d05d5982  vmovaps [rsp+0x80], xmm8
00007ac9d05d598b  vmovaps [rsp+0x90], xmm9
00007ac9d05d5994  vmovaps [rsp+0xA0], xmm10
00007ac9d05d599d  vmovaps [rsp+0xB0], xmm11
00007ac9d05d59a6  vmovaps [rsp+0xC0], xmm12
00007ac9d05d59af  vmovaps [rsp+0xD0], xmm14
00007ac9d05d59b8  vmovaps [rsp+0xE0], xmm15
00007ac9d05d59c1  sub rsp, 0x40
00007ac9d05d59c5  lea rdi, [rsp]
00007ac9d05d59c9  lea rsi, [rsp+0x10]
00007ac9d05d59ce  lea rdx, [rsp+0x20]
00007ac9d05d59d3  lea rcx, [rsp+0x30]
00007ac9d05d59d8  mov r8d, 0x00
00007ac9d05d59de  lea r9, [r15+0x3A8]
00007ac9d05d59e5  movaps [rdi], xmm13
00007ac9d05d59e9  movaps [rsi], xmm12
00007ac9d05d59ed  movaps [rdx], xmm15
00007ac9d05d59f1  movaps [rcx], xmm14
00007ac9d05d59f5  mov rax, 0x569AF9F93A50
00007ac9d05d59ff  call rax
00007ac9d05d5a01  movaps xmm13, [rsp]
00007ac9d05d5a06  add rsp, 0x40
00007ac9d05d5a0a  vmovaps xmm0, [rsp]
00007ac9d05d5a0f  vmovaps xmm1, [rsp+0x10]
00007ac9d05d5a15  vmovaps xmm2, [rsp+0x20]
00007ac9d05d5a1b  vmovaps xmm3, [rsp+0x30]
00007ac9d05d5a21  vmovaps xmm4, [rsp+0x40]
00007ac9d05d5a27  vmovaps xmm5, [rsp+0x50]
00007ac9d05d5a2d  vmovaps xmm6, [rsp+0x60]
00007ac9d05d5a33  vmovaps xmm7, [rsp+0x70]
00007ac9d05d5a39  vmovaps xmm8, [rsp+0x80]
00007ac9d05d5a42  vmovaps xmm9, [rsp+0x90]
00007ac9d05d5a4b  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d5a54  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d5a5d  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d5a66  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d5a6f  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d5a78  add rsp, 0xF0
00007ac9d05d5a7f  pop r11
00007ac9d05d5a81  pop r10
00007ac9d05d5a83  pop r9
00007ac9d05d5a85  pop r8
00007ac9d05d5a87  pop rsi
00007ac9d05d5a88  pop rdi
00007ac9d05d5a89  pop rdx
00007ac9d05d5a8a  pop rcx
00007ac9d05d5a8b  pop rax
00007ac9d05d5a8c  add rsp, 0x08
00007ac9d05d5a90  jmp 0x00007AC9D05D30CF
00007ac9d05d5a95  call 0x00007AC9D040E760
00007ac9d05d5a9a  jmp 0x00007AC9D05D30DC
00007ac9d05d5a9f  call 0x00007AC9D040D4E0
00007ac9d05d5aa4  jmp 0x00007AC9D05D30E9
00007ac9d05d5aa9  sub rsp, 0x08
00007ac9d05d5aad  push rax
00007ac9d05d5aae  push rcx
00007ac9d05d5aaf  push rdx
00007ac9d05d5ab0  push rdi
00007ac9d05d5ab1  push rsi
00007ac9d05d5ab2  push r8
00007ac9d05d5ab4  push r9
00007ac9d05d5ab6  push r10
00007ac9d05d5ab8  push r11
00007ac9d05d5aba  sub rsp, 0xF0
00007ac9d05d5ac1  vmovaps [rsp], xmm0
00007ac9d05d5ac6  vmovaps [rsp+0x10], xmm1
00007ac9d05d5acc  vmovaps [rsp+0x20], xmm2
00007ac9d05d5ad2  vmovaps [rsp+0x30], xmm3
00007ac9d05d5ad8  vmovaps [rsp+0x40], xmm4
00007ac9d05d5ade  vmovaps [rsp+0x50], xmm5
00007ac9d05d5ae4  vmovaps [rsp+0x60], xmm6
00007ac9d05d5aea  vmovaps [rsp+0x70], xmm7
00007ac9d05d5af0  vmovaps [rsp+0x80], xmm8
00007ac9d05d5af9  vmovaps [rsp+0x90], xmm9
00007ac9d05d5b02  vmovaps [rsp+0xA0], xmm10
00007ac9d05d5b0b  vmovaps [rsp+0xB0], xmm12
00007ac9d05d5b14  vmovaps [rsp+0xC0], xmm13
00007ac9d05d5b1d  vmovaps [rsp+0xD0], xmm14
00007ac9d05d5b26  vmovaps [rsp+0xE0], xmm15
00007ac9d05d5b2f  sub rsp, 0x40
00007ac9d05d5b33  lea rdi, [rsp]
00007ac9d05d5b37  lea rsi, [rsp+0x10]
00007ac9d05d5b3c  lea rdx, [rsp+0x20]
00007ac9d05d5b41  lea rcx, [rsp+0x30]
00007ac9d05d5b46  mov r8d, 0x00
00007ac9d05d5b4c  lea r9, [r15+0x3A8]
00007ac9d05d5b53  movaps [rdi], xmm11
00007ac9d05d5b57  movaps [rsi], xmm7
00007ac9d05d5b5a  movaps [rdx], xmm1
00007ac9d05d5b5d  movaps [rcx], xmm12
00007ac9d05d5b61  mov rax, 0x569AF9F93A50
00007ac9d05d5b6b  call rax
00007ac9d05d5b6d  movaps xmm11, [rsp]
00007ac9d05d5b72  add rsp, 0x40
00007ac9d05d5b76  vmovaps xmm0, [rsp]
00007ac9d05d5b7b  vmovaps xmm1, [rsp+0x10]
00007ac9d05d5b81  vmovaps xmm2, [rsp+0x20]
00007ac9d05d5b87  vmovaps xmm3, [rsp+0x30]
00007ac9d05d5b8d  vmovaps xmm4, [rsp+0x40]
00007ac9d05d5b93  vmovaps xmm5, [rsp+0x50]
00007ac9d05d5b99  vmovaps xmm6, [rsp+0x60]
00007ac9d05d5b9f  vmovaps xmm7, [rsp+0x70]
00007ac9d05d5ba5  vmovaps xmm8, [rsp+0x80]
00007ac9d05d5bae  vmovaps xmm9, [rsp+0x90]
00007ac9d05d5bb7  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d5bc0  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d5bc9  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d5bd2  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d5bdb  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d5be4  add rsp, 0xF0
00007ac9d05d5beb  pop r11
00007ac9d05d5bed  pop r10
00007ac9d05d5bef  pop r9
00007ac9d05d5bf1  pop r8
00007ac9d05d5bf3  pop rsi
00007ac9d05d5bf4  pop rdi
00007ac9d05d5bf5  pop rdx
00007ac9d05d5bf6  pop rcx
00007ac9d05d5bf7  pop rax
00007ac9d05d5bf8  add rsp, 0x08
00007ac9d05d5bfc  jmp 0x00007AC9D05D3122
00007ac9d05d5c01  call 0x00007AC9D03FF430
00007ac9d05d5c06  jmp 0x00007AC9D05D3134
00007ac9d05d5c0b  sub rsp, 0x08
00007ac9d05d5c0f  push rax
00007ac9d05d5c10  push rcx
00007ac9d05d5c11  push rdx
00007ac9d05d5c12  push rdi
00007ac9d05d5c13  push rsi
00007ac9d05d5c14  push r8
00007ac9d05d5c16  push r9
00007ac9d05d5c18  push r10
00007ac9d05d5c1a  push r11
00007ac9d05d5c1c  sub rsp, 0xF0
00007ac9d05d5c23  vmovaps [rsp], xmm0
00007ac9d05d5c28  vmovaps [rsp+0x10], xmm1
00007ac9d05d5c2e  vmovaps [rsp+0x20], xmm2
00007ac9d05d5c34  vmovaps [rsp+0x30], xmm3
00007ac9d05d5c3a  vmovaps [rsp+0x40], xmm4
00007ac9d05d5c40  vmovaps [rsp+0x50], xmm5
00007ac9d05d5c46  vmovaps [rsp+0x60], xmm6
00007ac9d05d5c4c  vmovaps [rsp+0x70], xmm7
00007ac9d05d5c52  vmovaps [rsp+0x80], xmm8
00007ac9d05d5c5b  vmovaps [rsp+0x90], xmm10
00007ac9d05d5c64  vmovaps [rsp+0xA0], xmm11
00007ac9d05d5c6d  vmovaps [rsp+0xB0], xmm12
00007ac9d05d5c76  vmovaps [rsp+0xC0], xmm13
00007ac9d05d5c7f  vmovaps [rsp+0xD0], xmm14
00007ac9d05d5c88  vmovaps [rsp+0xE0], xmm15
00007ac9d05d5c91  sub rsp, 0x40
00007ac9d05d5c95  lea rdi, [rsp]
00007ac9d05d5c99  lea rsi, [rsp+0x10]
00007ac9d05d5c9e  lea rdx, [rsp+0x20]
00007ac9d05d5ca3  lea rcx, [rsp+0x30]
00007ac9d05d5ca8  mov r8d, 0x00
00007ac9d05d5cae  lea r9, [r15+0x3A8]
00007ac9d05d5cb5  movaps [rdi], xmm9
00007ac9d05d5cb9  movaps [rsi], xmm8
00007ac9d05d5cbd  movaps [rdx], xmm14
00007ac9d05d5cc1  movaps [rcx], xmm12
00007ac9d05d5cc5  mov rax, 0x569AF9F93A50
00007ac9d05d5ccf  call rax
00007ac9d05d5cd1  movaps xmm9, [rsp]
00007ac9d05d5cd6  add rsp, 0x40
00007ac9d05d5cda  vmovaps xmm0, [rsp]
00007ac9d05d5cdf  vmovaps xmm1, [rsp+0x10]
00007ac9d05d5ce5  vmovaps xmm2, [rsp+0x20]
00007ac9d05d5ceb  vmovaps xmm3, [rsp+0x30]
00007ac9d05d5cf1  vmovaps xmm4, [rsp+0x40]
00007ac9d05d5cf7  vmovaps xmm5, [rsp+0x50]
00007ac9d05d5cfd  vmovaps xmm6, [rsp+0x60]
00007ac9d05d5d03  vmovaps xmm7, [rsp+0x70]
00007ac9d05d5d09  vmovaps xmm8, [rsp+0x80]
00007ac9d05d5d12  vmovaps xmm10, [rsp+0x90]
00007ac9d05d5d1b  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d5d24  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d5d2d  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d5d36  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d5d3f  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d5d48  add rsp, 0xF0
00007ac9d05d5d4f  pop r11
00007ac9d05d5d51  pop r10
00007ac9d05d5d53  pop r9
00007ac9d05d5d55  pop r8
00007ac9d05d5d57  pop rsi
00007ac9d05d5d58  pop rdi
00007ac9d05d5d59  pop rdx
00007ac9d05d5d5a  pop rcx
00007ac9d05d5d5b  pop rax
00007ac9d05d5d5c  add rsp, 0x08
00007ac9d05d5d60  jmp 0x00007AC9D05D3165
00007ac9d05d5d65  sub rsp, 0x08
00007ac9d05d5d69  push rax
00007ac9d05d5d6a  push rcx
00007ac9d05d5d6b  push rdx
00007ac9d05d5d6c  push rdi
00007ac9d05d5d6d  push rsi
00007ac9d05d5d6e  push r8
00007ac9d05d5d70  push r9
00007ac9d05d5d72  push r10
00007ac9d05d5d74  push r11
00007ac9d05d5d76  sub rsp, 0xF0
00007ac9d05d5d7d  vmovaps [rsp], xmm0
00007ac9d05d5d82  vmovaps [rsp+0x10], xmm1
00007ac9d05d5d88  vmovaps [rsp+0x20], xmm2
00007ac9d05d5d8e  vmovaps [rsp+0x30], xmm3
00007ac9d05d5d94  vmovaps [rsp+0x40], xmm4
00007ac9d05d5d9a  vmovaps [rsp+0x50], xmm5
00007ac9d05d5da0  vmovaps [rsp+0x60], xmm6
00007ac9d05d5da6  vmovaps [rsp+0x70], xmm7
00007ac9d05d5dac  vmovaps [rsp+0x80], xmm8
00007ac9d05d5db5  vmovaps [rsp+0x90], xmm9
00007ac9d05d5dbe  vmovaps [rsp+0xA0], xmm10
00007ac9d05d5dc7  vmovaps [rsp+0xB0], xmm11
00007ac9d05d5dd0  vmovaps [rsp+0xC0], xmm13
00007ac9d05d5dd9  vmovaps [rsp+0xD0], xmm14
00007ac9d05d5de2  vmovaps [rsp+0xE0], xmm15
00007ac9d05d5deb  sub rsp, 0x40
00007ac9d05d5def  lea rdi, [rsp]
00007ac9d05d5df3  lea rsi, [rsp+0x10]
00007ac9d05d5df8  lea rdx, [rsp+0x20]
00007ac9d05d5dfd  lea rcx, [rsp+0x30]
00007ac9d05d5e02  mov r8d, 0x00
00007ac9d05d5e08  lea r9, [r15+0x3A8]
00007ac9d05d5e0f  movaps [rdi], xmm12
00007ac9d05d5e13  movaps [rsi], xmm10
00007ac9d05d5e17  movaps [rdx], xmm15
00007ac9d05d5e1b  movaps [rcx], xmm14
00007ac9d05d5e1f  mov rax, 0x569AF9F93A50
00007ac9d05d5e29  call rax
00007ac9d05d5e2b  movaps xmm12, [rsp]
00007ac9d05d5e30  add rsp, 0x40
00007ac9d05d5e34  vmovaps xmm0, [rsp]
00007ac9d05d5e39  vmovaps xmm1, [rsp+0x10]
00007ac9d05d5e3f  vmovaps xmm2, [rsp+0x20]
00007ac9d05d5e45  vmovaps xmm3, [rsp+0x30]
00007ac9d05d5e4b  vmovaps xmm4, [rsp+0x40]
00007ac9d05d5e51  vmovaps xmm5, [rsp+0x50]
00007ac9d05d5e57  vmovaps xmm6, [rsp+0x60]
00007ac9d05d5e5d  vmovaps xmm7, [rsp+0x70]
00007ac9d05d5e63  vmovaps xmm8, [rsp+0x80]
00007ac9d05d5e6c  vmovaps xmm9, [rsp+0x90]
00007ac9d05d5e75  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d5e7e  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d5e87  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d5e90  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d5e99  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d5ea2  add rsp, 0xF0
00007ac9d05d5ea9  pop r11
00007ac9d05d5eab  pop r10
00007ac9d05d5ead  pop r9
00007ac9d05d5eaf  pop r8
00007ac9d05d5eb1  pop rsi
00007ac9d05d5eb2  pop rdi
00007ac9d05d5eb3  pop rdx
00007ac9d05d5eb4  pop rcx
00007ac9d05d5eb5  pop rax
00007ac9d05d5eb6  add rsp, 0x08
00007ac9d05d5eba  jmp 0x00007AC9D05D3196
00007ac9d05d5ebf  sub rsp, 0x08
00007ac9d05d5ec3  push rax
00007ac9d05d5ec4  push rcx
00007ac9d05d5ec5  push rdx
00007ac9d05d5ec6  push rdi
00007ac9d05d5ec7  push rsi
00007ac9d05d5ec8  push r8
00007ac9d05d5eca  push r9
00007ac9d05d5ecc  push r10
00007ac9d05d5ece  push r11
00007ac9d05d5ed0  sub rsp, 0xF0
00007ac9d05d5ed7  vmovaps [rsp], xmm0
00007ac9d05d5edc  vmovaps [rsp+0x10], xmm1
00007ac9d05d5ee2  vmovaps [rsp+0x20], xmm2
00007ac9d05d5ee8  vmovaps [rsp+0x30], xmm3
00007ac9d05d5eee  vmovaps [rsp+0x40], xmm4
00007ac9d05d5ef4  vmovaps [rsp+0x50], xmm5
00007ac9d05d5efa  vmovaps [rsp+0x60], xmm6
00007ac9d05d5f00  vmovaps [rsp+0x70], xmm7
00007ac9d05d5f06  vmovaps [rsp+0x80], xmm8
00007ac9d05d5f0f  vmovaps [rsp+0x90], xmm9
00007ac9d05d5f18  vmovaps [rsp+0xA0], xmm10
00007ac9d05d5f21  vmovaps [rsp+0xB0], xmm11
00007ac9d05d5f2a  vmovaps [rsp+0xC0], xmm12
00007ac9d05d5f33  vmovaps [rsp+0xD0], xmm13
00007ac9d05d5f3c  vmovaps [rsp+0xE0], xmm15
00007ac9d05d5f45  sub rsp, 0x40
00007ac9d05d5f49  lea rdi, [rsp]
00007ac9d05d5f4d  lea rsi, [rsp+0x10]
00007ac9d05d5f52  lea rdx, [rsp+0x20]
00007ac9d05d5f57  lea rcx, [rsp+0x30]
00007ac9d05d5f5c  mov r8d, 0x00
00007ac9d05d5f62  lea r9, [r15+0x3A8]
00007ac9d05d5f69  movaps [rdi], xmm14
00007ac9d05d5f6d  movaps [rsi], xmm13
00007ac9d05d5f71  movaps [rdx], xmm1
00007ac9d05d5f74  movaps [rcx], xmm15
00007ac9d05d5f78  mov rax, 0x569AF9F93A50
00007ac9d05d5f82  call rax
00007ac9d05d5f84  movaps xmm14, [rsp]
00007ac9d05d5f89  add rsp, 0x40
00007ac9d05d5f8d  vmovaps xmm0, [rsp]
00007ac9d05d5f92  vmovaps xmm1, [rsp+0x10]
00007ac9d05d5f98  vmovaps xmm2, [rsp+0x20]
00007ac9d05d5f9e  vmovaps xmm3, [rsp+0x30]
00007ac9d05d5fa4  vmovaps xmm4, [rsp+0x40]
00007ac9d05d5faa  vmovaps xmm5, [rsp+0x50]
00007ac9d05d5fb0  vmovaps xmm6, [rsp+0x60]
00007ac9d05d5fb6  vmovaps xmm7, [rsp+0x70]
00007ac9d05d5fbc  vmovaps xmm8, [rsp+0x80]
00007ac9d05d5fc5  vmovaps xmm9, [rsp+0x90]
00007ac9d05d5fce  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d5fd7  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d5fe0  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d5fe9  vmovaps xmm13, [rsp+0xD0]
00007ac9d05d5ff2  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d5ffb  add rsp, 0xF0
00007ac9d05d6002  pop r11
00007ac9d05d6004  pop r10
00007ac9d05d6006  pop r9
00007ac9d05d6008  pop r8
00007ac9d05d600a  pop rsi
00007ac9d05d600b  pop rdi
00007ac9d05d600c  pop rdx
00007ac9d05d600d  pop rcx
00007ac9d05d600e  pop rax
00007ac9d05d600f  add rsp, 0x08
00007ac9d05d6013  jmp 0x00007AC9D05D31C7
00007ac9d05d6018  call 0x00007AC9D04079B0
00007ac9d05d601d  jmp 0x00007AC9D05D31DA
00007ac9d05d6022  call 0x00007AC9D040B100
00007ac9d05d6027  jmp 0x00007AC9D05D31E5
00007ac9d05d602c  call 0x00007AC9D0409E90
00007ac9d05d6031  jmp 0x00007AC9D05D31F0
00007ac9d05d6036  call 0x00007AC9D040D600
00007ac9d05d603b  jmp 0x00007AC9D05D31FB
00007ac9d05d6040  int3
00007ac9d05d6041  nop [rax+rax*1], ax
00007ac9d05d604a  nop [rax+rax*1], ax
00007ac9d05d6050  mov rax, [r15+0x40]
00007ac9d05d6054  mov r14, [r15+0x58]
00007ac9d05d6058  lea r12, [rax+r14*1]
00007ac9d05d605c  vxorps xmm1, xmm1, xmm1
00007ac9d05d6060  vpbroadcastq xmm1, xmm1
00007ac9d05d6065  vxorps xmm15, xmm15, xmm15
00007ac9d05d606a  vpbroadcastq xmm15, xmm15
00007ac9d05d606f  lea rax, [r12+0x30]
00007ac9d05d6074  mov r11, [r13+rax*1]
00007ac9d05d6079  lea rax, [r12+0x38]
00007ac9d05d607e  mov r10, [r13+rax*1]
00007ac9d05d6083  movq xmm14, r11
00007ac9d05d6088  movq xmm13, r10
00007ac9d05d608d  movq xmm14, xmm14
00007ac9d05d6092  movq xmm13, xmm13
00007ac9d05d6097  vmovaps [rsp+0x10], xmm13
00007ac9d05d609d  movq xmm13, xmm13
00007ac9d05d60a2  movaps [r15+0x270], xmm13
00007ac9d05d60aa  movaps xmm13, [r15+0x160]
00007ac9d05d60b2  vmovaps [rsp+0x20], xmm13
00007ac9d05d60b8  vmovaps xmm12, [rsp+0x20]
00007ac9d05d60be  por xmm13, xmm12
00007ac9d05d60c3  lea rax, [r12+0x20]
00007ac9d05d60c8  mov r11, [r13+rax*1]
00007ac9d05d60cd  lea rax, [r12+0x28]
00007ac9d05d60d2  mov r10, [r13+rax*1]
00007ac9d05d60d7  movq xmm12, r11
00007ac9d05d60dc  movq xmm11, r10
00007ac9d05d60e1  movq xmm12, xmm12
00007ac9d05d60e6  movq xmm11, xmm11
00007ac9d05d60eb  movaps xmm10, [r15+0x2D0]
00007ac9d05d60f3  vmovaps [rsp+0x20], xmm10
00007ac9d05d60f9  vmovaps xmm9, [rsp+0x20]
00007ac9d05d60ff  por xmm10, xmm9
00007ac9d05d6104  movaps xmm9, [r15+0x300]
00007ac9d05d610c  vmovaps [rsp+0x20], xmm9
00007ac9d05d6112  vmovaps xmm8, [rsp+0x20]
00007ac9d05d6118  por xmm9, xmm8
00007ac9d05d611d  movaps xmm8, [r15+0x2B0]
00007ac9d05d6125  vmovaps [rsp+0x20], xmm8
00007ac9d05d612b  vmovaps xmm7, [rsp+0x20]
00007ac9d05d6131  por xmm8, xmm7
00007ac9d05d6136  movaps xmm7, [r15+0x180]
00007ac9d05d613e  vmovaps [rsp+0x20], xmm7
00007ac9d05d6144  vmovaps xmm6, [rsp+0x20]
00007ac9d05d614a  por xmm7, xmm6
00007ac9d05d614e  lea rax, [r12+0x10]
00007ac9d05d6153  mov r11, [r13+rax*1]
00007ac9d05d6158  lea rax, [r12+0x18]
00007ac9d05d615d  mov r10, [r13+rax*1]
00007ac9d05d6162  movq xmm6, r11
00007ac9d05d6167  movq xmm5, r10
00007ac9d05d616c  movq xmm6, xmm6
00007ac9d05d6170  movq xmm5, xmm5
00007ac9d05d6174  movaps xmm4, [r15+0x200]
00007ac9d05d617c  vmovaps [rsp+0x20], xmm4
00007ac9d05d6182  vmovaps xmm3, [rsp+0x20]
00007ac9d05d6188  por xmm4, xmm3
00007ac9d05d618c  movaps xmm3, [r15+0x1F0]
00007ac9d05d6194  vmovaps [rsp+0x20], xmm3
00007ac9d05d619a  vmovaps xmm2, [rsp+0x20]
00007ac9d05d61a0  por xmm3, xmm2
00007ac9d05d61a4  movaps xmm2, [r15+0x2E0]
00007ac9d05d61ac  vmovaps [rsp+0x20], xmm2
00007ac9d05d61b2  vmovaps [rsp+0x30], xmm1
00007ac9d05d61b8  vmovaps xmm1, [rsp+0x20]
00007ac9d05d61be  por xmm2, xmm1
00007ac9d05d61c2  movaps xmm1, [r15+0x2A0]
00007ac9d05d61ca  vmovaps [rsp+0x20], xmm1
00007ac9d05d61d0  vmovaps [rsp+0x40], xmm15
00007ac9d05d61d6  vmovaps xmm15, [rsp+0x20]
00007ac9d05d61dc  por xmm1, xmm15
00007ac9d05d61e1  movaps xmm15, [r15+0x280]
00007ac9d05d61e9  vmovaps [rsp+0x20], xmm15
00007ac9d05d61ef  vmovaps [rsp+0x50], xmm1
00007ac9d05d61f5  vmovaps xmm1, [rsp+0x20]
00007ac9d05d61fb  por xmm15, xmm1
00007ac9d05d6200  movaps xmm1, [r15+0x1C0]
00007ac9d05d6208  vmovaps [rsp+0x20], xmm1
00007ac9d05d620e  vmovaps [rsp+0x60], xmm15
00007ac9d05d6214  vmovaps xmm15, [rsp+0x20]
00007ac9d05d621a  por xmm1, xmm15
00007ac9d05d621f  movaps xmm15, [r15+0x210]
00007ac9d05d6227  vmovaps [rsp+0x20], xmm15
00007ac9d05d622d  vmovaps [rsp+0x70], xmm1
00007ac9d05d6233  vmovaps xmm1, [rsp+0x20]
00007ac9d05d6239  por xmm15, xmm1
00007ac9d05d623e  mov rax, [r13+r12*1]
00007ac9d05d6243  vmovq xmm1, rax
00007ac9d05d6248  vpbroadcastq xmm1, xmm1
00007ac9d05d624d  vmovaps [rsp+0x20], xmm1
00007ac9d05d6253  vxorps xmm1, xmm1, xmm1
00007ac9d05d6257  vpbroadcastq xmm1, xmm1
00007ac9d05d625c  mov rax, [r15+0xF8]
00007ac9d05d6263  vmovaps [rsp+0x80], xmm1
00007ac9d05d626c  movups xmm1, [r13+rax*1]
00007ac9d05d6272  vmovaps [rsp+0x90], xmm1
00007ac9d05d627b  vxorps xmm1, xmm1, xmm1
00007ac9d05d627f  vpbroadcastq xmm1, xmm1
00007ac9d05d6284  lea r11, [r12+0x08]
00007ac9d05d6289  mov r12, [r13+r11*1]
00007ac9d05d628e  vmovaps [rsp+0xA0], xmm1
00007ac9d05d6297  movq xmm1, r12
00007ac9d05d629c  movaps [r15+0x240], xmm1
00007ac9d05d62a4  mov r12, [r15+0x50]
00007ac9d05d62a8  lea r11, [r12+r14*1]
00007ac9d05d62ac  mov [r15+0x60], r11
00007ac9d05d62b0  lea r12, [r14+0x40]
00007ac9d05d62b4  mov [r15+0x58], r12
00007ac9d05d62b8  vmovaps xmm1, [rsp+0x30]
00007ac9d05d62be  vmovaps [rsp+0x30], xmm15
00007ac9d05d62c4  vmovaps xmm15, [rsp+0x90]
00007ac9d05d62cd  vmovaps [rsp+0x90], xmm14
00007ac9d05d62d6  vmovaps xmm14, [rsp+0x20]
00007ac9d05d62dc  vmovaps [rsp+0x20], xmm13
00007ac9d05d62e2  vmovaps [rsp+0xB0], xmm12
00007ac9d05d62eb  movaps xmm13, xmm1
00007ac9d05d62ef  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d62fa  vptest xmm12, xmm12
00007ac9d05d62ff  jnz 0x00007AC9D05D6D9C
00007ac9d05d6305  movaps xmm1, [r15+0x250]
00007ac9d05d630d  vmovaps xmm15, [rsp+0x40]
00007ac9d05d6313  vmovaps [rsp+0x40], xmm13
00007ac9d05d6319  movaps xmm12, xmm15
00007ac9d05d631d  vfmadd231pd xmm12, xmm1, xmm14
00007ac9d05d6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007ac9d05d6328  vptest xmm13, xmm13
00007ac9d05d632d  jnz 0x00007AC9D05D6EF5
00007ac9d05d6333  movaps xmm15, [r15+0x1E0]
00007ac9d05d633b  vmovaps [rsp+0xC0], xmm15
00007ac9d05d6344  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d634d  por xmm15, xmm13
00007ac9d05d6352  movaps xmm13, [r15+0x1D0]
00007ac9d05d635a  vmovaps [rsp+0xC0], xmm13
00007ac9d05d6363  vmovaps [rsp+0xD0], xmm1
00007ac9d05d636c  vmovaps xmm1, [rsp+0xC0]
00007ac9d05d6375  por xmm13, xmm1
00007ac9d05d637a  movaps xmm1, [r15+0x2C0]
00007ac9d05d6382  vmovaps [rsp+0xC0], xmm1
00007ac9d05d638b  vmovaps [rsp+0xE0], xmm15
00007ac9d05d6394  vmovaps xmm15, [rsp+0xC0]
00007ac9d05d639d  por xmm1, xmm15
00007ac9d05d63a2  movaps xmm15, [r15+0x290]
00007ac9d05d63aa  vmovaps [rsp+0xC0], xmm15
00007ac9d05d63b3  vmovaps [rsp+0xF0], xmm1
00007ac9d05d63bc  vmovaps xmm1, [rsp+0xC0]
00007ac9d05d63c5  por xmm15, xmm1
00007ac9d05d63ca  movaps xmm1, [r15+0x260]
00007ac9d05d63d2  vmovaps [rsp+0xC0], xmm1
00007ac9d05d63db  vmovaps [rsp+0x100], xmm15
00007ac9d05d63e4  vmovaps xmm15, [rsp+0xC0]
00007ac9d05d63ed  por xmm1, xmm15
00007ac9d05d63f2  vmovaps xmm15, [rsp+0xD0]
00007ac9d05d63fb  vmovaps [rsp+0xC0], xmm1
00007ac9d05d6404  vmovaps xmm1, [rsp+0xD0]
00007ac9d05d640d  por xmm15, xmm1
00007ac9d05d6412  lea r14, [rax+0xC0]
00007ac9d05d6419  movups xmm1, [r13+r14*1]
00007ac9d05d641f  mov [rsp+0xD0], rax
00007ac9d05d6427  xor eax, eax
00007ac9d05d6429  mov r14d, 0x200
00007ac9d05d642f  cmp r12, r14
00007ac9d05d6432  cmc
00007ac9d05d6433  lahf
00007ac9d05d6434  seto al
00007ac9d05d6437  mov [r15+0x108], eax
00007ac9d05d643e  vmovaps [rsp+0x110], xmm1
00007ac9d05d6447  vmovaps xmm1, [rsp+0x80]
00007ac9d05d6450  vmovaps [rsp+0x80], xmm15
00007ac9d05d6459  vmovaps xmm15, [rsp+0x110]
00007ac9d05d6462  vmovaps [rsp+0x110], xmm13
00007ac9d05d646b  vmovaps [rsp+0x120], xmm12
00007ac9d05d6474  movaps xmm13, xmm1
00007ac9d05d6478  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d6483  vptest xmm12, xmm12
00007ac9d05d6488  jnz 0x00007AC9D05D7058
00007ac9d05d648e  mov rax, [rsp+0xD0]
00007ac9d05d6496  lea r14, [rax+0xB0]
00007ac9d05d649d  movups xmm1, [r13+r14*1]
00007ac9d05d64a3  vmovaps xmm15, [rsp+0xA0]
00007ac9d05d64ac  vmovaps [rsp+0xA0], xmm13
00007ac9d05d64b5  movaps xmm12, xmm15
00007ac9d05d64b9  vfmadd231pd xmm12, xmm1, xmm14
00007ac9d05d64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007ac9d05d64c4  vptest xmm13, xmm13
00007ac9d05d64c9  jnz 0x00007AC9D05D71BB
00007ac9d05d64cf  vmovaps xmm1, [rsp+0x30]
00007ac9d05d64d5  vmovaps xmm15, [rsp+0x30]
00007ac9d05d64db  por xmm1, xmm15
00007ac9d05d64e0  movaps [r15+0x210], xmm1
00007ac9d05d64e8  vmovaps xmm15, [rsp+0x70]
00007ac9d05d64ee  vmovaps xmm14, [rsp+0x70]
00007ac9d05d64f4  por xmm15, xmm14
00007ac9d05d64f9  movaps [r15+0x1C0], xmm15
00007ac9d05d6501  vmovaps xmm14, [rsp+0x60]
00007ac9d05d6507  vmovaps xmm13, [rsp+0x60]
00007ac9d05d650d  por xmm14, xmm13
00007ac9d05d6512  movaps [r15+0x280], xmm14
00007ac9d05d651a  vmovaps xmm13, [rsp+0x50]
00007ac9d05d6520  vmovaps [rsp+0x30], xmm1
00007ac9d05d6526  vmovaps xmm1, [rsp+0x50]
00007ac9d05d652c  por xmm13, xmm1
00007ac9d05d6531  movaps [r15+0x2A0], xmm13
00007ac9d05d6539  vmovaps [rsp+0x50], xmm2
00007ac9d05d653f  vmovaps xmm1, [rsp+0x50]
00007ac9d05d6545  por xmm2, xmm1
00007ac9d05d6549  movaps [r15+0x2E0], xmm2
00007ac9d05d6551  vmovaps [rsp+0x50], xmm3
00007ac9d05d6557  vmovaps xmm1, [rsp+0x50]
00007ac9d05d655d  por xmm3, xmm1
00007ac9d05d6561  movaps [r15+0x1F0], xmm3
00007ac9d05d6569  vmovaps xmm1, [rsp+0x80]
00007ac9d05d6572  vmovaps [rsp+0x50], xmm15
00007ac9d05d6578  vmovaps xmm15, [rsp+0x80]
00007ac9d05d6581  por xmm1, xmm15
00007ac9d05d6586  movaps [r15+0x250], xmm1
00007ac9d05d658e  vmovaps xmm1, [rsp+0xC0]
00007ac9d05d6597  vmovaps xmm15, [rsp+0xC0]
00007ac9d05d65a0  por xmm1, xmm15
00007ac9d05d65a5  movaps [r15+0x260], xmm1
00007ac9d05d65ad  vmovaps xmm15, [rsp+0x100]
00007ac9d05d65b6  vmovaps [rsp+0x60], xmm1
00007ac9d05d65bc  vmovaps xmm1, [rsp+0x100]
00007ac9d05d65c5  por xmm15, xmm1
00007ac9d05d65ca  movaps [r15+0x290], xmm15
00007ac9d05d65d2  vmovaps xmm1, [rsp+0xF0]
00007ac9d05d65db  vmovaps [rsp+0x70], xmm15
00007ac9d05d65e1  vmovaps xmm15, [rsp+0xF0]
00007ac9d05d65ea  por xmm1, xmm15
00007ac9d05d65ef  movaps [r15+0x2C0], xmm1
00007ac9d05d65f7  movq xmm15, qword ptr [r15+0x240]
00007ac9d05d6600  vmovaps [rsp+0x80], xmm15
00007ac9d05d6609  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d660f  vmovaps [rsp+0xC0], xmm1
00007ac9d05d6618  vmovaps xmm1, [rsp+0x40]
00007ac9d05d661e  vmovaps [rsp+0x40], xmm15
00007ac9d05d6624  vmovaps xmm15, [rsp+0x30]
00007ac9d05d662a  vmovaps [rsp+0x30], xmm14
00007ac9d05d6630  vmovaps xmm14, [rsp+0x40]
00007ac9d05d6636  vmovaps [rsp+0x40], xmm13
00007ac9d05d663c  vmovaps [rsp+0xD0], xmm12
00007ac9d05d6645  movaps xmm13, xmm1
00007ac9d05d6649  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d6654  vptest xmm12, xmm12
00007ac9d05d6659  jnz 0x00007AC9D05D7314
00007ac9d05d665f  vmovaps xmm1, [rsp+0x80]
00007ac9d05d6668  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d666e  vmovaps xmm15, [rsp+0xA0]
00007ac9d05d6677  movaps xmm14, xmm15
00007ac9d05d667b  vfmadd231pd xmm14, xmm2, xmm1
00007ac9d05d6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007ac9d05d6686  vptest xmm12, xmm12
00007ac9d05d668b  jnz 0x00007AC9D05D746D
00007ac9d05d6691  vmovaps xmm1, [rsp+0x80]
00007ac9d05d669a  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d66a0  vmovaps xmm15, [rsp+0x120]
00007ac9d05d66a9  vmovaps xmm12, [rsp+0x50]
00007ac9d05d66af  vmovaps [rsp+0x50], xmm14
00007ac9d05d66b5  movaps xmm2, xmm15
00007ac9d05d66b9  vfmadd231pd xmm2, xmm12, xmm1
00007ac9d05d66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007ac9d05d66c3  vptest xmm14, xmm14
00007ac9d05d66c8  jnz 0x00007AC9D05D75C5
00007ac9d05d66ce  vmovaps xmm1, [rsp+0x110]
00007ac9d05d66d7  vmovaps xmm15, [rsp+0x110]
00007ac9d05d66e0  por xmm1, xmm15
00007ac9d05d66e5  movaps [r15+0x1D0], xmm1
00007ac9d05d66ed  vmovaps xmm15, [rsp+0x80]
00007ac9d05d66f6  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d66fc  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d6705  vmovaps [rsp+0x80], xmm1
00007ac9d05d670e  movaps xmm12, xmm14
00007ac9d05d6712  vfmadd231pd xmm12, xmm3, xmm15
00007ac9d05d6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007ac9d05d671d  vptest xmm1, xmm1
00007ac9d05d6722  jnz 0x00007AC9D05D771C
00007ac9d05d6728  vmovaps [rsp+0xA0], xmm4
00007ac9d05d6731  vmovaps xmm1, [rsp+0xA0]
00007ac9d05d673a  por xmm4, xmm1
00007ac9d05d673e  movaps [r15+0x200], xmm4
00007ac9d05d6746  vmovaps xmm1, [rsp+0xE0]
00007ac9d05d674f  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d6758  por xmm1, xmm15
00007ac9d05d675d  movaps [r15+0x1E0], xmm1
00007ac9d05d6765  vmovaps [rsp+0xA0], xmm8
00007ac9d05d676e  vmovaps xmm1, [rsp+0xA0]
00007ac9d05d6777  por xmm8, xmm1
00007ac9d05d677c  movaps [r15+0x2B0], xmm8
00007ac9d05d6784  vmovaps [rsp+0xA0], xmm9
00007ac9d05d678d  vmovaps xmm1, [rsp+0xA0]
00007ac9d05d6796  por xmm9, xmm1
00007ac9d05d679b  movaps [r15+0x300], xmm9
00007ac9d05d67a3  vmovaps [rsp+0xA0], xmm6
00007ac9d05d67ac  vpermilpd xmm6, xmm6, 0x00
00007ac9d05d67b2  vmovaps xmm14, [rsp+0x60]
00007ac9d05d67b8  movaps xmm9, xmm13
00007ac9d05d67bc  vfmadd231pd xmm9, xmm14, xmm6
00007ac9d05d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007ac9d05d67c7  vptest xmm3, xmm3
00007ac9d05d67cc  jnz 0x00007AC9D05D7875
00007ac9d05d67d2  vmovaps xmm14, [rsp+0xA0]
00007ac9d05d67db  vpermilpd xmm14, xmm14, 0x00
00007ac9d05d67e1  vmovaps xmm13, [rsp+0x50]
00007ac9d05d67e7  vmovaps xmm6, [rsp+0xC0]
00007ac9d05d67f0  vmovaps [rsp+0x50], xmm1
00007ac9d05d67f6  movaps xmm3, xmm13
00007ac9d05d67fa  vfmadd231pd xmm3, xmm6, xmm14
00007ac9d05d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007ac9d05d6804  vptest xmm1, xmm1
00007ac9d05d6809  jnz 0x00007AC9D05D79CE
00007ac9d05d680f  vmovaps xmm1, [rsp+0xA0]
00007ac9d05d6818  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d681e  vmovaps xmm14, [rsp+0x30]
00007ac9d05d6824  movaps xmm6, xmm2
00007ac9d05d6827  vfmadd231pd xmm6, xmm14, xmm1
00007ac9d05d682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007ac9d05d6831  vptest xmm13, xmm13
00007ac9d05d6836  jnz 0x00007AC9D05D7B25
00007ac9d05d683c  vmovaps xmm1, [rsp+0xA0]
00007ac9d05d6845  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d684b  vmovaps xmm14, [rsp+0x80]
00007ac9d05d6854  movaps xmm13, xmm12
00007ac9d05d6858  vfmadd231pd xmm13, xmm14, xmm1
00007ac9d05d685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007ac9d05d6863  vptest xmm2, xmm2
00007ac9d05d6868  jnz 0x00007AC9D05D7C7B
00007ac9d05d686e  vmovaps [rsp+0x30], xmm7
00007ac9d05d6874  vmovaps xmm1, [rsp+0x30]
00007ac9d05d687a  por xmm7, xmm1
00007ac9d05d687e  movaps [r15+0x180], xmm7
00007ac9d05d6886  vmovaps [rsp+0x30], xmm10
00007ac9d05d688c  vmovaps xmm1, [rsp+0x30]
00007ac9d05d6892  por xmm10, xmm1
00007ac9d05d6897  movaps [r15+0x2D0], xmm10
00007ac9d05d689f  vmovaps [rsp+0x30], xmm5
00007ac9d05d68a5  vpermilpd xmm5, xmm5, 0x00
00007ac9d05d68ab  vmovaps xmm14, [rsp+0x50]
00007ac9d05d68b1  movaps xmm12, xmm3
00007ac9d05d68b5  vfmadd231pd xmm12, xmm14, xmm5
00007ac9d05d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007ac9d05d68c0  vptest xmm10, xmm10
00007ac9d05d68c5  jnz 0x00007AC9D05D7DD4
00007ac9d05d68cb  vmovaps xmm14, [rsp+0x30]
00007ac9d05d68d1  vpermilpd xmm14, xmm14, 0x00
00007ac9d05d68d7  movaps xmm10, xmm9
00007ac9d05d68db  vfmadd231pd xmm10, xmm7, xmm14
00007ac9d05d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007ac9d05d68e6  vptest xmm5, xmm5
00007ac9d05d68eb  jnz 0x00007AC9D05D7F2C
00007ac9d05d68f1  lea r14, [rax+0x80]
00007ac9d05d68f8  movups xmm14, [r13+r14*1]
00007ac9d05d68fe  movaps [r15+0x2F0], xmm14
00007ac9d05d6906  vmovaps xmm9, [rsp+0x30]
00007ac9d05d690c  vpermilpd xmm9, xmm9, 0x00
00007ac9d05d6912  vmovaps xmm7, [rsp+0x70]
00007ac9d05d6918  movaps xmm5, xmm6
00007ac9d05d691b  vfmadd231pd xmm5, xmm7, xmm9
00007ac9d05d6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007ac9d05d6925  vptest xmm3, xmm3
00007ac9d05d692a  jnz 0x00007AC9D05D808F
00007ac9d05d6930  vmovaps xmm9, [rsp+0x30]
00007ac9d05d6936  vpermilpd xmm9, xmm9, 0x00
00007ac9d05d693c  movaps xmm7, xmm13
00007ac9d05d6940  vfmadd231pd xmm7, xmm1, xmm9
00007ac9d05d6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007ac9d05d694a  vptest xmm6, xmm6
00007ac9d05d694f  jnz 0x00007AC9D05D81E5
00007ac9d05d6955  vmovaps xmm1, [rsp+0x20]
00007ac9d05d695b  vmovaps xmm13, [rsp+0x20]
00007ac9d05d6961  por xmm1, xmm13
00007ac9d05d6966  movaps [r15+0x160], xmm1
00007ac9d05d696e  lea r14, [rax+0x40]
00007ac9d05d6972  movups xmm13, [r13+r14*1]
00007ac9d05d6978  lea r14, [rax+0x50]
00007ac9d05d697c  movups xmm9, [r13+r14*1]
00007ac9d05d6982  movaps [r15+0x1B0], xmm13
00007ac9d05d698a  movaps [r15+0x1A0], xmm9
00007ac9d05d6992  movaps xmm6, [r15+0x190]
00007ac9d05d699a  vmovaps xmm3, [rsp+0xB0]
00007ac9d05d69a3  vpermilpd xmm3, xmm3, 0x00
00007ac9d05d69a9  vmovaps [rsp+0x20], xmm1
00007ac9d05d69af  movaps xmm2, xmm12
00007ac9d05d69b3  vfmadd231pd xmm2, xmm6, xmm3
00007ac9d05d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007ac9d05d69bd  vptest xmm1, xmm1
00007ac9d05d69c2  jnz 0x00007AC9D05D8350
00007ac9d05d69c8  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d69d1  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d69d7  vmovaps xmm12, [rsp+0x20]
00007ac9d05d69dd  movaps xmm6, xmm10
00007ac9d05d69e1  vfmadd231pd xmm6, xmm12, xmm1
00007ac9d05d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007ac9d05d69eb  vptest xmm3, xmm3
00007ac9d05d69f0  jnz 0x00007AC9D05D84A6
00007ac9d05d69f6  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d69ff  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d6a05  vmovaps xmm12, [rsp+0x40]
00007ac9d05d6a0b  movaps xmm10, xmm5
00007ac9d05d6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007ac9d05d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007ac9d05d6a1a  vptest xmm3, xmm3
00007ac9d05d6a1f  jnz 0x00007AC9D05D85FD
00007ac9d05d6a25  vmovaps xmm1, [rsp+0xB0]
00007ac9d05d6a2e  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d6a34  movaps xmm12, xmm7
00007ac9d05d6a38  vfmadd231pd xmm12, xmm15, xmm1
00007ac9d05d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007ac9d05d6a43  vptest xmm5, xmm5
00007ac9d05d6a48  jnz 0x00007AC9D05D8755
00007ac9d05d6a4e  lea r14, [rax+0x60]
00007ac9d05d6a52  movups xmm1, [r13+r14*1]
00007ac9d05d6a58  lea r14, [rax+0x70]
00007ac9d05d6a5c  movups xmm15, [r13+r14*1]
00007ac9d05d6a62  movaps [r15+0x150], xmm1
00007ac9d05d6a6a  movaps [r15+0x120], xmm15
00007ac9d05d6a72  vmovaps [rsp+0x20], xmm11
00007ac9d05d6a78  vpermilpd xmm11, xmm11, 0x00
00007ac9d05d6a7e  movaps xmm7, xmm2
00007ac9d05d6a81  vfmadd231pd xmm7, xmm9, xmm11
00007ac9d05d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007ac9d05d6a8b  vptest xmm5, xmm5
00007ac9d05d6a90  jnz 0x00007AC9D05D88C1
00007ac9d05d6a96  vmovaps xmm11, [rsp+0x20]
00007ac9d05d6a9c  vpermilpd xmm11, xmm11, 0x00
00007ac9d05d6aa2  movaps xmm9, xmm6
00007ac9d05d6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007ac9d05d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007ac9d05d6ab1  vptest xmm5, xmm5
00007ac9d05d6ab6  jnz 0x00007AC9D05D8A18
00007ac9d05d6abc  vmovaps xmm1, [rsp+0x20]
00007ac9d05d6ac2  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d6ac8  movaps xmm11, xmm10
00007ac9d05d6acc  vfmadd231pd xmm11, xmm8, xmm1
00007ac9d05d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007ac9d05d6ad7  vptest xmm6, xmm6
00007ac9d05d6adc  jnz 0x00007AC9D05D8B70
00007ac9d05d6ae2  vmovaps xmm1, [rsp+0x20]
00007ac9d05d6ae8  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d6aee  movaps xmm10, xmm12
00007ac9d05d6af2  vfmadd231pd xmm10, xmm13, xmm1
00007ac9d05d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007ac9d05d6afd  vptest xmm8, xmm8
00007ac9d05d6b02  jnz 0x00007AC9D05D8CC9
00007ac9d05d6b08  lea r14, [rax+0x20]
00007ac9d05d6b0c  movups xmm1, [r13+r14*1]
00007ac9d05d6b12  lea r14, [rax+0x30]
00007ac9d05d6b16  movups xmm13, [r13+r14*1]
00007ac9d05d6b1c  vmovaps xmm12, [rsp+0x90]
00007ac9d05d6b25  vpermilpd xmm12, xmm12, 0x00
00007ac9d05d6b2b  movaps xmm8, xmm7
00007ac9d05d6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007ac9d05d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007ac9d05d6b3a  vptest xmm6, xmm6
00007ac9d05d6b3f  jnz 0x00007AC9D05D8E36
00007ac9d05d6b45  vmovaps xmm12, [rsp+0x90]
00007ac9d05d6b4e  vpermilpd xmm12, xmm12, 0x00
00007ac9d05d6b54  movaps xmm7, xmm9
00007ac9d05d6b58  vfmadd231pd xmm7, xmm14, xmm12
00007ac9d05d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007ac9d05d6b62  vptest xmm6, xmm6
00007ac9d05d6b67  jnz 0x00007AC9D05D8F8E
00007ac9d05d6b6d  vmovaps xmm14, [rsp+0x90]
00007ac9d05d6b76  vpermilpd xmm14, xmm14, 0x00
00007ac9d05d6b7c  movaps xmm12, xmm11
00007ac9d05d6b80  vfmadd231pd xmm12, xmm15, xmm14
00007ac9d05d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007ac9d05d6b8b  vptest xmm9, xmm9
00007ac9d05d6b90  jnz 0x00007AC9D05D90E6
00007ac9d05d6b96  vmovaps xmm15, [rsp+0x90]
00007ac9d05d6b9f  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d6ba5  movaps xmm11, xmm10
00007ac9d05d6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007ac9d05d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007ac9d05d6bb4  vptest xmm14, xmm14
00007ac9d05d6bb9  jnz 0x00007AC9D05D9240
00007ac9d05d6bbf  lea r14, [rax+0x90]
00007ac9d05d6bc6  movups xmm15, [r13+r14*1]
00007ac9d05d6bcc  lea r14, [rax+0xA0]
00007ac9d05d6bd3  movups xmm14, [r13+r14*1]
00007ac9d05d6bd9  movaps [r15+0x140], xmm15
00007ac9d05d6be1  movaps [r15+0x130], xmm14
00007ac9d05d6be9  vmovaps xmm13, [rsp+0x10]
00007ac9d05d6bef  vpermilpd xmm13, xmm13, 0x00
00007ac9d05d6bf5  movaps xmm10, xmm8
00007ac9d05d6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007ac9d05d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007ac9d05d6c04  vptest xmm9, xmm9
00007ac9d05d6c09  jnz 0x00007AC9D05D93AE
00007ac9d05d6c0f  movaps [r15+0x220], xmm10
00007ac9d05d6c17  lea r14, [rax+0x10]
00007ac9d05d6c1b  movups xmm1, [r13+r14*1]
00007ac9d05d6c21  movaps [r15+0x240], xmm1
00007ac9d05d6c29  vmovaps xmm13, [rsp+0x10]
00007ac9d05d6c2f  vpermilpd xmm13, xmm13, 0x00
00007ac9d05d6c35  movaps xmm9, xmm7
00007ac9d05d6c39  vfmadd231pd xmm9, xmm14, xmm13
00007ac9d05d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007ac9d05d6c44  vptest xmm8, xmm8
00007ac9d05d6c49  jnz 0x00007AC9D05D9511
00007ac9d05d6c4f  movaps [r15+0x110], xmm9
00007ac9d05d6c57  vmovaps xmm14, [rsp+0x10]
00007ac9d05d6c5d  vpermilpd xmm14, xmm14, 0x00
00007ac9d05d6c63  movaps xmm13, xmm12
00007ac9d05d6c67  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007ac9d05d6c72  vptest xmm8, xmm8
00007ac9d05d6c77  jnz 0x00007AC9D05D966A
00007ac9d05d6c7d  movaps [r15+0x170], xmm13
00007ac9d05d6c85  vmovaps xmm15, [rsp+0x10]
00007ac9d05d6c8b  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d6c91  movaps xmm14, xmm11
00007ac9d05d6c95  vfmadd231pd xmm14, xmm1, xmm15
00007ac9d05d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007ac9d05d6ca0  vptest xmm12, xmm12
00007ac9d05d6ca5  jnz 0x00007AC9D05D97C4
00007ac9d05d6cab  movaps [r15+0x230], xmm14
00007ac9d05d6cb3  movups [r13+r11*1], xmm9
00007ac9d05d6cb9  lea rax, [r11+0x10]
00007ac9d05d6cbd  movups [r13+rax*1], xmm13
00007ac9d05d6cc3  lea rax, [r11+0x20]
00007ac9d05d6cc7  movups [r13+rax*1], xmm10
00007ac9d05d6ccd  lea rax, [r11+0x30]
00007ac9d05d6cd1  movups [r13+rax*1], xmm14
00007ac9d05d6cd7  mov eax, [r15+0x108]
00007ac9d05d6cde  sahf
00007ac9d05d6cdf  jnz 0x00007AC9D05D6D11
00007ac9d05d6ce1  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d6ce9  jz 0x00007AC9D05D9950
00007ac9d05d6cef  nop [rax+rax*1], ax
00007ac9d05d6cf8  nop [rax+rax*1], eax
00007ac9d05d6d00  mov eax, 0x410664
00007ac9d05d6d05  mov [r15+0x100], rax
00007ac9d05d6d0c  jmp 0x00007AC9D03FE110
00007ac9d05d6d11  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d6d19  jz 0x00007AC9D05D6050
00007ac9d05d6d1f  nop [rax+rax*1], ax
00007ac9d05d6d28  nop [rax+rax*1], eax
00007ac9d05d6d30  mov eax, 0x4104F0
00007ac9d05d6d35  mov [r15+0x100], rax
00007ac9d05d6d3c  jmp 0x00007AC9D03FE110
00007ac9d05d6d41  int3
00007ac9d05d6d42  call 0x00007AC9D040A4B0
00007ac9d05d6d47  jmp 0x00007AC9D05D6079
00007ac9d05d6d4c  call 0x00007AC9D0409240
00007ac9d05d6d51  jmp 0x00007AC9D05D6083
00007ac9d05d6d56  call 0x00007AC9D040A4B0
00007ac9d05d6d5b  jmp 0x00007AC9D05D60CD
00007ac9d05d6d60  call 0x00007AC9D0409240
00007ac9d05d6d65  jmp 0x00007AC9D05D60D7
00007ac9d05d6d6a  call 0x00007AC9D040A4B0
00007ac9d05d6d6f  jmp 0x00007AC9D05D6158
00007ac9d05d6d74  call 0x00007AC9D0409240
00007ac9d05d6d79  jmp 0x00007AC9D05D6162
00007ac9d05d6d7e  call 0x00007AC9D04B47C0
00007ac9d05d6d83  jmp 0x00007AC9D05D6243
00007ac9d05d6d88  call 0x00007AC9D03FF430
00007ac9d05d6d8d  jmp 0x00007AC9D05D6272
00007ac9d05d6d92  call 0x00007AC9D04B0CE0
00007ac9d05d6d97  jmp 0x00007AC9D05D628E
00007ac9d05d6d9c  sub rsp, 0x08
00007ac9d05d6da0  push rax
00007ac9d05d6da1  push rcx
00007ac9d05d6da2  push rdx
00007ac9d05d6da3  push rdi
00007ac9d05d6da4  push rsi
00007ac9d05d6da5  push r8
00007ac9d05d6da7  push r9
00007ac9d05d6da9  push r10
00007ac9d05d6dab  push r11
00007ac9d05d6dad  sub rsp, 0xF0
00007ac9d05d6db4  vmovaps [rsp], xmm0
00007ac9d05d6db9  vmovaps [rsp+0x10], xmm1
00007ac9d05d6dbf  vmovaps [rsp+0x20], xmm2
00007ac9d05d6dc5  vmovaps [rsp+0x30], xmm3
00007ac9d05d6dcb  vmovaps [rsp+0x40], xmm4
00007ac9d05d6dd1  vmovaps [rsp+0x50], xmm5
00007ac9d05d6dd7  vmovaps [rsp+0x60], xmm6
00007ac9d05d6ddd  vmovaps [rsp+0x70], xmm7
00007ac9d05d6de3  vmovaps [rsp+0x80], xmm8
00007ac9d05d6dec  vmovaps [rsp+0x90], xmm9
00007ac9d05d6df5  vmovaps [rsp+0xA0], xmm10
00007ac9d05d6dfe  vmovaps [rsp+0xB0], xmm11
00007ac9d05d6e07  vmovaps [rsp+0xC0], xmm12
00007ac9d05d6e10  vmovaps [rsp+0xD0], xmm14
00007ac9d05d6e19  vmovaps [rsp+0xE0], xmm15
00007ac9d05d6e22  sub rsp, 0x40
00007ac9d05d6e26  lea rdi, [rsp]
00007ac9d05d6e2a  lea rsi, [rsp+0x10]
00007ac9d05d6e2f  lea rdx, [rsp+0x20]
00007ac9d05d6e34  lea rcx, [rsp+0x30]
00007ac9d05d6e39  mov r8d, 0x00
00007ac9d05d6e3f  lea r9, [r15+0x3A8]
00007ac9d05d6e46  movaps [rdi], xmm13
00007ac9d05d6e4a  movaps [rsi], xmm1
00007ac9d05d6e4d  movaps [rdx], xmm15
00007ac9d05d6e51  movaps [rcx], xmm14
00007ac9d05d6e55  mov rax, 0x569AF9F93A50
00007ac9d05d6e5f  call rax
00007ac9d05d6e61  movaps xmm13, [rsp]
00007ac9d05d6e66  add rsp, 0x40
00007ac9d05d6e6a  vmovaps xmm0, [rsp]
00007ac9d05d6e6f  vmovaps xmm1, [rsp+0x10]
00007ac9d05d6e75  vmovaps xmm2, [rsp+0x20]
00007ac9d05d6e7b  vmovaps xmm3, [rsp+0x30]
00007ac9d05d6e81  vmovaps xmm4, [rsp+0x40]
00007ac9d05d6e87  vmovaps xmm5, [rsp+0x50]
00007ac9d05d6e8d  vmovaps xmm6, [rsp+0x60]
00007ac9d05d6e93  vmovaps xmm7, [rsp+0x70]
00007ac9d05d6e99  vmovaps xmm8, [rsp+0x80]
00007ac9d05d6ea2  vmovaps xmm9, [rsp+0x90]
00007ac9d05d6eab  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d6eb4  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d6ebd  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d6ec6  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d6ecf  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d6ed8  add rsp, 0xF0
00007ac9d05d6edf  pop r11
00007ac9d05d6ee1  pop r10
00007ac9d05d6ee3  pop r9
00007ac9d05d6ee5  pop r8
00007ac9d05d6ee7  pop rsi
00007ac9d05d6ee8  pop rdi
00007ac9d05d6ee9  pop rdx
00007ac9d05d6eea  pop rcx
00007ac9d05d6eeb  pop rax
00007ac9d05d6eec  add rsp, 0x08
00007ac9d05d6ef0  jmp 0x00007AC9D05D6305
00007ac9d05d6ef5  sub rsp, 0x08
00007ac9d05d6ef9  push rax
00007ac9d05d6efa  push rcx
00007ac9d05d6efb  push rdx
00007ac9d05d6efc  push rdi
00007ac9d05d6efd  push rsi
00007ac9d05d6efe  push r8
00007ac9d05d6f00  push r9
00007ac9d05d6f02  push r10
00007ac9d05d6f04  push r11
00007ac9d05d6f06  sub rsp, 0xF0
00007ac9d05d6f0d  vmovaps [rsp], xmm0
00007ac9d05d6f12  vmovaps [rsp+0x10], xmm1
00007ac9d05d6f18  vmovaps [rsp+0x20], xmm2
00007ac9d05d6f1e  vmovaps [rsp+0x30], xmm3
00007ac9d05d6f24  vmovaps [rsp+0x40], xmm4
00007ac9d05d6f2a  vmovaps [rsp+0x50], xmm5
00007ac9d05d6f30  vmovaps [rsp+0x60], xmm6
00007ac9d05d6f36  vmovaps [rsp+0x70], xmm7
00007ac9d05d6f3c  vmovaps [rsp+0x80], xmm8
00007ac9d05d6f45  vmovaps [rsp+0x90], xmm9
00007ac9d05d6f4e  vmovaps [rsp+0xA0], xmm10
00007ac9d05d6f57  vmovaps [rsp+0xB0], xmm11
00007ac9d05d6f60  vmovaps [rsp+0xC0], xmm13
00007ac9d05d6f69  vmovaps [rsp+0xD0], xmm14
00007ac9d05d6f72  vmovaps [rsp+0xE0], xmm15
00007ac9d05d6f7b  sub rsp, 0x40
00007ac9d05d6f7f  lea rdi, [rsp]
00007ac9d05d6f83  lea rsi, [rsp+0x10]
00007ac9d05d6f88  lea rdx, [rsp+0x20]
00007ac9d05d6f8d  lea rcx, [rsp+0x30]
00007ac9d05d6f92  mov r8d, 0x00
00007ac9d05d6f98  lea r9, [r15+0x3A8]
00007ac9d05d6f9f  movaps [rdi], xmm12
00007ac9d05d6fa3  movaps [rsi], xmm15
00007ac9d05d6fa7  movaps [rdx], xmm1
00007ac9d05d6faa  movaps [rcx], xmm14
00007ac9d05d6fae  mov rax, 0x569AF9F93A50
00007ac9d05d6fb8  call rax
00007ac9d05d6fba  movaps xmm12, [rsp]
00007ac9d05d6fbf  add rsp, 0x40
00007ac9d05d6fc3  vmovaps xmm0, [rsp]
00007ac9d05d6fc8  vmovaps xmm1, [rsp+0x10]
00007ac9d05d6fce  vmovaps xmm2, [rsp+0x20]
00007ac9d05d6fd4  vmovaps xmm3, [rsp+0x30]
00007ac9d05d6fda  vmovaps xmm4, [rsp+0x40]
00007ac9d05d6fe0  vmovaps xmm5, [rsp+0x50]
00007ac9d05d6fe6  vmovaps xmm6, [rsp+0x60]
00007ac9d05d6fec  vmovaps xmm7, [rsp+0x70]
00007ac9d05d6ff2  vmovaps xmm8, [rsp+0x80]
00007ac9d05d6ffb  vmovaps xmm9, [rsp+0x90]
00007ac9d05d7004  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d700d  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d7016  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d701f  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d7028  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d7031  add rsp, 0xF0
00007ac9d05d7038  pop r11
00007ac9d05d703a  pop r10
00007ac9d05d703c  pop r9
00007ac9d05d703e  pop r8
00007ac9d05d7040  pop rsi
00007ac9d05d7041  pop rdi
00007ac9d05d7042  pop rdx
00007ac9d05d7043  pop rcx
00007ac9d05d7044  pop rax
00007ac9d05d7045  add rsp, 0x08
00007ac9d05d7049  jmp 0x00007AC9D05D6333
00007ac9d05d704e  call 0x00007AC9D04D64F0
00007ac9d05d7053  jmp 0x00007AC9D05D641F
00007ac9d05d7058  sub rsp, 0x08
00007ac9d05d705c  push rax
00007ac9d05d705d  push rcx
00007ac9d05d705e  push rdx
00007ac9d05d705f  push rdi
00007ac9d05d7060  push rsi
00007ac9d05d7061  push r8
00007ac9d05d7063  push r9
00007ac9d05d7065  push r10
00007ac9d05d7067  push r11
00007ac9d05d7069  sub rsp, 0xF0
00007ac9d05d7070  vmovaps [rsp], xmm0
00007ac9d05d7075  vmovaps [rsp+0x10], xmm1
00007ac9d05d707b  vmovaps [rsp+0x20], xmm2
00007ac9d05d7081  vmovaps [rsp+0x30], xmm3
00007ac9d05d7087  vmovaps [rsp+0x40], xmm4
00007ac9d05d708d  vmovaps [rsp+0x50], xmm5
00007ac9d05d7093  vmovaps [rsp+0x60], xmm6
00007ac9d05d7099  vmovaps [rsp+0x70], xmm7
00007ac9d05d709f  vmovaps [rsp+0x80], xmm8
00007ac9d05d70a8  vmovaps [rsp+0x90], xmm9
00007ac9d05d70b1  vmovaps [rsp+0xA0], xmm10
00007ac9d05d70ba  vmovaps [rsp+0xB0], xmm11
00007ac9d05d70c3  vmovaps [rsp+0xC0], xmm12
00007ac9d05d70cc  vmovaps [rsp+0xD0], xmm14
00007ac9d05d70d5  vmovaps [rsp+0xE0], xmm15
00007ac9d05d70de  sub rsp, 0x40
00007ac9d05d70e2  lea rdi, [rsp]
00007ac9d05d70e6  lea rsi, [rsp+0x10]
00007ac9d05d70eb  lea rdx, [rsp+0x20]
00007ac9d05d70f0  lea rcx, [rsp+0x30]
00007ac9d05d70f5  mov r8d, 0x00
00007ac9d05d70fb  lea r9, [r15+0x3A8]
00007ac9d05d7102  movaps [rdi], xmm13
00007ac9d05d7106  movaps [rsi], xmm1
00007ac9d05d7109  movaps [rdx], xmm15
00007ac9d05d710d  movaps [rcx], xmm14
00007ac9d05d7111  mov rax, 0x569AF9F93A50
00007ac9d05d711b  call rax
00007ac9d05d711d  movaps xmm13, [rsp]
00007ac9d05d7122  add rsp, 0x40
00007ac9d05d7126  vmovaps xmm0, [rsp]
00007ac9d05d712b  vmovaps xmm1, [rsp+0x10]
00007ac9d05d7131  vmovaps xmm2, [rsp+0x20]
00007ac9d05d7137  vmovaps xmm3, [rsp+0x30]
00007ac9d05d713d  vmovaps xmm4, [rsp+0x40]
00007ac9d05d7143  vmovaps xmm5, [rsp+0x50]
00007ac9d05d7149  vmovaps xmm6, [rsp+0x60]
00007ac9d05d714f  vmovaps xmm7, [rsp+0x70]
00007ac9d05d7155  vmovaps xmm8, [rsp+0x80]
00007ac9d05d715e  vmovaps xmm9, [rsp+0x90]
00007ac9d05d7167  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d7170  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d7179  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d7182  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d718b  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d7194  add rsp, 0xF0
00007ac9d05d719b  pop r11
00007ac9d05d719d  pop r10
00007ac9d05d719f  pop r9
00007ac9d05d71a1  pop r8
00007ac9d05d71a3  pop rsi
00007ac9d05d71a4  pop rdi
00007ac9d05d71a5  pop rdx
00007ac9d05d71a6  pop rcx
00007ac9d05d71a7  pop rax
00007ac9d05d71a8  add rsp, 0x08
00007ac9d05d71ac  jmp 0x00007AC9D05D648E
00007ac9d05d71b1  call 0x00007AC9D04D64F0
00007ac9d05d71b6  jmp 0x00007AC9D05D64A3
00007ac9d05d71bb  sub rsp, 0x08
00007ac9d05d71bf  push rax
00007ac9d05d71c0  push rcx
00007ac9d05d71c1  push rdx
00007ac9d05d71c2  push rdi
00007ac9d05d71c3  push rsi
00007ac9d05d71c4  push r8
00007ac9d05d71c6  push r9
00007ac9d05d71c8  push r10
00007ac9d05d71ca  push r11
00007ac9d05d71cc  sub rsp, 0xF0
00007ac9d05d71d3  vmovaps [rsp], xmm0
00007ac9d05d71d8  vmovaps [rsp+0x10], xmm1
00007ac9d05d71de  vmovaps [rsp+0x20], xmm2
00007ac9d05d71e4  vmovaps [rsp+0x30], xmm3
00007ac9d05d71ea  vmovaps [rsp+0x40], xmm4
00007ac9d05d71f0  vmovaps [rsp+0x50], xmm5
00007ac9d05d71f6  vmovaps [rsp+0x60], xmm6
00007ac9d05d71fc  vmovaps [rsp+0x70], xmm7
00007ac9d05d7202  vmovaps [rsp+0x80], xmm8
00007ac9d05d720b  vmovaps [rsp+0x90], xmm9
00007ac9d05d7214  vmovaps [rsp+0xA0], xmm10
00007ac9d05d721d  vmovaps [rsp+0xB0], xmm11
00007ac9d05d7226  vmovaps [rsp+0xC0], xmm13
00007ac9d05d722f  vmovaps [rsp+0xD0], xmm14
00007ac9d05d7238  vmovaps [rsp+0xE0], xmm15
00007ac9d05d7241  sub rsp, 0x40
00007ac9d05d7245  lea rdi, [rsp]
00007ac9d05d7249  lea rsi, [rsp+0x10]
00007ac9d05d724e  lea rdx, [rsp+0x20]
00007ac9d05d7253  lea rcx, [rsp+0x30]
00007ac9d05d7258  mov r8d, 0x00
00007ac9d05d725e  lea r9, [r15+0x3A8]
00007ac9d05d7265  movaps [rdi], xmm12
00007ac9d05d7269  movaps [rsi], xmm15
00007ac9d05d726d  movaps [rdx], xmm1
00007ac9d05d7270  movaps [rcx], xmm14
00007ac9d05d7274  mov rax, 0x569AF9F93A50
00007ac9d05d727e  call rax
00007ac9d05d7280  movaps xmm12, [rsp]
00007ac9d05d7285  add rsp, 0x40
00007ac9d05d7289  vmovaps xmm0, [rsp]
00007ac9d05d728e  vmovaps xmm1, [rsp+0x10]
00007ac9d05d7294  vmovaps xmm2, [rsp+0x20]
00007ac9d05d729a  vmovaps xmm3, [rsp+0x30]
00007ac9d05d72a0  vmovaps xmm4, [rsp+0x40]
00007ac9d05d72a6  vmovaps xmm5, [rsp+0x50]
00007ac9d05d72ac  vmovaps xmm6, [rsp+0x60]
00007ac9d05d72b2  vmovaps xmm7, [rsp+0x70]
00007ac9d05d72b8  vmovaps xmm8, [rsp+0x80]
00007ac9d05d72c1  vmovaps xmm9, [rsp+0x90]
00007ac9d05d72ca  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d72d3  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d72dc  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d72e5  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d72ee  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d72f7  add rsp, 0xF0
00007ac9d05d72fe  pop r11
00007ac9d05d7300  pop r10
00007ac9d05d7302  pop r9
00007ac9d05d7304  pop r8
00007ac9d05d7306  pop rsi
00007ac9d05d7307  pop rdi
00007ac9d05d7308  pop rdx
00007ac9d05d7309  pop rcx
00007ac9d05d730a  pop rax
00007ac9d05d730b  add rsp, 0x08
00007ac9d05d730f  jmp 0x00007AC9D05D64CF
00007ac9d05d7314  sub rsp, 0x08
00007ac9d05d7318  push rax
00007ac9d05d7319  push rcx
00007ac9d05d731a  push rdx
00007ac9d05d731b  push rdi
00007ac9d05d731c  push rsi
00007ac9d05d731d  push r8
00007ac9d05d731f  push r9
00007ac9d05d7321  push r10
00007ac9d05d7323  push r11
00007ac9d05d7325  sub rsp, 0xF0
00007ac9d05d732c  vmovaps [rsp], xmm0
00007ac9d05d7331  vmovaps [rsp+0x10], xmm1
00007ac9d05d7337  vmovaps [rsp+0x20], xmm2
00007ac9d05d733d  vmovaps [rsp+0x30], xmm3
00007ac9d05d7343  vmovaps [rsp+0x40], xmm4
00007ac9d05d7349  vmovaps [rsp+0x50], xmm5
00007ac9d05d734f  vmovaps [rsp+0x60], xmm6
00007ac9d05d7355  vmovaps [rsp+0x70], xmm7
00007ac9d05d735b  vmovaps [rsp+0x80], xmm8
00007ac9d05d7364  vmovaps [rsp+0x90], xmm9
00007ac9d05d736d  vmovaps [rsp+0xA0], xmm10
00007ac9d05d7376  vmovaps [rsp+0xB0], xmm11
00007ac9d05d737f  vmovaps [rsp+0xC0], xmm12
00007ac9d05d7388  vmovaps [rsp+0xD0], xmm14
00007ac9d05d7391  vmovaps [rsp+0xE0], xmm15
00007ac9d05d739a  sub rsp, 0x40
00007ac9d05d739e  lea rdi, [rsp]
00007ac9d05d73a2  lea rsi, [rsp+0x10]
00007ac9d05d73a7  lea rdx, [rsp+0x20]
00007ac9d05d73ac  lea rcx, [rsp+0x30]
00007ac9d05d73b1  mov r8d, 0x00
00007ac9d05d73b7  lea r9, [r15+0x3A8]
00007ac9d05d73be  movaps [rdi], xmm13
00007ac9d05d73c2  movaps [rsi], xmm1
00007ac9d05d73c5  movaps [rdx], xmm15
00007ac9d05d73c9  movaps [rcx], xmm14
00007ac9d05d73cd  mov rax, 0x569AF9F93A50
00007ac9d05d73d7  call rax
00007ac9d05d73d9  movaps xmm13, [rsp]
00007ac9d05d73de  add rsp, 0x40
00007ac9d05d73e2  vmovaps xmm0, [rsp]
00007ac9d05d73e7  vmovaps xmm1, [rsp+0x10]
00007ac9d05d73ed  vmovaps xmm2, [rsp+0x20]
00007ac9d05d73f3  vmovaps xmm3, [rsp+0x30]
00007ac9d05d73f9  vmovaps xmm4, [rsp+0x40]
00007ac9d05d73ff  vmovaps xmm5, [rsp+0x50]
00007ac9d05d7405  vmovaps xmm6, [rsp+0x60]
00007ac9d05d740b  vmovaps xmm7, [rsp+0x70]
00007ac9d05d7411  vmovaps xmm8, [rsp+0x80]
00007ac9d05d741a  vmovaps xmm9, [rsp+0x90]
00007ac9d05d7423  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d742c  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d7435  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d743e  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d7447  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d7450  add rsp, 0xF0
00007ac9d05d7457  pop r11
00007ac9d05d7459  pop r10
00007ac9d05d745b  pop r9
00007ac9d05d745d  pop r8
00007ac9d05d745f  pop rsi
00007ac9d05d7460  pop rdi
00007ac9d05d7461  pop rdx
00007ac9d05d7462  pop rcx
00007ac9d05d7463  pop rax
00007ac9d05d7464  add rsp, 0x08
00007ac9d05d7468  jmp 0x00007AC9D05D665F
00007ac9d05d746d  sub rsp, 0x08
00007ac9d05d7471  push rax
00007ac9d05d7472  push rcx
00007ac9d05d7473  push rdx
00007ac9d05d7474  push rdi
00007ac9d05d7475  push rsi
00007ac9d05d7476  push r8
00007ac9d05d7478  push r9
00007ac9d05d747a  push r10
00007ac9d05d747c  push r11
00007ac9d05d747e  sub rsp, 0xF0
00007ac9d05d7485  vmovaps [rsp], xmm0
00007ac9d05d748a  vmovaps [rsp+0x10], xmm1
00007ac9d05d7490  vmovaps [rsp+0x20], xmm2
00007ac9d05d7496  vmovaps [rsp+0x30], xmm3
00007ac9d05d749c  vmovaps [rsp+0x40], xmm4
00007ac9d05d74a2  vmovaps [rsp+0x50], xmm5
00007ac9d05d74a8  vmovaps [rsp+0x60], xmm6
00007ac9d05d74ae  vmovaps [rsp+0x70], xmm7
00007ac9d05d74b4  vmovaps [rsp+0x80], xmm8
00007ac9d05d74bd  vmovaps [rsp+0x90], xmm9
00007ac9d05d74c6  vmovaps [rsp+0xA0], xmm10
00007ac9d05d74cf  vmovaps [rsp+0xB0], xmm11
00007ac9d05d74d8  vmovaps [rsp+0xC0], xmm12
00007ac9d05d74e1  vmovaps [rsp+0xD0], xmm13
00007ac9d05d74ea  vmovaps [rsp+0xE0], xmm15
00007ac9d05d74f3  sub rsp, 0x40
00007ac9d05d74f7  lea rdi, [rsp]
00007ac9d05d74fb  lea rsi, [rsp+0x10]
00007ac9d05d7500  lea rdx, [rsp+0x20]
00007ac9d05d7505  lea rcx, [rsp+0x30]
00007ac9d05d750a  mov r8d, 0x00
00007ac9d05d7510  lea r9, [r15+0x3A8]
00007ac9d05d7517  movaps [rdi], xmm14
00007ac9d05d751b  movaps [rsi], xmm15
00007ac9d05d751f  movaps [rdx], xmm2
00007ac9d05d7522  movaps [rcx], xmm1
00007ac9d05d7525  mov rax, 0x569AF9F93A50
00007ac9d05d752f  call rax
00007ac9d05d7531  movaps xmm14, [rsp]
00007ac9d05d7536  add rsp, 0x40
00007ac9d05d753a  vmovaps xmm0, [rsp]
00007ac9d05d753f  vmovaps xmm1, [rsp+0x10]
00007ac9d05d7545  vmovaps xmm2, [rsp+0x20]
00007ac9d05d754b  vmovaps xmm3, [rsp+0x30]
00007ac9d05d7551  vmovaps xmm4, [rsp+0x40]
00007ac9d05d7557  vmovaps xmm5, [rsp+0x50]
00007ac9d05d755d  vmovaps xmm6, [rsp+0x60]
00007ac9d05d7563  vmovaps xmm7, [rsp+0x70]
00007ac9d05d7569  vmovaps xmm8, [rsp+0x80]
00007ac9d05d7572  vmovaps xmm9, [rsp+0x90]
00007ac9d05d757b  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d7584  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d758d  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d7596  vmovaps xmm13, [rsp+0xD0]
00007ac9d05d759f  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d75a8  add rsp, 0xF0
00007ac9d05d75af  pop r11
00007ac9d05d75b1  pop r10
00007ac9d05d75b3  pop r9
00007ac9d05d75b5  pop r8
00007ac9d05d75b7  pop rsi
00007ac9d05d75b8  pop rdi
00007ac9d05d75b9  pop rdx
00007ac9d05d75ba  pop rcx
00007ac9d05d75bb  pop rax
00007ac9d05d75bc  add rsp, 0x08
00007ac9d05d75c0  jmp 0x00007AC9D05D6691
00007ac9d05d75c5  sub rsp, 0x08
00007ac9d05d75c9  push rax
00007ac9d05d75ca  push rcx
00007ac9d05d75cb  push rdx
00007ac9d05d75cc  push rdi
00007ac9d05d75cd  push rsi
00007ac9d05d75ce  push r8
00007ac9d05d75d0  push r9
00007ac9d05d75d2  push r10
00007ac9d05d75d4  push r11
00007ac9d05d75d6  sub rsp, 0xF0
00007ac9d05d75dd  vmovaps [rsp], xmm0
00007ac9d05d75e2  vmovaps [rsp+0x10], xmm1
00007ac9d05d75e8  vmovaps [rsp+0x20], xmm3
00007ac9d05d75ee  vmovaps [rsp+0x30], xmm4
00007ac9d05d75f4  vmovaps [rsp+0x40], xmm5
00007ac9d05d75fa  vmovaps [rsp+0x50], xmm6
00007ac9d05d7600  vmovaps [rsp+0x60], xmm7
00007ac9d05d7606  vmovaps [rsp+0x70], xmm8
00007ac9d05d760c  vmovaps [rsp+0x80], xmm9
00007ac9d05d7615  vmovaps [rsp+0x90], xmm10
00007ac9d05d761e  vmovaps [rsp+0xA0], xmm11
00007ac9d05d7627  vmovaps [rsp+0xB0], xmm12
00007ac9d05d7630  vmovaps [rsp+0xC0], xmm13
00007ac9d05d7639  vmovaps [rsp+0xD0], xmm14
00007ac9d05d7642  vmovaps [rsp+0xE0], xmm15
00007ac9d05d764b  sub rsp, 0x40
00007ac9d05d764f  lea rdi, [rsp]
00007ac9d05d7653  lea rsi, [rsp+0x10]
00007ac9d05d7658  lea rdx, [rsp+0x20]
00007ac9d05d765d  lea rcx, [rsp+0x30]
00007ac9d05d7662  mov r8d, 0x00
00007ac9d05d7668  lea r9, [r15+0x3A8]
00007ac9d05d766f  movaps [rdi], xmm2
00007ac9d05d7672  movaps [rsi], xmm15
00007ac9d05d7676  movaps [rdx], xmm12
00007ac9d05d767a  movaps [rcx], xmm1
00007ac9d05d767d  mov rax, 0x569AF9F93A50
00007ac9d05d7687  call rax
00007ac9d05d7689  movaps xmm2, [rsp]
00007ac9d05d768d  add rsp, 0x40
00007ac9d05d7691  vmovaps xmm0, [rsp]
00007ac9d05d7696  vmovaps xmm1, [rsp+0x10]
00007ac9d05d769c  vmovaps xmm3, [rsp+0x20]
00007ac9d05d76a2  vmovaps xmm4, [rsp+0x30]
00007ac9d05d76a8  vmovaps xmm5, [rsp+0x40]
00007ac9d05d76ae  vmovaps xmm6, [rsp+0x50]
00007ac9d05d76b4  vmovaps xmm7, [rsp+0x60]
00007ac9d05d76ba  vmovaps xmm8, [rsp+0x70]
00007ac9d05d76c0  vmovaps xmm9, [rsp+0x80]
00007ac9d05d76c9  vmovaps xmm10, [rsp+0x90]
00007ac9d05d76d2  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d76db  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d76e4  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d76ed  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d76f6  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d76ff  add rsp, 0xF0
00007ac9d05d7706  pop r11
00007ac9d05d7708  pop r10
00007ac9d05d770a  pop r9
00007ac9d05d770c  pop r8
00007ac9d05d770e  pop rsi
00007ac9d05d770f  pop rdi
00007ac9d05d7710  pop rdx
00007ac9d05d7711  pop rcx
00007ac9d05d7712  pop rax
00007ac9d05d7713  add rsp, 0x08
00007ac9d05d7717  jmp 0x00007AC9D05D66CE
00007ac9d05d771c  sub rsp, 0x08
00007ac9d05d7720  push rax
00007ac9d05d7721  push rcx
00007ac9d05d7722  push rdx
00007ac9d05d7723  push rdi
00007ac9d05d7724  push rsi
00007ac9d05d7725  push r8
00007ac9d05d7727  push r9
00007ac9d05d7729  push r10
00007ac9d05d772b  push r11
00007ac9d05d772d  sub rsp, 0xF0
00007ac9d05d7734  vmovaps [rsp], xmm0
00007ac9d05d7739  vmovaps [rsp+0x10], xmm1
00007ac9d05d773f  vmovaps [rsp+0x20], xmm2
00007ac9d05d7745  vmovaps [rsp+0x30], xmm3
00007ac9d05d774b  vmovaps [rsp+0x40], xmm4
00007ac9d05d7751  vmovaps [rsp+0x50], xmm5
00007ac9d05d7757  vmovaps [rsp+0x60], xmm6
00007ac9d05d775d  vmovaps [rsp+0x70], xmm7
00007ac9d05d7763  vmovaps [rsp+0x80], xmm8
00007ac9d05d776c  vmovaps [rsp+0x90], xmm9
00007ac9d05d7775  vmovaps [rsp+0xA0], xmm10
00007ac9d05d777e  vmovaps [rsp+0xB0], xmm11
00007ac9d05d7787  vmovaps [rsp+0xC0], xmm13
00007ac9d05d7790  vmovaps [rsp+0xD0], xmm14
00007ac9d05d7799  vmovaps [rsp+0xE0], xmm15
00007ac9d05d77a2  sub rsp, 0x40
00007ac9d05d77a6  lea rdi, [rsp]
00007ac9d05d77aa  lea rsi, [rsp+0x10]
00007ac9d05d77af  lea rdx, [rsp+0x20]
00007ac9d05d77b4  lea rcx, [rsp+0x30]
00007ac9d05d77b9  mov r8d, 0x00
00007ac9d05d77bf  lea r9, [r15+0x3A8]
00007ac9d05d77c6  movaps [rdi], xmm12
00007ac9d05d77ca  movaps [rsi], xmm14
00007ac9d05d77ce  movaps [rdx], xmm3
00007ac9d05d77d1  movaps [rcx], xmm15
00007ac9d05d77d5  mov rax, 0x569AF9F93A50
00007ac9d05d77df  call rax
00007ac9d05d77e1  movaps xmm12, [rsp]
00007ac9d05d77e6  add rsp, 0x40
00007ac9d05d77ea  vmovaps xmm0, [rsp]
00007ac9d05d77ef  vmovaps xmm1, [rsp+0x10]
00007ac9d05d77f5  vmovaps xmm2, [rsp+0x20]
00007ac9d05d77fb  vmovaps xmm3, [rsp+0x30]
00007ac9d05d7801  vmovaps xmm4, [rsp+0x40]
00007ac9d05d7807  vmovaps xmm5, [rsp+0x50]
00007ac9d05d780d  vmovaps xmm6, [rsp+0x60]
00007ac9d05d7813  vmovaps xmm7, [rsp+0x70]
00007ac9d05d7819  vmovaps xmm8, [rsp+0x80]
00007ac9d05d7822  vmovaps xmm9, [rsp+0x90]
00007ac9d05d782b  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d7834  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d783d  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d7846  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d784f  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d7858  add rsp, 0xF0
00007ac9d05d785f  pop r11
00007ac9d05d7861  pop r10
00007ac9d05d7863  pop r9
00007ac9d05d7865  pop r8
00007ac9d05d7867  pop rsi
00007ac9d05d7868  pop rdi
00007ac9d05d7869  pop rdx
00007ac9d05d786a  pop rcx
00007ac9d05d786b  pop rax
00007ac9d05d786c  add rsp, 0x08
00007ac9d05d7870  jmp 0x00007AC9D05D6728
00007ac9d05d7875  sub rsp, 0x08
00007ac9d05d7879  push rax
00007ac9d05d787a  push rcx
00007ac9d05d787b  push rdx
00007ac9d05d787c  push rdi
00007ac9d05d787d  push rsi
00007ac9d05d787e  push r8
00007ac9d05d7880  push r9
00007ac9d05d7882  push r10
00007ac9d05d7884  push r11
00007ac9d05d7886  sub rsp, 0xF0
00007ac9d05d788d  vmovaps [rsp], xmm0
00007ac9d05d7892  vmovaps [rsp+0x10], xmm1
00007ac9d05d7898  vmovaps [rsp+0x20], xmm2
00007ac9d05d789e  vmovaps [rsp+0x30], xmm3
00007ac9d05d78a4  vmovaps [rsp+0x40], xmm4
00007ac9d05d78aa  vmovaps [rsp+0x50], xmm5
00007ac9d05d78b0  vmovaps [rsp+0x60], xmm6
00007ac9d05d78b6  vmovaps [rsp+0x70], xmm7
00007ac9d05d78bc  vmovaps [rsp+0x80], xmm8
00007ac9d05d78c5  vmovaps [rsp+0x90], xmm10
00007ac9d05d78ce  vmovaps [rsp+0xA0], xmm11
00007ac9d05d78d7  vmovaps [rsp+0xB0], xmm12
00007ac9d05d78e0  vmovaps [rsp+0xC0], xmm13
00007ac9d05d78e9  vmovaps [rsp+0xD0], xmm14
00007ac9d05d78f2  vmovaps [rsp+0xE0], xmm15
00007ac9d05d78fb  sub rsp, 0x40
00007ac9d05d78ff  lea rdi, [rsp]
00007ac9d05d7903  lea rsi, [rsp+0x10]
00007ac9d05d7908  lea rdx, [rsp+0x20]
00007ac9d05d790d  lea rcx, [rsp+0x30]
00007ac9d05d7912  mov r8d, 0x00
00007ac9d05d7918  lea r9, [r15+0x3A8]
00007ac9d05d791f  movaps [rdi], xmm9
00007ac9d05d7923  movaps [rsi], xmm13
00007ac9d05d7927  movaps [rdx], xmm14
00007ac9d05d792b  movaps [rcx], xmm6
00007ac9d05d792e  mov rax, 0x569AF9F93A50
00007ac9d05d7938  call rax
00007ac9d05d793a  movaps xmm9, [rsp]
00007ac9d05d793f  add rsp, 0x40
00007ac9d05d7943  vmovaps xmm0, [rsp]
00007ac9d05d7948  vmovaps xmm1, [rsp+0x10]
00007ac9d05d794e  vmovaps xmm2, [rsp+0x20]
00007ac9d05d7954  vmovaps xmm3, [rsp+0x30]
00007ac9d05d795a  vmovaps xmm4, [rsp+0x40]
00007ac9d05d7960  vmovaps xmm5, [rsp+0x50]
00007ac9d05d7966  vmovaps xmm6, [rsp+0x60]
00007ac9d05d796c  vmovaps xmm7, [rsp+0x70]
00007ac9d05d7972  vmovaps xmm8, [rsp+0x80]
00007ac9d05d797b  vmovaps xmm10, [rsp+0x90]
00007ac9d05d7984  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d798d  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d7996  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d799f  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d79a8  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d79b1  add rsp, 0xF0
00007ac9d05d79b8  pop r11
00007ac9d05d79ba  pop r10
00007ac9d05d79bc  pop r9
00007ac9d05d79be  pop r8
00007ac9d05d79c0  pop rsi
00007ac9d05d79c1  pop rdi
00007ac9d05d79c2  pop rdx
00007ac9d05d79c3  pop rcx
00007ac9d05d79c4  pop rax
00007ac9d05d79c5  add rsp, 0x08
00007ac9d05d79c9  jmp 0x00007AC9D05D67D2
00007ac9d05d79ce  sub rsp, 0x08
00007ac9d05d79d2  push rax
00007ac9d05d79d3  push rcx
00007ac9d05d79d4  push rdx
00007ac9d05d79d5  push rdi
00007ac9d05d79d6  push rsi
00007ac9d05d79d7  push r8
00007ac9d05d79d9  push r9
00007ac9d05d79db  push r10
00007ac9d05d79dd  push r11
00007ac9d05d79df  sub rsp, 0xF0
00007ac9d05d79e6  vmovaps [rsp], xmm0
00007ac9d05d79eb  vmovaps [rsp+0x10], xmm1
00007ac9d05d79f1  vmovaps [rsp+0x20], xmm2
00007ac9d05d79f7  vmovaps [rsp+0x30], xmm4
00007ac9d05d79fd  vmovaps [rsp+0x40], xmm5
00007ac9d05d7a03  vmovaps [rsp+0x50], xmm6
00007ac9d05d7a09  vmovaps [rsp+0x60], xmm7
00007ac9d05d7a0f  vmovaps [rsp+0x70], xmm8
00007ac9d05d7a15  vmovaps [rsp+0x80], xmm9
00007ac9d05d7a1e  vmovaps [rsp+0x90], xmm10
00007ac9d05d7a27  vmovaps [rsp+0xA0], xmm11
00007ac9d05d7a30  vmovaps [rsp+0xB0], xmm12
00007ac9d05d7a39  vmovaps [rsp+0xC0], xmm13
00007ac9d05d7a42  vmovaps [rsp+0xD0], xmm14
00007ac9d05d7a4b  vmovaps [rsp+0xE0], xmm15
00007ac9d05d7a54  sub rsp, 0x40
00007ac9d05d7a58  lea rdi, [rsp]
00007ac9d05d7a5c  lea rsi, [rsp+0x10]
00007ac9d05d7a61  lea rdx, [rsp+0x20]
00007ac9d05d7a66  lea rcx, [rsp+0x30]
00007ac9d05d7a6b  mov r8d, 0x00
00007ac9d05d7a71  lea r9, [r15+0x3A8]
00007ac9d05d7a78  movaps [rdi], xmm3
00007ac9d05d7a7b  movaps [rsi], xmm13
00007ac9d05d7a7f  movaps [rdx], xmm6
00007ac9d05d7a82  movaps [rcx], xmm14
00007ac9d05d7a86  mov rax, 0x569AF9F93A50
00007ac9d05d7a90  call rax
00007ac9d05d7a92  movaps xmm3, [rsp]
00007ac9d05d7a96  add rsp, 0x40
00007ac9d05d7a9a  vmovaps xmm0, [rsp]
00007ac9d05d7a9f  vmovaps xmm1, [rsp+0x10]
00007ac9d05d7aa5  vmovaps xmm2, [rsp+0x20]
00007ac9d05d7aab  vmovaps xmm4, [rsp+0x30]
00007ac9d05d7ab1  vmovaps xmm5, [rsp+0x40]
00007ac9d05d7ab7  vmovaps xmm6, [rsp+0x50]
00007ac9d05d7abd  vmovaps xmm7, [rsp+0x60]
00007ac9d05d7ac3  vmovaps xmm8, [rsp+0x70]
00007ac9d05d7ac9  vmovaps xmm9, [rsp+0x80]
00007ac9d05d7ad2  vmovaps xmm10, [rsp+0x90]
00007ac9d05d7adb  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d7ae4  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d7aed  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d7af6  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d7aff  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d7b08  add rsp, 0xF0
00007ac9d05d7b0f  pop r11
00007ac9d05d7b11  pop r10
00007ac9d05d7b13  pop r9
00007ac9d05d7b15  pop r8
00007ac9d05d7b17  pop rsi
00007ac9d05d7b18  pop rdi
00007ac9d05d7b19  pop rdx
00007ac9d05d7b1a  pop rcx
00007ac9d05d7b1b  pop rax
00007ac9d05d7b1c  add rsp, 0x08
00007ac9d05d7b20  jmp 0x00007AC9D05D680F
00007ac9d05d7b25  sub rsp, 0x08
00007ac9d05d7b29  push rax
00007ac9d05d7b2a  push rcx
00007ac9d05d7b2b  push rdx
00007ac9d05d7b2c  push rdi
00007ac9d05d7b2d  push rsi
00007ac9d05d7b2e  push r8
00007ac9d05d7b30  push r9
00007ac9d05d7b32  push r10
00007ac9d05d7b34  push r11
00007ac9d05d7b36  sub rsp, 0xF0
00007ac9d05d7b3d  vmovaps [rsp], xmm0
00007ac9d05d7b42  vmovaps [rsp+0x10], xmm1
00007ac9d05d7b48  vmovaps [rsp+0x20], xmm2
00007ac9d05d7b4e  vmovaps [rsp+0x30], xmm3
00007ac9d05d7b54  vmovaps [rsp+0x40], xmm4
00007ac9d05d7b5a  vmovaps [rsp+0x50], xmm5
00007ac9d05d7b60  vmovaps [rsp+0x60], xmm7
00007ac9d05d7b66  vmovaps [rsp+0x70], xmm8
00007ac9d05d7b6c  vmovaps [rsp+0x80], xmm9
00007ac9d05d7b75  vmovaps [rsp+0x90], xmm10
00007ac9d05d7b7e  vmovaps [rsp+0xA0], xmm11
00007ac9d05d7b87  vmovaps [rsp+0xB0], xmm12
00007ac9d05d7b90  vmovaps [rsp+0xC0], xmm13
00007ac9d05d7b99  vmovaps [rsp+0xD0], xmm14
00007ac9d05d7ba2  vmovaps [rsp+0xE0], xmm15
00007ac9d05d7bab  sub rsp, 0x40
00007ac9d05d7baf  lea rdi, [rsp]
00007ac9d05d7bb3  lea rsi, [rsp+0x10]
00007ac9d05d7bb8  lea rdx, [rsp+0x20]
00007ac9d05d7bbd  lea rcx, [rsp+0x30]
00007ac9d05d7bc2  mov r8d, 0x00
00007ac9d05d7bc8  lea r9, [r15+0x3A8]
00007ac9d05d7bcf  movaps [rdi], xmm6
00007ac9d05d7bd2  movaps [rsi], xmm2
00007ac9d05d7bd5  movaps [rdx], xmm14
00007ac9d05d7bd9  movaps [rcx], xmm1
00007ac9d05d7bdc  mov rax, 0x569AF9F93A50
00007ac9d05d7be6  call rax
00007ac9d05d7be8  movaps xmm6, [rsp]
00007ac9d05d7bec  add rsp, 0x40
00007ac9d05d7bf0  vmovaps xmm0, [rsp]
00007ac9d05d7bf5  vmovaps xmm1, [rsp+0x10]
00007ac9d05d7bfb  vmovaps xmm2, [rsp+0x20]
00007ac9d05d7c01  vmovaps xmm3, [rsp+0x30]
00007ac9d05d7c07  vmovaps xmm4, [rsp+0x40]
00007ac9d05d7c0d  vmovaps xmm5, [rsp+0x50]
00007ac9d05d7c13  vmovaps xmm7, [rsp+0x60]
00007ac9d05d7c19  vmovaps xmm8, [rsp+0x70]
00007ac9d05d7c1f  vmovaps xmm9, [rsp+0x80]
00007ac9d05d7c28  vmovaps xmm10, [rsp+0x90]
00007ac9d05d7c31  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d7c3a  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d7c43  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d7c4c  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d7c55  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d7c5e  add rsp, 0xF0
00007ac9d05d7c65  pop r11
00007ac9d05d7c67  pop r10
00007ac9d05d7c69  pop r9
00007ac9d05d7c6b  pop r8
00007ac9d05d7c6d  pop rsi
00007ac9d05d7c6e  pop rdi
00007ac9d05d7c6f  pop rdx
00007ac9d05d7c70  pop rcx
00007ac9d05d7c71  pop rax
00007ac9d05d7c72  add rsp, 0x08
00007ac9d05d7c76  jmp 0x00007AC9D05D683C
00007ac9d05d7c7b  sub rsp, 0x08
00007ac9d05d7c7f  push rax
00007ac9d05d7c80  push rcx
00007ac9d05d7c81  push rdx
00007ac9d05d7c82  push rdi
00007ac9d05d7c83  push rsi
00007ac9d05d7c84  push r8
00007ac9d05d7c86  push r9
00007ac9d05d7c88  push r10
00007ac9d05d7c8a  push r11
00007ac9d05d7c8c  sub rsp, 0xF0
00007ac9d05d7c93  vmovaps [rsp], xmm0
00007ac9d05d7c98  vmovaps [rsp+0x10], xmm1
00007ac9d05d7c9e  vmovaps [rsp+0x20], xmm2
00007ac9d05d7ca4  vmovaps [rsp+0x30], xmm3
00007ac9d05d7caa  vmovaps [rsp+0x40], xmm4
00007ac9d05d7cb0  vmovaps [rsp+0x50], xmm5
00007ac9d05d7cb6  vmovaps [rsp+0x60], xmm6
00007ac9d05d7cbc  vmovaps [rsp+0x70], xmm7
00007ac9d05d7cc2  vmovaps [rsp+0x80], xmm8
00007ac9d05d7ccb  vmovaps [rsp+0x90], xmm9
00007ac9d05d7cd4  vmovaps [rsp+0xA0], xmm10
00007ac9d05d7cdd  vmovaps [rsp+0xB0], xmm11
00007ac9d05d7ce6  vmovaps [rsp+0xC0], xmm12
00007ac9d05d7cef  vmovaps [rsp+0xD0], xmm14
00007ac9d05d7cf8  vmovaps [rsp+0xE0], xmm15
00007ac9d05d7d01  sub rsp, 0x40
00007ac9d05d7d05  lea rdi, [rsp]
00007ac9d05d7d09  lea rsi, [rsp+0x10]
00007ac9d05d7d0e  lea rdx, [rsp+0x20]
00007ac9d05d7d13  lea rcx, [rsp+0x30]
00007ac9d05d7d18  mov r8d, 0x00
00007ac9d05d7d1e  lea r9, [r15+0x3A8]
00007ac9d05d7d25  movaps [rdi], xmm13
00007ac9d05d7d29  movaps [rsi], xmm12
00007ac9d05d7d2d  movaps [rdx], xmm14
00007ac9d05d7d31  movaps [rcx], xmm1
00007ac9d05d7d34  mov rax, 0x569AF9F93A50
00007ac9d05d7d3e  call rax
00007ac9d05d7d40  movaps xmm13, [rsp]
00007ac9d05d7d45  add rsp, 0x40
00007ac9d05d7d49  vmovaps xmm0, [rsp]
00007ac9d05d7d4e  vmovaps xmm1, [rsp+0x10]
00007ac9d05d7d54  vmovaps xmm2, [rsp+0x20]
00007ac9d05d7d5a  vmovaps xmm3, [rsp+0x30]
00007ac9d05d7d60  vmovaps xmm4, [rsp+0x40]
00007ac9d05d7d66  vmovaps xmm5, [rsp+0x50]
00007ac9d05d7d6c  vmovaps xmm6, [rsp+0x60]
00007ac9d05d7d72  vmovaps xmm7, [rsp+0x70]
00007ac9d05d7d78  vmovaps xmm8, [rsp+0x80]
00007ac9d05d7d81  vmovaps xmm9, [rsp+0x90]
00007ac9d05d7d8a  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d7d93  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d7d9c  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d7da5  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d7dae  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d7db7  add rsp, 0xF0
00007ac9d05d7dbe  pop r11
00007ac9d05d7dc0  pop r10
00007ac9d05d7dc2  pop r9
00007ac9d05d7dc4  pop r8
00007ac9d05d7dc6  pop rsi
00007ac9d05d7dc7  pop rdi
00007ac9d05d7dc8  pop rdx
00007ac9d05d7dc9  pop rcx
00007ac9d05d7dca  pop rax
00007ac9d05d7dcb  add rsp, 0x08
00007ac9d05d7dcf  jmp 0x00007AC9D05D686E
00007ac9d05d7dd4  sub rsp, 0x08
00007ac9d05d7dd8  push rax
00007ac9d05d7dd9  push rcx
00007ac9d05d7dda  push rdx
00007ac9d05d7ddb  push rdi
00007ac9d05d7ddc  push rsi
00007ac9d05d7ddd  push r8
00007ac9d05d7ddf  push r9
00007ac9d05d7de1  push r10
00007ac9d05d7de3  push r11
00007ac9d05d7de5  sub rsp, 0xF0
00007ac9d05d7dec  vmovaps [rsp], xmm0
00007ac9d05d7df1  vmovaps [rsp+0x10], xmm1
00007ac9d05d7df7  vmovaps [rsp+0x20], xmm2
00007ac9d05d7dfd  vmovaps [rsp+0x30], xmm3
00007ac9d05d7e03  vmovaps [rsp+0x40], xmm4
00007ac9d05d7e09  vmovaps [rsp+0x50], xmm5
00007ac9d05d7e0f  vmovaps [rsp+0x60], xmm6
00007ac9d05d7e15  vmovaps [rsp+0x70], xmm7
00007ac9d05d7e1b  vmovaps [rsp+0x80], xmm8
00007ac9d05d7e24  vmovaps [rsp+0x90], xmm9
00007ac9d05d7e2d  vmovaps [rsp+0xA0], xmm10
00007ac9d05d7e36  vmovaps [rsp+0xB0], xmm11
00007ac9d05d7e3f  vmovaps [rsp+0xC0], xmm13
00007ac9d05d7e48  vmovaps [rsp+0xD0], xmm14
00007ac9d05d7e51  vmovaps [rsp+0xE0], xmm15
00007ac9d05d7e5a  sub rsp, 0x40
00007ac9d05d7e5e  lea rdi, [rsp]
00007ac9d05d7e62  lea rsi, [rsp+0x10]
00007ac9d05d7e67  lea rdx, [rsp+0x20]
00007ac9d05d7e6c  lea rcx, [rsp+0x30]
00007ac9d05d7e71  mov r8d, 0x00
00007ac9d05d7e77  lea r9, [r15+0x3A8]
00007ac9d05d7e7e  movaps [rdi], xmm12
00007ac9d05d7e82  movaps [rsi], xmm3
00007ac9d05d7e85  movaps [rdx], xmm14
00007ac9d05d7e89  movaps [rcx], xmm5
00007ac9d05d7e8c  mov rax, 0x569AF9F93A50
00007ac9d05d7e96  call rax
00007ac9d05d7e98  movaps xmm12, [rsp]
00007ac9d05d7e9d  add rsp, 0x40
00007ac9d05d7ea1  vmovaps xmm0, [rsp]
00007ac9d05d7ea6  vmovaps xmm1, [rsp+0x10]
00007ac9d05d7eac  vmovaps xmm2, [rsp+0x20]
00007ac9d05d7eb2  vmovaps xmm3, [rsp+0x30]
00007ac9d05d7eb8  vmovaps xmm4, [rsp+0x40]
00007ac9d05d7ebe  vmovaps xmm5, [rsp+0x50]
00007ac9d05d7ec4  vmovaps xmm6, [rsp+0x60]
00007ac9d05d7eca  vmovaps xmm7, [rsp+0x70]
00007ac9d05d7ed0  vmovaps xmm8, [rsp+0x80]
00007ac9d05d7ed9  vmovaps xmm9, [rsp+0x90]
00007ac9d05d7ee2  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d7eeb  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d7ef4  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d7efd  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d7f06  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d7f0f  add rsp, 0xF0
00007ac9d05d7f16  pop r11
00007ac9d05d7f18  pop r10
00007ac9d05d7f1a  pop r9
00007ac9d05d7f1c  pop r8
00007ac9d05d7f1e  pop rsi
00007ac9d05d7f1f  pop rdi
00007ac9d05d7f20  pop rdx
00007ac9d05d7f21  pop rcx
00007ac9d05d7f22  pop rax
00007ac9d05d7f23  add rsp, 0x08
00007ac9d05d7f27  jmp 0x00007AC9D05D68CB
00007ac9d05d7f2c  sub rsp, 0x08
00007ac9d05d7f30  push rax
00007ac9d05d7f31  push rcx
00007ac9d05d7f32  push rdx
00007ac9d05d7f33  push rdi
00007ac9d05d7f34  push rsi
00007ac9d05d7f35  push r8
00007ac9d05d7f37  push r9
00007ac9d05d7f39  push r10
00007ac9d05d7f3b  push r11
00007ac9d05d7f3d  sub rsp, 0xF0
00007ac9d05d7f44  vmovaps [rsp], xmm0
00007ac9d05d7f49  vmovaps [rsp+0x10], xmm1
00007ac9d05d7f4f  vmovaps [rsp+0x20], xmm2
00007ac9d05d7f55  vmovaps [rsp+0x30], xmm3
00007ac9d05d7f5b  vmovaps [rsp+0x40], xmm4
00007ac9d05d7f61  vmovaps [rsp+0x50], xmm5
00007ac9d05d7f67  vmovaps [rsp+0x60], xmm6
00007ac9d05d7f6d  vmovaps [rsp+0x70], xmm7
00007ac9d05d7f73  vmovaps [rsp+0x80], xmm8
00007ac9d05d7f7c  vmovaps [rsp+0x90], xmm9
00007ac9d05d7f85  vmovaps [rsp+0xA0], xmm11
00007ac9d05d7f8e  vmovaps [rsp+0xB0], xmm12
00007ac9d05d7f97  vmovaps [rsp+0xC0], xmm13
00007ac9d05d7fa0  vmovaps [rsp+0xD0], xmm14
00007ac9d05d7fa9  vmovaps [rsp+0xE0], xmm15
00007ac9d05d7fb2  sub rsp, 0x40
00007ac9d05d7fb6  lea rdi, [rsp]
00007ac9d05d7fba  lea rsi, [rsp+0x10]
00007ac9d05d7fbf  lea rdx, [rsp+0x20]
00007ac9d05d7fc4  lea rcx, [rsp+0x30]
00007ac9d05d7fc9  mov r8d, 0x00
00007ac9d05d7fcf  lea r9, [r15+0x3A8]
00007ac9d05d7fd6  movaps [rdi], xmm10
00007ac9d05d7fda  movaps [rsi], xmm9
00007ac9d05d7fde  movaps [rdx], xmm7
00007ac9d05d7fe1  movaps [rcx], xmm14
00007ac9d05d7fe5  mov rax, 0x569AF9F93A50
00007ac9d05d7fef  call rax
00007ac9d05d7ff1  movaps xmm10, [rsp]
00007ac9d05d7ff6  add rsp, 0x40
00007ac9d05d7ffa  vmovaps xmm0, [rsp]
00007ac9d05d7fff  vmovaps xmm1, [rsp+0x10]
00007ac9d05d8005  vmovaps xmm2, [rsp+0x20]
00007ac9d05d800b  vmovaps xmm3, [rsp+0x30]
00007ac9d05d8011  vmovaps xmm4, [rsp+0x40]
00007ac9d05d8017  vmovaps xmm5, [rsp+0x50]
00007ac9d05d801d  vmovaps xmm6, [rsp+0x60]
00007ac9d05d8023  vmovaps xmm7, [rsp+0x70]
00007ac9d05d8029  vmovaps xmm8, [rsp+0x80]
00007ac9d05d8032  vmovaps xmm9, [rsp+0x90]
00007ac9d05d803b  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d8044  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d804d  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d8056  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d805f  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d8068  add rsp, 0xF0
00007ac9d05d806f  pop r11
00007ac9d05d8071  pop r10
00007ac9d05d8073  pop r9
00007ac9d05d8075  pop r8
00007ac9d05d8077  pop rsi
00007ac9d05d8078  pop rdi
00007ac9d05d8079  pop rdx
00007ac9d05d807a  pop rcx
00007ac9d05d807b  pop rax
00007ac9d05d807c  add rsp, 0x08
00007ac9d05d8080  jmp 0x00007AC9D05D68F1
00007ac9d05d8085  call 0x00007AC9D04E45A0
00007ac9d05d808a  jmp 0x00007AC9D05D68FE
00007ac9d05d808f  sub rsp, 0x08
00007ac9d05d8093  push rax
00007ac9d05d8094  push rcx
00007ac9d05d8095  push rdx
00007ac9d05d8096  push rdi
00007ac9d05d8097  push rsi
00007ac9d05d8098  push r8
00007ac9d05d809a  push r9
00007ac9d05d809c  push r10
00007ac9d05d809e  push r11
00007ac9d05d80a0  sub rsp, 0xF0
00007ac9d05d80a7  vmovaps [rsp], xmm0
00007ac9d05d80ac  vmovaps [rsp+0x10], xmm1
00007ac9d05d80b2  vmovaps [rsp+0x20], xmm2
00007ac9d05d80b8  vmovaps [rsp+0x30], xmm3
00007ac9d05d80be  vmovaps [rsp+0x40], xmm4
00007ac9d05d80c4  vmovaps [rsp+0x50], xmm6
00007ac9d05d80ca  vmovaps [rsp+0x60], xmm7
00007ac9d05d80d0  vmovaps [rsp+0x70], xmm8
00007ac9d05d80d6  vmovaps [rsp+0x80], xmm9
00007ac9d05d80df  vmovaps [rsp+0x90], xmm10
00007ac9d05d80e8  vmovaps [rsp+0xA0], xmm11
00007ac9d05d80f1  vmovaps [rsp+0xB0], xmm12
00007ac9d05d80fa  vmovaps [rsp+0xC0], xmm13
00007ac9d05d8103  vmovaps [rsp+0xD0], xmm14
00007ac9d05d810c  vmovaps [rsp+0xE0], xmm15
00007ac9d05d8115  sub rsp, 0x40
00007ac9d05d8119  lea rdi, [rsp]
00007ac9d05d811d  lea rsi, [rsp+0x10]
00007ac9d05d8122  lea rdx, [rsp+0x20]
00007ac9d05d8127  lea rcx, [rsp+0x30]
00007ac9d05d812c  mov r8d, 0x00
00007ac9d05d8132  lea r9, [r15+0x3A8]
00007ac9d05d8139  movaps [rdi], xmm5
00007ac9d05d813c  movaps [rsi], xmm6
00007ac9d05d813f  movaps [rdx], xmm7
00007ac9d05d8142  movaps [rcx], xmm9
00007ac9d05d8146  mov rax, 0x569AF9F93A50
00007ac9d05d8150  call rax
00007ac9d05d8152  movaps xmm5, [rsp]
00007ac9d05d8156  add rsp, 0x40
00007ac9d05d815a  vmovaps xmm0, [rsp]
00007ac9d05d815f  vmovaps xmm1, [rsp+0x10]
00007ac9d05d8165  vmovaps xmm2, [rsp+0x20]
00007ac9d05d816b  vmovaps xmm3, [rsp+0x30]
00007ac9d05d8171  vmovaps xmm4, [rsp+0x40]
00007ac9d05d8177  vmovaps xmm6, [rsp+0x50]
00007ac9d05d817d  vmovaps xmm7, [rsp+0x60]
00007ac9d05d8183  vmovaps xmm8, [rsp+0x70]
00007ac9d05d8189  vmovaps xmm9, [rsp+0x80]
00007ac9d05d8192  vmovaps xmm10, [rsp+0x90]
00007ac9d05d819b  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d81a4  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d81ad  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d81b6  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d81bf  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d81c8  add rsp, 0xF0
00007ac9d05d81cf  pop r11
00007ac9d05d81d1  pop r10
00007ac9d05d81d3  pop r9
00007ac9d05d81d5  pop r8
00007ac9d05d81d7  pop rsi
00007ac9d05d81d8  pop rdi
00007ac9d05d81d9  pop rdx
00007ac9d05d81da  pop rcx
00007ac9d05d81db  pop rax
00007ac9d05d81dc  add rsp, 0x08
00007ac9d05d81e0  jmp 0x00007AC9D05D6930
00007ac9d05d81e5  sub rsp, 0x08
00007ac9d05d81e9  push rax
00007ac9d05d81ea  push rcx
00007ac9d05d81eb  push rdx
00007ac9d05d81ec  push rdi
00007ac9d05d81ed  push rsi
00007ac9d05d81ee  push r8
00007ac9d05d81f0  push r9
00007ac9d05d81f2  push r10
00007ac9d05d81f4  push r11
00007ac9d05d81f6  sub rsp, 0xF0
00007ac9d05d81fd  vmovaps [rsp], xmm0
00007ac9d05d8202  vmovaps [rsp+0x10], xmm1
00007ac9d05d8208  vmovaps [rsp+0x20], xmm2
00007ac9d05d820e  vmovaps [rsp+0x30], xmm3
00007ac9d05d8214  vmovaps [rsp+0x40], xmm4
00007ac9d05d821a  vmovaps [rsp+0x50], xmm5
00007ac9d05d8220  vmovaps [rsp+0x60], xmm6
00007ac9d05d8226  vmovaps [rsp+0x70], xmm8
00007ac9d05d822c  vmovaps [rsp+0x80], xmm9
00007ac9d05d8235  vmovaps [rsp+0x90], xmm10
00007ac9d05d823e  vmovaps [rsp+0xA0], xmm11
00007ac9d05d8247  vmovaps [rsp+0xB0], xmm12
00007ac9d05d8250  vmovaps [rsp+0xC0], xmm13
00007ac9d05d8259  vmovaps [rsp+0xD0], xmm14
00007ac9d05d8262  vmovaps [rsp+0xE0], xmm15
00007ac9d05d826b  sub rsp, 0x40
00007ac9d05d826f  lea rdi, [rsp]
00007ac9d05d8273  lea rsi, [rsp+0x10]
00007ac9d05d8278  lea rdx, [rsp+0x20]
00007ac9d05d827d  lea rcx, [rsp+0x30]
00007ac9d05d8282  mov r8d, 0x00
00007ac9d05d8288  lea r9, [r15+0x3A8]
00007ac9d05d828f  movaps [rdi], xmm7
00007ac9d05d8292  movaps [rsi], xmm13
00007ac9d05d8296  movaps [rdx], xmm1
00007ac9d05d8299  movaps [rcx], xmm9
00007ac9d05d829d  mov rax, 0x569AF9F93A50
00007ac9d05d82a7  call rax
00007ac9d05d82a9  movaps xmm7, [rsp]
00007ac9d05d82ad  add rsp, 0x40
00007ac9d05d82b1  vmovaps xmm0, [rsp]
00007ac9d05d82b6  vmovaps xmm1, [rsp+0x10]
00007ac9d05d82bc  vmovaps xmm2, [rsp+0x20]
00007ac9d05d82c2  vmovaps xmm3, [rsp+0x30]
00007ac9d05d82c8  vmovaps xmm4, [rsp+0x40]
00007ac9d05d82ce  vmovaps xmm5, [rsp+0x50]
00007ac9d05d82d4  vmovaps xmm6, [rsp+0x60]
00007ac9d05d82da  vmovaps xmm8, [rsp+0x70]
00007ac9d05d82e0  vmovaps xmm9, [rsp+0x80]
00007ac9d05d82e9  vmovaps xmm10, [rsp+0x90]
00007ac9d05d82f2  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d82fb  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d8304  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d830d  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d8316  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d831f  add rsp, 0xF0
00007ac9d05d8326  pop r11
00007ac9d05d8328  pop r10
00007ac9d05d832a  pop r9
00007ac9d05d832c  pop r8
00007ac9d05d832e  pop rsi
00007ac9d05d832f  pop rdi
00007ac9d05d8330  pop rdx
00007ac9d05d8331  pop rcx
00007ac9d05d8332  pop rax
00007ac9d05d8333  add rsp, 0x08
00007ac9d05d8337  jmp 0x00007AC9D05D6955
00007ac9d05d833c  call 0x00007AC9D04E3320
00007ac9d05d8341  jmp 0x00007AC9D05D6978
00007ac9d05d8346  call 0x00007AC9D04DE950
00007ac9d05d834b  jmp 0x00007AC9D05D6982
00007ac9d05d8350  sub rsp, 0x08
00007ac9d05d8354  push rax
00007ac9d05d8355  push rcx
00007ac9d05d8356  push rdx
00007ac9d05d8357  push rdi
00007ac9d05d8358  push rsi
00007ac9d05d8359  push r8
00007ac9d05d835b  push r9
00007ac9d05d835d  push r10
00007ac9d05d835f  push r11
00007ac9d05d8361  sub rsp, 0xF0
00007ac9d05d8368  vmovaps [rsp], xmm0
00007ac9d05d836d  vmovaps [rsp+0x10], xmm1
00007ac9d05d8373  vmovaps [rsp+0x20], xmm3
00007ac9d05d8379  vmovaps [rsp+0x30], xmm4
00007ac9d05d837f  vmovaps [rsp+0x40], xmm5
00007ac9d05d8385  vmovaps [rsp+0x50], xmm6
00007ac9d05d838b  vmovaps [rsp+0x60], xmm7
00007ac9d05d8391  vmovaps [rsp+0x70], xmm8
00007ac9d05d8397  vmovaps [rsp+0x80], xmm9
00007ac9d05d83a0  vmovaps [rsp+0x90], xmm10
00007ac9d05d83a9  vmovaps [rsp+0xA0], xmm11
00007ac9d05d83b2  vmovaps [rsp+0xB0], xmm12
00007ac9d05d83bb  vmovaps [rsp+0xC0], xmm13
00007ac9d05d83c4  vmovaps [rsp+0xD0], xmm14
00007ac9d05d83cd  vmovaps [rsp+0xE0], xmm15
00007ac9d05d83d6  sub rsp, 0x40
00007ac9d05d83da  lea rdi, [rsp]
00007ac9d05d83de  lea rsi, [rsp+0x10]
00007ac9d05d83e3  lea rdx, [rsp+0x20]
00007ac9d05d83e8  lea rcx, [rsp+0x30]
00007ac9d05d83ed  mov r8d, 0x00
00007ac9d05d83f3  lea r9, [r15+0x3A8]
00007ac9d05d83fa  movaps [rdi], xmm2
00007ac9d05d83fd  movaps [rsi], xmm12
00007ac9d05d8401  movaps [rdx], xmm6
00007ac9d05d8404  movaps [rcx], xmm3
00007ac9d05d8407  mov rax, 0x569AF9F93A50
00007ac9d05d8411  call rax
00007ac9d05d8413  movaps xmm2, [rsp]
00007ac9d05d8417  add rsp, 0x40
00007ac9d05d841b  vmovaps xmm0, [rsp]
00007ac9d05d8420  vmovaps xmm1, [rsp+0x10]
00007ac9d05d8426  vmovaps xmm3, [rsp+0x20]
00007ac9d05d842c  vmovaps xmm4, [rsp+0x30]
00007ac9d05d8432  vmovaps xmm5, [rsp+0x40]
00007ac9d05d8438  vmovaps xmm6, [rsp+0x50]
00007ac9d05d843e  vmovaps xmm7, [rsp+0x60]
00007ac9d05d8444  vmovaps xmm8, [rsp+0x70]
00007ac9d05d844a  vmovaps xmm9, [rsp+0x80]
00007ac9d05d8453  vmovaps xmm10, [rsp+0x90]
00007ac9d05d845c  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d8465  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d846e  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d8477  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d8480  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d8489  add rsp, 0xF0
00007ac9d05d8490  pop r11
00007ac9d05d8492  pop r10
00007ac9d05d8494  pop r9
00007ac9d05d8496  pop r8
00007ac9d05d8498  pop rsi
00007ac9d05d8499  pop rdi
00007ac9d05d849a  pop rdx
00007ac9d05d849b  pop rcx
00007ac9d05d849c  pop rax
00007ac9d05d849d  add rsp, 0x08
00007ac9d05d84a1  jmp 0x00007AC9D05D69C8
00007ac9d05d84a6  sub rsp, 0x08
00007ac9d05d84aa  push rax
00007ac9d05d84ab  push rcx
00007ac9d05d84ac  push rdx
00007ac9d05d84ad  push rdi
00007ac9d05d84ae  push rsi
00007ac9d05d84af  push r8
00007ac9d05d84b1  push r9
00007ac9d05d84b3  push r10
00007ac9d05d84b5  push r11
00007ac9d05d84b7  sub rsp, 0xF0
00007ac9d05d84be  vmovaps [rsp], xmm0
00007ac9d05d84c3  vmovaps [rsp+0x10], xmm1
00007ac9d05d84c9  vmovaps [rsp+0x20], xmm2
00007ac9d05d84cf  vmovaps [rsp+0x30], xmm3
00007ac9d05d84d5  vmovaps [rsp+0x40], xmm4
00007ac9d05d84db  vmovaps [rsp+0x50], xmm5
00007ac9d05d84e1  vmovaps [rsp+0x60], xmm7
00007ac9d05d84e7  vmovaps [rsp+0x70], xmm8
00007ac9d05d84ed  vmovaps [rsp+0x80], xmm9
00007ac9d05d84f6  vmovaps [rsp+0x90], xmm10
00007ac9d05d84ff  vmovaps [rsp+0xA0], xmm11
00007ac9d05d8508  vmovaps [rsp+0xB0], xmm12
00007ac9d05d8511  vmovaps [rsp+0xC0], xmm13
00007ac9d05d851a  vmovaps [rsp+0xD0], xmm14
00007ac9d05d8523  vmovaps [rsp+0xE0], xmm15
00007ac9d05d852c  sub rsp, 0x40
00007ac9d05d8530  lea rdi, [rsp]
00007ac9d05d8534  lea rsi, [rsp+0x10]
00007ac9d05d8539  lea rdx, [rsp+0x20]
00007ac9d05d853e  lea rcx, [rsp+0x30]
00007ac9d05d8543  mov r8d, 0x00
00007ac9d05d8549  lea r9, [r15+0x3A8]
00007ac9d05d8550  movaps [rdi], xmm6
00007ac9d05d8553  movaps [rsi], xmm10
00007ac9d05d8557  movaps [rdx], xmm12
00007ac9d05d855b  movaps [rcx], xmm1
00007ac9d05d855e  mov rax, 0x569AF9F93A50
00007ac9d05d8568  call rax
00007ac9d05d856a  movaps xmm6, [rsp]
00007ac9d05d856e  add rsp, 0x40
00007ac9d05d8572  vmovaps xmm0, [rsp]
00007ac9d05d8577  vmovaps xmm1, [rsp+0x10]
00007ac9d05d857d  vmovaps xmm2, [rsp+0x20]
00007ac9d05d8583  vmovaps xmm3, [rsp+0x30]
00007ac9d05d8589  vmovaps xmm4, [rsp+0x40]
00007ac9d05d858f  vmovaps xmm5, [rsp+0x50]
00007ac9d05d8595  vmovaps xmm7, [rsp+0x60]
00007ac9d05d859b  vmovaps xmm8, [rsp+0x70]
00007ac9d05d85a1  vmovaps xmm9, [rsp+0x80]
00007ac9d05d85aa  vmovaps xmm10, [rsp+0x90]
00007ac9d05d85b3  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d85bc  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d85c5  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d85ce  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d85d7  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d85e0  add rsp, 0xF0
00007ac9d05d85e7  pop r11
00007ac9d05d85e9  pop r10
00007ac9d05d85eb  pop r9
00007ac9d05d85ed  pop r8
00007ac9d05d85ef  pop rsi
00007ac9d05d85f0  pop rdi
00007ac9d05d85f1  pop rdx
00007ac9d05d85f2  pop rcx
00007ac9d05d85f3  pop rax
00007ac9d05d85f4  add rsp, 0x08
00007ac9d05d85f8  jmp 0x00007AC9D05D69F6
00007ac9d05d85fd  sub rsp, 0x08
00007ac9d05d8601  push rax
00007ac9d05d8602  push rcx
00007ac9d05d8603  push rdx
00007ac9d05d8604  push rdi
00007ac9d05d8605  push rsi
00007ac9d05d8606  push r8
00007ac9d05d8608  push r9
00007ac9d05d860a  push r10
00007ac9d05d860c  push r11
00007ac9d05d860e  sub rsp, 0xF0
00007ac9d05d8615  vmovaps [rsp], xmm0
00007ac9d05d861a  vmovaps [rsp+0x10], xmm1
00007ac9d05d8620  vmovaps [rsp+0x20], xmm2
00007ac9d05d8626  vmovaps [rsp+0x30], xmm3
00007ac9d05d862c  vmovaps [rsp+0x40], xmm4
00007ac9d05d8632  vmovaps [rsp+0x50], xmm5
00007ac9d05d8638  vmovaps [rsp+0x60], xmm6
00007ac9d05d863e  vmovaps [rsp+0x70], xmm7
00007ac9d05d8644  vmovaps [rsp+0x80], xmm8
00007ac9d05d864d  vmovaps [rsp+0x90], xmm9
00007ac9d05d8656  vmovaps [rsp+0xA0], xmm11
00007ac9d05d865f  vmovaps [rsp+0xB0], xmm12
00007ac9d05d8668  vmovaps [rsp+0xC0], xmm13
00007ac9d05d8671  vmovaps [rsp+0xD0], xmm14
00007ac9d05d867a  vmovaps [rsp+0xE0], xmm15
00007ac9d05d8683  sub rsp, 0x40
00007ac9d05d8687  lea rdi, [rsp]
00007ac9d05d868b  lea rsi, [rsp+0x10]
00007ac9d05d8690  lea rdx, [rsp+0x20]
00007ac9d05d8695  lea rcx, [rsp+0x30]
00007ac9d05d869a  mov r8d, 0x00
00007ac9d05d86a0  lea r9, [r15+0x3A8]
00007ac9d05d86a7  movaps [rdi], xmm10
00007ac9d05d86ab  movaps [rsi], xmm5
00007ac9d05d86ae  movaps [rdx], xmm12
00007ac9d05d86b2  movaps [rcx], xmm1
00007ac9d05d86b5  mov rax, 0x569AF9F93A50
00007ac9d05d86bf  call rax
00007ac9d05d86c1  movaps xmm10, [rsp]
00007ac9d05d86c6  add rsp, 0x40
00007ac9d05d86ca  vmovaps xmm0, [rsp]
00007ac9d05d86cf  vmovaps xmm1, [rsp+0x10]
00007ac9d05d86d5  vmovaps xmm2, [rsp+0x20]
00007ac9d05d86db  vmovaps xmm3, [rsp+0x30]
00007ac9d05d86e1  vmovaps xmm4, [rsp+0x40]
00007ac9d05d86e7  vmovaps xmm5, [rsp+0x50]
00007ac9d05d86ed  vmovaps xmm6, [rsp+0x60]
00007ac9d05d86f3  vmovaps xmm7, [rsp+0x70]
00007ac9d05d86f9  vmovaps xmm8, [rsp+0x80]
00007ac9d05d8702  vmovaps xmm9, [rsp+0x90]
00007ac9d05d870b  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d8714  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d871d  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d8726  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d872f  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d8738  add rsp, 0xF0
00007ac9d05d873f  pop r11
00007ac9d05d8741  pop r10
00007ac9d05d8743  pop r9
00007ac9d05d8745  pop r8
00007ac9d05d8747  pop rsi
00007ac9d05d8748  pop rdi
00007ac9d05d8749  pop rdx
00007ac9d05d874a  pop rcx
00007ac9d05d874b  pop rax
00007ac9d05d874c  add rsp, 0x08
00007ac9d05d8750  jmp 0x00007AC9D05D6A25
00007ac9d05d8755  sub rsp, 0x08
00007ac9d05d8759  push rax
00007ac9d05d875a  push rcx
00007ac9d05d875b  push rdx
00007ac9d05d875c  push rdi
00007ac9d05d875d  push rsi
00007ac9d05d875e  push r8
00007ac9d05d8760  push r9
00007ac9d05d8762  push r10
00007ac9d05d8764  push r11
00007ac9d05d8766  sub rsp, 0xF0
00007ac9d05d876d  vmovaps [rsp], xmm0
00007ac9d05d8772  vmovaps [rsp+0x10], xmm1
00007ac9d05d8778  vmovaps [rsp+0x20], xmm2
00007ac9d05d877e  vmovaps [rsp+0x30], xmm3
00007ac9d05d8784  vmovaps [rsp+0x40], xmm4
00007ac9d05d878a  vmovaps [rsp+0x50], xmm5
00007ac9d05d8790  vmovaps [rsp+0x60], xmm6
00007ac9d05d8796  vmovaps [rsp+0x70], xmm7
00007ac9d05d879c  vmovaps [rsp+0x80], xmm8
00007ac9d05d87a5  vmovaps [rsp+0x90], xmm9
00007ac9d05d87ae  vmovaps [rsp+0xA0], xmm10
00007ac9d05d87b7  vmovaps [rsp+0xB0], xmm11
00007ac9d05d87c0  vmovaps [rsp+0xC0], xmm13
00007ac9d05d87c9  vmovaps [rsp+0xD0], xmm14
00007ac9d05d87d2  vmovaps [rsp+0xE0], xmm15
00007ac9d05d87db  sub rsp, 0x40
00007ac9d05d87df  lea rdi, [rsp]
00007ac9d05d87e3  lea rsi, [rsp+0x10]
00007ac9d05d87e8  lea rdx, [rsp+0x20]
00007ac9d05d87ed  lea rcx, [rsp+0x30]
00007ac9d05d87f2  mov r8d, 0x00
00007ac9d05d87f8  lea r9, [r15+0x3A8]
00007ac9d05d87ff  movaps [rdi], xmm12
00007ac9d05d8803  movaps [rsi], xmm7
00007ac9d05d8806  movaps [rdx], xmm15
00007ac9d05d880a  movaps [rcx], xmm1
00007ac9d05d880d  mov rax, 0x569AF9F93A50
00007ac9d05d8817  call rax
00007ac9d05d8819  movaps xmm12, [rsp]
00007ac9d05d881e  add rsp, 0x40
00007ac9d05d8822  vmovaps xmm0, [rsp]
00007ac9d05d8827  vmovaps xmm1, [rsp+0x10]
00007ac9d05d882d  vmovaps xmm2, [rsp+0x20]
00007ac9d05d8833  vmovaps xmm3, [rsp+0x30]
00007ac9d05d8839  vmovaps xmm4, [rsp+0x40]
00007ac9d05d883f  vmovaps xmm5, [rsp+0x50]
00007ac9d05d8845  vmovaps xmm6, [rsp+0x60]
00007ac9d05d884b  vmovaps xmm7, [rsp+0x70]
00007ac9d05d8851  vmovaps xmm8, [rsp+0x80]
00007ac9d05d885a  vmovaps xmm9, [rsp+0x90]
00007ac9d05d8863  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d886c  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d8875  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d887e  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d8887  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d8890  add rsp, 0xF0
00007ac9d05d8897  pop r11
00007ac9d05d8899  pop r10
00007ac9d05d889b  pop r9
00007ac9d05d889d  pop r8
00007ac9d05d889f  pop rsi
00007ac9d05d88a0  pop rdi
00007ac9d05d88a1  pop rdx
00007ac9d05d88a2  pop rcx
00007ac9d05d88a3  pop rax
00007ac9d05d88a4  add rsp, 0x08
00007ac9d05d88a8  jmp 0x00007AC9D05D6A4E
00007ac9d05d88ad  call 0x00007AC9D04D64F0
00007ac9d05d88b2  jmp 0x00007AC9D05D6A58
00007ac9d05d88b7  call 0x00007AC9D04E5820
00007ac9d05d88bc  jmp 0x00007AC9D05D6A62
00007ac9d05d88c1  sub rsp, 0x08
00007ac9d05d88c5  push rax
00007ac9d05d88c6  push rcx
00007ac9d05d88c7  push rdx
00007ac9d05d88c8  push rdi
00007ac9d05d88c9  push rsi
00007ac9d05d88ca  push r8
00007ac9d05d88cc  push r9
00007ac9d05d88ce  push r10
00007ac9d05d88d0  push r11
00007ac9d05d88d2  sub rsp, 0xF0
00007ac9d05d88d9  vmovaps [rsp], xmm0
00007ac9d05d88de  vmovaps [rsp+0x10], xmm1
00007ac9d05d88e4  vmovaps [rsp+0x20], xmm2
00007ac9d05d88ea  vmovaps [rsp+0x30], xmm3
00007ac9d05d88f0  vmovaps [rsp+0x40], xmm4
00007ac9d05d88f6  vmovaps [rsp+0x50], xmm5
00007ac9d05d88fc  vmovaps [rsp+0x60], xmm6
00007ac9d05d8902  vmovaps [rsp+0x70], xmm8
00007ac9d05d8908  vmovaps [rsp+0x80], xmm9
00007ac9d05d8911  vmovaps [rsp+0x90], xmm10
00007ac9d05d891a  vmovaps [rsp+0xA0], xmm11
00007ac9d05d8923  vmovaps [rsp+0xB0], xmm12
00007ac9d05d892c  vmovaps [rsp+0xC0], xmm13
00007ac9d05d8935  vmovaps [rsp+0xD0], xmm14
00007ac9d05d893e  vmovaps [rsp+0xE0], xmm15
00007ac9d05d8947  sub rsp, 0x40
00007ac9d05d894b  lea rdi, [rsp]
00007ac9d05d894f  lea rsi, [rsp+0x10]
00007ac9d05d8954  lea rdx, [rsp+0x20]
00007ac9d05d8959  lea rcx, [rsp+0x30]
00007ac9d05d895e  mov r8d, 0x00
00007ac9d05d8964  lea r9, [r15+0x3A8]
00007ac9d05d896b  movaps [rdi], xmm7
00007ac9d05d896e  movaps [rsi], xmm2
00007ac9d05d8971  movaps [rdx], xmm9
00007ac9d05d8975  movaps [rcx], xmm11
00007ac9d05d8979  mov rax, 0x569AF9F93A50
00007ac9d05d8983  call rax
00007ac9d05d8985  movaps xmm7, [rsp]
00007ac9d05d8989  add rsp, 0x40
00007ac9d05d898d  vmovaps xmm0, [rsp]
00007ac9d05d8992  vmovaps xmm1, [rsp+0x10]
00007ac9d05d8998  vmovaps xmm2, [rsp+0x20]
00007ac9d05d899e  vmovaps xmm3, [rsp+0x30]
00007ac9d05d89a4  vmovaps xmm4, [rsp+0x40]
00007ac9d05d89aa  vmovaps xmm5, [rsp+0x50]
00007ac9d05d89b0  vmovaps xmm6, [rsp+0x60]
00007ac9d05d89b6  vmovaps xmm8, [rsp+0x70]
00007ac9d05d89bc  vmovaps xmm9, [rsp+0x80]
00007ac9d05d89c5  vmovaps xmm10, [rsp+0x90]
00007ac9d05d89ce  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d89d7  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d89e0  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d89e9  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d89f2  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d89fb  add rsp, 0xF0
00007ac9d05d8a02  pop r11
00007ac9d05d8a04  pop r10
00007ac9d05d8a06  pop r9
00007ac9d05d8a08  pop r8
00007ac9d05d8a0a  pop rsi
00007ac9d05d8a0b  pop rdi
00007ac9d05d8a0c  pop rdx
00007ac9d05d8a0d  pop rcx
00007ac9d05d8a0e  pop rax
00007ac9d05d8a0f  add rsp, 0x08
00007ac9d05d8a13  jmp 0x00007AC9D05D6A96
00007ac9d05d8a18  sub rsp, 0x08
00007ac9d05d8a1c  push rax
00007ac9d05d8a1d  push rcx
00007ac9d05d8a1e  push rdx
00007ac9d05d8a1f  push rdi
00007ac9d05d8a20  push rsi
00007ac9d05d8a21  push r8
00007ac9d05d8a23  push r9
00007ac9d05d8a25  push r10
00007ac9d05d8a27  push r11
00007ac9d05d8a29  sub rsp, 0xF0
00007ac9d05d8a30  vmovaps [rsp], xmm0
00007ac9d05d8a35  vmovaps [rsp+0x10], xmm1
00007ac9d05d8a3b  vmovaps [rsp+0x20], xmm2
00007ac9d05d8a41  vmovaps [rsp+0x30], xmm3
00007ac9d05d8a47  vmovaps [rsp+0x40], xmm4
00007ac9d05d8a4d  vmovaps [rsp+0x50], xmm5
00007ac9d05d8a53  vmovaps [rsp+0x60], xmm6
00007ac9d05d8a59  vmovaps [rsp+0x70], xmm7
00007ac9d05d8a5f  vmovaps [rsp+0x80], xmm8
00007ac9d05d8a68  vmovaps [rsp+0x90], xmm10
00007ac9d05d8a71  vmovaps [rsp+0xA0], xmm11
00007ac9d05d8a7a  vmovaps [rsp+0xB0], xmm12
00007ac9d05d8a83  vmovaps [rsp+0xC0], xmm13
00007ac9d05d8a8c  vmovaps [rsp+0xD0], xmm14
00007ac9d05d8a95  vmovaps [rsp+0xE0], xmm15
00007ac9d05d8a9e  sub rsp, 0x40
00007ac9d05d8aa2  lea rdi, [rsp]
00007ac9d05d8aa6  lea rsi, [rsp+0x10]
00007ac9d05d8aab  lea rdx, [rsp+0x20]
00007ac9d05d8ab0  lea rcx, [rsp+0x30]
00007ac9d05d8ab5  mov r8d, 0x00
00007ac9d05d8abb  lea r9, [r15+0x3A8]
00007ac9d05d8ac2  movaps [rdi], xmm9
00007ac9d05d8ac6  movaps [rsi], xmm6
00007ac9d05d8ac9  movaps [rdx], xmm1
00007ac9d05d8acc  movaps [rcx], xmm11
00007ac9d05d8ad0  mov rax, 0x569AF9F93A50
00007ac9d05d8ada  call rax
00007ac9d05d8adc  movaps xmm9, [rsp]
00007ac9d05d8ae1  add rsp, 0x40
00007ac9d05d8ae5  vmovaps xmm0, [rsp]
00007ac9d05d8aea  vmovaps xmm1, [rsp+0x10]
00007ac9d05d8af0  vmovaps xmm2, [rsp+0x20]
00007ac9d05d8af6  vmovaps xmm3, [rsp+0x30]
00007ac9d05d8afc  vmovaps xmm4, [rsp+0x40]
00007ac9d05d8b02  vmovaps xmm5, [rsp+0x50]
00007ac9d05d8b08  vmovaps xmm6, [rsp+0x60]
00007ac9d05d8b0e  vmovaps xmm7, [rsp+0x70]
00007ac9d05d8b14  vmovaps xmm8, [rsp+0x80]
00007ac9d05d8b1d  vmovaps xmm10, [rsp+0x90]
00007ac9d05d8b26  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d8b2f  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d8b38  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d8b41  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d8b4a  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d8b53  add rsp, 0xF0
00007ac9d05d8b5a  pop r11
00007ac9d05d8b5c  pop r10
00007ac9d05d8b5e  pop r9
00007ac9d05d8b60  pop r8
00007ac9d05d8b62  pop rsi
00007ac9d05d8b63  pop rdi
00007ac9d05d8b64  pop rdx
00007ac9d05d8b65  pop rcx
00007ac9d05d8b66  pop rax
00007ac9d05d8b67  add rsp, 0x08
00007ac9d05d8b6b  jmp 0x00007AC9D05D6ABC
00007ac9d05d8b70  sub rsp, 0x08
00007ac9d05d8b74  push rax
00007ac9d05d8b75  push rcx
00007ac9d05d8b76  push rdx
00007ac9d05d8b77  push rdi
00007ac9d05d8b78  push rsi
00007ac9d05d8b79  push r8
00007ac9d05d8b7b  push r9
00007ac9d05d8b7d  push r10
00007ac9d05d8b7f  push r11
00007ac9d05d8b81  sub rsp, 0xF0
00007ac9d05d8b88  vmovaps [rsp], xmm0
00007ac9d05d8b8d  vmovaps [rsp+0x10], xmm1
00007ac9d05d8b93  vmovaps [rsp+0x20], xmm2
00007ac9d05d8b99  vmovaps [rsp+0x30], xmm3
00007ac9d05d8b9f  vmovaps [rsp+0x40], xmm4
00007ac9d05d8ba5  vmovaps [rsp+0x50], xmm5
00007ac9d05d8bab  vmovaps [rsp+0x60], xmm6
00007ac9d05d8bb1  vmovaps [rsp+0x70], xmm7
00007ac9d05d8bb7  vmovaps [rsp+0x80], xmm8
00007ac9d05d8bc0  vmovaps [rsp+0x90], xmm9
00007ac9d05d8bc9  vmovaps [rsp+0xA0], xmm10
00007ac9d05d8bd2  vmovaps [rsp+0xB0], xmm12
00007ac9d05d8bdb  vmovaps [rsp+0xC0], xmm13
00007ac9d05d8be4  vmovaps [rsp+0xD0], xmm14
00007ac9d05d8bed  vmovaps [rsp+0xE0], xmm15
00007ac9d05d8bf6  sub rsp, 0x40
00007ac9d05d8bfa  lea rdi, [rsp]
00007ac9d05d8bfe  lea rsi, [rsp+0x10]
00007ac9d05d8c03  lea rdx, [rsp+0x20]
00007ac9d05d8c08  lea rcx, [rsp+0x30]
00007ac9d05d8c0d  mov r8d, 0x00
00007ac9d05d8c13  lea r9, [r15+0x3A8]
00007ac9d05d8c1a  movaps [rdi], xmm11
00007ac9d05d8c1e  movaps [rsi], xmm10
00007ac9d05d8c22  movaps [rdx], xmm8
00007ac9d05d8c26  movaps [rcx], xmm1
00007ac9d05d8c29  mov rax, 0x569AF9F93A50
00007ac9d05d8c33  call rax
00007ac9d05d8c35  movaps xmm11, [rsp]
00007ac9d05d8c3a  add rsp, 0x40
00007ac9d05d8c3e  vmovaps xmm0, [rsp]
00007ac9d05d8c43  vmovaps xmm1, [rsp+0x10]
00007ac9d05d8c49  vmovaps xmm2, [rsp+0x20]
00007ac9d05d8c4f  vmovaps xmm3, [rsp+0x30]
00007ac9d05d8c55  vmovaps xmm4, [rsp+0x40]
00007ac9d05d8c5b  vmovaps xmm5, [rsp+0x50]
00007ac9d05d8c61  vmovaps xmm6, [rsp+0x60]
00007ac9d05d8c67  vmovaps xmm7, [rsp+0x70]
00007ac9d05d8c6d  vmovaps xmm8, [rsp+0x80]
00007ac9d05d8c76  vmovaps xmm9, [rsp+0x90]
00007ac9d05d8c7f  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d8c88  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d8c91  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d8c9a  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d8ca3  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d8cac  add rsp, 0xF0
00007ac9d05d8cb3  pop r11
00007ac9d05d8cb5  pop r10
00007ac9d05d8cb7  pop r9
00007ac9d05d8cb9  pop r8
00007ac9d05d8cbb  pop rsi
00007ac9d05d8cbc  pop rdi
00007ac9d05d8cbd  pop rdx
00007ac9d05d8cbe  pop rcx
00007ac9d05d8cbf  pop rax
00007ac9d05d8cc0  add rsp, 0x08
00007ac9d05d8cc4  jmp 0x00007AC9D05D6AE2
00007ac9d05d8cc9  sub rsp, 0x08
00007ac9d05d8ccd  push rax
00007ac9d05d8cce  push rcx
00007ac9d05d8ccf  push rdx
00007ac9d05d8cd0  push rdi
00007ac9d05d8cd1  push rsi
00007ac9d05d8cd2  push r8
00007ac9d05d8cd4  push r9
00007ac9d05d8cd6  push r10
00007ac9d05d8cd8  push r11
00007ac9d05d8cda  sub rsp, 0xF0
00007ac9d05d8ce1  vmovaps [rsp], xmm0
00007ac9d05d8ce6  vmovaps [rsp+0x10], xmm1
00007ac9d05d8cec  vmovaps [rsp+0x20], xmm2
00007ac9d05d8cf2  vmovaps [rsp+0x30], xmm3
00007ac9d05d8cf8  vmovaps [rsp+0x40], xmm4
00007ac9d05d8cfe  vmovaps [rsp+0x50], xmm5
00007ac9d05d8d04  vmovaps [rsp+0x60], xmm6
00007ac9d05d8d0a  vmovaps [rsp+0x70], xmm7
00007ac9d05d8d10  vmovaps [rsp+0x80], xmm8
00007ac9d05d8d19  vmovaps [rsp+0x90], xmm9
00007ac9d05d8d22  vmovaps [rsp+0xA0], xmm11
00007ac9d05d8d2b  vmovaps [rsp+0xB0], xmm12
00007ac9d05d8d34  vmovaps [rsp+0xC0], xmm13
00007ac9d05d8d3d  vmovaps [rsp+0xD0], xmm14
00007ac9d05d8d46  vmovaps [rsp+0xE0], xmm15
00007ac9d05d8d4f  sub rsp, 0x40
00007ac9d05d8d53  lea rdi, [rsp]
00007ac9d05d8d57  lea rsi, [rsp+0x10]
00007ac9d05d8d5c  lea rdx, [rsp+0x20]
00007ac9d05d8d61  lea rcx, [rsp+0x30]
00007ac9d05d8d66  mov r8d, 0x00
00007ac9d05d8d6c  lea r9, [r15+0x3A8]
00007ac9d05d8d73  movaps [rdi], xmm10
00007ac9d05d8d77  movaps [rsi], xmm12
00007ac9d05d8d7b  movaps [rdx], xmm13
00007ac9d05d8d7f  movaps [rcx], xmm1
00007ac9d05d8d82  mov rax, 0x569AF9F93A50
00007ac9d05d8d8c  call rax
00007ac9d05d8d8e  movaps xmm10, [rsp]
00007ac9d05d8d93  add rsp, 0x40
00007ac9d05d8d97  vmovaps xmm0, [rsp]
00007ac9d05d8d9c  vmovaps xmm1, [rsp+0x10]
00007ac9d05d8da2  vmovaps xmm2, [rsp+0x20]
00007ac9d05d8da8  vmovaps xmm3, [rsp+0x30]
00007ac9d05d8dae  vmovaps xmm4, [rsp+0x40]
00007ac9d05d8db4  vmovaps xmm5, [rsp+0x50]
00007ac9d05d8dba  vmovaps xmm6, [rsp+0x60]
00007ac9d05d8dc0  vmovaps xmm7, [rsp+0x70]
00007ac9d05d8dc6  vmovaps xmm8, [rsp+0x80]
00007ac9d05d8dcf  vmovaps xmm9, [rsp+0x90]
00007ac9d05d8dd8  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d8de1  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d8dea  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d8df3  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d8dfc  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d8e05  add rsp, 0xF0
00007ac9d05d8e0c  pop r11
00007ac9d05d8e0e  pop r10
00007ac9d05d8e10  pop r9
00007ac9d05d8e12  pop r8
00007ac9d05d8e14  pop rsi
00007ac9d05d8e15  pop rdi
00007ac9d05d8e16  pop rdx
00007ac9d05d8e17  pop rcx
00007ac9d05d8e18  pop rax
00007ac9d05d8e19  add rsp, 0x08
00007ac9d05d8e1d  jmp 0x00007AC9D05D6B08
00007ac9d05d8e22  call 0x00007AC9D04D64F0
00007ac9d05d8e27  jmp 0x00007AC9D05D6B12
00007ac9d05d8e2c  call 0x00007AC9D04E3320
00007ac9d05d8e31  jmp 0x00007AC9D05D6B1C
00007ac9d05d8e36  sub rsp, 0x08
00007ac9d05d8e3a  push rax
00007ac9d05d8e3b  push rcx
00007ac9d05d8e3c  push rdx
00007ac9d05d8e3d  push rdi
00007ac9d05d8e3e  push rsi
00007ac9d05d8e3f  push r8
00007ac9d05d8e41  push r9
00007ac9d05d8e43  push r10
00007ac9d05d8e45  push r11
00007ac9d05d8e47  sub rsp, 0xF0
00007ac9d05d8e4e  vmovaps [rsp], xmm0
00007ac9d05d8e53  vmovaps [rsp+0x10], xmm1
00007ac9d05d8e59  vmovaps [rsp+0x20], xmm2
00007ac9d05d8e5f  vmovaps [rsp+0x30], xmm3
00007ac9d05d8e65  vmovaps [rsp+0x40], xmm4
00007ac9d05d8e6b  vmovaps [rsp+0x50], xmm5
00007ac9d05d8e71  vmovaps [rsp+0x60], xmm6
00007ac9d05d8e77  vmovaps [rsp+0x70], xmm7
00007ac9d05d8e7d  vmovaps [rsp+0x80], xmm9
00007ac9d05d8e86  vmovaps [rsp+0x90], xmm10
00007ac9d05d8e8f  vmovaps [rsp+0xA0], xmm11
00007ac9d05d8e98  vmovaps [rsp+0xB0], xmm12
00007ac9d05d8ea1  vmovaps [rsp+0xC0], xmm13
00007ac9d05d8eaa  vmovaps [rsp+0xD0], xmm14
00007ac9d05d8eb3  vmovaps [rsp+0xE0], xmm15
00007ac9d05d8ebc  sub rsp, 0x40
00007ac9d05d8ec0  lea rdi, [rsp]
00007ac9d05d8ec4  lea rsi, [rsp+0x10]
00007ac9d05d8ec9  lea rdx, [rsp+0x20]
00007ac9d05d8ece  lea rcx, [rsp+0x30]
00007ac9d05d8ed3  mov r8d, 0x00
00007ac9d05d8ed9  lea r9, [r15+0x3A8]
00007ac9d05d8ee0  movaps [rdi], xmm8
00007ac9d05d8ee4  movaps [rsi], xmm7
00007ac9d05d8ee7  movaps [rdx], xmm4
00007ac9d05d8eea  movaps [rcx], xmm12
00007ac9d05d8eee  mov rax, 0x569AF9F93A50
00007ac9d05d8ef8  call rax
00007ac9d05d8efa  movaps xmm8, [rsp]
00007ac9d05d8eff  add rsp, 0x40
00007ac9d05d8f03  vmovaps xmm0, [rsp]
00007ac9d05d8f08  vmovaps xmm1, [rsp+0x10]
00007ac9d05d8f0e  vmovaps xmm2, [rsp+0x20]
00007ac9d05d8f14  vmovaps xmm3, [rsp+0x30]
00007ac9d05d8f1a  vmovaps xmm4, [rsp+0x40]
00007ac9d05d8f20  vmovaps xmm5, [rsp+0x50]
00007ac9d05d8f26  vmovaps xmm6, [rsp+0x60]
00007ac9d05d8f2c  vmovaps xmm7, [rsp+0x70]
00007ac9d05d8f32  vmovaps xmm9, [rsp+0x80]
00007ac9d05d8f3b  vmovaps xmm10, [rsp+0x90]
00007ac9d05d8f44  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d8f4d  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d8f56  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d8f5f  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d8f68  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d8f71  add rsp, 0xF0
00007ac9d05d8f78  pop r11
00007ac9d05d8f7a  pop r10
00007ac9d05d8f7c  pop r9
00007ac9d05d8f7e  pop r8
00007ac9d05d8f80  pop rsi
00007ac9d05d8f81  pop rdi
00007ac9d05d8f82  pop rdx
00007ac9d05d8f83  pop rcx
00007ac9d05d8f84  pop rax
00007ac9d05d8f85  add rsp, 0x08
00007ac9d05d8f89  jmp 0x00007AC9D05D6B45
00007ac9d05d8f8e  sub rsp, 0x08
00007ac9d05d8f92  push rax
00007ac9d05d8f93  push rcx
00007ac9d05d8f94  push rdx
00007ac9d05d8f95  push rdi
00007ac9d05d8f96  push rsi
00007ac9d05d8f97  push r8
00007ac9d05d8f99  push r9
00007ac9d05d8f9b  push r10
00007ac9d05d8f9d  push r11
00007ac9d05d8f9f  sub rsp, 0xF0
00007ac9d05d8fa6  vmovaps [rsp], xmm0
00007ac9d05d8fab  vmovaps [rsp+0x10], xmm1
00007ac9d05d8fb1  vmovaps [rsp+0x20], xmm2
00007ac9d05d8fb7  vmovaps [rsp+0x30], xmm3
00007ac9d05d8fbd  vmovaps [rsp+0x40], xmm4
00007ac9d05d8fc3  vmovaps [rsp+0x50], xmm5
00007ac9d05d8fc9  vmovaps [rsp+0x60], xmm6
00007ac9d05d8fcf  vmovaps [rsp+0x70], xmm8
00007ac9d05d8fd5  vmovaps [rsp+0x80], xmm9
00007ac9d05d8fde  vmovaps [rsp+0x90], xmm10
00007ac9d05d8fe7  vmovaps [rsp+0xA0], xmm11
00007ac9d05d8ff0  vmovaps [rsp+0xB0], xmm12
00007ac9d05d8ff9  vmovaps [rsp+0xC0], xmm13
00007ac9d05d9002  vmovaps [rsp+0xD0], xmm14
00007ac9d05d900b  vmovaps [rsp+0xE0], xmm15
00007ac9d05d9014  sub rsp, 0x40
00007ac9d05d9018  lea rdi, [rsp]
00007ac9d05d901c  lea rsi, [rsp+0x10]
00007ac9d05d9021  lea rdx, [rsp+0x20]
00007ac9d05d9026  lea rcx, [rsp+0x30]
00007ac9d05d902b  mov r8d, 0x00
00007ac9d05d9031  lea r9, [r15+0x3A8]
00007ac9d05d9038  movaps [rdi], xmm7
00007ac9d05d903b  movaps [rsi], xmm9
00007ac9d05d903f  movaps [rdx], xmm14
00007ac9d05d9043  movaps [rcx], xmm12
00007ac9d05d9047  mov rax, 0x569AF9F93A50
00007ac9d05d9051  call rax
00007ac9d05d9053  movaps xmm7, [rsp]
00007ac9d05d9057  add rsp, 0x40
00007ac9d05d905b  vmovaps xmm0, [rsp]
00007ac9d05d9060  vmovaps xmm1, [rsp+0x10]
00007ac9d05d9066  vmovaps xmm2, [rsp+0x20]
00007ac9d05d906c  vmovaps xmm3, [rsp+0x30]
00007ac9d05d9072  vmovaps xmm4, [rsp+0x40]
00007ac9d05d9078  vmovaps xmm5, [rsp+0x50]
00007ac9d05d907e  vmovaps xmm6, [rsp+0x60]
00007ac9d05d9084  vmovaps xmm8, [rsp+0x70]
00007ac9d05d908a  vmovaps xmm9, [rsp+0x80]
00007ac9d05d9093  vmovaps xmm10, [rsp+0x90]
00007ac9d05d909c  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d90a5  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d90ae  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d90b7  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d90c0  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d90c9  add rsp, 0xF0
00007ac9d05d90d0  pop r11
00007ac9d05d90d2  pop r10
00007ac9d05d90d4  pop r9
00007ac9d05d90d6  pop r8
00007ac9d05d90d8  pop rsi
00007ac9d05d90d9  pop rdi
00007ac9d05d90da  pop rdx
00007ac9d05d90db  pop rcx
00007ac9d05d90dc  pop rax
00007ac9d05d90dd  add rsp, 0x08
00007ac9d05d90e1  jmp 0x00007AC9D05D6B6D
00007ac9d05d90e6  sub rsp, 0x08
00007ac9d05d90ea  push rax
00007ac9d05d90eb  push rcx
00007ac9d05d90ec  push rdx
00007ac9d05d90ed  push rdi
00007ac9d05d90ee  push rsi
00007ac9d05d90ef  push r8
00007ac9d05d90f1  push r9
00007ac9d05d90f3  push r10
00007ac9d05d90f5  push r11
00007ac9d05d90f7  sub rsp, 0xF0
00007ac9d05d90fe  vmovaps [rsp], xmm0
00007ac9d05d9103  vmovaps [rsp+0x10], xmm1
00007ac9d05d9109  vmovaps [rsp+0x20], xmm2
00007ac9d05d910f  vmovaps [rsp+0x30], xmm3
00007ac9d05d9115  vmovaps [rsp+0x40], xmm4
00007ac9d05d911b  vmovaps [rsp+0x50], xmm5
00007ac9d05d9121  vmovaps [rsp+0x60], xmm6
00007ac9d05d9127  vmovaps [rsp+0x70], xmm7
00007ac9d05d912d  vmovaps [rsp+0x80], xmm8
00007ac9d05d9136  vmovaps [rsp+0x90], xmm9
00007ac9d05d913f  vmovaps [rsp+0xA0], xmm10
00007ac9d05d9148  vmovaps [rsp+0xB0], xmm11
00007ac9d05d9151  vmovaps [rsp+0xC0], xmm13
00007ac9d05d915a  vmovaps [rsp+0xD0], xmm14
00007ac9d05d9163  vmovaps [rsp+0xE0], xmm15
00007ac9d05d916c  sub rsp, 0x40
00007ac9d05d9170  lea rdi, [rsp]
00007ac9d05d9174  lea rsi, [rsp+0x10]
00007ac9d05d9179  lea rdx, [rsp+0x20]
00007ac9d05d917e  lea rcx, [rsp+0x30]
00007ac9d05d9183  mov r8d, 0x00
00007ac9d05d9189  lea r9, [r15+0x3A8]
00007ac9d05d9190  movaps [rdi], xmm12
00007ac9d05d9194  movaps [rsi], xmm11
00007ac9d05d9198  movaps [rdx], xmm15
00007ac9d05d919c  movaps [rcx], xmm14
00007ac9d05d91a0  mov rax, 0x569AF9F93A50
00007ac9d05d91aa  call rax
00007ac9d05d91ac  movaps xmm12, [rsp]
00007ac9d05d91b1  add rsp, 0x40
00007ac9d05d91b5  vmovaps xmm0, [rsp]
00007ac9d05d91ba  vmovaps xmm1, [rsp+0x10]
00007ac9d05d91c0  vmovaps xmm2, [rsp+0x20]
00007ac9d05d91c6  vmovaps xmm3, [rsp+0x30]
00007ac9d05d91cc  vmovaps xmm4, [rsp+0x40]
00007ac9d05d91d2  vmovaps xmm5, [rsp+0x50]
00007ac9d05d91d8  vmovaps xmm6, [rsp+0x60]
00007ac9d05d91de  vmovaps xmm7, [rsp+0x70]
00007ac9d05d91e4  vmovaps xmm8, [rsp+0x80]
00007ac9d05d91ed  vmovaps xmm9, [rsp+0x90]
00007ac9d05d91f6  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d91ff  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d9208  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d9211  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d921a  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d9223  add rsp, 0xF0
00007ac9d05d922a  pop r11
00007ac9d05d922c  pop r10
00007ac9d05d922e  pop r9
00007ac9d05d9230  pop r8
00007ac9d05d9232  pop rsi
00007ac9d05d9233  pop rdi
00007ac9d05d9234  pop rdx
00007ac9d05d9235  pop rcx
00007ac9d05d9236  pop rax
00007ac9d05d9237  add rsp, 0x08
00007ac9d05d923b  jmp 0x00007AC9D05D6B96
00007ac9d05d9240  sub rsp, 0x08
00007ac9d05d9244  push rax
00007ac9d05d9245  push rcx
00007ac9d05d9246  push rdx
00007ac9d05d9247  push rdi
00007ac9d05d9248  push rsi
00007ac9d05d9249  push r8
00007ac9d05d924b  push r9
00007ac9d05d924d  push r10
00007ac9d05d924f  push r11
00007ac9d05d9251  sub rsp, 0xF0
00007ac9d05d9258  vmovaps [rsp], xmm0
00007ac9d05d925d  vmovaps [rsp+0x10], xmm1
00007ac9d05d9263  vmovaps [rsp+0x20], xmm2
00007ac9d05d9269  vmovaps [rsp+0x30], xmm3
00007ac9d05d926f  vmovaps [rsp+0x40], xmm4
00007ac9d05d9275  vmovaps [rsp+0x50], xmm5
00007ac9d05d927b  vmovaps [rsp+0x60], xmm6
00007ac9d05d9281  vmovaps [rsp+0x70], xmm7
00007ac9d05d9287  vmovaps [rsp+0x80], xmm8
00007ac9d05d9290  vmovaps [rsp+0x90], xmm9
00007ac9d05d9299  vmovaps [rsp+0xA0], xmm10
00007ac9d05d92a2  vmovaps [rsp+0xB0], xmm12
00007ac9d05d92ab  vmovaps [rsp+0xC0], xmm13
00007ac9d05d92b4  vmovaps [rsp+0xD0], xmm14
00007ac9d05d92bd  vmovaps [rsp+0xE0], xmm15
00007ac9d05d92c6  sub rsp, 0x40
00007ac9d05d92ca  lea rdi, [rsp]
00007ac9d05d92ce  lea rsi, [rsp+0x10]
00007ac9d05d92d3  lea rdx, [rsp+0x20]
00007ac9d05d92d8  lea rcx, [rsp+0x30]
00007ac9d05d92dd  mov r8d, 0x00
00007ac9d05d92e3  lea r9, [r15+0x3A8]
00007ac9d05d92ea  movaps [rdi], xmm11
00007ac9d05d92ee  movaps [rsi], xmm10
00007ac9d05d92f2  movaps [rdx], xmm13
00007ac9d05d92f6  movaps [rcx], xmm15
00007ac9d05d92fa  mov rax, 0x569AF9F93A50
00007ac9d05d9304  call rax
00007ac9d05d9306  movaps xmm11, [rsp]
00007ac9d05d930b  add rsp, 0x40
00007ac9d05d930f  vmovaps xmm0, [rsp]
00007ac9d05d9314  vmovaps xmm1, [rsp+0x10]
00007ac9d05d931a  vmovaps xmm2, [rsp+0x20]
00007ac9d05d9320  vmovaps xmm3, [rsp+0x30]
00007ac9d05d9326  vmovaps xmm4, [rsp+0x40]
00007ac9d05d932c  vmovaps xmm5, [rsp+0x50]
00007ac9d05d9332  vmovaps xmm6, [rsp+0x60]
00007ac9d05d9338  vmovaps xmm7, [rsp+0x70]
00007ac9d05d933e  vmovaps xmm8, [rsp+0x80]
00007ac9d05d9347  vmovaps xmm9, [rsp+0x90]
00007ac9d05d9350  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d9359  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d9362  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d936b  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d9374  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d937d  add rsp, 0xF0
00007ac9d05d9384  pop r11
00007ac9d05d9386  pop r10
00007ac9d05d9388  pop r9
00007ac9d05d938a  pop r8
00007ac9d05d938c  pop rsi
00007ac9d05d938d  pop rdi
00007ac9d05d938e  pop rdx
00007ac9d05d938f  pop rcx
00007ac9d05d9390  pop rax
00007ac9d05d9391  add rsp, 0x08
00007ac9d05d9395  jmp 0x00007AC9D05D6BBF
00007ac9d05d939a  call 0x00007AC9D04E5820
00007ac9d05d939f  jmp 0x00007AC9D05D6BCC
00007ac9d05d93a4  call 0x00007AC9D04E45A0
00007ac9d05d93a9  jmp 0x00007AC9D05D6BD9
00007ac9d05d93ae  sub rsp, 0x08
00007ac9d05d93b2  push rax
00007ac9d05d93b3  push rcx
00007ac9d05d93b4  push rdx
00007ac9d05d93b5  push rdi
00007ac9d05d93b6  push rsi
00007ac9d05d93b7  push r8
00007ac9d05d93b9  push r9
00007ac9d05d93bb  push r10
00007ac9d05d93bd  push r11
00007ac9d05d93bf  sub rsp, 0xF0
00007ac9d05d93c6  vmovaps [rsp], xmm0
00007ac9d05d93cb  vmovaps [rsp+0x10], xmm1
00007ac9d05d93d1  vmovaps [rsp+0x20], xmm2
00007ac9d05d93d7  vmovaps [rsp+0x30], xmm3
00007ac9d05d93dd  vmovaps [rsp+0x40], xmm4
00007ac9d05d93e3  vmovaps [rsp+0x50], xmm5
00007ac9d05d93e9  vmovaps [rsp+0x60], xmm6
00007ac9d05d93ef  vmovaps [rsp+0x70], xmm7
00007ac9d05d93f5  vmovaps [rsp+0x80], xmm8
00007ac9d05d93fe  vmovaps [rsp+0x90], xmm9
00007ac9d05d9407  vmovaps [rsp+0xA0], xmm11
00007ac9d05d9410  vmovaps [rsp+0xB0], xmm12
00007ac9d05d9419  vmovaps [rsp+0xC0], xmm13
00007ac9d05d9422  vmovaps [rsp+0xD0], xmm14
00007ac9d05d942b  vmovaps [rsp+0xE0], xmm15
00007ac9d05d9434  sub rsp, 0x40
00007ac9d05d9438  lea rdi, [rsp]
00007ac9d05d943c  lea rsi, [rsp+0x10]
00007ac9d05d9441  lea rdx, [rsp+0x20]
00007ac9d05d9446  lea rcx, [rsp+0x30]
00007ac9d05d944b  mov r8d, 0x00
00007ac9d05d9451  lea r9, [r15+0x3A8]
00007ac9d05d9458  movaps [rdi], xmm10
00007ac9d05d945c  movaps [rsi], xmm8
00007ac9d05d9460  movaps [rdx], xmm1
00007ac9d05d9463  movaps [rcx], xmm13
00007ac9d05d9467  mov rax, 0x569AF9F93A50
00007ac9d05d9471  call rax
00007ac9d05d9473  movaps xmm10, [rsp]
00007ac9d05d9478  add rsp, 0x40
00007ac9d05d947c  vmovaps xmm0, [rsp]
00007ac9d05d9481  vmovaps xmm1, [rsp+0x10]
00007ac9d05d9487  vmovaps xmm2, [rsp+0x20]
00007ac9d05d948d  vmovaps xmm3, [rsp+0x30]
00007ac9d05d9493  vmovaps xmm4, [rsp+0x40]
00007ac9d05d9499  vmovaps xmm5, [rsp+0x50]
00007ac9d05d949f  vmovaps xmm6, [rsp+0x60]
00007ac9d05d94a5  vmovaps xmm7, [rsp+0x70]
00007ac9d05d94ab  vmovaps xmm8, [rsp+0x80]
00007ac9d05d94b4  vmovaps xmm9, [rsp+0x90]
00007ac9d05d94bd  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d94c6  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d94cf  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d94d8  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d94e1  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d94ea  add rsp, 0xF0
00007ac9d05d94f1  pop r11
00007ac9d05d94f3  pop r10
00007ac9d05d94f5  pop r9
00007ac9d05d94f7  pop r8
00007ac9d05d94f9  pop rsi
00007ac9d05d94fa  pop rdi
00007ac9d05d94fb  pop rdx
00007ac9d05d94fc  pop rcx
00007ac9d05d94fd  pop rax
00007ac9d05d94fe  add rsp, 0x08
00007ac9d05d9502  jmp 0x00007AC9D05D6C0F
00007ac9d05d9507  call 0x00007AC9D04D64F0
00007ac9d05d950c  jmp 0x00007AC9D05D6C21
00007ac9d05d9511  sub rsp, 0x08
00007ac9d05d9515  push rax
00007ac9d05d9516  push rcx
00007ac9d05d9517  push rdx
00007ac9d05d9518  push rdi
00007ac9d05d9519  push rsi
00007ac9d05d951a  push r8
00007ac9d05d951c  push r9
00007ac9d05d951e  push r10
00007ac9d05d9520  push r11
00007ac9d05d9522  sub rsp, 0xF0
00007ac9d05d9529  vmovaps [rsp], xmm0
00007ac9d05d952e  vmovaps [rsp+0x10], xmm1
00007ac9d05d9534  vmovaps [rsp+0x20], xmm2
00007ac9d05d953a  vmovaps [rsp+0x30], xmm3
00007ac9d05d9540  vmovaps [rsp+0x40], xmm4
00007ac9d05d9546  vmovaps [rsp+0x50], xmm5
00007ac9d05d954c  vmovaps [rsp+0x60], xmm6
00007ac9d05d9552  vmovaps [rsp+0x70], xmm7
00007ac9d05d9558  vmovaps [rsp+0x80], xmm8
00007ac9d05d9561  vmovaps [rsp+0x90], xmm10
00007ac9d05d956a  vmovaps [rsp+0xA0], xmm11
00007ac9d05d9573  vmovaps [rsp+0xB0], xmm12
00007ac9d05d957c  vmovaps [rsp+0xC0], xmm13
00007ac9d05d9585  vmovaps [rsp+0xD0], xmm14
00007ac9d05d958e  vmovaps [rsp+0xE0], xmm15
00007ac9d05d9597  sub rsp, 0x40
00007ac9d05d959b  lea rdi, [rsp]
00007ac9d05d959f  lea rsi, [rsp+0x10]
00007ac9d05d95a4  lea rdx, [rsp+0x20]
00007ac9d05d95a9  lea rcx, [rsp+0x30]
00007ac9d05d95ae  mov r8d, 0x00
00007ac9d05d95b4  lea r9, [r15+0x3A8]
00007ac9d05d95bb  movaps [rdi], xmm9
00007ac9d05d95bf  movaps [rsi], xmm7
00007ac9d05d95c2  movaps [rdx], xmm14
00007ac9d05d95c6  movaps [rcx], xmm13
00007ac9d05d95ca  mov rax, 0x569AF9F93A50
00007ac9d05d95d4  call rax
00007ac9d05d95d6  movaps xmm9, [rsp]
00007ac9d05d95db  add rsp, 0x40
00007ac9d05d95df  vmovaps xmm0, [rsp]
00007ac9d05d95e4  vmovaps xmm1, [rsp+0x10]
00007ac9d05d95ea  vmovaps xmm2, [rsp+0x20]
00007ac9d05d95f0  vmovaps xmm3, [rsp+0x30]
00007ac9d05d95f6  vmovaps xmm4, [rsp+0x40]
00007ac9d05d95fc  vmovaps xmm5, [rsp+0x50]
00007ac9d05d9602  vmovaps xmm6, [rsp+0x60]
00007ac9d05d9608  vmovaps xmm7, [rsp+0x70]
00007ac9d05d960e  vmovaps xmm8, [rsp+0x80]
00007ac9d05d9617  vmovaps xmm10, [rsp+0x90]
00007ac9d05d9620  vmovaps xmm11, [rsp+0xA0]
00007ac9d05d9629  vmovaps xmm12, [rsp+0xB0]
00007ac9d05d9632  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d963b  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d9644  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d964d  add rsp, 0xF0
00007ac9d05d9654  pop r11
00007ac9d05d9656  pop r10
00007ac9d05d9658  pop r9
00007ac9d05d965a  pop r8
00007ac9d05d965c  pop rsi
00007ac9d05d965d  pop rdi
00007ac9d05d965e  pop rdx
00007ac9d05d965f  pop rcx
00007ac9d05d9660  pop rax
00007ac9d05d9661  add rsp, 0x08
00007ac9d05d9665  jmp 0x00007AC9D05D6C4F
00007ac9d05d966a  sub rsp, 0x08
00007ac9d05d966e  push rax
00007ac9d05d966f  push rcx
00007ac9d05d9670  push rdx
00007ac9d05d9671  push rdi
00007ac9d05d9672  push rsi
00007ac9d05d9673  push r8
00007ac9d05d9675  push r9
00007ac9d05d9677  push r10
00007ac9d05d9679  push r11
00007ac9d05d967b  sub rsp, 0xF0
00007ac9d05d9682  vmovaps [rsp], xmm0
00007ac9d05d9687  vmovaps [rsp+0x10], xmm1
00007ac9d05d968d  vmovaps [rsp+0x20], xmm2
00007ac9d05d9693  vmovaps [rsp+0x30], xmm3
00007ac9d05d9699  vmovaps [rsp+0x40], xmm4
00007ac9d05d969f  vmovaps [rsp+0x50], xmm5
00007ac9d05d96a5  vmovaps [rsp+0x60], xmm6
00007ac9d05d96ab  vmovaps [rsp+0x70], xmm7
00007ac9d05d96b1  vmovaps [rsp+0x80], xmm8
00007ac9d05d96ba  vmovaps [rsp+0x90], xmm9
00007ac9d05d96c3  vmovaps [rsp+0xA0], xmm10
00007ac9d05d96cc  vmovaps [rsp+0xB0], xmm11
00007ac9d05d96d5  vmovaps [rsp+0xC0], xmm12
00007ac9d05d96de  vmovaps [rsp+0xD0], xmm14
00007ac9d05d96e7  vmovaps [rsp+0xE0], xmm15
00007ac9d05d96f0  sub rsp, 0x40
00007ac9d05d96f4  lea rdi, [rsp]
00007ac9d05d96f8  lea rsi, [rsp+0x10]
00007ac9d05d96fd  lea rdx, [rsp+0x20]
00007ac9d05d9702  lea rcx, [rsp+0x30]
00007ac9d05d9707  mov r8d, 0x00
00007ac9d05d970d  lea r9, [r15+0x3A8]
00007ac9d05d9714  movaps [rdi], xmm13
00007ac9d05d9718  movaps [rsi], xmm12
00007ac9d05d971c  movaps [rdx], xmm15
00007ac9d05d9720  movaps [rcx], xmm14
00007ac9d05d9724  mov rax, 0x569AF9F93A50
00007ac9d05d972e  call rax
00007ac9d05d9730  movaps xmm13, [rsp]
00007ac9d05d9735  add rsp, 0x40
00007ac9d05d9739  vmovaps xmm0, [rsp]
00007ac9d05d973e  vmovaps xmm1, [rsp+0x10]
00007ac9d05d9744  vmovaps xmm2, [rsp+0x20]
00007ac9d05d974a  vmovaps xmm3, [rsp+0x30]
00007ac9d05d9750  vmovaps xmm4, [rsp+0x40]
00007ac9d05d9756  vmovaps xmm5, [rsp+0x50]
00007ac9d05d975c  vmovaps xmm6, [rsp+0x60]
00007ac9d05d9762  vmovaps xmm7, [rsp+0x70]
00007ac9d05d9768  vmovaps xmm8, [rsp+0x80]
00007ac9d05d9771  vmovaps xmm9, [rsp+0x90]
00007ac9d05d977a  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d9783  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d978c  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d9795  vmovaps xmm14, [rsp+0xD0]
00007ac9d05d979e  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d97a7  add rsp, 0xF0
00007ac9d05d97ae  pop r11
00007ac9d05d97b0  pop r10
00007ac9d05d97b2  pop r9
00007ac9d05d97b4  pop r8
00007ac9d05d97b6  pop rsi
00007ac9d05d97b7  pop rdi
00007ac9d05d97b8  pop rdx
00007ac9d05d97b9  pop rcx
00007ac9d05d97ba  pop rax
00007ac9d05d97bb  add rsp, 0x08
00007ac9d05d97bf  jmp 0x00007AC9D05D6C7D
00007ac9d05d97c4  sub rsp, 0x08
00007ac9d05d97c8  push rax
00007ac9d05d97c9  push rcx
00007ac9d05d97ca  push rdx
00007ac9d05d97cb  push rdi
00007ac9d05d97cc  push rsi
00007ac9d05d97cd  push r8
00007ac9d05d97cf  push r9
00007ac9d05d97d1  push r10
00007ac9d05d97d3  push r11
00007ac9d05d97d5  sub rsp, 0xF0
00007ac9d05d97dc  vmovaps [rsp], xmm0
00007ac9d05d97e1  vmovaps [rsp+0x10], xmm1
00007ac9d05d97e7  vmovaps [rsp+0x20], xmm2
00007ac9d05d97ed  vmovaps [rsp+0x30], xmm3
00007ac9d05d97f3  vmovaps [rsp+0x40], xmm4
00007ac9d05d97f9  vmovaps [rsp+0x50], xmm5
00007ac9d05d97ff  vmovaps [rsp+0x60], xmm6
00007ac9d05d9805  vmovaps [rsp+0x70], xmm7
00007ac9d05d980b  vmovaps [rsp+0x80], xmm8
00007ac9d05d9814  vmovaps [rsp+0x90], xmm9
00007ac9d05d981d  vmovaps [rsp+0xA0], xmm10
00007ac9d05d9826  vmovaps [rsp+0xB0], xmm11
00007ac9d05d982f  vmovaps [rsp+0xC0], xmm12
00007ac9d05d9838  vmovaps [rsp+0xD0], xmm13
00007ac9d05d9841  vmovaps [rsp+0xE0], xmm15
00007ac9d05d984a  sub rsp, 0x40
00007ac9d05d984e  lea rdi, [rsp]
00007ac9d05d9852  lea rsi, [rsp+0x10]
00007ac9d05d9857  lea rdx, [rsp+0x20]
00007ac9d05d985c  lea rcx, [rsp+0x30]
00007ac9d05d9861  mov r8d, 0x00
00007ac9d05d9867  lea r9, [r15+0x3A8]
00007ac9d05d986e  movaps [rdi], xmm14
00007ac9d05d9872  movaps [rsi], xmm11
00007ac9d05d9876  movaps [rdx], xmm1
00007ac9d05d9879  movaps [rcx], xmm15
00007ac9d05d987d  mov rax, 0x569AF9F93A50
00007ac9d05d9887  call rax
00007ac9d05d9889  movaps xmm14, [rsp]
00007ac9d05d988e  add rsp, 0x40
00007ac9d05d9892  vmovaps xmm0, [rsp]
00007ac9d05d9897  vmovaps xmm1, [rsp+0x10]
00007ac9d05d989d  vmovaps xmm2, [rsp+0x20]
00007ac9d05d98a3  vmovaps xmm3, [rsp+0x30]
00007ac9d05d98a9  vmovaps xmm4, [rsp+0x40]
00007ac9d05d98af  vmovaps xmm5, [rsp+0x50]
00007ac9d05d98b5  vmovaps xmm6, [rsp+0x60]
00007ac9d05d98bb  vmovaps xmm7, [rsp+0x70]
00007ac9d05d98c1  vmovaps xmm8, [rsp+0x80]
00007ac9d05d98ca  vmovaps xmm9, [rsp+0x90]
00007ac9d05d98d3  vmovaps xmm10, [rsp+0xA0]
00007ac9d05d98dc  vmovaps xmm11, [rsp+0xB0]
00007ac9d05d98e5  vmovaps xmm12, [rsp+0xC0]
00007ac9d05d98ee  vmovaps xmm13, [rsp+0xD0]
00007ac9d05d98f7  vmovaps xmm15, [rsp+0xE0]
00007ac9d05d9900  add rsp, 0xF0
00007ac9d05d9907  pop r11
00007ac9d05d9909  pop r10
00007ac9d05d990b  pop r9
00007ac9d05d990d  pop r8
00007ac9d05d990f  pop rsi
00007ac9d05d9910  pop rdi
00007ac9d05d9911  pop rdx
00007ac9d05d9912  pop rcx
00007ac9d05d9913  pop rax
00007ac9d05d9914  add rsp, 0x08
00007ac9d05d9918  jmp 0x00007AC9D05D6CAB
00007ac9d05d991d  call 0x00007AC9D04ACF70
00007ac9d05d9922  jmp 0x00007AC9D05D6CB9
00007ac9d05d9927  call 0x00007AC9D040C380
00007ac9d05d992c  jmp 0x00007AC9D05D6CC3
00007ac9d05d9931  call 0x00007AC9D0408C20
00007ac9d05d9936  jmp 0x00007AC9D05D6CCD
00007ac9d05d993b  call 0x00007AC9D040D600
00007ac9d05d9940  jmp 0x00007AC9D05D6CD7
00007ac9d05d9945  int3
00007ac9d05d9946  nop [rax+rax*1], ax
00007ac9d05d994f  nop
00007ac9d05d9950  mov eax, [r15+0x48]
00007ac9d05d9954  lea r14d, [eax+0x01]
00007ac9d05d9959  mov [rsp+0x10], r14d
00007ac9d05d995e  mov r14d, r14d
00007ac9d05d9961  mov [r15+0x48], r14
00007ac9d05d9965  xor eax, eax
00007ac9d05d9967  mov r14d, [rsp+0x10]
00007ac9d05d996c  cmp r14d, 0x1F4
00007ac9d05d9973  cmc
00007ac9d05d9974  lahf
00007ac9d05d9975  seto al
00007ac9d05d9978  mov [r15+0x108], eax
00007ac9d05d997f  mov eax, [r15+0x108]
00007ac9d05d9986  sahf
00007ac9d05d9987  jnz 0x00007AC9D05D99B9
00007ac9d05d9989  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d9991  jz 0x00007AC9D05DD2E0
00007ac9d05d9997  nop [rax+rax*1], ax
00007ac9d05d99a0  nop [rax+rax*1], eax
00007ac9d05d99a8  mov eax, 0x410670
00007ac9d05d99ad  mov [r15+0x100], rax
00007ac9d05d99b4  jmp 0x00007AC9D03FE110
00007ac9d05d99b9  cmp dword ptr [r15+0x318], 0x00
00007ac9d05d99c1  jz 0x00007AC9D05D99F0
00007ac9d05d99c7  nop [rax+rax*1], ax
00007ac9d05d99d0  nop [rax+rax*1], eax
00007ac9d05d99d8  mov eax, 0x4104EC
00007ac9d05d99dd  mov [r15+0x100], rax
00007ac9d05d99e4  jmp 0x00007AC9D03FE110
00007ac9d05d99e9  int3
00007ac9d05d99ea  int3
00007ac9d05d99eb  nop [rax+rax*1], eax
00007ac9d05d99f0  mov rax, [r15+0x40]
00007ac9d05d99f4  vxorps xmm1, xmm1, xmm1
00007ac9d05d99f8  vpbroadcastq xmm1, xmm1
00007ac9d05d99fd  vxorps xmm15, xmm15, xmm15
00007ac9d05d9a02  vpbroadcastq xmm15, xmm15
00007ac9d05d9a07  lea r14, [rax+0x30]
00007ac9d05d9a0b  mov r12, [r13+r14*1]
00007ac9d05d9a10  lea r14, [rax+0x38]
00007ac9d05d9a14  mov r11, [r13+r14*1]
00007ac9d05d9a19  movq xmm14, r12
00007ac9d05d9a1e  movq xmm13, r11
00007ac9d05d9a23  movq xmm14, xmm14
00007ac9d05d9a28  movq xmm13, xmm13
00007ac9d05d9a2d  vmovaps [rsp+0x10], xmm13
00007ac9d05d9a33  movq xmm13, xmm13
00007ac9d05d9a38  movaps [r15+0x270], xmm13
00007ac9d05d9a40  movaps xmm13, [r15+0x160]
00007ac9d05d9a48  vmovaps [rsp+0x20], xmm13
00007ac9d05d9a4e  vmovaps xmm12, [rsp+0x20]
00007ac9d05d9a54  por xmm13, xmm12
00007ac9d05d9a59  lea r14, [rax+0x20]
00007ac9d05d9a5d  mov r12, [r13+r14*1]
00007ac9d05d9a62  lea r14, [rax+0x28]
00007ac9d05d9a66  mov r11, [r13+r14*1]
00007ac9d05d9a6b  movq xmm12, r12
00007ac9d05d9a70  movq xmm11, r11
00007ac9d05d9a75  movq xmm12, xmm12
00007ac9d05d9a7a  movq xmm11, xmm11
00007ac9d05d9a7f  movaps xmm10, [r15+0x2D0]
00007ac9d05d9a87  vmovaps [rsp+0x20], xmm10
00007ac9d05d9a8d  vmovaps xmm9, [rsp+0x20]
00007ac9d05d9a93  por xmm10, xmm9
00007ac9d05d9a98  movaps xmm9, [r15+0x300]
00007ac9d05d9aa0  vmovaps [rsp+0x20], xmm9
00007ac9d05d9aa6  vmovaps xmm8, [rsp+0x20]
00007ac9d05d9aac  por xmm9, xmm8
00007ac9d05d9ab1  movaps xmm8, [r15+0x2B0]
00007ac9d05d9ab9  vmovaps [rsp+0x20], xmm8
00007ac9d05d9abf  vmovaps xmm7, [rsp+0x20]
00007ac9d05d9ac5  por xmm8, xmm7
00007ac9d05d9aca  movaps xmm7, [r15+0x180]
00007ac9d05d9ad2  vmovaps [rsp+0x20], xmm7
00007ac9d05d9ad8  vmovaps xmm6, [rsp+0x20]
00007ac9d05d9ade  por xmm7, xmm6
00007ac9d05d9ae2  lea r14, [rax+0x10]
00007ac9d05d9ae6  mov r12, [r13+r14*1]
00007ac9d05d9aeb  lea r14, [rax+0x18]
00007ac9d05d9aef  mov r11, [r13+r14*1]
00007ac9d05d9af4  movq xmm6, r12
00007ac9d05d9af9  movq xmm5, r11
00007ac9d05d9afe  movq xmm6, xmm6
00007ac9d05d9b02  movq xmm5, xmm5
00007ac9d05d9b06  movaps xmm4, [r15+0x200]
00007ac9d05d9b0e  vmovaps [rsp+0x20], xmm4
00007ac9d05d9b14  vmovaps xmm3, [rsp+0x20]
00007ac9d05d9b1a  por xmm4, xmm3
00007ac9d05d9b1e  movaps xmm3, [r15+0x1F0]
00007ac9d05d9b26  vmovaps [rsp+0x20], xmm3
00007ac9d05d9b2c  vmovaps xmm2, [rsp+0x20]
00007ac9d05d9b32  por xmm3, xmm2
00007ac9d05d9b36  movaps xmm2, [r15+0x2E0]
00007ac9d05d9b3e  vmovaps [rsp+0x20], xmm2
00007ac9d05d9b44  vmovaps [rsp+0x30], xmm1
00007ac9d05d9b4a  vmovaps xmm1, [rsp+0x20]
00007ac9d05d9b50  por xmm2, xmm1
00007ac9d05d9b54  movaps xmm1, [r15+0x2A0]
00007ac9d05d9b5c  vmovaps [rsp+0x20], xmm1
00007ac9d05d9b62  vmovaps [rsp+0x40], xmm15
00007ac9d05d9b68  vmovaps xmm15, [rsp+0x20]
00007ac9d05d9b6e  por xmm1, xmm15
00007ac9d05d9b73  movaps xmm15, [r15+0x280]
00007ac9d05d9b7b  vmovaps [rsp+0x20], xmm15
00007ac9d05d9b81  vmovaps [rsp+0x50], xmm1
00007ac9d05d9b87  vmovaps xmm1, [rsp+0x20]
00007ac9d05d9b8d  por xmm15, xmm1
00007ac9d05d9b92  movaps xmm1, [r15+0x1C0]
00007ac9d05d9b9a  vmovaps [rsp+0x20], xmm1
00007ac9d05d9ba0  vmovaps [rsp+0x60], xmm15
00007ac9d05d9ba6  vmovaps xmm15, [rsp+0x20]
00007ac9d05d9bac  por xmm1, xmm15
00007ac9d05d9bb1  movaps xmm15, [r15+0x210]
00007ac9d05d9bb9  vmovaps [rsp+0x20], xmm15
00007ac9d05d9bbf  vmovaps [rsp+0x70], xmm1
00007ac9d05d9bc5  vmovaps xmm1, [rsp+0x20]
00007ac9d05d9bcb  por xmm15, xmm1
00007ac9d05d9bd0  mov r14, [r13+rax*1]
00007ac9d05d9bd5  vmovq xmm1, r14
00007ac9d05d9bda  vpbroadcastq xmm1, xmm1
00007ac9d05d9bdf  vmovaps [rsp+0x20], xmm1
00007ac9d05d9be5  vxorps xmm1, xmm1, xmm1
00007ac9d05d9be9  vpbroadcastq xmm1, xmm1
00007ac9d05d9bee  mov r14, [r15+0xF8]
00007ac9d05d9bf5  vmovaps [rsp+0x80], xmm1
00007ac9d05d9bfe  movups xmm1, [r13+r14*1]
00007ac9d05d9c04  vmovaps [rsp+0x90], xmm1
00007ac9d05d9c0d  vxorps xmm1, xmm1, xmm1
00007ac9d05d9c11  vpbroadcastq xmm1, xmm1
00007ac9d05d9c16  lea r12, [rax+0x08]
00007ac9d05d9c1a  mov rax, [r13+r12*1]
00007ac9d05d9c1f  vmovaps [rsp+0xA0], xmm1
00007ac9d05d9c28  movq xmm1, rax
00007ac9d05d9c2d  movaps [r15+0x240], xmm1
00007ac9d05d9c35  mov rax, [r15+0x50]
00007ac9d05d9c39  mov [r15+0x60], rax
00007ac9d05d9c3d  mov qword ptr [r15+0x58], 0x40
00007ac9d05d9c45  vmovaps xmm1, [rsp+0x30]
00007ac9d05d9c4b  vmovaps [rsp+0x30], xmm15
00007ac9d05d9c51  vmovaps xmm15, [rsp+0x90]
00007ac9d05d9c5a  vmovaps [rsp+0x90], xmm14
00007ac9d05d9c63  vmovaps xmm14, [rsp+0x20]
00007ac9d05d9c69  vmovaps [rsp+0x20], xmm13
00007ac9d05d9c6f  vmovaps [rsp+0xB0], xmm12
00007ac9d05d9c78  movaps xmm13, xmm1
00007ac9d05d9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d9c87  vptest xmm12, xmm12
00007ac9d05d9c8c  jnz 0x00007AC9D05DA72F
00007ac9d05d9c92  movaps xmm1, [r15+0x250]
00007ac9d05d9c9a  vmovaps xmm15, [rsp+0x40]
00007ac9d05d9ca0  vmovaps [rsp+0x40], xmm13
00007ac9d05d9ca6  movaps xmm12, xmm15
00007ac9d05d9caa  vfmadd231pd xmm12, xmm1, xmm14
00007ac9d05d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007ac9d05d9cb5  vptest xmm13, xmm13
00007ac9d05d9cba  jnz 0x00007AC9D05DA888
00007ac9d05d9cc0  movaps xmm15, [r15+0x1E0]
00007ac9d05d9cc8  vmovaps [rsp+0xC0], xmm15
00007ac9d05d9cd1  vmovaps xmm13, [rsp+0xC0]
00007ac9d05d9cda  por xmm15, xmm13
00007ac9d05d9cdf  movaps xmm13, [r15+0x1D0]
00007ac9d05d9ce7  vmovaps [rsp+0xC0], xmm13
00007ac9d05d9cf0  vmovaps [rsp+0xD0], xmm1
00007ac9d05d9cf9  vmovaps xmm1, [rsp+0xC0]
00007ac9d05d9d02  por xmm13, xmm1
00007ac9d05d9d07  movaps xmm1, [r15+0x2C0]
00007ac9d05d9d0f  vmovaps [rsp+0xC0], xmm1
00007ac9d05d9d18  vmovaps [rsp+0xE0], xmm15
00007ac9d05d9d21  vmovaps xmm15, [rsp+0xC0]
00007ac9d05d9d2a  por xmm1, xmm15
00007ac9d05d9d2f  movaps xmm15, [r15+0x290]
00007ac9d05d9d37  vmovaps [rsp+0xC0], xmm15
00007ac9d05d9d40  vmovaps [rsp+0xF0], xmm1
00007ac9d05d9d49  vmovaps xmm1, [rsp+0xC0]
00007ac9d05d9d52  por xmm15, xmm1
00007ac9d05d9d57  movaps xmm1, [r15+0x260]
00007ac9d05d9d5f  vmovaps [rsp+0xC0], xmm1
00007ac9d05d9d68  vmovaps [rsp+0x100], xmm15
00007ac9d05d9d71  vmovaps xmm15, [rsp+0xC0]
00007ac9d05d9d7a  por xmm1, xmm15
00007ac9d05d9d7f  vmovaps xmm15, [rsp+0xD0]
00007ac9d05d9d88  vmovaps [rsp+0xC0], xmm1
00007ac9d05d9d91  vmovaps xmm1, [rsp+0xD0]
00007ac9d05d9d9a  por xmm15, xmm1
00007ac9d05d9d9f  lea r12, [r14+0xC0]
00007ac9d05d9da6  movups xmm1, [r13+r12*1]
00007ac9d05d9dac  mov [rsp+0xD0], rax
00007ac9d05d9db4  xor eax, eax
00007ac9d05d9db6  mov r12d, 0x40
00007ac9d05d9dbc  mov r11d, 0x200
00007ac9d05d9dc2  cmp r12, r11
00007ac9d05d9dc5  cmc
00007ac9d05d9dc6  lahf
00007ac9d05d9dc7  seto al
00007ac9d05d9dca  mov [r15+0x108], eax
00007ac9d05d9dd1  vmovaps [rsp+0x110], xmm1
00007ac9d05d9dda  vmovaps xmm1, [rsp+0x80]
00007ac9d05d9de3  vmovaps [rsp+0x80], xmm15
00007ac9d05d9dec  vmovaps xmm15, [rsp+0x110]
00007ac9d05d9df5  vmovaps [rsp+0x110], xmm13
00007ac9d05d9dfe  vmovaps [rsp+0x120], xmm12
00007ac9d05d9e07  movaps xmm13, xmm1
00007ac9d05d9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d9e16  vptest xmm12, xmm12
00007ac9d05d9e1b  jnz 0x00007AC9D05DA9EB
00007ac9d05d9e21  lea rax, [r14+0xB0]
00007ac9d05d9e28  movups xmm1, [r13+rax*1]
00007ac9d05d9e2e  vmovaps xmm15, [rsp+0xA0]
00007ac9d05d9e37  vmovaps [rsp+0xA0], xmm13
00007ac9d05d9e40  movaps xmm12, xmm15
00007ac9d05d9e44  vfmadd231pd xmm12, xmm1, xmm14
00007ac9d05d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007ac9d05d9e4f  vptest xmm13, xmm13
00007ac9d05d9e54  jnz 0x00007AC9D05DAB4E
00007ac9d05d9e5a  vmovaps xmm1, [rsp+0x30]
00007ac9d05d9e60  vmovaps xmm15, [rsp+0x30]
00007ac9d05d9e66  por xmm1, xmm15
00007ac9d05d9e6b  movaps [r15+0x210], xmm1
00007ac9d05d9e73  vmovaps xmm15, [rsp+0x70]
00007ac9d05d9e79  vmovaps xmm14, [rsp+0x70]
00007ac9d05d9e7f  por xmm15, xmm14
00007ac9d05d9e84  movaps [r15+0x1C0], xmm15
00007ac9d05d9e8c  vmovaps xmm14, [rsp+0x60]
00007ac9d05d9e92  vmovaps xmm13, [rsp+0x60]
00007ac9d05d9e98  por xmm14, xmm13
00007ac9d05d9e9d  movaps [r15+0x280], xmm14
00007ac9d05d9ea5  vmovaps xmm13, [rsp+0x50]
00007ac9d05d9eab  vmovaps [rsp+0x30], xmm1
00007ac9d05d9eb1  vmovaps xmm1, [rsp+0x50]
00007ac9d05d9eb7  por xmm13, xmm1
00007ac9d05d9ebc  movaps [r15+0x2A0], xmm13
00007ac9d05d9ec4  vmovaps [rsp+0x50], xmm2
00007ac9d05d9eca  vmovaps xmm1, [rsp+0x50]
00007ac9d05d9ed0  por xmm2, xmm1
00007ac9d05d9ed4  movaps [r15+0x2E0], xmm2
00007ac9d05d9edc  vmovaps [rsp+0x50], xmm3
00007ac9d05d9ee2  vmovaps xmm1, [rsp+0x50]
00007ac9d05d9ee8  por xmm3, xmm1
00007ac9d05d9eec  movaps [r15+0x1F0], xmm3
00007ac9d05d9ef4  vmovaps xmm1, [rsp+0x80]
00007ac9d05d9efd  vmovaps [rsp+0x50], xmm15
00007ac9d05d9f03  vmovaps xmm15, [rsp+0x80]
00007ac9d05d9f0c  por xmm1, xmm15
00007ac9d05d9f11  movaps [r15+0x250], xmm1
00007ac9d05d9f19  vmovaps xmm1, [rsp+0xC0]
00007ac9d05d9f22  vmovaps xmm15, [rsp+0xC0]
00007ac9d05d9f2b  por xmm1, xmm15
00007ac9d05d9f30  movaps [r15+0x260], xmm1
00007ac9d05d9f38  vmovaps xmm15, [rsp+0x100]
00007ac9d05d9f41  vmovaps [rsp+0x60], xmm1
00007ac9d05d9f47  vmovaps xmm1, [rsp+0x100]
00007ac9d05d9f50  por xmm15, xmm1
00007ac9d05d9f55  movaps [r15+0x290], xmm15
00007ac9d05d9f5d  vmovaps xmm1, [rsp+0xF0]
00007ac9d05d9f66  vmovaps [rsp+0x70], xmm15
00007ac9d05d9f6c  vmovaps xmm15, [rsp+0xF0]
00007ac9d05d9f75  por xmm1, xmm15
00007ac9d05d9f7a  movaps [r15+0x2C0], xmm1
00007ac9d05d9f82  movq xmm15, qword ptr [r15+0x240]
00007ac9d05d9f8b  vmovaps [rsp+0x80], xmm15
00007ac9d05d9f94  vpermilpd xmm15, xmm15, 0x00
00007ac9d05d9f9a  vmovaps [rsp+0xC0], xmm1
00007ac9d05d9fa3  vmovaps xmm1, [rsp+0x40]
00007ac9d05d9fa9  vmovaps [rsp+0x40], xmm15
00007ac9d05d9faf  vmovaps xmm15, [rsp+0x30]
00007ac9d05d9fb5  vmovaps [rsp+0x30], xmm14
00007ac9d05d9fbb  vmovaps xmm14, [rsp+0x40]
00007ac9d05d9fc1  vmovaps [rsp+0x40], xmm13
00007ac9d05d9fc7  vmovaps [rsp+0xF0], xmm12
00007ac9d05d9fd0  movaps xmm13, xmm1
00007ac9d05d9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007ac9d05d9fdf  vptest xmm12, xmm12
00007ac9d05d9fe4  jnz 0x00007AC9D05DACA7
00007ac9d05d9fea  vmovaps xmm1, [rsp+0x80]
00007ac9d05d9ff3  vpermilpd xmm1, xmm1, 0x00
00007ac9d05d9ff9  vmovaps xmm15, [rsp+0xA0]
00007ac9d05da002  movaps xmm14, xmm15
00007ac9d05da006  vfmadd231pd xmm14, xmm2, xmm1
00007ac9d05da00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007ac9d05da011  vptest xmm12, xmm12
00007ac9d05da016  jnz 0x00007AC9D05DAE00
00007ac9d05da01c  vmovaps xmm1, [rsp+0x80]
00007ac9d05da025  vpermilpd xmm1, xmm1, 0x00
00007ac9d05da02b  vmovaps xmm15, [rsp+0x120]
00007ac9d05da034  vmovaps xmm12, [rsp+0x50]
00007ac9d05da03a  vmovaps [rsp+0x50], xmm14
00007ac9d05da040  movaps xmm2, xmm15
00007ac9d05da044  vfmadd231pd xmm2, xmm12, xmm1
00007ac9d05da049  vcmppd xmm14, xmm2, xmm2, 0x03
00007ac9d05da04e  vptest xmm14, xmm14
00007ac9d05da053  jnz 0x00007AC9D05DAF58
00007ac9d05da059  vmovaps xmm1, [rsp+0x110]
00007ac9d05da062  vmovaps xmm15, [rsp+0x110]
00007ac9d05da06b  por xmm1, xmm15
00007ac9d05da070  movaps [r15+0x1D0], xmm1
00007ac9d05da078  vmovaps xmm15, [rsp+0x80]
00007ac9d05da081  vpermilpd xmm15, xmm15, 0x00
00007ac9d05da087  vmovaps xmm14, [rsp+0xF0]
00007ac9d05da090  vmovaps [rsp+0x80], xmm1
00007ac9d05da099  movaps xmm12, xmm14
00007ac9d05da09d  vfmadd231pd xmm12, xmm3, xmm15
00007ac9d05da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007ac9d05da0a8  vptest xmm1, xmm1
00007ac9d05da0ad  jnz 0x00007AC9D05DB0AF
00007ac9d05da0b3  vmovaps [rsp+0xA0], xmm4
00007ac9d05da0bc  vmovaps xmm1, [rsp+0xA0]
00007ac9d05da0c5  por xmm4, xmm1
00007ac9d05da0c9  movaps [r15+0x200], xmm4
00007ac9d05da0d1  vmovaps xmm1, [rsp+0xE0]
00007ac9d05da0da  vmovaps xmm15, [rsp+0xE0]
00007ac9d05da0e3  por xmm1, xmm15
00007ac9d05da0e8  movaps [r15+0x1E0], xmm1
00007ac9d05da0f0  vmovaps [rsp+0xA0], xmm8
00007ac9d05da0f9  vmovaps xmm1, [rsp+0xA0]
00007ac9d05da102  por xmm8, xmm1
00007ac9d05da107  movaps [r15+0x2B0], xmm8
00007ac9d05da10f  vmovaps [rsp+0xA0], xmm9
00007ac9d05da118  vmovaps xmm1, [rsp+0xA0]
00007ac9d05da121  por xmm9, xmm1
00007ac9d05da126  movaps [r15+0x300], xmm9
00007ac9d05da12e  vmovaps [rsp+0xA0], xmm6
00007ac9d05da137  vpermilpd xmm6, xmm6, 0x00
00007ac9d05da13d  vmovaps xmm14, [rsp+0x60]
00007ac9d05da143  movaps xmm9, xmm13
00007ac9d05da147  vfmadd231pd xmm9, xmm14, xmm6
00007ac9d05da14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007ac9d05da152  vptest xmm3, xmm3
00007ac9d05da157  jnz 0x00007AC9D05DB208
00007ac9d05da15d  vmovaps xmm14, [rsp+0xA0]
00007ac9d05da166  vpermilpd xmm14, xmm14, 0x00
00007ac9d05da16c  vmovaps xmm13, [rsp+0x50]
00007ac9d05da172  vmovaps xmm6, [rsp+0xC0]
00007ac9d05da17b  vmovaps [rsp+0x50], xmm1
00007ac9d05da181  movaps xmm3, xmm13
00007ac9d05da185  vfmadd231pd xmm3, xmm6, xmm14
00007ac9d05da18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007ac9d05da18f  vptest xmm1, xmm1
00007ac9d05da194  jnz 0x00007AC9D05DB361
00007ac9d05da19a  vmovaps xmm1, [rsp+0xA0]
00007ac9d05da1a3  vpermilpd xmm1, xmm1, 0x00
00007ac9d05da1a9  vmovaps xmm14, [rsp+0x30]
00007ac9d05da1af  movaps xmm6, xmm2
00007ac9d05da1b2  vfmadd231pd xmm6, xmm14, xmm1
00007ac9d05da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007ac9d05da1bc  vptest xmm13, xmm13
00007ac9d05da1c1  jnz 0x00007AC9D05DB4B8
00007ac9d05da1c7  vmovaps xmm1, [rsp+0xA0]
00007ac9d05da1d0  vpermilpd xmm1, xmm1, 0x00
00007ac9d05da1d6  vmovaps xmm14, [rsp+0x80]
00007ac9d05da1df  movaps xmm13, xmm12
00007ac9d05da1e3  vfmadd231pd xmm13, xmm14, xmm1
00007ac9d05da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007ac9d05da1ee  vptest xmm2, xmm2
00007ac9d05da1f3  jnz 0x00007AC9D05DB60E
00007ac9d05da1f9  vmovaps [rsp+0x30], xmm7
00007ac9d05da1ff  vmovaps xmm1, [rsp+0x30]
00007ac9d05da205  por xmm7, xmm1
00007ac9d05da209  movaps [r15+0x180], xmm7
00007ac9d05da211  vmovaps [rsp+0x30], xmm10
00007ac9d05da217  vmovaps xmm1, [rsp+0x30]
00007ac9d05da21d  por xmm10, xmm1
00007ac9d05da222  movaps [r15+0x2D0], xmm10
00007ac9d05da22a  vmovaps [rsp+0x30], xmm5
00007ac9d05da230  vpermilpd xmm5, xmm5, 0x00
00007ac9d05da236  vmovaps xmm14, [rsp+0x50]
00007ac9d05da23c  movaps xmm12, xmm3
00007ac9d05da240  vfmadd231pd xmm12, xmm14, xmm5
00007ac9d05da245  vcmppd xmm10, xmm12, xmm12, 0x03
00007ac9d05da24b  vptest xmm10, xmm10
00007ac9d05da250  jnz 0x00007AC9D05DB767
00007ac9d05da256  vmovaps xmm14, [rsp+0x30]
00007ac9d05da25c  vpermilpd xmm14, xmm14, 0x00
00007ac9d05da262  movaps xmm10, xmm9
00007ac9d05da266  vfmadd231pd xmm10, xmm7, xmm14
00007ac9d05da26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007ac9d05da271  vptest xmm5, xmm5
00007ac9d05da276  jnz 0x00007AC9D05DB8BF
00007ac9d05da27c  lea rax, [r14+0x80]
00007ac9d05da283  movups xmm14, [r13+rax*1]
00007ac9d05da289  movaps [r15+0x2F0], xmm14
00007ac9d05da291  vmovaps xmm9, [rsp+0x30]
00007ac9d05da297  vpermilpd xmm9, xmm9, 0x00
00007ac9d05da29d  vmovaps xmm7, [rsp+0x70]
00007ac9d05da2a3  movaps xmm5, xmm6
00007ac9d05da2a6  vfmadd231pd xmm5, xmm7, xmm9
00007ac9d05da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007ac9d05da2b0  vptest xmm3, xmm3
00007ac9d05da2b5  jnz 0x00007AC9D05DBA22
00007ac9d05da2bb  vmovaps xmm9, [rsp+0x30]
00007ac9d05da2c1  vpermilpd xmm9, xmm9, 0x00
00007ac9d05da2c7  movaps xmm7, xmm13
00007ac9d05da2cb  vfmadd231pd xmm7, xmm1, xmm9
00007ac9d05da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007ac9d05da2d5  vptest xmm6, xmm6
00007ac9d05da2da  jnz 0x00007AC9D05DBB78
00007ac9d05da2e0  vmovaps xmm1, [rsp+0x20]
00007ac9d05da2e6  vmovaps xmm13, [rsp+0x20]
00007ac9d05da2ec  por xmm1, xmm13
00007ac9d05da2f1  movaps [r15+0x160], xmm1
00007ac9d05da2f9  lea rax, [r14+0x40]
00007ac9d05da2fd  movups xmm13, [r13+rax*1]
00007ac9d05da303  lea rax, [r14+0x50]
00007ac9d05da307  movups xmm9, [r13+rax*1]
00007ac9d05da30d  movaps [r15+0x1B0], xmm13
00007ac9d05da315  movaps [r15+0x1A0], xmm9
00007ac9d05da31d  movaps xmm6, [r15+0x190]
00007ac9d05da325  vmovaps xmm3, [rsp+0xB0]
00007ac9d05da32e  vpermilpd xmm3, xmm3, 0x00
00007ac9d05da334  vmovaps [rsp+0x20], xmm1
00007ac9d05da33a  movaps xmm2, xmm12
00007ac9d05da33e  vfmadd231pd xmm2, xmm6, xmm3
00007ac9d05da343  vcmppd xmm1, xmm2, xmm2, 0x03
00007ac9d05da348  vptest xmm1, xmm1
00007ac9d05da34d  jnz 0x00007AC9D05DBCE3
00007ac9d05da353  vmovaps xmm1, [rsp+0xB0]
00007ac9d05da35c  vpermilpd xmm1, xmm1, 0x00
00007ac9d05da362  vmovaps xmm12, [rsp+0x20]
00007ac9d05da368  movaps xmm6, xmm10
00007ac9d05da36c  vfmadd231pd xmm6, xmm12, xmm1
00007ac9d05da371  vcmppd xmm3, xmm6, xmm6, 0x03
00007ac9d05da376  vptest xmm3, xmm3
00007ac9d05da37b  jnz 0x00007AC9D05DBE39
00007ac9d05da381  vmovaps xmm1, [rsp+0xB0]
00007ac9d05da38a  vpermilpd xmm1, xmm1, 0x00
00007ac9d05da390  vmovaps xmm12, [rsp+0x40]
00007ac9d05da396  movaps xmm10, xmm5
00007ac9d05da39a  vfmadd231pd xmm10, xmm12, xmm1
00007ac9d05da39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007ac9d05da3a5  vptest xmm3, xmm3
00007ac9d05da3aa  jnz 0x00007AC9D05DBF90
00007ac9d05da3b0  vmovaps xmm1, [rsp+0xB0]
00007ac9d05da3b9  vpermilpd xmm1, xmm1, 0x00
00007ac9d05da3bf  movaps xmm12, xmm7
00007ac9d05da3c3  vfmadd231pd xmm12, xmm15, xmm1
00007ac9d05da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007ac9d05da3ce  vptest xmm5, xmm5
00007ac9d05da3d3  jnz 0x00007AC9D05DC0E8
00007ac9d05da3d9  lea rax, [r14+0x60]
00007ac9d05da3dd  movups xmm1, [r13+rax*1]
00007ac9d05da3e3  lea rax, [r14+0x70]
00007ac9d05da3e7  movups xmm15, [r13+rax*1]
00007ac9d05da3ed  movaps [r15+0x150], xmm1
00007ac9d05da3f5  movaps [r15+0x120], xmm15
00007ac9d05da3fd  vmovaps [rsp+0x20], xmm11
00007ac9d05da403  vpermilpd xmm11, xmm11, 0x00
00007ac9d05da409  movaps xmm7, xmm2
00007ac9d05da40c  vfmadd231pd xmm7, xmm9, xmm11
00007ac9d05da411  vcmppd xmm5, xmm7, xmm7, 0x03
00007ac9d05da416  vptest xmm5, xmm5
00007ac9d05da41b  jnz 0x00007AC9D05DC254
00007ac9d05da421  vmovaps xmm11, [rsp+0x20]
00007ac9d05da427  vpermilpd xmm11, xmm11, 0x00
00007ac9d05da42d  movaps xmm9, xmm6
00007ac9d05da431  vfmadd231pd xmm9, xmm1, xmm11
00007ac9d05da436  vcmppd xmm5, xmm9, xmm9, 0x03
00007ac9d05da43c  vptest xmm5, xmm5
00007ac9d05da441  jnz 0x00007AC9D05DC3AB
00007ac9d05da447  vmovaps xmm1, [rsp+0x20]
00007ac9d05da44d  vpermilpd xmm1, xmm1, 0x00
00007ac9d05da453  movaps xmm11, xmm10
00007ac9d05da457  vfmadd231pd xmm11, xmm8, xmm1
00007ac9d05da45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007ac9d05da462  vptest xmm6, xmm6
00007ac9d05da467  jnz 0x00007AC9D05DC503
00007ac9d05da46d  vmovaps xmm1, [rsp+0x20]
00007ac9d05da473  vpermilpd xmm1, xmm1, 0x00
00007ac9d05da479  movaps xmm10, xmm12
00007ac9d05da47d  vfmadd231pd xmm10, xmm13, xmm1
00007ac9d05da482  vcmppd xmm8, xmm10, xmm10, 0x03
00007ac9d05da488  vptest xmm8, xmm8
00007ac9d05da48d  jnz 0x00007AC9D05DC65C
00007ac9d05da493  lea rax, [r14+0x20]
00007ac9d05da497  movups xmm1, [r13+rax*1]
00007ac9d05da49d  lea rax, [r14+0x30]
00007ac9d05da4a1  movups xmm13, [r13+rax*1]
00007ac9d05da4a7  vmovaps xmm12, [rsp+0x90]
00007ac9d05da4b0  vpermilpd xmm12, xmm12, 0x00
00007ac9d05da4b6  movaps xmm8, xmm7
00007ac9d05da4ba  vfmadd231pd xmm8, xmm4, xmm12
00007ac9d05da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007ac9d05da4c5  vptest xmm6, xmm6
00007ac9d05da4ca  jnz 0x00007AC9D05DC7C9
00007ac9d05da4d0  vmovaps xmm12, [rsp+0x90]
00007ac9d05da4d9  vpermilpd xmm12, xmm12, 0x00
00007ac9d05da4df  movaps xmm7, xmm9
00007ac9d05da4e3  vfmadd231pd xmm7, xmm14, xmm12
00007ac9d05da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007ac9d05da4ed  vptest xmm6, xmm6
00007ac9d05da4f2  jnz 0x00007AC9D05DC921
00007ac9d05da4f8  vmovaps xmm14, [rsp+0x90]
00007ac9d05da501  vpermilpd xmm14, xmm14, 0x00
00007ac9d05da507  movaps xmm12, xmm11
00007ac9d05da50b  vfmadd231pd xmm12, xmm15, xmm14
00007ac9d05da510  vcmppd xmm9, xmm12, xmm12, 0x03
00007ac9d05da516  vptest xmm9, xmm9
00007ac9d05da51b  jnz 0x00007AC9D05DCA79
00007ac9d05da521  vmovaps xmm15, [rsp+0x90]
00007ac9d05da52a  vpermilpd xmm15, xmm15, 0x00
00007ac9d05da530  movaps xmm11, xmm10
00007ac9d05da534  vfmadd231pd xmm11, xmm13, xmm15
00007ac9d05da539  vcmppd xmm14, xmm11, xmm11, 0x03
00007ac9d05da53f  vptest xmm14, xmm14
00007ac9d05da544  jnz 0x00007AC9D05DCBD3
00007ac9d05da54a  lea rax, [r14+0x90]
00007ac9d05da551  movups xmm15, [r13+rax*1]
00007ac9d05da557  lea rax, [r14+0xA0]
00007ac9d05da55e  movups xmm14, [r13+rax*1]
00007ac9d05da564  movaps [r15+0x140], xmm15
00007ac9d05da56c  movaps [r15+0x130], xmm14
00007ac9d05da574  vmovaps xmm13, [rsp+0x10]
00007ac9d05da57a  vpermilpd xmm13, xmm13, 0x00
00007ac9d05da580  movaps xmm10, xmm8
00007ac9d05da584  vfmadd231pd xmm10, xmm1, xmm13
00007ac9d05da589  vcmppd xmm9, xmm10, xmm10, 0x03
00007ac9d05da58f  vptest xmm9, xmm9
00007ac9d05da594  jnz 0x00007AC9D05DCD41
00007ac9d05da59a  movaps [r15+0x220], xmm10
00007ac9d05da5a2  lea rax, [r14+0x10]
00007ac9d05da5a6  movups xmm1, [r13+rax*1]
00007ac9d05da5ac  movaps [r15+0x240], xmm1
00007ac9d05da5b4  vmovaps xmm13, [rsp+0x10]
00007ac9d05da5ba  vpermilpd xmm13, xmm13, 0x00
00007ac9d05da5c0  movaps xmm9, xmm7
00007ac9d05da5c4  vfmadd231pd xmm9, xmm14, xmm13
00007ac9d05da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007ac9d05da5cf  vptest xmm8, xmm8
00007ac9d05da5d4  jnz 0x00007AC9D05DCEA4
00007ac9d05da5da  movaps [r15+0x110], xmm9
00007ac9d05da5e2  vmovaps xmm14, [rsp+0x10]
00007ac9d05da5e8  vpermilpd xmm14, xmm14, 0x00
00007ac9d05da5ee  movaps xmm13, xmm12
00007ac9d05da5f2  vfmadd231pd xmm13, xmm15, xmm14
00007ac9d05da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007ac9d05da5fd  vptest xmm8, xmm8
00007ac9d05da602  jnz 0x00007AC9D05DCFFD
00007ac9d05da608  movaps [r15+0x170], xmm13
00007ac9d05da610  vmovaps xmm15, [rsp+0x10]
00007ac9d05da616  vpermilpd xmm15, xmm15, 0x00
00007ac9d05da61c  movaps xmm14, xmm11
00007ac9d05da620  vfmadd231pd xmm14, xmm1, xmm15
00007ac9d05da625  vcmppd xmm12, xmm14, xmm14, 0x03
00007ac9d05da62b  vptest xmm12, xmm12
00007ac9d05da630  jnz 0x00007AC9D05DD157
00007ac9d05da636  movaps [r15+0x230], xmm14
00007ac9d05da63e  mov rax, [rsp+0xD0]
00007ac9d05da646  movups [r13+rax*1], xmm9
00007ac9d05da64c  lea r14, [rax+0x10]
00007ac9d05da650  movups [r13+r14*1], xmm13
00007ac9d05da656  lea r14, [rax+0x20]
00007ac9d05da65a  movups [r13+r14*1], xmm10
00007ac9d05da660  lea r14, [rax+0x30]
00007ac9d05da664  movups [r13+r14*1], xmm14
00007ac9d05da66a  mov eax, [r15+0x108]
00007ac9d05da671  sahf
00007ac9d05da672  jnz 0x00007AC9D05DA6A4
00007ac9d05da674  cmp dword ptr [r15+0x318], 0x00
00007ac9d05da67c  jz 0x00007AC9D05D9950
00007ac9d05da682  nop [rax+rax*1], ax
00007ac9d05da68b  nop [rax+rax*1], eax
00007ac9d05da693  mov eax, 0x410664
00007ac9d05da698  mov [r15+0x100], rax
00007ac9d05da69f  jmp 0x00007AC9D03FE110
00007ac9d05da6a4  cmp dword ptr [r15+0x318], 0x00
00007ac9d05da6ac  jz 0x00007AC9D05D6050
00007ac9d05da6b2  nop [rax+rax*1], ax
00007ac9d05da6bb  nop [rax+rax*1], eax
00007ac9d05da6c3  mov eax, 0x4104F0
00007ac9d05da6c8  mov [r15+0x100], rax
00007ac9d05da6cf  jmp 0x00007AC9D03FE110
00007ac9d05da6d4  int3
00007ac9d05da6d5  call 0x00007AC9D04E27E0
00007ac9d05da6da  jmp 0x00007AC9D05D9A10
00007ac9d05da6df  call 0x00007AC9D04E1570
00007ac9d05da6e4  jmp 0x00007AC9D05D9A19
00007ac9d05da6e9  call 0x00007AC9D04E27E0
00007ac9d05da6ee  jmp 0x00007AC9D05D9A62
00007ac9d05da6f3  call 0x00007AC9D04E1570
00007ac9d05da6f8  jmp 0x00007AC9D05D9A6B
00007ac9d05da6fd  call 0x00007AC9D04E27E0
00007ac9d05da702  jmp 0x00007AC9D05D9AEB
00007ac9d05da707  call 0x00007AC9D04E1570
00007ac9d05da70c  jmp 0x00007AC9D05D9AF4
00007ac9d05da711  call 0x00007AC9D040DC20
00007ac9d05da716  jmp 0x00007AC9D05D9BD5
00007ac9d05da71b  call 0x00007AC9D04D64F0
00007ac9d05da720  jmp 0x00007AC9D05D9C04
00007ac9d05da725  call 0x00007AC9D04B47C0
00007ac9d05da72a  jmp 0x00007AC9D05D9C1F
00007ac9d05da72f  sub rsp, 0x08
00007ac9d05da733  push rax
00007ac9d05da734  push rcx
00007ac9d05da735  push rdx
00007ac9d05da736  push rdi
00007ac9d05da737  push rsi
00007ac9d05da738  push r8
00007ac9d05da73a  push r9
00007ac9d05da73c  push r10
00007ac9d05da73e  push r11
00007ac9d05da740  sub rsp, 0xF0
00007ac9d05da747  vmovaps [rsp], xmm0
00007ac9d05da74c  vmovaps [rsp+0x10], xmm1
00007ac9d05da752  vmovaps [rsp+0x20], xmm2
00007ac9d05da758  vmovaps [rsp+0x30], xmm3
00007ac9d05da75e  vmovaps [rsp+0x40], xmm4
00007ac9d05da764  vmovaps [rsp+0x50], xmm5
00007ac9d05da76a  vmovaps [rsp+0x60], xmm6
00007ac9d05da770  vmovaps [rsp+0x70], xmm7
00007ac9d05da776  vmovaps [rsp+0x80], xmm8
00007ac9d05da77f  vmovaps [rsp+0x90], xmm9
00007ac9d05da788  vmovaps [rsp+0xA0], xmm10
00007ac9d05da791  vmovaps [rsp+0xB0], xmm11
00007ac9d05da79a  vmovaps [rsp+0xC0], xmm12
00007ac9d05da7a3  vmovaps [rsp+0xD0], xmm14
00007ac9d05da7ac  vmovaps [rsp+0xE0], xmm15
00007ac9d05da7b5  sub rsp, 0x40
00007ac9d05da7b9  lea rdi, [rsp]
00007ac9d05da7bd  lea rsi, [rsp+0x10]
00007ac9d05da7c2  lea rdx, [rsp+0x20]
00007ac9d05da7c7  lea rcx, [rsp+0x30]
00007ac9d05da7cc  mov r8d, 0x00
00007ac9d05da7d2  lea r9, [r15+0x3A8]
00007ac9d05da7d9  movaps [rdi], xmm13
00007ac9d05da7dd  movaps [rsi], xmm1
00007ac9d05da7e0  movaps [rdx], xmm15
00007ac9d05da7e4  movaps [rcx], xmm14
00007ac9d05da7e8  mov rax, 0x569AF9F93A50
00007ac9d05da7f2  call rax
00007ac9d05da7f4  movaps xmm13, [rsp]
00007ac9d05da7f9  add rsp, 0x40
00007ac9d05da7fd  vmovaps xmm0, [rsp]
00007ac9d05da802  vmovaps xmm1, [rsp+0x10]
00007ac9d05da808  vmovaps xmm2, [rsp+0x20]
00007ac9d05da80e  vmovaps xmm3, [rsp+0x30]
00007ac9d05da814  vmovaps xmm4, [rsp+0x40]
00007ac9d05da81a  vmovaps xmm5, [rsp+0x50]
00007ac9d05da820  vmovaps xmm6, [rsp+0x60]
00007ac9d05da826  vmovaps xmm7, [rsp+0x70]
00007ac9d05da82c  vmovaps xmm8, [rsp+0x80]
00007ac9d05da835  vmovaps xmm9, [rsp+0x90]
00007ac9d05da83e  vmovaps xmm10, [rsp+0xA0]
00007ac9d05da847  vmovaps xmm11, [rsp+0xB0]
00007ac9d05da850  vmovaps xmm12, [rsp+0xC0]
00007ac9d05da859  vmovaps xmm14, [rsp+0xD0]
00007ac9d05da862  vmovaps xmm15, [rsp+0xE0]
00007ac9d05da86b  add rsp, 0xF0
00007ac9d05da872  pop r11
00007ac9d05da874  pop r10
00007ac9d05da876  pop r9
00007ac9d05da878  pop r8
00007ac9d05da87a  pop rsi
00007ac9d05da87b  pop rdi
00007ac9d05da87c  pop rdx
00007ac9d05da87d  pop rcx
00007ac9d05da87e  pop rax
00007ac9d05da87f  add rsp, 0x08
00007ac9d05da883  jmp 0x00007AC9D05D9C92
00007ac9d05da888  sub rsp, 0x08
00007ac9d05da88c  push rax
00007ac9d05da88d  push rcx
00007ac9d05da88e  push rdx
00007ac9d05da88f  push rdi
00007ac9d05da890  push rsi
00007ac9d05da891  push r8
00007ac9d05da893  push r9
00007ac9d05da895  push r10
00007ac9d05da897  push r11
00007ac9d05da899  sub rsp, 0xF0
00007ac9d05da8a0  vmovaps [rsp], xmm0
00007ac9d05da8a5  vmovaps [rsp+0x10], xmm1
00007ac9d05da8ab  vmovaps [rsp+0x20], xmm2
00007ac9d05da8b1  vmovaps [rsp+0x30], xmm3
00007ac9d05da8b7  vmovaps [rsp+0x40], xmm4
00007ac9d05da8bd  vmovaps [rsp+0x50], xmm5
00007ac9d05da8c3  vmovaps [rsp+0x60], xmm6
00007ac9d05da8c9  vmovaps [rsp+0x70], xmm7
00007ac9d05da8cf  vmovaps [rsp+0x80], xmm8
00007ac9d05da8d8  vmovaps [rsp+0x90], xmm9
00007ac9d05da8e1  vmovaps [rsp+0xA0], xmm10
00007ac9d05da8ea  vmovaps [rsp+0xB0], xmm11
00007ac9d05da8f3  vmovaps [rsp+0xC0], xmm13
00007ac9d05da8fc  vmovaps [rsp+0xD0], xmm14
00007ac9d05da905  vmovaps [rsp+0xE0], xmm15
00007ac9d05da90e  sub rsp, 0x40
00007ac9d05da912  lea rdi, [rsp]
00007ac9d05da916  lea rsi, [rsp+0x10]
00007ac9d05da91b  lea rdx, [rsp+0x20]
00007ac9d05da920  lea rcx, [rsp+0x30]
00007ac9d05da925  mov r8d, 0x00
00007ac9d05da92b  lea r9, [r15+0x3A8]
00007ac9d05da932  movaps [rdi], xmm12
00007ac9d05da936  movaps [rsi], xmm15
00007ac9d05da93a  movaps [rdx], xmm1
00007ac9d05da93d  movaps [rcx], xmm14
00007ac9d05da941  mov rax, 0x569AF9F93A50
00007ac9d05da94b  call rax
00007ac9d05da94d  movaps xmm12, [rsp]
00007ac9d05da952  add rsp, 0x40
00007ac9d05da956  vmovaps xmm0, [rsp]
00007ac9d05da95b  vmovaps xmm1, [rsp+0x10]
00007ac9d05da961  vmovaps xmm2, [rsp+0x20]
00007ac9d05da967  vmovaps xmm3, [rsp+0x30]
00007ac9d05da96d  vmovaps xmm4, [rsp+0x40]
00007ac9d05da973  vmovaps xmm5, [rsp+0x50]
00007ac9d05da979  vmovaps xmm6, [rsp+0x60]
00007ac9d05da97f  vmovaps xmm7, [rsp+0x70]
00007ac9d05da985  vmovaps xmm8, [rsp+0x80]
00007ac9d05da98e  vmovaps xmm9, [rsp+0x90]
00007ac9d05da997  vmovaps xmm10, [rsp+0xA0]
00007ac9d05da9a0  vmovaps xmm11, [rsp+0xB0]
00007ac9d05da9a9  vmovaps xmm13, [rsp+0xC0]
00007ac9d05da9b2  vmovaps xmm14, [rsp+0xD0]
00007ac9d05da9bb  vmovaps xmm15, [rsp+0xE0]
00007ac9d05da9c4  add rsp, 0xF0
00007ac9d05da9cb  pop r11
00007ac9d05da9cd  pop r10
00007ac9d05da9cf  pop r9
00007ac9d05da9d1  pop r8
00007ac9d05da9d3  pop rsi
00007ac9d05da9d4  pop rdi
00007ac9d05da9d5  pop rdx
00007ac9d05da9d6  pop rcx
00007ac9d05da9d7  pop rax
00007ac9d05da9d8  add rsp, 0x08
00007ac9d05da9dc  jmp 0x00007AC9D05D9CC0
00007ac9d05da9e1  call 0x00007AC9D04B52F0
00007ac9d05da9e6  jmp 0x00007AC9D05D9DAC
00007ac9d05da9eb  sub rsp, 0x08
00007ac9d05da9ef  push rax
00007ac9d05da9f0  push rcx
00007ac9d05da9f1  push rdx
00007ac9d05da9f2  push rdi
00007ac9d05da9f3  push rsi
00007ac9d05da9f4  push r8
00007ac9d05da9f6  push r9
00007ac9d05da9f8  push r10
00007ac9d05da9fa  push r11
00007ac9d05da9fc  sub rsp, 0xF0
00007ac9d05daa03  vmovaps [rsp], xmm0
00007ac9d05daa08  vmovaps [rsp+0x10], xmm1
00007ac9d05daa0e  vmovaps [rsp+0x20], xmm2
00007ac9d05daa14  vmovaps [rsp+0x30], xmm3
00007ac9d05daa1a  vmovaps [rsp+0x40], xmm4
00007ac9d05daa20  vmovaps [rsp+0x50], xmm5
00007ac9d05daa26  vmovaps [rsp+0x60], xmm6
00007ac9d05daa2c  vmovaps [rsp+0x70], xmm7
00007ac9d05daa32  vmovaps [rsp+0x80], xmm8
00007ac9d05daa3b  vmovaps [rsp+0x90], xmm9
00007ac9d05daa44  vmovaps [rsp+0xA0], xmm10
00007ac9d05daa4d  vmovaps [rsp+0xB0], xmm11
00007ac9d05daa56  vmovaps [rsp+0xC0], xmm12
00007ac9d05daa5f  vmovaps [rsp+0xD0], xmm14
00007ac9d05daa68  vmovaps [rsp+0xE0], xmm15
00007ac9d05daa71  sub rsp, 0x40
00007ac9d05daa75  lea rdi, [rsp]
00007ac9d05daa79  lea rsi, [rsp+0x10]
00007ac9d05daa7e  lea rdx, [rsp+0x20]
00007ac9d05daa83  lea rcx, [rsp+0x30]
00007ac9d05daa88  mov r8d, 0x00
00007ac9d05daa8e  lea r9, [r15+0x3A8]
00007ac9d05daa95  movaps [rdi], xmm13
00007ac9d05daa99  movaps [rsi], xmm1
00007ac9d05daa9c  movaps [rdx], xmm15
00007ac9d05daaa0  movaps [rcx], xmm14
00007ac9d05daaa4  mov rax, 0x569AF9F93A50
00007ac9d05daaae  call rax
00007ac9d05daab0  movaps xmm13, [rsp]
00007ac9d05daab5  add rsp, 0x40
00007ac9d05daab9  vmovaps xmm0, [rsp]
00007ac9d05daabe  vmovaps xmm1, [rsp+0x10]
00007ac9d05daac4  vmovaps xmm2, [rsp+0x20]
00007ac9d05daaca  vmovaps xmm3, [rsp+0x30]
00007ac9d05daad0  vmovaps xmm4, [rsp+0x40]
00007ac9d05daad6  vmovaps xmm5, [rsp+0x50]
00007ac9d05daadc  vmovaps xmm6, [rsp+0x60]
00007ac9d05daae2  vmovaps xmm7, [rsp+0x70]
00007ac9d05daae8  vmovaps xmm8, [rsp+0x80]
00007ac9d05daaf1  vmovaps xmm9, [rsp+0x90]
00007ac9d05daafa  vmovaps xmm10, [rsp+0xA0]
00007ac9d05dab03  vmovaps xmm11, [rsp+0xB0]
00007ac9d05dab0c  vmovaps xmm12, [rsp+0xC0]
00007ac9d05dab15  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dab1e  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dab27  add rsp, 0xF0
00007ac9d05dab2e  pop r11
00007ac9d05dab30  pop r10
00007ac9d05dab32  pop r9
00007ac9d05dab34  pop r8
00007ac9d05dab36  pop rsi
00007ac9d05dab37  pop rdi
00007ac9d05dab38  pop rdx
00007ac9d05dab39  pop rcx
00007ac9d05dab3a  pop rax
00007ac9d05dab3b  add rsp, 0x08
00007ac9d05dab3f  jmp 0x00007AC9D05D9E21
00007ac9d05dab44  call 0x00007AC9D03FF430
00007ac9d05dab49  jmp 0x00007AC9D05D9E2E
00007ac9d05dab4e  sub rsp, 0x08
00007ac9d05dab52  push rax
00007ac9d05dab53  push rcx
00007ac9d05dab54  push rdx
00007ac9d05dab55  push rdi
00007ac9d05dab56  push rsi
00007ac9d05dab57  push r8
00007ac9d05dab59  push r9
00007ac9d05dab5b  push r10
00007ac9d05dab5d  push r11
00007ac9d05dab5f  sub rsp, 0xF0
00007ac9d05dab66  vmovaps [rsp], xmm0
00007ac9d05dab6b  vmovaps [rsp+0x10], xmm1
00007ac9d05dab71  vmovaps [rsp+0x20], xmm2
00007ac9d05dab77  vmovaps [rsp+0x30], xmm3
00007ac9d05dab7d  vmovaps [rsp+0x40], xmm4
00007ac9d05dab83  vmovaps [rsp+0x50], xmm5
00007ac9d05dab89  vmovaps [rsp+0x60], xmm6
00007ac9d05dab8f  vmovaps [rsp+0x70], xmm7
00007ac9d05dab95  vmovaps [rsp+0x80], xmm8
00007ac9d05dab9e  vmovaps [rsp+0x90], xmm9
00007ac9d05daba7  vmovaps [rsp+0xA0], xmm10
00007ac9d05dabb0  vmovaps [rsp+0xB0], xmm11
00007ac9d05dabb9  vmovaps [rsp+0xC0], xmm13
00007ac9d05dabc2  vmovaps [rsp+0xD0], xmm14
00007ac9d05dabcb  vmovaps [rsp+0xE0], xmm15
00007ac9d05dabd4  sub rsp, 0x40
00007ac9d05dabd8  lea rdi, [rsp]
00007ac9d05dabdc  lea rsi, [rsp+0x10]
00007ac9d05dabe1  lea rdx, [rsp+0x20]
00007ac9d05dabe6  lea rcx, [rsp+0x30]
00007ac9d05dabeb  mov r8d, 0x00
00007ac9d05dabf1  lea r9, [r15+0x3A8]
00007ac9d05dabf8  movaps [rdi], xmm12
00007ac9d05dabfc  movaps [rsi], xmm15
00007ac9d05dac00  movaps [rdx], xmm1
00007ac9d05dac03  movaps [rcx], xmm14
00007ac9d05dac07  mov rax, 0x569AF9F93A50
00007ac9d05dac11  call rax
00007ac9d05dac13  movaps xmm12, [rsp]
00007ac9d05dac18  add rsp, 0x40
00007ac9d05dac1c  vmovaps xmm0, [rsp]
00007ac9d05dac21  vmovaps xmm1, [rsp+0x10]
00007ac9d05dac27  vmovaps xmm2, [rsp+0x20]
00007ac9d05dac2d  vmovaps xmm3, [rsp+0x30]
00007ac9d05dac33  vmovaps xmm4, [rsp+0x40]
00007ac9d05dac39  vmovaps xmm5, [rsp+0x50]
00007ac9d05dac3f  vmovaps xmm6, [rsp+0x60]
00007ac9d05dac45  vmovaps xmm7, [rsp+0x70]
00007ac9d05dac4b  vmovaps xmm8, [rsp+0x80]
00007ac9d05dac54  vmovaps xmm9, [rsp+0x90]
00007ac9d05dac5d  vmovaps xmm10, [rsp+0xA0]
00007ac9d05dac66  vmovaps xmm11, [rsp+0xB0]
00007ac9d05dac6f  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dac78  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dac81  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dac8a  add rsp, 0xF0
00007ac9d05dac91  pop r11
00007ac9d05dac93  pop r10
00007ac9d05dac95  pop r9
00007ac9d05dac97  pop r8
00007ac9d05dac99  pop rsi
00007ac9d05dac9a  pop rdi
00007ac9d05dac9b  pop rdx
00007ac9d05dac9c  pop rcx
00007ac9d05dac9d  pop rax
00007ac9d05dac9e  add rsp, 0x08
00007ac9d05daca2  jmp 0x00007AC9D05D9E5A
00007ac9d05daca7  sub rsp, 0x08
00007ac9d05dacab  push rax
00007ac9d05dacac  push rcx
00007ac9d05dacad  push rdx
00007ac9d05dacae  push rdi
00007ac9d05dacaf  push rsi
00007ac9d05dacb0  push r8
00007ac9d05dacb2  push r9
00007ac9d05dacb4  push r10
00007ac9d05dacb6  push r11
00007ac9d05dacb8  sub rsp, 0xF0
00007ac9d05dacbf  vmovaps [rsp], xmm0
00007ac9d05dacc4  vmovaps [rsp+0x10], xmm1
00007ac9d05dacca  vmovaps [rsp+0x20], xmm2
00007ac9d05dacd0  vmovaps [rsp+0x30], xmm3
00007ac9d05dacd6  vmovaps [rsp+0x40], xmm4
00007ac9d05dacdc  vmovaps [rsp+0x50], xmm5
00007ac9d05dace2  vmovaps [rsp+0x60], xmm6
00007ac9d05dace8  vmovaps [rsp+0x70], xmm7
00007ac9d05dacee  vmovaps [rsp+0x80], xmm8
00007ac9d05dacf7  vmovaps [rsp+0x90], xmm9
00007ac9d05dad00  vmovaps [rsp+0xA0], xmm10
00007ac9d05dad09  vmovaps [rsp+0xB0], xmm11
00007ac9d05dad12  vmovaps [rsp+0xC0], xmm12
00007ac9d05dad1b  vmovaps [rsp+0xD0], xmm14
00007ac9d05dad24  vmovaps [rsp+0xE0], xmm15
00007ac9d05dad2d  sub rsp, 0x40
00007ac9d05dad31  lea rdi, [rsp]
00007ac9d05dad35  lea rsi, [rsp+0x10]
00007ac9d05dad3a  lea rdx, [rsp+0x20]
00007ac9d05dad3f  lea rcx, [rsp+0x30]
00007ac9d05dad44  mov r8d, 0x00
00007ac9d05dad4a  lea r9, [r15+0x3A8]
00007ac9d05dad51  movaps [rdi], xmm13
00007ac9d05dad55  movaps [rsi], xmm1
00007ac9d05dad58  movaps [rdx], xmm15
00007ac9d05dad5c  movaps [rcx], xmm14
00007ac9d05dad60  mov rax, 0x569AF9F93A50
00007ac9d05dad6a  call rax
00007ac9d05dad6c  movaps xmm13, [rsp]
00007ac9d05dad71  add rsp, 0x40
00007ac9d05dad75  vmovaps xmm0, [rsp]
00007ac9d05dad7a  vmovaps xmm1, [rsp+0x10]
00007ac9d05dad80  vmovaps xmm2, [rsp+0x20]
00007ac9d05dad86  vmovaps xmm3, [rsp+0x30]
00007ac9d05dad8c  vmovaps xmm4, [rsp+0x40]
00007ac9d05dad92  vmovaps xmm5, [rsp+0x50]
00007ac9d05dad98  vmovaps xmm6, [rsp+0x60]
00007ac9d05dad9e  vmovaps xmm7, [rsp+0x70]
00007ac9d05dada4  vmovaps xmm8, [rsp+0x80]
00007ac9d05dadad  vmovaps xmm9, [rsp+0x90]
00007ac9d05dadb6  vmovaps xmm10, [rsp+0xA0]
00007ac9d05dadbf  vmovaps xmm11, [rsp+0xB0]
00007ac9d05dadc8  vmovaps xmm12, [rsp+0xC0]
00007ac9d05dadd1  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dadda  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dade3  add rsp, 0xF0
00007ac9d05dadea  pop r11
00007ac9d05dadec  pop r10
00007ac9d05dadee  pop r9
00007ac9d05dadf0  pop r8
00007ac9d05dadf2  pop rsi
00007ac9d05dadf3  pop rdi
00007ac9d05dadf4  pop rdx
00007ac9d05dadf5  pop rcx
00007ac9d05dadf6  pop rax
00007ac9d05dadf7  add rsp, 0x08
00007ac9d05dadfb  jmp 0x00007AC9D05D9FEA
00007ac9d05dae00  sub rsp, 0x08
00007ac9d05dae04  push rax
00007ac9d05dae05  push rcx
00007ac9d05dae06  push rdx
00007ac9d05dae07  push rdi
00007ac9d05dae08  push rsi
00007ac9d05dae09  push r8
00007ac9d05dae0b  push r9
00007ac9d05dae0d  push r10
00007ac9d05dae0f  push r11
00007ac9d05dae11  sub rsp, 0xF0
00007ac9d05dae18  vmovaps [rsp], xmm0
00007ac9d05dae1d  vmovaps [rsp+0x10], xmm1
00007ac9d05dae23  vmovaps [rsp+0x20], xmm2
00007ac9d05dae29  vmovaps [rsp+0x30], xmm3
00007ac9d05dae2f  vmovaps [rsp+0x40], xmm4
00007ac9d05dae35  vmovaps [rsp+0x50], xmm5
00007ac9d05dae3b  vmovaps [rsp+0x60], xmm6
00007ac9d05dae41  vmovaps [rsp+0x70], xmm7
00007ac9d05dae47  vmovaps [rsp+0x80], xmm8
00007ac9d05dae50  vmovaps [rsp+0x90], xmm9
00007ac9d05dae59  vmovaps [rsp+0xA0], xmm10
00007ac9d05dae62  vmovaps [rsp+0xB0], xmm11
00007ac9d05dae6b  vmovaps [rsp+0xC0], xmm12
00007ac9d05dae74  vmovaps [rsp+0xD0], xmm13
00007ac9d05dae7d  vmovaps [rsp+0xE0], xmm15
00007ac9d05dae86  sub rsp, 0x40
00007ac9d05dae8a  lea rdi, [rsp]
00007ac9d05dae8e  lea rsi, [rsp+0x10]
00007ac9d05dae93  lea rdx, [rsp+0x20]
00007ac9d05dae98  lea rcx, [rsp+0x30]
00007ac9d05dae9d  mov r8d, 0x00
00007ac9d05daea3  lea r9, [r15+0x3A8]
00007ac9d05daeaa  movaps [rdi], xmm14
00007ac9d05daeae  movaps [rsi], xmm15
00007ac9d05daeb2  movaps [rdx], xmm2
00007ac9d05daeb5  movaps [rcx], xmm1
00007ac9d05daeb8  mov rax, 0x569AF9F93A50
00007ac9d05daec2  call rax
00007ac9d05daec4  movaps xmm14, [rsp]
00007ac9d05daec9  add rsp, 0x40
00007ac9d05daecd  vmovaps xmm0, [rsp]
00007ac9d05daed2  vmovaps xmm1, [rsp+0x10]
00007ac9d05daed8  vmovaps xmm2, [rsp+0x20]
00007ac9d05daede  vmovaps xmm3, [rsp+0x30]
00007ac9d05daee4  vmovaps xmm4, [rsp+0x40]
00007ac9d05daeea  vmovaps xmm5, [rsp+0x50]
00007ac9d05daef0  vmovaps xmm6, [rsp+0x60]
00007ac9d05daef6  vmovaps xmm7, [rsp+0x70]
00007ac9d05daefc  vmovaps xmm8, [rsp+0x80]
00007ac9d05daf05  vmovaps xmm9, [rsp+0x90]
00007ac9d05daf0e  vmovaps xmm10, [rsp+0xA0]
00007ac9d05daf17  vmovaps xmm11, [rsp+0xB0]
00007ac9d05daf20  vmovaps xmm12, [rsp+0xC0]
00007ac9d05daf29  vmovaps xmm13, [rsp+0xD0]
00007ac9d05daf32  vmovaps xmm15, [rsp+0xE0]
00007ac9d05daf3b  add rsp, 0xF0
00007ac9d05daf42  pop r11
00007ac9d05daf44  pop r10
00007ac9d05daf46  pop r9
00007ac9d05daf48  pop r8
00007ac9d05daf4a  pop rsi
00007ac9d05daf4b  pop rdi
00007ac9d05daf4c  pop rdx
00007ac9d05daf4d  pop rcx
00007ac9d05daf4e  pop rax
00007ac9d05daf4f  add rsp, 0x08
00007ac9d05daf53  jmp 0x00007AC9D05DA01C
00007ac9d05daf58  sub rsp, 0x08
00007ac9d05daf5c  push rax
00007ac9d05daf5d  push rcx
00007ac9d05daf5e  push rdx
00007ac9d05daf5f  push rdi
00007ac9d05daf60  push rsi
00007ac9d05daf61  push r8
00007ac9d05daf63  push r9
00007ac9d05daf65  push r10
00007ac9d05daf67  push r11
00007ac9d05daf69  sub rsp, 0xF0
00007ac9d05daf70  vmovaps [rsp], xmm0
00007ac9d05daf75  vmovaps [rsp+0x10], xmm1
00007ac9d05daf7b  vmovaps [rsp+0x20], xmm3
00007ac9d05daf81  vmovaps [rsp+0x30], xmm4
00007ac9d05daf87  vmovaps [rsp+0x40], xmm5
00007ac9d05daf8d  vmovaps [rsp+0x50], xmm6
00007ac9d05daf93  vmovaps [rsp+0x60], xmm7
00007ac9d05daf99  vmovaps [rsp+0x70], xmm8
00007ac9d05daf9f  vmovaps [rsp+0x80], xmm9
00007ac9d05dafa8  vmovaps [rsp+0x90], xmm10
00007ac9d05dafb1  vmovaps [rsp+0xA0], xmm11
00007ac9d05dafba  vmovaps [rsp+0xB0], xmm12
00007ac9d05dafc3  vmovaps [rsp+0xC0], xmm13
00007ac9d05dafcc  vmovaps [rsp+0xD0], xmm14
00007ac9d05dafd5  vmovaps [rsp+0xE0], xmm15
00007ac9d05dafde  sub rsp, 0x40
00007ac9d05dafe2  lea rdi, [rsp]
00007ac9d05dafe6  lea rsi, [rsp+0x10]
00007ac9d05dafeb  lea rdx, [rsp+0x20]
00007ac9d05daff0  lea rcx, [rsp+0x30]
00007ac9d05daff5  mov r8d, 0x00
00007ac9d05daffb  lea r9, [r15+0x3A8]
00007ac9d05db002  movaps [rdi], xmm2
00007ac9d05db005  movaps [rsi], xmm15
00007ac9d05db009  movaps [rdx], xmm12
00007ac9d05db00d  movaps [rcx], xmm1
00007ac9d05db010  mov rax, 0x569AF9F93A50
00007ac9d05db01a  call rax
00007ac9d05db01c  movaps xmm2, [rsp]
00007ac9d05db020  add rsp, 0x40
00007ac9d05db024  vmovaps xmm0, [rsp]
00007ac9d05db029  vmovaps xmm1, [rsp+0x10]
00007ac9d05db02f  vmovaps xmm3, [rsp+0x20]
00007ac9d05db035  vmovaps xmm4, [rsp+0x30]
00007ac9d05db03b  vmovaps xmm5, [rsp+0x40]
00007ac9d05db041  vmovaps xmm6, [rsp+0x50]
00007ac9d05db047  vmovaps xmm7, [rsp+0x60]
00007ac9d05db04d  vmovaps xmm8, [rsp+0x70]
00007ac9d05db053  vmovaps xmm9, [rsp+0x80]
00007ac9d05db05c  vmovaps xmm10, [rsp+0x90]
00007ac9d05db065  vmovaps xmm11, [rsp+0xA0]
00007ac9d05db06e  vmovaps xmm12, [rsp+0xB0]
00007ac9d05db077  vmovaps xmm13, [rsp+0xC0]
00007ac9d05db080  vmovaps xmm14, [rsp+0xD0]
00007ac9d05db089  vmovaps xmm15, [rsp+0xE0]
00007ac9d05db092  add rsp, 0xF0
00007ac9d05db099  pop r11
00007ac9d05db09b  pop r10
00007ac9d05db09d  pop r9
00007ac9d05db09f  pop r8
00007ac9d05db0a1  pop rsi
00007ac9d05db0a2  pop rdi
00007ac9d05db0a3  pop rdx
00007ac9d05db0a4  pop rcx
00007ac9d05db0a5  pop rax
00007ac9d05db0a6  add rsp, 0x08
00007ac9d05db0aa  jmp 0x00007AC9D05DA059
00007ac9d05db0af  sub rsp, 0x08
00007ac9d05db0b3  push rax
00007ac9d05db0b4  push rcx
00007ac9d05db0b5  push rdx
00007ac9d05db0b6  push rdi
00007ac9d05db0b7  push rsi
00007ac9d05db0b8  push r8
00007ac9d05db0ba  push r9
00007ac9d05db0bc  push r10
00007ac9d05db0be  push r11
00007ac9d05db0c0  sub rsp, 0xF0
00007ac9d05db0c7  vmovaps [rsp], xmm0
00007ac9d05db0cc  vmovaps [rsp+0x10], xmm1
00007ac9d05db0d2  vmovaps [rsp+0x20], xmm2
00007ac9d05db0d8  vmovaps [rsp+0x30], xmm3
00007ac9d05db0de  vmovaps [rsp+0x40], xmm4
00007ac9d05db0e4  vmovaps [rsp+0x50], xmm5
00007ac9d05db0ea  vmovaps [rsp+0x60], xmm6
00007ac9d05db0f0  vmovaps [rsp+0x70], xmm7
00007ac9d05db0f6  vmovaps [rsp+0x80], xmm8
00007ac9d05db0ff  vmovaps [rsp+0x90], xmm9
00007ac9d05db108  vmovaps [rsp+0xA0], xmm10
00007ac9d05db111  vmovaps [rsp+0xB0], xmm11
00007ac9d05db11a  vmovaps [rsp+0xC0], xmm13
00007ac9d05db123  vmovaps [rsp+0xD0], xmm14
00007ac9d05db12c  vmovaps [rsp+0xE0], xmm15
00007ac9d05db135  sub rsp, 0x40
00007ac9d05db139  lea rdi, [rsp]
00007ac9d05db13d  lea rsi, [rsp+0x10]
00007ac9d05db142  lea rdx, [rsp+0x20]
00007ac9d05db147  lea rcx, [rsp+0x30]
00007ac9d05db14c  mov r8d, 0x00
00007ac9d05db152  lea r9, [r15+0x3A8]
00007ac9d05db159  movaps [rdi], xmm12
00007ac9d05db15d  movaps [rsi], xmm14
00007ac9d05db161  movaps [rdx], xmm3
00007ac9d05db164  movaps [rcx], xmm15
00007ac9d05db168  mov rax, 0x569AF9F93A50
00007ac9d05db172  call rax
00007ac9d05db174  movaps xmm12, [rsp]
00007ac9d05db179  add rsp, 0x40
00007ac9d05db17d  vmovaps xmm0, [rsp]
00007ac9d05db182  vmovaps xmm1, [rsp+0x10]
00007ac9d05db188  vmovaps xmm2, [rsp+0x20]
00007ac9d05db18e  vmovaps xmm3, [rsp+0x30]
00007ac9d05db194  vmovaps xmm4, [rsp+0x40]
00007ac9d05db19a  vmovaps xmm5, [rsp+0x50]
00007ac9d05db1a0  vmovaps xmm6, [rsp+0x60]
00007ac9d05db1a6  vmovaps xmm7, [rsp+0x70]
00007ac9d05db1ac  vmovaps xmm8, [rsp+0x80]
00007ac9d05db1b5  vmovaps xmm9, [rsp+0x90]
00007ac9d05db1be  vmovaps xmm10, [rsp+0xA0]
00007ac9d05db1c7  vmovaps xmm11, [rsp+0xB0]
00007ac9d05db1d0  vmovaps xmm13, [rsp+0xC0]
00007ac9d05db1d9  vmovaps xmm14, [rsp+0xD0]
00007ac9d05db1e2  vmovaps xmm15, [rsp+0xE0]
00007ac9d05db1eb  add rsp, 0xF0
00007ac9d05db1f2  pop r11
00007ac9d05db1f4  pop r10
00007ac9d05db1f6  pop r9
00007ac9d05db1f8  pop r8
00007ac9d05db1fa  pop rsi
00007ac9d05db1fb  pop rdi
00007ac9d05db1fc  pop rdx
00007ac9d05db1fd  pop rcx
00007ac9d05db1fe  pop rax
00007ac9d05db1ff  add rsp, 0x08
00007ac9d05db203  jmp 0x00007AC9D05DA0B3
00007ac9d05db208  sub rsp, 0x08
00007ac9d05db20c  push rax
00007ac9d05db20d  push rcx
00007ac9d05db20e  push rdx
00007ac9d05db20f  push rdi
00007ac9d05db210  push rsi
00007ac9d05db211  push r8
00007ac9d05db213  push r9
00007ac9d05db215  push r10
00007ac9d05db217  push r11
00007ac9d05db219  sub rsp, 0xF0
00007ac9d05db220  vmovaps [rsp], xmm0
00007ac9d05db225  vmovaps [rsp+0x10], xmm1
00007ac9d05db22b  vmovaps [rsp+0x20], xmm2
00007ac9d05db231  vmovaps [rsp+0x30], xmm3
00007ac9d05db237  vmovaps [rsp+0x40], xmm4
00007ac9d05db23d  vmovaps [rsp+0x50], xmm5
00007ac9d05db243  vmovaps [rsp+0x60], xmm6
00007ac9d05db249  vmovaps [rsp+0x70], xmm7
00007ac9d05db24f  vmovaps [rsp+0x80], xmm8
00007ac9d05db258  vmovaps [rsp+0x90], xmm10
00007ac9d05db261  vmovaps [rsp+0xA0], xmm11
00007ac9d05db26a  vmovaps [rsp+0xB0], xmm12
00007ac9d05db273  vmovaps [rsp+0xC0], xmm13
00007ac9d05db27c  vmovaps [rsp+0xD0], xmm14
00007ac9d05db285  vmovaps [rsp+0xE0], xmm15
00007ac9d05db28e  sub rsp, 0x40
00007ac9d05db292  lea rdi, [rsp]
00007ac9d05db296  lea rsi, [rsp+0x10]
00007ac9d05db29b  lea rdx, [rsp+0x20]
00007ac9d05db2a0  lea rcx, [rsp+0x30]
00007ac9d05db2a5  mov r8d, 0x00
00007ac9d05db2ab  lea r9, [r15+0x3A8]
00007ac9d05db2b2  movaps [rdi], xmm9
00007ac9d05db2b6  movaps [rsi], xmm13
00007ac9d05db2ba  movaps [rdx], xmm14
00007ac9d05db2be  movaps [rcx], xmm6
00007ac9d05db2c1  mov rax, 0x569AF9F93A50
00007ac9d05db2cb  call rax
00007ac9d05db2cd  movaps xmm9, [rsp]
00007ac9d05db2d2  add rsp, 0x40
00007ac9d05db2d6  vmovaps xmm0, [rsp]
00007ac9d05db2db  vmovaps xmm1, [rsp+0x10]
00007ac9d05db2e1  vmovaps xmm2, [rsp+0x20]
00007ac9d05db2e7  vmovaps xmm3, [rsp+0x30]
00007ac9d05db2ed  vmovaps xmm4, [rsp+0x40]
00007ac9d05db2f3  vmovaps xmm5, [rsp+0x50]
00007ac9d05db2f9  vmovaps xmm6, [rsp+0x60]
00007ac9d05db2ff  vmovaps xmm7, [rsp+0x70]
00007ac9d05db305  vmovaps xmm8, [rsp+0x80]
00007ac9d05db30e  vmovaps xmm10, [rsp+0x90]
00007ac9d05db317  vmovaps xmm11, [rsp+0xA0]
00007ac9d05db320  vmovaps xmm12, [rsp+0xB0]
00007ac9d05db329  vmovaps xmm13, [rsp+0xC0]
00007ac9d05db332  vmovaps xmm14, [rsp+0xD0]
00007ac9d05db33b  vmovaps xmm15, [rsp+0xE0]
00007ac9d05db344  add rsp, 0xF0
00007ac9d05db34b  pop r11
00007ac9d05db34d  pop r10
00007ac9d05db34f  pop r9
00007ac9d05db351  pop r8
00007ac9d05db353  pop rsi
00007ac9d05db354  pop rdi
00007ac9d05db355  pop rdx
00007ac9d05db356  pop rcx
00007ac9d05db357  pop rax
00007ac9d05db358  add rsp, 0x08
00007ac9d05db35c  jmp 0x00007AC9D05DA15D
00007ac9d05db361  sub rsp, 0x08
00007ac9d05db365  push rax
00007ac9d05db366  push rcx
00007ac9d05db367  push rdx
00007ac9d05db368  push rdi
00007ac9d05db369  push rsi
00007ac9d05db36a  push r8
00007ac9d05db36c  push r9
00007ac9d05db36e  push r10
00007ac9d05db370  push r11
00007ac9d05db372  sub rsp, 0xF0
00007ac9d05db379  vmovaps [rsp], xmm0
00007ac9d05db37e  vmovaps [rsp+0x10], xmm1
00007ac9d05db384  vmovaps [rsp+0x20], xmm2
00007ac9d05db38a  vmovaps [rsp+0x30], xmm4
00007ac9d05db390  vmovaps [rsp+0x40], xmm5
00007ac9d05db396  vmovaps [rsp+0x50], xmm6
00007ac9d05db39c  vmovaps [rsp+0x60], xmm7
00007ac9d05db3a2  vmovaps [rsp+0x70], xmm8
00007ac9d05db3a8  vmovaps [rsp+0x80], xmm9
00007ac9d05db3b1  vmovaps [rsp+0x90], xmm10
00007ac9d05db3ba  vmovaps [rsp+0xA0], xmm11
00007ac9d05db3c3  vmovaps [rsp+0xB0], xmm12
00007ac9d05db3cc  vmovaps [rsp+0xC0], xmm13
00007ac9d05db3d5  vmovaps [rsp+0xD0], xmm14
00007ac9d05db3de  vmovaps [rsp+0xE0], xmm15
00007ac9d05db3e7  sub rsp, 0x40
00007ac9d05db3eb  lea rdi, [rsp]
00007ac9d05db3ef  lea rsi, [rsp+0x10]
00007ac9d05db3f4  lea rdx, [rsp+0x20]
00007ac9d05db3f9  lea rcx, [rsp+0x30]
00007ac9d05db3fe  mov r8d, 0x00
00007ac9d05db404  lea r9, [r15+0x3A8]
00007ac9d05db40b  movaps [rdi], xmm3
00007ac9d05db40e  movaps [rsi], xmm13
00007ac9d05db412  movaps [rdx], xmm6
00007ac9d05db415  movaps [rcx], xmm14
00007ac9d05db419  mov rax, 0x569AF9F93A50
00007ac9d05db423  call rax
00007ac9d05db425  movaps xmm3, [rsp]
00007ac9d05db429  add rsp, 0x40
00007ac9d05db42d  vmovaps xmm0, [rsp]
00007ac9d05db432  vmovaps xmm1, [rsp+0x10]
00007ac9d05db438  vmovaps xmm2, [rsp+0x20]
00007ac9d05db43e  vmovaps xmm4, [rsp+0x30]
00007ac9d05db444  vmovaps xmm5, [rsp+0x40]
00007ac9d05db44a  vmovaps xmm6, [rsp+0x50]
00007ac9d05db450  vmovaps xmm7, [rsp+0x60]
00007ac9d05db456  vmovaps xmm8, [rsp+0x70]
00007ac9d05db45c  vmovaps xmm9, [rsp+0x80]
00007ac9d05db465  vmovaps xmm10, [rsp+0x90]
00007ac9d05db46e  vmovaps xmm11, [rsp+0xA0]
00007ac9d05db477  vmovaps xmm12, [rsp+0xB0]
00007ac9d05db480  vmovaps xmm13, [rsp+0xC0]
00007ac9d05db489  vmovaps xmm14, [rsp+0xD0]
00007ac9d05db492  vmovaps xmm15, [rsp+0xE0]
00007ac9d05db49b  add rsp, 0xF0
00007ac9d05db4a2  pop r11
00007ac9d05db4a4  pop r10
00007ac9d05db4a6  pop r9
00007ac9d05db4a8  pop r8
00007ac9d05db4aa  pop rsi
00007ac9d05db4ab  pop rdi
00007ac9d05db4ac  pop rdx
00007ac9d05db4ad  pop rcx
00007ac9d05db4ae  pop rax
00007ac9d05db4af  add rsp, 0x08
00007ac9d05db4b3  jmp 0x00007AC9D05DA19A
00007ac9d05db4b8  sub rsp, 0x08
00007ac9d05db4bc  push rax
00007ac9d05db4bd  push rcx
00007ac9d05db4be  push rdx
00007ac9d05db4bf  push rdi
00007ac9d05db4c0  push rsi
00007ac9d05db4c1  push r8
00007ac9d05db4c3  push r9
00007ac9d05db4c5  push r10
00007ac9d05db4c7  push r11
00007ac9d05db4c9  sub rsp, 0xF0
00007ac9d05db4d0  vmovaps [rsp], xmm0
00007ac9d05db4d5  vmovaps [rsp+0x10], xmm1
00007ac9d05db4db  vmovaps [rsp+0x20], xmm2
00007ac9d05db4e1  vmovaps [rsp+0x30], xmm3
00007ac9d05db4e7  vmovaps [rsp+0x40], xmm4
00007ac9d05db4ed  vmovaps [rsp+0x50], xmm5
00007ac9d05db4f3  vmovaps [rsp+0x60], xmm7
00007ac9d05db4f9  vmovaps [rsp+0x70], xmm8
00007ac9d05db4ff  vmovaps [rsp+0x80], xmm9
00007ac9d05db508  vmovaps [rsp+0x90], xmm10
00007ac9d05db511  vmovaps [rsp+0xA0], xmm11
00007ac9d05db51a  vmovaps [rsp+0xB0], xmm12
00007ac9d05db523  vmovaps [rsp+0xC0], xmm13
00007ac9d05db52c  vmovaps [rsp+0xD0], xmm14
00007ac9d05db535  vmovaps [rsp+0xE0], xmm15
00007ac9d05db53e  sub rsp, 0x40
00007ac9d05db542  lea rdi, [rsp]
00007ac9d05db546  lea rsi, [rsp+0x10]
00007ac9d05db54b  lea rdx, [rsp+0x20]
00007ac9d05db550  lea rcx, [rsp+0x30]
00007ac9d05db555  mov r8d, 0x00
00007ac9d05db55b  lea r9, [r15+0x3A8]
00007ac9d05db562  movaps [rdi], xmm6
00007ac9d05db565  movaps [rsi], xmm2
00007ac9d05db568  movaps [rdx], xmm14
00007ac9d05db56c  movaps [rcx], xmm1
00007ac9d05db56f  mov rax, 0x569AF9F93A50
00007ac9d05db579  call rax
00007ac9d05db57b  movaps xmm6, [rsp]
00007ac9d05db57f  add rsp, 0x40
00007ac9d05db583  vmovaps xmm0, [rsp]
00007ac9d05db588  vmovaps xmm1, [rsp+0x10]
00007ac9d05db58e  vmovaps xmm2, [rsp+0x20]
00007ac9d05db594  vmovaps xmm3, [rsp+0x30]
00007ac9d05db59a  vmovaps xmm4, [rsp+0x40]
00007ac9d05db5a0  vmovaps xmm5, [rsp+0x50]
00007ac9d05db5a6  vmovaps xmm7, [rsp+0x60]
00007ac9d05db5ac  vmovaps xmm8, [rsp+0x70]
00007ac9d05db5b2  vmovaps xmm9, [rsp+0x80]
00007ac9d05db5bb  vmovaps xmm10, [rsp+0x90]
00007ac9d05db5c4  vmovaps xmm11, [rsp+0xA0]
00007ac9d05db5cd  vmovaps xmm12, [rsp+0xB0]
00007ac9d05db5d6  vmovaps xmm13, [rsp+0xC0]
00007ac9d05db5df  vmovaps xmm14, [rsp+0xD0]
00007ac9d05db5e8  vmovaps xmm15, [rsp+0xE0]
00007ac9d05db5f1  add rsp, 0xF0
00007ac9d05db5f8  pop r11
00007ac9d05db5fa  pop r10
00007ac9d05db5fc  pop r9
00007ac9d05db5fe  pop r8
00007ac9d05db600  pop rsi
00007ac9d05db601  pop rdi
00007ac9d05db602  pop rdx
00007ac9d05db603  pop rcx
00007ac9d05db604  pop rax
00007ac9d05db605  add rsp, 0x08
00007ac9d05db609  jmp 0x00007AC9D05DA1C7
00007ac9d05db60e  sub rsp, 0x08
00007ac9d05db612  push rax
00007ac9d05db613  push rcx
00007ac9d05db614  push rdx
00007ac9d05db615  push rdi
00007ac9d05db616  push rsi
00007ac9d05db617  push r8
00007ac9d05db619  push r9
00007ac9d05db61b  push r10
00007ac9d05db61d  push r11
00007ac9d05db61f  sub rsp, 0xF0
00007ac9d05db626  vmovaps [rsp], xmm0
00007ac9d05db62b  vmovaps [rsp+0x10], xmm1
00007ac9d05db631  vmovaps [rsp+0x20], xmm2
00007ac9d05db637  vmovaps [rsp+0x30], xmm3
00007ac9d05db63d  vmovaps [rsp+0x40], xmm4
00007ac9d05db643  vmovaps [rsp+0x50], xmm5
00007ac9d05db649  vmovaps [rsp+0x60], xmm6
00007ac9d05db64f  vmovaps [rsp+0x70], xmm7
00007ac9d05db655  vmovaps [rsp+0x80], xmm8
00007ac9d05db65e  vmovaps [rsp+0x90], xmm9
00007ac9d05db667  vmovaps [rsp+0xA0], xmm10
00007ac9d05db670  vmovaps [rsp+0xB0], xmm11
00007ac9d05db679  vmovaps [rsp+0xC0], xmm12
00007ac9d05db682  vmovaps [rsp+0xD0], xmm14
00007ac9d05db68b  vmovaps [rsp+0xE0], xmm15
00007ac9d05db694  sub rsp, 0x40
00007ac9d05db698  lea rdi, [rsp]
00007ac9d05db69c  lea rsi, [rsp+0x10]
00007ac9d05db6a1  lea rdx, [rsp+0x20]
00007ac9d05db6a6  lea rcx, [rsp+0x30]
00007ac9d05db6ab  mov r8d, 0x00
00007ac9d05db6b1  lea r9, [r15+0x3A8]
00007ac9d05db6b8  movaps [rdi], xmm13
00007ac9d05db6bc  movaps [rsi], xmm12
00007ac9d05db6c0  movaps [rdx], xmm14
00007ac9d05db6c4  movaps [rcx], xmm1
00007ac9d05db6c7  mov rax, 0x569AF9F93A50
00007ac9d05db6d1  call rax
00007ac9d05db6d3  movaps xmm13, [rsp]
00007ac9d05db6d8  add rsp, 0x40
00007ac9d05db6dc  vmovaps xmm0, [rsp]
00007ac9d05db6e1  vmovaps xmm1, [rsp+0x10]
00007ac9d05db6e7  vmovaps xmm2, [rsp+0x20]
00007ac9d05db6ed  vmovaps xmm3, [rsp+0x30]
00007ac9d05db6f3  vmovaps xmm4, [rsp+0x40]
00007ac9d05db6f9  vmovaps xmm5, [rsp+0x50]
00007ac9d05db6ff  vmovaps xmm6, [rsp+0x60]
00007ac9d05db705  vmovaps xmm7, [rsp+0x70]
00007ac9d05db70b  vmovaps xmm8, [rsp+0x80]
00007ac9d05db714  vmovaps xmm9, [rsp+0x90]
00007ac9d05db71d  vmovaps xmm10, [rsp+0xA0]
00007ac9d05db726  vmovaps xmm11, [rsp+0xB0]
00007ac9d05db72f  vmovaps xmm12, [rsp+0xC0]
00007ac9d05db738  vmovaps xmm14, [rsp+0xD0]
00007ac9d05db741  vmovaps xmm15, [rsp+0xE0]
00007ac9d05db74a  add rsp, 0xF0
00007ac9d05db751  pop r11
00007ac9d05db753  pop r10
00007ac9d05db755  pop r9
00007ac9d05db757  pop r8
00007ac9d05db759  pop rsi
00007ac9d05db75a  pop rdi
00007ac9d05db75b  pop rdx
00007ac9d05db75c  pop rcx
00007ac9d05db75d  pop rax
00007ac9d05db75e  add rsp, 0x08
00007ac9d05db762  jmp 0x00007AC9D05DA1F9
00007ac9d05db767  sub rsp, 0x08
00007ac9d05db76b  push rax
00007ac9d05db76c  push rcx
00007ac9d05db76d  push rdx
00007ac9d05db76e  push rdi
00007ac9d05db76f  push rsi
00007ac9d05db770  push r8
00007ac9d05db772  push r9
00007ac9d05db774  push r10
00007ac9d05db776  push r11
00007ac9d05db778  sub rsp, 0xF0
00007ac9d05db77f  vmovaps [rsp], xmm0
00007ac9d05db784  vmovaps [rsp+0x10], xmm1
00007ac9d05db78a  vmovaps [rsp+0x20], xmm2
00007ac9d05db790  vmovaps [rsp+0x30], xmm3
00007ac9d05db796  vmovaps [rsp+0x40], xmm4
00007ac9d05db79c  vmovaps [rsp+0x50], xmm5
00007ac9d05db7a2  vmovaps [rsp+0x60], xmm6
00007ac9d05db7a8  vmovaps [rsp+0x70], xmm7
00007ac9d05db7ae  vmovaps [rsp+0x80], xmm8
00007ac9d05db7b7  vmovaps [rsp+0x90], xmm9
00007ac9d05db7c0  vmovaps [rsp+0xA0], xmm10
00007ac9d05db7c9  vmovaps [rsp+0xB0], xmm11
00007ac9d05db7d2  vmovaps [rsp+0xC0], xmm13
00007ac9d05db7db  vmovaps [rsp+0xD0], xmm14
00007ac9d05db7e4  vmovaps [rsp+0xE0], xmm15
00007ac9d05db7ed  sub rsp, 0x40
00007ac9d05db7f1  lea rdi, [rsp]
00007ac9d05db7f5  lea rsi, [rsp+0x10]
00007ac9d05db7fa  lea rdx, [rsp+0x20]
00007ac9d05db7ff  lea rcx, [rsp+0x30]
00007ac9d05db804  mov r8d, 0x00
00007ac9d05db80a  lea r9, [r15+0x3A8]
00007ac9d05db811  movaps [rdi], xmm12
00007ac9d05db815  movaps [rsi], xmm3
00007ac9d05db818  movaps [rdx], xmm14
00007ac9d05db81c  movaps [rcx], xmm5
00007ac9d05db81f  mov rax, 0x569AF9F93A50
00007ac9d05db829  call rax
00007ac9d05db82b  movaps xmm12, [rsp]
00007ac9d05db830  add rsp, 0x40
00007ac9d05db834  vmovaps xmm0, [rsp]
00007ac9d05db839  vmovaps xmm1, [rsp+0x10]
00007ac9d05db83f  vmovaps xmm2, [rsp+0x20]
00007ac9d05db845  vmovaps xmm3, [rsp+0x30]
00007ac9d05db84b  vmovaps xmm4, [rsp+0x40]
00007ac9d05db851  vmovaps xmm5, [rsp+0x50]
00007ac9d05db857  vmovaps xmm6, [rsp+0x60]
00007ac9d05db85d  vmovaps xmm7, [rsp+0x70]
00007ac9d05db863  vmovaps xmm8, [rsp+0x80]
00007ac9d05db86c  vmovaps xmm9, [rsp+0x90]
00007ac9d05db875  vmovaps xmm10, [rsp+0xA0]
00007ac9d05db87e  vmovaps xmm11, [rsp+0xB0]
00007ac9d05db887  vmovaps xmm13, [rsp+0xC0]
00007ac9d05db890  vmovaps xmm14, [rsp+0xD0]
00007ac9d05db899  vmovaps xmm15, [rsp+0xE0]
00007ac9d05db8a2  add rsp, 0xF0
00007ac9d05db8a9  pop r11
00007ac9d05db8ab  pop r10
00007ac9d05db8ad  pop r9
00007ac9d05db8af  pop r8
00007ac9d05db8b1  pop rsi
00007ac9d05db8b2  pop rdi
00007ac9d05db8b3  pop rdx
00007ac9d05db8b4  pop rcx
00007ac9d05db8b5  pop rax
00007ac9d05db8b6  add rsp, 0x08
00007ac9d05db8ba  jmp 0x00007AC9D05DA256
00007ac9d05db8bf  sub rsp, 0x08
00007ac9d05db8c3  push rax
00007ac9d05db8c4  push rcx
00007ac9d05db8c5  push rdx
00007ac9d05db8c6  push rdi
00007ac9d05db8c7  push rsi
00007ac9d05db8c8  push r8
00007ac9d05db8ca  push r9
00007ac9d05db8cc  push r10
00007ac9d05db8ce  push r11
00007ac9d05db8d0  sub rsp, 0xF0
00007ac9d05db8d7  vmovaps [rsp], xmm0
00007ac9d05db8dc  vmovaps [rsp+0x10], xmm1
00007ac9d05db8e2  vmovaps [rsp+0x20], xmm2
00007ac9d05db8e8  vmovaps [rsp+0x30], xmm3
00007ac9d05db8ee  vmovaps [rsp+0x40], xmm4
00007ac9d05db8f4  vmovaps [rsp+0x50], xmm5
00007ac9d05db8fa  vmovaps [rsp+0x60], xmm6
00007ac9d05db900  vmovaps [rsp+0x70], xmm7
00007ac9d05db906  vmovaps [rsp+0x80], xmm8
00007ac9d05db90f  vmovaps [rsp+0x90], xmm9
00007ac9d05db918  vmovaps [rsp+0xA0], xmm11
00007ac9d05db921  vmovaps [rsp+0xB0], xmm12
00007ac9d05db92a  vmovaps [rsp+0xC0], xmm13
00007ac9d05db933  vmovaps [rsp+0xD0], xmm14
00007ac9d05db93c  vmovaps [rsp+0xE0], xmm15
00007ac9d05db945  sub rsp, 0x40
00007ac9d05db949  lea rdi, [rsp]
00007ac9d05db94d  lea rsi, [rsp+0x10]
00007ac9d05db952  lea rdx, [rsp+0x20]
00007ac9d05db957  lea rcx, [rsp+0x30]
00007ac9d05db95c  mov r8d, 0x00
00007ac9d05db962  lea r9, [r15+0x3A8]
00007ac9d05db969  movaps [rdi], xmm10
00007ac9d05db96d  movaps [rsi], xmm9
00007ac9d05db971  movaps [rdx], xmm7
00007ac9d05db974  movaps [rcx], xmm14
00007ac9d05db978  mov rax, 0x569AF9F93A50
00007ac9d05db982  call rax
00007ac9d05db984  movaps xmm10, [rsp]
00007ac9d05db989  add rsp, 0x40
00007ac9d05db98d  vmovaps xmm0, [rsp]
00007ac9d05db992  vmovaps xmm1, [rsp+0x10]
00007ac9d05db998  vmovaps xmm2, [rsp+0x20]
00007ac9d05db99e  vmovaps xmm3, [rsp+0x30]
00007ac9d05db9a4  vmovaps xmm4, [rsp+0x40]
00007ac9d05db9aa  vmovaps xmm5, [rsp+0x50]
00007ac9d05db9b0  vmovaps xmm6, [rsp+0x60]
00007ac9d05db9b6  vmovaps xmm7, [rsp+0x70]
00007ac9d05db9bc  vmovaps xmm8, [rsp+0x80]
00007ac9d05db9c5  vmovaps xmm9, [rsp+0x90]
00007ac9d05db9ce  vmovaps xmm11, [rsp+0xA0]
00007ac9d05db9d7  vmovaps xmm12, [rsp+0xB0]
00007ac9d05db9e0  vmovaps xmm13, [rsp+0xC0]
00007ac9d05db9e9  vmovaps xmm14, [rsp+0xD0]
00007ac9d05db9f2  vmovaps xmm15, [rsp+0xE0]
00007ac9d05db9fb  add rsp, 0xF0
00007ac9d05dba02  pop r11
00007ac9d05dba04  pop r10
00007ac9d05dba06  pop r9
00007ac9d05dba08  pop r8
00007ac9d05dba0a  pop rsi
00007ac9d05dba0b  pop rdi
00007ac9d05dba0c  pop rdx
00007ac9d05dba0d  pop rcx
00007ac9d05dba0e  pop rax
00007ac9d05dba0f  add rsp, 0x08
00007ac9d05dba13  jmp 0x00007AC9D05DA27C
00007ac9d05dba18  call 0x00007AC9D040D4E0
00007ac9d05dba1d  jmp 0x00007AC9D05DA289
00007ac9d05dba22  sub rsp, 0x08
00007ac9d05dba26  push rax
00007ac9d05dba27  push rcx
00007ac9d05dba28  push rdx
00007ac9d05dba29  push rdi
00007ac9d05dba2a  push rsi
00007ac9d05dba2b  push r8
00007ac9d05dba2d  push r9
00007ac9d05dba2f  push r10
00007ac9d05dba31  push r11
00007ac9d05dba33  sub rsp, 0xF0
00007ac9d05dba3a  vmovaps [rsp], xmm0
00007ac9d05dba3f  vmovaps [rsp+0x10], xmm1
00007ac9d05dba45  vmovaps [rsp+0x20], xmm2
00007ac9d05dba4b  vmovaps [rsp+0x30], xmm3
00007ac9d05dba51  vmovaps [rsp+0x40], xmm4
00007ac9d05dba57  vmovaps [rsp+0x50], xmm6
00007ac9d05dba5d  vmovaps [rsp+0x60], xmm7
00007ac9d05dba63  vmovaps [rsp+0x70], xmm8
00007ac9d05dba69  vmovaps [rsp+0x80], xmm9
00007ac9d05dba72  vmovaps [rsp+0x90], xmm10
00007ac9d05dba7b  vmovaps [rsp+0xA0], xmm11
00007ac9d05dba84  vmovaps [rsp+0xB0], xmm12
00007ac9d05dba8d  vmovaps [rsp+0xC0], xmm13
00007ac9d05dba96  vmovaps [rsp+0xD0], xmm14
00007ac9d05dba9f  vmovaps [rsp+0xE0], xmm15
00007ac9d05dbaa8  sub rsp, 0x40
00007ac9d05dbaac  lea rdi, [rsp]
00007ac9d05dbab0  lea rsi, [rsp+0x10]
00007ac9d05dbab5  lea rdx, [rsp+0x20]
00007ac9d05dbaba  lea rcx, [rsp+0x30]
00007ac9d05dbabf  mov r8d, 0x00
00007ac9d05dbac5  lea r9, [r15+0x3A8]
00007ac9d05dbacc  movaps [rdi], xmm5
00007ac9d05dbacf  movaps [rsi], xmm6
00007ac9d05dbad2  movaps [rdx], xmm7
00007ac9d05dbad5  movaps [rcx], xmm9
00007ac9d05dbad9  mov rax, 0x569AF9F93A50
00007ac9d05dbae3  call rax
00007ac9d05dbae5  movaps xmm5, [rsp]
00007ac9d05dbae9  add rsp, 0x40
00007ac9d05dbaed  vmovaps xmm0, [rsp]
00007ac9d05dbaf2  vmovaps xmm1, [rsp+0x10]
00007ac9d05dbaf8  vmovaps xmm2, [rsp+0x20]
00007ac9d05dbafe  vmovaps xmm3, [rsp+0x30]
00007ac9d05dbb04  vmovaps xmm4, [rsp+0x40]
00007ac9d05dbb0a  vmovaps xmm6, [rsp+0x50]
00007ac9d05dbb10  vmovaps xmm7, [rsp+0x60]
00007ac9d05dbb16  vmovaps xmm8, [rsp+0x70]
00007ac9d05dbb1c  vmovaps xmm9, [rsp+0x80]
00007ac9d05dbb25  vmovaps xmm10, [rsp+0x90]
00007ac9d05dbb2e  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dbb37  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dbb40  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dbb49  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dbb52  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dbb5b  add rsp, 0xF0
00007ac9d05dbb62  pop r11
00007ac9d05dbb64  pop r10
00007ac9d05dbb66  pop r9
00007ac9d05dbb68  pop r8
00007ac9d05dbb6a  pop rsi
00007ac9d05dbb6b  pop rdi
00007ac9d05dbb6c  pop rdx
00007ac9d05dbb6d  pop rcx
00007ac9d05dbb6e  pop rax
00007ac9d05dbb6f  add rsp, 0x08
00007ac9d05dbb73  jmp 0x00007AC9D05DA2BB
00007ac9d05dbb78  sub rsp, 0x08
00007ac9d05dbb7c  push rax
00007ac9d05dbb7d  push rcx
00007ac9d05dbb7e  push rdx
00007ac9d05dbb7f  push rdi
00007ac9d05dbb80  push rsi
00007ac9d05dbb81  push r8
00007ac9d05dbb83  push r9
00007ac9d05dbb85  push r10
00007ac9d05dbb87  push r11
00007ac9d05dbb89  sub rsp, 0xF0
00007ac9d05dbb90  vmovaps [rsp], xmm0
00007ac9d05dbb95  vmovaps [rsp+0x10], xmm1
00007ac9d05dbb9b  vmovaps [rsp+0x20], xmm2
00007ac9d05dbba1  vmovaps [rsp+0x30], xmm3
00007ac9d05dbba7  vmovaps [rsp+0x40], xmm4
00007ac9d05dbbad  vmovaps [rsp+0x50], xmm5
00007ac9d05dbbb3  vmovaps [rsp+0x60], xmm6
00007ac9d05dbbb9  vmovaps [rsp+0x70], xmm8
00007ac9d05dbbbf  vmovaps [rsp+0x80], xmm9
00007ac9d05dbbc8  vmovaps [rsp+0x90], xmm10
00007ac9d05dbbd1  vmovaps [rsp+0xA0], xmm11
00007ac9d05dbbda  vmovaps [rsp+0xB0], xmm12
00007ac9d05dbbe3  vmovaps [rsp+0xC0], xmm13
00007ac9d05dbbec  vmovaps [rsp+0xD0], xmm14
00007ac9d05dbbf5  vmovaps [rsp+0xE0], xmm15
00007ac9d05dbbfe  sub rsp, 0x40
00007ac9d05dbc02  lea rdi, [rsp]
00007ac9d05dbc06  lea rsi, [rsp+0x10]
00007ac9d05dbc0b  lea rdx, [rsp+0x20]
00007ac9d05dbc10  lea rcx, [rsp+0x30]
00007ac9d05dbc15  mov r8d, 0x00
00007ac9d05dbc1b  lea r9, [r15+0x3A8]
00007ac9d05dbc22  movaps [rdi], xmm7
00007ac9d05dbc25  movaps [rsi], xmm13
00007ac9d05dbc29  movaps [rdx], xmm1
00007ac9d05dbc2c  movaps [rcx], xmm9
00007ac9d05dbc30  mov rax, 0x569AF9F93A50
00007ac9d05dbc3a  call rax
00007ac9d05dbc3c  movaps xmm7, [rsp]
00007ac9d05dbc40  add rsp, 0x40
00007ac9d05dbc44  vmovaps xmm0, [rsp]
00007ac9d05dbc49  vmovaps xmm1, [rsp+0x10]
00007ac9d05dbc4f  vmovaps xmm2, [rsp+0x20]
00007ac9d05dbc55  vmovaps xmm3, [rsp+0x30]
00007ac9d05dbc5b  vmovaps xmm4, [rsp+0x40]
00007ac9d05dbc61  vmovaps xmm5, [rsp+0x50]
00007ac9d05dbc67  vmovaps xmm6, [rsp+0x60]
00007ac9d05dbc6d  vmovaps xmm8, [rsp+0x70]
00007ac9d05dbc73  vmovaps xmm9, [rsp+0x80]
00007ac9d05dbc7c  vmovaps xmm10, [rsp+0x90]
00007ac9d05dbc85  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dbc8e  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dbc97  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dbca0  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dbca9  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dbcb2  add rsp, 0xF0
00007ac9d05dbcb9  pop r11
00007ac9d05dbcbb  pop r10
00007ac9d05dbcbd  pop r9
00007ac9d05dbcbf  pop r8
00007ac9d05dbcc1  pop rsi
00007ac9d05dbcc2  pop rdi
00007ac9d05dbcc3  pop rdx
00007ac9d05dbcc4  pop rcx
00007ac9d05dbcc5  pop rax
00007ac9d05dbcc6  add rsp, 0x08
00007ac9d05dbcca  jmp 0x00007AC9D05DA2E0
00007ac9d05dbccf  call 0x00007AC9D040C260
00007ac9d05dbcd4  jmp 0x00007AC9D05DA303
00007ac9d05dbcd9  call 0x00007AC9D0407890
00007ac9d05dbcde  jmp 0x00007AC9D05DA30D
00007ac9d05dbce3  sub rsp, 0x08
00007ac9d05dbce7  push rax
00007ac9d05dbce8  push rcx
00007ac9d05dbce9  push rdx
00007ac9d05dbcea  push rdi
00007ac9d05dbceb  push rsi
00007ac9d05dbcec  push r8
00007ac9d05dbcee  push r9
00007ac9d05dbcf0  push r10
00007ac9d05dbcf2  push r11
00007ac9d05dbcf4  sub rsp, 0xF0
00007ac9d05dbcfb  vmovaps [rsp], xmm0
00007ac9d05dbd00  vmovaps [rsp+0x10], xmm1
00007ac9d05dbd06  vmovaps [rsp+0x20], xmm3
00007ac9d05dbd0c  vmovaps [rsp+0x30], xmm4
00007ac9d05dbd12  vmovaps [rsp+0x40], xmm5
00007ac9d05dbd18  vmovaps [rsp+0x50], xmm6
00007ac9d05dbd1e  vmovaps [rsp+0x60], xmm7
00007ac9d05dbd24  vmovaps [rsp+0x70], xmm8
00007ac9d05dbd2a  vmovaps [rsp+0x80], xmm9
00007ac9d05dbd33  vmovaps [rsp+0x90], xmm10
00007ac9d05dbd3c  vmovaps [rsp+0xA0], xmm11
00007ac9d05dbd45  vmovaps [rsp+0xB0], xmm12
00007ac9d05dbd4e  vmovaps [rsp+0xC0], xmm13
00007ac9d05dbd57  vmovaps [rsp+0xD0], xmm14
00007ac9d05dbd60  vmovaps [rsp+0xE0], xmm15
00007ac9d05dbd69  sub rsp, 0x40
00007ac9d05dbd6d  lea rdi, [rsp]
00007ac9d05dbd71  lea rsi, [rsp+0x10]
00007ac9d05dbd76  lea rdx, [rsp+0x20]
00007ac9d05dbd7b  lea rcx, [rsp+0x30]
00007ac9d05dbd80  mov r8d, 0x00
00007ac9d05dbd86  lea r9, [r15+0x3A8]
00007ac9d05dbd8d  movaps [rdi], xmm2
00007ac9d05dbd90  movaps [rsi], xmm12
00007ac9d05dbd94  movaps [rdx], xmm6
00007ac9d05dbd97  movaps [rcx], xmm3
00007ac9d05dbd9a  mov rax, 0x569AF9F93A50
00007ac9d05dbda4  call rax
00007ac9d05dbda6  movaps xmm2, [rsp]
00007ac9d05dbdaa  add rsp, 0x40
00007ac9d05dbdae  vmovaps xmm0, [rsp]
00007ac9d05dbdb3  vmovaps xmm1, [rsp+0x10]
00007ac9d05dbdb9  vmovaps xmm3, [rsp+0x20]
00007ac9d05dbdbf  vmovaps xmm4, [rsp+0x30]
00007ac9d05dbdc5  vmovaps xmm5, [rsp+0x40]
00007ac9d05dbdcb  vmovaps xmm6, [rsp+0x50]
00007ac9d05dbdd1  vmovaps xmm7, [rsp+0x60]
00007ac9d05dbdd7  vmovaps xmm8, [rsp+0x70]
00007ac9d05dbddd  vmovaps xmm9, [rsp+0x80]
00007ac9d05dbde6  vmovaps xmm10, [rsp+0x90]
00007ac9d05dbdef  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dbdf8  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dbe01  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dbe0a  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dbe13  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dbe1c  add rsp, 0xF0
00007ac9d05dbe23  pop r11
00007ac9d05dbe25  pop r10
00007ac9d05dbe27  pop r9
00007ac9d05dbe29  pop r8
00007ac9d05dbe2b  pop rsi
00007ac9d05dbe2c  pop rdi
00007ac9d05dbe2d  pop rdx
00007ac9d05dbe2e  pop rcx
00007ac9d05dbe2f  pop rax
00007ac9d05dbe30  add rsp, 0x08
00007ac9d05dbe34  jmp 0x00007AC9D05DA353
00007ac9d05dbe39  sub rsp, 0x08
00007ac9d05dbe3d  push rax
00007ac9d05dbe3e  push rcx
00007ac9d05dbe3f  push rdx
00007ac9d05dbe40  push rdi
00007ac9d05dbe41  push rsi
00007ac9d05dbe42  push r8
00007ac9d05dbe44  push r9
00007ac9d05dbe46  push r10
00007ac9d05dbe48  push r11
00007ac9d05dbe4a  sub rsp, 0xF0
00007ac9d05dbe51  vmovaps [rsp], xmm0
00007ac9d05dbe56  vmovaps [rsp+0x10], xmm1
00007ac9d05dbe5c  vmovaps [rsp+0x20], xmm2
00007ac9d05dbe62  vmovaps [rsp+0x30], xmm3
00007ac9d05dbe68  vmovaps [rsp+0x40], xmm4
00007ac9d05dbe6e  vmovaps [rsp+0x50], xmm5
00007ac9d05dbe74  vmovaps [rsp+0x60], xmm7
00007ac9d05dbe7a  vmovaps [rsp+0x70], xmm8
00007ac9d05dbe80  vmovaps [rsp+0x80], xmm9
00007ac9d05dbe89  vmovaps [rsp+0x90], xmm10
00007ac9d05dbe92  vmovaps [rsp+0xA0], xmm11
00007ac9d05dbe9b  vmovaps [rsp+0xB0], xmm12
00007ac9d05dbea4  vmovaps [rsp+0xC0], xmm13
00007ac9d05dbead  vmovaps [rsp+0xD0], xmm14
00007ac9d05dbeb6  vmovaps [rsp+0xE0], xmm15
00007ac9d05dbebf  sub rsp, 0x40
00007ac9d05dbec3  lea rdi, [rsp]
00007ac9d05dbec7  lea rsi, [rsp+0x10]
00007ac9d05dbecc  lea rdx, [rsp+0x20]
00007ac9d05dbed1  lea rcx, [rsp+0x30]
00007ac9d05dbed6  mov r8d, 0x00
00007ac9d05dbedc  lea r9, [r15+0x3A8]
00007ac9d05dbee3  movaps [rdi], xmm6
00007ac9d05dbee6  movaps [rsi], xmm10
00007ac9d05dbeea  movaps [rdx], xmm12
00007ac9d05dbeee  movaps [rcx], xmm1
00007ac9d05dbef1  mov rax, 0x569AF9F93A50
00007ac9d05dbefb  call rax
00007ac9d05dbefd  movaps xmm6, [rsp]
00007ac9d05dbf01  add rsp, 0x40
00007ac9d05dbf05  vmovaps xmm0, [rsp]
00007ac9d05dbf0a  vmovaps xmm1, [rsp+0x10]
00007ac9d05dbf10  vmovaps xmm2, [rsp+0x20]
00007ac9d05dbf16  vmovaps xmm3, [rsp+0x30]
00007ac9d05dbf1c  vmovaps xmm4, [rsp+0x40]
00007ac9d05dbf22  vmovaps xmm5, [rsp+0x50]
00007ac9d05dbf28  vmovaps xmm7, [rsp+0x60]
00007ac9d05dbf2e  vmovaps xmm8, [rsp+0x70]
00007ac9d05dbf34  vmovaps xmm9, [rsp+0x80]
00007ac9d05dbf3d  vmovaps xmm10, [rsp+0x90]
00007ac9d05dbf46  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dbf4f  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dbf58  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dbf61  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dbf6a  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dbf73  add rsp, 0xF0
00007ac9d05dbf7a  pop r11
00007ac9d05dbf7c  pop r10
00007ac9d05dbf7e  pop r9
00007ac9d05dbf80  pop r8
00007ac9d05dbf82  pop rsi
00007ac9d05dbf83  pop rdi
00007ac9d05dbf84  pop rdx
00007ac9d05dbf85  pop rcx
00007ac9d05dbf86  pop rax
00007ac9d05dbf87  add rsp, 0x08
00007ac9d05dbf8b  jmp 0x00007AC9D05DA381
00007ac9d05dbf90  sub rsp, 0x08
00007ac9d05dbf94  push rax
00007ac9d05dbf95  push rcx
00007ac9d05dbf96  push rdx
00007ac9d05dbf97  push rdi
00007ac9d05dbf98  push rsi
00007ac9d05dbf99  push r8
00007ac9d05dbf9b  push r9
00007ac9d05dbf9d  push r10
00007ac9d05dbf9f  push r11
00007ac9d05dbfa1  sub rsp, 0xF0
00007ac9d05dbfa8  vmovaps [rsp], xmm0
00007ac9d05dbfad  vmovaps [rsp+0x10], xmm1
00007ac9d05dbfb3  vmovaps [rsp+0x20], xmm2
00007ac9d05dbfb9  vmovaps [rsp+0x30], xmm3
00007ac9d05dbfbf  vmovaps [rsp+0x40], xmm4
00007ac9d05dbfc5  vmovaps [rsp+0x50], xmm5
00007ac9d05dbfcb  vmovaps [rsp+0x60], xmm6
00007ac9d05dbfd1  vmovaps [rsp+0x70], xmm7
00007ac9d05dbfd7  vmovaps [rsp+0x80], xmm8
00007ac9d05dbfe0  vmovaps [rsp+0x90], xmm9
00007ac9d05dbfe9  vmovaps [rsp+0xA0], xmm11
00007ac9d05dbff2  vmovaps [rsp+0xB0], xmm12
00007ac9d05dbffb  vmovaps [rsp+0xC0], xmm13
00007ac9d05dc004  vmovaps [rsp+0xD0], xmm14
00007ac9d05dc00d  vmovaps [rsp+0xE0], xmm15
00007ac9d05dc016  sub rsp, 0x40
00007ac9d05dc01a  lea rdi, [rsp]
00007ac9d05dc01e  lea rsi, [rsp+0x10]
00007ac9d05dc023  lea rdx, [rsp+0x20]
00007ac9d05dc028  lea rcx, [rsp+0x30]
00007ac9d05dc02d  mov r8d, 0x00
00007ac9d05dc033  lea r9, [r15+0x3A8]
00007ac9d05dc03a  movaps [rdi], xmm10
00007ac9d05dc03e  movaps [rsi], xmm5
00007ac9d05dc041  movaps [rdx], xmm12
00007ac9d05dc045  movaps [rcx], xmm1
00007ac9d05dc048  mov rax, 0x569AF9F93A50
00007ac9d05dc052  call rax
00007ac9d05dc054  movaps xmm10, [rsp]
00007ac9d05dc059  add rsp, 0x40
00007ac9d05dc05d  vmovaps xmm0, [rsp]
00007ac9d05dc062  vmovaps xmm1, [rsp+0x10]
00007ac9d05dc068  vmovaps xmm2, [rsp+0x20]
00007ac9d05dc06e  vmovaps xmm3, [rsp+0x30]
00007ac9d05dc074  vmovaps xmm4, [rsp+0x40]
00007ac9d05dc07a  vmovaps xmm5, [rsp+0x50]
00007ac9d05dc080  vmovaps xmm6, [rsp+0x60]
00007ac9d05dc086  vmovaps xmm7, [rsp+0x70]
00007ac9d05dc08c  vmovaps xmm8, [rsp+0x80]
00007ac9d05dc095  vmovaps xmm9, [rsp+0x90]
00007ac9d05dc09e  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dc0a7  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dc0b0  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dc0b9  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dc0c2  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dc0cb  add rsp, 0xF0
00007ac9d05dc0d2  pop r11
00007ac9d05dc0d4  pop r10
00007ac9d05dc0d6  pop r9
00007ac9d05dc0d8  pop r8
00007ac9d05dc0da  pop rsi
00007ac9d05dc0db  pop rdi
00007ac9d05dc0dc  pop rdx
00007ac9d05dc0dd  pop rcx
00007ac9d05dc0de  pop rax
00007ac9d05dc0df  add rsp, 0x08
00007ac9d05dc0e3  jmp 0x00007AC9D05DA3B0
00007ac9d05dc0e8  sub rsp, 0x08
00007ac9d05dc0ec  push rax
00007ac9d05dc0ed  push rcx
00007ac9d05dc0ee  push rdx
00007ac9d05dc0ef  push rdi
00007ac9d05dc0f0  push rsi
00007ac9d05dc0f1  push r8
00007ac9d05dc0f3  push r9
00007ac9d05dc0f5  push r10
00007ac9d05dc0f7  push r11
00007ac9d05dc0f9  sub rsp, 0xF0
00007ac9d05dc100  vmovaps [rsp], xmm0
00007ac9d05dc105  vmovaps [rsp+0x10], xmm1
00007ac9d05dc10b  vmovaps [rsp+0x20], xmm2
00007ac9d05dc111  vmovaps [rsp+0x30], xmm3
00007ac9d05dc117  vmovaps [rsp+0x40], xmm4
00007ac9d05dc11d  vmovaps [rsp+0x50], xmm5
00007ac9d05dc123  vmovaps [rsp+0x60], xmm6
00007ac9d05dc129  vmovaps [rsp+0x70], xmm7
00007ac9d05dc12f  vmovaps [rsp+0x80], xmm8
00007ac9d05dc138  vmovaps [rsp+0x90], xmm9
00007ac9d05dc141  vmovaps [rsp+0xA0], xmm10
00007ac9d05dc14a  vmovaps [rsp+0xB0], xmm11
00007ac9d05dc153  vmovaps [rsp+0xC0], xmm13
00007ac9d05dc15c  vmovaps [rsp+0xD0], xmm14
00007ac9d05dc165  vmovaps [rsp+0xE0], xmm15
00007ac9d05dc16e  sub rsp, 0x40
00007ac9d05dc172  lea rdi, [rsp]
00007ac9d05dc176  lea rsi, [rsp+0x10]
00007ac9d05dc17b  lea rdx, [rsp+0x20]
00007ac9d05dc180  lea rcx, [rsp+0x30]
00007ac9d05dc185  mov r8d, 0x00
00007ac9d05dc18b  lea r9, [r15+0x3A8]
00007ac9d05dc192  movaps [rdi], xmm12
00007ac9d05dc196  movaps [rsi], xmm7
00007ac9d05dc199  movaps [rdx], xmm15
00007ac9d05dc19d  movaps [rcx], xmm1
00007ac9d05dc1a0  mov rax, 0x569AF9F93A50
00007ac9d05dc1aa  call rax
00007ac9d05dc1ac  movaps xmm12, [rsp]
00007ac9d05dc1b1  add rsp, 0x40
00007ac9d05dc1b5  vmovaps xmm0, [rsp]
00007ac9d05dc1ba  vmovaps xmm1, [rsp+0x10]
00007ac9d05dc1c0  vmovaps xmm2, [rsp+0x20]
00007ac9d05dc1c6  vmovaps xmm3, [rsp+0x30]
00007ac9d05dc1cc  vmovaps xmm4, [rsp+0x40]
00007ac9d05dc1d2  vmovaps xmm5, [rsp+0x50]
00007ac9d05dc1d8  vmovaps xmm6, [rsp+0x60]
00007ac9d05dc1de  vmovaps xmm7, [rsp+0x70]
00007ac9d05dc1e4  vmovaps xmm8, [rsp+0x80]
00007ac9d05dc1ed  vmovaps xmm9, [rsp+0x90]
00007ac9d05dc1f6  vmovaps xmm10, [rsp+0xA0]
00007ac9d05dc1ff  vmovaps xmm11, [rsp+0xB0]
00007ac9d05dc208  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dc211  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dc21a  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dc223  add rsp, 0xF0
00007ac9d05dc22a  pop r11
00007ac9d05dc22c  pop r10
00007ac9d05dc22e  pop r9
00007ac9d05dc230  pop r8
00007ac9d05dc232  pop rsi
00007ac9d05dc233  pop rdi
00007ac9d05dc234  pop rdx
00007ac9d05dc235  pop rcx
00007ac9d05dc236  pop rax
00007ac9d05dc237  add rsp, 0x08
00007ac9d05dc23b  jmp 0x00007AC9D05DA3D9
00007ac9d05dc240  call 0x00007AC9D03FF430
00007ac9d05dc245  jmp 0x00007AC9D05DA3E3
00007ac9d05dc24a  call 0x00007AC9D040E760
00007ac9d05dc24f  jmp 0x00007AC9D05DA3ED
00007ac9d05dc254  sub rsp, 0x08
00007ac9d05dc258  push rax
00007ac9d05dc259  push rcx
00007ac9d05dc25a  push rdx
00007ac9d05dc25b  push rdi
00007ac9d05dc25c  push rsi
00007ac9d05dc25d  push r8
00007ac9d05dc25f  push r9
00007ac9d05dc261  push r10
00007ac9d05dc263  push r11
00007ac9d05dc265  sub rsp, 0xF0
00007ac9d05dc26c  vmovaps [rsp], xmm0
00007ac9d05dc271  vmovaps [rsp+0x10], xmm1
00007ac9d05dc277  vmovaps [rsp+0x20], xmm2
00007ac9d05dc27d  vmovaps [rsp+0x30], xmm3
00007ac9d05dc283  vmovaps [rsp+0x40], xmm4
00007ac9d05dc289  vmovaps [rsp+0x50], xmm5
00007ac9d05dc28f  vmovaps [rsp+0x60], xmm6
00007ac9d05dc295  vmovaps [rsp+0x70], xmm8
00007ac9d05dc29b  vmovaps [rsp+0x80], xmm9
00007ac9d05dc2a4  vmovaps [rsp+0x90], xmm10
00007ac9d05dc2ad  vmovaps [rsp+0xA0], xmm11
00007ac9d05dc2b6  vmovaps [rsp+0xB0], xmm12
00007ac9d05dc2bf  vmovaps [rsp+0xC0], xmm13
00007ac9d05dc2c8  vmovaps [rsp+0xD0], xmm14
00007ac9d05dc2d1  vmovaps [rsp+0xE0], xmm15
00007ac9d05dc2da  sub rsp, 0x40
00007ac9d05dc2de  lea rdi, [rsp]
00007ac9d05dc2e2  lea rsi, [rsp+0x10]
00007ac9d05dc2e7  lea rdx, [rsp+0x20]
00007ac9d05dc2ec  lea rcx, [rsp+0x30]
00007ac9d05dc2f1  mov r8d, 0x00
00007ac9d05dc2f7  lea r9, [r15+0x3A8]
00007ac9d05dc2fe  movaps [rdi], xmm7
00007ac9d05dc301  movaps [rsi], xmm2
00007ac9d05dc304  movaps [rdx], xmm9
00007ac9d05dc308  movaps [rcx], xmm11
00007ac9d05dc30c  mov rax, 0x569AF9F93A50
00007ac9d05dc316  call rax
00007ac9d05dc318  movaps xmm7, [rsp]
00007ac9d05dc31c  add rsp, 0x40
00007ac9d05dc320  vmovaps xmm0, [rsp]
00007ac9d05dc325  vmovaps xmm1, [rsp+0x10]
00007ac9d05dc32b  vmovaps xmm2, [rsp+0x20]
00007ac9d05dc331  vmovaps xmm3, [rsp+0x30]
00007ac9d05dc337  vmovaps xmm4, [rsp+0x40]
00007ac9d05dc33d  vmovaps xmm5, [rsp+0x50]
00007ac9d05dc343  vmovaps xmm6, [rsp+0x60]
00007ac9d05dc349  vmovaps xmm8, [rsp+0x70]
00007ac9d05dc34f  vmovaps xmm9, [rsp+0x80]
00007ac9d05dc358  vmovaps xmm10, [rsp+0x90]
00007ac9d05dc361  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dc36a  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dc373  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dc37c  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dc385  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dc38e  add rsp, 0xF0
00007ac9d05dc395  pop r11
00007ac9d05dc397  pop r10
00007ac9d05dc399  pop r9
00007ac9d05dc39b  pop r8
00007ac9d05dc39d  pop rsi
00007ac9d05dc39e  pop rdi
00007ac9d05dc39f  pop rdx
00007ac9d05dc3a0  pop rcx
00007ac9d05dc3a1  pop rax
00007ac9d05dc3a2  add rsp, 0x08
00007ac9d05dc3a6  jmp 0x00007AC9D05DA421
00007ac9d05dc3ab  sub rsp, 0x08
00007ac9d05dc3af  push rax
00007ac9d05dc3b0  push rcx
00007ac9d05dc3b1  push rdx
00007ac9d05dc3b2  push rdi
00007ac9d05dc3b3  push rsi
00007ac9d05dc3b4  push r8
00007ac9d05dc3b6  push r9
00007ac9d05dc3b8  push r10
00007ac9d05dc3ba  push r11
00007ac9d05dc3bc  sub rsp, 0xF0
00007ac9d05dc3c3  vmovaps [rsp], xmm0
00007ac9d05dc3c8  vmovaps [rsp+0x10], xmm1
00007ac9d05dc3ce  vmovaps [rsp+0x20], xmm2
00007ac9d05dc3d4  vmovaps [rsp+0x30], xmm3
00007ac9d05dc3da  vmovaps [rsp+0x40], xmm4
00007ac9d05dc3e0  vmovaps [rsp+0x50], xmm5
00007ac9d05dc3e6  vmovaps [rsp+0x60], xmm6
00007ac9d05dc3ec  vmovaps [rsp+0x70], xmm7
00007ac9d05dc3f2  vmovaps [rsp+0x80], xmm8
00007ac9d05dc3fb  vmovaps [rsp+0x90], xmm10
00007ac9d05dc404  vmovaps [rsp+0xA0], xmm11
00007ac9d05dc40d  vmovaps [rsp+0xB0], xmm12
00007ac9d05dc416  vmovaps [rsp+0xC0], xmm13
00007ac9d05dc41f  vmovaps [rsp+0xD0], xmm14
00007ac9d05dc428  vmovaps [rsp+0xE0], xmm15
00007ac9d05dc431  sub rsp, 0x40
00007ac9d05dc435  lea rdi, [rsp]
00007ac9d05dc439  lea rsi, [rsp+0x10]
00007ac9d05dc43e  lea rdx, [rsp+0x20]
00007ac9d05dc443  lea rcx, [rsp+0x30]
00007ac9d05dc448  mov r8d, 0x00
00007ac9d05dc44e  lea r9, [r15+0x3A8]
00007ac9d05dc455  movaps [rdi], xmm9
00007ac9d05dc459  movaps [rsi], xmm6
00007ac9d05dc45c  movaps [rdx], xmm1
00007ac9d05dc45f  movaps [rcx], xmm11
00007ac9d05dc463  mov rax, 0x569AF9F93A50
00007ac9d05dc46d  call rax
00007ac9d05dc46f  movaps xmm9, [rsp]
00007ac9d05dc474  add rsp, 0x40
00007ac9d05dc478  vmovaps xmm0, [rsp]
00007ac9d05dc47d  vmovaps xmm1, [rsp+0x10]
00007ac9d05dc483  vmovaps xmm2, [rsp+0x20]
00007ac9d05dc489  vmovaps xmm3, [rsp+0x30]
00007ac9d05dc48f  vmovaps xmm4, [rsp+0x40]
00007ac9d05dc495  vmovaps xmm5, [rsp+0x50]
00007ac9d05dc49b  vmovaps xmm6, [rsp+0x60]
00007ac9d05dc4a1  vmovaps xmm7, [rsp+0x70]
00007ac9d05dc4a7  vmovaps xmm8, [rsp+0x80]
00007ac9d05dc4b0  vmovaps xmm10, [rsp+0x90]
00007ac9d05dc4b9  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dc4c2  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dc4cb  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dc4d4  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dc4dd  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dc4e6  add rsp, 0xF0
00007ac9d05dc4ed  pop r11
00007ac9d05dc4ef  pop r10
00007ac9d05dc4f1  pop r9
00007ac9d05dc4f3  pop r8
00007ac9d05dc4f5  pop rsi
00007ac9d05dc4f6  pop rdi
00007ac9d05dc4f7  pop rdx
00007ac9d05dc4f8  pop rcx
00007ac9d05dc4f9  pop rax
00007ac9d05dc4fa  add rsp, 0x08
00007ac9d05dc4fe  jmp 0x00007AC9D05DA447
00007ac9d05dc503  sub rsp, 0x08
00007ac9d05dc507  push rax
00007ac9d05dc508  push rcx
00007ac9d05dc509  push rdx
00007ac9d05dc50a  push rdi
00007ac9d05dc50b  push rsi
00007ac9d05dc50c  push r8
00007ac9d05dc50e  push r9
00007ac9d05dc510  push r10
00007ac9d05dc512  push r11
00007ac9d05dc514  sub rsp, 0xF0
00007ac9d05dc51b  vmovaps [rsp], xmm0
00007ac9d05dc520  vmovaps [rsp+0x10], xmm1
00007ac9d05dc526  vmovaps [rsp+0x20], xmm2
00007ac9d05dc52c  vmovaps [rsp+0x30], xmm3
00007ac9d05dc532  vmovaps [rsp+0x40], xmm4
00007ac9d05dc538  vmovaps [rsp+0x50], xmm5
00007ac9d05dc53e  vmovaps [rsp+0x60], xmm6
00007ac9d05dc544  vmovaps [rsp+0x70], xmm7
00007ac9d05dc54a  vmovaps [rsp+0x80], xmm8
00007ac9d05dc553  vmovaps [rsp+0x90], xmm9
00007ac9d05dc55c  vmovaps [rsp+0xA0], xmm10
00007ac9d05dc565  vmovaps [rsp+0xB0], xmm12
00007ac9d05dc56e  vmovaps [rsp+0xC0], xmm13
00007ac9d05dc577  vmovaps [rsp+0xD0], xmm14
00007ac9d05dc580  vmovaps [rsp+0xE0], xmm15
00007ac9d05dc589  sub rsp, 0x40
00007ac9d05dc58d  lea rdi, [rsp]
00007ac9d05dc591  lea rsi, [rsp+0x10]
00007ac9d05dc596  lea rdx, [rsp+0x20]
00007ac9d05dc59b  lea rcx, [rsp+0x30]
00007ac9d05dc5a0  mov r8d, 0x00
00007ac9d05dc5a6  lea r9, [r15+0x3A8]
00007ac9d05dc5ad  movaps [rdi], xmm11
00007ac9d05dc5b1  movaps [rsi], xmm10
00007ac9d05dc5b5  movaps [rdx], xmm8
00007ac9d05dc5b9  movaps [rcx], xmm1
00007ac9d05dc5bc  mov rax, 0x569AF9F93A50
00007ac9d05dc5c6  call rax
00007ac9d05dc5c8  movaps xmm11, [rsp]
00007ac9d05dc5cd  add rsp, 0x40
00007ac9d05dc5d1  vmovaps xmm0, [rsp]
00007ac9d05dc5d6  vmovaps xmm1, [rsp+0x10]
00007ac9d05dc5dc  vmovaps xmm2, [rsp+0x20]
00007ac9d05dc5e2  vmovaps xmm3, [rsp+0x30]
00007ac9d05dc5e8  vmovaps xmm4, [rsp+0x40]
00007ac9d05dc5ee  vmovaps xmm5, [rsp+0x50]
00007ac9d05dc5f4  vmovaps xmm6, [rsp+0x60]
00007ac9d05dc5fa  vmovaps xmm7, [rsp+0x70]
00007ac9d05dc600  vmovaps xmm8, [rsp+0x80]
00007ac9d05dc609  vmovaps xmm9, [rsp+0x90]
00007ac9d05dc612  vmovaps xmm10, [rsp+0xA0]
00007ac9d05dc61b  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dc624  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dc62d  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dc636  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dc63f  add rsp, 0xF0
00007ac9d05dc646  pop r11
00007ac9d05dc648  pop r10
00007ac9d05dc64a  pop r9
00007ac9d05dc64c  pop r8
00007ac9d05dc64e  pop rsi
00007ac9d05dc64f  pop rdi
00007ac9d05dc650  pop rdx
00007ac9d05dc651  pop rcx
00007ac9d05dc652  pop rax
00007ac9d05dc653  add rsp, 0x08
00007ac9d05dc657  jmp 0x00007AC9D05DA46D
00007ac9d05dc65c  sub rsp, 0x08
00007ac9d05dc660  push rax
00007ac9d05dc661  push rcx
00007ac9d05dc662  push rdx
00007ac9d05dc663  push rdi
00007ac9d05dc664  push rsi
00007ac9d05dc665  push r8
00007ac9d05dc667  push r9
00007ac9d05dc669  push r10
00007ac9d05dc66b  push r11
00007ac9d05dc66d  sub rsp, 0xF0
00007ac9d05dc674  vmovaps [rsp], xmm0
00007ac9d05dc679  vmovaps [rsp+0x10], xmm1
00007ac9d05dc67f  vmovaps [rsp+0x20], xmm2
00007ac9d05dc685  vmovaps [rsp+0x30], xmm3
00007ac9d05dc68b  vmovaps [rsp+0x40], xmm4
00007ac9d05dc691  vmovaps [rsp+0x50], xmm5
00007ac9d05dc697  vmovaps [rsp+0x60], xmm6
00007ac9d05dc69d  vmovaps [rsp+0x70], xmm7
00007ac9d05dc6a3  vmovaps [rsp+0x80], xmm8
00007ac9d05dc6ac  vmovaps [rsp+0x90], xmm9
00007ac9d05dc6b5  vmovaps [rsp+0xA0], xmm11
00007ac9d05dc6be  vmovaps [rsp+0xB0], xmm12
00007ac9d05dc6c7  vmovaps [rsp+0xC0], xmm13
00007ac9d05dc6d0  vmovaps [rsp+0xD0], xmm14
00007ac9d05dc6d9  vmovaps [rsp+0xE0], xmm15
00007ac9d05dc6e2  sub rsp, 0x40
00007ac9d05dc6e6  lea rdi, [rsp]
00007ac9d05dc6ea  lea rsi, [rsp+0x10]
00007ac9d05dc6ef  lea rdx, [rsp+0x20]
00007ac9d05dc6f4  lea rcx, [rsp+0x30]
00007ac9d05dc6f9  mov r8d, 0x00
00007ac9d05dc6ff  lea r9, [r15+0x3A8]
00007ac9d05dc706  movaps [rdi], xmm10
00007ac9d05dc70a  movaps [rsi], xmm12
00007ac9d05dc70e  movaps [rdx], xmm13
00007ac9d05dc712  movaps [rcx], xmm1
00007ac9d05dc715  mov rax, 0x569AF9F93A50
00007ac9d05dc71f  call rax
00007ac9d05dc721  movaps xmm10, [rsp]
00007ac9d05dc726  add rsp, 0x40
00007ac9d05dc72a  vmovaps xmm0, [rsp]
00007ac9d05dc72f  vmovaps xmm1, [rsp+0x10]
00007ac9d05dc735  vmovaps xmm2, [rsp+0x20]
00007ac9d05dc73b  vmovaps xmm3, [rsp+0x30]
00007ac9d05dc741  vmovaps xmm4, [rsp+0x40]
00007ac9d05dc747  vmovaps xmm5, [rsp+0x50]
00007ac9d05dc74d  vmovaps xmm6, [rsp+0x60]
00007ac9d05dc753  vmovaps xmm7, [rsp+0x70]
00007ac9d05dc759  vmovaps xmm8, [rsp+0x80]
00007ac9d05dc762  vmovaps xmm9, [rsp+0x90]
00007ac9d05dc76b  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dc774  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dc77d  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dc786  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dc78f  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dc798  add rsp, 0xF0
00007ac9d05dc79f  pop r11
00007ac9d05dc7a1  pop r10
00007ac9d05dc7a3  pop r9
00007ac9d05dc7a5  pop r8
00007ac9d05dc7a7  pop rsi
00007ac9d05dc7a8  pop rdi
00007ac9d05dc7a9  pop rdx
00007ac9d05dc7aa  pop rcx
00007ac9d05dc7ab  pop rax
00007ac9d05dc7ac  add rsp, 0x08
00007ac9d05dc7b0  jmp 0x00007AC9D05DA493
00007ac9d05dc7b5  call 0x00007AC9D03FF430
00007ac9d05dc7ba  jmp 0x00007AC9D05DA49D
00007ac9d05dc7bf  call 0x00007AC9D040C260
00007ac9d05dc7c4  jmp 0x00007AC9D05DA4A7
00007ac9d05dc7c9  sub rsp, 0x08
00007ac9d05dc7cd  push rax
00007ac9d05dc7ce  push rcx
00007ac9d05dc7cf  push rdx
00007ac9d05dc7d0  push rdi
00007ac9d05dc7d1  push rsi
00007ac9d05dc7d2  push r8
00007ac9d05dc7d4  push r9
00007ac9d05dc7d6  push r10
00007ac9d05dc7d8  push r11
00007ac9d05dc7da  sub rsp, 0xF0
00007ac9d05dc7e1  vmovaps [rsp], xmm0
00007ac9d05dc7e6  vmovaps [rsp+0x10], xmm1
00007ac9d05dc7ec  vmovaps [rsp+0x20], xmm2
00007ac9d05dc7f2  vmovaps [rsp+0x30], xmm3
00007ac9d05dc7f8  vmovaps [rsp+0x40], xmm4
00007ac9d05dc7fe  vmovaps [rsp+0x50], xmm5
00007ac9d05dc804  vmovaps [rsp+0x60], xmm6
00007ac9d05dc80a  vmovaps [rsp+0x70], xmm7
00007ac9d05dc810  vmovaps [rsp+0x80], xmm9
00007ac9d05dc819  vmovaps [rsp+0x90], xmm10
00007ac9d05dc822  vmovaps [rsp+0xA0], xmm11
00007ac9d05dc82b  vmovaps [rsp+0xB0], xmm12
00007ac9d05dc834  vmovaps [rsp+0xC0], xmm13
00007ac9d05dc83d  vmovaps [rsp+0xD0], xmm14
00007ac9d05dc846  vmovaps [rsp+0xE0], xmm15
00007ac9d05dc84f  sub rsp, 0x40
00007ac9d05dc853  lea rdi, [rsp]
00007ac9d05dc857  lea rsi, [rsp+0x10]
00007ac9d05dc85c  lea rdx, [rsp+0x20]
00007ac9d05dc861  lea rcx, [rsp+0x30]
00007ac9d05dc866  mov r8d, 0x00
00007ac9d05dc86c  lea r9, [r15+0x3A8]
00007ac9d05dc873  movaps [rdi], xmm8
00007ac9d05dc877  movaps [rsi], xmm7
00007ac9d05dc87a  movaps [rdx], xmm4
00007ac9d05dc87d  movaps [rcx], xmm12
00007ac9d05dc881  mov rax, 0x569AF9F93A50
00007ac9d05dc88b  call rax
00007ac9d05dc88d  movaps xmm8, [rsp]
00007ac9d05dc892  add rsp, 0x40
00007ac9d05dc896  vmovaps xmm0, [rsp]
00007ac9d05dc89b  vmovaps xmm1, [rsp+0x10]
00007ac9d05dc8a1  vmovaps xmm2, [rsp+0x20]
00007ac9d05dc8a7  vmovaps xmm3, [rsp+0x30]
00007ac9d05dc8ad  vmovaps xmm4, [rsp+0x40]
00007ac9d05dc8b3  vmovaps xmm5, [rsp+0x50]
00007ac9d05dc8b9  vmovaps xmm6, [rsp+0x60]
00007ac9d05dc8bf  vmovaps xmm7, [rsp+0x70]
00007ac9d05dc8c5  vmovaps xmm9, [rsp+0x80]
00007ac9d05dc8ce  vmovaps xmm10, [rsp+0x90]
00007ac9d05dc8d7  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dc8e0  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dc8e9  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dc8f2  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dc8fb  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dc904  add rsp, 0xF0
00007ac9d05dc90b  pop r11
00007ac9d05dc90d  pop r10
00007ac9d05dc90f  pop r9
00007ac9d05dc911  pop r8
00007ac9d05dc913  pop rsi
00007ac9d05dc914  pop rdi
00007ac9d05dc915  pop rdx
00007ac9d05dc916  pop rcx
00007ac9d05dc917  pop rax
00007ac9d05dc918  add rsp, 0x08
00007ac9d05dc91c  jmp 0x00007AC9D05DA4D0
00007ac9d05dc921  sub rsp, 0x08
00007ac9d05dc925  push rax
00007ac9d05dc926  push rcx
00007ac9d05dc927  push rdx
00007ac9d05dc928  push rdi
00007ac9d05dc929  push rsi
00007ac9d05dc92a  push r8
00007ac9d05dc92c  push r9
00007ac9d05dc92e  push r10
00007ac9d05dc930  push r11
00007ac9d05dc932  sub rsp, 0xF0
00007ac9d05dc939  vmovaps [rsp], xmm0
00007ac9d05dc93e  vmovaps [rsp+0x10], xmm1
00007ac9d05dc944  vmovaps [rsp+0x20], xmm2
00007ac9d05dc94a  vmovaps [rsp+0x30], xmm3
00007ac9d05dc950  vmovaps [rsp+0x40], xmm4
00007ac9d05dc956  vmovaps [rsp+0x50], xmm5
00007ac9d05dc95c  vmovaps [rsp+0x60], xmm6
00007ac9d05dc962  vmovaps [rsp+0x70], xmm8
00007ac9d05dc968  vmovaps [rsp+0x80], xmm9
00007ac9d05dc971  vmovaps [rsp+0x90], xmm10
00007ac9d05dc97a  vmovaps [rsp+0xA0], xmm11
00007ac9d05dc983  vmovaps [rsp+0xB0], xmm12
00007ac9d05dc98c  vmovaps [rsp+0xC0], xmm13
00007ac9d05dc995  vmovaps [rsp+0xD0], xmm14
00007ac9d05dc99e  vmovaps [rsp+0xE0], xmm15
00007ac9d05dc9a7  sub rsp, 0x40
00007ac9d05dc9ab  lea rdi, [rsp]
00007ac9d05dc9af  lea rsi, [rsp+0x10]
00007ac9d05dc9b4  lea rdx, [rsp+0x20]
00007ac9d05dc9b9  lea rcx, [rsp+0x30]
00007ac9d05dc9be  mov r8d, 0x00
00007ac9d05dc9c4  lea r9, [r15+0x3A8]
00007ac9d05dc9cb  movaps [rdi], xmm7
00007ac9d05dc9ce  movaps [rsi], xmm9
00007ac9d05dc9d2  movaps [rdx], xmm14
00007ac9d05dc9d6  movaps [rcx], xmm12
00007ac9d05dc9da  mov rax, 0x569AF9F93A50
00007ac9d05dc9e4  call rax
00007ac9d05dc9e6  movaps xmm7, [rsp]
00007ac9d05dc9ea  add rsp, 0x40
00007ac9d05dc9ee  vmovaps xmm0, [rsp]
00007ac9d05dc9f3  vmovaps xmm1, [rsp+0x10]
00007ac9d05dc9f9  vmovaps xmm2, [rsp+0x20]
00007ac9d05dc9ff  vmovaps xmm3, [rsp+0x30]
00007ac9d05dca05  vmovaps xmm4, [rsp+0x40]
00007ac9d05dca0b  vmovaps xmm5, [rsp+0x50]
00007ac9d05dca11  vmovaps xmm6, [rsp+0x60]
00007ac9d05dca17  vmovaps xmm8, [rsp+0x70]
00007ac9d05dca1d  vmovaps xmm9, [rsp+0x80]
00007ac9d05dca26  vmovaps xmm10, [rsp+0x90]
00007ac9d05dca2f  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dca38  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dca41  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dca4a  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dca53  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dca5c  add rsp, 0xF0
00007ac9d05dca63  pop r11
00007ac9d05dca65  pop r10
00007ac9d05dca67  pop r9
00007ac9d05dca69  pop r8
00007ac9d05dca6b  pop rsi
00007ac9d05dca6c  pop rdi
00007ac9d05dca6d  pop rdx
00007ac9d05dca6e  pop rcx
00007ac9d05dca6f  pop rax
00007ac9d05dca70  add rsp, 0x08
00007ac9d05dca74  jmp 0x00007AC9D05DA4F8
00007ac9d05dca79  sub rsp, 0x08
00007ac9d05dca7d  push rax
00007ac9d05dca7e  push rcx
00007ac9d05dca7f  push rdx
00007ac9d05dca80  push rdi
00007ac9d05dca81  push rsi
00007ac9d05dca82  push r8
00007ac9d05dca84  push r9
00007ac9d05dca86  push r10
00007ac9d05dca88  push r11
00007ac9d05dca8a  sub rsp, 0xF0
00007ac9d05dca91  vmovaps [rsp], xmm0
00007ac9d05dca96  vmovaps [rsp+0x10], xmm1
00007ac9d05dca9c  vmovaps [rsp+0x20], xmm2
00007ac9d05dcaa2  vmovaps [rsp+0x30], xmm3
00007ac9d05dcaa8  vmovaps [rsp+0x40], xmm4
00007ac9d05dcaae  vmovaps [rsp+0x50], xmm5
00007ac9d05dcab4  vmovaps [rsp+0x60], xmm6
00007ac9d05dcaba  vmovaps [rsp+0x70], xmm7
00007ac9d05dcac0  vmovaps [rsp+0x80], xmm8
00007ac9d05dcac9  vmovaps [rsp+0x90], xmm9
00007ac9d05dcad2  vmovaps [rsp+0xA0], xmm10
00007ac9d05dcadb  vmovaps [rsp+0xB0], xmm11
00007ac9d05dcae4  vmovaps [rsp+0xC0], xmm13
00007ac9d05dcaed  vmovaps [rsp+0xD0], xmm14
00007ac9d05dcaf6  vmovaps [rsp+0xE0], xmm15
00007ac9d05dcaff  sub rsp, 0x40
00007ac9d05dcb03  lea rdi, [rsp]
00007ac9d05dcb07  lea rsi, [rsp+0x10]
00007ac9d05dcb0c  lea rdx, [rsp+0x20]
00007ac9d05dcb11  lea rcx, [rsp+0x30]
00007ac9d05dcb16  mov r8d, 0x00
00007ac9d05dcb1c  lea r9, [r15+0x3A8]
00007ac9d05dcb23  movaps [rdi], xmm12
00007ac9d05dcb27  movaps [rsi], xmm11
00007ac9d05dcb2b  movaps [rdx], xmm15
00007ac9d05dcb2f  movaps [rcx], xmm14
00007ac9d05dcb33  mov rax, 0x569AF9F93A50
00007ac9d05dcb3d  call rax
00007ac9d05dcb3f  movaps xmm12, [rsp]
00007ac9d05dcb44  add rsp, 0x40
00007ac9d05dcb48  vmovaps xmm0, [rsp]
00007ac9d05dcb4d  vmovaps xmm1, [rsp+0x10]
00007ac9d05dcb53  vmovaps xmm2, [rsp+0x20]
00007ac9d05dcb59  vmovaps xmm3, [rsp+0x30]
00007ac9d05dcb5f  vmovaps xmm4, [rsp+0x40]
00007ac9d05dcb65  vmovaps xmm5, [rsp+0x50]
00007ac9d05dcb6b  vmovaps xmm6, [rsp+0x60]
00007ac9d05dcb71  vmovaps xmm7, [rsp+0x70]
00007ac9d05dcb77  vmovaps xmm8, [rsp+0x80]
00007ac9d05dcb80  vmovaps xmm9, [rsp+0x90]
00007ac9d05dcb89  vmovaps xmm10, [rsp+0xA0]
00007ac9d05dcb92  vmovaps xmm11, [rsp+0xB0]
00007ac9d05dcb9b  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dcba4  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dcbad  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dcbb6  add rsp, 0xF0
00007ac9d05dcbbd  pop r11
00007ac9d05dcbbf  pop r10
00007ac9d05dcbc1  pop r9
00007ac9d05dcbc3  pop r8
00007ac9d05dcbc5  pop rsi
00007ac9d05dcbc6  pop rdi
00007ac9d05dcbc7  pop rdx
00007ac9d05dcbc8  pop rcx
00007ac9d05dcbc9  pop rax
00007ac9d05dcbca  add rsp, 0x08
00007ac9d05dcbce  jmp 0x00007AC9D05DA521
00007ac9d05dcbd3  sub rsp, 0x08
00007ac9d05dcbd7  push rax
00007ac9d05dcbd8  push rcx
00007ac9d05dcbd9  push rdx
00007ac9d05dcbda  push rdi
00007ac9d05dcbdb  push rsi
00007ac9d05dcbdc  push r8
00007ac9d05dcbde  push r9
00007ac9d05dcbe0  push r10
00007ac9d05dcbe2  push r11
00007ac9d05dcbe4  sub rsp, 0xF0
00007ac9d05dcbeb  vmovaps [rsp], xmm0
00007ac9d05dcbf0  vmovaps [rsp+0x10], xmm1
00007ac9d05dcbf6  vmovaps [rsp+0x20], xmm2
00007ac9d05dcbfc  vmovaps [rsp+0x30], xmm3
00007ac9d05dcc02  vmovaps [rsp+0x40], xmm4
00007ac9d05dcc08  vmovaps [rsp+0x50], xmm5
00007ac9d05dcc0e  vmovaps [rsp+0x60], xmm6
00007ac9d05dcc14  vmovaps [rsp+0x70], xmm7
00007ac9d05dcc1a  vmovaps [rsp+0x80], xmm8
00007ac9d05dcc23  vmovaps [rsp+0x90], xmm9
00007ac9d05dcc2c  vmovaps [rsp+0xA0], xmm10
00007ac9d05dcc35  vmovaps [rsp+0xB0], xmm12
00007ac9d05dcc3e  vmovaps [rsp+0xC0], xmm13
00007ac9d05dcc47  vmovaps [rsp+0xD0], xmm14
00007ac9d05dcc50  vmovaps [rsp+0xE0], xmm15
00007ac9d05dcc59  sub rsp, 0x40
00007ac9d05dcc5d  lea rdi, [rsp]
00007ac9d05dcc61  lea rsi, [rsp+0x10]
00007ac9d05dcc66  lea rdx, [rsp+0x20]
00007ac9d05dcc6b  lea rcx, [rsp+0x30]
00007ac9d05dcc70  mov r8d, 0x00
00007ac9d05dcc76  lea r9, [r15+0x3A8]
00007ac9d05dcc7d  movaps [rdi], xmm11
00007ac9d05dcc81  movaps [rsi], xmm10
00007ac9d05dcc85  movaps [rdx], xmm13
00007ac9d05dcc89  movaps [rcx], xmm15
00007ac9d05dcc8d  mov rax, 0x569AF9F93A50
00007ac9d05dcc97  call rax
00007ac9d05dcc99  movaps xmm11, [rsp]
00007ac9d05dcc9e  add rsp, 0x40
00007ac9d05dcca2  vmovaps xmm0, [rsp]
00007ac9d05dcca7  vmovaps xmm1, [rsp+0x10]
00007ac9d05dccad  vmovaps xmm2, [rsp+0x20]
00007ac9d05dccb3  vmovaps xmm3, [rsp+0x30]
00007ac9d05dccb9  vmovaps xmm4, [rsp+0x40]
00007ac9d05dccbf  vmovaps xmm5, [rsp+0x50]
00007ac9d05dccc5  vmovaps xmm6, [rsp+0x60]
00007ac9d05dcccb  vmovaps xmm7, [rsp+0x70]
00007ac9d05dccd1  vmovaps xmm8, [rsp+0x80]
00007ac9d05dccda  vmovaps xmm9, [rsp+0x90]
00007ac9d05dcce3  vmovaps xmm10, [rsp+0xA0]
00007ac9d05dccec  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dccf5  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dccfe  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dcd07  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dcd10  add rsp, 0xF0
00007ac9d05dcd17  pop r11
00007ac9d05dcd19  pop r10
00007ac9d05dcd1b  pop r9
00007ac9d05dcd1d  pop r8
00007ac9d05dcd1f  pop rsi
00007ac9d05dcd20  pop rdi
00007ac9d05dcd21  pop rdx
00007ac9d05dcd22  pop rcx
00007ac9d05dcd23  pop rax
00007ac9d05dcd24  add rsp, 0x08
00007ac9d05dcd28  jmp 0x00007AC9D05DA54A
00007ac9d05dcd2d  call 0x00007AC9D040E760
00007ac9d05dcd32  jmp 0x00007AC9D05DA557
00007ac9d05dcd37  call 0x00007AC9D040D4E0
00007ac9d05dcd3c  jmp 0x00007AC9D05DA564
00007ac9d05dcd41  sub rsp, 0x08
00007ac9d05dcd45  push rax
00007ac9d05dcd46  push rcx
00007ac9d05dcd47  push rdx
00007ac9d05dcd48  push rdi
00007ac9d05dcd49  push rsi
00007ac9d05dcd4a  push r8
00007ac9d05dcd4c  push r9
00007ac9d05dcd4e  push r10
00007ac9d05dcd50  push r11
00007ac9d05dcd52  sub rsp, 0xF0
00007ac9d05dcd59  vmovaps [rsp], xmm0
00007ac9d05dcd5e  vmovaps [rsp+0x10], xmm1
00007ac9d05dcd64  vmovaps [rsp+0x20], xmm2
00007ac9d05dcd6a  vmovaps [rsp+0x30], xmm3
00007ac9d05dcd70  vmovaps [rsp+0x40], xmm4
00007ac9d05dcd76  vmovaps [rsp+0x50], xmm5
00007ac9d05dcd7c  vmovaps [rsp+0x60], xmm6
00007ac9d05dcd82  vmovaps [rsp+0x70], xmm7
00007ac9d05dcd88  vmovaps [rsp+0x80], xmm8
00007ac9d05dcd91  vmovaps [rsp+0x90], xmm9
00007ac9d05dcd9a  vmovaps [rsp+0xA0], xmm11
00007ac9d05dcda3  vmovaps [rsp+0xB0], xmm12
00007ac9d05dcdac  vmovaps [rsp+0xC0], xmm13
00007ac9d05dcdb5  vmovaps [rsp+0xD0], xmm14
00007ac9d05dcdbe  vmovaps [rsp+0xE0], xmm15
00007ac9d05dcdc7  sub rsp, 0x40
00007ac9d05dcdcb  lea rdi, [rsp]
00007ac9d05dcdcf  lea rsi, [rsp+0x10]
00007ac9d05dcdd4  lea rdx, [rsp+0x20]
00007ac9d05dcdd9  lea rcx, [rsp+0x30]
00007ac9d05dcdde  mov r8d, 0x00
00007ac9d05dcde4  lea r9, [r15+0x3A8]
00007ac9d05dcdeb  movaps [rdi], xmm10
00007ac9d05dcdef  movaps [rsi], xmm8
00007ac9d05dcdf3  movaps [rdx], xmm1
00007ac9d05dcdf6  movaps [rcx], xmm13
00007ac9d05dcdfa  mov rax, 0x569AF9F93A50
00007ac9d05dce04  call rax
00007ac9d05dce06  movaps xmm10, [rsp]
00007ac9d05dce0b  add rsp, 0x40
00007ac9d05dce0f  vmovaps xmm0, [rsp]
00007ac9d05dce14  vmovaps xmm1, [rsp+0x10]
00007ac9d05dce1a  vmovaps xmm2, [rsp+0x20]
00007ac9d05dce20  vmovaps xmm3, [rsp+0x30]
00007ac9d05dce26  vmovaps xmm4, [rsp+0x40]
00007ac9d05dce2c  vmovaps xmm5, [rsp+0x50]
00007ac9d05dce32  vmovaps xmm6, [rsp+0x60]
00007ac9d05dce38  vmovaps xmm7, [rsp+0x70]
00007ac9d05dce3e  vmovaps xmm8, [rsp+0x80]
00007ac9d05dce47  vmovaps xmm9, [rsp+0x90]
00007ac9d05dce50  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dce59  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dce62  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dce6b  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dce74  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dce7d  add rsp, 0xF0
00007ac9d05dce84  pop r11
00007ac9d05dce86  pop r10
00007ac9d05dce88  pop r9
00007ac9d05dce8a  pop r8
00007ac9d05dce8c  pop rsi
00007ac9d05dce8d  pop rdi
00007ac9d05dce8e  pop rdx
00007ac9d05dce8f  pop rcx
00007ac9d05dce90  pop rax
00007ac9d05dce91  add rsp, 0x08
00007ac9d05dce95  jmp 0x00007AC9D05DA59A
00007ac9d05dce9a  call 0x00007AC9D03FF430
00007ac9d05dce9f  jmp 0x00007AC9D05DA5AC
00007ac9d05dcea4  sub rsp, 0x08
00007ac9d05dcea8  push rax
00007ac9d05dcea9  push rcx
00007ac9d05dceaa  push rdx
00007ac9d05dceab  push rdi
00007ac9d05dceac  push rsi
00007ac9d05dcead  push r8
00007ac9d05dceaf  push r9
00007ac9d05dceb1  push r10
00007ac9d05dceb3  push r11
00007ac9d05dceb5  sub rsp, 0xF0
00007ac9d05dcebc  vmovaps [rsp], xmm0
00007ac9d05dcec1  vmovaps [rsp+0x10], xmm1
00007ac9d05dcec7  vmovaps [rsp+0x20], xmm2
00007ac9d05dcecd  vmovaps [rsp+0x30], xmm3
00007ac9d05dced3  vmovaps [rsp+0x40], xmm4
00007ac9d05dced9  vmovaps [rsp+0x50], xmm5
00007ac9d05dcedf  vmovaps [rsp+0x60], xmm6
00007ac9d05dcee5  vmovaps [rsp+0x70], xmm7
00007ac9d05dceeb  vmovaps [rsp+0x80], xmm8
00007ac9d05dcef4  vmovaps [rsp+0x90], xmm10
00007ac9d05dcefd  vmovaps [rsp+0xA0], xmm11
00007ac9d05dcf06  vmovaps [rsp+0xB0], xmm12
00007ac9d05dcf0f  vmovaps [rsp+0xC0], xmm13
00007ac9d05dcf18  vmovaps [rsp+0xD0], xmm14
00007ac9d05dcf21  vmovaps [rsp+0xE0], xmm15
00007ac9d05dcf2a  sub rsp, 0x40
00007ac9d05dcf2e  lea rdi, [rsp]
00007ac9d05dcf32  lea rsi, [rsp+0x10]
00007ac9d05dcf37  lea rdx, [rsp+0x20]
00007ac9d05dcf3c  lea rcx, [rsp+0x30]
00007ac9d05dcf41  mov r8d, 0x00
00007ac9d05dcf47  lea r9, [r15+0x3A8]
00007ac9d05dcf4e  movaps [rdi], xmm9
00007ac9d05dcf52  movaps [rsi], xmm7
00007ac9d05dcf55  movaps [rdx], xmm14
00007ac9d05dcf59  movaps [rcx], xmm13
00007ac9d05dcf5d  mov rax, 0x569AF9F93A50
00007ac9d05dcf67  call rax
00007ac9d05dcf69  movaps xmm9, [rsp]
00007ac9d05dcf6e  add rsp, 0x40
00007ac9d05dcf72  vmovaps xmm0, [rsp]
00007ac9d05dcf77  vmovaps xmm1, [rsp+0x10]
00007ac9d05dcf7d  vmovaps xmm2, [rsp+0x20]
00007ac9d05dcf83  vmovaps xmm3, [rsp+0x30]
00007ac9d05dcf89  vmovaps xmm4, [rsp+0x40]
00007ac9d05dcf8f  vmovaps xmm5, [rsp+0x50]
00007ac9d05dcf95  vmovaps xmm6, [rsp+0x60]
00007ac9d05dcf9b  vmovaps xmm7, [rsp+0x70]
00007ac9d05dcfa1  vmovaps xmm8, [rsp+0x80]
00007ac9d05dcfaa  vmovaps xmm10, [rsp+0x90]
00007ac9d05dcfb3  vmovaps xmm11, [rsp+0xA0]
00007ac9d05dcfbc  vmovaps xmm12, [rsp+0xB0]
00007ac9d05dcfc5  vmovaps xmm13, [rsp+0xC0]
00007ac9d05dcfce  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dcfd7  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dcfe0  add rsp, 0xF0
00007ac9d05dcfe7  pop r11
00007ac9d05dcfe9  pop r10
00007ac9d05dcfeb  pop r9
00007ac9d05dcfed  pop r8
00007ac9d05dcfef  pop rsi
00007ac9d05dcff0  pop rdi
00007ac9d05dcff1  pop rdx
00007ac9d05dcff2  pop rcx
00007ac9d05dcff3  pop rax
00007ac9d05dcff4  add rsp, 0x08
00007ac9d05dcff8  jmp 0x00007AC9D05DA5DA
00007ac9d05dcffd  sub rsp, 0x08
00007ac9d05dd001  push rax
00007ac9d05dd002  push rcx
00007ac9d05dd003  push rdx
00007ac9d05dd004  push rdi
00007ac9d05dd005  push rsi
00007ac9d05dd006  push r8
00007ac9d05dd008  push r9
00007ac9d05dd00a  push r10
00007ac9d05dd00c  push r11
00007ac9d05dd00e  sub rsp, 0xF0
00007ac9d05dd015  vmovaps [rsp], xmm0
00007ac9d05dd01a  vmovaps [rsp+0x10], xmm1
00007ac9d05dd020  vmovaps [rsp+0x20], xmm2
00007ac9d05dd026  vmovaps [rsp+0x30], xmm3
00007ac9d05dd02c  vmovaps [rsp+0x40], xmm4
00007ac9d05dd032  vmovaps [rsp+0x50], xmm5
00007ac9d05dd038  vmovaps [rsp+0x60], xmm6
00007ac9d05dd03e  vmovaps [rsp+0x70], xmm7
00007ac9d05dd044  vmovaps [rsp+0x80], xmm8
00007ac9d05dd04d  vmovaps [rsp+0x90], xmm9
00007ac9d05dd056  vmovaps [rsp+0xA0], xmm10
00007ac9d05dd05f  vmovaps [rsp+0xB0], xmm11
00007ac9d05dd068  vmovaps [rsp+0xC0], xmm12
00007ac9d05dd071  vmovaps [rsp+0xD0], xmm14
00007ac9d05dd07a  vmovaps [rsp+0xE0], xmm15
00007ac9d05dd083  sub rsp, 0x40
00007ac9d05dd087  lea rdi, [rsp]
00007ac9d05dd08b  lea rsi, [rsp+0x10]
00007ac9d05dd090  lea rdx, [rsp+0x20]
00007ac9d05dd095  lea rcx, [rsp+0x30]
00007ac9d05dd09a  mov r8d, 0x00
00007ac9d05dd0a0  lea r9, [r15+0x3A8]
00007ac9d05dd0a7  movaps [rdi], xmm13
00007ac9d05dd0ab  movaps [rsi], xmm12
00007ac9d05dd0af  movaps [rdx], xmm15
00007ac9d05dd0b3  movaps [rcx], xmm14
00007ac9d05dd0b7  mov rax, 0x569AF9F93A50
00007ac9d05dd0c1  call rax
00007ac9d05dd0c3  movaps xmm13, [rsp]
00007ac9d05dd0c8  add rsp, 0x40
00007ac9d05dd0cc  vmovaps xmm0, [rsp]
00007ac9d05dd0d1  vmovaps xmm1, [rsp+0x10]
00007ac9d05dd0d7  vmovaps xmm2, [rsp+0x20]
00007ac9d05dd0dd  vmovaps xmm3, [rsp+0x30]
00007ac9d05dd0e3  vmovaps xmm4, [rsp+0x40]
00007ac9d05dd0e9  vmovaps xmm5, [rsp+0x50]
00007ac9d05dd0ef  vmovaps xmm6, [rsp+0x60]
00007ac9d05dd0f5  vmovaps xmm7, [rsp+0x70]
00007ac9d05dd0fb  vmovaps xmm8, [rsp+0x80]
00007ac9d05dd104  vmovaps xmm9, [rsp+0x90]
00007ac9d05dd10d  vmovaps xmm10, [rsp+0xA0]
00007ac9d05dd116  vmovaps xmm11, [rsp+0xB0]
00007ac9d05dd11f  vmovaps xmm12, [rsp+0xC0]
00007ac9d05dd128  vmovaps xmm14, [rsp+0xD0]
00007ac9d05dd131  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dd13a  add rsp, 0xF0
00007ac9d05dd141  pop r11
00007ac9d05dd143  pop r10
00007ac9d05dd145  pop r9
00007ac9d05dd147  pop r8
00007ac9d05dd149  pop rsi
00007ac9d05dd14a  pop rdi
00007ac9d05dd14b  pop rdx
00007ac9d05dd14c  pop rcx
00007ac9d05dd14d  pop rax
00007ac9d05dd14e  add rsp, 0x08
00007ac9d05dd152  jmp 0x00007AC9D05DA608
00007ac9d05dd157  sub rsp, 0x08
00007ac9d05dd15b  push rax
00007ac9d05dd15c  push rcx
00007ac9d05dd15d  push rdx
00007ac9d05dd15e  push rdi
00007ac9d05dd15f  push rsi
00007ac9d05dd160  push r8
00007ac9d05dd162  push r9
00007ac9d05dd164  push r10
00007ac9d05dd166  push r11
00007ac9d05dd168  sub rsp, 0xF0
00007ac9d05dd16f  vmovaps [rsp], xmm0
00007ac9d05dd174  vmovaps [rsp+0x10], xmm1
00007ac9d05dd17a  vmovaps [rsp+0x20], xmm2
00007ac9d05dd180  vmovaps [rsp+0x30], xmm3
00007ac9d05dd186  vmovaps [rsp+0x40], xmm4
00007ac9d05dd18c  vmovaps [rsp+0x50], xmm5
00007ac9d05dd192  vmovaps [rsp+0x60], xmm6
00007ac9d05dd198  vmovaps [rsp+0x70], xmm7
00007ac9d05dd19e  vmovaps [rsp+0x80], xmm8
00007ac9d05dd1a7  vmovaps [rsp+0x90], xmm9
00007ac9d05dd1b0  vmovaps [rsp+0xA0], xmm10
00007ac9d05dd1b9  vmovaps [rsp+0xB0], xmm11
00007ac9d05dd1c2  vmovaps [rsp+0xC0], xmm12
00007ac9d05dd1cb  vmovaps [rsp+0xD0], xmm13
00007ac9d05dd1d4  vmovaps [rsp+0xE0], xmm15
00007ac9d05dd1dd  sub rsp, 0x40
00007ac9d05dd1e1  lea rdi, [rsp]
00007ac9d05dd1e5  lea rsi, [rsp+0x10]
00007ac9d05dd1ea  lea rdx, [rsp+0x20]
00007ac9d05dd1ef  lea rcx, [rsp+0x30]
00007ac9d05dd1f4  mov r8d, 0x00
00007ac9d05dd1fa  lea r9, [r15+0x3A8]
00007ac9d05dd201  movaps [rdi], xmm14
00007ac9d05dd205  movaps [rsi], xmm11
00007ac9d05dd209  movaps [rdx], xmm1
00007ac9d05dd20c  movaps [rcx], xmm15
00007ac9d05dd210  mov rax, 0x569AF9F93A50
00007ac9d05dd21a  call rax
00007ac9d05dd21c  movaps xmm14, [rsp]
00007ac9d05dd221  add rsp, 0x40
00007ac9d05dd225  vmovaps xmm0, [rsp]
00007ac9d05dd22a  vmovaps xmm1, [rsp+0x10]
00007ac9d05dd230  vmovaps xmm2, [rsp+0x20]
00007ac9d05dd236  vmovaps xmm3, [rsp+0x30]
00007ac9d05dd23c  vmovaps xmm4, [rsp+0x40]
00007ac9d05dd242  vmovaps xmm5, [rsp+0x50]
00007ac9d05dd248  vmovaps xmm6, [rsp+0x60]
00007ac9d05dd24e  vmovaps xmm7, [rsp+0x70]
00007ac9d05dd254  vmovaps xmm8, [rsp+0x80]
00007ac9d05dd25d  vmovaps xmm9, [rsp+0x90]
00007ac9d05dd266  vmovaps xmm10, [rsp+0xA0]
00007ac9d05dd26f  vmovaps xmm11, [rsp+0xB0]
00007ac9d05dd278  vmovaps xmm12, [rsp+0xC0]
00007ac9d05dd281  vmovaps xmm13, [rsp+0xD0]
00007ac9d05dd28a  vmovaps xmm15, [rsp+0xE0]
00007ac9d05dd293  add rsp, 0xF0
00007ac9d05dd29a  pop r11
00007ac9d05dd29c  pop r10
00007ac9d05dd29e  pop r9
00007ac9d05dd2a0  pop r8
00007ac9d05dd2a2  pop rsi
00007ac9d05dd2a3  pop rdi
00007ac9d05dd2a4  pop rdx
00007ac9d05dd2a5  pop rcx
00007ac9d05dd2a6  pop rax
00007ac9d05dd2a7  add rsp, 0x08
00007ac9d05dd2ab  jmp 0x00007AC9D05DA636
00007ac9d05dd2b0  call 0x00007AC9D04079B0
00007ac9d05dd2b5  jmp 0x00007AC9D05DA64C
00007ac9d05dd2ba  call 0x00007AC9D04E3440
00007ac9d05dd2bf  jmp 0x00007AC9D05DA656
00007ac9d05dd2c4  call 0x00007AC9D04DFCE0
00007ac9d05dd2c9  jmp 0x00007AC9D05DA660
00007ac9d05dd2ce  call 0x00007AC9D04E46C0
00007ac9d05dd2d3  jmp 0x00007AC9D05DA66A
00007ac9d05dd2d8  int3
00007ac9d05dd2d9  nop [rax], eax
00007ac9d05dd2e0  mov qword ptr [r15+0x40], 0x430000
00007ac9d05dd2e8  mov eax, 0x430C50
00007ac9d05dd2ed  mov r14, [r13+rax*1]
00007ac9d05dd2f2  movq xmm1, r14
00007ac9d05dd2f7  mov rax, [r15+0x50]
00007ac9d05dd2fb  movups xmm15, [r13+rax*1]
00007ac9d05dd301  movaps [r15+0x120], xmm15
00007ac9d05dd309  mov qword ptr [r15+0x48], 0x10
00007ac9d05dd311  xor eax, eax
00007ac9d05dd313  mov r14d, 0x10
00007ac9d05dd319  mov r12d, 0x200
00007ac9d05dd31f  cmp r14, r12
00007ac9d05dd322  cmc
00007ac9d05dd323  lahf
00007ac9d05dd324  seto al
00007ac9d05dd327  mov [r15+0x108], eax
00007ac9d05dd32e  pextrq rax, xmm15, 0x01
00007ac9d05dd335  movq xmm14, rax
00007ac9d05dd33a  movaps [r15+0x130], xmm14
00007ac9d05dd342  movq rax, xmm1
00007ac9d05dd347  movq r14, xmm15
00007ac9d05dd34c  vmovq xmm1, rax
00007ac9d05dd351  vmovq xmm15, r14
00007ac9d05dd356  movaps xmm13, xmm1
00007ac9d05dd35a  addsd xmm13, xmm15
00007ac9d05dd35f  ucomisd xmm13, xmm13
00007ac9d05dd364  jp 0x00007AC9D05DD423
00007ac9d05dd36a  movq xmm13, xmm13
00007ac9d05dd36f  movq rax, xmm13
00007ac9d05dd374  movq r14, xmm14
00007ac9d05dd379  vmovq xmm1, rax
00007ac9d05dd37e  vmovq xmm15, r14
00007ac9d05dd383  movaps xmm14, xmm1
00007ac9d05dd387  addsd xmm14, xmm15
00007ac9d05dd38c  ucomisd xmm14, xmm14
00007ac9d05dd391  jp 0x00007AC9D05DD46B
00007ac9d05dd397  movq xmm14, xmm14
00007ac9d05dd39c  movaps [r15+0x110], xmm14
00007ac9d05dd3a4  mov eax, [r15+0x108]
00007ac9d05dd3ab  sahf
00007ac9d05dd3ac  jnz 0x00007AC9D05DD3DE
00007ac9d05dd3ae  cmp dword ptr [r15+0x318], 0x00
00007ac9d05dd3b6  jz 0x00007AC9D05DD680
00007ac9d05dd3bc  nop [rax+rax*1], ax
00007ac9d05dd3c5  nop [rax+rax*1], eax
00007ac9d05dd3cd  mov eax, 0x410698
00007ac9d05dd3d2  mov [r15+0x100], rax
00007ac9d05dd3d9  jmp 0x00007AC9D03FE110
00007ac9d05dd3de  cmp dword ptr [r15+0x318], 0x00
00007ac9d05dd3e6  jz 0x00007AC9D05DD4C0
00007ac9d05dd3ec  nop [rax+rax*1], ax
00007ac9d05dd3f5  nop [rax+rax*1], eax
00007ac9d05dd3fd  mov eax, 0x41067C
00007ac9d05dd402  mov [r15+0x100], rax
00007ac9d05dd409  jmp 0x00007AC9D03FE110
00007ac9d05dd40e  int3
00007ac9d05dd40f  call 0x00007AC9D040DC20
00007ac9d05dd414  jmp 0x00007AC9D05DD2F2
00007ac9d05dd419  call 0x00007AC9D040E760
00007ac9d05dd41e  jmp 0x00007AC9D05DD301
00007ac9d05dd423  ucomisd xmm1, xmm15
00007ac9d05dd428  jp 0x00007AC9D05DD437
00007ac9d05dd42a  movaps xmm13, [0x00007AC9D01FE060]
00007ac9d05dd432  jmp 0x00007AC9D05DD36A
00007ac9d05dd437  vxorps xmm0, xmm1, xmm15
00007ac9d05dd43c  pextrw eax, xmm0, 0x03
00007ac9d05dd441  and eax, 0x7FF8
00007ac9d05dd446  cmp eax, 0x08
00007ac9d05dd449  jnz 0x00007AC9D05DD36A
00007ac9d05dd44f  movq rax, xmm15
00007ac9d05dd454  shl rax, 0x0D
00007ac9d05dd458  jbe 0x00007AC9D05DD36A
00007ac9d05dd45e  vorps xmm13, xmm15, [0x00007AC9D01FE070]
00007ac9d05dd466  jmp 0x00007AC9D05DD36A
00007ac9d05dd46b  ucomisd xmm1, xmm15
00007ac9d05dd470  jp 0x00007AC9D05DD47F
00007ac9d05dd472  movaps xmm14, [0x00007AC9D01FE060]
00007ac9d05dd47a  jmp 0x00007AC9D05DD397
00007ac9d05dd47f  vxorps xmm0, xmm1, xmm15
00007ac9d05dd484  pextrw eax, xmm0, 0x03
00007ac9d05dd489  and eax, 0x7FF8
00007ac9d05dd48e  cmp eax, 0x08
00007ac9d05dd491  jnz 0x00007AC9D05DD397
00007ac9d05dd497  movq rax, xmm15
00007ac9d05dd49c  shl rax, 0x0D
00007ac9d05dd4a0  jbe 0x00007AC9D05DD397
00007ac9d05dd4a6  vorps xmm14, xmm15, [0x00007AC9D01FE070]
00007ac9d05dd4ae  jmp 0x00007AC9D05DD397
00007ac9d05dd4b3  int3
00007ac9d05dd4b4  nop [rax+rax*1], ax
00007ac9d05dd4bd  nop [rax], eax
00007ac9d05dd4c0  mov rax, [r15+0x48]
00007ac9d05dd4c4  mov r14, [r15+0x50]
00007ac9d05dd4c8  lea r12, [r14+rax*1]
00007ac9d05dd4cc  movups xmm1, [r13+r12*1]
00007ac9d05dd4d2  movaps [r15+0x120], xmm1
00007ac9d05dd4da  lea r14, [rax+0x10]
00007ac9d05dd4de  mov [r15+0x48], r14
00007ac9d05dd4e2  xor eax, eax
00007ac9d05dd4e4  mov r12d, 0x200
00007ac9d05dd4ea  cmp r14, r12
00007ac9d05dd4ed  cmc
00007ac9d05dd4ee  lahf
00007ac9d05dd4ef  seto al
00007ac9d05dd4f2  mov [r15+0x108], eax
00007ac9d05dd4f9  pextrq rax, xmm1, 0x01
00007ac9d05dd500  movq xmm15, rax
00007ac9d05dd505  movaps [r15+0x130], xmm15
00007ac9d05dd50d  movaps xmm14, [r15+0x110]
00007ac9d05dd515  movq rax, xmm14
00007ac9d05dd51a  movq r14, xmm1
00007ac9d05dd51f  vmovq xmm1, rax
00007ac9d05dd524  vmovq xmm14, r14
00007ac9d05dd529  movaps xmm13, xmm1
00007ac9d05dd52d  addsd xmm13, xmm14
00007ac9d05dd532  ucomisd xmm13, xmm13
00007ac9d05dd537  jp 0x00007AC9D05DD5EC
00007ac9d05dd53d  movq xmm13, xmm13
00007ac9d05dd542  movq rax, xmm13
00007ac9d05dd547  movq r14, xmm15
00007ac9d05dd54c  vmovq xmm1, rax
00007ac9d05dd551  vmovq xmm15, r14
00007ac9d05dd556  movaps xmm14, xmm1
00007ac9d05dd55a  addsd xmm14, xmm15
00007ac9d05dd55f  ucomisd xmm14, xmm14
00007ac9d05dd564  jp 0x00007AC9D05DD634
00007ac9d05dd56a  movq xmm14, xmm14
00007ac9d05dd56f  movaps [r15+0x110], xmm14
00007ac9d05dd577  mov eax, [r15+0x108]
00007ac9d05dd57e  sahf
00007ac9d05dd57f  jnz 0x00007AC9D05DD5B1
00007ac9d05dd581  cmp dword ptr [r15+0x318], 0x00
00007ac9d05dd589  jz 0x00007AC9D05DD680
00007ac9d05dd58f  nop [rax+rax*1], ax
00007ac9d05dd598  nop [rax+rax*1], eax
00007ac9d05dd5a0  mov eax, 0x410698
00007ac9d05dd5a5  mov [r15+0x100], rax
00007ac9d05dd5ac  jmp 0x00007AC9D03FE110
00007ac9d05dd5b1  cmp dword ptr [r15+0x318], 0x00
00007ac9d05dd5b9  jz 0x00007AC9D05DD4C0
00007ac9d05dd5bf  nop [rax+rax*1], ax
00007ac9d05dd5c8  nop [rax+rax*1], eax
00007ac9d05dd5d0  mov eax, 0x41067C
00007ac9d05dd5d5  mov [r15+0x100], rax
00007ac9d05dd5dc  jmp 0x00007AC9D03FE110
00007ac9d05dd5e1  int3
00007ac9d05dd5e2  call 0x00007AC9D04B52F0
00007ac9d05dd5e7  jmp 0x00007AC9D05DD4D2
00007ac9d05dd5ec  ucomisd xmm1, xmm14
00007ac9d05dd5f1  jp 0x00007AC9D05DD600
00007ac9d05dd5f3  movaps xmm13, [0x00007AC9D01FE060]
00007ac9d05dd5fb  jmp 0x00007AC9D05DD53D
00007ac9d05dd600  vxorps xmm0, xmm1, xmm14
00007ac9d05dd605  pextrw eax, xmm0, 0x03
00007ac9d05dd60a  and eax, 0x7FF8
00007ac9d05dd60f  cmp eax, 0x08
00007ac9d05dd612  jnz 0x00007AC9D05DD53D
00007ac9d05dd618  movq rax, xmm14
00007ac9d05dd61d  shl rax, 0x0D
00007ac9d05dd621  jbe 0x00007AC9D05DD53D
00007ac9d05dd627  vorps xmm13, xmm14, [0x00007AC9D01FE070]
00007ac9d05dd62f  jmp 0x00007AC9D05DD53D
00007ac9d05dd634  ucomisd xmm1, xmm15
00007ac9d05dd639  jp 0x00007AC9D05DD648
00007ac9d05dd63b  movaps xmm14, [0x00007AC9D01FE060]
00007ac9d05dd643  jmp 0x00007AC9D05DD56A
00007ac9d05dd648  vxorps xmm0, xmm1, xmm15
00007ac9d05dd64d  pextrw eax, xmm0, 0x03
00007ac9d05dd652  and eax, 0x7FF8
00007ac9d05dd657  cmp eax, 0x08
00007ac9d05dd65a  jnz 0x00007AC9D05DD56A
00007ac9d05dd660  movq rax, xmm15
00007ac9d05dd665  shl rax, 0x0D
00007ac9d05dd669  jbe 0x00007AC9D05DD56A
00007ac9d05dd66f  vorps xmm14, xmm15, [0x00007AC9D01FE070]
00007ac9d05dd677  jmp 0x00007AC9D05DD56A
00007ac9d05dd67c  int3
00007ac9d05dd67d  nop [rax], eax
00007ac9d05dd680  mov rax, [r15+0xF8]
00007ac9d05dd687  lea r14, [rax+0x1A0]
00007ac9d05dd68e  mov r12, [r13+r14*1]
00007ac9d05dd693  lea r14, [rax+0x1A8]
00007ac9d05dd69a  mov r11, [r13+r14*1]
00007ac9d05dd69f  mov [r15+0xA0], r12
00007ac9d05dd6a6  mov [r15+0x98], r11
00007ac9d05dd6ad  mov r14, [r15+0x40]
00007ac9d05dd6b1  lea r12, [r14+0xC50]
00007ac9d05dd6b8  movaps xmm1, [r15+0x110]
00007ac9d05dd6c0  movq r14, xmm1
00007ac9d05dd6c5  mov [r13+r12*1], r14
00007ac9d05dd6ca  lea r14, [rax+0x190]
00007ac9d05dd6d1  mov r12, [r13+r14*1]
00007ac9d05dd6d6  lea r14, [rax+0x198]
00007ac9d05dd6dd  mov r11, [r13+r14*1]
00007ac9d05dd6e2  mov [r15+0xE8], r12
00007ac9d05dd6e9  mov [r15+0xF0], r11
00007ac9d05dd6f0  lea r14, [rax+0x180]
00007ac9d05dd6f7  mov r12, [r13+r14*1]
00007ac9d05dd6fc  lea r14, [rax+0x188]
00007ac9d05dd703  mov r10, [r13+r14*1]
00007ac9d05dd708  movq xmm1, r12
00007ac9d05dd70d  movq xmm15, r10
00007ac9d05dd712  movq xmm1, xmm1
00007ac9d05dd716  movq xmm1, xmm1
00007ac9d05dd71a  movaps [r15+0x1A0], xmm1
00007ac9d05dd722  movq xmm15, xmm15
00007ac9d05dd727  movq xmm15, xmm15
00007ac9d05dd72c  movaps [r15+0x190], xmm15
00007ac9d05dd734  lea r14, [rax+0x170]
00007ac9d05dd73b  mov r12, [r13+r14*1]
00007ac9d05dd740  lea r14, [rax+0x178]
00007ac9d05dd747  mov r10, [r13+r14*1]
00007ac9d05dd74c  movq xmm1, r12
00007ac9d05dd751  movq xmm15, r10
00007ac9d05dd756  movq xmm1, xmm1
00007ac9d05dd75a  movq xmm1, xmm1
00007ac9d05dd75e  movaps [r15+0x1C0], xmm1
00007ac9d05dd766  movq xmm15, xmm15
00007ac9d05dd76b  movq xmm15, xmm15
00007ac9d05dd770  movaps [r15+0x1B0], xmm15
00007ac9d05dd778  lea r14, [rax+0x160]
00007ac9d05dd77f  mov r12, [r13+r14*1]
00007ac9d05dd784  lea r14, [rax+0x168]
00007ac9d05dd78b  mov r10, [r13+r14*1]
00007ac9d05dd790  movq xmm1, r12
00007ac9d05dd795  movq xmm15, r10
00007ac9d05dd79a  movq xmm1, xmm1
00007ac9d05dd79e  movq xmm1, xmm1
00007ac9d05dd7a2  movaps [r15+0x1E0], xmm1
00007ac9d05dd7aa  movq xmm15, xmm15
00007ac9d05dd7af  movq xmm15, xmm15
00007ac9d05dd7b4  movaps [r15+0x1D0], xmm15
00007ac9d05dd7bc  lea r14, [rax+0x150]
00007ac9d05dd7c3  mov r12, [r13+r14*1]
00007ac9d05dd7c8  lea r14, [rax+0x158]
00007ac9d05dd7cf  mov r10, [r13+r14*1]
00007ac9d05dd7d4  movq xmm1, r12
00007ac9d05dd7d9  movq xmm15, r10
00007ac9d05dd7de  movq xmm1, xmm1
00007ac9d05dd7e2  movq xmm1, xmm1
00007ac9d05dd7e6  movaps [r15+0x200], xmm1
00007ac9d05dd7ee  movq xmm15, xmm15
00007ac9d05dd7f3  movq xmm15, xmm15
00007ac9d05dd7f8  movaps [r15+0x1F0], xmm15
00007ac9d05dd800  lea r14, [rax+0x1B0]
00007ac9d05dd807  mov [r15+0xF8], r14
00007ac9d05dd80e  mov [r15+0x100], r11
00007ac9d05dd815  jmp 0x00007AC9D05CE5C0
00007ac9d05dd81a  int3
00007ac9d05dd81b  call 0x00007AC9D04E27E0
00007ac9d05dd820  jmp 0x00007AC9D05DD693
00007ac9d05dd825  call 0x00007AC9D04E1570
00007ac9d05dd82a  jmp 0x00007AC9D05DD69F
00007ac9d05dd82f  call 0x00007AC9D04C3FE0
00007ac9d05dd834  jmp 0x00007AC9D05DD6CA
00007ac9d05dd839  call 0x00007AC9D04E27E0
00007ac9d05dd83e  jmp 0x00007AC9D05DD6D6
00007ac9d05dd843  call 0x00007AC9D04E1570
00007ac9d05dd848  jmp 0x00007AC9D05DD6E2
00007ac9d05dd84d  call 0x00007AC9D04E27E0
00007ac9d05dd852  jmp 0x00007AC9D05DD6FC
00007ac9d05dd857  call 0x00007AC9D04E0300
00007ac9d05dd85c  jmp 0x00007AC9D05DD708
00007ac9d05dd861  call 0x00007AC9D04E27E0
00007ac9d05dd866  jmp 0x00007AC9D05DD740
00007ac9d05dd86b  call 0x00007AC9D04E0300
00007ac9d05dd870  jmp 0x00007AC9D05DD74C
00007ac9d05dd875  call 0x00007AC9D04E27E0
00007ac9d05dd87a  jmp 0x00007AC9D05DD784
00007ac9d05dd87f  call 0x00007AC9D04E0300
00007ac9d05dd884  jmp 0x00007AC9D05DD790
00007ac9d05dd889  call 0x00007AC9D04E27E0
00007ac9d05dd88e  jmp 0x00007AC9D05DD7C8
00007ac9d05dd893  call 0x00007AC9D04E0300
00007ac9d05dd898  jmp 0x00007AC9D05DD7D4
00007ac9d05dd89d  int3
00007ac9d05dd89e  nop
00007ac9d05dd8a0  mov qword ptr [r15+0x100], 0x04
00007ac9d05dd8ab  mov esi, 0x00
00007ac9d05dd8b0  mov edx, 0x09
00007ac9d05dd8b5  mov rdi, 0x7FFE8ACC48C0
00007ac9d05dd8bf  mov rax, 0x569AF9E26970
00007ac9d05dd8c9  call rax
00007ac9d05dd8cb  cmp dword ptr [r15+0x318], 0x00
00007ac9d05dd8d3  jnz 0x00007AC9D03FE110
00007ac9d05dd8d9  jmp 0x00007AC9D03FE0A0
00007ac9d05dd8de  int3
00007ac9d05dd8df  int3
