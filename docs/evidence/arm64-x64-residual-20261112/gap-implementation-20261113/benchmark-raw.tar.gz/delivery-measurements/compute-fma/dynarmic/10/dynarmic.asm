00007175dc9ce69b  nop [rax+rax*1], eax
00007175dc9ce6a0  mov rax, [r15+0xF8]
00007175dc9ce6a7  lea r14, [rax-0x1B0]
00007175dc9ce6ae  mov [r15+0xF8], r14
00007175dc9ce6b5  lea rax, [r14+0x1A0]
00007175dc9ce6bc  mov r12, [r15+0xA0]
00007175dc9ce6c3  mov r11, [r15+0x98]
00007175dc9ce6ca  mov [r13+rax*1], r12
00007175dc9ce6cf  lea rax, [r14+0x1A8]
00007175dc9ce6d6  mov [r13+rax*1], r11
00007175dc9ce6db  mov eax, 0x420A30
00007175dc9ce6e0  movups xmm1, [r13+rax*1]
00007175dc9ce6e6  mov eax, 0x4209C0
00007175dc9ce6eb  movups xmm15, [r13+rax*1]
00007175dc9ce6f1  mov eax, 0x420A50
00007175dc9ce6f6  movups xmm14, [r13+rax*1]
00007175dc9ce6fc  mov eax, 0x4209F0
00007175dc9ce701  movups xmm13, [r13+rax*1]
00007175dc9ce707  mov qword ptr [r15+0x98], 0x430C60
00007175dc9ce712  mov eax, 0x420A60
00007175dc9ce717  movups xmm12, [r13+rax*1]
00007175dc9ce71d  mov eax, 0x430C60
00007175dc9ce722  movups [r13+rax*1], xmm1
00007175dc9ce728  mov eax, 0x430C70
00007175dc9ce72d  movups [r13+rax*1], xmm15
00007175dc9ce733  mov eax, 0x430C80
00007175dc9ce738  movups [r13+rax*1], xmm14
00007175dc9ce73e  mov eax, 0x430C90
00007175dc9ce743  movups [r13+rax*1], xmm13
00007175dc9ce749  mov eax, 0x4209B0
00007175dc9ce74e  movups xmm14, [r13+rax*1]
00007175dc9ce754  mov eax, 0x4209A0
00007175dc9ce759  movups xmm13, [r13+rax*1]
00007175dc9ce75f  mov eax, 0x430D60
00007175dc9ce764  movups [r13+rax*1], xmm1
00007175dc9ce76a  mov eax, 0x430D70
00007175dc9ce76f  movups [r13+rax*1], xmm15
00007175dc9ce775  mov eax, 0x430CA0
00007175dc9ce77a  movups [r13+rax*1], xmm12
00007175dc9ce780  mov eax, 0x430CB0
00007175dc9ce785  movups [r13+rax*1], xmm14
00007175dc9ce78b  mov eax, 0x420990
00007175dc9ce790  movups xmm1, [r13+rax*1]
00007175dc9ce796  mov eax, 0x420A00
00007175dc9ce79b  movups xmm15, [r13+rax*1]
00007175dc9ce7a1  mov eax, 0x430CC0
00007175dc9ce7a6  movups [r13+rax*1], xmm13
00007175dc9ce7ac  mov eax, 0x430CD0
00007175dc9ce7b1  movups [r13+rax*1], xmm1
00007175dc9ce7b7  mov eax, 0x420A10
00007175dc9ce7bc  movups xmm1, [r13+rax*1]
00007175dc9ce7c2  mov eax, 0x4209E0
00007175dc9ce7c7  movups xmm14, [r13+rax*1]
00007175dc9ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007175dc9ce7d5  mov eax, 0x430CE0
00007175dc9ce7da  movups [r13+rax*1], xmm15
00007175dc9ce7e0  mov eax, 0x430CF0
00007175dc9ce7e5  movups [r13+rax*1], xmm1
00007175dc9ce7eb  mov eax, 0x420A80
00007175dc9ce7f0  movups xmm1, [r13+rax*1]
00007175dc9ce7f6  mov eax, 0x420A90
00007175dc9ce7fb  movups xmm15, [r13+rax*1]
00007175dc9ce801  movaps [r15+0x150], xmm15
00007175dc9ce809  mov qword ptr [r15+0xA0], 0x3E8
00007175dc9ce814  mov eax, 0x430D00
00007175dc9ce819  movups [r13+rax*1], xmm14
00007175dc9ce81f  mov eax, 0x430D10
00007175dc9ce824  movups [r13+rax*1], xmm1
00007175dc9ce82a  mov eax, 0x420A70
00007175dc9ce82f  movups xmm1, [r13+rax*1]
00007175dc9ce835  mov eax, 0x420A20
00007175dc9ce83a  movups xmm14, [r13+rax*1]
00007175dc9ce840  movaps [r15+0x140], xmm14
00007175dc9ce848  lea rax, [r14+0x150]
00007175dc9ce84f  movq xmm13, qword ptr [r15+0x200]
00007175dc9ce858  movq xmm12, qword ptr [r15+0x1F0]
00007175dc9ce861  movq r12, xmm13
00007175dc9ce866  movq r11, xmm12
00007175dc9ce86b  mov [r13+rax*1], r12
00007175dc9ce870  lea rax, [r14+0x158]
00007175dc9ce877  mov [r13+rax*1], r11
00007175dc9ce87c  mov eax, 0x430D20
00007175dc9ce881  movups [r13+rax*1], xmm15
00007175dc9ce887  mov eax, 0x430D30
00007175dc9ce88c  movups [r13+rax*1], xmm1
00007175dc9ce892  mov eax, 0x420A40
00007175dc9ce897  movups xmm1, [r13+rax*1]
00007175dc9ce89d  mov eax, 0x420AA8
00007175dc9ce8a2  mov r12, [r13+rax*1]
00007175dc9ce8a7  movq xmm15, r12
00007175dc9ce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007175dc9ce8b4  mov eax, 0x430D40
00007175dc9ce8b9  movups [r13+rax*1], xmm14
00007175dc9ce8bf  mov eax, 0x430D50
00007175dc9ce8c4  movups [r13+rax*1], xmm1
00007175dc9ce8ca  mov eax, 0x420B10
00007175dc9ce8cf  movups xmm1, [r13+rax*1]
00007175dc9ce8d5  movq rax, xmm15
00007175dc9ce8da  mov r12d, 0x430D80
00007175dc9ce8e0  mov [r13+r12*1], rax
00007175dc9ce8e5  mov eax, 0x420AF0
00007175dc9ce8ea  movups xmm15, [r13+rax*1]
00007175dc9ce8f0  mov eax, 0x420B00
00007175dc9ce8f5  movups xmm14, [r13+rax*1]
00007175dc9ce8fb  lea rax, [r14+0x130]
00007175dc9ce902  movups [r13+rax*1], xmm1
00007175dc9ce908  lea rax, [r14+0x160]
00007175dc9ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007175dc9ce918  movq xmm13, qword ptr [r15+0x1D0]
00007175dc9ce921  movq r12, xmm1
00007175dc9ce926  movq r11, xmm13
00007175dc9ce92b  mov [r13+rax*1], r12
00007175dc9ce930  lea rax, [r14+0x168]
00007175dc9ce937  mov [r13+rax*1], r11
00007175dc9ce93c  lea rax, [r14+0x110]
00007175dc9ce943  movups [r13+rax*1], xmm15
00007175dc9ce949  lea rax, [r14+0x120]
00007175dc9ce950  movups [r13+rax*1], xmm14
00007175dc9ce956  mov eax, 0x420AB0
00007175dc9ce95b  movups xmm1, [r13+rax*1]
00007175dc9ce961  mov eax, 0x420AC0
00007175dc9ce966  movups xmm15, [r13+rax*1]
00007175dc9ce96c  movaps [r15+0x120], xmm15
00007175dc9ce974  lea rax, [r14+0x170]
00007175dc9ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007175dc9ce984  movq xmm13, qword ptr [r15+0x1B0]
00007175dc9ce98d  movq r12, xmm14
00007175dc9ce992  movq r11, xmm13
00007175dc9ce997  mov [r13+rax*1], r12
00007175dc9ce99c  lea rax, [r14+0x178]
00007175dc9ce9a3  mov [r13+rax*1], r11
00007175dc9ce9a8  lea rax, [r14+0x180]
00007175dc9ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007175dc9ce9b8  movq xmm13, qword ptr [r15+0x190]
00007175dc9ce9c1  movq r12, xmm14
00007175dc9ce9c6  movq r11, xmm13
00007175dc9ce9cb  mov [r13+rax*1], r12
00007175dc9ce9d0  lea rax, [r14+0x188]
00007175dc9ce9d7  mov [r13+rax*1], r11
00007175dc9ce9dc  lea rax, [r14+0xD0]
00007175dc9ce9e3  movups [r13+rax*1], xmm1
00007175dc9ce9e9  lea rax, [r14+0xE0]
00007175dc9ce9f0  movups [r13+rax*1], xmm15
00007175dc9ce9f6  mov eax, 0x420AD0
00007175dc9ce9fb  movups xmm1, [r13+rax*1]
00007175dc9cea01  mov eax, 0x420AE0
00007175dc9cea06  movups xmm15, [r13+rax*1]
00007175dc9cea0c  movaps [r15+0x110], xmm1
00007175dc9cea14  movaps [r15+0x130], xmm15
00007175dc9cea1c  lea rax, [r14+0x190]
00007175dc9cea23  mov r12, [r15+0xE8]
00007175dc9cea2a  mov r11, [r15+0xF0]
00007175dc9cea31  mov [r13+rax*1], r12
00007175dc9cea36  lea rax, [r14+0x198]
00007175dc9cea3d  mov [r13+rax*1], r11
00007175dc9cea42  mov eax, 0x430D88
00007175dc9cea47  mov r12d, 0x421DF8D3
00007175dc9cea4d  mov [r13+rax*1], r12d
00007175dc9cea52  lea rax, [r14+0xF0]
00007175dc9cea59  movups [r13+rax*1], xmm1
00007175dc9cea5f  lea rax, [r14+0x100]
00007175dc9cea66  movups [r13+rax*1], xmm15
00007175dc9cea6c  lea rax, [r14+0xD0]
00007175dc9cea73  mov [r15], rax
00007175dc9cea76  mov qword ptr [r15+0x08], 0x430C60
00007175dc9cea7e  mov qword ptr [r15+0x10], 0x12C
00007175dc9cea86  mov qword ptr [r15+0xF0], 0x410284
00007175dc9cea91  mov r14d, [r15+0x320]
00007175dc9cea98  mov eax, 0x410284
00007175dc9cea9d  mov rcx, 0x7175DC9D07C0
00007175dc9ceaa7  mov [r15+r14*8+0x328], rax
00007175dc9ceaaf  mov [r15+r14*8+0x368], rcx
00007175dc9ceab7  add r14d, 0x01
00007175dc9ceabb  and r14d, 0x07
00007175dc9ceabf  mov [r15+0x320], r14d
00007175dc9ceac6  cmp dword ptr [r15+0x318], 0x00
00007175dc9ceace  jz 0x00007175DC9CED70
00007175dc9cead4  nop [rax+rax*1], ax
00007175dc9ceadd  nop [rax+rax*1], eax
00007175dc9ceae5  mov eax, 0x4106BC
00007175dc9ceaea  mov [r15+0x100], rax
00007175dc9ceaf1  jmp 0x00007175DC7FE110
00007175dc9ceaf6  int3
00007175dc9ceaf7  call 0x00007175DC80BC20
00007175dc9ceafc  jmp 0x00007175DC9CE6CF
00007175dc9ceb01  call 0x00007175DC80A9A0
00007175dc9ceb06  jmp 0x00007175DC9CE6DB
00007175dc9ceb0b  call 0x00007175DC7FF430
00007175dc9ceb10  jmp 0x00007175DC9CE6E6
00007175dc9ceb15  call 0x00007175DC80E760
00007175dc9ceb1a  jmp 0x00007175DC9CE6F1
00007175dc9ceb1f  call 0x00007175DC80D4E0
00007175dc9ceb24  jmp 0x00007175DC9CE6FC
00007175dc9ceb29  call 0x00007175DC80C260
00007175dc9ceb2e  jmp 0x00007175DC9CE707
00007175dc9ceb33  call 0x00007175DC80AFE0
00007175dc9ceb38  jmp 0x00007175DC9CE71D
00007175dc9ceb3d  call 0x00007175DC7FF540
00007175dc9ceb42  jmp 0x00007175DC9CE728
00007175dc9ceb47  call 0x00007175DC80E880
00007175dc9ceb4c  jmp 0x00007175DC9CE733
00007175dc9ceb51  call 0x00007175DC80D600
00007175dc9ceb56  jmp 0x00007175DC9CE73E
00007175dc9ceb5b  call 0x00007175DC80C380
00007175dc9ceb60  jmp 0x00007175DC9CE749
00007175dc9ceb65  call 0x00007175DC80D4E0
00007175dc9ceb6a  jmp 0x00007175DC9CE754
00007175dc9ceb6f  call 0x00007175DC80C260
00007175dc9ceb74  jmp 0x00007175DC9CE75F
00007175dc9ceb79  call 0x00007175DC7FF540
00007175dc9ceb7e  jmp 0x00007175DC9CE76A
00007175dc9ceb83  call 0x00007175DC80E880
00007175dc9ceb88  jmp 0x00007175DC9CE775
00007175dc9ceb8d  call 0x00007175DC80B100
00007175dc9ceb92  jmp 0x00007175DC9CE780
00007175dc9ceb97  call 0x00007175DC80D600
00007175dc9ceb9c  jmp 0x00007175DC9CE78B
00007175dc9ceba1  call 0x00007175DC7FF430
00007175dc9ceba6  jmp 0x00007175DC9CE796
00007175dc9cebab  call 0x00007175DC80E760
00007175dc9cebb0  jmp 0x00007175DC9CE7A1
00007175dc9cebb5  call 0x00007175DC80C380
00007175dc9cebba  jmp 0x00007175DC9CE7AC
00007175dc9cebbf  call 0x00007175DC7FF540
00007175dc9cebc4  jmp 0x00007175DC9CE7B7
00007175dc9cebc9  call 0x00007175DC7FF430
00007175dc9cebce  jmp 0x00007175DC9CE7C2
00007175dc9cebd3  call 0x00007175DC80D4E0
00007175dc9cebd8  jmp 0x00007175DC9CE7CD
00007175dc9cebdd  call 0x00007175DC80E880
00007175dc9cebe2  jmp 0x00007175DC9CE7E0
00007175dc9cebe7  call 0x00007175DC7FF540
00007175dc9cebec  jmp 0x00007175DC9CE7EB
00007175dc9cebf1  call 0x00007175DC7FF430
00007175dc9cebf6  jmp 0x00007175DC9CE7F6
00007175dc9cebfb  call 0x00007175DC80E760
00007175dc9cec00  jmp 0x00007175DC9CE801
00007175dc9cec05  call 0x00007175DC80D600
00007175dc9cec0a  jmp 0x00007175DC9CE81F
00007175dc9cec0f  call 0x00007175DC7FF540
00007175dc9cec14  jmp 0x00007175DC9CE82A
00007175dc9cec19  call 0x00007175DC7FF430
00007175dc9cec1e  jmp 0x00007175DC9CE835
00007175dc9cec23  call 0x00007175DC80D4E0
00007175dc9cec28  jmp 0x00007175DC9CE840
00007175dc9cec2d  call 0x00007175DC80BC20
00007175dc9cec32  jmp 0x00007175DC9CE870
00007175dc9cec37  call 0x00007175DC80A9A0
00007175dc9cec3c  jmp 0x00007175DC9CE87C
00007175dc9cec41  call 0x00007175DC80E880
00007175dc9cec46  jmp 0x00007175DC9CE887
00007175dc9cec4b  call 0x00007175DC7FF540
00007175dc9cec50  jmp 0x00007175DC9CE892
00007175dc9cec55  call 0x00007175DC7FF430
00007175dc9cec5a  jmp 0x00007175DC9CE89D
00007175dc9cec5f  call 0x00007175DC80B720
00007175dc9cec64  jmp 0x00007175DC9CE8A7
00007175dc9cec69  call 0x00007175DC80D600
00007175dc9cec6e  jmp 0x00007175DC9CE8BF
00007175dc9cec73  call 0x00007175DC7FF540
00007175dc9cec78  jmp 0x00007175DC9CE8CA
00007175dc9cec7d  call 0x00007175DC7FF430
00007175dc9cec82  jmp 0x00007175DC9CE8D5
00007175dc9cec87  call 0x00007175DC8B4CB0
00007175dc9cec8c  jmp 0x00007175DC9CE8E5
00007175dc9cec91  call 0x00007175DC80E760
00007175dc9cec96  jmp 0x00007175DC9CE8F0
00007175dc9cec9b  call 0x00007175DC80D4E0
00007175dc9ceca0  jmp 0x00007175DC9CE8FB
00007175dc9ceca5  call 0x00007175DC7FF540
00007175dc9cecaa  jmp 0x00007175DC9CE908
00007175dc9cecaf  call 0x00007175DC80BC20
00007175dc9cecb4  jmp 0x00007175DC9CE930
00007175dc9cecb9  call 0x00007175DC80A9A0
00007175dc9cecbe  jmp 0x00007175DC9CE93C
00007175dc9cecc3  call 0x00007175DC80E880
00007175dc9cecc8  jmp 0x00007175DC9CE949
00007175dc9ceccd  call 0x00007175DC80D600
00007175dc9cecd2  jmp 0x00007175DC9CE956
00007175dc9cecd7  call 0x00007175DC7FF430
00007175dc9cecdc  jmp 0x00007175DC9CE961
00007175dc9cece1  call 0x00007175DC80E760
00007175dc9cece6  jmp 0x00007175DC9CE96C
00007175dc9ceceb  call 0x00007175DC80BC20
00007175dc9cecf0  jmp 0x00007175DC9CE99C
00007175dc9cecf5  call 0x00007175DC80A9A0
00007175dc9cecfa  jmp 0x00007175DC9CE9A8
00007175dc9cecff  call 0x00007175DC80BC20
00007175dc9ced04  jmp 0x00007175DC9CE9D0
00007175dc9ced09  call 0x00007175DC80A9A0
00007175dc9ced0e  jmp 0x00007175DC9CE9DC
00007175dc9ced13  call 0x00007175DC7FF540
00007175dc9ced18  jmp 0x00007175DC9CE9E9
00007175dc9ced1d  call 0x00007175DC80E880
00007175dc9ced22  jmp 0x00007175DC9CE9F6
00007175dc9ced27  call 0x00007175DC7FF430
00007175dc9ced2c  jmp 0x00007175DC9CEA01
00007175dc9ced31  call 0x00007175DC80E760
00007175dc9ced36  jmp 0x00007175DC9CEA0C
00007175dc9ced3b  call 0x00007175DC80BC20
00007175dc9ced40  jmp 0x00007175DC9CEA36
00007175dc9ced45  call 0x00007175DC80A9A0
00007175dc9ced4a  jmp 0x00007175DC9CEA42
00007175dc9ced4f  call 0x00007175DC80BAE0
00007175dc9ced54  jmp 0x00007175DC9CEA52
00007175dc9ced59  call 0x00007175DC7FF540
00007175dc9ced5e  jmp 0x00007175DC9CEA5F
00007175dc9ced63  call 0x00007175DC80E880
00007175dc9ced68  jmp 0x00007175DC9CEA6C
00007175dc9ced6d  int3
00007175dc9ced6e  nop
00007175dc9ced70  mov rax, [r15]
00007175dc9ced73  lea r14, [rax+0x20]
00007175dc9ced77  mov r12, [r13+r14*1]
00007175dc9ced7c  mov r14, [r15+0x10]
00007175dc9ced80  lea r11, [r12+r14*1]
00007175dc9ced84  mov [r15+0x40], r11
00007175dc9ced88  lea r12, [rax+0x20]
00007175dc9ced8c  mov [r13+r12*1], r11
00007175dc9ced91  test r14, r14
00007175dc9ced94  setz r14b
00007175dc9ced98  movzx r14, r14b
00007175dc9ced9c  mov [rsp+0x414], r14b
00007175dc9ceda4  cmp byte ptr [rsp+0x414], 0x00
00007175dc9cedac  jz 0x00007175DC9CEDDE
00007175dc9cedae  cmp dword ptr [r15+0x318], 0x00
00007175dc9cedb6  mov eax, 0x410934
00007175dc9cedbb  mov [r15+0x100], rax
00007175dc9cedc2  jz 0x00007175DC7FE0A0
00007175dc9cedc8  nop [rax+rax*1], eax
00007175dc9cedcd  mov eax, 0x410934
00007175dc9cedd2  mov [r15+0x100], rax
00007175dc9cedd9  jmp 0x00007175DC7FE110
00007175dc9cedde  cmp dword ptr [r15+0x318], 0x00
00007175dc9cede6  jz 0x00007175DC9CEE30
00007175dc9cedec  nop [rax+rax*1], ax
00007175dc9cedf5  nop [rax+rax*1], eax
00007175dc9cedfd  mov eax, 0x4106CC
00007175dc9cee02  mov [r15+0x100], rax
00007175dc9cee09  jmp 0x00007175DC7FE110
00007175dc9cee0e  int3
00007175dc9cee0f  call 0x00007175DC8E27E0
00007175dc9cee14  jmp 0x00007175DC9CED7C
00007175dc9cee19  call 0x00007175DC8C0860
00007175dc9cee1e  jmp 0x00007175DC9CED91
00007175dc9cee23  int3
00007175dc9cee24  nop [rax+rax*1], ax
00007175dc9cee2d  nop [rax], eax
00007175dc9cee30  mov rax, [r15+0xF8]
00007175dc9cee37  lea r14, [rax-0x150]
00007175dc9cee3e  mov [r15+0xF8], r14
00007175dc9cee45  mov rax, [r15]
00007175dc9cee48  lea r12, [rax+0x68]
00007175dc9cee4c  mov r11, [r13+r12*1]
00007175dc9cee51  mov [r15+0x88], r11
00007175dc9cee58  lea r12, [rax+0x28]
00007175dc9cee5c  mov [r15+0x40], r12
00007175dc9cee60  mov [r15+0x48], r14
00007175dc9cee64  mov qword ptr [r15+0x50], 0x420B20
00007175dc9cee6c  lea rax, [r14+0x100]
00007175dc9cee73  mov r12, [r15+0xE8]
00007175dc9cee7a  mov r11, [r15+0xD8]
00007175dc9cee81  mov [r13+rax*1], r12
00007175dc9cee86  lea rax, [r14+0x108]
00007175dc9cee8d  mov [r13+rax*1], r11
00007175dc9cee92  lea rax, [r14+0x110]
00007175dc9cee99  mov r12, [r15+0xD0]
00007175dc9ceea0  mov r11, [r15+0xC8]
00007175dc9ceea7  mov [r13+rax*1], r12
00007175dc9ceeac  lea rax, [r14+0x118]
00007175dc9ceeb3  mov [r13+rax*1], r11
00007175dc9ceeb8  lea rax, [r14+0x120]
00007175dc9ceebf  mov r12, [r15+0xC0]
00007175dc9ceec6  mov r11, [r15+0xB8]
00007175dc9ceecd  mov [r13+rax*1], r12
00007175dc9ceed2  lea rax, [r14+0x128]
00007175dc9ceed9  mov [r13+rax*1], r11
00007175dc9ceede  lea rax, [r14+0x130]
00007175dc9ceee5  mov r12, [r15+0xB0]
00007175dc9ceeec  mov r11, [r15+0xA8]
00007175dc9ceef3  mov [r13+rax*1], r12
00007175dc9ceef8  lea rax, [r14+0x138]
00007175dc9ceeff  mov [r13+rax*1], r11
00007175dc9cef04  lea rax, [r14+0x140]
00007175dc9cef0b  mov r12, [r15+0xA0]
00007175dc9cef12  mov r11, [r15+0x98]
00007175dc9cef19  mov [r13+rax*1], r12
00007175dc9cef1e  lea rax, [r14+0x148]
00007175dc9cef25  mov [r13+rax*1], r11
00007175dc9cef2a  cmp dword ptr [r15+0x318], 0x00
00007175dc9cef32  jz 0x00007175DC9CEFD0
00007175dc9cef38  nop [rax+rax*1], ax
00007175dc9cef41  nop [rax+rax*1], eax
00007175dc9cef49  mov eax, 0x410704
00007175dc9cef4e  mov [r15+0x100], rax
00007175dc9cef55  jmp 0x00007175DC7FE110
00007175dc9cef5a  int3
00007175dc9cef5b  call 0x00007175DC8C0370
00007175dc9cef60  jmp 0x00007175DC9CEE51
00007175dc9cef65  call 0x00007175DC80BC20
00007175dc9cef6a  jmp 0x00007175DC9CEE86
00007175dc9cef6f  call 0x00007175DC80A9A0
00007175dc9cef74  jmp 0x00007175DC9CEE92
00007175dc9cef79  call 0x00007175DC80BC20
00007175dc9cef7e  jmp 0x00007175DC9CEEAC
00007175dc9cef83  call 0x00007175DC80A9A0
00007175dc9cef88  jmp 0x00007175DC9CEEB8
00007175dc9cef8d  call 0x00007175DC80BC20
00007175dc9cef92  jmp 0x00007175DC9CEED2
00007175dc9cef97  call 0x00007175DC80A9A0
00007175dc9cef9c  jmp 0x00007175DC9CEEDE
00007175dc9cefa1  call 0x00007175DC80BC20
00007175dc9cefa6  jmp 0x00007175DC9CEEF8
00007175dc9cefab  call 0x00007175DC80A9A0
00007175dc9cefb0  jmp 0x00007175DC9CEF04
00007175dc9cefb5  call 0x00007175DC80BC20
00007175dc9cefba  jmp 0x00007175DC9CEF1E
00007175dc9cefbf  call 0x00007175DC80A9A0
00007175dc9cefc4  jmp 0x00007175DC9CEF2A
00007175dc9cefc9  int3
00007175dc9cefca  nop [rax+rax*1], ax
00007175dc9cefd0  mov rax, [r15+0x08]
00007175dc9cefd4  movzx r14d, byte ptr [r13+rax*1]
00007175dc9cefda  movzx r14d, r14b
00007175dc9cefde  mov [rsp+0x10], r14d
00007175dc9cefe3  mov r14d, r14d
00007175dc9cefe6  mov [r15+0x58], r14
00007175dc9cefea  lea r14, [rax+0x01]
00007175dc9cefee  mov [r15+0x08], r14
00007175dc9ceff2  mov rax, [r15+0x88]
00007175dc9ceff9  lea r14, [rax+0x01]
00007175dc9ceffd  mov r12, [r15]
00007175dc9cf000  lea r11, [r12+0x68]
00007175dc9cf005  mov [r13+r11*1], r14
00007175dc9cf00a  lea r14, [r12+rax*1]
00007175dc9cf00e  mov [r15+0x60], r14
00007175dc9cf012  lea rax, [r14+0x28]
00007175dc9cf016  mov r11d, [rsp+0x10]
00007175dc9cf01b  movzx r14d, r11b
00007175dc9cf01f  mov [r13+rax*1], r14b
00007175dc9cf024  lea rax, [r12+0x68]
00007175dc9cf029  mov r14, [r13+rax*1]
00007175dc9cf02e  mov [r15+0x88], r14
00007175dc9cf035  xor eax, eax
00007175dc9cf037  mov r12d, 0x40
00007175dc9cf03d  cmp r14, r12
00007175dc9cf040  cmc
00007175dc9cf041  lahf
00007175dc9cf042  seto al
00007175dc9cf045  mov [r15+0x108], eax
00007175dc9cf04c  mov eax, [r15+0x108]
00007175dc9cf053  sahf
00007175dc9cf054  jnz 0x00007175DC9CF086
00007175dc9cf056  cmp dword ptr [r15+0x318], 0x00
00007175dc9cf05e  jz 0x00007175DC9CF170
00007175dc9cf064  nop [rax+rax*1], ax
00007175dc9cf06d  nop [rax+rax*1], eax
00007175dc9cf075  mov eax, 0x410724
00007175dc9cf07a  mov [r15+0x100], rax
00007175dc9cf081  jmp 0x00007175DC7FE110
00007175dc9cf086  cmp dword ptr [r15+0x318], 0x00
00007175dc9cf08e  jz 0x00007175DC9CF0E0
00007175dc9cf094  nop [rax+rax*1], ax
00007175dc9cf09d  nop [rax+rax*1], eax
00007175dc9cf0a5  mov eax, 0x4106FC
00007175dc9cf0aa  mov [r15+0x100], rax
00007175dc9cf0b1  jmp 0x00007175DC7FE110
00007175dc9cf0b6  int3
00007175dc9cf0b7  call 0x00007175DC80D860
00007175dc9cf0bc  jmp 0x00007175DC9CEFDA
00007175dc9cf0c1  call 0x00007175DC8B36E0
00007175dc9cf0c6  jmp 0x00007175DC9CF00A
00007175dc9cf0cb  call 0x00007175DC80DD60
00007175dc9cf0d0  jmp 0x00007175DC9CF024
00007175dc9cf0d5  call 0x00007175DC80DC20
00007175dc9cf0da  jmp 0x00007175DC9CF02E
00007175dc9cf0df  int3
00007175dc9cf0e0  mov rax, [r15+0x10]
00007175dc9cf0e4  lea r14, [rax-0x01]
00007175dc9cf0e8  mov [r15+0x10], r14
00007175dc9cf0ec  test r14, r14
00007175dc9cf0ef  setz r14b
00007175dc9cf0f3  movzx r14, r14b
00007175dc9cf0f7  mov [rsp+0x414], r14b
00007175dc9cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007175dc9cf107  jz 0x00007175DC9CF139
00007175dc9cf109  cmp dword ptr [r15+0x318], 0x00
00007175dc9cf111  jz 0x00007175DC9D0670
00007175dc9cf117  nop [rax+rax*1], ax
00007175dc9cf120  nop [rax+rax*1], eax
00007175dc9cf128  mov eax, 0x41091C
00007175dc9cf12d  mov [r15+0x100], rax
00007175dc9cf134  jmp 0x00007175DC7FE110
00007175dc9cf139  cmp dword ptr [r15+0x318], 0x00
00007175dc9cf141  jz 0x00007175DC9CEFD0
00007175dc9cf147  nop [rax+rax*1], ax
00007175dc9cf150  nop [rax+rax*1], eax
00007175dc9cf158  mov eax, 0x410704
00007175dc9cf15d  mov [r15+0x100], rax
00007175dc9cf164  jmp 0x00007175DC7FE110
00007175dc9cf169  int3
00007175dc9cf16a  int3
00007175dc9cf16b  nop [rax+rax*1], eax
00007175dc9cf170  mov rax, [r15+0x40]
00007175dc9cf174  movzx r14d, byte ptr [r13+rax*1]
00007175dc9cf17a  movaps xmm1, [r15+0x110]
00007175dc9cf182  pinsrb xmm1, r14d, 0x00
00007175dc9cf189  lea r14, [rax+0x01]
00007175dc9cf18d  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf193  movaps xmm15, [r15+0x120]
00007175dc9cf19b  pinsrb xmm15, r12d, 0x00
00007175dc9cf1a2  lea r14, [rax+0x02]
00007175dc9cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf1ac  movaps xmm14, [r15+0x130]
00007175dc9cf1b4  pinsrb xmm14, r12d, 0x00
00007175dc9cf1bb  lea r14, [rax+0x03]
00007175dc9cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf1c5  movaps xmm13, [r15+0x140]
00007175dc9cf1cd  pinsrb xmm13, r12d, 0x00
00007175dc9cf1d4  lea r14, [rax+0x04]
00007175dc9cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf1de  pinsrb xmm1, r12d, 0x01
00007175dc9cf1e5  lea r14, [rax+0x05]
00007175dc9cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf1ef  pinsrb xmm15, r12d, 0x01
00007175dc9cf1f6  lea r14, [rax+0x06]
00007175dc9cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf200  pinsrb xmm14, r12d, 0x01
00007175dc9cf207  lea r14, [rax+0x07]
00007175dc9cf20b  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf211  pinsrb xmm13, r12d, 0x01
00007175dc9cf218  lea r14, [rax+0x08]
00007175dc9cf21c  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf222  pinsrb xmm1, r12d, 0x02
00007175dc9cf229  lea r14, [rax+0x09]
00007175dc9cf22d  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf233  pinsrb xmm15, r12d, 0x02
00007175dc9cf23a  lea r14, [rax+0x0A]
00007175dc9cf23e  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf244  pinsrb xmm14, r12d, 0x02
00007175dc9cf24b  lea r14, [rax+0x0B]
00007175dc9cf24f  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf255  pinsrb xmm13, r12d, 0x02
00007175dc9cf25c  lea r14, [rax+0x0C]
00007175dc9cf260  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf266  pinsrb xmm1, r12d, 0x03
00007175dc9cf26d  lea r14, [rax+0x0D]
00007175dc9cf271  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf277  pinsrb xmm15, r12d, 0x03
00007175dc9cf27e  lea r14, [rax+0x0E]
00007175dc9cf282  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf288  pinsrb xmm14, r12d, 0x03
00007175dc9cf28f  lea r14, [rax+0x0F]
00007175dc9cf293  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf299  pinsrb xmm13, r12d, 0x03
00007175dc9cf2a0  lea r14, [rax+0x10]
00007175dc9cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf2aa  pinsrb xmm1, r12d, 0x04
00007175dc9cf2b1  lea r14, [rax+0x11]
00007175dc9cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf2bb  pinsrb xmm15, r12d, 0x04
00007175dc9cf2c2  lea r14, [rax+0x12]
00007175dc9cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf2cc  pinsrb xmm14, r12d, 0x04
00007175dc9cf2d3  lea r14, [rax+0x13]
00007175dc9cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf2dd  pinsrb xmm13, r12d, 0x04
00007175dc9cf2e4  lea r14, [rax+0x14]
00007175dc9cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf2ee  pinsrb xmm1, r12d, 0x05
00007175dc9cf2f5  lea r14, [rax+0x15]
00007175dc9cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf2ff  pinsrb xmm15, r12d, 0x05
00007175dc9cf306  lea r14, [rax+0x16]
00007175dc9cf30a  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf310  pinsrb xmm14, r12d, 0x05
00007175dc9cf317  lea r14, [rax+0x17]
00007175dc9cf31b  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf321  pinsrb xmm13, r12d, 0x05
00007175dc9cf328  lea r14, [rax+0x18]
00007175dc9cf32c  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf332  pinsrb xmm1, r12d, 0x06
00007175dc9cf339  lea r14, [rax+0x19]
00007175dc9cf33d  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf343  pinsrb xmm15, r12d, 0x06
00007175dc9cf34a  lea r14, [rax+0x1A]
00007175dc9cf34e  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf354  pinsrb xmm14, r12d, 0x06
00007175dc9cf35b  lea r14, [rax+0x1B]
00007175dc9cf35f  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf365  pinsrb xmm13, r12d, 0x06
00007175dc9cf36c  lea r14, [rax+0x1C]
00007175dc9cf370  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf376  pinsrb xmm1, r12d, 0x07
00007175dc9cf37d  lea r14, [rax+0x1D]
00007175dc9cf381  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf387  pinsrb xmm15, r12d, 0x07
00007175dc9cf38e  lea r14, [rax+0x1E]
00007175dc9cf392  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf398  pinsrb xmm14, r12d, 0x07
00007175dc9cf39f  lea r14, [rax+0x1F]
00007175dc9cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf3a9  pinsrb xmm13, r12d, 0x07
00007175dc9cf3b0  lea r14, [rax+0x20]
00007175dc9cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf3ba  pinsrb xmm1, r12d, 0x08
00007175dc9cf3c1  lea r14, [rax+0x21]
00007175dc9cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf3cb  pinsrb xmm15, r12d, 0x08
00007175dc9cf3d2  lea r14, [rax+0x22]
00007175dc9cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf3dc  pinsrb xmm14, r12d, 0x08
00007175dc9cf3e3  lea r14, [rax+0x23]
00007175dc9cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf3ed  pinsrb xmm13, r12d, 0x08
00007175dc9cf3f4  lea r14, [rax+0x24]
00007175dc9cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf3fe  pinsrb xmm1, r12d, 0x09
00007175dc9cf405  lea r14, [rax+0x25]
00007175dc9cf409  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf40f  pinsrb xmm15, r12d, 0x09
00007175dc9cf416  lea r14, [rax+0x26]
00007175dc9cf41a  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf420  pinsrb xmm14, r12d, 0x09
00007175dc9cf427  lea r14, [rax+0x27]
00007175dc9cf42b  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf431  pinsrb xmm13, r12d, 0x09
00007175dc9cf438  lea r14, [rax+0x28]
00007175dc9cf43c  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf442  pinsrb xmm1, r12d, 0x0A
00007175dc9cf449  lea r14, [rax+0x29]
00007175dc9cf44d  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf453  pinsrb xmm15, r12d, 0x0A
00007175dc9cf45a  lea r14, [rax+0x2A]
00007175dc9cf45e  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf464  pinsrb xmm14, r12d, 0x0A
00007175dc9cf46b  lea r14, [rax+0x2B]
00007175dc9cf46f  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf475  pinsrb xmm13, r12d, 0x0A
00007175dc9cf47c  lea r14, [rax+0x2C]
00007175dc9cf480  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf486  pinsrb xmm1, r12d, 0x0B
00007175dc9cf48d  lea r14, [rax+0x2D]
00007175dc9cf491  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf497  pinsrb xmm15, r12d, 0x0B
00007175dc9cf49e  lea r14, [rax+0x2E]
00007175dc9cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf4a8  pinsrb xmm14, r12d, 0x0B
00007175dc9cf4af  lea r14, [rax+0x2F]
00007175dc9cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf4b9  pinsrb xmm13, r12d, 0x0B
00007175dc9cf4c0  lea r14, [rax+0x30]
00007175dc9cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf4ca  pinsrb xmm1, r12d, 0x0C
00007175dc9cf4d1  lea r14, [rax+0x31]
00007175dc9cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf4db  pinsrb xmm15, r12d, 0x0C
00007175dc9cf4e2  lea r14, [rax+0x32]
00007175dc9cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf4ec  pinsrb xmm14, r12d, 0x0C
00007175dc9cf4f3  lea r14, [rax+0x33]
00007175dc9cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf4fd  pinsrb xmm13, r12d, 0x0C
00007175dc9cf504  lea r14, [rax+0x34]
00007175dc9cf508  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf50e  pinsrb xmm1, r12d, 0x0D
00007175dc9cf515  lea r14, [rax+0x35]
00007175dc9cf519  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf51f  pinsrb xmm15, r12d, 0x0D
00007175dc9cf526  lea r14, [rax+0x36]
00007175dc9cf52a  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf530  pinsrb xmm14, r12d, 0x0D
00007175dc9cf537  lea r14, [rax+0x37]
00007175dc9cf53b  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf541  pinsrb xmm13, r12d, 0x0D
00007175dc9cf548  lea r14, [rax+0x38]
00007175dc9cf54c  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf552  pinsrb xmm1, r12d, 0x0E
00007175dc9cf559  lea r14, [rax+0x39]
00007175dc9cf55d  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf563  pinsrb xmm15, r12d, 0x0E
00007175dc9cf56a  lea r14, [rax+0x3A]
00007175dc9cf56e  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf574  pinsrb xmm14, r12d, 0x0E
00007175dc9cf57b  lea r14, [rax+0x3B]
00007175dc9cf57f  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf585  pinsrb xmm13, r12d, 0x0E
00007175dc9cf58c  lea r14, [rax+0x3C]
00007175dc9cf590  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf596  pinsrb xmm1, r12d, 0x0F
00007175dc9cf59d  movaps [r15+0x110], xmm1
00007175dc9cf5a5  lea r14, [rax+0x3D]
00007175dc9cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf5af  pinsrb xmm15, r12d, 0x0F
00007175dc9cf5b6  movaps [r15+0x120], xmm15
00007175dc9cf5be  lea r14, [rax+0x3E]
00007175dc9cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007175dc9cf5c8  pinsrb xmm14, r12d, 0x0F
00007175dc9cf5cf  movaps [r15+0x130], xmm14
00007175dc9cf5d7  lea r14, [rax+0x3F]
00007175dc9cf5db  movzx eax, byte ptr [r13+r14*1]
00007175dc9cf5e1  pinsrb xmm13, eax, 0x0F
00007175dc9cf5e8  movaps [r15+0x140], xmm13
00007175dc9cf5f0  movq xmm1, qword ptr [r15+0x120]
00007175dc9cf5f9  pmovzxbw xmm1, xmm1
00007175dc9cf5fe  psllw xmm1, 0x00
00007175dc9cf603  movaps [r15+0x150], xmm1
00007175dc9cf60b  movq xmm1, qword ptr [r15+0x130]
00007175dc9cf614  pmovzxbw xmm1, xmm1
00007175dc9cf619  psllw xmm1, 0x00
00007175dc9cf61e  movaps [r15+0x160], xmm1
00007175dc9cf626  movq xmm1, qword ptr [r15+0x110]
00007175dc9cf62f  pmovzxbw xmm1, xmm1
00007175dc9cf634  psllw xmm1, 0x00
00007175dc9cf639  movaps [r15+0x170], xmm1
00007175dc9cf641  movaps xmm15, [r15+0x110]
00007175dc9cf649  pextrq rax, xmm15, 0x01
00007175dc9cf650  movq xmm15, rax
00007175dc9cf655  pmovzxbw xmm15, xmm15
00007175dc9cf65b  psllw xmm15, 0x00
00007175dc9cf661  movaps [r15+0x180], xmm15
00007175dc9cf669  movaps xmm14, [r15+0x120]
00007175dc9cf671  pextrq rax, xmm14, 0x01
00007175dc9cf678  movq xmm14, rax
00007175dc9cf67d  pmovzxbw xmm14, xmm14
00007175dc9cf683  psllw xmm14, 0x00
00007175dc9cf689  movaps [r15+0x210], xmm14
00007175dc9cf691  movaps xmm13, [r15+0x130]
00007175dc9cf699  pextrq rax, xmm13, 0x01
00007175dc9cf6a0  movq xmm13, rax
00007175dc9cf6a5  pmovzxbw xmm13, xmm13
00007175dc9cf6ab  psllw xmm13, 0x00
00007175dc9cf6b1  movaps [r15+0x220], xmm13
00007175dc9cf6b9  movq xmm12, qword ptr [r15+0x140]
00007175dc9cf6c2  pmovzxbw xmm12, xmm12
00007175dc9cf6c8  psllw xmm12, 0x00
00007175dc9cf6ce  movaps [r15+0x250], xmm12
00007175dc9cf6d6  movaps xmm12, [r15+0x140]
00007175dc9cf6de  pextrq rax, xmm12, 0x01
00007175dc9cf6e5  movq xmm12, rax
00007175dc9cf6ea  pmovzxbw xmm12, xmm12
00007175dc9cf6f0  psllw xmm12, 0x00
00007175dc9cf6f6  movaps [r15+0x110], xmm12
00007175dc9cf6fe  movq xmm11, qword ptr [r15+0x150]
00007175dc9cf707  pmovzxwd xmm11, xmm11
00007175dc9cf70d  pslld xmm11, 0x10
00007175dc9cf713  movq xmm10, qword ptr [r15+0x160]
00007175dc9cf71c  pmovzxwd xmm10, xmm10
00007175dc9cf722  pslld xmm10, 0x08
00007175dc9cf728  pextrq rax, xmm1, 0x01
00007175dc9cf72f  movq xmm1, rax
00007175dc9cf734  pmovzxwd xmm1, xmm1
00007175dc9cf739  pslld xmm1, 0x00
00007175dc9cf73e  movaps [r15+0x260], xmm1
00007175dc9cf746  pextrq rax, xmm15, 0x01
00007175dc9cf74d  movq xmm15, rax
00007175dc9cf752  pmovzxwd xmm15, xmm15
00007175dc9cf758  pslld xmm15, 0x00
00007175dc9cf75e  movaps [r15+0x270], xmm15
00007175dc9cf766  movq xmm9, qword ptr [r15+0x170]
00007175dc9cf76f  pmovzxwd xmm9, xmm9
00007175dc9cf775  pslld xmm9, 0x00
00007175dc9cf77b  pextrq rax, xmm14, 0x01
00007175dc9cf782  movq xmm14, rax
00007175dc9cf787  pmovzxwd xmm14, xmm14
00007175dc9cf78d  pslld xmm14, 0x10
00007175dc9cf793  movaps [r15+0x280], xmm14
00007175dc9cf79b  movq xmm8, qword ptr [r15+0x180]
00007175dc9cf7a4  pmovzxwd xmm8, xmm8
00007175dc9cf7aa  pslld xmm8, 0x00
00007175dc9cf7b0  movq xmm7, qword ptr [r15+0x210]
00007175dc9cf7b9  pmovzxwd xmm7, xmm7
00007175dc9cf7be  pslld xmm7, 0x10
00007175dc9cf7c3  movaps xmm6, [r15+0x150]
00007175dc9cf7cb  pextrq rax, xmm6, 0x01
00007175dc9cf7d2  movq xmm6, rax
00007175dc9cf7d7  pmovzxwd xmm6, xmm6
00007175dc9cf7dc  pslld xmm6, 0x10
00007175dc9cf7e1  por xmm11, xmm10
00007175dc9cf7e6  movaps [r15+0x230], xmm11
00007175dc9cf7ee  pextrq rax, xmm13, 0x01
00007175dc9cf7f5  movq xmm13, rax
00007175dc9cf7fa  pmovzxwd xmm13, xmm13
00007175dc9cf800  pslld xmm13, 0x08
00007175dc9cf806  movaps [r15+0x240], xmm13
00007175dc9cf80e  movq xmm10, qword ptr [r15+0x220]
00007175dc9cf817  pmovzxwd xmm10, xmm10
00007175dc9cf81d  pslld xmm10, 0x08
00007175dc9cf823  movaps xmm5, [r15+0x160]
00007175dc9cf82b  pextrq rax, xmm5, 0x01
00007175dc9cf832  movq xmm5, rax
00007175dc9cf837  pmovzxwd xmm5, xmm5
00007175dc9cf83c  pslld xmm5, 0x08
00007175dc9cf841  pslld xmm9, 0x18
00007175dc9cf847  pslld xmm15, 0x18
00007175dc9cf84d  pslld xmm8, 0x18
00007175dc9cf853  movq xmm4, qword ptr [r15+0x250]
00007175dc9cf85c  pmovzxwd xmm4, xmm4
00007175dc9cf861  pslld xmm4, 0x00
00007175dc9cf866  por xmm14, xmm13
00007175dc9cf86b  por xmm7, xmm10
00007175dc9cf870  movaps [r15+0x210], xmm7
00007175dc9cf878  pslld xmm1, 0x18
00007175dc9cf87d  movaps [r15+0x220], xmm1
00007175dc9cf885  por xmm6, xmm5
00007175dc9cf889  por xmm11, xmm9
00007175dc9cf88e  movaps [r15+0x160], xmm11
00007175dc9cf896  pextrq rax, xmm12, 0x01
00007175dc9cf89d  movq xmm13, rax
00007175dc9cf8a2  pmovzxwd xmm13, xmm13
00007175dc9cf8a8  pslld xmm13, 0x00
00007175dc9cf8ae  movaps [r15+0x170], xmm13
00007175dc9cf8b6  movq xmm12, qword ptr [r15+0x110]
00007175dc9cf8bf  pmovzxwd xmm12, xmm12
00007175dc9cf8c5  pslld xmm12, 0x00
00007175dc9cf8cb  por xmm14, xmm15
00007175dc9cf8d0  por xmm7, xmm8
00007175dc9cf8d5  movaps xmm15, [r15+0x250]
00007175dc9cf8dd  pextrq rax, xmm15, 0x01
00007175dc9cf8e4  movq xmm15, rax
00007175dc9cf8e9  pmovzxwd xmm15, xmm15
00007175dc9cf8ef  pslld xmm15, 0x00
00007175dc9cf8f5  movaps [r15+0x180], xmm15
00007175dc9cf8fd  por xmm6, xmm1
00007175dc9cf901  movaps [r15+0x150], xmm6
00007175dc9cf909  por xmm11, xmm4
00007175dc9cf90e  movaps [r15+0x140], xmm11
00007175dc9cf916  por xmm7, xmm12
00007175dc9cf91b  movaps [r15+0x110], xmm7
00007175dc9cf923  por xmm14, xmm13
00007175dc9cf928  movaps [r15+0x120], xmm14
00007175dc9cf930  por xmm6, xmm15
00007175dc9cf935  movaps [r15+0x130], xmm6
00007175dc9cf93d  mov rax, [r15+0xF8]
00007175dc9cf944  lea r14, [rax+0x20]
00007175dc9cf948  movups [r13+r14*1], xmm7
00007175dc9cf94e  lea r14, [rax+0x30]
00007175dc9cf952  movups [r13+r14*1], xmm14
00007175dc9cf958  movups [r13+rax*1], xmm11
00007175dc9cf95e  lea r14, [rax+0x10]
00007175dc9cf962  movups [r13+r14*1], xmm6
00007175dc9cf968  mov r14d, [r13+rax*1]
00007175dc9cf96d  mov rax, [r15+0x48]
00007175dc9cf971  mov [r15+0x68], rax
00007175dc9cf975  mov qword ptr [r15+0x58], 0x04
00007175dc9cf97d  lea r12, [rax+0x04]
00007175dc9cf981  mov r11d, [r13+r12*1]
00007175dc9cf986  mov [rsp+0x10], r11d
00007175dc9cf98b  mov r11d, r11d
00007175dc9cf98e  mov [r15+0x70], r11
00007175dc9cf992  lea r12, [rax+0x38]
00007175dc9cf996  mov r11d, [r13+r12*1]
00007175dc9cf99b  lea r12, [rax+0x24]
00007175dc9cf99f  mov r10d, [r13+r12*1]
00007175dc9cf9a4  mov [rsp+0x20], r10d
00007175dc9cf9a9  mov r10d, r10d
00007175dc9cf9ac  mov [r15+0x90], r10
00007175dc9cf9b3  mov [rsp+0x30], rax
00007175dc9cf9b8  xor eax, eax
00007175dc9cf9ba  mov r12d, 0x04
00007175dc9cf9c0  mov r10d, 0xC0
00007175dc9cf9c6  cmp r12, r10
00007175dc9cf9c9  cmc
00007175dc9cf9ca  lahf
00007175dc9cf9cb  seto al
00007175dc9cf9ce  mov [r15+0x108], eax
00007175dc9cf9d5  mov eax, [rsp+0x10]
00007175dc9cf9d9  mov r12d, [rsp+0x10]
00007175dc9cf9de  shrd eax, r12d, 0x07
00007175dc9cf9e3  mov [rsp+0x10], r11d
00007175dc9cf9e8  mov r10d, [rsp+0x10]
00007175dc9cf9ed  shrd r11d, r10d, 0x11
00007175dc9cf9f2  mov r9d, [rsp+0x20]
00007175dc9cf9f7  lea r8d, [r9d+r14d*1]
00007175dc9cf9fc  rorx r14d, r12d, 0x12
00007175dc9cfa02  xor eax, r14d
00007175dc9cfa05  rorx r14d, r10d, 0x13
00007175dc9cfa0b  xor r11d, r14d
00007175dc9cfa0e  mov [rsp+0x10], r11d
00007175dc9cfa13  mov r11d, r11d
00007175dc9cfa16  mov [r15+0x88], r11
00007175dc9cfa1d  mov [rsp+0x20], r12d
00007175dc9cfa22  shr r12d, 0x03
00007175dc9cfa26  xor eax, r12d
00007175dc9cfa29  mov [rsp+0x40], eax
00007175dc9cfa2d  mov eax, eax
00007175dc9cfa2f  mov [r15+0x80], rax
00007175dc9cfa36  shr r10d, 0x0A
00007175dc9cfa3a  mov eax, [rsp+0x10]
00007175dc9cfa3e  xor eax, r10d
00007175dc9cfa41  mov [rsp+0x10], eax
00007175dc9cfa45  mov eax, eax
00007175dc9cfa47  mov [r15+0x78], rax
00007175dc9cfa4b  mov eax, [rsp+0x40]
00007175dc9cfa4f  lea r14d, [r8d+eax*1]
00007175dc9cfa54  mov eax, [rsp+0x10]
00007175dc9cfa58  lea r12d, [r14d+eax*1]
00007175dc9cfa5d  mov rax, [rsp+0x30]
00007175dc9cfa62  lea r14, [rax+0x40]
00007175dc9cfa66  mov [r13+r14*1], r12d
00007175dc9cfa6b  mov eax, [rsp+0x20]
00007175dc9cfa6f  mov eax, eax
00007175dc9cfa71  mov [r15+0x60], rax
00007175dc9cfa75  mov eax, [r15+0x108]
00007175dc9cfa7c  sahf
00007175dc9cfa7d  jnz 0x00007175DC9CFAAF
00007175dc9cfa7f  cmp dword ptr [r15+0x318], 0x00
00007175dc9cfa87  jz 0x00007175DC9CFF70
00007175dc9cfa8d  nop [rax+rax*1], ax
00007175dc9cfa96  nop [rax+rax*1], eax
00007175dc9cfa9e  mov eax, 0x410820
00007175dc9cfaa3  mov [r15+0x100], rax
00007175dc9cfaaa  jmp 0x00007175DC7FE110
00007175dc9cfaaf  cmp dword ptr [r15+0x318], 0x00
00007175dc9cfab7  jz 0x00007175DC9CFDC0
00007175dc9cfabd  nop [rax+rax*1], ax
00007175dc9cfac6  nop [rax+rax*1], eax
00007175dc9cface  mov eax, 0x4107D8
00007175dc9cfad3  mov [r15+0x100], rax
00007175dc9cfada  jmp 0x00007175DC7FE110
00007175dc9cfadf  int3
00007175dc9cfae0  call 0x00007175DC80D860
00007175dc9cfae5  jmp 0x00007175DC9CF17A
00007175dc9cfaea  call 0x00007175DC8E2420
00007175dc9cfaef  jmp 0x00007175DC9CF193
00007175dc9cfaf4  call 0x00007175DC8E2420
00007175dc9cfaf9  jmp 0x00007175DC9CF1AC
00007175dc9cfafe  call 0x00007175DC8E2420
00007175dc9cfb03  jmp 0x00007175DC9CF1C5
00007175dc9cfb08  call 0x00007175DC8E2420
00007175dc9cfb0d  jmp 0x00007175DC9CF1DE
00007175dc9cfb12  call 0x00007175DC8E2420
00007175dc9cfb17  jmp 0x00007175DC9CF1EF
00007175dc9cfb1c  call 0x00007175DC8E2420
00007175dc9cfb21  jmp 0x00007175DC9CF200
00007175dc9cfb26  call 0x00007175DC8E2420
00007175dc9cfb2b  jmp 0x00007175DC9CF211
00007175dc9cfb30  call 0x00007175DC8E2420
00007175dc9cfb35  jmp 0x00007175DC9CF222
00007175dc9cfb3a  call 0x00007175DC8E2420
00007175dc9cfb3f  jmp 0x00007175DC9CF233
00007175dc9cfb44  call 0x00007175DC8E2420
00007175dc9cfb49  jmp 0x00007175DC9CF244
00007175dc9cfb4e  call 0x00007175DC8E2420
00007175dc9cfb53  jmp 0x00007175DC9CF255
00007175dc9cfb58  call 0x00007175DC8E2420
00007175dc9cfb5d  jmp 0x00007175DC9CF266
00007175dc9cfb62  call 0x00007175DC8E2420
00007175dc9cfb67  jmp 0x00007175DC9CF277
00007175dc9cfb6c  call 0x00007175DC8E2420
00007175dc9cfb71  jmp 0x00007175DC9CF288
00007175dc9cfb76  call 0x00007175DC8E2420
00007175dc9cfb7b  jmp 0x00007175DC9CF299
00007175dc9cfb80  call 0x00007175DC8E2420
00007175dc9cfb85  jmp 0x00007175DC9CF2AA
00007175dc9cfb8a  call 0x00007175DC8E2420
00007175dc9cfb8f  jmp 0x00007175DC9CF2BB
00007175dc9cfb94  call 0x00007175DC8E2420
00007175dc9cfb99  jmp 0x00007175DC9CF2CC
00007175dc9cfb9e  call 0x00007175DC8E2420
00007175dc9cfba3  jmp 0x00007175DC9CF2DD
00007175dc9cfba8  call 0x00007175DC8E2420
00007175dc9cfbad  jmp 0x00007175DC9CF2EE
00007175dc9cfbb2  call 0x00007175DC8E2420
00007175dc9cfbb7  jmp 0x00007175DC9CF2FF
00007175dc9cfbbc  call 0x00007175DC8E2420
00007175dc9cfbc1  jmp 0x00007175DC9CF310
00007175dc9cfbc6  call 0x00007175DC8E2420
00007175dc9cfbcb  jmp 0x00007175DC9CF321
00007175dc9cfbd0  call 0x00007175DC8E2420
00007175dc9cfbd5  jmp 0x00007175DC9CF332
00007175dc9cfbda  call 0x00007175DC8E2420
00007175dc9cfbdf  jmp 0x00007175DC9CF343
00007175dc9cfbe4  call 0x00007175DC8E2420
00007175dc9cfbe9  jmp 0x00007175DC9CF354
00007175dc9cfbee  call 0x00007175DC8E2420
00007175dc9cfbf3  jmp 0x00007175DC9CF365
00007175dc9cfbf8  call 0x00007175DC8E2420
00007175dc9cfbfd  jmp 0x00007175DC9CF376
00007175dc9cfc02  call 0x00007175DC8E2420
00007175dc9cfc07  jmp 0x00007175DC9CF387
00007175dc9cfc0c  call 0x00007175DC8E2420
00007175dc9cfc11  jmp 0x00007175DC9CF398
00007175dc9cfc16  call 0x00007175DC8E2420
00007175dc9cfc1b  jmp 0x00007175DC9CF3A9
00007175dc9cfc20  call 0x00007175DC8E2420
00007175dc9cfc25  jmp 0x00007175DC9CF3BA
00007175dc9cfc2a  call 0x00007175DC8E2420
00007175dc9cfc2f  jmp 0x00007175DC9CF3CB
00007175dc9cfc34  call 0x00007175DC8E2420
00007175dc9cfc39  jmp 0x00007175DC9CF3DC
00007175dc9cfc3e  call 0x00007175DC8E2420
00007175dc9cfc43  jmp 0x00007175DC9CF3ED
00007175dc9cfc48  call 0x00007175DC8E2420
00007175dc9cfc4d  jmp 0x00007175DC9CF3FE
00007175dc9cfc52  call 0x00007175DC8E2420
00007175dc9cfc57  jmp 0x00007175DC9CF40F
00007175dc9cfc5c  call 0x00007175DC8E2420
00007175dc9cfc61  jmp 0x00007175DC9CF420
00007175dc9cfc66  call 0x00007175DC8E2420
00007175dc9cfc6b  jmp 0x00007175DC9CF431
00007175dc9cfc70  call 0x00007175DC8E2420
00007175dc9cfc75  jmp 0x00007175DC9CF442
00007175dc9cfc7a  call 0x00007175DC8E2420
00007175dc9cfc7f  jmp 0x00007175DC9CF453
00007175dc9cfc84  call 0x00007175DC8E2420
00007175dc9cfc89  jmp 0x00007175DC9CF464
00007175dc9cfc8e  call 0x00007175DC8E2420
00007175dc9cfc93  jmp 0x00007175DC9CF475
00007175dc9cfc98  call 0x00007175DC8E2420
00007175dc9cfc9d  jmp 0x00007175DC9CF486
00007175dc9cfca2  call 0x00007175DC8E2420
00007175dc9cfca7  jmp 0x00007175DC9CF497
00007175dc9cfcac  call 0x00007175DC8E2420
00007175dc9cfcb1  jmp 0x00007175DC9CF4A8
00007175dc9cfcb6  call 0x00007175DC8E2420
00007175dc9cfcbb  jmp 0x00007175DC9CF4B9
00007175dc9cfcc0  call 0x00007175DC8E2420
00007175dc9cfcc5  jmp 0x00007175DC9CF4CA
00007175dc9cfcca  call 0x00007175DC8E2420
00007175dc9cfccf  jmp 0x00007175DC9CF4DB
00007175dc9cfcd4  call 0x00007175DC8E2420
00007175dc9cfcd9  jmp 0x00007175DC9CF4EC
00007175dc9cfcde  call 0x00007175DC8E2420
00007175dc9cfce3  jmp 0x00007175DC9CF4FD
00007175dc9cfce8  call 0x00007175DC8E2420
00007175dc9cfced  jmp 0x00007175DC9CF50E
00007175dc9cfcf2  call 0x00007175DC8E2420
00007175dc9cfcf7  jmp 0x00007175DC9CF51F
00007175dc9cfcfc  call 0x00007175DC8E2420
00007175dc9cfd01  jmp 0x00007175DC9CF530
00007175dc9cfd06  call 0x00007175DC8E2420
00007175dc9cfd0b  jmp 0x00007175DC9CF541
00007175dc9cfd10  call 0x00007175DC8E2420
00007175dc9cfd15  jmp 0x00007175DC9CF552
00007175dc9cfd1a  call 0x00007175DC8E2420
00007175dc9cfd1f  jmp 0x00007175DC9CF563
00007175dc9cfd24  call 0x00007175DC8E2420
00007175dc9cfd29  jmp 0x00007175DC9CF574
00007175dc9cfd2e  call 0x00007175DC8E2420
00007175dc9cfd33  jmp 0x00007175DC9CF585
00007175dc9cfd38  call 0x00007175DC8E2420
00007175dc9cfd3d  jmp 0x00007175DC9CF596
00007175dc9cfd42  call 0x00007175DC8E2420
00007175dc9cfd47  jmp 0x00007175DC9CF5AF
00007175dc9cfd4c  call 0x00007175DC8E2420
00007175dc9cfd51  jmp 0x00007175DC9CF5C8
00007175dc9cfd56  call 0x00007175DC8D5610
00007175dc9cfd5b  jmp 0x00007175DC9CF5E1
00007175dc9cfd60  call 0x00007175DC8DC580
00007175dc9cfd65  jmp 0x00007175DC9CF94E
00007175dc9cfd6a  call 0x00007175DC8E46C0
00007175dc9cfd6f  jmp 0x00007175DC9CF958
00007175dc9cfd74  call 0x00007175DC809E90
00007175dc9cfd79  jmp 0x00007175DC9CF95E
00007175dc9cfd7e  call 0x00007175DC8DB310
00007175dc9cfd83  jmp 0x00007175DC9CF968
00007175dc9cfd88  call 0x00007175DC80DAE0
00007175dc9cfd8d  jmp 0x00007175DC9CF96D
00007175dc9cfd92  call 0x00007175DC8C0230
00007175dc9cfd97  jmp 0x00007175DC9CF986
00007175dc9cfd9c  call 0x00007175DC8C0230
00007175dc9cfda1  jmp 0x00007175DC9CF99B
00007175dc9cfda6  call 0x00007175DC8BEFC0
00007175dc9cfdab  jmp 0x00007175DC9CF9A4
00007175dc9cfdb0  call 0x00007175DC8E2BA0
00007175dc9cfdb5  jmp 0x00007175DC9CFA6B
00007175dc9cfdba  int3
00007175dc9cfdbb  nop [rax+rax*1], eax
00007175dc9cfdc0  mov rax, [r15+0x48]
00007175dc9cfdc4  mov r14, [r15+0x58]
00007175dc9cfdc8  lea r12, [rax+r14*1]
00007175dc9cfdcc  mov [r15+0x68], r12
00007175dc9cfdd0  lea rax, [r14+0x04]
00007175dc9cfdd4  mov [r15+0x58], rax
00007175dc9cfdd8  lea r14, [r12+0x04]
00007175dc9cfddd  mov r11d, [r13+r14*1]
00007175dc9cfde2  mov [rsp+0x10], r11d
00007175dc9cfde7  mov r11d, r11d
00007175dc9cfdea  mov [r15+0x70], r11
00007175dc9cfdee  lea r14, [r12+0x38]
00007175dc9cfdf3  mov r11d, [r13+r14*1]
00007175dc9cfdf8  lea r14, [r12+0x24]
00007175dc9cfdfd  mov r10d, [r13+r14*1]
00007175dc9cfe02  mov [rsp+0x20], r10d
00007175dc9cfe07  mov r10d, r10d
00007175dc9cfe0a  mov [r15+0x90], r10
00007175dc9cfe11  mov [rsp+0x30], rax
00007175dc9cfe16  xor eax, eax
00007175dc9cfe18  mov r14, [rsp+0x30]
00007175dc9cfe1d  mov r10d, 0xC0
00007175dc9cfe23  cmp r14, r10
00007175dc9cfe26  cmc
00007175dc9cfe27  lahf
00007175dc9cfe28  seto al
00007175dc9cfe2b  mov [r15+0x108], eax
00007175dc9cfe32  mov eax, [rsp+0x10]
00007175dc9cfe36  mov r14d, [rsp+0x10]
00007175dc9cfe3b  shrd eax, r14d, 0x07
00007175dc9cfe40  mov [rsp+0x10], r11d
00007175dc9cfe45  mov r10d, [rsp+0x10]
00007175dc9cfe4a  shrd r11d, r10d, 0x11
00007175dc9cfe4f  mov r9d, [r15+0x60]
00007175dc9cfe53  mov r8d, [rsp+0x20]
00007175dc9cfe58  lea ebp, [r8d+r9d*1]
00007175dc9cfe5d  rorx r9d, r14d, 0x12
00007175dc9cfe63  xor eax, r9d
00007175dc9cfe66  rorx r9d, r10d, 0x13
00007175dc9cfe6c  xor r11d, r9d
00007175dc9cfe6f  mov [rsp+0x10], r11d
00007175dc9cfe74  mov r11d, r11d
00007175dc9cfe77  mov [r15+0x88], r11
00007175dc9cfe7e  mov [rsp+0x20], r14d
00007175dc9cfe83  shr r14d, 0x03
00007175dc9cfe87  xor eax, r14d
00007175dc9cfe8a  mov [rsp+0x30], eax
00007175dc9cfe8e  mov eax, eax
00007175dc9cfe90  mov [r15+0x80], rax
00007175dc9cfe97  shr r10d, 0x0A
00007175dc9cfe9b  mov eax, [rsp+0x10]
00007175dc9cfe9f  xor eax, r10d
00007175dc9cfea2  mov [rsp+0x10], eax
00007175dc9cfea6  mov eax, eax
00007175dc9cfea8  mov [r15+0x78], rax
00007175dc9cfeac  mov eax, [rsp+0x30]
00007175dc9cfeb0  lea r14d, [ebp+eax*1]
00007175dc9cfeb6  mov eax, [rsp+0x10]
00007175dc9cfeba  lea r11d, [r14d+eax*1]
00007175dc9cfebf  lea rax, [r12+0x40]
00007175dc9cfec4  mov [r13+rax*1], r11d
00007175dc9cfec9  mov eax, [rsp+0x20]
00007175dc9cfecd  mov eax, eax
00007175dc9cfecf  mov [r15+0x60], rax
00007175dc9cfed3  mov eax, [r15+0x108]
00007175dc9cfeda  sahf
00007175dc9cfedb  jnz 0x00007175DC9CFF0D
00007175dc9cfedd  cmp dword ptr [r15+0x318], 0x00
00007175dc9cfee5  jz 0x00007175DC9CFF70
00007175dc9cfeeb  nop [rax+rax*1], ax
00007175dc9cfef4  nop [rax+rax*1], eax
00007175dc9cfefc  mov eax, 0x410820
00007175dc9cff01  mov [r15+0x100], rax
00007175dc9cff08  jmp 0x00007175DC7FE110
00007175dc9cff0d  cmp dword ptr [r15+0x318], 0x00
00007175dc9cff15  jz 0x00007175DC9CFDC0
00007175dc9cff1b  nop [rax+rax*1], ax
00007175dc9cff24  nop [rax+rax*1], eax
00007175dc9cff2c  mov eax, 0x4107D8
00007175dc9cff31  mov [r15+0x100], rax
00007175dc9cff38  jmp 0x00007175DC7FE110
00007175dc9cff3d  int3
00007175dc9cff3e  call 0x00007175DC8E1430
00007175dc9cff43  jmp 0x00007175DC9CFDE2
00007175dc9cff48  call 0x00007175DC8E1430
00007175dc9cff4d  jmp 0x00007175DC9CFDF8
00007175dc9cff52  call 0x00007175DC8E01C0
00007175dc9cff57  jmp 0x00007175DC9CFE02
00007175dc9cff5c  call 0x00007175DC80A860
00007175dc9cff61  jmp 0x00007175DC9CFEC9
00007175dc9cff66  int3
00007175dc9cff67  nop [rax+rax*1], ax
00007175dc9cff70  mov rax, [r15]
00007175dc9cff73  mov r14d, [r13+rax*1]
00007175dc9cff78  lea r12, [rax+0x04]
00007175dc9cff7c  mov r11d, [r13+r12*1]
00007175dc9cff81  mov [rsp+0x10], r14d
00007175dc9cff86  mov r14d, r14d
00007175dc9cff89  mov [r15+0x78], r14
00007175dc9cff8d  mov [rsp+0x20], r11d
00007175dc9cff92  mov r11d, r11d
00007175dc9cff95  mov [r15+0x80], r11
00007175dc9cff9c  lea r14, [rax+0x08]
00007175dc9cffa0  mov r12d, [r13+r14*1]
00007175dc9cffa5  lea r14, [rax+0x0C]
00007175dc9cffa9  mov r11d, [r13+r14*1]
00007175dc9cffae  mov [rsp+0x30], r12d
00007175dc9cffb3  mov r12d, r12d
00007175dc9cffb6  mov [r15+0x70], r12
00007175dc9cffba  mov [rsp+0x40], r11d
00007175dc9cffbf  mov r11d, r11d
00007175dc9cffc2  mov [r15+0x68], r11
00007175dc9cffc6  lea r14, [rax+0x18]
00007175dc9cffca  mov r12d, [r13+r14*1]
00007175dc9cffcf  lea r14, [rax+0x1C]
00007175dc9cffd3  mov r11d, [r13+r14*1]
00007175dc9cffd8  mov [rsp+0x50], r12d
00007175dc9cffdd  mov r12d, r12d
00007175dc9cffe0  mov [r15+0x58], r12
00007175dc9cffe4  mov [rsp+0x60], r11d
00007175dc9cffe9  mov r11d, r11d
00007175dc9cffec  mov [r15+0x60], r11
00007175dc9cfff0  lea r14, [rax+0x10]
00007175dc9cfff4  mov r12d, [r13+r14*1]
00007175dc9cfff9  lea r14, [rax+0x14]
00007175dc9cfffd  mov eax, [r13+r14*1]
00007175dc9d0002  mov [rsp+0x70], r12d
00007175dc9d0007  mov r12d, r12d
00007175dc9d000a  mov [r15+0x18], r12
00007175dc9d000e  mov [rsp+0x80], eax
00007175dc9d0015  mov eax, eax
00007175dc9d0017  mov [r15+0x90], rax
00007175dc9d001e  mov eax, [rsp+0x70]
00007175dc9d0022  mov eax, eax
00007175dc9d0024  mov [r15+0x30], rax
00007175dc9d0028  mov eax, [rsp+0x50]
00007175dc9d002c  mov eax, eax
00007175dc9d002e  mov [r15+0xA0], rax
00007175dc9d0035  mov eax, [rsp+0x30]
00007175dc9d0039  mov eax, eax
00007175dc9d003b  mov [r15+0x28], rax
00007175dc9d003f  mov eax, [rsp+0x20]
00007175dc9d0043  mov eax, eax
00007175dc9d0045  mov [r15+0x98], rax
00007175dc9d004c  mov eax, [rsp+0x10]
00007175dc9d0050  mov eax, eax
00007175dc9d0052  mov [r15+0x38], rax
00007175dc9d0056  mov eax, [rsp+0x70]
00007175dc9d005a  mov r14d, [rsp+0x70]
00007175dc9d005f  shrd eax, r14d, 0x06
00007175dc9d0064  mov [rsp+0x70], r14d
00007175dc9d0069  mov r12d, [rsp+0x80]
00007175dc9d0071  and r14d, r12d
00007175dc9d0074  mov r11d, [rsp+0x10]
00007175dc9d0079  mov r10d, [rsp+0x10]
00007175dc9d007e  shrd r11d, r10d, 0x02
00007175dc9d0083  mov [rsp+0x10], r12d
00007175dc9d0088  mov r12d, r12d
00007175dc9d008b  mov [r15+0x20], r12
00007175dc9d008f  mov r12, [r15+0x50]
00007175dc9d0093  mov r9d, [r13+r12*1]
00007175dc9d0098  mov r12d, [rsp+0x50]
00007175dc9d009d  mov r8d, [rsp+0x70]
00007175dc9d00a2  andn ebp, r8d, r12d
00007175dc9d00a7  mov edi, [rsp+0x60]
00007175dc9d00ab  lea esi, [r14d+edi*1]
00007175dc9d00b0  rorx r14d, r8d, 0x0B
00007175dc9d00b6  xor eax, r14d
00007175dc9d00b9  rorx r14d, r10d, 0x0D
00007175dc9d00bf  xor r11d, r14d
00007175dc9d00c2  lea edi, [esi+ebp*1]
00007175dc9d00c6  mov r14, [r15+0x48]
00007175dc9d00ca  mov ebp, [r13+r14*1]
00007175dc9d00cf  mov r14d, [rsp+0x30]
00007175dc9d00d4  mov esi, [rsp+0x20]
00007175dc9d00d8  and r14d, esi
00007175dc9d00db  mov [rsp+0x20], r14d
00007175dc9d00e0  mov r14d, r14d
00007175dc9d00e3  mov [r15+0xD8], r14
00007175dc9d00ea  lea r14d, [edi+r9d*1]
00007175dc9d00ef  mov r9d, [rsp+0x30]
00007175dc9d00f4  xor r9d, esi
00007175dc9d00f7  rorx edi, r8d, 0x19
00007175dc9d00fd  xor eax, edi
00007175dc9d00ff  and r9d, r10d
00007175dc9d0102  rorx edi, r10d, 0x16
00007175dc9d0108  xor r11d, edi
00007175dc9d010b  mov [rsp+0x30], r11d
00007175dc9d0110  mov r11d, r11d
00007175dc9d0113  mov [r15+0xD0], r11
00007175dc9d011a  lea r11d, [r14d+ebp*1]
00007175dc9d011f  mov r10d, [rsp+0x20]
00007175dc9d0124  xor r9d, r10d
00007175dc9d0127  lea r14d, [r11d+eax*1]
00007175dc9d012c  mov qword ptr [r15+0x88], 0x04
00007175dc9d0137  mov eax, [rsp+0x30]
00007175dc9d013b  lea r11d, [r9d+eax*1]
00007175dc9d0140  mov eax, [rsp+0x40]
00007175dc9d0144  lea r10d, [r14d+eax*1]
00007175dc9d0149  mov r10d, r10d
00007175dc9d014c  mov [r15+0xB8], r10
00007175dc9d0153  xor eax, eax
00007175dc9d0155  mov r10d, 0x04
00007175dc9d015b  mov r9d, 0x100
00007175dc9d0161  cmp r10, r9
00007175dc9d0164  cmc
00007175dc9d0165  lahf
00007175dc9d0166  seto al
00007175dc9d0169  mov [r15+0x108], eax
00007175dc9d0170  lea eax, [r11d+r14d*1]
00007175dc9d0175  mov eax, eax
00007175dc9d0177  mov [r15+0xA8], rax
00007175dc9d017e  mov r12d, r12d
00007175dc9d0181  mov [r15+0xB0], r12
00007175dc9d0188  mov eax, [rsp+0x10]
00007175dc9d018c  mov eax, eax
00007175dc9d018e  mov [r15+0xC0], rax
00007175dc9d0195  mov r8d, r8d
00007175dc9d0198  mov [r15+0xC8], r8
00007175dc9d019f  mov eax, [r15+0x108]
00007175dc9d01a6  sahf
00007175dc9d01a7  jnz 0x00007175DC9D01D9
00007175dc9d01a9  cmp dword ptr [r15+0x318], 0x00
00007175dc9d01b1  jz 0x00007175DC9D04A0
00007175dc9d01b7  nop [rax+rax*1], ax
00007175dc9d01c0  nop [rax+rax*1], eax
00007175dc9d01c8  mov eax, 0x4108E0
00007175dc9d01cd  mov [r15+0x100], rax
00007175dc9d01d4  jmp 0x00007175DC7FE110
00007175dc9d01d9  cmp dword ptr [r15+0x318], 0x00
00007175dc9d01e1  jz 0x00007175DC9D0270
00007175dc9d01e7  nop [rax+rax*1], ax
00007175dc9d01f0  nop [rax+rax*1], eax
00007175dc9d01f8  mov eax, 0x410854
00007175dc9d01fd  mov [r15+0x100], rax
00007175dc9d0204  jmp 0x00007175DC7FE110
00007175dc9d0209  int3
00007175dc9d020a  call 0x00007175DC80DAE0
00007175dc9d020f  jmp 0x00007175DC9CFF78
00007175dc9d0214  call 0x00007175DC8C0230
00007175dc9d0219  jmp 0x00007175DC9CFF81
00007175dc9d021e  call 0x00007175DC8E26A0
00007175dc9d0223  jmp 0x00007175DC9CFFA5
00007175dc9d0228  call 0x00007175DC8E1430
00007175dc9d022d  jmp 0x00007175DC9CFFAE
00007175dc9d0232  call 0x00007175DC8E26A0
00007175dc9d0237  jmp 0x00007175DC9CFFCF
00007175dc9d023c  call 0x00007175DC8E1430
00007175dc9d0241  jmp 0x00007175DC9CFFD8
00007175dc9d0246  call 0x00007175DC8E26A0
00007175dc9d024b  jmp 0x00007175DC9CFFF9
00007175dc9d0250  call 0x00007175DC8D5890
00007175dc9d0255  jmp 0x00007175DC9D0002
00007175dc9d025a  call 0x00007175DC8BDD50
00007175dc9d025f  jmp 0x00007175DC9D0098
00007175dc9d0264  call 0x00007175DC8DA580
00007175dc9d0269  jmp 0x00007175DC9D00CF
00007175dc9d026e  int3
00007175dc9d026f  nop
00007175dc9d0270  mov eax, [r15+0xB8]
00007175dc9d0277  mov [rsp+0x10], eax
00007175dc9d027b  mov eax, eax
00007175dc9d027d  mov [r15+0x30], rax
00007175dc9d0281  mov eax, [r15+0xC0]
00007175dc9d0288  mov [rsp+0x20], eax
00007175dc9d028c  mov eax, eax
00007175dc9d028e  mov [r15+0xA0], rax
00007175dc9d0295  mov eax, [r15+0x28]
00007175dc9d0299  mov r14d, [r15+0x98]
00007175dc9d02a0  mov [rsp+0x30], r14d
00007175dc9d02a5  mov r14d, r14d
00007175dc9d02a8  mov [r15+0x28], r14
00007175dc9d02ac  mov r14d, [r15+0x38]
00007175dc9d02b0  mov [rsp+0x40], r14d
00007175dc9d02b5  mov r14d, r14d
00007175dc9d02b8  mov [r15+0x98], r14
00007175dc9d02bf  mov r14d, [r15+0xA8]
00007175dc9d02c6  mov [rsp+0x50], r14d
00007175dc9d02cb  mov r14d, r14d
00007175dc9d02ce  mov [r15+0x38], r14
00007175dc9d02d2  mov r14d, [rsp+0x10]
00007175dc9d02d7  mov r12d, [rsp+0x10]
00007175dc9d02dc  shrd r14d, r12d, 0x06
00007175dc9d02e1  mov r11d, [r15+0xC8]
00007175dc9d02e8  mov [rsp+0x10], r12d
00007175dc9d02ed  and r12d, r11d
00007175dc9d02f0  mov r10d, [rsp+0x50]
00007175dc9d02f5  mov r9d, [rsp+0x50]
00007175dc9d02fa  shrd r10d, r9d, 0x02
00007175dc9d02ff  mov [rsp+0x50], r11d
00007175dc9d0304  mov r11d, r11d
00007175dc9d0307  mov [r15+0x20], r11
00007175dc9d030b  mov r11, [r15+0x88]
00007175dc9d0312  mov r8, [r15+0x50]
00007175dc9d0316  lea rbp, [r8+r11*1]
00007175dc9d031a  mov r8d, [r13+rbp*1]
00007175dc9d031f  mov ebp, [rsp+0x20]
00007175dc9d0323  mov edi, [rsp+0x10]
00007175dc9d0327  andn esi, edi, ebp
00007175dc9d032c  mov edx, [r15+0xB0]
00007175dc9d0333  lea ecx, [r12d+edx*1]
00007175dc9d0338  rorx r12d, edi, 0x0B
00007175dc9d033e  xor r14d, r12d
00007175dc9d0341  rorx r12d, r9d, 0x0D
00007175dc9d0347  xor r10d, r12d
00007175dc9d034a  lea r12d, [ecx+esi*1]
00007175dc9d034f  mov rsi, [r15+0x48]
00007175dc9d0353  lea rdx, [rsi+r11*1]
00007175dc9d0357  mov esi, [r13+rdx*1]
00007175dc9d035c  mov edx, [rsp+0x30]
00007175dc9d0360  mov ecx, [rsp+0x40]
00007175dc9d0364  and edx, ecx
00007175dc9d0366  mov [rsp+0x10], edx
00007175dc9d036a  mov edx, edx
00007175dc9d036c  mov [r15+0xD8], rdx
00007175dc9d0373  lea edx, [r12d+r8d*1]
00007175dc9d0378  mov r12d, [rsp+0x30]
00007175dc9d037d  xor r12d, ecx
00007175dc9d0380  rorx r8d, edi, 0x19
00007175dc9d0386  xor r14d, r8d
00007175dc9d0389  and r12d, r9d
00007175dc9d038c  rorx r8d, r9d, 0x16
00007175dc9d0392  xor r10d, r8d
00007175dc9d0395  mov [rsp+0x20], r10d
00007175dc9d039a  mov r10d, r10d
00007175dc9d039d  mov [r15+0xD0], r10
00007175dc9d03a4  lea r10d, [edx+esi*1]
00007175dc9d03a9  mov r9d, [rsp+0x10]
00007175dc9d03ae  xor r12d, r9d
00007175dc9d03b1  lea r9d, [r10d+r14d*1]
00007175dc9d03b6  lea r14, [r11+0x04]
00007175dc9d03ba  mov [r15+0x88], r14
00007175dc9d03c1  mov r11d, [rsp+0x20]
00007175dc9d03c6  lea r10d, [r12d+r11d*1]
00007175dc9d03cb  lea r11d, [r9d+eax*1]
00007175dc9d03d0  mov r11d, r11d
00007175dc9d03d3  mov [r15+0xB8], r11
00007175dc9d03da  xor eax, eax
00007175dc9d03dc  mov r12d, 0x100
00007175dc9d03e2  cmp r14, r12
00007175dc9d03e5  cmc
00007175dc9d03e6  lahf
00007175dc9d03e7  seto al
00007175dc9d03ea  mov [r15+0x108], eax
00007175dc9d03f1  lea eax, [r10d+r9d*1]
00007175dc9d03f6  mov eax, eax
00007175dc9d03f8  mov [r15+0xA8], rax
00007175dc9d03ff  mov ebp, ebp
00007175dc9d0401  mov [r15+0xB0], rbp
00007175dc9d0408  mov eax, [rsp+0x50]
00007175dc9d040c  mov eax, eax
00007175dc9d040e  mov [r15+0xC0], rax
00007175dc9d0415  mov edi, edi
00007175dc9d0417  mov [r15+0xC8], rdi
00007175dc9d041e  mov eax, [r15+0x108]
00007175dc9d0425  sahf
00007175dc9d0426  jnz 0x00007175DC9D0458
00007175dc9d0428  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0430  jz 0x00007175DC9D04A0
00007175dc9d0436  nop [rax+rax*1], ax
00007175dc9d043f  nop [rax+rax*1], eax
00007175dc9d0447  mov eax, 0x4108E0
00007175dc9d044c  mov [r15+0x100], rax
00007175dc9d0453  jmp 0x00007175DC7FE110
00007175dc9d0458  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0460  jz 0x00007175DC9D0270
00007175dc9d0466  nop [rax+rax*1], ax
00007175dc9d046f  nop [rax+rax*1], eax
00007175dc9d0477  mov eax, 0x410854
00007175dc9d047c  mov [r15+0x100], rax
00007175dc9d0483  jmp 0x00007175DC7FE110
00007175dc9d0488  int3
00007175dc9d0489  call 0x00007175DC849010
00007175dc9d048e  jmp 0x00007175DC9D031F
00007175dc9d0493  call 0x00007175DC825930
00007175dc9d0498  jmp 0x00007175DC9D035C
00007175dc9d049d  int3
00007175dc9d049e  nop
00007175dc9d04a0  mov eax, [r15+0x98]
00007175dc9d04a7  mov r14d, [r15+0x70]
00007175dc9d04ab  lea r12d, [eax+r14d*1]
00007175dc9d04b0  mov eax, [r15+0x28]
00007175dc9d04b4  mov r14d, [r15+0x68]
00007175dc9d04b8  lea r11d, [eax+r14d*1]
00007175dc9d04bd  mov qword ptr [r15+0x88], 0x00
00007175dc9d04c8  mov eax, [r15+0xA8]
00007175dc9d04cf  mov r14d, [r15+0x78]
00007175dc9d04d3  lea r10d, [eax+r14d*1]
00007175dc9d04d8  mov [rsp+0x10], r10d
00007175dc9d04dd  mov r10d, r10d
00007175dc9d04e0  mov [r15+0x78], r10
00007175dc9d04e4  mov eax, [r15+0x38]
00007175dc9d04e8  mov r14d, [r15+0x80]
00007175dc9d04ef  lea r10d, [eax+r14d*1]
00007175dc9d04f4  mov [rsp+0x20], r10d
00007175dc9d04f9  mov r10d, r10d
00007175dc9d04fc  mov [r15+0x80], r10
00007175dc9d0503  mov rax, [r15]
00007175dc9d0506  lea r14, [rax+0x08]
00007175dc9d050a  mov [r13+r14*1], r12d
00007175dc9d050f  lea r14, [rax+0x0C]
00007175dc9d0513  mov [r13+r14*1], r11d
00007175dc9d0518  mov r14d, [r15+0xB8]
00007175dc9d051f  mov r12d, [r15+0x18]
00007175dc9d0523  lea r11d, [r14d+r12d*1]
00007175dc9d0528  mov [rsp+0x30], r11d
00007175dc9d052d  mov r11d, r11d
00007175dc9d0530  mov [r15+0x68], r11
00007175dc9d0534  mov r14d, [r15+0x30]
00007175dc9d0538  mov r12d, [r15+0x90]
00007175dc9d053f  lea r11d, [r14d+r12d*1]
00007175dc9d0544  mov [rsp+0x40], r11d
00007175dc9d0549  mov r11d, r11d
00007175dc9d054c  mov [r15+0x70], r11
00007175dc9d0550  mov r14d, [r15+0x20]
00007175dc9d0554  mov r12d, [r15+0x58]
00007175dc9d0558  lea r11d, [r14d+r12d*1]
00007175dc9d055d  mov [rsp+0x50], r11d
00007175dc9d0562  mov r11d, r11d
00007175dc9d0565  mov [r15+0x58], r11
00007175dc9d0569  mov r14d, [r15+0xA0]
00007175dc9d0570  mov r12d, [r15+0x60]
00007175dc9d0574  lea r11d, [r14d+r12d*1]
00007175dc9d0579  mov [rsp+0x60], r11d
00007175dc9d057e  mov r11d, r11d
00007175dc9d0581  mov [r15+0x60], r11
00007175dc9d0585  mov r14d, [rsp+0x10]
00007175dc9d058a  mov [r13+rax*1], r14d
00007175dc9d058f  lea r14, [rax+0x04]
00007175dc9d0593  mov r12d, [rsp+0x20]
00007175dc9d0598  mov [r13+r14*1], r12d
00007175dc9d059d  lea r14, [rax+0x10]
00007175dc9d05a1  mov r12d, [rsp+0x30]
00007175dc9d05a6  mov [r13+r14*1], r12d
00007175dc9d05ab  lea r14, [rax+0x14]
00007175dc9d05af  mov r12d, [rsp+0x40]
00007175dc9d05b4  mov [r13+r14*1], r12d
00007175dc9d05b9  lea r14, [rax+0x18]
00007175dc9d05bd  mov r12d, [rsp+0x50]
00007175dc9d05c2  mov [r13+r14*1], r12d
00007175dc9d05c7  lea r14, [rax+0x1C]
00007175dc9d05cb  mov r12d, [rsp+0x60]
00007175dc9d05d0  mov [r13+r14*1], r12d
00007175dc9d05d5  lea r14, [rax+0x68]
00007175dc9d05d9  xor eax, eax
00007175dc9d05db  mov [r13+r14*1], rax
00007175dc9d05e0  cmp dword ptr [r15+0x318], 0x00
00007175dc9d05e8  jz 0x00007175DC9CF0E0
00007175dc9d05ee  nop [rax+rax*1], ax
00007175dc9d05f7  nop [rax+rax*1], eax
00007175dc9d05ff  mov eax, 0x4106FC
00007175dc9d0604  mov [r15+0x100], rax
00007175dc9d060b  jmp 0x00007175DC7FE110
00007175dc9d0610  int3
00007175dc9d0611  call 0x00007175DC8E2BA0
00007175dc9d0616  jmp 0x00007175DC9D050F
00007175dc9d061b  call 0x00007175DC8E1920
00007175dc9d0620  jmp 0x00007175DC9D0518
00007175dc9d0625  call 0x00007175DC80DFE0
00007175dc9d062a  jmp 0x00007175DC9D058F
00007175dc9d062f  call 0x00007175DC8E2BA0
00007175dc9d0634  jmp 0x00007175DC9D059D
00007175dc9d0639  call 0x00007175DC8E2BA0
00007175dc9d063e  jmp 0x00007175DC9D05AB
00007175dc9d0643  call 0x00007175DC8E2BA0
00007175dc9d0648  jmp 0x00007175DC9D05B9
00007175dc9d064d  call 0x00007175DC8E2BA0
00007175dc9d0652  jmp 0x00007175DC9D05C7
00007175dc9d0657  call 0x00007175DC8E2BA0
00007175dc9d065c  jmp 0x00007175DC9D05D5
00007175dc9d0661  call 0x00007175DC8D5EB0
00007175dc9d0666  jmp 0x00007175DC9D05E0
00007175dc9d066b  int3
00007175dc9d066c  nop [rax], eax
00007175dc9d0670  mov rax, [r15+0xF8]
00007175dc9d0677  lea r14, [rax+0x140]
00007175dc9d067e  mov r12, [r13+r14*1]
00007175dc9d0683  lea r14, [rax+0x148]
00007175dc9d068a  mov r11, [r13+r14*1]
00007175dc9d068f  mov [r15+0xA0], r12
00007175dc9d0696  mov [r15+0x98], r11
00007175dc9d069d  lea r14, [rax+0x130]
00007175dc9d06a4  mov r12, [r13+r14*1]
00007175dc9d06a9  lea r14, [rax+0x138]
00007175dc9d06b0  mov r11, [r13+r14*1]
00007175dc9d06b5  mov [r15+0xB0], r12
00007175dc9d06bc  mov [r15+0xA8], r11
00007175dc9d06c3  lea r14, [rax+0x120]
00007175dc9d06ca  mov r12, [r13+r14*1]
00007175dc9d06cf  lea r14, [rax+0x128]
00007175dc9d06d6  mov r11, [r13+r14*1]
00007175dc9d06db  mov [r15+0xC0], r12
00007175dc9d06e2  mov [r15+0xB8], r11
00007175dc9d06e9  lea r14, [rax+0x110]
00007175dc9d06f0  mov r12, [r13+r14*1]
00007175dc9d06f5  lea r14, [rax+0x118]
00007175dc9d06fc  mov r11, [r13+r14*1]
00007175dc9d0701  mov [r15+0xD0], r12
00007175dc9d0708  mov [r15+0xC8], r11
00007175dc9d070f  lea r14, [rax+0x100]
00007175dc9d0716  mov r12, [r13+r14*1]
00007175dc9d071b  lea r14, [rax+0x108]
00007175dc9d0722  mov r11, [r13+r14*1]
00007175dc9d0727  mov [r15+0xE8], r12
00007175dc9d072e  mov [r15+0xD8], r11
00007175dc9d0735  lea r14, [rax+0x150]
00007175dc9d073c  mov [r15+0xF8], r14
00007175dc9d0743  mov rax, [r15+0xF0]
00007175dc9d074a  mov [r15+0x100], rax
00007175dc9d0751  jmp 0x00007175DC9CE5C0
00007175dc9d0756  int3
00007175dc9d0757  call 0x00007175DC8E27E0
00007175dc9d075c  jmp 0x00007175DC9D0683
00007175dc9d0761  call 0x00007175DC8E1570
00007175dc9d0766  jmp 0x00007175DC9D068F
00007175dc9d076b  call 0x00007175DC8E27E0
00007175dc9d0770  jmp 0x00007175DC9D06A9
00007175dc9d0775  call 0x00007175DC8E1570
00007175dc9d077a  jmp 0x00007175DC9D06B5
00007175dc9d077f  call 0x00007175DC8E27E0
00007175dc9d0784  jmp 0x00007175DC9D06CF
00007175dc9d0789  call 0x00007175DC8E1570
00007175dc9d078e  jmp 0x00007175DC9D06DB
00007175dc9d0793  call 0x00007175DC8E27E0
00007175dc9d0798  jmp 0x00007175DC9D06F5
00007175dc9d079d  call 0x00007175DC8E1570
00007175dc9d07a2  jmp 0x00007175DC9D0701
00007175dc9d07a7  call 0x00007175DC8E27E0
00007175dc9d07ac  jmp 0x00007175DC9D071B
00007175dc9d07b1  call 0x00007175DC8E1570
00007175dc9d07b6  jmp 0x00007175DC9D0727
00007175dc9d07bb  int3
00007175dc9d07bc  nop [rax], eax
00007175dc9d07c0  mov eax, [r15+0xA0]
00007175dc9d07c7  mov [rsp+0x10], eax
00007175dc9d07cb  xor eax, eax
00007175dc9d07cd  mov r14d, [rsp+0x10]
00007175dc9d07d2  sub r14d, 0x01
00007175dc9d07d6  cmc
00007175dc9d07d7  lahf
00007175dc9d07d8  seto al
00007175dc9d07db  mov [r15+0x108], eax
00007175dc9d07e2  mov r14d, r14d
00007175dc9d07e5  mov [r15+0xA0], r14
00007175dc9d07ec  mov eax, [r15+0x108]
00007175dc9d07f3  sahf
00007175dc9d07f4  jnz 0x00007175DC9D0826
00007175dc9d07f6  cmp dword ptr [r15+0x318], 0x00
00007175dc9d07fe  jz 0x00007175DC9D0900
00007175dc9d0804  nop [rax+rax*1], ax
00007175dc9d080d  nop [rax+rax*1], eax
00007175dc9d0815  mov eax, 0x41028C
00007175dc9d081a  mov [r15+0x100], rax
00007175dc9d0821  jmp 0x00007175DC7FE110
00007175dc9d0826  cmp dword ptr [r15+0x318], 0x00
00007175dc9d082e  jz 0x00007175DC9D0860
00007175dc9d0834  nop [rax+rax*1], ax
00007175dc9d083d  nop [rax+rax*1], eax
00007175dc9d0845  mov eax, 0x410274
00007175dc9d084a  mov [r15+0x100], rax
00007175dc9d0851  jmp 0x00007175DC7FE110
00007175dc9d0856  int3
00007175dc9d0857  int3
00007175dc9d0858  nop [rax+rax*1], eax
00007175dc9d0860  mov rax, [r15+0xF8]
00007175dc9d0867  lea r14, [rax+0xD0]
00007175dc9d086e  mov [r15], r14
00007175dc9d0871  mov rax, [r15+0x98]
00007175dc9d0878  mov [r15+0x08], rax
00007175dc9d087c  mov qword ptr [r15+0x10], 0x12C
00007175dc9d0884  mov qword ptr [r15+0xF0], 0x410284
00007175dc9d088f  mov r14d, [r15+0x320]
00007175dc9d0896  mov eax, 0x410284
00007175dc9d089b  mov rcx, 0x7175DC9D07C0
00007175dc9d08a5  mov [r15+r14*8+0x328], rax
00007175dc9d08ad  mov [r15+r14*8+0x368], rcx
00007175dc9d08b5  add r14d, 0x01
00007175dc9d08b9  and r14d, 0x07
00007175dc9d08bd  mov [r15+0x320], r14d
00007175dc9d08c4  cmp dword ptr [r15+0x318], 0x00
00007175dc9d08cc  jz 0x00007175DC9CED70
00007175dc9d08d2  nop [rax+rax*1], ax
00007175dc9d08db  nop [rax+rax*1], eax
00007175dc9d08e3  mov eax, 0x4106BC
00007175dc9d08e8  mov [r15+0x100], rax
00007175dc9d08ef  jmp 0x00007175DC7FE110
00007175dc9d08f4  int3
00007175dc9d08f5  int3
00007175dc9d08f6  nop [rax+rax*1], ax
00007175dc9d08ff  nop
00007175dc9d0900  mov rax, [r15+0xF8]
00007175dc9d0907  lea r14, [rax+0xF0]
00007175dc9d090e  mov r12, [r13+r14*1]
00007175dc9d0913  mov [r15+0x98], r12
00007175dc9d091a  mov qword ptr [r15+0x40], 0x80
00007175dc9d0922  lea r14, [rax+0xD0]
00007175dc9d0929  mov [r15], r14
00007175dc9d092c  lea r14, [rax+0x14C]
00007175dc9d0933  mov [r15+0x08], r14
00007175dc9d0937  mov qword ptr [r15+0x10], 0x01
00007175dc9d093f  lea r14, [rax+0x14C]
00007175dc9d0946  mov eax, 0x80
00007175dc9d094b  mov [r13+r14*1], al
00007175dc9d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007175dc9d095b  mov r14d, [r15+0x320]
00007175dc9d0962  mov eax, 0x4102A8
00007175dc9d0967  mov rcx, 0x7175DC9D09E0
00007175dc9d0971  mov [r15+r14*8+0x328], rax
00007175dc9d0979  mov [r15+r14*8+0x368], rcx
00007175dc9d0981  add r14d, 0x01
00007175dc9d0985  and r14d, 0x07
00007175dc9d0989  mov [r15+0x320], r14d
00007175dc9d0990  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0998  jz 0x00007175DC9CED70
00007175dc9d099e  nop [rax+rax*1], ax
00007175dc9d09a7  nop [rax+rax*1], eax
00007175dc9d09af  mov eax, 0x4106BC
00007175dc9d09b4  mov [r15+0x100], rax
00007175dc9d09bb  jmp 0x00007175DC7FE110
00007175dc9d09c0  int3
00007175dc9d09c1  call 0x00007175DC8E27E0
00007175dc9d09c6  jmp 0x00007175DC9D0913
00007175dc9d09cb  call 0x00007175DC8D5AF0
00007175dc9d09d0  jmp 0x00007175DC9D0950
00007175dc9d09d5  int3
00007175dc9d09d6  nop [rax+rax*1], ax
00007175dc9d09df  nop
00007175dc9d09e0  mov rax, [r15+0xF8]
00007175dc9d09e7  lea r14, [rax+0x138]
00007175dc9d09ee  mov r12, [r13+r14*1]
00007175dc9d09f3  mov [r15+0x40], r12
00007175dc9d09f7  lea r14, [rax+0x148]
00007175dc9d09fe  xor eax, eax
00007175dc9d0a00  mov [r13+r14*1], al
00007175dc9d0a05  xor eax, eax
00007175dc9d0a07  mov r14d, 0x38
00007175dc9d0a0d  cmp r12, r14
00007175dc9d0a10  cmc
00007175dc9d0a11  lahf
00007175dc9d0a12  seto al
00007175dc9d0a15  mov [r15+0x108], eax
00007175dc9d0a1c  mov eax, [r15+0x108]
00007175dc9d0a23  sahf
00007175dc9d0a24  jz 0x00007175DC9D0A56
00007175dc9d0a26  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0a2e  jz 0x00007175DC9D0AA0
00007175dc9d0a34  nop [rax+rax*1], ax
00007175dc9d0a3d  nop [rax+rax*1], eax
00007175dc9d0a45  mov eax, 0x4102B8
00007175dc9d0a4a  mov [r15+0x100], rax
00007175dc9d0a51  jmp 0x00007175DC7FE110
00007175dc9d0a56  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0a5e  jz 0x00007175DC9D0BF0
00007175dc9d0a64  nop [rax+rax*1], ax
00007175dc9d0a6d  nop [rax+rax*1], eax
00007175dc9d0a75  mov eax, 0x4102D4
00007175dc9d0a7a  mov [r15+0x100], rax
00007175dc9d0a81  jmp 0x00007175DC7FE110
00007175dc9d0a86  int3
00007175dc9d0a87  call 0x00007175DC8E27E0
00007175dc9d0a8c  jmp 0x00007175DC9D09F3
00007175dc9d0a91  call 0x00007175DC8D5AF0
00007175dc9d0a96  jmp 0x00007175DC9D0A05
00007175dc9d0a9b  int3
00007175dc9d0a9c  nop [rax], eax
00007175dc9d0aa0  mov rax, [r15+0xF8]
00007175dc9d0aa7  lea r14, [rax+0xD0]
00007175dc9d0aae  mov [r15], r14
00007175dc9d0ab1  lea r14, [rax+0x148]
00007175dc9d0ab8  mov [r15+0x08], r14
00007175dc9d0abc  mov qword ptr [r15+0x10], 0x01
00007175dc9d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007175dc9d0acf  mov r14d, [r15+0x320]
00007175dc9d0ad6  mov eax, 0x4102C8
00007175dc9d0adb  mov rcx, 0x7175DC9D0B40
00007175dc9d0ae5  mov [r15+r14*8+0x328], rax
00007175dc9d0aed  mov [r15+r14*8+0x368], rcx
00007175dc9d0af5  add r14d, 0x01
00007175dc9d0af9  and r14d, 0x07
00007175dc9d0afd  mov [r15+0x320], r14d
00007175dc9d0b04  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0b0c  jz 0x00007175DC9CED70
00007175dc9d0b12  nop [rax+rax*1], ax
00007175dc9d0b1b  nop [rax+rax*1], eax
00007175dc9d0b23  mov eax, 0x4106BC
00007175dc9d0b28  mov [r15+0x100], rax
00007175dc9d0b2f  jmp 0x00007175DC7FE110
00007175dc9d0b34  int3
00007175dc9d0b35  int3
00007175dc9d0b36  nop [rax+rax*1], ax
00007175dc9d0b3f  nop
00007175dc9d0b40  mov rax, [r15+0xF8]
00007175dc9d0b47  lea r14, [rax+0x138]
00007175dc9d0b4e  mov rax, [r13+r14*1]
00007175dc9d0b53  mov [r15+0x40], rax
00007175dc9d0b57  mov [rsp+0x10], rax
00007175dc9d0b5c  xor eax, eax
00007175dc9d0b5e  mov r14, [rsp+0x10]
00007175dc9d0b63  mov r12d, 0x38
00007175dc9d0b69  cmp r14, r12
00007175dc9d0b6c  cmc
00007175dc9d0b6d  lahf
00007175dc9d0b6e  seto al
00007175dc9d0b71  mov [r15+0x108], eax
00007175dc9d0b78  mov eax, [r15+0x108]
00007175dc9d0b7f  sahf
00007175dc9d0b80  jnz 0x00007175DC9D0BB2
00007175dc9d0b82  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0b8a  jz 0x00007175DC9D0BF0
00007175dc9d0b90  nop [rax+rax*1], ax
00007175dc9d0b99  nop [rax+rax*1], eax
00007175dc9d0ba1  mov eax, 0x4102D4
00007175dc9d0ba6  mov [r15+0x100], rax
00007175dc9d0bad  jmp 0x00007175DC7FE110
00007175dc9d0bb2  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0bba  jz 0x00007175DC9D0AA0
00007175dc9d0bc0  nop [rax+rax*1], ax
00007175dc9d0bc9  nop [rax+rax*1], eax
00007175dc9d0bd1  mov eax, 0x4102B8
00007175dc9d0bd6  mov [r15+0x100], rax
00007175dc9d0bdd  jmp 0x00007175DC7FE110
00007175dc9d0be2  int3
00007175dc9d0be3  call 0x00007175DC8D59C0
00007175dc9d0be8  jmp 0x00007175DC9D0B53
00007175dc9d0bed  int3
00007175dc9d0bee  nop
00007175dc9d0bf0  mov rax, [r15+0x98]
00007175dc9d0bf7  rorx r14, rax, 0x3D
00007175dc9d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007175dc9d0c01  mov rax, [r15+0xF8]
00007175dc9d0c08  lea r12, [rax+0xD0]
00007175dc9d0c0f  mov [r15], r12
00007175dc9d0c12  lea r12, [rax+0x140]
00007175dc9d0c19  mov [r15+0x08], r12
00007175dc9d0c1d  mov qword ptr [r15+0x10], 0x08
00007175dc9d0c25  bswap r14
00007175dc9d0c28  mov [r15+0x40], r14
00007175dc9d0c2c  lea r12, [rax+0x140]
00007175dc9d0c33  mov [r13+r12*1], r14
00007175dc9d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007175dc9d0c43  mov r14d, [r15+0x320]
00007175dc9d0c4a  mov eax, 0x4102F0
00007175dc9d0c4f  mov rcx, 0x7175DC9D0CC0
00007175dc9d0c59  mov [r15+r14*8+0x328], rax
00007175dc9d0c61  mov [r15+r14*8+0x368], rcx
00007175dc9d0c69  add r14d, 0x01
00007175dc9d0c6d  and r14d, 0x07
00007175dc9d0c71  mov [r15+0x320], r14d
00007175dc9d0c78  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0c80  jz 0x00007175DC9CED70
00007175dc9d0c86  nop [rax+rax*1], ax
00007175dc9d0c8f  nop [rax+rax*1], eax
00007175dc9d0c97  mov eax, 0x4106BC
00007175dc9d0c9c  mov [r15+0x100], rax
00007175dc9d0ca3  jmp 0x00007175DC7FE110
00007175dc9d0ca8  int3
00007175dc9d0ca9  call 0x00007175DC8C3FE0
00007175dc9d0cae  jmp 0x00007175DC9D0C38
00007175dc9d0cb3  int3
00007175dc9d0cb4  nop [rax+rax*1], ax
00007175dc9d0cbd  nop [rax], eax
00007175dc9d0cc0  mov rax, [r15+0xF8]
00007175dc9d0cc7  lea r14, [rax+0xD0]
00007175dc9d0cce  mov r12d, [r13+r14*1]
00007175dc9d0cd3  lea r14, [rax+0xD4]
00007175dc9d0cda  mov r11d, [r13+r14*1]
00007175dc9d0cdf  lea r14, [rax+0xD8]
00007175dc9d0ce6  mov r10d, [r13+r14*1]
00007175dc9d0ceb  lea r14, [rax+0xDC]
00007175dc9d0cf2  mov r9d, [r13+r14*1]
00007175dc9d0cf7  mov qword ptr [r15+0x48], 0x430C20
00007175dc9d0cff  mov qword ptr [r15+0xA0], 0x00
00007175dc9d0d0a  bswap r12d
00007175dc9d0d0d  bswap r11d
00007175dc9d0d10  mov qword ptr [r15+0x98], 0x430D8C
00007175dc9d0d1b  mov r14d, 0x430C20
00007175dc9d0d21  mov [r13+r14*1], r12d
00007175dc9d0d26  mov r14d, 0x430C24
00007175dc9d0d2c  mov [r13+r14*1], r11d
00007175dc9d0d31  bswap r10d
00007175dc9d0d34  bswap r9d
00007175dc9d0d37  lea r14, [rax+0xE0]
00007175dc9d0d3e  mov r12d, [r13+r14*1]
00007175dc9d0d43  lea r14, [rax+0xE4]
00007175dc9d0d4a  mov r11d, [r13+r14*1]
00007175dc9d0d4f  mov r14d, 0x430C28
00007175dc9d0d55  mov [r13+r14*1], r10d
00007175dc9d0d5a  mov r14d, 0x430C2C
00007175dc9d0d60  mov [r13+r14*1], r9d
00007175dc9d0d65  bswap r12d
00007175dc9d0d68  bswap r11d
00007175dc9d0d6b  mov [rsp+0x10], r11d
00007175dc9d0d70  mov r11d, r11d
00007175dc9d0d73  mov [r15+0x58], r11
00007175dc9d0d77  lea r14, [rax+0xE8]
00007175dc9d0d7e  mov r11d, [r13+r14*1]
00007175dc9d0d83  lea r14, [rax+0xEC]
00007175dc9d0d8a  mov eax, [r13+r14*1]
00007175dc9d0d8f  mov [rsp+0x20], eax
00007175dc9d0d93  mov eax, eax
00007175dc9d0d95  mov [r15+0x60], rax
00007175dc9d0d99  mov eax, 0x430C30
00007175dc9d0d9e  mov [r13+rax*1], r12d
00007175dc9d0da3  mov eax, 0x430C34
00007175dc9d0da8  mov r14d, [rsp+0x10]
00007175dc9d0dad  mov [r13+rax*1], r14d
00007175dc9d0db2  bswap r11d
00007175dc9d0db5  mov [rsp+0x10], r11d
00007175dc9d0dba  mov r11d, r11d
00007175dc9d0dbd  mov [r15+0x40], r11
00007175dc9d0dc1  mov eax, [rsp+0x20]
00007175dc9d0dc5  bswap eax
00007175dc9d0dc7  mov [rsp+0x20], eax
00007175dc9d0dcb  mov eax, eax
00007175dc9d0dcd  mov [r15+0x50], rax
00007175dc9d0dd1  mov eax, 0x430C38
00007175dc9d0dd6  mov r14d, [rsp+0x10]
00007175dc9d0ddb  mov [r13+rax*1], r14d
00007175dc9d0de0  mov eax, 0x430C3C
00007175dc9d0de5  mov r14d, [rsp+0x20]
00007175dc9d0dea  mov [r13+rax*1], r14d
00007175dc9d0def  mov eax, [r15+0xA0]
00007175dc9d0df6  lea r14d, [eax+0x11]
00007175dc9d0dfb  mov r14d, r14d
00007175dc9d0dfe  mov [r15], r14
00007175dc9d0e01  mov qword ptr [r15+0xF0], 0x41034C
00007175dc9d0e0c  mov r14d, [r15+0x320]
00007175dc9d0e13  mov eax, 0x41034C
00007175dc9d0e18  mov rcx, 0x7175DC9D0F90
00007175dc9d0e22  mov [r15+r14*8+0x328], rax
00007175dc9d0e2a  mov [r15+r14*8+0x368], rcx
00007175dc9d0e32  add r14d, 0x01
00007175dc9d0e36  and r14d, 0x07
00007175dc9d0e3a  mov [r15+0x320], r14d
00007175dc9d0e41  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0e49  jz 0x00007175DC9D0F20
00007175dc9d0e4f  nop [rax+rax*1], ax
00007175dc9d0e58  nop [rax+rax*1], eax
00007175dc9d0e60  mov eax, 0x410938
00007175dc9d0e65  mov [r15+0x100], rax
00007175dc9d0e6c  jmp 0x00007175DC7FE110
00007175dc9d0e71  int3
00007175dc9d0e72  call 0x00007175DC8E26A0
00007175dc9d0e77  jmp 0x00007175DC9D0CD3
00007175dc9d0e7c  call 0x00007175DC8E1430
00007175dc9d0e81  jmp 0x00007175DC9D0CDF
00007175dc9d0e86  call 0x00007175DC8E01C0
00007175dc9d0e8b  jmp 0x00007175DC9D0CEB
00007175dc9d0e90  call 0x00007175DC8DEF50
00007175dc9d0e95  jmp 0x00007175DC9D0CF7
00007175dc9d0e9a  call 0x00007175DC8E2BA0
00007175dc9d0e9f  jmp 0x00007175DC9D0D26
00007175dc9d0ea4  call 0x00007175DC8E1920
00007175dc9d0ea9  jmp 0x00007175DC9D0D31
00007175dc9d0eae  call 0x00007175DC8E26A0
00007175dc9d0eb3  jmp 0x00007175DC9D0D43
00007175dc9d0eb8  call 0x00007175DC8E1430
00007175dc9d0ebd  jmp 0x00007175DC9D0D4F
00007175dc9d0ec2  call 0x00007175DC8E06B0
00007175dc9d0ec7  jmp 0x00007175DC9D0D5A
00007175dc9d0ecc  call 0x00007175DC8DF440
00007175dc9d0ed1  jmp 0x00007175DC9D0D65
00007175dc9d0ed6  call 0x00007175DC8E1430
00007175dc9d0edb  jmp 0x00007175DC9D0D83
00007175dc9d0ee0  call 0x00007175DC8D5890
00007175dc9d0ee5  jmp 0x00007175DC9D0D8F
00007175dc9d0eea  call 0x00007175DC80BAE0
00007175dc9d0eef  jmp 0x00007175DC9D0DA3
00007175dc9d0ef4  call 0x00007175DC80DFE0
00007175dc9d0ef9  jmp 0x00007175DC9D0DB2
00007175dc9d0efe  call 0x00007175DC80DFE0
00007175dc9d0f03  jmp 0x00007175DC9D0DE0
00007175dc9d0f08  call 0x00007175DC80DFE0
00007175dc9d0f0d  jmp 0x00007175DC9D0DEF
00007175dc9d0f12  int3
00007175dc9d0f13  nop [rax+rax*1], ax
00007175dc9d0f1c  nop [rax], eax
00007175dc9d0f20  mov eax, [r15]
00007175dc9d0f23  mov [rsp+0x10], eax
00007175dc9d0f27  shr eax, 0x10
00007175dc9d0f2a  mov r14d, [rsp+0x10]
00007175dc9d0f2f  xor r14d, eax
00007175dc9d0f32  imul r14d, r14d, 0x7FEB352D
00007175dc9d0f39  mov eax, 0x846CA68B
00007175dc9d0f3e  mov eax, eax
00007175dc9d0f40  mov [r15+0x48], rax
00007175dc9d0f44  mov [rsp+0x10], r14d
00007175dc9d0f49  shr r14d, 0x0F
00007175dc9d0f4d  mov eax, [rsp+0x10]
00007175dc9d0f51  xor eax, r14d
00007175dc9d0f54  imul eax, eax, 0x846CA68B
00007175dc9d0f5a  mov [rsp+0x10], eax
00007175dc9d0f5e  mov eax, eax
00007175dc9d0f60  mov [r15+0x40], rax
00007175dc9d0f64  mov eax, [rsp+0x10]
00007175dc9d0f68  shr eax, 0x10
00007175dc9d0f6b  mov r14d, [rsp+0x10]
00007175dc9d0f70  xor r14d, eax
00007175dc9d0f73  mov r14d, r14d
00007175dc9d0f76  mov [r15], r14
00007175dc9d0f79  mov rax, [r15+0xF0]
00007175dc9d0f80  mov [r15+0x100], rax
00007175dc9d0f87  jmp 0x00007175DC9CE5C0
00007175dc9d0f8c  int3
00007175dc9d0f8d  int3
00007175dc9d0f8e  nop
00007175dc9d0f90  mov rax, [r15+0xA0]
00007175dc9d0f97  mov [rsp+0x10], rax
00007175dc9d0f9c  shl rax, 0x02
00007175dc9d0fa0  mov r14, [r15+0x98]
00007175dc9d0fa7  lea r12, [r14+rax*1]
00007175dc9d0fab  mov eax, [r15]
00007175dc9d0fae  mov [r13+r12*1], eax
00007175dc9d0fb3  mov rax, [rsp+0x10]
00007175dc9d0fb8  lea r14, [rax+0x01]
00007175dc9d0fbc  mov [r15+0xA0], r14
00007175dc9d0fc3  xor eax, eax
00007175dc9d0fc5  mov r12d, 0x400
00007175dc9d0fcb  cmp r14, r12
00007175dc9d0fce  cmc
00007175dc9d0fcf  lahf
00007175dc9d0fd0  seto al
00007175dc9d0fd3  mov [r15+0x108], eax
00007175dc9d0fda  mov eax, [r15+0x108]
00007175dc9d0fe1  sahf
00007175dc9d0fe2  jnz 0x00007175DC9D1014
00007175dc9d0fe4  cmp dword ptr [r15+0x318], 0x00
00007175dc9d0fec  jz 0x00007175DC9D10E0
00007175dc9d0ff2  nop [rax+rax*1], ax
00007175dc9d0ffb  nop [rax+rax*1], eax
00007175dc9d1003  mov eax, 0x41035C
00007175dc9d1008  mov [r15+0x100], rax
00007175dc9d100f  jmp 0x00007175DC7FE110
00007175dc9d1014  cmp dword ptr [r15+0x318], 0x00
00007175dc9d101c  jz 0x00007175DC9D1050
00007175dc9d1022  nop [rax+rax*1], ax
00007175dc9d102b  nop [rax+rax*1], eax
00007175dc9d1033  mov eax, 0x410344
00007175dc9d1038  mov [r15+0x100], rax
00007175dc9d103f  jmp 0x00007175DC7FE110
00007175dc9d1044  int3
00007175dc9d1045  call 0x00007175DC8B4B70
00007175dc9d104a  jmp 0x00007175DC9D0FB3
00007175dc9d104f  int3
00007175dc9d1050  mov eax, [r15+0xA0]
00007175dc9d1057  lea r14d, [eax+0x11]
00007175dc9d105c  mov r14d, r14d
00007175dc9d105f  mov [r15], r14
00007175dc9d1062  mov qword ptr [r15+0xF0], 0x41034C
00007175dc9d106d  mov r14d, [r15+0x320]
00007175dc9d1074  mov eax, 0x41034C
00007175dc9d1079  mov rcx, 0x7175DC9D0F90
00007175dc9d1083  mov [r15+r14*8+0x328], rax
00007175dc9d108b  mov [r15+r14*8+0x368], rcx
00007175dc9d1093  add r14d, 0x01
00007175dc9d1097  and r14d, 0x07
00007175dc9d109b  mov [r15+0x320], r14d
00007175dc9d10a2  cmp dword ptr [r15+0x318], 0x00
00007175dc9d10aa  jz 0x00007175DC9D0F20
00007175dc9d10b0  nop [rax+rax*1], ax
00007175dc9d10b9  nop [rax+rax*1], eax
00007175dc9d10c1  mov eax, 0x410938
00007175dc9d10c6  mov [r15+0x100], rax
00007175dc9d10cd  jmp 0x00007175DC7FE110
00007175dc9d10d2  int3
00007175dc9d10d3  int3
00007175dc9d10d4  nop [rax+rax*1], ax
00007175dc9d10dd  nop [rax], eax
00007175dc9d10e0  mov qword ptr [r15+0x40], 0x01
00007175dc9d10e8  cmp dword ptr [r15+0x318], 0x00
00007175dc9d10f0  jz 0x00007175DC9D1120
00007175dc9d10f6  nop [rax+rax*1], ax
00007175dc9d10ff  nop [rax+rax*1], eax
00007175dc9d1107  mov eax, 0x410378
00007175dc9d110c  mov [r15+0x100], rax
00007175dc9d1113  jmp 0x00007175DC7FE110
00007175dc9d1118  int3
00007175dc9d1119  int3
00007175dc9d111a  nop [rax+rax*1], ax
00007175dc9d1120  mov rax, [r15+0x40]
00007175dc9d1124  mov [rsp+0x10], rax
00007175dc9d1129  shl rax, 0x02
00007175dc9d112d  mov r14, [r15+0x98]
00007175dc9d1134  lea r12, [r14+rax*1]
00007175dc9d1138  mov eax, [r13+r12*1]
00007175dc9d113d  mov [rsp+0x20], eax
00007175dc9d1141  mov eax, eax
00007175dc9d1143  mov [r15+0x48], rax
00007175dc9d1147  mov rax, [rsp+0x10]
00007175dc9d114c  mov [r15+0x50], rax
00007175dc9d1150  mov eax, [r15+0x50]
00007175dc9d1154  lea r12d, [eax-0x01]
00007175dc9d1159  mov r12d, r12d
00007175dc9d115c  mov [r15+0x58], r12
00007175dc9d1160  mov rax, [r15+0x58]
00007175dc9d1164  mov r12d, eax
00007175dc9d1167  mov r12d, r12d
00007175dc9d116a  shl r12, 0x02
00007175dc9d116e  lea rax, [r14+r12*1]
00007175dc9d1172  mov r14d, [r13+rax*1]
00007175dc9d1177  mov [rsp+0x10], r14d
00007175dc9d117c  mov r14d, r14d
00007175dc9d117f  mov [r15+0x60], r14
00007175dc9d1183  xor eax, eax
00007175dc9d1185  mov r14d, [rsp+0x10]
00007175dc9d118a  mov r12d, [rsp+0x20]
00007175dc9d118f  cmp r14d, r12d
00007175dc9d1192  cmc
00007175dc9d1193  lahf
00007175dc9d1194  seto al
00007175dc9d1197  mov [r15+0x108], eax
00007175dc9d119e  mov eax, [r15+0x108]
00007175dc9d11a5  sahf
00007175dc9d11a6  cmc
00007175dc9d11a7  jbe 0x00007175DC9D11D9
00007175dc9d11a9  cmp dword ptr [r15+0x318], 0x00
00007175dc9d11b1  jz 0x00007175DC9D1220
00007175dc9d11b7  nop [rax+rax*1], ax
00007175dc9d11c0  nop [rax+rax*1], eax
00007175dc9d11c8  mov eax, 0x410390
00007175dc9d11cd  mov [r15+0x100], rax
00007175dc9d11d4  jmp 0x00007175DC7FE110
00007175dc9d11d9  cmp dword ptr [r15+0x318], 0x00
00007175dc9d11e1  jz 0x00007175DC9D14C0
00007175dc9d11e7  nop [rax+rax*1], ax
00007175dc9d11f0  nop [rax+rax*1], eax
00007175dc9d11f8  mov eax, 0x410368
00007175dc9d11fd  mov [r15+0x100], rax
00007175dc9d1204  jmp 0x00007175DC7FE110
00007175dc9d1209  int3
00007175dc9d120a  call 0x00007175DC8B4690
00007175dc9d120f  jmp 0x00007175DC9D113D
00007175dc9d1214  call 0x00007175DC80DAE0
00007175dc9d1219  jmp 0x00007175DC9D1177
00007175dc9d121e  int3
00007175dc9d121f  nop
00007175dc9d1220  mov rax, [r15+0x50]
00007175dc9d1224  mov [rsp+0x10], rax
00007175dc9d1229  shl rax, 0x02
00007175dc9d122d  mov r14, [r15+0x98]
00007175dc9d1234  lea r12, [r14+rax*1]
00007175dc9d1238  mov eax, [r15+0x60]
00007175dc9d123c  mov [r13+r12*1], eax
00007175dc9d1241  mov rax, [rsp+0x10]
00007175dc9d1246  lea r14, [rax-0x01]
00007175dc9d124a  mov [r15+0x50], r14
00007175dc9d124e  mov rax, [r15+0x58]
00007175dc9d1252  test rax, rax
00007175dc9d1255  setz al
00007175dc9d1258  movzx rax, al
00007175dc9d125c  mov [rsp+0x414], al
00007175dc9d1263  cmp byte ptr [rsp+0x414], 0x00
00007175dc9d126b  jz 0x00007175DC9D129D
00007175dc9d126d  cmp dword ptr [r15+0x318], 0x00
00007175dc9d1275  jz 0x00007175DC9D12E0
00007175dc9d127b  nop [rax+rax*1], ax
00007175dc9d1284  nop [rax+rax*1], eax
00007175dc9d128c  mov eax, 0x41039C
00007175dc9d1291  mov [r15+0x100], rax
00007175dc9d1298  jmp 0x00007175DC7FE110
00007175dc9d129d  cmp dword ptr [r15+0x318], 0x00
00007175dc9d12a5  jz 0x00007175DC9D13E0
00007175dc9d12ab  nop [rax+rax*1], ax
00007175dc9d12b4  nop [rax+rax*1], eax
00007175dc9d12bc  mov eax, 0x410380
00007175dc9d12c1  mov [r15+0x100], rax
00007175dc9d12c8  jmp 0x00007175DC7FE110
00007175dc9d12cd  int3
00007175dc9d12ce  call 0x00007175DC8B4B70
00007175dc9d12d3  jmp 0x00007175DC9D1241
00007175dc9d12d8  int3
00007175dc9d12d9  nop [rax], eax
00007175dc9d12e0  cmp dword ptr [r15+0x318], 0x00
00007175dc9d12e8  jz 0x00007175DC9D1320
00007175dc9d12ee  nop [rax+rax*1], ax
00007175dc9d12f7  nop [rax+rax*1], eax
00007175dc9d12ff  mov eax, 0x410364
00007175dc9d1304  mov [r15+0x100], rax
00007175dc9d130b  jmp 0x00007175DC7FE110
00007175dc9d1310  int3
00007175dc9d1311  int3
00007175dc9d1312  nop [rax+rax*1], ax
00007175dc9d131b  nop [rax+rax*1], eax
00007175dc9d1320  mov qword ptr [r15+0x50], 0x00
00007175dc9d1328  mov rax, [r15+0x40]
00007175dc9d132c  lea r14, [rax+0x01]
00007175dc9d1330  mov [r15+0x40], r14
00007175dc9d1334  mov rax, [r15+0x98]
00007175dc9d133b  mov r12d, [r15+0x48]
00007175dc9d133f  mov [r13+rax*1], r12d
00007175dc9d1344  xor eax, eax
00007175dc9d1346  mov r12d, 0x400
00007175dc9d134c  cmp r14, r12
00007175dc9d134f  cmc
00007175dc9d1350  lahf
00007175dc9d1351  seto al
00007175dc9d1354  mov [r15+0x108], eax
00007175dc9d135b  mov eax, [r15+0x108]
00007175dc9d1362  sahf
00007175dc9d1363  jz 0x00007175DC9D1395
00007175dc9d1365  cmp dword ptr [r15+0x318], 0x00
00007175dc9d136d  jz 0x00007175DC9D1120
00007175dc9d1373  nop [rax+rax*1], ax
00007175dc9d137c  nop [rax+rax*1], eax
00007175dc9d1384  mov eax, 0x410378
00007175dc9d1389  mov [r15+0x100], rax
00007175dc9d1390  jmp 0x00007175DC7FE110
00007175dc9d1395  cmp dword ptr [r15+0x318], 0x00
00007175dc9d139d  jz 0x00007175DC9D1580
00007175dc9d13a3  nop [rax+rax*1], ax
00007175dc9d13ac  nop [rax+rax*1], eax
00007175dc9d13b4  mov eax, 0x4103A0
00007175dc9d13b9  mov [r15+0x100], rax
00007175dc9d13c0  jmp 0x00007175DC7FE110
00007175dc9d13c5  int3
00007175dc9d13c6  call 0x00007175DC80BAE0
00007175dc9d13cb  jmp 0x00007175DC9D1344
00007175dc9d13d0  int3
00007175dc9d13d1  nop [rax+rax*1], ax
00007175dc9d13da  nop [rax+rax*1], ax
00007175dc9d13e0  mov eax, [r15+0x50]
00007175dc9d13e4  lea r14d, [eax-0x01]
00007175dc9d13e9  mov r14d, r14d
00007175dc9d13ec  mov [r15+0x58], r14
00007175dc9d13f0  mov rax, [r15+0x58]
00007175dc9d13f4  mov r14d, eax
00007175dc9d13f7  mov r14d, r14d
00007175dc9d13fa  shl r14, 0x02
00007175dc9d13fe  mov rax, [r15+0x98]
00007175dc9d1405  lea r12, [rax+r14*1]
00007175dc9d1409  mov eax, [r13+r12*1]
00007175dc9d140e  mov [rsp+0x10], eax
00007175dc9d1412  mov eax, eax
00007175dc9d1414  mov [r15+0x60], rax
00007175dc9d1418  mov eax, [r15+0x48]
00007175dc9d141c  mov [rsp+0x20], eax
00007175dc9d1420  xor eax, eax
00007175dc9d1422  mov r14d, [rsp+0x10]
00007175dc9d1427  mov r12d, [rsp+0x20]
00007175dc9d142c  cmp r14d, r12d
00007175dc9d142f  cmc
00007175dc9d1430  lahf
00007175dc9d1431  seto al
00007175dc9d1434  mov [r15+0x108], eax
00007175dc9d143b  mov eax, [r15+0x108]
00007175dc9d1442  sahf
00007175dc9d1443  cmc
00007175dc9d1444  jbe 0x00007175DC9D1476
00007175dc9d1446  cmp dword ptr [r15+0x318], 0x00
00007175dc9d144e  jz 0x00007175DC9D1220
00007175dc9d1454  nop [rax+rax*1], ax
00007175dc9d145d  nop [rax+rax*1], eax
00007175dc9d1465  mov eax, 0x410390
00007175dc9d146a  mov [r15+0x100], rax
00007175dc9d1471  jmp 0x00007175DC7FE110
00007175dc9d1476  cmp dword ptr [r15+0x318], 0x00
00007175dc9d147e  jz 0x00007175DC9D14C0
00007175dc9d1484  nop [rax+rax*1], ax
00007175dc9d148d  nop [rax+rax*1], eax
00007175dc9d1495  mov eax, 0x410368
00007175dc9d149a  mov [r15+0x100], rax
00007175dc9d14a1  jmp 0x00007175DC7FE110
00007175dc9d14a6  int3
00007175dc9d14a7  call 0x00007175DC8B4690
00007175dc9d14ac  jmp 0x00007175DC9D140E
00007175dc9d14b1  int3
00007175dc9d14b2  nop [rax+rax*1], ax
00007175dc9d14bb  nop [rax+rax*1], eax
00007175dc9d14c0  mov rax, [r15+0x40]
00007175dc9d14c4  lea r14, [rax+0x01]
00007175dc9d14c8  mov [r15+0x40], r14
00007175dc9d14cc  mov rax, [r15+0x50]
00007175dc9d14d0  mov r12d, eax
00007175dc9d14d3  mov r12d, r12d
00007175dc9d14d6  shl r12, 0x02
00007175dc9d14da  mov rax, [r15+0x98]
00007175dc9d14e1  lea r11, [rax+r12*1]
00007175dc9d14e5  mov eax, [r15+0x48]
00007175dc9d14e9  mov [r13+r11*1], eax
00007175dc9d14ee  xor eax, eax
00007175dc9d14f0  mov r12d, 0x400
00007175dc9d14f6  cmp r14, r12
00007175dc9d14f9  cmc
00007175dc9d14fa  lahf
00007175dc9d14fb  seto al
00007175dc9d14fe  mov [r15+0x108], eax
00007175dc9d1505  mov eax, [r15+0x108]
00007175dc9d150c  sahf
00007175dc9d150d  jz 0x00007175DC9D153F
00007175dc9d150f  cmp dword ptr [r15+0x318], 0x00
00007175dc9d1517  jz 0x00007175DC9D1120
00007175dc9d151d  nop [rax+rax*1], ax
00007175dc9d1526  nop [rax+rax*1], eax
00007175dc9d152e  mov eax, 0x410378
00007175dc9d1533  mov [r15+0x100], rax
00007175dc9d153a  jmp 0x00007175DC7FE110
00007175dc9d153f  cmp dword ptr [r15+0x318], 0x00
00007175dc9d1547  jz 0x00007175DC9D1580
00007175dc9d154d  nop [rax+rax*1], ax
00007175dc9d1556  nop [rax+rax*1], eax
00007175dc9d155e  mov eax, 0x4103A0
00007175dc9d1563  mov [r15+0x100], rax
00007175dc9d156a  jmp 0x00007175DC7FE110
00007175dc9d156f  int3
00007175dc9d1570  call 0x00007175DC8A4270
00007175dc9d1575  jmp 0x00007175DC9D14EE
00007175dc9d157a  int3
00007175dc9d157b  nop [rax+rax*1], eax
00007175dc9d1580  mov qword ptr [r15+0x40], 0x430000
00007175dc9d1588  mov eax, 0x430C40
00007175dc9d158d  mov r14, [r13+rax*1]
00007175dc9d1592  mov rax, [r15+0x98]
00007175dc9d1599  mov r12d, [r13+rax*1]
00007175dc9d159e  lea r11, [rax+0x04]
00007175dc9d15a2  mov eax, [r13+r11*1]
00007175dc9d15a7  mov r12d, r12d
00007175dc9d15aa  mov [r15+0x68], r12
00007175dc9d15ae  mov eax, eax
00007175dc9d15b0  mov [r15+0x60], rax
00007175dc9d15b4  mov rax, [r15+0x68]
00007175dc9d15b8  mov [r15+0x68], rax
00007175dc9d15bc  mov qword ptr [r15+0x58], 0x02
00007175dc9d15c4  mov [rsp+0x10], rax
00007175dc9d15c9  xor eax, eax
00007175dc9d15cb  mov r12d, 0x02
00007175dc9d15d1  mov r11d, 0x400
00007175dc9d15d7  cmp r12, r11
00007175dc9d15da  cmc
00007175dc9d15db  lahf
00007175dc9d15dc  seto al
00007175dc9d15df  mov [r15+0x108], eax
00007175dc9d15e6  mov rax, [r15+0x60]
00007175dc9d15ea  mov r12d, 0x02
00007175dc9d15f0  imul rax, r12
00007175dc9d15f4  mov [r15+0x50], rax
00007175dc9d15f8  mov rax, [rsp+0x10]
00007175dc9d15fd  lea r12, [rax+r14*1]
00007175dc9d1601  mov [r15+0x48], r12
00007175dc9d1605  mov eax, [r15+0x108]
00007175dc9d160c  sahf
00007175dc9d160d  jnz 0x00007175DC9D163F
00007175dc9d160f  cmp dword ptr [r15+0x318], 0x00
00007175dc9d1617  jz 0x00007175DC9D17B0
00007175dc9d161d  nop [rax+rax*1], ax
00007175dc9d1626  nop [rax+rax*1], eax
00007175dc9d162e  mov eax, 0x4103D0
00007175dc9d1633  mov [r15+0x100], rax
00007175dc9d163a  jmp 0x00007175DC7FE110
00007175dc9d163f  cmp dword ptr [r15+0x318], 0x00
00007175dc9d1647  jz 0x00007175DC9D1690
00007175dc9d164d  nop [rax+rax*1], ax
00007175dc9d1656  nop [rax+rax*1], eax
00007175dc9d165e  mov eax, 0x4103B0
00007175dc9d1663  mov [r15+0x100], rax
00007175dc9d166a  jmp 0x00007175DC7FE110
00007175dc9d166f  int3
00007175dc9d1670  call 0x00007175DC80DC20
00007175dc9d1675  jmp 0x00007175DC9D1592
00007175dc9d167a  call 0x00007175DC80B5E0
00007175dc9d167f  jmp 0x00007175DC9D159E
00007175dc9d1684  call 0x00007175DC8A3D90
00007175dc9d1689  jmp 0x00007175DC9D15A7
00007175dc9d168e  int3
00007175dc9d168f  nop
00007175dc9d1690  mov rax, [r15+0x98]
00007175dc9d1697  mov r14, [r15+0x58]
00007175dc9d169b  mov [rsp+0x10], r14
00007175dc9d16a0  shl r14, 0x02
00007175dc9d16a4  lea r12, [rax+r14*1]
00007175dc9d16a8  mov eax, [r13+r12*1]
00007175dc9d16ad  lea r14, [r12+0x04]
00007175dc9d16b2  mov r12d, [r13+r14*1]
00007175dc9d16b7  mov eax, eax
00007175dc9d16b9  mov [r15+0x68], rax
00007175dc9d16bd  mov r12d, r12d
00007175dc9d16c0  mov [r15+0x60], r12
00007175dc9d16c4  mov rax, [r15+0x68]
00007175dc9d16c8  mov [rsp+0x20], rax
00007175dc9d16cd  mov r14, [rsp+0x10]
00007175dc9d16d2  imul rax, r14
00007175dc9d16d6  mov r12, [rsp+0x20]
00007175dc9d16db  lea r11, [r12+rax*1]
00007175dc9d16df  mov [r15+0x68], r11
00007175dc9d16e3  lea rax, [r14+0x02]
00007175dc9d16e7  mov [r15+0x58], rax
00007175dc9d16eb  mov [rsp+0x10], rax
00007175dc9d16f0  xor eax, eax
00007175dc9d16f2  mov r14, [rsp+0x10]
00007175dc9d16f7  mov r12d, 0x400
00007175dc9d16fd  cmp r14, r12
00007175dc9d1700  cmc
00007175dc9d1701  lahf
00007175dc9d1702  seto al
00007175dc9d1705  mov [r15+0x108], eax
00007175dc9d170c  mov rax, [r15+0x50]
00007175dc9d1710  mov r12, [r15+0x60]
00007175dc9d1714  imul r14, r12
00007175dc9d1718  lea r12, [rax+r14*1]
00007175dc9d171c  mov [r15+0x50], r12
00007175dc9d1720  mov rax, [r15+0x48]
00007175dc9d1724  lea r14, [r11+rax*1]
00007175dc9d1728  mov [r15+0x48], r14
00007175dc9d172c  mov eax, [r15+0x108]
00007175dc9d1733  sahf
00007175dc9d1734  jnz 0x00007175DC9D1766
00007175dc9d1736  cmp dword ptr [r15+0x318], 0x00
00007175dc9d173e  jz 0x00007175DC9D17B0
00007175dc9d1744  nop [rax+rax*1], ax
00007175dc9d174d  nop [rax+rax*1], eax
00007175dc9d1755  mov eax, 0x4103D0
00007175dc9d175a  mov [r15+0x100], rax
00007175dc9d1761  jmp 0x00007175DC7FE110
00007175dc9d1766  cmp dword ptr [r15+0x318], 0x00
00007175dc9d176e  jz 0x00007175DC9D1690
00007175dc9d1774  nop [rax+rax*1], ax
00007175dc9d177d  nop [rax+rax*1], eax
00007175dc9d1785  mov eax, 0x4103B0
00007175dc9d178a  mov [r15+0x100], rax
00007175dc9d1791  jmp 0x00007175DC7FE110
00007175dc9d1796  int3
00007175dc9d1797  call 0x00007175DC8B4690
00007175dc9d179c  jmp 0x00007175DC9D16AD
00007175dc9d17a1  call 0x00007175DC8E26A0
00007175dc9d17a6  jmp 0x00007175DC9D16B7
00007175dc9d17ab  int3
00007175dc9d17ac  nop [rax], eax
00007175dc9d17b0  mov qword ptr [r15+0x98], 0x00
00007175dc9d17bb  mov rax, [r15+0x50]
00007175dc9d17bf  mov r14, [r15+0x48]
00007175dc9d17c3  lea r12, [rax+r14*1]
00007175dc9d17c7  mov [r15+0x48], r12
00007175dc9d17cb  mov rax, [r15+0x40]
00007175dc9d17cf  lea r14, [rax+0xC40]
00007175dc9d17d6  mov [r13+r14*1], r12
00007175dc9d17db  mov qword ptr [r15], 0x01
00007175dc9d17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007175dc9d17ed  mov r14d, [r15+0x320]
00007175dc9d17f4  mov eax, 0x4103E8
00007175dc9d17f9  mov rcx, 0x7175DC9D1860
00007175dc9d1803  mov [r15+r14*8+0x328], rax
00007175dc9d180b  mov [r15+r14*8+0x368], rcx
00007175dc9d1813  add r14d, 0x01
00007175dc9d1817  and r14d, 0x07
00007175dc9d181b  mov [r15+0x320], r14d
00007175dc9d1822  cmp dword ptr [r15+0x318], 0x00
00007175dc9d182a  jz 0x00007175DC9D0F20
00007175dc9d1830  nop [rax+rax*1], ax
00007175dc9d1839  nop [rax+rax*1], eax
00007175dc9d1841  mov eax, 0x410938
00007175dc9d1846  mov [r15+0x100], rax
00007175dc9d184d  jmp 0x00007175DC7FE110
00007175dc9d1852  int3
00007175dc9d1853  call 0x00007175DC8E2CE0
00007175dc9d1858  jmp 0x00007175DC9D17DB
00007175dc9d185d  int3
00007175dc9d185e  nop
00007175dc9d1860  mov eax, [r15+0x98]
00007175dc9d1867  lea r14d, [eax+0x01]
00007175dc9d186c  mov [rsp+0x10], r14d
00007175dc9d1871  mov r14d, r14d
00007175dc9d1874  mov [r15+0x98], r14
00007175dc9d187b  xor eax, eax
00007175dc9d187d  mov r14d, [rsp+0x10]
00007175dc9d1882  cmp r14d, 0x10000
00007175dc9d1889  cmc
00007175dc9d188a  lahf
00007175dc9d188b  seto al
00007175dc9d188e  mov [r15+0x108], eax
00007175dc9d1895  mov eax, [r15+0x108]
00007175dc9d189c  sahf
00007175dc9d189d  jnz 0x00007175DC9D18CF
00007175dc9d189f  cmp dword ptr [r15+0x318], 0x00
00007175dc9d18a7  jz 0x00007175DC9D19A0
00007175dc9d18ad  nop [rax+rax*1], ax
00007175dc9d18b6  nop [rax+rax*1], eax
00007175dc9d18be  mov eax, 0x4103F4
00007175dc9d18c3  mov [r15+0x100], rax
00007175dc9d18ca  jmp 0x00007175DC7FE110
00007175dc9d18cf  cmp dword ptr [r15+0x318], 0x00
00007175dc9d18d7  jz 0x00007175DC9D1910
00007175dc9d18dd  nop [rax+rax*1], ax
00007175dc9d18e6  nop [rax+rax*1], eax
00007175dc9d18ee  mov eax, 0x4103E0
00007175dc9d18f3  mov [r15+0x100], rax
00007175dc9d18fa  jmp 0x00007175DC7FE110
00007175dc9d18ff  int3
00007175dc9d1900  int3
00007175dc9d1901  nop [rax+rax*1], ax
00007175dc9d190a  nop [rax+rax*1], ax
00007175dc9d1910  mov eax, [r15]
00007175dc9d1913  mov r14d, [r15+0x98]
00007175dc9d191a  lea r12d, [eax+r14d*1]
00007175dc9d191f  mov r12d, r12d
00007175dc9d1922  mov [r15], r12
00007175dc9d1925  mov qword ptr [r15+0xF0], 0x4103E8
00007175dc9d1930  mov r14d, [r15+0x320]
00007175dc9d1937  mov eax, 0x4103E8
00007175dc9d193c  mov rcx, 0x7175DC9D1860
00007175dc9d1946  mov [r15+r14*8+0x328], rax
00007175dc9d194e  mov [r15+r14*8+0x368], rcx
00007175dc9d1956  add r14d, 0x01
00007175dc9d195a  and r14d, 0x07
00007175dc9d195e  mov [r15+0x320], r14d
00007175dc9d1965  cmp dword ptr [r15+0x318], 0x00
00007175dc9d196d  jz 0x00007175DC9D0F20
00007175dc9d1973  nop [rax+rax*1], ax
00007175dc9d197c  nop [rax+rax*1], eax
00007175dc9d1984  mov eax, 0x410938
00007175dc9d1989  mov [r15+0x100], rax
00007175dc9d1990  jmp 0x00007175DC7FE110
00007175dc9d1995  int3
00007175dc9d1996  int3
00007175dc9d1997  nop [rax+rax*1], ax
00007175dc9d19a0  vmovaps xmm1, [0x00007175DC5FE010]
00007175dc9d19a8  movq xmm1, xmm1
00007175dc9d19ac  movaps [r15+0x110], xmm1
00007175dc9d19b4  mov eax, 0x420AA0
00007175dc9d19b9  mov r14, [r13+rax*1]
00007175dc9d19be  movq xmm1, r14
00007175dc9d19c3  movaps [r15+0x120], xmm1
00007175dc9d19cb  vmovaps xmm1, [0x00007175DC5FE020]
00007175dc9d19d3  movq xmm1, xmm1
00007175dc9d19d7  movaps [r15+0x140], xmm1
00007175dc9d19df  vmovaps xmm1, [0x00007175DC5FE030]
00007175dc9d19e7  vpbroadcastq xmm1, xmm1
00007175dc9d19ec  movaps [r15+0x150], xmm1
00007175dc9d19f4  mov qword ptr [r15+0x40], 0x02
00007175dc9d19fc  vmovaps xmm15, [0x00007175DC5FE040]
00007175dc9d1a04  movq xmm15, xmm15
00007175dc9d1a09  movaps [r15+0x160], xmm15
00007175dc9d1a11  vmovaps xmm15, [0x00007175DC5FE050]
00007175dc9d1a19  vpbroadcastq xmm15, xmm15
00007175dc9d1a1e  movaps [r15+0x130], xmm15
00007175dc9d1a26  mov rax, [r15+0x40]
00007175dc9d1a2a  vmovq xmm14, rax
00007175dc9d1a2f  vpbroadcastq xmm14, xmm14
00007175dc9d1a34  movaps [r15+0x170], xmm14
00007175dc9d1a3c  mov eax, 0x4209D0
00007175dc9d1a41  movups xmm13, [r13+rax*1]
00007175dc9d1a47  mov qword ptr [r15+0x40], 0x431D90
00007175dc9d1a4f  mov eax, [r15]
00007175dc9d1a52  mov r14d, 0x430C48
00007175dc9d1a58  mov [r13+r14*1], eax
00007175dc9d1a5d  mov qword ptr [r15+0x50], 0x431F90
00007175dc9d1a65  vpmovqd xmm12, xmm13
00007175dc9d1a6b  pxor xmm11, xmm11
00007175dc9d1a70  punpcklqdq xmm12, xmm11
00007175dc9d1a75  movaps [r15+0x210], xmm12
00007175dc9d1a7d  movq xmm12, qword ptr [r15+0x140]
00007175dc9d1a86  movq xmm11, qword ptr [r15+0x120]
00007175dc9d1a8f  psubd xmm12, xmm11
00007175dc9d1a94  movq xmm12, xmm12
00007175dc9d1a99  paddq xmm13, xmm14
00007175dc9d1a9e  movaps [r15+0x180], xmm13
00007175dc9d1aa6  movq xmm14, qword ptr [r15+0x160]
00007175dc9d1aaf  paddd xmm11, xmm14
00007175dc9d1ab4  movq xmm11, xmm11
00007175dc9d1ab9  movq xmm11, xmm11
00007175dc9d1abe  movaps [r15+0x120], xmm11
00007175dc9d1ac6  pmovzxdq xmm12, xmm12
00007175dc9d1acc  psllq xmm12, 0x00
00007175dc9d1ad2  movq xmm14, qword ptr [r15+0x210]
00007175dc9d1adb  movq xmm13, qword ptr [r15+0x110]
00007175dc9d1ae4  paddd xmm14, xmm13
00007175dc9d1ae9  movq xmm14, xmm14
00007175dc9d1aee  vcvtuqq2pd xmm12, xmm12
00007175dc9d1af4  pmovzxdq xmm14, xmm14
00007175dc9d1afa  psllq xmm14, 0x00
00007175dc9d1b00  vcvtuqq2pd xmm14, xmm14
00007175dc9d1b06  movaps xmm13, xmm12
00007175dc9d1b0a  mulpd xmm13, xmm1
00007175dc9d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007175dc9d1b15  ptest xmm11, xmm11
00007175dc9d1b1b  jnz 0x00007175DC9D1C0F
00007175dc9d1b21  movaps [r15+0x220], xmm13
00007175dc9d1b29  mov eax, 0x431F90
00007175dc9d1b2e  movups [r13+rax*1], xmm13
00007175dc9d1b34  movaps xmm1, xmm14
00007175dc9d1b38  mulpd xmm1, xmm15
00007175dc9d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007175dc9d1b42  ptest xmm13, xmm13
00007175dc9d1b48  jnz 0x00007175DC9D1D5C
00007175dc9d1b4e  movaps [r15+0x210], xmm1
00007175dc9d1b56  mov eax, 0x431D90
00007175dc9d1b5b  movups [r13+rax*1], xmm1
00007175dc9d1b61  mov qword ptr [r15+0x48], 0x10
00007175dc9d1b69  xor eax, eax
00007175dc9d1b6b  mov r14d, 0x10
00007175dc9d1b71  mov r12d, 0x200
00007175dc9d1b77  cmp r14, r12
00007175dc9d1b7a  cmc
00007175dc9d1b7b  lahf
00007175dc9d1b7c  seto al
00007175dc9d1b7f  mov [r15+0x108], eax
00007175dc9d1b86  mov eax, [r15+0x108]
00007175dc9d1b8d  sahf
00007175dc9d1b8e  jnz 0x00007175DC9D1BC0
00007175dc9d1b90  cmp dword ptr [r15+0x318], 0x00
00007175dc9d1b98  jz 0x00007175DC9D2300
00007175dc9d1b9e  nop [rax+rax*1], ax
00007175dc9d1ba7  nop [rax+rax*1], eax
00007175dc9d1baf  mov eax, 0x410480
00007175dc9d1bb4  mov [r15+0x100], rax
00007175dc9d1bbb  jmp 0x00007175DC7FE110
00007175dc9d1bc0  cmp dword ptr [r15+0x318], 0x00
00007175dc9d1bc8  jz 0x00007175DC9D1EB0
00007175dc9d1bce  nop [rax+rax*1], ax
00007175dc9d1bd7  nop [rax+rax*1], eax
00007175dc9d1bdf  mov eax, 0x410440
00007175dc9d1be4  mov [r15+0x100], rax
00007175dc9d1beb  jmp 0x00007175DC7FE110
00007175dc9d1bf0  int3
00007175dc9d1bf1  call 0x00007175DC80DC20
00007175dc9d1bf6  jmp 0x00007175DC9D19BE
00007175dc9d1bfb  call 0x00007175DC80C260
00007175dc9d1c00  jmp 0x00007175DC9D1A47
00007175dc9d1c05  call 0x00007175DC8D5D70
00007175dc9d1c0a  jmp 0x00007175DC9D1A5D
00007175dc9d1c0f  sub rsp, 0x08
00007175dc9d1c13  push rax
00007175dc9d1c14  push rcx
00007175dc9d1c15  push rdx
00007175dc9d1c16  push rdi
00007175dc9d1c17  push rsi
00007175dc9d1c18  push r8
00007175dc9d1c1a  push r9
00007175dc9d1c1c  push r10
00007175dc9d1c1e  push r11
00007175dc9d1c20  sub rsp, 0xF0
00007175dc9d1c27  vmovaps [rsp], xmm0
00007175dc9d1c2c  vmovaps [rsp+0x10], xmm1
00007175dc9d1c32  vmovaps [rsp+0x20], xmm2
00007175dc9d1c38  vmovaps [rsp+0x30], xmm3
00007175dc9d1c3e  vmovaps [rsp+0x40], xmm4
00007175dc9d1c44  vmovaps [rsp+0x50], xmm5
00007175dc9d1c4a  vmovaps [rsp+0x60], xmm6
00007175dc9d1c50  vmovaps [rsp+0x70], xmm7
00007175dc9d1c56  vmovaps [rsp+0x80], xmm8
00007175dc9d1c5f  vmovaps [rsp+0x90], xmm9
00007175dc9d1c68  vmovaps [rsp+0xA0], xmm10
00007175dc9d1c71  vmovaps [rsp+0xB0], xmm11
00007175dc9d1c7a  vmovaps [rsp+0xC0], xmm12
00007175dc9d1c83  vmovaps [rsp+0xD0], xmm14
00007175dc9d1c8c  vmovaps [rsp+0xE0], xmm15
00007175dc9d1c95  sub rsp, 0x30
00007175dc9d1c99  movaps [rsp], xmm13
00007175dc9d1c9e  movaps [rsp+0x10], xmm12
00007175dc9d1ca4  movaps [rsp+0x20], xmm1
00007175dc9d1ca9  lea rdi, [rsp]
00007175dc9d1cad  mov esi, 0x00
00007175dc9d1cb2  mov rax, 0x622B29CAF530
00007175dc9d1cbc  call rax
00007175dc9d1cbe  movaps xmm13, [rsp]
00007175dc9d1cc3  add rsp, 0x30
00007175dc9d1cc7  vmovaps xmm0, [rsp]
00007175dc9d1ccc  vmovaps xmm1, [rsp+0x10]
00007175dc9d1cd2  vmovaps xmm2, [rsp+0x20]
00007175dc9d1cd8  vmovaps xmm3, [rsp+0x30]
00007175dc9d1cde  vmovaps xmm4, [rsp+0x40]
00007175dc9d1ce4  vmovaps xmm5, [rsp+0x50]
00007175dc9d1cea  vmovaps xmm6, [rsp+0x60]
00007175dc9d1cf0  vmovaps xmm7, [rsp+0x70]
00007175dc9d1cf6  vmovaps xmm8, [rsp+0x80]
00007175dc9d1cff  vmovaps xmm9, [rsp+0x90]
00007175dc9d1d08  vmovaps xmm10, [rsp+0xA0]
00007175dc9d1d11  vmovaps xmm11, [rsp+0xB0]
00007175dc9d1d1a  vmovaps xmm12, [rsp+0xC0]
00007175dc9d1d23  vmovaps xmm14, [rsp+0xD0]
00007175dc9d1d2c  vmovaps xmm15, [rsp+0xE0]
00007175dc9d1d35  add rsp, 0xF0
00007175dc9d1d3c  pop r11
00007175dc9d1d3e  pop r10
00007175dc9d1d40  pop r9
00007175dc9d1d42  pop r8
00007175dc9d1d44  pop rsi
00007175dc9d1d45  pop rdi
00007175dc9d1d46  pop rdx
00007175dc9d1d47  pop rcx
00007175dc9d1d48  pop rax
00007175dc9d1d49  add rsp, 0x08
00007175dc9d1d4d  jmp 0x00007175DC9D1B21
00007175dc9d1d52  call 0x00007175DC80C380
00007175dc9d1d57  jmp 0x00007175DC9D1B34
00007175dc9d1d5c  sub rsp, 0x08
00007175dc9d1d60  push rax
00007175dc9d1d61  push rcx
00007175dc9d1d62  push rdx
00007175dc9d1d63  push rdi
00007175dc9d1d64  push rsi
00007175dc9d1d65  push r8
00007175dc9d1d67  push r9
00007175dc9d1d69  push r10
00007175dc9d1d6b  push r11
00007175dc9d1d6d  sub rsp, 0xF0
00007175dc9d1d74  vmovaps [rsp], xmm0
00007175dc9d1d79  vmovaps [rsp+0x10], xmm2
00007175dc9d1d7f  vmovaps [rsp+0x20], xmm3
00007175dc9d1d85  vmovaps [rsp+0x30], xmm4
00007175dc9d1d8b  vmovaps [rsp+0x40], xmm5
00007175dc9d1d91  vmovaps [rsp+0x50], xmm6
00007175dc9d1d97  vmovaps [rsp+0x60], xmm7
00007175dc9d1d9d  vmovaps [rsp+0x70], xmm8
00007175dc9d1da3  vmovaps [rsp+0x80], xmm9
00007175dc9d1dac  vmovaps [rsp+0x90], xmm10
00007175dc9d1db5  vmovaps [rsp+0xA0], xmm11
00007175dc9d1dbe  vmovaps [rsp+0xB0], xmm12
00007175dc9d1dc7  vmovaps [rsp+0xC0], xmm13
00007175dc9d1dd0  vmovaps [rsp+0xD0], xmm14
00007175dc9d1dd9  vmovaps [rsp+0xE0], xmm15
00007175dc9d1de2  sub rsp, 0x30
00007175dc9d1de6  movaps [rsp], xmm1
00007175dc9d1dea  movaps [rsp+0x10], xmm14
00007175dc9d1df0  movaps [rsp+0x20], xmm15
00007175dc9d1df6  lea rdi, [rsp]
00007175dc9d1dfa  mov esi, 0x00
00007175dc9d1dff  mov rax, 0x622B29CAF530
00007175dc9d1e09  call rax
00007175dc9d1e0b  movaps xmm1, [rsp]
00007175dc9d1e0f  add rsp, 0x30
00007175dc9d1e13  vmovaps xmm0, [rsp]
00007175dc9d1e18  vmovaps xmm2, [rsp+0x10]
00007175dc9d1e1e  vmovaps xmm3, [rsp+0x20]
00007175dc9d1e24  vmovaps xmm4, [rsp+0x30]
00007175dc9d1e2a  vmovaps xmm5, [rsp+0x40]
00007175dc9d1e30  vmovaps xmm6, [rsp+0x50]
00007175dc9d1e36  vmovaps xmm7, [rsp+0x60]
00007175dc9d1e3c  vmovaps xmm8, [rsp+0x70]
00007175dc9d1e42  vmovaps xmm9, [rsp+0x80]
00007175dc9d1e4b  vmovaps xmm10, [rsp+0x90]
00007175dc9d1e54  vmovaps xmm11, [rsp+0xA0]
00007175dc9d1e5d  vmovaps xmm12, [rsp+0xB0]
00007175dc9d1e66  vmovaps xmm13, [rsp+0xC0]
00007175dc9d1e6f  vmovaps xmm14, [rsp+0xD0]
00007175dc9d1e78  vmovaps xmm15, [rsp+0xE0]
00007175dc9d1e81  add rsp, 0xF0
00007175dc9d1e88  pop r11
00007175dc9d1e8a  pop r10
00007175dc9d1e8c  pop r9
00007175dc9d1e8e  pop r8
00007175dc9d1e90  pop rsi
00007175dc9d1e91  pop rdi
00007175dc9d1e92  pop rdx
00007175dc9d1e93  pop rcx
00007175dc9d1e94  pop rax
00007175dc9d1e95  add rsp, 0x08
00007175dc9d1e99  jmp 0x00007175DC9D1B4E
00007175dc9d1e9e  call 0x00007175DC7FF540
00007175dc9d1ea3  jmp 0x00007175DC9D1B61
00007175dc9d1ea8  int3
00007175dc9d1ea9  nop [rax], eax
00007175dc9d1eb0  movaps xmm1, [r15+0x180]
00007175dc9d1eb8  vpmovqd xmm15, xmm1
00007175dc9d1ebe  pxor xmm14, xmm14
00007175dc9d1ec3  punpcklqdq xmm15, xmm14
00007175dc9d1ec8  movaps [r15+0x210], xmm15
00007175dc9d1ed0  movq xmm15, qword ptr [r15+0x140]
00007175dc9d1ed9  movq xmm14, qword ptr [r15+0x120]
00007175dc9d1ee2  psubd xmm15, xmm14
00007175dc9d1ee7  movq xmm15, xmm15
00007175dc9d1eec  movaps xmm13, [r15+0x170]
00007175dc9d1ef4  paddq xmm1, xmm13
00007175dc9d1ef9  movaps [r15+0x180], xmm1
00007175dc9d1f01  movq xmm1, qword ptr [r15+0x160]
00007175dc9d1f0a  paddd xmm14, xmm1
00007175dc9d1f0f  movq xmm14, xmm14
00007175dc9d1f14  movq xmm14, xmm14
00007175dc9d1f19  movaps [r15+0x120], xmm14
00007175dc9d1f21  pmovzxdq xmm15, xmm15
00007175dc9d1f27  psllq xmm15, 0x00
00007175dc9d1f2d  movq xmm1, qword ptr [r15+0x210]
00007175dc9d1f36  movq xmm14, qword ptr [r15+0x110]
00007175dc9d1f3f  paddd xmm1, xmm14
00007175dc9d1f44  movq xmm1, xmm1
00007175dc9d1f48  vcvtuqq2pd xmm15, xmm15
00007175dc9d1f4e  pmovzxdq xmm1, xmm1
00007175dc9d1f53  psllq xmm1, 0x00
00007175dc9d1f58  vcvtuqq2pd xmm1, xmm1
00007175dc9d1f5e  movaps xmm14, [r15+0x150]
00007175dc9d1f66  movaps xmm13, xmm15
00007175dc9d1f6a  mulpd xmm13, xmm14
00007175dc9d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d1f75  ptest xmm12, xmm12
00007175dc9d1f7b  jnz 0x00007175DC9D205E
00007175dc9d1f81  movaps [r15+0x220], xmm13
00007175dc9d1f89  mov rax, [r15+0x48]
00007175dc9d1f8d  mov r14, [r15+0x50]
00007175dc9d1f91  lea r12, [r14+rax*1]
00007175dc9d1f95  movups [r13+r12*1], xmm13
00007175dc9d1f9b  movaps xmm15, [r15+0x130]
00007175dc9d1fa3  movaps xmm14, xmm1
00007175dc9d1fa7  mulpd xmm14, xmm15
00007175dc9d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007175dc9d1fb2  ptest xmm13, xmm13
00007175dc9d1fb8  jnz 0x00007175DC9D21AC
00007175dc9d1fbe  movaps [r15+0x210], xmm14
00007175dc9d1fc6  mov r14, [r15+0x40]
00007175dc9d1fca  lea r12, [r14+rax*1]
00007175dc9d1fce  movups [r13+r12*1], xmm14
00007175dc9d1fd4  lea r14, [rax+0x10]
00007175dc9d1fd8  mov [r15+0x48], r14
00007175dc9d1fdc  xor eax, eax
00007175dc9d1fde  mov r12d, 0x200
00007175dc9d1fe4  cmp r14, r12
00007175dc9d1fe7  cmc
00007175dc9d1fe8  lahf
00007175dc9d1fe9  seto al
00007175dc9d1fec  mov [r15+0x108], eax
00007175dc9d1ff3  mov eax, [r15+0x108]
00007175dc9d1ffa  sahf
00007175dc9d1ffb  jnz 0x00007175DC9D202D
00007175dc9d1ffd  cmp dword ptr [r15+0x318], 0x00
00007175dc9d2005  jz 0x00007175DC9D2300
00007175dc9d200b  nop [rax+rax*1], ax
00007175dc9d2014  nop [rax+rax*1], eax
00007175dc9d201c  mov eax, 0x410480
00007175dc9d2021  mov [r15+0x100], rax
00007175dc9d2028  jmp 0x00007175DC7FE110
00007175dc9d202d  cmp dword ptr [r15+0x318], 0x00
00007175dc9d2035  jz 0x00007175DC9D1EB0
00007175dc9d203b  nop [rax+rax*1], ax
00007175dc9d2044  nop [rax+rax*1], eax
00007175dc9d204c  mov eax, 0x410440
00007175dc9d2051  mov [r15+0x100], rax
00007175dc9d2058  jmp 0x00007175DC7FE110
00007175dc9d205d  int3
00007175dc9d205e  sub rsp, 0x08
00007175dc9d2062  push rax
00007175dc9d2063  push rcx
00007175dc9d2064  push rdx
00007175dc9d2065  push rdi
00007175dc9d2066  push rsi
00007175dc9d2067  push r8
00007175dc9d2069  push r9
00007175dc9d206b  push r10
00007175dc9d206d  push r11
00007175dc9d206f  sub rsp, 0xF0
00007175dc9d2076  vmovaps [rsp], xmm0
00007175dc9d207b  vmovaps [rsp+0x10], xmm1
00007175dc9d2081  vmovaps [rsp+0x20], xmm2
00007175dc9d2087  vmovaps [rsp+0x30], xmm3
00007175dc9d208d  vmovaps [rsp+0x40], xmm4
00007175dc9d2093  vmovaps [rsp+0x50], xmm5
00007175dc9d2099  vmovaps [rsp+0x60], xmm6
00007175dc9d209f  vmovaps [rsp+0x70], xmm7
00007175dc9d20a5  vmovaps [rsp+0x80], xmm8
00007175dc9d20ae  vmovaps [rsp+0x90], xmm9
00007175dc9d20b7  vmovaps [rsp+0xA0], xmm10
00007175dc9d20c0  vmovaps [rsp+0xB0], xmm11
00007175dc9d20c9  vmovaps [rsp+0xC0], xmm12
00007175dc9d20d2  vmovaps [rsp+0xD0], xmm14
00007175dc9d20db  vmovaps [rsp+0xE0], xmm15
00007175dc9d20e4  sub rsp, 0x30
00007175dc9d20e8  movaps [rsp], xmm13
00007175dc9d20ed  movaps [rsp+0x10], xmm15
00007175dc9d20f3  movaps [rsp+0x20], xmm14
00007175dc9d20f9  lea rdi, [rsp]
00007175dc9d20fd  mov esi, 0x00
00007175dc9d2102  mov rax, 0x622B29CAF530
00007175dc9d210c  call rax
00007175dc9d210e  movaps xmm13, [rsp]
00007175dc9d2113  add rsp, 0x30
00007175dc9d2117  vmovaps xmm0, [rsp]
00007175dc9d211c  vmovaps xmm1, [rsp+0x10]
00007175dc9d2122  vmovaps xmm2, [rsp+0x20]
00007175dc9d2128  vmovaps xmm3, [rsp+0x30]
00007175dc9d212e  vmovaps xmm4, [rsp+0x40]
00007175dc9d2134  vmovaps xmm5, [rsp+0x50]
00007175dc9d213a  vmovaps xmm6, [rsp+0x60]
00007175dc9d2140  vmovaps xmm7, [rsp+0x70]
00007175dc9d2146  vmovaps xmm8, [rsp+0x80]
00007175dc9d214f  vmovaps xmm9, [rsp+0x90]
00007175dc9d2158  vmovaps xmm10, [rsp+0xA0]
00007175dc9d2161  vmovaps xmm11, [rsp+0xB0]
00007175dc9d216a  vmovaps xmm12, [rsp+0xC0]
00007175dc9d2173  vmovaps xmm14, [rsp+0xD0]
00007175dc9d217c  vmovaps xmm15, [rsp+0xE0]
00007175dc9d2185  add rsp, 0xF0
00007175dc9d218c  pop r11
00007175dc9d218e  pop r10
00007175dc9d2190  pop r9
00007175dc9d2192  pop r8
00007175dc9d2194  pop rsi
00007175dc9d2195  pop rdi
00007175dc9d2196  pop rdx
00007175dc9d2197  pop rcx
00007175dc9d2198  pop rax
00007175dc9d2199  add rsp, 0x08
00007175dc9d219d  jmp 0x00007175DC9D1F81
00007175dc9d21a2  call 0x00007175DC8C2240
00007175dc9d21a7  jmp 0x00007175DC9D1F9B
00007175dc9d21ac  sub rsp, 0x08
00007175dc9d21b0  push rax
00007175dc9d21b1  push rcx
00007175dc9d21b2  push rdx
00007175dc9d21b3  push rdi
00007175dc9d21b4  push rsi
00007175dc9d21b5  push r8
00007175dc9d21b7  push r9
00007175dc9d21b9  push r10
00007175dc9d21bb  push r11
00007175dc9d21bd  sub rsp, 0xF0
00007175dc9d21c4  vmovaps [rsp], xmm0
00007175dc9d21c9  vmovaps [rsp+0x10], xmm1
00007175dc9d21cf  vmovaps [rsp+0x20], xmm2
00007175dc9d21d5  vmovaps [rsp+0x30], xmm3
00007175dc9d21db  vmovaps [rsp+0x40], xmm4
00007175dc9d21e1  vmovaps [rsp+0x50], xmm5
00007175dc9d21e7  vmovaps [rsp+0x60], xmm6
00007175dc9d21ed  vmovaps [rsp+0x70], xmm7
00007175dc9d21f3  vmovaps [rsp+0x80], xmm8
00007175dc9d21fc  vmovaps [rsp+0x90], xmm9
00007175dc9d2205  vmovaps [rsp+0xA0], xmm10
00007175dc9d220e  vmovaps [rsp+0xB0], xmm11
00007175dc9d2217  vmovaps [rsp+0xC0], xmm12
00007175dc9d2220  vmovaps [rsp+0xD0], xmm13
00007175dc9d2229  vmovaps [rsp+0xE0], xmm15
00007175dc9d2232  sub rsp, 0x30
00007175dc9d2236  movaps [rsp], xmm14
00007175dc9d223b  movaps [rsp+0x10], xmm1
00007175dc9d2240  movaps [rsp+0x20], xmm15
00007175dc9d2246  lea rdi, [rsp]
00007175dc9d224a  mov esi, 0x00
00007175dc9d224f  mov rax, 0x622B29CAF530
00007175dc9d2259  call rax
00007175dc9d225b  movaps xmm14, [rsp]
00007175dc9d2260  add rsp, 0x30
00007175dc9d2264  vmovaps xmm0, [rsp]
00007175dc9d2269  vmovaps xmm1, [rsp+0x10]
00007175dc9d226f  vmovaps xmm2, [rsp+0x20]
00007175dc9d2275  vmovaps xmm3, [rsp+0x30]
00007175dc9d227b  vmovaps xmm4, [rsp+0x40]
00007175dc9d2281  vmovaps xmm5, [rsp+0x50]
00007175dc9d2287  vmovaps xmm6, [rsp+0x60]
00007175dc9d228d  vmovaps xmm7, [rsp+0x70]
00007175dc9d2293  vmovaps xmm8, [rsp+0x80]
00007175dc9d229c  vmovaps xmm9, [rsp+0x90]
00007175dc9d22a5  vmovaps xmm10, [rsp+0xA0]
00007175dc9d22ae  vmovaps xmm11, [rsp+0xB0]
00007175dc9d22b7  vmovaps xmm12, [rsp+0xC0]
00007175dc9d22c0  vmovaps xmm13, [rsp+0xD0]
00007175dc9d22c9  vmovaps xmm15, [rsp+0xE0]
00007175dc9d22d2  add rsp, 0xF0
00007175dc9d22d9  pop r11
00007175dc9d22db  pop r10
00007175dc9d22dd  pop r9
00007175dc9d22df  pop r8
00007175dc9d22e1  pop rsi
00007175dc9d22e2  pop rdi
00007175dc9d22e3  pop rdx
00007175dc9d22e4  pop rcx
00007175dc9d22e5  pop rax
00007175dc9d22e6  add rsp, 0x08
00007175dc9d22ea  jmp 0x00007175DC9D1FBE
00007175dc9d22ef  call 0x00007175DC8C34C0
00007175dc9d22f4  jmp 0x00007175DC9D1FD4
00007175dc9d22f9  int3
00007175dc9d22fa  nop [rax+rax*1], ax
00007175dc9d2300  mov rax, [r15+0x50]
00007175dc9d2304  movups xmm1, [r13+rax*1]
00007175dc9d230a  lea r14, [rax+0x10]
00007175dc9d230e  movups xmm15, [r13+r14*1]
00007175dc9d2314  mov qword ptr [r15+0x48], 0x00
00007175dc9d231c  lea r14, [rax+0x40]
00007175dc9d2320  movups xmm14, [r13+r14*1]
00007175dc9d2326  lea r14, [rax+0x50]
00007175dc9d232a  movups xmm13, [r13+r14*1]
00007175dc9d2330  lea r14, [rax+0x80]
00007175dc9d2337  movups xmm12, [r13+r14*1]
00007175dc9d233d  lea r14, [rax+0x90]
00007175dc9d2344  movups xmm11, [r13+r14*1]
00007175dc9d234a  mov r14, [r15+0xF8]
00007175dc9d2351  movups [r13+r14*1], xmm1
00007175dc9d2357  lea r12, [rax+0x20]
00007175dc9d235b  movups xmm1, [r13+r12*1]
00007175dc9d2361  lea r12, [rax+0x30]
00007175dc9d2365  movups xmm10, [r13+r12*1]
00007175dc9d236b  lea r12, [rax+0xC0]
00007175dc9d2372  movups xmm9, [r13+r12*1]
00007175dc9d2378  lea r12, [rax+0xD0]
00007175dc9d237f  movups xmm8, [r13+r12*1]
00007175dc9d2385  lea r12, [rax+0x100]
00007175dc9d238c  movups xmm7, [r13+r12*1]
00007175dc9d2392  lea r12, [rax+0x110]
00007175dc9d2399  movups xmm6, [r13+r12*1]
00007175dc9d239f  lea r12, [rax+0x140]
00007175dc9d23a6  movups xmm5, [r13+r12*1]
00007175dc9d23ac  lea r12, [rax+0x150]
00007175dc9d23b3  movups xmm4, [r13+r12*1]
00007175dc9d23b9  lea r12, [r14+0xB0]
00007175dc9d23c0  movups [r13+r12*1], xmm10
00007175dc9d23c6  lea r12, [r14+0xC0]
00007175dc9d23cd  movups [r13+r12*1], xmm1
00007175dc9d23d3  lea r12, [rax+0x180]
00007175dc9d23da  movups xmm1, [r13+r12*1]
00007175dc9d23e0  lea r12, [rax+0x190]
00007175dc9d23e7  movups xmm10, [r13+r12*1]
00007175dc9d23ed  lea r12, [rax+0x1C0]
00007175dc9d23f4  movups xmm3, [r13+r12*1]
00007175dc9d23fa  lea r12, [rax+0x1D0]
00007175dc9d2401  movups xmm2, [r13+r12*1]
00007175dc9d2407  lea r12, [rax+0x60]
00007175dc9d240b  vmovaps [rsp+0x10], xmm1
00007175dc9d2411  movups xmm1, [r13+r12*1]
00007175dc9d2417  lea r12, [rax+0x70]
00007175dc9d241b  vmovaps [rsp+0x20], xmm1
00007175dc9d2421  movups xmm1, [r13+r12*1]
00007175dc9d2427  lea r12, [r14+0x70]
00007175dc9d242b  movups [r13+r12*1], xmm10
00007175dc9d2431  lea r12, [r14+0x80]
00007175dc9d2438  vmovaps xmm10, [rsp+0x10]
00007175dc9d243e  movups [r13+r12*1], xmm10
00007175dc9d2444  lea r12, [rax+0xA0]
00007175dc9d244b  movups xmm10, [r13+r12*1]
00007175dc9d2451  lea r12, [rax+0xB0]
00007175dc9d2458  vmovaps [rsp+0x10], xmm1
00007175dc9d245e  movups xmm1, [r13+r12*1]
00007175dc9d2464  lea r12, [r14+0x90]
00007175dc9d246b  movups [r13+r12*1], xmm2
00007175dc9d2471  lea r12, [r14+0xA0]
00007175dc9d2478  movups [r13+r12*1], xmm3
00007175dc9d247e  lea r12, [rax+0xE0]
00007175dc9d2485  movups xmm3, [r13+r12*1]
00007175dc9d248b  lea r12, [rax+0xF0]
00007175dc9d2492  movups xmm2, [r13+r12*1]
00007175dc9d2498  lea r12, [rax+0x120]
00007175dc9d249f  vmovaps [rsp+0x30], xmm1
00007175dc9d24a5  movups xmm1, [r13+r12*1]
00007175dc9d24ab  lea r12, [rax+0x130]
00007175dc9d24b2  vmovaps [rsp+0x40], xmm1
00007175dc9d24b8  movups xmm1, [r13+r12*1]
00007175dc9d24be  vmovaps [rsp+0x50], xmm1
00007175dc9d24c4  vmovaps xmm1, [rsp+0x40]
00007175dc9d24ca  movaps [r15+0x190], xmm1
00007175dc9d24d2  lea r12, [rax+0x160]
00007175dc9d24d9  vmovaps [rsp+0x40], xmm1
00007175dc9d24df  movups xmm1, [r13+r12*1]
00007175dc9d24e5  lea r12, [rax+0x170]
00007175dc9d24ec  vmovaps [rsp+0x60], xmm1
00007175dc9d24f2  movups xmm1, [r13+r12*1]
00007175dc9d24f8  lea r12, [rax+0x1A0]
00007175dc9d24ff  vmovaps [rsp+0x70], xmm1
00007175dc9d2505  movups xmm1, [r13+r12*1]
00007175dc9d250b  lea r12, [rax+0x1B0]
00007175dc9d2512  vmovaps [rsp+0x80], xmm1
00007175dc9d251b  movups xmm1, [r13+r12*1]
00007175dc9d2521  lea r12, [rax+0x1E0]
00007175dc9d2528  vmovaps [rsp+0x90], xmm1
00007175dc9d2531  movups xmm1, [r13+r12*1]
00007175dc9d2537  lea r12, [rax+0x1F0]
00007175dc9d253e  vmovaps [rsp+0xA0], xmm1
00007175dc9d2547  movups xmm1, [r13+r12*1]
00007175dc9d254d  mov qword ptr [r15+0x50], 0x432190
00007175dc9d2555  lea rax, [r14+0x50]
00007175dc9d2559  vmovaps [rsp+0xB0], xmm1
00007175dc9d2562  vmovaps xmm1, [rsp+0x60]
00007175dc9d2568  movups [r13+rax*1], xmm1
00007175dc9d256e  lea rax, [r14+0x60]
00007175dc9d2572  movups [r13+rax*1], xmm5
00007175dc9d2578  lea rax, [r14+0x40]
00007175dc9d257c  vmovaps xmm1, [rsp+0x70]
00007175dc9d2582  movups [r13+rax*1], xmm1
00007175dc9d2588  lea rax, [r14+0x20]
00007175dc9d258c  vmovaps xmm1, [rsp+0xA0]
00007175dc9d2595  movups [r13+rax*1], xmm1
00007175dc9d259b  lea rax, [r14+0x30]
00007175dc9d259f  vmovaps xmm1, [rsp+0x90]
00007175dc9d25a8  movups [r13+rax*1], xmm1
00007175dc9d25ae  lea rax, [r14+0x10]
00007175dc9d25b2  vmovaps xmm1, [rsp+0xB0]
00007175dc9d25bb  movups [r13+rax*1], xmm1
00007175dc9d25c1  mov rax, [r15+0x40]
00007175dc9d25c5  vxorps xmm1, xmm1, xmm1
00007175dc9d25c9  vpbroadcastq xmm1, xmm1
00007175dc9d25ce  vxorps xmm5, xmm5, xmm5
00007175dc9d25d2  vpbroadcastq xmm5, xmm5
00007175dc9d25d7  lea r12, [rax+0x30]
00007175dc9d25db  mov r11, [r13+r12*1]
00007175dc9d25e0  lea r12, [rax+0x38]
00007175dc9d25e4  mov r10, [r13+r12*1]
00007175dc9d25e9  vmovaps [rsp+0x60], xmm1
00007175dc9d25ef  movq xmm1, r11
00007175dc9d25f4  vmovaps [rsp+0x70], xmm1
00007175dc9d25fa  movq xmm1, r10
00007175dc9d25ff  vmovaps [rsp+0x90], xmm1
00007175dc9d2608  vmovaps xmm1, [rsp+0x70]
00007175dc9d260e  movq xmm1, xmm1
00007175dc9d2612  vmovaps [rsp+0x70], xmm1
00007175dc9d2618  vmovaps xmm1, [rsp+0x90]
00007175dc9d2621  movq xmm1, xmm1
00007175dc9d2625  vmovaps [rsp+0x90], xmm1
00007175dc9d262e  movq xmm1, xmm1
00007175dc9d2632  movaps [r15+0x270], xmm1
00007175dc9d263a  vmovaps [rsp+0xA0], xmm7
00007175dc9d2643  vmovaps xmm1, [rsp+0xA0]
00007175dc9d264c  por xmm7, xmm1
00007175dc9d2650  lea r12, [rax+0x20]
00007175dc9d2654  mov r11, [r13+r12*1]
00007175dc9d2659  lea r12, [rax+0x28]
00007175dc9d265d  mov r10, [r13+r12*1]
00007175dc9d2662  movq xmm1, r11
00007175dc9d2667  vmovaps [rsp+0xA0], xmm1
00007175dc9d2670  movq xmm1, r10
00007175dc9d2675  vmovaps [rsp+0xB0], xmm1
00007175dc9d267e  vmovaps xmm1, [rsp+0xA0]
00007175dc9d2687  movq xmm1, xmm1
00007175dc9d268b  vmovaps [rsp+0xA0], xmm1
00007175dc9d2694  vmovaps xmm1, [rsp+0xB0]
00007175dc9d269d  movq xmm1, xmm1
00007175dc9d26a1  vmovaps [rsp+0xB0], xmm2
00007175dc9d26aa  vmovaps [rsp+0xC0], xmm1
00007175dc9d26b3  vmovaps xmm1, [rsp+0xB0]
00007175dc9d26bc  por xmm2, xmm1
00007175dc9d26c0  vmovaps [rsp+0xB0], xmm3
00007175dc9d26c9  vmovaps xmm1, [rsp+0xB0]
00007175dc9d26d2  por xmm3, xmm1
00007175dc9d26d6  vmovaps [rsp+0xB0], xmm4
00007175dc9d26df  vmovaps xmm1, [rsp+0xB0]
00007175dc9d26e8  por xmm4, xmm1
00007175dc9d26ec  vmovaps [rsp+0xB0], xmm9
00007175dc9d26f5  vmovaps xmm1, [rsp+0xB0]
00007175dc9d26fe  por xmm9, xmm1
00007175dc9d2703  lea r12, [rax+0x10]
00007175dc9d2707  mov r11, [r13+r12*1]
00007175dc9d270c  lea r12, [rax+0x18]
00007175dc9d2710  mov r10, [r13+r12*1]
00007175dc9d2715  movq xmm1, r11
00007175dc9d271a  vmovaps [rsp+0xB0], xmm1
00007175dc9d2723  movq xmm1, r10
00007175dc9d2728  vmovaps [rsp+0xD0], xmm1
00007175dc9d2731  vmovaps xmm1, [rsp+0xB0]
00007175dc9d273a  movq xmm1, xmm1
00007175dc9d273e  vmovaps [rsp+0xB0], xmm1
00007175dc9d2747  vmovaps xmm1, [rsp+0xD0]
00007175dc9d2750  movq xmm1, xmm1
00007175dc9d2754  vmovaps [rsp+0xD0], xmm1
00007175dc9d275d  vmovaps xmm1, [rsp+0x80]
00007175dc9d2766  vmovaps [rsp+0xE0], xmm15
00007175dc9d276f  vmovaps xmm15, [rsp+0x80]
00007175dc9d2778  por xmm1, xmm15
00007175dc9d277d  vmovaps xmm15, [rsp+0x10]
00007175dc9d2783  vmovaps [rsp+0x80], xmm1
00007175dc9d278c  vmovaps xmm1, [rsp+0x10]
00007175dc9d2792  por xmm15, xmm1
00007175dc9d2797  vmovaps xmm1, [rsp+0x20]
00007175dc9d279d  vmovaps [rsp+0x10], xmm15
00007175dc9d27a3  vmovaps xmm15, [rsp+0x20]
00007175dc9d27a9  por xmm1, xmm15
00007175dc9d27ae  vmovaps [rsp+0x20], xmm6
00007175dc9d27b4  vmovaps xmm15, [rsp+0x20]
00007175dc9d27ba  por xmm6, xmm15
00007175dc9d27bf  vmovaps [rsp+0x20], xmm11
00007175dc9d27c5  vmovaps xmm15, [rsp+0x20]
00007175dc9d27cb  por xmm11, xmm15
00007175dc9d27d0  vmovaps [rsp+0x20], xmm13
00007175dc9d27d6  vmovaps xmm15, [rsp+0x20]
00007175dc9d27dc  por xmm13, xmm15
00007175dc9d27e1  vmovaps [rsp+0x20], xmm14
00007175dc9d27e7  vmovaps xmm15, [rsp+0x20]
00007175dc9d27ed  por xmm14, xmm15
00007175dc9d27f2  mov r12, [r13+rax*1]
00007175dc9d27f7  vmovq xmm15, r12
00007175dc9d27fc  vpbroadcastq xmm15, xmm15
00007175dc9d2801  vmovaps [rsp+0x20], xmm1
00007175dc9d2807  vxorps xmm1, xmm1, xmm1
00007175dc9d280b  vpbroadcastq xmm1, xmm1
00007175dc9d2810  vmovaps [rsp+0xF0], xmm1
00007175dc9d2819  movups xmm1, [r13+r14*1]
00007175dc9d281f  vmovaps [rsp+0x100], xmm1
00007175dc9d2828  vxorps xmm1, xmm1, xmm1
00007175dc9d282c  vpbroadcastq xmm1, xmm1
00007175dc9d2831  lea r12, [rax+0x08]
00007175dc9d2835  mov rax, [r13+r12*1]
00007175dc9d283a  vmovaps [rsp+0x110], xmm1
00007175dc9d2843  movq xmm1, rax
00007175dc9d2848  movaps [r15+0x240], xmm1
00007175dc9d2850  mov qword ptr [r15+0x60], 0x432190
00007175dc9d2858  mov qword ptr [r15+0x58], 0x40
00007175dc9d2860  vmovaps xmm1, [rsp+0x60]
00007175dc9d2866  vmovaps [rsp+0x60], xmm15
00007175dc9d286c  vmovaps xmm15, [rsp+0x100]
00007175dc9d2875  vmovaps [rsp+0x100], xmm14
00007175dc9d287e  vmovaps xmm14, [rsp+0x60]
00007175dc9d2884  vmovaps [rsp+0x60], xmm13
00007175dc9d288a  vmovaps [rsp+0x120], xmm12
00007175dc9d2893  movaps xmm13, xmm1
00007175dc9d2897  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d28a2  vptest xmm12, xmm12
00007175dc9d28a7  jnz 0x00007175DC9D3482
00007175dc9d28ad  vmovaps xmm1, [rsp+0xE0]
00007175dc9d28b6  movaps xmm15, xmm5
00007175dc9d28ba  vfmadd231pd xmm15, xmm1, xmm14
00007175dc9d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007175dc9d28c5  vptest xmm12, xmm12
00007175dc9d28ca  jnz 0x00007175DC9D35DB
00007175dc9d28d0  vmovaps xmm12, [rsp+0x50]
00007175dc9d28d6  vmovaps xmm5, [rsp+0x50]
00007175dc9d28dc  por xmm12, xmm5
00007175dc9d28e1  vmovaps xmm5, [rsp+0x30]
00007175dc9d28e7  vmovaps [rsp+0x50], xmm1
00007175dc9d28ed  vmovaps xmm1, [rsp+0x30]
00007175dc9d28f3  por xmm5, xmm1
00007175dc9d28f7  vmovaps [rsp+0x30], xmm10
00007175dc9d28fd  vmovaps xmm1, [rsp+0x30]
00007175dc9d2903  por xmm10, xmm1
00007175dc9d2908  vmovaps [rsp+0x30], xmm8
00007175dc9d290e  vmovaps xmm1, [rsp+0x30]
00007175dc9d2914  por xmm8, xmm1
00007175dc9d2919  vmovaps xmm1, [rsp+0x120]
00007175dc9d2922  vmovaps [rsp+0x30], xmm15
00007175dc9d2928  vmovaps xmm15, [rsp+0x120]
00007175dc9d2931  por xmm1, xmm15
00007175dc9d2936  vmovaps xmm15, [rsp+0x50]
00007175dc9d293c  vmovaps [rsp+0xE0], xmm1
00007175dc9d2945  vmovaps xmm1, [rsp+0x50]
00007175dc9d294b  por xmm15, xmm1
00007175dc9d2950  lea rax, [r14+0xC0]
00007175dc9d2957  movups xmm1, [r13+rax*1]
00007175dc9d295d  xor eax, eax
00007175dc9d295f  mov r12d, 0x40
00007175dc9d2965  mov r11d, 0x200
00007175dc9d296b  cmp r12, r11
00007175dc9d296e  cmc
00007175dc9d296f  lahf
00007175dc9d2970  seto al
00007175dc9d2973  mov [r15+0x108], eax
00007175dc9d297a  vmovaps [rsp+0x50], xmm1
00007175dc9d2980  vmovaps xmm1, [rsp+0xF0]
00007175dc9d2989  vmovaps [rsp+0xF0], xmm15
00007175dc9d2992  vmovaps xmm15, [rsp+0x50]
00007175dc9d2998  vmovaps [rsp+0x50], xmm13
00007175dc9d299e  vmovaps [rsp+0x120], xmm12
00007175dc9d29a7  movaps xmm13, xmm1
00007175dc9d29ab  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d29b6  vptest xmm12, xmm12
00007175dc9d29bb  jnz 0x00007175DC9D373D
00007175dc9d29c1  lea rax, [r14+0xB0]
00007175dc9d29c8  movups xmm1, [r13+rax*1]
00007175dc9d29ce  vmovaps xmm15, [rsp+0x110]
00007175dc9d29d7  vmovaps [rsp+0x110], xmm13
00007175dc9d29e0  movaps xmm12, xmm15
00007175dc9d29e4  vfmadd231pd xmm12, xmm1, xmm14
00007175dc9d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007175dc9d29ef  vptest xmm13, xmm13
00007175dc9d29f4  jnz 0x00007175DC9D38A0
00007175dc9d29fa  vmovaps xmm1, [rsp+0x100]
00007175dc9d2a03  vmovaps xmm15, [rsp+0x100]
00007175dc9d2a0c  por xmm1, xmm15
00007175dc9d2a11  movaps [r15+0x210], xmm1
00007175dc9d2a19  vmovaps xmm15, [rsp+0x60]
00007175dc9d2a1f  vmovaps xmm14, [rsp+0x60]
00007175dc9d2a25  por xmm15, xmm14
00007175dc9d2a2a  movaps [r15+0x1C0], xmm15
00007175dc9d2a32  vmovaps [rsp+0x60], xmm11
00007175dc9d2a38  vmovaps xmm14, [rsp+0x60]
00007175dc9d2a3e  por xmm11, xmm14
00007175dc9d2a43  movaps [r15+0x280], xmm11
00007175dc9d2a4b  vmovaps [rsp+0x60], xmm6
00007175dc9d2a51  vmovaps xmm14, [rsp+0x60]
00007175dc9d2a57  por xmm6, xmm14
00007175dc9d2a5c  movaps [r15+0x2A0], xmm6
00007175dc9d2a64  vmovaps xmm14, [rsp+0x20]
00007175dc9d2a6a  vmovaps xmm13, [rsp+0x20]
00007175dc9d2a70  por xmm14, xmm13
00007175dc9d2a75  movaps [r15+0x2E0], xmm14
00007175dc9d2a7d  vmovaps xmm13, [rsp+0x10]
00007175dc9d2a83  vmovaps [rsp+0x20], xmm1
00007175dc9d2a89  vmovaps xmm1, [rsp+0x10]
00007175dc9d2a8f  por xmm13, xmm1
00007175dc9d2a94  movaps [r15+0x1F0], xmm13
00007175dc9d2a9c  vmovaps xmm1, [rsp+0xF0]
00007175dc9d2aa5  vmovaps [rsp+0x10], xmm15
00007175dc9d2aab  vmovaps xmm15, [rsp+0xF0]
00007175dc9d2ab4  por xmm1, xmm15
00007175dc9d2ab9  movaps [r15+0x250], xmm1
00007175dc9d2ac1  vmovaps xmm1, [rsp+0xE0]
00007175dc9d2aca  vmovaps xmm15, [rsp+0xE0]
00007175dc9d2ad3  por xmm1, xmm15
00007175dc9d2ad8  movaps [r15+0x260], xmm1
00007175dc9d2ae0  vmovaps [rsp+0x60], xmm8
00007175dc9d2ae6  vmovaps xmm15, [rsp+0x60]
00007175dc9d2aec  por xmm8, xmm15
00007175dc9d2af1  movaps [r15+0x290], xmm8
00007175dc9d2af9  vmovaps [rsp+0x60], xmm10
00007175dc9d2aff  vmovaps xmm15, [rsp+0x60]
00007175dc9d2b05  por xmm10, xmm15
00007175dc9d2b0a  movaps [r15+0x2C0], xmm10
00007175dc9d2b12  movq xmm15, qword ptr [r15+0x240]
00007175dc9d2b1b  vmovaps [rsp+0x60], xmm15
00007175dc9d2b21  vpermilpd xmm15, xmm15, 0x00
00007175dc9d2b27  vmovaps [rsp+0xE0], xmm1
00007175dc9d2b30  vmovaps xmm1, [rsp+0x50]
00007175dc9d2b36  vmovaps [rsp+0x50], xmm15
00007175dc9d2b3c  vmovaps xmm15, [rsp+0x20]
00007175dc9d2b42  vmovaps [rsp+0x20], xmm14
00007175dc9d2b48  vmovaps xmm14, [rsp+0x50]
00007175dc9d2b4e  vmovaps [rsp+0x50], xmm13
00007175dc9d2b54  vmovaps [rsp+0xF0], xmm12
00007175dc9d2b5d  movaps xmm13, xmm1
00007175dc9d2b61  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d2b6c  vptest xmm12, xmm12
00007175dc9d2b71  jnz 0x00007175DC9D39F9
00007175dc9d2b77  vmovaps xmm1, [rsp+0x60]
00007175dc9d2b7d  vpermilpd xmm1, xmm1, 0x00
00007175dc9d2b83  vmovaps xmm15, [rsp+0x110]
00007175dc9d2b8c  vmovaps xmm14, [rsp+0x20]
00007175dc9d2b92  vmovaps [rsp+0x20], xmm13
00007175dc9d2b98  movaps xmm12, xmm15
00007175dc9d2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007175dc9d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007175dc9d2ba7  vptest xmm13, xmm13
00007175dc9d2bac  jnz 0x00007175DC9D3B52
00007175dc9d2bb2  vmovaps xmm1, [rsp+0x60]
00007175dc9d2bb8  vpermilpd xmm1, xmm1, 0x00
00007175dc9d2bbe  vmovaps xmm15, [rsp+0x30]
00007175dc9d2bc4  vmovaps xmm14, [rsp+0x10]
00007175dc9d2bca  vmovaps [rsp+0x10], xmm12
00007175dc9d2bd0  movaps xmm13, xmm15
00007175dc9d2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007175dc9d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d2bdf  vptest xmm12, xmm12
00007175dc9d2be4  jnz 0x00007175DC9D3CAB
00007175dc9d2bea  vmovaps [rsp+0x30], xmm5
00007175dc9d2bf0  vmovaps xmm1, [rsp+0x30]
00007175dc9d2bf6  por xmm5, xmm1
00007175dc9d2bfa  movaps [r15+0x1D0], xmm5
00007175dc9d2c02  vmovaps xmm1, [rsp+0x60]
00007175dc9d2c08  vpermilpd xmm1, xmm1, 0x00
00007175dc9d2c0e  vmovaps xmm15, [rsp+0xF0]
00007175dc9d2c17  vmovaps xmm14, [rsp+0x50]
00007175dc9d2c1d  vmovaps [rsp+0x30], xmm13
00007175dc9d2c23  movaps xmm12, xmm15
00007175dc9d2c27  vfmadd231pd xmm12, xmm14, xmm1
00007175dc9d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007175dc9d2c32  vptest xmm13, xmm13
00007175dc9d2c37  jnz 0x00007175DC9D3E04
00007175dc9d2c3d  vmovaps xmm1, [rsp+0x80]
00007175dc9d2c46  vmovaps xmm15, [rsp+0x80]
00007175dc9d2c4f  por xmm1, xmm15
00007175dc9d2c54  movaps [r15+0x200], xmm1
00007175dc9d2c5c  vmovaps xmm15, [rsp+0x120]
00007175dc9d2c65  vmovaps xmm14, [rsp+0x120]
00007175dc9d2c6e  por xmm15, xmm14
00007175dc9d2c73  movaps [r15+0x1E0], xmm15
00007175dc9d2c7b  vmovaps [rsp+0x50], xmm4
00007175dc9d2c81  vmovaps xmm13, [rsp+0x50]
00007175dc9d2c87  por xmm4, xmm13
00007175dc9d2c8c  movaps [r15+0x2B0], xmm4
00007175dc9d2c94  vmovaps [rsp+0x50], xmm3
00007175dc9d2c9a  vmovaps xmm13, [rsp+0x50]
00007175dc9d2ca0  por xmm3, xmm13
00007175dc9d2ca5  movaps [r15+0x300], xmm3
00007175dc9d2cad  vmovaps xmm15, [rsp+0xB0]
00007175dc9d2cb6  vpermilpd xmm15, xmm15, 0x00
00007175dc9d2cbc  vmovaps xmm3, [rsp+0x20]
00007175dc9d2cc2  vmovaps [rsp+0x20], xmm1
00007175dc9d2cc8  vmovaps xmm1, [rsp+0xE0]
00007175dc9d2cd1  vmovaps [rsp+0x50], xmm14
00007175dc9d2cd7  vmovaps [rsp+0x60], xmm13
00007175dc9d2cdd  movaps xmm14, xmm3
00007175dc9d2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007175dc9d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007175dc9d2cec  vptest xmm13, xmm13
00007175dc9d2cf1  jnz 0x00007175DC9D3F5D
00007175dc9d2cf7  vmovaps xmm1, [rsp+0xB0]
00007175dc9d2d00  vpermilpd xmm1, xmm1, 0x00
00007175dc9d2d06  vmovaps xmm15, [rsp+0x10]
00007175dc9d2d0c  movaps xmm13, xmm15
00007175dc9d2d10  vfmadd231pd xmm13, xmm10, xmm1
00007175dc9d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007175dc9d2d1b  vptest xmm3, xmm3
00007175dc9d2d20  jnz 0x00007175DC9D40B5
00007175dc9d2d26  vmovaps xmm1, [rsp+0xB0]
00007175dc9d2d2f  vpermilpd xmm1, xmm1, 0x00
00007175dc9d2d35  vmovaps xmm15, [rsp+0x30]
00007175dc9d2d3b  movaps xmm10, xmm15
00007175dc9d2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007175dc9d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007175dc9d2d4a  vptest xmm3, xmm3
00007175dc9d2d4f  jnz 0x00007175DC9D420E
00007175dc9d2d55  vmovaps xmm1, [rsp+0xB0]
00007175dc9d2d5e  vpermilpd xmm1, xmm1, 0x00
00007175dc9d2d64  movaps xmm15, xmm12
00007175dc9d2d68  vfmadd231pd xmm15, xmm5, xmm1
00007175dc9d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007175dc9d2d73  vptest xmm11, xmm11
00007175dc9d2d78  jnz 0x00007175DC9D4367
00007175dc9d2d7e  vmovaps [rsp+0x10], xmm9
00007175dc9d2d84  vmovaps xmm1, [rsp+0x10]
00007175dc9d2d8a  por xmm9, xmm1
00007175dc9d2d8f  movaps [r15+0x180], xmm9
00007175dc9d2d97  vmovaps [rsp+0x10], xmm2
00007175dc9d2d9d  vmovaps xmm1, [rsp+0x10]
00007175dc9d2da3  por xmm2, xmm1
00007175dc9d2da7  movaps [r15+0x2D0], xmm2
00007175dc9d2daf  vmovaps xmm12, [rsp+0xD0]
00007175dc9d2db8  vpermilpd xmm12, xmm12, 0x00
00007175dc9d2dbe  vmovaps xmm11, [rsp+0x60]
00007175dc9d2dc4  movaps xmm5, xmm13
00007175dc9d2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007175dc9d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007175dc9d2dd2  vptest xmm3, xmm3
00007175dc9d2dd7  jnz 0x00007175DC9D44BF
00007175dc9d2ddd  vmovaps xmm13, [rsp+0xD0]
00007175dc9d2de6  vpermilpd xmm13, xmm13, 0x00
00007175dc9d2dec  movaps xmm12, xmm14
00007175dc9d2df0  vfmadd231pd xmm12, xmm9, xmm13
00007175dc9d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007175dc9d2dfb  vptest xmm11, xmm11
00007175dc9d2e00  jnz 0x00007175DC9D4617
00007175dc9d2e06  lea rax, [r14+0x80]
00007175dc9d2e0d  movups xmm14, [r13+rax*1]
00007175dc9d2e13  movaps [r15+0x2F0], xmm14
00007175dc9d2e1b  vmovaps xmm13, [rsp+0xD0]
00007175dc9d2e24  vpermilpd xmm13, xmm13, 0x00
00007175dc9d2e2a  movaps xmm11, xmm10
00007175dc9d2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007175dc9d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007175dc9d2e39  vptest xmm9, xmm9
00007175dc9d2e3e  jnz 0x00007175DC9D477B
00007175dc9d2e44  vmovaps xmm13, [rsp+0xD0]
00007175dc9d2e4d  vpermilpd xmm13, xmm13, 0x00
00007175dc9d2e53  movaps xmm10, xmm15
00007175dc9d2e57  vfmadd231pd xmm10, xmm1, xmm13
00007175dc9d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007175dc9d2e62  vptest xmm9, xmm9
00007175dc9d2e67  jnz 0x00007175DC9D48D5
00007175dc9d2e6d  vmovaps [rsp+0x10], xmm7
00007175dc9d2e73  vmovaps xmm1, [rsp+0x10]
00007175dc9d2e79  por xmm7, xmm1
00007175dc9d2e7d  movaps [r15+0x160], xmm7
00007175dc9d2e85  lea rax, [r14+0x40]
00007175dc9d2e89  movups xmm1, [r13+rax*1]
00007175dc9d2e8f  lea rax, [r14+0x50]
00007175dc9d2e93  movups xmm15, [r13+rax*1]
00007175dc9d2e99  movaps [r15+0x1B0], xmm1
00007175dc9d2ea1  movaps [r15+0x1A0], xmm15
00007175dc9d2ea9  vmovaps xmm13, [rsp+0xA0]
00007175dc9d2eb2  vpermilpd xmm13, xmm13, 0x00
00007175dc9d2eb8  vmovaps xmm9, [rsp+0x40]
00007175dc9d2ebe  movaps xmm8, xmm5
00007175dc9d2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007175dc9d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007175dc9d2ecd  vptest xmm3, xmm3
00007175dc9d2ed2  jnz 0x00007175DC9D4A42
00007175dc9d2ed8  vmovaps xmm13, [rsp+0xA0]
00007175dc9d2ee1  vpermilpd xmm13, xmm13, 0x00
00007175dc9d2ee7  movaps xmm9, xmm12
00007175dc9d2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007175dc9d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007175dc9d2ef6  vptest xmm5, xmm5
00007175dc9d2efb  jnz 0x00007175DC9D4B9B
00007175dc9d2f01  vmovaps xmm13, [rsp+0xA0]
00007175dc9d2f0a  vpermilpd xmm13, xmm13, 0x00
00007175dc9d2f10  movaps xmm12, xmm11
00007175dc9d2f14  vfmadd231pd xmm12, xmm6, xmm13
00007175dc9d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007175dc9d2f1f  vptest xmm7, xmm7
00007175dc9d2f24  jnz 0x00007175DC9D4CF4
00007175dc9d2f2a  vmovaps xmm13, [rsp+0xA0]
00007175dc9d2f33  vpermilpd xmm13, xmm13, 0x00
00007175dc9d2f39  vmovaps xmm11, [rsp+0x50]
00007175dc9d2f3f  movaps xmm7, xmm10
00007175dc9d2f43  vfmadd231pd xmm7, xmm11, xmm13
00007175dc9d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007175dc9d2f4d  vptest xmm6, xmm6
00007175dc9d2f52  jnz 0x00007175DC9D4E4D
00007175dc9d2f58  lea rax, [r14+0x60]
00007175dc9d2f5c  movups xmm13, [r13+rax*1]
00007175dc9d2f62  lea rax, [r14+0x70]
00007175dc9d2f66  movups xmm11, [r13+rax*1]
00007175dc9d2f6c  movaps [r15+0x150], xmm13
00007175dc9d2f74  movaps [r15+0x120], xmm11
00007175dc9d2f7c  vmovaps xmm10, [rsp+0xC0]
00007175dc9d2f85  vpermilpd xmm10, xmm10, 0x00
00007175dc9d2f8b  movaps xmm6, xmm8
00007175dc9d2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007175dc9d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007175dc9d2f99  vptest xmm5, xmm5
00007175dc9d2f9e  jnz 0x00007175DC9D4FB9
00007175dc9d2fa4  vmovaps xmm15, [rsp+0xC0]
00007175dc9d2fad  vpermilpd xmm15, xmm15, 0x00
00007175dc9d2fb3  movaps xmm10, xmm9
00007175dc9d2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007175dc9d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007175dc9d2fc2  vptest xmm8, xmm8
00007175dc9d2fc7  jnz 0x00007175DC9D5111
00007175dc9d2fcd  vmovaps xmm15, [rsp+0xC0]
00007175dc9d2fd6  vpermilpd xmm15, xmm15, 0x00
00007175dc9d2fdc  movaps xmm13, xmm12
00007175dc9d2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007175dc9d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007175dc9d2feb  vptest xmm9, xmm9
00007175dc9d2ff0  jnz 0x00007175DC9D526B
00007175dc9d2ff6  vmovaps xmm15, [rsp+0xC0]
00007175dc9d2fff  vpermilpd xmm15, xmm15, 0x00
00007175dc9d3005  movaps xmm12, xmm7
00007175dc9d3009  vfmadd231pd xmm12, xmm1, xmm15
00007175dc9d300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007175dc9d3014  vptest xmm9, xmm9
00007175dc9d3019  jnz 0x00007175DC9D53C4
00007175dc9d301f  lea rax, [r14+0x20]
00007175dc9d3023  movups xmm1, [r13+rax*1]
00007175dc9d3029  lea rax, [r14+0x30]
00007175dc9d302d  movups xmm15, [r13+rax*1]
00007175dc9d3033  vmovaps xmm9, [rsp+0x70]
00007175dc9d3039  vpermilpd xmm9, xmm9, 0x00
00007175dc9d303f  vmovaps xmm8, [rsp+0x20]
00007175dc9d3045  movaps xmm7, xmm6
00007175dc9d3048  vfmadd231pd xmm7, xmm8, xmm9
00007175dc9d304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007175dc9d3052  vptest xmm5, xmm5
00007175dc9d3057  jnz 0x00007175DC9D5530
00007175dc9d305d  vmovaps xmm9, [rsp+0x70]
00007175dc9d3063  vpermilpd xmm9, xmm9, 0x00
00007175dc9d3069  movaps xmm8, xmm10
00007175dc9d306d  vfmadd231pd xmm8, xmm14, xmm9
00007175dc9d3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007175dc9d3078  vptest xmm6, xmm6
00007175dc9d307d  jnz 0x00007175DC9D5687
00007175dc9d3083  vmovaps xmm14, [rsp+0x70]
00007175dc9d3089  vpermilpd xmm14, xmm14, 0x00
00007175dc9d308f  movaps xmm10, xmm13
00007175dc9d3093  vfmadd231pd xmm10, xmm11, xmm14
00007175dc9d3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007175dc9d309e  vptest xmm9, xmm9
00007175dc9d30a3  jnz 0x00007175DC9D57E1
00007175dc9d30a9  vmovaps xmm14, [rsp+0x70]
00007175dc9d30af  vpermilpd xmm14, xmm14, 0x00
00007175dc9d30b5  movaps xmm13, xmm12
00007175dc9d30b9  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007175dc9d30c4  vptest xmm11, xmm11
00007175dc9d30c9  jnz 0x00007175DC9D593B
00007175dc9d30cf  lea rax, [r14+0x90]
00007175dc9d30d6  movups xmm15, [r13+rax*1]
00007175dc9d30dc  lea rax, [r14+0xA0]
00007175dc9d30e3  movups xmm14, [r13+rax*1]
00007175dc9d30e9  movaps [r15+0x140], xmm15
00007175dc9d30f1  movaps [r15+0x130], xmm14
00007175dc9d30f9  vmovaps xmm12, [rsp+0x90]
00007175dc9d3102  vpermilpd xmm12, xmm12, 0x00
00007175dc9d3108  movaps xmm11, xmm7
00007175dc9d310c  vfmadd231pd xmm11, xmm1, xmm12
00007175dc9d3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007175dc9d3117  vptest xmm9, xmm9
00007175dc9d311c  jnz 0x00007175DC9D5AA9
00007175dc9d3122  movaps [r15+0x220], xmm11
00007175dc9d312a  lea rax, [r14+0x10]
00007175dc9d312e  movups xmm1, [r13+rax*1]
00007175dc9d3134  movaps [r15+0x240], xmm1
00007175dc9d313c  vmovaps xmm12, [rsp+0x90]
00007175dc9d3145  vpermilpd xmm12, xmm12, 0x00
00007175dc9d314b  movaps xmm9, xmm8
00007175dc9d314f  vfmadd231pd xmm9, xmm14, xmm12
00007175dc9d3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007175dc9d315a  vptest xmm7, xmm7
00007175dc9d315f  jnz 0x00007175DC9D5C0B
00007175dc9d3165  movaps [r15+0x110], xmm9
00007175dc9d316d  vmovaps xmm14, [rsp+0x90]
00007175dc9d3176  vpermilpd xmm14, xmm14, 0x00
00007175dc9d317c  movaps xmm12, xmm10
00007175dc9d3180  vfmadd231pd xmm12, xmm15, xmm14
00007175dc9d3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007175dc9d318b  vptest xmm8, xmm8
00007175dc9d3190  jnz 0x00007175DC9D5D65
00007175dc9d3196  movaps [r15+0x170], xmm12
00007175dc9d319e  vmovaps xmm15, [rsp+0x90]
00007175dc9d31a7  vpermilpd xmm15, xmm15, 0x00
00007175dc9d31ad  movaps xmm14, xmm13
00007175dc9d31b1  vfmadd231pd xmm14, xmm1, xmm15
00007175dc9d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007175dc9d31bc  vptest xmm10, xmm10
00007175dc9d31c1  jnz 0x00007175DC9D5EBF
00007175dc9d31c7  movaps [r15+0x230], xmm14
00007175dc9d31cf  mov eax, 0x432190
00007175dc9d31d4  movups [r13+rax*1], xmm9
00007175dc9d31da  mov eax, 0x4321A0
00007175dc9d31df  movups [r13+rax*1], xmm12
00007175dc9d31e5  mov eax, 0x4321B0
00007175dc9d31ea  movups [r13+rax*1], xmm11
00007175dc9d31f0  mov eax, 0x4321C0
00007175dc9d31f5  movups [r13+rax*1], xmm14
00007175dc9d31fb  mov eax, [r15+0x108]
00007175dc9d3202  sahf
00007175dc9d3203  jnz 0x00007175DC9D3235
00007175dc9d3205  cmp dword ptr [r15+0x318], 0x00
00007175dc9d320d  jz 0x00007175DC9D9950
00007175dc9d3213  nop [rax+rax*1], ax
00007175dc9d321c  nop [rax+rax*1], eax
00007175dc9d3224  mov eax, 0x410664
00007175dc9d3229  mov [r15+0x100], rax
00007175dc9d3230  jmp 0x00007175DC7FE110
00007175dc9d3235  cmp dword ptr [r15+0x318], 0x00
00007175dc9d323d  jz 0x00007175DC9D6050
00007175dc9d3243  nop [rax+rax*1], ax
00007175dc9d324c  nop [rax+rax*1], eax
00007175dc9d3254  mov eax, 0x4104F0
00007175dc9d3259  mov [r15+0x100], rax
00007175dc9d3260  jmp 0x00007175DC7FE110
00007175dc9d3265  int3
00007175dc9d3266  call 0x00007175DC7FF430
00007175dc9d326b  jmp 0x00007175DC9D230A
00007175dc9d3270  call 0x00007175DC8E5820
00007175dc9d3275  jmp 0x00007175DC9D2314
00007175dc9d327a  call 0x00007175DC8E45A0
00007175dc9d327f  jmp 0x00007175DC9D2326
00007175dc9d3284  call 0x00007175DC8E3320
00007175dc9d3289  jmp 0x00007175DC9D2330
00007175dc9d328e  call 0x00007175DC8E20A0
00007175dc9d3293  jmp 0x00007175DC9D233D
00007175dc9d3298  call 0x00007175DC8E0E30
00007175dc9d329d  jmp 0x00007175DC9D234A
00007175dc9d32a2  call 0x00007175DC8D6600
00007175dc9d32a7  jmp 0x00007175DC9D2357
00007175dc9d32ac  call 0x00007175DC8B52F0
00007175dc9d32b1  jmp 0x00007175DC9D2361
00007175dc9d32b6  call 0x00007175DC8BE9C0
00007175dc9d32bb  jmp 0x00007175DC9D236B
00007175dc9d32c0  call 0x00007175DC8BD750
00007175dc9d32c5  jmp 0x00007175DC9D2378
00007175dc9d32ca  call 0x00007175DC8BC4E0
00007175dc9d32cf  jmp 0x00007175DC9D2385
00007175dc9d32d4  call 0x00007175DC8BB270
00007175dc9d32d9  jmp 0x00007175DC9D2392
00007175dc9d32de  call 0x00007175DC8BA000
00007175dc9d32e3  jmp 0x00007175DC9D239F
00007175dc9d32e8  call 0x00007175DC8B8D90
00007175dc9d32ed  jmp 0x00007175DC9D23AC
00007175dc9d32f2  call 0x00007175DC8B8A20
00007175dc9d32f7  jmp 0x00007175DC9D23B9
00007175dc9d32fc  call 0x00007175DC8BEAE0
00007175dc9d3301  jmp 0x00007175DC9D23C6
00007175dc9d3306  call 0x00007175DC8B5400
00007175dc9d330b  jmp 0x00007175DC9D23D3
00007175dc9d3310  call 0x00007175DC8B52F0
00007175dc9d3315  jmp 0x00007175DC9D23E0
00007175dc9d331a  call 0x00007175DC8BE9C0
00007175dc9d331f  jmp 0x00007175DC9D23ED
00007175dc9d3324  call 0x00007175DC8B77B0
00007175dc9d3329  jmp 0x00007175DC9D23FA
00007175dc9d332e  call 0x00007175DC8B6550
00007175dc9d3333  jmp 0x00007175DC9D2407
00007175dc9d3338  call 0x00007175DC8B52F0
00007175dc9d333d  jmp 0x00007175DC9D2417
00007175dc9d3342  call 0x00007175DC8B52F0
00007175dc9d3347  jmp 0x00007175DC9D2427
00007175dc9d334c  call 0x00007175DC8BEAE0
00007175dc9d3351  jmp 0x00007175DC9D2431
00007175dc9d3356  call 0x00007175DC8BEAE0
00007175dc9d335b  jmp 0x00007175DC9D2444
00007175dc9d3360  call 0x00007175DC8BE9C0
00007175dc9d3365  jmp 0x00007175DC9D2451
00007175dc9d336a  call 0x00007175DC8B52F0
00007175dc9d336f  jmp 0x00007175DC9D2464
00007175dc9d3374  call 0x00007175DC8B6660
00007175dc9d3379  jmp 0x00007175DC9D2471
00007175dc9d337e  call 0x00007175DC8B78C0
00007175dc9d3383  jmp 0x00007175DC9D247E
00007175dc9d3388  call 0x00007175DC8B77B0
00007175dc9d338d  jmp 0x00007175DC9D248B
00007175dc9d3392  call 0x00007175DC8B6550
00007175dc9d3397  jmp 0x00007175DC9D2498
00007175dc9d339c  call 0x00007175DC8B52F0
00007175dc9d33a1  jmp 0x00007175DC9D24AB
00007175dc9d33a6  call 0x00007175DC8B52F0
00007175dc9d33ab  jmp 0x00007175DC9D24BE
00007175dc9d33b0  call 0x00007175DC8B52F0
00007175dc9d33b5  jmp 0x00007175DC9D24E5
00007175dc9d33ba  call 0x00007175DC8B52F0
00007175dc9d33bf  jmp 0x00007175DC9D24F8
00007175dc9d33c4  call 0x00007175DC8B52F0
00007175dc9d33c9  jmp 0x00007175DC9D250B
00007175dc9d33ce  call 0x00007175DC8B52F0
00007175dc9d33d3  jmp 0x00007175DC9D2521
00007175dc9d33d8  call 0x00007175DC8B52F0
00007175dc9d33dd  jmp 0x00007175DC9D2537
00007175dc9d33e2  call 0x00007175DC8B52F0
00007175dc9d33e7  jmp 0x00007175DC9D254D
00007175dc9d33ec  call 0x00007175DC7FF540
00007175dc9d33f1  jmp 0x00007175DC9D256E
00007175dc9d33f6  call 0x00007175DC802FE0
00007175dc9d33fb  jmp 0x00007175DC9D2578
00007175dc9d3400  call 0x00007175DC7FF540
00007175dc9d3405  jmp 0x00007175DC9D2588
00007175dc9d340a  call 0x00007175DC7FF540
00007175dc9d340f  jmp 0x00007175DC9D259B
00007175dc9d3414  call 0x00007175DC7FF540
00007175dc9d3419  jmp 0x00007175DC9D25AE
00007175dc9d341e  call 0x00007175DC7FF540
00007175dc9d3423  jmp 0x00007175DC9D25C1
00007175dc9d3428  call 0x00007175DC8C0370
00007175dc9d342d  jmp 0x00007175DC9D25E0
00007175dc9d3432  call 0x00007175DC8BF100
00007175dc9d3437  jmp 0x00007175DC9D25E9
00007175dc9d343c  call 0x00007175DC8C0370
00007175dc9d3441  jmp 0x00007175DC9D2659
00007175dc9d3446  call 0x00007175DC8BF100
00007175dc9d344b  jmp 0x00007175DC9D2662
00007175dc9d3450  call 0x00007175DC8C0370
00007175dc9d3455  jmp 0x00007175DC9D270C
00007175dc9d345a  call 0x00007175DC8BF100
00007175dc9d345f  jmp 0x00007175DC9D2715
00007175dc9d3464  call 0x00007175DC80B720
00007175dc9d3469  jmp 0x00007175DC9D27F7
00007175dc9d346e  call 0x00007175DC8D64F0
00007175dc9d3473  jmp 0x00007175DC9D281F
00007175dc9d3478  call 0x00007175DC8B47C0
00007175dc9d347d  jmp 0x00007175DC9D283A
00007175dc9d3482  sub rsp, 0x08
00007175dc9d3486  push rax
00007175dc9d3487  push rcx
00007175dc9d3488  push rdx
00007175dc9d3489  push rdi
00007175dc9d348a  push rsi
00007175dc9d348b  push r8
00007175dc9d348d  push r9
00007175dc9d348f  push r10
00007175dc9d3491  push r11
00007175dc9d3493  sub rsp, 0xF0
00007175dc9d349a  vmovaps [rsp], xmm0
00007175dc9d349f  vmovaps [rsp+0x10], xmm1
00007175dc9d34a5  vmovaps [rsp+0x20], xmm2
00007175dc9d34ab  vmovaps [rsp+0x30], xmm3
00007175dc9d34b1  vmovaps [rsp+0x40], xmm4
00007175dc9d34b7  vmovaps [rsp+0x50], xmm5
00007175dc9d34bd  vmovaps [rsp+0x60], xmm6
00007175dc9d34c3  vmovaps [rsp+0x70], xmm7
00007175dc9d34c9  vmovaps [rsp+0x80], xmm8
00007175dc9d34d2  vmovaps [rsp+0x90], xmm9
00007175dc9d34db  vmovaps [rsp+0xA0], xmm10
00007175dc9d34e4  vmovaps [rsp+0xB0], xmm11
00007175dc9d34ed  vmovaps [rsp+0xC0], xmm12
00007175dc9d34f6  vmovaps [rsp+0xD0], xmm14
00007175dc9d34ff  vmovaps [rsp+0xE0], xmm15
00007175dc9d3508  sub rsp, 0x40
00007175dc9d350c  lea rdi, [rsp]
00007175dc9d3510  lea rsi, [rsp+0x10]
00007175dc9d3515  lea rdx, [rsp+0x20]
00007175dc9d351a  lea rcx, [rsp+0x30]
00007175dc9d351f  mov r8d, 0x00
00007175dc9d3525  lea r9, [r15+0x3A8]
00007175dc9d352c  movaps [rdi], xmm13
00007175dc9d3530  movaps [rsi], xmm1
00007175dc9d3533  movaps [rdx], xmm15
00007175dc9d3537  movaps [rcx], xmm14
00007175dc9d353b  mov rax, 0x622B29CAFA50
00007175dc9d3545  call rax
00007175dc9d3547  movaps xmm13, [rsp]
00007175dc9d354c  add rsp, 0x40
00007175dc9d3550  vmovaps xmm0, [rsp]
00007175dc9d3555  vmovaps xmm1, [rsp+0x10]
00007175dc9d355b  vmovaps xmm2, [rsp+0x20]
00007175dc9d3561  vmovaps xmm3, [rsp+0x30]
00007175dc9d3567  vmovaps xmm4, [rsp+0x40]
00007175dc9d356d  vmovaps xmm5, [rsp+0x50]
00007175dc9d3573  vmovaps xmm6, [rsp+0x60]
00007175dc9d3579  vmovaps xmm7, [rsp+0x70]
00007175dc9d357f  vmovaps xmm8, [rsp+0x80]
00007175dc9d3588  vmovaps xmm9, [rsp+0x90]
00007175dc9d3591  vmovaps xmm10, [rsp+0xA0]
00007175dc9d359a  vmovaps xmm11, [rsp+0xB0]
00007175dc9d35a3  vmovaps xmm12, [rsp+0xC0]
00007175dc9d35ac  vmovaps xmm14, [rsp+0xD0]
00007175dc9d35b5  vmovaps xmm15, [rsp+0xE0]
00007175dc9d35be  add rsp, 0xF0
00007175dc9d35c5  pop r11
00007175dc9d35c7  pop r10
00007175dc9d35c9  pop r9
00007175dc9d35cb  pop r8
00007175dc9d35cd  pop rsi
00007175dc9d35ce  pop rdi
00007175dc9d35cf  pop rdx
00007175dc9d35d0  pop rcx
00007175dc9d35d1  pop rax
00007175dc9d35d2  add rsp, 0x08
00007175dc9d35d6  jmp 0x00007175DC9D28AD
00007175dc9d35db  sub rsp, 0x08
00007175dc9d35df  push rax
00007175dc9d35e0  push rcx
00007175dc9d35e1  push rdx
00007175dc9d35e2  push rdi
00007175dc9d35e3  push rsi
00007175dc9d35e4  push r8
00007175dc9d35e6  push r9
00007175dc9d35e8  push r10
00007175dc9d35ea  push r11
00007175dc9d35ec  sub rsp, 0xF0
00007175dc9d35f3  vmovaps [rsp], xmm0
00007175dc9d35f8  vmovaps [rsp+0x10], xmm1
00007175dc9d35fe  vmovaps [rsp+0x20], xmm2
00007175dc9d3604  vmovaps [rsp+0x30], xmm3
00007175dc9d360a  vmovaps [rsp+0x40], xmm4
00007175dc9d3610  vmovaps [rsp+0x50], xmm5
00007175dc9d3616  vmovaps [rsp+0x60], xmm6
00007175dc9d361c  vmovaps [rsp+0x70], xmm7
00007175dc9d3622  vmovaps [rsp+0x80], xmm8
00007175dc9d362b  vmovaps [rsp+0x90], xmm9
00007175dc9d3634  vmovaps [rsp+0xA0], xmm10
00007175dc9d363d  vmovaps [rsp+0xB0], xmm11
00007175dc9d3646  vmovaps [rsp+0xC0], xmm12
00007175dc9d364f  vmovaps [rsp+0xD0], xmm13
00007175dc9d3658  vmovaps [rsp+0xE0], xmm14
00007175dc9d3661  sub rsp, 0x40
00007175dc9d3665  lea rdi, [rsp]
00007175dc9d3669  lea rsi, [rsp+0x10]
00007175dc9d366e  lea rdx, [rsp+0x20]
00007175dc9d3673  lea rcx, [rsp+0x30]
00007175dc9d3678  mov r8d, 0x00
00007175dc9d367e  lea r9, [r15+0x3A8]
00007175dc9d3685  movaps [rdi], xmm15
00007175dc9d3689  movaps [rsi], xmm5
00007175dc9d368c  movaps [rdx], xmm1
00007175dc9d368f  movaps [rcx], xmm14
00007175dc9d3693  mov rax, 0x622B29CAFA50
00007175dc9d369d  call rax
00007175dc9d369f  movaps xmm15, [rsp]
00007175dc9d36a4  add rsp, 0x40
00007175dc9d36a8  vmovaps xmm0, [rsp]
00007175dc9d36ad  vmovaps xmm1, [rsp+0x10]
00007175dc9d36b3  vmovaps xmm2, [rsp+0x20]
00007175dc9d36b9  vmovaps xmm3, [rsp+0x30]
00007175dc9d36bf  vmovaps xmm4, [rsp+0x40]
00007175dc9d36c5  vmovaps xmm5, [rsp+0x50]
00007175dc9d36cb  vmovaps xmm6, [rsp+0x60]
00007175dc9d36d1  vmovaps xmm7, [rsp+0x70]
00007175dc9d36d7  vmovaps xmm8, [rsp+0x80]
00007175dc9d36e0  vmovaps xmm9, [rsp+0x90]
00007175dc9d36e9  vmovaps xmm10, [rsp+0xA0]
00007175dc9d36f2  vmovaps xmm11, [rsp+0xB0]
00007175dc9d36fb  vmovaps xmm12, [rsp+0xC0]
00007175dc9d3704  vmovaps xmm13, [rsp+0xD0]
00007175dc9d370d  vmovaps xmm14, [rsp+0xE0]
00007175dc9d3716  add rsp, 0xF0
00007175dc9d371d  pop r11
00007175dc9d371f  pop r10
00007175dc9d3721  pop r9
00007175dc9d3723  pop r8
00007175dc9d3725  pop rsi
00007175dc9d3726  pop rdi
00007175dc9d3727  pop rdx
00007175dc9d3728  pop rcx
00007175dc9d3729  pop rax
00007175dc9d372a  add rsp, 0x08
00007175dc9d372e  jmp 0x00007175DC9D28D0
00007175dc9d3733  call 0x00007175DC7FF430
00007175dc9d3738  jmp 0x00007175DC9D295D
00007175dc9d373d  sub rsp, 0x08
00007175dc9d3741  push rax
00007175dc9d3742  push rcx
00007175dc9d3743  push rdx
00007175dc9d3744  push rdi
00007175dc9d3745  push rsi
00007175dc9d3746  push r8
00007175dc9d3748  push r9
00007175dc9d374a  push r10
00007175dc9d374c  push r11
00007175dc9d374e  sub rsp, 0xF0
00007175dc9d3755  vmovaps [rsp], xmm0
00007175dc9d375a  vmovaps [rsp+0x10], xmm1
00007175dc9d3760  vmovaps [rsp+0x20], xmm2
00007175dc9d3766  vmovaps [rsp+0x30], xmm3
00007175dc9d376c  vmovaps [rsp+0x40], xmm4
00007175dc9d3772  vmovaps [rsp+0x50], xmm5
00007175dc9d3778  vmovaps [rsp+0x60], xmm6
00007175dc9d377e  vmovaps [rsp+0x70], xmm7
00007175dc9d3784  vmovaps [rsp+0x80], xmm8
00007175dc9d378d  vmovaps [rsp+0x90], xmm9
00007175dc9d3796  vmovaps [rsp+0xA0], xmm10
00007175dc9d379f  vmovaps [rsp+0xB0], xmm11
00007175dc9d37a8  vmovaps [rsp+0xC0], xmm12
00007175dc9d37b1  vmovaps [rsp+0xD0], xmm14
00007175dc9d37ba  vmovaps [rsp+0xE0], xmm15
00007175dc9d37c3  sub rsp, 0x40
00007175dc9d37c7  lea rdi, [rsp]
00007175dc9d37cb  lea rsi, [rsp+0x10]
00007175dc9d37d0  lea rdx, [rsp+0x20]
00007175dc9d37d5  lea rcx, [rsp+0x30]
00007175dc9d37da  mov r8d, 0x00
00007175dc9d37e0  lea r9, [r15+0x3A8]
00007175dc9d37e7  movaps [rdi], xmm13
00007175dc9d37eb  movaps [rsi], xmm1
00007175dc9d37ee  movaps [rdx], xmm15
00007175dc9d37f2  movaps [rcx], xmm14
00007175dc9d37f6  mov rax, 0x622B29CAFA50
00007175dc9d3800  call rax
00007175dc9d3802  movaps xmm13, [rsp]
00007175dc9d3807  add rsp, 0x40
00007175dc9d380b  vmovaps xmm0, [rsp]
00007175dc9d3810  vmovaps xmm1, [rsp+0x10]
00007175dc9d3816  vmovaps xmm2, [rsp+0x20]
00007175dc9d381c  vmovaps xmm3, [rsp+0x30]
00007175dc9d3822  vmovaps xmm4, [rsp+0x40]
00007175dc9d3828  vmovaps xmm5, [rsp+0x50]
00007175dc9d382e  vmovaps xmm6, [rsp+0x60]
00007175dc9d3834  vmovaps xmm7, [rsp+0x70]
00007175dc9d383a  vmovaps xmm8, [rsp+0x80]
00007175dc9d3843  vmovaps xmm9, [rsp+0x90]
00007175dc9d384c  vmovaps xmm10, [rsp+0xA0]
00007175dc9d3855  vmovaps xmm11, [rsp+0xB0]
00007175dc9d385e  vmovaps xmm12, [rsp+0xC0]
00007175dc9d3867  vmovaps xmm14, [rsp+0xD0]
00007175dc9d3870  vmovaps xmm15, [rsp+0xE0]
00007175dc9d3879  add rsp, 0xF0
00007175dc9d3880  pop r11
00007175dc9d3882  pop r10
00007175dc9d3884  pop r9
00007175dc9d3886  pop r8
00007175dc9d3888  pop rsi
00007175dc9d3889  pop rdi
00007175dc9d388a  pop rdx
00007175dc9d388b  pop rcx
00007175dc9d388c  pop rax
00007175dc9d388d  add rsp, 0x08
00007175dc9d3891  jmp 0x00007175DC9D29C1
00007175dc9d3896  call 0x00007175DC7FF430
00007175dc9d389b  jmp 0x00007175DC9D29CE
00007175dc9d38a0  sub rsp, 0x08
00007175dc9d38a4  push rax
00007175dc9d38a5  push rcx
00007175dc9d38a6  push rdx
00007175dc9d38a7  push rdi
00007175dc9d38a8  push rsi
00007175dc9d38a9  push r8
00007175dc9d38ab  push r9
00007175dc9d38ad  push r10
00007175dc9d38af  push r11
00007175dc9d38b1  sub rsp, 0xF0
00007175dc9d38b8  vmovaps [rsp], xmm0
00007175dc9d38bd  vmovaps [rsp+0x10], xmm1
00007175dc9d38c3  vmovaps [rsp+0x20], xmm2
00007175dc9d38c9  vmovaps [rsp+0x30], xmm3
00007175dc9d38cf  vmovaps [rsp+0x40], xmm4
00007175dc9d38d5  vmovaps [rsp+0x50], xmm5
00007175dc9d38db  vmovaps [rsp+0x60], xmm6
00007175dc9d38e1  vmovaps [rsp+0x70], xmm7
00007175dc9d38e7  vmovaps [rsp+0x80], xmm8
00007175dc9d38f0  vmovaps [rsp+0x90], xmm9
00007175dc9d38f9  vmovaps [rsp+0xA0], xmm10
00007175dc9d3902  vmovaps [rsp+0xB0], xmm11
00007175dc9d390b  vmovaps [rsp+0xC0], xmm13
00007175dc9d3914  vmovaps [rsp+0xD0], xmm14
00007175dc9d391d  vmovaps [rsp+0xE0], xmm15
00007175dc9d3926  sub rsp, 0x40
00007175dc9d392a  lea rdi, [rsp]
00007175dc9d392e  lea rsi, [rsp+0x10]
00007175dc9d3933  lea rdx, [rsp+0x20]
00007175dc9d3938  lea rcx, [rsp+0x30]
00007175dc9d393d  mov r8d, 0x00
00007175dc9d3943  lea r9, [r15+0x3A8]
00007175dc9d394a  movaps [rdi], xmm12
00007175dc9d394e  movaps [rsi], xmm15
00007175dc9d3952  movaps [rdx], xmm1
00007175dc9d3955  movaps [rcx], xmm14
00007175dc9d3959  mov rax, 0x622B29CAFA50
00007175dc9d3963  call rax
00007175dc9d3965  movaps xmm12, [rsp]
00007175dc9d396a  add rsp, 0x40
00007175dc9d396e  vmovaps xmm0, [rsp]
00007175dc9d3973  vmovaps xmm1, [rsp+0x10]
00007175dc9d3979  vmovaps xmm2, [rsp+0x20]
00007175dc9d397f  vmovaps xmm3, [rsp+0x30]
00007175dc9d3985  vmovaps xmm4, [rsp+0x40]
00007175dc9d398b  vmovaps xmm5, [rsp+0x50]
00007175dc9d3991  vmovaps xmm6, [rsp+0x60]
00007175dc9d3997  vmovaps xmm7, [rsp+0x70]
00007175dc9d399d  vmovaps xmm8, [rsp+0x80]
00007175dc9d39a6  vmovaps xmm9, [rsp+0x90]
00007175dc9d39af  vmovaps xmm10, [rsp+0xA0]
00007175dc9d39b8  vmovaps xmm11, [rsp+0xB0]
00007175dc9d39c1  vmovaps xmm13, [rsp+0xC0]
00007175dc9d39ca  vmovaps xmm14, [rsp+0xD0]
00007175dc9d39d3  vmovaps xmm15, [rsp+0xE0]
00007175dc9d39dc  add rsp, 0xF0
00007175dc9d39e3  pop r11
00007175dc9d39e5  pop r10
00007175dc9d39e7  pop r9
00007175dc9d39e9  pop r8
00007175dc9d39eb  pop rsi
00007175dc9d39ec  pop rdi
00007175dc9d39ed  pop rdx
00007175dc9d39ee  pop rcx
00007175dc9d39ef  pop rax
00007175dc9d39f0  add rsp, 0x08
00007175dc9d39f4  jmp 0x00007175DC9D29FA
00007175dc9d39f9  sub rsp, 0x08
00007175dc9d39fd  push rax
00007175dc9d39fe  push rcx
00007175dc9d39ff  push rdx
00007175dc9d3a00  push rdi
00007175dc9d3a01  push rsi
00007175dc9d3a02  push r8
00007175dc9d3a04  push r9
00007175dc9d3a06  push r10
00007175dc9d3a08  push r11
00007175dc9d3a0a  sub rsp, 0xF0
00007175dc9d3a11  vmovaps [rsp], xmm0
00007175dc9d3a16  vmovaps [rsp+0x10], xmm1
00007175dc9d3a1c  vmovaps [rsp+0x20], xmm2
00007175dc9d3a22  vmovaps [rsp+0x30], xmm3
00007175dc9d3a28  vmovaps [rsp+0x40], xmm4
00007175dc9d3a2e  vmovaps [rsp+0x50], xmm5
00007175dc9d3a34  vmovaps [rsp+0x60], xmm6
00007175dc9d3a3a  vmovaps [rsp+0x70], xmm7
00007175dc9d3a40  vmovaps [rsp+0x80], xmm8
00007175dc9d3a49  vmovaps [rsp+0x90], xmm9
00007175dc9d3a52  vmovaps [rsp+0xA0], xmm10
00007175dc9d3a5b  vmovaps [rsp+0xB0], xmm11
00007175dc9d3a64  vmovaps [rsp+0xC0], xmm12
00007175dc9d3a6d  vmovaps [rsp+0xD0], xmm14
00007175dc9d3a76  vmovaps [rsp+0xE0], xmm15
00007175dc9d3a7f  sub rsp, 0x40
00007175dc9d3a83  lea rdi, [rsp]
00007175dc9d3a87  lea rsi, [rsp+0x10]
00007175dc9d3a8c  lea rdx, [rsp+0x20]
00007175dc9d3a91  lea rcx, [rsp+0x30]
00007175dc9d3a96  mov r8d, 0x00
00007175dc9d3a9c  lea r9, [r15+0x3A8]
00007175dc9d3aa3  movaps [rdi], xmm13
00007175dc9d3aa7  movaps [rsi], xmm1
00007175dc9d3aaa  movaps [rdx], xmm15
00007175dc9d3aae  movaps [rcx], xmm14
00007175dc9d3ab2  mov rax, 0x622B29CAFA50
00007175dc9d3abc  call rax
00007175dc9d3abe  movaps xmm13, [rsp]
00007175dc9d3ac3  add rsp, 0x40
00007175dc9d3ac7  vmovaps xmm0, [rsp]
00007175dc9d3acc  vmovaps xmm1, [rsp+0x10]
00007175dc9d3ad2  vmovaps xmm2, [rsp+0x20]
00007175dc9d3ad8  vmovaps xmm3, [rsp+0x30]
00007175dc9d3ade  vmovaps xmm4, [rsp+0x40]
00007175dc9d3ae4  vmovaps xmm5, [rsp+0x50]
00007175dc9d3aea  vmovaps xmm6, [rsp+0x60]
00007175dc9d3af0  vmovaps xmm7, [rsp+0x70]
00007175dc9d3af6  vmovaps xmm8, [rsp+0x80]
00007175dc9d3aff  vmovaps xmm9, [rsp+0x90]
00007175dc9d3b08  vmovaps xmm10, [rsp+0xA0]
00007175dc9d3b11  vmovaps xmm11, [rsp+0xB0]
00007175dc9d3b1a  vmovaps xmm12, [rsp+0xC0]
00007175dc9d3b23  vmovaps xmm14, [rsp+0xD0]
00007175dc9d3b2c  vmovaps xmm15, [rsp+0xE0]
00007175dc9d3b35  add rsp, 0xF0
00007175dc9d3b3c  pop r11
00007175dc9d3b3e  pop r10
00007175dc9d3b40  pop r9
00007175dc9d3b42  pop r8
00007175dc9d3b44  pop rsi
00007175dc9d3b45  pop rdi
00007175dc9d3b46  pop rdx
00007175dc9d3b47  pop rcx
00007175dc9d3b48  pop rax
00007175dc9d3b49  add rsp, 0x08
00007175dc9d3b4d  jmp 0x00007175DC9D2B77
00007175dc9d3b52  sub rsp, 0x08
00007175dc9d3b56  push rax
00007175dc9d3b57  push rcx
00007175dc9d3b58  push rdx
00007175dc9d3b59  push rdi
00007175dc9d3b5a  push rsi
00007175dc9d3b5b  push r8
00007175dc9d3b5d  push r9
00007175dc9d3b5f  push r10
00007175dc9d3b61  push r11
00007175dc9d3b63  sub rsp, 0xF0
00007175dc9d3b6a  vmovaps [rsp], xmm0
00007175dc9d3b6f  vmovaps [rsp+0x10], xmm1
00007175dc9d3b75  vmovaps [rsp+0x20], xmm2
00007175dc9d3b7b  vmovaps [rsp+0x30], xmm3
00007175dc9d3b81  vmovaps [rsp+0x40], xmm4
00007175dc9d3b87  vmovaps [rsp+0x50], xmm5
00007175dc9d3b8d  vmovaps [rsp+0x60], xmm6
00007175dc9d3b93  vmovaps [rsp+0x70], xmm7
00007175dc9d3b99  vmovaps [rsp+0x80], xmm8
00007175dc9d3ba2  vmovaps [rsp+0x90], xmm9
00007175dc9d3bab  vmovaps [rsp+0xA0], xmm10
00007175dc9d3bb4  vmovaps [rsp+0xB0], xmm11
00007175dc9d3bbd  vmovaps [rsp+0xC0], xmm13
00007175dc9d3bc6  vmovaps [rsp+0xD0], xmm14
00007175dc9d3bcf  vmovaps [rsp+0xE0], xmm15
00007175dc9d3bd8  sub rsp, 0x40
00007175dc9d3bdc  lea rdi, [rsp]
00007175dc9d3be0  lea rsi, [rsp+0x10]
00007175dc9d3be5  lea rdx, [rsp+0x20]
00007175dc9d3bea  lea rcx, [rsp+0x30]
00007175dc9d3bef  mov r8d, 0x00
00007175dc9d3bf5  lea r9, [r15+0x3A8]
00007175dc9d3bfc  movaps [rdi], xmm12
00007175dc9d3c00  movaps [rsi], xmm15
00007175dc9d3c04  movaps [rdx], xmm14
00007175dc9d3c08  movaps [rcx], xmm1
00007175dc9d3c0b  mov rax, 0x622B29CAFA50
00007175dc9d3c15  call rax
00007175dc9d3c17  movaps xmm12, [rsp]
00007175dc9d3c1c  add rsp, 0x40
00007175dc9d3c20  vmovaps xmm0, [rsp]
00007175dc9d3c25  vmovaps xmm1, [rsp+0x10]
00007175dc9d3c2b  vmovaps xmm2, [rsp+0x20]
00007175dc9d3c31  vmovaps xmm3, [rsp+0x30]
00007175dc9d3c37  vmovaps xmm4, [rsp+0x40]
00007175dc9d3c3d  vmovaps xmm5, [rsp+0x50]
00007175dc9d3c43  vmovaps xmm6, [rsp+0x60]
00007175dc9d3c49  vmovaps xmm7, [rsp+0x70]
00007175dc9d3c4f  vmovaps xmm8, [rsp+0x80]
00007175dc9d3c58  vmovaps xmm9, [rsp+0x90]
00007175dc9d3c61  vmovaps xmm10, [rsp+0xA0]
00007175dc9d3c6a  vmovaps xmm11, [rsp+0xB0]
00007175dc9d3c73  vmovaps xmm13, [rsp+0xC0]
00007175dc9d3c7c  vmovaps xmm14, [rsp+0xD0]
00007175dc9d3c85  vmovaps xmm15, [rsp+0xE0]
00007175dc9d3c8e  add rsp, 0xF0
00007175dc9d3c95  pop r11
00007175dc9d3c97  pop r10
00007175dc9d3c99  pop r9
00007175dc9d3c9b  pop r8
00007175dc9d3c9d  pop rsi
00007175dc9d3c9e  pop rdi
00007175dc9d3c9f  pop rdx
00007175dc9d3ca0  pop rcx
00007175dc9d3ca1  pop rax
00007175dc9d3ca2  add rsp, 0x08
00007175dc9d3ca6  jmp 0x00007175DC9D2BB2
00007175dc9d3cab  sub rsp, 0x08
00007175dc9d3caf  push rax
00007175dc9d3cb0  push rcx
00007175dc9d3cb1  push rdx
00007175dc9d3cb2  push rdi
00007175dc9d3cb3  push rsi
00007175dc9d3cb4  push r8
00007175dc9d3cb6  push r9
00007175dc9d3cb8  push r10
00007175dc9d3cba  push r11
00007175dc9d3cbc  sub rsp, 0xF0
00007175dc9d3cc3  vmovaps [rsp], xmm0
00007175dc9d3cc8  vmovaps [rsp+0x10], xmm1
00007175dc9d3cce  vmovaps [rsp+0x20], xmm2
00007175dc9d3cd4  vmovaps [rsp+0x30], xmm3
00007175dc9d3cda  vmovaps [rsp+0x40], xmm4
00007175dc9d3ce0  vmovaps [rsp+0x50], xmm5
00007175dc9d3ce6  vmovaps [rsp+0x60], xmm6
00007175dc9d3cec  vmovaps [rsp+0x70], xmm7
00007175dc9d3cf2  vmovaps [rsp+0x80], xmm8
00007175dc9d3cfb  vmovaps [rsp+0x90], xmm9
00007175dc9d3d04  vmovaps [rsp+0xA0], xmm10
00007175dc9d3d0d  vmovaps [rsp+0xB0], xmm11
00007175dc9d3d16  vmovaps [rsp+0xC0], xmm12
00007175dc9d3d1f  vmovaps [rsp+0xD0], xmm14
00007175dc9d3d28  vmovaps [rsp+0xE0], xmm15
00007175dc9d3d31  sub rsp, 0x40
00007175dc9d3d35  lea rdi, [rsp]
00007175dc9d3d39  lea rsi, [rsp+0x10]
00007175dc9d3d3e  lea rdx, [rsp+0x20]
00007175dc9d3d43  lea rcx, [rsp+0x30]
00007175dc9d3d48  mov r8d, 0x00
00007175dc9d3d4e  lea r9, [r15+0x3A8]
00007175dc9d3d55  movaps [rdi], xmm13
00007175dc9d3d59  movaps [rsi], xmm15
00007175dc9d3d5d  movaps [rdx], xmm14
00007175dc9d3d61  movaps [rcx], xmm1
00007175dc9d3d64  mov rax, 0x622B29CAFA50
00007175dc9d3d6e  call rax
00007175dc9d3d70  movaps xmm13, [rsp]
00007175dc9d3d75  add rsp, 0x40
00007175dc9d3d79  vmovaps xmm0, [rsp]
00007175dc9d3d7e  vmovaps xmm1, [rsp+0x10]
00007175dc9d3d84  vmovaps xmm2, [rsp+0x20]
00007175dc9d3d8a  vmovaps xmm3, [rsp+0x30]
00007175dc9d3d90  vmovaps xmm4, [rsp+0x40]
00007175dc9d3d96  vmovaps xmm5, [rsp+0x50]
00007175dc9d3d9c  vmovaps xmm6, [rsp+0x60]
00007175dc9d3da2  vmovaps xmm7, [rsp+0x70]
00007175dc9d3da8  vmovaps xmm8, [rsp+0x80]
00007175dc9d3db1  vmovaps xmm9, [rsp+0x90]
00007175dc9d3dba  vmovaps xmm10, [rsp+0xA0]
00007175dc9d3dc3  vmovaps xmm11, [rsp+0xB0]
00007175dc9d3dcc  vmovaps xmm12, [rsp+0xC0]
00007175dc9d3dd5  vmovaps xmm14, [rsp+0xD0]
00007175dc9d3dde  vmovaps xmm15, [rsp+0xE0]
00007175dc9d3de7  add rsp, 0xF0
00007175dc9d3dee  pop r11
00007175dc9d3df0  pop r10
00007175dc9d3df2  pop r9
00007175dc9d3df4  pop r8
00007175dc9d3df6  pop rsi
00007175dc9d3df7  pop rdi
00007175dc9d3df8  pop rdx
00007175dc9d3df9  pop rcx
00007175dc9d3dfa  pop rax
00007175dc9d3dfb  add rsp, 0x08
00007175dc9d3dff  jmp 0x00007175DC9D2BEA
00007175dc9d3e04  sub rsp, 0x08
00007175dc9d3e08  push rax
00007175dc9d3e09  push rcx
00007175dc9d3e0a  push rdx
00007175dc9d3e0b  push rdi
00007175dc9d3e0c  push rsi
00007175dc9d3e0d  push r8
00007175dc9d3e0f  push r9
00007175dc9d3e11  push r10
00007175dc9d3e13  push r11
00007175dc9d3e15  sub rsp, 0xF0
00007175dc9d3e1c  vmovaps [rsp], xmm0
00007175dc9d3e21  vmovaps [rsp+0x10], xmm1
00007175dc9d3e27  vmovaps [rsp+0x20], xmm2
00007175dc9d3e2d  vmovaps [rsp+0x30], xmm3
00007175dc9d3e33  vmovaps [rsp+0x40], xmm4
00007175dc9d3e39  vmovaps [rsp+0x50], xmm5
00007175dc9d3e3f  vmovaps [rsp+0x60], xmm6
00007175dc9d3e45  vmovaps [rsp+0x70], xmm7
00007175dc9d3e4b  vmovaps [rsp+0x80], xmm8
00007175dc9d3e54  vmovaps [rsp+0x90], xmm9
00007175dc9d3e5d  vmovaps [rsp+0xA0], xmm10
00007175dc9d3e66  vmovaps [rsp+0xB0], xmm11
00007175dc9d3e6f  vmovaps [rsp+0xC0], xmm13
00007175dc9d3e78  vmovaps [rsp+0xD0], xmm14
00007175dc9d3e81  vmovaps [rsp+0xE0], xmm15
00007175dc9d3e8a  sub rsp, 0x40
00007175dc9d3e8e  lea rdi, [rsp]
00007175dc9d3e92  lea rsi, [rsp+0x10]
00007175dc9d3e97  lea rdx, [rsp+0x20]
00007175dc9d3e9c  lea rcx, [rsp+0x30]
00007175dc9d3ea1  mov r8d, 0x00
00007175dc9d3ea7  lea r9, [r15+0x3A8]
00007175dc9d3eae  movaps [rdi], xmm12
00007175dc9d3eb2  movaps [rsi], xmm15
00007175dc9d3eb6  movaps [rdx], xmm14
00007175dc9d3eba  movaps [rcx], xmm1
00007175dc9d3ebd  mov rax, 0x622B29CAFA50
00007175dc9d3ec7  call rax
00007175dc9d3ec9  movaps xmm12, [rsp]
00007175dc9d3ece  add rsp, 0x40
00007175dc9d3ed2  vmovaps xmm0, [rsp]
00007175dc9d3ed7  vmovaps xmm1, [rsp+0x10]
00007175dc9d3edd  vmovaps xmm2, [rsp+0x20]
00007175dc9d3ee3  vmovaps xmm3, [rsp+0x30]
00007175dc9d3ee9  vmovaps xmm4, [rsp+0x40]
00007175dc9d3eef  vmovaps xmm5, [rsp+0x50]
00007175dc9d3ef5  vmovaps xmm6, [rsp+0x60]
00007175dc9d3efb  vmovaps xmm7, [rsp+0x70]
00007175dc9d3f01  vmovaps xmm8, [rsp+0x80]
00007175dc9d3f0a  vmovaps xmm9, [rsp+0x90]
00007175dc9d3f13  vmovaps xmm10, [rsp+0xA0]
00007175dc9d3f1c  vmovaps xmm11, [rsp+0xB0]
00007175dc9d3f25  vmovaps xmm13, [rsp+0xC0]
00007175dc9d3f2e  vmovaps xmm14, [rsp+0xD0]
00007175dc9d3f37  vmovaps xmm15, [rsp+0xE0]
00007175dc9d3f40  add rsp, 0xF0
00007175dc9d3f47  pop r11
00007175dc9d3f49  pop r10
00007175dc9d3f4b  pop r9
00007175dc9d3f4d  pop r8
00007175dc9d3f4f  pop rsi
00007175dc9d3f50  pop rdi
00007175dc9d3f51  pop rdx
00007175dc9d3f52  pop rcx
00007175dc9d3f53  pop rax
00007175dc9d3f54  add rsp, 0x08
00007175dc9d3f58  jmp 0x00007175DC9D2C3D
00007175dc9d3f5d  sub rsp, 0x08
00007175dc9d3f61  push rax
00007175dc9d3f62  push rcx
00007175dc9d3f63  push rdx
00007175dc9d3f64  push rdi
00007175dc9d3f65  push rsi
00007175dc9d3f66  push r8
00007175dc9d3f68  push r9
00007175dc9d3f6a  push r10
00007175dc9d3f6c  push r11
00007175dc9d3f6e  sub rsp, 0xF0
00007175dc9d3f75  vmovaps [rsp], xmm0
00007175dc9d3f7a  vmovaps [rsp+0x10], xmm1
00007175dc9d3f80  vmovaps [rsp+0x20], xmm2
00007175dc9d3f86  vmovaps [rsp+0x30], xmm3
00007175dc9d3f8c  vmovaps [rsp+0x40], xmm4
00007175dc9d3f92  vmovaps [rsp+0x50], xmm5
00007175dc9d3f98  vmovaps [rsp+0x60], xmm6
00007175dc9d3f9e  vmovaps [rsp+0x70], xmm7
00007175dc9d3fa4  vmovaps [rsp+0x80], xmm8
00007175dc9d3fad  vmovaps [rsp+0x90], xmm9
00007175dc9d3fb6  vmovaps [rsp+0xA0], xmm10
00007175dc9d3fbf  vmovaps [rsp+0xB0], xmm11
00007175dc9d3fc8  vmovaps [rsp+0xC0], xmm12
00007175dc9d3fd1  vmovaps [rsp+0xD0], xmm13
00007175dc9d3fda  vmovaps [rsp+0xE0], xmm15
00007175dc9d3fe3  sub rsp, 0x40
00007175dc9d3fe7  lea rdi, [rsp]
00007175dc9d3feb  lea rsi, [rsp+0x10]
00007175dc9d3ff0  lea rdx, [rsp+0x20]
00007175dc9d3ff5  lea rcx, [rsp+0x30]
00007175dc9d3ffa  mov r8d, 0x00
00007175dc9d4000  lea r9, [r15+0x3A8]
00007175dc9d4007  movaps [rdi], xmm14
00007175dc9d400b  movaps [rsi], xmm3
00007175dc9d400e  movaps [rdx], xmm1
00007175dc9d4011  movaps [rcx], xmm15
00007175dc9d4015  mov rax, 0x622B29CAFA50
00007175dc9d401f  call rax
00007175dc9d4021  movaps xmm14, [rsp]
00007175dc9d4026  add rsp, 0x40
00007175dc9d402a  vmovaps xmm0, [rsp]
00007175dc9d402f  vmovaps xmm1, [rsp+0x10]
00007175dc9d4035  vmovaps xmm2, [rsp+0x20]
00007175dc9d403b  vmovaps xmm3, [rsp+0x30]
00007175dc9d4041  vmovaps xmm4, [rsp+0x40]
00007175dc9d4047  vmovaps xmm5, [rsp+0x50]
00007175dc9d404d  vmovaps xmm6, [rsp+0x60]
00007175dc9d4053  vmovaps xmm7, [rsp+0x70]
00007175dc9d4059  vmovaps xmm8, [rsp+0x80]
00007175dc9d4062  vmovaps xmm9, [rsp+0x90]
00007175dc9d406b  vmovaps xmm10, [rsp+0xA0]
00007175dc9d4074  vmovaps xmm11, [rsp+0xB0]
00007175dc9d407d  vmovaps xmm12, [rsp+0xC0]
00007175dc9d4086  vmovaps xmm13, [rsp+0xD0]
00007175dc9d408f  vmovaps xmm15, [rsp+0xE0]
00007175dc9d4098  add rsp, 0xF0
00007175dc9d409f  pop r11
00007175dc9d40a1  pop r10
00007175dc9d40a3  pop r9
00007175dc9d40a5  pop r8
00007175dc9d40a7  pop rsi
00007175dc9d40a8  pop rdi
00007175dc9d40a9  pop rdx
00007175dc9d40aa  pop rcx
00007175dc9d40ab  pop rax
00007175dc9d40ac  add rsp, 0x08
00007175dc9d40b0  jmp 0x00007175DC9D2CF7
00007175dc9d40b5  sub rsp, 0x08
00007175dc9d40b9  push rax
00007175dc9d40ba  push rcx
00007175dc9d40bb  push rdx
00007175dc9d40bc  push rdi
00007175dc9d40bd  push rsi
00007175dc9d40be  push r8
00007175dc9d40c0  push r9
00007175dc9d40c2  push r10
00007175dc9d40c4  push r11
00007175dc9d40c6  sub rsp, 0xF0
00007175dc9d40cd  vmovaps [rsp], xmm0
00007175dc9d40d2  vmovaps [rsp+0x10], xmm1
00007175dc9d40d8  vmovaps [rsp+0x20], xmm2
00007175dc9d40de  vmovaps [rsp+0x30], xmm3
00007175dc9d40e4  vmovaps [rsp+0x40], xmm4
00007175dc9d40ea  vmovaps [rsp+0x50], xmm5
00007175dc9d40f0  vmovaps [rsp+0x60], xmm6
00007175dc9d40f6  vmovaps [rsp+0x70], xmm7
00007175dc9d40fc  vmovaps [rsp+0x80], xmm8
00007175dc9d4105  vmovaps [rsp+0x90], xmm9
00007175dc9d410e  vmovaps [rsp+0xA0], xmm10
00007175dc9d4117  vmovaps [rsp+0xB0], xmm11
00007175dc9d4120  vmovaps [rsp+0xC0], xmm12
00007175dc9d4129  vmovaps [rsp+0xD0], xmm14
00007175dc9d4132  vmovaps [rsp+0xE0], xmm15
00007175dc9d413b  sub rsp, 0x40
00007175dc9d413f  lea rdi, [rsp]
00007175dc9d4143  lea rsi, [rsp+0x10]
00007175dc9d4148  lea rdx, [rsp+0x20]
00007175dc9d414d  lea rcx, [rsp+0x30]
00007175dc9d4152  mov r8d, 0x00
00007175dc9d4158  lea r9, [r15+0x3A8]
00007175dc9d415f  movaps [rdi], xmm13
00007175dc9d4163  movaps [rsi], xmm15
00007175dc9d4167  movaps [rdx], xmm10
00007175dc9d416b  movaps [rcx], xmm1
00007175dc9d416e  mov rax, 0x622B29CAFA50
00007175dc9d4178  call rax
00007175dc9d417a  movaps xmm13, [rsp]
00007175dc9d417f  add rsp, 0x40
00007175dc9d4183  vmovaps xmm0, [rsp]
00007175dc9d4188  vmovaps xmm1, [rsp+0x10]
00007175dc9d418e  vmovaps xmm2, [rsp+0x20]
00007175dc9d4194  vmovaps xmm3, [rsp+0x30]
00007175dc9d419a  vmovaps xmm4, [rsp+0x40]
00007175dc9d41a0  vmovaps xmm5, [rsp+0x50]
00007175dc9d41a6  vmovaps xmm6, [rsp+0x60]
00007175dc9d41ac  vmovaps xmm7, [rsp+0x70]
00007175dc9d41b2  vmovaps xmm8, [rsp+0x80]
00007175dc9d41bb  vmovaps xmm9, [rsp+0x90]
00007175dc9d41c4  vmovaps xmm10, [rsp+0xA0]
00007175dc9d41cd  vmovaps xmm11, [rsp+0xB0]
00007175dc9d41d6  vmovaps xmm12, [rsp+0xC0]
00007175dc9d41df  vmovaps xmm14, [rsp+0xD0]
00007175dc9d41e8  vmovaps xmm15, [rsp+0xE0]
00007175dc9d41f1  add rsp, 0xF0
00007175dc9d41f8  pop r11
00007175dc9d41fa  pop r10
00007175dc9d41fc  pop r9
00007175dc9d41fe  pop r8
00007175dc9d4200  pop rsi
00007175dc9d4201  pop rdi
00007175dc9d4202  pop rdx
00007175dc9d4203  pop rcx
00007175dc9d4204  pop rax
00007175dc9d4205  add rsp, 0x08
00007175dc9d4209  jmp 0x00007175DC9D2D26
00007175dc9d420e  sub rsp, 0x08
00007175dc9d4212  push rax
00007175dc9d4213  push rcx
00007175dc9d4214  push rdx
00007175dc9d4215  push rdi
00007175dc9d4216  push rsi
00007175dc9d4217  push r8
00007175dc9d4219  push r9
00007175dc9d421b  push r10
00007175dc9d421d  push r11
00007175dc9d421f  sub rsp, 0xF0
00007175dc9d4226  vmovaps [rsp], xmm0
00007175dc9d422b  vmovaps [rsp+0x10], xmm1
00007175dc9d4231  vmovaps [rsp+0x20], xmm2
00007175dc9d4237  vmovaps [rsp+0x30], xmm3
00007175dc9d423d  vmovaps [rsp+0x40], xmm4
00007175dc9d4243  vmovaps [rsp+0x50], xmm5
00007175dc9d4249  vmovaps [rsp+0x60], xmm6
00007175dc9d424f  vmovaps [rsp+0x70], xmm7
00007175dc9d4255  vmovaps [rsp+0x80], xmm8
00007175dc9d425e  vmovaps [rsp+0x90], xmm9
00007175dc9d4267  vmovaps [rsp+0xA0], xmm11
00007175dc9d4270  vmovaps [rsp+0xB0], xmm12
00007175dc9d4279  vmovaps [rsp+0xC0], xmm13
00007175dc9d4282  vmovaps [rsp+0xD0], xmm14
00007175dc9d428b  vmovaps [rsp+0xE0], xmm15
00007175dc9d4294  sub rsp, 0x40
00007175dc9d4298  lea rdi, [rsp]
00007175dc9d429c  lea rsi, [rsp+0x10]
00007175dc9d42a1  lea rdx, [rsp+0x20]
00007175dc9d42a6  lea rcx, [rsp+0x30]
00007175dc9d42ab  mov r8d, 0x00
00007175dc9d42b1  lea r9, [r15+0x3A8]
00007175dc9d42b8  movaps [rdi], xmm10
00007175dc9d42bc  movaps [rsi], xmm15
00007175dc9d42c0  movaps [rdx], xmm11
00007175dc9d42c4  movaps [rcx], xmm1
00007175dc9d42c7  mov rax, 0x622B29CAFA50
00007175dc9d42d1  call rax
00007175dc9d42d3  movaps xmm10, [rsp]
00007175dc9d42d8  add rsp, 0x40
00007175dc9d42dc  vmovaps xmm0, [rsp]
00007175dc9d42e1  vmovaps xmm1, [rsp+0x10]
00007175dc9d42e7  vmovaps xmm2, [rsp+0x20]
00007175dc9d42ed  vmovaps xmm3, [rsp+0x30]
00007175dc9d42f3  vmovaps xmm4, [rsp+0x40]
00007175dc9d42f9  vmovaps xmm5, [rsp+0x50]
00007175dc9d42ff  vmovaps xmm6, [rsp+0x60]
00007175dc9d4305  vmovaps xmm7, [rsp+0x70]
00007175dc9d430b  vmovaps xmm8, [rsp+0x80]
00007175dc9d4314  vmovaps xmm9, [rsp+0x90]
00007175dc9d431d  vmovaps xmm11, [rsp+0xA0]
00007175dc9d4326  vmovaps xmm12, [rsp+0xB0]
00007175dc9d432f  vmovaps xmm13, [rsp+0xC0]
00007175dc9d4338  vmovaps xmm14, [rsp+0xD0]
00007175dc9d4341  vmovaps xmm15, [rsp+0xE0]
00007175dc9d434a  add rsp, 0xF0
00007175dc9d4351  pop r11
00007175dc9d4353  pop r10
00007175dc9d4355  pop r9
00007175dc9d4357  pop r8
00007175dc9d4359  pop rsi
00007175dc9d435a  pop rdi
00007175dc9d435b  pop rdx
00007175dc9d435c  pop rcx
00007175dc9d435d  pop rax
00007175dc9d435e  add rsp, 0x08
00007175dc9d4362  jmp 0x00007175DC9D2D55
00007175dc9d4367  sub rsp, 0x08
00007175dc9d436b  push rax
00007175dc9d436c  push rcx
00007175dc9d436d  push rdx
00007175dc9d436e  push rdi
00007175dc9d436f  push rsi
00007175dc9d4370  push r8
00007175dc9d4372  push r9
00007175dc9d4374  push r10
00007175dc9d4376  push r11
00007175dc9d4378  sub rsp, 0xF0
00007175dc9d437f  vmovaps [rsp], xmm0
00007175dc9d4384  vmovaps [rsp+0x10], xmm1
00007175dc9d438a  vmovaps [rsp+0x20], xmm2
00007175dc9d4390  vmovaps [rsp+0x30], xmm3
00007175dc9d4396  vmovaps [rsp+0x40], xmm4
00007175dc9d439c  vmovaps [rsp+0x50], xmm5
00007175dc9d43a2  vmovaps [rsp+0x60], xmm6
00007175dc9d43a8  vmovaps [rsp+0x70], xmm7
00007175dc9d43ae  vmovaps [rsp+0x80], xmm8
00007175dc9d43b7  vmovaps [rsp+0x90], xmm9
00007175dc9d43c0  vmovaps [rsp+0xA0], xmm10
00007175dc9d43c9  vmovaps [rsp+0xB0], xmm11
00007175dc9d43d2  vmovaps [rsp+0xC0], xmm12
00007175dc9d43db  vmovaps [rsp+0xD0], xmm13
00007175dc9d43e4  vmovaps [rsp+0xE0], xmm14
00007175dc9d43ed  sub rsp, 0x40
00007175dc9d43f1  lea rdi, [rsp]
00007175dc9d43f5  lea rsi, [rsp+0x10]
00007175dc9d43fa  lea rdx, [rsp+0x20]
00007175dc9d43ff  lea rcx, [rsp+0x30]
00007175dc9d4404  mov r8d, 0x00
00007175dc9d440a  lea r9, [r15+0x3A8]
00007175dc9d4411  movaps [rdi], xmm15
00007175dc9d4415  movaps [rsi], xmm12
00007175dc9d4419  movaps [rdx], xmm5
00007175dc9d441c  movaps [rcx], xmm1
00007175dc9d441f  mov rax, 0x622B29CAFA50
00007175dc9d4429  call rax
00007175dc9d442b  movaps xmm15, [rsp]
00007175dc9d4430  add rsp, 0x40
00007175dc9d4434  vmovaps xmm0, [rsp]
00007175dc9d4439  vmovaps xmm1, [rsp+0x10]
00007175dc9d443f  vmovaps xmm2, [rsp+0x20]
00007175dc9d4445  vmovaps xmm3, [rsp+0x30]
00007175dc9d444b  vmovaps xmm4, [rsp+0x40]
00007175dc9d4451  vmovaps xmm5, [rsp+0x50]
00007175dc9d4457  vmovaps xmm6, [rsp+0x60]
00007175dc9d445d  vmovaps xmm7, [rsp+0x70]
00007175dc9d4463  vmovaps xmm8, [rsp+0x80]
00007175dc9d446c  vmovaps xmm9, [rsp+0x90]
00007175dc9d4475  vmovaps xmm10, [rsp+0xA0]
00007175dc9d447e  vmovaps xmm11, [rsp+0xB0]
00007175dc9d4487  vmovaps xmm12, [rsp+0xC0]
00007175dc9d4490  vmovaps xmm13, [rsp+0xD0]
00007175dc9d4499  vmovaps xmm14, [rsp+0xE0]
00007175dc9d44a2  add rsp, 0xF0
00007175dc9d44a9  pop r11
00007175dc9d44ab  pop r10
00007175dc9d44ad  pop r9
00007175dc9d44af  pop r8
00007175dc9d44b1  pop rsi
00007175dc9d44b2  pop rdi
00007175dc9d44b3  pop rdx
00007175dc9d44b4  pop rcx
00007175dc9d44b5  pop rax
00007175dc9d44b6  add rsp, 0x08
00007175dc9d44ba  jmp 0x00007175DC9D2D7E
00007175dc9d44bf  sub rsp, 0x08
00007175dc9d44c3  push rax
00007175dc9d44c4  push rcx
00007175dc9d44c5  push rdx
00007175dc9d44c6  push rdi
00007175dc9d44c7  push rsi
00007175dc9d44c8  push r8
00007175dc9d44ca  push r9
00007175dc9d44cc  push r10
00007175dc9d44ce  push r11
00007175dc9d44d0  sub rsp, 0xF0
00007175dc9d44d7  vmovaps [rsp], xmm0
00007175dc9d44dc  vmovaps [rsp+0x10], xmm1
00007175dc9d44e2  vmovaps [rsp+0x20], xmm2
00007175dc9d44e8  vmovaps [rsp+0x30], xmm3
00007175dc9d44ee  vmovaps [rsp+0x40], xmm4
00007175dc9d44f4  vmovaps [rsp+0x50], xmm6
00007175dc9d44fa  vmovaps [rsp+0x60], xmm7
00007175dc9d4500  vmovaps [rsp+0x70], xmm8
00007175dc9d4506  vmovaps [rsp+0x80], xmm9
00007175dc9d450f  vmovaps [rsp+0x90], xmm10
00007175dc9d4518  vmovaps [rsp+0xA0], xmm11
00007175dc9d4521  vmovaps [rsp+0xB0], xmm12
00007175dc9d452a  vmovaps [rsp+0xC0], xmm13
00007175dc9d4533  vmovaps [rsp+0xD0], xmm14
00007175dc9d453c  vmovaps [rsp+0xE0], xmm15
00007175dc9d4545  sub rsp, 0x40
00007175dc9d4549  lea rdi, [rsp]
00007175dc9d454d  lea rsi, [rsp+0x10]
00007175dc9d4552  lea rdx, [rsp+0x20]
00007175dc9d4557  lea rcx, [rsp+0x30]
00007175dc9d455c  mov r8d, 0x00
00007175dc9d4562  lea r9, [r15+0x3A8]
00007175dc9d4569  movaps [rdi], xmm5
00007175dc9d456c  movaps [rsi], xmm13
00007175dc9d4570  movaps [rdx], xmm11
00007175dc9d4574  movaps [rcx], xmm12
00007175dc9d4578  mov rax, 0x622B29CAFA50
00007175dc9d4582  call rax
00007175dc9d4584  movaps xmm5, [rsp]
00007175dc9d4588  add rsp, 0x40
00007175dc9d458c  vmovaps xmm0, [rsp]
00007175dc9d4591  vmovaps xmm1, [rsp+0x10]
00007175dc9d4597  vmovaps xmm2, [rsp+0x20]
00007175dc9d459d  vmovaps xmm3, [rsp+0x30]
00007175dc9d45a3  vmovaps xmm4, [rsp+0x40]
00007175dc9d45a9  vmovaps xmm6, [rsp+0x50]
00007175dc9d45af  vmovaps xmm7, [rsp+0x60]
00007175dc9d45b5  vmovaps xmm8, [rsp+0x70]
00007175dc9d45bb  vmovaps xmm9, [rsp+0x80]
00007175dc9d45c4  vmovaps xmm10, [rsp+0x90]
00007175dc9d45cd  vmovaps xmm11, [rsp+0xA0]
00007175dc9d45d6  vmovaps xmm12, [rsp+0xB0]
00007175dc9d45df  vmovaps xmm13, [rsp+0xC0]
00007175dc9d45e8  vmovaps xmm14, [rsp+0xD0]
00007175dc9d45f1  vmovaps xmm15, [rsp+0xE0]
00007175dc9d45fa  add rsp, 0xF0
00007175dc9d4601  pop r11
00007175dc9d4603  pop r10
00007175dc9d4605  pop r9
00007175dc9d4607  pop r8
00007175dc9d4609  pop rsi
00007175dc9d460a  pop rdi
00007175dc9d460b  pop rdx
00007175dc9d460c  pop rcx
00007175dc9d460d  pop rax
00007175dc9d460e  add rsp, 0x08
00007175dc9d4612  jmp 0x00007175DC9D2DDD
00007175dc9d4617  sub rsp, 0x08
00007175dc9d461b  push rax
00007175dc9d461c  push rcx
00007175dc9d461d  push rdx
00007175dc9d461e  push rdi
00007175dc9d461f  push rsi
00007175dc9d4620  push r8
00007175dc9d4622  push r9
00007175dc9d4624  push r10
00007175dc9d4626  push r11
00007175dc9d4628  sub rsp, 0xF0
00007175dc9d462f  vmovaps [rsp], xmm0
00007175dc9d4634  vmovaps [rsp+0x10], xmm1
00007175dc9d463a  vmovaps [rsp+0x20], xmm2
00007175dc9d4640  vmovaps [rsp+0x30], xmm3
00007175dc9d4646  vmovaps [rsp+0x40], xmm4
00007175dc9d464c  vmovaps [rsp+0x50], xmm5
00007175dc9d4652  vmovaps [rsp+0x60], xmm6
00007175dc9d4658  vmovaps [rsp+0x70], xmm7
00007175dc9d465e  vmovaps [rsp+0x80], xmm8
00007175dc9d4667  vmovaps [rsp+0x90], xmm9
00007175dc9d4670  vmovaps [rsp+0xA0], xmm10
00007175dc9d4679  vmovaps [rsp+0xB0], xmm11
00007175dc9d4682  vmovaps [rsp+0xC0], xmm13
00007175dc9d468b  vmovaps [rsp+0xD0], xmm14
00007175dc9d4694  vmovaps [rsp+0xE0], xmm15
00007175dc9d469d  sub rsp, 0x40
00007175dc9d46a1  lea rdi, [rsp]
00007175dc9d46a5  lea rsi, [rsp+0x10]
00007175dc9d46aa  lea rdx, [rsp+0x20]
00007175dc9d46af  lea rcx, [rsp+0x30]
00007175dc9d46b4  mov r8d, 0x00
00007175dc9d46ba  lea r9, [r15+0x3A8]
00007175dc9d46c1  movaps [rdi], xmm12
00007175dc9d46c5  movaps [rsi], xmm14
00007175dc9d46c9  movaps [rdx], xmm9
00007175dc9d46cd  movaps [rcx], xmm13
00007175dc9d46d1  mov rax, 0x622B29CAFA50
00007175dc9d46db  call rax
00007175dc9d46dd  movaps xmm12, [rsp]
00007175dc9d46e2  add rsp, 0x40
00007175dc9d46e6  vmovaps xmm0, [rsp]
00007175dc9d46eb  vmovaps xmm1, [rsp+0x10]
00007175dc9d46f1  vmovaps xmm2, [rsp+0x20]
00007175dc9d46f7  vmovaps xmm3, [rsp+0x30]
00007175dc9d46fd  vmovaps xmm4, [rsp+0x40]
00007175dc9d4703  vmovaps xmm5, [rsp+0x50]
00007175dc9d4709  vmovaps xmm6, [rsp+0x60]
00007175dc9d470f  vmovaps xmm7, [rsp+0x70]
00007175dc9d4715  vmovaps xmm8, [rsp+0x80]
00007175dc9d471e  vmovaps xmm9, [rsp+0x90]
00007175dc9d4727  vmovaps xmm10, [rsp+0xA0]
00007175dc9d4730  vmovaps xmm11, [rsp+0xB0]
00007175dc9d4739  vmovaps xmm13, [rsp+0xC0]
00007175dc9d4742  vmovaps xmm14, [rsp+0xD0]
00007175dc9d474b  vmovaps xmm15, [rsp+0xE0]
00007175dc9d4754  add rsp, 0xF0
00007175dc9d475b  pop r11
00007175dc9d475d  pop r10
00007175dc9d475f  pop r9
00007175dc9d4761  pop r8
00007175dc9d4763  pop rsi
00007175dc9d4764  pop rdi
00007175dc9d4765  pop rdx
00007175dc9d4766  pop rcx
00007175dc9d4767  pop rax
00007175dc9d4768  add rsp, 0x08
00007175dc9d476c  jmp 0x00007175DC9D2E06
00007175dc9d4771  call 0x00007175DC80D4E0
00007175dc9d4776  jmp 0x00007175DC9D2E13
00007175dc9d477b  sub rsp, 0x08
00007175dc9d477f  push rax
00007175dc9d4780  push rcx
00007175dc9d4781  push rdx
00007175dc9d4782  push rdi
00007175dc9d4783  push rsi
00007175dc9d4784  push r8
00007175dc9d4786  push r9
00007175dc9d4788  push r10
00007175dc9d478a  push r11
00007175dc9d478c  sub rsp, 0xF0
00007175dc9d4793  vmovaps [rsp], xmm0
00007175dc9d4798  vmovaps [rsp+0x10], xmm1
00007175dc9d479e  vmovaps [rsp+0x20], xmm2
00007175dc9d47a4  vmovaps [rsp+0x30], xmm3
00007175dc9d47aa  vmovaps [rsp+0x40], xmm4
00007175dc9d47b0  vmovaps [rsp+0x50], xmm5
00007175dc9d47b6  vmovaps [rsp+0x60], xmm6
00007175dc9d47bc  vmovaps [rsp+0x70], xmm7
00007175dc9d47c2  vmovaps [rsp+0x80], xmm8
00007175dc9d47cb  vmovaps [rsp+0x90], xmm9
00007175dc9d47d4  vmovaps [rsp+0xA0], xmm10
00007175dc9d47dd  vmovaps [rsp+0xB0], xmm12
00007175dc9d47e6  vmovaps [rsp+0xC0], xmm13
00007175dc9d47ef  vmovaps [rsp+0xD0], xmm14
00007175dc9d47f8  vmovaps [rsp+0xE0], xmm15
00007175dc9d4801  sub rsp, 0x40
00007175dc9d4805  lea rdi, [rsp]
00007175dc9d4809  lea rsi, [rsp+0x10]
00007175dc9d480e  lea rdx, [rsp+0x20]
00007175dc9d4813  lea rcx, [rsp+0x30]
00007175dc9d4818  mov r8d, 0x00
00007175dc9d481e  lea r9, [r15+0x3A8]
00007175dc9d4825  movaps [rdi], xmm11
00007175dc9d4829  movaps [rsi], xmm10
00007175dc9d482d  movaps [rdx], xmm8
00007175dc9d4831  movaps [rcx], xmm13
00007175dc9d4835  mov rax, 0x622B29CAFA50
00007175dc9d483f  call rax
00007175dc9d4841  movaps xmm11, [rsp]
00007175dc9d4846  add rsp, 0x40
00007175dc9d484a  vmovaps xmm0, [rsp]
00007175dc9d484f  vmovaps xmm1, [rsp+0x10]
00007175dc9d4855  vmovaps xmm2, [rsp+0x20]
00007175dc9d485b  vmovaps xmm3, [rsp+0x30]
00007175dc9d4861  vmovaps xmm4, [rsp+0x40]
00007175dc9d4867  vmovaps xmm5, [rsp+0x50]
00007175dc9d486d  vmovaps xmm6, [rsp+0x60]
00007175dc9d4873  vmovaps xmm7, [rsp+0x70]
00007175dc9d4879  vmovaps xmm8, [rsp+0x80]
00007175dc9d4882  vmovaps xmm9, [rsp+0x90]
00007175dc9d488b  vmovaps xmm10, [rsp+0xA0]
00007175dc9d4894  vmovaps xmm12, [rsp+0xB0]
00007175dc9d489d  vmovaps xmm13, [rsp+0xC0]
00007175dc9d48a6  vmovaps xmm14, [rsp+0xD0]
00007175dc9d48af  vmovaps xmm15, [rsp+0xE0]
00007175dc9d48b8  add rsp, 0xF0
00007175dc9d48bf  pop r11
00007175dc9d48c1  pop r10
00007175dc9d48c3  pop r9
00007175dc9d48c5  pop r8
00007175dc9d48c7  pop rsi
00007175dc9d48c8  pop rdi
00007175dc9d48c9  pop rdx
00007175dc9d48ca  pop rcx
00007175dc9d48cb  pop rax
00007175dc9d48cc  add rsp, 0x08
00007175dc9d48d0  jmp 0x00007175DC9D2E44
00007175dc9d48d5  sub rsp, 0x08
00007175dc9d48d9  push rax
00007175dc9d48da  push rcx
00007175dc9d48db  push rdx
00007175dc9d48dc  push rdi
00007175dc9d48dd  push rsi
00007175dc9d48de  push r8
00007175dc9d48e0  push r9
00007175dc9d48e2  push r10
00007175dc9d48e4  push r11
00007175dc9d48e6  sub rsp, 0xF0
00007175dc9d48ed  vmovaps [rsp], xmm0
00007175dc9d48f2  vmovaps [rsp+0x10], xmm1
00007175dc9d48f8  vmovaps [rsp+0x20], xmm2
00007175dc9d48fe  vmovaps [rsp+0x30], xmm3
00007175dc9d4904  vmovaps [rsp+0x40], xmm4
00007175dc9d490a  vmovaps [rsp+0x50], xmm5
00007175dc9d4910  vmovaps [rsp+0x60], xmm6
00007175dc9d4916  vmovaps [rsp+0x70], xmm7
00007175dc9d491c  vmovaps [rsp+0x80], xmm8
00007175dc9d4925  vmovaps [rsp+0x90], xmm9
00007175dc9d492e  vmovaps [rsp+0xA0], xmm11
00007175dc9d4937  vmovaps [rsp+0xB0], xmm12
00007175dc9d4940  vmovaps [rsp+0xC0], xmm13
00007175dc9d4949  vmovaps [rsp+0xD0], xmm14
00007175dc9d4952  vmovaps [rsp+0xE0], xmm15
00007175dc9d495b  sub rsp, 0x40
00007175dc9d495f  lea rdi, [rsp]
00007175dc9d4963  lea rsi, [rsp+0x10]
00007175dc9d4968  lea rdx, [rsp+0x20]
00007175dc9d496d  lea rcx, [rsp+0x30]
00007175dc9d4972  mov r8d, 0x00
00007175dc9d4978  lea r9, [r15+0x3A8]
00007175dc9d497f  movaps [rdi], xmm10
00007175dc9d4983  movaps [rsi], xmm15
00007175dc9d4987  movaps [rdx], xmm1
00007175dc9d498a  movaps [rcx], xmm13
00007175dc9d498e  mov rax, 0x622B29CAFA50
00007175dc9d4998  call rax
00007175dc9d499a  movaps xmm10, [rsp]
00007175dc9d499f  add rsp, 0x40
00007175dc9d49a3  vmovaps xmm0, [rsp]
00007175dc9d49a8  vmovaps xmm1, [rsp+0x10]
00007175dc9d49ae  vmovaps xmm2, [rsp+0x20]
00007175dc9d49b4  vmovaps xmm3, [rsp+0x30]
00007175dc9d49ba  vmovaps xmm4, [rsp+0x40]
00007175dc9d49c0  vmovaps xmm5, [rsp+0x50]
00007175dc9d49c6  vmovaps xmm6, [rsp+0x60]
00007175dc9d49cc  vmovaps xmm7, [rsp+0x70]
00007175dc9d49d2  vmovaps xmm8, [rsp+0x80]
00007175dc9d49db  vmovaps xmm9, [rsp+0x90]
00007175dc9d49e4  vmovaps xmm11, [rsp+0xA0]
00007175dc9d49ed  vmovaps xmm12, [rsp+0xB0]
00007175dc9d49f6  vmovaps xmm13, [rsp+0xC0]
00007175dc9d49ff  vmovaps xmm14, [rsp+0xD0]
00007175dc9d4a08  vmovaps xmm15, [rsp+0xE0]
00007175dc9d4a11  add rsp, 0xF0
00007175dc9d4a18  pop r11
00007175dc9d4a1a  pop r10
00007175dc9d4a1c  pop r9
00007175dc9d4a1e  pop r8
00007175dc9d4a20  pop rsi
00007175dc9d4a21  pop rdi
00007175dc9d4a22  pop rdx
00007175dc9d4a23  pop rcx
00007175dc9d4a24  pop rax
00007175dc9d4a25  add rsp, 0x08
00007175dc9d4a29  jmp 0x00007175DC9D2E6D
00007175dc9d4a2e  call 0x00007175DC7FF430
00007175dc9d4a33  jmp 0x00007175DC9D2E8F
00007175dc9d4a38  call 0x00007175DC80E760
00007175dc9d4a3d  jmp 0x00007175DC9D2E99
00007175dc9d4a42  sub rsp, 0x08
00007175dc9d4a46  push rax
00007175dc9d4a47  push rcx
00007175dc9d4a48  push rdx
00007175dc9d4a49  push rdi
00007175dc9d4a4a  push rsi
00007175dc9d4a4b  push r8
00007175dc9d4a4d  push r9
00007175dc9d4a4f  push r10
00007175dc9d4a51  push r11
00007175dc9d4a53  sub rsp, 0xF0
00007175dc9d4a5a  vmovaps [rsp], xmm0
00007175dc9d4a5f  vmovaps [rsp+0x10], xmm1
00007175dc9d4a65  vmovaps [rsp+0x20], xmm2
00007175dc9d4a6b  vmovaps [rsp+0x30], xmm3
00007175dc9d4a71  vmovaps [rsp+0x40], xmm4
00007175dc9d4a77  vmovaps [rsp+0x50], xmm5
00007175dc9d4a7d  vmovaps [rsp+0x60], xmm6
00007175dc9d4a83  vmovaps [rsp+0x70], xmm7
00007175dc9d4a89  vmovaps [rsp+0x80], xmm9
00007175dc9d4a92  vmovaps [rsp+0x90], xmm10
00007175dc9d4a9b  vmovaps [rsp+0xA0], xmm11
00007175dc9d4aa4  vmovaps [rsp+0xB0], xmm12
00007175dc9d4aad  vmovaps [rsp+0xC0], xmm13
00007175dc9d4ab6  vmovaps [rsp+0xD0], xmm14
00007175dc9d4abf  vmovaps [rsp+0xE0], xmm15
00007175dc9d4ac8  sub rsp, 0x40
00007175dc9d4acc  lea rdi, [rsp]
00007175dc9d4ad0  lea rsi, [rsp+0x10]
00007175dc9d4ad5  lea rdx, [rsp+0x20]
00007175dc9d4ada  lea rcx, [rsp+0x30]
00007175dc9d4adf  mov r8d, 0x00
00007175dc9d4ae5  lea r9, [r15+0x3A8]
00007175dc9d4aec  movaps [rdi], xmm8
00007175dc9d4af0  movaps [rsi], xmm5
00007175dc9d4af3  movaps [rdx], xmm9
00007175dc9d4af7  movaps [rcx], xmm13
00007175dc9d4afb  mov rax, 0x622B29CAFA50
00007175dc9d4b05  call rax
00007175dc9d4b07  movaps xmm8, [rsp]
00007175dc9d4b0c  add rsp, 0x40
00007175dc9d4b10  vmovaps xmm0, [rsp]
00007175dc9d4b15  vmovaps xmm1, [rsp+0x10]
00007175dc9d4b1b  vmovaps xmm2, [rsp+0x20]
00007175dc9d4b21  vmovaps xmm3, [rsp+0x30]
00007175dc9d4b27  vmovaps xmm4, [rsp+0x40]
00007175dc9d4b2d  vmovaps xmm5, [rsp+0x50]
00007175dc9d4b33  vmovaps xmm6, [rsp+0x60]
00007175dc9d4b39  vmovaps xmm7, [rsp+0x70]
00007175dc9d4b3f  vmovaps xmm9, [rsp+0x80]
00007175dc9d4b48  vmovaps xmm10, [rsp+0x90]
00007175dc9d4b51  vmovaps xmm11, [rsp+0xA0]
00007175dc9d4b5a  vmovaps xmm12, [rsp+0xB0]
00007175dc9d4b63  vmovaps xmm13, [rsp+0xC0]
00007175dc9d4b6c  vmovaps xmm14, [rsp+0xD0]
00007175dc9d4b75  vmovaps xmm15, [rsp+0xE0]
00007175dc9d4b7e  add rsp, 0xF0
00007175dc9d4b85  pop r11
00007175dc9d4b87  pop r10
00007175dc9d4b89  pop r9
00007175dc9d4b8b  pop r8
00007175dc9d4b8d  pop rsi
00007175dc9d4b8e  pop rdi
00007175dc9d4b8f  pop rdx
00007175dc9d4b90  pop rcx
00007175dc9d4b91  pop rax
00007175dc9d4b92  add rsp, 0x08
00007175dc9d4b96  jmp 0x00007175DC9D2ED8
00007175dc9d4b9b  sub rsp, 0x08
00007175dc9d4b9f  push rax
00007175dc9d4ba0  push rcx
00007175dc9d4ba1  push rdx
00007175dc9d4ba2  push rdi
00007175dc9d4ba3  push rsi
00007175dc9d4ba4  push r8
00007175dc9d4ba6  push r9
00007175dc9d4ba8  push r10
00007175dc9d4baa  push r11
00007175dc9d4bac  sub rsp, 0xF0
00007175dc9d4bb3  vmovaps [rsp], xmm0
00007175dc9d4bb8  vmovaps [rsp+0x10], xmm1
00007175dc9d4bbe  vmovaps [rsp+0x20], xmm2
00007175dc9d4bc4  vmovaps [rsp+0x30], xmm3
00007175dc9d4bca  vmovaps [rsp+0x40], xmm4
00007175dc9d4bd0  vmovaps [rsp+0x50], xmm5
00007175dc9d4bd6  vmovaps [rsp+0x60], xmm6
00007175dc9d4bdc  vmovaps [rsp+0x70], xmm7
00007175dc9d4be2  vmovaps [rsp+0x80], xmm8
00007175dc9d4beb  vmovaps [rsp+0x90], xmm10
00007175dc9d4bf4  vmovaps [rsp+0xA0], xmm11
00007175dc9d4bfd  vmovaps [rsp+0xB0], xmm12
00007175dc9d4c06  vmovaps [rsp+0xC0], xmm13
00007175dc9d4c0f  vmovaps [rsp+0xD0], xmm14
00007175dc9d4c18  vmovaps [rsp+0xE0], xmm15
00007175dc9d4c21  sub rsp, 0x40
00007175dc9d4c25  lea rdi, [rsp]
00007175dc9d4c29  lea rsi, [rsp+0x10]
00007175dc9d4c2e  lea rdx, [rsp+0x20]
00007175dc9d4c33  lea rcx, [rsp+0x30]
00007175dc9d4c38  mov r8d, 0x00
00007175dc9d4c3e  lea r9, [r15+0x3A8]
00007175dc9d4c45  movaps [rdi], xmm9
00007175dc9d4c49  movaps [rsi], xmm12
00007175dc9d4c4d  movaps [rdx], xmm7
00007175dc9d4c50  movaps [rcx], xmm13
00007175dc9d4c54  mov rax, 0x622B29CAFA50
00007175dc9d4c5e  call rax
00007175dc9d4c60  movaps xmm9, [rsp]
00007175dc9d4c65  add rsp, 0x40
00007175dc9d4c69  vmovaps xmm0, [rsp]
00007175dc9d4c6e  vmovaps xmm1, [rsp+0x10]
00007175dc9d4c74  vmovaps xmm2, [rsp+0x20]
00007175dc9d4c7a  vmovaps xmm3, [rsp+0x30]
00007175dc9d4c80  vmovaps xmm4, [rsp+0x40]
00007175dc9d4c86  vmovaps xmm5, [rsp+0x50]
00007175dc9d4c8c  vmovaps xmm6, [rsp+0x60]
00007175dc9d4c92  vmovaps xmm7, [rsp+0x70]
00007175dc9d4c98  vmovaps xmm8, [rsp+0x80]
00007175dc9d4ca1  vmovaps xmm10, [rsp+0x90]
00007175dc9d4caa  vmovaps xmm11, [rsp+0xA0]
00007175dc9d4cb3  vmovaps xmm12, [rsp+0xB0]
00007175dc9d4cbc  vmovaps xmm13, [rsp+0xC0]
00007175dc9d4cc5  vmovaps xmm14, [rsp+0xD0]
00007175dc9d4cce  vmovaps xmm15, [rsp+0xE0]
00007175dc9d4cd7  add rsp, 0xF0
00007175dc9d4cde  pop r11
00007175dc9d4ce0  pop r10
00007175dc9d4ce2  pop r9
00007175dc9d4ce4  pop r8
00007175dc9d4ce6  pop rsi
00007175dc9d4ce7  pop rdi
00007175dc9d4ce8  pop rdx
00007175dc9d4ce9  pop rcx
00007175dc9d4cea  pop rax
00007175dc9d4ceb  add rsp, 0x08
00007175dc9d4cef  jmp 0x00007175DC9D2F01
00007175dc9d4cf4  sub rsp, 0x08
00007175dc9d4cf8  push rax
00007175dc9d4cf9  push rcx
00007175dc9d4cfa  push rdx
00007175dc9d4cfb  push rdi
00007175dc9d4cfc  push rsi
00007175dc9d4cfd  push r8
00007175dc9d4cff  push r9
00007175dc9d4d01  push r10
00007175dc9d4d03  push r11
00007175dc9d4d05  sub rsp, 0xF0
00007175dc9d4d0c  vmovaps [rsp], xmm0
00007175dc9d4d11  vmovaps [rsp+0x10], xmm1
00007175dc9d4d17  vmovaps [rsp+0x20], xmm2
00007175dc9d4d1d  vmovaps [rsp+0x30], xmm3
00007175dc9d4d23  vmovaps [rsp+0x40], xmm4
00007175dc9d4d29  vmovaps [rsp+0x50], xmm5
00007175dc9d4d2f  vmovaps [rsp+0x60], xmm6
00007175dc9d4d35  vmovaps [rsp+0x70], xmm7
00007175dc9d4d3b  vmovaps [rsp+0x80], xmm8
00007175dc9d4d44  vmovaps [rsp+0x90], xmm9
00007175dc9d4d4d  vmovaps [rsp+0xA0], xmm10
00007175dc9d4d56  vmovaps [rsp+0xB0], xmm11
00007175dc9d4d5f  vmovaps [rsp+0xC0], xmm13
00007175dc9d4d68  vmovaps [rsp+0xD0], xmm14
00007175dc9d4d71  vmovaps [rsp+0xE0], xmm15
00007175dc9d4d7a  sub rsp, 0x40
00007175dc9d4d7e  lea rdi, [rsp]
00007175dc9d4d82  lea rsi, [rsp+0x10]
00007175dc9d4d87  lea rdx, [rsp+0x20]
00007175dc9d4d8c  lea rcx, [rsp+0x30]
00007175dc9d4d91  mov r8d, 0x00
00007175dc9d4d97  lea r9, [r15+0x3A8]
00007175dc9d4d9e  movaps [rdi], xmm12
00007175dc9d4da2  movaps [rsi], xmm11
00007175dc9d4da6  movaps [rdx], xmm6
00007175dc9d4da9  movaps [rcx], xmm13
00007175dc9d4dad  mov rax, 0x622B29CAFA50
00007175dc9d4db7  call rax
00007175dc9d4db9  movaps xmm12, [rsp]
00007175dc9d4dbe  add rsp, 0x40
00007175dc9d4dc2  vmovaps xmm0, [rsp]
00007175dc9d4dc7  vmovaps xmm1, [rsp+0x10]
00007175dc9d4dcd  vmovaps xmm2, [rsp+0x20]
00007175dc9d4dd3  vmovaps xmm3, [rsp+0x30]
00007175dc9d4dd9  vmovaps xmm4, [rsp+0x40]
00007175dc9d4ddf  vmovaps xmm5, [rsp+0x50]
00007175dc9d4de5  vmovaps xmm6, [rsp+0x60]
00007175dc9d4deb  vmovaps xmm7, [rsp+0x70]
00007175dc9d4df1  vmovaps xmm8, [rsp+0x80]
00007175dc9d4dfa  vmovaps xmm9, [rsp+0x90]
00007175dc9d4e03  vmovaps xmm10, [rsp+0xA0]
00007175dc9d4e0c  vmovaps xmm11, [rsp+0xB0]
00007175dc9d4e15  vmovaps xmm13, [rsp+0xC0]
00007175dc9d4e1e  vmovaps xmm14, [rsp+0xD0]
00007175dc9d4e27  vmovaps xmm15, [rsp+0xE0]
00007175dc9d4e30  add rsp, 0xF0
00007175dc9d4e37  pop r11
00007175dc9d4e39  pop r10
00007175dc9d4e3b  pop r9
00007175dc9d4e3d  pop r8
00007175dc9d4e3f  pop rsi
00007175dc9d4e40  pop rdi
00007175dc9d4e41  pop rdx
00007175dc9d4e42  pop rcx
00007175dc9d4e43  pop rax
00007175dc9d4e44  add rsp, 0x08
00007175dc9d4e48  jmp 0x00007175DC9D2F2A
00007175dc9d4e4d  sub rsp, 0x08
00007175dc9d4e51  push rax
00007175dc9d4e52  push rcx
00007175dc9d4e53  push rdx
00007175dc9d4e54  push rdi
00007175dc9d4e55  push rsi
00007175dc9d4e56  push r8
00007175dc9d4e58  push r9
00007175dc9d4e5a  push r10
00007175dc9d4e5c  push r11
00007175dc9d4e5e  sub rsp, 0xF0
00007175dc9d4e65  vmovaps [rsp], xmm0
00007175dc9d4e6a  vmovaps [rsp+0x10], xmm1
00007175dc9d4e70  vmovaps [rsp+0x20], xmm2
00007175dc9d4e76  vmovaps [rsp+0x30], xmm3
00007175dc9d4e7c  vmovaps [rsp+0x40], xmm4
00007175dc9d4e82  vmovaps [rsp+0x50], xmm5
00007175dc9d4e88  vmovaps [rsp+0x60], xmm6
00007175dc9d4e8e  vmovaps [rsp+0x70], xmm8
00007175dc9d4e94  vmovaps [rsp+0x80], xmm9
00007175dc9d4e9d  vmovaps [rsp+0x90], xmm10
00007175dc9d4ea6  vmovaps [rsp+0xA0], xmm11
00007175dc9d4eaf  vmovaps [rsp+0xB0], xmm12
00007175dc9d4eb8  vmovaps [rsp+0xC0], xmm13
00007175dc9d4ec1  vmovaps [rsp+0xD0], xmm14
00007175dc9d4eca  vmovaps [rsp+0xE0], xmm15
00007175dc9d4ed3  sub rsp, 0x40
00007175dc9d4ed7  lea rdi, [rsp]
00007175dc9d4edb  lea rsi, [rsp+0x10]
00007175dc9d4ee0  lea rdx, [rsp+0x20]
00007175dc9d4ee5  lea rcx, [rsp+0x30]
00007175dc9d4eea  mov r8d, 0x00
00007175dc9d4ef0  lea r9, [r15+0x3A8]
00007175dc9d4ef7  movaps [rdi], xmm7
00007175dc9d4efa  movaps [rsi], xmm10
00007175dc9d4efe  movaps [rdx], xmm11
00007175dc9d4f02  movaps [rcx], xmm13
00007175dc9d4f06  mov rax, 0x622B29CAFA50
00007175dc9d4f10  call rax
00007175dc9d4f12  movaps xmm7, [rsp]
00007175dc9d4f16  add rsp, 0x40
00007175dc9d4f1a  vmovaps xmm0, [rsp]
00007175dc9d4f1f  vmovaps xmm1, [rsp+0x10]
00007175dc9d4f25  vmovaps xmm2, [rsp+0x20]
00007175dc9d4f2b  vmovaps xmm3, [rsp+0x30]
00007175dc9d4f31  vmovaps xmm4, [rsp+0x40]
00007175dc9d4f37  vmovaps xmm5, [rsp+0x50]
00007175dc9d4f3d  vmovaps xmm6, [rsp+0x60]
00007175dc9d4f43  vmovaps xmm8, [rsp+0x70]
00007175dc9d4f49  vmovaps xmm9, [rsp+0x80]
00007175dc9d4f52  vmovaps xmm10, [rsp+0x90]
00007175dc9d4f5b  vmovaps xmm11, [rsp+0xA0]
00007175dc9d4f64  vmovaps xmm12, [rsp+0xB0]
00007175dc9d4f6d  vmovaps xmm13, [rsp+0xC0]
00007175dc9d4f76  vmovaps xmm14, [rsp+0xD0]
00007175dc9d4f7f  vmovaps xmm15, [rsp+0xE0]
00007175dc9d4f88  add rsp, 0xF0
00007175dc9d4f8f  pop r11
00007175dc9d4f91  pop r10
00007175dc9d4f93  pop r9
00007175dc9d4f95  pop r8
00007175dc9d4f97  pop rsi
00007175dc9d4f98  pop rdi
00007175dc9d4f99  pop rdx
00007175dc9d4f9a  pop rcx
00007175dc9d4f9b  pop rax
00007175dc9d4f9c  add rsp, 0x08
00007175dc9d4fa0  jmp 0x00007175DC9D2F58
00007175dc9d4fa5  call 0x00007175DC80C260
00007175dc9d4faa  jmp 0x00007175DC9D2F62
00007175dc9d4faf  call 0x00007175DC809D70
00007175dc9d4fb4  jmp 0x00007175DC9D2F6C
00007175dc9d4fb9  sub rsp, 0x08
00007175dc9d4fbd  push rax
00007175dc9d4fbe  push rcx
00007175dc9d4fbf  push rdx
00007175dc9d4fc0  push rdi
00007175dc9d4fc1  push rsi
00007175dc9d4fc2  push r8
00007175dc9d4fc4  push r9
00007175dc9d4fc6  push r10
00007175dc9d4fc8  push r11
00007175dc9d4fca  sub rsp, 0xF0
00007175dc9d4fd1  vmovaps [rsp], xmm0
00007175dc9d4fd6  vmovaps [rsp+0x10], xmm1
00007175dc9d4fdc  vmovaps [rsp+0x20], xmm2
00007175dc9d4fe2  vmovaps [rsp+0x30], xmm3
00007175dc9d4fe8  vmovaps [rsp+0x40], xmm4
00007175dc9d4fee  vmovaps [rsp+0x50], xmm5
00007175dc9d4ff4  vmovaps [rsp+0x60], xmm7
00007175dc9d4ffa  vmovaps [rsp+0x70], xmm8
00007175dc9d5000  vmovaps [rsp+0x80], xmm9
00007175dc9d5009  vmovaps [rsp+0x90], xmm10
00007175dc9d5012  vmovaps [rsp+0xA0], xmm11
00007175dc9d501b  vmovaps [rsp+0xB0], xmm12
00007175dc9d5024  vmovaps [rsp+0xC0], xmm13
00007175dc9d502d  vmovaps [rsp+0xD0], xmm14
00007175dc9d5036  vmovaps [rsp+0xE0], xmm15
00007175dc9d503f  sub rsp, 0x40
00007175dc9d5043  lea rdi, [rsp]
00007175dc9d5047  lea rsi, [rsp+0x10]
00007175dc9d504c  lea rdx, [rsp+0x20]
00007175dc9d5051  lea rcx, [rsp+0x30]
00007175dc9d5056  mov r8d, 0x00
00007175dc9d505c  lea r9, [r15+0x3A8]
00007175dc9d5063  movaps [rdi], xmm6
00007175dc9d5066  movaps [rsi], xmm8
00007175dc9d506a  movaps [rdx], xmm15
00007175dc9d506e  movaps [rcx], xmm10
00007175dc9d5072  mov rax, 0x622B29CAFA50
00007175dc9d507c  call rax
00007175dc9d507e  movaps xmm6, [rsp]
00007175dc9d5082  add rsp, 0x40
00007175dc9d5086  vmovaps xmm0, [rsp]
00007175dc9d508b  vmovaps xmm1, [rsp+0x10]
00007175dc9d5091  vmovaps xmm2, [rsp+0x20]
00007175dc9d5097  vmovaps xmm3, [rsp+0x30]
00007175dc9d509d  vmovaps xmm4, [rsp+0x40]
00007175dc9d50a3  vmovaps xmm5, [rsp+0x50]
00007175dc9d50a9  vmovaps xmm7, [rsp+0x60]
00007175dc9d50af  vmovaps xmm8, [rsp+0x70]
00007175dc9d50b5  vmovaps xmm9, [rsp+0x80]
00007175dc9d50be  vmovaps xmm10, [rsp+0x90]
00007175dc9d50c7  vmovaps xmm11, [rsp+0xA0]
00007175dc9d50d0  vmovaps xmm12, [rsp+0xB0]
00007175dc9d50d9  vmovaps xmm13, [rsp+0xC0]
00007175dc9d50e2  vmovaps xmm14, [rsp+0xD0]
00007175dc9d50eb  vmovaps xmm15, [rsp+0xE0]
00007175dc9d50f4  add rsp, 0xF0
00007175dc9d50fb  pop r11
00007175dc9d50fd  pop r10
00007175dc9d50ff  pop r9
00007175dc9d5101  pop r8
00007175dc9d5103  pop rsi
00007175dc9d5104  pop rdi
00007175dc9d5105  pop rdx
00007175dc9d5106  pop rcx
00007175dc9d5107  pop rax
00007175dc9d5108  add rsp, 0x08
00007175dc9d510c  jmp 0x00007175DC9D2FA4
00007175dc9d5111  sub rsp, 0x08
00007175dc9d5115  push rax
00007175dc9d5116  push rcx
00007175dc9d5117  push rdx
00007175dc9d5118  push rdi
00007175dc9d5119  push rsi
00007175dc9d511a  push r8
00007175dc9d511c  push r9
00007175dc9d511e  push r10
00007175dc9d5120  push r11
00007175dc9d5122  sub rsp, 0xF0
00007175dc9d5129  vmovaps [rsp], xmm0
00007175dc9d512e  vmovaps [rsp+0x10], xmm1
00007175dc9d5134  vmovaps [rsp+0x20], xmm2
00007175dc9d513a  vmovaps [rsp+0x30], xmm3
00007175dc9d5140  vmovaps [rsp+0x40], xmm4
00007175dc9d5146  vmovaps [rsp+0x50], xmm5
00007175dc9d514c  vmovaps [rsp+0x60], xmm6
00007175dc9d5152  vmovaps [rsp+0x70], xmm7
00007175dc9d5158  vmovaps [rsp+0x80], xmm8
00007175dc9d5161  vmovaps [rsp+0x90], xmm9
00007175dc9d516a  vmovaps [rsp+0xA0], xmm11
00007175dc9d5173  vmovaps [rsp+0xB0], xmm12
00007175dc9d517c  vmovaps [rsp+0xC0], xmm13
00007175dc9d5185  vmovaps [rsp+0xD0], xmm14
00007175dc9d518e  vmovaps [rsp+0xE0], xmm15
00007175dc9d5197  sub rsp, 0x40
00007175dc9d519b  lea rdi, [rsp]
00007175dc9d519f  lea rsi, [rsp+0x10]
00007175dc9d51a4  lea rdx, [rsp+0x20]
00007175dc9d51a9  lea rcx, [rsp+0x30]
00007175dc9d51ae  mov r8d, 0x00
00007175dc9d51b4  lea r9, [r15+0x3A8]
00007175dc9d51bb  movaps [rdi], xmm10
00007175dc9d51bf  movaps [rsi], xmm9
00007175dc9d51c3  movaps [rdx], xmm13
00007175dc9d51c7  movaps [rcx], xmm15
00007175dc9d51cb  mov rax, 0x622B29CAFA50
00007175dc9d51d5  call rax
00007175dc9d51d7  movaps xmm10, [rsp]
00007175dc9d51dc  add rsp, 0x40
00007175dc9d51e0  vmovaps xmm0, [rsp]
00007175dc9d51e5  vmovaps xmm1, [rsp+0x10]
00007175dc9d51eb  vmovaps xmm2, [rsp+0x20]
00007175dc9d51f1  vmovaps xmm3, [rsp+0x30]
00007175dc9d51f7  vmovaps xmm4, [rsp+0x40]
00007175dc9d51fd  vmovaps xmm5, [rsp+0x50]
00007175dc9d5203  vmovaps xmm6, [rsp+0x60]
00007175dc9d5209  vmovaps xmm7, [rsp+0x70]
00007175dc9d520f  vmovaps xmm8, [rsp+0x80]
00007175dc9d5218  vmovaps xmm9, [rsp+0x90]
00007175dc9d5221  vmovaps xmm11, [rsp+0xA0]
00007175dc9d522a  vmovaps xmm12, [rsp+0xB0]
00007175dc9d5233  vmovaps xmm13, [rsp+0xC0]
00007175dc9d523c  vmovaps xmm14, [rsp+0xD0]
00007175dc9d5245  vmovaps xmm15, [rsp+0xE0]
00007175dc9d524e  add rsp, 0xF0
00007175dc9d5255  pop r11
00007175dc9d5257  pop r10
00007175dc9d5259  pop r9
00007175dc9d525b  pop r8
00007175dc9d525d  pop rsi
00007175dc9d525e  pop rdi
00007175dc9d525f  pop rdx
00007175dc9d5260  pop rcx
00007175dc9d5261  pop rax
00007175dc9d5262  add rsp, 0x08
00007175dc9d5266  jmp 0x00007175DC9D2FCD
00007175dc9d526b  sub rsp, 0x08
00007175dc9d526f  push rax
00007175dc9d5270  push rcx
00007175dc9d5271  push rdx
00007175dc9d5272  push rdi
00007175dc9d5273  push rsi
00007175dc9d5274  push r8
00007175dc9d5276  push r9
00007175dc9d5278  push r10
00007175dc9d527a  push r11
00007175dc9d527c  sub rsp, 0xF0
00007175dc9d5283  vmovaps [rsp], xmm0
00007175dc9d5288  vmovaps [rsp+0x10], xmm1
00007175dc9d528e  vmovaps [rsp+0x20], xmm2
00007175dc9d5294  vmovaps [rsp+0x30], xmm3
00007175dc9d529a  vmovaps [rsp+0x40], xmm4
00007175dc9d52a0  vmovaps [rsp+0x50], xmm5
00007175dc9d52a6  vmovaps [rsp+0x60], xmm6
00007175dc9d52ac  vmovaps [rsp+0x70], xmm7
00007175dc9d52b2  vmovaps [rsp+0x80], xmm8
00007175dc9d52bb  vmovaps [rsp+0x90], xmm9
00007175dc9d52c4  vmovaps [rsp+0xA0], xmm10
00007175dc9d52cd  vmovaps [rsp+0xB0], xmm11
00007175dc9d52d6  vmovaps [rsp+0xC0], xmm12
00007175dc9d52df  vmovaps [rsp+0xD0], xmm14
00007175dc9d52e8  vmovaps [rsp+0xE0], xmm15
00007175dc9d52f1  sub rsp, 0x40
00007175dc9d52f5  lea rdi, [rsp]
00007175dc9d52f9  lea rsi, [rsp+0x10]
00007175dc9d52fe  lea rdx, [rsp+0x20]
00007175dc9d5303  lea rcx, [rsp+0x30]
00007175dc9d5308  mov r8d, 0x00
00007175dc9d530e  lea r9, [r15+0x3A8]
00007175dc9d5315  movaps [rdi], xmm13
00007175dc9d5319  movaps [rsi], xmm12
00007175dc9d531d  movaps [rdx], xmm4
00007175dc9d5320  movaps [rcx], xmm15
00007175dc9d5324  mov rax, 0x622B29CAFA50
00007175dc9d532e  call rax
00007175dc9d5330  movaps xmm13, [rsp]
00007175dc9d5335  add rsp, 0x40
00007175dc9d5339  vmovaps xmm0, [rsp]
00007175dc9d533e  vmovaps xmm1, [rsp+0x10]
00007175dc9d5344  vmovaps xmm2, [rsp+0x20]
00007175dc9d534a  vmovaps xmm3, [rsp+0x30]
00007175dc9d5350  vmovaps xmm4, [rsp+0x40]
00007175dc9d5356  vmovaps xmm5, [rsp+0x50]
00007175dc9d535c  vmovaps xmm6, [rsp+0x60]
00007175dc9d5362  vmovaps xmm7, [rsp+0x70]
00007175dc9d5368  vmovaps xmm8, [rsp+0x80]
00007175dc9d5371  vmovaps xmm9, [rsp+0x90]
00007175dc9d537a  vmovaps xmm10, [rsp+0xA0]
00007175dc9d5383  vmovaps xmm11, [rsp+0xB0]
00007175dc9d538c  vmovaps xmm12, [rsp+0xC0]
00007175dc9d5395  vmovaps xmm14, [rsp+0xD0]
00007175dc9d539e  vmovaps xmm15, [rsp+0xE0]
00007175dc9d53a7  add rsp, 0xF0
00007175dc9d53ae  pop r11
00007175dc9d53b0  pop r10
00007175dc9d53b2  pop r9
00007175dc9d53b4  pop r8
00007175dc9d53b6  pop rsi
00007175dc9d53b7  pop rdi
00007175dc9d53b8  pop rdx
00007175dc9d53b9  pop rcx
00007175dc9d53ba  pop rax
00007175dc9d53bb  add rsp, 0x08
00007175dc9d53bf  jmp 0x00007175DC9D2FF6
00007175dc9d53c4  sub rsp, 0x08
00007175dc9d53c8  push rax
00007175dc9d53c9  push rcx
00007175dc9d53ca  push rdx
00007175dc9d53cb  push rdi
00007175dc9d53cc  push rsi
00007175dc9d53cd  push r8
00007175dc9d53cf  push r9
00007175dc9d53d1  push r10
00007175dc9d53d3  push r11
00007175dc9d53d5  sub rsp, 0xF0
00007175dc9d53dc  vmovaps [rsp], xmm0
00007175dc9d53e1  vmovaps [rsp+0x10], xmm1
00007175dc9d53e7  vmovaps [rsp+0x20], xmm2
00007175dc9d53ed  vmovaps [rsp+0x30], xmm3
00007175dc9d53f3  vmovaps [rsp+0x40], xmm4
00007175dc9d53f9  vmovaps [rsp+0x50], xmm5
00007175dc9d53ff  vmovaps [rsp+0x60], xmm6
00007175dc9d5405  vmovaps [rsp+0x70], xmm7
00007175dc9d540b  vmovaps [rsp+0x80], xmm8
00007175dc9d5414  vmovaps [rsp+0x90], xmm9
00007175dc9d541d  vmovaps [rsp+0xA0], xmm10
00007175dc9d5426  vmovaps [rsp+0xB0], xmm11
00007175dc9d542f  vmovaps [rsp+0xC0], xmm13
00007175dc9d5438  vmovaps [rsp+0xD0], xmm14
00007175dc9d5441  vmovaps [rsp+0xE0], xmm15
00007175dc9d544a  sub rsp, 0x40
00007175dc9d544e  lea rdi, [rsp]
00007175dc9d5452  lea rsi, [rsp+0x10]
00007175dc9d5457  lea rdx, [rsp+0x20]
00007175dc9d545c  lea rcx, [rsp+0x30]
00007175dc9d5461  mov r8d, 0x00
00007175dc9d5467  lea r9, [r15+0x3A8]
00007175dc9d546e  movaps [rdi], xmm12
00007175dc9d5472  movaps [rsi], xmm7
00007175dc9d5475  movaps [rdx], xmm1
00007175dc9d5478  movaps [rcx], xmm15
00007175dc9d547c  mov rax, 0x622B29CAFA50
00007175dc9d5486  call rax
00007175dc9d5488  movaps xmm12, [rsp]
00007175dc9d548d  add rsp, 0x40
00007175dc9d5491  vmovaps xmm0, [rsp]
00007175dc9d5496  vmovaps xmm1, [rsp+0x10]
00007175dc9d549c  vmovaps xmm2, [rsp+0x20]
00007175dc9d54a2  vmovaps xmm3, [rsp+0x30]
00007175dc9d54a8  vmovaps xmm4, [rsp+0x40]
00007175dc9d54ae  vmovaps xmm5, [rsp+0x50]
00007175dc9d54b4  vmovaps xmm6, [rsp+0x60]
00007175dc9d54ba  vmovaps xmm7, [rsp+0x70]
00007175dc9d54c0  vmovaps xmm8, [rsp+0x80]
00007175dc9d54c9  vmovaps xmm9, [rsp+0x90]
00007175dc9d54d2  vmovaps xmm10, [rsp+0xA0]
00007175dc9d54db  vmovaps xmm11, [rsp+0xB0]
00007175dc9d54e4  vmovaps xmm13, [rsp+0xC0]
00007175dc9d54ed  vmovaps xmm14, [rsp+0xD0]
00007175dc9d54f6  vmovaps xmm15, [rsp+0xE0]
00007175dc9d54ff  add rsp, 0xF0
00007175dc9d5506  pop r11
00007175dc9d5508  pop r10
00007175dc9d550a  pop r9
00007175dc9d550c  pop r8
00007175dc9d550e  pop rsi
00007175dc9d550f  pop rdi
00007175dc9d5510  pop rdx
00007175dc9d5511  pop rcx
00007175dc9d5512  pop rax
00007175dc9d5513  add rsp, 0x08
00007175dc9d5517  jmp 0x00007175DC9D301F
00007175dc9d551c  call 0x00007175DC7FF430
00007175dc9d5521  jmp 0x00007175DC9D3029
00007175dc9d5526  call 0x00007175DC80E760
00007175dc9d552b  jmp 0x00007175DC9D3033
00007175dc9d5530  sub rsp, 0x08
00007175dc9d5534  push rax
00007175dc9d5535  push rcx
00007175dc9d5536  push rdx
00007175dc9d5537  push rdi
00007175dc9d5538  push rsi
00007175dc9d5539  push r8
00007175dc9d553b  push r9
00007175dc9d553d  push r10
00007175dc9d553f  push r11
00007175dc9d5541  sub rsp, 0xF0
00007175dc9d5548  vmovaps [rsp], xmm0
00007175dc9d554d  vmovaps [rsp+0x10], xmm1
00007175dc9d5553  vmovaps [rsp+0x20], xmm2
00007175dc9d5559  vmovaps [rsp+0x30], xmm3
00007175dc9d555f  vmovaps [rsp+0x40], xmm4
00007175dc9d5565  vmovaps [rsp+0x50], xmm5
00007175dc9d556b  vmovaps [rsp+0x60], xmm6
00007175dc9d5571  vmovaps [rsp+0x70], xmm8
00007175dc9d5577  vmovaps [rsp+0x80], xmm9
00007175dc9d5580  vmovaps [rsp+0x90], xmm10
00007175dc9d5589  vmovaps [rsp+0xA0], xmm11
00007175dc9d5592  vmovaps [rsp+0xB0], xmm12
00007175dc9d559b  vmovaps [rsp+0xC0], xmm13
00007175dc9d55a4  vmovaps [rsp+0xD0], xmm14
00007175dc9d55ad  vmovaps [rsp+0xE0], xmm15
00007175dc9d55b6  sub rsp, 0x40
00007175dc9d55ba  lea rdi, [rsp]
00007175dc9d55be  lea rsi, [rsp+0x10]
00007175dc9d55c3  lea rdx, [rsp+0x20]
00007175dc9d55c8  lea rcx, [rsp+0x30]
00007175dc9d55cd  mov r8d, 0x00
00007175dc9d55d3  lea r9, [r15+0x3A8]
00007175dc9d55da  movaps [rdi], xmm7
00007175dc9d55dd  movaps [rsi], xmm6
00007175dc9d55e0  movaps [rdx], xmm8
00007175dc9d55e4  movaps [rcx], xmm9
00007175dc9d55e8  mov rax, 0x622B29CAFA50
00007175dc9d55f2  call rax
00007175dc9d55f4  movaps xmm7, [rsp]
00007175dc9d55f8  add rsp, 0x40
00007175dc9d55fc  vmovaps xmm0, [rsp]
00007175dc9d5601  vmovaps xmm1, [rsp+0x10]
00007175dc9d5607  vmovaps xmm2, [rsp+0x20]
00007175dc9d560d  vmovaps xmm3, [rsp+0x30]
00007175dc9d5613  vmovaps xmm4, [rsp+0x40]
00007175dc9d5619  vmovaps xmm5, [rsp+0x50]
00007175dc9d561f  vmovaps xmm6, [rsp+0x60]
00007175dc9d5625  vmovaps xmm8, [rsp+0x70]
00007175dc9d562b  vmovaps xmm9, [rsp+0x80]
00007175dc9d5634  vmovaps xmm10, [rsp+0x90]
00007175dc9d563d  vmovaps xmm11, [rsp+0xA0]
00007175dc9d5646  vmovaps xmm12, [rsp+0xB0]
00007175dc9d564f  vmovaps xmm13, [rsp+0xC0]
00007175dc9d5658  vmovaps xmm14, [rsp+0xD0]
00007175dc9d5661  vmovaps xmm15, [rsp+0xE0]
00007175dc9d566a  add rsp, 0xF0
00007175dc9d5671  pop r11
00007175dc9d5673  pop r10
00007175dc9d5675  pop r9
00007175dc9d5677  pop r8
00007175dc9d5679  pop rsi
00007175dc9d567a  pop rdi
00007175dc9d567b  pop rdx
00007175dc9d567c  pop rcx
00007175dc9d567d  pop rax
00007175dc9d567e  add rsp, 0x08
00007175dc9d5682  jmp 0x00007175DC9D305D
00007175dc9d5687  sub rsp, 0x08
00007175dc9d568b  push rax
00007175dc9d568c  push rcx
00007175dc9d568d  push rdx
00007175dc9d568e  push rdi
00007175dc9d568f  push rsi
00007175dc9d5690  push r8
00007175dc9d5692  push r9
00007175dc9d5694  push r10
00007175dc9d5696  push r11
00007175dc9d5698  sub rsp, 0xF0
00007175dc9d569f  vmovaps [rsp], xmm0
00007175dc9d56a4  vmovaps [rsp+0x10], xmm1
00007175dc9d56aa  vmovaps [rsp+0x20], xmm2
00007175dc9d56b0  vmovaps [rsp+0x30], xmm3
00007175dc9d56b6  vmovaps [rsp+0x40], xmm4
00007175dc9d56bc  vmovaps [rsp+0x50], xmm5
00007175dc9d56c2  vmovaps [rsp+0x60], xmm6
00007175dc9d56c8  vmovaps [rsp+0x70], xmm7
00007175dc9d56ce  vmovaps [rsp+0x80], xmm9
00007175dc9d56d7  vmovaps [rsp+0x90], xmm10
00007175dc9d56e0  vmovaps [rsp+0xA0], xmm11
00007175dc9d56e9  vmovaps [rsp+0xB0], xmm12
00007175dc9d56f2  vmovaps [rsp+0xC0], xmm13
00007175dc9d56fb  vmovaps [rsp+0xD0], xmm14
00007175dc9d5704  vmovaps [rsp+0xE0], xmm15
00007175dc9d570d  sub rsp, 0x40
00007175dc9d5711  lea rdi, [rsp]
00007175dc9d5715  lea rsi, [rsp+0x10]
00007175dc9d571a  lea rdx, [rsp+0x20]
00007175dc9d571f  lea rcx, [rsp+0x30]
00007175dc9d5724  mov r8d, 0x00
00007175dc9d572a  lea r9, [r15+0x3A8]
00007175dc9d5731  movaps [rdi], xmm8
00007175dc9d5735  movaps [rsi], xmm10
00007175dc9d5739  movaps [rdx], xmm14
00007175dc9d573d  movaps [rcx], xmm9
00007175dc9d5741  mov rax, 0x622B29CAFA50
00007175dc9d574b  call rax
00007175dc9d574d  movaps xmm8, [rsp]
00007175dc9d5752  add rsp, 0x40
00007175dc9d5756  vmovaps xmm0, [rsp]
00007175dc9d575b  vmovaps xmm1, [rsp+0x10]
00007175dc9d5761  vmovaps xmm2, [rsp+0x20]
00007175dc9d5767  vmovaps xmm3, [rsp+0x30]
00007175dc9d576d  vmovaps xmm4, [rsp+0x40]
00007175dc9d5773  vmovaps xmm5, [rsp+0x50]
00007175dc9d5779  vmovaps xmm6, [rsp+0x60]
00007175dc9d577f  vmovaps xmm7, [rsp+0x70]
00007175dc9d5785  vmovaps xmm9, [rsp+0x80]
00007175dc9d578e  vmovaps xmm10, [rsp+0x90]
00007175dc9d5797  vmovaps xmm11, [rsp+0xA0]
00007175dc9d57a0  vmovaps xmm12, [rsp+0xB0]
00007175dc9d57a9  vmovaps xmm13, [rsp+0xC0]
00007175dc9d57b2  vmovaps xmm14, [rsp+0xD0]
00007175dc9d57bb  vmovaps xmm15, [rsp+0xE0]
00007175dc9d57c4  add rsp, 0xF0
00007175dc9d57cb  pop r11
00007175dc9d57cd  pop r10
00007175dc9d57cf  pop r9
00007175dc9d57d1  pop r8
00007175dc9d57d3  pop rsi
00007175dc9d57d4  pop rdi
00007175dc9d57d5  pop rdx
00007175dc9d57d6  pop rcx
00007175dc9d57d7  pop rax
00007175dc9d57d8  add rsp, 0x08
00007175dc9d57dc  jmp 0x00007175DC9D3083
00007175dc9d57e1  sub rsp, 0x08
00007175dc9d57e5  push rax
00007175dc9d57e6  push rcx
00007175dc9d57e7  push rdx
00007175dc9d57e8  push rdi
00007175dc9d57e9  push rsi
00007175dc9d57ea  push r8
00007175dc9d57ec  push r9
00007175dc9d57ee  push r10
00007175dc9d57f0  push r11
00007175dc9d57f2  sub rsp, 0xF0
00007175dc9d57f9  vmovaps [rsp], xmm0
00007175dc9d57fe  vmovaps [rsp+0x10], xmm1
00007175dc9d5804  vmovaps [rsp+0x20], xmm2
00007175dc9d580a  vmovaps [rsp+0x30], xmm3
00007175dc9d5810  vmovaps [rsp+0x40], xmm4
00007175dc9d5816  vmovaps [rsp+0x50], xmm5
00007175dc9d581c  vmovaps [rsp+0x60], xmm6
00007175dc9d5822  vmovaps [rsp+0x70], xmm7
00007175dc9d5828  vmovaps [rsp+0x80], xmm8
00007175dc9d5831  vmovaps [rsp+0x90], xmm9
00007175dc9d583a  vmovaps [rsp+0xA0], xmm11
00007175dc9d5843  vmovaps [rsp+0xB0], xmm12
00007175dc9d584c  vmovaps [rsp+0xC0], xmm13
00007175dc9d5855  vmovaps [rsp+0xD0], xmm14
00007175dc9d585e  vmovaps [rsp+0xE0], xmm15
00007175dc9d5867  sub rsp, 0x40
00007175dc9d586b  lea rdi, [rsp]
00007175dc9d586f  lea rsi, [rsp+0x10]
00007175dc9d5874  lea rdx, [rsp+0x20]
00007175dc9d5879  lea rcx, [rsp+0x30]
00007175dc9d587e  mov r8d, 0x00
00007175dc9d5884  lea r9, [r15+0x3A8]
00007175dc9d588b  movaps [rdi], xmm10
00007175dc9d588f  movaps [rsi], xmm13
00007175dc9d5893  movaps [rdx], xmm11
00007175dc9d5897  movaps [rcx], xmm14
00007175dc9d589b  mov rax, 0x622B29CAFA50
00007175dc9d58a5  call rax
00007175dc9d58a7  movaps xmm10, [rsp]
00007175dc9d58ac  add rsp, 0x40
00007175dc9d58b0  vmovaps xmm0, [rsp]
00007175dc9d58b5  vmovaps xmm1, [rsp+0x10]
00007175dc9d58bb  vmovaps xmm2, [rsp+0x20]
00007175dc9d58c1  vmovaps xmm3, [rsp+0x30]
00007175dc9d58c7  vmovaps xmm4, [rsp+0x40]
00007175dc9d58cd  vmovaps xmm5, [rsp+0x50]
00007175dc9d58d3  vmovaps xmm6, [rsp+0x60]
00007175dc9d58d9  vmovaps xmm7, [rsp+0x70]
00007175dc9d58df  vmovaps xmm8, [rsp+0x80]
00007175dc9d58e8  vmovaps xmm9, [rsp+0x90]
00007175dc9d58f1  vmovaps xmm11, [rsp+0xA0]
00007175dc9d58fa  vmovaps xmm12, [rsp+0xB0]
00007175dc9d5903  vmovaps xmm13, [rsp+0xC0]
00007175dc9d590c  vmovaps xmm14, [rsp+0xD0]
00007175dc9d5915  vmovaps xmm15, [rsp+0xE0]
00007175dc9d591e  add rsp, 0xF0
00007175dc9d5925  pop r11
00007175dc9d5927  pop r10
00007175dc9d5929  pop r9
00007175dc9d592b  pop r8
00007175dc9d592d  pop rsi
00007175dc9d592e  pop rdi
00007175dc9d592f  pop rdx
00007175dc9d5930  pop rcx
00007175dc9d5931  pop rax
00007175dc9d5932  add rsp, 0x08
00007175dc9d5936  jmp 0x00007175DC9D30A9
00007175dc9d593b  sub rsp, 0x08
00007175dc9d593f  push rax
00007175dc9d5940  push rcx
00007175dc9d5941  push rdx
00007175dc9d5942  push rdi
00007175dc9d5943  push rsi
00007175dc9d5944  push r8
00007175dc9d5946  push r9
00007175dc9d5948  push r10
00007175dc9d594a  push r11
00007175dc9d594c  sub rsp, 0xF0
00007175dc9d5953  vmovaps [rsp], xmm0
00007175dc9d5958  vmovaps [rsp+0x10], xmm1
00007175dc9d595e  vmovaps [rsp+0x20], xmm2
00007175dc9d5964  vmovaps [rsp+0x30], xmm3
00007175dc9d596a  vmovaps [rsp+0x40], xmm4
00007175dc9d5970  vmovaps [rsp+0x50], xmm5
00007175dc9d5976  vmovaps [rsp+0x60], xmm6
00007175dc9d597c  vmovaps [rsp+0x70], xmm7
00007175dc9d5982  vmovaps [rsp+0x80], xmm8
00007175dc9d598b  vmovaps [rsp+0x90], xmm9
00007175dc9d5994  vmovaps [rsp+0xA0], xmm10
00007175dc9d599d  vmovaps [rsp+0xB0], xmm11
00007175dc9d59a6  vmovaps [rsp+0xC0], xmm12
00007175dc9d59af  vmovaps [rsp+0xD0], xmm14
00007175dc9d59b8  vmovaps [rsp+0xE0], xmm15
00007175dc9d59c1  sub rsp, 0x40
00007175dc9d59c5  lea rdi, [rsp]
00007175dc9d59c9  lea rsi, [rsp+0x10]
00007175dc9d59ce  lea rdx, [rsp+0x20]
00007175dc9d59d3  lea rcx, [rsp+0x30]
00007175dc9d59d8  mov r8d, 0x00
00007175dc9d59de  lea r9, [r15+0x3A8]
00007175dc9d59e5  movaps [rdi], xmm13
00007175dc9d59e9  movaps [rsi], xmm12
00007175dc9d59ed  movaps [rdx], xmm15
00007175dc9d59f1  movaps [rcx], xmm14
00007175dc9d59f5  mov rax, 0x622B29CAFA50
00007175dc9d59ff  call rax
00007175dc9d5a01  movaps xmm13, [rsp]
00007175dc9d5a06  add rsp, 0x40
00007175dc9d5a0a  vmovaps xmm0, [rsp]
00007175dc9d5a0f  vmovaps xmm1, [rsp+0x10]
00007175dc9d5a15  vmovaps xmm2, [rsp+0x20]
00007175dc9d5a1b  vmovaps xmm3, [rsp+0x30]
00007175dc9d5a21  vmovaps xmm4, [rsp+0x40]
00007175dc9d5a27  vmovaps xmm5, [rsp+0x50]
00007175dc9d5a2d  vmovaps xmm6, [rsp+0x60]
00007175dc9d5a33  vmovaps xmm7, [rsp+0x70]
00007175dc9d5a39  vmovaps xmm8, [rsp+0x80]
00007175dc9d5a42  vmovaps xmm9, [rsp+0x90]
00007175dc9d5a4b  vmovaps xmm10, [rsp+0xA0]
00007175dc9d5a54  vmovaps xmm11, [rsp+0xB0]
00007175dc9d5a5d  vmovaps xmm12, [rsp+0xC0]
00007175dc9d5a66  vmovaps xmm14, [rsp+0xD0]
00007175dc9d5a6f  vmovaps xmm15, [rsp+0xE0]
00007175dc9d5a78  add rsp, 0xF0
00007175dc9d5a7f  pop r11
00007175dc9d5a81  pop r10
00007175dc9d5a83  pop r9
00007175dc9d5a85  pop r8
00007175dc9d5a87  pop rsi
00007175dc9d5a88  pop rdi
00007175dc9d5a89  pop rdx
00007175dc9d5a8a  pop rcx
00007175dc9d5a8b  pop rax
00007175dc9d5a8c  add rsp, 0x08
00007175dc9d5a90  jmp 0x00007175DC9D30CF
00007175dc9d5a95  call 0x00007175DC80E760
00007175dc9d5a9a  jmp 0x00007175DC9D30DC
00007175dc9d5a9f  call 0x00007175DC80D4E0
00007175dc9d5aa4  jmp 0x00007175DC9D30E9
00007175dc9d5aa9  sub rsp, 0x08
00007175dc9d5aad  push rax
00007175dc9d5aae  push rcx
00007175dc9d5aaf  push rdx
00007175dc9d5ab0  push rdi
00007175dc9d5ab1  push rsi
00007175dc9d5ab2  push r8
00007175dc9d5ab4  push r9
00007175dc9d5ab6  push r10
00007175dc9d5ab8  push r11
00007175dc9d5aba  sub rsp, 0xF0
00007175dc9d5ac1  vmovaps [rsp], xmm0
00007175dc9d5ac6  vmovaps [rsp+0x10], xmm1
00007175dc9d5acc  vmovaps [rsp+0x20], xmm2
00007175dc9d5ad2  vmovaps [rsp+0x30], xmm3
00007175dc9d5ad8  vmovaps [rsp+0x40], xmm4
00007175dc9d5ade  vmovaps [rsp+0x50], xmm5
00007175dc9d5ae4  vmovaps [rsp+0x60], xmm6
00007175dc9d5aea  vmovaps [rsp+0x70], xmm7
00007175dc9d5af0  vmovaps [rsp+0x80], xmm8
00007175dc9d5af9  vmovaps [rsp+0x90], xmm9
00007175dc9d5b02  vmovaps [rsp+0xA0], xmm10
00007175dc9d5b0b  vmovaps [rsp+0xB0], xmm12
00007175dc9d5b14  vmovaps [rsp+0xC0], xmm13
00007175dc9d5b1d  vmovaps [rsp+0xD0], xmm14
00007175dc9d5b26  vmovaps [rsp+0xE0], xmm15
00007175dc9d5b2f  sub rsp, 0x40
00007175dc9d5b33  lea rdi, [rsp]
00007175dc9d5b37  lea rsi, [rsp+0x10]
00007175dc9d5b3c  lea rdx, [rsp+0x20]
00007175dc9d5b41  lea rcx, [rsp+0x30]
00007175dc9d5b46  mov r8d, 0x00
00007175dc9d5b4c  lea r9, [r15+0x3A8]
00007175dc9d5b53  movaps [rdi], xmm11
00007175dc9d5b57  movaps [rsi], xmm7
00007175dc9d5b5a  movaps [rdx], xmm1
00007175dc9d5b5d  movaps [rcx], xmm12
00007175dc9d5b61  mov rax, 0x622B29CAFA50
00007175dc9d5b6b  call rax
00007175dc9d5b6d  movaps xmm11, [rsp]
00007175dc9d5b72  add rsp, 0x40
00007175dc9d5b76  vmovaps xmm0, [rsp]
00007175dc9d5b7b  vmovaps xmm1, [rsp+0x10]
00007175dc9d5b81  vmovaps xmm2, [rsp+0x20]
00007175dc9d5b87  vmovaps xmm3, [rsp+0x30]
00007175dc9d5b8d  vmovaps xmm4, [rsp+0x40]
00007175dc9d5b93  vmovaps xmm5, [rsp+0x50]
00007175dc9d5b99  vmovaps xmm6, [rsp+0x60]
00007175dc9d5b9f  vmovaps xmm7, [rsp+0x70]
00007175dc9d5ba5  vmovaps xmm8, [rsp+0x80]
00007175dc9d5bae  vmovaps xmm9, [rsp+0x90]
00007175dc9d5bb7  vmovaps xmm10, [rsp+0xA0]
00007175dc9d5bc0  vmovaps xmm12, [rsp+0xB0]
00007175dc9d5bc9  vmovaps xmm13, [rsp+0xC0]
00007175dc9d5bd2  vmovaps xmm14, [rsp+0xD0]
00007175dc9d5bdb  vmovaps xmm15, [rsp+0xE0]
00007175dc9d5be4  add rsp, 0xF0
00007175dc9d5beb  pop r11
00007175dc9d5bed  pop r10
00007175dc9d5bef  pop r9
00007175dc9d5bf1  pop r8
00007175dc9d5bf3  pop rsi
00007175dc9d5bf4  pop rdi
00007175dc9d5bf5  pop rdx
00007175dc9d5bf6  pop rcx
00007175dc9d5bf7  pop rax
00007175dc9d5bf8  add rsp, 0x08
00007175dc9d5bfc  jmp 0x00007175DC9D3122
00007175dc9d5c01  call 0x00007175DC7FF430
00007175dc9d5c06  jmp 0x00007175DC9D3134
00007175dc9d5c0b  sub rsp, 0x08
00007175dc9d5c0f  push rax
00007175dc9d5c10  push rcx
00007175dc9d5c11  push rdx
00007175dc9d5c12  push rdi
00007175dc9d5c13  push rsi
00007175dc9d5c14  push r8
00007175dc9d5c16  push r9
00007175dc9d5c18  push r10
00007175dc9d5c1a  push r11
00007175dc9d5c1c  sub rsp, 0xF0
00007175dc9d5c23  vmovaps [rsp], xmm0
00007175dc9d5c28  vmovaps [rsp+0x10], xmm1
00007175dc9d5c2e  vmovaps [rsp+0x20], xmm2
00007175dc9d5c34  vmovaps [rsp+0x30], xmm3
00007175dc9d5c3a  vmovaps [rsp+0x40], xmm4
00007175dc9d5c40  vmovaps [rsp+0x50], xmm5
00007175dc9d5c46  vmovaps [rsp+0x60], xmm6
00007175dc9d5c4c  vmovaps [rsp+0x70], xmm7
00007175dc9d5c52  vmovaps [rsp+0x80], xmm8
00007175dc9d5c5b  vmovaps [rsp+0x90], xmm10
00007175dc9d5c64  vmovaps [rsp+0xA0], xmm11
00007175dc9d5c6d  vmovaps [rsp+0xB0], xmm12
00007175dc9d5c76  vmovaps [rsp+0xC0], xmm13
00007175dc9d5c7f  vmovaps [rsp+0xD0], xmm14
00007175dc9d5c88  vmovaps [rsp+0xE0], xmm15
00007175dc9d5c91  sub rsp, 0x40
00007175dc9d5c95  lea rdi, [rsp]
00007175dc9d5c99  lea rsi, [rsp+0x10]
00007175dc9d5c9e  lea rdx, [rsp+0x20]
00007175dc9d5ca3  lea rcx, [rsp+0x30]
00007175dc9d5ca8  mov r8d, 0x00
00007175dc9d5cae  lea r9, [r15+0x3A8]
00007175dc9d5cb5  movaps [rdi], xmm9
00007175dc9d5cb9  movaps [rsi], xmm8
00007175dc9d5cbd  movaps [rdx], xmm14
00007175dc9d5cc1  movaps [rcx], xmm12
00007175dc9d5cc5  mov rax, 0x622B29CAFA50
00007175dc9d5ccf  call rax
00007175dc9d5cd1  movaps xmm9, [rsp]
00007175dc9d5cd6  add rsp, 0x40
00007175dc9d5cda  vmovaps xmm0, [rsp]
00007175dc9d5cdf  vmovaps xmm1, [rsp+0x10]
00007175dc9d5ce5  vmovaps xmm2, [rsp+0x20]
00007175dc9d5ceb  vmovaps xmm3, [rsp+0x30]
00007175dc9d5cf1  vmovaps xmm4, [rsp+0x40]
00007175dc9d5cf7  vmovaps xmm5, [rsp+0x50]
00007175dc9d5cfd  vmovaps xmm6, [rsp+0x60]
00007175dc9d5d03  vmovaps xmm7, [rsp+0x70]
00007175dc9d5d09  vmovaps xmm8, [rsp+0x80]
00007175dc9d5d12  vmovaps xmm10, [rsp+0x90]
00007175dc9d5d1b  vmovaps xmm11, [rsp+0xA0]
00007175dc9d5d24  vmovaps xmm12, [rsp+0xB0]
00007175dc9d5d2d  vmovaps xmm13, [rsp+0xC0]
00007175dc9d5d36  vmovaps xmm14, [rsp+0xD0]
00007175dc9d5d3f  vmovaps xmm15, [rsp+0xE0]
00007175dc9d5d48  add rsp, 0xF0
00007175dc9d5d4f  pop r11
00007175dc9d5d51  pop r10
00007175dc9d5d53  pop r9
00007175dc9d5d55  pop r8
00007175dc9d5d57  pop rsi
00007175dc9d5d58  pop rdi
00007175dc9d5d59  pop rdx
00007175dc9d5d5a  pop rcx
00007175dc9d5d5b  pop rax
00007175dc9d5d5c  add rsp, 0x08
00007175dc9d5d60  jmp 0x00007175DC9D3165
00007175dc9d5d65  sub rsp, 0x08
00007175dc9d5d69  push rax
00007175dc9d5d6a  push rcx
00007175dc9d5d6b  push rdx
00007175dc9d5d6c  push rdi
00007175dc9d5d6d  push rsi
00007175dc9d5d6e  push r8
00007175dc9d5d70  push r9
00007175dc9d5d72  push r10
00007175dc9d5d74  push r11
00007175dc9d5d76  sub rsp, 0xF0
00007175dc9d5d7d  vmovaps [rsp], xmm0
00007175dc9d5d82  vmovaps [rsp+0x10], xmm1
00007175dc9d5d88  vmovaps [rsp+0x20], xmm2
00007175dc9d5d8e  vmovaps [rsp+0x30], xmm3
00007175dc9d5d94  vmovaps [rsp+0x40], xmm4
00007175dc9d5d9a  vmovaps [rsp+0x50], xmm5
00007175dc9d5da0  vmovaps [rsp+0x60], xmm6
00007175dc9d5da6  vmovaps [rsp+0x70], xmm7
00007175dc9d5dac  vmovaps [rsp+0x80], xmm8
00007175dc9d5db5  vmovaps [rsp+0x90], xmm9
00007175dc9d5dbe  vmovaps [rsp+0xA0], xmm10
00007175dc9d5dc7  vmovaps [rsp+0xB0], xmm11
00007175dc9d5dd0  vmovaps [rsp+0xC0], xmm13
00007175dc9d5dd9  vmovaps [rsp+0xD0], xmm14
00007175dc9d5de2  vmovaps [rsp+0xE0], xmm15
00007175dc9d5deb  sub rsp, 0x40
00007175dc9d5def  lea rdi, [rsp]
00007175dc9d5df3  lea rsi, [rsp+0x10]
00007175dc9d5df8  lea rdx, [rsp+0x20]
00007175dc9d5dfd  lea rcx, [rsp+0x30]
00007175dc9d5e02  mov r8d, 0x00
00007175dc9d5e08  lea r9, [r15+0x3A8]
00007175dc9d5e0f  movaps [rdi], xmm12
00007175dc9d5e13  movaps [rsi], xmm10
00007175dc9d5e17  movaps [rdx], xmm15
00007175dc9d5e1b  movaps [rcx], xmm14
00007175dc9d5e1f  mov rax, 0x622B29CAFA50
00007175dc9d5e29  call rax
00007175dc9d5e2b  movaps xmm12, [rsp]
00007175dc9d5e30  add rsp, 0x40
00007175dc9d5e34  vmovaps xmm0, [rsp]
00007175dc9d5e39  vmovaps xmm1, [rsp+0x10]
00007175dc9d5e3f  vmovaps xmm2, [rsp+0x20]
00007175dc9d5e45  vmovaps xmm3, [rsp+0x30]
00007175dc9d5e4b  vmovaps xmm4, [rsp+0x40]
00007175dc9d5e51  vmovaps xmm5, [rsp+0x50]
00007175dc9d5e57  vmovaps xmm6, [rsp+0x60]
00007175dc9d5e5d  vmovaps xmm7, [rsp+0x70]
00007175dc9d5e63  vmovaps xmm8, [rsp+0x80]
00007175dc9d5e6c  vmovaps xmm9, [rsp+0x90]
00007175dc9d5e75  vmovaps xmm10, [rsp+0xA0]
00007175dc9d5e7e  vmovaps xmm11, [rsp+0xB0]
00007175dc9d5e87  vmovaps xmm13, [rsp+0xC0]
00007175dc9d5e90  vmovaps xmm14, [rsp+0xD0]
00007175dc9d5e99  vmovaps xmm15, [rsp+0xE0]
00007175dc9d5ea2  add rsp, 0xF0
00007175dc9d5ea9  pop r11
00007175dc9d5eab  pop r10
00007175dc9d5ead  pop r9
00007175dc9d5eaf  pop r8
00007175dc9d5eb1  pop rsi
00007175dc9d5eb2  pop rdi
00007175dc9d5eb3  pop rdx
00007175dc9d5eb4  pop rcx
00007175dc9d5eb5  pop rax
00007175dc9d5eb6  add rsp, 0x08
00007175dc9d5eba  jmp 0x00007175DC9D3196
00007175dc9d5ebf  sub rsp, 0x08
00007175dc9d5ec3  push rax
00007175dc9d5ec4  push rcx
00007175dc9d5ec5  push rdx
00007175dc9d5ec6  push rdi
00007175dc9d5ec7  push rsi
00007175dc9d5ec8  push r8
00007175dc9d5eca  push r9
00007175dc9d5ecc  push r10
00007175dc9d5ece  push r11
00007175dc9d5ed0  sub rsp, 0xF0
00007175dc9d5ed7  vmovaps [rsp], xmm0
00007175dc9d5edc  vmovaps [rsp+0x10], xmm1
00007175dc9d5ee2  vmovaps [rsp+0x20], xmm2
00007175dc9d5ee8  vmovaps [rsp+0x30], xmm3
00007175dc9d5eee  vmovaps [rsp+0x40], xmm4
00007175dc9d5ef4  vmovaps [rsp+0x50], xmm5
00007175dc9d5efa  vmovaps [rsp+0x60], xmm6
00007175dc9d5f00  vmovaps [rsp+0x70], xmm7
00007175dc9d5f06  vmovaps [rsp+0x80], xmm8
00007175dc9d5f0f  vmovaps [rsp+0x90], xmm9
00007175dc9d5f18  vmovaps [rsp+0xA0], xmm10
00007175dc9d5f21  vmovaps [rsp+0xB0], xmm11
00007175dc9d5f2a  vmovaps [rsp+0xC0], xmm12
00007175dc9d5f33  vmovaps [rsp+0xD0], xmm13
00007175dc9d5f3c  vmovaps [rsp+0xE0], xmm15
00007175dc9d5f45  sub rsp, 0x40
00007175dc9d5f49  lea rdi, [rsp]
00007175dc9d5f4d  lea rsi, [rsp+0x10]
00007175dc9d5f52  lea rdx, [rsp+0x20]
00007175dc9d5f57  lea rcx, [rsp+0x30]
00007175dc9d5f5c  mov r8d, 0x00
00007175dc9d5f62  lea r9, [r15+0x3A8]
00007175dc9d5f69  movaps [rdi], xmm14
00007175dc9d5f6d  movaps [rsi], xmm13
00007175dc9d5f71  movaps [rdx], xmm1
00007175dc9d5f74  movaps [rcx], xmm15
00007175dc9d5f78  mov rax, 0x622B29CAFA50
00007175dc9d5f82  call rax
00007175dc9d5f84  movaps xmm14, [rsp]
00007175dc9d5f89  add rsp, 0x40
00007175dc9d5f8d  vmovaps xmm0, [rsp]
00007175dc9d5f92  vmovaps xmm1, [rsp+0x10]
00007175dc9d5f98  vmovaps xmm2, [rsp+0x20]
00007175dc9d5f9e  vmovaps xmm3, [rsp+0x30]
00007175dc9d5fa4  vmovaps xmm4, [rsp+0x40]
00007175dc9d5faa  vmovaps xmm5, [rsp+0x50]
00007175dc9d5fb0  vmovaps xmm6, [rsp+0x60]
00007175dc9d5fb6  vmovaps xmm7, [rsp+0x70]
00007175dc9d5fbc  vmovaps xmm8, [rsp+0x80]
00007175dc9d5fc5  vmovaps xmm9, [rsp+0x90]
00007175dc9d5fce  vmovaps xmm10, [rsp+0xA0]
00007175dc9d5fd7  vmovaps xmm11, [rsp+0xB0]
00007175dc9d5fe0  vmovaps xmm12, [rsp+0xC0]
00007175dc9d5fe9  vmovaps xmm13, [rsp+0xD0]
00007175dc9d5ff2  vmovaps xmm15, [rsp+0xE0]
00007175dc9d5ffb  add rsp, 0xF0
00007175dc9d6002  pop r11
00007175dc9d6004  pop r10
00007175dc9d6006  pop r9
00007175dc9d6008  pop r8
00007175dc9d600a  pop rsi
00007175dc9d600b  pop rdi
00007175dc9d600c  pop rdx
00007175dc9d600d  pop rcx
00007175dc9d600e  pop rax
00007175dc9d600f  add rsp, 0x08
00007175dc9d6013  jmp 0x00007175DC9D31C7
00007175dc9d6018  call 0x00007175DC8079B0
00007175dc9d601d  jmp 0x00007175DC9D31DA
00007175dc9d6022  call 0x00007175DC80B100
00007175dc9d6027  jmp 0x00007175DC9D31E5
00007175dc9d602c  call 0x00007175DC809E90
00007175dc9d6031  jmp 0x00007175DC9D31F0
00007175dc9d6036  call 0x00007175DC80D600
00007175dc9d603b  jmp 0x00007175DC9D31FB
00007175dc9d6040  int3
00007175dc9d6041  nop [rax+rax*1], ax
00007175dc9d604a  nop [rax+rax*1], ax
00007175dc9d6050  mov rax, [r15+0x40]
00007175dc9d6054  mov r14, [r15+0x58]
00007175dc9d6058  lea r12, [rax+r14*1]
00007175dc9d605c  vxorps xmm1, xmm1, xmm1
00007175dc9d6060  vpbroadcastq xmm1, xmm1
00007175dc9d6065  vxorps xmm15, xmm15, xmm15
00007175dc9d606a  vpbroadcastq xmm15, xmm15
00007175dc9d606f  lea rax, [r12+0x30]
00007175dc9d6074  mov r11, [r13+rax*1]
00007175dc9d6079  lea rax, [r12+0x38]
00007175dc9d607e  mov r10, [r13+rax*1]
00007175dc9d6083  movq xmm14, r11
00007175dc9d6088  movq xmm13, r10
00007175dc9d608d  movq xmm14, xmm14
00007175dc9d6092  movq xmm13, xmm13
00007175dc9d6097  vmovaps [rsp+0x10], xmm13
00007175dc9d609d  movq xmm13, xmm13
00007175dc9d60a2  movaps [r15+0x270], xmm13
00007175dc9d60aa  movaps xmm13, [r15+0x160]
00007175dc9d60b2  vmovaps [rsp+0x20], xmm13
00007175dc9d60b8  vmovaps xmm12, [rsp+0x20]
00007175dc9d60be  por xmm13, xmm12
00007175dc9d60c3  lea rax, [r12+0x20]
00007175dc9d60c8  mov r11, [r13+rax*1]
00007175dc9d60cd  lea rax, [r12+0x28]
00007175dc9d60d2  mov r10, [r13+rax*1]
00007175dc9d60d7  movq xmm12, r11
00007175dc9d60dc  movq xmm11, r10
00007175dc9d60e1  movq xmm12, xmm12
00007175dc9d60e6  movq xmm11, xmm11
00007175dc9d60eb  movaps xmm10, [r15+0x2D0]
00007175dc9d60f3  vmovaps [rsp+0x20], xmm10
00007175dc9d60f9  vmovaps xmm9, [rsp+0x20]
00007175dc9d60ff  por xmm10, xmm9
00007175dc9d6104  movaps xmm9, [r15+0x300]
00007175dc9d610c  vmovaps [rsp+0x20], xmm9
00007175dc9d6112  vmovaps xmm8, [rsp+0x20]
00007175dc9d6118  por xmm9, xmm8
00007175dc9d611d  movaps xmm8, [r15+0x2B0]
00007175dc9d6125  vmovaps [rsp+0x20], xmm8
00007175dc9d612b  vmovaps xmm7, [rsp+0x20]
00007175dc9d6131  por xmm8, xmm7
00007175dc9d6136  movaps xmm7, [r15+0x180]
00007175dc9d613e  vmovaps [rsp+0x20], xmm7
00007175dc9d6144  vmovaps xmm6, [rsp+0x20]
00007175dc9d614a  por xmm7, xmm6
00007175dc9d614e  lea rax, [r12+0x10]
00007175dc9d6153  mov r11, [r13+rax*1]
00007175dc9d6158  lea rax, [r12+0x18]
00007175dc9d615d  mov r10, [r13+rax*1]
00007175dc9d6162  movq xmm6, r11
00007175dc9d6167  movq xmm5, r10
00007175dc9d616c  movq xmm6, xmm6
00007175dc9d6170  movq xmm5, xmm5
00007175dc9d6174  movaps xmm4, [r15+0x200]
00007175dc9d617c  vmovaps [rsp+0x20], xmm4
00007175dc9d6182  vmovaps xmm3, [rsp+0x20]
00007175dc9d6188  por xmm4, xmm3
00007175dc9d618c  movaps xmm3, [r15+0x1F0]
00007175dc9d6194  vmovaps [rsp+0x20], xmm3
00007175dc9d619a  vmovaps xmm2, [rsp+0x20]
00007175dc9d61a0  por xmm3, xmm2
00007175dc9d61a4  movaps xmm2, [r15+0x2E0]
00007175dc9d61ac  vmovaps [rsp+0x20], xmm2
00007175dc9d61b2  vmovaps [rsp+0x30], xmm1
00007175dc9d61b8  vmovaps xmm1, [rsp+0x20]
00007175dc9d61be  por xmm2, xmm1
00007175dc9d61c2  movaps xmm1, [r15+0x2A0]
00007175dc9d61ca  vmovaps [rsp+0x20], xmm1
00007175dc9d61d0  vmovaps [rsp+0x40], xmm15
00007175dc9d61d6  vmovaps xmm15, [rsp+0x20]
00007175dc9d61dc  por xmm1, xmm15
00007175dc9d61e1  movaps xmm15, [r15+0x280]
00007175dc9d61e9  vmovaps [rsp+0x20], xmm15
00007175dc9d61ef  vmovaps [rsp+0x50], xmm1
00007175dc9d61f5  vmovaps xmm1, [rsp+0x20]
00007175dc9d61fb  por xmm15, xmm1
00007175dc9d6200  movaps xmm1, [r15+0x1C0]
00007175dc9d6208  vmovaps [rsp+0x20], xmm1
00007175dc9d620e  vmovaps [rsp+0x60], xmm15
00007175dc9d6214  vmovaps xmm15, [rsp+0x20]
00007175dc9d621a  por xmm1, xmm15
00007175dc9d621f  movaps xmm15, [r15+0x210]
00007175dc9d6227  vmovaps [rsp+0x20], xmm15
00007175dc9d622d  vmovaps [rsp+0x70], xmm1
00007175dc9d6233  vmovaps xmm1, [rsp+0x20]
00007175dc9d6239  por xmm15, xmm1
00007175dc9d623e  mov rax, [r13+r12*1]
00007175dc9d6243  vmovq xmm1, rax
00007175dc9d6248  vpbroadcastq xmm1, xmm1
00007175dc9d624d  vmovaps [rsp+0x20], xmm1
00007175dc9d6253  vxorps xmm1, xmm1, xmm1
00007175dc9d6257  vpbroadcastq xmm1, xmm1
00007175dc9d625c  mov rax, [r15+0xF8]
00007175dc9d6263  vmovaps [rsp+0x80], xmm1
00007175dc9d626c  movups xmm1, [r13+rax*1]
00007175dc9d6272  vmovaps [rsp+0x90], xmm1
00007175dc9d627b  vxorps xmm1, xmm1, xmm1
00007175dc9d627f  vpbroadcastq xmm1, xmm1
00007175dc9d6284  lea r11, [r12+0x08]
00007175dc9d6289  mov r12, [r13+r11*1]
00007175dc9d628e  vmovaps [rsp+0xA0], xmm1
00007175dc9d6297  movq xmm1, r12
00007175dc9d629c  movaps [r15+0x240], xmm1
00007175dc9d62a4  mov r12, [r15+0x50]
00007175dc9d62a8  lea r11, [r12+r14*1]
00007175dc9d62ac  mov [r15+0x60], r11
00007175dc9d62b0  lea r12, [r14+0x40]
00007175dc9d62b4  mov [r15+0x58], r12
00007175dc9d62b8  vmovaps xmm1, [rsp+0x30]
00007175dc9d62be  vmovaps [rsp+0x30], xmm15
00007175dc9d62c4  vmovaps xmm15, [rsp+0x90]
00007175dc9d62cd  vmovaps [rsp+0x90], xmm14
00007175dc9d62d6  vmovaps xmm14, [rsp+0x20]
00007175dc9d62dc  vmovaps [rsp+0x20], xmm13
00007175dc9d62e2  vmovaps [rsp+0xB0], xmm12
00007175dc9d62eb  movaps xmm13, xmm1
00007175dc9d62ef  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d62fa  vptest xmm12, xmm12
00007175dc9d62ff  jnz 0x00007175DC9D6D9C
00007175dc9d6305  movaps xmm1, [r15+0x250]
00007175dc9d630d  vmovaps xmm15, [rsp+0x40]
00007175dc9d6313  vmovaps [rsp+0x40], xmm13
00007175dc9d6319  movaps xmm12, xmm15
00007175dc9d631d  vfmadd231pd xmm12, xmm1, xmm14
00007175dc9d6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007175dc9d6328  vptest xmm13, xmm13
00007175dc9d632d  jnz 0x00007175DC9D6EF5
00007175dc9d6333  movaps xmm15, [r15+0x1E0]
00007175dc9d633b  vmovaps [rsp+0xC0], xmm15
00007175dc9d6344  vmovaps xmm13, [rsp+0xC0]
00007175dc9d634d  por xmm15, xmm13
00007175dc9d6352  movaps xmm13, [r15+0x1D0]
00007175dc9d635a  vmovaps [rsp+0xC0], xmm13
00007175dc9d6363  vmovaps [rsp+0xD0], xmm1
00007175dc9d636c  vmovaps xmm1, [rsp+0xC0]
00007175dc9d6375  por xmm13, xmm1
00007175dc9d637a  movaps xmm1, [r15+0x2C0]
00007175dc9d6382  vmovaps [rsp+0xC0], xmm1
00007175dc9d638b  vmovaps [rsp+0xE0], xmm15
00007175dc9d6394  vmovaps xmm15, [rsp+0xC0]
00007175dc9d639d  por xmm1, xmm15
00007175dc9d63a2  movaps xmm15, [r15+0x290]
00007175dc9d63aa  vmovaps [rsp+0xC0], xmm15
00007175dc9d63b3  vmovaps [rsp+0xF0], xmm1
00007175dc9d63bc  vmovaps xmm1, [rsp+0xC0]
00007175dc9d63c5  por xmm15, xmm1
00007175dc9d63ca  movaps xmm1, [r15+0x260]
00007175dc9d63d2  vmovaps [rsp+0xC0], xmm1
00007175dc9d63db  vmovaps [rsp+0x100], xmm15
00007175dc9d63e4  vmovaps xmm15, [rsp+0xC0]
00007175dc9d63ed  por xmm1, xmm15
00007175dc9d63f2  vmovaps xmm15, [rsp+0xD0]
00007175dc9d63fb  vmovaps [rsp+0xC0], xmm1
00007175dc9d6404  vmovaps xmm1, [rsp+0xD0]
00007175dc9d640d  por xmm15, xmm1
00007175dc9d6412  lea r14, [rax+0xC0]
00007175dc9d6419  movups xmm1, [r13+r14*1]
00007175dc9d641f  mov [rsp+0xD0], rax
00007175dc9d6427  xor eax, eax
00007175dc9d6429  mov r14d, 0x200
00007175dc9d642f  cmp r12, r14
00007175dc9d6432  cmc
00007175dc9d6433  lahf
00007175dc9d6434  seto al
00007175dc9d6437  mov [r15+0x108], eax
00007175dc9d643e  vmovaps [rsp+0x110], xmm1
00007175dc9d6447  vmovaps xmm1, [rsp+0x80]
00007175dc9d6450  vmovaps [rsp+0x80], xmm15
00007175dc9d6459  vmovaps xmm15, [rsp+0x110]
00007175dc9d6462  vmovaps [rsp+0x110], xmm13
00007175dc9d646b  vmovaps [rsp+0x120], xmm12
00007175dc9d6474  movaps xmm13, xmm1
00007175dc9d6478  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d6483  vptest xmm12, xmm12
00007175dc9d6488  jnz 0x00007175DC9D7058
00007175dc9d648e  mov rax, [rsp+0xD0]
00007175dc9d6496  lea r14, [rax+0xB0]
00007175dc9d649d  movups xmm1, [r13+r14*1]
00007175dc9d64a3  vmovaps xmm15, [rsp+0xA0]
00007175dc9d64ac  vmovaps [rsp+0xA0], xmm13
00007175dc9d64b5  movaps xmm12, xmm15
00007175dc9d64b9  vfmadd231pd xmm12, xmm1, xmm14
00007175dc9d64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007175dc9d64c4  vptest xmm13, xmm13
00007175dc9d64c9  jnz 0x00007175DC9D71BB
00007175dc9d64cf  vmovaps xmm1, [rsp+0x30]
00007175dc9d64d5  vmovaps xmm15, [rsp+0x30]
00007175dc9d64db  por xmm1, xmm15
00007175dc9d64e0  movaps [r15+0x210], xmm1
00007175dc9d64e8  vmovaps xmm15, [rsp+0x70]
00007175dc9d64ee  vmovaps xmm14, [rsp+0x70]
00007175dc9d64f4  por xmm15, xmm14
00007175dc9d64f9  movaps [r15+0x1C0], xmm15
00007175dc9d6501  vmovaps xmm14, [rsp+0x60]
00007175dc9d6507  vmovaps xmm13, [rsp+0x60]
00007175dc9d650d  por xmm14, xmm13
00007175dc9d6512  movaps [r15+0x280], xmm14
00007175dc9d651a  vmovaps xmm13, [rsp+0x50]
00007175dc9d6520  vmovaps [rsp+0x30], xmm1
00007175dc9d6526  vmovaps xmm1, [rsp+0x50]
00007175dc9d652c  por xmm13, xmm1
00007175dc9d6531  movaps [r15+0x2A0], xmm13
00007175dc9d6539  vmovaps [rsp+0x50], xmm2
00007175dc9d653f  vmovaps xmm1, [rsp+0x50]
00007175dc9d6545  por xmm2, xmm1
00007175dc9d6549  movaps [r15+0x2E0], xmm2
00007175dc9d6551  vmovaps [rsp+0x50], xmm3
00007175dc9d6557  vmovaps xmm1, [rsp+0x50]
00007175dc9d655d  por xmm3, xmm1
00007175dc9d6561  movaps [r15+0x1F0], xmm3
00007175dc9d6569  vmovaps xmm1, [rsp+0x80]
00007175dc9d6572  vmovaps [rsp+0x50], xmm15
00007175dc9d6578  vmovaps xmm15, [rsp+0x80]
00007175dc9d6581  por xmm1, xmm15
00007175dc9d6586  movaps [r15+0x250], xmm1
00007175dc9d658e  vmovaps xmm1, [rsp+0xC0]
00007175dc9d6597  vmovaps xmm15, [rsp+0xC0]
00007175dc9d65a0  por xmm1, xmm15
00007175dc9d65a5  movaps [r15+0x260], xmm1
00007175dc9d65ad  vmovaps xmm15, [rsp+0x100]
00007175dc9d65b6  vmovaps [rsp+0x60], xmm1
00007175dc9d65bc  vmovaps xmm1, [rsp+0x100]
00007175dc9d65c5  por xmm15, xmm1
00007175dc9d65ca  movaps [r15+0x290], xmm15
00007175dc9d65d2  vmovaps xmm1, [rsp+0xF0]
00007175dc9d65db  vmovaps [rsp+0x70], xmm15
00007175dc9d65e1  vmovaps xmm15, [rsp+0xF0]
00007175dc9d65ea  por xmm1, xmm15
00007175dc9d65ef  movaps [r15+0x2C0], xmm1
00007175dc9d65f7  movq xmm15, qword ptr [r15+0x240]
00007175dc9d6600  vmovaps [rsp+0x80], xmm15
00007175dc9d6609  vpermilpd xmm15, xmm15, 0x00
00007175dc9d660f  vmovaps [rsp+0xC0], xmm1
00007175dc9d6618  vmovaps xmm1, [rsp+0x40]
00007175dc9d661e  vmovaps [rsp+0x40], xmm15
00007175dc9d6624  vmovaps xmm15, [rsp+0x30]
00007175dc9d662a  vmovaps [rsp+0x30], xmm14
00007175dc9d6630  vmovaps xmm14, [rsp+0x40]
00007175dc9d6636  vmovaps [rsp+0x40], xmm13
00007175dc9d663c  vmovaps [rsp+0xD0], xmm12
00007175dc9d6645  movaps xmm13, xmm1
00007175dc9d6649  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d6654  vptest xmm12, xmm12
00007175dc9d6659  jnz 0x00007175DC9D7314
00007175dc9d665f  vmovaps xmm1, [rsp+0x80]
00007175dc9d6668  vpermilpd xmm1, xmm1, 0x00
00007175dc9d666e  vmovaps xmm15, [rsp+0xA0]
00007175dc9d6677  movaps xmm14, xmm15
00007175dc9d667b  vfmadd231pd xmm14, xmm2, xmm1
00007175dc9d6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007175dc9d6686  vptest xmm12, xmm12
00007175dc9d668b  jnz 0x00007175DC9D746D
00007175dc9d6691  vmovaps xmm1, [rsp+0x80]
00007175dc9d669a  vpermilpd xmm1, xmm1, 0x00
00007175dc9d66a0  vmovaps xmm15, [rsp+0x120]
00007175dc9d66a9  vmovaps xmm12, [rsp+0x50]
00007175dc9d66af  vmovaps [rsp+0x50], xmm14
00007175dc9d66b5  movaps xmm2, xmm15
00007175dc9d66b9  vfmadd231pd xmm2, xmm12, xmm1
00007175dc9d66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007175dc9d66c3  vptest xmm14, xmm14
00007175dc9d66c8  jnz 0x00007175DC9D75C5
00007175dc9d66ce  vmovaps xmm1, [rsp+0x110]
00007175dc9d66d7  vmovaps xmm15, [rsp+0x110]
00007175dc9d66e0  por xmm1, xmm15
00007175dc9d66e5  movaps [r15+0x1D0], xmm1
00007175dc9d66ed  vmovaps xmm15, [rsp+0x80]
00007175dc9d66f6  vpermilpd xmm15, xmm15, 0x00
00007175dc9d66fc  vmovaps xmm14, [rsp+0xD0]
00007175dc9d6705  vmovaps [rsp+0x80], xmm1
00007175dc9d670e  movaps xmm12, xmm14
00007175dc9d6712  vfmadd231pd xmm12, xmm3, xmm15
00007175dc9d6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007175dc9d671d  vptest xmm1, xmm1
00007175dc9d6722  jnz 0x00007175DC9D771C
00007175dc9d6728  vmovaps [rsp+0xA0], xmm4
00007175dc9d6731  vmovaps xmm1, [rsp+0xA0]
00007175dc9d673a  por xmm4, xmm1
00007175dc9d673e  movaps [r15+0x200], xmm4
00007175dc9d6746  vmovaps xmm1, [rsp+0xE0]
00007175dc9d674f  vmovaps xmm15, [rsp+0xE0]
00007175dc9d6758  por xmm1, xmm15
00007175dc9d675d  movaps [r15+0x1E0], xmm1
00007175dc9d6765  vmovaps [rsp+0xA0], xmm8
00007175dc9d676e  vmovaps xmm1, [rsp+0xA0]
00007175dc9d6777  por xmm8, xmm1
00007175dc9d677c  movaps [r15+0x2B0], xmm8
00007175dc9d6784  vmovaps [rsp+0xA0], xmm9
00007175dc9d678d  vmovaps xmm1, [rsp+0xA0]
00007175dc9d6796  por xmm9, xmm1
00007175dc9d679b  movaps [r15+0x300], xmm9
00007175dc9d67a3  vmovaps [rsp+0xA0], xmm6
00007175dc9d67ac  vpermilpd xmm6, xmm6, 0x00
00007175dc9d67b2  vmovaps xmm14, [rsp+0x60]
00007175dc9d67b8  movaps xmm9, xmm13
00007175dc9d67bc  vfmadd231pd xmm9, xmm14, xmm6
00007175dc9d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007175dc9d67c7  vptest xmm3, xmm3
00007175dc9d67cc  jnz 0x00007175DC9D7875
00007175dc9d67d2  vmovaps xmm14, [rsp+0xA0]
00007175dc9d67db  vpermilpd xmm14, xmm14, 0x00
00007175dc9d67e1  vmovaps xmm13, [rsp+0x50]
00007175dc9d67e7  vmovaps xmm6, [rsp+0xC0]
00007175dc9d67f0  vmovaps [rsp+0x50], xmm1
00007175dc9d67f6  movaps xmm3, xmm13
00007175dc9d67fa  vfmadd231pd xmm3, xmm6, xmm14
00007175dc9d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007175dc9d6804  vptest xmm1, xmm1
00007175dc9d6809  jnz 0x00007175DC9D79CE
00007175dc9d680f  vmovaps xmm1, [rsp+0xA0]
00007175dc9d6818  vpermilpd xmm1, xmm1, 0x00
00007175dc9d681e  vmovaps xmm14, [rsp+0x30]
00007175dc9d6824  movaps xmm6, xmm2
00007175dc9d6827  vfmadd231pd xmm6, xmm14, xmm1
00007175dc9d682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007175dc9d6831  vptest xmm13, xmm13
00007175dc9d6836  jnz 0x00007175DC9D7B25
00007175dc9d683c  vmovaps xmm1, [rsp+0xA0]
00007175dc9d6845  vpermilpd xmm1, xmm1, 0x00
00007175dc9d684b  vmovaps xmm14, [rsp+0x80]
00007175dc9d6854  movaps xmm13, xmm12
00007175dc9d6858  vfmadd231pd xmm13, xmm14, xmm1
00007175dc9d685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007175dc9d6863  vptest xmm2, xmm2
00007175dc9d6868  jnz 0x00007175DC9D7C7B
00007175dc9d686e  vmovaps [rsp+0x30], xmm7
00007175dc9d6874  vmovaps xmm1, [rsp+0x30]
00007175dc9d687a  por xmm7, xmm1
00007175dc9d687e  movaps [r15+0x180], xmm7
00007175dc9d6886  vmovaps [rsp+0x30], xmm10
00007175dc9d688c  vmovaps xmm1, [rsp+0x30]
00007175dc9d6892  por xmm10, xmm1
00007175dc9d6897  movaps [r15+0x2D0], xmm10
00007175dc9d689f  vmovaps [rsp+0x30], xmm5
00007175dc9d68a5  vpermilpd xmm5, xmm5, 0x00
00007175dc9d68ab  vmovaps xmm14, [rsp+0x50]
00007175dc9d68b1  movaps xmm12, xmm3
00007175dc9d68b5  vfmadd231pd xmm12, xmm14, xmm5
00007175dc9d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007175dc9d68c0  vptest xmm10, xmm10
00007175dc9d68c5  jnz 0x00007175DC9D7DD4
00007175dc9d68cb  vmovaps xmm14, [rsp+0x30]
00007175dc9d68d1  vpermilpd xmm14, xmm14, 0x00
00007175dc9d68d7  movaps xmm10, xmm9
00007175dc9d68db  vfmadd231pd xmm10, xmm7, xmm14
00007175dc9d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007175dc9d68e6  vptest xmm5, xmm5
00007175dc9d68eb  jnz 0x00007175DC9D7F2C
00007175dc9d68f1  lea r14, [rax+0x80]
00007175dc9d68f8  movups xmm14, [r13+r14*1]
00007175dc9d68fe  movaps [r15+0x2F0], xmm14
00007175dc9d6906  vmovaps xmm9, [rsp+0x30]
00007175dc9d690c  vpermilpd xmm9, xmm9, 0x00
00007175dc9d6912  vmovaps xmm7, [rsp+0x70]
00007175dc9d6918  movaps xmm5, xmm6
00007175dc9d691b  vfmadd231pd xmm5, xmm7, xmm9
00007175dc9d6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007175dc9d6925  vptest xmm3, xmm3
00007175dc9d692a  jnz 0x00007175DC9D808F
00007175dc9d6930  vmovaps xmm9, [rsp+0x30]
00007175dc9d6936  vpermilpd xmm9, xmm9, 0x00
00007175dc9d693c  movaps xmm7, xmm13
00007175dc9d6940  vfmadd231pd xmm7, xmm1, xmm9
00007175dc9d6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007175dc9d694a  vptest xmm6, xmm6
00007175dc9d694f  jnz 0x00007175DC9D81E5
00007175dc9d6955  vmovaps xmm1, [rsp+0x20]
00007175dc9d695b  vmovaps xmm13, [rsp+0x20]
00007175dc9d6961  por xmm1, xmm13
00007175dc9d6966  movaps [r15+0x160], xmm1
00007175dc9d696e  lea r14, [rax+0x40]
00007175dc9d6972  movups xmm13, [r13+r14*1]
00007175dc9d6978  lea r14, [rax+0x50]
00007175dc9d697c  movups xmm9, [r13+r14*1]
00007175dc9d6982  movaps [r15+0x1B0], xmm13
00007175dc9d698a  movaps [r15+0x1A0], xmm9
00007175dc9d6992  movaps xmm6, [r15+0x190]
00007175dc9d699a  vmovaps xmm3, [rsp+0xB0]
00007175dc9d69a3  vpermilpd xmm3, xmm3, 0x00
00007175dc9d69a9  vmovaps [rsp+0x20], xmm1
00007175dc9d69af  movaps xmm2, xmm12
00007175dc9d69b3  vfmadd231pd xmm2, xmm6, xmm3
00007175dc9d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007175dc9d69bd  vptest xmm1, xmm1
00007175dc9d69c2  jnz 0x00007175DC9D8350
00007175dc9d69c8  vmovaps xmm1, [rsp+0xB0]
00007175dc9d69d1  vpermilpd xmm1, xmm1, 0x00
00007175dc9d69d7  vmovaps xmm12, [rsp+0x20]
00007175dc9d69dd  movaps xmm6, xmm10
00007175dc9d69e1  vfmadd231pd xmm6, xmm12, xmm1
00007175dc9d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007175dc9d69eb  vptest xmm3, xmm3
00007175dc9d69f0  jnz 0x00007175DC9D84A6
00007175dc9d69f6  vmovaps xmm1, [rsp+0xB0]
00007175dc9d69ff  vpermilpd xmm1, xmm1, 0x00
00007175dc9d6a05  vmovaps xmm12, [rsp+0x40]
00007175dc9d6a0b  movaps xmm10, xmm5
00007175dc9d6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007175dc9d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007175dc9d6a1a  vptest xmm3, xmm3
00007175dc9d6a1f  jnz 0x00007175DC9D85FD
00007175dc9d6a25  vmovaps xmm1, [rsp+0xB0]
00007175dc9d6a2e  vpermilpd xmm1, xmm1, 0x00
00007175dc9d6a34  movaps xmm12, xmm7
00007175dc9d6a38  vfmadd231pd xmm12, xmm15, xmm1
00007175dc9d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007175dc9d6a43  vptest xmm5, xmm5
00007175dc9d6a48  jnz 0x00007175DC9D8755
00007175dc9d6a4e  lea r14, [rax+0x60]
00007175dc9d6a52  movups xmm1, [r13+r14*1]
00007175dc9d6a58  lea r14, [rax+0x70]
00007175dc9d6a5c  movups xmm15, [r13+r14*1]
00007175dc9d6a62  movaps [r15+0x150], xmm1
00007175dc9d6a6a  movaps [r15+0x120], xmm15
00007175dc9d6a72  vmovaps [rsp+0x20], xmm11
00007175dc9d6a78  vpermilpd xmm11, xmm11, 0x00
00007175dc9d6a7e  movaps xmm7, xmm2
00007175dc9d6a81  vfmadd231pd xmm7, xmm9, xmm11
00007175dc9d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007175dc9d6a8b  vptest xmm5, xmm5
00007175dc9d6a90  jnz 0x00007175DC9D88C1
00007175dc9d6a96  vmovaps xmm11, [rsp+0x20]
00007175dc9d6a9c  vpermilpd xmm11, xmm11, 0x00
00007175dc9d6aa2  movaps xmm9, xmm6
00007175dc9d6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007175dc9d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007175dc9d6ab1  vptest xmm5, xmm5
00007175dc9d6ab6  jnz 0x00007175DC9D8A18
00007175dc9d6abc  vmovaps xmm1, [rsp+0x20]
00007175dc9d6ac2  vpermilpd xmm1, xmm1, 0x00
00007175dc9d6ac8  movaps xmm11, xmm10
00007175dc9d6acc  vfmadd231pd xmm11, xmm8, xmm1
00007175dc9d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007175dc9d6ad7  vptest xmm6, xmm6
00007175dc9d6adc  jnz 0x00007175DC9D8B70
00007175dc9d6ae2  vmovaps xmm1, [rsp+0x20]
00007175dc9d6ae8  vpermilpd xmm1, xmm1, 0x00
00007175dc9d6aee  movaps xmm10, xmm12
00007175dc9d6af2  vfmadd231pd xmm10, xmm13, xmm1
00007175dc9d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007175dc9d6afd  vptest xmm8, xmm8
00007175dc9d6b02  jnz 0x00007175DC9D8CC9
00007175dc9d6b08  lea r14, [rax+0x20]
00007175dc9d6b0c  movups xmm1, [r13+r14*1]
00007175dc9d6b12  lea r14, [rax+0x30]
00007175dc9d6b16  movups xmm13, [r13+r14*1]
00007175dc9d6b1c  vmovaps xmm12, [rsp+0x90]
00007175dc9d6b25  vpermilpd xmm12, xmm12, 0x00
00007175dc9d6b2b  movaps xmm8, xmm7
00007175dc9d6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007175dc9d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007175dc9d6b3a  vptest xmm6, xmm6
00007175dc9d6b3f  jnz 0x00007175DC9D8E36
00007175dc9d6b45  vmovaps xmm12, [rsp+0x90]
00007175dc9d6b4e  vpermilpd xmm12, xmm12, 0x00
00007175dc9d6b54  movaps xmm7, xmm9
00007175dc9d6b58  vfmadd231pd xmm7, xmm14, xmm12
00007175dc9d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007175dc9d6b62  vptest xmm6, xmm6
00007175dc9d6b67  jnz 0x00007175DC9D8F8E
00007175dc9d6b6d  vmovaps xmm14, [rsp+0x90]
00007175dc9d6b76  vpermilpd xmm14, xmm14, 0x00
00007175dc9d6b7c  movaps xmm12, xmm11
00007175dc9d6b80  vfmadd231pd xmm12, xmm15, xmm14
00007175dc9d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007175dc9d6b8b  vptest xmm9, xmm9
00007175dc9d6b90  jnz 0x00007175DC9D90E6
00007175dc9d6b96  vmovaps xmm15, [rsp+0x90]
00007175dc9d6b9f  vpermilpd xmm15, xmm15, 0x00
00007175dc9d6ba5  movaps xmm11, xmm10
00007175dc9d6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007175dc9d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007175dc9d6bb4  vptest xmm14, xmm14
00007175dc9d6bb9  jnz 0x00007175DC9D9240
00007175dc9d6bbf  lea r14, [rax+0x90]
00007175dc9d6bc6  movups xmm15, [r13+r14*1]
00007175dc9d6bcc  lea r14, [rax+0xA0]
00007175dc9d6bd3  movups xmm14, [r13+r14*1]
00007175dc9d6bd9  movaps [r15+0x140], xmm15
00007175dc9d6be1  movaps [r15+0x130], xmm14
00007175dc9d6be9  vmovaps xmm13, [rsp+0x10]
00007175dc9d6bef  vpermilpd xmm13, xmm13, 0x00
00007175dc9d6bf5  movaps xmm10, xmm8
00007175dc9d6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007175dc9d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007175dc9d6c04  vptest xmm9, xmm9
00007175dc9d6c09  jnz 0x00007175DC9D93AE
00007175dc9d6c0f  movaps [r15+0x220], xmm10
00007175dc9d6c17  lea r14, [rax+0x10]
00007175dc9d6c1b  movups xmm1, [r13+r14*1]
00007175dc9d6c21  movaps [r15+0x240], xmm1
00007175dc9d6c29  vmovaps xmm13, [rsp+0x10]
00007175dc9d6c2f  vpermilpd xmm13, xmm13, 0x00
00007175dc9d6c35  movaps xmm9, xmm7
00007175dc9d6c39  vfmadd231pd xmm9, xmm14, xmm13
00007175dc9d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007175dc9d6c44  vptest xmm8, xmm8
00007175dc9d6c49  jnz 0x00007175DC9D9511
00007175dc9d6c4f  movaps [r15+0x110], xmm9
00007175dc9d6c57  vmovaps xmm14, [rsp+0x10]
00007175dc9d6c5d  vpermilpd xmm14, xmm14, 0x00
00007175dc9d6c63  movaps xmm13, xmm12
00007175dc9d6c67  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007175dc9d6c72  vptest xmm8, xmm8
00007175dc9d6c77  jnz 0x00007175DC9D966A
00007175dc9d6c7d  movaps [r15+0x170], xmm13
00007175dc9d6c85  vmovaps xmm15, [rsp+0x10]
00007175dc9d6c8b  vpermilpd xmm15, xmm15, 0x00
00007175dc9d6c91  movaps xmm14, xmm11
00007175dc9d6c95  vfmadd231pd xmm14, xmm1, xmm15
00007175dc9d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007175dc9d6ca0  vptest xmm12, xmm12
00007175dc9d6ca5  jnz 0x00007175DC9D97C4
00007175dc9d6cab  movaps [r15+0x230], xmm14
00007175dc9d6cb3  movups [r13+r11*1], xmm9
00007175dc9d6cb9  lea rax, [r11+0x10]
00007175dc9d6cbd  movups [r13+rax*1], xmm13
00007175dc9d6cc3  lea rax, [r11+0x20]
00007175dc9d6cc7  movups [r13+rax*1], xmm10
00007175dc9d6ccd  lea rax, [r11+0x30]
00007175dc9d6cd1  movups [r13+rax*1], xmm14
00007175dc9d6cd7  mov eax, [r15+0x108]
00007175dc9d6cde  sahf
00007175dc9d6cdf  jnz 0x00007175DC9D6D11
00007175dc9d6ce1  cmp dword ptr [r15+0x318], 0x00
00007175dc9d6ce9  jz 0x00007175DC9D9950
00007175dc9d6cef  nop [rax+rax*1], ax
00007175dc9d6cf8  nop [rax+rax*1], eax
00007175dc9d6d00  mov eax, 0x410664
00007175dc9d6d05  mov [r15+0x100], rax
00007175dc9d6d0c  jmp 0x00007175DC7FE110
00007175dc9d6d11  cmp dword ptr [r15+0x318], 0x00
00007175dc9d6d19  jz 0x00007175DC9D6050
00007175dc9d6d1f  nop [rax+rax*1], ax
00007175dc9d6d28  nop [rax+rax*1], eax
00007175dc9d6d30  mov eax, 0x4104F0
00007175dc9d6d35  mov [r15+0x100], rax
00007175dc9d6d3c  jmp 0x00007175DC7FE110
00007175dc9d6d41  int3
00007175dc9d6d42  call 0x00007175DC80A4B0
00007175dc9d6d47  jmp 0x00007175DC9D6079
00007175dc9d6d4c  call 0x00007175DC809240
00007175dc9d6d51  jmp 0x00007175DC9D6083
00007175dc9d6d56  call 0x00007175DC80A4B0
00007175dc9d6d5b  jmp 0x00007175DC9D60CD
00007175dc9d6d60  call 0x00007175DC809240
00007175dc9d6d65  jmp 0x00007175DC9D60D7
00007175dc9d6d6a  call 0x00007175DC80A4B0
00007175dc9d6d6f  jmp 0x00007175DC9D6158
00007175dc9d6d74  call 0x00007175DC809240
00007175dc9d6d79  jmp 0x00007175DC9D6162
00007175dc9d6d7e  call 0x00007175DC8B47C0
00007175dc9d6d83  jmp 0x00007175DC9D6243
00007175dc9d6d88  call 0x00007175DC7FF430
00007175dc9d6d8d  jmp 0x00007175DC9D6272
00007175dc9d6d92  call 0x00007175DC8B0CE0
00007175dc9d6d97  jmp 0x00007175DC9D628E
00007175dc9d6d9c  sub rsp, 0x08
00007175dc9d6da0  push rax
00007175dc9d6da1  push rcx
00007175dc9d6da2  push rdx
00007175dc9d6da3  push rdi
00007175dc9d6da4  push rsi
00007175dc9d6da5  push r8
00007175dc9d6da7  push r9
00007175dc9d6da9  push r10
00007175dc9d6dab  push r11
00007175dc9d6dad  sub rsp, 0xF0
00007175dc9d6db4  vmovaps [rsp], xmm0
00007175dc9d6db9  vmovaps [rsp+0x10], xmm1
00007175dc9d6dbf  vmovaps [rsp+0x20], xmm2
00007175dc9d6dc5  vmovaps [rsp+0x30], xmm3
00007175dc9d6dcb  vmovaps [rsp+0x40], xmm4
00007175dc9d6dd1  vmovaps [rsp+0x50], xmm5
00007175dc9d6dd7  vmovaps [rsp+0x60], xmm6
00007175dc9d6ddd  vmovaps [rsp+0x70], xmm7
00007175dc9d6de3  vmovaps [rsp+0x80], xmm8
00007175dc9d6dec  vmovaps [rsp+0x90], xmm9
00007175dc9d6df5  vmovaps [rsp+0xA0], xmm10
00007175dc9d6dfe  vmovaps [rsp+0xB0], xmm11
00007175dc9d6e07  vmovaps [rsp+0xC0], xmm12
00007175dc9d6e10  vmovaps [rsp+0xD0], xmm14
00007175dc9d6e19  vmovaps [rsp+0xE0], xmm15
00007175dc9d6e22  sub rsp, 0x40
00007175dc9d6e26  lea rdi, [rsp]
00007175dc9d6e2a  lea rsi, [rsp+0x10]
00007175dc9d6e2f  lea rdx, [rsp+0x20]
00007175dc9d6e34  lea rcx, [rsp+0x30]
00007175dc9d6e39  mov r8d, 0x00
00007175dc9d6e3f  lea r9, [r15+0x3A8]
00007175dc9d6e46  movaps [rdi], xmm13
00007175dc9d6e4a  movaps [rsi], xmm1
00007175dc9d6e4d  movaps [rdx], xmm15
00007175dc9d6e51  movaps [rcx], xmm14
00007175dc9d6e55  mov rax, 0x622B29CAFA50
00007175dc9d6e5f  call rax
00007175dc9d6e61  movaps xmm13, [rsp]
00007175dc9d6e66  add rsp, 0x40
00007175dc9d6e6a  vmovaps xmm0, [rsp]
00007175dc9d6e6f  vmovaps xmm1, [rsp+0x10]
00007175dc9d6e75  vmovaps xmm2, [rsp+0x20]
00007175dc9d6e7b  vmovaps xmm3, [rsp+0x30]
00007175dc9d6e81  vmovaps xmm4, [rsp+0x40]
00007175dc9d6e87  vmovaps xmm5, [rsp+0x50]
00007175dc9d6e8d  vmovaps xmm6, [rsp+0x60]
00007175dc9d6e93  vmovaps xmm7, [rsp+0x70]
00007175dc9d6e99  vmovaps xmm8, [rsp+0x80]
00007175dc9d6ea2  vmovaps xmm9, [rsp+0x90]
00007175dc9d6eab  vmovaps xmm10, [rsp+0xA0]
00007175dc9d6eb4  vmovaps xmm11, [rsp+0xB0]
00007175dc9d6ebd  vmovaps xmm12, [rsp+0xC0]
00007175dc9d6ec6  vmovaps xmm14, [rsp+0xD0]
00007175dc9d6ecf  vmovaps xmm15, [rsp+0xE0]
00007175dc9d6ed8  add rsp, 0xF0
00007175dc9d6edf  pop r11
00007175dc9d6ee1  pop r10
00007175dc9d6ee3  pop r9
00007175dc9d6ee5  pop r8
00007175dc9d6ee7  pop rsi
00007175dc9d6ee8  pop rdi
00007175dc9d6ee9  pop rdx
00007175dc9d6eea  pop rcx
00007175dc9d6eeb  pop rax
00007175dc9d6eec  add rsp, 0x08
00007175dc9d6ef0  jmp 0x00007175DC9D6305
00007175dc9d6ef5  sub rsp, 0x08
00007175dc9d6ef9  push rax
00007175dc9d6efa  push rcx
00007175dc9d6efb  push rdx
00007175dc9d6efc  push rdi
00007175dc9d6efd  push rsi
00007175dc9d6efe  push r8
00007175dc9d6f00  push r9
00007175dc9d6f02  push r10
00007175dc9d6f04  push r11
00007175dc9d6f06  sub rsp, 0xF0
00007175dc9d6f0d  vmovaps [rsp], xmm0
00007175dc9d6f12  vmovaps [rsp+0x10], xmm1
00007175dc9d6f18  vmovaps [rsp+0x20], xmm2
00007175dc9d6f1e  vmovaps [rsp+0x30], xmm3
00007175dc9d6f24  vmovaps [rsp+0x40], xmm4
00007175dc9d6f2a  vmovaps [rsp+0x50], xmm5
00007175dc9d6f30  vmovaps [rsp+0x60], xmm6
00007175dc9d6f36  vmovaps [rsp+0x70], xmm7
00007175dc9d6f3c  vmovaps [rsp+0x80], xmm8
00007175dc9d6f45  vmovaps [rsp+0x90], xmm9
00007175dc9d6f4e  vmovaps [rsp+0xA0], xmm10
00007175dc9d6f57  vmovaps [rsp+0xB0], xmm11
00007175dc9d6f60  vmovaps [rsp+0xC0], xmm13
00007175dc9d6f69  vmovaps [rsp+0xD0], xmm14
00007175dc9d6f72  vmovaps [rsp+0xE0], xmm15
00007175dc9d6f7b  sub rsp, 0x40
00007175dc9d6f7f  lea rdi, [rsp]
00007175dc9d6f83  lea rsi, [rsp+0x10]
00007175dc9d6f88  lea rdx, [rsp+0x20]
00007175dc9d6f8d  lea rcx, [rsp+0x30]
00007175dc9d6f92  mov r8d, 0x00
00007175dc9d6f98  lea r9, [r15+0x3A8]
00007175dc9d6f9f  movaps [rdi], xmm12
00007175dc9d6fa3  movaps [rsi], xmm15
00007175dc9d6fa7  movaps [rdx], xmm1
00007175dc9d6faa  movaps [rcx], xmm14
00007175dc9d6fae  mov rax, 0x622B29CAFA50
00007175dc9d6fb8  call rax
00007175dc9d6fba  movaps xmm12, [rsp]
00007175dc9d6fbf  add rsp, 0x40
00007175dc9d6fc3  vmovaps xmm0, [rsp]
00007175dc9d6fc8  vmovaps xmm1, [rsp+0x10]
00007175dc9d6fce  vmovaps xmm2, [rsp+0x20]
00007175dc9d6fd4  vmovaps xmm3, [rsp+0x30]
00007175dc9d6fda  vmovaps xmm4, [rsp+0x40]
00007175dc9d6fe0  vmovaps xmm5, [rsp+0x50]
00007175dc9d6fe6  vmovaps xmm6, [rsp+0x60]
00007175dc9d6fec  vmovaps xmm7, [rsp+0x70]
00007175dc9d6ff2  vmovaps xmm8, [rsp+0x80]
00007175dc9d6ffb  vmovaps xmm9, [rsp+0x90]
00007175dc9d7004  vmovaps xmm10, [rsp+0xA0]
00007175dc9d700d  vmovaps xmm11, [rsp+0xB0]
00007175dc9d7016  vmovaps xmm13, [rsp+0xC0]
00007175dc9d701f  vmovaps xmm14, [rsp+0xD0]
00007175dc9d7028  vmovaps xmm15, [rsp+0xE0]
00007175dc9d7031  add rsp, 0xF0
00007175dc9d7038  pop r11
00007175dc9d703a  pop r10
00007175dc9d703c  pop r9
00007175dc9d703e  pop r8
00007175dc9d7040  pop rsi
00007175dc9d7041  pop rdi
00007175dc9d7042  pop rdx
00007175dc9d7043  pop rcx
00007175dc9d7044  pop rax
00007175dc9d7045  add rsp, 0x08
00007175dc9d7049  jmp 0x00007175DC9D6333
00007175dc9d704e  call 0x00007175DC8D64F0
00007175dc9d7053  jmp 0x00007175DC9D641F
00007175dc9d7058  sub rsp, 0x08
00007175dc9d705c  push rax
00007175dc9d705d  push rcx
00007175dc9d705e  push rdx
00007175dc9d705f  push rdi
00007175dc9d7060  push rsi
00007175dc9d7061  push r8
00007175dc9d7063  push r9
00007175dc9d7065  push r10
00007175dc9d7067  push r11
00007175dc9d7069  sub rsp, 0xF0
00007175dc9d7070  vmovaps [rsp], xmm0
00007175dc9d7075  vmovaps [rsp+0x10], xmm1
00007175dc9d707b  vmovaps [rsp+0x20], xmm2
00007175dc9d7081  vmovaps [rsp+0x30], xmm3
00007175dc9d7087  vmovaps [rsp+0x40], xmm4
00007175dc9d708d  vmovaps [rsp+0x50], xmm5
00007175dc9d7093  vmovaps [rsp+0x60], xmm6
00007175dc9d7099  vmovaps [rsp+0x70], xmm7
00007175dc9d709f  vmovaps [rsp+0x80], xmm8
00007175dc9d70a8  vmovaps [rsp+0x90], xmm9
00007175dc9d70b1  vmovaps [rsp+0xA0], xmm10
00007175dc9d70ba  vmovaps [rsp+0xB0], xmm11
00007175dc9d70c3  vmovaps [rsp+0xC0], xmm12
00007175dc9d70cc  vmovaps [rsp+0xD0], xmm14
00007175dc9d70d5  vmovaps [rsp+0xE0], xmm15
00007175dc9d70de  sub rsp, 0x40
00007175dc9d70e2  lea rdi, [rsp]
00007175dc9d70e6  lea rsi, [rsp+0x10]
00007175dc9d70eb  lea rdx, [rsp+0x20]
00007175dc9d70f0  lea rcx, [rsp+0x30]
00007175dc9d70f5  mov r8d, 0x00
00007175dc9d70fb  lea r9, [r15+0x3A8]
00007175dc9d7102  movaps [rdi], xmm13
00007175dc9d7106  movaps [rsi], xmm1
00007175dc9d7109  movaps [rdx], xmm15
00007175dc9d710d  movaps [rcx], xmm14
00007175dc9d7111  mov rax, 0x622B29CAFA50
00007175dc9d711b  call rax
00007175dc9d711d  movaps xmm13, [rsp]
00007175dc9d7122  add rsp, 0x40
00007175dc9d7126  vmovaps xmm0, [rsp]
00007175dc9d712b  vmovaps xmm1, [rsp+0x10]
00007175dc9d7131  vmovaps xmm2, [rsp+0x20]
00007175dc9d7137  vmovaps xmm3, [rsp+0x30]
00007175dc9d713d  vmovaps xmm4, [rsp+0x40]
00007175dc9d7143  vmovaps xmm5, [rsp+0x50]
00007175dc9d7149  vmovaps xmm6, [rsp+0x60]
00007175dc9d714f  vmovaps xmm7, [rsp+0x70]
00007175dc9d7155  vmovaps xmm8, [rsp+0x80]
00007175dc9d715e  vmovaps xmm9, [rsp+0x90]
00007175dc9d7167  vmovaps xmm10, [rsp+0xA0]
00007175dc9d7170  vmovaps xmm11, [rsp+0xB0]
00007175dc9d7179  vmovaps xmm12, [rsp+0xC0]
00007175dc9d7182  vmovaps xmm14, [rsp+0xD0]
00007175dc9d718b  vmovaps xmm15, [rsp+0xE0]
00007175dc9d7194  add rsp, 0xF0
00007175dc9d719b  pop r11
00007175dc9d719d  pop r10
00007175dc9d719f  pop r9
00007175dc9d71a1  pop r8
00007175dc9d71a3  pop rsi
00007175dc9d71a4  pop rdi
00007175dc9d71a5  pop rdx
00007175dc9d71a6  pop rcx
00007175dc9d71a7  pop rax
00007175dc9d71a8  add rsp, 0x08
00007175dc9d71ac  jmp 0x00007175DC9D648E
00007175dc9d71b1  call 0x00007175DC8D64F0
00007175dc9d71b6  jmp 0x00007175DC9D64A3
00007175dc9d71bb  sub rsp, 0x08
00007175dc9d71bf  push rax
00007175dc9d71c0  push rcx
00007175dc9d71c1  push rdx
00007175dc9d71c2  push rdi
00007175dc9d71c3  push rsi
00007175dc9d71c4  push r8
00007175dc9d71c6  push r9
00007175dc9d71c8  push r10
00007175dc9d71ca  push r11
00007175dc9d71cc  sub rsp, 0xF0
00007175dc9d71d3  vmovaps [rsp], xmm0
00007175dc9d71d8  vmovaps [rsp+0x10], xmm1
00007175dc9d71de  vmovaps [rsp+0x20], xmm2
00007175dc9d71e4  vmovaps [rsp+0x30], xmm3
00007175dc9d71ea  vmovaps [rsp+0x40], xmm4
00007175dc9d71f0  vmovaps [rsp+0x50], xmm5
00007175dc9d71f6  vmovaps [rsp+0x60], xmm6
00007175dc9d71fc  vmovaps [rsp+0x70], xmm7
00007175dc9d7202  vmovaps [rsp+0x80], xmm8
00007175dc9d720b  vmovaps [rsp+0x90], xmm9
00007175dc9d7214  vmovaps [rsp+0xA0], xmm10
00007175dc9d721d  vmovaps [rsp+0xB0], xmm11
00007175dc9d7226  vmovaps [rsp+0xC0], xmm13
00007175dc9d722f  vmovaps [rsp+0xD0], xmm14
00007175dc9d7238  vmovaps [rsp+0xE0], xmm15
00007175dc9d7241  sub rsp, 0x40
00007175dc9d7245  lea rdi, [rsp]
00007175dc9d7249  lea rsi, [rsp+0x10]
00007175dc9d724e  lea rdx, [rsp+0x20]
00007175dc9d7253  lea rcx, [rsp+0x30]
00007175dc9d7258  mov r8d, 0x00
00007175dc9d725e  lea r9, [r15+0x3A8]
00007175dc9d7265  movaps [rdi], xmm12
00007175dc9d7269  movaps [rsi], xmm15
00007175dc9d726d  movaps [rdx], xmm1
00007175dc9d7270  movaps [rcx], xmm14
00007175dc9d7274  mov rax, 0x622B29CAFA50
00007175dc9d727e  call rax
00007175dc9d7280  movaps xmm12, [rsp]
00007175dc9d7285  add rsp, 0x40
00007175dc9d7289  vmovaps xmm0, [rsp]
00007175dc9d728e  vmovaps xmm1, [rsp+0x10]
00007175dc9d7294  vmovaps xmm2, [rsp+0x20]
00007175dc9d729a  vmovaps xmm3, [rsp+0x30]
00007175dc9d72a0  vmovaps xmm4, [rsp+0x40]
00007175dc9d72a6  vmovaps xmm5, [rsp+0x50]
00007175dc9d72ac  vmovaps xmm6, [rsp+0x60]
00007175dc9d72b2  vmovaps xmm7, [rsp+0x70]
00007175dc9d72b8  vmovaps xmm8, [rsp+0x80]
00007175dc9d72c1  vmovaps xmm9, [rsp+0x90]
00007175dc9d72ca  vmovaps xmm10, [rsp+0xA0]
00007175dc9d72d3  vmovaps xmm11, [rsp+0xB0]
00007175dc9d72dc  vmovaps xmm13, [rsp+0xC0]
00007175dc9d72e5  vmovaps xmm14, [rsp+0xD0]
00007175dc9d72ee  vmovaps xmm15, [rsp+0xE0]
00007175dc9d72f7  add rsp, 0xF0
00007175dc9d72fe  pop r11
00007175dc9d7300  pop r10
00007175dc9d7302  pop r9
00007175dc9d7304  pop r8
00007175dc9d7306  pop rsi
00007175dc9d7307  pop rdi
00007175dc9d7308  pop rdx
00007175dc9d7309  pop rcx
00007175dc9d730a  pop rax
00007175dc9d730b  add rsp, 0x08
00007175dc9d730f  jmp 0x00007175DC9D64CF
00007175dc9d7314  sub rsp, 0x08
00007175dc9d7318  push rax
00007175dc9d7319  push rcx
00007175dc9d731a  push rdx
00007175dc9d731b  push rdi
00007175dc9d731c  push rsi
00007175dc9d731d  push r8
00007175dc9d731f  push r9
00007175dc9d7321  push r10
00007175dc9d7323  push r11
00007175dc9d7325  sub rsp, 0xF0
00007175dc9d732c  vmovaps [rsp], xmm0
00007175dc9d7331  vmovaps [rsp+0x10], xmm1
00007175dc9d7337  vmovaps [rsp+0x20], xmm2
00007175dc9d733d  vmovaps [rsp+0x30], xmm3
00007175dc9d7343  vmovaps [rsp+0x40], xmm4
00007175dc9d7349  vmovaps [rsp+0x50], xmm5
00007175dc9d734f  vmovaps [rsp+0x60], xmm6
00007175dc9d7355  vmovaps [rsp+0x70], xmm7
00007175dc9d735b  vmovaps [rsp+0x80], xmm8
00007175dc9d7364  vmovaps [rsp+0x90], xmm9
00007175dc9d736d  vmovaps [rsp+0xA0], xmm10
00007175dc9d7376  vmovaps [rsp+0xB0], xmm11
00007175dc9d737f  vmovaps [rsp+0xC0], xmm12
00007175dc9d7388  vmovaps [rsp+0xD0], xmm14
00007175dc9d7391  vmovaps [rsp+0xE0], xmm15
00007175dc9d739a  sub rsp, 0x40
00007175dc9d739e  lea rdi, [rsp]
00007175dc9d73a2  lea rsi, [rsp+0x10]
00007175dc9d73a7  lea rdx, [rsp+0x20]
00007175dc9d73ac  lea rcx, [rsp+0x30]
00007175dc9d73b1  mov r8d, 0x00
00007175dc9d73b7  lea r9, [r15+0x3A8]
00007175dc9d73be  movaps [rdi], xmm13
00007175dc9d73c2  movaps [rsi], xmm1
00007175dc9d73c5  movaps [rdx], xmm15
00007175dc9d73c9  movaps [rcx], xmm14
00007175dc9d73cd  mov rax, 0x622B29CAFA50
00007175dc9d73d7  call rax
00007175dc9d73d9  movaps xmm13, [rsp]
00007175dc9d73de  add rsp, 0x40
00007175dc9d73e2  vmovaps xmm0, [rsp]
00007175dc9d73e7  vmovaps xmm1, [rsp+0x10]
00007175dc9d73ed  vmovaps xmm2, [rsp+0x20]
00007175dc9d73f3  vmovaps xmm3, [rsp+0x30]
00007175dc9d73f9  vmovaps xmm4, [rsp+0x40]
00007175dc9d73ff  vmovaps xmm5, [rsp+0x50]
00007175dc9d7405  vmovaps xmm6, [rsp+0x60]
00007175dc9d740b  vmovaps xmm7, [rsp+0x70]
00007175dc9d7411  vmovaps xmm8, [rsp+0x80]
00007175dc9d741a  vmovaps xmm9, [rsp+0x90]
00007175dc9d7423  vmovaps xmm10, [rsp+0xA0]
00007175dc9d742c  vmovaps xmm11, [rsp+0xB0]
00007175dc9d7435  vmovaps xmm12, [rsp+0xC0]
00007175dc9d743e  vmovaps xmm14, [rsp+0xD0]
00007175dc9d7447  vmovaps xmm15, [rsp+0xE0]
00007175dc9d7450  add rsp, 0xF0
00007175dc9d7457  pop r11
00007175dc9d7459  pop r10
00007175dc9d745b  pop r9
00007175dc9d745d  pop r8
00007175dc9d745f  pop rsi
00007175dc9d7460  pop rdi
00007175dc9d7461  pop rdx
00007175dc9d7462  pop rcx
00007175dc9d7463  pop rax
00007175dc9d7464  add rsp, 0x08
00007175dc9d7468  jmp 0x00007175DC9D665F
00007175dc9d746d  sub rsp, 0x08
00007175dc9d7471  push rax
00007175dc9d7472  push rcx
00007175dc9d7473  push rdx
00007175dc9d7474  push rdi
00007175dc9d7475  push rsi
00007175dc9d7476  push r8
00007175dc9d7478  push r9
00007175dc9d747a  push r10
00007175dc9d747c  push r11
00007175dc9d747e  sub rsp, 0xF0
00007175dc9d7485  vmovaps [rsp], xmm0
00007175dc9d748a  vmovaps [rsp+0x10], xmm1
00007175dc9d7490  vmovaps [rsp+0x20], xmm2
00007175dc9d7496  vmovaps [rsp+0x30], xmm3
00007175dc9d749c  vmovaps [rsp+0x40], xmm4
00007175dc9d74a2  vmovaps [rsp+0x50], xmm5
00007175dc9d74a8  vmovaps [rsp+0x60], xmm6
00007175dc9d74ae  vmovaps [rsp+0x70], xmm7
00007175dc9d74b4  vmovaps [rsp+0x80], xmm8
00007175dc9d74bd  vmovaps [rsp+0x90], xmm9
00007175dc9d74c6  vmovaps [rsp+0xA0], xmm10
00007175dc9d74cf  vmovaps [rsp+0xB0], xmm11
00007175dc9d74d8  vmovaps [rsp+0xC0], xmm12
00007175dc9d74e1  vmovaps [rsp+0xD0], xmm13
00007175dc9d74ea  vmovaps [rsp+0xE0], xmm15
00007175dc9d74f3  sub rsp, 0x40
00007175dc9d74f7  lea rdi, [rsp]
00007175dc9d74fb  lea rsi, [rsp+0x10]
00007175dc9d7500  lea rdx, [rsp+0x20]
00007175dc9d7505  lea rcx, [rsp+0x30]
00007175dc9d750a  mov r8d, 0x00
00007175dc9d7510  lea r9, [r15+0x3A8]
00007175dc9d7517  movaps [rdi], xmm14
00007175dc9d751b  movaps [rsi], xmm15
00007175dc9d751f  movaps [rdx], xmm2
00007175dc9d7522  movaps [rcx], xmm1
00007175dc9d7525  mov rax, 0x622B29CAFA50
00007175dc9d752f  call rax
00007175dc9d7531  movaps xmm14, [rsp]
00007175dc9d7536  add rsp, 0x40
00007175dc9d753a  vmovaps xmm0, [rsp]
00007175dc9d753f  vmovaps xmm1, [rsp+0x10]
00007175dc9d7545  vmovaps xmm2, [rsp+0x20]
00007175dc9d754b  vmovaps xmm3, [rsp+0x30]
00007175dc9d7551  vmovaps xmm4, [rsp+0x40]
00007175dc9d7557  vmovaps xmm5, [rsp+0x50]
00007175dc9d755d  vmovaps xmm6, [rsp+0x60]
00007175dc9d7563  vmovaps xmm7, [rsp+0x70]
00007175dc9d7569  vmovaps xmm8, [rsp+0x80]
00007175dc9d7572  vmovaps xmm9, [rsp+0x90]
00007175dc9d757b  vmovaps xmm10, [rsp+0xA0]
00007175dc9d7584  vmovaps xmm11, [rsp+0xB0]
00007175dc9d758d  vmovaps xmm12, [rsp+0xC0]
00007175dc9d7596  vmovaps xmm13, [rsp+0xD0]
00007175dc9d759f  vmovaps xmm15, [rsp+0xE0]
00007175dc9d75a8  add rsp, 0xF0
00007175dc9d75af  pop r11
00007175dc9d75b1  pop r10
00007175dc9d75b3  pop r9
00007175dc9d75b5  pop r8
00007175dc9d75b7  pop rsi
00007175dc9d75b8  pop rdi
00007175dc9d75b9  pop rdx
00007175dc9d75ba  pop rcx
00007175dc9d75bb  pop rax
00007175dc9d75bc  add rsp, 0x08
00007175dc9d75c0  jmp 0x00007175DC9D6691
00007175dc9d75c5  sub rsp, 0x08
00007175dc9d75c9  push rax
00007175dc9d75ca  push rcx
00007175dc9d75cb  push rdx
00007175dc9d75cc  push rdi
00007175dc9d75cd  push rsi
00007175dc9d75ce  push r8
00007175dc9d75d0  push r9
00007175dc9d75d2  push r10
00007175dc9d75d4  push r11
00007175dc9d75d6  sub rsp, 0xF0
00007175dc9d75dd  vmovaps [rsp], xmm0
00007175dc9d75e2  vmovaps [rsp+0x10], xmm1
00007175dc9d75e8  vmovaps [rsp+0x20], xmm3
00007175dc9d75ee  vmovaps [rsp+0x30], xmm4
00007175dc9d75f4  vmovaps [rsp+0x40], xmm5
00007175dc9d75fa  vmovaps [rsp+0x50], xmm6
00007175dc9d7600  vmovaps [rsp+0x60], xmm7
00007175dc9d7606  vmovaps [rsp+0x70], xmm8
00007175dc9d760c  vmovaps [rsp+0x80], xmm9
00007175dc9d7615  vmovaps [rsp+0x90], xmm10
00007175dc9d761e  vmovaps [rsp+0xA0], xmm11
00007175dc9d7627  vmovaps [rsp+0xB0], xmm12
00007175dc9d7630  vmovaps [rsp+0xC0], xmm13
00007175dc9d7639  vmovaps [rsp+0xD0], xmm14
00007175dc9d7642  vmovaps [rsp+0xE0], xmm15
00007175dc9d764b  sub rsp, 0x40
00007175dc9d764f  lea rdi, [rsp]
00007175dc9d7653  lea rsi, [rsp+0x10]
00007175dc9d7658  lea rdx, [rsp+0x20]
00007175dc9d765d  lea rcx, [rsp+0x30]
00007175dc9d7662  mov r8d, 0x00
00007175dc9d7668  lea r9, [r15+0x3A8]
00007175dc9d766f  movaps [rdi], xmm2
00007175dc9d7672  movaps [rsi], xmm15
00007175dc9d7676  movaps [rdx], xmm12
00007175dc9d767a  movaps [rcx], xmm1
00007175dc9d767d  mov rax, 0x622B29CAFA50
00007175dc9d7687  call rax
00007175dc9d7689  movaps xmm2, [rsp]
00007175dc9d768d  add rsp, 0x40
00007175dc9d7691  vmovaps xmm0, [rsp]
00007175dc9d7696  vmovaps xmm1, [rsp+0x10]
00007175dc9d769c  vmovaps xmm3, [rsp+0x20]
00007175dc9d76a2  vmovaps xmm4, [rsp+0x30]
00007175dc9d76a8  vmovaps xmm5, [rsp+0x40]
00007175dc9d76ae  vmovaps xmm6, [rsp+0x50]
00007175dc9d76b4  vmovaps xmm7, [rsp+0x60]
00007175dc9d76ba  vmovaps xmm8, [rsp+0x70]
00007175dc9d76c0  vmovaps xmm9, [rsp+0x80]
00007175dc9d76c9  vmovaps xmm10, [rsp+0x90]
00007175dc9d76d2  vmovaps xmm11, [rsp+0xA0]
00007175dc9d76db  vmovaps xmm12, [rsp+0xB0]
00007175dc9d76e4  vmovaps xmm13, [rsp+0xC0]
00007175dc9d76ed  vmovaps xmm14, [rsp+0xD0]
00007175dc9d76f6  vmovaps xmm15, [rsp+0xE0]
00007175dc9d76ff  add rsp, 0xF0
00007175dc9d7706  pop r11
00007175dc9d7708  pop r10
00007175dc9d770a  pop r9
00007175dc9d770c  pop r8
00007175dc9d770e  pop rsi
00007175dc9d770f  pop rdi
00007175dc9d7710  pop rdx
00007175dc9d7711  pop rcx
00007175dc9d7712  pop rax
00007175dc9d7713  add rsp, 0x08
00007175dc9d7717  jmp 0x00007175DC9D66CE
00007175dc9d771c  sub rsp, 0x08
00007175dc9d7720  push rax
00007175dc9d7721  push rcx
00007175dc9d7722  push rdx
00007175dc9d7723  push rdi
00007175dc9d7724  push rsi
00007175dc9d7725  push r8
00007175dc9d7727  push r9
00007175dc9d7729  push r10
00007175dc9d772b  push r11
00007175dc9d772d  sub rsp, 0xF0
00007175dc9d7734  vmovaps [rsp], xmm0
00007175dc9d7739  vmovaps [rsp+0x10], xmm1
00007175dc9d773f  vmovaps [rsp+0x20], xmm2
00007175dc9d7745  vmovaps [rsp+0x30], xmm3
00007175dc9d774b  vmovaps [rsp+0x40], xmm4
00007175dc9d7751  vmovaps [rsp+0x50], xmm5
00007175dc9d7757  vmovaps [rsp+0x60], xmm6
00007175dc9d775d  vmovaps [rsp+0x70], xmm7
00007175dc9d7763  vmovaps [rsp+0x80], xmm8
00007175dc9d776c  vmovaps [rsp+0x90], xmm9
00007175dc9d7775  vmovaps [rsp+0xA0], xmm10
00007175dc9d777e  vmovaps [rsp+0xB0], xmm11
00007175dc9d7787  vmovaps [rsp+0xC0], xmm13
00007175dc9d7790  vmovaps [rsp+0xD0], xmm14
00007175dc9d7799  vmovaps [rsp+0xE0], xmm15
00007175dc9d77a2  sub rsp, 0x40
00007175dc9d77a6  lea rdi, [rsp]
00007175dc9d77aa  lea rsi, [rsp+0x10]
00007175dc9d77af  lea rdx, [rsp+0x20]
00007175dc9d77b4  lea rcx, [rsp+0x30]
00007175dc9d77b9  mov r8d, 0x00
00007175dc9d77bf  lea r9, [r15+0x3A8]
00007175dc9d77c6  movaps [rdi], xmm12
00007175dc9d77ca  movaps [rsi], xmm14
00007175dc9d77ce  movaps [rdx], xmm3
00007175dc9d77d1  movaps [rcx], xmm15
00007175dc9d77d5  mov rax, 0x622B29CAFA50
00007175dc9d77df  call rax
00007175dc9d77e1  movaps xmm12, [rsp]
00007175dc9d77e6  add rsp, 0x40
00007175dc9d77ea  vmovaps xmm0, [rsp]
00007175dc9d77ef  vmovaps xmm1, [rsp+0x10]
00007175dc9d77f5  vmovaps xmm2, [rsp+0x20]
00007175dc9d77fb  vmovaps xmm3, [rsp+0x30]
00007175dc9d7801  vmovaps xmm4, [rsp+0x40]
00007175dc9d7807  vmovaps xmm5, [rsp+0x50]
00007175dc9d780d  vmovaps xmm6, [rsp+0x60]
00007175dc9d7813  vmovaps xmm7, [rsp+0x70]
00007175dc9d7819  vmovaps xmm8, [rsp+0x80]
00007175dc9d7822  vmovaps xmm9, [rsp+0x90]
00007175dc9d782b  vmovaps xmm10, [rsp+0xA0]
00007175dc9d7834  vmovaps xmm11, [rsp+0xB0]
00007175dc9d783d  vmovaps xmm13, [rsp+0xC0]
00007175dc9d7846  vmovaps xmm14, [rsp+0xD0]
00007175dc9d784f  vmovaps xmm15, [rsp+0xE0]
00007175dc9d7858  add rsp, 0xF0
00007175dc9d785f  pop r11
00007175dc9d7861  pop r10
00007175dc9d7863  pop r9
00007175dc9d7865  pop r8
00007175dc9d7867  pop rsi
00007175dc9d7868  pop rdi
00007175dc9d7869  pop rdx
00007175dc9d786a  pop rcx
00007175dc9d786b  pop rax
00007175dc9d786c  add rsp, 0x08
00007175dc9d7870  jmp 0x00007175DC9D6728
00007175dc9d7875  sub rsp, 0x08
00007175dc9d7879  push rax
00007175dc9d787a  push rcx
00007175dc9d787b  push rdx
00007175dc9d787c  push rdi
00007175dc9d787d  push rsi
00007175dc9d787e  push r8
00007175dc9d7880  push r9
00007175dc9d7882  push r10
00007175dc9d7884  push r11
00007175dc9d7886  sub rsp, 0xF0
00007175dc9d788d  vmovaps [rsp], xmm0
00007175dc9d7892  vmovaps [rsp+0x10], xmm1
00007175dc9d7898  vmovaps [rsp+0x20], xmm2
00007175dc9d789e  vmovaps [rsp+0x30], xmm3
00007175dc9d78a4  vmovaps [rsp+0x40], xmm4
00007175dc9d78aa  vmovaps [rsp+0x50], xmm5
00007175dc9d78b0  vmovaps [rsp+0x60], xmm6
00007175dc9d78b6  vmovaps [rsp+0x70], xmm7
00007175dc9d78bc  vmovaps [rsp+0x80], xmm8
00007175dc9d78c5  vmovaps [rsp+0x90], xmm10
00007175dc9d78ce  vmovaps [rsp+0xA0], xmm11
00007175dc9d78d7  vmovaps [rsp+0xB0], xmm12
00007175dc9d78e0  vmovaps [rsp+0xC0], xmm13
00007175dc9d78e9  vmovaps [rsp+0xD0], xmm14
00007175dc9d78f2  vmovaps [rsp+0xE0], xmm15
00007175dc9d78fb  sub rsp, 0x40
00007175dc9d78ff  lea rdi, [rsp]
00007175dc9d7903  lea rsi, [rsp+0x10]
00007175dc9d7908  lea rdx, [rsp+0x20]
00007175dc9d790d  lea rcx, [rsp+0x30]
00007175dc9d7912  mov r8d, 0x00
00007175dc9d7918  lea r9, [r15+0x3A8]
00007175dc9d791f  movaps [rdi], xmm9
00007175dc9d7923  movaps [rsi], xmm13
00007175dc9d7927  movaps [rdx], xmm14
00007175dc9d792b  movaps [rcx], xmm6
00007175dc9d792e  mov rax, 0x622B29CAFA50
00007175dc9d7938  call rax
00007175dc9d793a  movaps xmm9, [rsp]
00007175dc9d793f  add rsp, 0x40
00007175dc9d7943  vmovaps xmm0, [rsp]
00007175dc9d7948  vmovaps xmm1, [rsp+0x10]
00007175dc9d794e  vmovaps xmm2, [rsp+0x20]
00007175dc9d7954  vmovaps xmm3, [rsp+0x30]
00007175dc9d795a  vmovaps xmm4, [rsp+0x40]
00007175dc9d7960  vmovaps xmm5, [rsp+0x50]
00007175dc9d7966  vmovaps xmm6, [rsp+0x60]
00007175dc9d796c  vmovaps xmm7, [rsp+0x70]
00007175dc9d7972  vmovaps xmm8, [rsp+0x80]
00007175dc9d797b  vmovaps xmm10, [rsp+0x90]
00007175dc9d7984  vmovaps xmm11, [rsp+0xA0]
00007175dc9d798d  vmovaps xmm12, [rsp+0xB0]
00007175dc9d7996  vmovaps xmm13, [rsp+0xC0]
00007175dc9d799f  vmovaps xmm14, [rsp+0xD0]
00007175dc9d79a8  vmovaps xmm15, [rsp+0xE0]
00007175dc9d79b1  add rsp, 0xF0
00007175dc9d79b8  pop r11
00007175dc9d79ba  pop r10
00007175dc9d79bc  pop r9
00007175dc9d79be  pop r8
00007175dc9d79c0  pop rsi
00007175dc9d79c1  pop rdi
00007175dc9d79c2  pop rdx
00007175dc9d79c3  pop rcx
00007175dc9d79c4  pop rax
00007175dc9d79c5  add rsp, 0x08
00007175dc9d79c9  jmp 0x00007175DC9D67D2
00007175dc9d79ce  sub rsp, 0x08
00007175dc9d79d2  push rax
00007175dc9d79d3  push rcx
00007175dc9d79d4  push rdx
00007175dc9d79d5  push rdi
00007175dc9d79d6  push rsi
00007175dc9d79d7  push r8
00007175dc9d79d9  push r9
00007175dc9d79db  push r10
00007175dc9d79dd  push r11
00007175dc9d79df  sub rsp, 0xF0
00007175dc9d79e6  vmovaps [rsp], xmm0
00007175dc9d79eb  vmovaps [rsp+0x10], xmm1
00007175dc9d79f1  vmovaps [rsp+0x20], xmm2
00007175dc9d79f7  vmovaps [rsp+0x30], xmm4
00007175dc9d79fd  vmovaps [rsp+0x40], xmm5
00007175dc9d7a03  vmovaps [rsp+0x50], xmm6
00007175dc9d7a09  vmovaps [rsp+0x60], xmm7
00007175dc9d7a0f  vmovaps [rsp+0x70], xmm8
00007175dc9d7a15  vmovaps [rsp+0x80], xmm9
00007175dc9d7a1e  vmovaps [rsp+0x90], xmm10
00007175dc9d7a27  vmovaps [rsp+0xA0], xmm11
00007175dc9d7a30  vmovaps [rsp+0xB0], xmm12
00007175dc9d7a39  vmovaps [rsp+0xC0], xmm13
00007175dc9d7a42  vmovaps [rsp+0xD0], xmm14
00007175dc9d7a4b  vmovaps [rsp+0xE0], xmm15
00007175dc9d7a54  sub rsp, 0x40
00007175dc9d7a58  lea rdi, [rsp]
00007175dc9d7a5c  lea rsi, [rsp+0x10]
00007175dc9d7a61  lea rdx, [rsp+0x20]
00007175dc9d7a66  lea rcx, [rsp+0x30]
00007175dc9d7a6b  mov r8d, 0x00
00007175dc9d7a71  lea r9, [r15+0x3A8]
00007175dc9d7a78  movaps [rdi], xmm3
00007175dc9d7a7b  movaps [rsi], xmm13
00007175dc9d7a7f  movaps [rdx], xmm6
00007175dc9d7a82  movaps [rcx], xmm14
00007175dc9d7a86  mov rax, 0x622B29CAFA50
00007175dc9d7a90  call rax
00007175dc9d7a92  movaps xmm3, [rsp]
00007175dc9d7a96  add rsp, 0x40
00007175dc9d7a9a  vmovaps xmm0, [rsp]
00007175dc9d7a9f  vmovaps xmm1, [rsp+0x10]
00007175dc9d7aa5  vmovaps xmm2, [rsp+0x20]
00007175dc9d7aab  vmovaps xmm4, [rsp+0x30]
00007175dc9d7ab1  vmovaps xmm5, [rsp+0x40]
00007175dc9d7ab7  vmovaps xmm6, [rsp+0x50]
00007175dc9d7abd  vmovaps xmm7, [rsp+0x60]
00007175dc9d7ac3  vmovaps xmm8, [rsp+0x70]
00007175dc9d7ac9  vmovaps xmm9, [rsp+0x80]
00007175dc9d7ad2  vmovaps xmm10, [rsp+0x90]
00007175dc9d7adb  vmovaps xmm11, [rsp+0xA0]
00007175dc9d7ae4  vmovaps xmm12, [rsp+0xB0]
00007175dc9d7aed  vmovaps xmm13, [rsp+0xC0]
00007175dc9d7af6  vmovaps xmm14, [rsp+0xD0]
00007175dc9d7aff  vmovaps xmm15, [rsp+0xE0]
00007175dc9d7b08  add rsp, 0xF0
00007175dc9d7b0f  pop r11
00007175dc9d7b11  pop r10
00007175dc9d7b13  pop r9
00007175dc9d7b15  pop r8
00007175dc9d7b17  pop rsi
00007175dc9d7b18  pop rdi
00007175dc9d7b19  pop rdx
00007175dc9d7b1a  pop rcx
00007175dc9d7b1b  pop rax
00007175dc9d7b1c  add rsp, 0x08
00007175dc9d7b20  jmp 0x00007175DC9D680F
00007175dc9d7b25  sub rsp, 0x08
00007175dc9d7b29  push rax
00007175dc9d7b2a  push rcx
00007175dc9d7b2b  push rdx
00007175dc9d7b2c  push rdi
00007175dc9d7b2d  push rsi
00007175dc9d7b2e  push r8
00007175dc9d7b30  push r9
00007175dc9d7b32  push r10
00007175dc9d7b34  push r11
00007175dc9d7b36  sub rsp, 0xF0
00007175dc9d7b3d  vmovaps [rsp], xmm0
00007175dc9d7b42  vmovaps [rsp+0x10], xmm1
00007175dc9d7b48  vmovaps [rsp+0x20], xmm2
00007175dc9d7b4e  vmovaps [rsp+0x30], xmm3
00007175dc9d7b54  vmovaps [rsp+0x40], xmm4
00007175dc9d7b5a  vmovaps [rsp+0x50], xmm5
00007175dc9d7b60  vmovaps [rsp+0x60], xmm7
00007175dc9d7b66  vmovaps [rsp+0x70], xmm8
00007175dc9d7b6c  vmovaps [rsp+0x80], xmm9
00007175dc9d7b75  vmovaps [rsp+0x90], xmm10
00007175dc9d7b7e  vmovaps [rsp+0xA0], xmm11
00007175dc9d7b87  vmovaps [rsp+0xB0], xmm12
00007175dc9d7b90  vmovaps [rsp+0xC0], xmm13
00007175dc9d7b99  vmovaps [rsp+0xD0], xmm14
00007175dc9d7ba2  vmovaps [rsp+0xE0], xmm15
00007175dc9d7bab  sub rsp, 0x40
00007175dc9d7baf  lea rdi, [rsp]
00007175dc9d7bb3  lea rsi, [rsp+0x10]
00007175dc9d7bb8  lea rdx, [rsp+0x20]
00007175dc9d7bbd  lea rcx, [rsp+0x30]
00007175dc9d7bc2  mov r8d, 0x00
00007175dc9d7bc8  lea r9, [r15+0x3A8]
00007175dc9d7bcf  movaps [rdi], xmm6
00007175dc9d7bd2  movaps [rsi], xmm2
00007175dc9d7bd5  movaps [rdx], xmm14
00007175dc9d7bd9  movaps [rcx], xmm1
00007175dc9d7bdc  mov rax, 0x622B29CAFA50
00007175dc9d7be6  call rax
00007175dc9d7be8  movaps xmm6, [rsp]
00007175dc9d7bec  add rsp, 0x40
00007175dc9d7bf0  vmovaps xmm0, [rsp]
00007175dc9d7bf5  vmovaps xmm1, [rsp+0x10]
00007175dc9d7bfb  vmovaps xmm2, [rsp+0x20]
00007175dc9d7c01  vmovaps xmm3, [rsp+0x30]
00007175dc9d7c07  vmovaps xmm4, [rsp+0x40]
00007175dc9d7c0d  vmovaps xmm5, [rsp+0x50]
00007175dc9d7c13  vmovaps xmm7, [rsp+0x60]
00007175dc9d7c19  vmovaps xmm8, [rsp+0x70]
00007175dc9d7c1f  vmovaps xmm9, [rsp+0x80]
00007175dc9d7c28  vmovaps xmm10, [rsp+0x90]
00007175dc9d7c31  vmovaps xmm11, [rsp+0xA0]
00007175dc9d7c3a  vmovaps xmm12, [rsp+0xB0]
00007175dc9d7c43  vmovaps xmm13, [rsp+0xC0]
00007175dc9d7c4c  vmovaps xmm14, [rsp+0xD0]
00007175dc9d7c55  vmovaps xmm15, [rsp+0xE0]
00007175dc9d7c5e  add rsp, 0xF0
00007175dc9d7c65  pop r11
00007175dc9d7c67  pop r10
00007175dc9d7c69  pop r9
00007175dc9d7c6b  pop r8
00007175dc9d7c6d  pop rsi
00007175dc9d7c6e  pop rdi
00007175dc9d7c6f  pop rdx
00007175dc9d7c70  pop rcx
00007175dc9d7c71  pop rax
00007175dc9d7c72  add rsp, 0x08
00007175dc9d7c76  jmp 0x00007175DC9D683C
00007175dc9d7c7b  sub rsp, 0x08
00007175dc9d7c7f  push rax
00007175dc9d7c80  push rcx
00007175dc9d7c81  push rdx
00007175dc9d7c82  push rdi
00007175dc9d7c83  push rsi
00007175dc9d7c84  push r8
00007175dc9d7c86  push r9
00007175dc9d7c88  push r10
00007175dc9d7c8a  push r11
00007175dc9d7c8c  sub rsp, 0xF0
00007175dc9d7c93  vmovaps [rsp], xmm0
00007175dc9d7c98  vmovaps [rsp+0x10], xmm1
00007175dc9d7c9e  vmovaps [rsp+0x20], xmm2
00007175dc9d7ca4  vmovaps [rsp+0x30], xmm3
00007175dc9d7caa  vmovaps [rsp+0x40], xmm4
00007175dc9d7cb0  vmovaps [rsp+0x50], xmm5
00007175dc9d7cb6  vmovaps [rsp+0x60], xmm6
00007175dc9d7cbc  vmovaps [rsp+0x70], xmm7
00007175dc9d7cc2  vmovaps [rsp+0x80], xmm8
00007175dc9d7ccb  vmovaps [rsp+0x90], xmm9
00007175dc9d7cd4  vmovaps [rsp+0xA0], xmm10
00007175dc9d7cdd  vmovaps [rsp+0xB0], xmm11
00007175dc9d7ce6  vmovaps [rsp+0xC0], xmm12
00007175dc9d7cef  vmovaps [rsp+0xD0], xmm14
00007175dc9d7cf8  vmovaps [rsp+0xE0], xmm15
00007175dc9d7d01  sub rsp, 0x40
00007175dc9d7d05  lea rdi, [rsp]
00007175dc9d7d09  lea rsi, [rsp+0x10]
00007175dc9d7d0e  lea rdx, [rsp+0x20]
00007175dc9d7d13  lea rcx, [rsp+0x30]
00007175dc9d7d18  mov r8d, 0x00
00007175dc9d7d1e  lea r9, [r15+0x3A8]
00007175dc9d7d25  movaps [rdi], xmm13
00007175dc9d7d29  movaps [rsi], xmm12
00007175dc9d7d2d  movaps [rdx], xmm14
00007175dc9d7d31  movaps [rcx], xmm1
00007175dc9d7d34  mov rax, 0x622B29CAFA50
00007175dc9d7d3e  call rax
00007175dc9d7d40  movaps xmm13, [rsp]
00007175dc9d7d45  add rsp, 0x40
00007175dc9d7d49  vmovaps xmm0, [rsp]
00007175dc9d7d4e  vmovaps xmm1, [rsp+0x10]
00007175dc9d7d54  vmovaps xmm2, [rsp+0x20]
00007175dc9d7d5a  vmovaps xmm3, [rsp+0x30]
00007175dc9d7d60  vmovaps xmm4, [rsp+0x40]
00007175dc9d7d66  vmovaps xmm5, [rsp+0x50]
00007175dc9d7d6c  vmovaps xmm6, [rsp+0x60]
00007175dc9d7d72  vmovaps xmm7, [rsp+0x70]
00007175dc9d7d78  vmovaps xmm8, [rsp+0x80]
00007175dc9d7d81  vmovaps xmm9, [rsp+0x90]
00007175dc9d7d8a  vmovaps xmm10, [rsp+0xA0]
00007175dc9d7d93  vmovaps xmm11, [rsp+0xB0]
00007175dc9d7d9c  vmovaps xmm12, [rsp+0xC0]
00007175dc9d7da5  vmovaps xmm14, [rsp+0xD0]
00007175dc9d7dae  vmovaps xmm15, [rsp+0xE0]
00007175dc9d7db7  add rsp, 0xF0
00007175dc9d7dbe  pop r11
00007175dc9d7dc0  pop r10
00007175dc9d7dc2  pop r9
00007175dc9d7dc4  pop r8
00007175dc9d7dc6  pop rsi
00007175dc9d7dc7  pop rdi
00007175dc9d7dc8  pop rdx
00007175dc9d7dc9  pop rcx
00007175dc9d7dca  pop rax
00007175dc9d7dcb  add rsp, 0x08
00007175dc9d7dcf  jmp 0x00007175DC9D686E
00007175dc9d7dd4  sub rsp, 0x08
00007175dc9d7dd8  push rax
00007175dc9d7dd9  push rcx
00007175dc9d7dda  push rdx
00007175dc9d7ddb  push rdi
00007175dc9d7ddc  push rsi
00007175dc9d7ddd  push r8
00007175dc9d7ddf  push r9
00007175dc9d7de1  push r10
00007175dc9d7de3  push r11
00007175dc9d7de5  sub rsp, 0xF0
00007175dc9d7dec  vmovaps [rsp], xmm0
00007175dc9d7df1  vmovaps [rsp+0x10], xmm1
00007175dc9d7df7  vmovaps [rsp+0x20], xmm2
00007175dc9d7dfd  vmovaps [rsp+0x30], xmm3
00007175dc9d7e03  vmovaps [rsp+0x40], xmm4
00007175dc9d7e09  vmovaps [rsp+0x50], xmm5
00007175dc9d7e0f  vmovaps [rsp+0x60], xmm6
00007175dc9d7e15  vmovaps [rsp+0x70], xmm7
00007175dc9d7e1b  vmovaps [rsp+0x80], xmm8
00007175dc9d7e24  vmovaps [rsp+0x90], xmm9
00007175dc9d7e2d  vmovaps [rsp+0xA0], xmm10
00007175dc9d7e36  vmovaps [rsp+0xB0], xmm11
00007175dc9d7e3f  vmovaps [rsp+0xC0], xmm13
00007175dc9d7e48  vmovaps [rsp+0xD0], xmm14
00007175dc9d7e51  vmovaps [rsp+0xE0], xmm15
00007175dc9d7e5a  sub rsp, 0x40
00007175dc9d7e5e  lea rdi, [rsp]
00007175dc9d7e62  lea rsi, [rsp+0x10]
00007175dc9d7e67  lea rdx, [rsp+0x20]
00007175dc9d7e6c  lea rcx, [rsp+0x30]
00007175dc9d7e71  mov r8d, 0x00
00007175dc9d7e77  lea r9, [r15+0x3A8]
00007175dc9d7e7e  movaps [rdi], xmm12
00007175dc9d7e82  movaps [rsi], xmm3
00007175dc9d7e85  movaps [rdx], xmm14
00007175dc9d7e89  movaps [rcx], xmm5
00007175dc9d7e8c  mov rax, 0x622B29CAFA50
00007175dc9d7e96  call rax
00007175dc9d7e98  movaps xmm12, [rsp]
00007175dc9d7e9d  add rsp, 0x40
00007175dc9d7ea1  vmovaps xmm0, [rsp]
00007175dc9d7ea6  vmovaps xmm1, [rsp+0x10]
00007175dc9d7eac  vmovaps xmm2, [rsp+0x20]
00007175dc9d7eb2  vmovaps xmm3, [rsp+0x30]
00007175dc9d7eb8  vmovaps xmm4, [rsp+0x40]
00007175dc9d7ebe  vmovaps xmm5, [rsp+0x50]
00007175dc9d7ec4  vmovaps xmm6, [rsp+0x60]
00007175dc9d7eca  vmovaps xmm7, [rsp+0x70]
00007175dc9d7ed0  vmovaps xmm8, [rsp+0x80]
00007175dc9d7ed9  vmovaps xmm9, [rsp+0x90]
00007175dc9d7ee2  vmovaps xmm10, [rsp+0xA0]
00007175dc9d7eeb  vmovaps xmm11, [rsp+0xB0]
00007175dc9d7ef4  vmovaps xmm13, [rsp+0xC0]
00007175dc9d7efd  vmovaps xmm14, [rsp+0xD0]
00007175dc9d7f06  vmovaps xmm15, [rsp+0xE0]
00007175dc9d7f0f  add rsp, 0xF0
00007175dc9d7f16  pop r11
00007175dc9d7f18  pop r10
00007175dc9d7f1a  pop r9
00007175dc9d7f1c  pop r8
00007175dc9d7f1e  pop rsi
00007175dc9d7f1f  pop rdi
00007175dc9d7f20  pop rdx
00007175dc9d7f21  pop rcx
00007175dc9d7f22  pop rax
00007175dc9d7f23  add rsp, 0x08
00007175dc9d7f27  jmp 0x00007175DC9D68CB
00007175dc9d7f2c  sub rsp, 0x08
00007175dc9d7f30  push rax
00007175dc9d7f31  push rcx
00007175dc9d7f32  push rdx
00007175dc9d7f33  push rdi
00007175dc9d7f34  push rsi
00007175dc9d7f35  push r8
00007175dc9d7f37  push r9
00007175dc9d7f39  push r10
00007175dc9d7f3b  push r11
00007175dc9d7f3d  sub rsp, 0xF0
00007175dc9d7f44  vmovaps [rsp], xmm0
00007175dc9d7f49  vmovaps [rsp+0x10], xmm1
00007175dc9d7f4f  vmovaps [rsp+0x20], xmm2
00007175dc9d7f55  vmovaps [rsp+0x30], xmm3
00007175dc9d7f5b  vmovaps [rsp+0x40], xmm4
00007175dc9d7f61  vmovaps [rsp+0x50], xmm5
00007175dc9d7f67  vmovaps [rsp+0x60], xmm6
00007175dc9d7f6d  vmovaps [rsp+0x70], xmm7
00007175dc9d7f73  vmovaps [rsp+0x80], xmm8
00007175dc9d7f7c  vmovaps [rsp+0x90], xmm9
00007175dc9d7f85  vmovaps [rsp+0xA0], xmm11
00007175dc9d7f8e  vmovaps [rsp+0xB0], xmm12
00007175dc9d7f97  vmovaps [rsp+0xC0], xmm13
00007175dc9d7fa0  vmovaps [rsp+0xD0], xmm14
00007175dc9d7fa9  vmovaps [rsp+0xE0], xmm15
00007175dc9d7fb2  sub rsp, 0x40
00007175dc9d7fb6  lea rdi, [rsp]
00007175dc9d7fba  lea rsi, [rsp+0x10]
00007175dc9d7fbf  lea rdx, [rsp+0x20]
00007175dc9d7fc4  lea rcx, [rsp+0x30]
00007175dc9d7fc9  mov r8d, 0x00
00007175dc9d7fcf  lea r9, [r15+0x3A8]
00007175dc9d7fd6  movaps [rdi], xmm10
00007175dc9d7fda  movaps [rsi], xmm9
00007175dc9d7fde  movaps [rdx], xmm7
00007175dc9d7fe1  movaps [rcx], xmm14
00007175dc9d7fe5  mov rax, 0x622B29CAFA50
00007175dc9d7fef  call rax
00007175dc9d7ff1  movaps xmm10, [rsp]
00007175dc9d7ff6  add rsp, 0x40
00007175dc9d7ffa  vmovaps xmm0, [rsp]
00007175dc9d7fff  vmovaps xmm1, [rsp+0x10]
00007175dc9d8005  vmovaps xmm2, [rsp+0x20]
00007175dc9d800b  vmovaps xmm3, [rsp+0x30]
00007175dc9d8011  vmovaps xmm4, [rsp+0x40]
00007175dc9d8017  vmovaps xmm5, [rsp+0x50]
00007175dc9d801d  vmovaps xmm6, [rsp+0x60]
00007175dc9d8023  vmovaps xmm7, [rsp+0x70]
00007175dc9d8029  vmovaps xmm8, [rsp+0x80]
00007175dc9d8032  vmovaps xmm9, [rsp+0x90]
00007175dc9d803b  vmovaps xmm11, [rsp+0xA0]
00007175dc9d8044  vmovaps xmm12, [rsp+0xB0]
00007175dc9d804d  vmovaps xmm13, [rsp+0xC0]
00007175dc9d8056  vmovaps xmm14, [rsp+0xD0]
00007175dc9d805f  vmovaps xmm15, [rsp+0xE0]
00007175dc9d8068  add rsp, 0xF0
00007175dc9d806f  pop r11
00007175dc9d8071  pop r10
00007175dc9d8073  pop r9
00007175dc9d8075  pop r8
00007175dc9d8077  pop rsi
00007175dc9d8078  pop rdi
00007175dc9d8079  pop rdx
00007175dc9d807a  pop rcx
00007175dc9d807b  pop rax
00007175dc9d807c  add rsp, 0x08
00007175dc9d8080  jmp 0x00007175DC9D68F1
00007175dc9d8085  call 0x00007175DC8E45A0
00007175dc9d808a  jmp 0x00007175DC9D68FE
00007175dc9d808f  sub rsp, 0x08
00007175dc9d8093  push rax
00007175dc9d8094  push rcx
00007175dc9d8095  push rdx
00007175dc9d8096  push rdi
00007175dc9d8097  push rsi
00007175dc9d8098  push r8
00007175dc9d809a  push r9
00007175dc9d809c  push r10
00007175dc9d809e  push r11
00007175dc9d80a0  sub rsp, 0xF0
00007175dc9d80a7  vmovaps [rsp], xmm0
00007175dc9d80ac  vmovaps [rsp+0x10], xmm1
00007175dc9d80b2  vmovaps [rsp+0x20], xmm2
00007175dc9d80b8  vmovaps [rsp+0x30], xmm3
00007175dc9d80be  vmovaps [rsp+0x40], xmm4
00007175dc9d80c4  vmovaps [rsp+0x50], xmm6
00007175dc9d80ca  vmovaps [rsp+0x60], xmm7
00007175dc9d80d0  vmovaps [rsp+0x70], xmm8
00007175dc9d80d6  vmovaps [rsp+0x80], xmm9
00007175dc9d80df  vmovaps [rsp+0x90], xmm10
00007175dc9d80e8  vmovaps [rsp+0xA0], xmm11
00007175dc9d80f1  vmovaps [rsp+0xB0], xmm12
00007175dc9d80fa  vmovaps [rsp+0xC0], xmm13
00007175dc9d8103  vmovaps [rsp+0xD0], xmm14
00007175dc9d810c  vmovaps [rsp+0xE0], xmm15
00007175dc9d8115  sub rsp, 0x40
00007175dc9d8119  lea rdi, [rsp]
00007175dc9d811d  lea rsi, [rsp+0x10]
00007175dc9d8122  lea rdx, [rsp+0x20]
00007175dc9d8127  lea rcx, [rsp+0x30]
00007175dc9d812c  mov r8d, 0x00
00007175dc9d8132  lea r9, [r15+0x3A8]
00007175dc9d8139  movaps [rdi], xmm5
00007175dc9d813c  movaps [rsi], xmm6
00007175dc9d813f  movaps [rdx], xmm7
00007175dc9d8142  movaps [rcx], xmm9
00007175dc9d8146  mov rax, 0x622B29CAFA50
00007175dc9d8150  call rax
00007175dc9d8152  movaps xmm5, [rsp]
00007175dc9d8156  add rsp, 0x40
00007175dc9d815a  vmovaps xmm0, [rsp]
00007175dc9d815f  vmovaps xmm1, [rsp+0x10]
00007175dc9d8165  vmovaps xmm2, [rsp+0x20]
00007175dc9d816b  vmovaps xmm3, [rsp+0x30]
00007175dc9d8171  vmovaps xmm4, [rsp+0x40]
00007175dc9d8177  vmovaps xmm6, [rsp+0x50]
00007175dc9d817d  vmovaps xmm7, [rsp+0x60]
00007175dc9d8183  vmovaps xmm8, [rsp+0x70]
00007175dc9d8189  vmovaps xmm9, [rsp+0x80]
00007175dc9d8192  vmovaps xmm10, [rsp+0x90]
00007175dc9d819b  vmovaps xmm11, [rsp+0xA0]
00007175dc9d81a4  vmovaps xmm12, [rsp+0xB0]
00007175dc9d81ad  vmovaps xmm13, [rsp+0xC0]
00007175dc9d81b6  vmovaps xmm14, [rsp+0xD0]
00007175dc9d81bf  vmovaps xmm15, [rsp+0xE0]
00007175dc9d81c8  add rsp, 0xF0
00007175dc9d81cf  pop r11
00007175dc9d81d1  pop r10
00007175dc9d81d3  pop r9
00007175dc9d81d5  pop r8
00007175dc9d81d7  pop rsi
00007175dc9d81d8  pop rdi
00007175dc9d81d9  pop rdx
00007175dc9d81da  pop rcx
00007175dc9d81db  pop rax
00007175dc9d81dc  add rsp, 0x08
00007175dc9d81e0  jmp 0x00007175DC9D6930
00007175dc9d81e5  sub rsp, 0x08
00007175dc9d81e9  push rax
00007175dc9d81ea  push rcx
00007175dc9d81eb  push rdx
00007175dc9d81ec  push rdi
00007175dc9d81ed  push rsi
00007175dc9d81ee  push r8
00007175dc9d81f0  push r9
00007175dc9d81f2  push r10
00007175dc9d81f4  push r11
00007175dc9d81f6  sub rsp, 0xF0
00007175dc9d81fd  vmovaps [rsp], xmm0
00007175dc9d8202  vmovaps [rsp+0x10], xmm1
00007175dc9d8208  vmovaps [rsp+0x20], xmm2
00007175dc9d820e  vmovaps [rsp+0x30], xmm3
00007175dc9d8214  vmovaps [rsp+0x40], xmm4
00007175dc9d821a  vmovaps [rsp+0x50], xmm5
00007175dc9d8220  vmovaps [rsp+0x60], xmm6
00007175dc9d8226  vmovaps [rsp+0x70], xmm8
00007175dc9d822c  vmovaps [rsp+0x80], xmm9
00007175dc9d8235  vmovaps [rsp+0x90], xmm10
00007175dc9d823e  vmovaps [rsp+0xA0], xmm11
00007175dc9d8247  vmovaps [rsp+0xB0], xmm12
00007175dc9d8250  vmovaps [rsp+0xC0], xmm13
00007175dc9d8259  vmovaps [rsp+0xD0], xmm14
00007175dc9d8262  vmovaps [rsp+0xE0], xmm15
00007175dc9d826b  sub rsp, 0x40
00007175dc9d826f  lea rdi, [rsp]
00007175dc9d8273  lea rsi, [rsp+0x10]
00007175dc9d8278  lea rdx, [rsp+0x20]
00007175dc9d827d  lea rcx, [rsp+0x30]
00007175dc9d8282  mov r8d, 0x00
00007175dc9d8288  lea r9, [r15+0x3A8]
00007175dc9d828f  movaps [rdi], xmm7
00007175dc9d8292  movaps [rsi], xmm13
00007175dc9d8296  movaps [rdx], xmm1
00007175dc9d8299  movaps [rcx], xmm9
00007175dc9d829d  mov rax, 0x622B29CAFA50
00007175dc9d82a7  call rax
00007175dc9d82a9  movaps xmm7, [rsp]
00007175dc9d82ad  add rsp, 0x40
00007175dc9d82b1  vmovaps xmm0, [rsp]
00007175dc9d82b6  vmovaps xmm1, [rsp+0x10]
00007175dc9d82bc  vmovaps xmm2, [rsp+0x20]
00007175dc9d82c2  vmovaps xmm3, [rsp+0x30]
00007175dc9d82c8  vmovaps xmm4, [rsp+0x40]
00007175dc9d82ce  vmovaps xmm5, [rsp+0x50]
00007175dc9d82d4  vmovaps xmm6, [rsp+0x60]
00007175dc9d82da  vmovaps xmm8, [rsp+0x70]
00007175dc9d82e0  vmovaps xmm9, [rsp+0x80]
00007175dc9d82e9  vmovaps xmm10, [rsp+0x90]
00007175dc9d82f2  vmovaps xmm11, [rsp+0xA0]
00007175dc9d82fb  vmovaps xmm12, [rsp+0xB0]
00007175dc9d8304  vmovaps xmm13, [rsp+0xC0]
00007175dc9d830d  vmovaps xmm14, [rsp+0xD0]
00007175dc9d8316  vmovaps xmm15, [rsp+0xE0]
00007175dc9d831f  add rsp, 0xF0
00007175dc9d8326  pop r11
00007175dc9d8328  pop r10
00007175dc9d832a  pop r9
00007175dc9d832c  pop r8
00007175dc9d832e  pop rsi
00007175dc9d832f  pop rdi
00007175dc9d8330  pop rdx
00007175dc9d8331  pop rcx
00007175dc9d8332  pop rax
00007175dc9d8333  add rsp, 0x08
00007175dc9d8337  jmp 0x00007175DC9D6955
00007175dc9d833c  call 0x00007175DC8E3320
00007175dc9d8341  jmp 0x00007175DC9D6978
00007175dc9d8346  call 0x00007175DC8DE950
00007175dc9d834b  jmp 0x00007175DC9D6982
00007175dc9d8350  sub rsp, 0x08
00007175dc9d8354  push rax
00007175dc9d8355  push rcx
00007175dc9d8356  push rdx
00007175dc9d8357  push rdi
00007175dc9d8358  push rsi
00007175dc9d8359  push r8
00007175dc9d835b  push r9
00007175dc9d835d  push r10
00007175dc9d835f  push r11
00007175dc9d8361  sub rsp, 0xF0
00007175dc9d8368  vmovaps [rsp], xmm0
00007175dc9d836d  vmovaps [rsp+0x10], xmm1
00007175dc9d8373  vmovaps [rsp+0x20], xmm3
00007175dc9d8379  vmovaps [rsp+0x30], xmm4
00007175dc9d837f  vmovaps [rsp+0x40], xmm5
00007175dc9d8385  vmovaps [rsp+0x50], xmm6
00007175dc9d838b  vmovaps [rsp+0x60], xmm7
00007175dc9d8391  vmovaps [rsp+0x70], xmm8
00007175dc9d8397  vmovaps [rsp+0x80], xmm9
00007175dc9d83a0  vmovaps [rsp+0x90], xmm10
00007175dc9d83a9  vmovaps [rsp+0xA0], xmm11
00007175dc9d83b2  vmovaps [rsp+0xB0], xmm12
00007175dc9d83bb  vmovaps [rsp+0xC0], xmm13
00007175dc9d83c4  vmovaps [rsp+0xD0], xmm14
00007175dc9d83cd  vmovaps [rsp+0xE0], xmm15
00007175dc9d83d6  sub rsp, 0x40
00007175dc9d83da  lea rdi, [rsp]
00007175dc9d83de  lea rsi, [rsp+0x10]
00007175dc9d83e3  lea rdx, [rsp+0x20]
00007175dc9d83e8  lea rcx, [rsp+0x30]
00007175dc9d83ed  mov r8d, 0x00
00007175dc9d83f3  lea r9, [r15+0x3A8]
00007175dc9d83fa  movaps [rdi], xmm2
00007175dc9d83fd  movaps [rsi], xmm12
00007175dc9d8401  movaps [rdx], xmm6
00007175dc9d8404  movaps [rcx], xmm3
00007175dc9d8407  mov rax, 0x622B29CAFA50
00007175dc9d8411  call rax
00007175dc9d8413  movaps xmm2, [rsp]
00007175dc9d8417  add rsp, 0x40
00007175dc9d841b  vmovaps xmm0, [rsp]
00007175dc9d8420  vmovaps xmm1, [rsp+0x10]
00007175dc9d8426  vmovaps xmm3, [rsp+0x20]
00007175dc9d842c  vmovaps xmm4, [rsp+0x30]
00007175dc9d8432  vmovaps xmm5, [rsp+0x40]
00007175dc9d8438  vmovaps xmm6, [rsp+0x50]
00007175dc9d843e  vmovaps xmm7, [rsp+0x60]
00007175dc9d8444  vmovaps xmm8, [rsp+0x70]
00007175dc9d844a  vmovaps xmm9, [rsp+0x80]
00007175dc9d8453  vmovaps xmm10, [rsp+0x90]
00007175dc9d845c  vmovaps xmm11, [rsp+0xA0]
00007175dc9d8465  vmovaps xmm12, [rsp+0xB0]
00007175dc9d846e  vmovaps xmm13, [rsp+0xC0]
00007175dc9d8477  vmovaps xmm14, [rsp+0xD0]
00007175dc9d8480  vmovaps xmm15, [rsp+0xE0]
00007175dc9d8489  add rsp, 0xF0
00007175dc9d8490  pop r11
00007175dc9d8492  pop r10
00007175dc9d8494  pop r9
00007175dc9d8496  pop r8
00007175dc9d8498  pop rsi
00007175dc9d8499  pop rdi
00007175dc9d849a  pop rdx
00007175dc9d849b  pop rcx
00007175dc9d849c  pop rax
00007175dc9d849d  add rsp, 0x08
00007175dc9d84a1  jmp 0x00007175DC9D69C8
00007175dc9d84a6  sub rsp, 0x08
00007175dc9d84aa  push rax
00007175dc9d84ab  push rcx
00007175dc9d84ac  push rdx
00007175dc9d84ad  push rdi
00007175dc9d84ae  push rsi
00007175dc9d84af  push r8
00007175dc9d84b1  push r9
00007175dc9d84b3  push r10
00007175dc9d84b5  push r11
00007175dc9d84b7  sub rsp, 0xF0
00007175dc9d84be  vmovaps [rsp], xmm0
00007175dc9d84c3  vmovaps [rsp+0x10], xmm1
00007175dc9d84c9  vmovaps [rsp+0x20], xmm2
00007175dc9d84cf  vmovaps [rsp+0x30], xmm3
00007175dc9d84d5  vmovaps [rsp+0x40], xmm4
00007175dc9d84db  vmovaps [rsp+0x50], xmm5
00007175dc9d84e1  vmovaps [rsp+0x60], xmm7
00007175dc9d84e7  vmovaps [rsp+0x70], xmm8
00007175dc9d84ed  vmovaps [rsp+0x80], xmm9
00007175dc9d84f6  vmovaps [rsp+0x90], xmm10
00007175dc9d84ff  vmovaps [rsp+0xA0], xmm11
00007175dc9d8508  vmovaps [rsp+0xB0], xmm12
00007175dc9d8511  vmovaps [rsp+0xC0], xmm13
00007175dc9d851a  vmovaps [rsp+0xD0], xmm14
00007175dc9d8523  vmovaps [rsp+0xE0], xmm15
00007175dc9d852c  sub rsp, 0x40
00007175dc9d8530  lea rdi, [rsp]
00007175dc9d8534  lea rsi, [rsp+0x10]
00007175dc9d8539  lea rdx, [rsp+0x20]
00007175dc9d853e  lea rcx, [rsp+0x30]
00007175dc9d8543  mov r8d, 0x00
00007175dc9d8549  lea r9, [r15+0x3A8]
00007175dc9d8550  movaps [rdi], xmm6
00007175dc9d8553  movaps [rsi], xmm10
00007175dc9d8557  movaps [rdx], xmm12
00007175dc9d855b  movaps [rcx], xmm1
00007175dc9d855e  mov rax, 0x622B29CAFA50
00007175dc9d8568  call rax
00007175dc9d856a  movaps xmm6, [rsp]
00007175dc9d856e  add rsp, 0x40
00007175dc9d8572  vmovaps xmm0, [rsp]
00007175dc9d8577  vmovaps xmm1, [rsp+0x10]
00007175dc9d857d  vmovaps xmm2, [rsp+0x20]
00007175dc9d8583  vmovaps xmm3, [rsp+0x30]
00007175dc9d8589  vmovaps xmm4, [rsp+0x40]
00007175dc9d858f  vmovaps xmm5, [rsp+0x50]
00007175dc9d8595  vmovaps xmm7, [rsp+0x60]
00007175dc9d859b  vmovaps xmm8, [rsp+0x70]
00007175dc9d85a1  vmovaps xmm9, [rsp+0x80]
00007175dc9d85aa  vmovaps xmm10, [rsp+0x90]
00007175dc9d85b3  vmovaps xmm11, [rsp+0xA0]
00007175dc9d85bc  vmovaps xmm12, [rsp+0xB0]
00007175dc9d85c5  vmovaps xmm13, [rsp+0xC0]
00007175dc9d85ce  vmovaps xmm14, [rsp+0xD0]
00007175dc9d85d7  vmovaps xmm15, [rsp+0xE0]
00007175dc9d85e0  add rsp, 0xF0
00007175dc9d85e7  pop r11
00007175dc9d85e9  pop r10
00007175dc9d85eb  pop r9
00007175dc9d85ed  pop r8
00007175dc9d85ef  pop rsi
00007175dc9d85f0  pop rdi
00007175dc9d85f1  pop rdx
00007175dc9d85f2  pop rcx
00007175dc9d85f3  pop rax
00007175dc9d85f4  add rsp, 0x08
00007175dc9d85f8  jmp 0x00007175DC9D69F6
00007175dc9d85fd  sub rsp, 0x08
00007175dc9d8601  push rax
00007175dc9d8602  push rcx
00007175dc9d8603  push rdx
00007175dc9d8604  push rdi
00007175dc9d8605  push rsi
00007175dc9d8606  push r8
00007175dc9d8608  push r9
00007175dc9d860a  push r10
00007175dc9d860c  push r11
00007175dc9d860e  sub rsp, 0xF0
00007175dc9d8615  vmovaps [rsp], xmm0
00007175dc9d861a  vmovaps [rsp+0x10], xmm1
00007175dc9d8620  vmovaps [rsp+0x20], xmm2
00007175dc9d8626  vmovaps [rsp+0x30], xmm3
00007175dc9d862c  vmovaps [rsp+0x40], xmm4
00007175dc9d8632  vmovaps [rsp+0x50], xmm5
00007175dc9d8638  vmovaps [rsp+0x60], xmm6
00007175dc9d863e  vmovaps [rsp+0x70], xmm7
00007175dc9d8644  vmovaps [rsp+0x80], xmm8
00007175dc9d864d  vmovaps [rsp+0x90], xmm9
00007175dc9d8656  vmovaps [rsp+0xA0], xmm11
00007175dc9d865f  vmovaps [rsp+0xB0], xmm12
00007175dc9d8668  vmovaps [rsp+0xC0], xmm13
00007175dc9d8671  vmovaps [rsp+0xD0], xmm14
00007175dc9d867a  vmovaps [rsp+0xE0], xmm15
00007175dc9d8683  sub rsp, 0x40
00007175dc9d8687  lea rdi, [rsp]
00007175dc9d868b  lea rsi, [rsp+0x10]
00007175dc9d8690  lea rdx, [rsp+0x20]
00007175dc9d8695  lea rcx, [rsp+0x30]
00007175dc9d869a  mov r8d, 0x00
00007175dc9d86a0  lea r9, [r15+0x3A8]
00007175dc9d86a7  movaps [rdi], xmm10
00007175dc9d86ab  movaps [rsi], xmm5
00007175dc9d86ae  movaps [rdx], xmm12
00007175dc9d86b2  movaps [rcx], xmm1
00007175dc9d86b5  mov rax, 0x622B29CAFA50
00007175dc9d86bf  call rax
00007175dc9d86c1  movaps xmm10, [rsp]
00007175dc9d86c6  add rsp, 0x40
00007175dc9d86ca  vmovaps xmm0, [rsp]
00007175dc9d86cf  vmovaps xmm1, [rsp+0x10]
00007175dc9d86d5  vmovaps xmm2, [rsp+0x20]
00007175dc9d86db  vmovaps xmm3, [rsp+0x30]
00007175dc9d86e1  vmovaps xmm4, [rsp+0x40]
00007175dc9d86e7  vmovaps xmm5, [rsp+0x50]
00007175dc9d86ed  vmovaps xmm6, [rsp+0x60]
00007175dc9d86f3  vmovaps xmm7, [rsp+0x70]
00007175dc9d86f9  vmovaps xmm8, [rsp+0x80]
00007175dc9d8702  vmovaps xmm9, [rsp+0x90]
00007175dc9d870b  vmovaps xmm11, [rsp+0xA0]
00007175dc9d8714  vmovaps xmm12, [rsp+0xB0]
00007175dc9d871d  vmovaps xmm13, [rsp+0xC0]
00007175dc9d8726  vmovaps xmm14, [rsp+0xD0]
00007175dc9d872f  vmovaps xmm15, [rsp+0xE0]
00007175dc9d8738  add rsp, 0xF0
00007175dc9d873f  pop r11
00007175dc9d8741  pop r10
00007175dc9d8743  pop r9
00007175dc9d8745  pop r8
00007175dc9d8747  pop rsi
00007175dc9d8748  pop rdi
00007175dc9d8749  pop rdx
00007175dc9d874a  pop rcx
00007175dc9d874b  pop rax
00007175dc9d874c  add rsp, 0x08
00007175dc9d8750  jmp 0x00007175DC9D6A25
00007175dc9d8755  sub rsp, 0x08
00007175dc9d8759  push rax
00007175dc9d875a  push rcx
00007175dc9d875b  push rdx
00007175dc9d875c  push rdi
00007175dc9d875d  push rsi
00007175dc9d875e  push r8
00007175dc9d8760  push r9
00007175dc9d8762  push r10
00007175dc9d8764  push r11
00007175dc9d8766  sub rsp, 0xF0
00007175dc9d876d  vmovaps [rsp], xmm0
00007175dc9d8772  vmovaps [rsp+0x10], xmm1
00007175dc9d8778  vmovaps [rsp+0x20], xmm2
00007175dc9d877e  vmovaps [rsp+0x30], xmm3
00007175dc9d8784  vmovaps [rsp+0x40], xmm4
00007175dc9d878a  vmovaps [rsp+0x50], xmm5
00007175dc9d8790  vmovaps [rsp+0x60], xmm6
00007175dc9d8796  vmovaps [rsp+0x70], xmm7
00007175dc9d879c  vmovaps [rsp+0x80], xmm8
00007175dc9d87a5  vmovaps [rsp+0x90], xmm9
00007175dc9d87ae  vmovaps [rsp+0xA0], xmm10
00007175dc9d87b7  vmovaps [rsp+0xB0], xmm11
00007175dc9d87c0  vmovaps [rsp+0xC0], xmm13
00007175dc9d87c9  vmovaps [rsp+0xD0], xmm14
00007175dc9d87d2  vmovaps [rsp+0xE0], xmm15
00007175dc9d87db  sub rsp, 0x40
00007175dc9d87df  lea rdi, [rsp]
00007175dc9d87e3  lea rsi, [rsp+0x10]
00007175dc9d87e8  lea rdx, [rsp+0x20]
00007175dc9d87ed  lea rcx, [rsp+0x30]
00007175dc9d87f2  mov r8d, 0x00
00007175dc9d87f8  lea r9, [r15+0x3A8]
00007175dc9d87ff  movaps [rdi], xmm12
00007175dc9d8803  movaps [rsi], xmm7
00007175dc9d8806  movaps [rdx], xmm15
00007175dc9d880a  movaps [rcx], xmm1
00007175dc9d880d  mov rax, 0x622B29CAFA50
00007175dc9d8817  call rax
00007175dc9d8819  movaps xmm12, [rsp]
00007175dc9d881e  add rsp, 0x40
00007175dc9d8822  vmovaps xmm0, [rsp]
00007175dc9d8827  vmovaps xmm1, [rsp+0x10]
00007175dc9d882d  vmovaps xmm2, [rsp+0x20]
00007175dc9d8833  vmovaps xmm3, [rsp+0x30]
00007175dc9d8839  vmovaps xmm4, [rsp+0x40]
00007175dc9d883f  vmovaps xmm5, [rsp+0x50]
00007175dc9d8845  vmovaps xmm6, [rsp+0x60]
00007175dc9d884b  vmovaps xmm7, [rsp+0x70]
00007175dc9d8851  vmovaps xmm8, [rsp+0x80]
00007175dc9d885a  vmovaps xmm9, [rsp+0x90]
00007175dc9d8863  vmovaps xmm10, [rsp+0xA0]
00007175dc9d886c  vmovaps xmm11, [rsp+0xB0]
00007175dc9d8875  vmovaps xmm13, [rsp+0xC0]
00007175dc9d887e  vmovaps xmm14, [rsp+0xD0]
00007175dc9d8887  vmovaps xmm15, [rsp+0xE0]
00007175dc9d8890  add rsp, 0xF0
00007175dc9d8897  pop r11
00007175dc9d8899  pop r10
00007175dc9d889b  pop r9
00007175dc9d889d  pop r8
00007175dc9d889f  pop rsi
00007175dc9d88a0  pop rdi
00007175dc9d88a1  pop rdx
00007175dc9d88a2  pop rcx
00007175dc9d88a3  pop rax
00007175dc9d88a4  add rsp, 0x08
00007175dc9d88a8  jmp 0x00007175DC9D6A4E
00007175dc9d88ad  call 0x00007175DC8D64F0
00007175dc9d88b2  jmp 0x00007175DC9D6A58
00007175dc9d88b7  call 0x00007175DC8E5820
00007175dc9d88bc  jmp 0x00007175DC9D6A62
00007175dc9d88c1  sub rsp, 0x08
00007175dc9d88c5  push rax
00007175dc9d88c6  push rcx
00007175dc9d88c7  push rdx
00007175dc9d88c8  push rdi
00007175dc9d88c9  push rsi
00007175dc9d88ca  push r8
00007175dc9d88cc  push r9
00007175dc9d88ce  push r10
00007175dc9d88d0  push r11
00007175dc9d88d2  sub rsp, 0xF0
00007175dc9d88d9  vmovaps [rsp], xmm0
00007175dc9d88de  vmovaps [rsp+0x10], xmm1
00007175dc9d88e4  vmovaps [rsp+0x20], xmm2
00007175dc9d88ea  vmovaps [rsp+0x30], xmm3
00007175dc9d88f0  vmovaps [rsp+0x40], xmm4
00007175dc9d88f6  vmovaps [rsp+0x50], xmm5
00007175dc9d88fc  vmovaps [rsp+0x60], xmm6
00007175dc9d8902  vmovaps [rsp+0x70], xmm8
00007175dc9d8908  vmovaps [rsp+0x80], xmm9
00007175dc9d8911  vmovaps [rsp+0x90], xmm10
00007175dc9d891a  vmovaps [rsp+0xA0], xmm11
00007175dc9d8923  vmovaps [rsp+0xB0], xmm12
00007175dc9d892c  vmovaps [rsp+0xC0], xmm13
00007175dc9d8935  vmovaps [rsp+0xD0], xmm14
00007175dc9d893e  vmovaps [rsp+0xE0], xmm15
00007175dc9d8947  sub rsp, 0x40
00007175dc9d894b  lea rdi, [rsp]
00007175dc9d894f  lea rsi, [rsp+0x10]
00007175dc9d8954  lea rdx, [rsp+0x20]
00007175dc9d8959  lea rcx, [rsp+0x30]
00007175dc9d895e  mov r8d, 0x00
00007175dc9d8964  lea r9, [r15+0x3A8]
00007175dc9d896b  movaps [rdi], xmm7
00007175dc9d896e  movaps [rsi], xmm2
00007175dc9d8971  movaps [rdx], xmm9
00007175dc9d8975  movaps [rcx], xmm11
00007175dc9d8979  mov rax, 0x622B29CAFA50
00007175dc9d8983  call rax
00007175dc9d8985  movaps xmm7, [rsp]
00007175dc9d8989  add rsp, 0x40
00007175dc9d898d  vmovaps xmm0, [rsp]
00007175dc9d8992  vmovaps xmm1, [rsp+0x10]
00007175dc9d8998  vmovaps xmm2, [rsp+0x20]
00007175dc9d899e  vmovaps xmm3, [rsp+0x30]
00007175dc9d89a4  vmovaps xmm4, [rsp+0x40]
00007175dc9d89aa  vmovaps xmm5, [rsp+0x50]
00007175dc9d89b0  vmovaps xmm6, [rsp+0x60]
00007175dc9d89b6  vmovaps xmm8, [rsp+0x70]
00007175dc9d89bc  vmovaps xmm9, [rsp+0x80]
00007175dc9d89c5  vmovaps xmm10, [rsp+0x90]
00007175dc9d89ce  vmovaps xmm11, [rsp+0xA0]
00007175dc9d89d7  vmovaps xmm12, [rsp+0xB0]
00007175dc9d89e0  vmovaps xmm13, [rsp+0xC0]
00007175dc9d89e9  vmovaps xmm14, [rsp+0xD0]
00007175dc9d89f2  vmovaps xmm15, [rsp+0xE0]
00007175dc9d89fb  add rsp, 0xF0
00007175dc9d8a02  pop r11
00007175dc9d8a04  pop r10
00007175dc9d8a06  pop r9
00007175dc9d8a08  pop r8
00007175dc9d8a0a  pop rsi
00007175dc9d8a0b  pop rdi
00007175dc9d8a0c  pop rdx
00007175dc9d8a0d  pop rcx
00007175dc9d8a0e  pop rax
00007175dc9d8a0f  add rsp, 0x08
00007175dc9d8a13  jmp 0x00007175DC9D6A96
00007175dc9d8a18  sub rsp, 0x08
00007175dc9d8a1c  push rax
00007175dc9d8a1d  push rcx
00007175dc9d8a1e  push rdx
00007175dc9d8a1f  push rdi
00007175dc9d8a20  push rsi
00007175dc9d8a21  push r8
00007175dc9d8a23  push r9
00007175dc9d8a25  push r10
00007175dc9d8a27  push r11
00007175dc9d8a29  sub rsp, 0xF0
00007175dc9d8a30  vmovaps [rsp], xmm0
00007175dc9d8a35  vmovaps [rsp+0x10], xmm1
00007175dc9d8a3b  vmovaps [rsp+0x20], xmm2
00007175dc9d8a41  vmovaps [rsp+0x30], xmm3
00007175dc9d8a47  vmovaps [rsp+0x40], xmm4
00007175dc9d8a4d  vmovaps [rsp+0x50], xmm5
00007175dc9d8a53  vmovaps [rsp+0x60], xmm6
00007175dc9d8a59  vmovaps [rsp+0x70], xmm7
00007175dc9d8a5f  vmovaps [rsp+0x80], xmm8
00007175dc9d8a68  vmovaps [rsp+0x90], xmm10
00007175dc9d8a71  vmovaps [rsp+0xA0], xmm11
00007175dc9d8a7a  vmovaps [rsp+0xB0], xmm12
00007175dc9d8a83  vmovaps [rsp+0xC0], xmm13
00007175dc9d8a8c  vmovaps [rsp+0xD0], xmm14
00007175dc9d8a95  vmovaps [rsp+0xE0], xmm15
00007175dc9d8a9e  sub rsp, 0x40
00007175dc9d8aa2  lea rdi, [rsp]
00007175dc9d8aa6  lea rsi, [rsp+0x10]
00007175dc9d8aab  lea rdx, [rsp+0x20]
00007175dc9d8ab0  lea rcx, [rsp+0x30]
00007175dc9d8ab5  mov r8d, 0x00
00007175dc9d8abb  lea r9, [r15+0x3A8]
00007175dc9d8ac2  movaps [rdi], xmm9
00007175dc9d8ac6  movaps [rsi], xmm6
00007175dc9d8ac9  movaps [rdx], xmm1
00007175dc9d8acc  movaps [rcx], xmm11
00007175dc9d8ad0  mov rax, 0x622B29CAFA50
00007175dc9d8ada  call rax
00007175dc9d8adc  movaps xmm9, [rsp]
00007175dc9d8ae1  add rsp, 0x40
00007175dc9d8ae5  vmovaps xmm0, [rsp]
00007175dc9d8aea  vmovaps xmm1, [rsp+0x10]
00007175dc9d8af0  vmovaps xmm2, [rsp+0x20]
00007175dc9d8af6  vmovaps xmm3, [rsp+0x30]
00007175dc9d8afc  vmovaps xmm4, [rsp+0x40]
00007175dc9d8b02  vmovaps xmm5, [rsp+0x50]
00007175dc9d8b08  vmovaps xmm6, [rsp+0x60]
00007175dc9d8b0e  vmovaps xmm7, [rsp+0x70]
00007175dc9d8b14  vmovaps xmm8, [rsp+0x80]
00007175dc9d8b1d  vmovaps xmm10, [rsp+0x90]
00007175dc9d8b26  vmovaps xmm11, [rsp+0xA0]
00007175dc9d8b2f  vmovaps xmm12, [rsp+0xB0]
00007175dc9d8b38  vmovaps xmm13, [rsp+0xC0]
00007175dc9d8b41  vmovaps xmm14, [rsp+0xD0]
00007175dc9d8b4a  vmovaps xmm15, [rsp+0xE0]
00007175dc9d8b53  add rsp, 0xF0
00007175dc9d8b5a  pop r11
00007175dc9d8b5c  pop r10
00007175dc9d8b5e  pop r9
00007175dc9d8b60  pop r8
00007175dc9d8b62  pop rsi
00007175dc9d8b63  pop rdi
00007175dc9d8b64  pop rdx
00007175dc9d8b65  pop rcx
00007175dc9d8b66  pop rax
00007175dc9d8b67  add rsp, 0x08
00007175dc9d8b6b  jmp 0x00007175DC9D6ABC
00007175dc9d8b70  sub rsp, 0x08
00007175dc9d8b74  push rax
00007175dc9d8b75  push rcx
00007175dc9d8b76  push rdx
00007175dc9d8b77  push rdi
00007175dc9d8b78  push rsi
00007175dc9d8b79  push r8
00007175dc9d8b7b  push r9
00007175dc9d8b7d  push r10
00007175dc9d8b7f  push r11
00007175dc9d8b81  sub rsp, 0xF0
00007175dc9d8b88  vmovaps [rsp], xmm0
00007175dc9d8b8d  vmovaps [rsp+0x10], xmm1
00007175dc9d8b93  vmovaps [rsp+0x20], xmm2
00007175dc9d8b99  vmovaps [rsp+0x30], xmm3
00007175dc9d8b9f  vmovaps [rsp+0x40], xmm4
00007175dc9d8ba5  vmovaps [rsp+0x50], xmm5
00007175dc9d8bab  vmovaps [rsp+0x60], xmm6
00007175dc9d8bb1  vmovaps [rsp+0x70], xmm7
00007175dc9d8bb7  vmovaps [rsp+0x80], xmm8
00007175dc9d8bc0  vmovaps [rsp+0x90], xmm9
00007175dc9d8bc9  vmovaps [rsp+0xA0], xmm10
00007175dc9d8bd2  vmovaps [rsp+0xB0], xmm12
00007175dc9d8bdb  vmovaps [rsp+0xC0], xmm13
00007175dc9d8be4  vmovaps [rsp+0xD0], xmm14
00007175dc9d8bed  vmovaps [rsp+0xE0], xmm15
00007175dc9d8bf6  sub rsp, 0x40
00007175dc9d8bfa  lea rdi, [rsp]
00007175dc9d8bfe  lea rsi, [rsp+0x10]
00007175dc9d8c03  lea rdx, [rsp+0x20]
00007175dc9d8c08  lea rcx, [rsp+0x30]
00007175dc9d8c0d  mov r8d, 0x00
00007175dc9d8c13  lea r9, [r15+0x3A8]
00007175dc9d8c1a  movaps [rdi], xmm11
00007175dc9d8c1e  movaps [rsi], xmm10
00007175dc9d8c22  movaps [rdx], xmm8
00007175dc9d8c26  movaps [rcx], xmm1
00007175dc9d8c29  mov rax, 0x622B29CAFA50
00007175dc9d8c33  call rax
00007175dc9d8c35  movaps xmm11, [rsp]
00007175dc9d8c3a  add rsp, 0x40
00007175dc9d8c3e  vmovaps xmm0, [rsp]
00007175dc9d8c43  vmovaps xmm1, [rsp+0x10]
00007175dc9d8c49  vmovaps xmm2, [rsp+0x20]
00007175dc9d8c4f  vmovaps xmm3, [rsp+0x30]
00007175dc9d8c55  vmovaps xmm4, [rsp+0x40]
00007175dc9d8c5b  vmovaps xmm5, [rsp+0x50]
00007175dc9d8c61  vmovaps xmm6, [rsp+0x60]
00007175dc9d8c67  vmovaps xmm7, [rsp+0x70]
00007175dc9d8c6d  vmovaps xmm8, [rsp+0x80]
00007175dc9d8c76  vmovaps xmm9, [rsp+0x90]
00007175dc9d8c7f  vmovaps xmm10, [rsp+0xA0]
00007175dc9d8c88  vmovaps xmm12, [rsp+0xB0]
00007175dc9d8c91  vmovaps xmm13, [rsp+0xC0]
00007175dc9d8c9a  vmovaps xmm14, [rsp+0xD0]
00007175dc9d8ca3  vmovaps xmm15, [rsp+0xE0]
00007175dc9d8cac  add rsp, 0xF0
00007175dc9d8cb3  pop r11
00007175dc9d8cb5  pop r10
00007175dc9d8cb7  pop r9
00007175dc9d8cb9  pop r8
00007175dc9d8cbb  pop rsi
00007175dc9d8cbc  pop rdi
00007175dc9d8cbd  pop rdx
00007175dc9d8cbe  pop rcx
00007175dc9d8cbf  pop rax
00007175dc9d8cc0  add rsp, 0x08
00007175dc9d8cc4  jmp 0x00007175DC9D6AE2
00007175dc9d8cc9  sub rsp, 0x08
00007175dc9d8ccd  push rax
00007175dc9d8cce  push rcx
00007175dc9d8ccf  push rdx
00007175dc9d8cd0  push rdi
00007175dc9d8cd1  push rsi
00007175dc9d8cd2  push r8
00007175dc9d8cd4  push r9
00007175dc9d8cd6  push r10
00007175dc9d8cd8  push r11
00007175dc9d8cda  sub rsp, 0xF0
00007175dc9d8ce1  vmovaps [rsp], xmm0
00007175dc9d8ce6  vmovaps [rsp+0x10], xmm1
00007175dc9d8cec  vmovaps [rsp+0x20], xmm2
00007175dc9d8cf2  vmovaps [rsp+0x30], xmm3
00007175dc9d8cf8  vmovaps [rsp+0x40], xmm4
00007175dc9d8cfe  vmovaps [rsp+0x50], xmm5
00007175dc9d8d04  vmovaps [rsp+0x60], xmm6
00007175dc9d8d0a  vmovaps [rsp+0x70], xmm7
00007175dc9d8d10  vmovaps [rsp+0x80], xmm8
00007175dc9d8d19  vmovaps [rsp+0x90], xmm9
00007175dc9d8d22  vmovaps [rsp+0xA0], xmm11
00007175dc9d8d2b  vmovaps [rsp+0xB0], xmm12
00007175dc9d8d34  vmovaps [rsp+0xC0], xmm13
00007175dc9d8d3d  vmovaps [rsp+0xD0], xmm14
00007175dc9d8d46  vmovaps [rsp+0xE0], xmm15
00007175dc9d8d4f  sub rsp, 0x40
00007175dc9d8d53  lea rdi, [rsp]
00007175dc9d8d57  lea rsi, [rsp+0x10]
00007175dc9d8d5c  lea rdx, [rsp+0x20]
00007175dc9d8d61  lea rcx, [rsp+0x30]
00007175dc9d8d66  mov r8d, 0x00
00007175dc9d8d6c  lea r9, [r15+0x3A8]
00007175dc9d8d73  movaps [rdi], xmm10
00007175dc9d8d77  movaps [rsi], xmm12
00007175dc9d8d7b  movaps [rdx], xmm13
00007175dc9d8d7f  movaps [rcx], xmm1
00007175dc9d8d82  mov rax, 0x622B29CAFA50
00007175dc9d8d8c  call rax
00007175dc9d8d8e  movaps xmm10, [rsp]
00007175dc9d8d93  add rsp, 0x40
00007175dc9d8d97  vmovaps xmm0, [rsp]
00007175dc9d8d9c  vmovaps xmm1, [rsp+0x10]
00007175dc9d8da2  vmovaps xmm2, [rsp+0x20]
00007175dc9d8da8  vmovaps xmm3, [rsp+0x30]
00007175dc9d8dae  vmovaps xmm4, [rsp+0x40]
00007175dc9d8db4  vmovaps xmm5, [rsp+0x50]
00007175dc9d8dba  vmovaps xmm6, [rsp+0x60]
00007175dc9d8dc0  vmovaps xmm7, [rsp+0x70]
00007175dc9d8dc6  vmovaps xmm8, [rsp+0x80]
00007175dc9d8dcf  vmovaps xmm9, [rsp+0x90]
00007175dc9d8dd8  vmovaps xmm11, [rsp+0xA0]
00007175dc9d8de1  vmovaps xmm12, [rsp+0xB0]
00007175dc9d8dea  vmovaps xmm13, [rsp+0xC0]
00007175dc9d8df3  vmovaps xmm14, [rsp+0xD0]
00007175dc9d8dfc  vmovaps xmm15, [rsp+0xE0]
00007175dc9d8e05  add rsp, 0xF0
00007175dc9d8e0c  pop r11
00007175dc9d8e0e  pop r10
00007175dc9d8e10  pop r9
00007175dc9d8e12  pop r8
00007175dc9d8e14  pop rsi
00007175dc9d8e15  pop rdi
00007175dc9d8e16  pop rdx
00007175dc9d8e17  pop rcx
00007175dc9d8e18  pop rax
00007175dc9d8e19  add rsp, 0x08
00007175dc9d8e1d  jmp 0x00007175DC9D6B08
00007175dc9d8e22  call 0x00007175DC8D64F0
00007175dc9d8e27  jmp 0x00007175DC9D6B12
00007175dc9d8e2c  call 0x00007175DC8E3320
00007175dc9d8e31  jmp 0x00007175DC9D6B1C
00007175dc9d8e36  sub rsp, 0x08
00007175dc9d8e3a  push rax
00007175dc9d8e3b  push rcx
00007175dc9d8e3c  push rdx
00007175dc9d8e3d  push rdi
00007175dc9d8e3e  push rsi
00007175dc9d8e3f  push r8
00007175dc9d8e41  push r9
00007175dc9d8e43  push r10
00007175dc9d8e45  push r11
00007175dc9d8e47  sub rsp, 0xF0
00007175dc9d8e4e  vmovaps [rsp], xmm0
00007175dc9d8e53  vmovaps [rsp+0x10], xmm1
00007175dc9d8e59  vmovaps [rsp+0x20], xmm2
00007175dc9d8e5f  vmovaps [rsp+0x30], xmm3
00007175dc9d8e65  vmovaps [rsp+0x40], xmm4
00007175dc9d8e6b  vmovaps [rsp+0x50], xmm5
00007175dc9d8e71  vmovaps [rsp+0x60], xmm6
00007175dc9d8e77  vmovaps [rsp+0x70], xmm7
00007175dc9d8e7d  vmovaps [rsp+0x80], xmm9
00007175dc9d8e86  vmovaps [rsp+0x90], xmm10
00007175dc9d8e8f  vmovaps [rsp+0xA0], xmm11
00007175dc9d8e98  vmovaps [rsp+0xB0], xmm12
00007175dc9d8ea1  vmovaps [rsp+0xC0], xmm13
00007175dc9d8eaa  vmovaps [rsp+0xD0], xmm14
00007175dc9d8eb3  vmovaps [rsp+0xE0], xmm15
00007175dc9d8ebc  sub rsp, 0x40
00007175dc9d8ec0  lea rdi, [rsp]
00007175dc9d8ec4  lea rsi, [rsp+0x10]
00007175dc9d8ec9  lea rdx, [rsp+0x20]
00007175dc9d8ece  lea rcx, [rsp+0x30]
00007175dc9d8ed3  mov r8d, 0x00
00007175dc9d8ed9  lea r9, [r15+0x3A8]
00007175dc9d8ee0  movaps [rdi], xmm8
00007175dc9d8ee4  movaps [rsi], xmm7
00007175dc9d8ee7  movaps [rdx], xmm4
00007175dc9d8eea  movaps [rcx], xmm12
00007175dc9d8eee  mov rax, 0x622B29CAFA50
00007175dc9d8ef8  call rax
00007175dc9d8efa  movaps xmm8, [rsp]
00007175dc9d8eff  add rsp, 0x40
00007175dc9d8f03  vmovaps xmm0, [rsp]
00007175dc9d8f08  vmovaps xmm1, [rsp+0x10]
00007175dc9d8f0e  vmovaps xmm2, [rsp+0x20]
00007175dc9d8f14  vmovaps xmm3, [rsp+0x30]
00007175dc9d8f1a  vmovaps xmm4, [rsp+0x40]
00007175dc9d8f20  vmovaps xmm5, [rsp+0x50]
00007175dc9d8f26  vmovaps xmm6, [rsp+0x60]
00007175dc9d8f2c  vmovaps xmm7, [rsp+0x70]
00007175dc9d8f32  vmovaps xmm9, [rsp+0x80]
00007175dc9d8f3b  vmovaps xmm10, [rsp+0x90]
00007175dc9d8f44  vmovaps xmm11, [rsp+0xA0]
00007175dc9d8f4d  vmovaps xmm12, [rsp+0xB0]
00007175dc9d8f56  vmovaps xmm13, [rsp+0xC0]
00007175dc9d8f5f  vmovaps xmm14, [rsp+0xD0]
00007175dc9d8f68  vmovaps xmm15, [rsp+0xE0]
00007175dc9d8f71  add rsp, 0xF0
00007175dc9d8f78  pop r11
00007175dc9d8f7a  pop r10
00007175dc9d8f7c  pop r9
00007175dc9d8f7e  pop r8
00007175dc9d8f80  pop rsi
00007175dc9d8f81  pop rdi
00007175dc9d8f82  pop rdx
00007175dc9d8f83  pop rcx
00007175dc9d8f84  pop rax
00007175dc9d8f85  add rsp, 0x08
00007175dc9d8f89  jmp 0x00007175DC9D6B45
00007175dc9d8f8e  sub rsp, 0x08
00007175dc9d8f92  push rax
00007175dc9d8f93  push rcx
00007175dc9d8f94  push rdx
00007175dc9d8f95  push rdi
00007175dc9d8f96  push rsi
00007175dc9d8f97  push r8
00007175dc9d8f99  push r9
00007175dc9d8f9b  push r10
00007175dc9d8f9d  push r11
00007175dc9d8f9f  sub rsp, 0xF0
00007175dc9d8fa6  vmovaps [rsp], xmm0
00007175dc9d8fab  vmovaps [rsp+0x10], xmm1
00007175dc9d8fb1  vmovaps [rsp+0x20], xmm2
00007175dc9d8fb7  vmovaps [rsp+0x30], xmm3
00007175dc9d8fbd  vmovaps [rsp+0x40], xmm4
00007175dc9d8fc3  vmovaps [rsp+0x50], xmm5
00007175dc9d8fc9  vmovaps [rsp+0x60], xmm6
00007175dc9d8fcf  vmovaps [rsp+0x70], xmm8
00007175dc9d8fd5  vmovaps [rsp+0x80], xmm9
00007175dc9d8fde  vmovaps [rsp+0x90], xmm10
00007175dc9d8fe7  vmovaps [rsp+0xA0], xmm11
00007175dc9d8ff0  vmovaps [rsp+0xB0], xmm12
00007175dc9d8ff9  vmovaps [rsp+0xC0], xmm13
00007175dc9d9002  vmovaps [rsp+0xD0], xmm14
00007175dc9d900b  vmovaps [rsp+0xE0], xmm15
00007175dc9d9014  sub rsp, 0x40
00007175dc9d9018  lea rdi, [rsp]
00007175dc9d901c  lea rsi, [rsp+0x10]
00007175dc9d9021  lea rdx, [rsp+0x20]
00007175dc9d9026  lea rcx, [rsp+0x30]
00007175dc9d902b  mov r8d, 0x00
00007175dc9d9031  lea r9, [r15+0x3A8]
00007175dc9d9038  movaps [rdi], xmm7
00007175dc9d903b  movaps [rsi], xmm9
00007175dc9d903f  movaps [rdx], xmm14
00007175dc9d9043  movaps [rcx], xmm12
00007175dc9d9047  mov rax, 0x622B29CAFA50
00007175dc9d9051  call rax
00007175dc9d9053  movaps xmm7, [rsp]
00007175dc9d9057  add rsp, 0x40
00007175dc9d905b  vmovaps xmm0, [rsp]
00007175dc9d9060  vmovaps xmm1, [rsp+0x10]
00007175dc9d9066  vmovaps xmm2, [rsp+0x20]
00007175dc9d906c  vmovaps xmm3, [rsp+0x30]
00007175dc9d9072  vmovaps xmm4, [rsp+0x40]
00007175dc9d9078  vmovaps xmm5, [rsp+0x50]
00007175dc9d907e  vmovaps xmm6, [rsp+0x60]
00007175dc9d9084  vmovaps xmm8, [rsp+0x70]
00007175dc9d908a  vmovaps xmm9, [rsp+0x80]
00007175dc9d9093  vmovaps xmm10, [rsp+0x90]
00007175dc9d909c  vmovaps xmm11, [rsp+0xA0]
00007175dc9d90a5  vmovaps xmm12, [rsp+0xB0]
00007175dc9d90ae  vmovaps xmm13, [rsp+0xC0]
00007175dc9d90b7  vmovaps xmm14, [rsp+0xD0]
00007175dc9d90c0  vmovaps xmm15, [rsp+0xE0]
00007175dc9d90c9  add rsp, 0xF0
00007175dc9d90d0  pop r11
00007175dc9d90d2  pop r10
00007175dc9d90d4  pop r9
00007175dc9d90d6  pop r8
00007175dc9d90d8  pop rsi
00007175dc9d90d9  pop rdi
00007175dc9d90da  pop rdx
00007175dc9d90db  pop rcx
00007175dc9d90dc  pop rax
00007175dc9d90dd  add rsp, 0x08
00007175dc9d90e1  jmp 0x00007175DC9D6B6D
00007175dc9d90e6  sub rsp, 0x08
00007175dc9d90ea  push rax
00007175dc9d90eb  push rcx
00007175dc9d90ec  push rdx
00007175dc9d90ed  push rdi
00007175dc9d90ee  push rsi
00007175dc9d90ef  push r8
00007175dc9d90f1  push r9
00007175dc9d90f3  push r10
00007175dc9d90f5  push r11
00007175dc9d90f7  sub rsp, 0xF0
00007175dc9d90fe  vmovaps [rsp], xmm0
00007175dc9d9103  vmovaps [rsp+0x10], xmm1
00007175dc9d9109  vmovaps [rsp+0x20], xmm2
00007175dc9d910f  vmovaps [rsp+0x30], xmm3
00007175dc9d9115  vmovaps [rsp+0x40], xmm4
00007175dc9d911b  vmovaps [rsp+0x50], xmm5
00007175dc9d9121  vmovaps [rsp+0x60], xmm6
00007175dc9d9127  vmovaps [rsp+0x70], xmm7
00007175dc9d912d  vmovaps [rsp+0x80], xmm8
00007175dc9d9136  vmovaps [rsp+0x90], xmm9
00007175dc9d913f  vmovaps [rsp+0xA0], xmm10
00007175dc9d9148  vmovaps [rsp+0xB0], xmm11
00007175dc9d9151  vmovaps [rsp+0xC0], xmm13
00007175dc9d915a  vmovaps [rsp+0xD0], xmm14
00007175dc9d9163  vmovaps [rsp+0xE0], xmm15
00007175dc9d916c  sub rsp, 0x40
00007175dc9d9170  lea rdi, [rsp]
00007175dc9d9174  lea rsi, [rsp+0x10]
00007175dc9d9179  lea rdx, [rsp+0x20]
00007175dc9d917e  lea rcx, [rsp+0x30]
00007175dc9d9183  mov r8d, 0x00
00007175dc9d9189  lea r9, [r15+0x3A8]
00007175dc9d9190  movaps [rdi], xmm12
00007175dc9d9194  movaps [rsi], xmm11
00007175dc9d9198  movaps [rdx], xmm15
00007175dc9d919c  movaps [rcx], xmm14
00007175dc9d91a0  mov rax, 0x622B29CAFA50
00007175dc9d91aa  call rax
00007175dc9d91ac  movaps xmm12, [rsp]
00007175dc9d91b1  add rsp, 0x40
00007175dc9d91b5  vmovaps xmm0, [rsp]
00007175dc9d91ba  vmovaps xmm1, [rsp+0x10]
00007175dc9d91c0  vmovaps xmm2, [rsp+0x20]
00007175dc9d91c6  vmovaps xmm3, [rsp+0x30]
00007175dc9d91cc  vmovaps xmm4, [rsp+0x40]
00007175dc9d91d2  vmovaps xmm5, [rsp+0x50]
00007175dc9d91d8  vmovaps xmm6, [rsp+0x60]
00007175dc9d91de  vmovaps xmm7, [rsp+0x70]
00007175dc9d91e4  vmovaps xmm8, [rsp+0x80]
00007175dc9d91ed  vmovaps xmm9, [rsp+0x90]
00007175dc9d91f6  vmovaps xmm10, [rsp+0xA0]
00007175dc9d91ff  vmovaps xmm11, [rsp+0xB0]
00007175dc9d9208  vmovaps xmm13, [rsp+0xC0]
00007175dc9d9211  vmovaps xmm14, [rsp+0xD0]
00007175dc9d921a  vmovaps xmm15, [rsp+0xE0]
00007175dc9d9223  add rsp, 0xF0
00007175dc9d922a  pop r11
00007175dc9d922c  pop r10
00007175dc9d922e  pop r9
00007175dc9d9230  pop r8
00007175dc9d9232  pop rsi
00007175dc9d9233  pop rdi
00007175dc9d9234  pop rdx
00007175dc9d9235  pop rcx
00007175dc9d9236  pop rax
00007175dc9d9237  add rsp, 0x08
00007175dc9d923b  jmp 0x00007175DC9D6B96
00007175dc9d9240  sub rsp, 0x08
00007175dc9d9244  push rax
00007175dc9d9245  push rcx
00007175dc9d9246  push rdx
00007175dc9d9247  push rdi
00007175dc9d9248  push rsi
00007175dc9d9249  push r8
00007175dc9d924b  push r9
00007175dc9d924d  push r10
00007175dc9d924f  push r11
00007175dc9d9251  sub rsp, 0xF0
00007175dc9d9258  vmovaps [rsp], xmm0
00007175dc9d925d  vmovaps [rsp+0x10], xmm1
00007175dc9d9263  vmovaps [rsp+0x20], xmm2
00007175dc9d9269  vmovaps [rsp+0x30], xmm3
00007175dc9d926f  vmovaps [rsp+0x40], xmm4
00007175dc9d9275  vmovaps [rsp+0x50], xmm5
00007175dc9d927b  vmovaps [rsp+0x60], xmm6
00007175dc9d9281  vmovaps [rsp+0x70], xmm7
00007175dc9d9287  vmovaps [rsp+0x80], xmm8
00007175dc9d9290  vmovaps [rsp+0x90], xmm9
00007175dc9d9299  vmovaps [rsp+0xA0], xmm10
00007175dc9d92a2  vmovaps [rsp+0xB0], xmm12
00007175dc9d92ab  vmovaps [rsp+0xC0], xmm13
00007175dc9d92b4  vmovaps [rsp+0xD0], xmm14
00007175dc9d92bd  vmovaps [rsp+0xE0], xmm15
00007175dc9d92c6  sub rsp, 0x40
00007175dc9d92ca  lea rdi, [rsp]
00007175dc9d92ce  lea rsi, [rsp+0x10]
00007175dc9d92d3  lea rdx, [rsp+0x20]
00007175dc9d92d8  lea rcx, [rsp+0x30]
00007175dc9d92dd  mov r8d, 0x00
00007175dc9d92e3  lea r9, [r15+0x3A8]
00007175dc9d92ea  movaps [rdi], xmm11
00007175dc9d92ee  movaps [rsi], xmm10
00007175dc9d92f2  movaps [rdx], xmm13
00007175dc9d92f6  movaps [rcx], xmm15
00007175dc9d92fa  mov rax, 0x622B29CAFA50
00007175dc9d9304  call rax
00007175dc9d9306  movaps xmm11, [rsp]
00007175dc9d930b  add rsp, 0x40
00007175dc9d930f  vmovaps xmm0, [rsp]
00007175dc9d9314  vmovaps xmm1, [rsp+0x10]
00007175dc9d931a  vmovaps xmm2, [rsp+0x20]
00007175dc9d9320  vmovaps xmm3, [rsp+0x30]
00007175dc9d9326  vmovaps xmm4, [rsp+0x40]
00007175dc9d932c  vmovaps xmm5, [rsp+0x50]
00007175dc9d9332  vmovaps xmm6, [rsp+0x60]
00007175dc9d9338  vmovaps xmm7, [rsp+0x70]
00007175dc9d933e  vmovaps xmm8, [rsp+0x80]
00007175dc9d9347  vmovaps xmm9, [rsp+0x90]
00007175dc9d9350  vmovaps xmm10, [rsp+0xA0]
00007175dc9d9359  vmovaps xmm12, [rsp+0xB0]
00007175dc9d9362  vmovaps xmm13, [rsp+0xC0]
00007175dc9d936b  vmovaps xmm14, [rsp+0xD0]
00007175dc9d9374  vmovaps xmm15, [rsp+0xE0]
00007175dc9d937d  add rsp, 0xF0
00007175dc9d9384  pop r11
00007175dc9d9386  pop r10
00007175dc9d9388  pop r9
00007175dc9d938a  pop r8
00007175dc9d938c  pop rsi
00007175dc9d938d  pop rdi
00007175dc9d938e  pop rdx
00007175dc9d938f  pop rcx
00007175dc9d9390  pop rax
00007175dc9d9391  add rsp, 0x08
00007175dc9d9395  jmp 0x00007175DC9D6BBF
00007175dc9d939a  call 0x00007175DC8E5820
00007175dc9d939f  jmp 0x00007175DC9D6BCC
00007175dc9d93a4  call 0x00007175DC8E45A0
00007175dc9d93a9  jmp 0x00007175DC9D6BD9
00007175dc9d93ae  sub rsp, 0x08
00007175dc9d93b2  push rax
00007175dc9d93b3  push rcx
00007175dc9d93b4  push rdx
00007175dc9d93b5  push rdi
00007175dc9d93b6  push rsi
00007175dc9d93b7  push r8
00007175dc9d93b9  push r9
00007175dc9d93bb  push r10
00007175dc9d93bd  push r11
00007175dc9d93bf  sub rsp, 0xF0
00007175dc9d93c6  vmovaps [rsp], xmm0
00007175dc9d93cb  vmovaps [rsp+0x10], xmm1
00007175dc9d93d1  vmovaps [rsp+0x20], xmm2
00007175dc9d93d7  vmovaps [rsp+0x30], xmm3
00007175dc9d93dd  vmovaps [rsp+0x40], xmm4
00007175dc9d93e3  vmovaps [rsp+0x50], xmm5
00007175dc9d93e9  vmovaps [rsp+0x60], xmm6
00007175dc9d93ef  vmovaps [rsp+0x70], xmm7
00007175dc9d93f5  vmovaps [rsp+0x80], xmm8
00007175dc9d93fe  vmovaps [rsp+0x90], xmm9
00007175dc9d9407  vmovaps [rsp+0xA0], xmm11
00007175dc9d9410  vmovaps [rsp+0xB0], xmm12
00007175dc9d9419  vmovaps [rsp+0xC0], xmm13
00007175dc9d9422  vmovaps [rsp+0xD0], xmm14
00007175dc9d942b  vmovaps [rsp+0xE0], xmm15
00007175dc9d9434  sub rsp, 0x40
00007175dc9d9438  lea rdi, [rsp]
00007175dc9d943c  lea rsi, [rsp+0x10]
00007175dc9d9441  lea rdx, [rsp+0x20]
00007175dc9d9446  lea rcx, [rsp+0x30]
00007175dc9d944b  mov r8d, 0x00
00007175dc9d9451  lea r9, [r15+0x3A8]
00007175dc9d9458  movaps [rdi], xmm10
00007175dc9d945c  movaps [rsi], xmm8
00007175dc9d9460  movaps [rdx], xmm1
00007175dc9d9463  movaps [rcx], xmm13
00007175dc9d9467  mov rax, 0x622B29CAFA50
00007175dc9d9471  call rax
00007175dc9d9473  movaps xmm10, [rsp]
00007175dc9d9478  add rsp, 0x40
00007175dc9d947c  vmovaps xmm0, [rsp]
00007175dc9d9481  vmovaps xmm1, [rsp+0x10]
00007175dc9d9487  vmovaps xmm2, [rsp+0x20]
00007175dc9d948d  vmovaps xmm3, [rsp+0x30]
00007175dc9d9493  vmovaps xmm4, [rsp+0x40]
00007175dc9d9499  vmovaps xmm5, [rsp+0x50]
00007175dc9d949f  vmovaps xmm6, [rsp+0x60]
00007175dc9d94a5  vmovaps xmm7, [rsp+0x70]
00007175dc9d94ab  vmovaps xmm8, [rsp+0x80]
00007175dc9d94b4  vmovaps xmm9, [rsp+0x90]
00007175dc9d94bd  vmovaps xmm11, [rsp+0xA0]
00007175dc9d94c6  vmovaps xmm12, [rsp+0xB0]
00007175dc9d94cf  vmovaps xmm13, [rsp+0xC0]
00007175dc9d94d8  vmovaps xmm14, [rsp+0xD0]
00007175dc9d94e1  vmovaps xmm15, [rsp+0xE0]
00007175dc9d94ea  add rsp, 0xF0
00007175dc9d94f1  pop r11
00007175dc9d94f3  pop r10
00007175dc9d94f5  pop r9
00007175dc9d94f7  pop r8
00007175dc9d94f9  pop rsi
00007175dc9d94fa  pop rdi
00007175dc9d94fb  pop rdx
00007175dc9d94fc  pop rcx
00007175dc9d94fd  pop rax
00007175dc9d94fe  add rsp, 0x08
00007175dc9d9502  jmp 0x00007175DC9D6C0F
00007175dc9d9507  call 0x00007175DC8D64F0
00007175dc9d950c  jmp 0x00007175DC9D6C21
00007175dc9d9511  sub rsp, 0x08
00007175dc9d9515  push rax
00007175dc9d9516  push rcx
00007175dc9d9517  push rdx
00007175dc9d9518  push rdi
00007175dc9d9519  push rsi
00007175dc9d951a  push r8
00007175dc9d951c  push r9
00007175dc9d951e  push r10
00007175dc9d9520  push r11
00007175dc9d9522  sub rsp, 0xF0
00007175dc9d9529  vmovaps [rsp], xmm0
00007175dc9d952e  vmovaps [rsp+0x10], xmm1
00007175dc9d9534  vmovaps [rsp+0x20], xmm2
00007175dc9d953a  vmovaps [rsp+0x30], xmm3
00007175dc9d9540  vmovaps [rsp+0x40], xmm4
00007175dc9d9546  vmovaps [rsp+0x50], xmm5
00007175dc9d954c  vmovaps [rsp+0x60], xmm6
00007175dc9d9552  vmovaps [rsp+0x70], xmm7
00007175dc9d9558  vmovaps [rsp+0x80], xmm8
00007175dc9d9561  vmovaps [rsp+0x90], xmm10
00007175dc9d956a  vmovaps [rsp+0xA0], xmm11
00007175dc9d9573  vmovaps [rsp+0xB0], xmm12
00007175dc9d957c  vmovaps [rsp+0xC0], xmm13
00007175dc9d9585  vmovaps [rsp+0xD0], xmm14
00007175dc9d958e  vmovaps [rsp+0xE0], xmm15
00007175dc9d9597  sub rsp, 0x40
00007175dc9d959b  lea rdi, [rsp]
00007175dc9d959f  lea rsi, [rsp+0x10]
00007175dc9d95a4  lea rdx, [rsp+0x20]
00007175dc9d95a9  lea rcx, [rsp+0x30]
00007175dc9d95ae  mov r8d, 0x00
00007175dc9d95b4  lea r9, [r15+0x3A8]
00007175dc9d95bb  movaps [rdi], xmm9
00007175dc9d95bf  movaps [rsi], xmm7
00007175dc9d95c2  movaps [rdx], xmm14
00007175dc9d95c6  movaps [rcx], xmm13
00007175dc9d95ca  mov rax, 0x622B29CAFA50
00007175dc9d95d4  call rax
00007175dc9d95d6  movaps xmm9, [rsp]
00007175dc9d95db  add rsp, 0x40
00007175dc9d95df  vmovaps xmm0, [rsp]
00007175dc9d95e4  vmovaps xmm1, [rsp+0x10]
00007175dc9d95ea  vmovaps xmm2, [rsp+0x20]
00007175dc9d95f0  vmovaps xmm3, [rsp+0x30]
00007175dc9d95f6  vmovaps xmm4, [rsp+0x40]
00007175dc9d95fc  vmovaps xmm5, [rsp+0x50]
00007175dc9d9602  vmovaps xmm6, [rsp+0x60]
00007175dc9d9608  vmovaps xmm7, [rsp+0x70]
00007175dc9d960e  vmovaps xmm8, [rsp+0x80]
00007175dc9d9617  vmovaps xmm10, [rsp+0x90]
00007175dc9d9620  vmovaps xmm11, [rsp+0xA0]
00007175dc9d9629  vmovaps xmm12, [rsp+0xB0]
00007175dc9d9632  vmovaps xmm13, [rsp+0xC0]
00007175dc9d963b  vmovaps xmm14, [rsp+0xD0]
00007175dc9d9644  vmovaps xmm15, [rsp+0xE0]
00007175dc9d964d  add rsp, 0xF0
00007175dc9d9654  pop r11
00007175dc9d9656  pop r10
00007175dc9d9658  pop r9
00007175dc9d965a  pop r8
00007175dc9d965c  pop rsi
00007175dc9d965d  pop rdi
00007175dc9d965e  pop rdx
00007175dc9d965f  pop rcx
00007175dc9d9660  pop rax
00007175dc9d9661  add rsp, 0x08
00007175dc9d9665  jmp 0x00007175DC9D6C4F
00007175dc9d966a  sub rsp, 0x08
00007175dc9d966e  push rax
00007175dc9d966f  push rcx
00007175dc9d9670  push rdx
00007175dc9d9671  push rdi
00007175dc9d9672  push rsi
00007175dc9d9673  push r8
00007175dc9d9675  push r9
00007175dc9d9677  push r10
00007175dc9d9679  push r11
00007175dc9d967b  sub rsp, 0xF0
00007175dc9d9682  vmovaps [rsp], xmm0
00007175dc9d9687  vmovaps [rsp+0x10], xmm1
00007175dc9d968d  vmovaps [rsp+0x20], xmm2
00007175dc9d9693  vmovaps [rsp+0x30], xmm3
00007175dc9d9699  vmovaps [rsp+0x40], xmm4
00007175dc9d969f  vmovaps [rsp+0x50], xmm5
00007175dc9d96a5  vmovaps [rsp+0x60], xmm6
00007175dc9d96ab  vmovaps [rsp+0x70], xmm7
00007175dc9d96b1  vmovaps [rsp+0x80], xmm8
00007175dc9d96ba  vmovaps [rsp+0x90], xmm9
00007175dc9d96c3  vmovaps [rsp+0xA0], xmm10
00007175dc9d96cc  vmovaps [rsp+0xB0], xmm11
00007175dc9d96d5  vmovaps [rsp+0xC0], xmm12
00007175dc9d96de  vmovaps [rsp+0xD0], xmm14
00007175dc9d96e7  vmovaps [rsp+0xE0], xmm15
00007175dc9d96f0  sub rsp, 0x40
00007175dc9d96f4  lea rdi, [rsp]
00007175dc9d96f8  lea rsi, [rsp+0x10]
00007175dc9d96fd  lea rdx, [rsp+0x20]
00007175dc9d9702  lea rcx, [rsp+0x30]
00007175dc9d9707  mov r8d, 0x00
00007175dc9d970d  lea r9, [r15+0x3A8]
00007175dc9d9714  movaps [rdi], xmm13
00007175dc9d9718  movaps [rsi], xmm12
00007175dc9d971c  movaps [rdx], xmm15
00007175dc9d9720  movaps [rcx], xmm14
00007175dc9d9724  mov rax, 0x622B29CAFA50
00007175dc9d972e  call rax
00007175dc9d9730  movaps xmm13, [rsp]
00007175dc9d9735  add rsp, 0x40
00007175dc9d9739  vmovaps xmm0, [rsp]
00007175dc9d973e  vmovaps xmm1, [rsp+0x10]
00007175dc9d9744  vmovaps xmm2, [rsp+0x20]
00007175dc9d974a  vmovaps xmm3, [rsp+0x30]
00007175dc9d9750  vmovaps xmm4, [rsp+0x40]
00007175dc9d9756  vmovaps xmm5, [rsp+0x50]
00007175dc9d975c  vmovaps xmm6, [rsp+0x60]
00007175dc9d9762  vmovaps xmm7, [rsp+0x70]
00007175dc9d9768  vmovaps xmm8, [rsp+0x80]
00007175dc9d9771  vmovaps xmm9, [rsp+0x90]
00007175dc9d977a  vmovaps xmm10, [rsp+0xA0]
00007175dc9d9783  vmovaps xmm11, [rsp+0xB0]
00007175dc9d978c  vmovaps xmm12, [rsp+0xC0]
00007175dc9d9795  vmovaps xmm14, [rsp+0xD0]
00007175dc9d979e  vmovaps xmm15, [rsp+0xE0]
00007175dc9d97a7  add rsp, 0xF0
00007175dc9d97ae  pop r11
00007175dc9d97b0  pop r10
00007175dc9d97b2  pop r9
00007175dc9d97b4  pop r8
00007175dc9d97b6  pop rsi
00007175dc9d97b7  pop rdi
00007175dc9d97b8  pop rdx
00007175dc9d97b9  pop rcx
00007175dc9d97ba  pop rax
00007175dc9d97bb  add rsp, 0x08
00007175dc9d97bf  jmp 0x00007175DC9D6C7D
00007175dc9d97c4  sub rsp, 0x08
00007175dc9d97c8  push rax
00007175dc9d97c9  push rcx
00007175dc9d97ca  push rdx
00007175dc9d97cb  push rdi
00007175dc9d97cc  push rsi
00007175dc9d97cd  push r8
00007175dc9d97cf  push r9
00007175dc9d97d1  push r10
00007175dc9d97d3  push r11
00007175dc9d97d5  sub rsp, 0xF0
00007175dc9d97dc  vmovaps [rsp], xmm0
00007175dc9d97e1  vmovaps [rsp+0x10], xmm1
00007175dc9d97e7  vmovaps [rsp+0x20], xmm2
00007175dc9d97ed  vmovaps [rsp+0x30], xmm3
00007175dc9d97f3  vmovaps [rsp+0x40], xmm4
00007175dc9d97f9  vmovaps [rsp+0x50], xmm5
00007175dc9d97ff  vmovaps [rsp+0x60], xmm6
00007175dc9d9805  vmovaps [rsp+0x70], xmm7
00007175dc9d980b  vmovaps [rsp+0x80], xmm8
00007175dc9d9814  vmovaps [rsp+0x90], xmm9
00007175dc9d981d  vmovaps [rsp+0xA0], xmm10
00007175dc9d9826  vmovaps [rsp+0xB0], xmm11
00007175dc9d982f  vmovaps [rsp+0xC0], xmm12
00007175dc9d9838  vmovaps [rsp+0xD0], xmm13
00007175dc9d9841  vmovaps [rsp+0xE0], xmm15
00007175dc9d984a  sub rsp, 0x40
00007175dc9d984e  lea rdi, [rsp]
00007175dc9d9852  lea rsi, [rsp+0x10]
00007175dc9d9857  lea rdx, [rsp+0x20]
00007175dc9d985c  lea rcx, [rsp+0x30]
00007175dc9d9861  mov r8d, 0x00
00007175dc9d9867  lea r9, [r15+0x3A8]
00007175dc9d986e  movaps [rdi], xmm14
00007175dc9d9872  movaps [rsi], xmm11
00007175dc9d9876  movaps [rdx], xmm1
00007175dc9d9879  movaps [rcx], xmm15
00007175dc9d987d  mov rax, 0x622B29CAFA50
00007175dc9d9887  call rax
00007175dc9d9889  movaps xmm14, [rsp]
00007175dc9d988e  add rsp, 0x40
00007175dc9d9892  vmovaps xmm0, [rsp]
00007175dc9d9897  vmovaps xmm1, [rsp+0x10]
00007175dc9d989d  vmovaps xmm2, [rsp+0x20]
00007175dc9d98a3  vmovaps xmm3, [rsp+0x30]
00007175dc9d98a9  vmovaps xmm4, [rsp+0x40]
00007175dc9d98af  vmovaps xmm5, [rsp+0x50]
00007175dc9d98b5  vmovaps xmm6, [rsp+0x60]
00007175dc9d98bb  vmovaps xmm7, [rsp+0x70]
00007175dc9d98c1  vmovaps xmm8, [rsp+0x80]
00007175dc9d98ca  vmovaps xmm9, [rsp+0x90]
00007175dc9d98d3  vmovaps xmm10, [rsp+0xA0]
00007175dc9d98dc  vmovaps xmm11, [rsp+0xB0]
00007175dc9d98e5  vmovaps xmm12, [rsp+0xC0]
00007175dc9d98ee  vmovaps xmm13, [rsp+0xD0]
00007175dc9d98f7  vmovaps xmm15, [rsp+0xE0]
00007175dc9d9900  add rsp, 0xF0
00007175dc9d9907  pop r11
00007175dc9d9909  pop r10
00007175dc9d990b  pop r9
00007175dc9d990d  pop r8
00007175dc9d990f  pop rsi
00007175dc9d9910  pop rdi
00007175dc9d9911  pop rdx
00007175dc9d9912  pop rcx
00007175dc9d9913  pop rax
00007175dc9d9914  add rsp, 0x08
00007175dc9d9918  jmp 0x00007175DC9D6CAB
00007175dc9d991d  call 0x00007175DC8ACF70
00007175dc9d9922  jmp 0x00007175DC9D6CB9
00007175dc9d9927  call 0x00007175DC80C380
00007175dc9d992c  jmp 0x00007175DC9D6CC3
00007175dc9d9931  call 0x00007175DC808C20
00007175dc9d9936  jmp 0x00007175DC9D6CCD
00007175dc9d993b  call 0x00007175DC80D600
00007175dc9d9940  jmp 0x00007175DC9D6CD7
00007175dc9d9945  int3
00007175dc9d9946  nop [rax+rax*1], ax
00007175dc9d994f  nop
00007175dc9d9950  mov eax, [r15+0x48]
00007175dc9d9954  lea r14d, [eax+0x01]
00007175dc9d9959  mov [rsp+0x10], r14d
00007175dc9d995e  mov r14d, r14d
00007175dc9d9961  mov [r15+0x48], r14
00007175dc9d9965  xor eax, eax
00007175dc9d9967  mov r14d, [rsp+0x10]
00007175dc9d996c  cmp r14d, 0x1F4
00007175dc9d9973  cmc
00007175dc9d9974  lahf
00007175dc9d9975  seto al
00007175dc9d9978  mov [r15+0x108], eax
00007175dc9d997f  mov eax, [r15+0x108]
00007175dc9d9986  sahf
00007175dc9d9987  jnz 0x00007175DC9D99B9
00007175dc9d9989  cmp dword ptr [r15+0x318], 0x00
00007175dc9d9991  jz 0x00007175DC9DD2E0
00007175dc9d9997  nop [rax+rax*1], ax
00007175dc9d99a0  nop [rax+rax*1], eax
00007175dc9d99a8  mov eax, 0x410670
00007175dc9d99ad  mov [r15+0x100], rax
00007175dc9d99b4  jmp 0x00007175DC7FE110
00007175dc9d99b9  cmp dword ptr [r15+0x318], 0x00
00007175dc9d99c1  jz 0x00007175DC9D99F0
00007175dc9d99c7  nop [rax+rax*1], ax
00007175dc9d99d0  nop [rax+rax*1], eax
00007175dc9d99d8  mov eax, 0x4104EC
00007175dc9d99dd  mov [r15+0x100], rax
00007175dc9d99e4  jmp 0x00007175DC7FE110
00007175dc9d99e9  int3
00007175dc9d99ea  int3
00007175dc9d99eb  nop [rax+rax*1], eax
00007175dc9d99f0  mov rax, [r15+0x40]
00007175dc9d99f4  vxorps xmm1, xmm1, xmm1
00007175dc9d99f8  vpbroadcastq xmm1, xmm1
00007175dc9d99fd  vxorps xmm15, xmm15, xmm15
00007175dc9d9a02  vpbroadcastq xmm15, xmm15
00007175dc9d9a07  lea r14, [rax+0x30]
00007175dc9d9a0b  mov r12, [r13+r14*1]
00007175dc9d9a10  lea r14, [rax+0x38]
00007175dc9d9a14  mov r11, [r13+r14*1]
00007175dc9d9a19  movq xmm14, r12
00007175dc9d9a1e  movq xmm13, r11
00007175dc9d9a23  movq xmm14, xmm14
00007175dc9d9a28  movq xmm13, xmm13
00007175dc9d9a2d  vmovaps [rsp+0x10], xmm13
00007175dc9d9a33  movq xmm13, xmm13
00007175dc9d9a38  movaps [r15+0x270], xmm13
00007175dc9d9a40  movaps xmm13, [r15+0x160]
00007175dc9d9a48  vmovaps [rsp+0x20], xmm13
00007175dc9d9a4e  vmovaps xmm12, [rsp+0x20]
00007175dc9d9a54  por xmm13, xmm12
00007175dc9d9a59  lea r14, [rax+0x20]
00007175dc9d9a5d  mov r12, [r13+r14*1]
00007175dc9d9a62  lea r14, [rax+0x28]
00007175dc9d9a66  mov r11, [r13+r14*1]
00007175dc9d9a6b  movq xmm12, r12
00007175dc9d9a70  movq xmm11, r11
00007175dc9d9a75  movq xmm12, xmm12
00007175dc9d9a7a  movq xmm11, xmm11
00007175dc9d9a7f  movaps xmm10, [r15+0x2D0]
00007175dc9d9a87  vmovaps [rsp+0x20], xmm10
00007175dc9d9a8d  vmovaps xmm9, [rsp+0x20]
00007175dc9d9a93  por xmm10, xmm9
00007175dc9d9a98  movaps xmm9, [r15+0x300]
00007175dc9d9aa0  vmovaps [rsp+0x20], xmm9
00007175dc9d9aa6  vmovaps xmm8, [rsp+0x20]
00007175dc9d9aac  por xmm9, xmm8
00007175dc9d9ab1  movaps xmm8, [r15+0x2B0]
00007175dc9d9ab9  vmovaps [rsp+0x20], xmm8
00007175dc9d9abf  vmovaps xmm7, [rsp+0x20]
00007175dc9d9ac5  por xmm8, xmm7
00007175dc9d9aca  movaps xmm7, [r15+0x180]
00007175dc9d9ad2  vmovaps [rsp+0x20], xmm7
00007175dc9d9ad8  vmovaps xmm6, [rsp+0x20]
00007175dc9d9ade  por xmm7, xmm6
00007175dc9d9ae2  lea r14, [rax+0x10]
00007175dc9d9ae6  mov r12, [r13+r14*1]
00007175dc9d9aeb  lea r14, [rax+0x18]
00007175dc9d9aef  mov r11, [r13+r14*1]
00007175dc9d9af4  movq xmm6, r12
00007175dc9d9af9  movq xmm5, r11
00007175dc9d9afe  movq xmm6, xmm6
00007175dc9d9b02  movq xmm5, xmm5
00007175dc9d9b06  movaps xmm4, [r15+0x200]
00007175dc9d9b0e  vmovaps [rsp+0x20], xmm4
00007175dc9d9b14  vmovaps xmm3, [rsp+0x20]
00007175dc9d9b1a  por xmm4, xmm3
00007175dc9d9b1e  movaps xmm3, [r15+0x1F0]
00007175dc9d9b26  vmovaps [rsp+0x20], xmm3
00007175dc9d9b2c  vmovaps xmm2, [rsp+0x20]
00007175dc9d9b32  por xmm3, xmm2
00007175dc9d9b36  movaps xmm2, [r15+0x2E0]
00007175dc9d9b3e  vmovaps [rsp+0x20], xmm2
00007175dc9d9b44  vmovaps [rsp+0x30], xmm1
00007175dc9d9b4a  vmovaps xmm1, [rsp+0x20]
00007175dc9d9b50  por xmm2, xmm1
00007175dc9d9b54  movaps xmm1, [r15+0x2A0]
00007175dc9d9b5c  vmovaps [rsp+0x20], xmm1
00007175dc9d9b62  vmovaps [rsp+0x40], xmm15
00007175dc9d9b68  vmovaps xmm15, [rsp+0x20]
00007175dc9d9b6e  por xmm1, xmm15
00007175dc9d9b73  movaps xmm15, [r15+0x280]
00007175dc9d9b7b  vmovaps [rsp+0x20], xmm15
00007175dc9d9b81  vmovaps [rsp+0x50], xmm1
00007175dc9d9b87  vmovaps xmm1, [rsp+0x20]
00007175dc9d9b8d  por xmm15, xmm1
00007175dc9d9b92  movaps xmm1, [r15+0x1C0]
00007175dc9d9b9a  vmovaps [rsp+0x20], xmm1
00007175dc9d9ba0  vmovaps [rsp+0x60], xmm15
00007175dc9d9ba6  vmovaps xmm15, [rsp+0x20]
00007175dc9d9bac  por xmm1, xmm15
00007175dc9d9bb1  movaps xmm15, [r15+0x210]
00007175dc9d9bb9  vmovaps [rsp+0x20], xmm15
00007175dc9d9bbf  vmovaps [rsp+0x70], xmm1
00007175dc9d9bc5  vmovaps xmm1, [rsp+0x20]
00007175dc9d9bcb  por xmm15, xmm1
00007175dc9d9bd0  mov r14, [r13+rax*1]
00007175dc9d9bd5  vmovq xmm1, r14
00007175dc9d9bda  vpbroadcastq xmm1, xmm1
00007175dc9d9bdf  vmovaps [rsp+0x20], xmm1
00007175dc9d9be5  vxorps xmm1, xmm1, xmm1
00007175dc9d9be9  vpbroadcastq xmm1, xmm1
00007175dc9d9bee  mov r14, [r15+0xF8]
00007175dc9d9bf5  vmovaps [rsp+0x80], xmm1
00007175dc9d9bfe  movups xmm1, [r13+r14*1]
00007175dc9d9c04  vmovaps [rsp+0x90], xmm1
00007175dc9d9c0d  vxorps xmm1, xmm1, xmm1
00007175dc9d9c11  vpbroadcastq xmm1, xmm1
00007175dc9d9c16  lea r12, [rax+0x08]
00007175dc9d9c1a  mov rax, [r13+r12*1]
00007175dc9d9c1f  vmovaps [rsp+0xA0], xmm1
00007175dc9d9c28  movq xmm1, rax
00007175dc9d9c2d  movaps [r15+0x240], xmm1
00007175dc9d9c35  mov rax, [r15+0x50]
00007175dc9d9c39  mov [r15+0x60], rax
00007175dc9d9c3d  mov qword ptr [r15+0x58], 0x40
00007175dc9d9c45  vmovaps xmm1, [rsp+0x30]
00007175dc9d9c4b  vmovaps [rsp+0x30], xmm15
00007175dc9d9c51  vmovaps xmm15, [rsp+0x90]
00007175dc9d9c5a  vmovaps [rsp+0x90], xmm14
00007175dc9d9c63  vmovaps xmm14, [rsp+0x20]
00007175dc9d9c69  vmovaps [rsp+0x20], xmm13
00007175dc9d9c6f  vmovaps [rsp+0xB0], xmm12
00007175dc9d9c78  movaps xmm13, xmm1
00007175dc9d9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d9c87  vptest xmm12, xmm12
00007175dc9d9c8c  jnz 0x00007175DC9DA72F
00007175dc9d9c92  movaps xmm1, [r15+0x250]
00007175dc9d9c9a  vmovaps xmm15, [rsp+0x40]
00007175dc9d9ca0  vmovaps [rsp+0x40], xmm13
00007175dc9d9ca6  movaps xmm12, xmm15
00007175dc9d9caa  vfmadd231pd xmm12, xmm1, xmm14
00007175dc9d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007175dc9d9cb5  vptest xmm13, xmm13
00007175dc9d9cba  jnz 0x00007175DC9DA888
00007175dc9d9cc0  movaps xmm15, [r15+0x1E0]
00007175dc9d9cc8  vmovaps [rsp+0xC0], xmm15
00007175dc9d9cd1  vmovaps xmm13, [rsp+0xC0]
00007175dc9d9cda  por xmm15, xmm13
00007175dc9d9cdf  movaps xmm13, [r15+0x1D0]
00007175dc9d9ce7  vmovaps [rsp+0xC0], xmm13
00007175dc9d9cf0  vmovaps [rsp+0xD0], xmm1
00007175dc9d9cf9  vmovaps xmm1, [rsp+0xC0]
00007175dc9d9d02  por xmm13, xmm1
00007175dc9d9d07  movaps xmm1, [r15+0x2C0]
00007175dc9d9d0f  vmovaps [rsp+0xC0], xmm1
00007175dc9d9d18  vmovaps [rsp+0xE0], xmm15
00007175dc9d9d21  vmovaps xmm15, [rsp+0xC0]
00007175dc9d9d2a  por xmm1, xmm15
00007175dc9d9d2f  movaps xmm15, [r15+0x290]
00007175dc9d9d37  vmovaps [rsp+0xC0], xmm15
00007175dc9d9d40  vmovaps [rsp+0xF0], xmm1
00007175dc9d9d49  vmovaps xmm1, [rsp+0xC0]
00007175dc9d9d52  por xmm15, xmm1
00007175dc9d9d57  movaps xmm1, [r15+0x260]
00007175dc9d9d5f  vmovaps [rsp+0xC0], xmm1
00007175dc9d9d68  vmovaps [rsp+0x100], xmm15
00007175dc9d9d71  vmovaps xmm15, [rsp+0xC0]
00007175dc9d9d7a  por xmm1, xmm15
00007175dc9d9d7f  vmovaps xmm15, [rsp+0xD0]
00007175dc9d9d88  vmovaps [rsp+0xC0], xmm1
00007175dc9d9d91  vmovaps xmm1, [rsp+0xD0]
00007175dc9d9d9a  por xmm15, xmm1
00007175dc9d9d9f  lea r12, [r14+0xC0]
00007175dc9d9da6  movups xmm1, [r13+r12*1]
00007175dc9d9dac  mov [rsp+0xD0], rax
00007175dc9d9db4  xor eax, eax
00007175dc9d9db6  mov r12d, 0x40
00007175dc9d9dbc  mov r11d, 0x200
00007175dc9d9dc2  cmp r12, r11
00007175dc9d9dc5  cmc
00007175dc9d9dc6  lahf
00007175dc9d9dc7  seto al
00007175dc9d9dca  mov [r15+0x108], eax
00007175dc9d9dd1  vmovaps [rsp+0x110], xmm1
00007175dc9d9dda  vmovaps xmm1, [rsp+0x80]
00007175dc9d9de3  vmovaps [rsp+0x80], xmm15
00007175dc9d9dec  vmovaps xmm15, [rsp+0x110]
00007175dc9d9df5  vmovaps [rsp+0x110], xmm13
00007175dc9d9dfe  vmovaps [rsp+0x120], xmm12
00007175dc9d9e07  movaps xmm13, xmm1
00007175dc9d9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d9e16  vptest xmm12, xmm12
00007175dc9d9e1b  jnz 0x00007175DC9DA9EB
00007175dc9d9e21  lea rax, [r14+0xB0]
00007175dc9d9e28  movups xmm1, [r13+rax*1]
00007175dc9d9e2e  vmovaps xmm15, [rsp+0xA0]
00007175dc9d9e37  vmovaps [rsp+0xA0], xmm13
00007175dc9d9e40  movaps xmm12, xmm15
00007175dc9d9e44  vfmadd231pd xmm12, xmm1, xmm14
00007175dc9d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007175dc9d9e4f  vptest xmm13, xmm13
00007175dc9d9e54  jnz 0x00007175DC9DAB4E
00007175dc9d9e5a  vmovaps xmm1, [rsp+0x30]
00007175dc9d9e60  vmovaps xmm15, [rsp+0x30]
00007175dc9d9e66  por xmm1, xmm15
00007175dc9d9e6b  movaps [r15+0x210], xmm1
00007175dc9d9e73  vmovaps xmm15, [rsp+0x70]
00007175dc9d9e79  vmovaps xmm14, [rsp+0x70]
00007175dc9d9e7f  por xmm15, xmm14
00007175dc9d9e84  movaps [r15+0x1C0], xmm15
00007175dc9d9e8c  vmovaps xmm14, [rsp+0x60]
00007175dc9d9e92  vmovaps xmm13, [rsp+0x60]
00007175dc9d9e98  por xmm14, xmm13
00007175dc9d9e9d  movaps [r15+0x280], xmm14
00007175dc9d9ea5  vmovaps xmm13, [rsp+0x50]
00007175dc9d9eab  vmovaps [rsp+0x30], xmm1
00007175dc9d9eb1  vmovaps xmm1, [rsp+0x50]
00007175dc9d9eb7  por xmm13, xmm1
00007175dc9d9ebc  movaps [r15+0x2A0], xmm13
00007175dc9d9ec4  vmovaps [rsp+0x50], xmm2
00007175dc9d9eca  vmovaps xmm1, [rsp+0x50]
00007175dc9d9ed0  por xmm2, xmm1
00007175dc9d9ed4  movaps [r15+0x2E0], xmm2
00007175dc9d9edc  vmovaps [rsp+0x50], xmm3
00007175dc9d9ee2  vmovaps xmm1, [rsp+0x50]
00007175dc9d9ee8  por xmm3, xmm1
00007175dc9d9eec  movaps [r15+0x1F0], xmm3
00007175dc9d9ef4  vmovaps xmm1, [rsp+0x80]
00007175dc9d9efd  vmovaps [rsp+0x50], xmm15
00007175dc9d9f03  vmovaps xmm15, [rsp+0x80]
00007175dc9d9f0c  por xmm1, xmm15
00007175dc9d9f11  movaps [r15+0x250], xmm1
00007175dc9d9f19  vmovaps xmm1, [rsp+0xC0]
00007175dc9d9f22  vmovaps xmm15, [rsp+0xC0]
00007175dc9d9f2b  por xmm1, xmm15
00007175dc9d9f30  movaps [r15+0x260], xmm1
00007175dc9d9f38  vmovaps xmm15, [rsp+0x100]
00007175dc9d9f41  vmovaps [rsp+0x60], xmm1
00007175dc9d9f47  vmovaps xmm1, [rsp+0x100]
00007175dc9d9f50  por xmm15, xmm1
00007175dc9d9f55  movaps [r15+0x290], xmm15
00007175dc9d9f5d  vmovaps xmm1, [rsp+0xF0]
00007175dc9d9f66  vmovaps [rsp+0x70], xmm15
00007175dc9d9f6c  vmovaps xmm15, [rsp+0xF0]
00007175dc9d9f75  por xmm1, xmm15
00007175dc9d9f7a  movaps [r15+0x2C0], xmm1
00007175dc9d9f82  movq xmm15, qword ptr [r15+0x240]
00007175dc9d9f8b  vmovaps [rsp+0x80], xmm15
00007175dc9d9f94  vpermilpd xmm15, xmm15, 0x00
00007175dc9d9f9a  vmovaps [rsp+0xC0], xmm1
00007175dc9d9fa3  vmovaps xmm1, [rsp+0x40]
00007175dc9d9fa9  vmovaps [rsp+0x40], xmm15
00007175dc9d9faf  vmovaps xmm15, [rsp+0x30]
00007175dc9d9fb5  vmovaps [rsp+0x30], xmm14
00007175dc9d9fbb  vmovaps xmm14, [rsp+0x40]
00007175dc9d9fc1  vmovaps [rsp+0x40], xmm13
00007175dc9d9fc7  vmovaps [rsp+0xF0], xmm12
00007175dc9d9fd0  movaps xmm13, xmm1
00007175dc9d9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007175dc9d9fdf  vptest xmm12, xmm12
00007175dc9d9fe4  jnz 0x00007175DC9DACA7
00007175dc9d9fea  vmovaps xmm1, [rsp+0x80]
00007175dc9d9ff3  vpermilpd xmm1, xmm1, 0x00
00007175dc9d9ff9  vmovaps xmm15, [rsp+0xA0]
00007175dc9da002  movaps xmm14, xmm15
00007175dc9da006  vfmadd231pd xmm14, xmm2, xmm1
00007175dc9da00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007175dc9da011  vptest xmm12, xmm12
00007175dc9da016  jnz 0x00007175DC9DAE00
00007175dc9da01c  vmovaps xmm1, [rsp+0x80]
00007175dc9da025  vpermilpd xmm1, xmm1, 0x00
00007175dc9da02b  vmovaps xmm15, [rsp+0x120]
00007175dc9da034  vmovaps xmm12, [rsp+0x50]
00007175dc9da03a  vmovaps [rsp+0x50], xmm14
00007175dc9da040  movaps xmm2, xmm15
00007175dc9da044  vfmadd231pd xmm2, xmm12, xmm1
00007175dc9da049  vcmppd xmm14, xmm2, xmm2, 0x03
00007175dc9da04e  vptest xmm14, xmm14
00007175dc9da053  jnz 0x00007175DC9DAF58
00007175dc9da059  vmovaps xmm1, [rsp+0x110]
00007175dc9da062  vmovaps xmm15, [rsp+0x110]
00007175dc9da06b  por xmm1, xmm15
00007175dc9da070  movaps [r15+0x1D0], xmm1
00007175dc9da078  vmovaps xmm15, [rsp+0x80]
00007175dc9da081  vpermilpd xmm15, xmm15, 0x00
00007175dc9da087  vmovaps xmm14, [rsp+0xF0]
00007175dc9da090  vmovaps [rsp+0x80], xmm1
00007175dc9da099  movaps xmm12, xmm14
00007175dc9da09d  vfmadd231pd xmm12, xmm3, xmm15
00007175dc9da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007175dc9da0a8  vptest xmm1, xmm1
00007175dc9da0ad  jnz 0x00007175DC9DB0AF
00007175dc9da0b3  vmovaps [rsp+0xA0], xmm4
00007175dc9da0bc  vmovaps xmm1, [rsp+0xA0]
00007175dc9da0c5  por xmm4, xmm1
00007175dc9da0c9  movaps [r15+0x200], xmm4
00007175dc9da0d1  vmovaps xmm1, [rsp+0xE0]
00007175dc9da0da  vmovaps xmm15, [rsp+0xE0]
00007175dc9da0e3  por xmm1, xmm15
00007175dc9da0e8  movaps [r15+0x1E0], xmm1
00007175dc9da0f0  vmovaps [rsp+0xA0], xmm8
00007175dc9da0f9  vmovaps xmm1, [rsp+0xA0]
00007175dc9da102  por xmm8, xmm1
00007175dc9da107  movaps [r15+0x2B0], xmm8
00007175dc9da10f  vmovaps [rsp+0xA0], xmm9
00007175dc9da118  vmovaps xmm1, [rsp+0xA0]
00007175dc9da121  por xmm9, xmm1
00007175dc9da126  movaps [r15+0x300], xmm9
00007175dc9da12e  vmovaps [rsp+0xA0], xmm6
00007175dc9da137  vpermilpd xmm6, xmm6, 0x00
00007175dc9da13d  vmovaps xmm14, [rsp+0x60]
00007175dc9da143  movaps xmm9, xmm13
00007175dc9da147  vfmadd231pd xmm9, xmm14, xmm6
00007175dc9da14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007175dc9da152  vptest xmm3, xmm3
00007175dc9da157  jnz 0x00007175DC9DB208
00007175dc9da15d  vmovaps xmm14, [rsp+0xA0]
00007175dc9da166  vpermilpd xmm14, xmm14, 0x00
00007175dc9da16c  vmovaps xmm13, [rsp+0x50]
00007175dc9da172  vmovaps xmm6, [rsp+0xC0]
00007175dc9da17b  vmovaps [rsp+0x50], xmm1
00007175dc9da181  movaps xmm3, xmm13
00007175dc9da185  vfmadd231pd xmm3, xmm6, xmm14
00007175dc9da18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007175dc9da18f  vptest xmm1, xmm1
00007175dc9da194  jnz 0x00007175DC9DB361
00007175dc9da19a  vmovaps xmm1, [rsp+0xA0]
00007175dc9da1a3  vpermilpd xmm1, xmm1, 0x00
00007175dc9da1a9  vmovaps xmm14, [rsp+0x30]
00007175dc9da1af  movaps xmm6, xmm2
00007175dc9da1b2  vfmadd231pd xmm6, xmm14, xmm1
00007175dc9da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007175dc9da1bc  vptest xmm13, xmm13
00007175dc9da1c1  jnz 0x00007175DC9DB4B8
00007175dc9da1c7  vmovaps xmm1, [rsp+0xA0]
00007175dc9da1d0  vpermilpd xmm1, xmm1, 0x00
00007175dc9da1d6  vmovaps xmm14, [rsp+0x80]
00007175dc9da1df  movaps xmm13, xmm12
00007175dc9da1e3  vfmadd231pd xmm13, xmm14, xmm1
00007175dc9da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007175dc9da1ee  vptest xmm2, xmm2
00007175dc9da1f3  jnz 0x00007175DC9DB60E
00007175dc9da1f9  vmovaps [rsp+0x30], xmm7
00007175dc9da1ff  vmovaps xmm1, [rsp+0x30]
00007175dc9da205  por xmm7, xmm1
00007175dc9da209  movaps [r15+0x180], xmm7
00007175dc9da211  vmovaps [rsp+0x30], xmm10
00007175dc9da217  vmovaps xmm1, [rsp+0x30]
00007175dc9da21d  por xmm10, xmm1
00007175dc9da222  movaps [r15+0x2D0], xmm10
00007175dc9da22a  vmovaps [rsp+0x30], xmm5
00007175dc9da230  vpermilpd xmm5, xmm5, 0x00
00007175dc9da236  vmovaps xmm14, [rsp+0x50]
00007175dc9da23c  movaps xmm12, xmm3
00007175dc9da240  vfmadd231pd xmm12, xmm14, xmm5
00007175dc9da245  vcmppd xmm10, xmm12, xmm12, 0x03
00007175dc9da24b  vptest xmm10, xmm10
00007175dc9da250  jnz 0x00007175DC9DB767
00007175dc9da256  vmovaps xmm14, [rsp+0x30]
00007175dc9da25c  vpermilpd xmm14, xmm14, 0x00
00007175dc9da262  movaps xmm10, xmm9
00007175dc9da266  vfmadd231pd xmm10, xmm7, xmm14
00007175dc9da26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007175dc9da271  vptest xmm5, xmm5
00007175dc9da276  jnz 0x00007175DC9DB8BF
00007175dc9da27c  lea rax, [r14+0x80]
00007175dc9da283  movups xmm14, [r13+rax*1]
00007175dc9da289  movaps [r15+0x2F0], xmm14
00007175dc9da291  vmovaps xmm9, [rsp+0x30]
00007175dc9da297  vpermilpd xmm9, xmm9, 0x00
00007175dc9da29d  vmovaps xmm7, [rsp+0x70]
00007175dc9da2a3  movaps xmm5, xmm6
00007175dc9da2a6  vfmadd231pd xmm5, xmm7, xmm9
00007175dc9da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007175dc9da2b0  vptest xmm3, xmm3
00007175dc9da2b5  jnz 0x00007175DC9DBA22
00007175dc9da2bb  vmovaps xmm9, [rsp+0x30]
00007175dc9da2c1  vpermilpd xmm9, xmm9, 0x00
00007175dc9da2c7  movaps xmm7, xmm13
00007175dc9da2cb  vfmadd231pd xmm7, xmm1, xmm9
00007175dc9da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007175dc9da2d5  vptest xmm6, xmm6
00007175dc9da2da  jnz 0x00007175DC9DBB78
00007175dc9da2e0  vmovaps xmm1, [rsp+0x20]
00007175dc9da2e6  vmovaps xmm13, [rsp+0x20]
00007175dc9da2ec  por xmm1, xmm13
00007175dc9da2f1  movaps [r15+0x160], xmm1
00007175dc9da2f9  lea rax, [r14+0x40]
00007175dc9da2fd  movups xmm13, [r13+rax*1]
00007175dc9da303  lea rax, [r14+0x50]
00007175dc9da307  movups xmm9, [r13+rax*1]
00007175dc9da30d  movaps [r15+0x1B0], xmm13
00007175dc9da315  movaps [r15+0x1A0], xmm9
00007175dc9da31d  movaps xmm6, [r15+0x190]
00007175dc9da325  vmovaps xmm3, [rsp+0xB0]
00007175dc9da32e  vpermilpd xmm3, xmm3, 0x00
00007175dc9da334  vmovaps [rsp+0x20], xmm1
00007175dc9da33a  movaps xmm2, xmm12
00007175dc9da33e  vfmadd231pd xmm2, xmm6, xmm3
00007175dc9da343  vcmppd xmm1, xmm2, xmm2, 0x03
00007175dc9da348  vptest xmm1, xmm1
00007175dc9da34d  jnz 0x00007175DC9DBCE3
00007175dc9da353  vmovaps xmm1, [rsp+0xB0]
00007175dc9da35c  vpermilpd xmm1, xmm1, 0x00
00007175dc9da362  vmovaps xmm12, [rsp+0x20]
00007175dc9da368  movaps xmm6, xmm10
00007175dc9da36c  vfmadd231pd xmm6, xmm12, xmm1
00007175dc9da371  vcmppd xmm3, xmm6, xmm6, 0x03
00007175dc9da376  vptest xmm3, xmm3
00007175dc9da37b  jnz 0x00007175DC9DBE39
00007175dc9da381  vmovaps xmm1, [rsp+0xB0]
00007175dc9da38a  vpermilpd xmm1, xmm1, 0x00
00007175dc9da390  vmovaps xmm12, [rsp+0x40]
00007175dc9da396  movaps xmm10, xmm5
00007175dc9da39a  vfmadd231pd xmm10, xmm12, xmm1
00007175dc9da39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007175dc9da3a5  vptest xmm3, xmm3
00007175dc9da3aa  jnz 0x00007175DC9DBF90
00007175dc9da3b0  vmovaps xmm1, [rsp+0xB0]
00007175dc9da3b9  vpermilpd xmm1, xmm1, 0x00
00007175dc9da3bf  movaps xmm12, xmm7
00007175dc9da3c3  vfmadd231pd xmm12, xmm15, xmm1
00007175dc9da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007175dc9da3ce  vptest xmm5, xmm5
00007175dc9da3d3  jnz 0x00007175DC9DC0E8
00007175dc9da3d9  lea rax, [r14+0x60]
00007175dc9da3dd  movups xmm1, [r13+rax*1]
00007175dc9da3e3  lea rax, [r14+0x70]
00007175dc9da3e7  movups xmm15, [r13+rax*1]
00007175dc9da3ed  movaps [r15+0x150], xmm1
00007175dc9da3f5  movaps [r15+0x120], xmm15
00007175dc9da3fd  vmovaps [rsp+0x20], xmm11
00007175dc9da403  vpermilpd xmm11, xmm11, 0x00
00007175dc9da409  movaps xmm7, xmm2
00007175dc9da40c  vfmadd231pd xmm7, xmm9, xmm11
00007175dc9da411  vcmppd xmm5, xmm7, xmm7, 0x03
00007175dc9da416  vptest xmm5, xmm5
00007175dc9da41b  jnz 0x00007175DC9DC254
00007175dc9da421  vmovaps xmm11, [rsp+0x20]
00007175dc9da427  vpermilpd xmm11, xmm11, 0x00
00007175dc9da42d  movaps xmm9, xmm6
00007175dc9da431  vfmadd231pd xmm9, xmm1, xmm11
00007175dc9da436  vcmppd xmm5, xmm9, xmm9, 0x03
00007175dc9da43c  vptest xmm5, xmm5
00007175dc9da441  jnz 0x00007175DC9DC3AB
00007175dc9da447  vmovaps xmm1, [rsp+0x20]
00007175dc9da44d  vpermilpd xmm1, xmm1, 0x00
00007175dc9da453  movaps xmm11, xmm10
00007175dc9da457  vfmadd231pd xmm11, xmm8, xmm1
00007175dc9da45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007175dc9da462  vptest xmm6, xmm6
00007175dc9da467  jnz 0x00007175DC9DC503
00007175dc9da46d  vmovaps xmm1, [rsp+0x20]
00007175dc9da473  vpermilpd xmm1, xmm1, 0x00
00007175dc9da479  movaps xmm10, xmm12
00007175dc9da47d  vfmadd231pd xmm10, xmm13, xmm1
00007175dc9da482  vcmppd xmm8, xmm10, xmm10, 0x03
00007175dc9da488  vptest xmm8, xmm8
00007175dc9da48d  jnz 0x00007175DC9DC65C
00007175dc9da493  lea rax, [r14+0x20]
00007175dc9da497  movups xmm1, [r13+rax*1]
00007175dc9da49d  lea rax, [r14+0x30]
00007175dc9da4a1  movups xmm13, [r13+rax*1]
00007175dc9da4a7  vmovaps xmm12, [rsp+0x90]
00007175dc9da4b0  vpermilpd xmm12, xmm12, 0x00
00007175dc9da4b6  movaps xmm8, xmm7
00007175dc9da4ba  vfmadd231pd xmm8, xmm4, xmm12
00007175dc9da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007175dc9da4c5  vptest xmm6, xmm6
00007175dc9da4ca  jnz 0x00007175DC9DC7C9
00007175dc9da4d0  vmovaps xmm12, [rsp+0x90]
00007175dc9da4d9  vpermilpd xmm12, xmm12, 0x00
00007175dc9da4df  movaps xmm7, xmm9
00007175dc9da4e3  vfmadd231pd xmm7, xmm14, xmm12
00007175dc9da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007175dc9da4ed  vptest xmm6, xmm6
00007175dc9da4f2  jnz 0x00007175DC9DC921
00007175dc9da4f8  vmovaps xmm14, [rsp+0x90]
00007175dc9da501  vpermilpd xmm14, xmm14, 0x00
00007175dc9da507  movaps xmm12, xmm11
00007175dc9da50b  vfmadd231pd xmm12, xmm15, xmm14
00007175dc9da510  vcmppd xmm9, xmm12, xmm12, 0x03
00007175dc9da516  vptest xmm9, xmm9
00007175dc9da51b  jnz 0x00007175DC9DCA79
00007175dc9da521  vmovaps xmm15, [rsp+0x90]
00007175dc9da52a  vpermilpd xmm15, xmm15, 0x00
00007175dc9da530  movaps xmm11, xmm10
00007175dc9da534  vfmadd231pd xmm11, xmm13, xmm15
00007175dc9da539  vcmppd xmm14, xmm11, xmm11, 0x03
00007175dc9da53f  vptest xmm14, xmm14
00007175dc9da544  jnz 0x00007175DC9DCBD3
00007175dc9da54a  lea rax, [r14+0x90]
00007175dc9da551  movups xmm15, [r13+rax*1]
00007175dc9da557  lea rax, [r14+0xA0]
00007175dc9da55e  movups xmm14, [r13+rax*1]
00007175dc9da564  movaps [r15+0x140], xmm15
00007175dc9da56c  movaps [r15+0x130], xmm14
00007175dc9da574  vmovaps xmm13, [rsp+0x10]
00007175dc9da57a  vpermilpd xmm13, xmm13, 0x00
00007175dc9da580  movaps xmm10, xmm8
00007175dc9da584  vfmadd231pd xmm10, xmm1, xmm13
00007175dc9da589  vcmppd xmm9, xmm10, xmm10, 0x03
00007175dc9da58f  vptest xmm9, xmm9
00007175dc9da594  jnz 0x00007175DC9DCD41
00007175dc9da59a  movaps [r15+0x220], xmm10
00007175dc9da5a2  lea rax, [r14+0x10]
00007175dc9da5a6  movups xmm1, [r13+rax*1]
00007175dc9da5ac  movaps [r15+0x240], xmm1
00007175dc9da5b4  vmovaps xmm13, [rsp+0x10]
00007175dc9da5ba  vpermilpd xmm13, xmm13, 0x00
00007175dc9da5c0  movaps xmm9, xmm7
00007175dc9da5c4  vfmadd231pd xmm9, xmm14, xmm13
00007175dc9da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007175dc9da5cf  vptest xmm8, xmm8
00007175dc9da5d4  jnz 0x00007175DC9DCEA4
00007175dc9da5da  movaps [r15+0x110], xmm9
00007175dc9da5e2  vmovaps xmm14, [rsp+0x10]
00007175dc9da5e8  vpermilpd xmm14, xmm14, 0x00
00007175dc9da5ee  movaps xmm13, xmm12
00007175dc9da5f2  vfmadd231pd xmm13, xmm15, xmm14
00007175dc9da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007175dc9da5fd  vptest xmm8, xmm8
00007175dc9da602  jnz 0x00007175DC9DCFFD
00007175dc9da608  movaps [r15+0x170], xmm13
00007175dc9da610  vmovaps xmm15, [rsp+0x10]
00007175dc9da616  vpermilpd xmm15, xmm15, 0x00
00007175dc9da61c  movaps xmm14, xmm11
00007175dc9da620  vfmadd231pd xmm14, xmm1, xmm15
00007175dc9da625  vcmppd xmm12, xmm14, xmm14, 0x03
00007175dc9da62b  vptest xmm12, xmm12
00007175dc9da630  jnz 0x00007175DC9DD157
00007175dc9da636  movaps [r15+0x230], xmm14
00007175dc9da63e  mov rax, [rsp+0xD0]
00007175dc9da646  movups [r13+rax*1], xmm9
00007175dc9da64c  lea r14, [rax+0x10]
00007175dc9da650  movups [r13+r14*1], xmm13
00007175dc9da656  lea r14, [rax+0x20]
00007175dc9da65a  movups [r13+r14*1], xmm10
00007175dc9da660  lea r14, [rax+0x30]
00007175dc9da664  movups [r13+r14*1], xmm14
00007175dc9da66a  mov eax, [r15+0x108]
00007175dc9da671  sahf
00007175dc9da672  jnz 0x00007175DC9DA6A4
00007175dc9da674  cmp dword ptr [r15+0x318], 0x00
00007175dc9da67c  jz 0x00007175DC9D9950
00007175dc9da682  nop [rax+rax*1], ax
00007175dc9da68b  nop [rax+rax*1], eax
00007175dc9da693  mov eax, 0x410664
00007175dc9da698  mov [r15+0x100], rax
00007175dc9da69f  jmp 0x00007175DC7FE110
00007175dc9da6a4  cmp dword ptr [r15+0x318], 0x00
00007175dc9da6ac  jz 0x00007175DC9D6050
00007175dc9da6b2  nop [rax+rax*1], ax
00007175dc9da6bb  nop [rax+rax*1], eax
00007175dc9da6c3  mov eax, 0x4104F0
00007175dc9da6c8  mov [r15+0x100], rax
00007175dc9da6cf  jmp 0x00007175DC7FE110
00007175dc9da6d4  int3
00007175dc9da6d5  call 0x00007175DC8E27E0
00007175dc9da6da  jmp 0x00007175DC9D9A10
00007175dc9da6df  call 0x00007175DC8E1570
00007175dc9da6e4  jmp 0x00007175DC9D9A19
00007175dc9da6e9  call 0x00007175DC8E27E0
00007175dc9da6ee  jmp 0x00007175DC9D9A62
00007175dc9da6f3  call 0x00007175DC8E1570
00007175dc9da6f8  jmp 0x00007175DC9D9A6B
00007175dc9da6fd  call 0x00007175DC8E27E0
00007175dc9da702  jmp 0x00007175DC9D9AEB
00007175dc9da707  call 0x00007175DC8E1570
00007175dc9da70c  jmp 0x00007175DC9D9AF4
00007175dc9da711  call 0x00007175DC80DC20
00007175dc9da716  jmp 0x00007175DC9D9BD5
00007175dc9da71b  call 0x00007175DC8D64F0
00007175dc9da720  jmp 0x00007175DC9D9C04
00007175dc9da725  call 0x00007175DC8B47C0
00007175dc9da72a  jmp 0x00007175DC9D9C1F
00007175dc9da72f  sub rsp, 0x08
00007175dc9da733  push rax
00007175dc9da734  push rcx
00007175dc9da735  push rdx
00007175dc9da736  push rdi
00007175dc9da737  push rsi
00007175dc9da738  push r8
00007175dc9da73a  push r9
00007175dc9da73c  push r10
00007175dc9da73e  push r11
00007175dc9da740  sub rsp, 0xF0
00007175dc9da747  vmovaps [rsp], xmm0
00007175dc9da74c  vmovaps [rsp+0x10], xmm1
00007175dc9da752  vmovaps [rsp+0x20], xmm2
00007175dc9da758  vmovaps [rsp+0x30], xmm3
00007175dc9da75e  vmovaps [rsp+0x40], xmm4
00007175dc9da764  vmovaps [rsp+0x50], xmm5
00007175dc9da76a  vmovaps [rsp+0x60], xmm6
00007175dc9da770  vmovaps [rsp+0x70], xmm7
00007175dc9da776  vmovaps [rsp+0x80], xmm8
00007175dc9da77f  vmovaps [rsp+0x90], xmm9
00007175dc9da788  vmovaps [rsp+0xA0], xmm10
00007175dc9da791  vmovaps [rsp+0xB0], xmm11
00007175dc9da79a  vmovaps [rsp+0xC0], xmm12
00007175dc9da7a3  vmovaps [rsp+0xD0], xmm14
00007175dc9da7ac  vmovaps [rsp+0xE0], xmm15
00007175dc9da7b5  sub rsp, 0x40
00007175dc9da7b9  lea rdi, [rsp]
00007175dc9da7bd  lea rsi, [rsp+0x10]
00007175dc9da7c2  lea rdx, [rsp+0x20]
00007175dc9da7c7  lea rcx, [rsp+0x30]
00007175dc9da7cc  mov r8d, 0x00
00007175dc9da7d2  lea r9, [r15+0x3A8]
00007175dc9da7d9  movaps [rdi], xmm13
00007175dc9da7dd  movaps [rsi], xmm1
00007175dc9da7e0  movaps [rdx], xmm15
00007175dc9da7e4  movaps [rcx], xmm14
00007175dc9da7e8  mov rax, 0x622B29CAFA50
00007175dc9da7f2  call rax
00007175dc9da7f4  movaps xmm13, [rsp]
00007175dc9da7f9  add rsp, 0x40
00007175dc9da7fd  vmovaps xmm0, [rsp]
00007175dc9da802  vmovaps xmm1, [rsp+0x10]
00007175dc9da808  vmovaps xmm2, [rsp+0x20]
00007175dc9da80e  vmovaps xmm3, [rsp+0x30]
00007175dc9da814  vmovaps xmm4, [rsp+0x40]
00007175dc9da81a  vmovaps xmm5, [rsp+0x50]
00007175dc9da820  vmovaps xmm6, [rsp+0x60]
00007175dc9da826  vmovaps xmm7, [rsp+0x70]
00007175dc9da82c  vmovaps xmm8, [rsp+0x80]
00007175dc9da835  vmovaps xmm9, [rsp+0x90]
00007175dc9da83e  vmovaps xmm10, [rsp+0xA0]
00007175dc9da847  vmovaps xmm11, [rsp+0xB0]
00007175dc9da850  vmovaps xmm12, [rsp+0xC0]
00007175dc9da859  vmovaps xmm14, [rsp+0xD0]
00007175dc9da862  vmovaps xmm15, [rsp+0xE0]
00007175dc9da86b  add rsp, 0xF0
00007175dc9da872  pop r11
00007175dc9da874  pop r10
00007175dc9da876  pop r9
00007175dc9da878  pop r8
00007175dc9da87a  pop rsi
00007175dc9da87b  pop rdi
00007175dc9da87c  pop rdx
00007175dc9da87d  pop rcx
00007175dc9da87e  pop rax
00007175dc9da87f  add rsp, 0x08
00007175dc9da883  jmp 0x00007175DC9D9C92
00007175dc9da888  sub rsp, 0x08
00007175dc9da88c  push rax
00007175dc9da88d  push rcx
00007175dc9da88e  push rdx
00007175dc9da88f  push rdi
00007175dc9da890  push rsi
00007175dc9da891  push r8
00007175dc9da893  push r9
00007175dc9da895  push r10
00007175dc9da897  push r11
00007175dc9da899  sub rsp, 0xF0
00007175dc9da8a0  vmovaps [rsp], xmm0
00007175dc9da8a5  vmovaps [rsp+0x10], xmm1
00007175dc9da8ab  vmovaps [rsp+0x20], xmm2
00007175dc9da8b1  vmovaps [rsp+0x30], xmm3
00007175dc9da8b7  vmovaps [rsp+0x40], xmm4
00007175dc9da8bd  vmovaps [rsp+0x50], xmm5
00007175dc9da8c3  vmovaps [rsp+0x60], xmm6
00007175dc9da8c9  vmovaps [rsp+0x70], xmm7
00007175dc9da8cf  vmovaps [rsp+0x80], xmm8
00007175dc9da8d8  vmovaps [rsp+0x90], xmm9
00007175dc9da8e1  vmovaps [rsp+0xA0], xmm10
00007175dc9da8ea  vmovaps [rsp+0xB0], xmm11
00007175dc9da8f3  vmovaps [rsp+0xC0], xmm13
00007175dc9da8fc  vmovaps [rsp+0xD0], xmm14
00007175dc9da905  vmovaps [rsp+0xE0], xmm15
00007175dc9da90e  sub rsp, 0x40
00007175dc9da912  lea rdi, [rsp]
00007175dc9da916  lea rsi, [rsp+0x10]
00007175dc9da91b  lea rdx, [rsp+0x20]
00007175dc9da920  lea rcx, [rsp+0x30]
00007175dc9da925  mov r8d, 0x00
00007175dc9da92b  lea r9, [r15+0x3A8]
00007175dc9da932  movaps [rdi], xmm12
00007175dc9da936  movaps [rsi], xmm15
00007175dc9da93a  movaps [rdx], xmm1
00007175dc9da93d  movaps [rcx], xmm14
00007175dc9da941  mov rax, 0x622B29CAFA50
00007175dc9da94b  call rax
00007175dc9da94d  movaps xmm12, [rsp]
00007175dc9da952  add rsp, 0x40
00007175dc9da956  vmovaps xmm0, [rsp]
00007175dc9da95b  vmovaps xmm1, [rsp+0x10]
00007175dc9da961  vmovaps xmm2, [rsp+0x20]
00007175dc9da967  vmovaps xmm3, [rsp+0x30]
00007175dc9da96d  vmovaps xmm4, [rsp+0x40]
00007175dc9da973  vmovaps xmm5, [rsp+0x50]
00007175dc9da979  vmovaps xmm6, [rsp+0x60]
00007175dc9da97f  vmovaps xmm7, [rsp+0x70]
00007175dc9da985  vmovaps xmm8, [rsp+0x80]
00007175dc9da98e  vmovaps xmm9, [rsp+0x90]
00007175dc9da997  vmovaps xmm10, [rsp+0xA0]
00007175dc9da9a0  vmovaps xmm11, [rsp+0xB0]
00007175dc9da9a9  vmovaps xmm13, [rsp+0xC0]
00007175dc9da9b2  vmovaps xmm14, [rsp+0xD0]
00007175dc9da9bb  vmovaps xmm15, [rsp+0xE0]
00007175dc9da9c4  add rsp, 0xF0
00007175dc9da9cb  pop r11
00007175dc9da9cd  pop r10
00007175dc9da9cf  pop r9
00007175dc9da9d1  pop r8
00007175dc9da9d3  pop rsi
00007175dc9da9d4  pop rdi
00007175dc9da9d5  pop rdx
00007175dc9da9d6  pop rcx
00007175dc9da9d7  pop rax
00007175dc9da9d8  add rsp, 0x08
00007175dc9da9dc  jmp 0x00007175DC9D9CC0
00007175dc9da9e1  call 0x00007175DC8B52F0
00007175dc9da9e6  jmp 0x00007175DC9D9DAC
00007175dc9da9eb  sub rsp, 0x08
00007175dc9da9ef  push rax
00007175dc9da9f0  push rcx
00007175dc9da9f1  push rdx
00007175dc9da9f2  push rdi
00007175dc9da9f3  push rsi
00007175dc9da9f4  push r8
00007175dc9da9f6  push r9
00007175dc9da9f8  push r10
00007175dc9da9fa  push r11
00007175dc9da9fc  sub rsp, 0xF0
00007175dc9daa03  vmovaps [rsp], xmm0
00007175dc9daa08  vmovaps [rsp+0x10], xmm1
00007175dc9daa0e  vmovaps [rsp+0x20], xmm2
00007175dc9daa14  vmovaps [rsp+0x30], xmm3
00007175dc9daa1a  vmovaps [rsp+0x40], xmm4
00007175dc9daa20  vmovaps [rsp+0x50], xmm5
00007175dc9daa26  vmovaps [rsp+0x60], xmm6
00007175dc9daa2c  vmovaps [rsp+0x70], xmm7
00007175dc9daa32  vmovaps [rsp+0x80], xmm8
00007175dc9daa3b  vmovaps [rsp+0x90], xmm9
00007175dc9daa44  vmovaps [rsp+0xA0], xmm10
00007175dc9daa4d  vmovaps [rsp+0xB0], xmm11
00007175dc9daa56  vmovaps [rsp+0xC0], xmm12
00007175dc9daa5f  vmovaps [rsp+0xD0], xmm14
00007175dc9daa68  vmovaps [rsp+0xE0], xmm15
00007175dc9daa71  sub rsp, 0x40
00007175dc9daa75  lea rdi, [rsp]
00007175dc9daa79  lea rsi, [rsp+0x10]
00007175dc9daa7e  lea rdx, [rsp+0x20]
00007175dc9daa83  lea rcx, [rsp+0x30]
00007175dc9daa88  mov r8d, 0x00
00007175dc9daa8e  lea r9, [r15+0x3A8]
00007175dc9daa95  movaps [rdi], xmm13
00007175dc9daa99  movaps [rsi], xmm1
00007175dc9daa9c  movaps [rdx], xmm15
00007175dc9daaa0  movaps [rcx], xmm14
00007175dc9daaa4  mov rax, 0x622B29CAFA50
00007175dc9daaae  call rax
00007175dc9daab0  movaps xmm13, [rsp]
00007175dc9daab5  add rsp, 0x40
00007175dc9daab9  vmovaps xmm0, [rsp]
00007175dc9daabe  vmovaps xmm1, [rsp+0x10]
00007175dc9daac4  vmovaps xmm2, [rsp+0x20]
00007175dc9daaca  vmovaps xmm3, [rsp+0x30]
00007175dc9daad0  vmovaps xmm4, [rsp+0x40]
00007175dc9daad6  vmovaps xmm5, [rsp+0x50]
00007175dc9daadc  vmovaps xmm6, [rsp+0x60]
00007175dc9daae2  vmovaps xmm7, [rsp+0x70]
00007175dc9daae8  vmovaps xmm8, [rsp+0x80]
00007175dc9daaf1  vmovaps xmm9, [rsp+0x90]
00007175dc9daafa  vmovaps xmm10, [rsp+0xA0]
00007175dc9dab03  vmovaps xmm11, [rsp+0xB0]
00007175dc9dab0c  vmovaps xmm12, [rsp+0xC0]
00007175dc9dab15  vmovaps xmm14, [rsp+0xD0]
00007175dc9dab1e  vmovaps xmm15, [rsp+0xE0]
00007175dc9dab27  add rsp, 0xF0
00007175dc9dab2e  pop r11
00007175dc9dab30  pop r10
00007175dc9dab32  pop r9
00007175dc9dab34  pop r8
00007175dc9dab36  pop rsi
00007175dc9dab37  pop rdi
00007175dc9dab38  pop rdx
00007175dc9dab39  pop rcx
00007175dc9dab3a  pop rax
00007175dc9dab3b  add rsp, 0x08
00007175dc9dab3f  jmp 0x00007175DC9D9E21
00007175dc9dab44  call 0x00007175DC7FF430
00007175dc9dab49  jmp 0x00007175DC9D9E2E
00007175dc9dab4e  sub rsp, 0x08
00007175dc9dab52  push rax
00007175dc9dab53  push rcx
00007175dc9dab54  push rdx
00007175dc9dab55  push rdi
00007175dc9dab56  push rsi
00007175dc9dab57  push r8
00007175dc9dab59  push r9
00007175dc9dab5b  push r10
00007175dc9dab5d  push r11
00007175dc9dab5f  sub rsp, 0xF0
00007175dc9dab66  vmovaps [rsp], xmm0
00007175dc9dab6b  vmovaps [rsp+0x10], xmm1
00007175dc9dab71  vmovaps [rsp+0x20], xmm2
00007175dc9dab77  vmovaps [rsp+0x30], xmm3
00007175dc9dab7d  vmovaps [rsp+0x40], xmm4
00007175dc9dab83  vmovaps [rsp+0x50], xmm5
00007175dc9dab89  vmovaps [rsp+0x60], xmm6
00007175dc9dab8f  vmovaps [rsp+0x70], xmm7
00007175dc9dab95  vmovaps [rsp+0x80], xmm8
00007175dc9dab9e  vmovaps [rsp+0x90], xmm9
00007175dc9daba7  vmovaps [rsp+0xA0], xmm10
00007175dc9dabb0  vmovaps [rsp+0xB0], xmm11
00007175dc9dabb9  vmovaps [rsp+0xC0], xmm13
00007175dc9dabc2  vmovaps [rsp+0xD0], xmm14
00007175dc9dabcb  vmovaps [rsp+0xE0], xmm15
00007175dc9dabd4  sub rsp, 0x40
00007175dc9dabd8  lea rdi, [rsp]
00007175dc9dabdc  lea rsi, [rsp+0x10]
00007175dc9dabe1  lea rdx, [rsp+0x20]
00007175dc9dabe6  lea rcx, [rsp+0x30]
00007175dc9dabeb  mov r8d, 0x00
00007175dc9dabf1  lea r9, [r15+0x3A8]
00007175dc9dabf8  movaps [rdi], xmm12
00007175dc9dabfc  movaps [rsi], xmm15
00007175dc9dac00  movaps [rdx], xmm1
00007175dc9dac03  movaps [rcx], xmm14
00007175dc9dac07  mov rax, 0x622B29CAFA50
00007175dc9dac11  call rax
00007175dc9dac13  movaps xmm12, [rsp]
00007175dc9dac18  add rsp, 0x40
00007175dc9dac1c  vmovaps xmm0, [rsp]
00007175dc9dac21  vmovaps xmm1, [rsp+0x10]
00007175dc9dac27  vmovaps xmm2, [rsp+0x20]
00007175dc9dac2d  vmovaps xmm3, [rsp+0x30]
00007175dc9dac33  vmovaps xmm4, [rsp+0x40]
00007175dc9dac39  vmovaps xmm5, [rsp+0x50]
00007175dc9dac3f  vmovaps xmm6, [rsp+0x60]
00007175dc9dac45  vmovaps xmm7, [rsp+0x70]
00007175dc9dac4b  vmovaps xmm8, [rsp+0x80]
00007175dc9dac54  vmovaps xmm9, [rsp+0x90]
00007175dc9dac5d  vmovaps xmm10, [rsp+0xA0]
00007175dc9dac66  vmovaps xmm11, [rsp+0xB0]
00007175dc9dac6f  vmovaps xmm13, [rsp+0xC0]
00007175dc9dac78  vmovaps xmm14, [rsp+0xD0]
00007175dc9dac81  vmovaps xmm15, [rsp+0xE0]
00007175dc9dac8a  add rsp, 0xF0
00007175dc9dac91  pop r11
00007175dc9dac93  pop r10
00007175dc9dac95  pop r9
00007175dc9dac97  pop r8
00007175dc9dac99  pop rsi
00007175dc9dac9a  pop rdi
00007175dc9dac9b  pop rdx
00007175dc9dac9c  pop rcx
00007175dc9dac9d  pop rax
00007175dc9dac9e  add rsp, 0x08
00007175dc9daca2  jmp 0x00007175DC9D9E5A
00007175dc9daca7  sub rsp, 0x08
00007175dc9dacab  push rax
00007175dc9dacac  push rcx
00007175dc9dacad  push rdx
00007175dc9dacae  push rdi
00007175dc9dacaf  push rsi
00007175dc9dacb0  push r8
00007175dc9dacb2  push r9
00007175dc9dacb4  push r10
00007175dc9dacb6  push r11
00007175dc9dacb8  sub rsp, 0xF0
00007175dc9dacbf  vmovaps [rsp], xmm0
00007175dc9dacc4  vmovaps [rsp+0x10], xmm1
00007175dc9dacca  vmovaps [rsp+0x20], xmm2
00007175dc9dacd0  vmovaps [rsp+0x30], xmm3
00007175dc9dacd6  vmovaps [rsp+0x40], xmm4
00007175dc9dacdc  vmovaps [rsp+0x50], xmm5
00007175dc9dace2  vmovaps [rsp+0x60], xmm6
00007175dc9dace8  vmovaps [rsp+0x70], xmm7
00007175dc9dacee  vmovaps [rsp+0x80], xmm8
00007175dc9dacf7  vmovaps [rsp+0x90], xmm9
00007175dc9dad00  vmovaps [rsp+0xA0], xmm10
00007175dc9dad09  vmovaps [rsp+0xB0], xmm11
00007175dc9dad12  vmovaps [rsp+0xC0], xmm12
00007175dc9dad1b  vmovaps [rsp+0xD0], xmm14
00007175dc9dad24  vmovaps [rsp+0xE0], xmm15
00007175dc9dad2d  sub rsp, 0x40
00007175dc9dad31  lea rdi, [rsp]
00007175dc9dad35  lea rsi, [rsp+0x10]
00007175dc9dad3a  lea rdx, [rsp+0x20]
00007175dc9dad3f  lea rcx, [rsp+0x30]
00007175dc9dad44  mov r8d, 0x00
00007175dc9dad4a  lea r9, [r15+0x3A8]
00007175dc9dad51  movaps [rdi], xmm13
00007175dc9dad55  movaps [rsi], xmm1
00007175dc9dad58  movaps [rdx], xmm15
00007175dc9dad5c  movaps [rcx], xmm14
00007175dc9dad60  mov rax, 0x622B29CAFA50
00007175dc9dad6a  call rax
00007175dc9dad6c  movaps xmm13, [rsp]
00007175dc9dad71  add rsp, 0x40
00007175dc9dad75  vmovaps xmm0, [rsp]
00007175dc9dad7a  vmovaps xmm1, [rsp+0x10]
00007175dc9dad80  vmovaps xmm2, [rsp+0x20]
00007175dc9dad86  vmovaps xmm3, [rsp+0x30]
00007175dc9dad8c  vmovaps xmm4, [rsp+0x40]
00007175dc9dad92  vmovaps xmm5, [rsp+0x50]
00007175dc9dad98  vmovaps xmm6, [rsp+0x60]
00007175dc9dad9e  vmovaps xmm7, [rsp+0x70]
00007175dc9dada4  vmovaps xmm8, [rsp+0x80]
00007175dc9dadad  vmovaps xmm9, [rsp+0x90]
00007175dc9dadb6  vmovaps xmm10, [rsp+0xA0]
00007175dc9dadbf  vmovaps xmm11, [rsp+0xB0]
00007175dc9dadc8  vmovaps xmm12, [rsp+0xC0]
00007175dc9dadd1  vmovaps xmm14, [rsp+0xD0]
00007175dc9dadda  vmovaps xmm15, [rsp+0xE0]
00007175dc9dade3  add rsp, 0xF0
00007175dc9dadea  pop r11
00007175dc9dadec  pop r10
00007175dc9dadee  pop r9
00007175dc9dadf0  pop r8
00007175dc9dadf2  pop rsi
00007175dc9dadf3  pop rdi
00007175dc9dadf4  pop rdx
00007175dc9dadf5  pop rcx
00007175dc9dadf6  pop rax
00007175dc9dadf7  add rsp, 0x08
00007175dc9dadfb  jmp 0x00007175DC9D9FEA
00007175dc9dae00  sub rsp, 0x08
00007175dc9dae04  push rax
00007175dc9dae05  push rcx
00007175dc9dae06  push rdx
00007175dc9dae07  push rdi
00007175dc9dae08  push rsi
00007175dc9dae09  push r8
00007175dc9dae0b  push r9
00007175dc9dae0d  push r10
00007175dc9dae0f  push r11
00007175dc9dae11  sub rsp, 0xF0
00007175dc9dae18  vmovaps [rsp], xmm0
00007175dc9dae1d  vmovaps [rsp+0x10], xmm1
00007175dc9dae23  vmovaps [rsp+0x20], xmm2
00007175dc9dae29  vmovaps [rsp+0x30], xmm3
00007175dc9dae2f  vmovaps [rsp+0x40], xmm4
00007175dc9dae35  vmovaps [rsp+0x50], xmm5
00007175dc9dae3b  vmovaps [rsp+0x60], xmm6
00007175dc9dae41  vmovaps [rsp+0x70], xmm7
00007175dc9dae47  vmovaps [rsp+0x80], xmm8
00007175dc9dae50  vmovaps [rsp+0x90], xmm9
00007175dc9dae59  vmovaps [rsp+0xA0], xmm10
00007175dc9dae62  vmovaps [rsp+0xB0], xmm11
00007175dc9dae6b  vmovaps [rsp+0xC0], xmm12
00007175dc9dae74  vmovaps [rsp+0xD0], xmm13
00007175dc9dae7d  vmovaps [rsp+0xE0], xmm15
00007175dc9dae86  sub rsp, 0x40
00007175dc9dae8a  lea rdi, [rsp]
00007175dc9dae8e  lea rsi, [rsp+0x10]
00007175dc9dae93  lea rdx, [rsp+0x20]
00007175dc9dae98  lea rcx, [rsp+0x30]
00007175dc9dae9d  mov r8d, 0x00
00007175dc9daea3  lea r9, [r15+0x3A8]
00007175dc9daeaa  movaps [rdi], xmm14
00007175dc9daeae  movaps [rsi], xmm15
00007175dc9daeb2  movaps [rdx], xmm2
00007175dc9daeb5  movaps [rcx], xmm1
00007175dc9daeb8  mov rax, 0x622B29CAFA50
00007175dc9daec2  call rax
00007175dc9daec4  movaps xmm14, [rsp]
00007175dc9daec9  add rsp, 0x40
00007175dc9daecd  vmovaps xmm0, [rsp]
00007175dc9daed2  vmovaps xmm1, [rsp+0x10]
00007175dc9daed8  vmovaps xmm2, [rsp+0x20]
00007175dc9daede  vmovaps xmm3, [rsp+0x30]
00007175dc9daee4  vmovaps xmm4, [rsp+0x40]
00007175dc9daeea  vmovaps xmm5, [rsp+0x50]
00007175dc9daef0  vmovaps xmm6, [rsp+0x60]
00007175dc9daef6  vmovaps xmm7, [rsp+0x70]
00007175dc9daefc  vmovaps xmm8, [rsp+0x80]
00007175dc9daf05  vmovaps xmm9, [rsp+0x90]
00007175dc9daf0e  vmovaps xmm10, [rsp+0xA0]
00007175dc9daf17  vmovaps xmm11, [rsp+0xB0]
00007175dc9daf20  vmovaps xmm12, [rsp+0xC0]
00007175dc9daf29  vmovaps xmm13, [rsp+0xD0]
00007175dc9daf32  vmovaps xmm15, [rsp+0xE0]
00007175dc9daf3b  add rsp, 0xF0
00007175dc9daf42  pop r11
00007175dc9daf44  pop r10
00007175dc9daf46  pop r9
00007175dc9daf48  pop r8
00007175dc9daf4a  pop rsi
00007175dc9daf4b  pop rdi
00007175dc9daf4c  pop rdx
00007175dc9daf4d  pop rcx
00007175dc9daf4e  pop rax
00007175dc9daf4f  add rsp, 0x08
00007175dc9daf53  jmp 0x00007175DC9DA01C
00007175dc9daf58  sub rsp, 0x08
00007175dc9daf5c  push rax
00007175dc9daf5d  push rcx
00007175dc9daf5e  push rdx
00007175dc9daf5f  push rdi
00007175dc9daf60  push rsi
00007175dc9daf61  push r8
00007175dc9daf63  push r9
00007175dc9daf65  push r10
00007175dc9daf67  push r11
00007175dc9daf69  sub rsp, 0xF0
00007175dc9daf70  vmovaps [rsp], xmm0
00007175dc9daf75  vmovaps [rsp+0x10], xmm1
00007175dc9daf7b  vmovaps [rsp+0x20], xmm3
00007175dc9daf81  vmovaps [rsp+0x30], xmm4
00007175dc9daf87  vmovaps [rsp+0x40], xmm5
00007175dc9daf8d  vmovaps [rsp+0x50], xmm6
00007175dc9daf93  vmovaps [rsp+0x60], xmm7
00007175dc9daf99  vmovaps [rsp+0x70], xmm8
00007175dc9daf9f  vmovaps [rsp+0x80], xmm9
00007175dc9dafa8  vmovaps [rsp+0x90], xmm10
00007175dc9dafb1  vmovaps [rsp+0xA0], xmm11
00007175dc9dafba  vmovaps [rsp+0xB0], xmm12
00007175dc9dafc3  vmovaps [rsp+0xC0], xmm13
00007175dc9dafcc  vmovaps [rsp+0xD0], xmm14
00007175dc9dafd5  vmovaps [rsp+0xE0], xmm15
00007175dc9dafde  sub rsp, 0x40
00007175dc9dafe2  lea rdi, [rsp]
00007175dc9dafe6  lea rsi, [rsp+0x10]
00007175dc9dafeb  lea rdx, [rsp+0x20]
00007175dc9daff0  lea rcx, [rsp+0x30]
00007175dc9daff5  mov r8d, 0x00
00007175dc9daffb  lea r9, [r15+0x3A8]
00007175dc9db002  movaps [rdi], xmm2
00007175dc9db005  movaps [rsi], xmm15
00007175dc9db009  movaps [rdx], xmm12
00007175dc9db00d  movaps [rcx], xmm1
00007175dc9db010  mov rax, 0x622B29CAFA50
00007175dc9db01a  call rax
00007175dc9db01c  movaps xmm2, [rsp]
00007175dc9db020  add rsp, 0x40
00007175dc9db024  vmovaps xmm0, [rsp]
00007175dc9db029  vmovaps xmm1, [rsp+0x10]
00007175dc9db02f  vmovaps xmm3, [rsp+0x20]
00007175dc9db035  vmovaps xmm4, [rsp+0x30]
00007175dc9db03b  vmovaps xmm5, [rsp+0x40]
00007175dc9db041  vmovaps xmm6, [rsp+0x50]
00007175dc9db047  vmovaps xmm7, [rsp+0x60]
00007175dc9db04d  vmovaps xmm8, [rsp+0x70]
00007175dc9db053  vmovaps xmm9, [rsp+0x80]
00007175dc9db05c  vmovaps xmm10, [rsp+0x90]
00007175dc9db065  vmovaps xmm11, [rsp+0xA0]
00007175dc9db06e  vmovaps xmm12, [rsp+0xB0]
00007175dc9db077  vmovaps xmm13, [rsp+0xC0]
00007175dc9db080  vmovaps xmm14, [rsp+0xD0]
00007175dc9db089  vmovaps xmm15, [rsp+0xE0]
00007175dc9db092  add rsp, 0xF0
00007175dc9db099  pop r11
00007175dc9db09b  pop r10
00007175dc9db09d  pop r9
00007175dc9db09f  pop r8
00007175dc9db0a1  pop rsi
00007175dc9db0a2  pop rdi
00007175dc9db0a3  pop rdx
00007175dc9db0a4  pop rcx
00007175dc9db0a5  pop rax
00007175dc9db0a6  add rsp, 0x08
00007175dc9db0aa  jmp 0x00007175DC9DA059
00007175dc9db0af  sub rsp, 0x08
00007175dc9db0b3  push rax
00007175dc9db0b4  push rcx
00007175dc9db0b5  push rdx
00007175dc9db0b6  push rdi
00007175dc9db0b7  push rsi
00007175dc9db0b8  push r8
00007175dc9db0ba  push r9
00007175dc9db0bc  push r10
00007175dc9db0be  push r11
00007175dc9db0c0  sub rsp, 0xF0
00007175dc9db0c7  vmovaps [rsp], xmm0
00007175dc9db0cc  vmovaps [rsp+0x10], xmm1
00007175dc9db0d2  vmovaps [rsp+0x20], xmm2
00007175dc9db0d8  vmovaps [rsp+0x30], xmm3
00007175dc9db0de  vmovaps [rsp+0x40], xmm4
00007175dc9db0e4  vmovaps [rsp+0x50], xmm5
00007175dc9db0ea  vmovaps [rsp+0x60], xmm6
00007175dc9db0f0  vmovaps [rsp+0x70], xmm7
00007175dc9db0f6  vmovaps [rsp+0x80], xmm8
00007175dc9db0ff  vmovaps [rsp+0x90], xmm9
00007175dc9db108  vmovaps [rsp+0xA0], xmm10
00007175dc9db111  vmovaps [rsp+0xB0], xmm11
00007175dc9db11a  vmovaps [rsp+0xC0], xmm13
00007175dc9db123  vmovaps [rsp+0xD0], xmm14
00007175dc9db12c  vmovaps [rsp+0xE0], xmm15
00007175dc9db135  sub rsp, 0x40
00007175dc9db139  lea rdi, [rsp]
00007175dc9db13d  lea rsi, [rsp+0x10]
00007175dc9db142  lea rdx, [rsp+0x20]
00007175dc9db147  lea rcx, [rsp+0x30]
00007175dc9db14c  mov r8d, 0x00
00007175dc9db152  lea r9, [r15+0x3A8]
00007175dc9db159  movaps [rdi], xmm12
00007175dc9db15d  movaps [rsi], xmm14
00007175dc9db161  movaps [rdx], xmm3
00007175dc9db164  movaps [rcx], xmm15
00007175dc9db168  mov rax, 0x622B29CAFA50
00007175dc9db172  call rax
00007175dc9db174  movaps xmm12, [rsp]
00007175dc9db179  add rsp, 0x40
00007175dc9db17d  vmovaps xmm0, [rsp]
00007175dc9db182  vmovaps xmm1, [rsp+0x10]
00007175dc9db188  vmovaps xmm2, [rsp+0x20]
00007175dc9db18e  vmovaps xmm3, [rsp+0x30]
00007175dc9db194  vmovaps xmm4, [rsp+0x40]
00007175dc9db19a  vmovaps xmm5, [rsp+0x50]
00007175dc9db1a0  vmovaps xmm6, [rsp+0x60]
00007175dc9db1a6  vmovaps xmm7, [rsp+0x70]
00007175dc9db1ac  vmovaps xmm8, [rsp+0x80]
00007175dc9db1b5  vmovaps xmm9, [rsp+0x90]
00007175dc9db1be  vmovaps xmm10, [rsp+0xA0]
00007175dc9db1c7  vmovaps xmm11, [rsp+0xB0]
00007175dc9db1d0  vmovaps xmm13, [rsp+0xC0]
00007175dc9db1d9  vmovaps xmm14, [rsp+0xD0]
00007175dc9db1e2  vmovaps xmm15, [rsp+0xE0]
00007175dc9db1eb  add rsp, 0xF0
00007175dc9db1f2  pop r11
00007175dc9db1f4  pop r10
00007175dc9db1f6  pop r9
00007175dc9db1f8  pop r8
00007175dc9db1fa  pop rsi
00007175dc9db1fb  pop rdi
00007175dc9db1fc  pop rdx
00007175dc9db1fd  pop rcx
00007175dc9db1fe  pop rax
00007175dc9db1ff  add rsp, 0x08
00007175dc9db203  jmp 0x00007175DC9DA0B3
00007175dc9db208  sub rsp, 0x08
00007175dc9db20c  push rax
00007175dc9db20d  push rcx
00007175dc9db20e  push rdx
00007175dc9db20f  push rdi
00007175dc9db210  push rsi
00007175dc9db211  push r8
00007175dc9db213  push r9
00007175dc9db215  push r10
00007175dc9db217  push r11
00007175dc9db219  sub rsp, 0xF0
00007175dc9db220  vmovaps [rsp], xmm0
00007175dc9db225  vmovaps [rsp+0x10], xmm1
00007175dc9db22b  vmovaps [rsp+0x20], xmm2
00007175dc9db231  vmovaps [rsp+0x30], xmm3
00007175dc9db237  vmovaps [rsp+0x40], xmm4
00007175dc9db23d  vmovaps [rsp+0x50], xmm5
00007175dc9db243  vmovaps [rsp+0x60], xmm6
00007175dc9db249  vmovaps [rsp+0x70], xmm7
00007175dc9db24f  vmovaps [rsp+0x80], xmm8
00007175dc9db258  vmovaps [rsp+0x90], xmm10
00007175dc9db261  vmovaps [rsp+0xA0], xmm11
00007175dc9db26a  vmovaps [rsp+0xB0], xmm12
00007175dc9db273  vmovaps [rsp+0xC0], xmm13
00007175dc9db27c  vmovaps [rsp+0xD0], xmm14
00007175dc9db285  vmovaps [rsp+0xE0], xmm15
00007175dc9db28e  sub rsp, 0x40
00007175dc9db292  lea rdi, [rsp]
00007175dc9db296  lea rsi, [rsp+0x10]
00007175dc9db29b  lea rdx, [rsp+0x20]
00007175dc9db2a0  lea rcx, [rsp+0x30]
00007175dc9db2a5  mov r8d, 0x00
00007175dc9db2ab  lea r9, [r15+0x3A8]
00007175dc9db2b2  movaps [rdi], xmm9
00007175dc9db2b6  movaps [rsi], xmm13
00007175dc9db2ba  movaps [rdx], xmm14
00007175dc9db2be  movaps [rcx], xmm6
00007175dc9db2c1  mov rax, 0x622B29CAFA50
00007175dc9db2cb  call rax
00007175dc9db2cd  movaps xmm9, [rsp]
00007175dc9db2d2  add rsp, 0x40
00007175dc9db2d6  vmovaps xmm0, [rsp]
00007175dc9db2db  vmovaps xmm1, [rsp+0x10]
00007175dc9db2e1  vmovaps xmm2, [rsp+0x20]
00007175dc9db2e7  vmovaps xmm3, [rsp+0x30]
00007175dc9db2ed  vmovaps xmm4, [rsp+0x40]
00007175dc9db2f3  vmovaps xmm5, [rsp+0x50]
00007175dc9db2f9  vmovaps xmm6, [rsp+0x60]
00007175dc9db2ff  vmovaps xmm7, [rsp+0x70]
00007175dc9db305  vmovaps xmm8, [rsp+0x80]
00007175dc9db30e  vmovaps xmm10, [rsp+0x90]
00007175dc9db317  vmovaps xmm11, [rsp+0xA0]
00007175dc9db320  vmovaps xmm12, [rsp+0xB0]
00007175dc9db329  vmovaps xmm13, [rsp+0xC0]
00007175dc9db332  vmovaps xmm14, [rsp+0xD0]
00007175dc9db33b  vmovaps xmm15, [rsp+0xE0]
00007175dc9db344  add rsp, 0xF0
00007175dc9db34b  pop r11
00007175dc9db34d  pop r10
00007175dc9db34f  pop r9
00007175dc9db351  pop r8
00007175dc9db353  pop rsi
00007175dc9db354  pop rdi
00007175dc9db355  pop rdx
00007175dc9db356  pop rcx
00007175dc9db357  pop rax
00007175dc9db358  add rsp, 0x08
00007175dc9db35c  jmp 0x00007175DC9DA15D
00007175dc9db361  sub rsp, 0x08
00007175dc9db365  push rax
00007175dc9db366  push rcx
00007175dc9db367  push rdx
00007175dc9db368  push rdi
00007175dc9db369  push rsi
00007175dc9db36a  push r8
00007175dc9db36c  push r9
00007175dc9db36e  push r10
00007175dc9db370  push r11
00007175dc9db372  sub rsp, 0xF0
00007175dc9db379  vmovaps [rsp], xmm0
00007175dc9db37e  vmovaps [rsp+0x10], xmm1
00007175dc9db384  vmovaps [rsp+0x20], xmm2
00007175dc9db38a  vmovaps [rsp+0x30], xmm4
00007175dc9db390  vmovaps [rsp+0x40], xmm5
00007175dc9db396  vmovaps [rsp+0x50], xmm6
00007175dc9db39c  vmovaps [rsp+0x60], xmm7
00007175dc9db3a2  vmovaps [rsp+0x70], xmm8
00007175dc9db3a8  vmovaps [rsp+0x80], xmm9
00007175dc9db3b1  vmovaps [rsp+0x90], xmm10
00007175dc9db3ba  vmovaps [rsp+0xA0], xmm11
00007175dc9db3c3  vmovaps [rsp+0xB0], xmm12
00007175dc9db3cc  vmovaps [rsp+0xC0], xmm13
00007175dc9db3d5  vmovaps [rsp+0xD0], xmm14
00007175dc9db3de  vmovaps [rsp+0xE0], xmm15
00007175dc9db3e7  sub rsp, 0x40
00007175dc9db3eb  lea rdi, [rsp]
00007175dc9db3ef  lea rsi, [rsp+0x10]
00007175dc9db3f4  lea rdx, [rsp+0x20]
00007175dc9db3f9  lea rcx, [rsp+0x30]
00007175dc9db3fe  mov r8d, 0x00
00007175dc9db404  lea r9, [r15+0x3A8]
00007175dc9db40b  movaps [rdi], xmm3
00007175dc9db40e  movaps [rsi], xmm13
00007175dc9db412  movaps [rdx], xmm6
00007175dc9db415  movaps [rcx], xmm14
00007175dc9db419  mov rax, 0x622B29CAFA50
00007175dc9db423  call rax
00007175dc9db425  movaps xmm3, [rsp]
00007175dc9db429  add rsp, 0x40
00007175dc9db42d  vmovaps xmm0, [rsp]
00007175dc9db432  vmovaps xmm1, [rsp+0x10]
00007175dc9db438  vmovaps xmm2, [rsp+0x20]
00007175dc9db43e  vmovaps xmm4, [rsp+0x30]
00007175dc9db444  vmovaps xmm5, [rsp+0x40]
00007175dc9db44a  vmovaps xmm6, [rsp+0x50]
00007175dc9db450  vmovaps xmm7, [rsp+0x60]
00007175dc9db456  vmovaps xmm8, [rsp+0x70]
00007175dc9db45c  vmovaps xmm9, [rsp+0x80]
00007175dc9db465  vmovaps xmm10, [rsp+0x90]
00007175dc9db46e  vmovaps xmm11, [rsp+0xA0]
00007175dc9db477  vmovaps xmm12, [rsp+0xB0]
00007175dc9db480  vmovaps xmm13, [rsp+0xC0]
00007175dc9db489  vmovaps xmm14, [rsp+0xD0]
00007175dc9db492  vmovaps xmm15, [rsp+0xE0]
00007175dc9db49b  add rsp, 0xF0
00007175dc9db4a2  pop r11
00007175dc9db4a4  pop r10
00007175dc9db4a6  pop r9
00007175dc9db4a8  pop r8
00007175dc9db4aa  pop rsi
00007175dc9db4ab  pop rdi
00007175dc9db4ac  pop rdx
00007175dc9db4ad  pop rcx
00007175dc9db4ae  pop rax
00007175dc9db4af  add rsp, 0x08
00007175dc9db4b3  jmp 0x00007175DC9DA19A
00007175dc9db4b8  sub rsp, 0x08
00007175dc9db4bc  push rax
00007175dc9db4bd  push rcx
00007175dc9db4be  push rdx
00007175dc9db4bf  push rdi
00007175dc9db4c0  push rsi
00007175dc9db4c1  push r8
00007175dc9db4c3  push r9
00007175dc9db4c5  push r10
00007175dc9db4c7  push r11
00007175dc9db4c9  sub rsp, 0xF0
00007175dc9db4d0  vmovaps [rsp], xmm0
00007175dc9db4d5  vmovaps [rsp+0x10], xmm1
00007175dc9db4db  vmovaps [rsp+0x20], xmm2
00007175dc9db4e1  vmovaps [rsp+0x30], xmm3
00007175dc9db4e7  vmovaps [rsp+0x40], xmm4
00007175dc9db4ed  vmovaps [rsp+0x50], xmm5
00007175dc9db4f3  vmovaps [rsp+0x60], xmm7
00007175dc9db4f9  vmovaps [rsp+0x70], xmm8
00007175dc9db4ff  vmovaps [rsp+0x80], xmm9
00007175dc9db508  vmovaps [rsp+0x90], xmm10
00007175dc9db511  vmovaps [rsp+0xA0], xmm11
00007175dc9db51a  vmovaps [rsp+0xB0], xmm12
00007175dc9db523  vmovaps [rsp+0xC0], xmm13
00007175dc9db52c  vmovaps [rsp+0xD0], xmm14
00007175dc9db535  vmovaps [rsp+0xE0], xmm15
00007175dc9db53e  sub rsp, 0x40
00007175dc9db542  lea rdi, [rsp]
00007175dc9db546  lea rsi, [rsp+0x10]
00007175dc9db54b  lea rdx, [rsp+0x20]
00007175dc9db550  lea rcx, [rsp+0x30]
00007175dc9db555  mov r8d, 0x00
00007175dc9db55b  lea r9, [r15+0x3A8]
00007175dc9db562  movaps [rdi], xmm6
00007175dc9db565  movaps [rsi], xmm2
00007175dc9db568  movaps [rdx], xmm14
00007175dc9db56c  movaps [rcx], xmm1
00007175dc9db56f  mov rax, 0x622B29CAFA50
00007175dc9db579  call rax
00007175dc9db57b  movaps xmm6, [rsp]
00007175dc9db57f  add rsp, 0x40
00007175dc9db583  vmovaps xmm0, [rsp]
00007175dc9db588  vmovaps xmm1, [rsp+0x10]
00007175dc9db58e  vmovaps xmm2, [rsp+0x20]
00007175dc9db594  vmovaps xmm3, [rsp+0x30]
00007175dc9db59a  vmovaps xmm4, [rsp+0x40]
00007175dc9db5a0  vmovaps xmm5, [rsp+0x50]
00007175dc9db5a6  vmovaps xmm7, [rsp+0x60]
00007175dc9db5ac  vmovaps xmm8, [rsp+0x70]
00007175dc9db5b2  vmovaps xmm9, [rsp+0x80]
00007175dc9db5bb  vmovaps xmm10, [rsp+0x90]
00007175dc9db5c4  vmovaps xmm11, [rsp+0xA0]
00007175dc9db5cd  vmovaps xmm12, [rsp+0xB0]
00007175dc9db5d6  vmovaps xmm13, [rsp+0xC0]
00007175dc9db5df  vmovaps xmm14, [rsp+0xD0]
00007175dc9db5e8  vmovaps xmm15, [rsp+0xE0]
00007175dc9db5f1  add rsp, 0xF0
00007175dc9db5f8  pop r11
00007175dc9db5fa  pop r10
00007175dc9db5fc  pop r9
00007175dc9db5fe  pop r8
00007175dc9db600  pop rsi
00007175dc9db601  pop rdi
00007175dc9db602  pop rdx
00007175dc9db603  pop rcx
00007175dc9db604  pop rax
00007175dc9db605  add rsp, 0x08
00007175dc9db609  jmp 0x00007175DC9DA1C7
00007175dc9db60e  sub rsp, 0x08
00007175dc9db612  push rax
00007175dc9db613  push rcx
00007175dc9db614  push rdx
00007175dc9db615  push rdi
00007175dc9db616  push rsi
00007175dc9db617  push r8
00007175dc9db619  push r9
00007175dc9db61b  push r10
00007175dc9db61d  push r11
00007175dc9db61f  sub rsp, 0xF0
00007175dc9db626  vmovaps [rsp], xmm0
00007175dc9db62b  vmovaps [rsp+0x10], xmm1
00007175dc9db631  vmovaps [rsp+0x20], xmm2
00007175dc9db637  vmovaps [rsp+0x30], xmm3
00007175dc9db63d  vmovaps [rsp+0x40], xmm4
00007175dc9db643  vmovaps [rsp+0x50], xmm5
00007175dc9db649  vmovaps [rsp+0x60], xmm6
00007175dc9db64f  vmovaps [rsp+0x70], xmm7
00007175dc9db655  vmovaps [rsp+0x80], xmm8
00007175dc9db65e  vmovaps [rsp+0x90], xmm9
00007175dc9db667  vmovaps [rsp+0xA0], xmm10
00007175dc9db670  vmovaps [rsp+0xB0], xmm11
00007175dc9db679  vmovaps [rsp+0xC0], xmm12
00007175dc9db682  vmovaps [rsp+0xD0], xmm14
00007175dc9db68b  vmovaps [rsp+0xE0], xmm15
00007175dc9db694  sub rsp, 0x40
00007175dc9db698  lea rdi, [rsp]
00007175dc9db69c  lea rsi, [rsp+0x10]
00007175dc9db6a1  lea rdx, [rsp+0x20]
00007175dc9db6a6  lea rcx, [rsp+0x30]
00007175dc9db6ab  mov r8d, 0x00
00007175dc9db6b1  lea r9, [r15+0x3A8]
00007175dc9db6b8  movaps [rdi], xmm13
00007175dc9db6bc  movaps [rsi], xmm12
00007175dc9db6c0  movaps [rdx], xmm14
00007175dc9db6c4  movaps [rcx], xmm1
00007175dc9db6c7  mov rax, 0x622B29CAFA50
00007175dc9db6d1  call rax
00007175dc9db6d3  movaps xmm13, [rsp]
00007175dc9db6d8  add rsp, 0x40
00007175dc9db6dc  vmovaps xmm0, [rsp]
00007175dc9db6e1  vmovaps xmm1, [rsp+0x10]
00007175dc9db6e7  vmovaps xmm2, [rsp+0x20]
00007175dc9db6ed  vmovaps xmm3, [rsp+0x30]
00007175dc9db6f3  vmovaps xmm4, [rsp+0x40]
00007175dc9db6f9  vmovaps xmm5, [rsp+0x50]
00007175dc9db6ff  vmovaps xmm6, [rsp+0x60]
00007175dc9db705  vmovaps xmm7, [rsp+0x70]
00007175dc9db70b  vmovaps xmm8, [rsp+0x80]
00007175dc9db714  vmovaps xmm9, [rsp+0x90]
00007175dc9db71d  vmovaps xmm10, [rsp+0xA0]
00007175dc9db726  vmovaps xmm11, [rsp+0xB0]
00007175dc9db72f  vmovaps xmm12, [rsp+0xC0]
00007175dc9db738  vmovaps xmm14, [rsp+0xD0]
00007175dc9db741  vmovaps xmm15, [rsp+0xE0]
00007175dc9db74a  add rsp, 0xF0
00007175dc9db751  pop r11
00007175dc9db753  pop r10
00007175dc9db755  pop r9
00007175dc9db757  pop r8
00007175dc9db759  pop rsi
00007175dc9db75a  pop rdi
00007175dc9db75b  pop rdx
00007175dc9db75c  pop rcx
00007175dc9db75d  pop rax
00007175dc9db75e  add rsp, 0x08
00007175dc9db762  jmp 0x00007175DC9DA1F9
00007175dc9db767  sub rsp, 0x08
00007175dc9db76b  push rax
00007175dc9db76c  push rcx
00007175dc9db76d  push rdx
00007175dc9db76e  push rdi
00007175dc9db76f  push rsi
00007175dc9db770  push r8
00007175dc9db772  push r9
00007175dc9db774  push r10
00007175dc9db776  push r11
00007175dc9db778  sub rsp, 0xF0
00007175dc9db77f  vmovaps [rsp], xmm0
00007175dc9db784  vmovaps [rsp+0x10], xmm1
00007175dc9db78a  vmovaps [rsp+0x20], xmm2
00007175dc9db790  vmovaps [rsp+0x30], xmm3
00007175dc9db796  vmovaps [rsp+0x40], xmm4
00007175dc9db79c  vmovaps [rsp+0x50], xmm5
00007175dc9db7a2  vmovaps [rsp+0x60], xmm6
00007175dc9db7a8  vmovaps [rsp+0x70], xmm7
00007175dc9db7ae  vmovaps [rsp+0x80], xmm8
00007175dc9db7b7  vmovaps [rsp+0x90], xmm9
00007175dc9db7c0  vmovaps [rsp+0xA0], xmm10
00007175dc9db7c9  vmovaps [rsp+0xB0], xmm11
00007175dc9db7d2  vmovaps [rsp+0xC0], xmm13
00007175dc9db7db  vmovaps [rsp+0xD0], xmm14
00007175dc9db7e4  vmovaps [rsp+0xE0], xmm15
00007175dc9db7ed  sub rsp, 0x40
00007175dc9db7f1  lea rdi, [rsp]
00007175dc9db7f5  lea rsi, [rsp+0x10]
00007175dc9db7fa  lea rdx, [rsp+0x20]
00007175dc9db7ff  lea rcx, [rsp+0x30]
00007175dc9db804  mov r8d, 0x00
00007175dc9db80a  lea r9, [r15+0x3A8]
00007175dc9db811  movaps [rdi], xmm12
00007175dc9db815  movaps [rsi], xmm3
00007175dc9db818  movaps [rdx], xmm14
00007175dc9db81c  movaps [rcx], xmm5
00007175dc9db81f  mov rax, 0x622B29CAFA50
00007175dc9db829  call rax
00007175dc9db82b  movaps xmm12, [rsp]
00007175dc9db830  add rsp, 0x40
00007175dc9db834  vmovaps xmm0, [rsp]
00007175dc9db839  vmovaps xmm1, [rsp+0x10]
00007175dc9db83f  vmovaps xmm2, [rsp+0x20]
00007175dc9db845  vmovaps xmm3, [rsp+0x30]
00007175dc9db84b  vmovaps xmm4, [rsp+0x40]
00007175dc9db851  vmovaps xmm5, [rsp+0x50]
00007175dc9db857  vmovaps xmm6, [rsp+0x60]
00007175dc9db85d  vmovaps xmm7, [rsp+0x70]
00007175dc9db863  vmovaps xmm8, [rsp+0x80]
00007175dc9db86c  vmovaps xmm9, [rsp+0x90]
00007175dc9db875  vmovaps xmm10, [rsp+0xA0]
00007175dc9db87e  vmovaps xmm11, [rsp+0xB0]
00007175dc9db887  vmovaps xmm13, [rsp+0xC0]
00007175dc9db890  vmovaps xmm14, [rsp+0xD0]
00007175dc9db899  vmovaps xmm15, [rsp+0xE0]
00007175dc9db8a2  add rsp, 0xF0
00007175dc9db8a9  pop r11
00007175dc9db8ab  pop r10
00007175dc9db8ad  pop r9
00007175dc9db8af  pop r8
00007175dc9db8b1  pop rsi
00007175dc9db8b2  pop rdi
00007175dc9db8b3  pop rdx
00007175dc9db8b4  pop rcx
00007175dc9db8b5  pop rax
00007175dc9db8b6  add rsp, 0x08
00007175dc9db8ba  jmp 0x00007175DC9DA256
00007175dc9db8bf  sub rsp, 0x08
00007175dc9db8c3  push rax
00007175dc9db8c4  push rcx
00007175dc9db8c5  push rdx
00007175dc9db8c6  push rdi
00007175dc9db8c7  push rsi
00007175dc9db8c8  push r8
00007175dc9db8ca  push r9
00007175dc9db8cc  push r10
00007175dc9db8ce  push r11
00007175dc9db8d0  sub rsp, 0xF0
00007175dc9db8d7  vmovaps [rsp], xmm0
00007175dc9db8dc  vmovaps [rsp+0x10], xmm1
00007175dc9db8e2  vmovaps [rsp+0x20], xmm2
00007175dc9db8e8  vmovaps [rsp+0x30], xmm3
00007175dc9db8ee  vmovaps [rsp+0x40], xmm4
00007175dc9db8f4  vmovaps [rsp+0x50], xmm5
00007175dc9db8fa  vmovaps [rsp+0x60], xmm6
00007175dc9db900  vmovaps [rsp+0x70], xmm7
00007175dc9db906  vmovaps [rsp+0x80], xmm8
00007175dc9db90f  vmovaps [rsp+0x90], xmm9
00007175dc9db918  vmovaps [rsp+0xA0], xmm11
00007175dc9db921  vmovaps [rsp+0xB0], xmm12
00007175dc9db92a  vmovaps [rsp+0xC0], xmm13
00007175dc9db933  vmovaps [rsp+0xD0], xmm14
00007175dc9db93c  vmovaps [rsp+0xE0], xmm15
00007175dc9db945  sub rsp, 0x40
00007175dc9db949  lea rdi, [rsp]
00007175dc9db94d  lea rsi, [rsp+0x10]
00007175dc9db952  lea rdx, [rsp+0x20]
00007175dc9db957  lea rcx, [rsp+0x30]
00007175dc9db95c  mov r8d, 0x00
00007175dc9db962  lea r9, [r15+0x3A8]
00007175dc9db969  movaps [rdi], xmm10
00007175dc9db96d  movaps [rsi], xmm9
00007175dc9db971  movaps [rdx], xmm7
00007175dc9db974  movaps [rcx], xmm14
00007175dc9db978  mov rax, 0x622B29CAFA50
00007175dc9db982  call rax
00007175dc9db984  movaps xmm10, [rsp]
00007175dc9db989  add rsp, 0x40
00007175dc9db98d  vmovaps xmm0, [rsp]
00007175dc9db992  vmovaps xmm1, [rsp+0x10]
00007175dc9db998  vmovaps xmm2, [rsp+0x20]
00007175dc9db99e  vmovaps xmm3, [rsp+0x30]
00007175dc9db9a4  vmovaps xmm4, [rsp+0x40]
00007175dc9db9aa  vmovaps xmm5, [rsp+0x50]
00007175dc9db9b0  vmovaps xmm6, [rsp+0x60]
00007175dc9db9b6  vmovaps xmm7, [rsp+0x70]
00007175dc9db9bc  vmovaps xmm8, [rsp+0x80]
00007175dc9db9c5  vmovaps xmm9, [rsp+0x90]
00007175dc9db9ce  vmovaps xmm11, [rsp+0xA0]
00007175dc9db9d7  vmovaps xmm12, [rsp+0xB0]
00007175dc9db9e0  vmovaps xmm13, [rsp+0xC0]
00007175dc9db9e9  vmovaps xmm14, [rsp+0xD0]
00007175dc9db9f2  vmovaps xmm15, [rsp+0xE0]
00007175dc9db9fb  add rsp, 0xF0
00007175dc9dba02  pop r11
00007175dc9dba04  pop r10
00007175dc9dba06  pop r9
00007175dc9dba08  pop r8
00007175dc9dba0a  pop rsi
00007175dc9dba0b  pop rdi
00007175dc9dba0c  pop rdx
00007175dc9dba0d  pop rcx
00007175dc9dba0e  pop rax
00007175dc9dba0f  add rsp, 0x08
00007175dc9dba13  jmp 0x00007175DC9DA27C
00007175dc9dba18  call 0x00007175DC80D4E0
00007175dc9dba1d  jmp 0x00007175DC9DA289
00007175dc9dba22  sub rsp, 0x08
00007175dc9dba26  push rax
00007175dc9dba27  push rcx
00007175dc9dba28  push rdx
00007175dc9dba29  push rdi
00007175dc9dba2a  push rsi
00007175dc9dba2b  push r8
00007175dc9dba2d  push r9
00007175dc9dba2f  push r10
00007175dc9dba31  push r11
00007175dc9dba33  sub rsp, 0xF0
00007175dc9dba3a  vmovaps [rsp], xmm0
00007175dc9dba3f  vmovaps [rsp+0x10], xmm1
00007175dc9dba45  vmovaps [rsp+0x20], xmm2
00007175dc9dba4b  vmovaps [rsp+0x30], xmm3
00007175dc9dba51  vmovaps [rsp+0x40], xmm4
00007175dc9dba57  vmovaps [rsp+0x50], xmm6
00007175dc9dba5d  vmovaps [rsp+0x60], xmm7
00007175dc9dba63  vmovaps [rsp+0x70], xmm8
00007175dc9dba69  vmovaps [rsp+0x80], xmm9
00007175dc9dba72  vmovaps [rsp+0x90], xmm10
00007175dc9dba7b  vmovaps [rsp+0xA0], xmm11
00007175dc9dba84  vmovaps [rsp+0xB0], xmm12
00007175dc9dba8d  vmovaps [rsp+0xC0], xmm13
00007175dc9dba96  vmovaps [rsp+0xD0], xmm14
00007175dc9dba9f  vmovaps [rsp+0xE0], xmm15
00007175dc9dbaa8  sub rsp, 0x40
00007175dc9dbaac  lea rdi, [rsp]
00007175dc9dbab0  lea rsi, [rsp+0x10]
00007175dc9dbab5  lea rdx, [rsp+0x20]
00007175dc9dbaba  lea rcx, [rsp+0x30]
00007175dc9dbabf  mov r8d, 0x00
00007175dc9dbac5  lea r9, [r15+0x3A8]
00007175dc9dbacc  movaps [rdi], xmm5
00007175dc9dbacf  movaps [rsi], xmm6
00007175dc9dbad2  movaps [rdx], xmm7
00007175dc9dbad5  movaps [rcx], xmm9
00007175dc9dbad9  mov rax, 0x622B29CAFA50
00007175dc9dbae3  call rax
00007175dc9dbae5  movaps xmm5, [rsp]
00007175dc9dbae9  add rsp, 0x40
00007175dc9dbaed  vmovaps xmm0, [rsp]
00007175dc9dbaf2  vmovaps xmm1, [rsp+0x10]
00007175dc9dbaf8  vmovaps xmm2, [rsp+0x20]
00007175dc9dbafe  vmovaps xmm3, [rsp+0x30]
00007175dc9dbb04  vmovaps xmm4, [rsp+0x40]
00007175dc9dbb0a  vmovaps xmm6, [rsp+0x50]
00007175dc9dbb10  vmovaps xmm7, [rsp+0x60]
00007175dc9dbb16  vmovaps xmm8, [rsp+0x70]
00007175dc9dbb1c  vmovaps xmm9, [rsp+0x80]
00007175dc9dbb25  vmovaps xmm10, [rsp+0x90]
00007175dc9dbb2e  vmovaps xmm11, [rsp+0xA0]
00007175dc9dbb37  vmovaps xmm12, [rsp+0xB0]
00007175dc9dbb40  vmovaps xmm13, [rsp+0xC0]
00007175dc9dbb49  vmovaps xmm14, [rsp+0xD0]
00007175dc9dbb52  vmovaps xmm15, [rsp+0xE0]
00007175dc9dbb5b  add rsp, 0xF0
00007175dc9dbb62  pop r11
00007175dc9dbb64  pop r10
00007175dc9dbb66  pop r9
00007175dc9dbb68  pop r8
00007175dc9dbb6a  pop rsi
00007175dc9dbb6b  pop rdi
00007175dc9dbb6c  pop rdx
00007175dc9dbb6d  pop rcx
00007175dc9dbb6e  pop rax
00007175dc9dbb6f  add rsp, 0x08
00007175dc9dbb73  jmp 0x00007175DC9DA2BB
00007175dc9dbb78  sub rsp, 0x08
00007175dc9dbb7c  push rax
00007175dc9dbb7d  push rcx
00007175dc9dbb7e  push rdx
00007175dc9dbb7f  push rdi
00007175dc9dbb80  push rsi
00007175dc9dbb81  push r8
00007175dc9dbb83  push r9
00007175dc9dbb85  push r10
00007175dc9dbb87  push r11
00007175dc9dbb89  sub rsp, 0xF0
00007175dc9dbb90  vmovaps [rsp], xmm0
00007175dc9dbb95  vmovaps [rsp+0x10], xmm1
00007175dc9dbb9b  vmovaps [rsp+0x20], xmm2
00007175dc9dbba1  vmovaps [rsp+0x30], xmm3
00007175dc9dbba7  vmovaps [rsp+0x40], xmm4
00007175dc9dbbad  vmovaps [rsp+0x50], xmm5
00007175dc9dbbb3  vmovaps [rsp+0x60], xmm6
00007175dc9dbbb9  vmovaps [rsp+0x70], xmm8
00007175dc9dbbbf  vmovaps [rsp+0x80], xmm9
00007175dc9dbbc8  vmovaps [rsp+0x90], xmm10
00007175dc9dbbd1  vmovaps [rsp+0xA0], xmm11
00007175dc9dbbda  vmovaps [rsp+0xB0], xmm12
00007175dc9dbbe3  vmovaps [rsp+0xC0], xmm13
00007175dc9dbbec  vmovaps [rsp+0xD0], xmm14
00007175dc9dbbf5  vmovaps [rsp+0xE0], xmm15
00007175dc9dbbfe  sub rsp, 0x40
00007175dc9dbc02  lea rdi, [rsp]
00007175dc9dbc06  lea rsi, [rsp+0x10]
00007175dc9dbc0b  lea rdx, [rsp+0x20]
00007175dc9dbc10  lea rcx, [rsp+0x30]
00007175dc9dbc15  mov r8d, 0x00
00007175dc9dbc1b  lea r9, [r15+0x3A8]
00007175dc9dbc22  movaps [rdi], xmm7
00007175dc9dbc25  movaps [rsi], xmm13
00007175dc9dbc29  movaps [rdx], xmm1
00007175dc9dbc2c  movaps [rcx], xmm9
00007175dc9dbc30  mov rax, 0x622B29CAFA50
00007175dc9dbc3a  call rax
00007175dc9dbc3c  movaps xmm7, [rsp]
00007175dc9dbc40  add rsp, 0x40
00007175dc9dbc44  vmovaps xmm0, [rsp]
00007175dc9dbc49  vmovaps xmm1, [rsp+0x10]
00007175dc9dbc4f  vmovaps xmm2, [rsp+0x20]
00007175dc9dbc55  vmovaps xmm3, [rsp+0x30]
00007175dc9dbc5b  vmovaps xmm4, [rsp+0x40]
00007175dc9dbc61  vmovaps xmm5, [rsp+0x50]
00007175dc9dbc67  vmovaps xmm6, [rsp+0x60]
00007175dc9dbc6d  vmovaps xmm8, [rsp+0x70]
00007175dc9dbc73  vmovaps xmm9, [rsp+0x80]
00007175dc9dbc7c  vmovaps xmm10, [rsp+0x90]
00007175dc9dbc85  vmovaps xmm11, [rsp+0xA0]
00007175dc9dbc8e  vmovaps xmm12, [rsp+0xB0]
00007175dc9dbc97  vmovaps xmm13, [rsp+0xC0]
00007175dc9dbca0  vmovaps xmm14, [rsp+0xD0]
00007175dc9dbca9  vmovaps xmm15, [rsp+0xE0]
00007175dc9dbcb2  add rsp, 0xF0
00007175dc9dbcb9  pop r11
00007175dc9dbcbb  pop r10
00007175dc9dbcbd  pop r9
00007175dc9dbcbf  pop r8
00007175dc9dbcc1  pop rsi
00007175dc9dbcc2  pop rdi
00007175dc9dbcc3  pop rdx
00007175dc9dbcc4  pop rcx
00007175dc9dbcc5  pop rax
00007175dc9dbcc6  add rsp, 0x08
00007175dc9dbcca  jmp 0x00007175DC9DA2E0
00007175dc9dbccf  call 0x00007175DC80C260
00007175dc9dbcd4  jmp 0x00007175DC9DA303
00007175dc9dbcd9  call 0x00007175DC807890
00007175dc9dbcde  jmp 0x00007175DC9DA30D
00007175dc9dbce3  sub rsp, 0x08
00007175dc9dbce7  push rax
00007175dc9dbce8  push rcx
00007175dc9dbce9  push rdx
00007175dc9dbcea  push rdi
00007175dc9dbceb  push rsi
00007175dc9dbcec  push r8
00007175dc9dbcee  push r9
00007175dc9dbcf0  push r10
00007175dc9dbcf2  push r11
00007175dc9dbcf4  sub rsp, 0xF0
00007175dc9dbcfb  vmovaps [rsp], xmm0
00007175dc9dbd00  vmovaps [rsp+0x10], xmm1
00007175dc9dbd06  vmovaps [rsp+0x20], xmm3
00007175dc9dbd0c  vmovaps [rsp+0x30], xmm4
00007175dc9dbd12  vmovaps [rsp+0x40], xmm5
00007175dc9dbd18  vmovaps [rsp+0x50], xmm6
00007175dc9dbd1e  vmovaps [rsp+0x60], xmm7
00007175dc9dbd24  vmovaps [rsp+0x70], xmm8
00007175dc9dbd2a  vmovaps [rsp+0x80], xmm9
00007175dc9dbd33  vmovaps [rsp+0x90], xmm10
00007175dc9dbd3c  vmovaps [rsp+0xA0], xmm11
00007175dc9dbd45  vmovaps [rsp+0xB0], xmm12
00007175dc9dbd4e  vmovaps [rsp+0xC0], xmm13
00007175dc9dbd57  vmovaps [rsp+0xD0], xmm14
00007175dc9dbd60  vmovaps [rsp+0xE0], xmm15
00007175dc9dbd69  sub rsp, 0x40
00007175dc9dbd6d  lea rdi, [rsp]
00007175dc9dbd71  lea rsi, [rsp+0x10]
00007175dc9dbd76  lea rdx, [rsp+0x20]
00007175dc9dbd7b  lea rcx, [rsp+0x30]
00007175dc9dbd80  mov r8d, 0x00
00007175dc9dbd86  lea r9, [r15+0x3A8]
00007175dc9dbd8d  movaps [rdi], xmm2
00007175dc9dbd90  movaps [rsi], xmm12
00007175dc9dbd94  movaps [rdx], xmm6
00007175dc9dbd97  movaps [rcx], xmm3
00007175dc9dbd9a  mov rax, 0x622B29CAFA50
00007175dc9dbda4  call rax
00007175dc9dbda6  movaps xmm2, [rsp]
00007175dc9dbdaa  add rsp, 0x40
00007175dc9dbdae  vmovaps xmm0, [rsp]
00007175dc9dbdb3  vmovaps xmm1, [rsp+0x10]
00007175dc9dbdb9  vmovaps xmm3, [rsp+0x20]
00007175dc9dbdbf  vmovaps xmm4, [rsp+0x30]
00007175dc9dbdc5  vmovaps xmm5, [rsp+0x40]
00007175dc9dbdcb  vmovaps xmm6, [rsp+0x50]
00007175dc9dbdd1  vmovaps xmm7, [rsp+0x60]
00007175dc9dbdd7  vmovaps xmm8, [rsp+0x70]
00007175dc9dbddd  vmovaps xmm9, [rsp+0x80]
00007175dc9dbde6  vmovaps xmm10, [rsp+0x90]
00007175dc9dbdef  vmovaps xmm11, [rsp+0xA0]
00007175dc9dbdf8  vmovaps xmm12, [rsp+0xB0]
00007175dc9dbe01  vmovaps xmm13, [rsp+0xC0]
00007175dc9dbe0a  vmovaps xmm14, [rsp+0xD0]
00007175dc9dbe13  vmovaps xmm15, [rsp+0xE0]
00007175dc9dbe1c  add rsp, 0xF0
00007175dc9dbe23  pop r11
00007175dc9dbe25  pop r10
00007175dc9dbe27  pop r9
00007175dc9dbe29  pop r8
00007175dc9dbe2b  pop rsi
00007175dc9dbe2c  pop rdi
00007175dc9dbe2d  pop rdx
00007175dc9dbe2e  pop rcx
00007175dc9dbe2f  pop rax
00007175dc9dbe30  add rsp, 0x08
00007175dc9dbe34  jmp 0x00007175DC9DA353
00007175dc9dbe39  sub rsp, 0x08
00007175dc9dbe3d  push rax
00007175dc9dbe3e  push rcx
00007175dc9dbe3f  push rdx
00007175dc9dbe40  push rdi
00007175dc9dbe41  push rsi
00007175dc9dbe42  push r8
00007175dc9dbe44  push r9
00007175dc9dbe46  push r10
00007175dc9dbe48  push r11
00007175dc9dbe4a  sub rsp, 0xF0
00007175dc9dbe51  vmovaps [rsp], xmm0
00007175dc9dbe56  vmovaps [rsp+0x10], xmm1
00007175dc9dbe5c  vmovaps [rsp+0x20], xmm2
00007175dc9dbe62  vmovaps [rsp+0x30], xmm3
00007175dc9dbe68  vmovaps [rsp+0x40], xmm4
00007175dc9dbe6e  vmovaps [rsp+0x50], xmm5
00007175dc9dbe74  vmovaps [rsp+0x60], xmm7
00007175dc9dbe7a  vmovaps [rsp+0x70], xmm8
00007175dc9dbe80  vmovaps [rsp+0x80], xmm9
00007175dc9dbe89  vmovaps [rsp+0x90], xmm10
00007175dc9dbe92  vmovaps [rsp+0xA0], xmm11
00007175dc9dbe9b  vmovaps [rsp+0xB0], xmm12
00007175dc9dbea4  vmovaps [rsp+0xC0], xmm13
00007175dc9dbead  vmovaps [rsp+0xD0], xmm14
00007175dc9dbeb6  vmovaps [rsp+0xE0], xmm15
00007175dc9dbebf  sub rsp, 0x40
00007175dc9dbec3  lea rdi, [rsp]
00007175dc9dbec7  lea rsi, [rsp+0x10]
00007175dc9dbecc  lea rdx, [rsp+0x20]
00007175dc9dbed1  lea rcx, [rsp+0x30]
00007175dc9dbed6  mov r8d, 0x00
00007175dc9dbedc  lea r9, [r15+0x3A8]
00007175dc9dbee3  movaps [rdi], xmm6
00007175dc9dbee6  movaps [rsi], xmm10
00007175dc9dbeea  movaps [rdx], xmm12
00007175dc9dbeee  movaps [rcx], xmm1
00007175dc9dbef1  mov rax, 0x622B29CAFA50
00007175dc9dbefb  call rax
00007175dc9dbefd  movaps xmm6, [rsp]
00007175dc9dbf01  add rsp, 0x40
00007175dc9dbf05  vmovaps xmm0, [rsp]
00007175dc9dbf0a  vmovaps xmm1, [rsp+0x10]
00007175dc9dbf10  vmovaps xmm2, [rsp+0x20]
00007175dc9dbf16  vmovaps xmm3, [rsp+0x30]
00007175dc9dbf1c  vmovaps xmm4, [rsp+0x40]
00007175dc9dbf22  vmovaps xmm5, [rsp+0x50]
00007175dc9dbf28  vmovaps xmm7, [rsp+0x60]
00007175dc9dbf2e  vmovaps xmm8, [rsp+0x70]
00007175dc9dbf34  vmovaps xmm9, [rsp+0x80]
00007175dc9dbf3d  vmovaps xmm10, [rsp+0x90]
00007175dc9dbf46  vmovaps xmm11, [rsp+0xA0]
00007175dc9dbf4f  vmovaps xmm12, [rsp+0xB0]
00007175dc9dbf58  vmovaps xmm13, [rsp+0xC0]
00007175dc9dbf61  vmovaps xmm14, [rsp+0xD0]
00007175dc9dbf6a  vmovaps xmm15, [rsp+0xE0]
00007175dc9dbf73  add rsp, 0xF0
00007175dc9dbf7a  pop r11
00007175dc9dbf7c  pop r10
00007175dc9dbf7e  pop r9
00007175dc9dbf80  pop r8
00007175dc9dbf82  pop rsi
00007175dc9dbf83  pop rdi
00007175dc9dbf84  pop rdx
00007175dc9dbf85  pop rcx
00007175dc9dbf86  pop rax
00007175dc9dbf87  add rsp, 0x08
00007175dc9dbf8b  jmp 0x00007175DC9DA381
00007175dc9dbf90  sub rsp, 0x08
00007175dc9dbf94  push rax
00007175dc9dbf95  push rcx
00007175dc9dbf96  push rdx
00007175dc9dbf97  push rdi
00007175dc9dbf98  push rsi
00007175dc9dbf99  push r8
00007175dc9dbf9b  push r9
00007175dc9dbf9d  push r10
00007175dc9dbf9f  push r11
00007175dc9dbfa1  sub rsp, 0xF0
00007175dc9dbfa8  vmovaps [rsp], xmm0
00007175dc9dbfad  vmovaps [rsp+0x10], xmm1
00007175dc9dbfb3  vmovaps [rsp+0x20], xmm2
00007175dc9dbfb9  vmovaps [rsp+0x30], xmm3
00007175dc9dbfbf  vmovaps [rsp+0x40], xmm4
00007175dc9dbfc5  vmovaps [rsp+0x50], xmm5
00007175dc9dbfcb  vmovaps [rsp+0x60], xmm6
00007175dc9dbfd1  vmovaps [rsp+0x70], xmm7
00007175dc9dbfd7  vmovaps [rsp+0x80], xmm8
00007175dc9dbfe0  vmovaps [rsp+0x90], xmm9
00007175dc9dbfe9  vmovaps [rsp+0xA0], xmm11
00007175dc9dbff2  vmovaps [rsp+0xB0], xmm12
00007175dc9dbffb  vmovaps [rsp+0xC0], xmm13
00007175dc9dc004  vmovaps [rsp+0xD0], xmm14
00007175dc9dc00d  vmovaps [rsp+0xE0], xmm15
00007175dc9dc016  sub rsp, 0x40
00007175dc9dc01a  lea rdi, [rsp]
00007175dc9dc01e  lea rsi, [rsp+0x10]
00007175dc9dc023  lea rdx, [rsp+0x20]
00007175dc9dc028  lea rcx, [rsp+0x30]
00007175dc9dc02d  mov r8d, 0x00
00007175dc9dc033  lea r9, [r15+0x3A8]
00007175dc9dc03a  movaps [rdi], xmm10
00007175dc9dc03e  movaps [rsi], xmm5
00007175dc9dc041  movaps [rdx], xmm12
00007175dc9dc045  movaps [rcx], xmm1
00007175dc9dc048  mov rax, 0x622B29CAFA50
00007175dc9dc052  call rax
00007175dc9dc054  movaps xmm10, [rsp]
00007175dc9dc059  add rsp, 0x40
00007175dc9dc05d  vmovaps xmm0, [rsp]
00007175dc9dc062  vmovaps xmm1, [rsp+0x10]
00007175dc9dc068  vmovaps xmm2, [rsp+0x20]
00007175dc9dc06e  vmovaps xmm3, [rsp+0x30]
00007175dc9dc074  vmovaps xmm4, [rsp+0x40]
00007175dc9dc07a  vmovaps xmm5, [rsp+0x50]
00007175dc9dc080  vmovaps xmm6, [rsp+0x60]
00007175dc9dc086  vmovaps xmm7, [rsp+0x70]
00007175dc9dc08c  vmovaps xmm8, [rsp+0x80]
00007175dc9dc095  vmovaps xmm9, [rsp+0x90]
00007175dc9dc09e  vmovaps xmm11, [rsp+0xA0]
00007175dc9dc0a7  vmovaps xmm12, [rsp+0xB0]
00007175dc9dc0b0  vmovaps xmm13, [rsp+0xC0]
00007175dc9dc0b9  vmovaps xmm14, [rsp+0xD0]
00007175dc9dc0c2  vmovaps xmm15, [rsp+0xE0]
00007175dc9dc0cb  add rsp, 0xF0
00007175dc9dc0d2  pop r11
00007175dc9dc0d4  pop r10
00007175dc9dc0d6  pop r9
00007175dc9dc0d8  pop r8
00007175dc9dc0da  pop rsi
00007175dc9dc0db  pop rdi
00007175dc9dc0dc  pop rdx
00007175dc9dc0dd  pop rcx
00007175dc9dc0de  pop rax
00007175dc9dc0df  add rsp, 0x08
00007175dc9dc0e3  jmp 0x00007175DC9DA3B0
00007175dc9dc0e8  sub rsp, 0x08
00007175dc9dc0ec  push rax
00007175dc9dc0ed  push rcx
00007175dc9dc0ee  push rdx
00007175dc9dc0ef  push rdi
00007175dc9dc0f0  push rsi
00007175dc9dc0f1  push r8
00007175dc9dc0f3  push r9
00007175dc9dc0f5  push r10
00007175dc9dc0f7  push r11
00007175dc9dc0f9  sub rsp, 0xF0
00007175dc9dc100  vmovaps [rsp], xmm0
00007175dc9dc105  vmovaps [rsp+0x10], xmm1
00007175dc9dc10b  vmovaps [rsp+0x20], xmm2
00007175dc9dc111  vmovaps [rsp+0x30], xmm3
00007175dc9dc117  vmovaps [rsp+0x40], xmm4
00007175dc9dc11d  vmovaps [rsp+0x50], xmm5
00007175dc9dc123  vmovaps [rsp+0x60], xmm6
00007175dc9dc129  vmovaps [rsp+0x70], xmm7
00007175dc9dc12f  vmovaps [rsp+0x80], xmm8
00007175dc9dc138  vmovaps [rsp+0x90], xmm9
00007175dc9dc141  vmovaps [rsp+0xA0], xmm10
00007175dc9dc14a  vmovaps [rsp+0xB0], xmm11
00007175dc9dc153  vmovaps [rsp+0xC0], xmm13
00007175dc9dc15c  vmovaps [rsp+0xD0], xmm14
00007175dc9dc165  vmovaps [rsp+0xE0], xmm15
00007175dc9dc16e  sub rsp, 0x40
00007175dc9dc172  lea rdi, [rsp]
00007175dc9dc176  lea rsi, [rsp+0x10]
00007175dc9dc17b  lea rdx, [rsp+0x20]
00007175dc9dc180  lea rcx, [rsp+0x30]
00007175dc9dc185  mov r8d, 0x00
00007175dc9dc18b  lea r9, [r15+0x3A8]
00007175dc9dc192  movaps [rdi], xmm12
00007175dc9dc196  movaps [rsi], xmm7
00007175dc9dc199  movaps [rdx], xmm15
00007175dc9dc19d  movaps [rcx], xmm1
00007175dc9dc1a0  mov rax, 0x622B29CAFA50
00007175dc9dc1aa  call rax
00007175dc9dc1ac  movaps xmm12, [rsp]
00007175dc9dc1b1  add rsp, 0x40
00007175dc9dc1b5  vmovaps xmm0, [rsp]
00007175dc9dc1ba  vmovaps xmm1, [rsp+0x10]
00007175dc9dc1c0  vmovaps xmm2, [rsp+0x20]
00007175dc9dc1c6  vmovaps xmm3, [rsp+0x30]
00007175dc9dc1cc  vmovaps xmm4, [rsp+0x40]
00007175dc9dc1d2  vmovaps xmm5, [rsp+0x50]
00007175dc9dc1d8  vmovaps xmm6, [rsp+0x60]
00007175dc9dc1de  vmovaps xmm7, [rsp+0x70]
00007175dc9dc1e4  vmovaps xmm8, [rsp+0x80]
00007175dc9dc1ed  vmovaps xmm9, [rsp+0x90]
00007175dc9dc1f6  vmovaps xmm10, [rsp+0xA0]
00007175dc9dc1ff  vmovaps xmm11, [rsp+0xB0]
00007175dc9dc208  vmovaps xmm13, [rsp+0xC0]
00007175dc9dc211  vmovaps xmm14, [rsp+0xD0]
00007175dc9dc21a  vmovaps xmm15, [rsp+0xE0]
00007175dc9dc223  add rsp, 0xF0
00007175dc9dc22a  pop r11
00007175dc9dc22c  pop r10
00007175dc9dc22e  pop r9
00007175dc9dc230  pop r8
00007175dc9dc232  pop rsi
00007175dc9dc233  pop rdi
00007175dc9dc234  pop rdx
00007175dc9dc235  pop rcx
00007175dc9dc236  pop rax
00007175dc9dc237  add rsp, 0x08
00007175dc9dc23b  jmp 0x00007175DC9DA3D9
00007175dc9dc240  call 0x00007175DC7FF430
00007175dc9dc245  jmp 0x00007175DC9DA3E3
00007175dc9dc24a  call 0x00007175DC80E760
00007175dc9dc24f  jmp 0x00007175DC9DA3ED
00007175dc9dc254  sub rsp, 0x08
00007175dc9dc258  push rax
00007175dc9dc259  push rcx
00007175dc9dc25a  push rdx
00007175dc9dc25b  push rdi
00007175dc9dc25c  push rsi
00007175dc9dc25d  push r8
00007175dc9dc25f  push r9
00007175dc9dc261  push r10
00007175dc9dc263  push r11
00007175dc9dc265  sub rsp, 0xF0
00007175dc9dc26c  vmovaps [rsp], xmm0
00007175dc9dc271  vmovaps [rsp+0x10], xmm1
00007175dc9dc277  vmovaps [rsp+0x20], xmm2
00007175dc9dc27d  vmovaps [rsp+0x30], xmm3
00007175dc9dc283  vmovaps [rsp+0x40], xmm4
00007175dc9dc289  vmovaps [rsp+0x50], xmm5
00007175dc9dc28f  vmovaps [rsp+0x60], xmm6
00007175dc9dc295  vmovaps [rsp+0x70], xmm8
00007175dc9dc29b  vmovaps [rsp+0x80], xmm9
00007175dc9dc2a4  vmovaps [rsp+0x90], xmm10
00007175dc9dc2ad  vmovaps [rsp+0xA0], xmm11
00007175dc9dc2b6  vmovaps [rsp+0xB0], xmm12
00007175dc9dc2bf  vmovaps [rsp+0xC0], xmm13
00007175dc9dc2c8  vmovaps [rsp+0xD0], xmm14
00007175dc9dc2d1  vmovaps [rsp+0xE0], xmm15
00007175dc9dc2da  sub rsp, 0x40
00007175dc9dc2de  lea rdi, [rsp]
00007175dc9dc2e2  lea rsi, [rsp+0x10]
00007175dc9dc2e7  lea rdx, [rsp+0x20]
00007175dc9dc2ec  lea rcx, [rsp+0x30]
00007175dc9dc2f1  mov r8d, 0x00
00007175dc9dc2f7  lea r9, [r15+0x3A8]
00007175dc9dc2fe  movaps [rdi], xmm7
00007175dc9dc301  movaps [rsi], xmm2
00007175dc9dc304  movaps [rdx], xmm9
00007175dc9dc308  movaps [rcx], xmm11
00007175dc9dc30c  mov rax, 0x622B29CAFA50
00007175dc9dc316  call rax
00007175dc9dc318  movaps xmm7, [rsp]
00007175dc9dc31c  add rsp, 0x40
00007175dc9dc320  vmovaps xmm0, [rsp]
00007175dc9dc325  vmovaps xmm1, [rsp+0x10]
00007175dc9dc32b  vmovaps xmm2, [rsp+0x20]
00007175dc9dc331  vmovaps xmm3, [rsp+0x30]
00007175dc9dc337  vmovaps xmm4, [rsp+0x40]
00007175dc9dc33d  vmovaps xmm5, [rsp+0x50]
00007175dc9dc343  vmovaps xmm6, [rsp+0x60]
00007175dc9dc349  vmovaps xmm8, [rsp+0x70]
00007175dc9dc34f  vmovaps xmm9, [rsp+0x80]
00007175dc9dc358  vmovaps xmm10, [rsp+0x90]
00007175dc9dc361  vmovaps xmm11, [rsp+0xA0]
00007175dc9dc36a  vmovaps xmm12, [rsp+0xB0]
00007175dc9dc373  vmovaps xmm13, [rsp+0xC0]
00007175dc9dc37c  vmovaps xmm14, [rsp+0xD0]
00007175dc9dc385  vmovaps xmm15, [rsp+0xE0]
00007175dc9dc38e  add rsp, 0xF0
00007175dc9dc395  pop r11
00007175dc9dc397  pop r10
00007175dc9dc399  pop r9
00007175dc9dc39b  pop r8
00007175dc9dc39d  pop rsi
00007175dc9dc39e  pop rdi
00007175dc9dc39f  pop rdx
00007175dc9dc3a0  pop rcx
00007175dc9dc3a1  pop rax
00007175dc9dc3a2  add rsp, 0x08
00007175dc9dc3a6  jmp 0x00007175DC9DA421
00007175dc9dc3ab  sub rsp, 0x08
00007175dc9dc3af  push rax
00007175dc9dc3b0  push rcx
00007175dc9dc3b1  push rdx
00007175dc9dc3b2  push rdi
00007175dc9dc3b3  push rsi
00007175dc9dc3b4  push r8
00007175dc9dc3b6  push r9
00007175dc9dc3b8  push r10
00007175dc9dc3ba  push r11
00007175dc9dc3bc  sub rsp, 0xF0
00007175dc9dc3c3  vmovaps [rsp], xmm0
00007175dc9dc3c8  vmovaps [rsp+0x10], xmm1
00007175dc9dc3ce  vmovaps [rsp+0x20], xmm2
00007175dc9dc3d4  vmovaps [rsp+0x30], xmm3
00007175dc9dc3da  vmovaps [rsp+0x40], xmm4
00007175dc9dc3e0  vmovaps [rsp+0x50], xmm5
00007175dc9dc3e6  vmovaps [rsp+0x60], xmm6
00007175dc9dc3ec  vmovaps [rsp+0x70], xmm7
00007175dc9dc3f2  vmovaps [rsp+0x80], xmm8
00007175dc9dc3fb  vmovaps [rsp+0x90], xmm10
00007175dc9dc404  vmovaps [rsp+0xA0], xmm11
00007175dc9dc40d  vmovaps [rsp+0xB0], xmm12
00007175dc9dc416  vmovaps [rsp+0xC0], xmm13
00007175dc9dc41f  vmovaps [rsp+0xD0], xmm14
00007175dc9dc428  vmovaps [rsp+0xE0], xmm15
00007175dc9dc431  sub rsp, 0x40
00007175dc9dc435  lea rdi, [rsp]
00007175dc9dc439  lea rsi, [rsp+0x10]
00007175dc9dc43e  lea rdx, [rsp+0x20]
00007175dc9dc443  lea rcx, [rsp+0x30]
00007175dc9dc448  mov r8d, 0x00
00007175dc9dc44e  lea r9, [r15+0x3A8]
00007175dc9dc455  movaps [rdi], xmm9
00007175dc9dc459  movaps [rsi], xmm6
00007175dc9dc45c  movaps [rdx], xmm1
00007175dc9dc45f  movaps [rcx], xmm11
00007175dc9dc463  mov rax, 0x622B29CAFA50
00007175dc9dc46d  call rax
00007175dc9dc46f  movaps xmm9, [rsp]
00007175dc9dc474  add rsp, 0x40
00007175dc9dc478  vmovaps xmm0, [rsp]
00007175dc9dc47d  vmovaps xmm1, [rsp+0x10]
00007175dc9dc483  vmovaps xmm2, [rsp+0x20]
00007175dc9dc489  vmovaps xmm3, [rsp+0x30]
00007175dc9dc48f  vmovaps xmm4, [rsp+0x40]
00007175dc9dc495  vmovaps xmm5, [rsp+0x50]
00007175dc9dc49b  vmovaps xmm6, [rsp+0x60]
00007175dc9dc4a1  vmovaps xmm7, [rsp+0x70]
00007175dc9dc4a7  vmovaps xmm8, [rsp+0x80]
00007175dc9dc4b0  vmovaps xmm10, [rsp+0x90]
00007175dc9dc4b9  vmovaps xmm11, [rsp+0xA0]
00007175dc9dc4c2  vmovaps xmm12, [rsp+0xB0]
00007175dc9dc4cb  vmovaps xmm13, [rsp+0xC0]
00007175dc9dc4d4  vmovaps xmm14, [rsp+0xD0]
00007175dc9dc4dd  vmovaps xmm15, [rsp+0xE0]
00007175dc9dc4e6  add rsp, 0xF0
00007175dc9dc4ed  pop r11
00007175dc9dc4ef  pop r10
00007175dc9dc4f1  pop r9
00007175dc9dc4f3  pop r8
00007175dc9dc4f5  pop rsi
00007175dc9dc4f6  pop rdi
00007175dc9dc4f7  pop rdx
00007175dc9dc4f8  pop rcx
00007175dc9dc4f9  pop rax
00007175dc9dc4fa  add rsp, 0x08
00007175dc9dc4fe  jmp 0x00007175DC9DA447
00007175dc9dc503  sub rsp, 0x08
00007175dc9dc507  push rax
00007175dc9dc508  push rcx
00007175dc9dc509  push rdx
00007175dc9dc50a  push rdi
00007175dc9dc50b  push rsi
00007175dc9dc50c  push r8
00007175dc9dc50e  push r9
00007175dc9dc510  push r10
00007175dc9dc512  push r11
00007175dc9dc514  sub rsp, 0xF0
00007175dc9dc51b  vmovaps [rsp], xmm0
00007175dc9dc520  vmovaps [rsp+0x10], xmm1
00007175dc9dc526  vmovaps [rsp+0x20], xmm2
00007175dc9dc52c  vmovaps [rsp+0x30], xmm3
00007175dc9dc532  vmovaps [rsp+0x40], xmm4
00007175dc9dc538  vmovaps [rsp+0x50], xmm5
00007175dc9dc53e  vmovaps [rsp+0x60], xmm6
00007175dc9dc544  vmovaps [rsp+0x70], xmm7
00007175dc9dc54a  vmovaps [rsp+0x80], xmm8
00007175dc9dc553  vmovaps [rsp+0x90], xmm9
00007175dc9dc55c  vmovaps [rsp+0xA0], xmm10
00007175dc9dc565  vmovaps [rsp+0xB0], xmm12
00007175dc9dc56e  vmovaps [rsp+0xC0], xmm13
00007175dc9dc577  vmovaps [rsp+0xD0], xmm14
00007175dc9dc580  vmovaps [rsp+0xE0], xmm15
00007175dc9dc589  sub rsp, 0x40
00007175dc9dc58d  lea rdi, [rsp]
00007175dc9dc591  lea rsi, [rsp+0x10]
00007175dc9dc596  lea rdx, [rsp+0x20]
00007175dc9dc59b  lea rcx, [rsp+0x30]
00007175dc9dc5a0  mov r8d, 0x00
00007175dc9dc5a6  lea r9, [r15+0x3A8]
00007175dc9dc5ad  movaps [rdi], xmm11
00007175dc9dc5b1  movaps [rsi], xmm10
00007175dc9dc5b5  movaps [rdx], xmm8
00007175dc9dc5b9  movaps [rcx], xmm1
00007175dc9dc5bc  mov rax, 0x622B29CAFA50
00007175dc9dc5c6  call rax
00007175dc9dc5c8  movaps xmm11, [rsp]
00007175dc9dc5cd  add rsp, 0x40
00007175dc9dc5d1  vmovaps xmm0, [rsp]
00007175dc9dc5d6  vmovaps xmm1, [rsp+0x10]
00007175dc9dc5dc  vmovaps xmm2, [rsp+0x20]
00007175dc9dc5e2  vmovaps xmm3, [rsp+0x30]
00007175dc9dc5e8  vmovaps xmm4, [rsp+0x40]
00007175dc9dc5ee  vmovaps xmm5, [rsp+0x50]
00007175dc9dc5f4  vmovaps xmm6, [rsp+0x60]
00007175dc9dc5fa  vmovaps xmm7, [rsp+0x70]
00007175dc9dc600  vmovaps xmm8, [rsp+0x80]
00007175dc9dc609  vmovaps xmm9, [rsp+0x90]
00007175dc9dc612  vmovaps xmm10, [rsp+0xA0]
00007175dc9dc61b  vmovaps xmm12, [rsp+0xB0]
00007175dc9dc624  vmovaps xmm13, [rsp+0xC0]
00007175dc9dc62d  vmovaps xmm14, [rsp+0xD0]
00007175dc9dc636  vmovaps xmm15, [rsp+0xE0]
00007175dc9dc63f  add rsp, 0xF0
00007175dc9dc646  pop r11
00007175dc9dc648  pop r10
00007175dc9dc64a  pop r9
00007175dc9dc64c  pop r8
00007175dc9dc64e  pop rsi
00007175dc9dc64f  pop rdi
00007175dc9dc650  pop rdx
00007175dc9dc651  pop rcx
00007175dc9dc652  pop rax
00007175dc9dc653  add rsp, 0x08
00007175dc9dc657  jmp 0x00007175DC9DA46D
00007175dc9dc65c  sub rsp, 0x08
00007175dc9dc660  push rax
00007175dc9dc661  push rcx
00007175dc9dc662  push rdx
00007175dc9dc663  push rdi
00007175dc9dc664  push rsi
00007175dc9dc665  push r8
00007175dc9dc667  push r9
00007175dc9dc669  push r10
00007175dc9dc66b  push r11
00007175dc9dc66d  sub rsp, 0xF0
00007175dc9dc674  vmovaps [rsp], xmm0
00007175dc9dc679  vmovaps [rsp+0x10], xmm1
00007175dc9dc67f  vmovaps [rsp+0x20], xmm2
00007175dc9dc685  vmovaps [rsp+0x30], xmm3
00007175dc9dc68b  vmovaps [rsp+0x40], xmm4
00007175dc9dc691  vmovaps [rsp+0x50], xmm5
00007175dc9dc697  vmovaps [rsp+0x60], xmm6
00007175dc9dc69d  vmovaps [rsp+0x70], xmm7
00007175dc9dc6a3  vmovaps [rsp+0x80], xmm8
00007175dc9dc6ac  vmovaps [rsp+0x90], xmm9
00007175dc9dc6b5  vmovaps [rsp+0xA0], xmm11
00007175dc9dc6be  vmovaps [rsp+0xB0], xmm12
00007175dc9dc6c7  vmovaps [rsp+0xC0], xmm13
00007175dc9dc6d0  vmovaps [rsp+0xD0], xmm14
00007175dc9dc6d9  vmovaps [rsp+0xE0], xmm15
00007175dc9dc6e2  sub rsp, 0x40
00007175dc9dc6e6  lea rdi, [rsp]
00007175dc9dc6ea  lea rsi, [rsp+0x10]
00007175dc9dc6ef  lea rdx, [rsp+0x20]
00007175dc9dc6f4  lea rcx, [rsp+0x30]
00007175dc9dc6f9  mov r8d, 0x00
00007175dc9dc6ff  lea r9, [r15+0x3A8]
00007175dc9dc706  movaps [rdi], xmm10
00007175dc9dc70a  movaps [rsi], xmm12
00007175dc9dc70e  movaps [rdx], xmm13
00007175dc9dc712  movaps [rcx], xmm1
00007175dc9dc715  mov rax, 0x622B29CAFA50
00007175dc9dc71f  call rax
00007175dc9dc721  movaps xmm10, [rsp]
00007175dc9dc726  add rsp, 0x40
00007175dc9dc72a  vmovaps xmm0, [rsp]
00007175dc9dc72f  vmovaps xmm1, [rsp+0x10]
00007175dc9dc735  vmovaps xmm2, [rsp+0x20]
00007175dc9dc73b  vmovaps xmm3, [rsp+0x30]
00007175dc9dc741  vmovaps xmm4, [rsp+0x40]
00007175dc9dc747  vmovaps xmm5, [rsp+0x50]
00007175dc9dc74d  vmovaps xmm6, [rsp+0x60]
00007175dc9dc753  vmovaps xmm7, [rsp+0x70]
00007175dc9dc759  vmovaps xmm8, [rsp+0x80]
00007175dc9dc762  vmovaps xmm9, [rsp+0x90]
00007175dc9dc76b  vmovaps xmm11, [rsp+0xA0]
00007175dc9dc774  vmovaps xmm12, [rsp+0xB0]
00007175dc9dc77d  vmovaps xmm13, [rsp+0xC0]
00007175dc9dc786  vmovaps xmm14, [rsp+0xD0]
00007175dc9dc78f  vmovaps xmm15, [rsp+0xE0]
00007175dc9dc798  add rsp, 0xF0
00007175dc9dc79f  pop r11
00007175dc9dc7a1  pop r10
00007175dc9dc7a3  pop r9
00007175dc9dc7a5  pop r8
00007175dc9dc7a7  pop rsi
00007175dc9dc7a8  pop rdi
00007175dc9dc7a9  pop rdx
00007175dc9dc7aa  pop rcx
00007175dc9dc7ab  pop rax
00007175dc9dc7ac  add rsp, 0x08
00007175dc9dc7b0  jmp 0x00007175DC9DA493
00007175dc9dc7b5  call 0x00007175DC7FF430
00007175dc9dc7ba  jmp 0x00007175DC9DA49D
00007175dc9dc7bf  call 0x00007175DC80C260
00007175dc9dc7c4  jmp 0x00007175DC9DA4A7
00007175dc9dc7c9  sub rsp, 0x08
00007175dc9dc7cd  push rax
00007175dc9dc7ce  push rcx
00007175dc9dc7cf  push rdx
00007175dc9dc7d0  push rdi
00007175dc9dc7d1  push rsi
00007175dc9dc7d2  push r8
00007175dc9dc7d4  push r9
00007175dc9dc7d6  push r10
00007175dc9dc7d8  push r11
00007175dc9dc7da  sub rsp, 0xF0
00007175dc9dc7e1  vmovaps [rsp], xmm0
00007175dc9dc7e6  vmovaps [rsp+0x10], xmm1
00007175dc9dc7ec  vmovaps [rsp+0x20], xmm2
00007175dc9dc7f2  vmovaps [rsp+0x30], xmm3
00007175dc9dc7f8  vmovaps [rsp+0x40], xmm4
00007175dc9dc7fe  vmovaps [rsp+0x50], xmm5
00007175dc9dc804  vmovaps [rsp+0x60], xmm6
00007175dc9dc80a  vmovaps [rsp+0x70], xmm7
00007175dc9dc810  vmovaps [rsp+0x80], xmm9
00007175dc9dc819  vmovaps [rsp+0x90], xmm10
00007175dc9dc822  vmovaps [rsp+0xA0], xmm11
00007175dc9dc82b  vmovaps [rsp+0xB0], xmm12
00007175dc9dc834  vmovaps [rsp+0xC0], xmm13
00007175dc9dc83d  vmovaps [rsp+0xD0], xmm14
00007175dc9dc846  vmovaps [rsp+0xE0], xmm15
00007175dc9dc84f  sub rsp, 0x40
00007175dc9dc853  lea rdi, [rsp]
00007175dc9dc857  lea rsi, [rsp+0x10]
00007175dc9dc85c  lea rdx, [rsp+0x20]
00007175dc9dc861  lea rcx, [rsp+0x30]
00007175dc9dc866  mov r8d, 0x00
00007175dc9dc86c  lea r9, [r15+0x3A8]
00007175dc9dc873  movaps [rdi], xmm8
00007175dc9dc877  movaps [rsi], xmm7
00007175dc9dc87a  movaps [rdx], xmm4
00007175dc9dc87d  movaps [rcx], xmm12
00007175dc9dc881  mov rax, 0x622B29CAFA50
00007175dc9dc88b  call rax
00007175dc9dc88d  movaps xmm8, [rsp]
00007175dc9dc892  add rsp, 0x40
00007175dc9dc896  vmovaps xmm0, [rsp]
00007175dc9dc89b  vmovaps xmm1, [rsp+0x10]
00007175dc9dc8a1  vmovaps xmm2, [rsp+0x20]
00007175dc9dc8a7  vmovaps xmm3, [rsp+0x30]
00007175dc9dc8ad  vmovaps xmm4, [rsp+0x40]
00007175dc9dc8b3  vmovaps xmm5, [rsp+0x50]
00007175dc9dc8b9  vmovaps xmm6, [rsp+0x60]
00007175dc9dc8bf  vmovaps xmm7, [rsp+0x70]
00007175dc9dc8c5  vmovaps xmm9, [rsp+0x80]
00007175dc9dc8ce  vmovaps xmm10, [rsp+0x90]
00007175dc9dc8d7  vmovaps xmm11, [rsp+0xA0]
00007175dc9dc8e0  vmovaps xmm12, [rsp+0xB0]
00007175dc9dc8e9  vmovaps xmm13, [rsp+0xC0]
00007175dc9dc8f2  vmovaps xmm14, [rsp+0xD0]
00007175dc9dc8fb  vmovaps xmm15, [rsp+0xE0]
00007175dc9dc904  add rsp, 0xF0
00007175dc9dc90b  pop r11
00007175dc9dc90d  pop r10
00007175dc9dc90f  pop r9
00007175dc9dc911  pop r8
00007175dc9dc913  pop rsi
00007175dc9dc914  pop rdi
00007175dc9dc915  pop rdx
00007175dc9dc916  pop rcx
00007175dc9dc917  pop rax
00007175dc9dc918  add rsp, 0x08
00007175dc9dc91c  jmp 0x00007175DC9DA4D0
00007175dc9dc921  sub rsp, 0x08
00007175dc9dc925  push rax
00007175dc9dc926  push rcx
00007175dc9dc927  push rdx
00007175dc9dc928  push rdi
00007175dc9dc929  push rsi
00007175dc9dc92a  push r8
00007175dc9dc92c  push r9
00007175dc9dc92e  push r10
00007175dc9dc930  push r11
00007175dc9dc932  sub rsp, 0xF0
00007175dc9dc939  vmovaps [rsp], xmm0
00007175dc9dc93e  vmovaps [rsp+0x10], xmm1
00007175dc9dc944  vmovaps [rsp+0x20], xmm2
00007175dc9dc94a  vmovaps [rsp+0x30], xmm3
00007175dc9dc950  vmovaps [rsp+0x40], xmm4
00007175dc9dc956  vmovaps [rsp+0x50], xmm5
00007175dc9dc95c  vmovaps [rsp+0x60], xmm6
00007175dc9dc962  vmovaps [rsp+0x70], xmm8
00007175dc9dc968  vmovaps [rsp+0x80], xmm9
00007175dc9dc971  vmovaps [rsp+0x90], xmm10
00007175dc9dc97a  vmovaps [rsp+0xA0], xmm11
00007175dc9dc983  vmovaps [rsp+0xB0], xmm12
00007175dc9dc98c  vmovaps [rsp+0xC0], xmm13
00007175dc9dc995  vmovaps [rsp+0xD0], xmm14
00007175dc9dc99e  vmovaps [rsp+0xE0], xmm15
00007175dc9dc9a7  sub rsp, 0x40
00007175dc9dc9ab  lea rdi, [rsp]
00007175dc9dc9af  lea rsi, [rsp+0x10]
00007175dc9dc9b4  lea rdx, [rsp+0x20]
00007175dc9dc9b9  lea rcx, [rsp+0x30]
00007175dc9dc9be  mov r8d, 0x00
00007175dc9dc9c4  lea r9, [r15+0x3A8]
00007175dc9dc9cb  movaps [rdi], xmm7
00007175dc9dc9ce  movaps [rsi], xmm9
00007175dc9dc9d2  movaps [rdx], xmm14
00007175dc9dc9d6  movaps [rcx], xmm12
00007175dc9dc9da  mov rax, 0x622B29CAFA50
00007175dc9dc9e4  call rax
00007175dc9dc9e6  movaps xmm7, [rsp]
00007175dc9dc9ea  add rsp, 0x40
00007175dc9dc9ee  vmovaps xmm0, [rsp]
00007175dc9dc9f3  vmovaps xmm1, [rsp+0x10]
00007175dc9dc9f9  vmovaps xmm2, [rsp+0x20]
00007175dc9dc9ff  vmovaps xmm3, [rsp+0x30]
00007175dc9dca05  vmovaps xmm4, [rsp+0x40]
00007175dc9dca0b  vmovaps xmm5, [rsp+0x50]
00007175dc9dca11  vmovaps xmm6, [rsp+0x60]
00007175dc9dca17  vmovaps xmm8, [rsp+0x70]
00007175dc9dca1d  vmovaps xmm9, [rsp+0x80]
00007175dc9dca26  vmovaps xmm10, [rsp+0x90]
00007175dc9dca2f  vmovaps xmm11, [rsp+0xA0]
00007175dc9dca38  vmovaps xmm12, [rsp+0xB0]
00007175dc9dca41  vmovaps xmm13, [rsp+0xC0]
00007175dc9dca4a  vmovaps xmm14, [rsp+0xD0]
00007175dc9dca53  vmovaps xmm15, [rsp+0xE0]
00007175dc9dca5c  add rsp, 0xF0
00007175dc9dca63  pop r11
00007175dc9dca65  pop r10
00007175dc9dca67  pop r9
00007175dc9dca69  pop r8
00007175dc9dca6b  pop rsi
00007175dc9dca6c  pop rdi
00007175dc9dca6d  pop rdx
00007175dc9dca6e  pop rcx
00007175dc9dca6f  pop rax
00007175dc9dca70  add rsp, 0x08
00007175dc9dca74  jmp 0x00007175DC9DA4F8
00007175dc9dca79  sub rsp, 0x08
00007175dc9dca7d  push rax
00007175dc9dca7e  push rcx
00007175dc9dca7f  push rdx
00007175dc9dca80  push rdi
00007175dc9dca81  push rsi
00007175dc9dca82  push r8
00007175dc9dca84  push r9
00007175dc9dca86  push r10
00007175dc9dca88  push r11
00007175dc9dca8a  sub rsp, 0xF0
00007175dc9dca91  vmovaps [rsp], xmm0
00007175dc9dca96  vmovaps [rsp+0x10], xmm1
00007175dc9dca9c  vmovaps [rsp+0x20], xmm2
00007175dc9dcaa2  vmovaps [rsp+0x30], xmm3
00007175dc9dcaa8  vmovaps [rsp+0x40], xmm4
00007175dc9dcaae  vmovaps [rsp+0x50], xmm5
00007175dc9dcab4  vmovaps [rsp+0x60], xmm6
00007175dc9dcaba  vmovaps [rsp+0x70], xmm7
00007175dc9dcac0  vmovaps [rsp+0x80], xmm8
00007175dc9dcac9  vmovaps [rsp+0x90], xmm9
00007175dc9dcad2  vmovaps [rsp+0xA0], xmm10
00007175dc9dcadb  vmovaps [rsp+0xB0], xmm11
00007175dc9dcae4  vmovaps [rsp+0xC0], xmm13
00007175dc9dcaed  vmovaps [rsp+0xD0], xmm14
00007175dc9dcaf6  vmovaps [rsp+0xE0], xmm15
00007175dc9dcaff  sub rsp, 0x40
00007175dc9dcb03  lea rdi, [rsp]
00007175dc9dcb07  lea rsi, [rsp+0x10]
00007175dc9dcb0c  lea rdx, [rsp+0x20]
00007175dc9dcb11  lea rcx, [rsp+0x30]
00007175dc9dcb16  mov r8d, 0x00
00007175dc9dcb1c  lea r9, [r15+0x3A8]
00007175dc9dcb23  movaps [rdi], xmm12
00007175dc9dcb27  movaps [rsi], xmm11
00007175dc9dcb2b  movaps [rdx], xmm15
00007175dc9dcb2f  movaps [rcx], xmm14
00007175dc9dcb33  mov rax, 0x622B29CAFA50
00007175dc9dcb3d  call rax
00007175dc9dcb3f  movaps xmm12, [rsp]
00007175dc9dcb44  add rsp, 0x40
00007175dc9dcb48  vmovaps xmm0, [rsp]
00007175dc9dcb4d  vmovaps xmm1, [rsp+0x10]
00007175dc9dcb53  vmovaps xmm2, [rsp+0x20]
00007175dc9dcb59  vmovaps xmm3, [rsp+0x30]
00007175dc9dcb5f  vmovaps xmm4, [rsp+0x40]
00007175dc9dcb65  vmovaps xmm5, [rsp+0x50]
00007175dc9dcb6b  vmovaps xmm6, [rsp+0x60]
00007175dc9dcb71  vmovaps xmm7, [rsp+0x70]
00007175dc9dcb77  vmovaps xmm8, [rsp+0x80]
00007175dc9dcb80  vmovaps xmm9, [rsp+0x90]
00007175dc9dcb89  vmovaps xmm10, [rsp+0xA0]
00007175dc9dcb92  vmovaps xmm11, [rsp+0xB0]
00007175dc9dcb9b  vmovaps xmm13, [rsp+0xC0]
00007175dc9dcba4  vmovaps xmm14, [rsp+0xD0]
00007175dc9dcbad  vmovaps xmm15, [rsp+0xE0]
00007175dc9dcbb6  add rsp, 0xF0
00007175dc9dcbbd  pop r11
00007175dc9dcbbf  pop r10
00007175dc9dcbc1  pop r9
00007175dc9dcbc3  pop r8
00007175dc9dcbc5  pop rsi
00007175dc9dcbc6  pop rdi
00007175dc9dcbc7  pop rdx
00007175dc9dcbc8  pop rcx
00007175dc9dcbc9  pop rax
00007175dc9dcbca  add rsp, 0x08
00007175dc9dcbce  jmp 0x00007175DC9DA521
00007175dc9dcbd3  sub rsp, 0x08
00007175dc9dcbd7  push rax
00007175dc9dcbd8  push rcx
00007175dc9dcbd9  push rdx
00007175dc9dcbda  push rdi
00007175dc9dcbdb  push rsi
00007175dc9dcbdc  push r8
00007175dc9dcbde  push r9
00007175dc9dcbe0  push r10
00007175dc9dcbe2  push r11
00007175dc9dcbe4  sub rsp, 0xF0
00007175dc9dcbeb  vmovaps [rsp], xmm0
00007175dc9dcbf0  vmovaps [rsp+0x10], xmm1
00007175dc9dcbf6  vmovaps [rsp+0x20], xmm2
00007175dc9dcbfc  vmovaps [rsp+0x30], xmm3
00007175dc9dcc02  vmovaps [rsp+0x40], xmm4
00007175dc9dcc08  vmovaps [rsp+0x50], xmm5
00007175dc9dcc0e  vmovaps [rsp+0x60], xmm6
00007175dc9dcc14  vmovaps [rsp+0x70], xmm7
00007175dc9dcc1a  vmovaps [rsp+0x80], xmm8
00007175dc9dcc23  vmovaps [rsp+0x90], xmm9
00007175dc9dcc2c  vmovaps [rsp+0xA0], xmm10
00007175dc9dcc35  vmovaps [rsp+0xB0], xmm12
00007175dc9dcc3e  vmovaps [rsp+0xC0], xmm13
00007175dc9dcc47  vmovaps [rsp+0xD0], xmm14
00007175dc9dcc50  vmovaps [rsp+0xE0], xmm15
00007175dc9dcc59  sub rsp, 0x40
00007175dc9dcc5d  lea rdi, [rsp]
00007175dc9dcc61  lea rsi, [rsp+0x10]
00007175dc9dcc66  lea rdx, [rsp+0x20]
00007175dc9dcc6b  lea rcx, [rsp+0x30]
00007175dc9dcc70  mov r8d, 0x00
00007175dc9dcc76  lea r9, [r15+0x3A8]
00007175dc9dcc7d  movaps [rdi], xmm11
00007175dc9dcc81  movaps [rsi], xmm10
00007175dc9dcc85  movaps [rdx], xmm13
00007175dc9dcc89  movaps [rcx], xmm15
00007175dc9dcc8d  mov rax, 0x622B29CAFA50
00007175dc9dcc97  call rax
00007175dc9dcc99  movaps xmm11, [rsp]
00007175dc9dcc9e  add rsp, 0x40
00007175dc9dcca2  vmovaps xmm0, [rsp]
00007175dc9dcca7  vmovaps xmm1, [rsp+0x10]
00007175dc9dccad  vmovaps xmm2, [rsp+0x20]
00007175dc9dccb3  vmovaps xmm3, [rsp+0x30]
00007175dc9dccb9  vmovaps xmm4, [rsp+0x40]
00007175dc9dccbf  vmovaps xmm5, [rsp+0x50]
00007175dc9dccc5  vmovaps xmm6, [rsp+0x60]
00007175dc9dcccb  vmovaps xmm7, [rsp+0x70]
00007175dc9dccd1  vmovaps xmm8, [rsp+0x80]
00007175dc9dccda  vmovaps xmm9, [rsp+0x90]
00007175dc9dcce3  vmovaps xmm10, [rsp+0xA0]
00007175dc9dccec  vmovaps xmm12, [rsp+0xB0]
00007175dc9dccf5  vmovaps xmm13, [rsp+0xC0]
00007175dc9dccfe  vmovaps xmm14, [rsp+0xD0]
00007175dc9dcd07  vmovaps xmm15, [rsp+0xE0]
00007175dc9dcd10  add rsp, 0xF0
00007175dc9dcd17  pop r11
00007175dc9dcd19  pop r10
00007175dc9dcd1b  pop r9
00007175dc9dcd1d  pop r8
00007175dc9dcd1f  pop rsi
00007175dc9dcd20  pop rdi
00007175dc9dcd21  pop rdx
00007175dc9dcd22  pop rcx
00007175dc9dcd23  pop rax
00007175dc9dcd24  add rsp, 0x08
00007175dc9dcd28  jmp 0x00007175DC9DA54A
00007175dc9dcd2d  call 0x00007175DC80E760
00007175dc9dcd32  jmp 0x00007175DC9DA557
00007175dc9dcd37  call 0x00007175DC80D4E0
00007175dc9dcd3c  jmp 0x00007175DC9DA564
00007175dc9dcd41  sub rsp, 0x08
00007175dc9dcd45  push rax
00007175dc9dcd46  push rcx
00007175dc9dcd47  push rdx
00007175dc9dcd48  push rdi
00007175dc9dcd49  push rsi
00007175dc9dcd4a  push r8
00007175dc9dcd4c  push r9
00007175dc9dcd4e  push r10
00007175dc9dcd50  push r11
00007175dc9dcd52  sub rsp, 0xF0
00007175dc9dcd59  vmovaps [rsp], xmm0
00007175dc9dcd5e  vmovaps [rsp+0x10], xmm1
00007175dc9dcd64  vmovaps [rsp+0x20], xmm2
00007175dc9dcd6a  vmovaps [rsp+0x30], xmm3
00007175dc9dcd70  vmovaps [rsp+0x40], xmm4
00007175dc9dcd76  vmovaps [rsp+0x50], xmm5
00007175dc9dcd7c  vmovaps [rsp+0x60], xmm6
00007175dc9dcd82  vmovaps [rsp+0x70], xmm7
00007175dc9dcd88  vmovaps [rsp+0x80], xmm8
00007175dc9dcd91  vmovaps [rsp+0x90], xmm9
00007175dc9dcd9a  vmovaps [rsp+0xA0], xmm11
00007175dc9dcda3  vmovaps [rsp+0xB0], xmm12
00007175dc9dcdac  vmovaps [rsp+0xC0], xmm13
00007175dc9dcdb5  vmovaps [rsp+0xD0], xmm14
00007175dc9dcdbe  vmovaps [rsp+0xE0], xmm15
00007175dc9dcdc7  sub rsp, 0x40
00007175dc9dcdcb  lea rdi, [rsp]
00007175dc9dcdcf  lea rsi, [rsp+0x10]
00007175dc9dcdd4  lea rdx, [rsp+0x20]
00007175dc9dcdd9  lea rcx, [rsp+0x30]
00007175dc9dcdde  mov r8d, 0x00
00007175dc9dcde4  lea r9, [r15+0x3A8]
00007175dc9dcdeb  movaps [rdi], xmm10
00007175dc9dcdef  movaps [rsi], xmm8
00007175dc9dcdf3  movaps [rdx], xmm1
00007175dc9dcdf6  movaps [rcx], xmm13
00007175dc9dcdfa  mov rax, 0x622B29CAFA50
00007175dc9dce04  call rax
00007175dc9dce06  movaps xmm10, [rsp]
00007175dc9dce0b  add rsp, 0x40
00007175dc9dce0f  vmovaps xmm0, [rsp]
00007175dc9dce14  vmovaps xmm1, [rsp+0x10]
00007175dc9dce1a  vmovaps xmm2, [rsp+0x20]
00007175dc9dce20  vmovaps xmm3, [rsp+0x30]
00007175dc9dce26  vmovaps xmm4, [rsp+0x40]
00007175dc9dce2c  vmovaps xmm5, [rsp+0x50]
00007175dc9dce32  vmovaps xmm6, [rsp+0x60]
00007175dc9dce38  vmovaps xmm7, [rsp+0x70]
00007175dc9dce3e  vmovaps xmm8, [rsp+0x80]
00007175dc9dce47  vmovaps xmm9, [rsp+0x90]
00007175dc9dce50  vmovaps xmm11, [rsp+0xA0]
00007175dc9dce59  vmovaps xmm12, [rsp+0xB0]
00007175dc9dce62  vmovaps xmm13, [rsp+0xC0]
00007175dc9dce6b  vmovaps xmm14, [rsp+0xD0]
00007175dc9dce74  vmovaps xmm15, [rsp+0xE0]
00007175dc9dce7d  add rsp, 0xF0
00007175dc9dce84  pop r11
00007175dc9dce86  pop r10
00007175dc9dce88  pop r9
00007175dc9dce8a  pop r8
00007175dc9dce8c  pop rsi
00007175dc9dce8d  pop rdi
00007175dc9dce8e  pop rdx
00007175dc9dce8f  pop rcx
00007175dc9dce90  pop rax
00007175dc9dce91  add rsp, 0x08
00007175dc9dce95  jmp 0x00007175DC9DA59A
00007175dc9dce9a  call 0x00007175DC7FF430
00007175dc9dce9f  jmp 0x00007175DC9DA5AC
00007175dc9dcea4  sub rsp, 0x08
00007175dc9dcea8  push rax
00007175dc9dcea9  push rcx
00007175dc9dceaa  push rdx
00007175dc9dceab  push rdi
00007175dc9dceac  push rsi
00007175dc9dcead  push r8
00007175dc9dceaf  push r9
00007175dc9dceb1  push r10
00007175dc9dceb3  push r11
00007175dc9dceb5  sub rsp, 0xF0
00007175dc9dcebc  vmovaps [rsp], xmm0
00007175dc9dcec1  vmovaps [rsp+0x10], xmm1
00007175dc9dcec7  vmovaps [rsp+0x20], xmm2
00007175dc9dcecd  vmovaps [rsp+0x30], xmm3
00007175dc9dced3  vmovaps [rsp+0x40], xmm4
00007175dc9dced9  vmovaps [rsp+0x50], xmm5
00007175dc9dcedf  vmovaps [rsp+0x60], xmm6
00007175dc9dcee5  vmovaps [rsp+0x70], xmm7
00007175dc9dceeb  vmovaps [rsp+0x80], xmm8
00007175dc9dcef4  vmovaps [rsp+0x90], xmm10
00007175dc9dcefd  vmovaps [rsp+0xA0], xmm11
00007175dc9dcf06  vmovaps [rsp+0xB0], xmm12
00007175dc9dcf0f  vmovaps [rsp+0xC0], xmm13
00007175dc9dcf18  vmovaps [rsp+0xD0], xmm14
00007175dc9dcf21  vmovaps [rsp+0xE0], xmm15
00007175dc9dcf2a  sub rsp, 0x40
00007175dc9dcf2e  lea rdi, [rsp]
00007175dc9dcf32  lea rsi, [rsp+0x10]
00007175dc9dcf37  lea rdx, [rsp+0x20]
00007175dc9dcf3c  lea rcx, [rsp+0x30]
00007175dc9dcf41  mov r8d, 0x00
00007175dc9dcf47  lea r9, [r15+0x3A8]
00007175dc9dcf4e  movaps [rdi], xmm9
00007175dc9dcf52  movaps [rsi], xmm7
00007175dc9dcf55  movaps [rdx], xmm14
00007175dc9dcf59  movaps [rcx], xmm13
00007175dc9dcf5d  mov rax, 0x622B29CAFA50
00007175dc9dcf67  call rax
00007175dc9dcf69  movaps xmm9, [rsp]
00007175dc9dcf6e  add rsp, 0x40
00007175dc9dcf72  vmovaps xmm0, [rsp]
00007175dc9dcf77  vmovaps xmm1, [rsp+0x10]
00007175dc9dcf7d  vmovaps xmm2, [rsp+0x20]
00007175dc9dcf83  vmovaps xmm3, [rsp+0x30]
00007175dc9dcf89  vmovaps xmm4, [rsp+0x40]
00007175dc9dcf8f  vmovaps xmm5, [rsp+0x50]
00007175dc9dcf95  vmovaps xmm6, [rsp+0x60]
00007175dc9dcf9b  vmovaps xmm7, [rsp+0x70]
00007175dc9dcfa1  vmovaps xmm8, [rsp+0x80]
00007175dc9dcfaa  vmovaps xmm10, [rsp+0x90]
00007175dc9dcfb3  vmovaps xmm11, [rsp+0xA0]
00007175dc9dcfbc  vmovaps xmm12, [rsp+0xB0]
00007175dc9dcfc5  vmovaps xmm13, [rsp+0xC0]
00007175dc9dcfce  vmovaps xmm14, [rsp+0xD0]
00007175dc9dcfd7  vmovaps xmm15, [rsp+0xE0]
00007175dc9dcfe0  add rsp, 0xF0
00007175dc9dcfe7  pop r11
00007175dc9dcfe9  pop r10
00007175dc9dcfeb  pop r9
00007175dc9dcfed  pop r8
00007175dc9dcfef  pop rsi
00007175dc9dcff0  pop rdi
00007175dc9dcff1  pop rdx
00007175dc9dcff2  pop rcx
00007175dc9dcff3  pop rax
00007175dc9dcff4  add rsp, 0x08
00007175dc9dcff8  jmp 0x00007175DC9DA5DA
00007175dc9dcffd  sub rsp, 0x08
00007175dc9dd001  push rax
00007175dc9dd002  push rcx
00007175dc9dd003  push rdx
00007175dc9dd004  push rdi
00007175dc9dd005  push rsi
00007175dc9dd006  push r8
00007175dc9dd008  push r9
00007175dc9dd00a  push r10
00007175dc9dd00c  push r11
00007175dc9dd00e  sub rsp, 0xF0
00007175dc9dd015  vmovaps [rsp], xmm0
00007175dc9dd01a  vmovaps [rsp+0x10], xmm1
00007175dc9dd020  vmovaps [rsp+0x20], xmm2
00007175dc9dd026  vmovaps [rsp+0x30], xmm3
00007175dc9dd02c  vmovaps [rsp+0x40], xmm4
00007175dc9dd032  vmovaps [rsp+0x50], xmm5
00007175dc9dd038  vmovaps [rsp+0x60], xmm6
00007175dc9dd03e  vmovaps [rsp+0x70], xmm7
00007175dc9dd044  vmovaps [rsp+0x80], xmm8
00007175dc9dd04d  vmovaps [rsp+0x90], xmm9
00007175dc9dd056  vmovaps [rsp+0xA0], xmm10
00007175dc9dd05f  vmovaps [rsp+0xB0], xmm11
00007175dc9dd068  vmovaps [rsp+0xC0], xmm12
00007175dc9dd071  vmovaps [rsp+0xD0], xmm14
00007175dc9dd07a  vmovaps [rsp+0xE0], xmm15
00007175dc9dd083  sub rsp, 0x40
00007175dc9dd087  lea rdi, [rsp]
00007175dc9dd08b  lea rsi, [rsp+0x10]
00007175dc9dd090  lea rdx, [rsp+0x20]
00007175dc9dd095  lea rcx, [rsp+0x30]
00007175dc9dd09a  mov r8d, 0x00
00007175dc9dd0a0  lea r9, [r15+0x3A8]
00007175dc9dd0a7  movaps [rdi], xmm13
00007175dc9dd0ab  movaps [rsi], xmm12
00007175dc9dd0af  movaps [rdx], xmm15
00007175dc9dd0b3  movaps [rcx], xmm14
00007175dc9dd0b7  mov rax, 0x622B29CAFA50
00007175dc9dd0c1  call rax
00007175dc9dd0c3  movaps xmm13, [rsp]
00007175dc9dd0c8  add rsp, 0x40
00007175dc9dd0cc  vmovaps xmm0, [rsp]
00007175dc9dd0d1  vmovaps xmm1, [rsp+0x10]
00007175dc9dd0d7  vmovaps xmm2, [rsp+0x20]
00007175dc9dd0dd  vmovaps xmm3, [rsp+0x30]
00007175dc9dd0e3  vmovaps xmm4, [rsp+0x40]
00007175dc9dd0e9  vmovaps xmm5, [rsp+0x50]
00007175dc9dd0ef  vmovaps xmm6, [rsp+0x60]
00007175dc9dd0f5  vmovaps xmm7, [rsp+0x70]
00007175dc9dd0fb  vmovaps xmm8, [rsp+0x80]
00007175dc9dd104  vmovaps xmm9, [rsp+0x90]
00007175dc9dd10d  vmovaps xmm10, [rsp+0xA0]
00007175dc9dd116  vmovaps xmm11, [rsp+0xB0]
00007175dc9dd11f  vmovaps xmm12, [rsp+0xC0]
00007175dc9dd128  vmovaps xmm14, [rsp+0xD0]
00007175dc9dd131  vmovaps xmm15, [rsp+0xE0]
00007175dc9dd13a  add rsp, 0xF0
00007175dc9dd141  pop r11
00007175dc9dd143  pop r10
00007175dc9dd145  pop r9
00007175dc9dd147  pop r8
00007175dc9dd149  pop rsi
00007175dc9dd14a  pop rdi
00007175dc9dd14b  pop rdx
00007175dc9dd14c  pop rcx
00007175dc9dd14d  pop rax
00007175dc9dd14e  add rsp, 0x08
00007175dc9dd152  jmp 0x00007175DC9DA608
00007175dc9dd157  sub rsp, 0x08
00007175dc9dd15b  push rax
00007175dc9dd15c  push rcx
00007175dc9dd15d  push rdx
00007175dc9dd15e  push rdi
00007175dc9dd15f  push rsi
00007175dc9dd160  push r8
00007175dc9dd162  push r9
00007175dc9dd164  push r10
00007175dc9dd166  push r11
00007175dc9dd168  sub rsp, 0xF0
00007175dc9dd16f  vmovaps [rsp], xmm0
00007175dc9dd174  vmovaps [rsp+0x10], xmm1
00007175dc9dd17a  vmovaps [rsp+0x20], xmm2
00007175dc9dd180  vmovaps [rsp+0x30], xmm3
00007175dc9dd186  vmovaps [rsp+0x40], xmm4
00007175dc9dd18c  vmovaps [rsp+0x50], xmm5
00007175dc9dd192  vmovaps [rsp+0x60], xmm6
00007175dc9dd198  vmovaps [rsp+0x70], xmm7
00007175dc9dd19e  vmovaps [rsp+0x80], xmm8
00007175dc9dd1a7  vmovaps [rsp+0x90], xmm9
00007175dc9dd1b0  vmovaps [rsp+0xA0], xmm10
00007175dc9dd1b9  vmovaps [rsp+0xB0], xmm11
00007175dc9dd1c2  vmovaps [rsp+0xC0], xmm12
00007175dc9dd1cb  vmovaps [rsp+0xD0], xmm13
00007175dc9dd1d4  vmovaps [rsp+0xE0], xmm15
00007175dc9dd1dd  sub rsp, 0x40
00007175dc9dd1e1  lea rdi, [rsp]
00007175dc9dd1e5  lea rsi, [rsp+0x10]
00007175dc9dd1ea  lea rdx, [rsp+0x20]
00007175dc9dd1ef  lea rcx, [rsp+0x30]
00007175dc9dd1f4  mov r8d, 0x00
00007175dc9dd1fa  lea r9, [r15+0x3A8]
00007175dc9dd201  movaps [rdi], xmm14
00007175dc9dd205  movaps [rsi], xmm11
00007175dc9dd209  movaps [rdx], xmm1
00007175dc9dd20c  movaps [rcx], xmm15
00007175dc9dd210  mov rax, 0x622B29CAFA50
00007175dc9dd21a  call rax
00007175dc9dd21c  movaps xmm14, [rsp]
00007175dc9dd221  add rsp, 0x40
00007175dc9dd225  vmovaps xmm0, [rsp]
00007175dc9dd22a  vmovaps xmm1, [rsp+0x10]
00007175dc9dd230  vmovaps xmm2, [rsp+0x20]
00007175dc9dd236  vmovaps xmm3, [rsp+0x30]
00007175dc9dd23c  vmovaps xmm4, [rsp+0x40]
00007175dc9dd242  vmovaps xmm5, [rsp+0x50]
00007175dc9dd248  vmovaps xmm6, [rsp+0x60]
00007175dc9dd24e  vmovaps xmm7, [rsp+0x70]
00007175dc9dd254  vmovaps xmm8, [rsp+0x80]
00007175dc9dd25d  vmovaps xmm9, [rsp+0x90]
00007175dc9dd266  vmovaps xmm10, [rsp+0xA0]
00007175dc9dd26f  vmovaps xmm11, [rsp+0xB0]
00007175dc9dd278  vmovaps xmm12, [rsp+0xC0]
00007175dc9dd281  vmovaps xmm13, [rsp+0xD0]
00007175dc9dd28a  vmovaps xmm15, [rsp+0xE0]
00007175dc9dd293  add rsp, 0xF0
00007175dc9dd29a  pop r11
00007175dc9dd29c  pop r10
00007175dc9dd29e  pop r9
00007175dc9dd2a0  pop r8
00007175dc9dd2a2  pop rsi
00007175dc9dd2a3  pop rdi
00007175dc9dd2a4  pop rdx
00007175dc9dd2a5  pop rcx
00007175dc9dd2a6  pop rax
00007175dc9dd2a7  add rsp, 0x08
00007175dc9dd2ab  jmp 0x00007175DC9DA636
00007175dc9dd2b0  call 0x00007175DC8079B0
00007175dc9dd2b5  jmp 0x00007175DC9DA64C
00007175dc9dd2ba  call 0x00007175DC8E3440
00007175dc9dd2bf  jmp 0x00007175DC9DA656
00007175dc9dd2c4  call 0x00007175DC8DFCE0
00007175dc9dd2c9  jmp 0x00007175DC9DA660
00007175dc9dd2ce  call 0x00007175DC8E46C0
00007175dc9dd2d3  jmp 0x00007175DC9DA66A
00007175dc9dd2d8  int3
00007175dc9dd2d9  nop [rax], eax
00007175dc9dd2e0  mov qword ptr [r15+0x40], 0x430000
00007175dc9dd2e8  mov eax, 0x430C50
00007175dc9dd2ed  mov r14, [r13+rax*1]
00007175dc9dd2f2  movq xmm1, r14
00007175dc9dd2f7  mov rax, [r15+0x50]
00007175dc9dd2fb  movups xmm15, [r13+rax*1]
00007175dc9dd301  movaps [r15+0x120], xmm15
00007175dc9dd309  mov qword ptr [r15+0x48], 0x10
00007175dc9dd311  xor eax, eax
00007175dc9dd313  mov r14d, 0x10
00007175dc9dd319  mov r12d, 0x200
00007175dc9dd31f  cmp r14, r12
00007175dc9dd322  cmc
00007175dc9dd323  lahf
00007175dc9dd324  seto al
00007175dc9dd327  mov [r15+0x108], eax
00007175dc9dd32e  pextrq rax, xmm15, 0x01
00007175dc9dd335  movq xmm14, rax
00007175dc9dd33a  movaps [r15+0x130], xmm14
00007175dc9dd342  movq rax, xmm1
00007175dc9dd347  movq r14, xmm15
00007175dc9dd34c  vmovq xmm1, rax
00007175dc9dd351  vmovq xmm15, r14
00007175dc9dd356  movaps xmm13, xmm1
00007175dc9dd35a  addsd xmm13, xmm15
00007175dc9dd35f  ucomisd xmm13, xmm13
00007175dc9dd364  jp 0x00007175DC9DD423
00007175dc9dd36a  movq xmm13, xmm13
00007175dc9dd36f  movq rax, xmm13
00007175dc9dd374  movq r14, xmm14
00007175dc9dd379  vmovq xmm1, rax
00007175dc9dd37e  vmovq xmm15, r14
00007175dc9dd383  movaps xmm14, xmm1
00007175dc9dd387  addsd xmm14, xmm15
00007175dc9dd38c  ucomisd xmm14, xmm14
00007175dc9dd391  jp 0x00007175DC9DD46B
00007175dc9dd397  movq xmm14, xmm14
00007175dc9dd39c  movaps [r15+0x110], xmm14
00007175dc9dd3a4  mov eax, [r15+0x108]
00007175dc9dd3ab  sahf
00007175dc9dd3ac  jnz 0x00007175DC9DD3DE
00007175dc9dd3ae  cmp dword ptr [r15+0x318], 0x00
00007175dc9dd3b6  jz 0x00007175DC9DD680
00007175dc9dd3bc  nop [rax+rax*1], ax
00007175dc9dd3c5  nop [rax+rax*1], eax
00007175dc9dd3cd  mov eax, 0x410698
00007175dc9dd3d2  mov [r15+0x100], rax
00007175dc9dd3d9  jmp 0x00007175DC7FE110
00007175dc9dd3de  cmp dword ptr [r15+0x318], 0x00
00007175dc9dd3e6  jz 0x00007175DC9DD4C0
00007175dc9dd3ec  nop [rax+rax*1], ax
00007175dc9dd3f5  nop [rax+rax*1], eax
00007175dc9dd3fd  mov eax, 0x41067C
00007175dc9dd402  mov [r15+0x100], rax
00007175dc9dd409  jmp 0x00007175DC7FE110
00007175dc9dd40e  int3
00007175dc9dd40f  call 0x00007175DC80DC20
00007175dc9dd414  jmp 0x00007175DC9DD2F2
00007175dc9dd419  call 0x00007175DC80E760
00007175dc9dd41e  jmp 0x00007175DC9DD301
00007175dc9dd423  ucomisd xmm1, xmm15
00007175dc9dd428  jp 0x00007175DC9DD437
00007175dc9dd42a  movaps xmm13, [0x00007175DC5FE060]
00007175dc9dd432  jmp 0x00007175DC9DD36A
00007175dc9dd437  vxorps xmm0, xmm1, xmm15
00007175dc9dd43c  pextrw eax, xmm0, 0x03
00007175dc9dd441  and eax, 0x7FF8
00007175dc9dd446  cmp eax, 0x08
00007175dc9dd449  jnz 0x00007175DC9DD36A
00007175dc9dd44f  movq rax, xmm15
00007175dc9dd454  shl rax, 0x0D
00007175dc9dd458  jbe 0x00007175DC9DD36A
00007175dc9dd45e  vorps xmm13, xmm15, [0x00007175DC5FE070]
00007175dc9dd466  jmp 0x00007175DC9DD36A
00007175dc9dd46b  ucomisd xmm1, xmm15
00007175dc9dd470  jp 0x00007175DC9DD47F
00007175dc9dd472  movaps xmm14, [0x00007175DC5FE060]
00007175dc9dd47a  jmp 0x00007175DC9DD397
00007175dc9dd47f  vxorps xmm0, xmm1, xmm15
00007175dc9dd484  pextrw eax, xmm0, 0x03
00007175dc9dd489  and eax, 0x7FF8
00007175dc9dd48e  cmp eax, 0x08
00007175dc9dd491  jnz 0x00007175DC9DD397
00007175dc9dd497  movq rax, xmm15
00007175dc9dd49c  shl rax, 0x0D
00007175dc9dd4a0  jbe 0x00007175DC9DD397
00007175dc9dd4a6  vorps xmm14, xmm15, [0x00007175DC5FE070]
00007175dc9dd4ae  jmp 0x00007175DC9DD397
00007175dc9dd4b3  int3
00007175dc9dd4b4  nop [rax+rax*1], ax
00007175dc9dd4bd  nop [rax], eax
00007175dc9dd4c0  mov rax, [r15+0x48]
00007175dc9dd4c4  mov r14, [r15+0x50]
00007175dc9dd4c8  lea r12, [r14+rax*1]
00007175dc9dd4cc  movups xmm1, [r13+r12*1]
00007175dc9dd4d2  movaps [r15+0x120], xmm1
00007175dc9dd4da  lea r14, [rax+0x10]
00007175dc9dd4de  mov [r15+0x48], r14
00007175dc9dd4e2  xor eax, eax
00007175dc9dd4e4  mov r12d, 0x200
00007175dc9dd4ea  cmp r14, r12
00007175dc9dd4ed  cmc
00007175dc9dd4ee  lahf
00007175dc9dd4ef  seto al
00007175dc9dd4f2  mov [r15+0x108], eax
00007175dc9dd4f9  pextrq rax, xmm1, 0x01
00007175dc9dd500  movq xmm15, rax
00007175dc9dd505  movaps [r15+0x130], xmm15
00007175dc9dd50d  movaps xmm14, [r15+0x110]
00007175dc9dd515  movq rax, xmm14
00007175dc9dd51a  movq r14, xmm1
00007175dc9dd51f  vmovq xmm1, rax
00007175dc9dd524  vmovq xmm14, r14
00007175dc9dd529  movaps xmm13, xmm1
00007175dc9dd52d  addsd xmm13, xmm14
00007175dc9dd532  ucomisd xmm13, xmm13
00007175dc9dd537  jp 0x00007175DC9DD5EC
00007175dc9dd53d  movq xmm13, xmm13
00007175dc9dd542  movq rax, xmm13
00007175dc9dd547  movq r14, xmm15
00007175dc9dd54c  vmovq xmm1, rax
00007175dc9dd551  vmovq xmm15, r14
00007175dc9dd556  movaps xmm14, xmm1
00007175dc9dd55a  addsd xmm14, xmm15
00007175dc9dd55f  ucomisd xmm14, xmm14
00007175dc9dd564  jp 0x00007175DC9DD634
00007175dc9dd56a  movq xmm14, xmm14
00007175dc9dd56f  movaps [r15+0x110], xmm14
00007175dc9dd577  mov eax, [r15+0x108]
00007175dc9dd57e  sahf
00007175dc9dd57f  jnz 0x00007175DC9DD5B1
00007175dc9dd581  cmp dword ptr [r15+0x318], 0x00
00007175dc9dd589  jz 0x00007175DC9DD680
00007175dc9dd58f  nop [rax+rax*1], ax
00007175dc9dd598  nop [rax+rax*1], eax
00007175dc9dd5a0  mov eax, 0x410698
00007175dc9dd5a5  mov [r15+0x100], rax
00007175dc9dd5ac  jmp 0x00007175DC7FE110
00007175dc9dd5b1  cmp dword ptr [r15+0x318], 0x00
00007175dc9dd5b9  jz 0x00007175DC9DD4C0
00007175dc9dd5bf  nop [rax+rax*1], ax
00007175dc9dd5c8  nop [rax+rax*1], eax
00007175dc9dd5d0  mov eax, 0x41067C
00007175dc9dd5d5  mov [r15+0x100], rax
00007175dc9dd5dc  jmp 0x00007175DC7FE110
00007175dc9dd5e1  int3
00007175dc9dd5e2  call 0x00007175DC8B52F0
00007175dc9dd5e7  jmp 0x00007175DC9DD4D2
00007175dc9dd5ec  ucomisd xmm1, xmm14
00007175dc9dd5f1  jp 0x00007175DC9DD600
00007175dc9dd5f3  movaps xmm13, [0x00007175DC5FE060]
00007175dc9dd5fb  jmp 0x00007175DC9DD53D
00007175dc9dd600  vxorps xmm0, xmm1, xmm14
00007175dc9dd605  pextrw eax, xmm0, 0x03
00007175dc9dd60a  and eax, 0x7FF8
00007175dc9dd60f  cmp eax, 0x08
00007175dc9dd612  jnz 0x00007175DC9DD53D
00007175dc9dd618  movq rax, xmm14
00007175dc9dd61d  shl rax, 0x0D
00007175dc9dd621  jbe 0x00007175DC9DD53D
00007175dc9dd627  vorps xmm13, xmm14, [0x00007175DC5FE070]
00007175dc9dd62f  jmp 0x00007175DC9DD53D
00007175dc9dd634  ucomisd xmm1, xmm15
00007175dc9dd639  jp 0x00007175DC9DD648
00007175dc9dd63b  movaps xmm14, [0x00007175DC5FE060]
00007175dc9dd643  jmp 0x00007175DC9DD56A
00007175dc9dd648  vxorps xmm0, xmm1, xmm15
00007175dc9dd64d  pextrw eax, xmm0, 0x03
00007175dc9dd652  and eax, 0x7FF8
00007175dc9dd657  cmp eax, 0x08
00007175dc9dd65a  jnz 0x00007175DC9DD56A
00007175dc9dd660  movq rax, xmm15
00007175dc9dd665  shl rax, 0x0D
00007175dc9dd669  jbe 0x00007175DC9DD56A
00007175dc9dd66f  vorps xmm14, xmm15, [0x00007175DC5FE070]
00007175dc9dd677  jmp 0x00007175DC9DD56A
00007175dc9dd67c  int3
00007175dc9dd67d  nop [rax], eax
00007175dc9dd680  mov rax, [r15+0xF8]
00007175dc9dd687  lea r14, [rax+0x1A0]
00007175dc9dd68e  mov r12, [r13+r14*1]
00007175dc9dd693  lea r14, [rax+0x1A8]
00007175dc9dd69a  mov r11, [r13+r14*1]
00007175dc9dd69f  mov [r15+0xA0], r12
00007175dc9dd6a6  mov [r15+0x98], r11
00007175dc9dd6ad  mov r14, [r15+0x40]
00007175dc9dd6b1  lea r12, [r14+0xC50]
00007175dc9dd6b8  movaps xmm1, [r15+0x110]
00007175dc9dd6c0  movq r14, xmm1
00007175dc9dd6c5  mov [r13+r12*1], r14
00007175dc9dd6ca  lea r14, [rax+0x190]
00007175dc9dd6d1  mov r12, [r13+r14*1]
00007175dc9dd6d6  lea r14, [rax+0x198]
00007175dc9dd6dd  mov r11, [r13+r14*1]
00007175dc9dd6e2  mov [r15+0xE8], r12
00007175dc9dd6e9  mov [r15+0xF0], r11
00007175dc9dd6f0  lea r14, [rax+0x180]
00007175dc9dd6f7  mov r12, [r13+r14*1]
00007175dc9dd6fc  lea r14, [rax+0x188]
00007175dc9dd703  mov r10, [r13+r14*1]
00007175dc9dd708  movq xmm1, r12
00007175dc9dd70d  movq xmm15, r10
00007175dc9dd712  movq xmm1, xmm1
00007175dc9dd716  movq xmm1, xmm1
00007175dc9dd71a  movaps [r15+0x1A0], xmm1
00007175dc9dd722  movq xmm15, xmm15
00007175dc9dd727  movq xmm15, xmm15
00007175dc9dd72c  movaps [r15+0x190], xmm15
00007175dc9dd734  lea r14, [rax+0x170]
00007175dc9dd73b  mov r12, [r13+r14*1]
00007175dc9dd740  lea r14, [rax+0x178]
00007175dc9dd747  mov r10, [r13+r14*1]
00007175dc9dd74c  movq xmm1, r12
00007175dc9dd751  movq xmm15, r10
00007175dc9dd756  movq xmm1, xmm1
00007175dc9dd75a  movq xmm1, xmm1
00007175dc9dd75e  movaps [r15+0x1C0], xmm1
00007175dc9dd766  movq xmm15, xmm15
00007175dc9dd76b  movq xmm15, xmm15
00007175dc9dd770  movaps [r15+0x1B0], xmm15
00007175dc9dd778  lea r14, [rax+0x160]
00007175dc9dd77f  mov r12, [r13+r14*1]
00007175dc9dd784  lea r14, [rax+0x168]
00007175dc9dd78b  mov r10, [r13+r14*1]
00007175dc9dd790  movq xmm1, r12
00007175dc9dd795  movq xmm15, r10
00007175dc9dd79a  movq xmm1, xmm1
00007175dc9dd79e  movq xmm1, xmm1
00007175dc9dd7a2  movaps [r15+0x1E0], xmm1
00007175dc9dd7aa  movq xmm15, xmm15
00007175dc9dd7af  movq xmm15, xmm15
00007175dc9dd7b4  movaps [r15+0x1D0], xmm15
00007175dc9dd7bc  lea r14, [rax+0x150]
00007175dc9dd7c3  mov r12, [r13+r14*1]
00007175dc9dd7c8  lea r14, [rax+0x158]
00007175dc9dd7cf  mov r10, [r13+r14*1]
00007175dc9dd7d4  movq xmm1, r12
00007175dc9dd7d9  movq xmm15, r10
00007175dc9dd7de  movq xmm1, xmm1
00007175dc9dd7e2  movq xmm1, xmm1
00007175dc9dd7e6  movaps [r15+0x200], xmm1
00007175dc9dd7ee  movq xmm15, xmm15
00007175dc9dd7f3  movq xmm15, xmm15
00007175dc9dd7f8  movaps [r15+0x1F0], xmm15
00007175dc9dd800  lea r14, [rax+0x1B0]
00007175dc9dd807  mov [r15+0xF8], r14
00007175dc9dd80e  mov [r15+0x100], r11
00007175dc9dd815  jmp 0x00007175DC9CE5C0
00007175dc9dd81a  int3
00007175dc9dd81b  call 0x00007175DC8E27E0
00007175dc9dd820  jmp 0x00007175DC9DD693
00007175dc9dd825  call 0x00007175DC8E1570
00007175dc9dd82a  jmp 0x00007175DC9DD69F
00007175dc9dd82f  call 0x00007175DC8C3FE0
00007175dc9dd834  jmp 0x00007175DC9DD6CA
00007175dc9dd839  call 0x00007175DC8E27E0
00007175dc9dd83e  jmp 0x00007175DC9DD6D6
00007175dc9dd843  call 0x00007175DC8E1570
00007175dc9dd848  jmp 0x00007175DC9DD6E2
00007175dc9dd84d  call 0x00007175DC8E27E0
00007175dc9dd852  jmp 0x00007175DC9DD6FC
00007175dc9dd857  call 0x00007175DC8E0300
00007175dc9dd85c  jmp 0x00007175DC9DD708
00007175dc9dd861  call 0x00007175DC8E27E0
00007175dc9dd866  jmp 0x00007175DC9DD740
00007175dc9dd86b  call 0x00007175DC8E0300
00007175dc9dd870  jmp 0x00007175DC9DD74C
00007175dc9dd875  call 0x00007175DC8E27E0
00007175dc9dd87a  jmp 0x00007175DC9DD784
00007175dc9dd87f  call 0x00007175DC8E0300
00007175dc9dd884  jmp 0x00007175DC9DD790
00007175dc9dd889  call 0x00007175DC8E27E0
00007175dc9dd88e  jmp 0x00007175DC9DD7C8
00007175dc9dd893  call 0x00007175DC8E0300
00007175dc9dd898  jmp 0x00007175DC9DD7D4
00007175dc9dd89d  int3
00007175dc9dd89e  nop
00007175dc9dd8a0  mov qword ptr [r15+0x100], 0x04
00007175dc9dd8ab  mov esi, 0x00
00007175dc9dd8b0  mov edx, 0x09
00007175dc9dd8b5  mov rdi, 0x7FFCAEAC0320
00007175dc9dd8bf  mov rax, 0x622B29B42970
00007175dc9dd8c9  call rax
00007175dc9dd8cb  cmp dword ptr [r15+0x318], 0x00
00007175dc9dd8d3  jnz 0x00007175DC7FE110
00007175dc9dd8d9  jmp 0x00007175DC7FE0A0
00007175dc9dd8de  int3
00007175dc9dd8df  int3
