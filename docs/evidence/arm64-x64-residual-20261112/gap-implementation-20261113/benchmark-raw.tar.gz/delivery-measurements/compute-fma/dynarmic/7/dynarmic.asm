00007b2719bce69b  nop [rax+rax*1], eax
00007b2719bce6a0  mov rax, [r15+0xF8]
00007b2719bce6a7  lea r14, [rax-0x1B0]
00007b2719bce6ae  mov [r15+0xF8], r14
00007b2719bce6b5  lea rax, [r14+0x1A0]
00007b2719bce6bc  mov r12, [r15+0xA0]
00007b2719bce6c3  mov r11, [r15+0x98]
00007b2719bce6ca  mov [r13+rax*1], r12
00007b2719bce6cf  lea rax, [r14+0x1A8]
00007b2719bce6d6  mov [r13+rax*1], r11
00007b2719bce6db  mov eax, 0x420A30
00007b2719bce6e0  movups xmm1, [r13+rax*1]
00007b2719bce6e6  mov eax, 0x4209C0
00007b2719bce6eb  movups xmm15, [r13+rax*1]
00007b2719bce6f1  mov eax, 0x420A50
00007b2719bce6f6  movups xmm14, [r13+rax*1]
00007b2719bce6fc  mov eax, 0x4209F0
00007b2719bce701  movups xmm13, [r13+rax*1]
00007b2719bce707  mov qword ptr [r15+0x98], 0x430C60
00007b2719bce712  mov eax, 0x420A60
00007b2719bce717  movups xmm12, [r13+rax*1]
00007b2719bce71d  mov eax, 0x430C60
00007b2719bce722  movups [r13+rax*1], xmm1
00007b2719bce728  mov eax, 0x430C70
00007b2719bce72d  movups [r13+rax*1], xmm15
00007b2719bce733  mov eax, 0x430C80
00007b2719bce738  movups [r13+rax*1], xmm14
00007b2719bce73e  mov eax, 0x430C90
00007b2719bce743  movups [r13+rax*1], xmm13
00007b2719bce749  mov eax, 0x4209B0
00007b2719bce74e  movups xmm14, [r13+rax*1]
00007b2719bce754  mov eax, 0x4209A0
00007b2719bce759  movups xmm13, [r13+rax*1]
00007b2719bce75f  mov eax, 0x430D60
00007b2719bce764  movups [r13+rax*1], xmm1
00007b2719bce76a  mov eax, 0x430D70
00007b2719bce76f  movups [r13+rax*1], xmm15
00007b2719bce775  mov eax, 0x430CA0
00007b2719bce77a  movups [r13+rax*1], xmm12
00007b2719bce780  mov eax, 0x430CB0
00007b2719bce785  movups [r13+rax*1], xmm14
00007b2719bce78b  mov eax, 0x420990
00007b2719bce790  movups xmm1, [r13+rax*1]
00007b2719bce796  mov eax, 0x420A00
00007b2719bce79b  movups xmm15, [r13+rax*1]
00007b2719bce7a1  mov eax, 0x430CC0
00007b2719bce7a6  movups [r13+rax*1], xmm13
00007b2719bce7ac  mov eax, 0x430CD0
00007b2719bce7b1  movups [r13+rax*1], xmm1
00007b2719bce7b7  mov eax, 0x420A10
00007b2719bce7bc  movups xmm1, [r13+rax*1]
00007b2719bce7c2  mov eax, 0x4209E0
00007b2719bce7c7  movups xmm14, [r13+rax*1]
00007b2719bce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007b2719bce7d5  mov eax, 0x430CE0
00007b2719bce7da  movups [r13+rax*1], xmm15
00007b2719bce7e0  mov eax, 0x430CF0
00007b2719bce7e5  movups [r13+rax*1], xmm1
00007b2719bce7eb  mov eax, 0x420A80
00007b2719bce7f0  movups xmm1, [r13+rax*1]
00007b2719bce7f6  mov eax, 0x420A90
00007b2719bce7fb  movups xmm15, [r13+rax*1]
00007b2719bce801  movaps [r15+0x150], xmm15
00007b2719bce809  mov qword ptr [r15+0xA0], 0x3E8
00007b2719bce814  mov eax, 0x430D00
00007b2719bce819  movups [r13+rax*1], xmm14
00007b2719bce81f  mov eax, 0x430D10
00007b2719bce824  movups [r13+rax*1], xmm1
00007b2719bce82a  mov eax, 0x420A70
00007b2719bce82f  movups xmm1, [r13+rax*1]
00007b2719bce835  mov eax, 0x420A20
00007b2719bce83a  movups xmm14, [r13+rax*1]
00007b2719bce840  movaps [r15+0x140], xmm14
00007b2719bce848  lea rax, [r14+0x150]
00007b2719bce84f  movq xmm13, qword ptr [r15+0x200]
00007b2719bce858  movq xmm12, qword ptr [r15+0x1F0]
00007b2719bce861  movq r12, xmm13
00007b2719bce866  movq r11, xmm12
00007b2719bce86b  mov [r13+rax*1], r12
00007b2719bce870  lea rax, [r14+0x158]
00007b2719bce877  mov [r13+rax*1], r11
00007b2719bce87c  mov eax, 0x430D20
00007b2719bce881  movups [r13+rax*1], xmm15
00007b2719bce887  mov eax, 0x430D30
00007b2719bce88c  movups [r13+rax*1], xmm1
00007b2719bce892  mov eax, 0x420A40
00007b2719bce897  movups xmm1, [r13+rax*1]
00007b2719bce89d  mov eax, 0x420AA8
00007b2719bce8a2  mov r12, [r13+rax*1]
00007b2719bce8a7  movq xmm15, r12
00007b2719bce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007b2719bce8b4  mov eax, 0x430D40
00007b2719bce8b9  movups [r13+rax*1], xmm14
00007b2719bce8bf  mov eax, 0x430D50
00007b2719bce8c4  movups [r13+rax*1], xmm1
00007b2719bce8ca  mov eax, 0x420B10
00007b2719bce8cf  movups xmm1, [r13+rax*1]
00007b2719bce8d5  movq rax, xmm15
00007b2719bce8da  mov r12d, 0x430D80
00007b2719bce8e0  mov [r13+r12*1], rax
00007b2719bce8e5  mov eax, 0x420AF0
00007b2719bce8ea  movups xmm15, [r13+rax*1]
00007b2719bce8f0  mov eax, 0x420B00
00007b2719bce8f5  movups xmm14, [r13+rax*1]
00007b2719bce8fb  lea rax, [r14+0x130]
00007b2719bce902  movups [r13+rax*1], xmm1
00007b2719bce908  lea rax, [r14+0x160]
00007b2719bce90f  movq xmm1, qword ptr [r15+0x1E0]
00007b2719bce918  movq xmm13, qword ptr [r15+0x1D0]
00007b2719bce921  movq r12, xmm1
00007b2719bce926  movq r11, xmm13
00007b2719bce92b  mov [r13+rax*1], r12
00007b2719bce930  lea rax, [r14+0x168]
00007b2719bce937  mov [r13+rax*1], r11
00007b2719bce93c  lea rax, [r14+0x110]
00007b2719bce943  movups [r13+rax*1], xmm15
00007b2719bce949  lea rax, [r14+0x120]
00007b2719bce950  movups [r13+rax*1], xmm14
00007b2719bce956  mov eax, 0x420AB0
00007b2719bce95b  movups xmm1, [r13+rax*1]
00007b2719bce961  mov eax, 0x420AC0
00007b2719bce966  movups xmm15, [r13+rax*1]
00007b2719bce96c  movaps [r15+0x120], xmm15
00007b2719bce974  lea rax, [r14+0x170]
00007b2719bce97b  movq xmm14, qword ptr [r15+0x1C0]
00007b2719bce984  movq xmm13, qword ptr [r15+0x1B0]
00007b2719bce98d  movq r12, xmm14
00007b2719bce992  movq r11, xmm13
00007b2719bce997  mov [r13+rax*1], r12
00007b2719bce99c  lea rax, [r14+0x178]
00007b2719bce9a3  mov [r13+rax*1], r11
00007b2719bce9a8  lea rax, [r14+0x180]
00007b2719bce9af  movq xmm14, qword ptr [r15+0x1A0]
00007b2719bce9b8  movq xmm13, qword ptr [r15+0x190]
00007b2719bce9c1  movq r12, xmm14
00007b2719bce9c6  movq r11, xmm13
00007b2719bce9cb  mov [r13+rax*1], r12
00007b2719bce9d0  lea rax, [r14+0x188]
00007b2719bce9d7  mov [r13+rax*1], r11
00007b2719bce9dc  lea rax, [r14+0xD0]
00007b2719bce9e3  movups [r13+rax*1], xmm1
00007b2719bce9e9  lea rax, [r14+0xE0]
00007b2719bce9f0  movups [r13+rax*1], xmm15
00007b2719bce9f6  mov eax, 0x420AD0
00007b2719bce9fb  movups xmm1, [r13+rax*1]
00007b2719bcea01  mov eax, 0x420AE0
00007b2719bcea06  movups xmm15, [r13+rax*1]
00007b2719bcea0c  movaps [r15+0x110], xmm1
00007b2719bcea14  movaps [r15+0x130], xmm15
00007b2719bcea1c  lea rax, [r14+0x190]
00007b2719bcea23  mov r12, [r15+0xE8]
00007b2719bcea2a  mov r11, [r15+0xF0]
00007b2719bcea31  mov [r13+rax*1], r12
00007b2719bcea36  lea rax, [r14+0x198]
00007b2719bcea3d  mov [r13+rax*1], r11
00007b2719bcea42  mov eax, 0x430D88
00007b2719bcea47  mov r12d, 0x421DF8D3
00007b2719bcea4d  mov [r13+rax*1], r12d
00007b2719bcea52  lea rax, [r14+0xF0]
00007b2719bcea59  movups [r13+rax*1], xmm1
00007b2719bcea5f  lea rax, [r14+0x100]
00007b2719bcea66  movups [r13+rax*1], xmm15
00007b2719bcea6c  lea rax, [r14+0xD0]
00007b2719bcea73  mov [r15], rax
00007b2719bcea76  mov qword ptr [r15+0x08], 0x430C60
00007b2719bcea7e  mov qword ptr [r15+0x10], 0x12C
00007b2719bcea86  mov qword ptr [r15+0xF0], 0x410284
00007b2719bcea91  mov r14d, [r15+0x320]
00007b2719bcea98  mov eax, 0x410284
00007b2719bcea9d  mov rcx, 0x7B2719BD07C0
00007b2719bceaa7  mov [r15+r14*8+0x328], rax
00007b2719bceaaf  mov [r15+r14*8+0x368], rcx
00007b2719bceab7  add r14d, 0x01
00007b2719bceabb  and r14d, 0x07
00007b2719bceabf  mov [r15+0x320], r14d
00007b2719bceac6  cmp dword ptr [r15+0x318], 0x00
00007b2719bceace  jz 0x00007B2719BCED70
00007b2719bcead4  nop [rax+rax*1], ax
00007b2719bceadd  nop [rax+rax*1], eax
00007b2719bceae5  mov eax, 0x4106BC
00007b2719bceaea  mov [r15+0x100], rax
00007b2719bceaf1  jmp 0x00007B27199FE110
00007b2719bceaf6  int3
00007b2719bceaf7  call 0x00007B2719A0BC20
00007b2719bceafc  jmp 0x00007B2719BCE6CF
00007b2719bceb01  call 0x00007B2719A0A9A0
00007b2719bceb06  jmp 0x00007B2719BCE6DB
00007b2719bceb0b  call 0x00007B27199FF430
00007b2719bceb10  jmp 0x00007B2719BCE6E6
00007b2719bceb15  call 0x00007B2719A0E760
00007b2719bceb1a  jmp 0x00007B2719BCE6F1
00007b2719bceb1f  call 0x00007B2719A0D4E0
00007b2719bceb24  jmp 0x00007B2719BCE6FC
00007b2719bceb29  call 0x00007B2719A0C260
00007b2719bceb2e  jmp 0x00007B2719BCE707
00007b2719bceb33  call 0x00007B2719A0AFE0
00007b2719bceb38  jmp 0x00007B2719BCE71D
00007b2719bceb3d  call 0x00007B27199FF540
00007b2719bceb42  jmp 0x00007B2719BCE728
00007b2719bceb47  call 0x00007B2719A0E880
00007b2719bceb4c  jmp 0x00007B2719BCE733
00007b2719bceb51  call 0x00007B2719A0D600
00007b2719bceb56  jmp 0x00007B2719BCE73E
00007b2719bceb5b  call 0x00007B2719A0C380
00007b2719bceb60  jmp 0x00007B2719BCE749
00007b2719bceb65  call 0x00007B2719A0D4E0
00007b2719bceb6a  jmp 0x00007B2719BCE754
00007b2719bceb6f  call 0x00007B2719A0C260
00007b2719bceb74  jmp 0x00007B2719BCE75F
00007b2719bceb79  call 0x00007B27199FF540
00007b2719bceb7e  jmp 0x00007B2719BCE76A
00007b2719bceb83  call 0x00007B2719A0E880
00007b2719bceb88  jmp 0x00007B2719BCE775
00007b2719bceb8d  call 0x00007B2719A0B100
00007b2719bceb92  jmp 0x00007B2719BCE780
00007b2719bceb97  call 0x00007B2719A0D600
00007b2719bceb9c  jmp 0x00007B2719BCE78B
00007b2719bceba1  call 0x00007B27199FF430
00007b2719bceba6  jmp 0x00007B2719BCE796
00007b2719bcebab  call 0x00007B2719A0E760
00007b2719bcebb0  jmp 0x00007B2719BCE7A1
00007b2719bcebb5  call 0x00007B2719A0C380
00007b2719bcebba  jmp 0x00007B2719BCE7AC
00007b2719bcebbf  call 0x00007B27199FF540
00007b2719bcebc4  jmp 0x00007B2719BCE7B7
00007b2719bcebc9  call 0x00007B27199FF430
00007b2719bcebce  jmp 0x00007B2719BCE7C2
00007b2719bcebd3  call 0x00007B2719A0D4E0
00007b2719bcebd8  jmp 0x00007B2719BCE7CD
00007b2719bcebdd  call 0x00007B2719A0E880
00007b2719bcebe2  jmp 0x00007B2719BCE7E0
00007b2719bcebe7  call 0x00007B27199FF540
00007b2719bcebec  jmp 0x00007B2719BCE7EB
00007b2719bcebf1  call 0x00007B27199FF430
00007b2719bcebf6  jmp 0x00007B2719BCE7F6
00007b2719bcebfb  call 0x00007B2719A0E760
00007b2719bcec00  jmp 0x00007B2719BCE801
00007b2719bcec05  call 0x00007B2719A0D600
00007b2719bcec0a  jmp 0x00007B2719BCE81F
00007b2719bcec0f  call 0x00007B27199FF540
00007b2719bcec14  jmp 0x00007B2719BCE82A
00007b2719bcec19  call 0x00007B27199FF430
00007b2719bcec1e  jmp 0x00007B2719BCE835
00007b2719bcec23  call 0x00007B2719A0D4E0
00007b2719bcec28  jmp 0x00007B2719BCE840
00007b2719bcec2d  call 0x00007B2719A0BC20
00007b2719bcec32  jmp 0x00007B2719BCE870
00007b2719bcec37  call 0x00007B2719A0A9A0
00007b2719bcec3c  jmp 0x00007B2719BCE87C
00007b2719bcec41  call 0x00007B2719A0E880
00007b2719bcec46  jmp 0x00007B2719BCE887
00007b2719bcec4b  call 0x00007B27199FF540
00007b2719bcec50  jmp 0x00007B2719BCE892
00007b2719bcec55  call 0x00007B27199FF430
00007b2719bcec5a  jmp 0x00007B2719BCE89D
00007b2719bcec5f  call 0x00007B2719A0B720
00007b2719bcec64  jmp 0x00007B2719BCE8A7
00007b2719bcec69  call 0x00007B2719A0D600
00007b2719bcec6e  jmp 0x00007B2719BCE8BF
00007b2719bcec73  call 0x00007B27199FF540
00007b2719bcec78  jmp 0x00007B2719BCE8CA
00007b2719bcec7d  call 0x00007B27199FF430
00007b2719bcec82  jmp 0x00007B2719BCE8D5
00007b2719bcec87  call 0x00007B2719AB4CB0
00007b2719bcec8c  jmp 0x00007B2719BCE8E5
00007b2719bcec91  call 0x00007B2719A0E760
00007b2719bcec96  jmp 0x00007B2719BCE8F0
00007b2719bcec9b  call 0x00007B2719A0D4E0
00007b2719bceca0  jmp 0x00007B2719BCE8FB
00007b2719bceca5  call 0x00007B27199FF540
00007b2719bcecaa  jmp 0x00007B2719BCE908
00007b2719bcecaf  call 0x00007B2719A0BC20
00007b2719bcecb4  jmp 0x00007B2719BCE930
00007b2719bcecb9  call 0x00007B2719A0A9A0
00007b2719bcecbe  jmp 0x00007B2719BCE93C
00007b2719bcecc3  call 0x00007B2719A0E880
00007b2719bcecc8  jmp 0x00007B2719BCE949
00007b2719bceccd  call 0x00007B2719A0D600
00007b2719bcecd2  jmp 0x00007B2719BCE956
00007b2719bcecd7  call 0x00007B27199FF430
00007b2719bcecdc  jmp 0x00007B2719BCE961
00007b2719bcece1  call 0x00007B2719A0E760
00007b2719bcece6  jmp 0x00007B2719BCE96C
00007b2719bceceb  call 0x00007B2719A0BC20
00007b2719bcecf0  jmp 0x00007B2719BCE99C
00007b2719bcecf5  call 0x00007B2719A0A9A0
00007b2719bcecfa  jmp 0x00007B2719BCE9A8
00007b2719bcecff  call 0x00007B2719A0BC20
00007b2719bced04  jmp 0x00007B2719BCE9D0
00007b2719bced09  call 0x00007B2719A0A9A0
00007b2719bced0e  jmp 0x00007B2719BCE9DC
00007b2719bced13  call 0x00007B27199FF540
00007b2719bced18  jmp 0x00007B2719BCE9E9
00007b2719bced1d  call 0x00007B2719A0E880
00007b2719bced22  jmp 0x00007B2719BCE9F6
00007b2719bced27  call 0x00007B27199FF430
00007b2719bced2c  jmp 0x00007B2719BCEA01
00007b2719bced31  call 0x00007B2719A0E760
00007b2719bced36  jmp 0x00007B2719BCEA0C
00007b2719bced3b  call 0x00007B2719A0BC20
00007b2719bced40  jmp 0x00007B2719BCEA36
00007b2719bced45  call 0x00007B2719A0A9A0
00007b2719bced4a  jmp 0x00007B2719BCEA42
00007b2719bced4f  call 0x00007B2719A0BAE0
00007b2719bced54  jmp 0x00007B2719BCEA52
00007b2719bced59  call 0x00007B27199FF540
00007b2719bced5e  jmp 0x00007B2719BCEA5F
00007b2719bced63  call 0x00007B2719A0E880
00007b2719bced68  jmp 0x00007B2719BCEA6C
00007b2719bced6d  int3
00007b2719bced6e  nop
00007b2719bced70  mov rax, [r15]
00007b2719bced73  lea r14, [rax+0x20]
00007b2719bced77  mov r12, [r13+r14*1]
00007b2719bced7c  mov r14, [r15+0x10]
00007b2719bced80  lea r11, [r12+r14*1]
00007b2719bced84  mov [r15+0x40], r11
00007b2719bced88  lea r12, [rax+0x20]
00007b2719bced8c  mov [r13+r12*1], r11
00007b2719bced91  test r14, r14
00007b2719bced94  setz r14b
00007b2719bced98  movzx r14, r14b
00007b2719bced9c  mov [rsp+0x414], r14b
00007b2719bceda4  cmp byte ptr [rsp+0x414], 0x00
00007b2719bcedac  jz 0x00007B2719BCEDDE
00007b2719bcedae  cmp dword ptr [r15+0x318], 0x00
00007b2719bcedb6  mov eax, 0x410934
00007b2719bcedbb  mov [r15+0x100], rax
00007b2719bcedc2  jz 0x00007B27199FE0A0
00007b2719bcedc8  nop [rax+rax*1], eax
00007b2719bcedcd  mov eax, 0x410934
00007b2719bcedd2  mov [r15+0x100], rax
00007b2719bcedd9  jmp 0x00007B27199FE110
00007b2719bcedde  cmp dword ptr [r15+0x318], 0x00
00007b2719bcede6  jz 0x00007B2719BCEE30
00007b2719bcedec  nop [rax+rax*1], ax
00007b2719bcedf5  nop [rax+rax*1], eax
00007b2719bcedfd  mov eax, 0x4106CC
00007b2719bcee02  mov [r15+0x100], rax
00007b2719bcee09  jmp 0x00007B27199FE110
00007b2719bcee0e  int3
00007b2719bcee0f  call 0x00007B2719AE27E0
00007b2719bcee14  jmp 0x00007B2719BCED7C
00007b2719bcee19  call 0x00007B2719AC0860
00007b2719bcee1e  jmp 0x00007B2719BCED91
00007b2719bcee23  int3
00007b2719bcee24  nop [rax+rax*1], ax
00007b2719bcee2d  nop [rax], eax
00007b2719bcee30  mov rax, [r15+0xF8]
00007b2719bcee37  lea r14, [rax-0x150]
00007b2719bcee3e  mov [r15+0xF8], r14
00007b2719bcee45  mov rax, [r15]
00007b2719bcee48  lea r12, [rax+0x68]
00007b2719bcee4c  mov r11, [r13+r12*1]
00007b2719bcee51  mov [r15+0x88], r11
00007b2719bcee58  lea r12, [rax+0x28]
00007b2719bcee5c  mov [r15+0x40], r12
00007b2719bcee60  mov [r15+0x48], r14
00007b2719bcee64  mov qword ptr [r15+0x50], 0x420B20
00007b2719bcee6c  lea rax, [r14+0x100]
00007b2719bcee73  mov r12, [r15+0xE8]
00007b2719bcee7a  mov r11, [r15+0xD8]
00007b2719bcee81  mov [r13+rax*1], r12
00007b2719bcee86  lea rax, [r14+0x108]
00007b2719bcee8d  mov [r13+rax*1], r11
00007b2719bcee92  lea rax, [r14+0x110]
00007b2719bcee99  mov r12, [r15+0xD0]
00007b2719bceea0  mov r11, [r15+0xC8]
00007b2719bceea7  mov [r13+rax*1], r12
00007b2719bceeac  lea rax, [r14+0x118]
00007b2719bceeb3  mov [r13+rax*1], r11
00007b2719bceeb8  lea rax, [r14+0x120]
00007b2719bceebf  mov r12, [r15+0xC0]
00007b2719bceec6  mov r11, [r15+0xB8]
00007b2719bceecd  mov [r13+rax*1], r12
00007b2719bceed2  lea rax, [r14+0x128]
00007b2719bceed9  mov [r13+rax*1], r11
00007b2719bceede  lea rax, [r14+0x130]
00007b2719bceee5  mov r12, [r15+0xB0]
00007b2719bceeec  mov r11, [r15+0xA8]
00007b2719bceef3  mov [r13+rax*1], r12
00007b2719bceef8  lea rax, [r14+0x138]
00007b2719bceeff  mov [r13+rax*1], r11
00007b2719bcef04  lea rax, [r14+0x140]
00007b2719bcef0b  mov r12, [r15+0xA0]
00007b2719bcef12  mov r11, [r15+0x98]
00007b2719bcef19  mov [r13+rax*1], r12
00007b2719bcef1e  lea rax, [r14+0x148]
00007b2719bcef25  mov [r13+rax*1], r11
00007b2719bcef2a  cmp dword ptr [r15+0x318], 0x00
00007b2719bcef32  jz 0x00007B2719BCEFD0
00007b2719bcef38  nop [rax+rax*1], ax
00007b2719bcef41  nop [rax+rax*1], eax
00007b2719bcef49  mov eax, 0x410704
00007b2719bcef4e  mov [r15+0x100], rax
00007b2719bcef55  jmp 0x00007B27199FE110
00007b2719bcef5a  int3
00007b2719bcef5b  call 0x00007B2719AC0370
00007b2719bcef60  jmp 0x00007B2719BCEE51
00007b2719bcef65  call 0x00007B2719A0BC20
00007b2719bcef6a  jmp 0x00007B2719BCEE86
00007b2719bcef6f  call 0x00007B2719A0A9A0
00007b2719bcef74  jmp 0x00007B2719BCEE92
00007b2719bcef79  call 0x00007B2719A0BC20
00007b2719bcef7e  jmp 0x00007B2719BCEEAC
00007b2719bcef83  call 0x00007B2719A0A9A0
00007b2719bcef88  jmp 0x00007B2719BCEEB8
00007b2719bcef8d  call 0x00007B2719A0BC20
00007b2719bcef92  jmp 0x00007B2719BCEED2
00007b2719bcef97  call 0x00007B2719A0A9A0
00007b2719bcef9c  jmp 0x00007B2719BCEEDE
00007b2719bcefa1  call 0x00007B2719A0BC20
00007b2719bcefa6  jmp 0x00007B2719BCEEF8
00007b2719bcefab  call 0x00007B2719A0A9A0
00007b2719bcefb0  jmp 0x00007B2719BCEF04
00007b2719bcefb5  call 0x00007B2719A0BC20
00007b2719bcefba  jmp 0x00007B2719BCEF1E
00007b2719bcefbf  call 0x00007B2719A0A9A0
00007b2719bcefc4  jmp 0x00007B2719BCEF2A
00007b2719bcefc9  int3
00007b2719bcefca  nop [rax+rax*1], ax
00007b2719bcefd0  mov rax, [r15+0x08]
00007b2719bcefd4  movzx r14d, byte ptr [r13+rax*1]
00007b2719bcefda  movzx r14d, r14b
00007b2719bcefde  mov [rsp+0x10], r14d
00007b2719bcefe3  mov r14d, r14d
00007b2719bcefe6  mov [r15+0x58], r14
00007b2719bcefea  lea r14, [rax+0x01]
00007b2719bcefee  mov [r15+0x08], r14
00007b2719bceff2  mov rax, [r15+0x88]
00007b2719bceff9  lea r14, [rax+0x01]
00007b2719bceffd  mov r12, [r15]
00007b2719bcf000  lea r11, [r12+0x68]
00007b2719bcf005  mov [r13+r11*1], r14
00007b2719bcf00a  lea r14, [r12+rax*1]
00007b2719bcf00e  mov [r15+0x60], r14
00007b2719bcf012  lea rax, [r14+0x28]
00007b2719bcf016  mov r11d, [rsp+0x10]
00007b2719bcf01b  movzx r14d, r11b
00007b2719bcf01f  mov [r13+rax*1], r14b
00007b2719bcf024  lea rax, [r12+0x68]
00007b2719bcf029  mov r14, [r13+rax*1]
00007b2719bcf02e  mov [r15+0x88], r14
00007b2719bcf035  xor eax, eax
00007b2719bcf037  mov r12d, 0x40
00007b2719bcf03d  cmp r14, r12
00007b2719bcf040  cmc
00007b2719bcf041  lahf
00007b2719bcf042  seto al
00007b2719bcf045  mov [r15+0x108], eax
00007b2719bcf04c  mov eax, [r15+0x108]
00007b2719bcf053  sahf
00007b2719bcf054  jnz 0x00007B2719BCF086
00007b2719bcf056  cmp dword ptr [r15+0x318], 0x00
00007b2719bcf05e  jz 0x00007B2719BCF170
00007b2719bcf064  nop [rax+rax*1], ax
00007b2719bcf06d  nop [rax+rax*1], eax
00007b2719bcf075  mov eax, 0x410724
00007b2719bcf07a  mov [r15+0x100], rax
00007b2719bcf081  jmp 0x00007B27199FE110
00007b2719bcf086  cmp dword ptr [r15+0x318], 0x00
00007b2719bcf08e  jz 0x00007B2719BCF0E0
00007b2719bcf094  nop [rax+rax*1], ax
00007b2719bcf09d  nop [rax+rax*1], eax
00007b2719bcf0a5  mov eax, 0x4106FC
00007b2719bcf0aa  mov [r15+0x100], rax
00007b2719bcf0b1  jmp 0x00007B27199FE110
00007b2719bcf0b6  int3
00007b2719bcf0b7  call 0x00007B2719A0D860
00007b2719bcf0bc  jmp 0x00007B2719BCEFDA
00007b2719bcf0c1  call 0x00007B2719AB36E0
00007b2719bcf0c6  jmp 0x00007B2719BCF00A
00007b2719bcf0cb  call 0x00007B2719A0DD60
00007b2719bcf0d0  jmp 0x00007B2719BCF024
00007b2719bcf0d5  call 0x00007B2719A0DC20
00007b2719bcf0da  jmp 0x00007B2719BCF02E
00007b2719bcf0df  int3
00007b2719bcf0e0  mov rax, [r15+0x10]
00007b2719bcf0e4  lea r14, [rax-0x01]
00007b2719bcf0e8  mov [r15+0x10], r14
00007b2719bcf0ec  test r14, r14
00007b2719bcf0ef  setz r14b
00007b2719bcf0f3  movzx r14, r14b
00007b2719bcf0f7  mov [rsp+0x414], r14b
00007b2719bcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007b2719bcf107  jz 0x00007B2719BCF139
00007b2719bcf109  cmp dword ptr [r15+0x318], 0x00
00007b2719bcf111  jz 0x00007B2719BD0670
00007b2719bcf117  nop [rax+rax*1], ax
00007b2719bcf120  nop [rax+rax*1], eax
00007b2719bcf128  mov eax, 0x41091C
00007b2719bcf12d  mov [r15+0x100], rax
00007b2719bcf134  jmp 0x00007B27199FE110
00007b2719bcf139  cmp dword ptr [r15+0x318], 0x00
00007b2719bcf141  jz 0x00007B2719BCEFD0
00007b2719bcf147  nop [rax+rax*1], ax
00007b2719bcf150  nop [rax+rax*1], eax
00007b2719bcf158  mov eax, 0x410704
00007b2719bcf15d  mov [r15+0x100], rax
00007b2719bcf164  jmp 0x00007B27199FE110
00007b2719bcf169  int3
00007b2719bcf16a  int3
00007b2719bcf16b  nop [rax+rax*1], eax
00007b2719bcf170  mov rax, [r15+0x40]
00007b2719bcf174  movzx r14d, byte ptr [r13+rax*1]
00007b2719bcf17a  movaps xmm1, [r15+0x110]
00007b2719bcf182  pinsrb xmm1, r14d, 0x00
00007b2719bcf189  lea r14, [rax+0x01]
00007b2719bcf18d  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf193  movaps xmm15, [r15+0x120]
00007b2719bcf19b  pinsrb xmm15, r12d, 0x00
00007b2719bcf1a2  lea r14, [rax+0x02]
00007b2719bcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf1ac  movaps xmm14, [r15+0x130]
00007b2719bcf1b4  pinsrb xmm14, r12d, 0x00
00007b2719bcf1bb  lea r14, [rax+0x03]
00007b2719bcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf1c5  movaps xmm13, [r15+0x140]
00007b2719bcf1cd  pinsrb xmm13, r12d, 0x00
00007b2719bcf1d4  lea r14, [rax+0x04]
00007b2719bcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf1de  pinsrb xmm1, r12d, 0x01
00007b2719bcf1e5  lea r14, [rax+0x05]
00007b2719bcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf1ef  pinsrb xmm15, r12d, 0x01
00007b2719bcf1f6  lea r14, [rax+0x06]
00007b2719bcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf200  pinsrb xmm14, r12d, 0x01
00007b2719bcf207  lea r14, [rax+0x07]
00007b2719bcf20b  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf211  pinsrb xmm13, r12d, 0x01
00007b2719bcf218  lea r14, [rax+0x08]
00007b2719bcf21c  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf222  pinsrb xmm1, r12d, 0x02
00007b2719bcf229  lea r14, [rax+0x09]
00007b2719bcf22d  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf233  pinsrb xmm15, r12d, 0x02
00007b2719bcf23a  lea r14, [rax+0x0A]
00007b2719bcf23e  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf244  pinsrb xmm14, r12d, 0x02
00007b2719bcf24b  lea r14, [rax+0x0B]
00007b2719bcf24f  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf255  pinsrb xmm13, r12d, 0x02
00007b2719bcf25c  lea r14, [rax+0x0C]
00007b2719bcf260  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf266  pinsrb xmm1, r12d, 0x03
00007b2719bcf26d  lea r14, [rax+0x0D]
00007b2719bcf271  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf277  pinsrb xmm15, r12d, 0x03
00007b2719bcf27e  lea r14, [rax+0x0E]
00007b2719bcf282  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf288  pinsrb xmm14, r12d, 0x03
00007b2719bcf28f  lea r14, [rax+0x0F]
00007b2719bcf293  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf299  pinsrb xmm13, r12d, 0x03
00007b2719bcf2a0  lea r14, [rax+0x10]
00007b2719bcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf2aa  pinsrb xmm1, r12d, 0x04
00007b2719bcf2b1  lea r14, [rax+0x11]
00007b2719bcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf2bb  pinsrb xmm15, r12d, 0x04
00007b2719bcf2c2  lea r14, [rax+0x12]
00007b2719bcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf2cc  pinsrb xmm14, r12d, 0x04
00007b2719bcf2d3  lea r14, [rax+0x13]
00007b2719bcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf2dd  pinsrb xmm13, r12d, 0x04
00007b2719bcf2e4  lea r14, [rax+0x14]
00007b2719bcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf2ee  pinsrb xmm1, r12d, 0x05
00007b2719bcf2f5  lea r14, [rax+0x15]
00007b2719bcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf2ff  pinsrb xmm15, r12d, 0x05
00007b2719bcf306  lea r14, [rax+0x16]
00007b2719bcf30a  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf310  pinsrb xmm14, r12d, 0x05
00007b2719bcf317  lea r14, [rax+0x17]
00007b2719bcf31b  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf321  pinsrb xmm13, r12d, 0x05
00007b2719bcf328  lea r14, [rax+0x18]
00007b2719bcf32c  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf332  pinsrb xmm1, r12d, 0x06
00007b2719bcf339  lea r14, [rax+0x19]
00007b2719bcf33d  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf343  pinsrb xmm15, r12d, 0x06
00007b2719bcf34a  lea r14, [rax+0x1A]
00007b2719bcf34e  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf354  pinsrb xmm14, r12d, 0x06
00007b2719bcf35b  lea r14, [rax+0x1B]
00007b2719bcf35f  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf365  pinsrb xmm13, r12d, 0x06
00007b2719bcf36c  lea r14, [rax+0x1C]
00007b2719bcf370  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf376  pinsrb xmm1, r12d, 0x07
00007b2719bcf37d  lea r14, [rax+0x1D]
00007b2719bcf381  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf387  pinsrb xmm15, r12d, 0x07
00007b2719bcf38e  lea r14, [rax+0x1E]
00007b2719bcf392  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf398  pinsrb xmm14, r12d, 0x07
00007b2719bcf39f  lea r14, [rax+0x1F]
00007b2719bcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf3a9  pinsrb xmm13, r12d, 0x07
00007b2719bcf3b0  lea r14, [rax+0x20]
00007b2719bcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf3ba  pinsrb xmm1, r12d, 0x08
00007b2719bcf3c1  lea r14, [rax+0x21]
00007b2719bcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf3cb  pinsrb xmm15, r12d, 0x08
00007b2719bcf3d2  lea r14, [rax+0x22]
00007b2719bcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf3dc  pinsrb xmm14, r12d, 0x08
00007b2719bcf3e3  lea r14, [rax+0x23]
00007b2719bcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf3ed  pinsrb xmm13, r12d, 0x08
00007b2719bcf3f4  lea r14, [rax+0x24]
00007b2719bcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf3fe  pinsrb xmm1, r12d, 0x09
00007b2719bcf405  lea r14, [rax+0x25]
00007b2719bcf409  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf40f  pinsrb xmm15, r12d, 0x09
00007b2719bcf416  lea r14, [rax+0x26]
00007b2719bcf41a  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf420  pinsrb xmm14, r12d, 0x09
00007b2719bcf427  lea r14, [rax+0x27]
00007b2719bcf42b  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf431  pinsrb xmm13, r12d, 0x09
00007b2719bcf438  lea r14, [rax+0x28]
00007b2719bcf43c  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf442  pinsrb xmm1, r12d, 0x0A
00007b2719bcf449  lea r14, [rax+0x29]
00007b2719bcf44d  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf453  pinsrb xmm15, r12d, 0x0A
00007b2719bcf45a  lea r14, [rax+0x2A]
00007b2719bcf45e  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf464  pinsrb xmm14, r12d, 0x0A
00007b2719bcf46b  lea r14, [rax+0x2B]
00007b2719bcf46f  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf475  pinsrb xmm13, r12d, 0x0A
00007b2719bcf47c  lea r14, [rax+0x2C]
00007b2719bcf480  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf486  pinsrb xmm1, r12d, 0x0B
00007b2719bcf48d  lea r14, [rax+0x2D]
00007b2719bcf491  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf497  pinsrb xmm15, r12d, 0x0B
00007b2719bcf49e  lea r14, [rax+0x2E]
00007b2719bcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf4a8  pinsrb xmm14, r12d, 0x0B
00007b2719bcf4af  lea r14, [rax+0x2F]
00007b2719bcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf4b9  pinsrb xmm13, r12d, 0x0B
00007b2719bcf4c0  lea r14, [rax+0x30]
00007b2719bcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf4ca  pinsrb xmm1, r12d, 0x0C
00007b2719bcf4d1  lea r14, [rax+0x31]
00007b2719bcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf4db  pinsrb xmm15, r12d, 0x0C
00007b2719bcf4e2  lea r14, [rax+0x32]
00007b2719bcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf4ec  pinsrb xmm14, r12d, 0x0C
00007b2719bcf4f3  lea r14, [rax+0x33]
00007b2719bcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf4fd  pinsrb xmm13, r12d, 0x0C
00007b2719bcf504  lea r14, [rax+0x34]
00007b2719bcf508  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf50e  pinsrb xmm1, r12d, 0x0D
00007b2719bcf515  lea r14, [rax+0x35]
00007b2719bcf519  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf51f  pinsrb xmm15, r12d, 0x0D
00007b2719bcf526  lea r14, [rax+0x36]
00007b2719bcf52a  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf530  pinsrb xmm14, r12d, 0x0D
00007b2719bcf537  lea r14, [rax+0x37]
00007b2719bcf53b  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf541  pinsrb xmm13, r12d, 0x0D
00007b2719bcf548  lea r14, [rax+0x38]
00007b2719bcf54c  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf552  pinsrb xmm1, r12d, 0x0E
00007b2719bcf559  lea r14, [rax+0x39]
00007b2719bcf55d  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf563  pinsrb xmm15, r12d, 0x0E
00007b2719bcf56a  lea r14, [rax+0x3A]
00007b2719bcf56e  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf574  pinsrb xmm14, r12d, 0x0E
00007b2719bcf57b  lea r14, [rax+0x3B]
00007b2719bcf57f  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf585  pinsrb xmm13, r12d, 0x0E
00007b2719bcf58c  lea r14, [rax+0x3C]
00007b2719bcf590  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf596  pinsrb xmm1, r12d, 0x0F
00007b2719bcf59d  movaps [r15+0x110], xmm1
00007b2719bcf5a5  lea r14, [rax+0x3D]
00007b2719bcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf5af  pinsrb xmm15, r12d, 0x0F
00007b2719bcf5b6  movaps [r15+0x120], xmm15
00007b2719bcf5be  lea r14, [rax+0x3E]
00007b2719bcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007b2719bcf5c8  pinsrb xmm14, r12d, 0x0F
00007b2719bcf5cf  movaps [r15+0x130], xmm14
00007b2719bcf5d7  lea r14, [rax+0x3F]
00007b2719bcf5db  movzx eax, byte ptr [r13+r14*1]
00007b2719bcf5e1  pinsrb xmm13, eax, 0x0F
00007b2719bcf5e8  movaps [r15+0x140], xmm13
00007b2719bcf5f0  movq xmm1, qword ptr [r15+0x120]
00007b2719bcf5f9  pmovzxbw xmm1, xmm1
00007b2719bcf5fe  psllw xmm1, 0x00
00007b2719bcf603  movaps [r15+0x150], xmm1
00007b2719bcf60b  movq xmm1, qword ptr [r15+0x130]
00007b2719bcf614  pmovzxbw xmm1, xmm1
00007b2719bcf619  psllw xmm1, 0x00
00007b2719bcf61e  movaps [r15+0x160], xmm1
00007b2719bcf626  movq xmm1, qword ptr [r15+0x110]
00007b2719bcf62f  pmovzxbw xmm1, xmm1
00007b2719bcf634  psllw xmm1, 0x00
00007b2719bcf639  movaps [r15+0x170], xmm1
00007b2719bcf641  movaps xmm15, [r15+0x110]
00007b2719bcf649  pextrq rax, xmm15, 0x01
00007b2719bcf650  movq xmm15, rax
00007b2719bcf655  pmovzxbw xmm15, xmm15
00007b2719bcf65b  psllw xmm15, 0x00
00007b2719bcf661  movaps [r15+0x180], xmm15
00007b2719bcf669  movaps xmm14, [r15+0x120]
00007b2719bcf671  pextrq rax, xmm14, 0x01
00007b2719bcf678  movq xmm14, rax
00007b2719bcf67d  pmovzxbw xmm14, xmm14
00007b2719bcf683  psllw xmm14, 0x00
00007b2719bcf689  movaps [r15+0x210], xmm14
00007b2719bcf691  movaps xmm13, [r15+0x130]
00007b2719bcf699  pextrq rax, xmm13, 0x01
00007b2719bcf6a0  movq xmm13, rax
00007b2719bcf6a5  pmovzxbw xmm13, xmm13
00007b2719bcf6ab  psllw xmm13, 0x00
00007b2719bcf6b1  movaps [r15+0x220], xmm13
00007b2719bcf6b9  movq xmm12, qword ptr [r15+0x140]
00007b2719bcf6c2  pmovzxbw xmm12, xmm12
00007b2719bcf6c8  psllw xmm12, 0x00
00007b2719bcf6ce  movaps [r15+0x250], xmm12
00007b2719bcf6d6  movaps xmm12, [r15+0x140]
00007b2719bcf6de  pextrq rax, xmm12, 0x01
00007b2719bcf6e5  movq xmm12, rax
00007b2719bcf6ea  pmovzxbw xmm12, xmm12
00007b2719bcf6f0  psllw xmm12, 0x00
00007b2719bcf6f6  movaps [r15+0x110], xmm12
00007b2719bcf6fe  movq xmm11, qword ptr [r15+0x150]
00007b2719bcf707  pmovzxwd xmm11, xmm11
00007b2719bcf70d  pslld xmm11, 0x10
00007b2719bcf713  movq xmm10, qword ptr [r15+0x160]
00007b2719bcf71c  pmovzxwd xmm10, xmm10
00007b2719bcf722  pslld xmm10, 0x08
00007b2719bcf728  pextrq rax, xmm1, 0x01
00007b2719bcf72f  movq xmm1, rax
00007b2719bcf734  pmovzxwd xmm1, xmm1
00007b2719bcf739  pslld xmm1, 0x00
00007b2719bcf73e  movaps [r15+0x260], xmm1
00007b2719bcf746  pextrq rax, xmm15, 0x01
00007b2719bcf74d  movq xmm15, rax
00007b2719bcf752  pmovzxwd xmm15, xmm15
00007b2719bcf758  pslld xmm15, 0x00
00007b2719bcf75e  movaps [r15+0x270], xmm15
00007b2719bcf766  movq xmm9, qword ptr [r15+0x170]
00007b2719bcf76f  pmovzxwd xmm9, xmm9
00007b2719bcf775  pslld xmm9, 0x00
00007b2719bcf77b  pextrq rax, xmm14, 0x01
00007b2719bcf782  movq xmm14, rax
00007b2719bcf787  pmovzxwd xmm14, xmm14
00007b2719bcf78d  pslld xmm14, 0x10
00007b2719bcf793  movaps [r15+0x280], xmm14
00007b2719bcf79b  movq xmm8, qword ptr [r15+0x180]
00007b2719bcf7a4  pmovzxwd xmm8, xmm8
00007b2719bcf7aa  pslld xmm8, 0x00
00007b2719bcf7b0  movq xmm7, qword ptr [r15+0x210]
00007b2719bcf7b9  pmovzxwd xmm7, xmm7
00007b2719bcf7be  pslld xmm7, 0x10
00007b2719bcf7c3  movaps xmm6, [r15+0x150]
00007b2719bcf7cb  pextrq rax, xmm6, 0x01
00007b2719bcf7d2  movq xmm6, rax
00007b2719bcf7d7  pmovzxwd xmm6, xmm6
00007b2719bcf7dc  pslld xmm6, 0x10
00007b2719bcf7e1  por xmm11, xmm10
00007b2719bcf7e6  movaps [r15+0x230], xmm11
00007b2719bcf7ee  pextrq rax, xmm13, 0x01
00007b2719bcf7f5  movq xmm13, rax
00007b2719bcf7fa  pmovzxwd xmm13, xmm13
00007b2719bcf800  pslld xmm13, 0x08
00007b2719bcf806  movaps [r15+0x240], xmm13
00007b2719bcf80e  movq xmm10, qword ptr [r15+0x220]
00007b2719bcf817  pmovzxwd xmm10, xmm10
00007b2719bcf81d  pslld xmm10, 0x08
00007b2719bcf823  movaps xmm5, [r15+0x160]
00007b2719bcf82b  pextrq rax, xmm5, 0x01
00007b2719bcf832  movq xmm5, rax
00007b2719bcf837  pmovzxwd xmm5, xmm5
00007b2719bcf83c  pslld xmm5, 0x08
00007b2719bcf841  pslld xmm9, 0x18
00007b2719bcf847  pslld xmm15, 0x18
00007b2719bcf84d  pslld xmm8, 0x18
00007b2719bcf853  movq xmm4, qword ptr [r15+0x250]
00007b2719bcf85c  pmovzxwd xmm4, xmm4
00007b2719bcf861  pslld xmm4, 0x00
00007b2719bcf866  por xmm14, xmm13
00007b2719bcf86b  por xmm7, xmm10
00007b2719bcf870  movaps [r15+0x210], xmm7
00007b2719bcf878  pslld xmm1, 0x18
00007b2719bcf87d  movaps [r15+0x220], xmm1
00007b2719bcf885  por xmm6, xmm5
00007b2719bcf889  por xmm11, xmm9
00007b2719bcf88e  movaps [r15+0x160], xmm11
00007b2719bcf896  pextrq rax, xmm12, 0x01
00007b2719bcf89d  movq xmm13, rax
00007b2719bcf8a2  pmovzxwd xmm13, xmm13
00007b2719bcf8a8  pslld xmm13, 0x00
00007b2719bcf8ae  movaps [r15+0x170], xmm13
00007b2719bcf8b6  movq xmm12, qword ptr [r15+0x110]
00007b2719bcf8bf  pmovzxwd xmm12, xmm12
00007b2719bcf8c5  pslld xmm12, 0x00
00007b2719bcf8cb  por xmm14, xmm15
00007b2719bcf8d0  por xmm7, xmm8
00007b2719bcf8d5  movaps xmm15, [r15+0x250]
00007b2719bcf8dd  pextrq rax, xmm15, 0x01
00007b2719bcf8e4  movq xmm15, rax
00007b2719bcf8e9  pmovzxwd xmm15, xmm15
00007b2719bcf8ef  pslld xmm15, 0x00
00007b2719bcf8f5  movaps [r15+0x180], xmm15
00007b2719bcf8fd  por xmm6, xmm1
00007b2719bcf901  movaps [r15+0x150], xmm6
00007b2719bcf909  por xmm11, xmm4
00007b2719bcf90e  movaps [r15+0x140], xmm11
00007b2719bcf916  por xmm7, xmm12
00007b2719bcf91b  movaps [r15+0x110], xmm7
00007b2719bcf923  por xmm14, xmm13
00007b2719bcf928  movaps [r15+0x120], xmm14
00007b2719bcf930  por xmm6, xmm15
00007b2719bcf935  movaps [r15+0x130], xmm6
00007b2719bcf93d  mov rax, [r15+0xF8]
00007b2719bcf944  lea r14, [rax+0x20]
00007b2719bcf948  movups [r13+r14*1], xmm7
00007b2719bcf94e  lea r14, [rax+0x30]
00007b2719bcf952  movups [r13+r14*1], xmm14
00007b2719bcf958  movups [r13+rax*1], xmm11
00007b2719bcf95e  lea r14, [rax+0x10]
00007b2719bcf962  movups [r13+r14*1], xmm6
00007b2719bcf968  mov r14d, [r13+rax*1]
00007b2719bcf96d  mov rax, [r15+0x48]
00007b2719bcf971  mov [r15+0x68], rax
00007b2719bcf975  mov qword ptr [r15+0x58], 0x04
00007b2719bcf97d  lea r12, [rax+0x04]
00007b2719bcf981  mov r11d, [r13+r12*1]
00007b2719bcf986  mov [rsp+0x10], r11d
00007b2719bcf98b  mov r11d, r11d
00007b2719bcf98e  mov [r15+0x70], r11
00007b2719bcf992  lea r12, [rax+0x38]
00007b2719bcf996  mov r11d, [r13+r12*1]
00007b2719bcf99b  lea r12, [rax+0x24]
00007b2719bcf99f  mov r10d, [r13+r12*1]
00007b2719bcf9a4  mov [rsp+0x20], r10d
00007b2719bcf9a9  mov r10d, r10d
00007b2719bcf9ac  mov [r15+0x90], r10
00007b2719bcf9b3  mov [rsp+0x30], rax
00007b2719bcf9b8  xor eax, eax
00007b2719bcf9ba  mov r12d, 0x04
00007b2719bcf9c0  mov r10d, 0xC0
00007b2719bcf9c6  cmp r12, r10
00007b2719bcf9c9  cmc
00007b2719bcf9ca  lahf
00007b2719bcf9cb  seto al
00007b2719bcf9ce  mov [r15+0x108], eax
00007b2719bcf9d5  mov eax, [rsp+0x10]
00007b2719bcf9d9  mov r12d, [rsp+0x10]
00007b2719bcf9de  shrd eax, r12d, 0x07
00007b2719bcf9e3  mov [rsp+0x10], r11d
00007b2719bcf9e8  mov r10d, [rsp+0x10]
00007b2719bcf9ed  shrd r11d, r10d, 0x11
00007b2719bcf9f2  mov r9d, [rsp+0x20]
00007b2719bcf9f7  lea r8d, [r9d+r14d*1]
00007b2719bcf9fc  rorx r14d, r12d, 0x12
00007b2719bcfa02  xor eax, r14d
00007b2719bcfa05  rorx r14d, r10d, 0x13
00007b2719bcfa0b  xor r11d, r14d
00007b2719bcfa0e  mov [rsp+0x10], r11d
00007b2719bcfa13  mov r11d, r11d
00007b2719bcfa16  mov [r15+0x88], r11
00007b2719bcfa1d  mov [rsp+0x20], r12d
00007b2719bcfa22  shr r12d, 0x03
00007b2719bcfa26  xor eax, r12d
00007b2719bcfa29  mov [rsp+0x40], eax
00007b2719bcfa2d  mov eax, eax
00007b2719bcfa2f  mov [r15+0x80], rax
00007b2719bcfa36  shr r10d, 0x0A
00007b2719bcfa3a  mov eax, [rsp+0x10]
00007b2719bcfa3e  xor eax, r10d
00007b2719bcfa41  mov [rsp+0x10], eax
00007b2719bcfa45  mov eax, eax
00007b2719bcfa47  mov [r15+0x78], rax
00007b2719bcfa4b  mov eax, [rsp+0x40]
00007b2719bcfa4f  lea r14d, [r8d+eax*1]
00007b2719bcfa54  mov eax, [rsp+0x10]
00007b2719bcfa58  lea r12d, [r14d+eax*1]
00007b2719bcfa5d  mov rax, [rsp+0x30]
00007b2719bcfa62  lea r14, [rax+0x40]
00007b2719bcfa66  mov [r13+r14*1], r12d
00007b2719bcfa6b  mov eax, [rsp+0x20]
00007b2719bcfa6f  mov eax, eax
00007b2719bcfa71  mov [r15+0x60], rax
00007b2719bcfa75  mov eax, [r15+0x108]
00007b2719bcfa7c  sahf
00007b2719bcfa7d  jnz 0x00007B2719BCFAAF
00007b2719bcfa7f  cmp dword ptr [r15+0x318], 0x00
00007b2719bcfa87  jz 0x00007B2719BCFF70
00007b2719bcfa8d  nop [rax+rax*1], ax
00007b2719bcfa96  nop [rax+rax*1], eax
00007b2719bcfa9e  mov eax, 0x410820
00007b2719bcfaa3  mov [r15+0x100], rax
00007b2719bcfaaa  jmp 0x00007B27199FE110
00007b2719bcfaaf  cmp dword ptr [r15+0x318], 0x00
00007b2719bcfab7  jz 0x00007B2719BCFDC0
00007b2719bcfabd  nop [rax+rax*1], ax
00007b2719bcfac6  nop [rax+rax*1], eax
00007b2719bcface  mov eax, 0x4107D8
00007b2719bcfad3  mov [r15+0x100], rax
00007b2719bcfada  jmp 0x00007B27199FE110
00007b2719bcfadf  int3
00007b2719bcfae0  call 0x00007B2719A0D860
00007b2719bcfae5  jmp 0x00007B2719BCF17A
00007b2719bcfaea  call 0x00007B2719AE2420
00007b2719bcfaef  jmp 0x00007B2719BCF193
00007b2719bcfaf4  call 0x00007B2719AE2420
00007b2719bcfaf9  jmp 0x00007B2719BCF1AC
00007b2719bcfafe  call 0x00007B2719AE2420
00007b2719bcfb03  jmp 0x00007B2719BCF1C5
00007b2719bcfb08  call 0x00007B2719AE2420
00007b2719bcfb0d  jmp 0x00007B2719BCF1DE
00007b2719bcfb12  call 0x00007B2719AE2420
00007b2719bcfb17  jmp 0x00007B2719BCF1EF
00007b2719bcfb1c  call 0x00007B2719AE2420
00007b2719bcfb21  jmp 0x00007B2719BCF200
00007b2719bcfb26  call 0x00007B2719AE2420
00007b2719bcfb2b  jmp 0x00007B2719BCF211
00007b2719bcfb30  call 0x00007B2719AE2420
00007b2719bcfb35  jmp 0x00007B2719BCF222
00007b2719bcfb3a  call 0x00007B2719AE2420
00007b2719bcfb3f  jmp 0x00007B2719BCF233
00007b2719bcfb44  call 0x00007B2719AE2420
00007b2719bcfb49  jmp 0x00007B2719BCF244
00007b2719bcfb4e  call 0x00007B2719AE2420
00007b2719bcfb53  jmp 0x00007B2719BCF255
00007b2719bcfb58  call 0x00007B2719AE2420
00007b2719bcfb5d  jmp 0x00007B2719BCF266
00007b2719bcfb62  call 0x00007B2719AE2420
00007b2719bcfb67  jmp 0x00007B2719BCF277
00007b2719bcfb6c  call 0x00007B2719AE2420
00007b2719bcfb71  jmp 0x00007B2719BCF288
00007b2719bcfb76  call 0x00007B2719AE2420
00007b2719bcfb7b  jmp 0x00007B2719BCF299
00007b2719bcfb80  call 0x00007B2719AE2420
00007b2719bcfb85  jmp 0x00007B2719BCF2AA
00007b2719bcfb8a  call 0x00007B2719AE2420
00007b2719bcfb8f  jmp 0x00007B2719BCF2BB
00007b2719bcfb94  call 0x00007B2719AE2420
00007b2719bcfb99  jmp 0x00007B2719BCF2CC
00007b2719bcfb9e  call 0x00007B2719AE2420
00007b2719bcfba3  jmp 0x00007B2719BCF2DD
00007b2719bcfba8  call 0x00007B2719AE2420
00007b2719bcfbad  jmp 0x00007B2719BCF2EE
00007b2719bcfbb2  call 0x00007B2719AE2420
00007b2719bcfbb7  jmp 0x00007B2719BCF2FF
00007b2719bcfbbc  call 0x00007B2719AE2420
00007b2719bcfbc1  jmp 0x00007B2719BCF310
00007b2719bcfbc6  call 0x00007B2719AE2420
00007b2719bcfbcb  jmp 0x00007B2719BCF321
00007b2719bcfbd0  call 0x00007B2719AE2420
00007b2719bcfbd5  jmp 0x00007B2719BCF332
00007b2719bcfbda  call 0x00007B2719AE2420
00007b2719bcfbdf  jmp 0x00007B2719BCF343
00007b2719bcfbe4  call 0x00007B2719AE2420
00007b2719bcfbe9  jmp 0x00007B2719BCF354
00007b2719bcfbee  call 0x00007B2719AE2420
00007b2719bcfbf3  jmp 0x00007B2719BCF365
00007b2719bcfbf8  call 0x00007B2719AE2420
00007b2719bcfbfd  jmp 0x00007B2719BCF376
00007b2719bcfc02  call 0x00007B2719AE2420
00007b2719bcfc07  jmp 0x00007B2719BCF387
00007b2719bcfc0c  call 0x00007B2719AE2420
00007b2719bcfc11  jmp 0x00007B2719BCF398
00007b2719bcfc16  call 0x00007B2719AE2420
00007b2719bcfc1b  jmp 0x00007B2719BCF3A9
00007b2719bcfc20  call 0x00007B2719AE2420
00007b2719bcfc25  jmp 0x00007B2719BCF3BA
00007b2719bcfc2a  call 0x00007B2719AE2420
00007b2719bcfc2f  jmp 0x00007B2719BCF3CB
00007b2719bcfc34  call 0x00007B2719AE2420
00007b2719bcfc39  jmp 0x00007B2719BCF3DC
00007b2719bcfc3e  call 0x00007B2719AE2420
00007b2719bcfc43  jmp 0x00007B2719BCF3ED
00007b2719bcfc48  call 0x00007B2719AE2420
00007b2719bcfc4d  jmp 0x00007B2719BCF3FE
00007b2719bcfc52  call 0x00007B2719AE2420
00007b2719bcfc57  jmp 0x00007B2719BCF40F
00007b2719bcfc5c  call 0x00007B2719AE2420
00007b2719bcfc61  jmp 0x00007B2719BCF420
00007b2719bcfc66  call 0x00007B2719AE2420
00007b2719bcfc6b  jmp 0x00007B2719BCF431
00007b2719bcfc70  call 0x00007B2719AE2420
00007b2719bcfc75  jmp 0x00007B2719BCF442
00007b2719bcfc7a  call 0x00007B2719AE2420
00007b2719bcfc7f  jmp 0x00007B2719BCF453
00007b2719bcfc84  call 0x00007B2719AE2420
00007b2719bcfc89  jmp 0x00007B2719BCF464
00007b2719bcfc8e  call 0x00007B2719AE2420
00007b2719bcfc93  jmp 0x00007B2719BCF475
00007b2719bcfc98  call 0x00007B2719AE2420
00007b2719bcfc9d  jmp 0x00007B2719BCF486
00007b2719bcfca2  call 0x00007B2719AE2420
00007b2719bcfca7  jmp 0x00007B2719BCF497
00007b2719bcfcac  call 0x00007B2719AE2420
00007b2719bcfcb1  jmp 0x00007B2719BCF4A8
00007b2719bcfcb6  call 0x00007B2719AE2420
00007b2719bcfcbb  jmp 0x00007B2719BCF4B9
00007b2719bcfcc0  call 0x00007B2719AE2420
00007b2719bcfcc5  jmp 0x00007B2719BCF4CA
00007b2719bcfcca  call 0x00007B2719AE2420
00007b2719bcfccf  jmp 0x00007B2719BCF4DB
00007b2719bcfcd4  call 0x00007B2719AE2420
00007b2719bcfcd9  jmp 0x00007B2719BCF4EC
00007b2719bcfcde  call 0x00007B2719AE2420
00007b2719bcfce3  jmp 0x00007B2719BCF4FD
00007b2719bcfce8  call 0x00007B2719AE2420
00007b2719bcfced  jmp 0x00007B2719BCF50E
00007b2719bcfcf2  call 0x00007B2719AE2420
00007b2719bcfcf7  jmp 0x00007B2719BCF51F
00007b2719bcfcfc  call 0x00007B2719AE2420
00007b2719bcfd01  jmp 0x00007B2719BCF530
00007b2719bcfd06  call 0x00007B2719AE2420
00007b2719bcfd0b  jmp 0x00007B2719BCF541
00007b2719bcfd10  call 0x00007B2719AE2420
00007b2719bcfd15  jmp 0x00007B2719BCF552
00007b2719bcfd1a  call 0x00007B2719AE2420
00007b2719bcfd1f  jmp 0x00007B2719BCF563
00007b2719bcfd24  call 0x00007B2719AE2420
00007b2719bcfd29  jmp 0x00007B2719BCF574
00007b2719bcfd2e  call 0x00007B2719AE2420
00007b2719bcfd33  jmp 0x00007B2719BCF585
00007b2719bcfd38  call 0x00007B2719AE2420
00007b2719bcfd3d  jmp 0x00007B2719BCF596
00007b2719bcfd42  call 0x00007B2719AE2420
00007b2719bcfd47  jmp 0x00007B2719BCF5AF
00007b2719bcfd4c  call 0x00007B2719AE2420
00007b2719bcfd51  jmp 0x00007B2719BCF5C8
00007b2719bcfd56  call 0x00007B2719AD5610
00007b2719bcfd5b  jmp 0x00007B2719BCF5E1
00007b2719bcfd60  call 0x00007B2719ADC580
00007b2719bcfd65  jmp 0x00007B2719BCF94E
00007b2719bcfd6a  call 0x00007B2719AE46C0
00007b2719bcfd6f  jmp 0x00007B2719BCF958
00007b2719bcfd74  call 0x00007B2719A09E90
00007b2719bcfd79  jmp 0x00007B2719BCF95E
00007b2719bcfd7e  call 0x00007B2719ADB310
00007b2719bcfd83  jmp 0x00007B2719BCF968
00007b2719bcfd88  call 0x00007B2719A0DAE0
00007b2719bcfd8d  jmp 0x00007B2719BCF96D
00007b2719bcfd92  call 0x00007B2719AC0230
00007b2719bcfd97  jmp 0x00007B2719BCF986
00007b2719bcfd9c  call 0x00007B2719AC0230
00007b2719bcfda1  jmp 0x00007B2719BCF99B
00007b2719bcfda6  call 0x00007B2719ABEFC0
00007b2719bcfdab  jmp 0x00007B2719BCF9A4
00007b2719bcfdb0  call 0x00007B2719AE2BA0
00007b2719bcfdb5  jmp 0x00007B2719BCFA6B
00007b2719bcfdba  int3
00007b2719bcfdbb  nop [rax+rax*1], eax
00007b2719bcfdc0  mov rax, [r15+0x48]
00007b2719bcfdc4  mov r14, [r15+0x58]
00007b2719bcfdc8  lea r12, [rax+r14*1]
00007b2719bcfdcc  mov [r15+0x68], r12
00007b2719bcfdd0  lea rax, [r14+0x04]
00007b2719bcfdd4  mov [r15+0x58], rax
00007b2719bcfdd8  lea r14, [r12+0x04]
00007b2719bcfddd  mov r11d, [r13+r14*1]
00007b2719bcfde2  mov [rsp+0x10], r11d
00007b2719bcfde7  mov r11d, r11d
00007b2719bcfdea  mov [r15+0x70], r11
00007b2719bcfdee  lea r14, [r12+0x38]
00007b2719bcfdf3  mov r11d, [r13+r14*1]
00007b2719bcfdf8  lea r14, [r12+0x24]
00007b2719bcfdfd  mov r10d, [r13+r14*1]
00007b2719bcfe02  mov [rsp+0x20], r10d
00007b2719bcfe07  mov r10d, r10d
00007b2719bcfe0a  mov [r15+0x90], r10
00007b2719bcfe11  mov [rsp+0x30], rax
00007b2719bcfe16  xor eax, eax
00007b2719bcfe18  mov r14, [rsp+0x30]
00007b2719bcfe1d  mov r10d, 0xC0
00007b2719bcfe23  cmp r14, r10
00007b2719bcfe26  cmc
00007b2719bcfe27  lahf
00007b2719bcfe28  seto al
00007b2719bcfe2b  mov [r15+0x108], eax
00007b2719bcfe32  mov eax, [rsp+0x10]
00007b2719bcfe36  mov r14d, [rsp+0x10]
00007b2719bcfe3b  shrd eax, r14d, 0x07
00007b2719bcfe40  mov [rsp+0x10], r11d
00007b2719bcfe45  mov r10d, [rsp+0x10]
00007b2719bcfe4a  shrd r11d, r10d, 0x11
00007b2719bcfe4f  mov r9d, [r15+0x60]
00007b2719bcfe53  mov r8d, [rsp+0x20]
00007b2719bcfe58  lea ebp, [r8d+r9d*1]
00007b2719bcfe5d  rorx r9d, r14d, 0x12
00007b2719bcfe63  xor eax, r9d
00007b2719bcfe66  rorx r9d, r10d, 0x13
00007b2719bcfe6c  xor r11d, r9d
00007b2719bcfe6f  mov [rsp+0x10], r11d
00007b2719bcfe74  mov r11d, r11d
00007b2719bcfe77  mov [r15+0x88], r11
00007b2719bcfe7e  mov [rsp+0x20], r14d
00007b2719bcfe83  shr r14d, 0x03
00007b2719bcfe87  xor eax, r14d
00007b2719bcfe8a  mov [rsp+0x30], eax
00007b2719bcfe8e  mov eax, eax
00007b2719bcfe90  mov [r15+0x80], rax
00007b2719bcfe97  shr r10d, 0x0A
00007b2719bcfe9b  mov eax, [rsp+0x10]
00007b2719bcfe9f  xor eax, r10d
00007b2719bcfea2  mov [rsp+0x10], eax
00007b2719bcfea6  mov eax, eax
00007b2719bcfea8  mov [r15+0x78], rax
00007b2719bcfeac  mov eax, [rsp+0x30]
00007b2719bcfeb0  lea r14d, [ebp+eax*1]
00007b2719bcfeb6  mov eax, [rsp+0x10]
00007b2719bcfeba  lea r11d, [r14d+eax*1]
00007b2719bcfebf  lea rax, [r12+0x40]
00007b2719bcfec4  mov [r13+rax*1], r11d
00007b2719bcfec9  mov eax, [rsp+0x20]
00007b2719bcfecd  mov eax, eax
00007b2719bcfecf  mov [r15+0x60], rax
00007b2719bcfed3  mov eax, [r15+0x108]
00007b2719bcfeda  sahf
00007b2719bcfedb  jnz 0x00007B2719BCFF0D
00007b2719bcfedd  cmp dword ptr [r15+0x318], 0x00
00007b2719bcfee5  jz 0x00007B2719BCFF70
00007b2719bcfeeb  nop [rax+rax*1], ax
00007b2719bcfef4  nop [rax+rax*1], eax
00007b2719bcfefc  mov eax, 0x410820
00007b2719bcff01  mov [r15+0x100], rax
00007b2719bcff08  jmp 0x00007B27199FE110
00007b2719bcff0d  cmp dword ptr [r15+0x318], 0x00
00007b2719bcff15  jz 0x00007B2719BCFDC0
00007b2719bcff1b  nop [rax+rax*1], ax
00007b2719bcff24  nop [rax+rax*1], eax
00007b2719bcff2c  mov eax, 0x4107D8
00007b2719bcff31  mov [r15+0x100], rax
00007b2719bcff38  jmp 0x00007B27199FE110
00007b2719bcff3d  int3
00007b2719bcff3e  call 0x00007B2719AE1430
00007b2719bcff43  jmp 0x00007B2719BCFDE2
00007b2719bcff48  call 0x00007B2719AE1430
00007b2719bcff4d  jmp 0x00007B2719BCFDF8
00007b2719bcff52  call 0x00007B2719AE01C0
00007b2719bcff57  jmp 0x00007B2719BCFE02
00007b2719bcff5c  call 0x00007B2719A0A860
00007b2719bcff61  jmp 0x00007B2719BCFEC9
00007b2719bcff66  int3
00007b2719bcff67  nop [rax+rax*1], ax
00007b2719bcff70  mov rax, [r15]
00007b2719bcff73  mov r14d, [r13+rax*1]
00007b2719bcff78  lea r12, [rax+0x04]
00007b2719bcff7c  mov r11d, [r13+r12*1]
00007b2719bcff81  mov [rsp+0x10], r14d
00007b2719bcff86  mov r14d, r14d
00007b2719bcff89  mov [r15+0x78], r14
00007b2719bcff8d  mov [rsp+0x20], r11d
00007b2719bcff92  mov r11d, r11d
00007b2719bcff95  mov [r15+0x80], r11
00007b2719bcff9c  lea r14, [rax+0x08]
00007b2719bcffa0  mov r12d, [r13+r14*1]
00007b2719bcffa5  lea r14, [rax+0x0C]
00007b2719bcffa9  mov r11d, [r13+r14*1]
00007b2719bcffae  mov [rsp+0x30], r12d
00007b2719bcffb3  mov r12d, r12d
00007b2719bcffb6  mov [r15+0x70], r12
00007b2719bcffba  mov [rsp+0x40], r11d
00007b2719bcffbf  mov r11d, r11d
00007b2719bcffc2  mov [r15+0x68], r11
00007b2719bcffc6  lea r14, [rax+0x18]
00007b2719bcffca  mov r12d, [r13+r14*1]
00007b2719bcffcf  lea r14, [rax+0x1C]
00007b2719bcffd3  mov r11d, [r13+r14*1]
00007b2719bcffd8  mov [rsp+0x50], r12d
00007b2719bcffdd  mov r12d, r12d
00007b2719bcffe0  mov [r15+0x58], r12
00007b2719bcffe4  mov [rsp+0x60], r11d
00007b2719bcffe9  mov r11d, r11d
00007b2719bcffec  mov [r15+0x60], r11
00007b2719bcfff0  lea r14, [rax+0x10]
00007b2719bcfff4  mov r12d, [r13+r14*1]
00007b2719bcfff9  lea r14, [rax+0x14]
00007b2719bcfffd  mov eax, [r13+r14*1]
00007b2719bd0002  mov [rsp+0x70], r12d
00007b2719bd0007  mov r12d, r12d
00007b2719bd000a  mov [r15+0x18], r12
00007b2719bd000e  mov [rsp+0x80], eax
00007b2719bd0015  mov eax, eax
00007b2719bd0017  mov [r15+0x90], rax
00007b2719bd001e  mov eax, [rsp+0x70]
00007b2719bd0022  mov eax, eax
00007b2719bd0024  mov [r15+0x30], rax
00007b2719bd0028  mov eax, [rsp+0x50]
00007b2719bd002c  mov eax, eax
00007b2719bd002e  mov [r15+0xA0], rax
00007b2719bd0035  mov eax, [rsp+0x30]
00007b2719bd0039  mov eax, eax
00007b2719bd003b  mov [r15+0x28], rax
00007b2719bd003f  mov eax, [rsp+0x20]
00007b2719bd0043  mov eax, eax
00007b2719bd0045  mov [r15+0x98], rax
00007b2719bd004c  mov eax, [rsp+0x10]
00007b2719bd0050  mov eax, eax
00007b2719bd0052  mov [r15+0x38], rax
00007b2719bd0056  mov eax, [rsp+0x70]
00007b2719bd005a  mov r14d, [rsp+0x70]
00007b2719bd005f  shrd eax, r14d, 0x06
00007b2719bd0064  mov [rsp+0x70], r14d
00007b2719bd0069  mov r12d, [rsp+0x80]
00007b2719bd0071  and r14d, r12d
00007b2719bd0074  mov r11d, [rsp+0x10]
00007b2719bd0079  mov r10d, [rsp+0x10]
00007b2719bd007e  shrd r11d, r10d, 0x02
00007b2719bd0083  mov [rsp+0x10], r12d
00007b2719bd0088  mov r12d, r12d
00007b2719bd008b  mov [r15+0x20], r12
00007b2719bd008f  mov r12, [r15+0x50]
00007b2719bd0093  mov r9d, [r13+r12*1]
00007b2719bd0098  mov r12d, [rsp+0x50]
00007b2719bd009d  mov r8d, [rsp+0x70]
00007b2719bd00a2  andn ebp, r8d, r12d
00007b2719bd00a7  mov edi, [rsp+0x60]
00007b2719bd00ab  lea esi, [r14d+edi*1]
00007b2719bd00b0  rorx r14d, r8d, 0x0B
00007b2719bd00b6  xor eax, r14d
00007b2719bd00b9  rorx r14d, r10d, 0x0D
00007b2719bd00bf  xor r11d, r14d
00007b2719bd00c2  lea edi, [esi+ebp*1]
00007b2719bd00c6  mov r14, [r15+0x48]
00007b2719bd00ca  mov ebp, [r13+r14*1]
00007b2719bd00cf  mov r14d, [rsp+0x30]
00007b2719bd00d4  mov esi, [rsp+0x20]
00007b2719bd00d8  and r14d, esi
00007b2719bd00db  mov [rsp+0x20], r14d
00007b2719bd00e0  mov r14d, r14d
00007b2719bd00e3  mov [r15+0xD8], r14
00007b2719bd00ea  lea r14d, [edi+r9d*1]
00007b2719bd00ef  mov r9d, [rsp+0x30]
00007b2719bd00f4  xor r9d, esi
00007b2719bd00f7  rorx edi, r8d, 0x19
00007b2719bd00fd  xor eax, edi
00007b2719bd00ff  and r9d, r10d
00007b2719bd0102  rorx edi, r10d, 0x16
00007b2719bd0108  xor r11d, edi
00007b2719bd010b  mov [rsp+0x30], r11d
00007b2719bd0110  mov r11d, r11d
00007b2719bd0113  mov [r15+0xD0], r11
00007b2719bd011a  lea r11d, [r14d+ebp*1]
00007b2719bd011f  mov r10d, [rsp+0x20]
00007b2719bd0124  xor r9d, r10d
00007b2719bd0127  lea r14d, [r11d+eax*1]
00007b2719bd012c  mov qword ptr [r15+0x88], 0x04
00007b2719bd0137  mov eax, [rsp+0x30]
00007b2719bd013b  lea r11d, [r9d+eax*1]
00007b2719bd0140  mov eax, [rsp+0x40]
00007b2719bd0144  lea r10d, [r14d+eax*1]
00007b2719bd0149  mov r10d, r10d
00007b2719bd014c  mov [r15+0xB8], r10
00007b2719bd0153  xor eax, eax
00007b2719bd0155  mov r10d, 0x04
00007b2719bd015b  mov r9d, 0x100
00007b2719bd0161  cmp r10, r9
00007b2719bd0164  cmc
00007b2719bd0165  lahf
00007b2719bd0166  seto al
00007b2719bd0169  mov [r15+0x108], eax
00007b2719bd0170  lea eax, [r11d+r14d*1]
00007b2719bd0175  mov eax, eax
00007b2719bd0177  mov [r15+0xA8], rax
00007b2719bd017e  mov r12d, r12d
00007b2719bd0181  mov [r15+0xB0], r12
00007b2719bd0188  mov eax, [rsp+0x10]
00007b2719bd018c  mov eax, eax
00007b2719bd018e  mov [r15+0xC0], rax
00007b2719bd0195  mov r8d, r8d
00007b2719bd0198  mov [r15+0xC8], r8
00007b2719bd019f  mov eax, [r15+0x108]
00007b2719bd01a6  sahf
00007b2719bd01a7  jnz 0x00007B2719BD01D9
00007b2719bd01a9  cmp dword ptr [r15+0x318], 0x00
00007b2719bd01b1  jz 0x00007B2719BD04A0
00007b2719bd01b7  nop [rax+rax*1], ax
00007b2719bd01c0  nop [rax+rax*1], eax
00007b2719bd01c8  mov eax, 0x4108E0
00007b2719bd01cd  mov [r15+0x100], rax
00007b2719bd01d4  jmp 0x00007B27199FE110
00007b2719bd01d9  cmp dword ptr [r15+0x318], 0x00
00007b2719bd01e1  jz 0x00007B2719BD0270
00007b2719bd01e7  nop [rax+rax*1], ax
00007b2719bd01f0  nop [rax+rax*1], eax
00007b2719bd01f8  mov eax, 0x410854
00007b2719bd01fd  mov [r15+0x100], rax
00007b2719bd0204  jmp 0x00007B27199FE110
00007b2719bd0209  int3
00007b2719bd020a  call 0x00007B2719A0DAE0
00007b2719bd020f  jmp 0x00007B2719BCFF78
00007b2719bd0214  call 0x00007B2719AC0230
00007b2719bd0219  jmp 0x00007B2719BCFF81
00007b2719bd021e  call 0x00007B2719AE26A0
00007b2719bd0223  jmp 0x00007B2719BCFFA5
00007b2719bd0228  call 0x00007B2719AE1430
00007b2719bd022d  jmp 0x00007B2719BCFFAE
00007b2719bd0232  call 0x00007B2719AE26A0
00007b2719bd0237  jmp 0x00007B2719BCFFCF
00007b2719bd023c  call 0x00007B2719AE1430
00007b2719bd0241  jmp 0x00007B2719BCFFD8
00007b2719bd0246  call 0x00007B2719AE26A0
00007b2719bd024b  jmp 0x00007B2719BCFFF9
00007b2719bd0250  call 0x00007B2719AD5890
00007b2719bd0255  jmp 0x00007B2719BD0002
00007b2719bd025a  call 0x00007B2719ABDD50
00007b2719bd025f  jmp 0x00007B2719BD0098
00007b2719bd0264  call 0x00007B2719ADA580
00007b2719bd0269  jmp 0x00007B2719BD00CF
00007b2719bd026e  int3
00007b2719bd026f  nop
00007b2719bd0270  mov eax, [r15+0xB8]
00007b2719bd0277  mov [rsp+0x10], eax
00007b2719bd027b  mov eax, eax
00007b2719bd027d  mov [r15+0x30], rax
00007b2719bd0281  mov eax, [r15+0xC0]
00007b2719bd0288  mov [rsp+0x20], eax
00007b2719bd028c  mov eax, eax
00007b2719bd028e  mov [r15+0xA0], rax
00007b2719bd0295  mov eax, [r15+0x28]
00007b2719bd0299  mov r14d, [r15+0x98]
00007b2719bd02a0  mov [rsp+0x30], r14d
00007b2719bd02a5  mov r14d, r14d
00007b2719bd02a8  mov [r15+0x28], r14
00007b2719bd02ac  mov r14d, [r15+0x38]
00007b2719bd02b0  mov [rsp+0x40], r14d
00007b2719bd02b5  mov r14d, r14d
00007b2719bd02b8  mov [r15+0x98], r14
00007b2719bd02bf  mov r14d, [r15+0xA8]
00007b2719bd02c6  mov [rsp+0x50], r14d
00007b2719bd02cb  mov r14d, r14d
00007b2719bd02ce  mov [r15+0x38], r14
00007b2719bd02d2  mov r14d, [rsp+0x10]
00007b2719bd02d7  mov r12d, [rsp+0x10]
00007b2719bd02dc  shrd r14d, r12d, 0x06
00007b2719bd02e1  mov r11d, [r15+0xC8]
00007b2719bd02e8  mov [rsp+0x10], r12d
00007b2719bd02ed  and r12d, r11d
00007b2719bd02f0  mov r10d, [rsp+0x50]
00007b2719bd02f5  mov r9d, [rsp+0x50]
00007b2719bd02fa  shrd r10d, r9d, 0x02
00007b2719bd02ff  mov [rsp+0x50], r11d
00007b2719bd0304  mov r11d, r11d
00007b2719bd0307  mov [r15+0x20], r11
00007b2719bd030b  mov r11, [r15+0x88]
00007b2719bd0312  mov r8, [r15+0x50]
00007b2719bd0316  lea rbp, [r8+r11*1]
00007b2719bd031a  mov r8d, [r13+rbp*1]
00007b2719bd031f  mov ebp, [rsp+0x20]
00007b2719bd0323  mov edi, [rsp+0x10]
00007b2719bd0327  andn esi, edi, ebp
00007b2719bd032c  mov edx, [r15+0xB0]
00007b2719bd0333  lea ecx, [r12d+edx*1]
00007b2719bd0338  rorx r12d, edi, 0x0B
00007b2719bd033e  xor r14d, r12d
00007b2719bd0341  rorx r12d, r9d, 0x0D
00007b2719bd0347  xor r10d, r12d
00007b2719bd034a  lea r12d, [ecx+esi*1]
00007b2719bd034f  mov rsi, [r15+0x48]
00007b2719bd0353  lea rdx, [rsi+r11*1]
00007b2719bd0357  mov esi, [r13+rdx*1]
00007b2719bd035c  mov edx, [rsp+0x30]
00007b2719bd0360  mov ecx, [rsp+0x40]
00007b2719bd0364  and edx, ecx
00007b2719bd0366  mov [rsp+0x10], edx
00007b2719bd036a  mov edx, edx
00007b2719bd036c  mov [r15+0xD8], rdx
00007b2719bd0373  lea edx, [r12d+r8d*1]
00007b2719bd0378  mov r12d, [rsp+0x30]
00007b2719bd037d  xor r12d, ecx
00007b2719bd0380  rorx r8d, edi, 0x19
00007b2719bd0386  xor r14d, r8d
00007b2719bd0389  and r12d, r9d
00007b2719bd038c  rorx r8d, r9d, 0x16
00007b2719bd0392  xor r10d, r8d
00007b2719bd0395  mov [rsp+0x20], r10d
00007b2719bd039a  mov r10d, r10d
00007b2719bd039d  mov [r15+0xD0], r10
00007b2719bd03a4  lea r10d, [edx+esi*1]
00007b2719bd03a9  mov r9d, [rsp+0x10]
00007b2719bd03ae  xor r12d, r9d
00007b2719bd03b1  lea r9d, [r10d+r14d*1]
00007b2719bd03b6  lea r14, [r11+0x04]
00007b2719bd03ba  mov [r15+0x88], r14
00007b2719bd03c1  mov r11d, [rsp+0x20]
00007b2719bd03c6  lea r10d, [r12d+r11d*1]
00007b2719bd03cb  lea r11d, [r9d+eax*1]
00007b2719bd03d0  mov r11d, r11d
00007b2719bd03d3  mov [r15+0xB8], r11
00007b2719bd03da  xor eax, eax
00007b2719bd03dc  mov r12d, 0x100
00007b2719bd03e2  cmp r14, r12
00007b2719bd03e5  cmc
00007b2719bd03e6  lahf
00007b2719bd03e7  seto al
00007b2719bd03ea  mov [r15+0x108], eax
00007b2719bd03f1  lea eax, [r10d+r9d*1]
00007b2719bd03f6  mov eax, eax
00007b2719bd03f8  mov [r15+0xA8], rax
00007b2719bd03ff  mov ebp, ebp
00007b2719bd0401  mov [r15+0xB0], rbp
00007b2719bd0408  mov eax, [rsp+0x50]
00007b2719bd040c  mov eax, eax
00007b2719bd040e  mov [r15+0xC0], rax
00007b2719bd0415  mov edi, edi
00007b2719bd0417  mov [r15+0xC8], rdi
00007b2719bd041e  mov eax, [r15+0x108]
00007b2719bd0425  sahf
00007b2719bd0426  jnz 0x00007B2719BD0458
00007b2719bd0428  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0430  jz 0x00007B2719BD04A0
00007b2719bd0436  nop [rax+rax*1], ax
00007b2719bd043f  nop [rax+rax*1], eax
00007b2719bd0447  mov eax, 0x4108E0
00007b2719bd044c  mov [r15+0x100], rax
00007b2719bd0453  jmp 0x00007B27199FE110
00007b2719bd0458  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0460  jz 0x00007B2719BD0270
00007b2719bd0466  nop [rax+rax*1], ax
00007b2719bd046f  nop [rax+rax*1], eax
00007b2719bd0477  mov eax, 0x410854
00007b2719bd047c  mov [r15+0x100], rax
00007b2719bd0483  jmp 0x00007B27199FE110
00007b2719bd0488  int3
00007b2719bd0489  call 0x00007B2719A49010
00007b2719bd048e  jmp 0x00007B2719BD031F
00007b2719bd0493  call 0x00007B2719A25930
00007b2719bd0498  jmp 0x00007B2719BD035C
00007b2719bd049d  int3
00007b2719bd049e  nop
00007b2719bd04a0  mov eax, [r15+0x98]
00007b2719bd04a7  mov r14d, [r15+0x70]
00007b2719bd04ab  lea r12d, [eax+r14d*1]
00007b2719bd04b0  mov eax, [r15+0x28]
00007b2719bd04b4  mov r14d, [r15+0x68]
00007b2719bd04b8  lea r11d, [eax+r14d*1]
00007b2719bd04bd  mov qword ptr [r15+0x88], 0x00
00007b2719bd04c8  mov eax, [r15+0xA8]
00007b2719bd04cf  mov r14d, [r15+0x78]
00007b2719bd04d3  lea r10d, [eax+r14d*1]
00007b2719bd04d8  mov [rsp+0x10], r10d
00007b2719bd04dd  mov r10d, r10d
00007b2719bd04e0  mov [r15+0x78], r10
00007b2719bd04e4  mov eax, [r15+0x38]
00007b2719bd04e8  mov r14d, [r15+0x80]
00007b2719bd04ef  lea r10d, [eax+r14d*1]
00007b2719bd04f4  mov [rsp+0x20], r10d
00007b2719bd04f9  mov r10d, r10d
00007b2719bd04fc  mov [r15+0x80], r10
00007b2719bd0503  mov rax, [r15]
00007b2719bd0506  lea r14, [rax+0x08]
00007b2719bd050a  mov [r13+r14*1], r12d
00007b2719bd050f  lea r14, [rax+0x0C]
00007b2719bd0513  mov [r13+r14*1], r11d
00007b2719bd0518  mov r14d, [r15+0xB8]
00007b2719bd051f  mov r12d, [r15+0x18]
00007b2719bd0523  lea r11d, [r14d+r12d*1]
00007b2719bd0528  mov [rsp+0x30], r11d
00007b2719bd052d  mov r11d, r11d
00007b2719bd0530  mov [r15+0x68], r11
00007b2719bd0534  mov r14d, [r15+0x30]
00007b2719bd0538  mov r12d, [r15+0x90]
00007b2719bd053f  lea r11d, [r14d+r12d*1]
00007b2719bd0544  mov [rsp+0x40], r11d
00007b2719bd0549  mov r11d, r11d
00007b2719bd054c  mov [r15+0x70], r11
00007b2719bd0550  mov r14d, [r15+0x20]
00007b2719bd0554  mov r12d, [r15+0x58]
00007b2719bd0558  lea r11d, [r14d+r12d*1]
00007b2719bd055d  mov [rsp+0x50], r11d
00007b2719bd0562  mov r11d, r11d
00007b2719bd0565  mov [r15+0x58], r11
00007b2719bd0569  mov r14d, [r15+0xA0]
00007b2719bd0570  mov r12d, [r15+0x60]
00007b2719bd0574  lea r11d, [r14d+r12d*1]
00007b2719bd0579  mov [rsp+0x60], r11d
00007b2719bd057e  mov r11d, r11d
00007b2719bd0581  mov [r15+0x60], r11
00007b2719bd0585  mov r14d, [rsp+0x10]
00007b2719bd058a  mov [r13+rax*1], r14d
00007b2719bd058f  lea r14, [rax+0x04]
00007b2719bd0593  mov r12d, [rsp+0x20]
00007b2719bd0598  mov [r13+r14*1], r12d
00007b2719bd059d  lea r14, [rax+0x10]
00007b2719bd05a1  mov r12d, [rsp+0x30]
00007b2719bd05a6  mov [r13+r14*1], r12d
00007b2719bd05ab  lea r14, [rax+0x14]
00007b2719bd05af  mov r12d, [rsp+0x40]
00007b2719bd05b4  mov [r13+r14*1], r12d
00007b2719bd05b9  lea r14, [rax+0x18]
00007b2719bd05bd  mov r12d, [rsp+0x50]
00007b2719bd05c2  mov [r13+r14*1], r12d
00007b2719bd05c7  lea r14, [rax+0x1C]
00007b2719bd05cb  mov r12d, [rsp+0x60]
00007b2719bd05d0  mov [r13+r14*1], r12d
00007b2719bd05d5  lea r14, [rax+0x68]
00007b2719bd05d9  xor eax, eax
00007b2719bd05db  mov [r13+r14*1], rax
00007b2719bd05e0  cmp dword ptr [r15+0x318], 0x00
00007b2719bd05e8  jz 0x00007B2719BCF0E0
00007b2719bd05ee  nop [rax+rax*1], ax
00007b2719bd05f7  nop [rax+rax*1], eax
00007b2719bd05ff  mov eax, 0x4106FC
00007b2719bd0604  mov [r15+0x100], rax
00007b2719bd060b  jmp 0x00007B27199FE110
00007b2719bd0610  int3
00007b2719bd0611  call 0x00007B2719AE2BA0
00007b2719bd0616  jmp 0x00007B2719BD050F
00007b2719bd061b  call 0x00007B2719AE1920
00007b2719bd0620  jmp 0x00007B2719BD0518
00007b2719bd0625  call 0x00007B2719A0DFE0
00007b2719bd062a  jmp 0x00007B2719BD058F
00007b2719bd062f  call 0x00007B2719AE2BA0
00007b2719bd0634  jmp 0x00007B2719BD059D
00007b2719bd0639  call 0x00007B2719AE2BA0
00007b2719bd063e  jmp 0x00007B2719BD05AB
00007b2719bd0643  call 0x00007B2719AE2BA0
00007b2719bd0648  jmp 0x00007B2719BD05B9
00007b2719bd064d  call 0x00007B2719AE2BA0
00007b2719bd0652  jmp 0x00007B2719BD05C7
00007b2719bd0657  call 0x00007B2719AE2BA0
00007b2719bd065c  jmp 0x00007B2719BD05D5
00007b2719bd0661  call 0x00007B2719AD5EB0
00007b2719bd0666  jmp 0x00007B2719BD05E0
00007b2719bd066b  int3
00007b2719bd066c  nop [rax], eax
00007b2719bd0670  mov rax, [r15+0xF8]
00007b2719bd0677  lea r14, [rax+0x140]
00007b2719bd067e  mov r12, [r13+r14*1]
00007b2719bd0683  lea r14, [rax+0x148]
00007b2719bd068a  mov r11, [r13+r14*1]
00007b2719bd068f  mov [r15+0xA0], r12
00007b2719bd0696  mov [r15+0x98], r11
00007b2719bd069d  lea r14, [rax+0x130]
00007b2719bd06a4  mov r12, [r13+r14*1]
00007b2719bd06a9  lea r14, [rax+0x138]
00007b2719bd06b0  mov r11, [r13+r14*1]
00007b2719bd06b5  mov [r15+0xB0], r12
00007b2719bd06bc  mov [r15+0xA8], r11
00007b2719bd06c3  lea r14, [rax+0x120]
00007b2719bd06ca  mov r12, [r13+r14*1]
00007b2719bd06cf  lea r14, [rax+0x128]
00007b2719bd06d6  mov r11, [r13+r14*1]
00007b2719bd06db  mov [r15+0xC0], r12
00007b2719bd06e2  mov [r15+0xB8], r11
00007b2719bd06e9  lea r14, [rax+0x110]
00007b2719bd06f0  mov r12, [r13+r14*1]
00007b2719bd06f5  lea r14, [rax+0x118]
00007b2719bd06fc  mov r11, [r13+r14*1]
00007b2719bd0701  mov [r15+0xD0], r12
00007b2719bd0708  mov [r15+0xC8], r11
00007b2719bd070f  lea r14, [rax+0x100]
00007b2719bd0716  mov r12, [r13+r14*1]
00007b2719bd071b  lea r14, [rax+0x108]
00007b2719bd0722  mov r11, [r13+r14*1]
00007b2719bd0727  mov [r15+0xE8], r12
00007b2719bd072e  mov [r15+0xD8], r11
00007b2719bd0735  lea r14, [rax+0x150]
00007b2719bd073c  mov [r15+0xF8], r14
00007b2719bd0743  mov rax, [r15+0xF0]
00007b2719bd074a  mov [r15+0x100], rax
00007b2719bd0751  jmp 0x00007B2719BCE5C0
00007b2719bd0756  int3
00007b2719bd0757  call 0x00007B2719AE27E0
00007b2719bd075c  jmp 0x00007B2719BD0683
00007b2719bd0761  call 0x00007B2719AE1570
00007b2719bd0766  jmp 0x00007B2719BD068F
00007b2719bd076b  call 0x00007B2719AE27E0
00007b2719bd0770  jmp 0x00007B2719BD06A9
00007b2719bd0775  call 0x00007B2719AE1570
00007b2719bd077a  jmp 0x00007B2719BD06B5
00007b2719bd077f  call 0x00007B2719AE27E0
00007b2719bd0784  jmp 0x00007B2719BD06CF
00007b2719bd0789  call 0x00007B2719AE1570
00007b2719bd078e  jmp 0x00007B2719BD06DB
00007b2719bd0793  call 0x00007B2719AE27E0
00007b2719bd0798  jmp 0x00007B2719BD06F5
00007b2719bd079d  call 0x00007B2719AE1570
00007b2719bd07a2  jmp 0x00007B2719BD0701
00007b2719bd07a7  call 0x00007B2719AE27E0
00007b2719bd07ac  jmp 0x00007B2719BD071B
00007b2719bd07b1  call 0x00007B2719AE1570
00007b2719bd07b6  jmp 0x00007B2719BD0727
00007b2719bd07bb  int3
00007b2719bd07bc  nop [rax], eax
00007b2719bd07c0  mov eax, [r15+0xA0]
00007b2719bd07c7  mov [rsp+0x10], eax
00007b2719bd07cb  xor eax, eax
00007b2719bd07cd  mov r14d, [rsp+0x10]
00007b2719bd07d2  sub r14d, 0x01
00007b2719bd07d6  cmc
00007b2719bd07d7  lahf
00007b2719bd07d8  seto al
00007b2719bd07db  mov [r15+0x108], eax
00007b2719bd07e2  mov r14d, r14d
00007b2719bd07e5  mov [r15+0xA0], r14
00007b2719bd07ec  mov eax, [r15+0x108]
00007b2719bd07f3  sahf
00007b2719bd07f4  jnz 0x00007B2719BD0826
00007b2719bd07f6  cmp dword ptr [r15+0x318], 0x00
00007b2719bd07fe  jz 0x00007B2719BD0900
00007b2719bd0804  nop [rax+rax*1], ax
00007b2719bd080d  nop [rax+rax*1], eax
00007b2719bd0815  mov eax, 0x41028C
00007b2719bd081a  mov [r15+0x100], rax
00007b2719bd0821  jmp 0x00007B27199FE110
00007b2719bd0826  cmp dword ptr [r15+0x318], 0x00
00007b2719bd082e  jz 0x00007B2719BD0860
00007b2719bd0834  nop [rax+rax*1], ax
00007b2719bd083d  nop [rax+rax*1], eax
00007b2719bd0845  mov eax, 0x410274
00007b2719bd084a  mov [r15+0x100], rax
00007b2719bd0851  jmp 0x00007B27199FE110
00007b2719bd0856  int3
00007b2719bd0857  int3
00007b2719bd0858  nop [rax+rax*1], eax
00007b2719bd0860  mov rax, [r15+0xF8]
00007b2719bd0867  lea r14, [rax+0xD0]
00007b2719bd086e  mov [r15], r14
00007b2719bd0871  mov rax, [r15+0x98]
00007b2719bd0878  mov [r15+0x08], rax
00007b2719bd087c  mov qword ptr [r15+0x10], 0x12C
00007b2719bd0884  mov qword ptr [r15+0xF0], 0x410284
00007b2719bd088f  mov r14d, [r15+0x320]
00007b2719bd0896  mov eax, 0x410284
00007b2719bd089b  mov rcx, 0x7B2719BD07C0
00007b2719bd08a5  mov [r15+r14*8+0x328], rax
00007b2719bd08ad  mov [r15+r14*8+0x368], rcx
00007b2719bd08b5  add r14d, 0x01
00007b2719bd08b9  and r14d, 0x07
00007b2719bd08bd  mov [r15+0x320], r14d
00007b2719bd08c4  cmp dword ptr [r15+0x318], 0x00
00007b2719bd08cc  jz 0x00007B2719BCED70
00007b2719bd08d2  nop [rax+rax*1], ax
00007b2719bd08db  nop [rax+rax*1], eax
00007b2719bd08e3  mov eax, 0x4106BC
00007b2719bd08e8  mov [r15+0x100], rax
00007b2719bd08ef  jmp 0x00007B27199FE110
00007b2719bd08f4  int3
00007b2719bd08f5  int3
00007b2719bd08f6  nop [rax+rax*1], ax
00007b2719bd08ff  nop
00007b2719bd0900  mov rax, [r15+0xF8]
00007b2719bd0907  lea r14, [rax+0xF0]
00007b2719bd090e  mov r12, [r13+r14*1]
00007b2719bd0913  mov [r15+0x98], r12
00007b2719bd091a  mov qword ptr [r15+0x40], 0x80
00007b2719bd0922  lea r14, [rax+0xD0]
00007b2719bd0929  mov [r15], r14
00007b2719bd092c  lea r14, [rax+0x14C]
00007b2719bd0933  mov [r15+0x08], r14
00007b2719bd0937  mov qword ptr [r15+0x10], 0x01
00007b2719bd093f  lea r14, [rax+0x14C]
00007b2719bd0946  mov eax, 0x80
00007b2719bd094b  mov [r13+r14*1], al
00007b2719bd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007b2719bd095b  mov r14d, [r15+0x320]
00007b2719bd0962  mov eax, 0x4102A8
00007b2719bd0967  mov rcx, 0x7B2719BD09E0
00007b2719bd0971  mov [r15+r14*8+0x328], rax
00007b2719bd0979  mov [r15+r14*8+0x368], rcx
00007b2719bd0981  add r14d, 0x01
00007b2719bd0985  and r14d, 0x07
00007b2719bd0989  mov [r15+0x320], r14d
00007b2719bd0990  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0998  jz 0x00007B2719BCED70
00007b2719bd099e  nop [rax+rax*1], ax
00007b2719bd09a7  nop [rax+rax*1], eax
00007b2719bd09af  mov eax, 0x4106BC
00007b2719bd09b4  mov [r15+0x100], rax
00007b2719bd09bb  jmp 0x00007B27199FE110
00007b2719bd09c0  int3
00007b2719bd09c1  call 0x00007B2719AE27E0
00007b2719bd09c6  jmp 0x00007B2719BD0913
00007b2719bd09cb  call 0x00007B2719AD5AF0
00007b2719bd09d0  jmp 0x00007B2719BD0950
00007b2719bd09d5  int3
00007b2719bd09d6  nop [rax+rax*1], ax
00007b2719bd09df  nop
00007b2719bd09e0  mov rax, [r15+0xF8]
00007b2719bd09e7  lea r14, [rax+0x138]
00007b2719bd09ee  mov r12, [r13+r14*1]
00007b2719bd09f3  mov [r15+0x40], r12
00007b2719bd09f7  lea r14, [rax+0x148]
00007b2719bd09fe  xor eax, eax
00007b2719bd0a00  mov [r13+r14*1], al
00007b2719bd0a05  xor eax, eax
00007b2719bd0a07  mov r14d, 0x38
00007b2719bd0a0d  cmp r12, r14
00007b2719bd0a10  cmc
00007b2719bd0a11  lahf
00007b2719bd0a12  seto al
00007b2719bd0a15  mov [r15+0x108], eax
00007b2719bd0a1c  mov eax, [r15+0x108]
00007b2719bd0a23  sahf
00007b2719bd0a24  jz 0x00007B2719BD0A56
00007b2719bd0a26  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0a2e  jz 0x00007B2719BD0AA0
00007b2719bd0a34  nop [rax+rax*1], ax
00007b2719bd0a3d  nop [rax+rax*1], eax
00007b2719bd0a45  mov eax, 0x4102B8
00007b2719bd0a4a  mov [r15+0x100], rax
00007b2719bd0a51  jmp 0x00007B27199FE110
00007b2719bd0a56  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0a5e  jz 0x00007B2719BD0BF0
00007b2719bd0a64  nop [rax+rax*1], ax
00007b2719bd0a6d  nop [rax+rax*1], eax
00007b2719bd0a75  mov eax, 0x4102D4
00007b2719bd0a7a  mov [r15+0x100], rax
00007b2719bd0a81  jmp 0x00007B27199FE110
00007b2719bd0a86  int3
00007b2719bd0a87  call 0x00007B2719AE27E0
00007b2719bd0a8c  jmp 0x00007B2719BD09F3
00007b2719bd0a91  call 0x00007B2719AD5AF0
00007b2719bd0a96  jmp 0x00007B2719BD0A05
00007b2719bd0a9b  int3
00007b2719bd0a9c  nop [rax], eax
00007b2719bd0aa0  mov rax, [r15+0xF8]
00007b2719bd0aa7  lea r14, [rax+0xD0]
00007b2719bd0aae  mov [r15], r14
00007b2719bd0ab1  lea r14, [rax+0x148]
00007b2719bd0ab8  mov [r15+0x08], r14
00007b2719bd0abc  mov qword ptr [r15+0x10], 0x01
00007b2719bd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007b2719bd0acf  mov r14d, [r15+0x320]
00007b2719bd0ad6  mov eax, 0x4102C8
00007b2719bd0adb  mov rcx, 0x7B2719BD0B40
00007b2719bd0ae5  mov [r15+r14*8+0x328], rax
00007b2719bd0aed  mov [r15+r14*8+0x368], rcx
00007b2719bd0af5  add r14d, 0x01
00007b2719bd0af9  and r14d, 0x07
00007b2719bd0afd  mov [r15+0x320], r14d
00007b2719bd0b04  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0b0c  jz 0x00007B2719BCED70
00007b2719bd0b12  nop [rax+rax*1], ax
00007b2719bd0b1b  nop [rax+rax*1], eax
00007b2719bd0b23  mov eax, 0x4106BC
00007b2719bd0b28  mov [r15+0x100], rax
00007b2719bd0b2f  jmp 0x00007B27199FE110
00007b2719bd0b34  int3
00007b2719bd0b35  int3
00007b2719bd0b36  nop [rax+rax*1], ax
00007b2719bd0b3f  nop
00007b2719bd0b40  mov rax, [r15+0xF8]
00007b2719bd0b47  lea r14, [rax+0x138]
00007b2719bd0b4e  mov rax, [r13+r14*1]
00007b2719bd0b53  mov [r15+0x40], rax
00007b2719bd0b57  mov [rsp+0x10], rax
00007b2719bd0b5c  xor eax, eax
00007b2719bd0b5e  mov r14, [rsp+0x10]
00007b2719bd0b63  mov r12d, 0x38
00007b2719bd0b69  cmp r14, r12
00007b2719bd0b6c  cmc
00007b2719bd0b6d  lahf
00007b2719bd0b6e  seto al
00007b2719bd0b71  mov [r15+0x108], eax
00007b2719bd0b78  mov eax, [r15+0x108]
00007b2719bd0b7f  sahf
00007b2719bd0b80  jnz 0x00007B2719BD0BB2
00007b2719bd0b82  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0b8a  jz 0x00007B2719BD0BF0
00007b2719bd0b90  nop [rax+rax*1], ax
00007b2719bd0b99  nop [rax+rax*1], eax
00007b2719bd0ba1  mov eax, 0x4102D4
00007b2719bd0ba6  mov [r15+0x100], rax
00007b2719bd0bad  jmp 0x00007B27199FE110
00007b2719bd0bb2  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0bba  jz 0x00007B2719BD0AA0
00007b2719bd0bc0  nop [rax+rax*1], ax
00007b2719bd0bc9  nop [rax+rax*1], eax
00007b2719bd0bd1  mov eax, 0x4102B8
00007b2719bd0bd6  mov [r15+0x100], rax
00007b2719bd0bdd  jmp 0x00007B27199FE110
00007b2719bd0be2  int3
00007b2719bd0be3  call 0x00007B2719AD59C0
00007b2719bd0be8  jmp 0x00007B2719BD0B53
00007b2719bd0bed  int3
00007b2719bd0bee  nop
00007b2719bd0bf0  mov rax, [r15+0x98]
00007b2719bd0bf7  rorx r14, rax, 0x3D
00007b2719bd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007b2719bd0c01  mov rax, [r15+0xF8]
00007b2719bd0c08  lea r12, [rax+0xD0]
00007b2719bd0c0f  mov [r15], r12
00007b2719bd0c12  lea r12, [rax+0x140]
00007b2719bd0c19  mov [r15+0x08], r12
00007b2719bd0c1d  mov qword ptr [r15+0x10], 0x08
00007b2719bd0c25  bswap r14
00007b2719bd0c28  mov [r15+0x40], r14
00007b2719bd0c2c  lea r12, [rax+0x140]
00007b2719bd0c33  mov [r13+r12*1], r14
00007b2719bd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007b2719bd0c43  mov r14d, [r15+0x320]
00007b2719bd0c4a  mov eax, 0x4102F0
00007b2719bd0c4f  mov rcx, 0x7B2719BD0CC0
00007b2719bd0c59  mov [r15+r14*8+0x328], rax
00007b2719bd0c61  mov [r15+r14*8+0x368], rcx
00007b2719bd0c69  add r14d, 0x01
00007b2719bd0c6d  and r14d, 0x07
00007b2719bd0c71  mov [r15+0x320], r14d
00007b2719bd0c78  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0c80  jz 0x00007B2719BCED70
00007b2719bd0c86  nop [rax+rax*1], ax
00007b2719bd0c8f  nop [rax+rax*1], eax
00007b2719bd0c97  mov eax, 0x4106BC
00007b2719bd0c9c  mov [r15+0x100], rax
00007b2719bd0ca3  jmp 0x00007B27199FE110
00007b2719bd0ca8  int3
00007b2719bd0ca9  call 0x00007B2719AC3FE0
00007b2719bd0cae  jmp 0x00007B2719BD0C38
00007b2719bd0cb3  int3
00007b2719bd0cb4  nop [rax+rax*1], ax
00007b2719bd0cbd  nop [rax], eax
00007b2719bd0cc0  mov rax, [r15+0xF8]
00007b2719bd0cc7  lea r14, [rax+0xD0]
00007b2719bd0cce  mov r12d, [r13+r14*1]
00007b2719bd0cd3  lea r14, [rax+0xD4]
00007b2719bd0cda  mov r11d, [r13+r14*1]
00007b2719bd0cdf  lea r14, [rax+0xD8]
00007b2719bd0ce6  mov r10d, [r13+r14*1]
00007b2719bd0ceb  lea r14, [rax+0xDC]
00007b2719bd0cf2  mov r9d, [r13+r14*1]
00007b2719bd0cf7  mov qword ptr [r15+0x48], 0x430C20
00007b2719bd0cff  mov qword ptr [r15+0xA0], 0x00
00007b2719bd0d0a  bswap r12d
00007b2719bd0d0d  bswap r11d
00007b2719bd0d10  mov qword ptr [r15+0x98], 0x430D8C
00007b2719bd0d1b  mov r14d, 0x430C20
00007b2719bd0d21  mov [r13+r14*1], r12d
00007b2719bd0d26  mov r14d, 0x430C24
00007b2719bd0d2c  mov [r13+r14*1], r11d
00007b2719bd0d31  bswap r10d
00007b2719bd0d34  bswap r9d
00007b2719bd0d37  lea r14, [rax+0xE0]
00007b2719bd0d3e  mov r12d, [r13+r14*1]
00007b2719bd0d43  lea r14, [rax+0xE4]
00007b2719bd0d4a  mov r11d, [r13+r14*1]
00007b2719bd0d4f  mov r14d, 0x430C28
00007b2719bd0d55  mov [r13+r14*1], r10d
00007b2719bd0d5a  mov r14d, 0x430C2C
00007b2719bd0d60  mov [r13+r14*1], r9d
00007b2719bd0d65  bswap r12d
00007b2719bd0d68  bswap r11d
00007b2719bd0d6b  mov [rsp+0x10], r11d
00007b2719bd0d70  mov r11d, r11d
00007b2719bd0d73  mov [r15+0x58], r11
00007b2719bd0d77  lea r14, [rax+0xE8]
00007b2719bd0d7e  mov r11d, [r13+r14*1]
00007b2719bd0d83  lea r14, [rax+0xEC]
00007b2719bd0d8a  mov eax, [r13+r14*1]
00007b2719bd0d8f  mov [rsp+0x20], eax
00007b2719bd0d93  mov eax, eax
00007b2719bd0d95  mov [r15+0x60], rax
00007b2719bd0d99  mov eax, 0x430C30
00007b2719bd0d9e  mov [r13+rax*1], r12d
00007b2719bd0da3  mov eax, 0x430C34
00007b2719bd0da8  mov r14d, [rsp+0x10]
00007b2719bd0dad  mov [r13+rax*1], r14d
00007b2719bd0db2  bswap r11d
00007b2719bd0db5  mov [rsp+0x10], r11d
00007b2719bd0dba  mov r11d, r11d
00007b2719bd0dbd  mov [r15+0x40], r11
00007b2719bd0dc1  mov eax, [rsp+0x20]
00007b2719bd0dc5  bswap eax
00007b2719bd0dc7  mov [rsp+0x20], eax
00007b2719bd0dcb  mov eax, eax
00007b2719bd0dcd  mov [r15+0x50], rax
00007b2719bd0dd1  mov eax, 0x430C38
00007b2719bd0dd6  mov r14d, [rsp+0x10]
00007b2719bd0ddb  mov [r13+rax*1], r14d
00007b2719bd0de0  mov eax, 0x430C3C
00007b2719bd0de5  mov r14d, [rsp+0x20]
00007b2719bd0dea  mov [r13+rax*1], r14d
00007b2719bd0def  mov eax, [r15+0xA0]
00007b2719bd0df6  lea r14d, [eax+0x11]
00007b2719bd0dfb  mov r14d, r14d
00007b2719bd0dfe  mov [r15], r14
00007b2719bd0e01  mov qword ptr [r15+0xF0], 0x41034C
00007b2719bd0e0c  mov r14d, [r15+0x320]
00007b2719bd0e13  mov eax, 0x41034C
00007b2719bd0e18  mov rcx, 0x7B2719BD0F90
00007b2719bd0e22  mov [r15+r14*8+0x328], rax
00007b2719bd0e2a  mov [r15+r14*8+0x368], rcx
00007b2719bd0e32  add r14d, 0x01
00007b2719bd0e36  and r14d, 0x07
00007b2719bd0e3a  mov [r15+0x320], r14d
00007b2719bd0e41  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0e49  jz 0x00007B2719BD0F20
00007b2719bd0e4f  nop [rax+rax*1], ax
00007b2719bd0e58  nop [rax+rax*1], eax
00007b2719bd0e60  mov eax, 0x410938
00007b2719bd0e65  mov [r15+0x100], rax
00007b2719bd0e6c  jmp 0x00007B27199FE110
00007b2719bd0e71  int3
00007b2719bd0e72  call 0x00007B2719AE26A0
00007b2719bd0e77  jmp 0x00007B2719BD0CD3
00007b2719bd0e7c  call 0x00007B2719AE1430
00007b2719bd0e81  jmp 0x00007B2719BD0CDF
00007b2719bd0e86  call 0x00007B2719AE01C0
00007b2719bd0e8b  jmp 0x00007B2719BD0CEB
00007b2719bd0e90  call 0x00007B2719ADEF50
00007b2719bd0e95  jmp 0x00007B2719BD0CF7
00007b2719bd0e9a  call 0x00007B2719AE2BA0
00007b2719bd0e9f  jmp 0x00007B2719BD0D26
00007b2719bd0ea4  call 0x00007B2719AE1920
00007b2719bd0ea9  jmp 0x00007B2719BD0D31
00007b2719bd0eae  call 0x00007B2719AE26A0
00007b2719bd0eb3  jmp 0x00007B2719BD0D43
00007b2719bd0eb8  call 0x00007B2719AE1430
00007b2719bd0ebd  jmp 0x00007B2719BD0D4F
00007b2719bd0ec2  call 0x00007B2719AE06B0
00007b2719bd0ec7  jmp 0x00007B2719BD0D5A
00007b2719bd0ecc  call 0x00007B2719ADF440
00007b2719bd0ed1  jmp 0x00007B2719BD0D65
00007b2719bd0ed6  call 0x00007B2719AE1430
00007b2719bd0edb  jmp 0x00007B2719BD0D83
00007b2719bd0ee0  call 0x00007B2719AD5890
00007b2719bd0ee5  jmp 0x00007B2719BD0D8F
00007b2719bd0eea  call 0x00007B2719A0BAE0
00007b2719bd0eef  jmp 0x00007B2719BD0DA3
00007b2719bd0ef4  call 0x00007B2719A0DFE0
00007b2719bd0ef9  jmp 0x00007B2719BD0DB2
00007b2719bd0efe  call 0x00007B2719A0DFE0
00007b2719bd0f03  jmp 0x00007B2719BD0DE0
00007b2719bd0f08  call 0x00007B2719A0DFE0
00007b2719bd0f0d  jmp 0x00007B2719BD0DEF
00007b2719bd0f12  int3
00007b2719bd0f13  nop [rax+rax*1], ax
00007b2719bd0f1c  nop [rax], eax
00007b2719bd0f20  mov eax, [r15]
00007b2719bd0f23  mov [rsp+0x10], eax
00007b2719bd0f27  shr eax, 0x10
00007b2719bd0f2a  mov r14d, [rsp+0x10]
00007b2719bd0f2f  xor r14d, eax
00007b2719bd0f32  imul r14d, r14d, 0x7FEB352D
00007b2719bd0f39  mov eax, 0x846CA68B
00007b2719bd0f3e  mov eax, eax
00007b2719bd0f40  mov [r15+0x48], rax
00007b2719bd0f44  mov [rsp+0x10], r14d
00007b2719bd0f49  shr r14d, 0x0F
00007b2719bd0f4d  mov eax, [rsp+0x10]
00007b2719bd0f51  xor eax, r14d
00007b2719bd0f54  imul eax, eax, 0x846CA68B
00007b2719bd0f5a  mov [rsp+0x10], eax
00007b2719bd0f5e  mov eax, eax
00007b2719bd0f60  mov [r15+0x40], rax
00007b2719bd0f64  mov eax, [rsp+0x10]
00007b2719bd0f68  shr eax, 0x10
00007b2719bd0f6b  mov r14d, [rsp+0x10]
00007b2719bd0f70  xor r14d, eax
00007b2719bd0f73  mov r14d, r14d
00007b2719bd0f76  mov [r15], r14
00007b2719bd0f79  mov rax, [r15+0xF0]
00007b2719bd0f80  mov [r15+0x100], rax
00007b2719bd0f87  jmp 0x00007B2719BCE5C0
00007b2719bd0f8c  int3
00007b2719bd0f8d  int3
00007b2719bd0f8e  nop
00007b2719bd0f90  mov rax, [r15+0xA0]
00007b2719bd0f97  mov [rsp+0x10], rax
00007b2719bd0f9c  shl rax, 0x02
00007b2719bd0fa0  mov r14, [r15+0x98]
00007b2719bd0fa7  lea r12, [r14+rax*1]
00007b2719bd0fab  mov eax, [r15]
00007b2719bd0fae  mov [r13+r12*1], eax
00007b2719bd0fb3  mov rax, [rsp+0x10]
00007b2719bd0fb8  lea r14, [rax+0x01]
00007b2719bd0fbc  mov [r15+0xA0], r14
00007b2719bd0fc3  xor eax, eax
00007b2719bd0fc5  mov r12d, 0x400
00007b2719bd0fcb  cmp r14, r12
00007b2719bd0fce  cmc
00007b2719bd0fcf  lahf
00007b2719bd0fd0  seto al
00007b2719bd0fd3  mov [r15+0x108], eax
00007b2719bd0fda  mov eax, [r15+0x108]
00007b2719bd0fe1  sahf
00007b2719bd0fe2  jnz 0x00007B2719BD1014
00007b2719bd0fe4  cmp dword ptr [r15+0x318], 0x00
00007b2719bd0fec  jz 0x00007B2719BD10E0
00007b2719bd0ff2  nop [rax+rax*1], ax
00007b2719bd0ffb  nop [rax+rax*1], eax
00007b2719bd1003  mov eax, 0x41035C
00007b2719bd1008  mov [r15+0x100], rax
00007b2719bd100f  jmp 0x00007B27199FE110
00007b2719bd1014  cmp dword ptr [r15+0x318], 0x00
00007b2719bd101c  jz 0x00007B2719BD1050
00007b2719bd1022  nop [rax+rax*1], ax
00007b2719bd102b  nop [rax+rax*1], eax
00007b2719bd1033  mov eax, 0x410344
00007b2719bd1038  mov [r15+0x100], rax
00007b2719bd103f  jmp 0x00007B27199FE110
00007b2719bd1044  int3
00007b2719bd1045  call 0x00007B2719AB4B70
00007b2719bd104a  jmp 0x00007B2719BD0FB3
00007b2719bd104f  int3
00007b2719bd1050  mov eax, [r15+0xA0]
00007b2719bd1057  lea r14d, [eax+0x11]
00007b2719bd105c  mov r14d, r14d
00007b2719bd105f  mov [r15], r14
00007b2719bd1062  mov qword ptr [r15+0xF0], 0x41034C
00007b2719bd106d  mov r14d, [r15+0x320]
00007b2719bd1074  mov eax, 0x41034C
00007b2719bd1079  mov rcx, 0x7B2719BD0F90
00007b2719bd1083  mov [r15+r14*8+0x328], rax
00007b2719bd108b  mov [r15+r14*8+0x368], rcx
00007b2719bd1093  add r14d, 0x01
00007b2719bd1097  and r14d, 0x07
00007b2719bd109b  mov [r15+0x320], r14d
00007b2719bd10a2  cmp dword ptr [r15+0x318], 0x00
00007b2719bd10aa  jz 0x00007B2719BD0F20
00007b2719bd10b0  nop [rax+rax*1], ax
00007b2719bd10b9  nop [rax+rax*1], eax
00007b2719bd10c1  mov eax, 0x410938
00007b2719bd10c6  mov [r15+0x100], rax
00007b2719bd10cd  jmp 0x00007B27199FE110
00007b2719bd10d2  int3
00007b2719bd10d3  int3
00007b2719bd10d4  nop [rax+rax*1], ax
00007b2719bd10dd  nop [rax], eax
00007b2719bd10e0  mov qword ptr [r15+0x40], 0x01
00007b2719bd10e8  cmp dword ptr [r15+0x318], 0x00
00007b2719bd10f0  jz 0x00007B2719BD1120
00007b2719bd10f6  nop [rax+rax*1], ax
00007b2719bd10ff  nop [rax+rax*1], eax
00007b2719bd1107  mov eax, 0x410378
00007b2719bd110c  mov [r15+0x100], rax
00007b2719bd1113  jmp 0x00007B27199FE110
00007b2719bd1118  int3
00007b2719bd1119  int3
00007b2719bd111a  nop [rax+rax*1], ax
00007b2719bd1120  mov rax, [r15+0x40]
00007b2719bd1124  mov [rsp+0x10], rax
00007b2719bd1129  shl rax, 0x02
00007b2719bd112d  mov r14, [r15+0x98]
00007b2719bd1134  lea r12, [r14+rax*1]
00007b2719bd1138  mov eax, [r13+r12*1]
00007b2719bd113d  mov [rsp+0x20], eax
00007b2719bd1141  mov eax, eax
00007b2719bd1143  mov [r15+0x48], rax
00007b2719bd1147  mov rax, [rsp+0x10]
00007b2719bd114c  mov [r15+0x50], rax
00007b2719bd1150  mov eax, [r15+0x50]
00007b2719bd1154  lea r12d, [eax-0x01]
00007b2719bd1159  mov r12d, r12d
00007b2719bd115c  mov [r15+0x58], r12
00007b2719bd1160  mov rax, [r15+0x58]
00007b2719bd1164  mov r12d, eax
00007b2719bd1167  mov r12d, r12d
00007b2719bd116a  shl r12, 0x02
00007b2719bd116e  lea rax, [r14+r12*1]
00007b2719bd1172  mov r14d, [r13+rax*1]
00007b2719bd1177  mov [rsp+0x10], r14d
00007b2719bd117c  mov r14d, r14d
00007b2719bd117f  mov [r15+0x60], r14
00007b2719bd1183  xor eax, eax
00007b2719bd1185  mov r14d, [rsp+0x10]
00007b2719bd118a  mov r12d, [rsp+0x20]
00007b2719bd118f  cmp r14d, r12d
00007b2719bd1192  cmc
00007b2719bd1193  lahf
00007b2719bd1194  seto al
00007b2719bd1197  mov [r15+0x108], eax
00007b2719bd119e  mov eax, [r15+0x108]
00007b2719bd11a5  sahf
00007b2719bd11a6  cmc
00007b2719bd11a7  jbe 0x00007B2719BD11D9
00007b2719bd11a9  cmp dword ptr [r15+0x318], 0x00
00007b2719bd11b1  jz 0x00007B2719BD1220
00007b2719bd11b7  nop [rax+rax*1], ax
00007b2719bd11c0  nop [rax+rax*1], eax
00007b2719bd11c8  mov eax, 0x410390
00007b2719bd11cd  mov [r15+0x100], rax
00007b2719bd11d4  jmp 0x00007B27199FE110
00007b2719bd11d9  cmp dword ptr [r15+0x318], 0x00
00007b2719bd11e1  jz 0x00007B2719BD14C0
00007b2719bd11e7  nop [rax+rax*1], ax
00007b2719bd11f0  nop [rax+rax*1], eax
00007b2719bd11f8  mov eax, 0x410368
00007b2719bd11fd  mov [r15+0x100], rax
00007b2719bd1204  jmp 0x00007B27199FE110
00007b2719bd1209  int3
00007b2719bd120a  call 0x00007B2719AB4690
00007b2719bd120f  jmp 0x00007B2719BD113D
00007b2719bd1214  call 0x00007B2719A0DAE0
00007b2719bd1219  jmp 0x00007B2719BD1177
00007b2719bd121e  int3
00007b2719bd121f  nop
00007b2719bd1220  mov rax, [r15+0x50]
00007b2719bd1224  mov [rsp+0x10], rax
00007b2719bd1229  shl rax, 0x02
00007b2719bd122d  mov r14, [r15+0x98]
00007b2719bd1234  lea r12, [r14+rax*1]
00007b2719bd1238  mov eax, [r15+0x60]
00007b2719bd123c  mov [r13+r12*1], eax
00007b2719bd1241  mov rax, [rsp+0x10]
00007b2719bd1246  lea r14, [rax-0x01]
00007b2719bd124a  mov [r15+0x50], r14
00007b2719bd124e  mov rax, [r15+0x58]
00007b2719bd1252  test rax, rax
00007b2719bd1255  setz al
00007b2719bd1258  movzx rax, al
00007b2719bd125c  mov [rsp+0x414], al
00007b2719bd1263  cmp byte ptr [rsp+0x414], 0x00
00007b2719bd126b  jz 0x00007B2719BD129D
00007b2719bd126d  cmp dword ptr [r15+0x318], 0x00
00007b2719bd1275  jz 0x00007B2719BD12E0
00007b2719bd127b  nop [rax+rax*1], ax
00007b2719bd1284  nop [rax+rax*1], eax
00007b2719bd128c  mov eax, 0x41039C
00007b2719bd1291  mov [r15+0x100], rax
00007b2719bd1298  jmp 0x00007B27199FE110
00007b2719bd129d  cmp dword ptr [r15+0x318], 0x00
00007b2719bd12a5  jz 0x00007B2719BD13E0
00007b2719bd12ab  nop [rax+rax*1], ax
00007b2719bd12b4  nop [rax+rax*1], eax
00007b2719bd12bc  mov eax, 0x410380
00007b2719bd12c1  mov [r15+0x100], rax
00007b2719bd12c8  jmp 0x00007B27199FE110
00007b2719bd12cd  int3
00007b2719bd12ce  call 0x00007B2719AB4B70
00007b2719bd12d3  jmp 0x00007B2719BD1241
00007b2719bd12d8  int3
00007b2719bd12d9  nop [rax], eax
00007b2719bd12e0  cmp dword ptr [r15+0x318], 0x00
00007b2719bd12e8  jz 0x00007B2719BD1320
00007b2719bd12ee  nop [rax+rax*1], ax
00007b2719bd12f7  nop [rax+rax*1], eax
00007b2719bd12ff  mov eax, 0x410364
00007b2719bd1304  mov [r15+0x100], rax
00007b2719bd130b  jmp 0x00007B27199FE110
00007b2719bd1310  int3
00007b2719bd1311  int3
00007b2719bd1312  nop [rax+rax*1], ax
00007b2719bd131b  nop [rax+rax*1], eax
00007b2719bd1320  mov qword ptr [r15+0x50], 0x00
00007b2719bd1328  mov rax, [r15+0x40]
00007b2719bd132c  lea r14, [rax+0x01]
00007b2719bd1330  mov [r15+0x40], r14
00007b2719bd1334  mov rax, [r15+0x98]
00007b2719bd133b  mov r12d, [r15+0x48]
00007b2719bd133f  mov [r13+rax*1], r12d
00007b2719bd1344  xor eax, eax
00007b2719bd1346  mov r12d, 0x400
00007b2719bd134c  cmp r14, r12
00007b2719bd134f  cmc
00007b2719bd1350  lahf
00007b2719bd1351  seto al
00007b2719bd1354  mov [r15+0x108], eax
00007b2719bd135b  mov eax, [r15+0x108]
00007b2719bd1362  sahf
00007b2719bd1363  jz 0x00007B2719BD1395
00007b2719bd1365  cmp dword ptr [r15+0x318], 0x00
00007b2719bd136d  jz 0x00007B2719BD1120
00007b2719bd1373  nop [rax+rax*1], ax
00007b2719bd137c  nop [rax+rax*1], eax
00007b2719bd1384  mov eax, 0x410378
00007b2719bd1389  mov [r15+0x100], rax
00007b2719bd1390  jmp 0x00007B27199FE110
00007b2719bd1395  cmp dword ptr [r15+0x318], 0x00
00007b2719bd139d  jz 0x00007B2719BD1580
00007b2719bd13a3  nop [rax+rax*1], ax
00007b2719bd13ac  nop [rax+rax*1], eax
00007b2719bd13b4  mov eax, 0x4103A0
00007b2719bd13b9  mov [r15+0x100], rax
00007b2719bd13c0  jmp 0x00007B27199FE110
00007b2719bd13c5  int3
00007b2719bd13c6  call 0x00007B2719A0BAE0
00007b2719bd13cb  jmp 0x00007B2719BD1344
00007b2719bd13d0  int3
00007b2719bd13d1  nop [rax+rax*1], ax
00007b2719bd13da  nop [rax+rax*1], ax
00007b2719bd13e0  mov eax, [r15+0x50]
00007b2719bd13e4  lea r14d, [eax-0x01]
00007b2719bd13e9  mov r14d, r14d
00007b2719bd13ec  mov [r15+0x58], r14
00007b2719bd13f0  mov rax, [r15+0x58]
00007b2719bd13f4  mov r14d, eax
00007b2719bd13f7  mov r14d, r14d
00007b2719bd13fa  shl r14, 0x02
00007b2719bd13fe  mov rax, [r15+0x98]
00007b2719bd1405  lea r12, [rax+r14*1]
00007b2719bd1409  mov eax, [r13+r12*1]
00007b2719bd140e  mov [rsp+0x10], eax
00007b2719bd1412  mov eax, eax
00007b2719bd1414  mov [r15+0x60], rax
00007b2719bd1418  mov eax, [r15+0x48]
00007b2719bd141c  mov [rsp+0x20], eax
00007b2719bd1420  xor eax, eax
00007b2719bd1422  mov r14d, [rsp+0x10]
00007b2719bd1427  mov r12d, [rsp+0x20]
00007b2719bd142c  cmp r14d, r12d
00007b2719bd142f  cmc
00007b2719bd1430  lahf
00007b2719bd1431  seto al
00007b2719bd1434  mov [r15+0x108], eax
00007b2719bd143b  mov eax, [r15+0x108]
00007b2719bd1442  sahf
00007b2719bd1443  cmc
00007b2719bd1444  jbe 0x00007B2719BD1476
00007b2719bd1446  cmp dword ptr [r15+0x318], 0x00
00007b2719bd144e  jz 0x00007B2719BD1220
00007b2719bd1454  nop [rax+rax*1], ax
00007b2719bd145d  nop [rax+rax*1], eax
00007b2719bd1465  mov eax, 0x410390
00007b2719bd146a  mov [r15+0x100], rax
00007b2719bd1471  jmp 0x00007B27199FE110
00007b2719bd1476  cmp dword ptr [r15+0x318], 0x00
00007b2719bd147e  jz 0x00007B2719BD14C0
00007b2719bd1484  nop [rax+rax*1], ax
00007b2719bd148d  nop [rax+rax*1], eax
00007b2719bd1495  mov eax, 0x410368
00007b2719bd149a  mov [r15+0x100], rax
00007b2719bd14a1  jmp 0x00007B27199FE110
00007b2719bd14a6  int3
00007b2719bd14a7  call 0x00007B2719AB4690
00007b2719bd14ac  jmp 0x00007B2719BD140E
00007b2719bd14b1  int3
00007b2719bd14b2  nop [rax+rax*1], ax
00007b2719bd14bb  nop [rax+rax*1], eax
00007b2719bd14c0  mov rax, [r15+0x40]
00007b2719bd14c4  lea r14, [rax+0x01]
00007b2719bd14c8  mov [r15+0x40], r14
00007b2719bd14cc  mov rax, [r15+0x50]
00007b2719bd14d0  mov r12d, eax
00007b2719bd14d3  mov r12d, r12d
00007b2719bd14d6  shl r12, 0x02
00007b2719bd14da  mov rax, [r15+0x98]
00007b2719bd14e1  lea r11, [rax+r12*1]
00007b2719bd14e5  mov eax, [r15+0x48]
00007b2719bd14e9  mov [r13+r11*1], eax
00007b2719bd14ee  xor eax, eax
00007b2719bd14f0  mov r12d, 0x400
00007b2719bd14f6  cmp r14, r12
00007b2719bd14f9  cmc
00007b2719bd14fa  lahf
00007b2719bd14fb  seto al
00007b2719bd14fe  mov [r15+0x108], eax
00007b2719bd1505  mov eax, [r15+0x108]
00007b2719bd150c  sahf
00007b2719bd150d  jz 0x00007B2719BD153F
00007b2719bd150f  cmp dword ptr [r15+0x318], 0x00
00007b2719bd1517  jz 0x00007B2719BD1120
00007b2719bd151d  nop [rax+rax*1], ax
00007b2719bd1526  nop [rax+rax*1], eax
00007b2719bd152e  mov eax, 0x410378
00007b2719bd1533  mov [r15+0x100], rax
00007b2719bd153a  jmp 0x00007B27199FE110
00007b2719bd153f  cmp dword ptr [r15+0x318], 0x00
00007b2719bd1547  jz 0x00007B2719BD1580
00007b2719bd154d  nop [rax+rax*1], ax
00007b2719bd1556  nop [rax+rax*1], eax
00007b2719bd155e  mov eax, 0x4103A0
00007b2719bd1563  mov [r15+0x100], rax
00007b2719bd156a  jmp 0x00007B27199FE110
00007b2719bd156f  int3
00007b2719bd1570  call 0x00007B2719AA4270
00007b2719bd1575  jmp 0x00007B2719BD14EE
00007b2719bd157a  int3
00007b2719bd157b  nop [rax+rax*1], eax
00007b2719bd1580  mov qword ptr [r15+0x40], 0x430000
00007b2719bd1588  mov eax, 0x430C40
00007b2719bd158d  mov r14, [r13+rax*1]
00007b2719bd1592  mov rax, [r15+0x98]
00007b2719bd1599  mov r12d, [r13+rax*1]
00007b2719bd159e  lea r11, [rax+0x04]
00007b2719bd15a2  mov eax, [r13+r11*1]
00007b2719bd15a7  mov r12d, r12d
00007b2719bd15aa  mov [r15+0x68], r12
00007b2719bd15ae  mov eax, eax
00007b2719bd15b0  mov [r15+0x60], rax
00007b2719bd15b4  mov rax, [r15+0x68]
00007b2719bd15b8  mov [r15+0x68], rax
00007b2719bd15bc  mov qword ptr [r15+0x58], 0x02
00007b2719bd15c4  mov [rsp+0x10], rax
00007b2719bd15c9  xor eax, eax
00007b2719bd15cb  mov r12d, 0x02
00007b2719bd15d1  mov r11d, 0x400
00007b2719bd15d7  cmp r12, r11
00007b2719bd15da  cmc
00007b2719bd15db  lahf
00007b2719bd15dc  seto al
00007b2719bd15df  mov [r15+0x108], eax
00007b2719bd15e6  mov rax, [r15+0x60]
00007b2719bd15ea  mov r12d, 0x02
00007b2719bd15f0  imul rax, r12
00007b2719bd15f4  mov [r15+0x50], rax
00007b2719bd15f8  mov rax, [rsp+0x10]
00007b2719bd15fd  lea r12, [rax+r14*1]
00007b2719bd1601  mov [r15+0x48], r12
00007b2719bd1605  mov eax, [r15+0x108]
00007b2719bd160c  sahf
00007b2719bd160d  jnz 0x00007B2719BD163F
00007b2719bd160f  cmp dword ptr [r15+0x318], 0x00
00007b2719bd1617  jz 0x00007B2719BD17B0
00007b2719bd161d  nop [rax+rax*1], ax
00007b2719bd1626  nop [rax+rax*1], eax
00007b2719bd162e  mov eax, 0x4103D0
00007b2719bd1633  mov [r15+0x100], rax
00007b2719bd163a  jmp 0x00007B27199FE110
00007b2719bd163f  cmp dword ptr [r15+0x318], 0x00
00007b2719bd1647  jz 0x00007B2719BD1690
00007b2719bd164d  nop [rax+rax*1], ax
00007b2719bd1656  nop [rax+rax*1], eax
00007b2719bd165e  mov eax, 0x4103B0
00007b2719bd1663  mov [r15+0x100], rax
00007b2719bd166a  jmp 0x00007B27199FE110
00007b2719bd166f  int3
00007b2719bd1670  call 0x00007B2719A0DC20
00007b2719bd1675  jmp 0x00007B2719BD1592
00007b2719bd167a  call 0x00007B2719A0B5E0
00007b2719bd167f  jmp 0x00007B2719BD159E
00007b2719bd1684  call 0x00007B2719AA3D90
00007b2719bd1689  jmp 0x00007B2719BD15A7
00007b2719bd168e  int3
00007b2719bd168f  nop
00007b2719bd1690  mov rax, [r15+0x98]
00007b2719bd1697  mov r14, [r15+0x58]
00007b2719bd169b  mov [rsp+0x10], r14
00007b2719bd16a0  shl r14, 0x02
00007b2719bd16a4  lea r12, [rax+r14*1]
00007b2719bd16a8  mov eax, [r13+r12*1]
00007b2719bd16ad  lea r14, [r12+0x04]
00007b2719bd16b2  mov r12d, [r13+r14*1]
00007b2719bd16b7  mov eax, eax
00007b2719bd16b9  mov [r15+0x68], rax
00007b2719bd16bd  mov r12d, r12d
00007b2719bd16c0  mov [r15+0x60], r12
00007b2719bd16c4  mov rax, [r15+0x68]
00007b2719bd16c8  mov [rsp+0x20], rax
00007b2719bd16cd  mov r14, [rsp+0x10]
00007b2719bd16d2  imul rax, r14
00007b2719bd16d6  mov r12, [rsp+0x20]
00007b2719bd16db  lea r11, [r12+rax*1]
00007b2719bd16df  mov [r15+0x68], r11
00007b2719bd16e3  lea rax, [r14+0x02]
00007b2719bd16e7  mov [r15+0x58], rax
00007b2719bd16eb  mov [rsp+0x10], rax
00007b2719bd16f0  xor eax, eax
00007b2719bd16f2  mov r14, [rsp+0x10]
00007b2719bd16f7  mov r12d, 0x400
00007b2719bd16fd  cmp r14, r12
00007b2719bd1700  cmc
00007b2719bd1701  lahf
00007b2719bd1702  seto al
00007b2719bd1705  mov [r15+0x108], eax
00007b2719bd170c  mov rax, [r15+0x50]
00007b2719bd1710  mov r12, [r15+0x60]
00007b2719bd1714  imul r14, r12
00007b2719bd1718  lea r12, [rax+r14*1]
00007b2719bd171c  mov [r15+0x50], r12
00007b2719bd1720  mov rax, [r15+0x48]
00007b2719bd1724  lea r14, [r11+rax*1]
00007b2719bd1728  mov [r15+0x48], r14
00007b2719bd172c  mov eax, [r15+0x108]
00007b2719bd1733  sahf
00007b2719bd1734  jnz 0x00007B2719BD1766
00007b2719bd1736  cmp dword ptr [r15+0x318], 0x00
00007b2719bd173e  jz 0x00007B2719BD17B0
00007b2719bd1744  nop [rax+rax*1], ax
00007b2719bd174d  nop [rax+rax*1], eax
00007b2719bd1755  mov eax, 0x4103D0
00007b2719bd175a  mov [r15+0x100], rax
00007b2719bd1761  jmp 0x00007B27199FE110
00007b2719bd1766  cmp dword ptr [r15+0x318], 0x00
00007b2719bd176e  jz 0x00007B2719BD1690
00007b2719bd1774  nop [rax+rax*1], ax
00007b2719bd177d  nop [rax+rax*1], eax
00007b2719bd1785  mov eax, 0x4103B0
00007b2719bd178a  mov [r15+0x100], rax
00007b2719bd1791  jmp 0x00007B27199FE110
00007b2719bd1796  int3
00007b2719bd1797  call 0x00007B2719AB4690
00007b2719bd179c  jmp 0x00007B2719BD16AD
00007b2719bd17a1  call 0x00007B2719AE26A0
00007b2719bd17a6  jmp 0x00007B2719BD16B7
00007b2719bd17ab  int3
00007b2719bd17ac  nop [rax], eax
00007b2719bd17b0  mov qword ptr [r15+0x98], 0x00
00007b2719bd17bb  mov rax, [r15+0x50]
00007b2719bd17bf  mov r14, [r15+0x48]
00007b2719bd17c3  lea r12, [rax+r14*1]
00007b2719bd17c7  mov [r15+0x48], r12
00007b2719bd17cb  mov rax, [r15+0x40]
00007b2719bd17cf  lea r14, [rax+0xC40]
00007b2719bd17d6  mov [r13+r14*1], r12
00007b2719bd17db  mov qword ptr [r15], 0x01
00007b2719bd17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007b2719bd17ed  mov r14d, [r15+0x320]
00007b2719bd17f4  mov eax, 0x4103E8
00007b2719bd17f9  mov rcx, 0x7B2719BD1860
00007b2719bd1803  mov [r15+r14*8+0x328], rax
00007b2719bd180b  mov [r15+r14*8+0x368], rcx
00007b2719bd1813  add r14d, 0x01
00007b2719bd1817  and r14d, 0x07
00007b2719bd181b  mov [r15+0x320], r14d
00007b2719bd1822  cmp dword ptr [r15+0x318], 0x00
00007b2719bd182a  jz 0x00007B2719BD0F20
00007b2719bd1830  nop [rax+rax*1], ax
00007b2719bd1839  nop [rax+rax*1], eax
00007b2719bd1841  mov eax, 0x410938
00007b2719bd1846  mov [r15+0x100], rax
00007b2719bd184d  jmp 0x00007B27199FE110
00007b2719bd1852  int3
00007b2719bd1853  call 0x00007B2719AE2CE0
00007b2719bd1858  jmp 0x00007B2719BD17DB
00007b2719bd185d  int3
00007b2719bd185e  nop
00007b2719bd1860  mov eax, [r15+0x98]
00007b2719bd1867  lea r14d, [eax+0x01]
00007b2719bd186c  mov [rsp+0x10], r14d
00007b2719bd1871  mov r14d, r14d
00007b2719bd1874  mov [r15+0x98], r14
00007b2719bd187b  xor eax, eax
00007b2719bd187d  mov r14d, [rsp+0x10]
00007b2719bd1882  cmp r14d, 0x10000
00007b2719bd1889  cmc
00007b2719bd188a  lahf
00007b2719bd188b  seto al
00007b2719bd188e  mov [r15+0x108], eax
00007b2719bd1895  mov eax, [r15+0x108]
00007b2719bd189c  sahf
00007b2719bd189d  jnz 0x00007B2719BD18CF
00007b2719bd189f  cmp dword ptr [r15+0x318], 0x00
00007b2719bd18a7  jz 0x00007B2719BD19A0
00007b2719bd18ad  nop [rax+rax*1], ax
00007b2719bd18b6  nop [rax+rax*1], eax
00007b2719bd18be  mov eax, 0x4103F4
00007b2719bd18c3  mov [r15+0x100], rax
00007b2719bd18ca  jmp 0x00007B27199FE110
00007b2719bd18cf  cmp dword ptr [r15+0x318], 0x00
00007b2719bd18d7  jz 0x00007B2719BD1910
00007b2719bd18dd  nop [rax+rax*1], ax
00007b2719bd18e6  nop [rax+rax*1], eax
00007b2719bd18ee  mov eax, 0x4103E0
00007b2719bd18f3  mov [r15+0x100], rax
00007b2719bd18fa  jmp 0x00007B27199FE110
00007b2719bd18ff  int3
00007b2719bd1900  int3
00007b2719bd1901  nop [rax+rax*1], ax
00007b2719bd190a  nop [rax+rax*1], ax
00007b2719bd1910  mov eax, [r15]
00007b2719bd1913  mov r14d, [r15+0x98]
00007b2719bd191a  lea r12d, [eax+r14d*1]
00007b2719bd191f  mov r12d, r12d
00007b2719bd1922  mov [r15], r12
00007b2719bd1925  mov qword ptr [r15+0xF0], 0x4103E8
00007b2719bd1930  mov r14d, [r15+0x320]
00007b2719bd1937  mov eax, 0x4103E8
00007b2719bd193c  mov rcx, 0x7B2719BD1860
00007b2719bd1946  mov [r15+r14*8+0x328], rax
00007b2719bd194e  mov [r15+r14*8+0x368], rcx
00007b2719bd1956  add r14d, 0x01
00007b2719bd195a  and r14d, 0x07
00007b2719bd195e  mov [r15+0x320], r14d
00007b2719bd1965  cmp dword ptr [r15+0x318], 0x00
00007b2719bd196d  jz 0x00007B2719BD0F20
00007b2719bd1973  nop [rax+rax*1], ax
00007b2719bd197c  nop [rax+rax*1], eax
00007b2719bd1984  mov eax, 0x410938
00007b2719bd1989  mov [r15+0x100], rax
00007b2719bd1990  jmp 0x00007B27199FE110
00007b2719bd1995  int3
00007b2719bd1996  int3
00007b2719bd1997  nop [rax+rax*1], ax
00007b2719bd19a0  vmovaps xmm1, [0x00007B27197FE010]
00007b2719bd19a8  movq xmm1, xmm1
00007b2719bd19ac  movaps [r15+0x110], xmm1
00007b2719bd19b4  mov eax, 0x420AA0
00007b2719bd19b9  mov r14, [r13+rax*1]
00007b2719bd19be  movq xmm1, r14
00007b2719bd19c3  movaps [r15+0x120], xmm1
00007b2719bd19cb  vmovaps xmm1, [0x00007B27197FE020]
00007b2719bd19d3  movq xmm1, xmm1
00007b2719bd19d7  movaps [r15+0x140], xmm1
00007b2719bd19df  vmovaps xmm1, [0x00007B27197FE030]
00007b2719bd19e7  vpbroadcastq xmm1, xmm1
00007b2719bd19ec  movaps [r15+0x150], xmm1
00007b2719bd19f4  mov qword ptr [r15+0x40], 0x02
00007b2719bd19fc  vmovaps xmm15, [0x00007B27197FE040]
00007b2719bd1a04  movq xmm15, xmm15
00007b2719bd1a09  movaps [r15+0x160], xmm15
00007b2719bd1a11  vmovaps xmm15, [0x00007B27197FE050]
00007b2719bd1a19  vpbroadcastq xmm15, xmm15
00007b2719bd1a1e  movaps [r15+0x130], xmm15
00007b2719bd1a26  mov rax, [r15+0x40]
00007b2719bd1a2a  vmovq xmm14, rax
00007b2719bd1a2f  vpbroadcastq xmm14, xmm14
00007b2719bd1a34  movaps [r15+0x170], xmm14
00007b2719bd1a3c  mov eax, 0x4209D0
00007b2719bd1a41  movups xmm13, [r13+rax*1]
00007b2719bd1a47  mov qword ptr [r15+0x40], 0x431D90
00007b2719bd1a4f  mov eax, [r15]
00007b2719bd1a52  mov r14d, 0x430C48
00007b2719bd1a58  mov [r13+r14*1], eax
00007b2719bd1a5d  mov qword ptr [r15+0x50], 0x431F90
00007b2719bd1a65  vpmovqd xmm12, xmm13
00007b2719bd1a6b  pxor xmm11, xmm11
00007b2719bd1a70  punpcklqdq xmm12, xmm11
00007b2719bd1a75  movaps [r15+0x210], xmm12
00007b2719bd1a7d  movq xmm12, qword ptr [r15+0x140]
00007b2719bd1a86  movq xmm11, qword ptr [r15+0x120]
00007b2719bd1a8f  psubd xmm12, xmm11
00007b2719bd1a94  movq xmm12, xmm12
00007b2719bd1a99  paddq xmm13, xmm14
00007b2719bd1a9e  movaps [r15+0x180], xmm13
00007b2719bd1aa6  movq xmm14, qword ptr [r15+0x160]
00007b2719bd1aaf  paddd xmm11, xmm14
00007b2719bd1ab4  movq xmm11, xmm11
00007b2719bd1ab9  movq xmm11, xmm11
00007b2719bd1abe  movaps [r15+0x120], xmm11
00007b2719bd1ac6  pmovzxdq xmm12, xmm12
00007b2719bd1acc  psllq xmm12, 0x00
00007b2719bd1ad2  movq xmm14, qword ptr [r15+0x210]
00007b2719bd1adb  movq xmm13, qword ptr [r15+0x110]
00007b2719bd1ae4  paddd xmm14, xmm13
00007b2719bd1ae9  movq xmm14, xmm14
00007b2719bd1aee  vcvtuqq2pd xmm12, xmm12
00007b2719bd1af4  pmovzxdq xmm14, xmm14
00007b2719bd1afa  psllq xmm14, 0x00
00007b2719bd1b00  vcvtuqq2pd xmm14, xmm14
00007b2719bd1b06  movaps xmm13, xmm12
00007b2719bd1b0a  mulpd xmm13, xmm1
00007b2719bd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007b2719bd1b15  ptest xmm11, xmm11
00007b2719bd1b1b  jnz 0x00007B2719BD1C0F
00007b2719bd1b21  movaps [r15+0x220], xmm13
00007b2719bd1b29  mov eax, 0x431F90
00007b2719bd1b2e  movups [r13+rax*1], xmm13
00007b2719bd1b34  movaps xmm1, xmm14
00007b2719bd1b38  mulpd xmm1, xmm15
00007b2719bd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007b2719bd1b42  ptest xmm13, xmm13
00007b2719bd1b48  jnz 0x00007B2719BD1D5C
00007b2719bd1b4e  movaps [r15+0x210], xmm1
00007b2719bd1b56  mov eax, 0x431D90
00007b2719bd1b5b  movups [r13+rax*1], xmm1
00007b2719bd1b61  mov qword ptr [r15+0x48], 0x10
00007b2719bd1b69  xor eax, eax
00007b2719bd1b6b  mov r14d, 0x10
00007b2719bd1b71  mov r12d, 0x200
00007b2719bd1b77  cmp r14, r12
00007b2719bd1b7a  cmc
00007b2719bd1b7b  lahf
00007b2719bd1b7c  seto al
00007b2719bd1b7f  mov [r15+0x108], eax
00007b2719bd1b86  mov eax, [r15+0x108]
00007b2719bd1b8d  sahf
00007b2719bd1b8e  jnz 0x00007B2719BD1BC0
00007b2719bd1b90  cmp dword ptr [r15+0x318], 0x00
00007b2719bd1b98  jz 0x00007B2719BD2300
00007b2719bd1b9e  nop [rax+rax*1], ax
00007b2719bd1ba7  nop [rax+rax*1], eax
00007b2719bd1baf  mov eax, 0x410480
00007b2719bd1bb4  mov [r15+0x100], rax
00007b2719bd1bbb  jmp 0x00007B27199FE110
00007b2719bd1bc0  cmp dword ptr [r15+0x318], 0x00
00007b2719bd1bc8  jz 0x00007B2719BD1EB0
00007b2719bd1bce  nop [rax+rax*1], ax
00007b2719bd1bd7  nop [rax+rax*1], eax
00007b2719bd1bdf  mov eax, 0x410440
00007b2719bd1be4  mov [r15+0x100], rax
00007b2719bd1beb  jmp 0x00007B27199FE110
00007b2719bd1bf0  int3
00007b2719bd1bf1  call 0x00007B2719A0DC20
00007b2719bd1bf6  jmp 0x00007B2719BD19BE
00007b2719bd1bfb  call 0x00007B2719A0C260
00007b2719bd1c00  jmp 0x00007B2719BD1A47
00007b2719bd1c05  call 0x00007B2719AD5D70
00007b2719bd1c0a  jmp 0x00007B2719BD1A5D
00007b2719bd1c0f  sub rsp, 0x08
00007b2719bd1c13  push rax
00007b2719bd1c14  push rcx
00007b2719bd1c15  push rdx
00007b2719bd1c16  push rdi
00007b2719bd1c17  push rsi
00007b2719bd1c18  push r8
00007b2719bd1c1a  push r9
00007b2719bd1c1c  push r10
00007b2719bd1c1e  push r11
00007b2719bd1c20  sub rsp, 0xF0
00007b2719bd1c27  vmovaps [rsp], xmm0
00007b2719bd1c2c  vmovaps [rsp+0x10], xmm1
00007b2719bd1c32  vmovaps [rsp+0x20], xmm2
00007b2719bd1c38  vmovaps [rsp+0x30], xmm3
00007b2719bd1c3e  vmovaps [rsp+0x40], xmm4
00007b2719bd1c44  vmovaps [rsp+0x50], xmm5
00007b2719bd1c4a  vmovaps [rsp+0x60], xmm6
00007b2719bd1c50  vmovaps [rsp+0x70], xmm7
00007b2719bd1c56  vmovaps [rsp+0x80], xmm8
00007b2719bd1c5f  vmovaps [rsp+0x90], xmm9
00007b2719bd1c68  vmovaps [rsp+0xA0], xmm10
00007b2719bd1c71  vmovaps [rsp+0xB0], xmm11
00007b2719bd1c7a  vmovaps [rsp+0xC0], xmm12
00007b2719bd1c83  vmovaps [rsp+0xD0], xmm14
00007b2719bd1c8c  vmovaps [rsp+0xE0], xmm15
00007b2719bd1c95  sub rsp, 0x30
00007b2719bd1c99  movaps [rsp], xmm13
00007b2719bd1c9e  movaps [rsp+0x10], xmm12
00007b2719bd1ca4  movaps [rsp+0x20], xmm1
00007b2719bd1ca9  lea rdi, [rsp]
00007b2719bd1cad  mov esi, 0x00
00007b2719bd1cb2  mov rax, 0x5A8E6560C530
00007b2719bd1cbc  call rax
00007b2719bd1cbe  movaps xmm13, [rsp]
00007b2719bd1cc3  add rsp, 0x30
00007b2719bd1cc7  vmovaps xmm0, [rsp]
00007b2719bd1ccc  vmovaps xmm1, [rsp+0x10]
00007b2719bd1cd2  vmovaps xmm2, [rsp+0x20]
00007b2719bd1cd8  vmovaps xmm3, [rsp+0x30]
00007b2719bd1cde  vmovaps xmm4, [rsp+0x40]
00007b2719bd1ce4  vmovaps xmm5, [rsp+0x50]
00007b2719bd1cea  vmovaps xmm6, [rsp+0x60]
00007b2719bd1cf0  vmovaps xmm7, [rsp+0x70]
00007b2719bd1cf6  vmovaps xmm8, [rsp+0x80]
00007b2719bd1cff  vmovaps xmm9, [rsp+0x90]
00007b2719bd1d08  vmovaps xmm10, [rsp+0xA0]
00007b2719bd1d11  vmovaps xmm11, [rsp+0xB0]
00007b2719bd1d1a  vmovaps xmm12, [rsp+0xC0]
00007b2719bd1d23  vmovaps xmm14, [rsp+0xD0]
00007b2719bd1d2c  vmovaps xmm15, [rsp+0xE0]
00007b2719bd1d35  add rsp, 0xF0
00007b2719bd1d3c  pop r11
00007b2719bd1d3e  pop r10
00007b2719bd1d40  pop r9
00007b2719bd1d42  pop r8
00007b2719bd1d44  pop rsi
00007b2719bd1d45  pop rdi
00007b2719bd1d46  pop rdx
00007b2719bd1d47  pop rcx
00007b2719bd1d48  pop rax
00007b2719bd1d49  add rsp, 0x08
00007b2719bd1d4d  jmp 0x00007B2719BD1B21
00007b2719bd1d52  call 0x00007B2719A0C380
00007b2719bd1d57  jmp 0x00007B2719BD1B34
00007b2719bd1d5c  sub rsp, 0x08
00007b2719bd1d60  push rax
00007b2719bd1d61  push rcx
00007b2719bd1d62  push rdx
00007b2719bd1d63  push rdi
00007b2719bd1d64  push rsi
00007b2719bd1d65  push r8
00007b2719bd1d67  push r9
00007b2719bd1d69  push r10
00007b2719bd1d6b  push r11
00007b2719bd1d6d  sub rsp, 0xF0
00007b2719bd1d74  vmovaps [rsp], xmm0
00007b2719bd1d79  vmovaps [rsp+0x10], xmm2
00007b2719bd1d7f  vmovaps [rsp+0x20], xmm3
00007b2719bd1d85  vmovaps [rsp+0x30], xmm4
00007b2719bd1d8b  vmovaps [rsp+0x40], xmm5
00007b2719bd1d91  vmovaps [rsp+0x50], xmm6
00007b2719bd1d97  vmovaps [rsp+0x60], xmm7
00007b2719bd1d9d  vmovaps [rsp+0x70], xmm8
00007b2719bd1da3  vmovaps [rsp+0x80], xmm9
00007b2719bd1dac  vmovaps [rsp+0x90], xmm10
00007b2719bd1db5  vmovaps [rsp+0xA0], xmm11
00007b2719bd1dbe  vmovaps [rsp+0xB0], xmm12
00007b2719bd1dc7  vmovaps [rsp+0xC0], xmm13
00007b2719bd1dd0  vmovaps [rsp+0xD0], xmm14
00007b2719bd1dd9  vmovaps [rsp+0xE0], xmm15
00007b2719bd1de2  sub rsp, 0x30
00007b2719bd1de6  movaps [rsp], xmm1
00007b2719bd1dea  movaps [rsp+0x10], xmm14
00007b2719bd1df0  movaps [rsp+0x20], xmm15
00007b2719bd1df6  lea rdi, [rsp]
00007b2719bd1dfa  mov esi, 0x00
00007b2719bd1dff  mov rax, 0x5A8E6560C530
00007b2719bd1e09  call rax
00007b2719bd1e0b  movaps xmm1, [rsp]
00007b2719bd1e0f  add rsp, 0x30
00007b2719bd1e13  vmovaps xmm0, [rsp]
00007b2719bd1e18  vmovaps xmm2, [rsp+0x10]
00007b2719bd1e1e  vmovaps xmm3, [rsp+0x20]
00007b2719bd1e24  vmovaps xmm4, [rsp+0x30]
00007b2719bd1e2a  vmovaps xmm5, [rsp+0x40]
00007b2719bd1e30  vmovaps xmm6, [rsp+0x50]
00007b2719bd1e36  vmovaps xmm7, [rsp+0x60]
00007b2719bd1e3c  vmovaps xmm8, [rsp+0x70]
00007b2719bd1e42  vmovaps xmm9, [rsp+0x80]
00007b2719bd1e4b  vmovaps xmm10, [rsp+0x90]
00007b2719bd1e54  vmovaps xmm11, [rsp+0xA0]
00007b2719bd1e5d  vmovaps xmm12, [rsp+0xB0]
00007b2719bd1e66  vmovaps xmm13, [rsp+0xC0]
00007b2719bd1e6f  vmovaps xmm14, [rsp+0xD0]
00007b2719bd1e78  vmovaps xmm15, [rsp+0xE0]
00007b2719bd1e81  add rsp, 0xF0
00007b2719bd1e88  pop r11
00007b2719bd1e8a  pop r10
00007b2719bd1e8c  pop r9
00007b2719bd1e8e  pop r8
00007b2719bd1e90  pop rsi
00007b2719bd1e91  pop rdi
00007b2719bd1e92  pop rdx
00007b2719bd1e93  pop rcx
00007b2719bd1e94  pop rax
00007b2719bd1e95  add rsp, 0x08
00007b2719bd1e99  jmp 0x00007B2719BD1B4E
00007b2719bd1e9e  call 0x00007B27199FF540
00007b2719bd1ea3  jmp 0x00007B2719BD1B61
00007b2719bd1ea8  int3
00007b2719bd1ea9  nop [rax], eax
00007b2719bd1eb0  movaps xmm1, [r15+0x180]
00007b2719bd1eb8  vpmovqd xmm15, xmm1
00007b2719bd1ebe  pxor xmm14, xmm14
00007b2719bd1ec3  punpcklqdq xmm15, xmm14
00007b2719bd1ec8  movaps [r15+0x210], xmm15
00007b2719bd1ed0  movq xmm15, qword ptr [r15+0x140]
00007b2719bd1ed9  movq xmm14, qword ptr [r15+0x120]
00007b2719bd1ee2  psubd xmm15, xmm14
00007b2719bd1ee7  movq xmm15, xmm15
00007b2719bd1eec  movaps xmm13, [r15+0x170]
00007b2719bd1ef4  paddq xmm1, xmm13
00007b2719bd1ef9  movaps [r15+0x180], xmm1
00007b2719bd1f01  movq xmm1, qword ptr [r15+0x160]
00007b2719bd1f0a  paddd xmm14, xmm1
00007b2719bd1f0f  movq xmm14, xmm14
00007b2719bd1f14  movq xmm14, xmm14
00007b2719bd1f19  movaps [r15+0x120], xmm14
00007b2719bd1f21  pmovzxdq xmm15, xmm15
00007b2719bd1f27  psllq xmm15, 0x00
00007b2719bd1f2d  movq xmm1, qword ptr [r15+0x210]
00007b2719bd1f36  movq xmm14, qword ptr [r15+0x110]
00007b2719bd1f3f  paddd xmm1, xmm14
00007b2719bd1f44  movq xmm1, xmm1
00007b2719bd1f48  vcvtuqq2pd xmm15, xmm15
00007b2719bd1f4e  pmovzxdq xmm1, xmm1
00007b2719bd1f53  psllq xmm1, 0x00
00007b2719bd1f58  vcvtuqq2pd xmm1, xmm1
00007b2719bd1f5e  movaps xmm14, [r15+0x150]
00007b2719bd1f66  movaps xmm13, xmm15
00007b2719bd1f6a  mulpd xmm13, xmm14
00007b2719bd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd1f75  ptest xmm12, xmm12
00007b2719bd1f7b  jnz 0x00007B2719BD205E
00007b2719bd1f81  movaps [r15+0x220], xmm13
00007b2719bd1f89  mov rax, [r15+0x48]
00007b2719bd1f8d  mov r14, [r15+0x50]
00007b2719bd1f91  lea r12, [r14+rax*1]
00007b2719bd1f95  movups [r13+r12*1], xmm13
00007b2719bd1f9b  movaps xmm15, [r15+0x130]
00007b2719bd1fa3  movaps xmm14, xmm1
00007b2719bd1fa7  mulpd xmm14, xmm15
00007b2719bd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007b2719bd1fb2  ptest xmm13, xmm13
00007b2719bd1fb8  jnz 0x00007B2719BD21AC
00007b2719bd1fbe  movaps [r15+0x210], xmm14
00007b2719bd1fc6  mov r14, [r15+0x40]
00007b2719bd1fca  lea r12, [r14+rax*1]
00007b2719bd1fce  movups [r13+r12*1], xmm14
00007b2719bd1fd4  lea r14, [rax+0x10]
00007b2719bd1fd8  mov [r15+0x48], r14
00007b2719bd1fdc  xor eax, eax
00007b2719bd1fde  mov r12d, 0x200
00007b2719bd1fe4  cmp r14, r12
00007b2719bd1fe7  cmc
00007b2719bd1fe8  lahf
00007b2719bd1fe9  seto al
00007b2719bd1fec  mov [r15+0x108], eax
00007b2719bd1ff3  mov eax, [r15+0x108]
00007b2719bd1ffa  sahf
00007b2719bd1ffb  jnz 0x00007B2719BD202D
00007b2719bd1ffd  cmp dword ptr [r15+0x318], 0x00
00007b2719bd2005  jz 0x00007B2719BD2300
00007b2719bd200b  nop [rax+rax*1], ax
00007b2719bd2014  nop [rax+rax*1], eax
00007b2719bd201c  mov eax, 0x410480
00007b2719bd2021  mov [r15+0x100], rax
00007b2719bd2028  jmp 0x00007B27199FE110
00007b2719bd202d  cmp dword ptr [r15+0x318], 0x00
00007b2719bd2035  jz 0x00007B2719BD1EB0
00007b2719bd203b  nop [rax+rax*1], ax
00007b2719bd2044  nop [rax+rax*1], eax
00007b2719bd204c  mov eax, 0x410440
00007b2719bd2051  mov [r15+0x100], rax
00007b2719bd2058  jmp 0x00007B27199FE110
00007b2719bd205d  int3
00007b2719bd205e  sub rsp, 0x08
00007b2719bd2062  push rax
00007b2719bd2063  push rcx
00007b2719bd2064  push rdx
00007b2719bd2065  push rdi
00007b2719bd2066  push rsi
00007b2719bd2067  push r8
00007b2719bd2069  push r9
00007b2719bd206b  push r10
00007b2719bd206d  push r11
00007b2719bd206f  sub rsp, 0xF0
00007b2719bd2076  vmovaps [rsp], xmm0
00007b2719bd207b  vmovaps [rsp+0x10], xmm1
00007b2719bd2081  vmovaps [rsp+0x20], xmm2
00007b2719bd2087  vmovaps [rsp+0x30], xmm3
00007b2719bd208d  vmovaps [rsp+0x40], xmm4
00007b2719bd2093  vmovaps [rsp+0x50], xmm5
00007b2719bd2099  vmovaps [rsp+0x60], xmm6
00007b2719bd209f  vmovaps [rsp+0x70], xmm7
00007b2719bd20a5  vmovaps [rsp+0x80], xmm8
00007b2719bd20ae  vmovaps [rsp+0x90], xmm9
00007b2719bd20b7  vmovaps [rsp+0xA0], xmm10
00007b2719bd20c0  vmovaps [rsp+0xB0], xmm11
00007b2719bd20c9  vmovaps [rsp+0xC0], xmm12
00007b2719bd20d2  vmovaps [rsp+0xD0], xmm14
00007b2719bd20db  vmovaps [rsp+0xE0], xmm15
00007b2719bd20e4  sub rsp, 0x30
00007b2719bd20e8  movaps [rsp], xmm13
00007b2719bd20ed  movaps [rsp+0x10], xmm15
00007b2719bd20f3  movaps [rsp+0x20], xmm14
00007b2719bd20f9  lea rdi, [rsp]
00007b2719bd20fd  mov esi, 0x00
00007b2719bd2102  mov rax, 0x5A8E6560C530
00007b2719bd210c  call rax
00007b2719bd210e  movaps xmm13, [rsp]
00007b2719bd2113  add rsp, 0x30
00007b2719bd2117  vmovaps xmm0, [rsp]
00007b2719bd211c  vmovaps xmm1, [rsp+0x10]
00007b2719bd2122  vmovaps xmm2, [rsp+0x20]
00007b2719bd2128  vmovaps xmm3, [rsp+0x30]
00007b2719bd212e  vmovaps xmm4, [rsp+0x40]
00007b2719bd2134  vmovaps xmm5, [rsp+0x50]
00007b2719bd213a  vmovaps xmm6, [rsp+0x60]
00007b2719bd2140  vmovaps xmm7, [rsp+0x70]
00007b2719bd2146  vmovaps xmm8, [rsp+0x80]
00007b2719bd214f  vmovaps xmm9, [rsp+0x90]
00007b2719bd2158  vmovaps xmm10, [rsp+0xA0]
00007b2719bd2161  vmovaps xmm11, [rsp+0xB0]
00007b2719bd216a  vmovaps xmm12, [rsp+0xC0]
00007b2719bd2173  vmovaps xmm14, [rsp+0xD0]
00007b2719bd217c  vmovaps xmm15, [rsp+0xE0]
00007b2719bd2185  add rsp, 0xF0
00007b2719bd218c  pop r11
00007b2719bd218e  pop r10
00007b2719bd2190  pop r9
00007b2719bd2192  pop r8
00007b2719bd2194  pop rsi
00007b2719bd2195  pop rdi
00007b2719bd2196  pop rdx
00007b2719bd2197  pop rcx
00007b2719bd2198  pop rax
00007b2719bd2199  add rsp, 0x08
00007b2719bd219d  jmp 0x00007B2719BD1F81
00007b2719bd21a2  call 0x00007B2719AC2240
00007b2719bd21a7  jmp 0x00007B2719BD1F9B
00007b2719bd21ac  sub rsp, 0x08
00007b2719bd21b0  push rax
00007b2719bd21b1  push rcx
00007b2719bd21b2  push rdx
00007b2719bd21b3  push rdi
00007b2719bd21b4  push rsi
00007b2719bd21b5  push r8
00007b2719bd21b7  push r9
00007b2719bd21b9  push r10
00007b2719bd21bb  push r11
00007b2719bd21bd  sub rsp, 0xF0
00007b2719bd21c4  vmovaps [rsp], xmm0
00007b2719bd21c9  vmovaps [rsp+0x10], xmm1
00007b2719bd21cf  vmovaps [rsp+0x20], xmm2
00007b2719bd21d5  vmovaps [rsp+0x30], xmm3
00007b2719bd21db  vmovaps [rsp+0x40], xmm4
00007b2719bd21e1  vmovaps [rsp+0x50], xmm5
00007b2719bd21e7  vmovaps [rsp+0x60], xmm6
00007b2719bd21ed  vmovaps [rsp+0x70], xmm7
00007b2719bd21f3  vmovaps [rsp+0x80], xmm8
00007b2719bd21fc  vmovaps [rsp+0x90], xmm9
00007b2719bd2205  vmovaps [rsp+0xA0], xmm10
00007b2719bd220e  vmovaps [rsp+0xB0], xmm11
00007b2719bd2217  vmovaps [rsp+0xC0], xmm12
00007b2719bd2220  vmovaps [rsp+0xD0], xmm13
00007b2719bd2229  vmovaps [rsp+0xE0], xmm15
00007b2719bd2232  sub rsp, 0x30
00007b2719bd2236  movaps [rsp], xmm14
00007b2719bd223b  movaps [rsp+0x10], xmm1
00007b2719bd2240  movaps [rsp+0x20], xmm15
00007b2719bd2246  lea rdi, [rsp]
00007b2719bd224a  mov esi, 0x00
00007b2719bd224f  mov rax, 0x5A8E6560C530
00007b2719bd2259  call rax
00007b2719bd225b  movaps xmm14, [rsp]
00007b2719bd2260  add rsp, 0x30
00007b2719bd2264  vmovaps xmm0, [rsp]
00007b2719bd2269  vmovaps xmm1, [rsp+0x10]
00007b2719bd226f  vmovaps xmm2, [rsp+0x20]
00007b2719bd2275  vmovaps xmm3, [rsp+0x30]
00007b2719bd227b  vmovaps xmm4, [rsp+0x40]
00007b2719bd2281  vmovaps xmm5, [rsp+0x50]
00007b2719bd2287  vmovaps xmm6, [rsp+0x60]
00007b2719bd228d  vmovaps xmm7, [rsp+0x70]
00007b2719bd2293  vmovaps xmm8, [rsp+0x80]
00007b2719bd229c  vmovaps xmm9, [rsp+0x90]
00007b2719bd22a5  vmovaps xmm10, [rsp+0xA0]
00007b2719bd22ae  vmovaps xmm11, [rsp+0xB0]
00007b2719bd22b7  vmovaps xmm12, [rsp+0xC0]
00007b2719bd22c0  vmovaps xmm13, [rsp+0xD0]
00007b2719bd22c9  vmovaps xmm15, [rsp+0xE0]
00007b2719bd22d2  add rsp, 0xF0
00007b2719bd22d9  pop r11
00007b2719bd22db  pop r10
00007b2719bd22dd  pop r9
00007b2719bd22df  pop r8
00007b2719bd22e1  pop rsi
00007b2719bd22e2  pop rdi
00007b2719bd22e3  pop rdx
00007b2719bd22e4  pop rcx
00007b2719bd22e5  pop rax
00007b2719bd22e6  add rsp, 0x08
00007b2719bd22ea  jmp 0x00007B2719BD1FBE
00007b2719bd22ef  call 0x00007B2719AC34C0
00007b2719bd22f4  jmp 0x00007B2719BD1FD4
00007b2719bd22f9  int3
00007b2719bd22fa  nop [rax+rax*1], ax
00007b2719bd2300  mov rax, [r15+0x50]
00007b2719bd2304  movups xmm1, [r13+rax*1]
00007b2719bd230a  lea r14, [rax+0x10]
00007b2719bd230e  movups xmm15, [r13+r14*1]
00007b2719bd2314  mov qword ptr [r15+0x48], 0x00
00007b2719bd231c  lea r14, [rax+0x40]
00007b2719bd2320  movups xmm14, [r13+r14*1]
00007b2719bd2326  lea r14, [rax+0x50]
00007b2719bd232a  movups xmm13, [r13+r14*1]
00007b2719bd2330  lea r14, [rax+0x80]
00007b2719bd2337  movups xmm12, [r13+r14*1]
00007b2719bd233d  lea r14, [rax+0x90]
00007b2719bd2344  movups xmm11, [r13+r14*1]
00007b2719bd234a  mov r14, [r15+0xF8]
00007b2719bd2351  movups [r13+r14*1], xmm1
00007b2719bd2357  lea r12, [rax+0x20]
00007b2719bd235b  movups xmm1, [r13+r12*1]
00007b2719bd2361  lea r12, [rax+0x30]
00007b2719bd2365  movups xmm10, [r13+r12*1]
00007b2719bd236b  lea r12, [rax+0xC0]
00007b2719bd2372  movups xmm9, [r13+r12*1]
00007b2719bd2378  lea r12, [rax+0xD0]
00007b2719bd237f  movups xmm8, [r13+r12*1]
00007b2719bd2385  lea r12, [rax+0x100]
00007b2719bd238c  movups xmm7, [r13+r12*1]
00007b2719bd2392  lea r12, [rax+0x110]
00007b2719bd2399  movups xmm6, [r13+r12*1]
00007b2719bd239f  lea r12, [rax+0x140]
00007b2719bd23a6  movups xmm5, [r13+r12*1]
00007b2719bd23ac  lea r12, [rax+0x150]
00007b2719bd23b3  movups xmm4, [r13+r12*1]
00007b2719bd23b9  lea r12, [r14+0xB0]
00007b2719bd23c0  movups [r13+r12*1], xmm10
00007b2719bd23c6  lea r12, [r14+0xC0]
00007b2719bd23cd  movups [r13+r12*1], xmm1
00007b2719bd23d3  lea r12, [rax+0x180]
00007b2719bd23da  movups xmm1, [r13+r12*1]
00007b2719bd23e0  lea r12, [rax+0x190]
00007b2719bd23e7  movups xmm10, [r13+r12*1]
00007b2719bd23ed  lea r12, [rax+0x1C0]
00007b2719bd23f4  movups xmm3, [r13+r12*1]
00007b2719bd23fa  lea r12, [rax+0x1D0]
00007b2719bd2401  movups xmm2, [r13+r12*1]
00007b2719bd2407  lea r12, [rax+0x60]
00007b2719bd240b  vmovaps [rsp+0x10], xmm1
00007b2719bd2411  movups xmm1, [r13+r12*1]
00007b2719bd2417  lea r12, [rax+0x70]
00007b2719bd241b  vmovaps [rsp+0x20], xmm1
00007b2719bd2421  movups xmm1, [r13+r12*1]
00007b2719bd2427  lea r12, [r14+0x70]
00007b2719bd242b  movups [r13+r12*1], xmm10
00007b2719bd2431  lea r12, [r14+0x80]
00007b2719bd2438  vmovaps xmm10, [rsp+0x10]
00007b2719bd243e  movups [r13+r12*1], xmm10
00007b2719bd2444  lea r12, [rax+0xA0]
00007b2719bd244b  movups xmm10, [r13+r12*1]
00007b2719bd2451  lea r12, [rax+0xB0]
00007b2719bd2458  vmovaps [rsp+0x10], xmm1
00007b2719bd245e  movups xmm1, [r13+r12*1]
00007b2719bd2464  lea r12, [r14+0x90]
00007b2719bd246b  movups [r13+r12*1], xmm2
00007b2719bd2471  lea r12, [r14+0xA0]
00007b2719bd2478  movups [r13+r12*1], xmm3
00007b2719bd247e  lea r12, [rax+0xE0]
00007b2719bd2485  movups xmm3, [r13+r12*1]
00007b2719bd248b  lea r12, [rax+0xF0]
00007b2719bd2492  movups xmm2, [r13+r12*1]
00007b2719bd2498  lea r12, [rax+0x120]
00007b2719bd249f  vmovaps [rsp+0x30], xmm1
00007b2719bd24a5  movups xmm1, [r13+r12*1]
00007b2719bd24ab  lea r12, [rax+0x130]
00007b2719bd24b2  vmovaps [rsp+0x40], xmm1
00007b2719bd24b8  movups xmm1, [r13+r12*1]
00007b2719bd24be  vmovaps [rsp+0x50], xmm1
00007b2719bd24c4  vmovaps xmm1, [rsp+0x40]
00007b2719bd24ca  movaps [r15+0x190], xmm1
00007b2719bd24d2  lea r12, [rax+0x160]
00007b2719bd24d9  vmovaps [rsp+0x40], xmm1
00007b2719bd24df  movups xmm1, [r13+r12*1]
00007b2719bd24e5  lea r12, [rax+0x170]
00007b2719bd24ec  vmovaps [rsp+0x60], xmm1
00007b2719bd24f2  movups xmm1, [r13+r12*1]
00007b2719bd24f8  lea r12, [rax+0x1A0]
00007b2719bd24ff  vmovaps [rsp+0x70], xmm1
00007b2719bd2505  movups xmm1, [r13+r12*1]
00007b2719bd250b  lea r12, [rax+0x1B0]
00007b2719bd2512  vmovaps [rsp+0x80], xmm1
00007b2719bd251b  movups xmm1, [r13+r12*1]
00007b2719bd2521  lea r12, [rax+0x1E0]
00007b2719bd2528  vmovaps [rsp+0x90], xmm1
00007b2719bd2531  movups xmm1, [r13+r12*1]
00007b2719bd2537  lea r12, [rax+0x1F0]
00007b2719bd253e  vmovaps [rsp+0xA0], xmm1
00007b2719bd2547  movups xmm1, [r13+r12*1]
00007b2719bd254d  mov qword ptr [r15+0x50], 0x432190
00007b2719bd2555  lea rax, [r14+0x50]
00007b2719bd2559  vmovaps [rsp+0xB0], xmm1
00007b2719bd2562  vmovaps xmm1, [rsp+0x60]
00007b2719bd2568  movups [r13+rax*1], xmm1
00007b2719bd256e  lea rax, [r14+0x60]
00007b2719bd2572  movups [r13+rax*1], xmm5
00007b2719bd2578  lea rax, [r14+0x40]
00007b2719bd257c  vmovaps xmm1, [rsp+0x70]
00007b2719bd2582  movups [r13+rax*1], xmm1
00007b2719bd2588  lea rax, [r14+0x20]
00007b2719bd258c  vmovaps xmm1, [rsp+0xA0]
00007b2719bd2595  movups [r13+rax*1], xmm1
00007b2719bd259b  lea rax, [r14+0x30]
00007b2719bd259f  vmovaps xmm1, [rsp+0x90]
00007b2719bd25a8  movups [r13+rax*1], xmm1
00007b2719bd25ae  lea rax, [r14+0x10]
00007b2719bd25b2  vmovaps xmm1, [rsp+0xB0]
00007b2719bd25bb  movups [r13+rax*1], xmm1
00007b2719bd25c1  mov rax, [r15+0x40]
00007b2719bd25c5  vxorps xmm1, xmm1, xmm1
00007b2719bd25c9  vpbroadcastq xmm1, xmm1
00007b2719bd25ce  vxorps xmm5, xmm5, xmm5
00007b2719bd25d2  vpbroadcastq xmm5, xmm5
00007b2719bd25d7  lea r12, [rax+0x30]
00007b2719bd25db  mov r11, [r13+r12*1]
00007b2719bd25e0  lea r12, [rax+0x38]
00007b2719bd25e4  mov r10, [r13+r12*1]
00007b2719bd25e9  vmovaps [rsp+0x60], xmm1
00007b2719bd25ef  movq xmm1, r11
00007b2719bd25f4  vmovaps [rsp+0x70], xmm1
00007b2719bd25fa  movq xmm1, r10
00007b2719bd25ff  vmovaps [rsp+0x90], xmm1
00007b2719bd2608  vmovaps xmm1, [rsp+0x70]
00007b2719bd260e  movq xmm1, xmm1
00007b2719bd2612  vmovaps [rsp+0x70], xmm1
00007b2719bd2618  vmovaps xmm1, [rsp+0x90]
00007b2719bd2621  movq xmm1, xmm1
00007b2719bd2625  vmovaps [rsp+0x90], xmm1
00007b2719bd262e  movq xmm1, xmm1
00007b2719bd2632  movaps [r15+0x270], xmm1
00007b2719bd263a  vmovaps [rsp+0xA0], xmm7
00007b2719bd2643  vmovaps xmm1, [rsp+0xA0]
00007b2719bd264c  por xmm7, xmm1
00007b2719bd2650  lea r12, [rax+0x20]
00007b2719bd2654  mov r11, [r13+r12*1]
00007b2719bd2659  lea r12, [rax+0x28]
00007b2719bd265d  mov r10, [r13+r12*1]
00007b2719bd2662  movq xmm1, r11
00007b2719bd2667  vmovaps [rsp+0xA0], xmm1
00007b2719bd2670  movq xmm1, r10
00007b2719bd2675  vmovaps [rsp+0xB0], xmm1
00007b2719bd267e  vmovaps xmm1, [rsp+0xA0]
00007b2719bd2687  movq xmm1, xmm1
00007b2719bd268b  vmovaps [rsp+0xA0], xmm1
00007b2719bd2694  vmovaps xmm1, [rsp+0xB0]
00007b2719bd269d  movq xmm1, xmm1
00007b2719bd26a1  vmovaps [rsp+0xB0], xmm2
00007b2719bd26aa  vmovaps [rsp+0xC0], xmm1
00007b2719bd26b3  vmovaps xmm1, [rsp+0xB0]
00007b2719bd26bc  por xmm2, xmm1
00007b2719bd26c0  vmovaps [rsp+0xB0], xmm3
00007b2719bd26c9  vmovaps xmm1, [rsp+0xB0]
00007b2719bd26d2  por xmm3, xmm1
00007b2719bd26d6  vmovaps [rsp+0xB0], xmm4
00007b2719bd26df  vmovaps xmm1, [rsp+0xB0]
00007b2719bd26e8  por xmm4, xmm1
00007b2719bd26ec  vmovaps [rsp+0xB0], xmm9
00007b2719bd26f5  vmovaps xmm1, [rsp+0xB0]
00007b2719bd26fe  por xmm9, xmm1
00007b2719bd2703  lea r12, [rax+0x10]
00007b2719bd2707  mov r11, [r13+r12*1]
00007b2719bd270c  lea r12, [rax+0x18]
00007b2719bd2710  mov r10, [r13+r12*1]
00007b2719bd2715  movq xmm1, r11
00007b2719bd271a  vmovaps [rsp+0xB0], xmm1
00007b2719bd2723  movq xmm1, r10
00007b2719bd2728  vmovaps [rsp+0xD0], xmm1
00007b2719bd2731  vmovaps xmm1, [rsp+0xB0]
00007b2719bd273a  movq xmm1, xmm1
00007b2719bd273e  vmovaps [rsp+0xB0], xmm1
00007b2719bd2747  vmovaps xmm1, [rsp+0xD0]
00007b2719bd2750  movq xmm1, xmm1
00007b2719bd2754  vmovaps [rsp+0xD0], xmm1
00007b2719bd275d  vmovaps xmm1, [rsp+0x80]
00007b2719bd2766  vmovaps [rsp+0xE0], xmm15
00007b2719bd276f  vmovaps xmm15, [rsp+0x80]
00007b2719bd2778  por xmm1, xmm15
00007b2719bd277d  vmovaps xmm15, [rsp+0x10]
00007b2719bd2783  vmovaps [rsp+0x80], xmm1
00007b2719bd278c  vmovaps xmm1, [rsp+0x10]
00007b2719bd2792  por xmm15, xmm1
00007b2719bd2797  vmovaps xmm1, [rsp+0x20]
00007b2719bd279d  vmovaps [rsp+0x10], xmm15
00007b2719bd27a3  vmovaps xmm15, [rsp+0x20]
00007b2719bd27a9  por xmm1, xmm15
00007b2719bd27ae  vmovaps [rsp+0x20], xmm6
00007b2719bd27b4  vmovaps xmm15, [rsp+0x20]
00007b2719bd27ba  por xmm6, xmm15
00007b2719bd27bf  vmovaps [rsp+0x20], xmm11
00007b2719bd27c5  vmovaps xmm15, [rsp+0x20]
00007b2719bd27cb  por xmm11, xmm15
00007b2719bd27d0  vmovaps [rsp+0x20], xmm13
00007b2719bd27d6  vmovaps xmm15, [rsp+0x20]
00007b2719bd27dc  por xmm13, xmm15
00007b2719bd27e1  vmovaps [rsp+0x20], xmm14
00007b2719bd27e7  vmovaps xmm15, [rsp+0x20]
00007b2719bd27ed  por xmm14, xmm15
00007b2719bd27f2  mov r12, [r13+rax*1]
00007b2719bd27f7  vmovq xmm15, r12
00007b2719bd27fc  vpbroadcastq xmm15, xmm15
00007b2719bd2801  vmovaps [rsp+0x20], xmm1
00007b2719bd2807  vxorps xmm1, xmm1, xmm1
00007b2719bd280b  vpbroadcastq xmm1, xmm1
00007b2719bd2810  vmovaps [rsp+0xF0], xmm1
00007b2719bd2819  movups xmm1, [r13+r14*1]
00007b2719bd281f  vmovaps [rsp+0x100], xmm1
00007b2719bd2828  vxorps xmm1, xmm1, xmm1
00007b2719bd282c  vpbroadcastq xmm1, xmm1
00007b2719bd2831  lea r12, [rax+0x08]
00007b2719bd2835  mov rax, [r13+r12*1]
00007b2719bd283a  vmovaps [rsp+0x110], xmm1
00007b2719bd2843  movq xmm1, rax
00007b2719bd2848  movaps [r15+0x240], xmm1
00007b2719bd2850  mov qword ptr [r15+0x60], 0x432190
00007b2719bd2858  mov qword ptr [r15+0x58], 0x40
00007b2719bd2860  vmovaps xmm1, [rsp+0x60]
00007b2719bd2866  vmovaps [rsp+0x60], xmm15
00007b2719bd286c  vmovaps xmm15, [rsp+0x100]
00007b2719bd2875  vmovaps [rsp+0x100], xmm14
00007b2719bd287e  vmovaps xmm14, [rsp+0x60]
00007b2719bd2884  vmovaps [rsp+0x60], xmm13
00007b2719bd288a  vmovaps [rsp+0x120], xmm12
00007b2719bd2893  movaps xmm13, xmm1
00007b2719bd2897  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd28a2  vptest xmm12, xmm12
00007b2719bd28a7  jnz 0x00007B2719BD3482
00007b2719bd28ad  vmovaps xmm1, [rsp+0xE0]
00007b2719bd28b6  movaps xmm15, xmm5
00007b2719bd28ba  vfmadd231pd xmm15, xmm1, xmm14
00007b2719bd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007b2719bd28c5  vptest xmm12, xmm12
00007b2719bd28ca  jnz 0x00007B2719BD35DB
00007b2719bd28d0  vmovaps xmm12, [rsp+0x50]
00007b2719bd28d6  vmovaps xmm5, [rsp+0x50]
00007b2719bd28dc  por xmm12, xmm5
00007b2719bd28e1  vmovaps xmm5, [rsp+0x30]
00007b2719bd28e7  vmovaps [rsp+0x50], xmm1
00007b2719bd28ed  vmovaps xmm1, [rsp+0x30]
00007b2719bd28f3  por xmm5, xmm1
00007b2719bd28f7  vmovaps [rsp+0x30], xmm10
00007b2719bd28fd  vmovaps xmm1, [rsp+0x30]
00007b2719bd2903  por xmm10, xmm1
00007b2719bd2908  vmovaps [rsp+0x30], xmm8
00007b2719bd290e  vmovaps xmm1, [rsp+0x30]
00007b2719bd2914  por xmm8, xmm1
00007b2719bd2919  vmovaps xmm1, [rsp+0x120]
00007b2719bd2922  vmovaps [rsp+0x30], xmm15
00007b2719bd2928  vmovaps xmm15, [rsp+0x120]
00007b2719bd2931  por xmm1, xmm15
00007b2719bd2936  vmovaps xmm15, [rsp+0x50]
00007b2719bd293c  vmovaps [rsp+0xE0], xmm1
00007b2719bd2945  vmovaps xmm1, [rsp+0x50]
00007b2719bd294b  por xmm15, xmm1
00007b2719bd2950  lea rax, [r14+0xC0]
00007b2719bd2957  movups xmm1, [r13+rax*1]
00007b2719bd295d  xor eax, eax
00007b2719bd295f  mov r12d, 0x40
00007b2719bd2965  mov r11d, 0x200
00007b2719bd296b  cmp r12, r11
00007b2719bd296e  cmc
00007b2719bd296f  lahf
00007b2719bd2970  seto al
00007b2719bd2973  mov [r15+0x108], eax
00007b2719bd297a  vmovaps [rsp+0x50], xmm1
00007b2719bd2980  vmovaps xmm1, [rsp+0xF0]
00007b2719bd2989  vmovaps [rsp+0xF0], xmm15
00007b2719bd2992  vmovaps xmm15, [rsp+0x50]
00007b2719bd2998  vmovaps [rsp+0x50], xmm13
00007b2719bd299e  vmovaps [rsp+0x120], xmm12
00007b2719bd29a7  movaps xmm13, xmm1
00007b2719bd29ab  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd29b6  vptest xmm12, xmm12
00007b2719bd29bb  jnz 0x00007B2719BD373D
00007b2719bd29c1  lea rax, [r14+0xB0]
00007b2719bd29c8  movups xmm1, [r13+rax*1]
00007b2719bd29ce  vmovaps xmm15, [rsp+0x110]
00007b2719bd29d7  vmovaps [rsp+0x110], xmm13
00007b2719bd29e0  movaps xmm12, xmm15
00007b2719bd29e4  vfmadd231pd xmm12, xmm1, xmm14
00007b2719bd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007b2719bd29ef  vptest xmm13, xmm13
00007b2719bd29f4  jnz 0x00007B2719BD38A0
00007b2719bd29fa  vmovaps xmm1, [rsp+0x100]
00007b2719bd2a03  vmovaps xmm15, [rsp+0x100]
00007b2719bd2a0c  por xmm1, xmm15
00007b2719bd2a11  movaps [r15+0x210], xmm1
00007b2719bd2a19  vmovaps xmm15, [rsp+0x60]
00007b2719bd2a1f  vmovaps xmm14, [rsp+0x60]
00007b2719bd2a25  por xmm15, xmm14
00007b2719bd2a2a  movaps [r15+0x1C0], xmm15
00007b2719bd2a32  vmovaps [rsp+0x60], xmm11
00007b2719bd2a38  vmovaps xmm14, [rsp+0x60]
00007b2719bd2a3e  por xmm11, xmm14
00007b2719bd2a43  movaps [r15+0x280], xmm11
00007b2719bd2a4b  vmovaps [rsp+0x60], xmm6
00007b2719bd2a51  vmovaps xmm14, [rsp+0x60]
00007b2719bd2a57  por xmm6, xmm14
00007b2719bd2a5c  movaps [r15+0x2A0], xmm6
00007b2719bd2a64  vmovaps xmm14, [rsp+0x20]
00007b2719bd2a6a  vmovaps xmm13, [rsp+0x20]
00007b2719bd2a70  por xmm14, xmm13
00007b2719bd2a75  movaps [r15+0x2E0], xmm14
00007b2719bd2a7d  vmovaps xmm13, [rsp+0x10]
00007b2719bd2a83  vmovaps [rsp+0x20], xmm1
00007b2719bd2a89  vmovaps xmm1, [rsp+0x10]
00007b2719bd2a8f  por xmm13, xmm1
00007b2719bd2a94  movaps [r15+0x1F0], xmm13
00007b2719bd2a9c  vmovaps xmm1, [rsp+0xF0]
00007b2719bd2aa5  vmovaps [rsp+0x10], xmm15
00007b2719bd2aab  vmovaps xmm15, [rsp+0xF0]
00007b2719bd2ab4  por xmm1, xmm15
00007b2719bd2ab9  movaps [r15+0x250], xmm1
00007b2719bd2ac1  vmovaps xmm1, [rsp+0xE0]
00007b2719bd2aca  vmovaps xmm15, [rsp+0xE0]
00007b2719bd2ad3  por xmm1, xmm15
00007b2719bd2ad8  movaps [r15+0x260], xmm1
00007b2719bd2ae0  vmovaps [rsp+0x60], xmm8
00007b2719bd2ae6  vmovaps xmm15, [rsp+0x60]
00007b2719bd2aec  por xmm8, xmm15
00007b2719bd2af1  movaps [r15+0x290], xmm8
00007b2719bd2af9  vmovaps [rsp+0x60], xmm10
00007b2719bd2aff  vmovaps xmm15, [rsp+0x60]
00007b2719bd2b05  por xmm10, xmm15
00007b2719bd2b0a  movaps [r15+0x2C0], xmm10
00007b2719bd2b12  movq xmm15, qword ptr [r15+0x240]
00007b2719bd2b1b  vmovaps [rsp+0x60], xmm15
00007b2719bd2b21  vpermilpd xmm15, xmm15, 0x00
00007b2719bd2b27  vmovaps [rsp+0xE0], xmm1
00007b2719bd2b30  vmovaps xmm1, [rsp+0x50]
00007b2719bd2b36  vmovaps [rsp+0x50], xmm15
00007b2719bd2b3c  vmovaps xmm15, [rsp+0x20]
00007b2719bd2b42  vmovaps [rsp+0x20], xmm14
00007b2719bd2b48  vmovaps xmm14, [rsp+0x50]
00007b2719bd2b4e  vmovaps [rsp+0x50], xmm13
00007b2719bd2b54  vmovaps [rsp+0xF0], xmm12
00007b2719bd2b5d  movaps xmm13, xmm1
00007b2719bd2b61  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd2b6c  vptest xmm12, xmm12
00007b2719bd2b71  jnz 0x00007B2719BD39F9
00007b2719bd2b77  vmovaps xmm1, [rsp+0x60]
00007b2719bd2b7d  vpermilpd xmm1, xmm1, 0x00
00007b2719bd2b83  vmovaps xmm15, [rsp+0x110]
00007b2719bd2b8c  vmovaps xmm14, [rsp+0x20]
00007b2719bd2b92  vmovaps [rsp+0x20], xmm13
00007b2719bd2b98  movaps xmm12, xmm15
00007b2719bd2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007b2719bd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007b2719bd2ba7  vptest xmm13, xmm13
00007b2719bd2bac  jnz 0x00007B2719BD3B52
00007b2719bd2bb2  vmovaps xmm1, [rsp+0x60]
00007b2719bd2bb8  vpermilpd xmm1, xmm1, 0x00
00007b2719bd2bbe  vmovaps xmm15, [rsp+0x30]
00007b2719bd2bc4  vmovaps xmm14, [rsp+0x10]
00007b2719bd2bca  vmovaps [rsp+0x10], xmm12
00007b2719bd2bd0  movaps xmm13, xmm15
00007b2719bd2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007b2719bd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd2bdf  vptest xmm12, xmm12
00007b2719bd2be4  jnz 0x00007B2719BD3CAB
00007b2719bd2bea  vmovaps [rsp+0x30], xmm5
00007b2719bd2bf0  vmovaps xmm1, [rsp+0x30]
00007b2719bd2bf6  por xmm5, xmm1
00007b2719bd2bfa  movaps [r15+0x1D0], xmm5
00007b2719bd2c02  vmovaps xmm1, [rsp+0x60]
00007b2719bd2c08  vpermilpd xmm1, xmm1, 0x00
00007b2719bd2c0e  vmovaps xmm15, [rsp+0xF0]
00007b2719bd2c17  vmovaps xmm14, [rsp+0x50]
00007b2719bd2c1d  vmovaps [rsp+0x30], xmm13
00007b2719bd2c23  movaps xmm12, xmm15
00007b2719bd2c27  vfmadd231pd xmm12, xmm14, xmm1
00007b2719bd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007b2719bd2c32  vptest xmm13, xmm13
00007b2719bd2c37  jnz 0x00007B2719BD3E04
00007b2719bd2c3d  vmovaps xmm1, [rsp+0x80]
00007b2719bd2c46  vmovaps xmm15, [rsp+0x80]
00007b2719bd2c4f  por xmm1, xmm15
00007b2719bd2c54  movaps [r15+0x200], xmm1
00007b2719bd2c5c  vmovaps xmm15, [rsp+0x120]
00007b2719bd2c65  vmovaps xmm14, [rsp+0x120]
00007b2719bd2c6e  por xmm15, xmm14
00007b2719bd2c73  movaps [r15+0x1E0], xmm15
00007b2719bd2c7b  vmovaps [rsp+0x50], xmm4
00007b2719bd2c81  vmovaps xmm13, [rsp+0x50]
00007b2719bd2c87  por xmm4, xmm13
00007b2719bd2c8c  movaps [r15+0x2B0], xmm4
00007b2719bd2c94  vmovaps [rsp+0x50], xmm3
00007b2719bd2c9a  vmovaps xmm13, [rsp+0x50]
00007b2719bd2ca0  por xmm3, xmm13
00007b2719bd2ca5  movaps [r15+0x300], xmm3
00007b2719bd2cad  vmovaps xmm15, [rsp+0xB0]
00007b2719bd2cb6  vpermilpd xmm15, xmm15, 0x00
00007b2719bd2cbc  vmovaps xmm3, [rsp+0x20]
00007b2719bd2cc2  vmovaps [rsp+0x20], xmm1
00007b2719bd2cc8  vmovaps xmm1, [rsp+0xE0]
00007b2719bd2cd1  vmovaps [rsp+0x50], xmm14
00007b2719bd2cd7  vmovaps [rsp+0x60], xmm13
00007b2719bd2cdd  movaps xmm14, xmm3
00007b2719bd2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007b2719bd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007b2719bd2cec  vptest xmm13, xmm13
00007b2719bd2cf1  jnz 0x00007B2719BD3F5D
00007b2719bd2cf7  vmovaps xmm1, [rsp+0xB0]
00007b2719bd2d00  vpermilpd xmm1, xmm1, 0x00
00007b2719bd2d06  vmovaps xmm15, [rsp+0x10]
00007b2719bd2d0c  movaps xmm13, xmm15
00007b2719bd2d10  vfmadd231pd xmm13, xmm10, xmm1
00007b2719bd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007b2719bd2d1b  vptest xmm3, xmm3
00007b2719bd2d20  jnz 0x00007B2719BD40B5
00007b2719bd2d26  vmovaps xmm1, [rsp+0xB0]
00007b2719bd2d2f  vpermilpd xmm1, xmm1, 0x00
00007b2719bd2d35  vmovaps xmm15, [rsp+0x30]
00007b2719bd2d3b  movaps xmm10, xmm15
00007b2719bd2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007b2719bd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007b2719bd2d4a  vptest xmm3, xmm3
00007b2719bd2d4f  jnz 0x00007B2719BD420E
00007b2719bd2d55  vmovaps xmm1, [rsp+0xB0]
00007b2719bd2d5e  vpermilpd xmm1, xmm1, 0x00
00007b2719bd2d64  movaps xmm15, xmm12
00007b2719bd2d68  vfmadd231pd xmm15, xmm5, xmm1
00007b2719bd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007b2719bd2d73  vptest xmm11, xmm11
00007b2719bd2d78  jnz 0x00007B2719BD4367
00007b2719bd2d7e  vmovaps [rsp+0x10], xmm9
00007b2719bd2d84  vmovaps xmm1, [rsp+0x10]
00007b2719bd2d8a  por xmm9, xmm1
00007b2719bd2d8f  movaps [r15+0x180], xmm9
00007b2719bd2d97  vmovaps [rsp+0x10], xmm2
00007b2719bd2d9d  vmovaps xmm1, [rsp+0x10]
00007b2719bd2da3  por xmm2, xmm1
00007b2719bd2da7  movaps [r15+0x2D0], xmm2
00007b2719bd2daf  vmovaps xmm12, [rsp+0xD0]
00007b2719bd2db8  vpermilpd xmm12, xmm12, 0x00
00007b2719bd2dbe  vmovaps xmm11, [rsp+0x60]
00007b2719bd2dc4  movaps xmm5, xmm13
00007b2719bd2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007b2719bd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007b2719bd2dd2  vptest xmm3, xmm3
00007b2719bd2dd7  jnz 0x00007B2719BD44BF
00007b2719bd2ddd  vmovaps xmm13, [rsp+0xD0]
00007b2719bd2de6  vpermilpd xmm13, xmm13, 0x00
00007b2719bd2dec  movaps xmm12, xmm14
00007b2719bd2df0  vfmadd231pd xmm12, xmm9, xmm13
00007b2719bd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007b2719bd2dfb  vptest xmm11, xmm11
00007b2719bd2e00  jnz 0x00007B2719BD4617
00007b2719bd2e06  lea rax, [r14+0x80]
00007b2719bd2e0d  movups xmm14, [r13+rax*1]
00007b2719bd2e13  movaps [r15+0x2F0], xmm14
00007b2719bd2e1b  vmovaps xmm13, [rsp+0xD0]
00007b2719bd2e24  vpermilpd xmm13, xmm13, 0x00
00007b2719bd2e2a  movaps xmm11, xmm10
00007b2719bd2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007b2719bd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007b2719bd2e39  vptest xmm9, xmm9
00007b2719bd2e3e  jnz 0x00007B2719BD477B
00007b2719bd2e44  vmovaps xmm13, [rsp+0xD0]
00007b2719bd2e4d  vpermilpd xmm13, xmm13, 0x00
00007b2719bd2e53  movaps xmm10, xmm15
00007b2719bd2e57  vfmadd231pd xmm10, xmm1, xmm13
00007b2719bd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007b2719bd2e62  vptest xmm9, xmm9
00007b2719bd2e67  jnz 0x00007B2719BD48D5
00007b2719bd2e6d  vmovaps [rsp+0x10], xmm7
00007b2719bd2e73  vmovaps xmm1, [rsp+0x10]
00007b2719bd2e79  por xmm7, xmm1
00007b2719bd2e7d  movaps [r15+0x160], xmm7
00007b2719bd2e85  lea rax, [r14+0x40]
00007b2719bd2e89  movups xmm1, [r13+rax*1]
00007b2719bd2e8f  lea rax, [r14+0x50]
00007b2719bd2e93  movups xmm15, [r13+rax*1]
00007b2719bd2e99  movaps [r15+0x1B0], xmm1
00007b2719bd2ea1  movaps [r15+0x1A0], xmm15
00007b2719bd2ea9  vmovaps xmm13, [rsp+0xA0]
00007b2719bd2eb2  vpermilpd xmm13, xmm13, 0x00
00007b2719bd2eb8  vmovaps xmm9, [rsp+0x40]
00007b2719bd2ebe  movaps xmm8, xmm5
00007b2719bd2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007b2719bd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007b2719bd2ecd  vptest xmm3, xmm3
00007b2719bd2ed2  jnz 0x00007B2719BD4A42
00007b2719bd2ed8  vmovaps xmm13, [rsp+0xA0]
00007b2719bd2ee1  vpermilpd xmm13, xmm13, 0x00
00007b2719bd2ee7  movaps xmm9, xmm12
00007b2719bd2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007b2719bd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007b2719bd2ef6  vptest xmm5, xmm5
00007b2719bd2efb  jnz 0x00007B2719BD4B9B
00007b2719bd2f01  vmovaps xmm13, [rsp+0xA0]
00007b2719bd2f0a  vpermilpd xmm13, xmm13, 0x00
00007b2719bd2f10  movaps xmm12, xmm11
00007b2719bd2f14  vfmadd231pd xmm12, xmm6, xmm13
00007b2719bd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007b2719bd2f1f  vptest xmm7, xmm7
00007b2719bd2f24  jnz 0x00007B2719BD4CF4
00007b2719bd2f2a  vmovaps xmm13, [rsp+0xA0]
00007b2719bd2f33  vpermilpd xmm13, xmm13, 0x00
00007b2719bd2f39  vmovaps xmm11, [rsp+0x50]
00007b2719bd2f3f  movaps xmm7, xmm10
00007b2719bd2f43  vfmadd231pd xmm7, xmm11, xmm13
00007b2719bd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007b2719bd2f4d  vptest xmm6, xmm6
00007b2719bd2f52  jnz 0x00007B2719BD4E4D
00007b2719bd2f58  lea rax, [r14+0x60]
00007b2719bd2f5c  movups xmm13, [r13+rax*1]
00007b2719bd2f62  lea rax, [r14+0x70]
00007b2719bd2f66  movups xmm11, [r13+rax*1]
00007b2719bd2f6c  movaps [r15+0x150], xmm13
00007b2719bd2f74  movaps [r15+0x120], xmm11
00007b2719bd2f7c  vmovaps xmm10, [rsp+0xC0]
00007b2719bd2f85  vpermilpd xmm10, xmm10, 0x00
00007b2719bd2f8b  movaps xmm6, xmm8
00007b2719bd2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007b2719bd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007b2719bd2f99  vptest xmm5, xmm5
00007b2719bd2f9e  jnz 0x00007B2719BD4FB9
00007b2719bd2fa4  vmovaps xmm15, [rsp+0xC0]
00007b2719bd2fad  vpermilpd xmm15, xmm15, 0x00
00007b2719bd2fb3  movaps xmm10, xmm9
00007b2719bd2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007b2719bd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007b2719bd2fc2  vptest xmm8, xmm8
00007b2719bd2fc7  jnz 0x00007B2719BD5111
00007b2719bd2fcd  vmovaps xmm15, [rsp+0xC0]
00007b2719bd2fd6  vpermilpd xmm15, xmm15, 0x00
00007b2719bd2fdc  movaps xmm13, xmm12
00007b2719bd2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007b2719bd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007b2719bd2feb  vptest xmm9, xmm9
00007b2719bd2ff0  jnz 0x00007B2719BD526B
00007b2719bd2ff6  vmovaps xmm15, [rsp+0xC0]
00007b2719bd2fff  vpermilpd xmm15, xmm15, 0x00
00007b2719bd3005  movaps xmm12, xmm7
00007b2719bd3009  vfmadd231pd xmm12, xmm1, xmm15
00007b2719bd300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007b2719bd3014  vptest xmm9, xmm9
00007b2719bd3019  jnz 0x00007B2719BD53C4
00007b2719bd301f  lea rax, [r14+0x20]
00007b2719bd3023  movups xmm1, [r13+rax*1]
00007b2719bd3029  lea rax, [r14+0x30]
00007b2719bd302d  movups xmm15, [r13+rax*1]
00007b2719bd3033  vmovaps xmm9, [rsp+0x70]
00007b2719bd3039  vpermilpd xmm9, xmm9, 0x00
00007b2719bd303f  vmovaps xmm8, [rsp+0x20]
00007b2719bd3045  movaps xmm7, xmm6
00007b2719bd3048  vfmadd231pd xmm7, xmm8, xmm9
00007b2719bd304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007b2719bd3052  vptest xmm5, xmm5
00007b2719bd3057  jnz 0x00007B2719BD5530
00007b2719bd305d  vmovaps xmm9, [rsp+0x70]
00007b2719bd3063  vpermilpd xmm9, xmm9, 0x00
00007b2719bd3069  movaps xmm8, xmm10
00007b2719bd306d  vfmadd231pd xmm8, xmm14, xmm9
00007b2719bd3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007b2719bd3078  vptest xmm6, xmm6
00007b2719bd307d  jnz 0x00007B2719BD5687
00007b2719bd3083  vmovaps xmm14, [rsp+0x70]
00007b2719bd3089  vpermilpd xmm14, xmm14, 0x00
00007b2719bd308f  movaps xmm10, xmm13
00007b2719bd3093  vfmadd231pd xmm10, xmm11, xmm14
00007b2719bd3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007b2719bd309e  vptest xmm9, xmm9
00007b2719bd30a3  jnz 0x00007B2719BD57E1
00007b2719bd30a9  vmovaps xmm14, [rsp+0x70]
00007b2719bd30af  vpermilpd xmm14, xmm14, 0x00
00007b2719bd30b5  movaps xmm13, xmm12
00007b2719bd30b9  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007b2719bd30c4  vptest xmm11, xmm11
00007b2719bd30c9  jnz 0x00007B2719BD593B
00007b2719bd30cf  lea rax, [r14+0x90]
00007b2719bd30d6  movups xmm15, [r13+rax*1]
00007b2719bd30dc  lea rax, [r14+0xA0]
00007b2719bd30e3  movups xmm14, [r13+rax*1]
00007b2719bd30e9  movaps [r15+0x140], xmm15
00007b2719bd30f1  movaps [r15+0x130], xmm14
00007b2719bd30f9  vmovaps xmm12, [rsp+0x90]
00007b2719bd3102  vpermilpd xmm12, xmm12, 0x00
00007b2719bd3108  movaps xmm11, xmm7
00007b2719bd310c  vfmadd231pd xmm11, xmm1, xmm12
00007b2719bd3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007b2719bd3117  vptest xmm9, xmm9
00007b2719bd311c  jnz 0x00007B2719BD5AA9
00007b2719bd3122  movaps [r15+0x220], xmm11
00007b2719bd312a  lea rax, [r14+0x10]
00007b2719bd312e  movups xmm1, [r13+rax*1]
00007b2719bd3134  movaps [r15+0x240], xmm1
00007b2719bd313c  vmovaps xmm12, [rsp+0x90]
00007b2719bd3145  vpermilpd xmm12, xmm12, 0x00
00007b2719bd314b  movaps xmm9, xmm8
00007b2719bd314f  vfmadd231pd xmm9, xmm14, xmm12
00007b2719bd3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007b2719bd315a  vptest xmm7, xmm7
00007b2719bd315f  jnz 0x00007B2719BD5C0B
00007b2719bd3165  movaps [r15+0x110], xmm9
00007b2719bd316d  vmovaps xmm14, [rsp+0x90]
00007b2719bd3176  vpermilpd xmm14, xmm14, 0x00
00007b2719bd317c  movaps xmm12, xmm10
00007b2719bd3180  vfmadd231pd xmm12, xmm15, xmm14
00007b2719bd3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007b2719bd318b  vptest xmm8, xmm8
00007b2719bd3190  jnz 0x00007B2719BD5D65
00007b2719bd3196  movaps [r15+0x170], xmm12
00007b2719bd319e  vmovaps xmm15, [rsp+0x90]
00007b2719bd31a7  vpermilpd xmm15, xmm15, 0x00
00007b2719bd31ad  movaps xmm14, xmm13
00007b2719bd31b1  vfmadd231pd xmm14, xmm1, xmm15
00007b2719bd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007b2719bd31bc  vptest xmm10, xmm10
00007b2719bd31c1  jnz 0x00007B2719BD5EBF
00007b2719bd31c7  movaps [r15+0x230], xmm14
00007b2719bd31cf  mov eax, 0x432190
00007b2719bd31d4  movups [r13+rax*1], xmm9
00007b2719bd31da  mov eax, 0x4321A0
00007b2719bd31df  movups [r13+rax*1], xmm12
00007b2719bd31e5  mov eax, 0x4321B0
00007b2719bd31ea  movups [r13+rax*1], xmm11
00007b2719bd31f0  mov eax, 0x4321C0
00007b2719bd31f5  movups [r13+rax*1], xmm14
00007b2719bd31fb  mov eax, [r15+0x108]
00007b2719bd3202  sahf
00007b2719bd3203  jnz 0x00007B2719BD3235
00007b2719bd3205  cmp dword ptr [r15+0x318], 0x00
00007b2719bd320d  jz 0x00007B2719BD9950
00007b2719bd3213  nop [rax+rax*1], ax
00007b2719bd321c  nop [rax+rax*1], eax
00007b2719bd3224  mov eax, 0x410664
00007b2719bd3229  mov [r15+0x100], rax
00007b2719bd3230  jmp 0x00007B27199FE110
00007b2719bd3235  cmp dword ptr [r15+0x318], 0x00
00007b2719bd323d  jz 0x00007B2719BD6050
00007b2719bd3243  nop [rax+rax*1], ax
00007b2719bd324c  nop [rax+rax*1], eax
00007b2719bd3254  mov eax, 0x4104F0
00007b2719bd3259  mov [r15+0x100], rax
00007b2719bd3260  jmp 0x00007B27199FE110
00007b2719bd3265  int3
00007b2719bd3266  call 0x00007B27199FF430
00007b2719bd326b  jmp 0x00007B2719BD230A
00007b2719bd3270  call 0x00007B2719AE5820
00007b2719bd3275  jmp 0x00007B2719BD2314
00007b2719bd327a  call 0x00007B2719AE45A0
00007b2719bd327f  jmp 0x00007B2719BD2326
00007b2719bd3284  call 0x00007B2719AE3320
00007b2719bd3289  jmp 0x00007B2719BD2330
00007b2719bd328e  call 0x00007B2719AE20A0
00007b2719bd3293  jmp 0x00007B2719BD233D
00007b2719bd3298  call 0x00007B2719AE0E30
00007b2719bd329d  jmp 0x00007B2719BD234A
00007b2719bd32a2  call 0x00007B2719AD6600
00007b2719bd32a7  jmp 0x00007B2719BD2357
00007b2719bd32ac  call 0x00007B2719AB52F0
00007b2719bd32b1  jmp 0x00007B2719BD2361
00007b2719bd32b6  call 0x00007B2719ABE9C0
00007b2719bd32bb  jmp 0x00007B2719BD236B
00007b2719bd32c0  call 0x00007B2719ABD750
00007b2719bd32c5  jmp 0x00007B2719BD2378
00007b2719bd32ca  call 0x00007B2719ABC4E0
00007b2719bd32cf  jmp 0x00007B2719BD2385
00007b2719bd32d4  call 0x00007B2719ABB270
00007b2719bd32d9  jmp 0x00007B2719BD2392
00007b2719bd32de  call 0x00007B2719ABA000
00007b2719bd32e3  jmp 0x00007B2719BD239F
00007b2719bd32e8  call 0x00007B2719AB8D90
00007b2719bd32ed  jmp 0x00007B2719BD23AC
00007b2719bd32f2  call 0x00007B2719AB8A20
00007b2719bd32f7  jmp 0x00007B2719BD23B9
00007b2719bd32fc  call 0x00007B2719ABEAE0
00007b2719bd3301  jmp 0x00007B2719BD23C6
00007b2719bd3306  call 0x00007B2719AB5400
00007b2719bd330b  jmp 0x00007B2719BD23D3
00007b2719bd3310  call 0x00007B2719AB52F0
00007b2719bd3315  jmp 0x00007B2719BD23E0
00007b2719bd331a  call 0x00007B2719ABE9C0
00007b2719bd331f  jmp 0x00007B2719BD23ED
00007b2719bd3324  call 0x00007B2719AB77B0
00007b2719bd3329  jmp 0x00007B2719BD23FA
00007b2719bd332e  call 0x00007B2719AB6550
00007b2719bd3333  jmp 0x00007B2719BD2407
00007b2719bd3338  call 0x00007B2719AB52F0
00007b2719bd333d  jmp 0x00007B2719BD2417
00007b2719bd3342  call 0x00007B2719AB52F0
00007b2719bd3347  jmp 0x00007B2719BD2427
00007b2719bd334c  call 0x00007B2719ABEAE0
00007b2719bd3351  jmp 0x00007B2719BD2431
00007b2719bd3356  call 0x00007B2719ABEAE0
00007b2719bd335b  jmp 0x00007B2719BD2444
00007b2719bd3360  call 0x00007B2719ABE9C0
00007b2719bd3365  jmp 0x00007B2719BD2451
00007b2719bd336a  call 0x00007B2719AB52F0
00007b2719bd336f  jmp 0x00007B2719BD2464
00007b2719bd3374  call 0x00007B2719AB6660
00007b2719bd3379  jmp 0x00007B2719BD2471
00007b2719bd337e  call 0x00007B2719AB78C0
00007b2719bd3383  jmp 0x00007B2719BD247E
00007b2719bd3388  call 0x00007B2719AB77B0
00007b2719bd338d  jmp 0x00007B2719BD248B
00007b2719bd3392  call 0x00007B2719AB6550
00007b2719bd3397  jmp 0x00007B2719BD2498
00007b2719bd339c  call 0x00007B2719AB52F0
00007b2719bd33a1  jmp 0x00007B2719BD24AB
00007b2719bd33a6  call 0x00007B2719AB52F0
00007b2719bd33ab  jmp 0x00007B2719BD24BE
00007b2719bd33b0  call 0x00007B2719AB52F0
00007b2719bd33b5  jmp 0x00007B2719BD24E5
00007b2719bd33ba  call 0x00007B2719AB52F0
00007b2719bd33bf  jmp 0x00007B2719BD24F8
00007b2719bd33c4  call 0x00007B2719AB52F0
00007b2719bd33c9  jmp 0x00007B2719BD250B
00007b2719bd33ce  call 0x00007B2719AB52F0
00007b2719bd33d3  jmp 0x00007B2719BD2521
00007b2719bd33d8  call 0x00007B2719AB52F0
00007b2719bd33dd  jmp 0x00007B2719BD2537
00007b2719bd33e2  call 0x00007B2719AB52F0
00007b2719bd33e7  jmp 0x00007B2719BD254D
00007b2719bd33ec  call 0x00007B27199FF540
00007b2719bd33f1  jmp 0x00007B2719BD256E
00007b2719bd33f6  call 0x00007B2719A02FE0
00007b2719bd33fb  jmp 0x00007B2719BD2578
00007b2719bd3400  call 0x00007B27199FF540
00007b2719bd3405  jmp 0x00007B2719BD2588
00007b2719bd340a  call 0x00007B27199FF540
00007b2719bd340f  jmp 0x00007B2719BD259B
00007b2719bd3414  call 0x00007B27199FF540
00007b2719bd3419  jmp 0x00007B2719BD25AE
00007b2719bd341e  call 0x00007B27199FF540
00007b2719bd3423  jmp 0x00007B2719BD25C1
00007b2719bd3428  call 0x00007B2719AC0370
00007b2719bd342d  jmp 0x00007B2719BD25E0
00007b2719bd3432  call 0x00007B2719ABF100
00007b2719bd3437  jmp 0x00007B2719BD25E9
00007b2719bd343c  call 0x00007B2719AC0370
00007b2719bd3441  jmp 0x00007B2719BD2659
00007b2719bd3446  call 0x00007B2719ABF100
00007b2719bd344b  jmp 0x00007B2719BD2662
00007b2719bd3450  call 0x00007B2719AC0370
00007b2719bd3455  jmp 0x00007B2719BD270C
00007b2719bd345a  call 0x00007B2719ABF100
00007b2719bd345f  jmp 0x00007B2719BD2715
00007b2719bd3464  call 0x00007B2719A0B720
00007b2719bd3469  jmp 0x00007B2719BD27F7
00007b2719bd346e  call 0x00007B2719AD64F0
00007b2719bd3473  jmp 0x00007B2719BD281F
00007b2719bd3478  call 0x00007B2719AB47C0
00007b2719bd347d  jmp 0x00007B2719BD283A
00007b2719bd3482  sub rsp, 0x08
00007b2719bd3486  push rax
00007b2719bd3487  push rcx
00007b2719bd3488  push rdx
00007b2719bd3489  push rdi
00007b2719bd348a  push rsi
00007b2719bd348b  push r8
00007b2719bd348d  push r9
00007b2719bd348f  push r10
00007b2719bd3491  push r11
00007b2719bd3493  sub rsp, 0xF0
00007b2719bd349a  vmovaps [rsp], xmm0
00007b2719bd349f  vmovaps [rsp+0x10], xmm1
00007b2719bd34a5  vmovaps [rsp+0x20], xmm2
00007b2719bd34ab  vmovaps [rsp+0x30], xmm3
00007b2719bd34b1  vmovaps [rsp+0x40], xmm4
00007b2719bd34b7  vmovaps [rsp+0x50], xmm5
00007b2719bd34bd  vmovaps [rsp+0x60], xmm6
00007b2719bd34c3  vmovaps [rsp+0x70], xmm7
00007b2719bd34c9  vmovaps [rsp+0x80], xmm8
00007b2719bd34d2  vmovaps [rsp+0x90], xmm9
00007b2719bd34db  vmovaps [rsp+0xA0], xmm10
00007b2719bd34e4  vmovaps [rsp+0xB0], xmm11
00007b2719bd34ed  vmovaps [rsp+0xC0], xmm12
00007b2719bd34f6  vmovaps [rsp+0xD0], xmm14
00007b2719bd34ff  vmovaps [rsp+0xE0], xmm15
00007b2719bd3508  sub rsp, 0x40
00007b2719bd350c  lea rdi, [rsp]
00007b2719bd3510  lea rsi, [rsp+0x10]
00007b2719bd3515  lea rdx, [rsp+0x20]
00007b2719bd351a  lea rcx, [rsp+0x30]
00007b2719bd351f  mov r8d, 0x00
00007b2719bd3525  lea r9, [r15+0x3A8]
00007b2719bd352c  movaps [rdi], xmm13
00007b2719bd3530  movaps [rsi], xmm1
00007b2719bd3533  movaps [rdx], xmm15
00007b2719bd3537  movaps [rcx], xmm14
00007b2719bd353b  mov rax, 0x5A8E6560CA50
00007b2719bd3545  call rax
00007b2719bd3547  movaps xmm13, [rsp]
00007b2719bd354c  add rsp, 0x40
00007b2719bd3550  vmovaps xmm0, [rsp]
00007b2719bd3555  vmovaps xmm1, [rsp+0x10]
00007b2719bd355b  vmovaps xmm2, [rsp+0x20]
00007b2719bd3561  vmovaps xmm3, [rsp+0x30]
00007b2719bd3567  vmovaps xmm4, [rsp+0x40]
00007b2719bd356d  vmovaps xmm5, [rsp+0x50]
00007b2719bd3573  vmovaps xmm6, [rsp+0x60]
00007b2719bd3579  vmovaps xmm7, [rsp+0x70]
00007b2719bd357f  vmovaps xmm8, [rsp+0x80]
00007b2719bd3588  vmovaps xmm9, [rsp+0x90]
00007b2719bd3591  vmovaps xmm10, [rsp+0xA0]
00007b2719bd359a  vmovaps xmm11, [rsp+0xB0]
00007b2719bd35a3  vmovaps xmm12, [rsp+0xC0]
00007b2719bd35ac  vmovaps xmm14, [rsp+0xD0]
00007b2719bd35b5  vmovaps xmm15, [rsp+0xE0]
00007b2719bd35be  add rsp, 0xF0
00007b2719bd35c5  pop r11
00007b2719bd35c7  pop r10
00007b2719bd35c9  pop r9
00007b2719bd35cb  pop r8
00007b2719bd35cd  pop rsi
00007b2719bd35ce  pop rdi
00007b2719bd35cf  pop rdx
00007b2719bd35d0  pop rcx
00007b2719bd35d1  pop rax
00007b2719bd35d2  add rsp, 0x08
00007b2719bd35d6  jmp 0x00007B2719BD28AD
00007b2719bd35db  sub rsp, 0x08
00007b2719bd35df  push rax
00007b2719bd35e0  push rcx
00007b2719bd35e1  push rdx
00007b2719bd35e2  push rdi
00007b2719bd35e3  push rsi
00007b2719bd35e4  push r8
00007b2719bd35e6  push r9
00007b2719bd35e8  push r10
00007b2719bd35ea  push r11
00007b2719bd35ec  sub rsp, 0xF0
00007b2719bd35f3  vmovaps [rsp], xmm0
00007b2719bd35f8  vmovaps [rsp+0x10], xmm1
00007b2719bd35fe  vmovaps [rsp+0x20], xmm2
00007b2719bd3604  vmovaps [rsp+0x30], xmm3
00007b2719bd360a  vmovaps [rsp+0x40], xmm4
00007b2719bd3610  vmovaps [rsp+0x50], xmm5
00007b2719bd3616  vmovaps [rsp+0x60], xmm6
00007b2719bd361c  vmovaps [rsp+0x70], xmm7
00007b2719bd3622  vmovaps [rsp+0x80], xmm8
00007b2719bd362b  vmovaps [rsp+0x90], xmm9
00007b2719bd3634  vmovaps [rsp+0xA0], xmm10
00007b2719bd363d  vmovaps [rsp+0xB0], xmm11
00007b2719bd3646  vmovaps [rsp+0xC0], xmm12
00007b2719bd364f  vmovaps [rsp+0xD0], xmm13
00007b2719bd3658  vmovaps [rsp+0xE0], xmm14
00007b2719bd3661  sub rsp, 0x40
00007b2719bd3665  lea rdi, [rsp]
00007b2719bd3669  lea rsi, [rsp+0x10]
00007b2719bd366e  lea rdx, [rsp+0x20]
00007b2719bd3673  lea rcx, [rsp+0x30]
00007b2719bd3678  mov r8d, 0x00
00007b2719bd367e  lea r9, [r15+0x3A8]
00007b2719bd3685  movaps [rdi], xmm15
00007b2719bd3689  movaps [rsi], xmm5
00007b2719bd368c  movaps [rdx], xmm1
00007b2719bd368f  movaps [rcx], xmm14
00007b2719bd3693  mov rax, 0x5A8E6560CA50
00007b2719bd369d  call rax
00007b2719bd369f  movaps xmm15, [rsp]
00007b2719bd36a4  add rsp, 0x40
00007b2719bd36a8  vmovaps xmm0, [rsp]
00007b2719bd36ad  vmovaps xmm1, [rsp+0x10]
00007b2719bd36b3  vmovaps xmm2, [rsp+0x20]
00007b2719bd36b9  vmovaps xmm3, [rsp+0x30]
00007b2719bd36bf  vmovaps xmm4, [rsp+0x40]
00007b2719bd36c5  vmovaps xmm5, [rsp+0x50]
00007b2719bd36cb  vmovaps xmm6, [rsp+0x60]
00007b2719bd36d1  vmovaps xmm7, [rsp+0x70]
00007b2719bd36d7  vmovaps xmm8, [rsp+0x80]
00007b2719bd36e0  vmovaps xmm9, [rsp+0x90]
00007b2719bd36e9  vmovaps xmm10, [rsp+0xA0]
00007b2719bd36f2  vmovaps xmm11, [rsp+0xB0]
00007b2719bd36fb  vmovaps xmm12, [rsp+0xC0]
00007b2719bd3704  vmovaps xmm13, [rsp+0xD0]
00007b2719bd370d  vmovaps xmm14, [rsp+0xE0]
00007b2719bd3716  add rsp, 0xF0
00007b2719bd371d  pop r11
00007b2719bd371f  pop r10
00007b2719bd3721  pop r9
00007b2719bd3723  pop r8
00007b2719bd3725  pop rsi
00007b2719bd3726  pop rdi
00007b2719bd3727  pop rdx
00007b2719bd3728  pop rcx
00007b2719bd3729  pop rax
00007b2719bd372a  add rsp, 0x08
00007b2719bd372e  jmp 0x00007B2719BD28D0
00007b2719bd3733  call 0x00007B27199FF430
00007b2719bd3738  jmp 0x00007B2719BD295D
00007b2719bd373d  sub rsp, 0x08
00007b2719bd3741  push rax
00007b2719bd3742  push rcx
00007b2719bd3743  push rdx
00007b2719bd3744  push rdi
00007b2719bd3745  push rsi
00007b2719bd3746  push r8
00007b2719bd3748  push r9
00007b2719bd374a  push r10
00007b2719bd374c  push r11
00007b2719bd374e  sub rsp, 0xF0
00007b2719bd3755  vmovaps [rsp], xmm0
00007b2719bd375a  vmovaps [rsp+0x10], xmm1
00007b2719bd3760  vmovaps [rsp+0x20], xmm2
00007b2719bd3766  vmovaps [rsp+0x30], xmm3
00007b2719bd376c  vmovaps [rsp+0x40], xmm4
00007b2719bd3772  vmovaps [rsp+0x50], xmm5
00007b2719bd3778  vmovaps [rsp+0x60], xmm6
00007b2719bd377e  vmovaps [rsp+0x70], xmm7
00007b2719bd3784  vmovaps [rsp+0x80], xmm8
00007b2719bd378d  vmovaps [rsp+0x90], xmm9
00007b2719bd3796  vmovaps [rsp+0xA0], xmm10
00007b2719bd379f  vmovaps [rsp+0xB0], xmm11
00007b2719bd37a8  vmovaps [rsp+0xC0], xmm12
00007b2719bd37b1  vmovaps [rsp+0xD0], xmm14
00007b2719bd37ba  vmovaps [rsp+0xE0], xmm15
00007b2719bd37c3  sub rsp, 0x40
00007b2719bd37c7  lea rdi, [rsp]
00007b2719bd37cb  lea rsi, [rsp+0x10]
00007b2719bd37d0  lea rdx, [rsp+0x20]
00007b2719bd37d5  lea rcx, [rsp+0x30]
00007b2719bd37da  mov r8d, 0x00
00007b2719bd37e0  lea r9, [r15+0x3A8]
00007b2719bd37e7  movaps [rdi], xmm13
00007b2719bd37eb  movaps [rsi], xmm1
00007b2719bd37ee  movaps [rdx], xmm15
00007b2719bd37f2  movaps [rcx], xmm14
00007b2719bd37f6  mov rax, 0x5A8E6560CA50
00007b2719bd3800  call rax
00007b2719bd3802  movaps xmm13, [rsp]
00007b2719bd3807  add rsp, 0x40
00007b2719bd380b  vmovaps xmm0, [rsp]
00007b2719bd3810  vmovaps xmm1, [rsp+0x10]
00007b2719bd3816  vmovaps xmm2, [rsp+0x20]
00007b2719bd381c  vmovaps xmm3, [rsp+0x30]
00007b2719bd3822  vmovaps xmm4, [rsp+0x40]
00007b2719bd3828  vmovaps xmm5, [rsp+0x50]
00007b2719bd382e  vmovaps xmm6, [rsp+0x60]
00007b2719bd3834  vmovaps xmm7, [rsp+0x70]
00007b2719bd383a  vmovaps xmm8, [rsp+0x80]
00007b2719bd3843  vmovaps xmm9, [rsp+0x90]
00007b2719bd384c  vmovaps xmm10, [rsp+0xA0]
00007b2719bd3855  vmovaps xmm11, [rsp+0xB0]
00007b2719bd385e  vmovaps xmm12, [rsp+0xC0]
00007b2719bd3867  vmovaps xmm14, [rsp+0xD0]
00007b2719bd3870  vmovaps xmm15, [rsp+0xE0]
00007b2719bd3879  add rsp, 0xF0
00007b2719bd3880  pop r11
00007b2719bd3882  pop r10
00007b2719bd3884  pop r9
00007b2719bd3886  pop r8
00007b2719bd3888  pop rsi
00007b2719bd3889  pop rdi
00007b2719bd388a  pop rdx
00007b2719bd388b  pop rcx
00007b2719bd388c  pop rax
00007b2719bd388d  add rsp, 0x08
00007b2719bd3891  jmp 0x00007B2719BD29C1
00007b2719bd3896  call 0x00007B27199FF430
00007b2719bd389b  jmp 0x00007B2719BD29CE
00007b2719bd38a0  sub rsp, 0x08
00007b2719bd38a4  push rax
00007b2719bd38a5  push rcx
00007b2719bd38a6  push rdx
00007b2719bd38a7  push rdi
00007b2719bd38a8  push rsi
00007b2719bd38a9  push r8
00007b2719bd38ab  push r9
00007b2719bd38ad  push r10
00007b2719bd38af  push r11
00007b2719bd38b1  sub rsp, 0xF0
00007b2719bd38b8  vmovaps [rsp], xmm0
00007b2719bd38bd  vmovaps [rsp+0x10], xmm1
00007b2719bd38c3  vmovaps [rsp+0x20], xmm2
00007b2719bd38c9  vmovaps [rsp+0x30], xmm3
00007b2719bd38cf  vmovaps [rsp+0x40], xmm4
00007b2719bd38d5  vmovaps [rsp+0x50], xmm5
00007b2719bd38db  vmovaps [rsp+0x60], xmm6
00007b2719bd38e1  vmovaps [rsp+0x70], xmm7
00007b2719bd38e7  vmovaps [rsp+0x80], xmm8
00007b2719bd38f0  vmovaps [rsp+0x90], xmm9
00007b2719bd38f9  vmovaps [rsp+0xA0], xmm10
00007b2719bd3902  vmovaps [rsp+0xB0], xmm11
00007b2719bd390b  vmovaps [rsp+0xC0], xmm13
00007b2719bd3914  vmovaps [rsp+0xD0], xmm14
00007b2719bd391d  vmovaps [rsp+0xE0], xmm15
00007b2719bd3926  sub rsp, 0x40
00007b2719bd392a  lea rdi, [rsp]
00007b2719bd392e  lea rsi, [rsp+0x10]
00007b2719bd3933  lea rdx, [rsp+0x20]
00007b2719bd3938  lea rcx, [rsp+0x30]
00007b2719bd393d  mov r8d, 0x00
00007b2719bd3943  lea r9, [r15+0x3A8]
00007b2719bd394a  movaps [rdi], xmm12
00007b2719bd394e  movaps [rsi], xmm15
00007b2719bd3952  movaps [rdx], xmm1
00007b2719bd3955  movaps [rcx], xmm14
00007b2719bd3959  mov rax, 0x5A8E6560CA50
00007b2719bd3963  call rax
00007b2719bd3965  movaps xmm12, [rsp]
00007b2719bd396a  add rsp, 0x40
00007b2719bd396e  vmovaps xmm0, [rsp]
00007b2719bd3973  vmovaps xmm1, [rsp+0x10]
00007b2719bd3979  vmovaps xmm2, [rsp+0x20]
00007b2719bd397f  vmovaps xmm3, [rsp+0x30]
00007b2719bd3985  vmovaps xmm4, [rsp+0x40]
00007b2719bd398b  vmovaps xmm5, [rsp+0x50]
00007b2719bd3991  vmovaps xmm6, [rsp+0x60]
00007b2719bd3997  vmovaps xmm7, [rsp+0x70]
00007b2719bd399d  vmovaps xmm8, [rsp+0x80]
00007b2719bd39a6  vmovaps xmm9, [rsp+0x90]
00007b2719bd39af  vmovaps xmm10, [rsp+0xA0]
00007b2719bd39b8  vmovaps xmm11, [rsp+0xB0]
00007b2719bd39c1  vmovaps xmm13, [rsp+0xC0]
00007b2719bd39ca  vmovaps xmm14, [rsp+0xD0]
00007b2719bd39d3  vmovaps xmm15, [rsp+0xE0]
00007b2719bd39dc  add rsp, 0xF0
00007b2719bd39e3  pop r11
00007b2719bd39e5  pop r10
00007b2719bd39e7  pop r9
00007b2719bd39e9  pop r8
00007b2719bd39eb  pop rsi
00007b2719bd39ec  pop rdi
00007b2719bd39ed  pop rdx
00007b2719bd39ee  pop rcx
00007b2719bd39ef  pop rax
00007b2719bd39f0  add rsp, 0x08
00007b2719bd39f4  jmp 0x00007B2719BD29FA
00007b2719bd39f9  sub rsp, 0x08
00007b2719bd39fd  push rax
00007b2719bd39fe  push rcx
00007b2719bd39ff  push rdx
00007b2719bd3a00  push rdi
00007b2719bd3a01  push rsi
00007b2719bd3a02  push r8
00007b2719bd3a04  push r9
00007b2719bd3a06  push r10
00007b2719bd3a08  push r11
00007b2719bd3a0a  sub rsp, 0xF0
00007b2719bd3a11  vmovaps [rsp], xmm0
00007b2719bd3a16  vmovaps [rsp+0x10], xmm1
00007b2719bd3a1c  vmovaps [rsp+0x20], xmm2
00007b2719bd3a22  vmovaps [rsp+0x30], xmm3
00007b2719bd3a28  vmovaps [rsp+0x40], xmm4
00007b2719bd3a2e  vmovaps [rsp+0x50], xmm5
00007b2719bd3a34  vmovaps [rsp+0x60], xmm6
00007b2719bd3a3a  vmovaps [rsp+0x70], xmm7
00007b2719bd3a40  vmovaps [rsp+0x80], xmm8
00007b2719bd3a49  vmovaps [rsp+0x90], xmm9
00007b2719bd3a52  vmovaps [rsp+0xA0], xmm10
00007b2719bd3a5b  vmovaps [rsp+0xB0], xmm11
00007b2719bd3a64  vmovaps [rsp+0xC0], xmm12
00007b2719bd3a6d  vmovaps [rsp+0xD0], xmm14
00007b2719bd3a76  vmovaps [rsp+0xE0], xmm15
00007b2719bd3a7f  sub rsp, 0x40
00007b2719bd3a83  lea rdi, [rsp]
00007b2719bd3a87  lea rsi, [rsp+0x10]
00007b2719bd3a8c  lea rdx, [rsp+0x20]
00007b2719bd3a91  lea rcx, [rsp+0x30]
00007b2719bd3a96  mov r8d, 0x00
00007b2719bd3a9c  lea r9, [r15+0x3A8]
00007b2719bd3aa3  movaps [rdi], xmm13
00007b2719bd3aa7  movaps [rsi], xmm1
00007b2719bd3aaa  movaps [rdx], xmm15
00007b2719bd3aae  movaps [rcx], xmm14
00007b2719bd3ab2  mov rax, 0x5A8E6560CA50
00007b2719bd3abc  call rax
00007b2719bd3abe  movaps xmm13, [rsp]
00007b2719bd3ac3  add rsp, 0x40
00007b2719bd3ac7  vmovaps xmm0, [rsp]
00007b2719bd3acc  vmovaps xmm1, [rsp+0x10]
00007b2719bd3ad2  vmovaps xmm2, [rsp+0x20]
00007b2719bd3ad8  vmovaps xmm3, [rsp+0x30]
00007b2719bd3ade  vmovaps xmm4, [rsp+0x40]
00007b2719bd3ae4  vmovaps xmm5, [rsp+0x50]
00007b2719bd3aea  vmovaps xmm6, [rsp+0x60]
00007b2719bd3af0  vmovaps xmm7, [rsp+0x70]
00007b2719bd3af6  vmovaps xmm8, [rsp+0x80]
00007b2719bd3aff  vmovaps xmm9, [rsp+0x90]
00007b2719bd3b08  vmovaps xmm10, [rsp+0xA0]
00007b2719bd3b11  vmovaps xmm11, [rsp+0xB0]
00007b2719bd3b1a  vmovaps xmm12, [rsp+0xC0]
00007b2719bd3b23  vmovaps xmm14, [rsp+0xD0]
00007b2719bd3b2c  vmovaps xmm15, [rsp+0xE0]
00007b2719bd3b35  add rsp, 0xF0
00007b2719bd3b3c  pop r11
00007b2719bd3b3e  pop r10
00007b2719bd3b40  pop r9
00007b2719bd3b42  pop r8
00007b2719bd3b44  pop rsi
00007b2719bd3b45  pop rdi
00007b2719bd3b46  pop rdx
00007b2719bd3b47  pop rcx
00007b2719bd3b48  pop rax
00007b2719bd3b49  add rsp, 0x08
00007b2719bd3b4d  jmp 0x00007B2719BD2B77
00007b2719bd3b52  sub rsp, 0x08
00007b2719bd3b56  push rax
00007b2719bd3b57  push rcx
00007b2719bd3b58  push rdx
00007b2719bd3b59  push rdi
00007b2719bd3b5a  push rsi
00007b2719bd3b5b  push r8
00007b2719bd3b5d  push r9
00007b2719bd3b5f  push r10
00007b2719bd3b61  push r11
00007b2719bd3b63  sub rsp, 0xF0
00007b2719bd3b6a  vmovaps [rsp], xmm0
00007b2719bd3b6f  vmovaps [rsp+0x10], xmm1
00007b2719bd3b75  vmovaps [rsp+0x20], xmm2
00007b2719bd3b7b  vmovaps [rsp+0x30], xmm3
00007b2719bd3b81  vmovaps [rsp+0x40], xmm4
00007b2719bd3b87  vmovaps [rsp+0x50], xmm5
00007b2719bd3b8d  vmovaps [rsp+0x60], xmm6
00007b2719bd3b93  vmovaps [rsp+0x70], xmm7
00007b2719bd3b99  vmovaps [rsp+0x80], xmm8
00007b2719bd3ba2  vmovaps [rsp+0x90], xmm9
00007b2719bd3bab  vmovaps [rsp+0xA0], xmm10
00007b2719bd3bb4  vmovaps [rsp+0xB0], xmm11
00007b2719bd3bbd  vmovaps [rsp+0xC0], xmm13
00007b2719bd3bc6  vmovaps [rsp+0xD0], xmm14
00007b2719bd3bcf  vmovaps [rsp+0xE0], xmm15
00007b2719bd3bd8  sub rsp, 0x40
00007b2719bd3bdc  lea rdi, [rsp]
00007b2719bd3be0  lea rsi, [rsp+0x10]
00007b2719bd3be5  lea rdx, [rsp+0x20]
00007b2719bd3bea  lea rcx, [rsp+0x30]
00007b2719bd3bef  mov r8d, 0x00
00007b2719bd3bf5  lea r9, [r15+0x3A8]
00007b2719bd3bfc  movaps [rdi], xmm12
00007b2719bd3c00  movaps [rsi], xmm15
00007b2719bd3c04  movaps [rdx], xmm14
00007b2719bd3c08  movaps [rcx], xmm1
00007b2719bd3c0b  mov rax, 0x5A8E6560CA50
00007b2719bd3c15  call rax
00007b2719bd3c17  movaps xmm12, [rsp]
00007b2719bd3c1c  add rsp, 0x40
00007b2719bd3c20  vmovaps xmm0, [rsp]
00007b2719bd3c25  vmovaps xmm1, [rsp+0x10]
00007b2719bd3c2b  vmovaps xmm2, [rsp+0x20]
00007b2719bd3c31  vmovaps xmm3, [rsp+0x30]
00007b2719bd3c37  vmovaps xmm4, [rsp+0x40]
00007b2719bd3c3d  vmovaps xmm5, [rsp+0x50]
00007b2719bd3c43  vmovaps xmm6, [rsp+0x60]
00007b2719bd3c49  vmovaps xmm7, [rsp+0x70]
00007b2719bd3c4f  vmovaps xmm8, [rsp+0x80]
00007b2719bd3c58  vmovaps xmm9, [rsp+0x90]
00007b2719bd3c61  vmovaps xmm10, [rsp+0xA0]
00007b2719bd3c6a  vmovaps xmm11, [rsp+0xB0]
00007b2719bd3c73  vmovaps xmm13, [rsp+0xC0]
00007b2719bd3c7c  vmovaps xmm14, [rsp+0xD0]
00007b2719bd3c85  vmovaps xmm15, [rsp+0xE0]
00007b2719bd3c8e  add rsp, 0xF0
00007b2719bd3c95  pop r11
00007b2719bd3c97  pop r10
00007b2719bd3c99  pop r9
00007b2719bd3c9b  pop r8
00007b2719bd3c9d  pop rsi
00007b2719bd3c9e  pop rdi
00007b2719bd3c9f  pop rdx
00007b2719bd3ca0  pop rcx
00007b2719bd3ca1  pop rax
00007b2719bd3ca2  add rsp, 0x08
00007b2719bd3ca6  jmp 0x00007B2719BD2BB2
00007b2719bd3cab  sub rsp, 0x08
00007b2719bd3caf  push rax
00007b2719bd3cb0  push rcx
00007b2719bd3cb1  push rdx
00007b2719bd3cb2  push rdi
00007b2719bd3cb3  push rsi
00007b2719bd3cb4  push r8
00007b2719bd3cb6  push r9
00007b2719bd3cb8  push r10
00007b2719bd3cba  push r11
00007b2719bd3cbc  sub rsp, 0xF0
00007b2719bd3cc3  vmovaps [rsp], xmm0
00007b2719bd3cc8  vmovaps [rsp+0x10], xmm1
00007b2719bd3cce  vmovaps [rsp+0x20], xmm2
00007b2719bd3cd4  vmovaps [rsp+0x30], xmm3
00007b2719bd3cda  vmovaps [rsp+0x40], xmm4
00007b2719bd3ce0  vmovaps [rsp+0x50], xmm5
00007b2719bd3ce6  vmovaps [rsp+0x60], xmm6
00007b2719bd3cec  vmovaps [rsp+0x70], xmm7
00007b2719bd3cf2  vmovaps [rsp+0x80], xmm8
00007b2719bd3cfb  vmovaps [rsp+0x90], xmm9
00007b2719bd3d04  vmovaps [rsp+0xA0], xmm10
00007b2719bd3d0d  vmovaps [rsp+0xB0], xmm11
00007b2719bd3d16  vmovaps [rsp+0xC0], xmm12
00007b2719bd3d1f  vmovaps [rsp+0xD0], xmm14
00007b2719bd3d28  vmovaps [rsp+0xE0], xmm15
00007b2719bd3d31  sub rsp, 0x40
00007b2719bd3d35  lea rdi, [rsp]
00007b2719bd3d39  lea rsi, [rsp+0x10]
00007b2719bd3d3e  lea rdx, [rsp+0x20]
00007b2719bd3d43  lea rcx, [rsp+0x30]
00007b2719bd3d48  mov r8d, 0x00
00007b2719bd3d4e  lea r9, [r15+0x3A8]
00007b2719bd3d55  movaps [rdi], xmm13
00007b2719bd3d59  movaps [rsi], xmm15
00007b2719bd3d5d  movaps [rdx], xmm14
00007b2719bd3d61  movaps [rcx], xmm1
00007b2719bd3d64  mov rax, 0x5A8E6560CA50
00007b2719bd3d6e  call rax
00007b2719bd3d70  movaps xmm13, [rsp]
00007b2719bd3d75  add rsp, 0x40
00007b2719bd3d79  vmovaps xmm0, [rsp]
00007b2719bd3d7e  vmovaps xmm1, [rsp+0x10]
00007b2719bd3d84  vmovaps xmm2, [rsp+0x20]
00007b2719bd3d8a  vmovaps xmm3, [rsp+0x30]
00007b2719bd3d90  vmovaps xmm4, [rsp+0x40]
00007b2719bd3d96  vmovaps xmm5, [rsp+0x50]
00007b2719bd3d9c  vmovaps xmm6, [rsp+0x60]
00007b2719bd3da2  vmovaps xmm7, [rsp+0x70]
00007b2719bd3da8  vmovaps xmm8, [rsp+0x80]
00007b2719bd3db1  vmovaps xmm9, [rsp+0x90]
00007b2719bd3dba  vmovaps xmm10, [rsp+0xA0]
00007b2719bd3dc3  vmovaps xmm11, [rsp+0xB0]
00007b2719bd3dcc  vmovaps xmm12, [rsp+0xC0]
00007b2719bd3dd5  vmovaps xmm14, [rsp+0xD0]
00007b2719bd3dde  vmovaps xmm15, [rsp+0xE0]
00007b2719bd3de7  add rsp, 0xF0
00007b2719bd3dee  pop r11
00007b2719bd3df0  pop r10
00007b2719bd3df2  pop r9
00007b2719bd3df4  pop r8
00007b2719bd3df6  pop rsi
00007b2719bd3df7  pop rdi
00007b2719bd3df8  pop rdx
00007b2719bd3df9  pop rcx
00007b2719bd3dfa  pop rax
00007b2719bd3dfb  add rsp, 0x08
00007b2719bd3dff  jmp 0x00007B2719BD2BEA
00007b2719bd3e04  sub rsp, 0x08
00007b2719bd3e08  push rax
00007b2719bd3e09  push rcx
00007b2719bd3e0a  push rdx
00007b2719bd3e0b  push rdi
00007b2719bd3e0c  push rsi
00007b2719bd3e0d  push r8
00007b2719bd3e0f  push r9
00007b2719bd3e11  push r10
00007b2719bd3e13  push r11
00007b2719bd3e15  sub rsp, 0xF0
00007b2719bd3e1c  vmovaps [rsp], xmm0
00007b2719bd3e21  vmovaps [rsp+0x10], xmm1
00007b2719bd3e27  vmovaps [rsp+0x20], xmm2
00007b2719bd3e2d  vmovaps [rsp+0x30], xmm3
00007b2719bd3e33  vmovaps [rsp+0x40], xmm4
00007b2719bd3e39  vmovaps [rsp+0x50], xmm5
00007b2719bd3e3f  vmovaps [rsp+0x60], xmm6
00007b2719bd3e45  vmovaps [rsp+0x70], xmm7
00007b2719bd3e4b  vmovaps [rsp+0x80], xmm8
00007b2719bd3e54  vmovaps [rsp+0x90], xmm9
00007b2719bd3e5d  vmovaps [rsp+0xA0], xmm10
00007b2719bd3e66  vmovaps [rsp+0xB0], xmm11
00007b2719bd3e6f  vmovaps [rsp+0xC0], xmm13
00007b2719bd3e78  vmovaps [rsp+0xD0], xmm14
00007b2719bd3e81  vmovaps [rsp+0xE0], xmm15
00007b2719bd3e8a  sub rsp, 0x40
00007b2719bd3e8e  lea rdi, [rsp]
00007b2719bd3e92  lea rsi, [rsp+0x10]
00007b2719bd3e97  lea rdx, [rsp+0x20]
00007b2719bd3e9c  lea rcx, [rsp+0x30]
00007b2719bd3ea1  mov r8d, 0x00
00007b2719bd3ea7  lea r9, [r15+0x3A8]
00007b2719bd3eae  movaps [rdi], xmm12
00007b2719bd3eb2  movaps [rsi], xmm15
00007b2719bd3eb6  movaps [rdx], xmm14
00007b2719bd3eba  movaps [rcx], xmm1
00007b2719bd3ebd  mov rax, 0x5A8E6560CA50
00007b2719bd3ec7  call rax
00007b2719bd3ec9  movaps xmm12, [rsp]
00007b2719bd3ece  add rsp, 0x40
00007b2719bd3ed2  vmovaps xmm0, [rsp]
00007b2719bd3ed7  vmovaps xmm1, [rsp+0x10]
00007b2719bd3edd  vmovaps xmm2, [rsp+0x20]
00007b2719bd3ee3  vmovaps xmm3, [rsp+0x30]
00007b2719bd3ee9  vmovaps xmm4, [rsp+0x40]
00007b2719bd3eef  vmovaps xmm5, [rsp+0x50]
00007b2719bd3ef5  vmovaps xmm6, [rsp+0x60]
00007b2719bd3efb  vmovaps xmm7, [rsp+0x70]
00007b2719bd3f01  vmovaps xmm8, [rsp+0x80]
00007b2719bd3f0a  vmovaps xmm9, [rsp+0x90]
00007b2719bd3f13  vmovaps xmm10, [rsp+0xA0]
00007b2719bd3f1c  vmovaps xmm11, [rsp+0xB0]
00007b2719bd3f25  vmovaps xmm13, [rsp+0xC0]
00007b2719bd3f2e  vmovaps xmm14, [rsp+0xD0]
00007b2719bd3f37  vmovaps xmm15, [rsp+0xE0]
00007b2719bd3f40  add rsp, 0xF0
00007b2719bd3f47  pop r11
00007b2719bd3f49  pop r10
00007b2719bd3f4b  pop r9
00007b2719bd3f4d  pop r8
00007b2719bd3f4f  pop rsi
00007b2719bd3f50  pop rdi
00007b2719bd3f51  pop rdx
00007b2719bd3f52  pop rcx
00007b2719bd3f53  pop rax
00007b2719bd3f54  add rsp, 0x08
00007b2719bd3f58  jmp 0x00007B2719BD2C3D
00007b2719bd3f5d  sub rsp, 0x08
00007b2719bd3f61  push rax
00007b2719bd3f62  push rcx
00007b2719bd3f63  push rdx
00007b2719bd3f64  push rdi
00007b2719bd3f65  push rsi
00007b2719bd3f66  push r8
00007b2719bd3f68  push r9
00007b2719bd3f6a  push r10
00007b2719bd3f6c  push r11
00007b2719bd3f6e  sub rsp, 0xF0
00007b2719bd3f75  vmovaps [rsp], xmm0
00007b2719bd3f7a  vmovaps [rsp+0x10], xmm1
00007b2719bd3f80  vmovaps [rsp+0x20], xmm2
00007b2719bd3f86  vmovaps [rsp+0x30], xmm3
00007b2719bd3f8c  vmovaps [rsp+0x40], xmm4
00007b2719bd3f92  vmovaps [rsp+0x50], xmm5
00007b2719bd3f98  vmovaps [rsp+0x60], xmm6
00007b2719bd3f9e  vmovaps [rsp+0x70], xmm7
00007b2719bd3fa4  vmovaps [rsp+0x80], xmm8
00007b2719bd3fad  vmovaps [rsp+0x90], xmm9
00007b2719bd3fb6  vmovaps [rsp+0xA0], xmm10
00007b2719bd3fbf  vmovaps [rsp+0xB0], xmm11
00007b2719bd3fc8  vmovaps [rsp+0xC0], xmm12
00007b2719bd3fd1  vmovaps [rsp+0xD0], xmm13
00007b2719bd3fda  vmovaps [rsp+0xE0], xmm15
00007b2719bd3fe3  sub rsp, 0x40
00007b2719bd3fe7  lea rdi, [rsp]
00007b2719bd3feb  lea rsi, [rsp+0x10]
00007b2719bd3ff0  lea rdx, [rsp+0x20]
00007b2719bd3ff5  lea rcx, [rsp+0x30]
00007b2719bd3ffa  mov r8d, 0x00
00007b2719bd4000  lea r9, [r15+0x3A8]
00007b2719bd4007  movaps [rdi], xmm14
00007b2719bd400b  movaps [rsi], xmm3
00007b2719bd400e  movaps [rdx], xmm1
00007b2719bd4011  movaps [rcx], xmm15
00007b2719bd4015  mov rax, 0x5A8E6560CA50
00007b2719bd401f  call rax
00007b2719bd4021  movaps xmm14, [rsp]
00007b2719bd4026  add rsp, 0x40
00007b2719bd402a  vmovaps xmm0, [rsp]
00007b2719bd402f  vmovaps xmm1, [rsp+0x10]
00007b2719bd4035  vmovaps xmm2, [rsp+0x20]
00007b2719bd403b  vmovaps xmm3, [rsp+0x30]
00007b2719bd4041  vmovaps xmm4, [rsp+0x40]
00007b2719bd4047  vmovaps xmm5, [rsp+0x50]
00007b2719bd404d  vmovaps xmm6, [rsp+0x60]
00007b2719bd4053  vmovaps xmm7, [rsp+0x70]
00007b2719bd4059  vmovaps xmm8, [rsp+0x80]
00007b2719bd4062  vmovaps xmm9, [rsp+0x90]
00007b2719bd406b  vmovaps xmm10, [rsp+0xA0]
00007b2719bd4074  vmovaps xmm11, [rsp+0xB0]
00007b2719bd407d  vmovaps xmm12, [rsp+0xC0]
00007b2719bd4086  vmovaps xmm13, [rsp+0xD0]
00007b2719bd408f  vmovaps xmm15, [rsp+0xE0]
00007b2719bd4098  add rsp, 0xF0
00007b2719bd409f  pop r11
00007b2719bd40a1  pop r10
00007b2719bd40a3  pop r9
00007b2719bd40a5  pop r8
00007b2719bd40a7  pop rsi
00007b2719bd40a8  pop rdi
00007b2719bd40a9  pop rdx
00007b2719bd40aa  pop rcx
00007b2719bd40ab  pop rax
00007b2719bd40ac  add rsp, 0x08
00007b2719bd40b0  jmp 0x00007B2719BD2CF7
00007b2719bd40b5  sub rsp, 0x08
00007b2719bd40b9  push rax
00007b2719bd40ba  push rcx
00007b2719bd40bb  push rdx
00007b2719bd40bc  push rdi
00007b2719bd40bd  push rsi
00007b2719bd40be  push r8
00007b2719bd40c0  push r9
00007b2719bd40c2  push r10
00007b2719bd40c4  push r11
00007b2719bd40c6  sub rsp, 0xF0
00007b2719bd40cd  vmovaps [rsp], xmm0
00007b2719bd40d2  vmovaps [rsp+0x10], xmm1
00007b2719bd40d8  vmovaps [rsp+0x20], xmm2
00007b2719bd40de  vmovaps [rsp+0x30], xmm3
00007b2719bd40e4  vmovaps [rsp+0x40], xmm4
00007b2719bd40ea  vmovaps [rsp+0x50], xmm5
00007b2719bd40f0  vmovaps [rsp+0x60], xmm6
00007b2719bd40f6  vmovaps [rsp+0x70], xmm7
00007b2719bd40fc  vmovaps [rsp+0x80], xmm8
00007b2719bd4105  vmovaps [rsp+0x90], xmm9
00007b2719bd410e  vmovaps [rsp+0xA0], xmm10
00007b2719bd4117  vmovaps [rsp+0xB0], xmm11
00007b2719bd4120  vmovaps [rsp+0xC0], xmm12
00007b2719bd4129  vmovaps [rsp+0xD0], xmm14
00007b2719bd4132  vmovaps [rsp+0xE0], xmm15
00007b2719bd413b  sub rsp, 0x40
00007b2719bd413f  lea rdi, [rsp]
00007b2719bd4143  lea rsi, [rsp+0x10]
00007b2719bd4148  lea rdx, [rsp+0x20]
00007b2719bd414d  lea rcx, [rsp+0x30]
00007b2719bd4152  mov r8d, 0x00
00007b2719bd4158  lea r9, [r15+0x3A8]
00007b2719bd415f  movaps [rdi], xmm13
00007b2719bd4163  movaps [rsi], xmm15
00007b2719bd4167  movaps [rdx], xmm10
00007b2719bd416b  movaps [rcx], xmm1
00007b2719bd416e  mov rax, 0x5A8E6560CA50
00007b2719bd4178  call rax
00007b2719bd417a  movaps xmm13, [rsp]
00007b2719bd417f  add rsp, 0x40
00007b2719bd4183  vmovaps xmm0, [rsp]
00007b2719bd4188  vmovaps xmm1, [rsp+0x10]
00007b2719bd418e  vmovaps xmm2, [rsp+0x20]
00007b2719bd4194  vmovaps xmm3, [rsp+0x30]
00007b2719bd419a  vmovaps xmm4, [rsp+0x40]
00007b2719bd41a0  vmovaps xmm5, [rsp+0x50]
00007b2719bd41a6  vmovaps xmm6, [rsp+0x60]
00007b2719bd41ac  vmovaps xmm7, [rsp+0x70]
00007b2719bd41b2  vmovaps xmm8, [rsp+0x80]
00007b2719bd41bb  vmovaps xmm9, [rsp+0x90]
00007b2719bd41c4  vmovaps xmm10, [rsp+0xA0]
00007b2719bd41cd  vmovaps xmm11, [rsp+0xB0]
00007b2719bd41d6  vmovaps xmm12, [rsp+0xC0]
00007b2719bd41df  vmovaps xmm14, [rsp+0xD0]
00007b2719bd41e8  vmovaps xmm15, [rsp+0xE0]
00007b2719bd41f1  add rsp, 0xF0
00007b2719bd41f8  pop r11
00007b2719bd41fa  pop r10
00007b2719bd41fc  pop r9
00007b2719bd41fe  pop r8
00007b2719bd4200  pop rsi
00007b2719bd4201  pop rdi
00007b2719bd4202  pop rdx
00007b2719bd4203  pop rcx
00007b2719bd4204  pop rax
00007b2719bd4205  add rsp, 0x08
00007b2719bd4209  jmp 0x00007B2719BD2D26
00007b2719bd420e  sub rsp, 0x08
00007b2719bd4212  push rax
00007b2719bd4213  push rcx
00007b2719bd4214  push rdx
00007b2719bd4215  push rdi
00007b2719bd4216  push rsi
00007b2719bd4217  push r8
00007b2719bd4219  push r9
00007b2719bd421b  push r10
00007b2719bd421d  push r11
00007b2719bd421f  sub rsp, 0xF0
00007b2719bd4226  vmovaps [rsp], xmm0
00007b2719bd422b  vmovaps [rsp+0x10], xmm1
00007b2719bd4231  vmovaps [rsp+0x20], xmm2
00007b2719bd4237  vmovaps [rsp+0x30], xmm3
00007b2719bd423d  vmovaps [rsp+0x40], xmm4
00007b2719bd4243  vmovaps [rsp+0x50], xmm5
00007b2719bd4249  vmovaps [rsp+0x60], xmm6
00007b2719bd424f  vmovaps [rsp+0x70], xmm7
00007b2719bd4255  vmovaps [rsp+0x80], xmm8
00007b2719bd425e  vmovaps [rsp+0x90], xmm9
00007b2719bd4267  vmovaps [rsp+0xA0], xmm11
00007b2719bd4270  vmovaps [rsp+0xB0], xmm12
00007b2719bd4279  vmovaps [rsp+0xC0], xmm13
00007b2719bd4282  vmovaps [rsp+0xD0], xmm14
00007b2719bd428b  vmovaps [rsp+0xE0], xmm15
00007b2719bd4294  sub rsp, 0x40
00007b2719bd4298  lea rdi, [rsp]
00007b2719bd429c  lea rsi, [rsp+0x10]
00007b2719bd42a1  lea rdx, [rsp+0x20]
00007b2719bd42a6  lea rcx, [rsp+0x30]
00007b2719bd42ab  mov r8d, 0x00
00007b2719bd42b1  lea r9, [r15+0x3A8]
00007b2719bd42b8  movaps [rdi], xmm10
00007b2719bd42bc  movaps [rsi], xmm15
00007b2719bd42c0  movaps [rdx], xmm11
00007b2719bd42c4  movaps [rcx], xmm1
00007b2719bd42c7  mov rax, 0x5A8E6560CA50
00007b2719bd42d1  call rax
00007b2719bd42d3  movaps xmm10, [rsp]
00007b2719bd42d8  add rsp, 0x40
00007b2719bd42dc  vmovaps xmm0, [rsp]
00007b2719bd42e1  vmovaps xmm1, [rsp+0x10]
00007b2719bd42e7  vmovaps xmm2, [rsp+0x20]
00007b2719bd42ed  vmovaps xmm3, [rsp+0x30]
00007b2719bd42f3  vmovaps xmm4, [rsp+0x40]
00007b2719bd42f9  vmovaps xmm5, [rsp+0x50]
00007b2719bd42ff  vmovaps xmm6, [rsp+0x60]
00007b2719bd4305  vmovaps xmm7, [rsp+0x70]
00007b2719bd430b  vmovaps xmm8, [rsp+0x80]
00007b2719bd4314  vmovaps xmm9, [rsp+0x90]
00007b2719bd431d  vmovaps xmm11, [rsp+0xA0]
00007b2719bd4326  vmovaps xmm12, [rsp+0xB0]
00007b2719bd432f  vmovaps xmm13, [rsp+0xC0]
00007b2719bd4338  vmovaps xmm14, [rsp+0xD0]
00007b2719bd4341  vmovaps xmm15, [rsp+0xE0]
00007b2719bd434a  add rsp, 0xF0
00007b2719bd4351  pop r11
00007b2719bd4353  pop r10
00007b2719bd4355  pop r9
00007b2719bd4357  pop r8
00007b2719bd4359  pop rsi
00007b2719bd435a  pop rdi
00007b2719bd435b  pop rdx
00007b2719bd435c  pop rcx
00007b2719bd435d  pop rax
00007b2719bd435e  add rsp, 0x08
00007b2719bd4362  jmp 0x00007B2719BD2D55
00007b2719bd4367  sub rsp, 0x08
00007b2719bd436b  push rax
00007b2719bd436c  push rcx
00007b2719bd436d  push rdx
00007b2719bd436e  push rdi
00007b2719bd436f  push rsi
00007b2719bd4370  push r8
00007b2719bd4372  push r9
00007b2719bd4374  push r10
00007b2719bd4376  push r11
00007b2719bd4378  sub rsp, 0xF0
00007b2719bd437f  vmovaps [rsp], xmm0
00007b2719bd4384  vmovaps [rsp+0x10], xmm1
00007b2719bd438a  vmovaps [rsp+0x20], xmm2
00007b2719bd4390  vmovaps [rsp+0x30], xmm3
00007b2719bd4396  vmovaps [rsp+0x40], xmm4
00007b2719bd439c  vmovaps [rsp+0x50], xmm5
00007b2719bd43a2  vmovaps [rsp+0x60], xmm6
00007b2719bd43a8  vmovaps [rsp+0x70], xmm7
00007b2719bd43ae  vmovaps [rsp+0x80], xmm8
00007b2719bd43b7  vmovaps [rsp+0x90], xmm9
00007b2719bd43c0  vmovaps [rsp+0xA0], xmm10
00007b2719bd43c9  vmovaps [rsp+0xB0], xmm11
00007b2719bd43d2  vmovaps [rsp+0xC0], xmm12
00007b2719bd43db  vmovaps [rsp+0xD0], xmm13
00007b2719bd43e4  vmovaps [rsp+0xE0], xmm14
00007b2719bd43ed  sub rsp, 0x40
00007b2719bd43f1  lea rdi, [rsp]
00007b2719bd43f5  lea rsi, [rsp+0x10]
00007b2719bd43fa  lea rdx, [rsp+0x20]
00007b2719bd43ff  lea rcx, [rsp+0x30]
00007b2719bd4404  mov r8d, 0x00
00007b2719bd440a  lea r9, [r15+0x3A8]
00007b2719bd4411  movaps [rdi], xmm15
00007b2719bd4415  movaps [rsi], xmm12
00007b2719bd4419  movaps [rdx], xmm5
00007b2719bd441c  movaps [rcx], xmm1
00007b2719bd441f  mov rax, 0x5A8E6560CA50
00007b2719bd4429  call rax
00007b2719bd442b  movaps xmm15, [rsp]
00007b2719bd4430  add rsp, 0x40
00007b2719bd4434  vmovaps xmm0, [rsp]
00007b2719bd4439  vmovaps xmm1, [rsp+0x10]
00007b2719bd443f  vmovaps xmm2, [rsp+0x20]
00007b2719bd4445  vmovaps xmm3, [rsp+0x30]
00007b2719bd444b  vmovaps xmm4, [rsp+0x40]
00007b2719bd4451  vmovaps xmm5, [rsp+0x50]
00007b2719bd4457  vmovaps xmm6, [rsp+0x60]
00007b2719bd445d  vmovaps xmm7, [rsp+0x70]
00007b2719bd4463  vmovaps xmm8, [rsp+0x80]
00007b2719bd446c  vmovaps xmm9, [rsp+0x90]
00007b2719bd4475  vmovaps xmm10, [rsp+0xA0]
00007b2719bd447e  vmovaps xmm11, [rsp+0xB0]
00007b2719bd4487  vmovaps xmm12, [rsp+0xC0]
00007b2719bd4490  vmovaps xmm13, [rsp+0xD0]
00007b2719bd4499  vmovaps xmm14, [rsp+0xE0]
00007b2719bd44a2  add rsp, 0xF0
00007b2719bd44a9  pop r11
00007b2719bd44ab  pop r10
00007b2719bd44ad  pop r9
00007b2719bd44af  pop r8
00007b2719bd44b1  pop rsi
00007b2719bd44b2  pop rdi
00007b2719bd44b3  pop rdx
00007b2719bd44b4  pop rcx
00007b2719bd44b5  pop rax
00007b2719bd44b6  add rsp, 0x08
00007b2719bd44ba  jmp 0x00007B2719BD2D7E
00007b2719bd44bf  sub rsp, 0x08
00007b2719bd44c3  push rax
00007b2719bd44c4  push rcx
00007b2719bd44c5  push rdx
00007b2719bd44c6  push rdi
00007b2719bd44c7  push rsi
00007b2719bd44c8  push r8
00007b2719bd44ca  push r9
00007b2719bd44cc  push r10
00007b2719bd44ce  push r11
00007b2719bd44d0  sub rsp, 0xF0
00007b2719bd44d7  vmovaps [rsp], xmm0
00007b2719bd44dc  vmovaps [rsp+0x10], xmm1
00007b2719bd44e2  vmovaps [rsp+0x20], xmm2
00007b2719bd44e8  vmovaps [rsp+0x30], xmm3
00007b2719bd44ee  vmovaps [rsp+0x40], xmm4
00007b2719bd44f4  vmovaps [rsp+0x50], xmm6
00007b2719bd44fa  vmovaps [rsp+0x60], xmm7
00007b2719bd4500  vmovaps [rsp+0x70], xmm8
00007b2719bd4506  vmovaps [rsp+0x80], xmm9
00007b2719bd450f  vmovaps [rsp+0x90], xmm10
00007b2719bd4518  vmovaps [rsp+0xA0], xmm11
00007b2719bd4521  vmovaps [rsp+0xB0], xmm12
00007b2719bd452a  vmovaps [rsp+0xC0], xmm13
00007b2719bd4533  vmovaps [rsp+0xD0], xmm14
00007b2719bd453c  vmovaps [rsp+0xE0], xmm15
00007b2719bd4545  sub rsp, 0x40
00007b2719bd4549  lea rdi, [rsp]
00007b2719bd454d  lea rsi, [rsp+0x10]
00007b2719bd4552  lea rdx, [rsp+0x20]
00007b2719bd4557  lea rcx, [rsp+0x30]
00007b2719bd455c  mov r8d, 0x00
00007b2719bd4562  lea r9, [r15+0x3A8]
00007b2719bd4569  movaps [rdi], xmm5
00007b2719bd456c  movaps [rsi], xmm13
00007b2719bd4570  movaps [rdx], xmm11
00007b2719bd4574  movaps [rcx], xmm12
00007b2719bd4578  mov rax, 0x5A8E6560CA50
00007b2719bd4582  call rax
00007b2719bd4584  movaps xmm5, [rsp]
00007b2719bd4588  add rsp, 0x40
00007b2719bd458c  vmovaps xmm0, [rsp]
00007b2719bd4591  vmovaps xmm1, [rsp+0x10]
00007b2719bd4597  vmovaps xmm2, [rsp+0x20]
00007b2719bd459d  vmovaps xmm3, [rsp+0x30]
00007b2719bd45a3  vmovaps xmm4, [rsp+0x40]
00007b2719bd45a9  vmovaps xmm6, [rsp+0x50]
00007b2719bd45af  vmovaps xmm7, [rsp+0x60]
00007b2719bd45b5  vmovaps xmm8, [rsp+0x70]
00007b2719bd45bb  vmovaps xmm9, [rsp+0x80]
00007b2719bd45c4  vmovaps xmm10, [rsp+0x90]
00007b2719bd45cd  vmovaps xmm11, [rsp+0xA0]
00007b2719bd45d6  vmovaps xmm12, [rsp+0xB0]
00007b2719bd45df  vmovaps xmm13, [rsp+0xC0]
00007b2719bd45e8  vmovaps xmm14, [rsp+0xD0]
00007b2719bd45f1  vmovaps xmm15, [rsp+0xE0]
00007b2719bd45fa  add rsp, 0xF0
00007b2719bd4601  pop r11
00007b2719bd4603  pop r10
00007b2719bd4605  pop r9
00007b2719bd4607  pop r8
00007b2719bd4609  pop rsi
00007b2719bd460a  pop rdi
00007b2719bd460b  pop rdx
00007b2719bd460c  pop rcx
00007b2719bd460d  pop rax
00007b2719bd460e  add rsp, 0x08
00007b2719bd4612  jmp 0x00007B2719BD2DDD
00007b2719bd4617  sub rsp, 0x08
00007b2719bd461b  push rax
00007b2719bd461c  push rcx
00007b2719bd461d  push rdx
00007b2719bd461e  push rdi
00007b2719bd461f  push rsi
00007b2719bd4620  push r8
00007b2719bd4622  push r9
00007b2719bd4624  push r10
00007b2719bd4626  push r11
00007b2719bd4628  sub rsp, 0xF0
00007b2719bd462f  vmovaps [rsp], xmm0
00007b2719bd4634  vmovaps [rsp+0x10], xmm1
00007b2719bd463a  vmovaps [rsp+0x20], xmm2
00007b2719bd4640  vmovaps [rsp+0x30], xmm3
00007b2719bd4646  vmovaps [rsp+0x40], xmm4
00007b2719bd464c  vmovaps [rsp+0x50], xmm5
00007b2719bd4652  vmovaps [rsp+0x60], xmm6
00007b2719bd4658  vmovaps [rsp+0x70], xmm7
00007b2719bd465e  vmovaps [rsp+0x80], xmm8
00007b2719bd4667  vmovaps [rsp+0x90], xmm9
00007b2719bd4670  vmovaps [rsp+0xA0], xmm10
00007b2719bd4679  vmovaps [rsp+0xB0], xmm11
00007b2719bd4682  vmovaps [rsp+0xC0], xmm13
00007b2719bd468b  vmovaps [rsp+0xD0], xmm14
00007b2719bd4694  vmovaps [rsp+0xE0], xmm15
00007b2719bd469d  sub rsp, 0x40
00007b2719bd46a1  lea rdi, [rsp]
00007b2719bd46a5  lea rsi, [rsp+0x10]
00007b2719bd46aa  lea rdx, [rsp+0x20]
00007b2719bd46af  lea rcx, [rsp+0x30]
00007b2719bd46b4  mov r8d, 0x00
00007b2719bd46ba  lea r9, [r15+0x3A8]
00007b2719bd46c1  movaps [rdi], xmm12
00007b2719bd46c5  movaps [rsi], xmm14
00007b2719bd46c9  movaps [rdx], xmm9
00007b2719bd46cd  movaps [rcx], xmm13
00007b2719bd46d1  mov rax, 0x5A8E6560CA50
00007b2719bd46db  call rax
00007b2719bd46dd  movaps xmm12, [rsp]
00007b2719bd46e2  add rsp, 0x40
00007b2719bd46e6  vmovaps xmm0, [rsp]
00007b2719bd46eb  vmovaps xmm1, [rsp+0x10]
00007b2719bd46f1  vmovaps xmm2, [rsp+0x20]
00007b2719bd46f7  vmovaps xmm3, [rsp+0x30]
00007b2719bd46fd  vmovaps xmm4, [rsp+0x40]
00007b2719bd4703  vmovaps xmm5, [rsp+0x50]
00007b2719bd4709  vmovaps xmm6, [rsp+0x60]
00007b2719bd470f  vmovaps xmm7, [rsp+0x70]
00007b2719bd4715  vmovaps xmm8, [rsp+0x80]
00007b2719bd471e  vmovaps xmm9, [rsp+0x90]
00007b2719bd4727  vmovaps xmm10, [rsp+0xA0]
00007b2719bd4730  vmovaps xmm11, [rsp+0xB0]
00007b2719bd4739  vmovaps xmm13, [rsp+0xC0]
00007b2719bd4742  vmovaps xmm14, [rsp+0xD0]
00007b2719bd474b  vmovaps xmm15, [rsp+0xE0]
00007b2719bd4754  add rsp, 0xF0
00007b2719bd475b  pop r11
00007b2719bd475d  pop r10
00007b2719bd475f  pop r9
00007b2719bd4761  pop r8
00007b2719bd4763  pop rsi
00007b2719bd4764  pop rdi
00007b2719bd4765  pop rdx
00007b2719bd4766  pop rcx
00007b2719bd4767  pop rax
00007b2719bd4768  add rsp, 0x08
00007b2719bd476c  jmp 0x00007B2719BD2E06
00007b2719bd4771  call 0x00007B2719A0D4E0
00007b2719bd4776  jmp 0x00007B2719BD2E13
00007b2719bd477b  sub rsp, 0x08
00007b2719bd477f  push rax
00007b2719bd4780  push rcx
00007b2719bd4781  push rdx
00007b2719bd4782  push rdi
00007b2719bd4783  push rsi
00007b2719bd4784  push r8
00007b2719bd4786  push r9
00007b2719bd4788  push r10
00007b2719bd478a  push r11
00007b2719bd478c  sub rsp, 0xF0
00007b2719bd4793  vmovaps [rsp], xmm0
00007b2719bd4798  vmovaps [rsp+0x10], xmm1
00007b2719bd479e  vmovaps [rsp+0x20], xmm2
00007b2719bd47a4  vmovaps [rsp+0x30], xmm3
00007b2719bd47aa  vmovaps [rsp+0x40], xmm4
00007b2719bd47b0  vmovaps [rsp+0x50], xmm5
00007b2719bd47b6  vmovaps [rsp+0x60], xmm6
00007b2719bd47bc  vmovaps [rsp+0x70], xmm7
00007b2719bd47c2  vmovaps [rsp+0x80], xmm8
00007b2719bd47cb  vmovaps [rsp+0x90], xmm9
00007b2719bd47d4  vmovaps [rsp+0xA0], xmm10
00007b2719bd47dd  vmovaps [rsp+0xB0], xmm12
00007b2719bd47e6  vmovaps [rsp+0xC0], xmm13
00007b2719bd47ef  vmovaps [rsp+0xD0], xmm14
00007b2719bd47f8  vmovaps [rsp+0xE0], xmm15
00007b2719bd4801  sub rsp, 0x40
00007b2719bd4805  lea rdi, [rsp]
00007b2719bd4809  lea rsi, [rsp+0x10]
00007b2719bd480e  lea rdx, [rsp+0x20]
00007b2719bd4813  lea rcx, [rsp+0x30]
00007b2719bd4818  mov r8d, 0x00
00007b2719bd481e  lea r9, [r15+0x3A8]
00007b2719bd4825  movaps [rdi], xmm11
00007b2719bd4829  movaps [rsi], xmm10
00007b2719bd482d  movaps [rdx], xmm8
00007b2719bd4831  movaps [rcx], xmm13
00007b2719bd4835  mov rax, 0x5A8E6560CA50
00007b2719bd483f  call rax
00007b2719bd4841  movaps xmm11, [rsp]
00007b2719bd4846  add rsp, 0x40
00007b2719bd484a  vmovaps xmm0, [rsp]
00007b2719bd484f  vmovaps xmm1, [rsp+0x10]
00007b2719bd4855  vmovaps xmm2, [rsp+0x20]
00007b2719bd485b  vmovaps xmm3, [rsp+0x30]
00007b2719bd4861  vmovaps xmm4, [rsp+0x40]
00007b2719bd4867  vmovaps xmm5, [rsp+0x50]
00007b2719bd486d  vmovaps xmm6, [rsp+0x60]
00007b2719bd4873  vmovaps xmm7, [rsp+0x70]
00007b2719bd4879  vmovaps xmm8, [rsp+0x80]
00007b2719bd4882  vmovaps xmm9, [rsp+0x90]
00007b2719bd488b  vmovaps xmm10, [rsp+0xA0]
00007b2719bd4894  vmovaps xmm12, [rsp+0xB0]
00007b2719bd489d  vmovaps xmm13, [rsp+0xC0]
00007b2719bd48a6  vmovaps xmm14, [rsp+0xD0]
00007b2719bd48af  vmovaps xmm15, [rsp+0xE0]
00007b2719bd48b8  add rsp, 0xF0
00007b2719bd48bf  pop r11
00007b2719bd48c1  pop r10
00007b2719bd48c3  pop r9
00007b2719bd48c5  pop r8
00007b2719bd48c7  pop rsi
00007b2719bd48c8  pop rdi
00007b2719bd48c9  pop rdx
00007b2719bd48ca  pop rcx
00007b2719bd48cb  pop rax
00007b2719bd48cc  add rsp, 0x08
00007b2719bd48d0  jmp 0x00007B2719BD2E44
00007b2719bd48d5  sub rsp, 0x08
00007b2719bd48d9  push rax
00007b2719bd48da  push rcx
00007b2719bd48db  push rdx
00007b2719bd48dc  push rdi
00007b2719bd48dd  push rsi
00007b2719bd48de  push r8
00007b2719bd48e0  push r9
00007b2719bd48e2  push r10
00007b2719bd48e4  push r11
00007b2719bd48e6  sub rsp, 0xF0
00007b2719bd48ed  vmovaps [rsp], xmm0
00007b2719bd48f2  vmovaps [rsp+0x10], xmm1
00007b2719bd48f8  vmovaps [rsp+0x20], xmm2
00007b2719bd48fe  vmovaps [rsp+0x30], xmm3
00007b2719bd4904  vmovaps [rsp+0x40], xmm4
00007b2719bd490a  vmovaps [rsp+0x50], xmm5
00007b2719bd4910  vmovaps [rsp+0x60], xmm6
00007b2719bd4916  vmovaps [rsp+0x70], xmm7
00007b2719bd491c  vmovaps [rsp+0x80], xmm8
00007b2719bd4925  vmovaps [rsp+0x90], xmm9
00007b2719bd492e  vmovaps [rsp+0xA0], xmm11
00007b2719bd4937  vmovaps [rsp+0xB0], xmm12
00007b2719bd4940  vmovaps [rsp+0xC0], xmm13
00007b2719bd4949  vmovaps [rsp+0xD0], xmm14
00007b2719bd4952  vmovaps [rsp+0xE0], xmm15
00007b2719bd495b  sub rsp, 0x40
00007b2719bd495f  lea rdi, [rsp]
00007b2719bd4963  lea rsi, [rsp+0x10]
00007b2719bd4968  lea rdx, [rsp+0x20]
00007b2719bd496d  lea rcx, [rsp+0x30]
00007b2719bd4972  mov r8d, 0x00
00007b2719bd4978  lea r9, [r15+0x3A8]
00007b2719bd497f  movaps [rdi], xmm10
00007b2719bd4983  movaps [rsi], xmm15
00007b2719bd4987  movaps [rdx], xmm1
00007b2719bd498a  movaps [rcx], xmm13
00007b2719bd498e  mov rax, 0x5A8E6560CA50
00007b2719bd4998  call rax
00007b2719bd499a  movaps xmm10, [rsp]
00007b2719bd499f  add rsp, 0x40
00007b2719bd49a3  vmovaps xmm0, [rsp]
00007b2719bd49a8  vmovaps xmm1, [rsp+0x10]
00007b2719bd49ae  vmovaps xmm2, [rsp+0x20]
00007b2719bd49b4  vmovaps xmm3, [rsp+0x30]
00007b2719bd49ba  vmovaps xmm4, [rsp+0x40]
00007b2719bd49c0  vmovaps xmm5, [rsp+0x50]
00007b2719bd49c6  vmovaps xmm6, [rsp+0x60]
00007b2719bd49cc  vmovaps xmm7, [rsp+0x70]
00007b2719bd49d2  vmovaps xmm8, [rsp+0x80]
00007b2719bd49db  vmovaps xmm9, [rsp+0x90]
00007b2719bd49e4  vmovaps xmm11, [rsp+0xA0]
00007b2719bd49ed  vmovaps xmm12, [rsp+0xB0]
00007b2719bd49f6  vmovaps xmm13, [rsp+0xC0]
00007b2719bd49ff  vmovaps xmm14, [rsp+0xD0]
00007b2719bd4a08  vmovaps xmm15, [rsp+0xE0]
00007b2719bd4a11  add rsp, 0xF0
00007b2719bd4a18  pop r11
00007b2719bd4a1a  pop r10
00007b2719bd4a1c  pop r9
00007b2719bd4a1e  pop r8
00007b2719bd4a20  pop rsi
00007b2719bd4a21  pop rdi
00007b2719bd4a22  pop rdx
00007b2719bd4a23  pop rcx
00007b2719bd4a24  pop rax
00007b2719bd4a25  add rsp, 0x08
00007b2719bd4a29  jmp 0x00007B2719BD2E6D
00007b2719bd4a2e  call 0x00007B27199FF430
00007b2719bd4a33  jmp 0x00007B2719BD2E8F
00007b2719bd4a38  call 0x00007B2719A0E760
00007b2719bd4a3d  jmp 0x00007B2719BD2E99
00007b2719bd4a42  sub rsp, 0x08
00007b2719bd4a46  push rax
00007b2719bd4a47  push rcx
00007b2719bd4a48  push rdx
00007b2719bd4a49  push rdi
00007b2719bd4a4a  push rsi
00007b2719bd4a4b  push r8
00007b2719bd4a4d  push r9
00007b2719bd4a4f  push r10
00007b2719bd4a51  push r11
00007b2719bd4a53  sub rsp, 0xF0
00007b2719bd4a5a  vmovaps [rsp], xmm0
00007b2719bd4a5f  vmovaps [rsp+0x10], xmm1
00007b2719bd4a65  vmovaps [rsp+0x20], xmm2
00007b2719bd4a6b  vmovaps [rsp+0x30], xmm3
00007b2719bd4a71  vmovaps [rsp+0x40], xmm4
00007b2719bd4a77  vmovaps [rsp+0x50], xmm5
00007b2719bd4a7d  vmovaps [rsp+0x60], xmm6
00007b2719bd4a83  vmovaps [rsp+0x70], xmm7
00007b2719bd4a89  vmovaps [rsp+0x80], xmm9
00007b2719bd4a92  vmovaps [rsp+0x90], xmm10
00007b2719bd4a9b  vmovaps [rsp+0xA0], xmm11
00007b2719bd4aa4  vmovaps [rsp+0xB0], xmm12
00007b2719bd4aad  vmovaps [rsp+0xC0], xmm13
00007b2719bd4ab6  vmovaps [rsp+0xD0], xmm14
00007b2719bd4abf  vmovaps [rsp+0xE0], xmm15
00007b2719bd4ac8  sub rsp, 0x40
00007b2719bd4acc  lea rdi, [rsp]
00007b2719bd4ad0  lea rsi, [rsp+0x10]
00007b2719bd4ad5  lea rdx, [rsp+0x20]
00007b2719bd4ada  lea rcx, [rsp+0x30]
00007b2719bd4adf  mov r8d, 0x00
00007b2719bd4ae5  lea r9, [r15+0x3A8]
00007b2719bd4aec  movaps [rdi], xmm8
00007b2719bd4af0  movaps [rsi], xmm5
00007b2719bd4af3  movaps [rdx], xmm9
00007b2719bd4af7  movaps [rcx], xmm13
00007b2719bd4afb  mov rax, 0x5A8E6560CA50
00007b2719bd4b05  call rax
00007b2719bd4b07  movaps xmm8, [rsp]
00007b2719bd4b0c  add rsp, 0x40
00007b2719bd4b10  vmovaps xmm0, [rsp]
00007b2719bd4b15  vmovaps xmm1, [rsp+0x10]
00007b2719bd4b1b  vmovaps xmm2, [rsp+0x20]
00007b2719bd4b21  vmovaps xmm3, [rsp+0x30]
00007b2719bd4b27  vmovaps xmm4, [rsp+0x40]
00007b2719bd4b2d  vmovaps xmm5, [rsp+0x50]
00007b2719bd4b33  vmovaps xmm6, [rsp+0x60]
00007b2719bd4b39  vmovaps xmm7, [rsp+0x70]
00007b2719bd4b3f  vmovaps xmm9, [rsp+0x80]
00007b2719bd4b48  vmovaps xmm10, [rsp+0x90]
00007b2719bd4b51  vmovaps xmm11, [rsp+0xA0]
00007b2719bd4b5a  vmovaps xmm12, [rsp+0xB0]
00007b2719bd4b63  vmovaps xmm13, [rsp+0xC0]
00007b2719bd4b6c  vmovaps xmm14, [rsp+0xD0]
00007b2719bd4b75  vmovaps xmm15, [rsp+0xE0]
00007b2719bd4b7e  add rsp, 0xF0
00007b2719bd4b85  pop r11
00007b2719bd4b87  pop r10
00007b2719bd4b89  pop r9
00007b2719bd4b8b  pop r8
00007b2719bd4b8d  pop rsi
00007b2719bd4b8e  pop rdi
00007b2719bd4b8f  pop rdx
00007b2719bd4b90  pop rcx
00007b2719bd4b91  pop rax
00007b2719bd4b92  add rsp, 0x08
00007b2719bd4b96  jmp 0x00007B2719BD2ED8
00007b2719bd4b9b  sub rsp, 0x08
00007b2719bd4b9f  push rax
00007b2719bd4ba0  push rcx
00007b2719bd4ba1  push rdx
00007b2719bd4ba2  push rdi
00007b2719bd4ba3  push rsi
00007b2719bd4ba4  push r8
00007b2719bd4ba6  push r9
00007b2719bd4ba8  push r10
00007b2719bd4baa  push r11
00007b2719bd4bac  sub rsp, 0xF0
00007b2719bd4bb3  vmovaps [rsp], xmm0
00007b2719bd4bb8  vmovaps [rsp+0x10], xmm1
00007b2719bd4bbe  vmovaps [rsp+0x20], xmm2
00007b2719bd4bc4  vmovaps [rsp+0x30], xmm3
00007b2719bd4bca  vmovaps [rsp+0x40], xmm4
00007b2719bd4bd0  vmovaps [rsp+0x50], xmm5
00007b2719bd4bd6  vmovaps [rsp+0x60], xmm6
00007b2719bd4bdc  vmovaps [rsp+0x70], xmm7
00007b2719bd4be2  vmovaps [rsp+0x80], xmm8
00007b2719bd4beb  vmovaps [rsp+0x90], xmm10
00007b2719bd4bf4  vmovaps [rsp+0xA0], xmm11
00007b2719bd4bfd  vmovaps [rsp+0xB0], xmm12
00007b2719bd4c06  vmovaps [rsp+0xC0], xmm13
00007b2719bd4c0f  vmovaps [rsp+0xD0], xmm14
00007b2719bd4c18  vmovaps [rsp+0xE0], xmm15
00007b2719bd4c21  sub rsp, 0x40
00007b2719bd4c25  lea rdi, [rsp]
00007b2719bd4c29  lea rsi, [rsp+0x10]
00007b2719bd4c2e  lea rdx, [rsp+0x20]
00007b2719bd4c33  lea rcx, [rsp+0x30]
00007b2719bd4c38  mov r8d, 0x00
00007b2719bd4c3e  lea r9, [r15+0x3A8]
00007b2719bd4c45  movaps [rdi], xmm9
00007b2719bd4c49  movaps [rsi], xmm12
00007b2719bd4c4d  movaps [rdx], xmm7
00007b2719bd4c50  movaps [rcx], xmm13
00007b2719bd4c54  mov rax, 0x5A8E6560CA50
00007b2719bd4c5e  call rax
00007b2719bd4c60  movaps xmm9, [rsp]
00007b2719bd4c65  add rsp, 0x40
00007b2719bd4c69  vmovaps xmm0, [rsp]
00007b2719bd4c6e  vmovaps xmm1, [rsp+0x10]
00007b2719bd4c74  vmovaps xmm2, [rsp+0x20]
00007b2719bd4c7a  vmovaps xmm3, [rsp+0x30]
00007b2719bd4c80  vmovaps xmm4, [rsp+0x40]
00007b2719bd4c86  vmovaps xmm5, [rsp+0x50]
00007b2719bd4c8c  vmovaps xmm6, [rsp+0x60]
00007b2719bd4c92  vmovaps xmm7, [rsp+0x70]
00007b2719bd4c98  vmovaps xmm8, [rsp+0x80]
00007b2719bd4ca1  vmovaps xmm10, [rsp+0x90]
00007b2719bd4caa  vmovaps xmm11, [rsp+0xA0]
00007b2719bd4cb3  vmovaps xmm12, [rsp+0xB0]
00007b2719bd4cbc  vmovaps xmm13, [rsp+0xC0]
00007b2719bd4cc5  vmovaps xmm14, [rsp+0xD0]
00007b2719bd4cce  vmovaps xmm15, [rsp+0xE0]
00007b2719bd4cd7  add rsp, 0xF0
00007b2719bd4cde  pop r11
00007b2719bd4ce0  pop r10
00007b2719bd4ce2  pop r9
00007b2719bd4ce4  pop r8
00007b2719bd4ce6  pop rsi
00007b2719bd4ce7  pop rdi
00007b2719bd4ce8  pop rdx
00007b2719bd4ce9  pop rcx
00007b2719bd4cea  pop rax
00007b2719bd4ceb  add rsp, 0x08
00007b2719bd4cef  jmp 0x00007B2719BD2F01
00007b2719bd4cf4  sub rsp, 0x08
00007b2719bd4cf8  push rax
00007b2719bd4cf9  push rcx
00007b2719bd4cfa  push rdx
00007b2719bd4cfb  push rdi
00007b2719bd4cfc  push rsi
00007b2719bd4cfd  push r8
00007b2719bd4cff  push r9
00007b2719bd4d01  push r10
00007b2719bd4d03  push r11
00007b2719bd4d05  sub rsp, 0xF0
00007b2719bd4d0c  vmovaps [rsp], xmm0
00007b2719bd4d11  vmovaps [rsp+0x10], xmm1
00007b2719bd4d17  vmovaps [rsp+0x20], xmm2
00007b2719bd4d1d  vmovaps [rsp+0x30], xmm3
00007b2719bd4d23  vmovaps [rsp+0x40], xmm4
00007b2719bd4d29  vmovaps [rsp+0x50], xmm5
00007b2719bd4d2f  vmovaps [rsp+0x60], xmm6
00007b2719bd4d35  vmovaps [rsp+0x70], xmm7
00007b2719bd4d3b  vmovaps [rsp+0x80], xmm8
00007b2719bd4d44  vmovaps [rsp+0x90], xmm9
00007b2719bd4d4d  vmovaps [rsp+0xA0], xmm10
00007b2719bd4d56  vmovaps [rsp+0xB0], xmm11
00007b2719bd4d5f  vmovaps [rsp+0xC0], xmm13
00007b2719bd4d68  vmovaps [rsp+0xD0], xmm14
00007b2719bd4d71  vmovaps [rsp+0xE0], xmm15
00007b2719bd4d7a  sub rsp, 0x40
00007b2719bd4d7e  lea rdi, [rsp]
00007b2719bd4d82  lea rsi, [rsp+0x10]
00007b2719bd4d87  lea rdx, [rsp+0x20]
00007b2719bd4d8c  lea rcx, [rsp+0x30]
00007b2719bd4d91  mov r8d, 0x00
00007b2719bd4d97  lea r9, [r15+0x3A8]
00007b2719bd4d9e  movaps [rdi], xmm12
00007b2719bd4da2  movaps [rsi], xmm11
00007b2719bd4da6  movaps [rdx], xmm6
00007b2719bd4da9  movaps [rcx], xmm13
00007b2719bd4dad  mov rax, 0x5A8E6560CA50
00007b2719bd4db7  call rax
00007b2719bd4db9  movaps xmm12, [rsp]
00007b2719bd4dbe  add rsp, 0x40
00007b2719bd4dc2  vmovaps xmm0, [rsp]
00007b2719bd4dc7  vmovaps xmm1, [rsp+0x10]
00007b2719bd4dcd  vmovaps xmm2, [rsp+0x20]
00007b2719bd4dd3  vmovaps xmm3, [rsp+0x30]
00007b2719bd4dd9  vmovaps xmm4, [rsp+0x40]
00007b2719bd4ddf  vmovaps xmm5, [rsp+0x50]
00007b2719bd4de5  vmovaps xmm6, [rsp+0x60]
00007b2719bd4deb  vmovaps xmm7, [rsp+0x70]
00007b2719bd4df1  vmovaps xmm8, [rsp+0x80]
00007b2719bd4dfa  vmovaps xmm9, [rsp+0x90]
00007b2719bd4e03  vmovaps xmm10, [rsp+0xA0]
00007b2719bd4e0c  vmovaps xmm11, [rsp+0xB0]
00007b2719bd4e15  vmovaps xmm13, [rsp+0xC0]
00007b2719bd4e1e  vmovaps xmm14, [rsp+0xD0]
00007b2719bd4e27  vmovaps xmm15, [rsp+0xE0]
00007b2719bd4e30  add rsp, 0xF0
00007b2719bd4e37  pop r11
00007b2719bd4e39  pop r10
00007b2719bd4e3b  pop r9
00007b2719bd4e3d  pop r8
00007b2719bd4e3f  pop rsi
00007b2719bd4e40  pop rdi
00007b2719bd4e41  pop rdx
00007b2719bd4e42  pop rcx
00007b2719bd4e43  pop rax
00007b2719bd4e44  add rsp, 0x08
00007b2719bd4e48  jmp 0x00007B2719BD2F2A
00007b2719bd4e4d  sub rsp, 0x08
00007b2719bd4e51  push rax
00007b2719bd4e52  push rcx
00007b2719bd4e53  push rdx
00007b2719bd4e54  push rdi
00007b2719bd4e55  push rsi
00007b2719bd4e56  push r8
00007b2719bd4e58  push r9
00007b2719bd4e5a  push r10
00007b2719bd4e5c  push r11
00007b2719bd4e5e  sub rsp, 0xF0
00007b2719bd4e65  vmovaps [rsp], xmm0
00007b2719bd4e6a  vmovaps [rsp+0x10], xmm1
00007b2719bd4e70  vmovaps [rsp+0x20], xmm2
00007b2719bd4e76  vmovaps [rsp+0x30], xmm3
00007b2719bd4e7c  vmovaps [rsp+0x40], xmm4
00007b2719bd4e82  vmovaps [rsp+0x50], xmm5
00007b2719bd4e88  vmovaps [rsp+0x60], xmm6
00007b2719bd4e8e  vmovaps [rsp+0x70], xmm8
00007b2719bd4e94  vmovaps [rsp+0x80], xmm9
00007b2719bd4e9d  vmovaps [rsp+0x90], xmm10
00007b2719bd4ea6  vmovaps [rsp+0xA0], xmm11
00007b2719bd4eaf  vmovaps [rsp+0xB0], xmm12
00007b2719bd4eb8  vmovaps [rsp+0xC0], xmm13
00007b2719bd4ec1  vmovaps [rsp+0xD0], xmm14
00007b2719bd4eca  vmovaps [rsp+0xE0], xmm15
00007b2719bd4ed3  sub rsp, 0x40
00007b2719bd4ed7  lea rdi, [rsp]
00007b2719bd4edb  lea rsi, [rsp+0x10]
00007b2719bd4ee0  lea rdx, [rsp+0x20]
00007b2719bd4ee5  lea rcx, [rsp+0x30]
00007b2719bd4eea  mov r8d, 0x00
00007b2719bd4ef0  lea r9, [r15+0x3A8]
00007b2719bd4ef7  movaps [rdi], xmm7
00007b2719bd4efa  movaps [rsi], xmm10
00007b2719bd4efe  movaps [rdx], xmm11
00007b2719bd4f02  movaps [rcx], xmm13
00007b2719bd4f06  mov rax, 0x5A8E6560CA50
00007b2719bd4f10  call rax
00007b2719bd4f12  movaps xmm7, [rsp]
00007b2719bd4f16  add rsp, 0x40
00007b2719bd4f1a  vmovaps xmm0, [rsp]
00007b2719bd4f1f  vmovaps xmm1, [rsp+0x10]
00007b2719bd4f25  vmovaps xmm2, [rsp+0x20]
00007b2719bd4f2b  vmovaps xmm3, [rsp+0x30]
00007b2719bd4f31  vmovaps xmm4, [rsp+0x40]
00007b2719bd4f37  vmovaps xmm5, [rsp+0x50]
00007b2719bd4f3d  vmovaps xmm6, [rsp+0x60]
00007b2719bd4f43  vmovaps xmm8, [rsp+0x70]
00007b2719bd4f49  vmovaps xmm9, [rsp+0x80]
00007b2719bd4f52  vmovaps xmm10, [rsp+0x90]
00007b2719bd4f5b  vmovaps xmm11, [rsp+0xA0]
00007b2719bd4f64  vmovaps xmm12, [rsp+0xB0]
00007b2719bd4f6d  vmovaps xmm13, [rsp+0xC0]
00007b2719bd4f76  vmovaps xmm14, [rsp+0xD0]
00007b2719bd4f7f  vmovaps xmm15, [rsp+0xE0]
00007b2719bd4f88  add rsp, 0xF0
00007b2719bd4f8f  pop r11
00007b2719bd4f91  pop r10
00007b2719bd4f93  pop r9
00007b2719bd4f95  pop r8
00007b2719bd4f97  pop rsi
00007b2719bd4f98  pop rdi
00007b2719bd4f99  pop rdx
00007b2719bd4f9a  pop rcx
00007b2719bd4f9b  pop rax
00007b2719bd4f9c  add rsp, 0x08
00007b2719bd4fa0  jmp 0x00007B2719BD2F58
00007b2719bd4fa5  call 0x00007B2719A0C260
00007b2719bd4faa  jmp 0x00007B2719BD2F62
00007b2719bd4faf  call 0x00007B2719A09D70
00007b2719bd4fb4  jmp 0x00007B2719BD2F6C
00007b2719bd4fb9  sub rsp, 0x08
00007b2719bd4fbd  push rax
00007b2719bd4fbe  push rcx
00007b2719bd4fbf  push rdx
00007b2719bd4fc0  push rdi
00007b2719bd4fc1  push rsi
00007b2719bd4fc2  push r8
00007b2719bd4fc4  push r9
00007b2719bd4fc6  push r10
00007b2719bd4fc8  push r11
00007b2719bd4fca  sub rsp, 0xF0
00007b2719bd4fd1  vmovaps [rsp], xmm0
00007b2719bd4fd6  vmovaps [rsp+0x10], xmm1
00007b2719bd4fdc  vmovaps [rsp+0x20], xmm2
00007b2719bd4fe2  vmovaps [rsp+0x30], xmm3
00007b2719bd4fe8  vmovaps [rsp+0x40], xmm4
00007b2719bd4fee  vmovaps [rsp+0x50], xmm5
00007b2719bd4ff4  vmovaps [rsp+0x60], xmm7
00007b2719bd4ffa  vmovaps [rsp+0x70], xmm8
00007b2719bd5000  vmovaps [rsp+0x80], xmm9
00007b2719bd5009  vmovaps [rsp+0x90], xmm10
00007b2719bd5012  vmovaps [rsp+0xA0], xmm11
00007b2719bd501b  vmovaps [rsp+0xB0], xmm12
00007b2719bd5024  vmovaps [rsp+0xC0], xmm13
00007b2719bd502d  vmovaps [rsp+0xD0], xmm14
00007b2719bd5036  vmovaps [rsp+0xE0], xmm15
00007b2719bd503f  sub rsp, 0x40
00007b2719bd5043  lea rdi, [rsp]
00007b2719bd5047  lea rsi, [rsp+0x10]
00007b2719bd504c  lea rdx, [rsp+0x20]
00007b2719bd5051  lea rcx, [rsp+0x30]
00007b2719bd5056  mov r8d, 0x00
00007b2719bd505c  lea r9, [r15+0x3A8]
00007b2719bd5063  movaps [rdi], xmm6
00007b2719bd5066  movaps [rsi], xmm8
00007b2719bd506a  movaps [rdx], xmm15
00007b2719bd506e  movaps [rcx], xmm10
00007b2719bd5072  mov rax, 0x5A8E6560CA50
00007b2719bd507c  call rax
00007b2719bd507e  movaps xmm6, [rsp]
00007b2719bd5082  add rsp, 0x40
00007b2719bd5086  vmovaps xmm0, [rsp]
00007b2719bd508b  vmovaps xmm1, [rsp+0x10]
00007b2719bd5091  vmovaps xmm2, [rsp+0x20]
00007b2719bd5097  vmovaps xmm3, [rsp+0x30]
00007b2719bd509d  vmovaps xmm4, [rsp+0x40]
00007b2719bd50a3  vmovaps xmm5, [rsp+0x50]
00007b2719bd50a9  vmovaps xmm7, [rsp+0x60]
00007b2719bd50af  vmovaps xmm8, [rsp+0x70]
00007b2719bd50b5  vmovaps xmm9, [rsp+0x80]
00007b2719bd50be  vmovaps xmm10, [rsp+0x90]
00007b2719bd50c7  vmovaps xmm11, [rsp+0xA0]
00007b2719bd50d0  vmovaps xmm12, [rsp+0xB0]
00007b2719bd50d9  vmovaps xmm13, [rsp+0xC0]
00007b2719bd50e2  vmovaps xmm14, [rsp+0xD0]
00007b2719bd50eb  vmovaps xmm15, [rsp+0xE0]
00007b2719bd50f4  add rsp, 0xF0
00007b2719bd50fb  pop r11
00007b2719bd50fd  pop r10
00007b2719bd50ff  pop r9
00007b2719bd5101  pop r8
00007b2719bd5103  pop rsi
00007b2719bd5104  pop rdi
00007b2719bd5105  pop rdx
00007b2719bd5106  pop rcx
00007b2719bd5107  pop rax
00007b2719bd5108  add rsp, 0x08
00007b2719bd510c  jmp 0x00007B2719BD2FA4
00007b2719bd5111  sub rsp, 0x08
00007b2719bd5115  push rax
00007b2719bd5116  push rcx
00007b2719bd5117  push rdx
00007b2719bd5118  push rdi
00007b2719bd5119  push rsi
00007b2719bd511a  push r8
00007b2719bd511c  push r9
00007b2719bd511e  push r10
00007b2719bd5120  push r11
00007b2719bd5122  sub rsp, 0xF0
00007b2719bd5129  vmovaps [rsp], xmm0
00007b2719bd512e  vmovaps [rsp+0x10], xmm1
00007b2719bd5134  vmovaps [rsp+0x20], xmm2
00007b2719bd513a  vmovaps [rsp+0x30], xmm3
00007b2719bd5140  vmovaps [rsp+0x40], xmm4
00007b2719bd5146  vmovaps [rsp+0x50], xmm5
00007b2719bd514c  vmovaps [rsp+0x60], xmm6
00007b2719bd5152  vmovaps [rsp+0x70], xmm7
00007b2719bd5158  vmovaps [rsp+0x80], xmm8
00007b2719bd5161  vmovaps [rsp+0x90], xmm9
00007b2719bd516a  vmovaps [rsp+0xA0], xmm11
00007b2719bd5173  vmovaps [rsp+0xB0], xmm12
00007b2719bd517c  vmovaps [rsp+0xC0], xmm13
00007b2719bd5185  vmovaps [rsp+0xD0], xmm14
00007b2719bd518e  vmovaps [rsp+0xE0], xmm15
00007b2719bd5197  sub rsp, 0x40
00007b2719bd519b  lea rdi, [rsp]
00007b2719bd519f  lea rsi, [rsp+0x10]
00007b2719bd51a4  lea rdx, [rsp+0x20]
00007b2719bd51a9  lea rcx, [rsp+0x30]
00007b2719bd51ae  mov r8d, 0x00
00007b2719bd51b4  lea r9, [r15+0x3A8]
00007b2719bd51bb  movaps [rdi], xmm10
00007b2719bd51bf  movaps [rsi], xmm9
00007b2719bd51c3  movaps [rdx], xmm13
00007b2719bd51c7  movaps [rcx], xmm15
00007b2719bd51cb  mov rax, 0x5A8E6560CA50
00007b2719bd51d5  call rax
00007b2719bd51d7  movaps xmm10, [rsp]
00007b2719bd51dc  add rsp, 0x40
00007b2719bd51e0  vmovaps xmm0, [rsp]
00007b2719bd51e5  vmovaps xmm1, [rsp+0x10]
00007b2719bd51eb  vmovaps xmm2, [rsp+0x20]
00007b2719bd51f1  vmovaps xmm3, [rsp+0x30]
00007b2719bd51f7  vmovaps xmm4, [rsp+0x40]
00007b2719bd51fd  vmovaps xmm5, [rsp+0x50]
00007b2719bd5203  vmovaps xmm6, [rsp+0x60]
00007b2719bd5209  vmovaps xmm7, [rsp+0x70]
00007b2719bd520f  vmovaps xmm8, [rsp+0x80]
00007b2719bd5218  vmovaps xmm9, [rsp+0x90]
00007b2719bd5221  vmovaps xmm11, [rsp+0xA0]
00007b2719bd522a  vmovaps xmm12, [rsp+0xB0]
00007b2719bd5233  vmovaps xmm13, [rsp+0xC0]
00007b2719bd523c  vmovaps xmm14, [rsp+0xD0]
00007b2719bd5245  vmovaps xmm15, [rsp+0xE0]
00007b2719bd524e  add rsp, 0xF0
00007b2719bd5255  pop r11
00007b2719bd5257  pop r10
00007b2719bd5259  pop r9
00007b2719bd525b  pop r8
00007b2719bd525d  pop rsi
00007b2719bd525e  pop rdi
00007b2719bd525f  pop rdx
00007b2719bd5260  pop rcx
00007b2719bd5261  pop rax
00007b2719bd5262  add rsp, 0x08
00007b2719bd5266  jmp 0x00007B2719BD2FCD
00007b2719bd526b  sub rsp, 0x08
00007b2719bd526f  push rax
00007b2719bd5270  push rcx
00007b2719bd5271  push rdx
00007b2719bd5272  push rdi
00007b2719bd5273  push rsi
00007b2719bd5274  push r8
00007b2719bd5276  push r9
00007b2719bd5278  push r10
00007b2719bd527a  push r11
00007b2719bd527c  sub rsp, 0xF0
00007b2719bd5283  vmovaps [rsp], xmm0
00007b2719bd5288  vmovaps [rsp+0x10], xmm1
00007b2719bd528e  vmovaps [rsp+0x20], xmm2
00007b2719bd5294  vmovaps [rsp+0x30], xmm3
00007b2719bd529a  vmovaps [rsp+0x40], xmm4
00007b2719bd52a0  vmovaps [rsp+0x50], xmm5
00007b2719bd52a6  vmovaps [rsp+0x60], xmm6
00007b2719bd52ac  vmovaps [rsp+0x70], xmm7
00007b2719bd52b2  vmovaps [rsp+0x80], xmm8
00007b2719bd52bb  vmovaps [rsp+0x90], xmm9
00007b2719bd52c4  vmovaps [rsp+0xA0], xmm10
00007b2719bd52cd  vmovaps [rsp+0xB0], xmm11
00007b2719bd52d6  vmovaps [rsp+0xC0], xmm12
00007b2719bd52df  vmovaps [rsp+0xD0], xmm14
00007b2719bd52e8  vmovaps [rsp+0xE0], xmm15
00007b2719bd52f1  sub rsp, 0x40
00007b2719bd52f5  lea rdi, [rsp]
00007b2719bd52f9  lea rsi, [rsp+0x10]
00007b2719bd52fe  lea rdx, [rsp+0x20]
00007b2719bd5303  lea rcx, [rsp+0x30]
00007b2719bd5308  mov r8d, 0x00
00007b2719bd530e  lea r9, [r15+0x3A8]
00007b2719bd5315  movaps [rdi], xmm13
00007b2719bd5319  movaps [rsi], xmm12
00007b2719bd531d  movaps [rdx], xmm4
00007b2719bd5320  movaps [rcx], xmm15
00007b2719bd5324  mov rax, 0x5A8E6560CA50
00007b2719bd532e  call rax
00007b2719bd5330  movaps xmm13, [rsp]
00007b2719bd5335  add rsp, 0x40
00007b2719bd5339  vmovaps xmm0, [rsp]
00007b2719bd533e  vmovaps xmm1, [rsp+0x10]
00007b2719bd5344  vmovaps xmm2, [rsp+0x20]
00007b2719bd534a  vmovaps xmm3, [rsp+0x30]
00007b2719bd5350  vmovaps xmm4, [rsp+0x40]
00007b2719bd5356  vmovaps xmm5, [rsp+0x50]
00007b2719bd535c  vmovaps xmm6, [rsp+0x60]
00007b2719bd5362  vmovaps xmm7, [rsp+0x70]
00007b2719bd5368  vmovaps xmm8, [rsp+0x80]
00007b2719bd5371  vmovaps xmm9, [rsp+0x90]
00007b2719bd537a  vmovaps xmm10, [rsp+0xA0]
00007b2719bd5383  vmovaps xmm11, [rsp+0xB0]
00007b2719bd538c  vmovaps xmm12, [rsp+0xC0]
00007b2719bd5395  vmovaps xmm14, [rsp+0xD0]
00007b2719bd539e  vmovaps xmm15, [rsp+0xE0]
00007b2719bd53a7  add rsp, 0xF0
00007b2719bd53ae  pop r11
00007b2719bd53b0  pop r10
00007b2719bd53b2  pop r9
00007b2719bd53b4  pop r8
00007b2719bd53b6  pop rsi
00007b2719bd53b7  pop rdi
00007b2719bd53b8  pop rdx
00007b2719bd53b9  pop rcx
00007b2719bd53ba  pop rax
00007b2719bd53bb  add rsp, 0x08
00007b2719bd53bf  jmp 0x00007B2719BD2FF6
00007b2719bd53c4  sub rsp, 0x08
00007b2719bd53c8  push rax
00007b2719bd53c9  push rcx
00007b2719bd53ca  push rdx
00007b2719bd53cb  push rdi
00007b2719bd53cc  push rsi
00007b2719bd53cd  push r8
00007b2719bd53cf  push r9
00007b2719bd53d1  push r10
00007b2719bd53d3  push r11
00007b2719bd53d5  sub rsp, 0xF0
00007b2719bd53dc  vmovaps [rsp], xmm0
00007b2719bd53e1  vmovaps [rsp+0x10], xmm1
00007b2719bd53e7  vmovaps [rsp+0x20], xmm2
00007b2719bd53ed  vmovaps [rsp+0x30], xmm3
00007b2719bd53f3  vmovaps [rsp+0x40], xmm4
00007b2719bd53f9  vmovaps [rsp+0x50], xmm5
00007b2719bd53ff  vmovaps [rsp+0x60], xmm6
00007b2719bd5405  vmovaps [rsp+0x70], xmm7
00007b2719bd540b  vmovaps [rsp+0x80], xmm8
00007b2719bd5414  vmovaps [rsp+0x90], xmm9
00007b2719bd541d  vmovaps [rsp+0xA0], xmm10
00007b2719bd5426  vmovaps [rsp+0xB0], xmm11
00007b2719bd542f  vmovaps [rsp+0xC0], xmm13
00007b2719bd5438  vmovaps [rsp+0xD0], xmm14
00007b2719bd5441  vmovaps [rsp+0xE0], xmm15
00007b2719bd544a  sub rsp, 0x40
00007b2719bd544e  lea rdi, [rsp]
00007b2719bd5452  lea rsi, [rsp+0x10]
00007b2719bd5457  lea rdx, [rsp+0x20]
00007b2719bd545c  lea rcx, [rsp+0x30]
00007b2719bd5461  mov r8d, 0x00
00007b2719bd5467  lea r9, [r15+0x3A8]
00007b2719bd546e  movaps [rdi], xmm12
00007b2719bd5472  movaps [rsi], xmm7
00007b2719bd5475  movaps [rdx], xmm1
00007b2719bd5478  movaps [rcx], xmm15
00007b2719bd547c  mov rax, 0x5A8E6560CA50
00007b2719bd5486  call rax
00007b2719bd5488  movaps xmm12, [rsp]
00007b2719bd548d  add rsp, 0x40
00007b2719bd5491  vmovaps xmm0, [rsp]
00007b2719bd5496  vmovaps xmm1, [rsp+0x10]
00007b2719bd549c  vmovaps xmm2, [rsp+0x20]
00007b2719bd54a2  vmovaps xmm3, [rsp+0x30]
00007b2719bd54a8  vmovaps xmm4, [rsp+0x40]
00007b2719bd54ae  vmovaps xmm5, [rsp+0x50]
00007b2719bd54b4  vmovaps xmm6, [rsp+0x60]
00007b2719bd54ba  vmovaps xmm7, [rsp+0x70]
00007b2719bd54c0  vmovaps xmm8, [rsp+0x80]
00007b2719bd54c9  vmovaps xmm9, [rsp+0x90]
00007b2719bd54d2  vmovaps xmm10, [rsp+0xA0]
00007b2719bd54db  vmovaps xmm11, [rsp+0xB0]
00007b2719bd54e4  vmovaps xmm13, [rsp+0xC0]
00007b2719bd54ed  vmovaps xmm14, [rsp+0xD0]
00007b2719bd54f6  vmovaps xmm15, [rsp+0xE0]
00007b2719bd54ff  add rsp, 0xF0
00007b2719bd5506  pop r11
00007b2719bd5508  pop r10
00007b2719bd550a  pop r9
00007b2719bd550c  pop r8
00007b2719bd550e  pop rsi
00007b2719bd550f  pop rdi
00007b2719bd5510  pop rdx
00007b2719bd5511  pop rcx
00007b2719bd5512  pop rax
00007b2719bd5513  add rsp, 0x08
00007b2719bd5517  jmp 0x00007B2719BD301F
00007b2719bd551c  call 0x00007B27199FF430
00007b2719bd5521  jmp 0x00007B2719BD3029
00007b2719bd5526  call 0x00007B2719A0E760
00007b2719bd552b  jmp 0x00007B2719BD3033
00007b2719bd5530  sub rsp, 0x08
00007b2719bd5534  push rax
00007b2719bd5535  push rcx
00007b2719bd5536  push rdx
00007b2719bd5537  push rdi
00007b2719bd5538  push rsi
00007b2719bd5539  push r8
00007b2719bd553b  push r9
00007b2719bd553d  push r10
00007b2719bd553f  push r11
00007b2719bd5541  sub rsp, 0xF0
00007b2719bd5548  vmovaps [rsp], xmm0
00007b2719bd554d  vmovaps [rsp+0x10], xmm1
00007b2719bd5553  vmovaps [rsp+0x20], xmm2
00007b2719bd5559  vmovaps [rsp+0x30], xmm3
00007b2719bd555f  vmovaps [rsp+0x40], xmm4
00007b2719bd5565  vmovaps [rsp+0x50], xmm5
00007b2719bd556b  vmovaps [rsp+0x60], xmm6
00007b2719bd5571  vmovaps [rsp+0x70], xmm8
00007b2719bd5577  vmovaps [rsp+0x80], xmm9
00007b2719bd5580  vmovaps [rsp+0x90], xmm10
00007b2719bd5589  vmovaps [rsp+0xA0], xmm11
00007b2719bd5592  vmovaps [rsp+0xB0], xmm12
00007b2719bd559b  vmovaps [rsp+0xC0], xmm13
00007b2719bd55a4  vmovaps [rsp+0xD0], xmm14
00007b2719bd55ad  vmovaps [rsp+0xE0], xmm15
00007b2719bd55b6  sub rsp, 0x40
00007b2719bd55ba  lea rdi, [rsp]
00007b2719bd55be  lea rsi, [rsp+0x10]
00007b2719bd55c3  lea rdx, [rsp+0x20]
00007b2719bd55c8  lea rcx, [rsp+0x30]
00007b2719bd55cd  mov r8d, 0x00
00007b2719bd55d3  lea r9, [r15+0x3A8]
00007b2719bd55da  movaps [rdi], xmm7
00007b2719bd55dd  movaps [rsi], xmm6
00007b2719bd55e0  movaps [rdx], xmm8
00007b2719bd55e4  movaps [rcx], xmm9
00007b2719bd55e8  mov rax, 0x5A8E6560CA50
00007b2719bd55f2  call rax
00007b2719bd55f4  movaps xmm7, [rsp]
00007b2719bd55f8  add rsp, 0x40
00007b2719bd55fc  vmovaps xmm0, [rsp]
00007b2719bd5601  vmovaps xmm1, [rsp+0x10]
00007b2719bd5607  vmovaps xmm2, [rsp+0x20]
00007b2719bd560d  vmovaps xmm3, [rsp+0x30]
00007b2719bd5613  vmovaps xmm4, [rsp+0x40]
00007b2719bd5619  vmovaps xmm5, [rsp+0x50]
00007b2719bd561f  vmovaps xmm6, [rsp+0x60]
00007b2719bd5625  vmovaps xmm8, [rsp+0x70]
00007b2719bd562b  vmovaps xmm9, [rsp+0x80]
00007b2719bd5634  vmovaps xmm10, [rsp+0x90]
00007b2719bd563d  vmovaps xmm11, [rsp+0xA0]
00007b2719bd5646  vmovaps xmm12, [rsp+0xB0]
00007b2719bd564f  vmovaps xmm13, [rsp+0xC0]
00007b2719bd5658  vmovaps xmm14, [rsp+0xD0]
00007b2719bd5661  vmovaps xmm15, [rsp+0xE0]
00007b2719bd566a  add rsp, 0xF0
00007b2719bd5671  pop r11
00007b2719bd5673  pop r10
00007b2719bd5675  pop r9
00007b2719bd5677  pop r8
00007b2719bd5679  pop rsi
00007b2719bd567a  pop rdi
00007b2719bd567b  pop rdx
00007b2719bd567c  pop rcx
00007b2719bd567d  pop rax
00007b2719bd567e  add rsp, 0x08
00007b2719bd5682  jmp 0x00007B2719BD305D
00007b2719bd5687  sub rsp, 0x08
00007b2719bd568b  push rax
00007b2719bd568c  push rcx
00007b2719bd568d  push rdx
00007b2719bd568e  push rdi
00007b2719bd568f  push rsi
00007b2719bd5690  push r8
00007b2719bd5692  push r9
00007b2719bd5694  push r10
00007b2719bd5696  push r11
00007b2719bd5698  sub rsp, 0xF0
00007b2719bd569f  vmovaps [rsp], xmm0
00007b2719bd56a4  vmovaps [rsp+0x10], xmm1
00007b2719bd56aa  vmovaps [rsp+0x20], xmm2
00007b2719bd56b0  vmovaps [rsp+0x30], xmm3
00007b2719bd56b6  vmovaps [rsp+0x40], xmm4
00007b2719bd56bc  vmovaps [rsp+0x50], xmm5
00007b2719bd56c2  vmovaps [rsp+0x60], xmm6
00007b2719bd56c8  vmovaps [rsp+0x70], xmm7
00007b2719bd56ce  vmovaps [rsp+0x80], xmm9
00007b2719bd56d7  vmovaps [rsp+0x90], xmm10
00007b2719bd56e0  vmovaps [rsp+0xA0], xmm11
00007b2719bd56e9  vmovaps [rsp+0xB0], xmm12
00007b2719bd56f2  vmovaps [rsp+0xC0], xmm13
00007b2719bd56fb  vmovaps [rsp+0xD0], xmm14
00007b2719bd5704  vmovaps [rsp+0xE0], xmm15
00007b2719bd570d  sub rsp, 0x40
00007b2719bd5711  lea rdi, [rsp]
00007b2719bd5715  lea rsi, [rsp+0x10]
00007b2719bd571a  lea rdx, [rsp+0x20]
00007b2719bd571f  lea rcx, [rsp+0x30]
00007b2719bd5724  mov r8d, 0x00
00007b2719bd572a  lea r9, [r15+0x3A8]
00007b2719bd5731  movaps [rdi], xmm8
00007b2719bd5735  movaps [rsi], xmm10
00007b2719bd5739  movaps [rdx], xmm14
00007b2719bd573d  movaps [rcx], xmm9
00007b2719bd5741  mov rax, 0x5A8E6560CA50
00007b2719bd574b  call rax
00007b2719bd574d  movaps xmm8, [rsp]
00007b2719bd5752  add rsp, 0x40
00007b2719bd5756  vmovaps xmm0, [rsp]
00007b2719bd575b  vmovaps xmm1, [rsp+0x10]
00007b2719bd5761  vmovaps xmm2, [rsp+0x20]
00007b2719bd5767  vmovaps xmm3, [rsp+0x30]
00007b2719bd576d  vmovaps xmm4, [rsp+0x40]
00007b2719bd5773  vmovaps xmm5, [rsp+0x50]
00007b2719bd5779  vmovaps xmm6, [rsp+0x60]
00007b2719bd577f  vmovaps xmm7, [rsp+0x70]
00007b2719bd5785  vmovaps xmm9, [rsp+0x80]
00007b2719bd578e  vmovaps xmm10, [rsp+0x90]
00007b2719bd5797  vmovaps xmm11, [rsp+0xA0]
00007b2719bd57a0  vmovaps xmm12, [rsp+0xB0]
00007b2719bd57a9  vmovaps xmm13, [rsp+0xC0]
00007b2719bd57b2  vmovaps xmm14, [rsp+0xD0]
00007b2719bd57bb  vmovaps xmm15, [rsp+0xE0]
00007b2719bd57c4  add rsp, 0xF0
00007b2719bd57cb  pop r11
00007b2719bd57cd  pop r10
00007b2719bd57cf  pop r9
00007b2719bd57d1  pop r8
00007b2719bd57d3  pop rsi
00007b2719bd57d4  pop rdi
00007b2719bd57d5  pop rdx
00007b2719bd57d6  pop rcx
00007b2719bd57d7  pop rax
00007b2719bd57d8  add rsp, 0x08
00007b2719bd57dc  jmp 0x00007B2719BD3083
00007b2719bd57e1  sub rsp, 0x08
00007b2719bd57e5  push rax
00007b2719bd57e6  push rcx
00007b2719bd57e7  push rdx
00007b2719bd57e8  push rdi
00007b2719bd57e9  push rsi
00007b2719bd57ea  push r8
00007b2719bd57ec  push r9
00007b2719bd57ee  push r10
00007b2719bd57f0  push r11
00007b2719bd57f2  sub rsp, 0xF0
00007b2719bd57f9  vmovaps [rsp], xmm0
00007b2719bd57fe  vmovaps [rsp+0x10], xmm1
00007b2719bd5804  vmovaps [rsp+0x20], xmm2
00007b2719bd580a  vmovaps [rsp+0x30], xmm3
00007b2719bd5810  vmovaps [rsp+0x40], xmm4
00007b2719bd5816  vmovaps [rsp+0x50], xmm5
00007b2719bd581c  vmovaps [rsp+0x60], xmm6
00007b2719bd5822  vmovaps [rsp+0x70], xmm7
00007b2719bd5828  vmovaps [rsp+0x80], xmm8
00007b2719bd5831  vmovaps [rsp+0x90], xmm9
00007b2719bd583a  vmovaps [rsp+0xA0], xmm11
00007b2719bd5843  vmovaps [rsp+0xB0], xmm12
00007b2719bd584c  vmovaps [rsp+0xC0], xmm13
00007b2719bd5855  vmovaps [rsp+0xD0], xmm14
00007b2719bd585e  vmovaps [rsp+0xE0], xmm15
00007b2719bd5867  sub rsp, 0x40
00007b2719bd586b  lea rdi, [rsp]
00007b2719bd586f  lea rsi, [rsp+0x10]
00007b2719bd5874  lea rdx, [rsp+0x20]
00007b2719bd5879  lea rcx, [rsp+0x30]
00007b2719bd587e  mov r8d, 0x00
00007b2719bd5884  lea r9, [r15+0x3A8]
00007b2719bd588b  movaps [rdi], xmm10
00007b2719bd588f  movaps [rsi], xmm13
00007b2719bd5893  movaps [rdx], xmm11
00007b2719bd5897  movaps [rcx], xmm14
00007b2719bd589b  mov rax, 0x5A8E6560CA50
00007b2719bd58a5  call rax
00007b2719bd58a7  movaps xmm10, [rsp]
00007b2719bd58ac  add rsp, 0x40
00007b2719bd58b0  vmovaps xmm0, [rsp]
00007b2719bd58b5  vmovaps xmm1, [rsp+0x10]
00007b2719bd58bb  vmovaps xmm2, [rsp+0x20]
00007b2719bd58c1  vmovaps xmm3, [rsp+0x30]
00007b2719bd58c7  vmovaps xmm4, [rsp+0x40]
00007b2719bd58cd  vmovaps xmm5, [rsp+0x50]
00007b2719bd58d3  vmovaps xmm6, [rsp+0x60]
00007b2719bd58d9  vmovaps xmm7, [rsp+0x70]
00007b2719bd58df  vmovaps xmm8, [rsp+0x80]
00007b2719bd58e8  vmovaps xmm9, [rsp+0x90]
00007b2719bd58f1  vmovaps xmm11, [rsp+0xA0]
00007b2719bd58fa  vmovaps xmm12, [rsp+0xB0]
00007b2719bd5903  vmovaps xmm13, [rsp+0xC0]
00007b2719bd590c  vmovaps xmm14, [rsp+0xD0]
00007b2719bd5915  vmovaps xmm15, [rsp+0xE0]
00007b2719bd591e  add rsp, 0xF0
00007b2719bd5925  pop r11
00007b2719bd5927  pop r10
00007b2719bd5929  pop r9
00007b2719bd592b  pop r8
00007b2719bd592d  pop rsi
00007b2719bd592e  pop rdi
00007b2719bd592f  pop rdx
00007b2719bd5930  pop rcx
00007b2719bd5931  pop rax
00007b2719bd5932  add rsp, 0x08
00007b2719bd5936  jmp 0x00007B2719BD30A9
00007b2719bd593b  sub rsp, 0x08
00007b2719bd593f  push rax
00007b2719bd5940  push rcx
00007b2719bd5941  push rdx
00007b2719bd5942  push rdi
00007b2719bd5943  push rsi
00007b2719bd5944  push r8
00007b2719bd5946  push r9
00007b2719bd5948  push r10
00007b2719bd594a  push r11
00007b2719bd594c  sub rsp, 0xF0
00007b2719bd5953  vmovaps [rsp], xmm0
00007b2719bd5958  vmovaps [rsp+0x10], xmm1
00007b2719bd595e  vmovaps [rsp+0x20], xmm2
00007b2719bd5964  vmovaps [rsp+0x30], xmm3
00007b2719bd596a  vmovaps [rsp+0x40], xmm4
00007b2719bd5970  vmovaps [rsp+0x50], xmm5
00007b2719bd5976  vmovaps [rsp+0x60], xmm6
00007b2719bd597c  vmovaps [rsp+0x70], xmm7
00007b2719bd5982  vmovaps [rsp+0x80], xmm8
00007b2719bd598b  vmovaps [rsp+0x90], xmm9
00007b2719bd5994  vmovaps [rsp+0xA0], xmm10
00007b2719bd599d  vmovaps [rsp+0xB0], xmm11
00007b2719bd59a6  vmovaps [rsp+0xC0], xmm12
00007b2719bd59af  vmovaps [rsp+0xD0], xmm14
00007b2719bd59b8  vmovaps [rsp+0xE0], xmm15
00007b2719bd59c1  sub rsp, 0x40
00007b2719bd59c5  lea rdi, [rsp]
00007b2719bd59c9  lea rsi, [rsp+0x10]
00007b2719bd59ce  lea rdx, [rsp+0x20]
00007b2719bd59d3  lea rcx, [rsp+0x30]
00007b2719bd59d8  mov r8d, 0x00
00007b2719bd59de  lea r9, [r15+0x3A8]
00007b2719bd59e5  movaps [rdi], xmm13
00007b2719bd59e9  movaps [rsi], xmm12
00007b2719bd59ed  movaps [rdx], xmm15
00007b2719bd59f1  movaps [rcx], xmm14
00007b2719bd59f5  mov rax, 0x5A8E6560CA50
00007b2719bd59ff  call rax
00007b2719bd5a01  movaps xmm13, [rsp]
00007b2719bd5a06  add rsp, 0x40
00007b2719bd5a0a  vmovaps xmm0, [rsp]
00007b2719bd5a0f  vmovaps xmm1, [rsp+0x10]
00007b2719bd5a15  vmovaps xmm2, [rsp+0x20]
00007b2719bd5a1b  vmovaps xmm3, [rsp+0x30]
00007b2719bd5a21  vmovaps xmm4, [rsp+0x40]
00007b2719bd5a27  vmovaps xmm5, [rsp+0x50]
00007b2719bd5a2d  vmovaps xmm6, [rsp+0x60]
00007b2719bd5a33  vmovaps xmm7, [rsp+0x70]
00007b2719bd5a39  vmovaps xmm8, [rsp+0x80]
00007b2719bd5a42  vmovaps xmm9, [rsp+0x90]
00007b2719bd5a4b  vmovaps xmm10, [rsp+0xA0]
00007b2719bd5a54  vmovaps xmm11, [rsp+0xB0]
00007b2719bd5a5d  vmovaps xmm12, [rsp+0xC0]
00007b2719bd5a66  vmovaps xmm14, [rsp+0xD0]
00007b2719bd5a6f  vmovaps xmm15, [rsp+0xE0]
00007b2719bd5a78  add rsp, 0xF0
00007b2719bd5a7f  pop r11
00007b2719bd5a81  pop r10
00007b2719bd5a83  pop r9
00007b2719bd5a85  pop r8
00007b2719bd5a87  pop rsi
00007b2719bd5a88  pop rdi
00007b2719bd5a89  pop rdx
00007b2719bd5a8a  pop rcx
00007b2719bd5a8b  pop rax
00007b2719bd5a8c  add rsp, 0x08
00007b2719bd5a90  jmp 0x00007B2719BD30CF
00007b2719bd5a95  call 0x00007B2719A0E760
00007b2719bd5a9a  jmp 0x00007B2719BD30DC
00007b2719bd5a9f  call 0x00007B2719A0D4E0
00007b2719bd5aa4  jmp 0x00007B2719BD30E9
00007b2719bd5aa9  sub rsp, 0x08
00007b2719bd5aad  push rax
00007b2719bd5aae  push rcx
00007b2719bd5aaf  push rdx
00007b2719bd5ab0  push rdi
00007b2719bd5ab1  push rsi
00007b2719bd5ab2  push r8
00007b2719bd5ab4  push r9
00007b2719bd5ab6  push r10
00007b2719bd5ab8  push r11
00007b2719bd5aba  sub rsp, 0xF0
00007b2719bd5ac1  vmovaps [rsp], xmm0
00007b2719bd5ac6  vmovaps [rsp+0x10], xmm1
00007b2719bd5acc  vmovaps [rsp+0x20], xmm2
00007b2719bd5ad2  vmovaps [rsp+0x30], xmm3
00007b2719bd5ad8  vmovaps [rsp+0x40], xmm4
00007b2719bd5ade  vmovaps [rsp+0x50], xmm5
00007b2719bd5ae4  vmovaps [rsp+0x60], xmm6
00007b2719bd5aea  vmovaps [rsp+0x70], xmm7
00007b2719bd5af0  vmovaps [rsp+0x80], xmm8
00007b2719bd5af9  vmovaps [rsp+0x90], xmm9
00007b2719bd5b02  vmovaps [rsp+0xA0], xmm10
00007b2719bd5b0b  vmovaps [rsp+0xB0], xmm12
00007b2719bd5b14  vmovaps [rsp+0xC0], xmm13
00007b2719bd5b1d  vmovaps [rsp+0xD0], xmm14
00007b2719bd5b26  vmovaps [rsp+0xE0], xmm15
00007b2719bd5b2f  sub rsp, 0x40
00007b2719bd5b33  lea rdi, [rsp]
00007b2719bd5b37  lea rsi, [rsp+0x10]
00007b2719bd5b3c  lea rdx, [rsp+0x20]
00007b2719bd5b41  lea rcx, [rsp+0x30]
00007b2719bd5b46  mov r8d, 0x00
00007b2719bd5b4c  lea r9, [r15+0x3A8]
00007b2719bd5b53  movaps [rdi], xmm11
00007b2719bd5b57  movaps [rsi], xmm7
00007b2719bd5b5a  movaps [rdx], xmm1
00007b2719bd5b5d  movaps [rcx], xmm12
00007b2719bd5b61  mov rax, 0x5A8E6560CA50
00007b2719bd5b6b  call rax
00007b2719bd5b6d  movaps xmm11, [rsp]
00007b2719bd5b72  add rsp, 0x40
00007b2719bd5b76  vmovaps xmm0, [rsp]
00007b2719bd5b7b  vmovaps xmm1, [rsp+0x10]
00007b2719bd5b81  vmovaps xmm2, [rsp+0x20]
00007b2719bd5b87  vmovaps xmm3, [rsp+0x30]
00007b2719bd5b8d  vmovaps xmm4, [rsp+0x40]
00007b2719bd5b93  vmovaps xmm5, [rsp+0x50]
00007b2719bd5b99  vmovaps xmm6, [rsp+0x60]
00007b2719bd5b9f  vmovaps xmm7, [rsp+0x70]
00007b2719bd5ba5  vmovaps xmm8, [rsp+0x80]
00007b2719bd5bae  vmovaps xmm9, [rsp+0x90]
00007b2719bd5bb7  vmovaps xmm10, [rsp+0xA0]
00007b2719bd5bc0  vmovaps xmm12, [rsp+0xB0]
00007b2719bd5bc9  vmovaps xmm13, [rsp+0xC0]
00007b2719bd5bd2  vmovaps xmm14, [rsp+0xD0]
00007b2719bd5bdb  vmovaps xmm15, [rsp+0xE0]
00007b2719bd5be4  add rsp, 0xF0
00007b2719bd5beb  pop r11
00007b2719bd5bed  pop r10
00007b2719bd5bef  pop r9
00007b2719bd5bf1  pop r8
00007b2719bd5bf3  pop rsi
00007b2719bd5bf4  pop rdi
00007b2719bd5bf5  pop rdx
00007b2719bd5bf6  pop rcx
00007b2719bd5bf7  pop rax
00007b2719bd5bf8  add rsp, 0x08
00007b2719bd5bfc  jmp 0x00007B2719BD3122
00007b2719bd5c01  call 0x00007B27199FF430
00007b2719bd5c06  jmp 0x00007B2719BD3134
00007b2719bd5c0b  sub rsp, 0x08
00007b2719bd5c0f  push rax
00007b2719bd5c10  push rcx
00007b2719bd5c11  push rdx
00007b2719bd5c12  push rdi
00007b2719bd5c13  push rsi
00007b2719bd5c14  push r8
00007b2719bd5c16  push r9
00007b2719bd5c18  push r10
00007b2719bd5c1a  push r11
00007b2719bd5c1c  sub rsp, 0xF0
00007b2719bd5c23  vmovaps [rsp], xmm0
00007b2719bd5c28  vmovaps [rsp+0x10], xmm1
00007b2719bd5c2e  vmovaps [rsp+0x20], xmm2
00007b2719bd5c34  vmovaps [rsp+0x30], xmm3
00007b2719bd5c3a  vmovaps [rsp+0x40], xmm4
00007b2719bd5c40  vmovaps [rsp+0x50], xmm5
00007b2719bd5c46  vmovaps [rsp+0x60], xmm6
00007b2719bd5c4c  vmovaps [rsp+0x70], xmm7
00007b2719bd5c52  vmovaps [rsp+0x80], xmm8
00007b2719bd5c5b  vmovaps [rsp+0x90], xmm10
00007b2719bd5c64  vmovaps [rsp+0xA0], xmm11
00007b2719bd5c6d  vmovaps [rsp+0xB0], xmm12
00007b2719bd5c76  vmovaps [rsp+0xC0], xmm13
00007b2719bd5c7f  vmovaps [rsp+0xD0], xmm14
00007b2719bd5c88  vmovaps [rsp+0xE0], xmm15
00007b2719bd5c91  sub rsp, 0x40
00007b2719bd5c95  lea rdi, [rsp]
00007b2719bd5c99  lea rsi, [rsp+0x10]
00007b2719bd5c9e  lea rdx, [rsp+0x20]
00007b2719bd5ca3  lea rcx, [rsp+0x30]
00007b2719bd5ca8  mov r8d, 0x00
00007b2719bd5cae  lea r9, [r15+0x3A8]
00007b2719bd5cb5  movaps [rdi], xmm9
00007b2719bd5cb9  movaps [rsi], xmm8
00007b2719bd5cbd  movaps [rdx], xmm14
00007b2719bd5cc1  movaps [rcx], xmm12
00007b2719bd5cc5  mov rax, 0x5A8E6560CA50
00007b2719bd5ccf  call rax
00007b2719bd5cd1  movaps xmm9, [rsp]
00007b2719bd5cd6  add rsp, 0x40
00007b2719bd5cda  vmovaps xmm0, [rsp]
00007b2719bd5cdf  vmovaps xmm1, [rsp+0x10]
00007b2719bd5ce5  vmovaps xmm2, [rsp+0x20]
00007b2719bd5ceb  vmovaps xmm3, [rsp+0x30]
00007b2719bd5cf1  vmovaps xmm4, [rsp+0x40]
00007b2719bd5cf7  vmovaps xmm5, [rsp+0x50]
00007b2719bd5cfd  vmovaps xmm6, [rsp+0x60]
00007b2719bd5d03  vmovaps xmm7, [rsp+0x70]
00007b2719bd5d09  vmovaps xmm8, [rsp+0x80]
00007b2719bd5d12  vmovaps xmm10, [rsp+0x90]
00007b2719bd5d1b  vmovaps xmm11, [rsp+0xA0]
00007b2719bd5d24  vmovaps xmm12, [rsp+0xB0]
00007b2719bd5d2d  vmovaps xmm13, [rsp+0xC0]
00007b2719bd5d36  vmovaps xmm14, [rsp+0xD0]
00007b2719bd5d3f  vmovaps xmm15, [rsp+0xE0]
00007b2719bd5d48  add rsp, 0xF0
00007b2719bd5d4f  pop r11
00007b2719bd5d51  pop r10
00007b2719bd5d53  pop r9
00007b2719bd5d55  pop r8
00007b2719bd5d57  pop rsi
00007b2719bd5d58  pop rdi
00007b2719bd5d59  pop rdx
00007b2719bd5d5a  pop rcx
00007b2719bd5d5b  pop rax
00007b2719bd5d5c  add rsp, 0x08
00007b2719bd5d60  jmp 0x00007B2719BD3165
00007b2719bd5d65  sub rsp, 0x08
00007b2719bd5d69  push rax
00007b2719bd5d6a  push rcx
00007b2719bd5d6b  push rdx
00007b2719bd5d6c  push rdi
00007b2719bd5d6d  push rsi
00007b2719bd5d6e  push r8
00007b2719bd5d70  push r9
00007b2719bd5d72  push r10
00007b2719bd5d74  push r11
00007b2719bd5d76  sub rsp, 0xF0
00007b2719bd5d7d  vmovaps [rsp], xmm0
00007b2719bd5d82  vmovaps [rsp+0x10], xmm1
00007b2719bd5d88  vmovaps [rsp+0x20], xmm2
00007b2719bd5d8e  vmovaps [rsp+0x30], xmm3
00007b2719bd5d94  vmovaps [rsp+0x40], xmm4
00007b2719bd5d9a  vmovaps [rsp+0x50], xmm5
00007b2719bd5da0  vmovaps [rsp+0x60], xmm6
00007b2719bd5da6  vmovaps [rsp+0x70], xmm7
00007b2719bd5dac  vmovaps [rsp+0x80], xmm8
00007b2719bd5db5  vmovaps [rsp+0x90], xmm9
00007b2719bd5dbe  vmovaps [rsp+0xA0], xmm10
00007b2719bd5dc7  vmovaps [rsp+0xB0], xmm11
00007b2719bd5dd0  vmovaps [rsp+0xC0], xmm13
00007b2719bd5dd9  vmovaps [rsp+0xD0], xmm14
00007b2719bd5de2  vmovaps [rsp+0xE0], xmm15
00007b2719bd5deb  sub rsp, 0x40
00007b2719bd5def  lea rdi, [rsp]
00007b2719bd5df3  lea rsi, [rsp+0x10]
00007b2719bd5df8  lea rdx, [rsp+0x20]
00007b2719bd5dfd  lea rcx, [rsp+0x30]
00007b2719bd5e02  mov r8d, 0x00
00007b2719bd5e08  lea r9, [r15+0x3A8]
00007b2719bd5e0f  movaps [rdi], xmm12
00007b2719bd5e13  movaps [rsi], xmm10
00007b2719bd5e17  movaps [rdx], xmm15
00007b2719bd5e1b  movaps [rcx], xmm14
00007b2719bd5e1f  mov rax, 0x5A8E6560CA50
00007b2719bd5e29  call rax
00007b2719bd5e2b  movaps xmm12, [rsp]
00007b2719bd5e30  add rsp, 0x40
00007b2719bd5e34  vmovaps xmm0, [rsp]
00007b2719bd5e39  vmovaps xmm1, [rsp+0x10]
00007b2719bd5e3f  vmovaps xmm2, [rsp+0x20]
00007b2719bd5e45  vmovaps xmm3, [rsp+0x30]
00007b2719bd5e4b  vmovaps xmm4, [rsp+0x40]
00007b2719bd5e51  vmovaps xmm5, [rsp+0x50]
00007b2719bd5e57  vmovaps xmm6, [rsp+0x60]
00007b2719bd5e5d  vmovaps xmm7, [rsp+0x70]
00007b2719bd5e63  vmovaps xmm8, [rsp+0x80]
00007b2719bd5e6c  vmovaps xmm9, [rsp+0x90]
00007b2719bd5e75  vmovaps xmm10, [rsp+0xA0]
00007b2719bd5e7e  vmovaps xmm11, [rsp+0xB0]
00007b2719bd5e87  vmovaps xmm13, [rsp+0xC0]
00007b2719bd5e90  vmovaps xmm14, [rsp+0xD0]
00007b2719bd5e99  vmovaps xmm15, [rsp+0xE0]
00007b2719bd5ea2  add rsp, 0xF0
00007b2719bd5ea9  pop r11
00007b2719bd5eab  pop r10
00007b2719bd5ead  pop r9
00007b2719bd5eaf  pop r8
00007b2719bd5eb1  pop rsi
00007b2719bd5eb2  pop rdi
00007b2719bd5eb3  pop rdx
00007b2719bd5eb4  pop rcx
00007b2719bd5eb5  pop rax
00007b2719bd5eb6  add rsp, 0x08
00007b2719bd5eba  jmp 0x00007B2719BD3196
00007b2719bd5ebf  sub rsp, 0x08
00007b2719bd5ec3  push rax
00007b2719bd5ec4  push rcx
00007b2719bd5ec5  push rdx
00007b2719bd5ec6  push rdi
00007b2719bd5ec7  push rsi
00007b2719bd5ec8  push r8
00007b2719bd5eca  push r9
00007b2719bd5ecc  push r10
00007b2719bd5ece  push r11
00007b2719bd5ed0  sub rsp, 0xF0
00007b2719bd5ed7  vmovaps [rsp], xmm0
00007b2719bd5edc  vmovaps [rsp+0x10], xmm1
00007b2719bd5ee2  vmovaps [rsp+0x20], xmm2
00007b2719bd5ee8  vmovaps [rsp+0x30], xmm3
00007b2719bd5eee  vmovaps [rsp+0x40], xmm4
00007b2719bd5ef4  vmovaps [rsp+0x50], xmm5
00007b2719bd5efa  vmovaps [rsp+0x60], xmm6
00007b2719bd5f00  vmovaps [rsp+0x70], xmm7
00007b2719bd5f06  vmovaps [rsp+0x80], xmm8
00007b2719bd5f0f  vmovaps [rsp+0x90], xmm9
00007b2719bd5f18  vmovaps [rsp+0xA0], xmm10
00007b2719bd5f21  vmovaps [rsp+0xB0], xmm11
00007b2719bd5f2a  vmovaps [rsp+0xC0], xmm12
00007b2719bd5f33  vmovaps [rsp+0xD0], xmm13
00007b2719bd5f3c  vmovaps [rsp+0xE0], xmm15
00007b2719bd5f45  sub rsp, 0x40
00007b2719bd5f49  lea rdi, [rsp]
00007b2719bd5f4d  lea rsi, [rsp+0x10]
00007b2719bd5f52  lea rdx, [rsp+0x20]
00007b2719bd5f57  lea rcx, [rsp+0x30]
00007b2719bd5f5c  mov r8d, 0x00
00007b2719bd5f62  lea r9, [r15+0x3A8]
00007b2719bd5f69  movaps [rdi], xmm14
00007b2719bd5f6d  movaps [rsi], xmm13
00007b2719bd5f71  movaps [rdx], xmm1
00007b2719bd5f74  movaps [rcx], xmm15
00007b2719bd5f78  mov rax, 0x5A8E6560CA50
00007b2719bd5f82  call rax
00007b2719bd5f84  movaps xmm14, [rsp]
00007b2719bd5f89  add rsp, 0x40
00007b2719bd5f8d  vmovaps xmm0, [rsp]
00007b2719bd5f92  vmovaps xmm1, [rsp+0x10]
00007b2719bd5f98  vmovaps xmm2, [rsp+0x20]
00007b2719bd5f9e  vmovaps xmm3, [rsp+0x30]
00007b2719bd5fa4  vmovaps xmm4, [rsp+0x40]
00007b2719bd5faa  vmovaps xmm5, [rsp+0x50]
00007b2719bd5fb0  vmovaps xmm6, [rsp+0x60]
00007b2719bd5fb6  vmovaps xmm7, [rsp+0x70]
00007b2719bd5fbc  vmovaps xmm8, [rsp+0x80]
00007b2719bd5fc5  vmovaps xmm9, [rsp+0x90]
00007b2719bd5fce  vmovaps xmm10, [rsp+0xA0]
00007b2719bd5fd7  vmovaps xmm11, [rsp+0xB0]
00007b2719bd5fe0  vmovaps xmm12, [rsp+0xC0]
00007b2719bd5fe9  vmovaps xmm13, [rsp+0xD0]
00007b2719bd5ff2  vmovaps xmm15, [rsp+0xE0]
00007b2719bd5ffb  add rsp, 0xF0
00007b2719bd6002  pop r11
00007b2719bd6004  pop r10
00007b2719bd6006  pop r9
00007b2719bd6008  pop r8
00007b2719bd600a  pop rsi
00007b2719bd600b  pop rdi
00007b2719bd600c  pop rdx
00007b2719bd600d  pop rcx
00007b2719bd600e  pop rax
00007b2719bd600f  add rsp, 0x08
00007b2719bd6013  jmp 0x00007B2719BD31C7
00007b2719bd6018  call 0x00007B2719A079B0
00007b2719bd601d  jmp 0x00007B2719BD31DA
00007b2719bd6022  call 0x00007B2719A0B100
00007b2719bd6027  jmp 0x00007B2719BD31E5
00007b2719bd602c  call 0x00007B2719A09E90
00007b2719bd6031  jmp 0x00007B2719BD31F0
00007b2719bd6036  call 0x00007B2719A0D600
00007b2719bd603b  jmp 0x00007B2719BD31FB
00007b2719bd6040  int3
00007b2719bd6041  nop [rax+rax*1], ax
00007b2719bd604a  nop [rax+rax*1], ax
00007b2719bd6050  mov rax, [r15+0x40]
00007b2719bd6054  mov r14, [r15+0x58]
00007b2719bd6058  lea r12, [rax+r14*1]
00007b2719bd605c  vxorps xmm1, xmm1, xmm1
00007b2719bd6060  vpbroadcastq xmm1, xmm1
00007b2719bd6065  vxorps xmm15, xmm15, xmm15
00007b2719bd606a  vpbroadcastq xmm15, xmm15
00007b2719bd606f  lea rax, [r12+0x30]
00007b2719bd6074  mov r11, [r13+rax*1]
00007b2719bd6079  lea rax, [r12+0x38]
00007b2719bd607e  mov r10, [r13+rax*1]
00007b2719bd6083  movq xmm14, r11
00007b2719bd6088  movq xmm13, r10
00007b2719bd608d  movq xmm14, xmm14
00007b2719bd6092  movq xmm13, xmm13
00007b2719bd6097  vmovaps [rsp+0x10], xmm13
00007b2719bd609d  movq xmm13, xmm13
00007b2719bd60a2  movaps [r15+0x270], xmm13
00007b2719bd60aa  movaps xmm13, [r15+0x160]
00007b2719bd60b2  vmovaps [rsp+0x20], xmm13
00007b2719bd60b8  vmovaps xmm12, [rsp+0x20]
00007b2719bd60be  por xmm13, xmm12
00007b2719bd60c3  lea rax, [r12+0x20]
00007b2719bd60c8  mov r11, [r13+rax*1]
00007b2719bd60cd  lea rax, [r12+0x28]
00007b2719bd60d2  mov r10, [r13+rax*1]
00007b2719bd60d7  movq xmm12, r11
00007b2719bd60dc  movq xmm11, r10
00007b2719bd60e1  movq xmm12, xmm12
00007b2719bd60e6  movq xmm11, xmm11
00007b2719bd60eb  movaps xmm10, [r15+0x2D0]
00007b2719bd60f3  vmovaps [rsp+0x20], xmm10
00007b2719bd60f9  vmovaps xmm9, [rsp+0x20]
00007b2719bd60ff  por xmm10, xmm9
00007b2719bd6104  movaps xmm9, [r15+0x300]
00007b2719bd610c  vmovaps [rsp+0x20], xmm9
00007b2719bd6112  vmovaps xmm8, [rsp+0x20]
00007b2719bd6118  por xmm9, xmm8
00007b2719bd611d  movaps xmm8, [r15+0x2B0]
00007b2719bd6125  vmovaps [rsp+0x20], xmm8
00007b2719bd612b  vmovaps xmm7, [rsp+0x20]
00007b2719bd6131  por xmm8, xmm7
00007b2719bd6136  movaps xmm7, [r15+0x180]
00007b2719bd613e  vmovaps [rsp+0x20], xmm7
00007b2719bd6144  vmovaps xmm6, [rsp+0x20]
00007b2719bd614a  por xmm7, xmm6
00007b2719bd614e  lea rax, [r12+0x10]
00007b2719bd6153  mov r11, [r13+rax*1]
00007b2719bd6158  lea rax, [r12+0x18]
00007b2719bd615d  mov r10, [r13+rax*1]
00007b2719bd6162  movq xmm6, r11
00007b2719bd6167  movq xmm5, r10
00007b2719bd616c  movq xmm6, xmm6
00007b2719bd6170  movq xmm5, xmm5
00007b2719bd6174  movaps xmm4, [r15+0x200]
00007b2719bd617c  vmovaps [rsp+0x20], xmm4
00007b2719bd6182  vmovaps xmm3, [rsp+0x20]
00007b2719bd6188  por xmm4, xmm3
00007b2719bd618c  movaps xmm3, [r15+0x1F0]
00007b2719bd6194  vmovaps [rsp+0x20], xmm3
00007b2719bd619a  vmovaps xmm2, [rsp+0x20]
00007b2719bd61a0  por xmm3, xmm2
00007b2719bd61a4  movaps xmm2, [r15+0x2E0]
00007b2719bd61ac  vmovaps [rsp+0x20], xmm2
00007b2719bd61b2  vmovaps [rsp+0x30], xmm1
00007b2719bd61b8  vmovaps xmm1, [rsp+0x20]
00007b2719bd61be  por xmm2, xmm1
00007b2719bd61c2  movaps xmm1, [r15+0x2A0]
00007b2719bd61ca  vmovaps [rsp+0x20], xmm1
00007b2719bd61d0  vmovaps [rsp+0x40], xmm15
00007b2719bd61d6  vmovaps xmm15, [rsp+0x20]
00007b2719bd61dc  por xmm1, xmm15
00007b2719bd61e1  movaps xmm15, [r15+0x280]
00007b2719bd61e9  vmovaps [rsp+0x20], xmm15
00007b2719bd61ef  vmovaps [rsp+0x50], xmm1
00007b2719bd61f5  vmovaps xmm1, [rsp+0x20]
00007b2719bd61fb  por xmm15, xmm1
00007b2719bd6200  movaps xmm1, [r15+0x1C0]
00007b2719bd6208  vmovaps [rsp+0x20], xmm1
00007b2719bd620e  vmovaps [rsp+0x60], xmm15
00007b2719bd6214  vmovaps xmm15, [rsp+0x20]
00007b2719bd621a  por xmm1, xmm15
00007b2719bd621f  movaps xmm15, [r15+0x210]
00007b2719bd6227  vmovaps [rsp+0x20], xmm15
00007b2719bd622d  vmovaps [rsp+0x70], xmm1
00007b2719bd6233  vmovaps xmm1, [rsp+0x20]
00007b2719bd6239  por xmm15, xmm1
00007b2719bd623e  mov rax, [r13+r12*1]
00007b2719bd6243  vmovq xmm1, rax
00007b2719bd6248  vpbroadcastq xmm1, xmm1
00007b2719bd624d  vmovaps [rsp+0x20], xmm1
00007b2719bd6253  vxorps xmm1, xmm1, xmm1
00007b2719bd6257  vpbroadcastq xmm1, xmm1
00007b2719bd625c  mov rax, [r15+0xF8]
00007b2719bd6263  vmovaps [rsp+0x80], xmm1
00007b2719bd626c  movups xmm1, [r13+rax*1]
00007b2719bd6272  vmovaps [rsp+0x90], xmm1
00007b2719bd627b  vxorps xmm1, xmm1, xmm1
00007b2719bd627f  vpbroadcastq xmm1, xmm1
00007b2719bd6284  lea r11, [r12+0x08]
00007b2719bd6289  mov r12, [r13+r11*1]
00007b2719bd628e  vmovaps [rsp+0xA0], xmm1
00007b2719bd6297  movq xmm1, r12
00007b2719bd629c  movaps [r15+0x240], xmm1
00007b2719bd62a4  mov r12, [r15+0x50]
00007b2719bd62a8  lea r11, [r12+r14*1]
00007b2719bd62ac  mov [r15+0x60], r11
00007b2719bd62b0  lea r12, [r14+0x40]
00007b2719bd62b4  mov [r15+0x58], r12
00007b2719bd62b8  vmovaps xmm1, [rsp+0x30]
00007b2719bd62be  vmovaps [rsp+0x30], xmm15
00007b2719bd62c4  vmovaps xmm15, [rsp+0x90]
00007b2719bd62cd  vmovaps [rsp+0x90], xmm14
00007b2719bd62d6  vmovaps xmm14, [rsp+0x20]
00007b2719bd62dc  vmovaps [rsp+0x20], xmm13
00007b2719bd62e2  vmovaps [rsp+0xB0], xmm12
00007b2719bd62eb  movaps xmm13, xmm1
00007b2719bd62ef  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd62fa  vptest xmm12, xmm12
00007b2719bd62ff  jnz 0x00007B2719BD6D9C
00007b2719bd6305  movaps xmm1, [r15+0x250]
00007b2719bd630d  vmovaps xmm15, [rsp+0x40]
00007b2719bd6313  vmovaps [rsp+0x40], xmm13
00007b2719bd6319  movaps xmm12, xmm15
00007b2719bd631d  vfmadd231pd xmm12, xmm1, xmm14
00007b2719bd6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007b2719bd6328  vptest xmm13, xmm13
00007b2719bd632d  jnz 0x00007B2719BD6EF5
00007b2719bd6333  movaps xmm15, [r15+0x1E0]
00007b2719bd633b  vmovaps [rsp+0xC0], xmm15
00007b2719bd6344  vmovaps xmm13, [rsp+0xC0]
00007b2719bd634d  por xmm15, xmm13
00007b2719bd6352  movaps xmm13, [r15+0x1D0]
00007b2719bd635a  vmovaps [rsp+0xC0], xmm13
00007b2719bd6363  vmovaps [rsp+0xD0], xmm1
00007b2719bd636c  vmovaps xmm1, [rsp+0xC0]
00007b2719bd6375  por xmm13, xmm1
00007b2719bd637a  movaps xmm1, [r15+0x2C0]
00007b2719bd6382  vmovaps [rsp+0xC0], xmm1
00007b2719bd638b  vmovaps [rsp+0xE0], xmm15
00007b2719bd6394  vmovaps xmm15, [rsp+0xC0]
00007b2719bd639d  por xmm1, xmm15
00007b2719bd63a2  movaps xmm15, [r15+0x290]
00007b2719bd63aa  vmovaps [rsp+0xC0], xmm15
00007b2719bd63b3  vmovaps [rsp+0xF0], xmm1
00007b2719bd63bc  vmovaps xmm1, [rsp+0xC0]
00007b2719bd63c5  por xmm15, xmm1
00007b2719bd63ca  movaps xmm1, [r15+0x260]
00007b2719bd63d2  vmovaps [rsp+0xC0], xmm1
00007b2719bd63db  vmovaps [rsp+0x100], xmm15
00007b2719bd63e4  vmovaps xmm15, [rsp+0xC0]
00007b2719bd63ed  por xmm1, xmm15
00007b2719bd63f2  vmovaps xmm15, [rsp+0xD0]
00007b2719bd63fb  vmovaps [rsp+0xC0], xmm1
00007b2719bd6404  vmovaps xmm1, [rsp+0xD0]
00007b2719bd640d  por xmm15, xmm1
00007b2719bd6412  lea r14, [rax+0xC0]
00007b2719bd6419  movups xmm1, [r13+r14*1]
00007b2719bd641f  mov [rsp+0xD0], rax
00007b2719bd6427  xor eax, eax
00007b2719bd6429  mov r14d, 0x200
00007b2719bd642f  cmp r12, r14
00007b2719bd6432  cmc
00007b2719bd6433  lahf
00007b2719bd6434  seto al
00007b2719bd6437  mov [r15+0x108], eax
00007b2719bd643e  vmovaps [rsp+0x110], xmm1
00007b2719bd6447  vmovaps xmm1, [rsp+0x80]
00007b2719bd6450  vmovaps [rsp+0x80], xmm15
00007b2719bd6459  vmovaps xmm15, [rsp+0x110]
00007b2719bd6462  vmovaps [rsp+0x110], xmm13
00007b2719bd646b  vmovaps [rsp+0x120], xmm12
00007b2719bd6474  movaps xmm13, xmm1
00007b2719bd6478  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd6483  vptest xmm12, xmm12
00007b2719bd6488  jnz 0x00007B2719BD7058
00007b2719bd648e  mov rax, [rsp+0xD0]
00007b2719bd6496  lea r14, [rax+0xB0]
00007b2719bd649d  movups xmm1, [r13+r14*1]
00007b2719bd64a3  vmovaps xmm15, [rsp+0xA0]
00007b2719bd64ac  vmovaps [rsp+0xA0], xmm13
00007b2719bd64b5  movaps xmm12, xmm15
00007b2719bd64b9  vfmadd231pd xmm12, xmm1, xmm14
00007b2719bd64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007b2719bd64c4  vptest xmm13, xmm13
00007b2719bd64c9  jnz 0x00007B2719BD71BB
00007b2719bd64cf  vmovaps xmm1, [rsp+0x30]
00007b2719bd64d5  vmovaps xmm15, [rsp+0x30]
00007b2719bd64db  por xmm1, xmm15
00007b2719bd64e0  movaps [r15+0x210], xmm1
00007b2719bd64e8  vmovaps xmm15, [rsp+0x70]
00007b2719bd64ee  vmovaps xmm14, [rsp+0x70]
00007b2719bd64f4  por xmm15, xmm14
00007b2719bd64f9  movaps [r15+0x1C0], xmm15
00007b2719bd6501  vmovaps xmm14, [rsp+0x60]
00007b2719bd6507  vmovaps xmm13, [rsp+0x60]
00007b2719bd650d  por xmm14, xmm13
00007b2719bd6512  movaps [r15+0x280], xmm14
00007b2719bd651a  vmovaps xmm13, [rsp+0x50]
00007b2719bd6520  vmovaps [rsp+0x30], xmm1
00007b2719bd6526  vmovaps xmm1, [rsp+0x50]
00007b2719bd652c  por xmm13, xmm1
00007b2719bd6531  movaps [r15+0x2A0], xmm13
00007b2719bd6539  vmovaps [rsp+0x50], xmm2
00007b2719bd653f  vmovaps xmm1, [rsp+0x50]
00007b2719bd6545  por xmm2, xmm1
00007b2719bd6549  movaps [r15+0x2E0], xmm2
00007b2719bd6551  vmovaps [rsp+0x50], xmm3
00007b2719bd6557  vmovaps xmm1, [rsp+0x50]
00007b2719bd655d  por xmm3, xmm1
00007b2719bd6561  movaps [r15+0x1F0], xmm3
00007b2719bd6569  vmovaps xmm1, [rsp+0x80]
00007b2719bd6572  vmovaps [rsp+0x50], xmm15
00007b2719bd6578  vmovaps xmm15, [rsp+0x80]
00007b2719bd6581  por xmm1, xmm15
00007b2719bd6586  movaps [r15+0x250], xmm1
00007b2719bd658e  vmovaps xmm1, [rsp+0xC0]
00007b2719bd6597  vmovaps xmm15, [rsp+0xC0]
00007b2719bd65a0  por xmm1, xmm15
00007b2719bd65a5  movaps [r15+0x260], xmm1
00007b2719bd65ad  vmovaps xmm15, [rsp+0x100]
00007b2719bd65b6  vmovaps [rsp+0x60], xmm1
00007b2719bd65bc  vmovaps xmm1, [rsp+0x100]
00007b2719bd65c5  por xmm15, xmm1
00007b2719bd65ca  movaps [r15+0x290], xmm15
00007b2719bd65d2  vmovaps xmm1, [rsp+0xF0]
00007b2719bd65db  vmovaps [rsp+0x70], xmm15
00007b2719bd65e1  vmovaps xmm15, [rsp+0xF0]
00007b2719bd65ea  por xmm1, xmm15
00007b2719bd65ef  movaps [r15+0x2C0], xmm1
00007b2719bd65f7  movq xmm15, qword ptr [r15+0x240]
00007b2719bd6600  vmovaps [rsp+0x80], xmm15
00007b2719bd6609  vpermilpd xmm15, xmm15, 0x00
00007b2719bd660f  vmovaps [rsp+0xC0], xmm1
00007b2719bd6618  vmovaps xmm1, [rsp+0x40]
00007b2719bd661e  vmovaps [rsp+0x40], xmm15
00007b2719bd6624  vmovaps xmm15, [rsp+0x30]
00007b2719bd662a  vmovaps [rsp+0x30], xmm14
00007b2719bd6630  vmovaps xmm14, [rsp+0x40]
00007b2719bd6636  vmovaps [rsp+0x40], xmm13
00007b2719bd663c  vmovaps [rsp+0xD0], xmm12
00007b2719bd6645  movaps xmm13, xmm1
00007b2719bd6649  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd6654  vptest xmm12, xmm12
00007b2719bd6659  jnz 0x00007B2719BD7314
00007b2719bd665f  vmovaps xmm1, [rsp+0x80]
00007b2719bd6668  vpermilpd xmm1, xmm1, 0x00
00007b2719bd666e  vmovaps xmm15, [rsp+0xA0]
00007b2719bd6677  movaps xmm14, xmm15
00007b2719bd667b  vfmadd231pd xmm14, xmm2, xmm1
00007b2719bd6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007b2719bd6686  vptest xmm12, xmm12
00007b2719bd668b  jnz 0x00007B2719BD746D
00007b2719bd6691  vmovaps xmm1, [rsp+0x80]
00007b2719bd669a  vpermilpd xmm1, xmm1, 0x00
00007b2719bd66a0  vmovaps xmm15, [rsp+0x120]
00007b2719bd66a9  vmovaps xmm12, [rsp+0x50]
00007b2719bd66af  vmovaps [rsp+0x50], xmm14
00007b2719bd66b5  movaps xmm2, xmm15
00007b2719bd66b9  vfmadd231pd xmm2, xmm12, xmm1
00007b2719bd66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007b2719bd66c3  vptest xmm14, xmm14
00007b2719bd66c8  jnz 0x00007B2719BD75C5
00007b2719bd66ce  vmovaps xmm1, [rsp+0x110]
00007b2719bd66d7  vmovaps xmm15, [rsp+0x110]
00007b2719bd66e0  por xmm1, xmm15
00007b2719bd66e5  movaps [r15+0x1D0], xmm1
00007b2719bd66ed  vmovaps xmm15, [rsp+0x80]
00007b2719bd66f6  vpermilpd xmm15, xmm15, 0x00
00007b2719bd66fc  vmovaps xmm14, [rsp+0xD0]
00007b2719bd6705  vmovaps [rsp+0x80], xmm1
00007b2719bd670e  movaps xmm12, xmm14
00007b2719bd6712  vfmadd231pd xmm12, xmm3, xmm15
00007b2719bd6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007b2719bd671d  vptest xmm1, xmm1
00007b2719bd6722  jnz 0x00007B2719BD771C
00007b2719bd6728  vmovaps [rsp+0xA0], xmm4
00007b2719bd6731  vmovaps xmm1, [rsp+0xA0]
00007b2719bd673a  por xmm4, xmm1
00007b2719bd673e  movaps [r15+0x200], xmm4
00007b2719bd6746  vmovaps xmm1, [rsp+0xE0]
00007b2719bd674f  vmovaps xmm15, [rsp+0xE0]
00007b2719bd6758  por xmm1, xmm15
00007b2719bd675d  movaps [r15+0x1E0], xmm1
00007b2719bd6765  vmovaps [rsp+0xA0], xmm8
00007b2719bd676e  vmovaps xmm1, [rsp+0xA0]
00007b2719bd6777  por xmm8, xmm1
00007b2719bd677c  movaps [r15+0x2B0], xmm8
00007b2719bd6784  vmovaps [rsp+0xA0], xmm9
00007b2719bd678d  vmovaps xmm1, [rsp+0xA0]
00007b2719bd6796  por xmm9, xmm1
00007b2719bd679b  movaps [r15+0x300], xmm9
00007b2719bd67a3  vmovaps [rsp+0xA0], xmm6
00007b2719bd67ac  vpermilpd xmm6, xmm6, 0x00
00007b2719bd67b2  vmovaps xmm14, [rsp+0x60]
00007b2719bd67b8  movaps xmm9, xmm13
00007b2719bd67bc  vfmadd231pd xmm9, xmm14, xmm6
00007b2719bd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007b2719bd67c7  vptest xmm3, xmm3
00007b2719bd67cc  jnz 0x00007B2719BD7875
00007b2719bd67d2  vmovaps xmm14, [rsp+0xA0]
00007b2719bd67db  vpermilpd xmm14, xmm14, 0x00
00007b2719bd67e1  vmovaps xmm13, [rsp+0x50]
00007b2719bd67e7  vmovaps xmm6, [rsp+0xC0]
00007b2719bd67f0  vmovaps [rsp+0x50], xmm1
00007b2719bd67f6  movaps xmm3, xmm13
00007b2719bd67fa  vfmadd231pd xmm3, xmm6, xmm14
00007b2719bd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007b2719bd6804  vptest xmm1, xmm1
00007b2719bd6809  jnz 0x00007B2719BD79CE
00007b2719bd680f  vmovaps xmm1, [rsp+0xA0]
00007b2719bd6818  vpermilpd xmm1, xmm1, 0x00
00007b2719bd681e  vmovaps xmm14, [rsp+0x30]
00007b2719bd6824  movaps xmm6, xmm2
00007b2719bd6827  vfmadd231pd xmm6, xmm14, xmm1
00007b2719bd682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007b2719bd6831  vptest xmm13, xmm13
00007b2719bd6836  jnz 0x00007B2719BD7B25
00007b2719bd683c  vmovaps xmm1, [rsp+0xA0]
00007b2719bd6845  vpermilpd xmm1, xmm1, 0x00
00007b2719bd684b  vmovaps xmm14, [rsp+0x80]
00007b2719bd6854  movaps xmm13, xmm12
00007b2719bd6858  vfmadd231pd xmm13, xmm14, xmm1
00007b2719bd685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007b2719bd6863  vptest xmm2, xmm2
00007b2719bd6868  jnz 0x00007B2719BD7C7B
00007b2719bd686e  vmovaps [rsp+0x30], xmm7
00007b2719bd6874  vmovaps xmm1, [rsp+0x30]
00007b2719bd687a  por xmm7, xmm1
00007b2719bd687e  movaps [r15+0x180], xmm7
00007b2719bd6886  vmovaps [rsp+0x30], xmm10
00007b2719bd688c  vmovaps xmm1, [rsp+0x30]
00007b2719bd6892  por xmm10, xmm1
00007b2719bd6897  movaps [r15+0x2D0], xmm10
00007b2719bd689f  vmovaps [rsp+0x30], xmm5
00007b2719bd68a5  vpermilpd xmm5, xmm5, 0x00
00007b2719bd68ab  vmovaps xmm14, [rsp+0x50]
00007b2719bd68b1  movaps xmm12, xmm3
00007b2719bd68b5  vfmadd231pd xmm12, xmm14, xmm5
00007b2719bd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007b2719bd68c0  vptest xmm10, xmm10
00007b2719bd68c5  jnz 0x00007B2719BD7DD4
00007b2719bd68cb  vmovaps xmm14, [rsp+0x30]
00007b2719bd68d1  vpermilpd xmm14, xmm14, 0x00
00007b2719bd68d7  movaps xmm10, xmm9
00007b2719bd68db  vfmadd231pd xmm10, xmm7, xmm14
00007b2719bd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007b2719bd68e6  vptest xmm5, xmm5
00007b2719bd68eb  jnz 0x00007B2719BD7F2C
00007b2719bd68f1  lea r14, [rax+0x80]
00007b2719bd68f8  movups xmm14, [r13+r14*1]
00007b2719bd68fe  movaps [r15+0x2F0], xmm14
00007b2719bd6906  vmovaps xmm9, [rsp+0x30]
00007b2719bd690c  vpermilpd xmm9, xmm9, 0x00
00007b2719bd6912  vmovaps xmm7, [rsp+0x70]
00007b2719bd6918  movaps xmm5, xmm6
00007b2719bd691b  vfmadd231pd xmm5, xmm7, xmm9
00007b2719bd6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007b2719bd6925  vptest xmm3, xmm3
00007b2719bd692a  jnz 0x00007B2719BD808F
00007b2719bd6930  vmovaps xmm9, [rsp+0x30]
00007b2719bd6936  vpermilpd xmm9, xmm9, 0x00
00007b2719bd693c  movaps xmm7, xmm13
00007b2719bd6940  vfmadd231pd xmm7, xmm1, xmm9
00007b2719bd6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007b2719bd694a  vptest xmm6, xmm6
00007b2719bd694f  jnz 0x00007B2719BD81E5
00007b2719bd6955  vmovaps xmm1, [rsp+0x20]
00007b2719bd695b  vmovaps xmm13, [rsp+0x20]
00007b2719bd6961  por xmm1, xmm13
00007b2719bd6966  movaps [r15+0x160], xmm1
00007b2719bd696e  lea r14, [rax+0x40]
00007b2719bd6972  movups xmm13, [r13+r14*1]
00007b2719bd6978  lea r14, [rax+0x50]
00007b2719bd697c  movups xmm9, [r13+r14*1]
00007b2719bd6982  movaps [r15+0x1B0], xmm13
00007b2719bd698a  movaps [r15+0x1A0], xmm9
00007b2719bd6992  movaps xmm6, [r15+0x190]
00007b2719bd699a  vmovaps xmm3, [rsp+0xB0]
00007b2719bd69a3  vpermilpd xmm3, xmm3, 0x00
00007b2719bd69a9  vmovaps [rsp+0x20], xmm1
00007b2719bd69af  movaps xmm2, xmm12
00007b2719bd69b3  vfmadd231pd xmm2, xmm6, xmm3
00007b2719bd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007b2719bd69bd  vptest xmm1, xmm1
00007b2719bd69c2  jnz 0x00007B2719BD8350
00007b2719bd69c8  vmovaps xmm1, [rsp+0xB0]
00007b2719bd69d1  vpermilpd xmm1, xmm1, 0x00
00007b2719bd69d7  vmovaps xmm12, [rsp+0x20]
00007b2719bd69dd  movaps xmm6, xmm10
00007b2719bd69e1  vfmadd231pd xmm6, xmm12, xmm1
00007b2719bd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007b2719bd69eb  vptest xmm3, xmm3
00007b2719bd69f0  jnz 0x00007B2719BD84A6
00007b2719bd69f6  vmovaps xmm1, [rsp+0xB0]
00007b2719bd69ff  vpermilpd xmm1, xmm1, 0x00
00007b2719bd6a05  vmovaps xmm12, [rsp+0x40]
00007b2719bd6a0b  movaps xmm10, xmm5
00007b2719bd6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007b2719bd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007b2719bd6a1a  vptest xmm3, xmm3
00007b2719bd6a1f  jnz 0x00007B2719BD85FD
00007b2719bd6a25  vmovaps xmm1, [rsp+0xB0]
00007b2719bd6a2e  vpermilpd xmm1, xmm1, 0x00
00007b2719bd6a34  movaps xmm12, xmm7
00007b2719bd6a38  vfmadd231pd xmm12, xmm15, xmm1
00007b2719bd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007b2719bd6a43  vptest xmm5, xmm5
00007b2719bd6a48  jnz 0x00007B2719BD8755
00007b2719bd6a4e  lea r14, [rax+0x60]
00007b2719bd6a52  movups xmm1, [r13+r14*1]
00007b2719bd6a58  lea r14, [rax+0x70]
00007b2719bd6a5c  movups xmm15, [r13+r14*1]
00007b2719bd6a62  movaps [r15+0x150], xmm1
00007b2719bd6a6a  movaps [r15+0x120], xmm15
00007b2719bd6a72  vmovaps [rsp+0x20], xmm11
00007b2719bd6a78  vpermilpd xmm11, xmm11, 0x00
00007b2719bd6a7e  movaps xmm7, xmm2
00007b2719bd6a81  vfmadd231pd xmm7, xmm9, xmm11
00007b2719bd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007b2719bd6a8b  vptest xmm5, xmm5
00007b2719bd6a90  jnz 0x00007B2719BD88C1
00007b2719bd6a96  vmovaps xmm11, [rsp+0x20]
00007b2719bd6a9c  vpermilpd xmm11, xmm11, 0x00
00007b2719bd6aa2  movaps xmm9, xmm6
00007b2719bd6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007b2719bd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007b2719bd6ab1  vptest xmm5, xmm5
00007b2719bd6ab6  jnz 0x00007B2719BD8A18
00007b2719bd6abc  vmovaps xmm1, [rsp+0x20]
00007b2719bd6ac2  vpermilpd xmm1, xmm1, 0x00
00007b2719bd6ac8  movaps xmm11, xmm10
00007b2719bd6acc  vfmadd231pd xmm11, xmm8, xmm1
00007b2719bd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007b2719bd6ad7  vptest xmm6, xmm6
00007b2719bd6adc  jnz 0x00007B2719BD8B70
00007b2719bd6ae2  vmovaps xmm1, [rsp+0x20]
00007b2719bd6ae8  vpermilpd xmm1, xmm1, 0x00
00007b2719bd6aee  movaps xmm10, xmm12
00007b2719bd6af2  vfmadd231pd xmm10, xmm13, xmm1
00007b2719bd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007b2719bd6afd  vptest xmm8, xmm8
00007b2719bd6b02  jnz 0x00007B2719BD8CC9
00007b2719bd6b08  lea r14, [rax+0x20]
00007b2719bd6b0c  movups xmm1, [r13+r14*1]
00007b2719bd6b12  lea r14, [rax+0x30]
00007b2719bd6b16  movups xmm13, [r13+r14*1]
00007b2719bd6b1c  vmovaps xmm12, [rsp+0x90]
00007b2719bd6b25  vpermilpd xmm12, xmm12, 0x00
00007b2719bd6b2b  movaps xmm8, xmm7
00007b2719bd6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007b2719bd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007b2719bd6b3a  vptest xmm6, xmm6
00007b2719bd6b3f  jnz 0x00007B2719BD8E36
00007b2719bd6b45  vmovaps xmm12, [rsp+0x90]
00007b2719bd6b4e  vpermilpd xmm12, xmm12, 0x00
00007b2719bd6b54  movaps xmm7, xmm9
00007b2719bd6b58  vfmadd231pd xmm7, xmm14, xmm12
00007b2719bd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007b2719bd6b62  vptest xmm6, xmm6
00007b2719bd6b67  jnz 0x00007B2719BD8F8E
00007b2719bd6b6d  vmovaps xmm14, [rsp+0x90]
00007b2719bd6b76  vpermilpd xmm14, xmm14, 0x00
00007b2719bd6b7c  movaps xmm12, xmm11
00007b2719bd6b80  vfmadd231pd xmm12, xmm15, xmm14
00007b2719bd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007b2719bd6b8b  vptest xmm9, xmm9
00007b2719bd6b90  jnz 0x00007B2719BD90E6
00007b2719bd6b96  vmovaps xmm15, [rsp+0x90]
00007b2719bd6b9f  vpermilpd xmm15, xmm15, 0x00
00007b2719bd6ba5  movaps xmm11, xmm10
00007b2719bd6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007b2719bd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007b2719bd6bb4  vptest xmm14, xmm14
00007b2719bd6bb9  jnz 0x00007B2719BD9240
00007b2719bd6bbf  lea r14, [rax+0x90]
00007b2719bd6bc6  movups xmm15, [r13+r14*1]
00007b2719bd6bcc  lea r14, [rax+0xA0]
00007b2719bd6bd3  movups xmm14, [r13+r14*1]
00007b2719bd6bd9  movaps [r15+0x140], xmm15
00007b2719bd6be1  movaps [r15+0x130], xmm14
00007b2719bd6be9  vmovaps xmm13, [rsp+0x10]
00007b2719bd6bef  vpermilpd xmm13, xmm13, 0x00
00007b2719bd6bf5  movaps xmm10, xmm8
00007b2719bd6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007b2719bd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007b2719bd6c04  vptest xmm9, xmm9
00007b2719bd6c09  jnz 0x00007B2719BD93AE
00007b2719bd6c0f  movaps [r15+0x220], xmm10
00007b2719bd6c17  lea r14, [rax+0x10]
00007b2719bd6c1b  movups xmm1, [r13+r14*1]
00007b2719bd6c21  movaps [r15+0x240], xmm1
00007b2719bd6c29  vmovaps xmm13, [rsp+0x10]
00007b2719bd6c2f  vpermilpd xmm13, xmm13, 0x00
00007b2719bd6c35  movaps xmm9, xmm7
00007b2719bd6c39  vfmadd231pd xmm9, xmm14, xmm13
00007b2719bd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007b2719bd6c44  vptest xmm8, xmm8
00007b2719bd6c49  jnz 0x00007B2719BD9511
00007b2719bd6c4f  movaps [r15+0x110], xmm9
00007b2719bd6c57  vmovaps xmm14, [rsp+0x10]
00007b2719bd6c5d  vpermilpd xmm14, xmm14, 0x00
00007b2719bd6c63  movaps xmm13, xmm12
00007b2719bd6c67  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007b2719bd6c72  vptest xmm8, xmm8
00007b2719bd6c77  jnz 0x00007B2719BD966A
00007b2719bd6c7d  movaps [r15+0x170], xmm13
00007b2719bd6c85  vmovaps xmm15, [rsp+0x10]
00007b2719bd6c8b  vpermilpd xmm15, xmm15, 0x00
00007b2719bd6c91  movaps xmm14, xmm11
00007b2719bd6c95  vfmadd231pd xmm14, xmm1, xmm15
00007b2719bd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007b2719bd6ca0  vptest xmm12, xmm12
00007b2719bd6ca5  jnz 0x00007B2719BD97C4
00007b2719bd6cab  movaps [r15+0x230], xmm14
00007b2719bd6cb3  movups [r13+r11*1], xmm9
00007b2719bd6cb9  lea rax, [r11+0x10]
00007b2719bd6cbd  movups [r13+rax*1], xmm13
00007b2719bd6cc3  lea rax, [r11+0x20]
00007b2719bd6cc7  movups [r13+rax*1], xmm10
00007b2719bd6ccd  lea rax, [r11+0x30]
00007b2719bd6cd1  movups [r13+rax*1], xmm14
00007b2719bd6cd7  mov eax, [r15+0x108]
00007b2719bd6cde  sahf
00007b2719bd6cdf  jnz 0x00007B2719BD6D11
00007b2719bd6ce1  cmp dword ptr [r15+0x318], 0x00
00007b2719bd6ce9  jz 0x00007B2719BD9950
00007b2719bd6cef  nop [rax+rax*1], ax
00007b2719bd6cf8  nop [rax+rax*1], eax
00007b2719bd6d00  mov eax, 0x410664
00007b2719bd6d05  mov [r15+0x100], rax
00007b2719bd6d0c  jmp 0x00007B27199FE110
00007b2719bd6d11  cmp dword ptr [r15+0x318], 0x00
00007b2719bd6d19  jz 0x00007B2719BD6050
00007b2719bd6d1f  nop [rax+rax*1], ax
00007b2719bd6d28  nop [rax+rax*1], eax
00007b2719bd6d30  mov eax, 0x4104F0
00007b2719bd6d35  mov [r15+0x100], rax
00007b2719bd6d3c  jmp 0x00007B27199FE110
00007b2719bd6d41  int3
00007b2719bd6d42  call 0x00007B2719A0A4B0
00007b2719bd6d47  jmp 0x00007B2719BD6079
00007b2719bd6d4c  call 0x00007B2719A09240
00007b2719bd6d51  jmp 0x00007B2719BD6083
00007b2719bd6d56  call 0x00007B2719A0A4B0
00007b2719bd6d5b  jmp 0x00007B2719BD60CD
00007b2719bd6d60  call 0x00007B2719A09240
00007b2719bd6d65  jmp 0x00007B2719BD60D7
00007b2719bd6d6a  call 0x00007B2719A0A4B0
00007b2719bd6d6f  jmp 0x00007B2719BD6158
00007b2719bd6d74  call 0x00007B2719A09240
00007b2719bd6d79  jmp 0x00007B2719BD6162
00007b2719bd6d7e  call 0x00007B2719AB47C0
00007b2719bd6d83  jmp 0x00007B2719BD6243
00007b2719bd6d88  call 0x00007B27199FF430
00007b2719bd6d8d  jmp 0x00007B2719BD6272
00007b2719bd6d92  call 0x00007B2719AB0CE0
00007b2719bd6d97  jmp 0x00007B2719BD628E
00007b2719bd6d9c  sub rsp, 0x08
00007b2719bd6da0  push rax
00007b2719bd6da1  push rcx
00007b2719bd6da2  push rdx
00007b2719bd6da3  push rdi
00007b2719bd6da4  push rsi
00007b2719bd6da5  push r8
00007b2719bd6da7  push r9
00007b2719bd6da9  push r10
00007b2719bd6dab  push r11
00007b2719bd6dad  sub rsp, 0xF0
00007b2719bd6db4  vmovaps [rsp], xmm0
00007b2719bd6db9  vmovaps [rsp+0x10], xmm1
00007b2719bd6dbf  vmovaps [rsp+0x20], xmm2
00007b2719bd6dc5  vmovaps [rsp+0x30], xmm3
00007b2719bd6dcb  vmovaps [rsp+0x40], xmm4
00007b2719bd6dd1  vmovaps [rsp+0x50], xmm5
00007b2719bd6dd7  vmovaps [rsp+0x60], xmm6
00007b2719bd6ddd  vmovaps [rsp+0x70], xmm7
00007b2719bd6de3  vmovaps [rsp+0x80], xmm8
00007b2719bd6dec  vmovaps [rsp+0x90], xmm9
00007b2719bd6df5  vmovaps [rsp+0xA0], xmm10
00007b2719bd6dfe  vmovaps [rsp+0xB0], xmm11
00007b2719bd6e07  vmovaps [rsp+0xC0], xmm12
00007b2719bd6e10  vmovaps [rsp+0xD0], xmm14
00007b2719bd6e19  vmovaps [rsp+0xE0], xmm15
00007b2719bd6e22  sub rsp, 0x40
00007b2719bd6e26  lea rdi, [rsp]
00007b2719bd6e2a  lea rsi, [rsp+0x10]
00007b2719bd6e2f  lea rdx, [rsp+0x20]
00007b2719bd6e34  lea rcx, [rsp+0x30]
00007b2719bd6e39  mov r8d, 0x00
00007b2719bd6e3f  lea r9, [r15+0x3A8]
00007b2719bd6e46  movaps [rdi], xmm13
00007b2719bd6e4a  movaps [rsi], xmm1
00007b2719bd6e4d  movaps [rdx], xmm15
00007b2719bd6e51  movaps [rcx], xmm14
00007b2719bd6e55  mov rax, 0x5A8E6560CA50
00007b2719bd6e5f  call rax
00007b2719bd6e61  movaps xmm13, [rsp]
00007b2719bd6e66  add rsp, 0x40
00007b2719bd6e6a  vmovaps xmm0, [rsp]
00007b2719bd6e6f  vmovaps xmm1, [rsp+0x10]
00007b2719bd6e75  vmovaps xmm2, [rsp+0x20]
00007b2719bd6e7b  vmovaps xmm3, [rsp+0x30]
00007b2719bd6e81  vmovaps xmm4, [rsp+0x40]
00007b2719bd6e87  vmovaps xmm5, [rsp+0x50]
00007b2719bd6e8d  vmovaps xmm6, [rsp+0x60]
00007b2719bd6e93  vmovaps xmm7, [rsp+0x70]
00007b2719bd6e99  vmovaps xmm8, [rsp+0x80]
00007b2719bd6ea2  vmovaps xmm9, [rsp+0x90]
00007b2719bd6eab  vmovaps xmm10, [rsp+0xA0]
00007b2719bd6eb4  vmovaps xmm11, [rsp+0xB0]
00007b2719bd6ebd  vmovaps xmm12, [rsp+0xC0]
00007b2719bd6ec6  vmovaps xmm14, [rsp+0xD0]
00007b2719bd6ecf  vmovaps xmm15, [rsp+0xE0]
00007b2719bd6ed8  add rsp, 0xF0
00007b2719bd6edf  pop r11
00007b2719bd6ee1  pop r10
00007b2719bd6ee3  pop r9
00007b2719bd6ee5  pop r8
00007b2719bd6ee7  pop rsi
00007b2719bd6ee8  pop rdi
00007b2719bd6ee9  pop rdx
00007b2719bd6eea  pop rcx
00007b2719bd6eeb  pop rax
00007b2719bd6eec  add rsp, 0x08
00007b2719bd6ef0  jmp 0x00007B2719BD6305
00007b2719bd6ef5  sub rsp, 0x08
00007b2719bd6ef9  push rax
00007b2719bd6efa  push rcx
00007b2719bd6efb  push rdx
00007b2719bd6efc  push rdi
00007b2719bd6efd  push rsi
00007b2719bd6efe  push r8
00007b2719bd6f00  push r9
00007b2719bd6f02  push r10
00007b2719bd6f04  push r11
00007b2719bd6f06  sub rsp, 0xF0
00007b2719bd6f0d  vmovaps [rsp], xmm0
00007b2719bd6f12  vmovaps [rsp+0x10], xmm1
00007b2719bd6f18  vmovaps [rsp+0x20], xmm2
00007b2719bd6f1e  vmovaps [rsp+0x30], xmm3
00007b2719bd6f24  vmovaps [rsp+0x40], xmm4
00007b2719bd6f2a  vmovaps [rsp+0x50], xmm5
00007b2719bd6f30  vmovaps [rsp+0x60], xmm6
00007b2719bd6f36  vmovaps [rsp+0x70], xmm7
00007b2719bd6f3c  vmovaps [rsp+0x80], xmm8
00007b2719bd6f45  vmovaps [rsp+0x90], xmm9
00007b2719bd6f4e  vmovaps [rsp+0xA0], xmm10
00007b2719bd6f57  vmovaps [rsp+0xB0], xmm11
00007b2719bd6f60  vmovaps [rsp+0xC0], xmm13
00007b2719bd6f69  vmovaps [rsp+0xD0], xmm14
00007b2719bd6f72  vmovaps [rsp+0xE0], xmm15
00007b2719bd6f7b  sub rsp, 0x40
00007b2719bd6f7f  lea rdi, [rsp]
00007b2719bd6f83  lea rsi, [rsp+0x10]
00007b2719bd6f88  lea rdx, [rsp+0x20]
00007b2719bd6f8d  lea rcx, [rsp+0x30]
00007b2719bd6f92  mov r8d, 0x00
00007b2719bd6f98  lea r9, [r15+0x3A8]
00007b2719bd6f9f  movaps [rdi], xmm12
00007b2719bd6fa3  movaps [rsi], xmm15
00007b2719bd6fa7  movaps [rdx], xmm1
00007b2719bd6faa  movaps [rcx], xmm14
00007b2719bd6fae  mov rax, 0x5A8E6560CA50
00007b2719bd6fb8  call rax
00007b2719bd6fba  movaps xmm12, [rsp]
00007b2719bd6fbf  add rsp, 0x40
00007b2719bd6fc3  vmovaps xmm0, [rsp]
00007b2719bd6fc8  vmovaps xmm1, [rsp+0x10]
00007b2719bd6fce  vmovaps xmm2, [rsp+0x20]
00007b2719bd6fd4  vmovaps xmm3, [rsp+0x30]
00007b2719bd6fda  vmovaps xmm4, [rsp+0x40]
00007b2719bd6fe0  vmovaps xmm5, [rsp+0x50]
00007b2719bd6fe6  vmovaps xmm6, [rsp+0x60]
00007b2719bd6fec  vmovaps xmm7, [rsp+0x70]
00007b2719bd6ff2  vmovaps xmm8, [rsp+0x80]
00007b2719bd6ffb  vmovaps xmm9, [rsp+0x90]
00007b2719bd7004  vmovaps xmm10, [rsp+0xA0]
00007b2719bd700d  vmovaps xmm11, [rsp+0xB0]
00007b2719bd7016  vmovaps xmm13, [rsp+0xC0]
00007b2719bd701f  vmovaps xmm14, [rsp+0xD0]
00007b2719bd7028  vmovaps xmm15, [rsp+0xE0]
00007b2719bd7031  add rsp, 0xF0
00007b2719bd7038  pop r11
00007b2719bd703a  pop r10
00007b2719bd703c  pop r9
00007b2719bd703e  pop r8
00007b2719bd7040  pop rsi
00007b2719bd7041  pop rdi
00007b2719bd7042  pop rdx
00007b2719bd7043  pop rcx
00007b2719bd7044  pop rax
00007b2719bd7045  add rsp, 0x08
00007b2719bd7049  jmp 0x00007B2719BD6333
00007b2719bd704e  call 0x00007B2719AD64F0
00007b2719bd7053  jmp 0x00007B2719BD641F
00007b2719bd7058  sub rsp, 0x08
00007b2719bd705c  push rax
00007b2719bd705d  push rcx
00007b2719bd705e  push rdx
00007b2719bd705f  push rdi
00007b2719bd7060  push rsi
00007b2719bd7061  push r8
00007b2719bd7063  push r9
00007b2719bd7065  push r10
00007b2719bd7067  push r11
00007b2719bd7069  sub rsp, 0xF0
00007b2719bd7070  vmovaps [rsp], xmm0
00007b2719bd7075  vmovaps [rsp+0x10], xmm1
00007b2719bd707b  vmovaps [rsp+0x20], xmm2
00007b2719bd7081  vmovaps [rsp+0x30], xmm3
00007b2719bd7087  vmovaps [rsp+0x40], xmm4
00007b2719bd708d  vmovaps [rsp+0x50], xmm5
00007b2719bd7093  vmovaps [rsp+0x60], xmm6
00007b2719bd7099  vmovaps [rsp+0x70], xmm7
00007b2719bd709f  vmovaps [rsp+0x80], xmm8
00007b2719bd70a8  vmovaps [rsp+0x90], xmm9
00007b2719bd70b1  vmovaps [rsp+0xA0], xmm10
00007b2719bd70ba  vmovaps [rsp+0xB0], xmm11
00007b2719bd70c3  vmovaps [rsp+0xC0], xmm12
00007b2719bd70cc  vmovaps [rsp+0xD0], xmm14
00007b2719bd70d5  vmovaps [rsp+0xE0], xmm15
00007b2719bd70de  sub rsp, 0x40
00007b2719bd70e2  lea rdi, [rsp]
00007b2719bd70e6  lea rsi, [rsp+0x10]
00007b2719bd70eb  lea rdx, [rsp+0x20]
00007b2719bd70f0  lea rcx, [rsp+0x30]
00007b2719bd70f5  mov r8d, 0x00
00007b2719bd70fb  lea r9, [r15+0x3A8]
00007b2719bd7102  movaps [rdi], xmm13
00007b2719bd7106  movaps [rsi], xmm1
00007b2719bd7109  movaps [rdx], xmm15
00007b2719bd710d  movaps [rcx], xmm14
00007b2719bd7111  mov rax, 0x5A8E6560CA50
00007b2719bd711b  call rax
00007b2719bd711d  movaps xmm13, [rsp]
00007b2719bd7122  add rsp, 0x40
00007b2719bd7126  vmovaps xmm0, [rsp]
00007b2719bd712b  vmovaps xmm1, [rsp+0x10]
00007b2719bd7131  vmovaps xmm2, [rsp+0x20]
00007b2719bd7137  vmovaps xmm3, [rsp+0x30]
00007b2719bd713d  vmovaps xmm4, [rsp+0x40]
00007b2719bd7143  vmovaps xmm5, [rsp+0x50]
00007b2719bd7149  vmovaps xmm6, [rsp+0x60]
00007b2719bd714f  vmovaps xmm7, [rsp+0x70]
00007b2719bd7155  vmovaps xmm8, [rsp+0x80]
00007b2719bd715e  vmovaps xmm9, [rsp+0x90]
00007b2719bd7167  vmovaps xmm10, [rsp+0xA0]
00007b2719bd7170  vmovaps xmm11, [rsp+0xB0]
00007b2719bd7179  vmovaps xmm12, [rsp+0xC0]
00007b2719bd7182  vmovaps xmm14, [rsp+0xD0]
00007b2719bd718b  vmovaps xmm15, [rsp+0xE0]
00007b2719bd7194  add rsp, 0xF0
00007b2719bd719b  pop r11
00007b2719bd719d  pop r10
00007b2719bd719f  pop r9
00007b2719bd71a1  pop r8
00007b2719bd71a3  pop rsi
00007b2719bd71a4  pop rdi
00007b2719bd71a5  pop rdx
00007b2719bd71a6  pop rcx
00007b2719bd71a7  pop rax
00007b2719bd71a8  add rsp, 0x08
00007b2719bd71ac  jmp 0x00007B2719BD648E
00007b2719bd71b1  call 0x00007B2719AD64F0
00007b2719bd71b6  jmp 0x00007B2719BD64A3
00007b2719bd71bb  sub rsp, 0x08
00007b2719bd71bf  push rax
00007b2719bd71c0  push rcx
00007b2719bd71c1  push rdx
00007b2719bd71c2  push rdi
00007b2719bd71c3  push rsi
00007b2719bd71c4  push r8
00007b2719bd71c6  push r9
00007b2719bd71c8  push r10
00007b2719bd71ca  push r11
00007b2719bd71cc  sub rsp, 0xF0
00007b2719bd71d3  vmovaps [rsp], xmm0
00007b2719bd71d8  vmovaps [rsp+0x10], xmm1
00007b2719bd71de  vmovaps [rsp+0x20], xmm2
00007b2719bd71e4  vmovaps [rsp+0x30], xmm3
00007b2719bd71ea  vmovaps [rsp+0x40], xmm4
00007b2719bd71f0  vmovaps [rsp+0x50], xmm5
00007b2719bd71f6  vmovaps [rsp+0x60], xmm6
00007b2719bd71fc  vmovaps [rsp+0x70], xmm7
00007b2719bd7202  vmovaps [rsp+0x80], xmm8
00007b2719bd720b  vmovaps [rsp+0x90], xmm9
00007b2719bd7214  vmovaps [rsp+0xA0], xmm10
00007b2719bd721d  vmovaps [rsp+0xB0], xmm11
00007b2719bd7226  vmovaps [rsp+0xC0], xmm13
00007b2719bd722f  vmovaps [rsp+0xD0], xmm14
00007b2719bd7238  vmovaps [rsp+0xE0], xmm15
00007b2719bd7241  sub rsp, 0x40
00007b2719bd7245  lea rdi, [rsp]
00007b2719bd7249  lea rsi, [rsp+0x10]
00007b2719bd724e  lea rdx, [rsp+0x20]
00007b2719bd7253  lea rcx, [rsp+0x30]
00007b2719bd7258  mov r8d, 0x00
00007b2719bd725e  lea r9, [r15+0x3A8]
00007b2719bd7265  movaps [rdi], xmm12
00007b2719bd7269  movaps [rsi], xmm15
00007b2719bd726d  movaps [rdx], xmm1
00007b2719bd7270  movaps [rcx], xmm14
00007b2719bd7274  mov rax, 0x5A8E6560CA50
00007b2719bd727e  call rax
00007b2719bd7280  movaps xmm12, [rsp]
00007b2719bd7285  add rsp, 0x40
00007b2719bd7289  vmovaps xmm0, [rsp]
00007b2719bd728e  vmovaps xmm1, [rsp+0x10]
00007b2719bd7294  vmovaps xmm2, [rsp+0x20]
00007b2719bd729a  vmovaps xmm3, [rsp+0x30]
00007b2719bd72a0  vmovaps xmm4, [rsp+0x40]
00007b2719bd72a6  vmovaps xmm5, [rsp+0x50]
00007b2719bd72ac  vmovaps xmm6, [rsp+0x60]
00007b2719bd72b2  vmovaps xmm7, [rsp+0x70]
00007b2719bd72b8  vmovaps xmm8, [rsp+0x80]
00007b2719bd72c1  vmovaps xmm9, [rsp+0x90]
00007b2719bd72ca  vmovaps xmm10, [rsp+0xA0]
00007b2719bd72d3  vmovaps xmm11, [rsp+0xB0]
00007b2719bd72dc  vmovaps xmm13, [rsp+0xC0]
00007b2719bd72e5  vmovaps xmm14, [rsp+0xD0]
00007b2719bd72ee  vmovaps xmm15, [rsp+0xE0]
00007b2719bd72f7  add rsp, 0xF0
00007b2719bd72fe  pop r11
00007b2719bd7300  pop r10
00007b2719bd7302  pop r9
00007b2719bd7304  pop r8
00007b2719bd7306  pop rsi
00007b2719bd7307  pop rdi
00007b2719bd7308  pop rdx
00007b2719bd7309  pop rcx
00007b2719bd730a  pop rax
00007b2719bd730b  add rsp, 0x08
00007b2719bd730f  jmp 0x00007B2719BD64CF
00007b2719bd7314  sub rsp, 0x08
00007b2719bd7318  push rax
00007b2719bd7319  push rcx
00007b2719bd731a  push rdx
00007b2719bd731b  push rdi
00007b2719bd731c  push rsi
00007b2719bd731d  push r8
00007b2719bd731f  push r9
00007b2719bd7321  push r10
00007b2719bd7323  push r11
00007b2719bd7325  sub rsp, 0xF0
00007b2719bd732c  vmovaps [rsp], xmm0
00007b2719bd7331  vmovaps [rsp+0x10], xmm1
00007b2719bd7337  vmovaps [rsp+0x20], xmm2
00007b2719bd733d  vmovaps [rsp+0x30], xmm3
00007b2719bd7343  vmovaps [rsp+0x40], xmm4
00007b2719bd7349  vmovaps [rsp+0x50], xmm5
00007b2719bd734f  vmovaps [rsp+0x60], xmm6
00007b2719bd7355  vmovaps [rsp+0x70], xmm7
00007b2719bd735b  vmovaps [rsp+0x80], xmm8
00007b2719bd7364  vmovaps [rsp+0x90], xmm9
00007b2719bd736d  vmovaps [rsp+0xA0], xmm10
00007b2719bd7376  vmovaps [rsp+0xB0], xmm11
00007b2719bd737f  vmovaps [rsp+0xC0], xmm12
00007b2719bd7388  vmovaps [rsp+0xD0], xmm14
00007b2719bd7391  vmovaps [rsp+0xE0], xmm15
00007b2719bd739a  sub rsp, 0x40
00007b2719bd739e  lea rdi, [rsp]
00007b2719bd73a2  lea rsi, [rsp+0x10]
00007b2719bd73a7  lea rdx, [rsp+0x20]
00007b2719bd73ac  lea rcx, [rsp+0x30]
00007b2719bd73b1  mov r8d, 0x00
00007b2719bd73b7  lea r9, [r15+0x3A8]
00007b2719bd73be  movaps [rdi], xmm13
00007b2719bd73c2  movaps [rsi], xmm1
00007b2719bd73c5  movaps [rdx], xmm15
00007b2719bd73c9  movaps [rcx], xmm14
00007b2719bd73cd  mov rax, 0x5A8E6560CA50
00007b2719bd73d7  call rax
00007b2719bd73d9  movaps xmm13, [rsp]
00007b2719bd73de  add rsp, 0x40
00007b2719bd73e2  vmovaps xmm0, [rsp]
00007b2719bd73e7  vmovaps xmm1, [rsp+0x10]
00007b2719bd73ed  vmovaps xmm2, [rsp+0x20]
00007b2719bd73f3  vmovaps xmm3, [rsp+0x30]
00007b2719bd73f9  vmovaps xmm4, [rsp+0x40]
00007b2719bd73ff  vmovaps xmm5, [rsp+0x50]
00007b2719bd7405  vmovaps xmm6, [rsp+0x60]
00007b2719bd740b  vmovaps xmm7, [rsp+0x70]
00007b2719bd7411  vmovaps xmm8, [rsp+0x80]
00007b2719bd741a  vmovaps xmm9, [rsp+0x90]
00007b2719bd7423  vmovaps xmm10, [rsp+0xA0]
00007b2719bd742c  vmovaps xmm11, [rsp+0xB0]
00007b2719bd7435  vmovaps xmm12, [rsp+0xC0]
00007b2719bd743e  vmovaps xmm14, [rsp+0xD0]
00007b2719bd7447  vmovaps xmm15, [rsp+0xE0]
00007b2719bd7450  add rsp, 0xF0
00007b2719bd7457  pop r11
00007b2719bd7459  pop r10
00007b2719bd745b  pop r9
00007b2719bd745d  pop r8
00007b2719bd745f  pop rsi
00007b2719bd7460  pop rdi
00007b2719bd7461  pop rdx
00007b2719bd7462  pop rcx
00007b2719bd7463  pop rax
00007b2719bd7464  add rsp, 0x08
00007b2719bd7468  jmp 0x00007B2719BD665F
00007b2719bd746d  sub rsp, 0x08
00007b2719bd7471  push rax
00007b2719bd7472  push rcx
00007b2719bd7473  push rdx
00007b2719bd7474  push rdi
00007b2719bd7475  push rsi
00007b2719bd7476  push r8
00007b2719bd7478  push r9
00007b2719bd747a  push r10
00007b2719bd747c  push r11
00007b2719bd747e  sub rsp, 0xF0
00007b2719bd7485  vmovaps [rsp], xmm0
00007b2719bd748a  vmovaps [rsp+0x10], xmm1
00007b2719bd7490  vmovaps [rsp+0x20], xmm2
00007b2719bd7496  vmovaps [rsp+0x30], xmm3
00007b2719bd749c  vmovaps [rsp+0x40], xmm4
00007b2719bd74a2  vmovaps [rsp+0x50], xmm5
00007b2719bd74a8  vmovaps [rsp+0x60], xmm6
00007b2719bd74ae  vmovaps [rsp+0x70], xmm7
00007b2719bd74b4  vmovaps [rsp+0x80], xmm8
00007b2719bd74bd  vmovaps [rsp+0x90], xmm9
00007b2719bd74c6  vmovaps [rsp+0xA0], xmm10
00007b2719bd74cf  vmovaps [rsp+0xB0], xmm11
00007b2719bd74d8  vmovaps [rsp+0xC0], xmm12
00007b2719bd74e1  vmovaps [rsp+0xD0], xmm13
00007b2719bd74ea  vmovaps [rsp+0xE0], xmm15
00007b2719bd74f3  sub rsp, 0x40
00007b2719bd74f7  lea rdi, [rsp]
00007b2719bd74fb  lea rsi, [rsp+0x10]
00007b2719bd7500  lea rdx, [rsp+0x20]
00007b2719bd7505  lea rcx, [rsp+0x30]
00007b2719bd750a  mov r8d, 0x00
00007b2719bd7510  lea r9, [r15+0x3A8]
00007b2719bd7517  movaps [rdi], xmm14
00007b2719bd751b  movaps [rsi], xmm15
00007b2719bd751f  movaps [rdx], xmm2
00007b2719bd7522  movaps [rcx], xmm1
00007b2719bd7525  mov rax, 0x5A8E6560CA50
00007b2719bd752f  call rax
00007b2719bd7531  movaps xmm14, [rsp]
00007b2719bd7536  add rsp, 0x40
00007b2719bd753a  vmovaps xmm0, [rsp]
00007b2719bd753f  vmovaps xmm1, [rsp+0x10]
00007b2719bd7545  vmovaps xmm2, [rsp+0x20]
00007b2719bd754b  vmovaps xmm3, [rsp+0x30]
00007b2719bd7551  vmovaps xmm4, [rsp+0x40]
00007b2719bd7557  vmovaps xmm5, [rsp+0x50]
00007b2719bd755d  vmovaps xmm6, [rsp+0x60]
00007b2719bd7563  vmovaps xmm7, [rsp+0x70]
00007b2719bd7569  vmovaps xmm8, [rsp+0x80]
00007b2719bd7572  vmovaps xmm9, [rsp+0x90]
00007b2719bd757b  vmovaps xmm10, [rsp+0xA0]
00007b2719bd7584  vmovaps xmm11, [rsp+0xB0]
00007b2719bd758d  vmovaps xmm12, [rsp+0xC0]
00007b2719bd7596  vmovaps xmm13, [rsp+0xD0]
00007b2719bd759f  vmovaps xmm15, [rsp+0xE0]
00007b2719bd75a8  add rsp, 0xF0
00007b2719bd75af  pop r11
00007b2719bd75b1  pop r10
00007b2719bd75b3  pop r9
00007b2719bd75b5  pop r8
00007b2719bd75b7  pop rsi
00007b2719bd75b8  pop rdi
00007b2719bd75b9  pop rdx
00007b2719bd75ba  pop rcx
00007b2719bd75bb  pop rax
00007b2719bd75bc  add rsp, 0x08
00007b2719bd75c0  jmp 0x00007B2719BD6691
00007b2719bd75c5  sub rsp, 0x08
00007b2719bd75c9  push rax
00007b2719bd75ca  push rcx
00007b2719bd75cb  push rdx
00007b2719bd75cc  push rdi
00007b2719bd75cd  push rsi
00007b2719bd75ce  push r8
00007b2719bd75d0  push r9
00007b2719bd75d2  push r10
00007b2719bd75d4  push r11
00007b2719bd75d6  sub rsp, 0xF0
00007b2719bd75dd  vmovaps [rsp], xmm0
00007b2719bd75e2  vmovaps [rsp+0x10], xmm1
00007b2719bd75e8  vmovaps [rsp+0x20], xmm3
00007b2719bd75ee  vmovaps [rsp+0x30], xmm4
00007b2719bd75f4  vmovaps [rsp+0x40], xmm5
00007b2719bd75fa  vmovaps [rsp+0x50], xmm6
00007b2719bd7600  vmovaps [rsp+0x60], xmm7
00007b2719bd7606  vmovaps [rsp+0x70], xmm8
00007b2719bd760c  vmovaps [rsp+0x80], xmm9
00007b2719bd7615  vmovaps [rsp+0x90], xmm10
00007b2719bd761e  vmovaps [rsp+0xA0], xmm11
00007b2719bd7627  vmovaps [rsp+0xB0], xmm12
00007b2719bd7630  vmovaps [rsp+0xC0], xmm13
00007b2719bd7639  vmovaps [rsp+0xD0], xmm14
00007b2719bd7642  vmovaps [rsp+0xE0], xmm15
00007b2719bd764b  sub rsp, 0x40
00007b2719bd764f  lea rdi, [rsp]
00007b2719bd7653  lea rsi, [rsp+0x10]
00007b2719bd7658  lea rdx, [rsp+0x20]
00007b2719bd765d  lea rcx, [rsp+0x30]
00007b2719bd7662  mov r8d, 0x00
00007b2719bd7668  lea r9, [r15+0x3A8]
00007b2719bd766f  movaps [rdi], xmm2
00007b2719bd7672  movaps [rsi], xmm15
00007b2719bd7676  movaps [rdx], xmm12
00007b2719bd767a  movaps [rcx], xmm1
00007b2719bd767d  mov rax, 0x5A8E6560CA50
00007b2719bd7687  call rax
00007b2719bd7689  movaps xmm2, [rsp]
00007b2719bd768d  add rsp, 0x40
00007b2719bd7691  vmovaps xmm0, [rsp]
00007b2719bd7696  vmovaps xmm1, [rsp+0x10]
00007b2719bd769c  vmovaps xmm3, [rsp+0x20]
00007b2719bd76a2  vmovaps xmm4, [rsp+0x30]
00007b2719bd76a8  vmovaps xmm5, [rsp+0x40]
00007b2719bd76ae  vmovaps xmm6, [rsp+0x50]
00007b2719bd76b4  vmovaps xmm7, [rsp+0x60]
00007b2719bd76ba  vmovaps xmm8, [rsp+0x70]
00007b2719bd76c0  vmovaps xmm9, [rsp+0x80]
00007b2719bd76c9  vmovaps xmm10, [rsp+0x90]
00007b2719bd76d2  vmovaps xmm11, [rsp+0xA0]
00007b2719bd76db  vmovaps xmm12, [rsp+0xB0]
00007b2719bd76e4  vmovaps xmm13, [rsp+0xC0]
00007b2719bd76ed  vmovaps xmm14, [rsp+0xD0]
00007b2719bd76f6  vmovaps xmm15, [rsp+0xE0]
00007b2719bd76ff  add rsp, 0xF0
00007b2719bd7706  pop r11
00007b2719bd7708  pop r10
00007b2719bd770a  pop r9
00007b2719bd770c  pop r8
00007b2719bd770e  pop rsi
00007b2719bd770f  pop rdi
00007b2719bd7710  pop rdx
00007b2719bd7711  pop rcx
00007b2719bd7712  pop rax
00007b2719bd7713  add rsp, 0x08
00007b2719bd7717  jmp 0x00007B2719BD66CE
00007b2719bd771c  sub rsp, 0x08
00007b2719bd7720  push rax
00007b2719bd7721  push rcx
00007b2719bd7722  push rdx
00007b2719bd7723  push rdi
00007b2719bd7724  push rsi
00007b2719bd7725  push r8
00007b2719bd7727  push r9
00007b2719bd7729  push r10
00007b2719bd772b  push r11
00007b2719bd772d  sub rsp, 0xF0
00007b2719bd7734  vmovaps [rsp], xmm0
00007b2719bd7739  vmovaps [rsp+0x10], xmm1
00007b2719bd773f  vmovaps [rsp+0x20], xmm2
00007b2719bd7745  vmovaps [rsp+0x30], xmm3
00007b2719bd774b  vmovaps [rsp+0x40], xmm4
00007b2719bd7751  vmovaps [rsp+0x50], xmm5
00007b2719bd7757  vmovaps [rsp+0x60], xmm6
00007b2719bd775d  vmovaps [rsp+0x70], xmm7
00007b2719bd7763  vmovaps [rsp+0x80], xmm8
00007b2719bd776c  vmovaps [rsp+0x90], xmm9
00007b2719bd7775  vmovaps [rsp+0xA0], xmm10
00007b2719bd777e  vmovaps [rsp+0xB0], xmm11
00007b2719bd7787  vmovaps [rsp+0xC0], xmm13
00007b2719bd7790  vmovaps [rsp+0xD0], xmm14
00007b2719bd7799  vmovaps [rsp+0xE0], xmm15
00007b2719bd77a2  sub rsp, 0x40
00007b2719bd77a6  lea rdi, [rsp]
00007b2719bd77aa  lea rsi, [rsp+0x10]
00007b2719bd77af  lea rdx, [rsp+0x20]
00007b2719bd77b4  lea rcx, [rsp+0x30]
00007b2719bd77b9  mov r8d, 0x00
00007b2719bd77bf  lea r9, [r15+0x3A8]
00007b2719bd77c6  movaps [rdi], xmm12
00007b2719bd77ca  movaps [rsi], xmm14
00007b2719bd77ce  movaps [rdx], xmm3
00007b2719bd77d1  movaps [rcx], xmm15
00007b2719bd77d5  mov rax, 0x5A8E6560CA50
00007b2719bd77df  call rax
00007b2719bd77e1  movaps xmm12, [rsp]
00007b2719bd77e6  add rsp, 0x40
00007b2719bd77ea  vmovaps xmm0, [rsp]
00007b2719bd77ef  vmovaps xmm1, [rsp+0x10]
00007b2719bd77f5  vmovaps xmm2, [rsp+0x20]
00007b2719bd77fb  vmovaps xmm3, [rsp+0x30]
00007b2719bd7801  vmovaps xmm4, [rsp+0x40]
00007b2719bd7807  vmovaps xmm5, [rsp+0x50]
00007b2719bd780d  vmovaps xmm6, [rsp+0x60]
00007b2719bd7813  vmovaps xmm7, [rsp+0x70]
00007b2719bd7819  vmovaps xmm8, [rsp+0x80]
00007b2719bd7822  vmovaps xmm9, [rsp+0x90]
00007b2719bd782b  vmovaps xmm10, [rsp+0xA0]
00007b2719bd7834  vmovaps xmm11, [rsp+0xB0]
00007b2719bd783d  vmovaps xmm13, [rsp+0xC0]
00007b2719bd7846  vmovaps xmm14, [rsp+0xD0]
00007b2719bd784f  vmovaps xmm15, [rsp+0xE0]
00007b2719bd7858  add rsp, 0xF0
00007b2719bd785f  pop r11
00007b2719bd7861  pop r10
00007b2719bd7863  pop r9
00007b2719bd7865  pop r8
00007b2719bd7867  pop rsi
00007b2719bd7868  pop rdi
00007b2719bd7869  pop rdx
00007b2719bd786a  pop rcx
00007b2719bd786b  pop rax
00007b2719bd786c  add rsp, 0x08
00007b2719bd7870  jmp 0x00007B2719BD6728
00007b2719bd7875  sub rsp, 0x08
00007b2719bd7879  push rax
00007b2719bd787a  push rcx
00007b2719bd787b  push rdx
00007b2719bd787c  push rdi
00007b2719bd787d  push rsi
00007b2719bd787e  push r8
00007b2719bd7880  push r9
00007b2719bd7882  push r10
00007b2719bd7884  push r11
00007b2719bd7886  sub rsp, 0xF0
00007b2719bd788d  vmovaps [rsp], xmm0
00007b2719bd7892  vmovaps [rsp+0x10], xmm1
00007b2719bd7898  vmovaps [rsp+0x20], xmm2
00007b2719bd789e  vmovaps [rsp+0x30], xmm3
00007b2719bd78a4  vmovaps [rsp+0x40], xmm4
00007b2719bd78aa  vmovaps [rsp+0x50], xmm5
00007b2719bd78b0  vmovaps [rsp+0x60], xmm6
00007b2719bd78b6  vmovaps [rsp+0x70], xmm7
00007b2719bd78bc  vmovaps [rsp+0x80], xmm8
00007b2719bd78c5  vmovaps [rsp+0x90], xmm10
00007b2719bd78ce  vmovaps [rsp+0xA0], xmm11
00007b2719bd78d7  vmovaps [rsp+0xB0], xmm12
00007b2719bd78e0  vmovaps [rsp+0xC0], xmm13
00007b2719bd78e9  vmovaps [rsp+0xD0], xmm14
00007b2719bd78f2  vmovaps [rsp+0xE0], xmm15
00007b2719bd78fb  sub rsp, 0x40
00007b2719bd78ff  lea rdi, [rsp]
00007b2719bd7903  lea rsi, [rsp+0x10]
00007b2719bd7908  lea rdx, [rsp+0x20]
00007b2719bd790d  lea rcx, [rsp+0x30]
00007b2719bd7912  mov r8d, 0x00
00007b2719bd7918  lea r9, [r15+0x3A8]
00007b2719bd791f  movaps [rdi], xmm9
00007b2719bd7923  movaps [rsi], xmm13
00007b2719bd7927  movaps [rdx], xmm14
00007b2719bd792b  movaps [rcx], xmm6
00007b2719bd792e  mov rax, 0x5A8E6560CA50
00007b2719bd7938  call rax
00007b2719bd793a  movaps xmm9, [rsp]
00007b2719bd793f  add rsp, 0x40
00007b2719bd7943  vmovaps xmm0, [rsp]
00007b2719bd7948  vmovaps xmm1, [rsp+0x10]
00007b2719bd794e  vmovaps xmm2, [rsp+0x20]
00007b2719bd7954  vmovaps xmm3, [rsp+0x30]
00007b2719bd795a  vmovaps xmm4, [rsp+0x40]
00007b2719bd7960  vmovaps xmm5, [rsp+0x50]
00007b2719bd7966  vmovaps xmm6, [rsp+0x60]
00007b2719bd796c  vmovaps xmm7, [rsp+0x70]
00007b2719bd7972  vmovaps xmm8, [rsp+0x80]
00007b2719bd797b  vmovaps xmm10, [rsp+0x90]
00007b2719bd7984  vmovaps xmm11, [rsp+0xA0]
00007b2719bd798d  vmovaps xmm12, [rsp+0xB0]
00007b2719bd7996  vmovaps xmm13, [rsp+0xC0]
00007b2719bd799f  vmovaps xmm14, [rsp+0xD0]
00007b2719bd79a8  vmovaps xmm15, [rsp+0xE0]
00007b2719bd79b1  add rsp, 0xF0
00007b2719bd79b8  pop r11
00007b2719bd79ba  pop r10
00007b2719bd79bc  pop r9
00007b2719bd79be  pop r8
00007b2719bd79c0  pop rsi
00007b2719bd79c1  pop rdi
00007b2719bd79c2  pop rdx
00007b2719bd79c3  pop rcx
00007b2719bd79c4  pop rax
00007b2719bd79c5  add rsp, 0x08
00007b2719bd79c9  jmp 0x00007B2719BD67D2
00007b2719bd79ce  sub rsp, 0x08
00007b2719bd79d2  push rax
00007b2719bd79d3  push rcx
00007b2719bd79d4  push rdx
00007b2719bd79d5  push rdi
00007b2719bd79d6  push rsi
00007b2719bd79d7  push r8
00007b2719bd79d9  push r9
00007b2719bd79db  push r10
00007b2719bd79dd  push r11
00007b2719bd79df  sub rsp, 0xF0
00007b2719bd79e6  vmovaps [rsp], xmm0
00007b2719bd79eb  vmovaps [rsp+0x10], xmm1
00007b2719bd79f1  vmovaps [rsp+0x20], xmm2
00007b2719bd79f7  vmovaps [rsp+0x30], xmm4
00007b2719bd79fd  vmovaps [rsp+0x40], xmm5
00007b2719bd7a03  vmovaps [rsp+0x50], xmm6
00007b2719bd7a09  vmovaps [rsp+0x60], xmm7
00007b2719bd7a0f  vmovaps [rsp+0x70], xmm8
00007b2719bd7a15  vmovaps [rsp+0x80], xmm9
00007b2719bd7a1e  vmovaps [rsp+0x90], xmm10
00007b2719bd7a27  vmovaps [rsp+0xA0], xmm11
00007b2719bd7a30  vmovaps [rsp+0xB0], xmm12
00007b2719bd7a39  vmovaps [rsp+0xC0], xmm13
00007b2719bd7a42  vmovaps [rsp+0xD0], xmm14
00007b2719bd7a4b  vmovaps [rsp+0xE0], xmm15
00007b2719bd7a54  sub rsp, 0x40
00007b2719bd7a58  lea rdi, [rsp]
00007b2719bd7a5c  lea rsi, [rsp+0x10]
00007b2719bd7a61  lea rdx, [rsp+0x20]
00007b2719bd7a66  lea rcx, [rsp+0x30]
00007b2719bd7a6b  mov r8d, 0x00
00007b2719bd7a71  lea r9, [r15+0x3A8]
00007b2719bd7a78  movaps [rdi], xmm3
00007b2719bd7a7b  movaps [rsi], xmm13
00007b2719bd7a7f  movaps [rdx], xmm6
00007b2719bd7a82  movaps [rcx], xmm14
00007b2719bd7a86  mov rax, 0x5A8E6560CA50
00007b2719bd7a90  call rax
00007b2719bd7a92  movaps xmm3, [rsp]
00007b2719bd7a96  add rsp, 0x40
00007b2719bd7a9a  vmovaps xmm0, [rsp]
00007b2719bd7a9f  vmovaps xmm1, [rsp+0x10]
00007b2719bd7aa5  vmovaps xmm2, [rsp+0x20]
00007b2719bd7aab  vmovaps xmm4, [rsp+0x30]
00007b2719bd7ab1  vmovaps xmm5, [rsp+0x40]
00007b2719bd7ab7  vmovaps xmm6, [rsp+0x50]
00007b2719bd7abd  vmovaps xmm7, [rsp+0x60]
00007b2719bd7ac3  vmovaps xmm8, [rsp+0x70]
00007b2719bd7ac9  vmovaps xmm9, [rsp+0x80]
00007b2719bd7ad2  vmovaps xmm10, [rsp+0x90]
00007b2719bd7adb  vmovaps xmm11, [rsp+0xA0]
00007b2719bd7ae4  vmovaps xmm12, [rsp+0xB0]
00007b2719bd7aed  vmovaps xmm13, [rsp+0xC0]
00007b2719bd7af6  vmovaps xmm14, [rsp+0xD0]
00007b2719bd7aff  vmovaps xmm15, [rsp+0xE0]
00007b2719bd7b08  add rsp, 0xF0
00007b2719bd7b0f  pop r11
00007b2719bd7b11  pop r10
00007b2719bd7b13  pop r9
00007b2719bd7b15  pop r8
00007b2719bd7b17  pop rsi
00007b2719bd7b18  pop rdi
00007b2719bd7b19  pop rdx
00007b2719bd7b1a  pop rcx
00007b2719bd7b1b  pop rax
00007b2719bd7b1c  add rsp, 0x08
00007b2719bd7b20  jmp 0x00007B2719BD680F
00007b2719bd7b25  sub rsp, 0x08
00007b2719bd7b29  push rax
00007b2719bd7b2a  push rcx
00007b2719bd7b2b  push rdx
00007b2719bd7b2c  push rdi
00007b2719bd7b2d  push rsi
00007b2719bd7b2e  push r8
00007b2719bd7b30  push r9
00007b2719bd7b32  push r10
00007b2719bd7b34  push r11
00007b2719bd7b36  sub rsp, 0xF0
00007b2719bd7b3d  vmovaps [rsp], xmm0
00007b2719bd7b42  vmovaps [rsp+0x10], xmm1
00007b2719bd7b48  vmovaps [rsp+0x20], xmm2
00007b2719bd7b4e  vmovaps [rsp+0x30], xmm3
00007b2719bd7b54  vmovaps [rsp+0x40], xmm4
00007b2719bd7b5a  vmovaps [rsp+0x50], xmm5
00007b2719bd7b60  vmovaps [rsp+0x60], xmm7
00007b2719bd7b66  vmovaps [rsp+0x70], xmm8
00007b2719bd7b6c  vmovaps [rsp+0x80], xmm9
00007b2719bd7b75  vmovaps [rsp+0x90], xmm10
00007b2719bd7b7e  vmovaps [rsp+0xA0], xmm11
00007b2719bd7b87  vmovaps [rsp+0xB0], xmm12
00007b2719bd7b90  vmovaps [rsp+0xC0], xmm13
00007b2719bd7b99  vmovaps [rsp+0xD0], xmm14
00007b2719bd7ba2  vmovaps [rsp+0xE0], xmm15
00007b2719bd7bab  sub rsp, 0x40
00007b2719bd7baf  lea rdi, [rsp]
00007b2719bd7bb3  lea rsi, [rsp+0x10]
00007b2719bd7bb8  lea rdx, [rsp+0x20]
00007b2719bd7bbd  lea rcx, [rsp+0x30]
00007b2719bd7bc2  mov r8d, 0x00
00007b2719bd7bc8  lea r9, [r15+0x3A8]
00007b2719bd7bcf  movaps [rdi], xmm6
00007b2719bd7bd2  movaps [rsi], xmm2
00007b2719bd7bd5  movaps [rdx], xmm14
00007b2719bd7bd9  movaps [rcx], xmm1
00007b2719bd7bdc  mov rax, 0x5A8E6560CA50
00007b2719bd7be6  call rax
00007b2719bd7be8  movaps xmm6, [rsp]
00007b2719bd7bec  add rsp, 0x40
00007b2719bd7bf0  vmovaps xmm0, [rsp]
00007b2719bd7bf5  vmovaps xmm1, [rsp+0x10]
00007b2719bd7bfb  vmovaps xmm2, [rsp+0x20]
00007b2719bd7c01  vmovaps xmm3, [rsp+0x30]
00007b2719bd7c07  vmovaps xmm4, [rsp+0x40]
00007b2719bd7c0d  vmovaps xmm5, [rsp+0x50]
00007b2719bd7c13  vmovaps xmm7, [rsp+0x60]
00007b2719bd7c19  vmovaps xmm8, [rsp+0x70]
00007b2719bd7c1f  vmovaps xmm9, [rsp+0x80]
00007b2719bd7c28  vmovaps xmm10, [rsp+0x90]
00007b2719bd7c31  vmovaps xmm11, [rsp+0xA0]
00007b2719bd7c3a  vmovaps xmm12, [rsp+0xB0]
00007b2719bd7c43  vmovaps xmm13, [rsp+0xC0]
00007b2719bd7c4c  vmovaps xmm14, [rsp+0xD0]
00007b2719bd7c55  vmovaps xmm15, [rsp+0xE0]
00007b2719bd7c5e  add rsp, 0xF0
00007b2719bd7c65  pop r11
00007b2719bd7c67  pop r10
00007b2719bd7c69  pop r9
00007b2719bd7c6b  pop r8
00007b2719bd7c6d  pop rsi
00007b2719bd7c6e  pop rdi
00007b2719bd7c6f  pop rdx
00007b2719bd7c70  pop rcx
00007b2719bd7c71  pop rax
00007b2719bd7c72  add rsp, 0x08
00007b2719bd7c76  jmp 0x00007B2719BD683C
00007b2719bd7c7b  sub rsp, 0x08
00007b2719bd7c7f  push rax
00007b2719bd7c80  push rcx
00007b2719bd7c81  push rdx
00007b2719bd7c82  push rdi
00007b2719bd7c83  push rsi
00007b2719bd7c84  push r8
00007b2719bd7c86  push r9
00007b2719bd7c88  push r10
00007b2719bd7c8a  push r11
00007b2719bd7c8c  sub rsp, 0xF0
00007b2719bd7c93  vmovaps [rsp], xmm0
00007b2719bd7c98  vmovaps [rsp+0x10], xmm1
00007b2719bd7c9e  vmovaps [rsp+0x20], xmm2
00007b2719bd7ca4  vmovaps [rsp+0x30], xmm3
00007b2719bd7caa  vmovaps [rsp+0x40], xmm4
00007b2719bd7cb0  vmovaps [rsp+0x50], xmm5
00007b2719bd7cb6  vmovaps [rsp+0x60], xmm6
00007b2719bd7cbc  vmovaps [rsp+0x70], xmm7
00007b2719bd7cc2  vmovaps [rsp+0x80], xmm8
00007b2719bd7ccb  vmovaps [rsp+0x90], xmm9
00007b2719bd7cd4  vmovaps [rsp+0xA0], xmm10
00007b2719bd7cdd  vmovaps [rsp+0xB0], xmm11
00007b2719bd7ce6  vmovaps [rsp+0xC0], xmm12
00007b2719bd7cef  vmovaps [rsp+0xD0], xmm14
00007b2719bd7cf8  vmovaps [rsp+0xE0], xmm15
00007b2719bd7d01  sub rsp, 0x40
00007b2719bd7d05  lea rdi, [rsp]
00007b2719bd7d09  lea rsi, [rsp+0x10]
00007b2719bd7d0e  lea rdx, [rsp+0x20]
00007b2719bd7d13  lea rcx, [rsp+0x30]
00007b2719bd7d18  mov r8d, 0x00
00007b2719bd7d1e  lea r9, [r15+0x3A8]
00007b2719bd7d25  movaps [rdi], xmm13
00007b2719bd7d29  movaps [rsi], xmm12
00007b2719bd7d2d  movaps [rdx], xmm14
00007b2719bd7d31  movaps [rcx], xmm1
00007b2719bd7d34  mov rax, 0x5A8E6560CA50
00007b2719bd7d3e  call rax
00007b2719bd7d40  movaps xmm13, [rsp]
00007b2719bd7d45  add rsp, 0x40
00007b2719bd7d49  vmovaps xmm0, [rsp]
00007b2719bd7d4e  vmovaps xmm1, [rsp+0x10]
00007b2719bd7d54  vmovaps xmm2, [rsp+0x20]
00007b2719bd7d5a  vmovaps xmm3, [rsp+0x30]
00007b2719bd7d60  vmovaps xmm4, [rsp+0x40]
00007b2719bd7d66  vmovaps xmm5, [rsp+0x50]
00007b2719bd7d6c  vmovaps xmm6, [rsp+0x60]
00007b2719bd7d72  vmovaps xmm7, [rsp+0x70]
00007b2719bd7d78  vmovaps xmm8, [rsp+0x80]
00007b2719bd7d81  vmovaps xmm9, [rsp+0x90]
00007b2719bd7d8a  vmovaps xmm10, [rsp+0xA0]
00007b2719bd7d93  vmovaps xmm11, [rsp+0xB0]
00007b2719bd7d9c  vmovaps xmm12, [rsp+0xC0]
00007b2719bd7da5  vmovaps xmm14, [rsp+0xD0]
00007b2719bd7dae  vmovaps xmm15, [rsp+0xE0]
00007b2719bd7db7  add rsp, 0xF0
00007b2719bd7dbe  pop r11
00007b2719bd7dc0  pop r10
00007b2719bd7dc2  pop r9
00007b2719bd7dc4  pop r8
00007b2719bd7dc6  pop rsi
00007b2719bd7dc7  pop rdi
00007b2719bd7dc8  pop rdx
00007b2719bd7dc9  pop rcx
00007b2719bd7dca  pop rax
00007b2719bd7dcb  add rsp, 0x08
00007b2719bd7dcf  jmp 0x00007B2719BD686E
00007b2719bd7dd4  sub rsp, 0x08
00007b2719bd7dd8  push rax
00007b2719bd7dd9  push rcx
00007b2719bd7dda  push rdx
00007b2719bd7ddb  push rdi
00007b2719bd7ddc  push rsi
00007b2719bd7ddd  push r8
00007b2719bd7ddf  push r9
00007b2719bd7de1  push r10
00007b2719bd7de3  push r11
00007b2719bd7de5  sub rsp, 0xF0
00007b2719bd7dec  vmovaps [rsp], xmm0
00007b2719bd7df1  vmovaps [rsp+0x10], xmm1
00007b2719bd7df7  vmovaps [rsp+0x20], xmm2
00007b2719bd7dfd  vmovaps [rsp+0x30], xmm3
00007b2719bd7e03  vmovaps [rsp+0x40], xmm4
00007b2719bd7e09  vmovaps [rsp+0x50], xmm5
00007b2719bd7e0f  vmovaps [rsp+0x60], xmm6
00007b2719bd7e15  vmovaps [rsp+0x70], xmm7
00007b2719bd7e1b  vmovaps [rsp+0x80], xmm8
00007b2719bd7e24  vmovaps [rsp+0x90], xmm9
00007b2719bd7e2d  vmovaps [rsp+0xA0], xmm10
00007b2719bd7e36  vmovaps [rsp+0xB0], xmm11
00007b2719bd7e3f  vmovaps [rsp+0xC0], xmm13
00007b2719bd7e48  vmovaps [rsp+0xD0], xmm14
00007b2719bd7e51  vmovaps [rsp+0xE0], xmm15
00007b2719bd7e5a  sub rsp, 0x40
00007b2719bd7e5e  lea rdi, [rsp]
00007b2719bd7e62  lea rsi, [rsp+0x10]
00007b2719bd7e67  lea rdx, [rsp+0x20]
00007b2719bd7e6c  lea rcx, [rsp+0x30]
00007b2719bd7e71  mov r8d, 0x00
00007b2719bd7e77  lea r9, [r15+0x3A8]
00007b2719bd7e7e  movaps [rdi], xmm12
00007b2719bd7e82  movaps [rsi], xmm3
00007b2719bd7e85  movaps [rdx], xmm14
00007b2719bd7e89  movaps [rcx], xmm5
00007b2719bd7e8c  mov rax, 0x5A8E6560CA50
00007b2719bd7e96  call rax
00007b2719bd7e98  movaps xmm12, [rsp]
00007b2719bd7e9d  add rsp, 0x40
00007b2719bd7ea1  vmovaps xmm0, [rsp]
00007b2719bd7ea6  vmovaps xmm1, [rsp+0x10]
00007b2719bd7eac  vmovaps xmm2, [rsp+0x20]
00007b2719bd7eb2  vmovaps xmm3, [rsp+0x30]
00007b2719bd7eb8  vmovaps xmm4, [rsp+0x40]
00007b2719bd7ebe  vmovaps xmm5, [rsp+0x50]
00007b2719bd7ec4  vmovaps xmm6, [rsp+0x60]
00007b2719bd7eca  vmovaps xmm7, [rsp+0x70]
00007b2719bd7ed0  vmovaps xmm8, [rsp+0x80]
00007b2719bd7ed9  vmovaps xmm9, [rsp+0x90]
00007b2719bd7ee2  vmovaps xmm10, [rsp+0xA0]
00007b2719bd7eeb  vmovaps xmm11, [rsp+0xB0]
00007b2719bd7ef4  vmovaps xmm13, [rsp+0xC0]
00007b2719bd7efd  vmovaps xmm14, [rsp+0xD0]
00007b2719bd7f06  vmovaps xmm15, [rsp+0xE0]
00007b2719bd7f0f  add rsp, 0xF0
00007b2719bd7f16  pop r11
00007b2719bd7f18  pop r10
00007b2719bd7f1a  pop r9
00007b2719bd7f1c  pop r8
00007b2719bd7f1e  pop rsi
00007b2719bd7f1f  pop rdi
00007b2719bd7f20  pop rdx
00007b2719bd7f21  pop rcx
00007b2719bd7f22  pop rax
00007b2719bd7f23  add rsp, 0x08
00007b2719bd7f27  jmp 0x00007B2719BD68CB
00007b2719bd7f2c  sub rsp, 0x08
00007b2719bd7f30  push rax
00007b2719bd7f31  push rcx
00007b2719bd7f32  push rdx
00007b2719bd7f33  push rdi
00007b2719bd7f34  push rsi
00007b2719bd7f35  push r8
00007b2719bd7f37  push r9
00007b2719bd7f39  push r10
00007b2719bd7f3b  push r11
00007b2719bd7f3d  sub rsp, 0xF0
00007b2719bd7f44  vmovaps [rsp], xmm0
00007b2719bd7f49  vmovaps [rsp+0x10], xmm1
00007b2719bd7f4f  vmovaps [rsp+0x20], xmm2
00007b2719bd7f55  vmovaps [rsp+0x30], xmm3
00007b2719bd7f5b  vmovaps [rsp+0x40], xmm4
00007b2719bd7f61  vmovaps [rsp+0x50], xmm5
00007b2719bd7f67  vmovaps [rsp+0x60], xmm6
00007b2719bd7f6d  vmovaps [rsp+0x70], xmm7
00007b2719bd7f73  vmovaps [rsp+0x80], xmm8
00007b2719bd7f7c  vmovaps [rsp+0x90], xmm9
00007b2719bd7f85  vmovaps [rsp+0xA0], xmm11
00007b2719bd7f8e  vmovaps [rsp+0xB0], xmm12
00007b2719bd7f97  vmovaps [rsp+0xC0], xmm13
00007b2719bd7fa0  vmovaps [rsp+0xD0], xmm14
00007b2719bd7fa9  vmovaps [rsp+0xE0], xmm15
00007b2719bd7fb2  sub rsp, 0x40
00007b2719bd7fb6  lea rdi, [rsp]
00007b2719bd7fba  lea rsi, [rsp+0x10]
00007b2719bd7fbf  lea rdx, [rsp+0x20]
00007b2719bd7fc4  lea rcx, [rsp+0x30]
00007b2719bd7fc9  mov r8d, 0x00
00007b2719bd7fcf  lea r9, [r15+0x3A8]
00007b2719bd7fd6  movaps [rdi], xmm10
00007b2719bd7fda  movaps [rsi], xmm9
00007b2719bd7fde  movaps [rdx], xmm7
00007b2719bd7fe1  movaps [rcx], xmm14
00007b2719bd7fe5  mov rax, 0x5A8E6560CA50
00007b2719bd7fef  call rax
00007b2719bd7ff1  movaps xmm10, [rsp]
00007b2719bd7ff6  add rsp, 0x40
00007b2719bd7ffa  vmovaps xmm0, [rsp]
00007b2719bd7fff  vmovaps xmm1, [rsp+0x10]
00007b2719bd8005  vmovaps xmm2, [rsp+0x20]
00007b2719bd800b  vmovaps xmm3, [rsp+0x30]
00007b2719bd8011  vmovaps xmm4, [rsp+0x40]
00007b2719bd8017  vmovaps xmm5, [rsp+0x50]
00007b2719bd801d  vmovaps xmm6, [rsp+0x60]
00007b2719bd8023  vmovaps xmm7, [rsp+0x70]
00007b2719bd8029  vmovaps xmm8, [rsp+0x80]
00007b2719bd8032  vmovaps xmm9, [rsp+0x90]
00007b2719bd803b  vmovaps xmm11, [rsp+0xA0]
00007b2719bd8044  vmovaps xmm12, [rsp+0xB0]
00007b2719bd804d  vmovaps xmm13, [rsp+0xC0]
00007b2719bd8056  vmovaps xmm14, [rsp+0xD0]
00007b2719bd805f  vmovaps xmm15, [rsp+0xE0]
00007b2719bd8068  add rsp, 0xF0
00007b2719bd806f  pop r11
00007b2719bd8071  pop r10
00007b2719bd8073  pop r9
00007b2719bd8075  pop r8
00007b2719bd8077  pop rsi
00007b2719bd8078  pop rdi
00007b2719bd8079  pop rdx
00007b2719bd807a  pop rcx
00007b2719bd807b  pop rax
00007b2719bd807c  add rsp, 0x08
00007b2719bd8080  jmp 0x00007B2719BD68F1
00007b2719bd8085  call 0x00007B2719AE45A0
00007b2719bd808a  jmp 0x00007B2719BD68FE
00007b2719bd808f  sub rsp, 0x08
00007b2719bd8093  push rax
00007b2719bd8094  push rcx
00007b2719bd8095  push rdx
00007b2719bd8096  push rdi
00007b2719bd8097  push rsi
00007b2719bd8098  push r8
00007b2719bd809a  push r9
00007b2719bd809c  push r10
00007b2719bd809e  push r11
00007b2719bd80a0  sub rsp, 0xF0
00007b2719bd80a7  vmovaps [rsp], xmm0
00007b2719bd80ac  vmovaps [rsp+0x10], xmm1
00007b2719bd80b2  vmovaps [rsp+0x20], xmm2
00007b2719bd80b8  vmovaps [rsp+0x30], xmm3
00007b2719bd80be  vmovaps [rsp+0x40], xmm4
00007b2719bd80c4  vmovaps [rsp+0x50], xmm6
00007b2719bd80ca  vmovaps [rsp+0x60], xmm7
00007b2719bd80d0  vmovaps [rsp+0x70], xmm8
00007b2719bd80d6  vmovaps [rsp+0x80], xmm9
00007b2719bd80df  vmovaps [rsp+0x90], xmm10
00007b2719bd80e8  vmovaps [rsp+0xA0], xmm11
00007b2719bd80f1  vmovaps [rsp+0xB0], xmm12
00007b2719bd80fa  vmovaps [rsp+0xC0], xmm13
00007b2719bd8103  vmovaps [rsp+0xD0], xmm14
00007b2719bd810c  vmovaps [rsp+0xE0], xmm15
00007b2719bd8115  sub rsp, 0x40
00007b2719bd8119  lea rdi, [rsp]
00007b2719bd811d  lea rsi, [rsp+0x10]
00007b2719bd8122  lea rdx, [rsp+0x20]
00007b2719bd8127  lea rcx, [rsp+0x30]
00007b2719bd812c  mov r8d, 0x00
00007b2719bd8132  lea r9, [r15+0x3A8]
00007b2719bd8139  movaps [rdi], xmm5
00007b2719bd813c  movaps [rsi], xmm6
00007b2719bd813f  movaps [rdx], xmm7
00007b2719bd8142  movaps [rcx], xmm9
00007b2719bd8146  mov rax, 0x5A8E6560CA50
00007b2719bd8150  call rax
00007b2719bd8152  movaps xmm5, [rsp]
00007b2719bd8156  add rsp, 0x40
00007b2719bd815a  vmovaps xmm0, [rsp]
00007b2719bd815f  vmovaps xmm1, [rsp+0x10]
00007b2719bd8165  vmovaps xmm2, [rsp+0x20]
00007b2719bd816b  vmovaps xmm3, [rsp+0x30]
00007b2719bd8171  vmovaps xmm4, [rsp+0x40]
00007b2719bd8177  vmovaps xmm6, [rsp+0x50]
00007b2719bd817d  vmovaps xmm7, [rsp+0x60]
00007b2719bd8183  vmovaps xmm8, [rsp+0x70]
00007b2719bd8189  vmovaps xmm9, [rsp+0x80]
00007b2719bd8192  vmovaps xmm10, [rsp+0x90]
00007b2719bd819b  vmovaps xmm11, [rsp+0xA0]
00007b2719bd81a4  vmovaps xmm12, [rsp+0xB0]
00007b2719bd81ad  vmovaps xmm13, [rsp+0xC0]
00007b2719bd81b6  vmovaps xmm14, [rsp+0xD0]
00007b2719bd81bf  vmovaps xmm15, [rsp+0xE0]
00007b2719bd81c8  add rsp, 0xF0
00007b2719bd81cf  pop r11
00007b2719bd81d1  pop r10
00007b2719bd81d3  pop r9
00007b2719bd81d5  pop r8
00007b2719bd81d7  pop rsi
00007b2719bd81d8  pop rdi
00007b2719bd81d9  pop rdx
00007b2719bd81da  pop rcx
00007b2719bd81db  pop rax
00007b2719bd81dc  add rsp, 0x08
00007b2719bd81e0  jmp 0x00007B2719BD6930
00007b2719bd81e5  sub rsp, 0x08
00007b2719bd81e9  push rax
00007b2719bd81ea  push rcx
00007b2719bd81eb  push rdx
00007b2719bd81ec  push rdi
00007b2719bd81ed  push rsi
00007b2719bd81ee  push r8
00007b2719bd81f0  push r9
00007b2719bd81f2  push r10
00007b2719bd81f4  push r11
00007b2719bd81f6  sub rsp, 0xF0
00007b2719bd81fd  vmovaps [rsp], xmm0
00007b2719bd8202  vmovaps [rsp+0x10], xmm1
00007b2719bd8208  vmovaps [rsp+0x20], xmm2
00007b2719bd820e  vmovaps [rsp+0x30], xmm3
00007b2719bd8214  vmovaps [rsp+0x40], xmm4
00007b2719bd821a  vmovaps [rsp+0x50], xmm5
00007b2719bd8220  vmovaps [rsp+0x60], xmm6
00007b2719bd8226  vmovaps [rsp+0x70], xmm8
00007b2719bd822c  vmovaps [rsp+0x80], xmm9
00007b2719bd8235  vmovaps [rsp+0x90], xmm10
00007b2719bd823e  vmovaps [rsp+0xA0], xmm11
00007b2719bd8247  vmovaps [rsp+0xB0], xmm12
00007b2719bd8250  vmovaps [rsp+0xC0], xmm13
00007b2719bd8259  vmovaps [rsp+0xD0], xmm14
00007b2719bd8262  vmovaps [rsp+0xE0], xmm15
00007b2719bd826b  sub rsp, 0x40
00007b2719bd826f  lea rdi, [rsp]
00007b2719bd8273  lea rsi, [rsp+0x10]
00007b2719bd8278  lea rdx, [rsp+0x20]
00007b2719bd827d  lea rcx, [rsp+0x30]
00007b2719bd8282  mov r8d, 0x00
00007b2719bd8288  lea r9, [r15+0x3A8]
00007b2719bd828f  movaps [rdi], xmm7
00007b2719bd8292  movaps [rsi], xmm13
00007b2719bd8296  movaps [rdx], xmm1
00007b2719bd8299  movaps [rcx], xmm9
00007b2719bd829d  mov rax, 0x5A8E6560CA50
00007b2719bd82a7  call rax
00007b2719bd82a9  movaps xmm7, [rsp]
00007b2719bd82ad  add rsp, 0x40
00007b2719bd82b1  vmovaps xmm0, [rsp]
00007b2719bd82b6  vmovaps xmm1, [rsp+0x10]
00007b2719bd82bc  vmovaps xmm2, [rsp+0x20]
00007b2719bd82c2  vmovaps xmm3, [rsp+0x30]
00007b2719bd82c8  vmovaps xmm4, [rsp+0x40]
00007b2719bd82ce  vmovaps xmm5, [rsp+0x50]
00007b2719bd82d4  vmovaps xmm6, [rsp+0x60]
00007b2719bd82da  vmovaps xmm8, [rsp+0x70]
00007b2719bd82e0  vmovaps xmm9, [rsp+0x80]
00007b2719bd82e9  vmovaps xmm10, [rsp+0x90]
00007b2719bd82f2  vmovaps xmm11, [rsp+0xA0]
00007b2719bd82fb  vmovaps xmm12, [rsp+0xB0]
00007b2719bd8304  vmovaps xmm13, [rsp+0xC0]
00007b2719bd830d  vmovaps xmm14, [rsp+0xD0]
00007b2719bd8316  vmovaps xmm15, [rsp+0xE0]
00007b2719bd831f  add rsp, 0xF0
00007b2719bd8326  pop r11
00007b2719bd8328  pop r10
00007b2719bd832a  pop r9
00007b2719bd832c  pop r8
00007b2719bd832e  pop rsi
00007b2719bd832f  pop rdi
00007b2719bd8330  pop rdx
00007b2719bd8331  pop rcx
00007b2719bd8332  pop rax
00007b2719bd8333  add rsp, 0x08
00007b2719bd8337  jmp 0x00007B2719BD6955
00007b2719bd833c  call 0x00007B2719AE3320
00007b2719bd8341  jmp 0x00007B2719BD6978
00007b2719bd8346  call 0x00007B2719ADE950
00007b2719bd834b  jmp 0x00007B2719BD6982
00007b2719bd8350  sub rsp, 0x08
00007b2719bd8354  push rax
00007b2719bd8355  push rcx
00007b2719bd8356  push rdx
00007b2719bd8357  push rdi
00007b2719bd8358  push rsi
00007b2719bd8359  push r8
00007b2719bd835b  push r9
00007b2719bd835d  push r10
00007b2719bd835f  push r11
00007b2719bd8361  sub rsp, 0xF0
00007b2719bd8368  vmovaps [rsp], xmm0
00007b2719bd836d  vmovaps [rsp+0x10], xmm1
00007b2719bd8373  vmovaps [rsp+0x20], xmm3
00007b2719bd8379  vmovaps [rsp+0x30], xmm4
00007b2719bd837f  vmovaps [rsp+0x40], xmm5
00007b2719bd8385  vmovaps [rsp+0x50], xmm6
00007b2719bd838b  vmovaps [rsp+0x60], xmm7
00007b2719bd8391  vmovaps [rsp+0x70], xmm8
00007b2719bd8397  vmovaps [rsp+0x80], xmm9
00007b2719bd83a0  vmovaps [rsp+0x90], xmm10
00007b2719bd83a9  vmovaps [rsp+0xA0], xmm11
00007b2719bd83b2  vmovaps [rsp+0xB0], xmm12
00007b2719bd83bb  vmovaps [rsp+0xC0], xmm13
00007b2719bd83c4  vmovaps [rsp+0xD0], xmm14
00007b2719bd83cd  vmovaps [rsp+0xE0], xmm15
00007b2719bd83d6  sub rsp, 0x40
00007b2719bd83da  lea rdi, [rsp]
00007b2719bd83de  lea rsi, [rsp+0x10]
00007b2719bd83e3  lea rdx, [rsp+0x20]
00007b2719bd83e8  lea rcx, [rsp+0x30]
00007b2719bd83ed  mov r8d, 0x00
00007b2719bd83f3  lea r9, [r15+0x3A8]
00007b2719bd83fa  movaps [rdi], xmm2
00007b2719bd83fd  movaps [rsi], xmm12
00007b2719bd8401  movaps [rdx], xmm6
00007b2719bd8404  movaps [rcx], xmm3
00007b2719bd8407  mov rax, 0x5A8E6560CA50
00007b2719bd8411  call rax
00007b2719bd8413  movaps xmm2, [rsp]
00007b2719bd8417  add rsp, 0x40
00007b2719bd841b  vmovaps xmm0, [rsp]
00007b2719bd8420  vmovaps xmm1, [rsp+0x10]
00007b2719bd8426  vmovaps xmm3, [rsp+0x20]
00007b2719bd842c  vmovaps xmm4, [rsp+0x30]
00007b2719bd8432  vmovaps xmm5, [rsp+0x40]
00007b2719bd8438  vmovaps xmm6, [rsp+0x50]
00007b2719bd843e  vmovaps xmm7, [rsp+0x60]
00007b2719bd8444  vmovaps xmm8, [rsp+0x70]
00007b2719bd844a  vmovaps xmm9, [rsp+0x80]
00007b2719bd8453  vmovaps xmm10, [rsp+0x90]
00007b2719bd845c  vmovaps xmm11, [rsp+0xA0]
00007b2719bd8465  vmovaps xmm12, [rsp+0xB0]
00007b2719bd846e  vmovaps xmm13, [rsp+0xC0]
00007b2719bd8477  vmovaps xmm14, [rsp+0xD0]
00007b2719bd8480  vmovaps xmm15, [rsp+0xE0]
00007b2719bd8489  add rsp, 0xF0
00007b2719bd8490  pop r11
00007b2719bd8492  pop r10
00007b2719bd8494  pop r9
00007b2719bd8496  pop r8
00007b2719bd8498  pop rsi
00007b2719bd8499  pop rdi
00007b2719bd849a  pop rdx
00007b2719bd849b  pop rcx
00007b2719bd849c  pop rax
00007b2719bd849d  add rsp, 0x08
00007b2719bd84a1  jmp 0x00007B2719BD69C8
00007b2719bd84a6  sub rsp, 0x08
00007b2719bd84aa  push rax
00007b2719bd84ab  push rcx
00007b2719bd84ac  push rdx
00007b2719bd84ad  push rdi
00007b2719bd84ae  push rsi
00007b2719bd84af  push r8
00007b2719bd84b1  push r9
00007b2719bd84b3  push r10
00007b2719bd84b5  push r11
00007b2719bd84b7  sub rsp, 0xF0
00007b2719bd84be  vmovaps [rsp], xmm0
00007b2719bd84c3  vmovaps [rsp+0x10], xmm1
00007b2719bd84c9  vmovaps [rsp+0x20], xmm2
00007b2719bd84cf  vmovaps [rsp+0x30], xmm3
00007b2719bd84d5  vmovaps [rsp+0x40], xmm4
00007b2719bd84db  vmovaps [rsp+0x50], xmm5
00007b2719bd84e1  vmovaps [rsp+0x60], xmm7
00007b2719bd84e7  vmovaps [rsp+0x70], xmm8
00007b2719bd84ed  vmovaps [rsp+0x80], xmm9
00007b2719bd84f6  vmovaps [rsp+0x90], xmm10
00007b2719bd84ff  vmovaps [rsp+0xA0], xmm11
00007b2719bd8508  vmovaps [rsp+0xB0], xmm12
00007b2719bd8511  vmovaps [rsp+0xC0], xmm13
00007b2719bd851a  vmovaps [rsp+0xD0], xmm14
00007b2719bd8523  vmovaps [rsp+0xE0], xmm15
00007b2719bd852c  sub rsp, 0x40
00007b2719bd8530  lea rdi, [rsp]
00007b2719bd8534  lea rsi, [rsp+0x10]
00007b2719bd8539  lea rdx, [rsp+0x20]
00007b2719bd853e  lea rcx, [rsp+0x30]
00007b2719bd8543  mov r8d, 0x00
00007b2719bd8549  lea r9, [r15+0x3A8]
00007b2719bd8550  movaps [rdi], xmm6
00007b2719bd8553  movaps [rsi], xmm10
00007b2719bd8557  movaps [rdx], xmm12
00007b2719bd855b  movaps [rcx], xmm1
00007b2719bd855e  mov rax, 0x5A8E6560CA50
00007b2719bd8568  call rax
00007b2719bd856a  movaps xmm6, [rsp]
00007b2719bd856e  add rsp, 0x40
00007b2719bd8572  vmovaps xmm0, [rsp]
00007b2719bd8577  vmovaps xmm1, [rsp+0x10]
00007b2719bd857d  vmovaps xmm2, [rsp+0x20]
00007b2719bd8583  vmovaps xmm3, [rsp+0x30]
00007b2719bd8589  vmovaps xmm4, [rsp+0x40]
00007b2719bd858f  vmovaps xmm5, [rsp+0x50]
00007b2719bd8595  vmovaps xmm7, [rsp+0x60]
00007b2719bd859b  vmovaps xmm8, [rsp+0x70]
00007b2719bd85a1  vmovaps xmm9, [rsp+0x80]
00007b2719bd85aa  vmovaps xmm10, [rsp+0x90]
00007b2719bd85b3  vmovaps xmm11, [rsp+0xA0]
00007b2719bd85bc  vmovaps xmm12, [rsp+0xB0]
00007b2719bd85c5  vmovaps xmm13, [rsp+0xC0]
00007b2719bd85ce  vmovaps xmm14, [rsp+0xD0]
00007b2719bd85d7  vmovaps xmm15, [rsp+0xE0]
00007b2719bd85e0  add rsp, 0xF0
00007b2719bd85e7  pop r11
00007b2719bd85e9  pop r10
00007b2719bd85eb  pop r9
00007b2719bd85ed  pop r8
00007b2719bd85ef  pop rsi
00007b2719bd85f0  pop rdi
00007b2719bd85f1  pop rdx
00007b2719bd85f2  pop rcx
00007b2719bd85f3  pop rax
00007b2719bd85f4  add rsp, 0x08
00007b2719bd85f8  jmp 0x00007B2719BD69F6
00007b2719bd85fd  sub rsp, 0x08
00007b2719bd8601  push rax
00007b2719bd8602  push rcx
00007b2719bd8603  push rdx
00007b2719bd8604  push rdi
00007b2719bd8605  push rsi
00007b2719bd8606  push r8
00007b2719bd8608  push r9
00007b2719bd860a  push r10
00007b2719bd860c  push r11
00007b2719bd860e  sub rsp, 0xF0
00007b2719bd8615  vmovaps [rsp], xmm0
00007b2719bd861a  vmovaps [rsp+0x10], xmm1
00007b2719bd8620  vmovaps [rsp+0x20], xmm2
00007b2719bd8626  vmovaps [rsp+0x30], xmm3
00007b2719bd862c  vmovaps [rsp+0x40], xmm4
00007b2719bd8632  vmovaps [rsp+0x50], xmm5
00007b2719bd8638  vmovaps [rsp+0x60], xmm6
00007b2719bd863e  vmovaps [rsp+0x70], xmm7
00007b2719bd8644  vmovaps [rsp+0x80], xmm8
00007b2719bd864d  vmovaps [rsp+0x90], xmm9
00007b2719bd8656  vmovaps [rsp+0xA0], xmm11
00007b2719bd865f  vmovaps [rsp+0xB0], xmm12
00007b2719bd8668  vmovaps [rsp+0xC0], xmm13
00007b2719bd8671  vmovaps [rsp+0xD0], xmm14
00007b2719bd867a  vmovaps [rsp+0xE0], xmm15
00007b2719bd8683  sub rsp, 0x40
00007b2719bd8687  lea rdi, [rsp]
00007b2719bd868b  lea rsi, [rsp+0x10]
00007b2719bd8690  lea rdx, [rsp+0x20]
00007b2719bd8695  lea rcx, [rsp+0x30]
00007b2719bd869a  mov r8d, 0x00
00007b2719bd86a0  lea r9, [r15+0x3A8]
00007b2719bd86a7  movaps [rdi], xmm10
00007b2719bd86ab  movaps [rsi], xmm5
00007b2719bd86ae  movaps [rdx], xmm12
00007b2719bd86b2  movaps [rcx], xmm1
00007b2719bd86b5  mov rax, 0x5A8E6560CA50
00007b2719bd86bf  call rax
00007b2719bd86c1  movaps xmm10, [rsp]
00007b2719bd86c6  add rsp, 0x40
00007b2719bd86ca  vmovaps xmm0, [rsp]
00007b2719bd86cf  vmovaps xmm1, [rsp+0x10]
00007b2719bd86d5  vmovaps xmm2, [rsp+0x20]
00007b2719bd86db  vmovaps xmm3, [rsp+0x30]
00007b2719bd86e1  vmovaps xmm4, [rsp+0x40]
00007b2719bd86e7  vmovaps xmm5, [rsp+0x50]
00007b2719bd86ed  vmovaps xmm6, [rsp+0x60]
00007b2719bd86f3  vmovaps xmm7, [rsp+0x70]
00007b2719bd86f9  vmovaps xmm8, [rsp+0x80]
00007b2719bd8702  vmovaps xmm9, [rsp+0x90]
00007b2719bd870b  vmovaps xmm11, [rsp+0xA0]
00007b2719bd8714  vmovaps xmm12, [rsp+0xB0]
00007b2719bd871d  vmovaps xmm13, [rsp+0xC0]
00007b2719bd8726  vmovaps xmm14, [rsp+0xD0]
00007b2719bd872f  vmovaps xmm15, [rsp+0xE0]
00007b2719bd8738  add rsp, 0xF0
00007b2719bd873f  pop r11
00007b2719bd8741  pop r10
00007b2719bd8743  pop r9
00007b2719bd8745  pop r8
00007b2719bd8747  pop rsi
00007b2719bd8748  pop rdi
00007b2719bd8749  pop rdx
00007b2719bd874a  pop rcx
00007b2719bd874b  pop rax
00007b2719bd874c  add rsp, 0x08
00007b2719bd8750  jmp 0x00007B2719BD6A25
00007b2719bd8755  sub rsp, 0x08
00007b2719bd8759  push rax
00007b2719bd875a  push rcx
00007b2719bd875b  push rdx
00007b2719bd875c  push rdi
00007b2719bd875d  push rsi
00007b2719bd875e  push r8
00007b2719bd8760  push r9
00007b2719bd8762  push r10
00007b2719bd8764  push r11
00007b2719bd8766  sub rsp, 0xF0
00007b2719bd876d  vmovaps [rsp], xmm0
00007b2719bd8772  vmovaps [rsp+0x10], xmm1
00007b2719bd8778  vmovaps [rsp+0x20], xmm2
00007b2719bd877e  vmovaps [rsp+0x30], xmm3
00007b2719bd8784  vmovaps [rsp+0x40], xmm4
00007b2719bd878a  vmovaps [rsp+0x50], xmm5
00007b2719bd8790  vmovaps [rsp+0x60], xmm6
00007b2719bd8796  vmovaps [rsp+0x70], xmm7
00007b2719bd879c  vmovaps [rsp+0x80], xmm8
00007b2719bd87a5  vmovaps [rsp+0x90], xmm9
00007b2719bd87ae  vmovaps [rsp+0xA0], xmm10
00007b2719bd87b7  vmovaps [rsp+0xB0], xmm11
00007b2719bd87c0  vmovaps [rsp+0xC0], xmm13
00007b2719bd87c9  vmovaps [rsp+0xD0], xmm14
00007b2719bd87d2  vmovaps [rsp+0xE0], xmm15
00007b2719bd87db  sub rsp, 0x40
00007b2719bd87df  lea rdi, [rsp]
00007b2719bd87e3  lea rsi, [rsp+0x10]
00007b2719bd87e8  lea rdx, [rsp+0x20]
00007b2719bd87ed  lea rcx, [rsp+0x30]
00007b2719bd87f2  mov r8d, 0x00
00007b2719bd87f8  lea r9, [r15+0x3A8]
00007b2719bd87ff  movaps [rdi], xmm12
00007b2719bd8803  movaps [rsi], xmm7
00007b2719bd8806  movaps [rdx], xmm15
00007b2719bd880a  movaps [rcx], xmm1
00007b2719bd880d  mov rax, 0x5A8E6560CA50
00007b2719bd8817  call rax
00007b2719bd8819  movaps xmm12, [rsp]
00007b2719bd881e  add rsp, 0x40
00007b2719bd8822  vmovaps xmm0, [rsp]
00007b2719bd8827  vmovaps xmm1, [rsp+0x10]
00007b2719bd882d  vmovaps xmm2, [rsp+0x20]
00007b2719bd8833  vmovaps xmm3, [rsp+0x30]
00007b2719bd8839  vmovaps xmm4, [rsp+0x40]
00007b2719bd883f  vmovaps xmm5, [rsp+0x50]
00007b2719bd8845  vmovaps xmm6, [rsp+0x60]
00007b2719bd884b  vmovaps xmm7, [rsp+0x70]
00007b2719bd8851  vmovaps xmm8, [rsp+0x80]
00007b2719bd885a  vmovaps xmm9, [rsp+0x90]
00007b2719bd8863  vmovaps xmm10, [rsp+0xA0]
00007b2719bd886c  vmovaps xmm11, [rsp+0xB0]
00007b2719bd8875  vmovaps xmm13, [rsp+0xC0]
00007b2719bd887e  vmovaps xmm14, [rsp+0xD0]
00007b2719bd8887  vmovaps xmm15, [rsp+0xE0]
00007b2719bd8890  add rsp, 0xF0
00007b2719bd8897  pop r11
00007b2719bd8899  pop r10
00007b2719bd889b  pop r9
00007b2719bd889d  pop r8
00007b2719bd889f  pop rsi
00007b2719bd88a0  pop rdi
00007b2719bd88a1  pop rdx
00007b2719bd88a2  pop rcx
00007b2719bd88a3  pop rax
00007b2719bd88a4  add rsp, 0x08
00007b2719bd88a8  jmp 0x00007B2719BD6A4E
00007b2719bd88ad  call 0x00007B2719AD64F0
00007b2719bd88b2  jmp 0x00007B2719BD6A58
00007b2719bd88b7  call 0x00007B2719AE5820
00007b2719bd88bc  jmp 0x00007B2719BD6A62
00007b2719bd88c1  sub rsp, 0x08
00007b2719bd88c5  push rax
00007b2719bd88c6  push rcx
00007b2719bd88c7  push rdx
00007b2719bd88c8  push rdi
00007b2719bd88c9  push rsi
00007b2719bd88ca  push r8
00007b2719bd88cc  push r9
00007b2719bd88ce  push r10
00007b2719bd88d0  push r11
00007b2719bd88d2  sub rsp, 0xF0
00007b2719bd88d9  vmovaps [rsp], xmm0
00007b2719bd88de  vmovaps [rsp+0x10], xmm1
00007b2719bd88e4  vmovaps [rsp+0x20], xmm2
00007b2719bd88ea  vmovaps [rsp+0x30], xmm3
00007b2719bd88f0  vmovaps [rsp+0x40], xmm4
00007b2719bd88f6  vmovaps [rsp+0x50], xmm5
00007b2719bd88fc  vmovaps [rsp+0x60], xmm6
00007b2719bd8902  vmovaps [rsp+0x70], xmm8
00007b2719bd8908  vmovaps [rsp+0x80], xmm9
00007b2719bd8911  vmovaps [rsp+0x90], xmm10
00007b2719bd891a  vmovaps [rsp+0xA0], xmm11
00007b2719bd8923  vmovaps [rsp+0xB0], xmm12
00007b2719bd892c  vmovaps [rsp+0xC0], xmm13
00007b2719bd8935  vmovaps [rsp+0xD0], xmm14
00007b2719bd893e  vmovaps [rsp+0xE0], xmm15
00007b2719bd8947  sub rsp, 0x40
00007b2719bd894b  lea rdi, [rsp]
00007b2719bd894f  lea rsi, [rsp+0x10]
00007b2719bd8954  lea rdx, [rsp+0x20]
00007b2719bd8959  lea rcx, [rsp+0x30]
00007b2719bd895e  mov r8d, 0x00
00007b2719bd8964  lea r9, [r15+0x3A8]
00007b2719bd896b  movaps [rdi], xmm7
00007b2719bd896e  movaps [rsi], xmm2
00007b2719bd8971  movaps [rdx], xmm9
00007b2719bd8975  movaps [rcx], xmm11
00007b2719bd8979  mov rax, 0x5A8E6560CA50
00007b2719bd8983  call rax
00007b2719bd8985  movaps xmm7, [rsp]
00007b2719bd8989  add rsp, 0x40
00007b2719bd898d  vmovaps xmm0, [rsp]
00007b2719bd8992  vmovaps xmm1, [rsp+0x10]
00007b2719bd8998  vmovaps xmm2, [rsp+0x20]
00007b2719bd899e  vmovaps xmm3, [rsp+0x30]
00007b2719bd89a4  vmovaps xmm4, [rsp+0x40]
00007b2719bd89aa  vmovaps xmm5, [rsp+0x50]
00007b2719bd89b0  vmovaps xmm6, [rsp+0x60]
00007b2719bd89b6  vmovaps xmm8, [rsp+0x70]
00007b2719bd89bc  vmovaps xmm9, [rsp+0x80]
00007b2719bd89c5  vmovaps xmm10, [rsp+0x90]
00007b2719bd89ce  vmovaps xmm11, [rsp+0xA0]
00007b2719bd89d7  vmovaps xmm12, [rsp+0xB0]
00007b2719bd89e0  vmovaps xmm13, [rsp+0xC0]
00007b2719bd89e9  vmovaps xmm14, [rsp+0xD0]
00007b2719bd89f2  vmovaps xmm15, [rsp+0xE0]
00007b2719bd89fb  add rsp, 0xF0
00007b2719bd8a02  pop r11
00007b2719bd8a04  pop r10
00007b2719bd8a06  pop r9
00007b2719bd8a08  pop r8
00007b2719bd8a0a  pop rsi
00007b2719bd8a0b  pop rdi
00007b2719bd8a0c  pop rdx
00007b2719bd8a0d  pop rcx
00007b2719bd8a0e  pop rax
00007b2719bd8a0f  add rsp, 0x08
00007b2719bd8a13  jmp 0x00007B2719BD6A96
00007b2719bd8a18  sub rsp, 0x08
00007b2719bd8a1c  push rax
00007b2719bd8a1d  push rcx
00007b2719bd8a1e  push rdx
00007b2719bd8a1f  push rdi
00007b2719bd8a20  push rsi
00007b2719bd8a21  push r8
00007b2719bd8a23  push r9
00007b2719bd8a25  push r10
00007b2719bd8a27  push r11
00007b2719bd8a29  sub rsp, 0xF0
00007b2719bd8a30  vmovaps [rsp], xmm0
00007b2719bd8a35  vmovaps [rsp+0x10], xmm1
00007b2719bd8a3b  vmovaps [rsp+0x20], xmm2
00007b2719bd8a41  vmovaps [rsp+0x30], xmm3
00007b2719bd8a47  vmovaps [rsp+0x40], xmm4
00007b2719bd8a4d  vmovaps [rsp+0x50], xmm5
00007b2719bd8a53  vmovaps [rsp+0x60], xmm6
00007b2719bd8a59  vmovaps [rsp+0x70], xmm7
00007b2719bd8a5f  vmovaps [rsp+0x80], xmm8
00007b2719bd8a68  vmovaps [rsp+0x90], xmm10
00007b2719bd8a71  vmovaps [rsp+0xA0], xmm11
00007b2719bd8a7a  vmovaps [rsp+0xB0], xmm12
00007b2719bd8a83  vmovaps [rsp+0xC0], xmm13
00007b2719bd8a8c  vmovaps [rsp+0xD0], xmm14
00007b2719bd8a95  vmovaps [rsp+0xE0], xmm15
00007b2719bd8a9e  sub rsp, 0x40
00007b2719bd8aa2  lea rdi, [rsp]
00007b2719bd8aa6  lea rsi, [rsp+0x10]
00007b2719bd8aab  lea rdx, [rsp+0x20]
00007b2719bd8ab0  lea rcx, [rsp+0x30]
00007b2719bd8ab5  mov r8d, 0x00
00007b2719bd8abb  lea r9, [r15+0x3A8]
00007b2719bd8ac2  movaps [rdi], xmm9
00007b2719bd8ac6  movaps [rsi], xmm6
00007b2719bd8ac9  movaps [rdx], xmm1
00007b2719bd8acc  movaps [rcx], xmm11
00007b2719bd8ad0  mov rax, 0x5A8E6560CA50
00007b2719bd8ada  call rax
00007b2719bd8adc  movaps xmm9, [rsp]
00007b2719bd8ae1  add rsp, 0x40
00007b2719bd8ae5  vmovaps xmm0, [rsp]
00007b2719bd8aea  vmovaps xmm1, [rsp+0x10]
00007b2719bd8af0  vmovaps xmm2, [rsp+0x20]
00007b2719bd8af6  vmovaps xmm3, [rsp+0x30]
00007b2719bd8afc  vmovaps xmm4, [rsp+0x40]
00007b2719bd8b02  vmovaps xmm5, [rsp+0x50]
00007b2719bd8b08  vmovaps xmm6, [rsp+0x60]
00007b2719bd8b0e  vmovaps xmm7, [rsp+0x70]
00007b2719bd8b14  vmovaps xmm8, [rsp+0x80]
00007b2719bd8b1d  vmovaps xmm10, [rsp+0x90]
00007b2719bd8b26  vmovaps xmm11, [rsp+0xA0]
00007b2719bd8b2f  vmovaps xmm12, [rsp+0xB0]
00007b2719bd8b38  vmovaps xmm13, [rsp+0xC0]
00007b2719bd8b41  vmovaps xmm14, [rsp+0xD0]
00007b2719bd8b4a  vmovaps xmm15, [rsp+0xE0]
00007b2719bd8b53  add rsp, 0xF0
00007b2719bd8b5a  pop r11
00007b2719bd8b5c  pop r10
00007b2719bd8b5e  pop r9
00007b2719bd8b60  pop r8
00007b2719bd8b62  pop rsi
00007b2719bd8b63  pop rdi
00007b2719bd8b64  pop rdx
00007b2719bd8b65  pop rcx
00007b2719bd8b66  pop rax
00007b2719bd8b67  add rsp, 0x08
00007b2719bd8b6b  jmp 0x00007B2719BD6ABC
00007b2719bd8b70  sub rsp, 0x08
00007b2719bd8b74  push rax
00007b2719bd8b75  push rcx
00007b2719bd8b76  push rdx
00007b2719bd8b77  push rdi
00007b2719bd8b78  push rsi
00007b2719bd8b79  push r8
00007b2719bd8b7b  push r9
00007b2719bd8b7d  push r10
00007b2719bd8b7f  push r11
00007b2719bd8b81  sub rsp, 0xF0
00007b2719bd8b88  vmovaps [rsp], xmm0
00007b2719bd8b8d  vmovaps [rsp+0x10], xmm1
00007b2719bd8b93  vmovaps [rsp+0x20], xmm2
00007b2719bd8b99  vmovaps [rsp+0x30], xmm3
00007b2719bd8b9f  vmovaps [rsp+0x40], xmm4
00007b2719bd8ba5  vmovaps [rsp+0x50], xmm5
00007b2719bd8bab  vmovaps [rsp+0x60], xmm6
00007b2719bd8bb1  vmovaps [rsp+0x70], xmm7
00007b2719bd8bb7  vmovaps [rsp+0x80], xmm8
00007b2719bd8bc0  vmovaps [rsp+0x90], xmm9
00007b2719bd8bc9  vmovaps [rsp+0xA0], xmm10
00007b2719bd8bd2  vmovaps [rsp+0xB0], xmm12
00007b2719bd8bdb  vmovaps [rsp+0xC0], xmm13
00007b2719bd8be4  vmovaps [rsp+0xD0], xmm14
00007b2719bd8bed  vmovaps [rsp+0xE0], xmm15
00007b2719bd8bf6  sub rsp, 0x40
00007b2719bd8bfa  lea rdi, [rsp]
00007b2719bd8bfe  lea rsi, [rsp+0x10]
00007b2719bd8c03  lea rdx, [rsp+0x20]
00007b2719bd8c08  lea rcx, [rsp+0x30]
00007b2719bd8c0d  mov r8d, 0x00
00007b2719bd8c13  lea r9, [r15+0x3A8]
00007b2719bd8c1a  movaps [rdi], xmm11
00007b2719bd8c1e  movaps [rsi], xmm10
00007b2719bd8c22  movaps [rdx], xmm8
00007b2719bd8c26  movaps [rcx], xmm1
00007b2719bd8c29  mov rax, 0x5A8E6560CA50
00007b2719bd8c33  call rax
00007b2719bd8c35  movaps xmm11, [rsp]
00007b2719bd8c3a  add rsp, 0x40
00007b2719bd8c3e  vmovaps xmm0, [rsp]
00007b2719bd8c43  vmovaps xmm1, [rsp+0x10]
00007b2719bd8c49  vmovaps xmm2, [rsp+0x20]
00007b2719bd8c4f  vmovaps xmm3, [rsp+0x30]
00007b2719bd8c55  vmovaps xmm4, [rsp+0x40]
00007b2719bd8c5b  vmovaps xmm5, [rsp+0x50]
00007b2719bd8c61  vmovaps xmm6, [rsp+0x60]
00007b2719bd8c67  vmovaps xmm7, [rsp+0x70]
00007b2719bd8c6d  vmovaps xmm8, [rsp+0x80]
00007b2719bd8c76  vmovaps xmm9, [rsp+0x90]
00007b2719bd8c7f  vmovaps xmm10, [rsp+0xA0]
00007b2719bd8c88  vmovaps xmm12, [rsp+0xB0]
00007b2719bd8c91  vmovaps xmm13, [rsp+0xC0]
00007b2719bd8c9a  vmovaps xmm14, [rsp+0xD0]
00007b2719bd8ca3  vmovaps xmm15, [rsp+0xE0]
00007b2719bd8cac  add rsp, 0xF0
00007b2719bd8cb3  pop r11
00007b2719bd8cb5  pop r10
00007b2719bd8cb7  pop r9
00007b2719bd8cb9  pop r8
00007b2719bd8cbb  pop rsi
00007b2719bd8cbc  pop rdi
00007b2719bd8cbd  pop rdx
00007b2719bd8cbe  pop rcx
00007b2719bd8cbf  pop rax
00007b2719bd8cc0  add rsp, 0x08
00007b2719bd8cc4  jmp 0x00007B2719BD6AE2
00007b2719bd8cc9  sub rsp, 0x08
00007b2719bd8ccd  push rax
00007b2719bd8cce  push rcx
00007b2719bd8ccf  push rdx
00007b2719bd8cd0  push rdi
00007b2719bd8cd1  push rsi
00007b2719bd8cd2  push r8
00007b2719bd8cd4  push r9
00007b2719bd8cd6  push r10
00007b2719bd8cd8  push r11
00007b2719bd8cda  sub rsp, 0xF0
00007b2719bd8ce1  vmovaps [rsp], xmm0
00007b2719bd8ce6  vmovaps [rsp+0x10], xmm1
00007b2719bd8cec  vmovaps [rsp+0x20], xmm2
00007b2719bd8cf2  vmovaps [rsp+0x30], xmm3
00007b2719bd8cf8  vmovaps [rsp+0x40], xmm4
00007b2719bd8cfe  vmovaps [rsp+0x50], xmm5
00007b2719bd8d04  vmovaps [rsp+0x60], xmm6
00007b2719bd8d0a  vmovaps [rsp+0x70], xmm7
00007b2719bd8d10  vmovaps [rsp+0x80], xmm8
00007b2719bd8d19  vmovaps [rsp+0x90], xmm9
00007b2719bd8d22  vmovaps [rsp+0xA0], xmm11
00007b2719bd8d2b  vmovaps [rsp+0xB0], xmm12
00007b2719bd8d34  vmovaps [rsp+0xC0], xmm13
00007b2719bd8d3d  vmovaps [rsp+0xD0], xmm14
00007b2719bd8d46  vmovaps [rsp+0xE0], xmm15
00007b2719bd8d4f  sub rsp, 0x40
00007b2719bd8d53  lea rdi, [rsp]
00007b2719bd8d57  lea rsi, [rsp+0x10]
00007b2719bd8d5c  lea rdx, [rsp+0x20]
00007b2719bd8d61  lea rcx, [rsp+0x30]
00007b2719bd8d66  mov r8d, 0x00
00007b2719bd8d6c  lea r9, [r15+0x3A8]
00007b2719bd8d73  movaps [rdi], xmm10
00007b2719bd8d77  movaps [rsi], xmm12
00007b2719bd8d7b  movaps [rdx], xmm13
00007b2719bd8d7f  movaps [rcx], xmm1
00007b2719bd8d82  mov rax, 0x5A8E6560CA50
00007b2719bd8d8c  call rax
00007b2719bd8d8e  movaps xmm10, [rsp]
00007b2719bd8d93  add rsp, 0x40
00007b2719bd8d97  vmovaps xmm0, [rsp]
00007b2719bd8d9c  vmovaps xmm1, [rsp+0x10]
00007b2719bd8da2  vmovaps xmm2, [rsp+0x20]
00007b2719bd8da8  vmovaps xmm3, [rsp+0x30]
00007b2719bd8dae  vmovaps xmm4, [rsp+0x40]
00007b2719bd8db4  vmovaps xmm5, [rsp+0x50]
00007b2719bd8dba  vmovaps xmm6, [rsp+0x60]
00007b2719bd8dc0  vmovaps xmm7, [rsp+0x70]
00007b2719bd8dc6  vmovaps xmm8, [rsp+0x80]
00007b2719bd8dcf  vmovaps xmm9, [rsp+0x90]
00007b2719bd8dd8  vmovaps xmm11, [rsp+0xA0]
00007b2719bd8de1  vmovaps xmm12, [rsp+0xB0]
00007b2719bd8dea  vmovaps xmm13, [rsp+0xC0]
00007b2719bd8df3  vmovaps xmm14, [rsp+0xD0]
00007b2719bd8dfc  vmovaps xmm15, [rsp+0xE0]
00007b2719bd8e05  add rsp, 0xF0
00007b2719bd8e0c  pop r11
00007b2719bd8e0e  pop r10
00007b2719bd8e10  pop r9
00007b2719bd8e12  pop r8
00007b2719bd8e14  pop rsi
00007b2719bd8e15  pop rdi
00007b2719bd8e16  pop rdx
00007b2719bd8e17  pop rcx
00007b2719bd8e18  pop rax
00007b2719bd8e19  add rsp, 0x08
00007b2719bd8e1d  jmp 0x00007B2719BD6B08
00007b2719bd8e22  call 0x00007B2719AD64F0
00007b2719bd8e27  jmp 0x00007B2719BD6B12
00007b2719bd8e2c  call 0x00007B2719AE3320
00007b2719bd8e31  jmp 0x00007B2719BD6B1C
00007b2719bd8e36  sub rsp, 0x08
00007b2719bd8e3a  push rax
00007b2719bd8e3b  push rcx
00007b2719bd8e3c  push rdx
00007b2719bd8e3d  push rdi
00007b2719bd8e3e  push rsi
00007b2719bd8e3f  push r8
00007b2719bd8e41  push r9
00007b2719bd8e43  push r10
00007b2719bd8e45  push r11
00007b2719bd8e47  sub rsp, 0xF0
00007b2719bd8e4e  vmovaps [rsp], xmm0
00007b2719bd8e53  vmovaps [rsp+0x10], xmm1
00007b2719bd8e59  vmovaps [rsp+0x20], xmm2
00007b2719bd8e5f  vmovaps [rsp+0x30], xmm3
00007b2719bd8e65  vmovaps [rsp+0x40], xmm4
00007b2719bd8e6b  vmovaps [rsp+0x50], xmm5
00007b2719bd8e71  vmovaps [rsp+0x60], xmm6
00007b2719bd8e77  vmovaps [rsp+0x70], xmm7
00007b2719bd8e7d  vmovaps [rsp+0x80], xmm9
00007b2719bd8e86  vmovaps [rsp+0x90], xmm10
00007b2719bd8e8f  vmovaps [rsp+0xA0], xmm11
00007b2719bd8e98  vmovaps [rsp+0xB0], xmm12
00007b2719bd8ea1  vmovaps [rsp+0xC0], xmm13
00007b2719bd8eaa  vmovaps [rsp+0xD0], xmm14
00007b2719bd8eb3  vmovaps [rsp+0xE0], xmm15
00007b2719bd8ebc  sub rsp, 0x40
00007b2719bd8ec0  lea rdi, [rsp]
00007b2719bd8ec4  lea rsi, [rsp+0x10]
00007b2719bd8ec9  lea rdx, [rsp+0x20]
00007b2719bd8ece  lea rcx, [rsp+0x30]
00007b2719bd8ed3  mov r8d, 0x00
00007b2719bd8ed9  lea r9, [r15+0x3A8]
00007b2719bd8ee0  movaps [rdi], xmm8
00007b2719bd8ee4  movaps [rsi], xmm7
00007b2719bd8ee7  movaps [rdx], xmm4
00007b2719bd8eea  movaps [rcx], xmm12
00007b2719bd8eee  mov rax, 0x5A8E6560CA50
00007b2719bd8ef8  call rax
00007b2719bd8efa  movaps xmm8, [rsp]
00007b2719bd8eff  add rsp, 0x40
00007b2719bd8f03  vmovaps xmm0, [rsp]
00007b2719bd8f08  vmovaps xmm1, [rsp+0x10]
00007b2719bd8f0e  vmovaps xmm2, [rsp+0x20]
00007b2719bd8f14  vmovaps xmm3, [rsp+0x30]
00007b2719bd8f1a  vmovaps xmm4, [rsp+0x40]
00007b2719bd8f20  vmovaps xmm5, [rsp+0x50]
00007b2719bd8f26  vmovaps xmm6, [rsp+0x60]
00007b2719bd8f2c  vmovaps xmm7, [rsp+0x70]
00007b2719bd8f32  vmovaps xmm9, [rsp+0x80]
00007b2719bd8f3b  vmovaps xmm10, [rsp+0x90]
00007b2719bd8f44  vmovaps xmm11, [rsp+0xA0]
00007b2719bd8f4d  vmovaps xmm12, [rsp+0xB0]
00007b2719bd8f56  vmovaps xmm13, [rsp+0xC0]
00007b2719bd8f5f  vmovaps xmm14, [rsp+0xD0]
00007b2719bd8f68  vmovaps xmm15, [rsp+0xE0]
00007b2719bd8f71  add rsp, 0xF0
00007b2719bd8f78  pop r11
00007b2719bd8f7a  pop r10
00007b2719bd8f7c  pop r9
00007b2719bd8f7e  pop r8
00007b2719bd8f80  pop rsi
00007b2719bd8f81  pop rdi
00007b2719bd8f82  pop rdx
00007b2719bd8f83  pop rcx
00007b2719bd8f84  pop rax
00007b2719bd8f85  add rsp, 0x08
00007b2719bd8f89  jmp 0x00007B2719BD6B45
00007b2719bd8f8e  sub rsp, 0x08
00007b2719bd8f92  push rax
00007b2719bd8f93  push rcx
00007b2719bd8f94  push rdx
00007b2719bd8f95  push rdi
00007b2719bd8f96  push rsi
00007b2719bd8f97  push r8
00007b2719bd8f99  push r9
00007b2719bd8f9b  push r10
00007b2719bd8f9d  push r11
00007b2719bd8f9f  sub rsp, 0xF0
00007b2719bd8fa6  vmovaps [rsp], xmm0
00007b2719bd8fab  vmovaps [rsp+0x10], xmm1
00007b2719bd8fb1  vmovaps [rsp+0x20], xmm2
00007b2719bd8fb7  vmovaps [rsp+0x30], xmm3
00007b2719bd8fbd  vmovaps [rsp+0x40], xmm4
00007b2719bd8fc3  vmovaps [rsp+0x50], xmm5
00007b2719bd8fc9  vmovaps [rsp+0x60], xmm6
00007b2719bd8fcf  vmovaps [rsp+0x70], xmm8
00007b2719bd8fd5  vmovaps [rsp+0x80], xmm9
00007b2719bd8fde  vmovaps [rsp+0x90], xmm10
00007b2719bd8fe7  vmovaps [rsp+0xA0], xmm11
00007b2719bd8ff0  vmovaps [rsp+0xB0], xmm12
00007b2719bd8ff9  vmovaps [rsp+0xC0], xmm13
00007b2719bd9002  vmovaps [rsp+0xD0], xmm14
00007b2719bd900b  vmovaps [rsp+0xE0], xmm15
00007b2719bd9014  sub rsp, 0x40
00007b2719bd9018  lea rdi, [rsp]
00007b2719bd901c  lea rsi, [rsp+0x10]
00007b2719bd9021  lea rdx, [rsp+0x20]
00007b2719bd9026  lea rcx, [rsp+0x30]
00007b2719bd902b  mov r8d, 0x00
00007b2719bd9031  lea r9, [r15+0x3A8]
00007b2719bd9038  movaps [rdi], xmm7
00007b2719bd903b  movaps [rsi], xmm9
00007b2719bd903f  movaps [rdx], xmm14
00007b2719bd9043  movaps [rcx], xmm12
00007b2719bd9047  mov rax, 0x5A8E6560CA50
00007b2719bd9051  call rax
00007b2719bd9053  movaps xmm7, [rsp]
00007b2719bd9057  add rsp, 0x40
00007b2719bd905b  vmovaps xmm0, [rsp]
00007b2719bd9060  vmovaps xmm1, [rsp+0x10]
00007b2719bd9066  vmovaps xmm2, [rsp+0x20]
00007b2719bd906c  vmovaps xmm3, [rsp+0x30]
00007b2719bd9072  vmovaps xmm4, [rsp+0x40]
00007b2719bd9078  vmovaps xmm5, [rsp+0x50]
00007b2719bd907e  vmovaps xmm6, [rsp+0x60]
00007b2719bd9084  vmovaps xmm8, [rsp+0x70]
00007b2719bd908a  vmovaps xmm9, [rsp+0x80]
00007b2719bd9093  vmovaps xmm10, [rsp+0x90]
00007b2719bd909c  vmovaps xmm11, [rsp+0xA0]
00007b2719bd90a5  vmovaps xmm12, [rsp+0xB0]
00007b2719bd90ae  vmovaps xmm13, [rsp+0xC0]
00007b2719bd90b7  vmovaps xmm14, [rsp+0xD0]
00007b2719bd90c0  vmovaps xmm15, [rsp+0xE0]
00007b2719bd90c9  add rsp, 0xF0
00007b2719bd90d0  pop r11
00007b2719bd90d2  pop r10
00007b2719bd90d4  pop r9
00007b2719bd90d6  pop r8
00007b2719bd90d8  pop rsi
00007b2719bd90d9  pop rdi
00007b2719bd90da  pop rdx
00007b2719bd90db  pop rcx
00007b2719bd90dc  pop rax
00007b2719bd90dd  add rsp, 0x08
00007b2719bd90e1  jmp 0x00007B2719BD6B6D
00007b2719bd90e6  sub rsp, 0x08
00007b2719bd90ea  push rax
00007b2719bd90eb  push rcx
00007b2719bd90ec  push rdx
00007b2719bd90ed  push rdi
00007b2719bd90ee  push rsi
00007b2719bd90ef  push r8
00007b2719bd90f1  push r9
00007b2719bd90f3  push r10
00007b2719bd90f5  push r11
00007b2719bd90f7  sub rsp, 0xF0
00007b2719bd90fe  vmovaps [rsp], xmm0
00007b2719bd9103  vmovaps [rsp+0x10], xmm1
00007b2719bd9109  vmovaps [rsp+0x20], xmm2
00007b2719bd910f  vmovaps [rsp+0x30], xmm3
00007b2719bd9115  vmovaps [rsp+0x40], xmm4
00007b2719bd911b  vmovaps [rsp+0x50], xmm5
00007b2719bd9121  vmovaps [rsp+0x60], xmm6
00007b2719bd9127  vmovaps [rsp+0x70], xmm7
00007b2719bd912d  vmovaps [rsp+0x80], xmm8
00007b2719bd9136  vmovaps [rsp+0x90], xmm9
00007b2719bd913f  vmovaps [rsp+0xA0], xmm10
00007b2719bd9148  vmovaps [rsp+0xB0], xmm11
00007b2719bd9151  vmovaps [rsp+0xC0], xmm13
00007b2719bd915a  vmovaps [rsp+0xD0], xmm14
00007b2719bd9163  vmovaps [rsp+0xE0], xmm15
00007b2719bd916c  sub rsp, 0x40
00007b2719bd9170  lea rdi, [rsp]
00007b2719bd9174  lea rsi, [rsp+0x10]
00007b2719bd9179  lea rdx, [rsp+0x20]
00007b2719bd917e  lea rcx, [rsp+0x30]
00007b2719bd9183  mov r8d, 0x00
00007b2719bd9189  lea r9, [r15+0x3A8]
00007b2719bd9190  movaps [rdi], xmm12
00007b2719bd9194  movaps [rsi], xmm11
00007b2719bd9198  movaps [rdx], xmm15
00007b2719bd919c  movaps [rcx], xmm14
00007b2719bd91a0  mov rax, 0x5A8E6560CA50
00007b2719bd91aa  call rax
00007b2719bd91ac  movaps xmm12, [rsp]
00007b2719bd91b1  add rsp, 0x40
00007b2719bd91b5  vmovaps xmm0, [rsp]
00007b2719bd91ba  vmovaps xmm1, [rsp+0x10]
00007b2719bd91c0  vmovaps xmm2, [rsp+0x20]
00007b2719bd91c6  vmovaps xmm3, [rsp+0x30]
00007b2719bd91cc  vmovaps xmm4, [rsp+0x40]
00007b2719bd91d2  vmovaps xmm5, [rsp+0x50]
00007b2719bd91d8  vmovaps xmm6, [rsp+0x60]
00007b2719bd91de  vmovaps xmm7, [rsp+0x70]
00007b2719bd91e4  vmovaps xmm8, [rsp+0x80]
00007b2719bd91ed  vmovaps xmm9, [rsp+0x90]
00007b2719bd91f6  vmovaps xmm10, [rsp+0xA0]
00007b2719bd91ff  vmovaps xmm11, [rsp+0xB0]
00007b2719bd9208  vmovaps xmm13, [rsp+0xC0]
00007b2719bd9211  vmovaps xmm14, [rsp+0xD0]
00007b2719bd921a  vmovaps xmm15, [rsp+0xE0]
00007b2719bd9223  add rsp, 0xF0
00007b2719bd922a  pop r11
00007b2719bd922c  pop r10
00007b2719bd922e  pop r9
00007b2719bd9230  pop r8
00007b2719bd9232  pop rsi
00007b2719bd9233  pop rdi
00007b2719bd9234  pop rdx
00007b2719bd9235  pop rcx
00007b2719bd9236  pop rax
00007b2719bd9237  add rsp, 0x08
00007b2719bd923b  jmp 0x00007B2719BD6B96
00007b2719bd9240  sub rsp, 0x08
00007b2719bd9244  push rax
00007b2719bd9245  push rcx
00007b2719bd9246  push rdx
00007b2719bd9247  push rdi
00007b2719bd9248  push rsi
00007b2719bd9249  push r8
00007b2719bd924b  push r9
00007b2719bd924d  push r10
00007b2719bd924f  push r11
00007b2719bd9251  sub rsp, 0xF0
00007b2719bd9258  vmovaps [rsp], xmm0
00007b2719bd925d  vmovaps [rsp+0x10], xmm1
00007b2719bd9263  vmovaps [rsp+0x20], xmm2
00007b2719bd9269  vmovaps [rsp+0x30], xmm3
00007b2719bd926f  vmovaps [rsp+0x40], xmm4
00007b2719bd9275  vmovaps [rsp+0x50], xmm5
00007b2719bd927b  vmovaps [rsp+0x60], xmm6
00007b2719bd9281  vmovaps [rsp+0x70], xmm7
00007b2719bd9287  vmovaps [rsp+0x80], xmm8
00007b2719bd9290  vmovaps [rsp+0x90], xmm9
00007b2719bd9299  vmovaps [rsp+0xA0], xmm10
00007b2719bd92a2  vmovaps [rsp+0xB0], xmm12
00007b2719bd92ab  vmovaps [rsp+0xC0], xmm13
00007b2719bd92b4  vmovaps [rsp+0xD0], xmm14
00007b2719bd92bd  vmovaps [rsp+0xE0], xmm15
00007b2719bd92c6  sub rsp, 0x40
00007b2719bd92ca  lea rdi, [rsp]
00007b2719bd92ce  lea rsi, [rsp+0x10]
00007b2719bd92d3  lea rdx, [rsp+0x20]
00007b2719bd92d8  lea rcx, [rsp+0x30]
00007b2719bd92dd  mov r8d, 0x00
00007b2719bd92e3  lea r9, [r15+0x3A8]
00007b2719bd92ea  movaps [rdi], xmm11
00007b2719bd92ee  movaps [rsi], xmm10
00007b2719bd92f2  movaps [rdx], xmm13
00007b2719bd92f6  movaps [rcx], xmm15
00007b2719bd92fa  mov rax, 0x5A8E6560CA50
00007b2719bd9304  call rax
00007b2719bd9306  movaps xmm11, [rsp]
00007b2719bd930b  add rsp, 0x40
00007b2719bd930f  vmovaps xmm0, [rsp]
00007b2719bd9314  vmovaps xmm1, [rsp+0x10]
00007b2719bd931a  vmovaps xmm2, [rsp+0x20]
00007b2719bd9320  vmovaps xmm3, [rsp+0x30]
00007b2719bd9326  vmovaps xmm4, [rsp+0x40]
00007b2719bd932c  vmovaps xmm5, [rsp+0x50]
00007b2719bd9332  vmovaps xmm6, [rsp+0x60]
00007b2719bd9338  vmovaps xmm7, [rsp+0x70]
00007b2719bd933e  vmovaps xmm8, [rsp+0x80]
00007b2719bd9347  vmovaps xmm9, [rsp+0x90]
00007b2719bd9350  vmovaps xmm10, [rsp+0xA0]
00007b2719bd9359  vmovaps xmm12, [rsp+0xB0]
00007b2719bd9362  vmovaps xmm13, [rsp+0xC0]
00007b2719bd936b  vmovaps xmm14, [rsp+0xD0]
00007b2719bd9374  vmovaps xmm15, [rsp+0xE0]
00007b2719bd937d  add rsp, 0xF0
00007b2719bd9384  pop r11
00007b2719bd9386  pop r10
00007b2719bd9388  pop r9
00007b2719bd938a  pop r8
00007b2719bd938c  pop rsi
00007b2719bd938d  pop rdi
00007b2719bd938e  pop rdx
00007b2719bd938f  pop rcx
00007b2719bd9390  pop rax
00007b2719bd9391  add rsp, 0x08
00007b2719bd9395  jmp 0x00007B2719BD6BBF
00007b2719bd939a  call 0x00007B2719AE5820
00007b2719bd939f  jmp 0x00007B2719BD6BCC
00007b2719bd93a4  call 0x00007B2719AE45A0
00007b2719bd93a9  jmp 0x00007B2719BD6BD9
00007b2719bd93ae  sub rsp, 0x08
00007b2719bd93b2  push rax
00007b2719bd93b3  push rcx
00007b2719bd93b4  push rdx
00007b2719bd93b5  push rdi
00007b2719bd93b6  push rsi
00007b2719bd93b7  push r8
00007b2719bd93b9  push r9
00007b2719bd93bb  push r10
00007b2719bd93bd  push r11
00007b2719bd93bf  sub rsp, 0xF0
00007b2719bd93c6  vmovaps [rsp], xmm0
00007b2719bd93cb  vmovaps [rsp+0x10], xmm1
00007b2719bd93d1  vmovaps [rsp+0x20], xmm2
00007b2719bd93d7  vmovaps [rsp+0x30], xmm3
00007b2719bd93dd  vmovaps [rsp+0x40], xmm4
00007b2719bd93e3  vmovaps [rsp+0x50], xmm5
00007b2719bd93e9  vmovaps [rsp+0x60], xmm6
00007b2719bd93ef  vmovaps [rsp+0x70], xmm7
00007b2719bd93f5  vmovaps [rsp+0x80], xmm8
00007b2719bd93fe  vmovaps [rsp+0x90], xmm9
00007b2719bd9407  vmovaps [rsp+0xA0], xmm11
00007b2719bd9410  vmovaps [rsp+0xB0], xmm12
00007b2719bd9419  vmovaps [rsp+0xC0], xmm13
00007b2719bd9422  vmovaps [rsp+0xD0], xmm14
00007b2719bd942b  vmovaps [rsp+0xE0], xmm15
00007b2719bd9434  sub rsp, 0x40
00007b2719bd9438  lea rdi, [rsp]
00007b2719bd943c  lea rsi, [rsp+0x10]
00007b2719bd9441  lea rdx, [rsp+0x20]
00007b2719bd9446  lea rcx, [rsp+0x30]
00007b2719bd944b  mov r8d, 0x00
00007b2719bd9451  lea r9, [r15+0x3A8]
00007b2719bd9458  movaps [rdi], xmm10
00007b2719bd945c  movaps [rsi], xmm8
00007b2719bd9460  movaps [rdx], xmm1
00007b2719bd9463  movaps [rcx], xmm13
00007b2719bd9467  mov rax, 0x5A8E6560CA50
00007b2719bd9471  call rax
00007b2719bd9473  movaps xmm10, [rsp]
00007b2719bd9478  add rsp, 0x40
00007b2719bd947c  vmovaps xmm0, [rsp]
00007b2719bd9481  vmovaps xmm1, [rsp+0x10]
00007b2719bd9487  vmovaps xmm2, [rsp+0x20]
00007b2719bd948d  vmovaps xmm3, [rsp+0x30]
00007b2719bd9493  vmovaps xmm4, [rsp+0x40]
00007b2719bd9499  vmovaps xmm5, [rsp+0x50]
00007b2719bd949f  vmovaps xmm6, [rsp+0x60]
00007b2719bd94a5  vmovaps xmm7, [rsp+0x70]
00007b2719bd94ab  vmovaps xmm8, [rsp+0x80]
00007b2719bd94b4  vmovaps xmm9, [rsp+0x90]
00007b2719bd94bd  vmovaps xmm11, [rsp+0xA0]
00007b2719bd94c6  vmovaps xmm12, [rsp+0xB0]
00007b2719bd94cf  vmovaps xmm13, [rsp+0xC0]
00007b2719bd94d8  vmovaps xmm14, [rsp+0xD0]
00007b2719bd94e1  vmovaps xmm15, [rsp+0xE0]
00007b2719bd94ea  add rsp, 0xF0
00007b2719bd94f1  pop r11
00007b2719bd94f3  pop r10
00007b2719bd94f5  pop r9
00007b2719bd94f7  pop r8
00007b2719bd94f9  pop rsi
00007b2719bd94fa  pop rdi
00007b2719bd94fb  pop rdx
00007b2719bd94fc  pop rcx
00007b2719bd94fd  pop rax
00007b2719bd94fe  add rsp, 0x08
00007b2719bd9502  jmp 0x00007B2719BD6C0F
00007b2719bd9507  call 0x00007B2719AD64F0
00007b2719bd950c  jmp 0x00007B2719BD6C21
00007b2719bd9511  sub rsp, 0x08
00007b2719bd9515  push rax
00007b2719bd9516  push rcx
00007b2719bd9517  push rdx
00007b2719bd9518  push rdi
00007b2719bd9519  push rsi
00007b2719bd951a  push r8
00007b2719bd951c  push r9
00007b2719bd951e  push r10
00007b2719bd9520  push r11
00007b2719bd9522  sub rsp, 0xF0
00007b2719bd9529  vmovaps [rsp], xmm0
00007b2719bd952e  vmovaps [rsp+0x10], xmm1
00007b2719bd9534  vmovaps [rsp+0x20], xmm2
00007b2719bd953a  vmovaps [rsp+0x30], xmm3
00007b2719bd9540  vmovaps [rsp+0x40], xmm4
00007b2719bd9546  vmovaps [rsp+0x50], xmm5
00007b2719bd954c  vmovaps [rsp+0x60], xmm6
00007b2719bd9552  vmovaps [rsp+0x70], xmm7
00007b2719bd9558  vmovaps [rsp+0x80], xmm8
00007b2719bd9561  vmovaps [rsp+0x90], xmm10
00007b2719bd956a  vmovaps [rsp+0xA0], xmm11
00007b2719bd9573  vmovaps [rsp+0xB0], xmm12
00007b2719bd957c  vmovaps [rsp+0xC0], xmm13
00007b2719bd9585  vmovaps [rsp+0xD0], xmm14
00007b2719bd958e  vmovaps [rsp+0xE0], xmm15
00007b2719bd9597  sub rsp, 0x40
00007b2719bd959b  lea rdi, [rsp]
00007b2719bd959f  lea rsi, [rsp+0x10]
00007b2719bd95a4  lea rdx, [rsp+0x20]
00007b2719bd95a9  lea rcx, [rsp+0x30]
00007b2719bd95ae  mov r8d, 0x00
00007b2719bd95b4  lea r9, [r15+0x3A8]
00007b2719bd95bb  movaps [rdi], xmm9
00007b2719bd95bf  movaps [rsi], xmm7
00007b2719bd95c2  movaps [rdx], xmm14
00007b2719bd95c6  movaps [rcx], xmm13
00007b2719bd95ca  mov rax, 0x5A8E6560CA50
00007b2719bd95d4  call rax
00007b2719bd95d6  movaps xmm9, [rsp]
00007b2719bd95db  add rsp, 0x40
00007b2719bd95df  vmovaps xmm0, [rsp]
00007b2719bd95e4  vmovaps xmm1, [rsp+0x10]
00007b2719bd95ea  vmovaps xmm2, [rsp+0x20]
00007b2719bd95f0  vmovaps xmm3, [rsp+0x30]
00007b2719bd95f6  vmovaps xmm4, [rsp+0x40]
00007b2719bd95fc  vmovaps xmm5, [rsp+0x50]
00007b2719bd9602  vmovaps xmm6, [rsp+0x60]
00007b2719bd9608  vmovaps xmm7, [rsp+0x70]
00007b2719bd960e  vmovaps xmm8, [rsp+0x80]
00007b2719bd9617  vmovaps xmm10, [rsp+0x90]
00007b2719bd9620  vmovaps xmm11, [rsp+0xA0]
00007b2719bd9629  vmovaps xmm12, [rsp+0xB0]
00007b2719bd9632  vmovaps xmm13, [rsp+0xC0]
00007b2719bd963b  vmovaps xmm14, [rsp+0xD0]
00007b2719bd9644  vmovaps xmm15, [rsp+0xE0]
00007b2719bd964d  add rsp, 0xF0
00007b2719bd9654  pop r11
00007b2719bd9656  pop r10
00007b2719bd9658  pop r9
00007b2719bd965a  pop r8
00007b2719bd965c  pop rsi
00007b2719bd965d  pop rdi
00007b2719bd965e  pop rdx
00007b2719bd965f  pop rcx
00007b2719bd9660  pop rax
00007b2719bd9661  add rsp, 0x08
00007b2719bd9665  jmp 0x00007B2719BD6C4F
00007b2719bd966a  sub rsp, 0x08
00007b2719bd966e  push rax
00007b2719bd966f  push rcx
00007b2719bd9670  push rdx
00007b2719bd9671  push rdi
00007b2719bd9672  push rsi
00007b2719bd9673  push r8
00007b2719bd9675  push r9
00007b2719bd9677  push r10
00007b2719bd9679  push r11
00007b2719bd967b  sub rsp, 0xF0
00007b2719bd9682  vmovaps [rsp], xmm0
00007b2719bd9687  vmovaps [rsp+0x10], xmm1
00007b2719bd968d  vmovaps [rsp+0x20], xmm2
00007b2719bd9693  vmovaps [rsp+0x30], xmm3
00007b2719bd9699  vmovaps [rsp+0x40], xmm4
00007b2719bd969f  vmovaps [rsp+0x50], xmm5
00007b2719bd96a5  vmovaps [rsp+0x60], xmm6
00007b2719bd96ab  vmovaps [rsp+0x70], xmm7
00007b2719bd96b1  vmovaps [rsp+0x80], xmm8
00007b2719bd96ba  vmovaps [rsp+0x90], xmm9
00007b2719bd96c3  vmovaps [rsp+0xA0], xmm10
00007b2719bd96cc  vmovaps [rsp+0xB0], xmm11
00007b2719bd96d5  vmovaps [rsp+0xC0], xmm12
00007b2719bd96de  vmovaps [rsp+0xD0], xmm14
00007b2719bd96e7  vmovaps [rsp+0xE0], xmm15
00007b2719bd96f0  sub rsp, 0x40
00007b2719bd96f4  lea rdi, [rsp]
00007b2719bd96f8  lea rsi, [rsp+0x10]
00007b2719bd96fd  lea rdx, [rsp+0x20]
00007b2719bd9702  lea rcx, [rsp+0x30]
00007b2719bd9707  mov r8d, 0x00
00007b2719bd970d  lea r9, [r15+0x3A8]
00007b2719bd9714  movaps [rdi], xmm13
00007b2719bd9718  movaps [rsi], xmm12
00007b2719bd971c  movaps [rdx], xmm15
00007b2719bd9720  movaps [rcx], xmm14
00007b2719bd9724  mov rax, 0x5A8E6560CA50
00007b2719bd972e  call rax
00007b2719bd9730  movaps xmm13, [rsp]
00007b2719bd9735  add rsp, 0x40
00007b2719bd9739  vmovaps xmm0, [rsp]
00007b2719bd973e  vmovaps xmm1, [rsp+0x10]
00007b2719bd9744  vmovaps xmm2, [rsp+0x20]
00007b2719bd974a  vmovaps xmm3, [rsp+0x30]
00007b2719bd9750  vmovaps xmm4, [rsp+0x40]
00007b2719bd9756  vmovaps xmm5, [rsp+0x50]
00007b2719bd975c  vmovaps xmm6, [rsp+0x60]
00007b2719bd9762  vmovaps xmm7, [rsp+0x70]
00007b2719bd9768  vmovaps xmm8, [rsp+0x80]
00007b2719bd9771  vmovaps xmm9, [rsp+0x90]
00007b2719bd977a  vmovaps xmm10, [rsp+0xA0]
00007b2719bd9783  vmovaps xmm11, [rsp+0xB0]
00007b2719bd978c  vmovaps xmm12, [rsp+0xC0]
00007b2719bd9795  vmovaps xmm14, [rsp+0xD0]
00007b2719bd979e  vmovaps xmm15, [rsp+0xE0]
00007b2719bd97a7  add rsp, 0xF0
00007b2719bd97ae  pop r11
00007b2719bd97b0  pop r10
00007b2719bd97b2  pop r9
00007b2719bd97b4  pop r8
00007b2719bd97b6  pop rsi
00007b2719bd97b7  pop rdi
00007b2719bd97b8  pop rdx
00007b2719bd97b9  pop rcx
00007b2719bd97ba  pop rax
00007b2719bd97bb  add rsp, 0x08
00007b2719bd97bf  jmp 0x00007B2719BD6C7D
00007b2719bd97c4  sub rsp, 0x08
00007b2719bd97c8  push rax
00007b2719bd97c9  push rcx
00007b2719bd97ca  push rdx
00007b2719bd97cb  push rdi
00007b2719bd97cc  push rsi
00007b2719bd97cd  push r8
00007b2719bd97cf  push r9
00007b2719bd97d1  push r10
00007b2719bd97d3  push r11
00007b2719bd97d5  sub rsp, 0xF0
00007b2719bd97dc  vmovaps [rsp], xmm0
00007b2719bd97e1  vmovaps [rsp+0x10], xmm1
00007b2719bd97e7  vmovaps [rsp+0x20], xmm2
00007b2719bd97ed  vmovaps [rsp+0x30], xmm3
00007b2719bd97f3  vmovaps [rsp+0x40], xmm4
00007b2719bd97f9  vmovaps [rsp+0x50], xmm5
00007b2719bd97ff  vmovaps [rsp+0x60], xmm6
00007b2719bd9805  vmovaps [rsp+0x70], xmm7
00007b2719bd980b  vmovaps [rsp+0x80], xmm8
00007b2719bd9814  vmovaps [rsp+0x90], xmm9
00007b2719bd981d  vmovaps [rsp+0xA0], xmm10
00007b2719bd9826  vmovaps [rsp+0xB0], xmm11
00007b2719bd982f  vmovaps [rsp+0xC0], xmm12
00007b2719bd9838  vmovaps [rsp+0xD0], xmm13
00007b2719bd9841  vmovaps [rsp+0xE0], xmm15
00007b2719bd984a  sub rsp, 0x40
00007b2719bd984e  lea rdi, [rsp]
00007b2719bd9852  lea rsi, [rsp+0x10]
00007b2719bd9857  lea rdx, [rsp+0x20]
00007b2719bd985c  lea rcx, [rsp+0x30]
00007b2719bd9861  mov r8d, 0x00
00007b2719bd9867  lea r9, [r15+0x3A8]
00007b2719bd986e  movaps [rdi], xmm14
00007b2719bd9872  movaps [rsi], xmm11
00007b2719bd9876  movaps [rdx], xmm1
00007b2719bd9879  movaps [rcx], xmm15
00007b2719bd987d  mov rax, 0x5A8E6560CA50
00007b2719bd9887  call rax
00007b2719bd9889  movaps xmm14, [rsp]
00007b2719bd988e  add rsp, 0x40
00007b2719bd9892  vmovaps xmm0, [rsp]
00007b2719bd9897  vmovaps xmm1, [rsp+0x10]
00007b2719bd989d  vmovaps xmm2, [rsp+0x20]
00007b2719bd98a3  vmovaps xmm3, [rsp+0x30]
00007b2719bd98a9  vmovaps xmm4, [rsp+0x40]
00007b2719bd98af  vmovaps xmm5, [rsp+0x50]
00007b2719bd98b5  vmovaps xmm6, [rsp+0x60]
00007b2719bd98bb  vmovaps xmm7, [rsp+0x70]
00007b2719bd98c1  vmovaps xmm8, [rsp+0x80]
00007b2719bd98ca  vmovaps xmm9, [rsp+0x90]
00007b2719bd98d3  vmovaps xmm10, [rsp+0xA0]
00007b2719bd98dc  vmovaps xmm11, [rsp+0xB0]
00007b2719bd98e5  vmovaps xmm12, [rsp+0xC0]
00007b2719bd98ee  vmovaps xmm13, [rsp+0xD0]
00007b2719bd98f7  vmovaps xmm15, [rsp+0xE0]
00007b2719bd9900  add rsp, 0xF0
00007b2719bd9907  pop r11
00007b2719bd9909  pop r10
00007b2719bd990b  pop r9
00007b2719bd990d  pop r8
00007b2719bd990f  pop rsi
00007b2719bd9910  pop rdi
00007b2719bd9911  pop rdx
00007b2719bd9912  pop rcx
00007b2719bd9913  pop rax
00007b2719bd9914  add rsp, 0x08
00007b2719bd9918  jmp 0x00007B2719BD6CAB
00007b2719bd991d  call 0x00007B2719AACF70
00007b2719bd9922  jmp 0x00007B2719BD6CB9
00007b2719bd9927  call 0x00007B2719A0C380
00007b2719bd992c  jmp 0x00007B2719BD6CC3
00007b2719bd9931  call 0x00007B2719A08C20
00007b2719bd9936  jmp 0x00007B2719BD6CCD
00007b2719bd993b  call 0x00007B2719A0D600
00007b2719bd9940  jmp 0x00007B2719BD6CD7
00007b2719bd9945  int3
00007b2719bd9946  nop [rax+rax*1], ax
00007b2719bd994f  nop
00007b2719bd9950  mov eax, [r15+0x48]
00007b2719bd9954  lea r14d, [eax+0x01]
00007b2719bd9959  mov [rsp+0x10], r14d
00007b2719bd995e  mov r14d, r14d
00007b2719bd9961  mov [r15+0x48], r14
00007b2719bd9965  xor eax, eax
00007b2719bd9967  mov r14d, [rsp+0x10]
00007b2719bd996c  cmp r14d, 0x1F4
00007b2719bd9973  cmc
00007b2719bd9974  lahf
00007b2719bd9975  seto al
00007b2719bd9978  mov [r15+0x108], eax
00007b2719bd997f  mov eax, [r15+0x108]
00007b2719bd9986  sahf
00007b2719bd9987  jnz 0x00007B2719BD99B9
00007b2719bd9989  cmp dword ptr [r15+0x318], 0x00
00007b2719bd9991  jz 0x00007B2719BDD2E0
00007b2719bd9997  nop [rax+rax*1], ax
00007b2719bd99a0  nop [rax+rax*1], eax
00007b2719bd99a8  mov eax, 0x410670
00007b2719bd99ad  mov [r15+0x100], rax
00007b2719bd99b4  jmp 0x00007B27199FE110
00007b2719bd99b9  cmp dword ptr [r15+0x318], 0x00
00007b2719bd99c1  jz 0x00007B2719BD99F0
00007b2719bd99c7  nop [rax+rax*1], ax
00007b2719bd99d0  nop [rax+rax*1], eax
00007b2719bd99d8  mov eax, 0x4104EC
00007b2719bd99dd  mov [r15+0x100], rax
00007b2719bd99e4  jmp 0x00007B27199FE110
00007b2719bd99e9  int3
00007b2719bd99ea  int3
00007b2719bd99eb  nop [rax+rax*1], eax
00007b2719bd99f0  mov rax, [r15+0x40]
00007b2719bd99f4  vxorps xmm1, xmm1, xmm1
00007b2719bd99f8  vpbroadcastq xmm1, xmm1
00007b2719bd99fd  vxorps xmm15, xmm15, xmm15
00007b2719bd9a02  vpbroadcastq xmm15, xmm15
00007b2719bd9a07  lea r14, [rax+0x30]
00007b2719bd9a0b  mov r12, [r13+r14*1]
00007b2719bd9a10  lea r14, [rax+0x38]
00007b2719bd9a14  mov r11, [r13+r14*1]
00007b2719bd9a19  movq xmm14, r12
00007b2719bd9a1e  movq xmm13, r11
00007b2719bd9a23  movq xmm14, xmm14
00007b2719bd9a28  movq xmm13, xmm13
00007b2719bd9a2d  vmovaps [rsp+0x10], xmm13
00007b2719bd9a33  movq xmm13, xmm13
00007b2719bd9a38  movaps [r15+0x270], xmm13
00007b2719bd9a40  movaps xmm13, [r15+0x160]
00007b2719bd9a48  vmovaps [rsp+0x20], xmm13
00007b2719bd9a4e  vmovaps xmm12, [rsp+0x20]
00007b2719bd9a54  por xmm13, xmm12
00007b2719bd9a59  lea r14, [rax+0x20]
00007b2719bd9a5d  mov r12, [r13+r14*1]
00007b2719bd9a62  lea r14, [rax+0x28]
00007b2719bd9a66  mov r11, [r13+r14*1]
00007b2719bd9a6b  movq xmm12, r12
00007b2719bd9a70  movq xmm11, r11
00007b2719bd9a75  movq xmm12, xmm12
00007b2719bd9a7a  movq xmm11, xmm11
00007b2719bd9a7f  movaps xmm10, [r15+0x2D0]
00007b2719bd9a87  vmovaps [rsp+0x20], xmm10
00007b2719bd9a8d  vmovaps xmm9, [rsp+0x20]
00007b2719bd9a93  por xmm10, xmm9
00007b2719bd9a98  movaps xmm9, [r15+0x300]
00007b2719bd9aa0  vmovaps [rsp+0x20], xmm9
00007b2719bd9aa6  vmovaps xmm8, [rsp+0x20]
00007b2719bd9aac  por xmm9, xmm8
00007b2719bd9ab1  movaps xmm8, [r15+0x2B0]
00007b2719bd9ab9  vmovaps [rsp+0x20], xmm8
00007b2719bd9abf  vmovaps xmm7, [rsp+0x20]
00007b2719bd9ac5  por xmm8, xmm7
00007b2719bd9aca  movaps xmm7, [r15+0x180]
00007b2719bd9ad2  vmovaps [rsp+0x20], xmm7
00007b2719bd9ad8  vmovaps xmm6, [rsp+0x20]
00007b2719bd9ade  por xmm7, xmm6
00007b2719bd9ae2  lea r14, [rax+0x10]
00007b2719bd9ae6  mov r12, [r13+r14*1]
00007b2719bd9aeb  lea r14, [rax+0x18]
00007b2719bd9aef  mov r11, [r13+r14*1]
00007b2719bd9af4  movq xmm6, r12
00007b2719bd9af9  movq xmm5, r11
00007b2719bd9afe  movq xmm6, xmm6
00007b2719bd9b02  movq xmm5, xmm5
00007b2719bd9b06  movaps xmm4, [r15+0x200]
00007b2719bd9b0e  vmovaps [rsp+0x20], xmm4
00007b2719bd9b14  vmovaps xmm3, [rsp+0x20]
00007b2719bd9b1a  por xmm4, xmm3
00007b2719bd9b1e  movaps xmm3, [r15+0x1F0]
00007b2719bd9b26  vmovaps [rsp+0x20], xmm3
00007b2719bd9b2c  vmovaps xmm2, [rsp+0x20]
00007b2719bd9b32  por xmm3, xmm2
00007b2719bd9b36  movaps xmm2, [r15+0x2E0]
00007b2719bd9b3e  vmovaps [rsp+0x20], xmm2
00007b2719bd9b44  vmovaps [rsp+0x30], xmm1
00007b2719bd9b4a  vmovaps xmm1, [rsp+0x20]
00007b2719bd9b50  por xmm2, xmm1
00007b2719bd9b54  movaps xmm1, [r15+0x2A0]
00007b2719bd9b5c  vmovaps [rsp+0x20], xmm1
00007b2719bd9b62  vmovaps [rsp+0x40], xmm15
00007b2719bd9b68  vmovaps xmm15, [rsp+0x20]
00007b2719bd9b6e  por xmm1, xmm15
00007b2719bd9b73  movaps xmm15, [r15+0x280]
00007b2719bd9b7b  vmovaps [rsp+0x20], xmm15
00007b2719bd9b81  vmovaps [rsp+0x50], xmm1
00007b2719bd9b87  vmovaps xmm1, [rsp+0x20]
00007b2719bd9b8d  por xmm15, xmm1
00007b2719bd9b92  movaps xmm1, [r15+0x1C0]
00007b2719bd9b9a  vmovaps [rsp+0x20], xmm1
00007b2719bd9ba0  vmovaps [rsp+0x60], xmm15
00007b2719bd9ba6  vmovaps xmm15, [rsp+0x20]
00007b2719bd9bac  por xmm1, xmm15
00007b2719bd9bb1  movaps xmm15, [r15+0x210]
00007b2719bd9bb9  vmovaps [rsp+0x20], xmm15
00007b2719bd9bbf  vmovaps [rsp+0x70], xmm1
00007b2719bd9bc5  vmovaps xmm1, [rsp+0x20]
00007b2719bd9bcb  por xmm15, xmm1
00007b2719bd9bd0  mov r14, [r13+rax*1]
00007b2719bd9bd5  vmovq xmm1, r14
00007b2719bd9bda  vpbroadcastq xmm1, xmm1
00007b2719bd9bdf  vmovaps [rsp+0x20], xmm1
00007b2719bd9be5  vxorps xmm1, xmm1, xmm1
00007b2719bd9be9  vpbroadcastq xmm1, xmm1
00007b2719bd9bee  mov r14, [r15+0xF8]
00007b2719bd9bf5  vmovaps [rsp+0x80], xmm1
00007b2719bd9bfe  movups xmm1, [r13+r14*1]
00007b2719bd9c04  vmovaps [rsp+0x90], xmm1
00007b2719bd9c0d  vxorps xmm1, xmm1, xmm1
00007b2719bd9c11  vpbroadcastq xmm1, xmm1
00007b2719bd9c16  lea r12, [rax+0x08]
00007b2719bd9c1a  mov rax, [r13+r12*1]
00007b2719bd9c1f  vmovaps [rsp+0xA0], xmm1
00007b2719bd9c28  movq xmm1, rax
00007b2719bd9c2d  movaps [r15+0x240], xmm1
00007b2719bd9c35  mov rax, [r15+0x50]
00007b2719bd9c39  mov [r15+0x60], rax
00007b2719bd9c3d  mov qword ptr [r15+0x58], 0x40
00007b2719bd9c45  vmovaps xmm1, [rsp+0x30]
00007b2719bd9c4b  vmovaps [rsp+0x30], xmm15
00007b2719bd9c51  vmovaps xmm15, [rsp+0x90]
00007b2719bd9c5a  vmovaps [rsp+0x90], xmm14
00007b2719bd9c63  vmovaps xmm14, [rsp+0x20]
00007b2719bd9c69  vmovaps [rsp+0x20], xmm13
00007b2719bd9c6f  vmovaps [rsp+0xB0], xmm12
00007b2719bd9c78  movaps xmm13, xmm1
00007b2719bd9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd9c87  vptest xmm12, xmm12
00007b2719bd9c8c  jnz 0x00007B2719BDA72F
00007b2719bd9c92  movaps xmm1, [r15+0x250]
00007b2719bd9c9a  vmovaps xmm15, [rsp+0x40]
00007b2719bd9ca0  vmovaps [rsp+0x40], xmm13
00007b2719bd9ca6  movaps xmm12, xmm15
00007b2719bd9caa  vfmadd231pd xmm12, xmm1, xmm14
00007b2719bd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007b2719bd9cb5  vptest xmm13, xmm13
00007b2719bd9cba  jnz 0x00007B2719BDA888
00007b2719bd9cc0  movaps xmm15, [r15+0x1E0]
00007b2719bd9cc8  vmovaps [rsp+0xC0], xmm15
00007b2719bd9cd1  vmovaps xmm13, [rsp+0xC0]
00007b2719bd9cda  por xmm15, xmm13
00007b2719bd9cdf  movaps xmm13, [r15+0x1D0]
00007b2719bd9ce7  vmovaps [rsp+0xC0], xmm13
00007b2719bd9cf0  vmovaps [rsp+0xD0], xmm1
00007b2719bd9cf9  vmovaps xmm1, [rsp+0xC0]
00007b2719bd9d02  por xmm13, xmm1
00007b2719bd9d07  movaps xmm1, [r15+0x2C0]
00007b2719bd9d0f  vmovaps [rsp+0xC0], xmm1
00007b2719bd9d18  vmovaps [rsp+0xE0], xmm15
00007b2719bd9d21  vmovaps xmm15, [rsp+0xC0]
00007b2719bd9d2a  por xmm1, xmm15
00007b2719bd9d2f  movaps xmm15, [r15+0x290]
00007b2719bd9d37  vmovaps [rsp+0xC0], xmm15
00007b2719bd9d40  vmovaps [rsp+0xF0], xmm1
00007b2719bd9d49  vmovaps xmm1, [rsp+0xC0]
00007b2719bd9d52  por xmm15, xmm1
00007b2719bd9d57  movaps xmm1, [r15+0x260]
00007b2719bd9d5f  vmovaps [rsp+0xC0], xmm1
00007b2719bd9d68  vmovaps [rsp+0x100], xmm15
00007b2719bd9d71  vmovaps xmm15, [rsp+0xC0]
00007b2719bd9d7a  por xmm1, xmm15
00007b2719bd9d7f  vmovaps xmm15, [rsp+0xD0]
00007b2719bd9d88  vmovaps [rsp+0xC0], xmm1
00007b2719bd9d91  vmovaps xmm1, [rsp+0xD0]
00007b2719bd9d9a  por xmm15, xmm1
00007b2719bd9d9f  lea r12, [r14+0xC0]
00007b2719bd9da6  movups xmm1, [r13+r12*1]
00007b2719bd9dac  mov [rsp+0xD0], rax
00007b2719bd9db4  xor eax, eax
00007b2719bd9db6  mov r12d, 0x40
00007b2719bd9dbc  mov r11d, 0x200
00007b2719bd9dc2  cmp r12, r11
00007b2719bd9dc5  cmc
00007b2719bd9dc6  lahf
00007b2719bd9dc7  seto al
00007b2719bd9dca  mov [r15+0x108], eax
00007b2719bd9dd1  vmovaps [rsp+0x110], xmm1
00007b2719bd9dda  vmovaps xmm1, [rsp+0x80]
00007b2719bd9de3  vmovaps [rsp+0x80], xmm15
00007b2719bd9dec  vmovaps xmm15, [rsp+0x110]
00007b2719bd9df5  vmovaps [rsp+0x110], xmm13
00007b2719bd9dfe  vmovaps [rsp+0x120], xmm12
00007b2719bd9e07  movaps xmm13, xmm1
00007b2719bd9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd9e16  vptest xmm12, xmm12
00007b2719bd9e1b  jnz 0x00007B2719BDA9EB
00007b2719bd9e21  lea rax, [r14+0xB0]
00007b2719bd9e28  movups xmm1, [r13+rax*1]
00007b2719bd9e2e  vmovaps xmm15, [rsp+0xA0]
00007b2719bd9e37  vmovaps [rsp+0xA0], xmm13
00007b2719bd9e40  movaps xmm12, xmm15
00007b2719bd9e44  vfmadd231pd xmm12, xmm1, xmm14
00007b2719bd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007b2719bd9e4f  vptest xmm13, xmm13
00007b2719bd9e54  jnz 0x00007B2719BDAB4E
00007b2719bd9e5a  vmovaps xmm1, [rsp+0x30]
00007b2719bd9e60  vmovaps xmm15, [rsp+0x30]
00007b2719bd9e66  por xmm1, xmm15
00007b2719bd9e6b  movaps [r15+0x210], xmm1
00007b2719bd9e73  vmovaps xmm15, [rsp+0x70]
00007b2719bd9e79  vmovaps xmm14, [rsp+0x70]
00007b2719bd9e7f  por xmm15, xmm14
00007b2719bd9e84  movaps [r15+0x1C0], xmm15
00007b2719bd9e8c  vmovaps xmm14, [rsp+0x60]
00007b2719bd9e92  vmovaps xmm13, [rsp+0x60]
00007b2719bd9e98  por xmm14, xmm13
00007b2719bd9e9d  movaps [r15+0x280], xmm14
00007b2719bd9ea5  vmovaps xmm13, [rsp+0x50]
00007b2719bd9eab  vmovaps [rsp+0x30], xmm1
00007b2719bd9eb1  vmovaps xmm1, [rsp+0x50]
00007b2719bd9eb7  por xmm13, xmm1
00007b2719bd9ebc  movaps [r15+0x2A0], xmm13
00007b2719bd9ec4  vmovaps [rsp+0x50], xmm2
00007b2719bd9eca  vmovaps xmm1, [rsp+0x50]
00007b2719bd9ed0  por xmm2, xmm1
00007b2719bd9ed4  movaps [r15+0x2E0], xmm2
00007b2719bd9edc  vmovaps [rsp+0x50], xmm3
00007b2719bd9ee2  vmovaps xmm1, [rsp+0x50]
00007b2719bd9ee8  por xmm3, xmm1
00007b2719bd9eec  movaps [r15+0x1F0], xmm3
00007b2719bd9ef4  vmovaps xmm1, [rsp+0x80]
00007b2719bd9efd  vmovaps [rsp+0x50], xmm15
00007b2719bd9f03  vmovaps xmm15, [rsp+0x80]
00007b2719bd9f0c  por xmm1, xmm15
00007b2719bd9f11  movaps [r15+0x250], xmm1
00007b2719bd9f19  vmovaps xmm1, [rsp+0xC0]
00007b2719bd9f22  vmovaps xmm15, [rsp+0xC0]
00007b2719bd9f2b  por xmm1, xmm15
00007b2719bd9f30  movaps [r15+0x260], xmm1
00007b2719bd9f38  vmovaps xmm15, [rsp+0x100]
00007b2719bd9f41  vmovaps [rsp+0x60], xmm1
00007b2719bd9f47  vmovaps xmm1, [rsp+0x100]
00007b2719bd9f50  por xmm15, xmm1
00007b2719bd9f55  movaps [r15+0x290], xmm15
00007b2719bd9f5d  vmovaps xmm1, [rsp+0xF0]
00007b2719bd9f66  vmovaps [rsp+0x70], xmm15
00007b2719bd9f6c  vmovaps xmm15, [rsp+0xF0]
00007b2719bd9f75  por xmm1, xmm15
00007b2719bd9f7a  movaps [r15+0x2C0], xmm1
00007b2719bd9f82  movq xmm15, qword ptr [r15+0x240]
00007b2719bd9f8b  vmovaps [rsp+0x80], xmm15
00007b2719bd9f94  vpermilpd xmm15, xmm15, 0x00
00007b2719bd9f9a  vmovaps [rsp+0xC0], xmm1
00007b2719bd9fa3  vmovaps xmm1, [rsp+0x40]
00007b2719bd9fa9  vmovaps [rsp+0x40], xmm15
00007b2719bd9faf  vmovaps xmm15, [rsp+0x30]
00007b2719bd9fb5  vmovaps [rsp+0x30], xmm14
00007b2719bd9fbb  vmovaps xmm14, [rsp+0x40]
00007b2719bd9fc1  vmovaps [rsp+0x40], xmm13
00007b2719bd9fc7  vmovaps [rsp+0xF0], xmm12
00007b2719bd9fd0  movaps xmm13, xmm1
00007b2719bd9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007b2719bd9fdf  vptest xmm12, xmm12
00007b2719bd9fe4  jnz 0x00007B2719BDACA7
00007b2719bd9fea  vmovaps xmm1, [rsp+0x80]
00007b2719bd9ff3  vpermilpd xmm1, xmm1, 0x00
00007b2719bd9ff9  vmovaps xmm15, [rsp+0xA0]
00007b2719bda002  movaps xmm14, xmm15
00007b2719bda006  vfmadd231pd xmm14, xmm2, xmm1
00007b2719bda00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007b2719bda011  vptest xmm12, xmm12
00007b2719bda016  jnz 0x00007B2719BDAE00
00007b2719bda01c  vmovaps xmm1, [rsp+0x80]
00007b2719bda025  vpermilpd xmm1, xmm1, 0x00
00007b2719bda02b  vmovaps xmm15, [rsp+0x120]
00007b2719bda034  vmovaps xmm12, [rsp+0x50]
00007b2719bda03a  vmovaps [rsp+0x50], xmm14
00007b2719bda040  movaps xmm2, xmm15
00007b2719bda044  vfmadd231pd xmm2, xmm12, xmm1
00007b2719bda049  vcmppd xmm14, xmm2, xmm2, 0x03
00007b2719bda04e  vptest xmm14, xmm14
00007b2719bda053  jnz 0x00007B2719BDAF58
00007b2719bda059  vmovaps xmm1, [rsp+0x110]
00007b2719bda062  vmovaps xmm15, [rsp+0x110]
00007b2719bda06b  por xmm1, xmm15
00007b2719bda070  movaps [r15+0x1D0], xmm1
00007b2719bda078  vmovaps xmm15, [rsp+0x80]
00007b2719bda081  vpermilpd xmm15, xmm15, 0x00
00007b2719bda087  vmovaps xmm14, [rsp+0xF0]
00007b2719bda090  vmovaps [rsp+0x80], xmm1
00007b2719bda099  movaps xmm12, xmm14
00007b2719bda09d  vfmadd231pd xmm12, xmm3, xmm15
00007b2719bda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007b2719bda0a8  vptest xmm1, xmm1
00007b2719bda0ad  jnz 0x00007B2719BDB0AF
00007b2719bda0b3  vmovaps [rsp+0xA0], xmm4
00007b2719bda0bc  vmovaps xmm1, [rsp+0xA0]
00007b2719bda0c5  por xmm4, xmm1
00007b2719bda0c9  movaps [r15+0x200], xmm4
00007b2719bda0d1  vmovaps xmm1, [rsp+0xE0]
00007b2719bda0da  vmovaps xmm15, [rsp+0xE0]
00007b2719bda0e3  por xmm1, xmm15
00007b2719bda0e8  movaps [r15+0x1E0], xmm1
00007b2719bda0f0  vmovaps [rsp+0xA0], xmm8
00007b2719bda0f9  vmovaps xmm1, [rsp+0xA0]
00007b2719bda102  por xmm8, xmm1
00007b2719bda107  movaps [r15+0x2B0], xmm8
00007b2719bda10f  vmovaps [rsp+0xA0], xmm9
00007b2719bda118  vmovaps xmm1, [rsp+0xA0]
00007b2719bda121  por xmm9, xmm1
00007b2719bda126  movaps [r15+0x300], xmm9
00007b2719bda12e  vmovaps [rsp+0xA0], xmm6
00007b2719bda137  vpermilpd xmm6, xmm6, 0x00
00007b2719bda13d  vmovaps xmm14, [rsp+0x60]
00007b2719bda143  movaps xmm9, xmm13
00007b2719bda147  vfmadd231pd xmm9, xmm14, xmm6
00007b2719bda14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007b2719bda152  vptest xmm3, xmm3
00007b2719bda157  jnz 0x00007B2719BDB208
00007b2719bda15d  vmovaps xmm14, [rsp+0xA0]
00007b2719bda166  vpermilpd xmm14, xmm14, 0x00
00007b2719bda16c  vmovaps xmm13, [rsp+0x50]
00007b2719bda172  vmovaps xmm6, [rsp+0xC0]
00007b2719bda17b  vmovaps [rsp+0x50], xmm1
00007b2719bda181  movaps xmm3, xmm13
00007b2719bda185  vfmadd231pd xmm3, xmm6, xmm14
00007b2719bda18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007b2719bda18f  vptest xmm1, xmm1
00007b2719bda194  jnz 0x00007B2719BDB361
00007b2719bda19a  vmovaps xmm1, [rsp+0xA0]
00007b2719bda1a3  vpermilpd xmm1, xmm1, 0x00
00007b2719bda1a9  vmovaps xmm14, [rsp+0x30]
00007b2719bda1af  movaps xmm6, xmm2
00007b2719bda1b2  vfmadd231pd xmm6, xmm14, xmm1
00007b2719bda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007b2719bda1bc  vptest xmm13, xmm13
00007b2719bda1c1  jnz 0x00007B2719BDB4B8
00007b2719bda1c7  vmovaps xmm1, [rsp+0xA0]
00007b2719bda1d0  vpermilpd xmm1, xmm1, 0x00
00007b2719bda1d6  vmovaps xmm14, [rsp+0x80]
00007b2719bda1df  movaps xmm13, xmm12
00007b2719bda1e3  vfmadd231pd xmm13, xmm14, xmm1
00007b2719bda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007b2719bda1ee  vptest xmm2, xmm2
00007b2719bda1f3  jnz 0x00007B2719BDB60E
00007b2719bda1f9  vmovaps [rsp+0x30], xmm7
00007b2719bda1ff  vmovaps xmm1, [rsp+0x30]
00007b2719bda205  por xmm7, xmm1
00007b2719bda209  movaps [r15+0x180], xmm7
00007b2719bda211  vmovaps [rsp+0x30], xmm10
00007b2719bda217  vmovaps xmm1, [rsp+0x30]
00007b2719bda21d  por xmm10, xmm1
00007b2719bda222  movaps [r15+0x2D0], xmm10
00007b2719bda22a  vmovaps [rsp+0x30], xmm5
00007b2719bda230  vpermilpd xmm5, xmm5, 0x00
00007b2719bda236  vmovaps xmm14, [rsp+0x50]
00007b2719bda23c  movaps xmm12, xmm3
00007b2719bda240  vfmadd231pd xmm12, xmm14, xmm5
00007b2719bda245  vcmppd xmm10, xmm12, xmm12, 0x03
00007b2719bda24b  vptest xmm10, xmm10
00007b2719bda250  jnz 0x00007B2719BDB767
00007b2719bda256  vmovaps xmm14, [rsp+0x30]
00007b2719bda25c  vpermilpd xmm14, xmm14, 0x00
00007b2719bda262  movaps xmm10, xmm9
00007b2719bda266  vfmadd231pd xmm10, xmm7, xmm14
00007b2719bda26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007b2719bda271  vptest xmm5, xmm5
00007b2719bda276  jnz 0x00007B2719BDB8BF
00007b2719bda27c  lea rax, [r14+0x80]
00007b2719bda283  movups xmm14, [r13+rax*1]
00007b2719bda289  movaps [r15+0x2F0], xmm14
00007b2719bda291  vmovaps xmm9, [rsp+0x30]
00007b2719bda297  vpermilpd xmm9, xmm9, 0x00
00007b2719bda29d  vmovaps xmm7, [rsp+0x70]
00007b2719bda2a3  movaps xmm5, xmm6
00007b2719bda2a6  vfmadd231pd xmm5, xmm7, xmm9
00007b2719bda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007b2719bda2b0  vptest xmm3, xmm3
00007b2719bda2b5  jnz 0x00007B2719BDBA22
00007b2719bda2bb  vmovaps xmm9, [rsp+0x30]
00007b2719bda2c1  vpermilpd xmm9, xmm9, 0x00
00007b2719bda2c7  movaps xmm7, xmm13
00007b2719bda2cb  vfmadd231pd xmm7, xmm1, xmm9
00007b2719bda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007b2719bda2d5  vptest xmm6, xmm6
00007b2719bda2da  jnz 0x00007B2719BDBB78
00007b2719bda2e0  vmovaps xmm1, [rsp+0x20]
00007b2719bda2e6  vmovaps xmm13, [rsp+0x20]
00007b2719bda2ec  por xmm1, xmm13
00007b2719bda2f1  movaps [r15+0x160], xmm1
00007b2719bda2f9  lea rax, [r14+0x40]
00007b2719bda2fd  movups xmm13, [r13+rax*1]
00007b2719bda303  lea rax, [r14+0x50]
00007b2719bda307  movups xmm9, [r13+rax*1]
00007b2719bda30d  movaps [r15+0x1B0], xmm13
00007b2719bda315  movaps [r15+0x1A0], xmm9
00007b2719bda31d  movaps xmm6, [r15+0x190]
00007b2719bda325  vmovaps xmm3, [rsp+0xB0]
00007b2719bda32e  vpermilpd xmm3, xmm3, 0x00
00007b2719bda334  vmovaps [rsp+0x20], xmm1
00007b2719bda33a  movaps xmm2, xmm12
00007b2719bda33e  vfmadd231pd xmm2, xmm6, xmm3
00007b2719bda343  vcmppd xmm1, xmm2, xmm2, 0x03
00007b2719bda348  vptest xmm1, xmm1
00007b2719bda34d  jnz 0x00007B2719BDBCE3
00007b2719bda353  vmovaps xmm1, [rsp+0xB0]
00007b2719bda35c  vpermilpd xmm1, xmm1, 0x00
00007b2719bda362  vmovaps xmm12, [rsp+0x20]
00007b2719bda368  movaps xmm6, xmm10
00007b2719bda36c  vfmadd231pd xmm6, xmm12, xmm1
00007b2719bda371  vcmppd xmm3, xmm6, xmm6, 0x03
00007b2719bda376  vptest xmm3, xmm3
00007b2719bda37b  jnz 0x00007B2719BDBE39
00007b2719bda381  vmovaps xmm1, [rsp+0xB0]
00007b2719bda38a  vpermilpd xmm1, xmm1, 0x00
00007b2719bda390  vmovaps xmm12, [rsp+0x40]
00007b2719bda396  movaps xmm10, xmm5
00007b2719bda39a  vfmadd231pd xmm10, xmm12, xmm1
00007b2719bda39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007b2719bda3a5  vptest xmm3, xmm3
00007b2719bda3aa  jnz 0x00007B2719BDBF90
00007b2719bda3b0  vmovaps xmm1, [rsp+0xB0]
00007b2719bda3b9  vpermilpd xmm1, xmm1, 0x00
00007b2719bda3bf  movaps xmm12, xmm7
00007b2719bda3c3  vfmadd231pd xmm12, xmm15, xmm1
00007b2719bda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007b2719bda3ce  vptest xmm5, xmm5
00007b2719bda3d3  jnz 0x00007B2719BDC0E8
00007b2719bda3d9  lea rax, [r14+0x60]
00007b2719bda3dd  movups xmm1, [r13+rax*1]
00007b2719bda3e3  lea rax, [r14+0x70]
00007b2719bda3e7  movups xmm15, [r13+rax*1]
00007b2719bda3ed  movaps [r15+0x150], xmm1
00007b2719bda3f5  movaps [r15+0x120], xmm15
00007b2719bda3fd  vmovaps [rsp+0x20], xmm11
00007b2719bda403  vpermilpd xmm11, xmm11, 0x00
00007b2719bda409  movaps xmm7, xmm2
00007b2719bda40c  vfmadd231pd xmm7, xmm9, xmm11
00007b2719bda411  vcmppd xmm5, xmm7, xmm7, 0x03
00007b2719bda416  vptest xmm5, xmm5
00007b2719bda41b  jnz 0x00007B2719BDC254
00007b2719bda421  vmovaps xmm11, [rsp+0x20]
00007b2719bda427  vpermilpd xmm11, xmm11, 0x00
00007b2719bda42d  movaps xmm9, xmm6
00007b2719bda431  vfmadd231pd xmm9, xmm1, xmm11
00007b2719bda436  vcmppd xmm5, xmm9, xmm9, 0x03
00007b2719bda43c  vptest xmm5, xmm5
00007b2719bda441  jnz 0x00007B2719BDC3AB
00007b2719bda447  vmovaps xmm1, [rsp+0x20]
00007b2719bda44d  vpermilpd xmm1, xmm1, 0x00
00007b2719bda453  movaps xmm11, xmm10
00007b2719bda457  vfmadd231pd xmm11, xmm8, xmm1
00007b2719bda45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007b2719bda462  vptest xmm6, xmm6
00007b2719bda467  jnz 0x00007B2719BDC503
00007b2719bda46d  vmovaps xmm1, [rsp+0x20]
00007b2719bda473  vpermilpd xmm1, xmm1, 0x00
00007b2719bda479  movaps xmm10, xmm12
00007b2719bda47d  vfmadd231pd xmm10, xmm13, xmm1
00007b2719bda482  vcmppd xmm8, xmm10, xmm10, 0x03
00007b2719bda488  vptest xmm8, xmm8
00007b2719bda48d  jnz 0x00007B2719BDC65C
00007b2719bda493  lea rax, [r14+0x20]
00007b2719bda497  movups xmm1, [r13+rax*1]
00007b2719bda49d  lea rax, [r14+0x30]
00007b2719bda4a1  movups xmm13, [r13+rax*1]
00007b2719bda4a7  vmovaps xmm12, [rsp+0x90]
00007b2719bda4b0  vpermilpd xmm12, xmm12, 0x00
00007b2719bda4b6  movaps xmm8, xmm7
00007b2719bda4ba  vfmadd231pd xmm8, xmm4, xmm12
00007b2719bda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007b2719bda4c5  vptest xmm6, xmm6
00007b2719bda4ca  jnz 0x00007B2719BDC7C9
00007b2719bda4d0  vmovaps xmm12, [rsp+0x90]
00007b2719bda4d9  vpermilpd xmm12, xmm12, 0x00
00007b2719bda4df  movaps xmm7, xmm9
00007b2719bda4e3  vfmadd231pd xmm7, xmm14, xmm12
00007b2719bda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007b2719bda4ed  vptest xmm6, xmm6
00007b2719bda4f2  jnz 0x00007B2719BDC921
00007b2719bda4f8  vmovaps xmm14, [rsp+0x90]
00007b2719bda501  vpermilpd xmm14, xmm14, 0x00
00007b2719bda507  movaps xmm12, xmm11
00007b2719bda50b  vfmadd231pd xmm12, xmm15, xmm14
00007b2719bda510  vcmppd xmm9, xmm12, xmm12, 0x03
00007b2719bda516  vptest xmm9, xmm9
00007b2719bda51b  jnz 0x00007B2719BDCA79
00007b2719bda521  vmovaps xmm15, [rsp+0x90]
00007b2719bda52a  vpermilpd xmm15, xmm15, 0x00
00007b2719bda530  movaps xmm11, xmm10
00007b2719bda534  vfmadd231pd xmm11, xmm13, xmm15
00007b2719bda539  vcmppd xmm14, xmm11, xmm11, 0x03
00007b2719bda53f  vptest xmm14, xmm14
00007b2719bda544  jnz 0x00007B2719BDCBD3
00007b2719bda54a  lea rax, [r14+0x90]
00007b2719bda551  movups xmm15, [r13+rax*1]
00007b2719bda557  lea rax, [r14+0xA0]
00007b2719bda55e  movups xmm14, [r13+rax*1]
00007b2719bda564  movaps [r15+0x140], xmm15
00007b2719bda56c  movaps [r15+0x130], xmm14
00007b2719bda574  vmovaps xmm13, [rsp+0x10]
00007b2719bda57a  vpermilpd xmm13, xmm13, 0x00
00007b2719bda580  movaps xmm10, xmm8
00007b2719bda584  vfmadd231pd xmm10, xmm1, xmm13
00007b2719bda589  vcmppd xmm9, xmm10, xmm10, 0x03
00007b2719bda58f  vptest xmm9, xmm9
00007b2719bda594  jnz 0x00007B2719BDCD41
00007b2719bda59a  movaps [r15+0x220], xmm10
00007b2719bda5a2  lea rax, [r14+0x10]
00007b2719bda5a6  movups xmm1, [r13+rax*1]
00007b2719bda5ac  movaps [r15+0x240], xmm1
00007b2719bda5b4  vmovaps xmm13, [rsp+0x10]
00007b2719bda5ba  vpermilpd xmm13, xmm13, 0x00
00007b2719bda5c0  movaps xmm9, xmm7
00007b2719bda5c4  vfmadd231pd xmm9, xmm14, xmm13
00007b2719bda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007b2719bda5cf  vptest xmm8, xmm8
00007b2719bda5d4  jnz 0x00007B2719BDCEA4
00007b2719bda5da  movaps [r15+0x110], xmm9
00007b2719bda5e2  vmovaps xmm14, [rsp+0x10]
00007b2719bda5e8  vpermilpd xmm14, xmm14, 0x00
00007b2719bda5ee  movaps xmm13, xmm12
00007b2719bda5f2  vfmadd231pd xmm13, xmm15, xmm14
00007b2719bda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007b2719bda5fd  vptest xmm8, xmm8
00007b2719bda602  jnz 0x00007B2719BDCFFD
00007b2719bda608  movaps [r15+0x170], xmm13
00007b2719bda610  vmovaps xmm15, [rsp+0x10]
00007b2719bda616  vpermilpd xmm15, xmm15, 0x00
00007b2719bda61c  movaps xmm14, xmm11
00007b2719bda620  vfmadd231pd xmm14, xmm1, xmm15
00007b2719bda625  vcmppd xmm12, xmm14, xmm14, 0x03
00007b2719bda62b  vptest xmm12, xmm12
00007b2719bda630  jnz 0x00007B2719BDD157
00007b2719bda636  movaps [r15+0x230], xmm14
00007b2719bda63e  mov rax, [rsp+0xD0]
00007b2719bda646  movups [r13+rax*1], xmm9
00007b2719bda64c  lea r14, [rax+0x10]
00007b2719bda650  movups [r13+r14*1], xmm13
00007b2719bda656  lea r14, [rax+0x20]
00007b2719bda65a  movups [r13+r14*1], xmm10
00007b2719bda660  lea r14, [rax+0x30]
00007b2719bda664  movups [r13+r14*1], xmm14
00007b2719bda66a  mov eax, [r15+0x108]
00007b2719bda671  sahf
00007b2719bda672  jnz 0x00007B2719BDA6A4
00007b2719bda674  cmp dword ptr [r15+0x318], 0x00
00007b2719bda67c  jz 0x00007B2719BD9950
00007b2719bda682  nop [rax+rax*1], ax
00007b2719bda68b  nop [rax+rax*1], eax
00007b2719bda693  mov eax, 0x410664
00007b2719bda698  mov [r15+0x100], rax
00007b2719bda69f  jmp 0x00007B27199FE110
00007b2719bda6a4  cmp dword ptr [r15+0x318], 0x00
00007b2719bda6ac  jz 0x00007B2719BD6050
00007b2719bda6b2  nop [rax+rax*1], ax
00007b2719bda6bb  nop [rax+rax*1], eax
00007b2719bda6c3  mov eax, 0x4104F0
00007b2719bda6c8  mov [r15+0x100], rax
00007b2719bda6cf  jmp 0x00007B27199FE110
00007b2719bda6d4  int3
00007b2719bda6d5  call 0x00007B2719AE27E0
00007b2719bda6da  jmp 0x00007B2719BD9A10
00007b2719bda6df  call 0x00007B2719AE1570
00007b2719bda6e4  jmp 0x00007B2719BD9A19
00007b2719bda6e9  call 0x00007B2719AE27E0
00007b2719bda6ee  jmp 0x00007B2719BD9A62
00007b2719bda6f3  call 0x00007B2719AE1570
00007b2719bda6f8  jmp 0x00007B2719BD9A6B
00007b2719bda6fd  call 0x00007B2719AE27E0
00007b2719bda702  jmp 0x00007B2719BD9AEB
00007b2719bda707  call 0x00007B2719AE1570
00007b2719bda70c  jmp 0x00007B2719BD9AF4
00007b2719bda711  call 0x00007B2719A0DC20
00007b2719bda716  jmp 0x00007B2719BD9BD5
00007b2719bda71b  call 0x00007B2719AD64F0
00007b2719bda720  jmp 0x00007B2719BD9C04
00007b2719bda725  call 0x00007B2719AB47C0
00007b2719bda72a  jmp 0x00007B2719BD9C1F
00007b2719bda72f  sub rsp, 0x08
00007b2719bda733  push rax
00007b2719bda734  push rcx
00007b2719bda735  push rdx
00007b2719bda736  push rdi
00007b2719bda737  push rsi
00007b2719bda738  push r8
00007b2719bda73a  push r9
00007b2719bda73c  push r10
00007b2719bda73e  push r11
00007b2719bda740  sub rsp, 0xF0
00007b2719bda747  vmovaps [rsp], xmm0
00007b2719bda74c  vmovaps [rsp+0x10], xmm1
00007b2719bda752  vmovaps [rsp+0x20], xmm2
00007b2719bda758  vmovaps [rsp+0x30], xmm3
00007b2719bda75e  vmovaps [rsp+0x40], xmm4
00007b2719bda764  vmovaps [rsp+0x50], xmm5
00007b2719bda76a  vmovaps [rsp+0x60], xmm6
00007b2719bda770  vmovaps [rsp+0x70], xmm7
00007b2719bda776  vmovaps [rsp+0x80], xmm8
00007b2719bda77f  vmovaps [rsp+0x90], xmm9
00007b2719bda788  vmovaps [rsp+0xA0], xmm10
00007b2719bda791  vmovaps [rsp+0xB0], xmm11
00007b2719bda79a  vmovaps [rsp+0xC0], xmm12
00007b2719bda7a3  vmovaps [rsp+0xD0], xmm14
00007b2719bda7ac  vmovaps [rsp+0xE0], xmm15
00007b2719bda7b5  sub rsp, 0x40
00007b2719bda7b9  lea rdi, [rsp]
00007b2719bda7bd  lea rsi, [rsp+0x10]
00007b2719bda7c2  lea rdx, [rsp+0x20]
00007b2719bda7c7  lea rcx, [rsp+0x30]
00007b2719bda7cc  mov r8d, 0x00
00007b2719bda7d2  lea r9, [r15+0x3A8]
00007b2719bda7d9  movaps [rdi], xmm13
00007b2719bda7dd  movaps [rsi], xmm1
00007b2719bda7e0  movaps [rdx], xmm15
00007b2719bda7e4  movaps [rcx], xmm14
00007b2719bda7e8  mov rax, 0x5A8E6560CA50
00007b2719bda7f2  call rax
00007b2719bda7f4  movaps xmm13, [rsp]
00007b2719bda7f9  add rsp, 0x40
00007b2719bda7fd  vmovaps xmm0, [rsp]
00007b2719bda802  vmovaps xmm1, [rsp+0x10]
00007b2719bda808  vmovaps xmm2, [rsp+0x20]
00007b2719bda80e  vmovaps xmm3, [rsp+0x30]
00007b2719bda814  vmovaps xmm4, [rsp+0x40]
00007b2719bda81a  vmovaps xmm5, [rsp+0x50]
00007b2719bda820  vmovaps xmm6, [rsp+0x60]
00007b2719bda826  vmovaps xmm7, [rsp+0x70]
00007b2719bda82c  vmovaps xmm8, [rsp+0x80]
00007b2719bda835  vmovaps xmm9, [rsp+0x90]
00007b2719bda83e  vmovaps xmm10, [rsp+0xA0]
00007b2719bda847  vmovaps xmm11, [rsp+0xB0]
00007b2719bda850  vmovaps xmm12, [rsp+0xC0]
00007b2719bda859  vmovaps xmm14, [rsp+0xD0]
00007b2719bda862  vmovaps xmm15, [rsp+0xE0]
00007b2719bda86b  add rsp, 0xF0
00007b2719bda872  pop r11
00007b2719bda874  pop r10
00007b2719bda876  pop r9
00007b2719bda878  pop r8
00007b2719bda87a  pop rsi
00007b2719bda87b  pop rdi
00007b2719bda87c  pop rdx
00007b2719bda87d  pop rcx
00007b2719bda87e  pop rax
00007b2719bda87f  add rsp, 0x08
00007b2719bda883  jmp 0x00007B2719BD9C92
00007b2719bda888  sub rsp, 0x08
00007b2719bda88c  push rax
00007b2719bda88d  push rcx
00007b2719bda88e  push rdx
00007b2719bda88f  push rdi
00007b2719bda890  push rsi
00007b2719bda891  push r8
00007b2719bda893  push r9
00007b2719bda895  push r10
00007b2719bda897  push r11
00007b2719bda899  sub rsp, 0xF0
00007b2719bda8a0  vmovaps [rsp], xmm0
00007b2719bda8a5  vmovaps [rsp+0x10], xmm1
00007b2719bda8ab  vmovaps [rsp+0x20], xmm2
00007b2719bda8b1  vmovaps [rsp+0x30], xmm3
00007b2719bda8b7  vmovaps [rsp+0x40], xmm4
00007b2719bda8bd  vmovaps [rsp+0x50], xmm5
00007b2719bda8c3  vmovaps [rsp+0x60], xmm6
00007b2719bda8c9  vmovaps [rsp+0x70], xmm7
00007b2719bda8cf  vmovaps [rsp+0x80], xmm8
00007b2719bda8d8  vmovaps [rsp+0x90], xmm9
00007b2719bda8e1  vmovaps [rsp+0xA0], xmm10
00007b2719bda8ea  vmovaps [rsp+0xB0], xmm11
00007b2719bda8f3  vmovaps [rsp+0xC0], xmm13
00007b2719bda8fc  vmovaps [rsp+0xD0], xmm14
00007b2719bda905  vmovaps [rsp+0xE0], xmm15
00007b2719bda90e  sub rsp, 0x40
00007b2719bda912  lea rdi, [rsp]
00007b2719bda916  lea rsi, [rsp+0x10]
00007b2719bda91b  lea rdx, [rsp+0x20]
00007b2719bda920  lea rcx, [rsp+0x30]
00007b2719bda925  mov r8d, 0x00
00007b2719bda92b  lea r9, [r15+0x3A8]
00007b2719bda932  movaps [rdi], xmm12
00007b2719bda936  movaps [rsi], xmm15
00007b2719bda93a  movaps [rdx], xmm1
00007b2719bda93d  movaps [rcx], xmm14
00007b2719bda941  mov rax, 0x5A8E6560CA50
00007b2719bda94b  call rax
00007b2719bda94d  movaps xmm12, [rsp]
00007b2719bda952  add rsp, 0x40
00007b2719bda956  vmovaps xmm0, [rsp]
00007b2719bda95b  vmovaps xmm1, [rsp+0x10]
00007b2719bda961  vmovaps xmm2, [rsp+0x20]
00007b2719bda967  vmovaps xmm3, [rsp+0x30]
00007b2719bda96d  vmovaps xmm4, [rsp+0x40]
00007b2719bda973  vmovaps xmm5, [rsp+0x50]
00007b2719bda979  vmovaps xmm6, [rsp+0x60]
00007b2719bda97f  vmovaps xmm7, [rsp+0x70]
00007b2719bda985  vmovaps xmm8, [rsp+0x80]
00007b2719bda98e  vmovaps xmm9, [rsp+0x90]
00007b2719bda997  vmovaps xmm10, [rsp+0xA0]
00007b2719bda9a0  vmovaps xmm11, [rsp+0xB0]
00007b2719bda9a9  vmovaps xmm13, [rsp+0xC0]
00007b2719bda9b2  vmovaps xmm14, [rsp+0xD0]
00007b2719bda9bb  vmovaps xmm15, [rsp+0xE0]
00007b2719bda9c4  add rsp, 0xF0
00007b2719bda9cb  pop r11
00007b2719bda9cd  pop r10
00007b2719bda9cf  pop r9
00007b2719bda9d1  pop r8
00007b2719bda9d3  pop rsi
00007b2719bda9d4  pop rdi
00007b2719bda9d5  pop rdx
00007b2719bda9d6  pop rcx
00007b2719bda9d7  pop rax
00007b2719bda9d8  add rsp, 0x08
00007b2719bda9dc  jmp 0x00007B2719BD9CC0
00007b2719bda9e1  call 0x00007B2719AB52F0
00007b2719bda9e6  jmp 0x00007B2719BD9DAC
00007b2719bda9eb  sub rsp, 0x08
00007b2719bda9ef  push rax
00007b2719bda9f0  push rcx
00007b2719bda9f1  push rdx
00007b2719bda9f2  push rdi
00007b2719bda9f3  push rsi
00007b2719bda9f4  push r8
00007b2719bda9f6  push r9
00007b2719bda9f8  push r10
00007b2719bda9fa  push r11
00007b2719bda9fc  sub rsp, 0xF0
00007b2719bdaa03  vmovaps [rsp], xmm0
00007b2719bdaa08  vmovaps [rsp+0x10], xmm1
00007b2719bdaa0e  vmovaps [rsp+0x20], xmm2
00007b2719bdaa14  vmovaps [rsp+0x30], xmm3
00007b2719bdaa1a  vmovaps [rsp+0x40], xmm4
00007b2719bdaa20  vmovaps [rsp+0x50], xmm5
00007b2719bdaa26  vmovaps [rsp+0x60], xmm6
00007b2719bdaa2c  vmovaps [rsp+0x70], xmm7
00007b2719bdaa32  vmovaps [rsp+0x80], xmm8
00007b2719bdaa3b  vmovaps [rsp+0x90], xmm9
00007b2719bdaa44  vmovaps [rsp+0xA0], xmm10
00007b2719bdaa4d  vmovaps [rsp+0xB0], xmm11
00007b2719bdaa56  vmovaps [rsp+0xC0], xmm12
00007b2719bdaa5f  vmovaps [rsp+0xD0], xmm14
00007b2719bdaa68  vmovaps [rsp+0xE0], xmm15
00007b2719bdaa71  sub rsp, 0x40
00007b2719bdaa75  lea rdi, [rsp]
00007b2719bdaa79  lea rsi, [rsp+0x10]
00007b2719bdaa7e  lea rdx, [rsp+0x20]
00007b2719bdaa83  lea rcx, [rsp+0x30]
00007b2719bdaa88  mov r8d, 0x00
00007b2719bdaa8e  lea r9, [r15+0x3A8]
00007b2719bdaa95  movaps [rdi], xmm13
00007b2719bdaa99  movaps [rsi], xmm1
00007b2719bdaa9c  movaps [rdx], xmm15
00007b2719bdaaa0  movaps [rcx], xmm14
00007b2719bdaaa4  mov rax, 0x5A8E6560CA50
00007b2719bdaaae  call rax
00007b2719bdaab0  movaps xmm13, [rsp]
00007b2719bdaab5  add rsp, 0x40
00007b2719bdaab9  vmovaps xmm0, [rsp]
00007b2719bdaabe  vmovaps xmm1, [rsp+0x10]
00007b2719bdaac4  vmovaps xmm2, [rsp+0x20]
00007b2719bdaaca  vmovaps xmm3, [rsp+0x30]
00007b2719bdaad0  vmovaps xmm4, [rsp+0x40]
00007b2719bdaad6  vmovaps xmm5, [rsp+0x50]
00007b2719bdaadc  vmovaps xmm6, [rsp+0x60]
00007b2719bdaae2  vmovaps xmm7, [rsp+0x70]
00007b2719bdaae8  vmovaps xmm8, [rsp+0x80]
00007b2719bdaaf1  vmovaps xmm9, [rsp+0x90]
00007b2719bdaafa  vmovaps xmm10, [rsp+0xA0]
00007b2719bdab03  vmovaps xmm11, [rsp+0xB0]
00007b2719bdab0c  vmovaps xmm12, [rsp+0xC0]
00007b2719bdab15  vmovaps xmm14, [rsp+0xD0]
00007b2719bdab1e  vmovaps xmm15, [rsp+0xE0]
00007b2719bdab27  add rsp, 0xF0
00007b2719bdab2e  pop r11
00007b2719bdab30  pop r10
00007b2719bdab32  pop r9
00007b2719bdab34  pop r8
00007b2719bdab36  pop rsi
00007b2719bdab37  pop rdi
00007b2719bdab38  pop rdx
00007b2719bdab39  pop rcx
00007b2719bdab3a  pop rax
00007b2719bdab3b  add rsp, 0x08
00007b2719bdab3f  jmp 0x00007B2719BD9E21
00007b2719bdab44  call 0x00007B27199FF430
00007b2719bdab49  jmp 0x00007B2719BD9E2E
00007b2719bdab4e  sub rsp, 0x08
00007b2719bdab52  push rax
00007b2719bdab53  push rcx
00007b2719bdab54  push rdx
00007b2719bdab55  push rdi
00007b2719bdab56  push rsi
00007b2719bdab57  push r8
00007b2719bdab59  push r9
00007b2719bdab5b  push r10
00007b2719bdab5d  push r11
00007b2719bdab5f  sub rsp, 0xF0
00007b2719bdab66  vmovaps [rsp], xmm0
00007b2719bdab6b  vmovaps [rsp+0x10], xmm1
00007b2719bdab71  vmovaps [rsp+0x20], xmm2
00007b2719bdab77  vmovaps [rsp+0x30], xmm3
00007b2719bdab7d  vmovaps [rsp+0x40], xmm4
00007b2719bdab83  vmovaps [rsp+0x50], xmm5
00007b2719bdab89  vmovaps [rsp+0x60], xmm6
00007b2719bdab8f  vmovaps [rsp+0x70], xmm7
00007b2719bdab95  vmovaps [rsp+0x80], xmm8
00007b2719bdab9e  vmovaps [rsp+0x90], xmm9
00007b2719bdaba7  vmovaps [rsp+0xA0], xmm10
00007b2719bdabb0  vmovaps [rsp+0xB0], xmm11
00007b2719bdabb9  vmovaps [rsp+0xC0], xmm13
00007b2719bdabc2  vmovaps [rsp+0xD0], xmm14
00007b2719bdabcb  vmovaps [rsp+0xE0], xmm15
00007b2719bdabd4  sub rsp, 0x40
00007b2719bdabd8  lea rdi, [rsp]
00007b2719bdabdc  lea rsi, [rsp+0x10]
00007b2719bdabe1  lea rdx, [rsp+0x20]
00007b2719bdabe6  lea rcx, [rsp+0x30]
00007b2719bdabeb  mov r8d, 0x00
00007b2719bdabf1  lea r9, [r15+0x3A8]
00007b2719bdabf8  movaps [rdi], xmm12
00007b2719bdabfc  movaps [rsi], xmm15
00007b2719bdac00  movaps [rdx], xmm1
00007b2719bdac03  movaps [rcx], xmm14
00007b2719bdac07  mov rax, 0x5A8E6560CA50
00007b2719bdac11  call rax
00007b2719bdac13  movaps xmm12, [rsp]
00007b2719bdac18  add rsp, 0x40
00007b2719bdac1c  vmovaps xmm0, [rsp]
00007b2719bdac21  vmovaps xmm1, [rsp+0x10]
00007b2719bdac27  vmovaps xmm2, [rsp+0x20]
00007b2719bdac2d  vmovaps xmm3, [rsp+0x30]
00007b2719bdac33  vmovaps xmm4, [rsp+0x40]
00007b2719bdac39  vmovaps xmm5, [rsp+0x50]
00007b2719bdac3f  vmovaps xmm6, [rsp+0x60]
00007b2719bdac45  vmovaps xmm7, [rsp+0x70]
00007b2719bdac4b  vmovaps xmm8, [rsp+0x80]
00007b2719bdac54  vmovaps xmm9, [rsp+0x90]
00007b2719bdac5d  vmovaps xmm10, [rsp+0xA0]
00007b2719bdac66  vmovaps xmm11, [rsp+0xB0]
00007b2719bdac6f  vmovaps xmm13, [rsp+0xC0]
00007b2719bdac78  vmovaps xmm14, [rsp+0xD0]
00007b2719bdac81  vmovaps xmm15, [rsp+0xE0]
00007b2719bdac8a  add rsp, 0xF0
00007b2719bdac91  pop r11
00007b2719bdac93  pop r10
00007b2719bdac95  pop r9
00007b2719bdac97  pop r8
00007b2719bdac99  pop rsi
00007b2719bdac9a  pop rdi
00007b2719bdac9b  pop rdx
00007b2719bdac9c  pop rcx
00007b2719bdac9d  pop rax
00007b2719bdac9e  add rsp, 0x08
00007b2719bdaca2  jmp 0x00007B2719BD9E5A
00007b2719bdaca7  sub rsp, 0x08
00007b2719bdacab  push rax
00007b2719bdacac  push rcx
00007b2719bdacad  push rdx
00007b2719bdacae  push rdi
00007b2719bdacaf  push rsi
00007b2719bdacb0  push r8
00007b2719bdacb2  push r9
00007b2719bdacb4  push r10
00007b2719bdacb6  push r11
00007b2719bdacb8  sub rsp, 0xF0
00007b2719bdacbf  vmovaps [rsp], xmm0
00007b2719bdacc4  vmovaps [rsp+0x10], xmm1
00007b2719bdacca  vmovaps [rsp+0x20], xmm2
00007b2719bdacd0  vmovaps [rsp+0x30], xmm3
00007b2719bdacd6  vmovaps [rsp+0x40], xmm4
00007b2719bdacdc  vmovaps [rsp+0x50], xmm5
00007b2719bdace2  vmovaps [rsp+0x60], xmm6
00007b2719bdace8  vmovaps [rsp+0x70], xmm7
00007b2719bdacee  vmovaps [rsp+0x80], xmm8
00007b2719bdacf7  vmovaps [rsp+0x90], xmm9
00007b2719bdad00  vmovaps [rsp+0xA0], xmm10
00007b2719bdad09  vmovaps [rsp+0xB0], xmm11
00007b2719bdad12  vmovaps [rsp+0xC0], xmm12
00007b2719bdad1b  vmovaps [rsp+0xD0], xmm14
00007b2719bdad24  vmovaps [rsp+0xE0], xmm15
00007b2719bdad2d  sub rsp, 0x40
00007b2719bdad31  lea rdi, [rsp]
00007b2719bdad35  lea rsi, [rsp+0x10]
00007b2719bdad3a  lea rdx, [rsp+0x20]
00007b2719bdad3f  lea rcx, [rsp+0x30]
00007b2719bdad44  mov r8d, 0x00
00007b2719bdad4a  lea r9, [r15+0x3A8]
00007b2719bdad51  movaps [rdi], xmm13
00007b2719bdad55  movaps [rsi], xmm1
00007b2719bdad58  movaps [rdx], xmm15
00007b2719bdad5c  movaps [rcx], xmm14
00007b2719bdad60  mov rax, 0x5A8E6560CA50
00007b2719bdad6a  call rax
00007b2719bdad6c  movaps xmm13, [rsp]
00007b2719bdad71  add rsp, 0x40
00007b2719bdad75  vmovaps xmm0, [rsp]
00007b2719bdad7a  vmovaps xmm1, [rsp+0x10]
00007b2719bdad80  vmovaps xmm2, [rsp+0x20]
00007b2719bdad86  vmovaps xmm3, [rsp+0x30]
00007b2719bdad8c  vmovaps xmm4, [rsp+0x40]
00007b2719bdad92  vmovaps xmm5, [rsp+0x50]
00007b2719bdad98  vmovaps xmm6, [rsp+0x60]
00007b2719bdad9e  vmovaps xmm7, [rsp+0x70]
00007b2719bdada4  vmovaps xmm8, [rsp+0x80]
00007b2719bdadad  vmovaps xmm9, [rsp+0x90]
00007b2719bdadb6  vmovaps xmm10, [rsp+0xA0]
00007b2719bdadbf  vmovaps xmm11, [rsp+0xB0]
00007b2719bdadc8  vmovaps xmm12, [rsp+0xC0]
00007b2719bdadd1  vmovaps xmm14, [rsp+0xD0]
00007b2719bdadda  vmovaps xmm15, [rsp+0xE0]
00007b2719bdade3  add rsp, 0xF0
00007b2719bdadea  pop r11
00007b2719bdadec  pop r10
00007b2719bdadee  pop r9
00007b2719bdadf0  pop r8
00007b2719bdadf2  pop rsi
00007b2719bdadf3  pop rdi
00007b2719bdadf4  pop rdx
00007b2719bdadf5  pop rcx
00007b2719bdadf6  pop rax
00007b2719bdadf7  add rsp, 0x08
00007b2719bdadfb  jmp 0x00007B2719BD9FEA
00007b2719bdae00  sub rsp, 0x08
00007b2719bdae04  push rax
00007b2719bdae05  push rcx
00007b2719bdae06  push rdx
00007b2719bdae07  push rdi
00007b2719bdae08  push rsi
00007b2719bdae09  push r8
00007b2719bdae0b  push r9
00007b2719bdae0d  push r10
00007b2719bdae0f  push r11
00007b2719bdae11  sub rsp, 0xF0
00007b2719bdae18  vmovaps [rsp], xmm0
00007b2719bdae1d  vmovaps [rsp+0x10], xmm1
00007b2719bdae23  vmovaps [rsp+0x20], xmm2
00007b2719bdae29  vmovaps [rsp+0x30], xmm3
00007b2719bdae2f  vmovaps [rsp+0x40], xmm4
00007b2719bdae35  vmovaps [rsp+0x50], xmm5
00007b2719bdae3b  vmovaps [rsp+0x60], xmm6
00007b2719bdae41  vmovaps [rsp+0x70], xmm7
00007b2719bdae47  vmovaps [rsp+0x80], xmm8
00007b2719bdae50  vmovaps [rsp+0x90], xmm9
00007b2719bdae59  vmovaps [rsp+0xA0], xmm10
00007b2719bdae62  vmovaps [rsp+0xB0], xmm11
00007b2719bdae6b  vmovaps [rsp+0xC0], xmm12
00007b2719bdae74  vmovaps [rsp+0xD0], xmm13
00007b2719bdae7d  vmovaps [rsp+0xE0], xmm15
00007b2719bdae86  sub rsp, 0x40
00007b2719bdae8a  lea rdi, [rsp]
00007b2719bdae8e  lea rsi, [rsp+0x10]
00007b2719bdae93  lea rdx, [rsp+0x20]
00007b2719bdae98  lea rcx, [rsp+0x30]
00007b2719bdae9d  mov r8d, 0x00
00007b2719bdaea3  lea r9, [r15+0x3A8]
00007b2719bdaeaa  movaps [rdi], xmm14
00007b2719bdaeae  movaps [rsi], xmm15
00007b2719bdaeb2  movaps [rdx], xmm2
00007b2719bdaeb5  movaps [rcx], xmm1
00007b2719bdaeb8  mov rax, 0x5A8E6560CA50
00007b2719bdaec2  call rax
00007b2719bdaec4  movaps xmm14, [rsp]
00007b2719bdaec9  add rsp, 0x40
00007b2719bdaecd  vmovaps xmm0, [rsp]
00007b2719bdaed2  vmovaps xmm1, [rsp+0x10]
00007b2719bdaed8  vmovaps xmm2, [rsp+0x20]
00007b2719bdaede  vmovaps xmm3, [rsp+0x30]
00007b2719bdaee4  vmovaps xmm4, [rsp+0x40]
00007b2719bdaeea  vmovaps xmm5, [rsp+0x50]
00007b2719bdaef0  vmovaps xmm6, [rsp+0x60]
00007b2719bdaef6  vmovaps xmm7, [rsp+0x70]
00007b2719bdaefc  vmovaps xmm8, [rsp+0x80]
00007b2719bdaf05  vmovaps xmm9, [rsp+0x90]
00007b2719bdaf0e  vmovaps xmm10, [rsp+0xA0]
00007b2719bdaf17  vmovaps xmm11, [rsp+0xB0]
00007b2719bdaf20  vmovaps xmm12, [rsp+0xC0]
00007b2719bdaf29  vmovaps xmm13, [rsp+0xD0]
00007b2719bdaf32  vmovaps xmm15, [rsp+0xE0]
00007b2719bdaf3b  add rsp, 0xF0
00007b2719bdaf42  pop r11
00007b2719bdaf44  pop r10
00007b2719bdaf46  pop r9
00007b2719bdaf48  pop r8
00007b2719bdaf4a  pop rsi
00007b2719bdaf4b  pop rdi
00007b2719bdaf4c  pop rdx
00007b2719bdaf4d  pop rcx
00007b2719bdaf4e  pop rax
00007b2719bdaf4f  add rsp, 0x08
00007b2719bdaf53  jmp 0x00007B2719BDA01C
00007b2719bdaf58  sub rsp, 0x08
00007b2719bdaf5c  push rax
00007b2719bdaf5d  push rcx
00007b2719bdaf5e  push rdx
00007b2719bdaf5f  push rdi
00007b2719bdaf60  push rsi
00007b2719bdaf61  push r8
00007b2719bdaf63  push r9
00007b2719bdaf65  push r10
00007b2719bdaf67  push r11
00007b2719bdaf69  sub rsp, 0xF0
00007b2719bdaf70  vmovaps [rsp], xmm0
00007b2719bdaf75  vmovaps [rsp+0x10], xmm1
00007b2719bdaf7b  vmovaps [rsp+0x20], xmm3
00007b2719bdaf81  vmovaps [rsp+0x30], xmm4
00007b2719bdaf87  vmovaps [rsp+0x40], xmm5
00007b2719bdaf8d  vmovaps [rsp+0x50], xmm6
00007b2719bdaf93  vmovaps [rsp+0x60], xmm7
00007b2719bdaf99  vmovaps [rsp+0x70], xmm8
00007b2719bdaf9f  vmovaps [rsp+0x80], xmm9
00007b2719bdafa8  vmovaps [rsp+0x90], xmm10
00007b2719bdafb1  vmovaps [rsp+0xA0], xmm11
00007b2719bdafba  vmovaps [rsp+0xB0], xmm12
00007b2719bdafc3  vmovaps [rsp+0xC0], xmm13
00007b2719bdafcc  vmovaps [rsp+0xD0], xmm14
00007b2719bdafd5  vmovaps [rsp+0xE0], xmm15
00007b2719bdafde  sub rsp, 0x40
00007b2719bdafe2  lea rdi, [rsp]
00007b2719bdafe6  lea rsi, [rsp+0x10]
00007b2719bdafeb  lea rdx, [rsp+0x20]
00007b2719bdaff0  lea rcx, [rsp+0x30]
00007b2719bdaff5  mov r8d, 0x00
00007b2719bdaffb  lea r9, [r15+0x3A8]
00007b2719bdb002  movaps [rdi], xmm2
00007b2719bdb005  movaps [rsi], xmm15
00007b2719bdb009  movaps [rdx], xmm12
00007b2719bdb00d  movaps [rcx], xmm1
00007b2719bdb010  mov rax, 0x5A8E6560CA50
00007b2719bdb01a  call rax
00007b2719bdb01c  movaps xmm2, [rsp]
00007b2719bdb020  add rsp, 0x40
00007b2719bdb024  vmovaps xmm0, [rsp]
00007b2719bdb029  vmovaps xmm1, [rsp+0x10]
00007b2719bdb02f  vmovaps xmm3, [rsp+0x20]
00007b2719bdb035  vmovaps xmm4, [rsp+0x30]
00007b2719bdb03b  vmovaps xmm5, [rsp+0x40]
00007b2719bdb041  vmovaps xmm6, [rsp+0x50]
00007b2719bdb047  vmovaps xmm7, [rsp+0x60]
00007b2719bdb04d  vmovaps xmm8, [rsp+0x70]
00007b2719bdb053  vmovaps xmm9, [rsp+0x80]
00007b2719bdb05c  vmovaps xmm10, [rsp+0x90]
00007b2719bdb065  vmovaps xmm11, [rsp+0xA0]
00007b2719bdb06e  vmovaps xmm12, [rsp+0xB0]
00007b2719bdb077  vmovaps xmm13, [rsp+0xC0]
00007b2719bdb080  vmovaps xmm14, [rsp+0xD0]
00007b2719bdb089  vmovaps xmm15, [rsp+0xE0]
00007b2719bdb092  add rsp, 0xF0
00007b2719bdb099  pop r11
00007b2719bdb09b  pop r10
00007b2719bdb09d  pop r9
00007b2719bdb09f  pop r8
00007b2719bdb0a1  pop rsi
00007b2719bdb0a2  pop rdi
00007b2719bdb0a3  pop rdx
00007b2719bdb0a4  pop rcx
00007b2719bdb0a5  pop rax
00007b2719bdb0a6  add rsp, 0x08
00007b2719bdb0aa  jmp 0x00007B2719BDA059
00007b2719bdb0af  sub rsp, 0x08
00007b2719bdb0b3  push rax
00007b2719bdb0b4  push rcx
00007b2719bdb0b5  push rdx
00007b2719bdb0b6  push rdi
00007b2719bdb0b7  push rsi
00007b2719bdb0b8  push r8
00007b2719bdb0ba  push r9
00007b2719bdb0bc  push r10
00007b2719bdb0be  push r11
00007b2719bdb0c0  sub rsp, 0xF0
00007b2719bdb0c7  vmovaps [rsp], xmm0
00007b2719bdb0cc  vmovaps [rsp+0x10], xmm1
00007b2719bdb0d2  vmovaps [rsp+0x20], xmm2
00007b2719bdb0d8  vmovaps [rsp+0x30], xmm3
00007b2719bdb0de  vmovaps [rsp+0x40], xmm4
00007b2719bdb0e4  vmovaps [rsp+0x50], xmm5
00007b2719bdb0ea  vmovaps [rsp+0x60], xmm6
00007b2719bdb0f0  vmovaps [rsp+0x70], xmm7
00007b2719bdb0f6  vmovaps [rsp+0x80], xmm8
00007b2719bdb0ff  vmovaps [rsp+0x90], xmm9
00007b2719bdb108  vmovaps [rsp+0xA0], xmm10
00007b2719bdb111  vmovaps [rsp+0xB0], xmm11
00007b2719bdb11a  vmovaps [rsp+0xC0], xmm13
00007b2719bdb123  vmovaps [rsp+0xD0], xmm14
00007b2719bdb12c  vmovaps [rsp+0xE0], xmm15
00007b2719bdb135  sub rsp, 0x40
00007b2719bdb139  lea rdi, [rsp]
00007b2719bdb13d  lea rsi, [rsp+0x10]
00007b2719bdb142  lea rdx, [rsp+0x20]
00007b2719bdb147  lea rcx, [rsp+0x30]
00007b2719bdb14c  mov r8d, 0x00
00007b2719bdb152  lea r9, [r15+0x3A8]
00007b2719bdb159  movaps [rdi], xmm12
00007b2719bdb15d  movaps [rsi], xmm14
00007b2719bdb161  movaps [rdx], xmm3
00007b2719bdb164  movaps [rcx], xmm15
00007b2719bdb168  mov rax, 0x5A8E6560CA50
00007b2719bdb172  call rax
00007b2719bdb174  movaps xmm12, [rsp]
00007b2719bdb179  add rsp, 0x40
00007b2719bdb17d  vmovaps xmm0, [rsp]
00007b2719bdb182  vmovaps xmm1, [rsp+0x10]
00007b2719bdb188  vmovaps xmm2, [rsp+0x20]
00007b2719bdb18e  vmovaps xmm3, [rsp+0x30]
00007b2719bdb194  vmovaps xmm4, [rsp+0x40]
00007b2719bdb19a  vmovaps xmm5, [rsp+0x50]
00007b2719bdb1a0  vmovaps xmm6, [rsp+0x60]
00007b2719bdb1a6  vmovaps xmm7, [rsp+0x70]
00007b2719bdb1ac  vmovaps xmm8, [rsp+0x80]
00007b2719bdb1b5  vmovaps xmm9, [rsp+0x90]
00007b2719bdb1be  vmovaps xmm10, [rsp+0xA0]
00007b2719bdb1c7  vmovaps xmm11, [rsp+0xB0]
00007b2719bdb1d0  vmovaps xmm13, [rsp+0xC0]
00007b2719bdb1d9  vmovaps xmm14, [rsp+0xD0]
00007b2719bdb1e2  vmovaps xmm15, [rsp+0xE0]
00007b2719bdb1eb  add rsp, 0xF0
00007b2719bdb1f2  pop r11
00007b2719bdb1f4  pop r10
00007b2719bdb1f6  pop r9
00007b2719bdb1f8  pop r8
00007b2719bdb1fa  pop rsi
00007b2719bdb1fb  pop rdi
00007b2719bdb1fc  pop rdx
00007b2719bdb1fd  pop rcx
00007b2719bdb1fe  pop rax
00007b2719bdb1ff  add rsp, 0x08
00007b2719bdb203  jmp 0x00007B2719BDA0B3
00007b2719bdb208  sub rsp, 0x08
00007b2719bdb20c  push rax
00007b2719bdb20d  push rcx
00007b2719bdb20e  push rdx
00007b2719bdb20f  push rdi
00007b2719bdb210  push rsi
00007b2719bdb211  push r8
00007b2719bdb213  push r9
00007b2719bdb215  push r10
00007b2719bdb217  push r11
00007b2719bdb219  sub rsp, 0xF0
00007b2719bdb220  vmovaps [rsp], xmm0
00007b2719bdb225  vmovaps [rsp+0x10], xmm1
00007b2719bdb22b  vmovaps [rsp+0x20], xmm2
00007b2719bdb231  vmovaps [rsp+0x30], xmm3
00007b2719bdb237  vmovaps [rsp+0x40], xmm4
00007b2719bdb23d  vmovaps [rsp+0x50], xmm5
00007b2719bdb243  vmovaps [rsp+0x60], xmm6
00007b2719bdb249  vmovaps [rsp+0x70], xmm7
00007b2719bdb24f  vmovaps [rsp+0x80], xmm8
00007b2719bdb258  vmovaps [rsp+0x90], xmm10
00007b2719bdb261  vmovaps [rsp+0xA0], xmm11
00007b2719bdb26a  vmovaps [rsp+0xB0], xmm12
00007b2719bdb273  vmovaps [rsp+0xC0], xmm13
00007b2719bdb27c  vmovaps [rsp+0xD0], xmm14
00007b2719bdb285  vmovaps [rsp+0xE0], xmm15
00007b2719bdb28e  sub rsp, 0x40
00007b2719bdb292  lea rdi, [rsp]
00007b2719bdb296  lea rsi, [rsp+0x10]
00007b2719bdb29b  lea rdx, [rsp+0x20]
00007b2719bdb2a0  lea rcx, [rsp+0x30]
00007b2719bdb2a5  mov r8d, 0x00
00007b2719bdb2ab  lea r9, [r15+0x3A8]
00007b2719bdb2b2  movaps [rdi], xmm9
00007b2719bdb2b6  movaps [rsi], xmm13
00007b2719bdb2ba  movaps [rdx], xmm14
00007b2719bdb2be  movaps [rcx], xmm6
00007b2719bdb2c1  mov rax, 0x5A8E6560CA50
00007b2719bdb2cb  call rax
00007b2719bdb2cd  movaps xmm9, [rsp]
00007b2719bdb2d2  add rsp, 0x40
00007b2719bdb2d6  vmovaps xmm0, [rsp]
00007b2719bdb2db  vmovaps xmm1, [rsp+0x10]
00007b2719bdb2e1  vmovaps xmm2, [rsp+0x20]
00007b2719bdb2e7  vmovaps xmm3, [rsp+0x30]
00007b2719bdb2ed  vmovaps xmm4, [rsp+0x40]
00007b2719bdb2f3  vmovaps xmm5, [rsp+0x50]
00007b2719bdb2f9  vmovaps xmm6, [rsp+0x60]
00007b2719bdb2ff  vmovaps xmm7, [rsp+0x70]
00007b2719bdb305  vmovaps xmm8, [rsp+0x80]
00007b2719bdb30e  vmovaps xmm10, [rsp+0x90]
00007b2719bdb317  vmovaps xmm11, [rsp+0xA0]
00007b2719bdb320  vmovaps xmm12, [rsp+0xB0]
00007b2719bdb329  vmovaps xmm13, [rsp+0xC0]
00007b2719bdb332  vmovaps xmm14, [rsp+0xD0]
00007b2719bdb33b  vmovaps xmm15, [rsp+0xE0]
00007b2719bdb344  add rsp, 0xF0
00007b2719bdb34b  pop r11
00007b2719bdb34d  pop r10
00007b2719bdb34f  pop r9
00007b2719bdb351  pop r8
00007b2719bdb353  pop rsi
00007b2719bdb354  pop rdi
00007b2719bdb355  pop rdx
00007b2719bdb356  pop rcx
00007b2719bdb357  pop rax
00007b2719bdb358  add rsp, 0x08
00007b2719bdb35c  jmp 0x00007B2719BDA15D
00007b2719bdb361  sub rsp, 0x08
00007b2719bdb365  push rax
00007b2719bdb366  push rcx
00007b2719bdb367  push rdx
00007b2719bdb368  push rdi
00007b2719bdb369  push rsi
00007b2719bdb36a  push r8
00007b2719bdb36c  push r9
00007b2719bdb36e  push r10
00007b2719bdb370  push r11
00007b2719bdb372  sub rsp, 0xF0
00007b2719bdb379  vmovaps [rsp], xmm0
00007b2719bdb37e  vmovaps [rsp+0x10], xmm1
00007b2719bdb384  vmovaps [rsp+0x20], xmm2
00007b2719bdb38a  vmovaps [rsp+0x30], xmm4
00007b2719bdb390  vmovaps [rsp+0x40], xmm5
00007b2719bdb396  vmovaps [rsp+0x50], xmm6
00007b2719bdb39c  vmovaps [rsp+0x60], xmm7
00007b2719bdb3a2  vmovaps [rsp+0x70], xmm8
00007b2719bdb3a8  vmovaps [rsp+0x80], xmm9
00007b2719bdb3b1  vmovaps [rsp+0x90], xmm10
00007b2719bdb3ba  vmovaps [rsp+0xA0], xmm11
00007b2719bdb3c3  vmovaps [rsp+0xB0], xmm12
00007b2719bdb3cc  vmovaps [rsp+0xC0], xmm13
00007b2719bdb3d5  vmovaps [rsp+0xD0], xmm14
00007b2719bdb3de  vmovaps [rsp+0xE0], xmm15
00007b2719bdb3e7  sub rsp, 0x40
00007b2719bdb3eb  lea rdi, [rsp]
00007b2719bdb3ef  lea rsi, [rsp+0x10]
00007b2719bdb3f4  lea rdx, [rsp+0x20]
00007b2719bdb3f9  lea rcx, [rsp+0x30]
00007b2719bdb3fe  mov r8d, 0x00
00007b2719bdb404  lea r9, [r15+0x3A8]
00007b2719bdb40b  movaps [rdi], xmm3
00007b2719bdb40e  movaps [rsi], xmm13
00007b2719bdb412  movaps [rdx], xmm6
00007b2719bdb415  movaps [rcx], xmm14
00007b2719bdb419  mov rax, 0x5A8E6560CA50
00007b2719bdb423  call rax
00007b2719bdb425  movaps xmm3, [rsp]
00007b2719bdb429  add rsp, 0x40
00007b2719bdb42d  vmovaps xmm0, [rsp]
00007b2719bdb432  vmovaps xmm1, [rsp+0x10]
00007b2719bdb438  vmovaps xmm2, [rsp+0x20]
00007b2719bdb43e  vmovaps xmm4, [rsp+0x30]
00007b2719bdb444  vmovaps xmm5, [rsp+0x40]
00007b2719bdb44a  vmovaps xmm6, [rsp+0x50]
00007b2719bdb450  vmovaps xmm7, [rsp+0x60]
00007b2719bdb456  vmovaps xmm8, [rsp+0x70]
00007b2719bdb45c  vmovaps xmm9, [rsp+0x80]
00007b2719bdb465  vmovaps xmm10, [rsp+0x90]
00007b2719bdb46e  vmovaps xmm11, [rsp+0xA0]
00007b2719bdb477  vmovaps xmm12, [rsp+0xB0]
00007b2719bdb480  vmovaps xmm13, [rsp+0xC0]
00007b2719bdb489  vmovaps xmm14, [rsp+0xD0]
00007b2719bdb492  vmovaps xmm15, [rsp+0xE0]
00007b2719bdb49b  add rsp, 0xF0
00007b2719bdb4a2  pop r11
00007b2719bdb4a4  pop r10
00007b2719bdb4a6  pop r9
00007b2719bdb4a8  pop r8
00007b2719bdb4aa  pop rsi
00007b2719bdb4ab  pop rdi
00007b2719bdb4ac  pop rdx
00007b2719bdb4ad  pop rcx
00007b2719bdb4ae  pop rax
00007b2719bdb4af  add rsp, 0x08
00007b2719bdb4b3  jmp 0x00007B2719BDA19A
00007b2719bdb4b8  sub rsp, 0x08
00007b2719bdb4bc  push rax
00007b2719bdb4bd  push rcx
00007b2719bdb4be  push rdx
00007b2719bdb4bf  push rdi
00007b2719bdb4c0  push rsi
00007b2719bdb4c1  push r8
00007b2719bdb4c3  push r9
00007b2719bdb4c5  push r10
00007b2719bdb4c7  push r11
00007b2719bdb4c9  sub rsp, 0xF0
00007b2719bdb4d0  vmovaps [rsp], xmm0
00007b2719bdb4d5  vmovaps [rsp+0x10], xmm1
00007b2719bdb4db  vmovaps [rsp+0x20], xmm2
00007b2719bdb4e1  vmovaps [rsp+0x30], xmm3
00007b2719bdb4e7  vmovaps [rsp+0x40], xmm4
00007b2719bdb4ed  vmovaps [rsp+0x50], xmm5
00007b2719bdb4f3  vmovaps [rsp+0x60], xmm7
00007b2719bdb4f9  vmovaps [rsp+0x70], xmm8
00007b2719bdb4ff  vmovaps [rsp+0x80], xmm9
00007b2719bdb508  vmovaps [rsp+0x90], xmm10
00007b2719bdb511  vmovaps [rsp+0xA0], xmm11
00007b2719bdb51a  vmovaps [rsp+0xB0], xmm12
00007b2719bdb523  vmovaps [rsp+0xC0], xmm13
00007b2719bdb52c  vmovaps [rsp+0xD0], xmm14
00007b2719bdb535  vmovaps [rsp+0xE0], xmm15
00007b2719bdb53e  sub rsp, 0x40
00007b2719bdb542  lea rdi, [rsp]
00007b2719bdb546  lea rsi, [rsp+0x10]
00007b2719bdb54b  lea rdx, [rsp+0x20]
00007b2719bdb550  lea rcx, [rsp+0x30]
00007b2719bdb555  mov r8d, 0x00
00007b2719bdb55b  lea r9, [r15+0x3A8]
00007b2719bdb562  movaps [rdi], xmm6
00007b2719bdb565  movaps [rsi], xmm2
00007b2719bdb568  movaps [rdx], xmm14
00007b2719bdb56c  movaps [rcx], xmm1
00007b2719bdb56f  mov rax, 0x5A8E6560CA50
00007b2719bdb579  call rax
00007b2719bdb57b  movaps xmm6, [rsp]
00007b2719bdb57f  add rsp, 0x40
00007b2719bdb583  vmovaps xmm0, [rsp]
00007b2719bdb588  vmovaps xmm1, [rsp+0x10]
00007b2719bdb58e  vmovaps xmm2, [rsp+0x20]
00007b2719bdb594  vmovaps xmm3, [rsp+0x30]
00007b2719bdb59a  vmovaps xmm4, [rsp+0x40]
00007b2719bdb5a0  vmovaps xmm5, [rsp+0x50]
00007b2719bdb5a6  vmovaps xmm7, [rsp+0x60]
00007b2719bdb5ac  vmovaps xmm8, [rsp+0x70]
00007b2719bdb5b2  vmovaps xmm9, [rsp+0x80]
00007b2719bdb5bb  vmovaps xmm10, [rsp+0x90]
00007b2719bdb5c4  vmovaps xmm11, [rsp+0xA0]
00007b2719bdb5cd  vmovaps xmm12, [rsp+0xB0]
00007b2719bdb5d6  vmovaps xmm13, [rsp+0xC0]
00007b2719bdb5df  vmovaps xmm14, [rsp+0xD0]
00007b2719bdb5e8  vmovaps xmm15, [rsp+0xE0]
00007b2719bdb5f1  add rsp, 0xF0
00007b2719bdb5f8  pop r11
00007b2719bdb5fa  pop r10
00007b2719bdb5fc  pop r9
00007b2719bdb5fe  pop r8
00007b2719bdb600  pop rsi
00007b2719bdb601  pop rdi
00007b2719bdb602  pop rdx
00007b2719bdb603  pop rcx
00007b2719bdb604  pop rax
00007b2719bdb605  add rsp, 0x08
00007b2719bdb609  jmp 0x00007B2719BDA1C7
00007b2719bdb60e  sub rsp, 0x08
00007b2719bdb612  push rax
00007b2719bdb613  push rcx
00007b2719bdb614  push rdx
00007b2719bdb615  push rdi
00007b2719bdb616  push rsi
00007b2719bdb617  push r8
00007b2719bdb619  push r9
00007b2719bdb61b  push r10
00007b2719bdb61d  push r11
00007b2719bdb61f  sub rsp, 0xF0
00007b2719bdb626  vmovaps [rsp], xmm0
00007b2719bdb62b  vmovaps [rsp+0x10], xmm1
00007b2719bdb631  vmovaps [rsp+0x20], xmm2
00007b2719bdb637  vmovaps [rsp+0x30], xmm3
00007b2719bdb63d  vmovaps [rsp+0x40], xmm4
00007b2719bdb643  vmovaps [rsp+0x50], xmm5
00007b2719bdb649  vmovaps [rsp+0x60], xmm6
00007b2719bdb64f  vmovaps [rsp+0x70], xmm7
00007b2719bdb655  vmovaps [rsp+0x80], xmm8
00007b2719bdb65e  vmovaps [rsp+0x90], xmm9
00007b2719bdb667  vmovaps [rsp+0xA0], xmm10
00007b2719bdb670  vmovaps [rsp+0xB0], xmm11
00007b2719bdb679  vmovaps [rsp+0xC0], xmm12
00007b2719bdb682  vmovaps [rsp+0xD0], xmm14
00007b2719bdb68b  vmovaps [rsp+0xE0], xmm15
00007b2719bdb694  sub rsp, 0x40
00007b2719bdb698  lea rdi, [rsp]
00007b2719bdb69c  lea rsi, [rsp+0x10]
00007b2719bdb6a1  lea rdx, [rsp+0x20]
00007b2719bdb6a6  lea rcx, [rsp+0x30]
00007b2719bdb6ab  mov r8d, 0x00
00007b2719bdb6b1  lea r9, [r15+0x3A8]
00007b2719bdb6b8  movaps [rdi], xmm13
00007b2719bdb6bc  movaps [rsi], xmm12
00007b2719bdb6c0  movaps [rdx], xmm14
00007b2719bdb6c4  movaps [rcx], xmm1
00007b2719bdb6c7  mov rax, 0x5A8E6560CA50
00007b2719bdb6d1  call rax
00007b2719bdb6d3  movaps xmm13, [rsp]
00007b2719bdb6d8  add rsp, 0x40
00007b2719bdb6dc  vmovaps xmm0, [rsp]
00007b2719bdb6e1  vmovaps xmm1, [rsp+0x10]
00007b2719bdb6e7  vmovaps xmm2, [rsp+0x20]
00007b2719bdb6ed  vmovaps xmm3, [rsp+0x30]
00007b2719bdb6f3  vmovaps xmm4, [rsp+0x40]
00007b2719bdb6f9  vmovaps xmm5, [rsp+0x50]
00007b2719bdb6ff  vmovaps xmm6, [rsp+0x60]
00007b2719bdb705  vmovaps xmm7, [rsp+0x70]
00007b2719bdb70b  vmovaps xmm8, [rsp+0x80]
00007b2719bdb714  vmovaps xmm9, [rsp+0x90]
00007b2719bdb71d  vmovaps xmm10, [rsp+0xA0]
00007b2719bdb726  vmovaps xmm11, [rsp+0xB0]
00007b2719bdb72f  vmovaps xmm12, [rsp+0xC0]
00007b2719bdb738  vmovaps xmm14, [rsp+0xD0]
00007b2719bdb741  vmovaps xmm15, [rsp+0xE0]
00007b2719bdb74a  add rsp, 0xF0
00007b2719bdb751  pop r11
00007b2719bdb753  pop r10
00007b2719bdb755  pop r9
00007b2719bdb757  pop r8
00007b2719bdb759  pop rsi
00007b2719bdb75a  pop rdi
00007b2719bdb75b  pop rdx
00007b2719bdb75c  pop rcx
00007b2719bdb75d  pop rax
00007b2719bdb75e  add rsp, 0x08
00007b2719bdb762  jmp 0x00007B2719BDA1F9
00007b2719bdb767  sub rsp, 0x08
00007b2719bdb76b  push rax
00007b2719bdb76c  push rcx
00007b2719bdb76d  push rdx
00007b2719bdb76e  push rdi
00007b2719bdb76f  push rsi
00007b2719bdb770  push r8
00007b2719bdb772  push r9
00007b2719bdb774  push r10
00007b2719bdb776  push r11
00007b2719bdb778  sub rsp, 0xF0
00007b2719bdb77f  vmovaps [rsp], xmm0
00007b2719bdb784  vmovaps [rsp+0x10], xmm1
00007b2719bdb78a  vmovaps [rsp+0x20], xmm2
00007b2719bdb790  vmovaps [rsp+0x30], xmm3
00007b2719bdb796  vmovaps [rsp+0x40], xmm4
00007b2719bdb79c  vmovaps [rsp+0x50], xmm5
00007b2719bdb7a2  vmovaps [rsp+0x60], xmm6
00007b2719bdb7a8  vmovaps [rsp+0x70], xmm7
00007b2719bdb7ae  vmovaps [rsp+0x80], xmm8
00007b2719bdb7b7  vmovaps [rsp+0x90], xmm9
00007b2719bdb7c0  vmovaps [rsp+0xA0], xmm10
00007b2719bdb7c9  vmovaps [rsp+0xB0], xmm11
00007b2719bdb7d2  vmovaps [rsp+0xC0], xmm13
00007b2719bdb7db  vmovaps [rsp+0xD0], xmm14
00007b2719bdb7e4  vmovaps [rsp+0xE0], xmm15
00007b2719bdb7ed  sub rsp, 0x40
00007b2719bdb7f1  lea rdi, [rsp]
00007b2719bdb7f5  lea rsi, [rsp+0x10]
00007b2719bdb7fa  lea rdx, [rsp+0x20]
00007b2719bdb7ff  lea rcx, [rsp+0x30]
00007b2719bdb804  mov r8d, 0x00
00007b2719bdb80a  lea r9, [r15+0x3A8]
00007b2719bdb811  movaps [rdi], xmm12
00007b2719bdb815  movaps [rsi], xmm3
00007b2719bdb818  movaps [rdx], xmm14
00007b2719bdb81c  movaps [rcx], xmm5
00007b2719bdb81f  mov rax, 0x5A8E6560CA50
00007b2719bdb829  call rax
00007b2719bdb82b  movaps xmm12, [rsp]
00007b2719bdb830  add rsp, 0x40
00007b2719bdb834  vmovaps xmm0, [rsp]
00007b2719bdb839  vmovaps xmm1, [rsp+0x10]
00007b2719bdb83f  vmovaps xmm2, [rsp+0x20]
00007b2719bdb845  vmovaps xmm3, [rsp+0x30]
00007b2719bdb84b  vmovaps xmm4, [rsp+0x40]
00007b2719bdb851  vmovaps xmm5, [rsp+0x50]
00007b2719bdb857  vmovaps xmm6, [rsp+0x60]
00007b2719bdb85d  vmovaps xmm7, [rsp+0x70]
00007b2719bdb863  vmovaps xmm8, [rsp+0x80]
00007b2719bdb86c  vmovaps xmm9, [rsp+0x90]
00007b2719bdb875  vmovaps xmm10, [rsp+0xA0]
00007b2719bdb87e  vmovaps xmm11, [rsp+0xB0]
00007b2719bdb887  vmovaps xmm13, [rsp+0xC0]
00007b2719bdb890  vmovaps xmm14, [rsp+0xD0]
00007b2719bdb899  vmovaps xmm15, [rsp+0xE0]
00007b2719bdb8a2  add rsp, 0xF0
00007b2719bdb8a9  pop r11
00007b2719bdb8ab  pop r10
00007b2719bdb8ad  pop r9
00007b2719bdb8af  pop r8
00007b2719bdb8b1  pop rsi
00007b2719bdb8b2  pop rdi
00007b2719bdb8b3  pop rdx
00007b2719bdb8b4  pop rcx
00007b2719bdb8b5  pop rax
00007b2719bdb8b6  add rsp, 0x08
00007b2719bdb8ba  jmp 0x00007B2719BDA256
00007b2719bdb8bf  sub rsp, 0x08
00007b2719bdb8c3  push rax
00007b2719bdb8c4  push rcx
00007b2719bdb8c5  push rdx
00007b2719bdb8c6  push rdi
00007b2719bdb8c7  push rsi
00007b2719bdb8c8  push r8
00007b2719bdb8ca  push r9
00007b2719bdb8cc  push r10
00007b2719bdb8ce  push r11
00007b2719bdb8d0  sub rsp, 0xF0
00007b2719bdb8d7  vmovaps [rsp], xmm0
00007b2719bdb8dc  vmovaps [rsp+0x10], xmm1
00007b2719bdb8e2  vmovaps [rsp+0x20], xmm2
00007b2719bdb8e8  vmovaps [rsp+0x30], xmm3
00007b2719bdb8ee  vmovaps [rsp+0x40], xmm4
00007b2719bdb8f4  vmovaps [rsp+0x50], xmm5
00007b2719bdb8fa  vmovaps [rsp+0x60], xmm6
00007b2719bdb900  vmovaps [rsp+0x70], xmm7
00007b2719bdb906  vmovaps [rsp+0x80], xmm8
00007b2719bdb90f  vmovaps [rsp+0x90], xmm9
00007b2719bdb918  vmovaps [rsp+0xA0], xmm11
00007b2719bdb921  vmovaps [rsp+0xB0], xmm12
00007b2719bdb92a  vmovaps [rsp+0xC0], xmm13
00007b2719bdb933  vmovaps [rsp+0xD0], xmm14
00007b2719bdb93c  vmovaps [rsp+0xE0], xmm15
00007b2719bdb945  sub rsp, 0x40
00007b2719bdb949  lea rdi, [rsp]
00007b2719bdb94d  lea rsi, [rsp+0x10]
00007b2719bdb952  lea rdx, [rsp+0x20]
00007b2719bdb957  lea rcx, [rsp+0x30]
00007b2719bdb95c  mov r8d, 0x00
00007b2719bdb962  lea r9, [r15+0x3A8]
00007b2719bdb969  movaps [rdi], xmm10
00007b2719bdb96d  movaps [rsi], xmm9
00007b2719bdb971  movaps [rdx], xmm7
00007b2719bdb974  movaps [rcx], xmm14
00007b2719bdb978  mov rax, 0x5A8E6560CA50
00007b2719bdb982  call rax
00007b2719bdb984  movaps xmm10, [rsp]
00007b2719bdb989  add rsp, 0x40
00007b2719bdb98d  vmovaps xmm0, [rsp]
00007b2719bdb992  vmovaps xmm1, [rsp+0x10]
00007b2719bdb998  vmovaps xmm2, [rsp+0x20]
00007b2719bdb99e  vmovaps xmm3, [rsp+0x30]
00007b2719bdb9a4  vmovaps xmm4, [rsp+0x40]
00007b2719bdb9aa  vmovaps xmm5, [rsp+0x50]
00007b2719bdb9b0  vmovaps xmm6, [rsp+0x60]
00007b2719bdb9b6  vmovaps xmm7, [rsp+0x70]
00007b2719bdb9bc  vmovaps xmm8, [rsp+0x80]
00007b2719bdb9c5  vmovaps xmm9, [rsp+0x90]
00007b2719bdb9ce  vmovaps xmm11, [rsp+0xA0]
00007b2719bdb9d7  vmovaps xmm12, [rsp+0xB0]
00007b2719bdb9e0  vmovaps xmm13, [rsp+0xC0]
00007b2719bdb9e9  vmovaps xmm14, [rsp+0xD0]
00007b2719bdb9f2  vmovaps xmm15, [rsp+0xE0]
00007b2719bdb9fb  add rsp, 0xF0
00007b2719bdba02  pop r11
00007b2719bdba04  pop r10
00007b2719bdba06  pop r9
00007b2719bdba08  pop r8
00007b2719bdba0a  pop rsi
00007b2719bdba0b  pop rdi
00007b2719bdba0c  pop rdx
00007b2719bdba0d  pop rcx
00007b2719bdba0e  pop rax
00007b2719bdba0f  add rsp, 0x08
00007b2719bdba13  jmp 0x00007B2719BDA27C
00007b2719bdba18  call 0x00007B2719A0D4E0
00007b2719bdba1d  jmp 0x00007B2719BDA289
00007b2719bdba22  sub rsp, 0x08
00007b2719bdba26  push rax
00007b2719bdba27  push rcx
00007b2719bdba28  push rdx
00007b2719bdba29  push rdi
00007b2719bdba2a  push rsi
00007b2719bdba2b  push r8
00007b2719bdba2d  push r9
00007b2719bdba2f  push r10
00007b2719bdba31  push r11
00007b2719bdba33  sub rsp, 0xF0
00007b2719bdba3a  vmovaps [rsp], xmm0
00007b2719bdba3f  vmovaps [rsp+0x10], xmm1
00007b2719bdba45  vmovaps [rsp+0x20], xmm2
00007b2719bdba4b  vmovaps [rsp+0x30], xmm3
00007b2719bdba51  vmovaps [rsp+0x40], xmm4
00007b2719bdba57  vmovaps [rsp+0x50], xmm6
00007b2719bdba5d  vmovaps [rsp+0x60], xmm7
00007b2719bdba63  vmovaps [rsp+0x70], xmm8
00007b2719bdba69  vmovaps [rsp+0x80], xmm9
00007b2719bdba72  vmovaps [rsp+0x90], xmm10
00007b2719bdba7b  vmovaps [rsp+0xA0], xmm11
00007b2719bdba84  vmovaps [rsp+0xB0], xmm12
00007b2719bdba8d  vmovaps [rsp+0xC0], xmm13
00007b2719bdba96  vmovaps [rsp+0xD0], xmm14
00007b2719bdba9f  vmovaps [rsp+0xE0], xmm15
00007b2719bdbaa8  sub rsp, 0x40
00007b2719bdbaac  lea rdi, [rsp]
00007b2719bdbab0  lea rsi, [rsp+0x10]
00007b2719bdbab5  lea rdx, [rsp+0x20]
00007b2719bdbaba  lea rcx, [rsp+0x30]
00007b2719bdbabf  mov r8d, 0x00
00007b2719bdbac5  lea r9, [r15+0x3A8]
00007b2719bdbacc  movaps [rdi], xmm5
00007b2719bdbacf  movaps [rsi], xmm6
00007b2719bdbad2  movaps [rdx], xmm7
00007b2719bdbad5  movaps [rcx], xmm9
00007b2719bdbad9  mov rax, 0x5A8E6560CA50
00007b2719bdbae3  call rax
00007b2719bdbae5  movaps xmm5, [rsp]
00007b2719bdbae9  add rsp, 0x40
00007b2719bdbaed  vmovaps xmm0, [rsp]
00007b2719bdbaf2  vmovaps xmm1, [rsp+0x10]
00007b2719bdbaf8  vmovaps xmm2, [rsp+0x20]
00007b2719bdbafe  vmovaps xmm3, [rsp+0x30]
00007b2719bdbb04  vmovaps xmm4, [rsp+0x40]
00007b2719bdbb0a  vmovaps xmm6, [rsp+0x50]
00007b2719bdbb10  vmovaps xmm7, [rsp+0x60]
00007b2719bdbb16  vmovaps xmm8, [rsp+0x70]
00007b2719bdbb1c  vmovaps xmm9, [rsp+0x80]
00007b2719bdbb25  vmovaps xmm10, [rsp+0x90]
00007b2719bdbb2e  vmovaps xmm11, [rsp+0xA0]
00007b2719bdbb37  vmovaps xmm12, [rsp+0xB0]
00007b2719bdbb40  vmovaps xmm13, [rsp+0xC0]
00007b2719bdbb49  vmovaps xmm14, [rsp+0xD0]
00007b2719bdbb52  vmovaps xmm15, [rsp+0xE0]
00007b2719bdbb5b  add rsp, 0xF0
00007b2719bdbb62  pop r11
00007b2719bdbb64  pop r10
00007b2719bdbb66  pop r9
00007b2719bdbb68  pop r8
00007b2719bdbb6a  pop rsi
00007b2719bdbb6b  pop rdi
00007b2719bdbb6c  pop rdx
00007b2719bdbb6d  pop rcx
00007b2719bdbb6e  pop rax
00007b2719bdbb6f  add rsp, 0x08
00007b2719bdbb73  jmp 0x00007B2719BDA2BB
00007b2719bdbb78  sub rsp, 0x08
00007b2719bdbb7c  push rax
00007b2719bdbb7d  push rcx
00007b2719bdbb7e  push rdx
00007b2719bdbb7f  push rdi
00007b2719bdbb80  push rsi
00007b2719bdbb81  push r8
00007b2719bdbb83  push r9
00007b2719bdbb85  push r10
00007b2719bdbb87  push r11
00007b2719bdbb89  sub rsp, 0xF0
00007b2719bdbb90  vmovaps [rsp], xmm0
00007b2719bdbb95  vmovaps [rsp+0x10], xmm1
00007b2719bdbb9b  vmovaps [rsp+0x20], xmm2
00007b2719bdbba1  vmovaps [rsp+0x30], xmm3
00007b2719bdbba7  vmovaps [rsp+0x40], xmm4
00007b2719bdbbad  vmovaps [rsp+0x50], xmm5
00007b2719bdbbb3  vmovaps [rsp+0x60], xmm6
00007b2719bdbbb9  vmovaps [rsp+0x70], xmm8
00007b2719bdbbbf  vmovaps [rsp+0x80], xmm9
00007b2719bdbbc8  vmovaps [rsp+0x90], xmm10
00007b2719bdbbd1  vmovaps [rsp+0xA0], xmm11
00007b2719bdbbda  vmovaps [rsp+0xB0], xmm12
00007b2719bdbbe3  vmovaps [rsp+0xC0], xmm13
00007b2719bdbbec  vmovaps [rsp+0xD0], xmm14
00007b2719bdbbf5  vmovaps [rsp+0xE0], xmm15
00007b2719bdbbfe  sub rsp, 0x40
00007b2719bdbc02  lea rdi, [rsp]
00007b2719bdbc06  lea rsi, [rsp+0x10]
00007b2719bdbc0b  lea rdx, [rsp+0x20]
00007b2719bdbc10  lea rcx, [rsp+0x30]
00007b2719bdbc15  mov r8d, 0x00
00007b2719bdbc1b  lea r9, [r15+0x3A8]
00007b2719bdbc22  movaps [rdi], xmm7
00007b2719bdbc25  movaps [rsi], xmm13
00007b2719bdbc29  movaps [rdx], xmm1
00007b2719bdbc2c  movaps [rcx], xmm9
00007b2719bdbc30  mov rax, 0x5A8E6560CA50
00007b2719bdbc3a  call rax
00007b2719bdbc3c  movaps xmm7, [rsp]
00007b2719bdbc40  add rsp, 0x40
00007b2719bdbc44  vmovaps xmm0, [rsp]
00007b2719bdbc49  vmovaps xmm1, [rsp+0x10]
00007b2719bdbc4f  vmovaps xmm2, [rsp+0x20]
00007b2719bdbc55  vmovaps xmm3, [rsp+0x30]
00007b2719bdbc5b  vmovaps xmm4, [rsp+0x40]
00007b2719bdbc61  vmovaps xmm5, [rsp+0x50]
00007b2719bdbc67  vmovaps xmm6, [rsp+0x60]
00007b2719bdbc6d  vmovaps xmm8, [rsp+0x70]
00007b2719bdbc73  vmovaps xmm9, [rsp+0x80]
00007b2719bdbc7c  vmovaps xmm10, [rsp+0x90]
00007b2719bdbc85  vmovaps xmm11, [rsp+0xA0]
00007b2719bdbc8e  vmovaps xmm12, [rsp+0xB0]
00007b2719bdbc97  vmovaps xmm13, [rsp+0xC0]
00007b2719bdbca0  vmovaps xmm14, [rsp+0xD0]
00007b2719bdbca9  vmovaps xmm15, [rsp+0xE0]
00007b2719bdbcb2  add rsp, 0xF0
00007b2719bdbcb9  pop r11
00007b2719bdbcbb  pop r10
00007b2719bdbcbd  pop r9
00007b2719bdbcbf  pop r8
00007b2719bdbcc1  pop rsi
00007b2719bdbcc2  pop rdi
00007b2719bdbcc3  pop rdx
00007b2719bdbcc4  pop rcx
00007b2719bdbcc5  pop rax
00007b2719bdbcc6  add rsp, 0x08
00007b2719bdbcca  jmp 0x00007B2719BDA2E0
00007b2719bdbccf  call 0x00007B2719A0C260
00007b2719bdbcd4  jmp 0x00007B2719BDA303
00007b2719bdbcd9  call 0x00007B2719A07890
00007b2719bdbcde  jmp 0x00007B2719BDA30D
00007b2719bdbce3  sub rsp, 0x08
00007b2719bdbce7  push rax
00007b2719bdbce8  push rcx
00007b2719bdbce9  push rdx
00007b2719bdbcea  push rdi
00007b2719bdbceb  push rsi
00007b2719bdbcec  push r8
00007b2719bdbcee  push r9
00007b2719bdbcf0  push r10
00007b2719bdbcf2  push r11
00007b2719bdbcf4  sub rsp, 0xF0
00007b2719bdbcfb  vmovaps [rsp], xmm0
00007b2719bdbd00  vmovaps [rsp+0x10], xmm1
00007b2719bdbd06  vmovaps [rsp+0x20], xmm3
00007b2719bdbd0c  vmovaps [rsp+0x30], xmm4
00007b2719bdbd12  vmovaps [rsp+0x40], xmm5
00007b2719bdbd18  vmovaps [rsp+0x50], xmm6
00007b2719bdbd1e  vmovaps [rsp+0x60], xmm7
00007b2719bdbd24  vmovaps [rsp+0x70], xmm8
00007b2719bdbd2a  vmovaps [rsp+0x80], xmm9
00007b2719bdbd33  vmovaps [rsp+0x90], xmm10
00007b2719bdbd3c  vmovaps [rsp+0xA0], xmm11
00007b2719bdbd45  vmovaps [rsp+0xB0], xmm12
00007b2719bdbd4e  vmovaps [rsp+0xC0], xmm13
00007b2719bdbd57  vmovaps [rsp+0xD0], xmm14
00007b2719bdbd60  vmovaps [rsp+0xE0], xmm15
00007b2719bdbd69  sub rsp, 0x40
00007b2719bdbd6d  lea rdi, [rsp]
00007b2719bdbd71  lea rsi, [rsp+0x10]
00007b2719bdbd76  lea rdx, [rsp+0x20]
00007b2719bdbd7b  lea rcx, [rsp+0x30]
00007b2719bdbd80  mov r8d, 0x00
00007b2719bdbd86  lea r9, [r15+0x3A8]
00007b2719bdbd8d  movaps [rdi], xmm2
00007b2719bdbd90  movaps [rsi], xmm12
00007b2719bdbd94  movaps [rdx], xmm6
00007b2719bdbd97  movaps [rcx], xmm3
00007b2719bdbd9a  mov rax, 0x5A8E6560CA50
00007b2719bdbda4  call rax
00007b2719bdbda6  movaps xmm2, [rsp]
00007b2719bdbdaa  add rsp, 0x40
00007b2719bdbdae  vmovaps xmm0, [rsp]
00007b2719bdbdb3  vmovaps xmm1, [rsp+0x10]
00007b2719bdbdb9  vmovaps xmm3, [rsp+0x20]
00007b2719bdbdbf  vmovaps xmm4, [rsp+0x30]
00007b2719bdbdc5  vmovaps xmm5, [rsp+0x40]
00007b2719bdbdcb  vmovaps xmm6, [rsp+0x50]
00007b2719bdbdd1  vmovaps xmm7, [rsp+0x60]
00007b2719bdbdd7  vmovaps xmm8, [rsp+0x70]
00007b2719bdbddd  vmovaps xmm9, [rsp+0x80]
00007b2719bdbde6  vmovaps xmm10, [rsp+0x90]
00007b2719bdbdef  vmovaps xmm11, [rsp+0xA0]
00007b2719bdbdf8  vmovaps xmm12, [rsp+0xB0]
00007b2719bdbe01  vmovaps xmm13, [rsp+0xC0]
00007b2719bdbe0a  vmovaps xmm14, [rsp+0xD0]
00007b2719bdbe13  vmovaps xmm15, [rsp+0xE0]
00007b2719bdbe1c  add rsp, 0xF0
00007b2719bdbe23  pop r11
00007b2719bdbe25  pop r10
00007b2719bdbe27  pop r9
00007b2719bdbe29  pop r8
00007b2719bdbe2b  pop rsi
00007b2719bdbe2c  pop rdi
00007b2719bdbe2d  pop rdx
00007b2719bdbe2e  pop rcx
00007b2719bdbe2f  pop rax
00007b2719bdbe30  add rsp, 0x08
00007b2719bdbe34  jmp 0x00007B2719BDA353
00007b2719bdbe39  sub rsp, 0x08
00007b2719bdbe3d  push rax
00007b2719bdbe3e  push rcx
00007b2719bdbe3f  push rdx
00007b2719bdbe40  push rdi
00007b2719bdbe41  push rsi
00007b2719bdbe42  push r8
00007b2719bdbe44  push r9
00007b2719bdbe46  push r10
00007b2719bdbe48  push r11
00007b2719bdbe4a  sub rsp, 0xF0
00007b2719bdbe51  vmovaps [rsp], xmm0
00007b2719bdbe56  vmovaps [rsp+0x10], xmm1
00007b2719bdbe5c  vmovaps [rsp+0x20], xmm2
00007b2719bdbe62  vmovaps [rsp+0x30], xmm3
00007b2719bdbe68  vmovaps [rsp+0x40], xmm4
00007b2719bdbe6e  vmovaps [rsp+0x50], xmm5
00007b2719bdbe74  vmovaps [rsp+0x60], xmm7
00007b2719bdbe7a  vmovaps [rsp+0x70], xmm8
00007b2719bdbe80  vmovaps [rsp+0x80], xmm9
00007b2719bdbe89  vmovaps [rsp+0x90], xmm10
00007b2719bdbe92  vmovaps [rsp+0xA0], xmm11
00007b2719bdbe9b  vmovaps [rsp+0xB0], xmm12
00007b2719bdbea4  vmovaps [rsp+0xC0], xmm13
00007b2719bdbead  vmovaps [rsp+0xD0], xmm14
00007b2719bdbeb6  vmovaps [rsp+0xE0], xmm15
00007b2719bdbebf  sub rsp, 0x40
00007b2719bdbec3  lea rdi, [rsp]
00007b2719bdbec7  lea rsi, [rsp+0x10]
00007b2719bdbecc  lea rdx, [rsp+0x20]
00007b2719bdbed1  lea rcx, [rsp+0x30]
00007b2719bdbed6  mov r8d, 0x00
00007b2719bdbedc  lea r9, [r15+0x3A8]
00007b2719bdbee3  movaps [rdi], xmm6
00007b2719bdbee6  movaps [rsi], xmm10
00007b2719bdbeea  movaps [rdx], xmm12
00007b2719bdbeee  movaps [rcx], xmm1
00007b2719bdbef1  mov rax, 0x5A8E6560CA50
00007b2719bdbefb  call rax
00007b2719bdbefd  movaps xmm6, [rsp]
00007b2719bdbf01  add rsp, 0x40
00007b2719bdbf05  vmovaps xmm0, [rsp]
00007b2719bdbf0a  vmovaps xmm1, [rsp+0x10]
00007b2719bdbf10  vmovaps xmm2, [rsp+0x20]
00007b2719bdbf16  vmovaps xmm3, [rsp+0x30]
00007b2719bdbf1c  vmovaps xmm4, [rsp+0x40]
00007b2719bdbf22  vmovaps xmm5, [rsp+0x50]
00007b2719bdbf28  vmovaps xmm7, [rsp+0x60]
00007b2719bdbf2e  vmovaps xmm8, [rsp+0x70]
00007b2719bdbf34  vmovaps xmm9, [rsp+0x80]
00007b2719bdbf3d  vmovaps xmm10, [rsp+0x90]
00007b2719bdbf46  vmovaps xmm11, [rsp+0xA0]
00007b2719bdbf4f  vmovaps xmm12, [rsp+0xB0]
00007b2719bdbf58  vmovaps xmm13, [rsp+0xC0]
00007b2719bdbf61  vmovaps xmm14, [rsp+0xD0]
00007b2719bdbf6a  vmovaps xmm15, [rsp+0xE0]
00007b2719bdbf73  add rsp, 0xF0
00007b2719bdbf7a  pop r11
00007b2719bdbf7c  pop r10
00007b2719bdbf7e  pop r9
00007b2719bdbf80  pop r8
00007b2719bdbf82  pop rsi
00007b2719bdbf83  pop rdi
00007b2719bdbf84  pop rdx
00007b2719bdbf85  pop rcx
00007b2719bdbf86  pop rax
00007b2719bdbf87  add rsp, 0x08
00007b2719bdbf8b  jmp 0x00007B2719BDA381
00007b2719bdbf90  sub rsp, 0x08
00007b2719bdbf94  push rax
00007b2719bdbf95  push rcx
00007b2719bdbf96  push rdx
00007b2719bdbf97  push rdi
00007b2719bdbf98  push rsi
00007b2719bdbf99  push r8
00007b2719bdbf9b  push r9
00007b2719bdbf9d  push r10
00007b2719bdbf9f  push r11
00007b2719bdbfa1  sub rsp, 0xF0
00007b2719bdbfa8  vmovaps [rsp], xmm0
00007b2719bdbfad  vmovaps [rsp+0x10], xmm1
00007b2719bdbfb3  vmovaps [rsp+0x20], xmm2
00007b2719bdbfb9  vmovaps [rsp+0x30], xmm3
00007b2719bdbfbf  vmovaps [rsp+0x40], xmm4
00007b2719bdbfc5  vmovaps [rsp+0x50], xmm5
00007b2719bdbfcb  vmovaps [rsp+0x60], xmm6
00007b2719bdbfd1  vmovaps [rsp+0x70], xmm7
00007b2719bdbfd7  vmovaps [rsp+0x80], xmm8
00007b2719bdbfe0  vmovaps [rsp+0x90], xmm9
00007b2719bdbfe9  vmovaps [rsp+0xA0], xmm11
00007b2719bdbff2  vmovaps [rsp+0xB0], xmm12
00007b2719bdbffb  vmovaps [rsp+0xC0], xmm13
00007b2719bdc004  vmovaps [rsp+0xD0], xmm14
00007b2719bdc00d  vmovaps [rsp+0xE0], xmm15
00007b2719bdc016  sub rsp, 0x40
00007b2719bdc01a  lea rdi, [rsp]
00007b2719bdc01e  lea rsi, [rsp+0x10]
00007b2719bdc023  lea rdx, [rsp+0x20]
00007b2719bdc028  lea rcx, [rsp+0x30]
00007b2719bdc02d  mov r8d, 0x00
00007b2719bdc033  lea r9, [r15+0x3A8]
00007b2719bdc03a  movaps [rdi], xmm10
00007b2719bdc03e  movaps [rsi], xmm5
00007b2719bdc041  movaps [rdx], xmm12
00007b2719bdc045  movaps [rcx], xmm1
00007b2719bdc048  mov rax, 0x5A8E6560CA50
00007b2719bdc052  call rax
00007b2719bdc054  movaps xmm10, [rsp]
00007b2719bdc059  add rsp, 0x40
00007b2719bdc05d  vmovaps xmm0, [rsp]
00007b2719bdc062  vmovaps xmm1, [rsp+0x10]
00007b2719bdc068  vmovaps xmm2, [rsp+0x20]
00007b2719bdc06e  vmovaps xmm3, [rsp+0x30]
00007b2719bdc074  vmovaps xmm4, [rsp+0x40]
00007b2719bdc07a  vmovaps xmm5, [rsp+0x50]
00007b2719bdc080  vmovaps xmm6, [rsp+0x60]
00007b2719bdc086  vmovaps xmm7, [rsp+0x70]
00007b2719bdc08c  vmovaps xmm8, [rsp+0x80]
00007b2719bdc095  vmovaps xmm9, [rsp+0x90]
00007b2719bdc09e  vmovaps xmm11, [rsp+0xA0]
00007b2719bdc0a7  vmovaps xmm12, [rsp+0xB0]
00007b2719bdc0b0  vmovaps xmm13, [rsp+0xC0]
00007b2719bdc0b9  vmovaps xmm14, [rsp+0xD0]
00007b2719bdc0c2  vmovaps xmm15, [rsp+0xE0]
00007b2719bdc0cb  add rsp, 0xF0
00007b2719bdc0d2  pop r11
00007b2719bdc0d4  pop r10
00007b2719bdc0d6  pop r9
00007b2719bdc0d8  pop r8
00007b2719bdc0da  pop rsi
00007b2719bdc0db  pop rdi
00007b2719bdc0dc  pop rdx
00007b2719bdc0dd  pop rcx
00007b2719bdc0de  pop rax
00007b2719bdc0df  add rsp, 0x08
00007b2719bdc0e3  jmp 0x00007B2719BDA3B0
00007b2719bdc0e8  sub rsp, 0x08
00007b2719bdc0ec  push rax
00007b2719bdc0ed  push rcx
00007b2719bdc0ee  push rdx
00007b2719bdc0ef  push rdi
00007b2719bdc0f0  push rsi
00007b2719bdc0f1  push r8
00007b2719bdc0f3  push r9
00007b2719bdc0f5  push r10
00007b2719bdc0f7  push r11
00007b2719bdc0f9  sub rsp, 0xF0
00007b2719bdc100  vmovaps [rsp], xmm0
00007b2719bdc105  vmovaps [rsp+0x10], xmm1
00007b2719bdc10b  vmovaps [rsp+0x20], xmm2
00007b2719bdc111  vmovaps [rsp+0x30], xmm3
00007b2719bdc117  vmovaps [rsp+0x40], xmm4
00007b2719bdc11d  vmovaps [rsp+0x50], xmm5
00007b2719bdc123  vmovaps [rsp+0x60], xmm6
00007b2719bdc129  vmovaps [rsp+0x70], xmm7
00007b2719bdc12f  vmovaps [rsp+0x80], xmm8
00007b2719bdc138  vmovaps [rsp+0x90], xmm9
00007b2719bdc141  vmovaps [rsp+0xA0], xmm10
00007b2719bdc14a  vmovaps [rsp+0xB0], xmm11
00007b2719bdc153  vmovaps [rsp+0xC0], xmm13
00007b2719bdc15c  vmovaps [rsp+0xD0], xmm14
00007b2719bdc165  vmovaps [rsp+0xE0], xmm15
00007b2719bdc16e  sub rsp, 0x40
00007b2719bdc172  lea rdi, [rsp]
00007b2719bdc176  lea rsi, [rsp+0x10]
00007b2719bdc17b  lea rdx, [rsp+0x20]
00007b2719bdc180  lea rcx, [rsp+0x30]
00007b2719bdc185  mov r8d, 0x00
00007b2719bdc18b  lea r9, [r15+0x3A8]
00007b2719bdc192  movaps [rdi], xmm12
00007b2719bdc196  movaps [rsi], xmm7
00007b2719bdc199  movaps [rdx], xmm15
00007b2719bdc19d  movaps [rcx], xmm1
00007b2719bdc1a0  mov rax, 0x5A8E6560CA50
00007b2719bdc1aa  call rax
00007b2719bdc1ac  movaps xmm12, [rsp]
00007b2719bdc1b1  add rsp, 0x40
00007b2719bdc1b5  vmovaps xmm0, [rsp]
00007b2719bdc1ba  vmovaps xmm1, [rsp+0x10]
00007b2719bdc1c0  vmovaps xmm2, [rsp+0x20]
00007b2719bdc1c6  vmovaps xmm3, [rsp+0x30]
00007b2719bdc1cc  vmovaps xmm4, [rsp+0x40]
00007b2719bdc1d2  vmovaps xmm5, [rsp+0x50]
00007b2719bdc1d8  vmovaps xmm6, [rsp+0x60]
00007b2719bdc1de  vmovaps xmm7, [rsp+0x70]
00007b2719bdc1e4  vmovaps xmm8, [rsp+0x80]
00007b2719bdc1ed  vmovaps xmm9, [rsp+0x90]
00007b2719bdc1f6  vmovaps xmm10, [rsp+0xA0]
00007b2719bdc1ff  vmovaps xmm11, [rsp+0xB0]
00007b2719bdc208  vmovaps xmm13, [rsp+0xC0]
00007b2719bdc211  vmovaps xmm14, [rsp+0xD0]
00007b2719bdc21a  vmovaps xmm15, [rsp+0xE0]
00007b2719bdc223  add rsp, 0xF0
00007b2719bdc22a  pop r11
00007b2719bdc22c  pop r10
00007b2719bdc22e  pop r9
00007b2719bdc230  pop r8
00007b2719bdc232  pop rsi
00007b2719bdc233  pop rdi
00007b2719bdc234  pop rdx
00007b2719bdc235  pop rcx
00007b2719bdc236  pop rax
00007b2719bdc237  add rsp, 0x08
00007b2719bdc23b  jmp 0x00007B2719BDA3D9
00007b2719bdc240  call 0x00007B27199FF430
00007b2719bdc245  jmp 0x00007B2719BDA3E3
00007b2719bdc24a  call 0x00007B2719A0E760
00007b2719bdc24f  jmp 0x00007B2719BDA3ED
00007b2719bdc254  sub rsp, 0x08
00007b2719bdc258  push rax
00007b2719bdc259  push rcx
00007b2719bdc25a  push rdx
00007b2719bdc25b  push rdi
00007b2719bdc25c  push rsi
00007b2719bdc25d  push r8
00007b2719bdc25f  push r9
00007b2719bdc261  push r10
00007b2719bdc263  push r11
00007b2719bdc265  sub rsp, 0xF0
00007b2719bdc26c  vmovaps [rsp], xmm0
00007b2719bdc271  vmovaps [rsp+0x10], xmm1
00007b2719bdc277  vmovaps [rsp+0x20], xmm2
00007b2719bdc27d  vmovaps [rsp+0x30], xmm3
00007b2719bdc283  vmovaps [rsp+0x40], xmm4
00007b2719bdc289  vmovaps [rsp+0x50], xmm5
00007b2719bdc28f  vmovaps [rsp+0x60], xmm6
00007b2719bdc295  vmovaps [rsp+0x70], xmm8
00007b2719bdc29b  vmovaps [rsp+0x80], xmm9
00007b2719bdc2a4  vmovaps [rsp+0x90], xmm10
00007b2719bdc2ad  vmovaps [rsp+0xA0], xmm11
00007b2719bdc2b6  vmovaps [rsp+0xB0], xmm12
00007b2719bdc2bf  vmovaps [rsp+0xC0], xmm13
00007b2719bdc2c8  vmovaps [rsp+0xD0], xmm14
00007b2719bdc2d1  vmovaps [rsp+0xE0], xmm15
00007b2719bdc2da  sub rsp, 0x40
00007b2719bdc2de  lea rdi, [rsp]
00007b2719bdc2e2  lea rsi, [rsp+0x10]
00007b2719bdc2e7  lea rdx, [rsp+0x20]
00007b2719bdc2ec  lea rcx, [rsp+0x30]
00007b2719bdc2f1  mov r8d, 0x00
00007b2719bdc2f7  lea r9, [r15+0x3A8]
00007b2719bdc2fe  movaps [rdi], xmm7
00007b2719bdc301  movaps [rsi], xmm2
00007b2719bdc304  movaps [rdx], xmm9
00007b2719bdc308  movaps [rcx], xmm11
00007b2719bdc30c  mov rax, 0x5A8E6560CA50
00007b2719bdc316  call rax
00007b2719bdc318  movaps xmm7, [rsp]
00007b2719bdc31c  add rsp, 0x40
00007b2719bdc320  vmovaps xmm0, [rsp]
00007b2719bdc325  vmovaps xmm1, [rsp+0x10]
00007b2719bdc32b  vmovaps xmm2, [rsp+0x20]
00007b2719bdc331  vmovaps xmm3, [rsp+0x30]
00007b2719bdc337  vmovaps xmm4, [rsp+0x40]
00007b2719bdc33d  vmovaps xmm5, [rsp+0x50]
00007b2719bdc343  vmovaps xmm6, [rsp+0x60]
00007b2719bdc349  vmovaps xmm8, [rsp+0x70]
00007b2719bdc34f  vmovaps xmm9, [rsp+0x80]
00007b2719bdc358  vmovaps xmm10, [rsp+0x90]
00007b2719bdc361  vmovaps xmm11, [rsp+0xA0]
00007b2719bdc36a  vmovaps xmm12, [rsp+0xB0]
00007b2719bdc373  vmovaps xmm13, [rsp+0xC0]
00007b2719bdc37c  vmovaps xmm14, [rsp+0xD0]
00007b2719bdc385  vmovaps xmm15, [rsp+0xE0]
00007b2719bdc38e  add rsp, 0xF0
00007b2719bdc395  pop r11
00007b2719bdc397  pop r10
00007b2719bdc399  pop r9
00007b2719bdc39b  pop r8
00007b2719bdc39d  pop rsi
00007b2719bdc39e  pop rdi
00007b2719bdc39f  pop rdx
00007b2719bdc3a0  pop rcx
00007b2719bdc3a1  pop rax
00007b2719bdc3a2  add rsp, 0x08
00007b2719bdc3a6  jmp 0x00007B2719BDA421
00007b2719bdc3ab  sub rsp, 0x08
00007b2719bdc3af  push rax
00007b2719bdc3b0  push rcx
00007b2719bdc3b1  push rdx
00007b2719bdc3b2  push rdi
00007b2719bdc3b3  push rsi
00007b2719bdc3b4  push r8
00007b2719bdc3b6  push r9
00007b2719bdc3b8  push r10
00007b2719bdc3ba  push r11
00007b2719bdc3bc  sub rsp, 0xF0
00007b2719bdc3c3  vmovaps [rsp], xmm0
00007b2719bdc3c8  vmovaps [rsp+0x10], xmm1
00007b2719bdc3ce  vmovaps [rsp+0x20], xmm2
00007b2719bdc3d4  vmovaps [rsp+0x30], xmm3
00007b2719bdc3da  vmovaps [rsp+0x40], xmm4
00007b2719bdc3e0  vmovaps [rsp+0x50], xmm5
00007b2719bdc3e6  vmovaps [rsp+0x60], xmm6
00007b2719bdc3ec  vmovaps [rsp+0x70], xmm7
00007b2719bdc3f2  vmovaps [rsp+0x80], xmm8
00007b2719bdc3fb  vmovaps [rsp+0x90], xmm10
00007b2719bdc404  vmovaps [rsp+0xA0], xmm11
00007b2719bdc40d  vmovaps [rsp+0xB0], xmm12
00007b2719bdc416  vmovaps [rsp+0xC0], xmm13
00007b2719bdc41f  vmovaps [rsp+0xD0], xmm14
00007b2719bdc428  vmovaps [rsp+0xE0], xmm15
00007b2719bdc431  sub rsp, 0x40
00007b2719bdc435  lea rdi, [rsp]
00007b2719bdc439  lea rsi, [rsp+0x10]
00007b2719bdc43e  lea rdx, [rsp+0x20]
00007b2719bdc443  lea rcx, [rsp+0x30]
00007b2719bdc448  mov r8d, 0x00
00007b2719bdc44e  lea r9, [r15+0x3A8]
00007b2719bdc455  movaps [rdi], xmm9
00007b2719bdc459  movaps [rsi], xmm6
00007b2719bdc45c  movaps [rdx], xmm1
00007b2719bdc45f  movaps [rcx], xmm11
00007b2719bdc463  mov rax, 0x5A8E6560CA50
00007b2719bdc46d  call rax
00007b2719bdc46f  movaps xmm9, [rsp]
00007b2719bdc474  add rsp, 0x40
00007b2719bdc478  vmovaps xmm0, [rsp]
00007b2719bdc47d  vmovaps xmm1, [rsp+0x10]
00007b2719bdc483  vmovaps xmm2, [rsp+0x20]
00007b2719bdc489  vmovaps xmm3, [rsp+0x30]
00007b2719bdc48f  vmovaps xmm4, [rsp+0x40]
00007b2719bdc495  vmovaps xmm5, [rsp+0x50]
00007b2719bdc49b  vmovaps xmm6, [rsp+0x60]
00007b2719bdc4a1  vmovaps xmm7, [rsp+0x70]
00007b2719bdc4a7  vmovaps xmm8, [rsp+0x80]
00007b2719bdc4b0  vmovaps xmm10, [rsp+0x90]
00007b2719bdc4b9  vmovaps xmm11, [rsp+0xA0]
00007b2719bdc4c2  vmovaps xmm12, [rsp+0xB0]
00007b2719bdc4cb  vmovaps xmm13, [rsp+0xC0]
00007b2719bdc4d4  vmovaps xmm14, [rsp+0xD0]
00007b2719bdc4dd  vmovaps xmm15, [rsp+0xE0]
00007b2719bdc4e6  add rsp, 0xF0
00007b2719bdc4ed  pop r11
00007b2719bdc4ef  pop r10
00007b2719bdc4f1  pop r9
00007b2719bdc4f3  pop r8
00007b2719bdc4f5  pop rsi
00007b2719bdc4f6  pop rdi
00007b2719bdc4f7  pop rdx
00007b2719bdc4f8  pop rcx
00007b2719bdc4f9  pop rax
00007b2719bdc4fa  add rsp, 0x08
00007b2719bdc4fe  jmp 0x00007B2719BDA447
00007b2719bdc503  sub rsp, 0x08
00007b2719bdc507  push rax
00007b2719bdc508  push rcx
00007b2719bdc509  push rdx
00007b2719bdc50a  push rdi
00007b2719bdc50b  push rsi
00007b2719bdc50c  push r8
00007b2719bdc50e  push r9
00007b2719bdc510  push r10
00007b2719bdc512  push r11
00007b2719bdc514  sub rsp, 0xF0
00007b2719bdc51b  vmovaps [rsp], xmm0
00007b2719bdc520  vmovaps [rsp+0x10], xmm1
00007b2719bdc526  vmovaps [rsp+0x20], xmm2
00007b2719bdc52c  vmovaps [rsp+0x30], xmm3
00007b2719bdc532  vmovaps [rsp+0x40], xmm4
00007b2719bdc538  vmovaps [rsp+0x50], xmm5
00007b2719bdc53e  vmovaps [rsp+0x60], xmm6
00007b2719bdc544  vmovaps [rsp+0x70], xmm7
00007b2719bdc54a  vmovaps [rsp+0x80], xmm8
00007b2719bdc553  vmovaps [rsp+0x90], xmm9
00007b2719bdc55c  vmovaps [rsp+0xA0], xmm10
00007b2719bdc565  vmovaps [rsp+0xB0], xmm12
00007b2719bdc56e  vmovaps [rsp+0xC0], xmm13
00007b2719bdc577  vmovaps [rsp+0xD0], xmm14
00007b2719bdc580  vmovaps [rsp+0xE0], xmm15
00007b2719bdc589  sub rsp, 0x40
00007b2719bdc58d  lea rdi, [rsp]
00007b2719bdc591  lea rsi, [rsp+0x10]
00007b2719bdc596  lea rdx, [rsp+0x20]
00007b2719bdc59b  lea rcx, [rsp+0x30]
00007b2719bdc5a0  mov r8d, 0x00
00007b2719bdc5a6  lea r9, [r15+0x3A8]
00007b2719bdc5ad  movaps [rdi], xmm11
00007b2719bdc5b1  movaps [rsi], xmm10
00007b2719bdc5b5  movaps [rdx], xmm8
00007b2719bdc5b9  movaps [rcx], xmm1
00007b2719bdc5bc  mov rax, 0x5A8E6560CA50
00007b2719bdc5c6  call rax
00007b2719bdc5c8  movaps xmm11, [rsp]
00007b2719bdc5cd  add rsp, 0x40
00007b2719bdc5d1  vmovaps xmm0, [rsp]
00007b2719bdc5d6  vmovaps xmm1, [rsp+0x10]
00007b2719bdc5dc  vmovaps xmm2, [rsp+0x20]
00007b2719bdc5e2  vmovaps xmm3, [rsp+0x30]
00007b2719bdc5e8  vmovaps xmm4, [rsp+0x40]
00007b2719bdc5ee  vmovaps xmm5, [rsp+0x50]
00007b2719bdc5f4  vmovaps xmm6, [rsp+0x60]
00007b2719bdc5fa  vmovaps xmm7, [rsp+0x70]
00007b2719bdc600  vmovaps xmm8, [rsp+0x80]
00007b2719bdc609  vmovaps xmm9, [rsp+0x90]
00007b2719bdc612  vmovaps xmm10, [rsp+0xA0]
00007b2719bdc61b  vmovaps xmm12, [rsp+0xB0]
00007b2719bdc624  vmovaps xmm13, [rsp+0xC0]
00007b2719bdc62d  vmovaps xmm14, [rsp+0xD0]
00007b2719bdc636  vmovaps xmm15, [rsp+0xE0]
00007b2719bdc63f  add rsp, 0xF0
00007b2719bdc646  pop r11
00007b2719bdc648  pop r10
00007b2719bdc64a  pop r9
00007b2719bdc64c  pop r8
00007b2719bdc64e  pop rsi
00007b2719bdc64f  pop rdi
00007b2719bdc650  pop rdx
00007b2719bdc651  pop rcx
00007b2719bdc652  pop rax
00007b2719bdc653  add rsp, 0x08
00007b2719bdc657  jmp 0x00007B2719BDA46D
00007b2719bdc65c  sub rsp, 0x08
00007b2719bdc660  push rax
00007b2719bdc661  push rcx
00007b2719bdc662  push rdx
00007b2719bdc663  push rdi
00007b2719bdc664  push rsi
00007b2719bdc665  push r8
00007b2719bdc667  push r9
00007b2719bdc669  push r10
00007b2719bdc66b  push r11
00007b2719bdc66d  sub rsp, 0xF0
00007b2719bdc674  vmovaps [rsp], xmm0
00007b2719bdc679  vmovaps [rsp+0x10], xmm1
00007b2719bdc67f  vmovaps [rsp+0x20], xmm2
00007b2719bdc685  vmovaps [rsp+0x30], xmm3
00007b2719bdc68b  vmovaps [rsp+0x40], xmm4
00007b2719bdc691  vmovaps [rsp+0x50], xmm5
00007b2719bdc697  vmovaps [rsp+0x60], xmm6
00007b2719bdc69d  vmovaps [rsp+0x70], xmm7
00007b2719bdc6a3  vmovaps [rsp+0x80], xmm8
00007b2719bdc6ac  vmovaps [rsp+0x90], xmm9
00007b2719bdc6b5  vmovaps [rsp+0xA0], xmm11
00007b2719bdc6be  vmovaps [rsp+0xB0], xmm12
00007b2719bdc6c7  vmovaps [rsp+0xC0], xmm13
00007b2719bdc6d0  vmovaps [rsp+0xD0], xmm14
00007b2719bdc6d9  vmovaps [rsp+0xE0], xmm15
00007b2719bdc6e2  sub rsp, 0x40
00007b2719bdc6e6  lea rdi, [rsp]
00007b2719bdc6ea  lea rsi, [rsp+0x10]
00007b2719bdc6ef  lea rdx, [rsp+0x20]
00007b2719bdc6f4  lea rcx, [rsp+0x30]
00007b2719bdc6f9  mov r8d, 0x00
00007b2719bdc6ff  lea r9, [r15+0x3A8]
00007b2719bdc706  movaps [rdi], xmm10
00007b2719bdc70a  movaps [rsi], xmm12
00007b2719bdc70e  movaps [rdx], xmm13
00007b2719bdc712  movaps [rcx], xmm1
00007b2719bdc715  mov rax, 0x5A8E6560CA50
00007b2719bdc71f  call rax
00007b2719bdc721  movaps xmm10, [rsp]
00007b2719bdc726  add rsp, 0x40
00007b2719bdc72a  vmovaps xmm0, [rsp]
00007b2719bdc72f  vmovaps xmm1, [rsp+0x10]
00007b2719bdc735  vmovaps xmm2, [rsp+0x20]
00007b2719bdc73b  vmovaps xmm3, [rsp+0x30]
00007b2719bdc741  vmovaps xmm4, [rsp+0x40]
00007b2719bdc747  vmovaps xmm5, [rsp+0x50]
00007b2719bdc74d  vmovaps xmm6, [rsp+0x60]
00007b2719bdc753  vmovaps xmm7, [rsp+0x70]
00007b2719bdc759  vmovaps xmm8, [rsp+0x80]
00007b2719bdc762  vmovaps xmm9, [rsp+0x90]
00007b2719bdc76b  vmovaps xmm11, [rsp+0xA0]
00007b2719bdc774  vmovaps xmm12, [rsp+0xB0]
00007b2719bdc77d  vmovaps xmm13, [rsp+0xC0]
00007b2719bdc786  vmovaps xmm14, [rsp+0xD0]
00007b2719bdc78f  vmovaps xmm15, [rsp+0xE0]
00007b2719bdc798  add rsp, 0xF0
00007b2719bdc79f  pop r11
00007b2719bdc7a1  pop r10
00007b2719bdc7a3  pop r9
00007b2719bdc7a5  pop r8
00007b2719bdc7a7  pop rsi
00007b2719bdc7a8  pop rdi
00007b2719bdc7a9  pop rdx
00007b2719bdc7aa  pop rcx
00007b2719bdc7ab  pop rax
00007b2719bdc7ac  add rsp, 0x08
00007b2719bdc7b0  jmp 0x00007B2719BDA493
00007b2719bdc7b5  call 0x00007B27199FF430
00007b2719bdc7ba  jmp 0x00007B2719BDA49D
00007b2719bdc7bf  call 0x00007B2719A0C260
00007b2719bdc7c4  jmp 0x00007B2719BDA4A7
00007b2719bdc7c9  sub rsp, 0x08
00007b2719bdc7cd  push rax
00007b2719bdc7ce  push rcx
00007b2719bdc7cf  push rdx
00007b2719bdc7d0  push rdi
00007b2719bdc7d1  push rsi
00007b2719bdc7d2  push r8
00007b2719bdc7d4  push r9
00007b2719bdc7d6  push r10
00007b2719bdc7d8  push r11
00007b2719bdc7da  sub rsp, 0xF0
00007b2719bdc7e1  vmovaps [rsp], xmm0
00007b2719bdc7e6  vmovaps [rsp+0x10], xmm1
00007b2719bdc7ec  vmovaps [rsp+0x20], xmm2
00007b2719bdc7f2  vmovaps [rsp+0x30], xmm3
00007b2719bdc7f8  vmovaps [rsp+0x40], xmm4
00007b2719bdc7fe  vmovaps [rsp+0x50], xmm5
00007b2719bdc804  vmovaps [rsp+0x60], xmm6
00007b2719bdc80a  vmovaps [rsp+0x70], xmm7
00007b2719bdc810  vmovaps [rsp+0x80], xmm9
00007b2719bdc819  vmovaps [rsp+0x90], xmm10
00007b2719bdc822  vmovaps [rsp+0xA0], xmm11
00007b2719bdc82b  vmovaps [rsp+0xB0], xmm12
00007b2719bdc834  vmovaps [rsp+0xC0], xmm13
00007b2719bdc83d  vmovaps [rsp+0xD0], xmm14
00007b2719bdc846  vmovaps [rsp+0xE0], xmm15
00007b2719bdc84f  sub rsp, 0x40
00007b2719bdc853  lea rdi, [rsp]
00007b2719bdc857  lea rsi, [rsp+0x10]
00007b2719bdc85c  lea rdx, [rsp+0x20]
00007b2719bdc861  lea rcx, [rsp+0x30]
00007b2719bdc866  mov r8d, 0x00
00007b2719bdc86c  lea r9, [r15+0x3A8]
00007b2719bdc873  movaps [rdi], xmm8
00007b2719bdc877  movaps [rsi], xmm7
00007b2719bdc87a  movaps [rdx], xmm4
00007b2719bdc87d  movaps [rcx], xmm12
00007b2719bdc881  mov rax, 0x5A8E6560CA50
00007b2719bdc88b  call rax
00007b2719bdc88d  movaps xmm8, [rsp]
00007b2719bdc892  add rsp, 0x40
00007b2719bdc896  vmovaps xmm0, [rsp]
00007b2719bdc89b  vmovaps xmm1, [rsp+0x10]
00007b2719bdc8a1  vmovaps xmm2, [rsp+0x20]
00007b2719bdc8a7  vmovaps xmm3, [rsp+0x30]
00007b2719bdc8ad  vmovaps xmm4, [rsp+0x40]
00007b2719bdc8b3  vmovaps xmm5, [rsp+0x50]
00007b2719bdc8b9  vmovaps xmm6, [rsp+0x60]
00007b2719bdc8bf  vmovaps xmm7, [rsp+0x70]
00007b2719bdc8c5  vmovaps xmm9, [rsp+0x80]
00007b2719bdc8ce  vmovaps xmm10, [rsp+0x90]
00007b2719bdc8d7  vmovaps xmm11, [rsp+0xA0]
00007b2719bdc8e0  vmovaps xmm12, [rsp+0xB0]
00007b2719bdc8e9  vmovaps xmm13, [rsp+0xC0]
00007b2719bdc8f2  vmovaps xmm14, [rsp+0xD0]
00007b2719bdc8fb  vmovaps xmm15, [rsp+0xE0]
00007b2719bdc904  add rsp, 0xF0
00007b2719bdc90b  pop r11
00007b2719bdc90d  pop r10
00007b2719bdc90f  pop r9
00007b2719bdc911  pop r8
00007b2719bdc913  pop rsi
00007b2719bdc914  pop rdi
00007b2719bdc915  pop rdx
00007b2719bdc916  pop rcx
00007b2719bdc917  pop rax
00007b2719bdc918  add rsp, 0x08
00007b2719bdc91c  jmp 0x00007B2719BDA4D0
00007b2719bdc921  sub rsp, 0x08
00007b2719bdc925  push rax
00007b2719bdc926  push rcx
00007b2719bdc927  push rdx
00007b2719bdc928  push rdi
00007b2719bdc929  push rsi
00007b2719bdc92a  push r8
00007b2719bdc92c  push r9
00007b2719bdc92e  push r10
00007b2719bdc930  push r11
00007b2719bdc932  sub rsp, 0xF0
00007b2719bdc939  vmovaps [rsp], xmm0
00007b2719bdc93e  vmovaps [rsp+0x10], xmm1
00007b2719bdc944  vmovaps [rsp+0x20], xmm2
00007b2719bdc94a  vmovaps [rsp+0x30], xmm3
00007b2719bdc950  vmovaps [rsp+0x40], xmm4
00007b2719bdc956  vmovaps [rsp+0x50], xmm5
00007b2719bdc95c  vmovaps [rsp+0x60], xmm6
00007b2719bdc962  vmovaps [rsp+0x70], xmm8
00007b2719bdc968  vmovaps [rsp+0x80], xmm9
00007b2719bdc971  vmovaps [rsp+0x90], xmm10
00007b2719bdc97a  vmovaps [rsp+0xA0], xmm11
00007b2719bdc983  vmovaps [rsp+0xB0], xmm12
00007b2719bdc98c  vmovaps [rsp+0xC0], xmm13
00007b2719bdc995  vmovaps [rsp+0xD0], xmm14
00007b2719bdc99e  vmovaps [rsp+0xE0], xmm15
00007b2719bdc9a7  sub rsp, 0x40
00007b2719bdc9ab  lea rdi, [rsp]
00007b2719bdc9af  lea rsi, [rsp+0x10]
00007b2719bdc9b4  lea rdx, [rsp+0x20]
00007b2719bdc9b9  lea rcx, [rsp+0x30]
00007b2719bdc9be  mov r8d, 0x00
00007b2719bdc9c4  lea r9, [r15+0x3A8]
00007b2719bdc9cb  movaps [rdi], xmm7
00007b2719bdc9ce  movaps [rsi], xmm9
00007b2719bdc9d2  movaps [rdx], xmm14
00007b2719bdc9d6  movaps [rcx], xmm12
00007b2719bdc9da  mov rax, 0x5A8E6560CA50
00007b2719bdc9e4  call rax
00007b2719bdc9e6  movaps xmm7, [rsp]
00007b2719bdc9ea  add rsp, 0x40
00007b2719bdc9ee  vmovaps xmm0, [rsp]
00007b2719bdc9f3  vmovaps xmm1, [rsp+0x10]
00007b2719bdc9f9  vmovaps xmm2, [rsp+0x20]
00007b2719bdc9ff  vmovaps xmm3, [rsp+0x30]
00007b2719bdca05  vmovaps xmm4, [rsp+0x40]
00007b2719bdca0b  vmovaps xmm5, [rsp+0x50]
00007b2719bdca11  vmovaps xmm6, [rsp+0x60]
00007b2719bdca17  vmovaps xmm8, [rsp+0x70]
00007b2719bdca1d  vmovaps xmm9, [rsp+0x80]
00007b2719bdca26  vmovaps xmm10, [rsp+0x90]
00007b2719bdca2f  vmovaps xmm11, [rsp+0xA0]
00007b2719bdca38  vmovaps xmm12, [rsp+0xB0]
00007b2719bdca41  vmovaps xmm13, [rsp+0xC0]
00007b2719bdca4a  vmovaps xmm14, [rsp+0xD0]
00007b2719bdca53  vmovaps xmm15, [rsp+0xE0]
00007b2719bdca5c  add rsp, 0xF0
00007b2719bdca63  pop r11
00007b2719bdca65  pop r10
00007b2719bdca67  pop r9
00007b2719bdca69  pop r8
00007b2719bdca6b  pop rsi
00007b2719bdca6c  pop rdi
00007b2719bdca6d  pop rdx
00007b2719bdca6e  pop rcx
00007b2719bdca6f  pop rax
00007b2719bdca70  add rsp, 0x08
00007b2719bdca74  jmp 0x00007B2719BDA4F8
00007b2719bdca79  sub rsp, 0x08
00007b2719bdca7d  push rax
00007b2719bdca7e  push rcx
00007b2719bdca7f  push rdx
00007b2719bdca80  push rdi
00007b2719bdca81  push rsi
00007b2719bdca82  push r8
00007b2719bdca84  push r9
00007b2719bdca86  push r10
00007b2719bdca88  push r11
00007b2719bdca8a  sub rsp, 0xF0
00007b2719bdca91  vmovaps [rsp], xmm0
00007b2719bdca96  vmovaps [rsp+0x10], xmm1
00007b2719bdca9c  vmovaps [rsp+0x20], xmm2
00007b2719bdcaa2  vmovaps [rsp+0x30], xmm3
00007b2719bdcaa8  vmovaps [rsp+0x40], xmm4
00007b2719bdcaae  vmovaps [rsp+0x50], xmm5
00007b2719bdcab4  vmovaps [rsp+0x60], xmm6
00007b2719bdcaba  vmovaps [rsp+0x70], xmm7
00007b2719bdcac0  vmovaps [rsp+0x80], xmm8
00007b2719bdcac9  vmovaps [rsp+0x90], xmm9
00007b2719bdcad2  vmovaps [rsp+0xA0], xmm10
00007b2719bdcadb  vmovaps [rsp+0xB0], xmm11
00007b2719bdcae4  vmovaps [rsp+0xC0], xmm13
00007b2719bdcaed  vmovaps [rsp+0xD0], xmm14
00007b2719bdcaf6  vmovaps [rsp+0xE0], xmm15
00007b2719bdcaff  sub rsp, 0x40
00007b2719bdcb03  lea rdi, [rsp]
00007b2719bdcb07  lea rsi, [rsp+0x10]
00007b2719bdcb0c  lea rdx, [rsp+0x20]
00007b2719bdcb11  lea rcx, [rsp+0x30]
00007b2719bdcb16  mov r8d, 0x00
00007b2719bdcb1c  lea r9, [r15+0x3A8]
00007b2719bdcb23  movaps [rdi], xmm12
00007b2719bdcb27  movaps [rsi], xmm11
00007b2719bdcb2b  movaps [rdx], xmm15
00007b2719bdcb2f  movaps [rcx], xmm14
00007b2719bdcb33  mov rax, 0x5A8E6560CA50
00007b2719bdcb3d  call rax
00007b2719bdcb3f  movaps xmm12, [rsp]
00007b2719bdcb44  add rsp, 0x40
00007b2719bdcb48  vmovaps xmm0, [rsp]
00007b2719bdcb4d  vmovaps xmm1, [rsp+0x10]
00007b2719bdcb53  vmovaps xmm2, [rsp+0x20]
00007b2719bdcb59  vmovaps xmm3, [rsp+0x30]
00007b2719bdcb5f  vmovaps xmm4, [rsp+0x40]
00007b2719bdcb65  vmovaps xmm5, [rsp+0x50]
00007b2719bdcb6b  vmovaps xmm6, [rsp+0x60]
00007b2719bdcb71  vmovaps xmm7, [rsp+0x70]
00007b2719bdcb77  vmovaps xmm8, [rsp+0x80]
00007b2719bdcb80  vmovaps xmm9, [rsp+0x90]
00007b2719bdcb89  vmovaps xmm10, [rsp+0xA0]
00007b2719bdcb92  vmovaps xmm11, [rsp+0xB0]
00007b2719bdcb9b  vmovaps xmm13, [rsp+0xC0]
00007b2719bdcba4  vmovaps xmm14, [rsp+0xD0]
00007b2719bdcbad  vmovaps xmm15, [rsp+0xE0]
00007b2719bdcbb6  add rsp, 0xF0
00007b2719bdcbbd  pop r11
00007b2719bdcbbf  pop r10
00007b2719bdcbc1  pop r9
00007b2719bdcbc3  pop r8
00007b2719bdcbc5  pop rsi
00007b2719bdcbc6  pop rdi
00007b2719bdcbc7  pop rdx
00007b2719bdcbc8  pop rcx
00007b2719bdcbc9  pop rax
00007b2719bdcbca  add rsp, 0x08
00007b2719bdcbce  jmp 0x00007B2719BDA521
00007b2719bdcbd3  sub rsp, 0x08
00007b2719bdcbd7  push rax
00007b2719bdcbd8  push rcx
00007b2719bdcbd9  push rdx
00007b2719bdcbda  push rdi
00007b2719bdcbdb  push rsi
00007b2719bdcbdc  push r8
00007b2719bdcbde  push r9
00007b2719bdcbe0  push r10
00007b2719bdcbe2  push r11
00007b2719bdcbe4  sub rsp, 0xF0
00007b2719bdcbeb  vmovaps [rsp], xmm0
00007b2719bdcbf0  vmovaps [rsp+0x10], xmm1
00007b2719bdcbf6  vmovaps [rsp+0x20], xmm2
00007b2719bdcbfc  vmovaps [rsp+0x30], xmm3
00007b2719bdcc02  vmovaps [rsp+0x40], xmm4
00007b2719bdcc08  vmovaps [rsp+0x50], xmm5
00007b2719bdcc0e  vmovaps [rsp+0x60], xmm6
00007b2719bdcc14  vmovaps [rsp+0x70], xmm7
00007b2719bdcc1a  vmovaps [rsp+0x80], xmm8
00007b2719bdcc23  vmovaps [rsp+0x90], xmm9
00007b2719bdcc2c  vmovaps [rsp+0xA0], xmm10
00007b2719bdcc35  vmovaps [rsp+0xB0], xmm12
00007b2719bdcc3e  vmovaps [rsp+0xC0], xmm13
00007b2719bdcc47  vmovaps [rsp+0xD0], xmm14
00007b2719bdcc50  vmovaps [rsp+0xE0], xmm15
00007b2719bdcc59  sub rsp, 0x40
00007b2719bdcc5d  lea rdi, [rsp]
00007b2719bdcc61  lea rsi, [rsp+0x10]
00007b2719bdcc66  lea rdx, [rsp+0x20]
00007b2719bdcc6b  lea rcx, [rsp+0x30]
00007b2719bdcc70  mov r8d, 0x00
00007b2719bdcc76  lea r9, [r15+0x3A8]
00007b2719bdcc7d  movaps [rdi], xmm11
00007b2719bdcc81  movaps [rsi], xmm10
00007b2719bdcc85  movaps [rdx], xmm13
00007b2719bdcc89  movaps [rcx], xmm15
00007b2719bdcc8d  mov rax, 0x5A8E6560CA50
00007b2719bdcc97  call rax
00007b2719bdcc99  movaps xmm11, [rsp]
00007b2719bdcc9e  add rsp, 0x40
00007b2719bdcca2  vmovaps xmm0, [rsp]
00007b2719bdcca7  vmovaps xmm1, [rsp+0x10]
00007b2719bdccad  vmovaps xmm2, [rsp+0x20]
00007b2719bdccb3  vmovaps xmm3, [rsp+0x30]
00007b2719bdccb9  vmovaps xmm4, [rsp+0x40]
00007b2719bdccbf  vmovaps xmm5, [rsp+0x50]
00007b2719bdccc5  vmovaps xmm6, [rsp+0x60]
00007b2719bdcccb  vmovaps xmm7, [rsp+0x70]
00007b2719bdccd1  vmovaps xmm8, [rsp+0x80]
00007b2719bdccda  vmovaps xmm9, [rsp+0x90]
00007b2719bdcce3  vmovaps xmm10, [rsp+0xA0]
00007b2719bdccec  vmovaps xmm12, [rsp+0xB0]
00007b2719bdccf5  vmovaps xmm13, [rsp+0xC0]
00007b2719bdccfe  vmovaps xmm14, [rsp+0xD0]
00007b2719bdcd07  vmovaps xmm15, [rsp+0xE0]
00007b2719bdcd10  add rsp, 0xF0
00007b2719bdcd17  pop r11
00007b2719bdcd19  pop r10
00007b2719bdcd1b  pop r9
00007b2719bdcd1d  pop r8
00007b2719bdcd1f  pop rsi
00007b2719bdcd20  pop rdi
00007b2719bdcd21  pop rdx
00007b2719bdcd22  pop rcx
00007b2719bdcd23  pop rax
00007b2719bdcd24  add rsp, 0x08
00007b2719bdcd28  jmp 0x00007B2719BDA54A
00007b2719bdcd2d  call 0x00007B2719A0E760
00007b2719bdcd32  jmp 0x00007B2719BDA557
00007b2719bdcd37  call 0x00007B2719A0D4E0
00007b2719bdcd3c  jmp 0x00007B2719BDA564
00007b2719bdcd41  sub rsp, 0x08
00007b2719bdcd45  push rax
00007b2719bdcd46  push rcx
00007b2719bdcd47  push rdx
00007b2719bdcd48  push rdi
00007b2719bdcd49  push rsi
00007b2719bdcd4a  push r8
00007b2719bdcd4c  push r9
00007b2719bdcd4e  push r10
00007b2719bdcd50  push r11
00007b2719bdcd52  sub rsp, 0xF0
00007b2719bdcd59  vmovaps [rsp], xmm0
00007b2719bdcd5e  vmovaps [rsp+0x10], xmm1
00007b2719bdcd64  vmovaps [rsp+0x20], xmm2
00007b2719bdcd6a  vmovaps [rsp+0x30], xmm3
00007b2719bdcd70  vmovaps [rsp+0x40], xmm4
00007b2719bdcd76  vmovaps [rsp+0x50], xmm5
00007b2719bdcd7c  vmovaps [rsp+0x60], xmm6
00007b2719bdcd82  vmovaps [rsp+0x70], xmm7
00007b2719bdcd88  vmovaps [rsp+0x80], xmm8
00007b2719bdcd91  vmovaps [rsp+0x90], xmm9
00007b2719bdcd9a  vmovaps [rsp+0xA0], xmm11
00007b2719bdcda3  vmovaps [rsp+0xB0], xmm12
00007b2719bdcdac  vmovaps [rsp+0xC0], xmm13
00007b2719bdcdb5  vmovaps [rsp+0xD0], xmm14
00007b2719bdcdbe  vmovaps [rsp+0xE0], xmm15
00007b2719bdcdc7  sub rsp, 0x40
00007b2719bdcdcb  lea rdi, [rsp]
00007b2719bdcdcf  lea rsi, [rsp+0x10]
00007b2719bdcdd4  lea rdx, [rsp+0x20]
00007b2719bdcdd9  lea rcx, [rsp+0x30]
00007b2719bdcdde  mov r8d, 0x00
00007b2719bdcde4  lea r9, [r15+0x3A8]
00007b2719bdcdeb  movaps [rdi], xmm10
00007b2719bdcdef  movaps [rsi], xmm8
00007b2719bdcdf3  movaps [rdx], xmm1
00007b2719bdcdf6  movaps [rcx], xmm13
00007b2719bdcdfa  mov rax, 0x5A8E6560CA50
00007b2719bdce04  call rax
00007b2719bdce06  movaps xmm10, [rsp]
00007b2719bdce0b  add rsp, 0x40
00007b2719bdce0f  vmovaps xmm0, [rsp]
00007b2719bdce14  vmovaps xmm1, [rsp+0x10]
00007b2719bdce1a  vmovaps xmm2, [rsp+0x20]
00007b2719bdce20  vmovaps xmm3, [rsp+0x30]
00007b2719bdce26  vmovaps xmm4, [rsp+0x40]
00007b2719bdce2c  vmovaps xmm5, [rsp+0x50]
00007b2719bdce32  vmovaps xmm6, [rsp+0x60]
00007b2719bdce38  vmovaps xmm7, [rsp+0x70]
00007b2719bdce3e  vmovaps xmm8, [rsp+0x80]
00007b2719bdce47  vmovaps xmm9, [rsp+0x90]
00007b2719bdce50  vmovaps xmm11, [rsp+0xA0]
00007b2719bdce59  vmovaps xmm12, [rsp+0xB0]
00007b2719bdce62  vmovaps xmm13, [rsp+0xC0]
00007b2719bdce6b  vmovaps xmm14, [rsp+0xD0]
00007b2719bdce74  vmovaps xmm15, [rsp+0xE0]
00007b2719bdce7d  add rsp, 0xF0
00007b2719bdce84  pop r11
00007b2719bdce86  pop r10
00007b2719bdce88  pop r9
00007b2719bdce8a  pop r8
00007b2719bdce8c  pop rsi
00007b2719bdce8d  pop rdi
00007b2719bdce8e  pop rdx
00007b2719bdce8f  pop rcx
00007b2719bdce90  pop rax
00007b2719bdce91  add rsp, 0x08
00007b2719bdce95  jmp 0x00007B2719BDA59A
00007b2719bdce9a  call 0x00007B27199FF430
00007b2719bdce9f  jmp 0x00007B2719BDA5AC
00007b2719bdcea4  sub rsp, 0x08
00007b2719bdcea8  push rax
00007b2719bdcea9  push rcx
00007b2719bdceaa  push rdx
00007b2719bdceab  push rdi
00007b2719bdceac  push rsi
00007b2719bdcead  push r8
00007b2719bdceaf  push r9
00007b2719bdceb1  push r10
00007b2719bdceb3  push r11
00007b2719bdceb5  sub rsp, 0xF0
00007b2719bdcebc  vmovaps [rsp], xmm0
00007b2719bdcec1  vmovaps [rsp+0x10], xmm1
00007b2719bdcec7  vmovaps [rsp+0x20], xmm2
00007b2719bdcecd  vmovaps [rsp+0x30], xmm3
00007b2719bdced3  vmovaps [rsp+0x40], xmm4
00007b2719bdced9  vmovaps [rsp+0x50], xmm5
00007b2719bdcedf  vmovaps [rsp+0x60], xmm6
00007b2719bdcee5  vmovaps [rsp+0x70], xmm7
00007b2719bdceeb  vmovaps [rsp+0x80], xmm8
00007b2719bdcef4  vmovaps [rsp+0x90], xmm10
00007b2719bdcefd  vmovaps [rsp+0xA0], xmm11
00007b2719bdcf06  vmovaps [rsp+0xB0], xmm12
00007b2719bdcf0f  vmovaps [rsp+0xC0], xmm13
00007b2719bdcf18  vmovaps [rsp+0xD0], xmm14
00007b2719bdcf21  vmovaps [rsp+0xE0], xmm15
00007b2719bdcf2a  sub rsp, 0x40
00007b2719bdcf2e  lea rdi, [rsp]
00007b2719bdcf32  lea rsi, [rsp+0x10]
00007b2719bdcf37  lea rdx, [rsp+0x20]
00007b2719bdcf3c  lea rcx, [rsp+0x30]
00007b2719bdcf41  mov r8d, 0x00
00007b2719bdcf47  lea r9, [r15+0x3A8]
00007b2719bdcf4e  movaps [rdi], xmm9
00007b2719bdcf52  movaps [rsi], xmm7
00007b2719bdcf55  movaps [rdx], xmm14
00007b2719bdcf59  movaps [rcx], xmm13
00007b2719bdcf5d  mov rax, 0x5A8E6560CA50
00007b2719bdcf67  call rax
00007b2719bdcf69  movaps xmm9, [rsp]
00007b2719bdcf6e  add rsp, 0x40
00007b2719bdcf72  vmovaps xmm0, [rsp]
00007b2719bdcf77  vmovaps xmm1, [rsp+0x10]
00007b2719bdcf7d  vmovaps xmm2, [rsp+0x20]
00007b2719bdcf83  vmovaps xmm3, [rsp+0x30]
00007b2719bdcf89  vmovaps xmm4, [rsp+0x40]
00007b2719bdcf8f  vmovaps xmm5, [rsp+0x50]
00007b2719bdcf95  vmovaps xmm6, [rsp+0x60]
00007b2719bdcf9b  vmovaps xmm7, [rsp+0x70]
00007b2719bdcfa1  vmovaps xmm8, [rsp+0x80]
00007b2719bdcfaa  vmovaps xmm10, [rsp+0x90]
00007b2719bdcfb3  vmovaps xmm11, [rsp+0xA0]
00007b2719bdcfbc  vmovaps xmm12, [rsp+0xB0]
00007b2719bdcfc5  vmovaps xmm13, [rsp+0xC0]
00007b2719bdcfce  vmovaps xmm14, [rsp+0xD0]
00007b2719bdcfd7  vmovaps xmm15, [rsp+0xE0]
00007b2719bdcfe0  add rsp, 0xF0
00007b2719bdcfe7  pop r11
00007b2719bdcfe9  pop r10
00007b2719bdcfeb  pop r9
00007b2719bdcfed  pop r8
00007b2719bdcfef  pop rsi
00007b2719bdcff0  pop rdi
00007b2719bdcff1  pop rdx
00007b2719bdcff2  pop rcx
00007b2719bdcff3  pop rax
00007b2719bdcff4  add rsp, 0x08
00007b2719bdcff8  jmp 0x00007B2719BDA5DA
00007b2719bdcffd  sub rsp, 0x08
00007b2719bdd001  push rax
00007b2719bdd002  push rcx
00007b2719bdd003  push rdx
00007b2719bdd004  push rdi
00007b2719bdd005  push rsi
00007b2719bdd006  push r8
00007b2719bdd008  push r9
00007b2719bdd00a  push r10
00007b2719bdd00c  push r11
00007b2719bdd00e  sub rsp, 0xF0
00007b2719bdd015  vmovaps [rsp], xmm0
00007b2719bdd01a  vmovaps [rsp+0x10], xmm1
00007b2719bdd020  vmovaps [rsp+0x20], xmm2
00007b2719bdd026  vmovaps [rsp+0x30], xmm3
00007b2719bdd02c  vmovaps [rsp+0x40], xmm4
00007b2719bdd032  vmovaps [rsp+0x50], xmm5
00007b2719bdd038  vmovaps [rsp+0x60], xmm6
00007b2719bdd03e  vmovaps [rsp+0x70], xmm7
00007b2719bdd044  vmovaps [rsp+0x80], xmm8
00007b2719bdd04d  vmovaps [rsp+0x90], xmm9
00007b2719bdd056  vmovaps [rsp+0xA0], xmm10
00007b2719bdd05f  vmovaps [rsp+0xB0], xmm11
00007b2719bdd068  vmovaps [rsp+0xC0], xmm12
00007b2719bdd071  vmovaps [rsp+0xD0], xmm14
00007b2719bdd07a  vmovaps [rsp+0xE0], xmm15
00007b2719bdd083  sub rsp, 0x40
00007b2719bdd087  lea rdi, [rsp]
00007b2719bdd08b  lea rsi, [rsp+0x10]
00007b2719bdd090  lea rdx, [rsp+0x20]
00007b2719bdd095  lea rcx, [rsp+0x30]
00007b2719bdd09a  mov r8d, 0x00
00007b2719bdd0a0  lea r9, [r15+0x3A8]
00007b2719bdd0a7  movaps [rdi], xmm13
00007b2719bdd0ab  movaps [rsi], xmm12
00007b2719bdd0af  movaps [rdx], xmm15
00007b2719bdd0b3  movaps [rcx], xmm14
00007b2719bdd0b7  mov rax, 0x5A8E6560CA50
00007b2719bdd0c1  call rax
00007b2719bdd0c3  movaps xmm13, [rsp]
00007b2719bdd0c8  add rsp, 0x40
00007b2719bdd0cc  vmovaps xmm0, [rsp]
00007b2719bdd0d1  vmovaps xmm1, [rsp+0x10]
00007b2719bdd0d7  vmovaps xmm2, [rsp+0x20]
00007b2719bdd0dd  vmovaps xmm3, [rsp+0x30]
00007b2719bdd0e3  vmovaps xmm4, [rsp+0x40]
00007b2719bdd0e9  vmovaps xmm5, [rsp+0x50]
00007b2719bdd0ef  vmovaps xmm6, [rsp+0x60]
00007b2719bdd0f5  vmovaps xmm7, [rsp+0x70]
00007b2719bdd0fb  vmovaps xmm8, [rsp+0x80]
00007b2719bdd104  vmovaps xmm9, [rsp+0x90]
00007b2719bdd10d  vmovaps xmm10, [rsp+0xA0]
00007b2719bdd116  vmovaps xmm11, [rsp+0xB0]
00007b2719bdd11f  vmovaps xmm12, [rsp+0xC0]
00007b2719bdd128  vmovaps xmm14, [rsp+0xD0]
00007b2719bdd131  vmovaps xmm15, [rsp+0xE0]
00007b2719bdd13a  add rsp, 0xF0
00007b2719bdd141  pop r11
00007b2719bdd143  pop r10
00007b2719bdd145  pop r9
00007b2719bdd147  pop r8
00007b2719bdd149  pop rsi
00007b2719bdd14a  pop rdi
00007b2719bdd14b  pop rdx
00007b2719bdd14c  pop rcx
00007b2719bdd14d  pop rax
00007b2719bdd14e  add rsp, 0x08
00007b2719bdd152  jmp 0x00007B2719BDA608
00007b2719bdd157  sub rsp, 0x08
00007b2719bdd15b  push rax
00007b2719bdd15c  push rcx
00007b2719bdd15d  push rdx
00007b2719bdd15e  push rdi
00007b2719bdd15f  push rsi
00007b2719bdd160  push r8
00007b2719bdd162  push r9
00007b2719bdd164  push r10
00007b2719bdd166  push r11
00007b2719bdd168  sub rsp, 0xF0
00007b2719bdd16f  vmovaps [rsp], xmm0
00007b2719bdd174  vmovaps [rsp+0x10], xmm1
00007b2719bdd17a  vmovaps [rsp+0x20], xmm2
00007b2719bdd180  vmovaps [rsp+0x30], xmm3
00007b2719bdd186  vmovaps [rsp+0x40], xmm4
00007b2719bdd18c  vmovaps [rsp+0x50], xmm5
00007b2719bdd192  vmovaps [rsp+0x60], xmm6
00007b2719bdd198  vmovaps [rsp+0x70], xmm7
00007b2719bdd19e  vmovaps [rsp+0x80], xmm8
00007b2719bdd1a7  vmovaps [rsp+0x90], xmm9
00007b2719bdd1b0  vmovaps [rsp+0xA0], xmm10
00007b2719bdd1b9  vmovaps [rsp+0xB0], xmm11
00007b2719bdd1c2  vmovaps [rsp+0xC0], xmm12
00007b2719bdd1cb  vmovaps [rsp+0xD0], xmm13
00007b2719bdd1d4  vmovaps [rsp+0xE0], xmm15
00007b2719bdd1dd  sub rsp, 0x40
00007b2719bdd1e1  lea rdi, [rsp]
00007b2719bdd1e5  lea rsi, [rsp+0x10]
00007b2719bdd1ea  lea rdx, [rsp+0x20]
00007b2719bdd1ef  lea rcx, [rsp+0x30]
00007b2719bdd1f4  mov r8d, 0x00
00007b2719bdd1fa  lea r9, [r15+0x3A8]
00007b2719bdd201  movaps [rdi], xmm14
00007b2719bdd205  movaps [rsi], xmm11
00007b2719bdd209  movaps [rdx], xmm1
00007b2719bdd20c  movaps [rcx], xmm15
00007b2719bdd210  mov rax, 0x5A8E6560CA50
00007b2719bdd21a  call rax
00007b2719bdd21c  movaps xmm14, [rsp]
00007b2719bdd221  add rsp, 0x40
00007b2719bdd225  vmovaps xmm0, [rsp]
00007b2719bdd22a  vmovaps xmm1, [rsp+0x10]
00007b2719bdd230  vmovaps xmm2, [rsp+0x20]
00007b2719bdd236  vmovaps xmm3, [rsp+0x30]
00007b2719bdd23c  vmovaps xmm4, [rsp+0x40]
00007b2719bdd242  vmovaps xmm5, [rsp+0x50]
00007b2719bdd248  vmovaps xmm6, [rsp+0x60]
00007b2719bdd24e  vmovaps xmm7, [rsp+0x70]
00007b2719bdd254  vmovaps xmm8, [rsp+0x80]
00007b2719bdd25d  vmovaps xmm9, [rsp+0x90]
00007b2719bdd266  vmovaps xmm10, [rsp+0xA0]
00007b2719bdd26f  vmovaps xmm11, [rsp+0xB0]
00007b2719bdd278  vmovaps xmm12, [rsp+0xC0]
00007b2719bdd281  vmovaps xmm13, [rsp+0xD0]
00007b2719bdd28a  vmovaps xmm15, [rsp+0xE0]
00007b2719bdd293  add rsp, 0xF0
00007b2719bdd29a  pop r11
00007b2719bdd29c  pop r10
00007b2719bdd29e  pop r9
00007b2719bdd2a0  pop r8
00007b2719bdd2a2  pop rsi
00007b2719bdd2a3  pop rdi
00007b2719bdd2a4  pop rdx
00007b2719bdd2a5  pop rcx
00007b2719bdd2a6  pop rax
00007b2719bdd2a7  add rsp, 0x08
00007b2719bdd2ab  jmp 0x00007B2719BDA636
00007b2719bdd2b0  call 0x00007B2719A079B0
00007b2719bdd2b5  jmp 0x00007B2719BDA64C
00007b2719bdd2ba  call 0x00007B2719AE3440
00007b2719bdd2bf  jmp 0x00007B2719BDA656
00007b2719bdd2c4  call 0x00007B2719ADFCE0
00007b2719bdd2c9  jmp 0x00007B2719BDA660
00007b2719bdd2ce  call 0x00007B2719AE46C0
00007b2719bdd2d3  jmp 0x00007B2719BDA66A
00007b2719bdd2d8  int3
00007b2719bdd2d9  nop [rax], eax
00007b2719bdd2e0  mov qword ptr [r15+0x40], 0x430000
00007b2719bdd2e8  mov eax, 0x430C50
00007b2719bdd2ed  mov r14, [r13+rax*1]
00007b2719bdd2f2  movq xmm1, r14
00007b2719bdd2f7  mov rax, [r15+0x50]
00007b2719bdd2fb  movups xmm15, [r13+rax*1]
00007b2719bdd301  movaps [r15+0x120], xmm15
00007b2719bdd309  mov qword ptr [r15+0x48], 0x10
00007b2719bdd311  xor eax, eax
00007b2719bdd313  mov r14d, 0x10
00007b2719bdd319  mov r12d, 0x200
00007b2719bdd31f  cmp r14, r12
00007b2719bdd322  cmc
00007b2719bdd323  lahf
00007b2719bdd324  seto al
00007b2719bdd327  mov [r15+0x108], eax
00007b2719bdd32e  pextrq rax, xmm15, 0x01
00007b2719bdd335  movq xmm14, rax
00007b2719bdd33a  movaps [r15+0x130], xmm14
00007b2719bdd342  movq rax, xmm1
00007b2719bdd347  movq r14, xmm15
00007b2719bdd34c  vmovq xmm1, rax
00007b2719bdd351  vmovq xmm15, r14
00007b2719bdd356  movaps xmm13, xmm1
00007b2719bdd35a  addsd xmm13, xmm15
00007b2719bdd35f  ucomisd xmm13, xmm13
00007b2719bdd364  jp 0x00007B2719BDD423
00007b2719bdd36a  movq xmm13, xmm13
00007b2719bdd36f  movq rax, xmm13
00007b2719bdd374  movq r14, xmm14
00007b2719bdd379  vmovq xmm1, rax
00007b2719bdd37e  vmovq xmm15, r14
00007b2719bdd383  movaps xmm14, xmm1
00007b2719bdd387  addsd xmm14, xmm15
00007b2719bdd38c  ucomisd xmm14, xmm14
00007b2719bdd391  jp 0x00007B2719BDD46B
00007b2719bdd397  movq xmm14, xmm14
00007b2719bdd39c  movaps [r15+0x110], xmm14
00007b2719bdd3a4  mov eax, [r15+0x108]
00007b2719bdd3ab  sahf
00007b2719bdd3ac  jnz 0x00007B2719BDD3DE
00007b2719bdd3ae  cmp dword ptr [r15+0x318], 0x00
00007b2719bdd3b6  jz 0x00007B2719BDD680
00007b2719bdd3bc  nop [rax+rax*1], ax
00007b2719bdd3c5  nop [rax+rax*1], eax
00007b2719bdd3cd  mov eax, 0x410698
00007b2719bdd3d2  mov [r15+0x100], rax
00007b2719bdd3d9  jmp 0x00007B27199FE110
00007b2719bdd3de  cmp dword ptr [r15+0x318], 0x00
00007b2719bdd3e6  jz 0x00007B2719BDD4C0
00007b2719bdd3ec  nop [rax+rax*1], ax
00007b2719bdd3f5  nop [rax+rax*1], eax
00007b2719bdd3fd  mov eax, 0x41067C
00007b2719bdd402  mov [r15+0x100], rax
00007b2719bdd409  jmp 0x00007B27199FE110
00007b2719bdd40e  int3
00007b2719bdd40f  call 0x00007B2719A0DC20
00007b2719bdd414  jmp 0x00007B2719BDD2F2
00007b2719bdd419  call 0x00007B2719A0E760
00007b2719bdd41e  jmp 0x00007B2719BDD301
00007b2719bdd423  ucomisd xmm1, xmm15
00007b2719bdd428  jp 0x00007B2719BDD437
00007b2719bdd42a  movaps xmm13, [0x00007B27197FE060]
00007b2719bdd432  jmp 0x00007B2719BDD36A
00007b2719bdd437  vxorps xmm0, xmm1, xmm15
00007b2719bdd43c  pextrw eax, xmm0, 0x03
00007b2719bdd441  and eax, 0x7FF8
00007b2719bdd446  cmp eax, 0x08
00007b2719bdd449  jnz 0x00007B2719BDD36A
00007b2719bdd44f  movq rax, xmm15
00007b2719bdd454  shl rax, 0x0D
00007b2719bdd458  jbe 0x00007B2719BDD36A
00007b2719bdd45e  vorps xmm13, xmm15, [0x00007B27197FE070]
00007b2719bdd466  jmp 0x00007B2719BDD36A
00007b2719bdd46b  ucomisd xmm1, xmm15
00007b2719bdd470  jp 0x00007B2719BDD47F
00007b2719bdd472  movaps xmm14, [0x00007B27197FE060]
00007b2719bdd47a  jmp 0x00007B2719BDD397
00007b2719bdd47f  vxorps xmm0, xmm1, xmm15
00007b2719bdd484  pextrw eax, xmm0, 0x03
00007b2719bdd489  and eax, 0x7FF8
00007b2719bdd48e  cmp eax, 0x08
00007b2719bdd491  jnz 0x00007B2719BDD397
00007b2719bdd497  movq rax, xmm15
00007b2719bdd49c  shl rax, 0x0D
00007b2719bdd4a0  jbe 0x00007B2719BDD397
00007b2719bdd4a6  vorps xmm14, xmm15, [0x00007B27197FE070]
00007b2719bdd4ae  jmp 0x00007B2719BDD397
00007b2719bdd4b3  int3
00007b2719bdd4b4  nop [rax+rax*1], ax
00007b2719bdd4bd  nop [rax], eax
00007b2719bdd4c0  mov rax, [r15+0x48]
00007b2719bdd4c4  mov r14, [r15+0x50]
00007b2719bdd4c8  lea r12, [r14+rax*1]
00007b2719bdd4cc  movups xmm1, [r13+r12*1]
00007b2719bdd4d2  movaps [r15+0x120], xmm1
00007b2719bdd4da  lea r14, [rax+0x10]
00007b2719bdd4de  mov [r15+0x48], r14
00007b2719bdd4e2  xor eax, eax
00007b2719bdd4e4  mov r12d, 0x200
00007b2719bdd4ea  cmp r14, r12
00007b2719bdd4ed  cmc
00007b2719bdd4ee  lahf
00007b2719bdd4ef  seto al
00007b2719bdd4f2  mov [r15+0x108], eax
00007b2719bdd4f9  pextrq rax, xmm1, 0x01
00007b2719bdd500  movq xmm15, rax
00007b2719bdd505  movaps [r15+0x130], xmm15
00007b2719bdd50d  movaps xmm14, [r15+0x110]
00007b2719bdd515  movq rax, xmm14
00007b2719bdd51a  movq r14, xmm1
00007b2719bdd51f  vmovq xmm1, rax
00007b2719bdd524  vmovq xmm14, r14
00007b2719bdd529  movaps xmm13, xmm1
00007b2719bdd52d  addsd xmm13, xmm14
00007b2719bdd532  ucomisd xmm13, xmm13
00007b2719bdd537  jp 0x00007B2719BDD5EC
00007b2719bdd53d  movq xmm13, xmm13
00007b2719bdd542  movq rax, xmm13
00007b2719bdd547  movq r14, xmm15
00007b2719bdd54c  vmovq xmm1, rax
00007b2719bdd551  vmovq xmm15, r14
00007b2719bdd556  movaps xmm14, xmm1
00007b2719bdd55a  addsd xmm14, xmm15
00007b2719bdd55f  ucomisd xmm14, xmm14
00007b2719bdd564  jp 0x00007B2719BDD634
00007b2719bdd56a  movq xmm14, xmm14
00007b2719bdd56f  movaps [r15+0x110], xmm14
00007b2719bdd577  mov eax, [r15+0x108]
00007b2719bdd57e  sahf
00007b2719bdd57f  jnz 0x00007B2719BDD5B1
00007b2719bdd581  cmp dword ptr [r15+0x318], 0x00
00007b2719bdd589  jz 0x00007B2719BDD680
00007b2719bdd58f  nop [rax+rax*1], ax
00007b2719bdd598  nop [rax+rax*1], eax
00007b2719bdd5a0  mov eax, 0x410698
00007b2719bdd5a5  mov [r15+0x100], rax
00007b2719bdd5ac  jmp 0x00007B27199FE110
00007b2719bdd5b1  cmp dword ptr [r15+0x318], 0x00
00007b2719bdd5b9  jz 0x00007B2719BDD4C0
00007b2719bdd5bf  nop [rax+rax*1], ax
00007b2719bdd5c8  nop [rax+rax*1], eax
00007b2719bdd5d0  mov eax, 0x41067C
00007b2719bdd5d5  mov [r15+0x100], rax
00007b2719bdd5dc  jmp 0x00007B27199FE110
00007b2719bdd5e1  int3
00007b2719bdd5e2  call 0x00007B2719AB52F0
00007b2719bdd5e7  jmp 0x00007B2719BDD4D2
00007b2719bdd5ec  ucomisd xmm1, xmm14
00007b2719bdd5f1  jp 0x00007B2719BDD600
00007b2719bdd5f3  movaps xmm13, [0x00007B27197FE060]
00007b2719bdd5fb  jmp 0x00007B2719BDD53D
00007b2719bdd600  vxorps xmm0, xmm1, xmm14
00007b2719bdd605  pextrw eax, xmm0, 0x03
00007b2719bdd60a  and eax, 0x7FF8
00007b2719bdd60f  cmp eax, 0x08
00007b2719bdd612  jnz 0x00007B2719BDD53D
00007b2719bdd618  movq rax, xmm14
00007b2719bdd61d  shl rax, 0x0D
00007b2719bdd621  jbe 0x00007B2719BDD53D
00007b2719bdd627  vorps xmm13, xmm14, [0x00007B27197FE070]
00007b2719bdd62f  jmp 0x00007B2719BDD53D
00007b2719bdd634  ucomisd xmm1, xmm15
00007b2719bdd639  jp 0x00007B2719BDD648
00007b2719bdd63b  movaps xmm14, [0x00007B27197FE060]
00007b2719bdd643  jmp 0x00007B2719BDD56A
00007b2719bdd648  vxorps xmm0, xmm1, xmm15
00007b2719bdd64d  pextrw eax, xmm0, 0x03
00007b2719bdd652  and eax, 0x7FF8
00007b2719bdd657  cmp eax, 0x08
00007b2719bdd65a  jnz 0x00007B2719BDD56A
00007b2719bdd660  movq rax, xmm15
00007b2719bdd665  shl rax, 0x0D
00007b2719bdd669  jbe 0x00007B2719BDD56A
00007b2719bdd66f  vorps xmm14, xmm15, [0x00007B27197FE070]
00007b2719bdd677  jmp 0x00007B2719BDD56A
00007b2719bdd67c  int3
00007b2719bdd67d  nop [rax], eax
00007b2719bdd680  mov rax, [r15+0xF8]
00007b2719bdd687  lea r14, [rax+0x1A0]
00007b2719bdd68e  mov r12, [r13+r14*1]
00007b2719bdd693  lea r14, [rax+0x1A8]
00007b2719bdd69a  mov r11, [r13+r14*1]
00007b2719bdd69f  mov [r15+0xA0], r12
00007b2719bdd6a6  mov [r15+0x98], r11
00007b2719bdd6ad  mov r14, [r15+0x40]
00007b2719bdd6b1  lea r12, [r14+0xC50]
00007b2719bdd6b8  movaps xmm1, [r15+0x110]
00007b2719bdd6c0  movq r14, xmm1
00007b2719bdd6c5  mov [r13+r12*1], r14
00007b2719bdd6ca  lea r14, [rax+0x190]
00007b2719bdd6d1  mov r12, [r13+r14*1]
00007b2719bdd6d6  lea r14, [rax+0x198]
00007b2719bdd6dd  mov r11, [r13+r14*1]
00007b2719bdd6e2  mov [r15+0xE8], r12
00007b2719bdd6e9  mov [r15+0xF0], r11
00007b2719bdd6f0  lea r14, [rax+0x180]
00007b2719bdd6f7  mov r12, [r13+r14*1]
00007b2719bdd6fc  lea r14, [rax+0x188]
00007b2719bdd703  mov r10, [r13+r14*1]
00007b2719bdd708  movq xmm1, r12
00007b2719bdd70d  movq xmm15, r10
00007b2719bdd712  movq xmm1, xmm1
00007b2719bdd716  movq xmm1, xmm1
00007b2719bdd71a  movaps [r15+0x1A0], xmm1
00007b2719bdd722  movq xmm15, xmm15
00007b2719bdd727  movq xmm15, xmm15
00007b2719bdd72c  movaps [r15+0x190], xmm15
00007b2719bdd734  lea r14, [rax+0x170]
00007b2719bdd73b  mov r12, [r13+r14*1]
00007b2719bdd740  lea r14, [rax+0x178]
00007b2719bdd747  mov r10, [r13+r14*1]
00007b2719bdd74c  movq xmm1, r12
00007b2719bdd751  movq xmm15, r10
00007b2719bdd756  movq xmm1, xmm1
00007b2719bdd75a  movq xmm1, xmm1
00007b2719bdd75e  movaps [r15+0x1C0], xmm1
00007b2719bdd766  movq xmm15, xmm15
00007b2719bdd76b  movq xmm15, xmm15
00007b2719bdd770  movaps [r15+0x1B0], xmm15
00007b2719bdd778  lea r14, [rax+0x160]
00007b2719bdd77f  mov r12, [r13+r14*1]
00007b2719bdd784  lea r14, [rax+0x168]
00007b2719bdd78b  mov r10, [r13+r14*1]
00007b2719bdd790  movq xmm1, r12
00007b2719bdd795  movq xmm15, r10
00007b2719bdd79a  movq xmm1, xmm1
00007b2719bdd79e  movq xmm1, xmm1
00007b2719bdd7a2  movaps [r15+0x1E0], xmm1
00007b2719bdd7aa  movq xmm15, xmm15
00007b2719bdd7af  movq xmm15, xmm15
00007b2719bdd7b4  movaps [r15+0x1D0], xmm15
00007b2719bdd7bc  lea r14, [rax+0x150]
00007b2719bdd7c3  mov r12, [r13+r14*1]
00007b2719bdd7c8  lea r14, [rax+0x158]
00007b2719bdd7cf  mov r10, [r13+r14*1]
00007b2719bdd7d4  movq xmm1, r12
00007b2719bdd7d9  movq xmm15, r10
00007b2719bdd7de  movq xmm1, xmm1
00007b2719bdd7e2  movq xmm1, xmm1
00007b2719bdd7e6  movaps [r15+0x200], xmm1
00007b2719bdd7ee  movq xmm15, xmm15
00007b2719bdd7f3  movq xmm15, xmm15
00007b2719bdd7f8  movaps [r15+0x1F0], xmm15
00007b2719bdd800  lea r14, [rax+0x1B0]
00007b2719bdd807  mov [r15+0xF8], r14
00007b2719bdd80e  mov [r15+0x100], r11
00007b2719bdd815  jmp 0x00007B2719BCE5C0
00007b2719bdd81a  int3
00007b2719bdd81b  call 0x00007B2719AE27E0
00007b2719bdd820  jmp 0x00007B2719BDD693
00007b2719bdd825  call 0x00007B2719AE1570
00007b2719bdd82a  jmp 0x00007B2719BDD69F
00007b2719bdd82f  call 0x00007B2719AC3FE0
00007b2719bdd834  jmp 0x00007B2719BDD6CA
00007b2719bdd839  call 0x00007B2719AE27E0
00007b2719bdd83e  jmp 0x00007B2719BDD6D6
00007b2719bdd843  call 0x00007B2719AE1570
00007b2719bdd848  jmp 0x00007B2719BDD6E2
00007b2719bdd84d  call 0x00007B2719AE27E0
00007b2719bdd852  jmp 0x00007B2719BDD6FC
00007b2719bdd857  call 0x00007B2719AE0300
00007b2719bdd85c  jmp 0x00007B2719BDD708
00007b2719bdd861  call 0x00007B2719AE27E0
00007b2719bdd866  jmp 0x00007B2719BDD740
00007b2719bdd86b  call 0x00007B2719AE0300
00007b2719bdd870  jmp 0x00007B2719BDD74C
00007b2719bdd875  call 0x00007B2719AE27E0
00007b2719bdd87a  jmp 0x00007B2719BDD784
00007b2719bdd87f  call 0x00007B2719AE0300
00007b2719bdd884  jmp 0x00007B2719BDD790
00007b2719bdd889  call 0x00007B2719AE27E0
00007b2719bdd88e  jmp 0x00007B2719BDD7C8
00007b2719bdd893  call 0x00007B2719AE0300
00007b2719bdd898  jmp 0x00007B2719BDD7D4
00007b2719bdd89d  int3
00007b2719bdd89e  nop
00007b2719bdd8a0  mov qword ptr [r15+0x100], 0x04
00007b2719bdd8ab  mov esi, 0x00
00007b2719bdd8b0  mov edx, 0x09
00007b2719bdd8b5  mov rdi, 0x7FFC84B3C8B0
00007b2719bdd8bf  mov rax, 0x5A8E6549F970
00007b2719bdd8c9  call rax
00007b2719bdd8cb  cmp dword ptr [r15+0x318], 0x00
00007b2719bdd8d3  jnz 0x00007B27199FE110
00007b2719bdd8d9  jmp 0x00007B27199FE0A0
00007b2719bdd8de  int3
00007b2719bdd8df  int3
