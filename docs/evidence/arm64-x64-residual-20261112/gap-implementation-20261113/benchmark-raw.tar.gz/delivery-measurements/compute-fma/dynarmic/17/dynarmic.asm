00007ed4111ce69b  nop [rax+rax*1], eax
00007ed4111ce6a0  mov rax, [r15+0xF8]
00007ed4111ce6a7  lea r14, [rax-0x1B0]
00007ed4111ce6ae  mov [r15+0xF8], r14
00007ed4111ce6b5  lea rax, [r14+0x1A0]
00007ed4111ce6bc  mov r12, [r15+0xA0]
00007ed4111ce6c3  mov r11, [r15+0x98]
00007ed4111ce6ca  mov [r13+rax*1], r12
00007ed4111ce6cf  lea rax, [r14+0x1A8]
00007ed4111ce6d6  mov [r13+rax*1], r11
00007ed4111ce6db  mov eax, 0x420A30
00007ed4111ce6e0  movups xmm1, [r13+rax*1]
00007ed4111ce6e6  mov eax, 0x4209C0
00007ed4111ce6eb  movups xmm15, [r13+rax*1]
00007ed4111ce6f1  mov eax, 0x420A50
00007ed4111ce6f6  movups xmm14, [r13+rax*1]
00007ed4111ce6fc  mov eax, 0x4209F0
00007ed4111ce701  movups xmm13, [r13+rax*1]
00007ed4111ce707  mov qword ptr [r15+0x98], 0x430C60
00007ed4111ce712  mov eax, 0x420A60
00007ed4111ce717  movups xmm12, [r13+rax*1]
00007ed4111ce71d  mov eax, 0x430C60
00007ed4111ce722  movups [r13+rax*1], xmm1
00007ed4111ce728  mov eax, 0x430C70
00007ed4111ce72d  movups [r13+rax*1], xmm15
00007ed4111ce733  mov eax, 0x430C80
00007ed4111ce738  movups [r13+rax*1], xmm14
00007ed4111ce73e  mov eax, 0x430C90
00007ed4111ce743  movups [r13+rax*1], xmm13
00007ed4111ce749  mov eax, 0x4209B0
00007ed4111ce74e  movups xmm14, [r13+rax*1]
00007ed4111ce754  mov eax, 0x4209A0
00007ed4111ce759  movups xmm13, [r13+rax*1]
00007ed4111ce75f  mov eax, 0x430D60
00007ed4111ce764  movups [r13+rax*1], xmm1
00007ed4111ce76a  mov eax, 0x430D70
00007ed4111ce76f  movups [r13+rax*1], xmm15
00007ed4111ce775  mov eax, 0x430CA0
00007ed4111ce77a  movups [r13+rax*1], xmm12
00007ed4111ce780  mov eax, 0x430CB0
00007ed4111ce785  movups [r13+rax*1], xmm14
00007ed4111ce78b  mov eax, 0x420990
00007ed4111ce790  movups xmm1, [r13+rax*1]
00007ed4111ce796  mov eax, 0x420A00
00007ed4111ce79b  movups xmm15, [r13+rax*1]
00007ed4111ce7a1  mov eax, 0x430CC0
00007ed4111ce7a6  movups [r13+rax*1], xmm13
00007ed4111ce7ac  mov eax, 0x430CD0
00007ed4111ce7b1  movups [r13+rax*1], xmm1
00007ed4111ce7b7  mov eax, 0x420A10
00007ed4111ce7bc  movups xmm1, [r13+rax*1]
00007ed4111ce7c2  mov eax, 0x4209E0
00007ed4111ce7c7  movups xmm14, [r13+rax*1]
00007ed4111ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007ed4111ce7d5  mov eax, 0x430CE0
00007ed4111ce7da  movups [r13+rax*1], xmm15
00007ed4111ce7e0  mov eax, 0x430CF0
00007ed4111ce7e5  movups [r13+rax*1], xmm1
00007ed4111ce7eb  mov eax, 0x420A80
00007ed4111ce7f0  movups xmm1, [r13+rax*1]
00007ed4111ce7f6  mov eax, 0x420A90
00007ed4111ce7fb  movups xmm15, [r13+rax*1]
00007ed4111ce801  movaps [r15+0x150], xmm15
00007ed4111ce809  mov qword ptr [r15+0xA0], 0x3E8
00007ed4111ce814  mov eax, 0x430D00
00007ed4111ce819  movups [r13+rax*1], xmm14
00007ed4111ce81f  mov eax, 0x430D10
00007ed4111ce824  movups [r13+rax*1], xmm1
00007ed4111ce82a  mov eax, 0x420A70
00007ed4111ce82f  movups xmm1, [r13+rax*1]
00007ed4111ce835  mov eax, 0x420A20
00007ed4111ce83a  movups xmm14, [r13+rax*1]
00007ed4111ce840  movaps [r15+0x140], xmm14
00007ed4111ce848  lea rax, [r14+0x150]
00007ed4111ce84f  movq xmm13, qword ptr [r15+0x200]
00007ed4111ce858  movq xmm12, qword ptr [r15+0x1F0]
00007ed4111ce861  movq r12, xmm13
00007ed4111ce866  movq r11, xmm12
00007ed4111ce86b  mov [r13+rax*1], r12
00007ed4111ce870  lea rax, [r14+0x158]
00007ed4111ce877  mov [r13+rax*1], r11
00007ed4111ce87c  mov eax, 0x430D20
00007ed4111ce881  movups [r13+rax*1], xmm15
00007ed4111ce887  mov eax, 0x430D30
00007ed4111ce88c  movups [r13+rax*1], xmm1
00007ed4111ce892  mov eax, 0x420A40
00007ed4111ce897  movups xmm1, [r13+rax*1]
00007ed4111ce89d  mov eax, 0x420AA8
00007ed4111ce8a2  mov r12, [r13+rax*1]
00007ed4111ce8a7  movq xmm15, r12
00007ed4111ce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007ed4111ce8b4  mov eax, 0x430D40
00007ed4111ce8b9  movups [r13+rax*1], xmm14
00007ed4111ce8bf  mov eax, 0x430D50
00007ed4111ce8c4  movups [r13+rax*1], xmm1
00007ed4111ce8ca  mov eax, 0x420B10
00007ed4111ce8cf  movups xmm1, [r13+rax*1]
00007ed4111ce8d5  movq rax, xmm15
00007ed4111ce8da  mov r12d, 0x430D80
00007ed4111ce8e0  mov [r13+r12*1], rax
00007ed4111ce8e5  mov eax, 0x420AF0
00007ed4111ce8ea  movups xmm15, [r13+rax*1]
00007ed4111ce8f0  mov eax, 0x420B00
00007ed4111ce8f5  movups xmm14, [r13+rax*1]
00007ed4111ce8fb  lea rax, [r14+0x130]
00007ed4111ce902  movups [r13+rax*1], xmm1
00007ed4111ce908  lea rax, [r14+0x160]
00007ed4111ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007ed4111ce918  movq xmm13, qword ptr [r15+0x1D0]
00007ed4111ce921  movq r12, xmm1
00007ed4111ce926  movq r11, xmm13
00007ed4111ce92b  mov [r13+rax*1], r12
00007ed4111ce930  lea rax, [r14+0x168]
00007ed4111ce937  mov [r13+rax*1], r11
00007ed4111ce93c  lea rax, [r14+0x110]
00007ed4111ce943  movups [r13+rax*1], xmm15
00007ed4111ce949  lea rax, [r14+0x120]
00007ed4111ce950  movups [r13+rax*1], xmm14
00007ed4111ce956  mov eax, 0x420AB0
00007ed4111ce95b  movups xmm1, [r13+rax*1]
00007ed4111ce961  mov eax, 0x420AC0
00007ed4111ce966  movups xmm15, [r13+rax*1]
00007ed4111ce96c  movaps [r15+0x120], xmm15
00007ed4111ce974  lea rax, [r14+0x170]
00007ed4111ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007ed4111ce984  movq xmm13, qword ptr [r15+0x1B0]
00007ed4111ce98d  movq r12, xmm14
00007ed4111ce992  movq r11, xmm13
00007ed4111ce997  mov [r13+rax*1], r12
00007ed4111ce99c  lea rax, [r14+0x178]
00007ed4111ce9a3  mov [r13+rax*1], r11
00007ed4111ce9a8  lea rax, [r14+0x180]
00007ed4111ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007ed4111ce9b8  movq xmm13, qword ptr [r15+0x190]
00007ed4111ce9c1  movq r12, xmm14
00007ed4111ce9c6  movq r11, xmm13
00007ed4111ce9cb  mov [r13+rax*1], r12
00007ed4111ce9d0  lea rax, [r14+0x188]
00007ed4111ce9d7  mov [r13+rax*1], r11
00007ed4111ce9dc  lea rax, [r14+0xD0]
00007ed4111ce9e3  movups [r13+rax*1], xmm1
00007ed4111ce9e9  lea rax, [r14+0xE0]
00007ed4111ce9f0  movups [r13+rax*1], xmm15
00007ed4111ce9f6  mov eax, 0x420AD0
00007ed4111ce9fb  movups xmm1, [r13+rax*1]
00007ed4111cea01  mov eax, 0x420AE0
00007ed4111cea06  movups xmm15, [r13+rax*1]
00007ed4111cea0c  movaps [r15+0x110], xmm1
00007ed4111cea14  movaps [r15+0x130], xmm15
00007ed4111cea1c  lea rax, [r14+0x190]
00007ed4111cea23  mov r12, [r15+0xE8]
00007ed4111cea2a  mov r11, [r15+0xF0]
00007ed4111cea31  mov [r13+rax*1], r12
00007ed4111cea36  lea rax, [r14+0x198]
00007ed4111cea3d  mov [r13+rax*1], r11
00007ed4111cea42  mov eax, 0x430D88
00007ed4111cea47  mov r12d, 0x421DF8D3
00007ed4111cea4d  mov [r13+rax*1], r12d
00007ed4111cea52  lea rax, [r14+0xF0]
00007ed4111cea59  movups [r13+rax*1], xmm1
00007ed4111cea5f  lea rax, [r14+0x100]
00007ed4111cea66  movups [r13+rax*1], xmm15
00007ed4111cea6c  lea rax, [r14+0xD0]
00007ed4111cea73  mov [r15], rax
00007ed4111cea76  mov qword ptr [r15+0x08], 0x430C60
00007ed4111cea7e  mov qword ptr [r15+0x10], 0x12C
00007ed4111cea86  mov qword ptr [r15+0xF0], 0x410284
00007ed4111cea91  mov r14d, [r15+0x320]
00007ed4111cea98  mov eax, 0x410284
00007ed4111cea9d  mov rcx, 0x7ED4111D07C0
00007ed4111ceaa7  mov [r15+r14*8+0x328], rax
00007ed4111ceaaf  mov [r15+r14*8+0x368], rcx
00007ed4111ceab7  add r14d, 0x01
00007ed4111ceabb  and r14d, 0x07
00007ed4111ceabf  mov [r15+0x320], r14d
00007ed4111ceac6  cmp dword ptr [r15+0x318], 0x00
00007ed4111ceace  jz 0x00007ED4111CED70
00007ed4111cead4  nop [rax+rax*1], ax
00007ed4111ceadd  nop [rax+rax*1], eax
00007ed4111ceae5  mov eax, 0x4106BC
00007ed4111ceaea  mov [r15+0x100], rax
00007ed4111ceaf1  jmp 0x00007ED410FFE110
00007ed4111ceaf6  int3
00007ed4111ceaf7  call 0x00007ED41100BC20
00007ed4111ceafc  jmp 0x00007ED4111CE6CF
00007ed4111ceb01  call 0x00007ED41100A9A0
00007ed4111ceb06  jmp 0x00007ED4111CE6DB
00007ed4111ceb0b  call 0x00007ED410FFF430
00007ed4111ceb10  jmp 0x00007ED4111CE6E6
00007ed4111ceb15  call 0x00007ED41100E760
00007ed4111ceb1a  jmp 0x00007ED4111CE6F1
00007ed4111ceb1f  call 0x00007ED41100D4E0
00007ed4111ceb24  jmp 0x00007ED4111CE6FC
00007ed4111ceb29  call 0x00007ED41100C260
00007ed4111ceb2e  jmp 0x00007ED4111CE707
00007ed4111ceb33  call 0x00007ED41100AFE0
00007ed4111ceb38  jmp 0x00007ED4111CE71D
00007ed4111ceb3d  call 0x00007ED410FFF540
00007ed4111ceb42  jmp 0x00007ED4111CE728
00007ed4111ceb47  call 0x00007ED41100E880
00007ed4111ceb4c  jmp 0x00007ED4111CE733
00007ed4111ceb51  call 0x00007ED41100D600
00007ed4111ceb56  jmp 0x00007ED4111CE73E
00007ed4111ceb5b  call 0x00007ED41100C380
00007ed4111ceb60  jmp 0x00007ED4111CE749
00007ed4111ceb65  call 0x00007ED41100D4E0
00007ed4111ceb6a  jmp 0x00007ED4111CE754
00007ed4111ceb6f  call 0x00007ED41100C260
00007ed4111ceb74  jmp 0x00007ED4111CE75F
00007ed4111ceb79  call 0x00007ED410FFF540
00007ed4111ceb7e  jmp 0x00007ED4111CE76A
00007ed4111ceb83  call 0x00007ED41100E880
00007ed4111ceb88  jmp 0x00007ED4111CE775
00007ed4111ceb8d  call 0x00007ED41100B100
00007ed4111ceb92  jmp 0x00007ED4111CE780
00007ed4111ceb97  call 0x00007ED41100D600
00007ed4111ceb9c  jmp 0x00007ED4111CE78B
00007ed4111ceba1  call 0x00007ED410FFF430
00007ed4111ceba6  jmp 0x00007ED4111CE796
00007ed4111cebab  call 0x00007ED41100E760
00007ed4111cebb0  jmp 0x00007ED4111CE7A1
00007ed4111cebb5  call 0x00007ED41100C380
00007ed4111cebba  jmp 0x00007ED4111CE7AC
00007ed4111cebbf  call 0x00007ED410FFF540
00007ed4111cebc4  jmp 0x00007ED4111CE7B7
00007ed4111cebc9  call 0x00007ED410FFF430
00007ed4111cebce  jmp 0x00007ED4111CE7C2
00007ed4111cebd3  call 0x00007ED41100D4E0
00007ed4111cebd8  jmp 0x00007ED4111CE7CD
00007ed4111cebdd  call 0x00007ED41100E880
00007ed4111cebe2  jmp 0x00007ED4111CE7E0
00007ed4111cebe7  call 0x00007ED410FFF540
00007ed4111cebec  jmp 0x00007ED4111CE7EB
00007ed4111cebf1  call 0x00007ED410FFF430
00007ed4111cebf6  jmp 0x00007ED4111CE7F6
00007ed4111cebfb  call 0x00007ED41100E760
00007ed4111cec00  jmp 0x00007ED4111CE801
00007ed4111cec05  call 0x00007ED41100D600
00007ed4111cec0a  jmp 0x00007ED4111CE81F
00007ed4111cec0f  call 0x00007ED410FFF540
00007ed4111cec14  jmp 0x00007ED4111CE82A
00007ed4111cec19  call 0x00007ED410FFF430
00007ed4111cec1e  jmp 0x00007ED4111CE835
00007ed4111cec23  call 0x00007ED41100D4E0
00007ed4111cec28  jmp 0x00007ED4111CE840
00007ed4111cec2d  call 0x00007ED41100BC20
00007ed4111cec32  jmp 0x00007ED4111CE870
00007ed4111cec37  call 0x00007ED41100A9A0
00007ed4111cec3c  jmp 0x00007ED4111CE87C
00007ed4111cec41  call 0x00007ED41100E880
00007ed4111cec46  jmp 0x00007ED4111CE887
00007ed4111cec4b  call 0x00007ED410FFF540
00007ed4111cec50  jmp 0x00007ED4111CE892
00007ed4111cec55  call 0x00007ED410FFF430
00007ed4111cec5a  jmp 0x00007ED4111CE89D
00007ed4111cec5f  call 0x00007ED41100B720
00007ed4111cec64  jmp 0x00007ED4111CE8A7
00007ed4111cec69  call 0x00007ED41100D600
00007ed4111cec6e  jmp 0x00007ED4111CE8BF
00007ed4111cec73  call 0x00007ED410FFF540
00007ed4111cec78  jmp 0x00007ED4111CE8CA
00007ed4111cec7d  call 0x00007ED410FFF430
00007ed4111cec82  jmp 0x00007ED4111CE8D5
00007ed4111cec87  call 0x00007ED4110B4CB0
00007ed4111cec8c  jmp 0x00007ED4111CE8E5
00007ed4111cec91  call 0x00007ED41100E760
00007ed4111cec96  jmp 0x00007ED4111CE8F0
00007ed4111cec9b  call 0x00007ED41100D4E0
00007ed4111ceca0  jmp 0x00007ED4111CE8FB
00007ed4111ceca5  call 0x00007ED410FFF540
00007ed4111cecaa  jmp 0x00007ED4111CE908
00007ed4111cecaf  call 0x00007ED41100BC20
00007ed4111cecb4  jmp 0x00007ED4111CE930
00007ed4111cecb9  call 0x00007ED41100A9A0
00007ed4111cecbe  jmp 0x00007ED4111CE93C
00007ed4111cecc3  call 0x00007ED41100E880
00007ed4111cecc8  jmp 0x00007ED4111CE949
00007ed4111ceccd  call 0x00007ED41100D600
00007ed4111cecd2  jmp 0x00007ED4111CE956
00007ed4111cecd7  call 0x00007ED410FFF430
00007ed4111cecdc  jmp 0x00007ED4111CE961
00007ed4111cece1  call 0x00007ED41100E760
00007ed4111cece6  jmp 0x00007ED4111CE96C
00007ed4111ceceb  call 0x00007ED41100BC20
00007ed4111cecf0  jmp 0x00007ED4111CE99C
00007ed4111cecf5  call 0x00007ED41100A9A0
00007ed4111cecfa  jmp 0x00007ED4111CE9A8
00007ed4111cecff  call 0x00007ED41100BC20
00007ed4111ced04  jmp 0x00007ED4111CE9D0
00007ed4111ced09  call 0x00007ED41100A9A0
00007ed4111ced0e  jmp 0x00007ED4111CE9DC
00007ed4111ced13  call 0x00007ED410FFF540
00007ed4111ced18  jmp 0x00007ED4111CE9E9
00007ed4111ced1d  call 0x00007ED41100E880
00007ed4111ced22  jmp 0x00007ED4111CE9F6
00007ed4111ced27  call 0x00007ED410FFF430
00007ed4111ced2c  jmp 0x00007ED4111CEA01
00007ed4111ced31  call 0x00007ED41100E760
00007ed4111ced36  jmp 0x00007ED4111CEA0C
00007ed4111ced3b  call 0x00007ED41100BC20
00007ed4111ced40  jmp 0x00007ED4111CEA36
00007ed4111ced45  call 0x00007ED41100A9A0
00007ed4111ced4a  jmp 0x00007ED4111CEA42
00007ed4111ced4f  call 0x00007ED41100BAE0
00007ed4111ced54  jmp 0x00007ED4111CEA52
00007ed4111ced59  call 0x00007ED410FFF540
00007ed4111ced5e  jmp 0x00007ED4111CEA5F
00007ed4111ced63  call 0x00007ED41100E880
00007ed4111ced68  jmp 0x00007ED4111CEA6C
00007ed4111ced6d  int3
00007ed4111ced6e  nop
00007ed4111ced70  mov rax, [r15]
00007ed4111ced73  lea r14, [rax+0x20]
00007ed4111ced77  mov r12, [r13+r14*1]
00007ed4111ced7c  mov r14, [r15+0x10]
00007ed4111ced80  lea r11, [r12+r14*1]
00007ed4111ced84  mov [r15+0x40], r11
00007ed4111ced88  lea r12, [rax+0x20]
00007ed4111ced8c  mov [r13+r12*1], r11
00007ed4111ced91  test r14, r14
00007ed4111ced94  setz r14b
00007ed4111ced98  movzx r14, r14b
00007ed4111ced9c  mov [rsp+0x414], r14b
00007ed4111ceda4  cmp byte ptr [rsp+0x414], 0x00
00007ed4111cedac  jz 0x00007ED4111CEDDE
00007ed4111cedae  cmp dword ptr [r15+0x318], 0x00
00007ed4111cedb6  mov eax, 0x410934
00007ed4111cedbb  mov [r15+0x100], rax
00007ed4111cedc2  jz 0x00007ED410FFE0A0
00007ed4111cedc8  nop [rax+rax*1], eax
00007ed4111cedcd  mov eax, 0x410934
00007ed4111cedd2  mov [r15+0x100], rax
00007ed4111cedd9  jmp 0x00007ED410FFE110
00007ed4111cedde  cmp dword ptr [r15+0x318], 0x00
00007ed4111cede6  jz 0x00007ED4111CEE30
00007ed4111cedec  nop [rax+rax*1], ax
00007ed4111cedf5  nop [rax+rax*1], eax
00007ed4111cedfd  mov eax, 0x4106CC
00007ed4111cee02  mov [r15+0x100], rax
00007ed4111cee09  jmp 0x00007ED410FFE110
00007ed4111cee0e  int3
00007ed4111cee0f  call 0x00007ED4110E27E0
00007ed4111cee14  jmp 0x00007ED4111CED7C
00007ed4111cee19  call 0x00007ED4110C0860
00007ed4111cee1e  jmp 0x00007ED4111CED91
00007ed4111cee23  int3
00007ed4111cee24  nop [rax+rax*1], ax
00007ed4111cee2d  nop [rax], eax
00007ed4111cee30  mov rax, [r15+0xF8]
00007ed4111cee37  lea r14, [rax-0x150]
00007ed4111cee3e  mov [r15+0xF8], r14
00007ed4111cee45  mov rax, [r15]
00007ed4111cee48  lea r12, [rax+0x68]
00007ed4111cee4c  mov r11, [r13+r12*1]
00007ed4111cee51  mov [r15+0x88], r11
00007ed4111cee58  lea r12, [rax+0x28]
00007ed4111cee5c  mov [r15+0x40], r12
00007ed4111cee60  mov [r15+0x48], r14
00007ed4111cee64  mov qword ptr [r15+0x50], 0x420B20
00007ed4111cee6c  lea rax, [r14+0x100]
00007ed4111cee73  mov r12, [r15+0xE8]
00007ed4111cee7a  mov r11, [r15+0xD8]
00007ed4111cee81  mov [r13+rax*1], r12
00007ed4111cee86  lea rax, [r14+0x108]
00007ed4111cee8d  mov [r13+rax*1], r11
00007ed4111cee92  lea rax, [r14+0x110]
00007ed4111cee99  mov r12, [r15+0xD0]
00007ed4111ceea0  mov r11, [r15+0xC8]
00007ed4111ceea7  mov [r13+rax*1], r12
00007ed4111ceeac  lea rax, [r14+0x118]
00007ed4111ceeb3  mov [r13+rax*1], r11
00007ed4111ceeb8  lea rax, [r14+0x120]
00007ed4111ceebf  mov r12, [r15+0xC0]
00007ed4111ceec6  mov r11, [r15+0xB8]
00007ed4111ceecd  mov [r13+rax*1], r12
00007ed4111ceed2  lea rax, [r14+0x128]
00007ed4111ceed9  mov [r13+rax*1], r11
00007ed4111ceede  lea rax, [r14+0x130]
00007ed4111ceee5  mov r12, [r15+0xB0]
00007ed4111ceeec  mov r11, [r15+0xA8]
00007ed4111ceef3  mov [r13+rax*1], r12
00007ed4111ceef8  lea rax, [r14+0x138]
00007ed4111ceeff  mov [r13+rax*1], r11
00007ed4111cef04  lea rax, [r14+0x140]
00007ed4111cef0b  mov r12, [r15+0xA0]
00007ed4111cef12  mov r11, [r15+0x98]
00007ed4111cef19  mov [r13+rax*1], r12
00007ed4111cef1e  lea rax, [r14+0x148]
00007ed4111cef25  mov [r13+rax*1], r11
00007ed4111cef2a  cmp dword ptr [r15+0x318], 0x00
00007ed4111cef32  jz 0x00007ED4111CEFD0
00007ed4111cef38  nop [rax+rax*1], ax
00007ed4111cef41  nop [rax+rax*1], eax
00007ed4111cef49  mov eax, 0x410704
00007ed4111cef4e  mov [r15+0x100], rax
00007ed4111cef55  jmp 0x00007ED410FFE110
00007ed4111cef5a  int3
00007ed4111cef5b  call 0x00007ED4110C0370
00007ed4111cef60  jmp 0x00007ED4111CEE51
00007ed4111cef65  call 0x00007ED41100BC20
00007ed4111cef6a  jmp 0x00007ED4111CEE86
00007ed4111cef6f  call 0x00007ED41100A9A0
00007ed4111cef74  jmp 0x00007ED4111CEE92
00007ed4111cef79  call 0x00007ED41100BC20
00007ed4111cef7e  jmp 0x00007ED4111CEEAC
00007ed4111cef83  call 0x00007ED41100A9A0
00007ed4111cef88  jmp 0x00007ED4111CEEB8
00007ed4111cef8d  call 0x00007ED41100BC20
00007ed4111cef92  jmp 0x00007ED4111CEED2
00007ed4111cef97  call 0x00007ED41100A9A0
00007ed4111cef9c  jmp 0x00007ED4111CEEDE
00007ed4111cefa1  call 0x00007ED41100BC20
00007ed4111cefa6  jmp 0x00007ED4111CEEF8
00007ed4111cefab  call 0x00007ED41100A9A0
00007ed4111cefb0  jmp 0x00007ED4111CEF04
00007ed4111cefb5  call 0x00007ED41100BC20
00007ed4111cefba  jmp 0x00007ED4111CEF1E
00007ed4111cefbf  call 0x00007ED41100A9A0
00007ed4111cefc4  jmp 0x00007ED4111CEF2A
00007ed4111cefc9  int3
00007ed4111cefca  nop [rax+rax*1], ax
00007ed4111cefd0  mov rax, [r15+0x08]
00007ed4111cefd4  movzx r14d, byte ptr [r13+rax*1]
00007ed4111cefda  movzx r14d, r14b
00007ed4111cefde  mov [rsp+0x10], r14d
00007ed4111cefe3  mov r14d, r14d
00007ed4111cefe6  mov [r15+0x58], r14
00007ed4111cefea  lea r14, [rax+0x01]
00007ed4111cefee  mov [r15+0x08], r14
00007ed4111ceff2  mov rax, [r15+0x88]
00007ed4111ceff9  lea r14, [rax+0x01]
00007ed4111ceffd  mov r12, [r15]
00007ed4111cf000  lea r11, [r12+0x68]
00007ed4111cf005  mov [r13+r11*1], r14
00007ed4111cf00a  lea r14, [r12+rax*1]
00007ed4111cf00e  mov [r15+0x60], r14
00007ed4111cf012  lea rax, [r14+0x28]
00007ed4111cf016  mov r11d, [rsp+0x10]
00007ed4111cf01b  movzx r14d, r11b
00007ed4111cf01f  mov [r13+rax*1], r14b
00007ed4111cf024  lea rax, [r12+0x68]
00007ed4111cf029  mov r14, [r13+rax*1]
00007ed4111cf02e  mov [r15+0x88], r14
00007ed4111cf035  xor eax, eax
00007ed4111cf037  mov r12d, 0x40
00007ed4111cf03d  cmp r14, r12
00007ed4111cf040  cmc
00007ed4111cf041  lahf
00007ed4111cf042  seto al
00007ed4111cf045  mov [r15+0x108], eax
00007ed4111cf04c  mov eax, [r15+0x108]
00007ed4111cf053  sahf
00007ed4111cf054  jnz 0x00007ED4111CF086
00007ed4111cf056  cmp dword ptr [r15+0x318], 0x00
00007ed4111cf05e  jz 0x00007ED4111CF170
00007ed4111cf064  nop [rax+rax*1], ax
00007ed4111cf06d  nop [rax+rax*1], eax
00007ed4111cf075  mov eax, 0x410724
00007ed4111cf07a  mov [r15+0x100], rax
00007ed4111cf081  jmp 0x00007ED410FFE110
00007ed4111cf086  cmp dword ptr [r15+0x318], 0x00
00007ed4111cf08e  jz 0x00007ED4111CF0E0
00007ed4111cf094  nop [rax+rax*1], ax
00007ed4111cf09d  nop [rax+rax*1], eax
00007ed4111cf0a5  mov eax, 0x4106FC
00007ed4111cf0aa  mov [r15+0x100], rax
00007ed4111cf0b1  jmp 0x00007ED410FFE110
00007ed4111cf0b6  int3
00007ed4111cf0b7  call 0x00007ED41100D860
00007ed4111cf0bc  jmp 0x00007ED4111CEFDA
00007ed4111cf0c1  call 0x00007ED4110B36E0
00007ed4111cf0c6  jmp 0x00007ED4111CF00A
00007ed4111cf0cb  call 0x00007ED41100DD60
00007ed4111cf0d0  jmp 0x00007ED4111CF024
00007ed4111cf0d5  call 0x00007ED41100DC20
00007ed4111cf0da  jmp 0x00007ED4111CF02E
00007ed4111cf0df  int3
00007ed4111cf0e0  mov rax, [r15+0x10]
00007ed4111cf0e4  lea r14, [rax-0x01]
00007ed4111cf0e8  mov [r15+0x10], r14
00007ed4111cf0ec  test r14, r14
00007ed4111cf0ef  setz r14b
00007ed4111cf0f3  movzx r14, r14b
00007ed4111cf0f7  mov [rsp+0x414], r14b
00007ed4111cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007ed4111cf107  jz 0x00007ED4111CF139
00007ed4111cf109  cmp dword ptr [r15+0x318], 0x00
00007ed4111cf111  jz 0x00007ED4111D0670
00007ed4111cf117  nop [rax+rax*1], ax
00007ed4111cf120  nop [rax+rax*1], eax
00007ed4111cf128  mov eax, 0x41091C
00007ed4111cf12d  mov [r15+0x100], rax
00007ed4111cf134  jmp 0x00007ED410FFE110
00007ed4111cf139  cmp dword ptr [r15+0x318], 0x00
00007ed4111cf141  jz 0x00007ED4111CEFD0
00007ed4111cf147  nop [rax+rax*1], ax
00007ed4111cf150  nop [rax+rax*1], eax
00007ed4111cf158  mov eax, 0x410704
00007ed4111cf15d  mov [r15+0x100], rax
00007ed4111cf164  jmp 0x00007ED410FFE110
00007ed4111cf169  int3
00007ed4111cf16a  int3
00007ed4111cf16b  nop [rax+rax*1], eax
00007ed4111cf170  mov rax, [r15+0x40]
00007ed4111cf174  movzx r14d, byte ptr [r13+rax*1]
00007ed4111cf17a  movaps xmm1, [r15+0x110]
00007ed4111cf182  pinsrb xmm1, r14d, 0x00
00007ed4111cf189  lea r14, [rax+0x01]
00007ed4111cf18d  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf193  movaps xmm15, [r15+0x120]
00007ed4111cf19b  pinsrb xmm15, r12d, 0x00
00007ed4111cf1a2  lea r14, [rax+0x02]
00007ed4111cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf1ac  movaps xmm14, [r15+0x130]
00007ed4111cf1b4  pinsrb xmm14, r12d, 0x00
00007ed4111cf1bb  lea r14, [rax+0x03]
00007ed4111cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf1c5  movaps xmm13, [r15+0x140]
00007ed4111cf1cd  pinsrb xmm13, r12d, 0x00
00007ed4111cf1d4  lea r14, [rax+0x04]
00007ed4111cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf1de  pinsrb xmm1, r12d, 0x01
00007ed4111cf1e5  lea r14, [rax+0x05]
00007ed4111cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf1ef  pinsrb xmm15, r12d, 0x01
00007ed4111cf1f6  lea r14, [rax+0x06]
00007ed4111cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf200  pinsrb xmm14, r12d, 0x01
00007ed4111cf207  lea r14, [rax+0x07]
00007ed4111cf20b  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf211  pinsrb xmm13, r12d, 0x01
00007ed4111cf218  lea r14, [rax+0x08]
00007ed4111cf21c  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf222  pinsrb xmm1, r12d, 0x02
00007ed4111cf229  lea r14, [rax+0x09]
00007ed4111cf22d  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf233  pinsrb xmm15, r12d, 0x02
00007ed4111cf23a  lea r14, [rax+0x0A]
00007ed4111cf23e  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf244  pinsrb xmm14, r12d, 0x02
00007ed4111cf24b  lea r14, [rax+0x0B]
00007ed4111cf24f  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf255  pinsrb xmm13, r12d, 0x02
00007ed4111cf25c  lea r14, [rax+0x0C]
00007ed4111cf260  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf266  pinsrb xmm1, r12d, 0x03
00007ed4111cf26d  lea r14, [rax+0x0D]
00007ed4111cf271  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf277  pinsrb xmm15, r12d, 0x03
00007ed4111cf27e  lea r14, [rax+0x0E]
00007ed4111cf282  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf288  pinsrb xmm14, r12d, 0x03
00007ed4111cf28f  lea r14, [rax+0x0F]
00007ed4111cf293  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf299  pinsrb xmm13, r12d, 0x03
00007ed4111cf2a0  lea r14, [rax+0x10]
00007ed4111cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf2aa  pinsrb xmm1, r12d, 0x04
00007ed4111cf2b1  lea r14, [rax+0x11]
00007ed4111cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf2bb  pinsrb xmm15, r12d, 0x04
00007ed4111cf2c2  lea r14, [rax+0x12]
00007ed4111cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf2cc  pinsrb xmm14, r12d, 0x04
00007ed4111cf2d3  lea r14, [rax+0x13]
00007ed4111cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf2dd  pinsrb xmm13, r12d, 0x04
00007ed4111cf2e4  lea r14, [rax+0x14]
00007ed4111cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf2ee  pinsrb xmm1, r12d, 0x05
00007ed4111cf2f5  lea r14, [rax+0x15]
00007ed4111cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf2ff  pinsrb xmm15, r12d, 0x05
00007ed4111cf306  lea r14, [rax+0x16]
00007ed4111cf30a  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf310  pinsrb xmm14, r12d, 0x05
00007ed4111cf317  lea r14, [rax+0x17]
00007ed4111cf31b  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf321  pinsrb xmm13, r12d, 0x05
00007ed4111cf328  lea r14, [rax+0x18]
00007ed4111cf32c  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf332  pinsrb xmm1, r12d, 0x06
00007ed4111cf339  lea r14, [rax+0x19]
00007ed4111cf33d  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf343  pinsrb xmm15, r12d, 0x06
00007ed4111cf34a  lea r14, [rax+0x1A]
00007ed4111cf34e  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf354  pinsrb xmm14, r12d, 0x06
00007ed4111cf35b  lea r14, [rax+0x1B]
00007ed4111cf35f  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf365  pinsrb xmm13, r12d, 0x06
00007ed4111cf36c  lea r14, [rax+0x1C]
00007ed4111cf370  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf376  pinsrb xmm1, r12d, 0x07
00007ed4111cf37d  lea r14, [rax+0x1D]
00007ed4111cf381  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf387  pinsrb xmm15, r12d, 0x07
00007ed4111cf38e  lea r14, [rax+0x1E]
00007ed4111cf392  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf398  pinsrb xmm14, r12d, 0x07
00007ed4111cf39f  lea r14, [rax+0x1F]
00007ed4111cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf3a9  pinsrb xmm13, r12d, 0x07
00007ed4111cf3b0  lea r14, [rax+0x20]
00007ed4111cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf3ba  pinsrb xmm1, r12d, 0x08
00007ed4111cf3c1  lea r14, [rax+0x21]
00007ed4111cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf3cb  pinsrb xmm15, r12d, 0x08
00007ed4111cf3d2  lea r14, [rax+0x22]
00007ed4111cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf3dc  pinsrb xmm14, r12d, 0x08
00007ed4111cf3e3  lea r14, [rax+0x23]
00007ed4111cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf3ed  pinsrb xmm13, r12d, 0x08
00007ed4111cf3f4  lea r14, [rax+0x24]
00007ed4111cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf3fe  pinsrb xmm1, r12d, 0x09
00007ed4111cf405  lea r14, [rax+0x25]
00007ed4111cf409  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf40f  pinsrb xmm15, r12d, 0x09
00007ed4111cf416  lea r14, [rax+0x26]
00007ed4111cf41a  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf420  pinsrb xmm14, r12d, 0x09
00007ed4111cf427  lea r14, [rax+0x27]
00007ed4111cf42b  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf431  pinsrb xmm13, r12d, 0x09
00007ed4111cf438  lea r14, [rax+0x28]
00007ed4111cf43c  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf442  pinsrb xmm1, r12d, 0x0A
00007ed4111cf449  lea r14, [rax+0x29]
00007ed4111cf44d  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf453  pinsrb xmm15, r12d, 0x0A
00007ed4111cf45a  lea r14, [rax+0x2A]
00007ed4111cf45e  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf464  pinsrb xmm14, r12d, 0x0A
00007ed4111cf46b  lea r14, [rax+0x2B]
00007ed4111cf46f  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf475  pinsrb xmm13, r12d, 0x0A
00007ed4111cf47c  lea r14, [rax+0x2C]
00007ed4111cf480  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf486  pinsrb xmm1, r12d, 0x0B
00007ed4111cf48d  lea r14, [rax+0x2D]
00007ed4111cf491  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf497  pinsrb xmm15, r12d, 0x0B
00007ed4111cf49e  lea r14, [rax+0x2E]
00007ed4111cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf4a8  pinsrb xmm14, r12d, 0x0B
00007ed4111cf4af  lea r14, [rax+0x2F]
00007ed4111cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf4b9  pinsrb xmm13, r12d, 0x0B
00007ed4111cf4c0  lea r14, [rax+0x30]
00007ed4111cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf4ca  pinsrb xmm1, r12d, 0x0C
00007ed4111cf4d1  lea r14, [rax+0x31]
00007ed4111cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf4db  pinsrb xmm15, r12d, 0x0C
00007ed4111cf4e2  lea r14, [rax+0x32]
00007ed4111cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf4ec  pinsrb xmm14, r12d, 0x0C
00007ed4111cf4f3  lea r14, [rax+0x33]
00007ed4111cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf4fd  pinsrb xmm13, r12d, 0x0C
00007ed4111cf504  lea r14, [rax+0x34]
00007ed4111cf508  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf50e  pinsrb xmm1, r12d, 0x0D
00007ed4111cf515  lea r14, [rax+0x35]
00007ed4111cf519  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf51f  pinsrb xmm15, r12d, 0x0D
00007ed4111cf526  lea r14, [rax+0x36]
00007ed4111cf52a  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf530  pinsrb xmm14, r12d, 0x0D
00007ed4111cf537  lea r14, [rax+0x37]
00007ed4111cf53b  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf541  pinsrb xmm13, r12d, 0x0D
00007ed4111cf548  lea r14, [rax+0x38]
00007ed4111cf54c  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf552  pinsrb xmm1, r12d, 0x0E
00007ed4111cf559  lea r14, [rax+0x39]
00007ed4111cf55d  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf563  pinsrb xmm15, r12d, 0x0E
00007ed4111cf56a  lea r14, [rax+0x3A]
00007ed4111cf56e  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf574  pinsrb xmm14, r12d, 0x0E
00007ed4111cf57b  lea r14, [rax+0x3B]
00007ed4111cf57f  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf585  pinsrb xmm13, r12d, 0x0E
00007ed4111cf58c  lea r14, [rax+0x3C]
00007ed4111cf590  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf596  pinsrb xmm1, r12d, 0x0F
00007ed4111cf59d  movaps [r15+0x110], xmm1
00007ed4111cf5a5  lea r14, [rax+0x3D]
00007ed4111cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf5af  pinsrb xmm15, r12d, 0x0F
00007ed4111cf5b6  movaps [r15+0x120], xmm15
00007ed4111cf5be  lea r14, [rax+0x3E]
00007ed4111cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007ed4111cf5c8  pinsrb xmm14, r12d, 0x0F
00007ed4111cf5cf  movaps [r15+0x130], xmm14
00007ed4111cf5d7  lea r14, [rax+0x3F]
00007ed4111cf5db  movzx eax, byte ptr [r13+r14*1]
00007ed4111cf5e1  pinsrb xmm13, eax, 0x0F
00007ed4111cf5e8  movaps [r15+0x140], xmm13
00007ed4111cf5f0  movq xmm1, qword ptr [r15+0x120]
00007ed4111cf5f9  pmovzxbw xmm1, xmm1
00007ed4111cf5fe  psllw xmm1, 0x00
00007ed4111cf603  movaps [r15+0x150], xmm1
00007ed4111cf60b  movq xmm1, qword ptr [r15+0x130]
00007ed4111cf614  pmovzxbw xmm1, xmm1
00007ed4111cf619  psllw xmm1, 0x00
00007ed4111cf61e  movaps [r15+0x160], xmm1
00007ed4111cf626  movq xmm1, qword ptr [r15+0x110]
00007ed4111cf62f  pmovzxbw xmm1, xmm1
00007ed4111cf634  psllw xmm1, 0x00
00007ed4111cf639  movaps [r15+0x170], xmm1
00007ed4111cf641  movaps xmm15, [r15+0x110]
00007ed4111cf649  pextrq rax, xmm15, 0x01
00007ed4111cf650  movq xmm15, rax
00007ed4111cf655  pmovzxbw xmm15, xmm15
00007ed4111cf65b  psllw xmm15, 0x00
00007ed4111cf661  movaps [r15+0x180], xmm15
00007ed4111cf669  movaps xmm14, [r15+0x120]
00007ed4111cf671  pextrq rax, xmm14, 0x01
00007ed4111cf678  movq xmm14, rax
00007ed4111cf67d  pmovzxbw xmm14, xmm14
00007ed4111cf683  psllw xmm14, 0x00
00007ed4111cf689  movaps [r15+0x210], xmm14
00007ed4111cf691  movaps xmm13, [r15+0x130]
00007ed4111cf699  pextrq rax, xmm13, 0x01
00007ed4111cf6a0  movq xmm13, rax
00007ed4111cf6a5  pmovzxbw xmm13, xmm13
00007ed4111cf6ab  psllw xmm13, 0x00
00007ed4111cf6b1  movaps [r15+0x220], xmm13
00007ed4111cf6b9  movq xmm12, qword ptr [r15+0x140]
00007ed4111cf6c2  pmovzxbw xmm12, xmm12
00007ed4111cf6c8  psllw xmm12, 0x00
00007ed4111cf6ce  movaps [r15+0x250], xmm12
00007ed4111cf6d6  movaps xmm12, [r15+0x140]
00007ed4111cf6de  pextrq rax, xmm12, 0x01
00007ed4111cf6e5  movq xmm12, rax
00007ed4111cf6ea  pmovzxbw xmm12, xmm12
00007ed4111cf6f0  psllw xmm12, 0x00
00007ed4111cf6f6  movaps [r15+0x110], xmm12
00007ed4111cf6fe  movq xmm11, qword ptr [r15+0x150]
00007ed4111cf707  pmovzxwd xmm11, xmm11
00007ed4111cf70d  pslld xmm11, 0x10
00007ed4111cf713  movq xmm10, qword ptr [r15+0x160]
00007ed4111cf71c  pmovzxwd xmm10, xmm10
00007ed4111cf722  pslld xmm10, 0x08
00007ed4111cf728  pextrq rax, xmm1, 0x01
00007ed4111cf72f  movq xmm1, rax
00007ed4111cf734  pmovzxwd xmm1, xmm1
00007ed4111cf739  pslld xmm1, 0x00
00007ed4111cf73e  movaps [r15+0x260], xmm1
00007ed4111cf746  pextrq rax, xmm15, 0x01
00007ed4111cf74d  movq xmm15, rax
00007ed4111cf752  pmovzxwd xmm15, xmm15
00007ed4111cf758  pslld xmm15, 0x00
00007ed4111cf75e  movaps [r15+0x270], xmm15
00007ed4111cf766  movq xmm9, qword ptr [r15+0x170]
00007ed4111cf76f  pmovzxwd xmm9, xmm9
00007ed4111cf775  pslld xmm9, 0x00
00007ed4111cf77b  pextrq rax, xmm14, 0x01
00007ed4111cf782  movq xmm14, rax
00007ed4111cf787  pmovzxwd xmm14, xmm14
00007ed4111cf78d  pslld xmm14, 0x10
00007ed4111cf793  movaps [r15+0x280], xmm14
00007ed4111cf79b  movq xmm8, qword ptr [r15+0x180]
00007ed4111cf7a4  pmovzxwd xmm8, xmm8
00007ed4111cf7aa  pslld xmm8, 0x00
00007ed4111cf7b0  movq xmm7, qword ptr [r15+0x210]
00007ed4111cf7b9  pmovzxwd xmm7, xmm7
00007ed4111cf7be  pslld xmm7, 0x10
00007ed4111cf7c3  movaps xmm6, [r15+0x150]
00007ed4111cf7cb  pextrq rax, xmm6, 0x01
00007ed4111cf7d2  movq xmm6, rax
00007ed4111cf7d7  pmovzxwd xmm6, xmm6
00007ed4111cf7dc  pslld xmm6, 0x10
00007ed4111cf7e1  por xmm11, xmm10
00007ed4111cf7e6  movaps [r15+0x230], xmm11
00007ed4111cf7ee  pextrq rax, xmm13, 0x01
00007ed4111cf7f5  movq xmm13, rax
00007ed4111cf7fa  pmovzxwd xmm13, xmm13
00007ed4111cf800  pslld xmm13, 0x08
00007ed4111cf806  movaps [r15+0x240], xmm13
00007ed4111cf80e  movq xmm10, qword ptr [r15+0x220]
00007ed4111cf817  pmovzxwd xmm10, xmm10
00007ed4111cf81d  pslld xmm10, 0x08
00007ed4111cf823  movaps xmm5, [r15+0x160]
00007ed4111cf82b  pextrq rax, xmm5, 0x01
00007ed4111cf832  movq xmm5, rax
00007ed4111cf837  pmovzxwd xmm5, xmm5
00007ed4111cf83c  pslld xmm5, 0x08
00007ed4111cf841  pslld xmm9, 0x18
00007ed4111cf847  pslld xmm15, 0x18
00007ed4111cf84d  pslld xmm8, 0x18
00007ed4111cf853  movq xmm4, qword ptr [r15+0x250]
00007ed4111cf85c  pmovzxwd xmm4, xmm4
00007ed4111cf861  pslld xmm4, 0x00
00007ed4111cf866  por xmm14, xmm13
00007ed4111cf86b  por xmm7, xmm10
00007ed4111cf870  movaps [r15+0x210], xmm7
00007ed4111cf878  pslld xmm1, 0x18
00007ed4111cf87d  movaps [r15+0x220], xmm1
00007ed4111cf885  por xmm6, xmm5
00007ed4111cf889  por xmm11, xmm9
00007ed4111cf88e  movaps [r15+0x160], xmm11
00007ed4111cf896  pextrq rax, xmm12, 0x01
00007ed4111cf89d  movq xmm13, rax
00007ed4111cf8a2  pmovzxwd xmm13, xmm13
00007ed4111cf8a8  pslld xmm13, 0x00
00007ed4111cf8ae  movaps [r15+0x170], xmm13
00007ed4111cf8b6  movq xmm12, qword ptr [r15+0x110]
00007ed4111cf8bf  pmovzxwd xmm12, xmm12
00007ed4111cf8c5  pslld xmm12, 0x00
00007ed4111cf8cb  por xmm14, xmm15
00007ed4111cf8d0  por xmm7, xmm8
00007ed4111cf8d5  movaps xmm15, [r15+0x250]
00007ed4111cf8dd  pextrq rax, xmm15, 0x01
00007ed4111cf8e4  movq xmm15, rax
00007ed4111cf8e9  pmovzxwd xmm15, xmm15
00007ed4111cf8ef  pslld xmm15, 0x00
00007ed4111cf8f5  movaps [r15+0x180], xmm15
00007ed4111cf8fd  por xmm6, xmm1
00007ed4111cf901  movaps [r15+0x150], xmm6
00007ed4111cf909  por xmm11, xmm4
00007ed4111cf90e  movaps [r15+0x140], xmm11
00007ed4111cf916  por xmm7, xmm12
00007ed4111cf91b  movaps [r15+0x110], xmm7
00007ed4111cf923  por xmm14, xmm13
00007ed4111cf928  movaps [r15+0x120], xmm14
00007ed4111cf930  por xmm6, xmm15
00007ed4111cf935  movaps [r15+0x130], xmm6
00007ed4111cf93d  mov rax, [r15+0xF8]
00007ed4111cf944  lea r14, [rax+0x20]
00007ed4111cf948  movups [r13+r14*1], xmm7
00007ed4111cf94e  lea r14, [rax+0x30]
00007ed4111cf952  movups [r13+r14*1], xmm14
00007ed4111cf958  movups [r13+rax*1], xmm11
00007ed4111cf95e  lea r14, [rax+0x10]
00007ed4111cf962  movups [r13+r14*1], xmm6
00007ed4111cf968  mov r14d, [r13+rax*1]
00007ed4111cf96d  mov rax, [r15+0x48]
00007ed4111cf971  mov [r15+0x68], rax
00007ed4111cf975  mov qword ptr [r15+0x58], 0x04
00007ed4111cf97d  lea r12, [rax+0x04]
00007ed4111cf981  mov r11d, [r13+r12*1]
00007ed4111cf986  mov [rsp+0x10], r11d
00007ed4111cf98b  mov r11d, r11d
00007ed4111cf98e  mov [r15+0x70], r11
00007ed4111cf992  lea r12, [rax+0x38]
00007ed4111cf996  mov r11d, [r13+r12*1]
00007ed4111cf99b  lea r12, [rax+0x24]
00007ed4111cf99f  mov r10d, [r13+r12*1]
00007ed4111cf9a4  mov [rsp+0x20], r10d
00007ed4111cf9a9  mov r10d, r10d
00007ed4111cf9ac  mov [r15+0x90], r10
00007ed4111cf9b3  mov [rsp+0x30], rax
00007ed4111cf9b8  xor eax, eax
00007ed4111cf9ba  mov r12d, 0x04
00007ed4111cf9c0  mov r10d, 0xC0
00007ed4111cf9c6  cmp r12, r10
00007ed4111cf9c9  cmc
00007ed4111cf9ca  lahf
00007ed4111cf9cb  seto al
00007ed4111cf9ce  mov [r15+0x108], eax
00007ed4111cf9d5  mov eax, [rsp+0x10]
00007ed4111cf9d9  mov r12d, [rsp+0x10]
00007ed4111cf9de  shrd eax, r12d, 0x07
00007ed4111cf9e3  mov [rsp+0x10], r11d
00007ed4111cf9e8  mov r10d, [rsp+0x10]
00007ed4111cf9ed  shrd r11d, r10d, 0x11
00007ed4111cf9f2  mov r9d, [rsp+0x20]
00007ed4111cf9f7  lea r8d, [r9d+r14d*1]
00007ed4111cf9fc  rorx r14d, r12d, 0x12
00007ed4111cfa02  xor eax, r14d
00007ed4111cfa05  rorx r14d, r10d, 0x13
00007ed4111cfa0b  xor r11d, r14d
00007ed4111cfa0e  mov [rsp+0x10], r11d
00007ed4111cfa13  mov r11d, r11d
00007ed4111cfa16  mov [r15+0x88], r11
00007ed4111cfa1d  mov [rsp+0x20], r12d
00007ed4111cfa22  shr r12d, 0x03
00007ed4111cfa26  xor eax, r12d
00007ed4111cfa29  mov [rsp+0x40], eax
00007ed4111cfa2d  mov eax, eax
00007ed4111cfa2f  mov [r15+0x80], rax
00007ed4111cfa36  shr r10d, 0x0A
00007ed4111cfa3a  mov eax, [rsp+0x10]
00007ed4111cfa3e  xor eax, r10d
00007ed4111cfa41  mov [rsp+0x10], eax
00007ed4111cfa45  mov eax, eax
00007ed4111cfa47  mov [r15+0x78], rax
00007ed4111cfa4b  mov eax, [rsp+0x40]
00007ed4111cfa4f  lea r14d, [r8d+eax*1]
00007ed4111cfa54  mov eax, [rsp+0x10]
00007ed4111cfa58  lea r12d, [r14d+eax*1]
00007ed4111cfa5d  mov rax, [rsp+0x30]
00007ed4111cfa62  lea r14, [rax+0x40]
00007ed4111cfa66  mov [r13+r14*1], r12d
00007ed4111cfa6b  mov eax, [rsp+0x20]
00007ed4111cfa6f  mov eax, eax
00007ed4111cfa71  mov [r15+0x60], rax
00007ed4111cfa75  mov eax, [r15+0x108]
00007ed4111cfa7c  sahf
00007ed4111cfa7d  jnz 0x00007ED4111CFAAF
00007ed4111cfa7f  cmp dword ptr [r15+0x318], 0x00
00007ed4111cfa87  jz 0x00007ED4111CFF70
00007ed4111cfa8d  nop [rax+rax*1], ax
00007ed4111cfa96  nop [rax+rax*1], eax
00007ed4111cfa9e  mov eax, 0x410820
00007ed4111cfaa3  mov [r15+0x100], rax
00007ed4111cfaaa  jmp 0x00007ED410FFE110
00007ed4111cfaaf  cmp dword ptr [r15+0x318], 0x00
00007ed4111cfab7  jz 0x00007ED4111CFDC0
00007ed4111cfabd  nop [rax+rax*1], ax
00007ed4111cfac6  nop [rax+rax*1], eax
00007ed4111cface  mov eax, 0x4107D8
00007ed4111cfad3  mov [r15+0x100], rax
00007ed4111cfada  jmp 0x00007ED410FFE110
00007ed4111cfadf  int3
00007ed4111cfae0  call 0x00007ED41100D860
00007ed4111cfae5  jmp 0x00007ED4111CF17A
00007ed4111cfaea  call 0x00007ED4110E2420
00007ed4111cfaef  jmp 0x00007ED4111CF193
00007ed4111cfaf4  call 0x00007ED4110E2420
00007ed4111cfaf9  jmp 0x00007ED4111CF1AC
00007ed4111cfafe  call 0x00007ED4110E2420
00007ed4111cfb03  jmp 0x00007ED4111CF1C5
00007ed4111cfb08  call 0x00007ED4110E2420
00007ed4111cfb0d  jmp 0x00007ED4111CF1DE
00007ed4111cfb12  call 0x00007ED4110E2420
00007ed4111cfb17  jmp 0x00007ED4111CF1EF
00007ed4111cfb1c  call 0x00007ED4110E2420
00007ed4111cfb21  jmp 0x00007ED4111CF200
00007ed4111cfb26  call 0x00007ED4110E2420
00007ed4111cfb2b  jmp 0x00007ED4111CF211
00007ed4111cfb30  call 0x00007ED4110E2420
00007ed4111cfb35  jmp 0x00007ED4111CF222
00007ed4111cfb3a  call 0x00007ED4110E2420
00007ed4111cfb3f  jmp 0x00007ED4111CF233
00007ed4111cfb44  call 0x00007ED4110E2420
00007ed4111cfb49  jmp 0x00007ED4111CF244
00007ed4111cfb4e  call 0x00007ED4110E2420
00007ed4111cfb53  jmp 0x00007ED4111CF255
00007ed4111cfb58  call 0x00007ED4110E2420
00007ed4111cfb5d  jmp 0x00007ED4111CF266
00007ed4111cfb62  call 0x00007ED4110E2420
00007ed4111cfb67  jmp 0x00007ED4111CF277
00007ed4111cfb6c  call 0x00007ED4110E2420
00007ed4111cfb71  jmp 0x00007ED4111CF288
00007ed4111cfb76  call 0x00007ED4110E2420
00007ed4111cfb7b  jmp 0x00007ED4111CF299
00007ed4111cfb80  call 0x00007ED4110E2420
00007ed4111cfb85  jmp 0x00007ED4111CF2AA
00007ed4111cfb8a  call 0x00007ED4110E2420
00007ed4111cfb8f  jmp 0x00007ED4111CF2BB
00007ed4111cfb94  call 0x00007ED4110E2420
00007ed4111cfb99  jmp 0x00007ED4111CF2CC
00007ed4111cfb9e  call 0x00007ED4110E2420
00007ed4111cfba3  jmp 0x00007ED4111CF2DD
00007ed4111cfba8  call 0x00007ED4110E2420
00007ed4111cfbad  jmp 0x00007ED4111CF2EE
00007ed4111cfbb2  call 0x00007ED4110E2420
00007ed4111cfbb7  jmp 0x00007ED4111CF2FF
00007ed4111cfbbc  call 0x00007ED4110E2420
00007ed4111cfbc1  jmp 0x00007ED4111CF310
00007ed4111cfbc6  call 0x00007ED4110E2420
00007ed4111cfbcb  jmp 0x00007ED4111CF321
00007ed4111cfbd0  call 0x00007ED4110E2420
00007ed4111cfbd5  jmp 0x00007ED4111CF332
00007ed4111cfbda  call 0x00007ED4110E2420
00007ed4111cfbdf  jmp 0x00007ED4111CF343
00007ed4111cfbe4  call 0x00007ED4110E2420
00007ed4111cfbe9  jmp 0x00007ED4111CF354
00007ed4111cfbee  call 0x00007ED4110E2420
00007ed4111cfbf3  jmp 0x00007ED4111CF365
00007ed4111cfbf8  call 0x00007ED4110E2420
00007ed4111cfbfd  jmp 0x00007ED4111CF376
00007ed4111cfc02  call 0x00007ED4110E2420
00007ed4111cfc07  jmp 0x00007ED4111CF387
00007ed4111cfc0c  call 0x00007ED4110E2420
00007ed4111cfc11  jmp 0x00007ED4111CF398
00007ed4111cfc16  call 0x00007ED4110E2420
00007ed4111cfc1b  jmp 0x00007ED4111CF3A9
00007ed4111cfc20  call 0x00007ED4110E2420
00007ed4111cfc25  jmp 0x00007ED4111CF3BA
00007ed4111cfc2a  call 0x00007ED4110E2420
00007ed4111cfc2f  jmp 0x00007ED4111CF3CB
00007ed4111cfc34  call 0x00007ED4110E2420
00007ed4111cfc39  jmp 0x00007ED4111CF3DC
00007ed4111cfc3e  call 0x00007ED4110E2420
00007ed4111cfc43  jmp 0x00007ED4111CF3ED
00007ed4111cfc48  call 0x00007ED4110E2420
00007ed4111cfc4d  jmp 0x00007ED4111CF3FE
00007ed4111cfc52  call 0x00007ED4110E2420
00007ed4111cfc57  jmp 0x00007ED4111CF40F
00007ed4111cfc5c  call 0x00007ED4110E2420
00007ed4111cfc61  jmp 0x00007ED4111CF420
00007ed4111cfc66  call 0x00007ED4110E2420
00007ed4111cfc6b  jmp 0x00007ED4111CF431
00007ed4111cfc70  call 0x00007ED4110E2420
00007ed4111cfc75  jmp 0x00007ED4111CF442
00007ed4111cfc7a  call 0x00007ED4110E2420
00007ed4111cfc7f  jmp 0x00007ED4111CF453
00007ed4111cfc84  call 0x00007ED4110E2420
00007ed4111cfc89  jmp 0x00007ED4111CF464
00007ed4111cfc8e  call 0x00007ED4110E2420
00007ed4111cfc93  jmp 0x00007ED4111CF475
00007ed4111cfc98  call 0x00007ED4110E2420
00007ed4111cfc9d  jmp 0x00007ED4111CF486
00007ed4111cfca2  call 0x00007ED4110E2420
00007ed4111cfca7  jmp 0x00007ED4111CF497
00007ed4111cfcac  call 0x00007ED4110E2420
00007ed4111cfcb1  jmp 0x00007ED4111CF4A8
00007ed4111cfcb6  call 0x00007ED4110E2420
00007ed4111cfcbb  jmp 0x00007ED4111CF4B9
00007ed4111cfcc0  call 0x00007ED4110E2420
00007ed4111cfcc5  jmp 0x00007ED4111CF4CA
00007ed4111cfcca  call 0x00007ED4110E2420
00007ed4111cfccf  jmp 0x00007ED4111CF4DB
00007ed4111cfcd4  call 0x00007ED4110E2420
00007ed4111cfcd9  jmp 0x00007ED4111CF4EC
00007ed4111cfcde  call 0x00007ED4110E2420
00007ed4111cfce3  jmp 0x00007ED4111CF4FD
00007ed4111cfce8  call 0x00007ED4110E2420
00007ed4111cfced  jmp 0x00007ED4111CF50E
00007ed4111cfcf2  call 0x00007ED4110E2420
00007ed4111cfcf7  jmp 0x00007ED4111CF51F
00007ed4111cfcfc  call 0x00007ED4110E2420
00007ed4111cfd01  jmp 0x00007ED4111CF530
00007ed4111cfd06  call 0x00007ED4110E2420
00007ed4111cfd0b  jmp 0x00007ED4111CF541
00007ed4111cfd10  call 0x00007ED4110E2420
00007ed4111cfd15  jmp 0x00007ED4111CF552
00007ed4111cfd1a  call 0x00007ED4110E2420
00007ed4111cfd1f  jmp 0x00007ED4111CF563
00007ed4111cfd24  call 0x00007ED4110E2420
00007ed4111cfd29  jmp 0x00007ED4111CF574
00007ed4111cfd2e  call 0x00007ED4110E2420
00007ed4111cfd33  jmp 0x00007ED4111CF585
00007ed4111cfd38  call 0x00007ED4110E2420
00007ed4111cfd3d  jmp 0x00007ED4111CF596
00007ed4111cfd42  call 0x00007ED4110E2420
00007ed4111cfd47  jmp 0x00007ED4111CF5AF
00007ed4111cfd4c  call 0x00007ED4110E2420
00007ed4111cfd51  jmp 0x00007ED4111CF5C8
00007ed4111cfd56  call 0x00007ED4110D5610
00007ed4111cfd5b  jmp 0x00007ED4111CF5E1
00007ed4111cfd60  call 0x00007ED4110DC580
00007ed4111cfd65  jmp 0x00007ED4111CF94E
00007ed4111cfd6a  call 0x00007ED4110E46C0
00007ed4111cfd6f  jmp 0x00007ED4111CF958
00007ed4111cfd74  call 0x00007ED411009E90
00007ed4111cfd79  jmp 0x00007ED4111CF95E
00007ed4111cfd7e  call 0x00007ED4110DB310
00007ed4111cfd83  jmp 0x00007ED4111CF968
00007ed4111cfd88  call 0x00007ED41100DAE0
00007ed4111cfd8d  jmp 0x00007ED4111CF96D
00007ed4111cfd92  call 0x00007ED4110C0230
00007ed4111cfd97  jmp 0x00007ED4111CF986
00007ed4111cfd9c  call 0x00007ED4110C0230
00007ed4111cfda1  jmp 0x00007ED4111CF99B
00007ed4111cfda6  call 0x00007ED4110BEFC0
00007ed4111cfdab  jmp 0x00007ED4111CF9A4
00007ed4111cfdb0  call 0x00007ED4110E2BA0
00007ed4111cfdb5  jmp 0x00007ED4111CFA6B
00007ed4111cfdba  int3
00007ed4111cfdbb  nop [rax+rax*1], eax
00007ed4111cfdc0  mov rax, [r15+0x48]
00007ed4111cfdc4  mov r14, [r15+0x58]
00007ed4111cfdc8  lea r12, [rax+r14*1]
00007ed4111cfdcc  mov [r15+0x68], r12
00007ed4111cfdd0  lea rax, [r14+0x04]
00007ed4111cfdd4  mov [r15+0x58], rax
00007ed4111cfdd8  lea r14, [r12+0x04]
00007ed4111cfddd  mov r11d, [r13+r14*1]
00007ed4111cfde2  mov [rsp+0x10], r11d
00007ed4111cfde7  mov r11d, r11d
00007ed4111cfdea  mov [r15+0x70], r11
00007ed4111cfdee  lea r14, [r12+0x38]
00007ed4111cfdf3  mov r11d, [r13+r14*1]
00007ed4111cfdf8  lea r14, [r12+0x24]
00007ed4111cfdfd  mov r10d, [r13+r14*1]
00007ed4111cfe02  mov [rsp+0x20], r10d
00007ed4111cfe07  mov r10d, r10d
00007ed4111cfe0a  mov [r15+0x90], r10
00007ed4111cfe11  mov [rsp+0x30], rax
00007ed4111cfe16  xor eax, eax
00007ed4111cfe18  mov r14, [rsp+0x30]
00007ed4111cfe1d  mov r10d, 0xC0
00007ed4111cfe23  cmp r14, r10
00007ed4111cfe26  cmc
00007ed4111cfe27  lahf
00007ed4111cfe28  seto al
00007ed4111cfe2b  mov [r15+0x108], eax
00007ed4111cfe32  mov eax, [rsp+0x10]
00007ed4111cfe36  mov r14d, [rsp+0x10]
00007ed4111cfe3b  shrd eax, r14d, 0x07
00007ed4111cfe40  mov [rsp+0x10], r11d
00007ed4111cfe45  mov r10d, [rsp+0x10]
00007ed4111cfe4a  shrd r11d, r10d, 0x11
00007ed4111cfe4f  mov r9d, [r15+0x60]
00007ed4111cfe53  mov r8d, [rsp+0x20]
00007ed4111cfe58  lea ebp, [r8d+r9d*1]
00007ed4111cfe5d  rorx r9d, r14d, 0x12
00007ed4111cfe63  xor eax, r9d
00007ed4111cfe66  rorx r9d, r10d, 0x13
00007ed4111cfe6c  xor r11d, r9d
00007ed4111cfe6f  mov [rsp+0x10], r11d
00007ed4111cfe74  mov r11d, r11d
00007ed4111cfe77  mov [r15+0x88], r11
00007ed4111cfe7e  mov [rsp+0x20], r14d
00007ed4111cfe83  shr r14d, 0x03
00007ed4111cfe87  xor eax, r14d
00007ed4111cfe8a  mov [rsp+0x30], eax
00007ed4111cfe8e  mov eax, eax
00007ed4111cfe90  mov [r15+0x80], rax
00007ed4111cfe97  shr r10d, 0x0A
00007ed4111cfe9b  mov eax, [rsp+0x10]
00007ed4111cfe9f  xor eax, r10d
00007ed4111cfea2  mov [rsp+0x10], eax
00007ed4111cfea6  mov eax, eax
00007ed4111cfea8  mov [r15+0x78], rax
00007ed4111cfeac  mov eax, [rsp+0x30]
00007ed4111cfeb0  lea r14d, [ebp+eax*1]
00007ed4111cfeb6  mov eax, [rsp+0x10]
00007ed4111cfeba  lea r11d, [r14d+eax*1]
00007ed4111cfebf  lea rax, [r12+0x40]
00007ed4111cfec4  mov [r13+rax*1], r11d
00007ed4111cfec9  mov eax, [rsp+0x20]
00007ed4111cfecd  mov eax, eax
00007ed4111cfecf  mov [r15+0x60], rax
00007ed4111cfed3  mov eax, [r15+0x108]
00007ed4111cfeda  sahf
00007ed4111cfedb  jnz 0x00007ED4111CFF0D
00007ed4111cfedd  cmp dword ptr [r15+0x318], 0x00
00007ed4111cfee5  jz 0x00007ED4111CFF70
00007ed4111cfeeb  nop [rax+rax*1], ax
00007ed4111cfef4  nop [rax+rax*1], eax
00007ed4111cfefc  mov eax, 0x410820
00007ed4111cff01  mov [r15+0x100], rax
00007ed4111cff08  jmp 0x00007ED410FFE110
00007ed4111cff0d  cmp dword ptr [r15+0x318], 0x00
00007ed4111cff15  jz 0x00007ED4111CFDC0
00007ed4111cff1b  nop [rax+rax*1], ax
00007ed4111cff24  nop [rax+rax*1], eax
00007ed4111cff2c  mov eax, 0x4107D8
00007ed4111cff31  mov [r15+0x100], rax
00007ed4111cff38  jmp 0x00007ED410FFE110
00007ed4111cff3d  int3
00007ed4111cff3e  call 0x00007ED4110E1430
00007ed4111cff43  jmp 0x00007ED4111CFDE2
00007ed4111cff48  call 0x00007ED4110E1430
00007ed4111cff4d  jmp 0x00007ED4111CFDF8
00007ed4111cff52  call 0x00007ED4110E01C0
00007ed4111cff57  jmp 0x00007ED4111CFE02
00007ed4111cff5c  call 0x00007ED41100A860
00007ed4111cff61  jmp 0x00007ED4111CFEC9
00007ed4111cff66  int3
00007ed4111cff67  nop [rax+rax*1], ax
00007ed4111cff70  mov rax, [r15]
00007ed4111cff73  mov r14d, [r13+rax*1]
00007ed4111cff78  lea r12, [rax+0x04]
00007ed4111cff7c  mov r11d, [r13+r12*1]
00007ed4111cff81  mov [rsp+0x10], r14d
00007ed4111cff86  mov r14d, r14d
00007ed4111cff89  mov [r15+0x78], r14
00007ed4111cff8d  mov [rsp+0x20], r11d
00007ed4111cff92  mov r11d, r11d
00007ed4111cff95  mov [r15+0x80], r11
00007ed4111cff9c  lea r14, [rax+0x08]
00007ed4111cffa0  mov r12d, [r13+r14*1]
00007ed4111cffa5  lea r14, [rax+0x0C]
00007ed4111cffa9  mov r11d, [r13+r14*1]
00007ed4111cffae  mov [rsp+0x30], r12d
00007ed4111cffb3  mov r12d, r12d
00007ed4111cffb6  mov [r15+0x70], r12
00007ed4111cffba  mov [rsp+0x40], r11d
00007ed4111cffbf  mov r11d, r11d
00007ed4111cffc2  mov [r15+0x68], r11
00007ed4111cffc6  lea r14, [rax+0x18]
00007ed4111cffca  mov r12d, [r13+r14*1]
00007ed4111cffcf  lea r14, [rax+0x1C]
00007ed4111cffd3  mov r11d, [r13+r14*1]
00007ed4111cffd8  mov [rsp+0x50], r12d
00007ed4111cffdd  mov r12d, r12d
00007ed4111cffe0  mov [r15+0x58], r12
00007ed4111cffe4  mov [rsp+0x60], r11d
00007ed4111cffe9  mov r11d, r11d
00007ed4111cffec  mov [r15+0x60], r11
00007ed4111cfff0  lea r14, [rax+0x10]
00007ed4111cfff4  mov r12d, [r13+r14*1]
00007ed4111cfff9  lea r14, [rax+0x14]
00007ed4111cfffd  mov eax, [r13+r14*1]
00007ed4111d0002  mov [rsp+0x70], r12d
00007ed4111d0007  mov r12d, r12d
00007ed4111d000a  mov [r15+0x18], r12
00007ed4111d000e  mov [rsp+0x80], eax
00007ed4111d0015  mov eax, eax
00007ed4111d0017  mov [r15+0x90], rax
00007ed4111d001e  mov eax, [rsp+0x70]
00007ed4111d0022  mov eax, eax
00007ed4111d0024  mov [r15+0x30], rax
00007ed4111d0028  mov eax, [rsp+0x50]
00007ed4111d002c  mov eax, eax
00007ed4111d002e  mov [r15+0xA0], rax
00007ed4111d0035  mov eax, [rsp+0x30]
00007ed4111d0039  mov eax, eax
00007ed4111d003b  mov [r15+0x28], rax
00007ed4111d003f  mov eax, [rsp+0x20]
00007ed4111d0043  mov eax, eax
00007ed4111d0045  mov [r15+0x98], rax
00007ed4111d004c  mov eax, [rsp+0x10]
00007ed4111d0050  mov eax, eax
00007ed4111d0052  mov [r15+0x38], rax
00007ed4111d0056  mov eax, [rsp+0x70]
00007ed4111d005a  mov r14d, [rsp+0x70]
00007ed4111d005f  shrd eax, r14d, 0x06
00007ed4111d0064  mov [rsp+0x70], r14d
00007ed4111d0069  mov r12d, [rsp+0x80]
00007ed4111d0071  and r14d, r12d
00007ed4111d0074  mov r11d, [rsp+0x10]
00007ed4111d0079  mov r10d, [rsp+0x10]
00007ed4111d007e  shrd r11d, r10d, 0x02
00007ed4111d0083  mov [rsp+0x10], r12d
00007ed4111d0088  mov r12d, r12d
00007ed4111d008b  mov [r15+0x20], r12
00007ed4111d008f  mov r12, [r15+0x50]
00007ed4111d0093  mov r9d, [r13+r12*1]
00007ed4111d0098  mov r12d, [rsp+0x50]
00007ed4111d009d  mov r8d, [rsp+0x70]
00007ed4111d00a2  andn ebp, r8d, r12d
00007ed4111d00a7  mov edi, [rsp+0x60]
00007ed4111d00ab  lea esi, [r14d+edi*1]
00007ed4111d00b0  rorx r14d, r8d, 0x0B
00007ed4111d00b6  xor eax, r14d
00007ed4111d00b9  rorx r14d, r10d, 0x0D
00007ed4111d00bf  xor r11d, r14d
00007ed4111d00c2  lea edi, [esi+ebp*1]
00007ed4111d00c6  mov r14, [r15+0x48]
00007ed4111d00ca  mov ebp, [r13+r14*1]
00007ed4111d00cf  mov r14d, [rsp+0x30]
00007ed4111d00d4  mov esi, [rsp+0x20]
00007ed4111d00d8  and r14d, esi
00007ed4111d00db  mov [rsp+0x20], r14d
00007ed4111d00e0  mov r14d, r14d
00007ed4111d00e3  mov [r15+0xD8], r14
00007ed4111d00ea  lea r14d, [edi+r9d*1]
00007ed4111d00ef  mov r9d, [rsp+0x30]
00007ed4111d00f4  xor r9d, esi
00007ed4111d00f7  rorx edi, r8d, 0x19
00007ed4111d00fd  xor eax, edi
00007ed4111d00ff  and r9d, r10d
00007ed4111d0102  rorx edi, r10d, 0x16
00007ed4111d0108  xor r11d, edi
00007ed4111d010b  mov [rsp+0x30], r11d
00007ed4111d0110  mov r11d, r11d
00007ed4111d0113  mov [r15+0xD0], r11
00007ed4111d011a  lea r11d, [r14d+ebp*1]
00007ed4111d011f  mov r10d, [rsp+0x20]
00007ed4111d0124  xor r9d, r10d
00007ed4111d0127  lea r14d, [r11d+eax*1]
00007ed4111d012c  mov qword ptr [r15+0x88], 0x04
00007ed4111d0137  mov eax, [rsp+0x30]
00007ed4111d013b  lea r11d, [r9d+eax*1]
00007ed4111d0140  mov eax, [rsp+0x40]
00007ed4111d0144  lea r10d, [r14d+eax*1]
00007ed4111d0149  mov r10d, r10d
00007ed4111d014c  mov [r15+0xB8], r10
00007ed4111d0153  xor eax, eax
00007ed4111d0155  mov r10d, 0x04
00007ed4111d015b  mov r9d, 0x100
00007ed4111d0161  cmp r10, r9
00007ed4111d0164  cmc
00007ed4111d0165  lahf
00007ed4111d0166  seto al
00007ed4111d0169  mov [r15+0x108], eax
00007ed4111d0170  lea eax, [r11d+r14d*1]
00007ed4111d0175  mov eax, eax
00007ed4111d0177  mov [r15+0xA8], rax
00007ed4111d017e  mov r12d, r12d
00007ed4111d0181  mov [r15+0xB0], r12
00007ed4111d0188  mov eax, [rsp+0x10]
00007ed4111d018c  mov eax, eax
00007ed4111d018e  mov [r15+0xC0], rax
00007ed4111d0195  mov r8d, r8d
00007ed4111d0198  mov [r15+0xC8], r8
00007ed4111d019f  mov eax, [r15+0x108]
00007ed4111d01a6  sahf
00007ed4111d01a7  jnz 0x00007ED4111D01D9
00007ed4111d01a9  cmp dword ptr [r15+0x318], 0x00
00007ed4111d01b1  jz 0x00007ED4111D04A0
00007ed4111d01b7  nop [rax+rax*1], ax
00007ed4111d01c0  nop [rax+rax*1], eax
00007ed4111d01c8  mov eax, 0x4108E0
00007ed4111d01cd  mov [r15+0x100], rax
00007ed4111d01d4  jmp 0x00007ED410FFE110
00007ed4111d01d9  cmp dword ptr [r15+0x318], 0x00
00007ed4111d01e1  jz 0x00007ED4111D0270
00007ed4111d01e7  nop [rax+rax*1], ax
00007ed4111d01f0  nop [rax+rax*1], eax
00007ed4111d01f8  mov eax, 0x410854
00007ed4111d01fd  mov [r15+0x100], rax
00007ed4111d0204  jmp 0x00007ED410FFE110
00007ed4111d0209  int3
00007ed4111d020a  call 0x00007ED41100DAE0
00007ed4111d020f  jmp 0x00007ED4111CFF78
00007ed4111d0214  call 0x00007ED4110C0230
00007ed4111d0219  jmp 0x00007ED4111CFF81
00007ed4111d021e  call 0x00007ED4110E26A0
00007ed4111d0223  jmp 0x00007ED4111CFFA5
00007ed4111d0228  call 0x00007ED4110E1430
00007ed4111d022d  jmp 0x00007ED4111CFFAE
00007ed4111d0232  call 0x00007ED4110E26A0
00007ed4111d0237  jmp 0x00007ED4111CFFCF
00007ed4111d023c  call 0x00007ED4110E1430
00007ed4111d0241  jmp 0x00007ED4111CFFD8
00007ed4111d0246  call 0x00007ED4110E26A0
00007ed4111d024b  jmp 0x00007ED4111CFFF9
00007ed4111d0250  call 0x00007ED4110D5890
00007ed4111d0255  jmp 0x00007ED4111D0002
00007ed4111d025a  call 0x00007ED4110BDD50
00007ed4111d025f  jmp 0x00007ED4111D0098
00007ed4111d0264  call 0x00007ED4110DA580
00007ed4111d0269  jmp 0x00007ED4111D00CF
00007ed4111d026e  int3
00007ed4111d026f  nop
00007ed4111d0270  mov eax, [r15+0xB8]
00007ed4111d0277  mov [rsp+0x10], eax
00007ed4111d027b  mov eax, eax
00007ed4111d027d  mov [r15+0x30], rax
00007ed4111d0281  mov eax, [r15+0xC0]
00007ed4111d0288  mov [rsp+0x20], eax
00007ed4111d028c  mov eax, eax
00007ed4111d028e  mov [r15+0xA0], rax
00007ed4111d0295  mov eax, [r15+0x28]
00007ed4111d0299  mov r14d, [r15+0x98]
00007ed4111d02a0  mov [rsp+0x30], r14d
00007ed4111d02a5  mov r14d, r14d
00007ed4111d02a8  mov [r15+0x28], r14
00007ed4111d02ac  mov r14d, [r15+0x38]
00007ed4111d02b0  mov [rsp+0x40], r14d
00007ed4111d02b5  mov r14d, r14d
00007ed4111d02b8  mov [r15+0x98], r14
00007ed4111d02bf  mov r14d, [r15+0xA8]
00007ed4111d02c6  mov [rsp+0x50], r14d
00007ed4111d02cb  mov r14d, r14d
00007ed4111d02ce  mov [r15+0x38], r14
00007ed4111d02d2  mov r14d, [rsp+0x10]
00007ed4111d02d7  mov r12d, [rsp+0x10]
00007ed4111d02dc  shrd r14d, r12d, 0x06
00007ed4111d02e1  mov r11d, [r15+0xC8]
00007ed4111d02e8  mov [rsp+0x10], r12d
00007ed4111d02ed  and r12d, r11d
00007ed4111d02f0  mov r10d, [rsp+0x50]
00007ed4111d02f5  mov r9d, [rsp+0x50]
00007ed4111d02fa  shrd r10d, r9d, 0x02
00007ed4111d02ff  mov [rsp+0x50], r11d
00007ed4111d0304  mov r11d, r11d
00007ed4111d0307  mov [r15+0x20], r11
00007ed4111d030b  mov r11, [r15+0x88]
00007ed4111d0312  mov r8, [r15+0x50]
00007ed4111d0316  lea rbp, [r8+r11*1]
00007ed4111d031a  mov r8d, [r13+rbp*1]
00007ed4111d031f  mov ebp, [rsp+0x20]
00007ed4111d0323  mov edi, [rsp+0x10]
00007ed4111d0327  andn esi, edi, ebp
00007ed4111d032c  mov edx, [r15+0xB0]
00007ed4111d0333  lea ecx, [r12d+edx*1]
00007ed4111d0338  rorx r12d, edi, 0x0B
00007ed4111d033e  xor r14d, r12d
00007ed4111d0341  rorx r12d, r9d, 0x0D
00007ed4111d0347  xor r10d, r12d
00007ed4111d034a  lea r12d, [ecx+esi*1]
00007ed4111d034f  mov rsi, [r15+0x48]
00007ed4111d0353  lea rdx, [rsi+r11*1]
00007ed4111d0357  mov esi, [r13+rdx*1]
00007ed4111d035c  mov edx, [rsp+0x30]
00007ed4111d0360  mov ecx, [rsp+0x40]
00007ed4111d0364  and edx, ecx
00007ed4111d0366  mov [rsp+0x10], edx
00007ed4111d036a  mov edx, edx
00007ed4111d036c  mov [r15+0xD8], rdx
00007ed4111d0373  lea edx, [r12d+r8d*1]
00007ed4111d0378  mov r12d, [rsp+0x30]
00007ed4111d037d  xor r12d, ecx
00007ed4111d0380  rorx r8d, edi, 0x19
00007ed4111d0386  xor r14d, r8d
00007ed4111d0389  and r12d, r9d
00007ed4111d038c  rorx r8d, r9d, 0x16
00007ed4111d0392  xor r10d, r8d
00007ed4111d0395  mov [rsp+0x20], r10d
00007ed4111d039a  mov r10d, r10d
00007ed4111d039d  mov [r15+0xD0], r10
00007ed4111d03a4  lea r10d, [edx+esi*1]
00007ed4111d03a9  mov r9d, [rsp+0x10]
00007ed4111d03ae  xor r12d, r9d
00007ed4111d03b1  lea r9d, [r10d+r14d*1]
00007ed4111d03b6  lea r14, [r11+0x04]
00007ed4111d03ba  mov [r15+0x88], r14
00007ed4111d03c1  mov r11d, [rsp+0x20]
00007ed4111d03c6  lea r10d, [r12d+r11d*1]
00007ed4111d03cb  lea r11d, [r9d+eax*1]
00007ed4111d03d0  mov r11d, r11d
00007ed4111d03d3  mov [r15+0xB8], r11
00007ed4111d03da  xor eax, eax
00007ed4111d03dc  mov r12d, 0x100
00007ed4111d03e2  cmp r14, r12
00007ed4111d03e5  cmc
00007ed4111d03e6  lahf
00007ed4111d03e7  seto al
00007ed4111d03ea  mov [r15+0x108], eax
00007ed4111d03f1  lea eax, [r10d+r9d*1]
00007ed4111d03f6  mov eax, eax
00007ed4111d03f8  mov [r15+0xA8], rax
00007ed4111d03ff  mov ebp, ebp
00007ed4111d0401  mov [r15+0xB0], rbp
00007ed4111d0408  mov eax, [rsp+0x50]
00007ed4111d040c  mov eax, eax
00007ed4111d040e  mov [r15+0xC0], rax
00007ed4111d0415  mov edi, edi
00007ed4111d0417  mov [r15+0xC8], rdi
00007ed4111d041e  mov eax, [r15+0x108]
00007ed4111d0425  sahf
00007ed4111d0426  jnz 0x00007ED4111D0458
00007ed4111d0428  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0430  jz 0x00007ED4111D04A0
00007ed4111d0436  nop [rax+rax*1], ax
00007ed4111d043f  nop [rax+rax*1], eax
00007ed4111d0447  mov eax, 0x4108E0
00007ed4111d044c  mov [r15+0x100], rax
00007ed4111d0453  jmp 0x00007ED410FFE110
00007ed4111d0458  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0460  jz 0x00007ED4111D0270
00007ed4111d0466  nop [rax+rax*1], ax
00007ed4111d046f  nop [rax+rax*1], eax
00007ed4111d0477  mov eax, 0x410854
00007ed4111d047c  mov [r15+0x100], rax
00007ed4111d0483  jmp 0x00007ED410FFE110
00007ed4111d0488  int3
00007ed4111d0489  call 0x00007ED411049010
00007ed4111d048e  jmp 0x00007ED4111D031F
00007ed4111d0493  call 0x00007ED411025930
00007ed4111d0498  jmp 0x00007ED4111D035C
00007ed4111d049d  int3
00007ed4111d049e  nop
00007ed4111d04a0  mov eax, [r15+0x98]
00007ed4111d04a7  mov r14d, [r15+0x70]
00007ed4111d04ab  lea r12d, [eax+r14d*1]
00007ed4111d04b0  mov eax, [r15+0x28]
00007ed4111d04b4  mov r14d, [r15+0x68]
00007ed4111d04b8  lea r11d, [eax+r14d*1]
00007ed4111d04bd  mov qword ptr [r15+0x88], 0x00
00007ed4111d04c8  mov eax, [r15+0xA8]
00007ed4111d04cf  mov r14d, [r15+0x78]
00007ed4111d04d3  lea r10d, [eax+r14d*1]
00007ed4111d04d8  mov [rsp+0x10], r10d
00007ed4111d04dd  mov r10d, r10d
00007ed4111d04e0  mov [r15+0x78], r10
00007ed4111d04e4  mov eax, [r15+0x38]
00007ed4111d04e8  mov r14d, [r15+0x80]
00007ed4111d04ef  lea r10d, [eax+r14d*1]
00007ed4111d04f4  mov [rsp+0x20], r10d
00007ed4111d04f9  mov r10d, r10d
00007ed4111d04fc  mov [r15+0x80], r10
00007ed4111d0503  mov rax, [r15]
00007ed4111d0506  lea r14, [rax+0x08]
00007ed4111d050a  mov [r13+r14*1], r12d
00007ed4111d050f  lea r14, [rax+0x0C]
00007ed4111d0513  mov [r13+r14*1], r11d
00007ed4111d0518  mov r14d, [r15+0xB8]
00007ed4111d051f  mov r12d, [r15+0x18]
00007ed4111d0523  lea r11d, [r14d+r12d*1]
00007ed4111d0528  mov [rsp+0x30], r11d
00007ed4111d052d  mov r11d, r11d
00007ed4111d0530  mov [r15+0x68], r11
00007ed4111d0534  mov r14d, [r15+0x30]
00007ed4111d0538  mov r12d, [r15+0x90]
00007ed4111d053f  lea r11d, [r14d+r12d*1]
00007ed4111d0544  mov [rsp+0x40], r11d
00007ed4111d0549  mov r11d, r11d
00007ed4111d054c  mov [r15+0x70], r11
00007ed4111d0550  mov r14d, [r15+0x20]
00007ed4111d0554  mov r12d, [r15+0x58]
00007ed4111d0558  lea r11d, [r14d+r12d*1]
00007ed4111d055d  mov [rsp+0x50], r11d
00007ed4111d0562  mov r11d, r11d
00007ed4111d0565  mov [r15+0x58], r11
00007ed4111d0569  mov r14d, [r15+0xA0]
00007ed4111d0570  mov r12d, [r15+0x60]
00007ed4111d0574  lea r11d, [r14d+r12d*1]
00007ed4111d0579  mov [rsp+0x60], r11d
00007ed4111d057e  mov r11d, r11d
00007ed4111d0581  mov [r15+0x60], r11
00007ed4111d0585  mov r14d, [rsp+0x10]
00007ed4111d058a  mov [r13+rax*1], r14d
00007ed4111d058f  lea r14, [rax+0x04]
00007ed4111d0593  mov r12d, [rsp+0x20]
00007ed4111d0598  mov [r13+r14*1], r12d
00007ed4111d059d  lea r14, [rax+0x10]
00007ed4111d05a1  mov r12d, [rsp+0x30]
00007ed4111d05a6  mov [r13+r14*1], r12d
00007ed4111d05ab  lea r14, [rax+0x14]
00007ed4111d05af  mov r12d, [rsp+0x40]
00007ed4111d05b4  mov [r13+r14*1], r12d
00007ed4111d05b9  lea r14, [rax+0x18]
00007ed4111d05bd  mov r12d, [rsp+0x50]
00007ed4111d05c2  mov [r13+r14*1], r12d
00007ed4111d05c7  lea r14, [rax+0x1C]
00007ed4111d05cb  mov r12d, [rsp+0x60]
00007ed4111d05d0  mov [r13+r14*1], r12d
00007ed4111d05d5  lea r14, [rax+0x68]
00007ed4111d05d9  xor eax, eax
00007ed4111d05db  mov [r13+r14*1], rax
00007ed4111d05e0  cmp dword ptr [r15+0x318], 0x00
00007ed4111d05e8  jz 0x00007ED4111CF0E0
00007ed4111d05ee  nop [rax+rax*1], ax
00007ed4111d05f7  nop [rax+rax*1], eax
00007ed4111d05ff  mov eax, 0x4106FC
00007ed4111d0604  mov [r15+0x100], rax
00007ed4111d060b  jmp 0x00007ED410FFE110
00007ed4111d0610  int3
00007ed4111d0611  call 0x00007ED4110E2BA0
00007ed4111d0616  jmp 0x00007ED4111D050F
00007ed4111d061b  call 0x00007ED4110E1920
00007ed4111d0620  jmp 0x00007ED4111D0518
00007ed4111d0625  call 0x00007ED41100DFE0
00007ed4111d062a  jmp 0x00007ED4111D058F
00007ed4111d062f  call 0x00007ED4110E2BA0
00007ed4111d0634  jmp 0x00007ED4111D059D
00007ed4111d0639  call 0x00007ED4110E2BA0
00007ed4111d063e  jmp 0x00007ED4111D05AB
00007ed4111d0643  call 0x00007ED4110E2BA0
00007ed4111d0648  jmp 0x00007ED4111D05B9
00007ed4111d064d  call 0x00007ED4110E2BA0
00007ed4111d0652  jmp 0x00007ED4111D05C7
00007ed4111d0657  call 0x00007ED4110E2BA0
00007ed4111d065c  jmp 0x00007ED4111D05D5
00007ed4111d0661  call 0x00007ED4110D5EB0
00007ed4111d0666  jmp 0x00007ED4111D05E0
00007ed4111d066b  int3
00007ed4111d066c  nop [rax], eax
00007ed4111d0670  mov rax, [r15+0xF8]
00007ed4111d0677  lea r14, [rax+0x140]
00007ed4111d067e  mov r12, [r13+r14*1]
00007ed4111d0683  lea r14, [rax+0x148]
00007ed4111d068a  mov r11, [r13+r14*1]
00007ed4111d068f  mov [r15+0xA0], r12
00007ed4111d0696  mov [r15+0x98], r11
00007ed4111d069d  lea r14, [rax+0x130]
00007ed4111d06a4  mov r12, [r13+r14*1]
00007ed4111d06a9  lea r14, [rax+0x138]
00007ed4111d06b0  mov r11, [r13+r14*1]
00007ed4111d06b5  mov [r15+0xB0], r12
00007ed4111d06bc  mov [r15+0xA8], r11
00007ed4111d06c3  lea r14, [rax+0x120]
00007ed4111d06ca  mov r12, [r13+r14*1]
00007ed4111d06cf  lea r14, [rax+0x128]
00007ed4111d06d6  mov r11, [r13+r14*1]
00007ed4111d06db  mov [r15+0xC0], r12
00007ed4111d06e2  mov [r15+0xB8], r11
00007ed4111d06e9  lea r14, [rax+0x110]
00007ed4111d06f0  mov r12, [r13+r14*1]
00007ed4111d06f5  lea r14, [rax+0x118]
00007ed4111d06fc  mov r11, [r13+r14*1]
00007ed4111d0701  mov [r15+0xD0], r12
00007ed4111d0708  mov [r15+0xC8], r11
00007ed4111d070f  lea r14, [rax+0x100]
00007ed4111d0716  mov r12, [r13+r14*1]
00007ed4111d071b  lea r14, [rax+0x108]
00007ed4111d0722  mov r11, [r13+r14*1]
00007ed4111d0727  mov [r15+0xE8], r12
00007ed4111d072e  mov [r15+0xD8], r11
00007ed4111d0735  lea r14, [rax+0x150]
00007ed4111d073c  mov [r15+0xF8], r14
00007ed4111d0743  mov rax, [r15+0xF0]
00007ed4111d074a  mov [r15+0x100], rax
00007ed4111d0751  jmp 0x00007ED4111CE5C0
00007ed4111d0756  int3
00007ed4111d0757  call 0x00007ED4110E27E0
00007ed4111d075c  jmp 0x00007ED4111D0683
00007ed4111d0761  call 0x00007ED4110E1570
00007ed4111d0766  jmp 0x00007ED4111D068F
00007ed4111d076b  call 0x00007ED4110E27E0
00007ed4111d0770  jmp 0x00007ED4111D06A9
00007ed4111d0775  call 0x00007ED4110E1570
00007ed4111d077a  jmp 0x00007ED4111D06B5
00007ed4111d077f  call 0x00007ED4110E27E0
00007ed4111d0784  jmp 0x00007ED4111D06CF
00007ed4111d0789  call 0x00007ED4110E1570
00007ed4111d078e  jmp 0x00007ED4111D06DB
00007ed4111d0793  call 0x00007ED4110E27E0
00007ed4111d0798  jmp 0x00007ED4111D06F5
00007ed4111d079d  call 0x00007ED4110E1570
00007ed4111d07a2  jmp 0x00007ED4111D0701
00007ed4111d07a7  call 0x00007ED4110E27E0
00007ed4111d07ac  jmp 0x00007ED4111D071B
00007ed4111d07b1  call 0x00007ED4110E1570
00007ed4111d07b6  jmp 0x00007ED4111D0727
00007ed4111d07bb  int3
00007ed4111d07bc  nop [rax], eax
00007ed4111d07c0  mov eax, [r15+0xA0]
00007ed4111d07c7  mov [rsp+0x10], eax
00007ed4111d07cb  xor eax, eax
00007ed4111d07cd  mov r14d, [rsp+0x10]
00007ed4111d07d2  sub r14d, 0x01
00007ed4111d07d6  cmc
00007ed4111d07d7  lahf
00007ed4111d07d8  seto al
00007ed4111d07db  mov [r15+0x108], eax
00007ed4111d07e2  mov r14d, r14d
00007ed4111d07e5  mov [r15+0xA0], r14
00007ed4111d07ec  mov eax, [r15+0x108]
00007ed4111d07f3  sahf
00007ed4111d07f4  jnz 0x00007ED4111D0826
00007ed4111d07f6  cmp dword ptr [r15+0x318], 0x00
00007ed4111d07fe  jz 0x00007ED4111D0900
00007ed4111d0804  nop [rax+rax*1], ax
00007ed4111d080d  nop [rax+rax*1], eax
00007ed4111d0815  mov eax, 0x41028C
00007ed4111d081a  mov [r15+0x100], rax
00007ed4111d0821  jmp 0x00007ED410FFE110
00007ed4111d0826  cmp dword ptr [r15+0x318], 0x00
00007ed4111d082e  jz 0x00007ED4111D0860
00007ed4111d0834  nop [rax+rax*1], ax
00007ed4111d083d  nop [rax+rax*1], eax
00007ed4111d0845  mov eax, 0x410274
00007ed4111d084a  mov [r15+0x100], rax
00007ed4111d0851  jmp 0x00007ED410FFE110
00007ed4111d0856  int3
00007ed4111d0857  int3
00007ed4111d0858  nop [rax+rax*1], eax
00007ed4111d0860  mov rax, [r15+0xF8]
00007ed4111d0867  lea r14, [rax+0xD0]
00007ed4111d086e  mov [r15], r14
00007ed4111d0871  mov rax, [r15+0x98]
00007ed4111d0878  mov [r15+0x08], rax
00007ed4111d087c  mov qword ptr [r15+0x10], 0x12C
00007ed4111d0884  mov qword ptr [r15+0xF0], 0x410284
00007ed4111d088f  mov r14d, [r15+0x320]
00007ed4111d0896  mov eax, 0x410284
00007ed4111d089b  mov rcx, 0x7ED4111D07C0
00007ed4111d08a5  mov [r15+r14*8+0x328], rax
00007ed4111d08ad  mov [r15+r14*8+0x368], rcx
00007ed4111d08b5  add r14d, 0x01
00007ed4111d08b9  and r14d, 0x07
00007ed4111d08bd  mov [r15+0x320], r14d
00007ed4111d08c4  cmp dword ptr [r15+0x318], 0x00
00007ed4111d08cc  jz 0x00007ED4111CED70
00007ed4111d08d2  nop [rax+rax*1], ax
00007ed4111d08db  nop [rax+rax*1], eax
00007ed4111d08e3  mov eax, 0x4106BC
00007ed4111d08e8  mov [r15+0x100], rax
00007ed4111d08ef  jmp 0x00007ED410FFE110
00007ed4111d08f4  int3
00007ed4111d08f5  int3
00007ed4111d08f6  nop [rax+rax*1], ax
00007ed4111d08ff  nop
00007ed4111d0900  mov rax, [r15+0xF8]
00007ed4111d0907  lea r14, [rax+0xF0]
00007ed4111d090e  mov r12, [r13+r14*1]
00007ed4111d0913  mov [r15+0x98], r12
00007ed4111d091a  mov qword ptr [r15+0x40], 0x80
00007ed4111d0922  lea r14, [rax+0xD0]
00007ed4111d0929  mov [r15], r14
00007ed4111d092c  lea r14, [rax+0x14C]
00007ed4111d0933  mov [r15+0x08], r14
00007ed4111d0937  mov qword ptr [r15+0x10], 0x01
00007ed4111d093f  lea r14, [rax+0x14C]
00007ed4111d0946  mov eax, 0x80
00007ed4111d094b  mov [r13+r14*1], al
00007ed4111d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007ed4111d095b  mov r14d, [r15+0x320]
00007ed4111d0962  mov eax, 0x4102A8
00007ed4111d0967  mov rcx, 0x7ED4111D09E0
00007ed4111d0971  mov [r15+r14*8+0x328], rax
00007ed4111d0979  mov [r15+r14*8+0x368], rcx
00007ed4111d0981  add r14d, 0x01
00007ed4111d0985  and r14d, 0x07
00007ed4111d0989  mov [r15+0x320], r14d
00007ed4111d0990  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0998  jz 0x00007ED4111CED70
00007ed4111d099e  nop [rax+rax*1], ax
00007ed4111d09a7  nop [rax+rax*1], eax
00007ed4111d09af  mov eax, 0x4106BC
00007ed4111d09b4  mov [r15+0x100], rax
00007ed4111d09bb  jmp 0x00007ED410FFE110
00007ed4111d09c0  int3
00007ed4111d09c1  call 0x00007ED4110E27E0
00007ed4111d09c6  jmp 0x00007ED4111D0913
00007ed4111d09cb  call 0x00007ED4110D5AF0
00007ed4111d09d0  jmp 0x00007ED4111D0950
00007ed4111d09d5  int3
00007ed4111d09d6  nop [rax+rax*1], ax
00007ed4111d09df  nop
00007ed4111d09e0  mov rax, [r15+0xF8]
00007ed4111d09e7  lea r14, [rax+0x138]
00007ed4111d09ee  mov r12, [r13+r14*1]
00007ed4111d09f3  mov [r15+0x40], r12
00007ed4111d09f7  lea r14, [rax+0x148]
00007ed4111d09fe  xor eax, eax
00007ed4111d0a00  mov [r13+r14*1], al
00007ed4111d0a05  xor eax, eax
00007ed4111d0a07  mov r14d, 0x38
00007ed4111d0a0d  cmp r12, r14
00007ed4111d0a10  cmc
00007ed4111d0a11  lahf
00007ed4111d0a12  seto al
00007ed4111d0a15  mov [r15+0x108], eax
00007ed4111d0a1c  mov eax, [r15+0x108]
00007ed4111d0a23  sahf
00007ed4111d0a24  jz 0x00007ED4111D0A56
00007ed4111d0a26  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0a2e  jz 0x00007ED4111D0AA0
00007ed4111d0a34  nop [rax+rax*1], ax
00007ed4111d0a3d  nop [rax+rax*1], eax
00007ed4111d0a45  mov eax, 0x4102B8
00007ed4111d0a4a  mov [r15+0x100], rax
00007ed4111d0a51  jmp 0x00007ED410FFE110
00007ed4111d0a56  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0a5e  jz 0x00007ED4111D0BF0
00007ed4111d0a64  nop [rax+rax*1], ax
00007ed4111d0a6d  nop [rax+rax*1], eax
00007ed4111d0a75  mov eax, 0x4102D4
00007ed4111d0a7a  mov [r15+0x100], rax
00007ed4111d0a81  jmp 0x00007ED410FFE110
00007ed4111d0a86  int3
00007ed4111d0a87  call 0x00007ED4110E27E0
00007ed4111d0a8c  jmp 0x00007ED4111D09F3
00007ed4111d0a91  call 0x00007ED4110D5AF0
00007ed4111d0a96  jmp 0x00007ED4111D0A05
00007ed4111d0a9b  int3
00007ed4111d0a9c  nop [rax], eax
00007ed4111d0aa0  mov rax, [r15+0xF8]
00007ed4111d0aa7  lea r14, [rax+0xD0]
00007ed4111d0aae  mov [r15], r14
00007ed4111d0ab1  lea r14, [rax+0x148]
00007ed4111d0ab8  mov [r15+0x08], r14
00007ed4111d0abc  mov qword ptr [r15+0x10], 0x01
00007ed4111d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007ed4111d0acf  mov r14d, [r15+0x320]
00007ed4111d0ad6  mov eax, 0x4102C8
00007ed4111d0adb  mov rcx, 0x7ED4111D0B40
00007ed4111d0ae5  mov [r15+r14*8+0x328], rax
00007ed4111d0aed  mov [r15+r14*8+0x368], rcx
00007ed4111d0af5  add r14d, 0x01
00007ed4111d0af9  and r14d, 0x07
00007ed4111d0afd  mov [r15+0x320], r14d
00007ed4111d0b04  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0b0c  jz 0x00007ED4111CED70
00007ed4111d0b12  nop [rax+rax*1], ax
00007ed4111d0b1b  nop [rax+rax*1], eax
00007ed4111d0b23  mov eax, 0x4106BC
00007ed4111d0b28  mov [r15+0x100], rax
00007ed4111d0b2f  jmp 0x00007ED410FFE110
00007ed4111d0b34  int3
00007ed4111d0b35  int3
00007ed4111d0b36  nop [rax+rax*1], ax
00007ed4111d0b3f  nop
00007ed4111d0b40  mov rax, [r15+0xF8]
00007ed4111d0b47  lea r14, [rax+0x138]
00007ed4111d0b4e  mov rax, [r13+r14*1]
00007ed4111d0b53  mov [r15+0x40], rax
00007ed4111d0b57  mov [rsp+0x10], rax
00007ed4111d0b5c  xor eax, eax
00007ed4111d0b5e  mov r14, [rsp+0x10]
00007ed4111d0b63  mov r12d, 0x38
00007ed4111d0b69  cmp r14, r12
00007ed4111d0b6c  cmc
00007ed4111d0b6d  lahf
00007ed4111d0b6e  seto al
00007ed4111d0b71  mov [r15+0x108], eax
00007ed4111d0b78  mov eax, [r15+0x108]
00007ed4111d0b7f  sahf
00007ed4111d0b80  jnz 0x00007ED4111D0BB2
00007ed4111d0b82  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0b8a  jz 0x00007ED4111D0BF0
00007ed4111d0b90  nop [rax+rax*1], ax
00007ed4111d0b99  nop [rax+rax*1], eax
00007ed4111d0ba1  mov eax, 0x4102D4
00007ed4111d0ba6  mov [r15+0x100], rax
00007ed4111d0bad  jmp 0x00007ED410FFE110
00007ed4111d0bb2  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0bba  jz 0x00007ED4111D0AA0
00007ed4111d0bc0  nop [rax+rax*1], ax
00007ed4111d0bc9  nop [rax+rax*1], eax
00007ed4111d0bd1  mov eax, 0x4102B8
00007ed4111d0bd6  mov [r15+0x100], rax
00007ed4111d0bdd  jmp 0x00007ED410FFE110
00007ed4111d0be2  int3
00007ed4111d0be3  call 0x00007ED4110D59C0
00007ed4111d0be8  jmp 0x00007ED4111D0B53
00007ed4111d0bed  int3
00007ed4111d0bee  nop
00007ed4111d0bf0  mov rax, [r15+0x98]
00007ed4111d0bf7  rorx r14, rax, 0x3D
00007ed4111d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007ed4111d0c01  mov rax, [r15+0xF8]
00007ed4111d0c08  lea r12, [rax+0xD0]
00007ed4111d0c0f  mov [r15], r12
00007ed4111d0c12  lea r12, [rax+0x140]
00007ed4111d0c19  mov [r15+0x08], r12
00007ed4111d0c1d  mov qword ptr [r15+0x10], 0x08
00007ed4111d0c25  bswap r14
00007ed4111d0c28  mov [r15+0x40], r14
00007ed4111d0c2c  lea r12, [rax+0x140]
00007ed4111d0c33  mov [r13+r12*1], r14
00007ed4111d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007ed4111d0c43  mov r14d, [r15+0x320]
00007ed4111d0c4a  mov eax, 0x4102F0
00007ed4111d0c4f  mov rcx, 0x7ED4111D0CC0
00007ed4111d0c59  mov [r15+r14*8+0x328], rax
00007ed4111d0c61  mov [r15+r14*8+0x368], rcx
00007ed4111d0c69  add r14d, 0x01
00007ed4111d0c6d  and r14d, 0x07
00007ed4111d0c71  mov [r15+0x320], r14d
00007ed4111d0c78  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0c80  jz 0x00007ED4111CED70
00007ed4111d0c86  nop [rax+rax*1], ax
00007ed4111d0c8f  nop [rax+rax*1], eax
00007ed4111d0c97  mov eax, 0x4106BC
00007ed4111d0c9c  mov [r15+0x100], rax
00007ed4111d0ca3  jmp 0x00007ED410FFE110
00007ed4111d0ca8  int3
00007ed4111d0ca9  call 0x00007ED4110C3FE0
00007ed4111d0cae  jmp 0x00007ED4111D0C38
00007ed4111d0cb3  int3
00007ed4111d0cb4  nop [rax+rax*1], ax
00007ed4111d0cbd  nop [rax], eax
00007ed4111d0cc0  mov rax, [r15+0xF8]
00007ed4111d0cc7  lea r14, [rax+0xD0]
00007ed4111d0cce  mov r12d, [r13+r14*1]
00007ed4111d0cd3  lea r14, [rax+0xD4]
00007ed4111d0cda  mov r11d, [r13+r14*1]
00007ed4111d0cdf  lea r14, [rax+0xD8]
00007ed4111d0ce6  mov r10d, [r13+r14*1]
00007ed4111d0ceb  lea r14, [rax+0xDC]
00007ed4111d0cf2  mov r9d, [r13+r14*1]
00007ed4111d0cf7  mov qword ptr [r15+0x48], 0x430C20
00007ed4111d0cff  mov qword ptr [r15+0xA0], 0x00
00007ed4111d0d0a  bswap r12d
00007ed4111d0d0d  bswap r11d
00007ed4111d0d10  mov qword ptr [r15+0x98], 0x430D8C
00007ed4111d0d1b  mov r14d, 0x430C20
00007ed4111d0d21  mov [r13+r14*1], r12d
00007ed4111d0d26  mov r14d, 0x430C24
00007ed4111d0d2c  mov [r13+r14*1], r11d
00007ed4111d0d31  bswap r10d
00007ed4111d0d34  bswap r9d
00007ed4111d0d37  lea r14, [rax+0xE0]
00007ed4111d0d3e  mov r12d, [r13+r14*1]
00007ed4111d0d43  lea r14, [rax+0xE4]
00007ed4111d0d4a  mov r11d, [r13+r14*1]
00007ed4111d0d4f  mov r14d, 0x430C28
00007ed4111d0d55  mov [r13+r14*1], r10d
00007ed4111d0d5a  mov r14d, 0x430C2C
00007ed4111d0d60  mov [r13+r14*1], r9d
00007ed4111d0d65  bswap r12d
00007ed4111d0d68  bswap r11d
00007ed4111d0d6b  mov [rsp+0x10], r11d
00007ed4111d0d70  mov r11d, r11d
00007ed4111d0d73  mov [r15+0x58], r11
00007ed4111d0d77  lea r14, [rax+0xE8]
00007ed4111d0d7e  mov r11d, [r13+r14*1]
00007ed4111d0d83  lea r14, [rax+0xEC]
00007ed4111d0d8a  mov eax, [r13+r14*1]
00007ed4111d0d8f  mov [rsp+0x20], eax
00007ed4111d0d93  mov eax, eax
00007ed4111d0d95  mov [r15+0x60], rax
00007ed4111d0d99  mov eax, 0x430C30
00007ed4111d0d9e  mov [r13+rax*1], r12d
00007ed4111d0da3  mov eax, 0x430C34
00007ed4111d0da8  mov r14d, [rsp+0x10]
00007ed4111d0dad  mov [r13+rax*1], r14d
00007ed4111d0db2  bswap r11d
00007ed4111d0db5  mov [rsp+0x10], r11d
00007ed4111d0dba  mov r11d, r11d
00007ed4111d0dbd  mov [r15+0x40], r11
00007ed4111d0dc1  mov eax, [rsp+0x20]
00007ed4111d0dc5  bswap eax
00007ed4111d0dc7  mov [rsp+0x20], eax
00007ed4111d0dcb  mov eax, eax
00007ed4111d0dcd  mov [r15+0x50], rax
00007ed4111d0dd1  mov eax, 0x430C38
00007ed4111d0dd6  mov r14d, [rsp+0x10]
00007ed4111d0ddb  mov [r13+rax*1], r14d
00007ed4111d0de0  mov eax, 0x430C3C
00007ed4111d0de5  mov r14d, [rsp+0x20]
00007ed4111d0dea  mov [r13+rax*1], r14d
00007ed4111d0def  mov eax, [r15+0xA0]
00007ed4111d0df6  lea r14d, [eax+0x11]
00007ed4111d0dfb  mov r14d, r14d
00007ed4111d0dfe  mov [r15], r14
00007ed4111d0e01  mov qword ptr [r15+0xF0], 0x41034C
00007ed4111d0e0c  mov r14d, [r15+0x320]
00007ed4111d0e13  mov eax, 0x41034C
00007ed4111d0e18  mov rcx, 0x7ED4111D0F90
00007ed4111d0e22  mov [r15+r14*8+0x328], rax
00007ed4111d0e2a  mov [r15+r14*8+0x368], rcx
00007ed4111d0e32  add r14d, 0x01
00007ed4111d0e36  and r14d, 0x07
00007ed4111d0e3a  mov [r15+0x320], r14d
00007ed4111d0e41  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0e49  jz 0x00007ED4111D0F20
00007ed4111d0e4f  nop [rax+rax*1], ax
00007ed4111d0e58  nop [rax+rax*1], eax
00007ed4111d0e60  mov eax, 0x410938
00007ed4111d0e65  mov [r15+0x100], rax
00007ed4111d0e6c  jmp 0x00007ED410FFE110
00007ed4111d0e71  int3
00007ed4111d0e72  call 0x00007ED4110E26A0
00007ed4111d0e77  jmp 0x00007ED4111D0CD3
00007ed4111d0e7c  call 0x00007ED4110E1430
00007ed4111d0e81  jmp 0x00007ED4111D0CDF
00007ed4111d0e86  call 0x00007ED4110E01C0
00007ed4111d0e8b  jmp 0x00007ED4111D0CEB
00007ed4111d0e90  call 0x00007ED4110DEF50
00007ed4111d0e95  jmp 0x00007ED4111D0CF7
00007ed4111d0e9a  call 0x00007ED4110E2BA0
00007ed4111d0e9f  jmp 0x00007ED4111D0D26
00007ed4111d0ea4  call 0x00007ED4110E1920
00007ed4111d0ea9  jmp 0x00007ED4111D0D31
00007ed4111d0eae  call 0x00007ED4110E26A0
00007ed4111d0eb3  jmp 0x00007ED4111D0D43
00007ed4111d0eb8  call 0x00007ED4110E1430
00007ed4111d0ebd  jmp 0x00007ED4111D0D4F
00007ed4111d0ec2  call 0x00007ED4110E06B0
00007ed4111d0ec7  jmp 0x00007ED4111D0D5A
00007ed4111d0ecc  call 0x00007ED4110DF440
00007ed4111d0ed1  jmp 0x00007ED4111D0D65
00007ed4111d0ed6  call 0x00007ED4110E1430
00007ed4111d0edb  jmp 0x00007ED4111D0D83
00007ed4111d0ee0  call 0x00007ED4110D5890
00007ed4111d0ee5  jmp 0x00007ED4111D0D8F
00007ed4111d0eea  call 0x00007ED41100BAE0
00007ed4111d0eef  jmp 0x00007ED4111D0DA3
00007ed4111d0ef4  call 0x00007ED41100DFE0
00007ed4111d0ef9  jmp 0x00007ED4111D0DB2
00007ed4111d0efe  call 0x00007ED41100DFE0
00007ed4111d0f03  jmp 0x00007ED4111D0DE0
00007ed4111d0f08  call 0x00007ED41100DFE0
00007ed4111d0f0d  jmp 0x00007ED4111D0DEF
00007ed4111d0f12  int3
00007ed4111d0f13  nop [rax+rax*1], ax
00007ed4111d0f1c  nop [rax], eax
00007ed4111d0f20  mov eax, [r15]
00007ed4111d0f23  mov [rsp+0x10], eax
00007ed4111d0f27  shr eax, 0x10
00007ed4111d0f2a  mov r14d, [rsp+0x10]
00007ed4111d0f2f  xor r14d, eax
00007ed4111d0f32  imul r14d, r14d, 0x7FEB352D
00007ed4111d0f39  mov eax, 0x846CA68B
00007ed4111d0f3e  mov eax, eax
00007ed4111d0f40  mov [r15+0x48], rax
00007ed4111d0f44  mov [rsp+0x10], r14d
00007ed4111d0f49  shr r14d, 0x0F
00007ed4111d0f4d  mov eax, [rsp+0x10]
00007ed4111d0f51  xor eax, r14d
00007ed4111d0f54  imul eax, eax, 0x846CA68B
00007ed4111d0f5a  mov [rsp+0x10], eax
00007ed4111d0f5e  mov eax, eax
00007ed4111d0f60  mov [r15+0x40], rax
00007ed4111d0f64  mov eax, [rsp+0x10]
00007ed4111d0f68  shr eax, 0x10
00007ed4111d0f6b  mov r14d, [rsp+0x10]
00007ed4111d0f70  xor r14d, eax
00007ed4111d0f73  mov r14d, r14d
00007ed4111d0f76  mov [r15], r14
00007ed4111d0f79  mov rax, [r15+0xF0]
00007ed4111d0f80  mov [r15+0x100], rax
00007ed4111d0f87  jmp 0x00007ED4111CE5C0
00007ed4111d0f8c  int3
00007ed4111d0f8d  int3
00007ed4111d0f8e  nop
00007ed4111d0f90  mov rax, [r15+0xA0]
00007ed4111d0f97  mov [rsp+0x10], rax
00007ed4111d0f9c  shl rax, 0x02
00007ed4111d0fa0  mov r14, [r15+0x98]
00007ed4111d0fa7  lea r12, [r14+rax*1]
00007ed4111d0fab  mov eax, [r15]
00007ed4111d0fae  mov [r13+r12*1], eax
00007ed4111d0fb3  mov rax, [rsp+0x10]
00007ed4111d0fb8  lea r14, [rax+0x01]
00007ed4111d0fbc  mov [r15+0xA0], r14
00007ed4111d0fc3  xor eax, eax
00007ed4111d0fc5  mov r12d, 0x400
00007ed4111d0fcb  cmp r14, r12
00007ed4111d0fce  cmc
00007ed4111d0fcf  lahf
00007ed4111d0fd0  seto al
00007ed4111d0fd3  mov [r15+0x108], eax
00007ed4111d0fda  mov eax, [r15+0x108]
00007ed4111d0fe1  sahf
00007ed4111d0fe2  jnz 0x00007ED4111D1014
00007ed4111d0fe4  cmp dword ptr [r15+0x318], 0x00
00007ed4111d0fec  jz 0x00007ED4111D10E0
00007ed4111d0ff2  nop [rax+rax*1], ax
00007ed4111d0ffb  nop [rax+rax*1], eax
00007ed4111d1003  mov eax, 0x41035C
00007ed4111d1008  mov [r15+0x100], rax
00007ed4111d100f  jmp 0x00007ED410FFE110
00007ed4111d1014  cmp dword ptr [r15+0x318], 0x00
00007ed4111d101c  jz 0x00007ED4111D1050
00007ed4111d1022  nop [rax+rax*1], ax
00007ed4111d102b  nop [rax+rax*1], eax
00007ed4111d1033  mov eax, 0x410344
00007ed4111d1038  mov [r15+0x100], rax
00007ed4111d103f  jmp 0x00007ED410FFE110
00007ed4111d1044  int3
00007ed4111d1045  call 0x00007ED4110B4B70
00007ed4111d104a  jmp 0x00007ED4111D0FB3
00007ed4111d104f  int3
00007ed4111d1050  mov eax, [r15+0xA0]
00007ed4111d1057  lea r14d, [eax+0x11]
00007ed4111d105c  mov r14d, r14d
00007ed4111d105f  mov [r15], r14
00007ed4111d1062  mov qword ptr [r15+0xF0], 0x41034C
00007ed4111d106d  mov r14d, [r15+0x320]
00007ed4111d1074  mov eax, 0x41034C
00007ed4111d1079  mov rcx, 0x7ED4111D0F90
00007ed4111d1083  mov [r15+r14*8+0x328], rax
00007ed4111d108b  mov [r15+r14*8+0x368], rcx
00007ed4111d1093  add r14d, 0x01
00007ed4111d1097  and r14d, 0x07
00007ed4111d109b  mov [r15+0x320], r14d
00007ed4111d10a2  cmp dword ptr [r15+0x318], 0x00
00007ed4111d10aa  jz 0x00007ED4111D0F20
00007ed4111d10b0  nop [rax+rax*1], ax
00007ed4111d10b9  nop [rax+rax*1], eax
00007ed4111d10c1  mov eax, 0x410938
00007ed4111d10c6  mov [r15+0x100], rax
00007ed4111d10cd  jmp 0x00007ED410FFE110
00007ed4111d10d2  int3
00007ed4111d10d3  int3
00007ed4111d10d4  nop [rax+rax*1], ax
00007ed4111d10dd  nop [rax], eax
00007ed4111d10e0  mov qword ptr [r15+0x40], 0x01
00007ed4111d10e8  cmp dword ptr [r15+0x318], 0x00
00007ed4111d10f0  jz 0x00007ED4111D1120
00007ed4111d10f6  nop [rax+rax*1], ax
00007ed4111d10ff  nop [rax+rax*1], eax
00007ed4111d1107  mov eax, 0x410378
00007ed4111d110c  mov [r15+0x100], rax
00007ed4111d1113  jmp 0x00007ED410FFE110
00007ed4111d1118  int3
00007ed4111d1119  int3
00007ed4111d111a  nop [rax+rax*1], ax
00007ed4111d1120  mov rax, [r15+0x40]
00007ed4111d1124  mov [rsp+0x10], rax
00007ed4111d1129  shl rax, 0x02
00007ed4111d112d  mov r14, [r15+0x98]
00007ed4111d1134  lea r12, [r14+rax*1]
00007ed4111d1138  mov eax, [r13+r12*1]
00007ed4111d113d  mov [rsp+0x20], eax
00007ed4111d1141  mov eax, eax
00007ed4111d1143  mov [r15+0x48], rax
00007ed4111d1147  mov rax, [rsp+0x10]
00007ed4111d114c  mov [r15+0x50], rax
00007ed4111d1150  mov eax, [r15+0x50]
00007ed4111d1154  lea r12d, [eax-0x01]
00007ed4111d1159  mov r12d, r12d
00007ed4111d115c  mov [r15+0x58], r12
00007ed4111d1160  mov rax, [r15+0x58]
00007ed4111d1164  mov r12d, eax
00007ed4111d1167  mov r12d, r12d
00007ed4111d116a  shl r12, 0x02
00007ed4111d116e  lea rax, [r14+r12*1]
00007ed4111d1172  mov r14d, [r13+rax*1]
00007ed4111d1177  mov [rsp+0x10], r14d
00007ed4111d117c  mov r14d, r14d
00007ed4111d117f  mov [r15+0x60], r14
00007ed4111d1183  xor eax, eax
00007ed4111d1185  mov r14d, [rsp+0x10]
00007ed4111d118a  mov r12d, [rsp+0x20]
00007ed4111d118f  cmp r14d, r12d
00007ed4111d1192  cmc
00007ed4111d1193  lahf
00007ed4111d1194  seto al
00007ed4111d1197  mov [r15+0x108], eax
00007ed4111d119e  mov eax, [r15+0x108]
00007ed4111d11a5  sahf
00007ed4111d11a6  cmc
00007ed4111d11a7  jbe 0x00007ED4111D11D9
00007ed4111d11a9  cmp dword ptr [r15+0x318], 0x00
00007ed4111d11b1  jz 0x00007ED4111D1220
00007ed4111d11b7  nop [rax+rax*1], ax
00007ed4111d11c0  nop [rax+rax*1], eax
00007ed4111d11c8  mov eax, 0x410390
00007ed4111d11cd  mov [r15+0x100], rax
00007ed4111d11d4  jmp 0x00007ED410FFE110
00007ed4111d11d9  cmp dword ptr [r15+0x318], 0x00
00007ed4111d11e1  jz 0x00007ED4111D14C0
00007ed4111d11e7  nop [rax+rax*1], ax
00007ed4111d11f0  nop [rax+rax*1], eax
00007ed4111d11f8  mov eax, 0x410368
00007ed4111d11fd  mov [r15+0x100], rax
00007ed4111d1204  jmp 0x00007ED410FFE110
00007ed4111d1209  int3
00007ed4111d120a  call 0x00007ED4110B4690
00007ed4111d120f  jmp 0x00007ED4111D113D
00007ed4111d1214  call 0x00007ED41100DAE0
00007ed4111d1219  jmp 0x00007ED4111D1177
00007ed4111d121e  int3
00007ed4111d121f  nop
00007ed4111d1220  mov rax, [r15+0x50]
00007ed4111d1224  mov [rsp+0x10], rax
00007ed4111d1229  shl rax, 0x02
00007ed4111d122d  mov r14, [r15+0x98]
00007ed4111d1234  lea r12, [r14+rax*1]
00007ed4111d1238  mov eax, [r15+0x60]
00007ed4111d123c  mov [r13+r12*1], eax
00007ed4111d1241  mov rax, [rsp+0x10]
00007ed4111d1246  lea r14, [rax-0x01]
00007ed4111d124a  mov [r15+0x50], r14
00007ed4111d124e  mov rax, [r15+0x58]
00007ed4111d1252  test rax, rax
00007ed4111d1255  setz al
00007ed4111d1258  movzx rax, al
00007ed4111d125c  mov [rsp+0x414], al
00007ed4111d1263  cmp byte ptr [rsp+0x414], 0x00
00007ed4111d126b  jz 0x00007ED4111D129D
00007ed4111d126d  cmp dword ptr [r15+0x318], 0x00
00007ed4111d1275  jz 0x00007ED4111D12E0
00007ed4111d127b  nop [rax+rax*1], ax
00007ed4111d1284  nop [rax+rax*1], eax
00007ed4111d128c  mov eax, 0x41039C
00007ed4111d1291  mov [r15+0x100], rax
00007ed4111d1298  jmp 0x00007ED410FFE110
00007ed4111d129d  cmp dword ptr [r15+0x318], 0x00
00007ed4111d12a5  jz 0x00007ED4111D13E0
00007ed4111d12ab  nop [rax+rax*1], ax
00007ed4111d12b4  nop [rax+rax*1], eax
00007ed4111d12bc  mov eax, 0x410380
00007ed4111d12c1  mov [r15+0x100], rax
00007ed4111d12c8  jmp 0x00007ED410FFE110
00007ed4111d12cd  int3
00007ed4111d12ce  call 0x00007ED4110B4B70
00007ed4111d12d3  jmp 0x00007ED4111D1241
00007ed4111d12d8  int3
00007ed4111d12d9  nop [rax], eax
00007ed4111d12e0  cmp dword ptr [r15+0x318], 0x00
00007ed4111d12e8  jz 0x00007ED4111D1320
00007ed4111d12ee  nop [rax+rax*1], ax
00007ed4111d12f7  nop [rax+rax*1], eax
00007ed4111d12ff  mov eax, 0x410364
00007ed4111d1304  mov [r15+0x100], rax
00007ed4111d130b  jmp 0x00007ED410FFE110
00007ed4111d1310  int3
00007ed4111d1311  int3
00007ed4111d1312  nop [rax+rax*1], ax
00007ed4111d131b  nop [rax+rax*1], eax
00007ed4111d1320  mov qword ptr [r15+0x50], 0x00
00007ed4111d1328  mov rax, [r15+0x40]
00007ed4111d132c  lea r14, [rax+0x01]
00007ed4111d1330  mov [r15+0x40], r14
00007ed4111d1334  mov rax, [r15+0x98]
00007ed4111d133b  mov r12d, [r15+0x48]
00007ed4111d133f  mov [r13+rax*1], r12d
00007ed4111d1344  xor eax, eax
00007ed4111d1346  mov r12d, 0x400
00007ed4111d134c  cmp r14, r12
00007ed4111d134f  cmc
00007ed4111d1350  lahf
00007ed4111d1351  seto al
00007ed4111d1354  mov [r15+0x108], eax
00007ed4111d135b  mov eax, [r15+0x108]
00007ed4111d1362  sahf
00007ed4111d1363  jz 0x00007ED4111D1395
00007ed4111d1365  cmp dword ptr [r15+0x318], 0x00
00007ed4111d136d  jz 0x00007ED4111D1120
00007ed4111d1373  nop [rax+rax*1], ax
00007ed4111d137c  nop [rax+rax*1], eax
00007ed4111d1384  mov eax, 0x410378
00007ed4111d1389  mov [r15+0x100], rax
00007ed4111d1390  jmp 0x00007ED410FFE110
00007ed4111d1395  cmp dword ptr [r15+0x318], 0x00
00007ed4111d139d  jz 0x00007ED4111D1580
00007ed4111d13a3  nop [rax+rax*1], ax
00007ed4111d13ac  nop [rax+rax*1], eax
00007ed4111d13b4  mov eax, 0x4103A0
00007ed4111d13b9  mov [r15+0x100], rax
00007ed4111d13c0  jmp 0x00007ED410FFE110
00007ed4111d13c5  int3
00007ed4111d13c6  call 0x00007ED41100BAE0
00007ed4111d13cb  jmp 0x00007ED4111D1344
00007ed4111d13d0  int3
00007ed4111d13d1  nop [rax+rax*1], ax
00007ed4111d13da  nop [rax+rax*1], ax
00007ed4111d13e0  mov eax, [r15+0x50]
00007ed4111d13e4  lea r14d, [eax-0x01]
00007ed4111d13e9  mov r14d, r14d
00007ed4111d13ec  mov [r15+0x58], r14
00007ed4111d13f0  mov rax, [r15+0x58]
00007ed4111d13f4  mov r14d, eax
00007ed4111d13f7  mov r14d, r14d
00007ed4111d13fa  shl r14, 0x02
00007ed4111d13fe  mov rax, [r15+0x98]
00007ed4111d1405  lea r12, [rax+r14*1]
00007ed4111d1409  mov eax, [r13+r12*1]
00007ed4111d140e  mov [rsp+0x10], eax
00007ed4111d1412  mov eax, eax
00007ed4111d1414  mov [r15+0x60], rax
00007ed4111d1418  mov eax, [r15+0x48]
00007ed4111d141c  mov [rsp+0x20], eax
00007ed4111d1420  xor eax, eax
00007ed4111d1422  mov r14d, [rsp+0x10]
00007ed4111d1427  mov r12d, [rsp+0x20]
00007ed4111d142c  cmp r14d, r12d
00007ed4111d142f  cmc
00007ed4111d1430  lahf
00007ed4111d1431  seto al
00007ed4111d1434  mov [r15+0x108], eax
00007ed4111d143b  mov eax, [r15+0x108]
00007ed4111d1442  sahf
00007ed4111d1443  cmc
00007ed4111d1444  jbe 0x00007ED4111D1476
00007ed4111d1446  cmp dword ptr [r15+0x318], 0x00
00007ed4111d144e  jz 0x00007ED4111D1220
00007ed4111d1454  nop [rax+rax*1], ax
00007ed4111d145d  nop [rax+rax*1], eax
00007ed4111d1465  mov eax, 0x410390
00007ed4111d146a  mov [r15+0x100], rax
00007ed4111d1471  jmp 0x00007ED410FFE110
00007ed4111d1476  cmp dword ptr [r15+0x318], 0x00
00007ed4111d147e  jz 0x00007ED4111D14C0
00007ed4111d1484  nop [rax+rax*1], ax
00007ed4111d148d  nop [rax+rax*1], eax
00007ed4111d1495  mov eax, 0x410368
00007ed4111d149a  mov [r15+0x100], rax
00007ed4111d14a1  jmp 0x00007ED410FFE110
00007ed4111d14a6  int3
00007ed4111d14a7  call 0x00007ED4110B4690
00007ed4111d14ac  jmp 0x00007ED4111D140E
00007ed4111d14b1  int3
00007ed4111d14b2  nop [rax+rax*1], ax
00007ed4111d14bb  nop [rax+rax*1], eax
00007ed4111d14c0  mov rax, [r15+0x40]
00007ed4111d14c4  lea r14, [rax+0x01]
00007ed4111d14c8  mov [r15+0x40], r14
00007ed4111d14cc  mov rax, [r15+0x50]
00007ed4111d14d0  mov r12d, eax
00007ed4111d14d3  mov r12d, r12d
00007ed4111d14d6  shl r12, 0x02
00007ed4111d14da  mov rax, [r15+0x98]
00007ed4111d14e1  lea r11, [rax+r12*1]
00007ed4111d14e5  mov eax, [r15+0x48]
00007ed4111d14e9  mov [r13+r11*1], eax
00007ed4111d14ee  xor eax, eax
00007ed4111d14f0  mov r12d, 0x400
00007ed4111d14f6  cmp r14, r12
00007ed4111d14f9  cmc
00007ed4111d14fa  lahf
00007ed4111d14fb  seto al
00007ed4111d14fe  mov [r15+0x108], eax
00007ed4111d1505  mov eax, [r15+0x108]
00007ed4111d150c  sahf
00007ed4111d150d  jz 0x00007ED4111D153F
00007ed4111d150f  cmp dword ptr [r15+0x318], 0x00
00007ed4111d1517  jz 0x00007ED4111D1120
00007ed4111d151d  nop [rax+rax*1], ax
00007ed4111d1526  nop [rax+rax*1], eax
00007ed4111d152e  mov eax, 0x410378
00007ed4111d1533  mov [r15+0x100], rax
00007ed4111d153a  jmp 0x00007ED410FFE110
00007ed4111d153f  cmp dword ptr [r15+0x318], 0x00
00007ed4111d1547  jz 0x00007ED4111D1580
00007ed4111d154d  nop [rax+rax*1], ax
00007ed4111d1556  nop [rax+rax*1], eax
00007ed4111d155e  mov eax, 0x4103A0
00007ed4111d1563  mov [r15+0x100], rax
00007ed4111d156a  jmp 0x00007ED410FFE110
00007ed4111d156f  int3
00007ed4111d1570  call 0x00007ED4110A4270
00007ed4111d1575  jmp 0x00007ED4111D14EE
00007ed4111d157a  int3
00007ed4111d157b  nop [rax+rax*1], eax
00007ed4111d1580  mov qword ptr [r15+0x40], 0x430000
00007ed4111d1588  mov eax, 0x430C40
00007ed4111d158d  mov r14, [r13+rax*1]
00007ed4111d1592  mov rax, [r15+0x98]
00007ed4111d1599  mov r12d, [r13+rax*1]
00007ed4111d159e  lea r11, [rax+0x04]
00007ed4111d15a2  mov eax, [r13+r11*1]
00007ed4111d15a7  mov r12d, r12d
00007ed4111d15aa  mov [r15+0x68], r12
00007ed4111d15ae  mov eax, eax
00007ed4111d15b0  mov [r15+0x60], rax
00007ed4111d15b4  mov rax, [r15+0x68]
00007ed4111d15b8  mov [r15+0x68], rax
00007ed4111d15bc  mov qword ptr [r15+0x58], 0x02
00007ed4111d15c4  mov [rsp+0x10], rax
00007ed4111d15c9  xor eax, eax
00007ed4111d15cb  mov r12d, 0x02
00007ed4111d15d1  mov r11d, 0x400
00007ed4111d15d7  cmp r12, r11
00007ed4111d15da  cmc
00007ed4111d15db  lahf
00007ed4111d15dc  seto al
00007ed4111d15df  mov [r15+0x108], eax
00007ed4111d15e6  mov rax, [r15+0x60]
00007ed4111d15ea  mov r12d, 0x02
00007ed4111d15f0  imul rax, r12
00007ed4111d15f4  mov [r15+0x50], rax
00007ed4111d15f8  mov rax, [rsp+0x10]
00007ed4111d15fd  lea r12, [rax+r14*1]
00007ed4111d1601  mov [r15+0x48], r12
00007ed4111d1605  mov eax, [r15+0x108]
00007ed4111d160c  sahf
00007ed4111d160d  jnz 0x00007ED4111D163F
00007ed4111d160f  cmp dword ptr [r15+0x318], 0x00
00007ed4111d1617  jz 0x00007ED4111D17B0
00007ed4111d161d  nop [rax+rax*1], ax
00007ed4111d1626  nop [rax+rax*1], eax
00007ed4111d162e  mov eax, 0x4103D0
00007ed4111d1633  mov [r15+0x100], rax
00007ed4111d163a  jmp 0x00007ED410FFE110
00007ed4111d163f  cmp dword ptr [r15+0x318], 0x00
00007ed4111d1647  jz 0x00007ED4111D1690
00007ed4111d164d  nop [rax+rax*1], ax
00007ed4111d1656  nop [rax+rax*1], eax
00007ed4111d165e  mov eax, 0x4103B0
00007ed4111d1663  mov [r15+0x100], rax
00007ed4111d166a  jmp 0x00007ED410FFE110
00007ed4111d166f  int3
00007ed4111d1670  call 0x00007ED41100DC20
00007ed4111d1675  jmp 0x00007ED4111D1592
00007ed4111d167a  call 0x00007ED41100B5E0
00007ed4111d167f  jmp 0x00007ED4111D159E
00007ed4111d1684  call 0x00007ED4110A3D90
00007ed4111d1689  jmp 0x00007ED4111D15A7
00007ed4111d168e  int3
00007ed4111d168f  nop
00007ed4111d1690  mov rax, [r15+0x98]
00007ed4111d1697  mov r14, [r15+0x58]
00007ed4111d169b  mov [rsp+0x10], r14
00007ed4111d16a0  shl r14, 0x02
00007ed4111d16a4  lea r12, [rax+r14*1]
00007ed4111d16a8  mov eax, [r13+r12*1]
00007ed4111d16ad  lea r14, [r12+0x04]
00007ed4111d16b2  mov r12d, [r13+r14*1]
00007ed4111d16b7  mov eax, eax
00007ed4111d16b9  mov [r15+0x68], rax
00007ed4111d16bd  mov r12d, r12d
00007ed4111d16c0  mov [r15+0x60], r12
00007ed4111d16c4  mov rax, [r15+0x68]
00007ed4111d16c8  mov [rsp+0x20], rax
00007ed4111d16cd  mov r14, [rsp+0x10]
00007ed4111d16d2  imul rax, r14
00007ed4111d16d6  mov r12, [rsp+0x20]
00007ed4111d16db  lea r11, [r12+rax*1]
00007ed4111d16df  mov [r15+0x68], r11
00007ed4111d16e3  lea rax, [r14+0x02]
00007ed4111d16e7  mov [r15+0x58], rax
00007ed4111d16eb  mov [rsp+0x10], rax
00007ed4111d16f0  xor eax, eax
00007ed4111d16f2  mov r14, [rsp+0x10]
00007ed4111d16f7  mov r12d, 0x400
00007ed4111d16fd  cmp r14, r12
00007ed4111d1700  cmc
00007ed4111d1701  lahf
00007ed4111d1702  seto al
00007ed4111d1705  mov [r15+0x108], eax
00007ed4111d170c  mov rax, [r15+0x50]
00007ed4111d1710  mov r12, [r15+0x60]
00007ed4111d1714  imul r14, r12
00007ed4111d1718  lea r12, [rax+r14*1]
00007ed4111d171c  mov [r15+0x50], r12
00007ed4111d1720  mov rax, [r15+0x48]
00007ed4111d1724  lea r14, [r11+rax*1]
00007ed4111d1728  mov [r15+0x48], r14
00007ed4111d172c  mov eax, [r15+0x108]
00007ed4111d1733  sahf
00007ed4111d1734  jnz 0x00007ED4111D1766
00007ed4111d1736  cmp dword ptr [r15+0x318], 0x00
00007ed4111d173e  jz 0x00007ED4111D17B0
00007ed4111d1744  nop [rax+rax*1], ax
00007ed4111d174d  nop [rax+rax*1], eax
00007ed4111d1755  mov eax, 0x4103D0
00007ed4111d175a  mov [r15+0x100], rax
00007ed4111d1761  jmp 0x00007ED410FFE110
00007ed4111d1766  cmp dword ptr [r15+0x318], 0x00
00007ed4111d176e  jz 0x00007ED4111D1690
00007ed4111d1774  nop [rax+rax*1], ax
00007ed4111d177d  nop [rax+rax*1], eax
00007ed4111d1785  mov eax, 0x4103B0
00007ed4111d178a  mov [r15+0x100], rax
00007ed4111d1791  jmp 0x00007ED410FFE110
00007ed4111d1796  int3
00007ed4111d1797  call 0x00007ED4110B4690
00007ed4111d179c  jmp 0x00007ED4111D16AD
00007ed4111d17a1  call 0x00007ED4110E26A0
00007ed4111d17a6  jmp 0x00007ED4111D16B7
00007ed4111d17ab  int3
00007ed4111d17ac  nop [rax], eax
00007ed4111d17b0  mov qword ptr [r15+0x98], 0x00
00007ed4111d17bb  mov rax, [r15+0x50]
00007ed4111d17bf  mov r14, [r15+0x48]
00007ed4111d17c3  lea r12, [rax+r14*1]
00007ed4111d17c7  mov [r15+0x48], r12
00007ed4111d17cb  mov rax, [r15+0x40]
00007ed4111d17cf  lea r14, [rax+0xC40]
00007ed4111d17d6  mov [r13+r14*1], r12
00007ed4111d17db  mov qword ptr [r15], 0x01
00007ed4111d17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007ed4111d17ed  mov r14d, [r15+0x320]
00007ed4111d17f4  mov eax, 0x4103E8
00007ed4111d17f9  mov rcx, 0x7ED4111D1860
00007ed4111d1803  mov [r15+r14*8+0x328], rax
00007ed4111d180b  mov [r15+r14*8+0x368], rcx
00007ed4111d1813  add r14d, 0x01
00007ed4111d1817  and r14d, 0x07
00007ed4111d181b  mov [r15+0x320], r14d
00007ed4111d1822  cmp dword ptr [r15+0x318], 0x00
00007ed4111d182a  jz 0x00007ED4111D0F20
00007ed4111d1830  nop [rax+rax*1], ax
00007ed4111d1839  nop [rax+rax*1], eax
00007ed4111d1841  mov eax, 0x410938
00007ed4111d1846  mov [r15+0x100], rax
00007ed4111d184d  jmp 0x00007ED410FFE110
00007ed4111d1852  int3
00007ed4111d1853  call 0x00007ED4110E2CE0
00007ed4111d1858  jmp 0x00007ED4111D17DB
00007ed4111d185d  int3
00007ed4111d185e  nop
00007ed4111d1860  mov eax, [r15+0x98]
00007ed4111d1867  lea r14d, [eax+0x01]
00007ed4111d186c  mov [rsp+0x10], r14d
00007ed4111d1871  mov r14d, r14d
00007ed4111d1874  mov [r15+0x98], r14
00007ed4111d187b  xor eax, eax
00007ed4111d187d  mov r14d, [rsp+0x10]
00007ed4111d1882  cmp r14d, 0x10000
00007ed4111d1889  cmc
00007ed4111d188a  lahf
00007ed4111d188b  seto al
00007ed4111d188e  mov [r15+0x108], eax
00007ed4111d1895  mov eax, [r15+0x108]
00007ed4111d189c  sahf
00007ed4111d189d  jnz 0x00007ED4111D18CF
00007ed4111d189f  cmp dword ptr [r15+0x318], 0x00
00007ed4111d18a7  jz 0x00007ED4111D19A0
00007ed4111d18ad  nop [rax+rax*1], ax
00007ed4111d18b6  nop [rax+rax*1], eax
00007ed4111d18be  mov eax, 0x4103F4
00007ed4111d18c3  mov [r15+0x100], rax
00007ed4111d18ca  jmp 0x00007ED410FFE110
00007ed4111d18cf  cmp dword ptr [r15+0x318], 0x00
00007ed4111d18d7  jz 0x00007ED4111D1910
00007ed4111d18dd  nop [rax+rax*1], ax
00007ed4111d18e6  nop [rax+rax*1], eax
00007ed4111d18ee  mov eax, 0x4103E0
00007ed4111d18f3  mov [r15+0x100], rax
00007ed4111d18fa  jmp 0x00007ED410FFE110
00007ed4111d18ff  int3
00007ed4111d1900  int3
00007ed4111d1901  nop [rax+rax*1], ax
00007ed4111d190a  nop [rax+rax*1], ax
00007ed4111d1910  mov eax, [r15]
00007ed4111d1913  mov r14d, [r15+0x98]
00007ed4111d191a  lea r12d, [eax+r14d*1]
00007ed4111d191f  mov r12d, r12d
00007ed4111d1922  mov [r15], r12
00007ed4111d1925  mov qword ptr [r15+0xF0], 0x4103E8
00007ed4111d1930  mov r14d, [r15+0x320]
00007ed4111d1937  mov eax, 0x4103E8
00007ed4111d193c  mov rcx, 0x7ED4111D1860
00007ed4111d1946  mov [r15+r14*8+0x328], rax
00007ed4111d194e  mov [r15+r14*8+0x368], rcx
00007ed4111d1956  add r14d, 0x01
00007ed4111d195a  and r14d, 0x07
00007ed4111d195e  mov [r15+0x320], r14d
00007ed4111d1965  cmp dword ptr [r15+0x318], 0x00
00007ed4111d196d  jz 0x00007ED4111D0F20
00007ed4111d1973  nop [rax+rax*1], ax
00007ed4111d197c  nop [rax+rax*1], eax
00007ed4111d1984  mov eax, 0x410938
00007ed4111d1989  mov [r15+0x100], rax
00007ed4111d1990  jmp 0x00007ED410FFE110
00007ed4111d1995  int3
00007ed4111d1996  int3
00007ed4111d1997  nop [rax+rax*1], ax
00007ed4111d19a0  vmovaps xmm1, [0x00007ED410DFE010]
00007ed4111d19a8  movq xmm1, xmm1
00007ed4111d19ac  movaps [r15+0x110], xmm1
00007ed4111d19b4  mov eax, 0x420AA0
00007ed4111d19b9  mov r14, [r13+rax*1]
00007ed4111d19be  movq xmm1, r14
00007ed4111d19c3  movaps [r15+0x120], xmm1
00007ed4111d19cb  vmovaps xmm1, [0x00007ED410DFE020]
00007ed4111d19d3  movq xmm1, xmm1
00007ed4111d19d7  movaps [r15+0x140], xmm1
00007ed4111d19df  vmovaps xmm1, [0x00007ED410DFE030]
00007ed4111d19e7  vpbroadcastq xmm1, xmm1
00007ed4111d19ec  movaps [r15+0x150], xmm1
00007ed4111d19f4  mov qword ptr [r15+0x40], 0x02
00007ed4111d19fc  vmovaps xmm15, [0x00007ED410DFE040]
00007ed4111d1a04  movq xmm15, xmm15
00007ed4111d1a09  movaps [r15+0x160], xmm15
00007ed4111d1a11  vmovaps xmm15, [0x00007ED410DFE050]
00007ed4111d1a19  vpbroadcastq xmm15, xmm15
00007ed4111d1a1e  movaps [r15+0x130], xmm15
00007ed4111d1a26  mov rax, [r15+0x40]
00007ed4111d1a2a  vmovq xmm14, rax
00007ed4111d1a2f  vpbroadcastq xmm14, xmm14
00007ed4111d1a34  movaps [r15+0x170], xmm14
00007ed4111d1a3c  mov eax, 0x4209D0
00007ed4111d1a41  movups xmm13, [r13+rax*1]
00007ed4111d1a47  mov qword ptr [r15+0x40], 0x431D90
00007ed4111d1a4f  mov eax, [r15]
00007ed4111d1a52  mov r14d, 0x430C48
00007ed4111d1a58  mov [r13+r14*1], eax
00007ed4111d1a5d  mov qword ptr [r15+0x50], 0x431F90
00007ed4111d1a65  vpmovqd xmm12, xmm13
00007ed4111d1a6b  pxor xmm11, xmm11
00007ed4111d1a70  punpcklqdq xmm12, xmm11
00007ed4111d1a75  movaps [r15+0x210], xmm12
00007ed4111d1a7d  movq xmm12, qword ptr [r15+0x140]
00007ed4111d1a86  movq xmm11, qword ptr [r15+0x120]
00007ed4111d1a8f  psubd xmm12, xmm11
00007ed4111d1a94  movq xmm12, xmm12
00007ed4111d1a99  paddq xmm13, xmm14
00007ed4111d1a9e  movaps [r15+0x180], xmm13
00007ed4111d1aa6  movq xmm14, qword ptr [r15+0x160]
00007ed4111d1aaf  paddd xmm11, xmm14
00007ed4111d1ab4  movq xmm11, xmm11
00007ed4111d1ab9  movq xmm11, xmm11
00007ed4111d1abe  movaps [r15+0x120], xmm11
00007ed4111d1ac6  pmovzxdq xmm12, xmm12
00007ed4111d1acc  psllq xmm12, 0x00
00007ed4111d1ad2  movq xmm14, qword ptr [r15+0x210]
00007ed4111d1adb  movq xmm13, qword ptr [r15+0x110]
00007ed4111d1ae4  paddd xmm14, xmm13
00007ed4111d1ae9  movq xmm14, xmm14
00007ed4111d1aee  vcvtuqq2pd xmm12, xmm12
00007ed4111d1af4  pmovzxdq xmm14, xmm14
00007ed4111d1afa  psllq xmm14, 0x00
00007ed4111d1b00  vcvtuqq2pd xmm14, xmm14
00007ed4111d1b06  movaps xmm13, xmm12
00007ed4111d1b0a  mulpd xmm13, xmm1
00007ed4111d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007ed4111d1b15  ptest xmm11, xmm11
00007ed4111d1b1b  jnz 0x00007ED4111D1C0F
00007ed4111d1b21  movaps [r15+0x220], xmm13
00007ed4111d1b29  mov eax, 0x431F90
00007ed4111d1b2e  movups [r13+rax*1], xmm13
00007ed4111d1b34  movaps xmm1, xmm14
00007ed4111d1b38  mulpd xmm1, xmm15
00007ed4111d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007ed4111d1b42  ptest xmm13, xmm13
00007ed4111d1b48  jnz 0x00007ED4111D1D5C
00007ed4111d1b4e  movaps [r15+0x210], xmm1
00007ed4111d1b56  mov eax, 0x431D90
00007ed4111d1b5b  movups [r13+rax*1], xmm1
00007ed4111d1b61  mov qword ptr [r15+0x48], 0x10
00007ed4111d1b69  xor eax, eax
00007ed4111d1b6b  mov r14d, 0x10
00007ed4111d1b71  mov r12d, 0x200
00007ed4111d1b77  cmp r14, r12
00007ed4111d1b7a  cmc
00007ed4111d1b7b  lahf
00007ed4111d1b7c  seto al
00007ed4111d1b7f  mov [r15+0x108], eax
00007ed4111d1b86  mov eax, [r15+0x108]
00007ed4111d1b8d  sahf
00007ed4111d1b8e  jnz 0x00007ED4111D1BC0
00007ed4111d1b90  cmp dword ptr [r15+0x318], 0x00
00007ed4111d1b98  jz 0x00007ED4111D2300
00007ed4111d1b9e  nop [rax+rax*1], ax
00007ed4111d1ba7  nop [rax+rax*1], eax
00007ed4111d1baf  mov eax, 0x410480
00007ed4111d1bb4  mov [r15+0x100], rax
00007ed4111d1bbb  jmp 0x00007ED410FFE110
00007ed4111d1bc0  cmp dword ptr [r15+0x318], 0x00
00007ed4111d1bc8  jz 0x00007ED4111D1EB0
00007ed4111d1bce  nop [rax+rax*1], ax
00007ed4111d1bd7  nop [rax+rax*1], eax
00007ed4111d1bdf  mov eax, 0x410440
00007ed4111d1be4  mov [r15+0x100], rax
00007ed4111d1beb  jmp 0x00007ED410FFE110
00007ed4111d1bf0  int3
00007ed4111d1bf1  call 0x00007ED41100DC20
00007ed4111d1bf6  jmp 0x00007ED4111D19BE
00007ed4111d1bfb  call 0x00007ED41100C260
00007ed4111d1c00  jmp 0x00007ED4111D1A47
00007ed4111d1c05  call 0x00007ED4110D5D70
00007ed4111d1c0a  jmp 0x00007ED4111D1A5D
00007ed4111d1c0f  sub rsp, 0x08
00007ed4111d1c13  push rax
00007ed4111d1c14  push rcx
00007ed4111d1c15  push rdx
00007ed4111d1c16  push rdi
00007ed4111d1c17  push rsi
00007ed4111d1c18  push r8
00007ed4111d1c1a  push r9
00007ed4111d1c1c  push r10
00007ed4111d1c1e  push r11
00007ed4111d1c20  sub rsp, 0xF0
00007ed4111d1c27  vmovaps [rsp], xmm0
00007ed4111d1c2c  vmovaps [rsp+0x10], xmm1
00007ed4111d1c32  vmovaps [rsp+0x20], xmm2
00007ed4111d1c38  vmovaps [rsp+0x30], xmm3
00007ed4111d1c3e  vmovaps [rsp+0x40], xmm4
00007ed4111d1c44  vmovaps [rsp+0x50], xmm5
00007ed4111d1c4a  vmovaps [rsp+0x60], xmm6
00007ed4111d1c50  vmovaps [rsp+0x70], xmm7
00007ed4111d1c56  vmovaps [rsp+0x80], xmm8
00007ed4111d1c5f  vmovaps [rsp+0x90], xmm9
00007ed4111d1c68  vmovaps [rsp+0xA0], xmm10
00007ed4111d1c71  vmovaps [rsp+0xB0], xmm11
00007ed4111d1c7a  vmovaps [rsp+0xC0], xmm12
00007ed4111d1c83  vmovaps [rsp+0xD0], xmm14
00007ed4111d1c8c  vmovaps [rsp+0xE0], xmm15
00007ed4111d1c95  sub rsp, 0x30
00007ed4111d1c99  movaps [rsp], xmm13
00007ed4111d1c9e  movaps [rsp+0x10], xmm12
00007ed4111d1ca4  movaps [rsp+0x20], xmm1
00007ed4111d1ca9  lea rdi, [rsp]
00007ed4111d1cad  mov esi, 0x00
00007ed4111d1cb2  mov rax, 0x5CA8E4A55530
00007ed4111d1cbc  call rax
00007ed4111d1cbe  movaps xmm13, [rsp]
00007ed4111d1cc3  add rsp, 0x30
00007ed4111d1cc7  vmovaps xmm0, [rsp]
00007ed4111d1ccc  vmovaps xmm1, [rsp+0x10]
00007ed4111d1cd2  vmovaps xmm2, [rsp+0x20]
00007ed4111d1cd8  vmovaps xmm3, [rsp+0x30]
00007ed4111d1cde  vmovaps xmm4, [rsp+0x40]
00007ed4111d1ce4  vmovaps xmm5, [rsp+0x50]
00007ed4111d1cea  vmovaps xmm6, [rsp+0x60]
00007ed4111d1cf0  vmovaps xmm7, [rsp+0x70]
00007ed4111d1cf6  vmovaps xmm8, [rsp+0x80]
00007ed4111d1cff  vmovaps xmm9, [rsp+0x90]
00007ed4111d1d08  vmovaps xmm10, [rsp+0xA0]
00007ed4111d1d11  vmovaps xmm11, [rsp+0xB0]
00007ed4111d1d1a  vmovaps xmm12, [rsp+0xC0]
00007ed4111d1d23  vmovaps xmm14, [rsp+0xD0]
00007ed4111d1d2c  vmovaps xmm15, [rsp+0xE0]
00007ed4111d1d35  add rsp, 0xF0
00007ed4111d1d3c  pop r11
00007ed4111d1d3e  pop r10
00007ed4111d1d40  pop r9
00007ed4111d1d42  pop r8
00007ed4111d1d44  pop rsi
00007ed4111d1d45  pop rdi
00007ed4111d1d46  pop rdx
00007ed4111d1d47  pop rcx
00007ed4111d1d48  pop rax
00007ed4111d1d49  add rsp, 0x08
00007ed4111d1d4d  jmp 0x00007ED4111D1B21
00007ed4111d1d52  call 0x00007ED41100C380
00007ed4111d1d57  jmp 0x00007ED4111D1B34
00007ed4111d1d5c  sub rsp, 0x08
00007ed4111d1d60  push rax
00007ed4111d1d61  push rcx
00007ed4111d1d62  push rdx
00007ed4111d1d63  push rdi
00007ed4111d1d64  push rsi
00007ed4111d1d65  push r8
00007ed4111d1d67  push r9
00007ed4111d1d69  push r10
00007ed4111d1d6b  push r11
00007ed4111d1d6d  sub rsp, 0xF0
00007ed4111d1d74  vmovaps [rsp], xmm0
00007ed4111d1d79  vmovaps [rsp+0x10], xmm2
00007ed4111d1d7f  vmovaps [rsp+0x20], xmm3
00007ed4111d1d85  vmovaps [rsp+0x30], xmm4
00007ed4111d1d8b  vmovaps [rsp+0x40], xmm5
00007ed4111d1d91  vmovaps [rsp+0x50], xmm6
00007ed4111d1d97  vmovaps [rsp+0x60], xmm7
00007ed4111d1d9d  vmovaps [rsp+0x70], xmm8
00007ed4111d1da3  vmovaps [rsp+0x80], xmm9
00007ed4111d1dac  vmovaps [rsp+0x90], xmm10
00007ed4111d1db5  vmovaps [rsp+0xA0], xmm11
00007ed4111d1dbe  vmovaps [rsp+0xB0], xmm12
00007ed4111d1dc7  vmovaps [rsp+0xC0], xmm13
00007ed4111d1dd0  vmovaps [rsp+0xD0], xmm14
00007ed4111d1dd9  vmovaps [rsp+0xE0], xmm15
00007ed4111d1de2  sub rsp, 0x30
00007ed4111d1de6  movaps [rsp], xmm1
00007ed4111d1dea  movaps [rsp+0x10], xmm14
00007ed4111d1df0  movaps [rsp+0x20], xmm15
00007ed4111d1df6  lea rdi, [rsp]
00007ed4111d1dfa  mov esi, 0x00
00007ed4111d1dff  mov rax, 0x5CA8E4A55530
00007ed4111d1e09  call rax
00007ed4111d1e0b  movaps xmm1, [rsp]
00007ed4111d1e0f  add rsp, 0x30
00007ed4111d1e13  vmovaps xmm0, [rsp]
00007ed4111d1e18  vmovaps xmm2, [rsp+0x10]
00007ed4111d1e1e  vmovaps xmm3, [rsp+0x20]
00007ed4111d1e24  vmovaps xmm4, [rsp+0x30]
00007ed4111d1e2a  vmovaps xmm5, [rsp+0x40]
00007ed4111d1e30  vmovaps xmm6, [rsp+0x50]
00007ed4111d1e36  vmovaps xmm7, [rsp+0x60]
00007ed4111d1e3c  vmovaps xmm8, [rsp+0x70]
00007ed4111d1e42  vmovaps xmm9, [rsp+0x80]
00007ed4111d1e4b  vmovaps xmm10, [rsp+0x90]
00007ed4111d1e54  vmovaps xmm11, [rsp+0xA0]
00007ed4111d1e5d  vmovaps xmm12, [rsp+0xB0]
00007ed4111d1e66  vmovaps xmm13, [rsp+0xC0]
00007ed4111d1e6f  vmovaps xmm14, [rsp+0xD0]
00007ed4111d1e78  vmovaps xmm15, [rsp+0xE0]
00007ed4111d1e81  add rsp, 0xF0
00007ed4111d1e88  pop r11
00007ed4111d1e8a  pop r10
00007ed4111d1e8c  pop r9
00007ed4111d1e8e  pop r8
00007ed4111d1e90  pop rsi
00007ed4111d1e91  pop rdi
00007ed4111d1e92  pop rdx
00007ed4111d1e93  pop rcx
00007ed4111d1e94  pop rax
00007ed4111d1e95  add rsp, 0x08
00007ed4111d1e99  jmp 0x00007ED4111D1B4E
00007ed4111d1e9e  call 0x00007ED410FFF540
00007ed4111d1ea3  jmp 0x00007ED4111D1B61
00007ed4111d1ea8  int3
00007ed4111d1ea9  nop [rax], eax
00007ed4111d1eb0  movaps xmm1, [r15+0x180]
00007ed4111d1eb8  vpmovqd xmm15, xmm1
00007ed4111d1ebe  pxor xmm14, xmm14
00007ed4111d1ec3  punpcklqdq xmm15, xmm14
00007ed4111d1ec8  movaps [r15+0x210], xmm15
00007ed4111d1ed0  movq xmm15, qword ptr [r15+0x140]
00007ed4111d1ed9  movq xmm14, qword ptr [r15+0x120]
00007ed4111d1ee2  psubd xmm15, xmm14
00007ed4111d1ee7  movq xmm15, xmm15
00007ed4111d1eec  movaps xmm13, [r15+0x170]
00007ed4111d1ef4  paddq xmm1, xmm13
00007ed4111d1ef9  movaps [r15+0x180], xmm1
00007ed4111d1f01  movq xmm1, qword ptr [r15+0x160]
00007ed4111d1f0a  paddd xmm14, xmm1
00007ed4111d1f0f  movq xmm14, xmm14
00007ed4111d1f14  movq xmm14, xmm14
00007ed4111d1f19  movaps [r15+0x120], xmm14
00007ed4111d1f21  pmovzxdq xmm15, xmm15
00007ed4111d1f27  psllq xmm15, 0x00
00007ed4111d1f2d  movq xmm1, qword ptr [r15+0x210]
00007ed4111d1f36  movq xmm14, qword ptr [r15+0x110]
00007ed4111d1f3f  paddd xmm1, xmm14
00007ed4111d1f44  movq xmm1, xmm1
00007ed4111d1f48  vcvtuqq2pd xmm15, xmm15
00007ed4111d1f4e  pmovzxdq xmm1, xmm1
00007ed4111d1f53  psllq xmm1, 0x00
00007ed4111d1f58  vcvtuqq2pd xmm1, xmm1
00007ed4111d1f5e  movaps xmm14, [r15+0x150]
00007ed4111d1f66  movaps xmm13, xmm15
00007ed4111d1f6a  mulpd xmm13, xmm14
00007ed4111d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d1f75  ptest xmm12, xmm12
00007ed4111d1f7b  jnz 0x00007ED4111D205E
00007ed4111d1f81  movaps [r15+0x220], xmm13
00007ed4111d1f89  mov rax, [r15+0x48]
00007ed4111d1f8d  mov r14, [r15+0x50]
00007ed4111d1f91  lea r12, [r14+rax*1]
00007ed4111d1f95  movups [r13+r12*1], xmm13
00007ed4111d1f9b  movaps xmm15, [r15+0x130]
00007ed4111d1fa3  movaps xmm14, xmm1
00007ed4111d1fa7  mulpd xmm14, xmm15
00007ed4111d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007ed4111d1fb2  ptest xmm13, xmm13
00007ed4111d1fb8  jnz 0x00007ED4111D21AC
00007ed4111d1fbe  movaps [r15+0x210], xmm14
00007ed4111d1fc6  mov r14, [r15+0x40]
00007ed4111d1fca  lea r12, [r14+rax*1]
00007ed4111d1fce  movups [r13+r12*1], xmm14
00007ed4111d1fd4  lea r14, [rax+0x10]
00007ed4111d1fd8  mov [r15+0x48], r14
00007ed4111d1fdc  xor eax, eax
00007ed4111d1fde  mov r12d, 0x200
00007ed4111d1fe4  cmp r14, r12
00007ed4111d1fe7  cmc
00007ed4111d1fe8  lahf
00007ed4111d1fe9  seto al
00007ed4111d1fec  mov [r15+0x108], eax
00007ed4111d1ff3  mov eax, [r15+0x108]
00007ed4111d1ffa  sahf
00007ed4111d1ffb  jnz 0x00007ED4111D202D
00007ed4111d1ffd  cmp dword ptr [r15+0x318], 0x00
00007ed4111d2005  jz 0x00007ED4111D2300
00007ed4111d200b  nop [rax+rax*1], ax
00007ed4111d2014  nop [rax+rax*1], eax
00007ed4111d201c  mov eax, 0x410480
00007ed4111d2021  mov [r15+0x100], rax
00007ed4111d2028  jmp 0x00007ED410FFE110
00007ed4111d202d  cmp dword ptr [r15+0x318], 0x00
00007ed4111d2035  jz 0x00007ED4111D1EB0
00007ed4111d203b  nop [rax+rax*1], ax
00007ed4111d2044  nop [rax+rax*1], eax
00007ed4111d204c  mov eax, 0x410440
00007ed4111d2051  mov [r15+0x100], rax
00007ed4111d2058  jmp 0x00007ED410FFE110
00007ed4111d205d  int3
00007ed4111d205e  sub rsp, 0x08
00007ed4111d2062  push rax
00007ed4111d2063  push rcx
00007ed4111d2064  push rdx
00007ed4111d2065  push rdi
00007ed4111d2066  push rsi
00007ed4111d2067  push r8
00007ed4111d2069  push r9
00007ed4111d206b  push r10
00007ed4111d206d  push r11
00007ed4111d206f  sub rsp, 0xF0
00007ed4111d2076  vmovaps [rsp], xmm0
00007ed4111d207b  vmovaps [rsp+0x10], xmm1
00007ed4111d2081  vmovaps [rsp+0x20], xmm2
00007ed4111d2087  vmovaps [rsp+0x30], xmm3
00007ed4111d208d  vmovaps [rsp+0x40], xmm4
00007ed4111d2093  vmovaps [rsp+0x50], xmm5
00007ed4111d2099  vmovaps [rsp+0x60], xmm6
00007ed4111d209f  vmovaps [rsp+0x70], xmm7
00007ed4111d20a5  vmovaps [rsp+0x80], xmm8
00007ed4111d20ae  vmovaps [rsp+0x90], xmm9
00007ed4111d20b7  vmovaps [rsp+0xA0], xmm10
00007ed4111d20c0  vmovaps [rsp+0xB0], xmm11
00007ed4111d20c9  vmovaps [rsp+0xC0], xmm12
00007ed4111d20d2  vmovaps [rsp+0xD0], xmm14
00007ed4111d20db  vmovaps [rsp+0xE0], xmm15
00007ed4111d20e4  sub rsp, 0x30
00007ed4111d20e8  movaps [rsp], xmm13
00007ed4111d20ed  movaps [rsp+0x10], xmm15
00007ed4111d20f3  movaps [rsp+0x20], xmm14
00007ed4111d20f9  lea rdi, [rsp]
00007ed4111d20fd  mov esi, 0x00
00007ed4111d2102  mov rax, 0x5CA8E4A55530
00007ed4111d210c  call rax
00007ed4111d210e  movaps xmm13, [rsp]
00007ed4111d2113  add rsp, 0x30
00007ed4111d2117  vmovaps xmm0, [rsp]
00007ed4111d211c  vmovaps xmm1, [rsp+0x10]
00007ed4111d2122  vmovaps xmm2, [rsp+0x20]
00007ed4111d2128  vmovaps xmm3, [rsp+0x30]
00007ed4111d212e  vmovaps xmm4, [rsp+0x40]
00007ed4111d2134  vmovaps xmm5, [rsp+0x50]
00007ed4111d213a  vmovaps xmm6, [rsp+0x60]
00007ed4111d2140  vmovaps xmm7, [rsp+0x70]
00007ed4111d2146  vmovaps xmm8, [rsp+0x80]
00007ed4111d214f  vmovaps xmm9, [rsp+0x90]
00007ed4111d2158  vmovaps xmm10, [rsp+0xA0]
00007ed4111d2161  vmovaps xmm11, [rsp+0xB0]
00007ed4111d216a  vmovaps xmm12, [rsp+0xC0]
00007ed4111d2173  vmovaps xmm14, [rsp+0xD0]
00007ed4111d217c  vmovaps xmm15, [rsp+0xE0]
00007ed4111d2185  add rsp, 0xF0
00007ed4111d218c  pop r11
00007ed4111d218e  pop r10
00007ed4111d2190  pop r9
00007ed4111d2192  pop r8
00007ed4111d2194  pop rsi
00007ed4111d2195  pop rdi
00007ed4111d2196  pop rdx
00007ed4111d2197  pop rcx
00007ed4111d2198  pop rax
00007ed4111d2199  add rsp, 0x08
00007ed4111d219d  jmp 0x00007ED4111D1F81
00007ed4111d21a2  call 0x00007ED4110C2240
00007ed4111d21a7  jmp 0x00007ED4111D1F9B
00007ed4111d21ac  sub rsp, 0x08
00007ed4111d21b0  push rax
00007ed4111d21b1  push rcx
00007ed4111d21b2  push rdx
00007ed4111d21b3  push rdi
00007ed4111d21b4  push rsi
00007ed4111d21b5  push r8
00007ed4111d21b7  push r9
00007ed4111d21b9  push r10
00007ed4111d21bb  push r11
00007ed4111d21bd  sub rsp, 0xF0
00007ed4111d21c4  vmovaps [rsp], xmm0
00007ed4111d21c9  vmovaps [rsp+0x10], xmm1
00007ed4111d21cf  vmovaps [rsp+0x20], xmm2
00007ed4111d21d5  vmovaps [rsp+0x30], xmm3
00007ed4111d21db  vmovaps [rsp+0x40], xmm4
00007ed4111d21e1  vmovaps [rsp+0x50], xmm5
00007ed4111d21e7  vmovaps [rsp+0x60], xmm6
00007ed4111d21ed  vmovaps [rsp+0x70], xmm7
00007ed4111d21f3  vmovaps [rsp+0x80], xmm8
00007ed4111d21fc  vmovaps [rsp+0x90], xmm9
00007ed4111d2205  vmovaps [rsp+0xA0], xmm10
00007ed4111d220e  vmovaps [rsp+0xB0], xmm11
00007ed4111d2217  vmovaps [rsp+0xC0], xmm12
00007ed4111d2220  vmovaps [rsp+0xD0], xmm13
00007ed4111d2229  vmovaps [rsp+0xE0], xmm15
00007ed4111d2232  sub rsp, 0x30
00007ed4111d2236  movaps [rsp], xmm14
00007ed4111d223b  movaps [rsp+0x10], xmm1
00007ed4111d2240  movaps [rsp+0x20], xmm15
00007ed4111d2246  lea rdi, [rsp]
00007ed4111d224a  mov esi, 0x00
00007ed4111d224f  mov rax, 0x5CA8E4A55530
00007ed4111d2259  call rax
00007ed4111d225b  movaps xmm14, [rsp]
00007ed4111d2260  add rsp, 0x30
00007ed4111d2264  vmovaps xmm0, [rsp]
00007ed4111d2269  vmovaps xmm1, [rsp+0x10]
00007ed4111d226f  vmovaps xmm2, [rsp+0x20]
00007ed4111d2275  vmovaps xmm3, [rsp+0x30]
00007ed4111d227b  vmovaps xmm4, [rsp+0x40]
00007ed4111d2281  vmovaps xmm5, [rsp+0x50]
00007ed4111d2287  vmovaps xmm6, [rsp+0x60]
00007ed4111d228d  vmovaps xmm7, [rsp+0x70]
00007ed4111d2293  vmovaps xmm8, [rsp+0x80]
00007ed4111d229c  vmovaps xmm9, [rsp+0x90]
00007ed4111d22a5  vmovaps xmm10, [rsp+0xA0]
00007ed4111d22ae  vmovaps xmm11, [rsp+0xB0]
00007ed4111d22b7  vmovaps xmm12, [rsp+0xC0]
00007ed4111d22c0  vmovaps xmm13, [rsp+0xD0]
00007ed4111d22c9  vmovaps xmm15, [rsp+0xE0]
00007ed4111d22d2  add rsp, 0xF0
00007ed4111d22d9  pop r11
00007ed4111d22db  pop r10
00007ed4111d22dd  pop r9
00007ed4111d22df  pop r8
00007ed4111d22e1  pop rsi
00007ed4111d22e2  pop rdi
00007ed4111d22e3  pop rdx
00007ed4111d22e4  pop rcx
00007ed4111d22e5  pop rax
00007ed4111d22e6  add rsp, 0x08
00007ed4111d22ea  jmp 0x00007ED4111D1FBE
00007ed4111d22ef  call 0x00007ED4110C34C0
00007ed4111d22f4  jmp 0x00007ED4111D1FD4
00007ed4111d22f9  int3
00007ed4111d22fa  nop [rax+rax*1], ax
00007ed4111d2300  mov rax, [r15+0x50]
00007ed4111d2304  movups xmm1, [r13+rax*1]
00007ed4111d230a  lea r14, [rax+0x10]
00007ed4111d230e  movups xmm15, [r13+r14*1]
00007ed4111d2314  mov qword ptr [r15+0x48], 0x00
00007ed4111d231c  lea r14, [rax+0x40]
00007ed4111d2320  movups xmm14, [r13+r14*1]
00007ed4111d2326  lea r14, [rax+0x50]
00007ed4111d232a  movups xmm13, [r13+r14*1]
00007ed4111d2330  lea r14, [rax+0x80]
00007ed4111d2337  movups xmm12, [r13+r14*1]
00007ed4111d233d  lea r14, [rax+0x90]
00007ed4111d2344  movups xmm11, [r13+r14*1]
00007ed4111d234a  mov r14, [r15+0xF8]
00007ed4111d2351  movups [r13+r14*1], xmm1
00007ed4111d2357  lea r12, [rax+0x20]
00007ed4111d235b  movups xmm1, [r13+r12*1]
00007ed4111d2361  lea r12, [rax+0x30]
00007ed4111d2365  movups xmm10, [r13+r12*1]
00007ed4111d236b  lea r12, [rax+0xC0]
00007ed4111d2372  movups xmm9, [r13+r12*1]
00007ed4111d2378  lea r12, [rax+0xD0]
00007ed4111d237f  movups xmm8, [r13+r12*1]
00007ed4111d2385  lea r12, [rax+0x100]
00007ed4111d238c  movups xmm7, [r13+r12*1]
00007ed4111d2392  lea r12, [rax+0x110]
00007ed4111d2399  movups xmm6, [r13+r12*1]
00007ed4111d239f  lea r12, [rax+0x140]
00007ed4111d23a6  movups xmm5, [r13+r12*1]
00007ed4111d23ac  lea r12, [rax+0x150]
00007ed4111d23b3  movups xmm4, [r13+r12*1]
00007ed4111d23b9  lea r12, [r14+0xB0]
00007ed4111d23c0  movups [r13+r12*1], xmm10
00007ed4111d23c6  lea r12, [r14+0xC0]
00007ed4111d23cd  movups [r13+r12*1], xmm1
00007ed4111d23d3  lea r12, [rax+0x180]
00007ed4111d23da  movups xmm1, [r13+r12*1]
00007ed4111d23e0  lea r12, [rax+0x190]
00007ed4111d23e7  movups xmm10, [r13+r12*1]
00007ed4111d23ed  lea r12, [rax+0x1C0]
00007ed4111d23f4  movups xmm3, [r13+r12*1]
00007ed4111d23fa  lea r12, [rax+0x1D0]
00007ed4111d2401  movups xmm2, [r13+r12*1]
00007ed4111d2407  lea r12, [rax+0x60]
00007ed4111d240b  vmovaps [rsp+0x10], xmm1
00007ed4111d2411  movups xmm1, [r13+r12*1]
00007ed4111d2417  lea r12, [rax+0x70]
00007ed4111d241b  vmovaps [rsp+0x20], xmm1
00007ed4111d2421  movups xmm1, [r13+r12*1]
00007ed4111d2427  lea r12, [r14+0x70]
00007ed4111d242b  movups [r13+r12*1], xmm10
00007ed4111d2431  lea r12, [r14+0x80]
00007ed4111d2438  vmovaps xmm10, [rsp+0x10]
00007ed4111d243e  movups [r13+r12*1], xmm10
00007ed4111d2444  lea r12, [rax+0xA0]
00007ed4111d244b  movups xmm10, [r13+r12*1]
00007ed4111d2451  lea r12, [rax+0xB0]
00007ed4111d2458  vmovaps [rsp+0x10], xmm1
00007ed4111d245e  movups xmm1, [r13+r12*1]
00007ed4111d2464  lea r12, [r14+0x90]
00007ed4111d246b  movups [r13+r12*1], xmm2
00007ed4111d2471  lea r12, [r14+0xA0]
00007ed4111d2478  movups [r13+r12*1], xmm3
00007ed4111d247e  lea r12, [rax+0xE0]
00007ed4111d2485  movups xmm3, [r13+r12*1]
00007ed4111d248b  lea r12, [rax+0xF0]
00007ed4111d2492  movups xmm2, [r13+r12*1]
00007ed4111d2498  lea r12, [rax+0x120]
00007ed4111d249f  vmovaps [rsp+0x30], xmm1
00007ed4111d24a5  movups xmm1, [r13+r12*1]
00007ed4111d24ab  lea r12, [rax+0x130]
00007ed4111d24b2  vmovaps [rsp+0x40], xmm1
00007ed4111d24b8  movups xmm1, [r13+r12*1]
00007ed4111d24be  vmovaps [rsp+0x50], xmm1
00007ed4111d24c4  vmovaps xmm1, [rsp+0x40]
00007ed4111d24ca  movaps [r15+0x190], xmm1
00007ed4111d24d2  lea r12, [rax+0x160]
00007ed4111d24d9  vmovaps [rsp+0x40], xmm1
00007ed4111d24df  movups xmm1, [r13+r12*1]
00007ed4111d24e5  lea r12, [rax+0x170]
00007ed4111d24ec  vmovaps [rsp+0x60], xmm1
00007ed4111d24f2  movups xmm1, [r13+r12*1]
00007ed4111d24f8  lea r12, [rax+0x1A0]
00007ed4111d24ff  vmovaps [rsp+0x70], xmm1
00007ed4111d2505  movups xmm1, [r13+r12*1]
00007ed4111d250b  lea r12, [rax+0x1B0]
00007ed4111d2512  vmovaps [rsp+0x80], xmm1
00007ed4111d251b  movups xmm1, [r13+r12*1]
00007ed4111d2521  lea r12, [rax+0x1E0]
00007ed4111d2528  vmovaps [rsp+0x90], xmm1
00007ed4111d2531  movups xmm1, [r13+r12*1]
00007ed4111d2537  lea r12, [rax+0x1F0]
00007ed4111d253e  vmovaps [rsp+0xA0], xmm1
00007ed4111d2547  movups xmm1, [r13+r12*1]
00007ed4111d254d  mov qword ptr [r15+0x50], 0x432190
00007ed4111d2555  lea rax, [r14+0x50]
00007ed4111d2559  vmovaps [rsp+0xB0], xmm1
00007ed4111d2562  vmovaps xmm1, [rsp+0x60]
00007ed4111d2568  movups [r13+rax*1], xmm1
00007ed4111d256e  lea rax, [r14+0x60]
00007ed4111d2572  movups [r13+rax*1], xmm5
00007ed4111d2578  lea rax, [r14+0x40]
00007ed4111d257c  vmovaps xmm1, [rsp+0x70]
00007ed4111d2582  movups [r13+rax*1], xmm1
00007ed4111d2588  lea rax, [r14+0x20]
00007ed4111d258c  vmovaps xmm1, [rsp+0xA0]
00007ed4111d2595  movups [r13+rax*1], xmm1
00007ed4111d259b  lea rax, [r14+0x30]
00007ed4111d259f  vmovaps xmm1, [rsp+0x90]
00007ed4111d25a8  movups [r13+rax*1], xmm1
00007ed4111d25ae  lea rax, [r14+0x10]
00007ed4111d25b2  vmovaps xmm1, [rsp+0xB0]
00007ed4111d25bb  movups [r13+rax*1], xmm1
00007ed4111d25c1  mov rax, [r15+0x40]
00007ed4111d25c5  vxorps xmm1, xmm1, xmm1
00007ed4111d25c9  vpbroadcastq xmm1, xmm1
00007ed4111d25ce  vxorps xmm5, xmm5, xmm5
00007ed4111d25d2  vpbroadcastq xmm5, xmm5
00007ed4111d25d7  lea r12, [rax+0x30]
00007ed4111d25db  mov r11, [r13+r12*1]
00007ed4111d25e0  lea r12, [rax+0x38]
00007ed4111d25e4  mov r10, [r13+r12*1]
00007ed4111d25e9  vmovaps [rsp+0x60], xmm1
00007ed4111d25ef  movq xmm1, r11
00007ed4111d25f4  vmovaps [rsp+0x70], xmm1
00007ed4111d25fa  movq xmm1, r10
00007ed4111d25ff  vmovaps [rsp+0x90], xmm1
00007ed4111d2608  vmovaps xmm1, [rsp+0x70]
00007ed4111d260e  movq xmm1, xmm1
00007ed4111d2612  vmovaps [rsp+0x70], xmm1
00007ed4111d2618  vmovaps xmm1, [rsp+0x90]
00007ed4111d2621  movq xmm1, xmm1
00007ed4111d2625  vmovaps [rsp+0x90], xmm1
00007ed4111d262e  movq xmm1, xmm1
00007ed4111d2632  movaps [r15+0x270], xmm1
00007ed4111d263a  vmovaps [rsp+0xA0], xmm7
00007ed4111d2643  vmovaps xmm1, [rsp+0xA0]
00007ed4111d264c  por xmm7, xmm1
00007ed4111d2650  lea r12, [rax+0x20]
00007ed4111d2654  mov r11, [r13+r12*1]
00007ed4111d2659  lea r12, [rax+0x28]
00007ed4111d265d  mov r10, [r13+r12*1]
00007ed4111d2662  movq xmm1, r11
00007ed4111d2667  vmovaps [rsp+0xA0], xmm1
00007ed4111d2670  movq xmm1, r10
00007ed4111d2675  vmovaps [rsp+0xB0], xmm1
00007ed4111d267e  vmovaps xmm1, [rsp+0xA0]
00007ed4111d2687  movq xmm1, xmm1
00007ed4111d268b  vmovaps [rsp+0xA0], xmm1
00007ed4111d2694  vmovaps xmm1, [rsp+0xB0]
00007ed4111d269d  movq xmm1, xmm1
00007ed4111d26a1  vmovaps [rsp+0xB0], xmm2
00007ed4111d26aa  vmovaps [rsp+0xC0], xmm1
00007ed4111d26b3  vmovaps xmm1, [rsp+0xB0]
00007ed4111d26bc  por xmm2, xmm1
00007ed4111d26c0  vmovaps [rsp+0xB0], xmm3
00007ed4111d26c9  vmovaps xmm1, [rsp+0xB0]
00007ed4111d26d2  por xmm3, xmm1
00007ed4111d26d6  vmovaps [rsp+0xB0], xmm4
00007ed4111d26df  vmovaps xmm1, [rsp+0xB0]
00007ed4111d26e8  por xmm4, xmm1
00007ed4111d26ec  vmovaps [rsp+0xB0], xmm9
00007ed4111d26f5  vmovaps xmm1, [rsp+0xB0]
00007ed4111d26fe  por xmm9, xmm1
00007ed4111d2703  lea r12, [rax+0x10]
00007ed4111d2707  mov r11, [r13+r12*1]
00007ed4111d270c  lea r12, [rax+0x18]
00007ed4111d2710  mov r10, [r13+r12*1]
00007ed4111d2715  movq xmm1, r11
00007ed4111d271a  vmovaps [rsp+0xB0], xmm1
00007ed4111d2723  movq xmm1, r10
00007ed4111d2728  vmovaps [rsp+0xD0], xmm1
00007ed4111d2731  vmovaps xmm1, [rsp+0xB0]
00007ed4111d273a  movq xmm1, xmm1
00007ed4111d273e  vmovaps [rsp+0xB0], xmm1
00007ed4111d2747  vmovaps xmm1, [rsp+0xD0]
00007ed4111d2750  movq xmm1, xmm1
00007ed4111d2754  vmovaps [rsp+0xD0], xmm1
00007ed4111d275d  vmovaps xmm1, [rsp+0x80]
00007ed4111d2766  vmovaps [rsp+0xE0], xmm15
00007ed4111d276f  vmovaps xmm15, [rsp+0x80]
00007ed4111d2778  por xmm1, xmm15
00007ed4111d277d  vmovaps xmm15, [rsp+0x10]
00007ed4111d2783  vmovaps [rsp+0x80], xmm1
00007ed4111d278c  vmovaps xmm1, [rsp+0x10]
00007ed4111d2792  por xmm15, xmm1
00007ed4111d2797  vmovaps xmm1, [rsp+0x20]
00007ed4111d279d  vmovaps [rsp+0x10], xmm15
00007ed4111d27a3  vmovaps xmm15, [rsp+0x20]
00007ed4111d27a9  por xmm1, xmm15
00007ed4111d27ae  vmovaps [rsp+0x20], xmm6
00007ed4111d27b4  vmovaps xmm15, [rsp+0x20]
00007ed4111d27ba  por xmm6, xmm15
00007ed4111d27bf  vmovaps [rsp+0x20], xmm11
00007ed4111d27c5  vmovaps xmm15, [rsp+0x20]
00007ed4111d27cb  por xmm11, xmm15
00007ed4111d27d0  vmovaps [rsp+0x20], xmm13
00007ed4111d27d6  vmovaps xmm15, [rsp+0x20]
00007ed4111d27dc  por xmm13, xmm15
00007ed4111d27e1  vmovaps [rsp+0x20], xmm14
00007ed4111d27e7  vmovaps xmm15, [rsp+0x20]
00007ed4111d27ed  por xmm14, xmm15
00007ed4111d27f2  mov r12, [r13+rax*1]
00007ed4111d27f7  vmovq xmm15, r12
00007ed4111d27fc  vpbroadcastq xmm15, xmm15
00007ed4111d2801  vmovaps [rsp+0x20], xmm1
00007ed4111d2807  vxorps xmm1, xmm1, xmm1
00007ed4111d280b  vpbroadcastq xmm1, xmm1
00007ed4111d2810  vmovaps [rsp+0xF0], xmm1
00007ed4111d2819  movups xmm1, [r13+r14*1]
00007ed4111d281f  vmovaps [rsp+0x100], xmm1
00007ed4111d2828  vxorps xmm1, xmm1, xmm1
00007ed4111d282c  vpbroadcastq xmm1, xmm1
00007ed4111d2831  lea r12, [rax+0x08]
00007ed4111d2835  mov rax, [r13+r12*1]
00007ed4111d283a  vmovaps [rsp+0x110], xmm1
00007ed4111d2843  movq xmm1, rax
00007ed4111d2848  movaps [r15+0x240], xmm1
00007ed4111d2850  mov qword ptr [r15+0x60], 0x432190
00007ed4111d2858  mov qword ptr [r15+0x58], 0x40
00007ed4111d2860  vmovaps xmm1, [rsp+0x60]
00007ed4111d2866  vmovaps [rsp+0x60], xmm15
00007ed4111d286c  vmovaps xmm15, [rsp+0x100]
00007ed4111d2875  vmovaps [rsp+0x100], xmm14
00007ed4111d287e  vmovaps xmm14, [rsp+0x60]
00007ed4111d2884  vmovaps [rsp+0x60], xmm13
00007ed4111d288a  vmovaps [rsp+0x120], xmm12
00007ed4111d2893  movaps xmm13, xmm1
00007ed4111d2897  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d28a2  vptest xmm12, xmm12
00007ed4111d28a7  jnz 0x00007ED4111D3482
00007ed4111d28ad  vmovaps xmm1, [rsp+0xE0]
00007ed4111d28b6  movaps xmm15, xmm5
00007ed4111d28ba  vfmadd231pd xmm15, xmm1, xmm14
00007ed4111d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007ed4111d28c5  vptest xmm12, xmm12
00007ed4111d28ca  jnz 0x00007ED4111D35DB
00007ed4111d28d0  vmovaps xmm12, [rsp+0x50]
00007ed4111d28d6  vmovaps xmm5, [rsp+0x50]
00007ed4111d28dc  por xmm12, xmm5
00007ed4111d28e1  vmovaps xmm5, [rsp+0x30]
00007ed4111d28e7  vmovaps [rsp+0x50], xmm1
00007ed4111d28ed  vmovaps xmm1, [rsp+0x30]
00007ed4111d28f3  por xmm5, xmm1
00007ed4111d28f7  vmovaps [rsp+0x30], xmm10
00007ed4111d28fd  vmovaps xmm1, [rsp+0x30]
00007ed4111d2903  por xmm10, xmm1
00007ed4111d2908  vmovaps [rsp+0x30], xmm8
00007ed4111d290e  vmovaps xmm1, [rsp+0x30]
00007ed4111d2914  por xmm8, xmm1
00007ed4111d2919  vmovaps xmm1, [rsp+0x120]
00007ed4111d2922  vmovaps [rsp+0x30], xmm15
00007ed4111d2928  vmovaps xmm15, [rsp+0x120]
00007ed4111d2931  por xmm1, xmm15
00007ed4111d2936  vmovaps xmm15, [rsp+0x50]
00007ed4111d293c  vmovaps [rsp+0xE0], xmm1
00007ed4111d2945  vmovaps xmm1, [rsp+0x50]
00007ed4111d294b  por xmm15, xmm1
00007ed4111d2950  lea rax, [r14+0xC0]
00007ed4111d2957  movups xmm1, [r13+rax*1]
00007ed4111d295d  xor eax, eax
00007ed4111d295f  mov r12d, 0x40
00007ed4111d2965  mov r11d, 0x200
00007ed4111d296b  cmp r12, r11
00007ed4111d296e  cmc
00007ed4111d296f  lahf
00007ed4111d2970  seto al
00007ed4111d2973  mov [r15+0x108], eax
00007ed4111d297a  vmovaps [rsp+0x50], xmm1
00007ed4111d2980  vmovaps xmm1, [rsp+0xF0]
00007ed4111d2989  vmovaps [rsp+0xF0], xmm15
00007ed4111d2992  vmovaps xmm15, [rsp+0x50]
00007ed4111d2998  vmovaps [rsp+0x50], xmm13
00007ed4111d299e  vmovaps [rsp+0x120], xmm12
00007ed4111d29a7  movaps xmm13, xmm1
00007ed4111d29ab  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d29b6  vptest xmm12, xmm12
00007ed4111d29bb  jnz 0x00007ED4111D373D
00007ed4111d29c1  lea rax, [r14+0xB0]
00007ed4111d29c8  movups xmm1, [r13+rax*1]
00007ed4111d29ce  vmovaps xmm15, [rsp+0x110]
00007ed4111d29d7  vmovaps [rsp+0x110], xmm13
00007ed4111d29e0  movaps xmm12, xmm15
00007ed4111d29e4  vfmadd231pd xmm12, xmm1, xmm14
00007ed4111d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007ed4111d29ef  vptest xmm13, xmm13
00007ed4111d29f4  jnz 0x00007ED4111D38A0
00007ed4111d29fa  vmovaps xmm1, [rsp+0x100]
00007ed4111d2a03  vmovaps xmm15, [rsp+0x100]
00007ed4111d2a0c  por xmm1, xmm15
00007ed4111d2a11  movaps [r15+0x210], xmm1
00007ed4111d2a19  vmovaps xmm15, [rsp+0x60]
00007ed4111d2a1f  vmovaps xmm14, [rsp+0x60]
00007ed4111d2a25  por xmm15, xmm14
00007ed4111d2a2a  movaps [r15+0x1C0], xmm15
00007ed4111d2a32  vmovaps [rsp+0x60], xmm11
00007ed4111d2a38  vmovaps xmm14, [rsp+0x60]
00007ed4111d2a3e  por xmm11, xmm14
00007ed4111d2a43  movaps [r15+0x280], xmm11
00007ed4111d2a4b  vmovaps [rsp+0x60], xmm6
00007ed4111d2a51  vmovaps xmm14, [rsp+0x60]
00007ed4111d2a57  por xmm6, xmm14
00007ed4111d2a5c  movaps [r15+0x2A0], xmm6
00007ed4111d2a64  vmovaps xmm14, [rsp+0x20]
00007ed4111d2a6a  vmovaps xmm13, [rsp+0x20]
00007ed4111d2a70  por xmm14, xmm13
00007ed4111d2a75  movaps [r15+0x2E0], xmm14
00007ed4111d2a7d  vmovaps xmm13, [rsp+0x10]
00007ed4111d2a83  vmovaps [rsp+0x20], xmm1
00007ed4111d2a89  vmovaps xmm1, [rsp+0x10]
00007ed4111d2a8f  por xmm13, xmm1
00007ed4111d2a94  movaps [r15+0x1F0], xmm13
00007ed4111d2a9c  vmovaps xmm1, [rsp+0xF0]
00007ed4111d2aa5  vmovaps [rsp+0x10], xmm15
00007ed4111d2aab  vmovaps xmm15, [rsp+0xF0]
00007ed4111d2ab4  por xmm1, xmm15
00007ed4111d2ab9  movaps [r15+0x250], xmm1
00007ed4111d2ac1  vmovaps xmm1, [rsp+0xE0]
00007ed4111d2aca  vmovaps xmm15, [rsp+0xE0]
00007ed4111d2ad3  por xmm1, xmm15
00007ed4111d2ad8  movaps [r15+0x260], xmm1
00007ed4111d2ae0  vmovaps [rsp+0x60], xmm8
00007ed4111d2ae6  vmovaps xmm15, [rsp+0x60]
00007ed4111d2aec  por xmm8, xmm15
00007ed4111d2af1  movaps [r15+0x290], xmm8
00007ed4111d2af9  vmovaps [rsp+0x60], xmm10
00007ed4111d2aff  vmovaps xmm15, [rsp+0x60]
00007ed4111d2b05  por xmm10, xmm15
00007ed4111d2b0a  movaps [r15+0x2C0], xmm10
00007ed4111d2b12  movq xmm15, qword ptr [r15+0x240]
00007ed4111d2b1b  vmovaps [rsp+0x60], xmm15
00007ed4111d2b21  vpermilpd xmm15, xmm15, 0x00
00007ed4111d2b27  vmovaps [rsp+0xE0], xmm1
00007ed4111d2b30  vmovaps xmm1, [rsp+0x50]
00007ed4111d2b36  vmovaps [rsp+0x50], xmm15
00007ed4111d2b3c  vmovaps xmm15, [rsp+0x20]
00007ed4111d2b42  vmovaps [rsp+0x20], xmm14
00007ed4111d2b48  vmovaps xmm14, [rsp+0x50]
00007ed4111d2b4e  vmovaps [rsp+0x50], xmm13
00007ed4111d2b54  vmovaps [rsp+0xF0], xmm12
00007ed4111d2b5d  movaps xmm13, xmm1
00007ed4111d2b61  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d2b6c  vptest xmm12, xmm12
00007ed4111d2b71  jnz 0x00007ED4111D39F9
00007ed4111d2b77  vmovaps xmm1, [rsp+0x60]
00007ed4111d2b7d  vpermilpd xmm1, xmm1, 0x00
00007ed4111d2b83  vmovaps xmm15, [rsp+0x110]
00007ed4111d2b8c  vmovaps xmm14, [rsp+0x20]
00007ed4111d2b92  vmovaps [rsp+0x20], xmm13
00007ed4111d2b98  movaps xmm12, xmm15
00007ed4111d2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007ed4111d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007ed4111d2ba7  vptest xmm13, xmm13
00007ed4111d2bac  jnz 0x00007ED4111D3B52
00007ed4111d2bb2  vmovaps xmm1, [rsp+0x60]
00007ed4111d2bb8  vpermilpd xmm1, xmm1, 0x00
00007ed4111d2bbe  vmovaps xmm15, [rsp+0x30]
00007ed4111d2bc4  vmovaps xmm14, [rsp+0x10]
00007ed4111d2bca  vmovaps [rsp+0x10], xmm12
00007ed4111d2bd0  movaps xmm13, xmm15
00007ed4111d2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007ed4111d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d2bdf  vptest xmm12, xmm12
00007ed4111d2be4  jnz 0x00007ED4111D3CAB
00007ed4111d2bea  vmovaps [rsp+0x30], xmm5
00007ed4111d2bf0  vmovaps xmm1, [rsp+0x30]
00007ed4111d2bf6  por xmm5, xmm1
00007ed4111d2bfa  movaps [r15+0x1D0], xmm5
00007ed4111d2c02  vmovaps xmm1, [rsp+0x60]
00007ed4111d2c08  vpermilpd xmm1, xmm1, 0x00
00007ed4111d2c0e  vmovaps xmm15, [rsp+0xF0]
00007ed4111d2c17  vmovaps xmm14, [rsp+0x50]
00007ed4111d2c1d  vmovaps [rsp+0x30], xmm13
00007ed4111d2c23  movaps xmm12, xmm15
00007ed4111d2c27  vfmadd231pd xmm12, xmm14, xmm1
00007ed4111d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007ed4111d2c32  vptest xmm13, xmm13
00007ed4111d2c37  jnz 0x00007ED4111D3E04
00007ed4111d2c3d  vmovaps xmm1, [rsp+0x80]
00007ed4111d2c46  vmovaps xmm15, [rsp+0x80]
00007ed4111d2c4f  por xmm1, xmm15
00007ed4111d2c54  movaps [r15+0x200], xmm1
00007ed4111d2c5c  vmovaps xmm15, [rsp+0x120]
00007ed4111d2c65  vmovaps xmm14, [rsp+0x120]
00007ed4111d2c6e  por xmm15, xmm14
00007ed4111d2c73  movaps [r15+0x1E0], xmm15
00007ed4111d2c7b  vmovaps [rsp+0x50], xmm4
00007ed4111d2c81  vmovaps xmm13, [rsp+0x50]
00007ed4111d2c87  por xmm4, xmm13
00007ed4111d2c8c  movaps [r15+0x2B0], xmm4
00007ed4111d2c94  vmovaps [rsp+0x50], xmm3
00007ed4111d2c9a  vmovaps xmm13, [rsp+0x50]
00007ed4111d2ca0  por xmm3, xmm13
00007ed4111d2ca5  movaps [r15+0x300], xmm3
00007ed4111d2cad  vmovaps xmm15, [rsp+0xB0]
00007ed4111d2cb6  vpermilpd xmm15, xmm15, 0x00
00007ed4111d2cbc  vmovaps xmm3, [rsp+0x20]
00007ed4111d2cc2  vmovaps [rsp+0x20], xmm1
00007ed4111d2cc8  vmovaps xmm1, [rsp+0xE0]
00007ed4111d2cd1  vmovaps [rsp+0x50], xmm14
00007ed4111d2cd7  vmovaps [rsp+0x60], xmm13
00007ed4111d2cdd  movaps xmm14, xmm3
00007ed4111d2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007ed4111d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007ed4111d2cec  vptest xmm13, xmm13
00007ed4111d2cf1  jnz 0x00007ED4111D3F5D
00007ed4111d2cf7  vmovaps xmm1, [rsp+0xB0]
00007ed4111d2d00  vpermilpd xmm1, xmm1, 0x00
00007ed4111d2d06  vmovaps xmm15, [rsp+0x10]
00007ed4111d2d0c  movaps xmm13, xmm15
00007ed4111d2d10  vfmadd231pd xmm13, xmm10, xmm1
00007ed4111d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007ed4111d2d1b  vptest xmm3, xmm3
00007ed4111d2d20  jnz 0x00007ED4111D40B5
00007ed4111d2d26  vmovaps xmm1, [rsp+0xB0]
00007ed4111d2d2f  vpermilpd xmm1, xmm1, 0x00
00007ed4111d2d35  vmovaps xmm15, [rsp+0x30]
00007ed4111d2d3b  movaps xmm10, xmm15
00007ed4111d2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007ed4111d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007ed4111d2d4a  vptest xmm3, xmm3
00007ed4111d2d4f  jnz 0x00007ED4111D420E
00007ed4111d2d55  vmovaps xmm1, [rsp+0xB0]
00007ed4111d2d5e  vpermilpd xmm1, xmm1, 0x00
00007ed4111d2d64  movaps xmm15, xmm12
00007ed4111d2d68  vfmadd231pd xmm15, xmm5, xmm1
00007ed4111d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007ed4111d2d73  vptest xmm11, xmm11
00007ed4111d2d78  jnz 0x00007ED4111D4367
00007ed4111d2d7e  vmovaps [rsp+0x10], xmm9
00007ed4111d2d84  vmovaps xmm1, [rsp+0x10]
00007ed4111d2d8a  por xmm9, xmm1
00007ed4111d2d8f  movaps [r15+0x180], xmm9
00007ed4111d2d97  vmovaps [rsp+0x10], xmm2
00007ed4111d2d9d  vmovaps xmm1, [rsp+0x10]
00007ed4111d2da3  por xmm2, xmm1
00007ed4111d2da7  movaps [r15+0x2D0], xmm2
00007ed4111d2daf  vmovaps xmm12, [rsp+0xD0]
00007ed4111d2db8  vpermilpd xmm12, xmm12, 0x00
00007ed4111d2dbe  vmovaps xmm11, [rsp+0x60]
00007ed4111d2dc4  movaps xmm5, xmm13
00007ed4111d2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007ed4111d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007ed4111d2dd2  vptest xmm3, xmm3
00007ed4111d2dd7  jnz 0x00007ED4111D44BF
00007ed4111d2ddd  vmovaps xmm13, [rsp+0xD0]
00007ed4111d2de6  vpermilpd xmm13, xmm13, 0x00
00007ed4111d2dec  movaps xmm12, xmm14
00007ed4111d2df0  vfmadd231pd xmm12, xmm9, xmm13
00007ed4111d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007ed4111d2dfb  vptest xmm11, xmm11
00007ed4111d2e00  jnz 0x00007ED4111D4617
00007ed4111d2e06  lea rax, [r14+0x80]
00007ed4111d2e0d  movups xmm14, [r13+rax*1]
00007ed4111d2e13  movaps [r15+0x2F0], xmm14
00007ed4111d2e1b  vmovaps xmm13, [rsp+0xD0]
00007ed4111d2e24  vpermilpd xmm13, xmm13, 0x00
00007ed4111d2e2a  movaps xmm11, xmm10
00007ed4111d2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007ed4111d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007ed4111d2e39  vptest xmm9, xmm9
00007ed4111d2e3e  jnz 0x00007ED4111D477B
00007ed4111d2e44  vmovaps xmm13, [rsp+0xD0]
00007ed4111d2e4d  vpermilpd xmm13, xmm13, 0x00
00007ed4111d2e53  movaps xmm10, xmm15
00007ed4111d2e57  vfmadd231pd xmm10, xmm1, xmm13
00007ed4111d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007ed4111d2e62  vptest xmm9, xmm9
00007ed4111d2e67  jnz 0x00007ED4111D48D5
00007ed4111d2e6d  vmovaps [rsp+0x10], xmm7
00007ed4111d2e73  vmovaps xmm1, [rsp+0x10]
00007ed4111d2e79  por xmm7, xmm1
00007ed4111d2e7d  movaps [r15+0x160], xmm7
00007ed4111d2e85  lea rax, [r14+0x40]
00007ed4111d2e89  movups xmm1, [r13+rax*1]
00007ed4111d2e8f  lea rax, [r14+0x50]
00007ed4111d2e93  movups xmm15, [r13+rax*1]
00007ed4111d2e99  movaps [r15+0x1B0], xmm1
00007ed4111d2ea1  movaps [r15+0x1A0], xmm15
00007ed4111d2ea9  vmovaps xmm13, [rsp+0xA0]
00007ed4111d2eb2  vpermilpd xmm13, xmm13, 0x00
00007ed4111d2eb8  vmovaps xmm9, [rsp+0x40]
00007ed4111d2ebe  movaps xmm8, xmm5
00007ed4111d2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007ed4111d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007ed4111d2ecd  vptest xmm3, xmm3
00007ed4111d2ed2  jnz 0x00007ED4111D4A42
00007ed4111d2ed8  vmovaps xmm13, [rsp+0xA0]
00007ed4111d2ee1  vpermilpd xmm13, xmm13, 0x00
00007ed4111d2ee7  movaps xmm9, xmm12
00007ed4111d2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007ed4111d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007ed4111d2ef6  vptest xmm5, xmm5
00007ed4111d2efb  jnz 0x00007ED4111D4B9B
00007ed4111d2f01  vmovaps xmm13, [rsp+0xA0]
00007ed4111d2f0a  vpermilpd xmm13, xmm13, 0x00
00007ed4111d2f10  movaps xmm12, xmm11
00007ed4111d2f14  vfmadd231pd xmm12, xmm6, xmm13
00007ed4111d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007ed4111d2f1f  vptest xmm7, xmm7
00007ed4111d2f24  jnz 0x00007ED4111D4CF4
00007ed4111d2f2a  vmovaps xmm13, [rsp+0xA0]
00007ed4111d2f33  vpermilpd xmm13, xmm13, 0x00
00007ed4111d2f39  vmovaps xmm11, [rsp+0x50]
00007ed4111d2f3f  movaps xmm7, xmm10
00007ed4111d2f43  vfmadd231pd xmm7, xmm11, xmm13
00007ed4111d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007ed4111d2f4d  vptest xmm6, xmm6
00007ed4111d2f52  jnz 0x00007ED4111D4E4D
00007ed4111d2f58  lea rax, [r14+0x60]
00007ed4111d2f5c  movups xmm13, [r13+rax*1]
00007ed4111d2f62  lea rax, [r14+0x70]
00007ed4111d2f66  movups xmm11, [r13+rax*1]
00007ed4111d2f6c  movaps [r15+0x150], xmm13
00007ed4111d2f74  movaps [r15+0x120], xmm11
00007ed4111d2f7c  vmovaps xmm10, [rsp+0xC0]
00007ed4111d2f85  vpermilpd xmm10, xmm10, 0x00
00007ed4111d2f8b  movaps xmm6, xmm8
00007ed4111d2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007ed4111d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007ed4111d2f99  vptest xmm5, xmm5
00007ed4111d2f9e  jnz 0x00007ED4111D4FB9
00007ed4111d2fa4  vmovaps xmm15, [rsp+0xC0]
00007ed4111d2fad  vpermilpd xmm15, xmm15, 0x00
00007ed4111d2fb3  movaps xmm10, xmm9
00007ed4111d2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007ed4111d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007ed4111d2fc2  vptest xmm8, xmm8
00007ed4111d2fc7  jnz 0x00007ED4111D5111
00007ed4111d2fcd  vmovaps xmm15, [rsp+0xC0]
00007ed4111d2fd6  vpermilpd xmm15, xmm15, 0x00
00007ed4111d2fdc  movaps xmm13, xmm12
00007ed4111d2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007ed4111d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007ed4111d2feb  vptest xmm9, xmm9
00007ed4111d2ff0  jnz 0x00007ED4111D526B
00007ed4111d2ff6  vmovaps xmm15, [rsp+0xC0]
00007ed4111d2fff  vpermilpd xmm15, xmm15, 0x00
00007ed4111d3005  movaps xmm12, xmm7
00007ed4111d3009  vfmadd231pd xmm12, xmm1, xmm15
00007ed4111d300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007ed4111d3014  vptest xmm9, xmm9
00007ed4111d3019  jnz 0x00007ED4111D53C4
00007ed4111d301f  lea rax, [r14+0x20]
00007ed4111d3023  movups xmm1, [r13+rax*1]
00007ed4111d3029  lea rax, [r14+0x30]
00007ed4111d302d  movups xmm15, [r13+rax*1]
00007ed4111d3033  vmovaps xmm9, [rsp+0x70]
00007ed4111d3039  vpermilpd xmm9, xmm9, 0x00
00007ed4111d303f  vmovaps xmm8, [rsp+0x20]
00007ed4111d3045  movaps xmm7, xmm6
00007ed4111d3048  vfmadd231pd xmm7, xmm8, xmm9
00007ed4111d304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007ed4111d3052  vptest xmm5, xmm5
00007ed4111d3057  jnz 0x00007ED4111D5530
00007ed4111d305d  vmovaps xmm9, [rsp+0x70]
00007ed4111d3063  vpermilpd xmm9, xmm9, 0x00
00007ed4111d3069  movaps xmm8, xmm10
00007ed4111d306d  vfmadd231pd xmm8, xmm14, xmm9
00007ed4111d3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007ed4111d3078  vptest xmm6, xmm6
00007ed4111d307d  jnz 0x00007ED4111D5687
00007ed4111d3083  vmovaps xmm14, [rsp+0x70]
00007ed4111d3089  vpermilpd xmm14, xmm14, 0x00
00007ed4111d308f  movaps xmm10, xmm13
00007ed4111d3093  vfmadd231pd xmm10, xmm11, xmm14
00007ed4111d3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007ed4111d309e  vptest xmm9, xmm9
00007ed4111d30a3  jnz 0x00007ED4111D57E1
00007ed4111d30a9  vmovaps xmm14, [rsp+0x70]
00007ed4111d30af  vpermilpd xmm14, xmm14, 0x00
00007ed4111d30b5  movaps xmm13, xmm12
00007ed4111d30b9  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007ed4111d30c4  vptest xmm11, xmm11
00007ed4111d30c9  jnz 0x00007ED4111D593B
00007ed4111d30cf  lea rax, [r14+0x90]
00007ed4111d30d6  movups xmm15, [r13+rax*1]
00007ed4111d30dc  lea rax, [r14+0xA0]
00007ed4111d30e3  movups xmm14, [r13+rax*1]
00007ed4111d30e9  movaps [r15+0x140], xmm15
00007ed4111d30f1  movaps [r15+0x130], xmm14
00007ed4111d30f9  vmovaps xmm12, [rsp+0x90]
00007ed4111d3102  vpermilpd xmm12, xmm12, 0x00
00007ed4111d3108  movaps xmm11, xmm7
00007ed4111d310c  vfmadd231pd xmm11, xmm1, xmm12
00007ed4111d3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007ed4111d3117  vptest xmm9, xmm9
00007ed4111d311c  jnz 0x00007ED4111D5AA9
00007ed4111d3122  movaps [r15+0x220], xmm11
00007ed4111d312a  lea rax, [r14+0x10]
00007ed4111d312e  movups xmm1, [r13+rax*1]
00007ed4111d3134  movaps [r15+0x240], xmm1
00007ed4111d313c  vmovaps xmm12, [rsp+0x90]
00007ed4111d3145  vpermilpd xmm12, xmm12, 0x00
00007ed4111d314b  movaps xmm9, xmm8
00007ed4111d314f  vfmadd231pd xmm9, xmm14, xmm12
00007ed4111d3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007ed4111d315a  vptest xmm7, xmm7
00007ed4111d315f  jnz 0x00007ED4111D5C0B
00007ed4111d3165  movaps [r15+0x110], xmm9
00007ed4111d316d  vmovaps xmm14, [rsp+0x90]
00007ed4111d3176  vpermilpd xmm14, xmm14, 0x00
00007ed4111d317c  movaps xmm12, xmm10
00007ed4111d3180  vfmadd231pd xmm12, xmm15, xmm14
00007ed4111d3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007ed4111d318b  vptest xmm8, xmm8
00007ed4111d3190  jnz 0x00007ED4111D5D65
00007ed4111d3196  movaps [r15+0x170], xmm12
00007ed4111d319e  vmovaps xmm15, [rsp+0x90]
00007ed4111d31a7  vpermilpd xmm15, xmm15, 0x00
00007ed4111d31ad  movaps xmm14, xmm13
00007ed4111d31b1  vfmadd231pd xmm14, xmm1, xmm15
00007ed4111d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007ed4111d31bc  vptest xmm10, xmm10
00007ed4111d31c1  jnz 0x00007ED4111D5EBF
00007ed4111d31c7  movaps [r15+0x230], xmm14
00007ed4111d31cf  mov eax, 0x432190
00007ed4111d31d4  movups [r13+rax*1], xmm9
00007ed4111d31da  mov eax, 0x4321A0
00007ed4111d31df  movups [r13+rax*1], xmm12
00007ed4111d31e5  mov eax, 0x4321B0
00007ed4111d31ea  movups [r13+rax*1], xmm11
00007ed4111d31f0  mov eax, 0x4321C0
00007ed4111d31f5  movups [r13+rax*1], xmm14
00007ed4111d31fb  mov eax, [r15+0x108]
00007ed4111d3202  sahf
00007ed4111d3203  jnz 0x00007ED4111D3235
00007ed4111d3205  cmp dword ptr [r15+0x318], 0x00
00007ed4111d320d  jz 0x00007ED4111D9950
00007ed4111d3213  nop [rax+rax*1], ax
00007ed4111d321c  nop [rax+rax*1], eax
00007ed4111d3224  mov eax, 0x410664
00007ed4111d3229  mov [r15+0x100], rax
00007ed4111d3230  jmp 0x00007ED410FFE110
00007ed4111d3235  cmp dword ptr [r15+0x318], 0x00
00007ed4111d323d  jz 0x00007ED4111D6050
00007ed4111d3243  nop [rax+rax*1], ax
00007ed4111d324c  nop [rax+rax*1], eax
00007ed4111d3254  mov eax, 0x4104F0
00007ed4111d3259  mov [r15+0x100], rax
00007ed4111d3260  jmp 0x00007ED410FFE110
00007ed4111d3265  int3
00007ed4111d3266  call 0x00007ED410FFF430
00007ed4111d326b  jmp 0x00007ED4111D230A
00007ed4111d3270  call 0x00007ED4110E5820
00007ed4111d3275  jmp 0x00007ED4111D2314
00007ed4111d327a  call 0x00007ED4110E45A0
00007ed4111d327f  jmp 0x00007ED4111D2326
00007ed4111d3284  call 0x00007ED4110E3320
00007ed4111d3289  jmp 0x00007ED4111D2330
00007ed4111d328e  call 0x00007ED4110E20A0
00007ed4111d3293  jmp 0x00007ED4111D233D
00007ed4111d3298  call 0x00007ED4110E0E30
00007ed4111d329d  jmp 0x00007ED4111D234A
00007ed4111d32a2  call 0x00007ED4110D6600
00007ed4111d32a7  jmp 0x00007ED4111D2357
00007ed4111d32ac  call 0x00007ED4110B52F0
00007ed4111d32b1  jmp 0x00007ED4111D2361
00007ed4111d32b6  call 0x00007ED4110BE9C0
00007ed4111d32bb  jmp 0x00007ED4111D236B
00007ed4111d32c0  call 0x00007ED4110BD750
00007ed4111d32c5  jmp 0x00007ED4111D2378
00007ed4111d32ca  call 0x00007ED4110BC4E0
00007ed4111d32cf  jmp 0x00007ED4111D2385
00007ed4111d32d4  call 0x00007ED4110BB270
00007ed4111d32d9  jmp 0x00007ED4111D2392
00007ed4111d32de  call 0x00007ED4110BA000
00007ed4111d32e3  jmp 0x00007ED4111D239F
00007ed4111d32e8  call 0x00007ED4110B8D90
00007ed4111d32ed  jmp 0x00007ED4111D23AC
00007ed4111d32f2  call 0x00007ED4110B8A20
00007ed4111d32f7  jmp 0x00007ED4111D23B9
00007ed4111d32fc  call 0x00007ED4110BEAE0
00007ed4111d3301  jmp 0x00007ED4111D23C6
00007ed4111d3306  call 0x00007ED4110B5400
00007ed4111d330b  jmp 0x00007ED4111D23D3
00007ed4111d3310  call 0x00007ED4110B52F0
00007ed4111d3315  jmp 0x00007ED4111D23E0
00007ed4111d331a  call 0x00007ED4110BE9C0
00007ed4111d331f  jmp 0x00007ED4111D23ED
00007ed4111d3324  call 0x00007ED4110B77B0
00007ed4111d3329  jmp 0x00007ED4111D23FA
00007ed4111d332e  call 0x00007ED4110B6550
00007ed4111d3333  jmp 0x00007ED4111D2407
00007ed4111d3338  call 0x00007ED4110B52F0
00007ed4111d333d  jmp 0x00007ED4111D2417
00007ed4111d3342  call 0x00007ED4110B52F0
00007ed4111d3347  jmp 0x00007ED4111D2427
00007ed4111d334c  call 0x00007ED4110BEAE0
00007ed4111d3351  jmp 0x00007ED4111D2431
00007ed4111d3356  call 0x00007ED4110BEAE0
00007ed4111d335b  jmp 0x00007ED4111D2444
00007ed4111d3360  call 0x00007ED4110BE9C0
00007ed4111d3365  jmp 0x00007ED4111D2451
00007ed4111d336a  call 0x00007ED4110B52F0
00007ed4111d336f  jmp 0x00007ED4111D2464
00007ed4111d3374  call 0x00007ED4110B6660
00007ed4111d3379  jmp 0x00007ED4111D2471
00007ed4111d337e  call 0x00007ED4110B78C0
00007ed4111d3383  jmp 0x00007ED4111D247E
00007ed4111d3388  call 0x00007ED4110B77B0
00007ed4111d338d  jmp 0x00007ED4111D248B
00007ed4111d3392  call 0x00007ED4110B6550
00007ed4111d3397  jmp 0x00007ED4111D2498
00007ed4111d339c  call 0x00007ED4110B52F0
00007ed4111d33a1  jmp 0x00007ED4111D24AB
00007ed4111d33a6  call 0x00007ED4110B52F0
00007ed4111d33ab  jmp 0x00007ED4111D24BE
00007ed4111d33b0  call 0x00007ED4110B52F0
00007ed4111d33b5  jmp 0x00007ED4111D24E5
00007ed4111d33ba  call 0x00007ED4110B52F0
00007ed4111d33bf  jmp 0x00007ED4111D24F8
00007ed4111d33c4  call 0x00007ED4110B52F0
00007ed4111d33c9  jmp 0x00007ED4111D250B
00007ed4111d33ce  call 0x00007ED4110B52F0
00007ed4111d33d3  jmp 0x00007ED4111D2521
00007ed4111d33d8  call 0x00007ED4110B52F0
00007ed4111d33dd  jmp 0x00007ED4111D2537
00007ed4111d33e2  call 0x00007ED4110B52F0
00007ed4111d33e7  jmp 0x00007ED4111D254D
00007ed4111d33ec  call 0x00007ED410FFF540
00007ed4111d33f1  jmp 0x00007ED4111D256E
00007ed4111d33f6  call 0x00007ED411002FE0
00007ed4111d33fb  jmp 0x00007ED4111D2578
00007ed4111d3400  call 0x00007ED410FFF540
00007ed4111d3405  jmp 0x00007ED4111D2588
00007ed4111d340a  call 0x00007ED410FFF540
00007ed4111d340f  jmp 0x00007ED4111D259B
00007ed4111d3414  call 0x00007ED410FFF540
00007ed4111d3419  jmp 0x00007ED4111D25AE
00007ed4111d341e  call 0x00007ED410FFF540
00007ed4111d3423  jmp 0x00007ED4111D25C1
00007ed4111d3428  call 0x00007ED4110C0370
00007ed4111d342d  jmp 0x00007ED4111D25E0
00007ed4111d3432  call 0x00007ED4110BF100
00007ed4111d3437  jmp 0x00007ED4111D25E9
00007ed4111d343c  call 0x00007ED4110C0370
00007ed4111d3441  jmp 0x00007ED4111D2659
00007ed4111d3446  call 0x00007ED4110BF100
00007ed4111d344b  jmp 0x00007ED4111D2662
00007ed4111d3450  call 0x00007ED4110C0370
00007ed4111d3455  jmp 0x00007ED4111D270C
00007ed4111d345a  call 0x00007ED4110BF100
00007ed4111d345f  jmp 0x00007ED4111D2715
00007ed4111d3464  call 0x00007ED41100B720
00007ed4111d3469  jmp 0x00007ED4111D27F7
00007ed4111d346e  call 0x00007ED4110D64F0
00007ed4111d3473  jmp 0x00007ED4111D281F
00007ed4111d3478  call 0x00007ED4110B47C0
00007ed4111d347d  jmp 0x00007ED4111D283A
00007ed4111d3482  sub rsp, 0x08
00007ed4111d3486  push rax
00007ed4111d3487  push rcx
00007ed4111d3488  push rdx
00007ed4111d3489  push rdi
00007ed4111d348a  push rsi
00007ed4111d348b  push r8
00007ed4111d348d  push r9
00007ed4111d348f  push r10
00007ed4111d3491  push r11
00007ed4111d3493  sub rsp, 0xF0
00007ed4111d349a  vmovaps [rsp], xmm0
00007ed4111d349f  vmovaps [rsp+0x10], xmm1
00007ed4111d34a5  vmovaps [rsp+0x20], xmm2
00007ed4111d34ab  vmovaps [rsp+0x30], xmm3
00007ed4111d34b1  vmovaps [rsp+0x40], xmm4
00007ed4111d34b7  vmovaps [rsp+0x50], xmm5
00007ed4111d34bd  vmovaps [rsp+0x60], xmm6
00007ed4111d34c3  vmovaps [rsp+0x70], xmm7
00007ed4111d34c9  vmovaps [rsp+0x80], xmm8
00007ed4111d34d2  vmovaps [rsp+0x90], xmm9
00007ed4111d34db  vmovaps [rsp+0xA0], xmm10
00007ed4111d34e4  vmovaps [rsp+0xB0], xmm11
00007ed4111d34ed  vmovaps [rsp+0xC0], xmm12
00007ed4111d34f6  vmovaps [rsp+0xD0], xmm14
00007ed4111d34ff  vmovaps [rsp+0xE0], xmm15
00007ed4111d3508  sub rsp, 0x40
00007ed4111d350c  lea rdi, [rsp]
00007ed4111d3510  lea rsi, [rsp+0x10]
00007ed4111d3515  lea rdx, [rsp+0x20]
00007ed4111d351a  lea rcx, [rsp+0x30]
00007ed4111d351f  mov r8d, 0x00
00007ed4111d3525  lea r9, [r15+0x3A8]
00007ed4111d352c  movaps [rdi], xmm13
00007ed4111d3530  movaps [rsi], xmm1
00007ed4111d3533  movaps [rdx], xmm15
00007ed4111d3537  movaps [rcx], xmm14
00007ed4111d353b  mov rax, 0x5CA8E4A55A50
00007ed4111d3545  call rax
00007ed4111d3547  movaps xmm13, [rsp]
00007ed4111d354c  add rsp, 0x40
00007ed4111d3550  vmovaps xmm0, [rsp]
00007ed4111d3555  vmovaps xmm1, [rsp+0x10]
00007ed4111d355b  vmovaps xmm2, [rsp+0x20]
00007ed4111d3561  vmovaps xmm3, [rsp+0x30]
00007ed4111d3567  vmovaps xmm4, [rsp+0x40]
00007ed4111d356d  vmovaps xmm5, [rsp+0x50]
00007ed4111d3573  vmovaps xmm6, [rsp+0x60]
00007ed4111d3579  vmovaps xmm7, [rsp+0x70]
00007ed4111d357f  vmovaps xmm8, [rsp+0x80]
00007ed4111d3588  vmovaps xmm9, [rsp+0x90]
00007ed4111d3591  vmovaps xmm10, [rsp+0xA0]
00007ed4111d359a  vmovaps xmm11, [rsp+0xB0]
00007ed4111d35a3  vmovaps xmm12, [rsp+0xC0]
00007ed4111d35ac  vmovaps xmm14, [rsp+0xD0]
00007ed4111d35b5  vmovaps xmm15, [rsp+0xE0]
00007ed4111d35be  add rsp, 0xF0
00007ed4111d35c5  pop r11
00007ed4111d35c7  pop r10
00007ed4111d35c9  pop r9
00007ed4111d35cb  pop r8
00007ed4111d35cd  pop rsi
00007ed4111d35ce  pop rdi
00007ed4111d35cf  pop rdx
00007ed4111d35d0  pop rcx
00007ed4111d35d1  pop rax
00007ed4111d35d2  add rsp, 0x08
00007ed4111d35d6  jmp 0x00007ED4111D28AD
00007ed4111d35db  sub rsp, 0x08
00007ed4111d35df  push rax
00007ed4111d35e0  push rcx
00007ed4111d35e1  push rdx
00007ed4111d35e2  push rdi
00007ed4111d35e3  push rsi
00007ed4111d35e4  push r8
00007ed4111d35e6  push r9
00007ed4111d35e8  push r10
00007ed4111d35ea  push r11
00007ed4111d35ec  sub rsp, 0xF0
00007ed4111d35f3  vmovaps [rsp], xmm0
00007ed4111d35f8  vmovaps [rsp+0x10], xmm1
00007ed4111d35fe  vmovaps [rsp+0x20], xmm2
00007ed4111d3604  vmovaps [rsp+0x30], xmm3
00007ed4111d360a  vmovaps [rsp+0x40], xmm4
00007ed4111d3610  vmovaps [rsp+0x50], xmm5
00007ed4111d3616  vmovaps [rsp+0x60], xmm6
00007ed4111d361c  vmovaps [rsp+0x70], xmm7
00007ed4111d3622  vmovaps [rsp+0x80], xmm8
00007ed4111d362b  vmovaps [rsp+0x90], xmm9
00007ed4111d3634  vmovaps [rsp+0xA0], xmm10
00007ed4111d363d  vmovaps [rsp+0xB0], xmm11
00007ed4111d3646  vmovaps [rsp+0xC0], xmm12
00007ed4111d364f  vmovaps [rsp+0xD0], xmm13
00007ed4111d3658  vmovaps [rsp+0xE0], xmm14
00007ed4111d3661  sub rsp, 0x40
00007ed4111d3665  lea rdi, [rsp]
00007ed4111d3669  lea rsi, [rsp+0x10]
00007ed4111d366e  lea rdx, [rsp+0x20]
00007ed4111d3673  lea rcx, [rsp+0x30]
00007ed4111d3678  mov r8d, 0x00
00007ed4111d367e  lea r9, [r15+0x3A8]
00007ed4111d3685  movaps [rdi], xmm15
00007ed4111d3689  movaps [rsi], xmm5
00007ed4111d368c  movaps [rdx], xmm1
00007ed4111d368f  movaps [rcx], xmm14
00007ed4111d3693  mov rax, 0x5CA8E4A55A50
00007ed4111d369d  call rax
00007ed4111d369f  movaps xmm15, [rsp]
00007ed4111d36a4  add rsp, 0x40
00007ed4111d36a8  vmovaps xmm0, [rsp]
00007ed4111d36ad  vmovaps xmm1, [rsp+0x10]
00007ed4111d36b3  vmovaps xmm2, [rsp+0x20]
00007ed4111d36b9  vmovaps xmm3, [rsp+0x30]
00007ed4111d36bf  vmovaps xmm4, [rsp+0x40]
00007ed4111d36c5  vmovaps xmm5, [rsp+0x50]
00007ed4111d36cb  vmovaps xmm6, [rsp+0x60]
00007ed4111d36d1  vmovaps xmm7, [rsp+0x70]
00007ed4111d36d7  vmovaps xmm8, [rsp+0x80]
00007ed4111d36e0  vmovaps xmm9, [rsp+0x90]
00007ed4111d36e9  vmovaps xmm10, [rsp+0xA0]
00007ed4111d36f2  vmovaps xmm11, [rsp+0xB0]
00007ed4111d36fb  vmovaps xmm12, [rsp+0xC0]
00007ed4111d3704  vmovaps xmm13, [rsp+0xD0]
00007ed4111d370d  vmovaps xmm14, [rsp+0xE0]
00007ed4111d3716  add rsp, 0xF0
00007ed4111d371d  pop r11
00007ed4111d371f  pop r10
00007ed4111d3721  pop r9
00007ed4111d3723  pop r8
00007ed4111d3725  pop rsi
00007ed4111d3726  pop rdi
00007ed4111d3727  pop rdx
00007ed4111d3728  pop rcx
00007ed4111d3729  pop rax
00007ed4111d372a  add rsp, 0x08
00007ed4111d372e  jmp 0x00007ED4111D28D0
00007ed4111d3733  call 0x00007ED410FFF430
00007ed4111d3738  jmp 0x00007ED4111D295D
00007ed4111d373d  sub rsp, 0x08
00007ed4111d3741  push rax
00007ed4111d3742  push rcx
00007ed4111d3743  push rdx
00007ed4111d3744  push rdi
00007ed4111d3745  push rsi
00007ed4111d3746  push r8
00007ed4111d3748  push r9
00007ed4111d374a  push r10
00007ed4111d374c  push r11
00007ed4111d374e  sub rsp, 0xF0
00007ed4111d3755  vmovaps [rsp], xmm0
00007ed4111d375a  vmovaps [rsp+0x10], xmm1
00007ed4111d3760  vmovaps [rsp+0x20], xmm2
00007ed4111d3766  vmovaps [rsp+0x30], xmm3
00007ed4111d376c  vmovaps [rsp+0x40], xmm4
00007ed4111d3772  vmovaps [rsp+0x50], xmm5
00007ed4111d3778  vmovaps [rsp+0x60], xmm6
00007ed4111d377e  vmovaps [rsp+0x70], xmm7
00007ed4111d3784  vmovaps [rsp+0x80], xmm8
00007ed4111d378d  vmovaps [rsp+0x90], xmm9
00007ed4111d3796  vmovaps [rsp+0xA0], xmm10
00007ed4111d379f  vmovaps [rsp+0xB0], xmm11
00007ed4111d37a8  vmovaps [rsp+0xC0], xmm12
00007ed4111d37b1  vmovaps [rsp+0xD0], xmm14
00007ed4111d37ba  vmovaps [rsp+0xE0], xmm15
00007ed4111d37c3  sub rsp, 0x40
00007ed4111d37c7  lea rdi, [rsp]
00007ed4111d37cb  lea rsi, [rsp+0x10]
00007ed4111d37d0  lea rdx, [rsp+0x20]
00007ed4111d37d5  lea rcx, [rsp+0x30]
00007ed4111d37da  mov r8d, 0x00
00007ed4111d37e0  lea r9, [r15+0x3A8]
00007ed4111d37e7  movaps [rdi], xmm13
00007ed4111d37eb  movaps [rsi], xmm1
00007ed4111d37ee  movaps [rdx], xmm15
00007ed4111d37f2  movaps [rcx], xmm14
00007ed4111d37f6  mov rax, 0x5CA8E4A55A50
00007ed4111d3800  call rax
00007ed4111d3802  movaps xmm13, [rsp]
00007ed4111d3807  add rsp, 0x40
00007ed4111d380b  vmovaps xmm0, [rsp]
00007ed4111d3810  vmovaps xmm1, [rsp+0x10]
00007ed4111d3816  vmovaps xmm2, [rsp+0x20]
00007ed4111d381c  vmovaps xmm3, [rsp+0x30]
00007ed4111d3822  vmovaps xmm4, [rsp+0x40]
00007ed4111d3828  vmovaps xmm5, [rsp+0x50]
00007ed4111d382e  vmovaps xmm6, [rsp+0x60]
00007ed4111d3834  vmovaps xmm7, [rsp+0x70]
00007ed4111d383a  vmovaps xmm8, [rsp+0x80]
00007ed4111d3843  vmovaps xmm9, [rsp+0x90]
00007ed4111d384c  vmovaps xmm10, [rsp+0xA0]
00007ed4111d3855  vmovaps xmm11, [rsp+0xB0]
00007ed4111d385e  vmovaps xmm12, [rsp+0xC0]
00007ed4111d3867  vmovaps xmm14, [rsp+0xD0]
00007ed4111d3870  vmovaps xmm15, [rsp+0xE0]
00007ed4111d3879  add rsp, 0xF0
00007ed4111d3880  pop r11
00007ed4111d3882  pop r10
00007ed4111d3884  pop r9
00007ed4111d3886  pop r8
00007ed4111d3888  pop rsi
00007ed4111d3889  pop rdi
00007ed4111d388a  pop rdx
00007ed4111d388b  pop rcx
00007ed4111d388c  pop rax
00007ed4111d388d  add rsp, 0x08
00007ed4111d3891  jmp 0x00007ED4111D29C1
00007ed4111d3896  call 0x00007ED410FFF430
00007ed4111d389b  jmp 0x00007ED4111D29CE
00007ed4111d38a0  sub rsp, 0x08
00007ed4111d38a4  push rax
00007ed4111d38a5  push rcx
00007ed4111d38a6  push rdx
00007ed4111d38a7  push rdi
00007ed4111d38a8  push rsi
00007ed4111d38a9  push r8
00007ed4111d38ab  push r9
00007ed4111d38ad  push r10
00007ed4111d38af  push r11
00007ed4111d38b1  sub rsp, 0xF0
00007ed4111d38b8  vmovaps [rsp], xmm0
00007ed4111d38bd  vmovaps [rsp+0x10], xmm1
00007ed4111d38c3  vmovaps [rsp+0x20], xmm2
00007ed4111d38c9  vmovaps [rsp+0x30], xmm3
00007ed4111d38cf  vmovaps [rsp+0x40], xmm4
00007ed4111d38d5  vmovaps [rsp+0x50], xmm5
00007ed4111d38db  vmovaps [rsp+0x60], xmm6
00007ed4111d38e1  vmovaps [rsp+0x70], xmm7
00007ed4111d38e7  vmovaps [rsp+0x80], xmm8
00007ed4111d38f0  vmovaps [rsp+0x90], xmm9
00007ed4111d38f9  vmovaps [rsp+0xA0], xmm10
00007ed4111d3902  vmovaps [rsp+0xB0], xmm11
00007ed4111d390b  vmovaps [rsp+0xC0], xmm13
00007ed4111d3914  vmovaps [rsp+0xD0], xmm14
00007ed4111d391d  vmovaps [rsp+0xE0], xmm15
00007ed4111d3926  sub rsp, 0x40
00007ed4111d392a  lea rdi, [rsp]
00007ed4111d392e  lea rsi, [rsp+0x10]
00007ed4111d3933  lea rdx, [rsp+0x20]
00007ed4111d3938  lea rcx, [rsp+0x30]
00007ed4111d393d  mov r8d, 0x00
00007ed4111d3943  lea r9, [r15+0x3A8]
00007ed4111d394a  movaps [rdi], xmm12
00007ed4111d394e  movaps [rsi], xmm15
00007ed4111d3952  movaps [rdx], xmm1
00007ed4111d3955  movaps [rcx], xmm14
00007ed4111d3959  mov rax, 0x5CA8E4A55A50
00007ed4111d3963  call rax
00007ed4111d3965  movaps xmm12, [rsp]
00007ed4111d396a  add rsp, 0x40
00007ed4111d396e  vmovaps xmm0, [rsp]
00007ed4111d3973  vmovaps xmm1, [rsp+0x10]
00007ed4111d3979  vmovaps xmm2, [rsp+0x20]
00007ed4111d397f  vmovaps xmm3, [rsp+0x30]
00007ed4111d3985  vmovaps xmm4, [rsp+0x40]
00007ed4111d398b  vmovaps xmm5, [rsp+0x50]
00007ed4111d3991  vmovaps xmm6, [rsp+0x60]
00007ed4111d3997  vmovaps xmm7, [rsp+0x70]
00007ed4111d399d  vmovaps xmm8, [rsp+0x80]
00007ed4111d39a6  vmovaps xmm9, [rsp+0x90]
00007ed4111d39af  vmovaps xmm10, [rsp+0xA0]
00007ed4111d39b8  vmovaps xmm11, [rsp+0xB0]
00007ed4111d39c1  vmovaps xmm13, [rsp+0xC0]
00007ed4111d39ca  vmovaps xmm14, [rsp+0xD0]
00007ed4111d39d3  vmovaps xmm15, [rsp+0xE0]
00007ed4111d39dc  add rsp, 0xF0
00007ed4111d39e3  pop r11
00007ed4111d39e5  pop r10
00007ed4111d39e7  pop r9
00007ed4111d39e9  pop r8
00007ed4111d39eb  pop rsi
00007ed4111d39ec  pop rdi
00007ed4111d39ed  pop rdx
00007ed4111d39ee  pop rcx
00007ed4111d39ef  pop rax
00007ed4111d39f0  add rsp, 0x08
00007ed4111d39f4  jmp 0x00007ED4111D29FA
00007ed4111d39f9  sub rsp, 0x08
00007ed4111d39fd  push rax
00007ed4111d39fe  push rcx
00007ed4111d39ff  push rdx
00007ed4111d3a00  push rdi
00007ed4111d3a01  push rsi
00007ed4111d3a02  push r8
00007ed4111d3a04  push r9
00007ed4111d3a06  push r10
00007ed4111d3a08  push r11
00007ed4111d3a0a  sub rsp, 0xF0
00007ed4111d3a11  vmovaps [rsp], xmm0
00007ed4111d3a16  vmovaps [rsp+0x10], xmm1
00007ed4111d3a1c  vmovaps [rsp+0x20], xmm2
00007ed4111d3a22  vmovaps [rsp+0x30], xmm3
00007ed4111d3a28  vmovaps [rsp+0x40], xmm4
00007ed4111d3a2e  vmovaps [rsp+0x50], xmm5
00007ed4111d3a34  vmovaps [rsp+0x60], xmm6
00007ed4111d3a3a  vmovaps [rsp+0x70], xmm7
00007ed4111d3a40  vmovaps [rsp+0x80], xmm8
00007ed4111d3a49  vmovaps [rsp+0x90], xmm9
00007ed4111d3a52  vmovaps [rsp+0xA0], xmm10
00007ed4111d3a5b  vmovaps [rsp+0xB0], xmm11
00007ed4111d3a64  vmovaps [rsp+0xC0], xmm12
00007ed4111d3a6d  vmovaps [rsp+0xD0], xmm14
00007ed4111d3a76  vmovaps [rsp+0xE0], xmm15
00007ed4111d3a7f  sub rsp, 0x40
00007ed4111d3a83  lea rdi, [rsp]
00007ed4111d3a87  lea rsi, [rsp+0x10]
00007ed4111d3a8c  lea rdx, [rsp+0x20]
00007ed4111d3a91  lea rcx, [rsp+0x30]
00007ed4111d3a96  mov r8d, 0x00
00007ed4111d3a9c  lea r9, [r15+0x3A8]
00007ed4111d3aa3  movaps [rdi], xmm13
00007ed4111d3aa7  movaps [rsi], xmm1
00007ed4111d3aaa  movaps [rdx], xmm15
00007ed4111d3aae  movaps [rcx], xmm14
00007ed4111d3ab2  mov rax, 0x5CA8E4A55A50
00007ed4111d3abc  call rax
00007ed4111d3abe  movaps xmm13, [rsp]
00007ed4111d3ac3  add rsp, 0x40
00007ed4111d3ac7  vmovaps xmm0, [rsp]
00007ed4111d3acc  vmovaps xmm1, [rsp+0x10]
00007ed4111d3ad2  vmovaps xmm2, [rsp+0x20]
00007ed4111d3ad8  vmovaps xmm3, [rsp+0x30]
00007ed4111d3ade  vmovaps xmm4, [rsp+0x40]
00007ed4111d3ae4  vmovaps xmm5, [rsp+0x50]
00007ed4111d3aea  vmovaps xmm6, [rsp+0x60]
00007ed4111d3af0  vmovaps xmm7, [rsp+0x70]
00007ed4111d3af6  vmovaps xmm8, [rsp+0x80]
00007ed4111d3aff  vmovaps xmm9, [rsp+0x90]
00007ed4111d3b08  vmovaps xmm10, [rsp+0xA0]
00007ed4111d3b11  vmovaps xmm11, [rsp+0xB0]
00007ed4111d3b1a  vmovaps xmm12, [rsp+0xC0]
00007ed4111d3b23  vmovaps xmm14, [rsp+0xD0]
00007ed4111d3b2c  vmovaps xmm15, [rsp+0xE0]
00007ed4111d3b35  add rsp, 0xF0
00007ed4111d3b3c  pop r11
00007ed4111d3b3e  pop r10
00007ed4111d3b40  pop r9
00007ed4111d3b42  pop r8
00007ed4111d3b44  pop rsi
00007ed4111d3b45  pop rdi
00007ed4111d3b46  pop rdx
00007ed4111d3b47  pop rcx
00007ed4111d3b48  pop rax
00007ed4111d3b49  add rsp, 0x08
00007ed4111d3b4d  jmp 0x00007ED4111D2B77
00007ed4111d3b52  sub rsp, 0x08
00007ed4111d3b56  push rax
00007ed4111d3b57  push rcx
00007ed4111d3b58  push rdx
00007ed4111d3b59  push rdi
00007ed4111d3b5a  push rsi
00007ed4111d3b5b  push r8
00007ed4111d3b5d  push r9
00007ed4111d3b5f  push r10
00007ed4111d3b61  push r11
00007ed4111d3b63  sub rsp, 0xF0
00007ed4111d3b6a  vmovaps [rsp], xmm0
00007ed4111d3b6f  vmovaps [rsp+0x10], xmm1
00007ed4111d3b75  vmovaps [rsp+0x20], xmm2
00007ed4111d3b7b  vmovaps [rsp+0x30], xmm3
00007ed4111d3b81  vmovaps [rsp+0x40], xmm4
00007ed4111d3b87  vmovaps [rsp+0x50], xmm5
00007ed4111d3b8d  vmovaps [rsp+0x60], xmm6
00007ed4111d3b93  vmovaps [rsp+0x70], xmm7
00007ed4111d3b99  vmovaps [rsp+0x80], xmm8
00007ed4111d3ba2  vmovaps [rsp+0x90], xmm9
00007ed4111d3bab  vmovaps [rsp+0xA0], xmm10
00007ed4111d3bb4  vmovaps [rsp+0xB0], xmm11
00007ed4111d3bbd  vmovaps [rsp+0xC0], xmm13
00007ed4111d3bc6  vmovaps [rsp+0xD0], xmm14
00007ed4111d3bcf  vmovaps [rsp+0xE0], xmm15
00007ed4111d3bd8  sub rsp, 0x40
00007ed4111d3bdc  lea rdi, [rsp]
00007ed4111d3be0  lea rsi, [rsp+0x10]
00007ed4111d3be5  lea rdx, [rsp+0x20]
00007ed4111d3bea  lea rcx, [rsp+0x30]
00007ed4111d3bef  mov r8d, 0x00
00007ed4111d3bf5  lea r9, [r15+0x3A8]
00007ed4111d3bfc  movaps [rdi], xmm12
00007ed4111d3c00  movaps [rsi], xmm15
00007ed4111d3c04  movaps [rdx], xmm14
00007ed4111d3c08  movaps [rcx], xmm1
00007ed4111d3c0b  mov rax, 0x5CA8E4A55A50
00007ed4111d3c15  call rax
00007ed4111d3c17  movaps xmm12, [rsp]
00007ed4111d3c1c  add rsp, 0x40
00007ed4111d3c20  vmovaps xmm0, [rsp]
00007ed4111d3c25  vmovaps xmm1, [rsp+0x10]
00007ed4111d3c2b  vmovaps xmm2, [rsp+0x20]
00007ed4111d3c31  vmovaps xmm3, [rsp+0x30]
00007ed4111d3c37  vmovaps xmm4, [rsp+0x40]
00007ed4111d3c3d  vmovaps xmm5, [rsp+0x50]
00007ed4111d3c43  vmovaps xmm6, [rsp+0x60]
00007ed4111d3c49  vmovaps xmm7, [rsp+0x70]
00007ed4111d3c4f  vmovaps xmm8, [rsp+0x80]
00007ed4111d3c58  vmovaps xmm9, [rsp+0x90]
00007ed4111d3c61  vmovaps xmm10, [rsp+0xA0]
00007ed4111d3c6a  vmovaps xmm11, [rsp+0xB0]
00007ed4111d3c73  vmovaps xmm13, [rsp+0xC0]
00007ed4111d3c7c  vmovaps xmm14, [rsp+0xD0]
00007ed4111d3c85  vmovaps xmm15, [rsp+0xE0]
00007ed4111d3c8e  add rsp, 0xF0
00007ed4111d3c95  pop r11
00007ed4111d3c97  pop r10
00007ed4111d3c99  pop r9
00007ed4111d3c9b  pop r8
00007ed4111d3c9d  pop rsi
00007ed4111d3c9e  pop rdi
00007ed4111d3c9f  pop rdx
00007ed4111d3ca0  pop rcx
00007ed4111d3ca1  pop rax
00007ed4111d3ca2  add rsp, 0x08
00007ed4111d3ca6  jmp 0x00007ED4111D2BB2
00007ed4111d3cab  sub rsp, 0x08
00007ed4111d3caf  push rax
00007ed4111d3cb0  push rcx
00007ed4111d3cb1  push rdx
00007ed4111d3cb2  push rdi
00007ed4111d3cb3  push rsi
00007ed4111d3cb4  push r8
00007ed4111d3cb6  push r9
00007ed4111d3cb8  push r10
00007ed4111d3cba  push r11
00007ed4111d3cbc  sub rsp, 0xF0
00007ed4111d3cc3  vmovaps [rsp], xmm0
00007ed4111d3cc8  vmovaps [rsp+0x10], xmm1
00007ed4111d3cce  vmovaps [rsp+0x20], xmm2
00007ed4111d3cd4  vmovaps [rsp+0x30], xmm3
00007ed4111d3cda  vmovaps [rsp+0x40], xmm4
00007ed4111d3ce0  vmovaps [rsp+0x50], xmm5
00007ed4111d3ce6  vmovaps [rsp+0x60], xmm6
00007ed4111d3cec  vmovaps [rsp+0x70], xmm7
00007ed4111d3cf2  vmovaps [rsp+0x80], xmm8
00007ed4111d3cfb  vmovaps [rsp+0x90], xmm9
00007ed4111d3d04  vmovaps [rsp+0xA0], xmm10
00007ed4111d3d0d  vmovaps [rsp+0xB0], xmm11
00007ed4111d3d16  vmovaps [rsp+0xC0], xmm12
00007ed4111d3d1f  vmovaps [rsp+0xD0], xmm14
00007ed4111d3d28  vmovaps [rsp+0xE0], xmm15
00007ed4111d3d31  sub rsp, 0x40
00007ed4111d3d35  lea rdi, [rsp]
00007ed4111d3d39  lea rsi, [rsp+0x10]
00007ed4111d3d3e  lea rdx, [rsp+0x20]
00007ed4111d3d43  lea rcx, [rsp+0x30]
00007ed4111d3d48  mov r8d, 0x00
00007ed4111d3d4e  lea r9, [r15+0x3A8]
00007ed4111d3d55  movaps [rdi], xmm13
00007ed4111d3d59  movaps [rsi], xmm15
00007ed4111d3d5d  movaps [rdx], xmm14
00007ed4111d3d61  movaps [rcx], xmm1
00007ed4111d3d64  mov rax, 0x5CA8E4A55A50
00007ed4111d3d6e  call rax
00007ed4111d3d70  movaps xmm13, [rsp]
00007ed4111d3d75  add rsp, 0x40
00007ed4111d3d79  vmovaps xmm0, [rsp]
00007ed4111d3d7e  vmovaps xmm1, [rsp+0x10]
00007ed4111d3d84  vmovaps xmm2, [rsp+0x20]
00007ed4111d3d8a  vmovaps xmm3, [rsp+0x30]
00007ed4111d3d90  vmovaps xmm4, [rsp+0x40]
00007ed4111d3d96  vmovaps xmm5, [rsp+0x50]
00007ed4111d3d9c  vmovaps xmm6, [rsp+0x60]
00007ed4111d3da2  vmovaps xmm7, [rsp+0x70]
00007ed4111d3da8  vmovaps xmm8, [rsp+0x80]
00007ed4111d3db1  vmovaps xmm9, [rsp+0x90]
00007ed4111d3dba  vmovaps xmm10, [rsp+0xA0]
00007ed4111d3dc3  vmovaps xmm11, [rsp+0xB0]
00007ed4111d3dcc  vmovaps xmm12, [rsp+0xC0]
00007ed4111d3dd5  vmovaps xmm14, [rsp+0xD0]
00007ed4111d3dde  vmovaps xmm15, [rsp+0xE0]
00007ed4111d3de7  add rsp, 0xF0
00007ed4111d3dee  pop r11
00007ed4111d3df0  pop r10
00007ed4111d3df2  pop r9
00007ed4111d3df4  pop r8
00007ed4111d3df6  pop rsi
00007ed4111d3df7  pop rdi
00007ed4111d3df8  pop rdx
00007ed4111d3df9  pop rcx
00007ed4111d3dfa  pop rax
00007ed4111d3dfb  add rsp, 0x08
00007ed4111d3dff  jmp 0x00007ED4111D2BEA
00007ed4111d3e04  sub rsp, 0x08
00007ed4111d3e08  push rax
00007ed4111d3e09  push rcx
00007ed4111d3e0a  push rdx
00007ed4111d3e0b  push rdi
00007ed4111d3e0c  push rsi
00007ed4111d3e0d  push r8
00007ed4111d3e0f  push r9
00007ed4111d3e11  push r10
00007ed4111d3e13  push r11
00007ed4111d3e15  sub rsp, 0xF0
00007ed4111d3e1c  vmovaps [rsp], xmm0
00007ed4111d3e21  vmovaps [rsp+0x10], xmm1
00007ed4111d3e27  vmovaps [rsp+0x20], xmm2
00007ed4111d3e2d  vmovaps [rsp+0x30], xmm3
00007ed4111d3e33  vmovaps [rsp+0x40], xmm4
00007ed4111d3e39  vmovaps [rsp+0x50], xmm5
00007ed4111d3e3f  vmovaps [rsp+0x60], xmm6
00007ed4111d3e45  vmovaps [rsp+0x70], xmm7
00007ed4111d3e4b  vmovaps [rsp+0x80], xmm8
00007ed4111d3e54  vmovaps [rsp+0x90], xmm9
00007ed4111d3e5d  vmovaps [rsp+0xA0], xmm10
00007ed4111d3e66  vmovaps [rsp+0xB0], xmm11
00007ed4111d3e6f  vmovaps [rsp+0xC0], xmm13
00007ed4111d3e78  vmovaps [rsp+0xD0], xmm14
00007ed4111d3e81  vmovaps [rsp+0xE0], xmm15
00007ed4111d3e8a  sub rsp, 0x40
00007ed4111d3e8e  lea rdi, [rsp]
00007ed4111d3e92  lea rsi, [rsp+0x10]
00007ed4111d3e97  lea rdx, [rsp+0x20]
00007ed4111d3e9c  lea rcx, [rsp+0x30]
00007ed4111d3ea1  mov r8d, 0x00
00007ed4111d3ea7  lea r9, [r15+0x3A8]
00007ed4111d3eae  movaps [rdi], xmm12
00007ed4111d3eb2  movaps [rsi], xmm15
00007ed4111d3eb6  movaps [rdx], xmm14
00007ed4111d3eba  movaps [rcx], xmm1
00007ed4111d3ebd  mov rax, 0x5CA8E4A55A50
00007ed4111d3ec7  call rax
00007ed4111d3ec9  movaps xmm12, [rsp]
00007ed4111d3ece  add rsp, 0x40
00007ed4111d3ed2  vmovaps xmm0, [rsp]
00007ed4111d3ed7  vmovaps xmm1, [rsp+0x10]
00007ed4111d3edd  vmovaps xmm2, [rsp+0x20]
00007ed4111d3ee3  vmovaps xmm3, [rsp+0x30]
00007ed4111d3ee9  vmovaps xmm4, [rsp+0x40]
00007ed4111d3eef  vmovaps xmm5, [rsp+0x50]
00007ed4111d3ef5  vmovaps xmm6, [rsp+0x60]
00007ed4111d3efb  vmovaps xmm7, [rsp+0x70]
00007ed4111d3f01  vmovaps xmm8, [rsp+0x80]
00007ed4111d3f0a  vmovaps xmm9, [rsp+0x90]
00007ed4111d3f13  vmovaps xmm10, [rsp+0xA0]
00007ed4111d3f1c  vmovaps xmm11, [rsp+0xB0]
00007ed4111d3f25  vmovaps xmm13, [rsp+0xC0]
00007ed4111d3f2e  vmovaps xmm14, [rsp+0xD0]
00007ed4111d3f37  vmovaps xmm15, [rsp+0xE0]
00007ed4111d3f40  add rsp, 0xF0
00007ed4111d3f47  pop r11
00007ed4111d3f49  pop r10
00007ed4111d3f4b  pop r9
00007ed4111d3f4d  pop r8
00007ed4111d3f4f  pop rsi
00007ed4111d3f50  pop rdi
00007ed4111d3f51  pop rdx
00007ed4111d3f52  pop rcx
00007ed4111d3f53  pop rax
00007ed4111d3f54  add rsp, 0x08
00007ed4111d3f58  jmp 0x00007ED4111D2C3D
00007ed4111d3f5d  sub rsp, 0x08
00007ed4111d3f61  push rax
00007ed4111d3f62  push rcx
00007ed4111d3f63  push rdx
00007ed4111d3f64  push rdi
00007ed4111d3f65  push rsi
00007ed4111d3f66  push r8
00007ed4111d3f68  push r9
00007ed4111d3f6a  push r10
00007ed4111d3f6c  push r11
00007ed4111d3f6e  sub rsp, 0xF0
00007ed4111d3f75  vmovaps [rsp], xmm0
00007ed4111d3f7a  vmovaps [rsp+0x10], xmm1
00007ed4111d3f80  vmovaps [rsp+0x20], xmm2
00007ed4111d3f86  vmovaps [rsp+0x30], xmm3
00007ed4111d3f8c  vmovaps [rsp+0x40], xmm4
00007ed4111d3f92  vmovaps [rsp+0x50], xmm5
00007ed4111d3f98  vmovaps [rsp+0x60], xmm6
00007ed4111d3f9e  vmovaps [rsp+0x70], xmm7
00007ed4111d3fa4  vmovaps [rsp+0x80], xmm8
00007ed4111d3fad  vmovaps [rsp+0x90], xmm9
00007ed4111d3fb6  vmovaps [rsp+0xA0], xmm10
00007ed4111d3fbf  vmovaps [rsp+0xB0], xmm11
00007ed4111d3fc8  vmovaps [rsp+0xC0], xmm12
00007ed4111d3fd1  vmovaps [rsp+0xD0], xmm13
00007ed4111d3fda  vmovaps [rsp+0xE0], xmm15
00007ed4111d3fe3  sub rsp, 0x40
00007ed4111d3fe7  lea rdi, [rsp]
00007ed4111d3feb  lea rsi, [rsp+0x10]
00007ed4111d3ff0  lea rdx, [rsp+0x20]
00007ed4111d3ff5  lea rcx, [rsp+0x30]
00007ed4111d3ffa  mov r8d, 0x00
00007ed4111d4000  lea r9, [r15+0x3A8]
00007ed4111d4007  movaps [rdi], xmm14
00007ed4111d400b  movaps [rsi], xmm3
00007ed4111d400e  movaps [rdx], xmm1
00007ed4111d4011  movaps [rcx], xmm15
00007ed4111d4015  mov rax, 0x5CA8E4A55A50
00007ed4111d401f  call rax
00007ed4111d4021  movaps xmm14, [rsp]
00007ed4111d4026  add rsp, 0x40
00007ed4111d402a  vmovaps xmm0, [rsp]
00007ed4111d402f  vmovaps xmm1, [rsp+0x10]
00007ed4111d4035  vmovaps xmm2, [rsp+0x20]
00007ed4111d403b  vmovaps xmm3, [rsp+0x30]
00007ed4111d4041  vmovaps xmm4, [rsp+0x40]
00007ed4111d4047  vmovaps xmm5, [rsp+0x50]
00007ed4111d404d  vmovaps xmm6, [rsp+0x60]
00007ed4111d4053  vmovaps xmm7, [rsp+0x70]
00007ed4111d4059  vmovaps xmm8, [rsp+0x80]
00007ed4111d4062  vmovaps xmm9, [rsp+0x90]
00007ed4111d406b  vmovaps xmm10, [rsp+0xA0]
00007ed4111d4074  vmovaps xmm11, [rsp+0xB0]
00007ed4111d407d  vmovaps xmm12, [rsp+0xC0]
00007ed4111d4086  vmovaps xmm13, [rsp+0xD0]
00007ed4111d408f  vmovaps xmm15, [rsp+0xE0]
00007ed4111d4098  add rsp, 0xF0
00007ed4111d409f  pop r11
00007ed4111d40a1  pop r10
00007ed4111d40a3  pop r9
00007ed4111d40a5  pop r8
00007ed4111d40a7  pop rsi
00007ed4111d40a8  pop rdi
00007ed4111d40a9  pop rdx
00007ed4111d40aa  pop rcx
00007ed4111d40ab  pop rax
00007ed4111d40ac  add rsp, 0x08
00007ed4111d40b0  jmp 0x00007ED4111D2CF7
00007ed4111d40b5  sub rsp, 0x08
00007ed4111d40b9  push rax
00007ed4111d40ba  push rcx
00007ed4111d40bb  push rdx
00007ed4111d40bc  push rdi
00007ed4111d40bd  push rsi
00007ed4111d40be  push r8
00007ed4111d40c0  push r9
00007ed4111d40c2  push r10
00007ed4111d40c4  push r11
00007ed4111d40c6  sub rsp, 0xF0
00007ed4111d40cd  vmovaps [rsp], xmm0
00007ed4111d40d2  vmovaps [rsp+0x10], xmm1
00007ed4111d40d8  vmovaps [rsp+0x20], xmm2
00007ed4111d40de  vmovaps [rsp+0x30], xmm3
00007ed4111d40e4  vmovaps [rsp+0x40], xmm4
00007ed4111d40ea  vmovaps [rsp+0x50], xmm5
00007ed4111d40f0  vmovaps [rsp+0x60], xmm6
00007ed4111d40f6  vmovaps [rsp+0x70], xmm7
00007ed4111d40fc  vmovaps [rsp+0x80], xmm8
00007ed4111d4105  vmovaps [rsp+0x90], xmm9
00007ed4111d410e  vmovaps [rsp+0xA0], xmm10
00007ed4111d4117  vmovaps [rsp+0xB0], xmm11
00007ed4111d4120  vmovaps [rsp+0xC0], xmm12
00007ed4111d4129  vmovaps [rsp+0xD0], xmm14
00007ed4111d4132  vmovaps [rsp+0xE0], xmm15
00007ed4111d413b  sub rsp, 0x40
00007ed4111d413f  lea rdi, [rsp]
00007ed4111d4143  lea rsi, [rsp+0x10]
00007ed4111d4148  lea rdx, [rsp+0x20]
00007ed4111d414d  lea rcx, [rsp+0x30]
00007ed4111d4152  mov r8d, 0x00
00007ed4111d4158  lea r9, [r15+0x3A8]
00007ed4111d415f  movaps [rdi], xmm13
00007ed4111d4163  movaps [rsi], xmm15
00007ed4111d4167  movaps [rdx], xmm10
00007ed4111d416b  movaps [rcx], xmm1
00007ed4111d416e  mov rax, 0x5CA8E4A55A50
00007ed4111d4178  call rax
00007ed4111d417a  movaps xmm13, [rsp]
00007ed4111d417f  add rsp, 0x40
00007ed4111d4183  vmovaps xmm0, [rsp]
00007ed4111d4188  vmovaps xmm1, [rsp+0x10]
00007ed4111d418e  vmovaps xmm2, [rsp+0x20]
00007ed4111d4194  vmovaps xmm3, [rsp+0x30]
00007ed4111d419a  vmovaps xmm4, [rsp+0x40]
00007ed4111d41a0  vmovaps xmm5, [rsp+0x50]
00007ed4111d41a6  vmovaps xmm6, [rsp+0x60]
00007ed4111d41ac  vmovaps xmm7, [rsp+0x70]
00007ed4111d41b2  vmovaps xmm8, [rsp+0x80]
00007ed4111d41bb  vmovaps xmm9, [rsp+0x90]
00007ed4111d41c4  vmovaps xmm10, [rsp+0xA0]
00007ed4111d41cd  vmovaps xmm11, [rsp+0xB0]
00007ed4111d41d6  vmovaps xmm12, [rsp+0xC0]
00007ed4111d41df  vmovaps xmm14, [rsp+0xD0]
00007ed4111d41e8  vmovaps xmm15, [rsp+0xE0]
00007ed4111d41f1  add rsp, 0xF0
00007ed4111d41f8  pop r11
00007ed4111d41fa  pop r10
00007ed4111d41fc  pop r9
00007ed4111d41fe  pop r8
00007ed4111d4200  pop rsi
00007ed4111d4201  pop rdi
00007ed4111d4202  pop rdx
00007ed4111d4203  pop rcx
00007ed4111d4204  pop rax
00007ed4111d4205  add rsp, 0x08
00007ed4111d4209  jmp 0x00007ED4111D2D26
00007ed4111d420e  sub rsp, 0x08
00007ed4111d4212  push rax
00007ed4111d4213  push rcx
00007ed4111d4214  push rdx
00007ed4111d4215  push rdi
00007ed4111d4216  push rsi
00007ed4111d4217  push r8
00007ed4111d4219  push r9
00007ed4111d421b  push r10
00007ed4111d421d  push r11
00007ed4111d421f  sub rsp, 0xF0
00007ed4111d4226  vmovaps [rsp], xmm0
00007ed4111d422b  vmovaps [rsp+0x10], xmm1
00007ed4111d4231  vmovaps [rsp+0x20], xmm2
00007ed4111d4237  vmovaps [rsp+0x30], xmm3
00007ed4111d423d  vmovaps [rsp+0x40], xmm4
00007ed4111d4243  vmovaps [rsp+0x50], xmm5
00007ed4111d4249  vmovaps [rsp+0x60], xmm6
00007ed4111d424f  vmovaps [rsp+0x70], xmm7
00007ed4111d4255  vmovaps [rsp+0x80], xmm8
00007ed4111d425e  vmovaps [rsp+0x90], xmm9
00007ed4111d4267  vmovaps [rsp+0xA0], xmm11
00007ed4111d4270  vmovaps [rsp+0xB0], xmm12
00007ed4111d4279  vmovaps [rsp+0xC0], xmm13
00007ed4111d4282  vmovaps [rsp+0xD0], xmm14
00007ed4111d428b  vmovaps [rsp+0xE0], xmm15
00007ed4111d4294  sub rsp, 0x40
00007ed4111d4298  lea rdi, [rsp]
00007ed4111d429c  lea rsi, [rsp+0x10]
00007ed4111d42a1  lea rdx, [rsp+0x20]
00007ed4111d42a6  lea rcx, [rsp+0x30]
00007ed4111d42ab  mov r8d, 0x00
00007ed4111d42b1  lea r9, [r15+0x3A8]
00007ed4111d42b8  movaps [rdi], xmm10
00007ed4111d42bc  movaps [rsi], xmm15
00007ed4111d42c0  movaps [rdx], xmm11
00007ed4111d42c4  movaps [rcx], xmm1
00007ed4111d42c7  mov rax, 0x5CA8E4A55A50
00007ed4111d42d1  call rax
00007ed4111d42d3  movaps xmm10, [rsp]
00007ed4111d42d8  add rsp, 0x40
00007ed4111d42dc  vmovaps xmm0, [rsp]
00007ed4111d42e1  vmovaps xmm1, [rsp+0x10]
00007ed4111d42e7  vmovaps xmm2, [rsp+0x20]
00007ed4111d42ed  vmovaps xmm3, [rsp+0x30]
00007ed4111d42f3  vmovaps xmm4, [rsp+0x40]
00007ed4111d42f9  vmovaps xmm5, [rsp+0x50]
00007ed4111d42ff  vmovaps xmm6, [rsp+0x60]
00007ed4111d4305  vmovaps xmm7, [rsp+0x70]
00007ed4111d430b  vmovaps xmm8, [rsp+0x80]
00007ed4111d4314  vmovaps xmm9, [rsp+0x90]
00007ed4111d431d  vmovaps xmm11, [rsp+0xA0]
00007ed4111d4326  vmovaps xmm12, [rsp+0xB0]
00007ed4111d432f  vmovaps xmm13, [rsp+0xC0]
00007ed4111d4338  vmovaps xmm14, [rsp+0xD0]
00007ed4111d4341  vmovaps xmm15, [rsp+0xE0]
00007ed4111d434a  add rsp, 0xF0
00007ed4111d4351  pop r11
00007ed4111d4353  pop r10
00007ed4111d4355  pop r9
00007ed4111d4357  pop r8
00007ed4111d4359  pop rsi
00007ed4111d435a  pop rdi
00007ed4111d435b  pop rdx
00007ed4111d435c  pop rcx
00007ed4111d435d  pop rax
00007ed4111d435e  add rsp, 0x08
00007ed4111d4362  jmp 0x00007ED4111D2D55
00007ed4111d4367  sub rsp, 0x08
00007ed4111d436b  push rax
00007ed4111d436c  push rcx
00007ed4111d436d  push rdx
00007ed4111d436e  push rdi
00007ed4111d436f  push rsi
00007ed4111d4370  push r8
00007ed4111d4372  push r9
00007ed4111d4374  push r10
00007ed4111d4376  push r11
00007ed4111d4378  sub rsp, 0xF0
00007ed4111d437f  vmovaps [rsp], xmm0
00007ed4111d4384  vmovaps [rsp+0x10], xmm1
00007ed4111d438a  vmovaps [rsp+0x20], xmm2
00007ed4111d4390  vmovaps [rsp+0x30], xmm3
00007ed4111d4396  vmovaps [rsp+0x40], xmm4
00007ed4111d439c  vmovaps [rsp+0x50], xmm5
00007ed4111d43a2  vmovaps [rsp+0x60], xmm6
00007ed4111d43a8  vmovaps [rsp+0x70], xmm7
00007ed4111d43ae  vmovaps [rsp+0x80], xmm8
00007ed4111d43b7  vmovaps [rsp+0x90], xmm9
00007ed4111d43c0  vmovaps [rsp+0xA0], xmm10
00007ed4111d43c9  vmovaps [rsp+0xB0], xmm11
00007ed4111d43d2  vmovaps [rsp+0xC0], xmm12
00007ed4111d43db  vmovaps [rsp+0xD0], xmm13
00007ed4111d43e4  vmovaps [rsp+0xE0], xmm14
00007ed4111d43ed  sub rsp, 0x40
00007ed4111d43f1  lea rdi, [rsp]
00007ed4111d43f5  lea rsi, [rsp+0x10]
00007ed4111d43fa  lea rdx, [rsp+0x20]
00007ed4111d43ff  lea rcx, [rsp+0x30]
00007ed4111d4404  mov r8d, 0x00
00007ed4111d440a  lea r9, [r15+0x3A8]
00007ed4111d4411  movaps [rdi], xmm15
00007ed4111d4415  movaps [rsi], xmm12
00007ed4111d4419  movaps [rdx], xmm5
00007ed4111d441c  movaps [rcx], xmm1
00007ed4111d441f  mov rax, 0x5CA8E4A55A50
00007ed4111d4429  call rax
00007ed4111d442b  movaps xmm15, [rsp]
00007ed4111d4430  add rsp, 0x40
00007ed4111d4434  vmovaps xmm0, [rsp]
00007ed4111d4439  vmovaps xmm1, [rsp+0x10]
00007ed4111d443f  vmovaps xmm2, [rsp+0x20]
00007ed4111d4445  vmovaps xmm3, [rsp+0x30]
00007ed4111d444b  vmovaps xmm4, [rsp+0x40]
00007ed4111d4451  vmovaps xmm5, [rsp+0x50]
00007ed4111d4457  vmovaps xmm6, [rsp+0x60]
00007ed4111d445d  vmovaps xmm7, [rsp+0x70]
00007ed4111d4463  vmovaps xmm8, [rsp+0x80]
00007ed4111d446c  vmovaps xmm9, [rsp+0x90]
00007ed4111d4475  vmovaps xmm10, [rsp+0xA0]
00007ed4111d447e  vmovaps xmm11, [rsp+0xB0]
00007ed4111d4487  vmovaps xmm12, [rsp+0xC0]
00007ed4111d4490  vmovaps xmm13, [rsp+0xD0]
00007ed4111d4499  vmovaps xmm14, [rsp+0xE0]
00007ed4111d44a2  add rsp, 0xF0
00007ed4111d44a9  pop r11
00007ed4111d44ab  pop r10
00007ed4111d44ad  pop r9
00007ed4111d44af  pop r8
00007ed4111d44b1  pop rsi
00007ed4111d44b2  pop rdi
00007ed4111d44b3  pop rdx
00007ed4111d44b4  pop rcx
00007ed4111d44b5  pop rax
00007ed4111d44b6  add rsp, 0x08
00007ed4111d44ba  jmp 0x00007ED4111D2D7E
00007ed4111d44bf  sub rsp, 0x08
00007ed4111d44c3  push rax
00007ed4111d44c4  push rcx
00007ed4111d44c5  push rdx
00007ed4111d44c6  push rdi
00007ed4111d44c7  push rsi
00007ed4111d44c8  push r8
00007ed4111d44ca  push r9
00007ed4111d44cc  push r10
00007ed4111d44ce  push r11
00007ed4111d44d0  sub rsp, 0xF0
00007ed4111d44d7  vmovaps [rsp], xmm0
00007ed4111d44dc  vmovaps [rsp+0x10], xmm1
00007ed4111d44e2  vmovaps [rsp+0x20], xmm2
00007ed4111d44e8  vmovaps [rsp+0x30], xmm3
00007ed4111d44ee  vmovaps [rsp+0x40], xmm4
00007ed4111d44f4  vmovaps [rsp+0x50], xmm6
00007ed4111d44fa  vmovaps [rsp+0x60], xmm7
00007ed4111d4500  vmovaps [rsp+0x70], xmm8
00007ed4111d4506  vmovaps [rsp+0x80], xmm9
00007ed4111d450f  vmovaps [rsp+0x90], xmm10
00007ed4111d4518  vmovaps [rsp+0xA0], xmm11
00007ed4111d4521  vmovaps [rsp+0xB0], xmm12
00007ed4111d452a  vmovaps [rsp+0xC0], xmm13
00007ed4111d4533  vmovaps [rsp+0xD0], xmm14
00007ed4111d453c  vmovaps [rsp+0xE0], xmm15
00007ed4111d4545  sub rsp, 0x40
00007ed4111d4549  lea rdi, [rsp]
00007ed4111d454d  lea rsi, [rsp+0x10]
00007ed4111d4552  lea rdx, [rsp+0x20]
00007ed4111d4557  lea rcx, [rsp+0x30]
00007ed4111d455c  mov r8d, 0x00
00007ed4111d4562  lea r9, [r15+0x3A8]
00007ed4111d4569  movaps [rdi], xmm5
00007ed4111d456c  movaps [rsi], xmm13
00007ed4111d4570  movaps [rdx], xmm11
00007ed4111d4574  movaps [rcx], xmm12
00007ed4111d4578  mov rax, 0x5CA8E4A55A50
00007ed4111d4582  call rax
00007ed4111d4584  movaps xmm5, [rsp]
00007ed4111d4588  add rsp, 0x40
00007ed4111d458c  vmovaps xmm0, [rsp]
00007ed4111d4591  vmovaps xmm1, [rsp+0x10]
00007ed4111d4597  vmovaps xmm2, [rsp+0x20]
00007ed4111d459d  vmovaps xmm3, [rsp+0x30]
00007ed4111d45a3  vmovaps xmm4, [rsp+0x40]
00007ed4111d45a9  vmovaps xmm6, [rsp+0x50]
00007ed4111d45af  vmovaps xmm7, [rsp+0x60]
00007ed4111d45b5  vmovaps xmm8, [rsp+0x70]
00007ed4111d45bb  vmovaps xmm9, [rsp+0x80]
00007ed4111d45c4  vmovaps xmm10, [rsp+0x90]
00007ed4111d45cd  vmovaps xmm11, [rsp+0xA0]
00007ed4111d45d6  vmovaps xmm12, [rsp+0xB0]
00007ed4111d45df  vmovaps xmm13, [rsp+0xC0]
00007ed4111d45e8  vmovaps xmm14, [rsp+0xD0]
00007ed4111d45f1  vmovaps xmm15, [rsp+0xE0]
00007ed4111d45fa  add rsp, 0xF0
00007ed4111d4601  pop r11
00007ed4111d4603  pop r10
00007ed4111d4605  pop r9
00007ed4111d4607  pop r8
00007ed4111d4609  pop rsi
00007ed4111d460a  pop rdi
00007ed4111d460b  pop rdx
00007ed4111d460c  pop rcx
00007ed4111d460d  pop rax
00007ed4111d460e  add rsp, 0x08
00007ed4111d4612  jmp 0x00007ED4111D2DDD
00007ed4111d4617  sub rsp, 0x08
00007ed4111d461b  push rax
00007ed4111d461c  push rcx
00007ed4111d461d  push rdx
00007ed4111d461e  push rdi
00007ed4111d461f  push rsi
00007ed4111d4620  push r8
00007ed4111d4622  push r9
00007ed4111d4624  push r10
00007ed4111d4626  push r11
00007ed4111d4628  sub rsp, 0xF0
00007ed4111d462f  vmovaps [rsp], xmm0
00007ed4111d4634  vmovaps [rsp+0x10], xmm1
00007ed4111d463a  vmovaps [rsp+0x20], xmm2
00007ed4111d4640  vmovaps [rsp+0x30], xmm3
00007ed4111d4646  vmovaps [rsp+0x40], xmm4
00007ed4111d464c  vmovaps [rsp+0x50], xmm5
00007ed4111d4652  vmovaps [rsp+0x60], xmm6
00007ed4111d4658  vmovaps [rsp+0x70], xmm7
00007ed4111d465e  vmovaps [rsp+0x80], xmm8
00007ed4111d4667  vmovaps [rsp+0x90], xmm9
00007ed4111d4670  vmovaps [rsp+0xA0], xmm10
00007ed4111d4679  vmovaps [rsp+0xB0], xmm11
00007ed4111d4682  vmovaps [rsp+0xC0], xmm13
00007ed4111d468b  vmovaps [rsp+0xD0], xmm14
00007ed4111d4694  vmovaps [rsp+0xE0], xmm15
00007ed4111d469d  sub rsp, 0x40
00007ed4111d46a1  lea rdi, [rsp]
00007ed4111d46a5  lea rsi, [rsp+0x10]
00007ed4111d46aa  lea rdx, [rsp+0x20]
00007ed4111d46af  lea rcx, [rsp+0x30]
00007ed4111d46b4  mov r8d, 0x00
00007ed4111d46ba  lea r9, [r15+0x3A8]
00007ed4111d46c1  movaps [rdi], xmm12
00007ed4111d46c5  movaps [rsi], xmm14
00007ed4111d46c9  movaps [rdx], xmm9
00007ed4111d46cd  movaps [rcx], xmm13
00007ed4111d46d1  mov rax, 0x5CA8E4A55A50
00007ed4111d46db  call rax
00007ed4111d46dd  movaps xmm12, [rsp]
00007ed4111d46e2  add rsp, 0x40
00007ed4111d46e6  vmovaps xmm0, [rsp]
00007ed4111d46eb  vmovaps xmm1, [rsp+0x10]
00007ed4111d46f1  vmovaps xmm2, [rsp+0x20]
00007ed4111d46f7  vmovaps xmm3, [rsp+0x30]
00007ed4111d46fd  vmovaps xmm4, [rsp+0x40]
00007ed4111d4703  vmovaps xmm5, [rsp+0x50]
00007ed4111d4709  vmovaps xmm6, [rsp+0x60]
00007ed4111d470f  vmovaps xmm7, [rsp+0x70]
00007ed4111d4715  vmovaps xmm8, [rsp+0x80]
00007ed4111d471e  vmovaps xmm9, [rsp+0x90]
00007ed4111d4727  vmovaps xmm10, [rsp+0xA0]
00007ed4111d4730  vmovaps xmm11, [rsp+0xB0]
00007ed4111d4739  vmovaps xmm13, [rsp+0xC0]
00007ed4111d4742  vmovaps xmm14, [rsp+0xD0]
00007ed4111d474b  vmovaps xmm15, [rsp+0xE0]
00007ed4111d4754  add rsp, 0xF0
00007ed4111d475b  pop r11
00007ed4111d475d  pop r10
00007ed4111d475f  pop r9
00007ed4111d4761  pop r8
00007ed4111d4763  pop rsi
00007ed4111d4764  pop rdi
00007ed4111d4765  pop rdx
00007ed4111d4766  pop rcx
00007ed4111d4767  pop rax
00007ed4111d4768  add rsp, 0x08
00007ed4111d476c  jmp 0x00007ED4111D2E06
00007ed4111d4771  call 0x00007ED41100D4E0
00007ed4111d4776  jmp 0x00007ED4111D2E13
00007ed4111d477b  sub rsp, 0x08
00007ed4111d477f  push rax
00007ed4111d4780  push rcx
00007ed4111d4781  push rdx
00007ed4111d4782  push rdi
00007ed4111d4783  push rsi
00007ed4111d4784  push r8
00007ed4111d4786  push r9
00007ed4111d4788  push r10
00007ed4111d478a  push r11
00007ed4111d478c  sub rsp, 0xF0
00007ed4111d4793  vmovaps [rsp], xmm0
00007ed4111d4798  vmovaps [rsp+0x10], xmm1
00007ed4111d479e  vmovaps [rsp+0x20], xmm2
00007ed4111d47a4  vmovaps [rsp+0x30], xmm3
00007ed4111d47aa  vmovaps [rsp+0x40], xmm4
00007ed4111d47b0  vmovaps [rsp+0x50], xmm5
00007ed4111d47b6  vmovaps [rsp+0x60], xmm6
00007ed4111d47bc  vmovaps [rsp+0x70], xmm7
00007ed4111d47c2  vmovaps [rsp+0x80], xmm8
00007ed4111d47cb  vmovaps [rsp+0x90], xmm9
00007ed4111d47d4  vmovaps [rsp+0xA0], xmm10
00007ed4111d47dd  vmovaps [rsp+0xB0], xmm12
00007ed4111d47e6  vmovaps [rsp+0xC0], xmm13
00007ed4111d47ef  vmovaps [rsp+0xD0], xmm14
00007ed4111d47f8  vmovaps [rsp+0xE0], xmm15
00007ed4111d4801  sub rsp, 0x40
00007ed4111d4805  lea rdi, [rsp]
00007ed4111d4809  lea rsi, [rsp+0x10]
00007ed4111d480e  lea rdx, [rsp+0x20]
00007ed4111d4813  lea rcx, [rsp+0x30]
00007ed4111d4818  mov r8d, 0x00
00007ed4111d481e  lea r9, [r15+0x3A8]
00007ed4111d4825  movaps [rdi], xmm11
00007ed4111d4829  movaps [rsi], xmm10
00007ed4111d482d  movaps [rdx], xmm8
00007ed4111d4831  movaps [rcx], xmm13
00007ed4111d4835  mov rax, 0x5CA8E4A55A50
00007ed4111d483f  call rax
00007ed4111d4841  movaps xmm11, [rsp]
00007ed4111d4846  add rsp, 0x40
00007ed4111d484a  vmovaps xmm0, [rsp]
00007ed4111d484f  vmovaps xmm1, [rsp+0x10]
00007ed4111d4855  vmovaps xmm2, [rsp+0x20]
00007ed4111d485b  vmovaps xmm3, [rsp+0x30]
00007ed4111d4861  vmovaps xmm4, [rsp+0x40]
00007ed4111d4867  vmovaps xmm5, [rsp+0x50]
00007ed4111d486d  vmovaps xmm6, [rsp+0x60]
00007ed4111d4873  vmovaps xmm7, [rsp+0x70]
00007ed4111d4879  vmovaps xmm8, [rsp+0x80]
00007ed4111d4882  vmovaps xmm9, [rsp+0x90]
00007ed4111d488b  vmovaps xmm10, [rsp+0xA0]
00007ed4111d4894  vmovaps xmm12, [rsp+0xB0]
00007ed4111d489d  vmovaps xmm13, [rsp+0xC0]
00007ed4111d48a6  vmovaps xmm14, [rsp+0xD0]
00007ed4111d48af  vmovaps xmm15, [rsp+0xE0]
00007ed4111d48b8  add rsp, 0xF0
00007ed4111d48bf  pop r11
00007ed4111d48c1  pop r10
00007ed4111d48c3  pop r9
00007ed4111d48c5  pop r8
00007ed4111d48c7  pop rsi
00007ed4111d48c8  pop rdi
00007ed4111d48c9  pop rdx
00007ed4111d48ca  pop rcx
00007ed4111d48cb  pop rax
00007ed4111d48cc  add rsp, 0x08
00007ed4111d48d0  jmp 0x00007ED4111D2E44
00007ed4111d48d5  sub rsp, 0x08
00007ed4111d48d9  push rax
00007ed4111d48da  push rcx
00007ed4111d48db  push rdx
00007ed4111d48dc  push rdi
00007ed4111d48dd  push rsi
00007ed4111d48de  push r8
00007ed4111d48e0  push r9
00007ed4111d48e2  push r10
00007ed4111d48e4  push r11
00007ed4111d48e6  sub rsp, 0xF0
00007ed4111d48ed  vmovaps [rsp], xmm0
00007ed4111d48f2  vmovaps [rsp+0x10], xmm1
00007ed4111d48f8  vmovaps [rsp+0x20], xmm2
00007ed4111d48fe  vmovaps [rsp+0x30], xmm3
00007ed4111d4904  vmovaps [rsp+0x40], xmm4
00007ed4111d490a  vmovaps [rsp+0x50], xmm5
00007ed4111d4910  vmovaps [rsp+0x60], xmm6
00007ed4111d4916  vmovaps [rsp+0x70], xmm7
00007ed4111d491c  vmovaps [rsp+0x80], xmm8
00007ed4111d4925  vmovaps [rsp+0x90], xmm9
00007ed4111d492e  vmovaps [rsp+0xA0], xmm11
00007ed4111d4937  vmovaps [rsp+0xB0], xmm12
00007ed4111d4940  vmovaps [rsp+0xC0], xmm13
00007ed4111d4949  vmovaps [rsp+0xD0], xmm14
00007ed4111d4952  vmovaps [rsp+0xE0], xmm15
00007ed4111d495b  sub rsp, 0x40
00007ed4111d495f  lea rdi, [rsp]
00007ed4111d4963  lea rsi, [rsp+0x10]
00007ed4111d4968  lea rdx, [rsp+0x20]
00007ed4111d496d  lea rcx, [rsp+0x30]
00007ed4111d4972  mov r8d, 0x00
00007ed4111d4978  lea r9, [r15+0x3A8]
00007ed4111d497f  movaps [rdi], xmm10
00007ed4111d4983  movaps [rsi], xmm15
00007ed4111d4987  movaps [rdx], xmm1
00007ed4111d498a  movaps [rcx], xmm13
00007ed4111d498e  mov rax, 0x5CA8E4A55A50
00007ed4111d4998  call rax
00007ed4111d499a  movaps xmm10, [rsp]
00007ed4111d499f  add rsp, 0x40
00007ed4111d49a3  vmovaps xmm0, [rsp]
00007ed4111d49a8  vmovaps xmm1, [rsp+0x10]
00007ed4111d49ae  vmovaps xmm2, [rsp+0x20]
00007ed4111d49b4  vmovaps xmm3, [rsp+0x30]
00007ed4111d49ba  vmovaps xmm4, [rsp+0x40]
00007ed4111d49c0  vmovaps xmm5, [rsp+0x50]
00007ed4111d49c6  vmovaps xmm6, [rsp+0x60]
00007ed4111d49cc  vmovaps xmm7, [rsp+0x70]
00007ed4111d49d2  vmovaps xmm8, [rsp+0x80]
00007ed4111d49db  vmovaps xmm9, [rsp+0x90]
00007ed4111d49e4  vmovaps xmm11, [rsp+0xA0]
00007ed4111d49ed  vmovaps xmm12, [rsp+0xB0]
00007ed4111d49f6  vmovaps xmm13, [rsp+0xC0]
00007ed4111d49ff  vmovaps xmm14, [rsp+0xD0]
00007ed4111d4a08  vmovaps xmm15, [rsp+0xE0]
00007ed4111d4a11  add rsp, 0xF0
00007ed4111d4a18  pop r11
00007ed4111d4a1a  pop r10
00007ed4111d4a1c  pop r9
00007ed4111d4a1e  pop r8
00007ed4111d4a20  pop rsi
00007ed4111d4a21  pop rdi
00007ed4111d4a22  pop rdx
00007ed4111d4a23  pop rcx
00007ed4111d4a24  pop rax
00007ed4111d4a25  add rsp, 0x08
00007ed4111d4a29  jmp 0x00007ED4111D2E6D
00007ed4111d4a2e  call 0x00007ED410FFF430
00007ed4111d4a33  jmp 0x00007ED4111D2E8F
00007ed4111d4a38  call 0x00007ED41100E760
00007ed4111d4a3d  jmp 0x00007ED4111D2E99
00007ed4111d4a42  sub rsp, 0x08
00007ed4111d4a46  push rax
00007ed4111d4a47  push rcx
00007ed4111d4a48  push rdx
00007ed4111d4a49  push rdi
00007ed4111d4a4a  push rsi
00007ed4111d4a4b  push r8
00007ed4111d4a4d  push r9
00007ed4111d4a4f  push r10
00007ed4111d4a51  push r11
00007ed4111d4a53  sub rsp, 0xF0
00007ed4111d4a5a  vmovaps [rsp], xmm0
00007ed4111d4a5f  vmovaps [rsp+0x10], xmm1
00007ed4111d4a65  vmovaps [rsp+0x20], xmm2
00007ed4111d4a6b  vmovaps [rsp+0x30], xmm3
00007ed4111d4a71  vmovaps [rsp+0x40], xmm4
00007ed4111d4a77  vmovaps [rsp+0x50], xmm5
00007ed4111d4a7d  vmovaps [rsp+0x60], xmm6
00007ed4111d4a83  vmovaps [rsp+0x70], xmm7
00007ed4111d4a89  vmovaps [rsp+0x80], xmm9
00007ed4111d4a92  vmovaps [rsp+0x90], xmm10
00007ed4111d4a9b  vmovaps [rsp+0xA0], xmm11
00007ed4111d4aa4  vmovaps [rsp+0xB0], xmm12
00007ed4111d4aad  vmovaps [rsp+0xC0], xmm13
00007ed4111d4ab6  vmovaps [rsp+0xD0], xmm14
00007ed4111d4abf  vmovaps [rsp+0xE0], xmm15
00007ed4111d4ac8  sub rsp, 0x40
00007ed4111d4acc  lea rdi, [rsp]
00007ed4111d4ad0  lea rsi, [rsp+0x10]
00007ed4111d4ad5  lea rdx, [rsp+0x20]
00007ed4111d4ada  lea rcx, [rsp+0x30]
00007ed4111d4adf  mov r8d, 0x00
00007ed4111d4ae5  lea r9, [r15+0x3A8]
00007ed4111d4aec  movaps [rdi], xmm8
00007ed4111d4af0  movaps [rsi], xmm5
00007ed4111d4af3  movaps [rdx], xmm9
00007ed4111d4af7  movaps [rcx], xmm13
00007ed4111d4afb  mov rax, 0x5CA8E4A55A50
00007ed4111d4b05  call rax
00007ed4111d4b07  movaps xmm8, [rsp]
00007ed4111d4b0c  add rsp, 0x40
00007ed4111d4b10  vmovaps xmm0, [rsp]
00007ed4111d4b15  vmovaps xmm1, [rsp+0x10]
00007ed4111d4b1b  vmovaps xmm2, [rsp+0x20]
00007ed4111d4b21  vmovaps xmm3, [rsp+0x30]
00007ed4111d4b27  vmovaps xmm4, [rsp+0x40]
00007ed4111d4b2d  vmovaps xmm5, [rsp+0x50]
00007ed4111d4b33  vmovaps xmm6, [rsp+0x60]
00007ed4111d4b39  vmovaps xmm7, [rsp+0x70]
00007ed4111d4b3f  vmovaps xmm9, [rsp+0x80]
00007ed4111d4b48  vmovaps xmm10, [rsp+0x90]
00007ed4111d4b51  vmovaps xmm11, [rsp+0xA0]
00007ed4111d4b5a  vmovaps xmm12, [rsp+0xB0]
00007ed4111d4b63  vmovaps xmm13, [rsp+0xC0]
00007ed4111d4b6c  vmovaps xmm14, [rsp+0xD0]
00007ed4111d4b75  vmovaps xmm15, [rsp+0xE0]
00007ed4111d4b7e  add rsp, 0xF0
00007ed4111d4b85  pop r11
00007ed4111d4b87  pop r10
00007ed4111d4b89  pop r9
00007ed4111d4b8b  pop r8
00007ed4111d4b8d  pop rsi
00007ed4111d4b8e  pop rdi
00007ed4111d4b8f  pop rdx
00007ed4111d4b90  pop rcx
00007ed4111d4b91  pop rax
00007ed4111d4b92  add rsp, 0x08
00007ed4111d4b96  jmp 0x00007ED4111D2ED8
00007ed4111d4b9b  sub rsp, 0x08
00007ed4111d4b9f  push rax
00007ed4111d4ba0  push rcx
00007ed4111d4ba1  push rdx
00007ed4111d4ba2  push rdi
00007ed4111d4ba3  push rsi
00007ed4111d4ba4  push r8
00007ed4111d4ba6  push r9
00007ed4111d4ba8  push r10
00007ed4111d4baa  push r11
00007ed4111d4bac  sub rsp, 0xF0
00007ed4111d4bb3  vmovaps [rsp], xmm0
00007ed4111d4bb8  vmovaps [rsp+0x10], xmm1
00007ed4111d4bbe  vmovaps [rsp+0x20], xmm2
00007ed4111d4bc4  vmovaps [rsp+0x30], xmm3
00007ed4111d4bca  vmovaps [rsp+0x40], xmm4
00007ed4111d4bd0  vmovaps [rsp+0x50], xmm5
00007ed4111d4bd6  vmovaps [rsp+0x60], xmm6
00007ed4111d4bdc  vmovaps [rsp+0x70], xmm7
00007ed4111d4be2  vmovaps [rsp+0x80], xmm8
00007ed4111d4beb  vmovaps [rsp+0x90], xmm10
00007ed4111d4bf4  vmovaps [rsp+0xA0], xmm11
00007ed4111d4bfd  vmovaps [rsp+0xB0], xmm12
00007ed4111d4c06  vmovaps [rsp+0xC0], xmm13
00007ed4111d4c0f  vmovaps [rsp+0xD0], xmm14
00007ed4111d4c18  vmovaps [rsp+0xE0], xmm15
00007ed4111d4c21  sub rsp, 0x40
00007ed4111d4c25  lea rdi, [rsp]
00007ed4111d4c29  lea rsi, [rsp+0x10]
00007ed4111d4c2e  lea rdx, [rsp+0x20]
00007ed4111d4c33  lea rcx, [rsp+0x30]
00007ed4111d4c38  mov r8d, 0x00
00007ed4111d4c3e  lea r9, [r15+0x3A8]
00007ed4111d4c45  movaps [rdi], xmm9
00007ed4111d4c49  movaps [rsi], xmm12
00007ed4111d4c4d  movaps [rdx], xmm7
00007ed4111d4c50  movaps [rcx], xmm13
00007ed4111d4c54  mov rax, 0x5CA8E4A55A50
00007ed4111d4c5e  call rax
00007ed4111d4c60  movaps xmm9, [rsp]
00007ed4111d4c65  add rsp, 0x40
00007ed4111d4c69  vmovaps xmm0, [rsp]
00007ed4111d4c6e  vmovaps xmm1, [rsp+0x10]
00007ed4111d4c74  vmovaps xmm2, [rsp+0x20]
00007ed4111d4c7a  vmovaps xmm3, [rsp+0x30]
00007ed4111d4c80  vmovaps xmm4, [rsp+0x40]
00007ed4111d4c86  vmovaps xmm5, [rsp+0x50]
00007ed4111d4c8c  vmovaps xmm6, [rsp+0x60]
00007ed4111d4c92  vmovaps xmm7, [rsp+0x70]
00007ed4111d4c98  vmovaps xmm8, [rsp+0x80]
00007ed4111d4ca1  vmovaps xmm10, [rsp+0x90]
00007ed4111d4caa  vmovaps xmm11, [rsp+0xA0]
00007ed4111d4cb3  vmovaps xmm12, [rsp+0xB0]
00007ed4111d4cbc  vmovaps xmm13, [rsp+0xC0]
00007ed4111d4cc5  vmovaps xmm14, [rsp+0xD0]
00007ed4111d4cce  vmovaps xmm15, [rsp+0xE0]
00007ed4111d4cd7  add rsp, 0xF0
00007ed4111d4cde  pop r11
00007ed4111d4ce0  pop r10
00007ed4111d4ce2  pop r9
00007ed4111d4ce4  pop r8
00007ed4111d4ce6  pop rsi
00007ed4111d4ce7  pop rdi
00007ed4111d4ce8  pop rdx
00007ed4111d4ce9  pop rcx
00007ed4111d4cea  pop rax
00007ed4111d4ceb  add rsp, 0x08
00007ed4111d4cef  jmp 0x00007ED4111D2F01
00007ed4111d4cf4  sub rsp, 0x08
00007ed4111d4cf8  push rax
00007ed4111d4cf9  push rcx
00007ed4111d4cfa  push rdx
00007ed4111d4cfb  push rdi
00007ed4111d4cfc  push rsi
00007ed4111d4cfd  push r8
00007ed4111d4cff  push r9
00007ed4111d4d01  push r10
00007ed4111d4d03  push r11
00007ed4111d4d05  sub rsp, 0xF0
00007ed4111d4d0c  vmovaps [rsp], xmm0
00007ed4111d4d11  vmovaps [rsp+0x10], xmm1
00007ed4111d4d17  vmovaps [rsp+0x20], xmm2
00007ed4111d4d1d  vmovaps [rsp+0x30], xmm3
00007ed4111d4d23  vmovaps [rsp+0x40], xmm4
00007ed4111d4d29  vmovaps [rsp+0x50], xmm5
00007ed4111d4d2f  vmovaps [rsp+0x60], xmm6
00007ed4111d4d35  vmovaps [rsp+0x70], xmm7
00007ed4111d4d3b  vmovaps [rsp+0x80], xmm8
00007ed4111d4d44  vmovaps [rsp+0x90], xmm9
00007ed4111d4d4d  vmovaps [rsp+0xA0], xmm10
00007ed4111d4d56  vmovaps [rsp+0xB0], xmm11
00007ed4111d4d5f  vmovaps [rsp+0xC0], xmm13
00007ed4111d4d68  vmovaps [rsp+0xD0], xmm14
00007ed4111d4d71  vmovaps [rsp+0xE0], xmm15
00007ed4111d4d7a  sub rsp, 0x40
00007ed4111d4d7e  lea rdi, [rsp]
00007ed4111d4d82  lea rsi, [rsp+0x10]
00007ed4111d4d87  lea rdx, [rsp+0x20]
00007ed4111d4d8c  lea rcx, [rsp+0x30]
00007ed4111d4d91  mov r8d, 0x00
00007ed4111d4d97  lea r9, [r15+0x3A8]
00007ed4111d4d9e  movaps [rdi], xmm12
00007ed4111d4da2  movaps [rsi], xmm11
00007ed4111d4da6  movaps [rdx], xmm6
00007ed4111d4da9  movaps [rcx], xmm13
00007ed4111d4dad  mov rax, 0x5CA8E4A55A50
00007ed4111d4db7  call rax
00007ed4111d4db9  movaps xmm12, [rsp]
00007ed4111d4dbe  add rsp, 0x40
00007ed4111d4dc2  vmovaps xmm0, [rsp]
00007ed4111d4dc7  vmovaps xmm1, [rsp+0x10]
00007ed4111d4dcd  vmovaps xmm2, [rsp+0x20]
00007ed4111d4dd3  vmovaps xmm3, [rsp+0x30]
00007ed4111d4dd9  vmovaps xmm4, [rsp+0x40]
00007ed4111d4ddf  vmovaps xmm5, [rsp+0x50]
00007ed4111d4de5  vmovaps xmm6, [rsp+0x60]
00007ed4111d4deb  vmovaps xmm7, [rsp+0x70]
00007ed4111d4df1  vmovaps xmm8, [rsp+0x80]
00007ed4111d4dfa  vmovaps xmm9, [rsp+0x90]
00007ed4111d4e03  vmovaps xmm10, [rsp+0xA0]
00007ed4111d4e0c  vmovaps xmm11, [rsp+0xB0]
00007ed4111d4e15  vmovaps xmm13, [rsp+0xC0]
00007ed4111d4e1e  vmovaps xmm14, [rsp+0xD0]
00007ed4111d4e27  vmovaps xmm15, [rsp+0xE0]
00007ed4111d4e30  add rsp, 0xF0
00007ed4111d4e37  pop r11
00007ed4111d4e39  pop r10
00007ed4111d4e3b  pop r9
00007ed4111d4e3d  pop r8
00007ed4111d4e3f  pop rsi
00007ed4111d4e40  pop rdi
00007ed4111d4e41  pop rdx
00007ed4111d4e42  pop rcx
00007ed4111d4e43  pop rax
00007ed4111d4e44  add rsp, 0x08
00007ed4111d4e48  jmp 0x00007ED4111D2F2A
00007ed4111d4e4d  sub rsp, 0x08
00007ed4111d4e51  push rax
00007ed4111d4e52  push rcx
00007ed4111d4e53  push rdx
00007ed4111d4e54  push rdi
00007ed4111d4e55  push rsi
00007ed4111d4e56  push r8
00007ed4111d4e58  push r9
00007ed4111d4e5a  push r10
00007ed4111d4e5c  push r11
00007ed4111d4e5e  sub rsp, 0xF0
00007ed4111d4e65  vmovaps [rsp], xmm0
00007ed4111d4e6a  vmovaps [rsp+0x10], xmm1
00007ed4111d4e70  vmovaps [rsp+0x20], xmm2
00007ed4111d4e76  vmovaps [rsp+0x30], xmm3
00007ed4111d4e7c  vmovaps [rsp+0x40], xmm4
00007ed4111d4e82  vmovaps [rsp+0x50], xmm5
00007ed4111d4e88  vmovaps [rsp+0x60], xmm6
00007ed4111d4e8e  vmovaps [rsp+0x70], xmm8
00007ed4111d4e94  vmovaps [rsp+0x80], xmm9
00007ed4111d4e9d  vmovaps [rsp+0x90], xmm10
00007ed4111d4ea6  vmovaps [rsp+0xA0], xmm11
00007ed4111d4eaf  vmovaps [rsp+0xB0], xmm12
00007ed4111d4eb8  vmovaps [rsp+0xC0], xmm13
00007ed4111d4ec1  vmovaps [rsp+0xD0], xmm14
00007ed4111d4eca  vmovaps [rsp+0xE0], xmm15
00007ed4111d4ed3  sub rsp, 0x40
00007ed4111d4ed7  lea rdi, [rsp]
00007ed4111d4edb  lea rsi, [rsp+0x10]
00007ed4111d4ee0  lea rdx, [rsp+0x20]
00007ed4111d4ee5  lea rcx, [rsp+0x30]
00007ed4111d4eea  mov r8d, 0x00
00007ed4111d4ef0  lea r9, [r15+0x3A8]
00007ed4111d4ef7  movaps [rdi], xmm7
00007ed4111d4efa  movaps [rsi], xmm10
00007ed4111d4efe  movaps [rdx], xmm11
00007ed4111d4f02  movaps [rcx], xmm13
00007ed4111d4f06  mov rax, 0x5CA8E4A55A50
00007ed4111d4f10  call rax
00007ed4111d4f12  movaps xmm7, [rsp]
00007ed4111d4f16  add rsp, 0x40
00007ed4111d4f1a  vmovaps xmm0, [rsp]
00007ed4111d4f1f  vmovaps xmm1, [rsp+0x10]
00007ed4111d4f25  vmovaps xmm2, [rsp+0x20]
00007ed4111d4f2b  vmovaps xmm3, [rsp+0x30]
00007ed4111d4f31  vmovaps xmm4, [rsp+0x40]
00007ed4111d4f37  vmovaps xmm5, [rsp+0x50]
00007ed4111d4f3d  vmovaps xmm6, [rsp+0x60]
00007ed4111d4f43  vmovaps xmm8, [rsp+0x70]
00007ed4111d4f49  vmovaps xmm9, [rsp+0x80]
00007ed4111d4f52  vmovaps xmm10, [rsp+0x90]
00007ed4111d4f5b  vmovaps xmm11, [rsp+0xA0]
00007ed4111d4f64  vmovaps xmm12, [rsp+0xB0]
00007ed4111d4f6d  vmovaps xmm13, [rsp+0xC0]
00007ed4111d4f76  vmovaps xmm14, [rsp+0xD0]
00007ed4111d4f7f  vmovaps xmm15, [rsp+0xE0]
00007ed4111d4f88  add rsp, 0xF0
00007ed4111d4f8f  pop r11
00007ed4111d4f91  pop r10
00007ed4111d4f93  pop r9
00007ed4111d4f95  pop r8
00007ed4111d4f97  pop rsi
00007ed4111d4f98  pop rdi
00007ed4111d4f99  pop rdx
00007ed4111d4f9a  pop rcx
00007ed4111d4f9b  pop rax
00007ed4111d4f9c  add rsp, 0x08
00007ed4111d4fa0  jmp 0x00007ED4111D2F58
00007ed4111d4fa5  call 0x00007ED41100C260
00007ed4111d4faa  jmp 0x00007ED4111D2F62
00007ed4111d4faf  call 0x00007ED411009D70
00007ed4111d4fb4  jmp 0x00007ED4111D2F6C
00007ed4111d4fb9  sub rsp, 0x08
00007ed4111d4fbd  push rax
00007ed4111d4fbe  push rcx
00007ed4111d4fbf  push rdx
00007ed4111d4fc0  push rdi
00007ed4111d4fc1  push rsi
00007ed4111d4fc2  push r8
00007ed4111d4fc4  push r9
00007ed4111d4fc6  push r10
00007ed4111d4fc8  push r11
00007ed4111d4fca  sub rsp, 0xF0
00007ed4111d4fd1  vmovaps [rsp], xmm0
00007ed4111d4fd6  vmovaps [rsp+0x10], xmm1
00007ed4111d4fdc  vmovaps [rsp+0x20], xmm2
00007ed4111d4fe2  vmovaps [rsp+0x30], xmm3
00007ed4111d4fe8  vmovaps [rsp+0x40], xmm4
00007ed4111d4fee  vmovaps [rsp+0x50], xmm5
00007ed4111d4ff4  vmovaps [rsp+0x60], xmm7
00007ed4111d4ffa  vmovaps [rsp+0x70], xmm8
00007ed4111d5000  vmovaps [rsp+0x80], xmm9
00007ed4111d5009  vmovaps [rsp+0x90], xmm10
00007ed4111d5012  vmovaps [rsp+0xA0], xmm11
00007ed4111d501b  vmovaps [rsp+0xB0], xmm12
00007ed4111d5024  vmovaps [rsp+0xC0], xmm13
00007ed4111d502d  vmovaps [rsp+0xD0], xmm14
00007ed4111d5036  vmovaps [rsp+0xE0], xmm15
00007ed4111d503f  sub rsp, 0x40
00007ed4111d5043  lea rdi, [rsp]
00007ed4111d5047  lea rsi, [rsp+0x10]
00007ed4111d504c  lea rdx, [rsp+0x20]
00007ed4111d5051  lea rcx, [rsp+0x30]
00007ed4111d5056  mov r8d, 0x00
00007ed4111d505c  lea r9, [r15+0x3A8]
00007ed4111d5063  movaps [rdi], xmm6
00007ed4111d5066  movaps [rsi], xmm8
00007ed4111d506a  movaps [rdx], xmm15
00007ed4111d506e  movaps [rcx], xmm10
00007ed4111d5072  mov rax, 0x5CA8E4A55A50
00007ed4111d507c  call rax
00007ed4111d507e  movaps xmm6, [rsp]
00007ed4111d5082  add rsp, 0x40
00007ed4111d5086  vmovaps xmm0, [rsp]
00007ed4111d508b  vmovaps xmm1, [rsp+0x10]
00007ed4111d5091  vmovaps xmm2, [rsp+0x20]
00007ed4111d5097  vmovaps xmm3, [rsp+0x30]
00007ed4111d509d  vmovaps xmm4, [rsp+0x40]
00007ed4111d50a3  vmovaps xmm5, [rsp+0x50]
00007ed4111d50a9  vmovaps xmm7, [rsp+0x60]
00007ed4111d50af  vmovaps xmm8, [rsp+0x70]
00007ed4111d50b5  vmovaps xmm9, [rsp+0x80]
00007ed4111d50be  vmovaps xmm10, [rsp+0x90]
00007ed4111d50c7  vmovaps xmm11, [rsp+0xA0]
00007ed4111d50d0  vmovaps xmm12, [rsp+0xB0]
00007ed4111d50d9  vmovaps xmm13, [rsp+0xC0]
00007ed4111d50e2  vmovaps xmm14, [rsp+0xD0]
00007ed4111d50eb  vmovaps xmm15, [rsp+0xE0]
00007ed4111d50f4  add rsp, 0xF0
00007ed4111d50fb  pop r11
00007ed4111d50fd  pop r10
00007ed4111d50ff  pop r9
00007ed4111d5101  pop r8
00007ed4111d5103  pop rsi
00007ed4111d5104  pop rdi
00007ed4111d5105  pop rdx
00007ed4111d5106  pop rcx
00007ed4111d5107  pop rax
00007ed4111d5108  add rsp, 0x08
00007ed4111d510c  jmp 0x00007ED4111D2FA4
00007ed4111d5111  sub rsp, 0x08
00007ed4111d5115  push rax
00007ed4111d5116  push rcx
00007ed4111d5117  push rdx
00007ed4111d5118  push rdi
00007ed4111d5119  push rsi
00007ed4111d511a  push r8
00007ed4111d511c  push r9
00007ed4111d511e  push r10
00007ed4111d5120  push r11
00007ed4111d5122  sub rsp, 0xF0
00007ed4111d5129  vmovaps [rsp], xmm0
00007ed4111d512e  vmovaps [rsp+0x10], xmm1
00007ed4111d5134  vmovaps [rsp+0x20], xmm2
00007ed4111d513a  vmovaps [rsp+0x30], xmm3
00007ed4111d5140  vmovaps [rsp+0x40], xmm4
00007ed4111d5146  vmovaps [rsp+0x50], xmm5
00007ed4111d514c  vmovaps [rsp+0x60], xmm6
00007ed4111d5152  vmovaps [rsp+0x70], xmm7
00007ed4111d5158  vmovaps [rsp+0x80], xmm8
00007ed4111d5161  vmovaps [rsp+0x90], xmm9
00007ed4111d516a  vmovaps [rsp+0xA0], xmm11
00007ed4111d5173  vmovaps [rsp+0xB0], xmm12
00007ed4111d517c  vmovaps [rsp+0xC0], xmm13
00007ed4111d5185  vmovaps [rsp+0xD0], xmm14
00007ed4111d518e  vmovaps [rsp+0xE0], xmm15
00007ed4111d5197  sub rsp, 0x40
00007ed4111d519b  lea rdi, [rsp]
00007ed4111d519f  lea rsi, [rsp+0x10]
00007ed4111d51a4  lea rdx, [rsp+0x20]
00007ed4111d51a9  lea rcx, [rsp+0x30]
00007ed4111d51ae  mov r8d, 0x00
00007ed4111d51b4  lea r9, [r15+0x3A8]
00007ed4111d51bb  movaps [rdi], xmm10
00007ed4111d51bf  movaps [rsi], xmm9
00007ed4111d51c3  movaps [rdx], xmm13
00007ed4111d51c7  movaps [rcx], xmm15
00007ed4111d51cb  mov rax, 0x5CA8E4A55A50
00007ed4111d51d5  call rax
00007ed4111d51d7  movaps xmm10, [rsp]
00007ed4111d51dc  add rsp, 0x40
00007ed4111d51e0  vmovaps xmm0, [rsp]
00007ed4111d51e5  vmovaps xmm1, [rsp+0x10]
00007ed4111d51eb  vmovaps xmm2, [rsp+0x20]
00007ed4111d51f1  vmovaps xmm3, [rsp+0x30]
00007ed4111d51f7  vmovaps xmm4, [rsp+0x40]
00007ed4111d51fd  vmovaps xmm5, [rsp+0x50]
00007ed4111d5203  vmovaps xmm6, [rsp+0x60]
00007ed4111d5209  vmovaps xmm7, [rsp+0x70]
00007ed4111d520f  vmovaps xmm8, [rsp+0x80]
00007ed4111d5218  vmovaps xmm9, [rsp+0x90]
00007ed4111d5221  vmovaps xmm11, [rsp+0xA0]
00007ed4111d522a  vmovaps xmm12, [rsp+0xB0]
00007ed4111d5233  vmovaps xmm13, [rsp+0xC0]
00007ed4111d523c  vmovaps xmm14, [rsp+0xD0]
00007ed4111d5245  vmovaps xmm15, [rsp+0xE0]
00007ed4111d524e  add rsp, 0xF0
00007ed4111d5255  pop r11
00007ed4111d5257  pop r10
00007ed4111d5259  pop r9
00007ed4111d525b  pop r8
00007ed4111d525d  pop rsi
00007ed4111d525e  pop rdi
00007ed4111d525f  pop rdx
00007ed4111d5260  pop rcx
00007ed4111d5261  pop rax
00007ed4111d5262  add rsp, 0x08
00007ed4111d5266  jmp 0x00007ED4111D2FCD
00007ed4111d526b  sub rsp, 0x08
00007ed4111d526f  push rax
00007ed4111d5270  push rcx
00007ed4111d5271  push rdx
00007ed4111d5272  push rdi
00007ed4111d5273  push rsi
00007ed4111d5274  push r8
00007ed4111d5276  push r9
00007ed4111d5278  push r10
00007ed4111d527a  push r11
00007ed4111d527c  sub rsp, 0xF0
00007ed4111d5283  vmovaps [rsp], xmm0
00007ed4111d5288  vmovaps [rsp+0x10], xmm1
00007ed4111d528e  vmovaps [rsp+0x20], xmm2
00007ed4111d5294  vmovaps [rsp+0x30], xmm3
00007ed4111d529a  vmovaps [rsp+0x40], xmm4
00007ed4111d52a0  vmovaps [rsp+0x50], xmm5
00007ed4111d52a6  vmovaps [rsp+0x60], xmm6
00007ed4111d52ac  vmovaps [rsp+0x70], xmm7
00007ed4111d52b2  vmovaps [rsp+0x80], xmm8
00007ed4111d52bb  vmovaps [rsp+0x90], xmm9
00007ed4111d52c4  vmovaps [rsp+0xA0], xmm10
00007ed4111d52cd  vmovaps [rsp+0xB0], xmm11
00007ed4111d52d6  vmovaps [rsp+0xC0], xmm12
00007ed4111d52df  vmovaps [rsp+0xD0], xmm14
00007ed4111d52e8  vmovaps [rsp+0xE0], xmm15
00007ed4111d52f1  sub rsp, 0x40
00007ed4111d52f5  lea rdi, [rsp]
00007ed4111d52f9  lea rsi, [rsp+0x10]
00007ed4111d52fe  lea rdx, [rsp+0x20]
00007ed4111d5303  lea rcx, [rsp+0x30]
00007ed4111d5308  mov r8d, 0x00
00007ed4111d530e  lea r9, [r15+0x3A8]
00007ed4111d5315  movaps [rdi], xmm13
00007ed4111d5319  movaps [rsi], xmm12
00007ed4111d531d  movaps [rdx], xmm4
00007ed4111d5320  movaps [rcx], xmm15
00007ed4111d5324  mov rax, 0x5CA8E4A55A50
00007ed4111d532e  call rax
00007ed4111d5330  movaps xmm13, [rsp]
00007ed4111d5335  add rsp, 0x40
00007ed4111d5339  vmovaps xmm0, [rsp]
00007ed4111d533e  vmovaps xmm1, [rsp+0x10]
00007ed4111d5344  vmovaps xmm2, [rsp+0x20]
00007ed4111d534a  vmovaps xmm3, [rsp+0x30]
00007ed4111d5350  vmovaps xmm4, [rsp+0x40]
00007ed4111d5356  vmovaps xmm5, [rsp+0x50]
00007ed4111d535c  vmovaps xmm6, [rsp+0x60]
00007ed4111d5362  vmovaps xmm7, [rsp+0x70]
00007ed4111d5368  vmovaps xmm8, [rsp+0x80]
00007ed4111d5371  vmovaps xmm9, [rsp+0x90]
00007ed4111d537a  vmovaps xmm10, [rsp+0xA0]
00007ed4111d5383  vmovaps xmm11, [rsp+0xB0]
00007ed4111d538c  vmovaps xmm12, [rsp+0xC0]
00007ed4111d5395  vmovaps xmm14, [rsp+0xD0]
00007ed4111d539e  vmovaps xmm15, [rsp+0xE0]
00007ed4111d53a7  add rsp, 0xF0
00007ed4111d53ae  pop r11
00007ed4111d53b0  pop r10
00007ed4111d53b2  pop r9
00007ed4111d53b4  pop r8
00007ed4111d53b6  pop rsi
00007ed4111d53b7  pop rdi
00007ed4111d53b8  pop rdx
00007ed4111d53b9  pop rcx
00007ed4111d53ba  pop rax
00007ed4111d53bb  add rsp, 0x08
00007ed4111d53bf  jmp 0x00007ED4111D2FF6
00007ed4111d53c4  sub rsp, 0x08
00007ed4111d53c8  push rax
00007ed4111d53c9  push rcx
00007ed4111d53ca  push rdx
00007ed4111d53cb  push rdi
00007ed4111d53cc  push rsi
00007ed4111d53cd  push r8
00007ed4111d53cf  push r9
00007ed4111d53d1  push r10
00007ed4111d53d3  push r11
00007ed4111d53d5  sub rsp, 0xF0
00007ed4111d53dc  vmovaps [rsp], xmm0
00007ed4111d53e1  vmovaps [rsp+0x10], xmm1
00007ed4111d53e7  vmovaps [rsp+0x20], xmm2
00007ed4111d53ed  vmovaps [rsp+0x30], xmm3
00007ed4111d53f3  vmovaps [rsp+0x40], xmm4
00007ed4111d53f9  vmovaps [rsp+0x50], xmm5
00007ed4111d53ff  vmovaps [rsp+0x60], xmm6
00007ed4111d5405  vmovaps [rsp+0x70], xmm7
00007ed4111d540b  vmovaps [rsp+0x80], xmm8
00007ed4111d5414  vmovaps [rsp+0x90], xmm9
00007ed4111d541d  vmovaps [rsp+0xA0], xmm10
00007ed4111d5426  vmovaps [rsp+0xB0], xmm11
00007ed4111d542f  vmovaps [rsp+0xC0], xmm13
00007ed4111d5438  vmovaps [rsp+0xD0], xmm14
00007ed4111d5441  vmovaps [rsp+0xE0], xmm15
00007ed4111d544a  sub rsp, 0x40
00007ed4111d544e  lea rdi, [rsp]
00007ed4111d5452  lea rsi, [rsp+0x10]
00007ed4111d5457  lea rdx, [rsp+0x20]
00007ed4111d545c  lea rcx, [rsp+0x30]
00007ed4111d5461  mov r8d, 0x00
00007ed4111d5467  lea r9, [r15+0x3A8]
00007ed4111d546e  movaps [rdi], xmm12
00007ed4111d5472  movaps [rsi], xmm7
00007ed4111d5475  movaps [rdx], xmm1
00007ed4111d5478  movaps [rcx], xmm15
00007ed4111d547c  mov rax, 0x5CA8E4A55A50
00007ed4111d5486  call rax
00007ed4111d5488  movaps xmm12, [rsp]
00007ed4111d548d  add rsp, 0x40
00007ed4111d5491  vmovaps xmm0, [rsp]
00007ed4111d5496  vmovaps xmm1, [rsp+0x10]
00007ed4111d549c  vmovaps xmm2, [rsp+0x20]
00007ed4111d54a2  vmovaps xmm3, [rsp+0x30]
00007ed4111d54a8  vmovaps xmm4, [rsp+0x40]
00007ed4111d54ae  vmovaps xmm5, [rsp+0x50]
00007ed4111d54b4  vmovaps xmm6, [rsp+0x60]
00007ed4111d54ba  vmovaps xmm7, [rsp+0x70]
00007ed4111d54c0  vmovaps xmm8, [rsp+0x80]
00007ed4111d54c9  vmovaps xmm9, [rsp+0x90]
00007ed4111d54d2  vmovaps xmm10, [rsp+0xA0]
00007ed4111d54db  vmovaps xmm11, [rsp+0xB0]
00007ed4111d54e4  vmovaps xmm13, [rsp+0xC0]
00007ed4111d54ed  vmovaps xmm14, [rsp+0xD0]
00007ed4111d54f6  vmovaps xmm15, [rsp+0xE0]
00007ed4111d54ff  add rsp, 0xF0
00007ed4111d5506  pop r11
00007ed4111d5508  pop r10
00007ed4111d550a  pop r9
00007ed4111d550c  pop r8
00007ed4111d550e  pop rsi
00007ed4111d550f  pop rdi
00007ed4111d5510  pop rdx
00007ed4111d5511  pop rcx
00007ed4111d5512  pop rax
00007ed4111d5513  add rsp, 0x08
00007ed4111d5517  jmp 0x00007ED4111D301F
00007ed4111d551c  call 0x00007ED410FFF430
00007ed4111d5521  jmp 0x00007ED4111D3029
00007ed4111d5526  call 0x00007ED41100E760
00007ed4111d552b  jmp 0x00007ED4111D3033
00007ed4111d5530  sub rsp, 0x08
00007ed4111d5534  push rax
00007ed4111d5535  push rcx
00007ed4111d5536  push rdx
00007ed4111d5537  push rdi
00007ed4111d5538  push rsi
00007ed4111d5539  push r8
00007ed4111d553b  push r9
00007ed4111d553d  push r10
00007ed4111d553f  push r11
00007ed4111d5541  sub rsp, 0xF0
00007ed4111d5548  vmovaps [rsp], xmm0
00007ed4111d554d  vmovaps [rsp+0x10], xmm1
00007ed4111d5553  vmovaps [rsp+0x20], xmm2
00007ed4111d5559  vmovaps [rsp+0x30], xmm3
00007ed4111d555f  vmovaps [rsp+0x40], xmm4
00007ed4111d5565  vmovaps [rsp+0x50], xmm5
00007ed4111d556b  vmovaps [rsp+0x60], xmm6
00007ed4111d5571  vmovaps [rsp+0x70], xmm8
00007ed4111d5577  vmovaps [rsp+0x80], xmm9
00007ed4111d5580  vmovaps [rsp+0x90], xmm10
00007ed4111d5589  vmovaps [rsp+0xA0], xmm11
00007ed4111d5592  vmovaps [rsp+0xB0], xmm12
00007ed4111d559b  vmovaps [rsp+0xC0], xmm13
00007ed4111d55a4  vmovaps [rsp+0xD0], xmm14
00007ed4111d55ad  vmovaps [rsp+0xE0], xmm15
00007ed4111d55b6  sub rsp, 0x40
00007ed4111d55ba  lea rdi, [rsp]
00007ed4111d55be  lea rsi, [rsp+0x10]
00007ed4111d55c3  lea rdx, [rsp+0x20]
00007ed4111d55c8  lea rcx, [rsp+0x30]
00007ed4111d55cd  mov r8d, 0x00
00007ed4111d55d3  lea r9, [r15+0x3A8]
00007ed4111d55da  movaps [rdi], xmm7
00007ed4111d55dd  movaps [rsi], xmm6
00007ed4111d55e0  movaps [rdx], xmm8
00007ed4111d55e4  movaps [rcx], xmm9
00007ed4111d55e8  mov rax, 0x5CA8E4A55A50
00007ed4111d55f2  call rax
00007ed4111d55f4  movaps xmm7, [rsp]
00007ed4111d55f8  add rsp, 0x40
00007ed4111d55fc  vmovaps xmm0, [rsp]
00007ed4111d5601  vmovaps xmm1, [rsp+0x10]
00007ed4111d5607  vmovaps xmm2, [rsp+0x20]
00007ed4111d560d  vmovaps xmm3, [rsp+0x30]
00007ed4111d5613  vmovaps xmm4, [rsp+0x40]
00007ed4111d5619  vmovaps xmm5, [rsp+0x50]
00007ed4111d561f  vmovaps xmm6, [rsp+0x60]
00007ed4111d5625  vmovaps xmm8, [rsp+0x70]
00007ed4111d562b  vmovaps xmm9, [rsp+0x80]
00007ed4111d5634  vmovaps xmm10, [rsp+0x90]
00007ed4111d563d  vmovaps xmm11, [rsp+0xA0]
00007ed4111d5646  vmovaps xmm12, [rsp+0xB0]
00007ed4111d564f  vmovaps xmm13, [rsp+0xC0]
00007ed4111d5658  vmovaps xmm14, [rsp+0xD0]
00007ed4111d5661  vmovaps xmm15, [rsp+0xE0]
00007ed4111d566a  add rsp, 0xF0
00007ed4111d5671  pop r11
00007ed4111d5673  pop r10
00007ed4111d5675  pop r9
00007ed4111d5677  pop r8
00007ed4111d5679  pop rsi
00007ed4111d567a  pop rdi
00007ed4111d567b  pop rdx
00007ed4111d567c  pop rcx
00007ed4111d567d  pop rax
00007ed4111d567e  add rsp, 0x08
00007ed4111d5682  jmp 0x00007ED4111D305D
00007ed4111d5687  sub rsp, 0x08
00007ed4111d568b  push rax
00007ed4111d568c  push rcx
00007ed4111d568d  push rdx
00007ed4111d568e  push rdi
00007ed4111d568f  push rsi
00007ed4111d5690  push r8
00007ed4111d5692  push r9
00007ed4111d5694  push r10
00007ed4111d5696  push r11
00007ed4111d5698  sub rsp, 0xF0
00007ed4111d569f  vmovaps [rsp], xmm0
00007ed4111d56a4  vmovaps [rsp+0x10], xmm1
00007ed4111d56aa  vmovaps [rsp+0x20], xmm2
00007ed4111d56b0  vmovaps [rsp+0x30], xmm3
00007ed4111d56b6  vmovaps [rsp+0x40], xmm4
00007ed4111d56bc  vmovaps [rsp+0x50], xmm5
00007ed4111d56c2  vmovaps [rsp+0x60], xmm6
00007ed4111d56c8  vmovaps [rsp+0x70], xmm7
00007ed4111d56ce  vmovaps [rsp+0x80], xmm9
00007ed4111d56d7  vmovaps [rsp+0x90], xmm10
00007ed4111d56e0  vmovaps [rsp+0xA0], xmm11
00007ed4111d56e9  vmovaps [rsp+0xB0], xmm12
00007ed4111d56f2  vmovaps [rsp+0xC0], xmm13
00007ed4111d56fb  vmovaps [rsp+0xD0], xmm14
00007ed4111d5704  vmovaps [rsp+0xE0], xmm15
00007ed4111d570d  sub rsp, 0x40
00007ed4111d5711  lea rdi, [rsp]
00007ed4111d5715  lea rsi, [rsp+0x10]
00007ed4111d571a  lea rdx, [rsp+0x20]
00007ed4111d571f  lea rcx, [rsp+0x30]
00007ed4111d5724  mov r8d, 0x00
00007ed4111d572a  lea r9, [r15+0x3A8]
00007ed4111d5731  movaps [rdi], xmm8
00007ed4111d5735  movaps [rsi], xmm10
00007ed4111d5739  movaps [rdx], xmm14
00007ed4111d573d  movaps [rcx], xmm9
00007ed4111d5741  mov rax, 0x5CA8E4A55A50
00007ed4111d574b  call rax
00007ed4111d574d  movaps xmm8, [rsp]
00007ed4111d5752  add rsp, 0x40
00007ed4111d5756  vmovaps xmm0, [rsp]
00007ed4111d575b  vmovaps xmm1, [rsp+0x10]
00007ed4111d5761  vmovaps xmm2, [rsp+0x20]
00007ed4111d5767  vmovaps xmm3, [rsp+0x30]
00007ed4111d576d  vmovaps xmm4, [rsp+0x40]
00007ed4111d5773  vmovaps xmm5, [rsp+0x50]
00007ed4111d5779  vmovaps xmm6, [rsp+0x60]
00007ed4111d577f  vmovaps xmm7, [rsp+0x70]
00007ed4111d5785  vmovaps xmm9, [rsp+0x80]
00007ed4111d578e  vmovaps xmm10, [rsp+0x90]
00007ed4111d5797  vmovaps xmm11, [rsp+0xA0]
00007ed4111d57a0  vmovaps xmm12, [rsp+0xB0]
00007ed4111d57a9  vmovaps xmm13, [rsp+0xC0]
00007ed4111d57b2  vmovaps xmm14, [rsp+0xD0]
00007ed4111d57bb  vmovaps xmm15, [rsp+0xE0]
00007ed4111d57c4  add rsp, 0xF0
00007ed4111d57cb  pop r11
00007ed4111d57cd  pop r10
00007ed4111d57cf  pop r9
00007ed4111d57d1  pop r8
00007ed4111d57d3  pop rsi
00007ed4111d57d4  pop rdi
00007ed4111d57d5  pop rdx
00007ed4111d57d6  pop rcx
00007ed4111d57d7  pop rax
00007ed4111d57d8  add rsp, 0x08
00007ed4111d57dc  jmp 0x00007ED4111D3083
00007ed4111d57e1  sub rsp, 0x08
00007ed4111d57e5  push rax
00007ed4111d57e6  push rcx
00007ed4111d57e7  push rdx
00007ed4111d57e8  push rdi
00007ed4111d57e9  push rsi
00007ed4111d57ea  push r8
00007ed4111d57ec  push r9
00007ed4111d57ee  push r10
00007ed4111d57f0  push r11
00007ed4111d57f2  sub rsp, 0xF0
00007ed4111d57f9  vmovaps [rsp], xmm0
00007ed4111d57fe  vmovaps [rsp+0x10], xmm1
00007ed4111d5804  vmovaps [rsp+0x20], xmm2
00007ed4111d580a  vmovaps [rsp+0x30], xmm3
00007ed4111d5810  vmovaps [rsp+0x40], xmm4
00007ed4111d5816  vmovaps [rsp+0x50], xmm5
00007ed4111d581c  vmovaps [rsp+0x60], xmm6
00007ed4111d5822  vmovaps [rsp+0x70], xmm7
00007ed4111d5828  vmovaps [rsp+0x80], xmm8
00007ed4111d5831  vmovaps [rsp+0x90], xmm9
00007ed4111d583a  vmovaps [rsp+0xA0], xmm11
00007ed4111d5843  vmovaps [rsp+0xB0], xmm12
00007ed4111d584c  vmovaps [rsp+0xC0], xmm13
00007ed4111d5855  vmovaps [rsp+0xD0], xmm14
00007ed4111d585e  vmovaps [rsp+0xE0], xmm15
00007ed4111d5867  sub rsp, 0x40
00007ed4111d586b  lea rdi, [rsp]
00007ed4111d586f  lea rsi, [rsp+0x10]
00007ed4111d5874  lea rdx, [rsp+0x20]
00007ed4111d5879  lea rcx, [rsp+0x30]
00007ed4111d587e  mov r8d, 0x00
00007ed4111d5884  lea r9, [r15+0x3A8]
00007ed4111d588b  movaps [rdi], xmm10
00007ed4111d588f  movaps [rsi], xmm13
00007ed4111d5893  movaps [rdx], xmm11
00007ed4111d5897  movaps [rcx], xmm14
00007ed4111d589b  mov rax, 0x5CA8E4A55A50
00007ed4111d58a5  call rax
00007ed4111d58a7  movaps xmm10, [rsp]
00007ed4111d58ac  add rsp, 0x40
00007ed4111d58b0  vmovaps xmm0, [rsp]
00007ed4111d58b5  vmovaps xmm1, [rsp+0x10]
00007ed4111d58bb  vmovaps xmm2, [rsp+0x20]
00007ed4111d58c1  vmovaps xmm3, [rsp+0x30]
00007ed4111d58c7  vmovaps xmm4, [rsp+0x40]
00007ed4111d58cd  vmovaps xmm5, [rsp+0x50]
00007ed4111d58d3  vmovaps xmm6, [rsp+0x60]
00007ed4111d58d9  vmovaps xmm7, [rsp+0x70]
00007ed4111d58df  vmovaps xmm8, [rsp+0x80]
00007ed4111d58e8  vmovaps xmm9, [rsp+0x90]
00007ed4111d58f1  vmovaps xmm11, [rsp+0xA0]
00007ed4111d58fa  vmovaps xmm12, [rsp+0xB0]
00007ed4111d5903  vmovaps xmm13, [rsp+0xC0]
00007ed4111d590c  vmovaps xmm14, [rsp+0xD0]
00007ed4111d5915  vmovaps xmm15, [rsp+0xE0]
00007ed4111d591e  add rsp, 0xF0
00007ed4111d5925  pop r11
00007ed4111d5927  pop r10
00007ed4111d5929  pop r9
00007ed4111d592b  pop r8
00007ed4111d592d  pop rsi
00007ed4111d592e  pop rdi
00007ed4111d592f  pop rdx
00007ed4111d5930  pop rcx
00007ed4111d5931  pop rax
00007ed4111d5932  add rsp, 0x08
00007ed4111d5936  jmp 0x00007ED4111D30A9
00007ed4111d593b  sub rsp, 0x08
00007ed4111d593f  push rax
00007ed4111d5940  push rcx
00007ed4111d5941  push rdx
00007ed4111d5942  push rdi
00007ed4111d5943  push rsi
00007ed4111d5944  push r8
00007ed4111d5946  push r9
00007ed4111d5948  push r10
00007ed4111d594a  push r11
00007ed4111d594c  sub rsp, 0xF0
00007ed4111d5953  vmovaps [rsp], xmm0
00007ed4111d5958  vmovaps [rsp+0x10], xmm1
00007ed4111d595e  vmovaps [rsp+0x20], xmm2
00007ed4111d5964  vmovaps [rsp+0x30], xmm3
00007ed4111d596a  vmovaps [rsp+0x40], xmm4
00007ed4111d5970  vmovaps [rsp+0x50], xmm5
00007ed4111d5976  vmovaps [rsp+0x60], xmm6
00007ed4111d597c  vmovaps [rsp+0x70], xmm7
00007ed4111d5982  vmovaps [rsp+0x80], xmm8
00007ed4111d598b  vmovaps [rsp+0x90], xmm9
00007ed4111d5994  vmovaps [rsp+0xA0], xmm10
00007ed4111d599d  vmovaps [rsp+0xB0], xmm11
00007ed4111d59a6  vmovaps [rsp+0xC0], xmm12
00007ed4111d59af  vmovaps [rsp+0xD0], xmm14
00007ed4111d59b8  vmovaps [rsp+0xE0], xmm15
00007ed4111d59c1  sub rsp, 0x40
00007ed4111d59c5  lea rdi, [rsp]
00007ed4111d59c9  lea rsi, [rsp+0x10]
00007ed4111d59ce  lea rdx, [rsp+0x20]
00007ed4111d59d3  lea rcx, [rsp+0x30]
00007ed4111d59d8  mov r8d, 0x00
00007ed4111d59de  lea r9, [r15+0x3A8]
00007ed4111d59e5  movaps [rdi], xmm13
00007ed4111d59e9  movaps [rsi], xmm12
00007ed4111d59ed  movaps [rdx], xmm15
00007ed4111d59f1  movaps [rcx], xmm14
00007ed4111d59f5  mov rax, 0x5CA8E4A55A50
00007ed4111d59ff  call rax
00007ed4111d5a01  movaps xmm13, [rsp]
00007ed4111d5a06  add rsp, 0x40
00007ed4111d5a0a  vmovaps xmm0, [rsp]
00007ed4111d5a0f  vmovaps xmm1, [rsp+0x10]
00007ed4111d5a15  vmovaps xmm2, [rsp+0x20]
00007ed4111d5a1b  vmovaps xmm3, [rsp+0x30]
00007ed4111d5a21  vmovaps xmm4, [rsp+0x40]
00007ed4111d5a27  vmovaps xmm5, [rsp+0x50]
00007ed4111d5a2d  vmovaps xmm6, [rsp+0x60]
00007ed4111d5a33  vmovaps xmm7, [rsp+0x70]
00007ed4111d5a39  vmovaps xmm8, [rsp+0x80]
00007ed4111d5a42  vmovaps xmm9, [rsp+0x90]
00007ed4111d5a4b  vmovaps xmm10, [rsp+0xA0]
00007ed4111d5a54  vmovaps xmm11, [rsp+0xB0]
00007ed4111d5a5d  vmovaps xmm12, [rsp+0xC0]
00007ed4111d5a66  vmovaps xmm14, [rsp+0xD0]
00007ed4111d5a6f  vmovaps xmm15, [rsp+0xE0]
00007ed4111d5a78  add rsp, 0xF0
00007ed4111d5a7f  pop r11
00007ed4111d5a81  pop r10
00007ed4111d5a83  pop r9
00007ed4111d5a85  pop r8
00007ed4111d5a87  pop rsi
00007ed4111d5a88  pop rdi
00007ed4111d5a89  pop rdx
00007ed4111d5a8a  pop rcx
00007ed4111d5a8b  pop rax
00007ed4111d5a8c  add rsp, 0x08
00007ed4111d5a90  jmp 0x00007ED4111D30CF
00007ed4111d5a95  call 0x00007ED41100E760
00007ed4111d5a9a  jmp 0x00007ED4111D30DC
00007ed4111d5a9f  call 0x00007ED41100D4E0
00007ed4111d5aa4  jmp 0x00007ED4111D30E9
00007ed4111d5aa9  sub rsp, 0x08
00007ed4111d5aad  push rax
00007ed4111d5aae  push rcx
00007ed4111d5aaf  push rdx
00007ed4111d5ab0  push rdi
00007ed4111d5ab1  push rsi
00007ed4111d5ab2  push r8
00007ed4111d5ab4  push r9
00007ed4111d5ab6  push r10
00007ed4111d5ab8  push r11
00007ed4111d5aba  sub rsp, 0xF0
00007ed4111d5ac1  vmovaps [rsp], xmm0
00007ed4111d5ac6  vmovaps [rsp+0x10], xmm1
00007ed4111d5acc  vmovaps [rsp+0x20], xmm2
00007ed4111d5ad2  vmovaps [rsp+0x30], xmm3
00007ed4111d5ad8  vmovaps [rsp+0x40], xmm4
00007ed4111d5ade  vmovaps [rsp+0x50], xmm5
00007ed4111d5ae4  vmovaps [rsp+0x60], xmm6
00007ed4111d5aea  vmovaps [rsp+0x70], xmm7
00007ed4111d5af0  vmovaps [rsp+0x80], xmm8
00007ed4111d5af9  vmovaps [rsp+0x90], xmm9
00007ed4111d5b02  vmovaps [rsp+0xA0], xmm10
00007ed4111d5b0b  vmovaps [rsp+0xB0], xmm12
00007ed4111d5b14  vmovaps [rsp+0xC0], xmm13
00007ed4111d5b1d  vmovaps [rsp+0xD0], xmm14
00007ed4111d5b26  vmovaps [rsp+0xE0], xmm15
00007ed4111d5b2f  sub rsp, 0x40
00007ed4111d5b33  lea rdi, [rsp]
00007ed4111d5b37  lea rsi, [rsp+0x10]
00007ed4111d5b3c  lea rdx, [rsp+0x20]
00007ed4111d5b41  lea rcx, [rsp+0x30]
00007ed4111d5b46  mov r8d, 0x00
00007ed4111d5b4c  lea r9, [r15+0x3A8]
00007ed4111d5b53  movaps [rdi], xmm11
00007ed4111d5b57  movaps [rsi], xmm7
00007ed4111d5b5a  movaps [rdx], xmm1
00007ed4111d5b5d  movaps [rcx], xmm12
00007ed4111d5b61  mov rax, 0x5CA8E4A55A50
00007ed4111d5b6b  call rax
00007ed4111d5b6d  movaps xmm11, [rsp]
00007ed4111d5b72  add rsp, 0x40
00007ed4111d5b76  vmovaps xmm0, [rsp]
00007ed4111d5b7b  vmovaps xmm1, [rsp+0x10]
00007ed4111d5b81  vmovaps xmm2, [rsp+0x20]
00007ed4111d5b87  vmovaps xmm3, [rsp+0x30]
00007ed4111d5b8d  vmovaps xmm4, [rsp+0x40]
00007ed4111d5b93  vmovaps xmm5, [rsp+0x50]
00007ed4111d5b99  vmovaps xmm6, [rsp+0x60]
00007ed4111d5b9f  vmovaps xmm7, [rsp+0x70]
00007ed4111d5ba5  vmovaps xmm8, [rsp+0x80]
00007ed4111d5bae  vmovaps xmm9, [rsp+0x90]
00007ed4111d5bb7  vmovaps xmm10, [rsp+0xA0]
00007ed4111d5bc0  vmovaps xmm12, [rsp+0xB0]
00007ed4111d5bc9  vmovaps xmm13, [rsp+0xC0]
00007ed4111d5bd2  vmovaps xmm14, [rsp+0xD0]
00007ed4111d5bdb  vmovaps xmm15, [rsp+0xE0]
00007ed4111d5be4  add rsp, 0xF0
00007ed4111d5beb  pop r11
00007ed4111d5bed  pop r10
00007ed4111d5bef  pop r9
00007ed4111d5bf1  pop r8
00007ed4111d5bf3  pop rsi
00007ed4111d5bf4  pop rdi
00007ed4111d5bf5  pop rdx
00007ed4111d5bf6  pop rcx
00007ed4111d5bf7  pop rax
00007ed4111d5bf8  add rsp, 0x08
00007ed4111d5bfc  jmp 0x00007ED4111D3122
00007ed4111d5c01  call 0x00007ED410FFF430
00007ed4111d5c06  jmp 0x00007ED4111D3134
00007ed4111d5c0b  sub rsp, 0x08
00007ed4111d5c0f  push rax
00007ed4111d5c10  push rcx
00007ed4111d5c11  push rdx
00007ed4111d5c12  push rdi
00007ed4111d5c13  push rsi
00007ed4111d5c14  push r8
00007ed4111d5c16  push r9
00007ed4111d5c18  push r10
00007ed4111d5c1a  push r11
00007ed4111d5c1c  sub rsp, 0xF0
00007ed4111d5c23  vmovaps [rsp], xmm0
00007ed4111d5c28  vmovaps [rsp+0x10], xmm1
00007ed4111d5c2e  vmovaps [rsp+0x20], xmm2
00007ed4111d5c34  vmovaps [rsp+0x30], xmm3
00007ed4111d5c3a  vmovaps [rsp+0x40], xmm4
00007ed4111d5c40  vmovaps [rsp+0x50], xmm5
00007ed4111d5c46  vmovaps [rsp+0x60], xmm6
00007ed4111d5c4c  vmovaps [rsp+0x70], xmm7
00007ed4111d5c52  vmovaps [rsp+0x80], xmm8
00007ed4111d5c5b  vmovaps [rsp+0x90], xmm10
00007ed4111d5c64  vmovaps [rsp+0xA0], xmm11
00007ed4111d5c6d  vmovaps [rsp+0xB0], xmm12
00007ed4111d5c76  vmovaps [rsp+0xC0], xmm13
00007ed4111d5c7f  vmovaps [rsp+0xD0], xmm14
00007ed4111d5c88  vmovaps [rsp+0xE0], xmm15
00007ed4111d5c91  sub rsp, 0x40
00007ed4111d5c95  lea rdi, [rsp]
00007ed4111d5c99  lea rsi, [rsp+0x10]
00007ed4111d5c9e  lea rdx, [rsp+0x20]
00007ed4111d5ca3  lea rcx, [rsp+0x30]
00007ed4111d5ca8  mov r8d, 0x00
00007ed4111d5cae  lea r9, [r15+0x3A8]
00007ed4111d5cb5  movaps [rdi], xmm9
00007ed4111d5cb9  movaps [rsi], xmm8
00007ed4111d5cbd  movaps [rdx], xmm14
00007ed4111d5cc1  movaps [rcx], xmm12
00007ed4111d5cc5  mov rax, 0x5CA8E4A55A50
00007ed4111d5ccf  call rax
00007ed4111d5cd1  movaps xmm9, [rsp]
00007ed4111d5cd6  add rsp, 0x40
00007ed4111d5cda  vmovaps xmm0, [rsp]
00007ed4111d5cdf  vmovaps xmm1, [rsp+0x10]
00007ed4111d5ce5  vmovaps xmm2, [rsp+0x20]
00007ed4111d5ceb  vmovaps xmm3, [rsp+0x30]
00007ed4111d5cf1  vmovaps xmm4, [rsp+0x40]
00007ed4111d5cf7  vmovaps xmm5, [rsp+0x50]
00007ed4111d5cfd  vmovaps xmm6, [rsp+0x60]
00007ed4111d5d03  vmovaps xmm7, [rsp+0x70]
00007ed4111d5d09  vmovaps xmm8, [rsp+0x80]
00007ed4111d5d12  vmovaps xmm10, [rsp+0x90]
00007ed4111d5d1b  vmovaps xmm11, [rsp+0xA0]
00007ed4111d5d24  vmovaps xmm12, [rsp+0xB0]
00007ed4111d5d2d  vmovaps xmm13, [rsp+0xC0]
00007ed4111d5d36  vmovaps xmm14, [rsp+0xD0]
00007ed4111d5d3f  vmovaps xmm15, [rsp+0xE0]
00007ed4111d5d48  add rsp, 0xF0
00007ed4111d5d4f  pop r11
00007ed4111d5d51  pop r10
00007ed4111d5d53  pop r9
00007ed4111d5d55  pop r8
00007ed4111d5d57  pop rsi
00007ed4111d5d58  pop rdi
00007ed4111d5d59  pop rdx
00007ed4111d5d5a  pop rcx
00007ed4111d5d5b  pop rax
00007ed4111d5d5c  add rsp, 0x08
00007ed4111d5d60  jmp 0x00007ED4111D3165
00007ed4111d5d65  sub rsp, 0x08
00007ed4111d5d69  push rax
00007ed4111d5d6a  push rcx
00007ed4111d5d6b  push rdx
00007ed4111d5d6c  push rdi
00007ed4111d5d6d  push rsi
00007ed4111d5d6e  push r8
00007ed4111d5d70  push r9
00007ed4111d5d72  push r10
00007ed4111d5d74  push r11
00007ed4111d5d76  sub rsp, 0xF0
00007ed4111d5d7d  vmovaps [rsp], xmm0
00007ed4111d5d82  vmovaps [rsp+0x10], xmm1
00007ed4111d5d88  vmovaps [rsp+0x20], xmm2
00007ed4111d5d8e  vmovaps [rsp+0x30], xmm3
00007ed4111d5d94  vmovaps [rsp+0x40], xmm4
00007ed4111d5d9a  vmovaps [rsp+0x50], xmm5
00007ed4111d5da0  vmovaps [rsp+0x60], xmm6
00007ed4111d5da6  vmovaps [rsp+0x70], xmm7
00007ed4111d5dac  vmovaps [rsp+0x80], xmm8
00007ed4111d5db5  vmovaps [rsp+0x90], xmm9
00007ed4111d5dbe  vmovaps [rsp+0xA0], xmm10
00007ed4111d5dc7  vmovaps [rsp+0xB0], xmm11
00007ed4111d5dd0  vmovaps [rsp+0xC0], xmm13
00007ed4111d5dd9  vmovaps [rsp+0xD0], xmm14
00007ed4111d5de2  vmovaps [rsp+0xE0], xmm15
00007ed4111d5deb  sub rsp, 0x40
00007ed4111d5def  lea rdi, [rsp]
00007ed4111d5df3  lea rsi, [rsp+0x10]
00007ed4111d5df8  lea rdx, [rsp+0x20]
00007ed4111d5dfd  lea rcx, [rsp+0x30]
00007ed4111d5e02  mov r8d, 0x00
00007ed4111d5e08  lea r9, [r15+0x3A8]
00007ed4111d5e0f  movaps [rdi], xmm12
00007ed4111d5e13  movaps [rsi], xmm10
00007ed4111d5e17  movaps [rdx], xmm15
00007ed4111d5e1b  movaps [rcx], xmm14
00007ed4111d5e1f  mov rax, 0x5CA8E4A55A50
00007ed4111d5e29  call rax
00007ed4111d5e2b  movaps xmm12, [rsp]
00007ed4111d5e30  add rsp, 0x40
00007ed4111d5e34  vmovaps xmm0, [rsp]
00007ed4111d5e39  vmovaps xmm1, [rsp+0x10]
00007ed4111d5e3f  vmovaps xmm2, [rsp+0x20]
00007ed4111d5e45  vmovaps xmm3, [rsp+0x30]
00007ed4111d5e4b  vmovaps xmm4, [rsp+0x40]
00007ed4111d5e51  vmovaps xmm5, [rsp+0x50]
00007ed4111d5e57  vmovaps xmm6, [rsp+0x60]
00007ed4111d5e5d  vmovaps xmm7, [rsp+0x70]
00007ed4111d5e63  vmovaps xmm8, [rsp+0x80]
00007ed4111d5e6c  vmovaps xmm9, [rsp+0x90]
00007ed4111d5e75  vmovaps xmm10, [rsp+0xA0]
00007ed4111d5e7e  vmovaps xmm11, [rsp+0xB0]
00007ed4111d5e87  vmovaps xmm13, [rsp+0xC0]
00007ed4111d5e90  vmovaps xmm14, [rsp+0xD0]
00007ed4111d5e99  vmovaps xmm15, [rsp+0xE0]
00007ed4111d5ea2  add rsp, 0xF0
00007ed4111d5ea9  pop r11
00007ed4111d5eab  pop r10
00007ed4111d5ead  pop r9
00007ed4111d5eaf  pop r8
00007ed4111d5eb1  pop rsi
00007ed4111d5eb2  pop rdi
00007ed4111d5eb3  pop rdx
00007ed4111d5eb4  pop rcx
00007ed4111d5eb5  pop rax
00007ed4111d5eb6  add rsp, 0x08
00007ed4111d5eba  jmp 0x00007ED4111D3196
00007ed4111d5ebf  sub rsp, 0x08
00007ed4111d5ec3  push rax
00007ed4111d5ec4  push rcx
00007ed4111d5ec5  push rdx
00007ed4111d5ec6  push rdi
00007ed4111d5ec7  push rsi
00007ed4111d5ec8  push r8
00007ed4111d5eca  push r9
00007ed4111d5ecc  push r10
00007ed4111d5ece  push r11
00007ed4111d5ed0  sub rsp, 0xF0
00007ed4111d5ed7  vmovaps [rsp], xmm0
00007ed4111d5edc  vmovaps [rsp+0x10], xmm1
00007ed4111d5ee2  vmovaps [rsp+0x20], xmm2
00007ed4111d5ee8  vmovaps [rsp+0x30], xmm3
00007ed4111d5eee  vmovaps [rsp+0x40], xmm4
00007ed4111d5ef4  vmovaps [rsp+0x50], xmm5
00007ed4111d5efa  vmovaps [rsp+0x60], xmm6
00007ed4111d5f00  vmovaps [rsp+0x70], xmm7
00007ed4111d5f06  vmovaps [rsp+0x80], xmm8
00007ed4111d5f0f  vmovaps [rsp+0x90], xmm9
00007ed4111d5f18  vmovaps [rsp+0xA0], xmm10
00007ed4111d5f21  vmovaps [rsp+0xB0], xmm11
00007ed4111d5f2a  vmovaps [rsp+0xC0], xmm12
00007ed4111d5f33  vmovaps [rsp+0xD0], xmm13
00007ed4111d5f3c  vmovaps [rsp+0xE0], xmm15
00007ed4111d5f45  sub rsp, 0x40
00007ed4111d5f49  lea rdi, [rsp]
00007ed4111d5f4d  lea rsi, [rsp+0x10]
00007ed4111d5f52  lea rdx, [rsp+0x20]
00007ed4111d5f57  lea rcx, [rsp+0x30]
00007ed4111d5f5c  mov r8d, 0x00
00007ed4111d5f62  lea r9, [r15+0x3A8]
00007ed4111d5f69  movaps [rdi], xmm14
00007ed4111d5f6d  movaps [rsi], xmm13
00007ed4111d5f71  movaps [rdx], xmm1
00007ed4111d5f74  movaps [rcx], xmm15
00007ed4111d5f78  mov rax, 0x5CA8E4A55A50
00007ed4111d5f82  call rax
00007ed4111d5f84  movaps xmm14, [rsp]
00007ed4111d5f89  add rsp, 0x40
00007ed4111d5f8d  vmovaps xmm0, [rsp]
00007ed4111d5f92  vmovaps xmm1, [rsp+0x10]
00007ed4111d5f98  vmovaps xmm2, [rsp+0x20]
00007ed4111d5f9e  vmovaps xmm3, [rsp+0x30]
00007ed4111d5fa4  vmovaps xmm4, [rsp+0x40]
00007ed4111d5faa  vmovaps xmm5, [rsp+0x50]
00007ed4111d5fb0  vmovaps xmm6, [rsp+0x60]
00007ed4111d5fb6  vmovaps xmm7, [rsp+0x70]
00007ed4111d5fbc  vmovaps xmm8, [rsp+0x80]
00007ed4111d5fc5  vmovaps xmm9, [rsp+0x90]
00007ed4111d5fce  vmovaps xmm10, [rsp+0xA0]
00007ed4111d5fd7  vmovaps xmm11, [rsp+0xB0]
00007ed4111d5fe0  vmovaps xmm12, [rsp+0xC0]
00007ed4111d5fe9  vmovaps xmm13, [rsp+0xD0]
00007ed4111d5ff2  vmovaps xmm15, [rsp+0xE0]
00007ed4111d5ffb  add rsp, 0xF0
00007ed4111d6002  pop r11
00007ed4111d6004  pop r10
00007ed4111d6006  pop r9
00007ed4111d6008  pop r8
00007ed4111d600a  pop rsi
00007ed4111d600b  pop rdi
00007ed4111d600c  pop rdx
00007ed4111d600d  pop rcx
00007ed4111d600e  pop rax
00007ed4111d600f  add rsp, 0x08
00007ed4111d6013  jmp 0x00007ED4111D31C7
00007ed4111d6018  call 0x00007ED4110079B0
00007ed4111d601d  jmp 0x00007ED4111D31DA
00007ed4111d6022  call 0x00007ED41100B100
00007ed4111d6027  jmp 0x00007ED4111D31E5
00007ed4111d602c  call 0x00007ED411009E90
00007ed4111d6031  jmp 0x00007ED4111D31F0
00007ed4111d6036  call 0x00007ED41100D600
00007ed4111d603b  jmp 0x00007ED4111D31FB
00007ed4111d6040  int3
00007ed4111d6041  nop [rax+rax*1], ax
00007ed4111d604a  nop [rax+rax*1], ax
00007ed4111d6050  mov rax, [r15+0x40]
00007ed4111d6054  mov r14, [r15+0x58]
00007ed4111d6058  lea r12, [rax+r14*1]
00007ed4111d605c  vxorps xmm1, xmm1, xmm1
00007ed4111d6060  vpbroadcastq xmm1, xmm1
00007ed4111d6065  vxorps xmm15, xmm15, xmm15
00007ed4111d606a  vpbroadcastq xmm15, xmm15
00007ed4111d606f  lea rax, [r12+0x30]
00007ed4111d6074  mov r11, [r13+rax*1]
00007ed4111d6079  lea rax, [r12+0x38]
00007ed4111d607e  mov r10, [r13+rax*1]
00007ed4111d6083  movq xmm14, r11
00007ed4111d6088  movq xmm13, r10
00007ed4111d608d  movq xmm14, xmm14
00007ed4111d6092  movq xmm13, xmm13
00007ed4111d6097  vmovaps [rsp+0x10], xmm13
00007ed4111d609d  movq xmm13, xmm13
00007ed4111d60a2  movaps [r15+0x270], xmm13
00007ed4111d60aa  movaps xmm13, [r15+0x160]
00007ed4111d60b2  vmovaps [rsp+0x20], xmm13
00007ed4111d60b8  vmovaps xmm12, [rsp+0x20]
00007ed4111d60be  por xmm13, xmm12
00007ed4111d60c3  lea rax, [r12+0x20]
00007ed4111d60c8  mov r11, [r13+rax*1]
00007ed4111d60cd  lea rax, [r12+0x28]
00007ed4111d60d2  mov r10, [r13+rax*1]
00007ed4111d60d7  movq xmm12, r11
00007ed4111d60dc  movq xmm11, r10
00007ed4111d60e1  movq xmm12, xmm12
00007ed4111d60e6  movq xmm11, xmm11
00007ed4111d60eb  movaps xmm10, [r15+0x2D0]
00007ed4111d60f3  vmovaps [rsp+0x20], xmm10
00007ed4111d60f9  vmovaps xmm9, [rsp+0x20]
00007ed4111d60ff  por xmm10, xmm9
00007ed4111d6104  movaps xmm9, [r15+0x300]
00007ed4111d610c  vmovaps [rsp+0x20], xmm9
00007ed4111d6112  vmovaps xmm8, [rsp+0x20]
00007ed4111d6118  por xmm9, xmm8
00007ed4111d611d  movaps xmm8, [r15+0x2B0]
00007ed4111d6125  vmovaps [rsp+0x20], xmm8
00007ed4111d612b  vmovaps xmm7, [rsp+0x20]
00007ed4111d6131  por xmm8, xmm7
00007ed4111d6136  movaps xmm7, [r15+0x180]
00007ed4111d613e  vmovaps [rsp+0x20], xmm7
00007ed4111d6144  vmovaps xmm6, [rsp+0x20]
00007ed4111d614a  por xmm7, xmm6
00007ed4111d614e  lea rax, [r12+0x10]
00007ed4111d6153  mov r11, [r13+rax*1]
00007ed4111d6158  lea rax, [r12+0x18]
00007ed4111d615d  mov r10, [r13+rax*1]
00007ed4111d6162  movq xmm6, r11
00007ed4111d6167  movq xmm5, r10
00007ed4111d616c  movq xmm6, xmm6
00007ed4111d6170  movq xmm5, xmm5
00007ed4111d6174  movaps xmm4, [r15+0x200]
00007ed4111d617c  vmovaps [rsp+0x20], xmm4
00007ed4111d6182  vmovaps xmm3, [rsp+0x20]
00007ed4111d6188  por xmm4, xmm3
00007ed4111d618c  movaps xmm3, [r15+0x1F0]
00007ed4111d6194  vmovaps [rsp+0x20], xmm3
00007ed4111d619a  vmovaps xmm2, [rsp+0x20]
00007ed4111d61a0  por xmm3, xmm2
00007ed4111d61a4  movaps xmm2, [r15+0x2E0]
00007ed4111d61ac  vmovaps [rsp+0x20], xmm2
00007ed4111d61b2  vmovaps [rsp+0x30], xmm1
00007ed4111d61b8  vmovaps xmm1, [rsp+0x20]
00007ed4111d61be  por xmm2, xmm1
00007ed4111d61c2  movaps xmm1, [r15+0x2A0]
00007ed4111d61ca  vmovaps [rsp+0x20], xmm1
00007ed4111d61d0  vmovaps [rsp+0x40], xmm15
00007ed4111d61d6  vmovaps xmm15, [rsp+0x20]
00007ed4111d61dc  por xmm1, xmm15
00007ed4111d61e1  movaps xmm15, [r15+0x280]
00007ed4111d61e9  vmovaps [rsp+0x20], xmm15
00007ed4111d61ef  vmovaps [rsp+0x50], xmm1
00007ed4111d61f5  vmovaps xmm1, [rsp+0x20]
00007ed4111d61fb  por xmm15, xmm1
00007ed4111d6200  movaps xmm1, [r15+0x1C0]
00007ed4111d6208  vmovaps [rsp+0x20], xmm1
00007ed4111d620e  vmovaps [rsp+0x60], xmm15
00007ed4111d6214  vmovaps xmm15, [rsp+0x20]
00007ed4111d621a  por xmm1, xmm15
00007ed4111d621f  movaps xmm15, [r15+0x210]
00007ed4111d6227  vmovaps [rsp+0x20], xmm15
00007ed4111d622d  vmovaps [rsp+0x70], xmm1
00007ed4111d6233  vmovaps xmm1, [rsp+0x20]
00007ed4111d6239  por xmm15, xmm1
00007ed4111d623e  mov rax, [r13+r12*1]
00007ed4111d6243  vmovq xmm1, rax
00007ed4111d6248  vpbroadcastq xmm1, xmm1
00007ed4111d624d  vmovaps [rsp+0x20], xmm1
00007ed4111d6253  vxorps xmm1, xmm1, xmm1
00007ed4111d6257  vpbroadcastq xmm1, xmm1
00007ed4111d625c  mov rax, [r15+0xF8]
00007ed4111d6263  vmovaps [rsp+0x80], xmm1
00007ed4111d626c  movups xmm1, [r13+rax*1]
00007ed4111d6272  vmovaps [rsp+0x90], xmm1
00007ed4111d627b  vxorps xmm1, xmm1, xmm1
00007ed4111d627f  vpbroadcastq xmm1, xmm1
00007ed4111d6284  lea r11, [r12+0x08]
00007ed4111d6289  mov r12, [r13+r11*1]
00007ed4111d628e  vmovaps [rsp+0xA0], xmm1
00007ed4111d6297  movq xmm1, r12
00007ed4111d629c  movaps [r15+0x240], xmm1
00007ed4111d62a4  mov r12, [r15+0x50]
00007ed4111d62a8  lea r11, [r12+r14*1]
00007ed4111d62ac  mov [r15+0x60], r11
00007ed4111d62b0  lea r12, [r14+0x40]
00007ed4111d62b4  mov [r15+0x58], r12
00007ed4111d62b8  vmovaps xmm1, [rsp+0x30]
00007ed4111d62be  vmovaps [rsp+0x30], xmm15
00007ed4111d62c4  vmovaps xmm15, [rsp+0x90]
00007ed4111d62cd  vmovaps [rsp+0x90], xmm14
00007ed4111d62d6  vmovaps xmm14, [rsp+0x20]
00007ed4111d62dc  vmovaps [rsp+0x20], xmm13
00007ed4111d62e2  vmovaps [rsp+0xB0], xmm12
00007ed4111d62eb  movaps xmm13, xmm1
00007ed4111d62ef  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d62fa  vptest xmm12, xmm12
00007ed4111d62ff  jnz 0x00007ED4111D6D9C
00007ed4111d6305  movaps xmm1, [r15+0x250]
00007ed4111d630d  vmovaps xmm15, [rsp+0x40]
00007ed4111d6313  vmovaps [rsp+0x40], xmm13
00007ed4111d6319  movaps xmm12, xmm15
00007ed4111d631d  vfmadd231pd xmm12, xmm1, xmm14
00007ed4111d6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007ed4111d6328  vptest xmm13, xmm13
00007ed4111d632d  jnz 0x00007ED4111D6EF5
00007ed4111d6333  movaps xmm15, [r15+0x1E0]
00007ed4111d633b  vmovaps [rsp+0xC0], xmm15
00007ed4111d6344  vmovaps xmm13, [rsp+0xC0]
00007ed4111d634d  por xmm15, xmm13
00007ed4111d6352  movaps xmm13, [r15+0x1D0]
00007ed4111d635a  vmovaps [rsp+0xC0], xmm13
00007ed4111d6363  vmovaps [rsp+0xD0], xmm1
00007ed4111d636c  vmovaps xmm1, [rsp+0xC0]
00007ed4111d6375  por xmm13, xmm1
00007ed4111d637a  movaps xmm1, [r15+0x2C0]
00007ed4111d6382  vmovaps [rsp+0xC0], xmm1
00007ed4111d638b  vmovaps [rsp+0xE0], xmm15
00007ed4111d6394  vmovaps xmm15, [rsp+0xC0]
00007ed4111d639d  por xmm1, xmm15
00007ed4111d63a2  movaps xmm15, [r15+0x290]
00007ed4111d63aa  vmovaps [rsp+0xC0], xmm15
00007ed4111d63b3  vmovaps [rsp+0xF0], xmm1
00007ed4111d63bc  vmovaps xmm1, [rsp+0xC0]
00007ed4111d63c5  por xmm15, xmm1
00007ed4111d63ca  movaps xmm1, [r15+0x260]
00007ed4111d63d2  vmovaps [rsp+0xC0], xmm1
00007ed4111d63db  vmovaps [rsp+0x100], xmm15
00007ed4111d63e4  vmovaps xmm15, [rsp+0xC0]
00007ed4111d63ed  por xmm1, xmm15
00007ed4111d63f2  vmovaps xmm15, [rsp+0xD0]
00007ed4111d63fb  vmovaps [rsp+0xC0], xmm1
00007ed4111d6404  vmovaps xmm1, [rsp+0xD0]
00007ed4111d640d  por xmm15, xmm1
00007ed4111d6412  lea r14, [rax+0xC0]
00007ed4111d6419  movups xmm1, [r13+r14*1]
00007ed4111d641f  mov [rsp+0xD0], rax
00007ed4111d6427  xor eax, eax
00007ed4111d6429  mov r14d, 0x200
00007ed4111d642f  cmp r12, r14
00007ed4111d6432  cmc
00007ed4111d6433  lahf
00007ed4111d6434  seto al
00007ed4111d6437  mov [r15+0x108], eax
00007ed4111d643e  vmovaps [rsp+0x110], xmm1
00007ed4111d6447  vmovaps xmm1, [rsp+0x80]
00007ed4111d6450  vmovaps [rsp+0x80], xmm15
00007ed4111d6459  vmovaps xmm15, [rsp+0x110]
00007ed4111d6462  vmovaps [rsp+0x110], xmm13
00007ed4111d646b  vmovaps [rsp+0x120], xmm12
00007ed4111d6474  movaps xmm13, xmm1
00007ed4111d6478  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d6483  vptest xmm12, xmm12
00007ed4111d6488  jnz 0x00007ED4111D7058
00007ed4111d648e  mov rax, [rsp+0xD0]
00007ed4111d6496  lea r14, [rax+0xB0]
00007ed4111d649d  movups xmm1, [r13+r14*1]
00007ed4111d64a3  vmovaps xmm15, [rsp+0xA0]
00007ed4111d64ac  vmovaps [rsp+0xA0], xmm13
00007ed4111d64b5  movaps xmm12, xmm15
00007ed4111d64b9  vfmadd231pd xmm12, xmm1, xmm14
00007ed4111d64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007ed4111d64c4  vptest xmm13, xmm13
00007ed4111d64c9  jnz 0x00007ED4111D71BB
00007ed4111d64cf  vmovaps xmm1, [rsp+0x30]
00007ed4111d64d5  vmovaps xmm15, [rsp+0x30]
00007ed4111d64db  por xmm1, xmm15
00007ed4111d64e0  movaps [r15+0x210], xmm1
00007ed4111d64e8  vmovaps xmm15, [rsp+0x70]
00007ed4111d64ee  vmovaps xmm14, [rsp+0x70]
00007ed4111d64f4  por xmm15, xmm14
00007ed4111d64f9  movaps [r15+0x1C0], xmm15
00007ed4111d6501  vmovaps xmm14, [rsp+0x60]
00007ed4111d6507  vmovaps xmm13, [rsp+0x60]
00007ed4111d650d  por xmm14, xmm13
00007ed4111d6512  movaps [r15+0x280], xmm14
00007ed4111d651a  vmovaps xmm13, [rsp+0x50]
00007ed4111d6520  vmovaps [rsp+0x30], xmm1
00007ed4111d6526  vmovaps xmm1, [rsp+0x50]
00007ed4111d652c  por xmm13, xmm1
00007ed4111d6531  movaps [r15+0x2A0], xmm13
00007ed4111d6539  vmovaps [rsp+0x50], xmm2
00007ed4111d653f  vmovaps xmm1, [rsp+0x50]
00007ed4111d6545  por xmm2, xmm1
00007ed4111d6549  movaps [r15+0x2E0], xmm2
00007ed4111d6551  vmovaps [rsp+0x50], xmm3
00007ed4111d6557  vmovaps xmm1, [rsp+0x50]
00007ed4111d655d  por xmm3, xmm1
00007ed4111d6561  movaps [r15+0x1F0], xmm3
00007ed4111d6569  vmovaps xmm1, [rsp+0x80]
00007ed4111d6572  vmovaps [rsp+0x50], xmm15
00007ed4111d6578  vmovaps xmm15, [rsp+0x80]
00007ed4111d6581  por xmm1, xmm15
00007ed4111d6586  movaps [r15+0x250], xmm1
00007ed4111d658e  vmovaps xmm1, [rsp+0xC0]
00007ed4111d6597  vmovaps xmm15, [rsp+0xC0]
00007ed4111d65a0  por xmm1, xmm15
00007ed4111d65a5  movaps [r15+0x260], xmm1
00007ed4111d65ad  vmovaps xmm15, [rsp+0x100]
00007ed4111d65b6  vmovaps [rsp+0x60], xmm1
00007ed4111d65bc  vmovaps xmm1, [rsp+0x100]
00007ed4111d65c5  por xmm15, xmm1
00007ed4111d65ca  movaps [r15+0x290], xmm15
00007ed4111d65d2  vmovaps xmm1, [rsp+0xF0]
00007ed4111d65db  vmovaps [rsp+0x70], xmm15
00007ed4111d65e1  vmovaps xmm15, [rsp+0xF0]
00007ed4111d65ea  por xmm1, xmm15
00007ed4111d65ef  movaps [r15+0x2C0], xmm1
00007ed4111d65f7  movq xmm15, qword ptr [r15+0x240]
00007ed4111d6600  vmovaps [rsp+0x80], xmm15
00007ed4111d6609  vpermilpd xmm15, xmm15, 0x00
00007ed4111d660f  vmovaps [rsp+0xC0], xmm1
00007ed4111d6618  vmovaps xmm1, [rsp+0x40]
00007ed4111d661e  vmovaps [rsp+0x40], xmm15
00007ed4111d6624  vmovaps xmm15, [rsp+0x30]
00007ed4111d662a  vmovaps [rsp+0x30], xmm14
00007ed4111d6630  vmovaps xmm14, [rsp+0x40]
00007ed4111d6636  vmovaps [rsp+0x40], xmm13
00007ed4111d663c  vmovaps [rsp+0xD0], xmm12
00007ed4111d6645  movaps xmm13, xmm1
00007ed4111d6649  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d6654  vptest xmm12, xmm12
00007ed4111d6659  jnz 0x00007ED4111D7314
00007ed4111d665f  vmovaps xmm1, [rsp+0x80]
00007ed4111d6668  vpermilpd xmm1, xmm1, 0x00
00007ed4111d666e  vmovaps xmm15, [rsp+0xA0]
00007ed4111d6677  movaps xmm14, xmm15
00007ed4111d667b  vfmadd231pd xmm14, xmm2, xmm1
00007ed4111d6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007ed4111d6686  vptest xmm12, xmm12
00007ed4111d668b  jnz 0x00007ED4111D746D
00007ed4111d6691  vmovaps xmm1, [rsp+0x80]
00007ed4111d669a  vpermilpd xmm1, xmm1, 0x00
00007ed4111d66a0  vmovaps xmm15, [rsp+0x120]
00007ed4111d66a9  vmovaps xmm12, [rsp+0x50]
00007ed4111d66af  vmovaps [rsp+0x50], xmm14
00007ed4111d66b5  movaps xmm2, xmm15
00007ed4111d66b9  vfmadd231pd xmm2, xmm12, xmm1
00007ed4111d66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007ed4111d66c3  vptest xmm14, xmm14
00007ed4111d66c8  jnz 0x00007ED4111D75C5
00007ed4111d66ce  vmovaps xmm1, [rsp+0x110]
00007ed4111d66d7  vmovaps xmm15, [rsp+0x110]
00007ed4111d66e0  por xmm1, xmm15
00007ed4111d66e5  movaps [r15+0x1D0], xmm1
00007ed4111d66ed  vmovaps xmm15, [rsp+0x80]
00007ed4111d66f6  vpermilpd xmm15, xmm15, 0x00
00007ed4111d66fc  vmovaps xmm14, [rsp+0xD0]
00007ed4111d6705  vmovaps [rsp+0x80], xmm1
00007ed4111d670e  movaps xmm12, xmm14
00007ed4111d6712  vfmadd231pd xmm12, xmm3, xmm15
00007ed4111d6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007ed4111d671d  vptest xmm1, xmm1
00007ed4111d6722  jnz 0x00007ED4111D771C
00007ed4111d6728  vmovaps [rsp+0xA0], xmm4
00007ed4111d6731  vmovaps xmm1, [rsp+0xA0]
00007ed4111d673a  por xmm4, xmm1
00007ed4111d673e  movaps [r15+0x200], xmm4
00007ed4111d6746  vmovaps xmm1, [rsp+0xE0]
00007ed4111d674f  vmovaps xmm15, [rsp+0xE0]
00007ed4111d6758  por xmm1, xmm15
00007ed4111d675d  movaps [r15+0x1E0], xmm1
00007ed4111d6765  vmovaps [rsp+0xA0], xmm8
00007ed4111d676e  vmovaps xmm1, [rsp+0xA0]
00007ed4111d6777  por xmm8, xmm1
00007ed4111d677c  movaps [r15+0x2B0], xmm8
00007ed4111d6784  vmovaps [rsp+0xA0], xmm9
00007ed4111d678d  vmovaps xmm1, [rsp+0xA0]
00007ed4111d6796  por xmm9, xmm1
00007ed4111d679b  movaps [r15+0x300], xmm9
00007ed4111d67a3  vmovaps [rsp+0xA0], xmm6
00007ed4111d67ac  vpermilpd xmm6, xmm6, 0x00
00007ed4111d67b2  vmovaps xmm14, [rsp+0x60]
00007ed4111d67b8  movaps xmm9, xmm13
00007ed4111d67bc  vfmadd231pd xmm9, xmm14, xmm6
00007ed4111d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007ed4111d67c7  vptest xmm3, xmm3
00007ed4111d67cc  jnz 0x00007ED4111D7875
00007ed4111d67d2  vmovaps xmm14, [rsp+0xA0]
00007ed4111d67db  vpermilpd xmm14, xmm14, 0x00
00007ed4111d67e1  vmovaps xmm13, [rsp+0x50]
00007ed4111d67e7  vmovaps xmm6, [rsp+0xC0]
00007ed4111d67f0  vmovaps [rsp+0x50], xmm1
00007ed4111d67f6  movaps xmm3, xmm13
00007ed4111d67fa  vfmadd231pd xmm3, xmm6, xmm14
00007ed4111d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007ed4111d6804  vptest xmm1, xmm1
00007ed4111d6809  jnz 0x00007ED4111D79CE
00007ed4111d680f  vmovaps xmm1, [rsp+0xA0]
00007ed4111d6818  vpermilpd xmm1, xmm1, 0x00
00007ed4111d681e  vmovaps xmm14, [rsp+0x30]
00007ed4111d6824  movaps xmm6, xmm2
00007ed4111d6827  vfmadd231pd xmm6, xmm14, xmm1
00007ed4111d682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007ed4111d6831  vptest xmm13, xmm13
00007ed4111d6836  jnz 0x00007ED4111D7B25
00007ed4111d683c  vmovaps xmm1, [rsp+0xA0]
00007ed4111d6845  vpermilpd xmm1, xmm1, 0x00
00007ed4111d684b  vmovaps xmm14, [rsp+0x80]
00007ed4111d6854  movaps xmm13, xmm12
00007ed4111d6858  vfmadd231pd xmm13, xmm14, xmm1
00007ed4111d685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007ed4111d6863  vptest xmm2, xmm2
00007ed4111d6868  jnz 0x00007ED4111D7C7B
00007ed4111d686e  vmovaps [rsp+0x30], xmm7
00007ed4111d6874  vmovaps xmm1, [rsp+0x30]
00007ed4111d687a  por xmm7, xmm1
00007ed4111d687e  movaps [r15+0x180], xmm7
00007ed4111d6886  vmovaps [rsp+0x30], xmm10
00007ed4111d688c  vmovaps xmm1, [rsp+0x30]
00007ed4111d6892  por xmm10, xmm1
00007ed4111d6897  movaps [r15+0x2D0], xmm10
00007ed4111d689f  vmovaps [rsp+0x30], xmm5
00007ed4111d68a5  vpermilpd xmm5, xmm5, 0x00
00007ed4111d68ab  vmovaps xmm14, [rsp+0x50]
00007ed4111d68b1  movaps xmm12, xmm3
00007ed4111d68b5  vfmadd231pd xmm12, xmm14, xmm5
00007ed4111d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007ed4111d68c0  vptest xmm10, xmm10
00007ed4111d68c5  jnz 0x00007ED4111D7DD4
00007ed4111d68cb  vmovaps xmm14, [rsp+0x30]
00007ed4111d68d1  vpermilpd xmm14, xmm14, 0x00
00007ed4111d68d7  movaps xmm10, xmm9
00007ed4111d68db  vfmadd231pd xmm10, xmm7, xmm14
00007ed4111d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007ed4111d68e6  vptest xmm5, xmm5
00007ed4111d68eb  jnz 0x00007ED4111D7F2C
00007ed4111d68f1  lea r14, [rax+0x80]
00007ed4111d68f8  movups xmm14, [r13+r14*1]
00007ed4111d68fe  movaps [r15+0x2F0], xmm14
00007ed4111d6906  vmovaps xmm9, [rsp+0x30]
00007ed4111d690c  vpermilpd xmm9, xmm9, 0x00
00007ed4111d6912  vmovaps xmm7, [rsp+0x70]
00007ed4111d6918  movaps xmm5, xmm6
00007ed4111d691b  vfmadd231pd xmm5, xmm7, xmm9
00007ed4111d6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007ed4111d6925  vptest xmm3, xmm3
00007ed4111d692a  jnz 0x00007ED4111D808F
00007ed4111d6930  vmovaps xmm9, [rsp+0x30]
00007ed4111d6936  vpermilpd xmm9, xmm9, 0x00
00007ed4111d693c  movaps xmm7, xmm13
00007ed4111d6940  vfmadd231pd xmm7, xmm1, xmm9
00007ed4111d6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007ed4111d694a  vptest xmm6, xmm6
00007ed4111d694f  jnz 0x00007ED4111D81E5
00007ed4111d6955  vmovaps xmm1, [rsp+0x20]
00007ed4111d695b  vmovaps xmm13, [rsp+0x20]
00007ed4111d6961  por xmm1, xmm13
00007ed4111d6966  movaps [r15+0x160], xmm1
00007ed4111d696e  lea r14, [rax+0x40]
00007ed4111d6972  movups xmm13, [r13+r14*1]
00007ed4111d6978  lea r14, [rax+0x50]
00007ed4111d697c  movups xmm9, [r13+r14*1]
00007ed4111d6982  movaps [r15+0x1B0], xmm13
00007ed4111d698a  movaps [r15+0x1A0], xmm9
00007ed4111d6992  movaps xmm6, [r15+0x190]
00007ed4111d699a  vmovaps xmm3, [rsp+0xB0]
00007ed4111d69a3  vpermilpd xmm3, xmm3, 0x00
00007ed4111d69a9  vmovaps [rsp+0x20], xmm1
00007ed4111d69af  movaps xmm2, xmm12
00007ed4111d69b3  vfmadd231pd xmm2, xmm6, xmm3
00007ed4111d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007ed4111d69bd  vptest xmm1, xmm1
00007ed4111d69c2  jnz 0x00007ED4111D8350
00007ed4111d69c8  vmovaps xmm1, [rsp+0xB0]
00007ed4111d69d1  vpermilpd xmm1, xmm1, 0x00
00007ed4111d69d7  vmovaps xmm12, [rsp+0x20]
00007ed4111d69dd  movaps xmm6, xmm10
00007ed4111d69e1  vfmadd231pd xmm6, xmm12, xmm1
00007ed4111d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007ed4111d69eb  vptest xmm3, xmm3
00007ed4111d69f0  jnz 0x00007ED4111D84A6
00007ed4111d69f6  vmovaps xmm1, [rsp+0xB0]
00007ed4111d69ff  vpermilpd xmm1, xmm1, 0x00
00007ed4111d6a05  vmovaps xmm12, [rsp+0x40]
00007ed4111d6a0b  movaps xmm10, xmm5
00007ed4111d6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007ed4111d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007ed4111d6a1a  vptest xmm3, xmm3
00007ed4111d6a1f  jnz 0x00007ED4111D85FD
00007ed4111d6a25  vmovaps xmm1, [rsp+0xB0]
00007ed4111d6a2e  vpermilpd xmm1, xmm1, 0x00
00007ed4111d6a34  movaps xmm12, xmm7
00007ed4111d6a38  vfmadd231pd xmm12, xmm15, xmm1
00007ed4111d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007ed4111d6a43  vptest xmm5, xmm5
00007ed4111d6a48  jnz 0x00007ED4111D8755
00007ed4111d6a4e  lea r14, [rax+0x60]
00007ed4111d6a52  movups xmm1, [r13+r14*1]
00007ed4111d6a58  lea r14, [rax+0x70]
00007ed4111d6a5c  movups xmm15, [r13+r14*1]
00007ed4111d6a62  movaps [r15+0x150], xmm1
00007ed4111d6a6a  movaps [r15+0x120], xmm15
00007ed4111d6a72  vmovaps [rsp+0x20], xmm11
00007ed4111d6a78  vpermilpd xmm11, xmm11, 0x00
00007ed4111d6a7e  movaps xmm7, xmm2
00007ed4111d6a81  vfmadd231pd xmm7, xmm9, xmm11
00007ed4111d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007ed4111d6a8b  vptest xmm5, xmm5
00007ed4111d6a90  jnz 0x00007ED4111D88C1
00007ed4111d6a96  vmovaps xmm11, [rsp+0x20]
00007ed4111d6a9c  vpermilpd xmm11, xmm11, 0x00
00007ed4111d6aa2  movaps xmm9, xmm6
00007ed4111d6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007ed4111d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007ed4111d6ab1  vptest xmm5, xmm5
00007ed4111d6ab6  jnz 0x00007ED4111D8A18
00007ed4111d6abc  vmovaps xmm1, [rsp+0x20]
00007ed4111d6ac2  vpermilpd xmm1, xmm1, 0x00
00007ed4111d6ac8  movaps xmm11, xmm10
00007ed4111d6acc  vfmadd231pd xmm11, xmm8, xmm1
00007ed4111d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007ed4111d6ad7  vptest xmm6, xmm6
00007ed4111d6adc  jnz 0x00007ED4111D8B70
00007ed4111d6ae2  vmovaps xmm1, [rsp+0x20]
00007ed4111d6ae8  vpermilpd xmm1, xmm1, 0x00
00007ed4111d6aee  movaps xmm10, xmm12
00007ed4111d6af2  vfmadd231pd xmm10, xmm13, xmm1
00007ed4111d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007ed4111d6afd  vptest xmm8, xmm8
00007ed4111d6b02  jnz 0x00007ED4111D8CC9
00007ed4111d6b08  lea r14, [rax+0x20]
00007ed4111d6b0c  movups xmm1, [r13+r14*1]
00007ed4111d6b12  lea r14, [rax+0x30]
00007ed4111d6b16  movups xmm13, [r13+r14*1]
00007ed4111d6b1c  vmovaps xmm12, [rsp+0x90]
00007ed4111d6b25  vpermilpd xmm12, xmm12, 0x00
00007ed4111d6b2b  movaps xmm8, xmm7
00007ed4111d6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007ed4111d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007ed4111d6b3a  vptest xmm6, xmm6
00007ed4111d6b3f  jnz 0x00007ED4111D8E36
00007ed4111d6b45  vmovaps xmm12, [rsp+0x90]
00007ed4111d6b4e  vpermilpd xmm12, xmm12, 0x00
00007ed4111d6b54  movaps xmm7, xmm9
00007ed4111d6b58  vfmadd231pd xmm7, xmm14, xmm12
00007ed4111d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007ed4111d6b62  vptest xmm6, xmm6
00007ed4111d6b67  jnz 0x00007ED4111D8F8E
00007ed4111d6b6d  vmovaps xmm14, [rsp+0x90]
00007ed4111d6b76  vpermilpd xmm14, xmm14, 0x00
00007ed4111d6b7c  movaps xmm12, xmm11
00007ed4111d6b80  vfmadd231pd xmm12, xmm15, xmm14
00007ed4111d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007ed4111d6b8b  vptest xmm9, xmm9
00007ed4111d6b90  jnz 0x00007ED4111D90E6
00007ed4111d6b96  vmovaps xmm15, [rsp+0x90]
00007ed4111d6b9f  vpermilpd xmm15, xmm15, 0x00
00007ed4111d6ba5  movaps xmm11, xmm10
00007ed4111d6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007ed4111d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007ed4111d6bb4  vptest xmm14, xmm14
00007ed4111d6bb9  jnz 0x00007ED4111D9240
00007ed4111d6bbf  lea r14, [rax+0x90]
00007ed4111d6bc6  movups xmm15, [r13+r14*1]
00007ed4111d6bcc  lea r14, [rax+0xA0]
00007ed4111d6bd3  movups xmm14, [r13+r14*1]
00007ed4111d6bd9  movaps [r15+0x140], xmm15
00007ed4111d6be1  movaps [r15+0x130], xmm14
00007ed4111d6be9  vmovaps xmm13, [rsp+0x10]
00007ed4111d6bef  vpermilpd xmm13, xmm13, 0x00
00007ed4111d6bf5  movaps xmm10, xmm8
00007ed4111d6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007ed4111d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007ed4111d6c04  vptest xmm9, xmm9
00007ed4111d6c09  jnz 0x00007ED4111D93AE
00007ed4111d6c0f  movaps [r15+0x220], xmm10
00007ed4111d6c17  lea r14, [rax+0x10]
00007ed4111d6c1b  movups xmm1, [r13+r14*1]
00007ed4111d6c21  movaps [r15+0x240], xmm1
00007ed4111d6c29  vmovaps xmm13, [rsp+0x10]
00007ed4111d6c2f  vpermilpd xmm13, xmm13, 0x00
00007ed4111d6c35  movaps xmm9, xmm7
00007ed4111d6c39  vfmadd231pd xmm9, xmm14, xmm13
00007ed4111d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007ed4111d6c44  vptest xmm8, xmm8
00007ed4111d6c49  jnz 0x00007ED4111D9511
00007ed4111d6c4f  movaps [r15+0x110], xmm9
00007ed4111d6c57  vmovaps xmm14, [rsp+0x10]
00007ed4111d6c5d  vpermilpd xmm14, xmm14, 0x00
00007ed4111d6c63  movaps xmm13, xmm12
00007ed4111d6c67  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007ed4111d6c72  vptest xmm8, xmm8
00007ed4111d6c77  jnz 0x00007ED4111D966A
00007ed4111d6c7d  movaps [r15+0x170], xmm13
00007ed4111d6c85  vmovaps xmm15, [rsp+0x10]
00007ed4111d6c8b  vpermilpd xmm15, xmm15, 0x00
00007ed4111d6c91  movaps xmm14, xmm11
00007ed4111d6c95  vfmadd231pd xmm14, xmm1, xmm15
00007ed4111d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007ed4111d6ca0  vptest xmm12, xmm12
00007ed4111d6ca5  jnz 0x00007ED4111D97C4
00007ed4111d6cab  movaps [r15+0x230], xmm14
00007ed4111d6cb3  movups [r13+r11*1], xmm9
00007ed4111d6cb9  lea rax, [r11+0x10]
00007ed4111d6cbd  movups [r13+rax*1], xmm13
00007ed4111d6cc3  lea rax, [r11+0x20]
00007ed4111d6cc7  movups [r13+rax*1], xmm10
00007ed4111d6ccd  lea rax, [r11+0x30]
00007ed4111d6cd1  movups [r13+rax*1], xmm14
00007ed4111d6cd7  mov eax, [r15+0x108]
00007ed4111d6cde  sahf
00007ed4111d6cdf  jnz 0x00007ED4111D6D11
00007ed4111d6ce1  cmp dword ptr [r15+0x318], 0x00
00007ed4111d6ce9  jz 0x00007ED4111D9950
00007ed4111d6cef  nop [rax+rax*1], ax
00007ed4111d6cf8  nop [rax+rax*1], eax
00007ed4111d6d00  mov eax, 0x410664
00007ed4111d6d05  mov [r15+0x100], rax
00007ed4111d6d0c  jmp 0x00007ED410FFE110
00007ed4111d6d11  cmp dword ptr [r15+0x318], 0x00
00007ed4111d6d19  jz 0x00007ED4111D6050
00007ed4111d6d1f  nop [rax+rax*1], ax
00007ed4111d6d28  nop [rax+rax*1], eax
00007ed4111d6d30  mov eax, 0x4104F0
00007ed4111d6d35  mov [r15+0x100], rax
00007ed4111d6d3c  jmp 0x00007ED410FFE110
00007ed4111d6d41  int3
00007ed4111d6d42  call 0x00007ED41100A4B0
00007ed4111d6d47  jmp 0x00007ED4111D6079
00007ed4111d6d4c  call 0x00007ED411009240
00007ed4111d6d51  jmp 0x00007ED4111D6083
00007ed4111d6d56  call 0x00007ED41100A4B0
00007ed4111d6d5b  jmp 0x00007ED4111D60CD
00007ed4111d6d60  call 0x00007ED411009240
00007ed4111d6d65  jmp 0x00007ED4111D60D7
00007ed4111d6d6a  call 0x00007ED41100A4B0
00007ed4111d6d6f  jmp 0x00007ED4111D6158
00007ed4111d6d74  call 0x00007ED411009240
00007ed4111d6d79  jmp 0x00007ED4111D6162
00007ed4111d6d7e  call 0x00007ED4110B47C0
00007ed4111d6d83  jmp 0x00007ED4111D6243
00007ed4111d6d88  call 0x00007ED410FFF430
00007ed4111d6d8d  jmp 0x00007ED4111D6272
00007ed4111d6d92  call 0x00007ED4110B0CE0
00007ed4111d6d97  jmp 0x00007ED4111D628E
00007ed4111d6d9c  sub rsp, 0x08
00007ed4111d6da0  push rax
00007ed4111d6da1  push rcx
00007ed4111d6da2  push rdx
00007ed4111d6da3  push rdi
00007ed4111d6da4  push rsi
00007ed4111d6da5  push r8
00007ed4111d6da7  push r9
00007ed4111d6da9  push r10
00007ed4111d6dab  push r11
00007ed4111d6dad  sub rsp, 0xF0
00007ed4111d6db4  vmovaps [rsp], xmm0
00007ed4111d6db9  vmovaps [rsp+0x10], xmm1
00007ed4111d6dbf  vmovaps [rsp+0x20], xmm2
00007ed4111d6dc5  vmovaps [rsp+0x30], xmm3
00007ed4111d6dcb  vmovaps [rsp+0x40], xmm4
00007ed4111d6dd1  vmovaps [rsp+0x50], xmm5
00007ed4111d6dd7  vmovaps [rsp+0x60], xmm6
00007ed4111d6ddd  vmovaps [rsp+0x70], xmm7
00007ed4111d6de3  vmovaps [rsp+0x80], xmm8
00007ed4111d6dec  vmovaps [rsp+0x90], xmm9
00007ed4111d6df5  vmovaps [rsp+0xA0], xmm10
00007ed4111d6dfe  vmovaps [rsp+0xB0], xmm11
00007ed4111d6e07  vmovaps [rsp+0xC0], xmm12
00007ed4111d6e10  vmovaps [rsp+0xD0], xmm14
00007ed4111d6e19  vmovaps [rsp+0xE0], xmm15
00007ed4111d6e22  sub rsp, 0x40
00007ed4111d6e26  lea rdi, [rsp]
00007ed4111d6e2a  lea rsi, [rsp+0x10]
00007ed4111d6e2f  lea rdx, [rsp+0x20]
00007ed4111d6e34  lea rcx, [rsp+0x30]
00007ed4111d6e39  mov r8d, 0x00
00007ed4111d6e3f  lea r9, [r15+0x3A8]
00007ed4111d6e46  movaps [rdi], xmm13
00007ed4111d6e4a  movaps [rsi], xmm1
00007ed4111d6e4d  movaps [rdx], xmm15
00007ed4111d6e51  movaps [rcx], xmm14
00007ed4111d6e55  mov rax, 0x5CA8E4A55A50
00007ed4111d6e5f  call rax
00007ed4111d6e61  movaps xmm13, [rsp]
00007ed4111d6e66  add rsp, 0x40
00007ed4111d6e6a  vmovaps xmm0, [rsp]
00007ed4111d6e6f  vmovaps xmm1, [rsp+0x10]
00007ed4111d6e75  vmovaps xmm2, [rsp+0x20]
00007ed4111d6e7b  vmovaps xmm3, [rsp+0x30]
00007ed4111d6e81  vmovaps xmm4, [rsp+0x40]
00007ed4111d6e87  vmovaps xmm5, [rsp+0x50]
00007ed4111d6e8d  vmovaps xmm6, [rsp+0x60]
00007ed4111d6e93  vmovaps xmm7, [rsp+0x70]
00007ed4111d6e99  vmovaps xmm8, [rsp+0x80]
00007ed4111d6ea2  vmovaps xmm9, [rsp+0x90]
00007ed4111d6eab  vmovaps xmm10, [rsp+0xA0]
00007ed4111d6eb4  vmovaps xmm11, [rsp+0xB0]
00007ed4111d6ebd  vmovaps xmm12, [rsp+0xC0]
00007ed4111d6ec6  vmovaps xmm14, [rsp+0xD0]
00007ed4111d6ecf  vmovaps xmm15, [rsp+0xE0]
00007ed4111d6ed8  add rsp, 0xF0
00007ed4111d6edf  pop r11
00007ed4111d6ee1  pop r10
00007ed4111d6ee3  pop r9
00007ed4111d6ee5  pop r8
00007ed4111d6ee7  pop rsi
00007ed4111d6ee8  pop rdi
00007ed4111d6ee9  pop rdx
00007ed4111d6eea  pop rcx
00007ed4111d6eeb  pop rax
00007ed4111d6eec  add rsp, 0x08
00007ed4111d6ef0  jmp 0x00007ED4111D6305
00007ed4111d6ef5  sub rsp, 0x08
00007ed4111d6ef9  push rax
00007ed4111d6efa  push rcx
00007ed4111d6efb  push rdx
00007ed4111d6efc  push rdi
00007ed4111d6efd  push rsi
00007ed4111d6efe  push r8
00007ed4111d6f00  push r9
00007ed4111d6f02  push r10
00007ed4111d6f04  push r11
00007ed4111d6f06  sub rsp, 0xF0
00007ed4111d6f0d  vmovaps [rsp], xmm0
00007ed4111d6f12  vmovaps [rsp+0x10], xmm1
00007ed4111d6f18  vmovaps [rsp+0x20], xmm2
00007ed4111d6f1e  vmovaps [rsp+0x30], xmm3
00007ed4111d6f24  vmovaps [rsp+0x40], xmm4
00007ed4111d6f2a  vmovaps [rsp+0x50], xmm5
00007ed4111d6f30  vmovaps [rsp+0x60], xmm6
00007ed4111d6f36  vmovaps [rsp+0x70], xmm7
00007ed4111d6f3c  vmovaps [rsp+0x80], xmm8
00007ed4111d6f45  vmovaps [rsp+0x90], xmm9
00007ed4111d6f4e  vmovaps [rsp+0xA0], xmm10
00007ed4111d6f57  vmovaps [rsp+0xB0], xmm11
00007ed4111d6f60  vmovaps [rsp+0xC0], xmm13
00007ed4111d6f69  vmovaps [rsp+0xD0], xmm14
00007ed4111d6f72  vmovaps [rsp+0xE0], xmm15
00007ed4111d6f7b  sub rsp, 0x40
00007ed4111d6f7f  lea rdi, [rsp]
00007ed4111d6f83  lea rsi, [rsp+0x10]
00007ed4111d6f88  lea rdx, [rsp+0x20]
00007ed4111d6f8d  lea rcx, [rsp+0x30]
00007ed4111d6f92  mov r8d, 0x00
00007ed4111d6f98  lea r9, [r15+0x3A8]
00007ed4111d6f9f  movaps [rdi], xmm12
00007ed4111d6fa3  movaps [rsi], xmm15
00007ed4111d6fa7  movaps [rdx], xmm1
00007ed4111d6faa  movaps [rcx], xmm14
00007ed4111d6fae  mov rax, 0x5CA8E4A55A50
00007ed4111d6fb8  call rax
00007ed4111d6fba  movaps xmm12, [rsp]
00007ed4111d6fbf  add rsp, 0x40
00007ed4111d6fc3  vmovaps xmm0, [rsp]
00007ed4111d6fc8  vmovaps xmm1, [rsp+0x10]
00007ed4111d6fce  vmovaps xmm2, [rsp+0x20]
00007ed4111d6fd4  vmovaps xmm3, [rsp+0x30]
00007ed4111d6fda  vmovaps xmm4, [rsp+0x40]
00007ed4111d6fe0  vmovaps xmm5, [rsp+0x50]
00007ed4111d6fe6  vmovaps xmm6, [rsp+0x60]
00007ed4111d6fec  vmovaps xmm7, [rsp+0x70]
00007ed4111d6ff2  vmovaps xmm8, [rsp+0x80]
00007ed4111d6ffb  vmovaps xmm9, [rsp+0x90]
00007ed4111d7004  vmovaps xmm10, [rsp+0xA0]
00007ed4111d700d  vmovaps xmm11, [rsp+0xB0]
00007ed4111d7016  vmovaps xmm13, [rsp+0xC0]
00007ed4111d701f  vmovaps xmm14, [rsp+0xD0]
00007ed4111d7028  vmovaps xmm15, [rsp+0xE0]
00007ed4111d7031  add rsp, 0xF0
00007ed4111d7038  pop r11
00007ed4111d703a  pop r10
00007ed4111d703c  pop r9
00007ed4111d703e  pop r8
00007ed4111d7040  pop rsi
00007ed4111d7041  pop rdi
00007ed4111d7042  pop rdx
00007ed4111d7043  pop rcx
00007ed4111d7044  pop rax
00007ed4111d7045  add rsp, 0x08
00007ed4111d7049  jmp 0x00007ED4111D6333
00007ed4111d704e  call 0x00007ED4110D64F0
00007ed4111d7053  jmp 0x00007ED4111D641F
00007ed4111d7058  sub rsp, 0x08
00007ed4111d705c  push rax
00007ed4111d705d  push rcx
00007ed4111d705e  push rdx
00007ed4111d705f  push rdi
00007ed4111d7060  push rsi
00007ed4111d7061  push r8
00007ed4111d7063  push r9
00007ed4111d7065  push r10
00007ed4111d7067  push r11
00007ed4111d7069  sub rsp, 0xF0
00007ed4111d7070  vmovaps [rsp], xmm0
00007ed4111d7075  vmovaps [rsp+0x10], xmm1
00007ed4111d707b  vmovaps [rsp+0x20], xmm2
00007ed4111d7081  vmovaps [rsp+0x30], xmm3
00007ed4111d7087  vmovaps [rsp+0x40], xmm4
00007ed4111d708d  vmovaps [rsp+0x50], xmm5
00007ed4111d7093  vmovaps [rsp+0x60], xmm6
00007ed4111d7099  vmovaps [rsp+0x70], xmm7
00007ed4111d709f  vmovaps [rsp+0x80], xmm8
00007ed4111d70a8  vmovaps [rsp+0x90], xmm9
00007ed4111d70b1  vmovaps [rsp+0xA0], xmm10
00007ed4111d70ba  vmovaps [rsp+0xB0], xmm11
00007ed4111d70c3  vmovaps [rsp+0xC0], xmm12
00007ed4111d70cc  vmovaps [rsp+0xD0], xmm14
00007ed4111d70d5  vmovaps [rsp+0xE0], xmm15
00007ed4111d70de  sub rsp, 0x40
00007ed4111d70e2  lea rdi, [rsp]
00007ed4111d70e6  lea rsi, [rsp+0x10]
00007ed4111d70eb  lea rdx, [rsp+0x20]
00007ed4111d70f0  lea rcx, [rsp+0x30]
00007ed4111d70f5  mov r8d, 0x00
00007ed4111d70fb  lea r9, [r15+0x3A8]
00007ed4111d7102  movaps [rdi], xmm13
00007ed4111d7106  movaps [rsi], xmm1
00007ed4111d7109  movaps [rdx], xmm15
00007ed4111d710d  movaps [rcx], xmm14
00007ed4111d7111  mov rax, 0x5CA8E4A55A50
00007ed4111d711b  call rax
00007ed4111d711d  movaps xmm13, [rsp]
00007ed4111d7122  add rsp, 0x40
00007ed4111d7126  vmovaps xmm0, [rsp]
00007ed4111d712b  vmovaps xmm1, [rsp+0x10]
00007ed4111d7131  vmovaps xmm2, [rsp+0x20]
00007ed4111d7137  vmovaps xmm3, [rsp+0x30]
00007ed4111d713d  vmovaps xmm4, [rsp+0x40]
00007ed4111d7143  vmovaps xmm5, [rsp+0x50]
00007ed4111d7149  vmovaps xmm6, [rsp+0x60]
00007ed4111d714f  vmovaps xmm7, [rsp+0x70]
00007ed4111d7155  vmovaps xmm8, [rsp+0x80]
00007ed4111d715e  vmovaps xmm9, [rsp+0x90]
00007ed4111d7167  vmovaps xmm10, [rsp+0xA0]
00007ed4111d7170  vmovaps xmm11, [rsp+0xB0]
00007ed4111d7179  vmovaps xmm12, [rsp+0xC0]
00007ed4111d7182  vmovaps xmm14, [rsp+0xD0]
00007ed4111d718b  vmovaps xmm15, [rsp+0xE0]
00007ed4111d7194  add rsp, 0xF0
00007ed4111d719b  pop r11
00007ed4111d719d  pop r10
00007ed4111d719f  pop r9
00007ed4111d71a1  pop r8
00007ed4111d71a3  pop rsi
00007ed4111d71a4  pop rdi
00007ed4111d71a5  pop rdx
00007ed4111d71a6  pop rcx
00007ed4111d71a7  pop rax
00007ed4111d71a8  add rsp, 0x08
00007ed4111d71ac  jmp 0x00007ED4111D648E
00007ed4111d71b1  call 0x00007ED4110D64F0
00007ed4111d71b6  jmp 0x00007ED4111D64A3
00007ed4111d71bb  sub rsp, 0x08
00007ed4111d71bf  push rax
00007ed4111d71c0  push rcx
00007ed4111d71c1  push rdx
00007ed4111d71c2  push rdi
00007ed4111d71c3  push rsi
00007ed4111d71c4  push r8
00007ed4111d71c6  push r9
00007ed4111d71c8  push r10
00007ed4111d71ca  push r11
00007ed4111d71cc  sub rsp, 0xF0
00007ed4111d71d3  vmovaps [rsp], xmm0
00007ed4111d71d8  vmovaps [rsp+0x10], xmm1
00007ed4111d71de  vmovaps [rsp+0x20], xmm2
00007ed4111d71e4  vmovaps [rsp+0x30], xmm3
00007ed4111d71ea  vmovaps [rsp+0x40], xmm4
00007ed4111d71f0  vmovaps [rsp+0x50], xmm5
00007ed4111d71f6  vmovaps [rsp+0x60], xmm6
00007ed4111d71fc  vmovaps [rsp+0x70], xmm7
00007ed4111d7202  vmovaps [rsp+0x80], xmm8
00007ed4111d720b  vmovaps [rsp+0x90], xmm9
00007ed4111d7214  vmovaps [rsp+0xA0], xmm10
00007ed4111d721d  vmovaps [rsp+0xB0], xmm11
00007ed4111d7226  vmovaps [rsp+0xC0], xmm13
00007ed4111d722f  vmovaps [rsp+0xD0], xmm14
00007ed4111d7238  vmovaps [rsp+0xE0], xmm15
00007ed4111d7241  sub rsp, 0x40
00007ed4111d7245  lea rdi, [rsp]
00007ed4111d7249  lea rsi, [rsp+0x10]
00007ed4111d724e  lea rdx, [rsp+0x20]
00007ed4111d7253  lea rcx, [rsp+0x30]
00007ed4111d7258  mov r8d, 0x00
00007ed4111d725e  lea r9, [r15+0x3A8]
00007ed4111d7265  movaps [rdi], xmm12
00007ed4111d7269  movaps [rsi], xmm15
00007ed4111d726d  movaps [rdx], xmm1
00007ed4111d7270  movaps [rcx], xmm14
00007ed4111d7274  mov rax, 0x5CA8E4A55A50
00007ed4111d727e  call rax
00007ed4111d7280  movaps xmm12, [rsp]
00007ed4111d7285  add rsp, 0x40
00007ed4111d7289  vmovaps xmm0, [rsp]
00007ed4111d728e  vmovaps xmm1, [rsp+0x10]
00007ed4111d7294  vmovaps xmm2, [rsp+0x20]
00007ed4111d729a  vmovaps xmm3, [rsp+0x30]
00007ed4111d72a0  vmovaps xmm4, [rsp+0x40]
00007ed4111d72a6  vmovaps xmm5, [rsp+0x50]
00007ed4111d72ac  vmovaps xmm6, [rsp+0x60]
00007ed4111d72b2  vmovaps xmm7, [rsp+0x70]
00007ed4111d72b8  vmovaps xmm8, [rsp+0x80]
00007ed4111d72c1  vmovaps xmm9, [rsp+0x90]
00007ed4111d72ca  vmovaps xmm10, [rsp+0xA0]
00007ed4111d72d3  vmovaps xmm11, [rsp+0xB0]
00007ed4111d72dc  vmovaps xmm13, [rsp+0xC0]
00007ed4111d72e5  vmovaps xmm14, [rsp+0xD0]
00007ed4111d72ee  vmovaps xmm15, [rsp+0xE0]
00007ed4111d72f7  add rsp, 0xF0
00007ed4111d72fe  pop r11
00007ed4111d7300  pop r10
00007ed4111d7302  pop r9
00007ed4111d7304  pop r8
00007ed4111d7306  pop rsi
00007ed4111d7307  pop rdi
00007ed4111d7308  pop rdx
00007ed4111d7309  pop rcx
00007ed4111d730a  pop rax
00007ed4111d730b  add rsp, 0x08
00007ed4111d730f  jmp 0x00007ED4111D64CF
00007ed4111d7314  sub rsp, 0x08
00007ed4111d7318  push rax
00007ed4111d7319  push rcx
00007ed4111d731a  push rdx
00007ed4111d731b  push rdi
00007ed4111d731c  push rsi
00007ed4111d731d  push r8
00007ed4111d731f  push r9
00007ed4111d7321  push r10
00007ed4111d7323  push r11
00007ed4111d7325  sub rsp, 0xF0
00007ed4111d732c  vmovaps [rsp], xmm0
00007ed4111d7331  vmovaps [rsp+0x10], xmm1
00007ed4111d7337  vmovaps [rsp+0x20], xmm2
00007ed4111d733d  vmovaps [rsp+0x30], xmm3
00007ed4111d7343  vmovaps [rsp+0x40], xmm4
00007ed4111d7349  vmovaps [rsp+0x50], xmm5
00007ed4111d734f  vmovaps [rsp+0x60], xmm6
00007ed4111d7355  vmovaps [rsp+0x70], xmm7
00007ed4111d735b  vmovaps [rsp+0x80], xmm8
00007ed4111d7364  vmovaps [rsp+0x90], xmm9
00007ed4111d736d  vmovaps [rsp+0xA0], xmm10
00007ed4111d7376  vmovaps [rsp+0xB0], xmm11
00007ed4111d737f  vmovaps [rsp+0xC0], xmm12
00007ed4111d7388  vmovaps [rsp+0xD0], xmm14
00007ed4111d7391  vmovaps [rsp+0xE0], xmm15
00007ed4111d739a  sub rsp, 0x40
00007ed4111d739e  lea rdi, [rsp]
00007ed4111d73a2  lea rsi, [rsp+0x10]
00007ed4111d73a7  lea rdx, [rsp+0x20]
00007ed4111d73ac  lea rcx, [rsp+0x30]
00007ed4111d73b1  mov r8d, 0x00
00007ed4111d73b7  lea r9, [r15+0x3A8]
00007ed4111d73be  movaps [rdi], xmm13
00007ed4111d73c2  movaps [rsi], xmm1
00007ed4111d73c5  movaps [rdx], xmm15
00007ed4111d73c9  movaps [rcx], xmm14
00007ed4111d73cd  mov rax, 0x5CA8E4A55A50
00007ed4111d73d7  call rax
00007ed4111d73d9  movaps xmm13, [rsp]
00007ed4111d73de  add rsp, 0x40
00007ed4111d73e2  vmovaps xmm0, [rsp]
00007ed4111d73e7  vmovaps xmm1, [rsp+0x10]
00007ed4111d73ed  vmovaps xmm2, [rsp+0x20]
00007ed4111d73f3  vmovaps xmm3, [rsp+0x30]
00007ed4111d73f9  vmovaps xmm4, [rsp+0x40]
00007ed4111d73ff  vmovaps xmm5, [rsp+0x50]
00007ed4111d7405  vmovaps xmm6, [rsp+0x60]
00007ed4111d740b  vmovaps xmm7, [rsp+0x70]
00007ed4111d7411  vmovaps xmm8, [rsp+0x80]
00007ed4111d741a  vmovaps xmm9, [rsp+0x90]
00007ed4111d7423  vmovaps xmm10, [rsp+0xA0]
00007ed4111d742c  vmovaps xmm11, [rsp+0xB0]
00007ed4111d7435  vmovaps xmm12, [rsp+0xC0]
00007ed4111d743e  vmovaps xmm14, [rsp+0xD0]
00007ed4111d7447  vmovaps xmm15, [rsp+0xE0]
00007ed4111d7450  add rsp, 0xF0
00007ed4111d7457  pop r11
00007ed4111d7459  pop r10
00007ed4111d745b  pop r9
00007ed4111d745d  pop r8
00007ed4111d745f  pop rsi
00007ed4111d7460  pop rdi
00007ed4111d7461  pop rdx
00007ed4111d7462  pop rcx
00007ed4111d7463  pop rax
00007ed4111d7464  add rsp, 0x08
00007ed4111d7468  jmp 0x00007ED4111D665F
00007ed4111d746d  sub rsp, 0x08
00007ed4111d7471  push rax
00007ed4111d7472  push rcx
00007ed4111d7473  push rdx
00007ed4111d7474  push rdi
00007ed4111d7475  push rsi
00007ed4111d7476  push r8
00007ed4111d7478  push r9
00007ed4111d747a  push r10
00007ed4111d747c  push r11
00007ed4111d747e  sub rsp, 0xF0
00007ed4111d7485  vmovaps [rsp], xmm0
00007ed4111d748a  vmovaps [rsp+0x10], xmm1
00007ed4111d7490  vmovaps [rsp+0x20], xmm2
00007ed4111d7496  vmovaps [rsp+0x30], xmm3
00007ed4111d749c  vmovaps [rsp+0x40], xmm4
00007ed4111d74a2  vmovaps [rsp+0x50], xmm5
00007ed4111d74a8  vmovaps [rsp+0x60], xmm6
00007ed4111d74ae  vmovaps [rsp+0x70], xmm7
00007ed4111d74b4  vmovaps [rsp+0x80], xmm8
00007ed4111d74bd  vmovaps [rsp+0x90], xmm9
00007ed4111d74c6  vmovaps [rsp+0xA0], xmm10
00007ed4111d74cf  vmovaps [rsp+0xB0], xmm11
00007ed4111d74d8  vmovaps [rsp+0xC0], xmm12
00007ed4111d74e1  vmovaps [rsp+0xD0], xmm13
00007ed4111d74ea  vmovaps [rsp+0xE0], xmm15
00007ed4111d74f3  sub rsp, 0x40
00007ed4111d74f7  lea rdi, [rsp]
00007ed4111d74fb  lea rsi, [rsp+0x10]
00007ed4111d7500  lea rdx, [rsp+0x20]
00007ed4111d7505  lea rcx, [rsp+0x30]
00007ed4111d750a  mov r8d, 0x00
00007ed4111d7510  lea r9, [r15+0x3A8]
00007ed4111d7517  movaps [rdi], xmm14
00007ed4111d751b  movaps [rsi], xmm15
00007ed4111d751f  movaps [rdx], xmm2
00007ed4111d7522  movaps [rcx], xmm1
00007ed4111d7525  mov rax, 0x5CA8E4A55A50
00007ed4111d752f  call rax
00007ed4111d7531  movaps xmm14, [rsp]
00007ed4111d7536  add rsp, 0x40
00007ed4111d753a  vmovaps xmm0, [rsp]
00007ed4111d753f  vmovaps xmm1, [rsp+0x10]
00007ed4111d7545  vmovaps xmm2, [rsp+0x20]
00007ed4111d754b  vmovaps xmm3, [rsp+0x30]
00007ed4111d7551  vmovaps xmm4, [rsp+0x40]
00007ed4111d7557  vmovaps xmm5, [rsp+0x50]
00007ed4111d755d  vmovaps xmm6, [rsp+0x60]
00007ed4111d7563  vmovaps xmm7, [rsp+0x70]
00007ed4111d7569  vmovaps xmm8, [rsp+0x80]
00007ed4111d7572  vmovaps xmm9, [rsp+0x90]
00007ed4111d757b  vmovaps xmm10, [rsp+0xA0]
00007ed4111d7584  vmovaps xmm11, [rsp+0xB0]
00007ed4111d758d  vmovaps xmm12, [rsp+0xC0]
00007ed4111d7596  vmovaps xmm13, [rsp+0xD0]
00007ed4111d759f  vmovaps xmm15, [rsp+0xE0]
00007ed4111d75a8  add rsp, 0xF0
00007ed4111d75af  pop r11
00007ed4111d75b1  pop r10
00007ed4111d75b3  pop r9
00007ed4111d75b5  pop r8
00007ed4111d75b7  pop rsi
00007ed4111d75b8  pop rdi
00007ed4111d75b9  pop rdx
00007ed4111d75ba  pop rcx
00007ed4111d75bb  pop rax
00007ed4111d75bc  add rsp, 0x08
00007ed4111d75c0  jmp 0x00007ED4111D6691
00007ed4111d75c5  sub rsp, 0x08
00007ed4111d75c9  push rax
00007ed4111d75ca  push rcx
00007ed4111d75cb  push rdx
00007ed4111d75cc  push rdi
00007ed4111d75cd  push rsi
00007ed4111d75ce  push r8
00007ed4111d75d0  push r9
00007ed4111d75d2  push r10
00007ed4111d75d4  push r11
00007ed4111d75d6  sub rsp, 0xF0
00007ed4111d75dd  vmovaps [rsp], xmm0
00007ed4111d75e2  vmovaps [rsp+0x10], xmm1
00007ed4111d75e8  vmovaps [rsp+0x20], xmm3
00007ed4111d75ee  vmovaps [rsp+0x30], xmm4
00007ed4111d75f4  vmovaps [rsp+0x40], xmm5
00007ed4111d75fa  vmovaps [rsp+0x50], xmm6
00007ed4111d7600  vmovaps [rsp+0x60], xmm7
00007ed4111d7606  vmovaps [rsp+0x70], xmm8
00007ed4111d760c  vmovaps [rsp+0x80], xmm9
00007ed4111d7615  vmovaps [rsp+0x90], xmm10
00007ed4111d761e  vmovaps [rsp+0xA0], xmm11
00007ed4111d7627  vmovaps [rsp+0xB0], xmm12
00007ed4111d7630  vmovaps [rsp+0xC0], xmm13
00007ed4111d7639  vmovaps [rsp+0xD0], xmm14
00007ed4111d7642  vmovaps [rsp+0xE0], xmm15
00007ed4111d764b  sub rsp, 0x40
00007ed4111d764f  lea rdi, [rsp]
00007ed4111d7653  lea rsi, [rsp+0x10]
00007ed4111d7658  lea rdx, [rsp+0x20]
00007ed4111d765d  lea rcx, [rsp+0x30]
00007ed4111d7662  mov r8d, 0x00
00007ed4111d7668  lea r9, [r15+0x3A8]
00007ed4111d766f  movaps [rdi], xmm2
00007ed4111d7672  movaps [rsi], xmm15
00007ed4111d7676  movaps [rdx], xmm12
00007ed4111d767a  movaps [rcx], xmm1
00007ed4111d767d  mov rax, 0x5CA8E4A55A50
00007ed4111d7687  call rax
00007ed4111d7689  movaps xmm2, [rsp]
00007ed4111d768d  add rsp, 0x40
00007ed4111d7691  vmovaps xmm0, [rsp]
00007ed4111d7696  vmovaps xmm1, [rsp+0x10]
00007ed4111d769c  vmovaps xmm3, [rsp+0x20]
00007ed4111d76a2  vmovaps xmm4, [rsp+0x30]
00007ed4111d76a8  vmovaps xmm5, [rsp+0x40]
00007ed4111d76ae  vmovaps xmm6, [rsp+0x50]
00007ed4111d76b4  vmovaps xmm7, [rsp+0x60]
00007ed4111d76ba  vmovaps xmm8, [rsp+0x70]
00007ed4111d76c0  vmovaps xmm9, [rsp+0x80]
00007ed4111d76c9  vmovaps xmm10, [rsp+0x90]
00007ed4111d76d2  vmovaps xmm11, [rsp+0xA0]
00007ed4111d76db  vmovaps xmm12, [rsp+0xB0]
00007ed4111d76e4  vmovaps xmm13, [rsp+0xC0]
00007ed4111d76ed  vmovaps xmm14, [rsp+0xD0]
00007ed4111d76f6  vmovaps xmm15, [rsp+0xE0]
00007ed4111d76ff  add rsp, 0xF0
00007ed4111d7706  pop r11
00007ed4111d7708  pop r10
00007ed4111d770a  pop r9
00007ed4111d770c  pop r8
00007ed4111d770e  pop rsi
00007ed4111d770f  pop rdi
00007ed4111d7710  pop rdx
00007ed4111d7711  pop rcx
00007ed4111d7712  pop rax
00007ed4111d7713  add rsp, 0x08
00007ed4111d7717  jmp 0x00007ED4111D66CE
00007ed4111d771c  sub rsp, 0x08
00007ed4111d7720  push rax
00007ed4111d7721  push rcx
00007ed4111d7722  push rdx
00007ed4111d7723  push rdi
00007ed4111d7724  push rsi
00007ed4111d7725  push r8
00007ed4111d7727  push r9
00007ed4111d7729  push r10
00007ed4111d772b  push r11
00007ed4111d772d  sub rsp, 0xF0
00007ed4111d7734  vmovaps [rsp], xmm0
00007ed4111d7739  vmovaps [rsp+0x10], xmm1
00007ed4111d773f  vmovaps [rsp+0x20], xmm2
00007ed4111d7745  vmovaps [rsp+0x30], xmm3
00007ed4111d774b  vmovaps [rsp+0x40], xmm4
00007ed4111d7751  vmovaps [rsp+0x50], xmm5
00007ed4111d7757  vmovaps [rsp+0x60], xmm6
00007ed4111d775d  vmovaps [rsp+0x70], xmm7
00007ed4111d7763  vmovaps [rsp+0x80], xmm8
00007ed4111d776c  vmovaps [rsp+0x90], xmm9
00007ed4111d7775  vmovaps [rsp+0xA0], xmm10
00007ed4111d777e  vmovaps [rsp+0xB0], xmm11
00007ed4111d7787  vmovaps [rsp+0xC0], xmm13
00007ed4111d7790  vmovaps [rsp+0xD0], xmm14
00007ed4111d7799  vmovaps [rsp+0xE0], xmm15
00007ed4111d77a2  sub rsp, 0x40
00007ed4111d77a6  lea rdi, [rsp]
00007ed4111d77aa  lea rsi, [rsp+0x10]
00007ed4111d77af  lea rdx, [rsp+0x20]
00007ed4111d77b4  lea rcx, [rsp+0x30]
00007ed4111d77b9  mov r8d, 0x00
00007ed4111d77bf  lea r9, [r15+0x3A8]
00007ed4111d77c6  movaps [rdi], xmm12
00007ed4111d77ca  movaps [rsi], xmm14
00007ed4111d77ce  movaps [rdx], xmm3
00007ed4111d77d1  movaps [rcx], xmm15
00007ed4111d77d5  mov rax, 0x5CA8E4A55A50
00007ed4111d77df  call rax
00007ed4111d77e1  movaps xmm12, [rsp]
00007ed4111d77e6  add rsp, 0x40
00007ed4111d77ea  vmovaps xmm0, [rsp]
00007ed4111d77ef  vmovaps xmm1, [rsp+0x10]
00007ed4111d77f5  vmovaps xmm2, [rsp+0x20]
00007ed4111d77fb  vmovaps xmm3, [rsp+0x30]
00007ed4111d7801  vmovaps xmm4, [rsp+0x40]
00007ed4111d7807  vmovaps xmm5, [rsp+0x50]
00007ed4111d780d  vmovaps xmm6, [rsp+0x60]
00007ed4111d7813  vmovaps xmm7, [rsp+0x70]
00007ed4111d7819  vmovaps xmm8, [rsp+0x80]
00007ed4111d7822  vmovaps xmm9, [rsp+0x90]
00007ed4111d782b  vmovaps xmm10, [rsp+0xA0]
00007ed4111d7834  vmovaps xmm11, [rsp+0xB0]
00007ed4111d783d  vmovaps xmm13, [rsp+0xC0]
00007ed4111d7846  vmovaps xmm14, [rsp+0xD0]
00007ed4111d784f  vmovaps xmm15, [rsp+0xE0]
00007ed4111d7858  add rsp, 0xF0
00007ed4111d785f  pop r11
00007ed4111d7861  pop r10
00007ed4111d7863  pop r9
00007ed4111d7865  pop r8
00007ed4111d7867  pop rsi
00007ed4111d7868  pop rdi
00007ed4111d7869  pop rdx
00007ed4111d786a  pop rcx
00007ed4111d786b  pop rax
00007ed4111d786c  add rsp, 0x08
00007ed4111d7870  jmp 0x00007ED4111D6728
00007ed4111d7875  sub rsp, 0x08
00007ed4111d7879  push rax
00007ed4111d787a  push rcx
00007ed4111d787b  push rdx
00007ed4111d787c  push rdi
00007ed4111d787d  push rsi
00007ed4111d787e  push r8
00007ed4111d7880  push r9
00007ed4111d7882  push r10
00007ed4111d7884  push r11
00007ed4111d7886  sub rsp, 0xF0
00007ed4111d788d  vmovaps [rsp], xmm0
00007ed4111d7892  vmovaps [rsp+0x10], xmm1
00007ed4111d7898  vmovaps [rsp+0x20], xmm2
00007ed4111d789e  vmovaps [rsp+0x30], xmm3
00007ed4111d78a4  vmovaps [rsp+0x40], xmm4
00007ed4111d78aa  vmovaps [rsp+0x50], xmm5
00007ed4111d78b0  vmovaps [rsp+0x60], xmm6
00007ed4111d78b6  vmovaps [rsp+0x70], xmm7
00007ed4111d78bc  vmovaps [rsp+0x80], xmm8
00007ed4111d78c5  vmovaps [rsp+0x90], xmm10
00007ed4111d78ce  vmovaps [rsp+0xA0], xmm11
00007ed4111d78d7  vmovaps [rsp+0xB0], xmm12
00007ed4111d78e0  vmovaps [rsp+0xC0], xmm13
00007ed4111d78e9  vmovaps [rsp+0xD0], xmm14
00007ed4111d78f2  vmovaps [rsp+0xE0], xmm15
00007ed4111d78fb  sub rsp, 0x40
00007ed4111d78ff  lea rdi, [rsp]
00007ed4111d7903  lea rsi, [rsp+0x10]
00007ed4111d7908  lea rdx, [rsp+0x20]
00007ed4111d790d  lea rcx, [rsp+0x30]
00007ed4111d7912  mov r8d, 0x00
00007ed4111d7918  lea r9, [r15+0x3A8]
00007ed4111d791f  movaps [rdi], xmm9
00007ed4111d7923  movaps [rsi], xmm13
00007ed4111d7927  movaps [rdx], xmm14
00007ed4111d792b  movaps [rcx], xmm6
00007ed4111d792e  mov rax, 0x5CA8E4A55A50
00007ed4111d7938  call rax
00007ed4111d793a  movaps xmm9, [rsp]
00007ed4111d793f  add rsp, 0x40
00007ed4111d7943  vmovaps xmm0, [rsp]
00007ed4111d7948  vmovaps xmm1, [rsp+0x10]
00007ed4111d794e  vmovaps xmm2, [rsp+0x20]
00007ed4111d7954  vmovaps xmm3, [rsp+0x30]
00007ed4111d795a  vmovaps xmm4, [rsp+0x40]
00007ed4111d7960  vmovaps xmm5, [rsp+0x50]
00007ed4111d7966  vmovaps xmm6, [rsp+0x60]
00007ed4111d796c  vmovaps xmm7, [rsp+0x70]
00007ed4111d7972  vmovaps xmm8, [rsp+0x80]
00007ed4111d797b  vmovaps xmm10, [rsp+0x90]
00007ed4111d7984  vmovaps xmm11, [rsp+0xA0]
00007ed4111d798d  vmovaps xmm12, [rsp+0xB0]
00007ed4111d7996  vmovaps xmm13, [rsp+0xC0]
00007ed4111d799f  vmovaps xmm14, [rsp+0xD0]
00007ed4111d79a8  vmovaps xmm15, [rsp+0xE0]
00007ed4111d79b1  add rsp, 0xF0
00007ed4111d79b8  pop r11
00007ed4111d79ba  pop r10
00007ed4111d79bc  pop r9
00007ed4111d79be  pop r8
00007ed4111d79c0  pop rsi
00007ed4111d79c1  pop rdi
00007ed4111d79c2  pop rdx
00007ed4111d79c3  pop rcx
00007ed4111d79c4  pop rax
00007ed4111d79c5  add rsp, 0x08
00007ed4111d79c9  jmp 0x00007ED4111D67D2
00007ed4111d79ce  sub rsp, 0x08
00007ed4111d79d2  push rax
00007ed4111d79d3  push rcx
00007ed4111d79d4  push rdx
00007ed4111d79d5  push rdi
00007ed4111d79d6  push rsi
00007ed4111d79d7  push r8
00007ed4111d79d9  push r9
00007ed4111d79db  push r10
00007ed4111d79dd  push r11
00007ed4111d79df  sub rsp, 0xF0
00007ed4111d79e6  vmovaps [rsp], xmm0
00007ed4111d79eb  vmovaps [rsp+0x10], xmm1
00007ed4111d79f1  vmovaps [rsp+0x20], xmm2
00007ed4111d79f7  vmovaps [rsp+0x30], xmm4
00007ed4111d79fd  vmovaps [rsp+0x40], xmm5
00007ed4111d7a03  vmovaps [rsp+0x50], xmm6
00007ed4111d7a09  vmovaps [rsp+0x60], xmm7
00007ed4111d7a0f  vmovaps [rsp+0x70], xmm8
00007ed4111d7a15  vmovaps [rsp+0x80], xmm9
00007ed4111d7a1e  vmovaps [rsp+0x90], xmm10
00007ed4111d7a27  vmovaps [rsp+0xA0], xmm11
00007ed4111d7a30  vmovaps [rsp+0xB0], xmm12
00007ed4111d7a39  vmovaps [rsp+0xC0], xmm13
00007ed4111d7a42  vmovaps [rsp+0xD0], xmm14
00007ed4111d7a4b  vmovaps [rsp+0xE0], xmm15
00007ed4111d7a54  sub rsp, 0x40
00007ed4111d7a58  lea rdi, [rsp]
00007ed4111d7a5c  lea rsi, [rsp+0x10]
00007ed4111d7a61  lea rdx, [rsp+0x20]
00007ed4111d7a66  lea rcx, [rsp+0x30]
00007ed4111d7a6b  mov r8d, 0x00
00007ed4111d7a71  lea r9, [r15+0x3A8]
00007ed4111d7a78  movaps [rdi], xmm3
00007ed4111d7a7b  movaps [rsi], xmm13
00007ed4111d7a7f  movaps [rdx], xmm6
00007ed4111d7a82  movaps [rcx], xmm14
00007ed4111d7a86  mov rax, 0x5CA8E4A55A50
00007ed4111d7a90  call rax
00007ed4111d7a92  movaps xmm3, [rsp]
00007ed4111d7a96  add rsp, 0x40
00007ed4111d7a9a  vmovaps xmm0, [rsp]
00007ed4111d7a9f  vmovaps xmm1, [rsp+0x10]
00007ed4111d7aa5  vmovaps xmm2, [rsp+0x20]
00007ed4111d7aab  vmovaps xmm4, [rsp+0x30]
00007ed4111d7ab1  vmovaps xmm5, [rsp+0x40]
00007ed4111d7ab7  vmovaps xmm6, [rsp+0x50]
00007ed4111d7abd  vmovaps xmm7, [rsp+0x60]
00007ed4111d7ac3  vmovaps xmm8, [rsp+0x70]
00007ed4111d7ac9  vmovaps xmm9, [rsp+0x80]
00007ed4111d7ad2  vmovaps xmm10, [rsp+0x90]
00007ed4111d7adb  vmovaps xmm11, [rsp+0xA0]
00007ed4111d7ae4  vmovaps xmm12, [rsp+0xB0]
00007ed4111d7aed  vmovaps xmm13, [rsp+0xC0]
00007ed4111d7af6  vmovaps xmm14, [rsp+0xD0]
00007ed4111d7aff  vmovaps xmm15, [rsp+0xE0]
00007ed4111d7b08  add rsp, 0xF0
00007ed4111d7b0f  pop r11
00007ed4111d7b11  pop r10
00007ed4111d7b13  pop r9
00007ed4111d7b15  pop r8
00007ed4111d7b17  pop rsi
00007ed4111d7b18  pop rdi
00007ed4111d7b19  pop rdx
00007ed4111d7b1a  pop rcx
00007ed4111d7b1b  pop rax
00007ed4111d7b1c  add rsp, 0x08
00007ed4111d7b20  jmp 0x00007ED4111D680F
00007ed4111d7b25  sub rsp, 0x08
00007ed4111d7b29  push rax
00007ed4111d7b2a  push rcx
00007ed4111d7b2b  push rdx
00007ed4111d7b2c  push rdi
00007ed4111d7b2d  push rsi
00007ed4111d7b2e  push r8
00007ed4111d7b30  push r9
00007ed4111d7b32  push r10
00007ed4111d7b34  push r11
00007ed4111d7b36  sub rsp, 0xF0
00007ed4111d7b3d  vmovaps [rsp], xmm0
00007ed4111d7b42  vmovaps [rsp+0x10], xmm1
00007ed4111d7b48  vmovaps [rsp+0x20], xmm2
00007ed4111d7b4e  vmovaps [rsp+0x30], xmm3
00007ed4111d7b54  vmovaps [rsp+0x40], xmm4
00007ed4111d7b5a  vmovaps [rsp+0x50], xmm5
00007ed4111d7b60  vmovaps [rsp+0x60], xmm7
00007ed4111d7b66  vmovaps [rsp+0x70], xmm8
00007ed4111d7b6c  vmovaps [rsp+0x80], xmm9
00007ed4111d7b75  vmovaps [rsp+0x90], xmm10
00007ed4111d7b7e  vmovaps [rsp+0xA0], xmm11
00007ed4111d7b87  vmovaps [rsp+0xB0], xmm12
00007ed4111d7b90  vmovaps [rsp+0xC0], xmm13
00007ed4111d7b99  vmovaps [rsp+0xD0], xmm14
00007ed4111d7ba2  vmovaps [rsp+0xE0], xmm15
00007ed4111d7bab  sub rsp, 0x40
00007ed4111d7baf  lea rdi, [rsp]
00007ed4111d7bb3  lea rsi, [rsp+0x10]
00007ed4111d7bb8  lea rdx, [rsp+0x20]
00007ed4111d7bbd  lea rcx, [rsp+0x30]
00007ed4111d7bc2  mov r8d, 0x00
00007ed4111d7bc8  lea r9, [r15+0x3A8]
00007ed4111d7bcf  movaps [rdi], xmm6
00007ed4111d7bd2  movaps [rsi], xmm2
00007ed4111d7bd5  movaps [rdx], xmm14
00007ed4111d7bd9  movaps [rcx], xmm1
00007ed4111d7bdc  mov rax, 0x5CA8E4A55A50
00007ed4111d7be6  call rax
00007ed4111d7be8  movaps xmm6, [rsp]
00007ed4111d7bec  add rsp, 0x40
00007ed4111d7bf0  vmovaps xmm0, [rsp]
00007ed4111d7bf5  vmovaps xmm1, [rsp+0x10]
00007ed4111d7bfb  vmovaps xmm2, [rsp+0x20]
00007ed4111d7c01  vmovaps xmm3, [rsp+0x30]
00007ed4111d7c07  vmovaps xmm4, [rsp+0x40]
00007ed4111d7c0d  vmovaps xmm5, [rsp+0x50]
00007ed4111d7c13  vmovaps xmm7, [rsp+0x60]
00007ed4111d7c19  vmovaps xmm8, [rsp+0x70]
00007ed4111d7c1f  vmovaps xmm9, [rsp+0x80]
00007ed4111d7c28  vmovaps xmm10, [rsp+0x90]
00007ed4111d7c31  vmovaps xmm11, [rsp+0xA0]
00007ed4111d7c3a  vmovaps xmm12, [rsp+0xB0]
00007ed4111d7c43  vmovaps xmm13, [rsp+0xC0]
00007ed4111d7c4c  vmovaps xmm14, [rsp+0xD0]
00007ed4111d7c55  vmovaps xmm15, [rsp+0xE0]
00007ed4111d7c5e  add rsp, 0xF0
00007ed4111d7c65  pop r11
00007ed4111d7c67  pop r10
00007ed4111d7c69  pop r9
00007ed4111d7c6b  pop r8
00007ed4111d7c6d  pop rsi
00007ed4111d7c6e  pop rdi
00007ed4111d7c6f  pop rdx
00007ed4111d7c70  pop rcx
00007ed4111d7c71  pop rax
00007ed4111d7c72  add rsp, 0x08
00007ed4111d7c76  jmp 0x00007ED4111D683C
00007ed4111d7c7b  sub rsp, 0x08
00007ed4111d7c7f  push rax
00007ed4111d7c80  push rcx
00007ed4111d7c81  push rdx
00007ed4111d7c82  push rdi
00007ed4111d7c83  push rsi
00007ed4111d7c84  push r8
00007ed4111d7c86  push r9
00007ed4111d7c88  push r10
00007ed4111d7c8a  push r11
00007ed4111d7c8c  sub rsp, 0xF0
00007ed4111d7c93  vmovaps [rsp], xmm0
00007ed4111d7c98  vmovaps [rsp+0x10], xmm1
00007ed4111d7c9e  vmovaps [rsp+0x20], xmm2
00007ed4111d7ca4  vmovaps [rsp+0x30], xmm3
00007ed4111d7caa  vmovaps [rsp+0x40], xmm4
00007ed4111d7cb0  vmovaps [rsp+0x50], xmm5
00007ed4111d7cb6  vmovaps [rsp+0x60], xmm6
00007ed4111d7cbc  vmovaps [rsp+0x70], xmm7
00007ed4111d7cc2  vmovaps [rsp+0x80], xmm8
00007ed4111d7ccb  vmovaps [rsp+0x90], xmm9
00007ed4111d7cd4  vmovaps [rsp+0xA0], xmm10
00007ed4111d7cdd  vmovaps [rsp+0xB0], xmm11
00007ed4111d7ce6  vmovaps [rsp+0xC0], xmm12
00007ed4111d7cef  vmovaps [rsp+0xD0], xmm14
00007ed4111d7cf8  vmovaps [rsp+0xE0], xmm15
00007ed4111d7d01  sub rsp, 0x40
00007ed4111d7d05  lea rdi, [rsp]
00007ed4111d7d09  lea rsi, [rsp+0x10]
00007ed4111d7d0e  lea rdx, [rsp+0x20]
00007ed4111d7d13  lea rcx, [rsp+0x30]
00007ed4111d7d18  mov r8d, 0x00
00007ed4111d7d1e  lea r9, [r15+0x3A8]
00007ed4111d7d25  movaps [rdi], xmm13
00007ed4111d7d29  movaps [rsi], xmm12
00007ed4111d7d2d  movaps [rdx], xmm14
00007ed4111d7d31  movaps [rcx], xmm1
00007ed4111d7d34  mov rax, 0x5CA8E4A55A50
00007ed4111d7d3e  call rax
00007ed4111d7d40  movaps xmm13, [rsp]
00007ed4111d7d45  add rsp, 0x40
00007ed4111d7d49  vmovaps xmm0, [rsp]
00007ed4111d7d4e  vmovaps xmm1, [rsp+0x10]
00007ed4111d7d54  vmovaps xmm2, [rsp+0x20]
00007ed4111d7d5a  vmovaps xmm3, [rsp+0x30]
00007ed4111d7d60  vmovaps xmm4, [rsp+0x40]
00007ed4111d7d66  vmovaps xmm5, [rsp+0x50]
00007ed4111d7d6c  vmovaps xmm6, [rsp+0x60]
00007ed4111d7d72  vmovaps xmm7, [rsp+0x70]
00007ed4111d7d78  vmovaps xmm8, [rsp+0x80]
00007ed4111d7d81  vmovaps xmm9, [rsp+0x90]
00007ed4111d7d8a  vmovaps xmm10, [rsp+0xA0]
00007ed4111d7d93  vmovaps xmm11, [rsp+0xB0]
00007ed4111d7d9c  vmovaps xmm12, [rsp+0xC0]
00007ed4111d7da5  vmovaps xmm14, [rsp+0xD0]
00007ed4111d7dae  vmovaps xmm15, [rsp+0xE0]
00007ed4111d7db7  add rsp, 0xF0
00007ed4111d7dbe  pop r11
00007ed4111d7dc0  pop r10
00007ed4111d7dc2  pop r9
00007ed4111d7dc4  pop r8
00007ed4111d7dc6  pop rsi
00007ed4111d7dc7  pop rdi
00007ed4111d7dc8  pop rdx
00007ed4111d7dc9  pop rcx
00007ed4111d7dca  pop rax
00007ed4111d7dcb  add rsp, 0x08
00007ed4111d7dcf  jmp 0x00007ED4111D686E
00007ed4111d7dd4  sub rsp, 0x08
00007ed4111d7dd8  push rax
00007ed4111d7dd9  push rcx
00007ed4111d7dda  push rdx
00007ed4111d7ddb  push rdi
00007ed4111d7ddc  push rsi
00007ed4111d7ddd  push r8
00007ed4111d7ddf  push r9
00007ed4111d7de1  push r10
00007ed4111d7de3  push r11
00007ed4111d7de5  sub rsp, 0xF0
00007ed4111d7dec  vmovaps [rsp], xmm0
00007ed4111d7df1  vmovaps [rsp+0x10], xmm1
00007ed4111d7df7  vmovaps [rsp+0x20], xmm2
00007ed4111d7dfd  vmovaps [rsp+0x30], xmm3
00007ed4111d7e03  vmovaps [rsp+0x40], xmm4
00007ed4111d7e09  vmovaps [rsp+0x50], xmm5
00007ed4111d7e0f  vmovaps [rsp+0x60], xmm6
00007ed4111d7e15  vmovaps [rsp+0x70], xmm7
00007ed4111d7e1b  vmovaps [rsp+0x80], xmm8
00007ed4111d7e24  vmovaps [rsp+0x90], xmm9
00007ed4111d7e2d  vmovaps [rsp+0xA0], xmm10
00007ed4111d7e36  vmovaps [rsp+0xB0], xmm11
00007ed4111d7e3f  vmovaps [rsp+0xC0], xmm13
00007ed4111d7e48  vmovaps [rsp+0xD0], xmm14
00007ed4111d7e51  vmovaps [rsp+0xE0], xmm15
00007ed4111d7e5a  sub rsp, 0x40
00007ed4111d7e5e  lea rdi, [rsp]
00007ed4111d7e62  lea rsi, [rsp+0x10]
00007ed4111d7e67  lea rdx, [rsp+0x20]
00007ed4111d7e6c  lea rcx, [rsp+0x30]
00007ed4111d7e71  mov r8d, 0x00
00007ed4111d7e77  lea r9, [r15+0x3A8]
00007ed4111d7e7e  movaps [rdi], xmm12
00007ed4111d7e82  movaps [rsi], xmm3
00007ed4111d7e85  movaps [rdx], xmm14
00007ed4111d7e89  movaps [rcx], xmm5
00007ed4111d7e8c  mov rax, 0x5CA8E4A55A50
00007ed4111d7e96  call rax
00007ed4111d7e98  movaps xmm12, [rsp]
00007ed4111d7e9d  add rsp, 0x40
00007ed4111d7ea1  vmovaps xmm0, [rsp]
00007ed4111d7ea6  vmovaps xmm1, [rsp+0x10]
00007ed4111d7eac  vmovaps xmm2, [rsp+0x20]
00007ed4111d7eb2  vmovaps xmm3, [rsp+0x30]
00007ed4111d7eb8  vmovaps xmm4, [rsp+0x40]
00007ed4111d7ebe  vmovaps xmm5, [rsp+0x50]
00007ed4111d7ec4  vmovaps xmm6, [rsp+0x60]
00007ed4111d7eca  vmovaps xmm7, [rsp+0x70]
00007ed4111d7ed0  vmovaps xmm8, [rsp+0x80]
00007ed4111d7ed9  vmovaps xmm9, [rsp+0x90]
00007ed4111d7ee2  vmovaps xmm10, [rsp+0xA0]
00007ed4111d7eeb  vmovaps xmm11, [rsp+0xB0]
00007ed4111d7ef4  vmovaps xmm13, [rsp+0xC0]
00007ed4111d7efd  vmovaps xmm14, [rsp+0xD0]
00007ed4111d7f06  vmovaps xmm15, [rsp+0xE0]
00007ed4111d7f0f  add rsp, 0xF0
00007ed4111d7f16  pop r11
00007ed4111d7f18  pop r10
00007ed4111d7f1a  pop r9
00007ed4111d7f1c  pop r8
00007ed4111d7f1e  pop rsi
00007ed4111d7f1f  pop rdi
00007ed4111d7f20  pop rdx
00007ed4111d7f21  pop rcx
00007ed4111d7f22  pop rax
00007ed4111d7f23  add rsp, 0x08
00007ed4111d7f27  jmp 0x00007ED4111D68CB
00007ed4111d7f2c  sub rsp, 0x08
00007ed4111d7f30  push rax
00007ed4111d7f31  push rcx
00007ed4111d7f32  push rdx
00007ed4111d7f33  push rdi
00007ed4111d7f34  push rsi
00007ed4111d7f35  push r8
00007ed4111d7f37  push r9
00007ed4111d7f39  push r10
00007ed4111d7f3b  push r11
00007ed4111d7f3d  sub rsp, 0xF0
00007ed4111d7f44  vmovaps [rsp], xmm0
00007ed4111d7f49  vmovaps [rsp+0x10], xmm1
00007ed4111d7f4f  vmovaps [rsp+0x20], xmm2
00007ed4111d7f55  vmovaps [rsp+0x30], xmm3
00007ed4111d7f5b  vmovaps [rsp+0x40], xmm4
00007ed4111d7f61  vmovaps [rsp+0x50], xmm5
00007ed4111d7f67  vmovaps [rsp+0x60], xmm6
00007ed4111d7f6d  vmovaps [rsp+0x70], xmm7
00007ed4111d7f73  vmovaps [rsp+0x80], xmm8
00007ed4111d7f7c  vmovaps [rsp+0x90], xmm9
00007ed4111d7f85  vmovaps [rsp+0xA0], xmm11
00007ed4111d7f8e  vmovaps [rsp+0xB0], xmm12
00007ed4111d7f97  vmovaps [rsp+0xC0], xmm13
00007ed4111d7fa0  vmovaps [rsp+0xD0], xmm14
00007ed4111d7fa9  vmovaps [rsp+0xE0], xmm15
00007ed4111d7fb2  sub rsp, 0x40
00007ed4111d7fb6  lea rdi, [rsp]
00007ed4111d7fba  lea rsi, [rsp+0x10]
00007ed4111d7fbf  lea rdx, [rsp+0x20]
00007ed4111d7fc4  lea rcx, [rsp+0x30]
00007ed4111d7fc9  mov r8d, 0x00
00007ed4111d7fcf  lea r9, [r15+0x3A8]
00007ed4111d7fd6  movaps [rdi], xmm10
00007ed4111d7fda  movaps [rsi], xmm9
00007ed4111d7fde  movaps [rdx], xmm7
00007ed4111d7fe1  movaps [rcx], xmm14
00007ed4111d7fe5  mov rax, 0x5CA8E4A55A50
00007ed4111d7fef  call rax
00007ed4111d7ff1  movaps xmm10, [rsp]
00007ed4111d7ff6  add rsp, 0x40
00007ed4111d7ffa  vmovaps xmm0, [rsp]
00007ed4111d7fff  vmovaps xmm1, [rsp+0x10]
00007ed4111d8005  vmovaps xmm2, [rsp+0x20]
00007ed4111d800b  vmovaps xmm3, [rsp+0x30]
00007ed4111d8011  vmovaps xmm4, [rsp+0x40]
00007ed4111d8017  vmovaps xmm5, [rsp+0x50]
00007ed4111d801d  vmovaps xmm6, [rsp+0x60]
00007ed4111d8023  vmovaps xmm7, [rsp+0x70]
00007ed4111d8029  vmovaps xmm8, [rsp+0x80]
00007ed4111d8032  vmovaps xmm9, [rsp+0x90]
00007ed4111d803b  vmovaps xmm11, [rsp+0xA0]
00007ed4111d8044  vmovaps xmm12, [rsp+0xB0]
00007ed4111d804d  vmovaps xmm13, [rsp+0xC0]
00007ed4111d8056  vmovaps xmm14, [rsp+0xD0]
00007ed4111d805f  vmovaps xmm15, [rsp+0xE0]
00007ed4111d8068  add rsp, 0xF0
00007ed4111d806f  pop r11
00007ed4111d8071  pop r10
00007ed4111d8073  pop r9
00007ed4111d8075  pop r8
00007ed4111d8077  pop rsi
00007ed4111d8078  pop rdi
00007ed4111d8079  pop rdx
00007ed4111d807a  pop rcx
00007ed4111d807b  pop rax
00007ed4111d807c  add rsp, 0x08
00007ed4111d8080  jmp 0x00007ED4111D68F1
00007ed4111d8085  call 0x00007ED4110E45A0
00007ed4111d808a  jmp 0x00007ED4111D68FE
00007ed4111d808f  sub rsp, 0x08
00007ed4111d8093  push rax
00007ed4111d8094  push rcx
00007ed4111d8095  push rdx
00007ed4111d8096  push rdi
00007ed4111d8097  push rsi
00007ed4111d8098  push r8
00007ed4111d809a  push r9
00007ed4111d809c  push r10
00007ed4111d809e  push r11
00007ed4111d80a0  sub rsp, 0xF0
00007ed4111d80a7  vmovaps [rsp], xmm0
00007ed4111d80ac  vmovaps [rsp+0x10], xmm1
00007ed4111d80b2  vmovaps [rsp+0x20], xmm2
00007ed4111d80b8  vmovaps [rsp+0x30], xmm3
00007ed4111d80be  vmovaps [rsp+0x40], xmm4
00007ed4111d80c4  vmovaps [rsp+0x50], xmm6
00007ed4111d80ca  vmovaps [rsp+0x60], xmm7
00007ed4111d80d0  vmovaps [rsp+0x70], xmm8
00007ed4111d80d6  vmovaps [rsp+0x80], xmm9
00007ed4111d80df  vmovaps [rsp+0x90], xmm10
00007ed4111d80e8  vmovaps [rsp+0xA0], xmm11
00007ed4111d80f1  vmovaps [rsp+0xB0], xmm12
00007ed4111d80fa  vmovaps [rsp+0xC0], xmm13
00007ed4111d8103  vmovaps [rsp+0xD0], xmm14
00007ed4111d810c  vmovaps [rsp+0xE0], xmm15
00007ed4111d8115  sub rsp, 0x40
00007ed4111d8119  lea rdi, [rsp]
00007ed4111d811d  lea rsi, [rsp+0x10]
00007ed4111d8122  lea rdx, [rsp+0x20]
00007ed4111d8127  lea rcx, [rsp+0x30]
00007ed4111d812c  mov r8d, 0x00
00007ed4111d8132  lea r9, [r15+0x3A8]
00007ed4111d8139  movaps [rdi], xmm5
00007ed4111d813c  movaps [rsi], xmm6
00007ed4111d813f  movaps [rdx], xmm7
00007ed4111d8142  movaps [rcx], xmm9
00007ed4111d8146  mov rax, 0x5CA8E4A55A50
00007ed4111d8150  call rax
00007ed4111d8152  movaps xmm5, [rsp]
00007ed4111d8156  add rsp, 0x40
00007ed4111d815a  vmovaps xmm0, [rsp]
00007ed4111d815f  vmovaps xmm1, [rsp+0x10]
00007ed4111d8165  vmovaps xmm2, [rsp+0x20]
00007ed4111d816b  vmovaps xmm3, [rsp+0x30]
00007ed4111d8171  vmovaps xmm4, [rsp+0x40]
00007ed4111d8177  vmovaps xmm6, [rsp+0x50]
00007ed4111d817d  vmovaps xmm7, [rsp+0x60]
00007ed4111d8183  vmovaps xmm8, [rsp+0x70]
00007ed4111d8189  vmovaps xmm9, [rsp+0x80]
00007ed4111d8192  vmovaps xmm10, [rsp+0x90]
00007ed4111d819b  vmovaps xmm11, [rsp+0xA0]
00007ed4111d81a4  vmovaps xmm12, [rsp+0xB0]
00007ed4111d81ad  vmovaps xmm13, [rsp+0xC0]
00007ed4111d81b6  vmovaps xmm14, [rsp+0xD0]
00007ed4111d81bf  vmovaps xmm15, [rsp+0xE0]
00007ed4111d81c8  add rsp, 0xF0
00007ed4111d81cf  pop r11
00007ed4111d81d1  pop r10
00007ed4111d81d3  pop r9
00007ed4111d81d5  pop r8
00007ed4111d81d7  pop rsi
00007ed4111d81d8  pop rdi
00007ed4111d81d9  pop rdx
00007ed4111d81da  pop rcx
00007ed4111d81db  pop rax
00007ed4111d81dc  add rsp, 0x08
00007ed4111d81e0  jmp 0x00007ED4111D6930
00007ed4111d81e5  sub rsp, 0x08
00007ed4111d81e9  push rax
00007ed4111d81ea  push rcx
00007ed4111d81eb  push rdx
00007ed4111d81ec  push rdi
00007ed4111d81ed  push rsi
00007ed4111d81ee  push r8
00007ed4111d81f0  push r9
00007ed4111d81f2  push r10
00007ed4111d81f4  push r11
00007ed4111d81f6  sub rsp, 0xF0
00007ed4111d81fd  vmovaps [rsp], xmm0
00007ed4111d8202  vmovaps [rsp+0x10], xmm1
00007ed4111d8208  vmovaps [rsp+0x20], xmm2
00007ed4111d820e  vmovaps [rsp+0x30], xmm3
00007ed4111d8214  vmovaps [rsp+0x40], xmm4
00007ed4111d821a  vmovaps [rsp+0x50], xmm5
00007ed4111d8220  vmovaps [rsp+0x60], xmm6
00007ed4111d8226  vmovaps [rsp+0x70], xmm8
00007ed4111d822c  vmovaps [rsp+0x80], xmm9
00007ed4111d8235  vmovaps [rsp+0x90], xmm10
00007ed4111d823e  vmovaps [rsp+0xA0], xmm11
00007ed4111d8247  vmovaps [rsp+0xB0], xmm12
00007ed4111d8250  vmovaps [rsp+0xC0], xmm13
00007ed4111d8259  vmovaps [rsp+0xD0], xmm14
00007ed4111d8262  vmovaps [rsp+0xE0], xmm15
00007ed4111d826b  sub rsp, 0x40
00007ed4111d826f  lea rdi, [rsp]
00007ed4111d8273  lea rsi, [rsp+0x10]
00007ed4111d8278  lea rdx, [rsp+0x20]
00007ed4111d827d  lea rcx, [rsp+0x30]
00007ed4111d8282  mov r8d, 0x00
00007ed4111d8288  lea r9, [r15+0x3A8]
00007ed4111d828f  movaps [rdi], xmm7
00007ed4111d8292  movaps [rsi], xmm13
00007ed4111d8296  movaps [rdx], xmm1
00007ed4111d8299  movaps [rcx], xmm9
00007ed4111d829d  mov rax, 0x5CA8E4A55A50
00007ed4111d82a7  call rax
00007ed4111d82a9  movaps xmm7, [rsp]
00007ed4111d82ad  add rsp, 0x40
00007ed4111d82b1  vmovaps xmm0, [rsp]
00007ed4111d82b6  vmovaps xmm1, [rsp+0x10]
00007ed4111d82bc  vmovaps xmm2, [rsp+0x20]
00007ed4111d82c2  vmovaps xmm3, [rsp+0x30]
00007ed4111d82c8  vmovaps xmm4, [rsp+0x40]
00007ed4111d82ce  vmovaps xmm5, [rsp+0x50]
00007ed4111d82d4  vmovaps xmm6, [rsp+0x60]
00007ed4111d82da  vmovaps xmm8, [rsp+0x70]
00007ed4111d82e0  vmovaps xmm9, [rsp+0x80]
00007ed4111d82e9  vmovaps xmm10, [rsp+0x90]
00007ed4111d82f2  vmovaps xmm11, [rsp+0xA0]
00007ed4111d82fb  vmovaps xmm12, [rsp+0xB0]
00007ed4111d8304  vmovaps xmm13, [rsp+0xC0]
00007ed4111d830d  vmovaps xmm14, [rsp+0xD0]
00007ed4111d8316  vmovaps xmm15, [rsp+0xE0]
00007ed4111d831f  add rsp, 0xF0
00007ed4111d8326  pop r11
00007ed4111d8328  pop r10
00007ed4111d832a  pop r9
00007ed4111d832c  pop r8
00007ed4111d832e  pop rsi
00007ed4111d832f  pop rdi
00007ed4111d8330  pop rdx
00007ed4111d8331  pop rcx
00007ed4111d8332  pop rax
00007ed4111d8333  add rsp, 0x08
00007ed4111d8337  jmp 0x00007ED4111D6955
00007ed4111d833c  call 0x00007ED4110E3320
00007ed4111d8341  jmp 0x00007ED4111D6978
00007ed4111d8346  call 0x00007ED4110DE950
00007ed4111d834b  jmp 0x00007ED4111D6982
00007ed4111d8350  sub rsp, 0x08
00007ed4111d8354  push rax
00007ed4111d8355  push rcx
00007ed4111d8356  push rdx
00007ed4111d8357  push rdi
00007ed4111d8358  push rsi
00007ed4111d8359  push r8
00007ed4111d835b  push r9
00007ed4111d835d  push r10
00007ed4111d835f  push r11
00007ed4111d8361  sub rsp, 0xF0
00007ed4111d8368  vmovaps [rsp], xmm0
00007ed4111d836d  vmovaps [rsp+0x10], xmm1
00007ed4111d8373  vmovaps [rsp+0x20], xmm3
00007ed4111d8379  vmovaps [rsp+0x30], xmm4
00007ed4111d837f  vmovaps [rsp+0x40], xmm5
00007ed4111d8385  vmovaps [rsp+0x50], xmm6
00007ed4111d838b  vmovaps [rsp+0x60], xmm7
00007ed4111d8391  vmovaps [rsp+0x70], xmm8
00007ed4111d8397  vmovaps [rsp+0x80], xmm9
00007ed4111d83a0  vmovaps [rsp+0x90], xmm10
00007ed4111d83a9  vmovaps [rsp+0xA0], xmm11
00007ed4111d83b2  vmovaps [rsp+0xB0], xmm12
00007ed4111d83bb  vmovaps [rsp+0xC0], xmm13
00007ed4111d83c4  vmovaps [rsp+0xD0], xmm14
00007ed4111d83cd  vmovaps [rsp+0xE0], xmm15
00007ed4111d83d6  sub rsp, 0x40
00007ed4111d83da  lea rdi, [rsp]
00007ed4111d83de  lea rsi, [rsp+0x10]
00007ed4111d83e3  lea rdx, [rsp+0x20]
00007ed4111d83e8  lea rcx, [rsp+0x30]
00007ed4111d83ed  mov r8d, 0x00
00007ed4111d83f3  lea r9, [r15+0x3A8]
00007ed4111d83fa  movaps [rdi], xmm2
00007ed4111d83fd  movaps [rsi], xmm12
00007ed4111d8401  movaps [rdx], xmm6
00007ed4111d8404  movaps [rcx], xmm3
00007ed4111d8407  mov rax, 0x5CA8E4A55A50
00007ed4111d8411  call rax
00007ed4111d8413  movaps xmm2, [rsp]
00007ed4111d8417  add rsp, 0x40
00007ed4111d841b  vmovaps xmm0, [rsp]
00007ed4111d8420  vmovaps xmm1, [rsp+0x10]
00007ed4111d8426  vmovaps xmm3, [rsp+0x20]
00007ed4111d842c  vmovaps xmm4, [rsp+0x30]
00007ed4111d8432  vmovaps xmm5, [rsp+0x40]
00007ed4111d8438  vmovaps xmm6, [rsp+0x50]
00007ed4111d843e  vmovaps xmm7, [rsp+0x60]
00007ed4111d8444  vmovaps xmm8, [rsp+0x70]
00007ed4111d844a  vmovaps xmm9, [rsp+0x80]
00007ed4111d8453  vmovaps xmm10, [rsp+0x90]
00007ed4111d845c  vmovaps xmm11, [rsp+0xA0]
00007ed4111d8465  vmovaps xmm12, [rsp+0xB0]
00007ed4111d846e  vmovaps xmm13, [rsp+0xC0]
00007ed4111d8477  vmovaps xmm14, [rsp+0xD0]
00007ed4111d8480  vmovaps xmm15, [rsp+0xE0]
00007ed4111d8489  add rsp, 0xF0
00007ed4111d8490  pop r11
00007ed4111d8492  pop r10
00007ed4111d8494  pop r9
00007ed4111d8496  pop r8
00007ed4111d8498  pop rsi
00007ed4111d8499  pop rdi
00007ed4111d849a  pop rdx
00007ed4111d849b  pop rcx
00007ed4111d849c  pop rax
00007ed4111d849d  add rsp, 0x08
00007ed4111d84a1  jmp 0x00007ED4111D69C8
00007ed4111d84a6  sub rsp, 0x08
00007ed4111d84aa  push rax
00007ed4111d84ab  push rcx
00007ed4111d84ac  push rdx
00007ed4111d84ad  push rdi
00007ed4111d84ae  push rsi
00007ed4111d84af  push r8
00007ed4111d84b1  push r9
00007ed4111d84b3  push r10
00007ed4111d84b5  push r11
00007ed4111d84b7  sub rsp, 0xF0
00007ed4111d84be  vmovaps [rsp], xmm0
00007ed4111d84c3  vmovaps [rsp+0x10], xmm1
00007ed4111d84c9  vmovaps [rsp+0x20], xmm2
00007ed4111d84cf  vmovaps [rsp+0x30], xmm3
00007ed4111d84d5  vmovaps [rsp+0x40], xmm4
00007ed4111d84db  vmovaps [rsp+0x50], xmm5
00007ed4111d84e1  vmovaps [rsp+0x60], xmm7
00007ed4111d84e7  vmovaps [rsp+0x70], xmm8
00007ed4111d84ed  vmovaps [rsp+0x80], xmm9
00007ed4111d84f6  vmovaps [rsp+0x90], xmm10
00007ed4111d84ff  vmovaps [rsp+0xA0], xmm11
00007ed4111d8508  vmovaps [rsp+0xB0], xmm12
00007ed4111d8511  vmovaps [rsp+0xC0], xmm13
00007ed4111d851a  vmovaps [rsp+0xD0], xmm14
00007ed4111d8523  vmovaps [rsp+0xE0], xmm15
00007ed4111d852c  sub rsp, 0x40
00007ed4111d8530  lea rdi, [rsp]
00007ed4111d8534  lea rsi, [rsp+0x10]
00007ed4111d8539  lea rdx, [rsp+0x20]
00007ed4111d853e  lea rcx, [rsp+0x30]
00007ed4111d8543  mov r8d, 0x00
00007ed4111d8549  lea r9, [r15+0x3A8]
00007ed4111d8550  movaps [rdi], xmm6
00007ed4111d8553  movaps [rsi], xmm10
00007ed4111d8557  movaps [rdx], xmm12
00007ed4111d855b  movaps [rcx], xmm1
00007ed4111d855e  mov rax, 0x5CA8E4A55A50
00007ed4111d8568  call rax
00007ed4111d856a  movaps xmm6, [rsp]
00007ed4111d856e  add rsp, 0x40
00007ed4111d8572  vmovaps xmm0, [rsp]
00007ed4111d8577  vmovaps xmm1, [rsp+0x10]
00007ed4111d857d  vmovaps xmm2, [rsp+0x20]
00007ed4111d8583  vmovaps xmm3, [rsp+0x30]
00007ed4111d8589  vmovaps xmm4, [rsp+0x40]
00007ed4111d858f  vmovaps xmm5, [rsp+0x50]
00007ed4111d8595  vmovaps xmm7, [rsp+0x60]
00007ed4111d859b  vmovaps xmm8, [rsp+0x70]
00007ed4111d85a1  vmovaps xmm9, [rsp+0x80]
00007ed4111d85aa  vmovaps xmm10, [rsp+0x90]
00007ed4111d85b3  vmovaps xmm11, [rsp+0xA0]
00007ed4111d85bc  vmovaps xmm12, [rsp+0xB0]
00007ed4111d85c5  vmovaps xmm13, [rsp+0xC0]
00007ed4111d85ce  vmovaps xmm14, [rsp+0xD0]
00007ed4111d85d7  vmovaps xmm15, [rsp+0xE0]
00007ed4111d85e0  add rsp, 0xF0
00007ed4111d85e7  pop r11
00007ed4111d85e9  pop r10
00007ed4111d85eb  pop r9
00007ed4111d85ed  pop r8
00007ed4111d85ef  pop rsi
00007ed4111d85f0  pop rdi
00007ed4111d85f1  pop rdx
00007ed4111d85f2  pop rcx
00007ed4111d85f3  pop rax
00007ed4111d85f4  add rsp, 0x08
00007ed4111d85f8  jmp 0x00007ED4111D69F6
00007ed4111d85fd  sub rsp, 0x08
00007ed4111d8601  push rax
00007ed4111d8602  push rcx
00007ed4111d8603  push rdx
00007ed4111d8604  push rdi
00007ed4111d8605  push rsi
00007ed4111d8606  push r8
00007ed4111d8608  push r9
00007ed4111d860a  push r10
00007ed4111d860c  push r11
00007ed4111d860e  sub rsp, 0xF0
00007ed4111d8615  vmovaps [rsp], xmm0
00007ed4111d861a  vmovaps [rsp+0x10], xmm1
00007ed4111d8620  vmovaps [rsp+0x20], xmm2
00007ed4111d8626  vmovaps [rsp+0x30], xmm3
00007ed4111d862c  vmovaps [rsp+0x40], xmm4
00007ed4111d8632  vmovaps [rsp+0x50], xmm5
00007ed4111d8638  vmovaps [rsp+0x60], xmm6
00007ed4111d863e  vmovaps [rsp+0x70], xmm7
00007ed4111d8644  vmovaps [rsp+0x80], xmm8
00007ed4111d864d  vmovaps [rsp+0x90], xmm9
00007ed4111d8656  vmovaps [rsp+0xA0], xmm11
00007ed4111d865f  vmovaps [rsp+0xB0], xmm12
00007ed4111d8668  vmovaps [rsp+0xC0], xmm13
00007ed4111d8671  vmovaps [rsp+0xD0], xmm14
00007ed4111d867a  vmovaps [rsp+0xE0], xmm15
00007ed4111d8683  sub rsp, 0x40
00007ed4111d8687  lea rdi, [rsp]
00007ed4111d868b  lea rsi, [rsp+0x10]
00007ed4111d8690  lea rdx, [rsp+0x20]
00007ed4111d8695  lea rcx, [rsp+0x30]
00007ed4111d869a  mov r8d, 0x00
00007ed4111d86a0  lea r9, [r15+0x3A8]
00007ed4111d86a7  movaps [rdi], xmm10
00007ed4111d86ab  movaps [rsi], xmm5
00007ed4111d86ae  movaps [rdx], xmm12
00007ed4111d86b2  movaps [rcx], xmm1
00007ed4111d86b5  mov rax, 0x5CA8E4A55A50
00007ed4111d86bf  call rax
00007ed4111d86c1  movaps xmm10, [rsp]
00007ed4111d86c6  add rsp, 0x40
00007ed4111d86ca  vmovaps xmm0, [rsp]
00007ed4111d86cf  vmovaps xmm1, [rsp+0x10]
00007ed4111d86d5  vmovaps xmm2, [rsp+0x20]
00007ed4111d86db  vmovaps xmm3, [rsp+0x30]
00007ed4111d86e1  vmovaps xmm4, [rsp+0x40]
00007ed4111d86e7  vmovaps xmm5, [rsp+0x50]
00007ed4111d86ed  vmovaps xmm6, [rsp+0x60]
00007ed4111d86f3  vmovaps xmm7, [rsp+0x70]
00007ed4111d86f9  vmovaps xmm8, [rsp+0x80]
00007ed4111d8702  vmovaps xmm9, [rsp+0x90]
00007ed4111d870b  vmovaps xmm11, [rsp+0xA0]
00007ed4111d8714  vmovaps xmm12, [rsp+0xB0]
00007ed4111d871d  vmovaps xmm13, [rsp+0xC0]
00007ed4111d8726  vmovaps xmm14, [rsp+0xD0]
00007ed4111d872f  vmovaps xmm15, [rsp+0xE0]
00007ed4111d8738  add rsp, 0xF0
00007ed4111d873f  pop r11
00007ed4111d8741  pop r10
00007ed4111d8743  pop r9
00007ed4111d8745  pop r8
00007ed4111d8747  pop rsi
00007ed4111d8748  pop rdi
00007ed4111d8749  pop rdx
00007ed4111d874a  pop rcx
00007ed4111d874b  pop rax
00007ed4111d874c  add rsp, 0x08
00007ed4111d8750  jmp 0x00007ED4111D6A25
00007ed4111d8755  sub rsp, 0x08
00007ed4111d8759  push rax
00007ed4111d875a  push rcx
00007ed4111d875b  push rdx
00007ed4111d875c  push rdi
00007ed4111d875d  push rsi
00007ed4111d875e  push r8
00007ed4111d8760  push r9
00007ed4111d8762  push r10
00007ed4111d8764  push r11
00007ed4111d8766  sub rsp, 0xF0
00007ed4111d876d  vmovaps [rsp], xmm0
00007ed4111d8772  vmovaps [rsp+0x10], xmm1
00007ed4111d8778  vmovaps [rsp+0x20], xmm2
00007ed4111d877e  vmovaps [rsp+0x30], xmm3
00007ed4111d8784  vmovaps [rsp+0x40], xmm4
00007ed4111d878a  vmovaps [rsp+0x50], xmm5
00007ed4111d8790  vmovaps [rsp+0x60], xmm6
00007ed4111d8796  vmovaps [rsp+0x70], xmm7
00007ed4111d879c  vmovaps [rsp+0x80], xmm8
00007ed4111d87a5  vmovaps [rsp+0x90], xmm9
00007ed4111d87ae  vmovaps [rsp+0xA0], xmm10
00007ed4111d87b7  vmovaps [rsp+0xB0], xmm11
00007ed4111d87c0  vmovaps [rsp+0xC0], xmm13
00007ed4111d87c9  vmovaps [rsp+0xD0], xmm14
00007ed4111d87d2  vmovaps [rsp+0xE0], xmm15
00007ed4111d87db  sub rsp, 0x40
00007ed4111d87df  lea rdi, [rsp]
00007ed4111d87e3  lea rsi, [rsp+0x10]
00007ed4111d87e8  lea rdx, [rsp+0x20]
00007ed4111d87ed  lea rcx, [rsp+0x30]
00007ed4111d87f2  mov r8d, 0x00
00007ed4111d87f8  lea r9, [r15+0x3A8]
00007ed4111d87ff  movaps [rdi], xmm12
00007ed4111d8803  movaps [rsi], xmm7
00007ed4111d8806  movaps [rdx], xmm15
00007ed4111d880a  movaps [rcx], xmm1
00007ed4111d880d  mov rax, 0x5CA8E4A55A50
00007ed4111d8817  call rax
00007ed4111d8819  movaps xmm12, [rsp]
00007ed4111d881e  add rsp, 0x40
00007ed4111d8822  vmovaps xmm0, [rsp]
00007ed4111d8827  vmovaps xmm1, [rsp+0x10]
00007ed4111d882d  vmovaps xmm2, [rsp+0x20]
00007ed4111d8833  vmovaps xmm3, [rsp+0x30]
00007ed4111d8839  vmovaps xmm4, [rsp+0x40]
00007ed4111d883f  vmovaps xmm5, [rsp+0x50]
00007ed4111d8845  vmovaps xmm6, [rsp+0x60]
00007ed4111d884b  vmovaps xmm7, [rsp+0x70]
00007ed4111d8851  vmovaps xmm8, [rsp+0x80]
00007ed4111d885a  vmovaps xmm9, [rsp+0x90]
00007ed4111d8863  vmovaps xmm10, [rsp+0xA0]
00007ed4111d886c  vmovaps xmm11, [rsp+0xB0]
00007ed4111d8875  vmovaps xmm13, [rsp+0xC0]
00007ed4111d887e  vmovaps xmm14, [rsp+0xD0]
00007ed4111d8887  vmovaps xmm15, [rsp+0xE0]
00007ed4111d8890  add rsp, 0xF0
00007ed4111d8897  pop r11
00007ed4111d8899  pop r10
00007ed4111d889b  pop r9
00007ed4111d889d  pop r8
00007ed4111d889f  pop rsi
00007ed4111d88a0  pop rdi
00007ed4111d88a1  pop rdx
00007ed4111d88a2  pop rcx
00007ed4111d88a3  pop rax
00007ed4111d88a4  add rsp, 0x08
00007ed4111d88a8  jmp 0x00007ED4111D6A4E
00007ed4111d88ad  call 0x00007ED4110D64F0
00007ed4111d88b2  jmp 0x00007ED4111D6A58
00007ed4111d88b7  call 0x00007ED4110E5820
00007ed4111d88bc  jmp 0x00007ED4111D6A62
00007ed4111d88c1  sub rsp, 0x08
00007ed4111d88c5  push rax
00007ed4111d88c6  push rcx
00007ed4111d88c7  push rdx
00007ed4111d88c8  push rdi
00007ed4111d88c9  push rsi
00007ed4111d88ca  push r8
00007ed4111d88cc  push r9
00007ed4111d88ce  push r10
00007ed4111d88d0  push r11
00007ed4111d88d2  sub rsp, 0xF0
00007ed4111d88d9  vmovaps [rsp], xmm0
00007ed4111d88de  vmovaps [rsp+0x10], xmm1
00007ed4111d88e4  vmovaps [rsp+0x20], xmm2
00007ed4111d88ea  vmovaps [rsp+0x30], xmm3
00007ed4111d88f0  vmovaps [rsp+0x40], xmm4
00007ed4111d88f6  vmovaps [rsp+0x50], xmm5
00007ed4111d88fc  vmovaps [rsp+0x60], xmm6
00007ed4111d8902  vmovaps [rsp+0x70], xmm8
00007ed4111d8908  vmovaps [rsp+0x80], xmm9
00007ed4111d8911  vmovaps [rsp+0x90], xmm10
00007ed4111d891a  vmovaps [rsp+0xA0], xmm11
00007ed4111d8923  vmovaps [rsp+0xB0], xmm12
00007ed4111d892c  vmovaps [rsp+0xC0], xmm13
00007ed4111d8935  vmovaps [rsp+0xD0], xmm14
00007ed4111d893e  vmovaps [rsp+0xE0], xmm15
00007ed4111d8947  sub rsp, 0x40
00007ed4111d894b  lea rdi, [rsp]
00007ed4111d894f  lea rsi, [rsp+0x10]
00007ed4111d8954  lea rdx, [rsp+0x20]
00007ed4111d8959  lea rcx, [rsp+0x30]
00007ed4111d895e  mov r8d, 0x00
00007ed4111d8964  lea r9, [r15+0x3A8]
00007ed4111d896b  movaps [rdi], xmm7
00007ed4111d896e  movaps [rsi], xmm2
00007ed4111d8971  movaps [rdx], xmm9
00007ed4111d8975  movaps [rcx], xmm11
00007ed4111d8979  mov rax, 0x5CA8E4A55A50
00007ed4111d8983  call rax
00007ed4111d8985  movaps xmm7, [rsp]
00007ed4111d8989  add rsp, 0x40
00007ed4111d898d  vmovaps xmm0, [rsp]
00007ed4111d8992  vmovaps xmm1, [rsp+0x10]
00007ed4111d8998  vmovaps xmm2, [rsp+0x20]
00007ed4111d899e  vmovaps xmm3, [rsp+0x30]
00007ed4111d89a4  vmovaps xmm4, [rsp+0x40]
00007ed4111d89aa  vmovaps xmm5, [rsp+0x50]
00007ed4111d89b0  vmovaps xmm6, [rsp+0x60]
00007ed4111d89b6  vmovaps xmm8, [rsp+0x70]
00007ed4111d89bc  vmovaps xmm9, [rsp+0x80]
00007ed4111d89c5  vmovaps xmm10, [rsp+0x90]
00007ed4111d89ce  vmovaps xmm11, [rsp+0xA0]
00007ed4111d89d7  vmovaps xmm12, [rsp+0xB0]
00007ed4111d89e0  vmovaps xmm13, [rsp+0xC0]
00007ed4111d89e9  vmovaps xmm14, [rsp+0xD0]
00007ed4111d89f2  vmovaps xmm15, [rsp+0xE0]
00007ed4111d89fb  add rsp, 0xF0
00007ed4111d8a02  pop r11
00007ed4111d8a04  pop r10
00007ed4111d8a06  pop r9
00007ed4111d8a08  pop r8
00007ed4111d8a0a  pop rsi
00007ed4111d8a0b  pop rdi
00007ed4111d8a0c  pop rdx
00007ed4111d8a0d  pop rcx
00007ed4111d8a0e  pop rax
00007ed4111d8a0f  add rsp, 0x08
00007ed4111d8a13  jmp 0x00007ED4111D6A96
00007ed4111d8a18  sub rsp, 0x08
00007ed4111d8a1c  push rax
00007ed4111d8a1d  push rcx
00007ed4111d8a1e  push rdx
00007ed4111d8a1f  push rdi
00007ed4111d8a20  push rsi
00007ed4111d8a21  push r8
00007ed4111d8a23  push r9
00007ed4111d8a25  push r10
00007ed4111d8a27  push r11
00007ed4111d8a29  sub rsp, 0xF0
00007ed4111d8a30  vmovaps [rsp], xmm0
00007ed4111d8a35  vmovaps [rsp+0x10], xmm1
00007ed4111d8a3b  vmovaps [rsp+0x20], xmm2
00007ed4111d8a41  vmovaps [rsp+0x30], xmm3
00007ed4111d8a47  vmovaps [rsp+0x40], xmm4
00007ed4111d8a4d  vmovaps [rsp+0x50], xmm5
00007ed4111d8a53  vmovaps [rsp+0x60], xmm6
00007ed4111d8a59  vmovaps [rsp+0x70], xmm7
00007ed4111d8a5f  vmovaps [rsp+0x80], xmm8
00007ed4111d8a68  vmovaps [rsp+0x90], xmm10
00007ed4111d8a71  vmovaps [rsp+0xA0], xmm11
00007ed4111d8a7a  vmovaps [rsp+0xB0], xmm12
00007ed4111d8a83  vmovaps [rsp+0xC0], xmm13
00007ed4111d8a8c  vmovaps [rsp+0xD0], xmm14
00007ed4111d8a95  vmovaps [rsp+0xE0], xmm15
00007ed4111d8a9e  sub rsp, 0x40
00007ed4111d8aa2  lea rdi, [rsp]
00007ed4111d8aa6  lea rsi, [rsp+0x10]
00007ed4111d8aab  lea rdx, [rsp+0x20]
00007ed4111d8ab0  lea rcx, [rsp+0x30]
00007ed4111d8ab5  mov r8d, 0x00
00007ed4111d8abb  lea r9, [r15+0x3A8]
00007ed4111d8ac2  movaps [rdi], xmm9
00007ed4111d8ac6  movaps [rsi], xmm6
00007ed4111d8ac9  movaps [rdx], xmm1
00007ed4111d8acc  movaps [rcx], xmm11
00007ed4111d8ad0  mov rax, 0x5CA8E4A55A50
00007ed4111d8ada  call rax
00007ed4111d8adc  movaps xmm9, [rsp]
00007ed4111d8ae1  add rsp, 0x40
00007ed4111d8ae5  vmovaps xmm0, [rsp]
00007ed4111d8aea  vmovaps xmm1, [rsp+0x10]
00007ed4111d8af0  vmovaps xmm2, [rsp+0x20]
00007ed4111d8af6  vmovaps xmm3, [rsp+0x30]
00007ed4111d8afc  vmovaps xmm4, [rsp+0x40]
00007ed4111d8b02  vmovaps xmm5, [rsp+0x50]
00007ed4111d8b08  vmovaps xmm6, [rsp+0x60]
00007ed4111d8b0e  vmovaps xmm7, [rsp+0x70]
00007ed4111d8b14  vmovaps xmm8, [rsp+0x80]
00007ed4111d8b1d  vmovaps xmm10, [rsp+0x90]
00007ed4111d8b26  vmovaps xmm11, [rsp+0xA0]
00007ed4111d8b2f  vmovaps xmm12, [rsp+0xB0]
00007ed4111d8b38  vmovaps xmm13, [rsp+0xC0]
00007ed4111d8b41  vmovaps xmm14, [rsp+0xD0]
00007ed4111d8b4a  vmovaps xmm15, [rsp+0xE0]
00007ed4111d8b53  add rsp, 0xF0
00007ed4111d8b5a  pop r11
00007ed4111d8b5c  pop r10
00007ed4111d8b5e  pop r9
00007ed4111d8b60  pop r8
00007ed4111d8b62  pop rsi
00007ed4111d8b63  pop rdi
00007ed4111d8b64  pop rdx
00007ed4111d8b65  pop rcx
00007ed4111d8b66  pop rax
00007ed4111d8b67  add rsp, 0x08
00007ed4111d8b6b  jmp 0x00007ED4111D6ABC
00007ed4111d8b70  sub rsp, 0x08
00007ed4111d8b74  push rax
00007ed4111d8b75  push rcx
00007ed4111d8b76  push rdx
00007ed4111d8b77  push rdi
00007ed4111d8b78  push rsi
00007ed4111d8b79  push r8
00007ed4111d8b7b  push r9
00007ed4111d8b7d  push r10
00007ed4111d8b7f  push r11
00007ed4111d8b81  sub rsp, 0xF0
00007ed4111d8b88  vmovaps [rsp], xmm0
00007ed4111d8b8d  vmovaps [rsp+0x10], xmm1
00007ed4111d8b93  vmovaps [rsp+0x20], xmm2
00007ed4111d8b99  vmovaps [rsp+0x30], xmm3
00007ed4111d8b9f  vmovaps [rsp+0x40], xmm4
00007ed4111d8ba5  vmovaps [rsp+0x50], xmm5
00007ed4111d8bab  vmovaps [rsp+0x60], xmm6
00007ed4111d8bb1  vmovaps [rsp+0x70], xmm7
00007ed4111d8bb7  vmovaps [rsp+0x80], xmm8
00007ed4111d8bc0  vmovaps [rsp+0x90], xmm9
00007ed4111d8bc9  vmovaps [rsp+0xA0], xmm10
00007ed4111d8bd2  vmovaps [rsp+0xB0], xmm12
00007ed4111d8bdb  vmovaps [rsp+0xC0], xmm13
00007ed4111d8be4  vmovaps [rsp+0xD0], xmm14
00007ed4111d8bed  vmovaps [rsp+0xE0], xmm15
00007ed4111d8bf6  sub rsp, 0x40
00007ed4111d8bfa  lea rdi, [rsp]
00007ed4111d8bfe  lea rsi, [rsp+0x10]
00007ed4111d8c03  lea rdx, [rsp+0x20]
00007ed4111d8c08  lea rcx, [rsp+0x30]
00007ed4111d8c0d  mov r8d, 0x00
00007ed4111d8c13  lea r9, [r15+0x3A8]
00007ed4111d8c1a  movaps [rdi], xmm11
00007ed4111d8c1e  movaps [rsi], xmm10
00007ed4111d8c22  movaps [rdx], xmm8
00007ed4111d8c26  movaps [rcx], xmm1
00007ed4111d8c29  mov rax, 0x5CA8E4A55A50
00007ed4111d8c33  call rax
00007ed4111d8c35  movaps xmm11, [rsp]
00007ed4111d8c3a  add rsp, 0x40
00007ed4111d8c3e  vmovaps xmm0, [rsp]
00007ed4111d8c43  vmovaps xmm1, [rsp+0x10]
00007ed4111d8c49  vmovaps xmm2, [rsp+0x20]
00007ed4111d8c4f  vmovaps xmm3, [rsp+0x30]
00007ed4111d8c55  vmovaps xmm4, [rsp+0x40]
00007ed4111d8c5b  vmovaps xmm5, [rsp+0x50]
00007ed4111d8c61  vmovaps xmm6, [rsp+0x60]
00007ed4111d8c67  vmovaps xmm7, [rsp+0x70]
00007ed4111d8c6d  vmovaps xmm8, [rsp+0x80]
00007ed4111d8c76  vmovaps xmm9, [rsp+0x90]
00007ed4111d8c7f  vmovaps xmm10, [rsp+0xA0]
00007ed4111d8c88  vmovaps xmm12, [rsp+0xB0]
00007ed4111d8c91  vmovaps xmm13, [rsp+0xC0]
00007ed4111d8c9a  vmovaps xmm14, [rsp+0xD0]
00007ed4111d8ca3  vmovaps xmm15, [rsp+0xE0]
00007ed4111d8cac  add rsp, 0xF0
00007ed4111d8cb3  pop r11
00007ed4111d8cb5  pop r10
00007ed4111d8cb7  pop r9
00007ed4111d8cb9  pop r8
00007ed4111d8cbb  pop rsi
00007ed4111d8cbc  pop rdi
00007ed4111d8cbd  pop rdx
00007ed4111d8cbe  pop rcx
00007ed4111d8cbf  pop rax
00007ed4111d8cc0  add rsp, 0x08
00007ed4111d8cc4  jmp 0x00007ED4111D6AE2
00007ed4111d8cc9  sub rsp, 0x08
00007ed4111d8ccd  push rax
00007ed4111d8cce  push rcx
00007ed4111d8ccf  push rdx
00007ed4111d8cd0  push rdi
00007ed4111d8cd1  push rsi
00007ed4111d8cd2  push r8
00007ed4111d8cd4  push r9
00007ed4111d8cd6  push r10
00007ed4111d8cd8  push r11
00007ed4111d8cda  sub rsp, 0xF0
00007ed4111d8ce1  vmovaps [rsp], xmm0
00007ed4111d8ce6  vmovaps [rsp+0x10], xmm1
00007ed4111d8cec  vmovaps [rsp+0x20], xmm2
00007ed4111d8cf2  vmovaps [rsp+0x30], xmm3
00007ed4111d8cf8  vmovaps [rsp+0x40], xmm4
00007ed4111d8cfe  vmovaps [rsp+0x50], xmm5
00007ed4111d8d04  vmovaps [rsp+0x60], xmm6
00007ed4111d8d0a  vmovaps [rsp+0x70], xmm7
00007ed4111d8d10  vmovaps [rsp+0x80], xmm8
00007ed4111d8d19  vmovaps [rsp+0x90], xmm9
00007ed4111d8d22  vmovaps [rsp+0xA0], xmm11
00007ed4111d8d2b  vmovaps [rsp+0xB0], xmm12
00007ed4111d8d34  vmovaps [rsp+0xC0], xmm13
00007ed4111d8d3d  vmovaps [rsp+0xD0], xmm14
00007ed4111d8d46  vmovaps [rsp+0xE0], xmm15
00007ed4111d8d4f  sub rsp, 0x40
00007ed4111d8d53  lea rdi, [rsp]
00007ed4111d8d57  lea rsi, [rsp+0x10]
00007ed4111d8d5c  lea rdx, [rsp+0x20]
00007ed4111d8d61  lea rcx, [rsp+0x30]
00007ed4111d8d66  mov r8d, 0x00
00007ed4111d8d6c  lea r9, [r15+0x3A8]
00007ed4111d8d73  movaps [rdi], xmm10
00007ed4111d8d77  movaps [rsi], xmm12
00007ed4111d8d7b  movaps [rdx], xmm13
00007ed4111d8d7f  movaps [rcx], xmm1
00007ed4111d8d82  mov rax, 0x5CA8E4A55A50
00007ed4111d8d8c  call rax
00007ed4111d8d8e  movaps xmm10, [rsp]
00007ed4111d8d93  add rsp, 0x40
00007ed4111d8d97  vmovaps xmm0, [rsp]
00007ed4111d8d9c  vmovaps xmm1, [rsp+0x10]
00007ed4111d8da2  vmovaps xmm2, [rsp+0x20]
00007ed4111d8da8  vmovaps xmm3, [rsp+0x30]
00007ed4111d8dae  vmovaps xmm4, [rsp+0x40]
00007ed4111d8db4  vmovaps xmm5, [rsp+0x50]
00007ed4111d8dba  vmovaps xmm6, [rsp+0x60]
00007ed4111d8dc0  vmovaps xmm7, [rsp+0x70]
00007ed4111d8dc6  vmovaps xmm8, [rsp+0x80]
00007ed4111d8dcf  vmovaps xmm9, [rsp+0x90]
00007ed4111d8dd8  vmovaps xmm11, [rsp+0xA0]
00007ed4111d8de1  vmovaps xmm12, [rsp+0xB0]
00007ed4111d8dea  vmovaps xmm13, [rsp+0xC0]
00007ed4111d8df3  vmovaps xmm14, [rsp+0xD0]
00007ed4111d8dfc  vmovaps xmm15, [rsp+0xE0]
00007ed4111d8e05  add rsp, 0xF0
00007ed4111d8e0c  pop r11
00007ed4111d8e0e  pop r10
00007ed4111d8e10  pop r9
00007ed4111d8e12  pop r8
00007ed4111d8e14  pop rsi
00007ed4111d8e15  pop rdi
00007ed4111d8e16  pop rdx
00007ed4111d8e17  pop rcx
00007ed4111d8e18  pop rax
00007ed4111d8e19  add rsp, 0x08
00007ed4111d8e1d  jmp 0x00007ED4111D6B08
00007ed4111d8e22  call 0x00007ED4110D64F0
00007ed4111d8e27  jmp 0x00007ED4111D6B12
00007ed4111d8e2c  call 0x00007ED4110E3320
00007ed4111d8e31  jmp 0x00007ED4111D6B1C
00007ed4111d8e36  sub rsp, 0x08
00007ed4111d8e3a  push rax
00007ed4111d8e3b  push rcx
00007ed4111d8e3c  push rdx
00007ed4111d8e3d  push rdi
00007ed4111d8e3e  push rsi
00007ed4111d8e3f  push r8
00007ed4111d8e41  push r9
00007ed4111d8e43  push r10
00007ed4111d8e45  push r11
00007ed4111d8e47  sub rsp, 0xF0
00007ed4111d8e4e  vmovaps [rsp], xmm0
00007ed4111d8e53  vmovaps [rsp+0x10], xmm1
00007ed4111d8e59  vmovaps [rsp+0x20], xmm2
00007ed4111d8e5f  vmovaps [rsp+0x30], xmm3
00007ed4111d8e65  vmovaps [rsp+0x40], xmm4
00007ed4111d8e6b  vmovaps [rsp+0x50], xmm5
00007ed4111d8e71  vmovaps [rsp+0x60], xmm6
00007ed4111d8e77  vmovaps [rsp+0x70], xmm7
00007ed4111d8e7d  vmovaps [rsp+0x80], xmm9
00007ed4111d8e86  vmovaps [rsp+0x90], xmm10
00007ed4111d8e8f  vmovaps [rsp+0xA0], xmm11
00007ed4111d8e98  vmovaps [rsp+0xB0], xmm12
00007ed4111d8ea1  vmovaps [rsp+0xC0], xmm13
00007ed4111d8eaa  vmovaps [rsp+0xD0], xmm14
00007ed4111d8eb3  vmovaps [rsp+0xE0], xmm15
00007ed4111d8ebc  sub rsp, 0x40
00007ed4111d8ec0  lea rdi, [rsp]
00007ed4111d8ec4  lea rsi, [rsp+0x10]
00007ed4111d8ec9  lea rdx, [rsp+0x20]
00007ed4111d8ece  lea rcx, [rsp+0x30]
00007ed4111d8ed3  mov r8d, 0x00
00007ed4111d8ed9  lea r9, [r15+0x3A8]
00007ed4111d8ee0  movaps [rdi], xmm8
00007ed4111d8ee4  movaps [rsi], xmm7
00007ed4111d8ee7  movaps [rdx], xmm4
00007ed4111d8eea  movaps [rcx], xmm12
00007ed4111d8eee  mov rax, 0x5CA8E4A55A50
00007ed4111d8ef8  call rax
00007ed4111d8efa  movaps xmm8, [rsp]
00007ed4111d8eff  add rsp, 0x40
00007ed4111d8f03  vmovaps xmm0, [rsp]
00007ed4111d8f08  vmovaps xmm1, [rsp+0x10]
00007ed4111d8f0e  vmovaps xmm2, [rsp+0x20]
00007ed4111d8f14  vmovaps xmm3, [rsp+0x30]
00007ed4111d8f1a  vmovaps xmm4, [rsp+0x40]
00007ed4111d8f20  vmovaps xmm5, [rsp+0x50]
00007ed4111d8f26  vmovaps xmm6, [rsp+0x60]
00007ed4111d8f2c  vmovaps xmm7, [rsp+0x70]
00007ed4111d8f32  vmovaps xmm9, [rsp+0x80]
00007ed4111d8f3b  vmovaps xmm10, [rsp+0x90]
00007ed4111d8f44  vmovaps xmm11, [rsp+0xA0]
00007ed4111d8f4d  vmovaps xmm12, [rsp+0xB0]
00007ed4111d8f56  vmovaps xmm13, [rsp+0xC0]
00007ed4111d8f5f  vmovaps xmm14, [rsp+0xD0]
00007ed4111d8f68  vmovaps xmm15, [rsp+0xE0]
00007ed4111d8f71  add rsp, 0xF0
00007ed4111d8f78  pop r11
00007ed4111d8f7a  pop r10
00007ed4111d8f7c  pop r9
00007ed4111d8f7e  pop r8
00007ed4111d8f80  pop rsi
00007ed4111d8f81  pop rdi
00007ed4111d8f82  pop rdx
00007ed4111d8f83  pop rcx
00007ed4111d8f84  pop rax
00007ed4111d8f85  add rsp, 0x08
00007ed4111d8f89  jmp 0x00007ED4111D6B45
00007ed4111d8f8e  sub rsp, 0x08
00007ed4111d8f92  push rax
00007ed4111d8f93  push rcx
00007ed4111d8f94  push rdx
00007ed4111d8f95  push rdi
00007ed4111d8f96  push rsi
00007ed4111d8f97  push r8
00007ed4111d8f99  push r9
00007ed4111d8f9b  push r10
00007ed4111d8f9d  push r11
00007ed4111d8f9f  sub rsp, 0xF0
00007ed4111d8fa6  vmovaps [rsp], xmm0
00007ed4111d8fab  vmovaps [rsp+0x10], xmm1
00007ed4111d8fb1  vmovaps [rsp+0x20], xmm2
00007ed4111d8fb7  vmovaps [rsp+0x30], xmm3
00007ed4111d8fbd  vmovaps [rsp+0x40], xmm4
00007ed4111d8fc3  vmovaps [rsp+0x50], xmm5
00007ed4111d8fc9  vmovaps [rsp+0x60], xmm6
00007ed4111d8fcf  vmovaps [rsp+0x70], xmm8
00007ed4111d8fd5  vmovaps [rsp+0x80], xmm9
00007ed4111d8fde  vmovaps [rsp+0x90], xmm10
00007ed4111d8fe7  vmovaps [rsp+0xA0], xmm11
00007ed4111d8ff0  vmovaps [rsp+0xB0], xmm12
00007ed4111d8ff9  vmovaps [rsp+0xC0], xmm13
00007ed4111d9002  vmovaps [rsp+0xD0], xmm14
00007ed4111d900b  vmovaps [rsp+0xE0], xmm15
00007ed4111d9014  sub rsp, 0x40
00007ed4111d9018  lea rdi, [rsp]
00007ed4111d901c  lea rsi, [rsp+0x10]
00007ed4111d9021  lea rdx, [rsp+0x20]
00007ed4111d9026  lea rcx, [rsp+0x30]
00007ed4111d902b  mov r8d, 0x00
00007ed4111d9031  lea r9, [r15+0x3A8]
00007ed4111d9038  movaps [rdi], xmm7
00007ed4111d903b  movaps [rsi], xmm9
00007ed4111d903f  movaps [rdx], xmm14
00007ed4111d9043  movaps [rcx], xmm12
00007ed4111d9047  mov rax, 0x5CA8E4A55A50
00007ed4111d9051  call rax
00007ed4111d9053  movaps xmm7, [rsp]
00007ed4111d9057  add rsp, 0x40
00007ed4111d905b  vmovaps xmm0, [rsp]
00007ed4111d9060  vmovaps xmm1, [rsp+0x10]
00007ed4111d9066  vmovaps xmm2, [rsp+0x20]
00007ed4111d906c  vmovaps xmm3, [rsp+0x30]
00007ed4111d9072  vmovaps xmm4, [rsp+0x40]
00007ed4111d9078  vmovaps xmm5, [rsp+0x50]
00007ed4111d907e  vmovaps xmm6, [rsp+0x60]
00007ed4111d9084  vmovaps xmm8, [rsp+0x70]
00007ed4111d908a  vmovaps xmm9, [rsp+0x80]
00007ed4111d9093  vmovaps xmm10, [rsp+0x90]
00007ed4111d909c  vmovaps xmm11, [rsp+0xA0]
00007ed4111d90a5  vmovaps xmm12, [rsp+0xB0]
00007ed4111d90ae  vmovaps xmm13, [rsp+0xC0]
00007ed4111d90b7  vmovaps xmm14, [rsp+0xD0]
00007ed4111d90c0  vmovaps xmm15, [rsp+0xE0]
00007ed4111d90c9  add rsp, 0xF0
00007ed4111d90d0  pop r11
00007ed4111d90d2  pop r10
00007ed4111d90d4  pop r9
00007ed4111d90d6  pop r8
00007ed4111d90d8  pop rsi
00007ed4111d90d9  pop rdi
00007ed4111d90da  pop rdx
00007ed4111d90db  pop rcx
00007ed4111d90dc  pop rax
00007ed4111d90dd  add rsp, 0x08
00007ed4111d90e1  jmp 0x00007ED4111D6B6D
00007ed4111d90e6  sub rsp, 0x08
00007ed4111d90ea  push rax
00007ed4111d90eb  push rcx
00007ed4111d90ec  push rdx
00007ed4111d90ed  push rdi
00007ed4111d90ee  push rsi
00007ed4111d90ef  push r8
00007ed4111d90f1  push r9
00007ed4111d90f3  push r10
00007ed4111d90f5  push r11
00007ed4111d90f7  sub rsp, 0xF0
00007ed4111d90fe  vmovaps [rsp], xmm0
00007ed4111d9103  vmovaps [rsp+0x10], xmm1
00007ed4111d9109  vmovaps [rsp+0x20], xmm2
00007ed4111d910f  vmovaps [rsp+0x30], xmm3
00007ed4111d9115  vmovaps [rsp+0x40], xmm4
00007ed4111d911b  vmovaps [rsp+0x50], xmm5
00007ed4111d9121  vmovaps [rsp+0x60], xmm6
00007ed4111d9127  vmovaps [rsp+0x70], xmm7
00007ed4111d912d  vmovaps [rsp+0x80], xmm8
00007ed4111d9136  vmovaps [rsp+0x90], xmm9
00007ed4111d913f  vmovaps [rsp+0xA0], xmm10
00007ed4111d9148  vmovaps [rsp+0xB0], xmm11
00007ed4111d9151  vmovaps [rsp+0xC0], xmm13
00007ed4111d915a  vmovaps [rsp+0xD0], xmm14
00007ed4111d9163  vmovaps [rsp+0xE0], xmm15
00007ed4111d916c  sub rsp, 0x40
00007ed4111d9170  lea rdi, [rsp]
00007ed4111d9174  lea rsi, [rsp+0x10]
00007ed4111d9179  lea rdx, [rsp+0x20]
00007ed4111d917e  lea rcx, [rsp+0x30]
00007ed4111d9183  mov r8d, 0x00
00007ed4111d9189  lea r9, [r15+0x3A8]
00007ed4111d9190  movaps [rdi], xmm12
00007ed4111d9194  movaps [rsi], xmm11
00007ed4111d9198  movaps [rdx], xmm15
00007ed4111d919c  movaps [rcx], xmm14
00007ed4111d91a0  mov rax, 0x5CA8E4A55A50
00007ed4111d91aa  call rax
00007ed4111d91ac  movaps xmm12, [rsp]
00007ed4111d91b1  add rsp, 0x40
00007ed4111d91b5  vmovaps xmm0, [rsp]
00007ed4111d91ba  vmovaps xmm1, [rsp+0x10]
00007ed4111d91c0  vmovaps xmm2, [rsp+0x20]
00007ed4111d91c6  vmovaps xmm3, [rsp+0x30]
00007ed4111d91cc  vmovaps xmm4, [rsp+0x40]
00007ed4111d91d2  vmovaps xmm5, [rsp+0x50]
00007ed4111d91d8  vmovaps xmm6, [rsp+0x60]
00007ed4111d91de  vmovaps xmm7, [rsp+0x70]
00007ed4111d91e4  vmovaps xmm8, [rsp+0x80]
00007ed4111d91ed  vmovaps xmm9, [rsp+0x90]
00007ed4111d91f6  vmovaps xmm10, [rsp+0xA0]
00007ed4111d91ff  vmovaps xmm11, [rsp+0xB0]
00007ed4111d9208  vmovaps xmm13, [rsp+0xC0]
00007ed4111d9211  vmovaps xmm14, [rsp+0xD0]
00007ed4111d921a  vmovaps xmm15, [rsp+0xE0]
00007ed4111d9223  add rsp, 0xF0
00007ed4111d922a  pop r11
00007ed4111d922c  pop r10
00007ed4111d922e  pop r9
00007ed4111d9230  pop r8
00007ed4111d9232  pop rsi
00007ed4111d9233  pop rdi
00007ed4111d9234  pop rdx
00007ed4111d9235  pop rcx
00007ed4111d9236  pop rax
00007ed4111d9237  add rsp, 0x08
00007ed4111d923b  jmp 0x00007ED4111D6B96
00007ed4111d9240  sub rsp, 0x08
00007ed4111d9244  push rax
00007ed4111d9245  push rcx
00007ed4111d9246  push rdx
00007ed4111d9247  push rdi
00007ed4111d9248  push rsi
00007ed4111d9249  push r8
00007ed4111d924b  push r9
00007ed4111d924d  push r10
00007ed4111d924f  push r11
00007ed4111d9251  sub rsp, 0xF0
00007ed4111d9258  vmovaps [rsp], xmm0
00007ed4111d925d  vmovaps [rsp+0x10], xmm1
00007ed4111d9263  vmovaps [rsp+0x20], xmm2
00007ed4111d9269  vmovaps [rsp+0x30], xmm3
00007ed4111d926f  vmovaps [rsp+0x40], xmm4
00007ed4111d9275  vmovaps [rsp+0x50], xmm5
00007ed4111d927b  vmovaps [rsp+0x60], xmm6
00007ed4111d9281  vmovaps [rsp+0x70], xmm7
00007ed4111d9287  vmovaps [rsp+0x80], xmm8
00007ed4111d9290  vmovaps [rsp+0x90], xmm9
00007ed4111d9299  vmovaps [rsp+0xA0], xmm10
00007ed4111d92a2  vmovaps [rsp+0xB0], xmm12
00007ed4111d92ab  vmovaps [rsp+0xC0], xmm13
00007ed4111d92b4  vmovaps [rsp+0xD0], xmm14
00007ed4111d92bd  vmovaps [rsp+0xE0], xmm15
00007ed4111d92c6  sub rsp, 0x40
00007ed4111d92ca  lea rdi, [rsp]
00007ed4111d92ce  lea rsi, [rsp+0x10]
00007ed4111d92d3  lea rdx, [rsp+0x20]
00007ed4111d92d8  lea rcx, [rsp+0x30]
00007ed4111d92dd  mov r8d, 0x00
00007ed4111d92e3  lea r9, [r15+0x3A8]
00007ed4111d92ea  movaps [rdi], xmm11
00007ed4111d92ee  movaps [rsi], xmm10
00007ed4111d92f2  movaps [rdx], xmm13
00007ed4111d92f6  movaps [rcx], xmm15
00007ed4111d92fa  mov rax, 0x5CA8E4A55A50
00007ed4111d9304  call rax
00007ed4111d9306  movaps xmm11, [rsp]
00007ed4111d930b  add rsp, 0x40
00007ed4111d930f  vmovaps xmm0, [rsp]
00007ed4111d9314  vmovaps xmm1, [rsp+0x10]
00007ed4111d931a  vmovaps xmm2, [rsp+0x20]
00007ed4111d9320  vmovaps xmm3, [rsp+0x30]
00007ed4111d9326  vmovaps xmm4, [rsp+0x40]
00007ed4111d932c  vmovaps xmm5, [rsp+0x50]
00007ed4111d9332  vmovaps xmm6, [rsp+0x60]
00007ed4111d9338  vmovaps xmm7, [rsp+0x70]
00007ed4111d933e  vmovaps xmm8, [rsp+0x80]
00007ed4111d9347  vmovaps xmm9, [rsp+0x90]
00007ed4111d9350  vmovaps xmm10, [rsp+0xA0]
00007ed4111d9359  vmovaps xmm12, [rsp+0xB0]
00007ed4111d9362  vmovaps xmm13, [rsp+0xC0]
00007ed4111d936b  vmovaps xmm14, [rsp+0xD0]
00007ed4111d9374  vmovaps xmm15, [rsp+0xE0]
00007ed4111d937d  add rsp, 0xF0
00007ed4111d9384  pop r11
00007ed4111d9386  pop r10
00007ed4111d9388  pop r9
00007ed4111d938a  pop r8
00007ed4111d938c  pop rsi
00007ed4111d938d  pop rdi
00007ed4111d938e  pop rdx
00007ed4111d938f  pop rcx
00007ed4111d9390  pop rax
00007ed4111d9391  add rsp, 0x08
00007ed4111d9395  jmp 0x00007ED4111D6BBF
00007ed4111d939a  call 0x00007ED4110E5820
00007ed4111d939f  jmp 0x00007ED4111D6BCC
00007ed4111d93a4  call 0x00007ED4110E45A0
00007ed4111d93a9  jmp 0x00007ED4111D6BD9
00007ed4111d93ae  sub rsp, 0x08
00007ed4111d93b2  push rax
00007ed4111d93b3  push rcx
00007ed4111d93b4  push rdx
00007ed4111d93b5  push rdi
00007ed4111d93b6  push rsi
00007ed4111d93b7  push r8
00007ed4111d93b9  push r9
00007ed4111d93bb  push r10
00007ed4111d93bd  push r11
00007ed4111d93bf  sub rsp, 0xF0
00007ed4111d93c6  vmovaps [rsp], xmm0
00007ed4111d93cb  vmovaps [rsp+0x10], xmm1
00007ed4111d93d1  vmovaps [rsp+0x20], xmm2
00007ed4111d93d7  vmovaps [rsp+0x30], xmm3
00007ed4111d93dd  vmovaps [rsp+0x40], xmm4
00007ed4111d93e3  vmovaps [rsp+0x50], xmm5
00007ed4111d93e9  vmovaps [rsp+0x60], xmm6
00007ed4111d93ef  vmovaps [rsp+0x70], xmm7
00007ed4111d93f5  vmovaps [rsp+0x80], xmm8
00007ed4111d93fe  vmovaps [rsp+0x90], xmm9
00007ed4111d9407  vmovaps [rsp+0xA0], xmm11
00007ed4111d9410  vmovaps [rsp+0xB0], xmm12
00007ed4111d9419  vmovaps [rsp+0xC0], xmm13
00007ed4111d9422  vmovaps [rsp+0xD0], xmm14
00007ed4111d942b  vmovaps [rsp+0xE0], xmm15
00007ed4111d9434  sub rsp, 0x40
00007ed4111d9438  lea rdi, [rsp]
00007ed4111d943c  lea rsi, [rsp+0x10]
00007ed4111d9441  lea rdx, [rsp+0x20]
00007ed4111d9446  lea rcx, [rsp+0x30]
00007ed4111d944b  mov r8d, 0x00
00007ed4111d9451  lea r9, [r15+0x3A8]
00007ed4111d9458  movaps [rdi], xmm10
00007ed4111d945c  movaps [rsi], xmm8
00007ed4111d9460  movaps [rdx], xmm1
00007ed4111d9463  movaps [rcx], xmm13
00007ed4111d9467  mov rax, 0x5CA8E4A55A50
00007ed4111d9471  call rax
00007ed4111d9473  movaps xmm10, [rsp]
00007ed4111d9478  add rsp, 0x40
00007ed4111d947c  vmovaps xmm0, [rsp]
00007ed4111d9481  vmovaps xmm1, [rsp+0x10]
00007ed4111d9487  vmovaps xmm2, [rsp+0x20]
00007ed4111d948d  vmovaps xmm3, [rsp+0x30]
00007ed4111d9493  vmovaps xmm4, [rsp+0x40]
00007ed4111d9499  vmovaps xmm5, [rsp+0x50]
00007ed4111d949f  vmovaps xmm6, [rsp+0x60]
00007ed4111d94a5  vmovaps xmm7, [rsp+0x70]
00007ed4111d94ab  vmovaps xmm8, [rsp+0x80]
00007ed4111d94b4  vmovaps xmm9, [rsp+0x90]
00007ed4111d94bd  vmovaps xmm11, [rsp+0xA0]
00007ed4111d94c6  vmovaps xmm12, [rsp+0xB0]
00007ed4111d94cf  vmovaps xmm13, [rsp+0xC0]
00007ed4111d94d8  vmovaps xmm14, [rsp+0xD0]
00007ed4111d94e1  vmovaps xmm15, [rsp+0xE0]
00007ed4111d94ea  add rsp, 0xF0
00007ed4111d94f1  pop r11
00007ed4111d94f3  pop r10
00007ed4111d94f5  pop r9
00007ed4111d94f7  pop r8
00007ed4111d94f9  pop rsi
00007ed4111d94fa  pop rdi
00007ed4111d94fb  pop rdx
00007ed4111d94fc  pop rcx
00007ed4111d94fd  pop rax
00007ed4111d94fe  add rsp, 0x08
00007ed4111d9502  jmp 0x00007ED4111D6C0F
00007ed4111d9507  call 0x00007ED4110D64F0
00007ed4111d950c  jmp 0x00007ED4111D6C21
00007ed4111d9511  sub rsp, 0x08
00007ed4111d9515  push rax
00007ed4111d9516  push rcx
00007ed4111d9517  push rdx
00007ed4111d9518  push rdi
00007ed4111d9519  push rsi
00007ed4111d951a  push r8
00007ed4111d951c  push r9
00007ed4111d951e  push r10
00007ed4111d9520  push r11
00007ed4111d9522  sub rsp, 0xF0
00007ed4111d9529  vmovaps [rsp], xmm0
00007ed4111d952e  vmovaps [rsp+0x10], xmm1
00007ed4111d9534  vmovaps [rsp+0x20], xmm2
00007ed4111d953a  vmovaps [rsp+0x30], xmm3
00007ed4111d9540  vmovaps [rsp+0x40], xmm4
00007ed4111d9546  vmovaps [rsp+0x50], xmm5
00007ed4111d954c  vmovaps [rsp+0x60], xmm6
00007ed4111d9552  vmovaps [rsp+0x70], xmm7
00007ed4111d9558  vmovaps [rsp+0x80], xmm8
00007ed4111d9561  vmovaps [rsp+0x90], xmm10
00007ed4111d956a  vmovaps [rsp+0xA0], xmm11
00007ed4111d9573  vmovaps [rsp+0xB0], xmm12
00007ed4111d957c  vmovaps [rsp+0xC0], xmm13
00007ed4111d9585  vmovaps [rsp+0xD0], xmm14
00007ed4111d958e  vmovaps [rsp+0xE0], xmm15
00007ed4111d9597  sub rsp, 0x40
00007ed4111d959b  lea rdi, [rsp]
00007ed4111d959f  lea rsi, [rsp+0x10]
00007ed4111d95a4  lea rdx, [rsp+0x20]
00007ed4111d95a9  lea rcx, [rsp+0x30]
00007ed4111d95ae  mov r8d, 0x00
00007ed4111d95b4  lea r9, [r15+0x3A8]
00007ed4111d95bb  movaps [rdi], xmm9
00007ed4111d95bf  movaps [rsi], xmm7
00007ed4111d95c2  movaps [rdx], xmm14
00007ed4111d95c6  movaps [rcx], xmm13
00007ed4111d95ca  mov rax, 0x5CA8E4A55A50
00007ed4111d95d4  call rax
00007ed4111d95d6  movaps xmm9, [rsp]
00007ed4111d95db  add rsp, 0x40
00007ed4111d95df  vmovaps xmm0, [rsp]
00007ed4111d95e4  vmovaps xmm1, [rsp+0x10]
00007ed4111d95ea  vmovaps xmm2, [rsp+0x20]
00007ed4111d95f0  vmovaps xmm3, [rsp+0x30]
00007ed4111d95f6  vmovaps xmm4, [rsp+0x40]
00007ed4111d95fc  vmovaps xmm5, [rsp+0x50]
00007ed4111d9602  vmovaps xmm6, [rsp+0x60]
00007ed4111d9608  vmovaps xmm7, [rsp+0x70]
00007ed4111d960e  vmovaps xmm8, [rsp+0x80]
00007ed4111d9617  vmovaps xmm10, [rsp+0x90]
00007ed4111d9620  vmovaps xmm11, [rsp+0xA0]
00007ed4111d9629  vmovaps xmm12, [rsp+0xB0]
00007ed4111d9632  vmovaps xmm13, [rsp+0xC0]
00007ed4111d963b  vmovaps xmm14, [rsp+0xD0]
00007ed4111d9644  vmovaps xmm15, [rsp+0xE0]
00007ed4111d964d  add rsp, 0xF0
00007ed4111d9654  pop r11
00007ed4111d9656  pop r10
00007ed4111d9658  pop r9
00007ed4111d965a  pop r8
00007ed4111d965c  pop rsi
00007ed4111d965d  pop rdi
00007ed4111d965e  pop rdx
00007ed4111d965f  pop rcx
00007ed4111d9660  pop rax
00007ed4111d9661  add rsp, 0x08
00007ed4111d9665  jmp 0x00007ED4111D6C4F
00007ed4111d966a  sub rsp, 0x08
00007ed4111d966e  push rax
00007ed4111d966f  push rcx
00007ed4111d9670  push rdx
00007ed4111d9671  push rdi
00007ed4111d9672  push rsi
00007ed4111d9673  push r8
00007ed4111d9675  push r9
00007ed4111d9677  push r10
00007ed4111d9679  push r11
00007ed4111d967b  sub rsp, 0xF0
00007ed4111d9682  vmovaps [rsp], xmm0
00007ed4111d9687  vmovaps [rsp+0x10], xmm1
00007ed4111d968d  vmovaps [rsp+0x20], xmm2
00007ed4111d9693  vmovaps [rsp+0x30], xmm3
00007ed4111d9699  vmovaps [rsp+0x40], xmm4
00007ed4111d969f  vmovaps [rsp+0x50], xmm5
00007ed4111d96a5  vmovaps [rsp+0x60], xmm6
00007ed4111d96ab  vmovaps [rsp+0x70], xmm7
00007ed4111d96b1  vmovaps [rsp+0x80], xmm8
00007ed4111d96ba  vmovaps [rsp+0x90], xmm9
00007ed4111d96c3  vmovaps [rsp+0xA0], xmm10
00007ed4111d96cc  vmovaps [rsp+0xB0], xmm11
00007ed4111d96d5  vmovaps [rsp+0xC0], xmm12
00007ed4111d96de  vmovaps [rsp+0xD0], xmm14
00007ed4111d96e7  vmovaps [rsp+0xE0], xmm15
00007ed4111d96f0  sub rsp, 0x40
00007ed4111d96f4  lea rdi, [rsp]
00007ed4111d96f8  lea rsi, [rsp+0x10]
00007ed4111d96fd  lea rdx, [rsp+0x20]
00007ed4111d9702  lea rcx, [rsp+0x30]
00007ed4111d9707  mov r8d, 0x00
00007ed4111d970d  lea r9, [r15+0x3A8]
00007ed4111d9714  movaps [rdi], xmm13
00007ed4111d9718  movaps [rsi], xmm12
00007ed4111d971c  movaps [rdx], xmm15
00007ed4111d9720  movaps [rcx], xmm14
00007ed4111d9724  mov rax, 0x5CA8E4A55A50
00007ed4111d972e  call rax
00007ed4111d9730  movaps xmm13, [rsp]
00007ed4111d9735  add rsp, 0x40
00007ed4111d9739  vmovaps xmm0, [rsp]
00007ed4111d973e  vmovaps xmm1, [rsp+0x10]
00007ed4111d9744  vmovaps xmm2, [rsp+0x20]
00007ed4111d974a  vmovaps xmm3, [rsp+0x30]
00007ed4111d9750  vmovaps xmm4, [rsp+0x40]
00007ed4111d9756  vmovaps xmm5, [rsp+0x50]
00007ed4111d975c  vmovaps xmm6, [rsp+0x60]
00007ed4111d9762  vmovaps xmm7, [rsp+0x70]
00007ed4111d9768  vmovaps xmm8, [rsp+0x80]
00007ed4111d9771  vmovaps xmm9, [rsp+0x90]
00007ed4111d977a  vmovaps xmm10, [rsp+0xA0]
00007ed4111d9783  vmovaps xmm11, [rsp+0xB0]
00007ed4111d978c  vmovaps xmm12, [rsp+0xC0]
00007ed4111d9795  vmovaps xmm14, [rsp+0xD0]
00007ed4111d979e  vmovaps xmm15, [rsp+0xE0]
00007ed4111d97a7  add rsp, 0xF0
00007ed4111d97ae  pop r11
00007ed4111d97b0  pop r10
00007ed4111d97b2  pop r9
00007ed4111d97b4  pop r8
00007ed4111d97b6  pop rsi
00007ed4111d97b7  pop rdi
00007ed4111d97b8  pop rdx
00007ed4111d97b9  pop rcx
00007ed4111d97ba  pop rax
00007ed4111d97bb  add rsp, 0x08
00007ed4111d97bf  jmp 0x00007ED4111D6C7D
00007ed4111d97c4  sub rsp, 0x08
00007ed4111d97c8  push rax
00007ed4111d97c9  push rcx
00007ed4111d97ca  push rdx
00007ed4111d97cb  push rdi
00007ed4111d97cc  push rsi
00007ed4111d97cd  push r8
00007ed4111d97cf  push r9
00007ed4111d97d1  push r10
00007ed4111d97d3  push r11
00007ed4111d97d5  sub rsp, 0xF0
00007ed4111d97dc  vmovaps [rsp], xmm0
00007ed4111d97e1  vmovaps [rsp+0x10], xmm1
00007ed4111d97e7  vmovaps [rsp+0x20], xmm2
00007ed4111d97ed  vmovaps [rsp+0x30], xmm3
00007ed4111d97f3  vmovaps [rsp+0x40], xmm4
00007ed4111d97f9  vmovaps [rsp+0x50], xmm5
00007ed4111d97ff  vmovaps [rsp+0x60], xmm6
00007ed4111d9805  vmovaps [rsp+0x70], xmm7
00007ed4111d980b  vmovaps [rsp+0x80], xmm8
00007ed4111d9814  vmovaps [rsp+0x90], xmm9
00007ed4111d981d  vmovaps [rsp+0xA0], xmm10
00007ed4111d9826  vmovaps [rsp+0xB0], xmm11
00007ed4111d982f  vmovaps [rsp+0xC0], xmm12
00007ed4111d9838  vmovaps [rsp+0xD0], xmm13
00007ed4111d9841  vmovaps [rsp+0xE0], xmm15
00007ed4111d984a  sub rsp, 0x40
00007ed4111d984e  lea rdi, [rsp]
00007ed4111d9852  lea rsi, [rsp+0x10]
00007ed4111d9857  lea rdx, [rsp+0x20]
00007ed4111d985c  lea rcx, [rsp+0x30]
00007ed4111d9861  mov r8d, 0x00
00007ed4111d9867  lea r9, [r15+0x3A8]
00007ed4111d986e  movaps [rdi], xmm14
00007ed4111d9872  movaps [rsi], xmm11
00007ed4111d9876  movaps [rdx], xmm1
00007ed4111d9879  movaps [rcx], xmm15
00007ed4111d987d  mov rax, 0x5CA8E4A55A50
00007ed4111d9887  call rax
00007ed4111d9889  movaps xmm14, [rsp]
00007ed4111d988e  add rsp, 0x40
00007ed4111d9892  vmovaps xmm0, [rsp]
00007ed4111d9897  vmovaps xmm1, [rsp+0x10]
00007ed4111d989d  vmovaps xmm2, [rsp+0x20]
00007ed4111d98a3  vmovaps xmm3, [rsp+0x30]
00007ed4111d98a9  vmovaps xmm4, [rsp+0x40]
00007ed4111d98af  vmovaps xmm5, [rsp+0x50]
00007ed4111d98b5  vmovaps xmm6, [rsp+0x60]
00007ed4111d98bb  vmovaps xmm7, [rsp+0x70]
00007ed4111d98c1  vmovaps xmm8, [rsp+0x80]
00007ed4111d98ca  vmovaps xmm9, [rsp+0x90]
00007ed4111d98d3  vmovaps xmm10, [rsp+0xA0]
00007ed4111d98dc  vmovaps xmm11, [rsp+0xB0]
00007ed4111d98e5  vmovaps xmm12, [rsp+0xC0]
00007ed4111d98ee  vmovaps xmm13, [rsp+0xD0]
00007ed4111d98f7  vmovaps xmm15, [rsp+0xE0]
00007ed4111d9900  add rsp, 0xF0
00007ed4111d9907  pop r11
00007ed4111d9909  pop r10
00007ed4111d990b  pop r9
00007ed4111d990d  pop r8
00007ed4111d990f  pop rsi
00007ed4111d9910  pop rdi
00007ed4111d9911  pop rdx
00007ed4111d9912  pop rcx
00007ed4111d9913  pop rax
00007ed4111d9914  add rsp, 0x08
00007ed4111d9918  jmp 0x00007ED4111D6CAB
00007ed4111d991d  call 0x00007ED4110ACF70
00007ed4111d9922  jmp 0x00007ED4111D6CB9
00007ed4111d9927  call 0x00007ED41100C380
00007ed4111d992c  jmp 0x00007ED4111D6CC3
00007ed4111d9931  call 0x00007ED411008C20
00007ed4111d9936  jmp 0x00007ED4111D6CCD
00007ed4111d993b  call 0x00007ED41100D600
00007ed4111d9940  jmp 0x00007ED4111D6CD7
00007ed4111d9945  int3
00007ed4111d9946  nop [rax+rax*1], ax
00007ed4111d994f  nop
00007ed4111d9950  mov eax, [r15+0x48]
00007ed4111d9954  lea r14d, [eax+0x01]
00007ed4111d9959  mov [rsp+0x10], r14d
00007ed4111d995e  mov r14d, r14d
00007ed4111d9961  mov [r15+0x48], r14
00007ed4111d9965  xor eax, eax
00007ed4111d9967  mov r14d, [rsp+0x10]
00007ed4111d996c  cmp r14d, 0x1F4
00007ed4111d9973  cmc
00007ed4111d9974  lahf
00007ed4111d9975  seto al
00007ed4111d9978  mov [r15+0x108], eax
00007ed4111d997f  mov eax, [r15+0x108]
00007ed4111d9986  sahf
00007ed4111d9987  jnz 0x00007ED4111D99B9
00007ed4111d9989  cmp dword ptr [r15+0x318], 0x00
00007ed4111d9991  jz 0x00007ED4111DD2E0
00007ed4111d9997  nop [rax+rax*1], ax
00007ed4111d99a0  nop [rax+rax*1], eax
00007ed4111d99a8  mov eax, 0x410670
00007ed4111d99ad  mov [r15+0x100], rax
00007ed4111d99b4  jmp 0x00007ED410FFE110
00007ed4111d99b9  cmp dword ptr [r15+0x318], 0x00
00007ed4111d99c1  jz 0x00007ED4111D99F0
00007ed4111d99c7  nop [rax+rax*1], ax
00007ed4111d99d0  nop [rax+rax*1], eax
00007ed4111d99d8  mov eax, 0x4104EC
00007ed4111d99dd  mov [r15+0x100], rax
00007ed4111d99e4  jmp 0x00007ED410FFE110
00007ed4111d99e9  int3
00007ed4111d99ea  int3
00007ed4111d99eb  nop [rax+rax*1], eax
00007ed4111d99f0  mov rax, [r15+0x40]
00007ed4111d99f4  vxorps xmm1, xmm1, xmm1
00007ed4111d99f8  vpbroadcastq xmm1, xmm1
00007ed4111d99fd  vxorps xmm15, xmm15, xmm15
00007ed4111d9a02  vpbroadcastq xmm15, xmm15
00007ed4111d9a07  lea r14, [rax+0x30]
00007ed4111d9a0b  mov r12, [r13+r14*1]
00007ed4111d9a10  lea r14, [rax+0x38]
00007ed4111d9a14  mov r11, [r13+r14*1]
00007ed4111d9a19  movq xmm14, r12
00007ed4111d9a1e  movq xmm13, r11
00007ed4111d9a23  movq xmm14, xmm14
00007ed4111d9a28  movq xmm13, xmm13
00007ed4111d9a2d  vmovaps [rsp+0x10], xmm13
00007ed4111d9a33  movq xmm13, xmm13
00007ed4111d9a38  movaps [r15+0x270], xmm13
00007ed4111d9a40  movaps xmm13, [r15+0x160]
00007ed4111d9a48  vmovaps [rsp+0x20], xmm13
00007ed4111d9a4e  vmovaps xmm12, [rsp+0x20]
00007ed4111d9a54  por xmm13, xmm12
00007ed4111d9a59  lea r14, [rax+0x20]
00007ed4111d9a5d  mov r12, [r13+r14*1]
00007ed4111d9a62  lea r14, [rax+0x28]
00007ed4111d9a66  mov r11, [r13+r14*1]
00007ed4111d9a6b  movq xmm12, r12
00007ed4111d9a70  movq xmm11, r11
00007ed4111d9a75  movq xmm12, xmm12
00007ed4111d9a7a  movq xmm11, xmm11
00007ed4111d9a7f  movaps xmm10, [r15+0x2D0]
00007ed4111d9a87  vmovaps [rsp+0x20], xmm10
00007ed4111d9a8d  vmovaps xmm9, [rsp+0x20]
00007ed4111d9a93  por xmm10, xmm9
00007ed4111d9a98  movaps xmm9, [r15+0x300]
00007ed4111d9aa0  vmovaps [rsp+0x20], xmm9
00007ed4111d9aa6  vmovaps xmm8, [rsp+0x20]
00007ed4111d9aac  por xmm9, xmm8
00007ed4111d9ab1  movaps xmm8, [r15+0x2B0]
00007ed4111d9ab9  vmovaps [rsp+0x20], xmm8
00007ed4111d9abf  vmovaps xmm7, [rsp+0x20]
00007ed4111d9ac5  por xmm8, xmm7
00007ed4111d9aca  movaps xmm7, [r15+0x180]
00007ed4111d9ad2  vmovaps [rsp+0x20], xmm7
00007ed4111d9ad8  vmovaps xmm6, [rsp+0x20]
00007ed4111d9ade  por xmm7, xmm6
00007ed4111d9ae2  lea r14, [rax+0x10]
00007ed4111d9ae6  mov r12, [r13+r14*1]
00007ed4111d9aeb  lea r14, [rax+0x18]
00007ed4111d9aef  mov r11, [r13+r14*1]
00007ed4111d9af4  movq xmm6, r12
00007ed4111d9af9  movq xmm5, r11
00007ed4111d9afe  movq xmm6, xmm6
00007ed4111d9b02  movq xmm5, xmm5
00007ed4111d9b06  movaps xmm4, [r15+0x200]
00007ed4111d9b0e  vmovaps [rsp+0x20], xmm4
00007ed4111d9b14  vmovaps xmm3, [rsp+0x20]
00007ed4111d9b1a  por xmm4, xmm3
00007ed4111d9b1e  movaps xmm3, [r15+0x1F0]
00007ed4111d9b26  vmovaps [rsp+0x20], xmm3
00007ed4111d9b2c  vmovaps xmm2, [rsp+0x20]
00007ed4111d9b32  por xmm3, xmm2
00007ed4111d9b36  movaps xmm2, [r15+0x2E0]
00007ed4111d9b3e  vmovaps [rsp+0x20], xmm2
00007ed4111d9b44  vmovaps [rsp+0x30], xmm1
00007ed4111d9b4a  vmovaps xmm1, [rsp+0x20]
00007ed4111d9b50  por xmm2, xmm1
00007ed4111d9b54  movaps xmm1, [r15+0x2A0]
00007ed4111d9b5c  vmovaps [rsp+0x20], xmm1
00007ed4111d9b62  vmovaps [rsp+0x40], xmm15
00007ed4111d9b68  vmovaps xmm15, [rsp+0x20]
00007ed4111d9b6e  por xmm1, xmm15
00007ed4111d9b73  movaps xmm15, [r15+0x280]
00007ed4111d9b7b  vmovaps [rsp+0x20], xmm15
00007ed4111d9b81  vmovaps [rsp+0x50], xmm1
00007ed4111d9b87  vmovaps xmm1, [rsp+0x20]
00007ed4111d9b8d  por xmm15, xmm1
00007ed4111d9b92  movaps xmm1, [r15+0x1C0]
00007ed4111d9b9a  vmovaps [rsp+0x20], xmm1
00007ed4111d9ba0  vmovaps [rsp+0x60], xmm15
00007ed4111d9ba6  vmovaps xmm15, [rsp+0x20]
00007ed4111d9bac  por xmm1, xmm15
00007ed4111d9bb1  movaps xmm15, [r15+0x210]
00007ed4111d9bb9  vmovaps [rsp+0x20], xmm15
00007ed4111d9bbf  vmovaps [rsp+0x70], xmm1
00007ed4111d9bc5  vmovaps xmm1, [rsp+0x20]
00007ed4111d9bcb  por xmm15, xmm1
00007ed4111d9bd0  mov r14, [r13+rax*1]
00007ed4111d9bd5  vmovq xmm1, r14
00007ed4111d9bda  vpbroadcastq xmm1, xmm1
00007ed4111d9bdf  vmovaps [rsp+0x20], xmm1
00007ed4111d9be5  vxorps xmm1, xmm1, xmm1
00007ed4111d9be9  vpbroadcastq xmm1, xmm1
00007ed4111d9bee  mov r14, [r15+0xF8]
00007ed4111d9bf5  vmovaps [rsp+0x80], xmm1
00007ed4111d9bfe  movups xmm1, [r13+r14*1]
00007ed4111d9c04  vmovaps [rsp+0x90], xmm1
00007ed4111d9c0d  vxorps xmm1, xmm1, xmm1
00007ed4111d9c11  vpbroadcastq xmm1, xmm1
00007ed4111d9c16  lea r12, [rax+0x08]
00007ed4111d9c1a  mov rax, [r13+r12*1]
00007ed4111d9c1f  vmovaps [rsp+0xA0], xmm1
00007ed4111d9c28  movq xmm1, rax
00007ed4111d9c2d  movaps [r15+0x240], xmm1
00007ed4111d9c35  mov rax, [r15+0x50]
00007ed4111d9c39  mov [r15+0x60], rax
00007ed4111d9c3d  mov qword ptr [r15+0x58], 0x40
00007ed4111d9c45  vmovaps xmm1, [rsp+0x30]
00007ed4111d9c4b  vmovaps [rsp+0x30], xmm15
00007ed4111d9c51  vmovaps xmm15, [rsp+0x90]
00007ed4111d9c5a  vmovaps [rsp+0x90], xmm14
00007ed4111d9c63  vmovaps xmm14, [rsp+0x20]
00007ed4111d9c69  vmovaps [rsp+0x20], xmm13
00007ed4111d9c6f  vmovaps [rsp+0xB0], xmm12
00007ed4111d9c78  movaps xmm13, xmm1
00007ed4111d9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d9c87  vptest xmm12, xmm12
00007ed4111d9c8c  jnz 0x00007ED4111DA72F
00007ed4111d9c92  movaps xmm1, [r15+0x250]
00007ed4111d9c9a  vmovaps xmm15, [rsp+0x40]
00007ed4111d9ca0  vmovaps [rsp+0x40], xmm13
00007ed4111d9ca6  movaps xmm12, xmm15
00007ed4111d9caa  vfmadd231pd xmm12, xmm1, xmm14
00007ed4111d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007ed4111d9cb5  vptest xmm13, xmm13
00007ed4111d9cba  jnz 0x00007ED4111DA888
00007ed4111d9cc0  movaps xmm15, [r15+0x1E0]
00007ed4111d9cc8  vmovaps [rsp+0xC0], xmm15
00007ed4111d9cd1  vmovaps xmm13, [rsp+0xC0]
00007ed4111d9cda  por xmm15, xmm13
00007ed4111d9cdf  movaps xmm13, [r15+0x1D0]
00007ed4111d9ce7  vmovaps [rsp+0xC0], xmm13
00007ed4111d9cf0  vmovaps [rsp+0xD0], xmm1
00007ed4111d9cf9  vmovaps xmm1, [rsp+0xC0]
00007ed4111d9d02  por xmm13, xmm1
00007ed4111d9d07  movaps xmm1, [r15+0x2C0]
00007ed4111d9d0f  vmovaps [rsp+0xC0], xmm1
00007ed4111d9d18  vmovaps [rsp+0xE0], xmm15
00007ed4111d9d21  vmovaps xmm15, [rsp+0xC0]
00007ed4111d9d2a  por xmm1, xmm15
00007ed4111d9d2f  movaps xmm15, [r15+0x290]
00007ed4111d9d37  vmovaps [rsp+0xC0], xmm15
00007ed4111d9d40  vmovaps [rsp+0xF0], xmm1
00007ed4111d9d49  vmovaps xmm1, [rsp+0xC0]
00007ed4111d9d52  por xmm15, xmm1
00007ed4111d9d57  movaps xmm1, [r15+0x260]
00007ed4111d9d5f  vmovaps [rsp+0xC0], xmm1
00007ed4111d9d68  vmovaps [rsp+0x100], xmm15
00007ed4111d9d71  vmovaps xmm15, [rsp+0xC0]
00007ed4111d9d7a  por xmm1, xmm15
00007ed4111d9d7f  vmovaps xmm15, [rsp+0xD0]
00007ed4111d9d88  vmovaps [rsp+0xC0], xmm1
00007ed4111d9d91  vmovaps xmm1, [rsp+0xD0]
00007ed4111d9d9a  por xmm15, xmm1
00007ed4111d9d9f  lea r12, [r14+0xC0]
00007ed4111d9da6  movups xmm1, [r13+r12*1]
00007ed4111d9dac  mov [rsp+0xD0], rax
00007ed4111d9db4  xor eax, eax
00007ed4111d9db6  mov r12d, 0x40
00007ed4111d9dbc  mov r11d, 0x200
00007ed4111d9dc2  cmp r12, r11
00007ed4111d9dc5  cmc
00007ed4111d9dc6  lahf
00007ed4111d9dc7  seto al
00007ed4111d9dca  mov [r15+0x108], eax
00007ed4111d9dd1  vmovaps [rsp+0x110], xmm1
00007ed4111d9dda  vmovaps xmm1, [rsp+0x80]
00007ed4111d9de3  vmovaps [rsp+0x80], xmm15
00007ed4111d9dec  vmovaps xmm15, [rsp+0x110]
00007ed4111d9df5  vmovaps [rsp+0x110], xmm13
00007ed4111d9dfe  vmovaps [rsp+0x120], xmm12
00007ed4111d9e07  movaps xmm13, xmm1
00007ed4111d9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d9e16  vptest xmm12, xmm12
00007ed4111d9e1b  jnz 0x00007ED4111DA9EB
00007ed4111d9e21  lea rax, [r14+0xB0]
00007ed4111d9e28  movups xmm1, [r13+rax*1]
00007ed4111d9e2e  vmovaps xmm15, [rsp+0xA0]
00007ed4111d9e37  vmovaps [rsp+0xA0], xmm13
00007ed4111d9e40  movaps xmm12, xmm15
00007ed4111d9e44  vfmadd231pd xmm12, xmm1, xmm14
00007ed4111d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007ed4111d9e4f  vptest xmm13, xmm13
00007ed4111d9e54  jnz 0x00007ED4111DAB4E
00007ed4111d9e5a  vmovaps xmm1, [rsp+0x30]
00007ed4111d9e60  vmovaps xmm15, [rsp+0x30]
00007ed4111d9e66  por xmm1, xmm15
00007ed4111d9e6b  movaps [r15+0x210], xmm1
00007ed4111d9e73  vmovaps xmm15, [rsp+0x70]
00007ed4111d9e79  vmovaps xmm14, [rsp+0x70]
00007ed4111d9e7f  por xmm15, xmm14
00007ed4111d9e84  movaps [r15+0x1C0], xmm15
00007ed4111d9e8c  vmovaps xmm14, [rsp+0x60]
00007ed4111d9e92  vmovaps xmm13, [rsp+0x60]
00007ed4111d9e98  por xmm14, xmm13
00007ed4111d9e9d  movaps [r15+0x280], xmm14
00007ed4111d9ea5  vmovaps xmm13, [rsp+0x50]
00007ed4111d9eab  vmovaps [rsp+0x30], xmm1
00007ed4111d9eb1  vmovaps xmm1, [rsp+0x50]
00007ed4111d9eb7  por xmm13, xmm1
00007ed4111d9ebc  movaps [r15+0x2A0], xmm13
00007ed4111d9ec4  vmovaps [rsp+0x50], xmm2
00007ed4111d9eca  vmovaps xmm1, [rsp+0x50]
00007ed4111d9ed0  por xmm2, xmm1
00007ed4111d9ed4  movaps [r15+0x2E0], xmm2
00007ed4111d9edc  vmovaps [rsp+0x50], xmm3
00007ed4111d9ee2  vmovaps xmm1, [rsp+0x50]
00007ed4111d9ee8  por xmm3, xmm1
00007ed4111d9eec  movaps [r15+0x1F0], xmm3
00007ed4111d9ef4  vmovaps xmm1, [rsp+0x80]
00007ed4111d9efd  vmovaps [rsp+0x50], xmm15
00007ed4111d9f03  vmovaps xmm15, [rsp+0x80]
00007ed4111d9f0c  por xmm1, xmm15
00007ed4111d9f11  movaps [r15+0x250], xmm1
00007ed4111d9f19  vmovaps xmm1, [rsp+0xC0]
00007ed4111d9f22  vmovaps xmm15, [rsp+0xC0]
00007ed4111d9f2b  por xmm1, xmm15
00007ed4111d9f30  movaps [r15+0x260], xmm1
00007ed4111d9f38  vmovaps xmm15, [rsp+0x100]
00007ed4111d9f41  vmovaps [rsp+0x60], xmm1
00007ed4111d9f47  vmovaps xmm1, [rsp+0x100]
00007ed4111d9f50  por xmm15, xmm1
00007ed4111d9f55  movaps [r15+0x290], xmm15
00007ed4111d9f5d  vmovaps xmm1, [rsp+0xF0]
00007ed4111d9f66  vmovaps [rsp+0x70], xmm15
00007ed4111d9f6c  vmovaps xmm15, [rsp+0xF0]
00007ed4111d9f75  por xmm1, xmm15
00007ed4111d9f7a  movaps [r15+0x2C0], xmm1
00007ed4111d9f82  movq xmm15, qword ptr [r15+0x240]
00007ed4111d9f8b  vmovaps [rsp+0x80], xmm15
00007ed4111d9f94  vpermilpd xmm15, xmm15, 0x00
00007ed4111d9f9a  vmovaps [rsp+0xC0], xmm1
00007ed4111d9fa3  vmovaps xmm1, [rsp+0x40]
00007ed4111d9fa9  vmovaps [rsp+0x40], xmm15
00007ed4111d9faf  vmovaps xmm15, [rsp+0x30]
00007ed4111d9fb5  vmovaps [rsp+0x30], xmm14
00007ed4111d9fbb  vmovaps xmm14, [rsp+0x40]
00007ed4111d9fc1  vmovaps [rsp+0x40], xmm13
00007ed4111d9fc7  vmovaps [rsp+0xF0], xmm12
00007ed4111d9fd0  movaps xmm13, xmm1
00007ed4111d9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007ed4111d9fdf  vptest xmm12, xmm12
00007ed4111d9fe4  jnz 0x00007ED4111DACA7
00007ed4111d9fea  vmovaps xmm1, [rsp+0x80]
00007ed4111d9ff3  vpermilpd xmm1, xmm1, 0x00
00007ed4111d9ff9  vmovaps xmm15, [rsp+0xA0]
00007ed4111da002  movaps xmm14, xmm15
00007ed4111da006  vfmadd231pd xmm14, xmm2, xmm1
00007ed4111da00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007ed4111da011  vptest xmm12, xmm12
00007ed4111da016  jnz 0x00007ED4111DAE00
00007ed4111da01c  vmovaps xmm1, [rsp+0x80]
00007ed4111da025  vpermilpd xmm1, xmm1, 0x00
00007ed4111da02b  vmovaps xmm15, [rsp+0x120]
00007ed4111da034  vmovaps xmm12, [rsp+0x50]
00007ed4111da03a  vmovaps [rsp+0x50], xmm14
00007ed4111da040  movaps xmm2, xmm15
00007ed4111da044  vfmadd231pd xmm2, xmm12, xmm1
00007ed4111da049  vcmppd xmm14, xmm2, xmm2, 0x03
00007ed4111da04e  vptest xmm14, xmm14
00007ed4111da053  jnz 0x00007ED4111DAF58
00007ed4111da059  vmovaps xmm1, [rsp+0x110]
00007ed4111da062  vmovaps xmm15, [rsp+0x110]
00007ed4111da06b  por xmm1, xmm15
00007ed4111da070  movaps [r15+0x1D0], xmm1
00007ed4111da078  vmovaps xmm15, [rsp+0x80]
00007ed4111da081  vpermilpd xmm15, xmm15, 0x00
00007ed4111da087  vmovaps xmm14, [rsp+0xF0]
00007ed4111da090  vmovaps [rsp+0x80], xmm1
00007ed4111da099  movaps xmm12, xmm14
00007ed4111da09d  vfmadd231pd xmm12, xmm3, xmm15
00007ed4111da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007ed4111da0a8  vptest xmm1, xmm1
00007ed4111da0ad  jnz 0x00007ED4111DB0AF
00007ed4111da0b3  vmovaps [rsp+0xA0], xmm4
00007ed4111da0bc  vmovaps xmm1, [rsp+0xA0]
00007ed4111da0c5  por xmm4, xmm1
00007ed4111da0c9  movaps [r15+0x200], xmm4
00007ed4111da0d1  vmovaps xmm1, [rsp+0xE0]
00007ed4111da0da  vmovaps xmm15, [rsp+0xE0]
00007ed4111da0e3  por xmm1, xmm15
00007ed4111da0e8  movaps [r15+0x1E0], xmm1
00007ed4111da0f0  vmovaps [rsp+0xA0], xmm8
00007ed4111da0f9  vmovaps xmm1, [rsp+0xA0]
00007ed4111da102  por xmm8, xmm1
00007ed4111da107  movaps [r15+0x2B0], xmm8
00007ed4111da10f  vmovaps [rsp+0xA0], xmm9
00007ed4111da118  vmovaps xmm1, [rsp+0xA0]
00007ed4111da121  por xmm9, xmm1
00007ed4111da126  movaps [r15+0x300], xmm9
00007ed4111da12e  vmovaps [rsp+0xA0], xmm6
00007ed4111da137  vpermilpd xmm6, xmm6, 0x00
00007ed4111da13d  vmovaps xmm14, [rsp+0x60]
00007ed4111da143  movaps xmm9, xmm13
00007ed4111da147  vfmadd231pd xmm9, xmm14, xmm6
00007ed4111da14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007ed4111da152  vptest xmm3, xmm3
00007ed4111da157  jnz 0x00007ED4111DB208
00007ed4111da15d  vmovaps xmm14, [rsp+0xA0]
00007ed4111da166  vpermilpd xmm14, xmm14, 0x00
00007ed4111da16c  vmovaps xmm13, [rsp+0x50]
00007ed4111da172  vmovaps xmm6, [rsp+0xC0]
00007ed4111da17b  vmovaps [rsp+0x50], xmm1
00007ed4111da181  movaps xmm3, xmm13
00007ed4111da185  vfmadd231pd xmm3, xmm6, xmm14
00007ed4111da18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007ed4111da18f  vptest xmm1, xmm1
00007ed4111da194  jnz 0x00007ED4111DB361
00007ed4111da19a  vmovaps xmm1, [rsp+0xA0]
00007ed4111da1a3  vpermilpd xmm1, xmm1, 0x00
00007ed4111da1a9  vmovaps xmm14, [rsp+0x30]
00007ed4111da1af  movaps xmm6, xmm2
00007ed4111da1b2  vfmadd231pd xmm6, xmm14, xmm1
00007ed4111da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007ed4111da1bc  vptest xmm13, xmm13
00007ed4111da1c1  jnz 0x00007ED4111DB4B8
00007ed4111da1c7  vmovaps xmm1, [rsp+0xA0]
00007ed4111da1d0  vpermilpd xmm1, xmm1, 0x00
00007ed4111da1d6  vmovaps xmm14, [rsp+0x80]
00007ed4111da1df  movaps xmm13, xmm12
00007ed4111da1e3  vfmadd231pd xmm13, xmm14, xmm1
00007ed4111da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007ed4111da1ee  vptest xmm2, xmm2
00007ed4111da1f3  jnz 0x00007ED4111DB60E
00007ed4111da1f9  vmovaps [rsp+0x30], xmm7
00007ed4111da1ff  vmovaps xmm1, [rsp+0x30]
00007ed4111da205  por xmm7, xmm1
00007ed4111da209  movaps [r15+0x180], xmm7
00007ed4111da211  vmovaps [rsp+0x30], xmm10
00007ed4111da217  vmovaps xmm1, [rsp+0x30]
00007ed4111da21d  por xmm10, xmm1
00007ed4111da222  movaps [r15+0x2D0], xmm10
00007ed4111da22a  vmovaps [rsp+0x30], xmm5
00007ed4111da230  vpermilpd xmm5, xmm5, 0x00
00007ed4111da236  vmovaps xmm14, [rsp+0x50]
00007ed4111da23c  movaps xmm12, xmm3
00007ed4111da240  vfmadd231pd xmm12, xmm14, xmm5
00007ed4111da245  vcmppd xmm10, xmm12, xmm12, 0x03
00007ed4111da24b  vptest xmm10, xmm10
00007ed4111da250  jnz 0x00007ED4111DB767
00007ed4111da256  vmovaps xmm14, [rsp+0x30]
00007ed4111da25c  vpermilpd xmm14, xmm14, 0x00
00007ed4111da262  movaps xmm10, xmm9
00007ed4111da266  vfmadd231pd xmm10, xmm7, xmm14
00007ed4111da26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007ed4111da271  vptest xmm5, xmm5
00007ed4111da276  jnz 0x00007ED4111DB8BF
00007ed4111da27c  lea rax, [r14+0x80]
00007ed4111da283  movups xmm14, [r13+rax*1]
00007ed4111da289  movaps [r15+0x2F0], xmm14
00007ed4111da291  vmovaps xmm9, [rsp+0x30]
00007ed4111da297  vpermilpd xmm9, xmm9, 0x00
00007ed4111da29d  vmovaps xmm7, [rsp+0x70]
00007ed4111da2a3  movaps xmm5, xmm6
00007ed4111da2a6  vfmadd231pd xmm5, xmm7, xmm9
00007ed4111da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007ed4111da2b0  vptest xmm3, xmm3
00007ed4111da2b5  jnz 0x00007ED4111DBA22
00007ed4111da2bb  vmovaps xmm9, [rsp+0x30]
00007ed4111da2c1  vpermilpd xmm9, xmm9, 0x00
00007ed4111da2c7  movaps xmm7, xmm13
00007ed4111da2cb  vfmadd231pd xmm7, xmm1, xmm9
00007ed4111da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007ed4111da2d5  vptest xmm6, xmm6
00007ed4111da2da  jnz 0x00007ED4111DBB78
00007ed4111da2e0  vmovaps xmm1, [rsp+0x20]
00007ed4111da2e6  vmovaps xmm13, [rsp+0x20]
00007ed4111da2ec  por xmm1, xmm13
00007ed4111da2f1  movaps [r15+0x160], xmm1
00007ed4111da2f9  lea rax, [r14+0x40]
00007ed4111da2fd  movups xmm13, [r13+rax*1]
00007ed4111da303  lea rax, [r14+0x50]
00007ed4111da307  movups xmm9, [r13+rax*1]
00007ed4111da30d  movaps [r15+0x1B0], xmm13
00007ed4111da315  movaps [r15+0x1A0], xmm9
00007ed4111da31d  movaps xmm6, [r15+0x190]
00007ed4111da325  vmovaps xmm3, [rsp+0xB0]
00007ed4111da32e  vpermilpd xmm3, xmm3, 0x00
00007ed4111da334  vmovaps [rsp+0x20], xmm1
00007ed4111da33a  movaps xmm2, xmm12
00007ed4111da33e  vfmadd231pd xmm2, xmm6, xmm3
00007ed4111da343  vcmppd xmm1, xmm2, xmm2, 0x03
00007ed4111da348  vptest xmm1, xmm1
00007ed4111da34d  jnz 0x00007ED4111DBCE3
00007ed4111da353  vmovaps xmm1, [rsp+0xB0]
00007ed4111da35c  vpermilpd xmm1, xmm1, 0x00
00007ed4111da362  vmovaps xmm12, [rsp+0x20]
00007ed4111da368  movaps xmm6, xmm10
00007ed4111da36c  vfmadd231pd xmm6, xmm12, xmm1
00007ed4111da371  vcmppd xmm3, xmm6, xmm6, 0x03
00007ed4111da376  vptest xmm3, xmm3
00007ed4111da37b  jnz 0x00007ED4111DBE39
00007ed4111da381  vmovaps xmm1, [rsp+0xB0]
00007ed4111da38a  vpermilpd xmm1, xmm1, 0x00
00007ed4111da390  vmovaps xmm12, [rsp+0x40]
00007ed4111da396  movaps xmm10, xmm5
00007ed4111da39a  vfmadd231pd xmm10, xmm12, xmm1
00007ed4111da39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007ed4111da3a5  vptest xmm3, xmm3
00007ed4111da3aa  jnz 0x00007ED4111DBF90
00007ed4111da3b0  vmovaps xmm1, [rsp+0xB0]
00007ed4111da3b9  vpermilpd xmm1, xmm1, 0x00
00007ed4111da3bf  movaps xmm12, xmm7
00007ed4111da3c3  vfmadd231pd xmm12, xmm15, xmm1
00007ed4111da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007ed4111da3ce  vptest xmm5, xmm5
00007ed4111da3d3  jnz 0x00007ED4111DC0E8
00007ed4111da3d9  lea rax, [r14+0x60]
00007ed4111da3dd  movups xmm1, [r13+rax*1]
00007ed4111da3e3  lea rax, [r14+0x70]
00007ed4111da3e7  movups xmm15, [r13+rax*1]
00007ed4111da3ed  movaps [r15+0x150], xmm1
00007ed4111da3f5  movaps [r15+0x120], xmm15
00007ed4111da3fd  vmovaps [rsp+0x20], xmm11
00007ed4111da403  vpermilpd xmm11, xmm11, 0x00
00007ed4111da409  movaps xmm7, xmm2
00007ed4111da40c  vfmadd231pd xmm7, xmm9, xmm11
00007ed4111da411  vcmppd xmm5, xmm7, xmm7, 0x03
00007ed4111da416  vptest xmm5, xmm5
00007ed4111da41b  jnz 0x00007ED4111DC254
00007ed4111da421  vmovaps xmm11, [rsp+0x20]
00007ed4111da427  vpermilpd xmm11, xmm11, 0x00
00007ed4111da42d  movaps xmm9, xmm6
00007ed4111da431  vfmadd231pd xmm9, xmm1, xmm11
00007ed4111da436  vcmppd xmm5, xmm9, xmm9, 0x03
00007ed4111da43c  vptest xmm5, xmm5
00007ed4111da441  jnz 0x00007ED4111DC3AB
00007ed4111da447  vmovaps xmm1, [rsp+0x20]
00007ed4111da44d  vpermilpd xmm1, xmm1, 0x00
00007ed4111da453  movaps xmm11, xmm10
00007ed4111da457  vfmadd231pd xmm11, xmm8, xmm1
00007ed4111da45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007ed4111da462  vptest xmm6, xmm6
00007ed4111da467  jnz 0x00007ED4111DC503
00007ed4111da46d  vmovaps xmm1, [rsp+0x20]
00007ed4111da473  vpermilpd xmm1, xmm1, 0x00
00007ed4111da479  movaps xmm10, xmm12
00007ed4111da47d  vfmadd231pd xmm10, xmm13, xmm1
00007ed4111da482  vcmppd xmm8, xmm10, xmm10, 0x03
00007ed4111da488  vptest xmm8, xmm8
00007ed4111da48d  jnz 0x00007ED4111DC65C
00007ed4111da493  lea rax, [r14+0x20]
00007ed4111da497  movups xmm1, [r13+rax*1]
00007ed4111da49d  lea rax, [r14+0x30]
00007ed4111da4a1  movups xmm13, [r13+rax*1]
00007ed4111da4a7  vmovaps xmm12, [rsp+0x90]
00007ed4111da4b0  vpermilpd xmm12, xmm12, 0x00
00007ed4111da4b6  movaps xmm8, xmm7
00007ed4111da4ba  vfmadd231pd xmm8, xmm4, xmm12
00007ed4111da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007ed4111da4c5  vptest xmm6, xmm6
00007ed4111da4ca  jnz 0x00007ED4111DC7C9
00007ed4111da4d0  vmovaps xmm12, [rsp+0x90]
00007ed4111da4d9  vpermilpd xmm12, xmm12, 0x00
00007ed4111da4df  movaps xmm7, xmm9
00007ed4111da4e3  vfmadd231pd xmm7, xmm14, xmm12
00007ed4111da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007ed4111da4ed  vptest xmm6, xmm6
00007ed4111da4f2  jnz 0x00007ED4111DC921
00007ed4111da4f8  vmovaps xmm14, [rsp+0x90]
00007ed4111da501  vpermilpd xmm14, xmm14, 0x00
00007ed4111da507  movaps xmm12, xmm11
00007ed4111da50b  vfmadd231pd xmm12, xmm15, xmm14
00007ed4111da510  vcmppd xmm9, xmm12, xmm12, 0x03
00007ed4111da516  vptest xmm9, xmm9
00007ed4111da51b  jnz 0x00007ED4111DCA79
00007ed4111da521  vmovaps xmm15, [rsp+0x90]
00007ed4111da52a  vpermilpd xmm15, xmm15, 0x00
00007ed4111da530  movaps xmm11, xmm10
00007ed4111da534  vfmadd231pd xmm11, xmm13, xmm15
00007ed4111da539  vcmppd xmm14, xmm11, xmm11, 0x03
00007ed4111da53f  vptest xmm14, xmm14
00007ed4111da544  jnz 0x00007ED4111DCBD3
00007ed4111da54a  lea rax, [r14+0x90]
00007ed4111da551  movups xmm15, [r13+rax*1]
00007ed4111da557  lea rax, [r14+0xA0]
00007ed4111da55e  movups xmm14, [r13+rax*1]
00007ed4111da564  movaps [r15+0x140], xmm15
00007ed4111da56c  movaps [r15+0x130], xmm14
00007ed4111da574  vmovaps xmm13, [rsp+0x10]
00007ed4111da57a  vpermilpd xmm13, xmm13, 0x00
00007ed4111da580  movaps xmm10, xmm8
00007ed4111da584  vfmadd231pd xmm10, xmm1, xmm13
00007ed4111da589  vcmppd xmm9, xmm10, xmm10, 0x03
00007ed4111da58f  vptest xmm9, xmm9
00007ed4111da594  jnz 0x00007ED4111DCD41
00007ed4111da59a  movaps [r15+0x220], xmm10
00007ed4111da5a2  lea rax, [r14+0x10]
00007ed4111da5a6  movups xmm1, [r13+rax*1]
00007ed4111da5ac  movaps [r15+0x240], xmm1
00007ed4111da5b4  vmovaps xmm13, [rsp+0x10]
00007ed4111da5ba  vpermilpd xmm13, xmm13, 0x00
00007ed4111da5c0  movaps xmm9, xmm7
00007ed4111da5c4  vfmadd231pd xmm9, xmm14, xmm13
00007ed4111da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007ed4111da5cf  vptest xmm8, xmm8
00007ed4111da5d4  jnz 0x00007ED4111DCEA4
00007ed4111da5da  movaps [r15+0x110], xmm9
00007ed4111da5e2  vmovaps xmm14, [rsp+0x10]
00007ed4111da5e8  vpermilpd xmm14, xmm14, 0x00
00007ed4111da5ee  movaps xmm13, xmm12
00007ed4111da5f2  vfmadd231pd xmm13, xmm15, xmm14
00007ed4111da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007ed4111da5fd  vptest xmm8, xmm8
00007ed4111da602  jnz 0x00007ED4111DCFFD
00007ed4111da608  movaps [r15+0x170], xmm13
00007ed4111da610  vmovaps xmm15, [rsp+0x10]
00007ed4111da616  vpermilpd xmm15, xmm15, 0x00
00007ed4111da61c  movaps xmm14, xmm11
00007ed4111da620  vfmadd231pd xmm14, xmm1, xmm15
00007ed4111da625  vcmppd xmm12, xmm14, xmm14, 0x03
00007ed4111da62b  vptest xmm12, xmm12
00007ed4111da630  jnz 0x00007ED4111DD157
00007ed4111da636  movaps [r15+0x230], xmm14
00007ed4111da63e  mov rax, [rsp+0xD0]
00007ed4111da646  movups [r13+rax*1], xmm9
00007ed4111da64c  lea r14, [rax+0x10]
00007ed4111da650  movups [r13+r14*1], xmm13
00007ed4111da656  lea r14, [rax+0x20]
00007ed4111da65a  movups [r13+r14*1], xmm10
00007ed4111da660  lea r14, [rax+0x30]
00007ed4111da664  movups [r13+r14*1], xmm14
00007ed4111da66a  mov eax, [r15+0x108]
00007ed4111da671  sahf
00007ed4111da672  jnz 0x00007ED4111DA6A4
00007ed4111da674  cmp dword ptr [r15+0x318], 0x00
00007ed4111da67c  jz 0x00007ED4111D9950
00007ed4111da682  nop [rax+rax*1], ax
00007ed4111da68b  nop [rax+rax*1], eax
00007ed4111da693  mov eax, 0x410664
00007ed4111da698  mov [r15+0x100], rax
00007ed4111da69f  jmp 0x00007ED410FFE110
00007ed4111da6a4  cmp dword ptr [r15+0x318], 0x00
00007ed4111da6ac  jz 0x00007ED4111D6050
00007ed4111da6b2  nop [rax+rax*1], ax
00007ed4111da6bb  nop [rax+rax*1], eax
00007ed4111da6c3  mov eax, 0x4104F0
00007ed4111da6c8  mov [r15+0x100], rax
00007ed4111da6cf  jmp 0x00007ED410FFE110
00007ed4111da6d4  int3
00007ed4111da6d5  call 0x00007ED4110E27E0
00007ed4111da6da  jmp 0x00007ED4111D9A10
00007ed4111da6df  call 0x00007ED4110E1570
00007ed4111da6e4  jmp 0x00007ED4111D9A19
00007ed4111da6e9  call 0x00007ED4110E27E0
00007ed4111da6ee  jmp 0x00007ED4111D9A62
00007ed4111da6f3  call 0x00007ED4110E1570
00007ed4111da6f8  jmp 0x00007ED4111D9A6B
00007ed4111da6fd  call 0x00007ED4110E27E0
00007ed4111da702  jmp 0x00007ED4111D9AEB
00007ed4111da707  call 0x00007ED4110E1570
00007ed4111da70c  jmp 0x00007ED4111D9AF4
00007ed4111da711  call 0x00007ED41100DC20
00007ed4111da716  jmp 0x00007ED4111D9BD5
00007ed4111da71b  call 0x00007ED4110D64F0
00007ed4111da720  jmp 0x00007ED4111D9C04
00007ed4111da725  call 0x00007ED4110B47C0
00007ed4111da72a  jmp 0x00007ED4111D9C1F
00007ed4111da72f  sub rsp, 0x08
00007ed4111da733  push rax
00007ed4111da734  push rcx
00007ed4111da735  push rdx
00007ed4111da736  push rdi
00007ed4111da737  push rsi
00007ed4111da738  push r8
00007ed4111da73a  push r9
00007ed4111da73c  push r10
00007ed4111da73e  push r11
00007ed4111da740  sub rsp, 0xF0
00007ed4111da747  vmovaps [rsp], xmm0
00007ed4111da74c  vmovaps [rsp+0x10], xmm1
00007ed4111da752  vmovaps [rsp+0x20], xmm2
00007ed4111da758  vmovaps [rsp+0x30], xmm3
00007ed4111da75e  vmovaps [rsp+0x40], xmm4
00007ed4111da764  vmovaps [rsp+0x50], xmm5
00007ed4111da76a  vmovaps [rsp+0x60], xmm6
00007ed4111da770  vmovaps [rsp+0x70], xmm7
00007ed4111da776  vmovaps [rsp+0x80], xmm8
00007ed4111da77f  vmovaps [rsp+0x90], xmm9
00007ed4111da788  vmovaps [rsp+0xA0], xmm10
00007ed4111da791  vmovaps [rsp+0xB0], xmm11
00007ed4111da79a  vmovaps [rsp+0xC0], xmm12
00007ed4111da7a3  vmovaps [rsp+0xD0], xmm14
00007ed4111da7ac  vmovaps [rsp+0xE0], xmm15
00007ed4111da7b5  sub rsp, 0x40
00007ed4111da7b9  lea rdi, [rsp]
00007ed4111da7bd  lea rsi, [rsp+0x10]
00007ed4111da7c2  lea rdx, [rsp+0x20]
00007ed4111da7c7  lea rcx, [rsp+0x30]
00007ed4111da7cc  mov r8d, 0x00
00007ed4111da7d2  lea r9, [r15+0x3A8]
00007ed4111da7d9  movaps [rdi], xmm13
00007ed4111da7dd  movaps [rsi], xmm1
00007ed4111da7e0  movaps [rdx], xmm15
00007ed4111da7e4  movaps [rcx], xmm14
00007ed4111da7e8  mov rax, 0x5CA8E4A55A50
00007ed4111da7f2  call rax
00007ed4111da7f4  movaps xmm13, [rsp]
00007ed4111da7f9  add rsp, 0x40
00007ed4111da7fd  vmovaps xmm0, [rsp]
00007ed4111da802  vmovaps xmm1, [rsp+0x10]
00007ed4111da808  vmovaps xmm2, [rsp+0x20]
00007ed4111da80e  vmovaps xmm3, [rsp+0x30]
00007ed4111da814  vmovaps xmm4, [rsp+0x40]
00007ed4111da81a  vmovaps xmm5, [rsp+0x50]
00007ed4111da820  vmovaps xmm6, [rsp+0x60]
00007ed4111da826  vmovaps xmm7, [rsp+0x70]
00007ed4111da82c  vmovaps xmm8, [rsp+0x80]
00007ed4111da835  vmovaps xmm9, [rsp+0x90]
00007ed4111da83e  vmovaps xmm10, [rsp+0xA0]
00007ed4111da847  vmovaps xmm11, [rsp+0xB0]
00007ed4111da850  vmovaps xmm12, [rsp+0xC0]
00007ed4111da859  vmovaps xmm14, [rsp+0xD0]
00007ed4111da862  vmovaps xmm15, [rsp+0xE0]
00007ed4111da86b  add rsp, 0xF0
00007ed4111da872  pop r11
00007ed4111da874  pop r10
00007ed4111da876  pop r9
00007ed4111da878  pop r8
00007ed4111da87a  pop rsi
00007ed4111da87b  pop rdi
00007ed4111da87c  pop rdx
00007ed4111da87d  pop rcx
00007ed4111da87e  pop rax
00007ed4111da87f  add rsp, 0x08
00007ed4111da883  jmp 0x00007ED4111D9C92
00007ed4111da888  sub rsp, 0x08
00007ed4111da88c  push rax
00007ed4111da88d  push rcx
00007ed4111da88e  push rdx
00007ed4111da88f  push rdi
00007ed4111da890  push rsi
00007ed4111da891  push r8
00007ed4111da893  push r9
00007ed4111da895  push r10
00007ed4111da897  push r11
00007ed4111da899  sub rsp, 0xF0
00007ed4111da8a0  vmovaps [rsp], xmm0
00007ed4111da8a5  vmovaps [rsp+0x10], xmm1
00007ed4111da8ab  vmovaps [rsp+0x20], xmm2
00007ed4111da8b1  vmovaps [rsp+0x30], xmm3
00007ed4111da8b7  vmovaps [rsp+0x40], xmm4
00007ed4111da8bd  vmovaps [rsp+0x50], xmm5
00007ed4111da8c3  vmovaps [rsp+0x60], xmm6
00007ed4111da8c9  vmovaps [rsp+0x70], xmm7
00007ed4111da8cf  vmovaps [rsp+0x80], xmm8
00007ed4111da8d8  vmovaps [rsp+0x90], xmm9
00007ed4111da8e1  vmovaps [rsp+0xA0], xmm10
00007ed4111da8ea  vmovaps [rsp+0xB0], xmm11
00007ed4111da8f3  vmovaps [rsp+0xC0], xmm13
00007ed4111da8fc  vmovaps [rsp+0xD0], xmm14
00007ed4111da905  vmovaps [rsp+0xE0], xmm15
00007ed4111da90e  sub rsp, 0x40
00007ed4111da912  lea rdi, [rsp]
00007ed4111da916  lea rsi, [rsp+0x10]
00007ed4111da91b  lea rdx, [rsp+0x20]
00007ed4111da920  lea rcx, [rsp+0x30]
00007ed4111da925  mov r8d, 0x00
00007ed4111da92b  lea r9, [r15+0x3A8]
00007ed4111da932  movaps [rdi], xmm12
00007ed4111da936  movaps [rsi], xmm15
00007ed4111da93a  movaps [rdx], xmm1
00007ed4111da93d  movaps [rcx], xmm14
00007ed4111da941  mov rax, 0x5CA8E4A55A50
00007ed4111da94b  call rax
00007ed4111da94d  movaps xmm12, [rsp]
00007ed4111da952  add rsp, 0x40
00007ed4111da956  vmovaps xmm0, [rsp]
00007ed4111da95b  vmovaps xmm1, [rsp+0x10]
00007ed4111da961  vmovaps xmm2, [rsp+0x20]
00007ed4111da967  vmovaps xmm3, [rsp+0x30]
00007ed4111da96d  vmovaps xmm4, [rsp+0x40]
00007ed4111da973  vmovaps xmm5, [rsp+0x50]
00007ed4111da979  vmovaps xmm6, [rsp+0x60]
00007ed4111da97f  vmovaps xmm7, [rsp+0x70]
00007ed4111da985  vmovaps xmm8, [rsp+0x80]
00007ed4111da98e  vmovaps xmm9, [rsp+0x90]
00007ed4111da997  vmovaps xmm10, [rsp+0xA0]
00007ed4111da9a0  vmovaps xmm11, [rsp+0xB0]
00007ed4111da9a9  vmovaps xmm13, [rsp+0xC0]
00007ed4111da9b2  vmovaps xmm14, [rsp+0xD0]
00007ed4111da9bb  vmovaps xmm15, [rsp+0xE0]
00007ed4111da9c4  add rsp, 0xF0
00007ed4111da9cb  pop r11
00007ed4111da9cd  pop r10
00007ed4111da9cf  pop r9
00007ed4111da9d1  pop r8
00007ed4111da9d3  pop rsi
00007ed4111da9d4  pop rdi
00007ed4111da9d5  pop rdx
00007ed4111da9d6  pop rcx
00007ed4111da9d7  pop rax
00007ed4111da9d8  add rsp, 0x08
00007ed4111da9dc  jmp 0x00007ED4111D9CC0
00007ed4111da9e1  call 0x00007ED4110B52F0
00007ed4111da9e6  jmp 0x00007ED4111D9DAC
00007ed4111da9eb  sub rsp, 0x08
00007ed4111da9ef  push rax
00007ed4111da9f0  push rcx
00007ed4111da9f1  push rdx
00007ed4111da9f2  push rdi
00007ed4111da9f3  push rsi
00007ed4111da9f4  push r8
00007ed4111da9f6  push r9
00007ed4111da9f8  push r10
00007ed4111da9fa  push r11
00007ed4111da9fc  sub rsp, 0xF0
00007ed4111daa03  vmovaps [rsp], xmm0
00007ed4111daa08  vmovaps [rsp+0x10], xmm1
00007ed4111daa0e  vmovaps [rsp+0x20], xmm2
00007ed4111daa14  vmovaps [rsp+0x30], xmm3
00007ed4111daa1a  vmovaps [rsp+0x40], xmm4
00007ed4111daa20  vmovaps [rsp+0x50], xmm5
00007ed4111daa26  vmovaps [rsp+0x60], xmm6
00007ed4111daa2c  vmovaps [rsp+0x70], xmm7
00007ed4111daa32  vmovaps [rsp+0x80], xmm8
00007ed4111daa3b  vmovaps [rsp+0x90], xmm9
00007ed4111daa44  vmovaps [rsp+0xA0], xmm10
00007ed4111daa4d  vmovaps [rsp+0xB0], xmm11
00007ed4111daa56  vmovaps [rsp+0xC0], xmm12
00007ed4111daa5f  vmovaps [rsp+0xD0], xmm14
00007ed4111daa68  vmovaps [rsp+0xE0], xmm15
00007ed4111daa71  sub rsp, 0x40
00007ed4111daa75  lea rdi, [rsp]
00007ed4111daa79  lea rsi, [rsp+0x10]
00007ed4111daa7e  lea rdx, [rsp+0x20]
00007ed4111daa83  lea rcx, [rsp+0x30]
00007ed4111daa88  mov r8d, 0x00
00007ed4111daa8e  lea r9, [r15+0x3A8]
00007ed4111daa95  movaps [rdi], xmm13
00007ed4111daa99  movaps [rsi], xmm1
00007ed4111daa9c  movaps [rdx], xmm15
00007ed4111daaa0  movaps [rcx], xmm14
00007ed4111daaa4  mov rax, 0x5CA8E4A55A50
00007ed4111daaae  call rax
00007ed4111daab0  movaps xmm13, [rsp]
00007ed4111daab5  add rsp, 0x40
00007ed4111daab9  vmovaps xmm0, [rsp]
00007ed4111daabe  vmovaps xmm1, [rsp+0x10]
00007ed4111daac4  vmovaps xmm2, [rsp+0x20]
00007ed4111daaca  vmovaps xmm3, [rsp+0x30]
00007ed4111daad0  vmovaps xmm4, [rsp+0x40]
00007ed4111daad6  vmovaps xmm5, [rsp+0x50]
00007ed4111daadc  vmovaps xmm6, [rsp+0x60]
00007ed4111daae2  vmovaps xmm7, [rsp+0x70]
00007ed4111daae8  vmovaps xmm8, [rsp+0x80]
00007ed4111daaf1  vmovaps xmm9, [rsp+0x90]
00007ed4111daafa  vmovaps xmm10, [rsp+0xA0]
00007ed4111dab03  vmovaps xmm11, [rsp+0xB0]
00007ed4111dab0c  vmovaps xmm12, [rsp+0xC0]
00007ed4111dab15  vmovaps xmm14, [rsp+0xD0]
00007ed4111dab1e  vmovaps xmm15, [rsp+0xE0]
00007ed4111dab27  add rsp, 0xF0
00007ed4111dab2e  pop r11
00007ed4111dab30  pop r10
00007ed4111dab32  pop r9
00007ed4111dab34  pop r8
00007ed4111dab36  pop rsi
00007ed4111dab37  pop rdi
00007ed4111dab38  pop rdx
00007ed4111dab39  pop rcx
00007ed4111dab3a  pop rax
00007ed4111dab3b  add rsp, 0x08
00007ed4111dab3f  jmp 0x00007ED4111D9E21
00007ed4111dab44  call 0x00007ED410FFF430
00007ed4111dab49  jmp 0x00007ED4111D9E2E
00007ed4111dab4e  sub rsp, 0x08
00007ed4111dab52  push rax
00007ed4111dab53  push rcx
00007ed4111dab54  push rdx
00007ed4111dab55  push rdi
00007ed4111dab56  push rsi
00007ed4111dab57  push r8
00007ed4111dab59  push r9
00007ed4111dab5b  push r10
00007ed4111dab5d  push r11
00007ed4111dab5f  sub rsp, 0xF0
00007ed4111dab66  vmovaps [rsp], xmm0
00007ed4111dab6b  vmovaps [rsp+0x10], xmm1
00007ed4111dab71  vmovaps [rsp+0x20], xmm2
00007ed4111dab77  vmovaps [rsp+0x30], xmm3
00007ed4111dab7d  vmovaps [rsp+0x40], xmm4
00007ed4111dab83  vmovaps [rsp+0x50], xmm5
00007ed4111dab89  vmovaps [rsp+0x60], xmm6
00007ed4111dab8f  vmovaps [rsp+0x70], xmm7
00007ed4111dab95  vmovaps [rsp+0x80], xmm8
00007ed4111dab9e  vmovaps [rsp+0x90], xmm9
00007ed4111daba7  vmovaps [rsp+0xA0], xmm10
00007ed4111dabb0  vmovaps [rsp+0xB0], xmm11
00007ed4111dabb9  vmovaps [rsp+0xC0], xmm13
00007ed4111dabc2  vmovaps [rsp+0xD0], xmm14
00007ed4111dabcb  vmovaps [rsp+0xE0], xmm15
00007ed4111dabd4  sub rsp, 0x40
00007ed4111dabd8  lea rdi, [rsp]
00007ed4111dabdc  lea rsi, [rsp+0x10]
00007ed4111dabe1  lea rdx, [rsp+0x20]
00007ed4111dabe6  lea rcx, [rsp+0x30]
00007ed4111dabeb  mov r8d, 0x00
00007ed4111dabf1  lea r9, [r15+0x3A8]
00007ed4111dabf8  movaps [rdi], xmm12
00007ed4111dabfc  movaps [rsi], xmm15
00007ed4111dac00  movaps [rdx], xmm1
00007ed4111dac03  movaps [rcx], xmm14
00007ed4111dac07  mov rax, 0x5CA8E4A55A50
00007ed4111dac11  call rax
00007ed4111dac13  movaps xmm12, [rsp]
00007ed4111dac18  add rsp, 0x40
00007ed4111dac1c  vmovaps xmm0, [rsp]
00007ed4111dac21  vmovaps xmm1, [rsp+0x10]
00007ed4111dac27  vmovaps xmm2, [rsp+0x20]
00007ed4111dac2d  vmovaps xmm3, [rsp+0x30]
00007ed4111dac33  vmovaps xmm4, [rsp+0x40]
00007ed4111dac39  vmovaps xmm5, [rsp+0x50]
00007ed4111dac3f  vmovaps xmm6, [rsp+0x60]
00007ed4111dac45  vmovaps xmm7, [rsp+0x70]
00007ed4111dac4b  vmovaps xmm8, [rsp+0x80]
00007ed4111dac54  vmovaps xmm9, [rsp+0x90]
00007ed4111dac5d  vmovaps xmm10, [rsp+0xA0]
00007ed4111dac66  vmovaps xmm11, [rsp+0xB0]
00007ed4111dac6f  vmovaps xmm13, [rsp+0xC0]
00007ed4111dac78  vmovaps xmm14, [rsp+0xD0]
00007ed4111dac81  vmovaps xmm15, [rsp+0xE0]
00007ed4111dac8a  add rsp, 0xF0
00007ed4111dac91  pop r11
00007ed4111dac93  pop r10
00007ed4111dac95  pop r9
00007ed4111dac97  pop r8
00007ed4111dac99  pop rsi
00007ed4111dac9a  pop rdi
00007ed4111dac9b  pop rdx
00007ed4111dac9c  pop rcx
00007ed4111dac9d  pop rax
00007ed4111dac9e  add rsp, 0x08
00007ed4111daca2  jmp 0x00007ED4111D9E5A
00007ed4111daca7  sub rsp, 0x08
00007ed4111dacab  push rax
00007ed4111dacac  push rcx
00007ed4111dacad  push rdx
00007ed4111dacae  push rdi
00007ed4111dacaf  push rsi
00007ed4111dacb0  push r8
00007ed4111dacb2  push r9
00007ed4111dacb4  push r10
00007ed4111dacb6  push r11
00007ed4111dacb8  sub rsp, 0xF0
00007ed4111dacbf  vmovaps [rsp], xmm0
00007ed4111dacc4  vmovaps [rsp+0x10], xmm1
00007ed4111dacca  vmovaps [rsp+0x20], xmm2
00007ed4111dacd0  vmovaps [rsp+0x30], xmm3
00007ed4111dacd6  vmovaps [rsp+0x40], xmm4
00007ed4111dacdc  vmovaps [rsp+0x50], xmm5
00007ed4111dace2  vmovaps [rsp+0x60], xmm6
00007ed4111dace8  vmovaps [rsp+0x70], xmm7
00007ed4111dacee  vmovaps [rsp+0x80], xmm8
00007ed4111dacf7  vmovaps [rsp+0x90], xmm9
00007ed4111dad00  vmovaps [rsp+0xA0], xmm10
00007ed4111dad09  vmovaps [rsp+0xB0], xmm11
00007ed4111dad12  vmovaps [rsp+0xC0], xmm12
00007ed4111dad1b  vmovaps [rsp+0xD0], xmm14
00007ed4111dad24  vmovaps [rsp+0xE0], xmm15
00007ed4111dad2d  sub rsp, 0x40
00007ed4111dad31  lea rdi, [rsp]
00007ed4111dad35  lea rsi, [rsp+0x10]
00007ed4111dad3a  lea rdx, [rsp+0x20]
00007ed4111dad3f  lea rcx, [rsp+0x30]
00007ed4111dad44  mov r8d, 0x00
00007ed4111dad4a  lea r9, [r15+0x3A8]
00007ed4111dad51  movaps [rdi], xmm13
00007ed4111dad55  movaps [rsi], xmm1
00007ed4111dad58  movaps [rdx], xmm15
00007ed4111dad5c  movaps [rcx], xmm14
00007ed4111dad60  mov rax, 0x5CA8E4A55A50
00007ed4111dad6a  call rax
00007ed4111dad6c  movaps xmm13, [rsp]
00007ed4111dad71  add rsp, 0x40
00007ed4111dad75  vmovaps xmm0, [rsp]
00007ed4111dad7a  vmovaps xmm1, [rsp+0x10]
00007ed4111dad80  vmovaps xmm2, [rsp+0x20]
00007ed4111dad86  vmovaps xmm3, [rsp+0x30]
00007ed4111dad8c  vmovaps xmm4, [rsp+0x40]
00007ed4111dad92  vmovaps xmm5, [rsp+0x50]
00007ed4111dad98  vmovaps xmm6, [rsp+0x60]
00007ed4111dad9e  vmovaps xmm7, [rsp+0x70]
00007ed4111dada4  vmovaps xmm8, [rsp+0x80]
00007ed4111dadad  vmovaps xmm9, [rsp+0x90]
00007ed4111dadb6  vmovaps xmm10, [rsp+0xA0]
00007ed4111dadbf  vmovaps xmm11, [rsp+0xB0]
00007ed4111dadc8  vmovaps xmm12, [rsp+0xC0]
00007ed4111dadd1  vmovaps xmm14, [rsp+0xD0]
00007ed4111dadda  vmovaps xmm15, [rsp+0xE0]
00007ed4111dade3  add rsp, 0xF0
00007ed4111dadea  pop r11
00007ed4111dadec  pop r10
00007ed4111dadee  pop r9
00007ed4111dadf0  pop r8
00007ed4111dadf2  pop rsi
00007ed4111dadf3  pop rdi
00007ed4111dadf4  pop rdx
00007ed4111dadf5  pop rcx
00007ed4111dadf6  pop rax
00007ed4111dadf7  add rsp, 0x08
00007ed4111dadfb  jmp 0x00007ED4111D9FEA
00007ed4111dae00  sub rsp, 0x08
00007ed4111dae04  push rax
00007ed4111dae05  push rcx
00007ed4111dae06  push rdx
00007ed4111dae07  push rdi
00007ed4111dae08  push rsi
00007ed4111dae09  push r8
00007ed4111dae0b  push r9
00007ed4111dae0d  push r10
00007ed4111dae0f  push r11
00007ed4111dae11  sub rsp, 0xF0
00007ed4111dae18  vmovaps [rsp], xmm0
00007ed4111dae1d  vmovaps [rsp+0x10], xmm1
00007ed4111dae23  vmovaps [rsp+0x20], xmm2
00007ed4111dae29  vmovaps [rsp+0x30], xmm3
00007ed4111dae2f  vmovaps [rsp+0x40], xmm4
00007ed4111dae35  vmovaps [rsp+0x50], xmm5
00007ed4111dae3b  vmovaps [rsp+0x60], xmm6
00007ed4111dae41  vmovaps [rsp+0x70], xmm7
00007ed4111dae47  vmovaps [rsp+0x80], xmm8
00007ed4111dae50  vmovaps [rsp+0x90], xmm9
00007ed4111dae59  vmovaps [rsp+0xA0], xmm10
00007ed4111dae62  vmovaps [rsp+0xB0], xmm11
00007ed4111dae6b  vmovaps [rsp+0xC0], xmm12
00007ed4111dae74  vmovaps [rsp+0xD0], xmm13
00007ed4111dae7d  vmovaps [rsp+0xE0], xmm15
00007ed4111dae86  sub rsp, 0x40
00007ed4111dae8a  lea rdi, [rsp]
00007ed4111dae8e  lea rsi, [rsp+0x10]
00007ed4111dae93  lea rdx, [rsp+0x20]
00007ed4111dae98  lea rcx, [rsp+0x30]
00007ed4111dae9d  mov r8d, 0x00
00007ed4111daea3  lea r9, [r15+0x3A8]
00007ed4111daeaa  movaps [rdi], xmm14
00007ed4111daeae  movaps [rsi], xmm15
00007ed4111daeb2  movaps [rdx], xmm2
00007ed4111daeb5  movaps [rcx], xmm1
00007ed4111daeb8  mov rax, 0x5CA8E4A55A50
00007ed4111daec2  call rax
00007ed4111daec4  movaps xmm14, [rsp]
00007ed4111daec9  add rsp, 0x40
00007ed4111daecd  vmovaps xmm0, [rsp]
00007ed4111daed2  vmovaps xmm1, [rsp+0x10]
00007ed4111daed8  vmovaps xmm2, [rsp+0x20]
00007ed4111daede  vmovaps xmm3, [rsp+0x30]
00007ed4111daee4  vmovaps xmm4, [rsp+0x40]
00007ed4111daeea  vmovaps xmm5, [rsp+0x50]
00007ed4111daef0  vmovaps xmm6, [rsp+0x60]
00007ed4111daef6  vmovaps xmm7, [rsp+0x70]
00007ed4111daefc  vmovaps xmm8, [rsp+0x80]
00007ed4111daf05  vmovaps xmm9, [rsp+0x90]
00007ed4111daf0e  vmovaps xmm10, [rsp+0xA0]
00007ed4111daf17  vmovaps xmm11, [rsp+0xB0]
00007ed4111daf20  vmovaps xmm12, [rsp+0xC0]
00007ed4111daf29  vmovaps xmm13, [rsp+0xD0]
00007ed4111daf32  vmovaps xmm15, [rsp+0xE0]
00007ed4111daf3b  add rsp, 0xF0
00007ed4111daf42  pop r11
00007ed4111daf44  pop r10
00007ed4111daf46  pop r9
00007ed4111daf48  pop r8
00007ed4111daf4a  pop rsi
00007ed4111daf4b  pop rdi
00007ed4111daf4c  pop rdx
00007ed4111daf4d  pop rcx
00007ed4111daf4e  pop rax
00007ed4111daf4f  add rsp, 0x08
00007ed4111daf53  jmp 0x00007ED4111DA01C
00007ed4111daf58  sub rsp, 0x08
00007ed4111daf5c  push rax
00007ed4111daf5d  push rcx
00007ed4111daf5e  push rdx
00007ed4111daf5f  push rdi
00007ed4111daf60  push rsi
00007ed4111daf61  push r8
00007ed4111daf63  push r9
00007ed4111daf65  push r10
00007ed4111daf67  push r11
00007ed4111daf69  sub rsp, 0xF0
00007ed4111daf70  vmovaps [rsp], xmm0
00007ed4111daf75  vmovaps [rsp+0x10], xmm1
00007ed4111daf7b  vmovaps [rsp+0x20], xmm3
00007ed4111daf81  vmovaps [rsp+0x30], xmm4
00007ed4111daf87  vmovaps [rsp+0x40], xmm5
00007ed4111daf8d  vmovaps [rsp+0x50], xmm6
00007ed4111daf93  vmovaps [rsp+0x60], xmm7
00007ed4111daf99  vmovaps [rsp+0x70], xmm8
00007ed4111daf9f  vmovaps [rsp+0x80], xmm9
00007ed4111dafa8  vmovaps [rsp+0x90], xmm10
00007ed4111dafb1  vmovaps [rsp+0xA0], xmm11
00007ed4111dafba  vmovaps [rsp+0xB0], xmm12
00007ed4111dafc3  vmovaps [rsp+0xC0], xmm13
00007ed4111dafcc  vmovaps [rsp+0xD0], xmm14
00007ed4111dafd5  vmovaps [rsp+0xE0], xmm15
00007ed4111dafde  sub rsp, 0x40
00007ed4111dafe2  lea rdi, [rsp]
00007ed4111dafe6  lea rsi, [rsp+0x10]
00007ed4111dafeb  lea rdx, [rsp+0x20]
00007ed4111daff0  lea rcx, [rsp+0x30]
00007ed4111daff5  mov r8d, 0x00
00007ed4111daffb  lea r9, [r15+0x3A8]
00007ed4111db002  movaps [rdi], xmm2
00007ed4111db005  movaps [rsi], xmm15
00007ed4111db009  movaps [rdx], xmm12
00007ed4111db00d  movaps [rcx], xmm1
00007ed4111db010  mov rax, 0x5CA8E4A55A50
00007ed4111db01a  call rax
00007ed4111db01c  movaps xmm2, [rsp]
00007ed4111db020  add rsp, 0x40
00007ed4111db024  vmovaps xmm0, [rsp]
00007ed4111db029  vmovaps xmm1, [rsp+0x10]
00007ed4111db02f  vmovaps xmm3, [rsp+0x20]
00007ed4111db035  vmovaps xmm4, [rsp+0x30]
00007ed4111db03b  vmovaps xmm5, [rsp+0x40]
00007ed4111db041  vmovaps xmm6, [rsp+0x50]
00007ed4111db047  vmovaps xmm7, [rsp+0x60]
00007ed4111db04d  vmovaps xmm8, [rsp+0x70]
00007ed4111db053  vmovaps xmm9, [rsp+0x80]
00007ed4111db05c  vmovaps xmm10, [rsp+0x90]
00007ed4111db065  vmovaps xmm11, [rsp+0xA0]
00007ed4111db06e  vmovaps xmm12, [rsp+0xB0]
00007ed4111db077  vmovaps xmm13, [rsp+0xC0]
00007ed4111db080  vmovaps xmm14, [rsp+0xD0]
00007ed4111db089  vmovaps xmm15, [rsp+0xE0]
00007ed4111db092  add rsp, 0xF0
00007ed4111db099  pop r11
00007ed4111db09b  pop r10
00007ed4111db09d  pop r9
00007ed4111db09f  pop r8
00007ed4111db0a1  pop rsi
00007ed4111db0a2  pop rdi
00007ed4111db0a3  pop rdx
00007ed4111db0a4  pop rcx
00007ed4111db0a5  pop rax
00007ed4111db0a6  add rsp, 0x08
00007ed4111db0aa  jmp 0x00007ED4111DA059
00007ed4111db0af  sub rsp, 0x08
00007ed4111db0b3  push rax
00007ed4111db0b4  push rcx
00007ed4111db0b5  push rdx
00007ed4111db0b6  push rdi
00007ed4111db0b7  push rsi
00007ed4111db0b8  push r8
00007ed4111db0ba  push r9
00007ed4111db0bc  push r10
00007ed4111db0be  push r11
00007ed4111db0c0  sub rsp, 0xF0
00007ed4111db0c7  vmovaps [rsp], xmm0
00007ed4111db0cc  vmovaps [rsp+0x10], xmm1
00007ed4111db0d2  vmovaps [rsp+0x20], xmm2
00007ed4111db0d8  vmovaps [rsp+0x30], xmm3
00007ed4111db0de  vmovaps [rsp+0x40], xmm4
00007ed4111db0e4  vmovaps [rsp+0x50], xmm5
00007ed4111db0ea  vmovaps [rsp+0x60], xmm6
00007ed4111db0f0  vmovaps [rsp+0x70], xmm7
00007ed4111db0f6  vmovaps [rsp+0x80], xmm8
00007ed4111db0ff  vmovaps [rsp+0x90], xmm9
00007ed4111db108  vmovaps [rsp+0xA0], xmm10
00007ed4111db111  vmovaps [rsp+0xB0], xmm11
00007ed4111db11a  vmovaps [rsp+0xC0], xmm13
00007ed4111db123  vmovaps [rsp+0xD0], xmm14
00007ed4111db12c  vmovaps [rsp+0xE0], xmm15
00007ed4111db135  sub rsp, 0x40
00007ed4111db139  lea rdi, [rsp]
00007ed4111db13d  lea rsi, [rsp+0x10]
00007ed4111db142  lea rdx, [rsp+0x20]
00007ed4111db147  lea rcx, [rsp+0x30]
00007ed4111db14c  mov r8d, 0x00
00007ed4111db152  lea r9, [r15+0x3A8]
00007ed4111db159  movaps [rdi], xmm12
00007ed4111db15d  movaps [rsi], xmm14
00007ed4111db161  movaps [rdx], xmm3
00007ed4111db164  movaps [rcx], xmm15
00007ed4111db168  mov rax, 0x5CA8E4A55A50
00007ed4111db172  call rax
00007ed4111db174  movaps xmm12, [rsp]
00007ed4111db179  add rsp, 0x40
00007ed4111db17d  vmovaps xmm0, [rsp]
00007ed4111db182  vmovaps xmm1, [rsp+0x10]
00007ed4111db188  vmovaps xmm2, [rsp+0x20]
00007ed4111db18e  vmovaps xmm3, [rsp+0x30]
00007ed4111db194  vmovaps xmm4, [rsp+0x40]
00007ed4111db19a  vmovaps xmm5, [rsp+0x50]
00007ed4111db1a0  vmovaps xmm6, [rsp+0x60]
00007ed4111db1a6  vmovaps xmm7, [rsp+0x70]
00007ed4111db1ac  vmovaps xmm8, [rsp+0x80]
00007ed4111db1b5  vmovaps xmm9, [rsp+0x90]
00007ed4111db1be  vmovaps xmm10, [rsp+0xA0]
00007ed4111db1c7  vmovaps xmm11, [rsp+0xB0]
00007ed4111db1d0  vmovaps xmm13, [rsp+0xC0]
00007ed4111db1d9  vmovaps xmm14, [rsp+0xD0]
00007ed4111db1e2  vmovaps xmm15, [rsp+0xE0]
00007ed4111db1eb  add rsp, 0xF0
00007ed4111db1f2  pop r11
00007ed4111db1f4  pop r10
00007ed4111db1f6  pop r9
00007ed4111db1f8  pop r8
00007ed4111db1fa  pop rsi
00007ed4111db1fb  pop rdi
00007ed4111db1fc  pop rdx
00007ed4111db1fd  pop rcx
00007ed4111db1fe  pop rax
00007ed4111db1ff  add rsp, 0x08
00007ed4111db203  jmp 0x00007ED4111DA0B3
00007ed4111db208  sub rsp, 0x08
00007ed4111db20c  push rax
00007ed4111db20d  push rcx
00007ed4111db20e  push rdx
00007ed4111db20f  push rdi
00007ed4111db210  push rsi
00007ed4111db211  push r8
00007ed4111db213  push r9
00007ed4111db215  push r10
00007ed4111db217  push r11
00007ed4111db219  sub rsp, 0xF0
00007ed4111db220  vmovaps [rsp], xmm0
00007ed4111db225  vmovaps [rsp+0x10], xmm1
00007ed4111db22b  vmovaps [rsp+0x20], xmm2
00007ed4111db231  vmovaps [rsp+0x30], xmm3
00007ed4111db237  vmovaps [rsp+0x40], xmm4
00007ed4111db23d  vmovaps [rsp+0x50], xmm5
00007ed4111db243  vmovaps [rsp+0x60], xmm6
00007ed4111db249  vmovaps [rsp+0x70], xmm7
00007ed4111db24f  vmovaps [rsp+0x80], xmm8
00007ed4111db258  vmovaps [rsp+0x90], xmm10
00007ed4111db261  vmovaps [rsp+0xA0], xmm11
00007ed4111db26a  vmovaps [rsp+0xB0], xmm12
00007ed4111db273  vmovaps [rsp+0xC0], xmm13
00007ed4111db27c  vmovaps [rsp+0xD0], xmm14
00007ed4111db285  vmovaps [rsp+0xE0], xmm15
00007ed4111db28e  sub rsp, 0x40
00007ed4111db292  lea rdi, [rsp]
00007ed4111db296  lea rsi, [rsp+0x10]
00007ed4111db29b  lea rdx, [rsp+0x20]
00007ed4111db2a0  lea rcx, [rsp+0x30]
00007ed4111db2a5  mov r8d, 0x00
00007ed4111db2ab  lea r9, [r15+0x3A8]
00007ed4111db2b2  movaps [rdi], xmm9
00007ed4111db2b6  movaps [rsi], xmm13
00007ed4111db2ba  movaps [rdx], xmm14
00007ed4111db2be  movaps [rcx], xmm6
00007ed4111db2c1  mov rax, 0x5CA8E4A55A50
00007ed4111db2cb  call rax
00007ed4111db2cd  movaps xmm9, [rsp]
00007ed4111db2d2  add rsp, 0x40
00007ed4111db2d6  vmovaps xmm0, [rsp]
00007ed4111db2db  vmovaps xmm1, [rsp+0x10]
00007ed4111db2e1  vmovaps xmm2, [rsp+0x20]
00007ed4111db2e7  vmovaps xmm3, [rsp+0x30]
00007ed4111db2ed  vmovaps xmm4, [rsp+0x40]
00007ed4111db2f3  vmovaps xmm5, [rsp+0x50]
00007ed4111db2f9  vmovaps xmm6, [rsp+0x60]
00007ed4111db2ff  vmovaps xmm7, [rsp+0x70]
00007ed4111db305  vmovaps xmm8, [rsp+0x80]
00007ed4111db30e  vmovaps xmm10, [rsp+0x90]
00007ed4111db317  vmovaps xmm11, [rsp+0xA0]
00007ed4111db320  vmovaps xmm12, [rsp+0xB0]
00007ed4111db329  vmovaps xmm13, [rsp+0xC0]
00007ed4111db332  vmovaps xmm14, [rsp+0xD0]
00007ed4111db33b  vmovaps xmm15, [rsp+0xE0]
00007ed4111db344  add rsp, 0xF0
00007ed4111db34b  pop r11
00007ed4111db34d  pop r10
00007ed4111db34f  pop r9
00007ed4111db351  pop r8
00007ed4111db353  pop rsi
00007ed4111db354  pop rdi
00007ed4111db355  pop rdx
00007ed4111db356  pop rcx
00007ed4111db357  pop rax
00007ed4111db358  add rsp, 0x08
00007ed4111db35c  jmp 0x00007ED4111DA15D
00007ed4111db361  sub rsp, 0x08
00007ed4111db365  push rax
00007ed4111db366  push rcx
00007ed4111db367  push rdx
00007ed4111db368  push rdi
00007ed4111db369  push rsi
00007ed4111db36a  push r8
00007ed4111db36c  push r9
00007ed4111db36e  push r10
00007ed4111db370  push r11
00007ed4111db372  sub rsp, 0xF0
00007ed4111db379  vmovaps [rsp], xmm0
00007ed4111db37e  vmovaps [rsp+0x10], xmm1
00007ed4111db384  vmovaps [rsp+0x20], xmm2
00007ed4111db38a  vmovaps [rsp+0x30], xmm4
00007ed4111db390  vmovaps [rsp+0x40], xmm5
00007ed4111db396  vmovaps [rsp+0x50], xmm6
00007ed4111db39c  vmovaps [rsp+0x60], xmm7
00007ed4111db3a2  vmovaps [rsp+0x70], xmm8
00007ed4111db3a8  vmovaps [rsp+0x80], xmm9
00007ed4111db3b1  vmovaps [rsp+0x90], xmm10
00007ed4111db3ba  vmovaps [rsp+0xA0], xmm11
00007ed4111db3c3  vmovaps [rsp+0xB0], xmm12
00007ed4111db3cc  vmovaps [rsp+0xC0], xmm13
00007ed4111db3d5  vmovaps [rsp+0xD0], xmm14
00007ed4111db3de  vmovaps [rsp+0xE0], xmm15
00007ed4111db3e7  sub rsp, 0x40
00007ed4111db3eb  lea rdi, [rsp]
00007ed4111db3ef  lea rsi, [rsp+0x10]
00007ed4111db3f4  lea rdx, [rsp+0x20]
00007ed4111db3f9  lea rcx, [rsp+0x30]
00007ed4111db3fe  mov r8d, 0x00
00007ed4111db404  lea r9, [r15+0x3A8]
00007ed4111db40b  movaps [rdi], xmm3
00007ed4111db40e  movaps [rsi], xmm13
00007ed4111db412  movaps [rdx], xmm6
00007ed4111db415  movaps [rcx], xmm14
00007ed4111db419  mov rax, 0x5CA8E4A55A50
00007ed4111db423  call rax
00007ed4111db425  movaps xmm3, [rsp]
00007ed4111db429  add rsp, 0x40
00007ed4111db42d  vmovaps xmm0, [rsp]
00007ed4111db432  vmovaps xmm1, [rsp+0x10]
00007ed4111db438  vmovaps xmm2, [rsp+0x20]
00007ed4111db43e  vmovaps xmm4, [rsp+0x30]
00007ed4111db444  vmovaps xmm5, [rsp+0x40]
00007ed4111db44a  vmovaps xmm6, [rsp+0x50]
00007ed4111db450  vmovaps xmm7, [rsp+0x60]
00007ed4111db456  vmovaps xmm8, [rsp+0x70]
00007ed4111db45c  vmovaps xmm9, [rsp+0x80]
00007ed4111db465  vmovaps xmm10, [rsp+0x90]
00007ed4111db46e  vmovaps xmm11, [rsp+0xA0]
00007ed4111db477  vmovaps xmm12, [rsp+0xB0]
00007ed4111db480  vmovaps xmm13, [rsp+0xC0]
00007ed4111db489  vmovaps xmm14, [rsp+0xD0]
00007ed4111db492  vmovaps xmm15, [rsp+0xE0]
00007ed4111db49b  add rsp, 0xF0
00007ed4111db4a2  pop r11
00007ed4111db4a4  pop r10
00007ed4111db4a6  pop r9
00007ed4111db4a8  pop r8
00007ed4111db4aa  pop rsi
00007ed4111db4ab  pop rdi
00007ed4111db4ac  pop rdx
00007ed4111db4ad  pop rcx
00007ed4111db4ae  pop rax
00007ed4111db4af  add rsp, 0x08
00007ed4111db4b3  jmp 0x00007ED4111DA19A
00007ed4111db4b8  sub rsp, 0x08
00007ed4111db4bc  push rax
00007ed4111db4bd  push rcx
00007ed4111db4be  push rdx
00007ed4111db4bf  push rdi
00007ed4111db4c0  push rsi
00007ed4111db4c1  push r8
00007ed4111db4c3  push r9
00007ed4111db4c5  push r10
00007ed4111db4c7  push r11
00007ed4111db4c9  sub rsp, 0xF0
00007ed4111db4d0  vmovaps [rsp], xmm0
00007ed4111db4d5  vmovaps [rsp+0x10], xmm1
00007ed4111db4db  vmovaps [rsp+0x20], xmm2
00007ed4111db4e1  vmovaps [rsp+0x30], xmm3
00007ed4111db4e7  vmovaps [rsp+0x40], xmm4
00007ed4111db4ed  vmovaps [rsp+0x50], xmm5
00007ed4111db4f3  vmovaps [rsp+0x60], xmm7
00007ed4111db4f9  vmovaps [rsp+0x70], xmm8
00007ed4111db4ff  vmovaps [rsp+0x80], xmm9
00007ed4111db508  vmovaps [rsp+0x90], xmm10
00007ed4111db511  vmovaps [rsp+0xA0], xmm11
00007ed4111db51a  vmovaps [rsp+0xB0], xmm12
00007ed4111db523  vmovaps [rsp+0xC0], xmm13
00007ed4111db52c  vmovaps [rsp+0xD0], xmm14
00007ed4111db535  vmovaps [rsp+0xE0], xmm15
00007ed4111db53e  sub rsp, 0x40
00007ed4111db542  lea rdi, [rsp]
00007ed4111db546  lea rsi, [rsp+0x10]
00007ed4111db54b  lea rdx, [rsp+0x20]
00007ed4111db550  lea rcx, [rsp+0x30]
00007ed4111db555  mov r8d, 0x00
00007ed4111db55b  lea r9, [r15+0x3A8]
00007ed4111db562  movaps [rdi], xmm6
00007ed4111db565  movaps [rsi], xmm2
00007ed4111db568  movaps [rdx], xmm14
00007ed4111db56c  movaps [rcx], xmm1
00007ed4111db56f  mov rax, 0x5CA8E4A55A50
00007ed4111db579  call rax
00007ed4111db57b  movaps xmm6, [rsp]
00007ed4111db57f  add rsp, 0x40
00007ed4111db583  vmovaps xmm0, [rsp]
00007ed4111db588  vmovaps xmm1, [rsp+0x10]
00007ed4111db58e  vmovaps xmm2, [rsp+0x20]
00007ed4111db594  vmovaps xmm3, [rsp+0x30]
00007ed4111db59a  vmovaps xmm4, [rsp+0x40]
00007ed4111db5a0  vmovaps xmm5, [rsp+0x50]
00007ed4111db5a6  vmovaps xmm7, [rsp+0x60]
00007ed4111db5ac  vmovaps xmm8, [rsp+0x70]
00007ed4111db5b2  vmovaps xmm9, [rsp+0x80]
00007ed4111db5bb  vmovaps xmm10, [rsp+0x90]
00007ed4111db5c4  vmovaps xmm11, [rsp+0xA0]
00007ed4111db5cd  vmovaps xmm12, [rsp+0xB0]
00007ed4111db5d6  vmovaps xmm13, [rsp+0xC0]
00007ed4111db5df  vmovaps xmm14, [rsp+0xD0]
00007ed4111db5e8  vmovaps xmm15, [rsp+0xE0]
00007ed4111db5f1  add rsp, 0xF0
00007ed4111db5f8  pop r11
00007ed4111db5fa  pop r10
00007ed4111db5fc  pop r9
00007ed4111db5fe  pop r8
00007ed4111db600  pop rsi
00007ed4111db601  pop rdi
00007ed4111db602  pop rdx
00007ed4111db603  pop rcx
00007ed4111db604  pop rax
00007ed4111db605  add rsp, 0x08
00007ed4111db609  jmp 0x00007ED4111DA1C7
00007ed4111db60e  sub rsp, 0x08
00007ed4111db612  push rax
00007ed4111db613  push rcx
00007ed4111db614  push rdx
00007ed4111db615  push rdi
00007ed4111db616  push rsi
00007ed4111db617  push r8
00007ed4111db619  push r9
00007ed4111db61b  push r10
00007ed4111db61d  push r11
00007ed4111db61f  sub rsp, 0xF0
00007ed4111db626  vmovaps [rsp], xmm0
00007ed4111db62b  vmovaps [rsp+0x10], xmm1
00007ed4111db631  vmovaps [rsp+0x20], xmm2
00007ed4111db637  vmovaps [rsp+0x30], xmm3
00007ed4111db63d  vmovaps [rsp+0x40], xmm4
00007ed4111db643  vmovaps [rsp+0x50], xmm5
00007ed4111db649  vmovaps [rsp+0x60], xmm6
00007ed4111db64f  vmovaps [rsp+0x70], xmm7
00007ed4111db655  vmovaps [rsp+0x80], xmm8
00007ed4111db65e  vmovaps [rsp+0x90], xmm9
00007ed4111db667  vmovaps [rsp+0xA0], xmm10
00007ed4111db670  vmovaps [rsp+0xB0], xmm11
00007ed4111db679  vmovaps [rsp+0xC0], xmm12
00007ed4111db682  vmovaps [rsp+0xD0], xmm14
00007ed4111db68b  vmovaps [rsp+0xE0], xmm15
00007ed4111db694  sub rsp, 0x40
00007ed4111db698  lea rdi, [rsp]
00007ed4111db69c  lea rsi, [rsp+0x10]
00007ed4111db6a1  lea rdx, [rsp+0x20]
00007ed4111db6a6  lea rcx, [rsp+0x30]
00007ed4111db6ab  mov r8d, 0x00
00007ed4111db6b1  lea r9, [r15+0x3A8]
00007ed4111db6b8  movaps [rdi], xmm13
00007ed4111db6bc  movaps [rsi], xmm12
00007ed4111db6c0  movaps [rdx], xmm14
00007ed4111db6c4  movaps [rcx], xmm1
00007ed4111db6c7  mov rax, 0x5CA8E4A55A50
00007ed4111db6d1  call rax
00007ed4111db6d3  movaps xmm13, [rsp]
00007ed4111db6d8  add rsp, 0x40
00007ed4111db6dc  vmovaps xmm0, [rsp]
00007ed4111db6e1  vmovaps xmm1, [rsp+0x10]
00007ed4111db6e7  vmovaps xmm2, [rsp+0x20]
00007ed4111db6ed  vmovaps xmm3, [rsp+0x30]
00007ed4111db6f3  vmovaps xmm4, [rsp+0x40]
00007ed4111db6f9  vmovaps xmm5, [rsp+0x50]
00007ed4111db6ff  vmovaps xmm6, [rsp+0x60]
00007ed4111db705  vmovaps xmm7, [rsp+0x70]
00007ed4111db70b  vmovaps xmm8, [rsp+0x80]
00007ed4111db714  vmovaps xmm9, [rsp+0x90]
00007ed4111db71d  vmovaps xmm10, [rsp+0xA0]
00007ed4111db726  vmovaps xmm11, [rsp+0xB0]
00007ed4111db72f  vmovaps xmm12, [rsp+0xC0]
00007ed4111db738  vmovaps xmm14, [rsp+0xD0]
00007ed4111db741  vmovaps xmm15, [rsp+0xE0]
00007ed4111db74a  add rsp, 0xF0
00007ed4111db751  pop r11
00007ed4111db753  pop r10
00007ed4111db755  pop r9
00007ed4111db757  pop r8
00007ed4111db759  pop rsi
00007ed4111db75a  pop rdi
00007ed4111db75b  pop rdx
00007ed4111db75c  pop rcx
00007ed4111db75d  pop rax
00007ed4111db75e  add rsp, 0x08
00007ed4111db762  jmp 0x00007ED4111DA1F9
00007ed4111db767  sub rsp, 0x08
00007ed4111db76b  push rax
00007ed4111db76c  push rcx
00007ed4111db76d  push rdx
00007ed4111db76e  push rdi
00007ed4111db76f  push rsi
00007ed4111db770  push r8
00007ed4111db772  push r9
00007ed4111db774  push r10
00007ed4111db776  push r11
00007ed4111db778  sub rsp, 0xF0
00007ed4111db77f  vmovaps [rsp], xmm0
00007ed4111db784  vmovaps [rsp+0x10], xmm1
00007ed4111db78a  vmovaps [rsp+0x20], xmm2
00007ed4111db790  vmovaps [rsp+0x30], xmm3
00007ed4111db796  vmovaps [rsp+0x40], xmm4
00007ed4111db79c  vmovaps [rsp+0x50], xmm5
00007ed4111db7a2  vmovaps [rsp+0x60], xmm6
00007ed4111db7a8  vmovaps [rsp+0x70], xmm7
00007ed4111db7ae  vmovaps [rsp+0x80], xmm8
00007ed4111db7b7  vmovaps [rsp+0x90], xmm9
00007ed4111db7c0  vmovaps [rsp+0xA0], xmm10
00007ed4111db7c9  vmovaps [rsp+0xB0], xmm11
00007ed4111db7d2  vmovaps [rsp+0xC0], xmm13
00007ed4111db7db  vmovaps [rsp+0xD0], xmm14
00007ed4111db7e4  vmovaps [rsp+0xE0], xmm15
00007ed4111db7ed  sub rsp, 0x40
00007ed4111db7f1  lea rdi, [rsp]
00007ed4111db7f5  lea rsi, [rsp+0x10]
00007ed4111db7fa  lea rdx, [rsp+0x20]
00007ed4111db7ff  lea rcx, [rsp+0x30]
00007ed4111db804  mov r8d, 0x00
00007ed4111db80a  lea r9, [r15+0x3A8]
00007ed4111db811  movaps [rdi], xmm12
00007ed4111db815  movaps [rsi], xmm3
00007ed4111db818  movaps [rdx], xmm14
00007ed4111db81c  movaps [rcx], xmm5
00007ed4111db81f  mov rax, 0x5CA8E4A55A50
00007ed4111db829  call rax
00007ed4111db82b  movaps xmm12, [rsp]
00007ed4111db830  add rsp, 0x40
00007ed4111db834  vmovaps xmm0, [rsp]
00007ed4111db839  vmovaps xmm1, [rsp+0x10]
00007ed4111db83f  vmovaps xmm2, [rsp+0x20]
00007ed4111db845  vmovaps xmm3, [rsp+0x30]
00007ed4111db84b  vmovaps xmm4, [rsp+0x40]
00007ed4111db851  vmovaps xmm5, [rsp+0x50]
00007ed4111db857  vmovaps xmm6, [rsp+0x60]
00007ed4111db85d  vmovaps xmm7, [rsp+0x70]
00007ed4111db863  vmovaps xmm8, [rsp+0x80]
00007ed4111db86c  vmovaps xmm9, [rsp+0x90]
00007ed4111db875  vmovaps xmm10, [rsp+0xA0]
00007ed4111db87e  vmovaps xmm11, [rsp+0xB0]
00007ed4111db887  vmovaps xmm13, [rsp+0xC0]
00007ed4111db890  vmovaps xmm14, [rsp+0xD0]
00007ed4111db899  vmovaps xmm15, [rsp+0xE0]
00007ed4111db8a2  add rsp, 0xF0
00007ed4111db8a9  pop r11
00007ed4111db8ab  pop r10
00007ed4111db8ad  pop r9
00007ed4111db8af  pop r8
00007ed4111db8b1  pop rsi
00007ed4111db8b2  pop rdi
00007ed4111db8b3  pop rdx
00007ed4111db8b4  pop rcx
00007ed4111db8b5  pop rax
00007ed4111db8b6  add rsp, 0x08
00007ed4111db8ba  jmp 0x00007ED4111DA256
00007ed4111db8bf  sub rsp, 0x08
00007ed4111db8c3  push rax
00007ed4111db8c4  push rcx
00007ed4111db8c5  push rdx
00007ed4111db8c6  push rdi
00007ed4111db8c7  push rsi
00007ed4111db8c8  push r8
00007ed4111db8ca  push r9
00007ed4111db8cc  push r10
00007ed4111db8ce  push r11
00007ed4111db8d0  sub rsp, 0xF0
00007ed4111db8d7  vmovaps [rsp], xmm0
00007ed4111db8dc  vmovaps [rsp+0x10], xmm1
00007ed4111db8e2  vmovaps [rsp+0x20], xmm2
00007ed4111db8e8  vmovaps [rsp+0x30], xmm3
00007ed4111db8ee  vmovaps [rsp+0x40], xmm4
00007ed4111db8f4  vmovaps [rsp+0x50], xmm5
00007ed4111db8fa  vmovaps [rsp+0x60], xmm6
00007ed4111db900  vmovaps [rsp+0x70], xmm7
00007ed4111db906  vmovaps [rsp+0x80], xmm8
00007ed4111db90f  vmovaps [rsp+0x90], xmm9
00007ed4111db918  vmovaps [rsp+0xA0], xmm11
00007ed4111db921  vmovaps [rsp+0xB0], xmm12
00007ed4111db92a  vmovaps [rsp+0xC0], xmm13
00007ed4111db933  vmovaps [rsp+0xD0], xmm14
00007ed4111db93c  vmovaps [rsp+0xE0], xmm15
00007ed4111db945  sub rsp, 0x40
00007ed4111db949  lea rdi, [rsp]
00007ed4111db94d  lea rsi, [rsp+0x10]
00007ed4111db952  lea rdx, [rsp+0x20]
00007ed4111db957  lea rcx, [rsp+0x30]
00007ed4111db95c  mov r8d, 0x00
00007ed4111db962  lea r9, [r15+0x3A8]
00007ed4111db969  movaps [rdi], xmm10
00007ed4111db96d  movaps [rsi], xmm9
00007ed4111db971  movaps [rdx], xmm7
00007ed4111db974  movaps [rcx], xmm14
00007ed4111db978  mov rax, 0x5CA8E4A55A50
00007ed4111db982  call rax
00007ed4111db984  movaps xmm10, [rsp]
00007ed4111db989  add rsp, 0x40
00007ed4111db98d  vmovaps xmm0, [rsp]
00007ed4111db992  vmovaps xmm1, [rsp+0x10]
00007ed4111db998  vmovaps xmm2, [rsp+0x20]
00007ed4111db99e  vmovaps xmm3, [rsp+0x30]
00007ed4111db9a4  vmovaps xmm4, [rsp+0x40]
00007ed4111db9aa  vmovaps xmm5, [rsp+0x50]
00007ed4111db9b0  vmovaps xmm6, [rsp+0x60]
00007ed4111db9b6  vmovaps xmm7, [rsp+0x70]
00007ed4111db9bc  vmovaps xmm8, [rsp+0x80]
00007ed4111db9c5  vmovaps xmm9, [rsp+0x90]
00007ed4111db9ce  vmovaps xmm11, [rsp+0xA0]
00007ed4111db9d7  vmovaps xmm12, [rsp+0xB0]
00007ed4111db9e0  vmovaps xmm13, [rsp+0xC0]
00007ed4111db9e9  vmovaps xmm14, [rsp+0xD0]
00007ed4111db9f2  vmovaps xmm15, [rsp+0xE0]
00007ed4111db9fb  add rsp, 0xF0
00007ed4111dba02  pop r11
00007ed4111dba04  pop r10
00007ed4111dba06  pop r9
00007ed4111dba08  pop r8
00007ed4111dba0a  pop rsi
00007ed4111dba0b  pop rdi
00007ed4111dba0c  pop rdx
00007ed4111dba0d  pop rcx
00007ed4111dba0e  pop rax
00007ed4111dba0f  add rsp, 0x08
00007ed4111dba13  jmp 0x00007ED4111DA27C
00007ed4111dba18  call 0x00007ED41100D4E0
00007ed4111dba1d  jmp 0x00007ED4111DA289
00007ed4111dba22  sub rsp, 0x08
00007ed4111dba26  push rax
00007ed4111dba27  push rcx
00007ed4111dba28  push rdx
00007ed4111dba29  push rdi
00007ed4111dba2a  push rsi
00007ed4111dba2b  push r8
00007ed4111dba2d  push r9
00007ed4111dba2f  push r10
00007ed4111dba31  push r11
00007ed4111dba33  sub rsp, 0xF0
00007ed4111dba3a  vmovaps [rsp], xmm0
00007ed4111dba3f  vmovaps [rsp+0x10], xmm1
00007ed4111dba45  vmovaps [rsp+0x20], xmm2
00007ed4111dba4b  vmovaps [rsp+0x30], xmm3
00007ed4111dba51  vmovaps [rsp+0x40], xmm4
00007ed4111dba57  vmovaps [rsp+0x50], xmm6
00007ed4111dba5d  vmovaps [rsp+0x60], xmm7
00007ed4111dba63  vmovaps [rsp+0x70], xmm8
00007ed4111dba69  vmovaps [rsp+0x80], xmm9
00007ed4111dba72  vmovaps [rsp+0x90], xmm10
00007ed4111dba7b  vmovaps [rsp+0xA0], xmm11
00007ed4111dba84  vmovaps [rsp+0xB0], xmm12
00007ed4111dba8d  vmovaps [rsp+0xC0], xmm13
00007ed4111dba96  vmovaps [rsp+0xD0], xmm14
00007ed4111dba9f  vmovaps [rsp+0xE0], xmm15
00007ed4111dbaa8  sub rsp, 0x40
00007ed4111dbaac  lea rdi, [rsp]
00007ed4111dbab0  lea rsi, [rsp+0x10]
00007ed4111dbab5  lea rdx, [rsp+0x20]
00007ed4111dbaba  lea rcx, [rsp+0x30]
00007ed4111dbabf  mov r8d, 0x00
00007ed4111dbac5  lea r9, [r15+0x3A8]
00007ed4111dbacc  movaps [rdi], xmm5
00007ed4111dbacf  movaps [rsi], xmm6
00007ed4111dbad2  movaps [rdx], xmm7
00007ed4111dbad5  movaps [rcx], xmm9
00007ed4111dbad9  mov rax, 0x5CA8E4A55A50
00007ed4111dbae3  call rax
00007ed4111dbae5  movaps xmm5, [rsp]
00007ed4111dbae9  add rsp, 0x40
00007ed4111dbaed  vmovaps xmm0, [rsp]
00007ed4111dbaf2  vmovaps xmm1, [rsp+0x10]
00007ed4111dbaf8  vmovaps xmm2, [rsp+0x20]
00007ed4111dbafe  vmovaps xmm3, [rsp+0x30]
00007ed4111dbb04  vmovaps xmm4, [rsp+0x40]
00007ed4111dbb0a  vmovaps xmm6, [rsp+0x50]
00007ed4111dbb10  vmovaps xmm7, [rsp+0x60]
00007ed4111dbb16  vmovaps xmm8, [rsp+0x70]
00007ed4111dbb1c  vmovaps xmm9, [rsp+0x80]
00007ed4111dbb25  vmovaps xmm10, [rsp+0x90]
00007ed4111dbb2e  vmovaps xmm11, [rsp+0xA0]
00007ed4111dbb37  vmovaps xmm12, [rsp+0xB0]
00007ed4111dbb40  vmovaps xmm13, [rsp+0xC0]
00007ed4111dbb49  vmovaps xmm14, [rsp+0xD0]
00007ed4111dbb52  vmovaps xmm15, [rsp+0xE0]
00007ed4111dbb5b  add rsp, 0xF0
00007ed4111dbb62  pop r11
00007ed4111dbb64  pop r10
00007ed4111dbb66  pop r9
00007ed4111dbb68  pop r8
00007ed4111dbb6a  pop rsi
00007ed4111dbb6b  pop rdi
00007ed4111dbb6c  pop rdx
00007ed4111dbb6d  pop rcx
00007ed4111dbb6e  pop rax
00007ed4111dbb6f  add rsp, 0x08
00007ed4111dbb73  jmp 0x00007ED4111DA2BB
00007ed4111dbb78  sub rsp, 0x08
00007ed4111dbb7c  push rax
00007ed4111dbb7d  push rcx
00007ed4111dbb7e  push rdx
00007ed4111dbb7f  push rdi
00007ed4111dbb80  push rsi
00007ed4111dbb81  push r8
00007ed4111dbb83  push r9
00007ed4111dbb85  push r10
00007ed4111dbb87  push r11
00007ed4111dbb89  sub rsp, 0xF0
00007ed4111dbb90  vmovaps [rsp], xmm0
00007ed4111dbb95  vmovaps [rsp+0x10], xmm1
00007ed4111dbb9b  vmovaps [rsp+0x20], xmm2
00007ed4111dbba1  vmovaps [rsp+0x30], xmm3
00007ed4111dbba7  vmovaps [rsp+0x40], xmm4
00007ed4111dbbad  vmovaps [rsp+0x50], xmm5
00007ed4111dbbb3  vmovaps [rsp+0x60], xmm6
00007ed4111dbbb9  vmovaps [rsp+0x70], xmm8
00007ed4111dbbbf  vmovaps [rsp+0x80], xmm9
00007ed4111dbbc8  vmovaps [rsp+0x90], xmm10
00007ed4111dbbd1  vmovaps [rsp+0xA0], xmm11
00007ed4111dbbda  vmovaps [rsp+0xB0], xmm12
00007ed4111dbbe3  vmovaps [rsp+0xC0], xmm13
00007ed4111dbbec  vmovaps [rsp+0xD0], xmm14
00007ed4111dbbf5  vmovaps [rsp+0xE0], xmm15
00007ed4111dbbfe  sub rsp, 0x40
00007ed4111dbc02  lea rdi, [rsp]
00007ed4111dbc06  lea rsi, [rsp+0x10]
00007ed4111dbc0b  lea rdx, [rsp+0x20]
00007ed4111dbc10  lea rcx, [rsp+0x30]
00007ed4111dbc15  mov r8d, 0x00
00007ed4111dbc1b  lea r9, [r15+0x3A8]
00007ed4111dbc22  movaps [rdi], xmm7
00007ed4111dbc25  movaps [rsi], xmm13
00007ed4111dbc29  movaps [rdx], xmm1
00007ed4111dbc2c  movaps [rcx], xmm9
00007ed4111dbc30  mov rax, 0x5CA8E4A55A50
00007ed4111dbc3a  call rax
00007ed4111dbc3c  movaps xmm7, [rsp]
00007ed4111dbc40  add rsp, 0x40
00007ed4111dbc44  vmovaps xmm0, [rsp]
00007ed4111dbc49  vmovaps xmm1, [rsp+0x10]
00007ed4111dbc4f  vmovaps xmm2, [rsp+0x20]
00007ed4111dbc55  vmovaps xmm3, [rsp+0x30]
00007ed4111dbc5b  vmovaps xmm4, [rsp+0x40]
00007ed4111dbc61  vmovaps xmm5, [rsp+0x50]
00007ed4111dbc67  vmovaps xmm6, [rsp+0x60]
00007ed4111dbc6d  vmovaps xmm8, [rsp+0x70]
00007ed4111dbc73  vmovaps xmm9, [rsp+0x80]
00007ed4111dbc7c  vmovaps xmm10, [rsp+0x90]
00007ed4111dbc85  vmovaps xmm11, [rsp+0xA0]
00007ed4111dbc8e  vmovaps xmm12, [rsp+0xB0]
00007ed4111dbc97  vmovaps xmm13, [rsp+0xC0]
00007ed4111dbca0  vmovaps xmm14, [rsp+0xD0]
00007ed4111dbca9  vmovaps xmm15, [rsp+0xE0]
00007ed4111dbcb2  add rsp, 0xF0
00007ed4111dbcb9  pop r11
00007ed4111dbcbb  pop r10
00007ed4111dbcbd  pop r9
00007ed4111dbcbf  pop r8
00007ed4111dbcc1  pop rsi
00007ed4111dbcc2  pop rdi
00007ed4111dbcc3  pop rdx
00007ed4111dbcc4  pop rcx
00007ed4111dbcc5  pop rax
00007ed4111dbcc6  add rsp, 0x08
00007ed4111dbcca  jmp 0x00007ED4111DA2E0
00007ed4111dbccf  call 0x00007ED41100C260
00007ed4111dbcd4  jmp 0x00007ED4111DA303
00007ed4111dbcd9  call 0x00007ED411007890
00007ed4111dbcde  jmp 0x00007ED4111DA30D
00007ed4111dbce3  sub rsp, 0x08
00007ed4111dbce7  push rax
00007ed4111dbce8  push rcx
00007ed4111dbce9  push rdx
00007ed4111dbcea  push rdi
00007ed4111dbceb  push rsi
00007ed4111dbcec  push r8
00007ed4111dbcee  push r9
00007ed4111dbcf0  push r10
00007ed4111dbcf2  push r11
00007ed4111dbcf4  sub rsp, 0xF0
00007ed4111dbcfb  vmovaps [rsp], xmm0
00007ed4111dbd00  vmovaps [rsp+0x10], xmm1
00007ed4111dbd06  vmovaps [rsp+0x20], xmm3
00007ed4111dbd0c  vmovaps [rsp+0x30], xmm4
00007ed4111dbd12  vmovaps [rsp+0x40], xmm5
00007ed4111dbd18  vmovaps [rsp+0x50], xmm6
00007ed4111dbd1e  vmovaps [rsp+0x60], xmm7
00007ed4111dbd24  vmovaps [rsp+0x70], xmm8
00007ed4111dbd2a  vmovaps [rsp+0x80], xmm9
00007ed4111dbd33  vmovaps [rsp+0x90], xmm10
00007ed4111dbd3c  vmovaps [rsp+0xA0], xmm11
00007ed4111dbd45  vmovaps [rsp+0xB0], xmm12
00007ed4111dbd4e  vmovaps [rsp+0xC0], xmm13
00007ed4111dbd57  vmovaps [rsp+0xD0], xmm14
00007ed4111dbd60  vmovaps [rsp+0xE0], xmm15
00007ed4111dbd69  sub rsp, 0x40
00007ed4111dbd6d  lea rdi, [rsp]
00007ed4111dbd71  lea rsi, [rsp+0x10]
00007ed4111dbd76  lea rdx, [rsp+0x20]
00007ed4111dbd7b  lea rcx, [rsp+0x30]
00007ed4111dbd80  mov r8d, 0x00
00007ed4111dbd86  lea r9, [r15+0x3A8]
00007ed4111dbd8d  movaps [rdi], xmm2
00007ed4111dbd90  movaps [rsi], xmm12
00007ed4111dbd94  movaps [rdx], xmm6
00007ed4111dbd97  movaps [rcx], xmm3
00007ed4111dbd9a  mov rax, 0x5CA8E4A55A50
00007ed4111dbda4  call rax
00007ed4111dbda6  movaps xmm2, [rsp]
00007ed4111dbdaa  add rsp, 0x40
00007ed4111dbdae  vmovaps xmm0, [rsp]
00007ed4111dbdb3  vmovaps xmm1, [rsp+0x10]
00007ed4111dbdb9  vmovaps xmm3, [rsp+0x20]
00007ed4111dbdbf  vmovaps xmm4, [rsp+0x30]
00007ed4111dbdc5  vmovaps xmm5, [rsp+0x40]
00007ed4111dbdcb  vmovaps xmm6, [rsp+0x50]
00007ed4111dbdd1  vmovaps xmm7, [rsp+0x60]
00007ed4111dbdd7  vmovaps xmm8, [rsp+0x70]
00007ed4111dbddd  vmovaps xmm9, [rsp+0x80]
00007ed4111dbde6  vmovaps xmm10, [rsp+0x90]
00007ed4111dbdef  vmovaps xmm11, [rsp+0xA0]
00007ed4111dbdf8  vmovaps xmm12, [rsp+0xB0]
00007ed4111dbe01  vmovaps xmm13, [rsp+0xC0]
00007ed4111dbe0a  vmovaps xmm14, [rsp+0xD0]
00007ed4111dbe13  vmovaps xmm15, [rsp+0xE0]
00007ed4111dbe1c  add rsp, 0xF0
00007ed4111dbe23  pop r11
00007ed4111dbe25  pop r10
00007ed4111dbe27  pop r9
00007ed4111dbe29  pop r8
00007ed4111dbe2b  pop rsi
00007ed4111dbe2c  pop rdi
00007ed4111dbe2d  pop rdx
00007ed4111dbe2e  pop rcx
00007ed4111dbe2f  pop rax
00007ed4111dbe30  add rsp, 0x08
00007ed4111dbe34  jmp 0x00007ED4111DA353
00007ed4111dbe39  sub rsp, 0x08
00007ed4111dbe3d  push rax
00007ed4111dbe3e  push rcx
00007ed4111dbe3f  push rdx
00007ed4111dbe40  push rdi
00007ed4111dbe41  push rsi
00007ed4111dbe42  push r8
00007ed4111dbe44  push r9
00007ed4111dbe46  push r10
00007ed4111dbe48  push r11
00007ed4111dbe4a  sub rsp, 0xF0
00007ed4111dbe51  vmovaps [rsp], xmm0
00007ed4111dbe56  vmovaps [rsp+0x10], xmm1
00007ed4111dbe5c  vmovaps [rsp+0x20], xmm2
00007ed4111dbe62  vmovaps [rsp+0x30], xmm3
00007ed4111dbe68  vmovaps [rsp+0x40], xmm4
00007ed4111dbe6e  vmovaps [rsp+0x50], xmm5
00007ed4111dbe74  vmovaps [rsp+0x60], xmm7
00007ed4111dbe7a  vmovaps [rsp+0x70], xmm8
00007ed4111dbe80  vmovaps [rsp+0x80], xmm9
00007ed4111dbe89  vmovaps [rsp+0x90], xmm10
00007ed4111dbe92  vmovaps [rsp+0xA0], xmm11
00007ed4111dbe9b  vmovaps [rsp+0xB0], xmm12
00007ed4111dbea4  vmovaps [rsp+0xC0], xmm13
00007ed4111dbead  vmovaps [rsp+0xD0], xmm14
00007ed4111dbeb6  vmovaps [rsp+0xE0], xmm15
00007ed4111dbebf  sub rsp, 0x40
00007ed4111dbec3  lea rdi, [rsp]
00007ed4111dbec7  lea rsi, [rsp+0x10]
00007ed4111dbecc  lea rdx, [rsp+0x20]
00007ed4111dbed1  lea rcx, [rsp+0x30]
00007ed4111dbed6  mov r8d, 0x00
00007ed4111dbedc  lea r9, [r15+0x3A8]
00007ed4111dbee3  movaps [rdi], xmm6
00007ed4111dbee6  movaps [rsi], xmm10
00007ed4111dbeea  movaps [rdx], xmm12
00007ed4111dbeee  movaps [rcx], xmm1
00007ed4111dbef1  mov rax, 0x5CA8E4A55A50
00007ed4111dbefb  call rax
00007ed4111dbefd  movaps xmm6, [rsp]
00007ed4111dbf01  add rsp, 0x40
00007ed4111dbf05  vmovaps xmm0, [rsp]
00007ed4111dbf0a  vmovaps xmm1, [rsp+0x10]
00007ed4111dbf10  vmovaps xmm2, [rsp+0x20]
00007ed4111dbf16  vmovaps xmm3, [rsp+0x30]
00007ed4111dbf1c  vmovaps xmm4, [rsp+0x40]
00007ed4111dbf22  vmovaps xmm5, [rsp+0x50]
00007ed4111dbf28  vmovaps xmm7, [rsp+0x60]
00007ed4111dbf2e  vmovaps xmm8, [rsp+0x70]
00007ed4111dbf34  vmovaps xmm9, [rsp+0x80]
00007ed4111dbf3d  vmovaps xmm10, [rsp+0x90]
00007ed4111dbf46  vmovaps xmm11, [rsp+0xA0]
00007ed4111dbf4f  vmovaps xmm12, [rsp+0xB0]
00007ed4111dbf58  vmovaps xmm13, [rsp+0xC0]
00007ed4111dbf61  vmovaps xmm14, [rsp+0xD0]
00007ed4111dbf6a  vmovaps xmm15, [rsp+0xE0]
00007ed4111dbf73  add rsp, 0xF0
00007ed4111dbf7a  pop r11
00007ed4111dbf7c  pop r10
00007ed4111dbf7e  pop r9
00007ed4111dbf80  pop r8
00007ed4111dbf82  pop rsi
00007ed4111dbf83  pop rdi
00007ed4111dbf84  pop rdx
00007ed4111dbf85  pop rcx
00007ed4111dbf86  pop rax
00007ed4111dbf87  add rsp, 0x08
00007ed4111dbf8b  jmp 0x00007ED4111DA381
00007ed4111dbf90  sub rsp, 0x08
00007ed4111dbf94  push rax
00007ed4111dbf95  push rcx
00007ed4111dbf96  push rdx
00007ed4111dbf97  push rdi
00007ed4111dbf98  push rsi
00007ed4111dbf99  push r8
00007ed4111dbf9b  push r9
00007ed4111dbf9d  push r10
00007ed4111dbf9f  push r11
00007ed4111dbfa1  sub rsp, 0xF0
00007ed4111dbfa8  vmovaps [rsp], xmm0
00007ed4111dbfad  vmovaps [rsp+0x10], xmm1
00007ed4111dbfb3  vmovaps [rsp+0x20], xmm2
00007ed4111dbfb9  vmovaps [rsp+0x30], xmm3
00007ed4111dbfbf  vmovaps [rsp+0x40], xmm4
00007ed4111dbfc5  vmovaps [rsp+0x50], xmm5
00007ed4111dbfcb  vmovaps [rsp+0x60], xmm6
00007ed4111dbfd1  vmovaps [rsp+0x70], xmm7
00007ed4111dbfd7  vmovaps [rsp+0x80], xmm8
00007ed4111dbfe0  vmovaps [rsp+0x90], xmm9
00007ed4111dbfe9  vmovaps [rsp+0xA0], xmm11
00007ed4111dbff2  vmovaps [rsp+0xB0], xmm12
00007ed4111dbffb  vmovaps [rsp+0xC0], xmm13
00007ed4111dc004  vmovaps [rsp+0xD0], xmm14
00007ed4111dc00d  vmovaps [rsp+0xE0], xmm15
00007ed4111dc016  sub rsp, 0x40
00007ed4111dc01a  lea rdi, [rsp]
00007ed4111dc01e  lea rsi, [rsp+0x10]
00007ed4111dc023  lea rdx, [rsp+0x20]
00007ed4111dc028  lea rcx, [rsp+0x30]
00007ed4111dc02d  mov r8d, 0x00
00007ed4111dc033  lea r9, [r15+0x3A8]
00007ed4111dc03a  movaps [rdi], xmm10
00007ed4111dc03e  movaps [rsi], xmm5
00007ed4111dc041  movaps [rdx], xmm12
00007ed4111dc045  movaps [rcx], xmm1
00007ed4111dc048  mov rax, 0x5CA8E4A55A50
00007ed4111dc052  call rax
00007ed4111dc054  movaps xmm10, [rsp]
00007ed4111dc059  add rsp, 0x40
00007ed4111dc05d  vmovaps xmm0, [rsp]
00007ed4111dc062  vmovaps xmm1, [rsp+0x10]
00007ed4111dc068  vmovaps xmm2, [rsp+0x20]
00007ed4111dc06e  vmovaps xmm3, [rsp+0x30]
00007ed4111dc074  vmovaps xmm4, [rsp+0x40]
00007ed4111dc07a  vmovaps xmm5, [rsp+0x50]
00007ed4111dc080  vmovaps xmm6, [rsp+0x60]
00007ed4111dc086  vmovaps xmm7, [rsp+0x70]
00007ed4111dc08c  vmovaps xmm8, [rsp+0x80]
00007ed4111dc095  vmovaps xmm9, [rsp+0x90]
00007ed4111dc09e  vmovaps xmm11, [rsp+0xA0]
00007ed4111dc0a7  vmovaps xmm12, [rsp+0xB0]
00007ed4111dc0b0  vmovaps xmm13, [rsp+0xC0]
00007ed4111dc0b9  vmovaps xmm14, [rsp+0xD0]
00007ed4111dc0c2  vmovaps xmm15, [rsp+0xE0]
00007ed4111dc0cb  add rsp, 0xF0
00007ed4111dc0d2  pop r11
00007ed4111dc0d4  pop r10
00007ed4111dc0d6  pop r9
00007ed4111dc0d8  pop r8
00007ed4111dc0da  pop rsi
00007ed4111dc0db  pop rdi
00007ed4111dc0dc  pop rdx
00007ed4111dc0dd  pop rcx
00007ed4111dc0de  pop rax
00007ed4111dc0df  add rsp, 0x08
00007ed4111dc0e3  jmp 0x00007ED4111DA3B0
00007ed4111dc0e8  sub rsp, 0x08
00007ed4111dc0ec  push rax
00007ed4111dc0ed  push rcx
00007ed4111dc0ee  push rdx
00007ed4111dc0ef  push rdi
00007ed4111dc0f0  push rsi
00007ed4111dc0f1  push r8
00007ed4111dc0f3  push r9
00007ed4111dc0f5  push r10
00007ed4111dc0f7  push r11
00007ed4111dc0f9  sub rsp, 0xF0
00007ed4111dc100  vmovaps [rsp], xmm0
00007ed4111dc105  vmovaps [rsp+0x10], xmm1
00007ed4111dc10b  vmovaps [rsp+0x20], xmm2
00007ed4111dc111  vmovaps [rsp+0x30], xmm3
00007ed4111dc117  vmovaps [rsp+0x40], xmm4
00007ed4111dc11d  vmovaps [rsp+0x50], xmm5
00007ed4111dc123  vmovaps [rsp+0x60], xmm6
00007ed4111dc129  vmovaps [rsp+0x70], xmm7
00007ed4111dc12f  vmovaps [rsp+0x80], xmm8
00007ed4111dc138  vmovaps [rsp+0x90], xmm9
00007ed4111dc141  vmovaps [rsp+0xA0], xmm10
00007ed4111dc14a  vmovaps [rsp+0xB0], xmm11
00007ed4111dc153  vmovaps [rsp+0xC0], xmm13
00007ed4111dc15c  vmovaps [rsp+0xD0], xmm14
00007ed4111dc165  vmovaps [rsp+0xE0], xmm15
00007ed4111dc16e  sub rsp, 0x40
00007ed4111dc172  lea rdi, [rsp]
00007ed4111dc176  lea rsi, [rsp+0x10]
00007ed4111dc17b  lea rdx, [rsp+0x20]
00007ed4111dc180  lea rcx, [rsp+0x30]
00007ed4111dc185  mov r8d, 0x00
00007ed4111dc18b  lea r9, [r15+0x3A8]
00007ed4111dc192  movaps [rdi], xmm12
00007ed4111dc196  movaps [rsi], xmm7
00007ed4111dc199  movaps [rdx], xmm15
00007ed4111dc19d  movaps [rcx], xmm1
00007ed4111dc1a0  mov rax, 0x5CA8E4A55A50
00007ed4111dc1aa  call rax
00007ed4111dc1ac  movaps xmm12, [rsp]
00007ed4111dc1b1  add rsp, 0x40
00007ed4111dc1b5  vmovaps xmm0, [rsp]
00007ed4111dc1ba  vmovaps xmm1, [rsp+0x10]
00007ed4111dc1c0  vmovaps xmm2, [rsp+0x20]
00007ed4111dc1c6  vmovaps xmm3, [rsp+0x30]
00007ed4111dc1cc  vmovaps xmm4, [rsp+0x40]
00007ed4111dc1d2  vmovaps xmm5, [rsp+0x50]
00007ed4111dc1d8  vmovaps xmm6, [rsp+0x60]
00007ed4111dc1de  vmovaps xmm7, [rsp+0x70]
00007ed4111dc1e4  vmovaps xmm8, [rsp+0x80]
00007ed4111dc1ed  vmovaps xmm9, [rsp+0x90]
00007ed4111dc1f6  vmovaps xmm10, [rsp+0xA0]
00007ed4111dc1ff  vmovaps xmm11, [rsp+0xB0]
00007ed4111dc208  vmovaps xmm13, [rsp+0xC0]
00007ed4111dc211  vmovaps xmm14, [rsp+0xD0]
00007ed4111dc21a  vmovaps xmm15, [rsp+0xE0]
00007ed4111dc223  add rsp, 0xF0
00007ed4111dc22a  pop r11
00007ed4111dc22c  pop r10
00007ed4111dc22e  pop r9
00007ed4111dc230  pop r8
00007ed4111dc232  pop rsi
00007ed4111dc233  pop rdi
00007ed4111dc234  pop rdx
00007ed4111dc235  pop rcx
00007ed4111dc236  pop rax
00007ed4111dc237  add rsp, 0x08
00007ed4111dc23b  jmp 0x00007ED4111DA3D9
00007ed4111dc240  call 0x00007ED410FFF430
00007ed4111dc245  jmp 0x00007ED4111DA3E3
00007ed4111dc24a  call 0x00007ED41100E760
00007ed4111dc24f  jmp 0x00007ED4111DA3ED
00007ed4111dc254  sub rsp, 0x08
00007ed4111dc258  push rax
00007ed4111dc259  push rcx
00007ed4111dc25a  push rdx
00007ed4111dc25b  push rdi
00007ed4111dc25c  push rsi
00007ed4111dc25d  push r8
00007ed4111dc25f  push r9
00007ed4111dc261  push r10
00007ed4111dc263  push r11
00007ed4111dc265  sub rsp, 0xF0
00007ed4111dc26c  vmovaps [rsp], xmm0
00007ed4111dc271  vmovaps [rsp+0x10], xmm1
00007ed4111dc277  vmovaps [rsp+0x20], xmm2
00007ed4111dc27d  vmovaps [rsp+0x30], xmm3
00007ed4111dc283  vmovaps [rsp+0x40], xmm4
00007ed4111dc289  vmovaps [rsp+0x50], xmm5
00007ed4111dc28f  vmovaps [rsp+0x60], xmm6
00007ed4111dc295  vmovaps [rsp+0x70], xmm8
00007ed4111dc29b  vmovaps [rsp+0x80], xmm9
00007ed4111dc2a4  vmovaps [rsp+0x90], xmm10
00007ed4111dc2ad  vmovaps [rsp+0xA0], xmm11
00007ed4111dc2b6  vmovaps [rsp+0xB0], xmm12
00007ed4111dc2bf  vmovaps [rsp+0xC0], xmm13
00007ed4111dc2c8  vmovaps [rsp+0xD0], xmm14
00007ed4111dc2d1  vmovaps [rsp+0xE0], xmm15
00007ed4111dc2da  sub rsp, 0x40
00007ed4111dc2de  lea rdi, [rsp]
00007ed4111dc2e2  lea rsi, [rsp+0x10]
00007ed4111dc2e7  lea rdx, [rsp+0x20]
00007ed4111dc2ec  lea rcx, [rsp+0x30]
00007ed4111dc2f1  mov r8d, 0x00
00007ed4111dc2f7  lea r9, [r15+0x3A8]
00007ed4111dc2fe  movaps [rdi], xmm7
00007ed4111dc301  movaps [rsi], xmm2
00007ed4111dc304  movaps [rdx], xmm9
00007ed4111dc308  movaps [rcx], xmm11
00007ed4111dc30c  mov rax, 0x5CA8E4A55A50
00007ed4111dc316  call rax
00007ed4111dc318  movaps xmm7, [rsp]
00007ed4111dc31c  add rsp, 0x40
00007ed4111dc320  vmovaps xmm0, [rsp]
00007ed4111dc325  vmovaps xmm1, [rsp+0x10]
00007ed4111dc32b  vmovaps xmm2, [rsp+0x20]
00007ed4111dc331  vmovaps xmm3, [rsp+0x30]
00007ed4111dc337  vmovaps xmm4, [rsp+0x40]
00007ed4111dc33d  vmovaps xmm5, [rsp+0x50]
00007ed4111dc343  vmovaps xmm6, [rsp+0x60]
00007ed4111dc349  vmovaps xmm8, [rsp+0x70]
00007ed4111dc34f  vmovaps xmm9, [rsp+0x80]
00007ed4111dc358  vmovaps xmm10, [rsp+0x90]
00007ed4111dc361  vmovaps xmm11, [rsp+0xA0]
00007ed4111dc36a  vmovaps xmm12, [rsp+0xB0]
00007ed4111dc373  vmovaps xmm13, [rsp+0xC0]
00007ed4111dc37c  vmovaps xmm14, [rsp+0xD0]
00007ed4111dc385  vmovaps xmm15, [rsp+0xE0]
00007ed4111dc38e  add rsp, 0xF0
00007ed4111dc395  pop r11
00007ed4111dc397  pop r10
00007ed4111dc399  pop r9
00007ed4111dc39b  pop r8
00007ed4111dc39d  pop rsi
00007ed4111dc39e  pop rdi
00007ed4111dc39f  pop rdx
00007ed4111dc3a0  pop rcx
00007ed4111dc3a1  pop rax
00007ed4111dc3a2  add rsp, 0x08
00007ed4111dc3a6  jmp 0x00007ED4111DA421
00007ed4111dc3ab  sub rsp, 0x08
00007ed4111dc3af  push rax
00007ed4111dc3b0  push rcx
00007ed4111dc3b1  push rdx
00007ed4111dc3b2  push rdi
00007ed4111dc3b3  push rsi
00007ed4111dc3b4  push r8
00007ed4111dc3b6  push r9
00007ed4111dc3b8  push r10
00007ed4111dc3ba  push r11
00007ed4111dc3bc  sub rsp, 0xF0
00007ed4111dc3c3  vmovaps [rsp], xmm0
00007ed4111dc3c8  vmovaps [rsp+0x10], xmm1
00007ed4111dc3ce  vmovaps [rsp+0x20], xmm2
00007ed4111dc3d4  vmovaps [rsp+0x30], xmm3
00007ed4111dc3da  vmovaps [rsp+0x40], xmm4
00007ed4111dc3e0  vmovaps [rsp+0x50], xmm5
00007ed4111dc3e6  vmovaps [rsp+0x60], xmm6
00007ed4111dc3ec  vmovaps [rsp+0x70], xmm7
00007ed4111dc3f2  vmovaps [rsp+0x80], xmm8
00007ed4111dc3fb  vmovaps [rsp+0x90], xmm10
00007ed4111dc404  vmovaps [rsp+0xA0], xmm11
00007ed4111dc40d  vmovaps [rsp+0xB0], xmm12
00007ed4111dc416  vmovaps [rsp+0xC0], xmm13
00007ed4111dc41f  vmovaps [rsp+0xD0], xmm14
00007ed4111dc428  vmovaps [rsp+0xE0], xmm15
00007ed4111dc431  sub rsp, 0x40
00007ed4111dc435  lea rdi, [rsp]
00007ed4111dc439  lea rsi, [rsp+0x10]
00007ed4111dc43e  lea rdx, [rsp+0x20]
00007ed4111dc443  lea rcx, [rsp+0x30]
00007ed4111dc448  mov r8d, 0x00
00007ed4111dc44e  lea r9, [r15+0x3A8]
00007ed4111dc455  movaps [rdi], xmm9
00007ed4111dc459  movaps [rsi], xmm6
00007ed4111dc45c  movaps [rdx], xmm1
00007ed4111dc45f  movaps [rcx], xmm11
00007ed4111dc463  mov rax, 0x5CA8E4A55A50
00007ed4111dc46d  call rax
00007ed4111dc46f  movaps xmm9, [rsp]
00007ed4111dc474  add rsp, 0x40
00007ed4111dc478  vmovaps xmm0, [rsp]
00007ed4111dc47d  vmovaps xmm1, [rsp+0x10]
00007ed4111dc483  vmovaps xmm2, [rsp+0x20]
00007ed4111dc489  vmovaps xmm3, [rsp+0x30]
00007ed4111dc48f  vmovaps xmm4, [rsp+0x40]
00007ed4111dc495  vmovaps xmm5, [rsp+0x50]
00007ed4111dc49b  vmovaps xmm6, [rsp+0x60]
00007ed4111dc4a1  vmovaps xmm7, [rsp+0x70]
00007ed4111dc4a7  vmovaps xmm8, [rsp+0x80]
00007ed4111dc4b0  vmovaps xmm10, [rsp+0x90]
00007ed4111dc4b9  vmovaps xmm11, [rsp+0xA0]
00007ed4111dc4c2  vmovaps xmm12, [rsp+0xB0]
00007ed4111dc4cb  vmovaps xmm13, [rsp+0xC0]
00007ed4111dc4d4  vmovaps xmm14, [rsp+0xD0]
00007ed4111dc4dd  vmovaps xmm15, [rsp+0xE0]
00007ed4111dc4e6  add rsp, 0xF0
00007ed4111dc4ed  pop r11
00007ed4111dc4ef  pop r10
00007ed4111dc4f1  pop r9
00007ed4111dc4f3  pop r8
00007ed4111dc4f5  pop rsi
00007ed4111dc4f6  pop rdi
00007ed4111dc4f7  pop rdx
00007ed4111dc4f8  pop rcx
00007ed4111dc4f9  pop rax
00007ed4111dc4fa  add rsp, 0x08
00007ed4111dc4fe  jmp 0x00007ED4111DA447
00007ed4111dc503  sub rsp, 0x08
00007ed4111dc507  push rax
00007ed4111dc508  push rcx
00007ed4111dc509  push rdx
00007ed4111dc50a  push rdi
00007ed4111dc50b  push rsi
00007ed4111dc50c  push r8
00007ed4111dc50e  push r9
00007ed4111dc510  push r10
00007ed4111dc512  push r11
00007ed4111dc514  sub rsp, 0xF0
00007ed4111dc51b  vmovaps [rsp], xmm0
00007ed4111dc520  vmovaps [rsp+0x10], xmm1
00007ed4111dc526  vmovaps [rsp+0x20], xmm2
00007ed4111dc52c  vmovaps [rsp+0x30], xmm3
00007ed4111dc532  vmovaps [rsp+0x40], xmm4
00007ed4111dc538  vmovaps [rsp+0x50], xmm5
00007ed4111dc53e  vmovaps [rsp+0x60], xmm6
00007ed4111dc544  vmovaps [rsp+0x70], xmm7
00007ed4111dc54a  vmovaps [rsp+0x80], xmm8
00007ed4111dc553  vmovaps [rsp+0x90], xmm9
00007ed4111dc55c  vmovaps [rsp+0xA0], xmm10
00007ed4111dc565  vmovaps [rsp+0xB0], xmm12
00007ed4111dc56e  vmovaps [rsp+0xC0], xmm13
00007ed4111dc577  vmovaps [rsp+0xD0], xmm14
00007ed4111dc580  vmovaps [rsp+0xE0], xmm15
00007ed4111dc589  sub rsp, 0x40
00007ed4111dc58d  lea rdi, [rsp]
00007ed4111dc591  lea rsi, [rsp+0x10]
00007ed4111dc596  lea rdx, [rsp+0x20]
00007ed4111dc59b  lea rcx, [rsp+0x30]
00007ed4111dc5a0  mov r8d, 0x00
00007ed4111dc5a6  lea r9, [r15+0x3A8]
00007ed4111dc5ad  movaps [rdi], xmm11
00007ed4111dc5b1  movaps [rsi], xmm10
00007ed4111dc5b5  movaps [rdx], xmm8
00007ed4111dc5b9  movaps [rcx], xmm1
00007ed4111dc5bc  mov rax, 0x5CA8E4A55A50
00007ed4111dc5c6  call rax
00007ed4111dc5c8  movaps xmm11, [rsp]
00007ed4111dc5cd  add rsp, 0x40
00007ed4111dc5d1  vmovaps xmm0, [rsp]
00007ed4111dc5d6  vmovaps xmm1, [rsp+0x10]
00007ed4111dc5dc  vmovaps xmm2, [rsp+0x20]
00007ed4111dc5e2  vmovaps xmm3, [rsp+0x30]
00007ed4111dc5e8  vmovaps xmm4, [rsp+0x40]
00007ed4111dc5ee  vmovaps xmm5, [rsp+0x50]
00007ed4111dc5f4  vmovaps xmm6, [rsp+0x60]
00007ed4111dc5fa  vmovaps xmm7, [rsp+0x70]
00007ed4111dc600  vmovaps xmm8, [rsp+0x80]
00007ed4111dc609  vmovaps xmm9, [rsp+0x90]
00007ed4111dc612  vmovaps xmm10, [rsp+0xA0]
00007ed4111dc61b  vmovaps xmm12, [rsp+0xB0]
00007ed4111dc624  vmovaps xmm13, [rsp+0xC0]
00007ed4111dc62d  vmovaps xmm14, [rsp+0xD0]
00007ed4111dc636  vmovaps xmm15, [rsp+0xE0]
00007ed4111dc63f  add rsp, 0xF0
00007ed4111dc646  pop r11
00007ed4111dc648  pop r10
00007ed4111dc64a  pop r9
00007ed4111dc64c  pop r8
00007ed4111dc64e  pop rsi
00007ed4111dc64f  pop rdi
00007ed4111dc650  pop rdx
00007ed4111dc651  pop rcx
00007ed4111dc652  pop rax
00007ed4111dc653  add rsp, 0x08
00007ed4111dc657  jmp 0x00007ED4111DA46D
00007ed4111dc65c  sub rsp, 0x08
00007ed4111dc660  push rax
00007ed4111dc661  push rcx
00007ed4111dc662  push rdx
00007ed4111dc663  push rdi
00007ed4111dc664  push rsi
00007ed4111dc665  push r8
00007ed4111dc667  push r9
00007ed4111dc669  push r10
00007ed4111dc66b  push r11
00007ed4111dc66d  sub rsp, 0xF0
00007ed4111dc674  vmovaps [rsp], xmm0
00007ed4111dc679  vmovaps [rsp+0x10], xmm1
00007ed4111dc67f  vmovaps [rsp+0x20], xmm2
00007ed4111dc685  vmovaps [rsp+0x30], xmm3
00007ed4111dc68b  vmovaps [rsp+0x40], xmm4
00007ed4111dc691  vmovaps [rsp+0x50], xmm5
00007ed4111dc697  vmovaps [rsp+0x60], xmm6
00007ed4111dc69d  vmovaps [rsp+0x70], xmm7
00007ed4111dc6a3  vmovaps [rsp+0x80], xmm8
00007ed4111dc6ac  vmovaps [rsp+0x90], xmm9
00007ed4111dc6b5  vmovaps [rsp+0xA0], xmm11
00007ed4111dc6be  vmovaps [rsp+0xB0], xmm12
00007ed4111dc6c7  vmovaps [rsp+0xC0], xmm13
00007ed4111dc6d0  vmovaps [rsp+0xD0], xmm14
00007ed4111dc6d9  vmovaps [rsp+0xE0], xmm15
00007ed4111dc6e2  sub rsp, 0x40
00007ed4111dc6e6  lea rdi, [rsp]
00007ed4111dc6ea  lea rsi, [rsp+0x10]
00007ed4111dc6ef  lea rdx, [rsp+0x20]
00007ed4111dc6f4  lea rcx, [rsp+0x30]
00007ed4111dc6f9  mov r8d, 0x00
00007ed4111dc6ff  lea r9, [r15+0x3A8]
00007ed4111dc706  movaps [rdi], xmm10
00007ed4111dc70a  movaps [rsi], xmm12
00007ed4111dc70e  movaps [rdx], xmm13
00007ed4111dc712  movaps [rcx], xmm1
00007ed4111dc715  mov rax, 0x5CA8E4A55A50
00007ed4111dc71f  call rax
00007ed4111dc721  movaps xmm10, [rsp]
00007ed4111dc726  add rsp, 0x40
00007ed4111dc72a  vmovaps xmm0, [rsp]
00007ed4111dc72f  vmovaps xmm1, [rsp+0x10]
00007ed4111dc735  vmovaps xmm2, [rsp+0x20]
00007ed4111dc73b  vmovaps xmm3, [rsp+0x30]
00007ed4111dc741  vmovaps xmm4, [rsp+0x40]
00007ed4111dc747  vmovaps xmm5, [rsp+0x50]
00007ed4111dc74d  vmovaps xmm6, [rsp+0x60]
00007ed4111dc753  vmovaps xmm7, [rsp+0x70]
00007ed4111dc759  vmovaps xmm8, [rsp+0x80]
00007ed4111dc762  vmovaps xmm9, [rsp+0x90]
00007ed4111dc76b  vmovaps xmm11, [rsp+0xA0]
00007ed4111dc774  vmovaps xmm12, [rsp+0xB0]
00007ed4111dc77d  vmovaps xmm13, [rsp+0xC0]
00007ed4111dc786  vmovaps xmm14, [rsp+0xD0]
00007ed4111dc78f  vmovaps xmm15, [rsp+0xE0]
00007ed4111dc798  add rsp, 0xF0
00007ed4111dc79f  pop r11
00007ed4111dc7a1  pop r10
00007ed4111dc7a3  pop r9
00007ed4111dc7a5  pop r8
00007ed4111dc7a7  pop rsi
00007ed4111dc7a8  pop rdi
00007ed4111dc7a9  pop rdx
00007ed4111dc7aa  pop rcx
00007ed4111dc7ab  pop rax
00007ed4111dc7ac  add rsp, 0x08
00007ed4111dc7b0  jmp 0x00007ED4111DA493
00007ed4111dc7b5  call 0x00007ED410FFF430
00007ed4111dc7ba  jmp 0x00007ED4111DA49D
00007ed4111dc7bf  call 0x00007ED41100C260
00007ed4111dc7c4  jmp 0x00007ED4111DA4A7
00007ed4111dc7c9  sub rsp, 0x08
00007ed4111dc7cd  push rax
00007ed4111dc7ce  push rcx
00007ed4111dc7cf  push rdx
00007ed4111dc7d0  push rdi
00007ed4111dc7d1  push rsi
00007ed4111dc7d2  push r8
00007ed4111dc7d4  push r9
00007ed4111dc7d6  push r10
00007ed4111dc7d8  push r11
00007ed4111dc7da  sub rsp, 0xF0
00007ed4111dc7e1  vmovaps [rsp], xmm0
00007ed4111dc7e6  vmovaps [rsp+0x10], xmm1
00007ed4111dc7ec  vmovaps [rsp+0x20], xmm2
00007ed4111dc7f2  vmovaps [rsp+0x30], xmm3
00007ed4111dc7f8  vmovaps [rsp+0x40], xmm4
00007ed4111dc7fe  vmovaps [rsp+0x50], xmm5
00007ed4111dc804  vmovaps [rsp+0x60], xmm6
00007ed4111dc80a  vmovaps [rsp+0x70], xmm7
00007ed4111dc810  vmovaps [rsp+0x80], xmm9
00007ed4111dc819  vmovaps [rsp+0x90], xmm10
00007ed4111dc822  vmovaps [rsp+0xA0], xmm11
00007ed4111dc82b  vmovaps [rsp+0xB0], xmm12
00007ed4111dc834  vmovaps [rsp+0xC0], xmm13
00007ed4111dc83d  vmovaps [rsp+0xD0], xmm14
00007ed4111dc846  vmovaps [rsp+0xE0], xmm15
00007ed4111dc84f  sub rsp, 0x40
00007ed4111dc853  lea rdi, [rsp]
00007ed4111dc857  lea rsi, [rsp+0x10]
00007ed4111dc85c  lea rdx, [rsp+0x20]
00007ed4111dc861  lea rcx, [rsp+0x30]
00007ed4111dc866  mov r8d, 0x00
00007ed4111dc86c  lea r9, [r15+0x3A8]
00007ed4111dc873  movaps [rdi], xmm8
00007ed4111dc877  movaps [rsi], xmm7
00007ed4111dc87a  movaps [rdx], xmm4
00007ed4111dc87d  movaps [rcx], xmm12
00007ed4111dc881  mov rax, 0x5CA8E4A55A50
00007ed4111dc88b  call rax
00007ed4111dc88d  movaps xmm8, [rsp]
00007ed4111dc892  add rsp, 0x40
00007ed4111dc896  vmovaps xmm0, [rsp]
00007ed4111dc89b  vmovaps xmm1, [rsp+0x10]
00007ed4111dc8a1  vmovaps xmm2, [rsp+0x20]
00007ed4111dc8a7  vmovaps xmm3, [rsp+0x30]
00007ed4111dc8ad  vmovaps xmm4, [rsp+0x40]
00007ed4111dc8b3  vmovaps xmm5, [rsp+0x50]
00007ed4111dc8b9  vmovaps xmm6, [rsp+0x60]
00007ed4111dc8bf  vmovaps xmm7, [rsp+0x70]
00007ed4111dc8c5  vmovaps xmm9, [rsp+0x80]
00007ed4111dc8ce  vmovaps xmm10, [rsp+0x90]
00007ed4111dc8d7  vmovaps xmm11, [rsp+0xA0]
00007ed4111dc8e0  vmovaps xmm12, [rsp+0xB0]
00007ed4111dc8e9  vmovaps xmm13, [rsp+0xC0]
00007ed4111dc8f2  vmovaps xmm14, [rsp+0xD0]
00007ed4111dc8fb  vmovaps xmm15, [rsp+0xE0]
00007ed4111dc904  add rsp, 0xF0
00007ed4111dc90b  pop r11
00007ed4111dc90d  pop r10
00007ed4111dc90f  pop r9
00007ed4111dc911  pop r8
00007ed4111dc913  pop rsi
00007ed4111dc914  pop rdi
00007ed4111dc915  pop rdx
00007ed4111dc916  pop rcx
00007ed4111dc917  pop rax
00007ed4111dc918  add rsp, 0x08
00007ed4111dc91c  jmp 0x00007ED4111DA4D0
00007ed4111dc921  sub rsp, 0x08
00007ed4111dc925  push rax
00007ed4111dc926  push rcx
00007ed4111dc927  push rdx
00007ed4111dc928  push rdi
00007ed4111dc929  push rsi
00007ed4111dc92a  push r8
00007ed4111dc92c  push r9
00007ed4111dc92e  push r10
00007ed4111dc930  push r11
00007ed4111dc932  sub rsp, 0xF0
00007ed4111dc939  vmovaps [rsp], xmm0
00007ed4111dc93e  vmovaps [rsp+0x10], xmm1
00007ed4111dc944  vmovaps [rsp+0x20], xmm2
00007ed4111dc94a  vmovaps [rsp+0x30], xmm3
00007ed4111dc950  vmovaps [rsp+0x40], xmm4
00007ed4111dc956  vmovaps [rsp+0x50], xmm5
00007ed4111dc95c  vmovaps [rsp+0x60], xmm6
00007ed4111dc962  vmovaps [rsp+0x70], xmm8
00007ed4111dc968  vmovaps [rsp+0x80], xmm9
00007ed4111dc971  vmovaps [rsp+0x90], xmm10
00007ed4111dc97a  vmovaps [rsp+0xA0], xmm11
00007ed4111dc983  vmovaps [rsp+0xB0], xmm12
00007ed4111dc98c  vmovaps [rsp+0xC0], xmm13
00007ed4111dc995  vmovaps [rsp+0xD0], xmm14
00007ed4111dc99e  vmovaps [rsp+0xE0], xmm15
00007ed4111dc9a7  sub rsp, 0x40
00007ed4111dc9ab  lea rdi, [rsp]
00007ed4111dc9af  lea rsi, [rsp+0x10]
00007ed4111dc9b4  lea rdx, [rsp+0x20]
00007ed4111dc9b9  lea rcx, [rsp+0x30]
00007ed4111dc9be  mov r8d, 0x00
00007ed4111dc9c4  lea r9, [r15+0x3A8]
00007ed4111dc9cb  movaps [rdi], xmm7
00007ed4111dc9ce  movaps [rsi], xmm9
00007ed4111dc9d2  movaps [rdx], xmm14
00007ed4111dc9d6  movaps [rcx], xmm12
00007ed4111dc9da  mov rax, 0x5CA8E4A55A50
00007ed4111dc9e4  call rax
00007ed4111dc9e6  movaps xmm7, [rsp]
00007ed4111dc9ea  add rsp, 0x40
00007ed4111dc9ee  vmovaps xmm0, [rsp]
00007ed4111dc9f3  vmovaps xmm1, [rsp+0x10]
00007ed4111dc9f9  vmovaps xmm2, [rsp+0x20]
00007ed4111dc9ff  vmovaps xmm3, [rsp+0x30]
00007ed4111dca05  vmovaps xmm4, [rsp+0x40]
00007ed4111dca0b  vmovaps xmm5, [rsp+0x50]
00007ed4111dca11  vmovaps xmm6, [rsp+0x60]
00007ed4111dca17  vmovaps xmm8, [rsp+0x70]
00007ed4111dca1d  vmovaps xmm9, [rsp+0x80]
00007ed4111dca26  vmovaps xmm10, [rsp+0x90]
00007ed4111dca2f  vmovaps xmm11, [rsp+0xA0]
00007ed4111dca38  vmovaps xmm12, [rsp+0xB0]
00007ed4111dca41  vmovaps xmm13, [rsp+0xC0]
00007ed4111dca4a  vmovaps xmm14, [rsp+0xD0]
00007ed4111dca53  vmovaps xmm15, [rsp+0xE0]
00007ed4111dca5c  add rsp, 0xF0
00007ed4111dca63  pop r11
00007ed4111dca65  pop r10
00007ed4111dca67  pop r9
00007ed4111dca69  pop r8
00007ed4111dca6b  pop rsi
00007ed4111dca6c  pop rdi
00007ed4111dca6d  pop rdx
00007ed4111dca6e  pop rcx
00007ed4111dca6f  pop rax
00007ed4111dca70  add rsp, 0x08
00007ed4111dca74  jmp 0x00007ED4111DA4F8
00007ed4111dca79  sub rsp, 0x08
00007ed4111dca7d  push rax
00007ed4111dca7e  push rcx
00007ed4111dca7f  push rdx
00007ed4111dca80  push rdi
00007ed4111dca81  push rsi
00007ed4111dca82  push r8
00007ed4111dca84  push r9
00007ed4111dca86  push r10
00007ed4111dca88  push r11
00007ed4111dca8a  sub rsp, 0xF0
00007ed4111dca91  vmovaps [rsp], xmm0
00007ed4111dca96  vmovaps [rsp+0x10], xmm1
00007ed4111dca9c  vmovaps [rsp+0x20], xmm2
00007ed4111dcaa2  vmovaps [rsp+0x30], xmm3
00007ed4111dcaa8  vmovaps [rsp+0x40], xmm4
00007ed4111dcaae  vmovaps [rsp+0x50], xmm5
00007ed4111dcab4  vmovaps [rsp+0x60], xmm6
00007ed4111dcaba  vmovaps [rsp+0x70], xmm7
00007ed4111dcac0  vmovaps [rsp+0x80], xmm8
00007ed4111dcac9  vmovaps [rsp+0x90], xmm9
00007ed4111dcad2  vmovaps [rsp+0xA0], xmm10
00007ed4111dcadb  vmovaps [rsp+0xB0], xmm11
00007ed4111dcae4  vmovaps [rsp+0xC0], xmm13
00007ed4111dcaed  vmovaps [rsp+0xD0], xmm14
00007ed4111dcaf6  vmovaps [rsp+0xE0], xmm15
00007ed4111dcaff  sub rsp, 0x40
00007ed4111dcb03  lea rdi, [rsp]
00007ed4111dcb07  lea rsi, [rsp+0x10]
00007ed4111dcb0c  lea rdx, [rsp+0x20]
00007ed4111dcb11  lea rcx, [rsp+0x30]
00007ed4111dcb16  mov r8d, 0x00
00007ed4111dcb1c  lea r9, [r15+0x3A8]
00007ed4111dcb23  movaps [rdi], xmm12
00007ed4111dcb27  movaps [rsi], xmm11
00007ed4111dcb2b  movaps [rdx], xmm15
00007ed4111dcb2f  movaps [rcx], xmm14
00007ed4111dcb33  mov rax, 0x5CA8E4A55A50
00007ed4111dcb3d  call rax
00007ed4111dcb3f  movaps xmm12, [rsp]
00007ed4111dcb44  add rsp, 0x40
00007ed4111dcb48  vmovaps xmm0, [rsp]
00007ed4111dcb4d  vmovaps xmm1, [rsp+0x10]
00007ed4111dcb53  vmovaps xmm2, [rsp+0x20]
00007ed4111dcb59  vmovaps xmm3, [rsp+0x30]
00007ed4111dcb5f  vmovaps xmm4, [rsp+0x40]
00007ed4111dcb65  vmovaps xmm5, [rsp+0x50]
00007ed4111dcb6b  vmovaps xmm6, [rsp+0x60]
00007ed4111dcb71  vmovaps xmm7, [rsp+0x70]
00007ed4111dcb77  vmovaps xmm8, [rsp+0x80]
00007ed4111dcb80  vmovaps xmm9, [rsp+0x90]
00007ed4111dcb89  vmovaps xmm10, [rsp+0xA0]
00007ed4111dcb92  vmovaps xmm11, [rsp+0xB0]
00007ed4111dcb9b  vmovaps xmm13, [rsp+0xC0]
00007ed4111dcba4  vmovaps xmm14, [rsp+0xD0]
00007ed4111dcbad  vmovaps xmm15, [rsp+0xE0]
00007ed4111dcbb6  add rsp, 0xF0
00007ed4111dcbbd  pop r11
00007ed4111dcbbf  pop r10
00007ed4111dcbc1  pop r9
00007ed4111dcbc3  pop r8
00007ed4111dcbc5  pop rsi
00007ed4111dcbc6  pop rdi
00007ed4111dcbc7  pop rdx
00007ed4111dcbc8  pop rcx
00007ed4111dcbc9  pop rax
00007ed4111dcbca  add rsp, 0x08
00007ed4111dcbce  jmp 0x00007ED4111DA521
00007ed4111dcbd3  sub rsp, 0x08
00007ed4111dcbd7  push rax
00007ed4111dcbd8  push rcx
00007ed4111dcbd9  push rdx
00007ed4111dcbda  push rdi
00007ed4111dcbdb  push rsi
00007ed4111dcbdc  push r8
00007ed4111dcbde  push r9
00007ed4111dcbe0  push r10
00007ed4111dcbe2  push r11
00007ed4111dcbe4  sub rsp, 0xF0
00007ed4111dcbeb  vmovaps [rsp], xmm0
00007ed4111dcbf0  vmovaps [rsp+0x10], xmm1
00007ed4111dcbf6  vmovaps [rsp+0x20], xmm2
00007ed4111dcbfc  vmovaps [rsp+0x30], xmm3
00007ed4111dcc02  vmovaps [rsp+0x40], xmm4
00007ed4111dcc08  vmovaps [rsp+0x50], xmm5
00007ed4111dcc0e  vmovaps [rsp+0x60], xmm6
00007ed4111dcc14  vmovaps [rsp+0x70], xmm7
00007ed4111dcc1a  vmovaps [rsp+0x80], xmm8
00007ed4111dcc23  vmovaps [rsp+0x90], xmm9
00007ed4111dcc2c  vmovaps [rsp+0xA0], xmm10
00007ed4111dcc35  vmovaps [rsp+0xB0], xmm12
00007ed4111dcc3e  vmovaps [rsp+0xC0], xmm13
00007ed4111dcc47  vmovaps [rsp+0xD0], xmm14
00007ed4111dcc50  vmovaps [rsp+0xE0], xmm15
00007ed4111dcc59  sub rsp, 0x40
00007ed4111dcc5d  lea rdi, [rsp]
00007ed4111dcc61  lea rsi, [rsp+0x10]
00007ed4111dcc66  lea rdx, [rsp+0x20]
00007ed4111dcc6b  lea rcx, [rsp+0x30]
00007ed4111dcc70  mov r8d, 0x00
00007ed4111dcc76  lea r9, [r15+0x3A8]
00007ed4111dcc7d  movaps [rdi], xmm11
00007ed4111dcc81  movaps [rsi], xmm10
00007ed4111dcc85  movaps [rdx], xmm13
00007ed4111dcc89  movaps [rcx], xmm15
00007ed4111dcc8d  mov rax, 0x5CA8E4A55A50
00007ed4111dcc97  call rax
00007ed4111dcc99  movaps xmm11, [rsp]
00007ed4111dcc9e  add rsp, 0x40
00007ed4111dcca2  vmovaps xmm0, [rsp]
00007ed4111dcca7  vmovaps xmm1, [rsp+0x10]
00007ed4111dccad  vmovaps xmm2, [rsp+0x20]
00007ed4111dccb3  vmovaps xmm3, [rsp+0x30]
00007ed4111dccb9  vmovaps xmm4, [rsp+0x40]
00007ed4111dccbf  vmovaps xmm5, [rsp+0x50]
00007ed4111dccc5  vmovaps xmm6, [rsp+0x60]
00007ed4111dcccb  vmovaps xmm7, [rsp+0x70]
00007ed4111dccd1  vmovaps xmm8, [rsp+0x80]
00007ed4111dccda  vmovaps xmm9, [rsp+0x90]
00007ed4111dcce3  vmovaps xmm10, [rsp+0xA0]
00007ed4111dccec  vmovaps xmm12, [rsp+0xB0]
00007ed4111dccf5  vmovaps xmm13, [rsp+0xC0]
00007ed4111dccfe  vmovaps xmm14, [rsp+0xD0]
00007ed4111dcd07  vmovaps xmm15, [rsp+0xE0]
00007ed4111dcd10  add rsp, 0xF0
00007ed4111dcd17  pop r11
00007ed4111dcd19  pop r10
00007ed4111dcd1b  pop r9
00007ed4111dcd1d  pop r8
00007ed4111dcd1f  pop rsi
00007ed4111dcd20  pop rdi
00007ed4111dcd21  pop rdx
00007ed4111dcd22  pop rcx
00007ed4111dcd23  pop rax
00007ed4111dcd24  add rsp, 0x08
00007ed4111dcd28  jmp 0x00007ED4111DA54A
00007ed4111dcd2d  call 0x00007ED41100E760
00007ed4111dcd32  jmp 0x00007ED4111DA557
00007ed4111dcd37  call 0x00007ED41100D4E0
00007ed4111dcd3c  jmp 0x00007ED4111DA564
00007ed4111dcd41  sub rsp, 0x08
00007ed4111dcd45  push rax
00007ed4111dcd46  push rcx
00007ed4111dcd47  push rdx
00007ed4111dcd48  push rdi
00007ed4111dcd49  push rsi
00007ed4111dcd4a  push r8
00007ed4111dcd4c  push r9
00007ed4111dcd4e  push r10
00007ed4111dcd50  push r11
00007ed4111dcd52  sub rsp, 0xF0
00007ed4111dcd59  vmovaps [rsp], xmm0
00007ed4111dcd5e  vmovaps [rsp+0x10], xmm1
00007ed4111dcd64  vmovaps [rsp+0x20], xmm2
00007ed4111dcd6a  vmovaps [rsp+0x30], xmm3
00007ed4111dcd70  vmovaps [rsp+0x40], xmm4
00007ed4111dcd76  vmovaps [rsp+0x50], xmm5
00007ed4111dcd7c  vmovaps [rsp+0x60], xmm6
00007ed4111dcd82  vmovaps [rsp+0x70], xmm7
00007ed4111dcd88  vmovaps [rsp+0x80], xmm8
00007ed4111dcd91  vmovaps [rsp+0x90], xmm9
00007ed4111dcd9a  vmovaps [rsp+0xA0], xmm11
00007ed4111dcda3  vmovaps [rsp+0xB0], xmm12
00007ed4111dcdac  vmovaps [rsp+0xC0], xmm13
00007ed4111dcdb5  vmovaps [rsp+0xD0], xmm14
00007ed4111dcdbe  vmovaps [rsp+0xE0], xmm15
00007ed4111dcdc7  sub rsp, 0x40
00007ed4111dcdcb  lea rdi, [rsp]
00007ed4111dcdcf  lea rsi, [rsp+0x10]
00007ed4111dcdd4  lea rdx, [rsp+0x20]
00007ed4111dcdd9  lea rcx, [rsp+0x30]
00007ed4111dcdde  mov r8d, 0x00
00007ed4111dcde4  lea r9, [r15+0x3A8]
00007ed4111dcdeb  movaps [rdi], xmm10
00007ed4111dcdef  movaps [rsi], xmm8
00007ed4111dcdf3  movaps [rdx], xmm1
00007ed4111dcdf6  movaps [rcx], xmm13
00007ed4111dcdfa  mov rax, 0x5CA8E4A55A50
00007ed4111dce04  call rax
00007ed4111dce06  movaps xmm10, [rsp]
00007ed4111dce0b  add rsp, 0x40
00007ed4111dce0f  vmovaps xmm0, [rsp]
00007ed4111dce14  vmovaps xmm1, [rsp+0x10]
00007ed4111dce1a  vmovaps xmm2, [rsp+0x20]
00007ed4111dce20  vmovaps xmm3, [rsp+0x30]
00007ed4111dce26  vmovaps xmm4, [rsp+0x40]
00007ed4111dce2c  vmovaps xmm5, [rsp+0x50]
00007ed4111dce32  vmovaps xmm6, [rsp+0x60]
00007ed4111dce38  vmovaps xmm7, [rsp+0x70]
00007ed4111dce3e  vmovaps xmm8, [rsp+0x80]
00007ed4111dce47  vmovaps xmm9, [rsp+0x90]
00007ed4111dce50  vmovaps xmm11, [rsp+0xA0]
00007ed4111dce59  vmovaps xmm12, [rsp+0xB0]
00007ed4111dce62  vmovaps xmm13, [rsp+0xC0]
00007ed4111dce6b  vmovaps xmm14, [rsp+0xD0]
00007ed4111dce74  vmovaps xmm15, [rsp+0xE0]
00007ed4111dce7d  add rsp, 0xF0
00007ed4111dce84  pop r11
00007ed4111dce86  pop r10
00007ed4111dce88  pop r9
00007ed4111dce8a  pop r8
00007ed4111dce8c  pop rsi
00007ed4111dce8d  pop rdi
00007ed4111dce8e  pop rdx
00007ed4111dce8f  pop rcx
00007ed4111dce90  pop rax
00007ed4111dce91  add rsp, 0x08
00007ed4111dce95  jmp 0x00007ED4111DA59A
00007ed4111dce9a  call 0x00007ED410FFF430
00007ed4111dce9f  jmp 0x00007ED4111DA5AC
00007ed4111dcea4  sub rsp, 0x08
00007ed4111dcea8  push rax
00007ed4111dcea9  push rcx
00007ed4111dceaa  push rdx
00007ed4111dceab  push rdi
00007ed4111dceac  push rsi
00007ed4111dcead  push r8
00007ed4111dceaf  push r9
00007ed4111dceb1  push r10
00007ed4111dceb3  push r11
00007ed4111dceb5  sub rsp, 0xF0
00007ed4111dcebc  vmovaps [rsp], xmm0
00007ed4111dcec1  vmovaps [rsp+0x10], xmm1
00007ed4111dcec7  vmovaps [rsp+0x20], xmm2
00007ed4111dcecd  vmovaps [rsp+0x30], xmm3
00007ed4111dced3  vmovaps [rsp+0x40], xmm4
00007ed4111dced9  vmovaps [rsp+0x50], xmm5
00007ed4111dcedf  vmovaps [rsp+0x60], xmm6
00007ed4111dcee5  vmovaps [rsp+0x70], xmm7
00007ed4111dceeb  vmovaps [rsp+0x80], xmm8
00007ed4111dcef4  vmovaps [rsp+0x90], xmm10
00007ed4111dcefd  vmovaps [rsp+0xA0], xmm11
00007ed4111dcf06  vmovaps [rsp+0xB0], xmm12
00007ed4111dcf0f  vmovaps [rsp+0xC0], xmm13
00007ed4111dcf18  vmovaps [rsp+0xD0], xmm14
00007ed4111dcf21  vmovaps [rsp+0xE0], xmm15
00007ed4111dcf2a  sub rsp, 0x40
00007ed4111dcf2e  lea rdi, [rsp]
00007ed4111dcf32  lea rsi, [rsp+0x10]
00007ed4111dcf37  lea rdx, [rsp+0x20]
00007ed4111dcf3c  lea rcx, [rsp+0x30]
00007ed4111dcf41  mov r8d, 0x00
00007ed4111dcf47  lea r9, [r15+0x3A8]
00007ed4111dcf4e  movaps [rdi], xmm9
00007ed4111dcf52  movaps [rsi], xmm7
00007ed4111dcf55  movaps [rdx], xmm14
00007ed4111dcf59  movaps [rcx], xmm13
00007ed4111dcf5d  mov rax, 0x5CA8E4A55A50
00007ed4111dcf67  call rax
00007ed4111dcf69  movaps xmm9, [rsp]
00007ed4111dcf6e  add rsp, 0x40
00007ed4111dcf72  vmovaps xmm0, [rsp]
00007ed4111dcf77  vmovaps xmm1, [rsp+0x10]
00007ed4111dcf7d  vmovaps xmm2, [rsp+0x20]
00007ed4111dcf83  vmovaps xmm3, [rsp+0x30]
00007ed4111dcf89  vmovaps xmm4, [rsp+0x40]
00007ed4111dcf8f  vmovaps xmm5, [rsp+0x50]
00007ed4111dcf95  vmovaps xmm6, [rsp+0x60]
00007ed4111dcf9b  vmovaps xmm7, [rsp+0x70]
00007ed4111dcfa1  vmovaps xmm8, [rsp+0x80]
00007ed4111dcfaa  vmovaps xmm10, [rsp+0x90]
00007ed4111dcfb3  vmovaps xmm11, [rsp+0xA0]
00007ed4111dcfbc  vmovaps xmm12, [rsp+0xB0]
00007ed4111dcfc5  vmovaps xmm13, [rsp+0xC0]
00007ed4111dcfce  vmovaps xmm14, [rsp+0xD0]
00007ed4111dcfd7  vmovaps xmm15, [rsp+0xE0]
00007ed4111dcfe0  add rsp, 0xF0
00007ed4111dcfe7  pop r11
00007ed4111dcfe9  pop r10
00007ed4111dcfeb  pop r9
00007ed4111dcfed  pop r8
00007ed4111dcfef  pop rsi
00007ed4111dcff0  pop rdi
00007ed4111dcff1  pop rdx
00007ed4111dcff2  pop rcx
00007ed4111dcff3  pop rax
00007ed4111dcff4  add rsp, 0x08
00007ed4111dcff8  jmp 0x00007ED4111DA5DA
00007ed4111dcffd  sub rsp, 0x08
00007ed4111dd001  push rax
00007ed4111dd002  push rcx
00007ed4111dd003  push rdx
00007ed4111dd004  push rdi
00007ed4111dd005  push rsi
00007ed4111dd006  push r8
00007ed4111dd008  push r9
00007ed4111dd00a  push r10
00007ed4111dd00c  push r11
00007ed4111dd00e  sub rsp, 0xF0
00007ed4111dd015  vmovaps [rsp], xmm0
00007ed4111dd01a  vmovaps [rsp+0x10], xmm1
00007ed4111dd020  vmovaps [rsp+0x20], xmm2
00007ed4111dd026  vmovaps [rsp+0x30], xmm3
00007ed4111dd02c  vmovaps [rsp+0x40], xmm4
00007ed4111dd032  vmovaps [rsp+0x50], xmm5
00007ed4111dd038  vmovaps [rsp+0x60], xmm6
00007ed4111dd03e  vmovaps [rsp+0x70], xmm7
00007ed4111dd044  vmovaps [rsp+0x80], xmm8
00007ed4111dd04d  vmovaps [rsp+0x90], xmm9
00007ed4111dd056  vmovaps [rsp+0xA0], xmm10
00007ed4111dd05f  vmovaps [rsp+0xB0], xmm11
00007ed4111dd068  vmovaps [rsp+0xC0], xmm12
00007ed4111dd071  vmovaps [rsp+0xD0], xmm14
00007ed4111dd07a  vmovaps [rsp+0xE0], xmm15
00007ed4111dd083  sub rsp, 0x40
00007ed4111dd087  lea rdi, [rsp]
00007ed4111dd08b  lea rsi, [rsp+0x10]
00007ed4111dd090  lea rdx, [rsp+0x20]
00007ed4111dd095  lea rcx, [rsp+0x30]
00007ed4111dd09a  mov r8d, 0x00
00007ed4111dd0a0  lea r9, [r15+0x3A8]
00007ed4111dd0a7  movaps [rdi], xmm13
00007ed4111dd0ab  movaps [rsi], xmm12
00007ed4111dd0af  movaps [rdx], xmm15
00007ed4111dd0b3  movaps [rcx], xmm14
00007ed4111dd0b7  mov rax, 0x5CA8E4A55A50
00007ed4111dd0c1  call rax
00007ed4111dd0c3  movaps xmm13, [rsp]
00007ed4111dd0c8  add rsp, 0x40
00007ed4111dd0cc  vmovaps xmm0, [rsp]
00007ed4111dd0d1  vmovaps xmm1, [rsp+0x10]
00007ed4111dd0d7  vmovaps xmm2, [rsp+0x20]
00007ed4111dd0dd  vmovaps xmm3, [rsp+0x30]
00007ed4111dd0e3  vmovaps xmm4, [rsp+0x40]
00007ed4111dd0e9  vmovaps xmm5, [rsp+0x50]
00007ed4111dd0ef  vmovaps xmm6, [rsp+0x60]
00007ed4111dd0f5  vmovaps xmm7, [rsp+0x70]
00007ed4111dd0fb  vmovaps xmm8, [rsp+0x80]
00007ed4111dd104  vmovaps xmm9, [rsp+0x90]
00007ed4111dd10d  vmovaps xmm10, [rsp+0xA0]
00007ed4111dd116  vmovaps xmm11, [rsp+0xB0]
00007ed4111dd11f  vmovaps xmm12, [rsp+0xC0]
00007ed4111dd128  vmovaps xmm14, [rsp+0xD0]
00007ed4111dd131  vmovaps xmm15, [rsp+0xE0]
00007ed4111dd13a  add rsp, 0xF0
00007ed4111dd141  pop r11
00007ed4111dd143  pop r10
00007ed4111dd145  pop r9
00007ed4111dd147  pop r8
00007ed4111dd149  pop rsi
00007ed4111dd14a  pop rdi
00007ed4111dd14b  pop rdx
00007ed4111dd14c  pop rcx
00007ed4111dd14d  pop rax
00007ed4111dd14e  add rsp, 0x08
00007ed4111dd152  jmp 0x00007ED4111DA608
00007ed4111dd157  sub rsp, 0x08
00007ed4111dd15b  push rax
00007ed4111dd15c  push rcx
00007ed4111dd15d  push rdx
00007ed4111dd15e  push rdi
00007ed4111dd15f  push rsi
00007ed4111dd160  push r8
00007ed4111dd162  push r9
00007ed4111dd164  push r10
00007ed4111dd166  push r11
00007ed4111dd168  sub rsp, 0xF0
00007ed4111dd16f  vmovaps [rsp], xmm0
00007ed4111dd174  vmovaps [rsp+0x10], xmm1
00007ed4111dd17a  vmovaps [rsp+0x20], xmm2
00007ed4111dd180  vmovaps [rsp+0x30], xmm3
00007ed4111dd186  vmovaps [rsp+0x40], xmm4
00007ed4111dd18c  vmovaps [rsp+0x50], xmm5
00007ed4111dd192  vmovaps [rsp+0x60], xmm6
00007ed4111dd198  vmovaps [rsp+0x70], xmm7
00007ed4111dd19e  vmovaps [rsp+0x80], xmm8
00007ed4111dd1a7  vmovaps [rsp+0x90], xmm9
00007ed4111dd1b0  vmovaps [rsp+0xA0], xmm10
00007ed4111dd1b9  vmovaps [rsp+0xB0], xmm11
00007ed4111dd1c2  vmovaps [rsp+0xC0], xmm12
00007ed4111dd1cb  vmovaps [rsp+0xD0], xmm13
00007ed4111dd1d4  vmovaps [rsp+0xE0], xmm15
00007ed4111dd1dd  sub rsp, 0x40
00007ed4111dd1e1  lea rdi, [rsp]
00007ed4111dd1e5  lea rsi, [rsp+0x10]
00007ed4111dd1ea  lea rdx, [rsp+0x20]
00007ed4111dd1ef  lea rcx, [rsp+0x30]
00007ed4111dd1f4  mov r8d, 0x00
00007ed4111dd1fa  lea r9, [r15+0x3A8]
00007ed4111dd201  movaps [rdi], xmm14
00007ed4111dd205  movaps [rsi], xmm11
00007ed4111dd209  movaps [rdx], xmm1
00007ed4111dd20c  movaps [rcx], xmm15
00007ed4111dd210  mov rax, 0x5CA8E4A55A50
00007ed4111dd21a  call rax
00007ed4111dd21c  movaps xmm14, [rsp]
00007ed4111dd221  add rsp, 0x40
00007ed4111dd225  vmovaps xmm0, [rsp]
00007ed4111dd22a  vmovaps xmm1, [rsp+0x10]
00007ed4111dd230  vmovaps xmm2, [rsp+0x20]
00007ed4111dd236  vmovaps xmm3, [rsp+0x30]
00007ed4111dd23c  vmovaps xmm4, [rsp+0x40]
00007ed4111dd242  vmovaps xmm5, [rsp+0x50]
00007ed4111dd248  vmovaps xmm6, [rsp+0x60]
00007ed4111dd24e  vmovaps xmm7, [rsp+0x70]
00007ed4111dd254  vmovaps xmm8, [rsp+0x80]
00007ed4111dd25d  vmovaps xmm9, [rsp+0x90]
00007ed4111dd266  vmovaps xmm10, [rsp+0xA0]
00007ed4111dd26f  vmovaps xmm11, [rsp+0xB0]
00007ed4111dd278  vmovaps xmm12, [rsp+0xC0]
00007ed4111dd281  vmovaps xmm13, [rsp+0xD0]
00007ed4111dd28a  vmovaps xmm15, [rsp+0xE0]
00007ed4111dd293  add rsp, 0xF0
00007ed4111dd29a  pop r11
00007ed4111dd29c  pop r10
00007ed4111dd29e  pop r9
00007ed4111dd2a0  pop r8
00007ed4111dd2a2  pop rsi
00007ed4111dd2a3  pop rdi
00007ed4111dd2a4  pop rdx
00007ed4111dd2a5  pop rcx
00007ed4111dd2a6  pop rax
00007ed4111dd2a7  add rsp, 0x08
00007ed4111dd2ab  jmp 0x00007ED4111DA636
00007ed4111dd2b0  call 0x00007ED4110079B0
00007ed4111dd2b5  jmp 0x00007ED4111DA64C
00007ed4111dd2ba  call 0x00007ED4110E3440
00007ed4111dd2bf  jmp 0x00007ED4111DA656
00007ed4111dd2c4  call 0x00007ED4110DFCE0
00007ed4111dd2c9  jmp 0x00007ED4111DA660
00007ed4111dd2ce  call 0x00007ED4110E46C0
00007ed4111dd2d3  jmp 0x00007ED4111DA66A
00007ed4111dd2d8  int3
00007ed4111dd2d9  nop [rax], eax
00007ed4111dd2e0  mov qword ptr [r15+0x40], 0x430000
00007ed4111dd2e8  mov eax, 0x430C50
00007ed4111dd2ed  mov r14, [r13+rax*1]
00007ed4111dd2f2  movq xmm1, r14
00007ed4111dd2f7  mov rax, [r15+0x50]
00007ed4111dd2fb  movups xmm15, [r13+rax*1]
00007ed4111dd301  movaps [r15+0x120], xmm15
00007ed4111dd309  mov qword ptr [r15+0x48], 0x10
00007ed4111dd311  xor eax, eax
00007ed4111dd313  mov r14d, 0x10
00007ed4111dd319  mov r12d, 0x200
00007ed4111dd31f  cmp r14, r12
00007ed4111dd322  cmc
00007ed4111dd323  lahf
00007ed4111dd324  seto al
00007ed4111dd327  mov [r15+0x108], eax
00007ed4111dd32e  pextrq rax, xmm15, 0x01
00007ed4111dd335  movq xmm14, rax
00007ed4111dd33a  movaps [r15+0x130], xmm14
00007ed4111dd342  movq rax, xmm1
00007ed4111dd347  movq r14, xmm15
00007ed4111dd34c  vmovq xmm1, rax
00007ed4111dd351  vmovq xmm15, r14
00007ed4111dd356  movaps xmm13, xmm1
00007ed4111dd35a  addsd xmm13, xmm15
00007ed4111dd35f  ucomisd xmm13, xmm13
00007ed4111dd364  jp 0x00007ED4111DD423
00007ed4111dd36a  movq xmm13, xmm13
00007ed4111dd36f  movq rax, xmm13
00007ed4111dd374  movq r14, xmm14
00007ed4111dd379  vmovq xmm1, rax
00007ed4111dd37e  vmovq xmm15, r14
00007ed4111dd383  movaps xmm14, xmm1
00007ed4111dd387  addsd xmm14, xmm15
00007ed4111dd38c  ucomisd xmm14, xmm14
00007ed4111dd391  jp 0x00007ED4111DD46B
00007ed4111dd397  movq xmm14, xmm14
00007ed4111dd39c  movaps [r15+0x110], xmm14
00007ed4111dd3a4  mov eax, [r15+0x108]
00007ed4111dd3ab  sahf
00007ed4111dd3ac  jnz 0x00007ED4111DD3DE
00007ed4111dd3ae  cmp dword ptr [r15+0x318], 0x00
00007ed4111dd3b6  jz 0x00007ED4111DD680
00007ed4111dd3bc  nop [rax+rax*1], ax
00007ed4111dd3c5  nop [rax+rax*1], eax
00007ed4111dd3cd  mov eax, 0x410698
00007ed4111dd3d2  mov [r15+0x100], rax
00007ed4111dd3d9  jmp 0x00007ED410FFE110
00007ed4111dd3de  cmp dword ptr [r15+0x318], 0x00
00007ed4111dd3e6  jz 0x00007ED4111DD4C0
00007ed4111dd3ec  nop [rax+rax*1], ax
00007ed4111dd3f5  nop [rax+rax*1], eax
00007ed4111dd3fd  mov eax, 0x41067C
00007ed4111dd402  mov [r15+0x100], rax
00007ed4111dd409  jmp 0x00007ED410FFE110
00007ed4111dd40e  int3
00007ed4111dd40f  call 0x00007ED41100DC20
00007ed4111dd414  jmp 0x00007ED4111DD2F2
00007ed4111dd419  call 0x00007ED41100E760
00007ed4111dd41e  jmp 0x00007ED4111DD301
00007ed4111dd423  ucomisd xmm1, xmm15
00007ed4111dd428  jp 0x00007ED4111DD437
00007ed4111dd42a  movaps xmm13, [0x00007ED410DFE060]
00007ed4111dd432  jmp 0x00007ED4111DD36A
00007ed4111dd437  vxorps xmm0, xmm1, xmm15
00007ed4111dd43c  pextrw eax, xmm0, 0x03
00007ed4111dd441  and eax, 0x7FF8
00007ed4111dd446  cmp eax, 0x08
00007ed4111dd449  jnz 0x00007ED4111DD36A
00007ed4111dd44f  movq rax, xmm15
00007ed4111dd454  shl rax, 0x0D
00007ed4111dd458  jbe 0x00007ED4111DD36A
00007ed4111dd45e  vorps xmm13, xmm15, [0x00007ED410DFE070]
00007ed4111dd466  jmp 0x00007ED4111DD36A
00007ed4111dd46b  ucomisd xmm1, xmm15
00007ed4111dd470  jp 0x00007ED4111DD47F
00007ed4111dd472  movaps xmm14, [0x00007ED410DFE060]
00007ed4111dd47a  jmp 0x00007ED4111DD397
00007ed4111dd47f  vxorps xmm0, xmm1, xmm15
00007ed4111dd484  pextrw eax, xmm0, 0x03
00007ed4111dd489  and eax, 0x7FF8
00007ed4111dd48e  cmp eax, 0x08
00007ed4111dd491  jnz 0x00007ED4111DD397
00007ed4111dd497  movq rax, xmm15
00007ed4111dd49c  shl rax, 0x0D
00007ed4111dd4a0  jbe 0x00007ED4111DD397
00007ed4111dd4a6  vorps xmm14, xmm15, [0x00007ED410DFE070]
00007ed4111dd4ae  jmp 0x00007ED4111DD397
00007ed4111dd4b3  int3
00007ed4111dd4b4  nop [rax+rax*1], ax
00007ed4111dd4bd  nop [rax], eax
00007ed4111dd4c0  mov rax, [r15+0x48]
00007ed4111dd4c4  mov r14, [r15+0x50]
00007ed4111dd4c8  lea r12, [r14+rax*1]
00007ed4111dd4cc  movups xmm1, [r13+r12*1]
00007ed4111dd4d2  movaps [r15+0x120], xmm1
00007ed4111dd4da  lea r14, [rax+0x10]
00007ed4111dd4de  mov [r15+0x48], r14
00007ed4111dd4e2  xor eax, eax
00007ed4111dd4e4  mov r12d, 0x200
00007ed4111dd4ea  cmp r14, r12
00007ed4111dd4ed  cmc
00007ed4111dd4ee  lahf
00007ed4111dd4ef  seto al
00007ed4111dd4f2  mov [r15+0x108], eax
00007ed4111dd4f9  pextrq rax, xmm1, 0x01
00007ed4111dd500  movq xmm15, rax
00007ed4111dd505  movaps [r15+0x130], xmm15
00007ed4111dd50d  movaps xmm14, [r15+0x110]
00007ed4111dd515  movq rax, xmm14
00007ed4111dd51a  movq r14, xmm1
00007ed4111dd51f  vmovq xmm1, rax
00007ed4111dd524  vmovq xmm14, r14
00007ed4111dd529  movaps xmm13, xmm1
00007ed4111dd52d  addsd xmm13, xmm14
00007ed4111dd532  ucomisd xmm13, xmm13
00007ed4111dd537  jp 0x00007ED4111DD5EC
00007ed4111dd53d  movq xmm13, xmm13
00007ed4111dd542  movq rax, xmm13
00007ed4111dd547  movq r14, xmm15
00007ed4111dd54c  vmovq xmm1, rax
00007ed4111dd551  vmovq xmm15, r14
00007ed4111dd556  movaps xmm14, xmm1
00007ed4111dd55a  addsd xmm14, xmm15
00007ed4111dd55f  ucomisd xmm14, xmm14
00007ed4111dd564  jp 0x00007ED4111DD634
00007ed4111dd56a  movq xmm14, xmm14
00007ed4111dd56f  movaps [r15+0x110], xmm14
00007ed4111dd577  mov eax, [r15+0x108]
00007ed4111dd57e  sahf
00007ed4111dd57f  jnz 0x00007ED4111DD5B1
00007ed4111dd581  cmp dword ptr [r15+0x318], 0x00
00007ed4111dd589  jz 0x00007ED4111DD680
00007ed4111dd58f  nop [rax+rax*1], ax
00007ed4111dd598  nop [rax+rax*1], eax
00007ed4111dd5a0  mov eax, 0x410698
00007ed4111dd5a5  mov [r15+0x100], rax
00007ed4111dd5ac  jmp 0x00007ED410FFE110
00007ed4111dd5b1  cmp dword ptr [r15+0x318], 0x00
00007ed4111dd5b9  jz 0x00007ED4111DD4C0
00007ed4111dd5bf  nop [rax+rax*1], ax
00007ed4111dd5c8  nop [rax+rax*1], eax
00007ed4111dd5d0  mov eax, 0x41067C
00007ed4111dd5d5  mov [r15+0x100], rax
00007ed4111dd5dc  jmp 0x00007ED410FFE110
00007ed4111dd5e1  int3
00007ed4111dd5e2  call 0x00007ED4110B52F0
00007ed4111dd5e7  jmp 0x00007ED4111DD4D2
00007ed4111dd5ec  ucomisd xmm1, xmm14
00007ed4111dd5f1  jp 0x00007ED4111DD600
00007ed4111dd5f3  movaps xmm13, [0x00007ED410DFE060]
00007ed4111dd5fb  jmp 0x00007ED4111DD53D
00007ed4111dd600  vxorps xmm0, xmm1, xmm14
00007ed4111dd605  pextrw eax, xmm0, 0x03
00007ed4111dd60a  and eax, 0x7FF8
00007ed4111dd60f  cmp eax, 0x08
00007ed4111dd612  jnz 0x00007ED4111DD53D
00007ed4111dd618  movq rax, xmm14
00007ed4111dd61d  shl rax, 0x0D
00007ed4111dd621  jbe 0x00007ED4111DD53D
00007ed4111dd627  vorps xmm13, xmm14, [0x00007ED410DFE070]
00007ed4111dd62f  jmp 0x00007ED4111DD53D
00007ed4111dd634  ucomisd xmm1, xmm15
00007ed4111dd639  jp 0x00007ED4111DD648
00007ed4111dd63b  movaps xmm14, [0x00007ED410DFE060]
00007ed4111dd643  jmp 0x00007ED4111DD56A
00007ed4111dd648  vxorps xmm0, xmm1, xmm15
00007ed4111dd64d  pextrw eax, xmm0, 0x03
00007ed4111dd652  and eax, 0x7FF8
00007ed4111dd657  cmp eax, 0x08
00007ed4111dd65a  jnz 0x00007ED4111DD56A
00007ed4111dd660  movq rax, xmm15
00007ed4111dd665  shl rax, 0x0D
00007ed4111dd669  jbe 0x00007ED4111DD56A
00007ed4111dd66f  vorps xmm14, xmm15, [0x00007ED410DFE070]
00007ed4111dd677  jmp 0x00007ED4111DD56A
00007ed4111dd67c  int3
00007ed4111dd67d  nop [rax], eax
00007ed4111dd680  mov rax, [r15+0xF8]
00007ed4111dd687  lea r14, [rax+0x1A0]
00007ed4111dd68e  mov r12, [r13+r14*1]
00007ed4111dd693  lea r14, [rax+0x1A8]
00007ed4111dd69a  mov r11, [r13+r14*1]
00007ed4111dd69f  mov [r15+0xA0], r12
00007ed4111dd6a6  mov [r15+0x98], r11
00007ed4111dd6ad  mov r14, [r15+0x40]
00007ed4111dd6b1  lea r12, [r14+0xC50]
00007ed4111dd6b8  movaps xmm1, [r15+0x110]
00007ed4111dd6c0  movq r14, xmm1
00007ed4111dd6c5  mov [r13+r12*1], r14
00007ed4111dd6ca  lea r14, [rax+0x190]
00007ed4111dd6d1  mov r12, [r13+r14*1]
00007ed4111dd6d6  lea r14, [rax+0x198]
00007ed4111dd6dd  mov r11, [r13+r14*1]
00007ed4111dd6e2  mov [r15+0xE8], r12
00007ed4111dd6e9  mov [r15+0xF0], r11
00007ed4111dd6f0  lea r14, [rax+0x180]
00007ed4111dd6f7  mov r12, [r13+r14*1]
00007ed4111dd6fc  lea r14, [rax+0x188]
00007ed4111dd703  mov r10, [r13+r14*1]
00007ed4111dd708  movq xmm1, r12
00007ed4111dd70d  movq xmm15, r10
00007ed4111dd712  movq xmm1, xmm1
00007ed4111dd716  movq xmm1, xmm1
00007ed4111dd71a  movaps [r15+0x1A0], xmm1
00007ed4111dd722  movq xmm15, xmm15
00007ed4111dd727  movq xmm15, xmm15
00007ed4111dd72c  movaps [r15+0x190], xmm15
00007ed4111dd734  lea r14, [rax+0x170]
00007ed4111dd73b  mov r12, [r13+r14*1]
00007ed4111dd740  lea r14, [rax+0x178]
00007ed4111dd747  mov r10, [r13+r14*1]
00007ed4111dd74c  movq xmm1, r12
00007ed4111dd751  movq xmm15, r10
00007ed4111dd756  movq xmm1, xmm1
00007ed4111dd75a  movq xmm1, xmm1
00007ed4111dd75e  movaps [r15+0x1C0], xmm1
00007ed4111dd766  movq xmm15, xmm15
00007ed4111dd76b  movq xmm15, xmm15
00007ed4111dd770  movaps [r15+0x1B0], xmm15
00007ed4111dd778  lea r14, [rax+0x160]
00007ed4111dd77f  mov r12, [r13+r14*1]
00007ed4111dd784  lea r14, [rax+0x168]
00007ed4111dd78b  mov r10, [r13+r14*1]
00007ed4111dd790  movq xmm1, r12
00007ed4111dd795  movq xmm15, r10
00007ed4111dd79a  movq xmm1, xmm1
00007ed4111dd79e  movq xmm1, xmm1
00007ed4111dd7a2  movaps [r15+0x1E0], xmm1
00007ed4111dd7aa  movq xmm15, xmm15
00007ed4111dd7af  movq xmm15, xmm15
00007ed4111dd7b4  movaps [r15+0x1D0], xmm15
00007ed4111dd7bc  lea r14, [rax+0x150]
00007ed4111dd7c3  mov r12, [r13+r14*1]
00007ed4111dd7c8  lea r14, [rax+0x158]
00007ed4111dd7cf  mov r10, [r13+r14*1]
00007ed4111dd7d4  movq xmm1, r12
00007ed4111dd7d9  movq xmm15, r10
00007ed4111dd7de  movq xmm1, xmm1
00007ed4111dd7e2  movq xmm1, xmm1
00007ed4111dd7e6  movaps [r15+0x200], xmm1
00007ed4111dd7ee  movq xmm15, xmm15
00007ed4111dd7f3  movq xmm15, xmm15
00007ed4111dd7f8  movaps [r15+0x1F0], xmm15
00007ed4111dd800  lea r14, [rax+0x1B0]
00007ed4111dd807  mov [r15+0xF8], r14
00007ed4111dd80e  mov [r15+0x100], r11
00007ed4111dd815  jmp 0x00007ED4111CE5C0
00007ed4111dd81a  int3
00007ed4111dd81b  call 0x00007ED4110E27E0
00007ed4111dd820  jmp 0x00007ED4111DD693
00007ed4111dd825  call 0x00007ED4110E1570
00007ed4111dd82a  jmp 0x00007ED4111DD69F
00007ed4111dd82f  call 0x00007ED4110C3FE0
00007ed4111dd834  jmp 0x00007ED4111DD6CA
00007ed4111dd839  call 0x00007ED4110E27E0
00007ed4111dd83e  jmp 0x00007ED4111DD6D6
00007ed4111dd843  call 0x00007ED4110E1570
00007ed4111dd848  jmp 0x00007ED4111DD6E2
00007ed4111dd84d  call 0x00007ED4110E27E0
00007ed4111dd852  jmp 0x00007ED4111DD6FC
00007ed4111dd857  call 0x00007ED4110E0300
00007ed4111dd85c  jmp 0x00007ED4111DD708
00007ed4111dd861  call 0x00007ED4110E27E0
00007ed4111dd866  jmp 0x00007ED4111DD740
00007ed4111dd86b  call 0x00007ED4110E0300
00007ed4111dd870  jmp 0x00007ED4111DD74C
00007ed4111dd875  call 0x00007ED4110E27E0
00007ed4111dd87a  jmp 0x00007ED4111DD784
00007ed4111dd87f  call 0x00007ED4110E0300
00007ed4111dd884  jmp 0x00007ED4111DD790
00007ed4111dd889  call 0x00007ED4110E27E0
00007ed4111dd88e  jmp 0x00007ED4111DD7C8
00007ed4111dd893  call 0x00007ED4110E0300
00007ed4111dd898  jmp 0x00007ED4111DD7D4
00007ed4111dd89d  int3
00007ed4111dd89e  nop
00007ed4111dd8a0  mov qword ptr [r15+0x100], 0x04
00007ed4111dd8ab  mov esi, 0x00
00007ed4111dd8b0  mov edx, 0x09
00007ed4111dd8b5  mov rdi, 0x7FFEC80166A0
00007ed4111dd8bf  mov rax, 0x5CA8E48E8970
00007ed4111dd8c9  call rax
00007ed4111dd8cb  cmp dword ptr [r15+0x318], 0x00
00007ed4111dd8d3  jnz 0x00007ED410FFE110
00007ed4111dd8d9  jmp 0x00007ED410FFE0A0
00007ed4111dd8de  int3
00007ed4111dd8df  int3
