0000710a0d1ce69b  nop [rax+rax*1], eax
0000710a0d1ce6a0  mov rax, [r15+0xF8]
0000710a0d1ce6a7  lea r14, [rax-0x1B0]
0000710a0d1ce6ae  mov [r15+0xF8], r14
0000710a0d1ce6b5  lea rax, [r14+0x1A0]
0000710a0d1ce6bc  mov r12, [r15+0xA0]
0000710a0d1ce6c3  mov r11, [r15+0x98]
0000710a0d1ce6ca  mov [r13+rax*1], r12
0000710a0d1ce6cf  lea rax, [r14+0x1A8]
0000710a0d1ce6d6  mov [r13+rax*1], r11
0000710a0d1ce6db  mov eax, 0x420A30
0000710a0d1ce6e0  movups xmm1, [r13+rax*1]
0000710a0d1ce6e6  mov eax, 0x4209C0
0000710a0d1ce6eb  movups xmm15, [r13+rax*1]
0000710a0d1ce6f1  mov eax, 0x420A50
0000710a0d1ce6f6  movups xmm14, [r13+rax*1]
0000710a0d1ce6fc  mov eax, 0x4209F0
0000710a0d1ce701  movups xmm13, [r13+rax*1]
0000710a0d1ce707  mov qword ptr [r15+0x98], 0x430C60
0000710a0d1ce712  mov eax, 0x420A60
0000710a0d1ce717  movups xmm12, [r13+rax*1]
0000710a0d1ce71d  mov eax, 0x430C60
0000710a0d1ce722  movups [r13+rax*1], xmm1
0000710a0d1ce728  mov eax, 0x430C70
0000710a0d1ce72d  movups [r13+rax*1], xmm15
0000710a0d1ce733  mov eax, 0x430C80
0000710a0d1ce738  movups [r13+rax*1], xmm14
0000710a0d1ce73e  mov eax, 0x430C90
0000710a0d1ce743  movups [r13+rax*1], xmm13
0000710a0d1ce749  mov eax, 0x4209B0
0000710a0d1ce74e  movups xmm14, [r13+rax*1]
0000710a0d1ce754  mov eax, 0x4209A0
0000710a0d1ce759  movups xmm13, [r13+rax*1]
0000710a0d1ce75f  mov eax, 0x430D60
0000710a0d1ce764  movups [r13+rax*1], xmm1
0000710a0d1ce76a  mov eax, 0x430D70
0000710a0d1ce76f  movups [r13+rax*1], xmm15
0000710a0d1ce775  mov eax, 0x430CA0
0000710a0d1ce77a  movups [r13+rax*1], xmm12
0000710a0d1ce780  mov eax, 0x430CB0
0000710a0d1ce785  movups [r13+rax*1], xmm14
0000710a0d1ce78b  mov eax, 0x420990
0000710a0d1ce790  movups xmm1, [r13+rax*1]
0000710a0d1ce796  mov eax, 0x420A00
0000710a0d1ce79b  movups xmm15, [r13+rax*1]
0000710a0d1ce7a1  mov eax, 0x430CC0
0000710a0d1ce7a6  movups [r13+rax*1], xmm13
0000710a0d1ce7ac  mov eax, 0x430CD0
0000710a0d1ce7b1  movups [r13+rax*1], xmm1
0000710a0d1ce7b7  mov eax, 0x420A10
0000710a0d1ce7bc  movups xmm1, [r13+rax*1]
0000710a0d1ce7c2  mov eax, 0x4209E0
0000710a0d1ce7c7  movups xmm14, [r13+rax*1]
0000710a0d1ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000710a0d1ce7d5  mov eax, 0x430CE0
0000710a0d1ce7da  movups [r13+rax*1], xmm15
0000710a0d1ce7e0  mov eax, 0x430CF0
0000710a0d1ce7e5  movups [r13+rax*1], xmm1
0000710a0d1ce7eb  mov eax, 0x420A80
0000710a0d1ce7f0  movups xmm1, [r13+rax*1]
0000710a0d1ce7f6  mov eax, 0x420A90
0000710a0d1ce7fb  movups xmm15, [r13+rax*1]
0000710a0d1ce801  movaps [r15+0x150], xmm15
0000710a0d1ce809  mov qword ptr [r15+0xA0], 0x3E8
0000710a0d1ce814  mov eax, 0x430D00
0000710a0d1ce819  movups [r13+rax*1], xmm14
0000710a0d1ce81f  mov eax, 0x430D10
0000710a0d1ce824  movups [r13+rax*1], xmm1
0000710a0d1ce82a  mov eax, 0x420A70
0000710a0d1ce82f  movups xmm1, [r13+rax*1]
0000710a0d1ce835  mov eax, 0x420A20
0000710a0d1ce83a  movups xmm14, [r13+rax*1]
0000710a0d1ce840  movaps [r15+0x140], xmm14
0000710a0d1ce848  lea rax, [r14+0x150]
0000710a0d1ce84f  movq xmm13, qword ptr [r15+0x200]
0000710a0d1ce858  movq xmm12, qword ptr [r15+0x1F0]
0000710a0d1ce861  movq r12, xmm13
0000710a0d1ce866  movq r11, xmm12
0000710a0d1ce86b  mov [r13+rax*1], r12
0000710a0d1ce870  lea rax, [r14+0x158]
0000710a0d1ce877  mov [r13+rax*1], r11
0000710a0d1ce87c  mov eax, 0x430D20
0000710a0d1ce881  movups [r13+rax*1], xmm15
0000710a0d1ce887  mov eax, 0x430D30
0000710a0d1ce88c  movups [r13+rax*1], xmm1
0000710a0d1ce892  mov eax, 0x420A40
0000710a0d1ce897  movups xmm1, [r13+rax*1]
0000710a0d1ce89d  mov eax, 0x420AA8
0000710a0d1ce8a2  mov r12, [r13+rax*1]
0000710a0d1ce8a7  movq xmm15, r12
0000710a0d1ce8ac  mov qword ptr [r15+0x40], 0x420AB0
0000710a0d1ce8b4  mov eax, 0x430D40
0000710a0d1ce8b9  movups [r13+rax*1], xmm14
0000710a0d1ce8bf  mov eax, 0x430D50
0000710a0d1ce8c4  movups [r13+rax*1], xmm1
0000710a0d1ce8ca  mov eax, 0x420B10
0000710a0d1ce8cf  movups xmm1, [r13+rax*1]
0000710a0d1ce8d5  movq rax, xmm15
0000710a0d1ce8da  mov r12d, 0x430D80
0000710a0d1ce8e0  mov [r13+r12*1], rax
0000710a0d1ce8e5  mov eax, 0x420AF0
0000710a0d1ce8ea  movups xmm15, [r13+rax*1]
0000710a0d1ce8f0  mov eax, 0x420B00
0000710a0d1ce8f5  movups xmm14, [r13+rax*1]
0000710a0d1ce8fb  lea rax, [r14+0x130]
0000710a0d1ce902  movups [r13+rax*1], xmm1
0000710a0d1ce908  lea rax, [r14+0x160]
0000710a0d1ce90f  movq xmm1, qword ptr [r15+0x1E0]
0000710a0d1ce918  movq xmm13, qword ptr [r15+0x1D0]
0000710a0d1ce921  movq r12, xmm1
0000710a0d1ce926  movq r11, xmm13
0000710a0d1ce92b  mov [r13+rax*1], r12
0000710a0d1ce930  lea rax, [r14+0x168]
0000710a0d1ce937  mov [r13+rax*1], r11
0000710a0d1ce93c  lea rax, [r14+0x110]
0000710a0d1ce943  movups [r13+rax*1], xmm15
0000710a0d1ce949  lea rax, [r14+0x120]
0000710a0d1ce950  movups [r13+rax*1], xmm14
0000710a0d1ce956  mov eax, 0x420AB0
0000710a0d1ce95b  movups xmm1, [r13+rax*1]
0000710a0d1ce961  mov eax, 0x420AC0
0000710a0d1ce966  movups xmm15, [r13+rax*1]
0000710a0d1ce96c  movaps [r15+0x120], xmm15
0000710a0d1ce974  lea rax, [r14+0x170]
0000710a0d1ce97b  movq xmm14, qword ptr [r15+0x1C0]
0000710a0d1ce984  movq xmm13, qword ptr [r15+0x1B0]
0000710a0d1ce98d  movq r12, xmm14
0000710a0d1ce992  movq r11, xmm13
0000710a0d1ce997  mov [r13+rax*1], r12
0000710a0d1ce99c  lea rax, [r14+0x178]
0000710a0d1ce9a3  mov [r13+rax*1], r11
0000710a0d1ce9a8  lea rax, [r14+0x180]
0000710a0d1ce9af  movq xmm14, qword ptr [r15+0x1A0]
0000710a0d1ce9b8  movq xmm13, qword ptr [r15+0x190]
0000710a0d1ce9c1  movq r12, xmm14
0000710a0d1ce9c6  movq r11, xmm13
0000710a0d1ce9cb  mov [r13+rax*1], r12
0000710a0d1ce9d0  lea rax, [r14+0x188]
0000710a0d1ce9d7  mov [r13+rax*1], r11
0000710a0d1ce9dc  lea rax, [r14+0xD0]
0000710a0d1ce9e3  movups [r13+rax*1], xmm1
0000710a0d1ce9e9  lea rax, [r14+0xE0]
0000710a0d1ce9f0  movups [r13+rax*1], xmm15
0000710a0d1ce9f6  mov eax, 0x420AD0
0000710a0d1ce9fb  movups xmm1, [r13+rax*1]
0000710a0d1cea01  mov eax, 0x420AE0
0000710a0d1cea06  movups xmm15, [r13+rax*1]
0000710a0d1cea0c  movaps [r15+0x110], xmm1
0000710a0d1cea14  movaps [r15+0x130], xmm15
0000710a0d1cea1c  lea rax, [r14+0x190]
0000710a0d1cea23  mov r12, [r15+0xE8]
0000710a0d1cea2a  mov r11, [r15+0xF0]
0000710a0d1cea31  mov [r13+rax*1], r12
0000710a0d1cea36  lea rax, [r14+0x198]
0000710a0d1cea3d  mov [r13+rax*1], r11
0000710a0d1cea42  mov eax, 0x430D88
0000710a0d1cea47  mov r12d, 0x421DF8D3
0000710a0d1cea4d  mov [r13+rax*1], r12d
0000710a0d1cea52  lea rax, [r14+0xF0]
0000710a0d1cea59  movups [r13+rax*1], xmm1
0000710a0d1cea5f  lea rax, [r14+0x100]
0000710a0d1cea66  movups [r13+rax*1], xmm15
0000710a0d1cea6c  lea rax, [r14+0xD0]
0000710a0d1cea73  mov [r15], rax
0000710a0d1cea76  mov qword ptr [r15+0x08], 0x430C60
0000710a0d1cea7e  mov qword ptr [r15+0x10], 0x12C
0000710a0d1cea86  mov qword ptr [r15+0xF0], 0x410284
0000710a0d1cea91  mov r14d, [r15+0x320]
0000710a0d1cea98  mov eax, 0x410284
0000710a0d1cea9d  mov rcx, 0x710A0D1D07C0
0000710a0d1ceaa7  mov [r15+r14*8+0x328], rax
0000710a0d1ceaaf  mov [r15+r14*8+0x368], rcx
0000710a0d1ceab7  add r14d, 0x01
0000710a0d1ceabb  and r14d, 0x07
0000710a0d1ceabf  mov [r15+0x320], r14d
0000710a0d1ceac6  cmp dword ptr [r15+0x318], 0x00
0000710a0d1ceace  jz 0x0000710A0D1CED70
0000710a0d1cead4  nop [rax+rax*1], ax
0000710a0d1ceadd  nop [rax+rax*1], eax
0000710a0d1ceae5  mov eax, 0x4106BC
0000710a0d1ceaea  mov [r15+0x100], rax
0000710a0d1ceaf1  jmp 0x0000710A0CFFE110
0000710a0d1ceaf6  int3
0000710a0d1ceaf7  call 0x0000710A0D00BC20
0000710a0d1ceafc  jmp 0x0000710A0D1CE6CF
0000710a0d1ceb01  call 0x0000710A0D00A9A0
0000710a0d1ceb06  jmp 0x0000710A0D1CE6DB
0000710a0d1ceb0b  call 0x0000710A0CFFF430
0000710a0d1ceb10  jmp 0x0000710A0D1CE6E6
0000710a0d1ceb15  call 0x0000710A0D00E760
0000710a0d1ceb1a  jmp 0x0000710A0D1CE6F1
0000710a0d1ceb1f  call 0x0000710A0D00D4E0
0000710a0d1ceb24  jmp 0x0000710A0D1CE6FC
0000710a0d1ceb29  call 0x0000710A0D00C260
0000710a0d1ceb2e  jmp 0x0000710A0D1CE707
0000710a0d1ceb33  call 0x0000710A0D00AFE0
0000710a0d1ceb38  jmp 0x0000710A0D1CE71D
0000710a0d1ceb3d  call 0x0000710A0CFFF540
0000710a0d1ceb42  jmp 0x0000710A0D1CE728
0000710a0d1ceb47  call 0x0000710A0D00E880
0000710a0d1ceb4c  jmp 0x0000710A0D1CE733
0000710a0d1ceb51  call 0x0000710A0D00D600
0000710a0d1ceb56  jmp 0x0000710A0D1CE73E
0000710a0d1ceb5b  call 0x0000710A0D00C380
0000710a0d1ceb60  jmp 0x0000710A0D1CE749
0000710a0d1ceb65  call 0x0000710A0D00D4E0
0000710a0d1ceb6a  jmp 0x0000710A0D1CE754
0000710a0d1ceb6f  call 0x0000710A0D00C260
0000710a0d1ceb74  jmp 0x0000710A0D1CE75F
0000710a0d1ceb79  call 0x0000710A0CFFF540
0000710a0d1ceb7e  jmp 0x0000710A0D1CE76A
0000710a0d1ceb83  call 0x0000710A0D00E880
0000710a0d1ceb88  jmp 0x0000710A0D1CE775
0000710a0d1ceb8d  call 0x0000710A0D00B100
0000710a0d1ceb92  jmp 0x0000710A0D1CE780
0000710a0d1ceb97  call 0x0000710A0D00D600
0000710a0d1ceb9c  jmp 0x0000710A0D1CE78B
0000710a0d1ceba1  call 0x0000710A0CFFF430
0000710a0d1ceba6  jmp 0x0000710A0D1CE796
0000710a0d1cebab  call 0x0000710A0D00E760
0000710a0d1cebb0  jmp 0x0000710A0D1CE7A1
0000710a0d1cebb5  call 0x0000710A0D00C380
0000710a0d1cebba  jmp 0x0000710A0D1CE7AC
0000710a0d1cebbf  call 0x0000710A0CFFF540
0000710a0d1cebc4  jmp 0x0000710A0D1CE7B7
0000710a0d1cebc9  call 0x0000710A0CFFF430
0000710a0d1cebce  jmp 0x0000710A0D1CE7C2
0000710a0d1cebd3  call 0x0000710A0D00D4E0
0000710a0d1cebd8  jmp 0x0000710A0D1CE7CD
0000710a0d1cebdd  call 0x0000710A0D00E880
0000710a0d1cebe2  jmp 0x0000710A0D1CE7E0
0000710a0d1cebe7  call 0x0000710A0CFFF540
0000710a0d1cebec  jmp 0x0000710A0D1CE7EB
0000710a0d1cebf1  call 0x0000710A0CFFF430
0000710a0d1cebf6  jmp 0x0000710A0D1CE7F6
0000710a0d1cebfb  call 0x0000710A0D00E760
0000710a0d1cec00  jmp 0x0000710A0D1CE801
0000710a0d1cec05  call 0x0000710A0D00D600
0000710a0d1cec0a  jmp 0x0000710A0D1CE81F
0000710a0d1cec0f  call 0x0000710A0CFFF540
0000710a0d1cec14  jmp 0x0000710A0D1CE82A
0000710a0d1cec19  call 0x0000710A0CFFF430
0000710a0d1cec1e  jmp 0x0000710A0D1CE835
0000710a0d1cec23  call 0x0000710A0D00D4E0
0000710a0d1cec28  jmp 0x0000710A0D1CE840
0000710a0d1cec2d  call 0x0000710A0D00BC20
0000710a0d1cec32  jmp 0x0000710A0D1CE870
0000710a0d1cec37  call 0x0000710A0D00A9A0
0000710a0d1cec3c  jmp 0x0000710A0D1CE87C
0000710a0d1cec41  call 0x0000710A0D00E880
0000710a0d1cec46  jmp 0x0000710A0D1CE887
0000710a0d1cec4b  call 0x0000710A0CFFF540
0000710a0d1cec50  jmp 0x0000710A0D1CE892
0000710a0d1cec55  call 0x0000710A0CFFF430
0000710a0d1cec5a  jmp 0x0000710A0D1CE89D
0000710a0d1cec5f  call 0x0000710A0D00B720
0000710a0d1cec64  jmp 0x0000710A0D1CE8A7
0000710a0d1cec69  call 0x0000710A0D00D600
0000710a0d1cec6e  jmp 0x0000710A0D1CE8BF
0000710a0d1cec73  call 0x0000710A0CFFF540
0000710a0d1cec78  jmp 0x0000710A0D1CE8CA
0000710a0d1cec7d  call 0x0000710A0CFFF430
0000710a0d1cec82  jmp 0x0000710A0D1CE8D5
0000710a0d1cec87  call 0x0000710A0D0B4CB0
0000710a0d1cec8c  jmp 0x0000710A0D1CE8E5
0000710a0d1cec91  call 0x0000710A0D00E760
0000710a0d1cec96  jmp 0x0000710A0D1CE8F0
0000710a0d1cec9b  call 0x0000710A0D00D4E0
0000710a0d1ceca0  jmp 0x0000710A0D1CE8FB
0000710a0d1ceca5  call 0x0000710A0CFFF540
0000710a0d1cecaa  jmp 0x0000710A0D1CE908
0000710a0d1cecaf  call 0x0000710A0D00BC20
0000710a0d1cecb4  jmp 0x0000710A0D1CE930
0000710a0d1cecb9  call 0x0000710A0D00A9A0
0000710a0d1cecbe  jmp 0x0000710A0D1CE93C
0000710a0d1cecc3  call 0x0000710A0D00E880
0000710a0d1cecc8  jmp 0x0000710A0D1CE949
0000710a0d1ceccd  call 0x0000710A0D00D600
0000710a0d1cecd2  jmp 0x0000710A0D1CE956
0000710a0d1cecd7  call 0x0000710A0CFFF430
0000710a0d1cecdc  jmp 0x0000710A0D1CE961
0000710a0d1cece1  call 0x0000710A0D00E760
0000710a0d1cece6  jmp 0x0000710A0D1CE96C
0000710a0d1ceceb  call 0x0000710A0D00BC20
0000710a0d1cecf0  jmp 0x0000710A0D1CE99C
0000710a0d1cecf5  call 0x0000710A0D00A9A0
0000710a0d1cecfa  jmp 0x0000710A0D1CE9A8
0000710a0d1cecff  call 0x0000710A0D00BC20
0000710a0d1ced04  jmp 0x0000710A0D1CE9D0
0000710a0d1ced09  call 0x0000710A0D00A9A0
0000710a0d1ced0e  jmp 0x0000710A0D1CE9DC
0000710a0d1ced13  call 0x0000710A0CFFF540
0000710a0d1ced18  jmp 0x0000710A0D1CE9E9
0000710a0d1ced1d  call 0x0000710A0D00E880
0000710a0d1ced22  jmp 0x0000710A0D1CE9F6
0000710a0d1ced27  call 0x0000710A0CFFF430
0000710a0d1ced2c  jmp 0x0000710A0D1CEA01
0000710a0d1ced31  call 0x0000710A0D00E760
0000710a0d1ced36  jmp 0x0000710A0D1CEA0C
0000710a0d1ced3b  call 0x0000710A0D00BC20
0000710a0d1ced40  jmp 0x0000710A0D1CEA36
0000710a0d1ced45  call 0x0000710A0D00A9A0
0000710a0d1ced4a  jmp 0x0000710A0D1CEA42
0000710a0d1ced4f  call 0x0000710A0D00BAE0
0000710a0d1ced54  jmp 0x0000710A0D1CEA52
0000710a0d1ced59  call 0x0000710A0CFFF540
0000710a0d1ced5e  jmp 0x0000710A0D1CEA5F
0000710a0d1ced63  call 0x0000710A0D00E880
0000710a0d1ced68  jmp 0x0000710A0D1CEA6C
0000710a0d1ced6d  int3
0000710a0d1ced6e  nop
0000710a0d1ced70  mov rax, [r15]
0000710a0d1ced73  lea r14, [rax+0x20]
0000710a0d1ced77  mov r12, [r13+r14*1]
0000710a0d1ced7c  mov r14, [r15+0x10]
0000710a0d1ced80  lea r11, [r12+r14*1]
0000710a0d1ced84  mov [r15+0x40], r11
0000710a0d1ced88  lea r12, [rax+0x20]
0000710a0d1ced8c  mov [r13+r12*1], r11
0000710a0d1ced91  test r14, r14
0000710a0d1ced94  setz r14b
0000710a0d1ced98  movzx r14, r14b
0000710a0d1ced9c  mov [rsp+0x414], r14b
0000710a0d1ceda4  cmp byte ptr [rsp+0x414], 0x00
0000710a0d1cedac  jz 0x0000710A0D1CEDDE
0000710a0d1cedae  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cedb6  mov eax, 0x410934
0000710a0d1cedbb  mov [r15+0x100], rax
0000710a0d1cedc2  jz 0x0000710A0CFFE0A0
0000710a0d1cedc8  nop [rax+rax*1], eax
0000710a0d1cedcd  mov eax, 0x410934
0000710a0d1cedd2  mov [r15+0x100], rax
0000710a0d1cedd9  jmp 0x0000710A0CFFE110
0000710a0d1cedde  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cede6  jz 0x0000710A0D1CEE30
0000710a0d1cedec  nop [rax+rax*1], ax
0000710a0d1cedf5  nop [rax+rax*1], eax
0000710a0d1cedfd  mov eax, 0x4106CC
0000710a0d1cee02  mov [r15+0x100], rax
0000710a0d1cee09  jmp 0x0000710A0CFFE110
0000710a0d1cee0e  int3
0000710a0d1cee0f  call 0x0000710A0D0E27E0
0000710a0d1cee14  jmp 0x0000710A0D1CED7C
0000710a0d1cee19  call 0x0000710A0D0C0860
0000710a0d1cee1e  jmp 0x0000710A0D1CED91
0000710a0d1cee23  int3
0000710a0d1cee24  nop [rax+rax*1], ax
0000710a0d1cee2d  nop [rax], eax
0000710a0d1cee30  mov rax, [r15+0xF8]
0000710a0d1cee37  lea r14, [rax-0x150]
0000710a0d1cee3e  mov [r15+0xF8], r14
0000710a0d1cee45  mov rax, [r15]
0000710a0d1cee48  lea r12, [rax+0x68]
0000710a0d1cee4c  mov r11, [r13+r12*1]
0000710a0d1cee51  mov [r15+0x88], r11
0000710a0d1cee58  lea r12, [rax+0x28]
0000710a0d1cee5c  mov [r15+0x40], r12
0000710a0d1cee60  mov [r15+0x48], r14
0000710a0d1cee64  mov qword ptr [r15+0x50], 0x420B20
0000710a0d1cee6c  lea rax, [r14+0x100]
0000710a0d1cee73  mov r12, [r15+0xE8]
0000710a0d1cee7a  mov r11, [r15+0xD8]
0000710a0d1cee81  mov [r13+rax*1], r12
0000710a0d1cee86  lea rax, [r14+0x108]
0000710a0d1cee8d  mov [r13+rax*1], r11
0000710a0d1cee92  lea rax, [r14+0x110]
0000710a0d1cee99  mov r12, [r15+0xD0]
0000710a0d1ceea0  mov r11, [r15+0xC8]
0000710a0d1ceea7  mov [r13+rax*1], r12
0000710a0d1ceeac  lea rax, [r14+0x118]
0000710a0d1ceeb3  mov [r13+rax*1], r11
0000710a0d1ceeb8  lea rax, [r14+0x120]
0000710a0d1ceebf  mov r12, [r15+0xC0]
0000710a0d1ceec6  mov r11, [r15+0xB8]
0000710a0d1ceecd  mov [r13+rax*1], r12
0000710a0d1ceed2  lea rax, [r14+0x128]
0000710a0d1ceed9  mov [r13+rax*1], r11
0000710a0d1ceede  lea rax, [r14+0x130]
0000710a0d1ceee5  mov r12, [r15+0xB0]
0000710a0d1ceeec  mov r11, [r15+0xA8]
0000710a0d1ceef3  mov [r13+rax*1], r12
0000710a0d1ceef8  lea rax, [r14+0x138]
0000710a0d1ceeff  mov [r13+rax*1], r11
0000710a0d1cef04  lea rax, [r14+0x140]
0000710a0d1cef0b  mov r12, [r15+0xA0]
0000710a0d1cef12  mov r11, [r15+0x98]
0000710a0d1cef19  mov [r13+rax*1], r12
0000710a0d1cef1e  lea rax, [r14+0x148]
0000710a0d1cef25  mov [r13+rax*1], r11
0000710a0d1cef2a  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cef32  jz 0x0000710A0D1CEFD0
0000710a0d1cef38  nop [rax+rax*1], ax
0000710a0d1cef41  nop [rax+rax*1], eax
0000710a0d1cef49  mov eax, 0x410704
0000710a0d1cef4e  mov [r15+0x100], rax
0000710a0d1cef55  jmp 0x0000710A0CFFE110
0000710a0d1cef5a  int3
0000710a0d1cef5b  call 0x0000710A0D0C0370
0000710a0d1cef60  jmp 0x0000710A0D1CEE51
0000710a0d1cef65  call 0x0000710A0D00BC20
0000710a0d1cef6a  jmp 0x0000710A0D1CEE86
0000710a0d1cef6f  call 0x0000710A0D00A9A0
0000710a0d1cef74  jmp 0x0000710A0D1CEE92
0000710a0d1cef79  call 0x0000710A0D00BC20
0000710a0d1cef7e  jmp 0x0000710A0D1CEEAC
0000710a0d1cef83  call 0x0000710A0D00A9A0
0000710a0d1cef88  jmp 0x0000710A0D1CEEB8
0000710a0d1cef8d  call 0x0000710A0D00BC20
0000710a0d1cef92  jmp 0x0000710A0D1CEED2
0000710a0d1cef97  call 0x0000710A0D00A9A0
0000710a0d1cef9c  jmp 0x0000710A0D1CEEDE
0000710a0d1cefa1  call 0x0000710A0D00BC20
0000710a0d1cefa6  jmp 0x0000710A0D1CEEF8
0000710a0d1cefab  call 0x0000710A0D00A9A0
0000710a0d1cefb0  jmp 0x0000710A0D1CEF04
0000710a0d1cefb5  call 0x0000710A0D00BC20
0000710a0d1cefba  jmp 0x0000710A0D1CEF1E
0000710a0d1cefbf  call 0x0000710A0D00A9A0
0000710a0d1cefc4  jmp 0x0000710A0D1CEF2A
0000710a0d1cefc9  int3
0000710a0d1cefca  nop [rax+rax*1], ax
0000710a0d1cefd0  mov rax, [r15+0x08]
0000710a0d1cefd4  movzx r14d, byte ptr [r13+rax*1]
0000710a0d1cefda  movzx r14d, r14b
0000710a0d1cefde  mov [rsp+0x10], r14d
0000710a0d1cefe3  mov r14d, r14d
0000710a0d1cefe6  mov [r15+0x58], r14
0000710a0d1cefea  lea r14, [rax+0x01]
0000710a0d1cefee  mov [r15+0x08], r14
0000710a0d1ceff2  mov rax, [r15+0x88]
0000710a0d1ceff9  lea r14, [rax+0x01]
0000710a0d1ceffd  mov r12, [r15]
0000710a0d1cf000  lea r11, [r12+0x68]
0000710a0d1cf005  mov [r13+r11*1], r14
0000710a0d1cf00a  lea r14, [r12+rax*1]
0000710a0d1cf00e  mov [r15+0x60], r14
0000710a0d1cf012  lea rax, [r14+0x28]
0000710a0d1cf016  mov r11d, [rsp+0x10]
0000710a0d1cf01b  movzx r14d, r11b
0000710a0d1cf01f  mov [r13+rax*1], r14b
0000710a0d1cf024  lea rax, [r12+0x68]
0000710a0d1cf029  mov r14, [r13+rax*1]
0000710a0d1cf02e  mov [r15+0x88], r14
0000710a0d1cf035  xor eax, eax
0000710a0d1cf037  mov r12d, 0x40
0000710a0d1cf03d  cmp r14, r12
0000710a0d1cf040  cmc
0000710a0d1cf041  lahf
0000710a0d1cf042  seto al
0000710a0d1cf045  mov [r15+0x108], eax
0000710a0d1cf04c  mov eax, [r15+0x108]
0000710a0d1cf053  sahf
0000710a0d1cf054  jnz 0x0000710A0D1CF086
0000710a0d1cf056  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cf05e  jz 0x0000710A0D1CF170
0000710a0d1cf064  nop [rax+rax*1], ax
0000710a0d1cf06d  nop [rax+rax*1], eax
0000710a0d1cf075  mov eax, 0x410724
0000710a0d1cf07a  mov [r15+0x100], rax
0000710a0d1cf081  jmp 0x0000710A0CFFE110
0000710a0d1cf086  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cf08e  jz 0x0000710A0D1CF0E0
0000710a0d1cf094  nop [rax+rax*1], ax
0000710a0d1cf09d  nop [rax+rax*1], eax
0000710a0d1cf0a5  mov eax, 0x4106FC
0000710a0d1cf0aa  mov [r15+0x100], rax
0000710a0d1cf0b1  jmp 0x0000710A0CFFE110
0000710a0d1cf0b6  int3
0000710a0d1cf0b7  call 0x0000710A0D00D860
0000710a0d1cf0bc  jmp 0x0000710A0D1CEFDA
0000710a0d1cf0c1  call 0x0000710A0D0B36E0
0000710a0d1cf0c6  jmp 0x0000710A0D1CF00A
0000710a0d1cf0cb  call 0x0000710A0D00DD60
0000710a0d1cf0d0  jmp 0x0000710A0D1CF024
0000710a0d1cf0d5  call 0x0000710A0D00DC20
0000710a0d1cf0da  jmp 0x0000710A0D1CF02E
0000710a0d1cf0df  int3
0000710a0d1cf0e0  mov rax, [r15+0x10]
0000710a0d1cf0e4  lea r14, [rax-0x01]
0000710a0d1cf0e8  mov [r15+0x10], r14
0000710a0d1cf0ec  test r14, r14
0000710a0d1cf0ef  setz r14b
0000710a0d1cf0f3  movzx r14, r14b
0000710a0d1cf0f7  mov [rsp+0x414], r14b
0000710a0d1cf0ff  cmp byte ptr [rsp+0x414], 0x00
0000710a0d1cf107  jz 0x0000710A0D1CF139
0000710a0d1cf109  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cf111  jz 0x0000710A0D1D0670
0000710a0d1cf117  nop [rax+rax*1], ax
0000710a0d1cf120  nop [rax+rax*1], eax
0000710a0d1cf128  mov eax, 0x41091C
0000710a0d1cf12d  mov [r15+0x100], rax
0000710a0d1cf134  jmp 0x0000710A0CFFE110
0000710a0d1cf139  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cf141  jz 0x0000710A0D1CEFD0
0000710a0d1cf147  nop [rax+rax*1], ax
0000710a0d1cf150  nop [rax+rax*1], eax
0000710a0d1cf158  mov eax, 0x410704
0000710a0d1cf15d  mov [r15+0x100], rax
0000710a0d1cf164  jmp 0x0000710A0CFFE110
0000710a0d1cf169  int3
0000710a0d1cf16a  int3
0000710a0d1cf16b  nop [rax+rax*1], eax
0000710a0d1cf170  mov rax, [r15+0x40]
0000710a0d1cf174  movzx r14d, byte ptr [r13+rax*1]
0000710a0d1cf17a  movaps xmm1, [r15+0x110]
0000710a0d1cf182  pinsrb xmm1, r14d, 0x00
0000710a0d1cf189  lea r14, [rax+0x01]
0000710a0d1cf18d  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf193  movaps xmm15, [r15+0x120]
0000710a0d1cf19b  pinsrb xmm15, r12d, 0x00
0000710a0d1cf1a2  lea r14, [rax+0x02]
0000710a0d1cf1a6  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf1ac  movaps xmm14, [r15+0x130]
0000710a0d1cf1b4  pinsrb xmm14, r12d, 0x00
0000710a0d1cf1bb  lea r14, [rax+0x03]
0000710a0d1cf1bf  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf1c5  movaps xmm13, [r15+0x140]
0000710a0d1cf1cd  pinsrb xmm13, r12d, 0x00
0000710a0d1cf1d4  lea r14, [rax+0x04]
0000710a0d1cf1d8  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf1de  pinsrb xmm1, r12d, 0x01
0000710a0d1cf1e5  lea r14, [rax+0x05]
0000710a0d1cf1e9  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf1ef  pinsrb xmm15, r12d, 0x01
0000710a0d1cf1f6  lea r14, [rax+0x06]
0000710a0d1cf1fa  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf200  pinsrb xmm14, r12d, 0x01
0000710a0d1cf207  lea r14, [rax+0x07]
0000710a0d1cf20b  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf211  pinsrb xmm13, r12d, 0x01
0000710a0d1cf218  lea r14, [rax+0x08]
0000710a0d1cf21c  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf222  pinsrb xmm1, r12d, 0x02
0000710a0d1cf229  lea r14, [rax+0x09]
0000710a0d1cf22d  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf233  pinsrb xmm15, r12d, 0x02
0000710a0d1cf23a  lea r14, [rax+0x0A]
0000710a0d1cf23e  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf244  pinsrb xmm14, r12d, 0x02
0000710a0d1cf24b  lea r14, [rax+0x0B]
0000710a0d1cf24f  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf255  pinsrb xmm13, r12d, 0x02
0000710a0d1cf25c  lea r14, [rax+0x0C]
0000710a0d1cf260  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf266  pinsrb xmm1, r12d, 0x03
0000710a0d1cf26d  lea r14, [rax+0x0D]
0000710a0d1cf271  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf277  pinsrb xmm15, r12d, 0x03
0000710a0d1cf27e  lea r14, [rax+0x0E]
0000710a0d1cf282  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf288  pinsrb xmm14, r12d, 0x03
0000710a0d1cf28f  lea r14, [rax+0x0F]
0000710a0d1cf293  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf299  pinsrb xmm13, r12d, 0x03
0000710a0d1cf2a0  lea r14, [rax+0x10]
0000710a0d1cf2a4  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf2aa  pinsrb xmm1, r12d, 0x04
0000710a0d1cf2b1  lea r14, [rax+0x11]
0000710a0d1cf2b5  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf2bb  pinsrb xmm15, r12d, 0x04
0000710a0d1cf2c2  lea r14, [rax+0x12]
0000710a0d1cf2c6  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf2cc  pinsrb xmm14, r12d, 0x04
0000710a0d1cf2d3  lea r14, [rax+0x13]
0000710a0d1cf2d7  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf2dd  pinsrb xmm13, r12d, 0x04
0000710a0d1cf2e4  lea r14, [rax+0x14]
0000710a0d1cf2e8  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf2ee  pinsrb xmm1, r12d, 0x05
0000710a0d1cf2f5  lea r14, [rax+0x15]
0000710a0d1cf2f9  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf2ff  pinsrb xmm15, r12d, 0x05
0000710a0d1cf306  lea r14, [rax+0x16]
0000710a0d1cf30a  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf310  pinsrb xmm14, r12d, 0x05
0000710a0d1cf317  lea r14, [rax+0x17]
0000710a0d1cf31b  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf321  pinsrb xmm13, r12d, 0x05
0000710a0d1cf328  lea r14, [rax+0x18]
0000710a0d1cf32c  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf332  pinsrb xmm1, r12d, 0x06
0000710a0d1cf339  lea r14, [rax+0x19]
0000710a0d1cf33d  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf343  pinsrb xmm15, r12d, 0x06
0000710a0d1cf34a  lea r14, [rax+0x1A]
0000710a0d1cf34e  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf354  pinsrb xmm14, r12d, 0x06
0000710a0d1cf35b  lea r14, [rax+0x1B]
0000710a0d1cf35f  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf365  pinsrb xmm13, r12d, 0x06
0000710a0d1cf36c  lea r14, [rax+0x1C]
0000710a0d1cf370  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf376  pinsrb xmm1, r12d, 0x07
0000710a0d1cf37d  lea r14, [rax+0x1D]
0000710a0d1cf381  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf387  pinsrb xmm15, r12d, 0x07
0000710a0d1cf38e  lea r14, [rax+0x1E]
0000710a0d1cf392  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf398  pinsrb xmm14, r12d, 0x07
0000710a0d1cf39f  lea r14, [rax+0x1F]
0000710a0d1cf3a3  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf3a9  pinsrb xmm13, r12d, 0x07
0000710a0d1cf3b0  lea r14, [rax+0x20]
0000710a0d1cf3b4  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf3ba  pinsrb xmm1, r12d, 0x08
0000710a0d1cf3c1  lea r14, [rax+0x21]
0000710a0d1cf3c5  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf3cb  pinsrb xmm15, r12d, 0x08
0000710a0d1cf3d2  lea r14, [rax+0x22]
0000710a0d1cf3d6  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf3dc  pinsrb xmm14, r12d, 0x08
0000710a0d1cf3e3  lea r14, [rax+0x23]
0000710a0d1cf3e7  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf3ed  pinsrb xmm13, r12d, 0x08
0000710a0d1cf3f4  lea r14, [rax+0x24]
0000710a0d1cf3f8  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf3fe  pinsrb xmm1, r12d, 0x09
0000710a0d1cf405  lea r14, [rax+0x25]
0000710a0d1cf409  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf40f  pinsrb xmm15, r12d, 0x09
0000710a0d1cf416  lea r14, [rax+0x26]
0000710a0d1cf41a  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf420  pinsrb xmm14, r12d, 0x09
0000710a0d1cf427  lea r14, [rax+0x27]
0000710a0d1cf42b  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf431  pinsrb xmm13, r12d, 0x09
0000710a0d1cf438  lea r14, [rax+0x28]
0000710a0d1cf43c  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf442  pinsrb xmm1, r12d, 0x0A
0000710a0d1cf449  lea r14, [rax+0x29]
0000710a0d1cf44d  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf453  pinsrb xmm15, r12d, 0x0A
0000710a0d1cf45a  lea r14, [rax+0x2A]
0000710a0d1cf45e  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf464  pinsrb xmm14, r12d, 0x0A
0000710a0d1cf46b  lea r14, [rax+0x2B]
0000710a0d1cf46f  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf475  pinsrb xmm13, r12d, 0x0A
0000710a0d1cf47c  lea r14, [rax+0x2C]
0000710a0d1cf480  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf486  pinsrb xmm1, r12d, 0x0B
0000710a0d1cf48d  lea r14, [rax+0x2D]
0000710a0d1cf491  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf497  pinsrb xmm15, r12d, 0x0B
0000710a0d1cf49e  lea r14, [rax+0x2E]
0000710a0d1cf4a2  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf4a8  pinsrb xmm14, r12d, 0x0B
0000710a0d1cf4af  lea r14, [rax+0x2F]
0000710a0d1cf4b3  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf4b9  pinsrb xmm13, r12d, 0x0B
0000710a0d1cf4c0  lea r14, [rax+0x30]
0000710a0d1cf4c4  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf4ca  pinsrb xmm1, r12d, 0x0C
0000710a0d1cf4d1  lea r14, [rax+0x31]
0000710a0d1cf4d5  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf4db  pinsrb xmm15, r12d, 0x0C
0000710a0d1cf4e2  lea r14, [rax+0x32]
0000710a0d1cf4e6  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf4ec  pinsrb xmm14, r12d, 0x0C
0000710a0d1cf4f3  lea r14, [rax+0x33]
0000710a0d1cf4f7  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf4fd  pinsrb xmm13, r12d, 0x0C
0000710a0d1cf504  lea r14, [rax+0x34]
0000710a0d1cf508  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf50e  pinsrb xmm1, r12d, 0x0D
0000710a0d1cf515  lea r14, [rax+0x35]
0000710a0d1cf519  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf51f  pinsrb xmm15, r12d, 0x0D
0000710a0d1cf526  lea r14, [rax+0x36]
0000710a0d1cf52a  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf530  pinsrb xmm14, r12d, 0x0D
0000710a0d1cf537  lea r14, [rax+0x37]
0000710a0d1cf53b  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf541  pinsrb xmm13, r12d, 0x0D
0000710a0d1cf548  lea r14, [rax+0x38]
0000710a0d1cf54c  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf552  pinsrb xmm1, r12d, 0x0E
0000710a0d1cf559  lea r14, [rax+0x39]
0000710a0d1cf55d  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf563  pinsrb xmm15, r12d, 0x0E
0000710a0d1cf56a  lea r14, [rax+0x3A]
0000710a0d1cf56e  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf574  pinsrb xmm14, r12d, 0x0E
0000710a0d1cf57b  lea r14, [rax+0x3B]
0000710a0d1cf57f  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf585  pinsrb xmm13, r12d, 0x0E
0000710a0d1cf58c  lea r14, [rax+0x3C]
0000710a0d1cf590  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf596  pinsrb xmm1, r12d, 0x0F
0000710a0d1cf59d  movaps [r15+0x110], xmm1
0000710a0d1cf5a5  lea r14, [rax+0x3D]
0000710a0d1cf5a9  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf5af  pinsrb xmm15, r12d, 0x0F
0000710a0d1cf5b6  movaps [r15+0x120], xmm15
0000710a0d1cf5be  lea r14, [rax+0x3E]
0000710a0d1cf5c2  movzx r12d, byte ptr [r13+r14*1]
0000710a0d1cf5c8  pinsrb xmm14, r12d, 0x0F
0000710a0d1cf5cf  movaps [r15+0x130], xmm14
0000710a0d1cf5d7  lea r14, [rax+0x3F]
0000710a0d1cf5db  movzx eax, byte ptr [r13+r14*1]
0000710a0d1cf5e1  pinsrb xmm13, eax, 0x0F
0000710a0d1cf5e8  movaps [r15+0x140], xmm13
0000710a0d1cf5f0  movq xmm1, qword ptr [r15+0x120]
0000710a0d1cf5f9  pmovzxbw xmm1, xmm1
0000710a0d1cf5fe  psllw xmm1, 0x00
0000710a0d1cf603  movaps [r15+0x150], xmm1
0000710a0d1cf60b  movq xmm1, qword ptr [r15+0x130]
0000710a0d1cf614  pmovzxbw xmm1, xmm1
0000710a0d1cf619  psllw xmm1, 0x00
0000710a0d1cf61e  movaps [r15+0x160], xmm1
0000710a0d1cf626  movq xmm1, qword ptr [r15+0x110]
0000710a0d1cf62f  pmovzxbw xmm1, xmm1
0000710a0d1cf634  psllw xmm1, 0x00
0000710a0d1cf639  movaps [r15+0x170], xmm1
0000710a0d1cf641  movaps xmm15, [r15+0x110]
0000710a0d1cf649  pextrq rax, xmm15, 0x01
0000710a0d1cf650  movq xmm15, rax
0000710a0d1cf655  pmovzxbw xmm15, xmm15
0000710a0d1cf65b  psllw xmm15, 0x00
0000710a0d1cf661  movaps [r15+0x180], xmm15
0000710a0d1cf669  movaps xmm14, [r15+0x120]
0000710a0d1cf671  pextrq rax, xmm14, 0x01
0000710a0d1cf678  movq xmm14, rax
0000710a0d1cf67d  pmovzxbw xmm14, xmm14
0000710a0d1cf683  psllw xmm14, 0x00
0000710a0d1cf689  movaps [r15+0x210], xmm14
0000710a0d1cf691  movaps xmm13, [r15+0x130]
0000710a0d1cf699  pextrq rax, xmm13, 0x01
0000710a0d1cf6a0  movq xmm13, rax
0000710a0d1cf6a5  pmovzxbw xmm13, xmm13
0000710a0d1cf6ab  psllw xmm13, 0x00
0000710a0d1cf6b1  movaps [r15+0x220], xmm13
0000710a0d1cf6b9  movq xmm12, qword ptr [r15+0x140]
0000710a0d1cf6c2  pmovzxbw xmm12, xmm12
0000710a0d1cf6c8  psllw xmm12, 0x00
0000710a0d1cf6ce  movaps [r15+0x250], xmm12
0000710a0d1cf6d6  movaps xmm12, [r15+0x140]
0000710a0d1cf6de  pextrq rax, xmm12, 0x01
0000710a0d1cf6e5  movq xmm12, rax
0000710a0d1cf6ea  pmovzxbw xmm12, xmm12
0000710a0d1cf6f0  psllw xmm12, 0x00
0000710a0d1cf6f6  movaps [r15+0x110], xmm12
0000710a0d1cf6fe  movq xmm11, qword ptr [r15+0x150]
0000710a0d1cf707  pmovzxwd xmm11, xmm11
0000710a0d1cf70d  pslld xmm11, 0x10
0000710a0d1cf713  movq xmm10, qword ptr [r15+0x160]
0000710a0d1cf71c  pmovzxwd xmm10, xmm10
0000710a0d1cf722  pslld xmm10, 0x08
0000710a0d1cf728  pextrq rax, xmm1, 0x01
0000710a0d1cf72f  movq xmm1, rax
0000710a0d1cf734  pmovzxwd xmm1, xmm1
0000710a0d1cf739  pslld xmm1, 0x00
0000710a0d1cf73e  movaps [r15+0x260], xmm1
0000710a0d1cf746  pextrq rax, xmm15, 0x01
0000710a0d1cf74d  movq xmm15, rax
0000710a0d1cf752  pmovzxwd xmm15, xmm15
0000710a0d1cf758  pslld xmm15, 0x00
0000710a0d1cf75e  movaps [r15+0x270], xmm15
0000710a0d1cf766  movq xmm9, qword ptr [r15+0x170]
0000710a0d1cf76f  pmovzxwd xmm9, xmm9
0000710a0d1cf775  pslld xmm9, 0x00
0000710a0d1cf77b  pextrq rax, xmm14, 0x01
0000710a0d1cf782  movq xmm14, rax
0000710a0d1cf787  pmovzxwd xmm14, xmm14
0000710a0d1cf78d  pslld xmm14, 0x10
0000710a0d1cf793  movaps [r15+0x280], xmm14
0000710a0d1cf79b  movq xmm8, qword ptr [r15+0x180]
0000710a0d1cf7a4  pmovzxwd xmm8, xmm8
0000710a0d1cf7aa  pslld xmm8, 0x00
0000710a0d1cf7b0  movq xmm7, qword ptr [r15+0x210]
0000710a0d1cf7b9  pmovzxwd xmm7, xmm7
0000710a0d1cf7be  pslld xmm7, 0x10
0000710a0d1cf7c3  movaps xmm6, [r15+0x150]
0000710a0d1cf7cb  pextrq rax, xmm6, 0x01
0000710a0d1cf7d2  movq xmm6, rax
0000710a0d1cf7d7  pmovzxwd xmm6, xmm6
0000710a0d1cf7dc  pslld xmm6, 0x10
0000710a0d1cf7e1  por xmm11, xmm10
0000710a0d1cf7e6  movaps [r15+0x230], xmm11
0000710a0d1cf7ee  pextrq rax, xmm13, 0x01
0000710a0d1cf7f5  movq xmm13, rax
0000710a0d1cf7fa  pmovzxwd xmm13, xmm13
0000710a0d1cf800  pslld xmm13, 0x08
0000710a0d1cf806  movaps [r15+0x240], xmm13
0000710a0d1cf80e  movq xmm10, qword ptr [r15+0x220]
0000710a0d1cf817  pmovzxwd xmm10, xmm10
0000710a0d1cf81d  pslld xmm10, 0x08
0000710a0d1cf823  movaps xmm5, [r15+0x160]
0000710a0d1cf82b  pextrq rax, xmm5, 0x01
0000710a0d1cf832  movq xmm5, rax
0000710a0d1cf837  pmovzxwd xmm5, xmm5
0000710a0d1cf83c  pslld xmm5, 0x08
0000710a0d1cf841  pslld xmm9, 0x18
0000710a0d1cf847  pslld xmm15, 0x18
0000710a0d1cf84d  pslld xmm8, 0x18
0000710a0d1cf853  movq xmm4, qword ptr [r15+0x250]
0000710a0d1cf85c  pmovzxwd xmm4, xmm4
0000710a0d1cf861  pslld xmm4, 0x00
0000710a0d1cf866  por xmm14, xmm13
0000710a0d1cf86b  por xmm7, xmm10
0000710a0d1cf870  movaps [r15+0x210], xmm7
0000710a0d1cf878  pslld xmm1, 0x18
0000710a0d1cf87d  movaps [r15+0x220], xmm1
0000710a0d1cf885  por xmm6, xmm5
0000710a0d1cf889  por xmm11, xmm9
0000710a0d1cf88e  movaps [r15+0x160], xmm11
0000710a0d1cf896  pextrq rax, xmm12, 0x01
0000710a0d1cf89d  movq xmm13, rax
0000710a0d1cf8a2  pmovzxwd xmm13, xmm13
0000710a0d1cf8a8  pslld xmm13, 0x00
0000710a0d1cf8ae  movaps [r15+0x170], xmm13
0000710a0d1cf8b6  movq xmm12, qword ptr [r15+0x110]
0000710a0d1cf8bf  pmovzxwd xmm12, xmm12
0000710a0d1cf8c5  pslld xmm12, 0x00
0000710a0d1cf8cb  por xmm14, xmm15
0000710a0d1cf8d0  por xmm7, xmm8
0000710a0d1cf8d5  movaps xmm15, [r15+0x250]
0000710a0d1cf8dd  pextrq rax, xmm15, 0x01
0000710a0d1cf8e4  movq xmm15, rax
0000710a0d1cf8e9  pmovzxwd xmm15, xmm15
0000710a0d1cf8ef  pslld xmm15, 0x00
0000710a0d1cf8f5  movaps [r15+0x180], xmm15
0000710a0d1cf8fd  por xmm6, xmm1
0000710a0d1cf901  movaps [r15+0x150], xmm6
0000710a0d1cf909  por xmm11, xmm4
0000710a0d1cf90e  movaps [r15+0x140], xmm11
0000710a0d1cf916  por xmm7, xmm12
0000710a0d1cf91b  movaps [r15+0x110], xmm7
0000710a0d1cf923  por xmm14, xmm13
0000710a0d1cf928  movaps [r15+0x120], xmm14
0000710a0d1cf930  por xmm6, xmm15
0000710a0d1cf935  movaps [r15+0x130], xmm6
0000710a0d1cf93d  mov rax, [r15+0xF8]
0000710a0d1cf944  lea r14, [rax+0x20]
0000710a0d1cf948  movups [r13+r14*1], xmm7
0000710a0d1cf94e  lea r14, [rax+0x30]
0000710a0d1cf952  movups [r13+r14*1], xmm14
0000710a0d1cf958  movups [r13+rax*1], xmm11
0000710a0d1cf95e  lea r14, [rax+0x10]
0000710a0d1cf962  movups [r13+r14*1], xmm6
0000710a0d1cf968  mov r14d, [r13+rax*1]
0000710a0d1cf96d  mov rax, [r15+0x48]
0000710a0d1cf971  mov [r15+0x68], rax
0000710a0d1cf975  mov qword ptr [r15+0x58], 0x04
0000710a0d1cf97d  lea r12, [rax+0x04]
0000710a0d1cf981  mov r11d, [r13+r12*1]
0000710a0d1cf986  mov [rsp+0x10], r11d
0000710a0d1cf98b  mov r11d, r11d
0000710a0d1cf98e  mov [r15+0x70], r11
0000710a0d1cf992  lea r12, [rax+0x38]
0000710a0d1cf996  mov r11d, [r13+r12*1]
0000710a0d1cf99b  lea r12, [rax+0x24]
0000710a0d1cf99f  mov r10d, [r13+r12*1]
0000710a0d1cf9a4  mov [rsp+0x20], r10d
0000710a0d1cf9a9  mov r10d, r10d
0000710a0d1cf9ac  mov [r15+0x90], r10
0000710a0d1cf9b3  mov [rsp+0x30], rax
0000710a0d1cf9b8  xor eax, eax
0000710a0d1cf9ba  mov r12d, 0x04
0000710a0d1cf9c0  mov r10d, 0xC0
0000710a0d1cf9c6  cmp r12, r10
0000710a0d1cf9c9  cmc
0000710a0d1cf9ca  lahf
0000710a0d1cf9cb  seto al
0000710a0d1cf9ce  mov [r15+0x108], eax
0000710a0d1cf9d5  mov eax, [rsp+0x10]
0000710a0d1cf9d9  mov r12d, [rsp+0x10]
0000710a0d1cf9de  shrd eax, r12d, 0x07
0000710a0d1cf9e3  mov [rsp+0x10], r11d
0000710a0d1cf9e8  mov r10d, [rsp+0x10]
0000710a0d1cf9ed  shrd r11d, r10d, 0x11
0000710a0d1cf9f2  mov r9d, [rsp+0x20]
0000710a0d1cf9f7  lea r8d, [r9d+r14d*1]
0000710a0d1cf9fc  rorx r14d, r12d, 0x12
0000710a0d1cfa02  xor eax, r14d
0000710a0d1cfa05  rorx r14d, r10d, 0x13
0000710a0d1cfa0b  xor r11d, r14d
0000710a0d1cfa0e  mov [rsp+0x10], r11d
0000710a0d1cfa13  mov r11d, r11d
0000710a0d1cfa16  mov [r15+0x88], r11
0000710a0d1cfa1d  mov [rsp+0x20], r12d
0000710a0d1cfa22  shr r12d, 0x03
0000710a0d1cfa26  xor eax, r12d
0000710a0d1cfa29  mov [rsp+0x40], eax
0000710a0d1cfa2d  mov eax, eax
0000710a0d1cfa2f  mov [r15+0x80], rax
0000710a0d1cfa36  shr r10d, 0x0A
0000710a0d1cfa3a  mov eax, [rsp+0x10]
0000710a0d1cfa3e  xor eax, r10d
0000710a0d1cfa41  mov [rsp+0x10], eax
0000710a0d1cfa45  mov eax, eax
0000710a0d1cfa47  mov [r15+0x78], rax
0000710a0d1cfa4b  mov eax, [rsp+0x40]
0000710a0d1cfa4f  lea r14d, [r8d+eax*1]
0000710a0d1cfa54  mov eax, [rsp+0x10]
0000710a0d1cfa58  lea r12d, [r14d+eax*1]
0000710a0d1cfa5d  mov rax, [rsp+0x30]
0000710a0d1cfa62  lea r14, [rax+0x40]
0000710a0d1cfa66  mov [r13+r14*1], r12d
0000710a0d1cfa6b  mov eax, [rsp+0x20]
0000710a0d1cfa6f  mov eax, eax
0000710a0d1cfa71  mov [r15+0x60], rax
0000710a0d1cfa75  mov eax, [r15+0x108]
0000710a0d1cfa7c  sahf
0000710a0d1cfa7d  jnz 0x0000710A0D1CFAAF
0000710a0d1cfa7f  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cfa87  jz 0x0000710A0D1CFF70
0000710a0d1cfa8d  nop [rax+rax*1], ax
0000710a0d1cfa96  nop [rax+rax*1], eax
0000710a0d1cfa9e  mov eax, 0x410820
0000710a0d1cfaa3  mov [r15+0x100], rax
0000710a0d1cfaaa  jmp 0x0000710A0CFFE110
0000710a0d1cfaaf  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cfab7  jz 0x0000710A0D1CFDC0
0000710a0d1cfabd  nop [rax+rax*1], ax
0000710a0d1cfac6  nop [rax+rax*1], eax
0000710a0d1cface  mov eax, 0x4107D8
0000710a0d1cfad3  mov [r15+0x100], rax
0000710a0d1cfada  jmp 0x0000710A0CFFE110
0000710a0d1cfadf  int3
0000710a0d1cfae0  call 0x0000710A0D00D860
0000710a0d1cfae5  jmp 0x0000710A0D1CF17A
0000710a0d1cfaea  call 0x0000710A0D0E2420
0000710a0d1cfaef  jmp 0x0000710A0D1CF193
0000710a0d1cfaf4  call 0x0000710A0D0E2420
0000710a0d1cfaf9  jmp 0x0000710A0D1CF1AC
0000710a0d1cfafe  call 0x0000710A0D0E2420
0000710a0d1cfb03  jmp 0x0000710A0D1CF1C5
0000710a0d1cfb08  call 0x0000710A0D0E2420
0000710a0d1cfb0d  jmp 0x0000710A0D1CF1DE
0000710a0d1cfb12  call 0x0000710A0D0E2420
0000710a0d1cfb17  jmp 0x0000710A0D1CF1EF
0000710a0d1cfb1c  call 0x0000710A0D0E2420
0000710a0d1cfb21  jmp 0x0000710A0D1CF200
0000710a0d1cfb26  call 0x0000710A0D0E2420
0000710a0d1cfb2b  jmp 0x0000710A0D1CF211
0000710a0d1cfb30  call 0x0000710A0D0E2420
0000710a0d1cfb35  jmp 0x0000710A0D1CF222
0000710a0d1cfb3a  call 0x0000710A0D0E2420
0000710a0d1cfb3f  jmp 0x0000710A0D1CF233
0000710a0d1cfb44  call 0x0000710A0D0E2420
0000710a0d1cfb49  jmp 0x0000710A0D1CF244
0000710a0d1cfb4e  call 0x0000710A0D0E2420
0000710a0d1cfb53  jmp 0x0000710A0D1CF255
0000710a0d1cfb58  call 0x0000710A0D0E2420
0000710a0d1cfb5d  jmp 0x0000710A0D1CF266
0000710a0d1cfb62  call 0x0000710A0D0E2420
0000710a0d1cfb67  jmp 0x0000710A0D1CF277
0000710a0d1cfb6c  call 0x0000710A0D0E2420
0000710a0d1cfb71  jmp 0x0000710A0D1CF288
0000710a0d1cfb76  call 0x0000710A0D0E2420
0000710a0d1cfb7b  jmp 0x0000710A0D1CF299
0000710a0d1cfb80  call 0x0000710A0D0E2420
0000710a0d1cfb85  jmp 0x0000710A0D1CF2AA
0000710a0d1cfb8a  call 0x0000710A0D0E2420
0000710a0d1cfb8f  jmp 0x0000710A0D1CF2BB
0000710a0d1cfb94  call 0x0000710A0D0E2420
0000710a0d1cfb99  jmp 0x0000710A0D1CF2CC
0000710a0d1cfb9e  call 0x0000710A0D0E2420
0000710a0d1cfba3  jmp 0x0000710A0D1CF2DD
0000710a0d1cfba8  call 0x0000710A0D0E2420
0000710a0d1cfbad  jmp 0x0000710A0D1CF2EE
0000710a0d1cfbb2  call 0x0000710A0D0E2420
0000710a0d1cfbb7  jmp 0x0000710A0D1CF2FF
0000710a0d1cfbbc  call 0x0000710A0D0E2420
0000710a0d1cfbc1  jmp 0x0000710A0D1CF310
0000710a0d1cfbc6  call 0x0000710A0D0E2420
0000710a0d1cfbcb  jmp 0x0000710A0D1CF321
0000710a0d1cfbd0  call 0x0000710A0D0E2420
0000710a0d1cfbd5  jmp 0x0000710A0D1CF332
0000710a0d1cfbda  call 0x0000710A0D0E2420
0000710a0d1cfbdf  jmp 0x0000710A0D1CF343
0000710a0d1cfbe4  call 0x0000710A0D0E2420
0000710a0d1cfbe9  jmp 0x0000710A0D1CF354
0000710a0d1cfbee  call 0x0000710A0D0E2420
0000710a0d1cfbf3  jmp 0x0000710A0D1CF365
0000710a0d1cfbf8  call 0x0000710A0D0E2420
0000710a0d1cfbfd  jmp 0x0000710A0D1CF376
0000710a0d1cfc02  call 0x0000710A0D0E2420
0000710a0d1cfc07  jmp 0x0000710A0D1CF387
0000710a0d1cfc0c  call 0x0000710A0D0E2420
0000710a0d1cfc11  jmp 0x0000710A0D1CF398
0000710a0d1cfc16  call 0x0000710A0D0E2420
0000710a0d1cfc1b  jmp 0x0000710A0D1CF3A9
0000710a0d1cfc20  call 0x0000710A0D0E2420
0000710a0d1cfc25  jmp 0x0000710A0D1CF3BA
0000710a0d1cfc2a  call 0x0000710A0D0E2420
0000710a0d1cfc2f  jmp 0x0000710A0D1CF3CB
0000710a0d1cfc34  call 0x0000710A0D0E2420
0000710a0d1cfc39  jmp 0x0000710A0D1CF3DC
0000710a0d1cfc3e  call 0x0000710A0D0E2420
0000710a0d1cfc43  jmp 0x0000710A0D1CF3ED
0000710a0d1cfc48  call 0x0000710A0D0E2420
0000710a0d1cfc4d  jmp 0x0000710A0D1CF3FE
0000710a0d1cfc52  call 0x0000710A0D0E2420
0000710a0d1cfc57  jmp 0x0000710A0D1CF40F
0000710a0d1cfc5c  call 0x0000710A0D0E2420
0000710a0d1cfc61  jmp 0x0000710A0D1CF420
0000710a0d1cfc66  call 0x0000710A0D0E2420
0000710a0d1cfc6b  jmp 0x0000710A0D1CF431
0000710a0d1cfc70  call 0x0000710A0D0E2420
0000710a0d1cfc75  jmp 0x0000710A0D1CF442
0000710a0d1cfc7a  call 0x0000710A0D0E2420
0000710a0d1cfc7f  jmp 0x0000710A0D1CF453
0000710a0d1cfc84  call 0x0000710A0D0E2420
0000710a0d1cfc89  jmp 0x0000710A0D1CF464
0000710a0d1cfc8e  call 0x0000710A0D0E2420
0000710a0d1cfc93  jmp 0x0000710A0D1CF475
0000710a0d1cfc98  call 0x0000710A0D0E2420
0000710a0d1cfc9d  jmp 0x0000710A0D1CF486
0000710a0d1cfca2  call 0x0000710A0D0E2420
0000710a0d1cfca7  jmp 0x0000710A0D1CF497
0000710a0d1cfcac  call 0x0000710A0D0E2420
0000710a0d1cfcb1  jmp 0x0000710A0D1CF4A8
0000710a0d1cfcb6  call 0x0000710A0D0E2420
0000710a0d1cfcbb  jmp 0x0000710A0D1CF4B9
0000710a0d1cfcc0  call 0x0000710A0D0E2420
0000710a0d1cfcc5  jmp 0x0000710A0D1CF4CA
0000710a0d1cfcca  call 0x0000710A0D0E2420
0000710a0d1cfccf  jmp 0x0000710A0D1CF4DB
0000710a0d1cfcd4  call 0x0000710A0D0E2420
0000710a0d1cfcd9  jmp 0x0000710A0D1CF4EC
0000710a0d1cfcde  call 0x0000710A0D0E2420
0000710a0d1cfce3  jmp 0x0000710A0D1CF4FD
0000710a0d1cfce8  call 0x0000710A0D0E2420
0000710a0d1cfced  jmp 0x0000710A0D1CF50E
0000710a0d1cfcf2  call 0x0000710A0D0E2420
0000710a0d1cfcf7  jmp 0x0000710A0D1CF51F
0000710a0d1cfcfc  call 0x0000710A0D0E2420
0000710a0d1cfd01  jmp 0x0000710A0D1CF530
0000710a0d1cfd06  call 0x0000710A0D0E2420
0000710a0d1cfd0b  jmp 0x0000710A0D1CF541
0000710a0d1cfd10  call 0x0000710A0D0E2420
0000710a0d1cfd15  jmp 0x0000710A0D1CF552
0000710a0d1cfd1a  call 0x0000710A0D0E2420
0000710a0d1cfd1f  jmp 0x0000710A0D1CF563
0000710a0d1cfd24  call 0x0000710A0D0E2420
0000710a0d1cfd29  jmp 0x0000710A0D1CF574
0000710a0d1cfd2e  call 0x0000710A0D0E2420
0000710a0d1cfd33  jmp 0x0000710A0D1CF585
0000710a0d1cfd38  call 0x0000710A0D0E2420
0000710a0d1cfd3d  jmp 0x0000710A0D1CF596
0000710a0d1cfd42  call 0x0000710A0D0E2420
0000710a0d1cfd47  jmp 0x0000710A0D1CF5AF
0000710a0d1cfd4c  call 0x0000710A0D0E2420
0000710a0d1cfd51  jmp 0x0000710A0D1CF5C8
0000710a0d1cfd56  call 0x0000710A0D0D5610
0000710a0d1cfd5b  jmp 0x0000710A0D1CF5E1
0000710a0d1cfd60  call 0x0000710A0D0DC580
0000710a0d1cfd65  jmp 0x0000710A0D1CF94E
0000710a0d1cfd6a  call 0x0000710A0D0E46C0
0000710a0d1cfd6f  jmp 0x0000710A0D1CF958
0000710a0d1cfd74  call 0x0000710A0D009E90
0000710a0d1cfd79  jmp 0x0000710A0D1CF95E
0000710a0d1cfd7e  call 0x0000710A0D0DB310
0000710a0d1cfd83  jmp 0x0000710A0D1CF968
0000710a0d1cfd88  call 0x0000710A0D00DAE0
0000710a0d1cfd8d  jmp 0x0000710A0D1CF96D
0000710a0d1cfd92  call 0x0000710A0D0C0230
0000710a0d1cfd97  jmp 0x0000710A0D1CF986
0000710a0d1cfd9c  call 0x0000710A0D0C0230
0000710a0d1cfda1  jmp 0x0000710A0D1CF99B
0000710a0d1cfda6  call 0x0000710A0D0BEFC0
0000710a0d1cfdab  jmp 0x0000710A0D1CF9A4
0000710a0d1cfdb0  call 0x0000710A0D0E2BA0
0000710a0d1cfdb5  jmp 0x0000710A0D1CFA6B
0000710a0d1cfdba  int3
0000710a0d1cfdbb  nop [rax+rax*1], eax
0000710a0d1cfdc0  mov rax, [r15+0x48]
0000710a0d1cfdc4  mov r14, [r15+0x58]
0000710a0d1cfdc8  lea r12, [rax+r14*1]
0000710a0d1cfdcc  mov [r15+0x68], r12
0000710a0d1cfdd0  lea rax, [r14+0x04]
0000710a0d1cfdd4  mov [r15+0x58], rax
0000710a0d1cfdd8  lea r14, [r12+0x04]
0000710a0d1cfddd  mov r11d, [r13+r14*1]
0000710a0d1cfde2  mov [rsp+0x10], r11d
0000710a0d1cfde7  mov r11d, r11d
0000710a0d1cfdea  mov [r15+0x70], r11
0000710a0d1cfdee  lea r14, [r12+0x38]
0000710a0d1cfdf3  mov r11d, [r13+r14*1]
0000710a0d1cfdf8  lea r14, [r12+0x24]
0000710a0d1cfdfd  mov r10d, [r13+r14*1]
0000710a0d1cfe02  mov [rsp+0x20], r10d
0000710a0d1cfe07  mov r10d, r10d
0000710a0d1cfe0a  mov [r15+0x90], r10
0000710a0d1cfe11  mov [rsp+0x30], rax
0000710a0d1cfe16  xor eax, eax
0000710a0d1cfe18  mov r14, [rsp+0x30]
0000710a0d1cfe1d  mov r10d, 0xC0
0000710a0d1cfe23  cmp r14, r10
0000710a0d1cfe26  cmc
0000710a0d1cfe27  lahf
0000710a0d1cfe28  seto al
0000710a0d1cfe2b  mov [r15+0x108], eax
0000710a0d1cfe32  mov eax, [rsp+0x10]
0000710a0d1cfe36  mov r14d, [rsp+0x10]
0000710a0d1cfe3b  shrd eax, r14d, 0x07
0000710a0d1cfe40  mov [rsp+0x10], r11d
0000710a0d1cfe45  mov r10d, [rsp+0x10]
0000710a0d1cfe4a  shrd r11d, r10d, 0x11
0000710a0d1cfe4f  mov r9d, [r15+0x60]
0000710a0d1cfe53  mov r8d, [rsp+0x20]
0000710a0d1cfe58  lea ebp, [r8d+r9d*1]
0000710a0d1cfe5d  rorx r9d, r14d, 0x12
0000710a0d1cfe63  xor eax, r9d
0000710a0d1cfe66  rorx r9d, r10d, 0x13
0000710a0d1cfe6c  xor r11d, r9d
0000710a0d1cfe6f  mov [rsp+0x10], r11d
0000710a0d1cfe74  mov r11d, r11d
0000710a0d1cfe77  mov [r15+0x88], r11
0000710a0d1cfe7e  mov [rsp+0x20], r14d
0000710a0d1cfe83  shr r14d, 0x03
0000710a0d1cfe87  xor eax, r14d
0000710a0d1cfe8a  mov [rsp+0x30], eax
0000710a0d1cfe8e  mov eax, eax
0000710a0d1cfe90  mov [r15+0x80], rax
0000710a0d1cfe97  shr r10d, 0x0A
0000710a0d1cfe9b  mov eax, [rsp+0x10]
0000710a0d1cfe9f  xor eax, r10d
0000710a0d1cfea2  mov [rsp+0x10], eax
0000710a0d1cfea6  mov eax, eax
0000710a0d1cfea8  mov [r15+0x78], rax
0000710a0d1cfeac  mov eax, [rsp+0x30]
0000710a0d1cfeb0  lea r14d, [ebp+eax*1]
0000710a0d1cfeb6  mov eax, [rsp+0x10]
0000710a0d1cfeba  lea r11d, [r14d+eax*1]
0000710a0d1cfebf  lea rax, [r12+0x40]
0000710a0d1cfec4  mov [r13+rax*1], r11d
0000710a0d1cfec9  mov eax, [rsp+0x20]
0000710a0d1cfecd  mov eax, eax
0000710a0d1cfecf  mov [r15+0x60], rax
0000710a0d1cfed3  mov eax, [r15+0x108]
0000710a0d1cfeda  sahf
0000710a0d1cfedb  jnz 0x0000710A0D1CFF0D
0000710a0d1cfedd  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cfee5  jz 0x0000710A0D1CFF70
0000710a0d1cfeeb  nop [rax+rax*1], ax
0000710a0d1cfef4  nop [rax+rax*1], eax
0000710a0d1cfefc  mov eax, 0x410820
0000710a0d1cff01  mov [r15+0x100], rax
0000710a0d1cff08  jmp 0x0000710A0CFFE110
0000710a0d1cff0d  cmp dword ptr [r15+0x318], 0x00
0000710a0d1cff15  jz 0x0000710A0D1CFDC0
0000710a0d1cff1b  nop [rax+rax*1], ax
0000710a0d1cff24  nop [rax+rax*1], eax
0000710a0d1cff2c  mov eax, 0x4107D8
0000710a0d1cff31  mov [r15+0x100], rax
0000710a0d1cff38  jmp 0x0000710A0CFFE110
0000710a0d1cff3d  int3
0000710a0d1cff3e  call 0x0000710A0D0E1430
0000710a0d1cff43  jmp 0x0000710A0D1CFDE2
0000710a0d1cff48  call 0x0000710A0D0E1430
0000710a0d1cff4d  jmp 0x0000710A0D1CFDF8
0000710a0d1cff52  call 0x0000710A0D0E01C0
0000710a0d1cff57  jmp 0x0000710A0D1CFE02
0000710a0d1cff5c  call 0x0000710A0D00A860
0000710a0d1cff61  jmp 0x0000710A0D1CFEC9
0000710a0d1cff66  int3
0000710a0d1cff67  nop [rax+rax*1], ax
0000710a0d1cff70  mov rax, [r15]
0000710a0d1cff73  mov r14d, [r13+rax*1]
0000710a0d1cff78  lea r12, [rax+0x04]
0000710a0d1cff7c  mov r11d, [r13+r12*1]
0000710a0d1cff81  mov [rsp+0x10], r14d
0000710a0d1cff86  mov r14d, r14d
0000710a0d1cff89  mov [r15+0x78], r14
0000710a0d1cff8d  mov [rsp+0x20], r11d
0000710a0d1cff92  mov r11d, r11d
0000710a0d1cff95  mov [r15+0x80], r11
0000710a0d1cff9c  lea r14, [rax+0x08]
0000710a0d1cffa0  mov r12d, [r13+r14*1]
0000710a0d1cffa5  lea r14, [rax+0x0C]
0000710a0d1cffa9  mov r11d, [r13+r14*1]
0000710a0d1cffae  mov [rsp+0x30], r12d
0000710a0d1cffb3  mov r12d, r12d
0000710a0d1cffb6  mov [r15+0x70], r12
0000710a0d1cffba  mov [rsp+0x40], r11d
0000710a0d1cffbf  mov r11d, r11d
0000710a0d1cffc2  mov [r15+0x68], r11
0000710a0d1cffc6  lea r14, [rax+0x18]
0000710a0d1cffca  mov r12d, [r13+r14*1]
0000710a0d1cffcf  lea r14, [rax+0x1C]
0000710a0d1cffd3  mov r11d, [r13+r14*1]
0000710a0d1cffd8  mov [rsp+0x50], r12d
0000710a0d1cffdd  mov r12d, r12d
0000710a0d1cffe0  mov [r15+0x58], r12
0000710a0d1cffe4  mov [rsp+0x60], r11d
0000710a0d1cffe9  mov r11d, r11d
0000710a0d1cffec  mov [r15+0x60], r11
0000710a0d1cfff0  lea r14, [rax+0x10]
0000710a0d1cfff4  mov r12d, [r13+r14*1]
0000710a0d1cfff9  lea r14, [rax+0x14]
0000710a0d1cfffd  mov eax, [r13+r14*1]
0000710a0d1d0002  mov [rsp+0x70], r12d
0000710a0d1d0007  mov r12d, r12d
0000710a0d1d000a  mov [r15+0x18], r12
0000710a0d1d000e  mov [rsp+0x80], eax
0000710a0d1d0015  mov eax, eax
0000710a0d1d0017  mov [r15+0x90], rax
0000710a0d1d001e  mov eax, [rsp+0x70]
0000710a0d1d0022  mov eax, eax
0000710a0d1d0024  mov [r15+0x30], rax
0000710a0d1d0028  mov eax, [rsp+0x50]
0000710a0d1d002c  mov eax, eax
0000710a0d1d002e  mov [r15+0xA0], rax
0000710a0d1d0035  mov eax, [rsp+0x30]
0000710a0d1d0039  mov eax, eax
0000710a0d1d003b  mov [r15+0x28], rax
0000710a0d1d003f  mov eax, [rsp+0x20]
0000710a0d1d0043  mov eax, eax
0000710a0d1d0045  mov [r15+0x98], rax
0000710a0d1d004c  mov eax, [rsp+0x10]
0000710a0d1d0050  mov eax, eax
0000710a0d1d0052  mov [r15+0x38], rax
0000710a0d1d0056  mov eax, [rsp+0x70]
0000710a0d1d005a  mov r14d, [rsp+0x70]
0000710a0d1d005f  shrd eax, r14d, 0x06
0000710a0d1d0064  mov [rsp+0x70], r14d
0000710a0d1d0069  mov r12d, [rsp+0x80]
0000710a0d1d0071  and r14d, r12d
0000710a0d1d0074  mov r11d, [rsp+0x10]
0000710a0d1d0079  mov r10d, [rsp+0x10]
0000710a0d1d007e  shrd r11d, r10d, 0x02
0000710a0d1d0083  mov [rsp+0x10], r12d
0000710a0d1d0088  mov r12d, r12d
0000710a0d1d008b  mov [r15+0x20], r12
0000710a0d1d008f  mov r12, [r15+0x50]
0000710a0d1d0093  mov r9d, [r13+r12*1]
0000710a0d1d0098  mov r12d, [rsp+0x50]
0000710a0d1d009d  mov r8d, [rsp+0x70]
0000710a0d1d00a2  andn ebp, r8d, r12d
0000710a0d1d00a7  mov edi, [rsp+0x60]
0000710a0d1d00ab  lea esi, [r14d+edi*1]
0000710a0d1d00b0  rorx r14d, r8d, 0x0B
0000710a0d1d00b6  xor eax, r14d
0000710a0d1d00b9  rorx r14d, r10d, 0x0D
0000710a0d1d00bf  xor r11d, r14d
0000710a0d1d00c2  lea edi, [esi+ebp*1]
0000710a0d1d00c6  mov r14, [r15+0x48]
0000710a0d1d00ca  mov ebp, [r13+r14*1]
0000710a0d1d00cf  mov r14d, [rsp+0x30]
0000710a0d1d00d4  mov esi, [rsp+0x20]
0000710a0d1d00d8  and r14d, esi
0000710a0d1d00db  mov [rsp+0x20], r14d
0000710a0d1d00e0  mov r14d, r14d
0000710a0d1d00e3  mov [r15+0xD8], r14
0000710a0d1d00ea  lea r14d, [edi+r9d*1]
0000710a0d1d00ef  mov r9d, [rsp+0x30]
0000710a0d1d00f4  xor r9d, esi
0000710a0d1d00f7  rorx edi, r8d, 0x19
0000710a0d1d00fd  xor eax, edi
0000710a0d1d00ff  and r9d, r10d
0000710a0d1d0102  rorx edi, r10d, 0x16
0000710a0d1d0108  xor r11d, edi
0000710a0d1d010b  mov [rsp+0x30], r11d
0000710a0d1d0110  mov r11d, r11d
0000710a0d1d0113  mov [r15+0xD0], r11
0000710a0d1d011a  lea r11d, [r14d+ebp*1]
0000710a0d1d011f  mov r10d, [rsp+0x20]
0000710a0d1d0124  xor r9d, r10d
0000710a0d1d0127  lea r14d, [r11d+eax*1]
0000710a0d1d012c  mov qword ptr [r15+0x88], 0x04
0000710a0d1d0137  mov eax, [rsp+0x30]
0000710a0d1d013b  lea r11d, [r9d+eax*1]
0000710a0d1d0140  mov eax, [rsp+0x40]
0000710a0d1d0144  lea r10d, [r14d+eax*1]
0000710a0d1d0149  mov r10d, r10d
0000710a0d1d014c  mov [r15+0xB8], r10
0000710a0d1d0153  xor eax, eax
0000710a0d1d0155  mov r10d, 0x04
0000710a0d1d015b  mov r9d, 0x100
0000710a0d1d0161  cmp r10, r9
0000710a0d1d0164  cmc
0000710a0d1d0165  lahf
0000710a0d1d0166  seto al
0000710a0d1d0169  mov [r15+0x108], eax
0000710a0d1d0170  lea eax, [r11d+r14d*1]
0000710a0d1d0175  mov eax, eax
0000710a0d1d0177  mov [r15+0xA8], rax
0000710a0d1d017e  mov r12d, r12d
0000710a0d1d0181  mov [r15+0xB0], r12
0000710a0d1d0188  mov eax, [rsp+0x10]
0000710a0d1d018c  mov eax, eax
0000710a0d1d018e  mov [r15+0xC0], rax
0000710a0d1d0195  mov r8d, r8d
0000710a0d1d0198  mov [r15+0xC8], r8
0000710a0d1d019f  mov eax, [r15+0x108]
0000710a0d1d01a6  sahf
0000710a0d1d01a7  jnz 0x0000710A0D1D01D9
0000710a0d1d01a9  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d01b1  jz 0x0000710A0D1D04A0
0000710a0d1d01b7  nop [rax+rax*1], ax
0000710a0d1d01c0  nop [rax+rax*1], eax
0000710a0d1d01c8  mov eax, 0x4108E0
0000710a0d1d01cd  mov [r15+0x100], rax
0000710a0d1d01d4  jmp 0x0000710A0CFFE110
0000710a0d1d01d9  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d01e1  jz 0x0000710A0D1D0270
0000710a0d1d01e7  nop [rax+rax*1], ax
0000710a0d1d01f0  nop [rax+rax*1], eax
0000710a0d1d01f8  mov eax, 0x410854
0000710a0d1d01fd  mov [r15+0x100], rax
0000710a0d1d0204  jmp 0x0000710A0CFFE110
0000710a0d1d0209  int3
0000710a0d1d020a  call 0x0000710A0D00DAE0
0000710a0d1d020f  jmp 0x0000710A0D1CFF78
0000710a0d1d0214  call 0x0000710A0D0C0230
0000710a0d1d0219  jmp 0x0000710A0D1CFF81
0000710a0d1d021e  call 0x0000710A0D0E26A0
0000710a0d1d0223  jmp 0x0000710A0D1CFFA5
0000710a0d1d0228  call 0x0000710A0D0E1430
0000710a0d1d022d  jmp 0x0000710A0D1CFFAE
0000710a0d1d0232  call 0x0000710A0D0E26A0
0000710a0d1d0237  jmp 0x0000710A0D1CFFCF
0000710a0d1d023c  call 0x0000710A0D0E1430
0000710a0d1d0241  jmp 0x0000710A0D1CFFD8
0000710a0d1d0246  call 0x0000710A0D0E26A0
0000710a0d1d024b  jmp 0x0000710A0D1CFFF9
0000710a0d1d0250  call 0x0000710A0D0D5890
0000710a0d1d0255  jmp 0x0000710A0D1D0002
0000710a0d1d025a  call 0x0000710A0D0BDD50
0000710a0d1d025f  jmp 0x0000710A0D1D0098
0000710a0d1d0264  call 0x0000710A0D0DA580
0000710a0d1d0269  jmp 0x0000710A0D1D00CF
0000710a0d1d026e  int3
0000710a0d1d026f  nop
0000710a0d1d0270  mov eax, [r15+0xB8]
0000710a0d1d0277  mov [rsp+0x10], eax
0000710a0d1d027b  mov eax, eax
0000710a0d1d027d  mov [r15+0x30], rax
0000710a0d1d0281  mov eax, [r15+0xC0]
0000710a0d1d0288  mov [rsp+0x20], eax
0000710a0d1d028c  mov eax, eax
0000710a0d1d028e  mov [r15+0xA0], rax
0000710a0d1d0295  mov eax, [r15+0x28]
0000710a0d1d0299  mov r14d, [r15+0x98]
0000710a0d1d02a0  mov [rsp+0x30], r14d
0000710a0d1d02a5  mov r14d, r14d
0000710a0d1d02a8  mov [r15+0x28], r14
0000710a0d1d02ac  mov r14d, [r15+0x38]
0000710a0d1d02b0  mov [rsp+0x40], r14d
0000710a0d1d02b5  mov r14d, r14d
0000710a0d1d02b8  mov [r15+0x98], r14
0000710a0d1d02bf  mov r14d, [r15+0xA8]
0000710a0d1d02c6  mov [rsp+0x50], r14d
0000710a0d1d02cb  mov r14d, r14d
0000710a0d1d02ce  mov [r15+0x38], r14
0000710a0d1d02d2  mov r14d, [rsp+0x10]
0000710a0d1d02d7  mov r12d, [rsp+0x10]
0000710a0d1d02dc  shrd r14d, r12d, 0x06
0000710a0d1d02e1  mov r11d, [r15+0xC8]
0000710a0d1d02e8  mov [rsp+0x10], r12d
0000710a0d1d02ed  and r12d, r11d
0000710a0d1d02f0  mov r10d, [rsp+0x50]
0000710a0d1d02f5  mov r9d, [rsp+0x50]
0000710a0d1d02fa  shrd r10d, r9d, 0x02
0000710a0d1d02ff  mov [rsp+0x50], r11d
0000710a0d1d0304  mov r11d, r11d
0000710a0d1d0307  mov [r15+0x20], r11
0000710a0d1d030b  mov r11, [r15+0x88]
0000710a0d1d0312  mov r8, [r15+0x50]
0000710a0d1d0316  lea rbp, [r8+r11*1]
0000710a0d1d031a  mov r8d, [r13+rbp*1]
0000710a0d1d031f  mov ebp, [rsp+0x20]
0000710a0d1d0323  mov edi, [rsp+0x10]
0000710a0d1d0327  andn esi, edi, ebp
0000710a0d1d032c  mov edx, [r15+0xB0]
0000710a0d1d0333  lea ecx, [r12d+edx*1]
0000710a0d1d0338  rorx r12d, edi, 0x0B
0000710a0d1d033e  xor r14d, r12d
0000710a0d1d0341  rorx r12d, r9d, 0x0D
0000710a0d1d0347  xor r10d, r12d
0000710a0d1d034a  lea r12d, [ecx+esi*1]
0000710a0d1d034f  mov rsi, [r15+0x48]
0000710a0d1d0353  lea rdx, [rsi+r11*1]
0000710a0d1d0357  mov esi, [r13+rdx*1]
0000710a0d1d035c  mov edx, [rsp+0x30]
0000710a0d1d0360  mov ecx, [rsp+0x40]
0000710a0d1d0364  and edx, ecx
0000710a0d1d0366  mov [rsp+0x10], edx
0000710a0d1d036a  mov edx, edx
0000710a0d1d036c  mov [r15+0xD8], rdx
0000710a0d1d0373  lea edx, [r12d+r8d*1]
0000710a0d1d0378  mov r12d, [rsp+0x30]
0000710a0d1d037d  xor r12d, ecx
0000710a0d1d0380  rorx r8d, edi, 0x19
0000710a0d1d0386  xor r14d, r8d
0000710a0d1d0389  and r12d, r9d
0000710a0d1d038c  rorx r8d, r9d, 0x16
0000710a0d1d0392  xor r10d, r8d
0000710a0d1d0395  mov [rsp+0x20], r10d
0000710a0d1d039a  mov r10d, r10d
0000710a0d1d039d  mov [r15+0xD0], r10
0000710a0d1d03a4  lea r10d, [edx+esi*1]
0000710a0d1d03a9  mov r9d, [rsp+0x10]
0000710a0d1d03ae  xor r12d, r9d
0000710a0d1d03b1  lea r9d, [r10d+r14d*1]
0000710a0d1d03b6  lea r14, [r11+0x04]
0000710a0d1d03ba  mov [r15+0x88], r14
0000710a0d1d03c1  mov r11d, [rsp+0x20]
0000710a0d1d03c6  lea r10d, [r12d+r11d*1]
0000710a0d1d03cb  lea r11d, [r9d+eax*1]
0000710a0d1d03d0  mov r11d, r11d
0000710a0d1d03d3  mov [r15+0xB8], r11
0000710a0d1d03da  xor eax, eax
0000710a0d1d03dc  mov r12d, 0x100
0000710a0d1d03e2  cmp r14, r12
0000710a0d1d03e5  cmc
0000710a0d1d03e6  lahf
0000710a0d1d03e7  seto al
0000710a0d1d03ea  mov [r15+0x108], eax
0000710a0d1d03f1  lea eax, [r10d+r9d*1]
0000710a0d1d03f6  mov eax, eax
0000710a0d1d03f8  mov [r15+0xA8], rax
0000710a0d1d03ff  mov ebp, ebp
0000710a0d1d0401  mov [r15+0xB0], rbp
0000710a0d1d0408  mov eax, [rsp+0x50]
0000710a0d1d040c  mov eax, eax
0000710a0d1d040e  mov [r15+0xC0], rax
0000710a0d1d0415  mov edi, edi
0000710a0d1d0417  mov [r15+0xC8], rdi
0000710a0d1d041e  mov eax, [r15+0x108]
0000710a0d1d0425  sahf
0000710a0d1d0426  jnz 0x0000710A0D1D0458
0000710a0d1d0428  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0430  jz 0x0000710A0D1D04A0
0000710a0d1d0436  nop [rax+rax*1], ax
0000710a0d1d043f  nop [rax+rax*1], eax
0000710a0d1d0447  mov eax, 0x4108E0
0000710a0d1d044c  mov [r15+0x100], rax
0000710a0d1d0453  jmp 0x0000710A0CFFE110
0000710a0d1d0458  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0460  jz 0x0000710A0D1D0270
0000710a0d1d0466  nop [rax+rax*1], ax
0000710a0d1d046f  nop [rax+rax*1], eax
0000710a0d1d0477  mov eax, 0x410854
0000710a0d1d047c  mov [r15+0x100], rax
0000710a0d1d0483  jmp 0x0000710A0CFFE110
0000710a0d1d0488  int3
0000710a0d1d0489  call 0x0000710A0D049010
0000710a0d1d048e  jmp 0x0000710A0D1D031F
0000710a0d1d0493  call 0x0000710A0D025930
0000710a0d1d0498  jmp 0x0000710A0D1D035C
0000710a0d1d049d  int3
0000710a0d1d049e  nop
0000710a0d1d04a0  mov eax, [r15+0x98]
0000710a0d1d04a7  mov r14d, [r15+0x70]
0000710a0d1d04ab  lea r12d, [eax+r14d*1]
0000710a0d1d04b0  mov eax, [r15+0x28]
0000710a0d1d04b4  mov r14d, [r15+0x68]
0000710a0d1d04b8  lea r11d, [eax+r14d*1]
0000710a0d1d04bd  mov qword ptr [r15+0x88], 0x00
0000710a0d1d04c8  mov eax, [r15+0xA8]
0000710a0d1d04cf  mov r14d, [r15+0x78]
0000710a0d1d04d3  lea r10d, [eax+r14d*1]
0000710a0d1d04d8  mov [rsp+0x10], r10d
0000710a0d1d04dd  mov r10d, r10d
0000710a0d1d04e0  mov [r15+0x78], r10
0000710a0d1d04e4  mov eax, [r15+0x38]
0000710a0d1d04e8  mov r14d, [r15+0x80]
0000710a0d1d04ef  lea r10d, [eax+r14d*1]
0000710a0d1d04f4  mov [rsp+0x20], r10d
0000710a0d1d04f9  mov r10d, r10d
0000710a0d1d04fc  mov [r15+0x80], r10
0000710a0d1d0503  mov rax, [r15]
0000710a0d1d0506  lea r14, [rax+0x08]
0000710a0d1d050a  mov [r13+r14*1], r12d
0000710a0d1d050f  lea r14, [rax+0x0C]
0000710a0d1d0513  mov [r13+r14*1], r11d
0000710a0d1d0518  mov r14d, [r15+0xB8]
0000710a0d1d051f  mov r12d, [r15+0x18]
0000710a0d1d0523  lea r11d, [r14d+r12d*1]
0000710a0d1d0528  mov [rsp+0x30], r11d
0000710a0d1d052d  mov r11d, r11d
0000710a0d1d0530  mov [r15+0x68], r11
0000710a0d1d0534  mov r14d, [r15+0x30]
0000710a0d1d0538  mov r12d, [r15+0x90]
0000710a0d1d053f  lea r11d, [r14d+r12d*1]
0000710a0d1d0544  mov [rsp+0x40], r11d
0000710a0d1d0549  mov r11d, r11d
0000710a0d1d054c  mov [r15+0x70], r11
0000710a0d1d0550  mov r14d, [r15+0x20]
0000710a0d1d0554  mov r12d, [r15+0x58]
0000710a0d1d0558  lea r11d, [r14d+r12d*1]
0000710a0d1d055d  mov [rsp+0x50], r11d
0000710a0d1d0562  mov r11d, r11d
0000710a0d1d0565  mov [r15+0x58], r11
0000710a0d1d0569  mov r14d, [r15+0xA0]
0000710a0d1d0570  mov r12d, [r15+0x60]
0000710a0d1d0574  lea r11d, [r14d+r12d*1]
0000710a0d1d0579  mov [rsp+0x60], r11d
0000710a0d1d057e  mov r11d, r11d
0000710a0d1d0581  mov [r15+0x60], r11
0000710a0d1d0585  mov r14d, [rsp+0x10]
0000710a0d1d058a  mov [r13+rax*1], r14d
0000710a0d1d058f  lea r14, [rax+0x04]
0000710a0d1d0593  mov r12d, [rsp+0x20]
0000710a0d1d0598  mov [r13+r14*1], r12d
0000710a0d1d059d  lea r14, [rax+0x10]
0000710a0d1d05a1  mov r12d, [rsp+0x30]
0000710a0d1d05a6  mov [r13+r14*1], r12d
0000710a0d1d05ab  lea r14, [rax+0x14]
0000710a0d1d05af  mov r12d, [rsp+0x40]
0000710a0d1d05b4  mov [r13+r14*1], r12d
0000710a0d1d05b9  lea r14, [rax+0x18]
0000710a0d1d05bd  mov r12d, [rsp+0x50]
0000710a0d1d05c2  mov [r13+r14*1], r12d
0000710a0d1d05c7  lea r14, [rax+0x1C]
0000710a0d1d05cb  mov r12d, [rsp+0x60]
0000710a0d1d05d0  mov [r13+r14*1], r12d
0000710a0d1d05d5  lea r14, [rax+0x68]
0000710a0d1d05d9  xor eax, eax
0000710a0d1d05db  mov [r13+r14*1], rax
0000710a0d1d05e0  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d05e8  jz 0x0000710A0D1CF0E0
0000710a0d1d05ee  nop [rax+rax*1], ax
0000710a0d1d05f7  nop [rax+rax*1], eax
0000710a0d1d05ff  mov eax, 0x4106FC
0000710a0d1d0604  mov [r15+0x100], rax
0000710a0d1d060b  jmp 0x0000710A0CFFE110
0000710a0d1d0610  int3
0000710a0d1d0611  call 0x0000710A0D0E2BA0
0000710a0d1d0616  jmp 0x0000710A0D1D050F
0000710a0d1d061b  call 0x0000710A0D0E1920
0000710a0d1d0620  jmp 0x0000710A0D1D0518
0000710a0d1d0625  call 0x0000710A0D00DFE0
0000710a0d1d062a  jmp 0x0000710A0D1D058F
0000710a0d1d062f  call 0x0000710A0D0E2BA0
0000710a0d1d0634  jmp 0x0000710A0D1D059D
0000710a0d1d0639  call 0x0000710A0D0E2BA0
0000710a0d1d063e  jmp 0x0000710A0D1D05AB
0000710a0d1d0643  call 0x0000710A0D0E2BA0
0000710a0d1d0648  jmp 0x0000710A0D1D05B9
0000710a0d1d064d  call 0x0000710A0D0E2BA0
0000710a0d1d0652  jmp 0x0000710A0D1D05C7
0000710a0d1d0657  call 0x0000710A0D0E2BA0
0000710a0d1d065c  jmp 0x0000710A0D1D05D5
0000710a0d1d0661  call 0x0000710A0D0D5EB0
0000710a0d1d0666  jmp 0x0000710A0D1D05E0
0000710a0d1d066b  int3
0000710a0d1d066c  nop [rax], eax
0000710a0d1d0670  mov rax, [r15+0xF8]
0000710a0d1d0677  lea r14, [rax+0x140]
0000710a0d1d067e  mov r12, [r13+r14*1]
0000710a0d1d0683  lea r14, [rax+0x148]
0000710a0d1d068a  mov r11, [r13+r14*1]
0000710a0d1d068f  mov [r15+0xA0], r12
0000710a0d1d0696  mov [r15+0x98], r11
0000710a0d1d069d  lea r14, [rax+0x130]
0000710a0d1d06a4  mov r12, [r13+r14*1]
0000710a0d1d06a9  lea r14, [rax+0x138]
0000710a0d1d06b0  mov r11, [r13+r14*1]
0000710a0d1d06b5  mov [r15+0xB0], r12
0000710a0d1d06bc  mov [r15+0xA8], r11
0000710a0d1d06c3  lea r14, [rax+0x120]
0000710a0d1d06ca  mov r12, [r13+r14*1]
0000710a0d1d06cf  lea r14, [rax+0x128]
0000710a0d1d06d6  mov r11, [r13+r14*1]
0000710a0d1d06db  mov [r15+0xC0], r12
0000710a0d1d06e2  mov [r15+0xB8], r11
0000710a0d1d06e9  lea r14, [rax+0x110]
0000710a0d1d06f0  mov r12, [r13+r14*1]
0000710a0d1d06f5  lea r14, [rax+0x118]
0000710a0d1d06fc  mov r11, [r13+r14*1]
0000710a0d1d0701  mov [r15+0xD0], r12
0000710a0d1d0708  mov [r15+0xC8], r11
0000710a0d1d070f  lea r14, [rax+0x100]
0000710a0d1d0716  mov r12, [r13+r14*1]
0000710a0d1d071b  lea r14, [rax+0x108]
0000710a0d1d0722  mov r11, [r13+r14*1]
0000710a0d1d0727  mov [r15+0xE8], r12
0000710a0d1d072e  mov [r15+0xD8], r11
0000710a0d1d0735  lea r14, [rax+0x150]
0000710a0d1d073c  mov [r15+0xF8], r14
0000710a0d1d0743  mov rax, [r15+0xF0]
0000710a0d1d074a  mov [r15+0x100], rax
0000710a0d1d0751  jmp 0x0000710A0D1CE5C0
0000710a0d1d0756  int3
0000710a0d1d0757  call 0x0000710A0D0E27E0
0000710a0d1d075c  jmp 0x0000710A0D1D0683
0000710a0d1d0761  call 0x0000710A0D0E1570
0000710a0d1d0766  jmp 0x0000710A0D1D068F
0000710a0d1d076b  call 0x0000710A0D0E27E0
0000710a0d1d0770  jmp 0x0000710A0D1D06A9
0000710a0d1d0775  call 0x0000710A0D0E1570
0000710a0d1d077a  jmp 0x0000710A0D1D06B5
0000710a0d1d077f  call 0x0000710A0D0E27E0
0000710a0d1d0784  jmp 0x0000710A0D1D06CF
0000710a0d1d0789  call 0x0000710A0D0E1570
0000710a0d1d078e  jmp 0x0000710A0D1D06DB
0000710a0d1d0793  call 0x0000710A0D0E27E0
0000710a0d1d0798  jmp 0x0000710A0D1D06F5
0000710a0d1d079d  call 0x0000710A0D0E1570
0000710a0d1d07a2  jmp 0x0000710A0D1D0701
0000710a0d1d07a7  call 0x0000710A0D0E27E0
0000710a0d1d07ac  jmp 0x0000710A0D1D071B
0000710a0d1d07b1  call 0x0000710A0D0E1570
0000710a0d1d07b6  jmp 0x0000710A0D1D0727
0000710a0d1d07bb  int3
0000710a0d1d07bc  nop [rax], eax
0000710a0d1d07c0  mov eax, [r15+0xA0]
0000710a0d1d07c7  mov [rsp+0x10], eax
0000710a0d1d07cb  xor eax, eax
0000710a0d1d07cd  mov r14d, [rsp+0x10]
0000710a0d1d07d2  sub r14d, 0x01
0000710a0d1d07d6  cmc
0000710a0d1d07d7  lahf
0000710a0d1d07d8  seto al
0000710a0d1d07db  mov [r15+0x108], eax
0000710a0d1d07e2  mov r14d, r14d
0000710a0d1d07e5  mov [r15+0xA0], r14
0000710a0d1d07ec  mov eax, [r15+0x108]
0000710a0d1d07f3  sahf
0000710a0d1d07f4  jnz 0x0000710A0D1D0826
0000710a0d1d07f6  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d07fe  jz 0x0000710A0D1D0900
0000710a0d1d0804  nop [rax+rax*1], ax
0000710a0d1d080d  nop [rax+rax*1], eax
0000710a0d1d0815  mov eax, 0x41028C
0000710a0d1d081a  mov [r15+0x100], rax
0000710a0d1d0821  jmp 0x0000710A0CFFE110
0000710a0d1d0826  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d082e  jz 0x0000710A0D1D0860
0000710a0d1d0834  nop [rax+rax*1], ax
0000710a0d1d083d  nop [rax+rax*1], eax
0000710a0d1d0845  mov eax, 0x410274
0000710a0d1d084a  mov [r15+0x100], rax
0000710a0d1d0851  jmp 0x0000710A0CFFE110
0000710a0d1d0856  int3
0000710a0d1d0857  int3
0000710a0d1d0858  nop [rax+rax*1], eax
0000710a0d1d0860  mov rax, [r15+0xF8]
0000710a0d1d0867  lea r14, [rax+0xD0]
0000710a0d1d086e  mov [r15], r14
0000710a0d1d0871  mov rax, [r15+0x98]
0000710a0d1d0878  mov [r15+0x08], rax
0000710a0d1d087c  mov qword ptr [r15+0x10], 0x12C
0000710a0d1d0884  mov qword ptr [r15+0xF0], 0x410284
0000710a0d1d088f  mov r14d, [r15+0x320]
0000710a0d1d0896  mov eax, 0x410284
0000710a0d1d089b  mov rcx, 0x710A0D1D07C0
0000710a0d1d08a5  mov [r15+r14*8+0x328], rax
0000710a0d1d08ad  mov [r15+r14*8+0x368], rcx
0000710a0d1d08b5  add r14d, 0x01
0000710a0d1d08b9  and r14d, 0x07
0000710a0d1d08bd  mov [r15+0x320], r14d
0000710a0d1d08c4  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d08cc  jz 0x0000710A0D1CED70
0000710a0d1d08d2  nop [rax+rax*1], ax
0000710a0d1d08db  nop [rax+rax*1], eax
0000710a0d1d08e3  mov eax, 0x4106BC
0000710a0d1d08e8  mov [r15+0x100], rax
0000710a0d1d08ef  jmp 0x0000710A0CFFE110
0000710a0d1d08f4  int3
0000710a0d1d08f5  int3
0000710a0d1d08f6  nop [rax+rax*1], ax
0000710a0d1d08ff  nop
0000710a0d1d0900  mov rax, [r15+0xF8]
0000710a0d1d0907  lea r14, [rax+0xF0]
0000710a0d1d090e  mov r12, [r13+r14*1]
0000710a0d1d0913  mov [r15+0x98], r12
0000710a0d1d091a  mov qword ptr [r15+0x40], 0x80
0000710a0d1d0922  lea r14, [rax+0xD0]
0000710a0d1d0929  mov [r15], r14
0000710a0d1d092c  lea r14, [rax+0x14C]
0000710a0d1d0933  mov [r15+0x08], r14
0000710a0d1d0937  mov qword ptr [r15+0x10], 0x01
0000710a0d1d093f  lea r14, [rax+0x14C]
0000710a0d1d0946  mov eax, 0x80
0000710a0d1d094b  mov [r13+r14*1], al
0000710a0d1d0950  mov qword ptr [r15+0xF0], 0x4102A8
0000710a0d1d095b  mov r14d, [r15+0x320]
0000710a0d1d0962  mov eax, 0x4102A8
0000710a0d1d0967  mov rcx, 0x710A0D1D09E0
0000710a0d1d0971  mov [r15+r14*8+0x328], rax
0000710a0d1d0979  mov [r15+r14*8+0x368], rcx
0000710a0d1d0981  add r14d, 0x01
0000710a0d1d0985  and r14d, 0x07
0000710a0d1d0989  mov [r15+0x320], r14d
0000710a0d1d0990  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0998  jz 0x0000710A0D1CED70
0000710a0d1d099e  nop [rax+rax*1], ax
0000710a0d1d09a7  nop [rax+rax*1], eax
0000710a0d1d09af  mov eax, 0x4106BC
0000710a0d1d09b4  mov [r15+0x100], rax
0000710a0d1d09bb  jmp 0x0000710A0CFFE110
0000710a0d1d09c0  int3
0000710a0d1d09c1  call 0x0000710A0D0E27E0
0000710a0d1d09c6  jmp 0x0000710A0D1D0913
0000710a0d1d09cb  call 0x0000710A0D0D5AF0
0000710a0d1d09d0  jmp 0x0000710A0D1D0950
0000710a0d1d09d5  int3
0000710a0d1d09d6  nop [rax+rax*1], ax
0000710a0d1d09df  nop
0000710a0d1d09e0  mov rax, [r15+0xF8]
0000710a0d1d09e7  lea r14, [rax+0x138]
0000710a0d1d09ee  mov r12, [r13+r14*1]
0000710a0d1d09f3  mov [r15+0x40], r12
0000710a0d1d09f7  lea r14, [rax+0x148]
0000710a0d1d09fe  xor eax, eax
0000710a0d1d0a00  mov [r13+r14*1], al
0000710a0d1d0a05  xor eax, eax
0000710a0d1d0a07  mov r14d, 0x38
0000710a0d1d0a0d  cmp r12, r14
0000710a0d1d0a10  cmc
0000710a0d1d0a11  lahf
0000710a0d1d0a12  seto al
0000710a0d1d0a15  mov [r15+0x108], eax
0000710a0d1d0a1c  mov eax, [r15+0x108]
0000710a0d1d0a23  sahf
0000710a0d1d0a24  jz 0x0000710A0D1D0A56
0000710a0d1d0a26  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0a2e  jz 0x0000710A0D1D0AA0
0000710a0d1d0a34  nop [rax+rax*1], ax
0000710a0d1d0a3d  nop [rax+rax*1], eax
0000710a0d1d0a45  mov eax, 0x4102B8
0000710a0d1d0a4a  mov [r15+0x100], rax
0000710a0d1d0a51  jmp 0x0000710A0CFFE110
0000710a0d1d0a56  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0a5e  jz 0x0000710A0D1D0BF0
0000710a0d1d0a64  nop [rax+rax*1], ax
0000710a0d1d0a6d  nop [rax+rax*1], eax
0000710a0d1d0a75  mov eax, 0x4102D4
0000710a0d1d0a7a  mov [r15+0x100], rax
0000710a0d1d0a81  jmp 0x0000710A0CFFE110
0000710a0d1d0a86  int3
0000710a0d1d0a87  call 0x0000710A0D0E27E0
0000710a0d1d0a8c  jmp 0x0000710A0D1D09F3
0000710a0d1d0a91  call 0x0000710A0D0D5AF0
0000710a0d1d0a96  jmp 0x0000710A0D1D0A05
0000710a0d1d0a9b  int3
0000710a0d1d0a9c  nop [rax], eax
0000710a0d1d0aa0  mov rax, [r15+0xF8]
0000710a0d1d0aa7  lea r14, [rax+0xD0]
0000710a0d1d0aae  mov [r15], r14
0000710a0d1d0ab1  lea r14, [rax+0x148]
0000710a0d1d0ab8  mov [r15+0x08], r14
0000710a0d1d0abc  mov qword ptr [r15+0x10], 0x01
0000710a0d1d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
0000710a0d1d0acf  mov r14d, [r15+0x320]
0000710a0d1d0ad6  mov eax, 0x4102C8
0000710a0d1d0adb  mov rcx, 0x710A0D1D0B40
0000710a0d1d0ae5  mov [r15+r14*8+0x328], rax
0000710a0d1d0aed  mov [r15+r14*8+0x368], rcx
0000710a0d1d0af5  add r14d, 0x01
0000710a0d1d0af9  and r14d, 0x07
0000710a0d1d0afd  mov [r15+0x320], r14d
0000710a0d1d0b04  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0b0c  jz 0x0000710A0D1CED70
0000710a0d1d0b12  nop [rax+rax*1], ax
0000710a0d1d0b1b  nop [rax+rax*1], eax
0000710a0d1d0b23  mov eax, 0x4106BC
0000710a0d1d0b28  mov [r15+0x100], rax
0000710a0d1d0b2f  jmp 0x0000710A0CFFE110
0000710a0d1d0b34  int3
0000710a0d1d0b35  int3
0000710a0d1d0b36  nop [rax+rax*1], ax
0000710a0d1d0b3f  nop
0000710a0d1d0b40  mov rax, [r15+0xF8]
0000710a0d1d0b47  lea r14, [rax+0x138]
0000710a0d1d0b4e  mov rax, [r13+r14*1]
0000710a0d1d0b53  mov [r15+0x40], rax
0000710a0d1d0b57  mov [rsp+0x10], rax
0000710a0d1d0b5c  xor eax, eax
0000710a0d1d0b5e  mov r14, [rsp+0x10]
0000710a0d1d0b63  mov r12d, 0x38
0000710a0d1d0b69  cmp r14, r12
0000710a0d1d0b6c  cmc
0000710a0d1d0b6d  lahf
0000710a0d1d0b6e  seto al
0000710a0d1d0b71  mov [r15+0x108], eax
0000710a0d1d0b78  mov eax, [r15+0x108]
0000710a0d1d0b7f  sahf
0000710a0d1d0b80  jnz 0x0000710A0D1D0BB2
0000710a0d1d0b82  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0b8a  jz 0x0000710A0D1D0BF0
0000710a0d1d0b90  nop [rax+rax*1], ax
0000710a0d1d0b99  nop [rax+rax*1], eax
0000710a0d1d0ba1  mov eax, 0x4102D4
0000710a0d1d0ba6  mov [r15+0x100], rax
0000710a0d1d0bad  jmp 0x0000710A0CFFE110
0000710a0d1d0bb2  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0bba  jz 0x0000710A0D1D0AA0
0000710a0d1d0bc0  nop [rax+rax*1], ax
0000710a0d1d0bc9  nop [rax+rax*1], eax
0000710a0d1d0bd1  mov eax, 0x4102B8
0000710a0d1d0bd6  mov [r15+0x100], rax
0000710a0d1d0bdd  jmp 0x0000710A0CFFE110
0000710a0d1d0be2  int3
0000710a0d1d0be3  call 0x0000710A0D0D59C0
0000710a0d1d0be8  jmp 0x0000710A0D1D0B53
0000710a0d1d0bed  int3
0000710a0d1d0bee  nop
0000710a0d1d0bf0  mov rax, [r15+0x98]
0000710a0d1d0bf7  rorx r14, rax, 0x3D
0000710a0d1d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
0000710a0d1d0c01  mov rax, [r15+0xF8]
0000710a0d1d0c08  lea r12, [rax+0xD0]
0000710a0d1d0c0f  mov [r15], r12
0000710a0d1d0c12  lea r12, [rax+0x140]
0000710a0d1d0c19  mov [r15+0x08], r12
0000710a0d1d0c1d  mov qword ptr [r15+0x10], 0x08
0000710a0d1d0c25  bswap r14
0000710a0d1d0c28  mov [r15+0x40], r14
0000710a0d1d0c2c  lea r12, [rax+0x140]
0000710a0d1d0c33  mov [r13+r12*1], r14
0000710a0d1d0c38  mov qword ptr [r15+0xF0], 0x4102F0
0000710a0d1d0c43  mov r14d, [r15+0x320]
0000710a0d1d0c4a  mov eax, 0x4102F0
0000710a0d1d0c4f  mov rcx, 0x710A0D1D0CC0
0000710a0d1d0c59  mov [r15+r14*8+0x328], rax
0000710a0d1d0c61  mov [r15+r14*8+0x368], rcx
0000710a0d1d0c69  add r14d, 0x01
0000710a0d1d0c6d  and r14d, 0x07
0000710a0d1d0c71  mov [r15+0x320], r14d
0000710a0d1d0c78  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0c80  jz 0x0000710A0D1CED70
0000710a0d1d0c86  nop [rax+rax*1], ax
0000710a0d1d0c8f  nop [rax+rax*1], eax
0000710a0d1d0c97  mov eax, 0x4106BC
0000710a0d1d0c9c  mov [r15+0x100], rax
0000710a0d1d0ca3  jmp 0x0000710A0CFFE110
0000710a0d1d0ca8  int3
0000710a0d1d0ca9  call 0x0000710A0D0C3FE0
0000710a0d1d0cae  jmp 0x0000710A0D1D0C38
0000710a0d1d0cb3  int3
0000710a0d1d0cb4  nop [rax+rax*1], ax
0000710a0d1d0cbd  nop [rax], eax
0000710a0d1d0cc0  mov rax, [r15+0xF8]
0000710a0d1d0cc7  lea r14, [rax+0xD0]
0000710a0d1d0cce  mov r12d, [r13+r14*1]
0000710a0d1d0cd3  lea r14, [rax+0xD4]
0000710a0d1d0cda  mov r11d, [r13+r14*1]
0000710a0d1d0cdf  lea r14, [rax+0xD8]
0000710a0d1d0ce6  mov r10d, [r13+r14*1]
0000710a0d1d0ceb  lea r14, [rax+0xDC]
0000710a0d1d0cf2  mov r9d, [r13+r14*1]
0000710a0d1d0cf7  mov qword ptr [r15+0x48], 0x430C20
0000710a0d1d0cff  mov qword ptr [r15+0xA0], 0x00
0000710a0d1d0d0a  bswap r12d
0000710a0d1d0d0d  bswap r11d
0000710a0d1d0d10  mov qword ptr [r15+0x98], 0x430D8C
0000710a0d1d0d1b  mov r14d, 0x430C20
0000710a0d1d0d21  mov [r13+r14*1], r12d
0000710a0d1d0d26  mov r14d, 0x430C24
0000710a0d1d0d2c  mov [r13+r14*1], r11d
0000710a0d1d0d31  bswap r10d
0000710a0d1d0d34  bswap r9d
0000710a0d1d0d37  lea r14, [rax+0xE0]
0000710a0d1d0d3e  mov r12d, [r13+r14*1]
0000710a0d1d0d43  lea r14, [rax+0xE4]
0000710a0d1d0d4a  mov r11d, [r13+r14*1]
0000710a0d1d0d4f  mov r14d, 0x430C28
0000710a0d1d0d55  mov [r13+r14*1], r10d
0000710a0d1d0d5a  mov r14d, 0x430C2C
0000710a0d1d0d60  mov [r13+r14*1], r9d
0000710a0d1d0d65  bswap r12d
0000710a0d1d0d68  bswap r11d
0000710a0d1d0d6b  mov [rsp+0x10], r11d
0000710a0d1d0d70  mov r11d, r11d
0000710a0d1d0d73  mov [r15+0x58], r11
0000710a0d1d0d77  lea r14, [rax+0xE8]
0000710a0d1d0d7e  mov r11d, [r13+r14*1]
0000710a0d1d0d83  lea r14, [rax+0xEC]
0000710a0d1d0d8a  mov eax, [r13+r14*1]
0000710a0d1d0d8f  mov [rsp+0x20], eax
0000710a0d1d0d93  mov eax, eax
0000710a0d1d0d95  mov [r15+0x60], rax
0000710a0d1d0d99  mov eax, 0x430C30
0000710a0d1d0d9e  mov [r13+rax*1], r12d
0000710a0d1d0da3  mov eax, 0x430C34
0000710a0d1d0da8  mov r14d, [rsp+0x10]
0000710a0d1d0dad  mov [r13+rax*1], r14d
0000710a0d1d0db2  bswap r11d
0000710a0d1d0db5  mov [rsp+0x10], r11d
0000710a0d1d0dba  mov r11d, r11d
0000710a0d1d0dbd  mov [r15+0x40], r11
0000710a0d1d0dc1  mov eax, [rsp+0x20]
0000710a0d1d0dc5  bswap eax
0000710a0d1d0dc7  mov [rsp+0x20], eax
0000710a0d1d0dcb  mov eax, eax
0000710a0d1d0dcd  mov [r15+0x50], rax
0000710a0d1d0dd1  mov eax, 0x430C38
0000710a0d1d0dd6  mov r14d, [rsp+0x10]
0000710a0d1d0ddb  mov [r13+rax*1], r14d
0000710a0d1d0de0  mov eax, 0x430C3C
0000710a0d1d0de5  mov r14d, [rsp+0x20]
0000710a0d1d0dea  mov [r13+rax*1], r14d
0000710a0d1d0def  mov eax, [r15+0xA0]
0000710a0d1d0df6  lea r14d, [eax+0x11]
0000710a0d1d0dfb  mov r14d, r14d
0000710a0d1d0dfe  mov [r15], r14
0000710a0d1d0e01  mov qword ptr [r15+0xF0], 0x41034C
0000710a0d1d0e0c  mov r14d, [r15+0x320]
0000710a0d1d0e13  mov eax, 0x41034C
0000710a0d1d0e18  mov rcx, 0x710A0D1D0F90
0000710a0d1d0e22  mov [r15+r14*8+0x328], rax
0000710a0d1d0e2a  mov [r15+r14*8+0x368], rcx
0000710a0d1d0e32  add r14d, 0x01
0000710a0d1d0e36  and r14d, 0x07
0000710a0d1d0e3a  mov [r15+0x320], r14d
0000710a0d1d0e41  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0e49  jz 0x0000710A0D1D0F20
0000710a0d1d0e4f  nop [rax+rax*1], ax
0000710a0d1d0e58  nop [rax+rax*1], eax
0000710a0d1d0e60  mov eax, 0x410938
0000710a0d1d0e65  mov [r15+0x100], rax
0000710a0d1d0e6c  jmp 0x0000710A0CFFE110
0000710a0d1d0e71  int3
0000710a0d1d0e72  call 0x0000710A0D0E26A0
0000710a0d1d0e77  jmp 0x0000710A0D1D0CD3
0000710a0d1d0e7c  call 0x0000710A0D0E1430
0000710a0d1d0e81  jmp 0x0000710A0D1D0CDF
0000710a0d1d0e86  call 0x0000710A0D0E01C0
0000710a0d1d0e8b  jmp 0x0000710A0D1D0CEB
0000710a0d1d0e90  call 0x0000710A0D0DEF50
0000710a0d1d0e95  jmp 0x0000710A0D1D0CF7
0000710a0d1d0e9a  call 0x0000710A0D0E2BA0
0000710a0d1d0e9f  jmp 0x0000710A0D1D0D26
0000710a0d1d0ea4  call 0x0000710A0D0E1920
0000710a0d1d0ea9  jmp 0x0000710A0D1D0D31
0000710a0d1d0eae  call 0x0000710A0D0E26A0
0000710a0d1d0eb3  jmp 0x0000710A0D1D0D43
0000710a0d1d0eb8  call 0x0000710A0D0E1430
0000710a0d1d0ebd  jmp 0x0000710A0D1D0D4F
0000710a0d1d0ec2  call 0x0000710A0D0E06B0
0000710a0d1d0ec7  jmp 0x0000710A0D1D0D5A
0000710a0d1d0ecc  call 0x0000710A0D0DF440
0000710a0d1d0ed1  jmp 0x0000710A0D1D0D65
0000710a0d1d0ed6  call 0x0000710A0D0E1430
0000710a0d1d0edb  jmp 0x0000710A0D1D0D83
0000710a0d1d0ee0  call 0x0000710A0D0D5890
0000710a0d1d0ee5  jmp 0x0000710A0D1D0D8F
0000710a0d1d0eea  call 0x0000710A0D00BAE0
0000710a0d1d0eef  jmp 0x0000710A0D1D0DA3
0000710a0d1d0ef4  call 0x0000710A0D00DFE0
0000710a0d1d0ef9  jmp 0x0000710A0D1D0DB2
0000710a0d1d0efe  call 0x0000710A0D00DFE0
0000710a0d1d0f03  jmp 0x0000710A0D1D0DE0
0000710a0d1d0f08  call 0x0000710A0D00DFE0
0000710a0d1d0f0d  jmp 0x0000710A0D1D0DEF
0000710a0d1d0f12  int3
0000710a0d1d0f13  nop [rax+rax*1], ax
0000710a0d1d0f1c  nop [rax], eax
0000710a0d1d0f20  mov eax, [r15]
0000710a0d1d0f23  mov [rsp+0x10], eax
0000710a0d1d0f27  shr eax, 0x10
0000710a0d1d0f2a  mov r14d, [rsp+0x10]
0000710a0d1d0f2f  xor r14d, eax
0000710a0d1d0f32  imul r14d, r14d, 0x7FEB352D
0000710a0d1d0f39  mov eax, 0x846CA68B
0000710a0d1d0f3e  mov eax, eax
0000710a0d1d0f40  mov [r15+0x48], rax
0000710a0d1d0f44  mov [rsp+0x10], r14d
0000710a0d1d0f49  shr r14d, 0x0F
0000710a0d1d0f4d  mov eax, [rsp+0x10]
0000710a0d1d0f51  xor eax, r14d
0000710a0d1d0f54  imul eax, eax, 0x846CA68B
0000710a0d1d0f5a  mov [rsp+0x10], eax
0000710a0d1d0f5e  mov eax, eax
0000710a0d1d0f60  mov [r15+0x40], rax
0000710a0d1d0f64  mov eax, [rsp+0x10]
0000710a0d1d0f68  shr eax, 0x10
0000710a0d1d0f6b  mov r14d, [rsp+0x10]
0000710a0d1d0f70  xor r14d, eax
0000710a0d1d0f73  mov r14d, r14d
0000710a0d1d0f76  mov [r15], r14
0000710a0d1d0f79  mov rax, [r15+0xF0]
0000710a0d1d0f80  mov [r15+0x100], rax
0000710a0d1d0f87  jmp 0x0000710A0D1CE5C0
0000710a0d1d0f8c  int3
0000710a0d1d0f8d  int3
0000710a0d1d0f8e  nop
0000710a0d1d0f90  mov rax, [r15+0xA0]
0000710a0d1d0f97  mov [rsp+0x10], rax
0000710a0d1d0f9c  shl rax, 0x02
0000710a0d1d0fa0  mov r14, [r15+0x98]
0000710a0d1d0fa7  lea r12, [r14+rax*1]
0000710a0d1d0fab  mov eax, [r15]
0000710a0d1d0fae  mov [r13+r12*1], eax
0000710a0d1d0fb3  mov rax, [rsp+0x10]
0000710a0d1d0fb8  lea r14, [rax+0x01]
0000710a0d1d0fbc  mov [r15+0xA0], r14
0000710a0d1d0fc3  xor eax, eax
0000710a0d1d0fc5  mov r12d, 0x400
0000710a0d1d0fcb  cmp r14, r12
0000710a0d1d0fce  cmc
0000710a0d1d0fcf  lahf
0000710a0d1d0fd0  seto al
0000710a0d1d0fd3  mov [r15+0x108], eax
0000710a0d1d0fda  mov eax, [r15+0x108]
0000710a0d1d0fe1  sahf
0000710a0d1d0fe2  jnz 0x0000710A0D1D1014
0000710a0d1d0fe4  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d0fec  jz 0x0000710A0D1D10E0
0000710a0d1d0ff2  nop [rax+rax*1], ax
0000710a0d1d0ffb  nop [rax+rax*1], eax
0000710a0d1d1003  mov eax, 0x41035C
0000710a0d1d1008  mov [r15+0x100], rax
0000710a0d1d100f  jmp 0x0000710A0CFFE110
0000710a0d1d1014  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d101c  jz 0x0000710A0D1D1050
0000710a0d1d1022  nop [rax+rax*1], ax
0000710a0d1d102b  nop [rax+rax*1], eax
0000710a0d1d1033  mov eax, 0x410344
0000710a0d1d1038  mov [r15+0x100], rax
0000710a0d1d103f  jmp 0x0000710A0CFFE110
0000710a0d1d1044  int3
0000710a0d1d1045  call 0x0000710A0D0B4B70
0000710a0d1d104a  jmp 0x0000710A0D1D0FB3
0000710a0d1d104f  int3
0000710a0d1d1050  mov eax, [r15+0xA0]
0000710a0d1d1057  lea r14d, [eax+0x11]
0000710a0d1d105c  mov r14d, r14d
0000710a0d1d105f  mov [r15], r14
0000710a0d1d1062  mov qword ptr [r15+0xF0], 0x41034C
0000710a0d1d106d  mov r14d, [r15+0x320]
0000710a0d1d1074  mov eax, 0x41034C
0000710a0d1d1079  mov rcx, 0x710A0D1D0F90
0000710a0d1d1083  mov [r15+r14*8+0x328], rax
0000710a0d1d108b  mov [r15+r14*8+0x368], rcx
0000710a0d1d1093  add r14d, 0x01
0000710a0d1d1097  and r14d, 0x07
0000710a0d1d109b  mov [r15+0x320], r14d
0000710a0d1d10a2  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d10aa  jz 0x0000710A0D1D0F20
0000710a0d1d10b0  nop [rax+rax*1], ax
0000710a0d1d10b9  nop [rax+rax*1], eax
0000710a0d1d10c1  mov eax, 0x410938
0000710a0d1d10c6  mov [r15+0x100], rax
0000710a0d1d10cd  jmp 0x0000710A0CFFE110
0000710a0d1d10d2  int3
0000710a0d1d10d3  int3
0000710a0d1d10d4  nop [rax+rax*1], ax
0000710a0d1d10dd  nop [rax], eax
0000710a0d1d10e0  mov qword ptr [r15+0x40], 0x01
0000710a0d1d10e8  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d10f0  jz 0x0000710A0D1D1120
0000710a0d1d10f6  nop [rax+rax*1], ax
0000710a0d1d10ff  nop [rax+rax*1], eax
0000710a0d1d1107  mov eax, 0x410378
0000710a0d1d110c  mov [r15+0x100], rax
0000710a0d1d1113  jmp 0x0000710A0CFFE110
0000710a0d1d1118  int3
0000710a0d1d1119  int3
0000710a0d1d111a  nop [rax+rax*1], ax
0000710a0d1d1120  mov rax, [r15+0x40]
0000710a0d1d1124  mov [rsp+0x10], rax
0000710a0d1d1129  shl rax, 0x02
0000710a0d1d112d  mov r14, [r15+0x98]
0000710a0d1d1134  lea r12, [r14+rax*1]
0000710a0d1d1138  mov eax, [r13+r12*1]
0000710a0d1d113d  mov [rsp+0x20], eax
0000710a0d1d1141  mov eax, eax
0000710a0d1d1143  mov [r15+0x48], rax
0000710a0d1d1147  mov rax, [rsp+0x10]
0000710a0d1d114c  mov [r15+0x50], rax
0000710a0d1d1150  mov eax, [r15+0x50]
0000710a0d1d1154  lea r12d, [eax-0x01]
0000710a0d1d1159  mov r12d, r12d
0000710a0d1d115c  mov [r15+0x58], r12
0000710a0d1d1160  mov rax, [r15+0x58]
0000710a0d1d1164  mov r12d, eax
0000710a0d1d1167  mov r12d, r12d
0000710a0d1d116a  shl r12, 0x02
0000710a0d1d116e  lea rax, [r14+r12*1]
0000710a0d1d1172  mov r14d, [r13+rax*1]
0000710a0d1d1177  mov [rsp+0x10], r14d
0000710a0d1d117c  mov r14d, r14d
0000710a0d1d117f  mov [r15+0x60], r14
0000710a0d1d1183  xor eax, eax
0000710a0d1d1185  mov r14d, [rsp+0x10]
0000710a0d1d118a  mov r12d, [rsp+0x20]
0000710a0d1d118f  cmp r14d, r12d
0000710a0d1d1192  cmc
0000710a0d1d1193  lahf
0000710a0d1d1194  seto al
0000710a0d1d1197  mov [r15+0x108], eax
0000710a0d1d119e  mov eax, [r15+0x108]
0000710a0d1d11a5  sahf
0000710a0d1d11a6  cmc
0000710a0d1d11a7  jbe 0x0000710A0D1D11D9
0000710a0d1d11a9  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d11b1  jz 0x0000710A0D1D1220
0000710a0d1d11b7  nop [rax+rax*1], ax
0000710a0d1d11c0  nop [rax+rax*1], eax
0000710a0d1d11c8  mov eax, 0x410390
0000710a0d1d11cd  mov [r15+0x100], rax
0000710a0d1d11d4  jmp 0x0000710A0CFFE110
0000710a0d1d11d9  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d11e1  jz 0x0000710A0D1D14C0
0000710a0d1d11e7  nop [rax+rax*1], ax
0000710a0d1d11f0  nop [rax+rax*1], eax
0000710a0d1d11f8  mov eax, 0x410368
0000710a0d1d11fd  mov [r15+0x100], rax
0000710a0d1d1204  jmp 0x0000710A0CFFE110
0000710a0d1d1209  int3
0000710a0d1d120a  call 0x0000710A0D0B4690
0000710a0d1d120f  jmp 0x0000710A0D1D113D
0000710a0d1d1214  call 0x0000710A0D00DAE0
0000710a0d1d1219  jmp 0x0000710A0D1D1177
0000710a0d1d121e  int3
0000710a0d1d121f  nop
0000710a0d1d1220  mov rax, [r15+0x50]
0000710a0d1d1224  mov [rsp+0x10], rax
0000710a0d1d1229  shl rax, 0x02
0000710a0d1d122d  mov r14, [r15+0x98]
0000710a0d1d1234  lea r12, [r14+rax*1]
0000710a0d1d1238  mov eax, [r15+0x60]
0000710a0d1d123c  mov [r13+r12*1], eax
0000710a0d1d1241  mov rax, [rsp+0x10]
0000710a0d1d1246  lea r14, [rax-0x01]
0000710a0d1d124a  mov [r15+0x50], r14
0000710a0d1d124e  mov rax, [r15+0x58]
0000710a0d1d1252  test rax, rax
0000710a0d1d1255  setz al
0000710a0d1d1258  movzx rax, al
0000710a0d1d125c  mov [rsp+0x414], al
0000710a0d1d1263  cmp byte ptr [rsp+0x414], 0x00
0000710a0d1d126b  jz 0x0000710A0D1D129D
0000710a0d1d126d  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d1275  jz 0x0000710A0D1D12E0
0000710a0d1d127b  nop [rax+rax*1], ax
0000710a0d1d1284  nop [rax+rax*1], eax
0000710a0d1d128c  mov eax, 0x41039C
0000710a0d1d1291  mov [r15+0x100], rax
0000710a0d1d1298  jmp 0x0000710A0CFFE110
0000710a0d1d129d  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d12a5  jz 0x0000710A0D1D13E0
0000710a0d1d12ab  nop [rax+rax*1], ax
0000710a0d1d12b4  nop [rax+rax*1], eax
0000710a0d1d12bc  mov eax, 0x410380
0000710a0d1d12c1  mov [r15+0x100], rax
0000710a0d1d12c8  jmp 0x0000710A0CFFE110
0000710a0d1d12cd  int3
0000710a0d1d12ce  call 0x0000710A0D0B4B70
0000710a0d1d12d3  jmp 0x0000710A0D1D1241
0000710a0d1d12d8  int3
0000710a0d1d12d9  nop [rax], eax
0000710a0d1d12e0  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d12e8  jz 0x0000710A0D1D1320
0000710a0d1d12ee  nop [rax+rax*1], ax
0000710a0d1d12f7  nop [rax+rax*1], eax
0000710a0d1d12ff  mov eax, 0x410364
0000710a0d1d1304  mov [r15+0x100], rax
0000710a0d1d130b  jmp 0x0000710A0CFFE110
0000710a0d1d1310  int3
0000710a0d1d1311  int3
0000710a0d1d1312  nop [rax+rax*1], ax
0000710a0d1d131b  nop [rax+rax*1], eax
0000710a0d1d1320  mov qword ptr [r15+0x50], 0x00
0000710a0d1d1328  mov rax, [r15+0x40]
0000710a0d1d132c  lea r14, [rax+0x01]
0000710a0d1d1330  mov [r15+0x40], r14
0000710a0d1d1334  mov rax, [r15+0x98]
0000710a0d1d133b  mov r12d, [r15+0x48]
0000710a0d1d133f  mov [r13+rax*1], r12d
0000710a0d1d1344  xor eax, eax
0000710a0d1d1346  mov r12d, 0x400
0000710a0d1d134c  cmp r14, r12
0000710a0d1d134f  cmc
0000710a0d1d1350  lahf
0000710a0d1d1351  seto al
0000710a0d1d1354  mov [r15+0x108], eax
0000710a0d1d135b  mov eax, [r15+0x108]
0000710a0d1d1362  sahf
0000710a0d1d1363  jz 0x0000710A0D1D1395
0000710a0d1d1365  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d136d  jz 0x0000710A0D1D1120
0000710a0d1d1373  nop [rax+rax*1], ax
0000710a0d1d137c  nop [rax+rax*1], eax
0000710a0d1d1384  mov eax, 0x410378
0000710a0d1d1389  mov [r15+0x100], rax
0000710a0d1d1390  jmp 0x0000710A0CFFE110
0000710a0d1d1395  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d139d  jz 0x0000710A0D1D1580
0000710a0d1d13a3  nop [rax+rax*1], ax
0000710a0d1d13ac  nop [rax+rax*1], eax
0000710a0d1d13b4  mov eax, 0x4103A0
0000710a0d1d13b9  mov [r15+0x100], rax
0000710a0d1d13c0  jmp 0x0000710A0CFFE110
0000710a0d1d13c5  int3
0000710a0d1d13c6  call 0x0000710A0D00BAE0
0000710a0d1d13cb  jmp 0x0000710A0D1D1344
0000710a0d1d13d0  int3
0000710a0d1d13d1  nop [rax+rax*1], ax
0000710a0d1d13da  nop [rax+rax*1], ax
0000710a0d1d13e0  mov eax, [r15+0x50]
0000710a0d1d13e4  lea r14d, [eax-0x01]
0000710a0d1d13e9  mov r14d, r14d
0000710a0d1d13ec  mov [r15+0x58], r14
0000710a0d1d13f0  mov rax, [r15+0x58]
0000710a0d1d13f4  mov r14d, eax
0000710a0d1d13f7  mov r14d, r14d
0000710a0d1d13fa  shl r14, 0x02
0000710a0d1d13fe  mov rax, [r15+0x98]
0000710a0d1d1405  lea r12, [rax+r14*1]
0000710a0d1d1409  mov eax, [r13+r12*1]
0000710a0d1d140e  mov [rsp+0x10], eax
0000710a0d1d1412  mov eax, eax
0000710a0d1d1414  mov [r15+0x60], rax
0000710a0d1d1418  mov eax, [r15+0x48]
0000710a0d1d141c  mov [rsp+0x20], eax
0000710a0d1d1420  xor eax, eax
0000710a0d1d1422  mov r14d, [rsp+0x10]
0000710a0d1d1427  mov r12d, [rsp+0x20]
0000710a0d1d142c  cmp r14d, r12d
0000710a0d1d142f  cmc
0000710a0d1d1430  lahf
0000710a0d1d1431  seto al
0000710a0d1d1434  mov [r15+0x108], eax
0000710a0d1d143b  mov eax, [r15+0x108]
0000710a0d1d1442  sahf
0000710a0d1d1443  cmc
0000710a0d1d1444  jbe 0x0000710A0D1D1476
0000710a0d1d1446  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d144e  jz 0x0000710A0D1D1220
0000710a0d1d1454  nop [rax+rax*1], ax
0000710a0d1d145d  nop [rax+rax*1], eax
0000710a0d1d1465  mov eax, 0x410390
0000710a0d1d146a  mov [r15+0x100], rax
0000710a0d1d1471  jmp 0x0000710A0CFFE110
0000710a0d1d1476  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d147e  jz 0x0000710A0D1D14C0
0000710a0d1d1484  nop [rax+rax*1], ax
0000710a0d1d148d  nop [rax+rax*1], eax
0000710a0d1d1495  mov eax, 0x410368
0000710a0d1d149a  mov [r15+0x100], rax
0000710a0d1d14a1  jmp 0x0000710A0CFFE110
0000710a0d1d14a6  int3
0000710a0d1d14a7  call 0x0000710A0D0B4690
0000710a0d1d14ac  jmp 0x0000710A0D1D140E
0000710a0d1d14b1  int3
0000710a0d1d14b2  nop [rax+rax*1], ax
0000710a0d1d14bb  nop [rax+rax*1], eax
0000710a0d1d14c0  mov rax, [r15+0x40]
0000710a0d1d14c4  lea r14, [rax+0x01]
0000710a0d1d14c8  mov [r15+0x40], r14
0000710a0d1d14cc  mov rax, [r15+0x50]
0000710a0d1d14d0  mov r12d, eax
0000710a0d1d14d3  mov r12d, r12d
0000710a0d1d14d6  shl r12, 0x02
0000710a0d1d14da  mov rax, [r15+0x98]
0000710a0d1d14e1  lea r11, [rax+r12*1]
0000710a0d1d14e5  mov eax, [r15+0x48]
0000710a0d1d14e9  mov [r13+r11*1], eax
0000710a0d1d14ee  xor eax, eax
0000710a0d1d14f0  mov r12d, 0x400
0000710a0d1d14f6  cmp r14, r12
0000710a0d1d14f9  cmc
0000710a0d1d14fa  lahf
0000710a0d1d14fb  seto al
0000710a0d1d14fe  mov [r15+0x108], eax
0000710a0d1d1505  mov eax, [r15+0x108]
0000710a0d1d150c  sahf
0000710a0d1d150d  jz 0x0000710A0D1D153F
0000710a0d1d150f  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d1517  jz 0x0000710A0D1D1120
0000710a0d1d151d  nop [rax+rax*1], ax
0000710a0d1d1526  nop [rax+rax*1], eax
0000710a0d1d152e  mov eax, 0x410378
0000710a0d1d1533  mov [r15+0x100], rax
0000710a0d1d153a  jmp 0x0000710A0CFFE110
0000710a0d1d153f  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d1547  jz 0x0000710A0D1D1580
0000710a0d1d154d  nop [rax+rax*1], ax
0000710a0d1d1556  nop [rax+rax*1], eax
0000710a0d1d155e  mov eax, 0x4103A0
0000710a0d1d1563  mov [r15+0x100], rax
0000710a0d1d156a  jmp 0x0000710A0CFFE110
0000710a0d1d156f  int3
0000710a0d1d1570  call 0x0000710A0D0A4270
0000710a0d1d1575  jmp 0x0000710A0D1D14EE
0000710a0d1d157a  int3
0000710a0d1d157b  nop [rax+rax*1], eax
0000710a0d1d1580  mov qword ptr [r15+0x40], 0x430000
0000710a0d1d1588  mov eax, 0x430C40
0000710a0d1d158d  mov r14, [r13+rax*1]
0000710a0d1d1592  mov rax, [r15+0x98]
0000710a0d1d1599  mov r12d, [r13+rax*1]
0000710a0d1d159e  lea r11, [rax+0x04]
0000710a0d1d15a2  mov eax, [r13+r11*1]
0000710a0d1d15a7  mov r12d, r12d
0000710a0d1d15aa  mov [r15+0x68], r12
0000710a0d1d15ae  mov eax, eax
0000710a0d1d15b0  mov [r15+0x60], rax
0000710a0d1d15b4  mov rax, [r15+0x68]
0000710a0d1d15b8  mov [r15+0x68], rax
0000710a0d1d15bc  mov qword ptr [r15+0x58], 0x02
0000710a0d1d15c4  mov [rsp+0x10], rax
0000710a0d1d15c9  xor eax, eax
0000710a0d1d15cb  mov r12d, 0x02
0000710a0d1d15d1  mov r11d, 0x400
0000710a0d1d15d7  cmp r12, r11
0000710a0d1d15da  cmc
0000710a0d1d15db  lahf
0000710a0d1d15dc  seto al
0000710a0d1d15df  mov [r15+0x108], eax
0000710a0d1d15e6  mov rax, [r15+0x60]
0000710a0d1d15ea  mov r12d, 0x02
0000710a0d1d15f0  imul rax, r12
0000710a0d1d15f4  mov [r15+0x50], rax
0000710a0d1d15f8  mov rax, [rsp+0x10]
0000710a0d1d15fd  lea r12, [rax+r14*1]
0000710a0d1d1601  mov [r15+0x48], r12
0000710a0d1d1605  mov eax, [r15+0x108]
0000710a0d1d160c  sahf
0000710a0d1d160d  jnz 0x0000710A0D1D163F
0000710a0d1d160f  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d1617  jz 0x0000710A0D1D17B0
0000710a0d1d161d  nop [rax+rax*1], ax
0000710a0d1d1626  nop [rax+rax*1], eax
0000710a0d1d162e  mov eax, 0x4103D0
0000710a0d1d1633  mov [r15+0x100], rax
0000710a0d1d163a  jmp 0x0000710A0CFFE110
0000710a0d1d163f  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d1647  jz 0x0000710A0D1D1690
0000710a0d1d164d  nop [rax+rax*1], ax
0000710a0d1d1656  nop [rax+rax*1], eax
0000710a0d1d165e  mov eax, 0x4103B0
0000710a0d1d1663  mov [r15+0x100], rax
0000710a0d1d166a  jmp 0x0000710A0CFFE110
0000710a0d1d166f  int3
0000710a0d1d1670  call 0x0000710A0D00DC20
0000710a0d1d1675  jmp 0x0000710A0D1D1592
0000710a0d1d167a  call 0x0000710A0D00B5E0
0000710a0d1d167f  jmp 0x0000710A0D1D159E
0000710a0d1d1684  call 0x0000710A0D0A3D90
0000710a0d1d1689  jmp 0x0000710A0D1D15A7
0000710a0d1d168e  int3
0000710a0d1d168f  nop
0000710a0d1d1690  mov rax, [r15+0x98]
0000710a0d1d1697  mov r14, [r15+0x58]
0000710a0d1d169b  mov [rsp+0x10], r14
0000710a0d1d16a0  shl r14, 0x02
0000710a0d1d16a4  lea r12, [rax+r14*1]
0000710a0d1d16a8  mov eax, [r13+r12*1]
0000710a0d1d16ad  lea r14, [r12+0x04]
0000710a0d1d16b2  mov r12d, [r13+r14*1]
0000710a0d1d16b7  mov eax, eax
0000710a0d1d16b9  mov [r15+0x68], rax
0000710a0d1d16bd  mov r12d, r12d
0000710a0d1d16c0  mov [r15+0x60], r12
0000710a0d1d16c4  mov rax, [r15+0x68]
0000710a0d1d16c8  mov [rsp+0x20], rax
0000710a0d1d16cd  mov r14, [rsp+0x10]
0000710a0d1d16d2  imul rax, r14
0000710a0d1d16d6  mov r12, [rsp+0x20]
0000710a0d1d16db  lea r11, [r12+rax*1]
0000710a0d1d16df  mov [r15+0x68], r11
0000710a0d1d16e3  lea rax, [r14+0x02]
0000710a0d1d16e7  mov [r15+0x58], rax
0000710a0d1d16eb  mov [rsp+0x10], rax
0000710a0d1d16f0  xor eax, eax
0000710a0d1d16f2  mov r14, [rsp+0x10]
0000710a0d1d16f7  mov r12d, 0x400
0000710a0d1d16fd  cmp r14, r12
0000710a0d1d1700  cmc
0000710a0d1d1701  lahf
0000710a0d1d1702  seto al
0000710a0d1d1705  mov [r15+0x108], eax
0000710a0d1d170c  mov rax, [r15+0x50]
0000710a0d1d1710  mov r12, [r15+0x60]
0000710a0d1d1714  imul r14, r12
0000710a0d1d1718  lea r12, [rax+r14*1]
0000710a0d1d171c  mov [r15+0x50], r12
0000710a0d1d1720  mov rax, [r15+0x48]
0000710a0d1d1724  lea r14, [r11+rax*1]
0000710a0d1d1728  mov [r15+0x48], r14
0000710a0d1d172c  mov eax, [r15+0x108]
0000710a0d1d1733  sahf
0000710a0d1d1734  jnz 0x0000710A0D1D1766
0000710a0d1d1736  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d173e  jz 0x0000710A0D1D17B0
0000710a0d1d1744  nop [rax+rax*1], ax
0000710a0d1d174d  nop [rax+rax*1], eax
0000710a0d1d1755  mov eax, 0x4103D0
0000710a0d1d175a  mov [r15+0x100], rax
0000710a0d1d1761  jmp 0x0000710A0CFFE110
0000710a0d1d1766  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d176e  jz 0x0000710A0D1D1690
0000710a0d1d1774  nop [rax+rax*1], ax
0000710a0d1d177d  nop [rax+rax*1], eax
0000710a0d1d1785  mov eax, 0x4103B0
0000710a0d1d178a  mov [r15+0x100], rax
0000710a0d1d1791  jmp 0x0000710A0CFFE110
0000710a0d1d1796  int3
0000710a0d1d1797  call 0x0000710A0D0B4690
0000710a0d1d179c  jmp 0x0000710A0D1D16AD
0000710a0d1d17a1  call 0x0000710A0D0E26A0
0000710a0d1d17a6  jmp 0x0000710A0D1D16B7
0000710a0d1d17ab  int3
0000710a0d1d17ac  nop [rax], eax
0000710a0d1d17b0  mov qword ptr [r15+0x98], 0x00
0000710a0d1d17bb  mov rax, [r15+0x50]
0000710a0d1d17bf  mov r14, [r15+0x48]
0000710a0d1d17c3  lea r12, [rax+r14*1]
0000710a0d1d17c7  mov [r15+0x48], r12
0000710a0d1d17cb  mov rax, [r15+0x40]
0000710a0d1d17cf  lea r14, [rax+0xC40]
0000710a0d1d17d6  mov [r13+r14*1], r12
0000710a0d1d17db  mov qword ptr [r15], 0x01
0000710a0d1d17e2  mov qword ptr [r15+0xF0], 0x4103E8
0000710a0d1d17ed  mov r14d, [r15+0x320]
0000710a0d1d17f4  mov eax, 0x4103E8
0000710a0d1d17f9  mov rcx, 0x710A0D1D1860
0000710a0d1d1803  mov [r15+r14*8+0x328], rax
0000710a0d1d180b  mov [r15+r14*8+0x368], rcx
0000710a0d1d1813  add r14d, 0x01
0000710a0d1d1817  and r14d, 0x07
0000710a0d1d181b  mov [r15+0x320], r14d
0000710a0d1d1822  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d182a  jz 0x0000710A0D1D0F20
0000710a0d1d1830  nop [rax+rax*1], ax
0000710a0d1d1839  nop [rax+rax*1], eax
0000710a0d1d1841  mov eax, 0x410938
0000710a0d1d1846  mov [r15+0x100], rax
0000710a0d1d184d  jmp 0x0000710A0CFFE110
0000710a0d1d1852  int3
0000710a0d1d1853  call 0x0000710A0D0E2CE0
0000710a0d1d1858  jmp 0x0000710A0D1D17DB
0000710a0d1d185d  int3
0000710a0d1d185e  nop
0000710a0d1d1860  mov eax, [r15+0x98]
0000710a0d1d1867  lea r14d, [eax+0x01]
0000710a0d1d186c  mov [rsp+0x10], r14d
0000710a0d1d1871  mov r14d, r14d
0000710a0d1d1874  mov [r15+0x98], r14
0000710a0d1d187b  xor eax, eax
0000710a0d1d187d  mov r14d, [rsp+0x10]
0000710a0d1d1882  cmp r14d, 0x10000
0000710a0d1d1889  cmc
0000710a0d1d188a  lahf
0000710a0d1d188b  seto al
0000710a0d1d188e  mov [r15+0x108], eax
0000710a0d1d1895  mov eax, [r15+0x108]
0000710a0d1d189c  sahf
0000710a0d1d189d  jnz 0x0000710A0D1D18CF
0000710a0d1d189f  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d18a7  jz 0x0000710A0D1D19A0
0000710a0d1d18ad  nop [rax+rax*1], ax
0000710a0d1d18b6  nop [rax+rax*1], eax
0000710a0d1d18be  mov eax, 0x4103F4
0000710a0d1d18c3  mov [r15+0x100], rax
0000710a0d1d18ca  jmp 0x0000710A0CFFE110
0000710a0d1d18cf  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d18d7  jz 0x0000710A0D1D1910
0000710a0d1d18dd  nop [rax+rax*1], ax
0000710a0d1d18e6  nop [rax+rax*1], eax
0000710a0d1d18ee  mov eax, 0x4103E0
0000710a0d1d18f3  mov [r15+0x100], rax
0000710a0d1d18fa  jmp 0x0000710A0CFFE110
0000710a0d1d18ff  int3
0000710a0d1d1900  int3
0000710a0d1d1901  nop [rax+rax*1], ax
0000710a0d1d190a  nop [rax+rax*1], ax
0000710a0d1d1910  mov eax, [r15]
0000710a0d1d1913  mov r14d, [r15+0x98]
0000710a0d1d191a  lea r12d, [eax+r14d*1]
0000710a0d1d191f  mov r12d, r12d
0000710a0d1d1922  mov [r15], r12
0000710a0d1d1925  mov qword ptr [r15+0xF0], 0x4103E8
0000710a0d1d1930  mov r14d, [r15+0x320]
0000710a0d1d1937  mov eax, 0x4103E8
0000710a0d1d193c  mov rcx, 0x710A0D1D1860
0000710a0d1d1946  mov [r15+r14*8+0x328], rax
0000710a0d1d194e  mov [r15+r14*8+0x368], rcx
0000710a0d1d1956  add r14d, 0x01
0000710a0d1d195a  and r14d, 0x07
0000710a0d1d195e  mov [r15+0x320], r14d
0000710a0d1d1965  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d196d  jz 0x0000710A0D1D0F20
0000710a0d1d1973  nop [rax+rax*1], ax
0000710a0d1d197c  nop [rax+rax*1], eax
0000710a0d1d1984  mov eax, 0x410938
0000710a0d1d1989  mov [r15+0x100], rax
0000710a0d1d1990  jmp 0x0000710A0CFFE110
0000710a0d1d1995  int3
0000710a0d1d1996  int3
0000710a0d1d1997  nop [rax+rax*1], ax
0000710a0d1d19a0  vmovaps xmm1, [0x0000710A0CDFE010]
0000710a0d1d19a8  movq xmm1, xmm1
0000710a0d1d19ac  movaps [r15+0x110], xmm1
0000710a0d1d19b4  mov eax, 0x420AA0
0000710a0d1d19b9  mov r14, [r13+rax*1]
0000710a0d1d19be  movq xmm1, r14
0000710a0d1d19c3  movaps [r15+0x120], xmm1
0000710a0d1d19cb  vmovaps xmm1, [0x0000710A0CDFE020]
0000710a0d1d19d3  movq xmm1, xmm1
0000710a0d1d19d7  movaps [r15+0x140], xmm1
0000710a0d1d19df  vmovaps xmm1, [0x0000710A0CDFE030]
0000710a0d1d19e7  vpbroadcastq xmm1, xmm1
0000710a0d1d19ec  movaps [r15+0x150], xmm1
0000710a0d1d19f4  mov qword ptr [r15+0x40], 0x02
0000710a0d1d19fc  vmovaps xmm15, [0x0000710A0CDFE040]
0000710a0d1d1a04  movq xmm15, xmm15
0000710a0d1d1a09  movaps [r15+0x160], xmm15
0000710a0d1d1a11  vmovaps xmm15, [0x0000710A0CDFE050]
0000710a0d1d1a19  vpbroadcastq xmm15, xmm15
0000710a0d1d1a1e  movaps [r15+0x130], xmm15
0000710a0d1d1a26  mov rax, [r15+0x40]
0000710a0d1d1a2a  vmovq xmm14, rax
0000710a0d1d1a2f  vpbroadcastq xmm14, xmm14
0000710a0d1d1a34  movaps [r15+0x170], xmm14
0000710a0d1d1a3c  mov eax, 0x4209D0
0000710a0d1d1a41  movups xmm13, [r13+rax*1]
0000710a0d1d1a47  mov qword ptr [r15+0x40], 0x431D90
0000710a0d1d1a4f  mov eax, [r15]
0000710a0d1d1a52  mov r14d, 0x430C48
0000710a0d1d1a58  mov [r13+r14*1], eax
0000710a0d1d1a5d  mov qword ptr [r15+0x50], 0x431F90
0000710a0d1d1a65  vpmovqd xmm12, xmm13
0000710a0d1d1a6b  pxor xmm11, xmm11
0000710a0d1d1a70  punpcklqdq xmm12, xmm11
0000710a0d1d1a75  movaps [r15+0x210], xmm12
0000710a0d1d1a7d  movq xmm12, qword ptr [r15+0x140]
0000710a0d1d1a86  movq xmm11, qword ptr [r15+0x120]
0000710a0d1d1a8f  psubd xmm12, xmm11
0000710a0d1d1a94  movq xmm12, xmm12
0000710a0d1d1a99  paddq xmm13, xmm14
0000710a0d1d1a9e  movaps [r15+0x180], xmm13
0000710a0d1d1aa6  movq xmm14, qword ptr [r15+0x160]
0000710a0d1d1aaf  paddd xmm11, xmm14
0000710a0d1d1ab4  movq xmm11, xmm11
0000710a0d1d1ab9  movq xmm11, xmm11
0000710a0d1d1abe  movaps [r15+0x120], xmm11
0000710a0d1d1ac6  pmovzxdq xmm12, xmm12
0000710a0d1d1acc  psllq xmm12, 0x00
0000710a0d1d1ad2  movq xmm14, qword ptr [r15+0x210]
0000710a0d1d1adb  movq xmm13, qword ptr [r15+0x110]
0000710a0d1d1ae4  paddd xmm14, xmm13
0000710a0d1d1ae9  movq xmm14, xmm14
0000710a0d1d1aee  vcvtuqq2pd xmm12, xmm12
0000710a0d1d1af4  pmovzxdq xmm14, xmm14
0000710a0d1d1afa  psllq xmm14, 0x00
0000710a0d1d1b00  vcvtuqq2pd xmm14, xmm14
0000710a0d1d1b06  movaps xmm13, xmm12
0000710a0d1d1b0a  mulpd xmm13, xmm1
0000710a0d1d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
0000710a0d1d1b15  ptest xmm11, xmm11
0000710a0d1d1b1b  jnz 0x0000710A0D1D1C0F
0000710a0d1d1b21  movaps [r15+0x220], xmm13
0000710a0d1d1b29  mov eax, 0x431F90
0000710a0d1d1b2e  movups [r13+rax*1], xmm13
0000710a0d1d1b34  movaps xmm1, xmm14
0000710a0d1d1b38  mulpd xmm1, xmm15
0000710a0d1d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
0000710a0d1d1b42  ptest xmm13, xmm13
0000710a0d1d1b48  jnz 0x0000710A0D1D1D5C
0000710a0d1d1b4e  movaps [r15+0x210], xmm1
0000710a0d1d1b56  mov eax, 0x431D90
0000710a0d1d1b5b  movups [r13+rax*1], xmm1
0000710a0d1d1b61  mov qword ptr [r15+0x48], 0x10
0000710a0d1d1b69  xor eax, eax
0000710a0d1d1b6b  mov r14d, 0x10
0000710a0d1d1b71  mov r12d, 0x200
0000710a0d1d1b77  cmp r14, r12
0000710a0d1d1b7a  cmc
0000710a0d1d1b7b  lahf
0000710a0d1d1b7c  seto al
0000710a0d1d1b7f  mov [r15+0x108], eax
0000710a0d1d1b86  mov eax, [r15+0x108]
0000710a0d1d1b8d  sahf
0000710a0d1d1b8e  jnz 0x0000710A0D1D1BC0
0000710a0d1d1b90  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d1b98  jz 0x0000710A0D1D2300
0000710a0d1d1b9e  nop [rax+rax*1], ax
0000710a0d1d1ba7  nop [rax+rax*1], eax
0000710a0d1d1baf  mov eax, 0x410480
0000710a0d1d1bb4  mov [r15+0x100], rax
0000710a0d1d1bbb  jmp 0x0000710A0CFFE110
0000710a0d1d1bc0  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d1bc8  jz 0x0000710A0D1D1EB0
0000710a0d1d1bce  nop [rax+rax*1], ax
0000710a0d1d1bd7  nop [rax+rax*1], eax
0000710a0d1d1bdf  mov eax, 0x410440
0000710a0d1d1be4  mov [r15+0x100], rax
0000710a0d1d1beb  jmp 0x0000710A0CFFE110
0000710a0d1d1bf0  int3
0000710a0d1d1bf1  call 0x0000710A0D00DC20
0000710a0d1d1bf6  jmp 0x0000710A0D1D19BE
0000710a0d1d1bfb  call 0x0000710A0D00C260
0000710a0d1d1c00  jmp 0x0000710A0D1D1A47
0000710a0d1d1c05  call 0x0000710A0D0D5D70
0000710a0d1d1c0a  jmp 0x0000710A0D1D1A5D
0000710a0d1d1c0f  sub rsp, 0x08
0000710a0d1d1c13  push rax
0000710a0d1d1c14  push rcx
0000710a0d1d1c15  push rdx
0000710a0d1d1c16  push rdi
0000710a0d1d1c17  push rsi
0000710a0d1d1c18  push r8
0000710a0d1d1c1a  push r9
0000710a0d1d1c1c  push r10
0000710a0d1d1c1e  push r11
0000710a0d1d1c20  sub rsp, 0xF0
0000710a0d1d1c27  vmovaps [rsp], xmm0
0000710a0d1d1c2c  vmovaps [rsp+0x10], xmm1
0000710a0d1d1c32  vmovaps [rsp+0x20], xmm2
0000710a0d1d1c38  vmovaps [rsp+0x30], xmm3
0000710a0d1d1c3e  vmovaps [rsp+0x40], xmm4
0000710a0d1d1c44  vmovaps [rsp+0x50], xmm5
0000710a0d1d1c4a  vmovaps [rsp+0x60], xmm6
0000710a0d1d1c50  vmovaps [rsp+0x70], xmm7
0000710a0d1d1c56  vmovaps [rsp+0x80], xmm8
0000710a0d1d1c5f  vmovaps [rsp+0x90], xmm9
0000710a0d1d1c68  vmovaps [rsp+0xA0], xmm10
0000710a0d1d1c71  vmovaps [rsp+0xB0], xmm11
0000710a0d1d1c7a  vmovaps [rsp+0xC0], xmm12
0000710a0d1d1c83  vmovaps [rsp+0xD0], xmm14
0000710a0d1d1c8c  vmovaps [rsp+0xE0], xmm15
0000710a0d1d1c95  sub rsp, 0x30
0000710a0d1d1c99  movaps [rsp], xmm13
0000710a0d1d1c9e  movaps [rsp+0x10], xmm12
0000710a0d1d1ca4  movaps [rsp+0x20], xmm1
0000710a0d1d1ca9  lea rdi, [rsp]
0000710a0d1d1cad  mov esi, 0x00
0000710a0d1d1cb2  mov rax, 0x64F334B05530
0000710a0d1d1cbc  call rax
0000710a0d1d1cbe  movaps xmm13, [rsp]
0000710a0d1d1cc3  add rsp, 0x30
0000710a0d1d1cc7  vmovaps xmm0, [rsp]
0000710a0d1d1ccc  vmovaps xmm1, [rsp+0x10]
0000710a0d1d1cd2  vmovaps xmm2, [rsp+0x20]
0000710a0d1d1cd8  vmovaps xmm3, [rsp+0x30]
0000710a0d1d1cde  vmovaps xmm4, [rsp+0x40]
0000710a0d1d1ce4  vmovaps xmm5, [rsp+0x50]
0000710a0d1d1cea  vmovaps xmm6, [rsp+0x60]
0000710a0d1d1cf0  vmovaps xmm7, [rsp+0x70]
0000710a0d1d1cf6  vmovaps xmm8, [rsp+0x80]
0000710a0d1d1cff  vmovaps xmm9, [rsp+0x90]
0000710a0d1d1d08  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d1d11  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d1d1a  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d1d23  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d1d2c  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d1d35  add rsp, 0xF0
0000710a0d1d1d3c  pop r11
0000710a0d1d1d3e  pop r10
0000710a0d1d1d40  pop r9
0000710a0d1d1d42  pop r8
0000710a0d1d1d44  pop rsi
0000710a0d1d1d45  pop rdi
0000710a0d1d1d46  pop rdx
0000710a0d1d1d47  pop rcx
0000710a0d1d1d48  pop rax
0000710a0d1d1d49  add rsp, 0x08
0000710a0d1d1d4d  jmp 0x0000710A0D1D1B21
0000710a0d1d1d52  call 0x0000710A0D00C380
0000710a0d1d1d57  jmp 0x0000710A0D1D1B34
0000710a0d1d1d5c  sub rsp, 0x08
0000710a0d1d1d60  push rax
0000710a0d1d1d61  push rcx
0000710a0d1d1d62  push rdx
0000710a0d1d1d63  push rdi
0000710a0d1d1d64  push rsi
0000710a0d1d1d65  push r8
0000710a0d1d1d67  push r9
0000710a0d1d1d69  push r10
0000710a0d1d1d6b  push r11
0000710a0d1d1d6d  sub rsp, 0xF0
0000710a0d1d1d74  vmovaps [rsp], xmm0
0000710a0d1d1d79  vmovaps [rsp+0x10], xmm2
0000710a0d1d1d7f  vmovaps [rsp+0x20], xmm3
0000710a0d1d1d85  vmovaps [rsp+0x30], xmm4
0000710a0d1d1d8b  vmovaps [rsp+0x40], xmm5
0000710a0d1d1d91  vmovaps [rsp+0x50], xmm6
0000710a0d1d1d97  vmovaps [rsp+0x60], xmm7
0000710a0d1d1d9d  vmovaps [rsp+0x70], xmm8
0000710a0d1d1da3  vmovaps [rsp+0x80], xmm9
0000710a0d1d1dac  vmovaps [rsp+0x90], xmm10
0000710a0d1d1db5  vmovaps [rsp+0xA0], xmm11
0000710a0d1d1dbe  vmovaps [rsp+0xB0], xmm12
0000710a0d1d1dc7  vmovaps [rsp+0xC0], xmm13
0000710a0d1d1dd0  vmovaps [rsp+0xD0], xmm14
0000710a0d1d1dd9  vmovaps [rsp+0xE0], xmm15
0000710a0d1d1de2  sub rsp, 0x30
0000710a0d1d1de6  movaps [rsp], xmm1
0000710a0d1d1dea  movaps [rsp+0x10], xmm14
0000710a0d1d1df0  movaps [rsp+0x20], xmm15
0000710a0d1d1df6  lea rdi, [rsp]
0000710a0d1d1dfa  mov esi, 0x00
0000710a0d1d1dff  mov rax, 0x64F334B05530
0000710a0d1d1e09  call rax
0000710a0d1d1e0b  movaps xmm1, [rsp]
0000710a0d1d1e0f  add rsp, 0x30
0000710a0d1d1e13  vmovaps xmm0, [rsp]
0000710a0d1d1e18  vmovaps xmm2, [rsp+0x10]
0000710a0d1d1e1e  vmovaps xmm3, [rsp+0x20]
0000710a0d1d1e24  vmovaps xmm4, [rsp+0x30]
0000710a0d1d1e2a  vmovaps xmm5, [rsp+0x40]
0000710a0d1d1e30  vmovaps xmm6, [rsp+0x50]
0000710a0d1d1e36  vmovaps xmm7, [rsp+0x60]
0000710a0d1d1e3c  vmovaps xmm8, [rsp+0x70]
0000710a0d1d1e42  vmovaps xmm9, [rsp+0x80]
0000710a0d1d1e4b  vmovaps xmm10, [rsp+0x90]
0000710a0d1d1e54  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d1e5d  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d1e66  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d1e6f  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d1e78  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d1e81  add rsp, 0xF0
0000710a0d1d1e88  pop r11
0000710a0d1d1e8a  pop r10
0000710a0d1d1e8c  pop r9
0000710a0d1d1e8e  pop r8
0000710a0d1d1e90  pop rsi
0000710a0d1d1e91  pop rdi
0000710a0d1d1e92  pop rdx
0000710a0d1d1e93  pop rcx
0000710a0d1d1e94  pop rax
0000710a0d1d1e95  add rsp, 0x08
0000710a0d1d1e99  jmp 0x0000710A0D1D1B4E
0000710a0d1d1e9e  call 0x0000710A0CFFF540
0000710a0d1d1ea3  jmp 0x0000710A0D1D1B61
0000710a0d1d1ea8  int3
0000710a0d1d1ea9  nop [rax], eax
0000710a0d1d1eb0  movaps xmm1, [r15+0x180]
0000710a0d1d1eb8  vpmovqd xmm15, xmm1
0000710a0d1d1ebe  pxor xmm14, xmm14
0000710a0d1d1ec3  punpcklqdq xmm15, xmm14
0000710a0d1d1ec8  movaps [r15+0x210], xmm15
0000710a0d1d1ed0  movq xmm15, qword ptr [r15+0x140]
0000710a0d1d1ed9  movq xmm14, qword ptr [r15+0x120]
0000710a0d1d1ee2  psubd xmm15, xmm14
0000710a0d1d1ee7  movq xmm15, xmm15
0000710a0d1d1eec  movaps xmm13, [r15+0x170]
0000710a0d1d1ef4  paddq xmm1, xmm13
0000710a0d1d1ef9  movaps [r15+0x180], xmm1
0000710a0d1d1f01  movq xmm1, qword ptr [r15+0x160]
0000710a0d1d1f0a  paddd xmm14, xmm1
0000710a0d1d1f0f  movq xmm14, xmm14
0000710a0d1d1f14  movq xmm14, xmm14
0000710a0d1d1f19  movaps [r15+0x120], xmm14
0000710a0d1d1f21  pmovzxdq xmm15, xmm15
0000710a0d1d1f27  psllq xmm15, 0x00
0000710a0d1d1f2d  movq xmm1, qword ptr [r15+0x210]
0000710a0d1d1f36  movq xmm14, qword ptr [r15+0x110]
0000710a0d1d1f3f  paddd xmm1, xmm14
0000710a0d1d1f44  movq xmm1, xmm1
0000710a0d1d1f48  vcvtuqq2pd xmm15, xmm15
0000710a0d1d1f4e  pmovzxdq xmm1, xmm1
0000710a0d1d1f53  psllq xmm1, 0x00
0000710a0d1d1f58  vcvtuqq2pd xmm1, xmm1
0000710a0d1d1f5e  movaps xmm14, [r15+0x150]
0000710a0d1d1f66  movaps xmm13, xmm15
0000710a0d1d1f6a  mulpd xmm13, xmm14
0000710a0d1d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d1f75  ptest xmm12, xmm12
0000710a0d1d1f7b  jnz 0x0000710A0D1D205E
0000710a0d1d1f81  movaps [r15+0x220], xmm13
0000710a0d1d1f89  mov rax, [r15+0x48]
0000710a0d1d1f8d  mov r14, [r15+0x50]
0000710a0d1d1f91  lea r12, [r14+rax*1]
0000710a0d1d1f95  movups [r13+r12*1], xmm13
0000710a0d1d1f9b  movaps xmm15, [r15+0x130]
0000710a0d1d1fa3  movaps xmm14, xmm1
0000710a0d1d1fa7  mulpd xmm14, xmm15
0000710a0d1d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
0000710a0d1d1fb2  ptest xmm13, xmm13
0000710a0d1d1fb8  jnz 0x0000710A0D1D21AC
0000710a0d1d1fbe  movaps [r15+0x210], xmm14
0000710a0d1d1fc6  mov r14, [r15+0x40]
0000710a0d1d1fca  lea r12, [r14+rax*1]
0000710a0d1d1fce  movups [r13+r12*1], xmm14
0000710a0d1d1fd4  lea r14, [rax+0x10]
0000710a0d1d1fd8  mov [r15+0x48], r14
0000710a0d1d1fdc  xor eax, eax
0000710a0d1d1fde  mov r12d, 0x200
0000710a0d1d1fe4  cmp r14, r12
0000710a0d1d1fe7  cmc
0000710a0d1d1fe8  lahf
0000710a0d1d1fe9  seto al
0000710a0d1d1fec  mov [r15+0x108], eax
0000710a0d1d1ff3  mov eax, [r15+0x108]
0000710a0d1d1ffa  sahf
0000710a0d1d1ffb  jnz 0x0000710A0D1D202D
0000710a0d1d1ffd  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d2005  jz 0x0000710A0D1D2300
0000710a0d1d200b  nop [rax+rax*1], ax
0000710a0d1d2014  nop [rax+rax*1], eax
0000710a0d1d201c  mov eax, 0x410480
0000710a0d1d2021  mov [r15+0x100], rax
0000710a0d1d2028  jmp 0x0000710A0CFFE110
0000710a0d1d202d  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d2035  jz 0x0000710A0D1D1EB0
0000710a0d1d203b  nop [rax+rax*1], ax
0000710a0d1d2044  nop [rax+rax*1], eax
0000710a0d1d204c  mov eax, 0x410440
0000710a0d1d2051  mov [r15+0x100], rax
0000710a0d1d2058  jmp 0x0000710A0CFFE110
0000710a0d1d205d  int3
0000710a0d1d205e  sub rsp, 0x08
0000710a0d1d2062  push rax
0000710a0d1d2063  push rcx
0000710a0d1d2064  push rdx
0000710a0d1d2065  push rdi
0000710a0d1d2066  push rsi
0000710a0d1d2067  push r8
0000710a0d1d2069  push r9
0000710a0d1d206b  push r10
0000710a0d1d206d  push r11
0000710a0d1d206f  sub rsp, 0xF0
0000710a0d1d2076  vmovaps [rsp], xmm0
0000710a0d1d207b  vmovaps [rsp+0x10], xmm1
0000710a0d1d2081  vmovaps [rsp+0x20], xmm2
0000710a0d1d2087  vmovaps [rsp+0x30], xmm3
0000710a0d1d208d  vmovaps [rsp+0x40], xmm4
0000710a0d1d2093  vmovaps [rsp+0x50], xmm5
0000710a0d1d2099  vmovaps [rsp+0x60], xmm6
0000710a0d1d209f  vmovaps [rsp+0x70], xmm7
0000710a0d1d20a5  vmovaps [rsp+0x80], xmm8
0000710a0d1d20ae  vmovaps [rsp+0x90], xmm9
0000710a0d1d20b7  vmovaps [rsp+0xA0], xmm10
0000710a0d1d20c0  vmovaps [rsp+0xB0], xmm11
0000710a0d1d20c9  vmovaps [rsp+0xC0], xmm12
0000710a0d1d20d2  vmovaps [rsp+0xD0], xmm14
0000710a0d1d20db  vmovaps [rsp+0xE0], xmm15
0000710a0d1d20e4  sub rsp, 0x30
0000710a0d1d20e8  movaps [rsp], xmm13
0000710a0d1d20ed  movaps [rsp+0x10], xmm15
0000710a0d1d20f3  movaps [rsp+0x20], xmm14
0000710a0d1d20f9  lea rdi, [rsp]
0000710a0d1d20fd  mov esi, 0x00
0000710a0d1d2102  mov rax, 0x64F334B05530
0000710a0d1d210c  call rax
0000710a0d1d210e  movaps xmm13, [rsp]
0000710a0d1d2113  add rsp, 0x30
0000710a0d1d2117  vmovaps xmm0, [rsp]
0000710a0d1d211c  vmovaps xmm1, [rsp+0x10]
0000710a0d1d2122  vmovaps xmm2, [rsp+0x20]
0000710a0d1d2128  vmovaps xmm3, [rsp+0x30]
0000710a0d1d212e  vmovaps xmm4, [rsp+0x40]
0000710a0d1d2134  vmovaps xmm5, [rsp+0x50]
0000710a0d1d213a  vmovaps xmm6, [rsp+0x60]
0000710a0d1d2140  vmovaps xmm7, [rsp+0x70]
0000710a0d1d2146  vmovaps xmm8, [rsp+0x80]
0000710a0d1d214f  vmovaps xmm9, [rsp+0x90]
0000710a0d1d2158  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d2161  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d216a  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d2173  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d217c  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d2185  add rsp, 0xF0
0000710a0d1d218c  pop r11
0000710a0d1d218e  pop r10
0000710a0d1d2190  pop r9
0000710a0d1d2192  pop r8
0000710a0d1d2194  pop rsi
0000710a0d1d2195  pop rdi
0000710a0d1d2196  pop rdx
0000710a0d1d2197  pop rcx
0000710a0d1d2198  pop rax
0000710a0d1d2199  add rsp, 0x08
0000710a0d1d219d  jmp 0x0000710A0D1D1F81
0000710a0d1d21a2  call 0x0000710A0D0C2240
0000710a0d1d21a7  jmp 0x0000710A0D1D1F9B
0000710a0d1d21ac  sub rsp, 0x08
0000710a0d1d21b0  push rax
0000710a0d1d21b1  push rcx
0000710a0d1d21b2  push rdx
0000710a0d1d21b3  push rdi
0000710a0d1d21b4  push rsi
0000710a0d1d21b5  push r8
0000710a0d1d21b7  push r9
0000710a0d1d21b9  push r10
0000710a0d1d21bb  push r11
0000710a0d1d21bd  sub rsp, 0xF0
0000710a0d1d21c4  vmovaps [rsp], xmm0
0000710a0d1d21c9  vmovaps [rsp+0x10], xmm1
0000710a0d1d21cf  vmovaps [rsp+0x20], xmm2
0000710a0d1d21d5  vmovaps [rsp+0x30], xmm3
0000710a0d1d21db  vmovaps [rsp+0x40], xmm4
0000710a0d1d21e1  vmovaps [rsp+0x50], xmm5
0000710a0d1d21e7  vmovaps [rsp+0x60], xmm6
0000710a0d1d21ed  vmovaps [rsp+0x70], xmm7
0000710a0d1d21f3  vmovaps [rsp+0x80], xmm8
0000710a0d1d21fc  vmovaps [rsp+0x90], xmm9
0000710a0d1d2205  vmovaps [rsp+0xA0], xmm10
0000710a0d1d220e  vmovaps [rsp+0xB0], xmm11
0000710a0d1d2217  vmovaps [rsp+0xC0], xmm12
0000710a0d1d2220  vmovaps [rsp+0xD0], xmm13
0000710a0d1d2229  vmovaps [rsp+0xE0], xmm15
0000710a0d1d2232  sub rsp, 0x30
0000710a0d1d2236  movaps [rsp], xmm14
0000710a0d1d223b  movaps [rsp+0x10], xmm1
0000710a0d1d2240  movaps [rsp+0x20], xmm15
0000710a0d1d2246  lea rdi, [rsp]
0000710a0d1d224a  mov esi, 0x00
0000710a0d1d224f  mov rax, 0x64F334B05530
0000710a0d1d2259  call rax
0000710a0d1d225b  movaps xmm14, [rsp]
0000710a0d1d2260  add rsp, 0x30
0000710a0d1d2264  vmovaps xmm0, [rsp]
0000710a0d1d2269  vmovaps xmm1, [rsp+0x10]
0000710a0d1d226f  vmovaps xmm2, [rsp+0x20]
0000710a0d1d2275  vmovaps xmm3, [rsp+0x30]
0000710a0d1d227b  vmovaps xmm4, [rsp+0x40]
0000710a0d1d2281  vmovaps xmm5, [rsp+0x50]
0000710a0d1d2287  vmovaps xmm6, [rsp+0x60]
0000710a0d1d228d  vmovaps xmm7, [rsp+0x70]
0000710a0d1d2293  vmovaps xmm8, [rsp+0x80]
0000710a0d1d229c  vmovaps xmm9, [rsp+0x90]
0000710a0d1d22a5  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d22ae  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d22b7  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d22c0  vmovaps xmm13, [rsp+0xD0]
0000710a0d1d22c9  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d22d2  add rsp, 0xF0
0000710a0d1d22d9  pop r11
0000710a0d1d22db  pop r10
0000710a0d1d22dd  pop r9
0000710a0d1d22df  pop r8
0000710a0d1d22e1  pop rsi
0000710a0d1d22e2  pop rdi
0000710a0d1d22e3  pop rdx
0000710a0d1d22e4  pop rcx
0000710a0d1d22e5  pop rax
0000710a0d1d22e6  add rsp, 0x08
0000710a0d1d22ea  jmp 0x0000710A0D1D1FBE
0000710a0d1d22ef  call 0x0000710A0D0C34C0
0000710a0d1d22f4  jmp 0x0000710A0D1D1FD4
0000710a0d1d22f9  int3
0000710a0d1d22fa  nop [rax+rax*1], ax
0000710a0d1d2300  mov rax, [r15+0x50]
0000710a0d1d2304  movups xmm1, [r13+rax*1]
0000710a0d1d230a  lea r14, [rax+0x10]
0000710a0d1d230e  movups xmm15, [r13+r14*1]
0000710a0d1d2314  mov qword ptr [r15+0x48], 0x00
0000710a0d1d231c  lea r14, [rax+0x40]
0000710a0d1d2320  movups xmm14, [r13+r14*1]
0000710a0d1d2326  lea r14, [rax+0x50]
0000710a0d1d232a  movups xmm13, [r13+r14*1]
0000710a0d1d2330  lea r14, [rax+0x80]
0000710a0d1d2337  movups xmm12, [r13+r14*1]
0000710a0d1d233d  lea r14, [rax+0x90]
0000710a0d1d2344  movups xmm11, [r13+r14*1]
0000710a0d1d234a  mov r14, [r15+0xF8]
0000710a0d1d2351  movups [r13+r14*1], xmm1
0000710a0d1d2357  lea r12, [rax+0x20]
0000710a0d1d235b  movups xmm1, [r13+r12*1]
0000710a0d1d2361  lea r12, [rax+0x30]
0000710a0d1d2365  movups xmm10, [r13+r12*1]
0000710a0d1d236b  lea r12, [rax+0xC0]
0000710a0d1d2372  movups xmm9, [r13+r12*1]
0000710a0d1d2378  lea r12, [rax+0xD0]
0000710a0d1d237f  movups xmm8, [r13+r12*1]
0000710a0d1d2385  lea r12, [rax+0x100]
0000710a0d1d238c  movups xmm7, [r13+r12*1]
0000710a0d1d2392  lea r12, [rax+0x110]
0000710a0d1d2399  movups xmm6, [r13+r12*1]
0000710a0d1d239f  lea r12, [rax+0x140]
0000710a0d1d23a6  movups xmm5, [r13+r12*1]
0000710a0d1d23ac  lea r12, [rax+0x150]
0000710a0d1d23b3  movups xmm4, [r13+r12*1]
0000710a0d1d23b9  lea r12, [r14+0xB0]
0000710a0d1d23c0  movups [r13+r12*1], xmm10
0000710a0d1d23c6  lea r12, [r14+0xC0]
0000710a0d1d23cd  movups [r13+r12*1], xmm1
0000710a0d1d23d3  lea r12, [rax+0x180]
0000710a0d1d23da  movups xmm1, [r13+r12*1]
0000710a0d1d23e0  lea r12, [rax+0x190]
0000710a0d1d23e7  movups xmm10, [r13+r12*1]
0000710a0d1d23ed  lea r12, [rax+0x1C0]
0000710a0d1d23f4  movups xmm3, [r13+r12*1]
0000710a0d1d23fa  lea r12, [rax+0x1D0]
0000710a0d1d2401  movups xmm2, [r13+r12*1]
0000710a0d1d2407  lea r12, [rax+0x60]
0000710a0d1d240b  vmovaps [rsp+0x10], xmm1
0000710a0d1d2411  movups xmm1, [r13+r12*1]
0000710a0d1d2417  lea r12, [rax+0x70]
0000710a0d1d241b  vmovaps [rsp+0x20], xmm1
0000710a0d1d2421  movups xmm1, [r13+r12*1]
0000710a0d1d2427  lea r12, [r14+0x70]
0000710a0d1d242b  movups [r13+r12*1], xmm10
0000710a0d1d2431  lea r12, [r14+0x80]
0000710a0d1d2438  vmovaps xmm10, [rsp+0x10]
0000710a0d1d243e  movups [r13+r12*1], xmm10
0000710a0d1d2444  lea r12, [rax+0xA0]
0000710a0d1d244b  movups xmm10, [r13+r12*1]
0000710a0d1d2451  lea r12, [rax+0xB0]
0000710a0d1d2458  vmovaps [rsp+0x10], xmm1
0000710a0d1d245e  movups xmm1, [r13+r12*1]
0000710a0d1d2464  lea r12, [r14+0x90]
0000710a0d1d246b  movups [r13+r12*1], xmm2
0000710a0d1d2471  lea r12, [r14+0xA0]
0000710a0d1d2478  movups [r13+r12*1], xmm3
0000710a0d1d247e  lea r12, [rax+0xE0]
0000710a0d1d2485  movups xmm3, [r13+r12*1]
0000710a0d1d248b  lea r12, [rax+0xF0]
0000710a0d1d2492  movups xmm2, [r13+r12*1]
0000710a0d1d2498  lea r12, [rax+0x120]
0000710a0d1d249f  vmovaps [rsp+0x30], xmm1
0000710a0d1d24a5  movups xmm1, [r13+r12*1]
0000710a0d1d24ab  lea r12, [rax+0x130]
0000710a0d1d24b2  vmovaps [rsp+0x40], xmm1
0000710a0d1d24b8  movups xmm1, [r13+r12*1]
0000710a0d1d24be  vmovaps [rsp+0x50], xmm1
0000710a0d1d24c4  vmovaps xmm1, [rsp+0x40]
0000710a0d1d24ca  movaps [r15+0x190], xmm1
0000710a0d1d24d2  lea r12, [rax+0x160]
0000710a0d1d24d9  vmovaps [rsp+0x40], xmm1
0000710a0d1d24df  movups xmm1, [r13+r12*1]
0000710a0d1d24e5  lea r12, [rax+0x170]
0000710a0d1d24ec  vmovaps [rsp+0x60], xmm1
0000710a0d1d24f2  movups xmm1, [r13+r12*1]
0000710a0d1d24f8  lea r12, [rax+0x1A0]
0000710a0d1d24ff  vmovaps [rsp+0x70], xmm1
0000710a0d1d2505  movups xmm1, [r13+r12*1]
0000710a0d1d250b  lea r12, [rax+0x1B0]
0000710a0d1d2512  vmovaps [rsp+0x80], xmm1
0000710a0d1d251b  movups xmm1, [r13+r12*1]
0000710a0d1d2521  lea r12, [rax+0x1E0]
0000710a0d1d2528  vmovaps [rsp+0x90], xmm1
0000710a0d1d2531  movups xmm1, [r13+r12*1]
0000710a0d1d2537  lea r12, [rax+0x1F0]
0000710a0d1d253e  vmovaps [rsp+0xA0], xmm1
0000710a0d1d2547  movups xmm1, [r13+r12*1]
0000710a0d1d254d  mov qword ptr [r15+0x50], 0x432190
0000710a0d1d2555  lea rax, [r14+0x50]
0000710a0d1d2559  vmovaps [rsp+0xB0], xmm1
0000710a0d1d2562  vmovaps xmm1, [rsp+0x60]
0000710a0d1d2568  movups [r13+rax*1], xmm1
0000710a0d1d256e  lea rax, [r14+0x60]
0000710a0d1d2572  movups [r13+rax*1], xmm5
0000710a0d1d2578  lea rax, [r14+0x40]
0000710a0d1d257c  vmovaps xmm1, [rsp+0x70]
0000710a0d1d2582  movups [r13+rax*1], xmm1
0000710a0d1d2588  lea rax, [r14+0x20]
0000710a0d1d258c  vmovaps xmm1, [rsp+0xA0]
0000710a0d1d2595  movups [r13+rax*1], xmm1
0000710a0d1d259b  lea rax, [r14+0x30]
0000710a0d1d259f  vmovaps xmm1, [rsp+0x90]
0000710a0d1d25a8  movups [r13+rax*1], xmm1
0000710a0d1d25ae  lea rax, [r14+0x10]
0000710a0d1d25b2  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d25bb  movups [r13+rax*1], xmm1
0000710a0d1d25c1  mov rax, [r15+0x40]
0000710a0d1d25c5  vxorps xmm1, xmm1, xmm1
0000710a0d1d25c9  vpbroadcastq xmm1, xmm1
0000710a0d1d25ce  vxorps xmm5, xmm5, xmm5
0000710a0d1d25d2  vpbroadcastq xmm5, xmm5
0000710a0d1d25d7  lea r12, [rax+0x30]
0000710a0d1d25db  mov r11, [r13+r12*1]
0000710a0d1d25e0  lea r12, [rax+0x38]
0000710a0d1d25e4  mov r10, [r13+r12*1]
0000710a0d1d25e9  vmovaps [rsp+0x60], xmm1
0000710a0d1d25ef  movq xmm1, r11
0000710a0d1d25f4  vmovaps [rsp+0x70], xmm1
0000710a0d1d25fa  movq xmm1, r10
0000710a0d1d25ff  vmovaps [rsp+0x90], xmm1
0000710a0d1d2608  vmovaps xmm1, [rsp+0x70]
0000710a0d1d260e  movq xmm1, xmm1
0000710a0d1d2612  vmovaps [rsp+0x70], xmm1
0000710a0d1d2618  vmovaps xmm1, [rsp+0x90]
0000710a0d1d2621  movq xmm1, xmm1
0000710a0d1d2625  vmovaps [rsp+0x90], xmm1
0000710a0d1d262e  movq xmm1, xmm1
0000710a0d1d2632  movaps [r15+0x270], xmm1
0000710a0d1d263a  vmovaps [rsp+0xA0], xmm7
0000710a0d1d2643  vmovaps xmm1, [rsp+0xA0]
0000710a0d1d264c  por xmm7, xmm1
0000710a0d1d2650  lea r12, [rax+0x20]
0000710a0d1d2654  mov r11, [r13+r12*1]
0000710a0d1d2659  lea r12, [rax+0x28]
0000710a0d1d265d  mov r10, [r13+r12*1]
0000710a0d1d2662  movq xmm1, r11
0000710a0d1d2667  vmovaps [rsp+0xA0], xmm1
0000710a0d1d2670  movq xmm1, r10
0000710a0d1d2675  vmovaps [rsp+0xB0], xmm1
0000710a0d1d267e  vmovaps xmm1, [rsp+0xA0]
0000710a0d1d2687  movq xmm1, xmm1
0000710a0d1d268b  vmovaps [rsp+0xA0], xmm1
0000710a0d1d2694  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d269d  movq xmm1, xmm1
0000710a0d1d26a1  vmovaps [rsp+0xB0], xmm2
0000710a0d1d26aa  vmovaps [rsp+0xC0], xmm1
0000710a0d1d26b3  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d26bc  por xmm2, xmm1
0000710a0d1d26c0  vmovaps [rsp+0xB0], xmm3
0000710a0d1d26c9  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d26d2  por xmm3, xmm1
0000710a0d1d26d6  vmovaps [rsp+0xB0], xmm4
0000710a0d1d26df  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d26e8  por xmm4, xmm1
0000710a0d1d26ec  vmovaps [rsp+0xB0], xmm9
0000710a0d1d26f5  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d26fe  por xmm9, xmm1
0000710a0d1d2703  lea r12, [rax+0x10]
0000710a0d1d2707  mov r11, [r13+r12*1]
0000710a0d1d270c  lea r12, [rax+0x18]
0000710a0d1d2710  mov r10, [r13+r12*1]
0000710a0d1d2715  movq xmm1, r11
0000710a0d1d271a  vmovaps [rsp+0xB0], xmm1
0000710a0d1d2723  movq xmm1, r10
0000710a0d1d2728  vmovaps [rsp+0xD0], xmm1
0000710a0d1d2731  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d273a  movq xmm1, xmm1
0000710a0d1d273e  vmovaps [rsp+0xB0], xmm1
0000710a0d1d2747  vmovaps xmm1, [rsp+0xD0]
0000710a0d1d2750  movq xmm1, xmm1
0000710a0d1d2754  vmovaps [rsp+0xD0], xmm1
0000710a0d1d275d  vmovaps xmm1, [rsp+0x80]
0000710a0d1d2766  vmovaps [rsp+0xE0], xmm15
0000710a0d1d276f  vmovaps xmm15, [rsp+0x80]
0000710a0d1d2778  por xmm1, xmm15
0000710a0d1d277d  vmovaps xmm15, [rsp+0x10]
0000710a0d1d2783  vmovaps [rsp+0x80], xmm1
0000710a0d1d278c  vmovaps xmm1, [rsp+0x10]
0000710a0d1d2792  por xmm15, xmm1
0000710a0d1d2797  vmovaps xmm1, [rsp+0x20]
0000710a0d1d279d  vmovaps [rsp+0x10], xmm15
0000710a0d1d27a3  vmovaps xmm15, [rsp+0x20]
0000710a0d1d27a9  por xmm1, xmm15
0000710a0d1d27ae  vmovaps [rsp+0x20], xmm6
0000710a0d1d27b4  vmovaps xmm15, [rsp+0x20]
0000710a0d1d27ba  por xmm6, xmm15
0000710a0d1d27bf  vmovaps [rsp+0x20], xmm11
0000710a0d1d27c5  vmovaps xmm15, [rsp+0x20]
0000710a0d1d27cb  por xmm11, xmm15
0000710a0d1d27d0  vmovaps [rsp+0x20], xmm13
0000710a0d1d27d6  vmovaps xmm15, [rsp+0x20]
0000710a0d1d27dc  por xmm13, xmm15
0000710a0d1d27e1  vmovaps [rsp+0x20], xmm14
0000710a0d1d27e7  vmovaps xmm15, [rsp+0x20]
0000710a0d1d27ed  por xmm14, xmm15
0000710a0d1d27f2  mov r12, [r13+rax*1]
0000710a0d1d27f7  vmovq xmm15, r12
0000710a0d1d27fc  vpbroadcastq xmm15, xmm15
0000710a0d1d2801  vmovaps [rsp+0x20], xmm1
0000710a0d1d2807  vxorps xmm1, xmm1, xmm1
0000710a0d1d280b  vpbroadcastq xmm1, xmm1
0000710a0d1d2810  vmovaps [rsp+0xF0], xmm1
0000710a0d1d2819  movups xmm1, [r13+r14*1]
0000710a0d1d281f  vmovaps [rsp+0x100], xmm1
0000710a0d1d2828  vxorps xmm1, xmm1, xmm1
0000710a0d1d282c  vpbroadcastq xmm1, xmm1
0000710a0d1d2831  lea r12, [rax+0x08]
0000710a0d1d2835  mov rax, [r13+r12*1]
0000710a0d1d283a  vmovaps [rsp+0x110], xmm1
0000710a0d1d2843  movq xmm1, rax
0000710a0d1d2848  movaps [r15+0x240], xmm1
0000710a0d1d2850  mov qword ptr [r15+0x60], 0x432190
0000710a0d1d2858  mov qword ptr [r15+0x58], 0x40
0000710a0d1d2860  vmovaps xmm1, [rsp+0x60]
0000710a0d1d2866  vmovaps [rsp+0x60], xmm15
0000710a0d1d286c  vmovaps xmm15, [rsp+0x100]
0000710a0d1d2875  vmovaps [rsp+0x100], xmm14
0000710a0d1d287e  vmovaps xmm14, [rsp+0x60]
0000710a0d1d2884  vmovaps [rsp+0x60], xmm13
0000710a0d1d288a  vmovaps [rsp+0x120], xmm12
0000710a0d1d2893  movaps xmm13, xmm1
0000710a0d1d2897  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d289c  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d28a2  vptest xmm12, xmm12
0000710a0d1d28a7  jnz 0x0000710A0D1D3482
0000710a0d1d28ad  vmovaps xmm1, [rsp+0xE0]
0000710a0d1d28b6  movaps xmm15, xmm5
0000710a0d1d28ba  vfmadd231pd xmm15, xmm1, xmm14
0000710a0d1d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
0000710a0d1d28c5  vptest xmm12, xmm12
0000710a0d1d28ca  jnz 0x0000710A0D1D35DB
0000710a0d1d28d0  vmovaps xmm12, [rsp+0x50]
0000710a0d1d28d6  vmovaps xmm5, [rsp+0x50]
0000710a0d1d28dc  por xmm12, xmm5
0000710a0d1d28e1  vmovaps xmm5, [rsp+0x30]
0000710a0d1d28e7  vmovaps [rsp+0x50], xmm1
0000710a0d1d28ed  vmovaps xmm1, [rsp+0x30]
0000710a0d1d28f3  por xmm5, xmm1
0000710a0d1d28f7  vmovaps [rsp+0x30], xmm10
0000710a0d1d28fd  vmovaps xmm1, [rsp+0x30]
0000710a0d1d2903  por xmm10, xmm1
0000710a0d1d2908  vmovaps [rsp+0x30], xmm8
0000710a0d1d290e  vmovaps xmm1, [rsp+0x30]
0000710a0d1d2914  por xmm8, xmm1
0000710a0d1d2919  vmovaps xmm1, [rsp+0x120]
0000710a0d1d2922  vmovaps [rsp+0x30], xmm15
0000710a0d1d2928  vmovaps xmm15, [rsp+0x120]
0000710a0d1d2931  por xmm1, xmm15
0000710a0d1d2936  vmovaps xmm15, [rsp+0x50]
0000710a0d1d293c  vmovaps [rsp+0xE0], xmm1
0000710a0d1d2945  vmovaps xmm1, [rsp+0x50]
0000710a0d1d294b  por xmm15, xmm1
0000710a0d1d2950  lea rax, [r14+0xC0]
0000710a0d1d2957  movups xmm1, [r13+rax*1]
0000710a0d1d295d  xor eax, eax
0000710a0d1d295f  mov r12d, 0x40
0000710a0d1d2965  mov r11d, 0x200
0000710a0d1d296b  cmp r12, r11
0000710a0d1d296e  cmc
0000710a0d1d296f  lahf
0000710a0d1d2970  seto al
0000710a0d1d2973  mov [r15+0x108], eax
0000710a0d1d297a  vmovaps [rsp+0x50], xmm1
0000710a0d1d2980  vmovaps xmm1, [rsp+0xF0]
0000710a0d1d2989  vmovaps [rsp+0xF0], xmm15
0000710a0d1d2992  vmovaps xmm15, [rsp+0x50]
0000710a0d1d2998  vmovaps [rsp+0x50], xmm13
0000710a0d1d299e  vmovaps [rsp+0x120], xmm12
0000710a0d1d29a7  movaps xmm13, xmm1
0000710a0d1d29ab  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d29b6  vptest xmm12, xmm12
0000710a0d1d29bb  jnz 0x0000710A0D1D373D
0000710a0d1d29c1  lea rax, [r14+0xB0]
0000710a0d1d29c8  movups xmm1, [r13+rax*1]
0000710a0d1d29ce  vmovaps xmm15, [rsp+0x110]
0000710a0d1d29d7  vmovaps [rsp+0x110], xmm13
0000710a0d1d29e0  movaps xmm12, xmm15
0000710a0d1d29e4  vfmadd231pd xmm12, xmm1, xmm14
0000710a0d1d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
0000710a0d1d29ef  vptest xmm13, xmm13
0000710a0d1d29f4  jnz 0x0000710A0D1D38A0
0000710a0d1d29fa  vmovaps xmm1, [rsp+0x100]
0000710a0d1d2a03  vmovaps xmm15, [rsp+0x100]
0000710a0d1d2a0c  por xmm1, xmm15
0000710a0d1d2a11  movaps [r15+0x210], xmm1
0000710a0d1d2a19  vmovaps xmm15, [rsp+0x60]
0000710a0d1d2a1f  vmovaps xmm14, [rsp+0x60]
0000710a0d1d2a25  por xmm15, xmm14
0000710a0d1d2a2a  movaps [r15+0x1C0], xmm15
0000710a0d1d2a32  vmovaps [rsp+0x60], xmm11
0000710a0d1d2a38  vmovaps xmm14, [rsp+0x60]
0000710a0d1d2a3e  por xmm11, xmm14
0000710a0d1d2a43  movaps [r15+0x280], xmm11
0000710a0d1d2a4b  vmovaps [rsp+0x60], xmm6
0000710a0d1d2a51  vmovaps xmm14, [rsp+0x60]
0000710a0d1d2a57  por xmm6, xmm14
0000710a0d1d2a5c  movaps [r15+0x2A0], xmm6
0000710a0d1d2a64  vmovaps xmm14, [rsp+0x20]
0000710a0d1d2a6a  vmovaps xmm13, [rsp+0x20]
0000710a0d1d2a70  por xmm14, xmm13
0000710a0d1d2a75  movaps [r15+0x2E0], xmm14
0000710a0d1d2a7d  vmovaps xmm13, [rsp+0x10]
0000710a0d1d2a83  vmovaps [rsp+0x20], xmm1
0000710a0d1d2a89  vmovaps xmm1, [rsp+0x10]
0000710a0d1d2a8f  por xmm13, xmm1
0000710a0d1d2a94  movaps [r15+0x1F0], xmm13
0000710a0d1d2a9c  vmovaps xmm1, [rsp+0xF0]
0000710a0d1d2aa5  vmovaps [rsp+0x10], xmm15
0000710a0d1d2aab  vmovaps xmm15, [rsp+0xF0]
0000710a0d1d2ab4  por xmm1, xmm15
0000710a0d1d2ab9  movaps [r15+0x250], xmm1
0000710a0d1d2ac1  vmovaps xmm1, [rsp+0xE0]
0000710a0d1d2aca  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d2ad3  por xmm1, xmm15
0000710a0d1d2ad8  movaps [r15+0x260], xmm1
0000710a0d1d2ae0  vmovaps [rsp+0x60], xmm8
0000710a0d1d2ae6  vmovaps xmm15, [rsp+0x60]
0000710a0d1d2aec  por xmm8, xmm15
0000710a0d1d2af1  movaps [r15+0x290], xmm8
0000710a0d1d2af9  vmovaps [rsp+0x60], xmm10
0000710a0d1d2aff  vmovaps xmm15, [rsp+0x60]
0000710a0d1d2b05  por xmm10, xmm15
0000710a0d1d2b0a  movaps [r15+0x2C0], xmm10
0000710a0d1d2b12  movq xmm15, qword ptr [r15+0x240]
0000710a0d1d2b1b  vmovaps [rsp+0x60], xmm15
0000710a0d1d2b21  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d2b27  vmovaps [rsp+0xE0], xmm1
0000710a0d1d2b30  vmovaps xmm1, [rsp+0x50]
0000710a0d1d2b36  vmovaps [rsp+0x50], xmm15
0000710a0d1d2b3c  vmovaps xmm15, [rsp+0x20]
0000710a0d1d2b42  vmovaps [rsp+0x20], xmm14
0000710a0d1d2b48  vmovaps xmm14, [rsp+0x50]
0000710a0d1d2b4e  vmovaps [rsp+0x50], xmm13
0000710a0d1d2b54  vmovaps [rsp+0xF0], xmm12
0000710a0d1d2b5d  movaps xmm13, xmm1
0000710a0d1d2b61  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d2b6c  vptest xmm12, xmm12
0000710a0d1d2b71  jnz 0x0000710A0D1D39F9
0000710a0d1d2b77  vmovaps xmm1, [rsp+0x60]
0000710a0d1d2b7d  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d2b83  vmovaps xmm15, [rsp+0x110]
0000710a0d1d2b8c  vmovaps xmm14, [rsp+0x20]
0000710a0d1d2b92  vmovaps [rsp+0x20], xmm13
0000710a0d1d2b98  movaps xmm12, xmm15
0000710a0d1d2b9c  vfmadd231pd xmm12, xmm14, xmm1
0000710a0d1d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
0000710a0d1d2ba7  vptest xmm13, xmm13
0000710a0d1d2bac  jnz 0x0000710A0D1D3B52
0000710a0d1d2bb2  vmovaps xmm1, [rsp+0x60]
0000710a0d1d2bb8  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d2bbe  vmovaps xmm15, [rsp+0x30]
0000710a0d1d2bc4  vmovaps xmm14, [rsp+0x10]
0000710a0d1d2bca  vmovaps [rsp+0x10], xmm12
0000710a0d1d2bd0  movaps xmm13, xmm15
0000710a0d1d2bd4  vfmadd231pd xmm13, xmm14, xmm1
0000710a0d1d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d2bdf  vptest xmm12, xmm12
0000710a0d1d2be4  jnz 0x0000710A0D1D3CAB
0000710a0d1d2bea  vmovaps [rsp+0x30], xmm5
0000710a0d1d2bf0  vmovaps xmm1, [rsp+0x30]
0000710a0d1d2bf6  por xmm5, xmm1
0000710a0d1d2bfa  movaps [r15+0x1D0], xmm5
0000710a0d1d2c02  vmovaps xmm1, [rsp+0x60]
0000710a0d1d2c08  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d2c0e  vmovaps xmm15, [rsp+0xF0]
0000710a0d1d2c17  vmovaps xmm14, [rsp+0x50]
0000710a0d1d2c1d  vmovaps [rsp+0x30], xmm13
0000710a0d1d2c23  movaps xmm12, xmm15
0000710a0d1d2c27  vfmadd231pd xmm12, xmm14, xmm1
0000710a0d1d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
0000710a0d1d2c32  vptest xmm13, xmm13
0000710a0d1d2c37  jnz 0x0000710A0D1D3E04
0000710a0d1d2c3d  vmovaps xmm1, [rsp+0x80]
0000710a0d1d2c46  vmovaps xmm15, [rsp+0x80]
0000710a0d1d2c4f  por xmm1, xmm15
0000710a0d1d2c54  movaps [r15+0x200], xmm1
0000710a0d1d2c5c  vmovaps xmm15, [rsp+0x120]
0000710a0d1d2c65  vmovaps xmm14, [rsp+0x120]
0000710a0d1d2c6e  por xmm15, xmm14
0000710a0d1d2c73  movaps [r15+0x1E0], xmm15
0000710a0d1d2c7b  vmovaps [rsp+0x50], xmm4
0000710a0d1d2c81  vmovaps xmm13, [rsp+0x50]
0000710a0d1d2c87  por xmm4, xmm13
0000710a0d1d2c8c  movaps [r15+0x2B0], xmm4
0000710a0d1d2c94  vmovaps [rsp+0x50], xmm3
0000710a0d1d2c9a  vmovaps xmm13, [rsp+0x50]
0000710a0d1d2ca0  por xmm3, xmm13
0000710a0d1d2ca5  movaps [r15+0x300], xmm3
0000710a0d1d2cad  vmovaps xmm15, [rsp+0xB0]
0000710a0d1d2cb6  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d2cbc  vmovaps xmm3, [rsp+0x20]
0000710a0d1d2cc2  vmovaps [rsp+0x20], xmm1
0000710a0d1d2cc8  vmovaps xmm1, [rsp+0xE0]
0000710a0d1d2cd1  vmovaps [rsp+0x50], xmm14
0000710a0d1d2cd7  vmovaps [rsp+0x60], xmm13
0000710a0d1d2cdd  movaps xmm14, xmm3
0000710a0d1d2ce1  vfmadd231pd xmm14, xmm1, xmm15
0000710a0d1d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
0000710a0d1d2cec  vptest xmm13, xmm13
0000710a0d1d2cf1  jnz 0x0000710A0D1D3F5D
0000710a0d1d2cf7  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d2d00  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d2d06  vmovaps xmm15, [rsp+0x10]
0000710a0d1d2d0c  movaps xmm13, xmm15
0000710a0d1d2d10  vfmadd231pd xmm13, xmm10, xmm1
0000710a0d1d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
0000710a0d1d2d1b  vptest xmm3, xmm3
0000710a0d1d2d20  jnz 0x0000710A0D1D40B5
0000710a0d1d2d26  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d2d2f  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d2d35  vmovaps xmm15, [rsp+0x30]
0000710a0d1d2d3b  movaps xmm10, xmm15
0000710a0d1d2d3f  vfmadd231pd xmm10, xmm11, xmm1
0000710a0d1d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
0000710a0d1d2d4a  vptest xmm3, xmm3
0000710a0d1d2d4f  jnz 0x0000710A0D1D420E
0000710a0d1d2d55  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d2d5e  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d2d64  movaps xmm15, xmm12
0000710a0d1d2d68  vfmadd231pd xmm15, xmm5, xmm1
0000710a0d1d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
0000710a0d1d2d73  vptest xmm11, xmm11
0000710a0d1d2d78  jnz 0x0000710A0D1D4367
0000710a0d1d2d7e  vmovaps [rsp+0x10], xmm9
0000710a0d1d2d84  vmovaps xmm1, [rsp+0x10]
0000710a0d1d2d8a  por xmm9, xmm1
0000710a0d1d2d8f  movaps [r15+0x180], xmm9
0000710a0d1d2d97  vmovaps [rsp+0x10], xmm2
0000710a0d1d2d9d  vmovaps xmm1, [rsp+0x10]
0000710a0d1d2da3  por xmm2, xmm1
0000710a0d1d2da7  movaps [r15+0x2D0], xmm2
0000710a0d1d2daf  vmovaps xmm12, [rsp+0xD0]
0000710a0d1d2db8  vpermilpd xmm12, xmm12, 0x00
0000710a0d1d2dbe  vmovaps xmm11, [rsp+0x60]
0000710a0d1d2dc4  movaps xmm5, xmm13
0000710a0d1d2dc8  vfmadd231pd xmm5, xmm11, xmm12
0000710a0d1d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
0000710a0d1d2dd2  vptest xmm3, xmm3
0000710a0d1d2dd7  jnz 0x0000710A0D1D44BF
0000710a0d1d2ddd  vmovaps xmm13, [rsp+0xD0]
0000710a0d1d2de6  vpermilpd xmm13, xmm13, 0x00
0000710a0d1d2dec  movaps xmm12, xmm14
0000710a0d1d2df0  vfmadd231pd xmm12, xmm9, xmm13
0000710a0d1d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
0000710a0d1d2dfb  vptest xmm11, xmm11
0000710a0d1d2e00  jnz 0x0000710A0D1D4617
0000710a0d1d2e06  lea rax, [r14+0x80]
0000710a0d1d2e0d  movups xmm14, [r13+rax*1]
0000710a0d1d2e13  movaps [r15+0x2F0], xmm14
0000710a0d1d2e1b  vmovaps xmm13, [rsp+0xD0]
0000710a0d1d2e24  vpermilpd xmm13, xmm13, 0x00
0000710a0d1d2e2a  movaps xmm11, xmm10
0000710a0d1d2e2e  vfmadd231pd xmm11, xmm8, xmm13
0000710a0d1d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
0000710a0d1d2e39  vptest xmm9, xmm9
0000710a0d1d2e3e  jnz 0x0000710A0D1D477B
0000710a0d1d2e44  vmovaps xmm13, [rsp+0xD0]
0000710a0d1d2e4d  vpermilpd xmm13, xmm13, 0x00
0000710a0d1d2e53  movaps xmm10, xmm15
0000710a0d1d2e57  vfmadd231pd xmm10, xmm1, xmm13
0000710a0d1d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
0000710a0d1d2e62  vptest xmm9, xmm9
0000710a0d1d2e67  jnz 0x0000710A0D1D48D5
0000710a0d1d2e6d  vmovaps [rsp+0x10], xmm7
0000710a0d1d2e73  vmovaps xmm1, [rsp+0x10]
0000710a0d1d2e79  por xmm7, xmm1
0000710a0d1d2e7d  movaps [r15+0x160], xmm7
0000710a0d1d2e85  lea rax, [r14+0x40]
0000710a0d1d2e89  movups xmm1, [r13+rax*1]
0000710a0d1d2e8f  lea rax, [r14+0x50]
0000710a0d1d2e93  movups xmm15, [r13+rax*1]
0000710a0d1d2e99  movaps [r15+0x1B0], xmm1
0000710a0d1d2ea1  movaps [r15+0x1A0], xmm15
0000710a0d1d2ea9  vmovaps xmm13, [rsp+0xA0]
0000710a0d1d2eb2  vpermilpd xmm13, xmm13, 0x00
0000710a0d1d2eb8  vmovaps xmm9, [rsp+0x40]
0000710a0d1d2ebe  movaps xmm8, xmm5
0000710a0d1d2ec2  vfmadd231pd xmm8, xmm9, xmm13
0000710a0d1d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
0000710a0d1d2ecd  vptest xmm3, xmm3
0000710a0d1d2ed2  jnz 0x0000710A0D1D4A42
0000710a0d1d2ed8  vmovaps xmm13, [rsp+0xA0]
0000710a0d1d2ee1  vpermilpd xmm13, xmm13, 0x00
0000710a0d1d2ee7  movaps xmm9, xmm12
0000710a0d1d2eeb  vfmadd231pd xmm9, xmm7, xmm13
0000710a0d1d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
0000710a0d1d2ef6  vptest xmm5, xmm5
0000710a0d1d2efb  jnz 0x0000710A0D1D4B9B
0000710a0d1d2f01  vmovaps xmm13, [rsp+0xA0]
0000710a0d1d2f0a  vpermilpd xmm13, xmm13, 0x00
0000710a0d1d2f10  movaps xmm12, xmm11
0000710a0d1d2f14  vfmadd231pd xmm12, xmm6, xmm13
0000710a0d1d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
0000710a0d1d2f1f  vptest xmm7, xmm7
0000710a0d1d2f24  jnz 0x0000710A0D1D4CF4
0000710a0d1d2f2a  vmovaps xmm13, [rsp+0xA0]
0000710a0d1d2f33  vpermilpd xmm13, xmm13, 0x00
0000710a0d1d2f39  vmovaps xmm11, [rsp+0x50]
0000710a0d1d2f3f  movaps xmm7, xmm10
0000710a0d1d2f43  vfmadd231pd xmm7, xmm11, xmm13
0000710a0d1d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
0000710a0d1d2f4d  vptest xmm6, xmm6
0000710a0d1d2f52  jnz 0x0000710A0D1D4E4D
0000710a0d1d2f58  lea rax, [r14+0x60]
0000710a0d1d2f5c  movups xmm13, [r13+rax*1]
0000710a0d1d2f62  lea rax, [r14+0x70]
0000710a0d1d2f66  movups xmm11, [r13+rax*1]
0000710a0d1d2f6c  movaps [r15+0x150], xmm13
0000710a0d1d2f74  movaps [r15+0x120], xmm11
0000710a0d1d2f7c  vmovaps xmm10, [rsp+0xC0]
0000710a0d1d2f85  vpermilpd xmm10, xmm10, 0x00
0000710a0d1d2f8b  movaps xmm6, xmm8
0000710a0d1d2f8f  vfmadd231pd xmm6, xmm15, xmm10
0000710a0d1d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
0000710a0d1d2f99  vptest xmm5, xmm5
0000710a0d1d2f9e  jnz 0x0000710A0D1D4FB9
0000710a0d1d2fa4  vmovaps xmm15, [rsp+0xC0]
0000710a0d1d2fad  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d2fb3  movaps xmm10, xmm9
0000710a0d1d2fb7  vfmadd231pd xmm10, xmm13, xmm15
0000710a0d1d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
0000710a0d1d2fc2  vptest xmm8, xmm8
0000710a0d1d2fc7  jnz 0x0000710A0D1D5111
0000710a0d1d2fcd  vmovaps xmm15, [rsp+0xC0]
0000710a0d1d2fd6  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d2fdc  movaps xmm13, xmm12
0000710a0d1d2fe0  vfmadd231pd xmm13, xmm4, xmm15
0000710a0d1d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
0000710a0d1d2feb  vptest xmm9, xmm9
0000710a0d1d2ff0  jnz 0x0000710A0D1D526B
0000710a0d1d2ff6  vmovaps xmm15, [rsp+0xC0]
0000710a0d1d2fff  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d3005  movaps xmm12, xmm7
0000710a0d1d3009  vfmadd231pd xmm12, xmm1, xmm15
0000710a0d1d300e  vcmppd xmm9, xmm12, xmm12, 0x03
0000710a0d1d3014  vptest xmm9, xmm9
0000710a0d1d3019  jnz 0x0000710A0D1D53C4
0000710a0d1d301f  lea rax, [r14+0x20]
0000710a0d1d3023  movups xmm1, [r13+rax*1]
0000710a0d1d3029  lea rax, [r14+0x30]
0000710a0d1d302d  movups xmm15, [r13+rax*1]
0000710a0d1d3033  vmovaps xmm9, [rsp+0x70]
0000710a0d1d3039  vpermilpd xmm9, xmm9, 0x00
0000710a0d1d303f  vmovaps xmm8, [rsp+0x20]
0000710a0d1d3045  movaps xmm7, xmm6
0000710a0d1d3048  vfmadd231pd xmm7, xmm8, xmm9
0000710a0d1d304d  vcmppd xmm5, xmm7, xmm7, 0x03
0000710a0d1d3052  vptest xmm5, xmm5
0000710a0d1d3057  jnz 0x0000710A0D1D5530
0000710a0d1d305d  vmovaps xmm9, [rsp+0x70]
0000710a0d1d3063  vpermilpd xmm9, xmm9, 0x00
0000710a0d1d3069  movaps xmm8, xmm10
0000710a0d1d306d  vfmadd231pd xmm8, xmm14, xmm9
0000710a0d1d3072  vcmppd xmm6, xmm8, xmm8, 0x03
0000710a0d1d3078  vptest xmm6, xmm6
0000710a0d1d307d  jnz 0x0000710A0D1D5687
0000710a0d1d3083  vmovaps xmm14, [rsp+0x70]
0000710a0d1d3089  vpermilpd xmm14, xmm14, 0x00
0000710a0d1d308f  movaps xmm10, xmm13
0000710a0d1d3093  vfmadd231pd xmm10, xmm11, xmm14
0000710a0d1d3098  vcmppd xmm9, xmm10, xmm10, 0x03
0000710a0d1d309e  vptest xmm9, xmm9
0000710a0d1d30a3  jnz 0x0000710A0D1D57E1
0000710a0d1d30a9  vmovaps xmm14, [rsp+0x70]
0000710a0d1d30af  vpermilpd xmm14, xmm14, 0x00
0000710a0d1d30b5  movaps xmm13, xmm12
0000710a0d1d30b9  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d30be  vcmppd xmm11, xmm13, xmm13, 0x03
0000710a0d1d30c4  vptest xmm11, xmm11
0000710a0d1d30c9  jnz 0x0000710A0D1D593B
0000710a0d1d30cf  lea rax, [r14+0x90]
0000710a0d1d30d6  movups xmm15, [r13+rax*1]
0000710a0d1d30dc  lea rax, [r14+0xA0]
0000710a0d1d30e3  movups xmm14, [r13+rax*1]
0000710a0d1d30e9  movaps [r15+0x140], xmm15
0000710a0d1d30f1  movaps [r15+0x130], xmm14
0000710a0d1d30f9  vmovaps xmm12, [rsp+0x90]
0000710a0d1d3102  vpermilpd xmm12, xmm12, 0x00
0000710a0d1d3108  movaps xmm11, xmm7
0000710a0d1d310c  vfmadd231pd xmm11, xmm1, xmm12
0000710a0d1d3111  vcmppd xmm9, xmm11, xmm11, 0x03
0000710a0d1d3117  vptest xmm9, xmm9
0000710a0d1d311c  jnz 0x0000710A0D1D5AA9
0000710a0d1d3122  movaps [r15+0x220], xmm11
0000710a0d1d312a  lea rax, [r14+0x10]
0000710a0d1d312e  movups xmm1, [r13+rax*1]
0000710a0d1d3134  movaps [r15+0x240], xmm1
0000710a0d1d313c  vmovaps xmm12, [rsp+0x90]
0000710a0d1d3145  vpermilpd xmm12, xmm12, 0x00
0000710a0d1d314b  movaps xmm9, xmm8
0000710a0d1d314f  vfmadd231pd xmm9, xmm14, xmm12
0000710a0d1d3154  vcmppd xmm7, xmm9, xmm9, 0x03
0000710a0d1d315a  vptest xmm7, xmm7
0000710a0d1d315f  jnz 0x0000710A0D1D5C0B
0000710a0d1d3165  movaps [r15+0x110], xmm9
0000710a0d1d316d  vmovaps xmm14, [rsp+0x90]
0000710a0d1d3176  vpermilpd xmm14, xmm14, 0x00
0000710a0d1d317c  movaps xmm12, xmm10
0000710a0d1d3180  vfmadd231pd xmm12, xmm15, xmm14
0000710a0d1d3185  vcmppd xmm8, xmm12, xmm12, 0x03
0000710a0d1d318b  vptest xmm8, xmm8
0000710a0d1d3190  jnz 0x0000710A0D1D5D65
0000710a0d1d3196  movaps [r15+0x170], xmm12
0000710a0d1d319e  vmovaps xmm15, [rsp+0x90]
0000710a0d1d31a7  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d31ad  movaps xmm14, xmm13
0000710a0d1d31b1  vfmadd231pd xmm14, xmm1, xmm15
0000710a0d1d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
0000710a0d1d31bc  vptest xmm10, xmm10
0000710a0d1d31c1  jnz 0x0000710A0D1D5EBF
0000710a0d1d31c7  movaps [r15+0x230], xmm14
0000710a0d1d31cf  mov eax, 0x432190
0000710a0d1d31d4  movups [r13+rax*1], xmm9
0000710a0d1d31da  mov eax, 0x4321A0
0000710a0d1d31df  movups [r13+rax*1], xmm12
0000710a0d1d31e5  mov eax, 0x4321B0
0000710a0d1d31ea  movups [r13+rax*1], xmm11
0000710a0d1d31f0  mov eax, 0x4321C0
0000710a0d1d31f5  movups [r13+rax*1], xmm14
0000710a0d1d31fb  mov eax, [r15+0x108]
0000710a0d1d3202  sahf
0000710a0d1d3203  jnz 0x0000710A0D1D3235
0000710a0d1d3205  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d320d  jz 0x0000710A0D1D9950
0000710a0d1d3213  nop [rax+rax*1], ax
0000710a0d1d321c  nop [rax+rax*1], eax
0000710a0d1d3224  mov eax, 0x410664
0000710a0d1d3229  mov [r15+0x100], rax
0000710a0d1d3230  jmp 0x0000710A0CFFE110
0000710a0d1d3235  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d323d  jz 0x0000710A0D1D6050
0000710a0d1d3243  nop [rax+rax*1], ax
0000710a0d1d324c  nop [rax+rax*1], eax
0000710a0d1d3254  mov eax, 0x4104F0
0000710a0d1d3259  mov [r15+0x100], rax
0000710a0d1d3260  jmp 0x0000710A0CFFE110
0000710a0d1d3265  int3
0000710a0d1d3266  call 0x0000710A0CFFF430
0000710a0d1d326b  jmp 0x0000710A0D1D230A
0000710a0d1d3270  call 0x0000710A0D0E5820
0000710a0d1d3275  jmp 0x0000710A0D1D2314
0000710a0d1d327a  call 0x0000710A0D0E45A0
0000710a0d1d327f  jmp 0x0000710A0D1D2326
0000710a0d1d3284  call 0x0000710A0D0E3320
0000710a0d1d3289  jmp 0x0000710A0D1D2330
0000710a0d1d328e  call 0x0000710A0D0E20A0
0000710a0d1d3293  jmp 0x0000710A0D1D233D
0000710a0d1d3298  call 0x0000710A0D0E0E30
0000710a0d1d329d  jmp 0x0000710A0D1D234A
0000710a0d1d32a2  call 0x0000710A0D0D6600
0000710a0d1d32a7  jmp 0x0000710A0D1D2357
0000710a0d1d32ac  call 0x0000710A0D0B52F0
0000710a0d1d32b1  jmp 0x0000710A0D1D2361
0000710a0d1d32b6  call 0x0000710A0D0BE9C0
0000710a0d1d32bb  jmp 0x0000710A0D1D236B
0000710a0d1d32c0  call 0x0000710A0D0BD750
0000710a0d1d32c5  jmp 0x0000710A0D1D2378
0000710a0d1d32ca  call 0x0000710A0D0BC4E0
0000710a0d1d32cf  jmp 0x0000710A0D1D2385
0000710a0d1d32d4  call 0x0000710A0D0BB270
0000710a0d1d32d9  jmp 0x0000710A0D1D2392
0000710a0d1d32de  call 0x0000710A0D0BA000
0000710a0d1d32e3  jmp 0x0000710A0D1D239F
0000710a0d1d32e8  call 0x0000710A0D0B8D90
0000710a0d1d32ed  jmp 0x0000710A0D1D23AC
0000710a0d1d32f2  call 0x0000710A0D0B8A20
0000710a0d1d32f7  jmp 0x0000710A0D1D23B9
0000710a0d1d32fc  call 0x0000710A0D0BEAE0
0000710a0d1d3301  jmp 0x0000710A0D1D23C6
0000710a0d1d3306  call 0x0000710A0D0B5400
0000710a0d1d330b  jmp 0x0000710A0D1D23D3
0000710a0d1d3310  call 0x0000710A0D0B52F0
0000710a0d1d3315  jmp 0x0000710A0D1D23E0
0000710a0d1d331a  call 0x0000710A0D0BE9C0
0000710a0d1d331f  jmp 0x0000710A0D1D23ED
0000710a0d1d3324  call 0x0000710A0D0B77B0
0000710a0d1d3329  jmp 0x0000710A0D1D23FA
0000710a0d1d332e  call 0x0000710A0D0B6550
0000710a0d1d3333  jmp 0x0000710A0D1D2407
0000710a0d1d3338  call 0x0000710A0D0B52F0
0000710a0d1d333d  jmp 0x0000710A0D1D2417
0000710a0d1d3342  call 0x0000710A0D0B52F0
0000710a0d1d3347  jmp 0x0000710A0D1D2427
0000710a0d1d334c  call 0x0000710A0D0BEAE0
0000710a0d1d3351  jmp 0x0000710A0D1D2431
0000710a0d1d3356  call 0x0000710A0D0BEAE0
0000710a0d1d335b  jmp 0x0000710A0D1D2444
0000710a0d1d3360  call 0x0000710A0D0BE9C0
0000710a0d1d3365  jmp 0x0000710A0D1D2451
0000710a0d1d336a  call 0x0000710A0D0B52F0
0000710a0d1d336f  jmp 0x0000710A0D1D2464
0000710a0d1d3374  call 0x0000710A0D0B6660
0000710a0d1d3379  jmp 0x0000710A0D1D2471
0000710a0d1d337e  call 0x0000710A0D0B78C0
0000710a0d1d3383  jmp 0x0000710A0D1D247E
0000710a0d1d3388  call 0x0000710A0D0B77B0
0000710a0d1d338d  jmp 0x0000710A0D1D248B
0000710a0d1d3392  call 0x0000710A0D0B6550
0000710a0d1d3397  jmp 0x0000710A0D1D2498
0000710a0d1d339c  call 0x0000710A0D0B52F0
0000710a0d1d33a1  jmp 0x0000710A0D1D24AB
0000710a0d1d33a6  call 0x0000710A0D0B52F0
0000710a0d1d33ab  jmp 0x0000710A0D1D24BE
0000710a0d1d33b0  call 0x0000710A0D0B52F0
0000710a0d1d33b5  jmp 0x0000710A0D1D24E5
0000710a0d1d33ba  call 0x0000710A0D0B52F0
0000710a0d1d33bf  jmp 0x0000710A0D1D24F8
0000710a0d1d33c4  call 0x0000710A0D0B52F0
0000710a0d1d33c9  jmp 0x0000710A0D1D250B
0000710a0d1d33ce  call 0x0000710A0D0B52F0
0000710a0d1d33d3  jmp 0x0000710A0D1D2521
0000710a0d1d33d8  call 0x0000710A0D0B52F0
0000710a0d1d33dd  jmp 0x0000710A0D1D2537
0000710a0d1d33e2  call 0x0000710A0D0B52F0
0000710a0d1d33e7  jmp 0x0000710A0D1D254D
0000710a0d1d33ec  call 0x0000710A0CFFF540
0000710a0d1d33f1  jmp 0x0000710A0D1D256E
0000710a0d1d33f6  call 0x0000710A0D002FE0
0000710a0d1d33fb  jmp 0x0000710A0D1D2578
0000710a0d1d3400  call 0x0000710A0CFFF540
0000710a0d1d3405  jmp 0x0000710A0D1D2588
0000710a0d1d340a  call 0x0000710A0CFFF540
0000710a0d1d340f  jmp 0x0000710A0D1D259B
0000710a0d1d3414  call 0x0000710A0CFFF540
0000710a0d1d3419  jmp 0x0000710A0D1D25AE
0000710a0d1d341e  call 0x0000710A0CFFF540
0000710a0d1d3423  jmp 0x0000710A0D1D25C1
0000710a0d1d3428  call 0x0000710A0D0C0370
0000710a0d1d342d  jmp 0x0000710A0D1D25E0
0000710a0d1d3432  call 0x0000710A0D0BF100
0000710a0d1d3437  jmp 0x0000710A0D1D25E9
0000710a0d1d343c  call 0x0000710A0D0C0370
0000710a0d1d3441  jmp 0x0000710A0D1D2659
0000710a0d1d3446  call 0x0000710A0D0BF100
0000710a0d1d344b  jmp 0x0000710A0D1D2662
0000710a0d1d3450  call 0x0000710A0D0C0370
0000710a0d1d3455  jmp 0x0000710A0D1D270C
0000710a0d1d345a  call 0x0000710A0D0BF100
0000710a0d1d345f  jmp 0x0000710A0D1D2715
0000710a0d1d3464  call 0x0000710A0D00B720
0000710a0d1d3469  jmp 0x0000710A0D1D27F7
0000710a0d1d346e  call 0x0000710A0D0D64F0
0000710a0d1d3473  jmp 0x0000710A0D1D281F
0000710a0d1d3478  call 0x0000710A0D0B47C0
0000710a0d1d347d  jmp 0x0000710A0D1D283A
0000710a0d1d3482  sub rsp, 0x08
0000710a0d1d3486  push rax
0000710a0d1d3487  push rcx
0000710a0d1d3488  push rdx
0000710a0d1d3489  push rdi
0000710a0d1d348a  push rsi
0000710a0d1d348b  push r8
0000710a0d1d348d  push r9
0000710a0d1d348f  push r10
0000710a0d1d3491  push r11
0000710a0d1d3493  sub rsp, 0xF0
0000710a0d1d349a  vmovaps [rsp], xmm0
0000710a0d1d349f  vmovaps [rsp+0x10], xmm1
0000710a0d1d34a5  vmovaps [rsp+0x20], xmm2
0000710a0d1d34ab  vmovaps [rsp+0x30], xmm3
0000710a0d1d34b1  vmovaps [rsp+0x40], xmm4
0000710a0d1d34b7  vmovaps [rsp+0x50], xmm5
0000710a0d1d34bd  vmovaps [rsp+0x60], xmm6
0000710a0d1d34c3  vmovaps [rsp+0x70], xmm7
0000710a0d1d34c9  vmovaps [rsp+0x80], xmm8
0000710a0d1d34d2  vmovaps [rsp+0x90], xmm9
0000710a0d1d34db  vmovaps [rsp+0xA0], xmm10
0000710a0d1d34e4  vmovaps [rsp+0xB0], xmm11
0000710a0d1d34ed  vmovaps [rsp+0xC0], xmm12
0000710a0d1d34f6  vmovaps [rsp+0xD0], xmm14
0000710a0d1d34ff  vmovaps [rsp+0xE0], xmm15
0000710a0d1d3508  sub rsp, 0x40
0000710a0d1d350c  lea rdi, [rsp]
0000710a0d1d3510  lea rsi, [rsp+0x10]
0000710a0d1d3515  lea rdx, [rsp+0x20]
0000710a0d1d351a  lea rcx, [rsp+0x30]
0000710a0d1d351f  mov r8d, 0x00
0000710a0d1d3525  lea r9, [r15+0x3A8]
0000710a0d1d352c  movaps [rdi], xmm13
0000710a0d1d3530  movaps [rsi], xmm1
0000710a0d1d3533  movaps [rdx], xmm15
0000710a0d1d3537  movaps [rcx], xmm14
0000710a0d1d353b  mov rax, 0x64F334B05A50
0000710a0d1d3545  call rax
0000710a0d1d3547  movaps xmm13, [rsp]
0000710a0d1d354c  add rsp, 0x40
0000710a0d1d3550  vmovaps xmm0, [rsp]
0000710a0d1d3555  vmovaps xmm1, [rsp+0x10]
0000710a0d1d355b  vmovaps xmm2, [rsp+0x20]
0000710a0d1d3561  vmovaps xmm3, [rsp+0x30]
0000710a0d1d3567  vmovaps xmm4, [rsp+0x40]
0000710a0d1d356d  vmovaps xmm5, [rsp+0x50]
0000710a0d1d3573  vmovaps xmm6, [rsp+0x60]
0000710a0d1d3579  vmovaps xmm7, [rsp+0x70]
0000710a0d1d357f  vmovaps xmm8, [rsp+0x80]
0000710a0d1d3588  vmovaps xmm9, [rsp+0x90]
0000710a0d1d3591  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d359a  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d35a3  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d35ac  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d35b5  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d35be  add rsp, 0xF0
0000710a0d1d35c5  pop r11
0000710a0d1d35c7  pop r10
0000710a0d1d35c9  pop r9
0000710a0d1d35cb  pop r8
0000710a0d1d35cd  pop rsi
0000710a0d1d35ce  pop rdi
0000710a0d1d35cf  pop rdx
0000710a0d1d35d0  pop rcx
0000710a0d1d35d1  pop rax
0000710a0d1d35d2  add rsp, 0x08
0000710a0d1d35d6  jmp 0x0000710A0D1D28AD
0000710a0d1d35db  sub rsp, 0x08
0000710a0d1d35df  push rax
0000710a0d1d35e0  push rcx
0000710a0d1d35e1  push rdx
0000710a0d1d35e2  push rdi
0000710a0d1d35e3  push rsi
0000710a0d1d35e4  push r8
0000710a0d1d35e6  push r9
0000710a0d1d35e8  push r10
0000710a0d1d35ea  push r11
0000710a0d1d35ec  sub rsp, 0xF0
0000710a0d1d35f3  vmovaps [rsp], xmm0
0000710a0d1d35f8  vmovaps [rsp+0x10], xmm1
0000710a0d1d35fe  vmovaps [rsp+0x20], xmm2
0000710a0d1d3604  vmovaps [rsp+0x30], xmm3
0000710a0d1d360a  vmovaps [rsp+0x40], xmm4
0000710a0d1d3610  vmovaps [rsp+0x50], xmm5
0000710a0d1d3616  vmovaps [rsp+0x60], xmm6
0000710a0d1d361c  vmovaps [rsp+0x70], xmm7
0000710a0d1d3622  vmovaps [rsp+0x80], xmm8
0000710a0d1d362b  vmovaps [rsp+0x90], xmm9
0000710a0d1d3634  vmovaps [rsp+0xA0], xmm10
0000710a0d1d363d  vmovaps [rsp+0xB0], xmm11
0000710a0d1d3646  vmovaps [rsp+0xC0], xmm12
0000710a0d1d364f  vmovaps [rsp+0xD0], xmm13
0000710a0d1d3658  vmovaps [rsp+0xE0], xmm14
0000710a0d1d3661  sub rsp, 0x40
0000710a0d1d3665  lea rdi, [rsp]
0000710a0d1d3669  lea rsi, [rsp+0x10]
0000710a0d1d366e  lea rdx, [rsp+0x20]
0000710a0d1d3673  lea rcx, [rsp+0x30]
0000710a0d1d3678  mov r8d, 0x00
0000710a0d1d367e  lea r9, [r15+0x3A8]
0000710a0d1d3685  movaps [rdi], xmm15
0000710a0d1d3689  movaps [rsi], xmm5
0000710a0d1d368c  movaps [rdx], xmm1
0000710a0d1d368f  movaps [rcx], xmm14
0000710a0d1d3693  mov rax, 0x64F334B05A50
0000710a0d1d369d  call rax
0000710a0d1d369f  movaps xmm15, [rsp]
0000710a0d1d36a4  add rsp, 0x40
0000710a0d1d36a8  vmovaps xmm0, [rsp]
0000710a0d1d36ad  vmovaps xmm1, [rsp+0x10]
0000710a0d1d36b3  vmovaps xmm2, [rsp+0x20]
0000710a0d1d36b9  vmovaps xmm3, [rsp+0x30]
0000710a0d1d36bf  vmovaps xmm4, [rsp+0x40]
0000710a0d1d36c5  vmovaps xmm5, [rsp+0x50]
0000710a0d1d36cb  vmovaps xmm6, [rsp+0x60]
0000710a0d1d36d1  vmovaps xmm7, [rsp+0x70]
0000710a0d1d36d7  vmovaps xmm8, [rsp+0x80]
0000710a0d1d36e0  vmovaps xmm9, [rsp+0x90]
0000710a0d1d36e9  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d36f2  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d36fb  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d3704  vmovaps xmm13, [rsp+0xD0]
0000710a0d1d370d  vmovaps xmm14, [rsp+0xE0]
0000710a0d1d3716  add rsp, 0xF0
0000710a0d1d371d  pop r11
0000710a0d1d371f  pop r10
0000710a0d1d3721  pop r9
0000710a0d1d3723  pop r8
0000710a0d1d3725  pop rsi
0000710a0d1d3726  pop rdi
0000710a0d1d3727  pop rdx
0000710a0d1d3728  pop rcx
0000710a0d1d3729  pop rax
0000710a0d1d372a  add rsp, 0x08
0000710a0d1d372e  jmp 0x0000710A0D1D28D0
0000710a0d1d3733  call 0x0000710A0CFFF430
0000710a0d1d3738  jmp 0x0000710A0D1D295D
0000710a0d1d373d  sub rsp, 0x08
0000710a0d1d3741  push rax
0000710a0d1d3742  push rcx
0000710a0d1d3743  push rdx
0000710a0d1d3744  push rdi
0000710a0d1d3745  push rsi
0000710a0d1d3746  push r8
0000710a0d1d3748  push r9
0000710a0d1d374a  push r10
0000710a0d1d374c  push r11
0000710a0d1d374e  sub rsp, 0xF0
0000710a0d1d3755  vmovaps [rsp], xmm0
0000710a0d1d375a  vmovaps [rsp+0x10], xmm1
0000710a0d1d3760  vmovaps [rsp+0x20], xmm2
0000710a0d1d3766  vmovaps [rsp+0x30], xmm3
0000710a0d1d376c  vmovaps [rsp+0x40], xmm4
0000710a0d1d3772  vmovaps [rsp+0x50], xmm5
0000710a0d1d3778  vmovaps [rsp+0x60], xmm6
0000710a0d1d377e  vmovaps [rsp+0x70], xmm7
0000710a0d1d3784  vmovaps [rsp+0x80], xmm8
0000710a0d1d378d  vmovaps [rsp+0x90], xmm9
0000710a0d1d3796  vmovaps [rsp+0xA0], xmm10
0000710a0d1d379f  vmovaps [rsp+0xB0], xmm11
0000710a0d1d37a8  vmovaps [rsp+0xC0], xmm12
0000710a0d1d37b1  vmovaps [rsp+0xD0], xmm14
0000710a0d1d37ba  vmovaps [rsp+0xE0], xmm15
0000710a0d1d37c3  sub rsp, 0x40
0000710a0d1d37c7  lea rdi, [rsp]
0000710a0d1d37cb  lea rsi, [rsp+0x10]
0000710a0d1d37d0  lea rdx, [rsp+0x20]
0000710a0d1d37d5  lea rcx, [rsp+0x30]
0000710a0d1d37da  mov r8d, 0x00
0000710a0d1d37e0  lea r9, [r15+0x3A8]
0000710a0d1d37e7  movaps [rdi], xmm13
0000710a0d1d37eb  movaps [rsi], xmm1
0000710a0d1d37ee  movaps [rdx], xmm15
0000710a0d1d37f2  movaps [rcx], xmm14
0000710a0d1d37f6  mov rax, 0x64F334B05A50
0000710a0d1d3800  call rax
0000710a0d1d3802  movaps xmm13, [rsp]
0000710a0d1d3807  add rsp, 0x40
0000710a0d1d380b  vmovaps xmm0, [rsp]
0000710a0d1d3810  vmovaps xmm1, [rsp+0x10]
0000710a0d1d3816  vmovaps xmm2, [rsp+0x20]
0000710a0d1d381c  vmovaps xmm3, [rsp+0x30]
0000710a0d1d3822  vmovaps xmm4, [rsp+0x40]
0000710a0d1d3828  vmovaps xmm5, [rsp+0x50]
0000710a0d1d382e  vmovaps xmm6, [rsp+0x60]
0000710a0d1d3834  vmovaps xmm7, [rsp+0x70]
0000710a0d1d383a  vmovaps xmm8, [rsp+0x80]
0000710a0d1d3843  vmovaps xmm9, [rsp+0x90]
0000710a0d1d384c  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d3855  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d385e  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d3867  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d3870  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d3879  add rsp, 0xF0
0000710a0d1d3880  pop r11
0000710a0d1d3882  pop r10
0000710a0d1d3884  pop r9
0000710a0d1d3886  pop r8
0000710a0d1d3888  pop rsi
0000710a0d1d3889  pop rdi
0000710a0d1d388a  pop rdx
0000710a0d1d388b  pop rcx
0000710a0d1d388c  pop rax
0000710a0d1d388d  add rsp, 0x08
0000710a0d1d3891  jmp 0x0000710A0D1D29C1
0000710a0d1d3896  call 0x0000710A0CFFF430
0000710a0d1d389b  jmp 0x0000710A0D1D29CE
0000710a0d1d38a0  sub rsp, 0x08
0000710a0d1d38a4  push rax
0000710a0d1d38a5  push rcx
0000710a0d1d38a6  push rdx
0000710a0d1d38a7  push rdi
0000710a0d1d38a8  push rsi
0000710a0d1d38a9  push r8
0000710a0d1d38ab  push r9
0000710a0d1d38ad  push r10
0000710a0d1d38af  push r11
0000710a0d1d38b1  sub rsp, 0xF0
0000710a0d1d38b8  vmovaps [rsp], xmm0
0000710a0d1d38bd  vmovaps [rsp+0x10], xmm1
0000710a0d1d38c3  vmovaps [rsp+0x20], xmm2
0000710a0d1d38c9  vmovaps [rsp+0x30], xmm3
0000710a0d1d38cf  vmovaps [rsp+0x40], xmm4
0000710a0d1d38d5  vmovaps [rsp+0x50], xmm5
0000710a0d1d38db  vmovaps [rsp+0x60], xmm6
0000710a0d1d38e1  vmovaps [rsp+0x70], xmm7
0000710a0d1d38e7  vmovaps [rsp+0x80], xmm8
0000710a0d1d38f0  vmovaps [rsp+0x90], xmm9
0000710a0d1d38f9  vmovaps [rsp+0xA0], xmm10
0000710a0d1d3902  vmovaps [rsp+0xB0], xmm11
0000710a0d1d390b  vmovaps [rsp+0xC0], xmm13
0000710a0d1d3914  vmovaps [rsp+0xD0], xmm14
0000710a0d1d391d  vmovaps [rsp+0xE0], xmm15
0000710a0d1d3926  sub rsp, 0x40
0000710a0d1d392a  lea rdi, [rsp]
0000710a0d1d392e  lea rsi, [rsp+0x10]
0000710a0d1d3933  lea rdx, [rsp+0x20]
0000710a0d1d3938  lea rcx, [rsp+0x30]
0000710a0d1d393d  mov r8d, 0x00
0000710a0d1d3943  lea r9, [r15+0x3A8]
0000710a0d1d394a  movaps [rdi], xmm12
0000710a0d1d394e  movaps [rsi], xmm15
0000710a0d1d3952  movaps [rdx], xmm1
0000710a0d1d3955  movaps [rcx], xmm14
0000710a0d1d3959  mov rax, 0x64F334B05A50
0000710a0d1d3963  call rax
0000710a0d1d3965  movaps xmm12, [rsp]
0000710a0d1d396a  add rsp, 0x40
0000710a0d1d396e  vmovaps xmm0, [rsp]
0000710a0d1d3973  vmovaps xmm1, [rsp+0x10]
0000710a0d1d3979  vmovaps xmm2, [rsp+0x20]
0000710a0d1d397f  vmovaps xmm3, [rsp+0x30]
0000710a0d1d3985  vmovaps xmm4, [rsp+0x40]
0000710a0d1d398b  vmovaps xmm5, [rsp+0x50]
0000710a0d1d3991  vmovaps xmm6, [rsp+0x60]
0000710a0d1d3997  vmovaps xmm7, [rsp+0x70]
0000710a0d1d399d  vmovaps xmm8, [rsp+0x80]
0000710a0d1d39a6  vmovaps xmm9, [rsp+0x90]
0000710a0d1d39af  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d39b8  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d39c1  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d39ca  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d39d3  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d39dc  add rsp, 0xF0
0000710a0d1d39e3  pop r11
0000710a0d1d39e5  pop r10
0000710a0d1d39e7  pop r9
0000710a0d1d39e9  pop r8
0000710a0d1d39eb  pop rsi
0000710a0d1d39ec  pop rdi
0000710a0d1d39ed  pop rdx
0000710a0d1d39ee  pop rcx
0000710a0d1d39ef  pop rax
0000710a0d1d39f0  add rsp, 0x08
0000710a0d1d39f4  jmp 0x0000710A0D1D29FA
0000710a0d1d39f9  sub rsp, 0x08
0000710a0d1d39fd  push rax
0000710a0d1d39fe  push rcx
0000710a0d1d39ff  push rdx
0000710a0d1d3a00  push rdi
0000710a0d1d3a01  push rsi
0000710a0d1d3a02  push r8
0000710a0d1d3a04  push r9
0000710a0d1d3a06  push r10
0000710a0d1d3a08  push r11
0000710a0d1d3a0a  sub rsp, 0xF0
0000710a0d1d3a11  vmovaps [rsp], xmm0
0000710a0d1d3a16  vmovaps [rsp+0x10], xmm1
0000710a0d1d3a1c  vmovaps [rsp+0x20], xmm2
0000710a0d1d3a22  vmovaps [rsp+0x30], xmm3
0000710a0d1d3a28  vmovaps [rsp+0x40], xmm4
0000710a0d1d3a2e  vmovaps [rsp+0x50], xmm5
0000710a0d1d3a34  vmovaps [rsp+0x60], xmm6
0000710a0d1d3a3a  vmovaps [rsp+0x70], xmm7
0000710a0d1d3a40  vmovaps [rsp+0x80], xmm8
0000710a0d1d3a49  vmovaps [rsp+0x90], xmm9
0000710a0d1d3a52  vmovaps [rsp+0xA0], xmm10
0000710a0d1d3a5b  vmovaps [rsp+0xB0], xmm11
0000710a0d1d3a64  vmovaps [rsp+0xC0], xmm12
0000710a0d1d3a6d  vmovaps [rsp+0xD0], xmm14
0000710a0d1d3a76  vmovaps [rsp+0xE0], xmm15
0000710a0d1d3a7f  sub rsp, 0x40
0000710a0d1d3a83  lea rdi, [rsp]
0000710a0d1d3a87  lea rsi, [rsp+0x10]
0000710a0d1d3a8c  lea rdx, [rsp+0x20]
0000710a0d1d3a91  lea rcx, [rsp+0x30]
0000710a0d1d3a96  mov r8d, 0x00
0000710a0d1d3a9c  lea r9, [r15+0x3A8]
0000710a0d1d3aa3  movaps [rdi], xmm13
0000710a0d1d3aa7  movaps [rsi], xmm1
0000710a0d1d3aaa  movaps [rdx], xmm15
0000710a0d1d3aae  movaps [rcx], xmm14
0000710a0d1d3ab2  mov rax, 0x64F334B05A50
0000710a0d1d3abc  call rax
0000710a0d1d3abe  movaps xmm13, [rsp]
0000710a0d1d3ac3  add rsp, 0x40
0000710a0d1d3ac7  vmovaps xmm0, [rsp]
0000710a0d1d3acc  vmovaps xmm1, [rsp+0x10]
0000710a0d1d3ad2  vmovaps xmm2, [rsp+0x20]
0000710a0d1d3ad8  vmovaps xmm3, [rsp+0x30]
0000710a0d1d3ade  vmovaps xmm4, [rsp+0x40]
0000710a0d1d3ae4  vmovaps xmm5, [rsp+0x50]
0000710a0d1d3aea  vmovaps xmm6, [rsp+0x60]
0000710a0d1d3af0  vmovaps xmm7, [rsp+0x70]
0000710a0d1d3af6  vmovaps xmm8, [rsp+0x80]
0000710a0d1d3aff  vmovaps xmm9, [rsp+0x90]
0000710a0d1d3b08  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d3b11  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d3b1a  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d3b23  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d3b2c  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d3b35  add rsp, 0xF0
0000710a0d1d3b3c  pop r11
0000710a0d1d3b3e  pop r10
0000710a0d1d3b40  pop r9
0000710a0d1d3b42  pop r8
0000710a0d1d3b44  pop rsi
0000710a0d1d3b45  pop rdi
0000710a0d1d3b46  pop rdx
0000710a0d1d3b47  pop rcx
0000710a0d1d3b48  pop rax
0000710a0d1d3b49  add rsp, 0x08
0000710a0d1d3b4d  jmp 0x0000710A0D1D2B77
0000710a0d1d3b52  sub rsp, 0x08
0000710a0d1d3b56  push rax
0000710a0d1d3b57  push rcx
0000710a0d1d3b58  push rdx
0000710a0d1d3b59  push rdi
0000710a0d1d3b5a  push rsi
0000710a0d1d3b5b  push r8
0000710a0d1d3b5d  push r9
0000710a0d1d3b5f  push r10
0000710a0d1d3b61  push r11
0000710a0d1d3b63  sub rsp, 0xF0
0000710a0d1d3b6a  vmovaps [rsp], xmm0
0000710a0d1d3b6f  vmovaps [rsp+0x10], xmm1
0000710a0d1d3b75  vmovaps [rsp+0x20], xmm2
0000710a0d1d3b7b  vmovaps [rsp+0x30], xmm3
0000710a0d1d3b81  vmovaps [rsp+0x40], xmm4
0000710a0d1d3b87  vmovaps [rsp+0x50], xmm5
0000710a0d1d3b8d  vmovaps [rsp+0x60], xmm6
0000710a0d1d3b93  vmovaps [rsp+0x70], xmm7
0000710a0d1d3b99  vmovaps [rsp+0x80], xmm8
0000710a0d1d3ba2  vmovaps [rsp+0x90], xmm9
0000710a0d1d3bab  vmovaps [rsp+0xA0], xmm10
0000710a0d1d3bb4  vmovaps [rsp+0xB0], xmm11
0000710a0d1d3bbd  vmovaps [rsp+0xC0], xmm13
0000710a0d1d3bc6  vmovaps [rsp+0xD0], xmm14
0000710a0d1d3bcf  vmovaps [rsp+0xE0], xmm15
0000710a0d1d3bd8  sub rsp, 0x40
0000710a0d1d3bdc  lea rdi, [rsp]
0000710a0d1d3be0  lea rsi, [rsp+0x10]
0000710a0d1d3be5  lea rdx, [rsp+0x20]
0000710a0d1d3bea  lea rcx, [rsp+0x30]
0000710a0d1d3bef  mov r8d, 0x00
0000710a0d1d3bf5  lea r9, [r15+0x3A8]
0000710a0d1d3bfc  movaps [rdi], xmm12
0000710a0d1d3c00  movaps [rsi], xmm15
0000710a0d1d3c04  movaps [rdx], xmm14
0000710a0d1d3c08  movaps [rcx], xmm1
0000710a0d1d3c0b  mov rax, 0x64F334B05A50
0000710a0d1d3c15  call rax
0000710a0d1d3c17  movaps xmm12, [rsp]
0000710a0d1d3c1c  add rsp, 0x40
0000710a0d1d3c20  vmovaps xmm0, [rsp]
0000710a0d1d3c25  vmovaps xmm1, [rsp+0x10]
0000710a0d1d3c2b  vmovaps xmm2, [rsp+0x20]
0000710a0d1d3c31  vmovaps xmm3, [rsp+0x30]
0000710a0d1d3c37  vmovaps xmm4, [rsp+0x40]
0000710a0d1d3c3d  vmovaps xmm5, [rsp+0x50]
0000710a0d1d3c43  vmovaps xmm6, [rsp+0x60]
0000710a0d1d3c49  vmovaps xmm7, [rsp+0x70]
0000710a0d1d3c4f  vmovaps xmm8, [rsp+0x80]
0000710a0d1d3c58  vmovaps xmm9, [rsp+0x90]
0000710a0d1d3c61  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d3c6a  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d3c73  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d3c7c  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d3c85  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d3c8e  add rsp, 0xF0
0000710a0d1d3c95  pop r11
0000710a0d1d3c97  pop r10
0000710a0d1d3c99  pop r9
0000710a0d1d3c9b  pop r8
0000710a0d1d3c9d  pop rsi
0000710a0d1d3c9e  pop rdi
0000710a0d1d3c9f  pop rdx
0000710a0d1d3ca0  pop rcx
0000710a0d1d3ca1  pop rax
0000710a0d1d3ca2  add rsp, 0x08
0000710a0d1d3ca6  jmp 0x0000710A0D1D2BB2
0000710a0d1d3cab  sub rsp, 0x08
0000710a0d1d3caf  push rax
0000710a0d1d3cb0  push rcx
0000710a0d1d3cb1  push rdx
0000710a0d1d3cb2  push rdi
0000710a0d1d3cb3  push rsi
0000710a0d1d3cb4  push r8
0000710a0d1d3cb6  push r9
0000710a0d1d3cb8  push r10
0000710a0d1d3cba  push r11
0000710a0d1d3cbc  sub rsp, 0xF0
0000710a0d1d3cc3  vmovaps [rsp], xmm0
0000710a0d1d3cc8  vmovaps [rsp+0x10], xmm1
0000710a0d1d3cce  vmovaps [rsp+0x20], xmm2
0000710a0d1d3cd4  vmovaps [rsp+0x30], xmm3
0000710a0d1d3cda  vmovaps [rsp+0x40], xmm4
0000710a0d1d3ce0  vmovaps [rsp+0x50], xmm5
0000710a0d1d3ce6  vmovaps [rsp+0x60], xmm6
0000710a0d1d3cec  vmovaps [rsp+0x70], xmm7
0000710a0d1d3cf2  vmovaps [rsp+0x80], xmm8
0000710a0d1d3cfb  vmovaps [rsp+0x90], xmm9
0000710a0d1d3d04  vmovaps [rsp+0xA0], xmm10
0000710a0d1d3d0d  vmovaps [rsp+0xB0], xmm11
0000710a0d1d3d16  vmovaps [rsp+0xC0], xmm12
0000710a0d1d3d1f  vmovaps [rsp+0xD0], xmm14
0000710a0d1d3d28  vmovaps [rsp+0xE0], xmm15
0000710a0d1d3d31  sub rsp, 0x40
0000710a0d1d3d35  lea rdi, [rsp]
0000710a0d1d3d39  lea rsi, [rsp+0x10]
0000710a0d1d3d3e  lea rdx, [rsp+0x20]
0000710a0d1d3d43  lea rcx, [rsp+0x30]
0000710a0d1d3d48  mov r8d, 0x00
0000710a0d1d3d4e  lea r9, [r15+0x3A8]
0000710a0d1d3d55  movaps [rdi], xmm13
0000710a0d1d3d59  movaps [rsi], xmm15
0000710a0d1d3d5d  movaps [rdx], xmm14
0000710a0d1d3d61  movaps [rcx], xmm1
0000710a0d1d3d64  mov rax, 0x64F334B05A50
0000710a0d1d3d6e  call rax
0000710a0d1d3d70  movaps xmm13, [rsp]
0000710a0d1d3d75  add rsp, 0x40
0000710a0d1d3d79  vmovaps xmm0, [rsp]
0000710a0d1d3d7e  vmovaps xmm1, [rsp+0x10]
0000710a0d1d3d84  vmovaps xmm2, [rsp+0x20]
0000710a0d1d3d8a  vmovaps xmm3, [rsp+0x30]
0000710a0d1d3d90  vmovaps xmm4, [rsp+0x40]
0000710a0d1d3d96  vmovaps xmm5, [rsp+0x50]
0000710a0d1d3d9c  vmovaps xmm6, [rsp+0x60]
0000710a0d1d3da2  vmovaps xmm7, [rsp+0x70]
0000710a0d1d3da8  vmovaps xmm8, [rsp+0x80]
0000710a0d1d3db1  vmovaps xmm9, [rsp+0x90]
0000710a0d1d3dba  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d3dc3  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d3dcc  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d3dd5  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d3dde  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d3de7  add rsp, 0xF0
0000710a0d1d3dee  pop r11
0000710a0d1d3df0  pop r10
0000710a0d1d3df2  pop r9
0000710a0d1d3df4  pop r8
0000710a0d1d3df6  pop rsi
0000710a0d1d3df7  pop rdi
0000710a0d1d3df8  pop rdx
0000710a0d1d3df9  pop rcx
0000710a0d1d3dfa  pop rax
0000710a0d1d3dfb  add rsp, 0x08
0000710a0d1d3dff  jmp 0x0000710A0D1D2BEA
0000710a0d1d3e04  sub rsp, 0x08
0000710a0d1d3e08  push rax
0000710a0d1d3e09  push rcx
0000710a0d1d3e0a  push rdx
0000710a0d1d3e0b  push rdi
0000710a0d1d3e0c  push rsi
0000710a0d1d3e0d  push r8
0000710a0d1d3e0f  push r9
0000710a0d1d3e11  push r10
0000710a0d1d3e13  push r11
0000710a0d1d3e15  sub rsp, 0xF0
0000710a0d1d3e1c  vmovaps [rsp], xmm0
0000710a0d1d3e21  vmovaps [rsp+0x10], xmm1
0000710a0d1d3e27  vmovaps [rsp+0x20], xmm2
0000710a0d1d3e2d  vmovaps [rsp+0x30], xmm3
0000710a0d1d3e33  vmovaps [rsp+0x40], xmm4
0000710a0d1d3e39  vmovaps [rsp+0x50], xmm5
0000710a0d1d3e3f  vmovaps [rsp+0x60], xmm6
0000710a0d1d3e45  vmovaps [rsp+0x70], xmm7
0000710a0d1d3e4b  vmovaps [rsp+0x80], xmm8
0000710a0d1d3e54  vmovaps [rsp+0x90], xmm9
0000710a0d1d3e5d  vmovaps [rsp+0xA0], xmm10
0000710a0d1d3e66  vmovaps [rsp+0xB0], xmm11
0000710a0d1d3e6f  vmovaps [rsp+0xC0], xmm13
0000710a0d1d3e78  vmovaps [rsp+0xD0], xmm14
0000710a0d1d3e81  vmovaps [rsp+0xE0], xmm15
0000710a0d1d3e8a  sub rsp, 0x40
0000710a0d1d3e8e  lea rdi, [rsp]
0000710a0d1d3e92  lea rsi, [rsp+0x10]
0000710a0d1d3e97  lea rdx, [rsp+0x20]
0000710a0d1d3e9c  lea rcx, [rsp+0x30]
0000710a0d1d3ea1  mov r8d, 0x00
0000710a0d1d3ea7  lea r9, [r15+0x3A8]
0000710a0d1d3eae  movaps [rdi], xmm12
0000710a0d1d3eb2  movaps [rsi], xmm15
0000710a0d1d3eb6  movaps [rdx], xmm14
0000710a0d1d3eba  movaps [rcx], xmm1
0000710a0d1d3ebd  mov rax, 0x64F334B05A50
0000710a0d1d3ec7  call rax
0000710a0d1d3ec9  movaps xmm12, [rsp]
0000710a0d1d3ece  add rsp, 0x40
0000710a0d1d3ed2  vmovaps xmm0, [rsp]
0000710a0d1d3ed7  vmovaps xmm1, [rsp+0x10]
0000710a0d1d3edd  vmovaps xmm2, [rsp+0x20]
0000710a0d1d3ee3  vmovaps xmm3, [rsp+0x30]
0000710a0d1d3ee9  vmovaps xmm4, [rsp+0x40]
0000710a0d1d3eef  vmovaps xmm5, [rsp+0x50]
0000710a0d1d3ef5  vmovaps xmm6, [rsp+0x60]
0000710a0d1d3efb  vmovaps xmm7, [rsp+0x70]
0000710a0d1d3f01  vmovaps xmm8, [rsp+0x80]
0000710a0d1d3f0a  vmovaps xmm9, [rsp+0x90]
0000710a0d1d3f13  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d3f1c  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d3f25  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d3f2e  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d3f37  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d3f40  add rsp, 0xF0
0000710a0d1d3f47  pop r11
0000710a0d1d3f49  pop r10
0000710a0d1d3f4b  pop r9
0000710a0d1d3f4d  pop r8
0000710a0d1d3f4f  pop rsi
0000710a0d1d3f50  pop rdi
0000710a0d1d3f51  pop rdx
0000710a0d1d3f52  pop rcx
0000710a0d1d3f53  pop rax
0000710a0d1d3f54  add rsp, 0x08
0000710a0d1d3f58  jmp 0x0000710A0D1D2C3D
0000710a0d1d3f5d  sub rsp, 0x08
0000710a0d1d3f61  push rax
0000710a0d1d3f62  push rcx
0000710a0d1d3f63  push rdx
0000710a0d1d3f64  push rdi
0000710a0d1d3f65  push rsi
0000710a0d1d3f66  push r8
0000710a0d1d3f68  push r9
0000710a0d1d3f6a  push r10
0000710a0d1d3f6c  push r11
0000710a0d1d3f6e  sub rsp, 0xF0
0000710a0d1d3f75  vmovaps [rsp], xmm0
0000710a0d1d3f7a  vmovaps [rsp+0x10], xmm1
0000710a0d1d3f80  vmovaps [rsp+0x20], xmm2
0000710a0d1d3f86  vmovaps [rsp+0x30], xmm3
0000710a0d1d3f8c  vmovaps [rsp+0x40], xmm4
0000710a0d1d3f92  vmovaps [rsp+0x50], xmm5
0000710a0d1d3f98  vmovaps [rsp+0x60], xmm6
0000710a0d1d3f9e  vmovaps [rsp+0x70], xmm7
0000710a0d1d3fa4  vmovaps [rsp+0x80], xmm8
0000710a0d1d3fad  vmovaps [rsp+0x90], xmm9
0000710a0d1d3fb6  vmovaps [rsp+0xA0], xmm10
0000710a0d1d3fbf  vmovaps [rsp+0xB0], xmm11
0000710a0d1d3fc8  vmovaps [rsp+0xC0], xmm12
0000710a0d1d3fd1  vmovaps [rsp+0xD0], xmm13
0000710a0d1d3fda  vmovaps [rsp+0xE0], xmm15
0000710a0d1d3fe3  sub rsp, 0x40
0000710a0d1d3fe7  lea rdi, [rsp]
0000710a0d1d3feb  lea rsi, [rsp+0x10]
0000710a0d1d3ff0  lea rdx, [rsp+0x20]
0000710a0d1d3ff5  lea rcx, [rsp+0x30]
0000710a0d1d3ffa  mov r8d, 0x00
0000710a0d1d4000  lea r9, [r15+0x3A8]
0000710a0d1d4007  movaps [rdi], xmm14
0000710a0d1d400b  movaps [rsi], xmm3
0000710a0d1d400e  movaps [rdx], xmm1
0000710a0d1d4011  movaps [rcx], xmm15
0000710a0d1d4015  mov rax, 0x64F334B05A50
0000710a0d1d401f  call rax
0000710a0d1d4021  movaps xmm14, [rsp]
0000710a0d1d4026  add rsp, 0x40
0000710a0d1d402a  vmovaps xmm0, [rsp]
0000710a0d1d402f  vmovaps xmm1, [rsp+0x10]
0000710a0d1d4035  vmovaps xmm2, [rsp+0x20]
0000710a0d1d403b  vmovaps xmm3, [rsp+0x30]
0000710a0d1d4041  vmovaps xmm4, [rsp+0x40]
0000710a0d1d4047  vmovaps xmm5, [rsp+0x50]
0000710a0d1d404d  vmovaps xmm6, [rsp+0x60]
0000710a0d1d4053  vmovaps xmm7, [rsp+0x70]
0000710a0d1d4059  vmovaps xmm8, [rsp+0x80]
0000710a0d1d4062  vmovaps xmm9, [rsp+0x90]
0000710a0d1d406b  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d4074  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d407d  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d4086  vmovaps xmm13, [rsp+0xD0]
0000710a0d1d408f  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d4098  add rsp, 0xF0
0000710a0d1d409f  pop r11
0000710a0d1d40a1  pop r10
0000710a0d1d40a3  pop r9
0000710a0d1d40a5  pop r8
0000710a0d1d40a7  pop rsi
0000710a0d1d40a8  pop rdi
0000710a0d1d40a9  pop rdx
0000710a0d1d40aa  pop rcx
0000710a0d1d40ab  pop rax
0000710a0d1d40ac  add rsp, 0x08
0000710a0d1d40b0  jmp 0x0000710A0D1D2CF7
0000710a0d1d40b5  sub rsp, 0x08
0000710a0d1d40b9  push rax
0000710a0d1d40ba  push rcx
0000710a0d1d40bb  push rdx
0000710a0d1d40bc  push rdi
0000710a0d1d40bd  push rsi
0000710a0d1d40be  push r8
0000710a0d1d40c0  push r9
0000710a0d1d40c2  push r10
0000710a0d1d40c4  push r11
0000710a0d1d40c6  sub rsp, 0xF0
0000710a0d1d40cd  vmovaps [rsp], xmm0
0000710a0d1d40d2  vmovaps [rsp+0x10], xmm1
0000710a0d1d40d8  vmovaps [rsp+0x20], xmm2
0000710a0d1d40de  vmovaps [rsp+0x30], xmm3
0000710a0d1d40e4  vmovaps [rsp+0x40], xmm4
0000710a0d1d40ea  vmovaps [rsp+0x50], xmm5
0000710a0d1d40f0  vmovaps [rsp+0x60], xmm6
0000710a0d1d40f6  vmovaps [rsp+0x70], xmm7
0000710a0d1d40fc  vmovaps [rsp+0x80], xmm8
0000710a0d1d4105  vmovaps [rsp+0x90], xmm9
0000710a0d1d410e  vmovaps [rsp+0xA0], xmm10
0000710a0d1d4117  vmovaps [rsp+0xB0], xmm11
0000710a0d1d4120  vmovaps [rsp+0xC0], xmm12
0000710a0d1d4129  vmovaps [rsp+0xD0], xmm14
0000710a0d1d4132  vmovaps [rsp+0xE0], xmm15
0000710a0d1d413b  sub rsp, 0x40
0000710a0d1d413f  lea rdi, [rsp]
0000710a0d1d4143  lea rsi, [rsp+0x10]
0000710a0d1d4148  lea rdx, [rsp+0x20]
0000710a0d1d414d  lea rcx, [rsp+0x30]
0000710a0d1d4152  mov r8d, 0x00
0000710a0d1d4158  lea r9, [r15+0x3A8]
0000710a0d1d415f  movaps [rdi], xmm13
0000710a0d1d4163  movaps [rsi], xmm15
0000710a0d1d4167  movaps [rdx], xmm10
0000710a0d1d416b  movaps [rcx], xmm1
0000710a0d1d416e  mov rax, 0x64F334B05A50
0000710a0d1d4178  call rax
0000710a0d1d417a  movaps xmm13, [rsp]
0000710a0d1d417f  add rsp, 0x40
0000710a0d1d4183  vmovaps xmm0, [rsp]
0000710a0d1d4188  vmovaps xmm1, [rsp+0x10]
0000710a0d1d418e  vmovaps xmm2, [rsp+0x20]
0000710a0d1d4194  vmovaps xmm3, [rsp+0x30]
0000710a0d1d419a  vmovaps xmm4, [rsp+0x40]
0000710a0d1d41a0  vmovaps xmm5, [rsp+0x50]
0000710a0d1d41a6  vmovaps xmm6, [rsp+0x60]
0000710a0d1d41ac  vmovaps xmm7, [rsp+0x70]
0000710a0d1d41b2  vmovaps xmm8, [rsp+0x80]
0000710a0d1d41bb  vmovaps xmm9, [rsp+0x90]
0000710a0d1d41c4  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d41cd  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d41d6  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d41df  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d41e8  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d41f1  add rsp, 0xF0
0000710a0d1d41f8  pop r11
0000710a0d1d41fa  pop r10
0000710a0d1d41fc  pop r9
0000710a0d1d41fe  pop r8
0000710a0d1d4200  pop rsi
0000710a0d1d4201  pop rdi
0000710a0d1d4202  pop rdx
0000710a0d1d4203  pop rcx
0000710a0d1d4204  pop rax
0000710a0d1d4205  add rsp, 0x08
0000710a0d1d4209  jmp 0x0000710A0D1D2D26
0000710a0d1d420e  sub rsp, 0x08
0000710a0d1d4212  push rax
0000710a0d1d4213  push rcx
0000710a0d1d4214  push rdx
0000710a0d1d4215  push rdi
0000710a0d1d4216  push rsi
0000710a0d1d4217  push r8
0000710a0d1d4219  push r9
0000710a0d1d421b  push r10
0000710a0d1d421d  push r11
0000710a0d1d421f  sub rsp, 0xF0
0000710a0d1d4226  vmovaps [rsp], xmm0
0000710a0d1d422b  vmovaps [rsp+0x10], xmm1
0000710a0d1d4231  vmovaps [rsp+0x20], xmm2
0000710a0d1d4237  vmovaps [rsp+0x30], xmm3
0000710a0d1d423d  vmovaps [rsp+0x40], xmm4
0000710a0d1d4243  vmovaps [rsp+0x50], xmm5
0000710a0d1d4249  vmovaps [rsp+0x60], xmm6
0000710a0d1d424f  vmovaps [rsp+0x70], xmm7
0000710a0d1d4255  vmovaps [rsp+0x80], xmm8
0000710a0d1d425e  vmovaps [rsp+0x90], xmm9
0000710a0d1d4267  vmovaps [rsp+0xA0], xmm11
0000710a0d1d4270  vmovaps [rsp+0xB0], xmm12
0000710a0d1d4279  vmovaps [rsp+0xC0], xmm13
0000710a0d1d4282  vmovaps [rsp+0xD0], xmm14
0000710a0d1d428b  vmovaps [rsp+0xE0], xmm15
0000710a0d1d4294  sub rsp, 0x40
0000710a0d1d4298  lea rdi, [rsp]
0000710a0d1d429c  lea rsi, [rsp+0x10]
0000710a0d1d42a1  lea rdx, [rsp+0x20]
0000710a0d1d42a6  lea rcx, [rsp+0x30]
0000710a0d1d42ab  mov r8d, 0x00
0000710a0d1d42b1  lea r9, [r15+0x3A8]
0000710a0d1d42b8  movaps [rdi], xmm10
0000710a0d1d42bc  movaps [rsi], xmm15
0000710a0d1d42c0  movaps [rdx], xmm11
0000710a0d1d42c4  movaps [rcx], xmm1
0000710a0d1d42c7  mov rax, 0x64F334B05A50
0000710a0d1d42d1  call rax
0000710a0d1d42d3  movaps xmm10, [rsp]
0000710a0d1d42d8  add rsp, 0x40
0000710a0d1d42dc  vmovaps xmm0, [rsp]
0000710a0d1d42e1  vmovaps xmm1, [rsp+0x10]
0000710a0d1d42e7  vmovaps xmm2, [rsp+0x20]
0000710a0d1d42ed  vmovaps xmm3, [rsp+0x30]
0000710a0d1d42f3  vmovaps xmm4, [rsp+0x40]
0000710a0d1d42f9  vmovaps xmm5, [rsp+0x50]
0000710a0d1d42ff  vmovaps xmm6, [rsp+0x60]
0000710a0d1d4305  vmovaps xmm7, [rsp+0x70]
0000710a0d1d430b  vmovaps xmm8, [rsp+0x80]
0000710a0d1d4314  vmovaps xmm9, [rsp+0x90]
0000710a0d1d431d  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d4326  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d432f  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d4338  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d4341  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d434a  add rsp, 0xF0
0000710a0d1d4351  pop r11
0000710a0d1d4353  pop r10
0000710a0d1d4355  pop r9
0000710a0d1d4357  pop r8
0000710a0d1d4359  pop rsi
0000710a0d1d435a  pop rdi
0000710a0d1d435b  pop rdx
0000710a0d1d435c  pop rcx
0000710a0d1d435d  pop rax
0000710a0d1d435e  add rsp, 0x08
0000710a0d1d4362  jmp 0x0000710A0D1D2D55
0000710a0d1d4367  sub rsp, 0x08
0000710a0d1d436b  push rax
0000710a0d1d436c  push rcx
0000710a0d1d436d  push rdx
0000710a0d1d436e  push rdi
0000710a0d1d436f  push rsi
0000710a0d1d4370  push r8
0000710a0d1d4372  push r9
0000710a0d1d4374  push r10
0000710a0d1d4376  push r11
0000710a0d1d4378  sub rsp, 0xF0
0000710a0d1d437f  vmovaps [rsp], xmm0
0000710a0d1d4384  vmovaps [rsp+0x10], xmm1
0000710a0d1d438a  vmovaps [rsp+0x20], xmm2
0000710a0d1d4390  vmovaps [rsp+0x30], xmm3
0000710a0d1d4396  vmovaps [rsp+0x40], xmm4
0000710a0d1d439c  vmovaps [rsp+0x50], xmm5
0000710a0d1d43a2  vmovaps [rsp+0x60], xmm6
0000710a0d1d43a8  vmovaps [rsp+0x70], xmm7
0000710a0d1d43ae  vmovaps [rsp+0x80], xmm8
0000710a0d1d43b7  vmovaps [rsp+0x90], xmm9
0000710a0d1d43c0  vmovaps [rsp+0xA0], xmm10
0000710a0d1d43c9  vmovaps [rsp+0xB0], xmm11
0000710a0d1d43d2  vmovaps [rsp+0xC0], xmm12
0000710a0d1d43db  vmovaps [rsp+0xD0], xmm13
0000710a0d1d43e4  vmovaps [rsp+0xE0], xmm14
0000710a0d1d43ed  sub rsp, 0x40
0000710a0d1d43f1  lea rdi, [rsp]
0000710a0d1d43f5  lea rsi, [rsp+0x10]
0000710a0d1d43fa  lea rdx, [rsp+0x20]
0000710a0d1d43ff  lea rcx, [rsp+0x30]
0000710a0d1d4404  mov r8d, 0x00
0000710a0d1d440a  lea r9, [r15+0x3A8]
0000710a0d1d4411  movaps [rdi], xmm15
0000710a0d1d4415  movaps [rsi], xmm12
0000710a0d1d4419  movaps [rdx], xmm5
0000710a0d1d441c  movaps [rcx], xmm1
0000710a0d1d441f  mov rax, 0x64F334B05A50
0000710a0d1d4429  call rax
0000710a0d1d442b  movaps xmm15, [rsp]
0000710a0d1d4430  add rsp, 0x40
0000710a0d1d4434  vmovaps xmm0, [rsp]
0000710a0d1d4439  vmovaps xmm1, [rsp+0x10]
0000710a0d1d443f  vmovaps xmm2, [rsp+0x20]
0000710a0d1d4445  vmovaps xmm3, [rsp+0x30]
0000710a0d1d444b  vmovaps xmm4, [rsp+0x40]
0000710a0d1d4451  vmovaps xmm5, [rsp+0x50]
0000710a0d1d4457  vmovaps xmm6, [rsp+0x60]
0000710a0d1d445d  vmovaps xmm7, [rsp+0x70]
0000710a0d1d4463  vmovaps xmm8, [rsp+0x80]
0000710a0d1d446c  vmovaps xmm9, [rsp+0x90]
0000710a0d1d4475  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d447e  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d4487  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d4490  vmovaps xmm13, [rsp+0xD0]
0000710a0d1d4499  vmovaps xmm14, [rsp+0xE0]
0000710a0d1d44a2  add rsp, 0xF0
0000710a0d1d44a9  pop r11
0000710a0d1d44ab  pop r10
0000710a0d1d44ad  pop r9
0000710a0d1d44af  pop r8
0000710a0d1d44b1  pop rsi
0000710a0d1d44b2  pop rdi
0000710a0d1d44b3  pop rdx
0000710a0d1d44b4  pop rcx
0000710a0d1d44b5  pop rax
0000710a0d1d44b6  add rsp, 0x08
0000710a0d1d44ba  jmp 0x0000710A0D1D2D7E
0000710a0d1d44bf  sub rsp, 0x08
0000710a0d1d44c3  push rax
0000710a0d1d44c4  push rcx
0000710a0d1d44c5  push rdx
0000710a0d1d44c6  push rdi
0000710a0d1d44c7  push rsi
0000710a0d1d44c8  push r8
0000710a0d1d44ca  push r9
0000710a0d1d44cc  push r10
0000710a0d1d44ce  push r11
0000710a0d1d44d0  sub rsp, 0xF0
0000710a0d1d44d7  vmovaps [rsp], xmm0
0000710a0d1d44dc  vmovaps [rsp+0x10], xmm1
0000710a0d1d44e2  vmovaps [rsp+0x20], xmm2
0000710a0d1d44e8  vmovaps [rsp+0x30], xmm3
0000710a0d1d44ee  vmovaps [rsp+0x40], xmm4
0000710a0d1d44f4  vmovaps [rsp+0x50], xmm6
0000710a0d1d44fa  vmovaps [rsp+0x60], xmm7
0000710a0d1d4500  vmovaps [rsp+0x70], xmm8
0000710a0d1d4506  vmovaps [rsp+0x80], xmm9
0000710a0d1d450f  vmovaps [rsp+0x90], xmm10
0000710a0d1d4518  vmovaps [rsp+0xA0], xmm11
0000710a0d1d4521  vmovaps [rsp+0xB0], xmm12
0000710a0d1d452a  vmovaps [rsp+0xC0], xmm13
0000710a0d1d4533  vmovaps [rsp+0xD0], xmm14
0000710a0d1d453c  vmovaps [rsp+0xE0], xmm15
0000710a0d1d4545  sub rsp, 0x40
0000710a0d1d4549  lea rdi, [rsp]
0000710a0d1d454d  lea rsi, [rsp+0x10]
0000710a0d1d4552  lea rdx, [rsp+0x20]
0000710a0d1d4557  lea rcx, [rsp+0x30]
0000710a0d1d455c  mov r8d, 0x00
0000710a0d1d4562  lea r9, [r15+0x3A8]
0000710a0d1d4569  movaps [rdi], xmm5
0000710a0d1d456c  movaps [rsi], xmm13
0000710a0d1d4570  movaps [rdx], xmm11
0000710a0d1d4574  movaps [rcx], xmm12
0000710a0d1d4578  mov rax, 0x64F334B05A50
0000710a0d1d4582  call rax
0000710a0d1d4584  movaps xmm5, [rsp]
0000710a0d1d4588  add rsp, 0x40
0000710a0d1d458c  vmovaps xmm0, [rsp]
0000710a0d1d4591  vmovaps xmm1, [rsp+0x10]
0000710a0d1d4597  vmovaps xmm2, [rsp+0x20]
0000710a0d1d459d  vmovaps xmm3, [rsp+0x30]
0000710a0d1d45a3  vmovaps xmm4, [rsp+0x40]
0000710a0d1d45a9  vmovaps xmm6, [rsp+0x50]
0000710a0d1d45af  vmovaps xmm7, [rsp+0x60]
0000710a0d1d45b5  vmovaps xmm8, [rsp+0x70]
0000710a0d1d45bb  vmovaps xmm9, [rsp+0x80]
0000710a0d1d45c4  vmovaps xmm10, [rsp+0x90]
0000710a0d1d45cd  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d45d6  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d45df  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d45e8  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d45f1  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d45fa  add rsp, 0xF0
0000710a0d1d4601  pop r11
0000710a0d1d4603  pop r10
0000710a0d1d4605  pop r9
0000710a0d1d4607  pop r8
0000710a0d1d4609  pop rsi
0000710a0d1d460a  pop rdi
0000710a0d1d460b  pop rdx
0000710a0d1d460c  pop rcx
0000710a0d1d460d  pop rax
0000710a0d1d460e  add rsp, 0x08
0000710a0d1d4612  jmp 0x0000710A0D1D2DDD
0000710a0d1d4617  sub rsp, 0x08
0000710a0d1d461b  push rax
0000710a0d1d461c  push rcx
0000710a0d1d461d  push rdx
0000710a0d1d461e  push rdi
0000710a0d1d461f  push rsi
0000710a0d1d4620  push r8
0000710a0d1d4622  push r9
0000710a0d1d4624  push r10
0000710a0d1d4626  push r11
0000710a0d1d4628  sub rsp, 0xF0
0000710a0d1d462f  vmovaps [rsp], xmm0
0000710a0d1d4634  vmovaps [rsp+0x10], xmm1
0000710a0d1d463a  vmovaps [rsp+0x20], xmm2
0000710a0d1d4640  vmovaps [rsp+0x30], xmm3
0000710a0d1d4646  vmovaps [rsp+0x40], xmm4
0000710a0d1d464c  vmovaps [rsp+0x50], xmm5
0000710a0d1d4652  vmovaps [rsp+0x60], xmm6
0000710a0d1d4658  vmovaps [rsp+0x70], xmm7
0000710a0d1d465e  vmovaps [rsp+0x80], xmm8
0000710a0d1d4667  vmovaps [rsp+0x90], xmm9
0000710a0d1d4670  vmovaps [rsp+0xA0], xmm10
0000710a0d1d4679  vmovaps [rsp+0xB0], xmm11
0000710a0d1d4682  vmovaps [rsp+0xC0], xmm13
0000710a0d1d468b  vmovaps [rsp+0xD0], xmm14
0000710a0d1d4694  vmovaps [rsp+0xE0], xmm15
0000710a0d1d469d  sub rsp, 0x40
0000710a0d1d46a1  lea rdi, [rsp]
0000710a0d1d46a5  lea rsi, [rsp+0x10]
0000710a0d1d46aa  lea rdx, [rsp+0x20]
0000710a0d1d46af  lea rcx, [rsp+0x30]
0000710a0d1d46b4  mov r8d, 0x00
0000710a0d1d46ba  lea r9, [r15+0x3A8]
0000710a0d1d46c1  movaps [rdi], xmm12
0000710a0d1d46c5  movaps [rsi], xmm14
0000710a0d1d46c9  movaps [rdx], xmm9
0000710a0d1d46cd  movaps [rcx], xmm13
0000710a0d1d46d1  mov rax, 0x64F334B05A50
0000710a0d1d46db  call rax
0000710a0d1d46dd  movaps xmm12, [rsp]
0000710a0d1d46e2  add rsp, 0x40
0000710a0d1d46e6  vmovaps xmm0, [rsp]
0000710a0d1d46eb  vmovaps xmm1, [rsp+0x10]
0000710a0d1d46f1  vmovaps xmm2, [rsp+0x20]
0000710a0d1d46f7  vmovaps xmm3, [rsp+0x30]
0000710a0d1d46fd  vmovaps xmm4, [rsp+0x40]
0000710a0d1d4703  vmovaps xmm5, [rsp+0x50]
0000710a0d1d4709  vmovaps xmm6, [rsp+0x60]
0000710a0d1d470f  vmovaps xmm7, [rsp+0x70]
0000710a0d1d4715  vmovaps xmm8, [rsp+0x80]
0000710a0d1d471e  vmovaps xmm9, [rsp+0x90]
0000710a0d1d4727  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d4730  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d4739  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d4742  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d474b  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d4754  add rsp, 0xF0
0000710a0d1d475b  pop r11
0000710a0d1d475d  pop r10
0000710a0d1d475f  pop r9
0000710a0d1d4761  pop r8
0000710a0d1d4763  pop rsi
0000710a0d1d4764  pop rdi
0000710a0d1d4765  pop rdx
0000710a0d1d4766  pop rcx
0000710a0d1d4767  pop rax
0000710a0d1d4768  add rsp, 0x08
0000710a0d1d476c  jmp 0x0000710A0D1D2E06
0000710a0d1d4771  call 0x0000710A0D00D4E0
0000710a0d1d4776  jmp 0x0000710A0D1D2E13
0000710a0d1d477b  sub rsp, 0x08
0000710a0d1d477f  push rax
0000710a0d1d4780  push rcx
0000710a0d1d4781  push rdx
0000710a0d1d4782  push rdi
0000710a0d1d4783  push rsi
0000710a0d1d4784  push r8
0000710a0d1d4786  push r9
0000710a0d1d4788  push r10
0000710a0d1d478a  push r11
0000710a0d1d478c  sub rsp, 0xF0
0000710a0d1d4793  vmovaps [rsp], xmm0
0000710a0d1d4798  vmovaps [rsp+0x10], xmm1
0000710a0d1d479e  vmovaps [rsp+0x20], xmm2
0000710a0d1d47a4  vmovaps [rsp+0x30], xmm3
0000710a0d1d47aa  vmovaps [rsp+0x40], xmm4
0000710a0d1d47b0  vmovaps [rsp+0x50], xmm5
0000710a0d1d47b6  vmovaps [rsp+0x60], xmm6
0000710a0d1d47bc  vmovaps [rsp+0x70], xmm7
0000710a0d1d47c2  vmovaps [rsp+0x80], xmm8
0000710a0d1d47cb  vmovaps [rsp+0x90], xmm9
0000710a0d1d47d4  vmovaps [rsp+0xA0], xmm10
0000710a0d1d47dd  vmovaps [rsp+0xB0], xmm12
0000710a0d1d47e6  vmovaps [rsp+0xC0], xmm13
0000710a0d1d47ef  vmovaps [rsp+0xD0], xmm14
0000710a0d1d47f8  vmovaps [rsp+0xE0], xmm15
0000710a0d1d4801  sub rsp, 0x40
0000710a0d1d4805  lea rdi, [rsp]
0000710a0d1d4809  lea rsi, [rsp+0x10]
0000710a0d1d480e  lea rdx, [rsp+0x20]
0000710a0d1d4813  lea rcx, [rsp+0x30]
0000710a0d1d4818  mov r8d, 0x00
0000710a0d1d481e  lea r9, [r15+0x3A8]
0000710a0d1d4825  movaps [rdi], xmm11
0000710a0d1d4829  movaps [rsi], xmm10
0000710a0d1d482d  movaps [rdx], xmm8
0000710a0d1d4831  movaps [rcx], xmm13
0000710a0d1d4835  mov rax, 0x64F334B05A50
0000710a0d1d483f  call rax
0000710a0d1d4841  movaps xmm11, [rsp]
0000710a0d1d4846  add rsp, 0x40
0000710a0d1d484a  vmovaps xmm0, [rsp]
0000710a0d1d484f  vmovaps xmm1, [rsp+0x10]
0000710a0d1d4855  vmovaps xmm2, [rsp+0x20]
0000710a0d1d485b  vmovaps xmm3, [rsp+0x30]
0000710a0d1d4861  vmovaps xmm4, [rsp+0x40]
0000710a0d1d4867  vmovaps xmm5, [rsp+0x50]
0000710a0d1d486d  vmovaps xmm6, [rsp+0x60]
0000710a0d1d4873  vmovaps xmm7, [rsp+0x70]
0000710a0d1d4879  vmovaps xmm8, [rsp+0x80]
0000710a0d1d4882  vmovaps xmm9, [rsp+0x90]
0000710a0d1d488b  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d4894  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d489d  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d48a6  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d48af  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d48b8  add rsp, 0xF0
0000710a0d1d48bf  pop r11
0000710a0d1d48c1  pop r10
0000710a0d1d48c3  pop r9
0000710a0d1d48c5  pop r8
0000710a0d1d48c7  pop rsi
0000710a0d1d48c8  pop rdi
0000710a0d1d48c9  pop rdx
0000710a0d1d48ca  pop rcx
0000710a0d1d48cb  pop rax
0000710a0d1d48cc  add rsp, 0x08
0000710a0d1d48d0  jmp 0x0000710A0D1D2E44
0000710a0d1d48d5  sub rsp, 0x08
0000710a0d1d48d9  push rax
0000710a0d1d48da  push rcx
0000710a0d1d48db  push rdx
0000710a0d1d48dc  push rdi
0000710a0d1d48dd  push rsi
0000710a0d1d48de  push r8
0000710a0d1d48e0  push r9
0000710a0d1d48e2  push r10
0000710a0d1d48e4  push r11
0000710a0d1d48e6  sub rsp, 0xF0
0000710a0d1d48ed  vmovaps [rsp], xmm0
0000710a0d1d48f2  vmovaps [rsp+0x10], xmm1
0000710a0d1d48f8  vmovaps [rsp+0x20], xmm2
0000710a0d1d48fe  vmovaps [rsp+0x30], xmm3
0000710a0d1d4904  vmovaps [rsp+0x40], xmm4
0000710a0d1d490a  vmovaps [rsp+0x50], xmm5
0000710a0d1d4910  vmovaps [rsp+0x60], xmm6
0000710a0d1d4916  vmovaps [rsp+0x70], xmm7
0000710a0d1d491c  vmovaps [rsp+0x80], xmm8
0000710a0d1d4925  vmovaps [rsp+0x90], xmm9
0000710a0d1d492e  vmovaps [rsp+0xA0], xmm11
0000710a0d1d4937  vmovaps [rsp+0xB0], xmm12
0000710a0d1d4940  vmovaps [rsp+0xC0], xmm13
0000710a0d1d4949  vmovaps [rsp+0xD0], xmm14
0000710a0d1d4952  vmovaps [rsp+0xE0], xmm15
0000710a0d1d495b  sub rsp, 0x40
0000710a0d1d495f  lea rdi, [rsp]
0000710a0d1d4963  lea rsi, [rsp+0x10]
0000710a0d1d4968  lea rdx, [rsp+0x20]
0000710a0d1d496d  lea rcx, [rsp+0x30]
0000710a0d1d4972  mov r8d, 0x00
0000710a0d1d4978  lea r9, [r15+0x3A8]
0000710a0d1d497f  movaps [rdi], xmm10
0000710a0d1d4983  movaps [rsi], xmm15
0000710a0d1d4987  movaps [rdx], xmm1
0000710a0d1d498a  movaps [rcx], xmm13
0000710a0d1d498e  mov rax, 0x64F334B05A50
0000710a0d1d4998  call rax
0000710a0d1d499a  movaps xmm10, [rsp]
0000710a0d1d499f  add rsp, 0x40
0000710a0d1d49a3  vmovaps xmm0, [rsp]
0000710a0d1d49a8  vmovaps xmm1, [rsp+0x10]
0000710a0d1d49ae  vmovaps xmm2, [rsp+0x20]
0000710a0d1d49b4  vmovaps xmm3, [rsp+0x30]
0000710a0d1d49ba  vmovaps xmm4, [rsp+0x40]
0000710a0d1d49c0  vmovaps xmm5, [rsp+0x50]
0000710a0d1d49c6  vmovaps xmm6, [rsp+0x60]
0000710a0d1d49cc  vmovaps xmm7, [rsp+0x70]
0000710a0d1d49d2  vmovaps xmm8, [rsp+0x80]
0000710a0d1d49db  vmovaps xmm9, [rsp+0x90]
0000710a0d1d49e4  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d49ed  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d49f6  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d49ff  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d4a08  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d4a11  add rsp, 0xF0
0000710a0d1d4a18  pop r11
0000710a0d1d4a1a  pop r10
0000710a0d1d4a1c  pop r9
0000710a0d1d4a1e  pop r8
0000710a0d1d4a20  pop rsi
0000710a0d1d4a21  pop rdi
0000710a0d1d4a22  pop rdx
0000710a0d1d4a23  pop rcx
0000710a0d1d4a24  pop rax
0000710a0d1d4a25  add rsp, 0x08
0000710a0d1d4a29  jmp 0x0000710A0D1D2E6D
0000710a0d1d4a2e  call 0x0000710A0CFFF430
0000710a0d1d4a33  jmp 0x0000710A0D1D2E8F
0000710a0d1d4a38  call 0x0000710A0D00E760
0000710a0d1d4a3d  jmp 0x0000710A0D1D2E99
0000710a0d1d4a42  sub rsp, 0x08
0000710a0d1d4a46  push rax
0000710a0d1d4a47  push rcx
0000710a0d1d4a48  push rdx
0000710a0d1d4a49  push rdi
0000710a0d1d4a4a  push rsi
0000710a0d1d4a4b  push r8
0000710a0d1d4a4d  push r9
0000710a0d1d4a4f  push r10
0000710a0d1d4a51  push r11
0000710a0d1d4a53  sub rsp, 0xF0
0000710a0d1d4a5a  vmovaps [rsp], xmm0
0000710a0d1d4a5f  vmovaps [rsp+0x10], xmm1
0000710a0d1d4a65  vmovaps [rsp+0x20], xmm2
0000710a0d1d4a6b  vmovaps [rsp+0x30], xmm3
0000710a0d1d4a71  vmovaps [rsp+0x40], xmm4
0000710a0d1d4a77  vmovaps [rsp+0x50], xmm5
0000710a0d1d4a7d  vmovaps [rsp+0x60], xmm6
0000710a0d1d4a83  vmovaps [rsp+0x70], xmm7
0000710a0d1d4a89  vmovaps [rsp+0x80], xmm9
0000710a0d1d4a92  vmovaps [rsp+0x90], xmm10
0000710a0d1d4a9b  vmovaps [rsp+0xA0], xmm11
0000710a0d1d4aa4  vmovaps [rsp+0xB0], xmm12
0000710a0d1d4aad  vmovaps [rsp+0xC0], xmm13
0000710a0d1d4ab6  vmovaps [rsp+0xD0], xmm14
0000710a0d1d4abf  vmovaps [rsp+0xE0], xmm15
0000710a0d1d4ac8  sub rsp, 0x40
0000710a0d1d4acc  lea rdi, [rsp]
0000710a0d1d4ad0  lea rsi, [rsp+0x10]
0000710a0d1d4ad5  lea rdx, [rsp+0x20]
0000710a0d1d4ada  lea rcx, [rsp+0x30]
0000710a0d1d4adf  mov r8d, 0x00
0000710a0d1d4ae5  lea r9, [r15+0x3A8]
0000710a0d1d4aec  movaps [rdi], xmm8
0000710a0d1d4af0  movaps [rsi], xmm5
0000710a0d1d4af3  movaps [rdx], xmm9
0000710a0d1d4af7  movaps [rcx], xmm13
0000710a0d1d4afb  mov rax, 0x64F334B05A50
0000710a0d1d4b05  call rax
0000710a0d1d4b07  movaps xmm8, [rsp]
0000710a0d1d4b0c  add rsp, 0x40
0000710a0d1d4b10  vmovaps xmm0, [rsp]
0000710a0d1d4b15  vmovaps xmm1, [rsp+0x10]
0000710a0d1d4b1b  vmovaps xmm2, [rsp+0x20]
0000710a0d1d4b21  vmovaps xmm3, [rsp+0x30]
0000710a0d1d4b27  vmovaps xmm4, [rsp+0x40]
0000710a0d1d4b2d  vmovaps xmm5, [rsp+0x50]
0000710a0d1d4b33  vmovaps xmm6, [rsp+0x60]
0000710a0d1d4b39  vmovaps xmm7, [rsp+0x70]
0000710a0d1d4b3f  vmovaps xmm9, [rsp+0x80]
0000710a0d1d4b48  vmovaps xmm10, [rsp+0x90]
0000710a0d1d4b51  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d4b5a  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d4b63  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d4b6c  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d4b75  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d4b7e  add rsp, 0xF0
0000710a0d1d4b85  pop r11
0000710a0d1d4b87  pop r10
0000710a0d1d4b89  pop r9
0000710a0d1d4b8b  pop r8
0000710a0d1d4b8d  pop rsi
0000710a0d1d4b8e  pop rdi
0000710a0d1d4b8f  pop rdx
0000710a0d1d4b90  pop rcx
0000710a0d1d4b91  pop rax
0000710a0d1d4b92  add rsp, 0x08
0000710a0d1d4b96  jmp 0x0000710A0D1D2ED8
0000710a0d1d4b9b  sub rsp, 0x08
0000710a0d1d4b9f  push rax
0000710a0d1d4ba0  push rcx
0000710a0d1d4ba1  push rdx
0000710a0d1d4ba2  push rdi
0000710a0d1d4ba3  push rsi
0000710a0d1d4ba4  push r8
0000710a0d1d4ba6  push r9
0000710a0d1d4ba8  push r10
0000710a0d1d4baa  push r11
0000710a0d1d4bac  sub rsp, 0xF0
0000710a0d1d4bb3  vmovaps [rsp], xmm0
0000710a0d1d4bb8  vmovaps [rsp+0x10], xmm1
0000710a0d1d4bbe  vmovaps [rsp+0x20], xmm2
0000710a0d1d4bc4  vmovaps [rsp+0x30], xmm3
0000710a0d1d4bca  vmovaps [rsp+0x40], xmm4
0000710a0d1d4bd0  vmovaps [rsp+0x50], xmm5
0000710a0d1d4bd6  vmovaps [rsp+0x60], xmm6
0000710a0d1d4bdc  vmovaps [rsp+0x70], xmm7
0000710a0d1d4be2  vmovaps [rsp+0x80], xmm8
0000710a0d1d4beb  vmovaps [rsp+0x90], xmm10
0000710a0d1d4bf4  vmovaps [rsp+0xA0], xmm11
0000710a0d1d4bfd  vmovaps [rsp+0xB0], xmm12
0000710a0d1d4c06  vmovaps [rsp+0xC0], xmm13
0000710a0d1d4c0f  vmovaps [rsp+0xD0], xmm14
0000710a0d1d4c18  vmovaps [rsp+0xE0], xmm15
0000710a0d1d4c21  sub rsp, 0x40
0000710a0d1d4c25  lea rdi, [rsp]
0000710a0d1d4c29  lea rsi, [rsp+0x10]
0000710a0d1d4c2e  lea rdx, [rsp+0x20]
0000710a0d1d4c33  lea rcx, [rsp+0x30]
0000710a0d1d4c38  mov r8d, 0x00
0000710a0d1d4c3e  lea r9, [r15+0x3A8]
0000710a0d1d4c45  movaps [rdi], xmm9
0000710a0d1d4c49  movaps [rsi], xmm12
0000710a0d1d4c4d  movaps [rdx], xmm7
0000710a0d1d4c50  movaps [rcx], xmm13
0000710a0d1d4c54  mov rax, 0x64F334B05A50
0000710a0d1d4c5e  call rax
0000710a0d1d4c60  movaps xmm9, [rsp]
0000710a0d1d4c65  add rsp, 0x40
0000710a0d1d4c69  vmovaps xmm0, [rsp]
0000710a0d1d4c6e  vmovaps xmm1, [rsp+0x10]
0000710a0d1d4c74  vmovaps xmm2, [rsp+0x20]
0000710a0d1d4c7a  vmovaps xmm3, [rsp+0x30]
0000710a0d1d4c80  vmovaps xmm4, [rsp+0x40]
0000710a0d1d4c86  vmovaps xmm5, [rsp+0x50]
0000710a0d1d4c8c  vmovaps xmm6, [rsp+0x60]
0000710a0d1d4c92  vmovaps xmm7, [rsp+0x70]
0000710a0d1d4c98  vmovaps xmm8, [rsp+0x80]
0000710a0d1d4ca1  vmovaps xmm10, [rsp+0x90]
0000710a0d1d4caa  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d4cb3  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d4cbc  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d4cc5  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d4cce  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d4cd7  add rsp, 0xF0
0000710a0d1d4cde  pop r11
0000710a0d1d4ce0  pop r10
0000710a0d1d4ce2  pop r9
0000710a0d1d4ce4  pop r8
0000710a0d1d4ce6  pop rsi
0000710a0d1d4ce7  pop rdi
0000710a0d1d4ce8  pop rdx
0000710a0d1d4ce9  pop rcx
0000710a0d1d4cea  pop rax
0000710a0d1d4ceb  add rsp, 0x08
0000710a0d1d4cef  jmp 0x0000710A0D1D2F01
0000710a0d1d4cf4  sub rsp, 0x08
0000710a0d1d4cf8  push rax
0000710a0d1d4cf9  push rcx
0000710a0d1d4cfa  push rdx
0000710a0d1d4cfb  push rdi
0000710a0d1d4cfc  push rsi
0000710a0d1d4cfd  push r8
0000710a0d1d4cff  push r9
0000710a0d1d4d01  push r10
0000710a0d1d4d03  push r11
0000710a0d1d4d05  sub rsp, 0xF0
0000710a0d1d4d0c  vmovaps [rsp], xmm0
0000710a0d1d4d11  vmovaps [rsp+0x10], xmm1
0000710a0d1d4d17  vmovaps [rsp+0x20], xmm2
0000710a0d1d4d1d  vmovaps [rsp+0x30], xmm3
0000710a0d1d4d23  vmovaps [rsp+0x40], xmm4
0000710a0d1d4d29  vmovaps [rsp+0x50], xmm5
0000710a0d1d4d2f  vmovaps [rsp+0x60], xmm6
0000710a0d1d4d35  vmovaps [rsp+0x70], xmm7
0000710a0d1d4d3b  vmovaps [rsp+0x80], xmm8
0000710a0d1d4d44  vmovaps [rsp+0x90], xmm9
0000710a0d1d4d4d  vmovaps [rsp+0xA0], xmm10
0000710a0d1d4d56  vmovaps [rsp+0xB0], xmm11
0000710a0d1d4d5f  vmovaps [rsp+0xC0], xmm13
0000710a0d1d4d68  vmovaps [rsp+0xD0], xmm14
0000710a0d1d4d71  vmovaps [rsp+0xE0], xmm15
0000710a0d1d4d7a  sub rsp, 0x40
0000710a0d1d4d7e  lea rdi, [rsp]
0000710a0d1d4d82  lea rsi, [rsp+0x10]
0000710a0d1d4d87  lea rdx, [rsp+0x20]
0000710a0d1d4d8c  lea rcx, [rsp+0x30]
0000710a0d1d4d91  mov r8d, 0x00
0000710a0d1d4d97  lea r9, [r15+0x3A8]
0000710a0d1d4d9e  movaps [rdi], xmm12
0000710a0d1d4da2  movaps [rsi], xmm11
0000710a0d1d4da6  movaps [rdx], xmm6
0000710a0d1d4da9  movaps [rcx], xmm13
0000710a0d1d4dad  mov rax, 0x64F334B05A50
0000710a0d1d4db7  call rax
0000710a0d1d4db9  movaps xmm12, [rsp]
0000710a0d1d4dbe  add rsp, 0x40
0000710a0d1d4dc2  vmovaps xmm0, [rsp]
0000710a0d1d4dc7  vmovaps xmm1, [rsp+0x10]
0000710a0d1d4dcd  vmovaps xmm2, [rsp+0x20]
0000710a0d1d4dd3  vmovaps xmm3, [rsp+0x30]
0000710a0d1d4dd9  vmovaps xmm4, [rsp+0x40]
0000710a0d1d4ddf  vmovaps xmm5, [rsp+0x50]
0000710a0d1d4de5  vmovaps xmm6, [rsp+0x60]
0000710a0d1d4deb  vmovaps xmm7, [rsp+0x70]
0000710a0d1d4df1  vmovaps xmm8, [rsp+0x80]
0000710a0d1d4dfa  vmovaps xmm9, [rsp+0x90]
0000710a0d1d4e03  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d4e0c  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d4e15  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d4e1e  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d4e27  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d4e30  add rsp, 0xF0
0000710a0d1d4e37  pop r11
0000710a0d1d4e39  pop r10
0000710a0d1d4e3b  pop r9
0000710a0d1d4e3d  pop r8
0000710a0d1d4e3f  pop rsi
0000710a0d1d4e40  pop rdi
0000710a0d1d4e41  pop rdx
0000710a0d1d4e42  pop rcx
0000710a0d1d4e43  pop rax
0000710a0d1d4e44  add rsp, 0x08
0000710a0d1d4e48  jmp 0x0000710A0D1D2F2A
0000710a0d1d4e4d  sub rsp, 0x08
0000710a0d1d4e51  push rax
0000710a0d1d4e52  push rcx
0000710a0d1d4e53  push rdx
0000710a0d1d4e54  push rdi
0000710a0d1d4e55  push rsi
0000710a0d1d4e56  push r8
0000710a0d1d4e58  push r9
0000710a0d1d4e5a  push r10
0000710a0d1d4e5c  push r11
0000710a0d1d4e5e  sub rsp, 0xF0
0000710a0d1d4e65  vmovaps [rsp], xmm0
0000710a0d1d4e6a  vmovaps [rsp+0x10], xmm1
0000710a0d1d4e70  vmovaps [rsp+0x20], xmm2
0000710a0d1d4e76  vmovaps [rsp+0x30], xmm3
0000710a0d1d4e7c  vmovaps [rsp+0x40], xmm4
0000710a0d1d4e82  vmovaps [rsp+0x50], xmm5
0000710a0d1d4e88  vmovaps [rsp+0x60], xmm6
0000710a0d1d4e8e  vmovaps [rsp+0x70], xmm8
0000710a0d1d4e94  vmovaps [rsp+0x80], xmm9
0000710a0d1d4e9d  vmovaps [rsp+0x90], xmm10
0000710a0d1d4ea6  vmovaps [rsp+0xA0], xmm11
0000710a0d1d4eaf  vmovaps [rsp+0xB0], xmm12
0000710a0d1d4eb8  vmovaps [rsp+0xC0], xmm13
0000710a0d1d4ec1  vmovaps [rsp+0xD0], xmm14
0000710a0d1d4eca  vmovaps [rsp+0xE0], xmm15
0000710a0d1d4ed3  sub rsp, 0x40
0000710a0d1d4ed7  lea rdi, [rsp]
0000710a0d1d4edb  lea rsi, [rsp+0x10]
0000710a0d1d4ee0  lea rdx, [rsp+0x20]
0000710a0d1d4ee5  lea rcx, [rsp+0x30]
0000710a0d1d4eea  mov r8d, 0x00
0000710a0d1d4ef0  lea r9, [r15+0x3A8]
0000710a0d1d4ef7  movaps [rdi], xmm7
0000710a0d1d4efa  movaps [rsi], xmm10
0000710a0d1d4efe  movaps [rdx], xmm11
0000710a0d1d4f02  movaps [rcx], xmm13
0000710a0d1d4f06  mov rax, 0x64F334B05A50
0000710a0d1d4f10  call rax
0000710a0d1d4f12  movaps xmm7, [rsp]
0000710a0d1d4f16  add rsp, 0x40
0000710a0d1d4f1a  vmovaps xmm0, [rsp]
0000710a0d1d4f1f  vmovaps xmm1, [rsp+0x10]
0000710a0d1d4f25  vmovaps xmm2, [rsp+0x20]
0000710a0d1d4f2b  vmovaps xmm3, [rsp+0x30]
0000710a0d1d4f31  vmovaps xmm4, [rsp+0x40]
0000710a0d1d4f37  vmovaps xmm5, [rsp+0x50]
0000710a0d1d4f3d  vmovaps xmm6, [rsp+0x60]
0000710a0d1d4f43  vmovaps xmm8, [rsp+0x70]
0000710a0d1d4f49  vmovaps xmm9, [rsp+0x80]
0000710a0d1d4f52  vmovaps xmm10, [rsp+0x90]
0000710a0d1d4f5b  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d4f64  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d4f6d  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d4f76  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d4f7f  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d4f88  add rsp, 0xF0
0000710a0d1d4f8f  pop r11
0000710a0d1d4f91  pop r10
0000710a0d1d4f93  pop r9
0000710a0d1d4f95  pop r8
0000710a0d1d4f97  pop rsi
0000710a0d1d4f98  pop rdi
0000710a0d1d4f99  pop rdx
0000710a0d1d4f9a  pop rcx
0000710a0d1d4f9b  pop rax
0000710a0d1d4f9c  add rsp, 0x08
0000710a0d1d4fa0  jmp 0x0000710A0D1D2F58
0000710a0d1d4fa5  call 0x0000710A0D00C260
0000710a0d1d4faa  jmp 0x0000710A0D1D2F62
0000710a0d1d4faf  call 0x0000710A0D009D70
0000710a0d1d4fb4  jmp 0x0000710A0D1D2F6C
0000710a0d1d4fb9  sub rsp, 0x08
0000710a0d1d4fbd  push rax
0000710a0d1d4fbe  push rcx
0000710a0d1d4fbf  push rdx
0000710a0d1d4fc0  push rdi
0000710a0d1d4fc1  push rsi
0000710a0d1d4fc2  push r8
0000710a0d1d4fc4  push r9
0000710a0d1d4fc6  push r10
0000710a0d1d4fc8  push r11
0000710a0d1d4fca  sub rsp, 0xF0
0000710a0d1d4fd1  vmovaps [rsp], xmm0
0000710a0d1d4fd6  vmovaps [rsp+0x10], xmm1
0000710a0d1d4fdc  vmovaps [rsp+0x20], xmm2
0000710a0d1d4fe2  vmovaps [rsp+0x30], xmm3
0000710a0d1d4fe8  vmovaps [rsp+0x40], xmm4
0000710a0d1d4fee  vmovaps [rsp+0x50], xmm5
0000710a0d1d4ff4  vmovaps [rsp+0x60], xmm7
0000710a0d1d4ffa  vmovaps [rsp+0x70], xmm8
0000710a0d1d5000  vmovaps [rsp+0x80], xmm9
0000710a0d1d5009  vmovaps [rsp+0x90], xmm10
0000710a0d1d5012  vmovaps [rsp+0xA0], xmm11
0000710a0d1d501b  vmovaps [rsp+0xB0], xmm12
0000710a0d1d5024  vmovaps [rsp+0xC0], xmm13
0000710a0d1d502d  vmovaps [rsp+0xD0], xmm14
0000710a0d1d5036  vmovaps [rsp+0xE0], xmm15
0000710a0d1d503f  sub rsp, 0x40
0000710a0d1d5043  lea rdi, [rsp]
0000710a0d1d5047  lea rsi, [rsp+0x10]
0000710a0d1d504c  lea rdx, [rsp+0x20]
0000710a0d1d5051  lea rcx, [rsp+0x30]
0000710a0d1d5056  mov r8d, 0x00
0000710a0d1d505c  lea r9, [r15+0x3A8]
0000710a0d1d5063  movaps [rdi], xmm6
0000710a0d1d5066  movaps [rsi], xmm8
0000710a0d1d506a  movaps [rdx], xmm15
0000710a0d1d506e  movaps [rcx], xmm10
0000710a0d1d5072  mov rax, 0x64F334B05A50
0000710a0d1d507c  call rax
0000710a0d1d507e  movaps xmm6, [rsp]
0000710a0d1d5082  add rsp, 0x40
0000710a0d1d5086  vmovaps xmm0, [rsp]
0000710a0d1d508b  vmovaps xmm1, [rsp+0x10]
0000710a0d1d5091  vmovaps xmm2, [rsp+0x20]
0000710a0d1d5097  vmovaps xmm3, [rsp+0x30]
0000710a0d1d509d  vmovaps xmm4, [rsp+0x40]
0000710a0d1d50a3  vmovaps xmm5, [rsp+0x50]
0000710a0d1d50a9  vmovaps xmm7, [rsp+0x60]
0000710a0d1d50af  vmovaps xmm8, [rsp+0x70]
0000710a0d1d50b5  vmovaps xmm9, [rsp+0x80]
0000710a0d1d50be  vmovaps xmm10, [rsp+0x90]
0000710a0d1d50c7  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d50d0  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d50d9  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d50e2  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d50eb  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d50f4  add rsp, 0xF0
0000710a0d1d50fb  pop r11
0000710a0d1d50fd  pop r10
0000710a0d1d50ff  pop r9
0000710a0d1d5101  pop r8
0000710a0d1d5103  pop rsi
0000710a0d1d5104  pop rdi
0000710a0d1d5105  pop rdx
0000710a0d1d5106  pop rcx
0000710a0d1d5107  pop rax
0000710a0d1d5108  add rsp, 0x08
0000710a0d1d510c  jmp 0x0000710A0D1D2FA4
0000710a0d1d5111  sub rsp, 0x08
0000710a0d1d5115  push rax
0000710a0d1d5116  push rcx
0000710a0d1d5117  push rdx
0000710a0d1d5118  push rdi
0000710a0d1d5119  push rsi
0000710a0d1d511a  push r8
0000710a0d1d511c  push r9
0000710a0d1d511e  push r10
0000710a0d1d5120  push r11
0000710a0d1d5122  sub rsp, 0xF0
0000710a0d1d5129  vmovaps [rsp], xmm0
0000710a0d1d512e  vmovaps [rsp+0x10], xmm1
0000710a0d1d5134  vmovaps [rsp+0x20], xmm2
0000710a0d1d513a  vmovaps [rsp+0x30], xmm3
0000710a0d1d5140  vmovaps [rsp+0x40], xmm4
0000710a0d1d5146  vmovaps [rsp+0x50], xmm5
0000710a0d1d514c  vmovaps [rsp+0x60], xmm6
0000710a0d1d5152  vmovaps [rsp+0x70], xmm7
0000710a0d1d5158  vmovaps [rsp+0x80], xmm8
0000710a0d1d5161  vmovaps [rsp+0x90], xmm9
0000710a0d1d516a  vmovaps [rsp+0xA0], xmm11
0000710a0d1d5173  vmovaps [rsp+0xB0], xmm12
0000710a0d1d517c  vmovaps [rsp+0xC0], xmm13
0000710a0d1d5185  vmovaps [rsp+0xD0], xmm14
0000710a0d1d518e  vmovaps [rsp+0xE0], xmm15
0000710a0d1d5197  sub rsp, 0x40
0000710a0d1d519b  lea rdi, [rsp]
0000710a0d1d519f  lea rsi, [rsp+0x10]
0000710a0d1d51a4  lea rdx, [rsp+0x20]
0000710a0d1d51a9  lea rcx, [rsp+0x30]
0000710a0d1d51ae  mov r8d, 0x00
0000710a0d1d51b4  lea r9, [r15+0x3A8]
0000710a0d1d51bb  movaps [rdi], xmm10
0000710a0d1d51bf  movaps [rsi], xmm9
0000710a0d1d51c3  movaps [rdx], xmm13
0000710a0d1d51c7  movaps [rcx], xmm15
0000710a0d1d51cb  mov rax, 0x64F334B05A50
0000710a0d1d51d5  call rax
0000710a0d1d51d7  movaps xmm10, [rsp]
0000710a0d1d51dc  add rsp, 0x40
0000710a0d1d51e0  vmovaps xmm0, [rsp]
0000710a0d1d51e5  vmovaps xmm1, [rsp+0x10]
0000710a0d1d51eb  vmovaps xmm2, [rsp+0x20]
0000710a0d1d51f1  vmovaps xmm3, [rsp+0x30]
0000710a0d1d51f7  vmovaps xmm4, [rsp+0x40]
0000710a0d1d51fd  vmovaps xmm5, [rsp+0x50]
0000710a0d1d5203  vmovaps xmm6, [rsp+0x60]
0000710a0d1d5209  vmovaps xmm7, [rsp+0x70]
0000710a0d1d520f  vmovaps xmm8, [rsp+0x80]
0000710a0d1d5218  vmovaps xmm9, [rsp+0x90]
0000710a0d1d5221  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d522a  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d5233  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d523c  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d5245  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d524e  add rsp, 0xF0
0000710a0d1d5255  pop r11
0000710a0d1d5257  pop r10
0000710a0d1d5259  pop r9
0000710a0d1d525b  pop r8
0000710a0d1d525d  pop rsi
0000710a0d1d525e  pop rdi
0000710a0d1d525f  pop rdx
0000710a0d1d5260  pop rcx
0000710a0d1d5261  pop rax
0000710a0d1d5262  add rsp, 0x08
0000710a0d1d5266  jmp 0x0000710A0D1D2FCD
0000710a0d1d526b  sub rsp, 0x08
0000710a0d1d526f  push rax
0000710a0d1d5270  push rcx
0000710a0d1d5271  push rdx
0000710a0d1d5272  push rdi
0000710a0d1d5273  push rsi
0000710a0d1d5274  push r8
0000710a0d1d5276  push r9
0000710a0d1d5278  push r10
0000710a0d1d527a  push r11
0000710a0d1d527c  sub rsp, 0xF0
0000710a0d1d5283  vmovaps [rsp], xmm0
0000710a0d1d5288  vmovaps [rsp+0x10], xmm1
0000710a0d1d528e  vmovaps [rsp+0x20], xmm2
0000710a0d1d5294  vmovaps [rsp+0x30], xmm3
0000710a0d1d529a  vmovaps [rsp+0x40], xmm4
0000710a0d1d52a0  vmovaps [rsp+0x50], xmm5
0000710a0d1d52a6  vmovaps [rsp+0x60], xmm6
0000710a0d1d52ac  vmovaps [rsp+0x70], xmm7
0000710a0d1d52b2  vmovaps [rsp+0x80], xmm8
0000710a0d1d52bb  vmovaps [rsp+0x90], xmm9
0000710a0d1d52c4  vmovaps [rsp+0xA0], xmm10
0000710a0d1d52cd  vmovaps [rsp+0xB0], xmm11
0000710a0d1d52d6  vmovaps [rsp+0xC0], xmm12
0000710a0d1d52df  vmovaps [rsp+0xD0], xmm14
0000710a0d1d52e8  vmovaps [rsp+0xE0], xmm15
0000710a0d1d52f1  sub rsp, 0x40
0000710a0d1d52f5  lea rdi, [rsp]
0000710a0d1d52f9  lea rsi, [rsp+0x10]
0000710a0d1d52fe  lea rdx, [rsp+0x20]
0000710a0d1d5303  lea rcx, [rsp+0x30]
0000710a0d1d5308  mov r8d, 0x00
0000710a0d1d530e  lea r9, [r15+0x3A8]
0000710a0d1d5315  movaps [rdi], xmm13
0000710a0d1d5319  movaps [rsi], xmm12
0000710a0d1d531d  movaps [rdx], xmm4
0000710a0d1d5320  movaps [rcx], xmm15
0000710a0d1d5324  mov rax, 0x64F334B05A50
0000710a0d1d532e  call rax
0000710a0d1d5330  movaps xmm13, [rsp]
0000710a0d1d5335  add rsp, 0x40
0000710a0d1d5339  vmovaps xmm0, [rsp]
0000710a0d1d533e  vmovaps xmm1, [rsp+0x10]
0000710a0d1d5344  vmovaps xmm2, [rsp+0x20]
0000710a0d1d534a  vmovaps xmm3, [rsp+0x30]
0000710a0d1d5350  vmovaps xmm4, [rsp+0x40]
0000710a0d1d5356  vmovaps xmm5, [rsp+0x50]
0000710a0d1d535c  vmovaps xmm6, [rsp+0x60]
0000710a0d1d5362  vmovaps xmm7, [rsp+0x70]
0000710a0d1d5368  vmovaps xmm8, [rsp+0x80]
0000710a0d1d5371  vmovaps xmm9, [rsp+0x90]
0000710a0d1d537a  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d5383  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d538c  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d5395  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d539e  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d53a7  add rsp, 0xF0
0000710a0d1d53ae  pop r11
0000710a0d1d53b0  pop r10
0000710a0d1d53b2  pop r9
0000710a0d1d53b4  pop r8
0000710a0d1d53b6  pop rsi
0000710a0d1d53b7  pop rdi
0000710a0d1d53b8  pop rdx
0000710a0d1d53b9  pop rcx
0000710a0d1d53ba  pop rax
0000710a0d1d53bb  add rsp, 0x08
0000710a0d1d53bf  jmp 0x0000710A0D1D2FF6
0000710a0d1d53c4  sub rsp, 0x08
0000710a0d1d53c8  push rax
0000710a0d1d53c9  push rcx
0000710a0d1d53ca  push rdx
0000710a0d1d53cb  push rdi
0000710a0d1d53cc  push rsi
0000710a0d1d53cd  push r8
0000710a0d1d53cf  push r9
0000710a0d1d53d1  push r10
0000710a0d1d53d3  push r11
0000710a0d1d53d5  sub rsp, 0xF0
0000710a0d1d53dc  vmovaps [rsp], xmm0
0000710a0d1d53e1  vmovaps [rsp+0x10], xmm1
0000710a0d1d53e7  vmovaps [rsp+0x20], xmm2
0000710a0d1d53ed  vmovaps [rsp+0x30], xmm3
0000710a0d1d53f3  vmovaps [rsp+0x40], xmm4
0000710a0d1d53f9  vmovaps [rsp+0x50], xmm5
0000710a0d1d53ff  vmovaps [rsp+0x60], xmm6
0000710a0d1d5405  vmovaps [rsp+0x70], xmm7
0000710a0d1d540b  vmovaps [rsp+0x80], xmm8
0000710a0d1d5414  vmovaps [rsp+0x90], xmm9
0000710a0d1d541d  vmovaps [rsp+0xA0], xmm10
0000710a0d1d5426  vmovaps [rsp+0xB0], xmm11
0000710a0d1d542f  vmovaps [rsp+0xC0], xmm13
0000710a0d1d5438  vmovaps [rsp+0xD0], xmm14
0000710a0d1d5441  vmovaps [rsp+0xE0], xmm15
0000710a0d1d544a  sub rsp, 0x40
0000710a0d1d544e  lea rdi, [rsp]
0000710a0d1d5452  lea rsi, [rsp+0x10]
0000710a0d1d5457  lea rdx, [rsp+0x20]
0000710a0d1d545c  lea rcx, [rsp+0x30]
0000710a0d1d5461  mov r8d, 0x00
0000710a0d1d5467  lea r9, [r15+0x3A8]
0000710a0d1d546e  movaps [rdi], xmm12
0000710a0d1d5472  movaps [rsi], xmm7
0000710a0d1d5475  movaps [rdx], xmm1
0000710a0d1d5478  movaps [rcx], xmm15
0000710a0d1d547c  mov rax, 0x64F334B05A50
0000710a0d1d5486  call rax
0000710a0d1d5488  movaps xmm12, [rsp]
0000710a0d1d548d  add rsp, 0x40
0000710a0d1d5491  vmovaps xmm0, [rsp]
0000710a0d1d5496  vmovaps xmm1, [rsp+0x10]
0000710a0d1d549c  vmovaps xmm2, [rsp+0x20]
0000710a0d1d54a2  vmovaps xmm3, [rsp+0x30]
0000710a0d1d54a8  vmovaps xmm4, [rsp+0x40]
0000710a0d1d54ae  vmovaps xmm5, [rsp+0x50]
0000710a0d1d54b4  vmovaps xmm6, [rsp+0x60]
0000710a0d1d54ba  vmovaps xmm7, [rsp+0x70]
0000710a0d1d54c0  vmovaps xmm8, [rsp+0x80]
0000710a0d1d54c9  vmovaps xmm9, [rsp+0x90]
0000710a0d1d54d2  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d54db  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d54e4  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d54ed  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d54f6  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d54ff  add rsp, 0xF0
0000710a0d1d5506  pop r11
0000710a0d1d5508  pop r10
0000710a0d1d550a  pop r9
0000710a0d1d550c  pop r8
0000710a0d1d550e  pop rsi
0000710a0d1d550f  pop rdi
0000710a0d1d5510  pop rdx
0000710a0d1d5511  pop rcx
0000710a0d1d5512  pop rax
0000710a0d1d5513  add rsp, 0x08
0000710a0d1d5517  jmp 0x0000710A0D1D301F
0000710a0d1d551c  call 0x0000710A0CFFF430
0000710a0d1d5521  jmp 0x0000710A0D1D3029
0000710a0d1d5526  call 0x0000710A0D00E760
0000710a0d1d552b  jmp 0x0000710A0D1D3033
0000710a0d1d5530  sub rsp, 0x08
0000710a0d1d5534  push rax
0000710a0d1d5535  push rcx
0000710a0d1d5536  push rdx
0000710a0d1d5537  push rdi
0000710a0d1d5538  push rsi
0000710a0d1d5539  push r8
0000710a0d1d553b  push r9
0000710a0d1d553d  push r10
0000710a0d1d553f  push r11
0000710a0d1d5541  sub rsp, 0xF0
0000710a0d1d5548  vmovaps [rsp], xmm0
0000710a0d1d554d  vmovaps [rsp+0x10], xmm1
0000710a0d1d5553  vmovaps [rsp+0x20], xmm2
0000710a0d1d5559  vmovaps [rsp+0x30], xmm3
0000710a0d1d555f  vmovaps [rsp+0x40], xmm4
0000710a0d1d5565  vmovaps [rsp+0x50], xmm5
0000710a0d1d556b  vmovaps [rsp+0x60], xmm6
0000710a0d1d5571  vmovaps [rsp+0x70], xmm8
0000710a0d1d5577  vmovaps [rsp+0x80], xmm9
0000710a0d1d5580  vmovaps [rsp+0x90], xmm10
0000710a0d1d5589  vmovaps [rsp+0xA0], xmm11
0000710a0d1d5592  vmovaps [rsp+0xB0], xmm12
0000710a0d1d559b  vmovaps [rsp+0xC0], xmm13
0000710a0d1d55a4  vmovaps [rsp+0xD0], xmm14
0000710a0d1d55ad  vmovaps [rsp+0xE0], xmm15
0000710a0d1d55b6  sub rsp, 0x40
0000710a0d1d55ba  lea rdi, [rsp]
0000710a0d1d55be  lea rsi, [rsp+0x10]
0000710a0d1d55c3  lea rdx, [rsp+0x20]
0000710a0d1d55c8  lea rcx, [rsp+0x30]
0000710a0d1d55cd  mov r8d, 0x00
0000710a0d1d55d3  lea r9, [r15+0x3A8]
0000710a0d1d55da  movaps [rdi], xmm7
0000710a0d1d55dd  movaps [rsi], xmm6
0000710a0d1d55e0  movaps [rdx], xmm8
0000710a0d1d55e4  movaps [rcx], xmm9
0000710a0d1d55e8  mov rax, 0x64F334B05A50
0000710a0d1d55f2  call rax
0000710a0d1d55f4  movaps xmm7, [rsp]
0000710a0d1d55f8  add rsp, 0x40
0000710a0d1d55fc  vmovaps xmm0, [rsp]
0000710a0d1d5601  vmovaps xmm1, [rsp+0x10]
0000710a0d1d5607  vmovaps xmm2, [rsp+0x20]
0000710a0d1d560d  vmovaps xmm3, [rsp+0x30]
0000710a0d1d5613  vmovaps xmm4, [rsp+0x40]
0000710a0d1d5619  vmovaps xmm5, [rsp+0x50]
0000710a0d1d561f  vmovaps xmm6, [rsp+0x60]
0000710a0d1d5625  vmovaps xmm8, [rsp+0x70]
0000710a0d1d562b  vmovaps xmm9, [rsp+0x80]
0000710a0d1d5634  vmovaps xmm10, [rsp+0x90]
0000710a0d1d563d  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d5646  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d564f  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d5658  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d5661  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d566a  add rsp, 0xF0
0000710a0d1d5671  pop r11
0000710a0d1d5673  pop r10
0000710a0d1d5675  pop r9
0000710a0d1d5677  pop r8
0000710a0d1d5679  pop rsi
0000710a0d1d567a  pop rdi
0000710a0d1d567b  pop rdx
0000710a0d1d567c  pop rcx
0000710a0d1d567d  pop rax
0000710a0d1d567e  add rsp, 0x08
0000710a0d1d5682  jmp 0x0000710A0D1D305D
0000710a0d1d5687  sub rsp, 0x08
0000710a0d1d568b  push rax
0000710a0d1d568c  push rcx
0000710a0d1d568d  push rdx
0000710a0d1d568e  push rdi
0000710a0d1d568f  push rsi
0000710a0d1d5690  push r8
0000710a0d1d5692  push r9
0000710a0d1d5694  push r10
0000710a0d1d5696  push r11
0000710a0d1d5698  sub rsp, 0xF0
0000710a0d1d569f  vmovaps [rsp], xmm0
0000710a0d1d56a4  vmovaps [rsp+0x10], xmm1
0000710a0d1d56aa  vmovaps [rsp+0x20], xmm2
0000710a0d1d56b0  vmovaps [rsp+0x30], xmm3
0000710a0d1d56b6  vmovaps [rsp+0x40], xmm4
0000710a0d1d56bc  vmovaps [rsp+0x50], xmm5
0000710a0d1d56c2  vmovaps [rsp+0x60], xmm6
0000710a0d1d56c8  vmovaps [rsp+0x70], xmm7
0000710a0d1d56ce  vmovaps [rsp+0x80], xmm9
0000710a0d1d56d7  vmovaps [rsp+0x90], xmm10
0000710a0d1d56e0  vmovaps [rsp+0xA0], xmm11
0000710a0d1d56e9  vmovaps [rsp+0xB0], xmm12
0000710a0d1d56f2  vmovaps [rsp+0xC0], xmm13
0000710a0d1d56fb  vmovaps [rsp+0xD0], xmm14
0000710a0d1d5704  vmovaps [rsp+0xE0], xmm15
0000710a0d1d570d  sub rsp, 0x40
0000710a0d1d5711  lea rdi, [rsp]
0000710a0d1d5715  lea rsi, [rsp+0x10]
0000710a0d1d571a  lea rdx, [rsp+0x20]
0000710a0d1d571f  lea rcx, [rsp+0x30]
0000710a0d1d5724  mov r8d, 0x00
0000710a0d1d572a  lea r9, [r15+0x3A8]
0000710a0d1d5731  movaps [rdi], xmm8
0000710a0d1d5735  movaps [rsi], xmm10
0000710a0d1d5739  movaps [rdx], xmm14
0000710a0d1d573d  movaps [rcx], xmm9
0000710a0d1d5741  mov rax, 0x64F334B05A50
0000710a0d1d574b  call rax
0000710a0d1d574d  movaps xmm8, [rsp]
0000710a0d1d5752  add rsp, 0x40
0000710a0d1d5756  vmovaps xmm0, [rsp]
0000710a0d1d575b  vmovaps xmm1, [rsp+0x10]
0000710a0d1d5761  vmovaps xmm2, [rsp+0x20]
0000710a0d1d5767  vmovaps xmm3, [rsp+0x30]
0000710a0d1d576d  vmovaps xmm4, [rsp+0x40]
0000710a0d1d5773  vmovaps xmm5, [rsp+0x50]
0000710a0d1d5779  vmovaps xmm6, [rsp+0x60]
0000710a0d1d577f  vmovaps xmm7, [rsp+0x70]
0000710a0d1d5785  vmovaps xmm9, [rsp+0x80]
0000710a0d1d578e  vmovaps xmm10, [rsp+0x90]
0000710a0d1d5797  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d57a0  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d57a9  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d57b2  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d57bb  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d57c4  add rsp, 0xF0
0000710a0d1d57cb  pop r11
0000710a0d1d57cd  pop r10
0000710a0d1d57cf  pop r9
0000710a0d1d57d1  pop r8
0000710a0d1d57d3  pop rsi
0000710a0d1d57d4  pop rdi
0000710a0d1d57d5  pop rdx
0000710a0d1d57d6  pop rcx
0000710a0d1d57d7  pop rax
0000710a0d1d57d8  add rsp, 0x08
0000710a0d1d57dc  jmp 0x0000710A0D1D3083
0000710a0d1d57e1  sub rsp, 0x08
0000710a0d1d57e5  push rax
0000710a0d1d57e6  push rcx
0000710a0d1d57e7  push rdx
0000710a0d1d57e8  push rdi
0000710a0d1d57e9  push rsi
0000710a0d1d57ea  push r8
0000710a0d1d57ec  push r9
0000710a0d1d57ee  push r10
0000710a0d1d57f0  push r11
0000710a0d1d57f2  sub rsp, 0xF0
0000710a0d1d57f9  vmovaps [rsp], xmm0
0000710a0d1d57fe  vmovaps [rsp+0x10], xmm1
0000710a0d1d5804  vmovaps [rsp+0x20], xmm2
0000710a0d1d580a  vmovaps [rsp+0x30], xmm3
0000710a0d1d5810  vmovaps [rsp+0x40], xmm4
0000710a0d1d5816  vmovaps [rsp+0x50], xmm5
0000710a0d1d581c  vmovaps [rsp+0x60], xmm6
0000710a0d1d5822  vmovaps [rsp+0x70], xmm7
0000710a0d1d5828  vmovaps [rsp+0x80], xmm8
0000710a0d1d5831  vmovaps [rsp+0x90], xmm9
0000710a0d1d583a  vmovaps [rsp+0xA0], xmm11
0000710a0d1d5843  vmovaps [rsp+0xB0], xmm12
0000710a0d1d584c  vmovaps [rsp+0xC0], xmm13
0000710a0d1d5855  vmovaps [rsp+0xD0], xmm14
0000710a0d1d585e  vmovaps [rsp+0xE0], xmm15
0000710a0d1d5867  sub rsp, 0x40
0000710a0d1d586b  lea rdi, [rsp]
0000710a0d1d586f  lea rsi, [rsp+0x10]
0000710a0d1d5874  lea rdx, [rsp+0x20]
0000710a0d1d5879  lea rcx, [rsp+0x30]
0000710a0d1d587e  mov r8d, 0x00
0000710a0d1d5884  lea r9, [r15+0x3A8]
0000710a0d1d588b  movaps [rdi], xmm10
0000710a0d1d588f  movaps [rsi], xmm13
0000710a0d1d5893  movaps [rdx], xmm11
0000710a0d1d5897  movaps [rcx], xmm14
0000710a0d1d589b  mov rax, 0x64F334B05A50
0000710a0d1d58a5  call rax
0000710a0d1d58a7  movaps xmm10, [rsp]
0000710a0d1d58ac  add rsp, 0x40
0000710a0d1d58b0  vmovaps xmm0, [rsp]
0000710a0d1d58b5  vmovaps xmm1, [rsp+0x10]
0000710a0d1d58bb  vmovaps xmm2, [rsp+0x20]
0000710a0d1d58c1  vmovaps xmm3, [rsp+0x30]
0000710a0d1d58c7  vmovaps xmm4, [rsp+0x40]
0000710a0d1d58cd  vmovaps xmm5, [rsp+0x50]
0000710a0d1d58d3  vmovaps xmm6, [rsp+0x60]
0000710a0d1d58d9  vmovaps xmm7, [rsp+0x70]
0000710a0d1d58df  vmovaps xmm8, [rsp+0x80]
0000710a0d1d58e8  vmovaps xmm9, [rsp+0x90]
0000710a0d1d58f1  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d58fa  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d5903  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d590c  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d5915  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d591e  add rsp, 0xF0
0000710a0d1d5925  pop r11
0000710a0d1d5927  pop r10
0000710a0d1d5929  pop r9
0000710a0d1d592b  pop r8
0000710a0d1d592d  pop rsi
0000710a0d1d592e  pop rdi
0000710a0d1d592f  pop rdx
0000710a0d1d5930  pop rcx
0000710a0d1d5931  pop rax
0000710a0d1d5932  add rsp, 0x08
0000710a0d1d5936  jmp 0x0000710A0D1D30A9
0000710a0d1d593b  sub rsp, 0x08
0000710a0d1d593f  push rax
0000710a0d1d5940  push rcx
0000710a0d1d5941  push rdx
0000710a0d1d5942  push rdi
0000710a0d1d5943  push rsi
0000710a0d1d5944  push r8
0000710a0d1d5946  push r9
0000710a0d1d5948  push r10
0000710a0d1d594a  push r11
0000710a0d1d594c  sub rsp, 0xF0
0000710a0d1d5953  vmovaps [rsp], xmm0
0000710a0d1d5958  vmovaps [rsp+0x10], xmm1
0000710a0d1d595e  vmovaps [rsp+0x20], xmm2
0000710a0d1d5964  vmovaps [rsp+0x30], xmm3
0000710a0d1d596a  vmovaps [rsp+0x40], xmm4
0000710a0d1d5970  vmovaps [rsp+0x50], xmm5
0000710a0d1d5976  vmovaps [rsp+0x60], xmm6
0000710a0d1d597c  vmovaps [rsp+0x70], xmm7
0000710a0d1d5982  vmovaps [rsp+0x80], xmm8
0000710a0d1d598b  vmovaps [rsp+0x90], xmm9
0000710a0d1d5994  vmovaps [rsp+0xA0], xmm10
0000710a0d1d599d  vmovaps [rsp+0xB0], xmm11
0000710a0d1d59a6  vmovaps [rsp+0xC0], xmm12
0000710a0d1d59af  vmovaps [rsp+0xD0], xmm14
0000710a0d1d59b8  vmovaps [rsp+0xE0], xmm15
0000710a0d1d59c1  sub rsp, 0x40
0000710a0d1d59c5  lea rdi, [rsp]
0000710a0d1d59c9  lea rsi, [rsp+0x10]
0000710a0d1d59ce  lea rdx, [rsp+0x20]
0000710a0d1d59d3  lea rcx, [rsp+0x30]
0000710a0d1d59d8  mov r8d, 0x00
0000710a0d1d59de  lea r9, [r15+0x3A8]
0000710a0d1d59e5  movaps [rdi], xmm13
0000710a0d1d59e9  movaps [rsi], xmm12
0000710a0d1d59ed  movaps [rdx], xmm15
0000710a0d1d59f1  movaps [rcx], xmm14
0000710a0d1d59f5  mov rax, 0x64F334B05A50
0000710a0d1d59ff  call rax
0000710a0d1d5a01  movaps xmm13, [rsp]
0000710a0d1d5a06  add rsp, 0x40
0000710a0d1d5a0a  vmovaps xmm0, [rsp]
0000710a0d1d5a0f  vmovaps xmm1, [rsp+0x10]
0000710a0d1d5a15  vmovaps xmm2, [rsp+0x20]
0000710a0d1d5a1b  vmovaps xmm3, [rsp+0x30]
0000710a0d1d5a21  vmovaps xmm4, [rsp+0x40]
0000710a0d1d5a27  vmovaps xmm5, [rsp+0x50]
0000710a0d1d5a2d  vmovaps xmm6, [rsp+0x60]
0000710a0d1d5a33  vmovaps xmm7, [rsp+0x70]
0000710a0d1d5a39  vmovaps xmm8, [rsp+0x80]
0000710a0d1d5a42  vmovaps xmm9, [rsp+0x90]
0000710a0d1d5a4b  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d5a54  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d5a5d  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d5a66  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d5a6f  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d5a78  add rsp, 0xF0
0000710a0d1d5a7f  pop r11
0000710a0d1d5a81  pop r10
0000710a0d1d5a83  pop r9
0000710a0d1d5a85  pop r8
0000710a0d1d5a87  pop rsi
0000710a0d1d5a88  pop rdi
0000710a0d1d5a89  pop rdx
0000710a0d1d5a8a  pop rcx
0000710a0d1d5a8b  pop rax
0000710a0d1d5a8c  add rsp, 0x08
0000710a0d1d5a90  jmp 0x0000710A0D1D30CF
0000710a0d1d5a95  call 0x0000710A0D00E760
0000710a0d1d5a9a  jmp 0x0000710A0D1D30DC
0000710a0d1d5a9f  call 0x0000710A0D00D4E0
0000710a0d1d5aa4  jmp 0x0000710A0D1D30E9
0000710a0d1d5aa9  sub rsp, 0x08
0000710a0d1d5aad  push rax
0000710a0d1d5aae  push rcx
0000710a0d1d5aaf  push rdx
0000710a0d1d5ab0  push rdi
0000710a0d1d5ab1  push rsi
0000710a0d1d5ab2  push r8
0000710a0d1d5ab4  push r9
0000710a0d1d5ab6  push r10
0000710a0d1d5ab8  push r11
0000710a0d1d5aba  sub rsp, 0xF0
0000710a0d1d5ac1  vmovaps [rsp], xmm0
0000710a0d1d5ac6  vmovaps [rsp+0x10], xmm1
0000710a0d1d5acc  vmovaps [rsp+0x20], xmm2
0000710a0d1d5ad2  vmovaps [rsp+0x30], xmm3
0000710a0d1d5ad8  vmovaps [rsp+0x40], xmm4
0000710a0d1d5ade  vmovaps [rsp+0x50], xmm5
0000710a0d1d5ae4  vmovaps [rsp+0x60], xmm6
0000710a0d1d5aea  vmovaps [rsp+0x70], xmm7
0000710a0d1d5af0  vmovaps [rsp+0x80], xmm8
0000710a0d1d5af9  vmovaps [rsp+0x90], xmm9
0000710a0d1d5b02  vmovaps [rsp+0xA0], xmm10
0000710a0d1d5b0b  vmovaps [rsp+0xB0], xmm12
0000710a0d1d5b14  vmovaps [rsp+0xC0], xmm13
0000710a0d1d5b1d  vmovaps [rsp+0xD0], xmm14
0000710a0d1d5b26  vmovaps [rsp+0xE0], xmm15
0000710a0d1d5b2f  sub rsp, 0x40
0000710a0d1d5b33  lea rdi, [rsp]
0000710a0d1d5b37  lea rsi, [rsp+0x10]
0000710a0d1d5b3c  lea rdx, [rsp+0x20]
0000710a0d1d5b41  lea rcx, [rsp+0x30]
0000710a0d1d5b46  mov r8d, 0x00
0000710a0d1d5b4c  lea r9, [r15+0x3A8]
0000710a0d1d5b53  movaps [rdi], xmm11
0000710a0d1d5b57  movaps [rsi], xmm7
0000710a0d1d5b5a  movaps [rdx], xmm1
0000710a0d1d5b5d  movaps [rcx], xmm12
0000710a0d1d5b61  mov rax, 0x64F334B05A50
0000710a0d1d5b6b  call rax
0000710a0d1d5b6d  movaps xmm11, [rsp]
0000710a0d1d5b72  add rsp, 0x40
0000710a0d1d5b76  vmovaps xmm0, [rsp]
0000710a0d1d5b7b  vmovaps xmm1, [rsp+0x10]
0000710a0d1d5b81  vmovaps xmm2, [rsp+0x20]
0000710a0d1d5b87  vmovaps xmm3, [rsp+0x30]
0000710a0d1d5b8d  vmovaps xmm4, [rsp+0x40]
0000710a0d1d5b93  vmovaps xmm5, [rsp+0x50]
0000710a0d1d5b99  vmovaps xmm6, [rsp+0x60]
0000710a0d1d5b9f  vmovaps xmm7, [rsp+0x70]
0000710a0d1d5ba5  vmovaps xmm8, [rsp+0x80]
0000710a0d1d5bae  vmovaps xmm9, [rsp+0x90]
0000710a0d1d5bb7  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d5bc0  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d5bc9  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d5bd2  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d5bdb  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d5be4  add rsp, 0xF0
0000710a0d1d5beb  pop r11
0000710a0d1d5bed  pop r10
0000710a0d1d5bef  pop r9
0000710a0d1d5bf1  pop r8
0000710a0d1d5bf3  pop rsi
0000710a0d1d5bf4  pop rdi
0000710a0d1d5bf5  pop rdx
0000710a0d1d5bf6  pop rcx
0000710a0d1d5bf7  pop rax
0000710a0d1d5bf8  add rsp, 0x08
0000710a0d1d5bfc  jmp 0x0000710A0D1D3122
0000710a0d1d5c01  call 0x0000710A0CFFF430
0000710a0d1d5c06  jmp 0x0000710A0D1D3134
0000710a0d1d5c0b  sub rsp, 0x08
0000710a0d1d5c0f  push rax
0000710a0d1d5c10  push rcx
0000710a0d1d5c11  push rdx
0000710a0d1d5c12  push rdi
0000710a0d1d5c13  push rsi
0000710a0d1d5c14  push r8
0000710a0d1d5c16  push r9
0000710a0d1d5c18  push r10
0000710a0d1d5c1a  push r11
0000710a0d1d5c1c  sub rsp, 0xF0
0000710a0d1d5c23  vmovaps [rsp], xmm0
0000710a0d1d5c28  vmovaps [rsp+0x10], xmm1
0000710a0d1d5c2e  vmovaps [rsp+0x20], xmm2
0000710a0d1d5c34  vmovaps [rsp+0x30], xmm3
0000710a0d1d5c3a  vmovaps [rsp+0x40], xmm4
0000710a0d1d5c40  vmovaps [rsp+0x50], xmm5
0000710a0d1d5c46  vmovaps [rsp+0x60], xmm6
0000710a0d1d5c4c  vmovaps [rsp+0x70], xmm7
0000710a0d1d5c52  vmovaps [rsp+0x80], xmm8
0000710a0d1d5c5b  vmovaps [rsp+0x90], xmm10
0000710a0d1d5c64  vmovaps [rsp+0xA0], xmm11
0000710a0d1d5c6d  vmovaps [rsp+0xB0], xmm12
0000710a0d1d5c76  vmovaps [rsp+0xC0], xmm13
0000710a0d1d5c7f  vmovaps [rsp+0xD0], xmm14
0000710a0d1d5c88  vmovaps [rsp+0xE0], xmm15
0000710a0d1d5c91  sub rsp, 0x40
0000710a0d1d5c95  lea rdi, [rsp]
0000710a0d1d5c99  lea rsi, [rsp+0x10]
0000710a0d1d5c9e  lea rdx, [rsp+0x20]
0000710a0d1d5ca3  lea rcx, [rsp+0x30]
0000710a0d1d5ca8  mov r8d, 0x00
0000710a0d1d5cae  lea r9, [r15+0x3A8]
0000710a0d1d5cb5  movaps [rdi], xmm9
0000710a0d1d5cb9  movaps [rsi], xmm8
0000710a0d1d5cbd  movaps [rdx], xmm14
0000710a0d1d5cc1  movaps [rcx], xmm12
0000710a0d1d5cc5  mov rax, 0x64F334B05A50
0000710a0d1d5ccf  call rax
0000710a0d1d5cd1  movaps xmm9, [rsp]
0000710a0d1d5cd6  add rsp, 0x40
0000710a0d1d5cda  vmovaps xmm0, [rsp]
0000710a0d1d5cdf  vmovaps xmm1, [rsp+0x10]
0000710a0d1d5ce5  vmovaps xmm2, [rsp+0x20]
0000710a0d1d5ceb  vmovaps xmm3, [rsp+0x30]
0000710a0d1d5cf1  vmovaps xmm4, [rsp+0x40]
0000710a0d1d5cf7  vmovaps xmm5, [rsp+0x50]
0000710a0d1d5cfd  vmovaps xmm6, [rsp+0x60]
0000710a0d1d5d03  vmovaps xmm7, [rsp+0x70]
0000710a0d1d5d09  vmovaps xmm8, [rsp+0x80]
0000710a0d1d5d12  vmovaps xmm10, [rsp+0x90]
0000710a0d1d5d1b  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d5d24  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d5d2d  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d5d36  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d5d3f  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d5d48  add rsp, 0xF0
0000710a0d1d5d4f  pop r11
0000710a0d1d5d51  pop r10
0000710a0d1d5d53  pop r9
0000710a0d1d5d55  pop r8
0000710a0d1d5d57  pop rsi
0000710a0d1d5d58  pop rdi
0000710a0d1d5d59  pop rdx
0000710a0d1d5d5a  pop rcx
0000710a0d1d5d5b  pop rax
0000710a0d1d5d5c  add rsp, 0x08
0000710a0d1d5d60  jmp 0x0000710A0D1D3165
0000710a0d1d5d65  sub rsp, 0x08
0000710a0d1d5d69  push rax
0000710a0d1d5d6a  push rcx
0000710a0d1d5d6b  push rdx
0000710a0d1d5d6c  push rdi
0000710a0d1d5d6d  push rsi
0000710a0d1d5d6e  push r8
0000710a0d1d5d70  push r9
0000710a0d1d5d72  push r10
0000710a0d1d5d74  push r11
0000710a0d1d5d76  sub rsp, 0xF0
0000710a0d1d5d7d  vmovaps [rsp], xmm0
0000710a0d1d5d82  vmovaps [rsp+0x10], xmm1
0000710a0d1d5d88  vmovaps [rsp+0x20], xmm2
0000710a0d1d5d8e  vmovaps [rsp+0x30], xmm3
0000710a0d1d5d94  vmovaps [rsp+0x40], xmm4
0000710a0d1d5d9a  vmovaps [rsp+0x50], xmm5
0000710a0d1d5da0  vmovaps [rsp+0x60], xmm6
0000710a0d1d5da6  vmovaps [rsp+0x70], xmm7
0000710a0d1d5dac  vmovaps [rsp+0x80], xmm8
0000710a0d1d5db5  vmovaps [rsp+0x90], xmm9
0000710a0d1d5dbe  vmovaps [rsp+0xA0], xmm10
0000710a0d1d5dc7  vmovaps [rsp+0xB0], xmm11
0000710a0d1d5dd0  vmovaps [rsp+0xC0], xmm13
0000710a0d1d5dd9  vmovaps [rsp+0xD0], xmm14
0000710a0d1d5de2  vmovaps [rsp+0xE0], xmm15
0000710a0d1d5deb  sub rsp, 0x40
0000710a0d1d5def  lea rdi, [rsp]
0000710a0d1d5df3  lea rsi, [rsp+0x10]
0000710a0d1d5df8  lea rdx, [rsp+0x20]
0000710a0d1d5dfd  lea rcx, [rsp+0x30]
0000710a0d1d5e02  mov r8d, 0x00
0000710a0d1d5e08  lea r9, [r15+0x3A8]
0000710a0d1d5e0f  movaps [rdi], xmm12
0000710a0d1d5e13  movaps [rsi], xmm10
0000710a0d1d5e17  movaps [rdx], xmm15
0000710a0d1d5e1b  movaps [rcx], xmm14
0000710a0d1d5e1f  mov rax, 0x64F334B05A50
0000710a0d1d5e29  call rax
0000710a0d1d5e2b  movaps xmm12, [rsp]
0000710a0d1d5e30  add rsp, 0x40
0000710a0d1d5e34  vmovaps xmm0, [rsp]
0000710a0d1d5e39  vmovaps xmm1, [rsp+0x10]
0000710a0d1d5e3f  vmovaps xmm2, [rsp+0x20]
0000710a0d1d5e45  vmovaps xmm3, [rsp+0x30]
0000710a0d1d5e4b  vmovaps xmm4, [rsp+0x40]
0000710a0d1d5e51  vmovaps xmm5, [rsp+0x50]
0000710a0d1d5e57  vmovaps xmm6, [rsp+0x60]
0000710a0d1d5e5d  vmovaps xmm7, [rsp+0x70]
0000710a0d1d5e63  vmovaps xmm8, [rsp+0x80]
0000710a0d1d5e6c  vmovaps xmm9, [rsp+0x90]
0000710a0d1d5e75  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d5e7e  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d5e87  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d5e90  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d5e99  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d5ea2  add rsp, 0xF0
0000710a0d1d5ea9  pop r11
0000710a0d1d5eab  pop r10
0000710a0d1d5ead  pop r9
0000710a0d1d5eaf  pop r8
0000710a0d1d5eb1  pop rsi
0000710a0d1d5eb2  pop rdi
0000710a0d1d5eb3  pop rdx
0000710a0d1d5eb4  pop rcx
0000710a0d1d5eb5  pop rax
0000710a0d1d5eb6  add rsp, 0x08
0000710a0d1d5eba  jmp 0x0000710A0D1D3196
0000710a0d1d5ebf  sub rsp, 0x08
0000710a0d1d5ec3  push rax
0000710a0d1d5ec4  push rcx
0000710a0d1d5ec5  push rdx
0000710a0d1d5ec6  push rdi
0000710a0d1d5ec7  push rsi
0000710a0d1d5ec8  push r8
0000710a0d1d5eca  push r9
0000710a0d1d5ecc  push r10
0000710a0d1d5ece  push r11
0000710a0d1d5ed0  sub rsp, 0xF0
0000710a0d1d5ed7  vmovaps [rsp], xmm0
0000710a0d1d5edc  vmovaps [rsp+0x10], xmm1
0000710a0d1d5ee2  vmovaps [rsp+0x20], xmm2
0000710a0d1d5ee8  vmovaps [rsp+0x30], xmm3
0000710a0d1d5eee  vmovaps [rsp+0x40], xmm4
0000710a0d1d5ef4  vmovaps [rsp+0x50], xmm5
0000710a0d1d5efa  vmovaps [rsp+0x60], xmm6
0000710a0d1d5f00  vmovaps [rsp+0x70], xmm7
0000710a0d1d5f06  vmovaps [rsp+0x80], xmm8
0000710a0d1d5f0f  vmovaps [rsp+0x90], xmm9
0000710a0d1d5f18  vmovaps [rsp+0xA0], xmm10
0000710a0d1d5f21  vmovaps [rsp+0xB0], xmm11
0000710a0d1d5f2a  vmovaps [rsp+0xC0], xmm12
0000710a0d1d5f33  vmovaps [rsp+0xD0], xmm13
0000710a0d1d5f3c  vmovaps [rsp+0xE0], xmm15
0000710a0d1d5f45  sub rsp, 0x40
0000710a0d1d5f49  lea rdi, [rsp]
0000710a0d1d5f4d  lea rsi, [rsp+0x10]
0000710a0d1d5f52  lea rdx, [rsp+0x20]
0000710a0d1d5f57  lea rcx, [rsp+0x30]
0000710a0d1d5f5c  mov r8d, 0x00
0000710a0d1d5f62  lea r9, [r15+0x3A8]
0000710a0d1d5f69  movaps [rdi], xmm14
0000710a0d1d5f6d  movaps [rsi], xmm13
0000710a0d1d5f71  movaps [rdx], xmm1
0000710a0d1d5f74  movaps [rcx], xmm15
0000710a0d1d5f78  mov rax, 0x64F334B05A50
0000710a0d1d5f82  call rax
0000710a0d1d5f84  movaps xmm14, [rsp]
0000710a0d1d5f89  add rsp, 0x40
0000710a0d1d5f8d  vmovaps xmm0, [rsp]
0000710a0d1d5f92  vmovaps xmm1, [rsp+0x10]
0000710a0d1d5f98  vmovaps xmm2, [rsp+0x20]
0000710a0d1d5f9e  vmovaps xmm3, [rsp+0x30]
0000710a0d1d5fa4  vmovaps xmm4, [rsp+0x40]
0000710a0d1d5faa  vmovaps xmm5, [rsp+0x50]
0000710a0d1d5fb0  vmovaps xmm6, [rsp+0x60]
0000710a0d1d5fb6  vmovaps xmm7, [rsp+0x70]
0000710a0d1d5fbc  vmovaps xmm8, [rsp+0x80]
0000710a0d1d5fc5  vmovaps xmm9, [rsp+0x90]
0000710a0d1d5fce  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d5fd7  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d5fe0  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d5fe9  vmovaps xmm13, [rsp+0xD0]
0000710a0d1d5ff2  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d5ffb  add rsp, 0xF0
0000710a0d1d6002  pop r11
0000710a0d1d6004  pop r10
0000710a0d1d6006  pop r9
0000710a0d1d6008  pop r8
0000710a0d1d600a  pop rsi
0000710a0d1d600b  pop rdi
0000710a0d1d600c  pop rdx
0000710a0d1d600d  pop rcx
0000710a0d1d600e  pop rax
0000710a0d1d600f  add rsp, 0x08
0000710a0d1d6013  jmp 0x0000710A0D1D31C7
0000710a0d1d6018  call 0x0000710A0D0079B0
0000710a0d1d601d  jmp 0x0000710A0D1D31DA
0000710a0d1d6022  call 0x0000710A0D00B100
0000710a0d1d6027  jmp 0x0000710A0D1D31E5
0000710a0d1d602c  call 0x0000710A0D009E90
0000710a0d1d6031  jmp 0x0000710A0D1D31F0
0000710a0d1d6036  call 0x0000710A0D00D600
0000710a0d1d603b  jmp 0x0000710A0D1D31FB
0000710a0d1d6040  int3
0000710a0d1d6041  nop [rax+rax*1], ax
0000710a0d1d604a  nop [rax+rax*1], ax
0000710a0d1d6050  mov rax, [r15+0x40]
0000710a0d1d6054  mov r14, [r15+0x58]
0000710a0d1d6058  lea r12, [rax+r14*1]
0000710a0d1d605c  vxorps xmm1, xmm1, xmm1
0000710a0d1d6060  vpbroadcastq xmm1, xmm1
0000710a0d1d6065  vxorps xmm15, xmm15, xmm15
0000710a0d1d606a  vpbroadcastq xmm15, xmm15
0000710a0d1d606f  lea rax, [r12+0x30]
0000710a0d1d6074  mov r11, [r13+rax*1]
0000710a0d1d6079  lea rax, [r12+0x38]
0000710a0d1d607e  mov r10, [r13+rax*1]
0000710a0d1d6083  movq xmm14, r11
0000710a0d1d6088  movq xmm13, r10
0000710a0d1d608d  movq xmm14, xmm14
0000710a0d1d6092  movq xmm13, xmm13
0000710a0d1d6097  vmovaps [rsp+0x10], xmm13
0000710a0d1d609d  movq xmm13, xmm13
0000710a0d1d60a2  movaps [r15+0x270], xmm13
0000710a0d1d60aa  movaps xmm13, [r15+0x160]
0000710a0d1d60b2  vmovaps [rsp+0x20], xmm13
0000710a0d1d60b8  vmovaps xmm12, [rsp+0x20]
0000710a0d1d60be  por xmm13, xmm12
0000710a0d1d60c3  lea rax, [r12+0x20]
0000710a0d1d60c8  mov r11, [r13+rax*1]
0000710a0d1d60cd  lea rax, [r12+0x28]
0000710a0d1d60d2  mov r10, [r13+rax*1]
0000710a0d1d60d7  movq xmm12, r11
0000710a0d1d60dc  movq xmm11, r10
0000710a0d1d60e1  movq xmm12, xmm12
0000710a0d1d60e6  movq xmm11, xmm11
0000710a0d1d60eb  movaps xmm10, [r15+0x2D0]
0000710a0d1d60f3  vmovaps [rsp+0x20], xmm10
0000710a0d1d60f9  vmovaps xmm9, [rsp+0x20]
0000710a0d1d60ff  por xmm10, xmm9
0000710a0d1d6104  movaps xmm9, [r15+0x300]
0000710a0d1d610c  vmovaps [rsp+0x20], xmm9
0000710a0d1d6112  vmovaps xmm8, [rsp+0x20]
0000710a0d1d6118  por xmm9, xmm8
0000710a0d1d611d  movaps xmm8, [r15+0x2B0]
0000710a0d1d6125  vmovaps [rsp+0x20], xmm8
0000710a0d1d612b  vmovaps xmm7, [rsp+0x20]
0000710a0d1d6131  por xmm8, xmm7
0000710a0d1d6136  movaps xmm7, [r15+0x180]
0000710a0d1d613e  vmovaps [rsp+0x20], xmm7
0000710a0d1d6144  vmovaps xmm6, [rsp+0x20]
0000710a0d1d614a  por xmm7, xmm6
0000710a0d1d614e  lea rax, [r12+0x10]
0000710a0d1d6153  mov r11, [r13+rax*1]
0000710a0d1d6158  lea rax, [r12+0x18]
0000710a0d1d615d  mov r10, [r13+rax*1]
0000710a0d1d6162  movq xmm6, r11
0000710a0d1d6167  movq xmm5, r10
0000710a0d1d616c  movq xmm6, xmm6
0000710a0d1d6170  movq xmm5, xmm5
0000710a0d1d6174  movaps xmm4, [r15+0x200]
0000710a0d1d617c  vmovaps [rsp+0x20], xmm4
0000710a0d1d6182  vmovaps xmm3, [rsp+0x20]
0000710a0d1d6188  por xmm4, xmm3
0000710a0d1d618c  movaps xmm3, [r15+0x1F0]
0000710a0d1d6194  vmovaps [rsp+0x20], xmm3
0000710a0d1d619a  vmovaps xmm2, [rsp+0x20]
0000710a0d1d61a0  por xmm3, xmm2
0000710a0d1d61a4  movaps xmm2, [r15+0x2E0]
0000710a0d1d61ac  vmovaps [rsp+0x20], xmm2
0000710a0d1d61b2  vmovaps [rsp+0x30], xmm1
0000710a0d1d61b8  vmovaps xmm1, [rsp+0x20]
0000710a0d1d61be  por xmm2, xmm1
0000710a0d1d61c2  movaps xmm1, [r15+0x2A0]
0000710a0d1d61ca  vmovaps [rsp+0x20], xmm1
0000710a0d1d61d0  vmovaps [rsp+0x40], xmm15
0000710a0d1d61d6  vmovaps xmm15, [rsp+0x20]
0000710a0d1d61dc  por xmm1, xmm15
0000710a0d1d61e1  movaps xmm15, [r15+0x280]
0000710a0d1d61e9  vmovaps [rsp+0x20], xmm15
0000710a0d1d61ef  vmovaps [rsp+0x50], xmm1
0000710a0d1d61f5  vmovaps xmm1, [rsp+0x20]
0000710a0d1d61fb  por xmm15, xmm1
0000710a0d1d6200  movaps xmm1, [r15+0x1C0]
0000710a0d1d6208  vmovaps [rsp+0x20], xmm1
0000710a0d1d620e  vmovaps [rsp+0x60], xmm15
0000710a0d1d6214  vmovaps xmm15, [rsp+0x20]
0000710a0d1d621a  por xmm1, xmm15
0000710a0d1d621f  movaps xmm15, [r15+0x210]
0000710a0d1d6227  vmovaps [rsp+0x20], xmm15
0000710a0d1d622d  vmovaps [rsp+0x70], xmm1
0000710a0d1d6233  vmovaps xmm1, [rsp+0x20]
0000710a0d1d6239  por xmm15, xmm1
0000710a0d1d623e  mov rax, [r13+r12*1]
0000710a0d1d6243  vmovq xmm1, rax
0000710a0d1d6248  vpbroadcastq xmm1, xmm1
0000710a0d1d624d  vmovaps [rsp+0x20], xmm1
0000710a0d1d6253  vxorps xmm1, xmm1, xmm1
0000710a0d1d6257  vpbroadcastq xmm1, xmm1
0000710a0d1d625c  mov rax, [r15+0xF8]
0000710a0d1d6263  vmovaps [rsp+0x80], xmm1
0000710a0d1d626c  movups xmm1, [r13+rax*1]
0000710a0d1d6272  vmovaps [rsp+0x90], xmm1
0000710a0d1d627b  vxorps xmm1, xmm1, xmm1
0000710a0d1d627f  vpbroadcastq xmm1, xmm1
0000710a0d1d6284  lea r11, [r12+0x08]
0000710a0d1d6289  mov r12, [r13+r11*1]
0000710a0d1d628e  vmovaps [rsp+0xA0], xmm1
0000710a0d1d6297  movq xmm1, r12
0000710a0d1d629c  movaps [r15+0x240], xmm1
0000710a0d1d62a4  mov r12, [r15+0x50]
0000710a0d1d62a8  lea r11, [r12+r14*1]
0000710a0d1d62ac  mov [r15+0x60], r11
0000710a0d1d62b0  lea r12, [r14+0x40]
0000710a0d1d62b4  mov [r15+0x58], r12
0000710a0d1d62b8  vmovaps xmm1, [rsp+0x30]
0000710a0d1d62be  vmovaps [rsp+0x30], xmm15
0000710a0d1d62c4  vmovaps xmm15, [rsp+0x90]
0000710a0d1d62cd  vmovaps [rsp+0x90], xmm14
0000710a0d1d62d6  vmovaps xmm14, [rsp+0x20]
0000710a0d1d62dc  vmovaps [rsp+0x20], xmm13
0000710a0d1d62e2  vmovaps [rsp+0xB0], xmm12
0000710a0d1d62eb  movaps xmm13, xmm1
0000710a0d1d62ef  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d62fa  vptest xmm12, xmm12
0000710a0d1d62ff  jnz 0x0000710A0D1D6D9C
0000710a0d1d6305  movaps xmm1, [r15+0x250]
0000710a0d1d630d  vmovaps xmm15, [rsp+0x40]
0000710a0d1d6313  vmovaps [rsp+0x40], xmm13
0000710a0d1d6319  movaps xmm12, xmm15
0000710a0d1d631d  vfmadd231pd xmm12, xmm1, xmm14
0000710a0d1d6322  vcmppd xmm13, xmm12, xmm12, 0x03
0000710a0d1d6328  vptest xmm13, xmm13
0000710a0d1d632d  jnz 0x0000710A0D1D6EF5
0000710a0d1d6333  movaps xmm15, [r15+0x1E0]
0000710a0d1d633b  vmovaps [rsp+0xC0], xmm15
0000710a0d1d6344  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d634d  por xmm15, xmm13
0000710a0d1d6352  movaps xmm13, [r15+0x1D0]
0000710a0d1d635a  vmovaps [rsp+0xC0], xmm13
0000710a0d1d6363  vmovaps [rsp+0xD0], xmm1
0000710a0d1d636c  vmovaps xmm1, [rsp+0xC0]
0000710a0d1d6375  por xmm13, xmm1
0000710a0d1d637a  movaps xmm1, [r15+0x2C0]
0000710a0d1d6382  vmovaps [rsp+0xC0], xmm1
0000710a0d1d638b  vmovaps [rsp+0xE0], xmm15
0000710a0d1d6394  vmovaps xmm15, [rsp+0xC0]
0000710a0d1d639d  por xmm1, xmm15
0000710a0d1d63a2  movaps xmm15, [r15+0x290]
0000710a0d1d63aa  vmovaps [rsp+0xC0], xmm15
0000710a0d1d63b3  vmovaps [rsp+0xF0], xmm1
0000710a0d1d63bc  vmovaps xmm1, [rsp+0xC0]
0000710a0d1d63c5  por xmm15, xmm1
0000710a0d1d63ca  movaps xmm1, [r15+0x260]
0000710a0d1d63d2  vmovaps [rsp+0xC0], xmm1
0000710a0d1d63db  vmovaps [rsp+0x100], xmm15
0000710a0d1d63e4  vmovaps xmm15, [rsp+0xC0]
0000710a0d1d63ed  por xmm1, xmm15
0000710a0d1d63f2  vmovaps xmm15, [rsp+0xD0]
0000710a0d1d63fb  vmovaps [rsp+0xC0], xmm1
0000710a0d1d6404  vmovaps xmm1, [rsp+0xD0]
0000710a0d1d640d  por xmm15, xmm1
0000710a0d1d6412  lea r14, [rax+0xC0]
0000710a0d1d6419  movups xmm1, [r13+r14*1]
0000710a0d1d641f  mov [rsp+0xD0], rax
0000710a0d1d6427  xor eax, eax
0000710a0d1d6429  mov r14d, 0x200
0000710a0d1d642f  cmp r12, r14
0000710a0d1d6432  cmc
0000710a0d1d6433  lahf
0000710a0d1d6434  seto al
0000710a0d1d6437  mov [r15+0x108], eax
0000710a0d1d643e  vmovaps [rsp+0x110], xmm1
0000710a0d1d6447  vmovaps xmm1, [rsp+0x80]
0000710a0d1d6450  vmovaps [rsp+0x80], xmm15
0000710a0d1d6459  vmovaps xmm15, [rsp+0x110]
0000710a0d1d6462  vmovaps [rsp+0x110], xmm13
0000710a0d1d646b  vmovaps [rsp+0x120], xmm12
0000710a0d1d6474  movaps xmm13, xmm1
0000710a0d1d6478  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d647d  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d6483  vptest xmm12, xmm12
0000710a0d1d6488  jnz 0x0000710A0D1D7058
0000710a0d1d648e  mov rax, [rsp+0xD0]
0000710a0d1d6496  lea r14, [rax+0xB0]
0000710a0d1d649d  movups xmm1, [r13+r14*1]
0000710a0d1d64a3  vmovaps xmm15, [rsp+0xA0]
0000710a0d1d64ac  vmovaps [rsp+0xA0], xmm13
0000710a0d1d64b5  movaps xmm12, xmm15
0000710a0d1d64b9  vfmadd231pd xmm12, xmm1, xmm14
0000710a0d1d64be  vcmppd xmm13, xmm12, xmm12, 0x03
0000710a0d1d64c4  vptest xmm13, xmm13
0000710a0d1d64c9  jnz 0x0000710A0D1D71BB
0000710a0d1d64cf  vmovaps xmm1, [rsp+0x30]
0000710a0d1d64d5  vmovaps xmm15, [rsp+0x30]
0000710a0d1d64db  por xmm1, xmm15
0000710a0d1d64e0  movaps [r15+0x210], xmm1
0000710a0d1d64e8  vmovaps xmm15, [rsp+0x70]
0000710a0d1d64ee  vmovaps xmm14, [rsp+0x70]
0000710a0d1d64f4  por xmm15, xmm14
0000710a0d1d64f9  movaps [r15+0x1C0], xmm15
0000710a0d1d6501  vmovaps xmm14, [rsp+0x60]
0000710a0d1d6507  vmovaps xmm13, [rsp+0x60]
0000710a0d1d650d  por xmm14, xmm13
0000710a0d1d6512  movaps [r15+0x280], xmm14
0000710a0d1d651a  vmovaps xmm13, [rsp+0x50]
0000710a0d1d6520  vmovaps [rsp+0x30], xmm1
0000710a0d1d6526  vmovaps xmm1, [rsp+0x50]
0000710a0d1d652c  por xmm13, xmm1
0000710a0d1d6531  movaps [r15+0x2A0], xmm13
0000710a0d1d6539  vmovaps [rsp+0x50], xmm2
0000710a0d1d653f  vmovaps xmm1, [rsp+0x50]
0000710a0d1d6545  por xmm2, xmm1
0000710a0d1d6549  movaps [r15+0x2E0], xmm2
0000710a0d1d6551  vmovaps [rsp+0x50], xmm3
0000710a0d1d6557  vmovaps xmm1, [rsp+0x50]
0000710a0d1d655d  por xmm3, xmm1
0000710a0d1d6561  movaps [r15+0x1F0], xmm3
0000710a0d1d6569  vmovaps xmm1, [rsp+0x80]
0000710a0d1d6572  vmovaps [rsp+0x50], xmm15
0000710a0d1d6578  vmovaps xmm15, [rsp+0x80]
0000710a0d1d6581  por xmm1, xmm15
0000710a0d1d6586  movaps [r15+0x250], xmm1
0000710a0d1d658e  vmovaps xmm1, [rsp+0xC0]
0000710a0d1d6597  vmovaps xmm15, [rsp+0xC0]
0000710a0d1d65a0  por xmm1, xmm15
0000710a0d1d65a5  movaps [r15+0x260], xmm1
0000710a0d1d65ad  vmovaps xmm15, [rsp+0x100]
0000710a0d1d65b6  vmovaps [rsp+0x60], xmm1
0000710a0d1d65bc  vmovaps xmm1, [rsp+0x100]
0000710a0d1d65c5  por xmm15, xmm1
0000710a0d1d65ca  movaps [r15+0x290], xmm15
0000710a0d1d65d2  vmovaps xmm1, [rsp+0xF0]
0000710a0d1d65db  vmovaps [rsp+0x70], xmm15
0000710a0d1d65e1  vmovaps xmm15, [rsp+0xF0]
0000710a0d1d65ea  por xmm1, xmm15
0000710a0d1d65ef  movaps [r15+0x2C0], xmm1
0000710a0d1d65f7  movq xmm15, qword ptr [r15+0x240]
0000710a0d1d6600  vmovaps [rsp+0x80], xmm15
0000710a0d1d6609  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d660f  vmovaps [rsp+0xC0], xmm1
0000710a0d1d6618  vmovaps xmm1, [rsp+0x40]
0000710a0d1d661e  vmovaps [rsp+0x40], xmm15
0000710a0d1d6624  vmovaps xmm15, [rsp+0x30]
0000710a0d1d662a  vmovaps [rsp+0x30], xmm14
0000710a0d1d6630  vmovaps xmm14, [rsp+0x40]
0000710a0d1d6636  vmovaps [rsp+0x40], xmm13
0000710a0d1d663c  vmovaps [rsp+0xD0], xmm12
0000710a0d1d6645  movaps xmm13, xmm1
0000710a0d1d6649  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d664e  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d6654  vptest xmm12, xmm12
0000710a0d1d6659  jnz 0x0000710A0D1D7314
0000710a0d1d665f  vmovaps xmm1, [rsp+0x80]
0000710a0d1d6668  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d666e  vmovaps xmm15, [rsp+0xA0]
0000710a0d1d6677  movaps xmm14, xmm15
0000710a0d1d667b  vfmadd231pd xmm14, xmm2, xmm1
0000710a0d1d6680  vcmppd xmm12, xmm14, xmm14, 0x03
0000710a0d1d6686  vptest xmm12, xmm12
0000710a0d1d668b  jnz 0x0000710A0D1D746D
0000710a0d1d6691  vmovaps xmm1, [rsp+0x80]
0000710a0d1d669a  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d66a0  vmovaps xmm15, [rsp+0x120]
0000710a0d1d66a9  vmovaps xmm12, [rsp+0x50]
0000710a0d1d66af  vmovaps [rsp+0x50], xmm14
0000710a0d1d66b5  movaps xmm2, xmm15
0000710a0d1d66b9  vfmadd231pd xmm2, xmm12, xmm1
0000710a0d1d66be  vcmppd xmm14, xmm2, xmm2, 0x03
0000710a0d1d66c3  vptest xmm14, xmm14
0000710a0d1d66c8  jnz 0x0000710A0D1D75C5
0000710a0d1d66ce  vmovaps xmm1, [rsp+0x110]
0000710a0d1d66d7  vmovaps xmm15, [rsp+0x110]
0000710a0d1d66e0  por xmm1, xmm15
0000710a0d1d66e5  movaps [r15+0x1D0], xmm1
0000710a0d1d66ed  vmovaps xmm15, [rsp+0x80]
0000710a0d1d66f6  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d66fc  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d6705  vmovaps [rsp+0x80], xmm1
0000710a0d1d670e  movaps xmm12, xmm14
0000710a0d1d6712  vfmadd231pd xmm12, xmm3, xmm15
0000710a0d1d6717  vcmppd xmm1, xmm12, xmm12, 0x03
0000710a0d1d671d  vptest xmm1, xmm1
0000710a0d1d6722  jnz 0x0000710A0D1D771C
0000710a0d1d6728  vmovaps [rsp+0xA0], xmm4
0000710a0d1d6731  vmovaps xmm1, [rsp+0xA0]
0000710a0d1d673a  por xmm4, xmm1
0000710a0d1d673e  movaps [r15+0x200], xmm4
0000710a0d1d6746  vmovaps xmm1, [rsp+0xE0]
0000710a0d1d674f  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d6758  por xmm1, xmm15
0000710a0d1d675d  movaps [r15+0x1E0], xmm1
0000710a0d1d6765  vmovaps [rsp+0xA0], xmm8
0000710a0d1d676e  vmovaps xmm1, [rsp+0xA0]
0000710a0d1d6777  por xmm8, xmm1
0000710a0d1d677c  movaps [r15+0x2B0], xmm8
0000710a0d1d6784  vmovaps [rsp+0xA0], xmm9
0000710a0d1d678d  vmovaps xmm1, [rsp+0xA0]
0000710a0d1d6796  por xmm9, xmm1
0000710a0d1d679b  movaps [r15+0x300], xmm9
0000710a0d1d67a3  vmovaps [rsp+0xA0], xmm6
0000710a0d1d67ac  vpermilpd xmm6, xmm6, 0x00
0000710a0d1d67b2  vmovaps xmm14, [rsp+0x60]
0000710a0d1d67b8  movaps xmm9, xmm13
0000710a0d1d67bc  vfmadd231pd xmm9, xmm14, xmm6
0000710a0d1d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
0000710a0d1d67c7  vptest xmm3, xmm3
0000710a0d1d67cc  jnz 0x0000710A0D1D7875
0000710a0d1d67d2  vmovaps xmm14, [rsp+0xA0]
0000710a0d1d67db  vpermilpd xmm14, xmm14, 0x00
0000710a0d1d67e1  vmovaps xmm13, [rsp+0x50]
0000710a0d1d67e7  vmovaps xmm6, [rsp+0xC0]
0000710a0d1d67f0  vmovaps [rsp+0x50], xmm1
0000710a0d1d67f6  movaps xmm3, xmm13
0000710a0d1d67fa  vfmadd231pd xmm3, xmm6, xmm14
0000710a0d1d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
0000710a0d1d6804  vptest xmm1, xmm1
0000710a0d1d6809  jnz 0x0000710A0D1D79CE
0000710a0d1d680f  vmovaps xmm1, [rsp+0xA0]
0000710a0d1d6818  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d681e  vmovaps xmm14, [rsp+0x30]
0000710a0d1d6824  movaps xmm6, xmm2
0000710a0d1d6827  vfmadd231pd xmm6, xmm14, xmm1
0000710a0d1d682c  vcmppd xmm13, xmm6, xmm6, 0x03
0000710a0d1d6831  vptest xmm13, xmm13
0000710a0d1d6836  jnz 0x0000710A0D1D7B25
0000710a0d1d683c  vmovaps xmm1, [rsp+0xA0]
0000710a0d1d6845  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d684b  vmovaps xmm14, [rsp+0x80]
0000710a0d1d6854  movaps xmm13, xmm12
0000710a0d1d6858  vfmadd231pd xmm13, xmm14, xmm1
0000710a0d1d685d  vcmppd xmm2, xmm13, xmm13, 0x03
0000710a0d1d6863  vptest xmm2, xmm2
0000710a0d1d6868  jnz 0x0000710A0D1D7C7B
0000710a0d1d686e  vmovaps [rsp+0x30], xmm7
0000710a0d1d6874  vmovaps xmm1, [rsp+0x30]
0000710a0d1d687a  por xmm7, xmm1
0000710a0d1d687e  movaps [r15+0x180], xmm7
0000710a0d1d6886  vmovaps [rsp+0x30], xmm10
0000710a0d1d688c  vmovaps xmm1, [rsp+0x30]
0000710a0d1d6892  por xmm10, xmm1
0000710a0d1d6897  movaps [r15+0x2D0], xmm10
0000710a0d1d689f  vmovaps [rsp+0x30], xmm5
0000710a0d1d68a5  vpermilpd xmm5, xmm5, 0x00
0000710a0d1d68ab  vmovaps xmm14, [rsp+0x50]
0000710a0d1d68b1  movaps xmm12, xmm3
0000710a0d1d68b5  vfmadd231pd xmm12, xmm14, xmm5
0000710a0d1d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
0000710a0d1d68c0  vptest xmm10, xmm10
0000710a0d1d68c5  jnz 0x0000710A0D1D7DD4
0000710a0d1d68cb  vmovaps xmm14, [rsp+0x30]
0000710a0d1d68d1  vpermilpd xmm14, xmm14, 0x00
0000710a0d1d68d7  movaps xmm10, xmm9
0000710a0d1d68db  vfmadd231pd xmm10, xmm7, xmm14
0000710a0d1d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
0000710a0d1d68e6  vptest xmm5, xmm5
0000710a0d1d68eb  jnz 0x0000710A0D1D7F2C
0000710a0d1d68f1  lea r14, [rax+0x80]
0000710a0d1d68f8  movups xmm14, [r13+r14*1]
0000710a0d1d68fe  movaps [r15+0x2F0], xmm14
0000710a0d1d6906  vmovaps xmm9, [rsp+0x30]
0000710a0d1d690c  vpermilpd xmm9, xmm9, 0x00
0000710a0d1d6912  vmovaps xmm7, [rsp+0x70]
0000710a0d1d6918  movaps xmm5, xmm6
0000710a0d1d691b  vfmadd231pd xmm5, xmm7, xmm9
0000710a0d1d6920  vcmppd xmm3, xmm5, xmm5, 0x03
0000710a0d1d6925  vptest xmm3, xmm3
0000710a0d1d692a  jnz 0x0000710A0D1D808F
0000710a0d1d6930  vmovaps xmm9, [rsp+0x30]
0000710a0d1d6936  vpermilpd xmm9, xmm9, 0x00
0000710a0d1d693c  movaps xmm7, xmm13
0000710a0d1d6940  vfmadd231pd xmm7, xmm1, xmm9
0000710a0d1d6945  vcmppd xmm6, xmm7, xmm7, 0x03
0000710a0d1d694a  vptest xmm6, xmm6
0000710a0d1d694f  jnz 0x0000710A0D1D81E5
0000710a0d1d6955  vmovaps xmm1, [rsp+0x20]
0000710a0d1d695b  vmovaps xmm13, [rsp+0x20]
0000710a0d1d6961  por xmm1, xmm13
0000710a0d1d6966  movaps [r15+0x160], xmm1
0000710a0d1d696e  lea r14, [rax+0x40]
0000710a0d1d6972  movups xmm13, [r13+r14*1]
0000710a0d1d6978  lea r14, [rax+0x50]
0000710a0d1d697c  movups xmm9, [r13+r14*1]
0000710a0d1d6982  movaps [r15+0x1B0], xmm13
0000710a0d1d698a  movaps [r15+0x1A0], xmm9
0000710a0d1d6992  movaps xmm6, [r15+0x190]
0000710a0d1d699a  vmovaps xmm3, [rsp+0xB0]
0000710a0d1d69a3  vpermilpd xmm3, xmm3, 0x00
0000710a0d1d69a9  vmovaps [rsp+0x20], xmm1
0000710a0d1d69af  movaps xmm2, xmm12
0000710a0d1d69b3  vfmadd231pd xmm2, xmm6, xmm3
0000710a0d1d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
0000710a0d1d69bd  vptest xmm1, xmm1
0000710a0d1d69c2  jnz 0x0000710A0D1D8350
0000710a0d1d69c8  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d69d1  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d69d7  vmovaps xmm12, [rsp+0x20]
0000710a0d1d69dd  movaps xmm6, xmm10
0000710a0d1d69e1  vfmadd231pd xmm6, xmm12, xmm1
0000710a0d1d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
0000710a0d1d69eb  vptest xmm3, xmm3
0000710a0d1d69f0  jnz 0x0000710A0D1D84A6
0000710a0d1d69f6  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d69ff  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d6a05  vmovaps xmm12, [rsp+0x40]
0000710a0d1d6a0b  movaps xmm10, xmm5
0000710a0d1d6a0f  vfmadd231pd xmm10, xmm12, xmm1
0000710a0d1d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
0000710a0d1d6a1a  vptest xmm3, xmm3
0000710a0d1d6a1f  jnz 0x0000710A0D1D85FD
0000710a0d1d6a25  vmovaps xmm1, [rsp+0xB0]
0000710a0d1d6a2e  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d6a34  movaps xmm12, xmm7
0000710a0d1d6a38  vfmadd231pd xmm12, xmm15, xmm1
0000710a0d1d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
0000710a0d1d6a43  vptest xmm5, xmm5
0000710a0d1d6a48  jnz 0x0000710A0D1D8755
0000710a0d1d6a4e  lea r14, [rax+0x60]
0000710a0d1d6a52  movups xmm1, [r13+r14*1]
0000710a0d1d6a58  lea r14, [rax+0x70]
0000710a0d1d6a5c  movups xmm15, [r13+r14*1]
0000710a0d1d6a62  movaps [r15+0x150], xmm1
0000710a0d1d6a6a  movaps [r15+0x120], xmm15
0000710a0d1d6a72  vmovaps [rsp+0x20], xmm11
0000710a0d1d6a78  vpermilpd xmm11, xmm11, 0x00
0000710a0d1d6a7e  movaps xmm7, xmm2
0000710a0d1d6a81  vfmadd231pd xmm7, xmm9, xmm11
0000710a0d1d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
0000710a0d1d6a8b  vptest xmm5, xmm5
0000710a0d1d6a90  jnz 0x0000710A0D1D88C1
0000710a0d1d6a96  vmovaps xmm11, [rsp+0x20]
0000710a0d1d6a9c  vpermilpd xmm11, xmm11, 0x00
0000710a0d1d6aa2  movaps xmm9, xmm6
0000710a0d1d6aa6  vfmadd231pd xmm9, xmm1, xmm11
0000710a0d1d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
0000710a0d1d6ab1  vptest xmm5, xmm5
0000710a0d1d6ab6  jnz 0x0000710A0D1D8A18
0000710a0d1d6abc  vmovaps xmm1, [rsp+0x20]
0000710a0d1d6ac2  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d6ac8  movaps xmm11, xmm10
0000710a0d1d6acc  vfmadd231pd xmm11, xmm8, xmm1
0000710a0d1d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
0000710a0d1d6ad7  vptest xmm6, xmm6
0000710a0d1d6adc  jnz 0x0000710A0D1D8B70
0000710a0d1d6ae2  vmovaps xmm1, [rsp+0x20]
0000710a0d1d6ae8  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d6aee  movaps xmm10, xmm12
0000710a0d1d6af2  vfmadd231pd xmm10, xmm13, xmm1
0000710a0d1d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
0000710a0d1d6afd  vptest xmm8, xmm8
0000710a0d1d6b02  jnz 0x0000710A0D1D8CC9
0000710a0d1d6b08  lea r14, [rax+0x20]
0000710a0d1d6b0c  movups xmm1, [r13+r14*1]
0000710a0d1d6b12  lea r14, [rax+0x30]
0000710a0d1d6b16  movups xmm13, [r13+r14*1]
0000710a0d1d6b1c  vmovaps xmm12, [rsp+0x90]
0000710a0d1d6b25  vpermilpd xmm12, xmm12, 0x00
0000710a0d1d6b2b  movaps xmm8, xmm7
0000710a0d1d6b2f  vfmadd231pd xmm8, xmm4, xmm12
0000710a0d1d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
0000710a0d1d6b3a  vptest xmm6, xmm6
0000710a0d1d6b3f  jnz 0x0000710A0D1D8E36
0000710a0d1d6b45  vmovaps xmm12, [rsp+0x90]
0000710a0d1d6b4e  vpermilpd xmm12, xmm12, 0x00
0000710a0d1d6b54  movaps xmm7, xmm9
0000710a0d1d6b58  vfmadd231pd xmm7, xmm14, xmm12
0000710a0d1d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
0000710a0d1d6b62  vptest xmm6, xmm6
0000710a0d1d6b67  jnz 0x0000710A0D1D8F8E
0000710a0d1d6b6d  vmovaps xmm14, [rsp+0x90]
0000710a0d1d6b76  vpermilpd xmm14, xmm14, 0x00
0000710a0d1d6b7c  movaps xmm12, xmm11
0000710a0d1d6b80  vfmadd231pd xmm12, xmm15, xmm14
0000710a0d1d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
0000710a0d1d6b8b  vptest xmm9, xmm9
0000710a0d1d6b90  jnz 0x0000710A0D1D90E6
0000710a0d1d6b96  vmovaps xmm15, [rsp+0x90]
0000710a0d1d6b9f  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d6ba5  movaps xmm11, xmm10
0000710a0d1d6ba9  vfmadd231pd xmm11, xmm13, xmm15
0000710a0d1d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
0000710a0d1d6bb4  vptest xmm14, xmm14
0000710a0d1d6bb9  jnz 0x0000710A0D1D9240
0000710a0d1d6bbf  lea r14, [rax+0x90]
0000710a0d1d6bc6  movups xmm15, [r13+r14*1]
0000710a0d1d6bcc  lea r14, [rax+0xA0]
0000710a0d1d6bd3  movups xmm14, [r13+r14*1]
0000710a0d1d6bd9  movaps [r15+0x140], xmm15
0000710a0d1d6be1  movaps [r15+0x130], xmm14
0000710a0d1d6be9  vmovaps xmm13, [rsp+0x10]
0000710a0d1d6bef  vpermilpd xmm13, xmm13, 0x00
0000710a0d1d6bf5  movaps xmm10, xmm8
0000710a0d1d6bf9  vfmadd231pd xmm10, xmm1, xmm13
0000710a0d1d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
0000710a0d1d6c04  vptest xmm9, xmm9
0000710a0d1d6c09  jnz 0x0000710A0D1D93AE
0000710a0d1d6c0f  movaps [r15+0x220], xmm10
0000710a0d1d6c17  lea r14, [rax+0x10]
0000710a0d1d6c1b  movups xmm1, [r13+r14*1]
0000710a0d1d6c21  movaps [r15+0x240], xmm1
0000710a0d1d6c29  vmovaps xmm13, [rsp+0x10]
0000710a0d1d6c2f  vpermilpd xmm13, xmm13, 0x00
0000710a0d1d6c35  movaps xmm9, xmm7
0000710a0d1d6c39  vfmadd231pd xmm9, xmm14, xmm13
0000710a0d1d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
0000710a0d1d6c44  vptest xmm8, xmm8
0000710a0d1d6c49  jnz 0x0000710A0D1D9511
0000710a0d1d6c4f  movaps [r15+0x110], xmm9
0000710a0d1d6c57  vmovaps xmm14, [rsp+0x10]
0000710a0d1d6c5d  vpermilpd xmm14, xmm14, 0x00
0000710a0d1d6c63  movaps xmm13, xmm12
0000710a0d1d6c67  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
0000710a0d1d6c72  vptest xmm8, xmm8
0000710a0d1d6c77  jnz 0x0000710A0D1D966A
0000710a0d1d6c7d  movaps [r15+0x170], xmm13
0000710a0d1d6c85  vmovaps xmm15, [rsp+0x10]
0000710a0d1d6c8b  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d6c91  movaps xmm14, xmm11
0000710a0d1d6c95  vfmadd231pd xmm14, xmm1, xmm15
0000710a0d1d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
0000710a0d1d6ca0  vptest xmm12, xmm12
0000710a0d1d6ca5  jnz 0x0000710A0D1D97C4
0000710a0d1d6cab  movaps [r15+0x230], xmm14
0000710a0d1d6cb3  movups [r13+r11*1], xmm9
0000710a0d1d6cb9  lea rax, [r11+0x10]
0000710a0d1d6cbd  movups [r13+rax*1], xmm13
0000710a0d1d6cc3  lea rax, [r11+0x20]
0000710a0d1d6cc7  movups [r13+rax*1], xmm10
0000710a0d1d6ccd  lea rax, [r11+0x30]
0000710a0d1d6cd1  movups [r13+rax*1], xmm14
0000710a0d1d6cd7  mov eax, [r15+0x108]
0000710a0d1d6cde  sahf
0000710a0d1d6cdf  jnz 0x0000710A0D1D6D11
0000710a0d1d6ce1  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d6ce9  jz 0x0000710A0D1D9950
0000710a0d1d6cef  nop [rax+rax*1], ax
0000710a0d1d6cf8  nop [rax+rax*1], eax
0000710a0d1d6d00  mov eax, 0x410664
0000710a0d1d6d05  mov [r15+0x100], rax
0000710a0d1d6d0c  jmp 0x0000710A0CFFE110
0000710a0d1d6d11  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d6d19  jz 0x0000710A0D1D6050
0000710a0d1d6d1f  nop [rax+rax*1], ax
0000710a0d1d6d28  nop [rax+rax*1], eax
0000710a0d1d6d30  mov eax, 0x4104F0
0000710a0d1d6d35  mov [r15+0x100], rax
0000710a0d1d6d3c  jmp 0x0000710A0CFFE110
0000710a0d1d6d41  int3
0000710a0d1d6d42  call 0x0000710A0D00A4B0
0000710a0d1d6d47  jmp 0x0000710A0D1D6079
0000710a0d1d6d4c  call 0x0000710A0D009240
0000710a0d1d6d51  jmp 0x0000710A0D1D6083
0000710a0d1d6d56  call 0x0000710A0D00A4B0
0000710a0d1d6d5b  jmp 0x0000710A0D1D60CD
0000710a0d1d6d60  call 0x0000710A0D009240
0000710a0d1d6d65  jmp 0x0000710A0D1D60D7
0000710a0d1d6d6a  call 0x0000710A0D00A4B0
0000710a0d1d6d6f  jmp 0x0000710A0D1D6158
0000710a0d1d6d74  call 0x0000710A0D009240
0000710a0d1d6d79  jmp 0x0000710A0D1D6162
0000710a0d1d6d7e  call 0x0000710A0D0B47C0
0000710a0d1d6d83  jmp 0x0000710A0D1D6243
0000710a0d1d6d88  call 0x0000710A0CFFF430
0000710a0d1d6d8d  jmp 0x0000710A0D1D6272
0000710a0d1d6d92  call 0x0000710A0D0B0CE0
0000710a0d1d6d97  jmp 0x0000710A0D1D628E
0000710a0d1d6d9c  sub rsp, 0x08
0000710a0d1d6da0  push rax
0000710a0d1d6da1  push rcx
0000710a0d1d6da2  push rdx
0000710a0d1d6da3  push rdi
0000710a0d1d6da4  push rsi
0000710a0d1d6da5  push r8
0000710a0d1d6da7  push r9
0000710a0d1d6da9  push r10
0000710a0d1d6dab  push r11
0000710a0d1d6dad  sub rsp, 0xF0
0000710a0d1d6db4  vmovaps [rsp], xmm0
0000710a0d1d6db9  vmovaps [rsp+0x10], xmm1
0000710a0d1d6dbf  vmovaps [rsp+0x20], xmm2
0000710a0d1d6dc5  vmovaps [rsp+0x30], xmm3
0000710a0d1d6dcb  vmovaps [rsp+0x40], xmm4
0000710a0d1d6dd1  vmovaps [rsp+0x50], xmm5
0000710a0d1d6dd7  vmovaps [rsp+0x60], xmm6
0000710a0d1d6ddd  vmovaps [rsp+0x70], xmm7
0000710a0d1d6de3  vmovaps [rsp+0x80], xmm8
0000710a0d1d6dec  vmovaps [rsp+0x90], xmm9
0000710a0d1d6df5  vmovaps [rsp+0xA0], xmm10
0000710a0d1d6dfe  vmovaps [rsp+0xB0], xmm11
0000710a0d1d6e07  vmovaps [rsp+0xC0], xmm12
0000710a0d1d6e10  vmovaps [rsp+0xD0], xmm14
0000710a0d1d6e19  vmovaps [rsp+0xE0], xmm15
0000710a0d1d6e22  sub rsp, 0x40
0000710a0d1d6e26  lea rdi, [rsp]
0000710a0d1d6e2a  lea rsi, [rsp+0x10]
0000710a0d1d6e2f  lea rdx, [rsp+0x20]
0000710a0d1d6e34  lea rcx, [rsp+0x30]
0000710a0d1d6e39  mov r8d, 0x00
0000710a0d1d6e3f  lea r9, [r15+0x3A8]
0000710a0d1d6e46  movaps [rdi], xmm13
0000710a0d1d6e4a  movaps [rsi], xmm1
0000710a0d1d6e4d  movaps [rdx], xmm15
0000710a0d1d6e51  movaps [rcx], xmm14
0000710a0d1d6e55  mov rax, 0x64F334B05A50
0000710a0d1d6e5f  call rax
0000710a0d1d6e61  movaps xmm13, [rsp]
0000710a0d1d6e66  add rsp, 0x40
0000710a0d1d6e6a  vmovaps xmm0, [rsp]
0000710a0d1d6e6f  vmovaps xmm1, [rsp+0x10]
0000710a0d1d6e75  vmovaps xmm2, [rsp+0x20]
0000710a0d1d6e7b  vmovaps xmm3, [rsp+0x30]
0000710a0d1d6e81  vmovaps xmm4, [rsp+0x40]
0000710a0d1d6e87  vmovaps xmm5, [rsp+0x50]
0000710a0d1d6e8d  vmovaps xmm6, [rsp+0x60]
0000710a0d1d6e93  vmovaps xmm7, [rsp+0x70]
0000710a0d1d6e99  vmovaps xmm8, [rsp+0x80]
0000710a0d1d6ea2  vmovaps xmm9, [rsp+0x90]
0000710a0d1d6eab  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d6eb4  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d6ebd  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d6ec6  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d6ecf  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d6ed8  add rsp, 0xF0
0000710a0d1d6edf  pop r11
0000710a0d1d6ee1  pop r10
0000710a0d1d6ee3  pop r9
0000710a0d1d6ee5  pop r8
0000710a0d1d6ee7  pop rsi
0000710a0d1d6ee8  pop rdi
0000710a0d1d6ee9  pop rdx
0000710a0d1d6eea  pop rcx
0000710a0d1d6eeb  pop rax
0000710a0d1d6eec  add rsp, 0x08
0000710a0d1d6ef0  jmp 0x0000710A0D1D6305
0000710a0d1d6ef5  sub rsp, 0x08
0000710a0d1d6ef9  push rax
0000710a0d1d6efa  push rcx
0000710a0d1d6efb  push rdx
0000710a0d1d6efc  push rdi
0000710a0d1d6efd  push rsi
0000710a0d1d6efe  push r8
0000710a0d1d6f00  push r9
0000710a0d1d6f02  push r10
0000710a0d1d6f04  push r11
0000710a0d1d6f06  sub rsp, 0xF0
0000710a0d1d6f0d  vmovaps [rsp], xmm0
0000710a0d1d6f12  vmovaps [rsp+0x10], xmm1
0000710a0d1d6f18  vmovaps [rsp+0x20], xmm2
0000710a0d1d6f1e  vmovaps [rsp+0x30], xmm3
0000710a0d1d6f24  vmovaps [rsp+0x40], xmm4
0000710a0d1d6f2a  vmovaps [rsp+0x50], xmm5
0000710a0d1d6f30  vmovaps [rsp+0x60], xmm6
0000710a0d1d6f36  vmovaps [rsp+0x70], xmm7
0000710a0d1d6f3c  vmovaps [rsp+0x80], xmm8
0000710a0d1d6f45  vmovaps [rsp+0x90], xmm9
0000710a0d1d6f4e  vmovaps [rsp+0xA0], xmm10
0000710a0d1d6f57  vmovaps [rsp+0xB0], xmm11
0000710a0d1d6f60  vmovaps [rsp+0xC0], xmm13
0000710a0d1d6f69  vmovaps [rsp+0xD0], xmm14
0000710a0d1d6f72  vmovaps [rsp+0xE0], xmm15
0000710a0d1d6f7b  sub rsp, 0x40
0000710a0d1d6f7f  lea rdi, [rsp]
0000710a0d1d6f83  lea rsi, [rsp+0x10]
0000710a0d1d6f88  lea rdx, [rsp+0x20]
0000710a0d1d6f8d  lea rcx, [rsp+0x30]
0000710a0d1d6f92  mov r8d, 0x00
0000710a0d1d6f98  lea r9, [r15+0x3A8]
0000710a0d1d6f9f  movaps [rdi], xmm12
0000710a0d1d6fa3  movaps [rsi], xmm15
0000710a0d1d6fa7  movaps [rdx], xmm1
0000710a0d1d6faa  movaps [rcx], xmm14
0000710a0d1d6fae  mov rax, 0x64F334B05A50
0000710a0d1d6fb8  call rax
0000710a0d1d6fba  movaps xmm12, [rsp]
0000710a0d1d6fbf  add rsp, 0x40
0000710a0d1d6fc3  vmovaps xmm0, [rsp]
0000710a0d1d6fc8  vmovaps xmm1, [rsp+0x10]
0000710a0d1d6fce  vmovaps xmm2, [rsp+0x20]
0000710a0d1d6fd4  vmovaps xmm3, [rsp+0x30]
0000710a0d1d6fda  vmovaps xmm4, [rsp+0x40]
0000710a0d1d6fe0  vmovaps xmm5, [rsp+0x50]
0000710a0d1d6fe6  vmovaps xmm6, [rsp+0x60]
0000710a0d1d6fec  vmovaps xmm7, [rsp+0x70]
0000710a0d1d6ff2  vmovaps xmm8, [rsp+0x80]
0000710a0d1d6ffb  vmovaps xmm9, [rsp+0x90]
0000710a0d1d7004  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d700d  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d7016  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d701f  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d7028  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d7031  add rsp, 0xF0
0000710a0d1d7038  pop r11
0000710a0d1d703a  pop r10
0000710a0d1d703c  pop r9
0000710a0d1d703e  pop r8
0000710a0d1d7040  pop rsi
0000710a0d1d7041  pop rdi
0000710a0d1d7042  pop rdx
0000710a0d1d7043  pop rcx
0000710a0d1d7044  pop rax
0000710a0d1d7045  add rsp, 0x08
0000710a0d1d7049  jmp 0x0000710A0D1D6333
0000710a0d1d704e  call 0x0000710A0D0D64F0
0000710a0d1d7053  jmp 0x0000710A0D1D641F
0000710a0d1d7058  sub rsp, 0x08
0000710a0d1d705c  push rax
0000710a0d1d705d  push rcx
0000710a0d1d705e  push rdx
0000710a0d1d705f  push rdi
0000710a0d1d7060  push rsi
0000710a0d1d7061  push r8
0000710a0d1d7063  push r9
0000710a0d1d7065  push r10
0000710a0d1d7067  push r11
0000710a0d1d7069  sub rsp, 0xF0
0000710a0d1d7070  vmovaps [rsp], xmm0
0000710a0d1d7075  vmovaps [rsp+0x10], xmm1
0000710a0d1d707b  vmovaps [rsp+0x20], xmm2
0000710a0d1d7081  vmovaps [rsp+0x30], xmm3
0000710a0d1d7087  vmovaps [rsp+0x40], xmm4
0000710a0d1d708d  vmovaps [rsp+0x50], xmm5
0000710a0d1d7093  vmovaps [rsp+0x60], xmm6
0000710a0d1d7099  vmovaps [rsp+0x70], xmm7
0000710a0d1d709f  vmovaps [rsp+0x80], xmm8
0000710a0d1d70a8  vmovaps [rsp+0x90], xmm9
0000710a0d1d70b1  vmovaps [rsp+0xA0], xmm10
0000710a0d1d70ba  vmovaps [rsp+0xB0], xmm11
0000710a0d1d70c3  vmovaps [rsp+0xC0], xmm12
0000710a0d1d70cc  vmovaps [rsp+0xD0], xmm14
0000710a0d1d70d5  vmovaps [rsp+0xE0], xmm15
0000710a0d1d70de  sub rsp, 0x40
0000710a0d1d70e2  lea rdi, [rsp]
0000710a0d1d70e6  lea rsi, [rsp+0x10]
0000710a0d1d70eb  lea rdx, [rsp+0x20]
0000710a0d1d70f0  lea rcx, [rsp+0x30]
0000710a0d1d70f5  mov r8d, 0x00
0000710a0d1d70fb  lea r9, [r15+0x3A8]
0000710a0d1d7102  movaps [rdi], xmm13
0000710a0d1d7106  movaps [rsi], xmm1
0000710a0d1d7109  movaps [rdx], xmm15
0000710a0d1d710d  movaps [rcx], xmm14
0000710a0d1d7111  mov rax, 0x64F334B05A50
0000710a0d1d711b  call rax
0000710a0d1d711d  movaps xmm13, [rsp]
0000710a0d1d7122  add rsp, 0x40
0000710a0d1d7126  vmovaps xmm0, [rsp]
0000710a0d1d712b  vmovaps xmm1, [rsp+0x10]
0000710a0d1d7131  vmovaps xmm2, [rsp+0x20]
0000710a0d1d7137  vmovaps xmm3, [rsp+0x30]
0000710a0d1d713d  vmovaps xmm4, [rsp+0x40]
0000710a0d1d7143  vmovaps xmm5, [rsp+0x50]
0000710a0d1d7149  vmovaps xmm6, [rsp+0x60]
0000710a0d1d714f  vmovaps xmm7, [rsp+0x70]
0000710a0d1d7155  vmovaps xmm8, [rsp+0x80]
0000710a0d1d715e  vmovaps xmm9, [rsp+0x90]
0000710a0d1d7167  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d7170  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d7179  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d7182  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d718b  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d7194  add rsp, 0xF0
0000710a0d1d719b  pop r11
0000710a0d1d719d  pop r10
0000710a0d1d719f  pop r9
0000710a0d1d71a1  pop r8
0000710a0d1d71a3  pop rsi
0000710a0d1d71a4  pop rdi
0000710a0d1d71a5  pop rdx
0000710a0d1d71a6  pop rcx
0000710a0d1d71a7  pop rax
0000710a0d1d71a8  add rsp, 0x08
0000710a0d1d71ac  jmp 0x0000710A0D1D648E
0000710a0d1d71b1  call 0x0000710A0D0D64F0
0000710a0d1d71b6  jmp 0x0000710A0D1D64A3
0000710a0d1d71bb  sub rsp, 0x08
0000710a0d1d71bf  push rax
0000710a0d1d71c0  push rcx
0000710a0d1d71c1  push rdx
0000710a0d1d71c2  push rdi
0000710a0d1d71c3  push rsi
0000710a0d1d71c4  push r8
0000710a0d1d71c6  push r9
0000710a0d1d71c8  push r10
0000710a0d1d71ca  push r11
0000710a0d1d71cc  sub rsp, 0xF0
0000710a0d1d71d3  vmovaps [rsp], xmm0
0000710a0d1d71d8  vmovaps [rsp+0x10], xmm1
0000710a0d1d71de  vmovaps [rsp+0x20], xmm2
0000710a0d1d71e4  vmovaps [rsp+0x30], xmm3
0000710a0d1d71ea  vmovaps [rsp+0x40], xmm4
0000710a0d1d71f0  vmovaps [rsp+0x50], xmm5
0000710a0d1d71f6  vmovaps [rsp+0x60], xmm6
0000710a0d1d71fc  vmovaps [rsp+0x70], xmm7
0000710a0d1d7202  vmovaps [rsp+0x80], xmm8
0000710a0d1d720b  vmovaps [rsp+0x90], xmm9
0000710a0d1d7214  vmovaps [rsp+0xA0], xmm10
0000710a0d1d721d  vmovaps [rsp+0xB0], xmm11
0000710a0d1d7226  vmovaps [rsp+0xC0], xmm13
0000710a0d1d722f  vmovaps [rsp+0xD0], xmm14
0000710a0d1d7238  vmovaps [rsp+0xE0], xmm15
0000710a0d1d7241  sub rsp, 0x40
0000710a0d1d7245  lea rdi, [rsp]
0000710a0d1d7249  lea rsi, [rsp+0x10]
0000710a0d1d724e  lea rdx, [rsp+0x20]
0000710a0d1d7253  lea rcx, [rsp+0x30]
0000710a0d1d7258  mov r8d, 0x00
0000710a0d1d725e  lea r9, [r15+0x3A8]
0000710a0d1d7265  movaps [rdi], xmm12
0000710a0d1d7269  movaps [rsi], xmm15
0000710a0d1d726d  movaps [rdx], xmm1
0000710a0d1d7270  movaps [rcx], xmm14
0000710a0d1d7274  mov rax, 0x64F334B05A50
0000710a0d1d727e  call rax
0000710a0d1d7280  movaps xmm12, [rsp]
0000710a0d1d7285  add rsp, 0x40
0000710a0d1d7289  vmovaps xmm0, [rsp]
0000710a0d1d728e  vmovaps xmm1, [rsp+0x10]
0000710a0d1d7294  vmovaps xmm2, [rsp+0x20]
0000710a0d1d729a  vmovaps xmm3, [rsp+0x30]
0000710a0d1d72a0  vmovaps xmm4, [rsp+0x40]
0000710a0d1d72a6  vmovaps xmm5, [rsp+0x50]
0000710a0d1d72ac  vmovaps xmm6, [rsp+0x60]
0000710a0d1d72b2  vmovaps xmm7, [rsp+0x70]
0000710a0d1d72b8  vmovaps xmm8, [rsp+0x80]
0000710a0d1d72c1  vmovaps xmm9, [rsp+0x90]
0000710a0d1d72ca  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d72d3  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d72dc  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d72e5  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d72ee  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d72f7  add rsp, 0xF0
0000710a0d1d72fe  pop r11
0000710a0d1d7300  pop r10
0000710a0d1d7302  pop r9
0000710a0d1d7304  pop r8
0000710a0d1d7306  pop rsi
0000710a0d1d7307  pop rdi
0000710a0d1d7308  pop rdx
0000710a0d1d7309  pop rcx
0000710a0d1d730a  pop rax
0000710a0d1d730b  add rsp, 0x08
0000710a0d1d730f  jmp 0x0000710A0D1D64CF
0000710a0d1d7314  sub rsp, 0x08
0000710a0d1d7318  push rax
0000710a0d1d7319  push rcx
0000710a0d1d731a  push rdx
0000710a0d1d731b  push rdi
0000710a0d1d731c  push rsi
0000710a0d1d731d  push r8
0000710a0d1d731f  push r9
0000710a0d1d7321  push r10
0000710a0d1d7323  push r11
0000710a0d1d7325  sub rsp, 0xF0
0000710a0d1d732c  vmovaps [rsp], xmm0
0000710a0d1d7331  vmovaps [rsp+0x10], xmm1
0000710a0d1d7337  vmovaps [rsp+0x20], xmm2
0000710a0d1d733d  vmovaps [rsp+0x30], xmm3
0000710a0d1d7343  vmovaps [rsp+0x40], xmm4
0000710a0d1d7349  vmovaps [rsp+0x50], xmm5
0000710a0d1d734f  vmovaps [rsp+0x60], xmm6
0000710a0d1d7355  vmovaps [rsp+0x70], xmm7
0000710a0d1d735b  vmovaps [rsp+0x80], xmm8
0000710a0d1d7364  vmovaps [rsp+0x90], xmm9
0000710a0d1d736d  vmovaps [rsp+0xA0], xmm10
0000710a0d1d7376  vmovaps [rsp+0xB0], xmm11
0000710a0d1d737f  vmovaps [rsp+0xC0], xmm12
0000710a0d1d7388  vmovaps [rsp+0xD0], xmm14
0000710a0d1d7391  vmovaps [rsp+0xE0], xmm15
0000710a0d1d739a  sub rsp, 0x40
0000710a0d1d739e  lea rdi, [rsp]
0000710a0d1d73a2  lea rsi, [rsp+0x10]
0000710a0d1d73a7  lea rdx, [rsp+0x20]
0000710a0d1d73ac  lea rcx, [rsp+0x30]
0000710a0d1d73b1  mov r8d, 0x00
0000710a0d1d73b7  lea r9, [r15+0x3A8]
0000710a0d1d73be  movaps [rdi], xmm13
0000710a0d1d73c2  movaps [rsi], xmm1
0000710a0d1d73c5  movaps [rdx], xmm15
0000710a0d1d73c9  movaps [rcx], xmm14
0000710a0d1d73cd  mov rax, 0x64F334B05A50
0000710a0d1d73d7  call rax
0000710a0d1d73d9  movaps xmm13, [rsp]
0000710a0d1d73de  add rsp, 0x40
0000710a0d1d73e2  vmovaps xmm0, [rsp]
0000710a0d1d73e7  vmovaps xmm1, [rsp+0x10]
0000710a0d1d73ed  vmovaps xmm2, [rsp+0x20]
0000710a0d1d73f3  vmovaps xmm3, [rsp+0x30]
0000710a0d1d73f9  vmovaps xmm4, [rsp+0x40]
0000710a0d1d73ff  vmovaps xmm5, [rsp+0x50]
0000710a0d1d7405  vmovaps xmm6, [rsp+0x60]
0000710a0d1d740b  vmovaps xmm7, [rsp+0x70]
0000710a0d1d7411  vmovaps xmm8, [rsp+0x80]
0000710a0d1d741a  vmovaps xmm9, [rsp+0x90]
0000710a0d1d7423  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d742c  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d7435  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d743e  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d7447  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d7450  add rsp, 0xF0
0000710a0d1d7457  pop r11
0000710a0d1d7459  pop r10
0000710a0d1d745b  pop r9
0000710a0d1d745d  pop r8
0000710a0d1d745f  pop rsi
0000710a0d1d7460  pop rdi
0000710a0d1d7461  pop rdx
0000710a0d1d7462  pop rcx
0000710a0d1d7463  pop rax
0000710a0d1d7464  add rsp, 0x08
0000710a0d1d7468  jmp 0x0000710A0D1D665F
0000710a0d1d746d  sub rsp, 0x08
0000710a0d1d7471  push rax
0000710a0d1d7472  push rcx
0000710a0d1d7473  push rdx
0000710a0d1d7474  push rdi
0000710a0d1d7475  push rsi
0000710a0d1d7476  push r8
0000710a0d1d7478  push r9
0000710a0d1d747a  push r10
0000710a0d1d747c  push r11
0000710a0d1d747e  sub rsp, 0xF0
0000710a0d1d7485  vmovaps [rsp], xmm0
0000710a0d1d748a  vmovaps [rsp+0x10], xmm1
0000710a0d1d7490  vmovaps [rsp+0x20], xmm2
0000710a0d1d7496  vmovaps [rsp+0x30], xmm3
0000710a0d1d749c  vmovaps [rsp+0x40], xmm4
0000710a0d1d74a2  vmovaps [rsp+0x50], xmm5
0000710a0d1d74a8  vmovaps [rsp+0x60], xmm6
0000710a0d1d74ae  vmovaps [rsp+0x70], xmm7
0000710a0d1d74b4  vmovaps [rsp+0x80], xmm8
0000710a0d1d74bd  vmovaps [rsp+0x90], xmm9
0000710a0d1d74c6  vmovaps [rsp+0xA0], xmm10
0000710a0d1d74cf  vmovaps [rsp+0xB0], xmm11
0000710a0d1d74d8  vmovaps [rsp+0xC0], xmm12
0000710a0d1d74e1  vmovaps [rsp+0xD0], xmm13
0000710a0d1d74ea  vmovaps [rsp+0xE0], xmm15
0000710a0d1d74f3  sub rsp, 0x40
0000710a0d1d74f7  lea rdi, [rsp]
0000710a0d1d74fb  lea rsi, [rsp+0x10]
0000710a0d1d7500  lea rdx, [rsp+0x20]
0000710a0d1d7505  lea rcx, [rsp+0x30]
0000710a0d1d750a  mov r8d, 0x00
0000710a0d1d7510  lea r9, [r15+0x3A8]
0000710a0d1d7517  movaps [rdi], xmm14
0000710a0d1d751b  movaps [rsi], xmm15
0000710a0d1d751f  movaps [rdx], xmm2
0000710a0d1d7522  movaps [rcx], xmm1
0000710a0d1d7525  mov rax, 0x64F334B05A50
0000710a0d1d752f  call rax
0000710a0d1d7531  movaps xmm14, [rsp]
0000710a0d1d7536  add rsp, 0x40
0000710a0d1d753a  vmovaps xmm0, [rsp]
0000710a0d1d753f  vmovaps xmm1, [rsp+0x10]
0000710a0d1d7545  vmovaps xmm2, [rsp+0x20]
0000710a0d1d754b  vmovaps xmm3, [rsp+0x30]
0000710a0d1d7551  vmovaps xmm4, [rsp+0x40]
0000710a0d1d7557  vmovaps xmm5, [rsp+0x50]
0000710a0d1d755d  vmovaps xmm6, [rsp+0x60]
0000710a0d1d7563  vmovaps xmm7, [rsp+0x70]
0000710a0d1d7569  vmovaps xmm8, [rsp+0x80]
0000710a0d1d7572  vmovaps xmm9, [rsp+0x90]
0000710a0d1d757b  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d7584  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d758d  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d7596  vmovaps xmm13, [rsp+0xD0]
0000710a0d1d759f  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d75a8  add rsp, 0xF0
0000710a0d1d75af  pop r11
0000710a0d1d75b1  pop r10
0000710a0d1d75b3  pop r9
0000710a0d1d75b5  pop r8
0000710a0d1d75b7  pop rsi
0000710a0d1d75b8  pop rdi
0000710a0d1d75b9  pop rdx
0000710a0d1d75ba  pop rcx
0000710a0d1d75bb  pop rax
0000710a0d1d75bc  add rsp, 0x08
0000710a0d1d75c0  jmp 0x0000710A0D1D6691
0000710a0d1d75c5  sub rsp, 0x08
0000710a0d1d75c9  push rax
0000710a0d1d75ca  push rcx
0000710a0d1d75cb  push rdx
0000710a0d1d75cc  push rdi
0000710a0d1d75cd  push rsi
0000710a0d1d75ce  push r8
0000710a0d1d75d0  push r9
0000710a0d1d75d2  push r10
0000710a0d1d75d4  push r11
0000710a0d1d75d6  sub rsp, 0xF0
0000710a0d1d75dd  vmovaps [rsp], xmm0
0000710a0d1d75e2  vmovaps [rsp+0x10], xmm1
0000710a0d1d75e8  vmovaps [rsp+0x20], xmm3
0000710a0d1d75ee  vmovaps [rsp+0x30], xmm4
0000710a0d1d75f4  vmovaps [rsp+0x40], xmm5
0000710a0d1d75fa  vmovaps [rsp+0x50], xmm6
0000710a0d1d7600  vmovaps [rsp+0x60], xmm7
0000710a0d1d7606  vmovaps [rsp+0x70], xmm8
0000710a0d1d760c  vmovaps [rsp+0x80], xmm9
0000710a0d1d7615  vmovaps [rsp+0x90], xmm10
0000710a0d1d761e  vmovaps [rsp+0xA0], xmm11
0000710a0d1d7627  vmovaps [rsp+0xB0], xmm12
0000710a0d1d7630  vmovaps [rsp+0xC0], xmm13
0000710a0d1d7639  vmovaps [rsp+0xD0], xmm14
0000710a0d1d7642  vmovaps [rsp+0xE0], xmm15
0000710a0d1d764b  sub rsp, 0x40
0000710a0d1d764f  lea rdi, [rsp]
0000710a0d1d7653  lea rsi, [rsp+0x10]
0000710a0d1d7658  lea rdx, [rsp+0x20]
0000710a0d1d765d  lea rcx, [rsp+0x30]
0000710a0d1d7662  mov r8d, 0x00
0000710a0d1d7668  lea r9, [r15+0x3A8]
0000710a0d1d766f  movaps [rdi], xmm2
0000710a0d1d7672  movaps [rsi], xmm15
0000710a0d1d7676  movaps [rdx], xmm12
0000710a0d1d767a  movaps [rcx], xmm1
0000710a0d1d767d  mov rax, 0x64F334B05A50
0000710a0d1d7687  call rax
0000710a0d1d7689  movaps xmm2, [rsp]
0000710a0d1d768d  add rsp, 0x40
0000710a0d1d7691  vmovaps xmm0, [rsp]
0000710a0d1d7696  vmovaps xmm1, [rsp+0x10]
0000710a0d1d769c  vmovaps xmm3, [rsp+0x20]
0000710a0d1d76a2  vmovaps xmm4, [rsp+0x30]
0000710a0d1d76a8  vmovaps xmm5, [rsp+0x40]
0000710a0d1d76ae  vmovaps xmm6, [rsp+0x50]
0000710a0d1d76b4  vmovaps xmm7, [rsp+0x60]
0000710a0d1d76ba  vmovaps xmm8, [rsp+0x70]
0000710a0d1d76c0  vmovaps xmm9, [rsp+0x80]
0000710a0d1d76c9  vmovaps xmm10, [rsp+0x90]
0000710a0d1d76d2  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d76db  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d76e4  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d76ed  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d76f6  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d76ff  add rsp, 0xF0
0000710a0d1d7706  pop r11
0000710a0d1d7708  pop r10
0000710a0d1d770a  pop r9
0000710a0d1d770c  pop r8
0000710a0d1d770e  pop rsi
0000710a0d1d770f  pop rdi
0000710a0d1d7710  pop rdx
0000710a0d1d7711  pop rcx
0000710a0d1d7712  pop rax
0000710a0d1d7713  add rsp, 0x08
0000710a0d1d7717  jmp 0x0000710A0D1D66CE
0000710a0d1d771c  sub rsp, 0x08
0000710a0d1d7720  push rax
0000710a0d1d7721  push rcx
0000710a0d1d7722  push rdx
0000710a0d1d7723  push rdi
0000710a0d1d7724  push rsi
0000710a0d1d7725  push r8
0000710a0d1d7727  push r9
0000710a0d1d7729  push r10
0000710a0d1d772b  push r11
0000710a0d1d772d  sub rsp, 0xF0
0000710a0d1d7734  vmovaps [rsp], xmm0
0000710a0d1d7739  vmovaps [rsp+0x10], xmm1
0000710a0d1d773f  vmovaps [rsp+0x20], xmm2
0000710a0d1d7745  vmovaps [rsp+0x30], xmm3
0000710a0d1d774b  vmovaps [rsp+0x40], xmm4
0000710a0d1d7751  vmovaps [rsp+0x50], xmm5
0000710a0d1d7757  vmovaps [rsp+0x60], xmm6
0000710a0d1d775d  vmovaps [rsp+0x70], xmm7
0000710a0d1d7763  vmovaps [rsp+0x80], xmm8
0000710a0d1d776c  vmovaps [rsp+0x90], xmm9
0000710a0d1d7775  vmovaps [rsp+0xA0], xmm10
0000710a0d1d777e  vmovaps [rsp+0xB0], xmm11
0000710a0d1d7787  vmovaps [rsp+0xC0], xmm13
0000710a0d1d7790  vmovaps [rsp+0xD0], xmm14
0000710a0d1d7799  vmovaps [rsp+0xE0], xmm15
0000710a0d1d77a2  sub rsp, 0x40
0000710a0d1d77a6  lea rdi, [rsp]
0000710a0d1d77aa  lea rsi, [rsp+0x10]
0000710a0d1d77af  lea rdx, [rsp+0x20]
0000710a0d1d77b4  lea rcx, [rsp+0x30]
0000710a0d1d77b9  mov r8d, 0x00
0000710a0d1d77bf  lea r9, [r15+0x3A8]
0000710a0d1d77c6  movaps [rdi], xmm12
0000710a0d1d77ca  movaps [rsi], xmm14
0000710a0d1d77ce  movaps [rdx], xmm3
0000710a0d1d77d1  movaps [rcx], xmm15
0000710a0d1d77d5  mov rax, 0x64F334B05A50
0000710a0d1d77df  call rax
0000710a0d1d77e1  movaps xmm12, [rsp]
0000710a0d1d77e6  add rsp, 0x40
0000710a0d1d77ea  vmovaps xmm0, [rsp]
0000710a0d1d77ef  vmovaps xmm1, [rsp+0x10]
0000710a0d1d77f5  vmovaps xmm2, [rsp+0x20]
0000710a0d1d77fb  vmovaps xmm3, [rsp+0x30]
0000710a0d1d7801  vmovaps xmm4, [rsp+0x40]
0000710a0d1d7807  vmovaps xmm5, [rsp+0x50]
0000710a0d1d780d  vmovaps xmm6, [rsp+0x60]
0000710a0d1d7813  vmovaps xmm7, [rsp+0x70]
0000710a0d1d7819  vmovaps xmm8, [rsp+0x80]
0000710a0d1d7822  vmovaps xmm9, [rsp+0x90]
0000710a0d1d782b  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d7834  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d783d  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d7846  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d784f  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d7858  add rsp, 0xF0
0000710a0d1d785f  pop r11
0000710a0d1d7861  pop r10
0000710a0d1d7863  pop r9
0000710a0d1d7865  pop r8
0000710a0d1d7867  pop rsi
0000710a0d1d7868  pop rdi
0000710a0d1d7869  pop rdx
0000710a0d1d786a  pop rcx
0000710a0d1d786b  pop rax
0000710a0d1d786c  add rsp, 0x08
0000710a0d1d7870  jmp 0x0000710A0D1D6728
0000710a0d1d7875  sub rsp, 0x08
0000710a0d1d7879  push rax
0000710a0d1d787a  push rcx
0000710a0d1d787b  push rdx
0000710a0d1d787c  push rdi
0000710a0d1d787d  push rsi
0000710a0d1d787e  push r8
0000710a0d1d7880  push r9
0000710a0d1d7882  push r10
0000710a0d1d7884  push r11
0000710a0d1d7886  sub rsp, 0xF0
0000710a0d1d788d  vmovaps [rsp], xmm0
0000710a0d1d7892  vmovaps [rsp+0x10], xmm1
0000710a0d1d7898  vmovaps [rsp+0x20], xmm2
0000710a0d1d789e  vmovaps [rsp+0x30], xmm3
0000710a0d1d78a4  vmovaps [rsp+0x40], xmm4
0000710a0d1d78aa  vmovaps [rsp+0x50], xmm5
0000710a0d1d78b0  vmovaps [rsp+0x60], xmm6
0000710a0d1d78b6  vmovaps [rsp+0x70], xmm7
0000710a0d1d78bc  vmovaps [rsp+0x80], xmm8
0000710a0d1d78c5  vmovaps [rsp+0x90], xmm10
0000710a0d1d78ce  vmovaps [rsp+0xA0], xmm11
0000710a0d1d78d7  vmovaps [rsp+0xB0], xmm12
0000710a0d1d78e0  vmovaps [rsp+0xC0], xmm13
0000710a0d1d78e9  vmovaps [rsp+0xD0], xmm14
0000710a0d1d78f2  vmovaps [rsp+0xE0], xmm15
0000710a0d1d78fb  sub rsp, 0x40
0000710a0d1d78ff  lea rdi, [rsp]
0000710a0d1d7903  lea rsi, [rsp+0x10]
0000710a0d1d7908  lea rdx, [rsp+0x20]
0000710a0d1d790d  lea rcx, [rsp+0x30]
0000710a0d1d7912  mov r8d, 0x00
0000710a0d1d7918  lea r9, [r15+0x3A8]
0000710a0d1d791f  movaps [rdi], xmm9
0000710a0d1d7923  movaps [rsi], xmm13
0000710a0d1d7927  movaps [rdx], xmm14
0000710a0d1d792b  movaps [rcx], xmm6
0000710a0d1d792e  mov rax, 0x64F334B05A50
0000710a0d1d7938  call rax
0000710a0d1d793a  movaps xmm9, [rsp]
0000710a0d1d793f  add rsp, 0x40
0000710a0d1d7943  vmovaps xmm0, [rsp]
0000710a0d1d7948  vmovaps xmm1, [rsp+0x10]
0000710a0d1d794e  vmovaps xmm2, [rsp+0x20]
0000710a0d1d7954  vmovaps xmm3, [rsp+0x30]
0000710a0d1d795a  vmovaps xmm4, [rsp+0x40]
0000710a0d1d7960  vmovaps xmm5, [rsp+0x50]
0000710a0d1d7966  vmovaps xmm6, [rsp+0x60]
0000710a0d1d796c  vmovaps xmm7, [rsp+0x70]
0000710a0d1d7972  vmovaps xmm8, [rsp+0x80]
0000710a0d1d797b  vmovaps xmm10, [rsp+0x90]
0000710a0d1d7984  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d798d  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d7996  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d799f  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d79a8  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d79b1  add rsp, 0xF0
0000710a0d1d79b8  pop r11
0000710a0d1d79ba  pop r10
0000710a0d1d79bc  pop r9
0000710a0d1d79be  pop r8
0000710a0d1d79c0  pop rsi
0000710a0d1d79c1  pop rdi
0000710a0d1d79c2  pop rdx
0000710a0d1d79c3  pop rcx
0000710a0d1d79c4  pop rax
0000710a0d1d79c5  add rsp, 0x08
0000710a0d1d79c9  jmp 0x0000710A0D1D67D2
0000710a0d1d79ce  sub rsp, 0x08
0000710a0d1d79d2  push rax
0000710a0d1d79d3  push rcx
0000710a0d1d79d4  push rdx
0000710a0d1d79d5  push rdi
0000710a0d1d79d6  push rsi
0000710a0d1d79d7  push r8
0000710a0d1d79d9  push r9
0000710a0d1d79db  push r10
0000710a0d1d79dd  push r11
0000710a0d1d79df  sub rsp, 0xF0
0000710a0d1d79e6  vmovaps [rsp], xmm0
0000710a0d1d79eb  vmovaps [rsp+0x10], xmm1
0000710a0d1d79f1  vmovaps [rsp+0x20], xmm2
0000710a0d1d79f7  vmovaps [rsp+0x30], xmm4
0000710a0d1d79fd  vmovaps [rsp+0x40], xmm5
0000710a0d1d7a03  vmovaps [rsp+0x50], xmm6
0000710a0d1d7a09  vmovaps [rsp+0x60], xmm7
0000710a0d1d7a0f  vmovaps [rsp+0x70], xmm8
0000710a0d1d7a15  vmovaps [rsp+0x80], xmm9
0000710a0d1d7a1e  vmovaps [rsp+0x90], xmm10
0000710a0d1d7a27  vmovaps [rsp+0xA0], xmm11
0000710a0d1d7a30  vmovaps [rsp+0xB0], xmm12
0000710a0d1d7a39  vmovaps [rsp+0xC0], xmm13
0000710a0d1d7a42  vmovaps [rsp+0xD0], xmm14
0000710a0d1d7a4b  vmovaps [rsp+0xE0], xmm15
0000710a0d1d7a54  sub rsp, 0x40
0000710a0d1d7a58  lea rdi, [rsp]
0000710a0d1d7a5c  lea rsi, [rsp+0x10]
0000710a0d1d7a61  lea rdx, [rsp+0x20]
0000710a0d1d7a66  lea rcx, [rsp+0x30]
0000710a0d1d7a6b  mov r8d, 0x00
0000710a0d1d7a71  lea r9, [r15+0x3A8]
0000710a0d1d7a78  movaps [rdi], xmm3
0000710a0d1d7a7b  movaps [rsi], xmm13
0000710a0d1d7a7f  movaps [rdx], xmm6
0000710a0d1d7a82  movaps [rcx], xmm14
0000710a0d1d7a86  mov rax, 0x64F334B05A50
0000710a0d1d7a90  call rax
0000710a0d1d7a92  movaps xmm3, [rsp]
0000710a0d1d7a96  add rsp, 0x40
0000710a0d1d7a9a  vmovaps xmm0, [rsp]
0000710a0d1d7a9f  vmovaps xmm1, [rsp+0x10]
0000710a0d1d7aa5  vmovaps xmm2, [rsp+0x20]
0000710a0d1d7aab  vmovaps xmm4, [rsp+0x30]
0000710a0d1d7ab1  vmovaps xmm5, [rsp+0x40]
0000710a0d1d7ab7  vmovaps xmm6, [rsp+0x50]
0000710a0d1d7abd  vmovaps xmm7, [rsp+0x60]
0000710a0d1d7ac3  vmovaps xmm8, [rsp+0x70]
0000710a0d1d7ac9  vmovaps xmm9, [rsp+0x80]
0000710a0d1d7ad2  vmovaps xmm10, [rsp+0x90]
0000710a0d1d7adb  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d7ae4  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d7aed  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d7af6  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d7aff  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d7b08  add rsp, 0xF0
0000710a0d1d7b0f  pop r11
0000710a0d1d7b11  pop r10
0000710a0d1d7b13  pop r9
0000710a0d1d7b15  pop r8
0000710a0d1d7b17  pop rsi
0000710a0d1d7b18  pop rdi
0000710a0d1d7b19  pop rdx
0000710a0d1d7b1a  pop rcx
0000710a0d1d7b1b  pop rax
0000710a0d1d7b1c  add rsp, 0x08
0000710a0d1d7b20  jmp 0x0000710A0D1D680F
0000710a0d1d7b25  sub rsp, 0x08
0000710a0d1d7b29  push rax
0000710a0d1d7b2a  push rcx
0000710a0d1d7b2b  push rdx
0000710a0d1d7b2c  push rdi
0000710a0d1d7b2d  push rsi
0000710a0d1d7b2e  push r8
0000710a0d1d7b30  push r9
0000710a0d1d7b32  push r10
0000710a0d1d7b34  push r11
0000710a0d1d7b36  sub rsp, 0xF0
0000710a0d1d7b3d  vmovaps [rsp], xmm0
0000710a0d1d7b42  vmovaps [rsp+0x10], xmm1
0000710a0d1d7b48  vmovaps [rsp+0x20], xmm2
0000710a0d1d7b4e  vmovaps [rsp+0x30], xmm3
0000710a0d1d7b54  vmovaps [rsp+0x40], xmm4
0000710a0d1d7b5a  vmovaps [rsp+0x50], xmm5
0000710a0d1d7b60  vmovaps [rsp+0x60], xmm7
0000710a0d1d7b66  vmovaps [rsp+0x70], xmm8
0000710a0d1d7b6c  vmovaps [rsp+0x80], xmm9
0000710a0d1d7b75  vmovaps [rsp+0x90], xmm10
0000710a0d1d7b7e  vmovaps [rsp+0xA0], xmm11
0000710a0d1d7b87  vmovaps [rsp+0xB0], xmm12
0000710a0d1d7b90  vmovaps [rsp+0xC0], xmm13
0000710a0d1d7b99  vmovaps [rsp+0xD0], xmm14
0000710a0d1d7ba2  vmovaps [rsp+0xE0], xmm15
0000710a0d1d7bab  sub rsp, 0x40
0000710a0d1d7baf  lea rdi, [rsp]
0000710a0d1d7bb3  lea rsi, [rsp+0x10]
0000710a0d1d7bb8  lea rdx, [rsp+0x20]
0000710a0d1d7bbd  lea rcx, [rsp+0x30]
0000710a0d1d7bc2  mov r8d, 0x00
0000710a0d1d7bc8  lea r9, [r15+0x3A8]
0000710a0d1d7bcf  movaps [rdi], xmm6
0000710a0d1d7bd2  movaps [rsi], xmm2
0000710a0d1d7bd5  movaps [rdx], xmm14
0000710a0d1d7bd9  movaps [rcx], xmm1
0000710a0d1d7bdc  mov rax, 0x64F334B05A50
0000710a0d1d7be6  call rax
0000710a0d1d7be8  movaps xmm6, [rsp]
0000710a0d1d7bec  add rsp, 0x40
0000710a0d1d7bf0  vmovaps xmm0, [rsp]
0000710a0d1d7bf5  vmovaps xmm1, [rsp+0x10]
0000710a0d1d7bfb  vmovaps xmm2, [rsp+0x20]
0000710a0d1d7c01  vmovaps xmm3, [rsp+0x30]
0000710a0d1d7c07  vmovaps xmm4, [rsp+0x40]
0000710a0d1d7c0d  vmovaps xmm5, [rsp+0x50]
0000710a0d1d7c13  vmovaps xmm7, [rsp+0x60]
0000710a0d1d7c19  vmovaps xmm8, [rsp+0x70]
0000710a0d1d7c1f  vmovaps xmm9, [rsp+0x80]
0000710a0d1d7c28  vmovaps xmm10, [rsp+0x90]
0000710a0d1d7c31  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d7c3a  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d7c43  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d7c4c  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d7c55  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d7c5e  add rsp, 0xF0
0000710a0d1d7c65  pop r11
0000710a0d1d7c67  pop r10
0000710a0d1d7c69  pop r9
0000710a0d1d7c6b  pop r8
0000710a0d1d7c6d  pop rsi
0000710a0d1d7c6e  pop rdi
0000710a0d1d7c6f  pop rdx
0000710a0d1d7c70  pop rcx
0000710a0d1d7c71  pop rax
0000710a0d1d7c72  add rsp, 0x08
0000710a0d1d7c76  jmp 0x0000710A0D1D683C
0000710a0d1d7c7b  sub rsp, 0x08
0000710a0d1d7c7f  push rax
0000710a0d1d7c80  push rcx
0000710a0d1d7c81  push rdx
0000710a0d1d7c82  push rdi
0000710a0d1d7c83  push rsi
0000710a0d1d7c84  push r8
0000710a0d1d7c86  push r9
0000710a0d1d7c88  push r10
0000710a0d1d7c8a  push r11
0000710a0d1d7c8c  sub rsp, 0xF0
0000710a0d1d7c93  vmovaps [rsp], xmm0
0000710a0d1d7c98  vmovaps [rsp+0x10], xmm1
0000710a0d1d7c9e  vmovaps [rsp+0x20], xmm2
0000710a0d1d7ca4  vmovaps [rsp+0x30], xmm3
0000710a0d1d7caa  vmovaps [rsp+0x40], xmm4
0000710a0d1d7cb0  vmovaps [rsp+0x50], xmm5
0000710a0d1d7cb6  vmovaps [rsp+0x60], xmm6
0000710a0d1d7cbc  vmovaps [rsp+0x70], xmm7
0000710a0d1d7cc2  vmovaps [rsp+0x80], xmm8
0000710a0d1d7ccb  vmovaps [rsp+0x90], xmm9
0000710a0d1d7cd4  vmovaps [rsp+0xA0], xmm10
0000710a0d1d7cdd  vmovaps [rsp+0xB0], xmm11
0000710a0d1d7ce6  vmovaps [rsp+0xC0], xmm12
0000710a0d1d7cef  vmovaps [rsp+0xD0], xmm14
0000710a0d1d7cf8  vmovaps [rsp+0xE0], xmm15
0000710a0d1d7d01  sub rsp, 0x40
0000710a0d1d7d05  lea rdi, [rsp]
0000710a0d1d7d09  lea rsi, [rsp+0x10]
0000710a0d1d7d0e  lea rdx, [rsp+0x20]
0000710a0d1d7d13  lea rcx, [rsp+0x30]
0000710a0d1d7d18  mov r8d, 0x00
0000710a0d1d7d1e  lea r9, [r15+0x3A8]
0000710a0d1d7d25  movaps [rdi], xmm13
0000710a0d1d7d29  movaps [rsi], xmm12
0000710a0d1d7d2d  movaps [rdx], xmm14
0000710a0d1d7d31  movaps [rcx], xmm1
0000710a0d1d7d34  mov rax, 0x64F334B05A50
0000710a0d1d7d3e  call rax
0000710a0d1d7d40  movaps xmm13, [rsp]
0000710a0d1d7d45  add rsp, 0x40
0000710a0d1d7d49  vmovaps xmm0, [rsp]
0000710a0d1d7d4e  vmovaps xmm1, [rsp+0x10]
0000710a0d1d7d54  vmovaps xmm2, [rsp+0x20]
0000710a0d1d7d5a  vmovaps xmm3, [rsp+0x30]
0000710a0d1d7d60  vmovaps xmm4, [rsp+0x40]
0000710a0d1d7d66  vmovaps xmm5, [rsp+0x50]
0000710a0d1d7d6c  vmovaps xmm6, [rsp+0x60]
0000710a0d1d7d72  vmovaps xmm7, [rsp+0x70]
0000710a0d1d7d78  vmovaps xmm8, [rsp+0x80]
0000710a0d1d7d81  vmovaps xmm9, [rsp+0x90]
0000710a0d1d7d8a  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d7d93  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d7d9c  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d7da5  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d7dae  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d7db7  add rsp, 0xF0
0000710a0d1d7dbe  pop r11
0000710a0d1d7dc0  pop r10
0000710a0d1d7dc2  pop r9
0000710a0d1d7dc4  pop r8
0000710a0d1d7dc6  pop rsi
0000710a0d1d7dc7  pop rdi
0000710a0d1d7dc8  pop rdx
0000710a0d1d7dc9  pop rcx
0000710a0d1d7dca  pop rax
0000710a0d1d7dcb  add rsp, 0x08
0000710a0d1d7dcf  jmp 0x0000710A0D1D686E
0000710a0d1d7dd4  sub rsp, 0x08
0000710a0d1d7dd8  push rax
0000710a0d1d7dd9  push rcx
0000710a0d1d7dda  push rdx
0000710a0d1d7ddb  push rdi
0000710a0d1d7ddc  push rsi
0000710a0d1d7ddd  push r8
0000710a0d1d7ddf  push r9
0000710a0d1d7de1  push r10
0000710a0d1d7de3  push r11
0000710a0d1d7de5  sub rsp, 0xF0
0000710a0d1d7dec  vmovaps [rsp], xmm0
0000710a0d1d7df1  vmovaps [rsp+0x10], xmm1
0000710a0d1d7df7  vmovaps [rsp+0x20], xmm2
0000710a0d1d7dfd  vmovaps [rsp+0x30], xmm3
0000710a0d1d7e03  vmovaps [rsp+0x40], xmm4
0000710a0d1d7e09  vmovaps [rsp+0x50], xmm5
0000710a0d1d7e0f  vmovaps [rsp+0x60], xmm6
0000710a0d1d7e15  vmovaps [rsp+0x70], xmm7
0000710a0d1d7e1b  vmovaps [rsp+0x80], xmm8
0000710a0d1d7e24  vmovaps [rsp+0x90], xmm9
0000710a0d1d7e2d  vmovaps [rsp+0xA0], xmm10
0000710a0d1d7e36  vmovaps [rsp+0xB0], xmm11
0000710a0d1d7e3f  vmovaps [rsp+0xC0], xmm13
0000710a0d1d7e48  vmovaps [rsp+0xD0], xmm14
0000710a0d1d7e51  vmovaps [rsp+0xE0], xmm15
0000710a0d1d7e5a  sub rsp, 0x40
0000710a0d1d7e5e  lea rdi, [rsp]
0000710a0d1d7e62  lea rsi, [rsp+0x10]
0000710a0d1d7e67  lea rdx, [rsp+0x20]
0000710a0d1d7e6c  lea rcx, [rsp+0x30]
0000710a0d1d7e71  mov r8d, 0x00
0000710a0d1d7e77  lea r9, [r15+0x3A8]
0000710a0d1d7e7e  movaps [rdi], xmm12
0000710a0d1d7e82  movaps [rsi], xmm3
0000710a0d1d7e85  movaps [rdx], xmm14
0000710a0d1d7e89  movaps [rcx], xmm5
0000710a0d1d7e8c  mov rax, 0x64F334B05A50
0000710a0d1d7e96  call rax
0000710a0d1d7e98  movaps xmm12, [rsp]
0000710a0d1d7e9d  add rsp, 0x40
0000710a0d1d7ea1  vmovaps xmm0, [rsp]
0000710a0d1d7ea6  vmovaps xmm1, [rsp+0x10]
0000710a0d1d7eac  vmovaps xmm2, [rsp+0x20]
0000710a0d1d7eb2  vmovaps xmm3, [rsp+0x30]
0000710a0d1d7eb8  vmovaps xmm4, [rsp+0x40]
0000710a0d1d7ebe  vmovaps xmm5, [rsp+0x50]
0000710a0d1d7ec4  vmovaps xmm6, [rsp+0x60]
0000710a0d1d7eca  vmovaps xmm7, [rsp+0x70]
0000710a0d1d7ed0  vmovaps xmm8, [rsp+0x80]
0000710a0d1d7ed9  vmovaps xmm9, [rsp+0x90]
0000710a0d1d7ee2  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d7eeb  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d7ef4  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d7efd  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d7f06  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d7f0f  add rsp, 0xF0
0000710a0d1d7f16  pop r11
0000710a0d1d7f18  pop r10
0000710a0d1d7f1a  pop r9
0000710a0d1d7f1c  pop r8
0000710a0d1d7f1e  pop rsi
0000710a0d1d7f1f  pop rdi
0000710a0d1d7f20  pop rdx
0000710a0d1d7f21  pop rcx
0000710a0d1d7f22  pop rax
0000710a0d1d7f23  add rsp, 0x08
0000710a0d1d7f27  jmp 0x0000710A0D1D68CB
0000710a0d1d7f2c  sub rsp, 0x08
0000710a0d1d7f30  push rax
0000710a0d1d7f31  push rcx
0000710a0d1d7f32  push rdx
0000710a0d1d7f33  push rdi
0000710a0d1d7f34  push rsi
0000710a0d1d7f35  push r8
0000710a0d1d7f37  push r9
0000710a0d1d7f39  push r10
0000710a0d1d7f3b  push r11
0000710a0d1d7f3d  sub rsp, 0xF0
0000710a0d1d7f44  vmovaps [rsp], xmm0
0000710a0d1d7f49  vmovaps [rsp+0x10], xmm1
0000710a0d1d7f4f  vmovaps [rsp+0x20], xmm2
0000710a0d1d7f55  vmovaps [rsp+0x30], xmm3
0000710a0d1d7f5b  vmovaps [rsp+0x40], xmm4
0000710a0d1d7f61  vmovaps [rsp+0x50], xmm5
0000710a0d1d7f67  vmovaps [rsp+0x60], xmm6
0000710a0d1d7f6d  vmovaps [rsp+0x70], xmm7
0000710a0d1d7f73  vmovaps [rsp+0x80], xmm8
0000710a0d1d7f7c  vmovaps [rsp+0x90], xmm9
0000710a0d1d7f85  vmovaps [rsp+0xA0], xmm11
0000710a0d1d7f8e  vmovaps [rsp+0xB0], xmm12
0000710a0d1d7f97  vmovaps [rsp+0xC0], xmm13
0000710a0d1d7fa0  vmovaps [rsp+0xD0], xmm14
0000710a0d1d7fa9  vmovaps [rsp+0xE0], xmm15
0000710a0d1d7fb2  sub rsp, 0x40
0000710a0d1d7fb6  lea rdi, [rsp]
0000710a0d1d7fba  lea rsi, [rsp+0x10]
0000710a0d1d7fbf  lea rdx, [rsp+0x20]
0000710a0d1d7fc4  lea rcx, [rsp+0x30]
0000710a0d1d7fc9  mov r8d, 0x00
0000710a0d1d7fcf  lea r9, [r15+0x3A8]
0000710a0d1d7fd6  movaps [rdi], xmm10
0000710a0d1d7fda  movaps [rsi], xmm9
0000710a0d1d7fde  movaps [rdx], xmm7
0000710a0d1d7fe1  movaps [rcx], xmm14
0000710a0d1d7fe5  mov rax, 0x64F334B05A50
0000710a0d1d7fef  call rax
0000710a0d1d7ff1  movaps xmm10, [rsp]
0000710a0d1d7ff6  add rsp, 0x40
0000710a0d1d7ffa  vmovaps xmm0, [rsp]
0000710a0d1d7fff  vmovaps xmm1, [rsp+0x10]
0000710a0d1d8005  vmovaps xmm2, [rsp+0x20]
0000710a0d1d800b  vmovaps xmm3, [rsp+0x30]
0000710a0d1d8011  vmovaps xmm4, [rsp+0x40]
0000710a0d1d8017  vmovaps xmm5, [rsp+0x50]
0000710a0d1d801d  vmovaps xmm6, [rsp+0x60]
0000710a0d1d8023  vmovaps xmm7, [rsp+0x70]
0000710a0d1d8029  vmovaps xmm8, [rsp+0x80]
0000710a0d1d8032  vmovaps xmm9, [rsp+0x90]
0000710a0d1d803b  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d8044  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d804d  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d8056  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d805f  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d8068  add rsp, 0xF0
0000710a0d1d806f  pop r11
0000710a0d1d8071  pop r10
0000710a0d1d8073  pop r9
0000710a0d1d8075  pop r8
0000710a0d1d8077  pop rsi
0000710a0d1d8078  pop rdi
0000710a0d1d8079  pop rdx
0000710a0d1d807a  pop rcx
0000710a0d1d807b  pop rax
0000710a0d1d807c  add rsp, 0x08
0000710a0d1d8080  jmp 0x0000710A0D1D68F1
0000710a0d1d8085  call 0x0000710A0D0E45A0
0000710a0d1d808a  jmp 0x0000710A0D1D68FE
0000710a0d1d808f  sub rsp, 0x08
0000710a0d1d8093  push rax
0000710a0d1d8094  push rcx
0000710a0d1d8095  push rdx
0000710a0d1d8096  push rdi
0000710a0d1d8097  push rsi
0000710a0d1d8098  push r8
0000710a0d1d809a  push r9
0000710a0d1d809c  push r10
0000710a0d1d809e  push r11
0000710a0d1d80a0  sub rsp, 0xF0
0000710a0d1d80a7  vmovaps [rsp], xmm0
0000710a0d1d80ac  vmovaps [rsp+0x10], xmm1
0000710a0d1d80b2  vmovaps [rsp+0x20], xmm2
0000710a0d1d80b8  vmovaps [rsp+0x30], xmm3
0000710a0d1d80be  vmovaps [rsp+0x40], xmm4
0000710a0d1d80c4  vmovaps [rsp+0x50], xmm6
0000710a0d1d80ca  vmovaps [rsp+0x60], xmm7
0000710a0d1d80d0  vmovaps [rsp+0x70], xmm8
0000710a0d1d80d6  vmovaps [rsp+0x80], xmm9
0000710a0d1d80df  vmovaps [rsp+0x90], xmm10
0000710a0d1d80e8  vmovaps [rsp+0xA0], xmm11
0000710a0d1d80f1  vmovaps [rsp+0xB0], xmm12
0000710a0d1d80fa  vmovaps [rsp+0xC0], xmm13
0000710a0d1d8103  vmovaps [rsp+0xD0], xmm14
0000710a0d1d810c  vmovaps [rsp+0xE0], xmm15
0000710a0d1d8115  sub rsp, 0x40
0000710a0d1d8119  lea rdi, [rsp]
0000710a0d1d811d  lea rsi, [rsp+0x10]
0000710a0d1d8122  lea rdx, [rsp+0x20]
0000710a0d1d8127  lea rcx, [rsp+0x30]
0000710a0d1d812c  mov r8d, 0x00
0000710a0d1d8132  lea r9, [r15+0x3A8]
0000710a0d1d8139  movaps [rdi], xmm5
0000710a0d1d813c  movaps [rsi], xmm6
0000710a0d1d813f  movaps [rdx], xmm7
0000710a0d1d8142  movaps [rcx], xmm9
0000710a0d1d8146  mov rax, 0x64F334B05A50
0000710a0d1d8150  call rax
0000710a0d1d8152  movaps xmm5, [rsp]
0000710a0d1d8156  add rsp, 0x40
0000710a0d1d815a  vmovaps xmm0, [rsp]
0000710a0d1d815f  vmovaps xmm1, [rsp+0x10]
0000710a0d1d8165  vmovaps xmm2, [rsp+0x20]
0000710a0d1d816b  vmovaps xmm3, [rsp+0x30]
0000710a0d1d8171  vmovaps xmm4, [rsp+0x40]
0000710a0d1d8177  vmovaps xmm6, [rsp+0x50]
0000710a0d1d817d  vmovaps xmm7, [rsp+0x60]
0000710a0d1d8183  vmovaps xmm8, [rsp+0x70]
0000710a0d1d8189  vmovaps xmm9, [rsp+0x80]
0000710a0d1d8192  vmovaps xmm10, [rsp+0x90]
0000710a0d1d819b  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d81a4  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d81ad  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d81b6  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d81bf  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d81c8  add rsp, 0xF0
0000710a0d1d81cf  pop r11
0000710a0d1d81d1  pop r10
0000710a0d1d81d3  pop r9
0000710a0d1d81d5  pop r8
0000710a0d1d81d7  pop rsi
0000710a0d1d81d8  pop rdi
0000710a0d1d81d9  pop rdx
0000710a0d1d81da  pop rcx
0000710a0d1d81db  pop rax
0000710a0d1d81dc  add rsp, 0x08
0000710a0d1d81e0  jmp 0x0000710A0D1D6930
0000710a0d1d81e5  sub rsp, 0x08
0000710a0d1d81e9  push rax
0000710a0d1d81ea  push rcx
0000710a0d1d81eb  push rdx
0000710a0d1d81ec  push rdi
0000710a0d1d81ed  push rsi
0000710a0d1d81ee  push r8
0000710a0d1d81f0  push r9
0000710a0d1d81f2  push r10
0000710a0d1d81f4  push r11
0000710a0d1d81f6  sub rsp, 0xF0
0000710a0d1d81fd  vmovaps [rsp], xmm0
0000710a0d1d8202  vmovaps [rsp+0x10], xmm1
0000710a0d1d8208  vmovaps [rsp+0x20], xmm2
0000710a0d1d820e  vmovaps [rsp+0x30], xmm3
0000710a0d1d8214  vmovaps [rsp+0x40], xmm4
0000710a0d1d821a  vmovaps [rsp+0x50], xmm5
0000710a0d1d8220  vmovaps [rsp+0x60], xmm6
0000710a0d1d8226  vmovaps [rsp+0x70], xmm8
0000710a0d1d822c  vmovaps [rsp+0x80], xmm9
0000710a0d1d8235  vmovaps [rsp+0x90], xmm10
0000710a0d1d823e  vmovaps [rsp+0xA0], xmm11
0000710a0d1d8247  vmovaps [rsp+0xB0], xmm12
0000710a0d1d8250  vmovaps [rsp+0xC0], xmm13
0000710a0d1d8259  vmovaps [rsp+0xD0], xmm14
0000710a0d1d8262  vmovaps [rsp+0xE0], xmm15
0000710a0d1d826b  sub rsp, 0x40
0000710a0d1d826f  lea rdi, [rsp]
0000710a0d1d8273  lea rsi, [rsp+0x10]
0000710a0d1d8278  lea rdx, [rsp+0x20]
0000710a0d1d827d  lea rcx, [rsp+0x30]
0000710a0d1d8282  mov r8d, 0x00
0000710a0d1d8288  lea r9, [r15+0x3A8]
0000710a0d1d828f  movaps [rdi], xmm7
0000710a0d1d8292  movaps [rsi], xmm13
0000710a0d1d8296  movaps [rdx], xmm1
0000710a0d1d8299  movaps [rcx], xmm9
0000710a0d1d829d  mov rax, 0x64F334B05A50
0000710a0d1d82a7  call rax
0000710a0d1d82a9  movaps xmm7, [rsp]
0000710a0d1d82ad  add rsp, 0x40
0000710a0d1d82b1  vmovaps xmm0, [rsp]
0000710a0d1d82b6  vmovaps xmm1, [rsp+0x10]
0000710a0d1d82bc  vmovaps xmm2, [rsp+0x20]
0000710a0d1d82c2  vmovaps xmm3, [rsp+0x30]
0000710a0d1d82c8  vmovaps xmm4, [rsp+0x40]
0000710a0d1d82ce  vmovaps xmm5, [rsp+0x50]
0000710a0d1d82d4  vmovaps xmm6, [rsp+0x60]
0000710a0d1d82da  vmovaps xmm8, [rsp+0x70]
0000710a0d1d82e0  vmovaps xmm9, [rsp+0x80]
0000710a0d1d82e9  vmovaps xmm10, [rsp+0x90]
0000710a0d1d82f2  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d82fb  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d8304  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d830d  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d8316  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d831f  add rsp, 0xF0
0000710a0d1d8326  pop r11
0000710a0d1d8328  pop r10
0000710a0d1d832a  pop r9
0000710a0d1d832c  pop r8
0000710a0d1d832e  pop rsi
0000710a0d1d832f  pop rdi
0000710a0d1d8330  pop rdx
0000710a0d1d8331  pop rcx
0000710a0d1d8332  pop rax
0000710a0d1d8333  add rsp, 0x08
0000710a0d1d8337  jmp 0x0000710A0D1D6955
0000710a0d1d833c  call 0x0000710A0D0E3320
0000710a0d1d8341  jmp 0x0000710A0D1D6978
0000710a0d1d8346  call 0x0000710A0D0DE950
0000710a0d1d834b  jmp 0x0000710A0D1D6982
0000710a0d1d8350  sub rsp, 0x08
0000710a0d1d8354  push rax
0000710a0d1d8355  push rcx
0000710a0d1d8356  push rdx
0000710a0d1d8357  push rdi
0000710a0d1d8358  push rsi
0000710a0d1d8359  push r8
0000710a0d1d835b  push r9
0000710a0d1d835d  push r10
0000710a0d1d835f  push r11
0000710a0d1d8361  sub rsp, 0xF0
0000710a0d1d8368  vmovaps [rsp], xmm0
0000710a0d1d836d  vmovaps [rsp+0x10], xmm1
0000710a0d1d8373  vmovaps [rsp+0x20], xmm3
0000710a0d1d8379  vmovaps [rsp+0x30], xmm4
0000710a0d1d837f  vmovaps [rsp+0x40], xmm5
0000710a0d1d8385  vmovaps [rsp+0x50], xmm6
0000710a0d1d838b  vmovaps [rsp+0x60], xmm7
0000710a0d1d8391  vmovaps [rsp+0x70], xmm8
0000710a0d1d8397  vmovaps [rsp+0x80], xmm9
0000710a0d1d83a0  vmovaps [rsp+0x90], xmm10
0000710a0d1d83a9  vmovaps [rsp+0xA0], xmm11
0000710a0d1d83b2  vmovaps [rsp+0xB0], xmm12
0000710a0d1d83bb  vmovaps [rsp+0xC0], xmm13
0000710a0d1d83c4  vmovaps [rsp+0xD0], xmm14
0000710a0d1d83cd  vmovaps [rsp+0xE0], xmm15
0000710a0d1d83d6  sub rsp, 0x40
0000710a0d1d83da  lea rdi, [rsp]
0000710a0d1d83de  lea rsi, [rsp+0x10]
0000710a0d1d83e3  lea rdx, [rsp+0x20]
0000710a0d1d83e8  lea rcx, [rsp+0x30]
0000710a0d1d83ed  mov r8d, 0x00
0000710a0d1d83f3  lea r9, [r15+0x3A8]
0000710a0d1d83fa  movaps [rdi], xmm2
0000710a0d1d83fd  movaps [rsi], xmm12
0000710a0d1d8401  movaps [rdx], xmm6
0000710a0d1d8404  movaps [rcx], xmm3
0000710a0d1d8407  mov rax, 0x64F334B05A50
0000710a0d1d8411  call rax
0000710a0d1d8413  movaps xmm2, [rsp]
0000710a0d1d8417  add rsp, 0x40
0000710a0d1d841b  vmovaps xmm0, [rsp]
0000710a0d1d8420  vmovaps xmm1, [rsp+0x10]
0000710a0d1d8426  vmovaps xmm3, [rsp+0x20]
0000710a0d1d842c  vmovaps xmm4, [rsp+0x30]
0000710a0d1d8432  vmovaps xmm5, [rsp+0x40]
0000710a0d1d8438  vmovaps xmm6, [rsp+0x50]
0000710a0d1d843e  vmovaps xmm7, [rsp+0x60]
0000710a0d1d8444  vmovaps xmm8, [rsp+0x70]
0000710a0d1d844a  vmovaps xmm9, [rsp+0x80]
0000710a0d1d8453  vmovaps xmm10, [rsp+0x90]
0000710a0d1d845c  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d8465  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d846e  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d8477  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d8480  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d8489  add rsp, 0xF0
0000710a0d1d8490  pop r11
0000710a0d1d8492  pop r10
0000710a0d1d8494  pop r9
0000710a0d1d8496  pop r8
0000710a0d1d8498  pop rsi
0000710a0d1d8499  pop rdi
0000710a0d1d849a  pop rdx
0000710a0d1d849b  pop rcx
0000710a0d1d849c  pop rax
0000710a0d1d849d  add rsp, 0x08
0000710a0d1d84a1  jmp 0x0000710A0D1D69C8
0000710a0d1d84a6  sub rsp, 0x08
0000710a0d1d84aa  push rax
0000710a0d1d84ab  push rcx
0000710a0d1d84ac  push rdx
0000710a0d1d84ad  push rdi
0000710a0d1d84ae  push rsi
0000710a0d1d84af  push r8
0000710a0d1d84b1  push r9
0000710a0d1d84b3  push r10
0000710a0d1d84b5  push r11
0000710a0d1d84b7  sub rsp, 0xF0
0000710a0d1d84be  vmovaps [rsp], xmm0
0000710a0d1d84c3  vmovaps [rsp+0x10], xmm1
0000710a0d1d84c9  vmovaps [rsp+0x20], xmm2
0000710a0d1d84cf  vmovaps [rsp+0x30], xmm3
0000710a0d1d84d5  vmovaps [rsp+0x40], xmm4
0000710a0d1d84db  vmovaps [rsp+0x50], xmm5
0000710a0d1d84e1  vmovaps [rsp+0x60], xmm7
0000710a0d1d84e7  vmovaps [rsp+0x70], xmm8
0000710a0d1d84ed  vmovaps [rsp+0x80], xmm9
0000710a0d1d84f6  vmovaps [rsp+0x90], xmm10
0000710a0d1d84ff  vmovaps [rsp+0xA0], xmm11
0000710a0d1d8508  vmovaps [rsp+0xB0], xmm12
0000710a0d1d8511  vmovaps [rsp+0xC0], xmm13
0000710a0d1d851a  vmovaps [rsp+0xD0], xmm14
0000710a0d1d8523  vmovaps [rsp+0xE0], xmm15
0000710a0d1d852c  sub rsp, 0x40
0000710a0d1d8530  lea rdi, [rsp]
0000710a0d1d8534  lea rsi, [rsp+0x10]
0000710a0d1d8539  lea rdx, [rsp+0x20]
0000710a0d1d853e  lea rcx, [rsp+0x30]
0000710a0d1d8543  mov r8d, 0x00
0000710a0d1d8549  lea r9, [r15+0x3A8]
0000710a0d1d8550  movaps [rdi], xmm6
0000710a0d1d8553  movaps [rsi], xmm10
0000710a0d1d8557  movaps [rdx], xmm12
0000710a0d1d855b  movaps [rcx], xmm1
0000710a0d1d855e  mov rax, 0x64F334B05A50
0000710a0d1d8568  call rax
0000710a0d1d856a  movaps xmm6, [rsp]
0000710a0d1d856e  add rsp, 0x40
0000710a0d1d8572  vmovaps xmm0, [rsp]
0000710a0d1d8577  vmovaps xmm1, [rsp+0x10]
0000710a0d1d857d  vmovaps xmm2, [rsp+0x20]
0000710a0d1d8583  vmovaps xmm3, [rsp+0x30]
0000710a0d1d8589  vmovaps xmm4, [rsp+0x40]
0000710a0d1d858f  vmovaps xmm5, [rsp+0x50]
0000710a0d1d8595  vmovaps xmm7, [rsp+0x60]
0000710a0d1d859b  vmovaps xmm8, [rsp+0x70]
0000710a0d1d85a1  vmovaps xmm9, [rsp+0x80]
0000710a0d1d85aa  vmovaps xmm10, [rsp+0x90]
0000710a0d1d85b3  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d85bc  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d85c5  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d85ce  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d85d7  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d85e0  add rsp, 0xF0
0000710a0d1d85e7  pop r11
0000710a0d1d85e9  pop r10
0000710a0d1d85eb  pop r9
0000710a0d1d85ed  pop r8
0000710a0d1d85ef  pop rsi
0000710a0d1d85f0  pop rdi
0000710a0d1d85f1  pop rdx
0000710a0d1d85f2  pop rcx
0000710a0d1d85f3  pop rax
0000710a0d1d85f4  add rsp, 0x08
0000710a0d1d85f8  jmp 0x0000710A0D1D69F6
0000710a0d1d85fd  sub rsp, 0x08
0000710a0d1d8601  push rax
0000710a0d1d8602  push rcx
0000710a0d1d8603  push rdx
0000710a0d1d8604  push rdi
0000710a0d1d8605  push rsi
0000710a0d1d8606  push r8
0000710a0d1d8608  push r9
0000710a0d1d860a  push r10
0000710a0d1d860c  push r11
0000710a0d1d860e  sub rsp, 0xF0
0000710a0d1d8615  vmovaps [rsp], xmm0
0000710a0d1d861a  vmovaps [rsp+0x10], xmm1
0000710a0d1d8620  vmovaps [rsp+0x20], xmm2
0000710a0d1d8626  vmovaps [rsp+0x30], xmm3
0000710a0d1d862c  vmovaps [rsp+0x40], xmm4
0000710a0d1d8632  vmovaps [rsp+0x50], xmm5
0000710a0d1d8638  vmovaps [rsp+0x60], xmm6
0000710a0d1d863e  vmovaps [rsp+0x70], xmm7
0000710a0d1d8644  vmovaps [rsp+0x80], xmm8
0000710a0d1d864d  vmovaps [rsp+0x90], xmm9
0000710a0d1d8656  vmovaps [rsp+0xA0], xmm11
0000710a0d1d865f  vmovaps [rsp+0xB0], xmm12
0000710a0d1d8668  vmovaps [rsp+0xC0], xmm13
0000710a0d1d8671  vmovaps [rsp+0xD0], xmm14
0000710a0d1d867a  vmovaps [rsp+0xE0], xmm15
0000710a0d1d8683  sub rsp, 0x40
0000710a0d1d8687  lea rdi, [rsp]
0000710a0d1d868b  lea rsi, [rsp+0x10]
0000710a0d1d8690  lea rdx, [rsp+0x20]
0000710a0d1d8695  lea rcx, [rsp+0x30]
0000710a0d1d869a  mov r8d, 0x00
0000710a0d1d86a0  lea r9, [r15+0x3A8]
0000710a0d1d86a7  movaps [rdi], xmm10
0000710a0d1d86ab  movaps [rsi], xmm5
0000710a0d1d86ae  movaps [rdx], xmm12
0000710a0d1d86b2  movaps [rcx], xmm1
0000710a0d1d86b5  mov rax, 0x64F334B05A50
0000710a0d1d86bf  call rax
0000710a0d1d86c1  movaps xmm10, [rsp]
0000710a0d1d86c6  add rsp, 0x40
0000710a0d1d86ca  vmovaps xmm0, [rsp]
0000710a0d1d86cf  vmovaps xmm1, [rsp+0x10]
0000710a0d1d86d5  vmovaps xmm2, [rsp+0x20]
0000710a0d1d86db  vmovaps xmm3, [rsp+0x30]
0000710a0d1d86e1  vmovaps xmm4, [rsp+0x40]
0000710a0d1d86e7  vmovaps xmm5, [rsp+0x50]
0000710a0d1d86ed  vmovaps xmm6, [rsp+0x60]
0000710a0d1d86f3  vmovaps xmm7, [rsp+0x70]
0000710a0d1d86f9  vmovaps xmm8, [rsp+0x80]
0000710a0d1d8702  vmovaps xmm9, [rsp+0x90]
0000710a0d1d870b  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d8714  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d871d  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d8726  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d872f  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d8738  add rsp, 0xF0
0000710a0d1d873f  pop r11
0000710a0d1d8741  pop r10
0000710a0d1d8743  pop r9
0000710a0d1d8745  pop r8
0000710a0d1d8747  pop rsi
0000710a0d1d8748  pop rdi
0000710a0d1d8749  pop rdx
0000710a0d1d874a  pop rcx
0000710a0d1d874b  pop rax
0000710a0d1d874c  add rsp, 0x08
0000710a0d1d8750  jmp 0x0000710A0D1D6A25
0000710a0d1d8755  sub rsp, 0x08
0000710a0d1d8759  push rax
0000710a0d1d875a  push rcx
0000710a0d1d875b  push rdx
0000710a0d1d875c  push rdi
0000710a0d1d875d  push rsi
0000710a0d1d875e  push r8
0000710a0d1d8760  push r9
0000710a0d1d8762  push r10
0000710a0d1d8764  push r11
0000710a0d1d8766  sub rsp, 0xF0
0000710a0d1d876d  vmovaps [rsp], xmm0
0000710a0d1d8772  vmovaps [rsp+0x10], xmm1
0000710a0d1d8778  vmovaps [rsp+0x20], xmm2
0000710a0d1d877e  vmovaps [rsp+0x30], xmm3
0000710a0d1d8784  vmovaps [rsp+0x40], xmm4
0000710a0d1d878a  vmovaps [rsp+0x50], xmm5
0000710a0d1d8790  vmovaps [rsp+0x60], xmm6
0000710a0d1d8796  vmovaps [rsp+0x70], xmm7
0000710a0d1d879c  vmovaps [rsp+0x80], xmm8
0000710a0d1d87a5  vmovaps [rsp+0x90], xmm9
0000710a0d1d87ae  vmovaps [rsp+0xA0], xmm10
0000710a0d1d87b7  vmovaps [rsp+0xB0], xmm11
0000710a0d1d87c0  vmovaps [rsp+0xC0], xmm13
0000710a0d1d87c9  vmovaps [rsp+0xD0], xmm14
0000710a0d1d87d2  vmovaps [rsp+0xE0], xmm15
0000710a0d1d87db  sub rsp, 0x40
0000710a0d1d87df  lea rdi, [rsp]
0000710a0d1d87e3  lea rsi, [rsp+0x10]
0000710a0d1d87e8  lea rdx, [rsp+0x20]
0000710a0d1d87ed  lea rcx, [rsp+0x30]
0000710a0d1d87f2  mov r8d, 0x00
0000710a0d1d87f8  lea r9, [r15+0x3A8]
0000710a0d1d87ff  movaps [rdi], xmm12
0000710a0d1d8803  movaps [rsi], xmm7
0000710a0d1d8806  movaps [rdx], xmm15
0000710a0d1d880a  movaps [rcx], xmm1
0000710a0d1d880d  mov rax, 0x64F334B05A50
0000710a0d1d8817  call rax
0000710a0d1d8819  movaps xmm12, [rsp]
0000710a0d1d881e  add rsp, 0x40
0000710a0d1d8822  vmovaps xmm0, [rsp]
0000710a0d1d8827  vmovaps xmm1, [rsp+0x10]
0000710a0d1d882d  vmovaps xmm2, [rsp+0x20]
0000710a0d1d8833  vmovaps xmm3, [rsp+0x30]
0000710a0d1d8839  vmovaps xmm4, [rsp+0x40]
0000710a0d1d883f  vmovaps xmm5, [rsp+0x50]
0000710a0d1d8845  vmovaps xmm6, [rsp+0x60]
0000710a0d1d884b  vmovaps xmm7, [rsp+0x70]
0000710a0d1d8851  vmovaps xmm8, [rsp+0x80]
0000710a0d1d885a  vmovaps xmm9, [rsp+0x90]
0000710a0d1d8863  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d886c  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d8875  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d887e  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d8887  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d8890  add rsp, 0xF0
0000710a0d1d8897  pop r11
0000710a0d1d8899  pop r10
0000710a0d1d889b  pop r9
0000710a0d1d889d  pop r8
0000710a0d1d889f  pop rsi
0000710a0d1d88a0  pop rdi
0000710a0d1d88a1  pop rdx
0000710a0d1d88a2  pop rcx
0000710a0d1d88a3  pop rax
0000710a0d1d88a4  add rsp, 0x08
0000710a0d1d88a8  jmp 0x0000710A0D1D6A4E
0000710a0d1d88ad  call 0x0000710A0D0D64F0
0000710a0d1d88b2  jmp 0x0000710A0D1D6A58
0000710a0d1d88b7  call 0x0000710A0D0E5820
0000710a0d1d88bc  jmp 0x0000710A0D1D6A62
0000710a0d1d88c1  sub rsp, 0x08
0000710a0d1d88c5  push rax
0000710a0d1d88c6  push rcx
0000710a0d1d88c7  push rdx
0000710a0d1d88c8  push rdi
0000710a0d1d88c9  push rsi
0000710a0d1d88ca  push r8
0000710a0d1d88cc  push r9
0000710a0d1d88ce  push r10
0000710a0d1d88d0  push r11
0000710a0d1d88d2  sub rsp, 0xF0
0000710a0d1d88d9  vmovaps [rsp], xmm0
0000710a0d1d88de  vmovaps [rsp+0x10], xmm1
0000710a0d1d88e4  vmovaps [rsp+0x20], xmm2
0000710a0d1d88ea  vmovaps [rsp+0x30], xmm3
0000710a0d1d88f0  vmovaps [rsp+0x40], xmm4
0000710a0d1d88f6  vmovaps [rsp+0x50], xmm5
0000710a0d1d88fc  vmovaps [rsp+0x60], xmm6
0000710a0d1d8902  vmovaps [rsp+0x70], xmm8
0000710a0d1d8908  vmovaps [rsp+0x80], xmm9
0000710a0d1d8911  vmovaps [rsp+0x90], xmm10
0000710a0d1d891a  vmovaps [rsp+0xA0], xmm11
0000710a0d1d8923  vmovaps [rsp+0xB0], xmm12
0000710a0d1d892c  vmovaps [rsp+0xC0], xmm13
0000710a0d1d8935  vmovaps [rsp+0xD0], xmm14
0000710a0d1d893e  vmovaps [rsp+0xE0], xmm15
0000710a0d1d8947  sub rsp, 0x40
0000710a0d1d894b  lea rdi, [rsp]
0000710a0d1d894f  lea rsi, [rsp+0x10]
0000710a0d1d8954  lea rdx, [rsp+0x20]
0000710a0d1d8959  lea rcx, [rsp+0x30]
0000710a0d1d895e  mov r8d, 0x00
0000710a0d1d8964  lea r9, [r15+0x3A8]
0000710a0d1d896b  movaps [rdi], xmm7
0000710a0d1d896e  movaps [rsi], xmm2
0000710a0d1d8971  movaps [rdx], xmm9
0000710a0d1d8975  movaps [rcx], xmm11
0000710a0d1d8979  mov rax, 0x64F334B05A50
0000710a0d1d8983  call rax
0000710a0d1d8985  movaps xmm7, [rsp]
0000710a0d1d8989  add rsp, 0x40
0000710a0d1d898d  vmovaps xmm0, [rsp]
0000710a0d1d8992  vmovaps xmm1, [rsp+0x10]
0000710a0d1d8998  vmovaps xmm2, [rsp+0x20]
0000710a0d1d899e  vmovaps xmm3, [rsp+0x30]
0000710a0d1d89a4  vmovaps xmm4, [rsp+0x40]
0000710a0d1d89aa  vmovaps xmm5, [rsp+0x50]
0000710a0d1d89b0  vmovaps xmm6, [rsp+0x60]
0000710a0d1d89b6  vmovaps xmm8, [rsp+0x70]
0000710a0d1d89bc  vmovaps xmm9, [rsp+0x80]
0000710a0d1d89c5  vmovaps xmm10, [rsp+0x90]
0000710a0d1d89ce  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d89d7  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d89e0  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d89e9  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d89f2  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d89fb  add rsp, 0xF0
0000710a0d1d8a02  pop r11
0000710a0d1d8a04  pop r10
0000710a0d1d8a06  pop r9
0000710a0d1d8a08  pop r8
0000710a0d1d8a0a  pop rsi
0000710a0d1d8a0b  pop rdi
0000710a0d1d8a0c  pop rdx
0000710a0d1d8a0d  pop rcx
0000710a0d1d8a0e  pop rax
0000710a0d1d8a0f  add rsp, 0x08
0000710a0d1d8a13  jmp 0x0000710A0D1D6A96
0000710a0d1d8a18  sub rsp, 0x08
0000710a0d1d8a1c  push rax
0000710a0d1d8a1d  push rcx
0000710a0d1d8a1e  push rdx
0000710a0d1d8a1f  push rdi
0000710a0d1d8a20  push rsi
0000710a0d1d8a21  push r8
0000710a0d1d8a23  push r9
0000710a0d1d8a25  push r10
0000710a0d1d8a27  push r11
0000710a0d1d8a29  sub rsp, 0xF0
0000710a0d1d8a30  vmovaps [rsp], xmm0
0000710a0d1d8a35  vmovaps [rsp+0x10], xmm1
0000710a0d1d8a3b  vmovaps [rsp+0x20], xmm2
0000710a0d1d8a41  vmovaps [rsp+0x30], xmm3
0000710a0d1d8a47  vmovaps [rsp+0x40], xmm4
0000710a0d1d8a4d  vmovaps [rsp+0x50], xmm5
0000710a0d1d8a53  vmovaps [rsp+0x60], xmm6
0000710a0d1d8a59  vmovaps [rsp+0x70], xmm7
0000710a0d1d8a5f  vmovaps [rsp+0x80], xmm8
0000710a0d1d8a68  vmovaps [rsp+0x90], xmm10
0000710a0d1d8a71  vmovaps [rsp+0xA0], xmm11
0000710a0d1d8a7a  vmovaps [rsp+0xB0], xmm12
0000710a0d1d8a83  vmovaps [rsp+0xC0], xmm13
0000710a0d1d8a8c  vmovaps [rsp+0xD0], xmm14
0000710a0d1d8a95  vmovaps [rsp+0xE0], xmm15
0000710a0d1d8a9e  sub rsp, 0x40
0000710a0d1d8aa2  lea rdi, [rsp]
0000710a0d1d8aa6  lea rsi, [rsp+0x10]
0000710a0d1d8aab  lea rdx, [rsp+0x20]
0000710a0d1d8ab0  lea rcx, [rsp+0x30]
0000710a0d1d8ab5  mov r8d, 0x00
0000710a0d1d8abb  lea r9, [r15+0x3A8]
0000710a0d1d8ac2  movaps [rdi], xmm9
0000710a0d1d8ac6  movaps [rsi], xmm6
0000710a0d1d8ac9  movaps [rdx], xmm1
0000710a0d1d8acc  movaps [rcx], xmm11
0000710a0d1d8ad0  mov rax, 0x64F334B05A50
0000710a0d1d8ada  call rax
0000710a0d1d8adc  movaps xmm9, [rsp]
0000710a0d1d8ae1  add rsp, 0x40
0000710a0d1d8ae5  vmovaps xmm0, [rsp]
0000710a0d1d8aea  vmovaps xmm1, [rsp+0x10]
0000710a0d1d8af0  vmovaps xmm2, [rsp+0x20]
0000710a0d1d8af6  vmovaps xmm3, [rsp+0x30]
0000710a0d1d8afc  vmovaps xmm4, [rsp+0x40]
0000710a0d1d8b02  vmovaps xmm5, [rsp+0x50]
0000710a0d1d8b08  vmovaps xmm6, [rsp+0x60]
0000710a0d1d8b0e  vmovaps xmm7, [rsp+0x70]
0000710a0d1d8b14  vmovaps xmm8, [rsp+0x80]
0000710a0d1d8b1d  vmovaps xmm10, [rsp+0x90]
0000710a0d1d8b26  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d8b2f  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d8b38  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d8b41  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d8b4a  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d8b53  add rsp, 0xF0
0000710a0d1d8b5a  pop r11
0000710a0d1d8b5c  pop r10
0000710a0d1d8b5e  pop r9
0000710a0d1d8b60  pop r8
0000710a0d1d8b62  pop rsi
0000710a0d1d8b63  pop rdi
0000710a0d1d8b64  pop rdx
0000710a0d1d8b65  pop rcx
0000710a0d1d8b66  pop rax
0000710a0d1d8b67  add rsp, 0x08
0000710a0d1d8b6b  jmp 0x0000710A0D1D6ABC
0000710a0d1d8b70  sub rsp, 0x08
0000710a0d1d8b74  push rax
0000710a0d1d8b75  push rcx
0000710a0d1d8b76  push rdx
0000710a0d1d8b77  push rdi
0000710a0d1d8b78  push rsi
0000710a0d1d8b79  push r8
0000710a0d1d8b7b  push r9
0000710a0d1d8b7d  push r10
0000710a0d1d8b7f  push r11
0000710a0d1d8b81  sub rsp, 0xF0
0000710a0d1d8b88  vmovaps [rsp], xmm0
0000710a0d1d8b8d  vmovaps [rsp+0x10], xmm1
0000710a0d1d8b93  vmovaps [rsp+0x20], xmm2
0000710a0d1d8b99  vmovaps [rsp+0x30], xmm3
0000710a0d1d8b9f  vmovaps [rsp+0x40], xmm4
0000710a0d1d8ba5  vmovaps [rsp+0x50], xmm5
0000710a0d1d8bab  vmovaps [rsp+0x60], xmm6
0000710a0d1d8bb1  vmovaps [rsp+0x70], xmm7
0000710a0d1d8bb7  vmovaps [rsp+0x80], xmm8
0000710a0d1d8bc0  vmovaps [rsp+0x90], xmm9
0000710a0d1d8bc9  vmovaps [rsp+0xA0], xmm10
0000710a0d1d8bd2  vmovaps [rsp+0xB0], xmm12
0000710a0d1d8bdb  vmovaps [rsp+0xC0], xmm13
0000710a0d1d8be4  vmovaps [rsp+0xD0], xmm14
0000710a0d1d8bed  vmovaps [rsp+0xE0], xmm15
0000710a0d1d8bf6  sub rsp, 0x40
0000710a0d1d8bfa  lea rdi, [rsp]
0000710a0d1d8bfe  lea rsi, [rsp+0x10]
0000710a0d1d8c03  lea rdx, [rsp+0x20]
0000710a0d1d8c08  lea rcx, [rsp+0x30]
0000710a0d1d8c0d  mov r8d, 0x00
0000710a0d1d8c13  lea r9, [r15+0x3A8]
0000710a0d1d8c1a  movaps [rdi], xmm11
0000710a0d1d8c1e  movaps [rsi], xmm10
0000710a0d1d8c22  movaps [rdx], xmm8
0000710a0d1d8c26  movaps [rcx], xmm1
0000710a0d1d8c29  mov rax, 0x64F334B05A50
0000710a0d1d8c33  call rax
0000710a0d1d8c35  movaps xmm11, [rsp]
0000710a0d1d8c3a  add rsp, 0x40
0000710a0d1d8c3e  vmovaps xmm0, [rsp]
0000710a0d1d8c43  vmovaps xmm1, [rsp+0x10]
0000710a0d1d8c49  vmovaps xmm2, [rsp+0x20]
0000710a0d1d8c4f  vmovaps xmm3, [rsp+0x30]
0000710a0d1d8c55  vmovaps xmm4, [rsp+0x40]
0000710a0d1d8c5b  vmovaps xmm5, [rsp+0x50]
0000710a0d1d8c61  vmovaps xmm6, [rsp+0x60]
0000710a0d1d8c67  vmovaps xmm7, [rsp+0x70]
0000710a0d1d8c6d  vmovaps xmm8, [rsp+0x80]
0000710a0d1d8c76  vmovaps xmm9, [rsp+0x90]
0000710a0d1d8c7f  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d8c88  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d8c91  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d8c9a  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d8ca3  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d8cac  add rsp, 0xF0
0000710a0d1d8cb3  pop r11
0000710a0d1d8cb5  pop r10
0000710a0d1d8cb7  pop r9
0000710a0d1d8cb9  pop r8
0000710a0d1d8cbb  pop rsi
0000710a0d1d8cbc  pop rdi
0000710a0d1d8cbd  pop rdx
0000710a0d1d8cbe  pop rcx
0000710a0d1d8cbf  pop rax
0000710a0d1d8cc0  add rsp, 0x08
0000710a0d1d8cc4  jmp 0x0000710A0D1D6AE2
0000710a0d1d8cc9  sub rsp, 0x08
0000710a0d1d8ccd  push rax
0000710a0d1d8cce  push rcx
0000710a0d1d8ccf  push rdx
0000710a0d1d8cd0  push rdi
0000710a0d1d8cd1  push rsi
0000710a0d1d8cd2  push r8
0000710a0d1d8cd4  push r9
0000710a0d1d8cd6  push r10
0000710a0d1d8cd8  push r11
0000710a0d1d8cda  sub rsp, 0xF0
0000710a0d1d8ce1  vmovaps [rsp], xmm0
0000710a0d1d8ce6  vmovaps [rsp+0x10], xmm1
0000710a0d1d8cec  vmovaps [rsp+0x20], xmm2
0000710a0d1d8cf2  vmovaps [rsp+0x30], xmm3
0000710a0d1d8cf8  vmovaps [rsp+0x40], xmm4
0000710a0d1d8cfe  vmovaps [rsp+0x50], xmm5
0000710a0d1d8d04  vmovaps [rsp+0x60], xmm6
0000710a0d1d8d0a  vmovaps [rsp+0x70], xmm7
0000710a0d1d8d10  vmovaps [rsp+0x80], xmm8
0000710a0d1d8d19  vmovaps [rsp+0x90], xmm9
0000710a0d1d8d22  vmovaps [rsp+0xA0], xmm11
0000710a0d1d8d2b  vmovaps [rsp+0xB0], xmm12
0000710a0d1d8d34  vmovaps [rsp+0xC0], xmm13
0000710a0d1d8d3d  vmovaps [rsp+0xD0], xmm14
0000710a0d1d8d46  vmovaps [rsp+0xE0], xmm15
0000710a0d1d8d4f  sub rsp, 0x40
0000710a0d1d8d53  lea rdi, [rsp]
0000710a0d1d8d57  lea rsi, [rsp+0x10]
0000710a0d1d8d5c  lea rdx, [rsp+0x20]
0000710a0d1d8d61  lea rcx, [rsp+0x30]
0000710a0d1d8d66  mov r8d, 0x00
0000710a0d1d8d6c  lea r9, [r15+0x3A8]
0000710a0d1d8d73  movaps [rdi], xmm10
0000710a0d1d8d77  movaps [rsi], xmm12
0000710a0d1d8d7b  movaps [rdx], xmm13
0000710a0d1d8d7f  movaps [rcx], xmm1
0000710a0d1d8d82  mov rax, 0x64F334B05A50
0000710a0d1d8d8c  call rax
0000710a0d1d8d8e  movaps xmm10, [rsp]
0000710a0d1d8d93  add rsp, 0x40
0000710a0d1d8d97  vmovaps xmm0, [rsp]
0000710a0d1d8d9c  vmovaps xmm1, [rsp+0x10]
0000710a0d1d8da2  vmovaps xmm2, [rsp+0x20]
0000710a0d1d8da8  vmovaps xmm3, [rsp+0x30]
0000710a0d1d8dae  vmovaps xmm4, [rsp+0x40]
0000710a0d1d8db4  vmovaps xmm5, [rsp+0x50]
0000710a0d1d8dba  vmovaps xmm6, [rsp+0x60]
0000710a0d1d8dc0  vmovaps xmm7, [rsp+0x70]
0000710a0d1d8dc6  vmovaps xmm8, [rsp+0x80]
0000710a0d1d8dcf  vmovaps xmm9, [rsp+0x90]
0000710a0d1d8dd8  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d8de1  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d8dea  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d8df3  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d8dfc  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d8e05  add rsp, 0xF0
0000710a0d1d8e0c  pop r11
0000710a0d1d8e0e  pop r10
0000710a0d1d8e10  pop r9
0000710a0d1d8e12  pop r8
0000710a0d1d8e14  pop rsi
0000710a0d1d8e15  pop rdi
0000710a0d1d8e16  pop rdx
0000710a0d1d8e17  pop rcx
0000710a0d1d8e18  pop rax
0000710a0d1d8e19  add rsp, 0x08
0000710a0d1d8e1d  jmp 0x0000710A0D1D6B08
0000710a0d1d8e22  call 0x0000710A0D0D64F0
0000710a0d1d8e27  jmp 0x0000710A0D1D6B12
0000710a0d1d8e2c  call 0x0000710A0D0E3320
0000710a0d1d8e31  jmp 0x0000710A0D1D6B1C
0000710a0d1d8e36  sub rsp, 0x08
0000710a0d1d8e3a  push rax
0000710a0d1d8e3b  push rcx
0000710a0d1d8e3c  push rdx
0000710a0d1d8e3d  push rdi
0000710a0d1d8e3e  push rsi
0000710a0d1d8e3f  push r8
0000710a0d1d8e41  push r9
0000710a0d1d8e43  push r10
0000710a0d1d8e45  push r11
0000710a0d1d8e47  sub rsp, 0xF0
0000710a0d1d8e4e  vmovaps [rsp], xmm0
0000710a0d1d8e53  vmovaps [rsp+0x10], xmm1
0000710a0d1d8e59  vmovaps [rsp+0x20], xmm2
0000710a0d1d8e5f  vmovaps [rsp+0x30], xmm3
0000710a0d1d8e65  vmovaps [rsp+0x40], xmm4
0000710a0d1d8e6b  vmovaps [rsp+0x50], xmm5
0000710a0d1d8e71  vmovaps [rsp+0x60], xmm6
0000710a0d1d8e77  vmovaps [rsp+0x70], xmm7
0000710a0d1d8e7d  vmovaps [rsp+0x80], xmm9
0000710a0d1d8e86  vmovaps [rsp+0x90], xmm10
0000710a0d1d8e8f  vmovaps [rsp+0xA0], xmm11
0000710a0d1d8e98  vmovaps [rsp+0xB0], xmm12
0000710a0d1d8ea1  vmovaps [rsp+0xC0], xmm13
0000710a0d1d8eaa  vmovaps [rsp+0xD0], xmm14
0000710a0d1d8eb3  vmovaps [rsp+0xE0], xmm15
0000710a0d1d8ebc  sub rsp, 0x40
0000710a0d1d8ec0  lea rdi, [rsp]
0000710a0d1d8ec4  lea rsi, [rsp+0x10]
0000710a0d1d8ec9  lea rdx, [rsp+0x20]
0000710a0d1d8ece  lea rcx, [rsp+0x30]
0000710a0d1d8ed3  mov r8d, 0x00
0000710a0d1d8ed9  lea r9, [r15+0x3A8]
0000710a0d1d8ee0  movaps [rdi], xmm8
0000710a0d1d8ee4  movaps [rsi], xmm7
0000710a0d1d8ee7  movaps [rdx], xmm4
0000710a0d1d8eea  movaps [rcx], xmm12
0000710a0d1d8eee  mov rax, 0x64F334B05A50
0000710a0d1d8ef8  call rax
0000710a0d1d8efa  movaps xmm8, [rsp]
0000710a0d1d8eff  add rsp, 0x40
0000710a0d1d8f03  vmovaps xmm0, [rsp]
0000710a0d1d8f08  vmovaps xmm1, [rsp+0x10]
0000710a0d1d8f0e  vmovaps xmm2, [rsp+0x20]
0000710a0d1d8f14  vmovaps xmm3, [rsp+0x30]
0000710a0d1d8f1a  vmovaps xmm4, [rsp+0x40]
0000710a0d1d8f20  vmovaps xmm5, [rsp+0x50]
0000710a0d1d8f26  vmovaps xmm6, [rsp+0x60]
0000710a0d1d8f2c  vmovaps xmm7, [rsp+0x70]
0000710a0d1d8f32  vmovaps xmm9, [rsp+0x80]
0000710a0d1d8f3b  vmovaps xmm10, [rsp+0x90]
0000710a0d1d8f44  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d8f4d  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d8f56  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d8f5f  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d8f68  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d8f71  add rsp, 0xF0
0000710a0d1d8f78  pop r11
0000710a0d1d8f7a  pop r10
0000710a0d1d8f7c  pop r9
0000710a0d1d8f7e  pop r8
0000710a0d1d8f80  pop rsi
0000710a0d1d8f81  pop rdi
0000710a0d1d8f82  pop rdx
0000710a0d1d8f83  pop rcx
0000710a0d1d8f84  pop rax
0000710a0d1d8f85  add rsp, 0x08
0000710a0d1d8f89  jmp 0x0000710A0D1D6B45
0000710a0d1d8f8e  sub rsp, 0x08
0000710a0d1d8f92  push rax
0000710a0d1d8f93  push rcx
0000710a0d1d8f94  push rdx
0000710a0d1d8f95  push rdi
0000710a0d1d8f96  push rsi
0000710a0d1d8f97  push r8
0000710a0d1d8f99  push r9
0000710a0d1d8f9b  push r10
0000710a0d1d8f9d  push r11
0000710a0d1d8f9f  sub rsp, 0xF0
0000710a0d1d8fa6  vmovaps [rsp], xmm0
0000710a0d1d8fab  vmovaps [rsp+0x10], xmm1
0000710a0d1d8fb1  vmovaps [rsp+0x20], xmm2
0000710a0d1d8fb7  vmovaps [rsp+0x30], xmm3
0000710a0d1d8fbd  vmovaps [rsp+0x40], xmm4
0000710a0d1d8fc3  vmovaps [rsp+0x50], xmm5
0000710a0d1d8fc9  vmovaps [rsp+0x60], xmm6
0000710a0d1d8fcf  vmovaps [rsp+0x70], xmm8
0000710a0d1d8fd5  vmovaps [rsp+0x80], xmm9
0000710a0d1d8fde  vmovaps [rsp+0x90], xmm10
0000710a0d1d8fe7  vmovaps [rsp+0xA0], xmm11
0000710a0d1d8ff0  vmovaps [rsp+0xB0], xmm12
0000710a0d1d8ff9  vmovaps [rsp+0xC0], xmm13
0000710a0d1d9002  vmovaps [rsp+0xD0], xmm14
0000710a0d1d900b  vmovaps [rsp+0xE0], xmm15
0000710a0d1d9014  sub rsp, 0x40
0000710a0d1d9018  lea rdi, [rsp]
0000710a0d1d901c  lea rsi, [rsp+0x10]
0000710a0d1d9021  lea rdx, [rsp+0x20]
0000710a0d1d9026  lea rcx, [rsp+0x30]
0000710a0d1d902b  mov r8d, 0x00
0000710a0d1d9031  lea r9, [r15+0x3A8]
0000710a0d1d9038  movaps [rdi], xmm7
0000710a0d1d903b  movaps [rsi], xmm9
0000710a0d1d903f  movaps [rdx], xmm14
0000710a0d1d9043  movaps [rcx], xmm12
0000710a0d1d9047  mov rax, 0x64F334B05A50
0000710a0d1d9051  call rax
0000710a0d1d9053  movaps xmm7, [rsp]
0000710a0d1d9057  add rsp, 0x40
0000710a0d1d905b  vmovaps xmm0, [rsp]
0000710a0d1d9060  vmovaps xmm1, [rsp+0x10]
0000710a0d1d9066  vmovaps xmm2, [rsp+0x20]
0000710a0d1d906c  vmovaps xmm3, [rsp+0x30]
0000710a0d1d9072  vmovaps xmm4, [rsp+0x40]
0000710a0d1d9078  vmovaps xmm5, [rsp+0x50]
0000710a0d1d907e  vmovaps xmm6, [rsp+0x60]
0000710a0d1d9084  vmovaps xmm8, [rsp+0x70]
0000710a0d1d908a  vmovaps xmm9, [rsp+0x80]
0000710a0d1d9093  vmovaps xmm10, [rsp+0x90]
0000710a0d1d909c  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d90a5  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d90ae  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d90b7  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d90c0  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d90c9  add rsp, 0xF0
0000710a0d1d90d0  pop r11
0000710a0d1d90d2  pop r10
0000710a0d1d90d4  pop r9
0000710a0d1d90d6  pop r8
0000710a0d1d90d8  pop rsi
0000710a0d1d90d9  pop rdi
0000710a0d1d90da  pop rdx
0000710a0d1d90db  pop rcx
0000710a0d1d90dc  pop rax
0000710a0d1d90dd  add rsp, 0x08
0000710a0d1d90e1  jmp 0x0000710A0D1D6B6D
0000710a0d1d90e6  sub rsp, 0x08
0000710a0d1d90ea  push rax
0000710a0d1d90eb  push rcx
0000710a0d1d90ec  push rdx
0000710a0d1d90ed  push rdi
0000710a0d1d90ee  push rsi
0000710a0d1d90ef  push r8
0000710a0d1d90f1  push r9
0000710a0d1d90f3  push r10
0000710a0d1d90f5  push r11
0000710a0d1d90f7  sub rsp, 0xF0
0000710a0d1d90fe  vmovaps [rsp], xmm0
0000710a0d1d9103  vmovaps [rsp+0x10], xmm1
0000710a0d1d9109  vmovaps [rsp+0x20], xmm2
0000710a0d1d910f  vmovaps [rsp+0x30], xmm3
0000710a0d1d9115  vmovaps [rsp+0x40], xmm4
0000710a0d1d911b  vmovaps [rsp+0x50], xmm5
0000710a0d1d9121  vmovaps [rsp+0x60], xmm6
0000710a0d1d9127  vmovaps [rsp+0x70], xmm7
0000710a0d1d912d  vmovaps [rsp+0x80], xmm8
0000710a0d1d9136  vmovaps [rsp+0x90], xmm9
0000710a0d1d913f  vmovaps [rsp+0xA0], xmm10
0000710a0d1d9148  vmovaps [rsp+0xB0], xmm11
0000710a0d1d9151  vmovaps [rsp+0xC0], xmm13
0000710a0d1d915a  vmovaps [rsp+0xD0], xmm14
0000710a0d1d9163  vmovaps [rsp+0xE0], xmm15
0000710a0d1d916c  sub rsp, 0x40
0000710a0d1d9170  lea rdi, [rsp]
0000710a0d1d9174  lea rsi, [rsp+0x10]
0000710a0d1d9179  lea rdx, [rsp+0x20]
0000710a0d1d917e  lea rcx, [rsp+0x30]
0000710a0d1d9183  mov r8d, 0x00
0000710a0d1d9189  lea r9, [r15+0x3A8]
0000710a0d1d9190  movaps [rdi], xmm12
0000710a0d1d9194  movaps [rsi], xmm11
0000710a0d1d9198  movaps [rdx], xmm15
0000710a0d1d919c  movaps [rcx], xmm14
0000710a0d1d91a0  mov rax, 0x64F334B05A50
0000710a0d1d91aa  call rax
0000710a0d1d91ac  movaps xmm12, [rsp]
0000710a0d1d91b1  add rsp, 0x40
0000710a0d1d91b5  vmovaps xmm0, [rsp]
0000710a0d1d91ba  vmovaps xmm1, [rsp+0x10]
0000710a0d1d91c0  vmovaps xmm2, [rsp+0x20]
0000710a0d1d91c6  vmovaps xmm3, [rsp+0x30]
0000710a0d1d91cc  vmovaps xmm4, [rsp+0x40]
0000710a0d1d91d2  vmovaps xmm5, [rsp+0x50]
0000710a0d1d91d8  vmovaps xmm6, [rsp+0x60]
0000710a0d1d91de  vmovaps xmm7, [rsp+0x70]
0000710a0d1d91e4  vmovaps xmm8, [rsp+0x80]
0000710a0d1d91ed  vmovaps xmm9, [rsp+0x90]
0000710a0d1d91f6  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d91ff  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d9208  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d9211  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d921a  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d9223  add rsp, 0xF0
0000710a0d1d922a  pop r11
0000710a0d1d922c  pop r10
0000710a0d1d922e  pop r9
0000710a0d1d9230  pop r8
0000710a0d1d9232  pop rsi
0000710a0d1d9233  pop rdi
0000710a0d1d9234  pop rdx
0000710a0d1d9235  pop rcx
0000710a0d1d9236  pop rax
0000710a0d1d9237  add rsp, 0x08
0000710a0d1d923b  jmp 0x0000710A0D1D6B96
0000710a0d1d9240  sub rsp, 0x08
0000710a0d1d9244  push rax
0000710a0d1d9245  push rcx
0000710a0d1d9246  push rdx
0000710a0d1d9247  push rdi
0000710a0d1d9248  push rsi
0000710a0d1d9249  push r8
0000710a0d1d924b  push r9
0000710a0d1d924d  push r10
0000710a0d1d924f  push r11
0000710a0d1d9251  sub rsp, 0xF0
0000710a0d1d9258  vmovaps [rsp], xmm0
0000710a0d1d925d  vmovaps [rsp+0x10], xmm1
0000710a0d1d9263  vmovaps [rsp+0x20], xmm2
0000710a0d1d9269  vmovaps [rsp+0x30], xmm3
0000710a0d1d926f  vmovaps [rsp+0x40], xmm4
0000710a0d1d9275  vmovaps [rsp+0x50], xmm5
0000710a0d1d927b  vmovaps [rsp+0x60], xmm6
0000710a0d1d9281  vmovaps [rsp+0x70], xmm7
0000710a0d1d9287  vmovaps [rsp+0x80], xmm8
0000710a0d1d9290  vmovaps [rsp+0x90], xmm9
0000710a0d1d9299  vmovaps [rsp+0xA0], xmm10
0000710a0d1d92a2  vmovaps [rsp+0xB0], xmm12
0000710a0d1d92ab  vmovaps [rsp+0xC0], xmm13
0000710a0d1d92b4  vmovaps [rsp+0xD0], xmm14
0000710a0d1d92bd  vmovaps [rsp+0xE0], xmm15
0000710a0d1d92c6  sub rsp, 0x40
0000710a0d1d92ca  lea rdi, [rsp]
0000710a0d1d92ce  lea rsi, [rsp+0x10]
0000710a0d1d92d3  lea rdx, [rsp+0x20]
0000710a0d1d92d8  lea rcx, [rsp+0x30]
0000710a0d1d92dd  mov r8d, 0x00
0000710a0d1d92e3  lea r9, [r15+0x3A8]
0000710a0d1d92ea  movaps [rdi], xmm11
0000710a0d1d92ee  movaps [rsi], xmm10
0000710a0d1d92f2  movaps [rdx], xmm13
0000710a0d1d92f6  movaps [rcx], xmm15
0000710a0d1d92fa  mov rax, 0x64F334B05A50
0000710a0d1d9304  call rax
0000710a0d1d9306  movaps xmm11, [rsp]
0000710a0d1d930b  add rsp, 0x40
0000710a0d1d930f  vmovaps xmm0, [rsp]
0000710a0d1d9314  vmovaps xmm1, [rsp+0x10]
0000710a0d1d931a  vmovaps xmm2, [rsp+0x20]
0000710a0d1d9320  vmovaps xmm3, [rsp+0x30]
0000710a0d1d9326  vmovaps xmm4, [rsp+0x40]
0000710a0d1d932c  vmovaps xmm5, [rsp+0x50]
0000710a0d1d9332  vmovaps xmm6, [rsp+0x60]
0000710a0d1d9338  vmovaps xmm7, [rsp+0x70]
0000710a0d1d933e  vmovaps xmm8, [rsp+0x80]
0000710a0d1d9347  vmovaps xmm9, [rsp+0x90]
0000710a0d1d9350  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d9359  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d9362  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d936b  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d9374  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d937d  add rsp, 0xF0
0000710a0d1d9384  pop r11
0000710a0d1d9386  pop r10
0000710a0d1d9388  pop r9
0000710a0d1d938a  pop r8
0000710a0d1d938c  pop rsi
0000710a0d1d938d  pop rdi
0000710a0d1d938e  pop rdx
0000710a0d1d938f  pop rcx
0000710a0d1d9390  pop rax
0000710a0d1d9391  add rsp, 0x08
0000710a0d1d9395  jmp 0x0000710A0D1D6BBF
0000710a0d1d939a  call 0x0000710A0D0E5820
0000710a0d1d939f  jmp 0x0000710A0D1D6BCC
0000710a0d1d93a4  call 0x0000710A0D0E45A0
0000710a0d1d93a9  jmp 0x0000710A0D1D6BD9
0000710a0d1d93ae  sub rsp, 0x08
0000710a0d1d93b2  push rax
0000710a0d1d93b3  push rcx
0000710a0d1d93b4  push rdx
0000710a0d1d93b5  push rdi
0000710a0d1d93b6  push rsi
0000710a0d1d93b7  push r8
0000710a0d1d93b9  push r9
0000710a0d1d93bb  push r10
0000710a0d1d93bd  push r11
0000710a0d1d93bf  sub rsp, 0xF0
0000710a0d1d93c6  vmovaps [rsp], xmm0
0000710a0d1d93cb  vmovaps [rsp+0x10], xmm1
0000710a0d1d93d1  vmovaps [rsp+0x20], xmm2
0000710a0d1d93d7  vmovaps [rsp+0x30], xmm3
0000710a0d1d93dd  vmovaps [rsp+0x40], xmm4
0000710a0d1d93e3  vmovaps [rsp+0x50], xmm5
0000710a0d1d93e9  vmovaps [rsp+0x60], xmm6
0000710a0d1d93ef  vmovaps [rsp+0x70], xmm7
0000710a0d1d93f5  vmovaps [rsp+0x80], xmm8
0000710a0d1d93fe  vmovaps [rsp+0x90], xmm9
0000710a0d1d9407  vmovaps [rsp+0xA0], xmm11
0000710a0d1d9410  vmovaps [rsp+0xB0], xmm12
0000710a0d1d9419  vmovaps [rsp+0xC0], xmm13
0000710a0d1d9422  vmovaps [rsp+0xD0], xmm14
0000710a0d1d942b  vmovaps [rsp+0xE0], xmm15
0000710a0d1d9434  sub rsp, 0x40
0000710a0d1d9438  lea rdi, [rsp]
0000710a0d1d943c  lea rsi, [rsp+0x10]
0000710a0d1d9441  lea rdx, [rsp+0x20]
0000710a0d1d9446  lea rcx, [rsp+0x30]
0000710a0d1d944b  mov r8d, 0x00
0000710a0d1d9451  lea r9, [r15+0x3A8]
0000710a0d1d9458  movaps [rdi], xmm10
0000710a0d1d945c  movaps [rsi], xmm8
0000710a0d1d9460  movaps [rdx], xmm1
0000710a0d1d9463  movaps [rcx], xmm13
0000710a0d1d9467  mov rax, 0x64F334B05A50
0000710a0d1d9471  call rax
0000710a0d1d9473  movaps xmm10, [rsp]
0000710a0d1d9478  add rsp, 0x40
0000710a0d1d947c  vmovaps xmm0, [rsp]
0000710a0d1d9481  vmovaps xmm1, [rsp+0x10]
0000710a0d1d9487  vmovaps xmm2, [rsp+0x20]
0000710a0d1d948d  vmovaps xmm3, [rsp+0x30]
0000710a0d1d9493  vmovaps xmm4, [rsp+0x40]
0000710a0d1d9499  vmovaps xmm5, [rsp+0x50]
0000710a0d1d949f  vmovaps xmm6, [rsp+0x60]
0000710a0d1d94a5  vmovaps xmm7, [rsp+0x70]
0000710a0d1d94ab  vmovaps xmm8, [rsp+0x80]
0000710a0d1d94b4  vmovaps xmm9, [rsp+0x90]
0000710a0d1d94bd  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d94c6  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d94cf  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d94d8  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d94e1  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d94ea  add rsp, 0xF0
0000710a0d1d94f1  pop r11
0000710a0d1d94f3  pop r10
0000710a0d1d94f5  pop r9
0000710a0d1d94f7  pop r8
0000710a0d1d94f9  pop rsi
0000710a0d1d94fa  pop rdi
0000710a0d1d94fb  pop rdx
0000710a0d1d94fc  pop rcx
0000710a0d1d94fd  pop rax
0000710a0d1d94fe  add rsp, 0x08
0000710a0d1d9502  jmp 0x0000710A0D1D6C0F
0000710a0d1d9507  call 0x0000710A0D0D64F0
0000710a0d1d950c  jmp 0x0000710A0D1D6C21
0000710a0d1d9511  sub rsp, 0x08
0000710a0d1d9515  push rax
0000710a0d1d9516  push rcx
0000710a0d1d9517  push rdx
0000710a0d1d9518  push rdi
0000710a0d1d9519  push rsi
0000710a0d1d951a  push r8
0000710a0d1d951c  push r9
0000710a0d1d951e  push r10
0000710a0d1d9520  push r11
0000710a0d1d9522  sub rsp, 0xF0
0000710a0d1d9529  vmovaps [rsp], xmm0
0000710a0d1d952e  vmovaps [rsp+0x10], xmm1
0000710a0d1d9534  vmovaps [rsp+0x20], xmm2
0000710a0d1d953a  vmovaps [rsp+0x30], xmm3
0000710a0d1d9540  vmovaps [rsp+0x40], xmm4
0000710a0d1d9546  vmovaps [rsp+0x50], xmm5
0000710a0d1d954c  vmovaps [rsp+0x60], xmm6
0000710a0d1d9552  vmovaps [rsp+0x70], xmm7
0000710a0d1d9558  vmovaps [rsp+0x80], xmm8
0000710a0d1d9561  vmovaps [rsp+0x90], xmm10
0000710a0d1d956a  vmovaps [rsp+0xA0], xmm11
0000710a0d1d9573  vmovaps [rsp+0xB0], xmm12
0000710a0d1d957c  vmovaps [rsp+0xC0], xmm13
0000710a0d1d9585  vmovaps [rsp+0xD0], xmm14
0000710a0d1d958e  vmovaps [rsp+0xE0], xmm15
0000710a0d1d9597  sub rsp, 0x40
0000710a0d1d959b  lea rdi, [rsp]
0000710a0d1d959f  lea rsi, [rsp+0x10]
0000710a0d1d95a4  lea rdx, [rsp+0x20]
0000710a0d1d95a9  lea rcx, [rsp+0x30]
0000710a0d1d95ae  mov r8d, 0x00
0000710a0d1d95b4  lea r9, [r15+0x3A8]
0000710a0d1d95bb  movaps [rdi], xmm9
0000710a0d1d95bf  movaps [rsi], xmm7
0000710a0d1d95c2  movaps [rdx], xmm14
0000710a0d1d95c6  movaps [rcx], xmm13
0000710a0d1d95ca  mov rax, 0x64F334B05A50
0000710a0d1d95d4  call rax
0000710a0d1d95d6  movaps xmm9, [rsp]
0000710a0d1d95db  add rsp, 0x40
0000710a0d1d95df  vmovaps xmm0, [rsp]
0000710a0d1d95e4  vmovaps xmm1, [rsp+0x10]
0000710a0d1d95ea  vmovaps xmm2, [rsp+0x20]
0000710a0d1d95f0  vmovaps xmm3, [rsp+0x30]
0000710a0d1d95f6  vmovaps xmm4, [rsp+0x40]
0000710a0d1d95fc  vmovaps xmm5, [rsp+0x50]
0000710a0d1d9602  vmovaps xmm6, [rsp+0x60]
0000710a0d1d9608  vmovaps xmm7, [rsp+0x70]
0000710a0d1d960e  vmovaps xmm8, [rsp+0x80]
0000710a0d1d9617  vmovaps xmm10, [rsp+0x90]
0000710a0d1d9620  vmovaps xmm11, [rsp+0xA0]
0000710a0d1d9629  vmovaps xmm12, [rsp+0xB0]
0000710a0d1d9632  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d963b  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d9644  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d964d  add rsp, 0xF0
0000710a0d1d9654  pop r11
0000710a0d1d9656  pop r10
0000710a0d1d9658  pop r9
0000710a0d1d965a  pop r8
0000710a0d1d965c  pop rsi
0000710a0d1d965d  pop rdi
0000710a0d1d965e  pop rdx
0000710a0d1d965f  pop rcx
0000710a0d1d9660  pop rax
0000710a0d1d9661  add rsp, 0x08
0000710a0d1d9665  jmp 0x0000710A0D1D6C4F
0000710a0d1d966a  sub rsp, 0x08
0000710a0d1d966e  push rax
0000710a0d1d966f  push rcx
0000710a0d1d9670  push rdx
0000710a0d1d9671  push rdi
0000710a0d1d9672  push rsi
0000710a0d1d9673  push r8
0000710a0d1d9675  push r9
0000710a0d1d9677  push r10
0000710a0d1d9679  push r11
0000710a0d1d967b  sub rsp, 0xF0
0000710a0d1d9682  vmovaps [rsp], xmm0
0000710a0d1d9687  vmovaps [rsp+0x10], xmm1
0000710a0d1d968d  vmovaps [rsp+0x20], xmm2
0000710a0d1d9693  vmovaps [rsp+0x30], xmm3
0000710a0d1d9699  vmovaps [rsp+0x40], xmm4
0000710a0d1d969f  vmovaps [rsp+0x50], xmm5
0000710a0d1d96a5  vmovaps [rsp+0x60], xmm6
0000710a0d1d96ab  vmovaps [rsp+0x70], xmm7
0000710a0d1d96b1  vmovaps [rsp+0x80], xmm8
0000710a0d1d96ba  vmovaps [rsp+0x90], xmm9
0000710a0d1d96c3  vmovaps [rsp+0xA0], xmm10
0000710a0d1d96cc  vmovaps [rsp+0xB0], xmm11
0000710a0d1d96d5  vmovaps [rsp+0xC0], xmm12
0000710a0d1d96de  vmovaps [rsp+0xD0], xmm14
0000710a0d1d96e7  vmovaps [rsp+0xE0], xmm15
0000710a0d1d96f0  sub rsp, 0x40
0000710a0d1d96f4  lea rdi, [rsp]
0000710a0d1d96f8  lea rsi, [rsp+0x10]
0000710a0d1d96fd  lea rdx, [rsp+0x20]
0000710a0d1d9702  lea rcx, [rsp+0x30]
0000710a0d1d9707  mov r8d, 0x00
0000710a0d1d970d  lea r9, [r15+0x3A8]
0000710a0d1d9714  movaps [rdi], xmm13
0000710a0d1d9718  movaps [rsi], xmm12
0000710a0d1d971c  movaps [rdx], xmm15
0000710a0d1d9720  movaps [rcx], xmm14
0000710a0d1d9724  mov rax, 0x64F334B05A50
0000710a0d1d972e  call rax
0000710a0d1d9730  movaps xmm13, [rsp]
0000710a0d1d9735  add rsp, 0x40
0000710a0d1d9739  vmovaps xmm0, [rsp]
0000710a0d1d973e  vmovaps xmm1, [rsp+0x10]
0000710a0d1d9744  vmovaps xmm2, [rsp+0x20]
0000710a0d1d974a  vmovaps xmm3, [rsp+0x30]
0000710a0d1d9750  vmovaps xmm4, [rsp+0x40]
0000710a0d1d9756  vmovaps xmm5, [rsp+0x50]
0000710a0d1d975c  vmovaps xmm6, [rsp+0x60]
0000710a0d1d9762  vmovaps xmm7, [rsp+0x70]
0000710a0d1d9768  vmovaps xmm8, [rsp+0x80]
0000710a0d1d9771  vmovaps xmm9, [rsp+0x90]
0000710a0d1d977a  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d9783  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d978c  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d9795  vmovaps xmm14, [rsp+0xD0]
0000710a0d1d979e  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d97a7  add rsp, 0xF0
0000710a0d1d97ae  pop r11
0000710a0d1d97b0  pop r10
0000710a0d1d97b2  pop r9
0000710a0d1d97b4  pop r8
0000710a0d1d97b6  pop rsi
0000710a0d1d97b7  pop rdi
0000710a0d1d97b8  pop rdx
0000710a0d1d97b9  pop rcx
0000710a0d1d97ba  pop rax
0000710a0d1d97bb  add rsp, 0x08
0000710a0d1d97bf  jmp 0x0000710A0D1D6C7D
0000710a0d1d97c4  sub rsp, 0x08
0000710a0d1d97c8  push rax
0000710a0d1d97c9  push rcx
0000710a0d1d97ca  push rdx
0000710a0d1d97cb  push rdi
0000710a0d1d97cc  push rsi
0000710a0d1d97cd  push r8
0000710a0d1d97cf  push r9
0000710a0d1d97d1  push r10
0000710a0d1d97d3  push r11
0000710a0d1d97d5  sub rsp, 0xF0
0000710a0d1d97dc  vmovaps [rsp], xmm0
0000710a0d1d97e1  vmovaps [rsp+0x10], xmm1
0000710a0d1d97e7  vmovaps [rsp+0x20], xmm2
0000710a0d1d97ed  vmovaps [rsp+0x30], xmm3
0000710a0d1d97f3  vmovaps [rsp+0x40], xmm4
0000710a0d1d97f9  vmovaps [rsp+0x50], xmm5
0000710a0d1d97ff  vmovaps [rsp+0x60], xmm6
0000710a0d1d9805  vmovaps [rsp+0x70], xmm7
0000710a0d1d980b  vmovaps [rsp+0x80], xmm8
0000710a0d1d9814  vmovaps [rsp+0x90], xmm9
0000710a0d1d981d  vmovaps [rsp+0xA0], xmm10
0000710a0d1d9826  vmovaps [rsp+0xB0], xmm11
0000710a0d1d982f  vmovaps [rsp+0xC0], xmm12
0000710a0d1d9838  vmovaps [rsp+0xD0], xmm13
0000710a0d1d9841  vmovaps [rsp+0xE0], xmm15
0000710a0d1d984a  sub rsp, 0x40
0000710a0d1d984e  lea rdi, [rsp]
0000710a0d1d9852  lea rsi, [rsp+0x10]
0000710a0d1d9857  lea rdx, [rsp+0x20]
0000710a0d1d985c  lea rcx, [rsp+0x30]
0000710a0d1d9861  mov r8d, 0x00
0000710a0d1d9867  lea r9, [r15+0x3A8]
0000710a0d1d986e  movaps [rdi], xmm14
0000710a0d1d9872  movaps [rsi], xmm11
0000710a0d1d9876  movaps [rdx], xmm1
0000710a0d1d9879  movaps [rcx], xmm15
0000710a0d1d987d  mov rax, 0x64F334B05A50
0000710a0d1d9887  call rax
0000710a0d1d9889  movaps xmm14, [rsp]
0000710a0d1d988e  add rsp, 0x40
0000710a0d1d9892  vmovaps xmm0, [rsp]
0000710a0d1d9897  vmovaps xmm1, [rsp+0x10]
0000710a0d1d989d  vmovaps xmm2, [rsp+0x20]
0000710a0d1d98a3  vmovaps xmm3, [rsp+0x30]
0000710a0d1d98a9  vmovaps xmm4, [rsp+0x40]
0000710a0d1d98af  vmovaps xmm5, [rsp+0x50]
0000710a0d1d98b5  vmovaps xmm6, [rsp+0x60]
0000710a0d1d98bb  vmovaps xmm7, [rsp+0x70]
0000710a0d1d98c1  vmovaps xmm8, [rsp+0x80]
0000710a0d1d98ca  vmovaps xmm9, [rsp+0x90]
0000710a0d1d98d3  vmovaps xmm10, [rsp+0xA0]
0000710a0d1d98dc  vmovaps xmm11, [rsp+0xB0]
0000710a0d1d98e5  vmovaps xmm12, [rsp+0xC0]
0000710a0d1d98ee  vmovaps xmm13, [rsp+0xD0]
0000710a0d1d98f7  vmovaps xmm15, [rsp+0xE0]
0000710a0d1d9900  add rsp, 0xF0
0000710a0d1d9907  pop r11
0000710a0d1d9909  pop r10
0000710a0d1d990b  pop r9
0000710a0d1d990d  pop r8
0000710a0d1d990f  pop rsi
0000710a0d1d9910  pop rdi
0000710a0d1d9911  pop rdx
0000710a0d1d9912  pop rcx
0000710a0d1d9913  pop rax
0000710a0d1d9914  add rsp, 0x08
0000710a0d1d9918  jmp 0x0000710A0D1D6CAB
0000710a0d1d991d  call 0x0000710A0D0ACF70
0000710a0d1d9922  jmp 0x0000710A0D1D6CB9
0000710a0d1d9927  call 0x0000710A0D00C380
0000710a0d1d992c  jmp 0x0000710A0D1D6CC3
0000710a0d1d9931  call 0x0000710A0D008C20
0000710a0d1d9936  jmp 0x0000710A0D1D6CCD
0000710a0d1d993b  call 0x0000710A0D00D600
0000710a0d1d9940  jmp 0x0000710A0D1D6CD7
0000710a0d1d9945  int3
0000710a0d1d9946  nop [rax+rax*1], ax
0000710a0d1d994f  nop
0000710a0d1d9950  mov eax, [r15+0x48]
0000710a0d1d9954  lea r14d, [eax+0x01]
0000710a0d1d9959  mov [rsp+0x10], r14d
0000710a0d1d995e  mov r14d, r14d
0000710a0d1d9961  mov [r15+0x48], r14
0000710a0d1d9965  xor eax, eax
0000710a0d1d9967  mov r14d, [rsp+0x10]
0000710a0d1d996c  cmp r14d, 0x1F4
0000710a0d1d9973  cmc
0000710a0d1d9974  lahf
0000710a0d1d9975  seto al
0000710a0d1d9978  mov [r15+0x108], eax
0000710a0d1d997f  mov eax, [r15+0x108]
0000710a0d1d9986  sahf
0000710a0d1d9987  jnz 0x0000710A0D1D99B9
0000710a0d1d9989  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d9991  jz 0x0000710A0D1DD2E0
0000710a0d1d9997  nop [rax+rax*1], ax
0000710a0d1d99a0  nop [rax+rax*1], eax
0000710a0d1d99a8  mov eax, 0x410670
0000710a0d1d99ad  mov [r15+0x100], rax
0000710a0d1d99b4  jmp 0x0000710A0CFFE110
0000710a0d1d99b9  cmp dword ptr [r15+0x318], 0x00
0000710a0d1d99c1  jz 0x0000710A0D1D99F0
0000710a0d1d99c7  nop [rax+rax*1], ax
0000710a0d1d99d0  nop [rax+rax*1], eax
0000710a0d1d99d8  mov eax, 0x4104EC
0000710a0d1d99dd  mov [r15+0x100], rax
0000710a0d1d99e4  jmp 0x0000710A0CFFE110
0000710a0d1d99e9  int3
0000710a0d1d99ea  int3
0000710a0d1d99eb  nop [rax+rax*1], eax
0000710a0d1d99f0  mov rax, [r15+0x40]
0000710a0d1d99f4  vxorps xmm1, xmm1, xmm1
0000710a0d1d99f8  vpbroadcastq xmm1, xmm1
0000710a0d1d99fd  vxorps xmm15, xmm15, xmm15
0000710a0d1d9a02  vpbroadcastq xmm15, xmm15
0000710a0d1d9a07  lea r14, [rax+0x30]
0000710a0d1d9a0b  mov r12, [r13+r14*1]
0000710a0d1d9a10  lea r14, [rax+0x38]
0000710a0d1d9a14  mov r11, [r13+r14*1]
0000710a0d1d9a19  movq xmm14, r12
0000710a0d1d9a1e  movq xmm13, r11
0000710a0d1d9a23  movq xmm14, xmm14
0000710a0d1d9a28  movq xmm13, xmm13
0000710a0d1d9a2d  vmovaps [rsp+0x10], xmm13
0000710a0d1d9a33  movq xmm13, xmm13
0000710a0d1d9a38  movaps [r15+0x270], xmm13
0000710a0d1d9a40  movaps xmm13, [r15+0x160]
0000710a0d1d9a48  vmovaps [rsp+0x20], xmm13
0000710a0d1d9a4e  vmovaps xmm12, [rsp+0x20]
0000710a0d1d9a54  por xmm13, xmm12
0000710a0d1d9a59  lea r14, [rax+0x20]
0000710a0d1d9a5d  mov r12, [r13+r14*1]
0000710a0d1d9a62  lea r14, [rax+0x28]
0000710a0d1d9a66  mov r11, [r13+r14*1]
0000710a0d1d9a6b  movq xmm12, r12
0000710a0d1d9a70  movq xmm11, r11
0000710a0d1d9a75  movq xmm12, xmm12
0000710a0d1d9a7a  movq xmm11, xmm11
0000710a0d1d9a7f  movaps xmm10, [r15+0x2D0]
0000710a0d1d9a87  vmovaps [rsp+0x20], xmm10
0000710a0d1d9a8d  vmovaps xmm9, [rsp+0x20]
0000710a0d1d9a93  por xmm10, xmm9
0000710a0d1d9a98  movaps xmm9, [r15+0x300]
0000710a0d1d9aa0  vmovaps [rsp+0x20], xmm9
0000710a0d1d9aa6  vmovaps xmm8, [rsp+0x20]
0000710a0d1d9aac  por xmm9, xmm8
0000710a0d1d9ab1  movaps xmm8, [r15+0x2B0]
0000710a0d1d9ab9  vmovaps [rsp+0x20], xmm8
0000710a0d1d9abf  vmovaps xmm7, [rsp+0x20]
0000710a0d1d9ac5  por xmm8, xmm7
0000710a0d1d9aca  movaps xmm7, [r15+0x180]
0000710a0d1d9ad2  vmovaps [rsp+0x20], xmm7
0000710a0d1d9ad8  vmovaps xmm6, [rsp+0x20]
0000710a0d1d9ade  por xmm7, xmm6
0000710a0d1d9ae2  lea r14, [rax+0x10]
0000710a0d1d9ae6  mov r12, [r13+r14*1]
0000710a0d1d9aeb  lea r14, [rax+0x18]
0000710a0d1d9aef  mov r11, [r13+r14*1]
0000710a0d1d9af4  movq xmm6, r12
0000710a0d1d9af9  movq xmm5, r11
0000710a0d1d9afe  movq xmm6, xmm6
0000710a0d1d9b02  movq xmm5, xmm5
0000710a0d1d9b06  movaps xmm4, [r15+0x200]
0000710a0d1d9b0e  vmovaps [rsp+0x20], xmm4
0000710a0d1d9b14  vmovaps xmm3, [rsp+0x20]
0000710a0d1d9b1a  por xmm4, xmm3
0000710a0d1d9b1e  movaps xmm3, [r15+0x1F0]
0000710a0d1d9b26  vmovaps [rsp+0x20], xmm3
0000710a0d1d9b2c  vmovaps xmm2, [rsp+0x20]
0000710a0d1d9b32  por xmm3, xmm2
0000710a0d1d9b36  movaps xmm2, [r15+0x2E0]
0000710a0d1d9b3e  vmovaps [rsp+0x20], xmm2
0000710a0d1d9b44  vmovaps [rsp+0x30], xmm1
0000710a0d1d9b4a  vmovaps xmm1, [rsp+0x20]
0000710a0d1d9b50  por xmm2, xmm1
0000710a0d1d9b54  movaps xmm1, [r15+0x2A0]
0000710a0d1d9b5c  vmovaps [rsp+0x20], xmm1
0000710a0d1d9b62  vmovaps [rsp+0x40], xmm15
0000710a0d1d9b68  vmovaps xmm15, [rsp+0x20]
0000710a0d1d9b6e  por xmm1, xmm15
0000710a0d1d9b73  movaps xmm15, [r15+0x280]
0000710a0d1d9b7b  vmovaps [rsp+0x20], xmm15
0000710a0d1d9b81  vmovaps [rsp+0x50], xmm1
0000710a0d1d9b87  vmovaps xmm1, [rsp+0x20]
0000710a0d1d9b8d  por xmm15, xmm1
0000710a0d1d9b92  movaps xmm1, [r15+0x1C0]
0000710a0d1d9b9a  vmovaps [rsp+0x20], xmm1
0000710a0d1d9ba0  vmovaps [rsp+0x60], xmm15
0000710a0d1d9ba6  vmovaps xmm15, [rsp+0x20]
0000710a0d1d9bac  por xmm1, xmm15
0000710a0d1d9bb1  movaps xmm15, [r15+0x210]
0000710a0d1d9bb9  vmovaps [rsp+0x20], xmm15
0000710a0d1d9bbf  vmovaps [rsp+0x70], xmm1
0000710a0d1d9bc5  vmovaps xmm1, [rsp+0x20]
0000710a0d1d9bcb  por xmm15, xmm1
0000710a0d1d9bd0  mov r14, [r13+rax*1]
0000710a0d1d9bd5  vmovq xmm1, r14
0000710a0d1d9bda  vpbroadcastq xmm1, xmm1
0000710a0d1d9bdf  vmovaps [rsp+0x20], xmm1
0000710a0d1d9be5  vxorps xmm1, xmm1, xmm1
0000710a0d1d9be9  vpbroadcastq xmm1, xmm1
0000710a0d1d9bee  mov r14, [r15+0xF8]
0000710a0d1d9bf5  vmovaps [rsp+0x80], xmm1
0000710a0d1d9bfe  movups xmm1, [r13+r14*1]
0000710a0d1d9c04  vmovaps [rsp+0x90], xmm1
0000710a0d1d9c0d  vxorps xmm1, xmm1, xmm1
0000710a0d1d9c11  vpbroadcastq xmm1, xmm1
0000710a0d1d9c16  lea r12, [rax+0x08]
0000710a0d1d9c1a  mov rax, [r13+r12*1]
0000710a0d1d9c1f  vmovaps [rsp+0xA0], xmm1
0000710a0d1d9c28  movq xmm1, rax
0000710a0d1d9c2d  movaps [r15+0x240], xmm1
0000710a0d1d9c35  mov rax, [r15+0x50]
0000710a0d1d9c39  mov [r15+0x60], rax
0000710a0d1d9c3d  mov qword ptr [r15+0x58], 0x40
0000710a0d1d9c45  vmovaps xmm1, [rsp+0x30]
0000710a0d1d9c4b  vmovaps [rsp+0x30], xmm15
0000710a0d1d9c51  vmovaps xmm15, [rsp+0x90]
0000710a0d1d9c5a  vmovaps [rsp+0x90], xmm14
0000710a0d1d9c63  vmovaps xmm14, [rsp+0x20]
0000710a0d1d9c69  vmovaps [rsp+0x20], xmm13
0000710a0d1d9c6f  vmovaps [rsp+0xB0], xmm12
0000710a0d1d9c78  movaps xmm13, xmm1
0000710a0d1d9c7c  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d9c87  vptest xmm12, xmm12
0000710a0d1d9c8c  jnz 0x0000710A0D1DA72F
0000710a0d1d9c92  movaps xmm1, [r15+0x250]
0000710a0d1d9c9a  vmovaps xmm15, [rsp+0x40]
0000710a0d1d9ca0  vmovaps [rsp+0x40], xmm13
0000710a0d1d9ca6  movaps xmm12, xmm15
0000710a0d1d9caa  vfmadd231pd xmm12, xmm1, xmm14
0000710a0d1d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
0000710a0d1d9cb5  vptest xmm13, xmm13
0000710a0d1d9cba  jnz 0x0000710A0D1DA888
0000710a0d1d9cc0  movaps xmm15, [r15+0x1E0]
0000710a0d1d9cc8  vmovaps [rsp+0xC0], xmm15
0000710a0d1d9cd1  vmovaps xmm13, [rsp+0xC0]
0000710a0d1d9cda  por xmm15, xmm13
0000710a0d1d9cdf  movaps xmm13, [r15+0x1D0]
0000710a0d1d9ce7  vmovaps [rsp+0xC0], xmm13
0000710a0d1d9cf0  vmovaps [rsp+0xD0], xmm1
0000710a0d1d9cf9  vmovaps xmm1, [rsp+0xC0]
0000710a0d1d9d02  por xmm13, xmm1
0000710a0d1d9d07  movaps xmm1, [r15+0x2C0]
0000710a0d1d9d0f  vmovaps [rsp+0xC0], xmm1
0000710a0d1d9d18  vmovaps [rsp+0xE0], xmm15
0000710a0d1d9d21  vmovaps xmm15, [rsp+0xC0]
0000710a0d1d9d2a  por xmm1, xmm15
0000710a0d1d9d2f  movaps xmm15, [r15+0x290]
0000710a0d1d9d37  vmovaps [rsp+0xC0], xmm15
0000710a0d1d9d40  vmovaps [rsp+0xF0], xmm1
0000710a0d1d9d49  vmovaps xmm1, [rsp+0xC0]
0000710a0d1d9d52  por xmm15, xmm1
0000710a0d1d9d57  movaps xmm1, [r15+0x260]
0000710a0d1d9d5f  vmovaps [rsp+0xC0], xmm1
0000710a0d1d9d68  vmovaps [rsp+0x100], xmm15
0000710a0d1d9d71  vmovaps xmm15, [rsp+0xC0]
0000710a0d1d9d7a  por xmm1, xmm15
0000710a0d1d9d7f  vmovaps xmm15, [rsp+0xD0]
0000710a0d1d9d88  vmovaps [rsp+0xC0], xmm1
0000710a0d1d9d91  vmovaps xmm1, [rsp+0xD0]
0000710a0d1d9d9a  por xmm15, xmm1
0000710a0d1d9d9f  lea r12, [r14+0xC0]
0000710a0d1d9da6  movups xmm1, [r13+r12*1]
0000710a0d1d9dac  mov [rsp+0xD0], rax
0000710a0d1d9db4  xor eax, eax
0000710a0d1d9db6  mov r12d, 0x40
0000710a0d1d9dbc  mov r11d, 0x200
0000710a0d1d9dc2  cmp r12, r11
0000710a0d1d9dc5  cmc
0000710a0d1d9dc6  lahf
0000710a0d1d9dc7  seto al
0000710a0d1d9dca  mov [r15+0x108], eax
0000710a0d1d9dd1  vmovaps [rsp+0x110], xmm1
0000710a0d1d9dda  vmovaps xmm1, [rsp+0x80]
0000710a0d1d9de3  vmovaps [rsp+0x80], xmm15
0000710a0d1d9dec  vmovaps xmm15, [rsp+0x110]
0000710a0d1d9df5  vmovaps [rsp+0x110], xmm13
0000710a0d1d9dfe  vmovaps [rsp+0x120], xmm12
0000710a0d1d9e07  movaps xmm13, xmm1
0000710a0d1d9e0b  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d9e16  vptest xmm12, xmm12
0000710a0d1d9e1b  jnz 0x0000710A0D1DA9EB
0000710a0d1d9e21  lea rax, [r14+0xB0]
0000710a0d1d9e28  movups xmm1, [r13+rax*1]
0000710a0d1d9e2e  vmovaps xmm15, [rsp+0xA0]
0000710a0d1d9e37  vmovaps [rsp+0xA0], xmm13
0000710a0d1d9e40  movaps xmm12, xmm15
0000710a0d1d9e44  vfmadd231pd xmm12, xmm1, xmm14
0000710a0d1d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
0000710a0d1d9e4f  vptest xmm13, xmm13
0000710a0d1d9e54  jnz 0x0000710A0D1DAB4E
0000710a0d1d9e5a  vmovaps xmm1, [rsp+0x30]
0000710a0d1d9e60  vmovaps xmm15, [rsp+0x30]
0000710a0d1d9e66  por xmm1, xmm15
0000710a0d1d9e6b  movaps [r15+0x210], xmm1
0000710a0d1d9e73  vmovaps xmm15, [rsp+0x70]
0000710a0d1d9e79  vmovaps xmm14, [rsp+0x70]
0000710a0d1d9e7f  por xmm15, xmm14
0000710a0d1d9e84  movaps [r15+0x1C0], xmm15
0000710a0d1d9e8c  vmovaps xmm14, [rsp+0x60]
0000710a0d1d9e92  vmovaps xmm13, [rsp+0x60]
0000710a0d1d9e98  por xmm14, xmm13
0000710a0d1d9e9d  movaps [r15+0x280], xmm14
0000710a0d1d9ea5  vmovaps xmm13, [rsp+0x50]
0000710a0d1d9eab  vmovaps [rsp+0x30], xmm1
0000710a0d1d9eb1  vmovaps xmm1, [rsp+0x50]
0000710a0d1d9eb7  por xmm13, xmm1
0000710a0d1d9ebc  movaps [r15+0x2A0], xmm13
0000710a0d1d9ec4  vmovaps [rsp+0x50], xmm2
0000710a0d1d9eca  vmovaps xmm1, [rsp+0x50]
0000710a0d1d9ed0  por xmm2, xmm1
0000710a0d1d9ed4  movaps [r15+0x2E0], xmm2
0000710a0d1d9edc  vmovaps [rsp+0x50], xmm3
0000710a0d1d9ee2  vmovaps xmm1, [rsp+0x50]
0000710a0d1d9ee8  por xmm3, xmm1
0000710a0d1d9eec  movaps [r15+0x1F0], xmm3
0000710a0d1d9ef4  vmovaps xmm1, [rsp+0x80]
0000710a0d1d9efd  vmovaps [rsp+0x50], xmm15
0000710a0d1d9f03  vmovaps xmm15, [rsp+0x80]
0000710a0d1d9f0c  por xmm1, xmm15
0000710a0d1d9f11  movaps [r15+0x250], xmm1
0000710a0d1d9f19  vmovaps xmm1, [rsp+0xC0]
0000710a0d1d9f22  vmovaps xmm15, [rsp+0xC0]
0000710a0d1d9f2b  por xmm1, xmm15
0000710a0d1d9f30  movaps [r15+0x260], xmm1
0000710a0d1d9f38  vmovaps xmm15, [rsp+0x100]
0000710a0d1d9f41  vmovaps [rsp+0x60], xmm1
0000710a0d1d9f47  vmovaps xmm1, [rsp+0x100]
0000710a0d1d9f50  por xmm15, xmm1
0000710a0d1d9f55  movaps [r15+0x290], xmm15
0000710a0d1d9f5d  vmovaps xmm1, [rsp+0xF0]
0000710a0d1d9f66  vmovaps [rsp+0x70], xmm15
0000710a0d1d9f6c  vmovaps xmm15, [rsp+0xF0]
0000710a0d1d9f75  por xmm1, xmm15
0000710a0d1d9f7a  movaps [r15+0x2C0], xmm1
0000710a0d1d9f82  movq xmm15, qword ptr [r15+0x240]
0000710a0d1d9f8b  vmovaps [rsp+0x80], xmm15
0000710a0d1d9f94  vpermilpd xmm15, xmm15, 0x00
0000710a0d1d9f9a  vmovaps [rsp+0xC0], xmm1
0000710a0d1d9fa3  vmovaps xmm1, [rsp+0x40]
0000710a0d1d9fa9  vmovaps [rsp+0x40], xmm15
0000710a0d1d9faf  vmovaps xmm15, [rsp+0x30]
0000710a0d1d9fb5  vmovaps [rsp+0x30], xmm14
0000710a0d1d9fbb  vmovaps xmm14, [rsp+0x40]
0000710a0d1d9fc1  vmovaps [rsp+0x40], xmm13
0000710a0d1d9fc7  vmovaps [rsp+0xF0], xmm12
0000710a0d1d9fd0  movaps xmm13, xmm1
0000710a0d1d9fd4  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000710a0d1d9fdf  vptest xmm12, xmm12
0000710a0d1d9fe4  jnz 0x0000710A0D1DACA7
0000710a0d1d9fea  vmovaps xmm1, [rsp+0x80]
0000710a0d1d9ff3  vpermilpd xmm1, xmm1, 0x00
0000710a0d1d9ff9  vmovaps xmm15, [rsp+0xA0]
0000710a0d1da002  movaps xmm14, xmm15
0000710a0d1da006  vfmadd231pd xmm14, xmm2, xmm1
0000710a0d1da00b  vcmppd xmm12, xmm14, xmm14, 0x03
0000710a0d1da011  vptest xmm12, xmm12
0000710a0d1da016  jnz 0x0000710A0D1DAE00
0000710a0d1da01c  vmovaps xmm1, [rsp+0x80]
0000710a0d1da025  vpermilpd xmm1, xmm1, 0x00
0000710a0d1da02b  vmovaps xmm15, [rsp+0x120]
0000710a0d1da034  vmovaps xmm12, [rsp+0x50]
0000710a0d1da03a  vmovaps [rsp+0x50], xmm14
0000710a0d1da040  movaps xmm2, xmm15
0000710a0d1da044  vfmadd231pd xmm2, xmm12, xmm1
0000710a0d1da049  vcmppd xmm14, xmm2, xmm2, 0x03
0000710a0d1da04e  vptest xmm14, xmm14
0000710a0d1da053  jnz 0x0000710A0D1DAF58
0000710a0d1da059  vmovaps xmm1, [rsp+0x110]
0000710a0d1da062  vmovaps xmm15, [rsp+0x110]
0000710a0d1da06b  por xmm1, xmm15
0000710a0d1da070  movaps [r15+0x1D0], xmm1
0000710a0d1da078  vmovaps xmm15, [rsp+0x80]
0000710a0d1da081  vpermilpd xmm15, xmm15, 0x00
0000710a0d1da087  vmovaps xmm14, [rsp+0xF0]
0000710a0d1da090  vmovaps [rsp+0x80], xmm1
0000710a0d1da099  movaps xmm12, xmm14
0000710a0d1da09d  vfmadd231pd xmm12, xmm3, xmm15
0000710a0d1da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
0000710a0d1da0a8  vptest xmm1, xmm1
0000710a0d1da0ad  jnz 0x0000710A0D1DB0AF
0000710a0d1da0b3  vmovaps [rsp+0xA0], xmm4
0000710a0d1da0bc  vmovaps xmm1, [rsp+0xA0]
0000710a0d1da0c5  por xmm4, xmm1
0000710a0d1da0c9  movaps [r15+0x200], xmm4
0000710a0d1da0d1  vmovaps xmm1, [rsp+0xE0]
0000710a0d1da0da  vmovaps xmm15, [rsp+0xE0]
0000710a0d1da0e3  por xmm1, xmm15
0000710a0d1da0e8  movaps [r15+0x1E0], xmm1
0000710a0d1da0f0  vmovaps [rsp+0xA0], xmm8
0000710a0d1da0f9  vmovaps xmm1, [rsp+0xA0]
0000710a0d1da102  por xmm8, xmm1
0000710a0d1da107  movaps [r15+0x2B0], xmm8
0000710a0d1da10f  vmovaps [rsp+0xA0], xmm9
0000710a0d1da118  vmovaps xmm1, [rsp+0xA0]
0000710a0d1da121  por xmm9, xmm1
0000710a0d1da126  movaps [r15+0x300], xmm9
0000710a0d1da12e  vmovaps [rsp+0xA0], xmm6
0000710a0d1da137  vpermilpd xmm6, xmm6, 0x00
0000710a0d1da13d  vmovaps xmm14, [rsp+0x60]
0000710a0d1da143  movaps xmm9, xmm13
0000710a0d1da147  vfmadd231pd xmm9, xmm14, xmm6
0000710a0d1da14c  vcmppd xmm3, xmm9, xmm9, 0x03
0000710a0d1da152  vptest xmm3, xmm3
0000710a0d1da157  jnz 0x0000710A0D1DB208
0000710a0d1da15d  vmovaps xmm14, [rsp+0xA0]
0000710a0d1da166  vpermilpd xmm14, xmm14, 0x00
0000710a0d1da16c  vmovaps xmm13, [rsp+0x50]
0000710a0d1da172  vmovaps xmm6, [rsp+0xC0]
0000710a0d1da17b  vmovaps [rsp+0x50], xmm1
0000710a0d1da181  movaps xmm3, xmm13
0000710a0d1da185  vfmadd231pd xmm3, xmm6, xmm14
0000710a0d1da18a  vcmppd xmm1, xmm3, xmm3, 0x03
0000710a0d1da18f  vptest xmm1, xmm1
0000710a0d1da194  jnz 0x0000710A0D1DB361
0000710a0d1da19a  vmovaps xmm1, [rsp+0xA0]
0000710a0d1da1a3  vpermilpd xmm1, xmm1, 0x00
0000710a0d1da1a9  vmovaps xmm14, [rsp+0x30]
0000710a0d1da1af  movaps xmm6, xmm2
0000710a0d1da1b2  vfmadd231pd xmm6, xmm14, xmm1
0000710a0d1da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
0000710a0d1da1bc  vptest xmm13, xmm13
0000710a0d1da1c1  jnz 0x0000710A0D1DB4B8
0000710a0d1da1c7  vmovaps xmm1, [rsp+0xA0]
0000710a0d1da1d0  vpermilpd xmm1, xmm1, 0x00
0000710a0d1da1d6  vmovaps xmm14, [rsp+0x80]
0000710a0d1da1df  movaps xmm13, xmm12
0000710a0d1da1e3  vfmadd231pd xmm13, xmm14, xmm1
0000710a0d1da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
0000710a0d1da1ee  vptest xmm2, xmm2
0000710a0d1da1f3  jnz 0x0000710A0D1DB60E
0000710a0d1da1f9  vmovaps [rsp+0x30], xmm7
0000710a0d1da1ff  vmovaps xmm1, [rsp+0x30]
0000710a0d1da205  por xmm7, xmm1
0000710a0d1da209  movaps [r15+0x180], xmm7
0000710a0d1da211  vmovaps [rsp+0x30], xmm10
0000710a0d1da217  vmovaps xmm1, [rsp+0x30]
0000710a0d1da21d  por xmm10, xmm1
0000710a0d1da222  movaps [r15+0x2D0], xmm10
0000710a0d1da22a  vmovaps [rsp+0x30], xmm5
0000710a0d1da230  vpermilpd xmm5, xmm5, 0x00
0000710a0d1da236  vmovaps xmm14, [rsp+0x50]
0000710a0d1da23c  movaps xmm12, xmm3
0000710a0d1da240  vfmadd231pd xmm12, xmm14, xmm5
0000710a0d1da245  vcmppd xmm10, xmm12, xmm12, 0x03
0000710a0d1da24b  vptest xmm10, xmm10
0000710a0d1da250  jnz 0x0000710A0D1DB767
0000710a0d1da256  vmovaps xmm14, [rsp+0x30]
0000710a0d1da25c  vpermilpd xmm14, xmm14, 0x00
0000710a0d1da262  movaps xmm10, xmm9
0000710a0d1da266  vfmadd231pd xmm10, xmm7, xmm14
0000710a0d1da26b  vcmppd xmm5, xmm10, xmm10, 0x03
0000710a0d1da271  vptest xmm5, xmm5
0000710a0d1da276  jnz 0x0000710A0D1DB8BF
0000710a0d1da27c  lea rax, [r14+0x80]
0000710a0d1da283  movups xmm14, [r13+rax*1]
0000710a0d1da289  movaps [r15+0x2F0], xmm14
0000710a0d1da291  vmovaps xmm9, [rsp+0x30]
0000710a0d1da297  vpermilpd xmm9, xmm9, 0x00
0000710a0d1da29d  vmovaps xmm7, [rsp+0x70]
0000710a0d1da2a3  movaps xmm5, xmm6
0000710a0d1da2a6  vfmadd231pd xmm5, xmm7, xmm9
0000710a0d1da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
0000710a0d1da2b0  vptest xmm3, xmm3
0000710a0d1da2b5  jnz 0x0000710A0D1DBA22
0000710a0d1da2bb  vmovaps xmm9, [rsp+0x30]
0000710a0d1da2c1  vpermilpd xmm9, xmm9, 0x00
0000710a0d1da2c7  movaps xmm7, xmm13
0000710a0d1da2cb  vfmadd231pd xmm7, xmm1, xmm9
0000710a0d1da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
0000710a0d1da2d5  vptest xmm6, xmm6
0000710a0d1da2da  jnz 0x0000710A0D1DBB78
0000710a0d1da2e0  vmovaps xmm1, [rsp+0x20]
0000710a0d1da2e6  vmovaps xmm13, [rsp+0x20]
0000710a0d1da2ec  por xmm1, xmm13
0000710a0d1da2f1  movaps [r15+0x160], xmm1
0000710a0d1da2f9  lea rax, [r14+0x40]
0000710a0d1da2fd  movups xmm13, [r13+rax*1]
0000710a0d1da303  lea rax, [r14+0x50]
0000710a0d1da307  movups xmm9, [r13+rax*1]
0000710a0d1da30d  movaps [r15+0x1B0], xmm13
0000710a0d1da315  movaps [r15+0x1A0], xmm9
0000710a0d1da31d  movaps xmm6, [r15+0x190]
0000710a0d1da325  vmovaps xmm3, [rsp+0xB0]
0000710a0d1da32e  vpermilpd xmm3, xmm3, 0x00
0000710a0d1da334  vmovaps [rsp+0x20], xmm1
0000710a0d1da33a  movaps xmm2, xmm12
0000710a0d1da33e  vfmadd231pd xmm2, xmm6, xmm3
0000710a0d1da343  vcmppd xmm1, xmm2, xmm2, 0x03
0000710a0d1da348  vptest xmm1, xmm1
0000710a0d1da34d  jnz 0x0000710A0D1DBCE3
0000710a0d1da353  vmovaps xmm1, [rsp+0xB0]
0000710a0d1da35c  vpermilpd xmm1, xmm1, 0x00
0000710a0d1da362  vmovaps xmm12, [rsp+0x20]
0000710a0d1da368  movaps xmm6, xmm10
0000710a0d1da36c  vfmadd231pd xmm6, xmm12, xmm1
0000710a0d1da371  vcmppd xmm3, xmm6, xmm6, 0x03
0000710a0d1da376  vptest xmm3, xmm3
0000710a0d1da37b  jnz 0x0000710A0D1DBE39
0000710a0d1da381  vmovaps xmm1, [rsp+0xB0]
0000710a0d1da38a  vpermilpd xmm1, xmm1, 0x00
0000710a0d1da390  vmovaps xmm12, [rsp+0x40]
0000710a0d1da396  movaps xmm10, xmm5
0000710a0d1da39a  vfmadd231pd xmm10, xmm12, xmm1
0000710a0d1da39f  vcmppd xmm3, xmm10, xmm10, 0x03
0000710a0d1da3a5  vptest xmm3, xmm3
0000710a0d1da3aa  jnz 0x0000710A0D1DBF90
0000710a0d1da3b0  vmovaps xmm1, [rsp+0xB0]
0000710a0d1da3b9  vpermilpd xmm1, xmm1, 0x00
0000710a0d1da3bf  movaps xmm12, xmm7
0000710a0d1da3c3  vfmadd231pd xmm12, xmm15, xmm1
0000710a0d1da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
0000710a0d1da3ce  vptest xmm5, xmm5
0000710a0d1da3d3  jnz 0x0000710A0D1DC0E8
0000710a0d1da3d9  lea rax, [r14+0x60]
0000710a0d1da3dd  movups xmm1, [r13+rax*1]
0000710a0d1da3e3  lea rax, [r14+0x70]
0000710a0d1da3e7  movups xmm15, [r13+rax*1]
0000710a0d1da3ed  movaps [r15+0x150], xmm1
0000710a0d1da3f5  movaps [r15+0x120], xmm15
0000710a0d1da3fd  vmovaps [rsp+0x20], xmm11
0000710a0d1da403  vpermilpd xmm11, xmm11, 0x00
0000710a0d1da409  movaps xmm7, xmm2
0000710a0d1da40c  vfmadd231pd xmm7, xmm9, xmm11
0000710a0d1da411  vcmppd xmm5, xmm7, xmm7, 0x03
0000710a0d1da416  vptest xmm5, xmm5
0000710a0d1da41b  jnz 0x0000710A0D1DC254
0000710a0d1da421  vmovaps xmm11, [rsp+0x20]
0000710a0d1da427  vpermilpd xmm11, xmm11, 0x00
0000710a0d1da42d  movaps xmm9, xmm6
0000710a0d1da431  vfmadd231pd xmm9, xmm1, xmm11
0000710a0d1da436  vcmppd xmm5, xmm9, xmm9, 0x03
0000710a0d1da43c  vptest xmm5, xmm5
0000710a0d1da441  jnz 0x0000710A0D1DC3AB
0000710a0d1da447  vmovaps xmm1, [rsp+0x20]
0000710a0d1da44d  vpermilpd xmm1, xmm1, 0x00
0000710a0d1da453  movaps xmm11, xmm10
0000710a0d1da457  vfmadd231pd xmm11, xmm8, xmm1
0000710a0d1da45c  vcmppd xmm6, xmm11, xmm11, 0x03
0000710a0d1da462  vptest xmm6, xmm6
0000710a0d1da467  jnz 0x0000710A0D1DC503
0000710a0d1da46d  vmovaps xmm1, [rsp+0x20]
0000710a0d1da473  vpermilpd xmm1, xmm1, 0x00
0000710a0d1da479  movaps xmm10, xmm12
0000710a0d1da47d  vfmadd231pd xmm10, xmm13, xmm1
0000710a0d1da482  vcmppd xmm8, xmm10, xmm10, 0x03
0000710a0d1da488  vptest xmm8, xmm8
0000710a0d1da48d  jnz 0x0000710A0D1DC65C
0000710a0d1da493  lea rax, [r14+0x20]
0000710a0d1da497  movups xmm1, [r13+rax*1]
0000710a0d1da49d  lea rax, [r14+0x30]
0000710a0d1da4a1  movups xmm13, [r13+rax*1]
0000710a0d1da4a7  vmovaps xmm12, [rsp+0x90]
0000710a0d1da4b0  vpermilpd xmm12, xmm12, 0x00
0000710a0d1da4b6  movaps xmm8, xmm7
0000710a0d1da4ba  vfmadd231pd xmm8, xmm4, xmm12
0000710a0d1da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
0000710a0d1da4c5  vptest xmm6, xmm6
0000710a0d1da4ca  jnz 0x0000710A0D1DC7C9
0000710a0d1da4d0  vmovaps xmm12, [rsp+0x90]
0000710a0d1da4d9  vpermilpd xmm12, xmm12, 0x00
0000710a0d1da4df  movaps xmm7, xmm9
0000710a0d1da4e3  vfmadd231pd xmm7, xmm14, xmm12
0000710a0d1da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
0000710a0d1da4ed  vptest xmm6, xmm6
0000710a0d1da4f2  jnz 0x0000710A0D1DC921
0000710a0d1da4f8  vmovaps xmm14, [rsp+0x90]
0000710a0d1da501  vpermilpd xmm14, xmm14, 0x00
0000710a0d1da507  movaps xmm12, xmm11
0000710a0d1da50b  vfmadd231pd xmm12, xmm15, xmm14
0000710a0d1da510  vcmppd xmm9, xmm12, xmm12, 0x03
0000710a0d1da516  vptest xmm9, xmm9
0000710a0d1da51b  jnz 0x0000710A0D1DCA79
0000710a0d1da521  vmovaps xmm15, [rsp+0x90]
0000710a0d1da52a  vpermilpd xmm15, xmm15, 0x00
0000710a0d1da530  movaps xmm11, xmm10
0000710a0d1da534  vfmadd231pd xmm11, xmm13, xmm15
0000710a0d1da539  vcmppd xmm14, xmm11, xmm11, 0x03
0000710a0d1da53f  vptest xmm14, xmm14
0000710a0d1da544  jnz 0x0000710A0D1DCBD3
0000710a0d1da54a  lea rax, [r14+0x90]
0000710a0d1da551  movups xmm15, [r13+rax*1]
0000710a0d1da557  lea rax, [r14+0xA0]
0000710a0d1da55e  movups xmm14, [r13+rax*1]
0000710a0d1da564  movaps [r15+0x140], xmm15
0000710a0d1da56c  movaps [r15+0x130], xmm14
0000710a0d1da574  vmovaps xmm13, [rsp+0x10]
0000710a0d1da57a  vpermilpd xmm13, xmm13, 0x00
0000710a0d1da580  movaps xmm10, xmm8
0000710a0d1da584  vfmadd231pd xmm10, xmm1, xmm13
0000710a0d1da589  vcmppd xmm9, xmm10, xmm10, 0x03
0000710a0d1da58f  vptest xmm9, xmm9
0000710a0d1da594  jnz 0x0000710A0D1DCD41
0000710a0d1da59a  movaps [r15+0x220], xmm10
0000710a0d1da5a2  lea rax, [r14+0x10]
0000710a0d1da5a6  movups xmm1, [r13+rax*1]
0000710a0d1da5ac  movaps [r15+0x240], xmm1
0000710a0d1da5b4  vmovaps xmm13, [rsp+0x10]
0000710a0d1da5ba  vpermilpd xmm13, xmm13, 0x00
0000710a0d1da5c0  movaps xmm9, xmm7
0000710a0d1da5c4  vfmadd231pd xmm9, xmm14, xmm13
0000710a0d1da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
0000710a0d1da5cf  vptest xmm8, xmm8
0000710a0d1da5d4  jnz 0x0000710A0D1DCEA4
0000710a0d1da5da  movaps [r15+0x110], xmm9
0000710a0d1da5e2  vmovaps xmm14, [rsp+0x10]
0000710a0d1da5e8  vpermilpd xmm14, xmm14, 0x00
0000710a0d1da5ee  movaps xmm13, xmm12
0000710a0d1da5f2  vfmadd231pd xmm13, xmm15, xmm14
0000710a0d1da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
0000710a0d1da5fd  vptest xmm8, xmm8
0000710a0d1da602  jnz 0x0000710A0D1DCFFD
0000710a0d1da608  movaps [r15+0x170], xmm13
0000710a0d1da610  vmovaps xmm15, [rsp+0x10]
0000710a0d1da616  vpermilpd xmm15, xmm15, 0x00
0000710a0d1da61c  movaps xmm14, xmm11
0000710a0d1da620  vfmadd231pd xmm14, xmm1, xmm15
0000710a0d1da625  vcmppd xmm12, xmm14, xmm14, 0x03
0000710a0d1da62b  vptest xmm12, xmm12
0000710a0d1da630  jnz 0x0000710A0D1DD157
0000710a0d1da636  movaps [r15+0x230], xmm14
0000710a0d1da63e  mov rax, [rsp+0xD0]
0000710a0d1da646  movups [r13+rax*1], xmm9
0000710a0d1da64c  lea r14, [rax+0x10]
0000710a0d1da650  movups [r13+r14*1], xmm13
0000710a0d1da656  lea r14, [rax+0x20]
0000710a0d1da65a  movups [r13+r14*1], xmm10
0000710a0d1da660  lea r14, [rax+0x30]
0000710a0d1da664  movups [r13+r14*1], xmm14
0000710a0d1da66a  mov eax, [r15+0x108]
0000710a0d1da671  sahf
0000710a0d1da672  jnz 0x0000710A0D1DA6A4
0000710a0d1da674  cmp dword ptr [r15+0x318], 0x00
0000710a0d1da67c  jz 0x0000710A0D1D9950
0000710a0d1da682  nop [rax+rax*1], ax
0000710a0d1da68b  nop [rax+rax*1], eax
0000710a0d1da693  mov eax, 0x410664
0000710a0d1da698  mov [r15+0x100], rax
0000710a0d1da69f  jmp 0x0000710A0CFFE110
0000710a0d1da6a4  cmp dword ptr [r15+0x318], 0x00
0000710a0d1da6ac  jz 0x0000710A0D1D6050
0000710a0d1da6b2  nop [rax+rax*1], ax
0000710a0d1da6bb  nop [rax+rax*1], eax
0000710a0d1da6c3  mov eax, 0x4104F0
0000710a0d1da6c8  mov [r15+0x100], rax
0000710a0d1da6cf  jmp 0x0000710A0CFFE110
0000710a0d1da6d4  int3
0000710a0d1da6d5  call 0x0000710A0D0E27E0
0000710a0d1da6da  jmp 0x0000710A0D1D9A10
0000710a0d1da6df  call 0x0000710A0D0E1570
0000710a0d1da6e4  jmp 0x0000710A0D1D9A19
0000710a0d1da6e9  call 0x0000710A0D0E27E0
0000710a0d1da6ee  jmp 0x0000710A0D1D9A62
0000710a0d1da6f3  call 0x0000710A0D0E1570
0000710a0d1da6f8  jmp 0x0000710A0D1D9A6B
0000710a0d1da6fd  call 0x0000710A0D0E27E0
0000710a0d1da702  jmp 0x0000710A0D1D9AEB
0000710a0d1da707  call 0x0000710A0D0E1570
0000710a0d1da70c  jmp 0x0000710A0D1D9AF4
0000710a0d1da711  call 0x0000710A0D00DC20
0000710a0d1da716  jmp 0x0000710A0D1D9BD5
0000710a0d1da71b  call 0x0000710A0D0D64F0
0000710a0d1da720  jmp 0x0000710A0D1D9C04
0000710a0d1da725  call 0x0000710A0D0B47C0
0000710a0d1da72a  jmp 0x0000710A0D1D9C1F
0000710a0d1da72f  sub rsp, 0x08
0000710a0d1da733  push rax
0000710a0d1da734  push rcx
0000710a0d1da735  push rdx
0000710a0d1da736  push rdi
0000710a0d1da737  push rsi
0000710a0d1da738  push r8
0000710a0d1da73a  push r9
0000710a0d1da73c  push r10
0000710a0d1da73e  push r11
0000710a0d1da740  sub rsp, 0xF0
0000710a0d1da747  vmovaps [rsp], xmm0
0000710a0d1da74c  vmovaps [rsp+0x10], xmm1
0000710a0d1da752  vmovaps [rsp+0x20], xmm2
0000710a0d1da758  vmovaps [rsp+0x30], xmm3
0000710a0d1da75e  vmovaps [rsp+0x40], xmm4
0000710a0d1da764  vmovaps [rsp+0x50], xmm5
0000710a0d1da76a  vmovaps [rsp+0x60], xmm6
0000710a0d1da770  vmovaps [rsp+0x70], xmm7
0000710a0d1da776  vmovaps [rsp+0x80], xmm8
0000710a0d1da77f  vmovaps [rsp+0x90], xmm9
0000710a0d1da788  vmovaps [rsp+0xA0], xmm10
0000710a0d1da791  vmovaps [rsp+0xB0], xmm11
0000710a0d1da79a  vmovaps [rsp+0xC0], xmm12
0000710a0d1da7a3  vmovaps [rsp+0xD0], xmm14
0000710a0d1da7ac  vmovaps [rsp+0xE0], xmm15
0000710a0d1da7b5  sub rsp, 0x40
0000710a0d1da7b9  lea rdi, [rsp]
0000710a0d1da7bd  lea rsi, [rsp+0x10]
0000710a0d1da7c2  lea rdx, [rsp+0x20]
0000710a0d1da7c7  lea rcx, [rsp+0x30]
0000710a0d1da7cc  mov r8d, 0x00
0000710a0d1da7d2  lea r9, [r15+0x3A8]
0000710a0d1da7d9  movaps [rdi], xmm13
0000710a0d1da7dd  movaps [rsi], xmm1
0000710a0d1da7e0  movaps [rdx], xmm15
0000710a0d1da7e4  movaps [rcx], xmm14
0000710a0d1da7e8  mov rax, 0x64F334B05A50
0000710a0d1da7f2  call rax
0000710a0d1da7f4  movaps xmm13, [rsp]
0000710a0d1da7f9  add rsp, 0x40
0000710a0d1da7fd  vmovaps xmm0, [rsp]
0000710a0d1da802  vmovaps xmm1, [rsp+0x10]
0000710a0d1da808  vmovaps xmm2, [rsp+0x20]
0000710a0d1da80e  vmovaps xmm3, [rsp+0x30]
0000710a0d1da814  vmovaps xmm4, [rsp+0x40]
0000710a0d1da81a  vmovaps xmm5, [rsp+0x50]
0000710a0d1da820  vmovaps xmm6, [rsp+0x60]
0000710a0d1da826  vmovaps xmm7, [rsp+0x70]
0000710a0d1da82c  vmovaps xmm8, [rsp+0x80]
0000710a0d1da835  vmovaps xmm9, [rsp+0x90]
0000710a0d1da83e  vmovaps xmm10, [rsp+0xA0]
0000710a0d1da847  vmovaps xmm11, [rsp+0xB0]
0000710a0d1da850  vmovaps xmm12, [rsp+0xC0]
0000710a0d1da859  vmovaps xmm14, [rsp+0xD0]
0000710a0d1da862  vmovaps xmm15, [rsp+0xE0]
0000710a0d1da86b  add rsp, 0xF0
0000710a0d1da872  pop r11
0000710a0d1da874  pop r10
0000710a0d1da876  pop r9
0000710a0d1da878  pop r8
0000710a0d1da87a  pop rsi
0000710a0d1da87b  pop rdi
0000710a0d1da87c  pop rdx
0000710a0d1da87d  pop rcx
0000710a0d1da87e  pop rax
0000710a0d1da87f  add rsp, 0x08
0000710a0d1da883  jmp 0x0000710A0D1D9C92
0000710a0d1da888  sub rsp, 0x08
0000710a0d1da88c  push rax
0000710a0d1da88d  push rcx
0000710a0d1da88e  push rdx
0000710a0d1da88f  push rdi
0000710a0d1da890  push rsi
0000710a0d1da891  push r8
0000710a0d1da893  push r9
0000710a0d1da895  push r10
0000710a0d1da897  push r11
0000710a0d1da899  sub rsp, 0xF0
0000710a0d1da8a0  vmovaps [rsp], xmm0
0000710a0d1da8a5  vmovaps [rsp+0x10], xmm1
0000710a0d1da8ab  vmovaps [rsp+0x20], xmm2
0000710a0d1da8b1  vmovaps [rsp+0x30], xmm3
0000710a0d1da8b7  vmovaps [rsp+0x40], xmm4
0000710a0d1da8bd  vmovaps [rsp+0x50], xmm5
0000710a0d1da8c3  vmovaps [rsp+0x60], xmm6
0000710a0d1da8c9  vmovaps [rsp+0x70], xmm7
0000710a0d1da8cf  vmovaps [rsp+0x80], xmm8
0000710a0d1da8d8  vmovaps [rsp+0x90], xmm9
0000710a0d1da8e1  vmovaps [rsp+0xA0], xmm10
0000710a0d1da8ea  vmovaps [rsp+0xB0], xmm11
0000710a0d1da8f3  vmovaps [rsp+0xC0], xmm13
0000710a0d1da8fc  vmovaps [rsp+0xD0], xmm14
0000710a0d1da905  vmovaps [rsp+0xE0], xmm15
0000710a0d1da90e  sub rsp, 0x40
0000710a0d1da912  lea rdi, [rsp]
0000710a0d1da916  lea rsi, [rsp+0x10]
0000710a0d1da91b  lea rdx, [rsp+0x20]
0000710a0d1da920  lea rcx, [rsp+0x30]
0000710a0d1da925  mov r8d, 0x00
0000710a0d1da92b  lea r9, [r15+0x3A8]
0000710a0d1da932  movaps [rdi], xmm12
0000710a0d1da936  movaps [rsi], xmm15
0000710a0d1da93a  movaps [rdx], xmm1
0000710a0d1da93d  movaps [rcx], xmm14
0000710a0d1da941  mov rax, 0x64F334B05A50
0000710a0d1da94b  call rax
0000710a0d1da94d  movaps xmm12, [rsp]
0000710a0d1da952  add rsp, 0x40
0000710a0d1da956  vmovaps xmm0, [rsp]
0000710a0d1da95b  vmovaps xmm1, [rsp+0x10]
0000710a0d1da961  vmovaps xmm2, [rsp+0x20]
0000710a0d1da967  vmovaps xmm3, [rsp+0x30]
0000710a0d1da96d  vmovaps xmm4, [rsp+0x40]
0000710a0d1da973  vmovaps xmm5, [rsp+0x50]
0000710a0d1da979  vmovaps xmm6, [rsp+0x60]
0000710a0d1da97f  vmovaps xmm7, [rsp+0x70]
0000710a0d1da985  vmovaps xmm8, [rsp+0x80]
0000710a0d1da98e  vmovaps xmm9, [rsp+0x90]
0000710a0d1da997  vmovaps xmm10, [rsp+0xA0]
0000710a0d1da9a0  vmovaps xmm11, [rsp+0xB0]
0000710a0d1da9a9  vmovaps xmm13, [rsp+0xC0]
0000710a0d1da9b2  vmovaps xmm14, [rsp+0xD0]
0000710a0d1da9bb  vmovaps xmm15, [rsp+0xE0]
0000710a0d1da9c4  add rsp, 0xF0
0000710a0d1da9cb  pop r11
0000710a0d1da9cd  pop r10
0000710a0d1da9cf  pop r9
0000710a0d1da9d1  pop r8
0000710a0d1da9d3  pop rsi
0000710a0d1da9d4  pop rdi
0000710a0d1da9d5  pop rdx
0000710a0d1da9d6  pop rcx
0000710a0d1da9d7  pop rax
0000710a0d1da9d8  add rsp, 0x08
0000710a0d1da9dc  jmp 0x0000710A0D1D9CC0
0000710a0d1da9e1  call 0x0000710A0D0B52F0
0000710a0d1da9e6  jmp 0x0000710A0D1D9DAC
0000710a0d1da9eb  sub rsp, 0x08
0000710a0d1da9ef  push rax
0000710a0d1da9f0  push rcx
0000710a0d1da9f1  push rdx
0000710a0d1da9f2  push rdi
0000710a0d1da9f3  push rsi
0000710a0d1da9f4  push r8
0000710a0d1da9f6  push r9
0000710a0d1da9f8  push r10
0000710a0d1da9fa  push r11
0000710a0d1da9fc  sub rsp, 0xF0
0000710a0d1daa03  vmovaps [rsp], xmm0
0000710a0d1daa08  vmovaps [rsp+0x10], xmm1
0000710a0d1daa0e  vmovaps [rsp+0x20], xmm2
0000710a0d1daa14  vmovaps [rsp+0x30], xmm3
0000710a0d1daa1a  vmovaps [rsp+0x40], xmm4
0000710a0d1daa20  vmovaps [rsp+0x50], xmm5
0000710a0d1daa26  vmovaps [rsp+0x60], xmm6
0000710a0d1daa2c  vmovaps [rsp+0x70], xmm7
0000710a0d1daa32  vmovaps [rsp+0x80], xmm8
0000710a0d1daa3b  vmovaps [rsp+0x90], xmm9
0000710a0d1daa44  vmovaps [rsp+0xA0], xmm10
0000710a0d1daa4d  vmovaps [rsp+0xB0], xmm11
0000710a0d1daa56  vmovaps [rsp+0xC0], xmm12
0000710a0d1daa5f  vmovaps [rsp+0xD0], xmm14
0000710a0d1daa68  vmovaps [rsp+0xE0], xmm15
0000710a0d1daa71  sub rsp, 0x40
0000710a0d1daa75  lea rdi, [rsp]
0000710a0d1daa79  lea rsi, [rsp+0x10]
0000710a0d1daa7e  lea rdx, [rsp+0x20]
0000710a0d1daa83  lea rcx, [rsp+0x30]
0000710a0d1daa88  mov r8d, 0x00
0000710a0d1daa8e  lea r9, [r15+0x3A8]
0000710a0d1daa95  movaps [rdi], xmm13
0000710a0d1daa99  movaps [rsi], xmm1
0000710a0d1daa9c  movaps [rdx], xmm15
0000710a0d1daaa0  movaps [rcx], xmm14
0000710a0d1daaa4  mov rax, 0x64F334B05A50
0000710a0d1daaae  call rax
0000710a0d1daab0  movaps xmm13, [rsp]
0000710a0d1daab5  add rsp, 0x40
0000710a0d1daab9  vmovaps xmm0, [rsp]
0000710a0d1daabe  vmovaps xmm1, [rsp+0x10]
0000710a0d1daac4  vmovaps xmm2, [rsp+0x20]
0000710a0d1daaca  vmovaps xmm3, [rsp+0x30]
0000710a0d1daad0  vmovaps xmm4, [rsp+0x40]
0000710a0d1daad6  vmovaps xmm5, [rsp+0x50]
0000710a0d1daadc  vmovaps xmm6, [rsp+0x60]
0000710a0d1daae2  vmovaps xmm7, [rsp+0x70]
0000710a0d1daae8  vmovaps xmm8, [rsp+0x80]
0000710a0d1daaf1  vmovaps xmm9, [rsp+0x90]
0000710a0d1daafa  vmovaps xmm10, [rsp+0xA0]
0000710a0d1dab03  vmovaps xmm11, [rsp+0xB0]
0000710a0d1dab0c  vmovaps xmm12, [rsp+0xC0]
0000710a0d1dab15  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dab1e  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dab27  add rsp, 0xF0
0000710a0d1dab2e  pop r11
0000710a0d1dab30  pop r10
0000710a0d1dab32  pop r9
0000710a0d1dab34  pop r8
0000710a0d1dab36  pop rsi
0000710a0d1dab37  pop rdi
0000710a0d1dab38  pop rdx
0000710a0d1dab39  pop rcx
0000710a0d1dab3a  pop rax
0000710a0d1dab3b  add rsp, 0x08
0000710a0d1dab3f  jmp 0x0000710A0D1D9E21
0000710a0d1dab44  call 0x0000710A0CFFF430
0000710a0d1dab49  jmp 0x0000710A0D1D9E2E
0000710a0d1dab4e  sub rsp, 0x08
0000710a0d1dab52  push rax
0000710a0d1dab53  push rcx
0000710a0d1dab54  push rdx
0000710a0d1dab55  push rdi
0000710a0d1dab56  push rsi
0000710a0d1dab57  push r8
0000710a0d1dab59  push r9
0000710a0d1dab5b  push r10
0000710a0d1dab5d  push r11
0000710a0d1dab5f  sub rsp, 0xF0
0000710a0d1dab66  vmovaps [rsp], xmm0
0000710a0d1dab6b  vmovaps [rsp+0x10], xmm1
0000710a0d1dab71  vmovaps [rsp+0x20], xmm2
0000710a0d1dab77  vmovaps [rsp+0x30], xmm3
0000710a0d1dab7d  vmovaps [rsp+0x40], xmm4
0000710a0d1dab83  vmovaps [rsp+0x50], xmm5
0000710a0d1dab89  vmovaps [rsp+0x60], xmm6
0000710a0d1dab8f  vmovaps [rsp+0x70], xmm7
0000710a0d1dab95  vmovaps [rsp+0x80], xmm8
0000710a0d1dab9e  vmovaps [rsp+0x90], xmm9
0000710a0d1daba7  vmovaps [rsp+0xA0], xmm10
0000710a0d1dabb0  vmovaps [rsp+0xB0], xmm11
0000710a0d1dabb9  vmovaps [rsp+0xC0], xmm13
0000710a0d1dabc2  vmovaps [rsp+0xD0], xmm14
0000710a0d1dabcb  vmovaps [rsp+0xE0], xmm15
0000710a0d1dabd4  sub rsp, 0x40
0000710a0d1dabd8  lea rdi, [rsp]
0000710a0d1dabdc  lea rsi, [rsp+0x10]
0000710a0d1dabe1  lea rdx, [rsp+0x20]
0000710a0d1dabe6  lea rcx, [rsp+0x30]
0000710a0d1dabeb  mov r8d, 0x00
0000710a0d1dabf1  lea r9, [r15+0x3A8]
0000710a0d1dabf8  movaps [rdi], xmm12
0000710a0d1dabfc  movaps [rsi], xmm15
0000710a0d1dac00  movaps [rdx], xmm1
0000710a0d1dac03  movaps [rcx], xmm14
0000710a0d1dac07  mov rax, 0x64F334B05A50
0000710a0d1dac11  call rax
0000710a0d1dac13  movaps xmm12, [rsp]
0000710a0d1dac18  add rsp, 0x40
0000710a0d1dac1c  vmovaps xmm0, [rsp]
0000710a0d1dac21  vmovaps xmm1, [rsp+0x10]
0000710a0d1dac27  vmovaps xmm2, [rsp+0x20]
0000710a0d1dac2d  vmovaps xmm3, [rsp+0x30]
0000710a0d1dac33  vmovaps xmm4, [rsp+0x40]
0000710a0d1dac39  vmovaps xmm5, [rsp+0x50]
0000710a0d1dac3f  vmovaps xmm6, [rsp+0x60]
0000710a0d1dac45  vmovaps xmm7, [rsp+0x70]
0000710a0d1dac4b  vmovaps xmm8, [rsp+0x80]
0000710a0d1dac54  vmovaps xmm9, [rsp+0x90]
0000710a0d1dac5d  vmovaps xmm10, [rsp+0xA0]
0000710a0d1dac66  vmovaps xmm11, [rsp+0xB0]
0000710a0d1dac6f  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dac78  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dac81  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dac8a  add rsp, 0xF0
0000710a0d1dac91  pop r11
0000710a0d1dac93  pop r10
0000710a0d1dac95  pop r9
0000710a0d1dac97  pop r8
0000710a0d1dac99  pop rsi
0000710a0d1dac9a  pop rdi
0000710a0d1dac9b  pop rdx
0000710a0d1dac9c  pop rcx
0000710a0d1dac9d  pop rax
0000710a0d1dac9e  add rsp, 0x08
0000710a0d1daca2  jmp 0x0000710A0D1D9E5A
0000710a0d1daca7  sub rsp, 0x08
0000710a0d1dacab  push rax
0000710a0d1dacac  push rcx
0000710a0d1dacad  push rdx
0000710a0d1dacae  push rdi
0000710a0d1dacaf  push rsi
0000710a0d1dacb0  push r8
0000710a0d1dacb2  push r9
0000710a0d1dacb4  push r10
0000710a0d1dacb6  push r11
0000710a0d1dacb8  sub rsp, 0xF0
0000710a0d1dacbf  vmovaps [rsp], xmm0
0000710a0d1dacc4  vmovaps [rsp+0x10], xmm1
0000710a0d1dacca  vmovaps [rsp+0x20], xmm2
0000710a0d1dacd0  vmovaps [rsp+0x30], xmm3
0000710a0d1dacd6  vmovaps [rsp+0x40], xmm4
0000710a0d1dacdc  vmovaps [rsp+0x50], xmm5
0000710a0d1dace2  vmovaps [rsp+0x60], xmm6
0000710a0d1dace8  vmovaps [rsp+0x70], xmm7
0000710a0d1dacee  vmovaps [rsp+0x80], xmm8
0000710a0d1dacf7  vmovaps [rsp+0x90], xmm9
0000710a0d1dad00  vmovaps [rsp+0xA0], xmm10
0000710a0d1dad09  vmovaps [rsp+0xB0], xmm11
0000710a0d1dad12  vmovaps [rsp+0xC0], xmm12
0000710a0d1dad1b  vmovaps [rsp+0xD0], xmm14
0000710a0d1dad24  vmovaps [rsp+0xE0], xmm15
0000710a0d1dad2d  sub rsp, 0x40
0000710a0d1dad31  lea rdi, [rsp]
0000710a0d1dad35  lea rsi, [rsp+0x10]
0000710a0d1dad3a  lea rdx, [rsp+0x20]
0000710a0d1dad3f  lea rcx, [rsp+0x30]
0000710a0d1dad44  mov r8d, 0x00
0000710a0d1dad4a  lea r9, [r15+0x3A8]
0000710a0d1dad51  movaps [rdi], xmm13
0000710a0d1dad55  movaps [rsi], xmm1
0000710a0d1dad58  movaps [rdx], xmm15
0000710a0d1dad5c  movaps [rcx], xmm14
0000710a0d1dad60  mov rax, 0x64F334B05A50
0000710a0d1dad6a  call rax
0000710a0d1dad6c  movaps xmm13, [rsp]
0000710a0d1dad71  add rsp, 0x40
0000710a0d1dad75  vmovaps xmm0, [rsp]
0000710a0d1dad7a  vmovaps xmm1, [rsp+0x10]
0000710a0d1dad80  vmovaps xmm2, [rsp+0x20]
0000710a0d1dad86  vmovaps xmm3, [rsp+0x30]
0000710a0d1dad8c  vmovaps xmm4, [rsp+0x40]
0000710a0d1dad92  vmovaps xmm5, [rsp+0x50]
0000710a0d1dad98  vmovaps xmm6, [rsp+0x60]
0000710a0d1dad9e  vmovaps xmm7, [rsp+0x70]
0000710a0d1dada4  vmovaps xmm8, [rsp+0x80]
0000710a0d1dadad  vmovaps xmm9, [rsp+0x90]
0000710a0d1dadb6  vmovaps xmm10, [rsp+0xA0]
0000710a0d1dadbf  vmovaps xmm11, [rsp+0xB0]
0000710a0d1dadc8  vmovaps xmm12, [rsp+0xC0]
0000710a0d1dadd1  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dadda  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dade3  add rsp, 0xF0
0000710a0d1dadea  pop r11
0000710a0d1dadec  pop r10
0000710a0d1dadee  pop r9
0000710a0d1dadf0  pop r8
0000710a0d1dadf2  pop rsi
0000710a0d1dadf3  pop rdi
0000710a0d1dadf4  pop rdx
0000710a0d1dadf5  pop rcx
0000710a0d1dadf6  pop rax
0000710a0d1dadf7  add rsp, 0x08
0000710a0d1dadfb  jmp 0x0000710A0D1D9FEA
0000710a0d1dae00  sub rsp, 0x08
0000710a0d1dae04  push rax
0000710a0d1dae05  push rcx
0000710a0d1dae06  push rdx
0000710a0d1dae07  push rdi
0000710a0d1dae08  push rsi
0000710a0d1dae09  push r8
0000710a0d1dae0b  push r9
0000710a0d1dae0d  push r10
0000710a0d1dae0f  push r11
0000710a0d1dae11  sub rsp, 0xF0
0000710a0d1dae18  vmovaps [rsp], xmm0
0000710a0d1dae1d  vmovaps [rsp+0x10], xmm1
0000710a0d1dae23  vmovaps [rsp+0x20], xmm2
0000710a0d1dae29  vmovaps [rsp+0x30], xmm3
0000710a0d1dae2f  vmovaps [rsp+0x40], xmm4
0000710a0d1dae35  vmovaps [rsp+0x50], xmm5
0000710a0d1dae3b  vmovaps [rsp+0x60], xmm6
0000710a0d1dae41  vmovaps [rsp+0x70], xmm7
0000710a0d1dae47  vmovaps [rsp+0x80], xmm8
0000710a0d1dae50  vmovaps [rsp+0x90], xmm9
0000710a0d1dae59  vmovaps [rsp+0xA0], xmm10
0000710a0d1dae62  vmovaps [rsp+0xB0], xmm11
0000710a0d1dae6b  vmovaps [rsp+0xC0], xmm12
0000710a0d1dae74  vmovaps [rsp+0xD0], xmm13
0000710a0d1dae7d  vmovaps [rsp+0xE0], xmm15
0000710a0d1dae86  sub rsp, 0x40
0000710a0d1dae8a  lea rdi, [rsp]
0000710a0d1dae8e  lea rsi, [rsp+0x10]
0000710a0d1dae93  lea rdx, [rsp+0x20]
0000710a0d1dae98  lea rcx, [rsp+0x30]
0000710a0d1dae9d  mov r8d, 0x00
0000710a0d1daea3  lea r9, [r15+0x3A8]
0000710a0d1daeaa  movaps [rdi], xmm14
0000710a0d1daeae  movaps [rsi], xmm15
0000710a0d1daeb2  movaps [rdx], xmm2
0000710a0d1daeb5  movaps [rcx], xmm1
0000710a0d1daeb8  mov rax, 0x64F334B05A50
0000710a0d1daec2  call rax
0000710a0d1daec4  movaps xmm14, [rsp]
0000710a0d1daec9  add rsp, 0x40
0000710a0d1daecd  vmovaps xmm0, [rsp]
0000710a0d1daed2  vmovaps xmm1, [rsp+0x10]
0000710a0d1daed8  vmovaps xmm2, [rsp+0x20]
0000710a0d1daede  vmovaps xmm3, [rsp+0x30]
0000710a0d1daee4  vmovaps xmm4, [rsp+0x40]
0000710a0d1daeea  vmovaps xmm5, [rsp+0x50]
0000710a0d1daef0  vmovaps xmm6, [rsp+0x60]
0000710a0d1daef6  vmovaps xmm7, [rsp+0x70]
0000710a0d1daefc  vmovaps xmm8, [rsp+0x80]
0000710a0d1daf05  vmovaps xmm9, [rsp+0x90]
0000710a0d1daf0e  vmovaps xmm10, [rsp+0xA0]
0000710a0d1daf17  vmovaps xmm11, [rsp+0xB0]
0000710a0d1daf20  vmovaps xmm12, [rsp+0xC0]
0000710a0d1daf29  vmovaps xmm13, [rsp+0xD0]
0000710a0d1daf32  vmovaps xmm15, [rsp+0xE0]
0000710a0d1daf3b  add rsp, 0xF0
0000710a0d1daf42  pop r11
0000710a0d1daf44  pop r10
0000710a0d1daf46  pop r9
0000710a0d1daf48  pop r8
0000710a0d1daf4a  pop rsi
0000710a0d1daf4b  pop rdi
0000710a0d1daf4c  pop rdx
0000710a0d1daf4d  pop rcx
0000710a0d1daf4e  pop rax
0000710a0d1daf4f  add rsp, 0x08
0000710a0d1daf53  jmp 0x0000710A0D1DA01C
0000710a0d1daf58  sub rsp, 0x08
0000710a0d1daf5c  push rax
0000710a0d1daf5d  push rcx
0000710a0d1daf5e  push rdx
0000710a0d1daf5f  push rdi
0000710a0d1daf60  push rsi
0000710a0d1daf61  push r8
0000710a0d1daf63  push r9
0000710a0d1daf65  push r10
0000710a0d1daf67  push r11
0000710a0d1daf69  sub rsp, 0xF0
0000710a0d1daf70  vmovaps [rsp], xmm0
0000710a0d1daf75  vmovaps [rsp+0x10], xmm1
0000710a0d1daf7b  vmovaps [rsp+0x20], xmm3
0000710a0d1daf81  vmovaps [rsp+0x30], xmm4
0000710a0d1daf87  vmovaps [rsp+0x40], xmm5
0000710a0d1daf8d  vmovaps [rsp+0x50], xmm6
0000710a0d1daf93  vmovaps [rsp+0x60], xmm7
0000710a0d1daf99  vmovaps [rsp+0x70], xmm8
0000710a0d1daf9f  vmovaps [rsp+0x80], xmm9
0000710a0d1dafa8  vmovaps [rsp+0x90], xmm10
0000710a0d1dafb1  vmovaps [rsp+0xA0], xmm11
0000710a0d1dafba  vmovaps [rsp+0xB0], xmm12
0000710a0d1dafc3  vmovaps [rsp+0xC0], xmm13
0000710a0d1dafcc  vmovaps [rsp+0xD0], xmm14
0000710a0d1dafd5  vmovaps [rsp+0xE0], xmm15
0000710a0d1dafde  sub rsp, 0x40
0000710a0d1dafe2  lea rdi, [rsp]
0000710a0d1dafe6  lea rsi, [rsp+0x10]
0000710a0d1dafeb  lea rdx, [rsp+0x20]
0000710a0d1daff0  lea rcx, [rsp+0x30]
0000710a0d1daff5  mov r8d, 0x00
0000710a0d1daffb  lea r9, [r15+0x3A8]
0000710a0d1db002  movaps [rdi], xmm2
0000710a0d1db005  movaps [rsi], xmm15
0000710a0d1db009  movaps [rdx], xmm12
0000710a0d1db00d  movaps [rcx], xmm1
0000710a0d1db010  mov rax, 0x64F334B05A50
0000710a0d1db01a  call rax
0000710a0d1db01c  movaps xmm2, [rsp]
0000710a0d1db020  add rsp, 0x40
0000710a0d1db024  vmovaps xmm0, [rsp]
0000710a0d1db029  vmovaps xmm1, [rsp+0x10]
0000710a0d1db02f  vmovaps xmm3, [rsp+0x20]
0000710a0d1db035  vmovaps xmm4, [rsp+0x30]
0000710a0d1db03b  vmovaps xmm5, [rsp+0x40]
0000710a0d1db041  vmovaps xmm6, [rsp+0x50]
0000710a0d1db047  vmovaps xmm7, [rsp+0x60]
0000710a0d1db04d  vmovaps xmm8, [rsp+0x70]
0000710a0d1db053  vmovaps xmm9, [rsp+0x80]
0000710a0d1db05c  vmovaps xmm10, [rsp+0x90]
0000710a0d1db065  vmovaps xmm11, [rsp+0xA0]
0000710a0d1db06e  vmovaps xmm12, [rsp+0xB0]
0000710a0d1db077  vmovaps xmm13, [rsp+0xC0]
0000710a0d1db080  vmovaps xmm14, [rsp+0xD0]
0000710a0d1db089  vmovaps xmm15, [rsp+0xE0]
0000710a0d1db092  add rsp, 0xF0
0000710a0d1db099  pop r11
0000710a0d1db09b  pop r10
0000710a0d1db09d  pop r9
0000710a0d1db09f  pop r8
0000710a0d1db0a1  pop rsi
0000710a0d1db0a2  pop rdi
0000710a0d1db0a3  pop rdx
0000710a0d1db0a4  pop rcx
0000710a0d1db0a5  pop rax
0000710a0d1db0a6  add rsp, 0x08
0000710a0d1db0aa  jmp 0x0000710A0D1DA059
0000710a0d1db0af  sub rsp, 0x08
0000710a0d1db0b3  push rax
0000710a0d1db0b4  push rcx
0000710a0d1db0b5  push rdx
0000710a0d1db0b6  push rdi
0000710a0d1db0b7  push rsi
0000710a0d1db0b8  push r8
0000710a0d1db0ba  push r9
0000710a0d1db0bc  push r10
0000710a0d1db0be  push r11
0000710a0d1db0c0  sub rsp, 0xF0
0000710a0d1db0c7  vmovaps [rsp], xmm0
0000710a0d1db0cc  vmovaps [rsp+0x10], xmm1
0000710a0d1db0d2  vmovaps [rsp+0x20], xmm2
0000710a0d1db0d8  vmovaps [rsp+0x30], xmm3
0000710a0d1db0de  vmovaps [rsp+0x40], xmm4
0000710a0d1db0e4  vmovaps [rsp+0x50], xmm5
0000710a0d1db0ea  vmovaps [rsp+0x60], xmm6
0000710a0d1db0f0  vmovaps [rsp+0x70], xmm7
0000710a0d1db0f6  vmovaps [rsp+0x80], xmm8
0000710a0d1db0ff  vmovaps [rsp+0x90], xmm9
0000710a0d1db108  vmovaps [rsp+0xA0], xmm10
0000710a0d1db111  vmovaps [rsp+0xB0], xmm11
0000710a0d1db11a  vmovaps [rsp+0xC0], xmm13
0000710a0d1db123  vmovaps [rsp+0xD0], xmm14
0000710a0d1db12c  vmovaps [rsp+0xE0], xmm15
0000710a0d1db135  sub rsp, 0x40
0000710a0d1db139  lea rdi, [rsp]
0000710a0d1db13d  lea rsi, [rsp+0x10]
0000710a0d1db142  lea rdx, [rsp+0x20]
0000710a0d1db147  lea rcx, [rsp+0x30]
0000710a0d1db14c  mov r8d, 0x00
0000710a0d1db152  lea r9, [r15+0x3A8]
0000710a0d1db159  movaps [rdi], xmm12
0000710a0d1db15d  movaps [rsi], xmm14
0000710a0d1db161  movaps [rdx], xmm3
0000710a0d1db164  movaps [rcx], xmm15
0000710a0d1db168  mov rax, 0x64F334B05A50
0000710a0d1db172  call rax
0000710a0d1db174  movaps xmm12, [rsp]
0000710a0d1db179  add rsp, 0x40
0000710a0d1db17d  vmovaps xmm0, [rsp]
0000710a0d1db182  vmovaps xmm1, [rsp+0x10]
0000710a0d1db188  vmovaps xmm2, [rsp+0x20]
0000710a0d1db18e  vmovaps xmm3, [rsp+0x30]
0000710a0d1db194  vmovaps xmm4, [rsp+0x40]
0000710a0d1db19a  vmovaps xmm5, [rsp+0x50]
0000710a0d1db1a0  vmovaps xmm6, [rsp+0x60]
0000710a0d1db1a6  vmovaps xmm7, [rsp+0x70]
0000710a0d1db1ac  vmovaps xmm8, [rsp+0x80]
0000710a0d1db1b5  vmovaps xmm9, [rsp+0x90]
0000710a0d1db1be  vmovaps xmm10, [rsp+0xA0]
0000710a0d1db1c7  vmovaps xmm11, [rsp+0xB0]
0000710a0d1db1d0  vmovaps xmm13, [rsp+0xC0]
0000710a0d1db1d9  vmovaps xmm14, [rsp+0xD0]
0000710a0d1db1e2  vmovaps xmm15, [rsp+0xE0]
0000710a0d1db1eb  add rsp, 0xF0
0000710a0d1db1f2  pop r11
0000710a0d1db1f4  pop r10
0000710a0d1db1f6  pop r9
0000710a0d1db1f8  pop r8
0000710a0d1db1fa  pop rsi
0000710a0d1db1fb  pop rdi
0000710a0d1db1fc  pop rdx
0000710a0d1db1fd  pop rcx
0000710a0d1db1fe  pop rax
0000710a0d1db1ff  add rsp, 0x08
0000710a0d1db203  jmp 0x0000710A0D1DA0B3
0000710a0d1db208  sub rsp, 0x08
0000710a0d1db20c  push rax
0000710a0d1db20d  push rcx
0000710a0d1db20e  push rdx
0000710a0d1db20f  push rdi
0000710a0d1db210  push rsi
0000710a0d1db211  push r8
0000710a0d1db213  push r9
0000710a0d1db215  push r10
0000710a0d1db217  push r11
0000710a0d1db219  sub rsp, 0xF0
0000710a0d1db220  vmovaps [rsp], xmm0
0000710a0d1db225  vmovaps [rsp+0x10], xmm1
0000710a0d1db22b  vmovaps [rsp+0x20], xmm2
0000710a0d1db231  vmovaps [rsp+0x30], xmm3
0000710a0d1db237  vmovaps [rsp+0x40], xmm4
0000710a0d1db23d  vmovaps [rsp+0x50], xmm5
0000710a0d1db243  vmovaps [rsp+0x60], xmm6
0000710a0d1db249  vmovaps [rsp+0x70], xmm7
0000710a0d1db24f  vmovaps [rsp+0x80], xmm8
0000710a0d1db258  vmovaps [rsp+0x90], xmm10
0000710a0d1db261  vmovaps [rsp+0xA0], xmm11
0000710a0d1db26a  vmovaps [rsp+0xB0], xmm12
0000710a0d1db273  vmovaps [rsp+0xC0], xmm13
0000710a0d1db27c  vmovaps [rsp+0xD0], xmm14
0000710a0d1db285  vmovaps [rsp+0xE0], xmm15
0000710a0d1db28e  sub rsp, 0x40
0000710a0d1db292  lea rdi, [rsp]
0000710a0d1db296  lea rsi, [rsp+0x10]
0000710a0d1db29b  lea rdx, [rsp+0x20]
0000710a0d1db2a0  lea rcx, [rsp+0x30]
0000710a0d1db2a5  mov r8d, 0x00
0000710a0d1db2ab  lea r9, [r15+0x3A8]
0000710a0d1db2b2  movaps [rdi], xmm9
0000710a0d1db2b6  movaps [rsi], xmm13
0000710a0d1db2ba  movaps [rdx], xmm14
0000710a0d1db2be  movaps [rcx], xmm6
0000710a0d1db2c1  mov rax, 0x64F334B05A50
0000710a0d1db2cb  call rax
0000710a0d1db2cd  movaps xmm9, [rsp]
0000710a0d1db2d2  add rsp, 0x40
0000710a0d1db2d6  vmovaps xmm0, [rsp]
0000710a0d1db2db  vmovaps xmm1, [rsp+0x10]
0000710a0d1db2e1  vmovaps xmm2, [rsp+0x20]
0000710a0d1db2e7  vmovaps xmm3, [rsp+0x30]
0000710a0d1db2ed  vmovaps xmm4, [rsp+0x40]
0000710a0d1db2f3  vmovaps xmm5, [rsp+0x50]
0000710a0d1db2f9  vmovaps xmm6, [rsp+0x60]
0000710a0d1db2ff  vmovaps xmm7, [rsp+0x70]
0000710a0d1db305  vmovaps xmm8, [rsp+0x80]
0000710a0d1db30e  vmovaps xmm10, [rsp+0x90]
0000710a0d1db317  vmovaps xmm11, [rsp+0xA0]
0000710a0d1db320  vmovaps xmm12, [rsp+0xB0]
0000710a0d1db329  vmovaps xmm13, [rsp+0xC0]
0000710a0d1db332  vmovaps xmm14, [rsp+0xD0]
0000710a0d1db33b  vmovaps xmm15, [rsp+0xE0]
0000710a0d1db344  add rsp, 0xF0
0000710a0d1db34b  pop r11
0000710a0d1db34d  pop r10
0000710a0d1db34f  pop r9
0000710a0d1db351  pop r8
0000710a0d1db353  pop rsi
0000710a0d1db354  pop rdi
0000710a0d1db355  pop rdx
0000710a0d1db356  pop rcx
0000710a0d1db357  pop rax
0000710a0d1db358  add rsp, 0x08
0000710a0d1db35c  jmp 0x0000710A0D1DA15D
0000710a0d1db361  sub rsp, 0x08
0000710a0d1db365  push rax
0000710a0d1db366  push rcx
0000710a0d1db367  push rdx
0000710a0d1db368  push rdi
0000710a0d1db369  push rsi
0000710a0d1db36a  push r8
0000710a0d1db36c  push r9
0000710a0d1db36e  push r10
0000710a0d1db370  push r11
0000710a0d1db372  sub rsp, 0xF0
0000710a0d1db379  vmovaps [rsp], xmm0
0000710a0d1db37e  vmovaps [rsp+0x10], xmm1
0000710a0d1db384  vmovaps [rsp+0x20], xmm2
0000710a0d1db38a  vmovaps [rsp+0x30], xmm4
0000710a0d1db390  vmovaps [rsp+0x40], xmm5
0000710a0d1db396  vmovaps [rsp+0x50], xmm6
0000710a0d1db39c  vmovaps [rsp+0x60], xmm7
0000710a0d1db3a2  vmovaps [rsp+0x70], xmm8
0000710a0d1db3a8  vmovaps [rsp+0x80], xmm9
0000710a0d1db3b1  vmovaps [rsp+0x90], xmm10
0000710a0d1db3ba  vmovaps [rsp+0xA0], xmm11
0000710a0d1db3c3  vmovaps [rsp+0xB0], xmm12
0000710a0d1db3cc  vmovaps [rsp+0xC0], xmm13
0000710a0d1db3d5  vmovaps [rsp+0xD0], xmm14
0000710a0d1db3de  vmovaps [rsp+0xE0], xmm15
0000710a0d1db3e7  sub rsp, 0x40
0000710a0d1db3eb  lea rdi, [rsp]
0000710a0d1db3ef  lea rsi, [rsp+0x10]
0000710a0d1db3f4  lea rdx, [rsp+0x20]
0000710a0d1db3f9  lea rcx, [rsp+0x30]
0000710a0d1db3fe  mov r8d, 0x00
0000710a0d1db404  lea r9, [r15+0x3A8]
0000710a0d1db40b  movaps [rdi], xmm3
0000710a0d1db40e  movaps [rsi], xmm13
0000710a0d1db412  movaps [rdx], xmm6
0000710a0d1db415  movaps [rcx], xmm14
0000710a0d1db419  mov rax, 0x64F334B05A50
0000710a0d1db423  call rax
0000710a0d1db425  movaps xmm3, [rsp]
0000710a0d1db429  add rsp, 0x40
0000710a0d1db42d  vmovaps xmm0, [rsp]
0000710a0d1db432  vmovaps xmm1, [rsp+0x10]
0000710a0d1db438  vmovaps xmm2, [rsp+0x20]
0000710a0d1db43e  vmovaps xmm4, [rsp+0x30]
0000710a0d1db444  vmovaps xmm5, [rsp+0x40]
0000710a0d1db44a  vmovaps xmm6, [rsp+0x50]
0000710a0d1db450  vmovaps xmm7, [rsp+0x60]
0000710a0d1db456  vmovaps xmm8, [rsp+0x70]
0000710a0d1db45c  vmovaps xmm9, [rsp+0x80]
0000710a0d1db465  vmovaps xmm10, [rsp+0x90]
0000710a0d1db46e  vmovaps xmm11, [rsp+0xA0]
0000710a0d1db477  vmovaps xmm12, [rsp+0xB0]
0000710a0d1db480  vmovaps xmm13, [rsp+0xC0]
0000710a0d1db489  vmovaps xmm14, [rsp+0xD0]
0000710a0d1db492  vmovaps xmm15, [rsp+0xE0]
0000710a0d1db49b  add rsp, 0xF0
0000710a0d1db4a2  pop r11
0000710a0d1db4a4  pop r10
0000710a0d1db4a6  pop r9
0000710a0d1db4a8  pop r8
0000710a0d1db4aa  pop rsi
0000710a0d1db4ab  pop rdi
0000710a0d1db4ac  pop rdx
0000710a0d1db4ad  pop rcx
0000710a0d1db4ae  pop rax
0000710a0d1db4af  add rsp, 0x08
0000710a0d1db4b3  jmp 0x0000710A0D1DA19A
0000710a0d1db4b8  sub rsp, 0x08
0000710a0d1db4bc  push rax
0000710a0d1db4bd  push rcx
0000710a0d1db4be  push rdx
0000710a0d1db4bf  push rdi
0000710a0d1db4c0  push rsi
0000710a0d1db4c1  push r8
0000710a0d1db4c3  push r9
0000710a0d1db4c5  push r10
0000710a0d1db4c7  push r11
0000710a0d1db4c9  sub rsp, 0xF0
0000710a0d1db4d0  vmovaps [rsp], xmm0
0000710a0d1db4d5  vmovaps [rsp+0x10], xmm1
0000710a0d1db4db  vmovaps [rsp+0x20], xmm2
0000710a0d1db4e1  vmovaps [rsp+0x30], xmm3
0000710a0d1db4e7  vmovaps [rsp+0x40], xmm4
0000710a0d1db4ed  vmovaps [rsp+0x50], xmm5
0000710a0d1db4f3  vmovaps [rsp+0x60], xmm7
0000710a0d1db4f9  vmovaps [rsp+0x70], xmm8
0000710a0d1db4ff  vmovaps [rsp+0x80], xmm9
0000710a0d1db508  vmovaps [rsp+0x90], xmm10
0000710a0d1db511  vmovaps [rsp+0xA0], xmm11
0000710a0d1db51a  vmovaps [rsp+0xB0], xmm12
0000710a0d1db523  vmovaps [rsp+0xC0], xmm13
0000710a0d1db52c  vmovaps [rsp+0xD0], xmm14
0000710a0d1db535  vmovaps [rsp+0xE0], xmm15
0000710a0d1db53e  sub rsp, 0x40
0000710a0d1db542  lea rdi, [rsp]
0000710a0d1db546  lea rsi, [rsp+0x10]
0000710a0d1db54b  lea rdx, [rsp+0x20]
0000710a0d1db550  lea rcx, [rsp+0x30]
0000710a0d1db555  mov r8d, 0x00
0000710a0d1db55b  lea r9, [r15+0x3A8]
0000710a0d1db562  movaps [rdi], xmm6
0000710a0d1db565  movaps [rsi], xmm2
0000710a0d1db568  movaps [rdx], xmm14
0000710a0d1db56c  movaps [rcx], xmm1
0000710a0d1db56f  mov rax, 0x64F334B05A50
0000710a0d1db579  call rax
0000710a0d1db57b  movaps xmm6, [rsp]
0000710a0d1db57f  add rsp, 0x40
0000710a0d1db583  vmovaps xmm0, [rsp]
0000710a0d1db588  vmovaps xmm1, [rsp+0x10]
0000710a0d1db58e  vmovaps xmm2, [rsp+0x20]
0000710a0d1db594  vmovaps xmm3, [rsp+0x30]
0000710a0d1db59a  vmovaps xmm4, [rsp+0x40]
0000710a0d1db5a0  vmovaps xmm5, [rsp+0x50]
0000710a0d1db5a6  vmovaps xmm7, [rsp+0x60]
0000710a0d1db5ac  vmovaps xmm8, [rsp+0x70]
0000710a0d1db5b2  vmovaps xmm9, [rsp+0x80]
0000710a0d1db5bb  vmovaps xmm10, [rsp+0x90]
0000710a0d1db5c4  vmovaps xmm11, [rsp+0xA0]
0000710a0d1db5cd  vmovaps xmm12, [rsp+0xB0]
0000710a0d1db5d6  vmovaps xmm13, [rsp+0xC0]
0000710a0d1db5df  vmovaps xmm14, [rsp+0xD0]
0000710a0d1db5e8  vmovaps xmm15, [rsp+0xE0]
0000710a0d1db5f1  add rsp, 0xF0
0000710a0d1db5f8  pop r11
0000710a0d1db5fa  pop r10
0000710a0d1db5fc  pop r9
0000710a0d1db5fe  pop r8
0000710a0d1db600  pop rsi
0000710a0d1db601  pop rdi
0000710a0d1db602  pop rdx
0000710a0d1db603  pop rcx
0000710a0d1db604  pop rax
0000710a0d1db605  add rsp, 0x08
0000710a0d1db609  jmp 0x0000710A0D1DA1C7
0000710a0d1db60e  sub rsp, 0x08
0000710a0d1db612  push rax
0000710a0d1db613  push rcx
0000710a0d1db614  push rdx
0000710a0d1db615  push rdi
0000710a0d1db616  push rsi
0000710a0d1db617  push r8
0000710a0d1db619  push r9
0000710a0d1db61b  push r10
0000710a0d1db61d  push r11
0000710a0d1db61f  sub rsp, 0xF0
0000710a0d1db626  vmovaps [rsp], xmm0
0000710a0d1db62b  vmovaps [rsp+0x10], xmm1
0000710a0d1db631  vmovaps [rsp+0x20], xmm2
0000710a0d1db637  vmovaps [rsp+0x30], xmm3
0000710a0d1db63d  vmovaps [rsp+0x40], xmm4
0000710a0d1db643  vmovaps [rsp+0x50], xmm5
0000710a0d1db649  vmovaps [rsp+0x60], xmm6
0000710a0d1db64f  vmovaps [rsp+0x70], xmm7
0000710a0d1db655  vmovaps [rsp+0x80], xmm8
0000710a0d1db65e  vmovaps [rsp+0x90], xmm9
0000710a0d1db667  vmovaps [rsp+0xA0], xmm10
0000710a0d1db670  vmovaps [rsp+0xB0], xmm11
0000710a0d1db679  vmovaps [rsp+0xC0], xmm12
0000710a0d1db682  vmovaps [rsp+0xD0], xmm14
0000710a0d1db68b  vmovaps [rsp+0xE0], xmm15
0000710a0d1db694  sub rsp, 0x40
0000710a0d1db698  lea rdi, [rsp]
0000710a0d1db69c  lea rsi, [rsp+0x10]
0000710a0d1db6a1  lea rdx, [rsp+0x20]
0000710a0d1db6a6  lea rcx, [rsp+0x30]
0000710a0d1db6ab  mov r8d, 0x00
0000710a0d1db6b1  lea r9, [r15+0x3A8]
0000710a0d1db6b8  movaps [rdi], xmm13
0000710a0d1db6bc  movaps [rsi], xmm12
0000710a0d1db6c0  movaps [rdx], xmm14
0000710a0d1db6c4  movaps [rcx], xmm1
0000710a0d1db6c7  mov rax, 0x64F334B05A50
0000710a0d1db6d1  call rax
0000710a0d1db6d3  movaps xmm13, [rsp]
0000710a0d1db6d8  add rsp, 0x40
0000710a0d1db6dc  vmovaps xmm0, [rsp]
0000710a0d1db6e1  vmovaps xmm1, [rsp+0x10]
0000710a0d1db6e7  vmovaps xmm2, [rsp+0x20]
0000710a0d1db6ed  vmovaps xmm3, [rsp+0x30]
0000710a0d1db6f3  vmovaps xmm4, [rsp+0x40]
0000710a0d1db6f9  vmovaps xmm5, [rsp+0x50]
0000710a0d1db6ff  vmovaps xmm6, [rsp+0x60]
0000710a0d1db705  vmovaps xmm7, [rsp+0x70]
0000710a0d1db70b  vmovaps xmm8, [rsp+0x80]
0000710a0d1db714  vmovaps xmm9, [rsp+0x90]
0000710a0d1db71d  vmovaps xmm10, [rsp+0xA0]
0000710a0d1db726  vmovaps xmm11, [rsp+0xB0]
0000710a0d1db72f  vmovaps xmm12, [rsp+0xC0]
0000710a0d1db738  vmovaps xmm14, [rsp+0xD0]
0000710a0d1db741  vmovaps xmm15, [rsp+0xE0]
0000710a0d1db74a  add rsp, 0xF0
0000710a0d1db751  pop r11
0000710a0d1db753  pop r10
0000710a0d1db755  pop r9
0000710a0d1db757  pop r8
0000710a0d1db759  pop rsi
0000710a0d1db75a  pop rdi
0000710a0d1db75b  pop rdx
0000710a0d1db75c  pop rcx
0000710a0d1db75d  pop rax
0000710a0d1db75e  add rsp, 0x08
0000710a0d1db762  jmp 0x0000710A0D1DA1F9
0000710a0d1db767  sub rsp, 0x08
0000710a0d1db76b  push rax
0000710a0d1db76c  push rcx
0000710a0d1db76d  push rdx
0000710a0d1db76e  push rdi
0000710a0d1db76f  push rsi
0000710a0d1db770  push r8
0000710a0d1db772  push r9
0000710a0d1db774  push r10
0000710a0d1db776  push r11
0000710a0d1db778  sub rsp, 0xF0
0000710a0d1db77f  vmovaps [rsp], xmm0
0000710a0d1db784  vmovaps [rsp+0x10], xmm1
0000710a0d1db78a  vmovaps [rsp+0x20], xmm2
0000710a0d1db790  vmovaps [rsp+0x30], xmm3
0000710a0d1db796  vmovaps [rsp+0x40], xmm4
0000710a0d1db79c  vmovaps [rsp+0x50], xmm5
0000710a0d1db7a2  vmovaps [rsp+0x60], xmm6
0000710a0d1db7a8  vmovaps [rsp+0x70], xmm7
0000710a0d1db7ae  vmovaps [rsp+0x80], xmm8
0000710a0d1db7b7  vmovaps [rsp+0x90], xmm9
0000710a0d1db7c0  vmovaps [rsp+0xA0], xmm10
0000710a0d1db7c9  vmovaps [rsp+0xB0], xmm11
0000710a0d1db7d2  vmovaps [rsp+0xC0], xmm13
0000710a0d1db7db  vmovaps [rsp+0xD0], xmm14
0000710a0d1db7e4  vmovaps [rsp+0xE0], xmm15
0000710a0d1db7ed  sub rsp, 0x40
0000710a0d1db7f1  lea rdi, [rsp]
0000710a0d1db7f5  lea rsi, [rsp+0x10]
0000710a0d1db7fa  lea rdx, [rsp+0x20]
0000710a0d1db7ff  lea rcx, [rsp+0x30]
0000710a0d1db804  mov r8d, 0x00
0000710a0d1db80a  lea r9, [r15+0x3A8]
0000710a0d1db811  movaps [rdi], xmm12
0000710a0d1db815  movaps [rsi], xmm3
0000710a0d1db818  movaps [rdx], xmm14
0000710a0d1db81c  movaps [rcx], xmm5
0000710a0d1db81f  mov rax, 0x64F334B05A50
0000710a0d1db829  call rax
0000710a0d1db82b  movaps xmm12, [rsp]
0000710a0d1db830  add rsp, 0x40
0000710a0d1db834  vmovaps xmm0, [rsp]
0000710a0d1db839  vmovaps xmm1, [rsp+0x10]
0000710a0d1db83f  vmovaps xmm2, [rsp+0x20]
0000710a0d1db845  vmovaps xmm3, [rsp+0x30]
0000710a0d1db84b  vmovaps xmm4, [rsp+0x40]
0000710a0d1db851  vmovaps xmm5, [rsp+0x50]
0000710a0d1db857  vmovaps xmm6, [rsp+0x60]
0000710a0d1db85d  vmovaps xmm7, [rsp+0x70]
0000710a0d1db863  vmovaps xmm8, [rsp+0x80]
0000710a0d1db86c  vmovaps xmm9, [rsp+0x90]
0000710a0d1db875  vmovaps xmm10, [rsp+0xA0]
0000710a0d1db87e  vmovaps xmm11, [rsp+0xB0]
0000710a0d1db887  vmovaps xmm13, [rsp+0xC0]
0000710a0d1db890  vmovaps xmm14, [rsp+0xD0]
0000710a0d1db899  vmovaps xmm15, [rsp+0xE0]
0000710a0d1db8a2  add rsp, 0xF0
0000710a0d1db8a9  pop r11
0000710a0d1db8ab  pop r10
0000710a0d1db8ad  pop r9
0000710a0d1db8af  pop r8
0000710a0d1db8b1  pop rsi
0000710a0d1db8b2  pop rdi
0000710a0d1db8b3  pop rdx
0000710a0d1db8b4  pop rcx
0000710a0d1db8b5  pop rax
0000710a0d1db8b6  add rsp, 0x08
0000710a0d1db8ba  jmp 0x0000710A0D1DA256
0000710a0d1db8bf  sub rsp, 0x08
0000710a0d1db8c3  push rax
0000710a0d1db8c4  push rcx
0000710a0d1db8c5  push rdx
0000710a0d1db8c6  push rdi
0000710a0d1db8c7  push rsi
0000710a0d1db8c8  push r8
0000710a0d1db8ca  push r9
0000710a0d1db8cc  push r10
0000710a0d1db8ce  push r11
0000710a0d1db8d0  sub rsp, 0xF0
0000710a0d1db8d7  vmovaps [rsp], xmm0
0000710a0d1db8dc  vmovaps [rsp+0x10], xmm1
0000710a0d1db8e2  vmovaps [rsp+0x20], xmm2
0000710a0d1db8e8  vmovaps [rsp+0x30], xmm3
0000710a0d1db8ee  vmovaps [rsp+0x40], xmm4
0000710a0d1db8f4  vmovaps [rsp+0x50], xmm5
0000710a0d1db8fa  vmovaps [rsp+0x60], xmm6
0000710a0d1db900  vmovaps [rsp+0x70], xmm7
0000710a0d1db906  vmovaps [rsp+0x80], xmm8
0000710a0d1db90f  vmovaps [rsp+0x90], xmm9
0000710a0d1db918  vmovaps [rsp+0xA0], xmm11
0000710a0d1db921  vmovaps [rsp+0xB0], xmm12
0000710a0d1db92a  vmovaps [rsp+0xC0], xmm13
0000710a0d1db933  vmovaps [rsp+0xD0], xmm14
0000710a0d1db93c  vmovaps [rsp+0xE0], xmm15
0000710a0d1db945  sub rsp, 0x40
0000710a0d1db949  lea rdi, [rsp]
0000710a0d1db94d  lea rsi, [rsp+0x10]
0000710a0d1db952  lea rdx, [rsp+0x20]
0000710a0d1db957  lea rcx, [rsp+0x30]
0000710a0d1db95c  mov r8d, 0x00
0000710a0d1db962  lea r9, [r15+0x3A8]
0000710a0d1db969  movaps [rdi], xmm10
0000710a0d1db96d  movaps [rsi], xmm9
0000710a0d1db971  movaps [rdx], xmm7
0000710a0d1db974  movaps [rcx], xmm14
0000710a0d1db978  mov rax, 0x64F334B05A50
0000710a0d1db982  call rax
0000710a0d1db984  movaps xmm10, [rsp]
0000710a0d1db989  add rsp, 0x40
0000710a0d1db98d  vmovaps xmm0, [rsp]
0000710a0d1db992  vmovaps xmm1, [rsp+0x10]
0000710a0d1db998  vmovaps xmm2, [rsp+0x20]
0000710a0d1db99e  vmovaps xmm3, [rsp+0x30]
0000710a0d1db9a4  vmovaps xmm4, [rsp+0x40]
0000710a0d1db9aa  vmovaps xmm5, [rsp+0x50]
0000710a0d1db9b0  vmovaps xmm6, [rsp+0x60]
0000710a0d1db9b6  vmovaps xmm7, [rsp+0x70]
0000710a0d1db9bc  vmovaps xmm8, [rsp+0x80]
0000710a0d1db9c5  vmovaps xmm9, [rsp+0x90]
0000710a0d1db9ce  vmovaps xmm11, [rsp+0xA0]
0000710a0d1db9d7  vmovaps xmm12, [rsp+0xB0]
0000710a0d1db9e0  vmovaps xmm13, [rsp+0xC0]
0000710a0d1db9e9  vmovaps xmm14, [rsp+0xD0]
0000710a0d1db9f2  vmovaps xmm15, [rsp+0xE0]
0000710a0d1db9fb  add rsp, 0xF0
0000710a0d1dba02  pop r11
0000710a0d1dba04  pop r10
0000710a0d1dba06  pop r9
0000710a0d1dba08  pop r8
0000710a0d1dba0a  pop rsi
0000710a0d1dba0b  pop rdi
0000710a0d1dba0c  pop rdx
0000710a0d1dba0d  pop rcx
0000710a0d1dba0e  pop rax
0000710a0d1dba0f  add rsp, 0x08
0000710a0d1dba13  jmp 0x0000710A0D1DA27C
0000710a0d1dba18  call 0x0000710A0D00D4E0
0000710a0d1dba1d  jmp 0x0000710A0D1DA289
0000710a0d1dba22  sub rsp, 0x08
0000710a0d1dba26  push rax
0000710a0d1dba27  push rcx
0000710a0d1dba28  push rdx
0000710a0d1dba29  push rdi
0000710a0d1dba2a  push rsi
0000710a0d1dba2b  push r8
0000710a0d1dba2d  push r9
0000710a0d1dba2f  push r10
0000710a0d1dba31  push r11
0000710a0d1dba33  sub rsp, 0xF0
0000710a0d1dba3a  vmovaps [rsp], xmm0
0000710a0d1dba3f  vmovaps [rsp+0x10], xmm1
0000710a0d1dba45  vmovaps [rsp+0x20], xmm2
0000710a0d1dba4b  vmovaps [rsp+0x30], xmm3
0000710a0d1dba51  vmovaps [rsp+0x40], xmm4
0000710a0d1dba57  vmovaps [rsp+0x50], xmm6
0000710a0d1dba5d  vmovaps [rsp+0x60], xmm7
0000710a0d1dba63  vmovaps [rsp+0x70], xmm8
0000710a0d1dba69  vmovaps [rsp+0x80], xmm9
0000710a0d1dba72  vmovaps [rsp+0x90], xmm10
0000710a0d1dba7b  vmovaps [rsp+0xA0], xmm11
0000710a0d1dba84  vmovaps [rsp+0xB0], xmm12
0000710a0d1dba8d  vmovaps [rsp+0xC0], xmm13
0000710a0d1dba96  vmovaps [rsp+0xD0], xmm14
0000710a0d1dba9f  vmovaps [rsp+0xE0], xmm15
0000710a0d1dbaa8  sub rsp, 0x40
0000710a0d1dbaac  lea rdi, [rsp]
0000710a0d1dbab0  lea rsi, [rsp+0x10]
0000710a0d1dbab5  lea rdx, [rsp+0x20]
0000710a0d1dbaba  lea rcx, [rsp+0x30]
0000710a0d1dbabf  mov r8d, 0x00
0000710a0d1dbac5  lea r9, [r15+0x3A8]
0000710a0d1dbacc  movaps [rdi], xmm5
0000710a0d1dbacf  movaps [rsi], xmm6
0000710a0d1dbad2  movaps [rdx], xmm7
0000710a0d1dbad5  movaps [rcx], xmm9
0000710a0d1dbad9  mov rax, 0x64F334B05A50
0000710a0d1dbae3  call rax
0000710a0d1dbae5  movaps xmm5, [rsp]
0000710a0d1dbae9  add rsp, 0x40
0000710a0d1dbaed  vmovaps xmm0, [rsp]
0000710a0d1dbaf2  vmovaps xmm1, [rsp+0x10]
0000710a0d1dbaf8  vmovaps xmm2, [rsp+0x20]
0000710a0d1dbafe  vmovaps xmm3, [rsp+0x30]
0000710a0d1dbb04  vmovaps xmm4, [rsp+0x40]
0000710a0d1dbb0a  vmovaps xmm6, [rsp+0x50]
0000710a0d1dbb10  vmovaps xmm7, [rsp+0x60]
0000710a0d1dbb16  vmovaps xmm8, [rsp+0x70]
0000710a0d1dbb1c  vmovaps xmm9, [rsp+0x80]
0000710a0d1dbb25  vmovaps xmm10, [rsp+0x90]
0000710a0d1dbb2e  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dbb37  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dbb40  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dbb49  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dbb52  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dbb5b  add rsp, 0xF0
0000710a0d1dbb62  pop r11
0000710a0d1dbb64  pop r10
0000710a0d1dbb66  pop r9
0000710a0d1dbb68  pop r8
0000710a0d1dbb6a  pop rsi
0000710a0d1dbb6b  pop rdi
0000710a0d1dbb6c  pop rdx
0000710a0d1dbb6d  pop rcx
0000710a0d1dbb6e  pop rax
0000710a0d1dbb6f  add rsp, 0x08
0000710a0d1dbb73  jmp 0x0000710A0D1DA2BB
0000710a0d1dbb78  sub rsp, 0x08
0000710a0d1dbb7c  push rax
0000710a0d1dbb7d  push rcx
0000710a0d1dbb7e  push rdx
0000710a0d1dbb7f  push rdi
0000710a0d1dbb80  push rsi
0000710a0d1dbb81  push r8
0000710a0d1dbb83  push r9
0000710a0d1dbb85  push r10
0000710a0d1dbb87  push r11
0000710a0d1dbb89  sub rsp, 0xF0
0000710a0d1dbb90  vmovaps [rsp], xmm0
0000710a0d1dbb95  vmovaps [rsp+0x10], xmm1
0000710a0d1dbb9b  vmovaps [rsp+0x20], xmm2
0000710a0d1dbba1  vmovaps [rsp+0x30], xmm3
0000710a0d1dbba7  vmovaps [rsp+0x40], xmm4
0000710a0d1dbbad  vmovaps [rsp+0x50], xmm5
0000710a0d1dbbb3  vmovaps [rsp+0x60], xmm6
0000710a0d1dbbb9  vmovaps [rsp+0x70], xmm8
0000710a0d1dbbbf  vmovaps [rsp+0x80], xmm9
0000710a0d1dbbc8  vmovaps [rsp+0x90], xmm10
0000710a0d1dbbd1  vmovaps [rsp+0xA0], xmm11
0000710a0d1dbbda  vmovaps [rsp+0xB0], xmm12
0000710a0d1dbbe3  vmovaps [rsp+0xC0], xmm13
0000710a0d1dbbec  vmovaps [rsp+0xD0], xmm14
0000710a0d1dbbf5  vmovaps [rsp+0xE0], xmm15
0000710a0d1dbbfe  sub rsp, 0x40
0000710a0d1dbc02  lea rdi, [rsp]
0000710a0d1dbc06  lea rsi, [rsp+0x10]
0000710a0d1dbc0b  lea rdx, [rsp+0x20]
0000710a0d1dbc10  lea rcx, [rsp+0x30]
0000710a0d1dbc15  mov r8d, 0x00
0000710a0d1dbc1b  lea r9, [r15+0x3A8]
0000710a0d1dbc22  movaps [rdi], xmm7
0000710a0d1dbc25  movaps [rsi], xmm13
0000710a0d1dbc29  movaps [rdx], xmm1
0000710a0d1dbc2c  movaps [rcx], xmm9
0000710a0d1dbc30  mov rax, 0x64F334B05A50
0000710a0d1dbc3a  call rax
0000710a0d1dbc3c  movaps xmm7, [rsp]
0000710a0d1dbc40  add rsp, 0x40
0000710a0d1dbc44  vmovaps xmm0, [rsp]
0000710a0d1dbc49  vmovaps xmm1, [rsp+0x10]
0000710a0d1dbc4f  vmovaps xmm2, [rsp+0x20]
0000710a0d1dbc55  vmovaps xmm3, [rsp+0x30]
0000710a0d1dbc5b  vmovaps xmm4, [rsp+0x40]
0000710a0d1dbc61  vmovaps xmm5, [rsp+0x50]
0000710a0d1dbc67  vmovaps xmm6, [rsp+0x60]
0000710a0d1dbc6d  vmovaps xmm8, [rsp+0x70]
0000710a0d1dbc73  vmovaps xmm9, [rsp+0x80]
0000710a0d1dbc7c  vmovaps xmm10, [rsp+0x90]
0000710a0d1dbc85  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dbc8e  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dbc97  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dbca0  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dbca9  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dbcb2  add rsp, 0xF0
0000710a0d1dbcb9  pop r11
0000710a0d1dbcbb  pop r10
0000710a0d1dbcbd  pop r9
0000710a0d1dbcbf  pop r8
0000710a0d1dbcc1  pop rsi
0000710a0d1dbcc2  pop rdi
0000710a0d1dbcc3  pop rdx
0000710a0d1dbcc4  pop rcx
0000710a0d1dbcc5  pop rax
0000710a0d1dbcc6  add rsp, 0x08
0000710a0d1dbcca  jmp 0x0000710A0D1DA2E0
0000710a0d1dbccf  call 0x0000710A0D00C260
0000710a0d1dbcd4  jmp 0x0000710A0D1DA303
0000710a0d1dbcd9  call 0x0000710A0D007890
0000710a0d1dbcde  jmp 0x0000710A0D1DA30D
0000710a0d1dbce3  sub rsp, 0x08
0000710a0d1dbce7  push rax
0000710a0d1dbce8  push rcx
0000710a0d1dbce9  push rdx
0000710a0d1dbcea  push rdi
0000710a0d1dbceb  push rsi
0000710a0d1dbcec  push r8
0000710a0d1dbcee  push r9
0000710a0d1dbcf0  push r10
0000710a0d1dbcf2  push r11
0000710a0d1dbcf4  sub rsp, 0xF0
0000710a0d1dbcfb  vmovaps [rsp], xmm0
0000710a0d1dbd00  vmovaps [rsp+0x10], xmm1
0000710a0d1dbd06  vmovaps [rsp+0x20], xmm3
0000710a0d1dbd0c  vmovaps [rsp+0x30], xmm4
0000710a0d1dbd12  vmovaps [rsp+0x40], xmm5
0000710a0d1dbd18  vmovaps [rsp+0x50], xmm6
0000710a0d1dbd1e  vmovaps [rsp+0x60], xmm7
0000710a0d1dbd24  vmovaps [rsp+0x70], xmm8
0000710a0d1dbd2a  vmovaps [rsp+0x80], xmm9
0000710a0d1dbd33  vmovaps [rsp+0x90], xmm10
0000710a0d1dbd3c  vmovaps [rsp+0xA0], xmm11
0000710a0d1dbd45  vmovaps [rsp+0xB0], xmm12
0000710a0d1dbd4e  vmovaps [rsp+0xC0], xmm13
0000710a0d1dbd57  vmovaps [rsp+0xD0], xmm14
0000710a0d1dbd60  vmovaps [rsp+0xE0], xmm15
0000710a0d1dbd69  sub rsp, 0x40
0000710a0d1dbd6d  lea rdi, [rsp]
0000710a0d1dbd71  lea rsi, [rsp+0x10]
0000710a0d1dbd76  lea rdx, [rsp+0x20]
0000710a0d1dbd7b  lea rcx, [rsp+0x30]
0000710a0d1dbd80  mov r8d, 0x00
0000710a0d1dbd86  lea r9, [r15+0x3A8]
0000710a0d1dbd8d  movaps [rdi], xmm2
0000710a0d1dbd90  movaps [rsi], xmm12
0000710a0d1dbd94  movaps [rdx], xmm6
0000710a0d1dbd97  movaps [rcx], xmm3
0000710a0d1dbd9a  mov rax, 0x64F334B05A50
0000710a0d1dbda4  call rax
0000710a0d1dbda6  movaps xmm2, [rsp]
0000710a0d1dbdaa  add rsp, 0x40
0000710a0d1dbdae  vmovaps xmm0, [rsp]
0000710a0d1dbdb3  vmovaps xmm1, [rsp+0x10]
0000710a0d1dbdb9  vmovaps xmm3, [rsp+0x20]
0000710a0d1dbdbf  vmovaps xmm4, [rsp+0x30]
0000710a0d1dbdc5  vmovaps xmm5, [rsp+0x40]
0000710a0d1dbdcb  vmovaps xmm6, [rsp+0x50]
0000710a0d1dbdd1  vmovaps xmm7, [rsp+0x60]
0000710a0d1dbdd7  vmovaps xmm8, [rsp+0x70]
0000710a0d1dbddd  vmovaps xmm9, [rsp+0x80]
0000710a0d1dbde6  vmovaps xmm10, [rsp+0x90]
0000710a0d1dbdef  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dbdf8  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dbe01  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dbe0a  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dbe13  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dbe1c  add rsp, 0xF0
0000710a0d1dbe23  pop r11
0000710a0d1dbe25  pop r10
0000710a0d1dbe27  pop r9
0000710a0d1dbe29  pop r8
0000710a0d1dbe2b  pop rsi
0000710a0d1dbe2c  pop rdi
0000710a0d1dbe2d  pop rdx
0000710a0d1dbe2e  pop rcx
0000710a0d1dbe2f  pop rax
0000710a0d1dbe30  add rsp, 0x08
0000710a0d1dbe34  jmp 0x0000710A0D1DA353
0000710a0d1dbe39  sub rsp, 0x08
0000710a0d1dbe3d  push rax
0000710a0d1dbe3e  push rcx
0000710a0d1dbe3f  push rdx
0000710a0d1dbe40  push rdi
0000710a0d1dbe41  push rsi
0000710a0d1dbe42  push r8
0000710a0d1dbe44  push r9
0000710a0d1dbe46  push r10
0000710a0d1dbe48  push r11
0000710a0d1dbe4a  sub rsp, 0xF0
0000710a0d1dbe51  vmovaps [rsp], xmm0
0000710a0d1dbe56  vmovaps [rsp+0x10], xmm1
0000710a0d1dbe5c  vmovaps [rsp+0x20], xmm2
0000710a0d1dbe62  vmovaps [rsp+0x30], xmm3
0000710a0d1dbe68  vmovaps [rsp+0x40], xmm4
0000710a0d1dbe6e  vmovaps [rsp+0x50], xmm5
0000710a0d1dbe74  vmovaps [rsp+0x60], xmm7
0000710a0d1dbe7a  vmovaps [rsp+0x70], xmm8
0000710a0d1dbe80  vmovaps [rsp+0x80], xmm9
0000710a0d1dbe89  vmovaps [rsp+0x90], xmm10
0000710a0d1dbe92  vmovaps [rsp+0xA0], xmm11
0000710a0d1dbe9b  vmovaps [rsp+0xB0], xmm12
0000710a0d1dbea4  vmovaps [rsp+0xC0], xmm13
0000710a0d1dbead  vmovaps [rsp+0xD0], xmm14
0000710a0d1dbeb6  vmovaps [rsp+0xE0], xmm15
0000710a0d1dbebf  sub rsp, 0x40
0000710a0d1dbec3  lea rdi, [rsp]
0000710a0d1dbec7  lea rsi, [rsp+0x10]
0000710a0d1dbecc  lea rdx, [rsp+0x20]
0000710a0d1dbed1  lea rcx, [rsp+0x30]
0000710a0d1dbed6  mov r8d, 0x00
0000710a0d1dbedc  lea r9, [r15+0x3A8]
0000710a0d1dbee3  movaps [rdi], xmm6
0000710a0d1dbee6  movaps [rsi], xmm10
0000710a0d1dbeea  movaps [rdx], xmm12
0000710a0d1dbeee  movaps [rcx], xmm1
0000710a0d1dbef1  mov rax, 0x64F334B05A50
0000710a0d1dbefb  call rax
0000710a0d1dbefd  movaps xmm6, [rsp]
0000710a0d1dbf01  add rsp, 0x40
0000710a0d1dbf05  vmovaps xmm0, [rsp]
0000710a0d1dbf0a  vmovaps xmm1, [rsp+0x10]
0000710a0d1dbf10  vmovaps xmm2, [rsp+0x20]
0000710a0d1dbf16  vmovaps xmm3, [rsp+0x30]
0000710a0d1dbf1c  vmovaps xmm4, [rsp+0x40]
0000710a0d1dbf22  vmovaps xmm5, [rsp+0x50]
0000710a0d1dbf28  vmovaps xmm7, [rsp+0x60]
0000710a0d1dbf2e  vmovaps xmm8, [rsp+0x70]
0000710a0d1dbf34  vmovaps xmm9, [rsp+0x80]
0000710a0d1dbf3d  vmovaps xmm10, [rsp+0x90]
0000710a0d1dbf46  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dbf4f  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dbf58  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dbf61  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dbf6a  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dbf73  add rsp, 0xF0
0000710a0d1dbf7a  pop r11
0000710a0d1dbf7c  pop r10
0000710a0d1dbf7e  pop r9
0000710a0d1dbf80  pop r8
0000710a0d1dbf82  pop rsi
0000710a0d1dbf83  pop rdi
0000710a0d1dbf84  pop rdx
0000710a0d1dbf85  pop rcx
0000710a0d1dbf86  pop rax
0000710a0d1dbf87  add rsp, 0x08
0000710a0d1dbf8b  jmp 0x0000710A0D1DA381
0000710a0d1dbf90  sub rsp, 0x08
0000710a0d1dbf94  push rax
0000710a0d1dbf95  push rcx
0000710a0d1dbf96  push rdx
0000710a0d1dbf97  push rdi
0000710a0d1dbf98  push rsi
0000710a0d1dbf99  push r8
0000710a0d1dbf9b  push r9
0000710a0d1dbf9d  push r10
0000710a0d1dbf9f  push r11
0000710a0d1dbfa1  sub rsp, 0xF0
0000710a0d1dbfa8  vmovaps [rsp], xmm0
0000710a0d1dbfad  vmovaps [rsp+0x10], xmm1
0000710a0d1dbfb3  vmovaps [rsp+0x20], xmm2
0000710a0d1dbfb9  vmovaps [rsp+0x30], xmm3
0000710a0d1dbfbf  vmovaps [rsp+0x40], xmm4
0000710a0d1dbfc5  vmovaps [rsp+0x50], xmm5
0000710a0d1dbfcb  vmovaps [rsp+0x60], xmm6
0000710a0d1dbfd1  vmovaps [rsp+0x70], xmm7
0000710a0d1dbfd7  vmovaps [rsp+0x80], xmm8
0000710a0d1dbfe0  vmovaps [rsp+0x90], xmm9
0000710a0d1dbfe9  vmovaps [rsp+0xA0], xmm11
0000710a0d1dbff2  vmovaps [rsp+0xB0], xmm12
0000710a0d1dbffb  vmovaps [rsp+0xC0], xmm13
0000710a0d1dc004  vmovaps [rsp+0xD0], xmm14
0000710a0d1dc00d  vmovaps [rsp+0xE0], xmm15
0000710a0d1dc016  sub rsp, 0x40
0000710a0d1dc01a  lea rdi, [rsp]
0000710a0d1dc01e  lea rsi, [rsp+0x10]
0000710a0d1dc023  lea rdx, [rsp+0x20]
0000710a0d1dc028  lea rcx, [rsp+0x30]
0000710a0d1dc02d  mov r8d, 0x00
0000710a0d1dc033  lea r9, [r15+0x3A8]
0000710a0d1dc03a  movaps [rdi], xmm10
0000710a0d1dc03e  movaps [rsi], xmm5
0000710a0d1dc041  movaps [rdx], xmm12
0000710a0d1dc045  movaps [rcx], xmm1
0000710a0d1dc048  mov rax, 0x64F334B05A50
0000710a0d1dc052  call rax
0000710a0d1dc054  movaps xmm10, [rsp]
0000710a0d1dc059  add rsp, 0x40
0000710a0d1dc05d  vmovaps xmm0, [rsp]
0000710a0d1dc062  vmovaps xmm1, [rsp+0x10]
0000710a0d1dc068  vmovaps xmm2, [rsp+0x20]
0000710a0d1dc06e  vmovaps xmm3, [rsp+0x30]
0000710a0d1dc074  vmovaps xmm4, [rsp+0x40]
0000710a0d1dc07a  vmovaps xmm5, [rsp+0x50]
0000710a0d1dc080  vmovaps xmm6, [rsp+0x60]
0000710a0d1dc086  vmovaps xmm7, [rsp+0x70]
0000710a0d1dc08c  vmovaps xmm8, [rsp+0x80]
0000710a0d1dc095  vmovaps xmm9, [rsp+0x90]
0000710a0d1dc09e  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dc0a7  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dc0b0  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dc0b9  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dc0c2  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dc0cb  add rsp, 0xF0
0000710a0d1dc0d2  pop r11
0000710a0d1dc0d4  pop r10
0000710a0d1dc0d6  pop r9
0000710a0d1dc0d8  pop r8
0000710a0d1dc0da  pop rsi
0000710a0d1dc0db  pop rdi
0000710a0d1dc0dc  pop rdx
0000710a0d1dc0dd  pop rcx
0000710a0d1dc0de  pop rax
0000710a0d1dc0df  add rsp, 0x08
0000710a0d1dc0e3  jmp 0x0000710A0D1DA3B0
0000710a0d1dc0e8  sub rsp, 0x08
0000710a0d1dc0ec  push rax
0000710a0d1dc0ed  push rcx
0000710a0d1dc0ee  push rdx
0000710a0d1dc0ef  push rdi
0000710a0d1dc0f0  push rsi
0000710a0d1dc0f1  push r8
0000710a0d1dc0f3  push r9
0000710a0d1dc0f5  push r10
0000710a0d1dc0f7  push r11
0000710a0d1dc0f9  sub rsp, 0xF0
0000710a0d1dc100  vmovaps [rsp], xmm0
0000710a0d1dc105  vmovaps [rsp+0x10], xmm1
0000710a0d1dc10b  vmovaps [rsp+0x20], xmm2
0000710a0d1dc111  vmovaps [rsp+0x30], xmm3
0000710a0d1dc117  vmovaps [rsp+0x40], xmm4
0000710a0d1dc11d  vmovaps [rsp+0x50], xmm5
0000710a0d1dc123  vmovaps [rsp+0x60], xmm6
0000710a0d1dc129  vmovaps [rsp+0x70], xmm7
0000710a0d1dc12f  vmovaps [rsp+0x80], xmm8
0000710a0d1dc138  vmovaps [rsp+0x90], xmm9
0000710a0d1dc141  vmovaps [rsp+0xA0], xmm10
0000710a0d1dc14a  vmovaps [rsp+0xB0], xmm11
0000710a0d1dc153  vmovaps [rsp+0xC0], xmm13
0000710a0d1dc15c  vmovaps [rsp+0xD0], xmm14
0000710a0d1dc165  vmovaps [rsp+0xE0], xmm15
0000710a0d1dc16e  sub rsp, 0x40
0000710a0d1dc172  lea rdi, [rsp]
0000710a0d1dc176  lea rsi, [rsp+0x10]
0000710a0d1dc17b  lea rdx, [rsp+0x20]
0000710a0d1dc180  lea rcx, [rsp+0x30]
0000710a0d1dc185  mov r8d, 0x00
0000710a0d1dc18b  lea r9, [r15+0x3A8]
0000710a0d1dc192  movaps [rdi], xmm12
0000710a0d1dc196  movaps [rsi], xmm7
0000710a0d1dc199  movaps [rdx], xmm15
0000710a0d1dc19d  movaps [rcx], xmm1
0000710a0d1dc1a0  mov rax, 0x64F334B05A50
0000710a0d1dc1aa  call rax
0000710a0d1dc1ac  movaps xmm12, [rsp]
0000710a0d1dc1b1  add rsp, 0x40
0000710a0d1dc1b5  vmovaps xmm0, [rsp]
0000710a0d1dc1ba  vmovaps xmm1, [rsp+0x10]
0000710a0d1dc1c0  vmovaps xmm2, [rsp+0x20]
0000710a0d1dc1c6  vmovaps xmm3, [rsp+0x30]
0000710a0d1dc1cc  vmovaps xmm4, [rsp+0x40]
0000710a0d1dc1d2  vmovaps xmm5, [rsp+0x50]
0000710a0d1dc1d8  vmovaps xmm6, [rsp+0x60]
0000710a0d1dc1de  vmovaps xmm7, [rsp+0x70]
0000710a0d1dc1e4  vmovaps xmm8, [rsp+0x80]
0000710a0d1dc1ed  vmovaps xmm9, [rsp+0x90]
0000710a0d1dc1f6  vmovaps xmm10, [rsp+0xA0]
0000710a0d1dc1ff  vmovaps xmm11, [rsp+0xB0]
0000710a0d1dc208  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dc211  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dc21a  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dc223  add rsp, 0xF0
0000710a0d1dc22a  pop r11
0000710a0d1dc22c  pop r10
0000710a0d1dc22e  pop r9
0000710a0d1dc230  pop r8
0000710a0d1dc232  pop rsi
0000710a0d1dc233  pop rdi
0000710a0d1dc234  pop rdx
0000710a0d1dc235  pop rcx
0000710a0d1dc236  pop rax
0000710a0d1dc237  add rsp, 0x08
0000710a0d1dc23b  jmp 0x0000710A0D1DA3D9
0000710a0d1dc240  call 0x0000710A0CFFF430
0000710a0d1dc245  jmp 0x0000710A0D1DA3E3
0000710a0d1dc24a  call 0x0000710A0D00E760
0000710a0d1dc24f  jmp 0x0000710A0D1DA3ED
0000710a0d1dc254  sub rsp, 0x08
0000710a0d1dc258  push rax
0000710a0d1dc259  push rcx
0000710a0d1dc25a  push rdx
0000710a0d1dc25b  push rdi
0000710a0d1dc25c  push rsi
0000710a0d1dc25d  push r8
0000710a0d1dc25f  push r9
0000710a0d1dc261  push r10
0000710a0d1dc263  push r11
0000710a0d1dc265  sub rsp, 0xF0
0000710a0d1dc26c  vmovaps [rsp], xmm0
0000710a0d1dc271  vmovaps [rsp+0x10], xmm1
0000710a0d1dc277  vmovaps [rsp+0x20], xmm2
0000710a0d1dc27d  vmovaps [rsp+0x30], xmm3
0000710a0d1dc283  vmovaps [rsp+0x40], xmm4
0000710a0d1dc289  vmovaps [rsp+0x50], xmm5
0000710a0d1dc28f  vmovaps [rsp+0x60], xmm6
0000710a0d1dc295  vmovaps [rsp+0x70], xmm8
0000710a0d1dc29b  vmovaps [rsp+0x80], xmm9
0000710a0d1dc2a4  vmovaps [rsp+0x90], xmm10
0000710a0d1dc2ad  vmovaps [rsp+0xA0], xmm11
0000710a0d1dc2b6  vmovaps [rsp+0xB0], xmm12
0000710a0d1dc2bf  vmovaps [rsp+0xC0], xmm13
0000710a0d1dc2c8  vmovaps [rsp+0xD0], xmm14
0000710a0d1dc2d1  vmovaps [rsp+0xE0], xmm15
0000710a0d1dc2da  sub rsp, 0x40
0000710a0d1dc2de  lea rdi, [rsp]
0000710a0d1dc2e2  lea rsi, [rsp+0x10]
0000710a0d1dc2e7  lea rdx, [rsp+0x20]
0000710a0d1dc2ec  lea rcx, [rsp+0x30]
0000710a0d1dc2f1  mov r8d, 0x00
0000710a0d1dc2f7  lea r9, [r15+0x3A8]
0000710a0d1dc2fe  movaps [rdi], xmm7
0000710a0d1dc301  movaps [rsi], xmm2
0000710a0d1dc304  movaps [rdx], xmm9
0000710a0d1dc308  movaps [rcx], xmm11
0000710a0d1dc30c  mov rax, 0x64F334B05A50
0000710a0d1dc316  call rax
0000710a0d1dc318  movaps xmm7, [rsp]
0000710a0d1dc31c  add rsp, 0x40
0000710a0d1dc320  vmovaps xmm0, [rsp]
0000710a0d1dc325  vmovaps xmm1, [rsp+0x10]
0000710a0d1dc32b  vmovaps xmm2, [rsp+0x20]
0000710a0d1dc331  vmovaps xmm3, [rsp+0x30]
0000710a0d1dc337  vmovaps xmm4, [rsp+0x40]
0000710a0d1dc33d  vmovaps xmm5, [rsp+0x50]
0000710a0d1dc343  vmovaps xmm6, [rsp+0x60]
0000710a0d1dc349  vmovaps xmm8, [rsp+0x70]
0000710a0d1dc34f  vmovaps xmm9, [rsp+0x80]
0000710a0d1dc358  vmovaps xmm10, [rsp+0x90]
0000710a0d1dc361  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dc36a  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dc373  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dc37c  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dc385  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dc38e  add rsp, 0xF0
0000710a0d1dc395  pop r11
0000710a0d1dc397  pop r10
0000710a0d1dc399  pop r9
0000710a0d1dc39b  pop r8
0000710a0d1dc39d  pop rsi
0000710a0d1dc39e  pop rdi
0000710a0d1dc39f  pop rdx
0000710a0d1dc3a0  pop rcx
0000710a0d1dc3a1  pop rax
0000710a0d1dc3a2  add rsp, 0x08
0000710a0d1dc3a6  jmp 0x0000710A0D1DA421
0000710a0d1dc3ab  sub rsp, 0x08
0000710a0d1dc3af  push rax
0000710a0d1dc3b0  push rcx
0000710a0d1dc3b1  push rdx
0000710a0d1dc3b2  push rdi
0000710a0d1dc3b3  push rsi
0000710a0d1dc3b4  push r8
0000710a0d1dc3b6  push r9
0000710a0d1dc3b8  push r10
0000710a0d1dc3ba  push r11
0000710a0d1dc3bc  sub rsp, 0xF0
0000710a0d1dc3c3  vmovaps [rsp], xmm0
0000710a0d1dc3c8  vmovaps [rsp+0x10], xmm1
0000710a0d1dc3ce  vmovaps [rsp+0x20], xmm2
0000710a0d1dc3d4  vmovaps [rsp+0x30], xmm3
0000710a0d1dc3da  vmovaps [rsp+0x40], xmm4
0000710a0d1dc3e0  vmovaps [rsp+0x50], xmm5
0000710a0d1dc3e6  vmovaps [rsp+0x60], xmm6
0000710a0d1dc3ec  vmovaps [rsp+0x70], xmm7
0000710a0d1dc3f2  vmovaps [rsp+0x80], xmm8
0000710a0d1dc3fb  vmovaps [rsp+0x90], xmm10
0000710a0d1dc404  vmovaps [rsp+0xA0], xmm11
0000710a0d1dc40d  vmovaps [rsp+0xB0], xmm12
0000710a0d1dc416  vmovaps [rsp+0xC0], xmm13
0000710a0d1dc41f  vmovaps [rsp+0xD0], xmm14
0000710a0d1dc428  vmovaps [rsp+0xE0], xmm15
0000710a0d1dc431  sub rsp, 0x40
0000710a0d1dc435  lea rdi, [rsp]
0000710a0d1dc439  lea rsi, [rsp+0x10]
0000710a0d1dc43e  lea rdx, [rsp+0x20]
0000710a0d1dc443  lea rcx, [rsp+0x30]
0000710a0d1dc448  mov r8d, 0x00
0000710a0d1dc44e  lea r9, [r15+0x3A8]
0000710a0d1dc455  movaps [rdi], xmm9
0000710a0d1dc459  movaps [rsi], xmm6
0000710a0d1dc45c  movaps [rdx], xmm1
0000710a0d1dc45f  movaps [rcx], xmm11
0000710a0d1dc463  mov rax, 0x64F334B05A50
0000710a0d1dc46d  call rax
0000710a0d1dc46f  movaps xmm9, [rsp]
0000710a0d1dc474  add rsp, 0x40
0000710a0d1dc478  vmovaps xmm0, [rsp]
0000710a0d1dc47d  vmovaps xmm1, [rsp+0x10]
0000710a0d1dc483  vmovaps xmm2, [rsp+0x20]
0000710a0d1dc489  vmovaps xmm3, [rsp+0x30]
0000710a0d1dc48f  vmovaps xmm4, [rsp+0x40]
0000710a0d1dc495  vmovaps xmm5, [rsp+0x50]
0000710a0d1dc49b  vmovaps xmm6, [rsp+0x60]
0000710a0d1dc4a1  vmovaps xmm7, [rsp+0x70]
0000710a0d1dc4a7  vmovaps xmm8, [rsp+0x80]
0000710a0d1dc4b0  vmovaps xmm10, [rsp+0x90]
0000710a0d1dc4b9  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dc4c2  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dc4cb  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dc4d4  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dc4dd  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dc4e6  add rsp, 0xF0
0000710a0d1dc4ed  pop r11
0000710a0d1dc4ef  pop r10
0000710a0d1dc4f1  pop r9
0000710a0d1dc4f3  pop r8
0000710a0d1dc4f5  pop rsi
0000710a0d1dc4f6  pop rdi
0000710a0d1dc4f7  pop rdx
0000710a0d1dc4f8  pop rcx
0000710a0d1dc4f9  pop rax
0000710a0d1dc4fa  add rsp, 0x08
0000710a0d1dc4fe  jmp 0x0000710A0D1DA447
0000710a0d1dc503  sub rsp, 0x08
0000710a0d1dc507  push rax
0000710a0d1dc508  push rcx
0000710a0d1dc509  push rdx
0000710a0d1dc50a  push rdi
0000710a0d1dc50b  push rsi
0000710a0d1dc50c  push r8
0000710a0d1dc50e  push r9
0000710a0d1dc510  push r10
0000710a0d1dc512  push r11
0000710a0d1dc514  sub rsp, 0xF0
0000710a0d1dc51b  vmovaps [rsp], xmm0
0000710a0d1dc520  vmovaps [rsp+0x10], xmm1
0000710a0d1dc526  vmovaps [rsp+0x20], xmm2
0000710a0d1dc52c  vmovaps [rsp+0x30], xmm3
0000710a0d1dc532  vmovaps [rsp+0x40], xmm4
0000710a0d1dc538  vmovaps [rsp+0x50], xmm5
0000710a0d1dc53e  vmovaps [rsp+0x60], xmm6
0000710a0d1dc544  vmovaps [rsp+0x70], xmm7
0000710a0d1dc54a  vmovaps [rsp+0x80], xmm8
0000710a0d1dc553  vmovaps [rsp+0x90], xmm9
0000710a0d1dc55c  vmovaps [rsp+0xA0], xmm10
0000710a0d1dc565  vmovaps [rsp+0xB0], xmm12
0000710a0d1dc56e  vmovaps [rsp+0xC0], xmm13
0000710a0d1dc577  vmovaps [rsp+0xD0], xmm14
0000710a0d1dc580  vmovaps [rsp+0xE0], xmm15
0000710a0d1dc589  sub rsp, 0x40
0000710a0d1dc58d  lea rdi, [rsp]
0000710a0d1dc591  lea rsi, [rsp+0x10]
0000710a0d1dc596  lea rdx, [rsp+0x20]
0000710a0d1dc59b  lea rcx, [rsp+0x30]
0000710a0d1dc5a0  mov r8d, 0x00
0000710a0d1dc5a6  lea r9, [r15+0x3A8]
0000710a0d1dc5ad  movaps [rdi], xmm11
0000710a0d1dc5b1  movaps [rsi], xmm10
0000710a0d1dc5b5  movaps [rdx], xmm8
0000710a0d1dc5b9  movaps [rcx], xmm1
0000710a0d1dc5bc  mov rax, 0x64F334B05A50
0000710a0d1dc5c6  call rax
0000710a0d1dc5c8  movaps xmm11, [rsp]
0000710a0d1dc5cd  add rsp, 0x40
0000710a0d1dc5d1  vmovaps xmm0, [rsp]
0000710a0d1dc5d6  vmovaps xmm1, [rsp+0x10]
0000710a0d1dc5dc  vmovaps xmm2, [rsp+0x20]
0000710a0d1dc5e2  vmovaps xmm3, [rsp+0x30]
0000710a0d1dc5e8  vmovaps xmm4, [rsp+0x40]
0000710a0d1dc5ee  vmovaps xmm5, [rsp+0x50]
0000710a0d1dc5f4  vmovaps xmm6, [rsp+0x60]
0000710a0d1dc5fa  vmovaps xmm7, [rsp+0x70]
0000710a0d1dc600  vmovaps xmm8, [rsp+0x80]
0000710a0d1dc609  vmovaps xmm9, [rsp+0x90]
0000710a0d1dc612  vmovaps xmm10, [rsp+0xA0]
0000710a0d1dc61b  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dc624  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dc62d  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dc636  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dc63f  add rsp, 0xF0
0000710a0d1dc646  pop r11
0000710a0d1dc648  pop r10
0000710a0d1dc64a  pop r9
0000710a0d1dc64c  pop r8
0000710a0d1dc64e  pop rsi
0000710a0d1dc64f  pop rdi
0000710a0d1dc650  pop rdx
0000710a0d1dc651  pop rcx
0000710a0d1dc652  pop rax
0000710a0d1dc653  add rsp, 0x08
0000710a0d1dc657  jmp 0x0000710A0D1DA46D
0000710a0d1dc65c  sub rsp, 0x08
0000710a0d1dc660  push rax
0000710a0d1dc661  push rcx
0000710a0d1dc662  push rdx
0000710a0d1dc663  push rdi
0000710a0d1dc664  push rsi
0000710a0d1dc665  push r8
0000710a0d1dc667  push r9
0000710a0d1dc669  push r10
0000710a0d1dc66b  push r11
0000710a0d1dc66d  sub rsp, 0xF0
0000710a0d1dc674  vmovaps [rsp], xmm0
0000710a0d1dc679  vmovaps [rsp+0x10], xmm1
0000710a0d1dc67f  vmovaps [rsp+0x20], xmm2
0000710a0d1dc685  vmovaps [rsp+0x30], xmm3
0000710a0d1dc68b  vmovaps [rsp+0x40], xmm4
0000710a0d1dc691  vmovaps [rsp+0x50], xmm5
0000710a0d1dc697  vmovaps [rsp+0x60], xmm6
0000710a0d1dc69d  vmovaps [rsp+0x70], xmm7
0000710a0d1dc6a3  vmovaps [rsp+0x80], xmm8
0000710a0d1dc6ac  vmovaps [rsp+0x90], xmm9
0000710a0d1dc6b5  vmovaps [rsp+0xA0], xmm11
0000710a0d1dc6be  vmovaps [rsp+0xB0], xmm12
0000710a0d1dc6c7  vmovaps [rsp+0xC0], xmm13
0000710a0d1dc6d0  vmovaps [rsp+0xD0], xmm14
0000710a0d1dc6d9  vmovaps [rsp+0xE0], xmm15
0000710a0d1dc6e2  sub rsp, 0x40
0000710a0d1dc6e6  lea rdi, [rsp]
0000710a0d1dc6ea  lea rsi, [rsp+0x10]
0000710a0d1dc6ef  lea rdx, [rsp+0x20]
0000710a0d1dc6f4  lea rcx, [rsp+0x30]
0000710a0d1dc6f9  mov r8d, 0x00
0000710a0d1dc6ff  lea r9, [r15+0x3A8]
0000710a0d1dc706  movaps [rdi], xmm10
0000710a0d1dc70a  movaps [rsi], xmm12
0000710a0d1dc70e  movaps [rdx], xmm13
0000710a0d1dc712  movaps [rcx], xmm1
0000710a0d1dc715  mov rax, 0x64F334B05A50
0000710a0d1dc71f  call rax
0000710a0d1dc721  movaps xmm10, [rsp]
0000710a0d1dc726  add rsp, 0x40
0000710a0d1dc72a  vmovaps xmm0, [rsp]
0000710a0d1dc72f  vmovaps xmm1, [rsp+0x10]
0000710a0d1dc735  vmovaps xmm2, [rsp+0x20]
0000710a0d1dc73b  vmovaps xmm3, [rsp+0x30]
0000710a0d1dc741  vmovaps xmm4, [rsp+0x40]
0000710a0d1dc747  vmovaps xmm5, [rsp+0x50]
0000710a0d1dc74d  vmovaps xmm6, [rsp+0x60]
0000710a0d1dc753  vmovaps xmm7, [rsp+0x70]
0000710a0d1dc759  vmovaps xmm8, [rsp+0x80]
0000710a0d1dc762  vmovaps xmm9, [rsp+0x90]
0000710a0d1dc76b  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dc774  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dc77d  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dc786  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dc78f  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dc798  add rsp, 0xF0
0000710a0d1dc79f  pop r11
0000710a0d1dc7a1  pop r10
0000710a0d1dc7a3  pop r9
0000710a0d1dc7a5  pop r8
0000710a0d1dc7a7  pop rsi
0000710a0d1dc7a8  pop rdi
0000710a0d1dc7a9  pop rdx
0000710a0d1dc7aa  pop rcx
0000710a0d1dc7ab  pop rax
0000710a0d1dc7ac  add rsp, 0x08
0000710a0d1dc7b0  jmp 0x0000710A0D1DA493
0000710a0d1dc7b5  call 0x0000710A0CFFF430
0000710a0d1dc7ba  jmp 0x0000710A0D1DA49D
0000710a0d1dc7bf  call 0x0000710A0D00C260
0000710a0d1dc7c4  jmp 0x0000710A0D1DA4A7
0000710a0d1dc7c9  sub rsp, 0x08
0000710a0d1dc7cd  push rax
0000710a0d1dc7ce  push rcx
0000710a0d1dc7cf  push rdx
0000710a0d1dc7d0  push rdi
0000710a0d1dc7d1  push rsi
0000710a0d1dc7d2  push r8
0000710a0d1dc7d4  push r9
0000710a0d1dc7d6  push r10
0000710a0d1dc7d8  push r11
0000710a0d1dc7da  sub rsp, 0xF0
0000710a0d1dc7e1  vmovaps [rsp], xmm0
0000710a0d1dc7e6  vmovaps [rsp+0x10], xmm1
0000710a0d1dc7ec  vmovaps [rsp+0x20], xmm2
0000710a0d1dc7f2  vmovaps [rsp+0x30], xmm3
0000710a0d1dc7f8  vmovaps [rsp+0x40], xmm4
0000710a0d1dc7fe  vmovaps [rsp+0x50], xmm5
0000710a0d1dc804  vmovaps [rsp+0x60], xmm6
0000710a0d1dc80a  vmovaps [rsp+0x70], xmm7
0000710a0d1dc810  vmovaps [rsp+0x80], xmm9
0000710a0d1dc819  vmovaps [rsp+0x90], xmm10
0000710a0d1dc822  vmovaps [rsp+0xA0], xmm11
0000710a0d1dc82b  vmovaps [rsp+0xB0], xmm12
0000710a0d1dc834  vmovaps [rsp+0xC0], xmm13
0000710a0d1dc83d  vmovaps [rsp+0xD0], xmm14
0000710a0d1dc846  vmovaps [rsp+0xE0], xmm15
0000710a0d1dc84f  sub rsp, 0x40
0000710a0d1dc853  lea rdi, [rsp]
0000710a0d1dc857  lea rsi, [rsp+0x10]
0000710a0d1dc85c  lea rdx, [rsp+0x20]
0000710a0d1dc861  lea rcx, [rsp+0x30]
0000710a0d1dc866  mov r8d, 0x00
0000710a0d1dc86c  lea r9, [r15+0x3A8]
0000710a0d1dc873  movaps [rdi], xmm8
0000710a0d1dc877  movaps [rsi], xmm7
0000710a0d1dc87a  movaps [rdx], xmm4
0000710a0d1dc87d  movaps [rcx], xmm12
0000710a0d1dc881  mov rax, 0x64F334B05A50
0000710a0d1dc88b  call rax
0000710a0d1dc88d  movaps xmm8, [rsp]
0000710a0d1dc892  add rsp, 0x40
0000710a0d1dc896  vmovaps xmm0, [rsp]
0000710a0d1dc89b  vmovaps xmm1, [rsp+0x10]
0000710a0d1dc8a1  vmovaps xmm2, [rsp+0x20]
0000710a0d1dc8a7  vmovaps xmm3, [rsp+0x30]
0000710a0d1dc8ad  vmovaps xmm4, [rsp+0x40]
0000710a0d1dc8b3  vmovaps xmm5, [rsp+0x50]
0000710a0d1dc8b9  vmovaps xmm6, [rsp+0x60]
0000710a0d1dc8bf  vmovaps xmm7, [rsp+0x70]
0000710a0d1dc8c5  vmovaps xmm9, [rsp+0x80]
0000710a0d1dc8ce  vmovaps xmm10, [rsp+0x90]
0000710a0d1dc8d7  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dc8e0  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dc8e9  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dc8f2  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dc8fb  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dc904  add rsp, 0xF0
0000710a0d1dc90b  pop r11
0000710a0d1dc90d  pop r10
0000710a0d1dc90f  pop r9
0000710a0d1dc911  pop r8
0000710a0d1dc913  pop rsi
0000710a0d1dc914  pop rdi
0000710a0d1dc915  pop rdx
0000710a0d1dc916  pop rcx
0000710a0d1dc917  pop rax
0000710a0d1dc918  add rsp, 0x08
0000710a0d1dc91c  jmp 0x0000710A0D1DA4D0
0000710a0d1dc921  sub rsp, 0x08
0000710a0d1dc925  push rax
0000710a0d1dc926  push rcx
0000710a0d1dc927  push rdx
0000710a0d1dc928  push rdi
0000710a0d1dc929  push rsi
0000710a0d1dc92a  push r8
0000710a0d1dc92c  push r9
0000710a0d1dc92e  push r10
0000710a0d1dc930  push r11
0000710a0d1dc932  sub rsp, 0xF0
0000710a0d1dc939  vmovaps [rsp], xmm0
0000710a0d1dc93e  vmovaps [rsp+0x10], xmm1
0000710a0d1dc944  vmovaps [rsp+0x20], xmm2
0000710a0d1dc94a  vmovaps [rsp+0x30], xmm3
0000710a0d1dc950  vmovaps [rsp+0x40], xmm4
0000710a0d1dc956  vmovaps [rsp+0x50], xmm5
0000710a0d1dc95c  vmovaps [rsp+0x60], xmm6
0000710a0d1dc962  vmovaps [rsp+0x70], xmm8
0000710a0d1dc968  vmovaps [rsp+0x80], xmm9
0000710a0d1dc971  vmovaps [rsp+0x90], xmm10
0000710a0d1dc97a  vmovaps [rsp+0xA0], xmm11
0000710a0d1dc983  vmovaps [rsp+0xB0], xmm12
0000710a0d1dc98c  vmovaps [rsp+0xC0], xmm13
0000710a0d1dc995  vmovaps [rsp+0xD0], xmm14
0000710a0d1dc99e  vmovaps [rsp+0xE0], xmm15
0000710a0d1dc9a7  sub rsp, 0x40
0000710a0d1dc9ab  lea rdi, [rsp]
0000710a0d1dc9af  lea rsi, [rsp+0x10]
0000710a0d1dc9b4  lea rdx, [rsp+0x20]
0000710a0d1dc9b9  lea rcx, [rsp+0x30]
0000710a0d1dc9be  mov r8d, 0x00
0000710a0d1dc9c4  lea r9, [r15+0x3A8]
0000710a0d1dc9cb  movaps [rdi], xmm7
0000710a0d1dc9ce  movaps [rsi], xmm9
0000710a0d1dc9d2  movaps [rdx], xmm14
0000710a0d1dc9d6  movaps [rcx], xmm12
0000710a0d1dc9da  mov rax, 0x64F334B05A50
0000710a0d1dc9e4  call rax
0000710a0d1dc9e6  movaps xmm7, [rsp]
0000710a0d1dc9ea  add rsp, 0x40
0000710a0d1dc9ee  vmovaps xmm0, [rsp]
0000710a0d1dc9f3  vmovaps xmm1, [rsp+0x10]
0000710a0d1dc9f9  vmovaps xmm2, [rsp+0x20]
0000710a0d1dc9ff  vmovaps xmm3, [rsp+0x30]
0000710a0d1dca05  vmovaps xmm4, [rsp+0x40]
0000710a0d1dca0b  vmovaps xmm5, [rsp+0x50]
0000710a0d1dca11  vmovaps xmm6, [rsp+0x60]
0000710a0d1dca17  vmovaps xmm8, [rsp+0x70]
0000710a0d1dca1d  vmovaps xmm9, [rsp+0x80]
0000710a0d1dca26  vmovaps xmm10, [rsp+0x90]
0000710a0d1dca2f  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dca38  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dca41  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dca4a  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dca53  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dca5c  add rsp, 0xF0
0000710a0d1dca63  pop r11
0000710a0d1dca65  pop r10
0000710a0d1dca67  pop r9
0000710a0d1dca69  pop r8
0000710a0d1dca6b  pop rsi
0000710a0d1dca6c  pop rdi
0000710a0d1dca6d  pop rdx
0000710a0d1dca6e  pop rcx
0000710a0d1dca6f  pop rax
0000710a0d1dca70  add rsp, 0x08
0000710a0d1dca74  jmp 0x0000710A0D1DA4F8
0000710a0d1dca79  sub rsp, 0x08
0000710a0d1dca7d  push rax
0000710a0d1dca7e  push rcx
0000710a0d1dca7f  push rdx
0000710a0d1dca80  push rdi
0000710a0d1dca81  push rsi
0000710a0d1dca82  push r8
0000710a0d1dca84  push r9
0000710a0d1dca86  push r10
0000710a0d1dca88  push r11
0000710a0d1dca8a  sub rsp, 0xF0
0000710a0d1dca91  vmovaps [rsp], xmm0
0000710a0d1dca96  vmovaps [rsp+0x10], xmm1
0000710a0d1dca9c  vmovaps [rsp+0x20], xmm2
0000710a0d1dcaa2  vmovaps [rsp+0x30], xmm3
0000710a0d1dcaa8  vmovaps [rsp+0x40], xmm4
0000710a0d1dcaae  vmovaps [rsp+0x50], xmm5
0000710a0d1dcab4  vmovaps [rsp+0x60], xmm6
0000710a0d1dcaba  vmovaps [rsp+0x70], xmm7
0000710a0d1dcac0  vmovaps [rsp+0x80], xmm8
0000710a0d1dcac9  vmovaps [rsp+0x90], xmm9
0000710a0d1dcad2  vmovaps [rsp+0xA0], xmm10
0000710a0d1dcadb  vmovaps [rsp+0xB0], xmm11
0000710a0d1dcae4  vmovaps [rsp+0xC0], xmm13
0000710a0d1dcaed  vmovaps [rsp+0xD0], xmm14
0000710a0d1dcaf6  vmovaps [rsp+0xE0], xmm15
0000710a0d1dcaff  sub rsp, 0x40
0000710a0d1dcb03  lea rdi, [rsp]
0000710a0d1dcb07  lea rsi, [rsp+0x10]
0000710a0d1dcb0c  lea rdx, [rsp+0x20]
0000710a0d1dcb11  lea rcx, [rsp+0x30]
0000710a0d1dcb16  mov r8d, 0x00
0000710a0d1dcb1c  lea r9, [r15+0x3A8]
0000710a0d1dcb23  movaps [rdi], xmm12
0000710a0d1dcb27  movaps [rsi], xmm11
0000710a0d1dcb2b  movaps [rdx], xmm15
0000710a0d1dcb2f  movaps [rcx], xmm14
0000710a0d1dcb33  mov rax, 0x64F334B05A50
0000710a0d1dcb3d  call rax
0000710a0d1dcb3f  movaps xmm12, [rsp]
0000710a0d1dcb44  add rsp, 0x40
0000710a0d1dcb48  vmovaps xmm0, [rsp]
0000710a0d1dcb4d  vmovaps xmm1, [rsp+0x10]
0000710a0d1dcb53  vmovaps xmm2, [rsp+0x20]
0000710a0d1dcb59  vmovaps xmm3, [rsp+0x30]
0000710a0d1dcb5f  vmovaps xmm4, [rsp+0x40]
0000710a0d1dcb65  vmovaps xmm5, [rsp+0x50]
0000710a0d1dcb6b  vmovaps xmm6, [rsp+0x60]
0000710a0d1dcb71  vmovaps xmm7, [rsp+0x70]
0000710a0d1dcb77  vmovaps xmm8, [rsp+0x80]
0000710a0d1dcb80  vmovaps xmm9, [rsp+0x90]
0000710a0d1dcb89  vmovaps xmm10, [rsp+0xA0]
0000710a0d1dcb92  vmovaps xmm11, [rsp+0xB0]
0000710a0d1dcb9b  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dcba4  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dcbad  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dcbb6  add rsp, 0xF0
0000710a0d1dcbbd  pop r11
0000710a0d1dcbbf  pop r10
0000710a0d1dcbc1  pop r9
0000710a0d1dcbc3  pop r8
0000710a0d1dcbc5  pop rsi
0000710a0d1dcbc6  pop rdi
0000710a0d1dcbc7  pop rdx
0000710a0d1dcbc8  pop rcx
0000710a0d1dcbc9  pop rax
0000710a0d1dcbca  add rsp, 0x08
0000710a0d1dcbce  jmp 0x0000710A0D1DA521
0000710a0d1dcbd3  sub rsp, 0x08
0000710a0d1dcbd7  push rax
0000710a0d1dcbd8  push rcx
0000710a0d1dcbd9  push rdx
0000710a0d1dcbda  push rdi
0000710a0d1dcbdb  push rsi
0000710a0d1dcbdc  push r8
0000710a0d1dcbde  push r9
0000710a0d1dcbe0  push r10
0000710a0d1dcbe2  push r11
0000710a0d1dcbe4  sub rsp, 0xF0
0000710a0d1dcbeb  vmovaps [rsp], xmm0
0000710a0d1dcbf0  vmovaps [rsp+0x10], xmm1
0000710a0d1dcbf6  vmovaps [rsp+0x20], xmm2
0000710a0d1dcbfc  vmovaps [rsp+0x30], xmm3
0000710a0d1dcc02  vmovaps [rsp+0x40], xmm4
0000710a0d1dcc08  vmovaps [rsp+0x50], xmm5
0000710a0d1dcc0e  vmovaps [rsp+0x60], xmm6
0000710a0d1dcc14  vmovaps [rsp+0x70], xmm7
0000710a0d1dcc1a  vmovaps [rsp+0x80], xmm8
0000710a0d1dcc23  vmovaps [rsp+0x90], xmm9
0000710a0d1dcc2c  vmovaps [rsp+0xA0], xmm10
0000710a0d1dcc35  vmovaps [rsp+0xB0], xmm12
0000710a0d1dcc3e  vmovaps [rsp+0xC0], xmm13
0000710a0d1dcc47  vmovaps [rsp+0xD0], xmm14
0000710a0d1dcc50  vmovaps [rsp+0xE0], xmm15
0000710a0d1dcc59  sub rsp, 0x40
0000710a0d1dcc5d  lea rdi, [rsp]
0000710a0d1dcc61  lea rsi, [rsp+0x10]
0000710a0d1dcc66  lea rdx, [rsp+0x20]
0000710a0d1dcc6b  lea rcx, [rsp+0x30]
0000710a0d1dcc70  mov r8d, 0x00
0000710a0d1dcc76  lea r9, [r15+0x3A8]
0000710a0d1dcc7d  movaps [rdi], xmm11
0000710a0d1dcc81  movaps [rsi], xmm10
0000710a0d1dcc85  movaps [rdx], xmm13
0000710a0d1dcc89  movaps [rcx], xmm15
0000710a0d1dcc8d  mov rax, 0x64F334B05A50
0000710a0d1dcc97  call rax
0000710a0d1dcc99  movaps xmm11, [rsp]
0000710a0d1dcc9e  add rsp, 0x40
0000710a0d1dcca2  vmovaps xmm0, [rsp]
0000710a0d1dcca7  vmovaps xmm1, [rsp+0x10]
0000710a0d1dccad  vmovaps xmm2, [rsp+0x20]
0000710a0d1dccb3  vmovaps xmm3, [rsp+0x30]
0000710a0d1dccb9  vmovaps xmm4, [rsp+0x40]
0000710a0d1dccbf  vmovaps xmm5, [rsp+0x50]
0000710a0d1dccc5  vmovaps xmm6, [rsp+0x60]
0000710a0d1dcccb  vmovaps xmm7, [rsp+0x70]
0000710a0d1dccd1  vmovaps xmm8, [rsp+0x80]
0000710a0d1dccda  vmovaps xmm9, [rsp+0x90]
0000710a0d1dcce3  vmovaps xmm10, [rsp+0xA0]
0000710a0d1dccec  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dccf5  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dccfe  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dcd07  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dcd10  add rsp, 0xF0
0000710a0d1dcd17  pop r11
0000710a0d1dcd19  pop r10
0000710a0d1dcd1b  pop r9
0000710a0d1dcd1d  pop r8
0000710a0d1dcd1f  pop rsi
0000710a0d1dcd20  pop rdi
0000710a0d1dcd21  pop rdx
0000710a0d1dcd22  pop rcx
0000710a0d1dcd23  pop rax
0000710a0d1dcd24  add rsp, 0x08
0000710a0d1dcd28  jmp 0x0000710A0D1DA54A
0000710a0d1dcd2d  call 0x0000710A0D00E760
0000710a0d1dcd32  jmp 0x0000710A0D1DA557
0000710a0d1dcd37  call 0x0000710A0D00D4E0
0000710a0d1dcd3c  jmp 0x0000710A0D1DA564
0000710a0d1dcd41  sub rsp, 0x08
0000710a0d1dcd45  push rax
0000710a0d1dcd46  push rcx
0000710a0d1dcd47  push rdx
0000710a0d1dcd48  push rdi
0000710a0d1dcd49  push rsi
0000710a0d1dcd4a  push r8
0000710a0d1dcd4c  push r9
0000710a0d1dcd4e  push r10
0000710a0d1dcd50  push r11
0000710a0d1dcd52  sub rsp, 0xF0
0000710a0d1dcd59  vmovaps [rsp], xmm0
0000710a0d1dcd5e  vmovaps [rsp+0x10], xmm1
0000710a0d1dcd64  vmovaps [rsp+0x20], xmm2
0000710a0d1dcd6a  vmovaps [rsp+0x30], xmm3
0000710a0d1dcd70  vmovaps [rsp+0x40], xmm4
0000710a0d1dcd76  vmovaps [rsp+0x50], xmm5
0000710a0d1dcd7c  vmovaps [rsp+0x60], xmm6
0000710a0d1dcd82  vmovaps [rsp+0x70], xmm7
0000710a0d1dcd88  vmovaps [rsp+0x80], xmm8
0000710a0d1dcd91  vmovaps [rsp+0x90], xmm9
0000710a0d1dcd9a  vmovaps [rsp+0xA0], xmm11
0000710a0d1dcda3  vmovaps [rsp+0xB0], xmm12
0000710a0d1dcdac  vmovaps [rsp+0xC0], xmm13
0000710a0d1dcdb5  vmovaps [rsp+0xD0], xmm14
0000710a0d1dcdbe  vmovaps [rsp+0xE0], xmm15
0000710a0d1dcdc7  sub rsp, 0x40
0000710a0d1dcdcb  lea rdi, [rsp]
0000710a0d1dcdcf  lea rsi, [rsp+0x10]
0000710a0d1dcdd4  lea rdx, [rsp+0x20]
0000710a0d1dcdd9  lea rcx, [rsp+0x30]
0000710a0d1dcdde  mov r8d, 0x00
0000710a0d1dcde4  lea r9, [r15+0x3A8]
0000710a0d1dcdeb  movaps [rdi], xmm10
0000710a0d1dcdef  movaps [rsi], xmm8
0000710a0d1dcdf3  movaps [rdx], xmm1
0000710a0d1dcdf6  movaps [rcx], xmm13
0000710a0d1dcdfa  mov rax, 0x64F334B05A50
0000710a0d1dce04  call rax
0000710a0d1dce06  movaps xmm10, [rsp]
0000710a0d1dce0b  add rsp, 0x40
0000710a0d1dce0f  vmovaps xmm0, [rsp]
0000710a0d1dce14  vmovaps xmm1, [rsp+0x10]
0000710a0d1dce1a  vmovaps xmm2, [rsp+0x20]
0000710a0d1dce20  vmovaps xmm3, [rsp+0x30]
0000710a0d1dce26  vmovaps xmm4, [rsp+0x40]
0000710a0d1dce2c  vmovaps xmm5, [rsp+0x50]
0000710a0d1dce32  vmovaps xmm6, [rsp+0x60]
0000710a0d1dce38  vmovaps xmm7, [rsp+0x70]
0000710a0d1dce3e  vmovaps xmm8, [rsp+0x80]
0000710a0d1dce47  vmovaps xmm9, [rsp+0x90]
0000710a0d1dce50  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dce59  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dce62  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dce6b  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dce74  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dce7d  add rsp, 0xF0
0000710a0d1dce84  pop r11
0000710a0d1dce86  pop r10
0000710a0d1dce88  pop r9
0000710a0d1dce8a  pop r8
0000710a0d1dce8c  pop rsi
0000710a0d1dce8d  pop rdi
0000710a0d1dce8e  pop rdx
0000710a0d1dce8f  pop rcx
0000710a0d1dce90  pop rax
0000710a0d1dce91  add rsp, 0x08
0000710a0d1dce95  jmp 0x0000710A0D1DA59A
0000710a0d1dce9a  call 0x0000710A0CFFF430
0000710a0d1dce9f  jmp 0x0000710A0D1DA5AC
0000710a0d1dcea4  sub rsp, 0x08
0000710a0d1dcea8  push rax
0000710a0d1dcea9  push rcx
0000710a0d1dceaa  push rdx
0000710a0d1dceab  push rdi
0000710a0d1dceac  push rsi
0000710a0d1dcead  push r8
0000710a0d1dceaf  push r9
0000710a0d1dceb1  push r10
0000710a0d1dceb3  push r11
0000710a0d1dceb5  sub rsp, 0xF0
0000710a0d1dcebc  vmovaps [rsp], xmm0
0000710a0d1dcec1  vmovaps [rsp+0x10], xmm1
0000710a0d1dcec7  vmovaps [rsp+0x20], xmm2
0000710a0d1dcecd  vmovaps [rsp+0x30], xmm3
0000710a0d1dced3  vmovaps [rsp+0x40], xmm4
0000710a0d1dced9  vmovaps [rsp+0x50], xmm5
0000710a0d1dcedf  vmovaps [rsp+0x60], xmm6
0000710a0d1dcee5  vmovaps [rsp+0x70], xmm7
0000710a0d1dceeb  vmovaps [rsp+0x80], xmm8
0000710a0d1dcef4  vmovaps [rsp+0x90], xmm10
0000710a0d1dcefd  vmovaps [rsp+0xA0], xmm11
0000710a0d1dcf06  vmovaps [rsp+0xB0], xmm12
0000710a0d1dcf0f  vmovaps [rsp+0xC0], xmm13
0000710a0d1dcf18  vmovaps [rsp+0xD0], xmm14
0000710a0d1dcf21  vmovaps [rsp+0xE0], xmm15
0000710a0d1dcf2a  sub rsp, 0x40
0000710a0d1dcf2e  lea rdi, [rsp]
0000710a0d1dcf32  lea rsi, [rsp+0x10]
0000710a0d1dcf37  lea rdx, [rsp+0x20]
0000710a0d1dcf3c  lea rcx, [rsp+0x30]
0000710a0d1dcf41  mov r8d, 0x00
0000710a0d1dcf47  lea r9, [r15+0x3A8]
0000710a0d1dcf4e  movaps [rdi], xmm9
0000710a0d1dcf52  movaps [rsi], xmm7
0000710a0d1dcf55  movaps [rdx], xmm14
0000710a0d1dcf59  movaps [rcx], xmm13
0000710a0d1dcf5d  mov rax, 0x64F334B05A50
0000710a0d1dcf67  call rax
0000710a0d1dcf69  movaps xmm9, [rsp]
0000710a0d1dcf6e  add rsp, 0x40
0000710a0d1dcf72  vmovaps xmm0, [rsp]
0000710a0d1dcf77  vmovaps xmm1, [rsp+0x10]
0000710a0d1dcf7d  vmovaps xmm2, [rsp+0x20]
0000710a0d1dcf83  vmovaps xmm3, [rsp+0x30]
0000710a0d1dcf89  vmovaps xmm4, [rsp+0x40]
0000710a0d1dcf8f  vmovaps xmm5, [rsp+0x50]
0000710a0d1dcf95  vmovaps xmm6, [rsp+0x60]
0000710a0d1dcf9b  vmovaps xmm7, [rsp+0x70]
0000710a0d1dcfa1  vmovaps xmm8, [rsp+0x80]
0000710a0d1dcfaa  vmovaps xmm10, [rsp+0x90]
0000710a0d1dcfb3  vmovaps xmm11, [rsp+0xA0]
0000710a0d1dcfbc  vmovaps xmm12, [rsp+0xB0]
0000710a0d1dcfc5  vmovaps xmm13, [rsp+0xC0]
0000710a0d1dcfce  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dcfd7  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dcfe0  add rsp, 0xF0
0000710a0d1dcfe7  pop r11
0000710a0d1dcfe9  pop r10
0000710a0d1dcfeb  pop r9
0000710a0d1dcfed  pop r8
0000710a0d1dcfef  pop rsi
0000710a0d1dcff0  pop rdi
0000710a0d1dcff1  pop rdx
0000710a0d1dcff2  pop rcx
0000710a0d1dcff3  pop rax
0000710a0d1dcff4  add rsp, 0x08
0000710a0d1dcff8  jmp 0x0000710A0D1DA5DA
0000710a0d1dcffd  sub rsp, 0x08
0000710a0d1dd001  push rax
0000710a0d1dd002  push rcx
0000710a0d1dd003  push rdx
0000710a0d1dd004  push rdi
0000710a0d1dd005  push rsi
0000710a0d1dd006  push r8
0000710a0d1dd008  push r9
0000710a0d1dd00a  push r10
0000710a0d1dd00c  push r11
0000710a0d1dd00e  sub rsp, 0xF0
0000710a0d1dd015  vmovaps [rsp], xmm0
0000710a0d1dd01a  vmovaps [rsp+0x10], xmm1
0000710a0d1dd020  vmovaps [rsp+0x20], xmm2
0000710a0d1dd026  vmovaps [rsp+0x30], xmm3
0000710a0d1dd02c  vmovaps [rsp+0x40], xmm4
0000710a0d1dd032  vmovaps [rsp+0x50], xmm5
0000710a0d1dd038  vmovaps [rsp+0x60], xmm6
0000710a0d1dd03e  vmovaps [rsp+0x70], xmm7
0000710a0d1dd044  vmovaps [rsp+0x80], xmm8
0000710a0d1dd04d  vmovaps [rsp+0x90], xmm9
0000710a0d1dd056  vmovaps [rsp+0xA0], xmm10
0000710a0d1dd05f  vmovaps [rsp+0xB0], xmm11
0000710a0d1dd068  vmovaps [rsp+0xC0], xmm12
0000710a0d1dd071  vmovaps [rsp+0xD0], xmm14
0000710a0d1dd07a  vmovaps [rsp+0xE0], xmm15
0000710a0d1dd083  sub rsp, 0x40
0000710a0d1dd087  lea rdi, [rsp]
0000710a0d1dd08b  lea rsi, [rsp+0x10]
0000710a0d1dd090  lea rdx, [rsp+0x20]
0000710a0d1dd095  lea rcx, [rsp+0x30]
0000710a0d1dd09a  mov r8d, 0x00
0000710a0d1dd0a0  lea r9, [r15+0x3A8]
0000710a0d1dd0a7  movaps [rdi], xmm13
0000710a0d1dd0ab  movaps [rsi], xmm12
0000710a0d1dd0af  movaps [rdx], xmm15
0000710a0d1dd0b3  movaps [rcx], xmm14
0000710a0d1dd0b7  mov rax, 0x64F334B05A50
0000710a0d1dd0c1  call rax
0000710a0d1dd0c3  movaps xmm13, [rsp]
0000710a0d1dd0c8  add rsp, 0x40
0000710a0d1dd0cc  vmovaps xmm0, [rsp]
0000710a0d1dd0d1  vmovaps xmm1, [rsp+0x10]
0000710a0d1dd0d7  vmovaps xmm2, [rsp+0x20]
0000710a0d1dd0dd  vmovaps xmm3, [rsp+0x30]
0000710a0d1dd0e3  vmovaps xmm4, [rsp+0x40]
0000710a0d1dd0e9  vmovaps xmm5, [rsp+0x50]
0000710a0d1dd0ef  vmovaps xmm6, [rsp+0x60]
0000710a0d1dd0f5  vmovaps xmm7, [rsp+0x70]
0000710a0d1dd0fb  vmovaps xmm8, [rsp+0x80]
0000710a0d1dd104  vmovaps xmm9, [rsp+0x90]
0000710a0d1dd10d  vmovaps xmm10, [rsp+0xA0]
0000710a0d1dd116  vmovaps xmm11, [rsp+0xB0]
0000710a0d1dd11f  vmovaps xmm12, [rsp+0xC0]
0000710a0d1dd128  vmovaps xmm14, [rsp+0xD0]
0000710a0d1dd131  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dd13a  add rsp, 0xF0
0000710a0d1dd141  pop r11
0000710a0d1dd143  pop r10
0000710a0d1dd145  pop r9
0000710a0d1dd147  pop r8
0000710a0d1dd149  pop rsi
0000710a0d1dd14a  pop rdi
0000710a0d1dd14b  pop rdx
0000710a0d1dd14c  pop rcx
0000710a0d1dd14d  pop rax
0000710a0d1dd14e  add rsp, 0x08
0000710a0d1dd152  jmp 0x0000710A0D1DA608
0000710a0d1dd157  sub rsp, 0x08
0000710a0d1dd15b  push rax
0000710a0d1dd15c  push rcx
0000710a0d1dd15d  push rdx
0000710a0d1dd15e  push rdi
0000710a0d1dd15f  push rsi
0000710a0d1dd160  push r8
0000710a0d1dd162  push r9
0000710a0d1dd164  push r10
0000710a0d1dd166  push r11
0000710a0d1dd168  sub rsp, 0xF0
0000710a0d1dd16f  vmovaps [rsp], xmm0
0000710a0d1dd174  vmovaps [rsp+0x10], xmm1
0000710a0d1dd17a  vmovaps [rsp+0x20], xmm2
0000710a0d1dd180  vmovaps [rsp+0x30], xmm3
0000710a0d1dd186  vmovaps [rsp+0x40], xmm4
0000710a0d1dd18c  vmovaps [rsp+0x50], xmm5
0000710a0d1dd192  vmovaps [rsp+0x60], xmm6
0000710a0d1dd198  vmovaps [rsp+0x70], xmm7
0000710a0d1dd19e  vmovaps [rsp+0x80], xmm8
0000710a0d1dd1a7  vmovaps [rsp+0x90], xmm9
0000710a0d1dd1b0  vmovaps [rsp+0xA0], xmm10
0000710a0d1dd1b9  vmovaps [rsp+0xB0], xmm11
0000710a0d1dd1c2  vmovaps [rsp+0xC0], xmm12
0000710a0d1dd1cb  vmovaps [rsp+0xD0], xmm13
0000710a0d1dd1d4  vmovaps [rsp+0xE0], xmm15
0000710a0d1dd1dd  sub rsp, 0x40
0000710a0d1dd1e1  lea rdi, [rsp]
0000710a0d1dd1e5  lea rsi, [rsp+0x10]
0000710a0d1dd1ea  lea rdx, [rsp+0x20]
0000710a0d1dd1ef  lea rcx, [rsp+0x30]
0000710a0d1dd1f4  mov r8d, 0x00
0000710a0d1dd1fa  lea r9, [r15+0x3A8]
0000710a0d1dd201  movaps [rdi], xmm14
0000710a0d1dd205  movaps [rsi], xmm11
0000710a0d1dd209  movaps [rdx], xmm1
0000710a0d1dd20c  movaps [rcx], xmm15
0000710a0d1dd210  mov rax, 0x64F334B05A50
0000710a0d1dd21a  call rax
0000710a0d1dd21c  movaps xmm14, [rsp]
0000710a0d1dd221  add rsp, 0x40
0000710a0d1dd225  vmovaps xmm0, [rsp]
0000710a0d1dd22a  vmovaps xmm1, [rsp+0x10]
0000710a0d1dd230  vmovaps xmm2, [rsp+0x20]
0000710a0d1dd236  vmovaps xmm3, [rsp+0x30]
0000710a0d1dd23c  vmovaps xmm4, [rsp+0x40]
0000710a0d1dd242  vmovaps xmm5, [rsp+0x50]
0000710a0d1dd248  vmovaps xmm6, [rsp+0x60]
0000710a0d1dd24e  vmovaps xmm7, [rsp+0x70]
0000710a0d1dd254  vmovaps xmm8, [rsp+0x80]
0000710a0d1dd25d  vmovaps xmm9, [rsp+0x90]
0000710a0d1dd266  vmovaps xmm10, [rsp+0xA0]
0000710a0d1dd26f  vmovaps xmm11, [rsp+0xB0]
0000710a0d1dd278  vmovaps xmm12, [rsp+0xC0]
0000710a0d1dd281  vmovaps xmm13, [rsp+0xD0]
0000710a0d1dd28a  vmovaps xmm15, [rsp+0xE0]
0000710a0d1dd293  add rsp, 0xF0
0000710a0d1dd29a  pop r11
0000710a0d1dd29c  pop r10
0000710a0d1dd29e  pop r9
0000710a0d1dd2a0  pop r8
0000710a0d1dd2a2  pop rsi
0000710a0d1dd2a3  pop rdi
0000710a0d1dd2a4  pop rdx
0000710a0d1dd2a5  pop rcx
0000710a0d1dd2a6  pop rax
0000710a0d1dd2a7  add rsp, 0x08
0000710a0d1dd2ab  jmp 0x0000710A0D1DA636
0000710a0d1dd2b0  call 0x0000710A0D0079B0
0000710a0d1dd2b5  jmp 0x0000710A0D1DA64C
0000710a0d1dd2ba  call 0x0000710A0D0E3440
0000710a0d1dd2bf  jmp 0x0000710A0D1DA656
0000710a0d1dd2c4  call 0x0000710A0D0DFCE0
0000710a0d1dd2c9  jmp 0x0000710A0D1DA660
0000710a0d1dd2ce  call 0x0000710A0D0E46C0
0000710a0d1dd2d3  jmp 0x0000710A0D1DA66A
0000710a0d1dd2d8  int3
0000710a0d1dd2d9  nop [rax], eax
0000710a0d1dd2e0  mov qword ptr [r15+0x40], 0x430000
0000710a0d1dd2e8  mov eax, 0x430C50
0000710a0d1dd2ed  mov r14, [r13+rax*1]
0000710a0d1dd2f2  movq xmm1, r14
0000710a0d1dd2f7  mov rax, [r15+0x50]
0000710a0d1dd2fb  movups xmm15, [r13+rax*1]
0000710a0d1dd301  movaps [r15+0x120], xmm15
0000710a0d1dd309  mov qword ptr [r15+0x48], 0x10
0000710a0d1dd311  xor eax, eax
0000710a0d1dd313  mov r14d, 0x10
0000710a0d1dd319  mov r12d, 0x200
0000710a0d1dd31f  cmp r14, r12
0000710a0d1dd322  cmc
0000710a0d1dd323  lahf
0000710a0d1dd324  seto al
0000710a0d1dd327  mov [r15+0x108], eax
0000710a0d1dd32e  pextrq rax, xmm15, 0x01
0000710a0d1dd335  movq xmm14, rax
0000710a0d1dd33a  movaps [r15+0x130], xmm14
0000710a0d1dd342  movq rax, xmm1
0000710a0d1dd347  movq r14, xmm15
0000710a0d1dd34c  vmovq xmm1, rax
0000710a0d1dd351  vmovq xmm15, r14
0000710a0d1dd356  movaps xmm13, xmm1
0000710a0d1dd35a  addsd xmm13, xmm15
0000710a0d1dd35f  ucomisd xmm13, xmm13
0000710a0d1dd364  jp 0x0000710A0D1DD423
0000710a0d1dd36a  movq xmm13, xmm13
0000710a0d1dd36f  movq rax, xmm13
0000710a0d1dd374  movq r14, xmm14
0000710a0d1dd379  vmovq xmm1, rax
0000710a0d1dd37e  vmovq xmm15, r14
0000710a0d1dd383  movaps xmm14, xmm1
0000710a0d1dd387  addsd xmm14, xmm15
0000710a0d1dd38c  ucomisd xmm14, xmm14
0000710a0d1dd391  jp 0x0000710A0D1DD46B
0000710a0d1dd397  movq xmm14, xmm14
0000710a0d1dd39c  movaps [r15+0x110], xmm14
0000710a0d1dd3a4  mov eax, [r15+0x108]
0000710a0d1dd3ab  sahf
0000710a0d1dd3ac  jnz 0x0000710A0D1DD3DE
0000710a0d1dd3ae  cmp dword ptr [r15+0x318], 0x00
0000710a0d1dd3b6  jz 0x0000710A0D1DD680
0000710a0d1dd3bc  nop [rax+rax*1], ax
0000710a0d1dd3c5  nop [rax+rax*1], eax
0000710a0d1dd3cd  mov eax, 0x410698
0000710a0d1dd3d2  mov [r15+0x100], rax
0000710a0d1dd3d9  jmp 0x0000710A0CFFE110
0000710a0d1dd3de  cmp dword ptr [r15+0x318], 0x00
0000710a0d1dd3e6  jz 0x0000710A0D1DD4C0
0000710a0d1dd3ec  nop [rax+rax*1], ax
0000710a0d1dd3f5  nop [rax+rax*1], eax
0000710a0d1dd3fd  mov eax, 0x41067C
0000710a0d1dd402  mov [r15+0x100], rax
0000710a0d1dd409  jmp 0x0000710A0CFFE110
0000710a0d1dd40e  int3
0000710a0d1dd40f  call 0x0000710A0D00DC20
0000710a0d1dd414  jmp 0x0000710A0D1DD2F2
0000710a0d1dd419  call 0x0000710A0D00E760
0000710a0d1dd41e  jmp 0x0000710A0D1DD301
0000710a0d1dd423  ucomisd xmm1, xmm15
0000710a0d1dd428  jp 0x0000710A0D1DD437
0000710a0d1dd42a  movaps xmm13, [0x0000710A0CDFE060]
0000710a0d1dd432  jmp 0x0000710A0D1DD36A
0000710a0d1dd437  vxorps xmm0, xmm1, xmm15
0000710a0d1dd43c  pextrw eax, xmm0, 0x03
0000710a0d1dd441  and eax, 0x7FF8
0000710a0d1dd446  cmp eax, 0x08
0000710a0d1dd449  jnz 0x0000710A0D1DD36A
0000710a0d1dd44f  movq rax, xmm15
0000710a0d1dd454  shl rax, 0x0D
0000710a0d1dd458  jbe 0x0000710A0D1DD36A
0000710a0d1dd45e  vorps xmm13, xmm15, [0x0000710A0CDFE070]
0000710a0d1dd466  jmp 0x0000710A0D1DD36A
0000710a0d1dd46b  ucomisd xmm1, xmm15
0000710a0d1dd470  jp 0x0000710A0D1DD47F
0000710a0d1dd472  movaps xmm14, [0x0000710A0CDFE060]
0000710a0d1dd47a  jmp 0x0000710A0D1DD397
0000710a0d1dd47f  vxorps xmm0, xmm1, xmm15
0000710a0d1dd484  pextrw eax, xmm0, 0x03
0000710a0d1dd489  and eax, 0x7FF8
0000710a0d1dd48e  cmp eax, 0x08
0000710a0d1dd491  jnz 0x0000710A0D1DD397
0000710a0d1dd497  movq rax, xmm15
0000710a0d1dd49c  shl rax, 0x0D
0000710a0d1dd4a0  jbe 0x0000710A0D1DD397
0000710a0d1dd4a6  vorps xmm14, xmm15, [0x0000710A0CDFE070]
0000710a0d1dd4ae  jmp 0x0000710A0D1DD397
0000710a0d1dd4b3  int3
0000710a0d1dd4b4  nop [rax+rax*1], ax
0000710a0d1dd4bd  nop [rax], eax
0000710a0d1dd4c0  mov rax, [r15+0x48]
0000710a0d1dd4c4  mov r14, [r15+0x50]
0000710a0d1dd4c8  lea r12, [r14+rax*1]
0000710a0d1dd4cc  movups xmm1, [r13+r12*1]
0000710a0d1dd4d2  movaps [r15+0x120], xmm1
0000710a0d1dd4da  lea r14, [rax+0x10]
0000710a0d1dd4de  mov [r15+0x48], r14
0000710a0d1dd4e2  xor eax, eax
0000710a0d1dd4e4  mov r12d, 0x200
0000710a0d1dd4ea  cmp r14, r12
0000710a0d1dd4ed  cmc
0000710a0d1dd4ee  lahf
0000710a0d1dd4ef  seto al
0000710a0d1dd4f2  mov [r15+0x108], eax
0000710a0d1dd4f9  pextrq rax, xmm1, 0x01
0000710a0d1dd500  movq xmm15, rax
0000710a0d1dd505  movaps [r15+0x130], xmm15
0000710a0d1dd50d  movaps xmm14, [r15+0x110]
0000710a0d1dd515  movq rax, xmm14
0000710a0d1dd51a  movq r14, xmm1
0000710a0d1dd51f  vmovq xmm1, rax
0000710a0d1dd524  vmovq xmm14, r14
0000710a0d1dd529  movaps xmm13, xmm1
0000710a0d1dd52d  addsd xmm13, xmm14
0000710a0d1dd532  ucomisd xmm13, xmm13
0000710a0d1dd537  jp 0x0000710A0D1DD5EC
0000710a0d1dd53d  movq xmm13, xmm13
0000710a0d1dd542  movq rax, xmm13
0000710a0d1dd547  movq r14, xmm15
0000710a0d1dd54c  vmovq xmm1, rax
0000710a0d1dd551  vmovq xmm15, r14
0000710a0d1dd556  movaps xmm14, xmm1
0000710a0d1dd55a  addsd xmm14, xmm15
0000710a0d1dd55f  ucomisd xmm14, xmm14
0000710a0d1dd564  jp 0x0000710A0D1DD634
0000710a0d1dd56a  movq xmm14, xmm14
0000710a0d1dd56f  movaps [r15+0x110], xmm14
0000710a0d1dd577  mov eax, [r15+0x108]
0000710a0d1dd57e  sahf
0000710a0d1dd57f  jnz 0x0000710A0D1DD5B1
0000710a0d1dd581  cmp dword ptr [r15+0x318], 0x00
0000710a0d1dd589  jz 0x0000710A0D1DD680
0000710a0d1dd58f  nop [rax+rax*1], ax
0000710a0d1dd598  nop [rax+rax*1], eax
0000710a0d1dd5a0  mov eax, 0x410698
0000710a0d1dd5a5  mov [r15+0x100], rax
0000710a0d1dd5ac  jmp 0x0000710A0CFFE110
0000710a0d1dd5b1  cmp dword ptr [r15+0x318], 0x00
0000710a0d1dd5b9  jz 0x0000710A0D1DD4C0
0000710a0d1dd5bf  nop [rax+rax*1], ax
0000710a0d1dd5c8  nop [rax+rax*1], eax
0000710a0d1dd5d0  mov eax, 0x41067C
0000710a0d1dd5d5  mov [r15+0x100], rax
0000710a0d1dd5dc  jmp 0x0000710A0CFFE110
0000710a0d1dd5e1  int3
0000710a0d1dd5e2  call 0x0000710A0D0B52F0
0000710a0d1dd5e7  jmp 0x0000710A0D1DD4D2
0000710a0d1dd5ec  ucomisd xmm1, xmm14
0000710a0d1dd5f1  jp 0x0000710A0D1DD600
0000710a0d1dd5f3  movaps xmm13, [0x0000710A0CDFE060]
0000710a0d1dd5fb  jmp 0x0000710A0D1DD53D
0000710a0d1dd600  vxorps xmm0, xmm1, xmm14
0000710a0d1dd605  pextrw eax, xmm0, 0x03
0000710a0d1dd60a  and eax, 0x7FF8
0000710a0d1dd60f  cmp eax, 0x08
0000710a0d1dd612  jnz 0x0000710A0D1DD53D
0000710a0d1dd618  movq rax, xmm14
0000710a0d1dd61d  shl rax, 0x0D
0000710a0d1dd621  jbe 0x0000710A0D1DD53D
0000710a0d1dd627  vorps xmm13, xmm14, [0x0000710A0CDFE070]
0000710a0d1dd62f  jmp 0x0000710A0D1DD53D
0000710a0d1dd634  ucomisd xmm1, xmm15
0000710a0d1dd639  jp 0x0000710A0D1DD648
0000710a0d1dd63b  movaps xmm14, [0x0000710A0CDFE060]
0000710a0d1dd643  jmp 0x0000710A0D1DD56A
0000710a0d1dd648  vxorps xmm0, xmm1, xmm15
0000710a0d1dd64d  pextrw eax, xmm0, 0x03
0000710a0d1dd652  and eax, 0x7FF8
0000710a0d1dd657  cmp eax, 0x08
0000710a0d1dd65a  jnz 0x0000710A0D1DD56A
0000710a0d1dd660  movq rax, xmm15
0000710a0d1dd665  shl rax, 0x0D
0000710a0d1dd669  jbe 0x0000710A0D1DD56A
0000710a0d1dd66f  vorps xmm14, xmm15, [0x0000710A0CDFE070]
0000710a0d1dd677  jmp 0x0000710A0D1DD56A
0000710a0d1dd67c  int3
0000710a0d1dd67d  nop [rax], eax
0000710a0d1dd680  mov rax, [r15+0xF8]
0000710a0d1dd687  lea r14, [rax+0x1A0]
0000710a0d1dd68e  mov r12, [r13+r14*1]
0000710a0d1dd693  lea r14, [rax+0x1A8]
0000710a0d1dd69a  mov r11, [r13+r14*1]
0000710a0d1dd69f  mov [r15+0xA0], r12
0000710a0d1dd6a6  mov [r15+0x98], r11
0000710a0d1dd6ad  mov r14, [r15+0x40]
0000710a0d1dd6b1  lea r12, [r14+0xC50]
0000710a0d1dd6b8  movaps xmm1, [r15+0x110]
0000710a0d1dd6c0  movq r14, xmm1
0000710a0d1dd6c5  mov [r13+r12*1], r14
0000710a0d1dd6ca  lea r14, [rax+0x190]
0000710a0d1dd6d1  mov r12, [r13+r14*1]
0000710a0d1dd6d6  lea r14, [rax+0x198]
0000710a0d1dd6dd  mov r11, [r13+r14*1]
0000710a0d1dd6e2  mov [r15+0xE8], r12
0000710a0d1dd6e9  mov [r15+0xF0], r11
0000710a0d1dd6f0  lea r14, [rax+0x180]
0000710a0d1dd6f7  mov r12, [r13+r14*1]
0000710a0d1dd6fc  lea r14, [rax+0x188]
0000710a0d1dd703  mov r10, [r13+r14*1]
0000710a0d1dd708  movq xmm1, r12
0000710a0d1dd70d  movq xmm15, r10
0000710a0d1dd712  movq xmm1, xmm1
0000710a0d1dd716  movq xmm1, xmm1
0000710a0d1dd71a  movaps [r15+0x1A0], xmm1
0000710a0d1dd722  movq xmm15, xmm15
0000710a0d1dd727  movq xmm15, xmm15
0000710a0d1dd72c  movaps [r15+0x190], xmm15
0000710a0d1dd734  lea r14, [rax+0x170]
0000710a0d1dd73b  mov r12, [r13+r14*1]
0000710a0d1dd740  lea r14, [rax+0x178]
0000710a0d1dd747  mov r10, [r13+r14*1]
0000710a0d1dd74c  movq xmm1, r12
0000710a0d1dd751  movq xmm15, r10
0000710a0d1dd756  movq xmm1, xmm1
0000710a0d1dd75a  movq xmm1, xmm1
0000710a0d1dd75e  movaps [r15+0x1C0], xmm1
0000710a0d1dd766  movq xmm15, xmm15
0000710a0d1dd76b  movq xmm15, xmm15
0000710a0d1dd770  movaps [r15+0x1B0], xmm15
0000710a0d1dd778  lea r14, [rax+0x160]
0000710a0d1dd77f  mov r12, [r13+r14*1]
0000710a0d1dd784  lea r14, [rax+0x168]
0000710a0d1dd78b  mov r10, [r13+r14*1]
0000710a0d1dd790  movq xmm1, r12
0000710a0d1dd795  movq xmm15, r10
0000710a0d1dd79a  movq xmm1, xmm1
0000710a0d1dd79e  movq xmm1, xmm1
0000710a0d1dd7a2  movaps [r15+0x1E0], xmm1
0000710a0d1dd7aa  movq xmm15, xmm15
0000710a0d1dd7af  movq xmm15, xmm15
0000710a0d1dd7b4  movaps [r15+0x1D0], xmm15
0000710a0d1dd7bc  lea r14, [rax+0x150]
0000710a0d1dd7c3  mov r12, [r13+r14*1]
0000710a0d1dd7c8  lea r14, [rax+0x158]
0000710a0d1dd7cf  mov r10, [r13+r14*1]
0000710a0d1dd7d4  movq xmm1, r12
0000710a0d1dd7d9  movq xmm15, r10
0000710a0d1dd7de  movq xmm1, xmm1
0000710a0d1dd7e2  movq xmm1, xmm1
0000710a0d1dd7e6  movaps [r15+0x200], xmm1
0000710a0d1dd7ee  movq xmm15, xmm15
0000710a0d1dd7f3  movq xmm15, xmm15
0000710a0d1dd7f8  movaps [r15+0x1F0], xmm15
0000710a0d1dd800  lea r14, [rax+0x1B0]
0000710a0d1dd807  mov [r15+0xF8], r14
0000710a0d1dd80e  mov [r15+0x100], r11
0000710a0d1dd815  jmp 0x0000710A0D1CE5C0
0000710a0d1dd81a  int3
0000710a0d1dd81b  call 0x0000710A0D0E27E0
0000710a0d1dd820  jmp 0x0000710A0D1DD693
0000710a0d1dd825  call 0x0000710A0D0E1570
0000710a0d1dd82a  jmp 0x0000710A0D1DD69F
0000710a0d1dd82f  call 0x0000710A0D0C3FE0
0000710a0d1dd834  jmp 0x0000710A0D1DD6CA
0000710a0d1dd839  call 0x0000710A0D0E27E0
0000710a0d1dd83e  jmp 0x0000710A0D1DD6D6
0000710a0d1dd843  call 0x0000710A0D0E1570
0000710a0d1dd848  jmp 0x0000710A0D1DD6E2
0000710a0d1dd84d  call 0x0000710A0D0E27E0
0000710a0d1dd852  jmp 0x0000710A0D1DD6FC
0000710a0d1dd857  call 0x0000710A0D0E0300
0000710a0d1dd85c  jmp 0x0000710A0D1DD708
0000710a0d1dd861  call 0x0000710A0D0E27E0
0000710a0d1dd866  jmp 0x0000710A0D1DD740
0000710a0d1dd86b  call 0x0000710A0D0E0300
0000710a0d1dd870  jmp 0x0000710A0D1DD74C
0000710a0d1dd875  call 0x0000710A0D0E27E0
0000710a0d1dd87a  jmp 0x0000710A0D1DD784
0000710a0d1dd87f  call 0x0000710A0D0E0300
0000710a0d1dd884  jmp 0x0000710A0D1DD790
0000710a0d1dd889  call 0x0000710A0D0E27E0
0000710a0d1dd88e  jmp 0x0000710A0D1DD7C8
0000710a0d1dd893  call 0x0000710A0D0E0300
0000710a0d1dd898  jmp 0x0000710A0D1DD7D4
0000710a0d1dd89d  int3
0000710a0d1dd89e  nop
0000710a0d1dd8a0  mov qword ptr [r15+0x100], 0x04
0000710a0d1dd8ab  mov esi, 0x00
0000710a0d1dd8b0  mov edx, 0x09
0000710a0d1dd8b5  mov rdi, 0x7FFFCD965890
0000710a0d1dd8bf  mov rax, 0x64F334998970
0000710a0d1dd8c9  call rax
0000710a0d1dd8cb  cmp dword ptr [r15+0x318], 0x00
0000710a0d1dd8d3  jnz 0x0000710A0CFFE110
0000710a0d1dd8d9  jmp 0x0000710A0CFFE0A0
0000710a0d1dd8de  int3
0000710a0d1dd8df  int3
