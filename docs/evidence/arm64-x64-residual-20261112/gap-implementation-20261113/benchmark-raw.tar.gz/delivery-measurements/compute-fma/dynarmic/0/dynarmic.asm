00007588ecdce69b  nop [rax+rax*1], eax
00007588ecdce6a0  mov rax, [r15+0xF8]
00007588ecdce6a7  lea r14, [rax-0x1B0]
00007588ecdce6ae  mov [r15+0xF8], r14
00007588ecdce6b5  lea rax, [r14+0x1A0]
00007588ecdce6bc  mov r12, [r15+0xA0]
00007588ecdce6c3  mov r11, [r15+0x98]
00007588ecdce6ca  mov [r13+rax*1], r12
00007588ecdce6cf  lea rax, [r14+0x1A8]
00007588ecdce6d6  mov [r13+rax*1], r11
00007588ecdce6db  mov eax, 0x420A30
00007588ecdce6e0  movups xmm1, [r13+rax*1]
00007588ecdce6e6  mov eax, 0x4209C0
00007588ecdce6eb  movups xmm15, [r13+rax*1]
00007588ecdce6f1  mov eax, 0x420A50
00007588ecdce6f6  movups xmm14, [r13+rax*1]
00007588ecdce6fc  mov eax, 0x4209F0
00007588ecdce701  movups xmm13, [r13+rax*1]
00007588ecdce707  mov qword ptr [r15+0x98], 0x430C60
00007588ecdce712  mov eax, 0x420A60
00007588ecdce717  movups xmm12, [r13+rax*1]
00007588ecdce71d  mov eax, 0x430C60
00007588ecdce722  movups [r13+rax*1], xmm1
00007588ecdce728  mov eax, 0x430C70
00007588ecdce72d  movups [r13+rax*1], xmm15
00007588ecdce733  mov eax, 0x430C80
00007588ecdce738  movups [r13+rax*1], xmm14
00007588ecdce73e  mov eax, 0x430C90
00007588ecdce743  movups [r13+rax*1], xmm13
00007588ecdce749  mov eax, 0x4209B0
00007588ecdce74e  movups xmm14, [r13+rax*1]
00007588ecdce754  mov eax, 0x4209A0
00007588ecdce759  movups xmm13, [r13+rax*1]
00007588ecdce75f  mov eax, 0x430D60
00007588ecdce764  movups [r13+rax*1], xmm1
00007588ecdce76a  mov eax, 0x430D70
00007588ecdce76f  movups [r13+rax*1], xmm15
00007588ecdce775  mov eax, 0x430CA0
00007588ecdce77a  movups [r13+rax*1], xmm12
00007588ecdce780  mov eax, 0x430CB0
00007588ecdce785  movups [r13+rax*1], xmm14
00007588ecdce78b  mov eax, 0x420990
00007588ecdce790  movups xmm1, [r13+rax*1]
00007588ecdce796  mov eax, 0x420A00
00007588ecdce79b  movups xmm15, [r13+rax*1]
00007588ecdce7a1  mov eax, 0x430CC0
00007588ecdce7a6  movups [r13+rax*1], xmm13
00007588ecdce7ac  mov eax, 0x430CD0
00007588ecdce7b1  movups [r13+rax*1], xmm1
00007588ecdce7b7  mov eax, 0x420A10
00007588ecdce7bc  movups xmm1, [r13+rax*1]
00007588ecdce7c2  mov eax, 0x4209E0
00007588ecdce7c7  movups xmm14, [r13+rax*1]
00007588ecdce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007588ecdce7d5  mov eax, 0x430CE0
00007588ecdce7da  movups [r13+rax*1], xmm15
00007588ecdce7e0  mov eax, 0x430CF0
00007588ecdce7e5  movups [r13+rax*1], xmm1
00007588ecdce7eb  mov eax, 0x420A80
00007588ecdce7f0  movups xmm1, [r13+rax*1]
00007588ecdce7f6  mov eax, 0x420A90
00007588ecdce7fb  movups xmm15, [r13+rax*1]
00007588ecdce801  movaps [r15+0x150], xmm15
00007588ecdce809  mov qword ptr [r15+0xA0], 0x3E8
00007588ecdce814  mov eax, 0x430D00
00007588ecdce819  movups [r13+rax*1], xmm14
00007588ecdce81f  mov eax, 0x430D10
00007588ecdce824  movups [r13+rax*1], xmm1
00007588ecdce82a  mov eax, 0x420A70
00007588ecdce82f  movups xmm1, [r13+rax*1]
00007588ecdce835  mov eax, 0x420A20
00007588ecdce83a  movups xmm14, [r13+rax*1]
00007588ecdce840  movaps [r15+0x140], xmm14
00007588ecdce848  lea rax, [r14+0x150]
00007588ecdce84f  movq xmm13, qword ptr [r15+0x200]
00007588ecdce858  movq xmm12, qword ptr [r15+0x1F0]
00007588ecdce861  movq r12, xmm13
00007588ecdce866  movq r11, xmm12
00007588ecdce86b  mov [r13+rax*1], r12
00007588ecdce870  lea rax, [r14+0x158]
00007588ecdce877  mov [r13+rax*1], r11
00007588ecdce87c  mov eax, 0x430D20
00007588ecdce881  movups [r13+rax*1], xmm15
00007588ecdce887  mov eax, 0x430D30
00007588ecdce88c  movups [r13+rax*1], xmm1
00007588ecdce892  mov eax, 0x420A40
00007588ecdce897  movups xmm1, [r13+rax*1]
00007588ecdce89d  mov eax, 0x420AA8
00007588ecdce8a2  mov r12, [r13+rax*1]
00007588ecdce8a7  movq xmm15, r12
00007588ecdce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007588ecdce8b4  mov eax, 0x430D40
00007588ecdce8b9  movups [r13+rax*1], xmm14
00007588ecdce8bf  mov eax, 0x430D50
00007588ecdce8c4  movups [r13+rax*1], xmm1
00007588ecdce8ca  mov eax, 0x420B10
00007588ecdce8cf  movups xmm1, [r13+rax*1]
00007588ecdce8d5  movq rax, xmm15
00007588ecdce8da  mov r12d, 0x430D80
00007588ecdce8e0  mov [r13+r12*1], rax
00007588ecdce8e5  mov eax, 0x420AF0
00007588ecdce8ea  movups xmm15, [r13+rax*1]
00007588ecdce8f0  mov eax, 0x420B00
00007588ecdce8f5  movups xmm14, [r13+rax*1]
00007588ecdce8fb  lea rax, [r14+0x130]
00007588ecdce902  movups [r13+rax*1], xmm1
00007588ecdce908  lea rax, [r14+0x160]
00007588ecdce90f  movq xmm1, qword ptr [r15+0x1E0]
00007588ecdce918  movq xmm13, qword ptr [r15+0x1D0]
00007588ecdce921  movq r12, xmm1
00007588ecdce926  movq r11, xmm13
00007588ecdce92b  mov [r13+rax*1], r12
00007588ecdce930  lea rax, [r14+0x168]
00007588ecdce937  mov [r13+rax*1], r11
00007588ecdce93c  lea rax, [r14+0x110]
00007588ecdce943  movups [r13+rax*1], xmm15
00007588ecdce949  lea rax, [r14+0x120]
00007588ecdce950  movups [r13+rax*1], xmm14
00007588ecdce956  mov eax, 0x420AB0
00007588ecdce95b  movups xmm1, [r13+rax*1]
00007588ecdce961  mov eax, 0x420AC0
00007588ecdce966  movups xmm15, [r13+rax*1]
00007588ecdce96c  movaps [r15+0x120], xmm15
00007588ecdce974  lea rax, [r14+0x170]
00007588ecdce97b  movq xmm14, qword ptr [r15+0x1C0]
00007588ecdce984  movq xmm13, qword ptr [r15+0x1B0]
00007588ecdce98d  movq r12, xmm14
00007588ecdce992  movq r11, xmm13
00007588ecdce997  mov [r13+rax*1], r12
00007588ecdce99c  lea rax, [r14+0x178]
00007588ecdce9a3  mov [r13+rax*1], r11
00007588ecdce9a8  lea rax, [r14+0x180]
00007588ecdce9af  movq xmm14, qword ptr [r15+0x1A0]
00007588ecdce9b8  movq xmm13, qword ptr [r15+0x190]
00007588ecdce9c1  movq r12, xmm14
00007588ecdce9c6  movq r11, xmm13
00007588ecdce9cb  mov [r13+rax*1], r12
00007588ecdce9d0  lea rax, [r14+0x188]
00007588ecdce9d7  mov [r13+rax*1], r11
00007588ecdce9dc  lea rax, [r14+0xD0]
00007588ecdce9e3  movups [r13+rax*1], xmm1
00007588ecdce9e9  lea rax, [r14+0xE0]
00007588ecdce9f0  movups [r13+rax*1], xmm15
00007588ecdce9f6  mov eax, 0x420AD0
00007588ecdce9fb  movups xmm1, [r13+rax*1]
00007588ecdcea01  mov eax, 0x420AE0
00007588ecdcea06  movups xmm15, [r13+rax*1]
00007588ecdcea0c  movaps [r15+0x110], xmm1
00007588ecdcea14  movaps [r15+0x130], xmm15
00007588ecdcea1c  lea rax, [r14+0x190]
00007588ecdcea23  mov r12, [r15+0xE8]
00007588ecdcea2a  mov r11, [r15+0xF0]
00007588ecdcea31  mov [r13+rax*1], r12
00007588ecdcea36  lea rax, [r14+0x198]
00007588ecdcea3d  mov [r13+rax*1], r11
00007588ecdcea42  mov eax, 0x430D88
00007588ecdcea47  mov r12d, 0x421DF8D3
00007588ecdcea4d  mov [r13+rax*1], r12d
00007588ecdcea52  lea rax, [r14+0xF0]
00007588ecdcea59  movups [r13+rax*1], xmm1
00007588ecdcea5f  lea rax, [r14+0x100]
00007588ecdcea66  movups [r13+rax*1], xmm15
00007588ecdcea6c  lea rax, [r14+0xD0]
00007588ecdcea73  mov [r15], rax
00007588ecdcea76  mov qword ptr [r15+0x08], 0x430C60
00007588ecdcea7e  mov qword ptr [r15+0x10], 0x12C
00007588ecdcea86  mov qword ptr [r15+0xF0], 0x410284
00007588ecdcea91  mov r14d, [r15+0x320]
00007588ecdcea98  mov eax, 0x410284
00007588ecdcea9d  mov rcx, 0x7588ECDD07C0
00007588ecdceaa7  mov [r15+r14*8+0x328], rax
00007588ecdceaaf  mov [r15+r14*8+0x368], rcx
00007588ecdceab7  add r14d, 0x01
00007588ecdceabb  and r14d, 0x07
00007588ecdceabf  mov [r15+0x320], r14d
00007588ecdceac6  cmp dword ptr [r15+0x318], 0x00
00007588ecdceace  jz 0x00007588ECDCED70
00007588ecdcead4  nop [rax+rax*1], ax
00007588ecdceadd  nop [rax+rax*1], eax
00007588ecdceae5  mov eax, 0x4106BC
00007588ecdceaea  mov [r15+0x100], rax
00007588ecdceaf1  jmp 0x00007588ECBFE110
00007588ecdceaf6  int3
00007588ecdceaf7  call 0x00007588ECC0BC20
00007588ecdceafc  jmp 0x00007588ECDCE6CF
00007588ecdceb01  call 0x00007588ECC0A9A0
00007588ecdceb06  jmp 0x00007588ECDCE6DB
00007588ecdceb0b  call 0x00007588ECBFF430
00007588ecdceb10  jmp 0x00007588ECDCE6E6
00007588ecdceb15  call 0x00007588ECC0E760
00007588ecdceb1a  jmp 0x00007588ECDCE6F1
00007588ecdceb1f  call 0x00007588ECC0D4E0
00007588ecdceb24  jmp 0x00007588ECDCE6FC
00007588ecdceb29  call 0x00007588ECC0C260
00007588ecdceb2e  jmp 0x00007588ECDCE707
00007588ecdceb33  call 0x00007588ECC0AFE0
00007588ecdceb38  jmp 0x00007588ECDCE71D
00007588ecdceb3d  call 0x00007588ECBFF540
00007588ecdceb42  jmp 0x00007588ECDCE728
00007588ecdceb47  call 0x00007588ECC0E880
00007588ecdceb4c  jmp 0x00007588ECDCE733
00007588ecdceb51  call 0x00007588ECC0D600
00007588ecdceb56  jmp 0x00007588ECDCE73E
00007588ecdceb5b  call 0x00007588ECC0C380
00007588ecdceb60  jmp 0x00007588ECDCE749
00007588ecdceb65  call 0x00007588ECC0D4E0
00007588ecdceb6a  jmp 0x00007588ECDCE754
00007588ecdceb6f  call 0x00007588ECC0C260
00007588ecdceb74  jmp 0x00007588ECDCE75F
00007588ecdceb79  call 0x00007588ECBFF540
00007588ecdceb7e  jmp 0x00007588ECDCE76A
00007588ecdceb83  call 0x00007588ECC0E880
00007588ecdceb88  jmp 0x00007588ECDCE775
00007588ecdceb8d  call 0x00007588ECC0B100
00007588ecdceb92  jmp 0x00007588ECDCE780
00007588ecdceb97  call 0x00007588ECC0D600
00007588ecdceb9c  jmp 0x00007588ECDCE78B
00007588ecdceba1  call 0x00007588ECBFF430
00007588ecdceba6  jmp 0x00007588ECDCE796
00007588ecdcebab  call 0x00007588ECC0E760
00007588ecdcebb0  jmp 0x00007588ECDCE7A1
00007588ecdcebb5  call 0x00007588ECC0C380
00007588ecdcebba  jmp 0x00007588ECDCE7AC
00007588ecdcebbf  call 0x00007588ECBFF540
00007588ecdcebc4  jmp 0x00007588ECDCE7B7
00007588ecdcebc9  call 0x00007588ECBFF430
00007588ecdcebce  jmp 0x00007588ECDCE7C2
00007588ecdcebd3  call 0x00007588ECC0D4E0
00007588ecdcebd8  jmp 0x00007588ECDCE7CD
00007588ecdcebdd  call 0x00007588ECC0E880
00007588ecdcebe2  jmp 0x00007588ECDCE7E0
00007588ecdcebe7  call 0x00007588ECBFF540
00007588ecdcebec  jmp 0x00007588ECDCE7EB
00007588ecdcebf1  call 0x00007588ECBFF430
00007588ecdcebf6  jmp 0x00007588ECDCE7F6
00007588ecdcebfb  call 0x00007588ECC0E760
00007588ecdcec00  jmp 0x00007588ECDCE801
00007588ecdcec05  call 0x00007588ECC0D600
00007588ecdcec0a  jmp 0x00007588ECDCE81F
00007588ecdcec0f  call 0x00007588ECBFF540
00007588ecdcec14  jmp 0x00007588ECDCE82A
00007588ecdcec19  call 0x00007588ECBFF430
00007588ecdcec1e  jmp 0x00007588ECDCE835
00007588ecdcec23  call 0x00007588ECC0D4E0
00007588ecdcec28  jmp 0x00007588ECDCE840
00007588ecdcec2d  call 0x00007588ECC0BC20
00007588ecdcec32  jmp 0x00007588ECDCE870
00007588ecdcec37  call 0x00007588ECC0A9A0
00007588ecdcec3c  jmp 0x00007588ECDCE87C
00007588ecdcec41  call 0x00007588ECC0E880
00007588ecdcec46  jmp 0x00007588ECDCE887
00007588ecdcec4b  call 0x00007588ECBFF540
00007588ecdcec50  jmp 0x00007588ECDCE892
00007588ecdcec55  call 0x00007588ECBFF430
00007588ecdcec5a  jmp 0x00007588ECDCE89D
00007588ecdcec5f  call 0x00007588ECC0B720
00007588ecdcec64  jmp 0x00007588ECDCE8A7
00007588ecdcec69  call 0x00007588ECC0D600
00007588ecdcec6e  jmp 0x00007588ECDCE8BF
00007588ecdcec73  call 0x00007588ECBFF540
00007588ecdcec78  jmp 0x00007588ECDCE8CA
00007588ecdcec7d  call 0x00007588ECBFF430
00007588ecdcec82  jmp 0x00007588ECDCE8D5
00007588ecdcec87  call 0x00007588ECCB4CB0
00007588ecdcec8c  jmp 0x00007588ECDCE8E5
00007588ecdcec91  call 0x00007588ECC0E760
00007588ecdcec96  jmp 0x00007588ECDCE8F0
00007588ecdcec9b  call 0x00007588ECC0D4E0
00007588ecdceca0  jmp 0x00007588ECDCE8FB
00007588ecdceca5  call 0x00007588ECBFF540
00007588ecdcecaa  jmp 0x00007588ECDCE908
00007588ecdcecaf  call 0x00007588ECC0BC20
00007588ecdcecb4  jmp 0x00007588ECDCE930
00007588ecdcecb9  call 0x00007588ECC0A9A0
00007588ecdcecbe  jmp 0x00007588ECDCE93C
00007588ecdcecc3  call 0x00007588ECC0E880
00007588ecdcecc8  jmp 0x00007588ECDCE949
00007588ecdceccd  call 0x00007588ECC0D600
00007588ecdcecd2  jmp 0x00007588ECDCE956
00007588ecdcecd7  call 0x00007588ECBFF430
00007588ecdcecdc  jmp 0x00007588ECDCE961
00007588ecdcece1  call 0x00007588ECC0E760
00007588ecdcece6  jmp 0x00007588ECDCE96C
00007588ecdceceb  call 0x00007588ECC0BC20
00007588ecdcecf0  jmp 0x00007588ECDCE99C
00007588ecdcecf5  call 0x00007588ECC0A9A0
00007588ecdcecfa  jmp 0x00007588ECDCE9A8
00007588ecdcecff  call 0x00007588ECC0BC20
00007588ecdced04  jmp 0x00007588ECDCE9D0
00007588ecdced09  call 0x00007588ECC0A9A0
00007588ecdced0e  jmp 0x00007588ECDCE9DC
00007588ecdced13  call 0x00007588ECBFF540
00007588ecdced18  jmp 0x00007588ECDCE9E9
00007588ecdced1d  call 0x00007588ECC0E880
00007588ecdced22  jmp 0x00007588ECDCE9F6
00007588ecdced27  call 0x00007588ECBFF430
00007588ecdced2c  jmp 0x00007588ECDCEA01
00007588ecdced31  call 0x00007588ECC0E760
00007588ecdced36  jmp 0x00007588ECDCEA0C
00007588ecdced3b  call 0x00007588ECC0BC20
00007588ecdced40  jmp 0x00007588ECDCEA36
00007588ecdced45  call 0x00007588ECC0A9A0
00007588ecdced4a  jmp 0x00007588ECDCEA42
00007588ecdced4f  call 0x00007588ECC0BAE0
00007588ecdced54  jmp 0x00007588ECDCEA52
00007588ecdced59  call 0x00007588ECBFF540
00007588ecdced5e  jmp 0x00007588ECDCEA5F
00007588ecdced63  call 0x00007588ECC0E880
00007588ecdced68  jmp 0x00007588ECDCEA6C
00007588ecdced6d  int3
00007588ecdced6e  nop
00007588ecdced70  mov rax, [r15]
00007588ecdced73  lea r14, [rax+0x20]
00007588ecdced77  mov r12, [r13+r14*1]
00007588ecdced7c  mov r14, [r15+0x10]
00007588ecdced80  lea r11, [r12+r14*1]
00007588ecdced84  mov [r15+0x40], r11
00007588ecdced88  lea r12, [rax+0x20]
00007588ecdced8c  mov [r13+r12*1], r11
00007588ecdced91  test r14, r14
00007588ecdced94  setz r14b
00007588ecdced98  movzx r14, r14b
00007588ecdced9c  mov [rsp+0x414], r14b
00007588ecdceda4  cmp byte ptr [rsp+0x414], 0x00
00007588ecdcedac  jz 0x00007588ECDCEDDE
00007588ecdcedae  cmp dword ptr [r15+0x318], 0x00
00007588ecdcedb6  mov eax, 0x410934
00007588ecdcedbb  mov [r15+0x100], rax
00007588ecdcedc2  jz 0x00007588ECBFE0A0
00007588ecdcedc8  nop [rax+rax*1], eax
00007588ecdcedcd  mov eax, 0x410934
00007588ecdcedd2  mov [r15+0x100], rax
00007588ecdcedd9  jmp 0x00007588ECBFE110
00007588ecdcedde  cmp dword ptr [r15+0x318], 0x00
00007588ecdcede6  jz 0x00007588ECDCEE30
00007588ecdcedec  nop [rax+rax*1], ax
00007588ecdcedf5  nop [rax+rax*1], eax
00007588ecdcedfd  mov eax, 0x4106CC
00007588ecdcee02  mov [r15+0x100], rax
00007588ecdcee09  jmp 0x00007588ECBFE110
00007588ecdcee0e  int3
00007588ecdcee0f  call 0x00007588ECCE27E0
00007588ecdcee14  jmp 0x00007588ECDCED7C
00007588ecdcee19  call 0x00007588ECCC0860
00007588ecdcee1e  jmp 0x00007588ECDCED91
00007588ecdcee23  int3
00007588ecdcee24  nop [rax+rax*1], ax
00007588ecdcee2d  nop [rax], eax
00007588ecdcee30  mov rax, [r15+0xF8]
00007588ecdcee37  lea r14, [rax-0x150]
00007588ecdcee3e  mov [r15+0xF8], r14
00007588ecdcee45  mov rax, [r15]
00007588ecdcee48  lea r12, [rax+0x68]
00007588ecdcee4c  mov r11, [r13+r12*1]
00007588ecdcee51  mov [r15+0x88], r11
00007588ecdcee58  lea r12, [rax+0x28]
00007588ecdcee5c  mov [r15+0x40], r12
00007588ecdcee60  mov [r15+0x48], r14
00007588ecdcee64  mov qword ptr [r15+0x50], 0x420B20
00007588ecdcee6c  lea rax, [r14+0x100]
00007588ecdcee73  mov r12, [r15+0xE8]
00007588ecdcee7a  mov r11, [r15+0xD8]
00007588ecdcee81  mov [r13+rax*1], r12
00007588ecdcee86  lea rax, [r14+0x108]
00007588ecdcee8d  mov [r13+rax*1], r11
00007588ecdcee92  lea rax, [r14+0x110]
00007588ecdcee99  mov r12, [r15+0xD0]
00007588ecdceea0  mov r11, [r15+0xC8]
00007588ecdceea7  mov [r13+rax*1], r12
00007588ecdceeac  lea rax, [r14+0x118]
00007588ecdceeb3  mov [r13+rax*1], r11
00007588ecdceeb8  lea rax, [r14+0x120]
00007588ecdceebf  mov r12, [r15+0xC0]
00007588ecdceec6  mov r11, [r15+0xB8]
00007588ecdceecd  mov [r13+rax*1], r12
00007588ecdceed2  lea rax, [r14+0x128]
00007588ecdceed9  mov [r13+rax*1], r11
00007588ecdceede  lea rax, [r14+0x130]
00007588ecdceee5  mov r12, [r15+0xB0]
00007588ecdceeec  mov r11, [r15+0xA8]
00007588ecdceef3  mov [r13+rax*1], r12
00007588ecdceef8  lea rax, [r14+0x138]
00007588ecdceeff  mov [r13+rax*1], r11
00007588ecdcef04  lea rax, [r14+0x140]
00007588ecdcef0b  mov r12, [r15+0xA0]
00007588ecdcef12  mov r11, [r15+0x98]
00007588ecdcef19  mov [r13+rax*1], r12
00007588ecdcef1e  lea rax, [r14+0x148]
00007588ecdcef25  mov [r13+rax*1], r11
00007588ecdcef2a  cmp dword ptr [r15+0x318], 0x00
00007588ecdcef32  jz 0x00007588ECDCEFD0
00007588ecdcef38  nop [rax+rax*1], ax
00007588ecdcef41  nop [rax+rax*1], eax
00007588ecdcef49  mov eax, 0x410704
00007588ecdcef4e  mov [r15+0x100], rax
00007588ecdcef55  jmp 0x00007588ECBFE110
00007588ecdcef5a  int3
00007588ecdcef5b  call 0x00007588ECCC0370
00007588ecdcef60  jmp 0x00007588ECDCEE51
00007588ecdcef65  call 0x00007588ECC0BC20
00007588ecdcef6a  jmp 0x00007588ECDCEE86
00007588ecdcef6f  call 0x00007588ECC0A9A0
00007588ecdcef74  jmp 0x00007588ECDCEE92
00007588ecdcef79  call 0x00007588ECC0BC20
00007588ecdcef7e  jmp 0x00007588ECDCEEAC
00007588ecdcef83  call 0x00007588ECC0A9A0
00007588ecdcef88  jmp 0x00007588ECDCEEB8
00007588ecdcef8d  call 0x00007588ECC0BC20
00007588ecdcef92  jmp 0x00007588ECDCEED2
00007588ecdcef97  call 0x00007588ECC0A9A0
00007588ecdcef9c  jmp 0x00007588ECDCEEDE
00007588ecdcefa1  call 0x00007588ECC0BC20
00007588ecdcefa6  jmp 0x00007588ECDCEEF8
00007588ecdcefab  call 0x00007588ECC0A9A0
00007588ecdcefb0  jmp 0x00007588ECDCEF04
00007588ecdcefb5  call 0x00007588ECC0BC20
00007588ecdcefba  jmp 0x00007588ECDCEF1E
00007588ecdcefbf  call 0x00007588ECC0A9A0
00007588ecdcefc4  jmp 0x00007588ECDCEF2A
00007588ecdcefc9  int3
00007588ecdcefca  nop [rax+rax*1], ax
00007588ecdcefd0  mov rax, [r15+0x08]
00007588ecdcefd4  movzx r14d, byte ptr [r13+rax*1]
00007588ecdcefda  movzx r14d, r14b
00007588ecdcefde  mov [rsp+0x10], r14d
00007588ecdcefe3  mov r14d, r14d
00007588ecdcefe6  mov [r15+0x58], r14
00007588ecdcefea  lea r14, [rax+0x01]
00007588ecdcefee  mov [r15+0x08], r14
00007588ecdceff2  mov rax, [r15+0x88]
00007588ecdceff9  lea r14, [rax+0x01]
00007588ecdceffd  mov r12, [r15]
00007588ecdcf000  lea r11, [r12+0x68]
00007588ecdcf005  mov [r13+r11*1], r14
00007588ecdcf00a  lea r14, [r12+rax*1]
00007588ecdcf00e  mov [r15+0x60], r14
00007588ecdcf012  lea rax, [r14+0x28]
00007588ecdcf016  mov r11d, [rsp+0x10]
00007588ecdcf01b  movzx r14d, r11b
00007588ecdcf01f  mov [r13+rax*1], r14b
00007588ecdcf024  lea rax, [r12+0x68]
00007588ecdcf029  mov r14, [r13+rax*1]
00007588ecdcf02e  mov [r15+0x88], r14
00007588ecdcf035  xor eax, eax
00007588ecdcf037  mov r12d, 0x40
00007588ecdcf03d  cmp r14, r12
00007588ecdcf040  cmc
00007588ecdcf041  lahf
00007588ecdcf042  seto al
00007588ecdcf045  mov [r15+0x108], eax
00007588ecdcf04c  mov eax, [r15+0x108]
00007588ecdcf053  sahf
00007588ecdcf054  jnz 0x00007588ECDCF086
00007588ecdcf056  cmp dword ptr [r15+0x318], 0x00
00007588ecdcf05e  jz 0x00007588ECDCF170
00007588ecdcf064  nop [rax+rax*1], ax
00007588ecdcf06d  nop [rax+rax*1], eax
00007588ecdcf075  mov eax, 0x410724
00007588ecdcf07a  mov [r15+0x100], rax
00007588ecdcf081  jmp 0x00007588ECBFE110
00007588ecdcf086  cmp dword ptr [r15+0x318], 0x00
00007588ecdcf08e  jz 0x00007588ECDCF0E0
00007588ecdcf094  nop [rax+rax*1], ax
00007588ecdcf09d  nop [rax+rax*1], eax
00007588ecdcf0a5  mov eax, 0x4106FC
00007588ecdcf0aa  mov [r15+0x100], rax
00007588ecdcf0b1  jmp 0x00007588ECBFE110
00007588ecdcf0b6  int3
00007588ecdcf0b7  call 0x00007588ECC0D860
00007588ecdcf0bc  jmp 0x00007588ECDCEFDA
00007588ecdcf0c1  call 0x00007588ECCB36E0
00007588ecdcf0c6  jmp 0x00007588ECDCF00A
00007588ecdcf0cb  call 0x00007588ECC0DD60
00007588ecdcf0d0  jmp 0x00007588ECDCF024
00007588ecdcf0d5  call 0x00007588ECC0DC20
00007588ecdcf0da  jmp 0x00007588ECDCF02E
00007588ecdcf0df  int3
00007588ecdcf0e0  mov rax, [r15+0x10]
00007588ecdcf0e4  lea r14, [rax-0x01]
00007588ecdcf0e8  mov [r15+0x10], r14
00007588ecdcf0ec  test r14, r14
00007588ecdcf0ef  setz r14b
00007588ecdcf0f3  movzx r14, r14b
00007588ecdcf0f7  mov [rsp+0x414], r14b
00007588ecdcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007588ecdcf107  jz 0x00007588ECDCF139
00007588ecdcf109  cmp dword ptr [r15+0x318], 0x00
00007588ecdcf111  jz 0x00007588ECDD0670
00007588ecdcf117  nop [rax+rax*1], ax
00007588ecdcf120  nop [rax+rax*1], eax
00007588ecdcf128  mov eax, 0x41091C
00007588ecdcf12d  mov [r15+0x100], rax
00007588ecdcf134  jmp 0x00007588ECBFE110
00007588ecdcf139  cmp dword ptr [r15+0x318], 0x00
00007588ecdcf141  jz 0x00007588ECDCEFD0
00007588ecdcf147  nop [rax+rax*1], ax
00007588ecdcf150  nop [rax+rax*1], eax
00007588ecdcf158  mov eax, 0x410704
00007588ecdcf15d  mov [r15+0x100], rax
00007588ecdcf164  jmp 0x00007588ECBFE110
00007588ecdcf169  int3
00007588ecdcf16a  int3
00007588ecdcf16b  nop [rax+rax*1], eax
00007588ecdcf170  mov rax, [r15+0x40]
00007588ecdcf174  movzx r14d, byte ptr [r13+rax*1]
00007588ecdcf17a  movaps xmm1, [r15+0x110]
00007588ecdcf182  pinsrb xmm1, r14d, 0x00
00007588ecdcf189  lea r14, [rax+0x01]
00007588ecdcf18d  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf193  movaps xmm15, [r15+0x120]
00007588ecdcf19b  pinsrb xmm15, r12d, 0x00
00007588ecdcf1a2  lea r14, [rax+0x02]
00007588ecdcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf1ac  movaps xmm14, [r15+0x130]
00007588ecdcf1b4  pinsrb xmm14, r12d, 0x00
00007588ecdcf1bb  lea r14, [rax+0x03]
00007588ecdcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf1c5  movaps xmm13, [r15+0x140]
00007588ecdcf1cd  pinsrb xmm13, r12d, 0x00
00007588ecdcf1d4  lea r14, [rax+0x04]
00007588ecdcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf1de  pinsrb xmm1, r12d, 0x01
00007588ecdcf1e5  lea r14, [rax+0x05]
00007588ecdcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf1ef  pinsrb xmm15, r12d, 0x01
00007588ecdcf1f6  lea r14, [rax+0x06]
00007588ecdcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf200  pinsrb xmm14, r12d, 0x01
00007588ecdcf207  lea r14, [rax+0x07]
00007588ecdcf20b  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf211  pinsrb xmm13, r12d, 0x01
00007588ecdcf218  lea r14, [rax+0x08]
00007588ecdcf21c  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf222  pinsrb xmm1, r12d, 0x02
00007588ecdcf229  lea r14, [rax+0x09]
00007588ecdcf22d  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf233  pinsrb xmm15, r12d, 0x02
00007588ecdcf23a  lea r14, [rax+0x0A]
00007588ecdcf23e  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf244  pinsrb xmm14, r12d, 0x02
00007588ecdcf24b  lea r14, [rax+0x0B]
00007588ecdcf24f  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf255  pinsrb xmm13, r12d, 0x02
00007588ecdcf25c  lea r14, [rax+0x0C]
00007588ecdcf260  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf266  pinsrb xmm1, r12d, 0x03
00007588ecdcf26d  lea r14, [rax+0x0D]
00007588ecdcf271  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf277  pinsrb xmm15, r12d, 0x03
00007588ecdcf27e  lea r14, [rax+0x0E]
00007588ecdcf282  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf288  pinsrb xmm14, r12d, 0x03
00007588ecdcf28f  lea r14, [rax+0x0F]
00007588ecdcf293  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf299  pinsrb xmm13, r12d, 0x03
00007588ecdcf2a0  lea r14, [rax+0x10]
00007588ecdcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf2aa  pinsrb xmm1, r12d, 0x04
00007588ecdcf2b1  lea r14, [rax+0x11]
00007588ecdcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf2bb  pinsrb xmm15, r12d, 0x04
00007588ecdcf2c2  lea r14, [rax+0x12]
00007588ecdcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf2cc  pinsrb xmm14, r12d, 0x04
00007588ecdcf2d3  lea r14, [rax+0x13]
00007588ecdcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf2dd  pinsrb xmm13, r12d, 0x04
00007588ecdcf2e4  lea r14, [rax+0x14]
00007588ecdcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf2ee  pinsrb xmm1, r12d, 0x05
00007588ecdcf2f5  lea r14, [rax+0x15]
00007588ecdcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf2ff  pinsrb xmm15, r12d, 0x05
00007588ecdcf306  lea r14, [rax+0x16]
00007588ecdcf30a  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf310  pinsrb xmm14, r12d, 0x05
00007588ecdcf317  lea r14, [rax+0x17]
00007588ecdcf31b  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf321  pinsrb xmm13, r12d, 0x05
00007588ecdcf328  lea r14, [rax+0x18]
00007588ecdcf32c  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf332  pinsrb xmm1, r12d, 0x06
00007588ecdcf339  lea r14, [rax+0x19]
00007588ecdcf33d  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf343  pinsrb xmm15, r12d, 0x06
00007588ecdcf34a  lea r14, [rax+0x1A]
00007588ecdcf34e  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf354  pinsrb xmm14, r12d, 0x06
00007588ecdcf35b  lea r14, [rax+0x1B]
00007588ecdcf35f  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf365  pinsrb xmm13, r12d, 0x06
00007588ecdcf36c  lea r14, [rax+0x1C]
00007588ecdcf370  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf376  pinsrb xmm1, r12d, 0x07
00007588ecdcf37d  lea r14, [rax+0x1D]
00007588ecdcf381  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf387  pinsrb xmm15, r12d, 0x07
00007588ecdcf38e  lea r14, [rax+0x1E]
00007588ecdcf392  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf398  pinsrb xmm14, r12d, 0x07
00007588ecdcf39f  lea r14, [rax+0x1F]
00007588ecdcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf3a9  pinsrb xmm13, r12d, 0x07
00007588ecdcf3b0  lea r14, [rax+0x20]
00007588ecdcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf3ba  pinsrb xmm1, r12d, 0x08
00007588ecdcf3c1  lea r14, [rax+0x21]
00007588ecdcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf3cb  pinsrb xmm15, r12d, 0x08
00007588ecdcf3d2  lea r14, [rax+0x22]
00007588ecdcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf3dc  pinsrb xmm14, r12d, 0x08
00007588ecdcf3e3  lea r14, [rax+0x23]
00007588ecdcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf3ed  pinsrb xmm13, r12d, 0x08
00007588ecdcf3f4  lea r14, [rax+0x24]
00007588ecdcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf3fe  pinsrb xmm1, r12d, 0x09
00007588ecdcf405  lea r14, [rax+0x25]
00007588ecdcf409  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf40f  pinsrb xmm15, r12d, 0x09
00007588ecdcf416  lea r14, [rax+0x26]
00007588ecdcf41a  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf420  pinsrb xmm14, r12d, 0x09
00007588ecdcf427  lea r14, [rax+0x27]
00007588ecdcf42b  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf431  pinsrb xmm13, r12d, 0x09
00007588ecdcf438  lea r14, [rax+0x28]
00007588ecdcf43c  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf442  pinsrb xmm1, r12d, 0x0A
00007588ecdcf449  lea r14, [rax+0x29]
00007588ecdcf44d  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf453  pinsrb xmm15, r12d, 0x0A
00007588ecdcf45a  lea r14, [rax+0x2A]
00007588ecdcf45e  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf464  pinsrb xmm14, r12d, 0x0A
00007588ecdcf46b  lea r14, [rax+0x2B]
00007588ecdcf46f  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf475  pinsrb xmm13, r12d, 0x0A
00007588ecdcf47c  lea r14, [rax+0x2C]
00007588ecdcf480  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf486  pinsrb xmm1, r12d, 0x0B
00007588ecdcf48d  lea r14, [rax+0x2D]
00007588ecdcf491  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf497  pinsrb xmm15, r12d, 0x0B
00007588ecdcf49e  lea r14, [rax+0x2E]
00007588ecdcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf4a8  pinsrb xmm14, r12d, 0x0B
00007588ecdcf4af  lea r14, [rax+0x2F]
00007588ecdcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf4b9  pinsrb xmm13, r12d, 0x0B
00007588ecdcf4c0  lea r14, [rax+0x30]
00007588ecdcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf4ca  pinsrb xmm1, r12d, 0x0C
00007588ecdcf4d1  lea r14, [rax+0x31]
00007588ecdcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf4db  pinsrb xmm15, r12d, 0x0C
00007588ecdcf4e2  lea r14, [rax+0x32]
00007588ecdcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf4ec  pinsrb xmm14, r12d, 0x0C
00007588ecdcf4f3  lea r14, [rax+0x33]
00007588ecdcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf4fd  pinsrb xmm13, r12d, 0x0C
00007588ecdcf504  lea r14, [rax+0x34]
00007588ecdcf508  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf50e  pinsrb xmm1, r12d, 0x0D
00007588ecdcf515  lea r14, [rax+0x35]
00007588ecdcf519  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf51f  pinsrb xmm15, r12d, 0x0D
00007588ecdcf526  lea r14, [rax+0x36]
00007588ecdcf52a  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf530  pinsrb xmm14, r12d, 0x0D
00007588ecdcf537  lea r14, [rax+0x37]
00007588ecdcf53b  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf541  pinsrb xmm13, r12d, 0x0D
00007588ecdcf548  lea r14, [rax+0x38]
00007588ecdcf54c  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf552  pinsrb xmm1, r12d, 0x0E
00007588ecdcf559  lea r14, [rax+0x39]
00007588ecdcf55d  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf563  pinsrb xmm15, r12d, 0x0E
00007588ecdcf56a  lea r14, [rax+0x3A]
00007588ecdcf56e  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf574  pinsrb xmm14, r12d, 0x0E
00007588ecdcf57b  lea r14, [rax+0x3B]
00007588ecdcf57f  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf585  pinsrb xmm13, r12d, 0x0E
00007588ecdcf58c  lea r14, [rax+0x3C]
00007588ecdcf590  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf596  pinsrb xmm1, r12d, 0x0F
00007588ecdcf59d  movaps [r15+0x110], xmm1
00007588ecdcf5a5  lea r14, [rax+0x3D]
00007588ecdcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf5af  pinsrb xmm15, r12d, 0x0F
00007588ecdcf5b6  movaps [r15+0x120], xmm15
00007588ecdcf5be  lea r14, [rax+0x3E]
00007588ecdcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007588ecdcf5c8  pinsrb xmm14, r12d, 0x0F
00007588ecdcf5cf  movaps [r15+0x130], xmm14
00007588ecdcf5d7  lea r14, [rax+0x3F]
00007588ecdcf5db  movzx eax, byte ptr [r13+r14*1]
00007588ecdcf5e1  pinsrb xmm13, eax, 0x0F
00007588ecdcf5e8  movaps [r15+0x140], xmm13
00007588ecdcf5f0  movq xmm1, qword ptr [r15+0x120]
00007588ecdcf5f9  pmovzxbw xmm1, xmm1
00007588ecdcf5fe  psllw xmm1, 0x00
00007588ecdcf603  movaps [r15+0x150], xmm1
00007588ecdcf60b  movq xmm1, qword ptr [r15+0x130]
00007588ecdcf614  pmovzxbw xmm1, xmm1
00007588ecdcf619  psllw xmm1, 0x00
00007588ecdcf61e  movaps [r15+0x160], xmm1
00007588ecdcf626  movq xmm1, qword ptr [r15+0x110]
00007588ecdcf62f  pmovzxbw xmm1, xmm1
00007588ecdcf634  psllw xmm1, 0x00
00007588ecdcf639  movaps [r15+0x170], xmm1
00007588ecdcf641  movaps xmm15, [r15+0x110]
00007588ecdcf649  pextrq rax, xmm15, 0x01
00007588ecdcf650  movq xmm15, rax
00007588ecdcf655  pmovzxbw xmm15, xmm15
00007588ecdcf65b  psllw xmm15, 0x00
00007588ecdcf661  movaps [r15+0x180], xmm15
00007588ecdcf669  movaps xmm14, [r15+0x120]
00007588ecdcf671  pextrq rax, xmm14, 0x01
00007588ecdcf678  movq xmm14, rax
00007588ecdcf67d  pmovzxbw xmm14, xmm14
00007588ecdcf683  psllw xmm14, 0x00
00007588ecdcf689  movaps [r15+0x210], xmm14
00007588ecdcf691  movaps xmm13, [r15+0x130]
00007588ecdcf699  pextrq rax, xmm13, 0x01
00007588ecdcf6a0  movq xmm13, rax
00007588ecdcf6a5  pmovzxbw xmm13, xmm13
00007588ecdcf6ab  psllw xmm13, 0x00
00007588ecdcf6b1  movaps [r15+0x220], xmm13
00007588ecdcf6b9  movq xmm12, qword ptr [r15+0x140]
00007588ecdcf6c2  pmovzxbw xmm12, xmm12
00007588ecdcf6c8  psllw xmm12, 0x00
00007588ecdcf6ce  movaps [r15+0x250], xmm12
00007588ecdcf6d6  movaps xmm12, [r15+0x140]
00007588ecdcf6de  pextrq rax, xmm12, 0x01
00007588ecdcf6e5  movq xmm12, rax
00007588ecdcf6ea  pmovzxbw xmm12, xmm12
00007588ecdcf6f0  psllw xmm12, 0x00
00007588ecdcf6f6  movaps [r15+0x110], xmm12
00007588ecdcf6fe  movq xmm11, qword ptr [r15+0x150]
00007588ecdcf707  pmovzxwd xmm11, xmm11
00007588ecdcf70d  pslld xmm11, 0x10
00007588ecdcf713  movq xmm10, qword ptr [r15+0x160]
00007588ecdcf71c  pmovzxwd xmm10, xmm10
00007588ecdcf722  pslld xmm10, 0x08
00007588ecdcf728  pextrq rax, xmm1, 0x01
00007588ecdcf72f  movq xmm1, rax
00007588ecdcf734  pmovzxwd xmm1, xmm1
00007588ecdcf739  pslld xmm1, 0x00
00007588ecdcf73e  movaps [r15+0x260], xmm1
00007588ecdcf746  pextrq rax, xmm15, 0x01
00007588ecdcf74d  movq xmm15, rax
00007588ecdcf752  pmovzxwd xmm15, xmm15
00007588ecdcf758  pslld xmm15, 0x00
00007588ecdcf75e  movaps [r15+0x270], xmm15
00007588ecdcf766  movq xmm9, qword ptr [r15+0x170]
00007588ecdcf76f  pmovzxwd xmm9, xmm9
00007588ecdcf775  pslld xmm9, 0x00
00007588ecdcf77b  pextrq rax, xmm14, 0x01
00007588ecdcf782  movq xmm14, rax
00007588ecdcf787  pmovzxwd xmm14, xmm14
00007588ecdcf78d  pslld xmm14, 0x10
00007588ecdcf793  movaps [r15+0x280], xmm14
00007588ecdcf79b  movq xmm8, qword ptr [r15+0x180]
00007588ecdcf7a4  pmovzxwd xmm8, xmm8
00007588ecdcf7aa  pslld xmm8, 0x00
00007588ecdcf7b0  movq xmm7, qword ptr [r15+0x210]
00007588ecdcf7b9  pmovzxwd xmm7, xmm7
00007588ecdcf7be  pslld xmm7, 0x10
00007588ecdcf7c3  movaps xmm6, [r15+0x150]
00007588ecdcf7cb  pextrq rax, xmm6, 0x01
00007588ecdcf7d2  movq xmm6, rax
00007588ecdcf7d7  pmovzxwd xmm6, xmm6
00007588ecdcf7dc  pslld xmm6, 0x10
00007588ecdcf7e1  por xmm11, xmm10
00007588ecdcf7e6  movaps [r15+0x230], xmm11
00007588ecdcf7ee  pextrq rax, xmm13, 0x01
00007588ecdcf7f5  movq xmm13, rax
00007588ecdcf7fa  pmovzxwd xmm13, xmm13
00007588ecdcf800  pslld xmm13, 0x08
00007588ecdcf806  movaps [r15+0x240], xmm13
00007588ecdcf80e  movq xmm10, qword ptr [r15+0x220]
00007588ecdcf817  pmovzxwd xmm10, xmm10
00007588ecdcf81d  pslld xmm10, 0x08
00007588ecdcf823  movaps xmm5, [r15+0x160]
00007588ecdcf82b  pextrq rax, xmm5, 0x01
00007588ecdcf832  movq xmm5, rax
00007588ecdcf837  pmovzxwd xmm5, xmm5
00007588ecdcf83c  pslld xmm5, 0x08
00007588ecdcf841  pslld xmm9, 0x18
00007588ecdcf847  pslld xmm15, 0x18
00007588ecdcf84d  pslld xmm8, 0x18
00007588ecdcf853  movq xmm4, qword ptr [r15+0x250]
00007588ecdcf85c  pmovzxwd xmm4, xmm4
00007588ecdcf861  pslld xmm4, 0x00
00007588ecdcf866  por xmm14, xmm13
00007588ecdcf86b  por xmm7, xmm10
00007588ecdcf870  movaps [r15+0x210], xmm7
00007588ecdcf878  pslld xmm1, 0x18
00007588ecdcf87d  movaps [r15+0x220], xmm1
00007588ecdcf885  por xmm6, xmm5
00007588ecdcf889  por xmm11, xmm9
00007588ecdcf88e  movaps [r15+0x160], xmm11
00007588ecdcf896  pextrq rax, xmm12, 0x01
00007588ecdcf89d  movq xmm13, rax
00007588ecdcf8a2  pmovzxwd xmm13, xmm13
00007588ecdcf8a8  pslld xmm13, 0x00
00007588ecdcf8ae  movaps [r15+0x170], xmm13
00007588ecdcf8b6  movq xmm12, qword ptr [r15+0x110]
00007588ecdcf8bf  pmovzxwd xmm12, xmm12
00007588ecdcf8c5  pslld xmm12, 0x00
00007588ecdcf8cb  por xmm14, xmm15
00007588ecdcf8d0  por xmm7, xmm8
00007588ecdcf8d5  movaps xmm15, [r15+0x250]
00007588ecdcf8dd  pextrq rax, xmm15, 0x01
00007588ecdcf8e4  movq xmm15, rax
00007588ecdcf8e9  pmovzxwd xmm15, xmm15
00007588ecdcf8ef  pslld xmm15, 0x00
00007588ecdcf8f5  movaps [r15+0x180], xmm15
00007588ecdcf8fd  por xmm6, xmm1
00007588ecdcf901  movaps [r15+0x150], xmm6
00007588ecdcf909  por xmm11, xmm4
00007588ecdcf90e  movaps [r15+0x140], xmm11
00007588ecdcf916  por xmm7, xmm12
00007588ecdcf91b  movaps [r15+0x110], xmm7
00007588ecdcf923  por xmm14, xmm13
00007588ecdcf928  movaps [r15+0x120], xmm14
00007588ecdcf930  por xmm6, xmm15
00007588ecdcf935  movaps [r15+0x130], xmm6
00007588ecdcf93d  mov rax, [r15+0xF8]
00007588ecdcf944  lea r14, [rax+0x20]
00007588ecdcf948  movups [r13+r14*1], xmm7
00007588ecdcf94e  lea r14, [rax+0x30]
00007588ecdcf952  movups [r13+r14*1], xmm14
00007588ecdcf958  movups [r13+rax*1], xmm11
00007588ecdcf95e  lea r14, [rax+0x10]
00007588ecdcf962  movups [r13+r14*1], xmm6
00007588ecdcf968  mov r14d, [r13+rax*1]
00007588ecdcf96d  mov rax, [r15+0x48]
00007588ecdcf971  mov [r15+0x68], rax
00007588ecdcf975  mov qword ptr [r15+0x58], 0x04
00007588ecdcf97d  lea r12, [rax+0x04]
00007588ecdcf981  mov r11d, [r13+r12*1]
00007588ecdcf986  mov [rsp+0x10], r11d
00007588ecdcf98b  mov r11d, r11d
00007588ecdcf98e  mov [r15+0x70], r11
00007588ecdcf992  lea r12, [rax+0x38]
00007588ecdcf996  mov r11d, [r13+r12*1]
00007588ecdcf99b  lea r12, [rax+0x24]
00007588ecdcf99f  mov r10d, [r13+r12*1]
00007588ecdcf9a4  mov [rsp+0x20], r10d
00007588ecdcf9a9  mov r10d, r10d
00007588ecdcf9ac  mov [r15+0x90], r10
00007588ecdcf9b3  mov [rsp+0x30], rax
00007588ecdcf9b8  xor eax, eax
00007588ecdcf9ba  mov r12d, 0x04
00007588ecdcf9c0  mov r10d, 0xC0
00007588ecdcf9c6  cmp r12, r10
00007588ecdcf9c9  cmc
00007588ecdcf9ca  lahf
00007588ecdcf9cb  seto al
00007588ecdcf9ce  mov [r15+0x108], eax
00007588ecdcf9d5  mov eax, [rsp+0x10]
00007588ecdcf9d9  mov r12d, [rsp+0x10]
00007588ecdcf9de  shrd eax, r12d, 0x07
00007588ecdcf9e3  mov [rsp+0x10], r11d
00007588ecdcf9e8  mov r10d, [rsp+0x10]
00007588ecdcf9ed  shrd r11d, r10d, 0x11
00007588ecdcf9f2  mov r9d, [rsp+0x20]
00007588ecdcf9f7  lea r8d, [r9d+r14d*1]
00007588ecdcf9fc  rorx r14d, r12d, 0x12
00007588ecdcfa02  xor eax, r14d
00007588ecdcfa05  rorx r14d, r10d, 0x13
00007588ecdcfa0b  xor r11d, r14d
00007588ecdcfa0e  mov [rsp+0x10], r11d
00007588ecdcfa13  mov r11d, r11d
00007588ecdcfa16  mov [r15+0x88], r11
00007588ecdcfa1d  mov [rsp+0x20], r12d
00007588ecdcfa22  shr r12d, 0x03
00007588ecdcfa26  xor eax, r12d
00007588ecdcfa29  mov [rsp+0x40], eax
00007588ecdcfa2d  mov eax, eax
00007588ecdcfa2f  mov [r15+0x80], rax
00007588ecdcfa36  shr r10d, 0x0A
00007588ecdcfa3a  mov eax, [rsp+0x10]
00007588ecdcfa3e  xor eax, r10d
00007588ecdcfa41  mov [rsp+0x10], eax
00007588ecdcfa45  mov eax, eax
00007588ecdcfa47  mov [r15+0x78], rax
00007588ecdcfa4b  mov eax, [rsp+0x40]
00007588ecdcfa4f  lea r14d, [r8d+eax*1]
00007588ecdcfa54  mov eax, [rsp+0x10]
00007588ecdcfa58  lea r12d, [r14d+eax*1]
00007588ecdcfa5d  mov rax, [rsp+0x30]
00007588ecdcfa62  lea r14, [rax+0x40]
00007588ecdcfa66  mov [r13+r14*1], r12d
00007588ecdcfa6b  mov eax, [rsp+0x20]
00007588ecdcfa6f  mov eax, eax
00007588ecdcfa71  mov [r15+0x60], rax
00007588ecdcfa75  mov eax, [r15+0x108]
00007588ecdcfa7c  sahf
00007588ecdcfa7d  jnz 0x00007588ECDCFAAF
00007588ecdcfa7f  cmp dword ptr [r15+0x318], 0x00
00007588ecdcfa87  jz 0x00007588ECDCFF70
00007588ecdcfa8d  nop [rax+rax*1], ax
00007588ecdcfa96  nop [rax+rax*1], eax
00007588ecdcfa9e  mov eax, 0x410820
00007588ecdcfaa3  mov [r15+0x100], rax
00007588ecdcfaaa  jmp 0x00007588ECBFE110
00007588ecdcfaaf  cmp dword ptr [r15+0x318], 0x00
00007588ecdcfab7  jz 0x00007588ECDCFDC0
00007588ecdcfabd  nop [rax+rax*1], ax
00007588ecdcfac6  nop [rax+rax*1], eax
00007588ecdcface  mov eax, 0x4107D8
00007588ecdcfad3  mov [r15+0x100], rax
00007588ecdcfada  jmp 0x00007588ECBFE110
00007588ecdcfadf  int3
00007588ecdcfae0  call 0x00007588ECC0D860
00007588ecdcfae5  jmp 0x00007588ECDCF17A
00007588ecdcfaea  call 0x00007588ECCE2420
00007588ecdcfaef  jmp 0x00007588ECDCF193
00007588ecdcfaf4  call 0x00007588ECCE2420
00007588ecdcfaf9  jmp 0x00007588ECDCF1AC
00007588ecdcfafe  call 0x00007588ECCE2420
00007588ecdcfb03  jmp 0x00007588ECDCF1C5
00007588ecdcfb08  call 0x00007588ECCE2420
00007588ecdcfb0d  jmp 0x00007588ECDCF1DE
00007588ecdcfb12  call 0x00007588ECCE2420
00007588ecdcfb17  jmp 0x00007588ECDCF1EF
00007588ecdcfb1c  call 0x00007588ECCE2420
00007588ecdcfb21  jmp 0x00007588ECDCF200
00007588ecdcfb26  call 0x00007588ECCE2420
00007588ecdcfb2b  jmp 0x00007588ECDCF211
00007588ecdcfb30  call 0x00007588ECCE2420
00007588ecdcfb35  jmp 0x00007588ECDCF222
00007588ecdcfb3a  call 0x00007588ECCE2420
00007588ecdcfb3f  jmp 0x00007588ECDCF233
00007588ecdcfb44  call 0x00007588ECCE2420
00007588ecdcfb49  jmp 0x00007588ECDCF244
00007588ecdcfb4e  call 0x00007588ECCE2420
00007588ecdcfb53  jmp 0x00007588ECDCF255
00007588ecdcfb58  call 0x00007588ECCE2420
00007588ecdcfb5d  jmp 0x00007588ECDCF266
00007588ecdcfb62  call 0x00007588ECCE2420
00007588ecdcfb67  jmp 0x00007588ECDCF277
00007588ecdcfb6c  call 0x00007588ECCE2420
00007588ecdcfb71  jmp 0x00007588ECDCF288
00007588ecdcfb76  call 0x00007588ECCE2420
00007588ecdcfb7b  jmp 0x00007588ECDCF299
00007588ecdcfb80  call 0x00007588ECCE2420
00007588ecdcfb85  jmp 0x00007588ECDCF2AA
00007588ecdcfb8a  call 0x00007588ECCE2420
00007588ecdcfb8f  jmp 0x00007588ECDCF2BB
00007588ecdcfb94  call 0x00007588ECCE2420
00007588ecdcfb99  jmp 0x00007588ECDCF2CC
00007588ecdcfb9e  call 0x00007588ECCE2420
00007588ecdcfba3  jmp 0x00007588ECDCF2DD
00007588ecdcfba8  call 0x00007588ECCE2420
00007588ecdcfbad  jmp 0x00007588ECDCF2EE
00007588ecdcfbb2  call 0x00007588ECCE2420
00007588ecdcfbb7  jmp 0x00007588ECDCF2FF
00007588ecdcfbbc  call 0x00007588ECCE2420
00007588ecdcfbc1  jmp 0x00007588ECDCF310
00007588ecdcfbc6  call 0x00007588ECCE2420
00007588ecdcfbcb  jmp 0x00007588ECDCF321
00007588ecdcfbd0  call 0x00007588ECCE2420
00007588ecdcfbd5  jmp 0x00007588ECDCF332
00007588ecdcfbda  call 0x00007588ECCE2420
00007588ecdcfbdf  jmp 0x00007588ECDCF343
00007588ecdcfbe4  call 0x00007588ECCE2420
00007588ecdcfbe9  jmp 0x00007588ECDCF354
00007588ecdcfbee  call 0x00007588ECCE2420
00007588ecdcfbf3  jmp 0x00007588ECDCF365
00007588ecdcfbf8  call 0x00007588ECCE2420
00007588ecdcfbfd  jmp 0x00007588ECDCF376
00007588ecdcfc02  call 0x00007588ECCE2420
00007588ecdcfc07  jmp 0x00007588ECDCF387
00007588ecdcfc0c  call 0x00007588ECCE2420
00007588ecdcfc11  jmp 0x00007588ECDCF398
00007588ecdcfc16  call 0x00007588ECCE2420
00007588ecdcfc1b  jmp 0x00007588ECDCF3A9
00007588ecdcfc20  call 0x00007588ECCE2420
00007588ecdcfc25  jmp 0x00007588ECDCF3BA
00007588ecdcfc2a  call 0x00007588ECCE2420
00007588ecdcfc2f  jmp 0x00007588ECDCF3CB
00007588ecdcfc34  call 0x00007588ECCE2420
00007588ecdcfc39  jmp 0x00007588ECDCF3DC
00007588ecdcfc3e  call 0x00007588ECCE2420
00007588ecdcfc43  jmp 0x00007588ECDCF3ED
00007588ecdcfc48  call 0x00007588ECCE2420
00007588ecdcfc4d  jmp 0x00007588ECDCF3FE
00007588ecdcfc52  call 0x00007588ECCE2420
00007588ecdcfc57  jmp 0x00007588ECDCF40F
00007588ecdcfc5c  call 0x00007588ECCE2420
00007588ecdcfc61  jmp 0x00007588ECDCF420
00007588ecdcfc66  call 0x00007588ECCE2420
00007588ecdcfc6b  jmp 0x00007588ECDCF431
00007588ecdcfc70  call 0x00007588ECCE2420
00007588ecdcfc75  jmp 0x00007588ECDCF442
00007588ecdcfc7a  call 0x00007588ECCE2420
00007588ecdcfc7f  jmp 0x00007588ECDCF453
00007588ecdcfc84  call 0x00007588ECCE2420
00007588ecdcfc89  jmp 0x00007588ECDCF464
00007588ecdcfc8e  call 0x00007588ECCE2420
00007588ecdcfc93  jmp 0x00007588ECDCF475
00007588ecdcfc98  call 0x00007588ECCE2420
00007588ecdcfc9d  jmp 0x00007588ECDCF486
00007588ecdcfca2  call 0x00007588ECCE2420
00007588ecdcfca7  jmp 0x00007588ECDCF497
00007588ecdcfcac  call 0x00007588ECCE2420
00007588ecdcfcb1  jmp 0x00007588ECDCF4A8
00007588ecdcfcb6  call 0x00007588ECCE2420
00007588ecdcfcbb  jmp 0x00007588ECDCF4B9
00007588ecdcfcc0  call 0x00007588ECCE2420
00007588ecdcfcc5  jmp 0x00007588ECDCF4CA
00007588ecdcfcca  call 0x00007588ECCE2420
00007588ecdcfccf  jmp 0x00007588ECDCF4DB
00007588ecdcfcd4  call 0x00007588ECCE2420
00007588ecdcfcd9  jmp 0x00007588ECDCF4EC
00007588ecdcfcde  call 0x00007588ECCE2420
00007588ecdcfce3  jmp 0x00007588ECDCF4FD
00007588ecdcfce8  call 0x00007588ECCE2420
00007588ecdcfced  jmp 0x00007588ECDCF50E
00007588ecdcfcf2  call 0x00007588ECCE2420
00007588ecdcfcf7  jmp 0x00007588ECDCF51F
00007588ecdcfcfc  call 0x00007588ECCE2420
00007588ecdcfd01  jmp 0x00007588ECDCF530
00007588ecdcfd06  call 0x00007588ECCE2420
00007588ecdcfd0b  jmp 0x00007588ECDCF541
00007588ecdcfd10  call 0x00007588ECCE2420
00007588ecdcfd15  jmp 0x00007588ECDCF552
00007588ecdcfd1a  call 0x00007588ECCE2420
00007588ecdcfd1f  jmp 0x00007588ECDCF563
00007588ecdcfd24  call 0x00007588ECCE2420
00007588ecdcfd29  jmp 0x00007588ECDCF574
00007588ecdcfd2e  call 0x00007588ECCE2420
00007588ecdcfd33  jmp 0x00007588ECDCF585
00007588ecdcfd38  call 0x00007588ECCE2420
00007588ecdcfd3d  jmp 0x00007588ECDCF596
00007588ecdcfd42  call 0x00007588ECCE2420
00007588ecdcfd47  jmp 0x00007588ECDCF5AF
00007588ecdcfd4c  call 0x00007588ECCE2420
00007588ecdcfd51  jmp 0x00007588ECDCF5C8
00007588ecdcfd56  call 0x00007588ECCD5610
00007588ecdcfd5b  jmp 0x00007588ECDCF5E1
00007588ecdcfd60  call 0x00007588ECCDC580
00007588ecdcfd65  jmp 0x00007588ECDCF94E
00007588ecdcfd6a  call 0x00007588ECCE46C0
00007588ecdcfd6f  jmp 0x00007588ECDCF958
00007588ecdcfd74  call 0x00007588ECC09E90
00007588ecdcfd79  jmp 0x00007588ECDCF95E
00007588ecdcfd7e  call 0x00007588ECCDB310
00007588ecdcfd83  jmp 0x00007588ECDCF968
00007588ecdcfd88  call 0x00007588ECC0DAE0
00007588ecdcfd8d  jmp 0x00007588ECDCF96D
00007588ecdcfd92  call 0x00007588ECCC0230
00007588ecdcfd97  jmp 0x00007588ECDCF986
00007588ecdcfd9c  call 0x00007588ECCC0230
00007588ecdcfda1  jmp 0x00007588ECDCF99B
00007588ecdcfda6  call 0x00007588ECCBEFC0
00007588ecdcfdab  jmp 0x00007588ECDCF9A4
00007588ecdcfdb0  call 0x00007588ECCE2BA0
00007588ecdcfdb5  jmp 0x00007588ECDCFA6B
00007588ecdcfdba  int3
00007588ecdcfdbb  nop [rax+rax*1], eax
00007588ecdcfdc0  mov rax, [r15+0x48]
00007588ecdcfdc4  mov r14, [r15+0x58]
00007588ecdcfdc8  lea r12, [rax+r14*1]
00007588ecdcfdcc  mov [r15+0x68], r12
00007588ecdcfdd0  lea rax, [r14+0x04]
00007588ecdcfdd4  mov [r15+0x58], rax
00007588ecdcfdd8  lea r14, [r12+0x04]
00007588ecdcfddd  mov r11d, [r13+r14*1]
00007588ecdcfde2  mov [rsp+0x10], r11d
00007588ecdcfde7  mov r11d, r11d
00007588ecdcfdea  mov [r15+0x70], r11
00007588ecdcfdee  lea r14, [r12+0x38]
00007588ecdcfdf3  mov r11d, [r13+r14*1]
00007588ecdcfdf8  lea r14, [r12+0x24]
00007588ecdcfdfd  mov r10d, [r13+r14*1]
00007588ecdcfe02  mov [rsp+0x20], r10d
00007588ecdcfe07  mov r10d, r10d
00007588ecdcfe0a  mov [r15+0x90], r10
00007588ecdcfe11  mov [rsp+0x30], rax
00007588ecdcfe16  xor eax, eax
00007588ecdcfe18  mov r14, [rsp+0x30]
00007588ecdcfe1d  mov r10d, 0xC0
00007588ecdcfe23  cmp r14, r10
00007588ecdcfe26  cmc
00007588ecdcfe27  lahf
00007588ecdcfe28  seto al
00007588ecdcfe2b  mov [r15+0x108], eax
00007588ecdcfe32  mov eax, [rsp+0x10]
00007588ecdcfe36  mov r14d, [rsp+0x10]
00007588ecdcfe3b  shrd eax, r14d, 0x07
00007588ecdcfe40  mov [rsp+0x10], r11d
00007588ecdcfe45  mov r10d, [rsp+0x10]
00007588ecdcfe4a  shrd r11d, r10d, 0x11
00007588ecdcfe4f  mov r9d, [r15+0x60]
00007588ecdcfe53  mov r8d, [rsp+0x20]
00007588ecdcfe58  lea ebp, [r8d+r9d*1]
00007588ecdcfe5d  rorx r9d, r14d, 0x12
00007588ecdcfe63  xor eax, r9d
00007588ecdcfe66  rorx r9d, r10d, 0x13
00007588ecdcfe6c  xor r11d, r9d
00007588ecdcfe6f  mov [rsp+0x10], r11d
00007588ecdcfe74  mov r11d, r11d
00007588ecdcfe77  mov [r15+0x88], r11
00007588ecdcfe7e  mov [rsp+0x20], r14d
00007588ecdcfe83  shr r14d, 0x03
00007588ecdcfe87  xor eax, r14d
00007588ecdcfe8a  mov [rsp+0x30], eax
00007588ecdcfe8e  mov eax, eax
00007588ecdcfe90  mov [r15+0x80], rax
00007588ecdcfe97  shr r10d, 0x0A
00007588ecdcfe9b  mov eax, [rsp+0x10]
00007588ecdcfe9f  xor eax, r10d
00007588ecdcfea2  mov [rsp+0x10], eax
00007588ecdcfea6  mov eax, eax
00007588ecdcfea8  mov [r15+0x78], rax
00007588ecdcfeac  mov eax, [rsp+0x30]
00007588ecdcfeb0  lea r14d, [ebp+eax*1]
00007588ecdcfeb6  mov eax, [rsp+0x10]
00007588ecdcfeba  lea r11d, [r14d+eax*1]
00007588ecdcfebf  lea rax, [r12+0x40]
00007588ecdcfec4  mov [r13+rax*1], r11d
00007588ecdcfec9  mov eax, [rsp+0x20]
00007588ecdcfecd  mov eax, eax
00007588ecdcfecf  mov [r15+0x60], rax
00007588ecdcfed3  mov eax, [r15+0x108]
00007588ecdcfeda  sahf
00007588ecdcfedb  jnz 0x00007588ECDCFF0D
00007588ecdcfedd  cmp dword ptr [r15+0x318], 0x00
00007588ecdcfee5  jz 0x00007588ECDCFF70
00007588ecdcfeeb  nop [rax+rax*1], ax
00007588ecdcfef4  nop [rax+rax*1], eax
00007588ecdcfefc  mov eax, 0x410820
00007588ecdcff01  mov [r15+0x100], rax
00007588ecdcff08  jmp 0x00007588ECBFE110
00007588ecdcff0d  cmp dword ptr [r15+0x318], 0x00
00007588ecdcff15  jz 0x00007588ECDCFDC0
00007588ecdcff1b  nop [rax+rax*1], ax
00007588ecdcff24  nop [rax+rax*1], eax
00007588ecdcff2c  mov eax, 0x4107D8
00007588ecdcff31  mov [r15+0x100], rax
00007588ecdcff38  jmp 0x00007588ECBFE110
00007588ecdcff3d  int3
00007588ecdcff3e  call 0x00007588ECCE1430
00007588ecdcff43  jmp 0x00007588ECDCFDE2
00007588ecdcff48  call 0x00007588ECCE1430
00007588ecdcff4d  jmp 0x00007588ECDCFDF8
00007588ecdcff52  call 0x00007588ECCE01C0
00007588ecdcff57  jmp 0x00007588ECDCFE02
00007588ecdcff5c  call 0x00007588ECC0A860
00007588ecdcff61  jmp 0x00007588ECDCFEC9
00007588ecdcff66  int3
00007588ecdcff67  nop [rax+rax*1], ax
00007588ecdcff70  mov rax, [r15]
00007588ecdcff73  mov r14d, [r13+rax*1]
00007588ecdcff78  lea r12, [rax+0x04]
00007588ecdcff7c  mov r11d, [r13+r12*1]
00007588ecdcff81  mov [rsp+0x10], r14d
00007588ecdcff86  mov r14d, r14d
00007588ecdcff89  mov [r15+0x78], r14
00007588ecdcff8d  mov [rsp+0x20], r11d
00007588ecdcff92  mov r11d, r11d
00007588ecdcff95  mov [r15+0x80], r11
00007588ecdcff9c  lea r14, [rax+0x08]
00007588ecdcffa0  mov r12d, [r13+r14*1]
00007588ecdcffa5  lea r14, [rax+0x0C]
00007588ecdcffa9  mov r11d, [r13+r14*1]
00007588ecdcffae  mov [rsp+0x30], r12d
00007588ecdcffb3  mov r12d, r12d
00007588ecdcffb6  mov [r15+0x70], r12
00007588ecdcffba  mov [rsp+0x40], r11d
00007588ecdcffbf  mov r11d, r11d
00007588ecdcffc2  mov [r15+0x68], r11
00007588ecdcffc6  lea r14, [rax+0x18]
00007588ecdcffca  mov r12d, [r13+r14*1]
00007588ecdcffcf  lea r14, [rax+0x1C]
00007588ecdcffd3  mov r11d, [r13+r14*1]
00007588ecdcffd8  mov [rsp+0x50], r12d
00007588ecdcffdd  mov r12d, r12d
00007588ecdcffe0  mov [r15+0x58], r12
00007588ecdcffe4  mov [rsp+0x60], r11d
00007588ecdcffe9  mov r11d, r11d
00007588ecdcffec  mov [r15+0x60], r11
00007588ecdcfff0  lea r14, [rax+0x10]
00007588ecdcfff4  mov r12d, [r13+r14*1]
00007588ecdcfff9  lea r14, [rax+0x14]
00007588ecdcfffd  mov eax, [r13+r14*1]
00007588ecdd0002  mov [rsp+0x70], r12d
00007588ecdd0007  mov r12d, r12d
00007588ecdd000a  mov [r15+0x18], r12
00007588ecdd000e  mov [rsp+0x80], eax
00007588ecdd0015  mov eax, eax
00007588ecdd0017  mov [r15+0x90], rax
00007588ecdd001e  mov eax, [rsp+0x70]
00007588ecdd0022  mov eax, eax
00007588ecdd0024  mov [r15+0x30], rax
00007588ecdd0028  mov eax, [rsp+0x50]
00007588ecdd002c  mov eax, eax
00007588ecdd002e  mov [r15+0xA0], rax
00007588ecdd0035  mov eax, [rsp+0x30]
00007588ecdd0039  mov eax, eax
00007588ecdd003b  mov [r15+0x28], rax
00007588ecdd003f  mov eax, [rsp+0x20]
00007588ecdd0043  mov eax, eax
00007588ecdd0045  mov [r15+0x98], rax
00007588ecdd004c  mov eax, [rsp+0x10]
00007588ecdd0050  mov eax, eax
00007588ecdd0052  mov [r15+0x38], rax
00007588ecdd0056  mov eax, [rsp+0x70]
00007588ecdd005a  mov r14d, [rsp+0x70]
00007588ecdd005f  shrd eax, r14d, 0x06
00007588ecdd0064  mov [rsp+0x70], r14d
00007588ecdd0069  mov r12d, [rsp+0x80]
00007588ecdd0071  and r14d, r12d
00007588ecdd0074  mov r11d, [rsp+0x10]
00007588ecdd0079  mov r10d, [rsp+0x10]
00007588ecdd007e  shrd r11d, r10d, 0x02
00007588ecdd0083  mov [rsp+0x10], r12d
00007588ecdd0088  mov r12d, r12d
00007588ecdd008b  mov [r15+0x20], r12
00007588ecdd008f  mov r12, [r15+0x50]
00007588ecdd0093  mov r9d, [r13+r12*1]
00007588ecdd0098  mov r12d, [rsp+0x50]
00007588ecdd009d  mov r8d, [rsp+0x70]
00007588ecdd00a2  andn ebp, r8d, r12d
00007588ecdd00a7  mov edi, [rsp+0x60]
00007588ecdd00ab  lea esi, [r14d+edi*1]
00007588ecdd00b0  rorx r14d, r8d, 0x0B
00007588ecdd00b6  xor eax, r14d
00007588ecdd00b9  rorx r14d, r10d, 0x0D
00007588ecdd00bf  xor r11d, r14d
00007588ecdd00c2  lea edi, [esi+ebp*1]
00007588ecdd00c6  mov r14, [r15+0x48]
00007588ecdd00ca  mov ebp, [r13+r14*1]
00007588ecdd00cf  mov r14d, [rsp+0x30]
00007588ecdd00d4  mov esi, [rsp+0x20]
00007588ecdd00d8  and r14d, esi
00007588ecdd00db  mov [rsp+0x20], r14d
00007588ecdd00e0  mov r14d, r14d
00007588ecdd00e3  mov [r15+0xD8], r14
00007588ecdd00ea  lea r14d, [edi+r9d*1]
00007588ecdd00ef  mov r9d, [rsp+0x30]
00007588ecdd00f4  xor r9d, esi
00007588ecdd00f7  rorx edi, r8d, 0x19
00007588ecdd00fd  xor eax, edi
00007588ecdd00ff  and r9d, r10d
00007588ecdd0102  rorx edi, r10d, 0x16
00007588ecdd0108  xor r11d, edi
00007588ecdd010b  mov [rsp+0x30], r11d
00007588ecdd0110  mov r11d, r11d
00007588ecdd0113  mov [r15+0xD0], r11
00007588ecdd011a  lea r11d, [r14d+ebp*1]
00007588ecdd011f  mov r10d, [rsp+0x20]
00007588ecdd0124  xor r9d, r10d
00007588ecdd0127  lea r14d, [r11d+eax*1]
00007588ecdd012c  mov qword ptr [r15+0x88], 0x04
00007588ecdd0137  mov eax, [rsp+0x30]
00007588ecdd013b  lea r11d, [r9d+eax*1]
00007588ecdd0140  mov eax, [rsp+0x40]
00007588ecdd0144  lea r10d, [r14d+eax*1]
00007588ecdd0149  mov r10d, r10d
00007588ecdd014c  mov [r15+0xB8], r10
00007588ecdd0153  xor eax, eax
00007588ecdd0155  mov r10d, 0x04
00007588ecdd015b  mov r9d, 0x100
00007588ecdd0161  cmp r10, r9
00007588ecdd0164  cmc
00007588ecdd0165  lahf
00007588ecdd0166  seto al
00007588ecdd0169  mov [r15+0x108], eax
00007588ecdd0170  lea eax, [r11d+r14d*1]
00007588ecdd0175  mov eax, eax
00007588ecdd0177  mov [r15+0xA8], rax
00007588ecdd017e  mov r12d, r12d
00007588ecdd0181  mov [r15+0xB0], r12
00007588ecdd0188  mov eax, [rsp+0x10]
00007588ecdd018c  mov eax, eax
00007588ecdd018e  mov [r15+0xC0], rax
00007588ecdd0195  mov r8d, r8d
00007588ecdd0198  mov [r15+0xC8], r8
00007588ecdd019f  mov eax, [r15+0x108]
00007588ecdd01a6  sahf
00007588ecdd01a7  jnz 0x00007588ECDD01D9
00007588ecdd01a9  cmp dword ptr [r15+0x318], 0x00
00007588ecdd01b1  jz 0x00007588ECDD04A0
00007588ecdd01b7  nop [rax+rax*1], ax
00007588ecdd01c0  nop [rax+rax*1], eax
00007588ecdd01c8  mov eax, 0x4108E0
00007588ecdd01cd  mov [r15+0x100], rax
00007588ecdd01d4  jmp 0x00007588ECBFE110
00007588ecdd01d9  cmp dword ptr [r15+0x318], 0x00
00007588ecdd01e1  jz 0x00007588ECDD0270
00007588ecdd01e7  nop [rax+rax*1], ax
00007588ecdd01f0  nop [rax+rax*1], eax
00007588ecdd01f8  mov eax, 0x410854
00007588ecdd01fd  mov [r15+0x100], rax
00007588ecdd0204  jmp 0x00007588ECBFE110
00007588ecdd0209  int3
00007588ecdd020a  call 0x00007588ECC0DAE0
00007588ecdd020f  jmp 0x00007588ECDCFF78
00007588ecdd0214  call 0x00007588ECCC0230
00007588ecdd0219  jmp 0x00007588ECDCFF81
00007588ecdd021e  call 0x00007588ECCE26A0
00007588ecdd0223  jmp 0x00007588ECDCFFA5
00007588ecdd0228  call 0x00007588ECCE1430
00007588ecdd022d  jmp 0x00007588ECDCFFAE
00007588ecdd0232  call 0x00007588ECCE26A0
00007588ecdd0237  jmp 0x00007588ECDCFFCF
00007588ecdd023c  call 0x00007588ECCE1430
00007588ecdd0241  jmp 0x00007588ECDCFFD8
00007588ecdd0246  call 0x00007588ECCE26A0
00007588ecdd024b  jmp 0x00007588ECDCFFF9
00007588ecdd0250  call 0x00007588ECCD5890
00007588ecdd0255  jmp 0x00007588ECDD0002
00007588ecdd025a  call 0x00007588ECCBDD50
00007588ecdd025f  jmp 0x00007588ECDD0098
00007588ecdd0264  call 0x00007588ECCDA580
00007588ecdd0269  jmp 0x00007588ECDD00CF
00007588ecdd026e  int3
00007588ecdd026f  nop
00007588ecdd0270  mov eax, [r15+0xB8]
00007588ecdd0277  mov [rsp+0x10], eax
00007588ecdd027b  mov eax, eax
00007588ecdd027d  mov [r15+0x30], rax
00007588ecdd0281  mov eax, [r15+0xC0]
00007588ecdd0288  mov [rsp+0x20], eax
00007588ecdd028c  mov eax, eax
00007588ecdd028e  mov [r15+0xA0], rax
00007588ecdd0295  mov eax, [r15+0x28]
00007588ecdd0299  mov r14d, [r15+0x98]
00007588ecdd02a0  mov [rsp+0x30], r14d
00007588ecdd02a5  mov r14d, r14d
00007588ecdd02a8  mov [r15+0x28], r14
00007588ecdd02ac  mov r14d, [r15+0x38]
00007588ecdd02b0  mov [rsp+0x40], r14d
00007588ecdd02b5  mov r14d, r14d
00007588ecdd02b8  mov [r15+0x98], r14
00007588ecdd02bf  mov r14d, [r15+0xA8]
00007588ecdd02c6  mov [rsp+0x50], r14d
00007588ecdd02cb  mov r14d, r14d
00007588ecdd02ce  mov [r15+0x38], r14
00007588ecdd02d2  mov r14d, [rsp+0x10]
00007588ecdd02d7  mov r12d, [rsp+0x10]
00007588ecdd02dc  shrd r14d, r12d, 0x06
00007588ecdd02e1  mov r11d, [r15+0xC8]
00007588ecdd02e8  mov [rsp+0x10], r12d
00007588ecdd02ed  and r12d, r11d
00007588ecdd02f0  mov r10d, [rsp+0x50]
00007588ecdd02f5  mov r9d, [rsp+0x50]
00007588ecdd02fa  shrd r10d, r9d, 0x02
00007588ecdd02ff  mov [rsp+0x50], r11d
00007588ecdd0304  mov r11d, r11d
00007588ecdd0307  mov [r15+0x20], r11
00007588ecdd030b  mov r11, [r15+0x88]
00007588ecdd0312  mov r8, [r15+0x50]
00007588ecdd0316  lea rbp, [r8+r11*1]
00007588ecdd031a  mov r8d, [r13+rbp*1]
00007588ecdd031f  mov ebp, [rsp+0x20]
00007588ecdd0323  mov edi, [rsp+0x10]
00007588ecdd0327  andn esi, edi, ebp
00007588ecdd032c  mov edx, [r15+0xB0]
00007588ecdd0333  lea ecx, [r12d+edx*1]
00007588ecdd0338  rorx r12d, edi, 0x0B
00007588ecdd033e  xor r14d, r12d
00007588ecdd0341  rorx r12d, r9d, 0x0D
00007588ecdd0347  xor r10d, r12d
00007588ecdd034a  lea r12d, [ecx+esi*1]
00007588ecdd034f  mov rsi, [r15+0x48]
00007588ecdd0353  lea rdx, [rsi+r11*1]
00007588ecdd0357  mov esi, [r13+rdx*1]
00007588ecdd035c  mov edx, [rsp+0x30]
00007588ecdd0360  mov ecx, [rsp+0x40]
00007588ecdd0364  and edx, ecx
00007588ecdd0366  mov [rsp+0x10], edx
00007588ecdd036a  mov edx, edx
00007588ecdd036c  mov [r15+0xD8], rdx
00007588ecdd0373  lea edx, [r12d+r8d*1]
00007588ecdd0378  mov r12d, [rsp+0x30]
00007588ecdd037d  xor r12d, ecx
00007588ecdd0380  rorx r8d, edi, 0x19
00007588ecdd0386  xor r14d, r8d
00007588ecdd0389  and r12d, r9d
00007588ecdd038c  rorx r8d, r9d, 0x16
00007588ecdd0392  xor r10d, r8d
00007588ecdd0395  mov [rsp+0x20], r10d
00007588ecdd039a  mov r10d, r10d
00007588ecdd039d  mov [r15+0xD0], r10
00007588ecdd03a4  lea r10d, [edx+esi*1]
00007588ecdd03a9  mov r9d, [rsp+0x10]
00007588ecdd03ae  xor r12d, r9d
00007588ecdd03b1  lea r9d, [r10d+r14d*1]
00007588ecdd03b6  lea r14, [r11+0x04]
00007588ecdd03ba  mov [r15+0x88], r14
00007588ecdd03c1  mov r11d, [rsp+0x20]
00007588ecdd03c6  lea r10d, [r12d+r11d*1]
00007588ecdd03cb  lea r11d, [r9d+eax*1]
00007588ecdd03d0  mov r11d, r11d
00007588ecdd03d3  mov [r15+0xB8], r11
00007588ecdd03da  xor eax, eax
00007588ecdd03dc  mov r12d, 0x100
00007588ecdd03e2  cmp r14, r12
00007588ecdd03e5  cmc
00007588ecdd03e6  lahf
00007588ecdd03e7  seto al
00007588ecdd03ea  mov [r15+0x108], eax
00007588ecdd03f1  lea eax, [r10d+r9d*1]
00007588ecdd03f6  mov eax, eax
00007588ecdd03f8  mov [r15+0xA8], rax
00007588ecdd03ff  mov ebp, ebp
00007588ecdd0401  mov [r15+0xB0], rbp
00007588ecdd0408  mov eax, [rsp+0x50]
00007588ecdd040c  mov eax, eax
00007588ecdd040e  mov [r15+0xC0], rax
00007588ecdd0415  mov edi, edi
00007588ecdd0417  mov [r15+0xC8], rdi
00007588ecdd041e  mov eax, [r15+0x108]
00007588ecdd0425  sahf
00007588ecdd0426  jnz 0x00007588ECDD0458
00007588ecdd0428  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0430  jz 0x00007588ECDD04A0
00007588ecdd0436  nop [rax+rax*1], ax
00007588ecdd043f  nop [rax+rax*1], eax
00007588ecdd0447  mov eax, 0x4108E0
00007588ecdd044c  mov [r15+0x100], rax
00007588ecdd0453  jmp 0x00007588ECBFE110
00007588ecdd0458  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0460  jz 0x00007588ECDD0270
00007588ecdd0466  nop [rax+rax*1], ax
00007588ecdd046f  nop [rax+rax*1], eax
00007588ecdd0477  mov eax, 0x410854
00007588ecdd047c  mov [r15+0x100], rax
00007588ecdd0483  jmp 0x00007588ECBFE110
00007588ecdd0488  int3
00007588ecdd0489  call 0x00007588ECC49010
00007588ecdd048e  jmp 0x00007588ECDD031F
00007588ecdd0493  call 0x00007588ECC25930
00007588ecdd0498  jmp 0x00007588ECDD035C
00007588ecdd049d  int3
00007588ecdd049e  nop
00007588ecdd04a0  mov eax, [r15+0x98]
00007588ecdd04a7  mov r14d, [r15+0x70]
00007588ecdd04ab  lea r12d, [eax+r14d*1]
00007588ecdd04b0  mov eax, [r15+0x28]
00007588ecdd04b4  mov r14d, [r15+0x68]
00007588ecdd04b8  lea r11d, [eax+r14d*1]
00007588ecdd04bd  mov qword ptr [r15+0x88], 0x00
00007588ecdd04c8  mov eax, [r15+0xA8]
00007588ecdd04cf  mov r14d, [r15+0x78]
00007588ecdd04d3  lea r10d, [eax+r14d*1]
00007588ecdd04d8  mov [rsp+0x10], r10d
00007588ecdd04dd  mov r10d, r10d
00007588ecdd04e0  mov [r15+0x78], r10
00007588ecdd04e4  mov eax, [r15+0x38]
00007588ecdd04e8  mov r14d, [r15+0x80]
00007588ecdd04ef  lea r10d, [eax+r14d*1]
00007588ecdd04f4  mov [rsp+0x20], r10d
00007588ecdd04f9  mov r10d, r10d
00007588ecdd04fc  mov [r15+0x80], r10
00007588ecdd0503  mov rax, [r15]
00007588ecdd0506  lea r14, [rax+0x08]
00007588ecdd050a  mov [r13+r14*1], r12d
00007588ecdd050f  lea r14, [rax+0x0C]
00007588ecdd0513  mov [r13+r14*1], r11d
00007588ecdd0518  mov r14d, [r15+0xB8]
00007588ecdd051f  mov r12d, [r15+0x18]
00007588ecdd0523  lea r11d, [r14d+r12d*1]
00007588ecdd0528  mov [rsp+0x30], r11d
00007588ecdd052d  mov r11d, r11d
00007588ecdd0530  mov [r15+0x68], r11
00007588ecdd0534  mov r14d, [r15+0x30]
00007588ecdd0538  mov r12d, [r15+0x90]
00007588ecdd053f  lea r11d, [r14d+r12d*1]
00007588ecdd0544  mov [rsp+0x40], r11d
00007588ecdd0549  mov r11d, r11d
00007588ecdd054c  mov [r15+0x70], r11
00007588ecdd0550  mov r14d, [r15+0x20]
00007588ecdd0554  mov r12d, [r15+0x58]
00007588ecdd0558  lea r11d, [r14d+r12d*1]
00007588ecdd055d  mov [rsp+0x50], r11d
00007588ecdd0562  mov r11d, r11d
00007588ecdd0565  mov [r15+0x58], r11
00007588ecdd0569  mov r14d, [r15+0xA0]
00007588ecdd0570  mov r12d, [r15+0x60]
00007588ecdd0574  lea r11d, [r14d+r12d*1]
00007588ecdd0579  mov [rsp+0x60], r11d
00007588ecdd057e  mov r11d, r11d
00007588ecdd0581  mov [r15+0x60], r11
00007588ecdd0585  mov r14d, [rsp+0x10]
00007588ecdd058a  mov [r13+rax*1], r14d
00007588ecdd058f  lea r14, [rax+0x04]
00007588ecdd0593  mov r12d, [rsp+0x20]
00007588ecdd0598  mov [r13+r14*1], r12d
00007588ecdd059d  lea r14, [rax+0x10]
00007588ecdd05a1  mov r12d, [rsp+0x30]
00007588ecdd05a6  mov [r13+r14*1], r12d
00007588ecdd05ab  lea r14, [rax+0x14]
00007588ecdd05af  mov r12d, [rsp+0x40]
00007588ecdd05b4  mov [r13+r14*1], r12d
00007588ecdd05b9  lea r14, [rax+0x18]
00007588ecdd05bd  mov r12d, [rsp+0x50]
00007588ecdd05c2  mov [r13+r14*1], r12d
00007588ecdd05c7  lea r14, [rax+0x1C]
00007588ecdd05cb  mov r12d, [rsp+0x60]
00007588ecdd05d0  mov [r13+r14*1], r12d
00007588ecdd05d5  lea r14, [rax+0x68]
00007588ecdd05d9  xor eax, eax
00007588ecdd05db  mov [r13+r14*1], rax
00007588ecdd05e0  cmp dword ptr [r15+0x318], 0x00
00007588ecdd05e8  jz 0x00007588ECDCF0E0
00007588ecdd05ee  nop [rax+rax*1], ax
00007588ecdd05f7  nop [rax+rax*1], eax
00007588ecdd05ff  mov eax, 0x4106FC
00007588ecdd0604  mov [r15+0x100], rax
00007588ecdd060b  jmp 0x00007588ECBFE110
00007588ecdd0610  int3
00007588ecdd0611  call 0x00007588ECCE2BA0
00007588ecdd0616  jmp 0x00007588ECDD050F
00007588ecdd061b  call 0x00007588ECCE1920
00007588ecdd0620  jmp 0x00007588ECDD0518
00007588ecdd0625  call 0x00007588ECC0DFE0
00007588ecdd062a  jmp 0x00007588ECDD058F
00007588ecdd062f  call 0x00007588ECCE2BA0
00007588ecdd0634  jmp 0x00007588ECDD059D
00007588ecdd0639  call 0x00007588ECCE2BA0
00007588ecdd063e  jmp 0x00007588ECDD05AB
00007588ecdd0643  call 0x00007588ECCE2BA0
00007588ecdd0648  jmp 0x00007588ECDD05B9
00007588ecdd064d  call 0x00007588ECCE2BA0
00007588ecdd0652  jmp 0x00007588ECDD05C7
00007588ecdd0657  call 0x00007588ECCE2BA0
00007588ecdd065c  jmp 0x00007588ECDD05D5
00007588ecdd0661  call 0x00007588ECCD5EB0
00007588ecdd0666  jmp 0x00007588ECDD05E0
00007588ecdd066b  int3
00007588ecdd066c  nop [rax], eax
00007588ecdd0670  mov rax, [r15+0xF8]
00007588ecdd0677  lea r14, [rax+0x140]
00007588ecdd067e  mov r12, [r13+r14*1]
00007588ecdd0683  lea r14, [rax+0x148]
00007588ecdd068a  mov r11, [r13+r14*1]
00007588ecdd068f  mov [r15+0xA0], r12
00007588ecdd0696  mov [r15+0x98], r11
00007588ecdd069d  lea r14, [rax+0x130]
00007588ecdd06a4  mov r12, [r13+r14*1]
00007588ecdd06a9  lea r14, [rax+0x138]
00007588ecdd06b0  mov r11, [r13+r14*1]
00007588ecdd06b5  mov [r15+0xB0], r12
00007588ecdd06bc  mov [r15+0xA8], r11
00007588ecdd06c3  lea r14, [rax+0x120]
00007588ecdd06ca  mov r12, [r13+r14*1]
00007588ecdd06cf  lea r14, [rax+0x128]
00007588ecdd06d6  mov r11, [r13+r14*1]
00007588ecdd06db  mov [r15+0xC0], r12
00007588ecdd06e2  mov [r15+0xB8], r11
00007588ecdd06e9  lea r14, [rax+0x110]
00007588ecdd06f0  mov r12, [r13+r14*1]
00007588ecdd06f5  lea r14, [rax+0x118]
00007588ecdd06fc  mov r11, [r13+r14*1]
00007588ecdd0701  mov [r15+0xD0], r12
00007588ecdd0708  mov [r15+0xC8], r11
00007588ecdd070f  lea r14, [rax+0x100]
00007588ecdd0716  mov r12, [r13+r14*1]
00007588ecdd071b  lea r14, [rax+0x108]
00007588ecdd0722  mov r11, [r13+r14*1]
00007588ecdd0727  mov [r15+0xE8], r12
00007588ecdd072e  mov [r15+0xD8], r11
00007588ecdd0735  lea r14, [rax+0x150]
00007588ecdd073c  mov [r15+0xF8], r14
00007588ecdd0743  mov rax, [r15+0xF0]
00007588ecdd074a  mov [r15+0x100], rax
00007588ecdd0751  jmp 0x00007588ECDCE5C0
00007588ecdd0756  int3
00007588ecdd0757  call 0x00007588ECCE27E0
00007588ecdd075c  jmp 0x00007588ECDD0683
00007588ecdd0761  call 0x00007588ECCE1570
00007588ecdd0766  jmp 0x00007588ECDD068F
00007588ecdd076b  call 0x00007588ECCE27E0
00007588ecdd0770  jmp 0x00007588ECDD06A9
00007588ecdd0775  call 0x00007588ECCE1570
00007588ecdd077a  jmp 0x00007588ECDD06B5
00007588ecdd077f  call 0x00007588ECCE27E0
00007588ecdd0784  jmp 0x00007588ECDD06CF
00007588ecdd0789  call 0x00007588ECCE1570
00007588ecdd078e  jmp 0x00007588ECDD06DB
00007588ecdd0793  call 0x00007588ECCE27E0
00007588ecdd0798  jmp 0x00007588ECDD06F5
00007588ecdd079d  call 0x00007588ECCE1570
00007588ecdd07a2  jmp 0x00007588ECDD0701
00007588ecdd07a7  call 0x00007588ECCE27E0
00007588ecdd07ac  jmp 0x00007588ECDD071B
00007588ecdd07b1  call 0x00007588ECCE1570
00007588ecdd07b6  jmp 0x00007588ECDD0727
00007588ecdd07bb  int3
00007588ecdd07bc  nop [rax], eax
00007588ecdd07c0  mov eax, [r15+0xA0]
00007588ecdd07c7  mov [rsp+0x10], eax
00007588ecdd07cb  xor eax, eax
00007588ecdd07cd  mov r14d, [rsp+0x10]
00007588ecdd07d2  sub r14d, 0x01
00007588ecdd07d6  cmc
00007588ecdd07d7  lahf
00007588ecdd07d8  seto al
00007588ecdd07db  mov [r15+0x108], eax
00007588ecdd07e2  mov r14d, r14d
00007588ecdd07e5  mov [r15+0xA0], r14
00007588ecdd07ec  mov eax, [r15+0x108]
00007588ecdd07f3  sahf
00007588ecdd07f4  jnz 0x00007588ECDD0826
00007588ecdd07f6  cmp dword ptr [r15+0x318], 0x00
00007588ecdd07fe  jz 0x00007588ECDD0900
00007588ecdd0804  nop [rax+rax*1], ax
00007588ecdd080d  nop [rax+rax*1], eax
00007588ecdd0815  mov eax, 0x41028C
00007588ecdd081a  mov [r15+0x100], rax
00007588ecdd0821  jmp 0x00007588ECBFE110
00007588ecdd0826  cmp dword ptr [r15+0x318], 0x00
00007588ecdd082e  jz 0x00007588ECDD0860
00007588ecdd0834  nop [rax+rax*1], ax
00007588ecdd083d  nop [rax+rax*1], eax
00007588ecdd0845  mov eax, 0x410274
00007588ecdd084a  mov [r15+0x100], rax
00007588ecdd0851  jmp 0x00007588ECBFE110
00007588ecdd0856  int3
00007588ecdd0857  int3
00007588ecdd0858  nop [rax+rax*1], eax
00007588ecdd0860  mov rax, [r15+0xF8]
00007588ecdd0867  lea r14, [rax+0xD0]
00007588ecdd086e  mov [r15], r14
00007588ecdd0871  mov rax, [r15+0x98]
00007588ecdd0878  mov [r15+0x08], rax
00007588ecdd087c  mov qword ptr [r15+0x10], 0x12C
00007588ecdd0884  mov qword ptr [r15+0xF0], 0x410284
00007588ecdd088f  mov r14d, [r15+0x320]
00007588ecdd0896  mov eax, 0x410284
00007588ecdd089b  mov rcx, 0x7588ECDD07C0
00007588ecdd08a5  mov [r15+r14*8+0x328], rax
00007588ecdd08ad  mov [r15+r14*8+0x368], rcx
00007588ecdd08b5  add r14d, 0x01
00007588ecdd08b9  and r14d, 0x07
00007588ecdd08bd  mov [r15+0x320], r14d
00007588ecdd08c4  cmp dword ptr [r15+0x318], 0x00
00007588ecdd08cc  jz 0x00007588ECDCED70
00007588ecdd08d2  nop [rax+rax*1], ax
00007588ecdd08db  nop [rax+rax*1], eax
00007588ecdd08e3  mov eax, 0x4106BC
00007588ecdd08e8  mov [r15+0x100], rax
00007588ecdd08ef  jmp 0x00007588ECBFE110
00007588ecdd08f4  int3
00007588ecdd08f5  int3
00007588ecdd08f6  nop [rax+rax*1], ax
00007588ecdd08ff  nop
00007588ecdd0900  mov rax, [r15+0xF8]
00007588ecdd0907  lea r14, [rax+0xF0]
00007588ecdd090e  mov r12, [r13+r14*1]
00007588ecdd0913  mov [r15+0x98], r12
00007588ecdd091a  mov qword ptr [r15+0x40], 0x80
00007588ecdd0922  lea r14, [rax+0xD0]
00007588ecdd0929  mov [r15], r14
00007588ecdd092c  lea r14, [rax+0x14C]
00007588ecdd0933  mov [r15+0x08], r14
00007588ecdd0937  mov qword ptr [r15+0x10], 0x01
00007588ecdd093f  lea r14, [rax+0x14C]
00007588ecdd0946  mov eax, 0x80
00007588ecdd094b  mov [r13+r14*1], al
00007588ecdd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007588ecdd095b  mov r14d, [r15+0x320]
00007588ecdd0962  mov eax, 0x4102A8
00007588ecdd0967  mov rcx, 0x7588ECDD09E0
00007588ecdd0971  mov [r15+r14*8+0x328], rax
00007588ecdd0979  mov [r15+r14*8+0x368], rcx
00007588ecdd0981  add r14d, 0x01
00007588ecdd0985  and r14d, 0x07
00007588ecdd0989  mov [r15+0x320], r14d
00007588ecdd0990  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0998  jz 0x00007588ECDCED70
00007588ecdd099e  nop [rax+rax*1], ax
00007588ecdd09a7  nop [rax+rax*1], eax
00007588ecdd09af  mov eax, 0x4106BC
00007588ecdd09b4  mov [r15+0x100], rax
00007588ecdd09bb  jmp 0x00007588ECBFE110
00007588ecdd09c0  int3
00007588ecdd09c1  call 0x00007588ECCE27E0
00007588ecdd09c6  jmp 0x00007588ECDD0913
00007588ecdd09cb  call 0x00007588ECCD5AF0
00007588ecdd09d0  jmp 0x00007588ECDD0950
00007588ecdd09d5  int3
00007588ecdd09d6  nop [rax+rax*1], ax
00007588ecdd09df  nop
00007588ecdd09e0  mov rax, [r15+0xF8]
00007588ecdd09e7  lea r14, [rax+0x138]
00007588ecdd09ee  mov r12, [r13+r14*1]
00007588ecdd09f3  mov [r15+0x40], r12
00007588ecdd09f7  lea r14, [rax+0x148]
00007588ecdd09fe  xor eax, eax
00007588ecdd0a00  mov [r13+r14*1], al
00007588ecdd0a05  xor eax, eax
00007588ecdd0a07  mov r14d, 0x38
00007588ecdd0a0d  cmp r12, r14
00007588ecdd0a10  cmc
00007588ecdd0a11  lahf
00007588ecdd0a12  seto al
00007588ecdd0a15  mov [r15+0x108], eax
00007588ecdd0a1c  mov eax, [r15+0x108]
00007588ecdd0a23  sahf
00007588ecdd0a24  jz 0x00007588ECDD0A56
00007588ecdd0a26  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0a2e  jz 0x00007588ECDD0AA0
00007588ecdd0a34  nop [rax+rax*1], ax
00007588ecdd0a3d  nop [rax+rax*1], eax
00007588ecdd0a45  mov eax, 0x4102B8
00007588ecdd0a4a  mov [r15+0x100], rax
00007588ecdd0a51  jmp 0x00007588ECBFE110
00007588ecdd0a56  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0a5e  jz 0x00007588ECDD0BF0
00007588ecdd0a64  nop [rax+rax*1], ax
00007588ecdd0a6d  nop [rax+rax*1], eax
00007588ecdd0a75  mov eax, 0x4102D4
00007588ecdd0a7a  mov [r15+0x100], rax
00007588ecdd0a81  jmp 0x00007588ECBFE110
00007588ecdd0a86  int3
00007588ecdd0a87  call 0x00007588ECCE27E0
00007588ecdd0a8c  jmp 0x00007588ECDD09F3
00007588ecdd0a91  call 0x00007588ECCD5AF0
00007588ecdd0a96  jmp 0x00007588ECDD0A05
00007588ecdd0a9b  int3
00007588ecdd0a9c  nop [rax], eax
00007588ecdd0aa0  mov rax, [r15+0xF8]
00007588ecdd0aa7  lea r14, [rax+0xD0]
00007588ecdd0aae  mov [r15], r14
00007588ecdd0ab1  lea r14, [rax+0x148]
00007588ecdd0ab8  mov [r15+0x08], r14
00007588ecdd0abc  mov qword ptr [r15+0x10], 0x01
00007588ecdd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007588ecdd0acf  mov r14d, [r15+0x320]
00007588ecdd0ad6  mov eax, 0x4102C8
00007588ecdd0adb  mov rcx, 0x7588ECDD0B40
00007588ecdd0ae5  mov [r15+r14*8+0x328], rax
00007588ecdd0aed  mov [r15+r14*8+0x368], rcx
00007588ecdd0af5  add r14d, 0x01
00007588ecdd0af9  and r14d, 0x07
00007588ecdd0afd  mov [r15+0x320], r14d
00007588ecdd0b04  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0b0c  jz 0x00007588ECDCED70
00007588ecdd0b12  nop [rax+rax*1], ax
00007588ecdd0b1b  nop [rax+rax*1], eax
00007588ecdd0b23  mov eax, 0x4106BC
00007588ecdd0b28  mov [r15+0x100], rax
00007588ecdd0b2f  jmp 0x00007588ECBFE110
00007588ecdd0b34  int3
00007588ecdd0b35  int3
00007588ecdd0b36  nop [rax+rax*1], ax
00007588ecdd0b3f  nop
00007588ecdd0b40  mov rax, [r15+0xF8]
00007588ecdd0b47  lea r14, [rax+0x138]
00007588ecdd0b4e  mov rax, [r13+r14*1]
00007588ecdd0b53  mov [r15+0x40], rax
00007588ecdd0b57  mov [rsp+0x10], rax
00007588ecdd0b5c  xor eax, eax
00007588ecdd0b5e  mov r14, [rsp+0x10]
00007588ecdd0b63  mov r12d, 0x38
00007588ecdd0b69  cmp r14, r12
00007588ecdd0b6c  cmc
00007588ecdd0b6d  lahf
00007588ecdd0b6e  seto al
00007588ecdd0b71  mov [r15+0x108], eax
00007588ecdd0b78  mov eax, [r15+0x108]
00007588ecdd0b7f  sahf
00007588ecdd0b80  jnz 0x00007588ECDD0BB2
00007588ecdd0b82  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0b8a  jz 0x00007588ECDD0BF0
00007588ecdd0b90  nop [rax+rax*1], ax
00007588ecdd0b99  nop [rax+rax*1], eax
00007588ecdd0ba1  mov eax, 0x4102D4
00007588ecdd0ba6  mov [r15+0x100], rax
00007588ecdd0bad  jmp 0x00007588ECBFE110
00007588ecdd0bb2  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0bba  jz 0x00007588ECDD0AA0
00007588ecdd0bc0  nop [rax+rax*1], ax
00007588ecdd0bc9  nop [rax+rax*1], eax
00007588ecdd0bd1  mov eax, 0x4102B8
00007588ecdd0bd6  mov [r15+0x100], rax
00007588ecdd0bdd  jmp 0x00007588ECBFE110
00007588ecdd0be2  int3
00007588ecdd0be3  call 0x00007588ECCD59C0
00007588ecdd0be8  jmp 0x00007588ECDD0B53
00007588ecdd0bed  int3
00007588ecdd0bee  nop
00007588ecdd0bf0  mov rax, [r15+0x98]
00007588ecdd0bf7  rorx r14, rax, 0x3D
00007588ecdd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007588ecdd0c01  mov rax, [r15+0xF8]
00007588ecdd0c08  lea r12, [rax+0xD0]
00007588ecdd0c0f  mov [r15], r12
00007588ecdd0c12  lea r12, [rax+0x140]
00007588ecdd0c19  mov [r15+0x08], r12
00007588ecdd0c1d  mov qword ptr [r15+0x10], 0x08
00007588ecdd0c25  bswap r14
00007588ecdd0c28  mov [r15+0x40], r14
00007588ecdd0c2c  lea r12, [rax+0x140]
00007588ecdd0c33  mov [r13+r12*1], r14
00007588ecdd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007588ecdd0c43  mov r14d, [r15+0x320]
00007588ecdd0c4a  mov eax, 0x4102F0
00007588ecdd0c4f  mov rcx, 0x7588ECDD0CC0
00007588ecdd0c59  mov [r15+r14*8+0x328], rax
00007588ecdd0c61  mov [r15+r14*8+0x368], rcx
00007588ecdd0c69  add r14d, 0x01
00007588ecdd0c6d  and r14d, 0x07
00007588ecdd0c71  mov [r15+0x320], r14d
00007588ecdd0c78  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0c80  jz 0x00007588ECDCED70
00007588ecdd0c86  nop [rax+rax*1], ax
00007588ecdd0c8f  nop [rax+rax*1], eax
00007588ecdd0c97  mov eax, 0x4106BC
00007588ecdd0c9c  mov [r15+0x100], rax
00007588ecdd0ca3  jmp 0x00007588ECBFE110
00007588ecdd0ca8  int3
00007588ecdd0ca9  call 0x00007588ECCC3FE0
00007588ecdd0cae  jmp 0x00007588ECDD0C38
00007588ecdd0cb3  int3
00007588ecdd0cb4  nop [rax+rax*1], ax
00007588ecdd0cbd  nop [rax], eax
00007588ecdd0cc0  mov rax, [r15+0xF8]
00007588ecdd0cc7  lea r14, [rax+0xD0]
00007588ecdd0cce  mov r12d, [r13+r14*1]
00007588ecdd0cd3  lea r14, [rax+0xD4]
00007588ecdd0cda  mov r11d, [r13+r14*1]
00007588ecdd0cdf  lea r14, [rax+0xD8]
00007588ecdd0ce6  mov r10d, [r13+r14*1]
00007588ecdd0ceb  lea r14, [rax+0xDC]
00007588ecdd0cf2  mov r9d, [r13+r14*1]
00007588ecdd0cf7  mov qword ptr [r15+0x48], 0x430C20
00007588ecdd0cff  mov qword ptr [r15+0xA0], 0x00
00007588ecdd0d0a  bswap r12d
00007588ecdd0d0d  bswap r11d
00007588ecdd0d10  mov qword ptr [r15+0x98], 0x430D8C
00007588ecdd0d1b  mov r14d, 0x430C20
00007588ecdd0d21  mov [r13+r14*1], r12d
00007588ecdd0d26  mov r14d, 0x430C24
00007588ecdd0d2c  mov [r13+r14*1], r11d
00007588ecdd0d31  bswap r10d
00007588ecdd0d34  bswap r9d
00007588ecdd0d37  lea r14, [rax+0xE0]
00007588ecdd0d3e  mov r12d, [r13+r14*1]
00007588ecdd0d43  lea r14, [rax+0xE4]
00007588ecdd0d4a  mov r11d, [r13+r14*1]
00007588ecdd0d4f  mov r14d, 0x430C28
00007588ecdd0d55  mov [r13+r14*1], r10d
00007588ecdd0d5a  mov r14d, 0x430C2C
00007588ecdd0d60  mov [r13+r14*1], r9d
00007588ecdd0d65  bswap r12d
00007588ecdd0d68  bswap r11d
00007588ecdd0d6b  mov [rsp+0x10], r11d
00007588ecdd0d70  mov r11d, r11d
00007588ecdd0d73  mov [r15+0x58], r11
00007588ecdd0d77  lea r14, [rax+0xE8]
00007588ecdd0d7e  mov r11d, [r13+r14*1]
00007588ecdd0d83  lea r14, [rax+0xEC]
00007588ecdd0d8a  mov eax, [r13+r14*1]
00007588ecdd0d8f  mov [rsp+0x20], eax
00007588ecdd0d93  mov eax, eax
00007588ecdd0d95  mov [r15+0x60], rax
00007588ecdd0d99  mov eax, 0x430C30
00007588ecdd0d9e  mov [r13+rax*1], r12d
00007588ecdd0da3  mov eax, 0x430C34
00007588ecdd0da8  mov r14d, [rsp+0x10]
00007588ecdd0dad  mov [r13+rax*1], r14d
00007588ecdd0db2  bswap r11d
00007588ecdd0db5  mov [rsp+0x10], r11d
00007588ecdd0dba  mov r11d, r11d
00007588ecdd0dbd  mov [r15+0x40], r11
00007588ecdd0dc1  mov eax, [rsp+0x20]
00007588ecdd0dc5  bswap eax
00007588ecdd0dc7  mov [rsp+0x20], eax
00007588ecdd0dcb  mov eax, eax
00007588ecdd0dcd  mov [r15+0x50], rax
00007588ecdd0dd1  mov eax, 0x430C38
00007588ecdd0dd6  mov r14d, [rsp+0x10]
00007588ecdd0ddb  mov [r13+rax*1], r14d
00007588ecdd0de0  mov eax, 0x430C3C
00007588ecdd0de5  mov r14d, [rsp+0x20]
00007588ecdd0dea  mov [r13+rax*1], r14d
00007588ecdd0def  mov eax, [r15+0xA0]
00007588ecdd0df6  lea r14d, [eax+0x11]
00007588ecdd0dfb  mov r14d, r14d
00007588ecdd0dfe  mov [r15], r14
00007588ecdd0e01  mov qword ptr [r15+0xF0], 0x41034C
00007588ecdd0e0c  mov r14d, [r15+0x320]
00007588ecdd0e13  mov eax, 0x41034C
00007588ecdd0e18  mov rcx, 0x7588ECDD0F90
00007588ecdd0e22  mov [r15+r14*8+0x328], rax
00007588ecdd0e2a  mov [r15+r14*8+0x368], rcx
00007588ecdd0e32  add r14d, 0x01
00007588ecdd0e36  and r14d, 0x07
00007588ecdd0e3a  mov [r15+0x320], r14d
00007588ecdd0e41  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0e49  jz 0x00007588ECDD0F20
00007588ecdd0e4f  nop [rax+rax*1], ax
00007588ecdd0e58  nop [rax+rax*1], eax
00007588ecdd0e60  mov eax, 0x410938
00007588ecdd0e65  mov [r15+0x100], rax
00007588ecdd0e6c  jmp 0x00007588ECBFE110
00007588ecdd0e71  int3
00007588ecdd0e72  call 0x00007588ECCE26A0
00007588ecdd0e77  jmp 0x00007588ECDD0CD3
00007588ecdd0e7c  call 0x00007588ECCE1430
00007588ecdd0e81  jmp 0x00007588ECDD0CDF
00007588ecdd0e86  call 0x00007588ECCE01C0
00007588ecdd0e8b  jmp 0x00007588ECDD0CEB
00007588ecdd0e90  call 0x00007588ECCDEF50
00007588ecdd0e95  jmp 0x00007588ECDD0CF7
00007588ecdd0e9a  call 0x00007588ECCE2BA0
00007588ecdd0e9f  jmp 0x00007588ECDD0D26
00007588ecdd0ea4  call 0x00007588ECCE1920
00007588ecdd0ea9  jmp 0x00007588ECDD0D31
00007588ecdd0eae  call 0x00007588ECCE26A0
00007588ecdd0eb3  jmp 0x00007588ECDD0D43
00007588ecdd0eb8  call 0x00007588ECCE1430
00007588ecdd0ebd  jmp 0x00007588ECDD0D4F
00007588ecdd0ec2  call 0x00007588ECCE06B0
00007588ecdd0ec7  jmp 0x00007588ECDD0D5A
00007588ecdd0ecc  call 0x00007588ECCDF440
00007588ecdd0ed1  jmp 0x00007588ECDD0D65
00007588ecdd0ed6  call 0x00007588ECCE1430
00007588ecdd0edb  jmp 0x00007588ECDD0D83
00007588ecdd0ee0  call 0x00007588ECCD5890
00007588ecdd0ee5  jmp 0x00007588ECDD0D8F
00007588ecdd0eea  call 0x00007588ECC0BAE0
00007588ecdd0eef  jmp 0x00007588ECDD0DA3
00007588ecdd0ef4  call 0x00007588ECC0DFE0
00007588ecdd0ef9  jmp 0x00007588ECDD0DB2
00007588ecdd0efe  call 0x00007588ECC0DFE0
00007588ecdd0f03  jmp 0x00007588ECDD0DE0
00007588ecdd0f08  call 0x00007588ECC0DFE0
00007588ecdd0f0d  jmp 0x00007588ECDD0DEF
00007588ecdd0f12  int3
00007588ecdd0f13  nop [rax+rax*1], ax
00007588ecdd0f1c  nop [rax], eax
00007588ecdd0f20  mov eax, [r15]
00007588ecdd0f23  mov [rsp+0x10], eax
00007588ecdd0f27  shr eax, 0x10
00007588ecdd0f2a  mov r14d, [rsp+0x10]
00007588ecdd0f2f  xor r14d, eax
00007588ecdd0f32  imul r14d, r14d, 0x7FEB352D
00007588ecdd0f39  mov eax, 0x846CA68B
00007588ecdd0f3e  mov eax, eax
00007588ecdd0f40  mov [r15+0x48], rax
00007588ecdd0f44  mov [rsp+0x10], r14d
00007588ecdd0f49  shr r14d, 0x0F
00007588ecdd0f4d  mov eax, [rsp+0x10]
00007588ecdd0f51  xor eax, r14d
00007588ecdd0f54  imul eax, eax, 0x846CA68B
00007588ecdd0f5a  mov [rsp+0x10], eax
00007588ecdd0f5e  mov eax, eax
00007588ecdd0f60  mov [r15+0x40], rax
00007588ecdd0f64  mov eax, [rsp+0x10]
00007588ecdd0f68  shr eax, 0x10
00007588ecdd0f6b  mov r14d, [rsp+0x10]
00007588ecdd0f70  xor r14d, eax
00007588ecdd0f73  mov r14d, r14d
00007588ecdd0f76  mov [r15], r14
00007588ecdd0f79  mov rax, [r15+0xF0]
00007588ecdd0f80  mov [r15+0x100], rax
00007588ecdd0f87  jmp 0x00007588ECDCE5C0
00007588ecdd0f8c  int3
00007588ecdd0f8d  int3
00007588ecdd0f8e  nop
00007588ecdd0f90  mov rax, [r15+0xA0]
00007588ecdd0f97  mov [rsp+0x10], rax
00007588ecdd0f9c  shl rax, 0x02
00007588ecdd0fa0  mov r14, [r15+0x98]
00007588ecdd0fa7  lea r12, [r14+rax*1]
00007588ecdd0fab  mov eax, [r15]
00007588ecdd0fae  mov [r13+r12*1], eax
00007588ecdd0fb3  mov rax, [rsp+0x10]
00007588ecdd0fb8  lea r14, [rax+0x01]
00007588ecdd0fbc  mov [r15+0xA0], r14
00007588ecdd0fc3  xor eax, eax
00007588ecdd0fc5  mov r12d, 0x400
00007588ecdd0fcb  cmp r14, r12
00007588ecdd0fce  cmc
00007588ecdd0fcf  lahf
00007588ecdd0fd0  seto al
00007588ecdd0fd3  mov [r15+0x108], eax
00007588ecdd0fda  mov eax, [r15+0x108]
00007588ecdd0fe1  sahf
00007588ecdd0fe2  jnz 0x00007588ECDD1014
00007588ecdd0fe4  cmp dword ptr [r15+0x318], 0x00
00007588ecdd0fec  jz 0x00007588ECDD10E0
00007588ecdd0ff2  nop [rax+rax*1], ax
00007588ecdd0ffb  nop [rax+rax*1], eax
00007588ecdd1003  mov eax, 0x41035C
00007588ecdd1008  mov [r15+0x100], rax
00007588ecdd100f  jmp 0x00007588ECBFE110
00007588ecdd1014  cmp dword ptr [r15+0x318], 0x00
00007588ecdd101c  jz 0x00007588ECDD1050
00007588ecdd1022  nop [rax+rax*1], ax
00007588ecdd102b  nop [rax+rax*1], eax
00007588ecdd1033  mov eax, 0x410344
00007588ecdd1038  mov [r15+0x100], rax
00007588ecdd103f  jmp 0x00007588ECBFE110
00007588ecdd1044  int3
00007588ecdd1045  call 0x00007588ECCB4B70
00007588ecdd104a  jmp 0x00007588ECDD0FB3
00007588ecdd104f  int3
00007588ecdd1050  mov eax, [r15+0xA0]
00007588ecdd1057  lea r14d, [eax+0x11]
00007588ecdd105c  mov r14d, r14d
00007588ecdd105f  mov [r15], r14
00007588ecdd1062  mov qword ptr [r15+0xF0], 0x41034C
00007588ecdd106d  mov r14d, [r15+0x320]
00007588ecdd1074  mov eax, 0x41034C
00007588ecdd1079  mov rcx, 0x7588ECDD0F90
00007588ecdd1083  mov [r15+r14*8+0x328], rax
00007588ecdd108b  mov [r15+r14*8+0x368], rcx
00007588ecdd1093  add r14d, 0x01
00007588ecdd1097  and r14d, 0x07
00007588ecdd109b  mov [r15+0x320], r14d
00007588ecdd10a2  cmp dword ptr [r15+0x318], 0x00
00007588ecdd10aa  jz 0x00007588ECDD0F20
00007588ecdd10b0  nop [rax+rax*1], ax
00007588ecdd10b9  nop [rax+rax*1], eax
00007588ecdd10c1  mov eax, 0x410938
00007588ecdd10c6  mov [r15+0x100], rax
00007588ecdd10cd  jmp 0x00007588ECBFE110
00007588ecdd10d2  int3
00007588ecdd10d3  int3
00007588ecdd10d4  nop [rax+rax*1], ax
00007588ecdd10dd  nop [rax], eax
00007588ecdd10e0  mov qword ptr [r15+0x40], 0x01
00007588ecdd10e8  cmp dword ptr [r15+0x318], 0x00
00007588ecdd10f0  jz 0x00007588ECDD1120
00007588ecdd10f6  nop [rax+rax*1], ax
00007588ecdd10ff  nop [rax+rax*1], eax
00007588ecdd1107  mov eax, 0x410378
00007588ecdd110c  mov [r15+0x100], rax
00007588ecdd1113  jmp 0x00007588ECBFE110
00007588ecdd1118  int3
00007588ecdd1119  int3
00007588ecdd111a  nop [rax+rax*1], ax
00007588ecdd1120  mov rax, [r15+0x40]
00007588ecdd1124  mov [rsp+0x10], rax
00007588ecdd1129  shl rax, 0x02
00007588ecdd112d  mov r14, [r15+0x98]
00007588ecdd1134  lea r12, [r14+rax*1]
00007588ecdd1138  mov eax, [r13+r12*1]
00007588ecdd113d  mov [rsp+0x20], eax
00007588ecdd1141  mov eax, eax
00007588ecdd1143  mov [r15+0x48], rax
00007588ecdd1147  mov rax, [rsp+0x10]
00007588ecdd114c  mov [r15+0x50], rax
00007588ecdd1150  mov eax, [r15+0x50]
00007588ecdd1154  lea r12d, [eax-0x01]
00007588ecdd1159  mov r12d, r12d
00007588ecdd115c  mov [r15+0x58], r12
00007588ecdd1160  mov rax, [r15+0x58]
00007588ecdd1164  mov r12d, eax
00007588ecdd1167  mov r12d, r12d
00007588ecdd116a  shl r12, 0x02
00007588ecdd116e  lea rax, [r14+r12*1]
00007588ecdd1172  mov r14d, [r13+rax*1]
00007588ecdd1177  mov [rsp+0x10], r14d
00007588ecdd117c  mov r14d, r14d
00007588ecdd117f  mov [r15+0x60], r14
00007588ecdd1183  xor eax, eax
00007588ecdd1185  mov r14d, [rsp+0x10]
00007588ecdd118a  mov r12d, [rsp+0x20]
00007588ecdd118f  cmp r14d, r12d
00007588ecdd1192  cmc
00007588ecdd1193  lahf
00007588ecdd1194  seto al
00007588ecdd1197  mov [r15+0x108], eax
00007588ecdd119e  mov eax, [r15+0x108]
00007588ecdd11a5  sahf
00007588ecdd11a6  cmc
00007588ecdd11a7  jbe 0x00007588ECDD11D9
00007588ecdd11a9  cmp dword ptr [r15+0x318], 0x00
00007588ecdd11b1  jz 0x00007588ECDD1220
00007588ecdd11b7  nop [rax+rax*1], ax
00007588ecdd11c0  nop [rax+rax*1], eax
00007588ecdd11c8  mov eax, 0x410390
00007588ecdd11cd  mov [r15+0x100], rax
00007588ecdd11d4  jmp 0x00007588ECBFE110
00007588ecdd11d9  cmp dword ptr [r15+0x318], 0x00
00007588ecdd11e1  jz 0x00007588ECDD14C0
00007588ecdd11e7  nop [rax+rax*1], ax
00007588ecdd11f0  nop [rax+rax*1], eax
00007588ecdd11f8  mov eax, 0x410368
00007588ecdd11fd  mov [r15+0x100], rax
00007588ecdd1204  jmp 0x00007588ECBFE110
00007588ecdd1209  int3
00007588ecdd120a  call 0x00007588ECCB4690
00007588ecdd120f  jmp 0x00007588ECDD113D
00007588ecdd1214  call 0x00007588ECC0DAE0
00007588ecdd1219  jmp 0x00007588ECDD1177
00007588ecdd121e  int3
00007588ecdd121f  nop
00007588ecdd1220  mov rax, [r15+0x50]
00007588ecdd1224  mov [rsp+0x10], rax
00007588ecdd1229  shl rax, 0x02
00007588ecdd122d  mov r14, [r15+0x98]
00007588ecdd1234  lea r12, [r14+rax*1]
00007588ecdd1238  mov eax, [r15+0x60]
00007588ecdd123c  mov [r13+r12*1], eax
00007588ecdd1241  mov rax, [rsp+0x10]
00007588ecdd1246  lea r14, [rax-0x01]
00007588ecdd124a  mov [r15+0x50], r14
00007588ecdd124e  mov rax, [r15+0x58]
00007588ecdd1252  test rax, rax
00007588ecdd1255  setz al
00007588ecdd1258  movzx rax, al
00007588ecdd125c  mov [rsp+0x414], al
00007588ecdd1263  cmp byte ptr [rsp+0x414], 0x00
00007588ecdd126b  jz 0x00007588ECDD129D
00007588ecdd126d  cmp dword ptr [r15+0x318], 0x00
00007588ecdd1275  jz 0x00007588ECDD12E0
00007588ecdd127b  nop [rax+rax*1], ax
00007588ecdd1284  nop [rax+rax*1], eax
00007588ecdd128c  mov eax, 0x41039C
00007588ecdd1291  mov [r15+0x100], rax
00007588ecdd1298  jmp 0x00007588ECBFE110
00007588ecdd129d  cmp dword ptr [r15+0x318], 0x00
00007588ecdd12a5  jz 0x00007588ECDD13E0
00007588ecdd12ab  nop [rax+rax*1], ax
00007588ecdd12b4  nop [rax+rax*1], eax
00007588ecdd12bc  mov eax, 0x410380
00007588ecdd12c1  mov [r15+0x100], rax
00007588ecdd12c8  jmp 0x00007588ECBFE110
00007588ecdd12cd  int3
00007588ecdd12ce  call 0x00007588ECCB4B70
00007588ecdd12d3  jmp 0x00007588ECDD1241
00007588ecdd12d8  int3
00007588ecdd12d9  nop [rax], eax
00007588ecdd12e0  cmp dword ptr [r15+0x318], 0x00
00007588ecdd12e8  jz 0x00007588ECDD1320
00007588ecdd12ee  nop [rax+rax*1], ax
00007588ecdd12f7  nop [rax+rax*1], eax
00007588ecdd12ff  mov eax, 0x410364
00007588ecdd1304  mov [r15+0x100], rax
00007588ecdd130b  jmp 0x00007588ECBFE110
00007588ecdd1310  int3
00007588ecdd1311  int3
00007588ecdd1312  nop [rax+rax*1], ax
00007588ecdd131b  nop [rax+rax*1], eax
00007588ecdd1320  mov qword ptr [r15+0x50], 0x00
00007588ecdd1328  mov rax, [r15+0x40]
00007588ecdd132c  lea r14, [rax+0x01]
00007588ecdd1330  mov [r15+0x40], r14
00007588ecdd1334  mov rax, [r15+0x98]
00007588ecdd133b  mov r12d, [r15+0x48]
00007588ecdd133f  mov [r13+rax*1], r12d
00007588ecdd1344  xor eax, eax
00007588ecdd1346  mov r12d, 0x400
00007588ecdd134c  cmp r14, r12
00007588ecdd134f  cmc
00007588ecdd1350  lahf
00007588ecdd1351  seto al
00007588ecdd1354  mov [r15+0x108], eax
00007588ecdd135b  mov eax, [r15+0x108]
00007588ecdd1362  sahf
00007588ecdd1363  jz 0x00007588ECDD1395
00007588ecdd1365  cmp dword ptr [r15+0x318], 0x00
00007588ecdd136d  jz 0x00007588ECDD1120
00007588ecdd1373  nop [rax+rax*1], ax
00007588ecdd137c  nop [rax+rax*1], eax
00007588ecdd1384  mov eax, 0x410378
00007588ecdd1389  mov [r15+0x100], rax
00007588ecdd1390  jmp 0x00007588ECBFE110
00007588ecdd1395  cmp dword ptr [r15+0x318], 0x00
00007588ecdd139d  jz 0x00007588ECDD1580
00007588ecdd13a3  nop [rax+rax*1], ax
00007588ecdd13ac  nop [rax+rax*1], eax
00007588ecdd13b4  mov eax, 0x4103A0
00007588ecdd13b9  mov [r15+0x100], rax
00007588ecdd13c0  jmp 0x00007588ECBFE110
00007588ecdd13c5  int3
00007588ecdd13c6  call 0x00007588ECC0BAE0
00007588ecdd13cb  jmp 0x00007588ECDD1344
00007588ecdd13d0  int3
00007588ecdd13d1  nop [rax+rax*1], ax
00007588ecdd13da  nop [rax+rax*1], ax
00007588ecdd13e0  mov eax, [r15+0x50]
00007588ecdd13e4  lea r14d, [eax-0x01]
00007588ecdd13e9  mov r14d, r14d
00007588ecdd13ec  mov [r15+0x58], r14
00007588ecdd13f0  mov rax, [r15+0x58]
00007588ecdd13f4  mov r14d, eax
00007588ecdd13f7  mov r14d, r14d
00007588ecdd13fa  shl r14, 0x02
00007588ecdd13fe  mov rax, [r15+0x98]
00007588ecdd1405  lea r12, [rax+r14*1]
00007588ecdd1409  mov eax, [r13+r12*1]
00007588ecdd140e  mov [rsp+0x10], eax
00007588ecdd1412  mov eax, eax
00007588ecdd1414  mov [r15+0x60], rax
00007588ecdd1418  mov eax, [r15+0x48]
00007588ecdd141c  mov [rsp+0x20], eax
00007588ecdd1420  xor eax, eax
00007588ecdd1422  mov r14d, [rsp+0x10]
00007588ecdd1427  mov r12d, [rsp+0x20]
00007588ecdd142c  cmp r14d, r12d
00007588ecdd142f  cmc
00007588ecdd1430  lahf
00007588ecdd1431  seto al
00007588ecdd1434  mov [r15+0x108], eax
00007588ecdd143b  mov eax, [r15+0x108]
00007588ecdd1442  sahf
00007588ecdd1443  cmc
00007588ecdd1444  jbe 0x00007588ECDD1476
00007588ecdd1446  cmp dword ptr [r15+0x318], 0x00
00007588ecdd144e  jz 0x00007588ECDD1220
00007588ecdd1454  nop [rax+rax*1], ax
00007588ecdd145d  nop [rax+rax*1], eax
00007588ecdd1465  mov eax, 0x410390
00007588ecdd146a  mov [r15+0x100], rax
00007588ecdd1471  jmp 0x00007588ECBFE110
00007588ecdd1476  cmp dword ptr [r15+0x318], 0x00
00007588ecdd147e  jz 0x00007588ECDD14C0
00007588ecdd1484  nop [rax+rax*1], ax
00007588ecdd148d  nop [rax+rax*1], eax
00007588ecdd1495  mov eax, 0x410368
00007588ecdd149a  mov [r15+0x100], rax
00007588ecdd14a1  jmp 0x00007588ECBFE110
00007588ecdd14a6  int3
00007588ecdd14a7  call 0x00007588ECCB4690
00007588ecdd14ac  jmp 0x00007588ECDD140E
00007588ecdd14b1  int3
00007588ecdd14b2  nop [rax+rax*1], ax
00007588ecdd14bb  nop [rax+rax*1], eax
00007588ecdd14c0  mov rax, [r15+0x40]
00007588ecdd14c4  lea r14, [rax+0x01]
00007588ecdd14c8  mov [r15+0x40], r14
00007588ecdd14cc  mov rax, [r15+0x50]
00007588ecdd14d0  mov r12d, eax
00007588ecdd14d3  mov r12d, r12d
00007588ecdd14d6  shl r12, 0x02
00007588ecdd14da  mov rax, [r15+0x98]
00007588ecdd14e1  lea r11, [rax+r12*1]
00007588ecdd14e5  mov eax, [r15+0x48]
00007588ecdd14e9  mov [r13+r11*1], eax
00007588ecdd14ee  xor eax, eax
00007588ecdd14f0  mov r12d, 0x400
00007588ecdd14f6  cmp r14, r12
00007588ecdd14f9  cmc
00007588ecdd14fa  lahf
00007588ecdd14fb  seto al
00007588ecdd14fe  mov [r15+0x108], eax
00007588ecdd1505  mov eax, [r15+0x108]
00007588ecdd150c  sahf
00007588ecdd150d  jz 0x00007588ECDD153F
00007588ecdd150f  cmp dword ptr [r15+0x318], 0x00
00007588ecdd1517  jz 0x00007588ECDD1120
00007588ecdd151d  nop [rax+rax*1], ax
00007588ecdd1526  nop [rax+rax*1], eax
00007588ecdd152e  mov eax, 0x410378
00007588ecdd1533  mov [r15+0x100], rax
00007588ecdd153a  jmp 0x00007588ECBFE110
00007588ecdd153f  cmp dword ptr [r15+0x318], 0x00
00007588ecdd1547  jz 0x00007588ECDD1580
00007588ecdd154d  nop [rax+rax*1], ax
00007588ecdd1556  nop [rax+rax*1], eax
00007588ecdd155e  mov eax, 0x4103A0
00007588ecdd1563  mov [r15+0x100], rax
00007588ecdd156a  jmp 0x00007588ECBFE110
00007588ecdd156f  int3
00007588ecdd1570  call 0x00007588ECCA4270
00007588ecdd1575  jmp 0x00007588ECDD14EE
00007588ecdd157a  int3
00007588ecdd157b  nop [rax+rax*1], eax
00007588ecdd1580  mov qword ptr [r15+0x40], 0x430000
00007588ecdd1588  mov eax, 0x430C40
00007588ecdd158d  mov r14, [r13+rax*1]
00007588ecdd1592  mov rax, [r15+0x98]
00007588ecdd1599  mov r12d, [r13+rax*1]
00007588ecdd159e  lea r11, [rax+0x04]
00007588ecdd15a2  mov eax, [r13+r11*1]
00007588ecdd15a7  mov r12d, r12d
00007588ecdd15aa  mov [r15+0x68], r12
00007588ecdd15ae  mov eax, eax
00007588ecdd15b0  mov [r15+0x60], rax
00007588ecdd15b4  mov rax, [r15+0x68]
00007588ecdd15b8  mov [r15+0x68], rax
00007588ecdd15bc  mov qword ptr [r15+0x58], 0x02
00007588ecdd15c4  mov [rsp+0x10], rax
00007588ecdd15c9  xor eax, eax
00007588ecdd15cb  mov r12d, 0x02
00007588ecdd15d1  mov r11d, 0x400
00007588ecdd15d7  cmp r12, r11
00007588ecdd15da  cmc
00007588ecdd15db  lahf
00007588ecdd15dc  seto al
00007588ecdd15df  mov [r15+0x108], eax
00007588ecdd15e6  mov rax, [r15+0x60]
00007588ecdd15ea  mov r12d, 0x02
00007588ecdd15f0  imul rax, r12
00007588ecdd15f4  mov [r15+0x50], rax
00007588ecdd15f8  mov rax, [rsp+0x10]
00007588ecdd15fd  lea r12, [rax+r14*1]
00007588ecdd1601  mov [r15+0x48], r12
00007588ecdd1605  mov eax, [r15+0x108]
00007588ecdd160c  sahf
00007588ecdd160d  jnz 0x00007588ECDD163F
00007588ecdd160f  cmp dword ptr [r15+0x318], 0x00
00007588ecdd1617  jz 0x00007588ECDD17B0
00007588ecdd161d  nop [rax+rax*1], ax
00007588ecdd1626  nop [rax+rax*1], eax
00007588ecdd162e  mov eax, 0x4103D0
00007588ecdd1633  mov [r15+0x100], rax
00007588ecdd163a  jmp 0x00007588ECBFE110
00007588ecdd163f  cmp dword ptr [r15+0x318], 0x00
00007588ecdd1647  jz 0x00007588ECDD1690
00007588ecdd164d  nop [rax+rax*1], ax
00007588ecdd1656  nop [rax+rax*1], eax
00007588ecdd165e  mov eax, 0x4103B0
00007588ecdd1663  mov [r15+0x100], rax
00007588ecdd166a  jmp 0x00007588ECBFE110
00007588ecdd166f  int3
00007588ecdd1670  call 0x00007588ECC0DC20
00007588ecdd1675  jmp 0x00007588ECDD1592
00007588ecdd167a  call 0x00007588ECC0B5E0
00007588ecdd167f  jmp 0x00007588ECDD159E
00007588ecdd1684  call 0x00007588ECCA3D90
00007588ecdd1689  jmp 0x00007588ECDD15A7
00007588ecdd168e  int3
00007588ecdd168f  nop
00007588ecdd1690  mov rax, [r15+0x98]
00007588ecdd1697  mov r14, [r15+0x58]
00007588ecdd169b  mov [rsp+0x10], r14
00007588ecdd16a0  shl r14, 0x02
00007588ecdd16a4  lea r12, [rax+r14*1]
00007588ecdd16a8  mov eax, [r13+r12*1]
00007588ecdd16ad  lea r14, [r12+0x04]
00007588ecdd16b2  mov r12d, [r13+r14*1]
00007588ecdd16b7  mov eax, eax
00007588ecdd16b9  mov [r15+0x68], rax
00007588ecdd16bd  mov r12d, r12d
00007588ecdd16c0  mov [r15+0x60], r12
00007588ecdd16c4  mov rax, [r15+0x68]
00007588ecdd16c8  mov [rsp+0x20], rax
00007588ecdd16cd  mov r14, [rsp+0x10]
00007588ecdd16d2  imul rax, r14
00007588ecdd16d6  mov r12, [rsp+0x20]
00007588ecdd16db  lea r11, [r12+rax*1]
00007588ecdd16df  mov [r15+0x68], r11
00007588ecdd16e3  lea rax, [r14+0x02]
00007588ecdd16e7  mov [r15+0x58], rax
00007588ecdd16eb  mov [rsp+0x10], rax
00007588ecdd16f0  xor eax, eax
00007588ecdd16f2  mov r14, [rsp+0x10]
00007588ecdd16f7  mov r12d, 0x400
00007588ecdd16fd  cmp r14, r12
00007588ecdd1700  cmc
00007588ecdd1701  lahf
00007588ecdd1702  seto al
00007588ecdd1705  mov [r15+0x108], eax
00007588ecdd170c  mov rax, [r15+0x50]
00007588ecdd1710  mov r12, [r15+0x60]
00007588ecdd1714  imul r14, r12
00007588ecdd1718  lea r12, [rax+r14*1]
00007588ecdd171c  mov [r15+0x50], r12
00007588ecdd1720  mov rax, [r15+0x48]
00007588ecdd1724  lea r14, [r11+rax*1]
00007588ecdd1728  mov [r15+0x48], r14
00007588ecdd172c  mov eax, [r15+0x108]
00007588ecdd1733  sahf
00007588ecdd1734  jnz 0x00007588ECDD1766
00007588ecdd1736  cmp dword ptr [r15+0x318], 0x00
00007588ecdd173e  jz 0x00007588ECDD17B0
00007588ecdd1744  nop [rax+rax*1], ax
00007588ecdd174d  nop [rax+rax*1], eax
00007588ecdd1755  mov eax, 0x4103D0
00007588ecdd175a  mov [r15+0x100], rax
00007588ecdd1761  jmp 0x00007588ECBFE110
00007588ecdd1766  cmp dword ptr [r15+0x318], 0x00
00007588ecdd176e  jz 0x00007588ECDD1690
00007588ecdd1774  nop [rax+rax*1], ax
00007588ecdd177d  nop [rax+rax*1], eax
00007588ecdd1785  mov eax, 0x4103B0
00007588ecdd178a  mov [r15+0x100], rax
00007588ecdd1791  jmp 0x00007588ECBFE110
00007588ecdd1796  int3
00007588ecdd1797  call 0x00007588ECCB4690
00007588ecdd179c  jmp 0x00007588ECDD16AD
00007588ecdd17a1  call 0x00007588ECCE26A0
00007588ecdd17a6  jmp 0x00007588ECDD16B7
00007588ecdd17ab  int3
00007588ecdd17ac  nop [rax], eax
00007588ecdd17b0  mov qword ptr [r15+0x98], 0x00
00007588ecdd17bb  mov rax, [r15+0x50]
00007588ecdd17bf  mov r14, [r15+0x48]
00007588ecdd17c3  lea r12, [rax+r14*1]
00007588ecdd17c7  mov [r15+0x48], r12
00007588ecdd17cb  mov rax, [r15+0x40]
00007588ecdd17cf  lea r14, [rax+0xC40]
00007588ecdd17d6  mov [r13+r14*1], r12
00007588ecdd17db  mov qword ptr [r15], 0x01
00007588ecdd17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007588ecdd17ed  mov r14d, [r15+0x320]
00007588ecdd17f4  mov eax, 0x4103E8
00007588ecdd17f9  mov rcx, 0x7588ECDD1860
00007588ecdd1803  mov [r15+r14*8+0x328], rax
00007588ecdd180b  mov [r15+r14*8+0x368], rcx
00007588ecdd1813  add r14d, 0x01
00007588ecdd1817  and r14d, 0x07
00007588ecdd181b  mov [r15+0x320], r14d
00007588ecdd1822  cmp dword ptr [r15+0x318], 0x00
00007588ecdd182a  jz 0x00007588ECDD0F20
00007588ecdd1830  nop [rax+rax*1], ax
00007588ecdd1839  nop [rax+rax*1], eax
00007588ecdd1841  mov eax, 0x410938
00007588ecdd1846  mov [r15+0x100], rax
00007588ecdd184d  jmp 0x00007588ECBFE110
00007588ecdd1852  int3
00007588ecdd1853  call 0x00007588ECCE2CE0
00007588ecdd1858  jmp 0x00007588ECDD17DB
00007588ecdd185d  int3
00007588ecdd185e  nop
00007588ecdd1860  mov eax, [r15+0x98]
00007588ecdd1867  lea r14d, [eax+0x01]
00007588ecdd186c  mov [rsp+0x10], r14d
00007588ecdd1871  mov r14d, r14d
00007588ecdd1874  mov [r15+0x98], r14
00007588ecdd187b  xor eax, eax
00007588ecdd187d  mov r14d, [rsp+0x10]
00007588ecdd1882  cmp r14d, 0x10000
00007588ecdd1889  cmc
00007588ecdd188a  lahf
00007588ecdd188b  seto al
00007588ecdd188e  mov [r15+0x108], eax
00007588ecdd1895  mov eax, [r15+0x108]
00007588ecdd189c  sahf
00007588ecdd189d  jnz 0x00007588ECDD18CF
00007588ecdd189f  cmp dword ptr [r15+0x318], 0x00
00007588ecdd18a7  jz 0x00007588ECDD19A0
00007588ecdd18ad  nop [rax+rax*1], ax
00007588ecdd18b6  nop [rax+rax*1], eax
00007588ecdd18be  mov eax, 0x4103F4
00007588ecdd18c3  mov [r15+0x100], rax
00007588ecdd18ca  jmp 0x00007588ECBFE110
00007588ecdd18cf  cmp dword ptr [r15+0x318], 0x00
00007588ecdd18d7  jz 0x00007588ECDD1910
00007588ecdd18dd  nop [rax+rax*1], ax
00007588ecdd18e6  nop [rax+rax*1], eax
00007588ecdd18ee  mov eax, 0x4103E0
00007588ecdd18f3  mov [r15+0x100], rax
00007588ecdd18fa  jmp 0x00007588ECBFE110
00007588ecdd18ff  int3
00007588ecdd1900  int3
00007588ecdd1901  nop [rax+rax*1], ax
00007588ecdd190a  nop [rax+rax*1], ax
00007588ecdd1910  mov eax, [r15]
00007588ecdd1913  mov r14d, [r15+0x98]
00007588ecdd191a  lea r12d, [eax+r14d*1]
00007588ecdd191f  mov r12d, r12d
00007588ecdd1922  mov [r15], r12
00007588ecdd1925  mov qword ptr [r15+0xF0], 0x4103E8
00007588ecdd1930  mov r14d, [r15+0x320]
00007588ecdd1937  mov eax, 0x4103E8
00007588ecdd193c  mov rcx, 0x7588ECDD1860
00007588ecdd1946  mov [r15+r14*8+0x328], rax
00007588ecdd194e  mov [r15+r14*8+0x368], rcx
00007588ecdd1956  add r14d, 0x01
00007588ecdd195a  and r14d, 0x07
00007588ecdd195e  mov [r15+0x320], r14d
00007588ecdd1965  cmp dword ptr [r15+0x318], 0x00
00007588ecdd196d  jz 0x00007588ECDD0F20
00007588ecdd1973  nop [rax+rax*1], ax
00007588ecdd197c  nop [rax+rax*1], eax
00007588ecdd1984  mov eax, 0x410938
00007588ecdd1989  mov [r15+0x100], rax
00007588ecdd1990  jmp 0x00007588ECBFE110
00007588ecdd1995  int3
00007588ecdd1996  int3
00007588ecdd1997  nop [rax+rax*1], ax
00007588ecdd19a0  vmovaps xmm1, [0x00007588EC9FE010]
00007588ecdd19a8  movq xmm1, xmm1
00007588ecdd19ac  movaps [r15+0x110], xmm1
00007588ecdd19b4  mov eax, 0x420AA0
00007588ecdd19b9  mov r14, [r13+rax*1]
00007588ecdd19be  movq xmm1, r14
00007588ecdd19c3  movaps [r15+0x120], xmm1
00007588ecdd19cb  vmovaps xmm1, [0x00007588EC9FE020]
00007588ecdd19d3  movq xmm1, xmm1
00007588ecdd19d7  movaps [r15+0x140], xmm1
00007588ecdd19df  vmovaps xmm1, [0x00007588EC9FE030]
00007588ecdd19e7  vpbroadcastq xmm1, xmm1
00007588ecdd19ec  movaps [r15+0x150], xmm1
00007588ecdd19f4  mov qword ptr [r15+0x40], 0x02
00007588ecdd19fc  vmovaps xmm15, [0x00007588EC9FE040]
00007588ecdd1a04  movq xmm15, xmm15
00007588ecdd1a09  movaps [r15+0x160], xmm15
00007588ecdd1a11  vmovaps xmm15, [0x00007588EC9FE050]
00007588ecdd1a19  vpbroadcastq xmm15, xmm15
00007588ecdd1a1e  movaps [r15+0x130], xmm15
00007588ecdd1a26  mov rax, [r15+0x40]
00007588ecdd1a2a  vmovq xmm14, rax
00007588ecdd1a2f  vpbroadcastq xmm14, xmm14
00007588ecdd1a34  movaps [r15+0x170], xmm14
00007588ecdd1a3c  mov eax, 0x4209D0
00007588ecdd1a41  movups xmm13, [r13+rax*1]
00007588ecdd1a47  mov qword ptr [r15+0x40], 0x431D90
00007588ecdd1a4f  mov eax, [r15]
00007588ecdd1a52  mov r14d, 0x430C48
00007588ecdd1a58  mov [r13+r14*1], eax
00007588ecdd1a5d  mov qword ptr [r15+0x50], 0x431F90
00007588ecdd1a65  vpmovqd xmm12, xmm13
00007588ecdd1a6b  pxor xmm11, xmm11
00007588ecdd1a70  punpcklqdq xmm12, xmm11
00007588ecdd1a75  movaps [r15+0x210], xmm12
00007588ecdd1a7d  movq xmm12, qword ptr [r15+0x140]
00007588ecdd1a86  movq xmm11, qword ptr [r15+0x120]
00007588ecdd1a8f  psubd xmm12, xmm11
00007588ecdd1a94  movq xmm12, xmm12
00007588ecdd1a99  paddq xmm13, xmm14
00007588ecdd1a9e  movaps [r15+0x180], xmm13
00007588ecdd1aa6  movq xmm14, qword ptr [r15+0x160]
00007588ecdd1aaf  paddd xmm11, xmm14
00007588ecdd1ab4  movq xmm11, xmm11
00007588ecdd1ab9  movq xmm11, xmm11
00007588ecdd1abe  movaps [r15+0x120], xmm11
00007588ecdd1ac6  pmovzxdq xmm12, xmm12
00007588ecdd1acc  psllq xmm12, 0x00
00007588ecdd1ad2  movq xmm14, qword ptr [r15+0x210]
00007588ecdd1adb  movq xmm13, qword ptr [r15+0x110]
00007588ecdd1ae4  paddd xmm14, xmm13
00007588ecdd1ae9  movq xmm14, xmm14
00007588ecdd1aee  vcvtuqq2pd xmm12, xmm12
00007588ecdd1af4  pmovzxdq xmm14, xmm14
00007588ecdd1afa  psllq xmm14, 0x00
00007588ecdd1b00  vcvtuqq2pd xmm14, xmm14
00007588ecdd1b06  movaps xmm13, xmm12
00007588ecdd1b0a  mulpd xmm13, xmm1
00007588ecdd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007588ecdd1b15  ptest xmm11, xmm11
00007588ecdd1b1b  jnz 0x00007588ECDD1C0F
00007588ecdd1b21  movaps [r15+0x220], xmm13
00007588ecdd1b29  mov eax, 0x431F90
00007588ecdd1b2e  movups [r13+rax*1], xmm13
00007588ecdd1b34  movaps xmm1, xmm14
00007588ecdd1b38  mulpd xmm1, xmm15
00007588ecdd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007588ecdd1b42  ptest xmm13, xmm13
00007588ecdd1b48  jnz 0x00007588ECDD1D5C
00007588ecdd1b4e  movaps [r15+0x210], xmm1
00007588ecdd1b56  mov eax, 0x431D90
00007588ecdd1b5b  movups [r13+rax*1], xmm1
00007588ecdd1b61  mov qword ptr [r15+0x48], 0x10
00007588ecdd1b69  xor eax, eax
00007588ecdd1b6b  mov r14d, 0x10
00007588ecdd1b71  mov r12d, 0x200
00007588ecdd1b77  cmp r14, r12
00007588ecdd1b7a  cmc
00007588ecdd1b7b  lahf
00007588ecdd1b7c  seto al
00007588ecdd1b7f  mov [r15+0x108], eax
00007588ecdd1b86  mov eax, [r15+0x108]
00007588ecdd1b8d  sahf
00007588ecdd1b8e  jnz 0x00007588ECDD1BC0
00007588ecdd1b90  cmp dword ptr [r15+0x318], 0x00
00007588ecdd1b98  jz 0x00007588ECDD2300
00007588ecdd1b9e  nop [rax+rax*1], ax
00007588ecdd1ba7  nop [rax+rax*1], eax
00007588ecdd1baf  mov eax, 0x410480
00007588ecdd1bb4  mov [r15+0x100], rax
00007588ecdd1bbb  jmp 0x00007588ECBFE110
00007588ecdd1bc0  cmp dword ptr [r15+0x318], 0x00
00007588ecdd1bc8  jz 0x00007588ECDD1EB0
00007588ecdd1bce  nop [rax+rax*1], ax
00007588ecdd1bd7  nop [rax+rax*1], eax
00007588ecdd1bdf  mov eax, 0x410440
00007588ecdd1be4  mov [r15+0x100], rax
00007588ecdd1beb  jmp 0x00007588ECBFE110
00007588ecdd1bf0  int3
00007588ecdd1bf1  call 0x00007588ECC0DC20
00007588ecdd1bf6  jmp 0x00007588ECDD19BE
00007588ecdd1bfb  call 0x00007588ECC0C260
00007588ecdd1c00  jmp 0x00007588ECDD1A47
00007588ecdd1c05  call 0x00007588ECCD5D70
00007588ecdd1c0a  jmp 0x00007588ECDD1A5D
00007588ecdd1c0f  sub rsp, 0x08
00007588ecdd1c13  push rax
00007588ecdd1c14  push rcx
00007588ecdd1c15  push rdx
00007588ecdd1c16  push rdi
00007588ecdd1c17  push rsi
00007588ecdd1c18  push r8
00007588ecdd1c1a  push r9
00007588ecdd1c1c  push r10
00007588ecdd1c1e  push r11
00007588ecdd1c20  sub rsp, 0xF0
00007588ecdd1c27  vmovaps [rsp], xmm0
00007588ecdd1c2c  vmovaps [rsp+0x10], xmm1
00007588ecdd1c32  vmovaps [rsp+0x20], xmm2
00007588ecdd1c38  vmovaps [rsp+0x30], xmm3
00007588ecdd1c3e  vmovaps [rsp+0x40], xmm4
00007588ecdd1c44  vmovaps [rsp+0x50], xmm5
00007588ecdd1c4a  vmovaps [rsp+0x60], xmm6
00007588ecdd1c50  vmovaps [rsp+0x70], xmm7
00007588ecdd1c56  vmovaps [rsp+0x80], xmm8
00007588ecdd1c5f  vmovaps [rsp+0x90], xmm9
00007588ecdd1c68  vmovaps [rsp+0xA0], xmm10
00007588ecdd1c71  vmovaps [rsp+0xB0], xmm11
00007588ecdd1c7a  vmovaps [rsp+0xC0], xmm12
00007588ecdd1c83  vmovaps [rsp+0xD0], xmm14
00007588ecdd1c8c  vmovaps [rsp+0xE0], xmm15
00007588ecdd1c95  sub rsp, 0x30
00007588ecdd1c99  movaps [rsp], xmm13
00007588ecdd1c9e  movaps [rsp+0x10], xmm12
00007588ecdd1ca4  movaps [rsp+0x20], xmm1
00007588ecdd1ca9  lea rdi, [rsp]
00007588ecdd1cad  mov esi, 0x00
00007588ecdd1cb2  mov rax, 0x6516BF3BB530
00007588ecdd1cbc  call rax
00007588ecdd1cbe  movaps xmm13, [rsp]
00007588ecdd1cc3  add rsp, 0x30
00007588ecdd1cc7  vmovaps xmm0, [rsp]
00007588ecdd1ccc  vmovaps xmm1, [rsp+0x10]
00007588ecdd1cd2  vmovaps xmm2, [rsp+0x20]
00007588ecdd1cd8  vmovaps xmm3, [rsp+0x30]
00007588ecdd1cde  vmovaps xmm4, [rsp+0x40]
00007588ecdd1ce4  vmovaps xmm5, [rsp+0x50]
00007588ecdd1cea  vmovaps xmm6, [rsp+0x60]
00007588ecdd1cf0  vmovaps xmm7, [rsp+0x70]
00007588ecdd1cf6  vmovaps xmm8, [rsp+0x80]
00007588ecdd1cff  vmovaps xmm9, [rsp+0x90]
00007588ecdd1d08  vmovaps xmm10, [rsp+0xA0]
00007588ecdd1d11  vmovaps xmm11, [rsp+0xB0]
00007588ecdd1d1a  vmovaps xmm12, [rsp+0xC0]
00007588ecdd1d23  vmovaps xmm14, [rsp+0xD0]
00007588ecdd1d2c  vmovaps xmm15, [rsp+0xE0]
00007588ecdd1d35  add rsp, 0xF0
00007588ecdd1d3c  pop r11
00007588ecdd1d3e  pop r10
00007588ecdd1d40  pop r9
00007588ecdd1d42  pop r8
00007588ecdd1d44  pop rsi
00007588ecdd1d45  pop rdi
00007588ecdd1d46  pop rdx
00007588ecdd1d47  pop rcx
00007588ecdd1d48  pop rax
00007588ecdd1d49  add rsp, 0x08
00007588ecdd1d4d  jmp 0x00007588ECDD1B21
00007588ecdd1d52  call 0x00007588ECC0C380
00007588ecdd1d57  jmp 0x00007588ECDD1B34
00007588ecdd1d5c  sub rsp, 0x08
00007588ecdd1d60  push rax
00007588ecdd1d61  push rcx
00007588ecdd1d62  push rdx
00007588ecdd1d63  push rdi
00007588ecdd1d64  push rsi
00007588ecdd1d65  push r8
00007588ecdd1d67  push r9
00007588ecdd1d69  push r10
00007588ecdd1d6b  push r11
00007588ecdd1d6d  sub rsp, 0xF0
00007588ecdd1d74  vmovaps [rsp], xmm0
00007588ecdd1d79  vmovaps [rsp+0x10], xmm2
00007588ecdd1d7f  vmovaps [rsp+0x20], xmm3
00007588ecdd1d85  vmovaps [rsp+0x30], xmm4
00007588ecdd1d8b  vmovaps [rsp+0x40], xmm5
00007588ecdd1d91  vmovaps [rsp+0x50], xmm6
00007588ecdd1d97  vmovaps [rsp+0x60], xmm7
00007588ecdd1d9d  vmovaps [rsp+0x70], xmm8
00007588ecdd1da3  vmovaps [rsp+0x80], xmm9
00007588ecdd1dac  vmovaps [rsp+0x90], xmm10
00007588ecdd1db5  vmovaps [rsp+0xA0], xmm11
00007588ecdd1dbe  vmovaps [rsp+0xB0], xmm12
00007588ecdd1dc7  vmovaps [rsp+0xC0], xmm13
00007588ecdd1dd0  vmovaps [rsp+0xD0], xmm14
00007588ecdd1dd9  vmovaps [rsp+0xE0], xmm15
00007588ecdd1de2  sub rsp, 0x30
00007588ecdd1de6  movaps [rsp], xmm1
00007588ecdd1dea  movaps [rsp+0x10], xmm14
00007588ecdd1df0  movaps [rsp+0x20], xmm15
00007588ecdd1df6  lea rdi, [rsp]
00007588ecdd1dfa  mov esi, 0x00
00007588ecdd1dff  mov rax, 0x6516BF3BB530
00007588ecdd1e09  call rax
00007588ecdd1e0b  movaps xmm1, [rsp]
00007588ecdd1e0f  add rsp, 0x30
00007588ecdd1e13  vmovaps xmm0, [rsp]
00007588ecdd1e18  vmovaps xmm2, [rsp+0x10]
00007588ecdd1e1e  vmovaps xmm3, [rsp+0x20]
00007588ecdd1e24  vmovaps xmm4, [rsp+0x30]
00007588ecdd1e2a  vmovaps xmm5, [rsp+0x40]
00007588ecdd1e30  vmovaps xmm6, [rsp+0x50]
00007588ecdd1e36  vmovaps xmm7, [rsp+0x60]
00007588ecdd1e3c  vmovaps xmm8, [rsp+0x70]
00007588ecdd1e42  vmovaps xmm9, [rsp+0x80]
00007588ecdd1e4b  vmovaps xmm10, [rsp+0x90]
00007588ecdd1e54  vmovaps xmm11, [rsp+0xA0]
00007588ecdd1e5d  vmovaps xmm12, [rsp+0xB0]
00007588ecdd1e66  vmovaps xmm13, [rsp+0xC0]
00007588ecdd1e6f  vmovaps xmm14, [rsp+0xD0]
00007588ecdd1e78  vmovaps xmm15, [rsp+0xE0]
00007588ecdd1e81  add rsp, 0xF0
00007588ecdd1e88  pop r11
00007588ecdd1e8a  pop r10
00007588ecdd1e8c  pop r9
00007588ecdd1e8e  pop r8
00007588ecdd1e90  pop rsi
00007588ecdd1e91  pop rdi
00007588ecdd1e92  pop rdx
00007588ecdd1e93  pop rcx
00007588ecdd1e94  pop rax
00007588ecdd1e95  add rsp, 0x08
00007588ecdd1e99  jmp 0x00007588ECDD1B4E
00007588ecdd1e9e  call 0x00007588ECBFF540
00007588ecdd1ea3  jmp 0x00007588ECDD1B61
00007588ecdd1ea8  int3
00007588ecdd1ea9  nop [rax], eax
00007588ecdd1eb0  movaps xmm1, [r15+0x180]
00007588ecdd1eb8  vpmovqd xmm15, xmm1
00007588ecdd1ebe  pxor xmm14, xmm14
00007588ecdd1ec3  punpcklqdq xmm15, xmm14
00007588ecdd1ec8  movaps [r15+0x210], xmm15
00007588ecdd1ed0  movq xmm15, qword ptr [r15+0x140]
00007588ecdd1ed9  movq xmm14, qword ptr [r15+0x120]
00007588ecdd1ee2  psubd xmm15, xmm14
00007588ecdd1ee7  movq xmm15, xmm15
00007588ecdd1eec  movaps xmm13, [r15+0x170]
00007588ecdd1ef4  paddq xmm1, xmm13
00007588ecdd1ef9  movaps [r15+0x180], xmm1
00007588ecdd1f01  movq xmm1, qword ptr [r15+0x160]
00007588ecdd1f0a  paddd xmm14, xmm1
00007588ecdd1f0f  movq xmm14, xmm14
00007588ecdd1f14  movq xmm14, xmm14
00007588ecdd1f19  movaps [r15+0x120], xmm14
00007588ecdd1f21  pmovzxdq xmm15, xmm15
00007588ecdd1f27  psllq xmm15, 0x00
00007588ecdd1f2d  movq xmm1, qword ptr [r15+0x210]
00007588ecdd1f36  movq xmm14, qword ptr [r15+0x110]
00007588ecdd1f3f  paddd xmm1, xmm14
00007588ecdd1f44  movq xmm1, xmm1
00007588ecdd1f48  vcvtuqq2pd xmm15, xmm15
00007588ecdd1f4e  pmovzxdq xmm1, xmm1
00007588ecdd1f53  psllq xmm1, 0x00
00007588ecdd1f58  vcvtuqq2pd xmm1, xmm1
00007588ecdd1f5e  movaps xmm14, [r15+0x150]
00007588ecdd1f66  movaps xmm13, xmm15
00007588ecdd1f6a  mulpd xmm13, xmm14
00007588ecdd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd1f75  ptest xmm12, xmm12
00007588ecdd1f7b  jnz 0x00007588ECDD205E
00007588ecdd1f81  movaps [r15+0x220], xmm13
00007588ecdd1f89  mov rax, [r15+0x48]
00007588ecdd1f8d  mov r14, [r15+0x50]
00007588ecdd1f91  lea r12, [r14+rax*1]
00007588ecdd1f95  movups [r13+r12*1], xmm13
00007588ecdd1f9b  movaps xmm15, [r15+0x130]
00007588ecdd1fa3  movaps xmm14, xmm1
00007588ecdd1fa7  mulpd xmm14, xmm15
00007588ecdd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007588ecdd1fb2  ptest xmm13, xmm13
00007588ecdd1fb8  jnz 0x00007588ECDD21AC
00007588ecdd1fbe  movaps [r15+0x210], xmm14
00007588ecdd1fc6  mov r14, [r15+0x40]
00007588ecdd1fca  lea r12, [r14+rax*1]
00007588ecdd1fce  movups [r13+r12*1], xmm14
00007588ecdd1fd4  lea r14, [rax+0x10]
00007588ecdd1fd8  mov [r15+0x48], r14
00007588ecdd1fdc  xor eax, eax
00007588ecdd1fde  mov r12d, 0x200
00007588ecdd1fe4  cmp r14, r12
00007588ecdd1fe7  cmc
00007588ecdd1fe8  lahf
00007588ecdd1fe9  seto al
00007588ecdd1fec  mov [r15+0x108], eax
00007588ecdd1ff3  mov eax, [r15+0x108]
00007588ecdd1ffa  sahf
00007588ecdd1ffb  jnz 0x00007588ECDD202D
00007588ecdd1ffd  cmp dword ptr [r15+0x318], 0x00
00007588ecdd2005  jz 0x00007588ECDD2300
00007588ecdd200b  nop [rax+rax*1], ax
00007588ecdd2014  nop [rax+rax*1], eax
00007588ecdd201c  mov eax, 0x410480
00007588ecdd2021  mov [r15+0x100], rax
00007588ecdd2028  jmp 0x00007588ECBFE110
00007588ecdd202d  cmp dword ptr [r15+0x318], 0x00
00007588ecdd2035  jz 0x00007588ECDD1EB0
00007588ecdd203b  nop [rax+rax*1], ax
00007588ecdd2044  nop [rax+rax*1], eax
00007588ecdd204c  mov eax, 0x410440
00007588ecdd2051  mov [r15+0x100], rax
00007588ecdd2058  jmp 0x00007588ECBFE110
00007588ecdd205d  int3
00007588ecdd205e  sub rsp, 0x08
00007588ecdd2062  push rax
00007588ecdd2063  push rcx
00007588ecdd2064  push rdx
00007588ecdd2065  push rdi
00007588ecdd2066  push rsi
00007588ecdd2067  push r8
00007588ecdd2069  push r9
00007588ecdd206b  push r10
00007588ecdd206d  push r11
00007588ecdd206f  sub rsp, 0xF0
00007588ecdd2076  vmovaps [rsp], xmm0
00007588ecdd207b  vmovaps [rsp+0x10], xmm1
00007588ecdd2081  vmovaps [rsp+0x20], xmm2
00007588ecdd2087  vmovaps [rsp+0x30], xmm3
00007588ecdd208d  vmovaps [rsp+0x40], xmm4
00007588ecdd2093  vmovaps [rsp+0x50], xmm5
00007588ecdd2099  vmovaps [rsp+0x60], xmm6
00007588ecdd209f  vmovaps [rsp+0x70], xmm7
00007588ecdd20a5  vmovaps [rsp+0x80], xmm8
00007588ecdd20ae  vmovaps [rsp+0x90], xmm9
00007588ecdd20b7  vmovaps [rsp+0xA0], xmm10
00007588ecdd20c0  vmovaps [rsp+0xB0], xmm11
00007588ecdd20c9  vmovaps [rsp+0xC0], xmm12
00007588ecdd20d2  vmovaps [rsp+0xD0], xmm14
00007588ecdd20db  vmovaps [rsp+0xE0], xmm15
00007588ecdd20e4  sub rsp, 0x30
00007588ecdd20e8  movaps [rsp], xmm13
00007588ecdd20ed  movaps [rsp+0x10], xmm15
00007588ecdd20f3  movaps [rsp+0x20], xmm14
00007588ecdd20f9  lea rdi, [rsp]
00007588ecdd20fd  mov esi, 0x00
00007588ecdd2102  mov rax, 0x6516BF3BB530
00007588ecdd210c  call rax
00007588ecdd210e  movaps xmm13, [rsp]
00007588ecdd2113  add rsp, 0x30
00007588ecdd2117  vmovaps xmm0, [rsp]
00007588ecdd211c  vmovaps xmm1, [rsp+0x10]
00007588ecdd2122  vmovaps xmm2, [rsp+0x20]
00007588ecdd2128  vmovaps xmm3, [rsp+0x30]
00007588ecdd212e  vmovaps xmm4, [rsp+0x40]
00007588ecdd2134  vmovaps xmm5, [rsp+0x50]
00007588ecdd213a  vmovaps xmm6, [rsp+0x60]
00007588ecdd2140  vmovaps xmm7, [rsp+0x70]
00007588ecdd2146  vmovaps xmm8, [rsp+0x80]
00007588ecdd214f  vmovaps xmm9, [rsp+0x90]
00007588ecdd2158  vmovaps xmm10, [rsp+0xA0]
00007588ecdd2161  vmovaps xmm11, [rsp+0xB0]
00007588ecdd216a  vmovaps xmm12, [rsp+0xC0]
00007588ecdd2173  vmovaps xmm14, [rsp+0xD0]
00007588ecdd217c  vmovaps xmm15, [rsp+0xE0]
00007588ecdd2185  add rsp, 0xF0
00007588ecdd218c  pop r11
00007588ecdd218e  pop r10
00007588ecdd2190  pop r9
00007588ecdd2192  pop r8
00007588ecdd2194  pop rsi
00007588ecdd2195  pop rdi
00007588ecdd2196  pop rdx
00007588ecdd2197  pop rcx
00007588ecdd2198  pop rax
00007588ecdd2199  add rsp, 0x08
00007588ecdd219d  jmp 0x00007588ECDD1F81
00007588ecdd21a2  call 0x00007588ECCC2240
00007588ecdd21a7  jmp 0x00007588ECDD1F9B
00007588ecdd21ac  sub rsp, 0x08
00007588ecdd21b0  push rax
00007588ecdd21b1  push rcx
00007588ecdd21b2  push rdx
00007588ecdd21b3  push rdi
00007588ecdd21b4  push rsi
00007588ecdd21b5  push r8
00007588ecdd21b7  push r9
00007588ecdd21b9  push r10
00007588ecdd21bb  push r11
00007588ecdd21bd  sub rsp, 0xF0
00007588ecdd21c4  vmovaps [rsp], xmm0
00007588ecdd21c9  vmovaps [rsp+0x10], xmm1
00007588ecdd21cf  vmovaps [rsp+0x20], xmm2
00007588ecdd21d5  vmovaps [rsp+0x30], xmm3
00007588ecdd21db  vmovaps [rsp+0x40], xmm4
00007588ecdd21e1  vmovaps [rsp+0x50], xmm5
00007588ecdd21e7  vmovaps [rsp+0x60], xmm6
00007588ecdd21ed  vmovaps [rsp+0x70], xmm7
00007588ecdd21f3  vmovaps [rsp+0x80], xmm8
00007588ecdd21fc  vmovaps [rsp+0x90], xmm9
00007588ecdd2205  vmovaps [rsp+0xA0], xmm10
00007588ecdd220e  vmovaps [rsp+0xB0], xmm11
00007588ecdd2217  vmovaps [rsp+0xC0], xmm12
00007588ecdd2220  vmovaps [rsp+0xD0], xmm13
00007588ecdd2229  vmovaps [rsp+0xE0], xmm15
00007588ecdd2232  sub rsp, 0x30
00007588ecdd2236  movaps [rsp], xmm14
00007588ecdd223b  movaps [rsp+0x10], xmm1
00007588ecdd2240  movaps [rsp+0x20], xmm15
00007588ecdd2246  lea rdi, [rsp]
00007588ecdd224a  mov esi, 0x00
00007588ecdd224f  mov rax, 0x6516BF3BB530
00007588ecdd2259  call rax
00007588ecdd225b  movaps xmm14, [rsp]
00007588ecdd2260  add rsp, 0x30
00007588ecdd2264  vmovaps xmm0, [rsp]
00007588ecdd2269  vmovaps xmm1, [rsp+0x10]
00007588ecdd226f  vmovaps xmm2, [rsp+0x20]
00007588ecdd2275  vmovaps xmm3, [rsp+0x30]
00007588ecdd227b  vmovaps xmm4, [rsp+0x40]
00007588ecdd2281  vmovaps xmm5, [rsp+0x50]
00007588ecdd2287  vmovaps xmm6, [rsp+0x60]
00007588ecdd228d  vmovaps xmm7, [rsp+0x70]
00007588ecdd2293  vmovaps xmm8, [rsp+0x80]
00007588ecdd229c  vmovaps xmm9, [rsp+0x90]
00007588ecdd22a5  vmovaps xmm10, [rsp+0xA0]
00007588ecdd22ae  vmovaps xmm11, [rsp+0xB0]
00007588ecdd22b7  vmovaps xmm12, [rsp+0xC0]
00007588ecdd22c0  vmovaps xmm13, [rsp+0xD0]
00007588ecdd22c9  vmovaps xmm15, [rsp+0xE0]
00007588ecdd22d2  add rsp, 0xF0
00007588ecdd22d9  pop r11
00007588ecdd22db  pop r10
00007588ecdd22dd  pop r9
00007588ecdd22df  pop r8
00007588ecdd22e1  pop rsi
00007588ecdd22e2  pop rdi
00007588ecdd22e3  pop rdx
00007588ecdd22e4  pop rcx
00007588ecdd22e5  pop rax
00007588ecdd22e6  add rsp, 0x08
00007588ecdd22ea  jmp 0x00007588ECDD1FBE
00007588ecdd22ef  call 0x00007588ECCC34C0
00007588ecdd22f4  jmp 0x00007588ECDD1FD4
00007588ecdd22f9  int3
00007588ecdd22fa  nop [rax+rax*1], ax
00007588ecdd2300  mov rax, [r15+0x50]
00007588ecdd2304  movups xmm1, [r13+rax*1]
00007588ecdd230a  lea r14, [rax+0x10]
00007588ecdd230e  movups xmm15, [r13+r14*1]
00007588ecdd2314  mov qword ptr [r15+0x48], 0x00
00007588ecdd231c  lea r14, [rax+0x40]
00007588ecdd2320  movups xmm14, [r13+r14*1]
00007588ecdd2326  lea r14, [rax+0x50]
00007588ecdd232a  movups xmm13, [r13+r14*1]
00007588ecdd2330  lea r14, [rax+0x80]
00007588ecdd2337  movups xmm12, [r13+r14*1]
00007588ecdd233d  lea r14, [rax+0x90]
00007588ecdd2344  movups xmm11, [r13+r14*1]
00007588ecdd234a  mov r14, [r15+0xF8]
00007588ecdd2351  movups [r13+r14*1], xmm1
00007588ecdd2357  lea r12, [rax+0x20]
00007588ecdd235b  movups xmm1, [r13+r12*1]
00007588ecdd2361  lea r12, [rax+0x30]
00007588ecdd2365  movups xmm10, [r13+r12*1]
00007588ecdd236b  lea r12, [rax+0xC0]
00007588ecdd2372  movups xmm9, [r13+r12*1]
00007588ecdd2378  lea r12, [rax+0xD0]
00007588ecdd237f  movups xmm8, [r13+r12*1]
00007588ecdd2385  lea r12, [rax+0x100]
00007588ecdd238c  movups xmm7, [r13+r12*1]
00007588ecdd2392  lea r12, [rax+0x110]
00007588ecdd2399  movups xmm6, [r13+r12*1]
00007588ecdd239f  lea r12, [rax+0x140]
00007588ecdd23a6  movups xmm5, [r13+r12*1]
00007588ecdd23ac  lea r12, [rax+0x150]
00007588ecdd23b3  movups xmm4, [r13+r12*1]
00007588ecdd23b9  lea r12, [r14+0xB0]
00007588ecdd23c0  movups [r13+r12*1], xmm10
00007588ecdd23c6  lea r12, [r14+0xC0]
00007588ecdd23cd  movups [r13+r12*1], xmm1
00007588ecdd23d3  lea r12, [rax+0x180]
00007588ecdd23da  movups xmm1, [r13+r12*1]
00007588ecdd23e0  lea r12, [rax+0x190]
00007588ecdd23e7  movups xmm10, [r13+r12*1]
00007588ecdd23ed  lea r12, [rax+0x1C0]
00007588ecdd23f4  movups xmm3, [r13+r12*1]
00007588ecdd23fa  lea r12, [rax+0x1D0]
00007588ecdd2401  movups xmm2, [r13+r12*1]
00007588ecdd2407  lea r12, [rax+0x60]
00007588ecdd240b  vmovaps [rsp+0x10], xmm1
00007588ecdd2411  movups xmm1, [r13+r12*1]
00007588ecdd2417  lea r12, [rax+0x70]
00007588ecdd241b  vmovaps [rsp+0x20], xmm1
00007588ecdd2421  movups xmm1, [r13+r12*1]
00007588ecdd2427  lea r12, [r14+0x70]
00007588ecdd242b  movups [r13+r12*1], xmm10
00007588ecdd2431  lea r12, [r14+0x80]
00007588ecdd2438  vmovaps xmm10, [rsp+0x10]
00007588ecdd243e  movups [r13+r12*1], xmm10
00007588ecdd2444  lea r12, [rax+0xA0]
00007588ecdd244b  movups xmm10, [r13+r12*1]
00007588ecdd2451  lea r12, [rax+0xB0]
00007588ecdd2458  vmovaps [rsp+0x10], xmm1
00007588ecdd245e  movups xmm1, [r13+r12*1]
00007588ecdd2464  lea r12, [r14+0x90]
00007588ecdd246b  movups [r13+r12*1], xmm2
00007588ecdd2471  lea r12, [r14+0xA0]
00007588ecdd2478  movups [r13+r12*1], xmm3
00007588ecdd247e  lea r12, [rax+0xE0]
00007588ecdd2485  movups xmm3, [r13+r12*1]
00007588ecdd248b  lea r12, [rax+0xF0]
00007588ecdd2492  movups xmm2, [r13+r12*1]
00007588ecdd2498  lea r12, [rax+0x120]
00007588ecdd249f  vmovaps [rsp+0x30], xmm1
00007588ecdd24a5  movups xmm1, [r13+r12*1]
00007588ecdd24ab  lea r12, [rax+0x130]
00007588ecdd24b2  vmovaps [rsp+0x40], xmm1
00007588ecdd24b8  movups xmm1, [r13+r12*1]
00007588ecdd24be  vmovaps [rsp+0x50], xmm1
00007588ecdd24c4  vmovaps xmm1, [rsp+0x40]
00007588ecdd24ca  movaps [r15+0x190], xmm1
00007588ecdd24d2  lea r12, [rax+0x160]
00007588ecdd24d9  vmovaps [rsp+0x40], xmm1
00007588ecdd24df  movups xmm1, [r13+r12*1]
00007588ecdd24e5  lea r12, [rax+0x170]
00007588ecdd24ec  vmovaps [rsp+0x60], xmm1
00007588ecdd24f2  movups xmm1, [r13+r12*1]
00007588ecdd24f8  lea r12, [rax+0x1A0]
00007588ecdd24ff  vmovaps [rsp+0x70], xmm1
00007588ecdd2505  movups xmm1, [r13+r12*1]
00007588ecdd250b  lea r12, [rax+0x1B0]
00007588ecdd2512  vmovaps [rsp+0x80], xmm1
00007588ecdd251b  movups xmm1, [r13+r12*1]
00007588ecdd2521  lea r12, [rax+0x1E0]
00007588ecdd2528  vmovaps [rsp+0x90], xmm1
00007588ecdd2531  movups xmm1, [r13+r12*1]
00007588ecdd2537  lea r12, [rax+0x1F0]
00007588ecdd253e  vmovaps [rsp+0xA0], xmm1
00007588ecdd2547  movups xmm1, [r13+r12*1]
00007588ecdd254d  mov qword ptr [r15+0x50], 0x432190
00007588ecdd2555  lea rax, [r14+0x50]
00007588ecdd2559  vmovaps [rsp+0xB0], xmm1
00007588ecdd2562  vmovaps xmm1, [rsp+0x60]
00007588ecdd2568  movups [r13+rax*1], xmm1
00007588ecdd256e  lea rax, [r14+0x60]
00007588ecdd2572  movups [r13+rax*1], xmm5
00007588ecdd2578  lea rax, [r14+0x40]
00007588ecdd257c  vmovaps xmm1, [rsp+0x70]
00007588ecdd2582  movups [r13+rax*1], xmm1
00007588ecdd2588  lea rax, [r14+0x20]
00007588ecdd258c  vmovaps xmm1, [rsp+0xA0]
00007588ecdd2595  movups [r13+rax*1], xmm1
00007588ecdd259b  lea rax, [r14+0x30]
00007588ecdd259f  vmovaps xmm1, [rsp+0x90]
00007588ecdd25a8  movups [r13+rax*1], xmm1
00007588ecdd25ae  lea rax, [r14+0x10]
00007588ecdd25b2  vmovaps xmm1, [rsp+0xB0]
00007588ecdd25bb  movups [r13+rax*1], xmm1
00007588ecdd25c1  mov rax, [r15+0x40]
00007588ecdd25c5  vxorps xmm1, xmm1, xmm1
00007588ecdd25c9  vpbroadcastq xmm1, xmm1
00007588ecdd25ce  vxorps xmm5, xmm5, xmm5
00007588ecdd25d2  vpbroadcastq xmm5, xmm5
00007588ecdd25d7  lea r12, [rax+0x30]
00007588ecdd25db  mov r11, [r13+r12*1]
00007588ecdd25e0  lea r12, [rax+0x38]
00007588ecdd25e4  mov r10, [r13+r12*1]
00007588ecdd25e9  vmovaps [rsp+0x60], xmm1
00007588ecdd25ef  movq xmm1, r11
00007588ecdd25f4  vmovaps [rsp+0x70], xmm1
00007588ecdd25fa  movq xmm1, r10
00007588ecdd25ff  vmovaps [rsp+0x90], xmm1
00007588ecdd2608  vmovaps xmm1, [rsp+0x70]
00007588ecdd260e  movq xmm1, xmm1
00007588ecdd2612  vmovaps [rsp+0x70], xmm1
00007588ecdd2618  vmovaps xmm1, [rsp+0x90]
00007588ecdd2621  movq xmm1, xmm1
00007588ecdd2625  vmovaps [rsp+0x90], xmm1
00007588ecdd262e  movq xmm1, xmm1
00007588ecdd2632  movaps [r15+0x270], xmm1
00007588ecdd263a  vmovaps [rsp+0xA0], xmm7
00007588ecdd2643  vmovaps xmm1, [rsp+0xA0]
00007588ecdd264c  por xmm7, xmm1
00007588ecdd2650  lea r12, [rax+0x20]
00007588ecdd2654  mov r11, [r13+r12*1]
00007588ecdd2659  lea r12, [rax+0x28]
00007588ecdd265d  mov r10, [r13+r12*1]
00007588ecdd2662  movq xmm1, r11
00007588ecdd2667  vmovaps [rsp+0xA0], xmm1
00007588ecdd2670  movq xmm1, r10
00007588ecdd2675  vmovaps [rsp+0xB0], xmm1
00007588ecdd267e  vmovaps xmm1, [rsp+0xA0]
00007588ecdd2687  movq xmm1, xmm1
00007588ecdd268b  vmovaps [rsp+0xA0], xmm1
00007588ecdd2694  vmovaps xmm1, [rsp+0xB0]
00007588ecdd269d  movq xmm1, xmm1
00007588ecdd26a1  vmovaps [rsp+0xB0], xmm2
00007588ecdd26aa  vmovaps [rsp+0xC0], xmm1
00007588ecdd26b3  vmovaps xmm1, [rsp+0xB0]
00007588ecdd26bc  por xmm2, xmm1
00007588ecdd26c0  vmovaps [rsp+0xB0], xmm3
00007588ecdd26c9  vmovaps xmm1, [rsp+0xB0]
00007588ecdd26d2  por xmm3, xmm1
00007588ecdd26d6  vmovaps [rsp+0xB0], xmm4
00007588ecdd26df  vmovaps xmm1, [rsp+0xB0]
00007588ecdd26e8  por xmm4, xmm1
00007588ecdd26ec  vmovaps [rsp+0xB0], xmm9
00007588ecdd26f5  vmovaps xmm1, [rsp+0xB0]
00007588ecdd26fe  por xmm9, xmm1
00007588ecdd2703  lea r12, [rax+0x10]
00007588ecdd2707  mov r11, [r13+r12*1]
00007588ecdd270c  lea r12, [rax+0x18]
00007588ecdd2710  mov r10, [r13+r12*1]
00007588ecdd2715  movq xmm1, r11
00007588ecdd271a  vmovaps [rsp+0xB0], xmm1
00007588ecdd2723  movq xmm1, r10
00007588ecdd2728  vmovaps [rsp+0xD0], xmm1
00007588ecdd2731  vmovaps xmm1, [rsp+0xB0]
00007588ecdd273a  movq xmm1, xmm1
00007588ecdd273e  vmovaps [rsp+0xB0], xmm1
00007588ecdd2747  vmovaps xmm1, [rsp+0xD0]
00007588ecdd2750  movq xmm1, xmm1
00007588ecdd2754  vmovaps [rsp+0xD0], xmm1
00007588ecdd275d  vmovaps xmm1, [rsp+0x80]
00007588ecdd2766  vmovaps [rsp+0xE0], xmm15
00007588ecdd276f  vmovaps xmm15, [rsp+0x80]
00007588ecdd2778  por xmm1, xmm15
00007588ecdd277d  vmovaps xmm15, [rsp+0x10]
00007588ecdd2783  vmovaps [rsp+0x80], xmm1
00007588ecdd278c  vmovaps xmm1, [rsp+0x10]
00007588ecdd2792  por xmm15, xmm1
00007588ecdd2797  vmovaps xmm1, [rsp+0x20]
00007588ecdd279d  vmovaps [rsp+0x10], xmm15
00007588ecdd27a3  vmovaps xmm15, [rsp+0x20]
00007588ecdd27a9  por xmm1, xmm15
00007588ecdd27ae  vmovaps [rsp+0x20], xmm6
00007588ecdd27b4  vmovaps xmm15, [rsp+0x20]
00007588ecdd27ba  por xmm6, xmm15
00007588ecdd27bf  vmovaps [rsp+0x20], xmm11
00007588ecdd27c5  vmovaps xmm15, [rsp+0x20]
00007588ecdd27cb  por xmm11, xmm15
00007588ecdd27d0  vmovaps [rsp+0x20], xmm13
00007588ecdd27d6  vmovaps xmm15, [rsp+0x20]
00007588ecdd27dc  por xmm13, xmm15
00007588ecdd27e1  vmovaps [rsp+0x20], xmm14
00007588ecdd27e7  vmovaps xmm15, [rsp+0x20]
00007588ecdd27ed  por xmm14, xmm15
00007588ecdd27f2  mov r12, [r13+rax*1]
00007588ecdd27f7  vmovq xmm15, r12
00007588ecdd27fc  vpbroadcastq xmm15, xmm15
00007588ecdd2801  vmovaps [rsp+0x20], xmm1
00007588ecdd2807  vxorps xmm1, xmm1, xmm1
00007588ecdd280b  vpbroadcastq xmm1, xmm1
00007588ecdd2810  vmovaps [rsp+0xF0], xmm1
00007588ecdd2819  movups xmm1, [r13+r14*1]
00007588ecdd281f  vmovaps [rsp+0x100], xmm1
00007588ecdd2828  vxorps xmm1, xmm1, xmm1
00007588ecdd282c  vpbroadcastq xmm1, xmm1
00007588ecdd2831  lea r12, [rax+0x08]
00007588ecdd2835  mov rax, [r13+r12*1]
00007588ecdd283a  vmovaps [rsp+0x110], xmm1
00007588ecdd2843  movq xmm1, rax
00007588ecdd2848  movaps [r15+0x240], xmm1
00007588ecdd2850  mov qword ptr [r15+0x60], 0x432190
00007588ecdd2858  mov qword ptr [r15+0x58], 0x40
00007588ecdd2860  vmovaps xmm1, [rsp+0x60]
00007588ecdd2866  vmovaps [rsp+0x60], xmm15
00007588ecdd286c  vmovaps xmm15, [rsp+0x100]
00007588ecdd2875  vmovaps [rsp+0x100], xmm14
00007588ecdd287e  vmovaps xmm14, [rsp+0x60]
00007588ecdd2884  vmovaps [rsp+0x60], xmm13
00007588ecdd288a  vmovaps [rsp+0x120], xmm12
00007588ecdd2893  movaps xmm13, xmm1
00007588ecdd2897  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd28a2  vptest xmm12, xmm12
00007588ecdd28a7  jnz 0x00007588ECDD3482
00007588ecdd28ad  vmovaps xmm1, [rsp+0xE0]
00007588ecdd28b6  movaps xmm15, xmm5
00007588ecdd28ba  vfmadd231pd xmm15, xmm1, xmm14
00007588ecdd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007588ecdd28c5  vptest xmm12, xmm12
00007588ecdd28ca  jnz 0x00007588ECDD35DB
00007588ecdd28d0  vmovaps xmm12, [rsp+0x50]
00007588ecdd28d6  vmovaps xmm5, [rsp+0x50]
00007588ecdd28dc  por xmm12, xmm5
00007588ecdd28e1  vmovaps xmm5, [rsp+0x30]
00007588ecdd28e7  vmovaps [rsp+0x50], xmm1
00007588ecdd28ed  vmovaps xmm1, [rsp+0x30]
00007588ecdd28f3  por xmm5, xmm1
00007588ecdd28f7  vmovaps [rsp+0x30], xmm10
00007588ecdd28fd  vmovaps xmm1, [rsp+0x30]
00007588ecdd2903  por xmm10, xmm1
00007588ecdd2908  vmovaps [rsp+0x30], xmm8
00007588ecdd290e  vmovaps xmm1, [rsp+0x30]
00007588ecdd2914  por xmm8, xmm1
00007588ecdd2919  vmovaps xmm1, [rsp+0x120]
00007588ecdd2922  vmovaps [rsp+0x30], xmm15
00007588ecdd2928  vmovaps xmm15, [rsp+0x120]
00007588ecdd2931  por xmm1, xmm15
00007588ecdd2936  vmovaps xmm15, [rsp+0x50]
00007588ecdd293c  vmovaps [rsp+0xE0], xmm1
00007588ecdd2945  vmovaps xmm1, [rsp+0x50]
00007588ecdd294b  por xmm15, xmm1
00007588ecdd2950  lea rax, [r14+0xC0]
00007588ecdd2957  movups xmm1, [r13+rax*1]
00007588ecdd295d  xor eax, eax
00007588ecdd295f  mov r12d, 0x40
00007588ecdd2965  mov r11d, 0x200
00007588ecdd296b  cmp r12, r11
00007588ecdd296e  cmc
00007588ecdd296f  lahf
00007588ecdd2970  seto al
00007588ecdd2973  mov [r15+0x108], eax
00007588ecdd297a  vmovaps [rsp+0x50], xmm1
00007588ecdd2980  vmovaps xmm1, [rsp+0xF0]
00007588ecdd2989  vmovaps [rsp+0xF0], xmm15
00007588ecdd2992  vmovaps xmm15, [rsp+0x50]
00007588ecdd2998  vmovaps [rsp+0x50], xmm13
00007588ecdd299e  vmovaps [rsp+0x120], xmm12
00007588ecdd29a7  movaps xmm13, xmm1
00007588ecdd29ab  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd29b6  vptest xmm12, xmm12
00007588ecdd29bb  jnz 0x00007588ECDD373D
00007588ecdd29c1  lea rax, [r14+0xB0]
00007588ecdd29c8  movups xmm1, [r13+rax*1]
00007588ecdd29ce  vmovaps xmm15, [rsp+0x110]
00007588ecdd29d7  vmovaps [rsp+0x110], xmm13
00007588ecdd29e0  movaps xmm12, xmm15
00007588ecdd29e4  vfmadd231pd xmm12, xmm1, xmm14
00007588ecdd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007588ecdd29ef  vptest xmm13, xmm13
00007588ecdd29f4  jnz 0x00007588ECDD38A0
00007588ecdd29fa  vmovaps xmm1, [rsp+0x100]
00007588ecdd2a03  vmovaps xmm15, [rsp+0x100]
00007588ecdd2a0c  por xmm1, xmm15
00007588ecdd2a11  movaps [r15+0x210], xmm1
00007588ecdd2a19  vmovaps xmm15, [rsp+0x60]
00007588ecdd2a1f  vmovaps xmm14, [rsp+0x60]
00007588ecdd2a25  por xmm15, xmm14
00007588ecdd2a2a  movaps [r15+0x1C0], xmm15
00007588ecdd2a32  vmovaps [rsp+0x60], xmm11
00007588ecdd2a38  vmovaps xmm14, [rsp+0x60]
00007588ecdd2a3e  por xmm11, xmm14
00007588ecdd2a43  movaps [r15+0x280], xmm11
00007588ecdd2a4b  vmovaps [rsp+0x60], xmm6
00007588ecdd2a51  vmovaps xmm14, [rsp+0x60]
00007588ecdd2a57  por xmm6, xmm14
00007588ecdd2a5c  movaps [r15+0x2A0], xmm6
00007588ecdd2a64  vmovaps xmm14, [rsp+0x20]
00007588ecdd2a6a  vmovaps xmm13, [rsp+0x20]
00007588ecdd2a70  por xmm14, xmm13
00007588ecdd2a75  movaps [r15+0x2E0], xmm14
00007588ecdd2a7d  vmovaps xmm13, [rsp+0x10]
00007588ecdd2a83  vmovaps [rsp+0x20], xmm1
00007588ecdd2a89  vmovaps xmm1, [rsp+0x10]
00007588ecdd2a8f  por xmm13, xmm1
00007588ecdd2a94  movaps [r15+0x1F0], xmm13
00007588ecdd2a9c  vmovaps xmm1, [rsp+0xF0]
00007588ecdd2aa5  vmovaps [rsp+0x10], xmm15
00007588ecdd2aab  vmovaps xmm15, [rsp+0xF0]
00007588ecdd2ab4  por xmm1, xmm15
00007588ecdd2ab9  movaps [r15+0x250], xmm1
00007588ecdd2ac1  vmovaps xmm1, [rsp+0xE0]
00007588ecdd2aca  vmovaps xmm15, [rsp+0xE0]
00007588ecdd2ad3  por xmm1, xmm15
00007588ecdd2ad8  movaps [r15+0x260], xmm1
00007588ecdd2ae0  vmovaps [rsp+0x60], xmm8
00007588ecdd2ae6  vmovaps xmm15, [rsp+0x60]
00007588ecdd2aec  por xmm8, xmm15
00007588ecdd2af1  movaps [r15+0x290], xmm8
00007588ecdd2af9  vmovaps [rsp+0x60], xmm10
00007588ecdd2aff  vmovaps xmm15, [rsp+0x60]
00007588ecdd2b05  por xmm10, xmm15
00007588ecdd2b0a  movaps [r15+0x2C0], xmm10
00007588ecdd2b12  movq xmm15, qword ptr [r15+0x240]
00007588ecdd2b1b  vmovaps [rsp+0x60], xmm15
00007588ecdd2b21  vpermilpd xmm15, xmm15, 0x00
00007588ecdd2b27  vmovaps [rsp+0xE0], xmm1
00007588ecdd2b30  vmovaps xmm1, [rsp+0x50]
00007588ecdd2b36  vmovaps [rsp+0x50], xmm15
00007588ecdd2b3c  vmovaps xmm15, [rsp+0x20]
00007588ecdd2b42  vmovaps [rsp+0x20], xmm14
00007588ecdd2b48  vmovaps xmm14, [rsp+0x50]
00007588ecdd2b4e  vmovaps [rsp+0x50], xmm13
00007588ecdd2b54  vmovaps [rsp+0xF0], xmm12
00007588ecdd2b5d  movaps xmm13, xmm1
00007588ecdd2b61  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd2b6c  vptest xmm12, xmm12
00007588ecdd2b71  jnz 0x00007588ECDD39F9
00007588ecdd2b77  vmovaps xmm1, [rsp+0x60]
00007588ecdd2b7d  vpermilpd xmm1, xmm1, 0x00
00007588ecdd2b83  vmovaps xmm15, [rsp+0x110]
00007588ecdd2b8c  vmovaps xmm14, [rsp+0x20]
00007588ecdd2b92  vmovaps [rsp+0x20], xmm13
00007588ecdd2b98  movaps xmm12, xmm15
00007588ecdd2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007588ecdd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007588ecdd2ba7  vptest xmm13, xmm13
00007588ecdd2bac  jnz 0x00007588ECDD3B52
00007588ecdd2bb2  vmovaps xmm1, [rsp+0x60]
00007588ecdd2bb8  vpermilpd xmm1, xmm1, 0x00
00007588ecdd2bbe  vmovaps xmm15, [rsp+0x30]
00007588ecdd2bc4  vmovaps xmm14, [rsp+0x10]
00007588ecdd2bca  vmovaps [rsp+0x10], xmm12
00007588ecdd2bd0  movaps xmm13, xmm15
00007588ecdd2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007588ecdd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd2bdf  vptest xmm12, xmm12
00007588ecdd2be4  jnz 0x00007588ECDD3CAB
00007588ecdd2bea  vmovaps [rsp+0x30], xmm5
00007588ecdd2bf0  vmovaps xmm1, [rsp+0x30]
00007588ecdd2bf6  por xmm5, xmm1
00007588ecdd2bfa  movaps [r15+0x1D0], xmm5
00007588ecdd2c02  vmovaps xmm1, [rsp+0x60]
00007588ecdd2c08  vpermilpd xmm1, xmm1, 0x00
00007588ecdd2c0e  vmovaps xmm15, [rsp+0xF0]
00007588ecdd2c17  vmovaps xmm14, [rsp+0x50]
00007588ecdd2c1d  vmovaps [rsp+0x30], xmm13
00007588ecdd2c23  movaps xmm12, xmm15
00007588ecdd2c27  vfmadd231pd xmm12, xmm14, xmm1
00007588ecdd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007588ecdd2c32  vptest xmm13, xmm13
00007588ecdd2c37  jnz 0x00007588ECDD3E04
00007588ecdd2c3d  vmovaps xmm1, [rsp+0x80]
00007588ecdd2c46  vmovaps xmm15, [rsp+0x80]
00007588ecdd2c4f  por xmm1, xmm15
00007588ecdd2c54  movaps [r15+0x200], xmm1
00007588ecdd2c5c  vmovaps xmm15, [rsp+0x120]
00007588ecdd2c65  vmovaps xmm14, [rsp+0x120]
00007588ecdd2c6e  por xmm15, xmm14
00007588ecdd2c73  movaps [r15+0x1E0], xmm15
00007588ecdd2c7b  vmovaps [rsp+0x50], xmm4
00007588ecdd2c81  vmovaps xmm13, [rsp+0x50]
00007588ecdd2c87  por xmm4, xmm13
00007588ecdd2c8c  movaps [r15+0x2B0], xmm4
00007588ecdd2c94  vmovaps [rsp+0x50], xmm3
00007588ecdd2c9a  vmovaps xmm13, [rsp+0x50]
00007588ecdd2ca0  por xmm3, xmm13
00007588ecdd2ca5  movaps [r15+0x300], xmm3
00007588ecdd2cad  vmovaps xmm15, [rsp+0xB0]
00007588ecdd2cb6  vpermilpd xmm15, xmm15, 0x00
00007588ecdd2cbc  vmovaps xmm3, [rsp+0x20]
00007588ecdd2cc2  vmovaps [rsp+0x20], xmm1
00007588ecdd2cc8  vmovaps xmm1, [rsp+0xE0]
00007588ecdd2cd1  vmovaps [rsp+0x50], xmm14
00007588ecdd2cd7  vmovaps [rsp+0x60], xmm13
00007588ecdd2cdd  movaps xmm14, xmm3
00007588ecdd2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007588ecdd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007588ecdd2cec  vptest xmm13, xmm13
00007588ecdd2cf1  jnz 0x00007588ECDD3F5D
00007588ecdd2cf7  vmovaps xmm1, [rsp+0xB0]
00007588ecdd2d00  vpermilpd xmm1, xmm1, 0x00
00007588ecdd2d06  vmovaps xmm15, [rsp+0x10]
00007588ecdd2d0c  movaps xmm13, xmm15
00007588ecdd2d10  vfmadd231pd xmm13, xmm10, xmm1
00007588ecdd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007588ecdd2d1b  vptest xmm3, xmm3
00007588ecdd2d20  jnz 0x00007588ECDD40B5
00007588ecdd2d26  vmovaps xmm1, [rsp+0xB0]
00007588ecdd2d2f  vpermilpd xmm1, xmm1, 0x00
00007588ecdd2d35  vmovaps xmm15, [rsp+0x30]
00007588ecdd2d3b  movaps xmm10, xmm15
00007588ecdd2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007588ecdd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007588ecdd2d4a  vptest xmm3, xmm3
00007588ecdd2d4f  jnz 0x00007588ECDD420E
00007588ecdd2d55  vmovaps xmm1, [rsp+0xB0]
00007588ecdd2d5e  vpermilpd xmm1, xmm1, 0x00
00007588ecdd2d64  movaps xmm15, xmm12
00007588ecdd2d68  vfmadd231pd xmm15, xmm5, xmm1
00007588ecdd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007588ecdd2d73  vptest xmm11, xmm11
00007588ecdd2d78  jnz 0x00007588ECDD4367
00007588ecdd2d7e  vmovaps [rsp+0x10], xmm9
00007588ecdd2d84  vmovaps xmm1, [rsp+0x10]
00007588ecdd2d8a  por xmm9, xmm1
00007588ecdd2d8f  movaps [r15+0x180], xmm9
00007588ecdd2d97  vmovaps [rsp+0x10], xmm2
00007588ecdd2d9d  vmovaps xmm1, [rsp+0x10]
00007588ecdd2da3  por xmm2, xmm1
00007588ecdd2da7  movaps [r15+0x2D0], xmm2
00007588ecdd2daf  vmovaps xmm12, [rsp+0xD0]
00007588ecdd2db8  vpermilpd xmm12, xmm12, 0x00
00007588ecdd2dbe  vmovaps xmm11, [rsp+0x60]
00007588ecdd2dc4  movaps xmm5, xmm13
00007588ecdd2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007588ecdd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007588ecdd2dd2  vptest xmm3, xmm3
00007588ecdd2dd7  jnz 0x00007588ECDD44BF
00007588ecdd2ddd  vmovaps xmm13, [rsp+0xD0]
00007588ecdd2de6  vpermilpd xmm13, xmm13, 0x00
00007588ecdd2dec  movaps xmm12, xmm14
00007588ecdd2df0  vfmadd231pd xmm12, xmm9, xmm13
00007588ecdd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007588ecdd2dfb  vptest xmm11, xmm11
00007588ecdd2e00  jnz 0x00007588ECDD4617
00007588ecdd2e06  lea rax, [r14+0x80]
00007588ecdd2e0d  movups xmm14, [r13+rax*1]
00007588ecdd2e13  movaps [r15+0x2F0], xmm14
00007588ecdd2e1b  vmovaps xmm13, [rsp+0xD0]
00007588ecdd2e24  vpermilpd xmm13, xmm13, 0x00
00007588ecdd2e2a  movaps xmm11, xmm10
00007588ecdd2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007588ecdd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007588ecdd2e39  vptest xmm9, xmm9
00007588ecdd2e3e  jnz 0x00007588ECDD477B
00007588ecdd2e44  vmovaps xmm13, [rsp+0xD0]
00007588ecdd2e4d  vpermilpd xmm13, xmm13, 0x00
00007588ecdd2e53  movaps xmm10, xmm15
00007588ecdd2e57  vfmadd231pd xmm10, xmm1, xmm13
00007588ecdd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007588ecdd2e62  vptest xmm9, xmm9
00007588ecdd2e67  jnz 0x00007588ECDD48D5
00007588ecdd2e6d  vmovaps [rsp+0x10], xmm7
00007588ecdd2e73  vmovaps xmm1, [rsp+0x10]
00007588ecdd2e79  por xmm7, xmm1
00007588ecdd2e7d  movaps [r15+0x160], xmm7
00007588ecdd2e85  lea rax, [r14+0x40]
00007588ecdd2e89  movups xmm1, [r13+rax*1]
00007588ecdd2e8f  lea rax, [r14+0x50]
00007588ecdd2e93  movups xmm15, [r13+rax*1]
00007588ecdd2e99  movaps [r15+0x1B0], xmm1
00007588ecdd2ea1  movaps [r15+0x1A0], xmm15
00007588ecdd2ea9  vmovaps xmm13, [rsp+0xA0]
00007588ecdd2eb2  vpermilpd xmm13, xmm13, 0x00
00007588ecdd2eb8  vmovaps xmm9, [rsp+0x40]
00007588ecdd2ebe  movaps xmm8, xmm5
00007588ecdd2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007588ecdd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007588ecdd2ecd  vptest xmm3, xmm3
00007588ecdd2ed2  jnz 0x00007588ECDD4A42
00007588ecdd2ed8  vmovaps xmm13, [rsp+0xA0]
00007588ecdd2ee1  vpermilpd xmm13, xmm13, 0x00
00007588ecdd2ee7  movaps xmm9, xmm12
00007588ecdd2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007588ecdd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007588ecdd2ef6  vptest xmm5, xmm5
00007588ecdd2efb  jnz 0x00007588ECDD4B9B
00007588ecdd2f01  vmovaps xmm13, [rsp+0xA0]
00007588ecdd2f0a  vpermilpd xmm13, xmm13, 0x00
00007588ecdd2f10  movaps xmm12, xmm11
00007588ecdd2f14  vfmadd231pd xmm12, xmm6, xmm13
00007588ecdd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007588ecdd2f1f  vptest xmm7, xmm7
00007588ecdd2f24  jnz 0x00007588ECDD4CF4
00007588ecdd2f2a  vmovaps xmm13, [rsp+0xA0]
00007588ecdd2f33  vpermilpd xmm13, xmm13, 0x00
00007588ecdd2f39  vmovaps xmm11, [rsp+0x50]
00007588ecdd2f3f  movaps xmm7, xmm10
00007588ecdd2f43  vfmadd231pd xmm7, xmm11, xmm13
00007588ecdd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007588ecdd2f4d  vptest xmm6, xmm6
00007588ecdd2f52  jnz 0x00007588ECDD4E4D
00007588ecdd2f58  lea rax, [r14+0x60]
00007588ecdd2f5c  movups xmm13, [r13+rax*1]
00007588ecdd2f62  lea rax, [r14+0x70]
00007588ecdd2f66  movups xmm11, [r13+rax*1]
00007588ecdd2f6c  movaps [r15+0x150], xmm13
00007588ecdd2f74  movaps [r15+0x120], xmm11
00007588ecdd2f7c  vmovaps xmm10, [rsp+0xC0]
00007588ecdd2f85  vpermilpd xmm10, xmm10, 0x00
00007588ecdd2f8b  movaps xmm6, xmm8
00007588ecdd2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007588ecdd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007588ecdd2f99  vptest xmm5, xmm5
00007588ecdd2f9e  jnz 0x00007588ECDD4FB9
00007588ecdd2fa4  vmovaps xmm15, [rsp+0xC0]
00007588ecdd2fad  vpermilpd xmm15, xmm15, 0x00
00007588ecdd2fb3  movaps xmm10, xmm9
00007588ecdd2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007588ecdd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007588ecdd2fc2  vptest xmm8, xmm8
00007588ecdd2fc7  jnz 0x00007588ECDD5111
00007588ecdd2fcd  vmovaps xmm15, [rsp+0xC0]
00007588ecdd2fd6  vpermilpd xmm15, xmm15, 0x00
00007588ecdd2fdc  movaps xmm13, xmm12
00007588ecdd2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007588ecdd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007588ecdd2feb  vptest xmm9, xmm9
00007588ecdd2ff0  jnz 0x00007588ECDD526B
00007588ecdd2ff6  vmovaps xmm15, [rsp+0xC0]
00007588ecdd2fff  vpermilpd xmm15, xmm15, 0x00
00007588ecdd3005  movaps xmm12, xmm7
00007588ecdd3009  vfmadd231pd xmm12, xmm1, xmm15
00007588ecdd300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007588ecdd3014  vptest xmm9, xmm9
00007588ecdd3019  jnz 0x00007588ECDD53C4
00007588ecdd301f  lea rax, [r14+0x20]
00007588ecdd3023  movups xmm1, [r13+rax*1]
00007588ecdd3029  lea rax, [r14+0x30]
00007588ecdd302d  movups xmm15, [r13+rax*1]
00007588ecdd3033  vmovaps xmm9, [rsp+0x70]
00007588ecdd3039  vpermilpd xmm9, xmm9, 0x00
00007588ecdd303f  vmovaps xmm8, [rsp+0x20]
00007588ecdd3045  movaps xmm7, xmm6
00007588ecdd3048  vfmadd231pd xmm7, xmm8, xmm9
00007588ecdd304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007588ecdd3052  vptest xmm5, xmm5
00007588ecdd3057  jnz 0x00007588ECDD5530
00007588ecdd305d  vmovaps xmm9, [rsp+0x70]
00007588ecdd3063  vpermilpd xmm9, xmm9, 0x00
00007588ecdd3069  movaps xmm8, xmm10
00007588ecdd306d  vfmadd231pd xmm8, xmm14, xmm9
00007588ecdd3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007588ecdd3078  vptest xmm6, xmm6
00007588ecdd307d  jnz 0x00007588ECDD5687
00007588ecdd3083  vmovaps xmm14, [rsp+0x70]
00007588ecdd3089  vpermilpd xmm14, xmm14, 0x00
00007588ecdd308f  movaps xmm10, xmm13
00007588ecdd3093  vfmadd231pd xmm10, xmm11, xmm14
00007588ecdd3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007588ecdd309e  vptest xmm9, xmm9
00007588ecdd30a3  jnz 0x00007588ECDD57E1
00007588ecdd30a9  vmovaps xmm14, [rsp+0x70]
00007588ecdd30af  vpermilpd xmm14, xmm14, 0x00
00007588ecdd30b5  movaps xmm13, xmm12
00007588ecdd30b9  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007588ecdd30c4  vptest xmm11, xmm11
00007588ecdd30c9  jnz 0x00007588ECDD593B
00007588ecdd30cf  lea rax, [r14+0x90]
00007588ecdd30d6  movups xmm15, [r13+rax*1]
00007588ecdd30dc  lea rax, [r14+0xA0]
00007588ecdd30e3  movups xmm14, [r13+rax*1]
00007588ecdd30e9  movaps [r15+0x140], xmm15
00007588ecdd30f1  movaps [r15+0x130], xmm14
00007588ecdd30f9  vmovaps xmm12, [rsp+0x90]
00007588ecdd3102  vpermilpd xmm12, xmm12, 0x00
00007588ecdd3108  movaps xmm11, xmm7
00007588ecdd310c  vfmadd231pd xmm11, xmm1, xmm12
00007588ecdd3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007588ecdd3117  vptest xmm9, xmm9
00007588ecdd311c  jnz 0x00007588ECDD5AA9
00007588ecdd3122  movaps [r15+0x220], xmm11
00007588ecdd312a  lea rax, [r14+0x10]
00007588ecdd312e  movups xmm1, [r13+rax*1]
00007588ecdd3134  movaps [r15+0x240], xmm1
00007588ecdd313c  vmovaps xmm12, [rsp+0x90]
00007588ecdd3145  vpermilpd xmm12, xmm12, 0x00
00007588ecdd314b  movaps xmm9, xmm8
00007588ecdd314f  vfmadd231pd xmm9, xmm14, xmm12
00007588ecdd3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007588ecdd315a  vptest xmm7, xmm7
00007588ecdd315f  jnz 0x00007588ECDD5C0B
00007588ecdd3165  movaps [r15+0x110], xmm9
00007588ecdd316d  vmovaps xmm14, [rsp+0x90]
00007588ecdd3176  vpermilpd xmm14, xmm14, 0x00
00007588ecdd317c  movaps xmm12, xmm10
00007588ecdd3180  vfmadd231pd xmm12, xmm15, xmm14
00007588ecdd3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007588ecdd318b  vptest xmm8, xmm8
00007588ecdd3190  jnz 0x00007588ECDD5D65
00007588ecdd3196  movaps [r15+0x170], xmm12
00007588ecdd319e  vmovaps xmm15, [rsp+0x90]
00007588ecdd31a7  vpermilpd xmm15, xmm15, 0x00
00007588ecdd31ad  movaps xmm14, xmm13
00007588ecdd31b1  vfmadd231pd xmm14, xmm1, xmm15
00007588ecdd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007588ecdd31bc  vptest xmm10, xmm10
00007588ecdd31c1  jnz 0x00007588ECDD5EBF
00007588ecdd31c7  movaps [r15+0x230], xmm14
00007588ecdd31cf  mov eax, 0x432190
00007588ecdd31d4  movups [r13+rax*1], xmm9
00007588ecdd31da  mov eax, 0x4321A0
00007588ecdd31df  movups [r13+rax*1], xmm12
00007588ecdd31e5  mov eax, 0x4321B0
00007588ecdd31ea  movups [r13+rax*1], xmm11
00007588ecdd31f0  mov eax, 0x4321C0
00007588ecdd31f5  movups [r13+rax*1], xmm14
00007588ecdd31fb  mov eax, [r15+0x108]
00007588ecdd3202  sahf
00007588ecdd3203  jnz 0x00007588ECDD3235
00007588ecdd3205  cmp dword ptr [r15+0x318], 0x00
00007588ecdd320d  jz 0x00007588ECDD9950
00007588ecdd3213  nop [rax+rax*1], ax
00007588ecdd321c  nop [rax+rax*1], eax
00007588ecdd3224  mov eax, 0x410664
00007588ecdd3229  mov [r15+0x100], rax
00007588ecdd3230  jmp 0x00007588ECBFE110
00007588ecdd3235  cmp dword ptr [r15+0x318], 0x00
00007588ecdd323d  jz 0x00007588ECDD6050
00007588ecdd3243  nop [rax+rax*1], ax
00007588ecdd324c  nop [rax+rax*1], eax
00007588ecdd3254  mov eax, 0x4104F0
00007588ecdd3259  mov [r15+0x100], rax
00007588ecdd3260  jmp 0x00007588ECBFE110
00007588ecdd3265  int3
00007588ecdd3266  call 0x00007588ECBFF430
00007588ecdd326b  jmp 0x00007588ECDD230A
00007588ecdd3270  call 0x00007588ECCE5820
00007588ecdd3275  jmp 0x00007588ECDD2314
00007588ecdd327a  call 0x00007588ECCE45A0
00007588ecdd327f  jmp 0x00007588ECDD2326
00007588ecdd3284  call 0x00007588ECCE3320
00007588ecdd3289  jmp 0x00007588ECDD2330
00007588ecdd328e  call 0x00007588ECCE20A0
00007588ecdd3293  jmp 0x00007588ECDD233D
00007588ecdd3298  call 0x00007588ECCE0E30
00007588ecdd329d  jmp 0x00007588ECDD234A
00007588ecdd32a2  call 0x00007588ECCD6600
00007588ecdd32a7  jmp 0x00007588ECDD2357
00007588ecdd32ac  call 0x00007588ECCB52F0
00007588ecdd32b1  jmp 0x00007588ECDD2361
00007588ecdd32b6  call 0x00007588ECCBE9C0
00007588ecdd32bb  jmp 0x00007588ECDD236B
00007588ecdd32c0  call 0x00007588ECCBD750
00007588ecdd32c5  jmp 0x00007588ECDD2378
00007588ecdd32ca  call 0x00007588ECCBC4E0
00007588ecdd32cf  jmp 0x00007588ECDD2385
00007588ecdd32d4  call 0x00007588ECCBB270
00007588ecdd32d9  jmp 0x00007588ECDD2392
00007588ecdd32de  call 0x00007588ECCBA000
00007588ecdd32e3  jmp 0x00007588ECDD239F
00007588ecdd32e8  call 0x00007588ECCB8D90
00007588ecdd32ed  jmp 0x00007588ECDD23AC
00007588ecdd32f2  call 0x00007588ECCB8A20
00007588ecdd32f7  jmp 0x00007588ECDD23B9
00007588ecdd32fc  call 0x00007588ECCBEAE0
00007588ecdd3301  jmp 0x00007588ECDD23C6
00007588ecdd3306  call 0x00007588ECCB5400
00007588ecdd330b  jmp 0x00007588ECDD23D3
00007588ecdd3310  call 0x00007588ECCB52F0
00007588ecdd3315  jmp 0x00007588ECDD23E0
00007588ecdd331a  call 0x00007588ECCBE9C0
00007588ecdd331f  jmp 0x00007588ECDD23ED
00007588ecdd3324  call 0x00007588ECCB77B0
00007588ecdd3329  jmp 0x00007588ECDD23FA
00007588ecdd332e  call 0x00007588ECCB6550
00007588ecdd3333  jmp 0x00007588ECDD2407
00007588ecdd3338  call 0x00007588ECCB52F0
00007588ecdd333d  jmp 0x00007588ECDD2417
00007588ecdd3342  call 0x00007588ECCB52F0
00007588ecdd3347  jmp 0x00007588ECDD2427
00007588ecdd334c  call 0x00007588ECCBEAE0
00007588ecdd3351  jmp 0x00007588ECDD2431
00007588ecdd3356  call 0x00007588ECCBEAE0
00007588ecdd335b  jmp 0x00007588ECDD2444
00007588ecdd3360  call 0x00007588ECCBE9C0
00007588ecdd3365  jmp 0x00007588ECDD2451
00007588ecdd336a  call 0x00007588ECCB52F0
00007588ecdd336f  jmp 0x00007588ECDD2464
00007588ecdd3374  call 0x00007588ECCB6660
00007588ecdd3379  jmp 0x00007588ECDD2471
00007588ecdd337e  call 0x00007588ECCB78C0
00007588ecdd3383  jmp 0x00007588ECDD247E
00007588ecdd3388  call 0x00007588ECCB77B0
00007588ecdd338d  jmp 0x00007588ECDD248B
00007588ecdd3392  call 0x00007588ECCB6550
00007588ecdd3397  jmp 0x00007588ECDD2498
00007588ecdd339c  call 0x00007588ECCB52F0
00007588ecdd33a1  jmp 0x00007588ECDD24AB
00007588ecdd33a6  call 0x00007588ECCB52F0
00007588ecdd33ab  jmp 0x00007588ECDD24BE
00007588ecdd33b0  call 0x00007588ECCB52F0
00007588ecdd33b5  jmp 0x00007588ECDD24E5
00007588ecdd33ba  call 0x00007588ECCB52F0
00007588ecdd33bf  jmp 0x00007588ECDD24F8
00007588ecdd33c4  call 0x00007588ECCB52F0
00007588ecdd33c9  jmp 0x00007588ECDD250B
00007588ecdd33ce  call 0x00007588ECCB52F0
00007588ecdd33d3  jmp 0x00007588ECDD2521
00007588ecdd33d8  call 0x00007588ECCB52F0
00007588ecdd33dd  jmp 0x00007588ECDD2537
00007588ecdd33e2  call 0x00007588ECCB52F0
00007588ecdd33e7  jmp 0x00007588ECDD254D
00007588ecdd33ec  call 0x00007588ECBFF540
00007588ecdd33f1  jmp 0x00007588ECDD256E
00007588ecdd33f6  call 0x00007588ECC02FE0
00007588ecdd33fb  jmp 0x00007588ECDD2578
00007588ecdd3400  call 0x00007588ECBFF540
00007588ecdd3405  jmp 0x00007588ECDD2588
00007588ecdd340a  call 0x00007588ECBFF540
00007588ecdd340f  jmp 0x00007588ECDD259B
00007588ecdd3414  call 0x00007588ECBFF540
00007588ecdd3419  jmp 0x00007588ECDD25AE
00007588ecdd341e  call 0x00007588ECBFF540
00007588ecdd3423  jmp 0x00007588ECDD25C1
00007588ecdd3428  call 0x00007588ECCC0370
00007588ecdd342d  jmp 0x00007588ECDD25E0
00007588ecdd3432  call 0x00007588ECCBF100
00007588ecdd3437  jmp 0x00007588ECDD25E9
00007588ecdd343c  call 0x00007588ECCC0370
00007588ecdd3441  jmp 0x00007588ECDD2659
00007588ecdd3446  call 0x00007588ECCBF100
00007588ecdd344b  jmp 0x00007588ECDD2662
00007588ecdd3450  call 0x00007588ECCC0370
00007588ecdd3455  jmp 0x00007588ECDD270C
00007588ecdd345a  call 0x00007588ECCBF100
00007588ecdd345f  jmp 0x00007588ECDD2715
00007588ecdd3464  call 0x00007588ECC0B720
00007588ecdd3469  jmp 0x00007588ECDD27F7
00007588ecdd346e  call 0x00007588ECCD64F0
00007588ecdd3473  jmp 0x00007588ECDD281F
00007588ecdd3478  call 0x00007588ECCB47C0
00007588ecdd347d  jmp 0x00007588ECDD283A
00007588ecdd3482  sub rsp, 0x08
00007588ecdd3486  push rax
00007588ecdd3487  push rcx
00007588ecdd3488  push rdx
00007588ecdd3489  push rdi
00007588ecdd348a  push rsi
00007588ecdd348b  push r8
00007588ecdd348d  push r9
00007588ecdd348f  push r10
00007588ecdd3491  push r11
00007588ecdd3493  sub rsp, 0xF0
00007588ecdd349a  vmovaps [rsp], xmm0
00007588ecdd349f  vmovaps [rsp+0x10], xmm1
00007588ecdd34a5  vmovaps [rsp+0x20], xmm2
00007588ecdd34ab  vmovaps [rsp+0x30], xmm3
00007588ecdd34b1  vmovaps [rsp+0x40], xmm4
00007588ecdd34b7  vmovaps [rsp+0x50], xmm5
00007588ecdd34bd  vmovaps [rsp+0x60], xmm6
00007588ecdd34c3  vmovaps [rsp+0x70], xmm7
00007588ecdd34c9  vmovaps [rsp+0x80], xmm8
00007588ecdd34d2  vmovaps [rsp+0x90], xmm9
00007588ecdd34db  vmovaps [rsp+0xA0], xmm10
00007588ecdd34e4  vmovaps [rsp+0xB0], xmm11
00007588ecdd34ed  vmovaps [rsp+0xC0], xmm12
00007588ecdd34f6  vmovaps [rsp+0xD0], xmm14
00007588ecdd34ff  vmovaps [rsp+0xE0], xmm15
00007588ecdd3508  sub rsp, 0x40
00007588ecdd350c  lea rdi, [rsp]
00007588ecdd3510  lea rsi, [rsp+0x10]
00007588ecdd3515  lea rdx, [rsp+0x20]
00007588ecdd351a  lea rcx, [rsp+0x30]
00007588ecdd351f  mov r8d, 0x00
00007588ecdd3525  lea r9, [r15+0x3A8]
00007588ecdd352c  movaps [rdi], xmm13
00007588ecdd3530  movaps [rsi], xmm1
00007588ecdd3533  movaps [rdx], xmm15
00007588ecdd3537  movaps [rcx], xmm14
00007588ecdd353b  mov rax, 0x6516BF3BBA50
00007588ecdd3545  call rax
00007588ecdd3547  movaps xmm13, [rsp]
00007588ecdd354c  add rsp, 0x40
00007588ecdd3550  vmovaps xmm0, [rsp]
00007588ecdd3555  vmovaps xmm1, [rsp+0x10]
00007588ecdd355b  vmovaps xmm2, [rsp+0x20]
00007588ecdd3561  vmovaps xmm3, [rsp+0x30]
00007588ecdd3567  vmovaps xmm4, [rsp+0x40]
00007588ecdd356d  vmovaps xmm5, [rsp+0x50]
00007588ecdd3573  vmovaps xmm6, [rsp+0x60]
00007588ecdd3579  vmovaps xmm7, [rsp+0x70]
00007588ecdd357f  vmovaps xmm8, [rsp+0x80]
00007588ecdd3588  vmovaps xmm9, [rsp+0x90]
00007588ecdd3591  vmovaps xmm10, [rsp+0xA0]
00007588ecdd359a  vmovaps xmm11, [rsp+0xB0]
00007588ecdd35a3  vmovaps xmm12, [rsp+0xC0]
00007588ecdd35ac  vmovaps xmm14, [rsp+0xD0]
00007588ecdd35b5  vmovaps xmm15, [rsp+0xE0]
00007588ecdd35be  add rsp, 0xF0
00007588ecdd35c5  pop r11
00007588ecdd35c7  pop r10
00007588ecdd35c9  pop r9
00007588ecdd35cb  pop r8
00007588ecdd35cd  pop rsi
00007588ecdd35ce  pop rdi
00007588ecdd35cf  pop rdx
00007588ecdd35d0  pop rcx
00007588ecdd35d1  pop rax
00007588ecdd35d2  add rsp, 0x08
00007588ecdd35d6  jmp 0x00007588ECDD28AD
00007588ecdd35db  sub rsp, 0x08
00007588ecdd35df  push rax
00007588ecdd35e0  push rcx
00007588ecdd35e1  push rdx
00007588ecdd35e2  push rdi
00007588ecdd35e3  push rsi
00007588ecdd35e4  push r8
00007588ecdd35e6  push r9
00007588ecdd35e8  push r10
00007588ecdd35ea  push r11
00007588ecdd35ec  sub rsp, 0xF0
00007588ecdd35f3  vmovaps [rsp], xmm0
00007588ecdd35f8  vmovaps [rsp+0x10], xmm1
00007588ecdd35fe  vmovaps [rsp+0x20], xmm2
00007588ecdd3604  vmovaps [rsp+0x30], xmm3
00007588ecdd360a  vmovaps [rsp+0x40], xmm4
00007588ecdd3610  vmovaps [rsp+0x50], xmm5
00007588ecdd3616  vmovaps [rsp+0x60], xmm6
00007588ecdd361c  vmovaps [rsp+0x70], xmm7
00007588ecdd3622  vmovaps [rsp+0x80], xmm8
00007588ecdd362b  vmovaps [rsp+0x90], xmm9
00007588ecdd3634  vmovaps [rsp+0xA0], xmm10
00007588ecdd363d  vmovaps [rsp+0xB0], xmm11
00007588ecdd3646  vmovaps [rsp+0xC0], xmm12
00007588ecdd364f  vmovaps [rsp+0xD0], xmm13
00007588ecdd3658  vmovaps [rsp+0xE0], xmm14
00007588ecdd3661  sub rsp, 0x40
00007588ecdd3665  lea rdi, [rsp]
00007588ecdd3669  lea rsi, [rsp+0x10]
00007588ecdd366e  lea rdx, [rsp+0x20]
00007588ecdd3673  lea rcx, [rsp+0x30]
00007588ecdd3678  mov r8d, 0x00
00007588ecdd367e  lea r9, [r15+0x3A8]
00007588ecdd3685  movaps [rdi], xmm15
00007588ecdd3689  movaps [rsi], xmm5
00007588ecdd368c  movaps [rdx], xmm1
00007588ecdd368f  movaps [rcx], xmm14
00007588ecdd3693  mov rax, 0x6516BF3BBA50
00007588ecdd369d  call rax
00007588ecdd369f  movaps xmm15, [rsp]
00007588ecdd36a4  add rsp, 0x40
00007588ecdd36a8  vmovaps xmm0, [rsp]
00007588ecdd36ad  vmovaps xmm1, [rsp+0x10]
00007588ecdd36b3  vmovaps xmm2, [rsp+0x20]
00007588ecdd36b9  vmovaps xmm3, [rsp+0x30]
00007588ecdd36bf  vmovaps xmm4, [rsp+0x40]
00007588ecdd36c5  vmovaps xmm5, [rsp+0x50]
00007588ecdd36cb  vmovaps xmm6, [rsp+0x60]
00007588ecdd36d1  vmovaps xmm7, [rsp+0x70]
00007588ecdd36d7  vmovaps xmm8, [rsp+0x80]
00007588ecdd36e0  vmovaps xmm9, [rsp+0x90]
00007588ecdd36e9  vmovaps xmm10, [rsp+0xA0]
00007588ecdd36f2  vmovaps xmm11, [rsp+0xB0]
00007588ecdd36fb  vmovaps xmm12, [rsp+0xC0]
00007588ecdd3704  vmovaps xmm13, [rsp+0xD0]
00007588ecdd370d  vmovaps xmm14, [rsp+0xE0]
00007588ecdd3716  add rsp, 0xF0
00007588ecdd371d  pop r11
00007588ecdd371f  pop r10
00007588ecdd3721  pop r9
00007588ecdd3723  pop r8
00007588ecdd3725  pop rsi
00007588ecdd3726  pop rdi
00007588ecdd3727  pop rdx
00007588ecdd3728  pop rcx
00007588ecdd3729  pop rax
00007588ecdd372a  add rsp, 0x08
00007588ecdd372e  jmp 0x00007588ECDD28D0
00007588ecdd3733  call 0x00007588ECBFF430
00007588ecdd3738  jmp 0x00007588ECDD295D
00007588ecdd373d  sub rsp, 0x08
00007588ecdd3741  push rax
00007588ecdd3742  push rcx
00007588ecdd3743  push rdx
00007588ecdd3744  push rdi
00007588ecdd3745  push rsi
00007588ecdd3746  push r8
00007588ecdd3748  push r9
00007588ecdd374a  push r10
00007588ecdd374c  push r11
00007588ecdd374e  sub rsp, 0xF0
00007588ecdd3755  vmovaps [rsp], xmm0
00007588ecdd375a  vmovaps [rsp+0x10], xmm1
00007588ecdd3760  vmovaps [rsp+0x20], xmm2
00007588ecdd3766  vmovaps [rsp+0x30], xmm3
00007588ecdd376c  vmovaps [rsp+0x40], xmm4
00007588ecdd3772  vmovaps [rsp+0x50], xmm5
00007588ecdd3778  vmovaps [rsp+0x60], xmm6
00007588ecdd377e  vmovaps [rsp+0x70], xmm7
00007588ecdd3784  vmovaps [rsp+0x80], xmm8
00007588ecdd378d  vmovaps [rsp+0x90], xmm9
00007588ecdd3796  vmovaps [rsp+0xA0], xmm10
00007588ecdd379f  vmovaps [rsp+0xB0], xmm11
00007588ecdd37a8  vmovaps [rsp+0xC0], xmm12
00007588ecdd37b1  vmovaps [rsp+0xD0], xmm14
00007588ecdd37ba  vmovaps [rsp+0xE0], xmm15
00007588ecdd37c3  sub rsp, 0x40
00007588ecdd37c7  lea rdi, [rsp]
00007588ecdd37cb  lea rsi, [rsp+0x10]
00007588ecdd37d0  lea rdx, [rsp+0x20]
00007588ecdd37d5  lea rcx, [rsp+0x30]
00007588ecdd37da  mov r8d, 0x00
00007588ecdd37e0  lea r9, [r15+0x3A8]
00007588ecdd37e7  movaps [rdi], xmm13
00007588ecdd37eb  movaps [rsi], xmm1
00007588ecdd37ee  movaps [rdx], xmm15
00007588ecdd37f2  movaps [rcx], xmm14
00007588ecdd37f6  mov rax, 0x6516BF3BBA50
00007588ecdd3800  call rax
00007588ecdd3802  movaps xmm13, [rsp]
00007588ecdd3807  add rsp, 0x40
00007588ecdd380b  vmovaps xmm0, [rsp]
00007588ecdd3810  vmovaps xmm1, [rsp+0x10]
00007588ecdd3816  vmovaps xmm2, [rsp+0x20]
00007588ecdd381c  vmovaps xmm3, [rsp+0x30]
00007588ecdd3822  vmovaps xmm4, [rsp+0x40]
00007588ecdd3828  vmovaps xmm5, [rsp+0x50]
00007588ecdd382e  vmovaps xmm6, [rsp+0x60]
00007588ecdd3834  vmovaps xmm7, [rsp+0x70]
00007588ecdd383a  vmovaps xmm8, [rsp+0x80]
00007588ecdd3843  vmovaps xmm9, [rsp+0x90]
00007588ecdd384c  vmovaps xmm10, [rsp+0xA0]
00007588ecdd3855  vmovaps xmm11, [rsp+0xB0]
00007588ecdd385e  vmovaps xmm12, [rsp+0xC0]
00007588ecdd3867  vmovaps xmm14, [rsp+0xD0]
00007588ecdd3870  vmovaps xmm15, [rsp+0xE0]
00007588ecdd3879  add rsp, 0xF0
00007588ecdd3880  pop r11
00007588ecdd3882  pop r10
00007588ecdd3884  pop r9
00007588ecdd3886  pop r8
00007588ecdd3888  pop rsi
00007588ecdd3889  pop rdi
00007588ecdd388a  pop rdx
00007588ecdd388b  pop rcx
00007588ecdd388c  pop rax
00007588ecdd388d  add rsp, 0x08
00007588ecdd3891  jmp 0x00007588ECDD29C1
00007588ecdd3896  call 0x00007588ECBFF430
00007588ecdd389b  jmp 0x00007588ECDD29CE
00007588ecdd38a0  sub rsp, 0x08
00007588ecdd38a4  push rax
00007588ecdd38a5  push rcx
00007588ecdd38a6  push rdx
00007588ecdd38a7  push rdi
00007588ecdd38a8  push rsi
00007588ecdd38a9  push r8
00007588ecdd38ab  push r9
00007588ecdd38ad  push r10
00007588ecdd38af  push r11
00007588ecdd38b1  sub rsp, 0xF0
00007588ecdd38b8  vmovaps [rsp], xmm0
00007588ecdd38bd  vmovaps [rsp+0x10], xmm1
00007588ecdd38c3  vmovaps [rsp+0x20], xmm2
00007588ecdd38c9  vmovaps [rsp+0x30], xmm3
00007588ecdd38cf  vmovaps [rsp+0x40], xmm4
00007588ecdd38d5  vmovaps [rsp+0x50], xmm5
00007588ecdd38db  vmovaps [rsp+0x60], xmm6
00007588ecdd38e1  vmovaps [rsp+0x70], xmm7
00007588ecdd38e7  vmovaps [rsp+0x80], xmm8
00007588ecdd38f0  vmovaps [rsp+0x90], xmm9
00007588ecdd38f9  vmovaps [rsp+0xA0], xmm10
00007588ecdd3902  vmovaps [rsp+0xB0], xmm11
00007588ecdd390b  vmovaps [rsp+0xC0], xmm13
00007588ecdd3914  vmovaps [rsp+0xD0], xmm14
00007588ecdd391d  vmovaps [rsp+0xE0], xmm15
00007588ecdd3926  sub rsp, 0x40
00007588ecdd392a  lea rdi, [rsp]
00007588ecdd392e  lea rsi, [rsp+0x10]
00007588ecdd3933  lea rdx, [rsp+0x20]
00007588ecdd3938  lea rcx, [rsp+0x30]
00007588ecdd393d  mov r8d, 0x00
00007588ecdd3943  lea r9, [r15+0x3A8]
00007588ecdd394a  movaps [rdi], xmm12
00007588ecdd394e  movaps [rsi], xmm15
00007588ecdd3952  movaps [rdx], xmm1
00007588ecdd3955  movaps [rcx], xmm14
00007588ecdd3959  mov rax, 0x6516BF3BBA50
00007588ecdd3963  call rax
00007588ecdd3965  movaps xmm12, [rsp]
00007588ecdd396a  add rsp, 0x40
00007588ecdd396e  vmovaps xmm0, [rsp]
00007588ecdd3973  vmovaps xmm1, [rsp+0x10]
00007588ecdd3979  vmovaps xmm2, [rsp+0x20]
00007588ecdd397f  vmovaps xmm3, [rsp+0x30]
00007588ecdd3985  vmovaps xmm4, [rsp+0x40]
00007588ecdd398b  vmovaps xmm5, [rsp+0x50]
00007588ecdd3991  vmovaps xmm6, [rsp+0x60]
00007588ecdd3997  vmovaps xmm7, [rsp+0x70]
00007588ecdd399d  vmovaps xmm8, [rsp+0x80]
00007588ecdd39a6  vmovaps xmm9, [rsp+0x90]
00007588ecdd39af  vmovaps xmm10, [rsp+0xA0]
00007588ecdd39b8  vmovaps xmm11, [rsp+0xB0]
00007588ecdd39c1  vmovaps xmm13, [rsp+0xC0]
00007588ecdd39ca  vmovaps xmm14, [rsp+0xD0]
00007588ecdd39d3  vmovaps xmm15, [rsp+0xE0]
00007588ecdd39dc  add rsp, 0xF0
00007588ecdd39e3  pop r11
00007588ecdd39e5  pop r10
00007588ecdd39e7  pop r9
00007588ecdd39e9  pop r8
00007588ecdd39eb  pop rsi
00007588ecdd39ec  pop rdi
00007588ecdd39ed  pop rdx
00007588ecdd39ee  pop rcx
00007588ecdd39ef  pop rax
00007588ecdd39f0  add rsp, 0x08
00007588ecdd39f4  jmp 0x00007588ECDD29FA
00007588ecdd39f9  sub rsp, 0x08
00007588ecdd39fd  push rax
00007588ecdd39fe  push rcx
00007588ecdd39ff  push rdx
00007588ecdd3a00  push rdi
00007588ecdd3a01  push rsi
00007588ecdd3a02  push r8
00007588ecdd3a04  push r9
00007588ecdd3a06  push r10
00007588ecdd3a08  push r11
00007588ecdd3a0a  sub rsp, 0xF0
00007588ecdd3a11  vmovaps [rsp], xmm0
00007588ecdd3a16  vmovaps [rsp+0x10], xmm1
00007588ecdd3a1c  vmovaps [rsp+0x20], xmm2
00007588ecdd3a22  vmovaps [rsp+0x30], xmm3
00007588ecdd3a28  vmovaps [rsp+0x40], xmm4
00007588ecdd3a2e  vmovaps [rsp+0x50], xmm5
00007588ecdd3a34  vmovaps [rsp+0x60], xmm6
00007588ecdd3a3a  vmovaps [rsp+0x70], xmm7
00007588ecdd3a40  vmovaps [rsp+0x80], xmm8
00007588ecdd3a49  vmovaps [rsp+0x90], xmm9
00007588ecdd3a52  vmovaps [rsp+0xA0], xmm10
00007588ecdd3a5b  vmovaps [rsp+0xB0], xmm11
00007588ecdd3a64  vmovaps [rsp+0xC0], xmm12
00007588ecdd3a6d  vmovaps [rsp+0xD0], xmm14
00007588ecdd3a76  vmovaps [rsp+0xE0], xmm15
00007588ecdd3a7f  sub rsp, 0x40
00007588ecdd3a83  lea rdi, [rsp]
00007588ecdd3a87  lea rsi, [rsp+0x10]
00007588ecdd3a8c  lea rdx, [rsp+0x20]
00007588ecdd3a91  lea rcx, [rsp+0x30]
00007588ecdd3a96  mov r8d, 0x00
00007588ecdd3a9c  lea r9, [r15+0x3A8]
00007588ecdd3aa3  movaps [rdi], xmm13
00007588ecdd3aa7  movaps [rsi], xmm1
00007588ecdd3aaa  movaps [rdx], xmm15
00007588ecdd3aae  movaps [rcx], xmm14
00007588ecdd3ab2  mov rax, 0x6516BF3BBA50
00007588ecdd3abc  call rax
00007588ecdd3abe  movaps xmm13, [rsp]
00007588ecdd3ac3  add rsp, 0x40
00007588ecdd3ac7  vmovaps xmm0, [rsp]
00007588ecdd3acc  vmovaps xmm1, [rsp+0x10]
00007588ecdd3ad2  vmovaps xmm2, [rsp+0x20]
00007588ecdd3ad8  vmovaps xmm3, [rsp+0x30]
00007588ecdd3ade  vmovaps xmm4, [rsp+0x40]
00007588ecdd3ae4  vmovaps xmm5, [rsp+0x50]
00007588ecdd3aea  vmovaps xmm6, [rsp+0x60]
00007588ecdd3af0  vmovaps xmm7, [rsp+0x70]
00007588ecdd3af6  vmovaps xmm8, [rsp+0x80]
00007588ecdd3aff  vmovaps xmm9, [rsp+0x90]
00007588ecdd3b08  vmovaps xmm10, [rsp+0xA0]
00007588ecdd3b11  vmovaps xmm11, [rsp+0xB0]
00007588ecdd3b1a  vmovaps xmm12, [rsp+0xC0]
00007588ecdd3b23  vmovaps xmm14, [rsp+0xD0]
00007588ecdd3b2c  vmovaps xmm15, [rsp+0xE0]
00007588ecdd3b35  add rsp, 0xF0
00007588ecdd3b3c  pop r11
00007588ecdd3b3e  pop r10
00007588ecdd3b40  pop r9
00007588ecdd3b42  pop r8
00007588ecdd3b44  pop rsi
00007588ecdd3b45  pop rdi
00007588ecdd3b46  pop rdx
00007588ecdd3b47  pop rcx
00007588ecdd3b48  pop rax
00007588ecdd3b49  add rsp, 0x08
00007588ecdd3b4d  jmp 0x00007588ECDD2B77
00007588ecdd3b52  sub rsp, 0x08
00007588ecdd3b56  push rax
00007588ecdd3b57  push rcx
00007588ecdd3b58  push rdx
00007588ecdd3b59  push rdi
00007588ecdd3b5a  push rsi
00007588ecdd3b5b  push r8
00007588ecdd3b5d  push r9
00007588ecdd3b5f  push r10
00007588ecdd3b61  push r11
00007588ecdd3b63  sub rsp, 0xF0
00007588ecdd3b6a  vmovaps [rsp], xmm0
00007588ecdd3b6f  vmovaps [rsp+0x10], xmm1
00007588ecdd3b75  vmovaps [rsp+0x20], xmm2
00007588ecdd3b7b  vmovaps [rsp+0x30], xmm3
00007588ecdd3b81  vmovaps [rsp+0x40], xmm4
00007588ecdd3b87  vmovaps [rsp+0x50], xmm5
00007588ecdd3b8d  vmovaps [rsp+0x60], xmm6
00007588ecdd3b93  vmovaps [rsp+0x70], xmm7
00007588ecdd3b99  vmovaps [rsp+0x80], xmm8
00007588ecdd3ba2  vmovaps [rsp+0x90], xmm9
00007588ecdd3bab  vmovaps [rsp+0xA0], xmm10
00007588ecdd3bb4  vmovaps [rsp+0xB0], xmm11
00007588ecdd3bbd  vmovaps [rsp+0xC0], xmm13
00007588ecdd3bc6  vmovaps [rsp+0xD0], xmm14
00007588ecdd3bcf  vmovaps [rsp+0xE0], xmm15
00007588ecdd3bd8  sub rsp, 0x40
00007588ecdd3bdc  lea rdi, [rsp]
00007588ecdd3be0  lea rsi, [rsp+0x10]
00007588ecdd3be5  lea rdx, [rsp+0x20]
00007588ecdd3bea  lea rcx, [rsp+0x30]
00007588ecdd3bef  mov r8d, 0x00
00007588ecdd3bf5  lea r9, [r15+0x3A8]
00007588ecdd3bfc  movaps [rdi], xmm12
00007588ecdd3c00  movaps [rsi], xmm15
00007588ecdd3c04  movaps [rdx], xmm14
00007588ecdd3c08  movaps [rcx], xmm1
00007588ecdd3c0b  mov rax, 0x6516BF3BBA50
00007588ecdd3c15  call rax
00007588ecdd3c17  movaps xmm12, [rsp]
00007588ecdd3c1c  add rsp, 0x40
00007588ecdd3c20  vmovaps xmm0, [rsp]
00007588ecdd3c25  vmovaps xmm1, [rsp+0x10]
00007588ecdd3c2b  vmovaps xmm2, [rsp+0x20]
00007588ecdd3c31  vmovaps xmm3, [rsp+0x30]
00007588ecdd3c37  vmovaps xmm4, [rsp+0x40]
00007588ecdd3c3d  vmovaps xmm5, [rsp+0x50]
00007588ecdd3c43  vmovaps xmm6, [rsp+0x60]
00007588ecdd3c49  vmovaps xmm7, [rsp+0x70]
00007588ecdd3c4f  vmovaps xmm8, [rsp+0x80]
00007588ecdd3c58  vmovaps xmm9, [rsp+0x90]
00007588ecdd3c61  vmovaps xmm10, [rsp+0xA0]
00007588ecdd3c6a  vmovaps xmm11, [rsp+0xB0]
00007588ecdd3c73  vmovaps xmm13, [rsp+0xC0]
00007588ecdd3c7c  vmovaps xmm14, [rsp+0xD0]
00007588ecdd3c85  vmovaps xmm15, [rsp+0xE0]
00007588ecdd3c8e  add rsp, 0xF0
00007588ecdd3c95  pop r11
00007588ecdd3c97  pop r10
00007588ecdd3c99  pop r9
00007588ecdd3c9b  pop r8
00007588ecdd3c9d  pop rsi
00007588ecdd3c9e  pop rdi
00007588ecdd3c9f  pop rdx
00007588ecdd3ca0  pop rcx
00007588ecdd3ca1  pop rax
00007588ecdd3ca2  add rsp, 0x08
00007588ecdd3ca6  jmp 0x00007588ECDD2BB2
00007588ecdd3cab  sub rsp, 0x08
00007588ecdd3caf  push rax
00007588ecdd3cb0  push rcx
00007588ecdd3cb1  push rdx
00007588ecdd3cb2  push rdi
00007588ecdd3cb3  push rsi
00007588ecdd3cb4  push r8
00007588ecdd3cb6  push r9
00007588ecdd3cb8  push r10
00007588ecdd3cba  push r11
00007588ecdd3cbc  sub rsp, 0xF0
00007588ecdd3cc3  vmovaps [rsp], xmm0
00007588ecdd3cc8  vmovaps [rsp+0x10], xmm1
00007588ecdd3cce  vmovaps [rsp+0x20], xmm2
00007588ecdd3cd4  vmovaps [rsp+0x30], xmm3
00007588ecdd3cda  vmovaps [rsp+0x40], xmm4
00007588ecdd3ce0  vmovaps [rsp+0x50], xmm5
00007588ecdd3ce6  vmovaps [rsp+0x60], xmm6
00007588ecdd3cec  vmovaps [rsp+0x70], xmm7
00007588ecdd3cf2  vmovaps [rsp+0x80], xmm8
00007588ecdd3cfb  vmovaps [rsp+0x90], xmm9
00007588ecdd3d04  vmovaps [rsp+0xA0], xmm10
00007588ecdd3d0d  vmovaps [rsp+0xB0], xmm11
00007588ecdd3d16  vmovaps [rsp+0xC0], xmm12
00007588ecdd3d1f  vmovaps [rsp+0xD0], xmm14
00007588ecdd3d28  vmovaps [rsp+0xE0], xmm15
00007588ecdd3d31  sub rsp, 0x40
00007588ecdd3d35  lea rdi, [rsp]
00007588ecdd3d39  lea rsi, [rsp+0x10]
00007588ecdd3d3e  lea rdx, [rsp+0x20]
00007588ecdd3d43  lea rcx, [rsp+0x30]
00007588ecdd3d48  mov r8d, 0x00
00007588ecdd3d4e  lea r9, [r15+0x3A8]
00007588ecdd3d55  movaps [rdi], xmm13
00007588ecdd3d59  movaps [rsi], xmm15
00007588ecdd3d5d  movaps [rdx], xmm14
00007588ecdd3d61  movaps [rcx], xmm1
00007588ecdd3d64  mov rax, 0x6516BF3BBA50
00007588ecdd3d6e  call rax
00007588ecdd3d70  movaps xmm13, [rsp]
00007588ecdd3d75  add rsp, 0x40
00007588ecdd3d79  vmovaps xmm0, [rsp]
00007588ecdd3d7e  vmovaps xmm1, [rsp+0x10]
00007588ecdd3d84  vmovaps xmm2, [rsp+0x20]
00007588ecdd3d8a  vmovaps xmm3, [rsp+0x30]
00007588ecdd3d90  vmovaps xmm4, [rsp+0x40]
00007588ecdd3d96  vmovaps xmm5, [rsp+0x50]
00007588ecdd3d9c  vmovaps xmm6, [rsp+0x60]
00007588ecdd3da2  vmovaps xmm7, [rsp+0x70]
00007588ecdd3da8  vmovaps xmm8, [rsp+0x80]
00007588ecdd3db1  vmovaps xmm9, [rsp+0x90]
00007588ecdd3dba  vmovaps xmm10, [rsp+0xA0]
00007588ecdd3dc3  vmovaps xmm11, [rsp+0xB0]
00007588ecdd3dcc  vmovaps xmm12, [rsp+0xC0]
00007588ecdd3dd5  vmovaps xmm14, [rsp+0xD0]
00007588ecdd3dde  vmovaps xmm15, [rsp+0xE0]
00007588ecdd3de7  add rsp, 0xF0
00007588ecdd3dee  pop r11
00007588ecdd3df0  pop r10
00007588ecdd3df2  pop r9
00007588ecdd3df4  pop r8
00007588ecdd3df6  pop rsi
00007588ecdd3df7  pop rdi
00007588ecdd3df8  pop rdx
00007588ecdd3df9  pop rcx
00007588ecdd3dfa  pop rax
00007588ecdd3dfb  add rsp, 0x08
00007588ecdd3dff  jmp 0x00007588ECDD2BEA
00007588ecdd3e04  sub rsp, 0x08
00007588ecdd3e08  push rax
00007588ecdd3e09  push rcx
00007588ecdd3e0a  push rdx
00007588ecdd3e0b  push rdi
00007588ecdd3e0c  push rsi
00007588ecdd3e0d  push r8
00007588ecdd3e0f  push r9
00007588ecdd3e11  push r10
00007588ecdd3e13  push r11
00007588ecdd3e15  sub rsp, 0xF0
00007588ecdd3e1c  vmovaps [rsp], xmm0
00007588ecdd3e21  vmovaps [rsp+0x10], xmm1
00007588ecdd3e27  vmovaps [rsp+0x20], xmm2
00007588ecdd3e2d  vmovaps [rsp+0x30], xmm3
00007588ecdd3e33  vmovaps [rsp+0x40], xmm4
00007588ecdd3e39  vmovaps [rsp+0x50], xmm5
00007588ecdd3e3f  vmovaps [rsp+0x60], xmm6
00007588ecdd3e45  vmovaps [rsp+0x70], xmm7
00007588ecdd3e4b  vmovaps [rsp+0x80], xmm8
00007588ecdd3e54  vmovaps [rsp+0x90], xmm9
00007588ecdd3e5d  vmovaps [rsp+0xA0], xmm10
00007588ecdd3e66  vmovaps [rsp+0xB0], xmm11
00007588ecdd3e6f  vmovaps [rsp+0xC0], xmm13
00007588ecdd3e78  vmovaps [rsp+0xD0], xmm14
00007588ecdd3e81  vmovaps [rsp+0xE0], xmm15
00007588ecdd3e8a  sub rsp, 0x40
00007588ecdd3e8e  lea rdi, [rsp]
00007588ecdd3e92  lea rsi, [rsp+0x10]
00007588ecdd3e97  lea rdx, [rsp+0x20]
00007588ecdd3e9c  lea rcx, [rsp+0x30]
00007588ecdd3ea1  mov r8d, 0x00
00007588ecdd3ea7  lea r9, [r15+0x3A8]
00007588ecdd3eae  movaps [rdi], xmm12
00007588ecdd3eb2  movaps [rsi], xmm15
00007588ecdd3eb6  movaps [rdx], xmm14
00007588ecdd3eba  movaps [rcx], xmm1
00007588ecdd3ebd  mov rax, 0x6516BF3BBA50
00007588ecdd3ec7  call rax
00007588ecdd3ec9  movaps xmm12, [rsp]
00007588ecdd3ece  add rsp, 0x40
00007588ecdd3ed2  vmovaps xmm0, [rsp]
00007588ecdd3ed7  vmovaps xmm1, [rsp+0x10]
00007588ecdd3edd  vmovaps xmm2, [rsp+0x20]
00007588ecdd3ee3  vmovaps xmm3, [rsp+0x30]
00007588ecdd3ee9  vmovaps xmm4, [rsp+0x40]
00007588ecdd3eef  vmovaps xmm5, [rsp+0x50]
00007588ecdd3ef5  vmovaps xmm6, [rsp+0x60]
00007588ecdd3efb  vmovaps xmm7, [rsp+0x70]
00007588ecdd3f01  vmovaps xmm8, [rsp+0x80]
00007588ecdd3f0a  vmovaps xmm9, [rsp+0x90]
00007588ecdd3f13  vmovaps xmm10, [rsp+0xA0]
00007588ecdd3f1c  vmovaps xmm11, [rsp+0xB0]
00007588ecdd3f25  vmovaps xmm13, [rsp+0xC0]
00007588ecdd3f2e  vmovaps xmm14, [rsp+0xD0]
00007588ecdd3f37  vmovaps xmm15, [rsp+0xE0]
00007588ecdd3f40  add rsp, 0xF0
00007588ecdd3f47  pop r11
00007588ecdd3f49  pop r10
00007588ecdd3f4b  pop r9
00007588ecdd3f4d  pop r8
00007588ecdd3f4f  pop rsi
00007588ecdd3f50  pop rdi
00007588ecdd3f51  pop rdx
00007588ecdd3f52  pop rcx
00007588ecdd3f53  pop rax
00007588ecdd3f54  add rsp, 0x08
00007588ecdd3f58  jmp 0x00007588ECDD2C3D
00007588ecdd3f5d  sub rsp, 0x08
00007588ecdd3f61  push rax
00007588ecdd3f62  push rcx
00007588ecdd3f63  push rdx
00007588ecdd3f64  push rdi
00007588ecdd3f65  push rsi
00007588ecdd3f66  push r8
00007588ecdd3f68  push r9
00007588ecdd3f6a  push r10
00007588ecdd3f6c  push r11
00007588ecdd3f6e  sub rsp, 0xF0
00007588ecdd3f75  vmovaps [rsp], xmm0
00007588ecdd3f7a  vmovaps [rsp+0x10], xmm1
00007588ecdd3f80  vmovaps [rsp+0x20], xmm2
00007588ecdd3f86  vmovaps [rsp+0x30], xmm3
00007588ecdd3f8c  vmovaps [rsp+0x40], xmm4
00007588ecdd3f92  vmovaps [rsp+0x50], xmm5
00007588ecdd3f98  vmovaps [rsp+0x60], xmm6
00007588ecdd3f9e  vmovaps [rsp+0x70], xmm7
00007588ecdd3fa4  vmovaps [rsp+0x80], xmm8
00007588ecdd3fad  vmovaps [rsp+0x90], xmm9
00007588ecdd3fb6  vmovaps [rsp+0xA0], xmm10
00007588ecdd3fbf  vmovaps [rsp+0xB0], xmm11
00007588ecdd3fc8  vmovaps [rsp+0xC0], xmm12
00007588ecdd3fd1  vmovaps [rsp+0xD0], xmm13
00007588ecdd3fda  vmovaps [rsp+0xE0], xmm15
00007588ecdd3fe3  sub rsp, 0x40
00007588ecdd3fe7  lea rdi, [rsp]
00007588ecdd3feb  lea rsi, [rsp+0x10]
00007588ecdd3ff0  lea rdx, [rsp+0x20]
00007588ecdd3ff5  lea rcx, [rsp+0x30]
00007588ecdd3ffa  mov r8d, 0x00
00007588ecdd4000  lea r9, [r15+0x3A8]
00007588ecdd4007  movaps [rdi], xmm14
00007588ecdd400b  movaps [rsi], xmm3
00007588ecdd400e  movaps [rdx], xmm1
00007588ecdd4011  movaps [rcx], xmm15
00007588ecdd4015  mov rax, 0x6516BF3BBA50
00007588ecdd401f  call rax
00007588ecdd4021  movaps xmm14, [rsp]
00007588ecdd4026  add rsp, 0x40
00007588ecdd402a  vmovaps xmm0, [rsp]
00007588ecdd402f  vmovaps xmm1, [rsp+0x10]
00007588ecdd4035  vmovaps xmm2, [rsp+0x20]
00007588ecdd403b  vmovaps xmm3, [rsp+0x30]
00007588ecdd4041  vmovaps xmm4, [rsp+0x40]
00007588ecdd4047  vmovaps xmm5, [rsp+0x50]
00007588ecdd404d  vmovaps xmm6, [rsp+0x60]
00007588ecdd4053  vmovaps xmm7, [rsp+0x70]
00007588ecdd4059  vmovaps xmm8, [rsp+0x80]
00007588ecdd4062  vmovaps xmm9, [rsp+0x90]
00007588ecdd406b  vmovaps xmm10, [rsp+0xA0]
00007588ecdd4074  vmovaps xmm11, [rsp+0xB0]
00007588ecdd407d  vmovaps xmm12, [rsp+0xC0]
00007588ecdd4086  vmovaps xmm13, [rsp+0xD0]
00007588ecdd408f  vmovaps xmm15, [rsp+0xE0]
00007588ecdd4098  add rsp, 0xF0
00007588ecdd409f  pop r11
00007588ecdd40a1  pop r10
00007588ecdd40a3  pop r9
00007588ecdd40a5  pop r8
00007588ecdd40a7  pop rsi
00007588ecdd40a8  pop rdi
00007588ecdd40a9  pop rdx
00007588ecdd40aa  pop rcx
00007588ecdd40ab  pop rax
00007588ecdd40ac  add rsp, 0x08
00007588ecdd40b0  jmp 0x00007588ECDD2CF7
00007588ecdd40b5  sub rsp, 0x08
00007588ecdd40b9  push rax
00007588ecdd40ba  push rcx
00007588ecdd40bb  push rdx
00007588ecdd40bc  push rdi
00007588ecdd40bd  push rsi
00007588ecdd40be  push r8
00007588ecdd40c0  push r9
00007588ecdd40c2  push r10
00007588ecdd40c4  push r11
00007588ecdd40c6  sub rsp, 0xF0
00007588ecdd40cd  vmovaps [rsp], xmm0
00007588ecdd40d2  vmovaps [rsp+0x10], xmm1
00007588ecdd40d8  vmovaps [rsp+0x20], xmm2
00007588ecdd40de  vmovaps [rsp+0x30], xmm3
00007588ecdd40e4  vmovaps [rsp+0x40], xmm4
00007588ecdd40ea  vmovaps [rsp+0x50], xmm5
00007588ecdd40f0  vmovaps [rsp+0x60], xmm6
00007588ecdd40f6  vmovaps [rsp+0x70], xmm7
00007588ecdd40fc  vmovaps [rsp+0x80], xmm8
00007588ecdd4105  vmovaps [rsp+0x90], xmm9
00007588ecdd410e  vmovaps [rsp+0xA0], xmm10
00007588ecdd4117  vmovaps [rsp+0xB0], xmm11
00007588ecdd4120  vmovaps [rsp+0xC0], xmm12
00007588ecdd4129  vmovaps [rsp+0xD0], xmm14
00007588ecdd4132  vmovaps [rsp+0xE0], xmm15
00007588ecdd413b  sub rsp, 0x40
00007588ecdd413f  lea rdi, [rsp]
00007588ecdd4143  lea rsi, [rsp+0x10]
00007588ecdd4148  lea rdx, [rsp+0x20]
00007588ecdd414d  lea rcx, [rsp+0x30]
00007588ecdd4152  mov r8d, 0x00
00007588ecdd4158  lea r9, [r15+0x3A8]
00007588ecdd415f  movaps [rdi], xmm13
00007588ecdd4163  movaps [rsi], xmm15
00007588ecdd4167  movaps [rdx], xmm10
00007588ecdd416b  movaps [rcx], xmm1
00007588ecdd416e  mov rax, 0x6516BF3BBA50
00007588ecdd4178  call rax
00007588ecdd417a  movaps xmm13, [rsp]
00007588ecdd417f  add rsp, 0x40
00007588ecdd4183  vmovaps xmm0, [rsp]
00007588ecdd4188  vmovaps xmm1, [rsp+0x10]
00007588ecdd418e  vmovaps xmm2, [rsp+0x20]
00007588ecdd4194  vmovaps xmm3, [rsp+0x30]
00007588ecdd419a  vmovaps xmm4, [rsp+0x40]
00007588ecdd41a0  vmovaps xmm5, [rsp+0x50]
00007588ecdd41a6  vmovaps xmm6, [rsp+0x60]
00007588ecdd41ac  vmovaps xmm7, [rsp+0x70]
00007588ecdd41b2  vmovaps xmm8, [rsp+0x80]
00007588ecdd41bb  vmovaps xmm9, [rsp+0x90]
00007588ecdd41c4  vmovaps xmm10, [rsp+0xA0]
00007588ecdd41cd  vmovaps xmm11, [rsp+0xB0]
00007588ecdd41d6  vmovaps xmm12, [rsp+0xC0]
00007588ecdd41df  vmovaps xmm14, [rsp+0xD0]
00007588ecdd41e8  vmovaps xmm15, [rsp+0xE0]
00007588ecdd41f1  add rsp, 0xF0
00007588ecdd41f8  pop r11
00007588ecdd41fa  pop r10
00007588ecdd41fc  pop r9
00007588ecdd41fe  pop r8
00007588ecdd4200  pop rsi
00007588ecdd4201  pop rdi
00007588ecdd4202  pop rdx
00007588ecdd4203  pop rcx
00007588ecdd4204  pop rax
00007588ecdd4205  add rsp, 0x08
00007588ecdd4209  jmp 0x00007588ECDD2D26
00007588ecdd420e  sub rsp, 0x08
00007588ecdd4212  push rax
00007588ecdd4213  push rcx
00007588ecdd4214  push rdx
00007588ecdd4215  push rdi
00007588ecdd4216  push rsi
00007588ecdd4217  push r8
00007588ecdd4219  push r9
00007588ecdd421b  push r10
00007588ecdd421d  push r11
00007588ecdd421f  sub rsp, 0xF0
00007588ecdd4226  vmovaps [rsp], xmm0
00007588ecdd422b  vmovaps [rsp+0x10], xmm1
00007588ecdd4231  vmovaps [rsp+0x20], xmm2
00007588ecdd4237  vmovaps [rsp+0x30], xmm3
00007588ecdd423d  vmovaps [rsp+0x40], xmm4
00007588ecdd4243  vmovaps [rsp+0x50], xmm5
00007588ecdd4249  vmovaps [rsp+0x60], xmm6
00007588ecdd424f  vmovaps [rsp+0x70], xmm7
00007588ecdd4255  vmovaps [rsp+0x80], xmm8
00007588ecdd425e  vmovaps [rsp+0x90], xmm9
00007588ecdd4267  vmovaps [rsp+0xA0], xmm11
00007588ecdd4270  vmovaps [rsp+0xB0], xmm12
00007588ecdd4279  vmovaps [rsp+0xC0], xmm13
00007588ecdd4282  vmovaps [rsp+0xD0], xmm14
00007588ecdd428b  vmovaps [rsp+0xE0], xmm15
00007588ecdd4294  sub rsp, 0x40
00007588ecdd4298  lea rdi, [rsp]
00007588ecdd429c  lea rsi, [rsp+0x10]
00007588ecdd42a1  lea rdx, [rsp+0x20]
00007588ecdd42a6  lea rcx, [rsp+0x30]
00007588ecdd42ab  mov r8d, 0x00
00007588ecdd42b1  lea r9, [r15+0x3A8]
00007588ecdd42b8  movaps [rdi], xmm10
00007588ecdd42bc  movaps [rsi], xmm15
00007588ecdd42c0  movaps [rdx], xmm11
00007588ecdd42c4  movaps [rcx], xmm1
00007588ecdd42c7  mov rax, 0x6516BF3BBA50
00007588ecdd42d1  call rax
00007588ecdd42d3  movaps xmm10, [rsp]
00007588ecdd42d8  add rsp, 0x40
00007588ecdd42dc  vmovaps xmm0, [rsp]
00007588ecdd42e1  vmovaps xmm1, [rsp+0x10]
00007588ecdd42e7  vmovaps xmm2, [rsp+0x20]
00007588ecdd42ed  vmovaps xmm3, [rsp+0x30]
00007588ecdd42f3  vmovaps xmm4, [rsp+0x40]
00007588ecdd42f9  vmovaps xmm5, [rsp+0x50]
00007588ecdd42ff  vmovaps xmm6, [rsp+0x60]
00007588ecdd4305  vmovaps xmm7, [rsp+0x70]
00007588ecdd430b  vmovaps xmm8, [rsp+0x80]
00007588ecdd4314  vmovaps xmm9, [rsp+0x90]
00007588ecdd431d  vmovaps xmm11, [rsp+0xA0]
00007588ecdd4326  vmovaps xmm12, [rsp+0xB0]
00007588ecdd432f  vmovaps xmm13, [rsp+0xC0]
00007588ecdd4338  vmovaps xmm14, [rsp+0xD0]
00007588ecdd4341  vmovaps xmm15, [rsp+0xE0]
00007588ecdd434a  add rsp, 0xF0
00007588ecdd4351  pop r11
00007588ecdd4353  pop r10
00007588ecdd4355  pop r9
00007588ecdd4357  pop r8
00007588ecdd4359  pop rsi
00007588ecdd435a  pop rdi
00007588ecdd435b  pop rdx
00007588ecdd435c  pop rcx
00007588ecdd435d  pop rax
00007588ecdd435e  add rsp, 0x08
00007588ecdd4362  jmp 0x00007588ECDD2D55
00007588ecdd4367  sub rsp, 0x08
00007588ecdd436b  push rax
00007588ecdd436c  push rcx
00007588ecdd436d  push rdx
00007588ecdd436e  push rdi
00007588ecdd436f  push rsi
00007588ecdd4370  push r8
00007588ecdd4372  push r9
00007588ecdd4374  push r10
00007588ecdd4376  push r11
00007588ecdd4378  sub rsp, 0xF0
00007588ecdd437f  vmovaps [rsp], xmm0
00007588ecdd4384  vmovaps [rsp+0x10], xmm1
00007588ecdd438a  vmovaps [rsp+0x20], xmm2
00007588ecdd4390  vmovaps [rsp+0x30], xmm3
00007588ecdd4396  vmovaps [rsp+0x40], xmm4
00007588ecdd439c  vmovaps [rsp+0x50], xmm5
00007588ecdd43a2  vmovaps [rsp+0x60], xmm6
00007588ecdd43a8  vmovaps [rsp+0x70], xmm7
00007588ecdd43ae  vmovaps [rsp+0x80], xmm8
00007588ecdd43b7  vmovaps [rsp+0x90], xmm9
00007588ecdd43c0  vmovaps [rsp+0xA0], xmm10
00007588ecdd43c9  vmovaps [rsp+0xB0], xmm11
00007588ecdd43d2  vmovaps [rsp+0xC0], xmm12
00007588ecdd43db  vmovaps [rsp+0xD0], xmm13
00007588ecdd43e4  vmovaps [rsp+0xE0], xmm14
00007588ecdd43ed  sub rsp, 0x40
00007588ecdd43f1  lea rdi, [rsp]
00007588ecdd43f5  lea rsi, [rsp+0x10]
00007588ecdd43fa  lea rdx, [rsp+0x20]
00007588ecdd43ff  lea rcx, [rsp+0x30]
00007588ecdd4404  mov r8d, 0x00
00007588ecdd440a  lea r9, [r15+0x3A8]
00007588ecdd4411  movaps [rdi], xmm15
00007588ecdd4415  movaps [rsi], xmm12
00007588ecdd4419  movaps [rdx], xmm5
00007588ecdd441c  movaps [rcx], xmm1
00007588ecdd441f  mov rax, 0x6516BF3BBA50
00007588ecdd4429  call rax
00007588ecdd442b  movaps xmm15, [rsp]
00007588ecdd4430  add rsp, 0x40
00007588ecdd4434  vmovaps xmm0, [rsp]
00007588ecdd4439  vmovaps xmm1, [rsp+0x10]
00007588ecdd443f  vmovaps xmm2, [rsp+0x20]
00007588ecdd4445  vmovaps xmm3, [rsp+0x30]
00007588ecdd444b  vmovaps xmm4, [rsp+0x40]
00007588ecdd4451  vmovaps xmm5, [rsp+0x50]
00007588ecdd4457  vmovaps xmm6, [rsp+0x60]
00007588ecdd445d  vmovaps xmm7, [rsp+0x70]
00007588ecdd4463  vmovaps xmm8, [rsp+0x80]
00007588ecdd446c  vmovaps xmm9, [rsp+0x90]
00007588ecdd4475  vmovaps xmm10, [rsp+0xA0]
00007588ecdd447e  vmovaps xmm11, [rsp+0xB0]
00007588ecdd4487  vmovaps xmm12, [rsp+0xC0]
00007588ecdd4490  vmovaps xmm13, [rsp+0xD0]
00007588ecdd4499  vmovaps xmm14, [rsp+0xE0]
00007588ecdd44a2  add rsp, 0xF0
00007588ecdd44a9  pop r11
00007588ecdd44ab  pop r10
00007588ecdd44ad  pop r9
00007588ecdd44af  pop r8
00007588ecdd44b1  pop rsi
00007588ecdd44b2  pop rdi
00007588ecdd44b3  pop rdx
00007588ecdd44b4  pop rcx
00007588ecdd44b5  pop rax
00007588ecdd44b6  add rsp, 0x08
00007588ecdd44ba  jmp 0x00007588ECDD2D7E
00007588ecdd44bf  sub rsp, 0x08
00007588ecdd44c3  push rax
00007588ecdd44c4  push rcx
00007588ecdd44c5  push rdx
00007588ecdd44c6  push rdi
00007588ecdd44c7  push rsi
00007588ecdd44c8  push r8
00007588ecdd44ca  push r9
00007588ecdd44cc  push r10
00007588ecdd44ce  push r11
00007588ecdd44d0  sub rsp, 0xF0
00007588ecdd44d7  vmovaps [rsp], xmm0
00007588ecdd44dc  vmovaps [rsp+0x10], xmm1
00007588ecdd44e2  vmovaps [rsp+0x20], xmm2
00007588ecdd44e8  vmovaps [rsp+0x30], xmm3
00007588ecdd44ee  vmovaps [rsp+0x40], xmm4
00007588ecdd44f4  vmovaps [rsp+0x50], xmm6
00007588ecdd44fa  vmovaps [rsp+0x60], xmm7
00007588ecdd4500  vmovaps [rsp+0x70], xmm8
00007588ecdd4506  vmovaps [rsp+0x80], xmm9
00007588ecdd450f  vmovaps [rsp+0x90], xmm10
00007588ecdd4518  vmovaps [rsp+0xA0], xmm11
00007588ecdd4521  vmovaps [rsp+0xB0], xmm12
00007588ecdd452a  vmovaps [rsp+0xC0], xmm13
00007588ecdd4533  vmovaps [rsp+0xD0], xmm14
00007588ecdd453c  vmovaps [rsp+0xE0], xmm15
00007588ecdd4545  sub rsp, 0x40
00007588ecdd4549  lea rdi, [rsp]
00007588ecdd454d  lea rsi, [rsp+0x10]
00007588ecdd4552  lea rdx, [rsp+0x20]
00007588ecdd4557  lea rcx, [rsp+0x30]
00007588ecdd455c  mov r8d, 0x00
00007588ecdd4562  lea r9, [r15+0x3A8]
00007588ecdd4569  movaps [rdi], xmm5
00007588ecdd456c  movaps [rsi], xmm13
00007588ecdd4570  movaps [rdx], xmm11
00007588ecdd4574  movaps [rcx], xmm12
00007588ecdd4578  mov rax, 0x6516BF3BBA50
00007588ecdd4582  call rax
00007588ecdd4584  movaps xmm5, [rsp]
00007588ecdd4588  add rsp, 0x40
00007588ecdd458c  vmovaps xmm0, [rsp]
00007588ecdd4591  vmovaps xmm1, [rsp+0x10]
00007588ecdd4597  vmovaps xmm2, [rsp+0x20]
00007588ecdd459d  vmovaps xmm3, [rsp+0x30]
00007588ecdd45a3  vmovaps xmm4, [rsp+0x40]
00007588ecdd45a9  vmovaps xmm6, [rsp+0x50]
00007588ecdd45af  vmovaps xmm7, [rsp+0x60]
00007588ecdd45b5  vmovaps xmm8, [rsp+0x70]
00007588ecdd45bb  vmovaps xmm9, [rsp+0x80]
00007588ecdd45c4  vmovaps xmm10, [rsp+0x90]
00007588ecdd45cd  vmovaps xmm11, [rsp+0xA0]
00007588ecdd45d6  vmovaps xmm12, [rsp+0xB0]
00007588ecdd45df  vmovaps xmm13, [rsp+0xC0]
00007588ecdd45e8  vmovaps xmm14, [rsp+0xD0]
00007588ecdd45f1  vmovaps xmm15, [rsp+0xE0]
00007588ecdd45fa  add rsp, 0xF0
00007588ecdd4601  pop r11
00007588ecdd4603  pop r10
00007588ecdd4605  pop r9
00007588ecdd4607  pop r8
00007588ecdd4609  pop rsi
00007588ecdd460a  pop rdi
00007588ecdd460b  pop rdx
00007588ecdd460c  pop rcx
00007588ecdd460d  pop rax
00007588ecdd460e  add rsp, 0x08
00007588ecdd4612  jmp 0x00007588ECDD2DDD
00007588ecdd4617  sub rsp, 0x08
00007588ecdd461b  push rax
00007588ecdd461c  push rcx
00007588ecdd461d  push rdx
00007588ecdd461e  push rdi
00007588ecdd461f  push rsi
00007588ecdd4620  push r8
00007588ecdd4622  push r9
00007588ecdd4624  push r10
00007588ecdd4626  push r11
00007588ecdd4628  sub rsp, 0xF0
00007588ecdd462f  vmovaps [rsp], xmm0
00007588ecdd4634  vmovaps [rsp+0x10], xmm1
00007588ecdd463a  vmovaps [rsp+0x20], xmm2
00007588ecdd4640  vmovaps [rsp+0x30], xmm3
00007588ecdd4646  vmovaps [rsp+0x40], xmm4
00007588ecdd464c  vmovaps [rsp+0x50], xmm5
00007588ecdd4652  vmovaps [rsp+0x60], xmm6
00007588ecdd4658  vmovaps [rsp+0x70], xmm7
00007588ecdd465e  vmovaps [rsp+0x80], xmm8
00007588ecdd4667  vmovaps [rsp+0x90], xmm9
00007588ecdd4670  vmovaps [rsp+0xA0], xmm10
00007588ecdd4679  vmovaps [rsp+0xB0], xmm11
00007588ecdd4682  vmovaps [rsp+0xC0], xmm13
00007588ecdd468b  vmovaps [rsp+0xD0], xmm14
00007588ecdd4694  vmovaps [rsp+0xE0], xmm15
00007588ecdd469d  sub rsp, 0x40
00007588ecdd46a1  lea rdi, [rsp]
00007588ecdd46a5  lea rsi, [rsp+0x10]
00007588ecdd46aa  lea rdx, [rsp+0x20]
00007588ecdd46af  lea rcx, [rsp+0x30]
00007588ecdd46b4  mov r8d, 0x00
00007588ecdd46ba  lea r9, [r15+0x3A8]
00007588ecdd46c1  movaps [rdi], xmm12
00007588ecdd46c5  movaps [rsi], xmm14
00007588ecdd46c9  movaps [rdx], xmm9
00007588ecdd46cd  movaps [rcx], xmm13
00007588ecdd46d1  mov rax, 0x6516BF3BBA50
00007588ecdd46db  call rax
00007588ecdd46dd  movaps xmm12, [rsp]
00007588ecdd46e2  add rsp, 0x40
00007588ecdd46e6  vmovaps xmm0, [rsp]
00007588ecdd46eb  vmovaps xmm1, [rsp+0x10]
00007588ecdd46f1  vmovaps xmm2, [rsp+0x20]
00007588ecdd46f7  vmovaps xmm3, [rsp+0x30]
00007588ecdd46fd  vmovaps xmm4, [rsp+0x40]
00007588ecdd4703  vmovaps xmm5, [rsp+0x50]
00007588ecdd4709  vmovaps xmm6, [rsp+0x60]
00007588ecdd470f  vmovaps xmm7, [rsp+0x70]
00007588ecdd4715  vmovaps xmm8, [rsp+0x80]
00007588ecdd471e  vmovaps xmm9, [rsp+0x90]
00007588ecdd4727  vmovaps xmm10, [rsp+0xA0]
00007588ecdd4730  vmovaps xmm11, [rsp+0xB0]
00007588ecdd4739  vmovaps xmm13, [rsp+0xC0]
00007588ecdd4742  vmovaps xmm14, [rsp+0xD0]
00007588ecdd474b  vmovaps xmm15, [rsp+0xE0]
00007588ecdd4754  add rsp, 0xF0
00007588ecdd475b  pop r11
00007588ecdd475d  pop r10
00007588ecdd475f  pop r9
00007588ecdd4761  pop r8
00007588ecdd4763  pop rsi
00007588ecdd4764  pop rdi
00007588ecdd4765  pop rdx
00007588ecdd4766  pop rcx
00007588ecdd4767  pop rax
00007588ecdd4768  add rsp, 0x08
00007588ecdd476c  jmp 0x00007588ECDD2E06
00007588ecdd4771  call 0x00007588ECC0D4E0
00007588ecdd4776  jmp 0x00007588ECDD2E13
00007588ecdd477b  sub rsp, 0x08
00007588ecdd477f  push rax
00007588ecdd4780  push rcx
00007588ecdd4781  push rdx
00007588ecdd4782  push rdi
00007588ecdd4783  push rsi
00007588ecdd4784  push r8
00007588ecdd4786  push r9
00007588ecdd4788  push r10
00007588ecdd478a  push r11
00007588ecdd478c  sub rsp, 0xF0
00007588ecdd4793  vmovaps [rsp], xmm0
00007588ecdd4798  vmovaps [rsp+0x10], xmm1
00007588ecdd479e  vmovaps [rsp+0x20], xmm2
00007588ecdd47a4  vmovaps [rsp+0x30], xmm3
00007588ecdd47aa  vmovaps [rsp+0x40], xmm4
00007588ecdd47b0  vmovaps [rsp+0x50], xmm5
00007588ecdd47b6  vmovaps [rsp+0x60], xmm6
00007588ecdd47bc  vmovaps [rsp+0x70], xmm7
00007588ecdd47c2  vmovaps [rsp+0x80], xmm8
00007588ecdd47cb  vmovaps [rsp+0x90], xmm9
00007588ecdd47d4  vmovaps [rsp+0xA0], xmm10
00007588ecdd47dd  vmovaps [rsp+0xB0], xmm12
00007588ecdd47e6  vmovaps [rsp+0xC0], xmm13
00007588ecdd47ef  vmovaps [rsp+0xD0], xmm14
00007588ecdd47f8  vmovaps [rsp+0xE0], xmm15
00007588ecdd4801  sub rsp, 0x40
00007588ecdd4805  lea rdi, [rsp]
00007588ecdd4809  lea rsi, [rsp+0x10]
00007588ecdd480e  lea rdx, [rsp+0x20]
00007588ecdd4813  lea rcx, [rsp+0x30]
00007588ecdd4818  mov r8d, 0x00
00007588ecdd481e  lea r9, [r15+0x3A8]
00007588ecdd4825  movaps [rdi], xmm11
00007588ecdd4829  movaps [rsi], xmm10
00007588ecdd482d  movaps [rdx], xmm8
00007588ecdd4831  movaps [rcx], xmm13
00007588ecdd4835  mov rax, 0x6516BF3BBA50
00007588ecdd483f  call rax
00007588ecdd4841  movaps xmm11, [rsp]
00007588ecdd4846  add rsp, 0x40
00007588ecdd484a  vmovaps xmm0, [rsp]
00007588ecdd484f  vmovaps xmm1, [rsp+0x10]
00007588ecdd4855  vmovaps xmm2, [rsp+0x20]
00007588ecdd485b  vmovaps xmm3, [rsp+0x30]
00007588ecdd4861  vmovaps xmm4, [rsp+0x40]
00007588ecdd4867  vmovaps xmm5, [rsp+0x50]
00007588ecdd486d  vmovaps xmm6, [rsp+0x60]
00007588ecdd4873  vmovaps xmm7, [rsp+0x70]
00007588ecdd4879  vmovaps xmm8, [rsp+0x80]
00007588ecdd4882  vmovaps xmm9, [rsp+0x90]
00007588ecdd488b  vmovaps xmm10, [rsp+0xA0]
00007588ecdd4894  vmovaps xmm12, [rsp+0xB0]
00007588ecdd489d  vmovaps xmm13, [rsp+0xC0]
00007588ecdd48a6  vmovaps xmm14, [rsp+0xD0]
00007588ecdd48af  vmovaps xmm15, [rsp+0xE0]
00007588ecdd48b8  add rsp, 0xF0
00007588ecdd48bf  pop r11
00007588ecdd48c1  pop r10
00007588ecdd48c3  pop r9
00007588ecdd48c5  pop r8
00007588ecdd48c7  pop rsi
00007588ecdd48c8  pop rdi
00007588ecdd48c9  pop rdx
00007588ecdd48ca  pop rcx
00007588ecdd48cb  pop rax
00007588ecdd48cc  add rsp, 0x08
00007588ecdd48d0  jmp 0x00007588ECDD2E44
00007588ecdd48d5  sub rsp, 0x08
00007588ecdd48d9  push rax
00007588ecdd48da  push rcx
00007588ecdd48db  push rdx
00007588ecdd48dc  push rdi
00007588ecdd48dd  push rsi
00007588ecdd48de  push r8
00007588ecdd48e0  push r9
00007588ecdd48e2  push r10
00007588ecdd48e4  push r11
00007588ecdd48e6  sub rsp, 0xF0
00007588ecdd48ed  vmovaps [rsp], xmm0
00007588ecdd48f2  vmovaps [rsp+0x10], xmm1
00007588ecdd48f8  vmovaps [rsp+0x20], xmm2
00007588ecdd48fe  vmovaps [rsp+0x30], xmm3
00007588ecdd4904  vmovaps [rsp+0x40], xmm4
00007588ecdd490a  vmovaps [rsp+0x50], xmm5
00007588ecdd4910  vmovaps [rsp+0x60], xmm6
00007588ecdd4916  vmovaps [rsp+0x70], xmm7
00007588ecdd491c  vmovaps [rsp+0x80], xmm8
00007588ecdd4925  vmovaps [rsp+0x90], xmm9
00007588ecdd492e  vmovaps [rsp+0xA0], xmm11
00007588ecdd4937  vmovaps [rsp+0xB0], xmm12
00007588ecdd4940  vmovaps [rsp+0xC0], xmm13
00007588ecdd4949  vmovaps [rsp+0xD0], xmm14
00007588ecdd4952  vmovaps [rsp+0xE0], xmm15
00007588ecdd495b  sub rsp, 0x40
00007588ecdd495f  lea rdi, [rsp]
00007588ecdd4963  lea rsi, [rsp+0x10]
00007588ecdd4968  lea rdx, [rsp+0x20]
00007588ecdd496d  lea rcx, [rsp+0x30]
00007588ecdd4972  mov r8d, 0x00
00007588ecdd4978  lea r9, [r15+0x3A8]
00007588ecdd497f  movaps [rdi], xmm10
00007588ecdd4983  movaps [rsi], xmm15
00007588ecdd4987  movaps [rdx], xmm1
00007588ecdd498a  movaps [rcx], xmm13
00007588ecdd498e  mov rax, 0x6516BF3BBA50
00007588ecdd4998  call rax
00007588ecdd499a  movaps xmm10, [rsp]
00007588ecdd499f  add rsp, 0x40
00007588ecdd49a3  vmovaps xmm0, [rsp]
00007588ecdd49a8  vmovaps xmm1, [rsp+0x10]
00007588ecdd49ae  vmovaps xmm2, [rsp+0x20]
00007588ecdd49b4  vmovaps xmm3, [rsp+0x30]
00007588ecdd49ba  vmovaps xmm4, [rsp+0x40]
00007588ecdd49c0  vmovaps xmm5, [rsp+0x50]
00007588ecdd49c6  vmovaps xmm6, [rsp+0x60]
00007588ecdd49cc  vmovaps xmm7, [rsp+0x70]
00007588ecdd49d2  vmovaps xmm8, [rsp+0x80]
00007588ecdd49db  vmovaps xmm9, [rsp+0x90]
00007588ecdd49e4  vmovaps xmm11, [rsp+0xA0]
00007588ecdd49ed  vmovaps xmm12, [rsp+0xB0]
00007588ecdd49f6  vmovaps xmm13, [rsp+0xC0]
00007588ecdd49ff  vmovaps xmm14, [rsp+0xD0]
00007588ecdd4a08  vmovaps xmm15, [rsp+0xE0]
00007588ecdd4a11  add rsp, 0xF0
00007588ecdd4a18  pop r11
00007588ecdd4a1a  pop r10
00007588ecdd4a1c  pop r9
00007588ecdd4a1e  pop r8
00007588ecdd4a20  pop rsi
00007588ecdd4a21  pop rdi
00007588ecdd4a22  pop rdx
00007588ecdd4a23  pop rcx
00007588ecdd4a24  pop rax
00007588ecdd4a25  add rsp, 0x08
00007588ecdd4a29  jmp 0x00007588ECDD2E6D
00007588ecdd4a2e  call 0x00007588ECBFF430
00007588ecdd4a33  jmp 0x00007588ECDD2E8F
00007588ecdd4a38  call 0x00007588ECC0E760
00007588ecdd4a3d  jmp 0x00007588ECDD2E99
00007588ecdd4a42  sub rsp, 0x08
00007588ecdd4a46  push rax
00007588ecdd4a47  push rcx
00007588ecdd4a48  push rdx
00007588ecdd4a49  push rdi
00007588ecdd4a4a  push rsi
00007588ecdd4a4b  push r8
00007588ecdd4a4d  push r9
00007588ecdd4a4f  push r10
00007588ecdd4a51  push r11
00007588ecdd4a53  sub rsp, 0xF0
00007588ecdd4a5a  vmovaps [rsp], xmm0
00007588ecdd4a5f  vmovaps [rsp+0x10], xmm1
00007588ecdd4a65  vmovaps [rsp+0x20], xmm2
00007588ecdd4a6b  vmovaps [rsp+0x30], xmm3
00007588ecdd4a71  vmovaps [rsp+0x40], xmm4
00007588ecdd4a77  vmovaps [rsp+0x50], xmm5
00007588ecdd4a7d  vmovaps [rsp+0x60], xmm6
00007588ecdd4a83  vmovaps [rsp+0x70], xmm7
00007588ecdd4a89  vmovaps [rsp+0x80], xmm9
00007588ecdd4a92  vmovaps [rsp+0x90], xmm10
00007588ecdd4a9b  vmovaps [rsp+0xA0], xmm11
00007588ecdd4aa4  vmovaps [rsp+0xB0], xmm12
00007588ecdd4aad  vmovaps [rsp+0xC0], xmm13
00007588ecdd4ab6  vmovaps [rsp+0xD0], xmm14
00007588ecdd4abf  vmovaps [rsp+0xE0], xmm15
00007588ecdd4ac8  sub rsp, 0x40
00007588ecdd4acc  lea rdi, [rsp]
00007588ecdd4ad0  lea rsi, [rsp+0x10]
00007588ecdd4ad5  lea rdx, [rsp+0x20]
00007588ecdd4ada  lea rcx, [rsp+0x30]
00007588ecdd4adf  mov r8d, 0x00
00007588ecdd4ae5  lea r9, [r15+0x3A8]
00007588ecdd4aec  movaps [rdi], xmm8
00007588ecdd4af0  movaps [rsi], xmm5
00007588ecdd4af3  movaps [rdx], xmm9
00007588ecdd4af7  movaps [rcx], xmm13
00007588ecdd4afb  mov rax, 0x6516BF3BBA50
00007588ecdd4b05  call rax
00007588ecdd4b07  movaps xmm8, [rsp]
00007588ecdd4b0c  add rsp, 0x40
00007588ecdd4b10  vmovaps xmm0, [rsp]
00007588ecdd4b15  vmovaps xmm1, [rsp+0x10]
00007588ecdd4b1b  vmovaps xmm2, [rsp+0x20]
00007588ecdd4b21  vmovaps xmm3, [rsp+0x30]
00007588ecdd4b27  vmovaps xmm4, [rsp+0x40]
00007588ecdd4b2d  vmovaps xmm5, [rsp+0x50]
00007588ecdd4b33  vmovaps xmm6, [rsp+0x60]
00007588ecdd4b39  vmovaps xmm7, [rsp+0x70]
00007588ecdd4b3f  vmovaps xmm9, [rsp+0x80]
00007588ecdd4b48  vmovaps xmm10, [rsp+0x90]
00007588ecdd4b51  vmovaps xmm11, [rsp+0xA0]
00007588ecdd4b5a  vmovaps xmm12, [rsp+0xB0]
00007588ecdd4b63  vmovaps xmm13, [rsp+0xC0]
00007588ecdd4b6c  vmovaps xmm14, [rsp+0xD0]
00007588ecdd4b75  vmovaps xmm15, [rsp+0xE0]
00007588ecdd4b7e  add rsp, 0xF0
00007588ecdd4b85  pop r11
00007588ecdd4b87  pop r10
00007588ecdd4b89  pop r9
00007588ecdd4b8b  pop r8
00007588ecdd4b8d  pop rsi
00007588ecdd4b8e  pop rdi
00007588ecdd4b8f  pop rdx
00007588ecdd4b90  pop rcx
00007588ecdd4b91  pop rax
00007588ecdd4b92  add rsp, 0x08
00007588ecdd4b96  jmp 0x00007588ECDD2ED8
00007588ecdd4b9b  sub rsp, 0x08
00007588ecdd4b9f  push rax
00007588ecdd4ba0  push rcx
00007588ecdd4ba1  push rdx
00007588ecdd4ba2  push rdi
00007588ecdd4ba3  push rsi
00007588ecdd4ba4  push r8
00007588ecdd4ba6  push r9
00007588ecdd4ba8  push r10
00007588ecdd4baa  push r11
00007588ecdd4bac  sub rsp, 0xF0
00007588ecdd4bb3  vmovaps [rsp], xmm0
00007588ecdd4bb8  vmovaps [rsp+0x10], xmm1
00007588ecdd4bbe  vmovaps [rsp+0x20], xmm2
00007588ecdd4bc4  vmovaps [rsp+0x30], xmm3
00007588ecdd4bca  vmovaps [rsp+0x40], xmm4
00007588ecdd4bd0  vmovaps [rsp+0x50], xmm5
00007588ecdd4bd6  vmovaps [rsp+0x60], xmm6
00007588ecdd4bdc  vmovaps [rsp+0x70], xmm7
00007588ecdd4be2  vmovaps [rsp+0x80], xmm8
00007588ecdd4beb  vmovaps [rsp+0x90], xmm10
00007588ecdd4bf4  vmovaps [rsp+0xA0], xmm11
00007588ecdd4bfd  vmovaps [rsp+0xB0], xmm12
00007588ecdd4c06  vmovaps [rsp+0xC0], xmm13
00007588ecdd4c0f  vmovaps [rsp+0xD0], xmm14
00007588ecdd4c18  vmovaps [rsp+0xE0], xmm15
00007588ecdd4c21  sub rsp, 0x40
00007588ecdd4c25  lea rdi, [rsp]
00007588ecdd4c29  lea rsi, [rsp+0x10]
00007588ecdd4c2e  lea rdx, [rsp+0x20]
00007588ecdd4c33  lea rcx, [rsp+0x30]
00007588ecdd4c38  mov r8d, 0x00
00007588ecdd4c3e  lea r9, [r15+0x3A8]
00007588ecdd4c45  movaps [rdi], xmm9
00007588ecdd4c49  movaps [rsi], xmm12
00007588ecdd4c4d  movaps [rdx], xmm7
00007588ecdd4c50  movaps [rcx], xmm13
00007588ecdd4c54  mov rax, 0x6516BF3BBA50
00007588ecdd4c5e  call rax
00007588ecdd4c60  movaps xmm9, [rsp]
00007588ecdd4c65  add rsp, 0x40
00007588ecdd4c69  vmovaps xmm0, [rsp]
00007588ecdd4c6e  vmovaps xmm1, [rsp+0x10]
00007588ecdd4c74  vmovaps xmm2, [rsp+0x20]
00007588ecdd4c7a  vmovaps xmm3, [rsp+0x30]
00007588ecdd4c80  vmovaps xmm4, [rsp+0x40]
00007588ecdd4c86  vmovaps xmm5, [rsp+0x50]
00007588ecdd4c8c  vmovaps xmm6, [rsp+0x60]
00007588ecdd4c92  vmovaps xmm7, [rsp+0x70]
00007588ecdd4c98  vmovaps xmm8, [rsp+0x80]
00007588ecdd4ca1  vmovaps xmm10, [rsp+0x90]
00007588ecdd4caa  vmovaps xmm11, [rsp+0xA0]
00007588ecdd4cb3  vmovaps xmm12, [rsp+0xB0]
00007588ecdd4cbc  vmovaps xmm13, [rsp+0xC0]
00007588ecdd4cc5  vmovaps xmm14, [rsp+0xD0]
00007588ecdd4cce  vmovaps xmm15, [rsp+0xE0]
00007588ecdd4cd7  add rsp, 0xF0
00007588ecdd4cde  pop r11
00007588ecdd4ce0  pop r10
00007588ecdd4ce2  pop r9
00007588ecdd4ce4  pop r8
00007588ecdd4ce6  pop rsi
00007588ecdd4ce7  pop rdi
00007588ecdd4ce8  pop rdx
00007588ecdd4ce9  pop rcx
00007588ecdd4cea  pop rax
00007588ecdd4ceb  add rsp, 0x08
00007588ecdd4cef  jmp 0x00007588ECDD2F01
00007588ecdd4cf4  sub rsp, 0x08
00007588ecdd4cf8  push rax
00007588ecdd4cf9  push rcx
00007588ecdd4cfa  push rdx
00007588ecdd4cfb  push rdi
00007588ecdd4cfc  push rsi
00007588ecdd4cfd  push r8
00007588ecdd4cff  push r9
00007588ecdd4d01  push r10
00007588ecdd4d03  push r11
00007588ecdd4d05  sub rsp, 0xF0
00007588ecdd4d0c  vmovaps [rsp], xmm0
00007588ecdd4d11  vmovaps [rsp+0x10], xmm1
00007588ecdd4d17  vmovaps [rsp+0x20], xmm2
00007588ecdd4d1d  vmovaps [rsp+0x30], xmm3
00007588ecdd4d23  vmovaps [rsp+0x40], xmm4
00007588ecdd4d29  vmovaps [rsp+0x50], xmm5
00007588ecdd4d2f  vmovaps [rsp+0x60], xmm6
00007588ecdd4d35  vmovaps [rsp+0x70], xmm7
00007588ecdd4d3b  vmovaps [rsp+0x80], xmm8
00007588ecdd4d44  vmovaps [rsp+0x90], xmm9
00007588ecdd4d4d  vmovaps [rsp+0xA0], xmm10
00007588ecdd4d56  vmovaps [rsp+0xB0], xmm11
00007588ecdd4d5f  vmovaps [rsp+0xC0], xmm13
00007588ecdd4d68  vmovaps [rsp+0xD0], xmm14
00007588ecdd4d71  vmovaps [rsp+0xE0], xmm15
00007588ecdd4d7a  sub rsp, 0x40
00007588ecdd4d7e  lea rdi, [rsp]
00007588ecdd4d82  lea rsi, [rsp+0x10]
00007588ecdd4d87  lea rdx, [rsp+0x20]
00007588ecdd4d8c  lea rcx, [rsp+0x30]
00007588ecdd4d91  mov r8d, 0x00
00007588ecdd4d97  lea r9, [r15+0x3A8]
00007588ecdd4d9e  movaps [rdi], xmm12
00007588ecdd4da2  movaps [rsi], xmm11
00007588ecdd4da6  movaps [rdx], xmm6
00007588ecdd4da9  movaps [rcx], xmm13
00007588ecdd4dad  mov rax, 0x6516BF3BBA50
00007588ecdd4db7  call rax
00007588ecdd4db9  movaps xmm12, [rsp]
00007588ecdd4dbe  add rsp, 0x40
00007588ecdd4dc2  vmovaps xmm0, [rsp]
00007588ecdd4dc7  vmovaps xmm1, [rsp+0x10]
00007588ecdd4dcd  vmovaps xmm2, [rsp+0x20]
00007588ecdd4dd3  vmovaps xmm3, [rsp+0x30]
00007588ecdd4dd9  vmovaps xmm4, [rsp+0x40]
00007588ecdd4ddf  vmovaps xmm5, [rsp+0x50]
00007588ecdd4de5  vmovaps xmm6, [rsp+0x60]
00007588ecdd4deb  vmovaps xmm7, [rsp+0x70]
00007588ecdd4df1  vmovaps xmm8, [rsp+0x80]
00007588ecdd4dfa  vmovaps xmm9, [rsp+0x90]
00007588ecdd4e03  vmovaps xmm10, [rsp+0xA0]
00007588ecdd4e0c  vmovaps xmm11, [rsp+0xB0]
00007588ecdd4e15  vmovaps xmm13, [rsp+0xC0]
00007588ecdd4e1e  vmovaps xmm14, [rsp+0xD0]
00007588ecdd4e27  vmovaps xmm15, [rsp+0xE0]
00007588ecdd4e30  add rsp, 0xF0
00007588ecdd4e37  pop r11
00007588ecdd4e39  pop r10
00007588ecdd4e3b  pop r9
00007588ecdd4e3d  pop r8
00007588ecdd4e3f  pop rsi
00007588ecdd4e40  pop rdi
00007588ecdd4e41  pop rdx
00007588ecdd4e42  pop rcx
00007588ecdd4e43  pop rax
00007588ecdd4e44  add rsp, 0x08
00007588ecdd4e48  jmp 0x00007588ECDD2F2A
00007588ecdd4e4d  sub rsp, 0x08
00007588ecdd4e51  push rax
00007588ecdd4e52  push rcx
00007588ecdd4e53  push rdx
00007588ecdd4e54  push rdi
00007588ecdd4e55  push rsi
00007588ecdd4e56  push r8
00007588ecdd4e58  push r9
00007588ecdd4e5a  push r10
00007588ecdd4e5c  push r11
00007588ecdd4e5e  sub rsp, 0xF0
00007588ecdd4e65  vmovaps [rsp], xmm0
00007588ecdd4e6a  vmovaps [rsp+0x10], xmm1
00007588ecdd4e70  vmovaps [rsp+0x20], xmm2
00007588ecdd4e76  vmovaps [rsp+0x30], xmm3
00007588ecdd4e7c  vmovaps [rsp+0x40], xmm4
00007588ecdd4e82  vmovaps [rsp+0x50], xmm5
00007588ecdd4e88  vmovaps [rsp+0x60], xmm6
00007588ecdd4e8e  vmovaps [rsp+0x70], xmm8
00007588ecdd4e94  vmovaps [rsp+0x80], xmm9
00007588ecdd4e9d  vmovaps [rsp+0x90], xmm10
00007588ecdd4ea6  vmovaps [rsp+0xA0], xmm11
00007588ecdd4eaf  vmovaps [rsp+0xB0], xmm12
00007588ecdd4eb8  vmovaps [rsp+0xC0], xmm13
00007588ecdd4ec1  vmovaps [rsp+0xD0], xmm14
00007588ecdd4eca  vmovaps [rsp+0xE0], xmm15
00007588ecdd4ed3  sub rsp, 0x40
00007588ecdd4ed7  lea rdi, [rsp]
00007588ecdd4edb  lea rsi, [rsp+0x10]
00007588ecdd4ee0  lea rdx, [rsp+0x20]
00007588ecdd4ee5  lea rcx, [rsp+0x30]
00007588ecdd4eea  mov r8d, 0x00
00007588ecdd4ef0  lea r9, [r15+0x3A8]
00007588ecdd4ef7  movaps [rdi], xmm7
00007588ecdd4efa  movaps [rsi], xmm10
00007588ecdd4efe  movaps [rdx], xmm11
00007588ecdd4f02  movaps [rcx], xmm13
00007588ecdd4f06  mov rax, 0x6516BF3BBA50
00007588ecdd4f10  call rax
00007588ecdd4f12  movaps xmm7, [rsp]
00007588ecdd4f16  add rsp, 0x40
00007588ecdd4f1a  vmovaps xmm0, [rsp]
00007588ecdd4f1f  vmovaps xmm1, [rsp+0x10]
00007588ecdd4f25  vmovaps xmm2, [rsp+0x20]
00007588ecdd4f2b  vmovaps xmm3, [rsp+0x30]
00007588ecdd4f31  vmovaps xmm4, [rsp+0x40]
00007588ecdd4f37  vmovaps xmm5, [rsp+0x50]
00007588ecdd4f3d  vmovaps xmm6, [rsp+0x60]
00007588ecdd4f43  vmovaps xmm8, [rsp+0x70]
00007588ecdd4f49  vmovaps xmm9, [rsp+0x80]
00007588ecdd4f52  vmovaps xmm10, [rsp+0x90]
00007588ecdd4f5b  vmovaps xmm11, [rsp+0xA0]
00007588ecdd4f64  vmovaps xmm12, [rsp+0xB0]
00007588ecdd4f6d  vmovaps xmm13, [rsp+0xC0]
00007588ecdd4f76  vmovaps xmm14, [rsp+0xD0]
00007588ecdd4f7f  vmovaps xmm15, [rsp+0xE0]
00007588ecdd4f88  add rsp, 0xF0
00007588ecdd4f8f  pop r11
00007588ecdd4f91  pop r10
00007588ecdd4f93  pop r9
00007588ecdd4f95  pop r8
00007588ecdd4f97  pop rsi
00007588ecdd4f98  pop rdi
00007588ecdd4f99  pop rdx
00007588ecdd4f9a  pop rcx
00007588ecdd4f9b  pop rax
00007588ecdd4f9c  add rsp, 0x08
00007588ecdd4fa0  jmp 0x00007588ECDD2F58
00007588ecdd4fa5  call 0x00007588ECC0C260
00007588ecdd4faa  jmp 0x00007588ECDD2F62
00007588ecdd4faf  call 0x00007588ECC09D70
00007588ecdd4fb4  jmp 0x00007588ECDD2F6C
00007588ecdd4fb9  sub rsp, 0x08
00007588ecdd4fbd  push rax
00007588ecdd4fbe  push rcx
00007588ecdd4fbf  push rdx
00007588ecdd4fc0  push rdi
00007588ecdd4fc1  push rsi
00007588ecdd4fc2  push r8
00007588ecdd4fc4  push r9
00007588ecdd4fc6  push r10
00007588ecdd4fc8  push r11
00007588ecdd4fca  sub rsp, 0xF0
00007588ecdd4fd1  vmovaps [rsp], xmm0
00007588ecdd4fd6  vmovaps [rsp+0x10], xmm1
00007588ecdd4fdc  vmovaps [rsp+0x20], xmm2
00007588ecdd4fe2  vmovaps [rsp+0x30], xmm3
00007588ecdd4fe8  vmovaps [rsp+0x40], xmm4
00007588ecdd4fee  vmovaps [rsp+0x50], xmm5
00007588ecdd4ff4  vmovaps [rsp+0x60], xmm7
00007588ecdd4ffa  vmovaps [rsp+0x70], xmm8
00007588ecdd5000  vmovaps [rsp+0x80], xmm9
00007588ecdd5009  vmovaps [rsp+0x90], xmm10
00007588ecdd5012  vmovaps [rsp+0xA0], xmm11
00007588ecdd501b  vmovaps [rsp+0xB0], xmm12
00007588ecdd5024  vmovaps [rsp+0xC0], xmm13
00007588ecdd502d  vmovaps [rsp+0xD0], xmm14
00007588ecdd5036  vmovaps [rsp+0xE0], xmm15
00007588ecdd503f  sub rsp, 0x40
00007588ecdd5043  lea rdi, [rsp]
00007588ecdd5047  lea rsi, [rsp+0x10]
00007588ecdd504c  lea rdx, [rsp+0x20]
00007588ecdd5051  lea rcx, [rsp+0x30]
00007588ecdd5056  mov r8d, 0x00
00007588ecdd505c  lea r9, [r15+0x3A8]
00007588ecdd5063  movaps [rdi], xmm6
00007588ecdd5066  movaps [rsi], xmm8
00007588ecdd506a  movaps [rdx], xmm15
00007588ecdd506e  movaps [rcx], xmm10
00007588ecdd5072  mov rax, 0x6516BF3BBA50
00007588ecdd507c  call rax
00007588ecdd507e  movaps xmm6, [rsp]
00007588ecdd5082  add rsp, 0x40
00007588ecdd5086  vmovaps xmm0, [rsp]
00007588ecdd508b  vmovaps xmm1, [rsp+0x10]
00007588ecdd5091  vmovaps xmm2, [rsp+0x20]
00007588ecdd5097  vmovaps xmm3, [rsp+0x30]
00007588ecdd509d  vmovaps xmm4, [rsp+0x40]
00007588ecdd50a3  vmovaps xmm5, [rsp+0x50]
00007588ecdd50a9  vmovaps xmm7, [rsp+0x60]
00007588ecdd50af  vmovaps xmm8, [rsp+0x70]
00007588ecdd50b5  vmovaps xmm9, [rsp+0x80]
00007588ecdd50be  vmovaps xmm10, [rsp+0x90]
00007588ecdd50c7  vmovaps xmm11, [rsp+0xA0]
00007588ecdd50d0  vmovaps xmm12, [rsp+0xB0]
00007588ecdd50d9  vmovaps xmm13, [rsp+0xC0]
00007588ecdd50e2  vmovaps xmm14, [rsp+0xD0]
00007588ecdd50eb  vmovaps xmm15, [rsp+0xE0]
00007588ecdd50f4  add rsp, 0xF0
00007588ecdd50fb  pop r11
00007588ecdd50fd  pop r10
00007588ecdd50ff  pop r9
00007588ecdd5101  pop r8
00007588ecdd5103  pop rsi
00007588ecdd5104  pop rdi
00007588ecdd5105  pop rdx
00007588ecdd5106  pop rcx
00007588ecdd5107  pop rax
00007588ecdd5108  add rsp, 0x08
00007588ecdd510c  jmp 0x00007588ECDD2FA4
00007588ecdd5111  sub rsp, 0x08
00007588ecdd5115  push rax
00007588ecdd5116  push rcx
00007588ecdd5117  push rdx
00007588ecdd5118  push rdi
00007588ecdd5119  push rsi
00007588ecdd511a  push r8
00007588ecdd511c  push r9
00007588ecdd511e  push r10
00007588ecdd5120  push r11
00007588ecdd5122  sub rsp, 0xF0
00007588ecdd5129  vmovaps [rsp], xmm0
00007588ecdd512e  vmovaps [rsp+0x10], xmm1
00007588ecdd5134  vmovaps [rsp+0x20], xmm2
00007588ecdd513a  vmovaps [rsp+0x30], xmm3
00007588ecdd5140  vmovaps [rsp+0x40], xmm4
00007588ecdd5146  vmovaps [rsp+0x50], xmm5
00007588ecdd514c  vmovaps [rsp+0x60], xmm6
00007588ecdd5152  vmovaps [rsp+0x70], xmm7
00007588ecdd5158  vmovaps [rsp+0x80], xmm8
00007588ecdd5161  vmovaps [rsp+0x90], xmm9
00007588ecdd516a  vmovaps [rsp+0xA0], xmm11
00007588ecdd5173  vmovaps [rsp+0xB0], xmm12
00007588ecdd517c  vmovaps [rsp+0xC0], xmm13
00007588ecdd5185  vmovaps [rsp+0xD0], xmm14
00007588ecdd518e  vmovaps [rsp+0xE0], xmm15
00007588ecdd5197  sub rsp, 0x40
00007588ecdd519b  lea rdi, [rsp]
00007588ecdd519f  lea rsi, [rsp+0x10]
00007588ecdd51a4  lea rdx, [rsp+0x20]
00007588ecdd51a9  lea rcx, [rsp+0x30]
00007588ecdd51ae  mov r8d, 0x00
00007588ecdd51b4  lea r9, [r15+0x3A8]
00007588ecdd51bb  movaps [rdi], xmm10
00007588ecdd51bf  movaps [rsi], xmm9
00007588ecdd51c3  movaps [rdx], xmm13
00007588ecdd51c7  movaps [rcx], xmm15
00007588ecdd51cb  mov rax, 0x6516BF3BBA50
00007588ecdd51d5  call rax
00007588ecdd51d7  movaps xmm10, [rsp]
00007588ecdd51dc  add rsp, 0x40
00007588ecdd51e0  vmovaps xmm0, [rsp]
00007588ecdd51e5  vmovaps xmm1, [rsp+0x10]
00007588ecdd51eb  vmovaps xmm2, [rsp+0x20]
00007588ecdd51f1  vmovaps xmm3, [rsp+0x30]
00007588ecdd51f7  vmovaps xmm4, [rsp+0x40]
00007588ecdd51fd  vmovaps xmm5, [rsp+0x50]
00007588ecdd5203  vmovaps xmm6, [rsp+0x60]
00007588ecdd5209  vmovaps xmm7, [rsp+0x70]
00007588ecdd520f  vmovaps xmm8, [rsp+0x80]
00007588ecdd5218  vmovaps xmm9, [rsp+0x90]
00007588ecdd5221  vmovaps xmm11, [rsp+0xA0]
00007588ecdd522a  vmovaps xmm12, [rsp+0xB0]
00007588ecdd5233  vmovaps xmm13, [rsp+0xC0]
00007588ecdd523c  vmovaps xmm14, [rsp+0xD0]
00007588ecdd5245  vmovaps xmm15, [rsp+0xE0]
00007588ecdd524e  add rsp, 0xF0
00007588ecdd5255  pop r11
00007588ecdd5257  pop r10
00007588ecdd5259  pop r9
00007588ecdd525b  pop r8
00007588ecdd525d  pop rsi
00007588ecdd525e  pop rdi
00007588ecdd525f  pop rdx
00007588ecdd5260  pop rcx
00007588ecdd5261  pop rax
00007588ecdd5262  add rsp, 0x08
00007588ecdd5266  jmp 0x00007588ECDD2FCD
00007588ecdd526b  sub rsp, 0x08
00007588ecdd526f  push rax
00007588ecdd5270  push rcx
00007588ecdd5271  push rdx
00007588ecdd5272  push rdi
00007588ecdd5273  push rsi
00007588ecdd5274  push r8
00007588ecdd5276  push r9
00007588ecdd5278  push r10
00007588ecdd527a  push r11
00007588ecdd527c  sub rsp, 0xF0
00007588ecdd5283  vmovaps [rsp], xmm0
00007588ecdd5288  vmovaps [rsp+0x10], xmm1
00007588ecdd528e  vmovaps [rsp+0x20], xmm2
00007588ecdd5294  vmovaps [rsp+0x30], xmm3
00007588ecdd529a  vmovaps [rsp+0x40], xmm4
00007588ecdd52a0  vmovaps [rsp+0x50], xmm5
00007588ecdd52a6  vmovaps [rsp+0x60], xmm6
00007588ecdd52ac  vmovaps [rsp+0x70], xmm7
00007588ecdd52b2  vmovaps [rsp+0x80], xmm8
00007588ecdd52bb  vmovaps [rsp+0x90], xmm9
00007588ecdd52c4  vmovaps [rsp+0xA0], xmm10
00007588ecdd52cd  vmovaps [rsp+0xB0], xmm11
00007588ecdd52d6  vmovaps [rsp+0xC0], xmm12
00007588ecdd52df  vmovaps [rsp+0xD0], xmm14
00007588ecdd52e8  vmovaps [rsp+0xE0], xmm15
00007588ecdd52f1  sub rsp, 0x40
00007588ecdd52f5  lea rdi, [rsp]
00007588ecdd52f9  lea rsi, [rsp+0x10]
00007588ecdd52fe  lea rdx, [rsp+0x20]
00007588ecdd5303  lea rcx, [rsp+0x30]
00007588ecdd5308  mov r8d, 0x00
00007588ecdd530e  lea r9, [r15+0x3A8]
00007588ecdd5315  movaps [rdi], xmm13
00007588ecdd5319  movaps [rsi], xmm12
00007588ecdd531d  movaps [rdx], xmm4
00007588ecdd5320  movaps [rcx], xmm15
00007588ecdd5324  mov rax, 0x6516BF3BBA50
00007588ecdd532e  call rax
00007588ecdd5330  movaps xmm13, [rsp]
00007588ecdd5335  add rsp, 0x40
00007588ecdd5339  vmovaps xmm0, [rsp]
00007588ecdd533e  vmovaps xmm1, [rsp+0x10]
00007588ecdd5344  vmovaps xmm2, [rsp+0x20]
00007588ecdd534a  vmovaps xmm3, [rsp+0x30]
00007588ecdd5350  vmovaps xmm4, [rsp+0x40]
00007588ecdd5356  vmovaps xmm5, [rsp+0x50]
00007588ecdd535c  vmovaps xmm6, [rsp+0x60]
00007588ecdd5362  vmovaps xmm7, [rsp+0x70]
00007588ecdd5368  vmovaps xmm8, [rsp+0x80]
00007588ecdd5371  vmovaps xmm9, [rsp+0x90]
00007588ecdd537a  vmovaps xmm10, [rsp+0xA0]
00007588ecdd5383  vmovaps xmm11, [rsp+0xB0]
00007588ecdd538c  vmovaps xmm12, [rsp+0xC0]
00007588ecdd5395  vmovaps xmm14, [rsp+0xD0]
00007588ecdd539e  vmovaps xmm15, [rsp+0xE0]
00007588ecdd53a7  add rsp, 0xF0
00007588ecdd53ae  pop r11
00007588ecdd53b0  pop r10
00007588ecdd53b2  pop r9
00007588ecdd53b4  pop r8
00007588ecdd53b6  pop rsi
00007588ecdd53b7  pop rdi
00007588ecdd53b8  pop rdx
00007588ecdd53b9  pop rcx
00007588ecdd53ba  pop rax
00007588ecdd53bb  add rsp, 0x08
00007588ecdd53bf  jmp 0x00007588ECDD2FF6
00007588ecdd53c4  sub rsp, 0x08
00007588ecdd53c8  push rax
00007588ecdd53c9  push rcx
00007588ecdd53ca  push rdx
00007588ecdd53cb  push rdi
00007588ecdd53cc  push rsi
00007588ecdd53cd  push r8
00007588ecdd53cf  push r9
00007588ecdd53d1  push r10
00007588ecdd53d3  push r11
00007588ecdd53d5  sub rsp, 0xF0
00007588ecdd53dc  vmovaps [rsp], xmm0
00007588ecdd53e1  vmovaps [rsp+0x10], xmm1
00007588ecdd53e7  vmovaps [rsp+0x20], xmm2
00007588ecdd53ed  vmovaps [rsp+0x30], xmm3
00007588ecdd53f3  vmovaps [rsp+0x40], xmm4
00007588ecdd53f9  vmovaps [rsp+0x50], xmm5
00007588ecdd53ff  vmovaps [rsp+0x60], xmm6
00007588ecdd5405  vmovaps [rsp+0x70], xmm7
00007588ecdd540b  vmovaps [rsp+0x80], xmm8
00007588ecdd5414  vmovaps [rsp+0x90], xmm9
00007588ecdd541d  vmovaps [rsp+0xA0], xmm10
00007588ecdd5426  vmovaps [rsp+0xB0], xmm11
00007588ecdd542f  vmovaps [rsp+0xC0], xmm13
00007588ecdd5438  vmovaps [rsp+0xD0], xmm14
00007588ecdd5441  vmovaps [rsp+0xE0], xmm15
00007588ecdd544a  sub rsp, 0x40
00007588ecdd544e  lea rdi, [rsp]
00007588ecdd5452  lea rsi, [rsp+0x10]
00007588ecdd5457  lea rdx, [rsp+0x20]
00007588ecdd545c  lea rcx, [rsp+0x30]
00007588ecdd5461  mov r8d, 0x00
00007588ecdd5467  lea r9, [r15+0x3A8]
00007588ecdd546e  movaps [rdi], xmm12
00007588ecdd5472  movaps [rsi], xmm7
00007588ecdd5475  movaps [rdx], xmm1
00007588ecdd5478  movaps [rcx], xmm15
00007588ecdd547c  mov rax, 0x6516BF3BBA50
00007588ecdd5486  call rax
00007588ecdd5488  movaps xmm12, [rsp]
00007588ecdd548d  add rsp, 0x40
00007588ecdd5491  vmovaps xmm0, [rsp]
00007588ecdd5496  vmovaps xmm1, [rsp+0x10]
00007588ecdd549c  vmovaps xmm2, [rsp+0x20]
00007588ecdd54a2  vmovaps xmm3, [rsp+0x30]
00007588ecdd54a8  vmovaps xmm4, [rsp+0x40]
00007588ecdd54ae  vmovaps xmm5, [rsp+0x50]
00007588ecdd54b4  vmovaps xmm6, [rsp+0x60]
00007588ecdd54ba  vmovaps xmm7, [rsp+0x70]
00007588ecdd54c0  vmovaps xmm8, [rsp+0x80]
00007588ecdd54c9  vmovaps xmm9, [rsp+0x90]
00007588ecdd54d2  vmovaps xmm10, [rsp+0xA0]
00007588ecdd54db  vmovaps xmm11, [rsp+0xB0]
00007588ecdd54e4  vmovaps xmm13, [rsp+0xC0]
00007588ecdd54ed  vmovaps xmm14, [rsp+0xD0]
00007588ecdd54f6  vmovaps xmm15, [rsp+0xE0]
00007588ecdd54ff  add rsp, 0xF0
00007588ecdd5506  pop r11
00007588ecdd5508  pop r10
00007588ecdd550a  pop r9
00007588ecdd550c  pop r8
00007588ecdd550e  pop rsi
00007588ecdd550f  pop rdi
00007588ecdd5510  pop rdx
00007588ecdd5511  pop rcx
00007588ecdd5512  pop rax
00007588ecdd5513  add rsp, 0x08
00007588ecdd5517  jmp 0x00007588ECDD301F
00007588ecdd551c  call 0x00007588ECBFF430
00007588ecdd5521  jmp 0x00007588ECDD3029
00007588ecdd5526  call 0x00007588ECC0E760
00007588ecdd552b  jmp 0x00007588ECDD3033
00007588ecdd5530  sub rsp, 0x08
00007588ecdd5534  push rax
00007588ecdd5535  push rcx
00007588ecdd5536  push rdx
00007588ecdd5537  push rdi
00007588ecdd5538  push rsi
00007588ecdd5539  push r8
00007588ecdd553b  push r9
00007588ecdd553d  push r10
00007588ecdd553f  push r11
00007588ecdd5541  sub rsp, 0xF0
00007588ecdd5548  vmovaps [rsp], xmm0
00007588ecdd554d  vmovaps [rsp+0x10], xmm1
00007588ecdd5553  vmovaps [rsp+0x20], xmm2
00007588ecdd5559  vmovaps [rsp+0x30], xmm3
00007588ecdd555f  vmovaps [rsp+0x40], xmm4
00007588ecdd5565  vmovaps [rsp+0x50], xmm5
00007588ecdd556b  vmovaps [rsp+0x60], xmm6
00007588ecdd5571  vmovaps [rsp+0x70], xmm8
00007588ecdd5577  vmovaps [rsp+0x80], xmm9
00007588ecdd5580  vmovaps [rsp+0x90], xmm10
00007588ecdd5589  vmovaps [rsp+0xA0], xmm11
00007588ecdd5592  vmovaps [rsp+0xB0], xmm12
00007588ecdd559b  vmovaps [rsp+0xC0], xmm13
00007588ecdd55a4  vmovaps [rsp+0xD0], xmm14
00007588ecdd55ad  vmovaps [rsp+0xE0], xmm15
00007588ecdd55b6  sub rsp, 0x40
00007588ecdd55ba  lea rdi, [rsp]
00007588ecdd55be  lea rsi, [rsp+0x10]
00007588ecdd55c3  lea rdx, [rsp+0x20]
00007588ecdd55c8  lea rcx, [rsp+0x30]
00007588ecdd55cd  mov r8d, 0x00
00007588ecdd55d3  lea r9, [r15+0x3A8]
00007588ecdd55da  movaps [rdi], xmm7
00007588ecdd55dd  movaps [rsi], xmm6
00007588ecdd55e0  movaps [rdx], xmm8
00007588ecdd55e4  movaps [rcx], xmm9
00007588ecdd55e8  mov rax, 0x6516BF3BBA50
00007588ecdd55f2  call rax
00007588ecdd55f4  movaps xmm7, [rsp]
00007588ecdd55f8  add rsp, 0x40
00007588ecdd55fc  vmovaps xmm0, [rsp]
00007588ecdd5601  vmovaps xmm1, [rsp+0x10]
00007588ecdd5607  vmovaps xmm2, [rsp+0x20]
00007588ecdd560d  vmovaps xmm3, [rsp+0x30]
00007588ecdd5613  vmovaps xmm4, [rsp+0x40]
00007588ecdd5619  vmovaps xmm5, [rsp+0x50]
00007588ecdd561f  vmovaps xmm6, [rsp+0x60]
00007588ecdd5625  vmovaps xmm8, [rsp+0x70]
00007588ecdd562b  vmovaps xmm9, [rsp+0x80]
00007588ecdd5634  vmovaps xmm10, [rsp+0x90]
00007588ecdd563d  vmovaps xmm11, [rsp+0xA0]
00007588ecdd5646  vmovaps xmm12, [rsp+0xB0]
00007588ecdd564f  vmovaps xmm13, [rsp+0xC0]
00007588ecdd5658  vmovaps xmm14, [rsp+0xD0]
00007588ecdd5661  vmovaps xmm15, [rsp+0xE0]
00007588ecdd566a  add rsp, 0xF0
00007588ecdd5671  pop r11
00007588ecdd5673  pop r10
00007588ecdd5675  pop r9
00007588ecdd5677  pop r8
00007588ecdd5679  pop rsi
00007588ecdd567a  pop rdi
00007588ecdd567b  pop rdx
00007588ecdd567c  pop rcx
00007588ecdd567d  pop rax
00007588ecdd567e  add rsp, 0x08
00007588ecdd5682  jmp 0x00007588ECDD305D
00007588ecdd5687  sub rsp, 0x08
00007588ecdd568b  push rax
00007588ecdd568c  push rcx
00007588ecdd568d  push rdx
00007588ecdd568e  push rdi
00007588ecdd568f  push rsi
00007588ecdd5690  push r8
00007588ecdd5692  push r9
00007588ecdd5694  push r10
00007588ecdd5696  push r11
00007588ecdd5698  sub rsp, 0xF0
00007588ecdd569f  vmovaps [rsp], xmm0
00007588ecdd56a4  vmovaps [rsp+0x10], xmm1
00007588ecdd56aa  vmovaps [rsp+0x20], xmm2
00007588ecdd56b0  vmovaps [rsp+0x30], xmm3
00007588ecdd56b6  vmovaps [rsp+0x40], xmm4
00007588ecdd56bc  vmovaps [rsp+0x50], xmm5
00007588ecdd56c2  vmovaps [rsp+0x60], xmm6
00007588ecdd56c8  vmovaps [rsp+0x70], xmm7
00007588ecdd56ce  vmovaps [rsp+0x80], xmm9
00007588ecdd56d7  vmovaps [rsp+0x90], xmm10
00007588ecdd56e0  vmovaps [rsp+0xA0], xmm11
00007588ecdd56e9  vmovaps [rsp+0xB0], xmm12
00007588ecdd56f2  vmovaps [rsp+0xC0], xmm13
00007588ecdd56fb  vmovaps [rsp+0xD0], xmm14
00007588ecdd5704  vmovaps [rsp+0xE0], xmm15
00007588ecdd570d  sub rsp, 0x40
00007588ecdd5711  lea rdi, [rsp]
00007588ecdd5715  lea rsi, [rsp+0x10]
00007588ecdd571a  lea rdx, [rsp+0x20]
00007588ecdd571f  lea rcx, [rsp+0x30]
00007588ecdd5724  mov r8d, 0x00
00007588ecdd572a  lea r9, [r15+0x3A8]
00007588ecdd5731  movaps [rdi], xmm8
00007588ecdd5735  movaps [rsi], xmm10
00007588ecdd5739  movaps [rdx], xmm14
00007588ecdd573d  movaps [rcx], xmm9
00007588ecdd5741  mov rax, 0x6516BF3BBA50
00007588ecdd574b  call rax
00007588ecdd574d  movaps xmm8, [rsp]
00007588ecdd5752  add rsp, 0x40
00007588ecdd5756  vmovaps xmm0, [rsp]
00007588ecdd575b  vmovaps xmm1, [rsp+0x10]
00007588ecdd5761  vmovaps xmm2, [rsp+0x20]
00007588ecdd5767  vmovaps xmm3, [rsp+0x30]
00007588ecdd576d  vmovaps xmm4, [rsp+0x40]
00007588ecdd5773  vmovaps xmm5, [rsp+0x50]
00007588ecdd5779  vmovaps xmm6, [rsp+0x60]
00007588ecdd577f  vmovaps xmm7, [rsp+0x70]
00007588ecdd5785  vmovaps xmm9, [rsp+0x80]
00007588ecdd578e  vmovaps xmm10, [rsp+0x90]
00007588ecdd5797  vmovaps xmm11, [rsp+0xA0]
00007588ecdd57a0  vmovaps xmm12, [rsp+0xB0]
00007588ecdd57a9  vmovaps xmm13, [rsp+0xC0]
00007588ecdd57b2  vmovaps xmm14, [rsp+0xD0]
00007588ecdd57bb  vmovaps xmm15, [rsp+0xE0]
00007588ecdd57c4  add rsp, 0xF0
00007588ecdd57cb  pop r11
00007588ecdd57cd  pop r10
00007588ecdd57cf  pop r9
00007588ecdd57d1  pop r8
00007588ecdd57d3  pop rsi
00007588ecdd57d4  pop rdi
00007588ecdd57d5  pop rdx
00007588ecdd57d6  pop rcx
00007588ecdd57d7  pop rax
00007588ecdd57d8  add rsp, 0x08
00007588ecdd57dc  jmp 0x00007588ECDD3083
00007588ecdd57e1  sub rsp, 0x08
00007588ecdd57e5  push rax
00007588ecdd57e6  push rcx
00007588ecdd57e7  push rdx
00007588ecdd57e8  push rdi
00007588ecdd57e9  push rsi
00007588ecdd57ea  push r8
00007588ecdd57ec  push r9
00007588ecdd57ee  push r10
00007588ecdd57f0  push r11
00007588ecdd57f2  sub rsp, 0xF0
00007588ecdd57f9  vmovaps [rsp], xmm0
00007588ecdd57fe  vmovaps [rsp+0x10], xmm1
00007588ecdd5804  vmovaps [rsp+0x20], xmm2
00007588ecdd580a  vmovaps [rsp+0x30], xmm3
00007588ecdd5810  vmovaps [rsp+0x40], xmm4
00007588ecdd5816  vmovaps [rsp+0x50], xmm5
00007588ecdd581c  vmovaps [rsp+0x60], xmm6
00007588ecdd5822  vmovaps [rsp+0x70], xmm7
00007588ecdd5828  vmovaps [rsp+0x80], xmm8
00007588ecdd5831  vmovaps [rsp+0x90], xmm9
00007588ecdd583a  vmovaps [rsp+0xA0], xmm11
00007588ecdd5843  vmovaps [rsp+0xB0], xmm12
00007588ecdd584c  vmovaps [rsp+0xC0], xmm13
00007588ecdd5855  vmovaps [rsp+0xD0], xmm14
00007588ecdd585e  vmovaps [rsp+0xE0], xmm15
00007588ecdd5867  sub rsp, 0x40
00007588ecdd586b  lea rdi, [rsp]
00007588ecdd586f  lea rsi, [rsp+0x10]
00007588ecdd5874  lea rdx, [rsp+0x20]
00007588ecdd5879  lea rcx, [rsp+0x30]
00007588ecdd587e  mov r8d, 0x00
00007588ecdd5884  lea r9, [r15+0x3A8]
00007588ecdd588b  movaps [rdi], xmm10
00007588ecdd588f  movaps [rsi], xmm13
00007588ecdd5893  movaps [rdx], xmm11
00007588ecdd5897  movaps [rcx], xmm14
00007588ecdd589b  mov rax, 0x6516BF3BBA50
00007588ecdd58a5  call rax
00007588ecdd58a7  movaps xmm10, [rsp]
00007588ecdd58ac  add rsp, 0x40
00007588ecdd58b0  vmovaps xmm0, [rsp]
00007588ecdd58b5  vmovaps xmm1, [rsp+0x10]
00007588ecdd58bb  vmovaps xmm2, [rsp+0x20]
00007588ecdd58c1  vmovaps xmm3, [rsp+0x30]
00007588ecdd58c7  vmovaps xmm4, [rsp+0x40]
00007588ecdd58cd  vmovaps xmm5, [rsp+0x50]
00007588ecdd58d3  vmovaps xmm6, [rsp+0x60]
00007588ecdd58d9  vmovaps xmm7, [rsp+0x70]
00007588ecdd58df  vmovaps xmm8, [rsp+0x80]
00007588ecdd58e8  vmovaps xmm9, [rsp+0x90]
00007588ecdd58f1  vmovaps xmm11, [rsp+0xA0]
00007588ecdd58fa  vmovaps xmm12, [rsp+0xB0]
00007588ecdd5903  vmovaps xmm13, [rsp+0xC0]
00007588ecdd590c  vmovaps xmm14, [rsp+0xD0]
00007588ecdd5915  vmovaps xmm15, [rsp+0xE0]
00007588ecdd591e  add rsp, 0xF0
00007588ecdd5925  pop r11
00007588ecdd5927  pop r10
00007588ecdd5929  pop r9
00007588ecdd592b  pop r8
00007588ecdd592d  pop rsi
00007588ecdd592e  pop rdi
00007588ecdd592f  pop rdx
00007588ecdd5930  pop rcx
00007588ecdd5931  pop rax
00007588ecdd5932  add rsp, 0x08
00007588ecdd5936  jmp 0x00007588ECDD30A9
00007588ecdd593b  sub rsp, 0x08
00007588ecdd593f  push rax
00007588ecdd5940  push rcx
00007588ecdd5941  push rdx
00007588ecdd5942  push rdi
00007588ecdd5943  push rsi
00007588ecdd5944  push r8
00007588ecdd5946  push r9
00007588ecdd5948  push r10
00007588ecdd594a  push r11
00007588ecdd594c  sub rsp, 0xF0
00007588ecdd5953  vmovaps [rsp], xmm0
00007588ecdd5958  vmovaps [rsp+0x10], xmm1
00007588ecdd595e  vmovaps [rsp+0x20], xmm2
00007588ecdd5964  vmovaps [rsp+0x30], xmm3
00007588ecdd596a  vmovaps [rsp+0x40], xmm4
00007588ecdd5970  vmovaps [rsp+0x50], xmm5
00007588ecdd5976  vmovaps [rsp+0x60], xmm6
00007588ecdd597c  vmovaps [rsp+0x70], xmm7
00007588ecdd5982  vmovaps [rsp+0x80], xmm8
00007588ecdd598b  vmovaps [rsp+0x90], xmm9
00007588ecdd5994  vmovaps [rsp+0xA0], xmm10
00007588ecdd599d  vmovaps [rsp+0xB0], xmm11
00007588ecdd59a6  vmovaps [rsp+0xC0], xmm12
00007588ecdd59af  vmovaps [rsp+0xD0], xmm14
00007588ecdd59b8  vmovaps [rsp+0xE0], xmm15
00007588ecdd59c1  sub rsp, 0x40
00007588ecdd59c5  lea rdi, [rsp]
00007588ecdd59c9  lea rsi, [rsp+0x10]
00007588ecdd59ce  lea rdx, [rsp+0x20]
00007588ecdd59d3  lea rcx, [rsp+0x30]
00007588ecdd59d8  mov r8d, 0x00
00007588ecdd59de  lea r9, [r15+0x3A8]
00007588ecdd59e5  movaps [rdi], xmm13
00007588ecdd59e9  movaps [rsi], xmm12
00007588ecdd59ed  movaps [rdx], xmm15
00007588ecdd59f1  movaps [rcx], xmm14
00007588ecdd59f5  mov rax, 0x6516BF3BBA50
00007588ecdd59ff  call rax
00007588ecdd5a01  movaps xmm13, [rsp]
00007588ecdd5a06  add rsp, 0x40
00007588ecdd5a0a  vmovaps xmm0, [rsp]
00007588ecdd5a0f  vmovaps xmm1, [rsp+0x10]
00007588ecdd5a15  vmovaps xmm2, [rsp+0x20]
00007588ecdd5a1b  vmovaps xmm3, [rsp+0x30]
00007588ecdd5a21  vmovaps xmm4, [rsp+0x40]
00007588ecdd5a27  vmovaps xmm5, [rsp+0x50]
00007588ecdd5a2d  vmovaps xmm6, [rsp+0x60]
00007588ecdd5a33  vmovaps xmm7, [rsp+0x70]
00007588ecdd5a39  vmovaps xmm8, [rsp+0x80]
00007588ecdd5a42  vmovaps xmm9, [rsp+0x90]
00007588ecdd5a4b  vmovaps xmm10, [rsp+0xA0]
00007588ecdd5a54  vmovaps xmm11, [rsp+0xB0]
00007588ecdd5a5d  vmovaps xmm12, [rsp+0xC0]
00007588ecdd5a66  vmovaps xmm14, [rsp+0xD0]
00007588ecdd5a6f  vmovaps xmm15, [rsp+0xE0]
00007588ecdd5a78  add rsp, 0xF0
00007588ecdd5a7f  pop r11
00007588ecdd5a81  pop r10
00007588ecdd5a83  pop r9
00007588ecdd5a85  pop r8
00007588ecdd5a87  pop rsi
00007588ecdd5a88  pop rdi
00007588ecdd5a89  pop rdx
00007588ecdd5a8a  pop rcx
00007588ecdd5a8b  pop rax
00007588ecdd5a8c  add rsp, 0x08
00007588ecdd5a90  jmp 0x00007588ECDD30CF
00007588ecdd5a95  call 0x00007588ECC0E760
00007588ecdd5a9a  jmp 0x00007588ECDD30DC
00007588ecdd5a9f  call 0x00007588ECC0D4E0
00007588ecdd5aa4  jmp 0x00007588ECDD30E9
00007588ecdd5aa9  sub rsp, 0x08
00007588ecdd5aad  push rax
00007588ecdd5aae  push rcx
00007588ecdd5aaf  push rdx
00007588ecdd5ab0  push rdi
00007588ecdd5ab1  push rsi
00007588ecdd5ab2  push r8
00007588ecdd5ab4  push r9
00007588ecdd5ab6  push r10
00007588ecdd5ab8  push r11
00007588ecdd5aba  sub rsp, 0xF0
00007588ecdd5ac1  vmovaps [rsp], xmm0
00007588ecdd5ac6  vmovaps [rsp+0x10], xmm1
00007588ecdd5acc  vmovaps [rsp+0x20], xmm2
00007588ecdd5ad2  vmovaps [rsp+0x30], xmm3
00007588ecdd5ad8  vmovaps [rsp+0x40], xmm4
00007588ecdd5ade  vmovaps [rsp+0x50], xmm5
00007588ecdd5ae4  vmovaps [rsp+0x60], xmm6
00007588ecdd5aea  vmovaps [rsp+0x70], xmm7
00007588ecdd5af0  vmovaps [rsp+0x80], xmm8
00007588ecdd5af9  vmovaps [rsp+0x90], xmm9
00007588ecdd5b02  vmovaps [rsp+0xA0], xmm10
00007588ecdd5b0b  vmovaps [rsp+0xB0], xmm12
00007588ecdd5b14  vmovaps [rsp+0xC0], xmm13
00007588ecdd5b1d  vmovaps [rsp+0xD0], xmm14
00007588ecdd5b26  vmovaps [rsp+0xE0], xmm15
00007588ecdd5b2f  sub rsp, 0x40
00007588ecdd5b33  lea rdi, [rsp]
00007588ecdd5b37  lea rsi, [rsp+0x10]
00007588ecdd5b3c  lea rdx, [rsp+0x20]
00007588ecdd5b41  lea rcx, [rsp+0x30]
00007588ecdd5b46  mov r8d, 0x00
00007588ecdd5b4c  lea r9, [r15+0x3A8]
00007588ecdd5b53  movaps [rdi], xmm11
00007588ecdd5b57  movaps [rsi], xmm7
00007588ecdd5b5a  movaps [rdx], xmm1
00007588ecdd5b5d  movaps [rcx], xmm12
00007588ecdd5b61  mov rax, 0x6516BF3BBA50
00007588ecdd5b6b  call rax
00007588ecdd5b6d  movaps xmm11, [rsp]
00007588ecdd5b72  add rsp, 0x40
00007588ecdd5b76  vmovaps xmm0, [rsp]
00007588ecdd5b7b  vmovaps xmm1, [rsp+0x10]
00007588ecdd5b81  vmovaps xmm2, [rsp+0x20]
00007588ecdd5b87  vmovaps xmm3, [rsp+0x30]
00007588ecdd5b8d  vmovaps xmm4, [rsp+0x40]
00007588ecdd5b93  vmovaps xmm5, [rsp+0x50]
00007588ecdd5b99  vmovaps xmm6, [rsp+0x60]
00007588ecdd5b9f  vmovaps xmm7, [rsp+0x70]
00007588ecdd5ba5  vmovaps xmm8, [rsp+0x80]
00007588ecdd5bae  vmovaps xmm9, [rsp+0x90]
00007588ecdd5bb7  vmovaps xmm10, [rsp+0xA0]
00007588ecdd5bc0  vmovaps xmm12, [rsp+0xB0]
00007588ecdd5bc9  vmovaps xmm13, [rsp+0xC0]
00007588ecdd5bd2  vmovaps xmm14, [rsp+0xD0]
00007588ecdd5bdb  vmovaps xmm15, [rsp+0xE0]
00007588ecdd5be4  add rsp, 0xF0
00007588ecdd5beb  pop r11
00007588ecdd5bed  pop r10
00007588ecdd5bef  pop r9
00007588ecdd5bf1  pop r8
00007588ecdd5bf3  pop rsi
00007588ecdd5bf4  pop rdi
00007588ecdd5bf5  pop rdx
00007588ecdd5bf6  pop rcx
00007588ecdd5bf7  pop rax
00007588ecdd5bf8  add rsp, 0x08
00007588ecdd5bfc  jmp 0x00007588ECDD3122
00007588ecdd5c01  call 0x00007588ECBFF430
00007588ecdd5c06  jmp 0x00007588ECDD3134
00007588ecdd5c0b  sub rsp, 0x08
00007588ecdd5c0f  push rax
00007588ecdd5c10  push rcx
00007588ecdd5c11  push rdx
00007588ecdd5c12  push rdi
00007588ecdd5c13  push rsi
00007588ecdd5c14  push r8
00007588ecdd5c16  push r9
00007588ecdd5c18  push r10
00007588ecdd5c1a  push r11
00007588ecdd5c1c  sub rsp, 0xF0
00007588ecdd5c23  vmovaps [rsp], xmm0
00007588ecdd5c28  vmovaps [rsp+0x10], xmm1
00007588ecdd5c2e  vmovaps [rsp+0x20], xmm2
00007588ecdd5c34  vmovaps [rsp+0x30], xmm3
00007588ecdd5c3a  vmovaps [rsp+0x40], xmm4
00007588ecdd5c40  vmovaps [rsp+0x50], xmm5
00007588ecdd5c46  vmovaps [rsp+0x60], xmm6
00007588ecdd5c4c  vmovaps [rsp+0x70], xmm7
00007588ecdd5c52  vmovaps [rsp+0x80], xmm8
00007588ecdd5c5b  vmovaps [rsp+0x90], xmm10
00007588ecdd5c64  vmovaps [rsp+0xA0], xmm11
00007588ecdd5c6d  vmovaps [rsp+0xB0], xmm12
00007588ecdd5c76  vmovaps [rsp+0xC0], xmm13
00007588ecdd5c7f  vmovaps [rsp+0xD0], xmm14
00007588ecdd5c88  vmovaps [rsp+0xE0], xmm15
00007588ecdd5c91  sub rsp, 0x40
00007588ecdd5c95  lea rdi, [rsp]
00007588ecdd5c99  lea rsi, [rsp+0x10]
00007588ecdd5c9e  lea rdx, [rsp+0x20]
00007588ecdd5ca3  lea rcx, [rsp+0x30]
00007588ecdd5ca8  mov r8d, 0x00
00007588ecdd5cae  lea r9, [r15+0x3A8]
00007588ecdd5cb5  movaps [rdi], xmm9
00007588ecdd5cb9  movaps [rsi], xmm8
00007588ecdd5cbd  movaps [rdx], xmm14
00007588ecdd5cc1  movaps [rcx], xmm12
00007588ecdd5cc5  mov rax, 0x6516BF3BBA50
00007588ecdd5ccf  call rax
00007588ecdd5cd1  movaps xmm9, [rsp]
00007588ecdd5cd6  add rsp, 0x40
00007588ecdd5cda  vmovaps xmm0, [rsp]
00007588ecdd5cdf  vmovaps xmm1, [rsp+0x10]
00007588ecdd5ce5  vmovaps xmm2, [rsp+0x20]
00007588ecdd5ceb  vmovaps xmm3, [rsp+0x30]
00007588ecdd5cf1  vmovaps xmm4, [rsp+0x40]
00007588ecdd5cf7  vmovaps xmm5, [rsp+0x50]
00007588ecdd5cfd  vmovaps xmm6, [rsp+0x60]
00007588ecdd5d03  vmovaps xmm7, [rsp+0x70]
00007588ecdd5d09  vmovaps xmm8, [rsp+0x80]
00007588ecdd5d12  vmovaps xmm10, [rsp+0x90]
00007588ecdd5d1b  vmovaps xmm11, [rsp+0xA0]
00007588ecdd5d24  vmovaps xmm12, [rsp+0xB0]
00007588ecdd5d2d  vmovaps xmm13, [rsp+0xC0]
00007588ecdd5d36  vmovaps xmm14, [rsp+0xD0]
00007588ecdd5d3f  vmovaps xmm15, [rsp+0xE0]
00007588ecdd5d48  add rsp, 0xF0
00007588ecdd5d4f  pop r11
00007588ecdd5d51  pop r10
00007588ecdd5d53  pop r9
00007588ecdd5d55  pop r8
00007588ecdd5d57  pop rsi
00007588ecdd5d58  pop rdi
00007588ecdd5d59  pop rdx
00007588ecdd5d5a  pop rcx
00007588ecdd5d5b  pop rax
00007588ecdd5d5c  add rsp, 0x08
00007588ecdd5d60  jmp 0x00007588ECDD3165
00007588ecdd5d65  sub rsp, 0x08
00007588ecdd5d69  push rax
00007588ecdd5d6a  push rcx
00007588ecdd5d6b  push rdx
00007588ecdd5d6c  push rdi
00007588ecdd5d6d  push rsi
00007588ecdd5d6e  push r8
00007588ecdd5d70  push r9
00007588ecdd5d72  push r10
00007588ecdd5d74  push r11
00007588ecdd5d76  sub rsp, 0xF0
00007588ecdd5d7d  vmovaps [rsp], xmm0
00007588ecdd5d82  vmovaps [rsp+0x10], xmm1
00007588ecdd5d88  vmovaps [rsp+0x20], xmm2
00007588ecdd5d8e  vmovaps [rsp+0x30], xmm3
00007588ecdd5d94  vmovaps [rsp+0x40], xmm4
00007588ecdd5d9a  vmovaps [rsp+0x50], xmm5
00007588ecdd5da0  vmovaps [rsp+0x60], xmm6
00007588ecdd5da6  vmovaps [rsp+0x70], xmm7
00007588ecdd5dac  vmovaps [rsp+0x80], xmm8
00007588ecdd5db5  vmovaps [rsp+0x90], xmm9
00007588ecdd5dbe  vmovaps [rsp+0xA0], xmm10
00007588ecdd5dc7  vmovaps [rsp+0xB0], xmm11
00007588ecdd5dd0  vmovaps [rsp+0xC0], xmm13
00007588ecdd5dd9  vmovaps [rsp+0xD0], xmm14
00007588ecdd5de2  vmovaps [rsp+0xE0], xmm15
00007588ecdd5deb  sub rsp, 0x40
00007588ecdd5def  lea rdi, [rsp]
00007588ecdd5df3  lea rsi, [rsp+0x10]
00007588ecdd5df8  lea rdx, [rsp+0x20]
00007588ecdd5dfd  lea rcx, [rsp+0x30]
00007588ecdd5e02  mov r8d, 0x00
00007588ecdd5e08  lea r9, [r15+0x3A8]
00007588ecdd5e0f  movaps [rdi], xmm12
00007588ecdd5e13  movaps [rsi], xmm10
00007588ecdd5e17  movaps [rdx], xmm15
00007588ecdd5e1b  movaps [rcx], xmm14
00007588ecdd5e1f  mov rax, 0x6516BF3BBA50
00007588ecdd5e29  call rax
00007588ecdd5e2b  movaps xmm12, [rsp]
00007588ecdd5e30  add rsp, 0x40
00007588ecdd5e34  vmovaps xmm0, [rsp]
00007588ecdd5e39  vmovaps xmm1, [rsp+0x10]
00007588ecdd5e3f  vmovaps xmm2, [rsp+0x20]
00007588ecdd5e45  vmovaps xmm3, [rsp+0x30]
00007588ecdd5e4b  vmovaps xmm4, [rsp+0x40]
00007588ecdd5e51  vmovaps xmm5, [rsp+0x50]
00007588ecdd5e57  vmovaps xmm6, [rsp+0x60]
00007588ecdd5e5d  vmovaps xmm7, [rsp+0x70]
00007588ecdd5e63  vmovaps xmm8, [rsp+0x80]
00007588ecdd5e6c  vmovaps xmm9, [rsp+0x90]
00007588ecdd5e75  vmovaps xmm10, [rsp+0xA0]
00007588ecdd5e7e  vmovaps xmm11, [rsp+0xB0]
00007588ecdd5e87  vmovaps xmm13, [rsp+0xC0]
00007588ecdd5e90  vmovaps xmm14, [rsp+0xD0]
00007588ecdd5e99  vmovaps xmm15, [rsp+0xE0]
00007588ecdd5ea2  add rsp, 0xF0
00007588ecdd5ea9  pop r11
00007588ecdd5eab  pop r10
00007588ecdd5ead  pop r9
00007588ecdd5eaf  pop r8
00007588ecdd5eb1  pop rsi
00007588ecdd5eb2  pop rdi
00007588ecdd5eb3  pop rdx
00007588ecdd5eb4  pop rcx
00007588ecdd5eb5  pop rax
00007588ecdd5eb6  add rsp, 0x08
00007588ecdd5eba  jmp 0x00007588ECDD3196
00007588ecdd5ebf  sub rsp, 0x08
00007588ecdd5ec3  push rax
00007588ecdd5ec4  push rcx
00007588ecdd5ec5  push rdx
00007588ecdd5ec6  push rdi
00007588ecdd5ec7  push rsi
00007588ecdd5ec8  push r8
00007588ecdd5eca  push r9
00007588ecdd5ecc  push r10
00007588ecdd5ece  push r11
00007588ecdd5ed0  sub rsp, 0xF0
00007588ecdd5ed7  vmovaps [rsp], xmm0
00007588ecdd5edc  vmovaps [rsp+0x10], xmm1
00007588ecdd5ee2  vmovaps [rsp+0x20], xmm2
00007588ecdd5ee8  vmovaps [rsp+0x30], xmm3
00007588ecdd5eee  vmovaps [rsp+0x40], xmm4
00007588ecdd5ef4  vmovaps [rsp+0x50], xmm5
00007588ecdd5efa  vmovaps [rsp+0x60], xmm6
00007588ecdd5f00  vmovaps [rsp+0x70], xmm7
00007588ecdd5f06  vmovaps [rsp+0x80], xmm8
00007588ecdd5f0f  vmovaps [rsp+0x90], xmm9
00007588ecdd5f18  vmovaps [rsp+0xA0], xmm10
00007588ecdd5f21  vmovaps [rsp+0xB0], xmm11
00007588ecdd5f2a  vmovaps [rsp+0xC0], xmm12
00007588ecdd5f33  vmovaps [rsp+0xD0], xmm13
00007588ecdd5f3c  vmovaps [rsp+0xE0], xmm15
00007588ecdd5f45  sub rsp, 0x40
00007588ecdd5f49  lea rdi, [rsp]
00007588ecdd5f4d  lea rsi, [rsp+0x10]
00007588ecdd5f52  lea rdx, [rsp+0x20]
00007588ecdd5f57  lea rcx, [rsp+0x30]
00007588ecdd5f5c  mov r8d, 0x00
00007588ecdd5f62  lea r9, [r15+0x3A8]
00007588ecdd5f69  movaps [rdi], xmm14
00007588ecdd5f6d  movaps [rsi], xmm13
00007588ecdd5f71  movaps [rdx], xmm1
00007588ecdd5f74  movaps [rcx], xmm15
00007588ecdd5f78  mov rax, 0x6516BF3BBA50
00007588ecdd5f82  call rax
00007588ecdd5f84  movaps xmm14, [rsp]
00007588ecdd5f89  add rsp, 0x40
00007588ecdd5f8d  vmovaps xmm0, [rsp]
00007588ecdd5f92  vmovaps xmm1, [rsp+0x10]
00007588ecdd5f98  vmovaps xmm2, [rsp+0x20]
00007588ecdd5f9e  vmovaps xmm3, [rsp+0x30]
00007588ecdd5fa4  vmovaps xmm4, [rsp+0x40]
00007588ecdd5faa  vmovaps xmm5, [rsp+0x50]
00007588ecdd5fb0  vmovaps xmm6, [rsp+0x60]
00007588ecdd5fb6  vmovaps xmm7, [rsp+0x70]
00007588ecdd5fbc  vmovaps xmm8, [rsp+0x80]
00007588ecdd5fc5  vmovaps xmm9, [rsp+0x90]
00007588ecdd5fce  vmovaps xmm10, [rsp+0xA0]
00007588ecdd5fd7  vmovaps xmm11, [rsp+0xB0]
00007588ecdd5fe0  vmovaps xmm12, [rsp+0xC0]
00007588ecdd5fe9  vmovaps xmm13, [rsp+0xD0]
00007588ecdd5ff2  vmovaps xmm15, [rsp+0xE0]
00007588ecdd5ffb  add rsp, 0xF0
00007588ecdd6002  pop r11
00007588ecdd6004  pop r10
00007588ecdd6006  pop r9
00007588ecdd6008  pop r8
00007588ecdd600a  pop rsi
00007588ecdd600b  pop rdi
00007588ecdd600c  pop rdx
00007588ecdd600d  pop rcx
00007588ecdd600e  pop rax
00007588ecdd600f  add rsp, 0x08
00007588ecdd6013  jmp 0x00007588ECDD31C7
00007588ecdd6018  call 0x00007588ECC079B0
00007588ecdd601d  jmp 0x00007588ECDD31DA
00007588ecdd6022  call 0x00007588ECC0B100
00007588ecdd6027  jmp 0x00007588ECDD31E5
00007588ecdd602c  call 0x00007588ECC09E90
00007588ecdd6031  jmp 0x00007588ECDD31F0
00007588ecdd6036  call 0x00007588ECC0D600
00007588ecdd603b  jmp 0x00007588ECDD31FB
00007588ecdd6040  int3
00007588ecdd6041  nop [rax+rax*1], ax
00007588ecdd604a  nop [rax+rax*1], ax
00007588ecdd6050  mov rax, [r15+0x40]
00007588ecdd6054  mov r14, [r15+0x58]
00007588ecdd6058  lea r12, [rax+r14*1]
00007588ecdd605c  vxorps xmm1, xmm1, xmm1
00007588ecdd6060  vpbroadcastq xmm1, xmm1
00007588ecdd6065  vxorps xmm15, xmm15, xmm15
00007588ecdd606a  vpbroadcastq xmm15, xmm15
00007588ecdd606f  lea rax, [r12+0x30]
00007588ecdd6074  mov r11, [r13+rax*1]
00007588ecdd6079  lea rax, [r12+0x38]
00007588ecdd607e  mov r10, [r13+rax*1]
00007588ecdd6083  movq xmm14, r11
00007588ecdd6088  movq xmm13, r10
00007588ecdd608d  movq xmm14, xmm14
00007588ecdd6092  movq xmm13, xmm13
00007588ecdd6097  vmovaps [rsp+0x10], xmm13
00007588ecdd609d  movq xmm13, xmm13
00007588ecdd60a2  movaps [r15+0x270], xmm13
00007588ecdd60aa  movaps xmm13, [r15+0x160]
00007588ecdd60b2  vmovaps [rsp+0x20], xmm13
00007588ecdd60b8  vmovaps xmm12, [rsp+0x20]
00007588ecdd60be  por xmm13, xmm12
00007588ecdd60c3  lea rax, [r12+0x20]
00007588ecdd60c8  mov r11, [r13+rax*1]
00007588ecdd60cd  lea rax, [r12+0x28]
00007588ecdd60d2  mov r10, [r13+rax*1]
00007588ecdd60d7  movq xmm12, r11
00007588ecdd60dc  movq xmm11, r10
00007588ecdd60e1  movq xmm12, xmm12
00007588ecdd60e6  movq xmm11, xmm11
00007588ecdd60eb  movaps xmm10, [r15+0x2D0]
00007588ecdd60f3  vmovaps [rsp+0x20], xmm10
00007588ecdd60f9  vmovaps xmm9, [rsp+0x20]
00007588ecdd60ff  por xmm10, xmm9
00007588ecdd6104  movaps xmm9, [r15+0x300]
00007588ecdd610c  vmovaps [rsp+0x20], xmm9
00007588ecdd6112  vmovaps xmm8, [rsp+0x20]
00007588ecdd6118  por xmm9, xmm8
00007588ecdd611d  movaps xmm8, [r15+0x2B0]
00007588ecdd6125  vmovaps [rsp+0x20], xmm8
00007588ecdd612b  vmovaps xmm7, [rsp+0x20]
00007588ecdd6131  por xmm8, xmm7
00007588ecdd6136  movaps xmm7, [r15+0x180]
00007588ecdd613e  vmovaps [rsp+0x20], xmm7
00007588ecdd6144  vmovaps xmm6, [rsp+0x20]
00007588ecdd614a  por xmm7, xmm6
00007588ecdd614e  lea rax, [r12+0x10]
00007588ecdd6153  mov r11, [r13+rax*1]
00007588ecdd6158  lea rax, [r12+0x18]
00007588ecdd615d  mov r10, [r13+rax*1]
00007588ecdd6162  movq xmm6, r11
00007588ecdd6167  movq xmm5, r10
00007588ecdd616c  movq xmm6, xmm6
00007588ecdd6170  movq xmm5, xmm5
00007588ecdd6174  movaps xmm4, [r15+0x200]
00007588ecdd617c  vmovaps [rsp+0x20], xmm4
00007588ecdd6182  vmovaps xmm3, [rsp+0x20]
00007588ecdd6188  por xmm4, xmm3
00007588ecdd618c  movaps xmm3, [r15+0x1F0]
00007588ecdd6194  vmovaps [rsp+0x20], xmm3
00007588ecdd619a  vmovaps xmm2, [rsp+0x20]
00007588ecdd61a0  por xmm3, xmm2
00007588ecdd61a4  movaps xmm2, [r15+0x2E0]
00007588ecdd61ac  vmovaps [rsp+0x20], xmm2
00007588ecdd61b2  vmovaps [rsp+0x30], xmm1
00007588ecdd61b8  vmovaps xmm1, [rsp+0x20]
00007588ecdd61be  por xmm2, xmm1
00007588ecdd61c2  movaps xmm1, [r15+0x2A0]
00007588ecdd61ca  vmovaps [rsp+0x20], xmm1
00007588ecdd61d0  vmovaps [rsp+0x40], xmm15
00007588ecdd61d6  vmovaps xmm15, [rsp+0x20]
00007588ecdd61dc  por xmm1, xmm15
00007588ecdd61e1  movaps xmm15, [r15+0x280]
00007588ecdd61e9  vmovaps [rsp+0x20], xmm15
00007588ecdd61ef  vmovaps [rsp+0x50], xmm1
00007588ecdd61f5  vmovaps xmm1, [rsp+0x20]
00007588ecdd61fb  por xmm15, xmm1
00007588ecdd6200  movaps xmm1, [r15+0x1C0]
00007588ecdd6208  vmovaps [rsp+0x20], xmm1
00007588ecdd620e  vmovaps [rsp+0x60], xmm15
00007588ecdd6214  vmovaps xmm15, [rsp+0x20]
00007588ecdd621a  por xmm1, xmm15
00007588ecdd621f  movaps xmm15, [r15+0x210]
00007588ecdd6227  vmovaps [rsp+0x20], xmm15
00007588ecdd622d  vmovaps [rsp+0x70], xmm1
00007588ecdd6233  vmovaps xmm1, [rsp+0x20]
00007588ecdd6239  por xmm15, xmm1
00007588ecdd623e  mov rax, [r13+r12*1]
00007588ecdd6243  vmovq xmm1, rax
00007588ecdd6248  vpbroadcastq xmm1, xmm1
00007588ecdd624d  vmovaps [rsp+0x20], xmm1
00007588ecdd6253  vxorps xmm1, xmm1, xmm1
00007588ecdd6257  vpbroadcastq xmm1, xmm1
00007588ecdd625c  mov rax, [r15+0xF8]
00007588ecdd6263  vmovaps [rsp+0x80], xmm1
00007588ecdd626c  movups xmm1, [r13+rax*1]
00007588ecdd6272  vmovaps [rsp+0x90], xmm1
00007588ecdd627b  vxorps xmm1, xmm1, xmm1
00007588ecdd627f  vpbroadcastq xmm1, xmm1
00007588ecdd6284  lea r11, [r12+0x08]
00007588ecdd6289  mov r12, [r13+r11*1]
00007588ecdd628e  vmovaps [rsp+0xA0], xmm1
00007588ecdd6297  movq xmm1, r12
00007588ecdd629c  movaps [r15+0x240], xmm1
00007588ecdd62a4  mov r12, [r15+0x50]
00007588ecdd62a8  lea r11, [r12+r14*1]
00007588ecdd62ac  mov [r15+0x60], r11
00007588ecdd62b0  lea r12, [r14+0x40]
00007588ecdd62b4  mov [r15+0x58], r12
00007588ecdd62b8  vmovaps xmm1, [rsp+0x30]
00007588ecdd62be  vmovaps [rsp+0x30], xmm15
00007588ecdd62c4  vmovaps xmm15, [rsp+0x90]
00007588ecdd62cd  vmovaps [rsp+0x90], xmm14
00007588ecdd62d6  vmovaps xmm14, [rsp+0x20]
00007588ecdd62dc  vmovaps [rsp+0x20], xmm13
00007588ecdd62e2  vmovaps [rsp+0xB0], xmm12
00007588ecdd62eb  movaps xmm13, xmm1
00007588ecdd62ef  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd62fa  vptest xmm12, xmm12
00007588ecdd62ff  jnz 0x00007588ECDD6D9C
00007588ecdd6305  movaps xmm1, [r15+0x250]
00007588ecdd630d  vmovaps xmm15, [rsp+0x40]
00007588ecdd6313  vmovaps [rsp+0x40], xmm13
00007588ecdd6319  movaps xmm12, xmm15
00007588ecdd631d  vfmadd231pd xmm12, xmm1, xmm14
00007588ecdd6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007588ecdd6328  vptest xmm13, xmm13
00007588ecdd632d  jnz 0x00007588ECDD6EF5
00007588ecdd6333  movaps xmm15, [r15+0x1E0]
00007588ecdd633b  vmovaps [rsp+0xC0], xmm15
00007588ecdd6344  vmovaps xmm13, [rsp+0xC0]
00007588ecdd634d  por xmm15, xmm13
00007588ecdd6352  movaps xmm13, [r15+0x1D0]
00007588ecdd635a  vmovaps [rsp+0xC0], xmm13
00007588ecdd6363  vmovaps [rsp+0xD0], xmm1
00007588ecdd636c  vmovaps xmm1, [rsp+0xC0]
00007588ecdd6375  por xmm13, xmm1
00007588ecdd637a  movaps xmm1, [r15+0x2C0]
00007588ecdd6382  vmovaps [rsp+0xC0], xmm1
00007588ecdd638b  vmovaps [rsp+0xE0], xmm15
00007588ecdd6394  vmovaps xmm15, [rsp+0xC0]
00007588ecdd639d  por xmm1, xmm15
00007588ecdd63a2  movaps xmm15, [r15+0x290]
00007588ecdd63aa  vmovaps [rsp+0xC0], xmm15
00007588ecdd63b3  vmovaps [rsp+0xF0], xmm1
00007588ecdd63bc  vmovaps xmm1, [rsp+0xC0]
00007588ecdd63c5  por xmm15, xmm1
00007588ecdd63ca  movaps xmm1, [r15+0x260]
00007588ecdd63d2  vmovaps [rsp+0xC0], xmm1
00007588ecdd63db  vmovaps [rsp+0x100], xmm15
00007588ecdd63e4  vmovaps xmm15, [rsp+0xC0]
00007588ecdd63ed  por xmm1, xmm15
00007588ecdd63f2  vmovaps xmm15, [rsp+0xD0]
00007588ecdd63fb  vmovaps [rsp+0xC0], xmm1
00007588ecdd6404  vmovaps xmm1, [rsp+0xD0]
00007588ecdd640d  por xmm15, xmm1
00007588ecdd6412  lea r14, [rax+0xC0]
00007588ecdd6419  movups xmm1, [r13+r14*1]
00007588ecdd641f  mov [rsp+0xD0], rax
00007588ecdd6427  xor eax, eax
00007588ecdd6429  mov r14d, 0x200
00007588ecdd642f  cmp r12, r14
00007588ecdd6432  cmc
00007588ecdd6433  lahf
00007588ecdd6434  seto al
00007588ecdd6437  mov [r15+0x108], eax
00007588ecdd643e  vmovaps [rsp+0x110], xmm1
00007588ecdd6447  vmovaps xmm1, [rsp+0x80]
00007588ecdd6450  vmovaps [rsp+0x80], xmm15
00007588ecdd6459  vmovaps xmm15, [rsp+0x110]
00007588ecdd6462  vmovaps [rsp+0x110], xmm13
00007588ecdd646b  vmovaps [rsp+0x120], xmm12
00007588ecdd6474  movaps xmm13, xmm1
00007588ecdd6478  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd6483  vptest xmm12, xmm12
00007588ecdd6488  jnz 0x00007588ECDD7058
00007588ecdd648e  mov rax, [rsp+0xD0]
00007588ecdd6496  lea r14, [rax+0xB0]
00007588ecdd649d  movups xmm1, [r13+r14*1]
00007588ecdd64a3  vmovaps xmm15, [rsp+0xA0]
00007588ecdd64ac  vmovaps [rsp+0xA0], xmm13
00007588ecdd64b5  movaps xmm12, xmm15
00007588ecdd64b9  vfmadd231pd xmm12, xmm1, xmm14
00007588ecdd64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007588ecdd64c4  vptest xmm13, xmm13
00007588ecdd64c9  jnz 0x00007588ECDD71BB
00007588ecdd64cf  vmovaps xmm1, [rsp+0x30]
00007588ecdd64d5  vmovaps xmm15, [rsp+0x30]
00007588ecdd64db  por xmm1, xmm15
00007588ecdd64e0  movaps [r15+0x210], xmm1
00007588ecdd64e8  vmovaps xmm15, [rsp+0x70]
00007588ecdd64ee  vmovaps xmm14, [rsp+0x70]
00007588ecdd64f4  por xmm15, xmm14
00007588ecdd64f9  movaps [r15+0x1C0], xmm15
00007588ecdd6501  vmovaps xmm14, [rsp+0x60]
00007588ecdd6507  vmovaps xmm13, [rsp+0x60]
00007588ecdd650d  por xmm14, xmm13
00007588ecdd6512  movaps [r15+0x280], xmm14
00007588ecdd651a  vmovaps xmm13, [rsp+0x50]
00007588ecdd6520  vmovaps [rsp+0x30], xmm1
00007588ecdd6526  vmovaps xmm1, [rsp+0x50]
00007588ecdd652c  por xmm13, xmm1
00007588ecdd6531  movaps [r15+0x2A0], xmm13
00007588ecdd6539  vmovaps [rsp+0x50], xmm2
00007588ecdd653f  vmovaps xmm1, [rsp+0x50]
00007588ecdd6545  por xmm2, xmm1
00007588ecdd6549  movaps [r15+0x2E0], xmm2
00007588ecdd6551  vmovaps [rsp+0x50], xmm3
00007588ecdd6557  vmovaps xmm1, [rsp+0x50]
00007588ecdd655d  por xmm3, xmm1
00007588ecdd6561  movaps [r15+0x1F0], xmm3
00007588ecdd6569  vmovaps xmm1, [rsp+0x80]
00007588ecdd6572  vmovaps [rsp+0x50], xmm15
00007588ecdd6578  vmovaps xmm15, [rsp+0x80]
00007588ecdd6581  por xmm1, xmm15
00007588ecdd6586  movaps [r15+0x250], xmm1
00007588ecdd658e  vmovaps xmm1, [rsp+0xC0]
00007588ecdd6597  vmovaps xmm15, [rsp+0xC0]
00007588ecdd65a0  por xmm1, xmm15
00007588ecdd65a5  movaps [r15+0x260], xmm1
00007588ecdd65ad  vmovaps xmm15, [rsp+0x100]
00007588ecdd65b6  vmovaps [rsp+0x60], xmm1
00007588ecdd65bc  vmovaps xmm1, [rsp+0x100]
00007588ecdd65c5  por xmm15, xmm1
00007588ecdd65ca  movaps [r15+0x290], xmm15
00007588ecdd65d2  vmovaps xmm1, [rsp+0xF0]
00007588ecdd65db  vmovaps [rsp+0x70], xmm15
00007588ecdd65e1  vmovaps xmm15, [rsp+0xF0]
00007588ecdd65ea  por xmm1, xmm15
00007588ecdd65ef  movaps [r15+0x2C0], xmm1
00007588ecdd65f7  movq xmm15, qword ptr [r15+0x240]
00007588ecdd6600  vmovaps [rsp+0x80], xmm15
00007588ecdd6609  vpermilpd xmm15, xmm15, 0x00
00007588ecdd660f  vmovaps [rsp+0xC0], xmm1
00007588ecdd6618  vmovaps xmm1, [rsp+0x40]
00007588ecdd661e  vmovaps [rsp+0x40], xmm15
00007588ecdd6624  vmovaps xmm15, [rsp+0x30]
00007588ecdd662a  vmovaps [rsp+0x30], xmm14
00007588ecdd6630  vmovaps xmm14, [rsp+0x40]
00007588ecdd6636  vmovaps [rsp+0x40], xmm13
00007588ecdd663c  vmovaps [rsp+0xD0], xmm12
00007588ecdd6645  movaps xmm13, xmm1
00007588ecdd6649  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd6654  vptest xmm12, xmm12
00007588ecdd6659  jnz 0x00007588ECDD7314
00007588ecdd665f  vmovaps xmm1, [rsp+0x80]
00007588ecdd6668  vpermilpd xmm1, xmm1, 0x00
00007588ecdd666e  vmovaps xmm15, [rsp+0xA0]
00007588ecdd6677  movaps xmm14, xmm15
00007588ecdd667b  vfmadd231pd xmm14, xmm2, xmm1
00007588ecdd6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007588ecdd6686  vptest xmm12, xmm12
00007588ecdd668b  jnz 0x00007588ECDD746D
00007588ecdd6691  vmovaps xmm1, [rsp+0x80]
00007588ecdd669a  vpermilpd xmm1, xmm1, 0x00
00007588ecdd66a0  vmovaps xmm15, [rsp+0x120]
00007588ecdd66a9  vmovaps xmm12, [rsp+0x50]
00007588ecdd66af  vmovaps [rsp+0x50], xmm14
00007588ecdd66b5  movaps xmm2, xmm15
00007588ecdd66b9  vfmadd231pd xmm2, xmm12, xmm1
00007588ecdd66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007588ecdd66c3  vptest xmm14, xmm14
00007588ecdd66c8  jnz 0x00007588ECDD75C5
00007588ecdd66ce  vmovaps xmm1, [rsp+0x110]
00007588ecdd66d7  vmovaps xmm15, [rsp+0x110]
00007588ecdd66e0  por xmm1, xmm15
00007588ecdd66e5  movaps [r15+0x1D0], xmm1
00007588ecdd66ed  vmovaps xmm15, [rsp+0x80]
00007588ecdd66f6  vpermilpd xmm15, xmm15, 0x00
00007588ecdd66fc  vmovaps xmm14, [rsp+0xD0]
00007588ecdd6705  vmovaps [rsp+0x80], xmm1
00007588ecdd670e  movaps xmm12, xmm14
00007588ecdd6712  vfmadd231pd xmm12, xmm3, xmm15
00007588ecdd6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007588ecdd671d  vptest xmm1, xmm1
00007588ecdd6722  jnz 0x00007588ECDD771C
00007588ecdd6728  vmovaps [rsp+0xA0], xmm4
00007588ecdd6731  vmovaps xmm1, [rsp+0xA0]
00007588ecdd673a  por xmm4, xmm1
00007588ecdd673e  movaps [r15+0x200], xmm4
00007588ecdd6746  vmovaps xmm1, [rsp+0xE0]
00007588ecdd674f  vmovaps xmm15, [rsp+0xE0]
00007588ecdd6758  por xmm1, xmm15
00007588ecdd675d  movaps [r15+0x1E0], xmm1
00007588ecdd6765  vmovaps [rsp+0xA0], xmm8
00007588ecdd676e  vmovaps xmm1, [rsp+0xA0]
00007588ecdd6777  por xmm8, xmm1
00007588ecdd677c  movaps [r15+0x2B0], xmm8
00007588ecdd6784  vmovaps [rsp+0xA0], xmm9
00007588ecdd678d  vmovaps xmm1, [rsp+0xA0]
00007588ecdd6796  por xmm9, xmm1
00007588ecdd679b  movaps [r15+0x300], xmm9
00007588ecdd67a3  vmovaps [rsp+0xA0], xmm6
00007588ecdd67ac  vpermilpd xmm6, xmm6, 0x00
00007588ecdd67b2  vmovaps xmm14, [rsp+0x60]
00007588ecdd67b8  movaps xmm9, xmm13
00007588ecdd67bc  vfmadd231pd xmm9, xmm14, xmm6
00007588ecdd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007588ecdd67c7  vptest xmm3, xmm3
00007588ecdd67cc  jnz 0x00007588ECDD7875
00007588ecdd67d2  vmovaps xmm14, [rsp+0xA0]
00007588ecdd67db  vpermilpd xmm14, xmm14, 0x00
00007588ecdd67e1  vmovaps xmm13, [rsp+0x50]
00007588ecdd67e7  vmovaps xmm6, [rsp+0xC0]
00007588ecdd67f0  vmovaps [rsp+0x50], xmm1
00007588ecdd67f6  movaps xmm3, xmm13
00007588ecdd67fa  vfmadd231pd xmm3, xmm6, xmm14
00007588ecdd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007588ecdd6804  vptest xmm1, xmm1
00007588ecdd6809  jnz 0x00007588ECDD79CE
00007588ecdd680f  vmovaps xmm1, [rsp+0xA0]
00007588ecdd6818  vpermilpd xmm1, xmm1, 0x00
00007588ecdd681e  vmovaps xmm14, [rsp+0x30]
00007588ecdd6824  movaps xmm6, xmm2
00007588ecdd6827  vfmadd231pd xmm6, xmm14, xmm1
00007588ecdd682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007588ecdd6831  vptest xmm13, xmm13
00007588ecdd6836  jnz 0x00007588ECDD7B25
00007588ecdd683c  vmovaps xmm1, [rsp+0xA0]
00007588ecdd6845  vpermilpd xmm1, xmm1, 0x00
00007588ecdd684b  vmovaps xmm14, [rsp+0x80]
00007588ecdd6854  movaps xmm13, xmm12
00007588ecdd6858  vfmadd231pd xmm13, xmm14, xmm1
00007588ecdd685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007588ecdd6863  vptest xmm2, xmm2
00007588ecdd6868  jnz 0x00007588ECDD7C7B
00007588ecdd686e  vmovaps [rsp+0x30], xmm7
00007588ecdd6874  vmovaps xmm1, [rsp+0x30]
00007588ecdd687a  por xmm7, xmm1
00007588ecdd687e  movaps [r15+0x180], xmm7
00007588ecdd6886  vmovaps [rsp+0x30], xmm10
00007588ecdd688c  vmovaps xmm1, [rsp+0x30]
00007588ecdd6892  por xmm10, xmm1
00007588ecdd6897  movaps [r15+0x2D0], xmm10
00007588ecdd689f  vmovaps [rsp+0x30], xmm5
00007588ecdd68a5  vpermilpd xmm5, xmm5, 0x00
00007588ecdd68ab  vmovaps xmm14, [rsp+0x50]
00007588ecdd68b1  movaps xmm12, xmm3
00007588ecdd68b5  vfmadd231pd xmm12, xmm14, xmm5
00007588ecdd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007588ecdd68c0  vptest xmm10, xmm10
00007588ecdd68c5  jnz 0x00007588ECDD7DD4
00007588ecdd68cb  vmovaps xmm14, [rsp+0x30]
00007588ecdd68d1  vpermilpd xmm14, xmm14, 0x00
00007588ecdd68d7  movaps xmm10, xmm9
00007588ecdd68db  vfmadd231pd xmm10, xmm7, xmm14
00007588ecdd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007588ecdd68e6  vptest xmm5, xmm5
00007588ecdd68eb  jnz 0x00007588ECDD7F2C
00007588ecdd68f1  lea r14, [rax+0x80]
00007588ecdd68f8  movups xmm14, [r13+r14*1]
00007588ecdd68fe  movaps [r15+0x2F0], xmm14
00007588ecdd6906  vmovaps xmm9, [rsp+0x30]
00007588ecdd690c  vpermilpd xmm9, xmm9, 0x00
00007588ecdd6912  vmovaps xmm7, [rsp+0x70]
00007588ecdd6918  movaps xmm5, xmm6
00007588ecdd691b  vfmadd231pd xmm5, xmm7, xmm9
00007588ecdd6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007588ecdd6925  vptest xmm3, xmm3
00007588ecdd692a  jnz 0x00007588ECDD808F
00007588ecdd6930  vmovaps xmm9, [rsp+0x30]
00007588ecdd6936  vpermilpd xmm9, xmm9, 0x00
00007588ecdd693c  movaps xmm7, xmm13
00007588ecdd6940  vfmadd231pd xmm7, xmm1, xmm9
00007588ecdd6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007588ecdd694a  vptest xmm6, xmm6
00007588ecdd694f  jnz 0x00007588ECDD81E5
00007588ecdd6955  vmovaps xmm1, [rsp+0x20]
00007588ecdd695b  vmovaps xmm13, [rsp+0x20]
00007588ecdd6961  por xmm1, xmm13
00007588ecdd6966  movaps [r15+0x160], xmm1
00007588ecdd696e  lea r14, [rax+0x40]
00007588ecdd6972  movups xmm13, [r13+r14*1]
00007588ecdd6978  lea r14, [rax+0x50]
00007588ecdd697c  movups xmm9, [r13+r14*1]
00007588ecdd6982  movaps [r15+0x1B0], xmm13
00007588ecdd698a  movaps [r15+0x1A0], xmm9
00007588ecdd6992  movaps xmm6, [r15+0x190]
00007588ecdd699a  vmovaps xmm3, [rsp+0xB0]
00007588ecdd69a3  vpermilpd xmm3, xmm3, 0x00
00007588ecdd69a9  vmovaps [rsp+0x20], xmm1
00007588ecdd69af  movaps xmm2, xmm12
00007588ecdd69b3  vfmadd231pd xmm2, xmm6, xmm3
00007588ecdd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007588ecdd69bd  vptest xmm1, xmm1
00007588ecdd69c2  jnz 0x00007588ECDD8350
00007588ecdd69c8  vmovaps xmm1, [rsp+0xB0]
00007588ecdd69d1  vpermilpd xmm1, xmm1, 0x00
00007588ecdd69d7  vmovaps xmm12, [rsp+0x20]
00007588ecdd69dd  movaps xmm6, xmm10
00007588ecdd69e1  vfmadd231pd xmm6, xmm12, xmm1
00007588ecdd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007588ecdd69eb  vptest xmm3, xmm3
00007588ecdd69f0  jnz 0x00007588ECDD84A6
00007588ecdd69f6  vmovaps xmm1, [rsp+0xB0]
00007588ecdd69ff  vpermilpd xmm1, xmm1, 0x00
00007588ecdd6a05  vmovaps xmm12, [rsp+0x40]
00007588ecdd6a0b  movaps xmm10, xmm5
00007588ecdd6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007588ecdd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007588ecdd6a1a  vptest xmm3, xmm3
00007588ecdd6a1f  jnz 0x00007588ECDD85FD
00007588ecdd6a25  vmovaps xmm1, [rsp+0xB0]
00007588ecdd6a2e  vpermilpd xmm1, xmm1, 0x00
00007588ecdd6a34  movaps xmm12, xmm7
00007588ecdd6a38  vfmadd231pd xmm12, xmm15, xmm1
00007588ecdd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007588ecdd6a43  vptest xmm5, xmm5
00007588ecdd6a48  jnz 0x00007588ECDD8755
00007588ecdd6a4e  lea r14, [rax+0x60]
00007588ecdd6a52  movups xmm1, [r13+r14*1]
00007588ecdd6a58  lea r14, [rax+0x70]
00007588ecdd6a5c  movups xmm15, [r13+r14*1]
00007588ecdd6a62  movaps [r15+0x150], xmm1
00007588ecdd6a6a  movaps [r15+0x120], xmm15
00007588ecdd6a72  vmovaps [rsp+0x20], xmm11
00007588ecdd6a78  vpermilpd xmm11, xmm11, 0x00
00007588ecdd6a7e  movaps xmm7, xmm2
00007588ecdd6a81  vfmadd231pd xmm7, xmm9, xmm11
00007588ecdd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007588ecdd6a8b  vptest xmm5, xmm5
00007588ecdd6a90  jnz 0x00007588ECDD88C1
00007588ecdd6a96  vmovaps xmm11, [rsp+0x20]
00007588ecdd6a9c  vpermilpd xmm11, xmm11, 0x00
00007588ecdd6aa2  movaps xmm9, xmm6
00007588ecdd6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007588ecdd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007588ecdd6ab1  vptest xmm5, xmm5
00007588ecdd6ab6  jnz 0x00007588ECDD8A18
00007588ecdd6abc  vmovaps xmm1, [rsp+0x20]
00007588ecdd6ac2  vpermilpd xmm1, xmm1, 0x00
00007588ecdd6ac8  movaps xmm11, xmm10
00007588ecdd6acc  vfmadd231pd xmm11, xmm8, xmm1
00007588ecdd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007588ecdd6ad7  vptest xmm6, xmm6
00007588ecdd6adc  jnz 0x00007588ECDD8B70
00007588ecdd6ae2  vmovaps xmm1, [rsp+0x20]
00007588ecdd6ae8  vpermilpd xmm1, xmm1, 0x00
00007588ecdd6aee  movaps xmm10, xmm12
00007588ecdd6af2  vfmadd231pd xmm10, xmm13, xmm1
00007588ecdd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007588ecdd6afd  vptest xmm8, xmm8
00007588ecdd6b02  jnz 0x00007588ECDD8CC9
00007588ecdd6b08  lea r14, [rax+0x20]
00007588ecdd6b0c  movups xmm1, [r13+r14*1]
00007588ecdd6b12  lea r14, [rax+0x30]
00007588ecdd6b16  movups xmm13, [r13+r14*1]
00007588ecdd6b1c  vmovaps xmm12, [rsp+0x90]
00007588ecdd6b25  vpermilpd xmm12, xmm12, 0x00
00007588ecdd6b2b  movaps xmm8, xmm7
00007588ecdd6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007588ecdd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007588ecdd6b3a  vptest xmm6, xmm6
00007588ecdd6b3f  jnz 0x00007588ECDD8E36
00007588ecdd6b45  vmovaps xmm12, [rsp+0x90]
00007588ecdd6b4e  vpermilpd xmm12, xmm12, 0x00
00007588ecdd6b54  movaps xmm7, xmm9
00007588ecdd6b58  vfmadd231pd xmm7, xmm14, xmm12
00007588ecdd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007588ecdd6b62  vptest xmm6, xmm6
00007588ecdd6b67  jnz 0x00007588ECDD8F8E
00007588ecdd6b6d  vmovaps xmm14, [rsp+0x90]
00007588ecdd6b76  vpermilpd xmm14, xmm14, 0x00
00007588ecdd6b7c  movaps xmm12, xmm11
00007588ecdd6b80  vfmadd231pd xmm12, xmm15, xmm14
00007588ecdd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007588ecdd6b8b  vptest xmm9, xmm9
00007588ecdd6b90  jnz 0x00007588ECDD90E6
00007588ecdd6b96  vmovaps xmm15, [rsp+0x90]
00007588ecdd6b9f  vpermilpd xmm15, xmm15, 0x00
00007588ecdd6ba5  movaps xmm11, xmm10
00007588ecdd6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007588ecdd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007588ecdd6bb4  vptest xmm14, xmm14
00007588ecdd6bb9  jnz 0x00007588ECDD9240
00007588ecdd6bbf  lea r14, [rax+0x90]
00007588ecdd6bc6  movups xmm15, [r13+r14*1]
00007588ecdd6bcc  lea r14, [rax+0xA0]
00007588ecdd6bd3  movups xmm14, [r13+r14*1]
00007588ecdd6bd9  movaps [r15+0x140], xmm15
00007588ecdd6be1  movaps [r15+0x130], xmm14
00007588ecdd6be9  vmovaps xmm13, [rsp+0x10]
00007588ecdd6bef  vpermilpd xmm13, xmm13, 0x00
00007588ecdd6bf5  movaps xmm10, xmm8
00007588ecdd6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007588ecdd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007588ecdd6c04  vptest xmm9, xmm9
00007588ecdd6c09  jnz 0x00007588ECDD93AE
00007588ecdd6c0f  movaps [r15+0x220], xmm10
00007588ecdd6c17  lea r14, [rax+0x10]
00007588ecdd6c1b  movups xmm1, [r13+r14*1]
00007588ecdd6c21  movaps [r15+0x240], xmm1
00007588ecdd6c29  vmovaps xmm13, [rsp+0x10]
00007588ecdd6c2f  vpermilpd xmm13, xmm13, 0x00
00007588ecdd6c35  movaps xmm9, xmm7
00007588ecdd6c39  vfmadd231pd xmm9, xmm14, xmm13
00007588ecdd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007588ecdd6c44  vptest xmm8, xmm8
00007588ecdd6c49  jnz 0x00007588ECDD9511
00007588ecdd6c4f  movaps [r15+0x110], xmm9
00007588ecdd6c57  vmovaps xmm14, [rsp+0x10]
00007588ecdd6c5d  vpermilpd xmm14, xmm14, 0x00
00007588ecdd6c63  movaps xmm13, xmm12
00007588ecdd6c67  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007588ecdd6c72  vptest xmm8, xmm8
00007588ecdd6c77  jnz 0x00007588ECDD966A
00007588ecdd6c7d  movaps [r15+0x170], xmm13
00007588ecdd6c85  vmovaps xmm15, [rsp+0x10]
00007588ecdd6c8b  vpermilpd xmm15, xmm15, 0x00
00007588ecdd6c91  movaps xmm14, xmm11
00007588ecdd6c95  vfmadd231pd xmm14, xmm1, xmm15
00007588ecdd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007588ecdd6ca0  vptest xmm12, xmm12
00007588ecdd6ca5  jnz 0x00007588ECDD97C4
00007588ecdd6cab  movaps [r15+0x230], xmm14
00007588ecdd6cb3  movups [r13+r11*1], xmm9
00007588ecdd6cb9  lea rax, [r11+0x10]
00007588ecdd6cbd  movups [r13+rax*1], xmm13
00007588ecdd6cc3  lea rax, [r11+0x20]
00007588ecdd6cc7  movups [r13+rax*1], xmm10
00007588ecdd6ccd  lea rax, [r11+0x30]
00007588ecdd6cd1  movups [r13+rax*1], xmm14
00007588ecdd6cd7  mov eax, [r15+0x108]
00007588ecdd6cde  sahf
00007588ecdd6cdf  jnz 0x00007588ECDD6D11
00007588ecdd6ce1  cmp dword ptr [r15+0x318], 0x00
00007588ecdd6ce9  jz 0x00007588ECDD9950
00007588ecdd6cef  nop [rax+rax*1], ax
00007588ecdd6cf8  nop [rax+rax*1], eax
00007588ecdd6d00  mov eax, 0x410664
00007588ecdd6d05  mov [r15+0x100], rax
00007588ecdd6d0c  jmp 0x00007588ECBFE110
00007588ecdd6d11  cmp dword ptr [r15+0x318], 0x00
00007588ecdd6d19  jz 0x00007588ECDD6050
00007588ecdd6d1f  nop [rax+rax*1], ax
00007588ecdd6d28  nop [rax+rax*1], eax
00007588ecdd6d30  mov eax, 0x4104F0
00007588ecdd6d35  mov [r15+0x100], rax
00007588ecdd6d3c  jmp 0x00007588ECBFE110
00007588ecdd6d41  int3
00007588ecdd6d42  call 0x00007588ECC0A4B0
00007588ecdd6d47  jmp 0x00007588ECDD6079
00007588ecdd6d4c  call 0x00007588ECC09240
00007588ecdd6d51  jmp 0x00007588ECDD6083
00007588ecdd6d56  call 0x00007588ECC0A4B0
00007588ecdd6d5b  jmp 0x00007588ECDD60CD
00007588ecdd6d60  call 0x00007588ECC09240
00007588ecdd6d65  jmp 0x00007588ECDD60D7
00007588ecdd6d6a  call 0x00007588ECC0A4B0
00007588ecdd6d6f  jmp 0x00007588ECDD6158
00007588ecdd6d74  call 0x00007588ECC09240
00007588ecdd6d79  jmp 0x00007588ECDD6162
00007588ecdd6d7e  call 0x00007588ECCB47C0
00007588ecdd6d83  jmp 0x00007588ECDD6243
00007588ecdd6d88  call 0x00007588ECBFF430
00007588ecdd6d8d  jmp 0x00007588ECDD6272
00007588ecdd6d92  call 0x00007588ECCB0CE0
00007588ecdd6d97  jmp 0x00007588ECDD628E
00007588ecdd6d9c  sub rsp, 0x08
00007588ecdd6da0  push rax
00007588ecdd6da1  push rcx
00007588ecdd6da2  push rdx
00007588ecdd6da3  push rdi
00007588ecdd6da4  push rsi
00007588ecdd6da5  push r8
00007588ecdd6da7  push r9
00007588ecdd6da9  push r10
00007588ecdd6dab  push r11
00007588ecdd6dad  sub rsp, 0xF0
00007588ecdd6db4  vmovaps [rsp], xmm0
00007588ecdd6db9  vmovaps [rsp+0x10], xmm1
00007588ecdd6dbf  vmovaps [rsp+0x20], xmm2
00007588ecdd6dc5  vmovaps [rsp+0x30], xmm3
00007588ecdd6dcb  vmovaps [rsp+0x40], xmm4
00007588ecdd6dd1  vmovaps [rsp+0x50], xmm5
00007588ecdd6dd7  vmovaps [rsp+0x60], xmm6
00007588ecdd6ddd  vmovaps [rsp+0x70], xmm7
00007588ecdd6de3  vmovaps [rsp+0x80], xmm8
00007588ecdd6dec  vmovaps [rsp+0x90], xmm9
00007588ecdd6df5  vmovaps [rsp+0xA0], xmm10
00007588ecdd6dfe  vmovaps [rsp+0xB0], xmm11
00007588ecdd6e07  vmovaps [rsp+0xC0], xmm12
00007588ecdd6e10  vmovaps [rsp+0xD0], xmm14
00007588ecdd6e19  vmovaps [rsp+0xE0], xmm15
00007588ecdd6e22  sub rsp, 0x40
00007588ecdd6e26  lea rdi, [rsp]
00007588ecdd6e2a  lea rsi, [rsp+0x10]
00007588ecdd6e2f  lea rdx, [rsp+0x20]
00007588ecdd6e34  lea rcx, [rsp+0x30]
00007588ecdd6e39  mov r8d, 0x00
00007588ecdd6e3f  lea r9, [r15+0x3A8]
00007588ecdd6e46  movaps [rdi], xmm13
00007588ecdd6e4a  movaps [rsi], xmm1
00007588ecdd6e4d  movaps [rdx], xmm15
00007588ecdd6e51  movaps [rcx], xmm14
00007588ecdd6e55  mov rax, 0x6516BF3BBA50
00007588ecdd6e5f  call rax
00007588ecdd6e61  movaps xmm13, [rsp]
00007588ecdd6e66  add rsp, 0x40
00007588ecdd6e6a  vmovaps xmm0, [rsp]
00007588ecdd6e6f  vmovaps xmm1, [rsp+0x10]
00007588ecdd6e75  vmovaps xmm2, [rsp+0x20]
00007588ecdd6e7b  vmovaps xmm3, [rsp+0x30]
00007588ecdd6e81  vmovaps xmm4, [rsp+0x40]
00007588ecdd6e87  vmovaps xmm5, [rsp+0x50]
00007588ecdd6e8d  vmovaps xmm6, [rsp+0x60]
00007588ecdd6e93  vmovaps xmm7, [rsp+0x70]
00007588ecdd6e99  vmovaps xmm8, [rsp+0x80]
00007588ecdd6ea2  vmovaps xmm9, [rsp+0x90]
00007588ecdd6eab  vmovaps xmm10, [rsp+0xA0]
00007588ecdd6eb4  vmovaps xmm11, [rsp+0xB0]
00007588ecdd6ebd  vmovaps xmm12, [rsp+0xC0]
00007588ecdd6ec6  vmovaps xmm14, [rsp+0xD0]
00007588ecdd6ecf  vmovaps xmm15, [rsp+0xE0]
00007588ecdd6ed8  add rsp, 0xF0
00007588ecdd6edf  pop r11
00007588ecdd6ee1  pop r10
00007588ecdd6ee3  pop r9
00007588ecdd6ee5  pop r8
00007588ecdd6ee7  pop rsi
00007588ecdd6ee8  pop rdi
00007588ecdd6ee9  pop rdx
00007588ecdd6eea  pop rcx
00007588ecdd6eeb  pop rax
00007588ecdd6eec  add rsp, 0x08
00007588ecdd6ef0  jmp 0x00007588ECDD6305
00007588ecdd6ef5  sub rsp, 0x08
00007588ecdd6ef9  push rax
00007588ecdd6efa  push rcx
00007588ecdd6efb  push rdx
00007588ecdd6efc  push rdi
00007588ecdd6efd  push rsi
00007588ecdd6efe  push r8
00007588ecdd6f00  push r9
00007588ecdd6f02  push r10
00007588ecdd6f04  push r11
00007588ecdd6f06  sub rsp, 0xF0
00007588ecdd6f0d  vmovaps [rsp], xmm0
00007588ecdd6f12  vmovaps [rsp+0x10], xmm1
00007588ecdd6f18  vmovaps [rsp+0x20], xmm2
00007588ecdd6f1e  vmovaps [rsp+0x30], xmm3
00007588ecdd6f24  vmovaps [rsp+0x40], xmm4
00007588ecdd6f2a  vmovaps [rsp+0x50], xmm5
00007588ecdd6f30  vmovaps [rsp+0x60], xmm6
00007588ecdd6f36  vmovaps [rsp+0x70], xmm7
00007588ecdd6f3c  vmovaps [rsp+0x80], xmm8
00007588ecdd6f45  vmovaps [rsp+0x90], xmm9
00007588ecdd6f4e  vmovaps [rsp+0xA0], xmm10
00007588ecdd6f57  vmovaps [rsp+0xB0], xmm11
00007588ecdd6f60  vmovaps [rsp+0xC0], xmm13
00007588ecdd6f69  vmovaps [rsp+0xD0], xmm14
00007588ecdd6f72  vmovaps [rsp+0xE0], xmm15
00007588ecdd6f7b  sub rsp, 0x40
00007588ecdd6f7f  lea rdi, [rsp]
00007588ecdd6f83  lea rsi, [rsp+0x10]
00007588ecdd6f88  lea rdx, [rsp+0x20]
00007588ecdd6f8d  lea rcx, [rsp+0x30]
00007588ecdd6f92  mov r8d, 0x00
00007588ecdd6f98  lea r9, [r15+0x3A8]
00007588ecdd6f9f  movaps [rdi], xmm12
00007588ecdd6fa3  movaps [rsi], xmm15
00007588ecdd6fa7  movaps [rdx], xmm1
00007588ecdd6faa  movaps [rcx], xmm14
00007588ecdd6fae  mov rax, 0x6516BF3BBA50
00007588ecdd6fb8  call rax
00007588ecdd6fba  movaps xmm12, [rsp]
00007588ecdd6fbf  add rsp, 0x40
00007588ecdd6fc3  vmovaps xmm0, [rsp]
00007588ecdd6fc8  vmovaps xmm1, [rsp+0x10]
00007588ecdd6fce  vmovaps xmm2, [rsp+0x20]
00007588ecdd6fd4  vmovaps xmm3, [rsp+0x30]
00007588ecdd6fda  vmovaps xmm4, [rsp+0x40]
00007588ecdd6fe0  vmovaps xmm5, [rsp+0x50]
00007588ecdd6fe6  vmovaps xmm6, [rsp+0x60]
00007588ecdd6fec  vmovaps xmm7, [rsp+0x70]
00007588ecdd6ff2  vmovaps xmm8, [rsp+0x80]
00007588ecdd6ffb  vmovaps xmm9, [rsp+0x90]
00007588ecdd7004  vmovaps xmm10, [rsp+0xA0]
00007588ecdd700d  vmovaps xmm11, [rsp+0xB0]
00007588ecdd7016  vmovaps xmm13, [rsp+0xC0]
00007588ecdd701f  vmovaps xmm14, [rsp+0xD0]
00007588ecdd7028  vmovaps xmm15, [rsp+0xE0]
00007588ecdd7031  add rsp, 0xF0
00007588ecdd7038  pop r11
00007588ecdd703a  pop r10
00007588ecdd703c  pop r9
00007588ecdd703e  pop r8
00007588ecdd7040  pop rsi
00007588ecdd7041  pop rdi
00007588ecdd7042  pop rdx
00007588ecdd7043  pop rcx
00007588ecdd7044  pop rax
00007588ecdd7045  add rsp, 0x08
00007588ecdd7049  jmp 0x00007588ECDD6333
00007588ecdd704e  call 0x00007588ECCD64F0
00007588ecdd7053  jmp 0x00007588ECDD641F
00007588ecdd7058  sub rsp, 0x08
00007588ecdd705c  push rax
00007588ecdd705d  push rcx
00007588ecdd705e  push rdx
00007588ecdd705f  push rdi
00007588ecdd7060  push rsi
00007588ecdd7061  push r8
00007588ecdd7063  push r9
00007588ecdd7065  push r10
00007588ecdd7067  push r11
00007588ecdd7069  sub rsp, 0xF0
00007588ecdd7070  vmovaps [rsp], xmm0
00007588ecdd7075  vmovaps [rsp+0x10], xmm1
00007588ecdd707b  vmovaps [rsp+0x20], xmm2
00007588ecdd7081  vmovaps [rsp+0x30], xmm3
00007588ecdd7087  vmovaps [rsp+0x40], xmm4
00007588ecdd708d  vmovaps [rsp+0x50], xmm5
00007588ecdd7093  vmovaps [rsp+0x60], xmm6
00007588ecdd7099  vmovaps [rsp+0x70], xmm7
00007588ecdd709f  vmovaps [rsp+0x80], xmm8
00007588ecdd70a8  vmovaps [rsp+0x90], xmm9
00007588ecdd70b1  vmovaps [rsp+0xA0], xmm10
00007588ecdd70ba  vmovaps [rsp+0xB0], xmm11
00007588ecdd70c3  vmovaps [rsp+0xC0], xmm12
00007588ecdd70cc  vmovaps [rsp+0xD0], xmm14
00007588ecdd70d5  vmovaps [rsp+0xE0], xmm15
00007588ecdd70de  sub rsp, 0x40
00007588ecdd70e2  lea rdi, [rsp]
00007588ecdd70e6  lea rsi, [rsp+0x10]
00007588ecdd70eb  lea rdx, [rsp+0x20]
00007588ecdd70f0  lea rcx, [rsp+0x30]
00007588ecdd70f5  mov r8d, 0x00
00007588ecdd70fb  lea r9, [r15+0x3A8]
00007588ecdd7102  movaps [rdi], xmm13
00007588ecdd7106  movaps [rsi], xmm1
00007588ecdd7109  movaps [rdx], xmm15
00007588ecdd710d  movaps [rcx], xmm14
00007588ecdd7111  mov rax, 0x6516BF3BBA50
00007588ecdd711b  call rax
00007588ecdd711d  movaps xmm13, [rsp]
00007588ecdd7122  add rsp, 0x40
00007588ecdd7126  vmovaps xmm0, [rsp]
00007588ecdd712b  vmovaps xmm1, [rsp+0x10]
00007588ecdd7131  vmovaps xmm2, [rsp+0x20]
00007588ecdd7137  vmovaps xmm3, [rsp+0x30]
00007588ecdd713d  vmovaps xmm4, [rsp+0x40]
00007588ecdd7143  vmovaps xmm5, [rsp+0x50]
00007588ecdd7149  vmovaps xmm6, [rsp+0x60]
00007588ecdd714f  vmovaps xmm7, [rsp+0x70]
00007588ecdd7155  vmovaps xmm8, [rsp+0x80]
00007588ecdd715e  vmovaps xmm9, [rsp+0x90]
00007588ecdd7167  vmovaps xmm10, [rsp+0xA0]
00007588ecdd7170  vmovaps xmm11, [rsp+0xB0]
00007588ecdd7179  vmovaps xmm12, [rsp+0xC0]
00007588ecdd7182  vmovaps xmm14, [rsp+0xD0]
00007588ecdd718b  vmovaps xmm15, [rsp+0xE0]
00007588ecdd7194  add rsp, 0xF0
00007588ecdd719b  pop r11
00007588ecdd719d  pop r10
00007588ecdd719f  pop r9
00007588ecdd71a1  pop r8
00007588ecdd71a3  pop rsi
00007588ecdd71a4  pop rdi
00007588ecdd71a5  pop rdx
00007588ecdd71a6  pop rcx
00007588ecdd71a7  pop rax
00007588ecdd71a8  add rsp, 0x08
00007588ecdd71ac  jmp 0x00007588ECDD648E
00007588ecdd71b1  call 0x00007588ECCD64F0
00007588ecdd71b6  jmp 0x00007588ECDD64A3
00007588ecdd71bb  sub rsp, 0x08
00007588ecdd71bf  push rax
00007588ecdd71c0  push rcx
00007588ecdd71c1  push rdx
00007588ecdd71c2  push rdi
00007588ecdd71c3  push rsi
00007588ecdd71c4  push r8
00007588ecdd71c6  push r9
00007588ecdd71c8  push r10
00007588ecdd71ca  push r11
00007588ecdd71cc  sub rsp, 0xF0
00007588ecdd71d3  vmovaps [rsp], xmm0
00007588ecdd71d8  vmovaps [rsp+0x10], xmm1
00007588ecdd71de  vmovaps [rsp+0x20], xmm2
00007588ecdd71e4  vmovaps [rsp+0x30], xmm3
00007588ecdd71ea  vmovaps [rsp+0x40], xmm4
00007588ecdd71f0  vmovaps [rsp+0x50], xmm5
00007588ecdd71f6  vmovaps [rsp+0x60], xmm6
00007588ecdd71fc  vmovaps [rsp+0x70], xmm7
00007588ecdd7202  vmovaps [rsp+0x80], xmm8
00007588ecdd720b  vmovaps [rsp+0x90], xmm9
00007588ecdd7214  vmovaps [rsp+0xA0], xmm10
00007588ecdd721d  vmovaps [rsp+0xB0], xmm11
00007588ecdd7226  vmovaps [rsp+0xC0], xmm13
00007588ecdd722f  vmovaps [rsp+0xD0], xmm14
00007588ecdd7238  vmovaps [rsp+0xE0], xmm15
00007588ecdd7241  sub rsp, 0x40
00007588ecdd7245  lea rdi, [rsp]
00007588ecdd7249  lea rsi, [rsp+0x10]
00007588ecdd724e  lea rdx, [rsp+0x20]
00007588ecdd7253  lea rcx, [rsp+0x30]
00007588ecdd7258  mov r8d, 0x00
00007588ecdd725e  lea r9, [r15+0x3A8]
00007588ecdd7265  movaps [rdi], xmm12
00007588ecdd7269  movaps [rsi], xmm15
00007588ecdd726d  movaps [rdx], xmm1
00007588ecdd7270  movaps [rcx], xmm14
00007588ecdd7274  mov rax, 0x6516BF3BBA50
00007588ecdd727e  call rax
00007588ecdd7280  movaps xmm12, [rsp]
00007588ecdd7285  add rsp, 0x40
00007588ecdd7289  vmovaps xmm0, [rsp]
00007588ecdd728e  vmovaps xmm1, [rsp+0x10]
00007588ecdd7294  vmovaps xmm2, [rsp+0x20]
00007588ecdd729a  vmovaps xmm3, [rsp+0x30]
00007588ecdd72a0  vmovaps xmm4, [rsp+0x40]
00007588ecdd72a6  vmovaps xmm5, [rsp+0x50]
00007588ecdd72ac  vmovaps xmm6, [rsp+0x60]
00007588ecdd72b2  vmovaps xmm7, [rsp+0x70]
00007588ecdd72b8  vmovaps xmm8, [rsp+0x80]
00007588ecdd72c1  vmovaps xmm9, [rsp+0x90]
00007588ecdd72ca  vmovaps xmm10, [rsp+0xA0]
00007588ecdd72d3  vmovaps xmm11, [rsp+0xB0]
00007588ecdd72dc  vmovaps xmm13, [rsp+0xC0]
00007588ecdd72e5  vmovaps xmm14, [rsp+0xD0]
00007588ecdd72ee  vmovaps xmm15, [rsp+0xE0]
00007588ecdd72f7  add rsp, 0xF0
00007588ecdd72fe  pop r11
00007588ecdd7300  pop r10
00007588ecdd7302  pop r9
00007588ecdd7304  pop r8
00007588ecdd7306  pop rsi
00007588ecdd7307  pop rdi
00007588ecdd7308  pop rdx
00007588ecdd7309  pop rcx
00007588ecdd730a  pop rax
00007588ecdd730b  add rsp, 0x08
00007588ecdd730f  jmp 0x00007588ECDD64CF
00007588ecdd7314  sub rsp, 0x08
00007588ecdd7318  push rax
00007588ecdd7319  push rcx
00007588ecdd731a  push rdx
00007588ecdd731b  push rdi
00007588ecdd731c  push rsi
00007588ecdd731d  push r8
00007588ecdd731f  push r9
00007588ecdd7321  push r10
00007588ecdd7323  push r11
00007588ecdd7325  sub rsp, 0xF0
00007588ecdd732c  vmovaps [rsp], xmm0
00007588ecdd7331  vmovaps [rsp+0x10], xmm1
00007588ecdd7337  vmovaps [rsp+0x20], xmm2
00007588ecdd733d  vmovaps [rsp+0x30], xmm3
00007588ecdd7343  vmovaps [rsp+0x40], xmm4
00007588ecdd7349  vmovaps [rsp+0x50], xmm5
00007588ecdd734f  vmovaps [rsp+0x60], xmm6
00007588ecdd7355  vmovaps [rsp+0x70], xmm7
00007588ecdd735b  vmovaps [rsp+0x80], xmm8
00007588ecdd7364  vmovaps [rsp+0x90], xmm9
00007588ecdd736d  vmovaps [rsp+0xA0], xmm10
00007588ecdd7376  vmovaps [rsp+0xB0], xmm11
00007588ecdd737f  vmovaps [rsp+0xC0], xmm12
00007588ecdd7388  vmovaps [rsp+0xD0], xmm14
00007588ecdd7391  vmovaps [rsp+0xE0], xmm15
00007588ecdd739a  sub rsp, 0x40
00007588ecdd739e  lea rdi, [rsp]
00007588ecdd73a2  lea rsi, [rsp+0x10]
00007588ecdd73a7  lea rdx, [rsp+0x20]
00007588ecdd73ac  lea rcx, [rsp+0x30]
00007588ecdd73b1  mov r8d, 0x00
00007588ecdd73b7  lea r9, [r15+0x3A8]
00007588ecdd73be  movaps [rdi], xmm13
00007588ecdd73c2  movaps [rsi], xmm1
00007588ecdd73c5  movaps [rdx], xmm15
00007588ecdd73c9  movaps [rcx], xmm14
00007588ecdd73cd  mov rax, 0x6516BF3BBA50
00007588ecdd73d7  call rax
00007588ecdd73d9  movaps xmm13, [rsp]
00007588ecdd73de  add rsp, 0x40
00007588ecdd73e2  vmovaps xmm0, [rsp]
00007588ecdd73e7  vmovaps xmm1, [rsp+0x10]
00007588ecdd73ed  vmovaps xmm2, [rsp+0x20]
00007588ecdd73f3  vmovaps xmm3, [rsp+0x30]
00007588ecdd73f9  vmovaps xmm4, [rsp+0x40]
00007588ecdd73ff  vmovaps xmm5, [rsp+0x50]
00007588ecdd7405  vmovaps xmm6, [rsp+0x60]
00007588ecdd740b  vmovaps xmm7, [rsp+0x70]
00007588ecdd7411  vmovaps xmm8, [rsp+0x80]
00007588ecdd741a  vmovaps xmm9, [rsp+0x90]
00007588ecdd7423  vmovaps xmm10, [rsp+0xA0]
00007588ecdd742c  vmovaps xmm11, [rsp+0xB0]
00007588ecdd7435  vmovaps xmm12, [rsp+0xC0]
00007588ecdd743e  vmovaps xmm14, [rsp+0xD0]
00007588ecdd7447  vmovaps xmm15, [rsp+0xE0]
00007588ecdd7450  add rsp, 0xF0
00007588ecdd7457  pop r11
00007588ecdd7459  pop r10
00007588ecdd745b  pop r9
00007588ecdd745d  pop r8
00007588ecdd745f  pop rsi
00007588ecdd7460  pop rdi
00007588ecdd7461  pop rdx
00007588ecdd7462  pop rcx
00007588ecdd7463  pop rax
00007588ecdd7464  add rsp, 0x08
00007588ecdd7468  jmp 0x00007588ECDD665F
00007588ecdd746d  sub rsp, 0x08
00007588ecdd7471  push rax
00007588ecdd7472  push rcx
00007588ecdd7473  push rdx
00007588ecdd7474  push rdi
00007588ecdd7475  push rsi
00007588ecdd7476  push r8
00007588ecdd7478  push r9
00007588ecdd747a  push r10
00007588ecdd747c  push r11
00007588ecdd747e  sub rsp, 0xF0
00007588ecdd7485  vmovaps [rsp], xmm0
00007588ecdd748a  vmovaps [rsp+0x10], xmm1
00007588ecdd7490  vmovaps [rsp+0x20], xmm2
00007588ecdd7496  vmovaps [rsp+0x30], xmm3
00007588ecdd749c  vmovaps [rsp+0x40], xmm4
00007588ecdd74a2  vmovaps [rsp+0x50], xmm5
00007588ecdd74a8  vmovaps [rsp+0x60], xmm6
00007588ecdd74ae  vmovaps [rsp+0x70], xmm7
00007588ecdd74b4  vmovaps [rsp+0x80], xmm8
00007588ecdd74bd  vmovaps [rsp+0x90], xmm9
00007588ecdd74c6  vmovaps [rsp+0xA0], xmm10
00007588ecdd74cf  vmovaps [rsp+0xB0], xmm11
00007588ecdd74d8  vmovaps [rsp+0xC0], xmm12
00007588ecdd74e1  vmovaps [rsp+0xD0], xmm13
00007588ecdd74ea  vmovaps [rsp+0xE0], xmm15
00007588ecdd74f3  sub rsp, 0x40
00007588ecdd74f7  lea rdi, [rsp]
00007588ecdd74fb  lea rsi, [rsp+0x10]
00007588ecdd7500  lea rdx, [rsp+0x20]
00007588ecdd7505  lea rcx, [rsp+0x30]
00007588ecdd750a  mov r8d, 0x00
00007588ecdd7510  lea r9, [r15+0x3A8]
00007588ecdd7517  movaps [rdi], xmm14
00007588ecdd751b  movaps [rsi], xmm15
00007588ecdd751f  movaps [rdx], xmm2
00007588ecdd7522  movaps [rcx], xmm1
00007588ecdd7525  mov rax, 0x6516BF3BBA50
00007588ecdd752f  call rax
00007588ecdd7531  movaps xmm14, [rsp]
00007588ecdd7536  add rsp, 0x40
00007588ecdd753a  vmovaps xmm0, [rsp]
00007588ecdd753f  vmovaps xmm1, [rsp+0x10]
00007588ecdd7545  vmovaps xmm2, [rsp+0x20]
00007588ecdd754b  vmovaps xmm3, [rsp+0x30]
00007588ecdd7551  vmovaps xmm4, [rsp+0x40]
00007588ecdd7557  vmovaps xmm5, [rsp+0x50]
00007588ecdd755d  vmovaps xmm6, [rsp+0x60]
00007588ecdd7563  vmovaps xmm7, [rsp+0x70]
00007588ecdd7569  vmovaps xmm8, [rsp+0x80]
00007588ecdd7572  vmovaps xmm9, [rsp+0x90]
00007588ecdd757b  vmovaps xmm10, [rsp+0xA0]
00007588ecdd7584  vmovaps xmm11, [rsp+0xB0]
00007588ecdd758d  vmovaps xmm12, [rsp+0xC0]
00007588ecdd7596  vmovaps xmm13, [rsp+0xD0]
00007588ecdd759f  vmovaps xmm15, [rsp+0xE0]
00007588ecdd75a8  add rsp, 0xF0
00007588ecdd75af  pop r11
00007588ecdd75b1  pop r10
00007588ecdd75b3  pop r9
00007588ecdd75b5  pop r8
00007588ecdd75b7  pop rsi
00007588ecdd75b8  pop rdi
00007588ecdd75b9  pop rdx
00007588ecdd75ba  pop rcx
00007588ecdd75bb  pop rax
00007588ecdd75bc  add rsp, 0x08
00007588ecdd75c0  jmp 0x00007588ECDD6691
00007588ecdd75c5  sub rsp, 0x08
00007588ecdd75c9  push rax
00007588ecdd75ca  push rcx
00007588ecdd75cb  push rdx
00007588ecdd75cc  push rdi
00007588ecdd75cd  push rsi
00007588ecdd75ce  push r8
00007588ecdd75d0  push r9
00007588ecdd75d2  push r10
00007588ecdd75d4  push r11
00007588ecdd75d6  sub rsp, 0xF0
00007588ecdd75dd  vmovaps [rsp], xmm0
00007588ecdd75e2  vmovaps [rsp+0x10], xmm1
00007588ecdd75e8  vmovaps [rsp+0x20], xmm3
00007588ecdd75ee  vmovaps [rsp+0x30], xmm4
00007588ecdd75f4  vmovaps [rsp+0x40], xmm5
00007588ecdd75fa  vmovaps [rsp+0x50], xmm6
00007588ecdd7600  vmovaps [rsp+0x60], xmm7
00007588ecdd7606  vmovaps [rsp+0x70], xmm8
00007588ecdd760c  vmovaps [rsp+0x80], xmm9
00007588ecdd7615  vmovaps [rsp+0x90], xmm10
00007588ecdd761e  vmovaps [rsp+0xA0], xmm11
00007588ecdd7627  vmovaps [rsp+0xB0], xmm12
00007588ecdd7630  vmovaps [rsp+0xC0], xmm13
00007588ecdd7639  vmovaps [rsp+0xD0], xmm14
00007588ecdd7642  vmovaps [rsp+0xE0], xmm15
00007588ecdd764b  sub rsp, 0x40
00007588ecdd764f  lea rdi, [rsp]
00007588ecdd7653  lea rsi, [rsp+0x10]
00007588ecdd7658  lea rdx, [rsp+0x20]
00007588ecdd765d  lea rcx, [rsp+0x30]
00007588ecdd7662  mov r8d, 0x00
00007588ecdd7668  lea r9, [r15+0x3A8]
00007588ecdd766f  movaps [rdi], xmm2
00007588ecdd7672  movaps [rsi], xmm15
00007588ecdd7676  movaps [rdx], xmm12
00007588ecdd767a  movaps [rcx], xmm1
00007588ecdd767d  mov rax, 0x6516BF3BBA50
00007588ecdd7687  call rax
00007588ecdd7689  movaps xmm2, [rsp]
00007588ecdd768d  add rsp, 0x40
00007588ecdd7691  vmovaps xmm0, [rsp]
00007588ecdd7696  vmovaps xmm1, [rsp+0x10]
00007588ecdd769c  vmovaps xmm3, [rsp+0x20]
00007588ecdd76a2  vmovaps xmm4, [rsp+0x30]
00007588ecdd76a8  vmovaps xmm5, [rsp+0x40]
00007588ecdd76ae  vmovaps xmm6, [rsp+0x50]
00007588ecdd76b4  vmovaps xmm7, [rsp+0x60]
00007588ecdd76ba  vmovaps xmm8, [rsp+0x70]
00007588ecdd76c0  vmovaps xmm9, [rsp+0x80]
00007588ecdd76c9  vmovaps xmm10, [rsp+0x90]
00007588ecdd76d2  vmovaps xmm11, [rsp+0xA0]
00007588ecdd76db  vmovaps xmm12, [rsp+0xB0]
00007588ecdd76e4  vmovaps xmm13, [rsp+0xC0]
00007588ecdd76ed  vmovaps xmm14, [rsp+0xD0]
00007588ecdd76f6  vmovaps xmm15, [rsp+0xE0]
00007588ecdd76ff  add rsp, 0xF0
00007588ecdd7706  pop r11
00007588ecdd7708  pop r10
00007588ecdd770a  pop r9
00007588ecdd770c  pop r8
00007588ecdd770e  pop rsi
00007588ecdd770f  pop rdi
00007588ecdd7710  pop rdx
00007588ecdd7711  pop rcx
00007588ecdd7712  pop rax
00007588ecdd7713  add rsp, 0x08
00007588ecdd7717  jmp 0x00007588ECDD66CE
00007588ecdd771c  sub rsp, 0x08
00007588ecdd7720  push rax
00007588ecdd7721  push rcx
00007588ecdd7722  push rdx
00007588ecdd7723  push rdi
00007588ecdd7724  push rsi
00007588ecdd7725  push r8
00007588ecdd7727  push r9
00007588ecdd7729  push r10
00007588ecdd772b  push r11
00007588ecdd772d  sub rsp, 0xF0
00007588ecdd7734  vmovaps [rsp], xmm0
00007588ecdd7739  vmovaps [rsp+0x10], xmm1
00007588ecdd773f  vmovaps [rsp+0x20], xmm2
00007588ecdd7745  vmovaps [rsp+0x30], xmm3
00007588ecdd774b  vmovaps [rsp+0x40], xmm4
00007588ecdd7751  vmovaps [rsp+0x50], xmm5
00007588ecdd7757  vmovaps [rsp+0x60], xmm6
00007588ecdd775d  vmovaps [rsp+0x70], xmm7
00007588ecdd7763  vmovaps [rsp+0x80], xmm8
00007588ecdd776c  vmovaps [rsp+0x90], xmm9
00007588ecdd7775  vmovaps [rsp+0xA0], xmm10
00007588ecdd777e  vmovaps [rsp+0xB0], xmm11
00007588ecdd7787  vmovaps [rsp+0xC0], xmm13
00007588ecdd7790  vmovaps [rsp+0xD0], xmm14
00007588ecdd7799  vmovaps [rsp+0xE0], xmm15
00007588ecdd77a2  sub rsp, 0x40
00007588ecdd77a6  lea rdi, [rsp]
00007588ecdd77aa  lea rsi, [rsp+0x10]
00007588ecdd77af  lea rdx, [rsp+0x20]
00007588ecdd77b4  lea rcx, [rsp+0x30]
00007588ecdd77b9  mov r8d, 0x00
00007588ecdd77bf  lea r9, [r15+0x3A8]
00007588ecdd77c6  movaps [rdi], xmm12
00007588ecdd77ca  movaps [rsi], xmm14
00007588ecdd77ce  movaps [rdx], xmm3
00007588ecdd77d1  movaps [rcx], xmm15
00007588ecdd77d5  mov rax, 0x6516BF3BBA50
00007588ecdd77df  call rax
00007588ecdd77e1  movaps xmm12, [rsp]
00007588ecdd77e6  add rsp, 0x40
00007588ecdd77ea  vmovaps xmm0, [rsp]
00007588ecdd77ef  vmovaps xmm1, [rsp+0x10]
00007588ecdd77f5  vmovaps xmm2, [rsp+0x20]
00007588ecdd77fb  vmovaps xmm3, [rsp+0x30]
00007588ecdd7801  vmovaps xmm4, [rsp+0x40]
00007588ecdd7807  vmovaps xmm5, [rsp+0x50]
00007588ecdd780d  vmovaps xmm6, [rsp+0x60]
00007588ecdd7813  vmovaps xmm7, [rsp+0x70]
00007588ecdd7819  vmovaps xmm8, [rsp+0x80]
00007588ecdd7822  vmovaps xmm9, [rsp+0x90]
00007588ecdd782b  vmovaps xmm10, [rsp+0xA0]
00007588ecdd7834  vmovaps xmm11, [rsp+0xB0]
00007588ecdd783d  vmovaps xmm13, [rsp+0xC0]
00007588ecdd7846  vmovaps xmm14, [rsp+0xD0]
00007588ecdd784f  vmovaps xmm15, [rsp+0xE0]
00007588ecdd7858  add rsp, 0xF0
00007588ecdd785f  pop r11
00007588ecdd7861  pop r10
00007588ecdd7863  pop r9
00007588ecdd7865  pop r8
00007588ecdd7867  pop rsi
00007588ecdd7868  pop rdi
00007588ecdd7869  pop rdx
00007588ecdd786a  pop rcx
00007588ecdd786b  pop rax
00007588ecdd786c  add rsp, 0x08
00007588ecdd7870  jmp 0x00007588ECDD6728
00007588ecdd7875  sub rsp, 0x08
00007588ecdd7879  push rax
00007588ecdd787a  push rcx
00007588ecdd787b  push rdx
00007588ecdd787c  push rdi
00007588ecdd787d  push rsi
00007588ecdd787e  push r8
00007588ecdd7880  push r9
00007588ecdd7882  push r10
00007588ecdd7884  push r11
00007588ecdd7886  sub rsp, 0xF0
00007588ecdd788d  vmovaps [rsp], xmm0
00007588ecdd7892  vmovaps [rsp+0x10], xmm1
00007588ecdd7898  vmovaps [rsp+0x20], xmm2
00007588ecdd789e  vmovaps [rsp+0x30], xmm3
00007588ecdd78a4  vmovaps [rsp+0x40], xmm4
00007588ecdd78aa  vmovaps [rsp+0x50], xmm5
00007588ecdd78b0  vmovaps [rsp+0x60], xmm6
00007588ecdd78b6  vmovaps [rsp+0x70], xmm7
00007588ecdd78bc  vmovaps [rsp+0x80], xmm8
00007588ecdd78c5  vmovaps [rsp+0x90], xmm10
00007588ecdd78ce  vmovaps [rsp+0xA0], xmm11
00007588ecdd78d7  vmovaps [rsp+0xB0], xmm12
00007588ecdd78e0  vmovaps [rsp+0xC0], xmm13
00007588ecdd78e9  vmovaps [rsp+0xD0], xmm14
00007588ecdd78f2  vmovaps [rsp+0xE0], xmm15
00007588ecdd78fb  sub rsp, 0x40
00007588ecdd78ff  lea rdi, [rsp]
00007588ecdd7903  lea rsi, [rsp+0x10]
00007588ecdd7908  lea rdx, [rsp+0x20]
00007588ecdd790d  lea rcx, [rsp+0x30]
00007588ecdd7912  mov r8d, 0x00
00007588ecdd7918  lea r9, [r15+0x3A8]
00007588ecdd791f  movaps [rdi], xmm9
00007588ecdd7923  movaps [rsi], xmm13
00007588ecdd7927  movaps [rdx], xmm14
00007588ecdd792b  movaps [rcx], xmm6
00007588ecdd792e  mov rax, 0x6516BF3BBA50
00007588ecdd7938  call rax
00007588ecdd793a  movaps xmm9, [rsp]
00007588ecdd793f  add rsp, 0x40
00007588ecdd7943  vmovaps xmm0, [rsp]
00007588ecdd7948  vmovaps xmm1, [rsp+0x10]
00007588ecdd794e  vmovaps xmm2, [rsp+0x20]
00007588ecdd7954  vmovaps xmm3, [rsp+0x30]
00007588ecdd795a  vmovaps xmm4, [rsp+0x40]
00007588ecdd7960  vmovaps xmm5, [rsp+0x50]
00007588ecdd7966  vmovaps xmm6, [rsp+0x60]
00007588ecdd796c  vmovaps xmm7, [rsp+0x70]
00007588ecdd7972  vmovaps xmm8, [rsp+0x80]
00007588ecdd797b  vmovaps xmm10, [rsp+0x90]
00007588ecdd7984  vmovaps xmm11, [rsp+0xA0]
00007588ecdd798d  vmovaps xmm12, [rsp+0xB0]
00007588ecdd7996  vmovaps xmm13, [rsp+0xC0]
00007588ecdd799f  vmovaps xmm14, [rsp+0xD0]
00007588ecdd79a8  vmovaps xmm15, [rsp+0xE0]
00007588ecdd79b1  add rsp, 0xF0
00007588ecdd79b8  pop r11
00007588ecdd79ba  pop r10
00007588ecdd79bc  pop r9
00007588ecdd79be  pop r8
00007588ecdd79c0  pop rsi
00007588ecdd79c1  pop rdi
00007588ecdd79c2  pop rdx
00007588ecdd79c3  pop rcx
00007588ecdd79c4  pop rax
00007588ecdd79c5  add rsp, 0x08
00007588ecdd79c9  jmp 0x00007588ECDD67D2
00007588ecdd79ce  sub rsp, 0x08
00007588ecdd79d2  push rax
00007588ecdd79d3  push rcx
00007588ecdd79d4  push rdx
00007588ecdd79d5  push rdi
00007588ecdd79d6  push rsi
00007588ecdd79d7  push r8
00007588ecdd79d9  push r9
00007588ecdd79db  push r10
00007588ecdd79dd  push r11
00007588ecdd79df  sub rsp, 0xF0
00007588ecdd79e6  vmovaps [rsp], xmm0
00007588ecdd79eb  vmovaps [rsp+0x10], xmm1
00007588ecdd79f1  vmovaps [rsp+0x20], xmm2
00007588ecdd79f7  vmovaps [rsp+0x30], xmm4
00007588ecdd79fd  vmovaps [rsp+0x40], xmm5
00007588ecdd7a03  vmovaps [rsp+0x50], xmm6
00007588ecdd7a09  vmovaps [rsp+0x60], xmm7
00007588ecdd7a0f  vmovaps [rsp+0x70], xmm8
00007588ecdd7a15  vmovaps [rsp+0x80], xmm9
00007588ecdd7a1e  vmovaps [rsp+0x90], xmm10
00007588ecdd7a27  vmovaps [rsp+0xA0], xmm11
00007588ecdd7a30  vmovaps [rsp+0xB0], xmm12
00007588ecdd7a39  vmovaps [rsp+0xC0], xmm13
00007588ecdd7a42  vmovaps [rsp+0xD0], xmm14
00007588ecdd7a4b  vmovaps [rsp+0xE0], xmm15
00007588ecdd7a54  sub rsp, 0x40
00007588ecdd7a58  lea rdi, [rsp]
00007588ecdd7a5c  lea rsi, [rsp+0x10]
00007588ecdd7a61  lea rdx, [rsp+0x20]
00007588ecdd7a66  lea rcx, [rsp+0x30]
00007588ecdd7a6b  mov r8d, 0x00
00007588ecdd7a71  lea r9, [r15+0x3A8]
00007588ecdd7a78  movaps [rdi], xmm3
00007588ecdd7a7b  movaps [rsi], xmm13
00007588ecdd7a7f  movaps [rdx], xmm6
00007588ecdd7a82  movaps [rcx], xmm14
00007588ecdd7a86  mov rax, 0x6516BF3BBA50
00007588ecdd7a90  call rax
00007588ecdd7a92  movaps xmm3, [rsp]
00007588ecdd7a96  add rsp, 0x40
00007588ecdd7a9a  vmovaps xmm0, [rsp]
00007588ecdd7a9f  vmovaps xmm1, [rsp+0x10]
00007588ecdd7aa5  vmovaps xmm2, [rsp+0x20]
00007588ecdd7aab  vmovaps xmm4, [rsp+0x30]
00007588ecdd7ab1  vmovaps xmm5, [rsp+0x40]
00007588ecdd7ab7  vmovaps xmm6, [rsp+0x50]
00007588ecdd7abd  vmovaps xmm7, [rsp+0x60]
00007588ecdd7ac3  vmovaps xmm8, [rsp+0x70]
00007588ecdd7ac9  vmovaps xmm9, [rsp+0x80]
00007588ecdd7ad2  vmovaps xmm10, [rsp+0x90]
00007588ecdd7adb  vmovaps xmm11, [rsp+0xA0]
00007588ecdd7ae4  vmovaps xmm12, [rsp+0xB0]
00007588ecdd7aed  vmovaps xmm13, [rsp+0xC0]
00007588ecdd7af6  vmovaps xmm14, [rsp+0xD0]
00007588ecdd7aff  vmovaps xmm15, [rsp+0xE0]
00007588ecdd7b08  add rsp, 0xF0
00007588ecdd7b0f  pop r11
00007588ecdd7b11  pop r10
00007588ecdd7b13  pop r9
00007588ecdd7b15  pop r8
00007588ecdd7b17  pop rsi
00007588ecdd7b18  pop rdi
00007588ecdd7b19  pop rdx
00007588ecdd7b1a  pop rcx
00007588ecdd7b1b  pop rax
00007588ecdd7b1c  add rsp, 0x08
00007588ecdd7b20  jmp 0x00007588ECDD680F
00007588ecdd7b25  sub rsp, 0x08
00007588ecdd7b29  push rax
00007588ecdd7b2a  push rcx
00007588ecdd7b2b  push rdx
00007588ecdd7b2c  push rdi
00007588ecdd7b2d  push rsi
00007588ecdd7b2e  push r8
00007588ecdd7b30  push r9
00007588ecdd7b32  push r10
00007588ecdd7b34  push r11
00007588ecdd7b36  sub rsp, 0xF0
00007588ecdd7b3d  vmovaps [rsp], xmm0
00007588ecdd7b42  vmovaps [rsp+0x10], xmm1
00007588ecdd7b48  vmovaps [rsp+0x20], xmm2
00007588ecdd7b4e  vmovaps [rsp+0x30], xmm3
00007588ecdd7b54  vmovaps [rsp+0x40], xmm4
00007588ecdd7b5a  vmovaps [rsp+0x50], xmm5
00007588ecdd7b60  vmovaps [rsp+0x60], xmm7
00007588ecdd7b66  vmovaps [rsp+0x70], xmm8
00007588ecdd7b6c  vmovaps [rsp+0x80], xmm9
00007588ecdd7b75  vmovaps [rsp+0x90], xmm10
00007588ecdd7b7e  vmovaps [rsp+0xA0], xmm11
00007588ecdd7b87  vmovaps [rsp+0xB0], xmm12
00007588ecdd7b90  vmovaps [rsp+0xC0], xmm13
00007588ecdd7b99  vmovaps [rsp+0xD0], xmm14
00007588ecdd7ba2  vmovaps [rsp+0xE0], xmm15
00007588ecdd7bab  sub rsp, 0x40
00007588ecdd7baf  lea rdi, [rsp]
00007588ecdd7bb3  lea rsi, [rsp+0x10]
00007588ecdd7bb8  lea rdx, [rsp+0x20]
00007588ecdd7bbd  lea rcx, [rsp+0x30]
00007588ecdd7bc2  mov r8d, 0x00
00007588ecdd7bc8  lea r9, [r15+0x3A8]
00007588ecdd7bcf  movaps [rdi], xmm6
00007588ecdd7bd2  movaps [rsi], xmm2
00007588ecdd7bd5  movaps [rdx], xmm14
00007588ecdd7bd9  movaps [rcx], xmm1
00007588ecdd7bdc  mov rax, 0x6516BF3BBA50
00007588ecdd7be6  call rax
00007588ecdd7be8  movaps xmm6, [rsp]
00007588ecdd7bec  add rsp, 0x40
00007588ecdd7bf0  vmovaps xmm0, [rsp]
00007588ecdd7bf5  vmovaps xmm1, [rsp+0x10]
00007588ecdd7bfb  vmovaps xmm2, [rsp+0x20]
00007588ecdd7c01  vmovaps xmm3, [rsp+0x30]
00007588ecdd7c07  vmovaps xmm4, [rsp+0x40]
00007588ecdd7c0d  vmovaps xmm5, [rsp+0x50]
00007588ecdd7c13  vmovaps xmm7, [rsp+0x60]
00007588ecdd7c19  vmovaps xmm8, [rsp+0x70]
00007588ecdd7c1f  vmovaps xmm9, [rsp+0x80]
00007588ecdd7c28  vmovaps xmm10, [rsp+0x90]
00007588ecdd7c31  vmovaps xmm11, [rsp+0xA0]
00007588ecdd7c3a  vmovaps xmm12, [rsp+0xB0]
00007588ecdd7c43  vmovaps xmm13, [rsp+0xC0]
00007588ecdd7c4c  vmovaps xmm14, [rsp+0xD0]
00007588ecdd7c55  vmovaps xmm15, [rsp+0xE0]
00007588ecdd7c5e  add rsp, 0xF0
00007588ecdd7c65  pop r11
00007588ecdd7c67  pop r10
00007588ecdd7c69  pop r9
00007588ecdd7c6b  pop r8
00007588ecdd7c6d  pop rsi
00007588ecdd7c6e  pop rdi
00007588ecdd7c6f  pop rdx
00007588ecdd7c70  pop rcx
00007588ecdd7c71  pop rax
00007588ecdd7c72  add rsp, 0x08
00007588ecdd7c76  jmp 0x00007588ECDD683C
00007588ecdd7c7b  sub rsp, 0x08
00007588ecdd7c7f  push rax
00007588ecdd7c80  push rcx
00007588ecdd7c81  push rdx
00007588ecdd7c82  push rdi
00007588ecdd7c83  push rsi
00007588ecdd7c84  push r8
00007588ecdd7c86  push r9
00007588ecdd7c88  push r10
00007588ecdd7c8a  push r11
00007588ecdd7c8c  sub rsp, 0xF0
00007588ecdd7c93  vmovaps [rsp], xmm0
00007588ecdd7c98  vmovaps [rsp+0x10], xmm1
00007588ecdd7c9e  vmovaps [rsp+0x20], xmm2
00007588ecdd7ca4  vmovaps [rsp+0x30], xmm3
00007588ecdd7caa  vmovaps [rsp+0x40], xmm4
00007588ecdd7cb0  vmovaps [rsp+0x50], xmm5
00007588ecdd7cb6  vmovaps [rsp+0x60], xmm6
00007588ecdd7cbc  vmovaps [rsp+0x70], xmm7
00007588ecdd7cc2  vmovaps [rsp+0x80], xmm8
00007588ecdd7ccb  vmovaps [rsp+0x90], xmm9
00007588ecdd7cd4  vmovaps [rsp+0xA0], xmm10
00007588ecdd7cdd  vmovaps [rsp+0xB0], xmm11
00007588ecdd7ce6  vmovaps [rsp+0xC0], xmm12
00007588ecdd7cef  vmovaps [rsp+0xD0], xmm14
00007588ecdd7cf8  vmovaps [rsp+0xE0], xmm15
00007588ecdd7d01  sub rsp, 0x40
00007588ecdd7d05  lea rdi, [rsp]
00007588ecdd7d09  lea rsi, [rsp+0x10]
00007588ecdd7d0e  lea rdx, [rsp+0x20]
00007588ecdd7d13  lea rcx, [rsp+0x30]
00007588ecdd7d18  mov r8d, 0x00
00007588ecdd7d1e  lea r9, [r15+0x3A8]
00007588ecdd7d25  movaps [rdi], xmm13
00007588ecdd7d29  movaps [rsi], xmm12
00007588ecdd7d2d  movaps [rdx], xmm14
00007588ecdd7d31  movaps [rcx], xmm1
00007588ecdd7d34  mov rax, 0x6516BF3BBA50
00007588ecdd7d3e  call rax
00007588ecdd7d40  movaps xmm13, [rsp]
00007588ecdd7d45  add rsp, 0x40
00007588ecdd7d49  vmovaps xmm0, [rsp]
00007588ecdd7d4e  vmovaps xmm1, [rsp+0x10]
00007588ecdd7d54  vmovaps xmm2, [rsp+0x20]
00007588ecdd7d5a  vmovaps xmm3, [rsp+0x30]
00007588ecdd7d60  vmovaps xmm4, [rsp+0x40]
00007588ecdd7d66  vmovaps xmm5, [rsp+0x50]
00007588ecdd7d6c  vmovaps xmm6, [rsp+0x60]
00007588ecdd7d72  vmovaps xmm7, [rsp+0x70]
00007588ecdd7d78  vmovaps xmm8, [rsp+0x80]
00007588ecdd7d81  vmovaps xmm9, [rsp+0x90]
00007588ecdd7d8a  vmovaps xmm10, [rsp+0xA0]
00007588ecdd7d93  vmovaps xmm11, [rsp+0xB0]
00007588ecdd7d9c  vmovaps xmm12, [rsp+0xC0]
00007588ecdd7da5  vmovaps xmm14, [rsp+0xD0]
00007588ecdd7dae  vmovaps xmm15, [rsp+0xE0]
00007588ecdd7db7  add rsp, 0xF0
00007588ecdd7dbe  pop r11
00007588ecdd7dc0  pop r10
00007588ecdd7dc2  pop r9
00007588ecdd7dc4  pop r8
00007588ecdd7dc6  pop rsi
00007588ecdd7dc7  pop rdi
00007588ecdd7dc8  pop rdx
00007588ecdd7dc9  pop rcx
00007588ecdd7dca  pop rax
00007588ecdd7dcb  add rsp, 0x08
00007588ecdd7dcf  jmp 0x00007588ECDD686E
00007588ecdd7dd4  sub rsp, 0x08
00007588ecdd7dd8  push rax
00007588ecdd7dd9  push rcx
00007588ecdd7dda  push rdx
00007588ecdd7ddb  push rdi
00007588ecdd7ddc  push rsi
00007588ecdd7ddd  push r8
00007588ecdd7ddf  push r9
00007588ecdd7de1  push r10
00007588ecdd7de3  push r11
00007588ecdd7de5  sub rsp, 0xF0
00007588ecdd7dec  vmovaps [rsp], xmm0
00007588ecdd7df1  vmovaps [rsp+0x10], xmm1
00007588ecdd7df7  vmovaps [rsp+0x20], xmm2
00007588ecdd7dfd  vmovaps [rsp+0x30], xmm3
00007588ecdd7e03  vmovaps [rsp+0x40], xmm4
00007588ecdd7e09  vmovaps [rsp+0x50], xmm5
00007588ecdd7e0f  vmovaps [rsp+0x60], xmm6
00007588ecdd7e15  vmovaps [rsp+0x70], xmm7
00007588ecdd7e1b  vmovaps [rsp+0x80], xmm8
00007588ecdd7e24  vmovaps [rsp+0x90], xmm9
00007588ecdd7e2d  vmovaps [rsp+0xA0], xmm10
00007588ecdd7e36  vmovaps [rsp+0xB0], xmm11
00007588ecdd7e3f  vmovaps [rsp+0xC0], xmm13
00007588ecdd7e48  vmovaps [rsp+0xD0], xmm14
00007588ecdd7e51  vmovaps [rsp+0xE0], xmm15
00007588ecdd7e5a  sub rsp, 0x40
00007588ecdd7e5e  lea rdi, [rsp]
00007588ecdd7e62  lea rsi, [rsp+0x10]
00007588ecdd7e67  lea rdx, [rsp+0x20]
00007588ecdd7e6c  lea rcx, [rsp+0x30]
00007588ecdd7e71  mov r8d, 0x00
00007588ecdd7e77  lea r9, [r15+0x3A8]
00007588ecdd7e7e  movaps [rdi], xmm12
00007588ecdd7e82  movaps [rsi], xmm3
00007588ecdd7e85  movaps [rdx], xmm14
00007588ecdd7e89  movaps [rcx], xmm5
00007588ecdd7e8c  mov rax, 0x6516BF3BBA50
00007588ecdd7e96  call rax
00007588ecdd7e98  movaps xmm12, [rsp]
00007588ecdd7e9d  add rsp, 0x40
00007588ecdd7ea1  vmovaps xmm0, [rsp]
00007588ecdd7ea6  vmovaps xmm1, [rsp+0x10]
00007588ecdd7eac  vmovaps xmm2, [rsp+0x20]
00007588ecdd7eb2  vmovaps xmm3, [rsp+0x30]
00007588ecdd7eb8  vmovaps xmm4, [rsp+0x40]
00007588ecdd7ebe  vmovaps xmm5, [rsp+0x50]
00007588ecdd7ec4  vmovaps xmm6, [rsp+0x60]
00007588ecdd7eca  vmovaps xmm7, [rsp+0x70]
00007588ecdd7ed0  vmovaps xmm8, [rsp+0x80]
00007588ecdd7ed9  vmovaps xmm9, [rsp+0x90]
00007588ecdd7ee2  vmovaps xmm10, [rsp+0xA0]
00007588ecdd7eeb  vmovaps xmm11, [rsp+0xB0]
00007588ecdd7ef4  vmovaps xmm13, [rsp+0xC0]
00007588ecdd7efd  vmovaps xmm14, [rsp+0xD0]
00007588ecdd7f06  vmovaps xmm15, [rsp+0xE0]
00007588ecdd7f0f  add rsp, 0xF0
00007588ecdd7f16  pop r11
00007588ecdd7f18  pop r10
00007588ecdd7f1a  pop r9
00007588ecdd7f1c  pop r8
00007588ecdd7f1e  pop rsi
00007588ecdd7f1f  pop rdi
00007588ecdd7f20  pop rdx
00007588ecdd7f21  pop rcx
00007588ecdd7f22  pop rax
00007588ecdd7f23  add rsp, 0x08
00007588ecdd7f27  jmp 0x00007588ECDD68CB
00007588ecdd7f2c  sub rsp, 0x08
00007588ecdd7f30  push rax
00007588ecdd7f31  push rcx
00007588ecdd7f32  push rdx
00007588ecdd7f33  push rdi
00007588ecdd7f34  push rsi
00007588ecdd7f35  push r8
00007588ecdd7f37  push r9
00007588ecdd7f39  push r10
00007588ecdd7f3b  push r11
00007588ecdd7f3d  sub rsp, 0xF0
00007588ecdd7f44  vmovaps [rsp], xmm0
00007588ecdd7f49  vmovaps [rsp+0x10], xmm1
00007588ecdd7f4f  vmovaps [rsp+0x20], xmm2
00007588ecdd7f55  vmovaps [rsp+0x30], xmm3
00007588ecdd7f5b  vmovaps [rsp+0x40], xmm4
00007588ecdd7f61  vmovaps [rsp+0x50], xmm5
00007588ecdd7f67  vmovaps [rsp+0x60], xmm6
00007588ecdd7f6d  vmovaps [rsp+0x70], xmm7
00007588ecdd7f73  vmovaps [rsp+0x80], xmm8
00007588ecdd7f7c  vmovaps [rsp+0x90], xmm9
00007588ecdd7f85  vmovaps [rsp+0xA0], xmm11
00007588ecdd7f8e  vmovaps [rsp+0xB0], xmm12
00007588ecdd7f97  vmovaps [rsp+0xC0], xmm13
00007588ecdd7fa0  vmovaps [rsp+0xD0], xmm14
00007588ecdd7fa9  vmovaps [rsp+0xE0], xmm15
00007588ecdd7fb2  sub rsp, 0x40
00007588ecdd7fb6  lea rdi, [rsp]
00007588ecdd7fba  lea rsi, [rsp+0x10]
00007588ecdd7fbf  lea rdx, [rsp+0x20]
00007588ecdd7fc4  lea rcx, [rsp+0x30]
00007588ecdd7fc9  mov r8d, 0x00
00007588ecdd7fcf  lea r9, [r15+0x3A8]
00007588ecdd7fd6  movaps [rdi], xmm10
00007588ecdd7fda  movaps [rsi], xmm9
00007588ecdd7fde  movaps [rdx], xmm7
00007588ecdd7fe1  movaps [rcx], xmm14
00007588ecdd7fe5  mov rax, 0x6516BF3BBA50
00007588ecdd7fef  call rax
00007588ecdd7ff1  movaps xmm10, [rsp]
00007588ecdd7ff6  add rsp, 0x40
00007588ecdd7ffa  vmovaps xmm0, [rsp]
00007588ecdd7fff  vmovaps xmm1, [rsp+0x10]
00007588ecdd8005  vmovaps xmm2, [rsp+0x20]
00007588ecdd800b  vmovaps xmm3, [rsp+0x30]
00007588ecdd8011  vmovaps xmm4, [rsp+0x40]
00007588ecdd8017  vmovaps xmm5, [rsp+0x50]
00007588ecdd801d  vmovaps xmm6, [rsp+0x60]
00007588ecdd8023  vmovaps xmm7, [rsp+0x70]
00007588ecdd8029  vmovaps xmm8, [rsp+0x80]
00007588ecdd8032  vmovaps xmm9, [rsp+0x90]
00007588ecdd803b  vmovaps xmm11, [rsp+0xA0]
00007588ecdd8044  vmovaps xmm12, [rsp+0xB0]
00007588ecdd804d  vmovaps xmm13, [rsp+0xC0]
00007588ecdd8056  vmovaps xmm14, [rsp+0xD0]
00007588ecdd805f  vmovaps xmm15, [rsp+0xE0]
00007588ecdd8068  add rsp, 0xF0
00007588ecdd806f  pop r11
00007588ecdd8071  pop r10
00007588ecdd8073  pop r9
00007588ecdd8075  pop r8
00007588ecdd8077  pop rsi
00007588ecdd8078  pop rdi
00007588ecdd8079  pop rdx
00007588ecdd807a  pop rcx
00007588ecdd807b  pop rax
00007588ecdd807c  add rsp, 0x08
00007588ecdd8080  jmp 0x00007588ECDD68F1
00007588ecdd8085  call 0x00007588ECCE45A0
00007588ecdd808a  jmp 0x00007588ECDD68FE
00007588ecdd808f  sub rsp, 0x08
00007588ecdd8093  push rax
00007588ecdd8094  push rcx
00007588ecdd8095  push rdx
00007588ecdd8096  push rdi
00007588ecdd8097  push rsi
00007588ecdd8098  push r8
00007588ecdd809a  push r9
00007588ecdd809c  push r10
00007588ecdd809e  push r11
00007588ecdd80a0  sub rsp, 0xF0
00007588ecdd80a7  vmovaps [rsp], xmm0
00007588ecdd80ac  vmovaps [rsp+0x10], xmm1
00007588ecdd80b2  vmovaps [rsp+0x20], xmm2
00007588ecdd80b8  vmovaps [rsp+0x30], xmm3
00007588ecdd80be  vmovaps [rsp+0x40], xmm4
00007588ecdd80c4  vmovaps [rsp+0x50], xmm6
00007588ecdd80ca  vmovaps [rsp+0x60], xmm7
00007588ecdd80d0  vmovaps [rsp+0x70], xmm8
00007588ecdd80d6  vmovaps [rsp+0x80], xmm9
00007588ecdd80df  vmovaps [rsp+0x90], xmm10
00007588ecdd80e8  vmovaps [rsp+0xA0], xmm11
00007588ecdd80f1  vmovaps [rsp+0xB0], xmm12
00007588ecdd80fa  vmovaps [rsp+0xC0], xmm13
00007588ecdd8103  vmovaps [rsp+0xD0], xmm14
00007588ecdd810c  vmovaps [rsp+0xE0], xmm15
00007588ecdd8115  sub rsp, 0x40
00007588ecdd8119  lea rdi, [rsp]
00007588ecdd811d  lea rsi, [rsp+0x10]
00007588ecdd8122  lea rdx, [rsp+0x20]
00007588ecdd8127  lea rcx, [rsp+0x30]
00007588ecdd812c  mov r8d, 0x00
00007588ecdd8132  lea r9, [r15+0x3A8]
00007588ecdd8139  movaps [rdi], xmm5
00007588ecdd813c  movaps [rsi], xmm6
00007588ecdd813f  movaps [rdx], xmm7
00007588ecdd8142  movaps [rcx], xmm9
00007588ecdd8146  mov rax, 0x6516BF3BBA50
00007588ecdd8150  call rax
00007588ecdd8152  movaps xmm5, [rsp]
00007588ecdd8156  add rsp, 0x40
00007588ecdd815a  vmovaps xmm0, [rsp]
00007588ecdd815f  vmovaps xmm1, [rsp+0x10]
00007588ecdd8165  vmovaps xmm2, [rsp+0x20]
00007588ecdd816b  vmovaps xmm3, [rsp+0x30]
00007588ecdd8171  vmovaps xmm4, [rsp+0x40]
00007588ecdd8177  vmovaps xmm6, [rsp+0x50]
00007588ecdd817d  vmovaps xmm7, [rsp+0x60]
00007588ecdd8183  vmovaps xmm8, [rsp+0x70]
00007588ecdd8189  vmovaps xmm9, [rsp+0x80]
00007588ecdd8192  vmovaps xmm10, [rsp+0x90]
00007588ecdd819b  vmovaps xmm11, [rsp+0xA0]
00007588ecdd81a4  vmovaps xmm12, [rsp+0xB0]
00007588ecdd81ad  vmovaps xmm13, [rsp+0xC0]
00007588ecdd81b6  vmovaps xmm14, [rsp+0xD0]
00007588ecdd81bf  vmovaps xmm15, [rsp+0xE0]
00007588ecdd81c8  add rsp, 0xF0
00007588ecdd81cf  pop r11
00007588ecdd81d1  pop r10
00007588ecdd81d3  pop r9
00007588ecdd81d5  pop r8
00007588ecdd81d7  pop rsi
00007588ecdd81d8  pop rdi
00007588ecdd81d9  pop rdx
00007588ecdd81da  pop rcx
00007588ecdd81db  pop rax
00007588ecdd81dc  add rsp, 0x08
00007588ecdd81e0  jmp 0x00007588ECDD6930
00007588ecdd81e5  sub rsp, 0x08
00007588ecdd81e9  push rax
00007588ecdd81ea  push rcx
00007588ecdd81eb  push rdx
00007588ecdd81ec  push rdi
00007588ecdd81ed  push rsi
00007588ecdd81ee  push r8
00007588ecdd81f0  push r9
00007588ecdd81f2  push r10
00007588ecdd81f4  push r11
00007588ecdd81f6  sub rsp, 0xF0
00007588ecdd81fd  vmovaps [rsp], xmm0
00007588ecdd8202  vmovaps [rsp+0x10], xmm1
00007588ecdd8208  vmovaps [rsp+0x20], xmm2
00007588ecdd820e  vmovaps [rsp+0x30], xmm3
00007588ecdd8214  vmovaps [rsp+0x40], xmm4
00007588ecdd821a  vmovaps [rsp+0x50], xmm5
00007588ecdd8220  vmovaps [rsp+0x60], xmm6
00007588ecdd8226  vmovaps [rsp+0x70], xmm8
00007588ecdd822c  vmovaps [rsp+0x80], xmm9
00007588ecdd8235  vmovaps [rsp+0x90], xmm10
00007588ecdd823e  vmovaps [rsp+0xA0], xmm11
00007588ecdd8247  vmovaps [rsp+0xB0], xmm12
00007588ecdd8250  vmovaps [rsp+0xC0], xmm13
00007588ecdd8259  vmovaps [rsp+0xD0], xmm14
00007588ecdd8262  vmovaps [rsp+0xE0], xmm15
00007588ecdd826b  sub rsp, 0x40
00007588ecdd826f  lea rdi, [rsp]
00007588ecdd8273  lea rsi, [rsp+0x10]
00007588ecdd8278  lea rdx, [rsp+0x20]
00007588ecdd827d  lea rcx, [rsp+0x30]
00007588ecdd8282  mov r8d, 0x00
00007588ecdd8288  lea r9, [r15+0x3A8]
00007588ecdd828f  movaps [rdi], xmm7
00007588ecdd8292  movaps [rsi], xmm13
00007588ecdd8296  movaps [rdx], xmm1
00007588ecdd8299  movaps [rcx], xmm9
00007588ecdd829d  mov rax, 0x6516BF3BBA50
00007588ecdd82a7  call rax
00007588ecdd82a9  movaps xmm7, [rsp]
00007588ecdd82ad  add rsp, 0x40
00007588ecdd82b1  vmovaps xmm0, [rsp]
00007588ecdd82b6  vmovaps xmm1, [rsp+0x10]
00007588ecdd82bc  vmovaps xmm2, [rsp+0x20]
00007588ecdd82c2  vmovaps xmm3, [rsp+0x30]
00007588ecdd82c8  vmovaps xmm4, [rsp+0x40]
00007588ecdd82ce  vmovaps xmm5, [rsp+0x50]
00007588ecdd82d4  vmovaps xmm6, [rsp+0x60]
00007588ecdd82da  vmovaps xmm8, [rsp+0x70]
00007588ecdd82e0  vmovaps xmm9, [rsp+0x80]
00007588ecdd82e9  vmovaps xmm10, [rsp+0x90]
00007588ecdd82f2  vmovaps xmm11, [rsp+0xA0]
00007588ecdd82fb  vmovaps xmm12, [rsp+0xB0]
00007588ecdd8304  vmovaps xmm13, [rsp+0xC0]
00007588ecdd830d  vmovaps xmm14, [rsp+0xD0]
00007588ecdd8316  vmovaps xmm15, [rsp+0xE0]
00007588ecdd831f  add rsp, 0xF0
00007588ecdd8326  pop r11
00007588ecdd8328  pop r10
00007588ecdd832a  pop r9
00007588ecdd832c  pop r8
00007588ecdd832e  pop rsi
00007588ecdd832f  pop rdi
00007588ecdd8330  pop rdx
00007588ecdd8331  pop rcx
00007588ecdd8332  pop rax
00007588ecdd8333  add rsp, 0x08
00007588ecdd8337  jmp 0x00007588ECDD6955
00007588ecdd833c  call 0x00007588ECCE3320
00007588ecdd8341  jmp 0x00007588ECDD6978
00007588ecdd8346  call 0x00007588ECCDE950
00007588ecdd834b  jmp 0x00007588ECDD6982
00007588ecdd8350  sub rsp, 0x08
00007588ecdd8354  push rax
00007588ecdd8355  push rcx
00007588ecdd8356  push rdx
00007588ecdd8357  push rdi
00007588ecdd8358  push rsi
00007588ecdd8359  push r8
00007588ecdd835b  push r9
00007588ecdd835d  push r10
00007588ecdd835f  push r11
00007588ecdd8361  sub rsp, 0xF0
00007588ecdd8368  vmovaps [rsp], xmm0
00007588ecdd836d  vmovaps [rsp+0x10], xmm1
00007588ecdd8373  vmovaps [rsp+0x20], xmm3
00007588ecdd8379  vmovaps [rsp+0x30], xmm4
00007588ecdd837f  vmovaps [rsp+0x40], xmm5
00007588ecdd8385  vmovaps [rsp+0x50], xmm6
00007588ecdd838b  vmovaps [rsp+0x60], xmm7
00007588ecdd8391  vmovaps [rsp+0x70], xmm8
00007588ecdd8397  vmovaps [rsp+0x80], xmm9
00007588ecdd83a0  vmovaps [rsp+0x90], xmm10
00007588ecdd83a9  vmovaps [rsp+0xA0], xmm11
00007588ecdd83b2  vmovaps [rsp+0xB0], xmm12
00007588ecdd83bb  vmovaps [rsp+0xC0], xmm13
00007588ecdd83c4  vmovaps [rsp+0xD0], xmm14
00007588ecdd83cd  vmovaps [rsp+0xE0], xmm15
00007588ecdd83d6  sub rsp, 0x40
00007588ecdd83da  lea rdi, [rsp]
00007588ecdd83de  lea rsi, [rsp+0x10]
00007588ecdd83e3  lea rdx, [rsp+0x20]
00007588ecdd83e8  lea rcx, [rsp+0x30]
00007588ecdd83ed  mov r8d, 0x00
00007588ecdd83f3  lea r9, [r15+0x3A8]
00007588ecdd83fa  movaps [rdi], xmm2
00007588ecdd83fd  movaps [rsi], xmm12
00007588ecdd8401  movaps [rdx], xmm6
00007588ecdd8404  movaps [rcx], xmm3
00007588ecdd8407  mov rax, 0x6516BF3BBA50
00007588ecdd8411  call rax
00007588ecdd8413  movaps xmm2, [rsp]
00007588ecdd8417  add rsp, 0x40
00007588ecdd841b  vmovaps xmm0, [rsp]
00007588ecdd8420  vmovaps xmm1, [rsp+0x10]
00007588ecdd8426  vmovaps xmm3, [rsp+0x20]
00007588ecdd842c  vmovaps xmm4, [rsp+0x30]
00007588ecdd8432  vmovaps xmm5, [rsp+0x40]
00007588ecdd8438  vmovaps xmm6, [rsp+0x50]
00007588ecdd843e  vmovaps xmm7, [rsp+0x60]
00007588ecdd8444  vmovaps xmm8, [rsp+0x70]
00007588ecdd844a  vmovaps xmm9, [rsp+0x80]
00007588ecdd8453  vmovaps xmm10, [rsp+0x90]
00007588ecdd845c  vmovaps xmm11, [rsp+0xA0]
00007588ecdd8465  vmovaps xmm12, [rsp+0xB0]
00007588ecdd846e  vmovaps xmm13, [rsp+0xC0]
00007588ecdd8477  vmovaps xmm14, [rsp+0xD0]
00007588ecdd8480  vmovaps xmm15, [rsp+0xE0]
00007588ecdd8489  add rsp, 0xF0
00007588ecdd8490  pop r11
00007588ecdd8492  pop r10
00007588ecdd8494  pop r9
00007588ecdd8496  pop r8
00007588ecdd8498  pop rsi
00007588ecdd8499  pop rdi
00007588ecdd849a  pop rdx
00007588ecdd849b  pop rcx
00007588ecdd849c  pop rax
00007588ecdd849d  add rsp, 0x08
00007588ecdd84a1  jmp 0x00007588ECDD69C8
00007588ecdd84a6  sub rsp, 0x08
00007588ecdd84aa  push rax
00007588ecdd84ab  push rcx
00007588ecdd84ac  push rdx
00007588ecdd84ad  push rdi
00007588ecdd84ae  push rsi
00007588ecdd84af  push r8
00007588ecdd84b1  push r9
00007588ecdd84b3  push r10
00007588ecdd84b5  push r11
00007588ecdd84b7  sub rsp, 0xF0
00007588ecdd84be  vmovaps [rsp], xmm0
00007588ecdd84c3  vmovaps [rsp+0x10], xmm1
00007588ecdd84c9  vmovaps [rsp+0x20], xmm2
00007588ecdd84cf  vmovaps [rsp+0x30], xmm3
00007588ecdd84d5  vmovaps [rsp+0x40], xmm4
00007588ecdd84db  vmovaps [rsp+0x50], xmm5
00007588ecdd84e1  vmovaps [rsp+0x60], xmm7
00007588ecdd84e7  vmovaps [rsp+0x70], xmm8
00007588ecdd84ed  vmovaps [rsp+0x80], xmm9
00007588ecdd84f6  vmovaps [rsp+0x90], xmm10
00007588ecdd84ff  vmovaps [rsp+0xA0], xmm11
00007588ecdd8508  vmovaps [rsp+0xB0], xmm12
00007588ecdd8511  vmovaps [rsp+0xC0], xmm13
00007588ecdd851a  vmovaps [rsp+0xD0], xmm14
00007588ecdd8523  vmovaps [rsp+0xE0], xmm15
00007588ecdd852c  sub rsp, 0x40
00007588ecdd8530  lea rdi, [rsp]
00007588ecdd8534  lea rsi, [rsp+0x10]
00007588ecdd8539  lea rdx, [rsp+0x20]
00007588ecdd853e  lea rcx, [rsp+0x30]
00007588ecdd8543  mov r8d, 0x00
00007588ecdd8549  lea r9, [r15+0x3A8]
00007588ecdd8550  movaps [rdi], xmm6
00007588ecdd8553  movaps [rsi], xmm10
00007588ecdd8557  movaps [rdx], xmm12
00007588ecdd855b  movaps [rcx], xmm1
00007588ecdd855e  mov rax, 0x6516BF3BBA50
00007588ecdd8568  call rax
00007588ecdd856a  movaps xmm6, [rsp]
00007588ecdd856e  add rsp, 0x40
00007588ecdd8572  vmovaps xmm0, [rsp]
00007588ecdd8577  vmovaps xmm1, [rsp+0x10]
00007588ecdd857d  vmovaps xmm2, [rsp+0x20]
00007588ecdd8583  vmovaps xmm3, [rsp+0x30]
00007588ecdd8589  vmovaps xmm4, [rsp+0x40]
00007588ecdd858f  vmovaps xmm5, [rsp+0x50]
00007588ecdd8595  vmovaps xmm7, [rsp+0x60]
00007588ecdd859b  vmovaps xmm8, [rsp+0x70]
00007588ecdd85a1  vmovaps xmm9, [rsp+0x80]
00007588ecdd85aa  vmovaps xmm10, [rsp+0x90]
00007588ecdd85b3  vmovaps xmm11, [rsp+0xA0]
00007588ecdd85bc  vmovaps xmm12, [rsp+0xB0]
00007588ecdd85c5  vmovaps xmm13, [rsp+0xC0]
00007588ecdd85ce  vmovaps xmm14, [rsp+0xD0]
00007588ecdd85d7  vmovaps xmm15, [rsp+0xE0]
00007588ecdd85e0  add rsp, 0xF0
00007588ecdd85e7  pop r11
00007588ecdd85e9  pop r10
00007588ecdd85eb  pop r9
00007588ecdd85ed  pop r8
00007588ecdd85ef  pop rsi
00007588ecdd85f0  pop rdi
00007588ecdd85f1  pop rdx
00007588ecdd85f2  pop rcx
00007588ecdd85f3  pop rax
00007588ecdd85f4  add rsp, 0x08
00007588ecdd85f8  jmp 0x00007588ECDD69F6
00007588ecdd85fd  sub rsp, 0x08
00007588ecdd8601  push rax
00007588ecdd8602  push rcx
00007588ecdd8603  push rdx
00007588ecdd8604  push rdi
00007588ecdd8605  push rsi
00007588ecdd8606  push r8
00007588ecdd8608  push r9
00007588ecdd860a  push r10
00007588ecdd860c  push r11
00007588ecdd860e  sub rsp, 0xF0
00007588ecdd8615  vmovaps [rsp], xmm0
00007588ecdd861a  vmovaps [rsp+0x10], xmm1
00007588ecdd8620  vmovaps [rsp+0x20], xmm2
00007588ecdd8626  vmovaps [rsp+0x30], xmm3
00007588ecdd862c  vmovaps [rsp+0x40], xmm4
00007588ecdd8632  vmovaps [rsp+0x50], xmm5
00007588ecdd8638  vmovaps [rsp+0x60], xmm6
00007588ecdd863e  vmovaps [rsp+0x70], xmm7
00007588ecdd8644  vmovaps [rsp+0x80], xmm8
00007588ecdd864d  vmovaps [rsp+0x90], xmm9
00007588ecdd8656  vmovaps [rsp+0xA0], xmm11
00007588ecdd865f  vmovaps [rsp+0xB0], xmm12
00007588ecdd8668  vmovaps [rsp+0xC0], xmm13
00007588ecdd8671  vmovaps [rsp+0xD0], xmm14
00007588ecdd867a  vmovaps [rsp+0xE0], xmm15
00007588ecdd8683  sub rsp, 0x40
00007588ecdd8687  lea rdi, [rsp]
00007588ecdd868b  lea rsi, [rsp+0x10]
00007588ecdd8690  lea rdx, [rsp+0x20]
00007588ecdd8695  lea rcx, [rsp+0x30]
00007588ecdd869a  mov r8d, 0x00
00007588ecdd86a0  lea r9, [r15+0x3A8]
00007588ecdd86a7  movaps [rdi], xmm10
00007588ecdd86ab  movaps [rsi], xmm5
00007588ecdd86ae  movaps [rdx], xmm12
00007588ecdd86b2  movaps [rcx], xmm1
00007588ecdd86b5  mov rax, 0x6516BF3BBA50
00007588ecdd86bf  call rax
00007588ecdd86c1  movaps xmm10, [rsp]
00007588ecdd86c6  add rsp, 0x40
00007588ecdd86ca  vmovaps xmm0, [rsp]
00007588ecdd86cf  vmovaps xmm1, [rsp+0x10]
00007588ecdd86d5  vmovaps xmm2, [rsp+0x20]
00007588ecdd86db  vmovaps xmm3, [rsp+0x30]
00007588ecdd86e1  vmovaps xmm4, [rsp+0x40]
00007588ecdd86e7  vmovaps xmm5, [rsp+0x50]
00007588ecdd86ed  vmovaps xmm6, [rsp+0x60]
00007588ecdd86f3  vmovaps xmm7, [rsp+0x70]
00007588ecdd86f9  vmovaps xmm8, [rsp+0x80]
00007588ecdd8702  vmovaps xmm9, [rsp+0x90]
00007588ecdd870b  vmovaps xmm11, [rsp+0xA0]
00007588ecdd8714  vmovaps xmm12, [rsp+0xB0]
00007588ecdd871d  vmovaps xmm13, [rsp+0xC0]
00007588ecdd8726  vmovaps xmm14, [rsp+0xD0]
00007588ecdd872f  vmovaps xmm15, [rsp+0xE0]
00007588ecdd8738  add rsp, 0xF0
00007588ecdd873f  pop r11
00007588ecdd8741  pop r10
00007588ecdd8743  pop r9
00007588ecdd8745  pop r8
00007588ecdd8747  pop rsi
00007588ecdd8748  pop rdi
00007588ecdd8749  pop rdx
00007588ecdd874a  pop rcx
00007588ecdd874b  pop rax
00007588ecdd874c  add rsp, 0x08
00007588ecdd8750  jmp 0x00007588ECDD6A25
00007588ecdd8755  sub rsp, 0x08
00007588ecdd8759  push rax
00007588ecdd875a  push rcx
00007588ecdd875b  push rdx
00007588ecdd875c  push rdi
00007588ecdd875d  push rsi
00007588ecdd875e  push r8
00007588ecdd8760  push r9
00007588ecdd8762  push r10
00007588ecdd8764  push r11
00007588ecdd8766  sub rsp, 0xF0
00007588ecdd876d  vmovaps [rsp], xmm0
00007588ecdd8772  vmovaps [rsp+0x10], xmm1
00007588ecdd8778  vmovaps [rsp+0x20], xmm2
00007588ecdd877e  vmovaps [rsp+0x30], xmm3
00007588ecdd8784  vmovaps [rsp+0x40], xmm4
00007588ecdd878a  vmovaps [rsp+0x50], xmm5
00007588ecdd8790  vmovaps [rsp+0x60], xmm6
00007588ecdd8796  vmovaps [rsp+0x70], xmm7
00007588ecdd879c  vmovaps [rsp+0x80], xmm8
00007588ecdd87a5  vmovaps [rsp+0x90], xmm9
00007588ecdd87ae  vmovaps [rsp+0xA0], xmm10
00007588ecdd87b7  vmovaps [rsp+0xB0], xmm11
00007588ecdd87c0  vmovaps [rsp+0xC0], xmm13
00007588ecdd87c9  vmovaps [rsp+0xD0], xmm14
00007588ecdd87d2  vmovaps [rsp+0xE0], xmm15
00007588ecdd87db  sub rsp, 0x40
00007588ecdd87df  lea rdi, [rsp]
00007588ecdd87e3  lea rsi, [rsp+0x10]
00007588ecdd87e8  lea rdx, [rsp+0x20]
00007588ecdd87ed  lea rcx, [rsp+0x30]
00007588ecdd87f2  mov r8d, 0x00
00007588ecdd87f8  lea r9, [r15+0x3A8]
00007588ecdd87ff  movaps [rdi], xmm12
00007588ecdd8803  movaps [rsi], xmm7
00007588ecdd8806  movaps [rdx], xmm15
00007588ecdd880a  movaps [rcx], xmm1
00007588ecdd880d  mov rax, 0x6516BF3BBA50
00007588ecdd8817  call rax
00007588ecdd8819  movaps xmm12, [rsp]
00007588ecdd881e  add rsp, 0x40
00007588ecdd8822  vmovaps xmm0, [rsp]
00007588ecdd8827  vmovaps xmm1, [rsp+0x10]
00007588ecdd882d  vmovaps xmm2, [rsp+0x20]
00007588ecdd8833  vmovaps xmm3, [rsp+0x30]
00007588ecdd8839  vmovaps xmm4, [rsp+0x40]
00007588ecdd883f  vmovaps xmm5, [rsp+0x50]
00007588ecdd8845  vmovaps xmm6, [rsp+0x60]
00007588ecdd884b  vmovaps xmm7, [rsp+0x70]
00007588ecdd8851  vmovaps xmm8, [rsp+0x80]
00007588ecdd885a  vmovaps xmm9, [rsp+0x90]
00007588ecdd8863  vmovaps xmm10, [rsp+0xA0]
00007588ecdd886c  vmovaps xmm11, [rsp+0xB0]
00007588ecdd8875  vmovaps xmm13, [rsp+0xC0]
00007588ecdd887e  vmovaps xmm14, [rsp+0xD0]
00007588ecdd8887  vmovaps xmm15, [rsp+0xE0]
00007588ecdd8890  add rsp, 0xF0
00007588ecdd8897  pop r11
00007588ecdd8899  pop r10
00007588ecdd889b  pop r9
00007588ecdd889d  pop r8
00007588ecdd889f  pop rsi
00007588ecdd88a0  pop rdi
00007588ecdd88a1  pop rdx
00007588ecdd88a2  pop rcx
00007588ecdd88a3  pop rax
00007588ecdd88a4  add rsp, 0x08
00007588ecdd88a8  jmp 0x00007588ECDD6A4E
00007588ecdd88ad  call 0x00007588ECCD64F0
00007588ecdd88b2  jmp 0x00007588ECDD6A58
00007588ecdd88b7  call 0x00007588ECCE5820
00007588ecdd88bc  jmp 0x00007588ECDD6A62
00007588ecdd88c1  sub rsp, 0x08
00007588ecdd88c5  push rax
00007588ecdd88c6  push rcx
00007588ecdd88c7  push rdx
00007588ecdd88c8  push rdi
00007588ecdd88c9  push rsi
00007588ecdd88ca  push r8
00007588ecdd88cc  push r9
00007588ecdd88ce  push r10
00007588ecdd88d0  push r11
00007588ecdd88d2  sub rsp, 0xF0
00007588ecdd88d9  vmovaps [rsp], xmm0
00007588ecdd88de  vmovaps [rsp+0x10], xmm1
00007588ecdd88e4  vmovaps [rsp+0x20], xmm2
00007588ecdd88ea  vmovaps [rsp+0x30], xmm3
00007588ecdd88f0  vmovaps [rsp+0x40], xmm4
00007588ecdd88f6  vmovaps [rsp+0x50], xmm5
00007588ecdd88fc  vmovaps [rsp+0x60], xmm6
00007588ecdd8902  vmovaps [rsp+0x70], xmm8
00007588ecdd8908  vmovaps [rsp+0x80], xmm9
00007588ecdd8911  vmovaps [rsp+0x90], xmm10
00007588ecdd891a  vmovaps [rsp+0xA0], xmm11
00007588ecdd8923  vmovaps [rsp+0xB0], xmm12
00007588ecdd892c  vmovaps [rsp+0xC0], xmm13
00007588ecdd8935  vmovaps [rsp+0xD0], xmm14
00007588ecdd893e  vmovaps [rsp+0xE0], xmm15
00007588ecdd8947  sub rsp, 0x40
00007588ecdd894b  lea rdi, [rsp]
00007588ecdd894f  lea rsi, [rsp+0x10]
00007588ecdd8954  lea rdx, [rsp+0x20]
00007588ecdd8959  lea rcx, [rsp+0x30]
00007588ecdd895e  mov r8d, 0x00
00007588ecdd8964  lea r9, [r15+0x3A8]
00007588ecdd896b  movaps [rdi], xmm7
00007588ecdd896e  movaps [rsi], xmm2
00007588ecdd8971  movaps [rdx], xmm9
00007588ecdd8975  movaps [rcx], xmm11
00007588ecdd8979  mov rax, 0x6516BF3BBA50
00007588ecdd8983  call rax
00007588ecdd8985  movaps xmm7, [rsp]
00007588ecdd8989  add rsp, 0x40
00007588ecdd898d  vmovaps xmm0, [rsp]
00007588ecdd8992  vmovaps xmm1, [rsp+0x10]
00007588ecdd8998  vmovaps xmm2, [rsp+0x20]
00007588ecdd899e  vmovaps xmm3, [rsp+0x30]
00007588ecdd89a4  vmovaps xmm4, [rsp+0x40]
00007588ecdd89aa  vmovaps xmm5, [rsp+0x50]
00007588ecdd89b0  vmovaps xmm6, [rsp+0x60]
00007588ecdd89b6  vmovaps xmm8, [rsp+0x70]
00007588ecdd89bc  vmovaps xmm9, [rsp+0x80]
00007588ecdd89c5  vmovaps xmm10, [rsp+0x90]
00007588ecdd89ce  vmovaps xmm11, [rsp+0xA0]
00007588ecdd89d7  vmovaps xmm12, [rsp+0xB0]
00007588ecdd89e0  vmovaps xmm13, [rsp+0xC0]
00007588ecdd89e9  vmovaps xmm14, [rsp+0xD0]
00007588ecdd89f2  vmovaps xmm15, [rsp+0xE0]
00007588ecdd89fb  add rsp, 0xF0
00007588ecdd8a02  pop r11
00007588ecdd8a04  pop r10
00007588ecdd8a06  pop r9
00007588ecdd8a08  pop r8
00007588ecdd8a0a  pop rsi
00007588ecdd8a0b  pop rdi
00007588ecdd8a0c  pop rdx
00007588ecdd8a0d  pop rcx
00007588ecdd8a0e  pop rax
00007588ecdd8a0f  add rsp, 0x08
00007588ecdd8a13  jmp 0x00007588ECDD6A96
00007588ecdd8a18  sub rsp, 0x08
00007588ecdd8a1c  push rax
00007588ecdd8a1d  push rcx
00007588ecdd8a1e  push rdx
00007588ecdd8a1f  push rdi
00007588ecdd8a20  push rsi
00007588ecdd8a21  push r8
00007588ecdd8a23  push r9
00007588ecdd8a25  push r10
00007588ecdd8a27  push r11
00007588ecdd8a29  sub rsp, 0xF0
00007588ecdd8a30  vmovaps [rsp], xmm0
00007588ecdd8a35  vmovaps [rsp+0x10], xmm1
00007588ecdd8a3b  vmovaps [rsp+0x20], xmm2
00007588ecdd8a41  vmovaps [rsp+0x30], xmm3
00007588ecdd8a47  vmovaps [rsp+0x40], xmm4
00007588ecdd8a4d  vmovaps [rsp+0x50], xmm5
00007588ecdd8a53  vmovaps [rsp+0x60], xmm6
00007588ecdd8a59  vmovaps [rsp+0x70], xmm7
00007588ecdd8a5f  vmovaps [rsp+0x80], xmm8
00007588ecdd8a68  vmovaps [rsp+0x90], xmm10
00007588ecdd8a71  vmovaps [rsp+0xA0], xmm11
00007588ecdd8a7a  vmovaps [rsp+0xB0], xmm12
00007588ecdd8a83  vmovaps [rsp+0xC0], xmm13
00007588ecdd8a8c  vmovaps [rsp+0xD0], xmm14
00007588ecdd8a95  vmovaps [rsp+0xE0], xmm15
00007588ecdd8a9e  sub rsp, 0x40
00007588ecdd8aa2  lea rdi, [rsp]
00007588ecdd8aa6  lea rsi, [rsp+0x10]
00007588ecdd8aab  lea rdx, [rsp+0x20]
00007588ecdd8ab0  lea rcx, [rsp+0x30]
00007588ecdd8ab5  mov r8d, 0x00
00007588ecdd8abb  lea r9, [r15+0x3A8]
00007588ecdd8ac2  movaps [rdi], xmm9
00007588ecdd8ac6  movaps [rsi], xmm6
00007588ecdd8ac9  movaps [rdx], xmm1
00007588ecdd8acc  movaps [rcx], xmm11
00007588ecdd8ad0  mov rax, 0x6516BF3BBA50
00007588ecdd8ada  call rax
00007588ecdd8adc  movaps xmm9, [rsp]
00007588ecdd8ae1  add rsp, 0x40
00007588ecdd8ae5  vmovaps xmm0, [rsp]
00007588ecdd8aea  vmovaps xmm1, [rsp+0x10]
00007588ecdd8af0  vmovaps xmm2, [rsp+0x20]
00007588ecdd8af6  vmovaps xmm3, [rsp+0x30]
00007588ecdd8afc  vmovaps xmm4, [rsp+0x40]
00007588ecdd8b02  vmovaps xmm5, [rsp+0x50]
00007588ecdd8b08  vmovaps xmm6, [rsp+0x60]
00007588ecdd8b0e  vmovaps xmm7, [rsp+0x70]
00007588ecdd8b14  vmovaps xmm8, [rsp+0x80]
00007588ecdd8b1d  vmovaps xmm10, [rsp+0x90]
00007588ecdd8b26  vmovaps xmm11, [rsp+0xA0]
00007588ecdd8b2f  vmovaps xmm12, [rsp+0xB0]
00007588ecdd8b38  vmovaps xmm13, [rsp+0xC0]
00007588ecdd8b41  vmovaps xmm14, [rsp+0xD0]
00007588ecdd8b4a  vmovaps xmm15, [rsp+0xE0]
00007588ecdd8b53  add rsp, 0xF0
00007588ecdd8b5a  pop r11
00007588ecdd8b5c  pop r10
00007588ecdd8b5e  pop r9
00007588ecdd8b60  pop r8
00007588ecdd8b62  pop rsi
00007588ecdd8b63  pop rdi
00007588ecdd8b64  pop rdx
00007588ecdd8b65  pop rcx
00007588ecdd8b66  pop rax
00007588ecdd8b67  add rsp, 0x08
00007588ecdd8b6b  jmp 0x00007588ECDD6ABC
00007588ecdd8b70  sub rsp, 0x08
00007588ecdd8b74  push rax
00007588ecdd8b75  push rcx
00007588ecdd8b76  push rdx
00007588ecdd8b77  push rdi
00007588ecdd8b78  push rsi
00007588ecdd8b79  push r8
00007588ecdd8b7b  push r9
00007588ecdd8b7d  push r10
00007588ecdd8b7f  push r11
00007588ecdd8b81  sub rsp, 0xF0
00007588ecdd8b88  vmovaps [rsp], xmm0
00007588ecdd8b8d  vmovaps [rsp+0x10], xmm1
00007588ecdd8b93  vmovaps [rsp+0x20], xmm2
00007588ecdd8b99  vmovaps [rsp+0x30], xmm3
00007588ecdd8b9f  vmovaps [rsp+0x40], xmm4
00007588ecdd8ba5  vmovaps [rsp+0x50], xmm5
00007588ecdd8bab  vmovaps [rsp+0x60], xmm6
00007588ecdd8bb1  vmovaps [rsp+0x70], xmm7
00007588ecdd8bb7  vmovaps [rsp+0x80], xmm8
00007588ecdd8bc0  vmovaps [rsp+0x90], xmm9
00007588ecdd8bc9  vmovaps [rsp+0xA0], xmm10
00007588ecdd8bd2  vmovaps [rsp+0xB0], xmm12
00007588ecdd8bdb  vmovaps [rsp+0xC0], xmm13
00007588ecdd8be4  vmovaps [rsp+0xD0], xmm14
00007588ecdd8bed  vmovaps [rsp+0xE0], xmm15
00007588ecdd8bf6  sub rsp, 0x40
00007588ecdd8bfa  lea rdi, [rsp]
00007588ecdd8bfe  lea rsi, [rsp+0x10]
00007588ecdd8c03  lea rdx, [rsp+0x20]
00007588ecdd8c08  lea rcx, [rsp+0x30]
00007588ecdd8c0d  mov r8d, 0x00
00007588ecdd8c13  lea r9, [r15+0x3A8]
00007588ecdd8c1a  movaps [rdi], xmm11
00007588ecdd8c1e  movaps [rsi], xmm10
00007588ecdd8c22  movaps [rdx], xmm8
00007588ecdd8c26  movaps [rcx], xmm1
00007588ecdd8c29  mov rax, 0x6516BF3BBA50
00007588ecdd8c33  call rax
00007588ecdd8c35  movaps xmm11, [rsp]
00007588ecdd8c3a  add rsp, 0x40
00007588ecdd8c3e  vmovaps xmm0, [rsp]
00007588ecdd8c43  vmovaps xmm1, [rsp+0x10]
00007588ecdd8c49  vmovaps xmm2, [rsp+0x20]
00007588ecdd8c4f  vmovaps xmm3, [rsp+0x30]
00007588ecdd8c55  vmovaps xmm4, [rsp+0x40]
00007588ecdd8c5b  vmovaps xmm5, [rsp+0x50]
00007588ecdd8c61  vmovaps xmm6, [rsp+0x60]
00007588ecdd8c67  vmovaps xmm7, [rsp+0x70]
00007588ecdd8c6d  vmovaps xmm8, [rsp+0x80]
00007588ecdd8c76  vmovaps xmm9, [rsp+0x90]
00007588ecdd8c7f  vmovaps xmm10, [rsp+0xA0]
00007588ecdd8c88  vmovaps xmm12, [rsp+0xB0]
00007588ecdd8c91  vmovaps xmm13, [rsp+0xC0]
00007588ecdd8c9a  vmovaps xmm14, [rsp+0xD0]
00007588ecdd8ca3  vmovaps xmm15, [rsp+0xE0]
00007588ecdd8cac  add rsp, 0xF0
00007588ecdd8cb3  pop r11
00007588ecdd8cb5  pop r10
00007588ecdd8cb7  pop r9
00007588ecdd8cb9  pop r8
00007588ecdd8cbb  pop rsi
00007588ecdd8cbc  pop rdi
00007588ecdd8cbd  pop rdx
00007588ecdd8cbe  pop rcx
00007588ecdd8cbf  pop rax
00007588ecdd8cc0  add rsp, 0x08
00007588ecdd8cc4  jmp 0x00007588ECDD6AE2
00007588ecdd8cc9  sub rsp, 0x08
00007588ecdd8ccd  push rax
00007588ecdd8cce  push rcx
00007588ecdd8ccf  push rdx
00007588ecdd8cd0  push rdi
00007588ecdd8cd1  push rsi
00007588ecdd8cd2  push r8
00007588ecdd8cd4  push r9
00007588ecdd8cd6  push r10
00007588ecdd8cd8  push r11
00007588ecdd8cda  sub rsp, 0xF0
00007588ecdd8ce1  vmovaps [rsp], xmm0
00007588ecdd8ce6  vmovaps [rsp+0x10], xmm1
00007588ecdd8cec  vmovaps [rsp+0x20], xmm2
00007588ecdd8cf2  vmovaps [rsp+0x30], xmm3
00007588ecdd8cf8  vmovaps [rsp+0x40], xmm4
00007588ecdd8cfe  vmovaps [rsp+0x50], xmm5
00007588ecdd8d04  vmovaps [rsp+0x60], xmm6
00007588ecdd8d0a  vmovaps [rsp+0x70], xmm7
00007588ecdd8d10  vmovaps [rsp+0x80], xmm8
00007588ecdd8d19  vmovaps [rsp+0x90], xmm9
00007588ecdd8d22  vmovaps [rsp+0xA0], xmm11
00007588ecdd8d2b  vmovaps [rsp+0xB0], xmm12
00007588ecdd8d34  vmovaps [rsp+0xC0], xmm13
00007588ecdd8d3d  vmovaps [rsp+0xD0], xmm14
00007588ecdd8d46  vmovaps [rsp+0xE0], xmm15
00007588ecdd8d4f  sub rsp, 0x40
00007588ecdd8d53  lea rdi, [rsp]
00007588ecdd8d57  lea rsi, [rsp+0x10]
00007588ecdd8d5c  lea rdx, [rsp+0x20]
00007588ecdd8d61  lea rcx, [rsp+0x30]
00007588ecdd8d66  mov r8d, 0x00
00007588ecdd8d6c  lea r9, [r15+0x3A8]
00007588ecdd8d73  movaps [rdi], xmm10
00007588ecdd8d77  movaps [rsi], xmm12
00007588ecdd8d7b  movaps [rdx], xmm13
00007588ecdd8d7f  movaps [rcx], xmm1
00007588ecdd8d82  mov rax, 0x6516BF3BBA50
00007588ecdd8d8c  call rax
00007588ecdd8d8e  movaps xmm10, [rsp]
00007588ecdd8d93  add rsp, 0x40
00007588ecdd8d97  vmovaps xmm0, [rsp]
00007588ecdd8d9c  vmovaps xmm1, [rsp+0x10]
00007588ecdd8da2  vmovaps xmm2, [rsp+0x20]
00007588ecdd8da8  vmovaps xmm3, [rsp+0x30]
00007588ecdd8dae  vmovaps xmm4, [rsp+0x40]
00007588ecdd8db4  vmovaps xmm5, [rsp+0x50]
00007588ecdd8dba  vmovaps xmm6, [rsp+0x60]
00007588ecdd8dc0  vmovaps xmm7, [rsp+0x70]
00007588ecdd8dc6  vmovaps xmm8, [rsp+0x80]
00007588ecdd8dcf  vmovaps xmm9, [rsp+0x90]
00007588ecdd8dd8  vmovaps xmm11, [rsp+0xA0]
00007588ecdd8de1  vmovaps xmm12, [rsp+0xB0]
00007588ecdd8dea  vmovaps xmm13, [rsp+0xC0]
00007588ecdd8df3  vmovaps xmm14, [rsp+0xD0]
00007588ecdd8dfc  vmovaps xmm15, [rsp+0xE0]
00007588ecdd8e05  add rsp, 0xF0
00007588ecdd8e0c  pop r11
00007588ecdd8e0e  pop r10
00007588ecdd8e10  pop r9
00007588ecdd8e12  pop r8
00007588ecdd8e14  pop rsi
00007588ecdd8e15  pop rdi
00007588ecdd8e16  pop rdx
00007588ecdd8e17  pop rcx
00007588ecdd8e18  pop rax
00007588ecdd8e19  add rsp, 0x08
00007588ecdd8e1d  jmp 0x00007588ECDD6B08
00007588ecdd8e22  call 0x00007588ECCD64F0
00007588ecdd8e27  jmp 0x00007588ECDD6B12
00007588ecdd8e2c  call 0x00007588ECCE3320
00007588ecdd8e31  jmp 0x00007588ECDD6B1C
00007588ecdd8e36  sub rsp, 0x08
00007588ecdd8e3a  push rax
00007588ecdd8e3b  push rcx
00007588ecdd8e3c  push rdx
00007588ecdd8e3d  push rdi
00007588ecdd8e3e  push rsi
00007588ecdd8e3f  push r8
00007588ecdd8e41  push r9
00007588ecdd8e43  push r10
00007588ecdd8e45  push r11
00007588ecdd8e47  sub rsp, 0xF0
00007588ecdd8e4e  vmovaps [rsp], xmm0
00007588ecdd8e53  vmovaps [rsp+0x10], xmm1
00007588ecdd8e59  vmovaps [rsp+0x20], xmm2
00007588ecdd8e5f  vmovaps [rsp+0x30], xmm3
00007588ecdd8e65  vmovaps [rsp+0x40], xmm4
00007588ecdd8e6b  vmovaps [rsp+0x50], xmm5
00007588ecdd8e71  vmovaps [rsp+0x60], xmm6
00007588ecdd8e77  vmovaps [rsp+0x70], xmm7
00007588ecdd8e7d  vmovaps [rsp+0x80], xmm9
00007588ecdd8e86  vmovaps [rsp+0x90], xmm10
00007588ecdd8e8f  vmovaps [rsp+0xA0], xmm11
00007588ecdd8e98  vmovaps [rsp+0xB0], xmm12
00007588ecdd8ea1  vmovaps [rsp+0xC0], xmm13
00007588ecdd8eaa  vmovaps [rsp+0xD0], xmm14
00007588ecdd8eb3  vmovaps [rsp+0xE0], xmm15
00007588ecdd8ebc  sub rsp, 0x40
00007588ecdd8ec0  lea rdi, [rsp]
00007588ecdd8ec4  lea rsi, [rsp+0x10]
00007588ecdd8ec9  lea rdx, [rsp+0x20]
00007588ecdd8ece  lea rcx, [rsp+0x30]
00007588ecdd8ed3  mov r8d, 0x00
00007588ecdd8ed9  lea r9, [r15+0x3A8]
00007588ecdd8ee0  movaps [rdi], xmm8
00007588ecdd8ee4  movaps [rsi], xmm7
00007588ecdd8ee7  movaps [rdx], xmm4
00007588ecdd8eea  movaps [rcx], xmm12
00007588ecdd8eee  mov rax, 0x6516BF3BBA50
00007588ecdd8ef8  call rax
00007588ecdd8efa  movaps xmm8, [rsp]
00007588ecdd8eff  add rsp, 0x40
00007588ecdd8f03  vmovaps xmm0, [rsp]
00007588ecdd8f08  vmovaps xmm1, [rsp+0x10]
00007588ecdd8f0e  vmovaps xmm2, [rsp+0x20]
00007588ecdd8f14  vmovaps xmm3, [rsp+0x30]
00007588ecdd8f1a  vmovaps xmm4, [rsp+0x40]
00007588ecdd8f20  vmovaps xmm5, [rsp+0x50]
00007588ecdd8f26  vmovaps xmm6, [rsp+0x60]
00007588ecdd8f2c  vmovaps xmm7, [rsp+0x70]
00007588ecdd8f32  vmovaps xmm9, [rsp+0x80]
00007588ecdd8f3b  vmovaps xmm10, [rsp+0x90]
00007588ecdd8f44  vmovaps xmm11, [rsp+0xA0]
00007588ecdd8f4d  vmovaps xmm12, [rsp+0xB0]
00007588ecdd8f56  vmovaps xmm13, [rsp+0xC0]
00007588ecdd8f5f  vmovaps xmm14, [rsp+0xD0]
00007588ecdd8f68  vmovaps xmm15, [rsp+0xE0]
00007588ecdd8f71  add rsp, 0xF0
00007588ecdd8f78  pop r11
00007588ecdd8f7a  pop r10
00007588ecdd8f7c  pop r9
00007588ecdd8f7e  pop r8
00007588ecdd8f80  pop rsi
00007588ecdd8f81  pop rdi
00007588ecdd8f82  pop rdx
00007588ecdd8f83  pop rcx
00007588ecdd8f84  pop rax
00007588ecdd8f85  add rsp, 0x08
00007588ecdd8f89  jmp 0x00007588ECDD6B45
00007588ecdd8f8e  sub rsp, 0x08
00007588ecdd8f92  push rax
00007588ecdd8f93  push rcx
00007588ecdd8f94  push rdx
00007588ecdd8f95  push rdi
00007588ecdd8f96  push rsi
00007588ecdd8f97  push r8
00007588ecdd8f99  push r9
00007588ecdd8f9b  push r10
00007588ecdd8f9d  push r11
00007588ecdd8f9f  sub rsp, 0xF0
00007588ecdd8fa6  vmovaps [rsp], xmm0
00007588ecdd8fab  vmovaps [rsp+0x10], xmm1
00007588ecdd8fb1  vmovaps [rsp+0x20], xmm2
00007588ecdd8fb7  vmovaps [rsp+0x30], xmm3
00007588ecdd8fbd  vmovaps [rsp+0x40], xmm4
00007588ecdd8fc3  vmovaps [rsp+0x50], xmm5
00007588ecdd8fc9  vmovaps [rsp+0x60], xmm6
00007588ecdd8fcf  vmovaps [rsp+0x70], xmm8
00007588ecdd8fd5  vmovaps [rsp+0x80], xmm9
00007588ecdd8fde  vmovaps [rsp+0x90], xmm10
00007588ecdd8fe7  vmovaps [rsp+0xA0], xmm11
00007588ecdd8ff0  vmovaps [rsp+0xB0], xmm12
00007588ecdd8ff9  vmovaps [rsp+0xC0], xmm13
00007588ecdd9002  vmovaps [rsp+0xD0], xmm14
00007588ecdd900b  vmovaps [rsp+0xE0], xmm15
00007588ecdd9014  sub rsp, 0x40
00007588ecdd9018  lea rdi, [rsp]
00007588ecdd901c  lea rsi, [rsp+0x10]
00007588ecdd9021  lea rdx, [rsp+0x20]
00007588ecdd9026  lea rcx, [rsp+0x30]
00007588ecdd902b  mov r8d, 0x00
00007588ecdd9031  lea r9, [r15+0x3A8]
00007588ecdd9038  movaps [rdi], xmm7
00007588ecdd903b  movaps [rsi], xmm9
00007588ecdd903f  movaps [rdx], xmm14
00007588ecdd9043  movaps [rcx], xmm12
00007588ecdd9047  mov rax, 0x6516BF3BBA50
00007588ecdd9051  call rax
00007588ecdd9053  movaps xmm7, [rsp]
00007588ecdd9057  add rsp, 0x40
00007588ecdd905b  vmovaps xmm0, [rsp]
00007588ecdd9060  vmovaps xmm1, [rsp+0x10]
00007588ecdd9066  vmovaps xmm2, [rsp+0x20]
00007588ecdd906c  vmovaps xmm3, [rsp+0x30]
00007588ecdd9072  vmovaps xmm4, [rsp+0x40]
00007588ecdd9078  vmovaps xmm5, [rsp+0x50]
00007588ecdd907e  vmovaps xmm6, [rsp+0x60]
00007588ecdd9084  vmovaps xmm8, [rsp+0x70]
00007588ecdd908a  vmovaps xmm9, [rsp+0x80]
00007588ecdd9093  vmovaps xmm10, [rsp+0x90]
00007588ecdd909c  vmovaps xmm11, [rsp+0xA0]
00007588ecdd90a5  vmovaps xmm12, [rsp+0xB0]
00007588ecdd90ae  vmovaps xmm13, [rsp+0xC0]
00007588ecdd90b7  vmovaps xmm14, [rsp+0xD0]
00007588ecdd90c0  vmovaps xmm15, [rsp+0xE0]
00007588ecdd90c9  add rsp, 0xF0
00007588ecdd90d0  pop r11
00007588ecdd90d2  pop r10
00007588ecdd90d4  pop r9
00007588ecdd90d6  pop r8
00007588ecdd90d8  pop rsi
00007588ecdd90d9  pop rdi
00007588ecdd90da  pop rdx
00007588ecdd90db  pop rcx
00007588ecdd90dc  pop rax
00007588ecdd90dd  add rsp, 0x08
00007588ecdd90e1  jmp 0x00007588ECDD6B6D
00007588ecdd90e6  sub rsp, 0x08
00007588ecdd90ea  push rax
00007588ecdd90eb  push rcx
00007588ecdd90ec  push rdx
00007588ecdd90ed  push rdi
00007588ecdd90ee  push rsi
00007588ecdd90ef  push r8
00007588ecdd90f1  push r9
00007588ecdd90f3  push r10
00007588ecdd90f5  push r11
00007588ecdd90f7  sub rsp, 0xF0
00007588ecdd90fe  vmovaps [rsp], xmm0
00007588ecdd9103  vmovaps [rsp+0x10], xmm1
00007588ecdd9109  vmovaps [rsp+0x20], xmm2
00007588ecdd910f  vmovaps [rsp+0x30], xmm3
00007588ecdd9115  vmovaps [rsp+0x40], xmm4
00007588ecdd911b  vmovaps [rsp+0x50], xmm5
00007588ecdd9121  vmovaps [rsp+0x60], xmm6
00007588ecdd9127  vmovaps [rsp+0x70], xmm7
00007588ecdd912d  vmovaps [rsp+0x80], xmm8
00007588ecdd9136  vmovaps [rsp+0x90], xmm9
00007588ecdd913f  vmovaps [rsp+0xA0], xmm10
00007588ecdd9148  vmovaps [rsp+0xB0], xmm11
00007588ecdd9151  vmovaps [rsp+0xC0], xmm13
00007588ecdd915a  vmovaps [rsp+0xD0], xmm14
00007588ecdd9163  vmovaps [rsp+0xE0], xmm15
00007588ecdd916c  sub rsp, 0x40
00007588ecdd9170  lea rdi, [rsp]
00007588ecdd9174  lea rsi, [rsp+0x10]
00007588ecdd9179  lea rdx, [rsp+0x20]
00007588ecdd917e  lea rcx, [rsp+0x30]
00007588ecdd9183  mov r8d, 0x00
00007588ecdd9189  lea r9, [r15+0x3A8]
00007588ecdd9190  movaps [rdi], xmm12
00007588ecdd9194  movaps [rsi], xmm11
00007588ecdd9198  movaps [rdx], xmm15
00007588ecdd919c  movaps [rcx], xmm14
00007588ecdd91a0  mov rax, 0x6516BF3BBA50
00007588ecdd91aa  call rax
00007588ecdd91ac  movaps xmm12, [rsp]
00007588ecdd91b1  add rsp, 0x40
00007588ecdd91b5  vmovaps xmm0, [rsp]
00007588ecdd91ba  vmovaps xmm1, [rsp+0x10]
00007588ecdd91c0  vmovaps xmm2, [rsp+0x20]
00007588ecdd91c6  vmovaps xmm3, [rsp+0x30]
00007588ecdd91cc  vmovaps xmm4, [rsp+0x40]
00007588ecdd91d2  vmovaps xmm5, [rsp+0x50]
00007588ecdd91d8  vmovaps xmm6, [rsp+0x60]
00007588ecdd91de  vmovaps xmm7, [rsp+0x70]
00007588ecdd91e4  vmovaps xmm8, [rsp+0x80]
00007588ecdd91ed  vmovaps xmm9, [rsp+0x90]
00007588ecdd91f6  vmovaps xmm10, [rsp+0xA0]
00007588ecdd91ff  vmovaps xmm11, [rsp+0xB0]
00007588ecdd9208  vmovaps xmm13, [rsp+0xC0]
00007588ecdd9211  vmovaps xmm14, [rsp+0xD0]
00007588ecdd921a  vmovaps xmm15, [rsp+0xE0]
00007588ecdd9223  add rsp, 0xF0
00007588ecdd922a  pop r11
00007588ecdd922c  pop r10
00007588ecdd922e  pop r9
00007588ecdd9230  pop r8
00007588ecdd9232  pop rsi
00007588ecdd9233  pop rdi
00007588ecdd9234  pop rdx
00007588ecdd9235  pop rcx
00007588ecdd9236  pop rax
00007588ecdd9237  add rsp, 0x08
00007588ecdd923b  jmp 0x00007588ECDD6B96
00007588ecdd9240  sub rsp, 0x08
00007588ecdd9244  push rax
00007588ecdd9245  push rcx
00007588ecdd9246  push rdx
00007588ecdd9247  push rdi
00007588ecdd9248  push rsi
00007588ecdd9249  push r8
00007588ecdd924b  push r9
00007588ecdd924d  push r10
00007588ecdd924f  push r11
00007588ecdd9251  sub rsp, 0xF0
00007588ecdd9258  vmovaps [rsp], xmm0
00007588ecdd925d  vmovaps [rsp+0x10], xmm1
00007588ecdd9263  vmovaps [rsp+0x20], xmm2
00007588ecdd9269  vmovaps [rsp+0x30], xmm3
00007588ecdd926f  vmovaps [rsp+0x40], xmm4
00007588ecdd9275  vmovaps [rsp+0x50], xmm5
00007588ecdd927b  vmovaps [rsp+0x60], xmm6
00007588ecdd9281  vmovaps [rsp+0x70], xmm7
00007588ecdd9287  vmovaps [rsp+0x80], xmm8
00007588ecdd9290  vmovaps [rsp+0x90], xmm9
00007588ecdd9299  vmovaps [rsp+0xA0], xmm10
00007588ecdd92a2  vmovaps [rsp+0xB0], xmm12
00007588ecdd92ab  vmovaps [rsp+0xC0], xmm13
00007588ecdd92b4  vmovaps [rsp+0xD0], xmm14
00007588ecdd92bd  vmovaps [rsp+0xE0], xmm15
00007588ecdd92c6  sub rsp, 0x40
00007588ecdd92ca  lea rdi, [rsp]
00007588ecdd92ce  lea rsi, [rsp+0x10]
00007588ecdd92d3  lea rdx, [rsp+0x20]
00007588ecdd92d8  lea rcx, [rsp+0x30]
00007588ecdd92dd  mov r8d, 0x00
00007588ecdd92e3  lea r9, [r15+0x3A8]
00007588ecdd92ea  movaps [rdi], xmm11
00007588ecdd92ee  movaps [rsi], xmm10
00007588ecdd92f2  movaps [rdx], xmm13
00007588ecdd92f6  movaps [rcx], xmm15
00007588ecdd92fa  mov rax, 0x6516BF3BBA50
00007588ecdd9304  call rax
00007588ecdd9306  movaps xmm11, [rsp]
00007588ecdd930b  add rsp, 0x40
00007588ecdd930f  vmovaps xmm0, [rsp]
00007588ecdd9314  vmovaps xmm1, [rsp+0x10]
00007588ecdd931a  vmovaps xmm2, [rsp+0x20]
00007588ecdd9320  vmovaps xmm3, [rsp+0x30]
00007588ecdd9326  vmovaps xmm4, [rsp+0x40]
00007588ecdd932c  vmovaps xmm5, [rsp+0x50]
00007588ecdd9332  vmovaps xmm6, [rsp+0x60]
00007588ecdd9338  vmovaps xmm7, [rsp+0x70]
00007588ecdd933e  vmovaps xmm8, [rsp+0x80]
00007588ecdd9347  vmovaps xmm9, [rsp+0x90]
00007588ecdd9350  vmovaps xmm10, [rsp+0xA0]
00007588ecdd9359  vmovaps xmm12, [rsp+0xB0]
00007588ecdd9362  vmovaps xmm13, [rsp+0xC0]
00007588ecdd936b  vmovaps xmm14, [rsp+0xD0]
00007588ecdd9374  vmovaps xmm15, [rsp+0xE0]
00007588ecdd937d  add rsp, 0xF0
00007588ecdd9384  pop r11
00007588ecdd9386  pop r10
00007588ecdd9388  pop r9
00007588ecdd938a  pop r8
00007588ecdd938c  pop rsi
00007588ecdd938d  pop rdi
00007588ecdd938e  pop rdx
00007588ecdd938f  pop rcx
00007588ecdd9390  pop rax
00007588ecdd9391  add rsp, 0x08
00007588ecdd9395  jmp 0x00007588ECDD6BBF
00007588ecdd939a  call 0x00007588ECCE5820
00007588ecdd939f  jmp 0x00007588ECDD6BCC
00007588ecdd93a4  call 0x00007588ECCE45A0
00007588ecdd93a9  jmp 0x00007588ECDD6BD9
00007588ecdd93ae  sub rsp, 0x08
00007588ecdd93b2  push rax
00007588ecdd93b3  push rcx
00007588ecdd93b4  push rdx
00007588ecdd93b5  push rdi
00007588ecdd93b6  push rsi
00007588ecdd93b7  push r8
00007588ecdd93b9  push r9
00007588ecdd93bb  push r10
00007588ecdd93bd  push r11
00007588ecdd93bf  sub rsp, 0xF0
00007588ecdd93c6  vmovaps [rsp], xmm0
00007588ecdd93cb  vmovaps [rsp+0x10], xmm1
00007588ecdd93d1  vmovaps [rsp+0x20], xmm2
00007588ecdd93d7  vmovaps [rsp+0x30], xmm3
00007588ecdd93dd  vmovaps [rsp+0x40], xmm4
00007588ecdd93e3  vmovaps [rsp+0x50], xmm5
00007588ecdd93e9  vmovaps [rsp+0x60], xmm6
00007588ecdd93ef  vmovaps [rsp+0x70], xmm7
00007588ecdd93f5  vmovaps [rsp+0x80], xmm8
00007588ecdd93fe  vmovaps [rsp+0x90], xmm9
00007588ecdd9407  vmovaps [rsp+0xA0], xmm11
00007588ecdd9410  vmovaps [rsp+0xB0], xmm12
00007588ecdd9419  vmovaps [rsp+0xC0], xmm13
00007588ecdd9422  vmovaps [rsp+0xD0], xmm14
00007588ecdd942b  vmovaps [rsp+0xE0], xmm15
00007588ecdd9434  sub rsp, 0x40
00007588ecdd9438  lea rdi, [rsp]
00007588ecdd943c  lea rsi, [rsp+0x10]
00007588ecdd9441  lea rdx, [rsp+0x20]
00007588ecdd9446  lea rcx, [rsp+0x30]
00007588ecdd944b  mov r8d, 0x00
00007588ecdd9451  lea r9, [r15+0x3A8]
00007588ecdd9458  movaps [rdi], xmm10
00007588ecdd945c  movaps [rsi], xmm8
00007588ecdd9460  movaps [rdx], xmm1
00007588ecdd9463  movaps [rcx], xmm13
00007588ecdd9467  mov rax, 0x6516BF3BBA50
00007588ecdd9471  call rax
00007588ecdd9473  movaps xmm10, [rsp]
00007588ecdd9478  add rsp, 0x40
00007588ecdd947c  vmovaps xmm0, [rsp]
00007588ecdd9481  vmovaps xmm1, [rsp+0x10]
00007588ecdd9487  vmovaps xmm2, [rsp+0x20]
00007588ecdd948d  vmovaps xmm3, [rsp+0x30]
00007588ecdd9493  vmovaps xmm4, [rsp+0x40]
00007588ecdd9499  vmovaps xmm5, [rsp+0x50]
00007588ecdd949f  vmovaps xmm6, [rsp+0x60]
00007588ecdd94a5  vmovaps xmm7, [rsp+0x70]
00007588ecdd94ab  vmovaps xmm8, [rsp+0x80]
00007588ecdd94b4  vmovaps xmm9, [rsp+0x90]
00007588ecdd94bd  vmovaps xmm11, [rsp+0xA0]
00007588ecdd94c6  vmovaps xmm12, [rsp+0xB0]
00007588ecdd94cf  vmovaps xmm13, [rsp+0xC0]
00007588ecdd94d8  vmovaps xmm14, [rsp+0xD0]
00007588ecdd94e1  vmovaps xmm15, [rsp+0xE0]
00007588ecdd94ea  add rsp, 0xF0
00007588ecdd94f1  pop r11
00007588ecdd94f3  pop r10
00007588ecdd94f5  pop r9
00007588ecdd94f7  pop r8
00007588ecdd94f9  pop rsi
00007588ecdd94fa  pop rdi
00007588ecdd94fb  pop rdx
00007588ecdd94fc  pop rcx
00007588ecdd94fd  pop rax
00007588ecdd94fe  add rsp, 0x08
00007588ecdd9502  jmp 0x00007588ECDD6C0F
00007588ecdd9507  call 0x00007588ECCD64F0
00007588ecdd950c  jmp 0x00007588ECDD6C21
00007588ecdd9511  sub rsp, 0x08
00007588ecdd9515  push rax
00007588ecdd9516  push rcx
00007588ecdd9517  push rdx
00007588ecdd9518  push rdi
00007588ecdd9519  push rsi
00007588ecdd951a  push r8
00007588ecdd951c  push r9
00007588ecdd951e  push r10
00007588ecdd9520  push r11
00007588ecdd9522  sub rsp, 0xF0
00007588ecdd9529  vmovaps [rsp], xmm0
00007588ecdd952e  vmovaps [rsp+0x10], xmm1
00007588ecdd9534  vmovaps [rsp+0x20], xmm2
00007588ecdd953a  vmovaps [rsp+0x30], xmm3
00007588ecdd9540  vmovaps [rsp+0x40], xmm4
00007588ecdd9546  vmovaps [rsp+0x50], xmm5
00007588ecdd954c  vmovaps [rsp+0x60], xmm6
00007588ecdd9552  vmovaps [rsp+0x70], xmm7
00007588ecdd9558  vmovaps [rsp+0x80], xmm8
00007588ecdd9561  vmovaps [rsp+0x90], xmm10
00007588ecdd956a  vmovaps [rsp+0xA0], xmm11
00007588ecdd9573  vmovaps [rsp+0xB0], xmm12
00007588ecdd957c  vmovaps [rsp+0xC0], xmm13
00007588ecdd9585  vmovaps [rsp+0xD0], xmm14
00007588ecdd958e  vmovaps [rsp+0xE0], xmm15
00007588ecdd9597  sub rsp, 0x40
00007588ecdd959b  lea rdi, [rsp]
00007588ecdd959f  lea rsi, [rsp+0x10]
00007588ecdd95a4  lea rdx, [rsp+0x20]
00007588ecdd95a9  lea rcx, [rsp+0x30]
00007588ecdd95ae  mov r8d, 0x00
00007588ecdd95b4  lea r9, [r15+0x3A8]
00007588ecdd95bb  movaps [rdi], xmm9
00007588ecdd95bf  movaps [rsi], xmm7
00007588ecdd95c2  movaps [rdx], xmm14
00007588ecdd95c6  movaps [rcx], xmm13
00007588ecdd95ca  mov rax, 0x6516BF3BBA50
00007588ecdd95d4  call rax
00007588ecdd95d6  movaps xmm9, [rsp]
00007588ecdd95db  add rsp, 0x40
00007588ecdd95df  vmovaps xmm0, [rsp]
00007588ecdd95e4  vmovaps xmm1, [rsp+0x10]
00007588ecdd95ea  vmovaps xmm2, [rsp+0x20]
00007588ecdd95f0  vmovaps xmm3, [rsp+0x30]
00007588ecdd95f6  vmovaps xmm4, [rsp+0x40]
00007588ecdd95fc  vmovaps xmm5, [rsp+0x50]
00007588ecdd9602  vmovaps xmm6, [rsp+0x60]
00007588ecdd9608  vmovaps xmm7, [rsp+0x70]
00007588ecdd960e  vmovaps xmm8, [rsp+0x80]
00007588ecdd9617  vmovaps xmm10, [rsp+0x90]
00007588ecdd9620  vmovaps xmm11, [rsp+0xA0]
00007588ecdd9629  vmovaps xmm12, [rsp+0xB0]
00007588ecdd9632  vmovaps xmm13, [rsp+0xC0]
00007588ecdd963b  vmovaps xmm14, [rsp+0xD0]
00007588ecdd9644  vmovaps xmm15, [rsp+0xE0]
00007588ecdd964d  add rsp, 0xF0
00007588ecdd9654  pop r11
00007588ecdd9656  pop r10
00007588ecdd9658  pop r9
00007588ecdd965a  pop r8
00007588ecdd965c  pop rsi
00007588ecdd965d  pop rdi
00007588ecdd965e  pop rdx
00007588ecdd965f  pop rcx
00007588ecdd9660  pop rax
00007588ecdd9661  add rsp, 0x08
00007588ecdd9665  jmp 0x00007588ECDD6C4F
00007588ecdd966a  sub rsp, 0x08
00007588ecdd966e  push rax
00007588ecdd966f  push rcx
00007588ecdd9670  push rdx
00007588ecdd9671  push rdi
00007588ecdd9672  push rsi
00007588ecdd9673  push r8
00007588ecdd9675  push r9
00007588ecdd9677  push r10
00007588ecdd9679  push r11
00007588ecdd967b  sub rsp, 0xF0
00007588ecdd9682  vmovaps [rsp], xmm0
00007588ecdd9687  vmovaps [rsp+0x10], xmm1
00007588ecdd968d  vmovaps [rsp+0x20], xmm2
00007588ecdd9693  vmovaps [rsp+0x30], xmm3
00007588ecdd9699  vmovaps [rsp+0x40], xmm4
00007588ecdd969f  vmovaps [rsp+0x50], xmm5
00007588ecdd96a5  vmovaps [rsp+0x60], xmm6
00007588ecdd96ab  vmovaps [rsp+0x70], xmm7
00007588ecdd96b1  vmovaps [rsp+0x80], xmm8
00007588ecdd96ba  vmovaps [rsp+0x90], xmm9
00007588ecdd96c3  vmovaps [rsp+0xA0], xmm10
00007588ecdd96cc  vmovaps [rsp+0xB0], xmm11
00007588ecdd96d5  vmovaps [rsp+0xC0], xmm12
00007588ecdd96de  vmovaps [rsp+0xD0], xmm14
00007588ecdd96e7  vmovaps [rsp+0xE0], xmm15
00007588ecdd96f0  sub rsp, 0x40
00007588ecdd96f4  lea rdi, [rsp]
00007588ecdd96f8  lea rsi, [rsp+0x10]
00007588ecdd96fd  lea rdx, [rsp+0x20]
00007588ecdd9702  lea rcx, [rsp+0x30]
00007588ecdd9707  mov r8d, 0x00
00007588ecdd970d  lea r9, [r15+0x3A8]
00007588ecdd9714  movaps [rdi], xmm13
00007588ecdd9718  movaps [rsi], xmm12
00007588ecdd971c  movaps [rdx], xmm15
00007588ecdd9720  movaps [rcx], xmm14
00007588ecdd9724  mov rax, 0x6516BF3BBA50
00007588ecdd972e  call rax
00007588ecdd9730  movaps xmm13, [rsp]
00007588ecdd9735  add rsp, 0x40
00007588ecdd9739  vmovaps xmm0, [rsp]
00007588ecdd973e  vmovaps xmm1, [rsp+0x10]
00007588ecdd9744  vmovaps xmm2, [rsp+0x20]
00007588ecdd974a  vmovaps xmm3, [rsp+0x30]
00007588ecdd9750  vmovaps xmm4, [rsp+0x40]
00007588ecdd9756  vmovaps xmm5, [rsp+0x50]
00007588ecdd975c  vmovaps xmm6, [rsp+0x60]
00007588ecdd9762  vmovaps xmm7, [rsp+0x70]
00007588ecdd9768  vmovaps xmm8, [rsp+0x80]
00007588ecdd9771  vmovaps xmm9, [rsp+0x90]
00007588ecdd977a  vmovaps xmm10, [rsp+0xA0]
00007588ecdd9783  vmovaps xmm11, [rsp+0xB0]
00007588ecdd978c  vmovaps xmm12, [rsp+0xC0]
00007588ecdd9795  vmovaps xmm14, [rsp+0xD0]
00007588ecdd979e  vmovaps xmm15, [rsp+0xE0]
00007588ecdd97a7  add rsp, 0xF0
00007588ecdd97ae  pop r11
00007588ecdd97b0  pop r10
00007588ecdd97b2  pop r9
00007588ecdd97b4  pop r8
00007588ecdd97b6  pop rsi
00007588ecdd97b7  pop rdi
00007588ecdd97b8  pop rdx
00007588ecdd97b9  pop rcx
00007588ecdd97ba  pop rax
00007588ecdd97bb  add rsp, 0x08
00007588ecdd97bf  jmp 0x00007588ECDD6C7D
00007588ecdd97c4  sub rsp, 0x08
00007588ecdd97c8  push rax
00007588ecdd97c9  push rcx
00007588ecdd97ca  push rdx
00007588ecdd97cb  push rdi
00007588ecdd97cc  push rsi
00007588ecdd97cd  push r8
00007588ecdd97cf  push r9
00007588ecdd97d1  push r10
00007588ecdd97d3  push r11
00007588ecdd97d5  sub rsp, 0xF0
00007588ecdd97dc  vmovaps [rsp], xmm0
00007588ecdd97e1  vmovaps [rsp+0x10], xmm1
00007588ecdd97e7  vmovaps [rsp+0x20], xmm2
00007588ecdd97ed  vmovaps [rsp+0x30], xmm3
00007588ecdd97f3  vmovaps [rsp+0x40], xmm4
00007588ecdd97f9  vmovaps [rsp+0x50], xmm5
00007588ecdd97ff  vmovaps [rsp+0x60], xmm6
00007588ecdd9805  vmovaps [rsp+0x70], xmm7
00007588ecdd980b  vmovaps [rsp+0x80], xmm8
00007588ecdd9814  vmovaps [rsp+0x90], xmm9
00007588ecdd981d  vmovaps [rsp+0xA0], xmm10
00007588ecdd9826  vmovaps [rsp+0xB0], xmm11
00007588ecdd982f  vmovaps [rsp+0xC0], xmm12
00007588ecdd9838  vmovaps [rsp+0xD0], xmm13
00007588ecdd9841  vmovaps [rsp+0xE0], xmm15
00007588ecdd984a  sub rsp, 0x40
00007588ecdd984e  lea rdi, [rsp]
00007588ecdd9852  lea rsi, [rsp+0x10]
00007588ecdd9857  lea rdx, [rsp+0x20]
00007588ecdd985c  lea rcx, [rsp+0x30]
00007588ecdd9861  mov r8d, 0x00
00007588ecdd9867  lea r9, [r15+0x3A8]
00007588ecdd986e  movaps [rdi], xmm14
00007588ecdd9872  movaps [rsi], xmm11
00007588ecdd9876  movaps [rdx], xmm1
00007588ecdd9879  movaps [rcx], xmm15
00007588ecdd987d  mov rax, 0x6516BF3BBA50
00007588ecdd9887  call rax
00007588ecdd9889  movaps xmm14, [rsp]
00007588ecdd988e  add rsp, 0x40
00007588ecdd9892  vmovaps xmm0, [rsp]
00007588ecdd9897  vmovaps xmm1, [rsp+0x10]
00007588ecdd989d  vmovaps xmm2, [rsp+0x20]
00007588ecdd98a3  vmovaps xmm3, [rsp+0x30]
00007588ecdd98a9  vmovaps xmm4, [rsp+0x40]
00007588ecdd98af  vmovaps xmm5, [rsp+0x50]
00007588ecdd98b5  vmovaps xmm6, [rsp+0x60]
00007588ecdd98bb  vmovaps xmm7, [rsp+0x70]
00007588ecdd98c1  vmovaps xmm8, [rsp+0x80]
00007588ecdd98ca  vmovaps xmm9, [rsp+0x90]
00007588ecdd98d3  vmovaps xmm10, [rsp+0xA0]
00007588ecdd98dc  vmovaps xmm11, [rsp+0xB0]
00007588ecdd98e5  vmovaps xmm12, [rsp+0xC0]
00007588ecdd98ee  vmovaps xmm13, [rsp+0xD0]
00007588ecdd98f7  vmovaps xmm15, [rsp+0xE0]
00007588ecdd9900  add rsp, 0xF0
00007588ecdd9907  pop r11
00007588ecdd9909  pop r10
00007588ecdd990b  pop r9
00007588ecdd990d  pop r8
00007588ecdd990f  pop rsi
00007588ecdd9910  pop rdi
00007588ecdd9911  pop rdx
00007588ecdd9912  pop rcx
00007588ecdd9913  pop rax
00007588ecdd9914  add rsp, 0x08
00007588ecdd9918  jmp 0x00007588ECDD6CAB
00007588ecdd991d  call 0x00007588ECCACF70
00007588ecdd9922  jmp 0x00007588ECDD6CB9
00007588ecdd9927  call 0x00007588ECC0C380
00007588ecdd992c  jmp 0x00007588ECDD6CC3
00007588ecdd9931  call 0x00007588ECC08C20
00007588ecdd9936  jmp 0x00007588ECDD6CCD
00007588ecdd993b  call 0x00007588ECC0D600
00007588ecdd9940  jmp 0x00007588ECDD6CD7
00007588ecdd9945  int3
00007588ecdd9946  nop [rax+rax*1], ax
00007588ecdd994f  nop
00007588ecdd9950  mov eax, [r15+0x48]
00007588ecdd9954  lea r14d, [eax+0x01]
00007588ecdd9959  mov [rsp+0x10], r14d
00007588ecdd995e  mov r14d, r14d
00007588ecdd9961  mov [r15+0x48], r14
00007588ecdd9965  xor eax, eax
00007588ecdd9967  mov r14d, [rsp+0x10]
00007588ecdd996c  cmp r14d, 0x1F4
00007588ecdd9973  cmc
00007588ecdd9974  lahf
00007588ecdd9975  seto al
00007588ecdd9978  mov [r15+0x108], eax
00007588ecdd997f  mov eax, [r15+0x108]
00007588ecdd9986  sahf
00007588ecdd9987  jnz 0x00007588ECDD99B9
00007588ecdd9989  cmp dword ptr [r15+0x318], 0x00
00007588ecdd9991  jz 0x00007588ECDDD2E0
00007588ecdd9997  nop [rax+rax*1], ax
00007588ecdd99a0  nop [rax+rax*1], eax
00007588ecdd99a8  mov eax, 0x410670
00007588ecdd99ad  mov [r15+0x100], rax
00007588ecdd99b4  jmp 0x00007588ECBFE110
00007588ecdd99b9  cmp dword ptr [r15+0x318], 0x00
00007588ecdd99c1  jz 0x00007588ECDD99F0
00007588ecdd99c7  nop [rax+rax*1], ax
00007588ecdd99d0  nop [rax+rax*1], eax
00007588ecdd99d8  mov eax, 0x4104EC
00007588ecdd99dd  mov [r15+0x100], rax
00007588ecdd99e4  jmp 0x00007588ECBFE110
00007588ecdd99e9  int3
00007588ecdd99ea  int3
00007588ecdd99eb  nop [rax+rax*1], eax
00007588ecdd99f0  mov rax, [r15+0x40]
00007588ecdd99f4  vxorps xmm1, xmm1, xmm1
00007588ecdd99f8  vpbroadcastq xmm1, xmm1
00007588ecdd99fd  vxorps xmm15, xmm15, xmm15
00007588ecdd9a02  vpbroadcastq xmm15, xmm15
00007588ecdd9a07  lea r14, [rax+0x30]
00007588ecdd9a0b  mov r12, [r13+r14*1]
00007588ecdd9a10  lea r14, [rax+0x38]
00007588ecdd9a14  mov r11, [r13+r14*1]
00007588ecdd9a19  movq xmm14, r12
00007588ecdd9a1e  movq xmm13, r11
00007588ecdd9a23  movq xmm14, xmm14
00007588ecdd9a28  movq xmm13, xmm13
00007588ecdd9a2d  vmovaps [rsp+0x10], xmm13
00007588ecdd9a33  movq xmm13, xmm13
00007588ecdd9a38  movaps [r15+0x270], xmm13
00007588ecdd9a40  movaps xmm13, [r15+0x160]
00007588ecdd9a48  vmovaps [rsp+0x20], xmm13
00007588ecdd9a4e  vmovaps xmm12, [rsp+0x20]
00007588ecdd9a54  por xmm13, xmm12
00007588ecdd9a59  lea r14, [rax+0x20]
00007588ecdd9a5d  mov r12, [r13+r14*1]
00007588ecdd9a62  lea r14, [rax+0x28]
00007588ecdd9a66  mov r11, [r13+r14*1]
00007588ecdd9a6b  movq xmm12, r12
00007588ecdd9a70  movq xmm11, r11
00007588ecdd9a75  movq xmm12, xmm12
00007588ecdd9a7a  movq xmm11, xmm11
00007588ecdd9a7f  movaps xmm10, [r15+0x2D0]
00007588ecdd9a87  vmovaps [rsp+0x20], xmm10
00007588ecdd9a8d  vmovaps xmm9, [rsp+0x20]
00007588ecdd9a93  por xmm10, xmm9
00007588ecdd9a98  movaps xmm9, [r15+0x300]
00007588ecdd9aa0  vmovaps [rsp+0x20], xmm9
00007588ecdd9aa6  vmovaps xmm8, [rsp+0x20]
00007588ecdd9aac  por xmm9, xmm8
00007588ecdd9ab1  movaps xmm8, [r15+0x2B0]
00007588ecdd9ab9  vmovaps [rsp+0x20], xmm8
00007588ecdd9abf  vmovaps xmm7, [rsp+0x20]
00007588ecdd9ac5  por xmm8, xmm7
00007588ecdd9aca  movaps xmm7, [r15+0x180]
00007588ecdd9ad2  vmovaps [rsp+0x20], xmm7
00007588ecdd9ad8  vmovaps xmm6, [rsp+0x20]
00007588ecdd9ade  por xmm7, xmm6
00007588ecdd9ae2  lea r14, [rax+0x10]
00007588ecdd9ae6  mov r12, [r13+r14*1]
00007588ecdd9aeb  lea r14, [rax+0x18]
00007588ecdd9aef  mov r11, [r13+r14*1]
00007588ecdd9af4  movq xmm6, r12
00007588ecdd9af9  movq xmm5, r11
00007588ecdd9afe  movq xmm6, xmm6
00007588ecdd9b02  movq xmm5, xmm5
00007588ecdd9b06  movaps xmm4, [r15+0x200]
00007588ecdd9b0e  vmovaps [rsp+0x20], xmm4
00007588ecdd9b14  vmovaps xmm3, [rsp+0x20]
00007588ecdd9b1a  por xmm4, xmm3
00007588ecdd9b1e  movaps xmm3, [r15+0x1F0]
00007588ecdd9b26  vmovaps [rsp+0x20], xmm3
00007588ecdd9b2c  vmovaps xmm2, [rsp+0x20]
00007588ecdd9b32  por xmm3, xmm2
00007588ecdd9b36  movaps xmm2, [r15+0x2E0]
00007588ecdd9b3e  vmovaps [rsp+0x20], xmm2
00007588ecdd9b44  vmovaps [rsp+0x30], xmm1
00007588ecdd9b4a  vmovaps xmm1, [rsp+0x20]
00007588ecdd9b50  por xmm2, xmm1
00007588ecdd9b54  movaps xmm1, [r15+0x2A0]
00007588ecdd9b5c  vmovaps [rsp+0x20], xmm1
00007588ecdd9b62  vmovaps [rsp+0x40], xmm15
00007588ecdd9b68  vmovaps xmm15, [rsp+0x20]
00007588ecdd9b6e  por xmm1, xmm15
00007588ecdd9b73  movaps xmm15, [r15+0x280]
00007588ecdd9b7b  vmovaps [rsp+0x20], xmm15
00007588ecdd9b81  vmovaps [rsp+0x50], xmm1
00007588ecdd9b87  vmovaps xmm1, [rsp+0x20]
00007588ecdd9b8d  por xmm15, xmm1
00007588ecdd9b92  movaps xmm1, [r15+0x1C0]
00007588ecdd9b9a  vmovaps [rsp+0x20], xmm1
00007588ecdd9ba0  vmovaps [rsp+0x60], xmm15
00007588ecdd9ba6  vmovaps xmm15, [rsp+0x20]
00007588ecdd9bac  por xmm1, xmm15
00007588ecdd9bb1  movaps xmm15, [r15+0x210]
00007588ecdd9bb9  vmovaps [rsp+0x20], xmm15
00007588ecdd9bbf  vmovaps [rsp+0x70], xmm1
00007588ecdd9bc5  vmovaps xmm1, [rsp+0x20]
00007588ecdd9bcb  por xmm15, xmm1
00007588ecdd9bd0  mov r14, [r13+rax*1]
00007588ecdd9bd5  vmovq xmm1, r14
00007588ecdd9bda  vpbroadcastq xmm1, xmm1
00007588ecdd9bdf  vmovaps [rsp+0x20], xmm1
00007588ecdd9be5  vxorps xmm1, xmm1, xmm1
00007588ecdd9be9  vpbroadcastq xmm1, xmm1
00007588ecdd9bee  mov r14, [r15+0xF8]
00007588ecdd9bf5  vmovaps [rsp+0x80], xmm1
00007588ecdd9bfe  movups xmm1, [r13+r14*1]
00007588ecdd9c04  vmovaps [rsp+0x90], xmm1
00007588ecdd9c0d  vxorps xmm1, xmm1, xmm1
00007588ecdd9c11  vpbroadcastq xmm1, xmm1
00007588ecdd9c16  lea r12, [rax+0x08]
00007588ecdd9c1a  mov rax, [r13+r12*1]
00007588ecdd9c1f  vmovaps [rsp+0xA0], xmm1
00007588ecdd9c28  movq xmm1, rax
00007588ecdd9c2d  movaps [r15+0x240], xmm1
00007588ecdd9c35  mov rax, [r15+0x50]
00007588ecdd9c39  mov [r15+0x60], rax
00007588ecdd9c3d  mov qword ptr [r15+0x58], 0x40
00007588ecdd9c45  vmovaps xmm1, [rsp+0x30]
00007588ecdd9c4b  vmovaps [rsp+0x30], xmm15
00007588ecdd9c51  vmovaps xmm15, [rsp+0x90]
00007588ecdd9c5a  vmovaps [rsp+0x90], xmm14
00007588ecdd9c63  vmovaps xmm14, [rsp+0x20]
00007588ecdd9c69  vmovaps [rsp+0x20], xmm13
00007588ecdd9c6f  vmovaps [rsp+0xB0], xmm12
00007588ecdd9c78  movaps xmm13, xmm1
00007588ecdd9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd9c87  vptest xmm12, xmm12
00007588ecdd9c8c  jnz 0x00007588ECDDA72F
00007588ecdd9c92  movaps xmm1, [r15+0x250]
00007588ecdd9c9a  vmovaps xmm15, [rsp+0x40]
00007588ecdd9ca0  vmovaps [rsp+0x40], xmm13
00007588ecdd9ca6  movaps xmm12, xmm15
00007588ecdd9caa  vfmadd231pd xmm12, xmm1, xmm14
00007588ecdd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007588ecdd9cb5  vptest xmm13, xmm13
00007588ecdd9cba  jnz 0x00007588ECDDA888
00007588ecdd9cc0  movaps xmm15, [r15+0x1E0]
00007588ecdd9cc8  vmovaps [rsp+0xC0], xmm15
00007588ecdd9cd1  vmovaps xmm13, [rsp+0xC0]
00007588ecdd9cda  por xmm15, xmm13
00007588ecdd9cdf  movaps xmm13, [r15+0x1D0]
00007588ecdd9ce7  vmovaps [rsp+0xC0], xmm13
00007588ecdd9cf0  vmovaps [rsp+0xD0], xmm1
00007588ecdd9cf9  vmovaps xmm1, [rsp+0xC0]
00007588ecdd9d02  por xmm13, xmm1
00007588ecdd9d07  movaps xmm1, [r15+0x2C0]
00007588ecdd9d0f  vmovaps [rsp+0xC0], xmm1
00007588ecdd9d18  vmovaps [rsp+0xE0], xmm15
00007588ecdd9d21  vmovaps xmm15, [rsp+0xC0]
00007588ecdd9d2a  por xmm1, xmm15
00007588ecdd9d2f  movaps xmm15, [r15+0x290]
00007588ecdd9d37  vmovaps [rsp+0xC0], xmm15
00007588ecdd9d40  vmovaps [rsp+0xF0], xmm1
00007588ecdd9d49  vmovaps xmm1, [rsp+0xC0]
00007588ecdd9d52  por xmm15, xmm1
00007588ecdd9d57  movaps xmm1, [r15+0x260]
00007588ecdd9d5f  vmovaps [rsp+0xC0], xmm1
00007588ecdd9d68  vmovaps [rsp+0x100], xmm15
00007588ecdd9d71  vmovaps xmm15, [rsp+0xC0]
00007588ecdd9d7a  por xmm1, xmm15
00007588ecdd9d7f  vmovaps xmm15, [rsp+0xD0]
00007588ecdd9d88  vmovaps [rsp+0xC0], xmm1
00007588ecdd9d91  vmovaps xmm1, [rsp+0xD0]
00007588ecdd9d9a  por xmm15, xmm1
00007588ecdd9d9f  lea r12, [r14+0xC0]
00007588ecdd9da6  movups xmm1, [r13+r12*1]
00007588ecdd9dac  mov [rsp+0xD0], rax
00007588ecdd9db4  xor eax, eax
00007588ecdd9db6  mov r12d, 0x40
00007588ecdd9dbc  mov r11d, 0x200
00007588ecdd9dc2  cmp r12, r11
00007588ecdd9dc5  cmc
00007588ecdd9dc6  lahf
00007588ecdd9dc7  seto al
00007588ecdd9dca  mov [r15+0x108], eax
00007588ecdd9dd1  vmovaps [rsp+0x110], xmm1
00007588ecdd9dda  vmovaps xmm1, [rsp+0x80]
00007588ecdd9de3  vmovaps [rsp+0x80], xmm15
00007588ecdd9dec  vmovaps xmm15, [rsp+0x110]
00007588ecdd9df5  vmovaps [rsp+0x110], xmm13
00007588ecdd9dfe  vmovaps [rsp+0x120], xmm12
00007588ecdd9e07  movaps xmm13, xmm1
00007588ecdd9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd9e16  vptest xmm12, xmm12
00007588ecdd9e1b  jnz 0x00007588ECDDA9EB
00007588ecdd9e21  lea rax, [r14+0xB0]
00007588ecdd9e28  movups xmm1, [r13+rax*1]
00007588ecdd9e2e  vmovaps xmm15, [rsp+0xA0]
00007588ecdd9e37  vmovaps [rsp+0xA0], xmm13
00007588ecdd9e40  movaps xmm12, xmm15
00007588ecdd9e44  vfmadd231pd xmm12, xmm1, xmm14
00007588ecdd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007588ecdd9e4f  vptest xmm13, xmm13
00007588ecdd9e54  jnz 0x00007588ECDDAB4E
00007588ecdd9e5a  vmovaps xmm1, [rsp+0x30]
00007588ecdd9e60  vmovaps xmm15, [rsp+0x30]
00007588ecdd9e66  por xmm1, xmm15
00007588ecdd9e6b  movaps [r15+0x210], xmm1
00007588ecdd9e73  vmovaps xmm15, [rsp+0x70]
00007588ecdd9e79  vmovaps xmm14, [rsp+0x70]
00007588ecdd9e7f  por xmm15, xmm14
00007588ecdd9e84  movaps [r15+0x1C0], xmm15
00007588ecdd9e8c  vmovaps xmm14, [rsp+0x60]
00007588ecdd9e92  vmovaps xmm13, [rsp+0x60]
00007588ecdd9e98  por xmm14, xmm13
00007588ecdd9e9d  movaps [r15+0x280], xmm14
00007588ecdd9ea5  vmovaps xmm13, [rsp+0x50]
00007588ecdd9eab  vmovaps [rsp+0x30], xmm1
00007588ecdd9eb1  vmovaps xmm1, [rsp+0x50]
00007588ecdd9eb7  por xmm13, xmm1
00007588ecdd9ebc  movaps [r15+0x2A0], xmm13
00007588ecdd9ec4  vmovaps [rsp+0x50], xmm2
00007588ecdd9eca  vmovaps xmm1, [rsp+0x50]
00007588ecdd9ed0  por xmm2, xmm1
00007588ecdd9ed4  movaps [r15+0x2E0], xmm2
00007588ecdd9edc  vmovaps [rsp+0x50], xmm3
00007588ecdd9ee2  vmovaps xmm1, [rsp+0x50]
00007588ecdd9ee8  por xmm3, xmm1
00007588ecdd9eec  movaps [r15+0x1F0], xmm3
00007588ecdd9ef4  vmovaps xmm1, [rsp+0x80]
00007588ecdd9efd  vmovaps [rsp+0x50], xmm15
00007588ecdd9f03  vmovaps xmm15, [rsp+0x80]
00007588ecdd9f0c  por xmm1, xmm15
00007588ecdd9f11  movaps [r15+0x250], xmm1
00007588ecdd9f19  vmovaps xmm1, [rsp+0xC0]
00007588ecdd9f22  vmovaps xmm15, [rsp+0xC0]
00007588ecdd9f2b  por xmm1, xmm15
00007588ecdd9f30  movaps [r15+0x260], xmm1
00007588ecdd9f38  vmovaps xmm15, [rsp+0x100]
00007588ecdd9f41  vmovaps [rsp+0x60], xmm1
00007588ecdd9f47  vmovaps xmm1, [rsp+0x100]
00007588ecdd9f50  por xmm15, xmm1
00007588ecdd9f55  movaps [r15+0x290], xmm15
00007588ecdd9f5d  vmovaps xmm1, [rsp+0xF0]
00007588ecdd9f66  vmovaps [rsp+0x70], xmm15
00007588ecdd9f6c  vmovaps xmm15, [rsp+0xF0]
00007588ecdd9f75  por xmm1, xmm15
00007588ecdd9f7a  movaps [r15+0x2C0], xmm1
00007588ecdd9f82  movq xmm15, qword ptr [r15+0x240]
00007588ecdd9f8b  vmovaps [rsp+0x80], xmm15
00007588ecdd9f94  vpermilpd xmm15, xmm15, 0x00
00007588ecdd9f9a  vmovaps [rsp+0xC0], xmm1
00007588ecdd9fa3  vmovaps xmm1, [rsp+0x40]
00007588ecdd9fa9  vmovaps [rsp+0x40], xmm15
00007588ecdd9faf  vmovaps xmm15, [rsp+0x30]
00007588ecdd9fb5  vmovaps [rsp+0x30], xmm14
00007588ecdd9fbb  vmovaps xmm14, [rsp+0x40]
00007588ecdd9fc1  vmovaps [rsp+0x40], xmm13
00007588ecdd9fc7  vmovaps [rsp+0xF0], xmm12
00007588ecdd9fd0  movaps xmm13, xmm1
00007588ecdd9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007588ecdd9fdf  vptest xmm12, xmm12
00007588ecdd9fe4  jnz 0x00007588ECDDACA7
00007588ecdd9fea  vmovaps xmm1, [rsp+0x80]
00007588ecdd9ff3  vpermilpd xmm1, xmm1, 0x00
00007588ecdd9ff9  vmovaps xmm15, [rsp+0xA0]
00007588ecdda002  movaps xmm14, xmm15
00007588ecdda006  vfmadd231pd xmm14, xmm2, xmm1
00007588ecdda00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007588ecdda011  vptest xmm12, xmm12
00007588ecdda016  jnz 0x00007588ECDDAE00
00007588ecdda01c  vmovaps xmm1, [rsp+0x80]
00007588ecdda025  vpermilpd xmm1, xmm1, 0x00
00007588ecdda02b  vmovaps xmm15, [rsp+0x120]
00007588ecdda034  vmovaps xmm12, [rsp+0x50]
00007588ecdda03a  vmovaps [rsp+0x50], xmm14
00007588ecdda040  movaps xmm2, xmm15
00007588ecdda044  vfmadd231pd xmm2, xmm12, xmm1
00007588ecdda049  vcmppd xmm14, xmm2, xmm2, 0x03
00007588ecdda04e  vptest xmm14, xmm14
00007588ecdda053  jnz 0x00007588ECDDAF58
00007588ecdda059  vmovaps xmm1, [rsp+0x110]
00007588ecdda062  vmovaps xmm15, [rsp+0x110]
00007588ecdda06b  por xmm1, xmm15
00007588ecdda070  movaps [r15+0x1D0], xmm1
00007588ecdda078  vmovaps xmm15, [rsp+0x80]
00007588ecdda081  vpermilpd xmm15, xmm15, 0x00
00007588ecdda087  vmovaps xmm14, [rsp+0xF0]
00007588ecdda090  vmovaps [rsp+0x80], xmm1
00007588ecdda099  movaps xmm12, xmm14
00007588ecdda09d  vfmadd231pd xmm12, xmm3, xmm15
00007588ecdda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007588ecdda0a8  vptest xmm1, xmm1
00007588ecdda0ad  jnz 0x00007588ECDDB0AF
00007588ecdda0b3  vmovaps [rsp+0xA0], xmm4
00007588ecdda0bc  vmovaps xmm1, [rsp+0xA0]
00007588ecdda0c5  por xmm4, xmm1
00007588ecdda0c9  movaps [r15+0x200], xmm4
00007588ecdda0d1  vmovaps xmm1, [rsp+0xE0]
00007588ecdda0da  vmovaps xmm15, [rsp+0xE0]
00007588ecdda0e3  por xmm1, xmm15
00007588ecdda0e8  movaps [r15+0x1E0], xmm1
00007588ecdda0f0  vmovaps [rsp+0xA0], xmm8
00007588ecdda0f9  vmovaps xmm1, [rsp+0xA0]
00007588ecdda102  por xmm8, xmm1
00007588ecdda107  movaps [r15+0x2B0], xmm8
00007588ecdda10f  vmovaps [rsp+0xA0], xmm9
00007588ecdda118  vmovaps xmm1, [rsp+0xA0]
00007588ecdda121  por xmm9, xmm1
00007588ecdda126  movaps [r15+0x300], xmm9
00007588ecdda12e  vmovaps [rsp+0xA0], xmm6
00007588ecdda137  vpermilpd xmm6, xmm6, 0x00
00007588ecdda13d  vmovaps xmm14, [rsp+0x60]
00007588ecdda143  movaps xmm9, xmm13
00007588ecdda147  vfmadd231pd xmm9, xmm14, xmm6
00007588ecdda14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007588ecdda152  vptest xmm3, xmm3
00007588ecdda157  jnz 0x00007588ECDDB208
00007588ecdda15d  vmovaps xmm14, [rsp+0xA0]
00007588ecdda166  vpermilpd xmm14, xmm14, 0x00
00007588ecdda16c  vmovaps xmm13, [rsp+0x50]
00007588ecdda172  vmovaps xmm6, [rsp+0xC0]
00007588ecdda17b  vmovaps [rsp+0x50], xmm1
00007588ecdda181  movaps xmm3, xmm13
00007588ecdda185  vfmadd231pd xmm3, xmm6, xmm14
00007588ecdda18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007588ecdda18f  vptest xmm1, xmm1
00007588ecdda194  jnz 0x00007588ECDDB361
00007588ecdda19a  vmovaps xmm1, [rsp+0xA0]
00007588ecdda1a3  vpermilpd xmm1, xmm1, 0x00
00007588ecdda1a9  vmovaps xmm14, [rsp+0x30]
00007588ecdda1af  movaps xmm6, xmm2
00007588ecdda1b2  vfmadd231pd xmm6, xmm14, xmm1
00007588ecdda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007588ecdda1bc  vptest xmm13, xmm13
00007588ecdda1c1  jnz 0x00007588ECDDB4B8
00007588ecdda1c7  vmovaps xmm1, [rsp+0xA0]
00007588ecdda1d0  vpermilpd xmm1, xmm1, 0x00
00007588ecdda1d6  vmovaps xmm14, [rsp+0x80]
00007588ecdda1df  movaps xmm13, xmm12
00007588ecdda1e3  vfmadd231pd xmm13, xmm14, xmm1
00007588ecdda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007588ecdda1ee  vptest xmm2, xmm2
00007588ecdda1f3  jnz 0x00007588ECDDB60E
00007588ecdda1f9  vmovaps [rsp+0x30], xmm7
00007588ecdda1ff  vmovaps xmm1, [rsp+0x30]
00007588ecdda205  por xmm7, xmm1
00007588ecdda209  movaps [r15+0x180], xmm7
00007588ecdda211  vmovaps [rsp+0x30], xmm10
00007588ecdda217  vmovaps xmm1, [rsp+0x30]
00007588ecdda21d  por xmm10, xmm1
00007588ecdda222  movaps [r15+0x2D0], xmm10
00007588ecdda22a  vmovaps [rsp+0x30], xmm5
00007588ecdda230  vpermilpd xmm5, xmm5, 0x00
00007588ecdda236  vmovaps xmm14, [rsp+0x50]
00007588ecdda23c  movaps xmm12, xmm3
00007588ecdda240  vfmadd231pd xmm12, xmm14, xmm5
00007588ecdda245  vcmppd xmm10, xmm12, xmm12, 0x03
00007588ecdda24b  vptest xmm10, xmm10
00007588ecdda250  jnz 0x00007588ECDDB767
00007588ecdda256  vmovaps xmm14, [rsp+0x30]
00007588ecdda25c  vpermilpd xmm14, xmm14, 0x00
00007588ecdda262  movaps xmm10, xmm9
00007588ecdda266  vfmadd231pd xmm10, xmm7, xmm14
00007588ecdda26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007588ecdda271  vptest xmm5, xmm5
00007588ecdda276  jnz 0x00007588ECDDB8BF
00007588ecdda27c  lea rax, [r14+0x80]
00007588ecdda283  movups xmm14, [r13+rax*1]
00007588ecdda289  movaps [r15+0x2F0], xmm14
00007588ecdda291  vmovaps xmm9, [rsp+0x30]
00007588ecdda297  vpermilpd xmm9, xmm9, 0x00
00007588ecdda29d  vmovaps xmm7, [rsp+0x70]
00007588ecdda2a3  movaps xmm5, xmm6
00007588ecdda2a6  vfmadd231pd xmm5, xmm7, xmm9
00007588ecdda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007588ecdda2b0  vptest xmm3, xmm3
00007588ecdda2b5  jnz 0x00007588ECDDBA22
00007588ecdda2bb  vmovaps xmm9, [rsp+0x30]
00007588ecdda2c1  vpermilpd xmm9, xmm9, 0x00
00007588ecdda2c7  movaps xmm7, xmm13
00007588ecdda2cb  vfmadd231pd xmm7, xmm1, xmm9
00007588ecdda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007588ecdda2d5  vptest xmm6, xmm6
00007588ecdda2da  jnz 0x00007588ECDDBB78
00007588ecdda2e0  vmovaps xmm1, [rsp+0x20]
00007588ecdda2e6  vmovaps xmm13, [rsp+0x20]
00007588ecdda2ec  por xmm1, xmm13
00007588ecdda2f1  movaps [r15+0x160], xmm1
00007588ecdda2f9  lea rax, [r14+0x40]
00007588ecdda2fd  movups xmm13, [r13+rax*1]
00007588ecdda303  lea rax, [r14+0x50]
00007588ecdda307  movups xmm9, [r13+rax*1]
00007588ecdda30d  movaps [r15+0x1B0], xmm13
00007588ecdda315  movaps [r15+0x1A0], xmm9
00007588ecdda31d  movaps xmm6, [r15+0x190]
00007588ecdda325  vmovaps xmm3, [rsp+0xB0]
00007588ecdda32e  vpermilpd xmm3, xmm3, 0x00
00007588ecdda334  vmovaps [rsp+0x20], xmm1
00007588ecdda33a  movaps xmm2, xmm12
00007588ecdda33e  vfmadd231pd xmm2, xmm6, xmm3
00007588ecdda343  vcmppd xmm1, xmm2, xmm2, 0x03
00007588ecdda348  vptest xmm1, xmm1
00007588ecdda34d  jnz 0x00007588ECDDBCE3
00007588ecdda353  vmovaps xmm1, [rsp+0xB0]
00007588ecdda35c  vpermilpd xmm1, xmm1, 0x00
00007588ecdda362  vmovaps xmm12, [rsp+0x20]
00007588ecdda368  movaps xmm6, xmm10
00007588ecdda36c  vfmadd231pd xmm6, xmm12, xmm1
00007588ecdda371  vcmppd xmm3, xmm6, xmm6, 0x03
00007588ecdda376  vptest xmm3, xmm3
00007588ecdda37b  jnz 0x00007588ECDDBE39
00007588ecdda381  vmovaps xmm1, [rsp+0xB0]
00007588ecdda38a  vpermilpd xmm1, xmm1, 0x00
00007588ecdda390  vmovaps xmm12, [rsp+0x40]
00007588ecdda396  movaps xmm10, xmm5
00007588ecdda39a  vfmadd231pd xmm10, xmm12, xmm1
00007588ecdda39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007588ecdda3a5  vptest xmm3, xmm3
00007588ecdda3aa  jnz 0x00007588ECDDBF90
00007588ecdda3b0  vmovaps xmm1, [rsp+0xB0]
00007588ecdda3b9  vpermilpd xmm1, xmm1, 0x00
00007588ecdda3bf  movaps xmm12, xmm7
00007588ecdda3c3  vfmadd231pd xmm12, xmm15, xmm1
00007588ecdda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007588ecdda3ce  vptest xmm5, xmm5
00007588ecdda3d3  jnz 0x00007588ECDDC0E8
00007588ecdda3d9  lea rax, [r14+0x60]
00007588ecdda3dd  movups xmm1, [r13+rax*1]
00007588ecdda3e3  lea rax, [r14+0x70]
00007588ecdda3e7  movups xmm15, [r13+rax*1]
00007588ecdda3ed  movaps [r15+0x150], xmm1
00007588ecdda3f5  movaps [r15+0x120], xmm15
00007588ecdda3fd  vmovaps [rsp+0x20], xmm11
00007588ecdda403  vpermilpd xmm11, xmm11, 0x00
00007588ecdda409  movaps xmm7, xmm2
00007588ecdda40c  vfmadd231pd xmm7, xmm9, xmm11
00007588ecdda411  vcmppd xmm5, xmm7, xmm7, 0x03
00007588ecdda416  vptest xmm5, xmm5
00007588ecdda41b  jnz 0x00007588ECDDC254
00007588ecdda421  vmovaps xmm11, [rsp+0x20]
00007588ecdda427  vpermilpd xmm11, xmm11, 0x00
00007588ecdda42d  movaps xmm9, xmm6
00007588ecdda431  vfmadd231pd xmm9, xmm1, xmm11
00007588ecdda436  vcmppd xmm5, xmm9, xmm9, 0x03
00007588ecdda43c  vptest xmm5, xmm5
00007588ecdda441  jnz 0x00007588ECDDC3AB
00007588ecdda447  vmovaps xmm1, [rsp+0x20]
00007588ecdda44d  vpermilpd xmm1, xmm1, 0x00
00007588ecdda453  movaps xmm11, xmm10
00007588ecdda457  vfmadd231pd xmm11, xmm8, xmm1
00007588ecdda45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007588ecdda462  vptest xmm6, xmm6
00007588ecdda467  jnz 0x00007588ECDDC503
00007588ecdda46d  vmovaps xmm1, [rsp+0x20]
00007588ecdda473  vpermilpd xmm1, xmm1, 0x00
00007588ecdda479  movaps xmm10, xmm12
00007588ecdda47d  vfmadd231pd xmm10, xmm13, xmm1
00007588ecdda482  vcmppd xmm8, xmm10, xmm10, 0x03
00007588ecdda488  vptest xmm8, xmm8
00007588ecdda48d  jnz 0x00007588ECDDC65C
00007588ecdda493  lea rax, [r14+0x20]
00007588ecdda497  movups xmm1, [r13+rax*1]
00007588ecdda49d  lea rax, [r14+0x30]
00007588ecdda4a1  movups xmm13, [r13+rax*1]
00007588ecdda4a7  vmovaps xmm12, [rsp+0x90]
00007588ecdda4b0  vpermilpd xmm12, xmm12, 0x00
00007588ecdda4b6  movaps xmm8, xmm7
00007588ecdda4ba  vfmadd231pd xmm8, xmm4, xmm12
00007588ecdda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007588ecdda4c5  vptest xmm6, xmm6
00007588ecdda4ca  jnz 0x00007588ECDDC7C9
00007588ecdda4d0  vmovaps xmm12, [rsp+0x90]
00007588ecdda4d9  vpermilpd xmm12, xmm12, 0x00
00007588ecdda4df  movaps xmm7, xmm9
00007588ecdda4e3  vfmadd231pd xmm7, xmm14, xmm12
00007588ecdda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007588ecdda4ed  vptest xmm6, xmm6
00007588ecdda4f2  jnz 0x00007588ECDDC921
00007588ecdda4f8  vmovaps xmm14, [rsp+0x90]
00007588ecdda501  vpermilpd xmm14, xmm14, 0x00
00007588ecdda507  movaps xmm12, xmm11
00007588ecdda50b  vfmadd231pd xmm12, xmm15, xmm14
00007588ecdda510  vcmppd xmm9, xmm12, xmm12, 0x03
00007588ecdda516  vptest xmm9, xmm9
00007588ecdda51b  jnz 0x00007588ECDDCA79
00007588ecdda521  vmovaps xmm15, [rsp+0x90]
00007588ecdda52a  vpermilpd xmm15, xmm15, 0x00
00007588ecdda530  movaps xmm11, xmm10
00007588ecdda534  vfmadd231pd xmm11, xmm13, xmm15
00007588ecdda539  vcmppd xmm14, xmm11, xmm11, 0x03
00007588ecdda53f  vptest xmm14, xmm14
00007588ecdda544  jnz 0x00007588ECDDCBD3
00007588ecdda54a  lea rax, [r14+0x90]
00007588ecdda551  movups xmm15, [r13+rax*1]
00007588ecdda557  lea rax, [r14+0xA0]
00007588ecdda55e  movups xmm14, [r13+rax*1]
00007588ecdda564  movaps [r15+0x140], xmm15
00007588ecdda56c  movaps [r15+0x130], xmm14
00007588ecdda574  vmovaps xmm13, [rsp+0x10]
00007588ecdda57a  vpermilpd xmm13, xmm13, 0x00
00007588ecdda580  movaps xmm10, xmm8
00007588ecdda584  vfmadd231pd xmm10, xmm1, xmm13
00007588ecdda589  vcmppd xmm9, xmm10, xmm10, 0x03
00007588ecdda58f  vptest xmm9, xmm9
00007588ecdda594  jnz 0x00007588ECDDCD41
00007588ecdda59a  movaps [r15+0x220], xmm10
00007588ecdda5a2  lea rax, [r14+0x10]
00007588ecdda5a6  movups xmm1, [r13+rax*1]
00007588ecdda5ac  movaps [r15+0x240], xmm1
00007588ecdda5b4  vmovaps xmm13, [rsp+0x10]
00007588ecdda5ba  vpermilpd xmm13, xmm13, 0x00
00007588ecdda5c0  movaps xmm9, xmm7
00007588ecdda5c4  vfmadd231pd xmm9, xmm14, xmm13
00007588ecdda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007588ecdda5cf  vptest xmm8, xmm8
00007588ecdda5d4  jnz 0x00007588ECDDCEA4
00007588ecdda5da  movaps [r15+0x110], xmm9
00007588ecdda5e2  vmovaps xmm14, [rsp+0x10]
00007588ecdda5e8  vpermilpd xmm14, xmm14, 0x00
00007588ecdda5ee  movaps xmm13, xmm12
00007588ecdda5f2  vfmadd231pd xmm13, xmm15, xmm14
00007588ecdda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007588ecdda5fd  vptest xmm8, xmm8
00007588ecdda602  jnz 0x00007588ECDDCFFD
00007588ecdda608  movaps [r15+0x170], xmm13
00007588ecdda610  vmovaps xmm15, [rsp+0x10]
00007588ecdda616  vpermilpd xmm15, xmm15, 0x00
00007588ecdda61c  movaps xmm14, xmm11
00007588ecdda620  vfmadd231pd xmm14, xmm1, xmm15
00007588ecdda625  vcmppd xmm12, xmm14, xmm14, 0x03
00007588ecdda62b  vptest xmm12, xmm12
00007588ecdda630  jnz 0x00007588ECDDD157
00007588ecdda636  movaps [r15+0x230], xmm14
00007588ecdda63e  mov rax, [rsp+0xD0]
00007588ecdda646  movups [r13+rax*1], xmm9
00007588ecdda64c  lea r14, [rax+0x10]
00007588ecdda650  movups [r13+r14*1], xmm13
00007588ecdda656  lea r14, [rax+0x20]
00007588ecdda65a  movups [r13+r14*1], xmm10
00007588ecdda660  lea r14, [rax+0x30]
00007588ecdda664  movups [r13+r14*1], xmm14
00007588ecdda66a  mov eax, [r15+0x108]
00007588ecdda671  sahf
00007588ecdda672  jnz 0x00007588ECDDA6A4
00007588ecdda674  cmp dword ptr [r15+0x318], 0x00
00007588ecdda67c  jz 0x00007588ECDD9950
00007588ecdda682  nop [rax+rax*1], ax
00007588ecdda68b  nop [rax+rax*1], eax
00007588ecdda693  mov eax, 0x410664
00007588ecdda698  mov [r15+0x100], rax
00007588ecdda69f  jmp 0x00007588ECBFE110
00007588ecdda6a4  cmp dword ptr [r15+0x318], 0x00
00007588ecdda6ac  jz 0x00007588ECDD6050
00007588ecdda6b2  nop [rax+rax*1], ax
00007588ecdda6bb  nop [rax+rax*1], eax
00007588ecdda6c3  mov eax, 0x4104F0
00007588ecdda6c8  mov [r15+0x100], rax
00007588ecdda6cf  jmp 0x00007588ECBFE110
00007588ecdda6d4  int3
00007588ecdda6d5  call 0x00007588ECCE27E0
00007588ecdda6da  jmp 0x00007588ECDD9A10
00007588ecdda6df  call 0x00007588ECCE1570
00007588ecdda6e4  jmp 0x00007588ECDD9A19
00007588ecdda6e9  call 0x00007588ECCE27E0
00007588ecdda6ee  jmp 0x00007588ECDD9A62
00007588ecdda6f3  call 0x00007588ECCE1570
00007588ecdda6f8  jmp 0x00007588ECDD9A6B
00007588ecdda6fd  call 0x00007588ECCE27E0
00007588ecdda702  jmp 0x00007588ECDD9AEB
00007588ecdda707  call 0x00007588ECCE1570
00007588ecdda70c  jmp 0x00007588ECDD9AF4
00007588ecdda711  call 0x00007588ECC0DC20
00007588ecdda716  jmp 0x00007588ECDD9BD5
00007588ecdda71b  call 0x00007588ECCD64F0
00007588ecdda720  jmp 0x00007588ECDD9C04
00007588ecdda725  call 0x00007588ECCB47C0
00007588ecdda72a  jmp 0x00007588ECDD9C1F
00007588ecdda72f  sub rsp, 0x08
00007588ecdda733  push rax
00007588ecdda734  push rcx
00007588ecdda735  push rdx
00007588ecdda736  push rdi
00007588ecdda737  push rsi
00007588ecdda738  push r8
00007588ecdda73a  push r9
00007588ecdda73c  push r10
00007588ecdda73e  push r11
00007588ecdda740  sub rsp, 0xF0
00007588ecdda747  vmovaps [rsp], xmm0
00007588ecdda74c  vmovaps [rsp+0x10], xmm1
00007588ecdda752  vmovaps [rsp+0x20], xmm2
00007588ecdda758  vmovaps [rsp+0x30], xmm3
00007588ecdda75e  vmovaps [rsp+0x40], xmm4
00007588ecdda764  vmovaps [rsp+0x50], xmm5
00007588ecdda76a  vmovaps [rsp+0x60], xmm6
00007588ecdda770  vmovaps [rsp+0x70], xmm7
00007588ecdda776  vmovaps [rsp+0x80], xmm8
00007588ecdda77f  vmovaps [rsp+0x90], xmm9
00007588ecdda788  vmovaps [rsp+0xA0], xmm10
00007588ecdda791  vmovaps [rsp+0xB0], xmm11
00007588ecdda79a  vmovaps [rsp+0xC0], xmm12
00007588ecdda7a3  vmovaps [rsp+0xD0], xmm14
00007588ecdda7ac  vmovaps [rsp+0xE0], xmm15
00007588ecdda7b5  sub rsp, 0x40
00007588ecdda7b9  lea rdi, [rsp]
00007588ecdda7bd  lea rsi, [rsp+0x10]
00007588ecdda7c2  lea rdx, [rsp+0x20]
00007588ecdda7c7  lea rcx, [rsp+0x30]
00007588ecdda7cc  mov r8d, 0x00
00007588ecdda7d2  lea r9, [r15+0x3A8]
00007588ecdda7d9  movaps [rdi], xmm13
00007588ecdda7dd  movaps [rsi], xmm1
00007588ecdda7e0  movaps [rdx], xmm15
00007588ecdda7e4  movaps [rcx], xmm14
00007588ecdda7e8  mov rax, 0x6516BF3BBA50
00007588ecdda7f2  call rax
00007588ecdda7f4  movaps xmm13, [rsp]
00007588ecdda7f9  add rsp, 0x40
00007588ecdda7fd  vmovaps xmm0, [rsp]
00007588ecdda802  vmovaps xmm1, [rsp+0x10]
00007588ecdda808  vmovaps xmm2, [rsp+0x20]
00007588ecdda80e  vmovaps xmm3, [rsp+0x30]
00007588ecdda814  vmovaps xmm4, [rsp+0x40]
00007588ecdda81a  vmovaps xmm5, [rsp+0x50]
00007588ecdda820  vmovaps xmm6, [rsp+0x60]
00007588ecdda826  vmovaps xmm7, [rsp+0x70]
00007588ecdda82c  vmovaps xmm8, [rsp+0x80]
00007588ecdda835  vmovaps xmm9, [rsp+0x90]
00007588ecdda83e  vmovaps xmm10, [rsp+0xA0]
00007588ecdda847  vmovaps xmm11, [rsp+0xB0]
00007588ecdda850  vmovaps xmm12, [rsp+0xC0]
00007588ecdda859  vmovaps xmm14, [rsp+0xD0]
00007588ecdda862  vmovaps xmm15, [rsp+0xE0]
00007588ecdda86b  add rsp, 0xF0
00007588ecdda872  pop r11
00007588ecdda874  pop r10
00007588ecdda876  pop r9
00007588ecdda878  pop r8
00007588ecdda87a  pop rsi
00007588ecdda87b  pop rdi
00007588ecdda87c  pop rdx
00007588ecdda87d  pop rcx
00007588ecdda87e  pop rax
00007588ecdda87f  add rsp, 0x08
00007588ecdda883  jmp 0x00007588ECDD9C92
00007588ecdda888  sub rsp, 0x08
00007588ecdda88c  push rax
00007588ecdda88d  push rcx
00007588ecdda88e  push rdx
00007588ecdda88f  push rdi
00007588ecdda890  push rsi
00007588ecdda891  push r8
00007588ecdda893  push r9
00007588ecdda895  push r10
00007588ecdda897  push r11
00007588ecdda899  sub rsp, 0xF0
00007588ecdda8a0  vmovaps [rsp], xmm0
00007588ecdda8a5  vmovaps [rsp+0x10], xmm1
00007588ecdda8ab  vmovaps [rsp+0x20], xmm2
00007588ecdda8b1  vmovaps [rsp+0x30], xmm3
00007588ecdda8b7  vmovaps [rsp+0x40], xmm4
00007588ecdda8bd  vmovaps [rsp+0x50], xmm5
00007588ecdda8c3  vmovaps [rsp+0x60], xmm6
00007588ecdda8c9  vmovaps [rsp+0x70], xmm7
00007588ecdda8cf  vmovaps [rsp+0x80], xmm8
00007588ecdda8d8  vmovaps [rsp+0x90], xmm9
00007588ecdda8e1  vmovaps [rsp+0xA0], xmm10
00007588ecdda8ea  vmovaps [rsp+0xB0], xmm11
00007588ecdda8f3  vmovaps [rsp+0xC0], xmm13
00007588ecdda8fc  vmovaps [rsp+0xD0], xmm14
00007588ecdda905  vmovaps [rsp+0xE0], xmm15
00007588ecdda90e  sub rsp, 0x40
00007588ecdda912  lea rdi, [rsp]
00007588ecdda916  lea rsi, [rsp+0x10]
00007588ecdda91b  lea rdx, [rsp+0x20]
00007588ecdda920  lea rcx, [rsp+0x30]
00007588ecdda925  mov r8d, 0x00
00007588ecdda92b  lea r9, [r15+0x3A8]
00007588ecdda932  movaps [rdi], xmm12
00007588ecdda936  movaps [rsi], xmm15
00007588ecdda93a  movaps [rdx], xmm1
00007588ecdda93d  movaps [rcx], xmm14
00007588ecdda941  mov rax, 0x6516BF3BBA50
00007588ecdda94b  call rax
00007588ecdda94d  movaps xmm12, [rsp]
00007588ecdda952  add rsp, 0x40
00007588ecdda956  vmovaps xmm0, [rsp]
00007588ecdda95b  vmovaps xmm1, [rsp+0x10]
00007588ecdda961  vmovaps xmm2, [rsp+0x20]
00007588ecdda967  vmovaps xmm3, [rsp+0x30]
00007588ecdda96d  vmovaps xmm4, [rsp+0x40]
00007588ecdda973  vmovaps xmm5, [rsp+0x50]
00007588ecdda979  vmovaps xmm6, [rsp+0x60]
00007588ecdda97f  vmovaps xmm7, [rsp+0x70]
00007588ecdda985  vmovaps xmm8, [rsp+0x80]
00007588ecdda98e  vmovaps xmm9, [rsp+0x90]
00007588ecdda997  vmovaps xmm10, [rsp+0xA0]
00007588ecdda9a0  vmovaps xmm11, [rsp+0xB0]
00007588ecdda9a9  vmovaps xmm13, [rsp+0xC0]
00007588ecdda9b2  vmovaps xmm14, [rsp+0xD0]
00007588ecdda9bb  vmovaps xmm15, [rsp+0xE0]
00007588ecdda9c4  add rsp, 0xF0
00007588ecdda9cb  pop r11
00007588ecdda9cd  pop r10
00007588ecdda9cf  pop r9
00007588ecdda9d1  pop r8
00007588ecdda9d3  pop rsi
00007588ecdda9d4  pop rdi
00007588ecdda9d5  pop rdx
00007588ecdda9d6  pop rcx
00007588ecdda9d7  pop rax
00007588ecdda9d8  add rsp, 0x08
00007588ecdda9dc  jmp 0x00007588ECDD9CC0
00007588ecdda9e1  call 0x00007588ECCB52F0
00007588ecdda9e6  jmp 0x00007588ECDD9DAC
00007588ecdda9eb  sub rsp, 0x08
00007588ecdda9ef  push rax
00007588ecdda9f0  push rcx
00007588ecdda9f1  push rdx
00007588ecdda9f2  push rdi
00007588ecdda9f3  push rsi
00007588ecdda9f4  push r8
00007588ecdda9f6  push r9
00007588ecdda9f8  push r10
00007588ecdda9fa  push r11
00007588ecdda9fc  sub rsp, 0xF0
00007588ecddaa03  vmovaps [rsp], xmm0
00007588ecddaa08  vmovaps [rsp+0x10], xmm1
00007588ecddaa0e  vmovaps [rsp+0x20], xmm2
00007588ecddaa14  vmovaps [rsp+0x30], xmm3
00007588ecddaa1a  vmovaps [rsp+0x40], xmm4
00007588ecddaa20  vmovaps [rsp+0x50], xmm5
00007588ecddaa26  vmovaps [rsp+0x60], xmm6
00007588ecddaa2c  vmovaps [rsp+0x70], xmm7
00007588ecddaa32  vmovaps [rsp+0x80], xmm8
00007588ecddaa3b  vmovaps [rsp+0x90], xmm9
00007588ecddaa44  vmovaps [rsp+0xA0], xmm10
00007588ecddaa4d  vmovaps [rsp+0xB0], xmm11
00007588ecddaa56  vmovaps [rsp+0xC0], xmm12
00007588ecddaa5f  vmovaps [rsp+0xD0], xmm14
00007588ecddaa68  vmovaps [rsp+0xE0], xmm15
00007588ecddaa71  sub rsp, 0x40
00007588ecddaa75  lea rdi, [rsp]
00007588ecddaa79  lea rsi, [rsp+0x10]
00007588ecddaa7e  lea rdx, [rsp+0x20]
00007588ecddaa83  lea rcx, [rsp+0x30]
00007588ecddaa88  mov r8d, 0x00
00007588ecddaa8e  lea r9, [r15+0x3A8]
00007588ecddaa95  movaps [rdi], xmm13
00007588ecddaa99  movaps [rsi], xmm1
00007588ecddaa9c  movaps [rdx], xmm15
00007588ecddaaa0  movaps [rcx], xmm14
00007588ecddaaa4  mov rax, 0x6516BF3BBA50
00007588ecddaaae  call rax
00007588ecddaab0  movaps xmm13, [rsp]
00007588ecddaab5  add rsp, 0x40
00007588ecddaab9  vmovaps xmm0, [rsp]
00007588ecddaabe  vmovaps xmm1, [rsp+0x10]
00007588ecddaac4  vmovaps xmm2, [rsp+0x20]
00007588ecddaaca  vmovaps xmm3, [rsp+0x30]
00007588ecddaad0  vmovaps xmm4, [rsp+0x40]
00007588ecddaad6  vmovaps xmm5, [rsp+0x50]
00007588ecddaadc  vmovaps xmm6, [rsp+0x60]
00007588ecddaae2  vmovaps xmm7, [rsp+0x70]
00007588ecddaae8  vmovaps xmm8, [rsp+0x80]
00007588ecddaaf1  vmovaps xmm9, [rsp+0x90]
00007588ecddaafa  vmovaps xmm10, [rsp+0xA0]
00007588ecddab03  vmovaps xmm11, [rsp+0xB0]
00007588ecddab0c  vmovaps xmm12, [rsp+0xC0]
00007588ecddab15  vmovaps xmm14, [rsp+0xD0]
00007588ecddab1e  vmovaps xmm15, [rsp+0xE0]
00007588ecddab27  add rsp, 0xF0
00007588ecddab2e  pop r11
00007588ecddab30  pop r10
00007588ecddab32  pop r9
00007588ecddab34  pop r8
00007588ecddab36  pop rsi
00007588ecddab37  pop rdi
00007588ecddab38  pop rdx
00007588ecddab39  pop rcx
00007588ecddab3a  pop rax
00007588ecddab3b  add rsp, 0x08
00007588ecddab3f  jmp 0x00007588ECDD9E21
00007588ecddab44  call 0x00007588ECBFF430
00007588ecddab49  jmp 0x00007588ECDD9E2E
00007588ecddab4e  sub rsp, 0x08
00007588ecddab52  push rax
00007588ecddab53  push rcx
00007588ecddab54  push rdx
00007588ecddab55  push rdi
00007588ecddab56  push rsi
00007588ecddab57  push r8
00007588ecddab59  push r9
00007588ecddab5b  push r10
00007588ecddab5d  push r11
00007588ecddab5f  sub rsp, 0xF0
00007588ecddab66  vmovaps [rsp], xmm0
00007588ecddab6b  vmovaps [rsp+0x10], xmm1
00007588ecddab71  vmovaps [rsp+0x20], xmm2
00007588ecddab77  vmovaps [rsp+0x30], xmm3
00007588ecddab7d  vmovaps [rsp+0x40], xmm4
00007588ecddab83  vmovaps [rsp+0x50], xmm5
00007588ecddab89  vmovaps [rsp+0x60], xmm6
00007588ecddab8f  vmovaps [rsp+0x70], xmm7
00007588ecddab95  vmovaps [rsp+0x80], xmm8
00007588ecddab9e  vmovaps [rsp+0x90], xmm9
00007588ecddaba7  vmovaps [rsp+0xA0], xmm10
00007588ecddabb0  vmovaps [rsp+0xB0], xmm11
00007588ecddabb9  vmovaps [rsp+0xC0], xmm13
00007588ecddabc2  vmovaps [rsp+0xD0], xmm14
00007588ecddabcb  vmovaps [rsp+0xE0], xmm15
00007588ecddabd4  sub rsp, 0x40
00007588ecddabd8  lea rdi, [rsp]
00007588ecddabdc  lea rsi, [rsp+0x10]
00007588ecddabe1  lea rdx, [rsp+0x20]
00007588ecddabe6  lea rcx, [rsp+0x30]
00007588ecddabeb  mov r8d, 0x00
00007588ecddabf1  lea r9, [r15+0x3A8]
00007588ecddabf8  movaps [rdi], xmm12
00007588ecddabfc  movaps [rsi], xmm15
00007588ecddac00  movaps [rdx], xmm1
00007588ecddac03  movaps [rcx], xmm14
00007588ecddac07  mov rax, 0x6516BF3BBA50
00007588ecddac11  call rax
00007588ecddac13  movaps xmm12, [rsp]
00007588ecddac18  add rsp, 0x40
00007588ecddac1c  vmovaps xmm0, [rsp]
00007588ecddac21  vmovaps xmm1, [rsp+0x10]
00007588ecddac27  vmovaps xmm2, [rsp+0x20]
00007588ecddac2d  vmovaps xmm3, [rsp+0x30]
00007588ecddac33  vmovaps xmm4, [rsp+0x40]
00007588ecddac39  vmovaps xmm5, [rsp+0x50]
00007588ecddac3f  vmovaps xmm6, [rsp+0x60]
00007588ecddac45  vmovaps xmm7, [rsp+0x70]
00007588ecddac4b  vmovaps xmm8, [rsp+0x80]
00007588ecddac54  vmovaps xmm9, [rsp+0x90]
00007588ecddac5d  vmovaps xmm10, [rsp+0xA0]
00007588ecddac66  vmovaps xmm11, [rsp+0xB0]
00007588ecddac6f  vmovaps xmm13, [rsp+0xC0]
00007588ecddac78  vmovaps xmm14, [rsp+0xD0]
00007588ecddac81  vmovaps xmm15, [rsp+0xE0]
00007588ecddac8a  add rsp, 0xF0
00007588ecddac91  pop r11
00007588ecddac93  pop r10
00007588ecddac95  pop r9
00007588ecddac97  pop r8
00007588ecddac99  pop rsi
00007588ecddac9a  pop rdi
00007588ecddac9b  pop rdx
00007588ecddac9c  pop rcx
00007588ecddac9d  pop rax
00007588ecddac9e  add rsp, 0x08
00007588ecddaca2  jmp 0x00007588ECDD9E5A
00007588ecddaca7  sub rsp, 0x08
00007588ecddacab  push rax
00007588ecddacac  push rcx
00007588ecddacad  push rdx
00007588ecddacae  push rdi
00007588ecddacaf  push rsi
00007588ecddacb0  push r8
00007588ecddacb2  push r9
00007588ecddacb4  push r10
00007588ecddacb6  push r11
00007588ecddacb8  sub rsp, 0xF0
00007588ecddacbf  vmovaps [rsp], xmm0
00007588ecddacc4  vmovaps [rsp+0x10], xmm1
00007588ecddacca  vmovaps [rsp+0x20], xmm2
00007588ecddacd0  vmovaps [rsp+0x30], xmm3
00007588ecddacd6  vmovaps [rsp+0x40], xmm4
00007588ecddacdc  vmovaps [rsp+0x50], xmm5
00007588ecddace2  vmovaps [rsp+0x60], xmm6
00007588ecddace8  vmovaps [rsp+0x70], xmm7
00007588ecddacee  vmovaps [rsp+0x80], xmm8
00007588ecddacf7  vmovaps [rsp+0x90], xmm9
00007588ecddad00  vmovaps [rsp+0xA0], xmm10
00007588ecddad09  vmovaps [rsp+0xB0], xmm11
00007588ecddad12  vmovaps [rsp+0xC0], xmm12
00007588ecddad1b  vmovaps [rsp+0xD0], xmm14
00007588ecddad24  vmovaps [rsp+0xE0], xmm15
00007588ecddad2d  sub rsp, 0x40
00007588ecddad31  lea rdi, [rsp]
00007588ecddad35  lea rsi, [rsp+0x10]
00007588ecddad3a  lea rdx, [rsp+0x20]
00007588ecddad3f  lea rcx, [rsp+0x30]
00007588ecddad44  mov r8d, 0x00
00007588ecddad4a  lea r9, [r15+0x3A8]
00007588ecddad51  movaps [rdi], xmm13
00007588ecddad55  movaps [rsi], xmm1
00007588ecddad58  movaps [rdx], xmm15
00007588ecddad5c  movaps [rcx], xmm14
00007588ecddad60  mov rax, 0x6516BF3BBA50
00007588ecddad6a  call rax
00007588ecddad6c  movaps xmm13, [rsp]
00007588ecddad71  add rsp, 0x40
00007588ecddad75  vmovaps xmm0, [rsp]
00007588ecddad7a  vmovaps xmm1, [rsp+0x10]
00007588ecddad80  vmovaps xmm2, [rsp+0x20]
00007588ecddad86  vmovaps xmm3, [rsp+0x30]
00007588ecddad8c  vmovaps xmm4, [rsp+0x40]
00007588ecddad92  vmovaps xmm5, [rsp+0x50]
00007588ecddad98  vmovaps xmm6, [rsp+0x60]
00007588ecddad9e  vmovaps xmm7, [rsp+0x70]
00007588ecddada4  vmovaps xmm8, [rsp+0x80]
00007588ecddadad  vmovaps xmm9, [rsp+0x90]
00007588ecddadb6  vmovaps xmm10, [rsp+0xA0]
00007588ecddadbf  vmovaps xmm11, [rsp+0xB0]
00007588ecddadc8  vmovaps xmm12, [rsp+0xC0]
00007588ecddadd1  vmovaps xmm14, [rsp+0xD0]
00007588ecddadda  vmovaps xmm15, [rsp+0xE0]
00007588ecddade3  add rsp, 0xF0
00007588ecddadea  pop r11
00007588ecddadec  pop r10
00007588ecddadee  pop r9
00007588ecddadf0  pop r8
00007588ecddadf2  pop rsi
00007588ecddadf3  pop rdi
00007588ecddadf4  pop rdx
00007588ecddadf5  pop rcx
00007588ecddadf6  pop rax
00007588ecddadf7  add rsp, 0x08
00007588ecddadfb  jmp 0x00007588ECDD9FEA
00007588ecddae00  sub rsp, 0x08
00007588ecddae04  push rax
00007588ecddae05  push rcx
00007588ecddae06  push rdx
00007588ecddae07  push rdi
00007588ecddae08  push rsi
00007588ecddae09  push r8
00007588ecddae0b  push r9
00007588ecddae0d  push r10
00007588ecddae0f  push r11
00007588ecddae11  sub rsp, 0xF0
00007588ecddae18  vmovaps [rsp], xmm0
00007588ecddae1d  vmovaps [rsp+0x10], xmm1
00007588ecddae23  vmovaps [rsp+0x20], xmm2
00007588ecddae29  vmovaps [rsp+0x30], xmm3
00007588ecddae2f  vmovaps [rsp+0x40], xmm4
00007588ecddae35  vmovaps [rsp+0x50], xmm5
00007588ecddae3b  vmovaps [rsp+0x60], xmm6
00007588ecddae41  vmovaps [rsp+0x70], xmm7
00007588ecddae47  vmovaps [rsp+0x80], xmm8
00007588ecddae50  vmovaps [rsp+0x90], xmm9
00007588ecddae59  vmovaps [rsp+0xA0], xmm10
00007588ecddae62  vmovaps [rsp+0xB0], xmm11
00007588ecddae6b  vmovaps [rsp+0xC0], xmm12
00007588ecddae74  vmovaps [rsp+0xD0], xmm13
00007588ecddae7d  vmovaps [rsp+0xE0], xmm15
00007588ecddae86  sub rsp, 0x40
00007588ecddae8a  lea rdi, [rsp]
00007588ecddae8e  lea rsi, [rsp+0x10]
00007588ecddae93  lea rdx, [rsp+0x20]
00007588ecddae98  lea rcx, [rsp+0x30]
00007588ecddae9d  mov r8d, 0x00
00007588ecddaea3  lea r9, [r15+0x3A8]
00007588ecddaeaa  movaps [rdi], xmm14
00007588ecddaeae  movaps [rsi], xmm15
00007588ecddaeb2  movaps [rdx], xmm2
00007588ecddaeb5  movaps [rcx], xmm1
00007588ecddaeb8  mov rax, 0x6516BF3BBA50
00007588ecddaec2  call rax
00007588ecddaec4  movaps xmm14, [rsp]
00007588ecddaec9  add rsp, 0x40
00007588ecddaecd  vmovaps xmm0, [rsp]
00007588ecddaed2  vmovaps xmm1, [rsp+0x10]
00007588ecddaed8  vmovaps xmm2, [rsp+0x20]
00007588ecddaede  vmovaps xmm3, [rsp+0x30]
00007588ecddaee4  vmovaps xmm4, [rsp+0x40]
00007588ecddaeea  vmovaps xmm5, [rsp+0x50]
00007588ecddaef0  vmovaps xmm6, [rsp+0x60]
00007588ecddaef6  vmovaps xmm7, [rsp+0x70]
00007588ecddaefc  vmovaps xmm8, [rsp+0x80]
00007588ecddaf05  vmovaps xmm9, [rsp+0x90]
00007588ecddaf0e  vmovaps xmm10, [rsp+0xA0]
00007588ecddaf17  vmovaps xmm11, [rsp+0xB0]
00007588ecddaf20  vmovaps xmm12, [rsp+0xC0]
00007588ecddaf29  vmovaps xmm13, [rsp+0xD0]
00007588ecddaf32  vmovaps xmm15, [rsp+0xE0]
00007588ecddaf3b  add rsp, 0xF0
00007588ecddaf42  pop r11
00007588ecddaf44  pop r10
00007588ecddaf46  pop r9
00007588ecddaf48  pop r8
00007588ecddaf4a  pop rsi
00007588ecddaf4b  pop rdi
00007588ecddaf4c  pop rdx
00007588ecddaf4d  pop rcx
00007588ecddaf4e  pop rax
00007588ecddaf4f  add rsp, 0x08
00007588ecddaf53  jmp 0x00007588ECDDA01C
00007588ecddaf58  sub rsp, 0x08
00007588ecddaf5c  push rax
00007588ecddaf5d  push rcx
00007588ecddaf5e  push rdx
00007588ecddaf5f  push rdi
00007588ecddaf60  push rsi
00007588ecddaf61  push r8
00007588ecddaf63  push r9
00007588ecddaf65  push r10
00007588ecddaf67  push r11
00007588ecddaf69  sub rsp, 0xF0
00007588ecddaf70  vmovaps [rsp], xmm0
00007588ecddaf75  vmovaps [rsp+0x10], xmm1
00007588ecddaf7b  vmovaps [rsp+0x20], xmm3
00007588ecddaf81  vmovaps [rsp+0x30], xmm4
00007588ecddaf87  vmovaps [rsp+0x40], xmm5
00007588ecddaf8d  vmovaps [rsp+0x50], xmm6
00007588ecddaf93  vmovaps [rsp+0x60], xmm7
00007588ecddaf99  vmovaps [rsp+0x70], xmm8
00007588ecddaf9f  vmovaps [rsp+0x80], xmm9
00007588ecddafa8  vmovaps [rsp+0x90], xmm10
00007588ecddafb1  vmovaps [rsp+0xA0], xmm11
00007588ecddafba  vmovaps [rsp+0xB0], xmm12
00007588ecddafc3  vmovaps [rsp+0xC0], xmm13
00007588ecddafcc  vmovaps [rsp+0xD0], xmm14
00007588ecddafd5  vmovaps [rsp+0xE0], xmm15
00007588ecddafde  sub rsp, 0x40
00007588ecddafe2  lea rdi, [rsp]
00007588ecddafe6  lea rsi, [rsp+0x10]
00007588ecddafeb  lea rdx, [rsp+0x20]
00007588ecddaff0  lea rcx, [rsp+0x30]
00007588ecddaff5  mov r8d, 0x00
00007588ecddaffb  lea r9, [r15+0x3A8]
00007588ecddb002  movaps [rdi], xmm2
00007588ecddb005  movaps [rsi], xmm15
00007588ecddb009  movaps [rdx], xmm12
00007588ecddb00d  movaps [rcx], xmm1
00007588ecddb010  mov rax, 0x6516BF3BBA50
00007588ecddb01a  call rax
00007588ecddb01c  movaps xmm2, [rsp]
00007588ecddb020  add rsp, 0x40
00007588ecddb024  vmovaps xmm0, [rsp]
00007588ecddb029  vmovaps xmm1, [rsp+0x10]
00007588ecddb02f  vmovaps xmm3, [rsp+0x20]
00007588ecddb035  vmovaps xmm4, [rsp+0x30]
00007588ecddb03b  vmovaps xmm5, [rsp+0x40]
00007588ecddb041  vmovaps xmm6, [rsp+0x50]
00007588ecddb047  vmovaps xmm7, [rsp+0x60]
00007588ecddb04d  vmovaps xmm8, [rsp+0x70]
00007588ecddb053  vmovaps xmm9, [rsp+0x80]
00007588ecddb05c  vmovaps xmm10, [rsp+0x90]
00007588ecddb065  vmovaps xmm11, [rsp+0xA0]
00007588ecddb06e  vmovaps xmm12, [rsp+0xB0]
00007588ecddb077  vmovaps xmm13, [rsp+0xC0]
00007588ecddb080  vmovaps xmm14, [rsp+0xD0]
00007588ecddb089  vmovaps xmm15, [rsp+0xE0]
00007588ecddb092  add rsp, 0xF0
00007588ecddb099  pop r11
00007588ecddb09b  pop r10
00007588ecddb09d  pop r9
00007588ecddb09f  pop r8
00007588ecddb0a1  pop rsi
00007588ecddb0a2  pop rdi
00007588ecddb0a3  pop rdx
00007588ecddb0a4  pop rcx
00007588ecddb0a5  pop rax
00007588ecddb0a6  add rsp, 0x08
00007588ecddb0aa  jmp 0x00007588ECDDA059
00007588ecddb0af  sub rsp, 0x08
00007588ecddb0b3  push rax
00007588ecddb0b4  push rcx
00007588ecddb0b5  push rdx
00007588ecddb0b6  push rdi
00007588ecddb0b7  push rsi
00007588ecddb0b8  push r8
00007588ecddb0ba  push r9
00007588ecddb0bc  push r10
00007588ecddb0be  push r11
00007588ecddb0c0  sub rsp, 0xF0
00007588ecddb0c7  vmovaps [rsp], xmm0
00007588ecddb0cc  vmovaps [rsp+0x10], xmm1
00007588ecddb0d2  vmovaps [rsp+0x20], xmm2
00007588ecddb0d8  vmovaps [rsp+0x30], xmm3
00007588ecddb0de  vmovaps [rsp+0x40], xmm4
00007588ecddb0e4  vmovaps [rsp+0x50], xmm5
00007588ecddb0ea  vmovaps [rsp+0x60], xmm6
00007588ecddb0f0  vmovaps [rsp+0x70], xmm7
00007588ecddb0f6  vmovaps [rsp+0x80], xmm8
00007588ecddb0ff  vmovaps [rsp+0x90], xmm9
00007588ecddb108  vmovaps [rsp+0xA0], xmm10
00007588ecddb111  vmovaps [rsp+0xB0], xmm11
00007588ecddb11a  vmovaps [rsp+0xC0], xmm13
00007588ecddb123  vmovaps [rsp+0xD0], xmm14
00007588ecddb12c  vmovaps [rsp+0xE0], xmm15
00007588ecddb135  sub rsp, 0x40
00007588ecddb139  lea rdi, [rsp]
00007588ecddb13d  lea rsi, [rsp+0x10]
00007588ecddb142  lea rdx, [rsp+0x20]
00007588ecddb147  lea rcx, [rsp+0x30]
00007588ecddb14c  mov r8d, 0x00
00007588ecddb152  lea r9, [r15+0x3A8]
00007588ecddb159  movaps [rdi], xmm12
00007588ecddb15d  movaps [rsi], xmm14
00007588ecddb161  movaps [rdx], xmm3
00007588ecddb164  movaps [rcx], xmm15
00007588ecddb168  mov rax, 0x6516BF3BBA50
00007588ecddb172  call rax
00007588ecddb174  movaps xmm12, [rsp]
00007588ecddb179  add rsp, 0x40
00007588ecddb17d  vmovaps xmm0, [rsp]
00007588ecddb182  vmovaps xmm1, [rsp+0x10]
00007588ecddb188  vmovaps xmm2, [rsp+0x20]
00007588ecddb18e  vmovaps xmm3, [rsp+0x30]
00007588ecddb194  vmovaps xmm4, [rsp+0x40]
00007588ecddb19a  vmovaps xmm5, [rsp+0x50]
00007588ecddb1a0  vmovaps xmm6, [rsp+0x60]
00007588ecddb1a6  vmovaps xmm7, [rsp+0x70]
00007588ecddb1ac  vmovaps xmm8, [rsp+0x80]
00007588ecddb1b5  vmovaps xmm9, [rsp+0x90]
00007588ecddb1be  vmovaps xmm10, [rsp+0xA0]
00007588ecddb1c7  vmovaps xmm11, [rsp+0xB0]
00007588ecddb1d0  vmovaps xmm13, [rsp+0xC0]
00007588ecddb1d9  vmovaps xmm14, [rsp+0xD0]
00007588ecddb1e2  vmovaps xmm15, [rsp+0xE0]
00007588ecddb1eb  add rsp, 0xF0
00007588ecddb1f2  pop r11
00007588ecddb1f4  pop r10
00007588ecddb1f6  pop r9
00007588ecddb1f8  pop r8
00007588ecddb1fa  pop rsi
00007588ecddb1fb  pop rdi
00007588ecddb1fc  pop rdx
00007588ecddb1fd  pop rcx
00007588ecddb1fe  pop rax
00007588ecddb1ff  add rsp, 0x08
00007588ecddb203  jmp 0x00007588ECDDA0B3
00007588ecddb208  sub rsp, 0x08
00007588ecddb20c  push rax
00007588ecddb20d  push rcx
00007588ecddb20e  push rdx
00007588ecddb20f  push rdi
00007588ecddb210  push rsi
00007588ecddb211  push r8
00007588ecddb213  push r9
00007588ecddb215  push r10
00007588ecddb217  push r11
00007588ecddb219  sub rsp, 0xF0
00007588ecddb220  vmovaps [rsp], xmm0
00007588ecddb225  vmovaps [rsp+0x10], xmm1
00007588ecddb22b  vmovaps [rsp+0x20], xmm2
00007588ecddb231  vmovaps [rsp+0x30], xmm3
00007588ecddb237  vmovaps [rsp+0x40], xmm4
00007588ecddb23d  vmovaps [rsp+0x50], xmm5
00007588ecddb243  vmovaps [rsp+0x60], xmm6
00007588ecddb249  vmovaps [rsp+0x70], xmm7
00007588ecddb24f  vmovaps [rsp+0x80], xmm8
00007588ecddb258  vmovaps [rsp+0x90], xmm10
00007588ecddb261  vmovaps [rsp+0xA0], xmm11
00007588ecddb26a  vmovaps [rsp+0xB0], xmm12
00007588ecddb273  vmovaps [rsp+0xC0], xmm13
00007588ecddb27c  vmovaps [rsp+0xD0], xmm14
00007588ecddb285  vmovaps [rsp+0xE0], xmm15
00007588ecddb28e  sub rsp, 0x40
00007588ecddb292  lea rdi, [rsp]
00007588ecddb296  lea rsi, [rsp+0x10]
00007588ecddb29b  lea rdx, [rsp+0x20]
00007588ecddb2a0  lea rcx, [rsp+0x30]
00007588ecddb2a5  mov r8d, 0x00
00007588ecddb2ab  lea r9, [r15+0x3A8]
00007588ecddb2b2  movaps [rdi], xmm9
00007588ecddb2b6  movaps [rsi], xmm13
00007588ecddb2ba  movaps [rdx], xmm14
00007588ecddb2be  movaps [rcx], xmm6
00007588ecddb2c1  mov rax, 0x6516BF3BBA50
00007588ecddb2cb  call rax
00007588ecddb2cd  movaps xmm9, [rsp]
00007588ecddb2d2  add rsp, 0x40
00007588ecddb2d6  vmovaps xmm0, [rsp]
00007588ecddb2db  vmovaps xmm1, [rsp+0x10]
00007588ecddb2e1  vmovaps xmm2, [rsp+0x20]
00007588ecddb2e7  vmovaps xmm3, [rsp+0x30]
00007588ecddb2ed  vmovaps xmm4, [rsp+0x40]
00007588ecddb2f3  vmovaps xmm5, [rsp+0x50]
00007588ecddb2f9  vmovaps xmm6, [rsp+0x60]
00007588ecddb2ff  vmovaps xmm7, [rsp+0x70]
00007588ecddb305  vmovaps xmm8, [rsp+0x80]
00007588ecddb30e  vmovaps xmm10, [rsp+0x90]
00007588ecddb317  vmovaps xmm11, [rsp+0xA0]
00007588ecddb320  vmovaps xmm12, [rsp+0xB0]
00007588ecddb329  vmovaps xmm13, [rsp+0xC0]
00007588ecddb332  vmovaps xmm14, [rsp+0xD0]
00007588ecddb33b  vmovaps xmm15, [rsp+0xE0]
00007588ecddb344  add rsp, 0xF0
00007588ecddb34b  pop r11
00007588ecddb34d  pop r10
00007588ecddb34f  pop r9
00007588ecddb351  pop r8
00007588ecddb353  pop rsi
00007588ecddb354  pop rdi
00007588ecddb355  pop rdx
00007588ecddb356  pop rcx
00007588ecddb357  pop rax
00007588ecddb358  add rsp, 0x08
00007588ecddb35c  jmp 0x00007588ECDDA15D
00007588ecddb361  sub rsp, 0x08
00007588ecddb365  push rax
00007588ecddb366  push rcx
00007588ecddb367  push rdx
00007588ecddb368  push rdi
00007588ecddb369  push rsi
00007588ecddb36a  push r8
00007588ecddb36c  push r9
00007588ecddb36e  push r10
00007588ecddb370  push r11
00007588ecddb372  sub rsp, 0xF0
00007588ecddb379  vmovaps [rsp], xmm0
00007588ecddb37e  vmovaps [rsp+0x10], xmm1
00007588ecddb384  vmovaps [rsp+0x20], xmm2
00007588ecddb38a  vmovaps [rsp+0x30], xmm4
00007588ecddb390  vmovaps [rsp+0x40], xmm5
00007588ecddb396  vmovaps [rsp+0x50], xmm6
00007588ecddb39c  vmovaps [rsp+0x60], xmm7
00007588ecddb3a2  vmovaps [rsp+0x70], xmm8
00007588ecddb3a8  vmovaps [rsp+0x80], xmm9
00007588ecddb3b1  vmovaps [rsp+0x90], xmm10
00007588ecddb3ba  vmovaps [rsp+0xA0], xmm11
00007588ecddb3c3  vmovaps [rsp+0xB0], xmm12
00007588ecddb3cc  vmovaps [rsp+0xC0], xmm13
00007588ecddb3d5  vmovaps [rsp+0xD0], xmm14
00007588ecddb3de  vmovaps [rsp+0xE0], xmm15
00007588ecddb3e7  sub rsp, 0x40
00007588ecddb3eb  lea rdi, [rsp]
00007588ecddb3ef  lea rsi, [rsp+0x10]
00007588ecddb3f4  lea rdx, [rsp+0x20]
00007588ecddb3f9  lea rcx, [rsp+0x30]
00007588ecddb3fe  mov r8d, 0x00
00007588ecddb404  lea r9, [r15+0x3A8]
00007588ecddb40b  movaps [rdi], xmm3
00007588ecddb40e  movaps [rsi], xmm13
00007588ecddb412  movaps [rdx], xmm6
00007588ecddb415  movaps [rcx], xmm14
00007588ecddb419  mov rax, 0x6516BF3BBA50
00007588ecddb423  call rax
00007588ecddb425  movaps xmm3, [rsp]
00007588ecddb429  add rsp, 0x40
00007588ecddb42d  vmovaps xmm0, [rsp]
00007588ecddb432  vmovaps xmm1, [rsp+0x10]
00007588ecddb438  vmovaps xmm2, [rsp+0x20]
00007588ecddb43e  vmovaps xmm4, [rsp+0x30]
00007588ecddb444  vmovaps xmm5, [rsp+0x40]
00007588ecddb44a  vmovaps xmm6, [rsp+0x50]
00007588ecddb450  vmovaps xmm7, [rsp+0x60]
00007588ecddb456  vmovaps xmm8, [rsp+0x70]
00007588ecddb45c  vmovaps xmm9, [rsp+0x80]
00007588ecddb465  vmovaps xmm10, [rsp+0x90]
00007588ecddb46e  vmovaps xmm11, [rsp+0xA0]
00007588ecddb477  vmovaps xmm12, [rsp+0xB0]
00007588ecddb480  vmovaps xmm13, [rsp+0xC0]
00007588ecddb489  vmovaps xmm14, [rsp+0xD0]
00007588ecddb492  vmovaps xmm15, [rsp+0xE0]
00007588ecddb49b  add rsp, 0xF0
00007588ecddb4a2  pop r11
00007588ecddb4a4  pop r10
00007588ecddb4a6  pop r9
00007588ecddb4a8  pop r8
00007588ecddb4aa  pop rsi
00007588ecddb4ab  pop rdi
00007588ecddb4ac  pop rdx
00007588ecddb4ad  pop rcx
00007588ecddb4ae  pop rax
00007588ecddb4af  add rsp, 0x08
00007588ecddb4b3  jmp 0x00007588ECDDA19A
00007588ecddb4b8  sub rsp, 0x08
00007588ecddb4bc  push rax
00007588ecddb4bd  push rcx
00007588ecddb4be  push rdx
00007588ecddb4bf  push rdi
00007588ecddb4c0  push rsi
00007588ecddb4c1  push r8
00007588ecddb4c3  push r9
00007588ecddb4c5  push r10
00007588ecddb4c7  push r11
00007588ecddb4c9  sub rsp, 0xF0
00007588ecddb4d0  vmovaps [rsp], xmm0
00007588ecddb4d5  vmovaps [rsp+0x10], xmm1
00007588ecddb4db  vmovaps [rsp+0x20], xmm2
00007588ecddb4e1  vmovaps [rsp+0x30], xmm3
00007588ecddb4e7  vmovaps [rsp+0x40], xmm4
00007588ecddb4ed  vmovaps [rsp+0x50], xmm5
00007588ecddb4f3  vmovaps [rsp+0x60], xmm7
00007588ecddb4f9  vmovaps [rsp+0x70], xmm8
00007588ecddb4ff  vmovaps [rsp+0x80], xmm9
00007588ecddb508  vmovaps [rsp+0x90], xmm10
00007588ecddb511  vmovaps [rsp+0xA0], xmm11
00007588ecddb51a  vmovaps [rsp+0xB0], xmm12
00007588ecddb523  vmovaps [rsp+0xC0], xmm13
00007588ecddb52c  vmovaps [rsp+0xD0], xmm14
00007588ecddb535  vmovaps [rsp+0xE0], xmm15
00007588ecddb53e  sub rsp, 0x40
00007588ecddb542  lea rdi, [rsp]
00007588ecddb546  lea rsi, [rsp+0x10]
00007588ecddb54b  lea rdx, [rsp+0x20]
00007588ecddb550  lea rcx, [rsp+0x30]
00007588ecddb555  mov r8d, 0x00
00007588ecddb55b  lea r9, [r15+0x3A8]
00007588ecddb562  movaps [rdi], xmm6
00007588ecddb565  movaps [rsi], xmm2
00007588ecddb568  movaps [rdx], xmm14
00007588ecddb56c  movaps [rcx], xmm1
00007588ecddb56f  mov rax, 0x6516BF3BBA50
00007588ecddb579  call rax
00007588ecddb57b  movaps xmm6, [rsp]
00007588ecddb57f  add rsp, 0x40
00007588ecddb583  vmovaps xmm0, [rsp]
00007588ecddb588  vmovaps xmm1, [rsp+0x10]
00007588ecddb58e  vmovaps xmm2, [rsp+0x20]
00007588ecddb594  vmovaps xmm3, [rsp+0x30]
00007588ecddb59a  vmovaps xmm4, [rsp+0x40]
00007588ecddb5a0  vmovaps xmm5, [rsp+0x50]
00007588ecddb5a6  vmovaps xmm7, [rsp+0x60]
00007588ecddb5ac  vmovaps xmm8, [rsp+0x70]
00007588ecddb5b2  vmovaps xmm9, [rsp+0x80]
00007588ecddb5bb  vmovaps xmm10, [rsp+0x90]
00007588ecddb5c4  vmovaps xmm11, [rsp+0xA0]
00007588ecddb5cd  vmovaps xmm12, [rsp+0xB0]
00007588ecddb5d6  vmovaps xmm13, [rsp+0xC0]
00007588ecddb5df  vmovaps xmm14, [rsp+0xD0]
00007588ecddb5e8  vmovaps xmm15, [rsp+0xE0]
00007588ecddb5f1  add rsp, 0xF0
00007588ecddb5f8  pop r11
00007588ecddb5fa  pop r10
00007588ecddb5fc  pop r9
00007588ecddb5fe  pop r8
00007588ecddb600  pop rsi
00007588ecddb601  pop rdi
00007588ecddb602  pop rdx
00007588ecddb603  pop rcx
00007588ecddb604  pop rax
00007588ecddb605  add rsp, 0x08
00007588ecddb609  jmp 0x00007588ECDDA1C7
00007588ecddb60e  sub rsp, 0x08
00007588ecddb612  push rax
00007588ecddb613  push rcx
00007588ecddb614  push rdx
00007588ecddb615  push rdi
00007588ecddb616  push rsi
00007588ecddb617  push r8
00007588ecddb619  push r9
00007588ecddb61b  push r10
00007588ecddb61d  push r11
00007588ecddb61f  sub rsp, 0xF0
00007588ecddb626  vmovaps [rsp], xmm0
00007588ecddb62b  vmovaps [rsp+0x10], xmm1
00007588ecddb631  vmovaps [rsp+0x20], xmm2
00007588ecddb637  vmovaps [rsp+0x30], xmm3
00007588ecddb63d  vmovaps [rsp+0x40], xmm4
00007588ecddb643  vmovaps [rsp+0x50], xmm5
00007588ecddb649  vmovaps [rsp+0x60], xmm6
00007588ecddb64f  vmovaps [rsp+0x70], xmm7
00007588ecddb655  vmovaps [rsp+0x80], xmm8
00007588ecddb65e  vmovaps [rsp+0x90], xmm9
00007588ecddb667  vmovaps [rsp+0xA0], xmm10
00007588ecddb670  vmovaps [rsp+0xB0], xmm11
00007588ecddb679  vmovaps [rsp+0xC0], xmm12
00007588ecddb682  vmovaps [rsp+0xD0], xmm14
00007588ecddb68b  vmovaps [rsp+0xE0], xmm15
00007588ecddb694  sub rsp, 0x40
00007588ecddb698  lea rdi, [rsp]
00007588ecddb69c  lea rsi, [rsp+0x10]
00007588ecddb6a1  lea rdx, [rsp+0x20]
00007588ecddb6a6  lea rcx, [rsp+0x30]
00007588ecddb6ab  mov r8d, 0x00
00007588ecddb6b1  lea r9, [r15+0x3A8]
00007588ecddb6b8  movaps [rdi], xmm13
00007588ecddb6bc  movaps [rsi], xmm12
00007588ecddb6c0  movaps [rdx], xmm14
00007588ecddb6c4  movaps [rcx], xmm1
00007588ecddb6c7  mov rax, 0x6516BF3BBA50
00007588ecddb6d1  call rax
00007588ecddb6d3  movaps xmm13, [rsp]
00007588ecddb6d8  add rsp, 0x40
00007588ecddb6dc  vmovaps xmm0, [rsp]
00007588ecddb6e1  vmovaps xmm1, [rsp+0x10]
00007588ecddb6e7  vmovaps xmm2, [rsp+0x20]
00007588ecddb6ed  vmovaps xmm3, [rsp+0x30]
00007588ecddb6f3  vmovaps xmm4, [rsp+0x40]
00007588ecddb6f9  vmovaps xmm5, [rsp+0x50]
00007588ecddb6ff  vmovaps xmm6, [rsp+0x60]
00007588ecddb705  vmovaps xmm7, [rsp+0x70]
00007588ecddb70b  vmovaps xmm8, [rsp+0x80]
00007588ecddb714  vmovaps xmm9, [rsp+0x90]
00007588ecddb71d  vmovaps xmm10, [rsp+0xA0]
00007588ecddb726  vmovaps xmm11, [rsp+0xB0]
00007588ecddb72f  vmovaps xmm12, [rsp+0xC0]
00007588ecddb738  vmovaps xmm14, [rsp+0xD0]
00007588ecddb741  vmovaps xmm15, [rsp+0xE0]
00007588ecddb74a  add rsp, 0xF0
00007588ecddb751  pop r11
00007588ecddb753  pop r10
00007588ecddb755  pop r9
00007588ecddb757  pop r8
00007588ecddb759  pop rsi
00007588ecddb75a  pop rdi
00007588ecddb75b  pop rdx
00007588ecddb75c  pop rcx
00007588ecddb75d  pop rax
00007588ecddb75e  add rsp, 0x08
00007588ecddb762  jmp 0x00007588ECDDA1F9
00007588ecddb767  sub rsp, 0x08
00007588ecddb76b  push rax
00007588ecddb76c  push rcx
00007588ecddb76d  push rdx
00007588ecddb76e  push rdi
00007588ecddb76f  push rsi
00007588ecddb770  push r8
00007588ecddb772  push r9
00007588ecddb774  push r10
00007588ecddb776  push r11
00007588ecddb778  sub rsp, 0xF0
00007588ecddb77f  vmovaps [rsp], xmm0
00007588ecddb784  vmovaps [rsp+0x10], xmm1
00007588ecddb78a  vmovaps [rsp+0x20], xmm2
00007588ecddb790  vmovaps [rsp+0x30], xmm3
00007588ecddb796  vmovaps [rsp+0x40], xmm4
00007588ecddb79c  vmovaps [rsp+0x50], xmm5
00007588ecddb7a2  vmovaps [rsp+0x60], xmm6
00007588ecddb7a8  vmovaps [rsp+0x70], xmm7
00007588ecddb7ae  vmovaps [rsp+0x80], xmm8
00007588ecddb7b7  vmovaps [rsp+0x90], xmm9
00007588ecddb7c0  vmovaps [rsp+0xA0], xmm10
00007588ecddb7c9  vmovaps [rsp+0xB0], xmm11
00007588ecddb7d2  vmovaps [rsp+0xC0], xmm13
00007588ecddb7db  vmovaps [rsp+0xD0], xmm14
00007588ecddb7e4  vmovaps [rsp+0xE0], xmm15
00007588ecddb7ed  sub rsp, 0x40
00007588ecddb7f1  lea rdi, [rsp]
00007588ecddb7f5  lea rsi, [rsp+0x10]
00007588ecddb7fa  lea rdx, [rsp+0x20]
00007588ecddb7ff  lea rcx, [rsp+0x30]
00007588ecddb804  mov r8d, 0x00
00007588ecddb80a  lea r9, [r15+0x3A8]
00007588ecddb811  movaps [rdi], xmm12
00007588ecddb815  movaps [rsi], xmm3
00007588ecddb818  movaps [rdx], xmm14
00007588ecddb81c  movaps [rcx], xmm5
00007588ecddb81f  mov rax, 0x6516BF3BBA50
00007588ecddb829  call rax
00007588ecddb82b  movaps xmm12, [rsp]
00007588ecddb830  add rsp, 0x40
00007588ecddb834  vmovaps xmm0, [rsp]
00007588ecddb839  vmovaps xmm1, [rsp+0x10]
00007588ecddb83f  vmovaps xmm2, [rsp+0x20]
00007588ecddb845  vmovaps xmm3, [rsp+0x30]
00007588ecddb84b  vmovaps xmm4, [rsp+0x40]
00007588ecddb851  vmovaps xmm5, [rsp+0x50]
00007588ecddb857  vmovaps xmm6, [rsp+0x60]
00007588ecddb85d  vmovaps xmm7, [rsp+0x70]
00007588ecddb863  vmovaps xmm8, [rsp+0x80]
00007588ecddb86c  vmovaps xmm9, [rsp+0x90]
00007588ecddb875  vmovaps xmm10, [rsp+0xA0]
00007588ecddb87e  vmovaps xmm11, [rsp+0xB0]
00007588ecddb887  vmovaps xmm13, [rsp+0xC0]
00007588ecddb890  vmovaps xmm14, [rsp+0xD0]
00007588ecddb899  vmovaps xmm15, [rsp+0xE0]
00007588ecddb8a2  add rsp, 0xF0
00007588ecddb8a9  pop r11
00007588ecddb8ab  pop r10
00007588ecddb8ad  pop r9
00007588ecddb8af  pop r8
00007588ecddb8b1  pop rsi
00007588ecddb8b2  pop rdi
00007588ecddb8b3  pop rdx
00007588ecddb8b4  pop rcx
00007588ecddb8b5  pop rax
00007588ecddb8b6  add rsp, 0x08
00007588ecddb8ba  jmp 0x00007588ECDDA256
00007588ecddb8bf  sub rsp, 0x08
00007588ecddb8c3  push rax
00007588ecddb8c4  push rcx
00007588ecddb8c5  push rdx
00007588ecddb8c6  push rdi
00007588ecddb8c7  push rsi
00007588ecddb8c8  push r8
00007588ecddb8ca  push r9
00007588ecddb8cc  push r10
00007588ecddb8ce  push r11
00007588ecddb8d0  sub rsp, 0xF0
00007588ecddb8d7  vmovaps [rsp], xmm0
00007588ecddb8dc  vmovaps [rsp+0x10], xmm1
00007588ecddb8e2  vmovaps [rsp+0x20], xmm2
00007588ecddb8e8  vmovaps [rsp+0x30], xmm3
00007588ecddb8ee  vmovaps [rsp+0x40], xmm4
00007588ecddb8f4  vmovaps [rsp+0x50], xmm5
00007588ecddb8fa  vmovaps [rsp+0x60], xmm6
00007588ecddb900  vmovaps [rsp+0x70], xmm7
00007588ecddb906  vmovaps [rsp+0x80], xmm8
00007588ecddb90f  vmovaps [rsp+0x90], xmm9
00007588ecddb918  vmovaps [rsp+0xA0], xmm11
00007588ecddb921  vmovaps [rsp+0xB0], xmm12
00007588ecddb92a  vmovaps [rsp+0xC0], xmm13
00007588ecddb933  vmovaps [rsp+0xD0], xmm14
00007588ecddb93c  vmovaps [rsp+0xE0], xmm15
00007588ecddb945  sub rsp, 0x40
00007588ecddb949  lea rdi, [rsp]
00007588ecddb94d  lea rsi, [rsp+0x10]
00007588ecddb952  lea rdx, [rsp+0x20]
00007588ecddb957  lea rcx, [rsp+0x30]
00007588ecddb95c  mov r8d, 0x00
00007588ecddb962  lea r9, [r15+0x3A8]
00007588ecddb969  movaps [rdi], xmm10
00007588ecddb96d  movaps [rsi], xmm9
00007588ecddb971  movaps [rdx], xmm7
00007588ecddb974  movaps [rcx], xmm14
00007588ecddb978  mov rax, 0x6516BF3BBA50
00007588ecddb982  call rax
00007588ecddb984  movaps xmm10, [rsp]
00007588ecddb989  add rsp, 0x40
00007588ecddb98d  vmovaps xmm0, [rsp]
00007588ecddb992  vmovaps xmm1, [rsp+0x10]
00007588ecddb998  vmovaps xmm2, [rsp+0x20]
00007588ecddb99e  vmovaps xmm3, [rsp+0x30]
00007588ecddb9a4  vmovaps xmm4, [rsp+0x40]
00007588ecddb9aa  vmovaps xmm5, [rsp+0x50]
00007588ecddb9b0  vmovaps xmm6, [rsp+0x60]
00007588ecddb9b6  vmovaps xmm7, [rsp+0x70]
00007588ecddb9bc  vmovaps xmm8, [rsp+0x80]
00007588ecddb9c5  vmovaps xmm9, [rsp+0x90]
00007588ecddb9ce  vmovaps xmm11, [rsp+0xA0]
00007588ecddb9d7  vmovaps xmm12, [rsp+0xB0]
00007588ecddb9e0  vmovaps xmm13, [rsp+0xC0]
00007588ecddb9e9  vmovaps xmm14, [rsp+0xD0]
00007588ecddb9f2  vmovaps xmm15, [rsp+0xE0]
00007588ecddb9fb  add rsp, 0xF0
00007588ecddba02  pop r11
00007588ecddba04  pop r10
00007588ecddba06  pop r9
00007588ecddba08  pop r8
00007588ecddba0a  pop rsi
00007588ecddba0b  pop rdi
00007588ecddba0c  pop rdx
00007588ecddba0d  pop rcx
00007588ecddba0e  pop rax
00007588ecddba0f  add rsp, 0x08
00007588ecddba13  jmp 0x00007588ECDDA27C
00007588ecddba18  call 0x00007588ECC0D4E0
00007588ecddba1d  jmp 0x00007588ECDDA289
00007588ecddba22  sub rsp, 0x08
00007588ecddba26  push rax
00007588ecddba27  push rcx
00007588ecddba28  push rdx
00007588ecddba29  push rdi
00007588ecddba2a  push rsi
00007588ecddba2b  push r8
00007588ecddba2d  push r9
00007588ecddba2f  push r10
00007588ecddba31  push r11
00007588ecddba33  sub rsp, 0xF0
00007588ecddba3a  vmovaps [rsp], xmm0
00007588ecddba3f  vmovaps [rsp+0x10], xmm1
00007588ecddba45  vmovaps [rsp+0x20], xmm2
00007588ecddba4b  vmovaps [rsp+0x30], xmm3
00007588ecddba51  vmovaps [rsp+0x40], xmm4
00007588ecddba57  vmovaps [rsp+0x50], xmm6
00007588ecddba5d  vmovaps [rsp+0x60], xmm7
00007588ecddba63  vmovaps [rsp+0x70], xmm8
00007588ecddba69  vmovaps [rsp+0x80], xmm9
00007588ecddba72  vmovaps [rsp+0x90], xmm10
00007588ecddba7b  vmovaps [rsp+0xA0], xmm11
00007588ecddba84  vmovaps [rsp+0xB0], xmm12
00007588ecddba8d  vmovaps [rsp+0xC0], xmm13
00007588ecddba96  vmovaps [rsp+0xD0], xmm14
00007588ecddba9f  vmovaps [rsp+0xE0], xmm15
00007588ecddbaa8  sub rsp, 0x40
00007588ecddbaac  lea rdi, [rsp]
00007588ecddbab0  lea rsi, [rsp+0x10]
00007588ecddbab5  lea rdx, [rsp+0x20]
00007588ecddbaba  lea rcx, [rsp+0x30]
00007588ecddbabf  mov r8d, 0x00
00007588ecddbac5  lea r9, [r15+0x3A8]
00007588ecddbacc  movaps [rdi], xmm5
00007588ecddbacf  movaps [rsi], xmm6
00007588ecddbad2  movaps [rdx], xmm7
00007588ecddbad5  movaps [rcx], xmm9
00007588ecddbad9  mov rax, 0x6516BF3BBA50
00007588ecddbae3  call rax
00007588ecddbae5  movaps xmm5, [rsp]
00007588ecddbae9  add rsp, 0x40
00007588ecddbaed  vmovaps xmm0, [rsp]
00007588ecddbaf2  vmovaps xmm1, [rsp+0x10]
00007588ecddbaf8  vmovaps xmm2, [rsp+0x20]
00007588ecddbafe  vmovaps xmm3, [rsp+0x30]
00007588ecddbb04  vmovaps xmm4, [rsp+0x40]
00007588ecddbb0a  vmovaps xmm6, [rsp+0x50]
00007588ecddbb10  vmovaps xmm7, [rsp+0x60]
00007588ecddbb16  vmovaps xmm8, [rsp+0x70]
00007588ecddbb1c  vmovaps xmm9, [rsp+0x80]
00007588ecddbb25  vmovaps xmm10, [rsp+0x90]
00007588ecddbb2e  vmovaps xmm11, [rsp+0xA0]
00007588ecddbb37  vmovaps xmm12, [rsp+0xB0]
00007588ecddbb40  vmovaps xmm13, [rsp+0xC0]
00007588ecddbb49  vmovaps xmm14, [rsp+0xD0]
00007588ecddbb52  vmovaps xmm15, [rsp+0xE0]
00007588ecddbb5b  add rsp, 0xF0
00007588ecddbb62  pop r11
00007588ecddbb64  pop r10
00007588ecddbb66  pop r9
00007588ecddbb68  pop r8
00007588ecddbb6a  pop rsi
00007588ecddbb6b  pop rdi
00007588ecddbb6c  pop rdx
00007588ecddbb6d  pop rcx
00007588ecddbb6e  pop rax
00007588ecddbb6f  add rsp, 0x08
00007588ecddbb73  jmp 0x00007588ECDDA2BB
00007588ecddbb78  sub rsp, 0x08
00007588ecddbb7c  push rax
00007588ecddbb7d  push rcx
00007588ecddbb7e  push rdx
00007588ecddbb7f  push rdi
00007588ecddbb80  push rsi
00007588ecddbb81  push r8
00007588ecddbb83  push r9
00007588ecddbb85  push r10
00007588ecddbb87  push r11
00007588ecddbb89  sub rsp, 0xF0
00007588ecddbb90  vmovaps [rsp], xmm0
00007588ecddbb95  vmovaps [rsp+0x10], xmm1
00007588ecddbb9b  vmovaps [rsp+0x20], xmm2
00007588ecddbba1  vmovaps [rsp+0x30], xmm3
00007588ecddbba7  vmovaps [rsp+0x40], xmm4
00007588ecddbbad  vmovaps [rsp+0x50], xmm5
00007588ecddbbb3  vmovaps [rsp+0x60], xmm6
00007588ecddbbb9  vmovaps [rsp+0x70], xmm8
00007588ecddbbbf  vmovaps [rsp+0x80], xmm9
00007588ecddbbc8  vmovaps [rsp+0x90], xmm10
00007588ecddbbd1  vmovaps [rsp+0xA0], xmm11
00007588ecddbbda  vmovaps [rsp+0xB0], xmm12
00007588ecddbbe3  vmovaps [rsp+0xC0], xmm13
00007588ecddbbec  vmovaps [rsp+0xD0], xmm14
00007588ecddbbf5  vmovaps [rsp+0xE0], xmm15
00007588ecddbbfe  sub rsp, 0x40
00007588ecddbc02  lea rdi, [rsp]
00007588ecddbc06  lea rsi, [rsp+0x10]
00007588ecddbc0b  lea rdx, [rsp+0x20]
00007588ecddbc10  lea rcx, [rsp+0x30]
00007588ecddbc15  mov r8d, 0x00
00007588ecddbc1b  lea r9, [r15+0x3A8]
00007588ecddbc22  movaps [rdi], xmm7
00007588ecddbc25  movaps [rsi], xmm13
00007588ecddbc29  movaps [rdx], xmm1
00007588ecddbc2c  movaps [rcx], xmm9
00007588ecddbc30  mov rax, 0x6516BF3BBA50
00007588ecddbc3a  call rax
00007588ecddbc3c  movaps xmm7, [rsp]
00007588ecddbc40  add rsp, 0x40
00007588ecddbc44  vmovaps xmm0, [rsp]
00007588ecddbc49  vmovaps xmm1, [rsp+0x10]
00007588ecddbc4f  vmovaps xmm2, [rsp+0x20]
00007588ecddbc55  vmovaps xmm3, [rsp+0x30]
00007588ecddbc5b  vmovaps xmm4, [rsp+0x40]
00007588ecddbc61  vmovaps xmm5, [rsp+0x50]
00007588ecddbc67  vmovaps xmm6, [rsp+0x60]
00007588ecddbc6d  vmovaps xmm8, [rsp+0x70]
00007588ecddbc73  vmovaps xmm9, [rsp+0x80]
00007588ecddbc7c  vmovaps xmm10, [rsp+0x90]
00007588ecddbc85  vmovaps xmm11, [rsp+0xA0]
00007588ecddbc8e  vmovaps xmm12, [rsp+0xB0]
00007588ecddbc97  vmovaps xmm13, [rsp+0xC0]
00007588ecddbca0  vmovaps xmm14, [rsp+0xD0]
00007588ecddbca9  vmovaps xmm15, [rsp+0xE0]
00007588ecddbcb2  add rsp, 0xF0
00007588ecddbcb9  pop r11
00007588ecddbcbb  pop r10
00007588ecddbcbd  pop r9
00007588ecddbcbf  pop r8
00007588ecddbcc1  pop rsi
00007588ecddbcc2  pop rdi
00007588ecddbcc3  pop rdx
00007588ecddbcc4  pop rcx
00007588ecddbcc5  pop rax
00007588ecddbcc6  add rsp, 0x08
00007588ecddbcca  jmp 0x00007588ECDDA2E0
00007588ecddbccf  call 0x00007588ECC0C260
00007588ecddbcd4  jmp 0x00007588ECDDA303
00007588ecddbcd9  call 0x00007588ECC07890
00007588ecddbcde  jmp 0x00007588ECDDA30D
00007588ecddbce3  sub rsp, 0x08
00007588ecddbce7  push rax
00007588ecddbce8  push rcx
00007588ecddbce9  push rdx
00007588ecddbcea  push rdi
00007588ecddbceb  push rsi
00007588ecddbcec  push r8
00007588ecddbcee  push r9
00007588ecddbcf0  push r10
00007588ecddbcf2  push r11
00007588ecddbcf4  sub rsp, 0xF0
00007588ecddbcfb  vmovaps [rsp], xmm0
00007588ecddbd00  vmovaps [rsp+0x10], xmm1
00007588ecddbd06  vmovaps [rsp+0x20], xmm3
00007588ecddbd0c  vmovaps [rsp+0x30], xmm4
00007588ecddbd12  vmovaps [rsp+0x40], xmm5
00007588ecddbd18  vmovaps [rsp+0x50], xmm6
00007588ecddbd1e  vmovaps [rsp+0x60], xmm7
00007588ecddbd24  vmovaps [rsp+0x70], xmm8
00007588ecddbd2a  vmovaps [rsp+0x80], xmm9
00007588ecddbd33  vmovaps [rsp+0x90], xmm10
00007588ecddbd3c  vmovaps [rsp+0xA0], xmm11
00007588ecddbd45  vmovaps [rsp+0xB0], xmm12
00007588ecddbd4e  vmovaps [rsp+0xC0], xmm13
00007588ecddbd57  vmovaps [rsp+0xD0], xmm14
00007588ecddbd60  vmovaps [rsp+0xE0], xmm15
00007588ecddbd69  sub rsp, 0x40
00007588ecddbd6d  lea rdi, [rsp]
00007588ecddbd71  lea rsi, [rsp+0x10]
00007588ecddbd76  lea rdx, [rsp+0x20]
00007588ecddbd7b  lea rcx, [rsp+0x30]
00007588ecddbd80  mov r8d, 0x00
00007588ecddbd86  lea r9, [r15+0x3A8]
00007588ecddbd8d  movaps [rdi], xmm2
00007588ecddbd90  movaps [rsi], xmm12
00007588ecddbd94  movaps [rdx], xmm6
00007588ecddbd97  movaps [rcx], xmm3
00007588ecddbd9a  mov rax, 0x6516BF3BBA50
00007588ecddbda4  call rax
00007588ecddbda6  movaps xmm2, [rsp]
00007588ecddbdaa  add rsp, 0x40
00007588ecddbdae  vmovaps xmm0, [rsp]
00007588ecddbdb3  vmovaps xmm1, [rsp+0x10]
00007588ecddbdb9  vmovaps xmm3, [rsp+0x20]
00007588ecddbdbf  vmovaps xmm4, [rsp+0x30]
00007588ecddbdc5  vmovaps xmm5, [rsp+0x40]
00007588ecddbdcb  vmovaps xmm6, [rsp+0x50]
00007588ecddbdd1  vmovaps xmm7, [rsp+0x60]
00007588ecddbdd7  vmovaps xmm8, [rsp+0x70]
00007588ecddbddd  vmovaps xmm9, [rsp+0x80]
00007588ecddbde6  vmovaps xmm10, [rsp+0x90]
00007588ecddbdef  vmovaps xmm11, [rsp+0xA0]
00007588ecddbdf8  vmovaps xmm12, [rsp+0xB0]
00007588ecddbe01  vmovaps xmm13, [rsp+0xC0]
00007588ecddbe0a  vmovaps xmm14, [rsp+0xD0]
00007588ecddbe13  vmovaps xmm15, [rsp+0xE0]
00007588ecddbe1c  add rsp, 0xF0
00007588ecddbe23  pop r11
00007588ecddbe25  pop r10
00007588ecddbe27  pop r9
00007588ecddbe29  pop r8
00007588ecddbe2b  pop rsi
00007588ecddbe2c  pop rdi
00007588ecddbe2d  pop rdx
00007588ecddbe2e  pop rcx
00007588ecddbe2f  pop rax
00007588ecddbe30  add rsp, 0x08
00007588ecddbe34  jmp 0x00007588ECDDA353
00007588ecddbe39  sub rsp, 0x08
00007588ecddbe3d  push rax
00007588ecddbe3e  push rcx
00007588ecddbe3f  push rdx
00007588ecddbe40  push rdi
00007588ecddbe41  push rsi
00007588ecddbe42  push r8
00007588ecddbe44  push r9
00007588ecddbe46  push r10
00007588ecddbe48  push r11
00007588ecddbe4a  sub rsp, 0xF0
00007588ecddbe51  vmovaps [rsp], xmm0
00007588ecddbe56  vmovaps [rsp+0x10], xmm1
00007588ecddbe5c  vmovaps [rsp+0x20], xmm2
00007588ecddbe62  vmovaps [rsp+0x30], xmm3
00007588ecddbe68  vmovaps [rsp+0x40], xmm4
00007588ecddbe6e  vmovaps [rsp+0x50], xmm5
00007588ecddbe74  vmovaps [rsp+0x60], xmm7
00007588ecddbe7a  vmovaps [rsp+0x70], xmm8
00007588ecddbe80  vmovaps [rsp+0x80], xmm9
00007588ecddbe89  vmovaps [rsp+0x90], xmm10
00007588ecddbe92  vmovaps [rsp+0xA0], xmm11
00007588ecddbe9b  vmovaps [rsp+0xB0], xmm12
00007588ecddbea4  vmovaps [rsp+0xC0], xmm13
00007588ecddbead  vmovaps [rsp+0xD0], xmm14
00007588ecddbeb6  vmovaps [rsp+0xE0], xmm15
00007588ecddbebf  sub rsp, 0x40
00007588ecddbec3  lea rdi, [rsp]
00007588ecddbec7  lea rsi, [rsp+0x10]
00007588ecddbecc  lea rdx, [rsp+0x20]
00007588ecddbed1  lea rcx, [rsp+0x30]
00007588ecddbed6  mov r8d, 0x00
00007588ecddbedc  lea r9, [r15+0x3A8]
00007588ecddbee3  movaps [rdi], xmm6
00007588ecddbee6  movaps [rsi], xmm10
00007588ecddbeea  movaps [rdx], xmm12
00007588ecddbeee  movaps [rcx], xmm1
00007588ecddbef1  mov rax, 0x6516BF3BBA50
00007588ecddbefb  call rax
00007588ecddbefd  movaps xmm6, [rsp]
00007588ecddbf01  add rsp, 0x40
00007588ecddbf05  vmovaps xmm0, [rsp]
00007588ecddbf0a  vmovaps xmm1, [rsp+0x10]
00007588ecddbf10  vmovaps xmm2, [rsp+0x20]
00007588ecddbf16  vmovaps xmm3, [rsp+0x30]
00007588ecddbf1c  vmovaps xmm4, [rsp+0x40]
00007588ecddbf22  vmovaps xmm5, [rsp+0x50]
00007588ecddbf28  vmovaps xmm7, [rsp+0x60]
00007588ecddbf2e  vmovaps xmm8, [rsp+0x70]
00007588ecddbf34  vmovaps xmm9, [rsp+0x80]
00007588ecddbf3d  vmovaps xmm10, [rsp+0x90]
00007588ecddbf46  vmovaps xmm11, [rsp+0xA0]
00007588ecddbf4f  vmovaps xmm12, [rsp+0xB0]
00007588ecddbf58  vmovaps xmm13, [rsp+0xC0]
00007588ecddbf61  vmovaps xmm14, [rsp+0xD0]
00007588ecddbf6a  vmovaps xmm15, [rsp+0xE0]
00007588ecddbf73  add rsp, 0xF0
00007588ecddbf7a  pop r11
00007588ecddbf7c  pop r10
00007588ecddbf7e  pop r9
00007588ecddbf80  pop r8
00007588ecddbf82  pop rsi
00007588ecddbf83  pop rdi
00007588ecddbf84  pop rdx
00007588ecddbf85  pop rcx
00007588ecddbf86  pop rax
00007588ecddbf87  add rsp, 0x08
00007588ecddbf8b  jmp 0x00007588ECDDA381
00007588ecddbf90  sub rsp, 0x08
00007588ecddbf94  push rax
00007588ecddbf95  push rcx
00007588ecddbf96  push rdx
00007588ecddbf97  push rdi
00007588ecddbf98  push rsi
00007588ecddbf99  push r8
00007588ecddbf9b  push r9
00007588ecddbf9d  push r10
00007588ecddbf9f  push r11
00007588ecddbfa1  sub rsp, 0xF0
00007588ecddbfa8  vmovaps [rsp], xmm0
00007588ecddbfad  vmovaps [rsp+0x10], xmm1
00007588ecddbfb3  vmovaps [rsp+0x20], xmm2
00007588ecddbfb9  vmovaps [rsp+0x30], xmm3
00007588ecddbfbf  vmovaps [rsp+0x40], xmm4
00007588ecddbfc5  vmovaps [rsp+0x50], xmm5
00007588ecddbfcb  vmovaps [rsp+0x60], xmm6
00007588ecddbfd1  vmovaps [rsp+0x70], xmm7
00007588ecddbfd7  vmovaps [rsp+0x80], xmm8
00007588ecddbfe0  vmovaps [rsp+0x90], xmm9
00007588ecddbfe9  vmovaps [rsp+0xA0], xmm11
00007588ecddbff2  vmovaps [rsp+0xB0], xmm12
00007588ecddbffb  vmovaps [rsp+0xC0], xmm13
00007588ecddc004  vmovaps [rsp+0xD0], xmm14
00007588ecddc00d  vmovaps [rsp+0xE0], xmm15
00007588ecddc016  sub rsp, 0x40
00007588ecddc01a  lea rdi, [rsp]
00007588ecddc01e  lea rsi, [rsp+0x10]
00007588ecddc023  lea rdx, [rsp+0x20]
00007588ecddc028  lea rcx, [rsp+0x30]
00007588ecddc02d  mov r8d, 0x00
00007588ecddc033  lea r9, [r15+0x3A8]
00007588ecddc03a  movaps [rdi], xmm10
00007588ecddc03e  movaps [rsi], xmm5
00007588ecddc041  movaps [rdx], xmm12
00007588ecddc045  movaps [rcx], xmm1
00007588ecddc048  mov rax, 0x6516BF3BBA50
00007588ecddc052  call rax
00007588ecddc054  movaps xmm10, [rsp]
00007588ecddc059  add rsp, 0x40
00007588ecddc05d  vmovaps xmm0, [rsp]
00007588ecddc062  vmovaps xmm1, [rsp+0x10]
00007588ecddc068  vmovaps xmm2, [rsp+0x20]
00007588ecddc06e  vmovaps xmm3, [rsp+0x30]
00007588ecddc074  vmovaps xmm4, [rsp+0x40]
00007588ecddc07a  vmovaps xmm5, [rsp+0x50]
00007588ecddc080  vmovaps xmm6, [rsp+0x60]
00007588ecddc086  vmovaps xmm7, [rsp+0x70]
00007588ecddc08c  vmovaps xmm8, [rsp+0x80]
00007588ecddc095  vmovaps xmm9, [rsp+0x90]
00007588ecddc09e  vmovaps xmm11, [rsp+0xA0]
00007588ecddc0a7  vmovaps xmm12, [rsp+0xB0]
00007588ecddc0b0  vmovaps xmm13, [rsp+0xC0]
00007588ecddc0b9  vmovaps xmm14, [rsp+0xD0]
00007588ecddc0c2  vmovaps xmm15, [rsp+0xE0]
00007588ecddc0cb  add rsp, 0xF0
00007588ecddc0d2  pop r11
00007588ecddc0d4  pop r10
00007588ecddc0d6  pop r9
00007588ecddc0d8  pop r8
00007588ecddc0da  pop rsi
00007588ecddc0db  pop rdi
00007588ecddc0dc  pop rdx
00007588ecddc0dd  pop rcx
00007588ecddc0de  pop rax
00007588ecddc0df  add rsp, 0x08
00007588ecddc0e3  jmp 0x00007588ECDDA3B0
00007588ecddc0e8  sub rsp, 0x08
00007588ecddc0ec  push rax
00007588ecddc0ed  push rcx
00007588ecddc0ee  push rdx
00007588ecddc0ef  push rdi
00007588ecddc0f0  push rsi
00007588ecddc0f1  push r8
00007588ecddc0f3  push r9
00007588ecddc0f5  push r10
00007588ecddc0f7  push r11
00007588ecddc0f9  sub rsp, 0xF0
00007588ecddc100  vmovaps [rsp], xmm0
00007588ecddc105  vmovaps [rsp+0x10], xmm1
00007588ecddc10b  vmovaps [rsp+0x20], xmm2
00007588ecddc111  vmovaps [rsp+0x30], xmm3
00007588ecddc117  vmovaps [rsp+0x40], xmm4
00007588ecddc11d  vmovaps [rsp+0x50], xmm5
00007588ecddc123  vmovaps [rsp+0x60], xmm6
00007588ecddc129  vmovaps [rsp+0x70], xmm7
00007588ecddc12f  vmovaps [rsp+0x80], xmm8
00007588ecddc138  vmovaps [rsp+0x90], xmm9
00007588ecddc141  vmovaps [rsp+0xA0], xmm10
00007588ecddc14a  vmovaps [rsp+0xB0], xmm11
00007588ecddc153  vmovaps [rsp+0xC0], xmm13
00007588ecddc15c  vmovaps [rsp+0xD0], xmm14
00007588ecddc165  vmovaps [rsp+0xE0], xmm15
00007588ecddc16e  sub rsp, 0x40
00007588ecddc172  lea rdi, [rsp]
00007588ecddc176  lea rsi, [rsp+0x10]
00007588ecddc17b  lea rdx, [rsp+0x20]
00007588ecddc180  lea rcx, [rsp+0x30]
00007588ecddc185  mov r8d, 0x00
00007588ecddc18b  lea r9, [r15+0x3A8]
00007588ecddc192  movaps [rdi], xmm12
00007588ecddc196  movaps [rsi], xmm7
00007588ecddc199  movaps [rdx], xmm15
00007588ecddc19d  movaps [rcx], xmm1
00007588ecddc1a0  mov rax, 0x6516BF3BBA50
00007588ecddc1aa  call rax
00007588ecddc1ac  movaps xmm12, [rsp]
00007588ecddc1b1  add rsp, 0x40
00007588ecddc1b5  vmovaps xmm0, [rsp]
00007588ecddc1ba  vmovaps xmm1, [rsp+0x10]
00007588ecddc1c0  vmovaps xmm2, [rsp+0x20]
00007588ecddc1c6  vmovaps xmm3, [rsp+0x30]
00007588ecddc1cc  vmovaps xmm4, [rsp+0x40]
00007588ecddc1d2  vmovaps xmm5, [rsp+0x50]
00007588ecddc1d8  vmovaps xmm6, [rsp+0x60]
00007588ecddc1de  vmovaps xmm7, [rsp+0x70]
00007588ecddc1e4  vmovaps xmm8, [rsp+0x80]
00007588ecddc1ed  vmovaps xmm9, [rsp+0x90]
00007588ecddc1f6  vmovaps xmm10, [rsp+0xA0]
00007588ecddc1ff  vmovaps xmm11, [rsp+0xB0]
00007588ecddc208  vmovaps xmm13, [rsp+0xC0]
00007588ecddc211  vmovaps xmm14, [rsp+0xD0]
00007588ecddc21a  vmovaps xmm15, [rsp+0xE0]
00007588ecddc223  add rsp, 0xF0
00007588ecddc22a  pop r11
00007588ecddc22c  pop r10
00007588ecddc22e  pop r9
00007588ecddc230  pop r8
00007588ecddc232  pop rsi
00007588ecddc233  pop rdi
00007588ecddc234  pop rdx
00007588ecddc235  pop rcx
00007588ecddc236  pop rax
00007588ecddc237  add rsp, 0x08
00007588ecddc23b  jmp 0x00007588ECDDA3D9
00007588ecddc240  call 0x00007588ECBFF430
00007588ecddc245  jmp 0x00007588ECDDA3E3
00007588ecddc24a  call 0x00007588ECC0E760
00007588ecddc24f  jmp 0x00007588ECDDA3ED
00007588ecddc254  sub rsp, 0x08
00007588ecddc258  push rax
00007588ecddc259  push rcx
00007588ecddc25a  push rdx
00007588ecddc25b  push rdi
00007588ecddc25c  push rsi
00007588ecddc25d  push r8
00007588ecddc25f  push r9
00007588ecddc261  push r10
00007588ecddc263  push r11
00007588ecddc265  sub rsp, 0xF0
00007588ecddc26c  vmovaps [rsp], xmm0
00007588ecddc271  vmovaps [rsp+0x10], xmm1
00007588ecddc277  vmovaps [rsp+0x20], xmm2
00007588ecddc27d  vmovaps [rsp+0x30], xmm3
00007588ecddc283  vmovaps [rsp+0x40], xmm4
00007588ecddc289  vmovaps [rsp+0x50], xmm5
00007588ecddc28f  vmovaps [rsp+0x60], xmm6
00007588ecddc295  vmovaps [rsp+0x70], xmm8
00007588ecddc29b  vmovaps [rsp+0x80], xmm9
00007588ecddc2a4  vmovaps [rsp+0x90], xmm10
00007588ecddc2ad  vmovaps [rsp+0xA0], xmm11
00007588ecddc2b6  vmovaps [rsp+0xB0], xmm12
00007588ecddc2bf  vmovaps [rsp+0xC0], xmm13
00007588ecddc2c8  vmovaps [rsp+0xD0], xmm14
00007588ecddc2d1  vmovaps [rsp+0xE0], xmm15
00007588ecddc2da  sub rsp, 0x40
00007588ecddc2de  lea rdi, [rsp]
00007588ecddc2e2  lea rsi, [rsp+0x10]
00007588ecddc2e7  lea rdx, [rsp+0x20]
00007588ecddc2ec  lea rcx, [rsp+0x30]
00007588ecddc2f1  mov r8d, 0x00
00007588ecddc2f7  lea r9, [r15+0x3A8]
00007588ecddc2fe  movaps [rdi], xmm7
00007588ecddc301  movaps [rsi], xmm2
00007588ecddc304  movaps [rdx], xmm9
00007588ecddc308  movaps [rcx], xmm11
00007588ecddc30c  mov rax, 0x6516BF3BBA50
00007588ecddc316  call rax
00007588ecddc318  movaps xmm7, [rsp]
00007588ecddc31c  add rsp, 0x40
00007588ecddc320  vmovaps xmm0, [rsp]
00007588ecddc325  vmovaps xmm1, [rsp+0x10]
00007588ecddc32b  vmovaps xmm2, [rsp+0x20]
00007588ecddc331  vmovaps xmm3, [rsp+0x30]
00007588ecddc337  vmovaps xmm4, [rsp+0x40]
00007588ecddc33d  vmovaps xmm5, [rsp+0x50]
00007588ecddc343  vmovaps xmm6, [rsp+0x60]
00007588ecddc349  vmovaps xmm8, [rsp+0x70]
00007588ecddc34f  vmovaps xmm9, [rsp+0x80]
00007588ecddc358  vmovaps xmm10, [rsp+0x90]
00007588ecddc361  vmovaps xmm11, [rsp+0xA0]
00007588ecddc36a  vmovaps xmm12, [rsp+0xB0]
00007588ecddc373  vmovaps xmm13, [rsp+0xC0]
00007588ecddc37c  vmovaps xmm14, [rsp+0xD0]
00007588ecddc385  vmovaps xmm15, [rsp+0xE0]
00007588ecddc38e  add rsp, 0xF0
00007588ecddc395  pop r11
00007588ecddc397  pop r10
00007588ecddc399  pop r9
00007588ecddc39b  pop r8
00007588ecddc39d  pop rsi
00007588ecddc39e  pop rdi
00007588ecddc39f  pop rdx
00007588ecddc3a0  pop rcx
00007588ecddc3a1  pop rax
00007588ecddc3a2  add rsp, 0x08
00007588ecddc3a6  jmp 0x00007588ECDDA421
00007588ecddc3ab  sub rsp, 0x08
00007588ecddc3af  push rax
00007588ecddc3b0  push rcx
00007588ecddc3b1  push rdx
00007588ecddc3b2  push rdi
00007588ecddc3b3  push rsi
00007588ecddc3b4  push r8
00007588ecddc3b6  push r9
00007588ecddc3b8  push r10
00007588ecddc3ba  push r11
00007588ecddc3bc  sub rsp, 0xF0
00007588ecddc3c3  vmovaps [rsp], xmm0
00007588ecddc3c8  vmovaps [rsp+0x10], xmm1
00007588ecddc3ce  vmovaps [rsp+0x20], xmm2
00007588ecddc3d4  vmovaps [rsp+0x30], xmm3
00007588ecddc3da  vmovaps [rsp+0x40], xmm4
00007588ecddc3e0  vmovaps [rsp+0x50], xmm5
00007588ecddc3e6  vmovaps [rsp+0x60], xmm6
00007588ecddc3ec  vmovaps [rsp+0x70], xmm7
00007588ecddc3f2  vmovaps [rsp+0x80], xmm8
00007588ecddc3fb  vmovaps [rsp+0x90], xmm10
00007588ecddc404  vmovaps [rsp+0xA0], xmm11
00007588ecddc40d  vmovaps [rsp+0xB0], xmm12
00007588ecddc416  vmovaps [rsp+0xC0], xmm13
00007588ecddc41f  vmovaps [rsp+0xD0], xmm14
00007588ecddc428  vmovaps [rsp+0xE0], xmm15
00007588ecddc431  sub rsp, 0x40
00007588ecddc435  lea rdi, [rsp]
00007588ecddc439  lea rsi, [rsp+0x10]
00007588ecddc43e  lea rdx, [rsp+0x20]
00007588ecddc443  lea rcx, [rsp+0x30]
00007588ecddc448  mov r8d, 0x00
00007588ecddc44e  lea r9, [r15+0x3A8]
00007588ecddc455  movaps [rdi], xmm9
00007588ecddc459  movaps [rsi], xmm6
00007588ecddc45c  movaps [rdx], xmm1
00007588ecddc45f  movaps [rcx], xmm11
00007588ecddc463  mov rax, 0x6516BF3BBA50
00007588ecddc46d  call rax
00007588ecddc46f  movaps xmm9, [rsp]
00007588ecddc474  add rsp, 0x40
00007588ecddc478  vmovaps xmm0, [rsp]
00007588ecddc47d  vmovaps xmm1, [rsp+0x10]
00007588ecddc483  vmovaps xmm2, [rsp+0x20]
00007588ecddc489  vmovaps xmm3, [rsp+0x30]
00007588ecddc48f  vmovaps xmm4, [rsp+0x40]
00007588ecddc495  vmovaps xmm5, [rsp+0x50]
00007588ecddc49b  vmovaps xmm6, [rsp+0x60]
00007588ecddc4a1  vmovaps xmm7, [rsp+0x70]
00007588ecddc4a7  vmovaps xmm8, [rsp+0x80]
00007588ecddc4b0  vmovaps xmm10, [rsp+0x90]
00007588ecddc4b9  vmovaps xmm11, [rsp+0xA0]
00007588ecddc4c2  vmovaps xmm12, [rsp+0xB0]
00007588ecddc4cb  vmovaps xmm13, [rsp+0xC0]
00007588ecddc4d4  vmovaps xmm14, [rsp+0xD0]
00007588ecddc4dd  vmovaps xmm15, [rsp+0xE0]
00007588ecddc4e6  add rsp, 0xF0
00007588ecddc4ed  pop r11
00007588ecddc4ef  pop r10
00007588ecddc4f1  pop r9
00007588ecddc4f3  pop r8
00007588ecddc4f5  pop rsi
00007588ecddc4f6  pop rdi
00007588ecddc4f7  pop rdx
00007588ecddc4f8  pop rcx
00007588ecddc4f9  pop rax
00007588ecddc4fa  add rsp, 0x08
00007588ecddc4fe  jmp 0x00007588ECDDA447
00007588ecddc503  sub rsp, 0x08
00007588ecddc507  push rax
00007588ecddc508  push rcx
00007588ecddc509  push rdx
00007588ecddc50a  push rdi
00007588ecddc50b  push rsi
00007588ecddc50c  push r8
00007588ecddc50e  push r9
00007588ecddc510  push r10
00007588ecddc512  push r11
00007588ecddc514  sub rsp, 0xF0
00007588ecddc51b  vmovaps [rsp], xmm0
00007588ecddc520  vmovaps [rsp+0x10], xmm1
00007588ecddc526  vmovaps [rsp+0x20], xmm2
00007588ecddc52c  vmovaps [rsp+0x30], xmm3
00007588ecddc532  vmovaps [rsp+0x40], xmm4
00007588ecddc538  vmovaps [rsp+0x50], xmm5
00007588ecddc53e  vmovaps [rsp+0x60], xmm6
00007588ecddc544  vmovaps [rsp+0x70], xmm7
00007588ecddc54a  vmovaps [rsp+0x80], xmm8
00007588ecddc553  vmovaps [rsp+0x90], xmm9
00007588ecddc55c  vmovaps [rsp+0xA0], xmm10
00007588ecddc565  vmovaps [rsp+0xB0], xmm12
00007588ecddc56e  vmovaps [rsp+0xC0], xmm13
00007588ecddc577  vmovaps [rsp+0xD0], xmm14
00007588ecddc580  vmovaps [rsp+0xE0], xmm15
00007588ecddc589  sub rsp, 0x40
00007588ecddc58d  lea rdi, [rsp]
00007588ecddc591  lea rsi, [rsp+0x10]
00007588ecddc596  lea rdx, [rsp+0x20]
00007588ecddc59b  lea rcx, [rsp+0x30]
00007588ecddc5a0  mov r8d, 0x00
00007588ecddc5a6  lea r9, [r15+0x3A8]
00007588ecddc5ad  movaps [rdi], xmm11
00007588ecddc5b1  movaps [rsi], xmm10
00007588ecddc5b5  movaps [rdx], xmm8
00007588ecddc5b9  movaps [rcx], xmm1
00007588ecddc5bc  mov rax, 0x6516BF3BBA50
00007588ecddc5c6  call rax
00007588ecddc5c8  movaps xmm11, [rsp]
00007588ecddc5cd  add rsp, 0x40
00007588ecddc5d1  vmovaps xmm0, [rsp]
00007588ecddc5d6  vmovaps xmm1, [rsp+0x10]
00007588ecddc5dc  vmovaps xmm2, [rsp+0x20]
00007588ecddc5e2  vmovaps xmm3, [rsp+0x30]
00007588ecddc5e8  vmovaps xmm4, [rsp+0x40]
00007588ecddc5ee  vmovaps xmm5, [rsp+0x50]
00007588ecddc5f4  vmovaps xmm6, [rsp+0x60]
00007588ecddc5fa  vmovaps xmm7, [rsp+0x70]
00007588ecddc600  vmovaps xmm8, [rsp+0x80]
00007588ecddc609  vmovaps xmm9, [rsp+0x90]
00007588ecddc612  vmovaps xmm10, [rsp+0xA0]
00007588ecddc61b  vmovaps xmm12, [rsp+0xB0]
00007588ecddc624  vmovaps xmm13, [rsp+0xC0]
00007588ecddc62d  vmovaps xmm14, [rsp+0xD0]
00007588ecddc636  vmovaps xmm15, [rsp+0xE0]
00007588ecddc63f  add rsp, 0xF0
00007588ecddc646  pop r11
00007588ecddc648  pop r10
00007588ecddc64a  pop r9
00007588ecddc64c  pop r8
00007588ecddc64e  pop rsi
00007588ecddc64f  pop rdi
00007588ecddc650  pop rdx
00007588ecddc651  pop rcx
00007588ecddc652  pop rax
00007588ecddc653  add rsp, 0x08
00007588ecddc657  jmp 0x00007588ECDDA46D
00007588ecddc65c  sub rsp, 0x08
00007588ecddc660  push rax
00007588ecddc661  push rcx
00007588ecddc662  push rdx
00007588ecddc663  push rdi
00007588ecddc664  push rsi
00007588ecddc665  push r8
00007588ecddc667  push r9
00007588ecddc669  push r10
00007588ecddc66b  push r11
00007588ecddc66d  sub rsp, 0xF0
00007588ecddc674  vmovaps [rsp], xmm0
00007588ecddc679  vmovaps [rsp+0x10], xmm1
00007588ecddc67f  vmovaps [rsp+0x20], xmm2
00007588ecddc685  vmovaps [rsp+0x30], xmm3
00007588ecddc68b  vmovaps [rsp+0x40], xmm4
00007588ecddc691  vmovaps [rsp+0x50], xmm5
00007588ecddc697  vmovaps [rsp+0x60], xmm6
00007588ecddc69d  vmovaps [rsp+0x70], xmm7
00007588ecddc6a3  vmovaps [rsp+0x80], xmm8
00007588ecddc6ac  vmovaps [rsp+0x90], xmm9
00007588ecddc6b5  vmovaps [rsp+0xA0], xmm11
00007588ecddc6be  vmovaps [rsp+0xB0], xmm12
00007588ecddc6c7  vmovaps [rsp+0xC0], xmm13
00007588ecddc6d0  vmovaps [rsp+0xD0], xmm14
00007588ecddc6d9  vmovaps [rsp+0xE0], xmm15
00007588ecddc6e2  sub rsp, 0x40
00007588ecddc6e6  lea rdi, [rsp]
00007588ecddc6ea  lea rsi, [rsp+0x10]
00007588ecddc6ef  lea rdx, [rsp+0x20]
00007588ecddc6f4  lea rcx, [rsp+0x30]
00007588ecddc6f9  mov r8d, 0x00
00007588ecddc6ff  lea r9, [r15+0x3A8]
00007588ecddc706  movaps [rdi], xmm10
00007588ecddc70a  movaps [rsi], xmm12
00007588ecddc70e  movaps [rdx], xmm13
00007588ecddc712  movaps [rcx], xmm1
00007588ecddc715  mov rax, 0x6516BF3BBA50
00007588ecddc71f  call rax
00007588ecddc721  movaps xmm10, [rsp]
00007588ecddc726  add rsp, 0x40
00007588ecddc72a  vmovaps xmm0, [rsp]
00007588ecddc72f  vmovaps xmm1, [rsp+0x10]
00007588ecddc735  vmovaps xmm2, [rsp+0x20]
00007588ecddc73b  vmovaps xmm3, [rsp+0x30]
00007588ecddc741  vmovaps xmm4, [rsp+0x40]
00007588ecddc747  vmovaps xmm5, [rsp+0x50]
00007588ecddc74d  vmovaps xmm6, [rsp+0x60]
00007588ecddc753  vmovaps xmm7, [rsp+0x70]
00007588ecddc759  vmovaps xmm8, [rsp+0x80]
00007588ecddc762  vmovaps xmm9, [rsp+0x90]
00007588ecddc76b  vmovaps xmm11, [rsp+0xA0]
00007588ecddc774  vmovaps xmm12, [rsp+0xB0]
00007588ecddc77d  vmovaps xmm13, [rsp+0xC0]
00007588ecddc786  vmovaps xmm14, [rsp+0xD0]
00007588ecddc78f  vmovaps xmm15, [rsp+0xE0]
00007588ecddc798  add rsp, 0xF0
00007588ecddc79f  pop r11
00007588ecddc7a1  pop r10
00007588ecddc7a3  pop r9
00007588ecddc7a5  pop r8
00007588ecddc7a7  pop rsi
00007588ecddc7a8  pop rdi
00007588ecddc7a9  pop rdx
00007588ecddc7aa  pop rcx
00007588ecddc7ab  pop rax
00007588ecddc7ac  add rsp, 0x08
00007588ecddc7b0  jmp 0x00007588ECDDA493
00007588ecddc7b5  call 0x00007588ECBFF430
00007588ecddc7ba  jmp 0x00007588ECDDA49D
00007588ecddc7bf  call 0x00007588ECC0C260
00007588ecddc7c4  jmp 0x00007588ECDDA4A7
00007588ecddc7c9  sub rsp, 0x08
00007588ecddc7cd  push rax
00007588ecddc7ce  push rcx
00007588ecddc7cf  push rdx
00007588ecddc7d0  push rdi
00007588ecddc7d1  push rsi
00007588ecddc7d2  push r8
00007588ecddc7d4  push r9
00007588ecddc7d6  push r10
00007588ecddc7d8  push r11
00007588ecddc7da  sub rsp, 0xF0
00007588ecddc7e1  vmovaps [rsp], xmm0
00007588ecddc7e6  vmovaps [rsp+0x10], xmm1
00007588ecddc7ec  vmovaps [rsp+0x20], xmm2
00007588ecddc7f2  vmovaps [rsp+0x30], xmm3
00007588ecddc7f8  vmovaps [rsp+0x40], xmm4
00007588ecddc7fe  vmovaps [rsp+0x50], xmm5
00007588ecddc804  vmovaps [rsp+0x60], xmm6
00007588ecddc80a  vmovaps [rsp+0x70], xmm7
00007588ecddc810  vmovaps [rsp+0x80], xmm9
00007588ecddc819  vmovaps [rsp+0x90], xmm10
00007588ecddc822  vmovaps [rsp+0xA0], xmm11
00007588ecddc82b  vmovaps [rsp+0xB0], xmm12
00007588ecddc834  vmovaps [rsp+0xC0], xmm13
00007588ecddc83d  vmovaps [rsp+0xD0], xmm14
00007588ecddc846  vmovaps [rsp+0xE0], xmm15
00007588ecddc84f  sub rsp, 0x40
00007588ecddc853  lea rdi, [rsp]
00007588ecddc857  lea rsi, [rsp+0x10]
00007588ecddc85c  lea rdx, [rsp+0x20]
00007588ecddc861  lea rcx, [rsp+0x30]
00007588ecddc866  mov r8d, 0x00
00007588ecddc86c  lea r9, [r15+0x3A8]
00007588ecddc873  movaps [rdi], xmm8
00007588ecddc877  movaps [rsi], xmm7
00007588ecddc87a  movaps [rdx], xmm4
00007588ecddc87d  movaps [rcx], xmm12
00007588ecddc881  mov rax, 0x6516BF3BBA50
00007588ecddc88b  call rax
00007588ecddc88d  movaps xmm8, [rsp]
00007588ecddc892  add rsp, 0x40
00007588ecddc896  vmovaps xmm0, [rsp]
00007588ecddc89b  vmovaps xmm1, [rsp+0x10]
00007588ecddc8a1  vmovaps xmm2, [rsp+0x20]
00007588ecddc8a7  vmovaps xmm3, [rsp+0x30]
00007588ecddc8ad  vmovaps xmm4, [rsp+0x40]
00007588ecddc8b3  vmovaps xmm5, [rsp+0x50]
00007588ecddc8b9  vmovaps xmm6, [rsp+0x60]
00007588ecddc8bf  vmovaps xmm7, [rsp+0x70]
00007588ecddc8c5  vmovaps xmm9, [rsp+0x80]
00007588ecddc8ce  vmovaps xmm10, [rsp+0x90]
00007588ecddc8d7  vmovaps xmm11, [rsp+0xA0]
00007588ecddc8e0  vmovaps xmm12, [rsp+0xB0]
00007588ecddc8e9  vmovaps xmm13, [rsp+0xC0]
00007588ecddc8f2  vmovaps xmm14, [rsp+0xD0]
00007588ecddc8fb  vmovaps xmm15, [rsp+0xE0]
00007588ecddc904  add rsp, 0xF0
00007588ecddc90b  pop r11
00007588ecddc90d  pop r10
00007588ecddc90f  pop r9
00007588ecddc911  pop r8
00007588ecddc913  pop rsi
00007588ecddc914  pop rdi
00007588ecddc915  pop rdx
00007588ecddc916  pop rcx
00007588ecddc917  pop rax
00007588ecddc918  add rsp, 0x08
00007588ecddc91c  jmp 0x00007588ECDDA4D0
00007588ecddc921  sub rsp, 0x08
00007588ecddc925  push rax
00007588ecddc926  push rcx
00007588ecddc927  push rdx
00007588ecddc928  push rdi
00007588ecddc929  push rsi
00007588ecddc92a  push r8
00007588ecddc92c  push r9
00007588ecddc92e  push r10
00007588ecddc930  push r11
00007588ecddc932  sub rsp, 0xF0
00007588ecddc939  vmovaps [rsp], xmm0
00007588ecddc93e  vmovaps [rsp+0x10], xmm1
00007588ecddc944  vmovaps [rsp+0x20], xmm2
00007588ecddc94a  vmovaps [rsp+0x30], xmm3
00007588ecddc950  vmovaps [rsp+0x40], xmm4
00007588ecddc956  vmovaps [rsp+0x50], xmm5
00007588ecddc95c  vmovaps [rsp+0x60], xmm6
00007588ecddc962  vmovaps [rsp+0x70], xmm8
00007588ecddc968  vmovaps [rsp+0x80], xmm9
00007588ecddc971  vmovaps [rsp+0x90], xmm10
00007588ecddc97a  vmovaps [rsp+0xA0], xmm11
00007588ecddc983  vmovaps [rsp+0xB0], xmm12
00007588ecddc98c  vmovaps [rsp+0xC0], xmm13
00007588ecddc995  vmovaps [rsp+0xD0], xmm14
00007588ecddc99e  vmovaps [rsp+0xE0], xmm15
00007588ecddc9a7  sub rsp, 0x40
00007588ecddc9ab  lea rdi, [rsp]
00007588ecddc9af  lea rsi, [rsp+0x10]
00007588ecddc9b4  lea rdx, [rsp+0x20]
00007588ecddc9b9  lea rcx, [rsp+0x30]
00007588ecddc9be  mov r8d, 0x00
00007588ecddc9c4  lea r9, [r15+0x3A8]
00007588ecddc9cb  movaps [rdi], xmm7
00007588ecddc9ce  movaps [rsi], xmm9
00007588ecddc9d2  movaps [rdx], xmm14
00007588ecddc9d6  movaps [rcx], xmm12
00007588ecddc9da  mov rax, 0x6516BF3BBA50
00007588ecddc9e4  call rax
00007588ecddc9e6  movaps xmm7, [rsp]
00007588ecddc9ea  add rsp, 0x40
00007588ecddc9ee  vmovaps xmm0, [rsp]
00007588ecddc9f3  vmovaps xmm1, [rsp+0x10]
00007588ecddc9f9  vmovaps xmm2, [rsp+0x20]
00007588ecddc9ff  vmovaps xmm3, [rsp+0x30]
00007588ecddca05  vmovaps xmm4, [rsp+0x40]
00007588ecddca0b  vmovaps xmm5, [rsp+0x50]
00007588ecddca11  vmovaps xmm6, [rsp+0x60]
00007588ecddca17  vmovaps xmm8, [rsp+0x70]
00007588ecddca1d  vmovaps xmm9, [rsp+0x80]
00007588ecddca26  vmovaps xmm10, [rsp+0x90]
00007588ecddca2f  vmovaps xmm11, [rsp+0xA0]
00007588ecddca38  vmovaps xmm12, [rsp+0xB0]
00007588ecddca41  vmovaps xmm13, [rsp+0xC0]
00007588ecddca4a  vmovaps xmm14, [rsp+0xD0]
00007588ecddca53  vmovaps xmm15, [rsp+0xE0]
00007588ecddca5c  add rsp, 0xF0
00007588ecddca63  pop r11
00007588ecddca65  pop r10
00007588ecddca67  pop r9
00007588ecddca69  pop r8
00007588ecddca6b  pop rsi
00007588ecddca6c  pop rdi
00007588ecddca6d  pop rdx
00007588ecddca6e  pop rcx
00007588ecddca6f  pop rax
00007588ecddca70  add rsp, 0x08
00007588ecddca74  jmp 0x00007588ECDDA4F8
00007588ecddca79  sub rsp, 0x08
00007588ecddca7d  push rax
00007588ecddca7e  push rcx
00007588ecddca7f  push rdx
00007588ecddca80  push rdi
00007588ecddca81  push rsi
00007588ecddca82  push r8
00007588ecddca84  push r9
00007588ecddca86  push r10
00007588ecddca88  push r11
00007588ecddca8a  sub rsp, 0xF0
00007588ecddca91  vmovaps [rsp], xmm0
00007588ecddca96  vmovaps [rsp+0x10], xmm1
00007588ecddca9c  vmovaps [rsp+0x20], xmm2
00007588ecddcaa2  vmovaps [rsp+0x30], xmm3
00007588ecddcaa8  vmovaps [rsp+0x40], xmm4
00007588ecddcaae  vmovaps [rsp+0x50], xmm5
00007588ecddcab4  vmovaps [rsp+0x60], xmm6
00007588ecddcaba  vmovaps [rsp+0x70], xmm7
00007588ecddcac0  vmovaps [rsp+0x80], xmm8
00007588ecddcac9  vmovaps [rsp+0x90], xmm9
00007588ecddcad2  vmovaps [rsp+0xA0], xmm10
00007588ecddcadb  vmovaps [rsp+0xB0], xmm11
00007588ecddcae4  vmovaps [rsp+0xC0], xmm13
00007588ecddcaed  vmovaps [rsp+0xD0], xmm14
00007588ecddcaf6  vmovaps [rsp+0xE0], xmm15
00007588ecddcaff  sub rsp, 0x40
00007588ecddcb03  lea rdi, [rsp]
00007588ecddcb07  lea rsi, [rsp+0x10]
00007588ecddcb0c  lea rdx, [rsp+0x20]
00007588ecddcb11  lea rcx, [rsp+0x30]
00007588ecddcb16  mov r8d, 0x00
00007588ecddcb1c  lea r9, [r15+0x3A8]
00007588ecddcb23  movaps [rdi], xmm12
00007588ecddcb27  movaps [rsi], xmm11
00007588ecddcb2b  movaps [rdx], xmm15
00007588ecddcb2f  movaps [rcx], xmm14
00007588ecddcb33  mov rax, 0x6516BF3BBA50
00007588ecddcb3d  call rax
00007588ecddcb3f  movaps xmm12, [rsp]
00007588ecddcb44  add rsp, 0x40
00007588ecddcb48  vmovaps xmm0, [rsp]
00007588ecddcb4d  vmovaps xmm1, [rsp+0x10]
00007588ecddcb53  vmovaps xmm2, [rsp+0x20]
00007588ecddcb59  vmovaps xmm3, [rsp+0x30]
00007588ecddcb5f  vmovaps xmm4, [rsp+0x40]
00007588ecddcb65  vmovaps xmm5, [rsp+0x50]
00007588ecddcb6b  vmovaps xmm6, [rsp+0x60]
00007588ecddcb71  vmovaps xmm7, [rsp+0x70]
00007588ecddcb77  vmovaps xmm8, [rsp+0x80]
00007588ecddcb80  vmovaps xmm9, [rsp+0x90]
00007588ecddcb89  vmovaps xmm10, [rsp+0xA0]
00007588ecddcb92  vmovaps xmm11, [rsp+0xB0]
00007588ecddcb9b  vmovaps xmm13, [rsp+0xC0]
00007588ecddcba4  vmovaps xmm14, [rsp+0xD0]
00007588ecddcbad  vmovaps xmm15, [rsp+0xE0]
00007588ecddcbb6  add rsp, 0xF0
00007588ecddcbbd  pop r11
00007588ecddcbbf  pop r10
00007588ecddcbc1  pop r9
00007588ecddcbc3  pop r8
00007588ecddcbc5  pop rsi
00007588ecddcbc6  pop rdi
00007588ecddcbc7  pop rdx
00007588ecddcbc8  pop rcx
00007588ecddcbc9  pop rax
00007588ecddcbca  add rsp, 0x08
00007588ecddcbce  jmp 0x00007588ECDDA521
00007588ecddcbd3  sub rsp, 0x08
00007588ecddcbd7  push rax
00007588ecddcbd8  push rcx
00007588ecddcbd9  push rdx
00007588ecddcbda  push rdi
00007588ecddcbdb  push rsi
00007588ecddcbdc  push r8
00007588ecddcbde  push r9
00007588ecddcbe0  push r10
00007588ecddcbe2  push r11
00007588ecddcbe4  sub rsp, 0xF0
00007588ecddcbeb  vmovaps [rsp], xmm0
00007588ecddcbf0  vmovaps [rsp+0x10], xmm1
00007588ecddcbf6  vmovaps [rsp+0x20], xmm2
00007588ecddcbfc  vmovaps [rsp+0x30], xmm3
00007588ecddcc02  vmovaps [rsp+0x40], xmm4
00007588ecddcc08  vmovaps [rsp+0x50], xmm5
00007588ecddcc0e  vmovaps [rsp+0x60], xmm6
00007588ecddcc14  vmovaps [rsp+0x70], xmm7
00007588ecddcc1a  vmovaps [rsp+0x80], xmm8
00007588ecddcc23  vmovaps [rsp+0x90], xmm9
00007588ecddcc2c  vmovaps [rsp+0xA0], xmm10
00007588ecddcc35  vmovaps [rsp+0xB0], xmm12
00007588ecddcc3e  vmovaps [rsp+0xC0], xmm13
00007588ecddcc47  vmovaps [rsp+0xD0], xmm14
00007588ecddcc50  vmovaps [rsp+0xE0], xmm15
00007588ecddcc59  sub rsp, 0x40
00007588ecddcc5d  lea rdi, [rsp]
00007588ecddcc61  lea rsi, [rsp+0x10]
00007588ecddcc66  lea rdx, [rsp+0x20]
00007588ecddcc6b  lea rcx, [rsp+0x30]
00007588ecddcc70  mov r8d, 0x00
00007588ecddcc76  lea r9, [r15+0x3A8]
00007588ecddcc7d  movaps [rdi], xmm11
00007588ecddcc81  movaps [rsi], xmm10
00007588ecddcc85  movaps [rdx], xmm13
00007588ecddcc89  movaps [rcx], xmm15
00007588ecddcc8d  mov rax, 0x6516BF3BBA50
00007588ecddcc97  call rax
00007588ecddcc99  movaps xmm11, [rsp]
00007588ecddcc9e  add rsp, 0x40
00007588ecddcca2  vmovaps xmm0, [rsp]
00007588ecddcca7  vmovaps xmm1, [rsp+0x10]
00007588ecddccad  vmovaps xmm2, [rsp+0x20]
00007588ecddccb3  vmovaps xmm3, [rsp+0x30]
00007588ecddccb9  vmovaps xmm4, [rsp+0x40]
00007588ecddccbf  vmovaps xmm5, [rsp+0x50]
00007588ecddccc5  vmovaps xmm6, [rsp+0x60]
00007588ecddcccb  vmovaps xmm7, [rsp+0x70]
00007588ecddccd1  vmovaps xmm8, [rsp+0x80]
00007588ecddccda  vmovaps xmm9, [rsp+0x90]
00007588ecddcce3  vmovaps xmm10, [rsp+0xA0]
00007588ecddccec  vmovaps xmm12, [rsp+0xB0]
00007588ecddccf5  vmovaps xmm13, [rsp+0xC0]
00007588ecddccfe  vmovaps xmm14, [rsp+0xD0]
00007588ecddcd07  vmovaps xmm15, [rsp+0xE0]
00007588ecddcd10  add rsp, 0xF0
00007588ecddcd17  pop r11
00007588ecddcd19  pop r10
00007588ecddcd1b  pop r9
00007588ecddcd1d  pop r8
00007588ecddcd1f  pop rsi
00007588ecddcd20  pop rdi
00007588ecddcd21  pop rdx
00007588ecddcd22  pop rcx
00007588ecddcd23  pop rax
00007588ecddcd24  add rsp, 0x08
00007588ecddcd28  jmp 0x00007588ECDDA54A
00007588ecddcd2d  call 0x00007588ECC0E760
00007588ecddcd32  jmp 0x00007588ECDDA557
00007588ecddcd37  call 0x00007588ECC0D4E0
00007588ecddcd3c  jmp 0x00007588ECDDA564
00007588ecddcd41  sub rsp, 0x08
00007588ecddcd45  push rax
00007588ecddcd46  push rcx
00007588ecddcd47  push rdx
00007588ecddcd48  push rdi
00007588ecddcd49  push rsi
00007588ecddcd4a  push r8
00007588ecddcd4c  push r9
00007588ecddcd4e  push r10
00007588ecddcd50  push r11
00007588ecddcd52  sub rsp, 0xF0
00007588ecddcd59  vmovaps [rsp], xmm0
00007588ecddcd5e  vmovaps [rsp+0x10], xmm1
00007588ecddcd64  vmovaps [rsp+0x20], xmm2
00007588ecddcd6a  vmovaps [rsp+0x30], xmm3
00007588ecddcd70  vmovaps [rsp+0x40], xmm4
00007588ecddcd76  vmovaps [rsp+0x50], xmm5
00007588ecddcd7c  vmovaps [rsp+0x60], xmm6
00007588ecddcd82  vmovaps [rsp+0x70], xmm7
00007588ecddcd88  vmovaps [rsp+0x80], xmm8
00007588ecddcd91  vmovaps [rsp+0x90], xmm9
00007588ecddcd9a  vmovaps [rsp+0xA0], xmm11
00007588ecddcda3  vmovaps [rsp+0xB0], xmm12
00007588ecddcdac  vmovaps [rsp+0xC0], xmm13
00007588ecddcdb5  vmovaps [rsp+0xD0], xmm14
00007588ecddcdbe  vmovaps [rsp+0xE0], xmm15
00007588ecddcdc7  sub rsp, 0x40
00007588ecddcdcb  lea rdi, [rsp]
00007588ecddcdcf  lea rsi, [rsp+0x10]
00007588ecddcdd4  lea rdx, [rsp+0x20]
00007588ecddcdd9  lea rcx, [rsp+0x30]
00007588ecddcdde  mov r8d, 0x00
00007588ecddcde4  lea r9, [r15+0x3A8]
00007588ecddcdeb  movaps [rdi], xmm10
00007588ecddcdef  movaps [rsi], xmm8
00007588ecddcdf3  movaps [rdx], xmm1
00007588ecddcdf6  movaps [rcx], xmm13
00007588ecddcdfa  mov rax, 0x6516BF3BBA50
00007588ecddce04  call rax
00007588ecddce06  movaps xmm10, [rsp]
00007588ecddce0b  add rsp, 0x40
00007588ecddce0f  vmovaps xmm0, [rsp]
00007588ecddce14  vmovaps xmm1, [rsp+0x10]
00007588ecddce1a  vmovaps xmm2, [rsp+0x20]
00007588ecddce20  vmovaps xmm3, [rsp+0x30]
00007588ecddce26  vmovaps xmm4, [rsp+0x40]
00007588ecddce2c  vmovaps xmm5, [rsp+0x50]
00007588ecddce32  vmovaps xmm6, [rsp+0x60]
00007588ecddce38  vmovaps xmm7, [rsp+0x70]
00007588ecddce3e  vmovaps xmm8, [rsp+0x80]
00007588ecddce47  vmovaps xmm9, [rsp+0x90]
00007588ecddce50  vmovaps xmm11, [rsp+0xA0]
00007588ecddce59  vmovaps xmm12, [rsp+0xB0]
00007588ecddce62  vmovaps xmm13, [rsp+0xC0]
00007588ecddce6b  vmovaps xmm14, [rsp+0xD0]
00007588ecddce74  vmovaps xmm15, [rsp+0xE0]
00007588ecddce7d  add rsp, 0xF0
00007588ecddce84  pop r11
00007588ecddce86  pop r10
00007588ecddce88  pop r9
00007588ecddce8a  pop r8
00007588ecddce8c  pop rsi
00007588ecddce8d  pop rdi
00007588ecddce8e  pop rdx
00007588ecddce8f  pop rcx
00007588ecddce90  pop rax
00007588ecddce91  add rsp, 0x08
00007588ecddce95  jmp 0x00007588ECDDA59A
00007588ecddce9a  call 0x00007588ECBFF430
00007588ecddce9f  jmp 0x00007588ECDDA5AC
00007588ecddcea4  sub rsp, 0x08
00007588ecddcea8  push rax
00007588ecddcea9  push rcx
00007588ecddceaa  push rdx
00007588ecddceab  push rdi
00007588ecddceac  push rsi
00007588ecddcead  push r8
00007588ecddceaf  push r9
00007588ecddceb1  push r10
00007588ecddceb3  push r11
00007588ecddceb5  sub rsp, 0xF0
00007588ecddcebc  vmovaps [rsp], xmm0
00007588ecddcec1  vmovaps [rsp+0x10], xmm1
00007588ecddcec7  vmovaps [rsp+0x20], xmm2
00007588ecddcecd  vmovaps [rsp+0x30], xmm3
00007588ecddced3  vmovaps [rsp+0x40], xmm4
00007588ecddced9  vmovaps [rsp+0x50], xmm5
00007588ecddcedf  vmovaps [rsp+0x60], xmm6
00007588ecddcee5  vmovaps [rsp+0x70], xmm7
00007588ecddceeb  vmovaps [rsp+0x80], xmm8
00007588ecddcef4  vmovaps [rsp+0x90], xmm10
00007588ecddcefd  vmovaps [rsp+0xA0], xmm11
00007588ecddcf06  vmovaps [rsp+0xB0], xmm12
00007588ecddcf0f  vmovaps [rsp+0xC0], xmm13
00007588ecddcf18  vmovaps [rsp+0xD0], xmm14
00007588ecddcf21  vmovaps [rsp+0xE0], xmm15
00007588ecddcf2a  sub rsp, 0x40
00007588ecddcf2e  lea rdi, [rsp]
00007588ecddcf32  lea rsi, [rsp+0x10]
00007588ecddcf37  lea rdx, [rsp+0x20]
00007588ecddcf3c  lea rcx, [rsp+0x30]
00007588ecddcf41  mov r8d, 0x00
00007588ecddcf47  lea r9, [r15+0x3A8]
00007588ecddcf4e  movaps [rdi], xmm9
00007588ecddcf52  movaps [rsi], xmm7
00007588ecddcf55  movaps [rdx], xmm14
00007588ecddcf59  movaps [rcx], xmm13
00007588ecddcf5d  mov rax, 0x6516BF3BBA50
00007588ecddcf67  call rax
00007588ecddcf69  movaps xmm9, [rsp]
00007588ecddcf6e  add rsp, 0x40
00007588ecddcf72  vmovaps xmm0, [rsp]
00007588ecddcf77  vmovaps xmm1, [rsp+0x10]
00007588ecddcf7d  vmovaps xmm2, [rsp+0x20]
00007588ecddcf83  vmovaps xmm3, [rsp+0x30]
00007588ecddcf89  vmovaps xmm4, [rsp+0x40]
00007588ecddcf8f  vmovaps xmm5, [rsp+0x50]
00007588ecddcf95  vmovaps xmm6, [rsp+0x60]
00007588ecddcf9b  vmovaps xmm7, [rsp+0x70]
00007588ecddcfa1  vmovaps xmm8, [rsp+0x80]
00007588ecddcfaa  vmovaps xmm10, [rsp+0x90]
00007588ecddcfb3  vmovaps xmm11, [rsp+0xA0]
00007588ecddcfbc  vmovaps xmm12, [rsp+0xB0]
00007588ecddcfc5  vmovaps xmm13, [rsp+0xC0]
00007588ecddcfce  vmovaps xmm14, [rsp+0xD0]
00007588ecddcfd7  vmovaps xmm15, [rsp+0xE0]
00007588ecddcfe0  add rsp, 0xF0
00007588ecddcfe7  pop r11
00007588ecddcfe9  pop r10
00007588ecddcfeb  pop r9
00007588ecddcfed  pop r8
00007588ecddcfef  pop rsi
00007588ecddcff0  pop rdi
00007588ecddcff1  pop rdx
00007588ecddcff2  pop rcx
00007588ecddcff3  pop rax
00007588ecddcff4  add rsp, 0x08
00007588ecddcff8  jmp 0x00007588ECDDA5DA
00007588ecddcffd  sub rsp, 0x08
00007588ecddd001  push rax
00007588ecddd002  push rcx
00007588ecddd003  push rdx
00007588ecddd004  push rdi
00007588ecddd005  push rsi
00007588ecddd006  push r8
00007588ecddd008  push r9
00007588ecddd00a  push r10
00007588ecddd00c  push r11
00007588ecddd00e  sub rsp, 0xF0
00007588ecddd015  vmovaps [rsp], xmm0
00007588ecddd01a  vmovaps [rsp+0x10], xmm1
00007588ecddd020  vmovaps [rsp+0x20], xmm2
00007588ecddd026  vmovaps [rsp+0x30], xmm3
00007588ecddd02c  vmovaps [rsp+0x40], xmm4
00007588ecddd032  vmovaps [rsp+0x50], xmm5
00007588ecddd038  vmovaps [rsp+0x60], xmm6
00007588ecddd03e  vmovaps [rsp+0x70], xmm7
00007588ecddd044  vmovaps [rsp+0x80], xmm8
00007588ecddd04d  vmovaps [rsp+0x90], xmm9
00007588ecddd056  vmovaps [rsp+0xA0], xmm10
00007588ecddd05f  vmovaps [rsp+0xB0], xmm11
00007588ecddd068  vmovaps [rsp+0xC0], xmm12
00007588ecddd071  vmovaps [rsp+0xD0], xmm14
00007588ecddd07a  vmovaps [rsp+0xE0], xmm15
00007588ecddd083  sub rsp, 0x40
00007588ecddd087  lea rdi, [rsp]
00007588ecddd08b  lea rsi, [rsp+0x10]
00007588ecddd090  lea rdx, [rsp+0x20]
00007588ecddd095  lea rcx, [rsp+0x30]
00007588ecddd09a  mov r8d, 0x00
00007588ecddd0a0  lea r9, [r15+0x3A8]
00007588ecddd0a7  movaps [rdi], xmm13
00007588ecddd0ab  movaps [rsi], xmm12
00007588ecddd0af  movaps [rdx], xmm15
00007588ecddd0b3  movaps [rcx], xmm14
00007588ecddd0b7  mov rax, 0x6516BF3BBA50
00007588ecddd0c1  call rax
00007588ecddd0c3  movaps xmm13, [rsp]
00007588ecddd0c8  add rsp, 0x40
00007588ecddd0cc  vmovaps xmm0, [rsp]
00007588ecddd0d1  vmovaps xmm1, [rsp+0x10]
00007588ecddd0d7  vmovaps xmm2, [rsp+0x20]
00007588ecddd0dd  vmovaps xmm3, [rsp+0x30]
00007588ecddd0e3  vmovaps xmm4, [rsp+0x40]
00007588ecddd0e9  vmovaps xmm5, [rsp+0x50]
00007588ecddd0ef  vmovaps xmm6, [rsp+0x60]
00007588ecddd0f5  vmovaps xmm7, [rsp+0x70]
00007588ecddd0fb  vmovaps xmm8, [rsp+0x80]
00007588ecddd104  vmovaps xmm9, [rsp+0x90]
00007588ecddd10d  vmovaps xmm10, [rsp+0xA0]
00007588ecddd116  vmovaps xmm11, [rsp+0xB0]
00007588ecddd11f  vmovaps xmm12, [rsp+0xC0]
00007588ecddd128  vmovaps xmm14, [rsp+0xD0]
00007588ecddd131  vmovaps xmm15, [rsp+0xE0]
00007588ecddd13a  add rsp, 0xF0
00007588ecddd141  pop r11
00007588ecddd143  pop r10
00007588ecddd145  pop r9
00007588ecddd147  pop r8
00007588ecddd149  pop rsi
00007588ecddd14a  pop rdi
00007588ecddd14b  pop rdx
00007588ecddd14c  pop rcx
00007588ecddd14d  pop rax
00007588ecddd14e  add rsp, 0x08
00007588ecddd152  jmp 0x00007588ECDDA608
00007588ecddd157  sub rsp, 0x08
00007588ecddd15b  push rax
00007588ecddd15c  push rcx
00007588ecddd15d  push rdx
00007588ecddd15e  push rdi
00007588ecddd15f  push rsi
00007588ecddd160  push r8
00007588ecddd162  push r9
00007588ecddd164  push r10
00007588ecddd166  push r11
00007588ecddd168  sub rsp, 0xF0
00007588ecddd16f  vmovaps [rsp], xmm0
00007588ecddd174  vmovaps [rsp+0x10], xmm1
00007588ecddd17a  vmovaps [rsp+0x20], xmm2
00007588ecddd180  vmovaps [rsp+0x30], xmm3
00007588ecddd186  vmovaps [rsp+0x40], xmm4
00007588ecddd18c  vmovaps [rsp+0x50], xmm5
00007588ecddd192  vmovaps [rsp+0x60], xmm6
00007588ecddd198  vmovaps [rsp+0x70], xmm7
00007588ecddd19e  vmovaps [rsp+0x80], xmm8
00007588ecddd1a7  vmovaps [rsp+0x90], xmm9
00007588ecddd1b0  vmovaps [rsp+0xA0], xmm10
00007588ecddd1b9  vmovaps [rsp+0xB0], xmm11
00007588ecddd1c2  vmovaps [rsp+0xC0], xmm12
00007588ecddd1cb  vmovaps [rsp+0xD0], xmm13
00007588ecddd1d4  vmovaps [rsp+0xE0], xmm15
00007588ecddd1dd  sub rsp, 0x40
00007588ecddd1e1  lea rdi, [rsp]
00007588ecddd1e5  lea rsi, [rsp+0x10]
00007588ecddd1ea  lea rdx, [rsp+0x20]
00007588ecddd1ef  lea rcx, [rsp+0x30]
00007588ecddd1f4  mov r8d, 0x00
00007588ecddd1fa  lea r9, [r15+0x3A8]
00007588ecddd201  movaps [rdi], xmm14
00007588ecddd205  movaps [rsi], xmm11
00007588ecddd209  movaps [rdx], xmm1
00007588ecddd20c  movaps [rcx], xmm15
00007588ecddd210  mov rax, 0x6516BF3BBA50
00007588ecddd21a  call rax
00007588ecddd21c  movaps xmm14, [rsp]
00007588ecddd221  add rsp, 0x40
00007588ecddd225  vmovaps xmm0, [rsp]
00007588ecddd22a  vmovaps xmm1, [rsp+0x10]
00007588ecddd230  vmovaps xmm2, [rsp+0x20]
00007588ecddd236  vmovaps xmm3, [rsp+0x30]
00007588ecddd23c  vmovaps xmm4, [rsp+0x40]
00007588ecddd242  vmovaps xmm5, [rsp+0x50]
00007588ecddd248  vmovaps xmm6, [rsp+0x60]
00007588ecddd24e  vmovaps xmm7, [rsp+0x70]
00007588ecddd254  vmovaps xmm8, [rsp+0x80]
00007588ecddd25d  vmovaps xmm9, [rsp+0x90]
00007588ecddd266  vmovaps xmm10, [rsp+0xA0]
00007588ecddd26f  vmovaps xmm11, [rsp+0xB0]
00007588ecddd278  vmovaps xmm12, [rsp+0xC0]
00007588ecddd281  vmovaps xmm13, [rsp+0xD0]
00007588ecddd28a  vmovaps xmm15, [rsp+0xE0]
00007588ecddd293  add rsp, 0xF0
00007588ecddd29a  pop r11
00007588ecddd29c  pop r10
00007588ecddd29e  pop r9
00007588ecddd2a0  pop r8
00007588ecddd2a2  pop rsi
00007588ecddd2a3  pop rdi
00007588ecddd2a4  pop rdx
00007588ecddd2a5  pop rcx
00007588ecddd2a6  pop rax
00007588ecddd2a7  add rsp, 0x08
00007588ecddd2ab  jmp 0x00007588ECDDA636
00007588ecddd2b0  call 0x00007588ECC079B0
00007588ecddd2b5  jmp 0x00007588ECDDA64C
00007588ecddd2ba  call 0x00007588ECCE3440
00007588ecddd2bf  jmp 0x00007588ECDDA656
00007588ecddd2c4  call 0x00007588ECCDFCE0
00007588ecddd2c9  jmp 0x00007588ECDDA660
00007588ecddd2ce  call 0x00007588ECCE46C0
00007588ecddd2d3  jmp 0x00007588ECDDA66A
00007588ecddd2d8  int3
00007588ecddd2d9  nop [rax], eax
00007588ecddd2e0  mov qword ptr [r15+0x40], 0x430000
00007588ecddd2e8  mov eax, 0x430C50
00007588ecddd2ed  mov r14, [r13+rax*1]
00007588ecddd2f2  movq xmm1, r14
00007588ecddd2f7  mov rax, [r15+0x50]
00007588ecddd2fb  movups xmm15, [r13+rax*1]
00007588ecddd301  movaps [r15+0x120], xmm15
00007588ecddd309  mov qword ptr [r15+0x48], 0x10
00007588ecddd311  xor eax, eax
00007588ecddd313  mov r14d, 0x10
00007588ecddd319  mov r12d, 0x200
00007588ecddd31f  cmp r14, r12
00007588ecddd322  cmc
00007588ecddd323  lahf
00007588ecddd324  seto al
00007588ecddd327  mov [r15+0x108], eax
00007588ecddd32e  pextrq rax, xmm15, 0x01
00007588ecddd335  movq xmm14, rax
00007588ecddd33a  movaps [r15+0x130], xmm14
00007588ecddd342  movq rax, xmm1
00007588ecddd347  movq r14, xmm15
00007588ecddd34c  vmovq xmm1, rax
00007588ecddd351  vmovq xmm15, r14
00007588ecddd356  movaps xmm13, xmm1
00007588ecddd35a  addsd xmm13, xmm15
00007588ecddd35f  ucomisd xmm13, xmm13
00007588ecddd364  jp 0x00007588ECDDD423
00007588ecddd36a  movq xmm13, xmm13
00007588ecddd36f  movq rax, xmm13
00007588ecddd374  movq r14, xmm14
00007588ecddd379  vmovq xmm1, rax
00007588ecddd37e  vmovq xmm15, r14
00007588ecddd383  movaps xmm14, xmm1
00007588ecddd387  addsd xmm14, xmm15
00007588ecddd38c  ucomisd xmm14, xmm14
00007588ecddd391  jp 0x00007588ECDDD46B
00007588ecddd397  movq xmm14, xmm14
00007588ecddd39c  movaps [r15+0x110], xmm14
00007588ecddd3a4  mov eax, [r15+0x108]
00007588ecddd3ab  sahf
00007588ecddd3ac  jnz 0x00007588ECDDD3DE
00007588ecddd3ae  cmp dword ptr [r15+0x318], 0x00
00007588ecddd3b6  jz 0x00007588ECDDD680
00007588ecddd3bc  nop [rax+rax*1], ax
00007588ecddd3c5  nop [rax+rax*1], eax
00007588ecddd3cd  mov eax, 0x410698
00007588ecddd3d2  mov [r15+0x100], rax
00007588ecddd3d9  jmp 0x00007588ECBFE110
00007588ecddd3de  cmp dword ptr [r15+0x318], 0x00
00007588ecddd3e6  jz 0x00007588ECDDD4C0
00007588ecddd3ec  nop [rax+rax*1], ax
00007588ecddd3f5  nop [rax+rax*1], eax
00007588ecddd3fd  mov eax, 0x41067C
00007588ecddd402  mov [r15+0x100], rax
00007588ecddd409  jmp 0x00007588ECBFE110
00007588ecddd40e  int3
00007588ecddd40f  call 0x00007588ECC0DC20
00007588ecddd414  jmp 0x00007588ECDDD2F2
00007588ecddd419  call 0x00007588ECC0E760
00007588ecddd41e  jmp 0x00007588ECDDD301
00007588ecddd423  ucomisd xmm1, xmm15
00007588ecddd428  jp 0x00007588ECDDD437
00007588ecddd42a  movaps xmm13, [0x00007588EC9FE060]
00007588ecddd432  jmp 0x00007588ECDDD36A
00007588ecddd437  vxorps xmm0, xmm1, xmm15
00007588ecddd43c  pextrw eax, xmm0, 0x03
00007588ecddd441  and eax, 0x7FF8
00007588ecddd446  cmp eax, 0x08
00007588ecddd449  jnz 0x00007588ECDDD36A
00007588ecddd44f  movq rax, xmm15
00007588ecddd454  shl rax, 0x0D
00007588ecddd458  jbe 0x00007588ECDDD36A
00007588ecddd45e  vorps xmm13, xmm15, [0x00007588EC9FE070]
00007588ecddd466  jmp 0x00007588ECDDD36A
00007588ecddd46b  ucomisd xmm1, xmm15
00007588ecddd470  jp 0x00007588ECDDD47F
00007588ecddd472  movaps xmm14, [0x00007588EC9FE060]
00007588ecddd47a  jmp 0x00007588ECDDD397
00007588ecddd47f  vxorps xmm0, xmm1, xmm15
00007588ecddd484  pextrw eax, xmm0, 0x03
00007588ecddd489  and eax, 0x7FF8
00007588ecddd48e  cmp eax, 0x08
00007588ecddd491  jnz 0x00007588ECDDD397
00007588ecddd497  movq rax, xmm15
00007588ecddd49c  shl rax, 0x0D
00007588ecddd4a0  jbe 0x00007588ECDDD397
00007588ecddd4a6  vorps xmm14, xmm15, [0x00007588EC9FE070]
00007588ecddd4ae  jmp 0x00007588ECDDD397
00007588ecddd4b3  int3
00007588ecddd4b4  nop [rax+rax*1], ax
00007588ecddd4bd  nop [rax], eax
00007588ecddd4c0  mov rax, [r15+0x48]
00007588ecddd4c4  mov r14, [r15+0x50]
00007588ecddd4c8  lea r12, [r14+rax*1]
00007588ecddd4cc  movups xmm1, [r13+r12*1]
00007588ecddd4d2  movaps [r15+0x120], xmm1
00007588ecddd4da  lea r14, [rax+0x10]
00007588ecddd4de  mov [r15+0x48], r14
00007588ecddd4e2  xor eax, eax
00007588ecddd4e4  mov r12d, 0x200
00007588ecddd4ea  cmp r14, r12
00007588ecddd4ed  cmc
00007588ecddd4ee  lahf
00007588ecddd4ef  seto al
00007588ecddd4f2  mov [r15+0x108], eax
00007588ecddd4f9  pextrq rax, xmm1, 0x01
00007588ecddd500  movq xmm15, rax
00007588ecddd505  movaps [r15+0x130], xmm15
00007588ecddd50d  movaps xmm14, [r15+0x110]
00007588ecddd515  movq rax, xmm14
00007588ecddd51a  movq r14, xmm1
00007588ecddd51f  vmovq xmm1, rax
00007588ecddd524  vmovq xmm14, r14
00007588ecddd529  movaps xmm13, xmm1
00007588ecddd52d  addsd xmm13, xmm14
00007588ecddd532  ucomisd xmm13, xmm13
00007588ecddd537  jp 0x00007588ECDDD5EC
00007588ecddd53d  movq xmm13, xmm13
00007588ecddd542  movq rax, xmm13
00007588ecddd547  movq r14, xmm15
00007588ecddd54c  vmovq xmm1, rax
00007588ecddd551  vmovq xmm15, r14
00007588ecddd556  movaps xmm14, xmm1
00007588ecddd55a  addsd xmm14, xmm15
00007588ecddd55f  ucomisd xmm14, xmm14
00007588ecddd564  jp 0x00007588ECDDD634
00007588ecddd56a  movq xmm14, xmm14
00007588ecddd56f  movaps [r15+0x110], xmm14
00007588ecddd577  mov eax, [r15+0x108]
00007588ecddd57e  sahf
00007588ecddd57f  jnz 0x00007588ECDDD5B1
00007588ecddd581  cmp dword ptr [r15+0x318], 0x00
00007588ecddd589  jz 0x00007588ECDDD680
00007588ecddd58f  nop [rax+rax*1], ax
00007588ecddd598  nop [rax+rax*1], eax
00007588ecddd5a0  mov eax, 0x410698
00007588ecddd5a5  mov [r15+0x100], rax
00007588ecddd5ac  jmp 0x00007588ECBFE110
00007588ecddd5b1  cmp dword ptr [r15+0x318], 0x00
00007588ecddd5b9  jz 0x00007588ECDDD4C0
00007588ecddd5bf  nop [rax+rax*1], ax
00007588ecddd5c8  nop [rax+rax*1], eax
00007588ecddd5d0  mov eax, 0x41067C
00007588ecddd5d5  mov [r15+0x100], rax
00007588ecddd5dc  jmp 0x00007588ECBFE110
00007588ecddd5e1  int3
00007588ecddd5e2  call 0x00007588ECCB52F0
00007588ecddd5e7  jmp 0x00007588ECDDD4D2
00007588ecddd5ec  ucomisd xmm1, xmm14
00007588ecddd5f1  jp 0x00007588ECDDD600
00007588ecddd5f3  movaps xmm13, [0x00007588EC9FE060]
00007588ecddd5fb  jmp 0x00007588ECDDD53D
00007588ecddd600  vxorps xmm0, xmm1, xmm14
00007588ecddd605  pextrw eax, xmm0, 0x03
00007588ecddd60a  and eax, 0x7FF8
00007588ecddd60f  cmp eax, 0x08
00007588ecddd612  jnz 0x00007588ECDDD53D
00007588ecddd618  movq rax, xmm14
00007588ecddd61d  shl rax, 0x0D
00007588ecddd621  jbe 0x00007588ECDDD53D
00007588ecddd627  vorps xmm13, xmm14, [0x00007588EC9FE070]
00007588ecddd62f  jmp 0x00007588ECDDD53D
00007588ecddd634  ucomisd xmm1, xmm15
00007588ecddd639  jp 0x00007588ECDDD648
00007588ecddd63b  movaps xmm14, [0x00007588EC9FE060]
00007588ecddd643  jmp 0x00007588ECDDD56A
00007588ecddd648  vxorps xmm0, xmm1, xmm15
00007588ecddd64d  pextrw eax, xmm0, 0x03
00007588ecddd652  and eax, 0x7FF8
00007588ecddd657  cmp eax, 0x08
00007588ecddd65a  jnz 0x00007588ECDDD56A
00007588ecddd660  movq rax, xmm15
00007588ecddd665  shl rax, 0x0D
00007588ecddd669  jbe 0x00007588ECDDD56A
00007588ecddd66f  vorps xmm14, xmm15, [0x00007588EC9FE070]
00007588ecddd677  jmp 0x00007588ECDDD56A
00007588ecddd67c  int3
00007588ecddd67d  nop [rax], eax
00007588ecddd680  mov rax, [r15+0xF8]
00007588ecddd687  lea r14, [rax+0x1A0]
00007588ecddd68e  mov r12, [r13+r14*1]
00007588ecddd693  lea r14, [rax+0x1A8]
00007588ecddd69a  mov r11, [r13+r14*1]
00007588ecddd69f  mov [r15+0xA0], r12
00007588ecddd6a6  mov [r15+0x98], r11
00007588ecddd6ad  mov r14, [r15+0x40]
00007588ecddd6b1  lea r12, [r14+0xC50]
00007588ecddd6b8  movaps xmm1, [r15+0x110]
00007588ecddd6c0  movq r14, xmm1
00007588ecddd6c5  mov [r13+r12*1], r14
00007588ecddd6ca  lea r14, [rax+0x190]
00007588ecddd6d1  mov r12, [r13+r14*1]
00007588ecddd6d6  lea r14, [rax+0x198]
00007588ecddd6dd  mov r11, [r13+r14*1]
00007588ecddd6e2  mov [r15+0xE8], r12
00007588ecddd6e9  mov [r15+0xF0], r11
00007588ecddd6f0  lea r14, [rax+0x180]
00007588ecddd6f7  mov r12, [r13+r14*1]
00007588ecddd6fc  lea r14, [rax+0x188]
00007588ecddd703  mov r10, [r13+r14*1]
00007588ecddd708  movq xmm1, r12
00007588ecddd70d  movq xmm15, r10
00007588ecddd712  movq xmm1, xmm1
00007588ecddd716  movq xmm1, xmm1
00007588ecddd71a  movaps [r15+0x1A0], xmm1
00007588ecddd722  movq xmm15, xmm15
00007588ecddd727  movq xmm15, xmm15
00007588ecddd72c  movaps [r15+0x190], xmm15
00007588ecddd734  lea r14, [rax+0x170]
00007588ecddd73b  mov r12, [r13+r14*1]
00007588ecddd740  lea r14, [rax+0x178]
00007588ecddd747  mov r10, [r13+r14*1]
00007588ecddd74c  movq xmm1, r12
00007588ecddd751  movq xmm15, r10
00007588ecddd756  movq xmm1, xmm1
00007588ecddd75a  movq xmm1, xmm1
00007588ecddd75e  movaps [r15+0x1C0], xmm1
00007588ecddd766  movq xmm15, xmm15
00007588ecddd76b  movq xmm15, xmm15
00007588ecddd770  movaps [r15+0x1B0], xmm15
00007588ecddd778  lea r14, [rax+0x160]
00007588ecddd77f  mov r12, [r13+r14*1]
00007588ecddd784  lea r14, [rax+0x168]
00007588ecddd78b  mov r10, [r13+r14*1]
00007588ecddd790  movq xmm1, r12
00007588ecddd795  movq xmm15, r10
00007588ecddd79a  movq xmm1, xmm1
00007588ecddd79e  movq xmm1, xmm1
00007588ecddd7a2  movaps [r15+0x1E0], xmm1
00007588ecddd7aa  movq xmm15, xmm15
00007588ecddd7af  movq xmm15, xmm15
00007588ecddd7b4  movaps [r15+0x1D0], xmm15
00007588ecddd7bc  lea r14, [rax+0x150]
00007588ecddd7c3  mov r12, [r13+r14*1]
00007588ecddd7c8  lea r14, [rax+0x158]
00007588ecddd7cf  mov r10, [r13+r14*1]
00007588ecddd7d4  movq xmm1, r12
00007588ecddd7d9  movq xmm15, r10
00007588ecddd7de  movq xmm1, xmm1
00007588ecddd7e2  movq xmm1, xmm1
00007588ecddd7e6  movaps [r15+0x200], xmm1
00007588ecddd7ee  movq xmm15, xmm15
00007588ecddd7f3  movq xmm15, xmm15
00007588ecddd7f8  movaps [r15+0x1F0], xmm15
00007588ecddd800  lea r14, [rax+0x1B0]
00007588ecddd807  mov [r15+0xF8], r14
00007588ecddd80e  mov [r15+0x100], r11
00007588ecddd815  jmp 0x00007588ECDCE5C0
00007588ecddd81a  int3
00007588ecddd81b  call 0x00007588ECCE27E0
00007588ecddd820  jmp 0x00007588ECDDD693
00007588ecddd825  call 0x00007588ECCE1570
00007588ecddd82a  jmp 0x00007588ECDDD69F
00007588ecddd82f  call 0x00007588ECCC3FE0
00007588ecddd834  jmp 0x00007588ECDDD6CA
00007588ecddd839  call 0x00007588ECCE27E0
00007588ecddd83e  jmp 0x00007588ECDDD6D6
00007588ecddd843  call 0x00007588ECCE1570
00007588ecddd848  jmp 0x00007588ECDDD6E2
00007588ecddd84d  call 0x00007588ECCE27E0
00007588ecddd852  jmp 0x00007588ECDDD6FC
00007588ecddd857  call 0x00007588ECCE0300
00007588ecddd85c  jmp 0x00007588ECDDD708
00007588ecddd861  call 0x00007588ECCE27E0
00007588ecddd866  jmp 0x00007588ECDDD740
00007588ecddd86b  call 0x00007588ECCE0300
00007588ecddd870  jmp 0x00007588ECDDD74C
00007588ecddd875  call 0x00007588ECCE27E0
00007588ecddd87a  jmp 0x00007588ECDDD784
00007588ecddd87f  call 0x00007588ECCE0300
00007588ecddd884  jmp 0x00007588ECDDD790
00007588ecddd889  call 0x00007588ECCE27E0
00007588ecddd88e  jmp 0x00007588ECDDD7C8
00007588ecddd893  call 0x00007588ECCE0300
00007588ecddd898  jmp 0x00007588ECDDD7D4
00007588ecddd89d  int3
00007588ecddd89e  nop
00007588ecddd8a0  mov qword ptr [r15+0x100], 0x04
00007588ecddd8ab  mov esi, 0x00
00007588ecddd8b0  mov edx, 0x09
00007588ecddd8b5  mov rdi, 0x7FFEF2802410
00007588ecddd8bf  mov rax, 0x6516BF24E970
00007588ecddd8c9  call rax
00007588ecddd8cb  cmp dword ptr [r15+0x318], 0x00
00007588ecddd8d3  jnz 0x00007588ECBFE110
00007588ecddd8d9  jmp 0x00007588ECBFE0A0
00007588ecddd8de  int3
00007588ecddd8df  int3
