0000707f9fbce69b  nop [rax+rax*1], eax
0000707f9fbce6a0  mov rax, [r15+0xF8]
0000707f9fbce6a7  lea r14, [rax-0x1B0]
0000707f9fbce6ae  mov [r15+0xF8], r14
0000707f9fbce6b5  lea rax, [r14+0x1A0]
0000707f9fbce6bc  mov r12, [r15+0xA0]
0000707f9fbce6c3  mov r11, [r15+0x98]
0000707f9fbce6ca  mov [r13+rax*1], r12
0000707f9fbce6cf  lea rax, [r14+0x1A8]
0000707f9fbce6d6  mov [r13+rax*1], r11
0000707f9fbce6db  mov eax, 0x420A30
0000707f9fbce6e0  movups xmm1, [r13+rax*1]
0000707f9fbce6e6  mov eax, 0x4209C0
0000707f9fbce6eb  movups xmm15, [r13+rax*1]
0000707f9fbce6f1  mov eax, 0x420A50
0000707f9fbce6f6  movups xmm14, [r13+rax*1]
0000707f9fbce6fc  mov eax, 0x4209F0
0000707f9fbce701  movups xmm13, [r13+rax*1]
0000707f9fbce707  mov qword ptr [r15+0x98], 0x430C60
0000707f9fbce712  mov eax, 0x420A60
0000707f9fbce717  movups xmm12, [r13+rax*1]
0000707f9fbce71d  mov eax, 0x430C60
0000707f9fbce722  movups [r13+rax*1], xmm1
0000707f9fbce728  mov eax, 0x430C70
0000707f9fbce72d  movups [r13+rax*1], xmm15
0000707f9fbce733  mov eax, 0x430C80
0000707f9fbce738  movups [r13+rax*1], xmm14
0000707f9fbce73e  mov eax, 0x430C90
0000707f9fbce743  movups [r13+rax*1], xmm13
0000707f9fbce749  mov eax, 0x4209B0
0000707f9fbce74e  movups xmm14, [r13+rax*1]
0000707f9fbce754  mov eax, 0x4209A0
0000707f9fbce759  movups xmm13, [r13+rax*1]
0000707f9fbce75f  mov eax, 0x430D60
0000707f9fbce764  movups [r13+rax*1], xmm1
0000707f9fbce76a  mov eax, 0x430D70
0000707f9fbce76f  movups [r13+rax*1], xmm15
0000707f9fbce775  mov eax, 0x430CA0
0000707f9fbce77a  movups [r13+rax*1], xmm12
0000707f9fbce780  mov eax, 0x430CB0
0000707f9fbce785  movups [r13+rax*1], xmm14
0000707f9fbce78b  mov eax, 0x420990
0000707f9fbce790  movups xmm1, [r13+rax*1]
0000707f9fbce796  mov eax, 0x420A00
0000707f9fbce79b  movups xmm15, [r13+rax*1]
0000707f9fbce7a1  mov eax, 0x430CC0
0000707f9fbce7a6  movups [r13+rax*1], xmm13
0000707f9fbce7ac  mov eax, 0x430CD0
0000707f9fbce7b1  movups [r13+rax*1], xmm1
0000707f9fbce7b7  mov eax, 0x420A10
0000707f9fbce7bc  movups xmm1, [r13+rax*1]
0000707f9fbce7c2  mov eax, 0x4209E0
0000707f9fbce7c7  movups xmm14, [r13+rax*1]
0000707f9fbce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000707f9fbce7d5  mov eax, 0x430CE0
0000707f9fbce7da  movups [r13+rax*1], xmm15
0000707f9fbce7e0  mov eax, 0x430CF0
0000707f9fbce7e5  movups [r13+rax*1], xmm1
0000707f9fbce7eb  mov eax, 0x420A80
0000707f9fbce7f0  movups xmm1, [r13+rax*1]
0000707f9fbce7f6  mov eax, 0x420A90
0000707f9fbce7fb  movups xmm15, [r13+rax*1]
0000707f9fbce801  movaps [r15+0x150], xmm15
0000707f9fbce809  mov qword ptr [r15+0xA0], 0x3E8
0000707f9fbce814  mov eax, 0x430D00
0000707f9fbce819  movups [r13+rax*1], xmm14
0000707f9fbce81f  mov eax, 0x430D10
0000707f9fbce824  movups [r13+rax*1], xmm1
0000707f9fbce82a  mov eax, 0x420A70
0000707f9fbce82f  movups xmm1, [r13+rax*1]
0000707f9fbce835  mov eax, 0x420A20
0000707f9fbce83a  movups xmm14, [r13+rax*1]
0000707f9fbce840  movaps [r15+0x140], xmm14
0000707f9fbce848  lea rax, [r14+0x150]
0000707f9fbce84f  movq xmm13, qword ptr [r15+0x200]
0000707f9fbce858  movq xmm12, qword ptr [r15+0x1F0]
0000707f9fbce861  movq r12, xmm13
0000707f9fbce866  movq r11, xmm12
0000707f9fbce86b  mov [r13+rax*1], r12
0000707f9fbce870  lea rax, [r14+0x158]
0000707f9fbce877  mov [r13+rax*1], r11
0000707f9fbce87c  mov eax, 0x430D20
0000707f9fbce881  movups [r13+rax*1], xmm15
0000707f9fbce887  mov eax, 0x430D30
0000707f9fbce88c  movups [r13+rax*1], xmm1
0000707f9fbce892  mov eax, 0x420A40
0000707f9fbce897  movups xmm1, [r13+rax*1]
0000707f9fbce89d  mov eax, 0x420AA8
0000707f9fbce8a2  mov r12, [r13+rax*1]
0000707f9fbce8a7  movq xmm15, r12
0000707f9fbce8ac  mov qword ptr [r15+0x40], 0x420AB0
0000707f9fbce8b4  mov eax, 0x430D40
0000707f9fbce8b9  movups [r13+rax*1], xmm14
0000707f9fbce8bf  mov eax, 0x430D50
0000707f9fbce8c4  movups [r13+rax*1], xmm1
0000707f9fbce8ca  mov eax, 0x420B10
0000707f9fbce8cf  movups xmm1, [r13+rax*1]
0000707f9fbce8d5  movq rax, xmm15
0000707f9fbce8da  mov r12d, 0x430D80
0000707f9fbce8e0  mov [r13+r12*1], rax
0000707f9fbce8e5  mov eax, 0x420AF0
0000707f9fbce8ea  movups xmm15, [r13+rax*1]
0000707f9fbce8f0  mov eax, 0x420B00
0000707f9fbce8f5  movups xmm14, [r13+rax*1]
0000707f9fbce8fb  lea rax, [r14+0x130]
0000707f9fbce902  movups [r13+rax*1], xmm1
0000707f9fbce908  lea rax, [r14+0x160]
0000707f9fbce90f  movq xmm1, qword ptr [r15+0x1E0]
0000707f9fbce918  movq xmm13, qword ptr [r15+0x1D0]
0000707f9fbce921  movq r12, xmm1
0000707f9fbce926  movq r11, xmm13
0000707f9fbce92b  mov [r13+rax*1], r12
0000707f9fbce930  lea rax, [r14+0x168]
0000707f9fbce937  mov [r13+rax*1], r11
0000707f9fbce93c  lea rax, [r14+0x110]
0000707f9fbce943  movups [r13+rax*1], xmm15
0000707f9fbce949  lea rax, [r14+0x120]
0000707f9fbce950  movups [r13+rax*1], xmm14
0000707f9fbce956  mov eax, 0x420AB0
0000707f9fbce95b  movups xmm1, [r13+rax*1]
0000707f9fbce961  mov eax, 0x420AC0
0000707f9fbce966  movups xmm15, [r13+rax*1]
0000707f9fbce96c  movaps [r15+0x120], xmm15
0000707f9fbce974  lea rax, [r14+0x170]
0000707f9fbce97b  movq xmm14, qword ptr [r15+0x1C0]
0000707f9fbce984  movq xmm13, qword ptr [r15+0x1B0]
0000707f9fbce98d  movq r12, xmm14
0000707f9fbce992  movq r11, xmm13
0000707f9fbce997  mov [r13+rax*1], r12
0000707f9fbce99c  lea rax, [r14+0x178]
0000707f9fbce9a3  mov [r13+rax*1], r11
0000707f9fbce9a8  lea rax, [r14+0x180]
0000707f9fbce9af  movq xmm14, qword ptr [r15+0x1A0]
0000707f9fbce9b8  movq xmm13, qword ptr [r15+0x190]
0000707f9fbce9c1  movq r12, xmm14
0000707f9fbce9c6  movq r11, xmm13
0000707f9fbce9cb  mov [r13+rax*1], r12
0000707f9fbce9d0  lea rax, [r14+0x188]
0000707f9fbce9d7  mov [r13+rax*1], r11
0000707f9fbce9dc  lea rax, [r14+0xD0]
0000707f9fbce9e3  movups [r13+rax*1], xmm1
0000707f9fbce9e9  lea rax, [r14+0xE0]
0000707f9fbce9f0  movups [r13+rax*1], xmm15
0000707f9fbce9f6  mov eax, 0x420AD0
0000707f9fbce9fb  movups xmm1, [r13+rax*1]
0000707f9fbcea01  mov eax, 0x420AE0
0000707f9fbcea06  movups xmm15, [r13+rax*1]
0000707f9fbcea0c  movaps [r15+0x110], xmm1
0000707f9fbcea14  movaps [r15+0x130], xmm15
0000707f9fbcea1c  lea rax, [r14+0x190]
0000707f9fbcea23  mov r12, [r15+0xE8]
0000707f9fbcea2a  mov r11, [r15+0xF0]
0000707f9fbcea31  mov [r13+rax*1], r12
0000707f9fbcea36  lea rax, [r14+0x198]
0000707f9fbcea3d  mov [r13+rax*1], r11
0000707f9fbcea42  mov eax, 0x430D88
0000707f9fbcea47  mov r12d, 0x421DF8D3
0000707f9fbcea4d  mov [r13+rax*1], r12d
0000707f9fbcea52  lea rax, [r14+0xF0]
0000707f9fbcea59  movups [r13+rax*1], xmm1
0000707f9fbcea5f  lea rax, [r14+0x100]
0000707f9fbcea66  movups [r13+rax*1], xmm15
0000707f9fbcea6c  lea rax, [r14+0xD0]
0000707f9fbcea73  mov [r15], rax
0000707f9fbcea76  mov qword ptr [r15+0x08], 0x430C60
0000707f9fbcea7e  mov qword ptr [r15+0x10], 0x12C
0000707f9fbcea86  mov qword ptr [r15+0xF0], 0x410284
0000707f9fbcea91  mov r14d, [r15+0x320]
0000707f9fbcea98  mov eax, 0x410284
0000707f9fbcea9d  mov rcx, 0x707F9FBD07C0
0000707f9fbceaa7  mov [r15+r14*8+0x328], rax
0000707f9fbceaaf  mov [r15+r14*8+0x368], rcx
0000707f9fbceab7  add r14d, 0x01
0000707f9fbceabb  and r14d, 0x07
0000707f9fbceabf  mov [r15+0x320], r14d
0000707f9fbceac6  cmp dword ptr [r15+0x318], 0x00
0000707f9fbceace  jz 0x0000707F9FBCED70
0000707f9fbcead4  nop [rax+rax*1], ax
0000707f9fbceadd  nop [rax+rax*1], eax
0000707f9fbceae5  mov eax, 0x4106BC
0000707f9fbceaea  mov [r15+0x100], rax
0000707f9fbceaf1  jmp 0x0000707F9F9FE110
0000707f9fbceaf6  int3
0000707f9fbceaf7  call 0x0000707F9FA0BC20
0000707f9fbceafc  jmp 0x0000707F9FBCE6CF
0000707f9fbceb01  call 0x0000707F9FA0A9A0
0000707f9fbceb06  jmp 0x0000707F9FBCE6DB
0000707f9fbceb0b  call 0x0000707F9F9FF430
0000707f9fbceb10  jmp 0x0000707F9FBCE6E6
0000707f9fbceb15  call 0x0000707F9FA0E760
0000707f9fbceb1a  jmp 0x0000707F9FBCE6F1
0000707f9fbceb1f  call 0x0000707F9FA0D4E0
0000707f9fbceb24  jmp 0x0000707F9FBCE6FC
0000707f9fbceb29  call 0x0000707F9FA0C260
0000707f9fbceb2e  jmp 0x0000707F9FBCE707
0000707f9fbceb33  call 0x0000707F9FA0AFE0
0000707f9fbceb38  jmp 0x0000707F9FBCE71D
0000707f9fbceb3d  call 0x0000707F9F9FF540
0000707f9fbceb42  jmp 0x0000707F9FBCE728
0000707f9fbceb47  call 0x0000707F9FA0E880
0000707f9fbceb4c  jmp 0x0000707F9FBCE733
0000707f9fbceb51  call 0x0000707F9FA0D600
0000707f9fbceb56  jmp 0x0000707F9FBCE73E
0000707f9fbceb5b  call 0x0000707F9FA0C380
0000707f9fbceb60  jmp 0x0000707F9FBCE749
0000707f9fbceb65  call 0x0000707F9FA0D4E0
0000707f9fbceb6a  jmp 0x0000707F9FBCE754
0000707f9fbceb6f  call 0x0000707F9FA0C260
0000707f9fbceb74  jmp 0x0000707F9FBCE75F
0000707f9fbceb79  call 0x0000707F9F9FF540
0000707f9fbceb7e  jmp 0x0000707F9FBCE76A
0000707f9fbceb83  call 0x0000707F9FA0E880
0000707f9fbceb88  jmp 0x0000707F9FBCE775
0000707f9fbceb8d  call 0x0000707F9FA0B100
0000707f9fbceb92  jmp 0x0000707F9FBCE780
0000707f9fbceb97  call 0x0000707F9FA0D600
0000707f9fbceb9c  jmp 0x0000707F9FBCE78B
0000707f9fbceba1  call 0x0000707F9F9FF430
0000707f9fbceba6  jmp 0x0000707F9FBCE796
0000707f9fbcebab  call 0x0000707F9FA0E760
0000707f9fbcebb0  jmp 0x0000707F9FBCE7A1
0000707f9fbcebb5  call 0x0000707F9FA0C380
0000707f9fbcebba  jmp 0x0000707F9FBCE7AC
0000707f9fbcebbf  call 0x0000707F9F9FF540
0000707f9fbcebc4  jmp 0x0000707F9FBCE7B7
0000707f9fbcebc9  call 0x0000707F9F9FF430
0000707f9fbcebce  jmp 0x0000707F9FBCE7C2
0000707f9fbcebd3  call 0x0000707F9FA0D4E0
0000707f9fbcebd8  jmp 0x0000707F9FBCE7CD
0000707f9fbcebdd  call 0x0000707F9FA0E880
0000707f9fbcebe2  jmp 0x0000707F9FBCE7E0
0000707f9fbcebe7  call 0x0000707F9F9FF540
0000707f9fbcebec  jmp 0x0000707F9FBCE7EB
0000707f9fbcebf1  call 0x0000707F9F9FF430
0000707f9fbcebf6  jmp 0x0000707F9FBCE7F6
0000707f9fbcebfb  call 0x0000707F9FA0E760
0000707f9fbcec00  jmp 0x0000707F9FBCE801
0000707f9fbcec05  call 0x0000707F9FA0D600
0000707f9fbcec0a  jmp 0x0000707F9FBCE81F
0000707f9fbcec0f  call 0x0000707F9F9FF540
0000707f9fbcec14  jmp 0x0000707F9FBCE82A
0000707f9fbcec19  call 0x0000707F9F9FF430
0000707f9fbcec1e  jmp 0x0000707F9FBCE835
0000707f9fbcec23  call 0x0000707F9FA0D4E0
0000707f9fbcec28  jmp 0x0000707F9FBCE840
0000707f9fbcec2d  call 0x0000707F9FA0BC20
0000707f9fbcec32  jmp 0x0000707F9FBCE870
0000707f9fbcec37  call 0x0000707F9FA0A9A0
0000707f9fbcec3c  jmp 0x0000707F9FBCE87C
0000707f9fbcec41  call 0x0000707F9FA0E880
0000707f9fbcec46  jmp 0x0000707F9FBCE887
0000707f9fbcec4b  call 0x0000707F9F9FF540
0000707f9fbcec50  jmp 0x0000707F9FBCE892
0000707f9fbcec55  call 0x0000707F9F9FF430
0000707f9fbcec5a  jmp 0x0000707F9FBCE89D
0000707f9fbcec5f  call 0x0000707F9FA0B720
0000707f9fbcec64  jmp 0x0000707F9FBCE8A7
0000707f9fbcec69  call 0x0000707F9FA0D600
0000707f9fbcec6e  jmp 0x0000707F9FBCE8BF
0000707f9fbcec73  call 0x0000707F9F9FF540
0000707f9fbcec78  jmp 0x0000707F9FBCE8CA
0000707f9fbcec7d  call 0x0000707F9F9FF430
0000707f9fbcec82  jmp 0x0000707F9FBCE8D5
0000707f9fbcec87  call 0x0000707F9FAB4CB0
0000707f9fbcec8c  jmp 0x0000707F9FBCE8E5
0000707f9fbcec91  call 0x0000707F9FA0E760
0000707f9fbcec96  jmp 0x0000707F9FBCE8F0
0000707f9fbcec9b  call 0x0000707F9FA0D4E0
0000707f9fbceca0  jmp 0x0000707F9FBCE8FB
0000707f9fbceca5  call 0x0000707F9F9FF540
0000707f9fbcecaa  jmp 0x0000707F9FBCE908
0000707f9fbcecaf  call 0x0000707F9FA0BC20
0000707f9fbcecb4  jmp 0x0000707F9FBCE930
0000707f9fbcecb9  call 0x0000707F9FA0A9A0
0000707f9fbcecbe  jmp 0x0000707F9FBCE93C
0000707f9fbcecc3  call 0x0000707F9FA0E880
0000707f9fbcecc8  jmp 0x0000707F9FBCE949
0000707f9fbceccd  call 0x0000707F9FA0D600
0000707f9fbcecd2  jmp 0x0000707F9FBCE956
0000707f9fbcecd7  call 0x0000707F9F9FF430
0000707f9fbcecdc  jmp 0x0000707F9FBCE961
0000707f9fbcece1  call 0x0000707F9FA0E760
0000707f9fbcece6  jmp 0x0000707F9FBCE96C
0000707f9fbceceb  call 0x0000707F9FA0BC20
0000707f9fbcecf0  jmp 0x0000707F9FBCE99C
0000707f9fbcecf5  call 0x0000707F9FA0A9A0
0000707f9fbcecfa  jmp 0x0000707F9FBCE9A8
0000707f9fbcecff  call 0x0000707F9FA0BC20
0000707f9fbced04  jmp 0x0000707F9FBCE9D0
0000707f9fbced09  call 0x0000707F9FA0A9A0
0000707f9fbced0e  jmp 0x0000707F9FBCE9DC
0000707f9fbced13  call 0x0000707F9F9FF540
0000707f9fbced18  jmp 0x0000707F9FBCE9E9
0000707f9fbced1d  call 0x0000707F9FA0E880
0000707f9fbced22  jmp 0x0000707F9FBCE9F6
0000707f9fbced27  call 0x0000707F9F9FF430
0000707f9fbced2c  jmp 0x0000707F9FBCEA01
0000707f9fbced31  call 0x0000707F9FA0E760
0000707f9fbced36  jmp 0x0000707F9FBCEA0C
0000707f9fbced3b  call 0x0000707F9FA0BC20
0000707f9fbced40  jmp 0x0000707F9FBCEA36
0000707f9fbced45  call 0x0000707F9FA0A9A0
0000707f9fbced4a  jmp 0x0000707F9FBCEA42
0000707f9fbced4f  call 0x0000707F9FA0BAE0
0000707f9fbced54  jmp 0x0000707F9FBCEA52
0000707f9fbced59  call 0x0000707F9F9FF540
0000707f9fbced5e  jmp 0x0000707F9FBCEA5F
0000707f9fbced63  call 0x0000707F9FA0E880
0000707f9fbced68  jmp 0x0000707F9FBCEA6C
0000707f9fbced6d  int3
0000707f9fbced6e  nop
0000707f9fbced70  mov rax, [r15]
0000707f9fbced73  lea r14, [rax+0x20]
0000707f9fbced77  mov r12, [r13+r14*1]
0000707f9fbced7c  mov r14, [r15+0x10]
0000707f9fbced80  lea r11, [r12+r14*1]
0000707f9fbced84  mov [r15+0x40], r11
0000707f9fbced88  lea r12, [rax+0x20]
0000707f9fbced8c  mov [r13+r12*1], r11
0000707f9fbced91  test r14, r14
0000707f9fbced94  setz r14b
0000707f9fbced98  movzx r14, r14b
0000707f9fbced9c  mov [rsp+0x414], r14b
0000707f9fbceda4  cmp byte ptr [rsp+0x414], 0x00
0000707f9fbcedac  jz 0x0000707F9FBCEDDE
0000707f9fbcedae  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcedb6  mov eax, 0x410934
0000707f9fbcedbb  mov [r15+0x100], rax
0000707f9fbcedc2  jz 0x0000707F9F9FE0A0
0000707f9fbcedc8  nop [rax+rax*1], eax
0000707f9fbcedcd  mov eax, 0x410934
0000707f9fbcedd2  mov [r15+0x100], rax
0000707f9fbcedd9  jmp 0x0000707F9F9FE110
0000707f9fbcedde  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcede6  jz 0x0000707F9FBCEE30
0000707f9fbcedec  nop [rax+rax*1], ax
0000707f9fbcedf5  nop [rax+rax*1], eax
0000707f9fbcedfd  mov eax, 0x4106CC
0000707f9fbcee02  mov [r15+0x100], rax
0000707f9fbcee09  jmp 0x0000707F9F9FE110
0000707f9fbcee0e  int3
0000707f9fbcee0f  call 0x0000707F9FAE27E0
0000707f9fbcee14  jmp 0x0000707F9FBCED7C
0000707f9fbcee19  call 0x0000707F9FAC0860
0000707f9fbcee1e  jmp 0x0000707F9FBCED91
0000707f9fbcee23  int3
0000707f9fbcee24  nop [rax+rax*1], ax
0000707f9fbcee2d  nop [rax], eax
0000707f9fbcee30  mov rax, [r15+0xF8]
0000707f9fbcee37  lea r14, [rax-0x150]
0000707f9fbcee3e  mov [r15+0xF8], r14
0000707f9fbcee45  mov rax, [r15]
0000707f9fbcee48  lea r12, [rax+0x68]
0000707f9fbcee4c  mov r11, [r13+r12*1]
0000707f9fbcee51  mov [r15+0x88], r11
0000707f9fbcee58  lea r12, [rax+0x28]
0000707f9fbcee5c  mov [r15+0x40], r12
0000707f9fbcee60  mov [r15+0x48], r14
0000707f9fbcee64  mov qword ptr [r15+0x50], 0x420B20
0000707f9fbcee6c  lea rax, [r14+0x100]
0000707f9fbcee73  mov r12, [r15+0xE8]
0000707f9fbcee7a  mov r11, [r15+0xD8]
0000707f9fbcee81  mov [r13+rax*1], r12
0000707f9fbcee86  lea rax, [r14+0x108]
0000707f9fbcee8d  mov [r13+rax*1], r11
0000707f9fbcee92  lea rax, [r14+0x110]
0000707f9fbcee99  mov r12, [r15+0xD0]
0000707f9fbceea0  mov r11, [r15+0xC8]
0000707f9fbceea7  mov [r13+rax*1], r12
0000707f9fbceeac  lea rax, [r14+0x118]
0000707f9fbceeb3  mov [r13+rax*1], r11
0000707f9fbceeb8  lea rax, [r14+0x120]
0000707f9fbceebf  mov r12, [r15+0xC0]
0000707f9fbceec6  mov r11, [r15+0xB8]
0000707f9fbceecd  mov [r13+rax*1], r12
0000707f9fbceed2  lea rax, [r14+0x128]
0000707f9fbceed9  mov [r13+rax*1], r11
0000707f9fbceede  lea rax, [r14+0x130]
0000707f9fbceee5  mov r12, [r15+0xB0]
0000707f9fbceeec  mov r11, [r15+0xA8]
0000707f9fbceef3  mov [r13+rax*1], r12
0000707f9fbceef8  lea rax, [r14+0x138]
0000707f9fbceeff  mov [r13+rax*1], r11
0000707f9fbcef04  lea rax, [r14+0x140]
0000707f9fbcef0b  mov r12, [r15+0xA0]
0000707f9fbcef12  mov r11, [r15+0x98]
0000707f9fbcef19  mov [r13+rax*1], r12
0000707f9fbcef1e  lea rax, [r14+0x148]
0000707f9fbcef25  mov [r13+rax*1], r11
0000707f9fbcef2a  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcef32  jz 0x0000707F9FBCEFD0
0000707f9fbcef38  nop [rax+rax*1], ax
0000707f9fbcef41  nop [rax+rax*1], eax
0000707f9fbcef49  mov eax, 0x410704
0000707f9fbcef4e  mov [r15+0x100], rax
0000707f9fbcef55  jmp 0x0000707F9F9FE110
0000707f9fbcef5a  int3
0000707f9fbcef5b  call 0x0000707F9FAC0370
0000707f9fbcef60  jmp 0x0000707F9FBCEE51
0000707f9fbcef65  call 0x0000707F9FA0BC20
0000707f9fbcef6a  jmp 0x0000707F9FBCEE86
0000707f9fbcef6f  call 0x0000707F9FA0A9A0
0000707f9fbcef74  jmp 0x0000707F9FBCEE92
0000707f9fbcef79  call 0x0000707F9FA0BC20
0000707f9fbcef7e  jmp 0x0000707F9FBCEEAC
0000707f9fbcef83  call 0x0000707F9FA0A9A0
0000707f9fbcef88  jmp 0x0000707F9FBCEEB8
0000707f9fbcef8d  call 0x0000707F9FA0BC20
0000707f9fbcef92  jmp 0x0000707F9FBCEED2
0000707f9fbcef97  call 0x0000707F9FA0A9A0
0000707f9fbcef9c  jmp 0x0000707F9FBCEEDE
0000707f9fbcefa1  call 0x0000707F9FA0BC20
0000707f9fbcefa6  jmp 0x0000707F9FBCEEF8
0000707f9fbcefab  call 0x0000707F9FA0A9A0
0000707f9fbcefb0  jmp 0x0000707F9FBCEF04
0000707f9fbcefb5  call 0x0000707F9FA0BC20
0000707f9fbcefba  jmp 0x0000707F9FBCEF1E
0000707f9fbcefbf  call 0x0000707F9FA0A9A0
0000707f9fbcefc4  jmp 0x0000707F9FBCEF2A
0000707f9fbcefc9  int3
0000707f9fbcefca  nop [rax+rax*1], ax
0000707f9fbcefd0  mov rax, [r15+0x08]
0000707f9fbcefd4  movzx r14d, byte ptr [r13+rax*1]
0000707f9fbcefda  movzx r14d, r14b
0000707f9fbcefde  mov [rsp+0x10], r14d
0000707f9fbcefe3  mov r14d, r14d
0000707f9fbcefe6  mov [r15+0x58], r14
0000707f9fbcefea  lea r14, [rax+0x01]
0000707f9fbcefee  mov [r15+0x08], r14
0000707f9fbceff2  mov rax, [r15+0x88]
0000707f9fbceff9  lea r14, [rax+0x01]
0000707f9fbceffd  mov r12, [r15]
0000707f9fbcf000  lea r11, [r12+0x68]
0000707f9fbcf005  mov [r13+r11*1], r14
0000707f9fbcf00a  lea r14, [r12+rax*1]
0000707f9fbcf00e  mov [r15+0x60], r14
0000707f9fbcf012  lea rax, [r14+0x28]
0000707f9fbcf016  mov r11d, [rsp+0x10]
0000707f9fbcf01b  movzx r14d, r11b
0000707f9fbcf01f  mov [r13+rax*1], r14b
0000707f9fbcf024  lea rax, [r12+0x68]
0000707f9fbcf029  mov r14, [r13+rax*1]
0000707f9fbcf02e  mov [r15+0x88], r14
0000707f9fbcf035  xor eax, eax
0000707f9fbcf037  mov r12d, 0x40
0000707f9fbcf03d  cmp r14, r12
0000707f9fbcf040  cmc
0000707f9fbcf041  lahf
0000707f9fbcf042  seto al
0000707f9fbcf045  mov [r15+0x108], eax
0000707f9fbcf04c  mov eax, [r15+0x108]
0000707f9fbcf053  sahf
0000707f9fbcf054  jnz 0x0000707F9FBCF086
0000707f9fbcf056  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcf05e  jz 0x0000707F9FBCF170
0000707f9fbcf064  nop [rax+rax*1], ax
0000707f9fbcf06d  nop [rax+rax*1], eax
0000707f9fbcf075  mov eax, 0x410724
0000707f9fbcf07a  mov [r15+0x100], rax
0000707f9fbcf081  jmp 0x0000707F9F9FE110
0000707f9fbcf086  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcf08e  jz 0x0000707F9FBCF0E0
0000707f9fbcf094  nop [rax+rax*1], ax
0000707f9fbcf09d  nop [rax+rax*1], eax
0000707f9fbcf0a5  mov eax, 0x4106FC
0000707f9fbcf0aa  mov [r15+0x100], rax
0000707f9fbcf0b1  jmp 0x0000707F9F9FE110
0000707f9fbcf0b6  int3
0000707f9fbcf0b7  call 0x0000707F9FA0D860
0000707f9fbcf0bc  jmp 0x0000707F9FBCEFDA
0000707f9fbcf0c1  call 0x0000707F9FAB36E0
0000707f9fbcf0c6  jmp 0x0000707F9FBCF00A
0000707f9fbcf0cb  call 0x0000707F9FA0DD60
0000707f9fbcf0d0  jmp 0x0000707F9FBCF024
0000707f9fbcf0d5  call 0x0000707F9FA0DC20
0000707f9fbcf0da  jmp 0x0000707F9FBCF02E
0000707f9fbcf0df  int3
0000707f9fbcf0e0  mov rax, [r15+0x10]
0000707f9fbcf0e4  lea r14, [rax-0x01]
0000707f9fbcf0e8  mov [r15+0x10], r14
0000707f9fbcf0ec  test r14, r14
0000707f9fbcf0ef  setz r14b
0000707f9fbcf0f3  movzx r14, r14b
0000707f9fbcf0f7  mov [rsp+0x414], r14b
0000707f9fbcf0ff  cmp byte ptr [rsp+0x414], 0x00
0000707f9fbcf107  jz 0x0000707F9FBCF139
0000707f9fbcf109  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcf111  jz 0x0000707F9FBD0670
0000707f9fbcf117  nop [rax+rax*1], ax
0000707f9fbcf120  nop [rax+rax*1], eax
0000707f9fbcf128  mov eax, 0x41091C
0000707f9fbcf12d  mov [r15+0x100], rax
0000707f9fbcf134  jmp 0x0000707F9F9FE110
0000707f9fbcf139  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcf141  jz 0x0000707F9FBCEFD0
0000707f9fbcf147  nop [rax+rax*1], ax
0000707f9fbcf150  nop [rax+rax*1], eax
0000707f9fbcf158  mov eax, 0x410704
0000707f9fbcf15d  mov [r15+0x100], rax
0000707f9fbcf164  jmp 0x0000707F9F9FE110
0000707f9fbcf169  int3
0000707f9fbcf16a  int3
0000707f9fbcf16b  nop [rax+rax*1], eax
0000707f9fbcf170  mov rax, [r15+0x40]
0000707f9fbcf174  movzx r14d, byte ptr [r13+rax*1]
0000707f9fbcf17a  movaps xmm1, [r15+0x110]
0000707f9fbcf182  pinsrb xmm1, r14d, 0x00
0000707f9fbcf189  lea r14, [rax+0x01]
0000707f9fbcf18d  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf193  movaps xmm15, [r15+0x120]
0000707f9fbcf19b  pinsrb xmm15, r12d, 0x00
0000707f9fbcf1a2  lea r14, [rax+0x02]
0000707f9fbcf1a6  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf1ac  movaps xmm14, [r15+0x130]
0000707f9fbcf1b4  pinsrb xmm14, r12d, 0x00
0000707f9fbcf1bb  lea r14, [rax+0x03]
0000707f9fbcf1bf  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf1c5  movaps xmm13, [r15+0x140]
0000707f9fbcf1cd  pinsrb xmm13, r12d, 0x00
0000707f9fbcf1d4  lea r14, [rax+0x04]
0000707f9fbcf1d8  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf1de  pinsrb xmm1, r12d, 0x01
0000707f9fbcf1e5  lea r14, [rax+0x05]
0000707f9fbcf1e9  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf1ef  pinsrb xmm15, r12d, 0x01
0000707f9fbcf1f6  lea r14, [rax+0x06]
0000707f9fbcf1fa  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf200  pinsrb xmm14, r12d, 0x01
0000707f9fbcf207  lea r14, [rax+0x07]
0000707f9fbcf20b  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf211  pinsrb xmm13, r12d, 0x01
0000707f9fbcf218  lea r14, [rax+0x08]
0000707f9fbcf21c  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf222  pinsrb xmm1, r12d, 0x02
0000707f9fbcf229  lea r14, [rax+0x09]
0000707f9fbcf22d  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf233  pinsrb xmm15, r12d, 0x02
0000707f9fbcf23a  lea r14, [rax+0x0A]
0000707f9fbcf23e  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf244  pinsrb xmm14, r12d, 0x02
0000707f9fbcf24b  lea r14, [rax+0x0B]
0000707f9fbcf24f  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf255  pinsrb xmm13, r12d, 0x02
0000707f9fbcf25c  lea r14, [rax+0x0C]
0000707f9fbcf260  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf266  pinsrb xmm1, r12d, 0x03
0000707f9fbcf26d  lea r14, [rax+0x0D]
0000707f9fbcf271  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf277  pinsrb xmm15, r12d, 0x03
0000707f9fbcf27e  lea r14, [rax+0x0E]
0000707f9fbcf282  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf288  pinsrb xmm14, r12d, 0x03
0000707f9fbcf28f  lea r14, [rax+0x0F]
0000707f9fbcf293  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf299  pinsrb xmm13, r12d, 0x03
0000707f9fbcf2a0  lea r14, [rax+0x10]
0000707f9fbcf2a4  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf2aa  pinsrb xmm1, r12d, 0x04
0000707f9fbcf2b1  lea r14, [rax+0x11]
0000707f9fbcf2b5  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf2bb  pinsrb xmm15, r12d, 0x04
0000707f9fbcf2c2  lea r14, [rax+0x12]
0000707f9fbcf2c6  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf2cc  pinsrb xmm14, r12d, 0x04
0000707f9fbcf2d3  lea r14, [rax+0x13]
0000707f9fbcf2d7  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf2dd  pinsrb xmm13, r12d, 0x04
0000707f9fbcf2e4  lea r14, [rax+0x14]
0000707f9fbcf2e8  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf2ee  pinsrb xmm1, r12d, 0x05
0000707f9fbcf2f5  lea r14, [rax+0x15]
0000707f9fbcf2f9  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf2ff  pinsrb xmm15, r12d, 0x05
0000707f9fbcf306  lea r14, [rax+0x16]
0000707f9fbcf30a  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf310  pinsrb xmm14, r12d, 0x05
0000707f9fbcf317  lea r14, [rax+0x17]
0000707f9fbcf31b  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf321  pinsrb xmm13, r12d, 0x05
0000707f9fbcf328  lea r14, [rax+0x18]
0000707f9fbcf32c  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf332  pinsrb xmm1, r12d, 0x06
0000707f9fbcf339  lea r14, [rax+0x19]
0000707f9fbcf33d  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf343  pinsrb xmm15, r12d, 0x06
0000707f9fbcf34a  lea r14, [rax+0x1A]
0000707f9fbcf34e  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf354  pinsrb xmm14, r12d, 0x06
0000707f9fbcf35b  lea r14, [rax+0x1B]
0000707f9fbcf35f  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf365  pinsrb xmm13, r12d, 0x06
0000707f9fbcf36c  lea r14, [rax+0x1C]
0000707f9fbcf370  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf376  pinsrb xmm1, r12d, 0x07
0000707f9fbcf37d  lea r14, [rax+0x1D]
0000707f9fbcf381  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf387  pinsrb xmm15, r12d, 0x07
0000707f9fbcf38e  lea r14, [rax+0x1E]
0000707f9fbcf392  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf398  pinsrb xmm14, r12d, 0x07
0000707f9fbcf39f  lea r14, [rax+0x1F]
0000707f9fbcf3a3  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf3a9  pinsrb xmm13, r12d, 0x07
0000707f9fbcf3b0  lea r14, [rax+0x20]
0000707f9fbcf3b4  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf3ba  pinsrb xmm1, r12d, 0x08
0000707f9fbcf3c1  lea r14, [rax+0x21]
0000707f9fbcf3c5  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf3cb  pinsrb xmm15, r12d, 0x08
0000707f9fbcf3d2  lea r14, [rax+0x22]
0000707f9fbcf3d6  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf3dc  pinsrb xmm14, r12d, 0x08
0000707f9fbcf3e3  lea r14, [rax+0x23]
0000707f9fbcf3e7  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf3ed  pinsrb xmm13, r12d, 0x08
0000707f9fbcf3f4  lea r14, [rax+0x24]
0000707f9fbcf3f8  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf3fe  pinsrb xmm1, r12d, 0x09
0000707f9fbcf405  lea r14, [rax+0x25]
0000707f9fbcf409  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf40f  pinsrb xmm15, r12d, 0x09
0000707f9fbcf416  lea r14, [rax+0x26]
0000707f9fbcf41a  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf420  pinsrb xmm14, r12d, 0x09
0000707f9fbcf427  lea r14, [rax+0x27]
0000707f9fbcf42b  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf431  pinsrb xmm13, r12d, 0x09
0000707f9fbcf438  lea r14, [rax+0x28]
0000707f9fbcf43c  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf442  pinsrb xmm1, r12d, 0x0A
0000707f9fbcf449  lea r14, [rax+0x29]
0000707f9fbcf44d  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf453  pinsrb xmm15, r12d, 0x0A
0000707f9fbcf45a  lea r14, [rax+0x2A]
0000707f9fbcf45e  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf464  pinsrb xmm14, r12d, 0x0A
0000707f9fbcf46b  lea r14, [rax+0x2B]
0000707f9fbcf46f  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf475  pinsrb xmm13, r12d, 0x0A
0000707f9fbcf47c  lea r14, [rax+0x2C]
0000707f9fbcf480  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf486  pinsrb xmm1, r12d, 0x0B
0000707f9fbcf48d  lea r14, [rax+0x2D]
0000707f9fbcf491  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf497  pinsrb xmm15, r12d, 0x0B
0000707f9fbcf49e  lea r14, [rax+0x2E]
0000707f9fbcf4a2  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf4a8  pinsrb xmm14, r12d, 0x0B
0000707f9fbcf4af  lea r14, [rax+0x2F]
0000707f9fbcf4b3  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf4b9  pinsrb xmm13, r12d, 0x0B
0000707f9fbcf4c0  lea r14, [rax+0x30]
0000707f9fbcf4c4  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf4ca  pinsrb xmm1, r12d, 0x0C
0000707f9fbcf4d1  lea r14, [rax+0x31]
0000707f9fbcf4d5  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf4db  pinsrb xmm15, r12d, 0x0C
0000707f9fbcf4e2  lea r14, [rax+0x32]
0000707f9fbcf4e6  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf4ec  pinsrb xmm14, r12d, 0x0C
0000707f9fbcf4f3  lea r14, [rax+0x33]
0000707f9fbcf4f7  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf4fd  pinsrb xmm13, r12d, 0x0C
0000707f9fbcf504  lea r14, [rax+0x34]
0000707f9fbcf508  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf50e  pinsrb xmm1, r12d, 0x0D
0000707f9fbcf515  lea r14, [rax+0x35]
0000707f9fbcf519  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf51f  pinsrb xmm15, r12d, 0x0D
0000707f9fbcf526  lea r14, [rax+0x36]
0000707f9fbcf52a  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf530  pinsrb xmm14, r12d, 0x0D
0000707f9fbcf537  lea r14, [rax+0x37]
0000707f9fbcf53b  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf541  pinsrb xmm13, r12d, 0x0D
0000707f9fbcf548  lea r14, [rax+0x38]
0000707f9fbcf54c  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf552  pinsrb xmm1, r12d, 0x0E
0000707f9fbcf559  lea r14, [rax+0x39]
0000707f9fbcf55d  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf563  pinsrb xmm15, r12d, 0x0E
0000707f9fbcf56a  lea r14, [rax+0x3A]
0000707f9fbcf56e  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf574  pinsrb xmm14, r12d, 0x0E
0000707f9fbcf57b  lea r14, [rax+0x3B]
0000707f9fbcf57f  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf585  pinsrb xmm13, r12d, 0x0E
0000707f9fbcf58c  lea r14, [rax+0x3C]
0000707f9fbcf590  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf596  pinsrb xmm1, r12d, 0x0F
0000707f9fbcf59d  movaps [r15+0x110], xmm1
0000707f9fbcf5a5  lea r14, [rax+0x3D]
0000707f9fbcf5a9  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf5af  pinsrb xmm15, r12d, 0x0F
0000707f9fbcf5b6  movaps [r15+0x120], xmm15
0000707f9fbcf5be  lea r14, [rax+0x3E]
0000707f9fbcf5c2  movzx r12d, byte ptr [r13+r14*1]
0000707f9fbcf5c8  pinsrb xmm14, r12d, 0x0F
0000707f9fbcf5cf  movaps [r15+0x130], xmm14
0000707f9fbcf5d7  lea r14, [rax+0x3F]
0000707f9fbcf5db  movzx eax, byte ptr [r13+r14*1]
0000707f9fbcf5e1  pinsrb xmm13, eax, 0x0F
0000707f9fbcf5e8  movaps [r15+0x140], xmm13
0000707f9fbcf5f0  movq xmm1, qword ptr [r15+0x120]
0000707f9fbcf5f9  pmovzxbw xmm1, xmm1
0000707f9fbcf5fe  psllw xmm1, 0x00
0000707f9fbcf603  movaps [r15+0x150], xmm1
0000707f9fbcf60b  movq xmm1, qword ptr [r15+0x130]
0000707f9fbcf614  pmovzxbw xmm1, xmm1
0000707f9fbcf619  psllw xmm1, 0x00
0000707f9fbcf61e  movaps [r15+0x160], xmm1
0000707f9fbcf626  movq xmm1, qword ptr [r15+0x110]
0000707f9fbcf62f  pmovzxbw xmm1, xmm1
0000707f9fbcf634  psllw xmm1, 0x00
0000707f9fbcf639  movaps [r15+0x170], xmm1
0000707f9fbcf641  movaps xmm15, [r15+0x110]
0000707f9fbcf649  pextrq rax, xmm15, 0x01
0000707f9fbcf650  movq xmm15, rax
0000707f9fbcf655  pmovzxbw xmm15, xmm15
0000707f9fbcf65b  psllw xmm15, 0x00
0000707f9fbcf661  movaps [r15+0x180], xmm15
0000707f9fbcf669  movaps xmm14, [r15+0x120]
0000707f9fbcf671  pextrq rax, xmm14, 0x01
0000707f9fbcf678  movq xmm14, rax
0000707f9fbcf67d  pmovzxbw xmm14, xmm14
0000707f9fbcf683  psllw xmm14, 0x00
0000707f9fbcf689  movaps [r15+0x210], xmm14
0000707f9fbcf691  movaps xmm13, [r15+0x130]
0000707f9fbcf699  pextrq rax, xmm13, 0x01
0000707f9fbcf6a0  movq xmm13, rax
0000707f9fbcf6a5  pmovzxbw xmm13, xmm13
0000707f9fbcf6ab  psllw xmm13, 0x00
0000707f9fbcf6b1  movaps [r15+0x220], xmm13
0000707f9fbcf6b9  movq xmm12, qword ptr [r15+0x140]
0000707f9fbcf6c2  pmovzxbw xmm12, xmm12
0000707f9fbcf6c8  psllw xmm12, 0x00
0000707f9fbcf6ce  movaps [r15+0x250], xmm12
0000707f9fbcf6d6  movaps xmm12, [r15+0x140]
0000707f9fbcf6de  pextrq rax, xmm12, 0x01
0000707f9fbcf6e5  movq xmm12, rax
0000707f9fbcf6ea  pmovzxbw xmm12, xmm12
0000707f9fbcf6f0  psllw xmm12, 0x00
0000707f9fbcf6f6  movaps [r15+0x110], xmm12
0000707f9fbcf6fe  movq xmm11, qword ptr [r15+0x150]
0000707f9fbcf707  pmovzxwd xmm11, xmm11
0000707f9fbcf70d  pslld xmm11, 0x10
0000707f9fbcf713  movq xmm10, qword ptr [r15+0x160]
0000707f9fbcf71c  pmovzxwd xmm10, xmm10
0000707f9fbcf722  pslld xmm10, 0x08
0000707f9fbcf728  pextrq rax, xmm1, 0x01
0000707f9fbcf72f  movq xmm1, rax
0000707f9fbcf734  pmovzxwd xmm1, xmm1
0000707f9fbcf739  pslld xmm1, 0x00
0000707f9fbcf73e  movaps [r15+0x260], xmm1
0000707f9fbcf746  pextrq rax, xmm15, 0x01
0000707f9fbcf74d  movq xmm15, rax
0000707f9fbcf752  pmovzxwd xmm15, xmm15
0000707f9fbcf758  pslld xmm15, 0x00
0000707f9fbcf75e  movaps [r15+0x270], xmm15
0000707f9fbcf766  movq xmm9, qword ptr [r15+0x170]
0000707f9fbcf76f  pmovzxwd xmm9, xmm9
0000707f9fbcf775  pslld xmm9, 0x00
0000707f9fbcf77b  pextrq rax, xmm14, 0x01
0000707f9fbcf782  movq xmm14, rax
0000707f9fbcf787  pmovzxwd xmm14, xmm14
0000707f9fbcf78d  pslld xmm14, 0x10
0000707f9fbcf793  movaps [r15+0x280], xmm14
0000707f9fbcf79b  movq xmm8, qword ptr [r15+0x180]
0000707f9fbcf7a4  pmovzxwd xmm8, xmm8
0000707f9fbcf7aa  pslld xmm8, 0x00
0000707f9fbcf7b0  movq xmm7, qword ptr [r15+0x210]
0000707f9fbcf7b9  pmovzxwd xmm7, xmm7
0000707f9fbcf7be  pslld xmm7, 0x10
0000707f9fbcf7c3  movaps xmm6, [r15+0x150]
0000707f9fbcf7cb  pextrq rax, xmm6, 0x01
0000707f9fbcf7d2  movq xmm6, rax
0000707f9fbcf7d7  pmovzxwd xmm6, xmm6
0000707f9fbcf7dc  pslld xmm6, 0x10
0000707f9fbcf7e1  por xmm11, xmm10
0000707f9fbcf7e6  movaps [r15+0x230], xmm11
0000707f9fbcf7ee  pextrq rax, xmm13, 0x01
0000707f9fbcf7f5  movq xmm13, rax
0000707f9fbcf7fa  pmovzxwd xmm13, xmm13
0000707f9fbcf800  pslld xmm13, 0x08
0000707f9fbcf806  movaps [r15+0x240], xmm13
0000707f9fbcf80e  movq xmm10, qword ptr [r15+0x220]
0000707f9fbcf817  pmovzxwd xmm10, xmm10
0000707f9fbcf81d  pslld xmm10, 0x08
0000707f9fbcf823  movaps xmm5, [r15+0x160]
0000707f9fbcf82b  pextrq rax, xmm5, 0x01
0000707f9fbcf832  movq xmm5, rax
0000707f9fbcf837  pmovzxwd xmm5, xmm5
0000707f9fbcf83c  pslld xmm5, 0x08
0000707f9fbcf841  pslld xmm9, 0x18
0000707f9fbcf847  pslld xmm15, 0x18
0000707f9fbcf84d  pslld xmm8, 0x18
0000707f9fbcf853  movq xmm4, qword ptr [r15+0x250]
0000707f9fbcf85c  pmovzxwd xmm4, xmm4
0000707f9fbcf861  pslld xmm4, 0x00
0000707f9fbcf866  por xmm14, xmm13
0000707f9fbcf86b  por xmm7, xmm10
0000707f9fbcf870  movaps [r15+0x210], xmm7
0000707f9fbcf878  pslld xmm1, 0x18
0000707f9fbcf87d  movaps [r15+0x220], xmm1
0000707f9fbcf885  por xmm6, xmm5
0000707f9fbcf889  por xmm11, xmm9
0000707f9fbcf88e  movaps [r15+0x160], xmm11
0000707f9fbcf896  pextrq rax, xmm12, 0x01
0000707f9fbcf89d  movq xmm13, rax
0000707f9fbcf8a2  pmovzxwd xmm13, xmm13
0000707f9fbcf8a8  pslld xmm13, 0x00
0000707f9fbcf8ae  movaps [r15+0x170], xmm13
0000707f9fbcf8b6  movq xmm12, qword ptr [r15+0x110]
0000707f9fbcf8bf  pmovzxwd xmm12, xmm12
0000707f9fbcf8c5  pslld xmm12, 0x00
0000707f9fbcf8cb  por xmm14, xmm15
0000707f9fbcf8d0  por xmm7, xmm8
0000707f9fbcf8d5  movaps xmm15, [r15+0x250]
0000707f9fbcf8dd  pextrq rax, xmm15, 0x01
0000707f9fbcf8e4  movq xmm15, rax
0000707f9fbcf8e9  pmovzxwd xmm15, xmm15
0000707f9fbcf8ef  pslld xmm15, 0x00
0000707f9fbcf8f5  movaps [r15+0x180], xmm15
0000707f9fbcf8fd  por xmm6, xmm1
0000707f9fbcf901  movaps [r15+0x150], xmm6
0000707f9fbcf909  por xmm11, xmm4
0000707f9fbcf90e  movaps [r15+0x140], xmm11
0000707f9fbcf916  por xmm7, xmm12
0000707f9fbcf91b  movaps [r15+0x110], xmm7
0000707f9fbcf923  por xmm14, xmm13
0000707f9fbcf928  movaps [r15+0x120], xmm14
0000707f9fbcf930  por xmm6, xmm15
0000707f9fbcf935  movaps [r15+0x130], xmm6
0000707f9fbcf93d  mov rax, [r15+0xF8]
0000707f9fbcf944  lea r14, [rax+0x20]
0000707f9fbcf948  movups [r13+r14*1], xmm7
0000707f9fbcf94e  lea r14, [rax+0x30]
0000707f9fbcf952  movups [r13+r14*1], xmm14
0000707f9fbcf958  movups [r13+rax*1], xmm11
0000707f9fbcf95e  lea r14, [rax+0x10]
0000707f9fbcf962  movups [r13+r14*1], xmm6
0000707f9fbcf968  mov r14d, [r13+rax*1]
0000707f9fbcf96d  mov rax, [r15+0x48]
0000707f9fbcf971  mov [r15+0x68], rax
0000707f9fbcf975  mov qword ptr [r15+0x58], 0x04
0000707f9fbcf97d  lea r12, [rax+0x04]
0000707f9fbcf981  mov r11d, [r13+r12*1]
0000707f9fbcf986  mov [rsp+0x10], r11d
0000707f9fbcf98b  mov r11d, r11d
0000707f9fbcf98e  mov [r15+0x70], r11
0000707f9fbcf992  lea r12, [rax+0x38]
0000707f9fbcf996  mov r11d, [r13+r12*1]
0000707f9fbcf99b  lea r12, [rax+0x24]
0000707f9fbcf99f  mov r10d, [r13+r12*1]
0000707f9fbcf9a4  mov [rsp+0x20], r10d
0000707f9fbcf9a9  mov r10d, r10d
0000707f9fbcf9ac  mov [r15+0x90], r10
0000707f9fbcf9b3  mov [rsp+0x30], rax
0000707f9fbcf9b8  xor eax, eax
0000707f9fbcf9ba  mov r12d, 0x04
0000707f9fbcf9c0  mov r10d, 0xC0
0000707f9fbcf9c6  cmp r12, r10
0000707f9fbcf9c9  cmc
0000707f9fbcf9ca  lahf
0000707f9fbcf9cb  seto al
0000707f9fbcf9ce  mov [r15+0x108], eax
0000707f9fbcf9d5  mov eax, [rsp+0x10]
0000707f9fbcf9d9  mov r12d, [rsp+0x10]
0000707f9fbcf9de  shrd eax, r12d, 0x07
0000707f9fbcf9e3  mov [rsp+0x10], r11d
0000707f9fbcf9e8  mov r10d, [rsp+0x10]
0000707f9fbcf9ed  shrd r11d, r10d, 0x11
0000707f9fbcf9f2  mov r9d, [rsp+0x20]
0000707f9fbcf9f7  lea r8d, [r9d+r14d*1]
0000707f9fbcf9fc  rorx r14d, r12d, 0x12
0000707f9fbcfa02  xor eax, r14d
0000707f9fbcfa05  rorx r14d, r10d, 0x13
0000707f9fbcfa0b  xor r11d, r14d
0000707f9fbcfa0e  mov [rsp+0x10], r11d
0000707f9fbcfa13  mov r11d, r11d
0000707f9fbcfa16  mov [r15+0x88], r11
0000707f9fbcfa1d  mov [rsp+0x20], r12d
0000707f9fbcfa22  shr r12d, 0x03
0000707f9fbcfa26  xor eax, r12d
0000707f9fbcfa29  mov [rsp+0x40], eax
0000707f9fbcfa2d  mov eax, eax
0000707f9fbcfa2f  mov [r15+0x80], rax
0000707f9fbcfa36  shr r10d, 0x0A
0000707f9fbcfa3a  mov eax, [rsp+0x10]
0000707f9fbcfa3e  xor eax, r10d
0000707f9fbcfa41  mov [rsp+0x10], eax
0000707f9fbcfa45  mov eax, eax
0000707f9fbcfa47  mov [r15+0x78], rax
0000707f9fbcfa4b  mov eax, [rsp+0x40]
0000707f9fbcfa4f  lea r14d, [r8d+eax*1]
0000707f9fbcfa54  mov eax, [rsp+0x10]
0000707f9fbcfa58  lea r12d, [r14d+eax*1]
0000707f9fbcfa5d  mov rax, [rsp+0x30]
0000707f9fbcfa62  lea r14, [rax+0x40]
0000707f9fbcfa66  mov [r13+r14*1], r12d
0000707f9fbcfa6b  mov eax, [rsp+0x20]
0000707f9fbcfa6f  mov eax, eax
0000707f9fbcfa71  mov [r15+0x60], rax
0000707f9fbcfa75  mov eax, [r15+0x108]
0000707f9fbcfa7c  sahf
0000707f9fbcfa7d  jnz 0x0000707F9FBCFAAF
0000707f9fbcfa7f  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcfa87  jz 0x0000707F9FBCFF70
0000707f9fbcfa8d  nop [rax+rax*1], ax
0000707f9fbcfa96  nop [rax+rax*1], eax
0000707f9fbcfa9e  mov eax, 0x410820
0000707f9fbcfaa3  mov [r15+0x100], rax
0000707f9fbcfaaa  jmp 0x0000707F9F9FE110
0000707f9fbcfaaf  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcfab7  jz 0x0000707F9FBCFDC0
0000707f9fbcfabd  nop [rax+rax*1], ax
0000707f9fbcfac6  nop [rax+rax*1], eax
0000707f9fbcface  mov eax, 0x4107D8
0000707f9fbcfad3  mov [r15+0x100], rax
0000707f9fbcfada  jmp 0x0000707F9F9FE110
0000707f9fbcfadf  int3
0000707f9fbcfae0  call 0x0000707F9FA0D860
0000707f9fbcfae5  jmp 0x0000707F9FBCF17A
0000707f9fbcfaea  call 0x0000707F9FAE2420
0000707f9fbcfaef  jmp 0x0000707F9FBCF193
0000707f9fbcfaf4  call 0x0000707F9FAE2420
0000707f9fbcfaf9  jmp 0x0000707F9FBCF1AC
0000707f9fbcfafe  call 0x0000707F9FAE2420
0000707f9fbcfb03  jmp 0x0000707F9FBCF1C5
0000707f9fbcfb08  call 0x0000707F9FAE2420
0000707f9fbcfb0d  jmp 0x0000707F9FBCF1DE
0000707f9fbcfb12  call 0x0000707F9FAE2420
0000707f9fbcfb17  jmp 0x0000707F9FBCF1EF
0000707f9fbcfb1c  call 0x0000707F9FAE2420
0000707f9fbcfb21  jmp 0x0000707F9FBCF200
0000707f9fbcfb26  call 0x0000707F9FAE2420
0000707f9fbcfb2b  jmp 0x0000707F9FBCF211
0000707f9fbcfb30  call 0x0000707F9FAE2420
0000707f9fbcfb35  jmp 0x0000707F9FBCF222
0000707f9fbcfb3a  call 0x0000707F9FAE2420
0000707f9fbcfb3f  jmp 0x0000707F9FBCF233
0000707f9fbcfb44  call 0x0000707F9FAE2420
0000707f9fbcfb49  jmp 0x0000707F9FBCF244
0000707f9fbcfb4e  call 0x0000707F9FAE2420
0000707f9fbcfb53  jmp 0x0000707F9FBCF255
0000707f9fbcfb58  call 0x0000707F9FAE2420
0000707f9fbcfb5d  jmp 0x0000707F9FBCF266
0000707f9fbcfb62  call 0x0000707F9FAE2420
0000707f9fbcfb67  jmp 0x0000707F9FBCF277
0000707f9fbcfb6c  call 0x0000707F9FAE2420
0000707f9fbcfb71  jmp 0x0000707F9FBCF288
0000707f9fbcfb76  call 0x0000707F9FAE2420
0000707f9fbcfb7b  jmp 0x0000707F9FBCF299
0000707f9fbcfb80  call 0x0000707F9FAE2420
0000707f9fbcfb85  jmp 0x0000707F9FBCF2AA
0000707f9fbcfb8a  call 0x0000707F9FAE2420
0000707f9fbcfb8f  jmp 0x0000707F9FBCF2BB
0000707f9fbcfb94  call 0x0000707F9FAE2420
0000707f9fbcfb99  jmp 0x0000707F9FBCF2CC
0000707f9fbcfb9e  call 0x0000707F9FAE2420
0000707f9fbcfba3  jmp 0x0000707F9FBCF2DD
0000707f9fbcfba8  call 0x0000707F9FAE2420
0000707f9fbcfbad  jmp 0x0000707F9FBCF2EE
0000707f9fbcfbb2  call 0x0000707F9FAE2420
0000707f9fbcfbb7  jmp 0x0000707F9FBCF2FF
0000707f9fbcfbbc  call 0x0000707F9FAE2420
0000707f9fbcfbc1  jmp 0x0000707F9FBCF310
0000707f9fbcfbc6  call 0x0000707F9FAE2420
0000707f9fbcfbcb  jmp 0x0000707F9FBCF321
0000707f9fbcfbd0  call 0x0000707F9FAE2420
0000707f9fbcfbd5  jmp 0x0000707F9FBCF332
0000707f9fbcfbda  call 0x0000707F9FAE2420
0000707f9fbcfbdf  jmp 0x0000707F9FBCF343
0000707f9fbcfbe4  call 0x0000707F9FAE2420
0000707f9fbcfbe9  jmp 0x0000707F9FBCF354
0000707f9fbcfbee  call 0x0000707F9FAE2420
0000707f9fbcfbf3  jmp 0x0000707F9FBCF365
0000707f9fbcfbf8  call 0x0000707F9FAE2420
0000707f9fbcfbfd  jmp 0x0000707F9FBCF376
0000707f9fbcfc02  call 0x0000707F9FAE2420
0000707f9fbcfc07  jmp 0x0000707F9FBCF387
0000707f9fbcfc0c  call 0x0000707F9FAE2420
0000707f9fbcfc11  jmp 0x0000707F9FBCF398
0000707f9fbcfc16  call 0x0000707F9FAE2420
0000707f9fbcfc1b  jmp 0x0000707F9FBCF3A9
0000707f9fbcfc20  call 0x0000707F9FAE2420
0000707f9fbcfc25  jmp 0x0000707F9FBCF3BA
0000707f9fbcfc2a  call 0x0000707F9FAE2420
0000707f9fbcfc2f  jmp 0x0000707F9FBCF3CB
0000707f9fbcfc34  call 0x0000707F9FAE2420
0000707f9fbcfc39  jmp 0x0000707F9FBCF3DC
0000707f9fbcfc3e  call 0x0000707F9FAE2420
0000707f9fbcfc43  jmp 0x0000707F9FBCF3ED
0000707f9fbcfc48  call 0x0000707F9FAE2420
0000707f9fbcfc4d  jmp 0x0000707F9FBCF3FE
0000707f9fbcfc52  call 0x0000707F9FAE2420
0000707f9fbcfc57  jmp 0x0000707F9FBCF40F
0000707f9fbcfc5c  call 0x0000707F9FAE2420
0000707f9fbcfc61  jmp 0x0000707F9FBCF420
0000707f9fbcfc66  call 0x0000707F9FAE2420
0000707f9fbcfc6b  jmp 0x0000707F9FBCF431
0000707f9fbcfc70  call 0x0000707F9FAE2420
0000707f9fbcfc75  jmp 0x0000707F9FBCF442
0000707f9fbcfc7a  call 0x0000707F9FAE2420
0000707f9fbcfc7f  jmp 0x0000707F9FBCF453
0000707f9fbcfc84  call 0x0000707F9FAE2420
0000707f9fbcfc89  jmp 0x0000707F9FBCF464
0000707f9fbcfc8e  call 0x0000707F9FAE2420
0000707f9fbcfc93  jmp 0x0000707F9FBCF475
0000707f9fbcfc98  call 0x0000707F9FAE2420
0000707f9fbcfc9d  jmp 0x0000707F9FBCF486
0000707f9fbcfca2  call 0x0000707F9FAE2420
0000707f9fbcfca7  jmp 0x0000707F9FBCF497
0000707f9fbcfcac  call 0x0000707F9FAE2420
0000707f9fbcfcb1  jmp 0x0000707F9FBCF4A8
0000707f9fbcfcb6  call 0x0000707F9FAE2420
0000707f9fbcfcbb  jmp 0x0000707F9FBCF4B9
0000707f9fbcfcc0  call 0x0000707F9FAE2420
0000707f9fbcfcc5  jmp 0x0000707F9FBCF4CA
0000707f9fbcfcca  call 0x0000707F9FAE2420
0000707f9fbcfccf  jmp 0x0000707F9FBCF4DB
0000707f9fbcfcd4  call 0x0000707F9FAE2420
0000707f9fbcfcd9  jmp 0x0000707F9FBCF4EC
0000707f9fbcfcde  call 0x0000707F9FAE2420
0000707f9fbcfce3  jmp 0x0000707F9FBCF4FD
0000707f9fbcfce8  call 0x0000707F9FAE2420
0000707f9fbcfced  jmp 0x0000707F9FBCF50E
0000707f9fbcfcf2  call 0x0000707F9FAE2420
0000707f9fbcfcf7  jmp 0x0000707F9FBCF51F
0000707f9fbcfcfc  call 0x0000707F9FAE2420
0000707f9fbcfd01  jmp 0x0000707F9FBCF530
0000707f9fbcfd06  call 0x0000707F9FAE2420
0000707f9fbcfd0b  jmp 0x0000707F9FBCF541
0000707f9fbcfd10  call 0x0000707F9FAE2420
0000707f9fbcfd15  jmp 0x0000707F9FBCF552
0000707f9fbcfd1a  call 0x0000707F9FAE2420
0000707f9fbcfd1f  jmp 0x0000707F9FBCF563
0000707f9fbcfd24  call 0x0000707F9FAE2420
0000707f9fbcfd29  jmp 0x0000707F9FBCF574
0000707f9fbcfd2e  call 0x0000707F9FAE2420
0000707f9fbcfd33  jmp 0x0000707F9FBCF585
0000707f9fbcfd38  call 0x0000707F9FAE2420
0000707f9fbcfd3d  jmp 0x0000707F9FBCF596
0000707f9fbcfd42  call 0x0000707F9FAE2420
0000707f9fbcfd47  jmp 0x0000707F9FBCF5AF
0000707f9fbcfd4c  call 0x0000707F9FAE2420
0000707f9fbcfd51  jmp 0x0000707F9FBCF5C8
0000707f9fbcfd56  call 0x0000707F9FAD5610
0000707f9fbcfd5b  jmp 0x0000707F9FBCF5E1
0000707f9fbcfd60  call 0x0000707F9FADC580
0000707f9fbcfd65  jmp 0x0000707F9FBCF94E
0000707f9fbcfd6a  call 0x0000707F9FAE46C0
0000707f9fbcfd6f  jmp 0x0000707F9FBCF958
0000707f9fbcfd74  call 0x0000707F9FA09E90
0000707f9fbcfd79  jmp 0x0000707F9FBCF95E
0000707f9fbcfd7e  call 0x0000707F9FADB310
0000707f9fbcfd83  jmp 0x0000707F9FBCF968
0000707f9fbcfd88  call 0x0000707F9FA0DAE0
0000707f9fbcfd8d  jmp 0x0000707F9FBCF96D
0000707f9fbcfd92  call 0x0000707F9FAC0230
0000707f9fbcfd97  jmp 0x0000707F9FBCF986
0000707f9fbcfd9c  call 0x0000707F9FAC0230
0000707f9fbcfda1  jmp 0x0000707F9FBCF99B
0000707f9fbcfda6  call 0x0000707F9FABEFC0
0000707f9fbcfdab  jmp 0x0000707F9FBCF9A4
0000707f9fbcfdb0  call 0x0000707F9FAE2BA0
0000707f9fbcfdb5  jmp 0x0000707F9FBCFA6B
0000707f9fbcfdba  int3
0000707f9fbcfdbb  nop [rax+rax*1], eax
0000707f9fbcfdc0  mov rax, [r15+0x48]
0000707f9fbcfdc4  mov r14, [r15+0x58]
0000707f9fbcfdc8  lea r12, [rax+r14*1]
0000707f9fbcfdcc  mov [r15+0x68], r12
0000707f9fbcfdd0  lea rax, [r14+0x04]
0000707f9fbcfdd4  mov [r15+0x58], rax
0000707f9fbcfdd8  lea r14, [r12+0x04]
0000707f9fbcfddd  mov r11d, [r13+r14*1]
0000707f9fbcfde2  mov [rsp+0x10], r11d
0000707f9fbcfde7  mov r11d, r11d
0000707f9fbcfdea  mov [r15+0x70], r11
0000707f9fbcfdee  lea r14, [r12+0x38]
0000707f9fbcfdf3  mov r11d, [r13+r14*1]
0000707f9fbcfdf8  lea r14, [r12+0x24]
0000707f9fbcfdfd  mov r10d, [r13+r14*1]
0000707f9fbcfe02  mov [rsp+0x20], r10d
0000707f9fbcfe07  mov r10d, r10d
0000707f9fbcfe0a  mov [r15+0x90], r10
0000707f9fbcfe11  mov [rsp+0x30], rax
0000707f9fbcfe16  xor eax, eax
0000707f9fbcfe18  mov r14, [rsp+0x30]
0000707f9fbcfe1d  mov r10d, 0xC0
0000707f9fbcfe23  cmp r14, r10
0000707f9fbcfe26  cmc
0000707f9fbcfe27  lahf
0000707f9fbcfe28  seto al
0000707f9fbcfe2b  mov [r15+0x108], eax
0000707f9fbcfe32  mov eax, [rsp+0x10]
0000707f9fbcfe36  mov r14d, [rsp+0x10]
0000707f9fbcfe3b  shrd eax, r14d, 0x07
0000707f9fbcfe40  mov [rsp+0x10], r11d
0000707f9fbcfe45  mov r10d, [rsp+0x10]
0000707f9fbcfe4a  shrd r11d, r10d, 0x11
0000707f9fbcfe4f  mov r9d, [r15+0x60]
0000707f9fbcfe53  mov r8d, [rsp+0x20]
0000707f9fbcfe58  lea ebp, [r8d+r9d*1]
0000707f9fbcfe5d  rorx r9d, r14d, 0x12
0000707f9fbcfe63  xor eax, r9d
0000707f9fbcfe66  rorx r9d, r10d, 0x13
0000707f9fbcfe6c  xor r11d, r9d
0000707f9fbcfe6f  mov [rsp+0x10], r11d
0000707f9fbcfe74  mov r11d, r11d
0000707f9fbcfe77  mov [r15+0x88], r11
0000707f9fbcfe7e  mov [rsp+0x20], r14d
0000707f9fbcfe83  shr r14d, 0x03
0000707f9fbcfe87  xor eax, r14d
0000707f9fbcfe8a  mov [rsp+0x30], eax
0000707f9fbcfe8e  mov eax, eax
0000707f9fbcfe90  mov [r15+0x80], rax
0000707f9fbcfe97  shr r10d, 0x0A
0000707f9fbcfe9b  mov eax, [rsp+0x10]
0000707f9fbcfe9f  xor eax, r10d
0000707f9fbcfea2  mov [rsp+0x10], eax
0000707f9fbcfea6  mov eax, eax
0000707f9fbcfea8  mov [r15+0x78], rax
0000707f9fbcfeac  mov eax, [rsp+0x30]
0000707f9fbcfeb0  lea r14d, [ebp+eax*1]
0000707f9fbcfeb6  mov eax, [rsp+0x10]
0000707f9fbcfeba  lea r11d, [r14d+eax*1]
0000707f9fbcfebf  lea rax, [r12+0x40]
0000707f9fbcfec4  mov [r13+rax*1], r11d
0000707f9fbcfec9  mov eax, [rsp+0x20]
0000707f9fbcfecd  mov eax, eax
0000707f9fbcfecf  mov [r15+0x60], rax
0000707f9fbcfed3  mov eax, [r15+0x108]
0000707f9fbcfeda  sahf
0000707f9fbcfedb  jnz 0x0000707F9FBCFF0D
0000707f9fbcfedd  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcfee5  jz 0x0000707F9FBCFF70
0000707f9fbcfeeb  nop [rax+rax*1], ax
0000707f9fbcfef4  nop [rax+rax*1], eax
0000707f9fbcfefc  mov eax, 0x410820
0000707f9fbcff01  mov [r15+0x100], rax
0000707f9fbcff08  jmp 0x0000707F9F9FE110
0000707f9fbcff0d  cmp dword ptr [r15+0x318], 0x00
0000707f9fbcff15  jz 0x0000707F9FBCFDC0
0000707f9fbcff1b  nop [rax+rax*1], ax
0000707f9fbcff24  nop [rax+rax*1], eax
0000707f9fbcff2c  mov eax, 0x4107D8
0000707f9fbcff31  mov [r15+0x100], rax
0000707f9fbcff38  jmp 0x0000707F9F9FE110
0000707f9fbcff3d  int3
0000707f9fbcff3e  call 0x0000707F9FAE1430
0000707f9fbcff43  jmp 0x0000707F9FBCFDE2
0000707f9fbcff48  call 0x0000707F9FAE1430
0000707f9fbcff4d  jmp 0x0000707F9FBCFDF8
0000707f9fbcff52  call 0x0000707F9FAE01C0
0000707f9fbcff57  jmp 0x0000707F9FBCFE02
0000707f9fbcff5c  call 0x0000707F9FA0A860
0000707f9fbcff61  jmp 0x0000707F9FBCFEC9
0000707f9fbcff66  int3
0000707f9fbcff67  nop [rax+rax*1], ax
0000707f9fbcff70  mov rax, [r15]
0000707f9fbcff73  mov r14d, [r13+rax*1]
0000707f9fbcff78  lea r12, [rax+0x04]
0000707f9fbcff7c  mov r11d, [r13+r12*1]
0000707f9fbcff81  mov [rsp+0x10], r14d
0000707f9fbcff86  mov r14d, r14d
0000707f9fbcff89  mov [r15+0x78], r14
0000707f9fbcff8d  mov [rsp+0x20], r11d
0000707f9fbcff92  mov r11d, r11d
0000707f9fbcff95  mov [r15+0x80], r11
0000707f9fbcff9c  lea r14, [rax+0x08]
0000707f9fbcffa0  mov r12d, [r13+r14*1]
0000707f9fbcffa5  lea r14, [rax+0x0C]
0000707f9fbcffa9  mov r11d, [r13+r14*1]
0000707f9fbcffae  mov [rsp+0x30], r12d
0000707f9fbcffb3  mov r12d, r12d
0000707f9fbcffb6  mov [r15+0x70], r12
0000707f9fbcffba  mov [rsp+0x40], r11d
0000707f9fbcffbf  mov r11d, r11d
0000707f9fbcffc2  mov [r15+0x68], r11
0000707f9fbcffc6  lea r14, [rax+0x18]
0000707f9fbcffca  mov r12d, [r13+r14*1]
0000707f9fbcffcf  lea r14, [rax+0x1C]
0000707f9fbcffd3  mov r11d, [r13+r14*1]
0000707f9fbcffd8  mov [rsp+0x50], r12d
0000707f9fbcffdd  mov r12d, r12d
0000707f9fbcffe0  mov [r15+0x58], r12
0000707f9fbcffe4  mov [rsp+0x60], r11d
0000707f9fbcffe9  mov r11d, r11d
0000707f9fbcffec  mov [r15+0x60], r11
0000707f9fbcfff0  lea r14, [rax+0x10]
0000707f9fbcfff4  mov r12d, [r13+r14*1]
0000707f9fbcfff9  lea r14, [rax+0x14]
0000707f9fbcfffd  mov eax, [r13+r14*1]
0000707f9fbd0002  mov [rsp+0x70], r12d
0000707f9fbd0007  mov r12d, r12d
0000707f9fbd000a  mov [r15+0x18], r12
0000707f9fbd000e  mov [rsp+0x80], eax
0000707f9fbd0015  mov eax, eax
0000707f9fbd0017  mov [r15+0x90], rax
0000707f9fbd001e  mov eax, [rsp+0x70]
0000707f9fbd0022  mov eax, eax
0000707f9fbd0024  mov [r15+0x30], rax
0000707f9fbd0028  mov eax, [rsp+0x50]
0000707f9fbd002c  mov eax, eax
0000707f9fbd002e  mov [r15+0xA0], rax
0000707f9fbd0035  mov eax, [rsp+0x30]
0000707f9fbd0039  mov eax, eax
0000707f9fbd003b  mov [r15+0x28], rax
0000707f9fbd003f  mov eax, [rsp+0x20]
0000707f9fbd0043  mov eax, eax
0000707f9fbd0045  mov [r15+0x98], rax
0000707f9fbd004c  mov eax, [rsp+0x10]
0000707f9fbd0050  mov eax, eax
0000707f9fbd0052  mov [r15+0x38], rax
0000707f9fbd0056  mov eax, [rsp+0x70]
0000707f9fbd005a  mov r14d, [rsp+0x70]
0000707f9fbd005f  shrd eax, r14d, 0x06
0000707f9fbd0064  mov [rsp+0x70], r14d
0000707f9fbd0069  mov r12d, [rsp+0x80]
0000707f9fbd0071  and r14d, r12d
0000707f9fbd0074  mov r11d, [rsp+0x10]
0000707f9fbd0079  mov r10d, [rsp+0x10]
0000707f9fbd007e  shrd r11d, r10d, 0x02
0000707f9fbd0083  mov [rsp+0x10], r12d
0000707f9fbd0088  mov r12d, r12d
0000707f9fbd008b  mov [r15+0x20], r12
0000707f9fbd008f  mov r12, [r15+0x50]
0000707f9fbd0093  mov r9d, [r13+r12*1]
0000707f9fbd0098  mov r12d, [rsp+0x50]
0000707f9fbd009d  mov r8d, [rsp+0x70]
0000707f9fbd00a2  andn ebp, r8d, r12d
0000707f9fbd00a7  mov edi, [rsp+0x60]
0000707f9fbd00ab  lea esi, [r14d+edi*1]
0000707f9fbd00b0  rorx r14d, r8d, 0x0B
0000707f9fbd00b6  xor eax, r14d
0000707f9fbd00b9  rorx r14d, r10d, 0x0D
0000707f9fbd00bf  xor r11d, r14d
0000707f9fbd00c2  lea edi, [esi+ebp*1]
0000707f9fbd00c6  mov r14, [r15+0x48]
0000707f9fbd00ca  mov ebp, [r13+r14*1]
0000707f9fbd00cf  mov r14d, [rsp+0x30]
0000707f9fbd00d4  mov esi, [rsp+0x20]
0000707f9fbd00d8  and r14d, esi
0000707f9fbd00db  mov [rsp+0x20], r14d
0000707f9fbd00e0  mov r14d, r14d
0000707f9fbd00e3  mov [r15+0xD8], r14
0000707f9fbd00ea  lea r14d, [edi+r9d*1]
0000707f9fbd00ef  mov r9d, [rsp+0x30]
0000707f9fbd00f4  xor r9d, esi
0000707f9fbd00f7  rorx edi, r8d, 0x19
0000707f9fbd00fd  xor eax, edi
0000707f9fbd00ff  and r9d, r10d
0000707f9fbd0102  rorx edi, r10d, 0x16
0000707f9fbd0108  xor r11d, edi
0000707f9fbd010b  mov [rsp+0x30], r11d
0000707f9fbd0110  mov r11d, r11d
0000707f9fbd0113  mov [r15+0xD0], r11
0000707f9fbd011a  lea r11d, [r14d+ebp*1]
0000707f9fbd011f  mov r10d, [rsp+0x20]
0000707f9fbd0124  xor r9d, r10d
0000707f9fbd0127  lea r14d, [r11d+eax*1]
0000707f9fbd012c  mov qword ptr [r15+0x88], 0x04
0000707f9fbd0137  mov eax, [rsp+0x30]
0000707f9fbd013b  lea r11d, [r9d+eax*1]
0000707f9fbd0140  mov eax, [rsp+0x40]
0000707f9fbd0144  lea r10d, [r14d+eax*1]
0000707f9fbd0149  mov r10d, r10d
0000707f9fbd014c  mov [r15+0xB8], r10
0000707f9fbd0153  xor eax, eax
0000707f9fbd0155  mov r10d, 0x04
0000707f9fbd015b  mov r9d, 0x100
0000707f9fbd0161  cmp r10, r9
0000707f9fbd0164  cmc
0000707f9fbd0165  lahf
0000707f9fbd0166  seto al
0000707f9fbd0169  mov [r15+0x108], eax
0000707f9fbd0170  lea eax, [r11d+r14d*1]
0000707f9fbd0175  mov eax, eax
0000707f9fbd0177  mov [r15+0xA8], rax
0000707f9fbd017e  mov r12d, r12d
0000707f9fbd0181  mov [r15+0xB0], r12
0000707f9fbd0188  mov eax, [rsp+0x10]
0000707f9fbd018c  mov eax, eax
0000707f9fbd018e  mov [r15+0xC0], rax
0000707f9fbd0195  mov r8d, r8d
0000707f9fbd0198  mov [r15+0xC8], r8
0000707f9fbd019f  mov eax, [r15+0x108]
0000707f9fbd01a6  sahf
0000707f9fbd01a7  jnz 0x0000707F9FBD01D9
0000707f9fbd01a9  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd01b1  jz 0x0000707F9FBD04A0
0000707f9fbd01b7  nop [rax+rax*1], ax
0000707f9fbd01c0  nop [rax+rax*1], eax
0000707f9fbd01c8  mov eax, 0x4108E0
0000707f9fbd01cd  mov [r15+0x100], rax
0000707f9fbd01d4  jmp 0x0000707F9F9FE110
0000707f9fbd01d9  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd01e1  jz 0x0000707F9FBD0270
0000707f9fbd01e7  nop [rax+rax*1], ax
0000707f9fbd01f0  nop [rax+rax*1], eax
0000707f9fbd01f8  mov eax, 0x410854
0000707f9fbd01fd  mov [r15+0x100], rax
0000707f9fbd0204  jmp 0x0000707F9F9FE110
0000707f9fbd0209  int3
0000707f9fbd020a  call 0x0000707F9FA0DAE0
0000707f9fbd020f  jmp 0x0000707F9FBCFF78
0000707f9fbd0214  call 0x0000707F9FAC0230
0000707f9fbd0219  jmp 0x0000707F9FBCFF81
0000707f9fbd021e  call 0x0000707F9FAE26A0
0000707f9fbd0223  jmp 0x0000707F9FBCFFA5
0000707f9fbd0228  call 0x0000707F9FAE1430
0000707f9fbd022d  jmp 0x0000707F9FBCFFAE
0000707f9fbd0232  call 0x0000707F9FAE26A0
0000707f9fbd0237  jmp 0x0000707F9FBCFFCF
0000707f9fbd023c  call 0x0000707F9FAE1430
0000707f9fbd0241  jmp 0x0000707F9FBCFFD8
0000707f9fbd0246  call 0x0000707F9FAE26A0
0000707f9fbd024b  jmp 0x0000707F9FBCFFF9
0000707f9fbd0250  call 0x0000707F9FAD5890
0000707f9fbd0255  jmp 0x0000707F9FBD0002
0000707f9fbd025a  call 0x0000707F9FABDD50
0000707f9fbd025f  jmp 0x0000707F9FBD0098
0000707f9fbd0264  call 0x0000707F9FADA580
0000707f9fbd0269  jmp 0x0000707F9FBD00CF
0000707f9fbd026e  int3
0000707f9fbd026f  nop
0000707f9fbd0270  mov eax, [r15+0xB8]
0000707f9fbd0277  mov [rsp+0x10], eax
0000707f9fbd027b  mov eax, eax
0000707f9fbd027d  mov [r15+0x30], rax
0000707f9fbd0281  mov eax, [r15+0xC0]
0000707f9fbd0288  mov [rsp+0x20], eax
0000707f9fbd028c  mov eax, eax
0000707f9fbd028e  mov [r15+0xA0], rax
0000707f9fbd0295  mov eax, [r15+0x28]
0000707f9fbd0299  mov r14d, [r15+0x98]
0000707f9fbd02a0  mov [rsp+0x30], r14d
0000707f9fbd02a5  mov r14d, r14d
0000707f9fbd02a8  mov [r15+0x28], r14
0000707f9fbd02ac  mov r14d, [r15+0x38]
0000707f9fbd02b0  mov [rsp+0x40], r14d
0000707f9fbd02b5  mov r14d, r14d
0000707f9fbd02b8  mov [r15+0x98], r14
0000707f9fbd02bf  mov r14d, [r15+0xA8]
0000707f9fbd02c6  mov [rsp+0x50], r14d
0000707f9fbd02cb  mov r14d, r14d
0000707f9fbd02ce  mov [r15+0x38], r14
0000707f9fbd02d2  mov r14d, [rsp+0x10]
0000707f9fbd02d7  mov r12d, [rsp+0x10]
0000707f9fbd02dc  shrd r14d, r12d, 0x06
0000707f9fbd02e1  mov r11d, [r15+0xC8]
0000707f9fbd02e8  mov [rsp+0x10], r12d
0000707f9fbd02ed  and r12d, r11d
0000707f9fbd02f0  mov r10d, [rsp+0x50]
0000707f9fbd02f5  mov r9d, [rsp+0x50]
0000707f9fbd02fa  shrd r10d, r9d, 0x02
0000707f9fbd02ff  mov [rsp+0x50], r11d
0000707f9fbd0304  mov r11d, r11d
0000707f9fbd0307  mov [r15+0x20], r11
0000707f9fbd030b  mov r11, [r15+0x88]
0000707f9fbd0312  mov r8, [r15+0x50]
0000707f9fbd0316  lea rbp, [r8+r11*1]
0000707f9fbd031a  mov r8d, [r13+rbp*1]
0000707f9fbd031f  mov ebp, [rsp+0x20]
0000707f9fbd0323  mov edi, [rsp+0x10]
0000707f9fbd0327  andn esi, edi, ebp
0000707f9fbd032c  mov edx, [r15+0xB0]
0000707f9fbd0333  lea ecx, [r12d+edx*1]
0000707f9fbd0338  rorx r12d, edi, 0x0B
0000707f9fbd033e  xor r14d, r12d
0000707f9fbd0341  rorx r12d, r9d, 0x0D
0000707f9fbd0347  xor r10d, r12d
0000707f9fbd034a  lea r12d, [ecx+esi*1]
0000707f9fbd034f  mov rsi, [r15+0x48]
0000707f9fbd0353  lea rdx, [rsi+r11*1]
0000707f9fbd0357  mov esi, [r13+rdx*1]
0000707f9fbd035c  mov edx, [rsp+0x30]
0000707f9fbd0360  mov ecx, [rsp+0x40]
0000707f9fbd0364  and edx, ecx
0000707f9fbd0366  mov [rsp+0x10], edx
0000707f9fbd036a  mov edx, edx
0000707f9fbd036c  mov [r15+0xD8], rdx
0000707f9fbd0373  lea edx, [r12d+r8d*1]
0000707f9fbd0378  mov r12d, [rsp+0x30]
0000707f9fbd037d  xor r12d, ecx
0000707f9fbd0380  rorx r8d, edi, 0x19
0000707f9fbd0386  xor r14d, r8d
0000707f9fbd0389  and r12d, r9d
0000707f9fbd038c  rorx r8d, r9d, 0x16
0000707f9fbd0392  xor r10d, r8d
0000707f9fbd0395  mov [rsp+0x20], r10d
0000707f9fbd039a  mov r10d, r10d
0000707f9fbd039d  mov [r15+0xD0], r10
0000707f9fbd03a4  lea r10d, [edx+esi*1]
0000707f9fbd03a9  mov r9d, [rsp+0x10]
0000707f9fbd03ae  xor r12d, r9d
0000707f9fbd03b1  lea r9d, [r10d+r14d*1]
0000707f9fbd03b6  lea r14, [r11+0x04]
0000707f9fbd03ba  mov [r15+0x88], r14
0000707f9fbd03c1  mov r11d, [rsp+0x20]
0000707f9fbd03c6  lea r10d, [r12d+r11d*1]
0000707f9fbd03cb  lea r11d, [r9d+eax*1]
0000707f9fbd03d0  mov r11d, r11d
0000707f9fbd03d3  mov [r15+0xB8], r11
0000707f9fbd03da  xor eax, eax
0000707f9fbd03dc  mov r12d, 0x100
0000707f9fbd03e2  cmp r14, r12
0000707f9fbd03e5  cmc
0000707f9fbd03e6  lahf
0000707f9fbd03e7  seto al
0000707f9fbd03ea  mov [r15+0x108], eax
0000707f9fbd03f1  lea eax, [r10d+r9d*1]
0000707f9fbd03f6  mov eax, eax
0000707f9fbd03f8  mov [r15+0xA8], rax
0000707f9fbd03ff  mov ebp, ebp
0000707f9fbd0401  mov [r15+0xB0], rbp
0000707f9fbd0408  mov eax, [rsp+0x50]
0000707f9fbd040c  mov eax, eax
0000707f9fbd040e  mov [r15+0xC0], rax
0000707f9fbd0415  mov edi, edi
0000707f9fbd0417  mov [r15+0xC8], rdi
0000707f9fbd041e  mov eax, [r15+0x108]
0000707f9fbd0425  sahf
0000707f9fbd0426  jnz 0x0000707F9FBD0458
0000707f9fbd0428  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0430  jz 0x0000707F9FBD04A0
0000707f9fbd0436  nop [rax+rax*1], ax
0000707f9fbd043f  nop [rax+rax*1], eax
0000707f9fbd0447  mov eax, 0x4108E0
0000707f9fbd044c  mov [r15+0x100], rax
0000707f9fbd0453  jmp 0x0000707F9F9FE110
0000707f9fbd0458  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0460  jz 0x0000707F9FBD0270
0000707f9fbd0466  nop [rax+rax*1], ax
0000707f9fbd046f  nop [rax+rax*1], eax
0000707f9fbd0477  mov eax, 0x410854
0000707f9fbd047c  mov [r15+0x100], rax
0000707f9fbd0483  jmp 0x0000707F9F9FE110
0000707f9fbd0488  int3
0000707f9fbd0489  call 0x0000707F9FA49010
0000707f9fbd048e  jmp 0x0000707F9FBD031F
0000707f9fbd0493  call 0x0000707F9FA25930
0000707f9fbd0498  jmp 0x0000707F9FBD035C
0000707f9fbd049d  int3
0000707f9fbd049e  nop
0000707f9fbd04a0  mov eax, [r15+0x98]
0000707f9fbd04a7  mov r14d, [r15+0x70]
0000707f9fbd04ab  lea r12d, [eax+r14d*1]
0000707f9fbd04b0  mov eax, [r15+0x28]
0000707f9fbd04b4  mov r14d, [r15+0x68]
0000707f9fbd04b8  lea r11d, [eax+r14d*1]
0000707f9fbd04bd  mov qword ptr [r15+0x88], 0x00
0000707f9fbd04c8  mov eax, [r15+0xA8]
0000707f9fbd04cf  mov r14d, [r15+0x78]
0000707f9fbd04d3  lea r10d, [eax+r14d*1]
0000707f9fbd04d8  mov [rsp+0x10], r10d
0000707f9fbd04dd  mov r10d, r10d
0000707f9fbd04e0  mov [r15+0x78], r10
0000707f9fbd04e4  mov eax, [r15+0x38]
0000707f9fbd04e8  mov r14d, [r15+0x80]
0000707f9fbd04ef  lea r10d, [eax+r14d*1]
0000707f9fbd04f4  mov [rsp+0x20], r10d
0000707f9fbd04f9  mov r10d, r10d
0000707f9fbd04fc  mov [r15+0x80], r10
0000707f9fbd0503  mov rax, [r15]
0000707f9fbd0506  lea r14, [rax+0x08]
0000707f9fbd050a  mov [r13+r14*1], r12d
0000707f9fbd050f  lea r14, [rax+0x0C]
0000707f9fbd0513  mov [r13+r14*1], r11d
0000707f9fbd0518  mov r14d, [r15+0xB8]
0000707f9fbd051f  mov r12d, [r15+0x18]
0000707f9fbd0523  lea r11d, [r14d+r12d*1]
0000707f9fbd0528  mov [rsp+0x30], r11d
0000707f9fbd052d  mov r11d, r11d
0000707f9fbd0530  mov [r15+0x68], r11
0000707f9fbd0534  mov r14d, [r15+0x30]
0000707f9fbd0538  mov r12d, [r15+0x90]
0000707f9fbd053f  lea r11d, [r14d+r12d*1]
0000707f9fbd0544  mov [rsp+0x40], r11d
0000707f9fbd0549  mov r11d, r11d
0000707f9fbd054c  mov [r15+0x70], r11
0000707f9fbd0550  mov r14d, [r15+0x20]
0000707f9fbd0554  mov r12d, [r15+0x58]
0000707f9fbd0558  lea r11d, [r14d+r12d*1]
0000707f9fbd055d  mov [rsp+0x50], r11d
0000707f9fbd0562  mov r11d, r11d
0000707f9fbd0565  mov [r15+0x58], r11
0000707f9fbd0569  mov r14d, [r15+0xA0]
0000707f9fbd0570  mov r12d, [r15+0x60]
0000707f9fbd0574  lea r11d, [r14d+r12d*1]
0000707f9fbd0579  mov [rsp+0x60], r11d
0000707f9fbd057e  mov r11d, r11d
0000707f9fbd0581  mov [r15+0x60], r11
0000707f9fbd0585  mov r14d, [rsp+0x10]
0000707f9fbd058a  mov [r13+rax*1], r14d
0000707f9fbd058f  lea r14, [rax+0x04]
0000707f9fbd0593  mov r12d, [rsp+0x20]
0000707f9fbd0598  mov [r13+r14*1], r12d
0000707f9fbd059d  lea r14, [rax+0x10]
0000707f9fbd05a1  mov r12d, [rsp+0x30]
0000707f9fbd05a6  mov [r13+r14*1], r12d
0000707f9fbd05ab  lea r14, [rax+0x14]
0000707f9fbd05af  mov r12d, [rsp+0x40]
0000707f9fbd05b4  mov [r13+r14*1], r12d
0000707f9fbd05b9  lea r14, [rax+0x18]
0000707f9fbd05bd  mov r12d, [rsp+0x50]
0000707f9fbd05c2  mov [r13+r14*1], r12d
0000707f9fbd05c7  lea r14, [rax+0x1C]
0000707f9fbd05cb  mov r12d, [rsp+0x60]
0000707f9fbd05d0  mov [r13+r14*1], r12d
0000707f9fbd05d5  lea r14, [rax+0x68]
0000707f9fbd05d9  xor eax, eax
0000707f9fbd05db  mov [r13+r14*1], rax
0000707f9fbd05e0  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd05e8  jz 0x0000707F9FBCF0E0
0000707f9fbd05ee  nop [rax+rax*1], ax
0000707f9fbd05f7  nop [rax+rax*1], eax
0000707f9fbd05ff  mov eax, 0x4106FC
0000707f9fbd0604  mov [r15+0x100], rax
0000707f9fbd060b  jmp 0x0000707F9F9FE110
0000707f9fbd0610  int3
0000707f9fbd0611  call 0x0000707F9FAE2BA0
0000707f9fbd0616  jmp 0x0000707F9FBD050F
0000707f9fbd061b  call 0x0000707F9FAE1920
0000707f9fbd0620  jmp 0x0000707F9FBD0518
0000707f9fbd0625  call 0x0000707F9FA0DFE0
0000707f9fbd062a  jmp 0x0000707F9FBD058F
0000707f9fbd062f  call 0x0000707F9FAE2BA0
0000707f9fbd0634  jmp 0x0000707F9FBD059D
0000707f9fbd0639  call 0x0000707F9FAE2BA0
0000707f9fbd063e  jmp 0x0000707F9FBD05AB
0000707f9fbd0643  call 0x0000707F9FAE2BA0
0000707f9fbd0648  jmp 0x0000707F9FBD05B9
0000707f9fbd064d  call 0x0000707F9FAE2BA0
0000707f9fbd0652  jmp 0x0000707F9FBD05C7
0000707f9fbd0657  call 0x0000707F9FAE2BA0
0000707f9fbd065c  jmp 0x0000707F9FBD05D5
0000707f9fbd0661  call 0x0000707F9FAD5EB0
0000707f9fbd0666  jmp 0x0000707F9FBD05E0
0000707f9fbd066b  int3
0000707f9fbd066c  nop [rax], eax
0000707f9fbd0670  mov rax, [r15+0xF8]
0000707f9fbd0677  lea r14, [rax+0x140]
0000707f9fbd067e  mov r12, [r13+r14*1]
0000707f9fbd0683  lea r14, [rax+0x148]
0000707f9fbd068a  mov r11, [r13+r14*1]
0000707f9fbd068f  mov [r15+0xA0], r12
0000707f9fbd0696  mov [r15+0x98], r11
0000707f9fbd069d  lea r14, [rax+0x130]
0000707f9fbd06a4  mov r12, [r13+r14*1]
0000707f9fbd06a9  lea r14, [rax+0x138]
0000707f9fbd06b0  mov r11, [r13+r14*1]
0000707f9fbd06b5  mov [r15+0xB0], r12
0000707f9fbd06bc  mov [r15+0xA8], r11
0000707f9fbd06c3  lea r14, [rax+0x120]
0000707f9fbd06ca  mov r12, [r13+r14*1]
0000707f9fbd06cf  lea r14, [rax+0x128]
0000707f9fbd06d6  mov r11, [r13+r14*1]
0000707f9fbd06db  mov [r15+0xC0], r12
0000707f9fbd06e2  mov [r15+0xB8], r11
0000707f9fbd06e9  lea r14, [rax+0x110]
0000707f9fbd06f0  mov r12, [r13+r14*1]
0000707f9fbd06f5  lea r14, [rax+0x118]
0000707f9fbd06fc  mov r11, [r13+r14*1]
0000707f9fbd0701  mov [r15+0xD0], r12
0000707f9fbd0708  mov [r15+0xC8], r11
0000707f9fbd070f  lea r14, [rax+0x100]
0000707f9fbd0716  mov r12, [r13+r14*1]
0000707f9fbd071b  lea r14, [rax+0x108]
0000707f9fbd0722  mov r11, [r13+r14*1]
0000707f9fbd0727  mov [r15+0xE8], r12
0000707f9fbd072e  mov [r15+0xD8], r11
0000707f9fbd0735  lea r14, [rax+0x150]
0000707f9fbd073c  mov [r15+0xF8], r14
0000707f9fbd0743  mov rax, [r15+0xF0]
0000707f9fbd074a  mov [r15+0x100], rax
0000707f9fbd0751  jmp 0x0000707F9FBCE5C0
0000707f9fbd0756  int3
0000707f9fbd0757  call 0x0000707F9FAE27E0
0000707f9fbd075c  jmp 0x0000707F9FBD0683
0000707f9fbd0761  call 0x0000707F9FAE1570
0000707f9fbd0766  jmp 0x0000707F9FBD068F
0000707f9fbd076b  call 0x0000707F9FAE27E0
0000707f9fbd0770  jmp 0x0000707F9FBD06A9
0000707f9fbd0775  call 0x0000707F9FAE1570
0000707f9fbd077a  jmp 0x0000707F9FBD06B5
0000707f9fbd077f  call 0x0000707F9FAE27E0
0000707f9fbd0784  jmp 0x0000707F9FBD06CF
0000707f9fbd0789  call 0x0000707F9FAE1570
0000707f9fbd078e  jmp 0x0000707F9FBD06DB
0000707f9fbd0793  call 0x0000707F9FAE27E0
0000707f9fbd0798  jmp 0x0000707F9FBD06F5
0000707f9fbd079d  call 0x0000707F9FAE1570
0000707f9fbd07a2  jmp 0x0000707F9FBD0701
0000707f9fbd07a7  call 0x0000707F9FAE27E0
0000707f9fbd07ac  jmp 0x0000707F9FBD071B
0000707f9fbd07b1  call 0x0000707F9FAE1570
0000707f9fbd07b6  jmp 0x0000707F9FBD0727
0000707f9fbd07bb  int3
0000707f9fbd07bc  nop [rax], eax
0000707f9fbd07c0  mov eax, [r15+0xA0]
0000707f9fbd07c7  mov [rsp+0x10], eax
0000707f9fbd07cb  xor eax, eax
0000707f9fbd07cd  mov r14d, [rsp+0x10]
0000707f9fbd07d2  sub r14d, 0x01
0000707f9fbd07d6  cmc
0000707f9fbd07d7  lahf
0000707f9fbd07d8  seto al
0000707f9fbd07db  mov [r15+0x108], eax
0000707f9fbd07e2  mov r14d, r14d
0000707f9fbd07e5  mov [r15+0xA0], r14
0000707f9fbd07ec  mov eax, [r15+0x108]
0000707f9fbd07f3  sahf
0000707f9fbd07f4  jnz 0x0000707F9FBD0826
0000707f9fbd07f6  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd07fe  jz 0x0000707F9FBD0900
0000707f9fbd0804  nop [rax+rax*1], ax
0000707f9fbd080d  nop [rax+rax*1], eax
0000707f9fbd0815  mov eax, 0x41028C
0000707f9fbd081a  mov [r15+0x100], rax
0000707f9fbd0821  jmp 0x0000707F9F9FE110
0000707f9fbd0826  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd082e  jz 0x0000707F9FBD0860
0000707f9fbd0834  nop [rax+rax*1], ax
0000707f9fbd083d  nop [rax+rax*1], eax
0000707f9fbd0845  mov eax, 0x410274
0000707f9fbd084a  mov [r15+0x100], rax
0000707f9fbd0851  jmp 0x0000707F9F9FE110
0000707f9fbd0856  int3
0000707f9fbd0857  int3
0000707f9fbd0858  nop [rax+rax*1], eax
0000707f9fbd0860  mov rax, [r15+0xF8]
0000707f9fbd0867  lea r14, [rax+0xD0]
0000707f9fbd086e  mov [r15], r14
0000707f9fbd0871  mov rax, [r15+0x98]
0000707f9fbd0878  mov [r15+0x08], rax
0000707f9fbd087c  mov qword ptr [r15+0x10], 0x12C
0000707f9fbd0884  mov qword ptr [r15+0xF0], 0x410284
0000707f9fbd088f  mov r14d, [r15+0x320]
0000707f9fbd0896  mov eax, 0x410284
0000707f9fbd089b  mov rcx, 0x707F9FBD07C0
0000707f9fbd08a5  mov [r15+r14*8+0x328], rax
0000707f9fbd08ad  mov [r15+r14*8+0x368], rcx
0000707f9fbd08b5  add r14d, 0x01
0000707f9fbd08b9  and r14d, 0x07
0000707f9fbd08bd  mov [r15+0x320], r14d
0000707f9fbd08c4  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd08cc  jz 0x0000707F9FBCED70
0000707f9fbd08d2  nop [rax+rax*1], ax
0000707f9fbd08db  nop [rax+rax*1], eax
0000707f9fbd08e3  mov eax, 0x4106BC
0000707f9fbd08e8  mov [r15+0x100], rax
0000707f9fbd08ef  jmp 0x0000707F9F9FE110
0000707f9fbd08f4  int3
0000707f9fbd08f5  int3
0000707f9fbd08f6  nop [rax+rax*1], ax
0000707f9fbd08ff  nop
0000707f9fbd0900  mov rax, [r15+0xF8]
0000707f9fbd0907  lea r14, [rax+0xF0]
0000707f9fbd090e  mov r12, [r13+r14*1]
0000707f9fbd0913  mov [r15+0x98], r12
0000707f9fbd091a  mov qword ptr [r15+0x40], 0x80
0000707f9fbd0922  lea r14, [rax+0xD0]
0000707f9fbd0929  mov [r15], r14
0000707f9fbd092c  lea r14, [rax+0x14C]
0000707f9fbd0933  mov [r15+0x08], r14
0000707f9fbd0937  mov qword ptr [r15+0x10], 0x01
0000707f9fbd093f  lea r14, [rax+0x14C]
0000707f9fbd0946  mov eax, 0x80
0000707f9fbd094b  mov [r13+r14*1], al
0000707f9fbd0950  mov qword ptr [r15+0xF0], 0x4102A8
0000707f9fbd095b  mov r14d, [r15+0x320]
0000707f9fbd0962  mov eax, 0x4102A8
0000707f9fbd0967  mov rcx, 0x707F9FBD09E0
0000707f9fbd0971  mov [r15+r14*8+0x328], rax
0000707f9fbd0979  mov [r15+r14*8+0x368], rcx
0000707f9fbd0981  add r14d, 0x01
0000707f9fbd0985  and r14d, 0x07
0000707f9fbd0989  mov [r15+0x320], r14d
0000707f9fbd0990  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0998  jz 0x0000707F9FBCED70
0000707f9fbd099e  nop [rax+rax*1], ax
0000707f9fbd09a7  nop [rax+rax*1], eax
0000707f9fbd09af  mov eax, 0x4106BC
0000707f9fbd09b4  mov [r15+0x100], rax
0000707f9fbd09bb  jmp 0x0000707F9F9FE110
0000707f9fbd09c0  int3
0000707f9fbd09c1  call 0x0000707F9FAE27E0
0000707f9fbd09c6  jmp 0x0000707F9FBD0913
0000707f9fbd09cb  call 0x0000707F9FAD5AF0
0000707f9fbd09d0  jmp 0x0000707F9FBD0950
0000707f9fbd09d5  int3
0000707f9fbd09d6  nop [rax+rax*1], ax
0000707f9fbd09df  nop
0000707f9fbd09e0  mov rax, [r15+0xF8]
0000707f9fbd09e7  lea r14, [rax+0x138]
0000707f9fbd09ee  mov r12, [r13+r14*1]
0000707f9fbd09f3  mov [r15+0x40], r12
0000707f9fbd09f7  lea r14, [rax+0x148]
0000707f9fbd09fe  xor eax, eax
0000707f9fbd0a00  mov [r13+r14*1], al
0000707f9fbd0a05  xor eax, eax
0000707f9fbd0a07  mov r14d, 0x38
0000707f9fbd0a0d  cmp r12, r14
0000707f9fbd0a10  cmc
0000707f9fbd0a11  lahf
0000707f9fbd0a12  seto al
0000707f9fbd0a15  mov [r15+0x108], eax
0000707f9fbd0a1c  mov eax, [r15+0x108]
0000707f9fbd0a23  sahf
0000707f9fbd0a24  jz 0x0000707F9FBD0A56
0000707f9fbd0a26  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0a2e  jz 0x0000707F9FBD0AA0
0000707f9fbd0a34  nop [rax+rax*1], ax
0000707f9fbd0a3d  nop [rax+rax*1], eax
0000707f9fbd0a45  mov eax, 0x4102B8
0000707f9fbd0a4a  mov [r15+0x100], rax
0000707f9fbd0a51  jmp 0x0000707F9F9FE110
0000707f9fbd0a56  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0a5e  jz 0x0000707F9FBD0BF0
0000707f9fbd0a64  nop [rax+rax*1], ax
0000707f9fbd0a6d  nop [rax+rax*1], eax
0000707f9fbd0a75  mov eax, 0x4102D4
0000707f9fbd0a7a  mov [r15+0x100], rax
0000707f9fbd0a81  jmp 0x0000707F9F9FE110
0000707f9fbd0a86  int3
0000707f9fbd0a87  call 0x0000707F9FAE27E0
0000707f9fbd0a8c  jmp 0x0000707F9FBD09F3
0000707f9fbd0a91  call 0x0000707F9FAD5AF0
0000707f9fbd0a96  jmp 0x0000707F9FBD0A05
0000707f9fbd0a9b  int3
0000707f9fbd0a9c  nop [rax], eax
0000707f9fbd0aa0  mov rax, [r15+0xF8]
0000707f9fbd0aa7  lea r14, [rax+0xD0]
0000707f9fbd0aae  mov [r15], r14
0000707f9fbd0ab1  lea r14, [rax+0x148]
0000707f9fbd0ab8  mov [r15+0x08], r14
0000707f9fbd0abc  mov qword ptr [r15+0x10], 0x01
0000707f9fbd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
0000707f9fbd0acf  mov r14d, [r15+0x320]
0000707f9fbd0ad6  mov eax, 0x4102C8
0000707f9fbd0adb  mov rcx, 0x707F9FBD0B40
0000707f9fbd0ae5  mov [r15+r14*8+0x328], rax
0000707f9fbd0aed  mov [r15+r14*8+0x368], rcx
0000707f9fbd0af5  add r14d, 0x01
0000707f9fbd0af9  and r14d, 0x07
0000707f9fbd0afd  mov [r15+0x320], r14d
0000707f9fbd0b04  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0b0c  jz 0x0000707F9FBCED70
0000707f9fbd0b12  nop [rax+rax*1], ax
0000707f9fbd0b1b  nop [rax+rax*1], eax
0000707f9fbd0b23  mov eax, 0x4106BC
0000707f9fbd0b28  mov [r15+0x100], rax
0000707f9fbd0b2f  jmp 0x0000707F9F9FE110
0000707f9fbd0b34  int3
0000707f9fbd0b35  int3
0000707f9fbd0b36  nop [rax+rax*1], ax
0000707f9fbd0b3f  nop
0000707f9fbd0b40  mov rax, [r15+0xF8]
0000707f9fbd0b47  lea r14, [rax+0x138]
0000707f9fbd0b4e  mov rax, [r13+r14*1]
0000707f9fbd0b53  mov [r15+0x40], rax
0000707f9fbd0b57  mov [rsp+0x10], rax
0000707f9fbd0b5c  xor eax, eax
0000707f9fbd0b5e  mov r14, [rsp+0x10]
0000707f9fbd0b63  mov r12d, 0x38
0000707f9fbd0b69  cmp r14, r12
0000707f9fbd0b6c  cmc
0000707f9fbd0b6d  lahf
0000707f9fbd0b6e  seto al
0000707f9fbd0b71  mov [r15+0x108], eax
0000707f9fbd0b78  mov eax, [r15+0x108]
0000707f9fbd0b7f  sahf
0000707f9fbd0b80  jnz 0x0000707F9FBD0BB2
0000707f9fbd0b82  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0b8a  jz 0x0000707F9FBD0BF0
0000707f9fbd0b90  nop [rax+rax*1], ax
0000707f9fbd0b99  nop [rax+rax*1], eax
0000707f9fbd0ba1  mov eax, 0x4102D4
0000707f9fbd0ba6  mov [r15+0x100], rax
0000707f9fbd0bad  jmp 0x0000707F9F9FE110
0000707f9fbd0bb2  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0bba  jz 0x0000707F9FBD0AA0
0000707f9fbd0bc0  nop [rax+rax*1], ax
0000707f9fbd0bc9  nop [rax+rax*1], eax
0000707f9fbd0bd1  mov eax, 0x4102B8
0000707f9fbd0bd6  mov [r15+0x100], rax
0000707f9fbd0bdd  jmp 0x0000707F9F9FE110
0000707f9fbd0be2  int3
0000707f9fbd0be3  call 0x0000707F9FAD59C0
0000707f9fbd0be8  jmp 0x0000707F9FBD0B53
0000707f9fbd0bed  int3
0000707f9fbd0bee  nop
0000707f9fbd0bf0  mov rax, [r15+0x98]
0000707f9fbd0bf7  rorx r14, rax, 0x3D
0000707f9fbd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
0000707f9fbd0c01  mov rax, [r15+0xF8]
0000707f9fbd0c08  lea r12, [rax+0xD0]
0000707f9fbd0c0f  mov [r15], r12
0000707f9fbd0c12  lea r12, [rax+0x140]
0000707f9fbd0c19  mov [r15+0x08], r12
0000707f9fbd0c1d  mov qword ptr [r15+0x10], 0x08
0000707f9fbd0c25  bswap r14
0000707f9fbd0c28  mov [r15+0x40], r14
0000707f9fbd0c2c  lea r12, [rax+0x140]
0000707f9fbd0c33  mov [r13+r12*1], r14
0000707f9fbd0c38  mov qword ptr [r15+0xF0], 0x4102F0
0000707f9fbd0c43  mov r14d, [r15+0x320]
0000707f9fbd0c4a  mov eax, 0x4102F0
0000707f9fbd0c4f  mov rcx, 0x707F9FBD0CC0
0000707f9fbd0c59  mov [r15+r14*8+0x328], rax
0000707f9fbd0c61  mov [r15+r14*8+0x368], rcx
0000707f9fbd0c69  add r14d, 0x01
0000707f9fbd0c6d  and r14d, 0x07
0000707f9fbd0c71  mov [r15+0x320], r14d
0000707f9fbd0c78  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0c80  jz 0x0000707F9FBCED70
0000707f9fbd0c86  nop [rax+rax*1], ax
0000707f9fbd0c8f  nop [rax+rax*1], eax
0000707f9fbd0c97  mov eax, 0x4106BC
0000707f9fbd0c9c  mov [r15+0x100], rax
0000707f9fbd0ca3  jmp 0x0000707F9F9FE110
0000707f9fbd0ca8  int3
0000707f9fbd0ca9  call 0x0000707F9FAC3FE0
0000707f9fbd0cae  jmp 0x0000707F9FBD0C38
0000707f9fbd0cb3  int3
0000707f9fbd0cb4  nop [rax+rax*1], ax
0000707f9fbd0cbd  nop [rax], eax
0000707f9fbd0cc0  mov rax, [r15+0xF8]
0000707f9fbd0cc7  lea r14, [rax+0xD0]
0000707f9fbd0cce  mov r12d, [r13+r14*1]
0000707f9fbd0cd3  lea r14, [rax+0xD4]
0000707f9fbd0cda  mov r11d, [r13+r14*1]
0000707f9fbd0cdf  lea r14, [rax+0xD8]
0000707f9fbd0ce6  mov r10d, [r13+r14*1]
0000707f9fbd0ceb  lea r14, [rax+0xDC]
0000707f9fbd0cf2  mov r9d, [r13+r14*1]
0000707f9fbd0cf7  mov qword ptr [r15+0x48], 0x430C20
0000707f9fbd0cff  mov qword ptr [r15+0xA0], 0x00
0000707f9fbd0d0a  bswap r12d
0000707f9fbd0d0d  bswap r11d
0000707f9fbd0d10  mov qword ptr [r15+0x98], 0x430D8C
0000707f9fbd0d1b  mov r14d, 0x430C20
0000707f9fbd0d21  mov [r13+r14*1], r12d
0000707f9fbd0d26  mov r14d, 0x430C24
0000707f9fbd0d2c  mov [r13+r14*1], r11d
0000707f9fbd0d31  bswap r10d
0000707f9fbd0d34  bswap r9d
0000707f9fbd0d37  lea r14, [rax+0xE0]
0000707f9fbd0d3e  mov r12d, [r13+r14*1]
0000707f9fbd0d43  lea r14, [rax+0xE4]
0000707f9fbd0d4a  mov r11d, [r13+r14*1]
0000707f9fbd0d4f  mov r14d, 0x430C28
0000707f9fbd0d55  mov [r13+r14*1], r10d
0000707f9fbd0d5a  mov r14d, 0x430C2C
0000707f9fbd0d60  mov [r13+r14*1], r9d
0000707f9fbd0d65  bswap r12d
0000707f9fbd0d68  bswap r11d
0000707f9fbd0d6b  mov [rsp+0x10], r11d
0000707f9fbd0d70  mov r11d, r11d
0000707f9fbd0d73  mov [r15+0x58], r11
0000707f9fbd0d77  lea r14, [rax+0xE8]
0000707f9fbd0d7e  mov r11d, [r13+r14*1]
0000707f9fbd0d83  lea r14, [rax+0xEC]
0000707f9fbd0d8a  mov eax, [r13+r14*1]
0000707f9fbd0d8f  mov [rsp+0x20], eax
0000707f9fbd0d93  mov eax, eax
0000707f9fbd0d95  mov [r15+0x60], rax
0000707f9fbd0d99  mov eax, 0x430C30
0000707f9fbd0d9e  mov [r13+rax*1], r12d
0000707f9fbd0da3  mov eax, 0x430C34
0000707f9fbd0da8  mov r14d, [rsp+0x10]
0000707f9fbd0dad  mov [r13+rax*1], r14d
0000707f9fbd0db2  bswap r11d
0000707f9fbd0db5  mov [rsp+0x10], r11d
0000707f9fbd0dba  mov r11d, r11d
0000707f9fbd0dbd  mov [r15+0x40], r11
0000707f9fbd0dc1  mov eax, [rsp+0x20]
0000707f9fbd0dc5  bswap eax
0000707f9fbd0dc7  mov [rsp+0x20], eax
0000707f9fbd0dcb  mov eax, eax
0000707f9fbd0dcd  mov [r15+0x50], rax
0000707f9fbd0dd1  mov eax, 0x430C38
0000707f9fbd0dd6  mov r14d, [rsp+0x10]
0000707f9fbd0ddb  mov [r13+rax*1], r14d
0000707f9fbd0de0  mov eax, 0x430C3C
0000707f9fbd0de5  mov r14d, [rsp+0x20]
0000707f9fbd0dea  mov [r13+rax*1], r14d
0000707f9fbd0def  mov eax, [r15+0xA0]
0000707f9fbd0df6  lea r14d, [eax+0x11]
0000707f9fbd0dfb  mov r14d, r14d
0000707f9fbd0dfe  mov [r15], r14
0000707f9fbd0e01  mov qword ptr [r15+0xF0], 0x41034C
0000707f9fbd0e0c  mov r14d, [r15+0x320]
0000707f9fbd0e13  mov eax, 0x41034C
0000707f9fbd0e18  mov rcx, 0x707F9FBD0F90
0000707f9fbd0e22  mov [r15+r14*8+0x328], rax
0000707f9fbd0e2a  mov [r15+r14*8+0x368], rcx
0000707f9fbd0e32  add r14d, 0x01
0000707f9fbd0e36  and r14d, 0x07
0000707f9fbd0e3a  mov [r15+0x320], r14d
0000707f9fbd0e41  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0e49  jz 0x0000707F9FBD0F20
0000707f9fbd0e4f  nop [rax+rax*1], ax
0000707f9fbd0e58  nop [rax+rax*1], eax
0000707f9fbd0e60  mov eax, 0x410938
0000707f9fbd0e65  mov [r15+0x100], rax
0000707f9fbd0e6c  jmp 0x0000707F9F9FE110
0000707f9fbd0e71  int3
0000707f9fbd0e72  call 0x0000707F9FAE26A0
0000707f9fbd0e77  jmp 0x0000707F9FBD0CD3
0000707f9fbd0e7c  call 0x0000707F9FAE1430
0000707f9fbd0e81  jmp 0x0000707F9FBD0CDF
0000707f9fbd0e86  call 0x0000707F9FAE01C0
0000707f9fbd0e8b  jmp 0x0000707F9FBD0CEB
0000707f9fbd0e90  call 0x0000707F9FADEF50
0000707f9fbd0e95  jmp 0x0000707F9FBD0CF7
0000707f9fbd0e9a  call 0x0000707F9FAE2BA0
0000707f9fbd0e9f  jmp 0x0000707F9FBD0D26
0000707f9fbd0ea4  call 0x0000707F9FAE1920
0000707f9fbd0ea9  jmp 0x0000707F9FBD0D31
0000707f9fbd0eae  call 0x0000707F9FAE26A0
0000707f9fbd0eb3  jmp 0x0000707F9FBD0D43
0000707f9fbd0eb8  call 0x0000707F9FAE1430
0000707f9fbd0ebd  jmp 0x0000707F9FBD0D4F
0000707f9fbd0ec2  call 0x0000707F9FAE06B0
0000707f9fbd0ec7  jmp 0x0000707F9FBD0D5A
0000707f9fbd0ecc  call 0x0000707F9FADF440
0000707f9fbd0ed1  jmp 0x0000707F9FBD0D65
0000707f9fbd0ed6  call 0x0000707F9FAE1430
0000707f9fbd0edb  jmp 0x0000707F9FBD0D83
0000707f9fbd0ee0  call 0x0000707F9FAD5890
0000707f9fbd0ee5  jmp 0x0000707F9FBD0D8F
0000707f9fbd0eea  call 0x0000707F9FA0BAE0
0000707f9fbd0eef  jmp 0x0000707F9FBD0DA3
0000707f9fbd0ef4  call 0x0000707F9FA0DFE0
0000707f9fbd0ef9  jmp 0x0000707F9FBD0DB2
0000707f9fbd0efe  call 0x0000707F9FA0DFE0
0000707f9fbd0f03  jmp 0x0000707F9FBD0DE0
0000707f9fbd0f08  call 0x0000707F9FA0DFE0
0000707f9fbd0f0d  jmp 0x0000707F9FBD0DEF
0000707f9fbd0f12  int3
0000707f9fbd0f13  nop [rax+rax*1], ax
0000707f9fbd0f1c  nop [rax], eax
0000707f9fbd0f20  mov eax, [r15]
0000707f9fbd0f23  mov [rsp+0x10], eax
0000707f9fbd0f27  shr eax, 0x10
0000707f9fbd0f2a  mov r14d, [rsp+0x10]
0000707f9fbd0f2f  xor r14d, eax
0000707f9fbd0f32  imul r14d, r14d, 0x7FEB352D
0000707f9fbd0f39  mov eax, 0x846CA68B
0000707f9fbd0f3e  mov eax, eax
0000707f9fbd0f40  mov [r15+0x48], rax
0000707f9fbd0f44  mov [rsp+0x10], r14d
0000707f9fbd0f49  shr r14d, 0x0F
0000707f9fbd0f4d  mov eax, [rsp+0x10]
0000707f9fbd0f51  xor eax, r14d
0000707f9fbd0f54  imul eax, eax, 0x846CA68B
0000707f9fbd0f5a  mov [rsp+0x10], eax
0000707f9fbd0f5e  mov eax, eax
0000707f9fbd0f60  mov [r15+0x40], rax
0000707f9fbd0f64  mov eax, [rsp+0x10]
0000707f9fbd0f68  shr eax, 0x10
0000707f9fbd0f6b  mov r14d, [rsp+0x10]
0000707f9fbd0f70  xor r14d, eax
0000707f9fbd0f73  mov r14d, r14d
0000707f9fbd0f76  mov [r15], r14
0000707f9fbd0f79  mov rax, [r15+0xF0]
0000707f9fbd0f80  mov [r15+0x100], rax
0000707f9fbd0f87  jmp 0x0000707F9FBCE5C0
0000707f9fbd0f8c  int3
0000707f9fbd0f8d  int3
0000707f9fbd0f8e  nop
0000707f9fbd0f90  mov rax, [r15+0xA0]
0000707f9fbd0f97  mov [rsp+0x10], rax
0000707f9fbd0f9c  shl rax, 0x02
0000707f9fbd0fa0  mov r14, [r15+0x98]
0000707f9fbd0fa7  lea r12, [r14+rax*1]
0000707f9fbd0fab  mov eax, [r15]
0000707f9fbd0fae  mov [r13+r12*1], eax
0000707f9fbd0fb3  mov rax, [rsp+0x10]
0000707f9fbd0fb8  lea r14, [rax+0x01]
0000707f9fbd0fbc  mov [r15+0xA0], r14
0000707f9fbd0fc3  xor eax, eax
0000707f9fbd0fc5  mov r12d, 0x400
0000707f9fbd0fcb  cmp r14, r12
0000707f9fbd0fce  cmc
0000707f9fbd0fcf  lahf
0000707f9fbd0fd0  seto al
0000707f9fbd0fd3  mov [r15+0x108], eax
0000707f9fbd0fda  mov eax, [r15+0x108]
0000707f9fbd0fe1  sahf
0000707f9fbd0fe2  jnz 0x0000707F9FBD1014
0000707f9fbd0fe4  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd0fec  jz 0x0000707F9FBD10E0
0000707f9fbd0ff2  nop [rax+rax*1], ax
0000707f9fbd0ffb  nop [rax+rax*1], eax
0000707f9fbd1003  mov eax, 0x41035C
0000707f9fbd1008  mov [r15+0x100], rax
0000707f9fbd100f  jmp 0x0000707F9F9FE110
0000707f9fbd1014  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd101c  jz 0x0000707F9FBD1050
0000707f9fbd1022  nop [rax+rax*1], ax
0000707f9fbd102b  nop [rax+rax*1], eax
0000707f9fbd1033  mov eax, 0x410344
0000707f9fbd1038  mov [r15+0x100], rax
0000707f9fbd103f  jmp 0x0000707F9F9FE110
0000707f9fbd1044  int3
0000707f9fbd1045  call 0x0000707F9FAB4B70
0000707f9fbd104a  jmp 0x0000707F9FBD0FB3
0000707f9fbd104f  int3
0000707f9fbd1050  mov eax, [r15+0xA0]
0000707f9fbd1057  lea r14d, [eax+0x11]
0000707f9fbd105c  mov r14d, r14d
0000707f9fbd105f  mov [r15], r14
0000707f9fbd1062  mov qword ptr [r15+0xF0], 0x41034C
0000707f9fbd106d  mov r14d, [r15+0x320]
0000707f9fbd1074  mov eax, 0x41034C
0000707f9fbd1079  mov rcx, 0x707F9FBD0F90
0000707f9fbd1083  mov [r15+r14*8+0x328], rax
0000707f9fbd108b  mov [r15+r14*8+0x368], rcx
0000707f9fbd1093  add r14d, 0x01
0000707f9fbd1097  and r14d, 0x07
0000707f9fbd109b  mov [r15+0x320], r14d
0000707f9fbd10a2  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd10aa  jz 0x0000707F9FBD0F20
0000707f9fbd10b0  nop [rax+rax*1], ax
0000707f9fbd10b9  nop [rax+rax*1], eax
0000707f9fbd10c1  mov eax, 0x410938
0000707f9fbd10c6  mov [r15+0x100], rax
0000707f9fbd10cd  jmp 0x0000707F9F9FE110
0000707f9fbd10d2  int3
0000707f9fbd10d3  int3
0000707f9fbd10d4  nop [rax+rax*1], ax
0000707f9fbd10dd  nop [rax], eax
0000707f9fbd10e0  mov qword ptr [r15+0x40], 0x01
0000707f9fbd10e8  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd10f0  jz 0x0000707F9FBD1120
0000707f9fbd10f6  nop [rax+rax*1], ax
0000707f9fbd10ff  nop [rax+rax*1], eax
0000707f9fbd1107  mov eax, 0x410378
0000707f9fbd110c  mov [r15+0x100], rax
0000707f9fbd1113  jmp 0x0000707F9F9FE110
0000707f9fbd1118  int3
0000707f9fbd1119  int3
0000707f9fbd111a  nop [rax+rax*1], ax
0000707f9fbd1120  mov rax, [r15+0x40]
0000707f9fbd1124  mov [rsp+0x10], rax
0000707f9fbd1129  shl rax, 0x02
0000707f9fbd112d  mov r14, [r15+0x98]
0000707f9fbd1134  lea r12, [r14+rax*1]
0000707f9fbd1138  mov eax, [r13+r12*1]
0000707f9fbd113d  mov [rsp+0x20], eax
0000707f9fbd1141  mov eax, eax
0000707f9fbd1143  mov [r15+0x48], rax
0000707f9fbd1147  mov rax, [rsp+0x10]
0000707f9fbd114c  mov [r15+0x50], rax
0000707f9fbd1150  mov eax, [r15+0x50]
0000707f9fbd1154  lea r12d, [eax-0x01]
0000707f9fbd1159  mov r12d, r12d
0000707f9fbd115c  mov [r15+0x58], r12
0000707f9fbd1160  mov rax, [r15+0x58]
0000707f9fbd1164  mov r12d, eax
0000707f9fbd1167  mov r12d, r12d
0000707f9fbd116a  shl r12, 0x02
0000707f9fbd116e  lea rax, [r14+r12*1]
0000707f9fbd1172  mov r14d, [r13+rax*1]
0000707f9fbd1177  mov [rsp+0x10], r14d
0000707f9fbd117c  mov r14d, r14d
0000707f9fbd117f  mov [r15+0x60], r14
0000707f9fbd1183  xor eax, eax
0000707f9fbd1185  mov r14d, [rsp+0x10]
0000707f9fbd118a  mov r12d, [rsp+0x20]
0000707f9fbd118f  cmp r14d, r12d
0000707f9fbd1192  cmc
0000707f9fbd1193  lahf
0000707f9fbd1194  seto al
0000707f9fbd1197  mov [r15+0x108], eax
0000707f9fbd119e  mov eax, [r15+0x108]
0000707f9fbd11a5  sahf
0000707f9fbd11a6  cmc
0000707f9fbd11a7  jbe 0x0000707F9FBD11D9
0000707f9fbd11a9  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd11b1  jz 0x0000707F9FBD1220
0000707f9fbd11b7  nop [rax+rax*1], ax
0000707f9fbd11c0  nop [rax+rax*1], eax
0000707f9fbd11c8  mov eax, 0x410390
0000707f9fbd11cd  mov [r15+0x100], rax
0000707f9fbd11d4  jmp 0x0000707F9F9FE110
0000707f9fbd11d9  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd11e1  jz 0x0000707F9FBD14C0
0000707f9fbd11e7  nop [rax+rax*1], ax
0000707f9fbd11f0  nop [rax+rax*1], eax
0000707f9fbd11f8  mov eax, 0x410368
0000707f9fbd11fd  mov [r15+0x100], rax
0000707f9fbd1204  jmp 0x0000707F9F9FE110
0000707f9fbd1209  int3
0000707f9fbd120a  call 0x0000707F9FAB4690
0000707f9fbd120f  jmp 0x0000707F9FBD113D
0000707f9fbd1214  call 0x0000707F9FA0DAE0
0000707f9fbd1219  jmp 0x0000707F9FBD1177
0000707f9fbd121e  int3
0000707f9fbd121f  nop
0000707f9fbd1220  mov rax, [r15+0x50]
0000707f9fbd1224  mov [rsp+0x10], rax
0000707f9fbd1229  shl rax, 0x02
0000707f9fbd122d  mov r14, [r15+0x98]
0000707f9fbd1234  lea r12, [r14+rax*1]
0000707f9fbd1238  mov eax, [r15+0x60]
0000707f9fbd123c  mov [r13+r12*1], eax
0000707f9fbd1241  mov rax, [rsp+0x10]
0000707f9fbd1246  lea r14, [rax-0x01]
0000707f9fbd124a  mov [r15+0x50], r14
0000707f9fbd124e  mov rax, [r15+0x58]
0000707f9fbd1252  test rax, rax
0000707f9fbd1255  setz al
0000707f9fbd1258  movzx rax, al
0000707f9fbd125c  mov [rsp+0x414], al
0000707f9fbd1263  cmp byte ptr [rsp+0x414], 0x00
0000707f9fbd126b  jz 0x0000707F9FBD129D
0000707f9fbd126d  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd1275  jz 0x0000707F9FBD12E0
0000707f9fbd127b  nop [rax+rax*1], ax
0000707f9fbd1284  nop [rax+rax*1], eax
0000707f9fbd128c  mov eax, 0x41039C
0000707f9fbd1291  mov [r15+0x100], rax
0000707f9fbd1298  jmp 0x0000707F9F9FE110
0000707f9fbd129d  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd12a5  jz 0x0000707F9FBD13E0
0000707f9fbd12ab  nop [rax+rax*1], ax
0000707f9fbd12b4  nop [rax+rax*1], eax
0000707f9fbd12bc  mov eax, 0x410380
0000707f9fbd12c1  mov [r15+0x100], rax
0000707f9fbd12c8  jmp 0x0000707F9F9FE110
0000707f9fbd12cd  int3
0000707f9fbd12ce  call 0x0000707F9FAB4B70
0000707f9fbd12d3  jmp 0x0000707F9FBD1241
0000707f9fbd12d8  int3
0000707f9fbd12d9  nop [rax], eax
0000707f9fbd12e0  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd12e8  jz 0x0000707F9FBD1320
0000707f9fbd12ee  nop [rax+rax*1], ax
0000707f9fbd12f7  nop [rax+rax*1], eax
0000707f9fbd12ff  mov eax, 0x410364
0000707f9fbd1304  mov [r15+0x100], rax
0000707f9fbd130b  jmp 0x0000707F9F9FE110
0000707f9fbd1310  int3
0000707f9fbd1311  int3
0000707f9fbd1312  nop [rax+rax*1], ax
0000707f9fbd131b  nop [rax+rax*1], eax
0000707f9fbd1320  mov qword ptr [r15+0x50], 0x00
0000707f9fbd1328  mov rax, [r15+0x40]
0000707f9fbd132c  lea r14, [rax+0x01]
0000707f9fbd1330  mov [r15+0x40], r14
0000707f9fbd1334  mov rax, [r15+0x98]
0000707f9fbd133b  mov r12d, [r15+0x48]
0000707f9fbd133f  mov [r13+rax*1], r12d
0000707f9fbd1344  xor eax, eax
0000707f9fbd1346  mov r12d, 0x400
0000707f9fbd134c  cmp r14, r12
0000707f9fbd134f  cmc
0000707f9fbd1350  lahf
0000707f9fbd1351  seto al
0000707f9fbd1354  mov [r15+0x108], eax
0000707f9fbd135b  mov eax, [r15+0x108]
0000707f9fbd1362  sahf
0000707f9fbd1363  jz 0x0000707F9FBD1395
0000707f9fbd1365  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd136d  jz 0x0000707F9FBD1120
0000707f9fbd1373  nop [rax+rax*1], ax
0000707f9fbd137c  nop [rax+rax*1], eax
0000707f9fbd1384  mov eax, 0x410378
0000707f9fbd1389  mov [r15+0x100], rax
0000707f9fbd1390  jmp 0x0000707F9F9FE110
0000707f9fbd1395  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd139d  jz 0x0000707F9FBD1580
0000707f9fbd13a3  nop [rax+rax*1], ax
0000707f9fbd13ac  nop [rax+rax*1], eax
0000707f9fbd13b4  mov eax, 0x4103A0
0000707f9fbd13b9  mov [r15+0x100], rax
0000707f9fbd13c0  jmp 0x0000707F9F9FE110
0000707f9fbd13c5  int3
0000707f9fbd13c6  call 0x0000707F9FA0BAE0
0000707f9fbd13cb  jmp 0x0000707F9FBD1344
0000707f9fbd13d0  int3
0000707f9fbd13d1  nop [rax+rax*1], ax
0000707f9fbd13da  nop [rax+rax*1], ax
0000707f9fbd13e0  mov eax, [r15+0x50]
0000707f9fbd13e4  lea r14d, [eax-0x01]
0000707f9fbd13e9  mov r14d, r14d
0000707f9fbd13ec  mov [r15+0x58], r14
0000707f9fbd13f0  mov rax, [r15+0x58]
0000707f9fbd13f4  mov r14d, eax
0000707f9fbd13f7  mov r14d, r14d
0000707f9fbd13fa  shl r14, 0x02
0000707f9fbd13fe  mov rax, [r15+0x98]
0000707f9fbd1405  lea r12, [rax+r14*1]
0000707f9fbd1409  mov eax, [r13+r12*1]
0000707f9fbd140e  mov [rsp+0x10], eax
0000707f9fbd1412  mov eax, eax
0000707f9fbd1414  mov [r15+0x60], rax
0000707f9fbd1418  mov eax, [r15+0x48]
0000707f9fbd141c  mov [rsp+0x20], eax
0000707f9fbd1420  xor eax, eax
0000707f9fbd1422  mov r14d, [rsp+0x10]
0000707f9fbd1427  mov r12d, [rsp+0x20]
0000707f9fbd142c  cmp r14d, r12d
0000707f9fbd142f  cmc
0000707f9fbd1430  lahf
0000707f9fbd1431  seto al
0000707f9fbd1434  mov [r15+0x108], eax
0000707f9fbd143b  mov eax, [r15+0x108]
0000707f9fbd1442  sahf
0000707f9fbd1443  cmc
0000707f9fbd1444  jbe 0x0000707F9FBD1476
0000707f9fbd1446  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd144e  jz 0x0000707F9FBD1220
0000707f9fbd1454  nop [rax+rax*1], ax
0000707f9fbd145d  nop [rax+rax*1], eax
0000707f9fbd1465  mov eax, 0x410390
0000707f9fbd146a  mov [r15+0x100], rax
0000707f9fbd1471  jmp 0x0000707F9F9FE110
0000707f9fbd1476  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd147e  jz 0x0000707F9FBD14C0
0000707f9fbd1484  nop [rax+rax*1], ax
0000707f9fbd148d  nop [rax+rax*1], eax
0000707f9fbd1495  mov eax, 0x410368
0000707f9fbd149a  mov [r15+0x100], rax
0000707f9fbd14a1  jmp 0x0000707F9F9FE110
0000707f9fbd14a6  int3
0000707f9fbd14a7  call 0x0000707F9FAB4690
0000707f9fbd14ac  jmp 0x0000707F9FBD140E
0000707f9fbd14b1  int3
0000707f9fbd14b2  nop [rax+rax*1], ax
0000707f9fbd14bb  nop [rax+rax*1], eax
0000707f9fbd14c0  mov rax, [r15+0x40]
0000707f9fbd14c4  lea r14, [rax+0x01]
0000707f9fbd14c8  mov [r15+0x40], r14
0000707f9fbd14cc  mov rax, [r15+0x50]
0000707f9fbd14d0  mov r12d, eax
0000707f9fbd14d3  mov r12d, r12d
0000707f9fbd14d6  shl r12, 0x02
0000707f9fbd14da  mov rax, [r15+0x98]
0000707f9fbd14e1  lea r11, [rax+r12*1]
0000707f9fbd14e5  mov eax, [r15+0x48]
0000707f9fbd14e9  mov [r13+r11*1], eax
0000707f9fbd14ee  xor eax, eax
0000707f9fbd14f0  mov r12d, 0x400
0000707f9fbd14f6  cmp r14, r12
0000707f9fbd14f9  cmc
0000707f9fbd14fa  lahf
0000707f9fbd14fb  seto al
0000707f9fbd14fe  mov [r15+0x108], eax
0000707f9fbd1505  mov eax, [r15+0x108]
0000707f9fbd150c  sahf
0000707f9fbd150d  jz 0x0000707F9FBD153F
0000707f9fbd150f  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd1517  jz 0x0000707F9FBD1120
0000707f9fbd151d  nop [rax+rax*1], ax
0000707f9fbd1526  nop [rax+rax*1], eax
0000707f9fbd152e  mov eax, 0x410378
0000707f9fbd1533  mov [r15+0x100], rax
0000707f9fbd153a  jmp 0x0000707F9F9FE110
0000707f9fbd153f  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd1547  jz 0x0000707F9FBD1580
0000707f9fbd154d  nop [rax+rax*1], ax
0000707f9fbd1556  nop [rax+rax*1], eax
0000707f9fbd155e  mov eax, 0x4103A0
0000707f9fbd1563  mov [r15+0x100], rax
0000707f9fbd156a  jmp 0x0000707F9F9FE110
0000707f9fbd156f  int3
0000707f9fbd1570  call 0x0000707F9FAA4270
0000707f9fbd1575  jmp 0x0000707F9FBD14EE
0000707f9fbd157a  int3
0000707f9fbd157b  nop [rax+rax*1], eax
0000707f9fbd1580  mov qword ptr [r15+0x40], 0x430000
0000707f9fbd1588  mov eax, 0x430C40
0000707f9fbd158d  mov r14, [r13+rax*1]
0000707f9fbd1592  mov rax, [r15+0x98]
0000707f9fbd1599  mov r12d, [r13+rax*1]
0000707f9fbd159e  lea r11, [rax+0x04]
0000707f9fbd15a2  mov eax, [r13+r11*1]
0000707f9fbd15a7  mov r12d, r12d
0000707f9fbd15aa  mov [r15+0x68], r12
0000707f9fbd15ae  mov eax, eax
0000707f9fbd15b0  mov [r15+0x60], rax
0000707f9fbd15b4  mov rax, [r15+0x68]
0000707f9fbd15b8  mov [r15+0x68], rax
0000707f9fbd15bc  mov qword ptr [r15+0x58], 0x02
0000707f9fbd15c4  mov [rsp+0x10], rax
0000707f9fbd15c9  xor eax, eax
0000707f9fbd15cb  mov r12d, 0x02
0000707f9fbd15d1  mov r11d, 0x400
0000707f9fbd15d7  cmp r12, r11
0000707f9fbd15da  cmc
0000707f9fbd15db  lahf
0000707f9fbd15dc  seto al
0000707f9fbd15df  mov [r15+0x108], eax
0000707f9fbd15e6  mov rax, [r15+0x60]
0000707f9fbd15ea  mov r12d, 0x02
0000707f9fbd15f0  imul rax, r12
0000707f9fbd15f4  mov [r15+0x50], rax
0000707f9fbd15f8  mov rax, [rsp+0x10]
0000707f9fbd15fd  lea r12, [rax+r14*1]
0000707f9fbd1601  mov [r15+0x48], r12
0000707f9fbd1605  mov eax, [r15+0x108]
0000707f9fbd160c  sahf
0000707f9fbd160d  jnz 0x0000707F9FBD163F
0000707f9fbd160f  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd1617  jz 0x0000707F9FBD17B0
0000707f9fbd161d  nop [rax+rax*1], ax
0000707f9fbd1626  nop [rax+rax*1], eax
0000707f9fbd162e  mov eax, 0x4103D0
0000707f9fbd1633  mov [r15+0x100], rax
0000707f9fbd163a  jmp 0x0000707F9F9FE110
0000707f9fbd163f  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd1647  jz 0x0000707F9FBD1690
0000707f9fbd164d  nop [rax+rax*1], ax
0000707f9fbd1656  nop [rax+rax*1], eax
0000707f9fbd165e  mov eax, 0x4103B0
0000707f9fbd1663  mov [r15+0x100], rax
0000707f9fbd166a  jmp 0x0000707F9F9FE110
0000707f9fbd166f  int3
0000707f9fbd1670  call 0x0000707F9FA0DC20
0000707f9fbd1675  jmp 0x0000707F9FBD1592
0000707f9fbd167a  call 0x0000707F9FA0B5E0
0000707f9fbd167f  jmp 0x0000707F9FBD159E
0000707f9fbd1684  call 0x0000707F9FAA3D90
0000707f9fbd1689  jmp 0x0000707F9FBD15A7
0000707f9fbd168e  int3
0000707f9fbd168f  nop
0000707f9fbd1690  mov rax, [r15+0x98]
0000707f9fbd1697  mov r14, [r15+0x58]
0000707f9fbd169b  mov [rsp+0x10], r14
0000707f9fbd16a0  shl r14, 0x02
0000707f9fbd16a4  lea r12, [rax+r14*1]
0000707f9fbd16a8  mov eax, [r13+r12*1]
0000707f9fbd16ad  lea r14, [r12+0x04]
0000707f9fbd16b2  mov r12d, [r13+r14*1]
0000707f9fbd16b7  mov eax, eax
0000707f9fbd16b9  mov [r15+0x68], rax
0000707f9fbd16bd  mov r12d, r12d
0000707f9fbd16c0  mov [r15+0x60], r12
0000707f9fbd16c4  mov rax, [r15+0x68]
0000707f9fbd16c8  mov [rsp+0x20], rax
0000707f9fbd16cd  mov r14, [rsp+0x10]
0000707f9fbd16d2  imul rax, r14
0000707f9fbd16d6  mov r12, [rsp+0x20]
0000707f9fbd16db  lea r11, [r12+rax*1]
0000707f9fbd16df  mov [r15+0x68], r11
0000707f9fbd16e3  lea rax, [r14+0x02]
0000707f9fbd16e7  mov [r15+0x58], rax
0000707f9fbd16eb  mov [rsp+0x10], rax
0000707f9fbd16f0  xor eax, eax
0000707f9fbd16f2  mov r14, [rsp+0x10]
0000707f9fbd16f7  mov r12d, 0x400
0000707f9fbd16fd  cmp r14, r12
0000707f9fbd1700  cmc
0000707f9fbd1701  lahf
0000707f9fbd1702  seto al
0000707f9fbd1705  mov [r15+0x108], eax
0000707f9fbd170c  mov rax, [r15+0x50]
0000707f9fbd1710  mov r12, [r15+0x60]
0000707f9fbd1714  imul r14, r12
0000707f9fbd1718  lea r12, [rax+r14*1]
0000707f9fbd171c  mov [r15+0x50], r12
0000707f9fbd1720  mov rax, [r15+0x48]
0000707f9fbd1724  lea r14, [r11+rax*1]
0000707f9fbd1728  mov [r15+0x48], r14
0000707f9fbd172c  mov eax, [r15+0x108]
0000707f9fbd1733  sahf
0000707f9fbd1734  jnz 0x0000707F9FBD1766
0000707f9fbd1736  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd173e  jz 0x0000707F9FBD17B0
0000707f9fbd1744  nop [rax+rax*1], ax
0000707f9fbd174d  nop [rax+rax*1], eax
0000707f9fbd1755  mov eax, 0x4103D0
0000707f9fbd175a  mov [r15+0x100], rax
0000707f9fbd1761  jmp 0x0000707F9F9FE110
0000707f9fbd1766  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd176e  jz 0x0000707F9FBD1690
0000707f9fbd1774  nop [rax+rax*1], ax
0000707f9fbd177d  nop [rax+rax*1], eax
0000707f9fbd1785  mov eax, 0x4103B0
0000707f9fbd178a  mov [r15+0x100], rax
0000707f9fbd1791  jmp 0x0000707F9F9FE110
0000707f9fbd1796  int3
0000707f9fbd1797  call 0x0000707F9FAB4690
0000707f9fbd179c  jmp 0x0000707F9FBD16AD
0000707f9fbd17a1  call 0x0000707F9FAE26A0
0000707f9fbd17a6  jmp 0x0000707F9FBD16B7
0000707f9fbd17ab  int3
0000707f9fbd17ac  nop [rax], eax
0000707f9fbd17b0  mov qword ptr [r15+0x98], 0x00
0000707f9fbd17bb  mov rax, [r15+0x50]
0000707f9fbd17bf  mov r14, [r15+0x48]
0000707f9fbd17c3  lea r12, [rax+r14*1]
0000707f9fbd17c7  mov [r15+0x48], r12
0000707f9fbd17cb  mov rax, [r15+0x40]
0000707f9fbd17cf  lea r14, [rax+0xC40]
0000707f9fbd17d6  mov [r13+r14*1], r12
0000707f9fbd17db  mov qword ptr [r15], 0x01
0000707f9fbd17e2  mov qword ptr [r15+0xF0], 0x4103E8
0000707f9fbd17ed  mov r14d, [r15+0x320]
0000707f9fbd17f4  mov eax, 0x4103E8
0000707f9fbd17f9  mov rcx, 0x707F9FBD1860
0000707f9fbd1803  mov [r15+r14*8+0x328], rax
0000707f9fbd180b  mov [r15+r14*8+0x368], rcx
0000707f9fbd1813  add r14d, 0x01
0000707f9fbd1817  and r14d, 0x07
0000707f9fbd181b  mov [r15+0x320], r14d
0000707f9fbd1822  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd182a  jz 0x0000707F9FBD0F20
0000707f9fbd1830  nop [rax+rax*1], ax
0000707f9fbd1839  nop [rax+rax*1], eax
0000707f9fbd1841  mov eax, 0x410938
0000707f9fbd1846  mov [r15+0x100], rax
0000707f9fbd184d  jmp 0x0000707F9F9FE110
0000707f9fbd1852  int3
0000707f9fbd1853  call 0x0000707F9FAE2CE0
0000707f9fbd1858  jmp 0x0000707F9FBD17DB
0000707f9fbd185d  int3
0000707f9fbd185e  nop
0000707f9fbd1860  mov eax, [r15+0x98]
0000707f9fbd1867  lea r14d, [eax+0x01]
0000707f9fbd186c  mov [rsp+0x10], r14d
0000707f9fbd1871  mov r14d, r14d
0000707f9fbd1874  mov [r15+0x98], r14
0000707f9fbd187b  xor eax, eax
0000707f9fbd187d  mov r14d, [rsp+0x10]
0000707f9fbd1882  cmp r14d, 0x10000
0000707f9fbd1889  cmc
0000707f9fbd188a  lahf
0000707f9fbd188b  seto al
0000707f9fbd188e  mov [r15+0x108], eax
0000707f9fbd1895  mov eax, [r15+0x108]
0000707f9fbd189c  sahf
0000707f9fbd189d  jnz 0x0000707F9FBD18CF
0000707f9fbd189f  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd18a7  jz 0x0000707F9FBD19A0
0000707f9fbd18ad  nop [rax+rax*1], ax
0000707f9fbd18b6  nop [rax+rax*1], eax
0000707f9fbd18be  mov eax, 0x4103F4
0000707f9fbd18c3  mov [r15+0x100], rax
0000707f9fbd18ca  jmp 0x0000707F9F9FE110
0000707f9fbd18cf  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd18d7  jz 0x0000707F9FBD1910
0000707f9fbd18dd  nop [rax+rax*1], ax
0000707f9fbd18e6  nop [rax+rax*1], eax
0000707f9fbd18ee  mov eax, 0x4103E0
0000707f9fbd18f3  mov [r15+0x100], rax
0000707f9fbd18fa  jmp 0x0000707F9F9FE110
0000707f9fbd18ff  int3
0000707f9fbd1900  int3
0000707f9fbd1901  nop [rax+rax*1], ax
0000707f9fbd190a  nop [rax+rax*1], ax
0000707f9fbd1910  mov eax, [r15]
0000707f9fbd1913  mov r14d, [r15+0x98]
0000707f9fbd191a  lea r12d, [eax+r14d*1]
0000707f9fbd191f  mov r12d, r12d
0000707f9fbd1922  mov [r15], r12
0000707f9fbd1925  mov qword ptr [r15+0xF0], 0x4103E8
0000707f9fbd1930  mov r14d, [r15+0x320]
0000707f9fbd1937  mov eax, 0x4103E8
0000707f9fbd193c  mov rcx, 0x707F9FBD1860
0000707f9fbd1946  mov [r15+r14*8+0x328], rax
0000707f9fbd194e  mov [r15+r14*8+0x368], rcx
0000707f9fbd1956  add r14d, 0x01
0000707f9fbd195a  and r14d, 0x07
0000707f9fbd195e  mov [r15+0x320], r14d
0000707f9fbd1965  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd196d  jz 0x0000707F9FBD0F20
0000707f9fbd1973  nop [rax+rax*1], ax
0000707f9fbd197c  nop [rax+rax*1], eax
0000707f9fbd1984  mov eax, 0x410938
0000707f9fbd1989  mov [r15+0x100], rax
0000707f9fbd1990  jmp 0x0000707F9F9FE110
0000707f9fbd1995  int3
0000707f9fbd1996  int3
0000707f9fbd1997  nop [rax+rax*1], ax
0000707f9fbd19a0  vmovaps xmm1, [0x0000707F9F7FE010]
0000707f9fbd19a8  movq xmm1, xmm1
0000707f9fbd19ac  movaps [r15+0x110], xmm1
0000707f9fbd19b4  mov eax, 0x420AA0
0000707f9fbd19b9  mov r14, [r13+rax*1]
0000707f9fbd19be  movq xmm1, r14
0000707f9fbd19c3  movaps [r15+0x120], xmm1
0000707f9fbd19cb  vmovaps xmm1, [0x0000707F9F7FE020]
0000707f9fbd19d3  movq xmm1, xmm1
0000707f9fbd19d7  movaps [r15+0x140], xmm1
0000707f9fbd19df  vmovaps xmm1, [0x0000707F9F7FE030]
0000707f9fbd19e7  vpbroadcastq xmm1, xmm1
0000707f9fbd19ec  movaps [r15+0x150], xmm1
0000707f9fbd19f4  mov qword ptr [r15+0x40], 0x02
0000707f9fbd19fc  vmovaps xmm15, [0x0000707F9F7FE040]
0000707f9fbd1a04  movq xmm15, xmm15
0000707f9fbd1a09  movaps [r15+0x160], xmm15
0000707f9fbd1a11  vmovaps xmm15, [0x0000707F9F7FE050]
0000707f9fbd1a19  vpbroadcastq xmm15, xmm15
0000707f9fbd1a1e  movaps [r15+0x130], xmm15
0000707f9fbd1a26  mov rax, [r15+0x40]
0000707f9fbd1a2a  vmovq xmm14, rax
0000707f9fbd1a2f  vpbroadcastq xmm14, xmm14
0000707f9fbd1a34  movaps [r15+0x170], xmm14
0000707f9fbd1a3c  mov eax, 0x4209D0
0000707f9fbd1a41  movups xmm13, [r13+rax*1]
0000707f9fbd1a47  mov qword ptr [r15+0x40], 0x431D90
0000707f9fbd1a4f  mov eax, [r15]
0000707f9fbd1a52  mov r14d, 0x430C48
0000707f9fbd1a58  mov [r13+r14*1], eax
0000707f9fbd1a5d  mov qword ptr [r15+0x50], 0x431F90
0000707f9fbd1a65  vpmovqd xmm12, xmm13
0000707f9fbd1a6b  pxor xmm11, xmm11
0000707f9fbd1a70  punpcklqdq xmm12, xmm11
0000707f9fbd1a75  movaps [r15+0x210], xmm12
0000707f9fbd1a7d  movq xmm12, qword ptr [r15+0x140]
0000707f9fbd1a86  movq xmm11, qword ptr [r15+0x120]
0000707f9fbd1a8f  psubd xmm12, xmm11
0000707f9fbd1a94  movq xmm12, xmm12
0000707f9fbd1a99  paddq xmm13, xmm14
0000707f9fbd1a9e  movaps [r15+0x180], xmm13
0000707f9fbd1aa6  movq xmm14, qword ptr [r15+0x160]
0000707f9fbd1aaf  paddd xmm11, xmm14
0000707f9fbd1ab4  movq xmm11, xmm11
0000707f9fbd1ab9  movq xmm11, xmm11
0000707f9fbd1abe  movaps [r15+0x120], xmm11
0000707f9fbd1ac6  pmovzxdq xmm12, xmm12
0000707f9fbd1acc  psllq xmm12, 0x00
0000707f9fbd1ad2  movq xmm14, qword ptr [r15+0x210]
0000707f9fbd1adb  movq xmm13, qword ptr [r15+0x110]
0000707f9fbd1ae4  paddd xmm14, xmm13
0000707f9fbd1ae9  movq xmm14, xmm14
0000707f9fbd1aee  vcvtuqq2pd xmm12, xmm12
0000707f9fbd1af4  pmovzxdq xmm14, xmm14
0000707f9fbd1afa  psllq xmm14, 0x00
0000707f9fbd1b00  vcvtuqq2pd xmm14, xmm14
0000707f9fbd1b06  movaps xmm13, xmm12
0000707f9fbd1b0a  mulpd xmm13, xmm1
0000707f9fbd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
0000707f9fbd1b15  ptest xmm11, xmm11
0000707f9fbd1b1b  jnz 0x0000707F9FBD1C0F
0000707f9fbd1b21  movaps [r15+0x220], xmm13
0000707f9fbd1b29  mov eax, 0x431F90
0000707f9fbd1b2e  movups [r13+rax*1], xmm13
0000707f9fbd1b34  movaps xmm1, xmm14
0000707f9fbd1b38  mulpd xmm1, xmm15
0000707f9fbd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
0000707f9fbd1b42  ptest xmm13, xmm13
0000707f9fbd1b48  jnz 0x0000707F9FBD1D5C
0000707f9fbd1b4e  movaps [r15+0x210], xmm1
0000707f9fbd1b56  mov eax, 0x431D90
0000707f9fbd1b5b  movups [r13+rax*1], xmm1
0000707f9fbd1b61  mov qword ptr [r15+0x48], 0x10
0000707f9fbd1b69  xor eax, eax
0000707f9fbd1b6b  mov r14d, 0x10
0000707f9fbd1b71  mov r12d, 0x200
0000707f9fbd1b77  cmp r14, r12
0000707f9fbd1b7a  cmc
0000707f9fbd1b7b  lahf
0000707f9fbd1b7c  seto al
0000707f9fbd1b7f  mov [r15+0x108], eax
0000707f9fbd1b86  mov eax, [r15+0x108]
0000707f9fbd1b8d  sahf
0000707f9fbd1b8e  jnz 0x0000707F9FBD1BC0
0000707f9fbd1b90  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd1b98  jz 0x0000707F9FBD2300
0000707f9fbd1b9e  nop [rax+rax*1], ax
0000707f9fbd1ba7  nop [rax+rax*1], eax
0000707f9fbd1baf  mov eax, 0x410480
0000707f9fbd1bb4  mov [r15+0x100], rax
0000707f9fbd1bbb  jmp 0x0000707F9F9FE110
0000707f9fbd1bc0  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd1bc8  jz 0x0000707F9FBD1EB0
0000707f9fbd1bce  nop [rax+rax*1], ax
0000707f9fbd1bd7  nop [rax+rax*1], eax
0000707f9fbd1bdf  mov eax, 0x410440
0000707f9fbd1be4  mov [r15+0x100], rax
0000707f9fbd1beb  jmp 0x0000707F9F9FE110
0000707f9fbd1bf0  int3
0000707f9fbd1bf1  call 0x0000707F9FA0DC20
0000707f9fbd1bf6  jmp 0x0000707F9FBD19BE
0000707f9fbd1bfb  call 0x0000707F9FA0C260
0000707f9fbd1c00  jmp 0x0000707F9FBD1A47
0000707f9fbd1c05  call 0x0000707F9FAD5D70
0000707f9fbd1c0a  jmp 0x0000707F9FBD1A5D
0000707f9fbd1c0f  sub rsp, 0x08
0000707f9fbd1c13  push rax
0000707f9fbd1c14  push rcx
0000707f9fbd1c15  push rdx
0000707f9fbd1c16  push rdi
0000707f9fbd1c17  push rsi
0000707f9fbd1c18  push r8
0000707f9fbd1c1a  push r9
0000707f9fbd1c1c  push r10
0000707f9fbd1c1e  push r11
0000707f9fbd1c20  sub rsp, 0xF0
0000707f9fbd1c27  vmovaps [rsp], xmm0
0000707f9fbd1c2c  vmovaps [rsp+0x10], xmm1
0000707f9fbd1c32  vmovaps [rsp+0x20], xmm2
0000707f9fbd1c38  vmovaps [rsp+0x30], xmm3
0000707f9fbd1c3e  vmovaps [rsp+0x40], xmm4
0000707f9fbd1c44  vmovaps [rsp+0x50], xmm5
0000707f9fbd1c4a  vmovaps [rsp+0x60], xmm6
0000707f9fbd1c50  vmovaps [rsp+0x70], xmm7
0000707f9fbd1c56  vmovaps [rsp+0x80], xmm8
0000707f9fbd1c5f  vmovaps [rsp+0x90], xmm9
0000707f9fbd1c68  vmovaps [rsp+0xA0], xmm10
0000707f9fbd1c71  vmovaps [rsp+0xB0], xmm11
0000707f9fbd1c7a  vmovaps [rsp+0xC0], xmm12
0000707f9fbd1c83  vmovaps [rsp+0xD0], xmm14
0000707f9fbd1c8c  vmovaps [rsp+0xE0], xmm15
0000707f9fbd1c95  sub rsp, 0x30
0000707f9fbd1c99  movaps [rsp], xmm13
0000707f9fbd1c9e  movaps [rsp+0x10], xmm12
0000707f9fbd1ca4  movaps [rsp+0x20], xmm1
0000707f9fbd1ca9  lea rdi, [rsp]
0000707f9fbd1cad  mov esi, 0x00
0000707f9fbd1cb2  mov rax, 0x5753922B7530
0000707f9fbd1cbc  call rax
0000707f9fbd1cbe  movaps xmm13, [rsp]
0000707f9fbd1cc3  add rsp, 0x30
0000707f9fbd1cc7  vmovaps xmm0, [rsp]
0000707f9fbd1ccc  vmovaps xmm1, [rsp+0x10]
0000707f9fbd1cd2  vmovaps xmm2, [rsp+0x20]
0000707f9fbd1cd8  vmovaps xmm3, [rsp+0x30]
0000707f9fbd1cde  vmovaps xmm4, [rsp+0x40]
0000707f9fbd1ce4  vmovaps xmm5, [rsp+0x50]
0000707f9fbd1cea  vmovaps xmm6, [rsp+0x60]
0000707f9fbd1cf0  vmovaps xmm7, [rsp+0x70]
0000707f9fbd1cf6  vmovaps xmm8, [rsp+0x80]
0000707f9fbd1cff  vmovaps xmm9, [rsp+0x90]
0000707f9fbd1d08  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd1d11  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd1d1a  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd1d23  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd1d2c  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd1d35  add rsp, 0xF0
0000707f9fbd1d3c  pop r11
0000707f9fbd1d3e  pop r10
0000707f9fbd1d40  pop r9
0000707f9fbd1d42  pop r8
0000707f9fbd1d44  pop rsi
0000707f9fbd1d45  pop rdi
0000707f9fbd1d46  pop rdx
0000707f9fbd1d47  pop rcx
0000707f9fbd1d48  pop rax
0000707f9fbd1d49  add rsp, 0x08
0000707f9fbd1d4d  jmp 0x0000707F9FBD1B21
0000707f9fbd1d52  call 0x0000707F9FA0C380
0000707f9fbd1d57  jmp 0x0000707F9FBD1B34
0000707f9fbd1d5c  sub rsp, 0x08
0000707f9fbd1d60  push rax
0000707f9fbd1d61  push rcx
0000707f9fbd1d62  push rdx
0000707f9fbd1d63  push rdi
0000707f9fbd1d64  push rsi
0000707f9fbd1d65  push r8
0000707f9fbd1d67  push r9
0000707f9fbd1d69  push r10
0000707f9fbd1d6b  push r11
0000707f9fbd1d6d  sub rsp, 0xF0
0000707f9fbd1d74  vmovaps [rsp], xmm0
0000707f9fbd1d79  vmovaps [rsp+0x10], xmm2
0000707f9fbd1d7f  vmovaps [rsp+0x20], xmm3
0000707f9fbd1d85  vmovaps [rsp+0x30], xmm4
0000707f9fbd1d8b  vmovaps [rsp+0x40], xmm5
0000707f9fbd1d91  vmovaps [rsp+0x50], xmm6
0000707f9fbd1d97  vmovaps [rsp+0x60], xmm7
0000707f9fbd1d9d  vmovaps [rsp+0x70], xmm8
0000707f9fbd1da3  vmovaps [rsp+0x80], xmm9
0000707f9fbd1dac  vmovaps [rsp+0x90], xmm10
0000707f9fbd1db5  vmovaps [rsp+0xA0], xmm11
0000707f9fbd1dbe  vmovaps [rsp+0xB0], xmm12
0000707f9fbd1dc7  vmovaps [rsp+0xC0], xmm13
0000707f9fbd1dd0  vmovaps [rsp+0xD0], xmm14
0000707f9fbd1dd9  vmovaps [rsp+0xE0], xmm15
0000707f9fbd1de2  sub rsp, 0x30
0000707f9fbd1de6  movaps [rsp], xmm1
0000707f9fbd1dea  movaps [rsp+0x10], xmm14
0000707f9fbd1df0  movaps [rsp+0x20], xmm15
0000707f9fbd1df6  lea rdi, [rsp]
0000707f9fbd1dfa  mov esi, 0x00
0000707f9fbd1dff  mov rax, 0x5753922B7530
0000707f9fbd1e09  call rax
0000707f9fbd1e0b  movaps xmm1, [rsp]
0000707f9fbd1e0f  add rsp, 0x30
0000707f9fbd1e13  vmovaps xmm0, [rsp]
0000707f9fbd1e18  vmovaps xmm2, [rsp+0x10]
0000707f9fbd1e1e  vmovaps xmm3, [rsp+0x20]
0000707f9fbd1e24  vmovaps xmm4, [rsp+0x30]
0000707f9fbd1e2a  vmovaps xmm5, [rsp+0x40]
0000707f9fbd1e30  vmovaps xmm6, [rsp+0x50]
0000707f9fbd1e36  vmovaps xmm7, [rsp+0x60]
0000707f9fbd1e3c  vmovaps xmm8, [rsp+0x70]
0000707f9fbd1e42  vmovaps xmm9, [rsp+0x80]
0000707f9fbd1e4b  vmovaps xmm10, [rsp+0x90]
0000707f9fbd1e54  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd1e5d  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd1e66  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd1e6f  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd1e78  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd1e81  add rsp, 0xF0
0000707f9fbd1e88  pop r11
0000707f9fbd1e8a  pop r10
0000707f9fbd1e8c  pop r9
0000707f9fbd1e8e  pop r8
0000707f9fbd1e90  pop rsi
0000707f9fbd1e91  pop rdi
0000707f9fbd1e92  pop rdx
0000707f9fbd1e93  pop rcx
0000707f9fbd1e94  pop rax
0000707f9fbd1e95  add rsp, 0x08
0000707f9fbd1e99  jmp 0x0000707F9FBD1B4E
0000707f9fbd1e9e  call 0x0000707F9F9FF540
0000707f9fbd1ea3  jmp 0x0000707F9FBD1B61
0000707f9fbd1ea8  int3
0000707f9fbd1ea9  nop [rax], eax
0000707f9fbd1eb0  movaps xmm1, [r15+0x180]
0000707f9fbd1eb8  vpmovqd xmm15, xmm1
0000707f9fbd1ebe  pxor xmm14, xmm14
0000707f9fbd1ec3  punpcklqdq xmm15, xmm14
0000707f9fbd1ec8  movaps [r15+0x210], xmm15
0000707f9fbd1ed0  movq xmm15, qword ptr [r15+0x140]
0000707f9fbd1ed9  movq xmm14, qword ptr [r15+0x120]
0000707f9fbd1ee2  psubd xmm15, xmm14
0000707f9fbd1ee7  movq xmm15, xmm15
0000707f9fbd1eec  movaps xmm13, [r15+0x170]
0000707f9fbd1ef4  paddq xmm1, xmm13
0000707f9fbd1ef9  movaps [r15+0x180], xmm1
0000707f9fbd1f01  movq xmm1, qword ptr [r15+0x160]
0000707f9fbd1f0a  paddd xmm14, xmm1
0000707f9fbd1f0f  movq xmm14, xmm14
0000707f9fbd1f14  movq xmm14, xmm14
0000707f9fbd1f19  movaps [r15+0x120], xmm14
0000707f9fbd1f21  pmovzxdq xmm15, xmm15
0000707f9fbd1f27  psllq xmm15, 0x00
0000707f9fbd1f2d  movq xmm1, qword ptr [r15+0x210]
0000707f9fbd1f36  movq xmm14, qword ptr [r15+0x110]
0000707f9fbd1f3f  paddd xmm1, xmm14
0000707f9fbd1f44  movq xmm1, xmm1
0000707f9fbd1f48  vcvtuqq2pd xmm15, xmm15
0000707f9fbd1f4e  pmovzxdq xmm1, xmm1
0000707f9fbd1f53  psllq xmm1, 0x00
0000707f9fbd1f58  vcvtuqq2pd xmm1, xmm1
0000707f9fbd1f5e  movaps xmm14, [r15+0x150]
0000707f9fbd1f66  movaps xmm13, xmm15
0000707f9fbd1f6a  mulpd xmm13, xmm14
0000707f9fbd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd1f75  ptest xmm12, xmm12
0000707f9fbd1f7b  jnz 0x0000707F9FBD205E
0000707f9fbd1f81  movaps [r15+0x220], xmm13
0000707f9fbd1f89  mov rax, [r15+0x48]
0000707f9fbd1f8d  mov r14, [r15+0x50]
0000707f9fbd1f91  lea r12, [r14+rax*1]
0000707f9fbd1f95  movups [r13+r12*1], xmm13
0000707f9fbd1f9b  movaps xmm15, [r15+0x130]
0000707f9fbd1fa3  movaps xmm14, xmm1
0000707f9fbd1fa7  mulpd xmm14, xmm15
0000707f9fbd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
0000707f9fbd1fb2  ptest xmm13, xmm13
0000707f9fbd1fb8  jnz 0x0000707F9FBD21AC
0000707f9fbd1fbe  movaps [r15+0x210], xmm14
0000707f9fbd1fc6  mov r14, [r15+0x40]
0000707f9fbd1fca  lea r12, [r14+rax*1]
0000707f9fbd1fce  movups [r13+r12*1], xmm14
0000707f9fbd1fd4  lea r14, [rax+0x10]
0000707f9fbd1fd8  mov [r15+0x48], r14
0000707f9fbd1fdc  xor eax, eax
0000707f9fbd1fde  mov r12d, 0x200
0000707f9fbd1fe4  cmp r14, r12
0000707f9fbd1fe7  cmc
0000707f9fbd1fe8  lahf
0000707f9fbd1fe9  seto al
0000707f9fbd1fec  mov [r15+0x108], eax
0000707f9fbd1ff3  mov eax, [r15+0x108]
0000707f9fbd1ffa  sahf
0000707f9fbd1ffb  jnz 0x0000707F9FBD202D
0000707f9fbd1ffd  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd2005  jz 0x0000707F9FBD2300
0000707f9fbd200b  nop [rax+rax*1], ax
0000707f9fbd2014  nop [rax+rax*1], eax
0000707f9fbd201c  mov eax, 0x410480
0000707f9fbd2021  mov [r15+0x100], rax
0000707f9fbd2028  jmp 0x0000707F9F9FE110
0000707f9fbd202d  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd2035  jz 0x0000707F9FBD1EB0
0000707f9fbd203b  nop [rax+rax*1], ax
0000707f9fbd2044  nop [rax+rax*1], eax
0000707f9fbd204c  mov eax, 0x410440
0000707f9fbd2051  mov [r15+0x100], rax
0000707f9fbd2058  jmp 0x0000707F9F9FE110
0000707f9fbd205d  int3
0000707f9fbd205e  sub rsp, 0x08
0000707f9fbd2062  push rax
0000707f9fbd2063  push rcx
0000707f9fbd2064  push rdx
0000707f9fbd2065  push rdi
0000707f9fbd2066  push rsi
0000707f9fbd2067  push r8
0000707f9fbd2069  push r9
0000707f9fbd206b  push r10
0000707f9fbd206d  push r11
0000707f9fbd206f  sub rsp, 0xF0
0000707f9fbd2076  vmovaps [rsp], xmm0
0000707f9fbd207b  vmovaps [rsp+0x10], xmm1
0000707f9fbd2081  vmovaps [rsp+0x20], xmm2
0000707f9fbd2087  vmovaps [rsp+0x30], xmm3
0000707f9fbd208d  vmovaps [rsp+0x40], xmm4
0000707f9fbd2093  vmovaps [rsp+0x50], xmm5
0000707f9fbd2099  vmovaps [rsp+0x60], xmm6
0000707f9fbd209f  vmovaps [rsp+0x70], xmm7
0000707f9fbd20a5  vmovaps [rsp+0x80], xmm8
0000707f9fbd20ae  vmovaps [rsp+0x90], xmm9
0000707f9fbd20b7  vmovaps [rsp+0xA0], xmm10
0000707f9fbd20c0  vmovaps [rsp+0xB0], xmm11
0000707f9fbd20c9  vmovaps [rsp+0xC0], xmm12
0000707f9fbd20d2  vmovaps [rsp+0xD0], xmm14
0000707f9fbd20db  vmovaps [rsp+0xE0], xmm15
0000707f9fbd20e4  sub rsp, 0x30
0000707f9fbd20e8  movaps [rsp], xmm13
0000707f9fbd20ed  movaps [rsp+0x10], xmm15
0000707f9fbd20f3  movaps [rsp+0x20], xmm14
0000707f9fbd20f9  lea rdi, [rsp]
0000707f9fbd20fd  mov esi, 0x00
0000707f9fbd2102  mov rax, 0x5753922B7530
0000707f9fbd210c  call rax
0000707f9fbd210e  movaps xmm13, [rsp]
0000707f9fbd2113  add rsp, 0x30
0000707f9fbd2117  vmovaps xmm0, [rsp]
0000707f9fbd211c  vmovaps xmm1, [rsp+0x10]
0000707f9fbd2122  vmovaps xmm2, [rsp+0x20]
0000707f9fbd2128  vmovaps xmm3, [rsp+0x30]
0000707f9fbd212e  vmovaps xmm4, [rsp+0x40]
0000707f9fbd2134  vmovaps xmm5, [rsp+0x50]
0000707f9fbd213a  vmovaps xmm6, [rsp+0x60]
0000707f9fbd2140  vmovaps xmm7, [rsp+0x70]
0000707f9fbd2146  vmovaps xmm8, [rsp+0x80]
0000707f9fbd214f  vmovaps xmm9, [rsp+0x90]
0000707f9fbd2158  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd2161  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd216a  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd2173  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd217c  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd2185  add rsp, 0xF0
0000707f9fbd218c  pop r11
0000707f9fbd218e  pop r10
0000707f9fbd2190  pop r9
0000707f9fbd2192  pop r8
0000707f9fbd2194  pop rsi
0000707f9fbd2195  pop rdi
0000707f9fbd2196  pop rdx
0000707f9fbd2197  pop rcx
0000707f9fbd2198  pop rax
0000707f9fbd2199  add rsp, 0x08
0000707f9fbd219d  jmp 0x0000707F9FBD1F81
0000707f9fbd21a2  call 0x0000707F9FAC2240
0000707f9fbd21a7  jmp 0x0000707F9FBD1F9B
0000707f9fbd21ac  sub rsp, 0x08
0000707f9fbd21b0  push rax
0000707f9fbd21b1  push rcx
0000707f9fbd21b2  push rdx
0000707f9fbd21b3  push rdi
0000707f9fbd21b4  push rsi
0000707f9fbd21b5  push r8
0000707f9fbd21b7  push r9
0000707f9fbd21b9  push r10
0000707f9fbd21bb  push r11
0000707f9fbd21bd  sub rsp, 0xF0
0000707f9fbd21c4  vmovaps [rsp], xmm0
0000707f9fbd21c9  vmovaps [rsp+0x10], xmm1
0000707f9fbd21cf  vmovaps [rsp+0x20], xmm2
0000707f9fbd21d5  vmovaps [rsp+0x30], xmm3
0000707f9fbd21db  vmovaps [rsp+0x40], xmm4
0000707f9fbd21e1  vmovaps [rsp+0x50], xmm5
0000707f9fbd21e7  vmovaps [rsp+0x60], xmm6
0000707f9fbd21ed  vmovaps [rsp+0x70], xmm7
0000707f9fbd21f3  vmovaps [rsp+0x80], xmm8
0000707f9fbd21fc  vmovaps [rsp+0x90], xmm9
0000707f9fbd2205  vmovaps [rsp+0xA0], xmm10
0000707f9fbd220e  vmovaps [rsp+0xB0], xmm11
0000707f9fbd2217  vmovaps [rsp+0xC0], xmm12
0000707f9fbd2220  vmovaps [rsp+0xD0], xmm13
0000707f9fbd2229  vmovaps [rsp+0xE0], xmm15
0000707f9fbd2232  sub rsp, 0x30
0000707f9fbd2236  movaps [rsp], xmm14
0000707f9fbd223b  movaps [rsp+0x10], xmm1
0000707f9fbd2240  movaps [rsp+0x20], xmm15
0000707f9fbd2246  lea rdi, [rsp]
0000707f9fbd224a  mov esi, 0x00
0000707f9fbd224f  mov rax, 0x5753922B7530
0000707f9fbd2259  call rax
0000707f9fbd225b  movaps xmm14, [rsp]
0000707f9fbd2260  add rsp, 0x30
0000707f9fbd2264  vmovaps xmm0, [rsp]
0000707f9fbd2269  vmovaps xmm1, [rsp+0x10]
0000707f9fbd226f  vmovaps xmm2, [rsp+0x20]
0000707f9fbd2275  vmovaps xmm3, [rsp+0x30]
0000707f9fbd227b  vmovaps xmm4, [rsp+0x40]
0000707f9fbd2281  vmovaps xmm5, [rsp+0x50]
0000707f9fbd2287  vmovaps xmm6, [rsp+0x60]
0000707f9fbd228d  vmovaps xmm7, [rsp+0x70]
0000707f9fbd2293  vmovaps xmm8, [rsp+0x80]
0000707f9fbd229c  vmovaps xmm9, [rsp+0x90]
0000707f9fbd22a5  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd22ae  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd22b7  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd22c0  vmovaps xmm13, [rsp+0xD0]
0000707f9fbd22c9  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd22d2  add rsp, 0xF0
0000707f9fbd22d9  pop r11
0000707f9fbd22db  pop r10
0000707f9fbd22dd  pop r9
0000707f9fbd22df  pop r8
0000707f9fbd22e1  pop rsi
0000707f9fbd22e2  pop rdi
0000707f9fbd22e3  pop rdx
0000707f9fbd22e4  pop rcx
0000707f9fbd22e5  pop rax
0000707f9fbd22e6  add rsp, 0x08
0000707f9fbd22ea  jmp 0x0000707F9FBD1FBE
0000707f9fbd22ef  call 0x0000707F9FAC34C0
0000707f9fbd22f4  jmp 0x0000707F9FBD1FD4
0000707f9fbd22f9  int3
0000707f9fbd22fa  nop [rax+rax*1], ax
0000707f9fbd2300  mov rax, [r15+0x50]
0000707f9fbd2304  movups xmm1, [r13+rax*1]
0000707f9fbd230a  lea r14, [rax+0x10]
0000707f9fbd230e  movups xmm15, [r13+r14*1]
0000707f9fbd2314  mov qword ptr [r15+0x48], 0x00
0000707f9fbd231c  lea r14, [rax+0x40]
0000707f9fbd2320  movups xmm14, [r13+r14*1]
0000707f9fbd2326  lea r14, [rax+0x50]
0000707f9fbd232a  movups xmm13, [r13+r14*1]
0000707f9fbd2330  lea r14, [rax+0x80]
0000707f9fbd2337  movups xmm12, [r13+r14*1]
0000707f9fbd233d  lea r14, [rax+0x90]
0000707f9fbd2344  movups xmm11, [r13+r14*1]
0000707f9fbd234a  mov r14, [r15+0xF8]
0000707f9fbd2351  movups [r13+r14*1], xmm1
0000707f9fbd2357  lea r12, [rax+0x20]
0000707f9fbd235b  movups xmm1, [r13+r12*1]
0000707f9fbd2361  lea r12, [rax+0x30]
0000707f9fbd2365  movups xmm10, [r13+r12*1]
0000707f9fbd236b  lea r12, [rax+0xC0]
0000707f9fbd2372  movups xmm9, [r13+r12*1]
0000707f9fbd2378  lea r12, [rax+0xD0]
0000707f9fbd237f  movups xmm8, [r13+r12*1]
0000707f9fbd2385  lea r12, [rax+0x100]
0000707f9fbd238c  movups xmm7, [r13+r12*1]
0000707f9fbd2392  lea r12, [rax+0x110]
0000707f9fbd2399  movups xmm6, [r13+r12*1]
0000707f9fbd239f  lea r12, [rax+0x140]
0000707f9fbd23a6  movups xmm5, [r13+r12*1]
0000707f9fbd23ac  lea r12, [rax+0x150]
0000707f9fbd23b3  movups xmm4, [r13+r12*1]
0000707f9fbd23b9  lea r12, [r14+0xB0]
0000707f9fbd23c0  movups [r13+r12*1], xmm10
0000707f9fbd23c6  lea r12, [r14+0xC0]
0000707f9fbd23cd  movups [r13+r12*1], xmm1
0000707f9fbd23d3  lea r12, [rax+0x180]
0000707f9fbd23da  movups xmm1, [r13+r12*1]
0000707f9fbd23e0  lea r12, [rax+0x190]
0000707f9fbd23e7  movups xmm10, [r13+r12*1]
0000707f9fbd23ed  lea r12, [rax+0x1C0]
0000707f9fbd23f4  movups xmm3, [r13+r12*1]
0000707f9fbd23fa  lea r12, [rax+0x1D0]
0000707f9fbd2401  movups xmm2, [r13+r12*1]
0000707f9fbd2407  lea r12, [rax+0x60]
0000707f9fbd240b  vmovaps [rsp+0x10], xmm1
0000707f9fbd2411  movups xmm1, [r13+r12*1]
0000707f9fbd2417  lea r12, [rax+0x70]
0000707f9fbd241b  vmovaps [rsp+0x20], xmm1
0000707f9fbd2421  movups xmm1, [r13+r12*1]
0000707f9fbd2427  lea r12, [r14+0x70]
0000707f9fbd242b  movups [r13+r12*1], xmm10
0000707f9fbd2431  lea r12, [r14+0x80]
0000707f9fbd2438  vmovaps xmm10, [rsp+0x10]
0000707f9fbd243e  movups [r13+r12*1], xmm10
0000707f9fbd2444  lea r12, [rax+0xA0]
0000707f9fbd244b  movups xmm10, [r13+r12*1]
0000707f9fbd2451  lea r12, [rax+0xB0]
0000707f9fbd2458  vmovaps [rsp+0x10], xmm1
0000707f9fbd245e  movups xmm1, [r13+r12*1]
0000707f9fbd2464  lea r12, [r14+0x90]
0000707f9fbd246b  movups [r13+r12*1], xmm2
0000707f9fbd2471  lea r12, [r14+0xA0]
0000707f9fbd2478  movups [r13+r12*1], xmm3
0000707f9fbd247e  lea r12, [rax+0xE0]
0000707f9fbd2485  movups xmm3, [r13+r12*1]
0000707f9fbd248b  lea r12, [rax+0xF0]
0000707f9fbd2492  movups xmm2, [r13+r12*1]
0000707f9fbd2498  lea r12, [rax+0x120]
0000707f9fbd249f  vmovaps [rsp+0x30], xmm1
0000707f9fbd24a5  movups xmm1, [r13+r12*1]
0000707f9fbd24ab  lea r12, [rax+0x130]
0000707f9fbd24b2  vmovaps [rsp+0x40], xmm1
0000707f9fbd24b8  movups xmm1, [r13+r12*1]
0000707f9fbd24be  vmovaps [rsp+0x50], xmm1
0000707f9fbd24c4  vmovaps xmm1, [rsp+0x40]
0000707f9fbd24ca  movaps [r15+0x190], xmm1
0000707f9fbd24d2  lea r12, [rax+0x160]
0000707f9fbd24d9  vmovaps [rsp+0x40], xmm1
0000707f9fbd24df  movups xmm1, [r13+r12*1]
0000707f9fbd24e5  lea r12, [rax+0x170]
0000707f9fbd24ec  vmovaps [rsp+0x60], xmm1
0000707f9fbd24f2  movups xmm1, [r13+r12*1]
0000707f9fbd24f8  lea r12, [rax+0x1A0]
0000707f9fbd24ff  vmovaps [rsp+0x70], xmm1
0000707f9fbd2505  movups xmm1, [r13+r12*1]
0000707f9fbd250b  lea r12, [rax+0x1B0]
0000707f9fbd2512  vmovaps [rsp+0x80], xmm1
0000707f9fbd251b  movups xmm1, [r13+r12*1]
0000707f9fbd2521  lea r12, [rax+0x1E0]
0000707f9fbd2528  vmovaps [rsp+0x90], xmm1
0000707f9fbd2531  movups xmm1, [r13+r12*1]
0000707f9fbd2537  lea r12, [rax+0x1F0]
0000707f9fbd253e  vmovaps [rsp+0xA0], xmm1
0000707f9fbd2547  movups xmm1, [r13+r12*1]
0000707f9fbd254d  mov qword ptr [r15+0x50], 0x432190
0000707f9fbd2555  lea rax, [r14+0x50]
0000707f9fbd2559  vmovaps [rsp+0xB0], xmm1
0000707f9fbd2562  vmovaps xmm1, [rsp+0x60]
0000707f9fbd2568  movups [r13+rax*1], xmm1
0000707f9fbd256e  lea rax, [r14+0x60]
0000707f9fbd2572  movups [r13+rax*1], xmm5
0000707f9fbd2578  lea rax, [r14+0x40]
0000707f9fbd257c  vmovaps xmm1, [rsp+0x70]
0000707f9fbd2582  movups [r13+rax*1], xmm1
0000707f9fbd2588  lea rax, [r14+0x20]
0000707f9fbd258c  vmovaps xmm1, [rsp+0xA0]
0000707f9fbd2595  movups [r13+rax*1], xmm1
0000707f9fbd259b  lea rax, [r14+0x30]
0000707f9fbd259f  vmovaps xmm1, [rsp+0x90]
0000707f9fbd25a8  movups [r13+rax*1], xmm1
0000707f9fbd25ae  lea rax, [r14+0x10]
0000707f9fbd25b2  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd25bb  movups [r13+rax*1], xmm1
0000707f9fbd25c1  mov rax, [r15+0x40]
0000707f9fbd25c5  vxorps xmm1, xmm1, xmm1
0000707f9fbd25c9  vpbroadcastq xmm1, xmm1
0000707f9fbd25ce  vxorps xmm5, xmm5, xmm5
0000707f9fbd25d2  vpbroadcastq xmm5, xmm5
0000707f9fbd25d7  lea r12, [rax+0x30]
0000707f9fbd25db  mov r11, [r13+r12*1]
0000707f9fbd25e0  lea r12, [rax+0x38]
0000707f9fbd25e4  mov r10, [r13+r12*1]
0000707f9fbd25e9  vmovaps [rsp+0x60], xmm1
0000707f9fbd25ef  movq xmm1, r11
0000707f9fbd25f4  vmovaps [rsp+0x70], xmm1
0000707f9fbd25fa  movq xmm1, r10
0000707f9fbd25ff  vmovaps [rsp+0x90], xmm1
0000707f9fbd2608  vmovaps xmm1, [rsp+0x70]
0000707f9fbd260e  movq xmm1, xmm1
0000707f9fbd2612  vmovaps [rsp+0x70], xmm1
0000707f9fbd2618  vmovaps xmm1, [rsp+0x90]
0000707f9fbd2621  movq xmm1, xmm1
0000707f9fbd2625  vmovaps [rsp+0x90], xmm1
0000707f9fbd262e  movq xmm1, xmm1
0000707f9fbd2632  movaps [r15+0x270], xmm1
0000707f9fbd263a  vmovaps [rsp+0xA0], xmm7
0000707f9fbd2643  vmovaps xmm1, [rsp+0xA0]
0000707f9fbd264c  por xmm7, xmm1
0000707f9fbd2650  lea r12, [rax+0x20]
0000707f9fbd2654  mov r11, [r13+r12*1]
0000707f9fbd2659  lea r12, [rax+0x28]
0000707f9fbd265d  mov r10, [r13+r12*1]
0000707f9fbd2662  movq xmm1, r11
0000707f9fbd2667  vmovaps [rsp+0xA0], xmm1
0000707f9fbd2670  movq xmm1, r10
0000707f9fbd2675  vmovaps [rsp+0xB0], xmm1
0000707f9fbd267e  vmovaps xmm1, [rsp+0xA0]
0000707f9fbd2687  movq xmm1, xmm1
0000707f9fbd268b  vmovaps [rsp+0xA0], xmm1
0000707f9fbd2694  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd269d  movq xmm1, xmm1
0000707f9fbd26a1  vmovaps [rsp+0xB0], xmm2
0000707f9fbd26aa  vmovaps [rsp+0xC0], xmm1
0000707f9fbd26b3  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd26bc  por xmm2, xmm1
0000707f9fbd26c0  vmovaps [rsp+0xB0], xmm3
0000707f9fbd26c9  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd26d2  por xmm3, xmm1
0000707f9fbd26d6  vmovaps [rsp+0xB0], xmm4
0000707f9fbd26df  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd26e8  por xmm4, xmm1
0000707f9fbd26ec  vmovaps [rsp+0xB0], xmm9
0000707f9fbd26f5  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd26fe  por xmm9, xmm1
0000707f9fbd2703  lea r12, [rax+0x10]
0000707f9fbd2707  mov r11, [r13+r12*1]
0000707f9fbd270c  lea r12, [rax+0x18]
0000707f9fbd2710  mov r10, [r13+r12*1]
0000707f9fbd2715  movq xmm1, r11
0000707f9fbd271a  vmovaps [rsp+0xB0], xmm1
0000707f9fbd2723  movq xmm1, r10
0000707f9fbd2728  vmovaps [rsp+0xD0], xmm1
0000707f9fbd2731  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd273a  movq xmm1, xmm1
0000707f9fbd273e  vmovaps [rsp+0xB0], xmm1
0000707f9fbd2747  vmovaps xmm1, [rsp+0xD0]
0000707f9fbd2750  movq xmm1, xmm1
0000707f9fbd2754  vmovaps [rsp+0xD0], xmm1
0000707f9fbd275d  vmovaps xmm1, [rsp+0x80]
0000707f9fbd2766  vmovaps [rsp+0xE0], xmm15
0000707f9fbd276f  vmovaps xmm15, [rsp+0x80]
0000707f9fbd2778  por xmm1, xmm15
0000707f9fbd277d  vmovaps xmm15, [rsp+0x10]
0000707f9fbd2783  vmovaps [rsp+0x80], xmm1
0000707f9fbd278c  vmovaps xmm1, [rsp+0x10]
0000707f9fbd2792  por xmm15, xmm1
0000707f9fbd2797  vmovaps xmm1, [rsp+0x20]
0000707f9fbd279d  vmovaps [rsp+0x10], xmm15
0000707f9fbd27a3  vmovaps xmm15, [rsp+0x20]
0000707f9fbd27a9  por xmm1, xmm15
0000707f9fbd27ae  vmovaps [rsp+0x20], xmm6
0000707f9fbd27b4  vmovaps xmm15, [rsp+0x20]
0000707f9fbd27ba  por xmm6, xmm15
0000707f9fbd27bf  vmovaps [rsp+0x20], xmm11
0000707f9fbd27c5  vmovaps xmm15, [rsp+0x20]
0000707f9fbd27cb  por xmm11, xmm15
0000707f9fbd27d0  vmovaps [rsp+0x20], xmm13
0000707f9fbd27d6  vmovaps xmm15, [rsp+0x20]
0000707f9fbd27dc  por xmm13, xmm15
0000707f9fbd27e1  vmovaps [rsp+0x20], xmm14
0000707f9fbd27e7  vmovaps xmm15, [rsp+0x20]
0000707f9fbd27ed  por xmm14, xmm15
0000707f9fbd27f2  mov r12, [r13+rax*1]
0000707f9fbd27f7  vmovq xmm15, r12
0000707f9fbd27fc  vpbroadcastq xmm15, xmm15
0000707f9fbd2801  vmovaps [rsp+0x20], xmm1
0000707f9fbd2807  vxorps xmm1, xmm1, xmm1
0000707f9fbd280b  vpbroadcastq xmm1, xmm1
0000707f9fbd2810  vmovaps [rsp+0xF0], xmm1
0000707f9fbd2819  movups xmm1, [r13+r14*1]
0000707f9fbd281f  vmovaps [rsp+0x100], xmm1
0000707f9fbd2828  vxorps xmm1, xmm1, xmm1
0000707f9fbd282c  vpbroadcastq xmm1, xmm1
0000707f9fbd2831  lea r12, [rax+0x08]
0000707f9fbd2835  mov rax, [r13+r12*1]
0000707f9fbd283a  vmovaps [rsp+0x110], xmm1
0000707f9fbd2843  movq xmm1, rax
0000707f9fbd2848  movaps [r15+0x240], xmm1
0000707f9fbd2850  mov qword ptr [r15+0x60], 0x432190
0000707f9fbd2858  mov qword ptr [r15+0x58], 0x40
0000707f9fbd2860  vmovaps xmm1, [rsp+0x60]
0000707f9fbd2866  vmovaps [rsp+0x60], xmm15
0000707f9fbd286c  vmovaps xmm15, [rsp+0x100]
0000707f9fbd2875  vmovaps [rsp+0x100], xmm14
0000707f9fbd287e  vmovaps xmm14, [rsp+0x60]
0000707f9fbd2884  vmovaps [rsp+0x60], xmm13
0000707f9fbd288a  vmovaps [rsp+0x120], xmm12
0000707f9fbd2893  movaps xmm13, xmm1
0000707f9fbd2897  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd289c  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd28a2  vptest xmm12, xmm12
0000707f9fbd28a7  jnz 0x0000707F9FBD3482
0000707f9fbd28ad  vmovaps xmm1, [rsp+0xE0]
0000707f9fbd28b6  movaps xmm15, xmm5
0000707f9fbd28ba  vfmadd231pd xmm15, xmm1, xmm14
0000707f9fbd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
0000707f9fbd28c5  vptest xmm12, xmm12
0000707f9fbd28ca  jnz 0x0000707F9FBD35DB
0000707f9fbd28d0  vmovaps xmm12, [rsp+0x50]
0000707f9fbd28d6  vmovaps xmm5, [rsp+0x50]
0000707f9fbd28dc  por xmm12, xmm5
0000707f9fbd28e1  vmovaps xmm5, [rsp+0x30]
0000707f9fbd28e7  vmovaps [rsp+0x50], xmm1
0000707f9fbd28ed  vmovaps xmm1, [rsp+0x30]
0000707f9fbd28f3  por xmm5, xmm1
0000707f9fbd28f7  vmovaps [rsp+0x30], xmm10
0000707f9fbd28fd  vmovaps xmm1, [rsp+0x30]
0000707f9fbd2903  por xmm10, xmm1
0000707f9fbd2908  vmovaps [rsp+0x30], xmm8
0000707f9fbd290e  vmovaps xmm1, [rsp+0x30]
0000707f9fbd2914  por xmm8, xmm1
0000707f9fbd2919  vmovaps xmm1, [rsp+0x120]
0000707f9fbd2922  vmovaps [rsp+0x30], xmm15
0000707f9fbd2928  vmovaps xmm15, [rsp+0x120]
0000707f9fbd2931  por xmm1, xmm15
0000707f9fbd2936  vmovaps xmm15, [rsp+0x50]
0000707f9fbd293c  vmovaps [rsp+0xE0], xmm1
0000707f9fbd2945  vmovaps xmm1, [rsp+0x50]
0000707f9fbd294b  por xmm15, xmm1
0000707f9fbd2950  lea rax, [r14+0xC0]
0000707f9fbd2957  movups xmm1, [r13+rax*1]
0000707f9fbd295d  xor eax, eax
0000707f9fbd295f  mov r12d, 0x40
0000707f9fbd2965  mov r11d, 0x200
0000707f9fbd296b  cmp r12, r11
0000707f9fbd296e  cmc
0000707f9fbd296f  lahf
0000707f9fbd2970  seto al
0000707f9fbd2973  mov [r15+0x108], eax
0000707f9fbd297a  vmovaps [rsp+0x50], xmm1
0000707f9fbd2980  vmovaps xmm1, [rsp+0xF0]
0000707f9fbd2989  vmovaps [rsp+0xF0], xmm15
0000707f9fbd2992  vmovaps xmm15, [rsp+0x50]
0000707f9fbd2998  vmovaps [rsp+0x50], xmm13
0000707f9fbd299e  vmovaps [rsp+0x120], xmm12
0000707f9fbd29a7  movaps xmm13, xmm1
0000707f9fbd29ab  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd29b6  vptest xmm12, xmm12
0000707f9fbd29bb  jnz 0x0000707F9FBD373D
0000707f9fbd29c1  lea rax, [r14+0xB0]
0000707f9fbd29c8  movups xmm1, [r13+rax*1]
0000707f9fbd29ce  vmovaps xmm15, [rsp+0x110]
0000707f9fbd29d7  vmovaps [rsp+0x110], xmm13
0000707f9fbd29e0  movaps xmm12, xmm15
0000707f9fbd29e4  vfmadd231pd xmm12, xmm1, xmm14
0000707f9fbd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
0000707f9fbd29ef  vptest xmm13, xmm13
0000707f9fbd29f4  jnz 0x0000707F9FBD38A0
0000707f9fbd29fa  vmovaps xmm1, [rsp+0x100]
0000707f9fbd2a03  vmovaps xmm15, [rsp+0x100]
0000707f9fbd2a0c  por xmm1, xmm15
0000707f9fbd2a11  movaps [r15+0x210], xmm1
0000707f9fbd2a19  vmovaps xmm15, [rsp+0x60]
0000707f9fbd2a1f  vmovaps xmm14, [rsp+0x60]
0000707f9fbd2a25  por xmm15, xmm14
0000707f9fbd2a2a  movaps [r15+0x1C0], xmm15
0000707f9fbd2a32  vmovaps [rsp+0x60], xmm11
0000707f9fbd2a38  vmovaps xmm14, [rsp+0x60]
0000707f9fbd2a3e  por xmm11, xmm14
0000707f9fbd2a43  movaps [r15+0x280], xmm11
0000707f9fbd2a4b  vmovaps [rsp+0x60], xmm6
0000707f9fbd2a51  vmovaps xmm14, [rsp+0x60]
0000707f9fbd2a57  por xmm6, xmm14
0000707f9fbd2a5c  movaps [r15+0x2A0], xmm6
0000707f9fbd2a64  vmovaps xmm14, [rsp+0x20]
0000707f9fbd2a6a  vmovaps xmm13, [rsp+0x20]
0000707f9fbd2a70  por xmm14, xmm13
0000707f9fbd2a75  movaps [r15+0x2E0], xmm14
0000707f9fbd2a7d  vmovaps xmm13, [rsp+0x10]
0000707f9fbd2a83  vmovaps [rsp+0x20], xmm1
0000707f9fbd2a89  vmovaps xmm1, [rsp+0x10]
0000707f9fbd2a8f  por xmm13, xmm1
0000707f9fbd2a94  movaps [r15+0x1F0], xmm13
0000707f9fbd2a9c  vmovaps xmm1, [rsp+0xF0]
0000707f9fbd2aa5  vmovaps [rsp+0x10], xmm15
0000707f9fbd2aab  vmovaps xmm15, [rsp+0xF0]
0000707f9fbd2ab4  por xmm1, xmm15
0000707f9fbd2ab9  movaps [r15+0x250], xmm1
0000707f9fbd2ac1  vmovaps xmm1, [rsp+0xE0]
0000707f9fbd2aca  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd2ad3  por xmm1, xmm15
0000707f9fbd2ad8  movaps [r15+0x260], xmm1
0000707f9fbd2ae0  vmovaps [rsp+0x60], xmm8
0000707f9fbd2ae6  vmovaps xmm15, [rsp+0x60]
0000707f9fbd2aec  por xmm8, xmm15
0000707f9fbd2af1  movaps [r15+0x290], xmm8
0000707f9fbd2af9  vmovaps [rsp+0x60], xmm10
0000707f9fbd2aff  vmovaps xmm15, [rsp+0x60]
0000707f9fbd2b05  por xmm10, xmm15
0000707f9fbd2b0a  movaps [r15+0x2C0], xmm10
0000707f9fbd2b12  movq xmm15, qword ptr [r15+0x240]
0000707f9fbd2b1b  vmovaps [rsp+0x60], xmm15
0000707f9fbd2b21  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd2b27  vmovaps [rsp+0xE0], xmm1
0000707f9fbd2b30  vmovaps xmm1, [rsp+0x50]
0000707f9fbd2b36  vmovaps [rsp+0x50], xmm15
0000707f9fbd2b3c  vmovaps xmm15, [rsp+0x20]
0000707f9fbd2b42  vmovaps [rsp+0x20], xmm14
0000707f9fbd2b48  vmovaps xmm14, [rsp+0x50]
0000707f9fbd2b4e  vmovaps [rsp+0x50], xmm13
0000707f9fbd2b54  vmovaps [rsp+0xF0], xmm12
0000707f9fbd2b5d  movaps xmm13, xmm1
0000707f9fbd2b61  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd2b6c  vptest xmm12, xmm12
0000707f9fbd2b71  jnz 0x0000707F9FBD39F9
0000707f9fbd2b77  vmovaps xmm1, [rsp+0x60]
0000707f9fbd2b7d  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd2b83  vmovaps xmm15, [rsp+0x110]
0000707f9fbd2b8c  vmovaps xmm14, [rsp+0x20]
0000707f9fbd2b92  vmovaps [rsp+0x20], xmm13
0000707f9fbd2b98  movaps xmm12, xmm15
0000707f9fbd2b9c  vfmadd231pd xmm12, xmm14, xmm1
0000707f9fbd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
0000707f9fbd2ba7  vptest xmm13, xmm13
0000707f9fbd2bac  jnz 0x0000707F9FBD3B52
0000707f9fbd2bb2  vmovaps xmm1, [rsp+0x60]
0000707f9fbd2bb8  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd2bbe  vmovaps xmm15, [rsp+0x30]
0000707f9fbd2bc4  vmovaps xmm14, [rsp+0x10]
0000707f9fbd2bca  vmovaps [rsp+0x10], xmm12
0000707f9fbd2bd0  movaps xmm13, xmm15
0000707f9fbd2bd4  vfmadd231pd xmm13, xmm14, xmm1
0000707f9fbd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd2bdf  vptest xmm12, xmm12
0000707f9fbd2be4  jnz 0x0000707F9FBD3CAB
0000707f9fbd2bea  vmovaps [rsp+0x30], xmm5
0000707f9fbd2bf0  vmovaps xmm1, [rsp+0x30]
0000707f9fbd2bf6  por xmm5, xmm1
0000707f9fbd2bfa  movaps [r15+0x1D0], xmm5
0000707f9fbd2c02  vmovaps xmm1, [rsp+0x60]
0000707f9fbd2c08  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd2c0e  vmovaps xmm15, [rsp+0xF0]
0000707f9fbd2c17  vmovaps xmm14, [rsp+0x50]
0000707f9fbd2c1d  vmovaps [rsp+0x30], xmm13
0000707f9fbd2c23  movaps xmm12, xmm15
0000707f9fbd2c27  vfmadd231pd xmm12, xmm14, xmm1
0000707f9fbd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
0000707f9fbd2c32  vptest xmm13, xmm13
0000707f9fbd2c37  jnz 0x0000707F9FBD3E04
0000707f9fbd2c3d  vmovaps xmm1, [rsp+0x80]
0000707f9fbd2c46  vmovaps xmm15, [rsp+0x80]
0000707f9fbd2c4f  por xmm1, xmm15
0000707f9fbd2c54  movaps [r15+0x200], xmm1
0000707f9fbd2c5c  vmovaps xmm15, [rsp+0x120]
0000707f9fbd2c65  vmovaps xmm14, [rsp+0x120]
0000707f9fbd2c6e  por xmm15, xmm14
0000707f9fbd2c73  movaps [r15+0x1E0], xmm15
0000707f9fbd2c7b  vmovaps [rsp+0x50], xmm4
0000707f9fbd2c81  vmovaps xmm13, [rsp+0x50]
0000707f9fbd2c87  por xmm4, xmm13
0000707f9fbd2c8c  movaps [r15+0x2B0], xmm4
0000707f9fbd2c94  vmovaps [rsp+0x50], xmm3
0000707f9fbd2c9a  vmovaps xmm13, [rsp+0x50]
0000707f9fbd2ca0  por xmm3, xmm13
0000707f9fbd2ca5  movaps [r15+0x300], xmm3
0000707f9fbd2cad  vmovaps xmm15, [rsp+0xB0]
0000707f9fbd2cb6  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd2cbc  vmovaps xmm3, [rsp+0x20]
0000707f9fbd2cc2  vmovaps [rsp+0x20], xmm1
0000707f9fbd2cc8  vmovaps xmm1, [rsp+0xE0]
0000707f9fbd2cd1  vmovaps [rsp+0x50], xmm14
0000707f9fbd2cd7  vmovaps [rsp+0x60], xmm13
0000707f9fbd2cdd  movaps xmm14, xmm3
0000707f9fbd2ce1  vfmadd231pd xmm14, xmm1, xmm15
0000707f9fbd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
0000707f9fbd2cec  vptest xmm13, xmm13
0000707f9fbd2cf1  jnz 0x0000707F9FBD3F5D
0000707f9fbd2cf7  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd2d00  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd2d06  vmovaps xmm15, [rsp+0x10]
0000707f9fbd2d0c  movaps xmm13, xmm15
0000707f9fbd2d10  vfmadd231pd xmm13, xmm10, xmm1
0000707f9fbd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
0000707f9fbd2d1b  vptest xmm3, xmm3
0000707f9fbd2d20  jnz 0x0000707F9FBD40B5
0000707f9fbd2d26  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd2d2f  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd2d35  vmovaps xmm15, [rsp+0x30]
0000707f9fbd2d3b  movaps xmm10, xmm15
0000707f9fbd2d3f  vfmadd231pd xmm10, xmm11, xmm1
0000707f9fbd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
0000707f9fbd2d4a  vptest xmm3, xmm3
0000707f9fbd2d4f  jnz 0x0000707F9FBD420E
0000707f9fbd2d55  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd2d5e  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd2d64  movaps xmm15, xmm12
0000707f9fbd2d68  vfmadd231pd xmm15, xmm5, xmm1
0000707f9fbd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
0000707f9fbd2d73  vptest xmm11, xmm11
0000707f9fbd2d78  jnz 0x0000707F9FBD4367
0000707f9fbd2d7e  vmovaps [rsp+0x10], xmm9
0000707f9fbd2d84  vmovaps xmm1, [rsp+0x10]
0000707f9fbd2d8a  por xmm9, xmm1
0000707f9fbd2d8f  movaps [r15+0x180], xmm9
0000707f9fbd2d97  vmovaps [rsp+0x10], xmm2
0000707f9fbd2d9d  vmovaps xmm1, [rsp+0x10]
0000707f9fbd2da3  por xmm2, xmm1
0000707f9fbd2da7  movaps [r15+0x2D0], xmm2
0000707f9fbd2daf  vmovaps xmm12, [rsp+0xD0]
0000707f9fbd2db8  vpermilpd xmm12, xmm12, 0x00
0000707f9fbd2dbe  vmovaps xmm11, [rsp+0x60]
0000707f9fbd2dc4  movaps xmm5, xmm13
0000707f9fbd2dc8  vfmadd231pd xmm5, xmm11, xmm12
0000707f9fbd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
0000707f9fbd2dd2  vptest xmm3, xmm3
0000707f9fbd2dd7  jnz 0x0000707F9FBD44BF
0000707f9fbd2ddd  vmovaps xmm13, [rsp+0xD0]
0000707f9fbd2de6  vpermilpd xmm13, xmm13, 0x00
0000707f9fbd2dec  movaps xmm12, xmm14
0000707f9fbd2df0  vfmadd231pd xmm12, xmm9, xmm13
0000707f9fbd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
0000707f9fbd2dfb  vptest xmm11, xmm11
0000707f9fbd2e00  jnz 0x0000707F9FBD4617
0000707f9fbd2e06  lea rax, [r14+0x80]
0000707f9fbd2e0d  movups xmm14, [r13+rax*1]
0000707f9fbd2e13  movaps [r15+0x2F0], xmm14
0000707f9fbd2e1b  vmovaps xmm13, [rsp+0xD0]
0000707f9fbd2e24  vpermilpd xmm13, xmm13, 0x00
0000707f9fbd2e2a  movaps xmm11, xmm10
0000707f9fbd2e2e  vfmadd231pd xmm11, xmm8, xmm13
0000707f9fbd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
0000707f9fbd2e39  vptest xmm9, xmm9
0000707f9fbd2e3e  jnz 0x0000707F9FBD477B
0000707f9fbd2e44  vmovaps xmm13, [rsp+0xD0]
0000707f9fbd2e4d  vpermilpd xmm13, xmm13, 0x00
0000707f9fbd2e53  movaps xmm10, xmm15
0000707f9fbd2e57  vfmadd231pd xmm10, xmm1, xmm13
0000707f9fbd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
0000707f9fbd2e62  vptest xmm9, xmm9
0000707f9fbd2e67  jnz 0x0000707F9FBD48D5
0000707f9fbd2e6d  vmovaps [rsp+0x10], xmm7
0000707f9fbd2e73  vmovaps xmm1, [rsp+0x10]
0000707f9fbd2e79  por xmm7, xmm1
0000707f9fbd2e7d  movaps [r15+0x160], xmm7
0000707f9fbd2e85  lea rax, [r14+0x40]
0000707f9fbd2e89  movups xmm1, [r13+rax*1]
0000707f9fbd2e8f  lea rax, [r14+0x50]
0000707f9fbd2e93  movups xmm15, [r13+rax*1]
0000707f9fbd2e99  movaps [r15+0x1B0], xmm1
0000707f9fbd2ea1  movaps [r15+0x1A0], xmm15
0000707f9fbd2ea9  vmovaps xmm13, [rsp+0xA0]
0000707f9fbd2eb2  vpermilpd xmm13, xmm13, 0x00
0000707f9fbd2eb8  vmovaps xmm9, [rsp+0x40]
0000707f9fbd2ebe  movaps xmm8, xmm5
0000707f9fbd2ec2  vfmadd231pd xmm8, xmm9, xmm13
0000707f9fbd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
0000707f9fbd2ecd  vptest xmm3, xmm3
0000707f9fbd2ed2  jnz 0x0000707F9FBD4A42
0000707f9fbd2ed8  vmovaps xmm13, [rsp+0xA0]
0000707f9fbd2ee1  vpermilpd xmm13, xmm13, 0x00
0000707f9fbd2ee7  movaps xmm9, xmm12
0000707f9fbd2eeb  vfmadd231pd xmm9, xmm7, xmm13
0000707f9fbd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
0000707f9fbd2ef6  vptest xmm5, xmm5
0000707f9fbd2efb  jnz 0x0000707F9FBD4B9B
0000707f9fbd2f01  vmovaps xmm13, [rsp+0xA0]
0000707f9fbd2f0a  vpermilpd xmm13, xmm13, 0x00
0000707f9fbd2f10  movaps xmm12, xmm11
0000707f9fbd2f14  vfmadd231pd xmm12, xmm6, xmm13
0000707f9fbd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
0000707f9fbd2f1f  vptest xmm7, xmm7
0000707f9fbd2f24  jnz 0x0000707F9FBD4CF4
0000707f9fbd2f2a  vmovaps xmm13, [rsp+0xA0]
0000707f9fbd2f33  vpermilpd xmm13, xmm13, 0x00
0000707f9fbd2f39  vmovaps xmm11, [rsp+0x50]
0000707f9fbd2f3f  movaps xmm7, xmm10
0000707f9fbd2f43  vfmadd231pd xmm7, xmm11, xmm13
0000707f9fbd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
0000707f9fbd2f4d  vptest xmm6, xmm6
0000707f9fbd2f52  jnz 0x0000707F9FBD4E4D
0000707f9fbd2f58  lea rax, [r14+0x60]
0000707f9fbd2f5c  movups xmm13, [r13+rax*1]
0000707f9fbd2f62  lea rax, [r14+0x70]
0000707f9fbd2f66  movups xmm11, [r13+rax*1]
0000707f9fbd2f6c  movaps [r15+0x150], xmm13
0000707f9fbd2f74  movaps [r15+0x120], xmm11
0000707f9fbd2f7c  vmovaps xmm10, [rsp+0xC0]
0000707f9fbd2f85  vpermilpd xmm10, xmm10, 0x00
0000707f9fbd2f8b  movaps xmm6, xmm8
0000707f9fbd2f8f  vfmadd231pd xmm6, xmm15, xmm10
0000707f9fbd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
0000707f9fbd2f99  vptest xmm5, xmm5
0000707f9fbd2f9e  jnz 0x0000707F9FBD4FB9
0000707f9fbd2fa4  vmovaps xmm15, [rsp+0xC0]
0000707f9fbd2fad  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd2fb3  movaps xmm10, xmm9
0000707f9fbd2fb7  vfmadd231pd xmm10, xmm13, xmm15
0000707f9fbd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
0000707f9fbd2fc2  vptest xmm8, xmm8
0000707f9fbd2fc7  jnz 0x0000707F9FBD5111
0000707f9fbd2fcd  vmovaps xmm15, [rsp+0xC0]
0000707f9fbd2fd6  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd2fdc  movaps xmm13, xmm12
0000707f9fbd2fe0  vfmadd231pd xmm13, xmm4, xmm15
0000707f9fbd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
0000707f9fbd2feb  vptest xmm9, xmm9
0000707f9fbd2ff0  jnz 0x0000707F9FBD526B
0000707f9fbd2ff6  vmovaps xmm15, [rsp+0xC0]
0000707f9fbd2fff  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd3005  movaps xmm12, xmm7
0000707f9fbd3009  vfmadd231pd xmm12, xmm1, xmm15
0000707f9fbd300e  vcmppd xmm9, xmm12, xmm12, 0x03
0000707f9fbd3014  vptest xmm9, xmm9
0000707f9fbd3019  jnz 0x0000707F9FBD53C4
0000707f9fbd301f  lea rax, [r14+0x20]
0000707f9fbd3023  movups xmm1, [r13+rax*1]
0000707f9fbd3029  lea rax, [r14+0x30]
0000707f9fbd302d  movups xmm15, [r13+rax*1]
0000707f9fbd3033  vmovaps xmm9, [rsp+0x70]
0000707f9fbd3039  vpermilpd xmm9, xmm9, 0x00
0000707f9fbd303f  vmovaps xmm8, [rsp+0x20]
0000707f9fbd3045  movaps xmm7, xmm6
0000707f9fbd3048  vfmadd231pd xmm7, xmm8, xmm9
0000707f9fbd304d  vcmppd xmm5, xmm7, xmm7, 0x03
0000707f9fbd3052  vptest xmm5, xmm5
0000707f9fbd3057  jnz 0x0000707F9FBD5530
0000707f9fbd305d  vmovaps xmm9, [rsp+0x70]
0000707f9fbd3063  vpermilpd xmm9, xmm9, 0x00
0000707f9fbd3069  movaps xmm8, xmm10
0000707f9fbd306d  vfmadd231pd xmm8, xmm14, xmm9
0000707f9fbd3072  vcmppd xmm6, xmm8, xmm8, 0x03
0000707f9fbd3078  vptest xmm6, xmm6
0000707f9fbd307d  jnz 0x0000707F9FBD5687
0000707f9fbd3083  vmovaps xmm14, [rsp+0x70]
0000707f9fbd3089  vpermilpd xmm14, xmm14, 0x00
0000707f9fbd308f  movaps xmm10, xmm13
0000707f9fbd3093  vfmadd231pd xmm10, xmm11, xmm14
0000707f9fbd3098  vcmppd xmm9, xmm10, xmm10, 0x03
0000707f9fbd309e  vptest xmm9, xmm9
0000707f9fbd30a3  jnz 0x0000707F9FBD57E1
0000707f9fbd30a9  vmovaps xmm14, [rsp+0x70]
0000707f9fbd30af  vpermilpd xmm14, xmm14, 0x00
0000707f9fbd30b5  movaps xmm13, xmm12
0000707f9fbd30b9  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd30be  vcmppd xmm11, xmm13, xmm13, 0x03
0000707f9fbd30c4  vptest xmm11, xmm11
0000707f9fbd30c9  jnz 0x0000707F9FBD593B
0000707f9fbd30cf  lea rax, [r14+0x90]
0000707f9fbd30d6  movups xmm15, [r13+rax*1]
0000707f9fbd30dc  lea rax, [r14+0xA0]
0000707f9fbd30e3  movups xmm14, [r13+rax*1]
0000707f9fbd30e9  movaps [r15+0x140], xmm15
0000707f9fbd30f1  movaps [r15+0x130], xmm14
0000707f9fbd30f9  vmovaps xmm12, [rsp+0x90]
0000707f9fbd3102  vpermilpd xmm12, xmm12, 0x00
0000707f9fbd3108  movaps xmm11, xmm7
0000707f9fbd310c  vfmadd231pd xmm11, xmm1, xmm12
0000707f9fbd3111  vcmppd xmm9, xmm11, xmm11, 0x03
0000707f9fbd3117  vptest xmm9, xmm9
0000707f9fbd311c  jnz 0x0000707F9FBD5AA9
0000707f9fbd3122  movaps [r15+0x220], xmm11
0000707f9fbd312a  lea rax, [r14+0x10]
0000707f9fbd312e  movups xmm1, [r13+rax*1]
0000707f9fbd3134  movaps [r15+0x240], xmm1
0000707f9fbd313c  vmovaps xmm12, [rsp+0x90]
0000707f9fbd3145  vpermilpd xmm12, xmm12, 0x00
0000707f9fbd314b  movaps xmm9, xmm8
0000707f9fbd314f  vfmadd231pd xmm9, xmm14, xmm12
0000707f9fbd3154  vcmppd xmm7, xmm9, xmm9, 0x03
0000707f9fbd315a  vptest xmm7, xmm7
0000707f9fbd315f  jnz 0x0000707F9FBD5C0B
0000707f9fbd3165  movaps [r15+0x110], xmm9
0000707f9fbd316d  vmovaps xmm14, [rsp+0x90]
0000707f9fbd3176  vpermilpd xmm14, xmm14, 0x00
0000707f9fbd317c  movaps xmm12, xmm10
0000707f9fbd3180  vfmadd231pd xmm12, xmm15, xmm14
0000707f9fbd3185  vcmppd xmm8, xmm12, xmm12, 0x03
0000707f9fbd318b  vptest xmm8, xmm8
0000707f9fbd3190  jnz 0x0000707F9FBD5D65
0000707f9fbd3196  movaps [r15+0x170], xmm12
0000707f9fbd319e  vmovaps xmm15, [rsp+0x90]
0000707f9fbd31a7  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd31ad  movaps xmm14, xmm13
0000707f9fbd31b1  vfmadd231pd xmm14, xmm1, xmm15
0000707f9fbd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
0000707f9fbd31bc  vptest xmm10, xmm10
0000707f9fbd31c1  jnz 0x0000707F9FBD5EBF
0000707f9fbd31c7  movaps [r15+0x230], xmm14
0000707f9fbd31cf  mov eax, 0x432190
0000707f9fbd31d4  movups [r13+rax*1], xmm9
0000707f9fbd31da  mov eax, 0x4321A0
0000707f9fbd31df  movups [r13+rax*1], xmm12
0000707f9fbd31e5  mov eax, 0x4321B0
0000707f9fbd31ea  movups [r13+rax*1], xmm11
0000707f9fbd31f0  mov eax, 0x4321C0
0000707f9fbd31f5  movups [r13+rax*1], xmm14
0000707f9fbd31fb  mov eax, [r15+0x108]
0000707f9fbd3202  sahf
0000707f9fbd3203  jnz 0x0000707F9FBD3235
0000707f9fbd3205  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd320d  jz 0x0000707F9FBD9950
0000707f9fbd3213  nop [rax+rax*1], ax
0000707f9fbd321c  nop [rax+rax*1], eax
0000707f9fbd3224  mov eax, 0x410664
0000707f9fbd3229  mov [r15+0x100], rax
0000707f9fbd3230  jmp 0x0000707F9F9FE110
0000707f9fbd3235  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd323d  jz 0x0000707F9FBD6050
0000707f9fbd3243  nop [rax+rax*1], ax
0000707f9fbd324c  nop [rax+rax*1], eax
0000707f9fbd3254  mov eax, 0x4104F0
0000707f9fbd3259  mov [r15+0x100], rax
0000707f9fbd3260  jmp 0x0000707F9F9FE110
0000707f9fbd3265  int3
0000707f9fbd3266  call 0x0000707F9F9FF430
0000707f9fbd326b  jmp 0x0000707F9FBD230A
0000707f9fbd3270  call 0x0000707F9FAE5820
0000707f9fbd3275  jmp 0x0000707F9FBD2314
0000707f9fbd327a  call 0x0000707F9FAE45A0
0000707f9fbd327f  jmp 0x0000707F9FBD2326
0000707f9fbd3284  call 0x0000707F9FAE3320
0000707f9fbd3289  jmp 0x0000707F9FBD2330
0000707f9fbd328e  call 0x0000707F9FAE20A0
0000707f9fbd3293  jmp 0x0000707F9FBD233D
0000707f9fbd3298  call 0x0000707F9FAE0E30
0000707f9fbd329d  jmp 0x0000707F9FBD234A
0000707f9fbd32a2  call 0x0000707F9FAD6600
0000707f9fbd32a7  jmp 0x0000707F9FBD2357
0000707f9fbd32ac  call 0x0000707F9FAB52F0
0000707f9fbd32b1  jmp 0x0000707F9FBD2361
0000707f9fbd32b6  call 0x0000707F9FABE9C0
0000707f9fbd32bb  jmp 0x0000707F9FBD236B
0000707f9fbd32c0  call 0x0000707F9FABD750
0000707f9fbd32c5  jmp 0x0000707F9FBD2378
0000707f9fbd32ca  call 0x0000707F9FABC4E0
0000707f9fbd32cf  jmp 0x0000707F9FBD2385
0000707f9fbd32d4  call 0x0000707F9FABB270
0000707f9fbd32d9  jmp 0x0000707F9FBD2392
0000707f9fbd32de  call 0x0000707F9FABA000
0000707f9fbd32e3  jmp 0x0000707F9FBD239F
0000707f9fbd32e8  call 0x0000707F9FAB8D90
0000707f9fbd32ed  jmp 0x0000707F9FBD23AC
0000707f9fbd32f2  call 0x0000707F9FAB8A20
0000707f9fbd32f7  jmp 0x0000707F9FBD23B9
0000707f9fbd32fc  call 0x0000707F9FABEAE0
0000707f9fbd3301  jmp 0x0000707F9FBD23C6
0000707f9fbd3306  call 0x0000707F9FAB5400
0000707f9fbd330b  jmp 0x0000707F9FBD23D3
0000707f9fbd3310  call 0x0000707F9FAB52F0
0000707f9fbd3315  jmp 0x0000707F9FBD23E0
0000707f9fbd331a  call 0x0000707F9FABE9C0
0000707f9fbd331f  jmp 0x0000707F9FBD23ED
0000707f9fbd3324  call 0x0000707F9FAB77B0
0000707f9fbd3329  jmp 0x0000707F9FBD23FA
0000707f9fbd332e  call 0x0000707F9FAB6550
0000707f9fbd3333  jmp 0x0000707F9FBD2407
0000707f9fbd3338  call 0x0000707F9FAB52F0
0000707f9fbd333d  jmp 0x0000707F9FBD2417
0000707f9fbd3342  call 0x0000707F9FAB52F0
0000707f9fbd3347  jmp 0x0000707F9FBD2427
0000707f9fbd334c  call 0x0000707F9FABEAE0
0000707f9fbd3351  jmp 0x0000707F9FBD2431
0000707f9fbd3356  call 0x0000707F9FABEAE0
0000707f9fbd335b  jmp 0x0000707F9FBD2444
0000707f9fbd3360  call 0x0000707F9FABE9C0
0000707f9fbd3365  jmp 0x0000707F9FBD2451
0000707f9fbd336a  call 0x0000707F9FAB52F0
0000707f9fbd336f  jmp 0x0000707F9FBD2464
0000707f9fbd3374  call 0x0000707F9FAB6660
0000707f9fbd3379  jmp 0x0000707F9FBD2471
0000707f9fbd337e  call 0x0000707F9FAB78C0
0000707f9fbd3383  jmp 0x0000707F9FBD247E
0000707f9fbd3388  call 0x0000707F9FAB77B0
0000707f9fbd338d  jmp 0x0000707F9FBD248B
0000707f9fbd3392  call 0x0000707F9FAB6550
0000707f9fbd3397  jmp 0x0000707F9FBD2498
0000707f9fbd339c  call 0x0000707F9FAB52F0
0000707f9fbd33a1  jmp 0x0000707F9FBD24AB
0000707f9fbd33a6  call 0x0000707F9FAB52F0
0000707f9fbd33ab  jmp 0x0000707F9FBD24BE
0000707f9fbd33b0  call 0x0000707F9FAB52F0
0000707f9fbd33b5  jmp 0x0000707F9FBD24E5
0000707f9fbd33ba  call 0x0000707F9FAB52F0
0000707f9fbd33bf  jmp 0x0000707F9FBD24F8
0000707f9fbd33c4  call 0x0000707F9FAB52F0
0000707f9fbd33c9  jmp 0x0000707F9FBD250B
0000707f9fbd33ce  call 0x0000707F9FAB52F0
0000707f9fbd33d3  jmp 0x0000707F9FBD2521
0000707f9fbd33d8  call 0x0000707F9FAB52F0
0000707f9fbd33dd  jmp 0x0000707F9FBD2537
0000707f9fbd33e2  call 0x0000707F9FAB52F0
0000707f9fbd33e7  jmp 0x0000707F9FBD254D
0000707f9fbd33ec  call 0x0000707F9F9FF540
0000707f9fbd33f1  jmp 0x0000707F9FBD256E
0000707f9fbd33f6  call 0x0000707F9FA02FE0
0000707f9fbd33fb  jmp 0x0000707F9FBD2578
0000707f9fbd3400  call 0x0000707F9F9FF540
0000707f9fbd3405  jmp 0x0000707F9FBD2588
0000707f9fbd340a  call 0x0000707F9F9FF540
0000707f9fbd340f  jmp 0x0000707F9FBD259B
0000707f9fbd3414  call 0x0000707F9F9FF540
0000707f9fbd3419  jmp 0x0000707F9FBD25AE
0000707f9fbd341e  call 0x0000707F9F9FF540
0000707f9fbd3423  jmp 0x0000707F9FBD25C1
0000707f9fbd3428  call 0x0000707F9FAC0370
0000707f9fbd342d  jmp 0x0000707F9FBD25E0
0000707f9fbd3432  call 0x0000707F9FABF100
0000707f9fbd3437  jmp 0x0000707F9FBD25E9
0000707f9fbd343c  call 0x0000707F9FAC0370
0000707f9fbd3441  jmp 0x0000707F9FBD2659
0000707f9fbd3446  call 0x0000707F9FABF100
0000707f9fbd344b  jmp 0x0000707F9FBD2662
0000707f9fbd3450  call 0x0000707F9FAC0370
0000707f9fbd3455  jmp 0x0000707F9FBD270C
0000707f9fbd345a  call 0x0000707F9FABF100
0000707f9fbd345f  jmp 0x0000707F9FBD2715
0000707f9fbd3464  call 0x0000707F9FA0B720
0000707f9fbd3469  jmp 0x0000707F9FBD27F7
0000707f9fbd346e  call 0x0000707F9FAD64F0
0000707f9fbd3473  jmp 0x0000707F9FBD281F
0000707f9fbd3478  call 0x0000707F9FAB47C0
0000707f9fbd347d  jmp 0x0000707F9FBD283A
0000707f9fbd3482  sub rsp, 0x08
0000707f9fbd3486  push rax
0000707f9fbd3487  push rcx
0000707f9fbd3488  push rdx
0000707f9fbd3489  push rdi
0000707f9fbd348a  push rsi
0000707f9fbd348b  push r8
0000707f9fbd348d  push r9
0000707f9fbd348f  push r10
0000707f9fbd3491  push r11
0000707f9fbd3493  sub rsp, 0xF0
0000707f9fbd349a  vmovaps [rsp], xmm0
0000707f9fbd349f  vmovaps [rsp+0x10], xmm1
0000707f9fbd34a5  vmovaps [rsp+0x20], xmm2
0000707f9fbd34ab  vmovaps [rsp+0x30], xmm3
0000707f9fbd34b1  vmovaps [rsp+0x40], xmm4
0000707f9fbd34b7  vmovaps [rsp+0x50], xmm5
0000707f9fbd34bd  vmovaps [rsp+0x60], xmm6
0000707f9fbd34c3  vmovaps [rsp+0x70], xmm7
0000707f9fbd34c9  vmovaps [rsp+0x80], xmm8
0000707f9fbd34d2  vmovaps [rsp+0x90], xmm9
0000707f9fbd34db  vmovaps [rsp+0xA0], xmm10
0000707f9fbd34e4  vmovaps [rsp+0xB0], xmm11
0000707f9fbd34ed  vmovaps [rsp+0xC0], xmm12
0000707f9fbd34f6  vmovaps [rsp+0xD0], xmm14
0000707f9fbd34ff  vmovaps [rsp+0xE0], xmm15
0000707f9fbd3508  sub rsp, 0x40
0000707f9fbd350c  lea rdi, [rsp]
0000707f9fbd3510  lea rsi, [rsp+0x10]
0000707f9fbd3515  lea rdx, [rsp+0x20]
0000707f9fbd351a  lea rcx, [rsp+0x30]
0000707f9fbd351f  mov r8d, 0x00
0000707f9fbd3525  lea r9, [r15+0x3A8]
0000707f9fbd352c  movaps [rdi], xmm13
0000707f9fbd3530  movaps [rsi], xmm1
0000707f9fbd3533  movaps [rdx], xmm15
0000707f9fbd3537  movaps [rcx], xmm14
0000707f9fbd353b  mov rax, 0x5753922B7A50
0000707f9fbd3545  call rax
0000707f9fbd3547  movaps xmm13, [rsp]
0000707f9fbd354c  add rsp, 0x40
0000707f9fbd3550  vmovaps xmm0, [rsp]
0000707f9fbd3555  vmovaps xmm1, [rsp+0x10]
0000707f9fbd355b  vmovaps xmm2, [rsp+0x20]
0000707f9fbd3561  vmovaps xmm3, [rsp+0x30]
0000707f9fbd3567  vmovaps xmm4, [rsp+0x40]
0000707f9fbd356d  vmovaps xmm5, [rsp+0x50]
0000707f9fbd3573  vmovaps xmm6, [rsp+0x60]
0000707f9fbd3579  vmovaps xmm7, [rsp+0x70]
0000707f9fbd357f  vmovaps xmm8, [rsp+0x80]
0000707f9fbd3588  vmovaps xmm9, [rsp+0x90]
0000707f9fbd3591  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd359a  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd35a3  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd35ac  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd35b5  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd35be  add rsp, 0xF0
0000707f9fbd35c5  pop r11
0000707f9fbd35c7  pop r10
0000707f9fbd35c9  pop r9
0000707f9fbd35cb  pop r8
0000707f9fbd35cd  pop rsi
0000707f9fbd35ce  pop rdi
0000707f9fbd35cf  pop rdx
0000707f9fbd35d0  pop rcx
0000707f9fbd35d1  pop rax
0000707f9fbd35d2  add rsp, 0x08
0000707f9fbd35d6  jmp 0x0000707F9FBD28AD
0000707f9fbd35db  sub rsp, 0x08
0000707f9fbd35df  push rax
0000707f9fbd35e0  push rcx
0000707f9fbd35e1  push rdx
0000707f9fbd35e2  push rdi
0000707f9fbd35e3  push rsi
0000707f9fbd35e4  push r8
0000707f9fbd35e6  push r9
0000707f9fbd35e8  push r10
0000707f9fbd35ea  push r11
0000707f9fbd35ec  sub rsp, 0xF0
0000707f9fbd35f3  vmovaps [rsp], xmm0
0000707f9fbd35f8  vmovaps [rsp+0x10], xmm1
0000707f9fbd35fe  vmovaps [rsp+0x20], xmm2
0000707f9fbd3604  vmovaps [rsp+0x30], xmm3
0000707f9fbd360a  vmovaps [rsp+0x40], xmm4
0000707f9fbd3610  vmovaps [rsp+0x50], xmm5
0000707f9fbd3616  vmovaps [rsp+0x60], xmm6
0000707f9fbd361c  vmovaps [rsp+0x70], xmm7
0000707f9fbd3622  vmovaps [rsp+0x80], xmm8
0000707f9fbd362b  vmovaps [rsp+0x90], xmm9
0000707f9fbd3634  vmovaps [rsp+0xA0], xmm10
0000707f9fbd363d  vmovaps [rsp+0xB0], xmm11
0000707f9fbd3646  vmovaps [rsp+0xC0], xmm12
0000707f9fbd364f  vmovaps [rsp+0xD0], xmm13
0000707f9fbd3658  vmovaps [rsp+0xE0], xmm14
0000707f9fbd3661  sub rsp, 0x40
0000707f9fbd3665  lea rdi, [rsp]
0000707f9fbd3669  lea rsi, [rsp+0x10]
0000707f9fbd366e  lea rdx, [rsp+0x20]
0000707f9fbd3673  lea rcx, [rsp+0x30]
0000707f9fbd3678  mov r8d, 0x00
0000707f9fbd367e  lea r9, [r15+0x3A8]
0000707f9fbd3685  movaps [rdi], xmm15
0000707f9fbd3689  movaps [rsi], xmm5
0000707f9fbd368c  movaps [rdx], xmm1
0000707f9fbd368f  movaps [rcx], xmm14
0000707f9fbd3693  mov rax, 0x5753922B7A50
0000707f9fbd369d  call rax
0000707f9fbd369f  movaps xmm15, [rsp]
0000707f9fbd36a4  add rsp, 0x40
0000707f9fbd36a8  vmovaps xmm0, [rsp]
0000707f9fbd36ad  vmovaps xmm1, [rsp+0x10]
0000707f9fbd36b3  vmovaps xmm2, [rsp+0x20]
0000707f9fbd36b9  vmovaps xmm3, [rsp+0x30]
0000707f9fbd36bf  vmovaps xmm4, [rsp+0x40]
0000707f9fbd36c5  vmovaps xmm5, [rsp+0x50]
0000707f9fbd36cb  vmovaps xmm6, [rsp+0x60]
0000707f9fbd36d1  vmovaps xmm7, [rsp+0x70]
0000707f9fbd36d7  vmovaps xmm8, [rsp+0x80]
0000707f9fbd36e0  vmovaps xmm9, [rsp+0x90]
0000707f9fbd36e9  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd36f2  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd36fb  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd3704  vmovaps xmm13, [rsp+0xD0]
0000707f9fbd370d  vmovaps xmm14, [rsp+0xE0]
0000707f9fbd3716  add rsp, 0xF0
0000707f9fbd371d  pop r11
0000707f9fbd371f  pop r10
0000707f9fbd3721  pop r9
0000707f9fbd3723  pop r8
0000707f9fbd3725  pop rsi
0000707f9fbd3726  pop rdi
0000707f9fbd3727  pop rdx
0000707f9fbd3728  pop rcx
0000707f9fbd3729  pop rax
0000707f9fbd372a  add rsp, 0x08
0000707f9fbd372e  jmp 0x0000707F9FBD28D0
0000707f9fbd3733  call 0x0000707F9F9FF430
0000707f9fbd3738  jmp 0x0000707F9FBD295D
0000707f9fbd373d  sub rsp, 0x08
0000707f9fbd3741  push rax
0000707f9fbd3742  push rcx
0000707f9fbd3743  push rdx
0000707f9fbd3744  push rdi
0000707f9fbd3745  push rsi
0000707f9fbd3746  push r8
0000707f9fbd3748  push r9
0000707f9fbd374a  push r10
0000707f9fbd374c  push r11
0000707f9fbd374e  sub rsp, 0xF0
0000707f9fbd3755  vmovaps [rsp], xmm0
0000707f9fbd375a  vmovaps [rsp+0x10], xmm1
0000707f9fbd3760  vmovaps [rsp+0x20], xmm2
0000707f9fbd3766  vmovaps [rsp+0x30], xmm3
0000707f9fbd376c  vmovaps [rsp+0x40], xmm4
0000707f9fbd3772  vmovaps [rsp+0x50], xmm5
0000707f9fbd3778  vmovaps [rsp+0x60], xmm6
0000707f9fbd377e  vmovaps [rsp+0x70], xmm7
0000707f9fbd3784  vmovaps [rsp+0x80], xmm8
0000707f9fbd378d  vmovaps [rsp+0x90], xmm9
0000707f9fbd3796  vmovaps [rsp+0xA0], xmm10
0000707f9fbd379f  vmovaps [rsp+0xB0], xmm11
0000707f9fbd37a8  vmovaps [rsp+0xC0], xmm12
0000707f9fbd37b1  vmovaps [rsp+0xD0], xmm14
0000707f9fbd37ba  vmovaps [rsp+0xE0], xmm15
0000707f9fbd37c3  sub rsp, 0x40
0000707f9fbd37c7  lea rdi, [rsp]
0000707f9fbd37cb  lea rsi, [rsp+0x10]
0000707f9fbd37d0  lea rdx, [rsp+0x20]
0000707f9fbd37d5  lea rcx, [rsp+0x30]
0000707f9fbd37da  mov r8d, 0x00
0000707f9fbd37e0  lea r9, [r15+0x3A8]
0000707f9fbd37e7  movaps [rdi], xmm13
0000707f9fbd37eb  movaps [rsi], xmm1
0000707f9fbd37ee  movaps [rdx], xmm15
0000707f9fbd37f2  movaps [rcx], xmm14
0000707f9fbd37f6  mov rax, 0x5753922B7A50
0000707f9fbd3800  call rax
0000707f9fbd3802  movaps xmm13, [rsp]
0000707f9fbd3807  add rsp, 0x40
0000707f9fbd380b  vmovaps xmm0, [rsp]
0000707f9fbd3810  vmovaps xmm1, [rsp+0x10]
0000707f9fbd3816  vmovaps xmm2, [rsp+0x20]
0000707f9fbd381c  vmovaps xmm3, [rsp+0x30]
0000707f9fbd3822  vmovaps xmm4, [rsp+0x40]
0000707f9fbd3828  vmovaps xmm5, [rsp+0x50]
0000707f9fbd382e  vmovaps xmm6, [rsp+0x60]
0000707f9fbd3834  vmovaps xmm7, [rsp+0x70]
0000707f9fbd383a  vmovaps xmm8, [rsp+0x80]
0000707f9fbd3843  vmovaps xmm9, [rsp+0x90]
0000707f9fbd384c  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd3855  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd385e  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd3867  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd3870  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd3879  add rsp, 0xF0
0000707f9fbd3880  pop r11
0000707f9fbd3882  pop r10
0000707f9fbd3884  pop r9
0000707f9fbd3886  pop r8
0000707f9fbd3888  pop rsi
0000707f9fbd3889  pop rdi
0000707f9fbd388a  pop rdx
0000707f9fbd388b  pop rcx
0000707f9fbd388c  pop rax
0000707f9fbd388d  add rsp, 0x08
0000707f9fbd3891  jmp 0x0000707F9FBD29C1
0000707f9fbd3896  call 0x0000707F9F9FF430
0000707f9fbd389b  jmp 0x0000707F9FBD29CE
0000707f9fbd38a0  sub rsp, 0x08
0000707f9fbd38a4  push rax
0000707f9fbd38a5  push rcx
0000707f9fbd38a6  push rdx
0000707f9fbd38a7  push rdi
0000707f9fbd38a8  push rsi
0000707f9fbd38a9  push r8
0000707f9fbd38ab  push r9
0000707f9fbd38ad  push r10
0000707f9fbd38af  push r11
0000707f9fbd38b1  sub rsp, 0xF0
0000707f9fbd38b8  vmovaps [rsp], xmm0
0000707f9fbd38bd  vmovaps [rsp+0x10], xmm1
0000707f9fbd38c3  vmovaps [rsp+0x20], xmm2
0000707f9fbd38c9  vmovaps [rsp+0x30], xmm3
0000707f9fbd38cf  vmovaps [rsp+0x40], xmm4
0000707f9fbd38d5  vmovaps [rsp+0x50], xmm5
0000707f9fbd38db  vmovaps [rsp+0x60], xmm6
0000707f9fbd38e1  vmovaps [rsp+0x70], xmm7
0000707f9fbd38e7  vmovaps [rsp+0x80], xmm8
0000707f9fbd38f0  vmovaps [rsp+0x90], xmm9
0000707f9fbd38f9  vmovaps [rsp+0xA0], xmm10
0000707f9fbd3902  vmovaps [rsp+0xB0], xmm11
0000707f9fbd390b  vmovaps [rsp+0xC0], xmm13
0000707f9fbd3914  vmovaps [rsp+0xD0], xmm14
0000707f9fbd391d  vmovaps [rsp+0xE0], xmm15
0000707f9fbd3926  sub rsp, 0x40
0000707f9fbd392a  lea rdi, [rsp]
0000707f9fbd392e  lea rsi, [rsp+0x10]
0000707f9fbd3933  lea rdx, [rsp+0x20]
0000707f9fbd3938  lea rcx, [rsp+0x30]
0000707f9fbd393d  mov r8d, 0x00
0000707f9fbd3943  lea r9, [r15+0x3A8]
0000707f9fbd394a  movaps [rdi], xmm12
0000707f9fbd394e  movaps [rsi], xmm15
0000707f9fbd3952  movaps [rdx], xmm1
0000707f9fbd3955  movaps [rcx], xmm14
0000707f9fbd3959  mov rax, 0x5753922B7A50
0000707f9fbd3963  call rax
0000707f9fbd3965  movaps xmm12, [rsp]
0000707f9fbd396a  add rsp, 0x40
0000707f9fbd396e  vmovaps xmm0, [rsp]
0000707f9fbd3973  vmovaps xmm1, [rsp+0x10]
0000707f9fbd3979  vmovaps xmm2, [rsp+0x20]
0000707f9fbd397f  vmovaps xmm3, [rsp+0x30]
0000707f9fbd3985  vmovaps xmm4, [rsp+0x40]
0000707f9fbd398b  vmovaps xmm5, [rsp+0x50]
0000707f9fbd3991  vmovaps xmm6, [rsp+0x60]
0000707f9fbd3997  vmovaps xmm7, [rsp+0x70]
0000707f9fbd399d  vmovaps xmm8, [rsp+0x80]
0000707f9fbd39a6  vmovaps xmm9, [rsp+0x90]
0000707f9fbd39af  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd39b8  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd39c1  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd39ca  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd39d3  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd39dc  add rsp, 0xF0
0000707f9fbd39e3  pop r11
0000707f9fbd39e5  pop r10
0000707f9fbd39e7  pop r9
0000707f9fbd39e9  pop r8
0000707f9fbd39eb  pop rsi
0000707f9fbd39ec  pop rdi
0000707f9fbd39ed  pop rdx
0000707f9fbd39ee  pop rcx
0000707f9fbd39ef  pop rax
0000707f9fbd39f0  add rsp, 0x08
0000707f9fbd39f4  jmp 0x0000707F9FBD29FA
0000707f9fbd39f9  sub rsp, 0x08
0000707f9fbd39fd  push rax
0000707f9fbd39fe  push rcx
0000707f9fbd39ff  push rdx
0000707f9fbd3a00  push rdi
0000707f9fbd3a01  push rsi
0000707f9fbd3a02  push r8
0000707f9fbd3a04  push r9
0000707f9fbd3a06  push r10
0000707f9fbd3a08  push r11
0000707f9fbd3a0a  sub rsp, 0xF0
0000707f9fbd3a11  vmovaps [rsp], xmm0
0000707f9fbd3a16  vmovaps [rsp+0x10], xmm1
0000707f9fbd3a1c  vmovaps [rsp+0x20], xmm2
0000707f9fbd3a22  vmovaps [rsp+0x30], xmm3
0000707f9fbd3a28  vmovaps [rsp+0x40], xmm4
0000707f9fbd3a2e  vmovaps [rsp+0x50], xmm5
0000707f9fbd3a34  vmovaps [rsp+0x60], xmm6
0000707f9fbd3a3a  vmovaps [rsp+0x70], xmm7
0000707f9fbd3a40  vmovaps [rsp+0x80], xmm8
0000707f9fbd3a49  vmovaps [rsp+0x90], xmm9
0000707f9fbd3a52  vmovaps [rsp+0xA0], xmm10
0000707f9fbd3a5b  vmovaps [rsp+0xB0], xmm11
0000707f9fbd3a64  vmovaps [rsp+0xC0], xmm12
0000707f9fbd3a6d  vmovaps [rsp+0xD0], xmm14
0000707f9fbd3a76  vmovaps [rsp+0xE0], xmm15
0000707f9fbd3a7f  sub rsp, 0x40
0000707f9fbd3a83  lea rdi, [rsp]
0000707f9fbd3a87  lea rsi, [rsp+0x10]
0000707f9fbd3a8c  lea rdx, [rsp+0x20]
0000707f9fbd3a91  lea rcx, [rsp+0x30]
0000707f9fbd3a96  mov r8d, 0x00
0000707f9fbd3a9c  lea r9, [r15+0x3A8]
0000707f9fbd3aa3  movaps [rdi], xmm13
0000707f9fbd3aa7  movaps [rsi], xmm1
0000707f9fbd3aaa  movaps [rdx], xmm15
0000707f9fbd3aae  movaps [rcx], xmm14
0000707f9fbd3ab2  mov rax, 0x5753922B7A50
0000707f9fbd3abc  call rax
0000707f9fbd3abe  movaps xmm13, [rsp]
0000707f9fbd3ac3  add rsp, 0x40
0000707f9fbd3ac7  vmovaps xmm0, [rsp]
0000707f9fbd3acc  vmovaps xmm1, [rsp+0x10]
0000707f9fbd3ad2  vmovaps xmm2, [rsp+0x20]
0000707f9fbd3ad8  vmovaps xmm3, [rsp+0x30]
0000707f9fbd3ade  vmovaps xmm4, [rsp+0x40]
0000707f9fbd3ae4  vmovaps xmm5, [rsp+0x50]
0000707f9fbd3aea  vmovaps xmm6, [rsp+0x60]
0000707f9fbd3af0  vmovaps xmm7, [rsp+0x70]
0000707f9fbd3af6  vmovaps xmm8, [rsp+0x80]
0000707f9fbd3aff  vmovaps xmm9, [rsp+0x90]
0000707f9fbd3b08  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd3b11  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd3b1a  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd3b23  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd3b2c  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd3b35  add rsp, 0xF0
0000707f9fbd3b3c  pop r11
0000707f9fbd3b3e  pop r10
0000707f9fbd3b40  pop r9
0000707f9fbd3b42  pop r8
0000707f9fbd3b44  pop rsi
0000707f9fbd3b45  pop rdi
0000707f9fbd3b46  pop rdx
0000707f9fbd3b47  pop rcx
0000707f9fbd3b48  pop rax
0000707f9fbd3b49  add rsp, 0x08
0000707f9fbd3b4d  jmp 0x0000707F9FBD2B77
0000707f9fbd3b52  sub rsp, 0x08
0000707f9fbd3b56  push rax
0000707f9fbd3b57  push rcx
0000707f9fbd3b58  push rdx
0000707f9fbd3b59  push rdi
0000707f9fbd3b5a  push rsi
0000707f9fbd3b5b  push r8
0000707f9fbd3b5d  push r9
0000707f9fbd3b5f  push r10
0000707f9fbd3b61  push r11
0000707f9fbd3b63  sub rsp, 0xF0
0000707f9fbd3b6a  vmovaps [rsp], xmm0
0000707f9fbd3b6f  vmovaps [rsp+0x10], xmm1
0000707f9fbd3b75  vmovaps [rsp+0x20], xmm2
0000707f9fbd3b7b  vmovaps [rsp+0x30], xmm3
0000707f9fbd3b81  vmovaps [rsp+0x40], xmm4
0000707f9fbd3b87  vmovaps [rsp+0x50], xmm5
0000707f9fbd3b8d  vmovaps [rsp+0x60], xmm6
0000707f9fbd3b93  vmovaps [rsp+0x70], xmm7
0000707f9fbd3b99  vmovaps [rsp+0x80], xmm8
0000707f9fbd3ba2  vmovaps [rsp+0x90], xmm9
0000707f9fbd3bab  vmovaps [rsp+0xA0], xmm10
0000707f9fbd3bb4  vmovaps [rsp+0xB0], xmm11
0000707f9fbd3bbd  vmovaps [rsp+0xC0], xmm13
0000707f9fbd3bc6  vmovaps [rsp+0xD0], xmm14
0000707f9fbd3bcf  vmovaps [rsp+0xE0], xmm15
0000707f9fbd3bd8  sub rsp, 0x40
0000707f9fbd3bdc  lea rdi, [rsp]
0000707f9fbd3be0  lea rsi, [rsp+0x10]
0000707f9fbd3be5  lea rdx, [rsp+0x20]
0000707f9fbd3bea  lea rcx, [rsp+0x30]
0000707f9fbd3bef  mov r8d, 0x00
0000707f9fbd3bf5  lea r9, [r15+0x3A8]
0000707f9fbd3bfc  movaps [rdi], xmm12
0000707f9fbd3c00  movaps [rsi], xmm15
0000707f9fbd3c04  movaps [rdx], xmm14
0000707f9fbd3c08  movaps [rcx], xmm1
0000707f9fbd3c0b  mov rax, 0x5753922B7A50
0000707f9fbd3c15  call rax
0000707f9fbd3c17  movaps xmm12, [rsp]
0000707f9fbd3c1c  add rsp, 0x40
0000707f9fbd3c20  vmovaps xmm0, [rsp]
0000707f9fbd3c25  vmovaps xmm1, [rsp+0x10]
0000707f9fbd3c2b  vmovaps xmm2, [rsp+0x20]
0000707f9fbd3c31  vmovaps xmm3, [rsp+0x30]
0000707f9fbd3c37  vmovaps xmm4, [rsp+0x40]
0000707f9fbd3c3d  vmovaps xmm5, [rsp+0x50]
0000707f9fbd3c43  vmovaps xmm6, [rsp+0x60]
0000707f9fbd3c49  vmovaps xmm7, [rsp+0x70]
0000707f9fbd3c4f  vmovaps xmm8, [rsp+0x80]
0000707f9fbd3c58  vmovaps xmm9, [rsp+0x90]
0000707f9fbd3c61  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd3c6a  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd3c73  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd3c7c  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd3c85  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd3c8e  add rsp, 0xF0
0000707f9fbd3c95  pop r11
0000707f9fbd3c97  pop r10
0000707f9fbd3c99  pop r9
0000707f9fbd3c9b  pop r8
0000707f9fbd3c9d  pop rsi
0000707f9fbd3c9e  pop rdi
0000707f9fbd3c9f  pop rdx
0000707f9fbd3ca0  pop rcx
0000707f9fbd3ca1  pop rax
0000707f9fbd3ca2  add rsp, 0x08
0000707f9fbd3ca6  jmp 0x0000707F9FBD2BB2
0000707f9fbd3cab  sub rsp, 0x08
0000707f9fbd3caf  push rax
0000707f9fbd3cb0  push rcx
0000707f9fbd3cb1  push rdx
0000707f9fbd3cb2  push rdi
0000707f9fbd3cb3  push rsi
0000707f9fbd3cb4  push r8
0000707f9fbd3cb6  push r9
0000707f9fbd3cb8  push r10
0000707f9fbd3cba  push r11
0000707f9fbd3cbc  sub rsp, 0xF0
0000707f9fbd3cc3  vmovaps [rsp], xmm0
0000707f9fbd3cc8  vmovaps [rsp+0x10], xmm1
0000707f9fbd3cce  vmovaps [rsp+0x20], xmm2
0000707f9fbd3cd4  vmovaps [rsp+0x30], xmm3
0000707f9fbd3cda  vmovaps [rsp+0x40], xmm4
0000707f9fbd3ce0  vmovaps [rsp+0x50], xmm5
0000707f9fbd3ce6  vmovaps [rsp+0x60], xmm6
0000707f9fbd3cec  vmovaps [rsp+0x70], xmm7
0000707f9fbd3cf2  vmovaps [rsp+0x80], xmm8
0000707f9fbd3cfb  vmovaps [rsp+0x90], xmm9
0000707f9fbd3d04  vmovaps [rsp+0xA0], xmm10
0000707f9fbd3d0d  vmovaps [rsp+0xB0], xmm11
0000707f9fbd3d16  vmovaps [rsp+0xC0], xmm12
0000707f9fbd3d1f  vmovaps [rsp+0xD0], xmm14
0000707f9fbd3d28  vmovaps [rsp+0xE0], xmm15
0000707f9fbd3d31  sub rsp, 0x40
0000707f9fbd3d35  lea rdi, [rsp]
0000707f9fbd3d39  lea rsi, [rsp+0x10]
0000707f9fbd3d3e  lea rdx, [rsp+0x20]
0000707f9fbd3d43  lea rcx, [rsp+0x30]
0000707f9fbd3d48  mov r8d, 0x00
0000707f9fbd3d4e  lea r9, [r15+0x3A8]
0000707f9fbd3d55  movaps [rdi], xmm13
0000707f9fbd3d59  movaps [rsi], xmm15
0000707f9fbd3d5d  movaps [rdx], xmm14
0000707f9fbd3d61  movaps [rcx], xmm1
0000707f9fbd3d64  mov rax, 0x5753922B7A50
0000707f9fbd3d6e  call rax
0000707f9fbd3d70  movaps xmm13, [rsp]
0000707f9fbd3d75  add rsp, 0x40
0000707f9fbd3d79  vmovaps xmm0, [rsp]
0000707f9fbd3d7e  vmovaps xmm1, [rsp+0x10]
0000707f9fbd3d84  vmovaps xmm2, [rsp+0x20]
0000707f9fbd3d8a  vmovaps xmm3, [rsp+0x30]
0000707f9fbd3d90  vmovaps xmm4, [rsp+0x40]
0000707f9fbd3d96  vmovaps xmm5, [rsp+0x50]
0000707f9fbd3d9c  vmovaps xmm6, [rsp+0x60]
0000707f9fbd3da2  vmovaps xmm7, [rsp+0x70]
0000707f9fbd3da8  vmovaps xmm8, [rsp+0x80]
0000707f9fbd3db1  vmovaps xmm9, [rsp+0x90]
0000707f9fbd3dba  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd3dc3  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd3dcc  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd3dd5  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd3dde  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd3de7  add rsp, 0xF0
0000707f9fbd3dee  pop r11
0000707f9fbd3df0  pop r10
0000707f9fbd3df2  pop r9
0000707f9fbd3df4  pop r8
0000707f9fbd3df6  pop rsi
0000707f9fbd3df7  pop rdi
0000707f9fbd3df8  pop rdx
0000707f9fbd3df9  pop rcx
0000707f9fbd3dfa  pop rax
0000707f9fbd3dfb  add rsp, 0x08
0000707f9fbd3dff  jmp 0x0000707F9FBD2BEA
0000707f9fbd3e04  sub rsp, 0x08
0000707f9fbd3e08  push rax
0000707f9fbd3e09  push rcx
0000707f9fbd3e0a  push rdx
0000707f9fbd3e0b  push rdi
0000707f9fbd3e0c  push rsi
0000707f9fbd3e0d  push r8
0000707f9fbd3e0f  push r9
0000707f9fbd3e11  push r10
0000707f9fbd3e13  push r11
0000707f9fbd3e15  sub rsp, 0xF0
0000707f9fbd3e1c  vmovaps [rsp], xmm0
0000707f9fbd3e21  vmovaps [rsp+0x10], xmm1
0000707f9fbd3e27  vmovaps [rsp+0x20], xmm2
0000707f9fbd3e2d  vmovaps [rsp+0x30], xmm3
0000707f9fbd3e33  vmovaps [rsp+0x40], xmm4
0000707f9fbd3e39  vmovaps [rsp+0x50], xmm5
0000707f9fbd3e3f  vmovaps [rsp+0x60], xmm6
0000707f9fbd3e45  vmovaps [rsp+0x70], xmm7
0000707f9fbd3e4b  vmovaps [rsp+0x80], xmm8
0000707f9fbd3e54  vmovaps [rsp+0x90], xmm9
0000707f9fbd3e5d  vmovaps [rsp+0xA0], xmm10
0000707f9fbd3e66  vmovaps [rsp+0xB0], xmm11
0000707f9fbd3e6f  vmovaps [rsp+0xC0], xmm13
0000707f9fbd3e78  vmovaps [rsp+0xD0], xmm14
0000707f9fbd3e81  vmovaps [rsp+0xE0], xmm15
0000707f9fbd3e8a  sub rsp, 0x40
0000707f9fbd3e8e  lea rdi, [rsp]
0000707f9fbd3e92  lea rsi, [rsp+0x10]
0000707f9fbd3e97  lea rdx, [rsp+0x20]
0000707f9fbd3e9c  lea rcx, [rsp+0x30]
0000707f9fbd3ea1  mov r8d, 0x00
0000707f9fbd3ea7  lea r9, [r15+0x3A8]
0000707f9fbd3eae  movaps [rdi], xmm12
0000707f9fbd3eb2  movaps [rsi], xmm15
0000707f9fbd3eb6  movaps [rdx], xmm14
0000707f9fbd3eba  movaps [rcx], xmm1
0000707f9fbd3ebd  mov rax, 0x5753922B7A50
0000707f9fbd3ec7  call rax
0000707f9fbd3ec9  movaps xmm12, [rsp]
0000707f9fbd3ece  add rsp, 0x40
0000707f9fbd3ed2  vmovaps xmm0, [rsp]
0000707f9fbd3ed7  vmovaps xmm1, [rsp+0x10]
0000707f9fbd3edd  vmovaps xmm2, [rsp+0x20]
0000707f9fbd3ee3  vmovaps xmm3, [rsp+0x30]
0000707f9fbd3ee9  vmovaps xmm4, [rsp+0x40]
0000707f9fbd3eef  vmovaps xmm5, [rsp+0x50]
0000707f9fbd3ef5  vmovaps xmm6, [rsp+0x60]
0000707f9fbd3efb  vmovaps xmm7, [rsp+0x70]
0000707f9fbd3f01  vmovaps xmm8, [rsp+0x80]
0000707f9fbd3f0a  vmovaps xmm9, [rsp+0x90]
0000707f9fbd3f13  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd3f1c  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd3f25  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd3f2e  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd3f37  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd3f40  add rsp, 0xF0
0000707f9fbd3f47  pop r11
0000707f9fbd3f49  pop r10
0000707f9fbd3f4b  pop r9
0000707f9fbd3f4d  pop r8
0000707f9fbd3f4f  pop rsi
0000707f9fbd3f50  pop rdi
0000707f9fbd3f51  pop rdx
0000707f9fbd3f52  pop rcx
0000707f9fbd3f53  pop rax
0000707f9fbd3f54  add rsp, 0x08
0000707f9fbd3f58  jmp 0x0000707F9FBD2C3D
0000707f9fbd3f5d  sub rsp, 0x08
0000707f9fbd3f61  push rax
0000707f9fbd3f62  push rcx
0000707f9fbd3f63  push rdx
0000707f9fbd3f64  push rdi
0000707f9fbd3f65  push rsi
0000707f9fbd3f66  push r8
0000707f9fbd3f68  push r9
0000707f9fbd3f6a  push r10
0000707f9fbd3f6c  push r11
0000707f9fbd3f6e  sub rsp, 0xF0
0000707f9fbd3f75  vmovaps [rsp], xmm0
0000707f9fbd3f7a  vmovaps [rsp+0x10], xmm1
0000707f9fbd3f80  vmovaps [rsp+0x20], xmm2
0000707f9fbd3f86  vmovaps [rsp+0x30], xmm3
0000707f9fbd3f8c  vmovaps [rsp+0x40], xmm4
0000707f9fbd3f92  vmovaps [rsp+0x50], xmm5
0000707f9fbd3f98  vmovaps [rsp+0x60], xmm6
0000707f9fbd3f9e  vmovaps [rsp+0x70], xmm7
0000707f9fbd3fa4  vmovaps [rsp+0x80], xmm8
0000707f9fbd3fad  vmovaps [rsp+0x90], xmm9
0000707f9fbd3fb6  vmovaps [rsp+0xA0], xmm10
0000707f9fbd3fbf  vmovaps [rsp+0xB0], xmm11
0000707f9fbd3fc8  vmovaps [rsp+0xC0], xmm12
0000707f9fbd3fd1  vmovaps [rsp+0xD0], xmm13
0000707f9fbd3fda  vmovaps [rsp+0xE0], xmm15
0000707f9fbd3fe3  sub rsp, 0x40
0000707f9fbd3fe7  lea rdi, [rsp]
0000707f9fbd3feb  lea rsi, [rsp+0x10]
0000707f9fbd3ff0  lea rdx, [rsp+0x20]
0000707f9fbd3ff5  lea rcx, [rsp+0x30]
0000707f9fbd3ffa  mov r8d, 0x00
0000707f9fbd4000  lea r9, [r15+0x3A8]
0000707f9fbd4007  movaps [rdi], xmm14
0000707f9fbd400b  movaps [rsi], xmm3
0000707f9fbd400e  movaps [rdx], xmm1
0000707f9fbd4011  movaps [rcx], xmm15
0000707f9fbd4015  mov rax, 0x5753922B7A50
0000707f9fbd401f  call rax
0000707f9fbd4021  movaps xmm14, [rsp]
0000707f9fbd4026  add rsp, 0x40
0000707f9fbd402a  vmovaps xmm0, [rsp]
0000707f9fbd402f  vmovaps xmm1, [rsp+0x10]
0000707f9fbd4035  vmovaps xmm2, [rsp+0x20]
0000707f9fbd403b  vmovaps xmm3, [rsp+0x30]
0000707f9fbd4041  vmovaps xmm4, [rsp+0x40]
0000707f9fbd4047  vmovaps xmm5, [rsp+0x50]
0000707f9fbd404d  vmovaps xmm6, [rsp+0x60]
0000707f9fbd4053  vmovaps xmm7, [rsp+0x70]
0000707f9fbd4059  vmovaps xmm8, [rsp+0x80]
0000707f9fbd4062  vmovaps xmm9, [rsp+0x90]
0000707f9fbd406b  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd4074  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd407d  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd4086  vmovaps xmm13, [rsp+0xD0]
0000707f9fbd408f  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd4098  add rsp, 0xF0
0000707f9fbd409f  pop r11
0000707f9fbd40a1  pop r10
0000707f9fbd40a3  pop r9
0000707f9fbd40a5  pop r8
0000707f9fbd40a7  pop rsi
0000707f9fbd40a8  pop rdi
0000707f9fbd40a9  pop rdx
0000707f9fbd40aa  pop rcx
0000707f9fbd40ab  pop rax
0000707f9fbd40ac  add rsp, 0x08
0000707f9fbd40b0  jmp 0x0000707F9FBD2CF7
0000707f9fbd40b5  sub rsp, 0x08
0000707f9fbd40b9  push rax
0000707f9fbd40ba  push rcx
0000707f9fbd40bb  push rdx
0000707f9fbd40bc  push rdi
0000707f9fbd40bd  push rsi
0000707f9fbd40be  push r8
0000707f9fbd40c0  push r9
0000707f9fbd40c2  push r10
0000707f9fbd40c4  push r11
0000707f9fbd40c6  sub rsp, 0xF0
0000707f9fbd40cd  vmovaps [rsp], xmm0
0000707f9fbd40d2  vmovaps [rsp+0x10], xmm1
0000707f9fbd40d8  vmovaps [rsp+0x20], xmm2
0000707f9fbd40de  vmovaps [rsp+0x30], xmm3
0000707f9fbd40e4  vmovaps [rsp+0x40], xmm4
0000707f9fbd40ea  vmovaps [rsp+0x50], xmm5
0000707f9fbd40f0  vmovaps [rsp+0x60], xmm6
0000707f9fbd40f6  vmovaps [rsp+0x70], xmm7
0000707f9fbd40fc  vmovaps [rsp+0x80], xmm8
0000707f9fbd4105  vmovaps [rsp+0x90], xmm9
0000707f9fbd410e  vmovaps [rsp+0xA0], xmm10
0000707f9fbd4117  vmovaps [rsp+0xB0], xmm11
0000707f9fbd4120  vmovaps [rsp+0xC0], xmm12
0000707f9fbd4129  vmovaps [rsp+0xD0], xmm14
0000707f9fbd4132  vmovaps [rsp+0xE0], xmm15
0000707f9fbd413b  sub rsp, 0x40
0000707f9fbd413f  lea rdi, [rsp]
0000707f9fbd4143  lea rsi, [rsp+0x10]
0000707f9fbd4148  lea rdx, [rsp+0x20]
0000707f9fbd414d  lea rcx, [rsp+0x30]
0000707f9fbd4152  mov r8d, 0x00
0000707f9fbd4158  lea r9, [r15+0x3A8]
0000707f9fbd415f  movaps [rdi], xmm13
0000707f9fbd4163  movaps [rsi], xmm15
0000707f9fbd4167  movaps [rdx], xmm10
0000707f9fbd416b  movaps [rcx], xmm1
0000707f9fbd416e  mov rax, 0x5753922B7A50
0000707f9fbd4178  call rax
0000707f9fbd417a  movaps xmm13, [rsp]
0000707f9fbd417f  add rsp, 0x40
0000707f9fbd4183  vmovaps xmm0, [rsp]
0000707f9fbd4188  vmovaps xmm1, [rsp+0x10]
0000707f9fbd418e  vmovaps xmm2, [rsp+0x20]
0000707f9fbd4194  vmovaps xmm3, [rsp+0x30]
0000707f9fbd419a  vmovaps xmm4, [rsp+0x40]
0000707f9fbd41a0  vmovaps xmm5, [rsp+0x50]
0000707f9fbd41a6  vmovaps xmm6, [rsp+0x60]
0000707f9fbd41ac  vmovaps xmm7, [rsp+0x70]
0000707f9fbd41b2  vmovaps xmm8, [rsp+0x80]
0000707f9fbd41bb  vmovaps xmm9, [rsp+0x90]
0000707f9fbd41c4  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd41cd  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd41d6  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd41df  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd41e8  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd41f1  add rsp, 0xF0
0000707f9fbd41f8  pop r11
0000707f9fbd41fa  pop r10
0000707f9fbd41fc  pop r9
0000707f9fbd41fe  pop r8
0000707f9fbd4200  pop rsi
0000707f9fbd4201  pop rdi
0000707f9fbd4202  pop rdx
0000707f9fbd4203  pop rcx
0000707f9fbd4204  pop rax
0000707f9fbd4205  add rsp, 0x08
0000707f9fbd4209  jmp 0x0000707F9FBD2D26
0000707f9fbd420e  sub rsp, 0x08
0000707f9fbd4212  push rax
0000707f9fbd4213  push rcx
0000707f9fbd4214  push rdx
0000707f9fbd4215  push rdi
0000707f9fbd4216  push rsi
0000707f9fbd4217  push r8
0000707f9fbd4219  push r9
0000707f9fbd421b  push r10
0000707f9fbd421d  push r11
0000707f9fbd421f  sub rsp, 0xF0
0000707f9fbd4226  vmovaps [rsp], xmm0
0000707f9fbd422b  vmovaps [rsp+0x10], xmm1
0000707f9fbd4231  vmovaps [rsp+0x20], xmm2
0000707f9fbd4237  vmovaps [rsp+0x30], xmm3
0000707f9fbd423d  vmovaps [rsp+0x40], xmm4
0000707f9fbd4243  vmovaps [rsp+0x50], xmm5
0000707f9fbd4249  vmovaps [rsp+0x60], xmm6
0000707f9fbd424f  vmovaps [rsp+0x70], xmm7
0000707f9fbd4255  vmovaps [rsp+0x80], xmm8
0000707f9fbd425e  vmovaps [rsp+0x90], xmm9
0000707f9fbd4267  vmovaps [rsp+0xA0], xmm11
0000707f9fbd4270  vmovaps [rsp+0xB0], xmm12
0000707f9fbd4279  vmovaps [rsp+0xC0], xmm13
0000707f9fbd4282  vmovaps [rsp+0xD0], xmm14
0000707f9fbd428b  vmovaps [rsp+0xE0], xmm15
0000707f9fbd4294  sub rsp, 0x40
0000707f9fbd4298  lea rdi, [rsp]
0000707f9fbd429c  lea rsi, [rsp+0x10]
0000707f9fbd42a1  lea rdx, [rsp+0x20]
0000707f9fbd42a6  lea rcx, [rsp+0x30]
0000707f9fbd42ab  mov r8d, 0x00
0000707f9fbd42b1  lea r9, [r15+0x3A8]
0000707f9fbd42b8  movaps [rdi], xmm10
0000707f9fbd42bc  movaps [rsi], xmm15
0000707f9fbd42c0  movaps [rdx], xmm11
0000707f9fbd42c4  movaps [rcx], xmm1
0000707f9fbd42c7  mov rax, 0x5753922B7A50
0000707f9fbd42d1  call rax
0000707f9fbd42d3  movaps xmm10, [rsp]
0000707f9fbd42d8  add rsp, 0x40
0000707f9fbd42dc  vmovaps xmm0, [rsp]
0000707f9fbd42e1  vmovaps xmm1, [rsp+0x10]
0000707f9fbd42e7  vmovaps xmm2, [rsp+0x20]
0000707f9fbd42ed  vmovaps xmm3, [rsp+0x30]
0000707f9fbd42f3  vmovaps xmm4, [rsp+0x40]
0000707f9fbd42f9  vmovaps xmm5, [rsp+0x50]
0000707f9fbd42ff  vmovaps xmm6, [rsp+0x60]
0000707f9fbd4305  vmovaps xmm7, [rsp+0x70]
0000707f9fbd430b  vmovaps xmm8, [rsp+0x80]
0000707f9fbd4314  vmovaps xmm9, [rsp+0x90]
0000707f9fbd431d  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd4326  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd432f  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd4338  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd4341  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd434a  add rsp, 0xF0
0000707f9fbd4351  pop r11
0000707f9fbd4353  pop r10
0000707f9fbd4355  pop r9
0000707f9fbd4357  pop r8
0000707f9fbd4359  pop rsi
0000707f9fbd435a  pop rdi
0000707f9fbd435b  pop rdx
0000707f9fbd435c  pop rcx
0000707f9fbd435d  pop rax
0000707f9fbd435e  add rsp, 0x08
0000707f9fbd4362  jmp 0x0000707F9FBD2D55
0000707f9fbd4367  sub rsp, 0x08
0000707f9fbd436b  push rax
0000707f9fbd436c  push rcx
0000707f9fbd436d  push rdx
0000707f9fbd436e  push rdi
0000707f9fbd436f  push rsi
0000707f9fbd4370  push r8
0000707f9fbd4372  push r9
0000707f9fbd4374  push r10
0000707f9fbd4376  push r11
0000707f9fbd4378  sub rsp, 0xF0
0000707f9fbd437f  vmovaps [rsp], xmm0
0000707f9fbd4384  vmovaps [rsp+0x10], xmm1
0000707f9fbd438a  vmovaps [rsp+0x20], xmm2
0000707f9fbd4390  vmovaps [rsp+0x30], xmm3
0000707f9fbd4396  vmovaps [rsp+0x40], xmm4
0000707f9fbd439c  vmovaps [rsp+0x50], xmm5
0000707f9fbd43a2  vmovaps [rsp+0x60], xmm6
0000707f9fbd43a8  vmovaps [rsp+0x70], xmm7
0000707f9fbd43ae  vmovaps [rsp+0x80], xmm8
0000707f9fbd43b7  vmovaps [rsp+0x90], xmm9
0000707f9fbd43c0  vmovaps [rsp+0xA0], xmm10
0000707f9fbd43c9  vmovaps [rsp+0xB0], xmm11
0000707f9fbd43d2  vmovaps [rsp+0xC0], xmm12
0000707f9fbd43db  vmovaps [rsp+0xD0], xmm13
0000707f9fbd43e4  vmovaps [rsp+0xE0], xmm14
0000707f9fbd43ed  sub rsp, 0x40
0000707f9fbd43f1  lea rdi, [rsp]
0000707f9fbd43f5  lea rsi, [rsp+0x10]
0000707f9fbd43fa  lea rdx, [rsp+0x20]
0000707f9fbd43ff  lea rcx, [rsp+0x30]
0000707f9fbd4404  mov r8d, 0x00
0000707f9fbd440a  lea r9, [r15+0x3A8]
0000707f9fbd4411  movaps [rdi], xmm15
0000707f9fbd4415  movaps [rsi], xmm12
0000707f9fbd4419  movaps [rdx], xmm5
0000707f9fbd441c  movaps [rcx], xmm1
0000707f9fbd441f  mov rax, 0x5753922B7A50
0000707f9fbd4429  call rax
0000707f9fbd442b  movaps xmm15, [rsp]
0000707f9fbd4430  add rsp, 0x40
0000707f9fbd4434  vmovaps xmm0, [rsp]
0000707f9fbd4439  vmovaps xmm1, [rsp+0x10]
0000707f9fbd443f  vmovaps xmm2, [rsp+0x20]
0000707f9fbd4445  vmovaps xmm3, [rsp+0x30]
0000707f9fbd444b  vmovaps xmm4, [rsp+0x40]
0000707f9fbd4451  vmovaps xmm5, [rsp+0x50]
0000707f9fbd4457  vmovaps xmm6, [rsp+0x60]
0000707f9fbd445d  vmovaps xmm7, [rsp+0x70]
0000707f9fbd4463  vmovaps xmm8, [rsp+0x80]
0000707f9fbd446c  vmovaps xmm9, [rsp+0x90]
0000707f9fbd4475  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd447e  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd4487  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd4490  vmovaps xmm13, [rsp+0xD0]
0000707f9fbd4499  vmovaps xmm14, [rsp+0xE0]
0000707f9fbd44a2  add rsp, 0xF0
0000707f9fbd44a9  pop r11
0000707f9fbd44ab  pop r10
0000707f9fbd44ad  pop r9
0000707f9fbd44af  pop r8
0000707f9fbd44b1  pop rsi
0000707f9fbd44b2  pop rdi
0000707f9fbd44b3  pop rdx
0000707f9fbd44b4  pop rcx
0000707f9fbd44b5  pop rax
0000707f9fbd44b6  add rsp, 0x08
0000707f9fbd44ba  jmp 0x0000707F9FBD2D7E
0000707f9fbd44bf  sub rsp, 0x08
0000707f9fbd44c3  push rax
0000707f9fbd44c4  push rcx
0000707f9fbd44c5  push rdx
0000707f9fbd44c6  push rdi
0000707f9fbd44c7  push rsi
0000707f9fbd44c8  push r8
0000707f9fbd44ca  push r9
0000707f9fbd44cc  push r10
0000707f9fbd44ce  push r11
0000707f9fbd44d0  sub rsp, 0xF0
0000707f9fbd44d7  vmovaps [rsp], xmm0
0000707f9fbd44dc  vmovaps [rsp+0x10], xmm1
0000707f9fbd44e2  vmovaps [rsp+0x20], xmm2
0000707f9fbd44e8  vmovaps [rsp+0x30], xmm3
0000707f9fbd44ee  vmovaps [rsp+0x40], xmm4
0000707f9fbd44f4  vmovaps [rsp+0x50], xmm6
0000707f9fbd44fa  vmovaps [rsp+0x60], xmm7
0000707f9fbd4500  vmovaps [rsp+0x70], xmm8
0000707f9fbd4506  vmovaps [rsp+0x80], xmm9
0000707f9fbd450f  vmovaps [rsp+0x90], xmm10
0000707f9fbd4518  vmovaps [rsp+0xA0], xmm11
0000707f9fbd4521  vmovaps [rsp+0xB0], xmm12
0000707f9fbd452a  vmovaps [rsp+0xC0], xmm13
0000707f9fbd4533  vmovaps [rsp+0xD0], xmm14
0000707f9fbd453c  vmovaps [rsp+0xE0], xmm15
0000707f9fbd4545  sub rsp, 0x40
0000707f9fbd4549  lea rdi, [rsp]
0000707f9fbd454d  lea rsi, [rsp+0x10]
0000707f9fbd4552  lea rdx, [rsp+0x20]
0000707f9fbd4557  lea rcx, [rsp+0x30]
0000707f9fbd455c  mov r8d, 0x00
0000707f9fbd4562  lea r9, [r15+0x3A8]
0000707f9fbd4569  movaps [rdi], xmm5
0000707f9fbd456c  movaps [rsi], xmm13
0000707f9fbd4570  movaps [rdx], xmm11
0000707f9fbd4574  movaps [rcx], xmm12
0000707f9fbd4578  mov rax, 0x5753922B7A50
0000707f9fbd4582  call rax
0000707f9fbd4584  movaps xmm5, [rsp]
0000707f9fbd4588  add rsp, 0x40
0000707f9fbd458c  vmovaps xmm0, [rsp]
0000707f9fbd4591  vmovaps xmm1, [rsp+0x10]
0000707f9fbd4597  vmovaps xmm2, [rsp+0x20]
0000707f9fbd459d  vmovaps xmm3, [rsp+0x30]
0000707f9fbd45a3  vmovaps xmm4, [rsp+0x40]
0000707f9fbd45a9  vmovaps xmm6, [rsp+0x50]
0000707f9fbd45af  vmovaps xmm7, [rsp+0x60]
0000707f9fbd45b5  vmovaps xmm8, [rsp+0x70]
0000707f9fbd45bb  vmovaps xmm9, [rsp+0x80]
0000707f9fbd45c4  vmovaps xmm10, [rsp+0x90]
0000707f9fbd45cd  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd45d6  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd45df  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd45e8  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd45f1  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd45fa  add rsp, 0xF0
0000707f9fbd4601  pop r11
0000707f9fbd4603  pop r10
0000707f9fbd4605  pop r9
0000707f9fbd4607  pop r8
0000707f9fbd4609  pop rsi
0000707f9fbd460a  pop rdi
0000707f9fbd460b  pop rdx
0000707f9fbd460c  pop rcx
0000707f9fbd460d  pop rax
0000707f9fbd460e  add rsp, 0x08
0000707f9fbd4612  jmp 0x0000707F9FBD2DDD
0000707f9fbd4617  sub rsp, 0x08
0000707f9fbd461b  push rax
0000707f9fbd461c  push rcx
0000707f9fbd461d  push rdx
0000707f9fbd461e  push rdi
0000707f9fbd461f  push rsi
0000707f9fbd4620  push r8
0000707f9fbd4622  push r9
0000707f9fbd4624  push r10
0000707f9fbd4626  push r11
0000707f9fbd4628  sub rsp, 0xF0
0000707f9fbd462f  vmovaps [rsp], xmm0
0000707f9fbd4634  vmovaps [rsp+0x10], xmm1
0000707f9fbd463a  vmovaps [rsp+0x20], xmm2
0000707f9fbd4640  vmovaps [rsp+0x30], xmm3
0000707f9fbd4646  vmovaps [rsp+0x40], xmm4
0000707f9fbd464c  vmovaps [rsp+0x50], xmm5
0000707f9fbd4652  vmovaps [rsp+0x60], xmm6
0000707f9fbd4658  vmovaps [rsp+0x70], xmm7
0000707f9fbd465e  vmovaps [rsp+0x80], xmm8
0000707f9fbd4667  vmovaps [rsp+0x90], xmm9
0000707f9fbd4670  vmovaps [rsp+0xA0], xmm10
0000707f9fbd4679  vmovaps [rsp+0xB0], xmm11
0000707f9fbd4682  vmovaps [rsp+0xC0], xmm13
0000707f9fbd468b  vmovaps [rsp+0xD0], xmm14
0000707f9fbd4694  vmovaps [rsp+0xE0], xmm15
0000707f9fbd469d  sub rsp, 0x40
0000707f9fbd46a1  lea rdi, [rsp]
0000707f9fbd46a5  lea rsi, [rsp+0x10]
0000707f9fbd46aa  lea rdx, [rsp+0x20]
0000707f9fbd46af  lea rcx, [rsp+0x30]
0000707f9fbd46b4  mov r8d, 0x00
0000707f9fbd46ba  lea r9, [r15+0x3A8]
0000707f9fbd46c1  movaps [rdi], xmm12
0000707f9fbd46c5  movaps [rsi], xmm14
0000707f9fbd46c9  movaps [rdx], xmm9
0000707f9fbd46cd  movaps [rcx], xmm13
0000707f9fbd46d1  mov rax, 0x5753922B7A50
0000707f9fbd46db  call rax
0000707f9fbd46dd  movaps xmm12, [rsp]
0000707f9fbd46e2  add rsp, 0x40
0000707f9fbd46e6  vmovaps xmm0, [rsp]
0000707f9fbd46eb  vmovaps xmm1, [rsp+0x10]
0000707f9fbd46f1  vmovaps xmm2, [rsp+0x20]
0000707f9fbd46f7  vmovaps xmm3, [rsp+0x30]
0000707f9fbd46fd  vmovaps xmm4, [rsp+0x40]
0000707f9fbd4703  vmovaps xmm5, [rsp+0x50]
0000707f9fbd4709  vmovaps xmm6, [rsp+0x60]
0000707f9fbd470f  vmovaps xmm7, [rsp+0x70]
0000707f9fbd4715  vmovaps xmm8, [rsp+0x80]
0000707f9fbd471e  vmovaps xmm9, [rsp+0x90]
0000707f9fbd4727  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd4730  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd4739  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd4742  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd474b  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd4754  add rsp, 0xF0
0000707f9fbd475b  pop r11
0000707f9fbd475d  pop r10
0000707f9fbd475f  pop r9
0000707f9fbd4761  pop r8
0000707f9fbd4763  pop rsi
0000707f9fbd4764  pop rdi
0000707f9fbd4765  pop rdx
0000707f9fbd4766  pop rcx
0000707f9fbd4767  pop rax
0000707f9fbd4768  add rsp, 0x08
0000707f9fbd476c  jmp 0x0000707F9FBD2E06
0000707f9fbd4771  call 0x0000707F9FA0D4E0
0000707f9fbd4776  jmp 0x0000707F9FBD2E13
0000707f9fbd477b  sub rsp, 0x08
0000707f9fbd477f  push rax
0000707f9fbd4780  push rcx
0000707f9fbd4781  push rdx
0000707f9fbd4782  push rdi
0000707f9fbd4783  push rsi
0000707f9fbd4784  push r8
0000707f9fbd4786  push r9
0000707f9fbd4788  push r10
0000707f9fbd478a  push r11
0000707f9fbd478c  sub rsp, 0xF0
0000707f9fbd4793  vmovaps [rsp], xmm0
0000707f9fbd4798  vmovaps [rsp+0x10], xmm1
0000707f9fbd479e  vmovaps [rsp+0x20], xmm2
0000707f9fbd47a4  vmovaps [rsp+0x30], xmm3
0000707f9fbd47aa  vmovaps [rsp+0x40], xmm4
0000707f9fbd47b0  vmovaps [rsp+0x50], xmm5
0000707f9fbd47b6  vmovaps [rsp+0x60], xmm6
0000707f9fbd47bc  vmovaps [rsp+0x70], xmm7
0000707f9fbd47c2  vmovaps [rsp+0x80], xmm8
0000707f9fbd47cb  vmovaps [rsp+0x90], xmm9
0000707f9fbd47d4  vmovaps [rsp+0xA0], xmm10
0000707f9fbd47dd  vmovaps [rsp+0xB0], xmm12
0000707f9fbd47e6  vmovaps [rsp+0xC0], xmm13
0000707f9fbd47ef  vmovaps [rsp+0xD0], xmm14
0000707f9fbd47f8  vmovaps [rsp+0xE0], xmm15
0000707f9fbd4801  sub rsp, 0x40
0000707f9fbd4805  lea rdi, [rsp]
0000707f9fbd4809  lea rsi, [rsp+0x10]
0000707f9fbd480e  lea rdx, [rsp+0x20]
0000707f9fbd4813  lea rcx, [rsp+0x30]
0000707f9fbd4818  mov r8d, 0x00
0000707f9fbd481e  lea r9, [r15+0x3A8]
0000707f9fbd4825  movaps [rdi], xmm11
0000707f9fbd4829  movaps [rsi], xmm10
0000707f9fbd482d  movaps [rdx], xmm8
0000707f9fbd4831  movaps [rcx], xmm13
0000707f9fbd4835  mov rax, 0x5753922B7A50
0000707f9fbd483f  call rax
0000707f9fbd4841  movaps xmm11, [rsp]
0000707f9fbd4846  add rsp, 0x40
0000707f9fbd484a  vmovaps xmm0, [rsp]
0000707f9fbd484f  vmovaps xmm1, [rsp+0x10]
0000707f9fbd4855  vmovaps xmm2, [rsp+0x20]
0000707f9fbd485b  vmovaps xmm3, [rsp+0x30]
0000707f9fbd4861  vmovaps xmm4, [rsp+0x40]
0000707f9fbd4867  vmovaps xmm5, [rsp+0x50]
0000707f9fbd486d  vmovaps xmm6, [rsp+0x60]
0000707f9fbd4873  vmovaps xmm7, [rsp+0x70]
0000707f9fbd4879  vmovaps xmm8, [rsp+0x80]
0000707f9fbd4882  vmovaps xmm9, [rsp+0x90]
0000707f9fbd488b  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd4894  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd489d  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd48a6  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd48af  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd48b8  add rsp, 0xF0
0000707f9fbd48bf  pop r11
0000707f9fbd48c1  pop r10
0000707f9fbd48c3  pop r9
0000707f9fbd48c5  pop r8
0000707f9fbd48c7  pop rsi
0000707f9fbd48c8  pop rdi
0000707f9fbd48c9  pop rdx
0000707f9fbd48ca  pop rcx
0000707f9fbd48cb  pop rax
0000707f9fbd48cc  add rsp, 0x08
0000707f9fbd48d0  jmp 0x0000707F9FBD2E44
0000707f9fbd48d5  sub rsp, 0x08
0000707f9fbd48d9  push rax
0000707f9fbd48da  push rcx
0000707f9fbd48db  push rdx
0000707f9fbd48dc  push rdi
0000707f9fbd48dd  push rsi
0000707f9fbd48de  push r8
0000707f9fbd48e0  push r9
0000707f9fbd48e2  push r10
0000707f9fbd48e4  push r11
0000707f9fbd48e6  sub rsp, 0xF0
0000707f9fbd48ed  vmovaps [rsp], xmm0
0000707f9fbd48f2  vmovaps [rsp+0x10], xmm1
0000707f9fbd48f8  vmovaps [rsp+0x20], xmm2
0000707f9fbd48fe  vmovaps [rsp+0x30], xmm3
0000707f9fbd4904  vmovaps [rsp+0x40], xmm4
0000707f9fbd490a  vmovaps [rsp+0x50], xmm5
0000707f9fbd4910  vmovaps [rsp+0x60], xmm6
0000707f9fbd4916  vmovaps [rsp+0x70], xmm7
0000707f9fbd491c  vmovaps [rsp+0x80], xmm8
0000707f9fbd4925  vmovaps [rsp+0x90], xmm9
0000707f9fbd492e  vmovaps [rsp+0xA0], xmm11
0000707f9fbd4937  vmovaps [rsp+0xB0], xmm12
0000707f9fbd4940  vmovaps [rsp+0xC0], xmm13
0000707f9fbd4949  vmovaps [rsp+0xD0], xmm14
0000707f9fbd4952  vmovaps [rsp+0xE0], xmm15
0000707f9fbd495b  sub rsp, 0x40
0000707f9fbd495f  lea rdi, [rsp]
0000707f9fbd4963  lea rsi, [rsp+0x10]
0000707f9fbd4968  lea rdx, [rsp+0x20]
0000707f9fbd496d  lea rcx, [rsp+0x30]
0000707f9fbd4972  mov r8d, 0x00
0000707f9fbd4978  lea r9, [r15+0x3A8]
0000707f9fbd497f  movaps [rdi], xmm10
0000707f9fbd4983  movaps [rsi], xmm15
0000707f9fbd4987  movaps [rdx], xmm1
0000707f9fbd498a  movaps [rcx], xmm13
0000707f9fbd498e  mov rax, 0x5753922B7A50
0000707f9fbd4998  call rax
0000707f9fbd499a  movaps xmm10, [rsp]
0000707f9fbd499f  add rsp, 0x40
0000707f9fbd49a3  vmovaps xmm0, [rsp]
0000707f9fbd49a8  vmovaps xmm1, [rsp+0x10]
0000707f9fbd49ae  vmovaps xmm2, [rsp+0x20]
0000707f9fbd49b4  vmovaps xmm3, [rsp+0x30]
0000707f9fbd49ba  vmovaps xmm4, [rsp+0x40]
0000707f9fbd49c0  vmovaps xmm5, [rsp+0x50]
0000707f9fbd49c6  vmovaps xmm6, [rsp+0x60]
0000707f9fbd49cc  vmovaps xmm7, [rsp+0x70]
0000707f9fbd49d2  vmovaps xmm8, [rsp+0x80]
0000707f9fbd49db  vmovaps xmm9, [rsp+0x90]
0000707f9fbd49e4  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd49ed  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd49f6  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd49ff  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd4a08  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd4a11  add rsp, 0xF0
0000707f9fbd4a18  pop r11
0000707f9fbd4a1a  pop r10
0000707f9fbd4a1c  pop r9
0000707f9fbd4a1e  pop r8
0000707f9fbd4a20  pop rsi
0000707f9fbd4a21  pop rdi
0000707f9fbd4a22  pop rdx
0000707f9fbd4a23  pop rcx
0000707f9fbd4a24  pop rax
0000707f9fbd4a25  add rsp, 0x08
0000707f9fbd4a29  jmp 0x0000707F9FBD2E6D
0000707f9fbd4a2e  call 0x0000707F9F9FF430
0000707f9fbd4a33  jmp 0x0000707F9FBD2E8F
0000707f9fbd4a38  call 0x0000707F9FA0E760
0000707f9fbd4a3d  jmp 0x0000707F9FBD2E99
0000707f9fbd4a42  sub rsp, 0x08
0000707f9fbd4a46  push rax
0000707f9fbd4a47  push rcx
0000707f9fbd4a48  push rdx
0000707f9fbd4a49  push rdi
0000707f9fbd4a4a  push rsi
0000707f9fbd4a4b  push r8
0000707f9fbd4a4d  push r9
0000707f9fbd4a4f  push r10
0000707f9fbd4a51  push r11
0000707f9fbd4a53  sub rsp, 0xF0
0000707f9fbd4a5a  vmovaps [rsp], xmm0
0000707f9fbd4a5f  vmovaps [rsp+0x10], xmm1
0000707f9fbd4a65  vmovaps [rsp+0x20], xmm2
0000707f9fbd4a6b  vmovaps [rsp+0x30], xmm3
0000707f9fbd4a71  vmovaps [rsp+0x40], xmm4
0000707f9fbd4a77  vmovaps [rsp+0x50], xmm5
0000707f9fbd4a7d  vmovaps [rsp+0x60], xmm6
0000707f9fbd4a83  vmovaps [rsp+0x70], xmm7
0000707f9fbd4a89  vmovaps [rsp+0x80], xmm9
0000707f9fbd4a92  vmovaps [rsp+0x90], xmm10
0000707f9fbd4a9b  vmovaps [rsp+0xA0], xmm11
0000707f9fbd4aa4  vmovaps [rsp+0xB0], xmm12
0000707f9fbd4aad  vmovaps [rsp+0xC0], xmm13
0000707f9fbd4ab6  vmovaps [rsp+0xD0], xmm14
0000707f9fbd4abf  vmovaps [rsp+0xE0], xmm15
0000707f9fbd4ac8  sub rsp, 0x40
0000707f9fbd4acc  lea rdi, [rsp]
0000707f9fbd4ad0  lea rsi, [rsp+0x10]
0000707f9fbd4ad5  lea rdx, [rsp+0x20]
0000707f9fbd4ada  lea rcx, [rsp+0x30]
0000707f9fbd4adf  mov r8d, 0x00
0000707f9fbd4ae5  lea r9, [r15+0x3A8]
0000707f9fbd4aec  movaps [rdi], xmm8
0000707f9fbd4af0  movaps [rsi], xmm5
0000707f9fbd4af3  movaps [rdx], xmm9
0000707f9fbd4af7  movaps [rcx], xmm13
0000707f9fbd4afb  mov rax, 0x5753922B7A50
0000707f9fbd4b05  call rax
0000707f9fbd4b07  movaps xmm8, [rsp]
0000707f9fbd4b0c  add rsp, 0x40
0000707f9fbd4b10  vmovaps xmm0, [rsp]
0000707f9fbd4b15  vmovaps xmm1, [rsp+0x10]
0000707f9fbd4b1b  vmovaps xmm2, [rsp+0x20]
0000707f9fbd4b21  vmovaps xmm3, [rsp+0x30]
0000707f9fbd4b27  vmovaps xmm4, [rsp+0x40]
0000707f9fbd4b2d  vmovaps xmm5, [rsp+0x50]
0000707f9fbd4b33  vmovaps xmm6, [rsp+0x60]
0000707f9fbd4b39  vmovaps xmm7, [rsp+0x70]
0000707f9fbd4b3f  vmovaps xmm9, [rsp+0x80]
0000707f9fbd4b48  vmovaps xmm10, [rsp+0x90]
0000707f9fbd4b51  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd4b5a  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd4b63  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd4b6c  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd4b75  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd4b7e  add rsp, 0xF0
0000707f9fbd4b85  pop r11
0000707f9fbd4b87  pop r10
0000707f9fbd4b89  pop r9
0000707f9fbd4b8b  pop r8
0000707f9fbd4b8d  pop rsi
0000707f9fbd4b8e  pop rdi
0000707f9fbd4b8f  pop rdx
0000707f9fbd4b90  pop rcx
0000707f9fbd4b91  pop rax
0000707f9fbd4b92  add rsp, 0x08
0000707f9fbd4b96  jmp 0x0000707F9FBD2ED8
0000707f9fbd4b9b  sub rsp, 0x08
0000707f9fbd4b9f  push rax
0000707f9fbd4ba0  push rcx
0000707f9fbd4ba1  push rdx
0000707f9fbd4ba2  push rdi
0000707f9fbd4ba3  push rsi
0000707f9fbd4ba4  push r8
0000707f9fbd4ba6  push r9
0000707f9fbd4ba8  push r10
0000707f9fbd4baa  push r11
0000707f9fbd4bac  sub rsp, 0xF0
0000707f9fbd4bb3  vmovaps [rsp], xmm0
0000707f9fbd4bb8  vmovaps [rsp+0x10], xmm1
0000707f9fbd4bbe  vmovaps [rsp+0x20], xmm2
0000707f9fbd4bc4  vmovaps [rsp+0x30], xmm3
0000707f9fbd4bca  vmovaps [rsp+0x40], xmm4
0000707f9fbd4bd0  vmovaps [rsp+0x50], xmm5
0000707f9fbd4bd6  vmovaps [rsp+0x60], xmm6
0000707f9fbd4bdc  vmovaps [rsp+0x70], xmm7
0000707f9fbd4be2  vmovaps [rsp+0x80], xmm8
0000707f9fbd4beb  vmovaps [rsp+0x90], xmm10
0000707f9fbd4bf4  vmovaps [rsp+0xA0], xmm11
0000707f9fbd4bfd  vmovaps [rsp+0xB0], xmm12
0000707f9fbd4c06  vmovaps [rsp+0xC0], xmm13
0000707f9fbd4c0f  vmovaps [rsp+0xD0], xmm14
0000707f9fbd4c18  vmovaps [rsp+0xE0], xmm15
0000707f9fbd4c21  sub rsp, 0x40
0000707f9fbd4c25  lea rdi, [rsp]
0000707f9fbd4c29  lea rsi, [rsp+0x10]
0000707f9fbd4c2e  lea rdx, [rsp+0x20]
0000707f9fbd4c33  lea rcx, [rsp+0x30]
0000707f9fbd4c38  mov r8d, 0x00
0000707f9fbd4c3e  lea r9, [r15+0x3A8]
0000707f9fbd4c45  movaps [rdi], xmm9
0000707f9fbd4c49  movaps [rsi], xmm12
0000707f9fbd4c4d  movaps [rdx], xmm7
0000707f9fbd4c50  movaps [rcx], xmm13
0000707f9fbd4c54  mov rax, 0x5753922B7A50
0000707f9fbd4c5e  call rax
0000707f9fbd4c60  movaps xmm9, [rsp]
0000707f9fbd4c65  add rsp, 0x40
0000707f9fbd4c69  vmovaps xmm0, [rsp]
0000707f9fbd4c6e  vmovaps xmm1, [rsp+0x10]
0000707f9fbd4c74  vmovaps xmm2, [rsp+0x20]
0000707f9fbd4c7a  vmovaps xmm3, [rsp+0x30]
0000707f9fbd4c80  vmovaps xmm4, [rsp+0x40]
0000707f9fbd4c86  vmovaps xmm5, [rsp+0x50]
0000707f9fbd4c8c  vmovaps xmm6, [rsp+0x60]
0000707f9fbd4c92  vmovaps xmm7, [rsp+0x70]
0000707f9fbd4c98  vmovaps xmm8, [rsp+0x80]
0000707f9fbd4ca1  vmovaps xmm10, [rsp+0x90]
0000707f9fbd4caa  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd4cb3  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd4cbc  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd4cc5  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd4cce  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd4cd7  add rsp, 0xF0
0000707f9fbd4cde  pop r11
0000707f9fbd4ce0  pop r10
0000707f9fbd4ce2  pop r9
0000707f9fbd4ce4  pop r8
0000707f9fbd4ce6  pop rsi
0000707f9fbd4ce7  pop rdi
0000707f9fbd4ce8  pop rdx
0000707f9fbd4ce9  pop rcx
0000707f9fbd4cea  pop rax
0000707f9fbd4ceb  add rsp, 0x08
0000707f9fbd4cef  jmp 0x0000707F9FBD2F01
0000707f9fbd4cf4  sub rsp, 0x08
0000707f9fbd4cf8  push rax
0000707f9fbd4cf9  push rcx
0000707f9fbd4cfa  push rdx
0000707f9fbd4cfb  push rdi
0000707f9fbd4cfc  push rsi
0000707f9fbd4cfd  push r8
0000707f9fbd4cff  push r9
0000707f9fbd4d01  push r10
0000707f9fbd4d03  push r11
0000707f9fbd4d05  sub rsp, 0xF0
0000707f9fbd4d0c  vmovaps [rsp], xmm0
0000707f9fbd4d11  vmovaps [rsp+0x10], xmm1
0000707f9fbd4d17  vmovaps [rsp+0x20], xmm2
0000707f9fbd4d1d  vmovaps [rsp+0x30], xmm3
0000707f9fbd4d23  vmovaps [rsp+0x40], xmm4
0000707f9fbd4d29  vmovaps [rsp+0x50], xmm5
0000707f9fbd4d2f  vmovaps [rsp+0x60], xmm6
0000707f9fbd4d35  vmovaps [rsp+0x70], xmm7
0000707f9fbd4d3b  vmovaps [rsp+0x80], xmm8
0000707f9fbd4d44  vmovaps [rsp+0x90], xmm9
0000707f9fbd4d4d  vmovaps [rsp+0xA0], xmm10
0000707f9fbd4d56  vmovaps [rsp+0xB0], xmm11
0000707f9fbd4d5f  vmovaps [rsp+0xC0], xmm13
0000707f9fbd4d68  vmovaps [rsp+0xD0], xmm14
0000707f9fbd4d71  vmovaps [rsp+0xE0], xmm15
0000707f9fbd4d7a  sub rsp, 0x40
0000707f9fbd4d7e  lea rdi, [rsp]
0000707f9fbd4d82  lea rsi, [rsp+0x10]
0000707f9fbd4d87  lea rdx, [rsp+0x20]
0000707f9fbd4d8c  lea rcx, [rsp+0x30]
0000707f9fbd4d91  mov r8d, 0x00
0000707f9fbd4d97  lea r9, [r15+0x3A8]
0000707f9fbd4d9e  movaps [rdi], xmm12
0000707f9fbd4da2  movaps [rsi], xmm11
0000707f9fbd4da6  movaps [rdx], xmm6
0000707f9fbd4da9  movaps [rcx], xmm13
0000707f9fbd4dad  mov rax, 0x5753922B7A50
0000707f9fbd4db7  call rax
0000707f9fbd4db9  movaps xmm12, [rsp]
0000707f9fbd4dbe  add rsp, 0x40
0000707f9fbd4dc2  vmovaps xmm0, [rsp]
0000707f9fbd4dc7  vmovaps xmm1, [rsp+0x10]
0000707f9fbd4dcd  vmovaps xmm2, [rsp+0x20]
0000707f9fbd4dd3  vmovaps xmm3, [rsp+0x30]
0000707f9fbd4dd9  vmovaps xmm4, [rsp+0x40]
0000707f9fbd4ddf  vmovaps xmm5, [rsp+0x50]
0000707f9fbd4de5  vmovaps xmm6, [rsp+0x60]
0000707f9fbd4deb  vmovaps xmm7, [rsp+0x70]
0000707f9fbd4df1  vmovaps xmm8, [rsp+0x80]
0000707f9fbd4dfa  vmovaps xmm9, [rsp+0x90]
0000707f9fbd4e03  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd4e0c  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd4e15  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd4e1e  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd4e27  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd4e30  add rsp, 0xF0
0000707f9fbd4e37  pop r11
0000707f9fbd4e39  pop r10
0000707f9fbd4e3b  pop r9
0000707f9fbd4e3d  pop r8
0000707f9fbd4e3f  pop rsi
0000707f9fbd4e40  pop rdi
0000707f9fbd4e41  pop rdx
0000707f9fbd4e42  pop rcx
0000707f9fbd4e43  pop rax
0000707f9fbd4e44  add rsp, 0x08
0000707f9fbd4e48  jmp 0x0000707F9FBD2F2A
0000707f9fbd4e4d  sub rsp, 0x08
0000707f9fbd4e51  push rax
0000707f9fbd4e52  push rcx
0000707f9fbd4e53  push rdx
0000707f9fbd4e54  push rdi
0000707f9fbd4e55  push rsi
0000707f9fbd4e56  push r8
0000707f9fbd4e58  push r9
0000707f9fbd4e5a  push r10
0000707f9fbd4e5c  push r11
0000707f9fbd4e5e  sub rsp, 0xF0
0000707f9fbd4e65  vmovaps [rsp], xmm0
0000707f9fbd4e6a  vmovaps [rsp+0x10], xmm1
0000707f9fbd4e70  vmovaps [rsp+0x20], xmm2
0000707f9fbd4e76  vmovaps [rsp+0x30], xmm3
0000707f9fbd4e7c  vmovaps [rsp+0x40], xmm4
0000707f9fbd4e82  vmovaps [rsp+0x50], xmm5
0000707f9fbd4e88  vmovaps [rsp+0x60], xmm6
0000707f9fbd4e8e  vmovaps [rsp+0x70], xmm8
0000707f9fbd4e94  vmovaps [rsp+0x80], xmm9
0000707f9fbd4e9d  vmovaps [rsp+0x90], xmm10
0000707f9fbd4ea6  vmovaps [rsp+0xA0], xmm11
0000707f9fbd4eaf  vmovaps [rsp+0xB0], xmm12
0000707f9fbd4eb8  vmovaps [rsp+0xC0], xmm13
0000707f9fbd4ec1  vmovaps [rsp+0xD0], xmm14
0000707f9fbd4eca  vmovaps [rsp+0xE0], xmm15
0000707f9fbd4ed3  sub rsp, 0x40
0000707f9fbd4ed7  lea rdi, [rsp]
0000707f9fbd4edb  lea rsi, [rsp+0x10]
0000707f9fbd4ee0  lea rdx, [rsp+0x20]
0000707f9fbd4ee5  lea rcx, [rsp+0x30]
0000707f9fbd4eea  mov r8d, 0x00
0000707f9fbd4ef0  lea r9, [r15+0x3A8]
0000707f9fbd4ef7  movaps [rdi], xmm7
0000707f9fbd4efa  movaps [rsi], xmm10
0000707f9fbd4efe  movaps [rdx], xmm11
0000707f9fbd4f02  movaps [rcx], xmm13
0000707f9fbd4f06  mov rax, 0x5753922B7A50
0000707f9fbd4f10  call rax
0000707f9fbd4f12  movaps xmm7, [rsp]
0000707f9fbd4f16  add rsp, 0x40
0000707f9fbd4f1a  vmovaps xmm0, [rsp]
0000707f9fbd4f1f  vmovaps xmm1, [rsp+0x10]
0000707f9fbd4f25  vmovaps xmm2, [rsp+0x20]
0000707f9fbd4f2b  vmovaps xmm3, [rsp+0x30]
0000707f9fbd4f31  vmovaps xmm4, [rsp+0x40]
0000707f9fbd4f37  vmovaps xmm5, [rsp+0x50]
0000707f9fbd4f3d  vmovaps xmm6, [rsp+0x60]
0000707f9fbd4f43  vmovaps xmm8, [rsp+0x70]
0000707f9fbd4f49  vmovaps xmm9, [rsp+0x80]
0000707f9fbd4f52  vmovaps xmm10, [rsp+0x90]
0000707f9fbd4f5b  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd4f64  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd4f6d  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd4f76  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd4f7f  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd4f88  add rsp, 0xF0
0000707f9fbd4f8f  pop r11
0000707f9fbd4f91  pop r10
0000707f9fbd4f93  pop r9
0000707f9fbd4f95  pop r8
0000707f9fbd4f97  pop rsi
0000707f9fbd4f98  pop rdi
0000707f9fbd4f99  pop rdx
0000707f9fbd4f9a  pop rcx
0000707f9fbd4f9b  pop rax
0000707f9fbd4f9c  add rsp, 0x08
0000707f9fbd4fa0  jmp 0x0000707F9FBD2F58
0000707f9fbd4fa5  call 0x0000707F9FA0C260
0000707f9fbd4faa  jmp 0x0000707F9FBD2F62
0000707f9fbd4faf  call 0x0000707F9FA09D70
0000707f9fbd4fb4  jmp 0x0000707F9FBD2F6C
0000707f9fbd4fb9  sub rsp, 0x08
0000707f9fbd4fbd  push rax
0000707f9fbd4fbe  push rcx
0000707f9fbd4fbf  push rdx
0000707f9fbd4fc0  push rdi
0000707f9fbd4fc1  push rsi
0000707f9fbd4fc2  push r8
0000707f9fbd4fc4  push r9
0000707f9fbd4fc6  push r10
0000707f9fbd4fc8  push r11
0000707f9fbd4fca  sub rsp, 0xF0
0000707f9fbd4fd1  vmovaps [rsp], xmm0
0000707f9fbd4fd6  vmovaps [rsp+0x10], xmm1
0000707f9fbd4fdc  vmovaps [rsp+0x20], xmm2
0000707f9fbd4fe2  vmovaps [rsp+0x30], xmm3
0000707f9fbd4fe8  vmovaps [rsp+0x40], xmm4
0000707f9fbd4fee  vmovaps [rsp+0x50], xmm5
0000707f9fbd4ff4  vmovaps [rsp+0x60], xmm7
0000707f9fbd4ffa  vmovaps [rsp+0x70], xmm8
0000707f9fbd5000  vmovaps [rsp+0x80], xmm9
0000707f9fbd5009  vmovaps [rsp+0x90], xmm10
0000707f9fbd5012  vmovaps [rsp+0xA0], xmm11
0000707f9fbd501b  vmovaps [rsp+0xB0], xmm12
0000707f9fbd5024  vmovaps [rsp+0xC0], xmm13
0000707f9fbd502d  vmovaps [rsp+0xD0], xmm14
0000707f9fbd5036  vmovaps [rsp+0xE0], xmm15
0000707f9fbd503f  sub rsp, 0x40
0000707f9fbd5043  lea rdi, [rsp]
0000707f9fbd5047  lea rsi, [rsp+0x10]
0000707f9fbd504c  lea rdx, [rsp+0x20]
0000707f9fbd5051  lea rcx, [rsp+0x30]
0000707f9fbd5056  mov r8d, 0x00
0000707f9fbd505c  lea r9, [r15+0x3A8]
0000707f9fbd5063  movaps [rdi], xmm6
0000707f9fbd5066  movaps [rsi], xmm8
0000707f9fbd506a  movaps [rdx], xmm15
0000707f9fbd506e  movaps [rcx], xmm10
0000707f9fbd5072  mov rax, 0x5753922B7A50
0000707f9fbd507c  call rax
0000707f9fbd507e  movaps xmm6, [rsp]
0000707f9fbd5082  add rsp, 0x40
0000707f9fbd5086  vmovaps xmm0, [rsp]
0000707f9fbd508b  vmovaps xmm1, [rsp+0x10]
0000707f9fbd5091  vmovaps xmm2, [rsp+0x20]
0000707f9fbd5097  vmovaps xmm3, [rsp+0x30]
0000707f9fbd509d  vmovaps xmm4, [rsp+0x40]
0000707f9fbd50a3  vmovaps xmm5, [rsp+0x50]
0000707f9fbd50a9  vmovaps xmm7, [rsp+0x60]
0000707f9fbd50af  vmovaps xmm8, [rsp+0x70]
0000707f9fbd50b5  vmovaps xmm9, [rsp+0x80]
0000707f9fbd50be  vmovaps xmm10, [rsp+0x90]
0000707f9fbd50c7  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd50d0  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd50d9  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd50e2  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd50eb  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd50f4  add rsp, 0xF0
0000707f9fbd50fb  pop r11
0000707f9fbd50fd  pop r10
0000707f9fbd50ff  pop r9
0000707f9fbd5101  pop r8
0000707f9fbd5103  pop rsi
0000707f9fbd5104  pop rdi
0000707f9fbd5105  pop rdx
0000707f9fbd5106  pop rcx
0000707f9fbd5107  pop rax
0000707f9fbd5108  add rsp, 0x08
0000707f9fbd510c  jmp 0x0000707F9FBD2FA4
0000707f9fbd5111  sub rsp, 0x08
0000707f9fbd5115  push rax
0000707f9fbd5116  push rcx
0000707f9fbd5117  push rdx
0000707f9fbd5118  push rdi
0000707f9fbd5119  push rsi
0000707f9fbd511a  push r8
0000707f9fbd511c  push r9
0000707f9fbd511e  push r10
0000707f9fbd5120  push r11
0000707f9fbd5122  sub rsp, 0xF0
0000707f9fbd5129  vmovaps [rsp], xmm0
0000707f9fbd512e  vmovaps [rsp+0x10], xmm1
0000707f9fbd5134  vmovaps [rsp+0x20], xmm2
0000707f9fbd513a  vmovaps [rsp+0x30], xmm3
0000707f9fbd5140  vmovaps [rsp+0x40], xmm4
0000707f9fbd5146  vmovaps [rsp+0x50], xmm5
0000707f9fbd514c  vmovaps [rsp+0x60], xmm6
0000707f9fbd5152  vmovaps [rsp+0x70], xmm7
0000707f9fbd5158  vmovaps [rsp+0x80], xmm8
0000707f9fbd5161  vmovaps [rsp+0x90], xmm9
0000707f9fbd516a  vmovaps [rsp+0xA0], xmm11
0000707f9fbd5173  vmovaps [rsp+0xB0], xmm12
0000707f9fbd517c  vmovaps [rsp+0xC0], xmm13
0000707f9fbd5185  vmovaps [rsp+0xD0], xmm14
0000707f9fbd518e  vmovaps [rsp+0xE0], xmm15
0000707f9fbd5197  sub rsp, 0x40
0000707f9fbd519b  lea rdi, [rsp]
0000707f9fbd519f  lea rsi, [rsp+0x10]
0000707f9fbd51a4  lea rdx, [rsp+0x20]
0000707f9fbd51a9  lea rcx, [rsp+0x30]
0000707f9fbd51ae  mov r8d, 0x00
0000707f9fbd51b4  lea r9, [r15+0x3A8]
0000707f9fbd51bb  movaps [rdi], xmm10
0000707f9fbd51bf  movaps [rsi], xmm9
0000707f9fbd51c3  movaps [rdx], xmm13
0000707f9fbd51c7  movaps [rcx], xmm15
0000707f9fbd51cb  mov rax, 0x5753922B7A50
0000707f9fbd51d5  call rax
0000707f9fbd51d7  movaps xmm10, [rsp]
0000707f9fbd51dc  add rsp, 0x40
0000707f9fbd51e0  vmovaps xmm0, [rsp]
0000707f9fbd51e5  vmovaps xmm1, [rsp+0x10]
0000707f9fbd51eb  vmovaps xmm2, [rsp+0x20]
0000707f9fbd51f1  vmovaps xmm3, [rsp+0x30]
0000707f9fbd51f7  vmovaps xmm4, [rsp+0x40]
0000707f9fbd51fd  vmovaps xmm5, [rsp+0x50]
0000707f9fbd5203  vmovaps xmm6, [rsp+0x60]
0000707f9fbd5209  vmovaps xmm7, [rsp+0x70]
0000707f9fbd520f  vmovaps xmm8, [rsp+0x80]
0000707f9fbd5218  vmovaps xmm9, [rsp+0x90]
0000707f9fbd5221  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd522a  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd5233  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd523c  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd5245  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd524e  add rsp, 0xF0
0000707f9fbd5255  pop r11
0000707f9fbd5257  pop r10
0000707f9fbd5259  pop r9
0000707f9fbd525b  pop r8
0000707f9fbd525d  pop rsi
0000707f9fbd525e  pop rdi
0000707f9fbd525f  pop rdx
0000707f9fbd5260  pop rcx
0000707f9fbd5261  pop rax
0000707f9fbd5262  add rsp, 0x08
0000707f9fbd5266  jmp 0x0000707F9FBD2FCD
0000707f9fbd526b  sub rsp, 0x08
0000707f9fbd526f  push rax
0000707f9fbd5270  push rcx
0000707f9fbd5271  push rdx
0000707f9fbd5272  push rdi
0000707f9fbd5273  push rsi
0000707f9fbd5274  push r8
0000707f9fbd5276  push r9
0000707f9fbd5278  push r10
0000707f9fbd527a  push r11
0000707f9fbd527c  sub rsp, 0xF0
0000707f9fbd5283  vmovaps [rsp], xmm0
0000707f9fbd5288  vmovaps [rsp+0x10], xmm1
0000707f9fbd528e  vmovaps [rsp+0x20], xmm2
0000707f9fbd5294  vmovaps [rsp+0x30], xmm3
0000707f9fbd529a  vmovaps [rsp+0x40], xmm4
0000707f9fbd52a0  vmovaps [rsp+0x50], xmm5
0000707f9fbd52a6  vmovaps [rsp+0x60], xmm6
0000707f9fbd52ac  vmovaps [rsp+0x70], xmm7
0000707f9fbd52b2  vmovaps [rsp+0x80], xmm8
0000707f9fbd52bb  vmovaps [rsp+0x90], xmm9
0000707f9fbd52c4  vmovaps [rsp+0xA0], xmm10
0000707f9fbd52cd  vmovaps [rsp+0xB0], xmm11
0000707f9fbd52d6  vmovaps [rsp+0xC0], xmm12
0000707f9fbd52df  vmovaps [rsp+0xD0], xmm14
0000707f9fbd52e8  vmovaps [rsp+0xE0], xmm15
0000707f9fbd52f1  sub rsp, 0x40
0000707f9fbd52f5  lea rdi, [rsp]
0000707f9fbd52f9  lea rsi, [rsp+0x10]
0000707f9fbd52fe  lea rdx, [rsp+0x20]
0000707f9fbd5303  lea rcx, [rsp+0x30]
0000707f9fbd5308  mov r8d, 0x00
0000707f9fbd530e  lea r9, [r15+0x3A8]
0000707f9fbd5315  movaps [rdi], xmm13
0000707f9fbd5319  movaps [rsi], xmm12
0000707f9fbd531d  movaps [rdx], xmm4
0000707f9fbd5320  movaps [rcx], xmm15
0000707f9fbd5324  mov rax, 0x5753922B7A50
0000707f9fbd532e  call rax
0000707f9fbd5330  movaps xmm13, [rsp]
0000707f9fbd5335  add rsp, 0x40
0000707f9fbd5339  vmovaps xmm0, [rsp]
0000707f9fbd533e  vmovaps xmm1, [rsp+0x10]
0000707f9fbd5344  vmovaps xmm2, [rsp+0x20]
0000707f9fbd534a  vmovaps xmm3, [rsp+0x30]
0000707f9fbd5350  vmovaps xmm4, [rsp+0x40]
0000707f9fbd5356  vmovaps xmm5, [rsp+0x50]
0000707f9fbd535c  vmovaps xmm6, [rsp+0x60]
0000707f9fbd5362  vmovaps xmm7, [rsp+0x70]
0000707f9fbd5368  vmovaps xmm8, [rsp+0x80]
0000707f9fbd5371  vmovaps xmm9, [rsp+0x90]
0000707f9fbd537a  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd5383  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd538c  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd5395  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd539e  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd53a7  add rsp, 0xF0
0000707f9fbd53ae  pop r11
0000707f9fbd53b0  pop r10
0000707f9fbd53b2  pop r9
0000707f9fbd53b4  pop r8
0000707f9fbd53b6  pop rsi
0000707f9fbd53b7  pop rdi
0000707f9fbd53b8  pop rdx
0000707f9fbd53b9  pop rcx
0000707f9fbd53ba  pop rax
0000707f9fbd53bb  add rsp, 0x08
0000707f9fbd53bf  jmp 0x0000707F9FBD2FF6
0000707f9fbd53c4  sub rsp, 0x08
0000707f9fbd53c8  push rax
0000707f9fbd53c9  push rcx
0000707f9fbd53ca  push rdx
0000707f9fbd53cb  push rdi
0000707f9fbd53cc  push rsi
0000707f9fbd53cd  push r8
0000707f9fbd53cf  push r9
0000707f9fbd53d1  push r10
0000707f9fbd53d3  push r11
0000707f9fbd53d5  sub rsp, 0xF0
0000707f9fbd53dc  vmovaps [rsp], xmm0
0000707f9fbd53e1  vmovaps [rsp+0x10], xmm1
0000707f9fbd53e7  vmovaps [rsp+0x20], xmm2
0000707f9fbd53ed  vmovaps [rsp+0x30], xmm3
0000707f9fbd53f3  vmovaps [rsp+0x40], xmm4
0000707f9fbd53f9  vmovaps [rsp+0x50], xmm5
0000707f9fbd53ff  vmovaps [rsp+0x60], xmm6
0000707f9fbd5405  vmovaps [rsp+0x70], xmm7
0000707f9fbd540b  vmovaps [rsp+0x80], xmm8
0000707f9fbd5414  vmovaps [rsp+0x90], xmm9
0000707f9fbd541d  vmovaps [rsp+0xA0], xmm10
0000707f9fbd5426  vmovaps [rsp+0xB0], xmm11
0000707f9fbd542f  vmovaps [rsp+0xC0], xmm13
0000707f9fbd5438  vmovaps [rsp+0xD0], xmm14
0000707f9fbd5441  vmovaps [rsp+0xE0], xmm15
0000707f9fbd544a  sub rsp, 0x40
0000707f9fbd544e  lea rdi, [rsp]
0000707f9fbd5452  lea rsi, [rsp+0x10]
0000707f9fbd5457  lea rdx, [rsp+0x20]
0000707f9fbd545c  lea rcx, [rsp+0x30]
0000707f9fbd5461  mov r8d, 0x00
0000707f9fbd5467  lea r9, [r15+0x3A8]
0000707f9fbd546e  movaps [rdi], xmm12
0000707f9fbd5472  movaps [rsi], xmm7
0000707f9fbd5475  movaps [rdx], xmm1
0000707f9fbd5478  movaps [rcx], xmm15
0000707f9fbd547c  mov rax, 0x5753922B7A50
0000707f9fbd5486  call rax
0000707f9fbd5488  movaps xmm12, [rsp]
0000707f9fbd548d  add rsp, 0x40
0000707f9fbd5491  vmovaps xmm0, [rsp]
0000707f9fbd5496  vmovaps xmm1, [rsp+0x10]
0000707f9fbd549c  vmovaps xmm2, [rsp+0x20]
0000707f9fbd54a2  vmovaps xmm3, [rsp+0x30]
0000707f9fbd54a8  vmovaps xmm4, [rsp+0x40]
0000707f9fbd54ae  vmovaps xmm5, [rsp+0x50]
0000707f9fbd54b4  vmovaps xmm6, [rsp+0x60]
0000707f9fbd54ba  vmovaps xmm7, [rsp+0x70]
0000707f9fbd54c0  vmovaps xmm8, [rsp+0x80]
0000707f9fbd54c9  vmovaps xmm9, [rsp+0x90]
0000707f9fbd54d2  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd54db  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd54e4  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd54ed  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd54f6  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd54ff  add rsp, 0xF0
0000707f9fbd5506  pop r11
0000707f9fbd5508  pop r10
0000707f9fbd550a  pop r9
0000707f9fbd550c  pop r8
0000707f9fbd550e  pop rsi
0000707f9fbd550f  pop rdi
0000707f9fbd5510  pop rdx
0000707f9fbd5511  pop rcx
0000707f9fbd5512  pop rax
0000707f9fbd5513  add rsp, 0x08
0000707f9fbd5517  jmp 0x0000707F9FBD301F
0000707f9fbd551c  call 0x0000707F9F9FF430
0000707f9fbd5521  jmp 0x0000707F9FBD3029
0000707f9fbd5526  call 0x0000707F9FA0E760
0000707f9fbd552b  jmp 0x0000707F9FBD3033
0000707f9fbd5530  sub rsp, 0x08
0000707f9fbd5534  push rax
0000707f9fbd5535  push rcx
0000707f9fbd5536  push rdx
0000707f9fbd5537  push rdi
0000707f9fbd5538  push rsi
0000707f9fbd5539  push r8
0000707f9fbd553b  push r9
0000707f9fbd553d  push r10
0000707f9fbd553f  push r11
0000707f9fbd5541  sub rsp, 0xF0
0000707f9fbd5548  vmovaps [rsp], xmm0
0000707f9fbd554d  vmovaps [rsp+0x10], xmm1
0000707f9fbd5553  vmovaps [rsp+0x20], xmm2
0000707f9fbd5559  vmovaps [rsp+0x30], xmm3
0000707f9fbd555f  vmovaps [rsp+0x40], xmm4
0000707f9fbd5565  vmovaps [rsp+0x50], xmm5
0000707f9fbd556b  vmovaps [rsp+0x60], xmm6
0000707f9fbd5571  vmovaps [rsp+0x70], xmm8
0000707f9fbd5577  vmovaps [rsp+0x80], xmm9
0000707f9fbd5580  vmovaps [rsp+0x90], xmm10
0000707f9fbd5589  vmovaps [rsp+0xA0], xmm11
0000707f9fbd5592  vmovaps [rsp+0xB0], xmm12
0000707f9fbd559b  vmovaps [rsp+0xC0], xmm13
0000707f9fbd55a4  vmovaps [rsp+0xD0], xmm14
0000707f9fbd55ad  vmovaps [rsp+0xE0], xmm15
0000707f9fbd55b6  sub rsp, 0x40
0000707f9fbd55ba  lea rdi, [rsp]
0000707f9fbd55be  lea rsi, [rsp+0x10]
0000707f9fbd55c3  lea rdx, [rsp+0x20]
0000707f9fbd55c8  lea rcx, [rsp+0x30]
0000707f9fbd55cd  mov r8d, 0x00
0000707f9fbd55d3  lea r9, [r15+0x3A8]
0000707f9fbd55da  movaps [rdi], xmm7
0000707f9fbd55dd  movaps [rsi], xmm6
0000707f9fbd55e0  movaps [rdx], xmm8
0000707f9fbd55e4  movaps [rcx], xmm9
0000707f9fbd55e8  mov rax, 0x5753922B7A50
0000707f9fbd55f2  call rax
0000707f9fbd55f4  movaps xmm7, [rsp]
0000707f9fbd55f8  add rsp, 0x40
0000707f9fbd55fc  vmovaps xmm0, [rsp]
0000707f9fbd5601  vmovaps xmm1, [rsp+0x10]
0000707f9fbd5607  vmovaps xmm2, [rsp+0x20]
0000707f9fbd560d  vmovaps xmm3, [rsp+0x30]
0000707f9fbd5613  vmovaps xmm4, [rsp+0x40]
0000707f9fbd5619  vmovaps xmm5, [rsp+0x50]
0000707f9fbd561f  vmovaps xmm6, [rsp+0x60]
0000707f9fbd5625  vmovaps xmm8, [rsp+0x70]
0000707f9fbd562b  vmovaps xmm9, [rsp+0x80]
0000707f9fbd5634  vmovaps xmm10, [rsp+0x90]
0000707f9fbd563d  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd5646  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd564f  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd5658  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd5661  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd566a  add rsp, 0xF0
0000707f9fbd5671  pop r11
0000707f9fbd5673  pop r10
0000707f9fbd5675  pop r9
0000707f9fbd5677  pop r8
0000707f9fbd5679  pop rsi
0000707f9fbd567a  pop rdi
0000707f9fbd567b  pop rdx
0000707f9fbd567c  pop rcx
0000707f9fbd567d  pop rax
0000707f9fbd567e  add rsp, 0x08
0000707f9fbd5682  jmp 0x0000707F9FBD305D
0000707f9fbd5687  sub rsp, 0x08
0000707f9fbd568b  push rax
0000707f9fbd568c  push rcx
0000707f9fbd568d  push rdx
0000707f9fbd568e  push rdi
0000707f9fbd568f  push rsi
0000707f9fbd5690  push r8
0000707f9fbd5692  push r9
0000707f9fbd5694  push r10
0000707f9fbd5696  push r11
0000707f9fbd5698  sub rsp, 0xF0
0000707f9fbd569f  vmovaps [rsp], xmm0
0000707f9fbd56a4  vmovaps [rsp+0x10], xmm1
0000707f9fbd56aa  vmovaps [rsp+0x20], xmm2
0000707f9fbd56b0  vmovaps [rsp+0x30], xmm3
0000707f9fbd56b6  vmovaps [rsp+0x40], xmm4
0000707f9fbd56bc  vmovaps [rsp+0x50], xmm5
0000707f9fbd56c2  vmovaps [rsp+0x60], xmm6
0000707f9fbd56c8  vmovaps [rsp+0x70], xmm7
0000707f9fbd56ce  vmovaps [rsp+0x80], xmm9
0000707f9fbd56d7  vmovaps [rsp+0x90], xmm10
0000707f9fbd56e0  vmovaps [rsp+0xA0], xmm11
0000707f9fbd56e9  vmovaps [rsp+0xB0], xmm12
0000707f9fbd56f2  vmovaps [rsp+0xC0], xmm13
0000707f9fbd56fb  vmovaps [rsp+0xD0], xmm14
0000707f9fbd5704  vmovaps [rsp+0xE0], xmm15
0000707f9fbd570d  sub rsp, 0x40
0000707f9fbd5711  lea rdi, [rsp]
0000707f9fbd5715  lea rsi, [rsp+0x10]
0000707f9fbd571a  lea rdx, [rsp+0x20]
0000707f9fbd571f  lea rcx, [rsp+0x30]
0000707f9fbd5724  mov r8d, 0x00
0000707f9fbd572a  lea r9, [r15+0x3A8]
0000707f9fbd5731  movaps [rdi], xmm8
0000707f9fbd5735  movaps [rsi], xmm10
0000707f9fbd5739  movaps [rdx], xmm14
0000707f9fbd573d  movaps [rcx], xmm9
0000707f9fbd5741  mov rax, 0x5753922B7A50
0000707f9fbd574b  call rax
0000707f9fbd574d  movaps xmm8, [rsp]
0000707f9fbd5752  add rsp, 0x40
0000707f9fbd5756  vmovaps xmm0, [rsp]
0000707f9fbd575b  vmovaps xmm1, [rsp+0x10]
0000707f9fbd5761  vmovaps xmm2, [rsp+0x20]
0000707f9fbd5767  vmovaps xmm3, [rsp+0x30]
0000707f9fbd576d  vmovaps xmm4, [rsp+0x40]
0000707f9fbd5773  vmovaps xmm5, [rsp+0x50]
0000707f9fbd5779  vmovaps xmm6, [rsp+0x60]
0000707f9fbd577f  vmovaps xmm7, [rsp+0x70]
0000707f9fbd5785  vmovaps xmm9, [rsp+0x80]
0000707f9fbd578e  vmovaps xmm10, [rsp+0x90]
0000707f9fbd5797  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd57a0  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd57a9  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd57b2  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd57bb  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd57c4  add rsp, 0xF0
0000707f9fbd57cb  pop r11
0000707f9fbd57cd  pop r10
0000707f9fbd57cf  pop r9
0000707f9fbd57d1  pop r8
0000707f9fbd57d3  pop rsi
0000707f9fbd57d4  pop rdi
0000707f9fbd57d5  pop rdx
0000707f9fbd57d6  pop rcx
0000707f9fbd57d7  pop rax
0000707f9fbd57d8  add rsp, 0x08
0000707f9fbd57dc  jmp 0x0000707F9FBD3083
0000707f9fbd57e1  sub rsp, 0x08
0000707f9fbd57e5  push rax
0000707f9fbd57e6  push rcx
0000707f9fbd57e7  push rdx
0000707f9fbd57e8  push rdi
0000707f9fbd57e9  push rsi
0000707f9fbd57ea  push r8
0000707f9fbd57ec  push r9
0000707f9fbd57ee  push r10
0000707f9fbd57f0  push r11
0000707f9fbd57f2  sub rsp, 0xF0
0000707f9fbd57f9  vmovaps [rsp], xmm0
0000707f9fbd57fe  vmovaps [rsp+0x10], xmm1
0000707f9fbd5804  vmovaps [rsp+0x20], xmm2
0000707f9fbd580a  vmovaps [rsp+0x30], xmm3
0000707f9fbd5810  vmovaps [rsp+0x40], xmm4
0000707f9fbd5816  vmovaps [rsp+0x50], xmm5
0000707f9fbd581c  vmovaps [rsp+0x60], xmm6
0000707f9fbd5822  vmovaps [rsp+0x70], xmm7
0000707f9fbd5828  vmovaps [rsp+0x80], xmm8
0000707f9fbd5831  vmovaps [rsp+0x90], xmm9
0000707f9fbd583a  vmovaps [rsp+0xA0], xmm11
0000707f9fbd5843  vmovaps [rsp+0xB0], xmm12
0000707f9fbd584c  vmovaps [rsp+0xC0], xmm13
0000707f9fbd5855  vmovaps [rsp+0xD0], xmm14
0000707f9fbd585e  vmovaps [rsp+0xE0], xmm15
0000707f9fbd5867  sub rsp, 0x40
0000707f9fbd586b  lea rdi, [rsp]
0000707f9fbd586f  lea rsi, [rsp+0x10]
0000707f9fbd5874  lea rdx, [rsp+0x20]
0000707f9fbd5879  lea rcx, [rsp+0x30]
0000707f9fbd587e  mov r8d, 0x00
0000707f9fbd5884  lea r9, [r15+0x3A8]
0000707f9fbd588b  movaps [rdi], xmm10
0000707f9fbd588f  movaps [rsi], xmm13
0000707f9fbd5893  movaps [rdx], xmm11
0000707f9fbd5897  movaps [rcx], xmm14
0000707f9fbd589b  mov rax, 0x5753922B7A50
0000707f9fbd58a5  call rax
0000707f9fbd58a7  movaps xmm10, [rsp]
0000707f9fbd58ac  add rsp, 0x40
0000707f9fbd58b0  vmovaps xmm0, [rsp]
0000707f9fbd58b5  vmovaps xmm1, [rsp+0x10]
0000707f9fbd58bb  vmovaps xmm2, [rsp+0x20]
0000707f9fbd58c1  vmovaps xmm3, [rsp+0x30]
0000707f9fbd58c7  vmovaps xmm4, [rsp+0x40]
0000707f9fbd58cd  vmovaps xmm5, [rsp+0x50]
0000707f9fbd58d3  vmovaps xmm6, [rsp+0x60]
0000707f9fbd58d9  vmovaps xmm7, [rsp+0x70]
0000707f9fbd58df  vmovaps xmm8, [rsp+0x80]
0000707f9fbd58e8  vmovaps xmm9, [rsp+0x90]
0000707f9fbd58f1  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd58fa  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd5903  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd590c  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd5915  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd591e  add rsp, 0xF0
0000707f9fbd5925  pop r11
0000707f9fbd5927  pop r10
0000707f9fbd5929  pop r9
0000707f9fbd592b  pop r8
0000707f9fbd592d  pop rsi
0000707f9fbd592e  pop rdi
0000707f9fbd592f  pop rdx
0000707f9fbd5930  pop rcx
0000707f9fbd5931  pop rax
0000707f9fbd5932  add rsp, 0x08
0000707f9fbd5936  jmp 0x0000707F9FBD30A9
0000707f9fbd593b  sub rsp, 0x08
0000707f9fbd593f  push rax
0000707f9fbd5940  push rcx
0000707f9fbd5941  push rdx
0000707f9fbd5942  push rdi
0000707f9fbd5943  push rsi
0000707f9fbd5944  push r8
0000707f9fbd5946  push r9
0000707f9fbd5948  push r10
0000707f9fbd594a  push r11
0000707f9fbd594c  sub rsp, 0xF0
0000707f9fbd5953  vmovaps [rsp], xmm0
0000707f9fbd5958  vmovaps [rsp+0x10], xmm1
0000707f9fbd595e  vmovaps [rsp+0x20], xmm2
0000707f9fbd5964  vmovaps [rsp+0x30], xmm3
0000707f9fbd596a  vmovaps [rsp+0x40], xmm4
0000707f9fbd5970  vmovaps [rsp+0x50], xmm5
0000707f9fbd5976  vmovaps [rsp+0x60], xmm6
0000707f9fbd597c  vmovaps [rsp+0x70], xmm7
0000707f9fbd5982  vmovaps [rsp+0x80], xmm8
0000707f9fbd598b  vmovaps [rsp+0x90], xmm9
0000707f9fbd5994  vmovaps [rsp+0xA0], xmm10
0000707f9fbd599d  vmovaps [rsp+0xB0], xmm11
0000707f9fbd59a6  vmovaps [rsp+0xC0], xmm12
0000707f9fbd59af  vmovaps [rsp+0xD0], xmm14
0000707f9fbd59b8  vmovaps [rsp+0xE0], xmm15
0000707f9fbd59c1  sub rsp, 0x40
0000707f9fbd59c5  lea rdi, [rsp]
0000707f9fbd59c9  lea rsi, [rsp+0x10]
0000707f9fbd59ce  lea rdx, [rsp+0x20]
0000707f9fbd59d3  lea rcx, [rsp+0x30]
0000707f9fbd59d8  mov r8d, 0x00
0000707f9fbd59de  lea r9, [r15+0x3A8]
0000707f9fbd59e5  movaps [rdi], xmm13
0000707f9fbd59e9  movaps [rsi], xmm12
0000707f9fbd59ed  movaps [rdx], xmm15
0000707f9fbd59f1  movaps [rcx], xmm14
0000707f9fbd59f5  mov rax, 0x5753922B7A50
0000707f9fbd59ff  call rax
0000707f9fbd5a01  movaps xmm13, [rsp]
0000707f9fbd5a06  add rsp, 0x40
0000707f9fbd5a0a  vmovaps xmm0, [rsp]
0000707f9fbd5a0f  vmovaps xmm1, [rsp+0x10]
0000707f9fbd5a15  vmovaps xmm2, [rsp+0x20]
0000707f9fbd5a1b  vmovaps xmm3, [rsp+0x30]
0000707f9fbd5a21  vmovaps xmm4, [rsp+0x40]
0000707f9fbd5a27  vmovaps xmm5, [rsp+0x50]
0000707f9fbd5a2d  vmovaps xmm6, [rsp+0x60]
0000707f9fbd5a33  vmovaps xmm7, [rsp+0x70]
0000707f9fbd5a39  vmovaps xmm8, [rsp+0x80]
0000707f9fbd5a42  vmovaps xmm9, [rsp+0x90]
0000707f9fbd5a4b  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd5a54  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd5a5d  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd5a66  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd5a6f  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd5a78  add rsp, 0xF0
0000707f9fbd5a7f  pop r11
0000707f9fbd5a81  pop r10
0000707f9fbd5a83  pop r9
0000707f9fbd5a85  pop r8
0000707f9fbd5a87  pop rsi
0000707f9fbd5a88  pop rdi
0000707f9fbd5a89  pop rdx
0000707f9fbd5a8a  pop rcx
0000707f9fbd5a8b  pop rax
0000707f9fbd5a8c  add rsp, 0x08
0000707f9fbd5a90  jmp 0x0000707F9FBD30CF
0000707f9fbd5a95  call 0x0000707F9FA0E760
0000707f9fbd5a9a  jmp 0x0000707F9FBD30DC
0000707f9fbd5a9f  call 0x0000707F9FA0D4E0
0000707f9fbd5aa4  jmp 0x0000707F9FBD30E9
0000707f9fbd5aa9  sub rsp, 0x08
0000707f9fbd5aad  push rax
0000707f9fbd5aae  push rcx
0000707f9fbd5aaf  push rdx
0000707f9fbd5ab0  push rdi
0000707f9fbd5ab1  push rsi
0000707f9fbd5ab2  push r8
0000707f9fbd5ab4  push r9
0000707f9fbd5ab6  push r10
0000707f9fbd5ab8  push r11
0000707f9fbd5aba  sub rsp, 0xF0
0000707f9fbd5ac1  vmovaps [rsp], xmm0
0000707f9fbd5ac6  vmovaps [rsp+0x10], xmm1
0000707f9fbd5acc  vmovaps [rsp+0x20], xmm2
0000707f9fbd5ad2  vmovaps [rsp+0x30], xmm3
0000707f9fbd5ad8  vmovaps [rsp+0x40], xmm4
0000707f9fbd5ade  vmovaps [rsp+0x50], xmm5
0000707f9fbd5ae4  vmovaps [rsp+0x60], xmm6
0000707f9fbd5aea  vmovaps [rsp+0x70], xmm7
0000707f9fbd5af0  vmovaps [rsp+0x80], xmm8
0000707f9fbd5af9  vmovaps [rsp+0x90], xmm9
0000707f9fbd5b02  vmovaps [rsp+0xA0], xmm10
0000707f9fbd5b0b  vmovaps [rsp+0xB0], xmm12
0000707f9fbd5b14  vmovaps [rsp+0xC0], xmm13
0000707f9fbd5b1d  vmovaps [rsp+0xD0], xmm14
0000707f9fbd5b26  vmovaps [rsp+0xE0], xmm15
0000707f9fbd5b2f  sub rsp, 0x40
0000707f9fbd5b33  lea rdi, [rsp]
0000707f9fbd5b37  lea rsi, [rsp+0x10]
0000707f9fbd5b3c  lea rdx, [rsp+0x20]
0000707f9fbd5b41  lea rcx, [rsp+0x30]
0000707f9fbd5b46  mov r8d, 0x00
0000707f9fbd5b4c  lea r9, [r15+0x3A8]
0000707f9fbd5b53  movaps [rdi], xmm11
0000707f9fbd5b57  movaps [rsi], xmm7
0000707f9fbd5b5a  movaps [rdx], xmm1
0000707f9fbd5b5d  movaps [rcx], xmm12
0000707f9fbd5b61  mov rax, 0x5753922B7A50
0000707f9fbd5b6b  call rax
0000707f9fbd5b6d  movaps xmm11, [rsp]
0000707f9fbd5b72  add rsp, 0x40
0000707f9fbd5b76  vmovaps xmm0, [rsp]
0000707f9fbd5b7b  vmovaps xmm1, [rsp+0x10]
0000707f9fbd5b81  vmovaps xmm2, [rsp+0x20]
0000707f9fbd5b87  vmovaps xmm3, [rsp+0x30]
0000707f9fbd5b8d  vmovaps xmm4, [rsp+0x40]
0000707f9fbd5b93  vmovaps xmm5, [rsp+0x50]
0000707f9fbd5b99  vmovaps xmm6, [rsp+0x60]
0000707f9fbd5b9f  vmovaps xmm7, [rsp+0x70]
0000707f9fbd5ba5  vmovaps xmm8, [rsp+0x80]
0000707f9fbd5bae  vmovaps xmm9, [rsp+0x90]
0000707f9fbd5bb7  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd5bc0  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd5bc9  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd5bd2  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd5bdb  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd5be4  add rsp, 0xF0
0000707f9fbd5beb  pop r11
0000707f9fbd5bed  pop r10
0000707f9fbd5bef  pop r9
0000707f9fbd5bf1  pop r8
0000707f9fbd5bf3  pop rsi
0000707f9fbd5bf4  pop rdi
0000707f9fbd5bf5  pop rdx
0000707f9fbd5bf6  pop rcx
0000707f9fbd5bf7  pop rax
0000707f9fbd5bf8  add rsp, 0x08
0000707f9fbd5bfc  jmp 0x0000707F9FBD3122
0000707f9fbd5c01  call 0x0000707F9F9FF430
0000707f9fbd5c06  jmp 0x0000707F9FBD3134
0000707f9fbd5c0b  sub rsp, 0x08
0000707f9fbd5c0f  push rax
0000707f9fbd5c10  push rcx
0000707f9fbd5c11  push rdx
0000707f9fbd5c12  push rdi
0000707f9fbd5c13  push rsi
0000707f9fbd5c14  push r8
0000707f9fbd5c16  push r9
0000707f9fbd5c18  push r10
0000707f9fbd5c1a  push r11
0000707f9fbd5c1c  sub rsp, 0xF0
0000707f9fbd5c23  vmovaps [rsp], xmm0
0000707f9fbd5c28  vmovaps [rsp+0x10], xmm1
0000707f9fbd5c2e  vmovaps [rsp+0x20], xmm2
0000707f9fbd5c34  vmovaps [rsp+0x30], xmm3
0000707f9fbd5c3a  vmovaps [rsp+0x40], xmm4
0000707f9fbd5c40  vmovaps [rsp+0x50], xmm5
0000707f9fbd5c46  vmovaps [rsp+0x60], xmm6
0000707f9fbd5c4c  vmovaps [rsp+0x70], xmm7
0000707f9fbd5c52  vmovaps [rsp+0x80], xmm8
0000707f9fbd5c5b  vmovaps [rsp+0x90], xmm10
0000707f9fbd5c64  vmovaps [rsp+0xA0], xmm11
0000707f9fbd5c6d  vmovaps [rsp+0xB0], xmm12
0000707f9fbd5c76  vmovaps [rsp+0xC0], xmm13
0000707f9fbd5c7f  vmovaps [rsp+0xD0], xmm14
0000707f9fbd5c88  vmovaps [rsp+0xE0], xmm15
0000707f9fbd5c91  sub rsp, 0x40
0000707f9fbd5c95  lea rdi, [rsp]
0000707f9fbd5c99  lea rsi, [rsp+0x10]
0000707f9fbd5c9e  lea rdx, [rsp+0x20]
0000707f9fbd5ca3  lea rcx, [rsp+0x30]
0000707f9fbd5ca8  mov r8d, 0x00
0000707f9fbd5cae  lea r9, [r15+0x3A8]
0000707f9fbd5cb5  movaps [rdi], xmm9
0000707f9fbd5cb9  movaps [rsi], xmm8
0000707f9fbd5cbd  movaps [rdx], xmm14
0000707f9fbd5cc1  movaps [rcx], xmm12
0000707f9fbd5cc5  mov rax, 0x5753922B7A50
0000707f9fbd5ccf  call rax
0000707f9fbd5cd1  movaps xmm9, [rsp]
0000707f9fbd5cd6  add rsp, 0x40
0000707f9fbd5cda  vmovaps xmm0, [rsp]
0000707f9fbd5cdf  vmovaps xmm1, [rsp+0x10]
0000707f9fbd5ce5  vmovaps xmm2, [rsp+0x20]
0000707f9fbd5ceb  vmovaps xmm3, [rsp+0x30]
0000707f9fbd5cf1  vmovaps xmm4, [rsp+0x40]
0000707f9fbd5cf7  vmovaps xmm5, [rsp+0x50]
0000707f9fbd5cfd  vmovaps xmm6, [rsp+0x60]
0000707f9fbd5d03  vmovaps xmm7, [rsp+0x70]
0000707f9fbd5d09  vmovaps xmm8, [rsp+0x80]
0000707f9fbd5d12  vmovaps xmm10, [rsp+0x90]
0000707f9fbd5d1b  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd5d24  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd5d2d  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd5d36  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd5d3f  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd5d48  add rsp, 0xF0
0000707f9fbd5d4f  pop r11
0000707f9fbd5d51  pop r10
0000707f9fbd5d53  pop r9
0000707f9fbd5d55  pop r8
0000707f9fbd5d57  pop rsi
0000707f9fbd5d58  pop rdi
0000707f9fbd5d59  pop rdx
0000707f9fbd5d5a  pop rcx
0000707f9fbd5d5b  pop rax
0000707f9fbd5d5c  add rsp, 0x08
0000707f9fbd5d60  jmp 0x0000707F9FBD3165
0000707f9fbd5d65  sub rsp, 0x08
0000707f9fbd5d69  push rax
0000707f9fbd5d6a  push rcx
0000707f9fbd5d6b  push rdx
0000707f9fbd5d6c  push rdi
0000707f9fbd5d6d  push rsi
0000707f9fbd5d6e  push r8
0000707f9fbd5d70  push r9
0000707f9fbd5d72  push r10
0000707f9fbd5d74  push r11
0000707f9fbd5d76  sub rsp, 0xF0
0000707f9fbd5d7d  vmovaps [rsp], xmm0
0000707f9fbd5d82  vmovaps [rsp+0x10], xmm1
0000707f9fbd5d88  vmovaps [rsp+0x20], xmm2
0000707f9fbd5d8e  vmovaps [rsp+0x30], xmm3
0000707f9fbd5d94  vmovaps [rsp+0x40], xmm4
0000707f9fbd5d9a  vmovaps [rsp+0x50], xmm5
0000707f9fbd5da0  vmovaps [rsp+0x60], xmm6
0000707f9fbd5da6  vmovaps [rsp+0x70], xmm7
0000707f9fbd5dac  vmovaps [rsp+0x80], xmm8
0000707f9fbd5db5  vmovaps [rsp+0x90], xmm9
0000707f9fbd5dbe  vmovaps [rsp+0xA0], xmm10
0000707f9fbd5dc7  vmovaps [rsp+0xB0], xmm11
0000707f9fbd5dd0  vmovaps [rsp+0xC0], xmm13
0000707f9fbd5dd9  vmovaps [rsp+0xD0], xmm14
0000707f9fbd5de2  vmovaps [rsp+0xE0], xmm15
0000707f9fbd5deb  sub rsp, 0x40
0000707f9fbd5def  lea rdi, [rsp]
0000707f9fbd5df3  lea rsi, [rsp+0x10]
0000707f9fbd5df8  lea rdx, [rsp+0x20]
0000707f9fbd5dfd  lea rcx, [rsp+0x30]
0000707f9fbd5e02  mov r8d, 0x00
0000707f9fbd5e08  lea r9, [r15+0x3A8]
0000707f9fbd5e0f  movaps [rdi], xmm12
0000707f9fbd5e13  movaps [rsi], xmm10
0000707f9fbd5e17  movaps [rdx], xmm15
0000707f9fbd5e1b  movaps [rcx], xmm14
0000707f9fbd5e1f  mov rax, 0x5753922B7A50
0000707f9fbd5e29  call rax
0000707f9fbd5e2b  movaps xmm12, [rsp]
0000707f9fbd5e30  add rsp, 0x40
0000707f9fbd5e34  vmovaps xmm0, [rsp]
0000707f9fbd5e39  vmovaps xmm1, [rsp+0x10]
0000707f9fbd5e3f  vmovaps xmm2, [rsp+0x20]
0000707f9fbd5e45  vmovaps xmm3, [rsp+0x30]
0000707f9fbd5e4b  vmovaps xmm4, [rsp+0x40]
0000707f9fbd5e51  vmovaps xmm5, [rsp+0x50]
0000707f9fbd5e57  vmovaps xmm6, [rsp+0x60]
0000707f9fbd5e5d  vmovaps xmm7, [rsp+0x70]
0000707f9fbd5e63  vmovaps xmm8, [rsp+0x80]
0000707f9fbd5e6c  vmovaps xmm9, [rsp+0x90]
0000707f9fbd5e75  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd5e7e  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd5e87  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd5e90  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd5e99  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd5ea2  add rsp, 0xF0
0000707f9fbd5ea9  pop r11
0000707f9fbd5eab  pop r10
0000707f9fbd5ead  pop r9
0000707f9fbd5eaf  pop r8
0000707f9fbd5eb1  pop rsi
0000707f9fbd5eb2  pop rdi
0000707f9fbd5eb3  pop rdx
0000707f9fbd5eb4  pop rcx
0000707f9fbd5eb5  pop rax
0000707f9fbd5eb6  add rsp, 0x08
0000707f9fbd5eba  jmp 0x0000707F9FBD3196
0000707f9fbd5ebf  sub rsp, 0x08
0000707f9fbd5ec3  push rax
0000707f9fbd5ec4  push rcx
0000707f9fbd5ec5  push rdx
0000707f9fbd5ec6  push rdi
0000707f9fbd5ec7  push rsi
0000707f9fbd5ec8  push r8
0000707f9fbd5eca  push r9
0000707f9fbd5ecc  push r10
0000707f9fbd5ece  push r11
0000707f9fbd5ed0  sub rsp, 0xF0
0000707f9fbd5ed7  vmovaps [rsp], xmm0
0000707f9fbd5edc  vmovaps [rsp+0x10], xmm1
0000707f9fbd5ee2  vmovaps [rsp+0x20], xmm2
0000707f9fbd5ee8  vmovaps [rsp+0x30], xmm3
0000707f9fbd5eee  vmovaps [rsp+0x40], xmm4
0000707f9fbd5ef4  vmovaps [rsp+0x50], xmm5
0000707f9fbd5efa  vmovaps [rsp+0x60], xmm6
0000707f9fbd5f00  vmovaps [rsp+0x70], xmm7
0000707f9fbd5f06  vmovaps [rsp+0x80], xmm8
0000707f9fbd5f0f  vmovaps [rsp+0x90], xmm9
0000707f9fbd5f18  vmovaps [rsp+0xA0], xmm10
0000707f9fbd5f21  vmovaps [rsp+0xB0], xmm11
0000707f9fbd5f2a  vmovaps [rsp+0xC0], xmm12
0000707f9fbd5f33  vmovaps [rsp+0xD0], xmm13
0000707f9fbd5f3c  vmovaps [rsp+0xE0], xmm15
0000707f9fbd5f45  sub rsp, 0x40
0000707f9fbd5f49  lea rdi, [rsp]
0000707f9fbd5f4d  lea rsi, [rsp+0x10]
0000707f9fbd5f52  lea rdx, [rsp+0x20]
0000707f9fbd5f57  lea rcx, [rsp+0x30]
0000707f9fbd5f5c  mov r8d, 0x00
0000707f9fbd5f62  lea r9, [r15+0x3A8]
0000707f9fbd5f69  movaps [rdi], xmm14
0000707f9fbd5f6d  movaps [rsi], xmm13
0000707f9fbd5f71  movaps [rdx], xmm1
0000707f9fbd5f74  movaps [rcx], xmm15
0000707f9fbd5f78  mov rax, 0x5753922B7A50
0000707f9fbd5f82  call rax
0000707f9fbd5f84  movaps xmm14, [rsp]
0000707f9fbd5f89  add rsp, 0x40
0000707f9fbd5f8d  vmovaps xmm0, [rsp]
0000707f9fbd5f92  vmovaps xmm1, [rsp+0x10]
0000707f9fbd5f98  vmovaps xmm2, [rsp+0x20]
0000707f9fbd5f9e  vmovaps xmm3, [rsp+0x30]
0000707f9fbd5fa4  vmovaps xmm4, [rsp+0x40]
0000707f9fbd5faa  vmovaps xmm5, [rsp+0x50]
0000707f9fbd5fb0  vmovaps xmm6, [rsp+0x60]
0000707f9fbd5fb6  vmovaps xmm7, [rsp+0x70]
0000707f9fbd5fbc  vmovaps xmm8, [rsp+0x80]
0000707f9fbd5fc5  vmovaps xmm9, [rsp+0x90]
0000707f9fbd5fce  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd5fd7  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd5fe0  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd5fe9  vmovaps xmm13, [rsp+0xD0]
0000707f9fbd5ff2  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd5ffb  add rsp, 0xF0
0000707f9fbd6002  pop r11
0000707f9fbd6004  pop r10
0000707f9fbd6006  pop r9
0000707f9fbd6008  pop r8
0000707f9fbd600a  pop rsi
0000707f9fbd600b  pop rdi
0000707f9fbd600c  pop rdx
0000707f9fbd600d  pop rcx
0000707f9fbd600e  pop rax
0000707f9fbd600f  add rsp, 0x08
0000707f9fbd6013  jmp 0x0000707F9FBD31C7
0000707f9fbd6018  call 0x0000707F9FA079B0
0000707f9fbd601d  jmp 0x0000707F9FBD31DA
0000707f9fbd6022  call 0x0000707F9FA0B100
0000707f9fbd6027  jmp 0x0000707F9FBD31E5
0000707f9fbd602c  call 0x0000707F9FA09E90
0000707f9fbd6031  jmp 0x0000707F9FBD31F0
0000707f9fbd6036  call 0x0000707F9FA0D600
0000707f9fbd603b  jmp 0x0000707F9FBD31FB
0000707f9fbd6040  int3
0000707f9fbd6041  nop [rax+rax*1], ax
0000707f9fbd604a  nop [rax+rax*1], ax
0000707f9fbd6050  mov rax, [r15+0x40]
0000707f9fbd6054  mov r14, [r15+0x58]
0000707f9fbd6058  lea r12, [rax+r14*1]
0000707f9fbd605c  vxorps xmm1, xmm1, xmm1
0000707f9fbd6060  vpbroadcastq xmm1, xmm1
0000707f9fbd6065  vxorps xmm15, xmm15, xmm15
0000707f9fbd606a  vpbroadcastq xmm15, xmm15
0000707f9fbd606f  lea rax, [r12+0x30]
0000707f9fbd6074  mov r11, [r13+rax*1]
0000707f9fbd6079  lea rax, [r12+0x38]
0000707f9fbd607e  mov r10, [r13+rax*1]
0000707f9fbd6083  movq xmm14, r11
0000707f9fbd6088  movq xmm13, r10
0000707f9fbd608d  movq xmm14, xmm14
0000707f9fbd6092  movq xmm13, xmm13
0000707f9fbd6097  vmovaps [rsp+0x10], xmm13
0000707f9fbd609d  movq xmm13, xmm13
0000707f9fbd60a2  movaps [r15+0x270], xmm13
0000707f9fbd60aa  movaps xmm13, [r15+0x160]
0000707f9fbd60b2  vmovaps [rsp+0x20], xmm13
0000707f9fbd60b8  vmovaps xmm12, [rsp+0x20]
0000707f9fbd60be  por xmm13, xmm12
0000707f9fbd60c3  lea rax, [r12+0x20]
0000707f9fbd60c8  mov r11, [r13+rax*1]
0000707f9fbd60cd  lea rax, [r12+0x28]
0000707f9fbd60d2  mov r10, [r13+rax*1]
0000707f9fbd60d7  movq xmm12, r11
0000707f9fbd60dc  movq xmm11, r10
0000707f9fbd60e1  movq xmm12, xmm12
0000707f9fbd60e6  movq xmm11, xmm11
0000707f9fbd60eb  movaps xmm10, [r15+0x2D0]
0000707f9fbd60f3  vmovaps [rsp+0x20], xmm10
0000707f9fbd60f9  vmovaps xmm9, [rsp+0x20]
0000707f9fbd60ff  por xmm10, xmm9
0000707f9fbd6104  movaps xmm9, [r15+0x300]
0000707f9fbd610c  vmovaps [rsp+0x20], xmm9
0000707f9fbd6112  vmovaps xmm8, [rsp+0x20]
0000707f9fbd6118  por xmm9, xmm8
0000707f9fbd611d  movaps xmm8, [r15+0x2B0]
0000707f9fbd6125  vmovaps [rsp+0x20], xmm8
0000707f9fbd612b  vmovaps xmm7, [rsp+0x20]
0000707f9fbd6131  por xmm8, xmm7
0000707f9fbd6136  movaps xmm7, [r15+0x180]
0000707f9fbd613e  vmovaps [rsp+0x20], xmm7
0000707f9fbd6144  vmovaps xmm6, [rsp+0x20]
0000707f9fbd614a  por xmm7, xmm6
0000707f9fbd614e  lea rax, [r12+0x10]
0000707f9fbd6153  mov r11, [r13+rax*1]
0000707f9fbd6158  lea rax, [r12+0x18]
0000707f9fbd615d  mov r10, [r13+rax*1]
0000707f9fbd6162  movq xmm6, r11
0000707f9fbd6167  movq xmm5, r10
0000707f9fbd616c  movq xmm6, xmm6
0000707f9fbd6170  movq xmm5, xmm5
0000707f9fbd6174  movaps xmm4, [r15+0x200]
0000707f9fbd617c  vmovaps [rsp+0x20], xmm4
0000707f9fbd6182  vmovaps xmm3, [rsp+0x20]
0000707f9fbd6188  por xmm4, xmm3
0000707f9fbd618c  movaps xmm3, [r15+0x1F0]
0000707f9fbd6194  vmovaps [rsp+0x20], xmm3
0000707f9fbd619a  vmovaps xmm2, [rsp+0x20]
0000707f9fbd61a0  por xmm3, xmm2
0000707f9fbd61a4  movaps xmm2, [r15+0x2E0]
0000707f9fbd61ac  vmovaps [rsp+0x20], xmm2
0000707f9fbd61b2  vmovaps [rsp+0x30], xmm1
0000707f9fbd61b8  vmovaps xmm1, [rsp+0x20]
0000707f9fbd61be  por xmm2, xmm1
0000707f9fbd61c2  movaps xmm1, [r15+0x2A0]
0000707f9fbd61ca  vmovaps [rsp+0x20], xmm1
0000707f9fbd61d0  vmovaps [rsp+0x40], xmm15
0000707f9fbd61d6  vmovaps xmm15, [rsp+0x20]
0000707f9fbd61dc  por xmm1, xmm15
0000707f9fbd61e1  movaps xmm15, [r15+0x280]
0000707f9fbd61e9  vmovaps [rsp+0x20], xmm15
0000707f9fbd61ef  vmovaps [rsp+0x50], xmm1
0000707f9fbd61f5  vmovaps xmm1, [rsp+0x20]
0000707f9fbd61fb  por xmm15, xmm1
0000707f9fbd6200  movaps xmm1, [r15+0x1C0]
0000707f9fbd6208  vmovaps [rsp+0x20], xmm1
0000707f9fbd620e  vmovaps [rsp+0x60], xmm15
0000707f9fbd6214  vmovaps xmm15, [rsp+0x20]
0000707f9fbd621a  por xmm1, xmm15
0000707f9fbd621f  movaps xmm15, [r15+0x210]
0000707f9fbd6227  vmovaps [rsp+0x20], xmm15
0000707f9fbd622d  vmovaps [rsp+0x70], xmm1
0000707f9fbd6233  vmovaps xmm1, [rsp+0x20]
0000707f9fbd6239  por xmm15, xmm1
0000707f9fbd623e  mov rax, [r13+r12*1]
0000707f9fbd6243  vmovq xmm1, rax
0000707f9fbd6248  vpbroadcastq xmm1, xmm1
0000707f9fbd624d  vmovaps [rsp+0x20], xmm1
0000707f9fbd6253  vxorps xmm1, xmm1, xmm1
0000707f9fbd6257  vpbroadcastq xmm1, xmm1
0000707f9fbd625c  mov rax, [r15+0xF8]
0000707f9fbd6263  vmovaps [rsp+0x80], xmm1
0000707f9fbd626c  movups xmm1, [r13+rax*1]
0000707f9fbd6272  vmovaps [rsp+0x90], xmm1
0000707f9fbd627b  vxorps xmm1, xmm1, xmm1
0000707f9fbd627f  vpbroadcastq xmm1, xmm1
0000707f9fbd6284  lea r11, [r12+0x08]
0000707f9fbd6289  mov r12, [r13+r11*1]
0000707f9fbd628e  vmovaps [rsp+0xA0], xmm1
0000707f9fbd6297  movq xmm1, r12
0000707f9fbd629c  movaps [r15+0x240], xmm1
0000707f9fbd62a4  mov r12, [r15+0x50]
0000707f9fbd62a8  lea r11, [r12+r14*1]
0000707f9fbd62ac  mov [r15+0x60], r11
0000707f9fbd62b0  lea r12, [r14+0x40]
0000707f9fbd62b4  mov [r15+0x58], r12
0000707f9fbd62b8  vmovaps xmm1, [rsp+0x30]
0000707f9fbd62be  vmovaps [rsp+0x30], xmm15
0000707f9fbd62c4  vmovaps xmm15, [rsp+0x90]
0000707f9fbd62cd  vmovaps [rsp+0x90], xmm14
0000707f9fbd62d6  vmovaps xmm14, [rsp+0x20]
0000707f9fbd62dc  vmovaps [rsp+0x20], xmm13
0000707f9fbd62e2  vmovaps [rsp+0xB0], xmm12
0000707f9fbd62eb  movaps xmm13, xmm1
0000707f9fbd62ef  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd62fa  vptest xmm12, xmm12
0000707f9fbd62ff  jnz 0x0000707F9FBD6D9C
0000707f9fbd6305  movaps xmm1, [r15+0x250]
0000707f9fbd630d  vmovaps xmm15, [rsp+0x40]
0000707f9fbd6313  vmovaps [rsp+0x40], xmm13
0000707f9fbd6319  movaps xmm12, xmm15
0000707f9fbd631d  vfmadd231pd xmm12, xmm1, xmm14
0000707f9fbd6322  vcmppd xmm13, xmm12, xmm12, 0x03
0000707f9fbd6328  vptest xmm13, xmm13
0000707f9fbd632d  jnz 0x0000707F9FBD6EF5
0000707f9fbd6333  movaps xmm15, [r15+0x1E0]
0000707f9fbd633b  vmovaps [rsp+0xC0], xmm15
0000707f9fbd6344  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd634d  por xmm15, xmm13
0000707f9fbd6352  movaps xmm13, [r15+0x1D0]
0000707f9fbd635a  vmovaps [rsp+0xC0], xmm13
0000707f9fbd6363  vmovaps [rsp+0xD0], xmm1
0000707f9fbd636c  vmovaps xmm1, [rsp+0xC0]
0000707f9fbd6375  por xmm13, xmm1
0000707f9fbd637a  movaps xmm1, [r15+0x2C0]
0000707f9fbd6382  vmovaps [rsp+0xC0], xmm1
0000707f9fbd638b  vmovaps [rsp+0xE0], xmm15
0000707f9fbd6394  vmovaps xmm15, [rsp+0xC0]
0000707f9fbd639d  por xmm1, xmm15
0000707f9fbd63a2  movaps xmm15, [r15+0x290]
0000707f9fbd63aa  vmovaps [rsp+0xC0], xmm15
0000707f9fbd63b3  vmovaps [rsp+0xF0], xmm1
0000707f9fbd63bc  vmovaps xmm1, [rsp+0xC0]
0000707f9fbd63c5  por xmm15, xmm1
0000707f9fbd63ca  movaps xmm1, [r15+0x260]
0000707f9fbd63d2  vmovaps [rsp+0xC0], xmm1
0000707f9fbd63db  vmovaps [rsp+0x100], xmm15
0000707f9fbd63e4  vmovaps xmm15, [rsp+0xC0]
0000707f9fbd63ed  por xmm1, xmm15
0000707f9fbd63f2  vmovaps xmm15, [rsp+0xD0]
0000707f9fbd63fb  vmovaps [rsp+0xC0], xmm1
0000707f9fbd6404  vmovaps xmm1, [rsp+0xD0]
0000707f9fbd640d  por xmm15, xmm1
0000707f9fbd6412  lea r14, [rax+0xC0]
0000707f9fbd6419  movups xmm1, [r13+r14*1]
0000707f9fbd641f  mov [rsp+0xD0], rax
0000707f9fbd6427  xor eax, eax
0000707f9fbd6429  mov r14d, 0x200
0000707f9fbd642f  cmp r12, r14
0000707f9fbd6432  cmc
0000707f9fbd6433  lahf
0000707f9fbd6434  seto al
0000707f9fbd6437  mov [r15+0x108], eax
0000707f9fbd643e  vmovaps [rsp+0x110], xmm1
0000707f9fbd6447  vmovaps xmm1, [rsp+0x80]
0000707f9fbd6450  vmovaps [rsp+0x80], xmm15
0000707f9fbd6459  vmovaps xmm15, [rsp+0x110]
0000707f9fbd6462  vmovaps [rsp+0x110], xmm13
0000707f9fbd646b  vmovaps [rsp+0x120], xmm12
0000707f9fbd6474  movaps xmm13, xmm1
0000707f9fbd6478  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd647d  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd6483  vptest xmm12, xmm12
0000707f9fbd6488  jnz 0x0000707F9FBD7058
0000707f9fbd648e  mov rax, [rsp+0xD0]
0000707f9fbd6496  lea r14, [rax+0xB0]
0000707f9fbd649d  movups xmm1, [r13+r14*1]
0000707f9fbd64a3  vmovaps xmm15, [rsp+0xA0]
0000707f9fbd64ac  vmovaps [rsp+0xA0], xmm13
0000707f9fbd64b5  movaps xmm12, xmm15
0000707f9fbd64b9  vfmadd231pd xmm12, xmm1, xmm14
0000707f9fbd64be  vcmppd xmm13, xmm12, xmm12, 0x03
0000707f9fbd64c4  vptest xmm13, xmm13
0000707f9fbd64c9  jnz 0x0000707F9FBD71BB
0000707f9fbd64cf  vmovaps xmm1, [rsp+0x30]
0000707f9fbd64d5  vmovaps xmm15, [rsp+0x30]
0000707f9fbd64db  por xmm1, xmm15
0000707f9fbd64e0  movaps [r15+0x210], xmm1
0000707f9fbd64e8  vmovaps xmm15, [rsp+0x70]
0000707f9fbd64ee  vmovaps xmm14, [rsp+0x70]
0000707f9fbd64f4  por xmm15, xmm14
0000707f9fbd64f9  movaps [r15+0x1C0], xmm15
0000707f9fbd6501  vmovaps xmm14, [rsp+0x60]
0000707f9fbd6507  vmovaps xmm13, [rsp+0x60]
0000707f9fbd650d  por xmm14, xmm13
0000707f9fbd6512  movaps [r15+0x280], xmm14
0000707f9fbd651a  vmovaps xmm13, [rsp+0x50]
0000707f9fbd6520  vmovaps [rsp+0x30], xmm1
0000707f9fbd6526  vmovaps xmm1, [rsp+0x50]
0000707f9fbd652c  por xmm13, xmm1
0000707f9fbd6531  movaps [r15+0x2A0], xmm13
0000707f9fbd6539  vmovaps [rsp+0x50], xmm2
0000707f9fbd653f  vmovaps xmm1, [rsp+0x50]
0000707f9fbd6545  por xmm2, xmm1
0000707f9fbd6549  movaps [r15+0x2E0], xmm2
0000707f9fbd6551  vmovaps [rsp+0x50], xmm3
0000707f9fbd6557  vmovaps xmm1, [rsp+0x50]
0000707f9fbd655d  por xmm3, xmm1
0000707f9fbd6561  movaps [r15+0x1F0], xmm3
0000707f9fbd6569  vmovaps xmm1, [rsp+0x80]
0000707f9fbd6572  vmovaps [rsp+0x50], xmm15
0000707f9fbd6578  vmovaps xmm15, [rsp+0x80]
0000707f9fbd6581  por xmm1, xmm15
0000707f9fbd6586  movaps [r15+0x250], xmm1
0000707f9fbd658e  vmovaps xmm1, [rsp+0xC0]
0000707f9fbd6597  vmovaps xmm15, [rsp+0xC0]
0000707f9fbd65a0  por xmm1, xmm15
0000707f9fbd65a5  movaps [r15+0x260], xmm1
0000707f9fbd65ad  vmovaps xmm15, [rsp+0x100]
0000707f9fbd65b6  vmovaps [rsp+0x60], xmm1
0000707f9fbd65bc  vmovaps xmm1, [rsp+0x100]
0000707f9fbd65c5  por xmm15, xmm1
0000707f9fbd65ca  movaps [r15+0x290], xmm15
0000707f9fbd65d2  vmovaps xmm1, [rsp+0xF0]
0000707f9fbd65db  vmovaps [rsp+0x70], xmm15
0000707f9fbd65e1  vmovaps xmm15, [rsp+0xF0]
0000707f9fbd65ea  por xmm1, xmm15
0000707f9fbd65ef  movaps [r15+0x2C0], xmm1
0000707f9fbd65f7  movq xmm15, qword ptr [r15+0x240]
0000707f9fbd6600  vmovaps [rsp+0x80], xmm15
0000707f9fbd6609  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd660f  vmovaps [rsp+0xC0], xmm1
0000707f9fbd6618  vmovaps xmm1, [rsp+0x40]
0000707f9fbd661e  vmovaps [rsp+0x40], xmm15
0000707f9fbd6624  vmovaps xmm15, [rsp+0x30]
0000707f9fbd662a  vmovaps [rsp+0x30], xmm14
0000707f9fbd6630  vmovaps xmm14, [rsp+0x40]
0000707f9fbd6636  vmovaps [rsp+0x40], xmm13
0000707f9fbd663c  vmovaps [rsp+0xD0], xmm12
0000707f9fbd6645  movaps xmm13, xmm1
0000707f9fbd6649  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd664e  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd6654  vptest xmm12, xmm12
0000707f9fbd6659  jnz 0x0000707F9FBD7314
0000707f9fbd665f  vmovaps xmm1, [rsp+0x80]
0000707f9fbd6668  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd666e  vmovaps xmm15, [rsp+0xA0]
0000707f9fbd6677  movaps xmm14, xmm15
0000707f9fbd667b  vfmadd231pd xmm14, xmm2, xmm1
0000707f9fbd6680  vcmppd xmm12, xmm14, xmm14, 0x03
0000707f9fbd6686  vptest xmm12, xmm12
0000707f9fbd668b  jnz 0x0000707F9FBD746D
0000707f9fbd6691  vmovaps xmm1, [rsp+0x80]
0000707f9fbd669a  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd66a0  vmovaps xmm15, [rsp+0x120]
0000707f9fbd66a9  vmovaps xmm12, [rsp+0x50]
0000707f9fbd66af  vmovaps [rsp+0x50], xmm14
0000707f9fbd66b5  movaps xmm2, xmm15
0000707f9fbd66b9  vfmadd231pd xmm2, xmm12, xmm1
0000707f9fbd66be  vcmppd xmm14, xmm2, xmm2, 0x03
0000707f9fbd66c3  vptest xmm14, xmm14
0000707f9fbd66c8  jnz 0x0000707F9FBD75C5
0000707f9fbd66ce  vmovaps xmm1, [rsp+0x110]
0000707f9fbd66d7  vmovaps xmm15, [rsp+0x110]
0000707f9fbd66e0  por xmm1, xmm15
0000707f9fbd66e5  movaps [r15+0x1D0], xmm1
0000707f9fbd66ed  vmovaps xmm15, [rsp+0x80]
0000707f9fbd66f6  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd66fc  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd6705  vmovaps [rsp+0x80], xmm1
0000707f9fbd670e  movaps xmm12, xmm14
0000707f9fbd6712  vfmadd231pd xmm12, xmm3, xmm15
0000707f9fbd6717  vcmppd xmm1, xmm12, xmm12, 0x03
0000707f9fbd671d  vptest xmm1, xmm1
0000707f9fbd6722  jnz 0x0000707F9FBD771C
0000707f9fbd6728  vmovaps [rsp+0xA0], xmm4
0000707f9fbd6731  vmovaps xmm1, [rsp+0xA0]
0000707f9fbd673a  por xmm4, xmm1
0000707f9fbd673e  movaps [r15+0x200], xmm4
0000707f9fbd6746  vmovaps xmm1, [rsp+0xE0]
0000707f9fbd674f  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd6758  por xmm1, xmm15
0000707f9fbd675d  movaps [r15+0x1E0], xmm1
0000707f9fbd6765  vmovaps [rsp+0xA0], xmm8
0000707f9fbd676e  vmovaps xmm1, [rsp+0xA0]
0000707f9fbd6777  por xmm8, xmm1
0000707f9fbd677c  movaps [r15+0x2B0], xmm8
0000707f9fbd6784  vmovaps [rsp+0xA0], xmm9
0000707f9fbd678d  vmovaps xmm1, [rsp+0xA0]
0000707f9fbd6796  por xmm9, xmm1
0000707f9fbd679b  movaps [r15+0x300], xmm9
0000707f9fbd67a3  vmovaps [rsp+0xA0], xmm6
0000707f9fbd67ac  vpermilpd xmm6, xmm6, 0x00
0000707f9fbd67b2  vmovaps xmm14, [rsp+0x60]
0000707f9fbd67b8  movaps xmm9, xmm13
0000707f9fbd67bc  vfmadd231pd xmm9, xmm14, xmm6
0000707f9fbd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
0000707f9fbd67c7  vptest xmm3, xmm3
0000707f9fbd67cc  jnz 0x0000707F9FBD7875
0000707f9fbd67d2  vmovaps xmm14, [rsp+0xA0]
0000707f9fbd67db  vpermilpd xmm14, xmm14, 0x00
0000707f9fbd67e1  vmovaps xmm13, [rsp+0x50]
0000707f9fbd67e7  vmovaps xmm6, [rsp+0xC0]
0000707f9fbd67f0  vmovaps [rsp+0x50], xmm1
0000707f9fbd67f6  movaps xmm3, xmm13
0000707f9fbd67fa  vfmadd231pd xmm3, xmm6, xmm14
0000707f9fbd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
0000707f9fbd6804  vptest xmm1, xmm1
0000707f9fbd6809  jnz 0x0000707F9FBD79CE
0000707f9fbd680f  vmovaps xmm1, [rsp+0xA0]
0000707f9fbd6818  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd681e  vmovaps xmm14, [rsp+0x30]
0000707f9fbd6824  movaps xmm6, xmm2
0000707f9fbd6827  vfmadd231pd xmm6, xmm14, xmm1
0000707f9fbd682c  vcmppd xmm13, xmm6, xmm6, 0x03
0000707f9fbd6831  vptest xmm13, xmm13
0000707f9fbd6836  jnz 0x0000707F9FBD7B25
0000707f9fbd683c  vmovaps xmm1, [rsp+0xA0]
0000707f9fbd6845  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd684b  vmovaps xmm14, [rsp+0x80]
0000707f9fbd6854  movaps xmm13, xmm12
0000707f9fbd6858  vfmadd231pd xmm13, xmm14, xmm1
0000707f9fbd685d  vcmppd xmm2, xmm13, xmm13, 0x03
0000707f9fbd6863  vptest xmm2, xmm2
0000707f9fbd6868  jnz 0x0000707F9FBD7C7B
0000707f9fbd686e  vmovaps [rsp+0x30], xmm7
0000707f9fbd6874  vmovaps xmm1, [rsp+0x30]
0000707f9fbd687a  por xmm7, xmm1
0000707f9fbd687e  movaps [r15+0x180], xmm7
0000707f9fbd6886  vmovaps [rsp+0x30], xmm10
0000707f9fbd688c  vmovaps xmm1, [rsp+0x30]
0000707f9fbd6892  por xmm10, xmm1
0000707f9fbd6897  movaps [r15+0x2D0], xmm10
0000707f9fbd689f  vmovaps [rsp+0x30], xmm5
0000707f9fbd68a5  vpermilpd xmm5, xmm5, 0x00
0000707f9fbd68ab  vmovaps xmm14, [rsp+0x50]
0000707f9fbd68b1  movaps xmm12, xmm3
0000707f9fbd68b5  vfmadd231pd xmm12, xmm14, xmm5
0000707f9fbd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
0000707f9fbd68c0  vptest xmm10, xmm10
0000707f9fbd68c5  jnz 0x0000707F9FBD7DD4
0000707f9fbd68cb  vmovaps xmm14, [rsp+0x30]
0000707f9fbd68d1  vpermilpd xmm14, xmm14, 0x00
0000707f9fbd68d7  movaps xmm10, xmm9
0000707f9fbd68db  vfmadd231pd xmm10, xmm7, xmm14
0000707f9fbd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
0000707f9fbd68e6  vptest xmm5, xmm5
0000707f9fbd68eb  jnz 0x0000707F9FBD7F2C
0000707f9fbd68f1  lea r14, [rax+0x80]
0000707f9fbd68f8  movups xmm14, [r13+r14*1]
0000707f9fbd68fe  movaps [r15+0x2F0], xmm14
0000707f9fbd6906  vmovaps xmm9, [rsp+0x30]
0000707f9fbd690c  vpermilpd xmm9, xmm9, 0x00
0000707f9fbd6912  vmovaps xmm7, [rsp+0x70]
0000707f9fbd6918  movaps xmm5, xmm6
0000707f9fbd691b  vfmadd231pd xmm5, xmm7, xmm9
0000707f9fbd6920  vcmppd xmm3, xmm5, xmm5, 0x03
0000707f9fbd6925  vptest xmm3, xmm3
0000707f9fbd692a  jnz 0x0000707F9FBD808F
0000707f9fbd6930  vmovaps xmm9, [rsp+0x30]
0000707f9fbd6936  vpermilpd xmm9, xmm9, 0x00
0000707f9fbd693c  movaps xmm7, xmm13
0000707f9fbd6940  vfmadd231pd xmm7, xmm1, xmm9
0000707f9fbd6945  vcmppd xmm6, xmm7, xmm7, 0x03
0000707f9fbd694a  vptest xmm6, xmm6
0000707f9fbd694f  jnz 0x0000707F9FBD81E5
0000707f9fbd6955  vmovaps xmm1, [rsp+0x20]
0000707f9fbd695b  vmovaps xmm13, [rsp+0x20]
0000707f9fbd6961  por xmm1, xmm13
0000707f9fbd6966  movaps [r15+0x160], xmm1
0000707f9fbd696e  lea r14, [rax+0x40]
0000707f9fbd6972  movups xmm13, [r13+r14*1]
0000707f9fbd6978  lea r14, [rax+0x50]
0000707f9fbd697c  movups xmm9, [r13+r14*1]
0000707f9fbd6982  movaps [r15+0x1B0], xmm13
0000707f9fbd698a  movaps [r15+0x1A0], xmm9
0000707f9fbd6992  movaps xmm6, [r15+0x190]
0000707f9fbd699a  vmovaps xmm3, [rsp+0xB0]
0000707f9fbd69a3  vpermilpd xmm3, xmm3, 0x00
0000707f9fbd69a9  vmovaps [rsp+0x20], xmm1
0000707f9fbd69af  movaps xmm2, xmm12
0000707f9fbd69b3  vfmadd231pd xmm2, xmm6, xmm3
0000707f9fbd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
0000707f9fbd69bd  vptest xmm1, xmm1
0000707f9fbd69c2  jnz 0x0000707F9FBD8350
0000707f9fbd69c8  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd69d1  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd69d7  vmovaps xmm12, [rsp+0x20]
0000707f9fbd69dd  movaps xmm6, xmm10
0000707f9fbd69e1  vfmadd231pd xmm6, xmm12, xmm1
0000707f9fbd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
0000707f9fbd69eb  vptest xmm3, xmm3
0000707f9fbd69f0  jnz 0x0000707F9FBD84A6
0000707f9fbd69f6  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd69ff  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd6a05  vmovaps xmm12, [rsp+0x40]
0000707f9fbd6a0b  movaps xmm10, xmm5
0000707f9fbd6a0f  vfmadd231pd xmm10, xmm12, xmm1
0000707f9fbd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
0000707f9fbd6a1a  vptest xmm3, xmm3
0000707f9fbd6a1f  jnz 0x0000707F9FBD85FD
0000707f9fbd6a25  vmovaps xmm1, [rsp+0xB0]
0000707f9fbd6a2e  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd6a34  movaps xmm12, xmm7
0000707f9fbd6a38  vfmadd231pd xmm12, xmm15, xmm1
0000707f9fbd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
0000707f9fbd6a43  vptest xmm5, xmm5
0000707f9fbd6a48  jnz 0x0000707F9FBD8755
0000707f9fbd6a4e  lea r14, [rax+0x60]
0000707f9fbd6a52  movups xmm1, [r13+r14*1]
0000707f9fbd6a58  lea r14, [rax+0x70]
0000707f9fbd6a5c  movups xmm15, [r13+r14*1]
0000707f9fbd6a62  movaps [r15+0x150], xmm1
0000707f9fbd6a6a  movaps [r15+0x120], xmm15
0000707f9fbd6a72  vmovaps [rsp+0x20], xmm11
0000707f9fbd6a78  vpermilpd xmm11, xmm11, 0x00
0000707f9fbd6a7e  movaps xmm7, xmm2
0000707f9fbd6a81  vfmadd231pd xmm7, xmm9, xmm11
0000707f9fbd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
0000707f9fbd6a8b  vptest xmm5, xmm5
0000707f9fbd6a90  jnz 0x0000707F9FBD88C1
0000707f9fbd6a96  vmovaps xmm11, [rsp+0x20]
0000707f9fbd6a9c  vpermilpd xmm11, xmm11, 0x00
0000707f9fbd6aa2  movaps xmm9, xmm6
0000707f9fbd6aa6  vfmadd231pd xmm9, xmm1, xmm11
0000707f9fbd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
0000707f9fbd6ab1  vptest xmm5, xmm5
0000707f9fbd6ab6  jnz 0x0000707F9FBD8A18
0000707f9fbd6abc  vmovaps xmm1, [rsp+0x20]
0000707f9fbd6ac2  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd6ac8  movaps xmm11, xmm10
0000707f9fbd6acc  vfmadd231pd xmm11, xmm8, xmm1
0000707f9fbd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
0000707f9fbd6ad7  vptest xmm6, xmm6
0000707f9fbd6adc  jnz 0x0000707F9FBD8B70
0000707f9fbd6ae2  vmovaps xmm1, [rsp+0x20]
0000707f9fbd6ae8  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd6aee  movaps xmm10, xmm12
0000707f9fbd6af2  vfmadd231pd xmm10, xmm13, xmm1
0000707f9fbd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
0000707f9fbd6afd  vptest xmm8, xmm8
0000707f9fbd6b02  jnz 0x0000707F9FBD8CC9
0000707f9fbd6b08  lea r14, [rax+0x20]
0000707f9fbd6b0c  movups xmm1, [r13+r14*1]
0000707f9fbd6b12  lea r14, [rax+0x30]
0000707f9fbd6b16  movups xmm13, [r13+r14*1]
0000707f9fbd6b1c  vmovaps xmm12, [rsp+0x90]
0000707f9fbd6b25  vpermilpd xmm12, xmm12, 0x00
0000707f9fbd6b2b  movaps xmm8, xmm7
0000707f9fbd6b2f  vfmadd231pd xmm8, xmm4, xmm12
0000707f9fbd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
0000707f9fbd6b3a  vptest xmm6, xmm6
0000707f9fbd6b3f  jnz 0x0000707F9FBD8E36
0000707f9fbd6b45  vmovaps xmm12, [rsp+0x90]
0000707f9fbd6b4e  vpermilpd xmm12, xmm12, 0x00
0000707f9fbd6b54  movaps xmm7, xmm9
0000707f9fbd6b58  vfmadd231pd xmm7, xmm14, xmm12
0000707f9fbd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
0000707f9fbd6b62  vptest xmm6, xmm6
0000707f9fbd6b67  jnz 0x0000707F9FBD8F8E
0000707f9fbd6b6d  vmovaps xmm14, [rsp+0x90]
0000707f9fbd6b76  vpermilpd xmm14, xmm14, 0x00
0000707f9fbd6b7c  movaps xmm12, xmm11
0000707f9fbd6b80  vfmadd231pd xmm12, xmm15, xmm14
0000707f9fbd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
0000707f9fbd6b8b  vptest xmm9, xmm9
0000707f9fbd6b90  jnz 0x0000707F9FBD90E6
0000707f9fbd6b96  vmovaps xmm15, [rsp+0x90]
0000707f9fbd6b9f  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd6ba5  movaps xmm11, xmm10
0000707f9fbd6ba9  vfmadd231pd xmm11, xmm13, xmm15
0000707f9fbd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
0000707f9fbd6bb4  vptest xmm14, xmm14
0000707f9fbd6bb9  jnz 0x0000707F9FBD9240
0000707f9fbd6bbf  lea r14, [rax+0x90]
0000707f9fbd6bc6  movups xmm15, [r13+r14*1]
0000707f9fbd6bcc  lea r14, [rax+0xA0]
0000707f9fbd6bd3  movups xmm14, [r13+r14*1]
0000707f9fbd6bd9  movaps [r15+0x140], xmm15
0000707f9fbd6be1  movaps [r15+0x130], xmm14
0000707f9fbd6be9  vmovaps xmm13, [rsp+0x10]
0000707f9fbd6bef  vpermilpd xmm13, xmm13, 0x00
0000707f9fbd6bf5  movaps xmm10, xmm8
0000707f9fbd6bf9  vfmadd231pd xmm10, xmm1, xmm13
0000707f9fbd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
0000707f9fbd6c04  vptest xmm9, xmm9
0000707f9fbd6c09  jnz 0x0000707F9FBD93AE
0000707f9fbd6c0f  movaps [r15+0x220], xmm10
0000707f9fbd6c17  lea r14, [rax+0x10]
0000707f9fbd6c1b  movups xmm1, [r13+r14*1]
0000707f9fbd6c21  movaps [r15+0x240], xmm1
0000707f9fbd6c29  vmovaps xmm13, [rsp+0x10]
0000707f9fbd6c2f  vpermilpd xmm13, xmm13, 0x00
0000707f9fbd6c35  movaps xmm9, xmm7
0000707f9fbd6c39  vfmadd231pd xmm9, xmm14, xmm13
0000707f9fbd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
0000707f9fbd6c44  vptest xmm8, xmm8
0000707f9fbd6c49  jnz 0x0000707F9FBD9511
0000707f9fbd6c4f  movaps [r15+0x110], xmm9
0000707f9fbd6c57  vmovaps xmm14, [rsp+0x10]
0000707f9fbd6c5d  vpermilpd xmm14, xmm14, 0x00
0000707f9fbd6c63  movaps xmm13, xmm12
0000707f9fbd6c67  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
0000707f9fbd6c72  vptest xmm8, xmm8
0000707f9fbd6c77  jnz 0x0000707F9FBD966A
0000707f9fbd6c7d  movaps [r15+0x170], xmm13
0000707f9fbd6c85  vmovaps xmm15, [rsp+0x10]
0000707f9fbd6c8b  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd6c91  movaps xmm14, xmm11
0000707f9fbd6c95  vfmadd231pd xmm14, xmm1, xmm15
0000707f9fbd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
0000707f9fbd6ca0  vptest xmm12, xmm12
0000707f9fbd6ca5  jnz 0x0000707F9FBD97C4
0000707f9fbd6cab  movaps [r15+0x230], xmm14
0000707f9fbd6cb3  movups [r13+r11*1], xmm9
0000707f9fbd6cb9  lea rax, [r11+0x10]
0000707f9fbd6cbd  movups [r13+rax*1], xmm13
0000707f9fbd6cc3  lea rax, [r11+0x20]
0000707f9fbd6cc7  movups [r13+rax*1], xmm10
0000707f9fbd6ccd  lea rax, [r11+0x30]
0000707f9fbd6cd1  movups [r13+rax*1], xmm14
0000707f9fbd6cd7  mov eax, [r15+0x108]
0000707f9fbd6cde  sahf
0000707f9fbd6cdf  jnz 0x0000707F9FBD6D11
0000707f9fbd6ce1  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd6ce9  jz 0x0000707F9FBD9950
0000707f9fbd6cef  nop [rax+rax*1], ax
0000707f9fbd6cf8  nop [rax+rax*1], eax
0000707f9fbd6d00  mov eax, 0x410664
0000707f9fbd6d05  mov [r15+0x100], rax
0000707f9fbd6d0c  jmp 0x0000707F9F9FE110
0000707f9fbd6d11  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd6d19  jz 0x0000707F9FBD6050
0000707f9fbd6d1f  nop [rax+rax*1], ax
0000707f9fbd6d28  nop [rax+rax*1], eax
0000707f9fbd6d30  mov eax, 0x4104F0
0000707f9fbd6d35  mov [r15+0x100], rax
0000707f9fbd6d3c  jmp 0x0000707F9F9FE110
0000707f9fbd6d41  int3
0000707f9fbd6d42  call 0x0000707F9FA0A4B0
0000707f9fbd6d47  jmp 0x0000707F9FBD6079
0000707f9fbd6d4c  call 0x0000707F9FA09240
0000707f9fbd6d51  jmp 0x0000707F9FBD6083
0000707f9fbd6d56  call 0x0000707F9FA0A4B0
0000707f9fbd6d5b  jmp 0x0000707F9FBD60CD
0000707f9fbd6d60  call 0x0000707F9FA09240
0000707f9fbd6d65  jmp 0x0000707F9FBD60D7
0000707f9fbd6d6a  call 0x0000707F9FA0A4B0
0000707f9fbd6d6f  jmp 0x0000707F9FBD6158
0000707f9fbd6d74  call 0x0000707F9FA09240
0000707f9fbd6d79  jmp 0x0000707F9FBD6162
0000707f9fbd6d7e  call 0x0000707F9FAB47C0
0000707f9fbd6d83  jmp 0x0000707F9FBD6243
0000707f9fbd6d88  call 0x0000707F9F9FF430
0000707f9fbd6d8d  jmp 0x0000707F9FBD6272
0000707f9fbd6d92  call 0x0000707F9FAB0CE0
0000707f9fbd6d97  jmp 0x0000707F9FBD628E
0000707f9fbd6d9c  sub rsp, 0x08
0000707f9fbd6da0  push rax
0000707f9fbd6da1  push rcx
0000707f9fbd6da2  push rdx
0000707f9fbd6da3  push rdi
0000707f9fbd6da4  push rsi
0000707f9fbd6da5  push r8
0000707f9fbd6da7  push r9
0000707f9fbd6da9  push r10
0000707f9fbd6dab  push r11
0000707f9fbd6dad  sub rsp, 0xF0
0000707f9fbd6db4  vmovaps [rsp], xmm0
0000707f9fbd6db9  vmovaps [rsp+0x10], xmm1
0000707f9fbd6dbf  vmovaps [rsp+0x20], xmm2
0000707f9fbd6dc5  vmovaps [rsp+0x30], xmm3
0000707f9fbd6dcb  vmovaps [rsp+0x40], xmm4
0000707f9fbd6dd1  vmovaps [rsp+0x50], xmm5
0000707f9fbd6dd7  vmovaps [rsp+0x60], xmm6
0000707f9fbd6ddd  vmovaps [rsp+0x70], xmm7
0000707f9fbd6de3  vmovaps [rsp+0x80], xmm8
0000707f9fbd6dec  vmovaps [rsp+0x90], xmm9
0000707f9fbd6df5  vmovaps [rsp+0xA0], xmm10
0000707f9fbd6dfe  vmovaps [rsp+0xB0], xmm11
0000707f9fbd6e07  vmovaps [rsp+0xC0], xmm12
0000707f9fbd6e10  vmovaps [rsp+0xD0], xmm14
0000707f9fbd6e19  vmovaps [rsp+0xE0], xmm15
0000707f9fbd6e22  sub rsp, 0x40
0000707f9fbd6e26  lea rdi, [rsp]
0000707f9fbd6e2a  lea rsi, [rsp+0x10]
0000707f9fbd6e2f  lea rdx, [rsp+0x20]
0000707f9fbd6e34  lea rcx, [rsp+0x30]
0000707f9fbd6e39  mov r8d, 0x00
0000707f9fbd6e3f  lea r9, [r15+0x3A8]
0000707f9fbd6e46  movaps [rdi], xmm13
0000707f9fbd6e4a  movaps [rsi], xmm1
0000707f9fbd6e4d  movaps [rdx], xmm15
0000707f9fbd6e51  movaps [rcx], xmm14
0000707f9fbd6e55  mov rax, 0x5753922B7A50
0000707f9fbd6e5f  call rax
0000707f9fbd6e61  movaps xmm13, [rsp]
0000707f9fbd6e66  add rsp, 0x40
0000707f9fbd6e6a  vmovaps xmm0, [rsp]
0000707f9fbd6e6f  vmovaps xmm1, [rsp+0x10]
0000707f9fbd6e75  vmovaps xmm2, [rsp+0x20]
0000707f9fbd6e7b  vmovaps xmm3, [rsp+0x30]
0000707f9fbd6e81  vmovaps xmm4, [rsp+0x40]
0000707f9fbd6e87  vmovaps xmm5, [rsp+0x50]
0000707f9fbd6e8d  vmovaps xmm6, [rsp+0x60]
0000707f9fbd6e93  vmovaps xmm7, [rsp+0x70]
0000707f9fbd6e99  vmovaps xmm8, [rsp+0x80]
0000707f9fbd6ea2  vmovaps xmm9, [rsp+0x90]
0000707f9fbd6eab  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd6eb4  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd6ebd  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd6ec6  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd6ecf  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd6ed8  add rsp, 0xF0
0000707f9fbd6edf  pop r11
0000707f9fbd6ee1  pop r10
0000707f9fbd6ee3  pop r9
0000707f9fbd6ee5  pop r8
0000707f9fbd6ee7  pop rsi
0000707f9fbd6ee8  pop rdi
0000707f9fbd6ee9  pop rdx
0000707f9fbd6eea  pop rcx
0000707f9fbd6eeb  pop rax
0000707f9fbd6eec  add rsp, 0x08
0000707f9fbd6ef0  jmp 0x0000707F9FBD6305
0000707f9fbd6ef5  sub rsp, 0x08
0000707f9fbd6ef9  push rax
0000707f9fbd6efa  push rcx
0000707f9fbd6efb  push rdx
0000707f9fbd6efc  push rdi
0000707f9fbd6efd  push rsi
0000707f9fbd6efe  push r8
0000707f9fbd6f00  push r9
0000707f9fbd6f02  push r10
0000707f9fbd6f04  push r11
0000707f9fbd6f06  sub rsp, 0xF0
0000707f9fbd6f0d  vmovaps [rsp], xmm0
0000707f9fbd6f12  vmovaps [rsp+0x10], xmm1
0000707f9fbd6f18  vmovaps [rsp+0x20], xmm2
0000707f9fbd6f1e  vmovaps [rsp+0x30], xmm3
0000707f9fbd6f24  vmovaps [rsp+0x40], xmm4
0000707f9fbd6f2a  vmovaps [rsp+0x50], xmm5
0000707f9fbd6f30  vmovaps [rsp+0x60], xmm6
0000707f9fbd6f36  vmovaps [rsp+0x70], xmm7
0000707f9fbd6f3c  vmovaps [rsp+0x80], xmm8
0000707f9fbd6f45  vmovaps [rsp+0x90], xmm9
0000707f9fbd6f4e  vmovaps [rsp+0xA0], xmm10
0000707f9fbd6f57  vmovaps [rsp+0xB0], xmm11
0000707f9fbd6f60  vmovaps [rsp+0xC0], xmm13
0000707f9fbd6f69  vmovaps [rsp+0xD0], xmm14
0000707f9fbd6f72  vmovaps [rsp+0xE0], xmm15
0000707f9fbd6f7b  sub rsp, 0x40
0000707f9fbd6f7f  lea rdi, [rsp]
0000707f9fbd6f83  lea rsi, [rsp+0x10]
0000707f9fbd6f88  lea rdx, [rsp+0x20]
0000707f9fbd6f8d  lea rcx, [rsp+0x30]
0000707f9fbd6f92  mov r8d, 0x00
0000707f9fbd6f98  lea r9, [r15+0x3A8]
0000707f9fbd6f9f  movaps [rdi], xmm12
0000707f9fbd6fa3  movaps [rsi], xmm15
0000707f9fbd6fa7  movaps [rdx], xmm1
0000707f9fbd6faa  movaps [rcx], xmm14
0000707f9fbd6fae  mov rax, 0x5753922B7A50
0000707f9fbd6fb8  call rax
0000707f9fbd6fba  movaps xmm12, [rsp]
0000707f9fbd6fbf  add rsp, 0x40
0000707f9fbd6fc3  vmovaps xmm0, [rsp]
0000707f9fbd6fc8  vmovaps xmm1, [rsp+0x10]
0000707f9fbd6fce  vmovaps xmm2, [rsp+0x20]
0000707f9fbd6fd4  vmovaps xmm3, [rsp+0x30]
0000707f9fbd6fda  vmovaps xmm4, [rsp+0x40]
0000707f9fbd6fe0  vmovaps xmm5, [rsp+0x50]
0000707f9fbd6fe6  vmovaps xmm6, [rsp+0x60]
0000707f9fbd6fec  vmovaps xmm7, [rsp+0x70]
0000707f9fbd6ff2  vmovaps xmm8, [rsp+0x80]
0000707f9fbd6ffb  vmovaps xmm9, [rsp+0x90]
0000707f9fbd7004  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd700d  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd7016  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd701f  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd7028  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd7031  add rsp, 0xF0
0000707f9fbd7038  pop r11
0000707f9fbd703a  pop r10
0000707f9fbd703c  pop r9
0000707f9fbd703e  pop r8
0000707f9fbd7040  pop rsi
0000707f9fbd7041  pop rdi
0000707f9fbd7042  pop rdx
0000707f9fbd7043  pop rcx
0000707f9fbd7044  pop rax
0000707f9fbd7045  add rsp, 0x08
0000707f9fbd7049  jmp 0x0000707F9FBD6333
0000707f9fbd704e  call 0x0000707F9FAD64F0
0000707f9fbd7053  jmp 0x0000707F9FBD641F
0000707f9fbd7058  sub rsp, 0x08
0000707f9fbd705c  push rax
0000707f9fbd705d  push rcx
0000707f9fbd705e  push rdx
0000707f9fbd705f  push rdi
0000707f9fbd7060  push rsi
0000707f9fbd7061  push r8
0000707f9fbd7063  push r9
0000707f9fbd7065  push r10
0000707f9fbd7067  push r11
0000707f9fbd7069  sub rsp, 0xF0
0000707f9fbd7070  vmovaps [rsp], xmm0
0000707f9fbd7075  vmovaps [rsp+0x10], xmm1
0000707f9fbd707b  vmovaps [rsp+0x20], xmm2
0000707f9fbd7081  vmovaps [rsp+0x30], xmm3
0000707f9fbd7087  vmovaps [rsp+0x40], xmm4
0000707f9fbd708d  vmovaps [rsp+0x50], xmm5
0000707f9fbd7093  vmovaps [rsp+0x60], xmm6
0000707f9fbd7099  vmovaps [rsp+0x70], xmm7
0000707f9fbd709f  vmovaps [rsp+0x80], xmm8
0000707f9fbd70a8  vmovaps [rsp+0x90], xmm9
0000707f9fbd70b1  vmovaps [rsp+0xA0], xmm10
0000707f9fbd70ba  vmovaps [rsp+0xB0], xmm11
0000707f9fbd70c3  vmovaps [rsp+0xC0], xmm12
0000707f9fbd70cc  vmovaps [rsp+0xD0], xmm14
0000707f9fbd70d5  vmovaps [rsp+0xE0], xmm15
0000707f9fbd70de  sub rsp, 0x40
0000707f9fbd70e2  lea rdi, [rsp]
0000707f9fbd70e6  lea rsi, [rsp+0x10]
0000707f9fbd70eb  lea rdx, [rsp+0x20]
0000707f9fbd70f0  lea rcx, [rsp+0x30]
0000707f9fbd70f5  mov r8d, 0x00
0000707f9fbd70fb  lea r9, [r15+0x3A8]
0000707f9fbd7102  movaps [rdi], xmm13
0000707f9fbd7106  movaps [rsi], xmm1
0000707f9fbd7109  movaps [rdx], xmm15
0000707f9fbd710d  movaps [rcx], xmm14
0000707f9fbd7111  mov rax, 0x5753922B7A50
0000707f9fbd711b  call rax
0000707f9fbd711d  movaps xmm13, [rsp]
0000707f9fbd7122  add rsp, 0x40
0000707f9fbd7126  vmovaps xmm0, [rsp]
0000707f9fbd712b  vmovaps xmm1, [rsp+0x10]
0000707f9fbd7131  vmovaps xmm2, [rsp+0x20]
0000707f9fbd7137  vmovaps xmm3, [rsp+0x30]
0000707f9fbd713d  vmovaps xmm4, [rsp+0x40]
0000707f9fbd7143  vmovaps xmm5, [rsp+0x50]
0000707f9fbd7149  vmovaps xmm6, [rsp+0x60]
0000707f9fbd714f  vmovaps xmm7, [rsp+0x70]
0000707f9fbd7155  vmovaps xmm8, [rsp+0x80]
0000707f9fbd715e  vmovaps xmm9, [rsp+0x90]
0000707f9fbd7167  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd7170  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd7179  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd7182  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd718b  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd7194  add rsp, 0xF0
0000707f9fbd719b  pop r11
0000707f9fbd719d  pop r10
0000707f9fbd719f  pop r9
0000707f9fbd71a1  pop r8
0000707f9fbd71a3  pop rsi
0000707f9fbd71a4  pop rdi
0000707f9fbd71a5  pop rdx
0000707f9fbd71a6  pop rcx
0000707f9fbd71a7  pop rax
0000707f9fbd71a8  add rsp, 0x08
0000707f9fbd71ac  jmp 0x0000707F9FBD648E
0000707f9fbd71b1  call 0x0000707F9FAD64F0
0000707f9fbd71b6  jmp 0x0000707F9FBD64A3
0000707f9fbd71bb  sub rsp, 0x08
0000707f9fbd71bf  push rax
0000707f9fbd71c0  push rcx
0000707f9fbd71c1  push rdx
0000707f9fbd71c2  push rdi
0000707f9fbd71c3  push rsi
0000707f9fbd71c4  push r8
0000707f9fbd71c6  push r9
0000707f9fbd71c8  push r10
0000707f9fbd71ca  push r11
0000707f9fbd71cc  sub rsp, 0xF0
0000707f9fbd71d3  vmovaps [rsp], xmm0
0000707f9fbd71d8  vmovaps [rsp+0x10], xmm1
0000707f9fbd71de  vmovaps [rsp+0x20], xmm2
0000707f9fbd71e4  vmovaps [rsp+0x30], xmm3
0000707f9fbd71ea  vmovaps [rsp+0x40], xmm4
0000707f9fbd71f0  vmovaps [rsp+0x50], xmm5
0000707f9fbd71f6  vmovaps [rsp+0x60], xmm6
0000707f9fbd71fc  vmovaps [rsp+0x70], xmm7
0000707f9fbd7202  vmovaps [rsp+0x80], xmm8
0000707f9fbd720b  vmovaps [rsp+0x90], xmm9
0000707f9fbd7214  vmovaps [rsp+0xA0], xmm10
0000707f9fbd721d  vmovaps [rsp+0xB0], xmm11
0000707f9fbd7226  vmovaps [rsp+0xC0], xmm13
0000707f9fbd722f  vmovaps [rsp+0xD0], xmm14
0000707f9fbd7238  vmovaps [rsp+0xE0], xmm15
0000707f9fbd7241  sub rsp, 0x40
0000707f9fbd7245  lea rdi, [rsp]
0000707f9fbd7249  lea rsi, [rsp+0x10]
0000707f9fbd724e  lea rdx, [rsp+0x20]
0000707f9fbd7253  lea rcx, [rsp+0x30]
0000707f9fbd7258  mov r8d, 0x00
0000707f9fbd725e  lea r9, [r15+0x3A8]
0000707f9fbd7265  movaps [rdi], xmm12
0000707f9fbd7269  movaps [rsi], xmm15
0000707f9fbd726d  movaps [rdx], xmm1
0000707f9fbd7270  movaps [rcx], xmm14
0000707f9fbd7274  mov rax, 0x5753922B7A50
0000707f9fbd727e  call rax
0000707f9fbd7280  movaps xmm12, [rsp]
0000707f9fbd7285  add rsp, 0x40
0000707f9fbd7289  vmovaps xmm0, [rsp]
0000707f9fbd728e  vmovaps xmm1, [rsp+0x10]
0000707f9fbd7294  vmovaps xmm2, [rsp+0x20]
0000707f9fbd729a  vmovaps xmm3, [rsp+0x30]
0000707f9fbd72a0  vmovaps xmm4, [rsp+0x40]
0000707f9fbd72a6  vmovaps xmm5, [rsp+0x50]
0000707f9fbd72ac  vmovaps xmm6, [rsp+0x60]
0000707f9fbd72b2  vmovaps xmm7, [rsp+0x70]
0000707f9fbd72b8  vmovaps xmm8, [rsp+0x80]
0000707f9fbd72c1  vmovaps xmm9, [rsp+0x90]
0000707f9fbd72ca  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd72d3  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd72dc  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd72e5  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd72ee  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd72f7  add rsp, 0xF0
0000707f9fbd72fe  pop r11
0000707f9fbd7300  pop r10
0000707f9fbd7302  pop r9
0000707f9fbd7304  pop r8
0000707f9fbd7306  pop rsi
0000707f9fbd7307  pop rdi
0000707f9fbd7308  pop rdx
0000707f9fbd7309  pop rcx
0000707f9fbd730a  pop rax
0000707f9fbd730b  add rsp, 0x08
0000707f9fbd730f  jmp 0x0000707F9FBD64CF
0000707f9fbd7314  sub rsp, 0x08
0000707f9fbd7318  push rax
0000707f9fbd7319  push rcx
0000707f9fbd731a  push rdx
0000707f9fbd731b  push rdi
0000707f9fbd731c  push rsi
0000707f9fbd731d  push r8
0000707f9fbd731f  push r9
0000707f9fbd7321  push r10
0000707f9fbd7323  push r11
0000707f9fbd7325  sub rsp, 0xF0
0000707f9fbd732c  vmovaps [rsp], xmm0
0000707f9fbd7331  vmovaps [rsp+0x10], xmm1
0000707f9fbd7337  vmovaps [rsp+0x20], xmm2
0000707f9fbd733d  vmovaps [rsp+0x30], xmm3
0000707f9fbd7343  vmovaps [rsp+0x40], xmm4
0000707f9fbd7349  vmovaps [rsp+0x50], xmm5
0000707f9fbd734f  vmovaps [rsp+0x60], xmm6
0000707f9fbd7355  vmovaps [rsp+0x70], xmm7
0000707f9fbd735b  vmovaps [rsp+0x80], xmm8
0000707f9fbd7364  vmovaps [rsp+0x90], xmm9
0000707f9fbd736d  vmovaps [rsp+0xA0], xmm10
0000707f9fbd7376  vmovaps [rsp+0xB0], xmm11
0000707f9fbd737f  vmovaps [rsp+0xC0], xmm12
0000707f9fbd7388  vmovaps [rsp+0xD0], xmm14
0000707f9fbd7391  vmovaps [rsp+0xE0], xmm15
0000707f9fbd739a  sub rsp, 0x40
0000707f9fbd739e  lea rdi, [rsp]
0000707f9fbd73a2  lea rsi, [rsp+0x10]
0000707f9fbd73a7  lea rdx, [rsp+0x20]
0000707f9fbd73ac  lea rcx, [rsp+0x30]
0000707f9fbd73b1  mov r8d, 0x00
0000707f9fbd73b7  lea r9, [r15+0x3A8]
0000707f9fbd73be  movaps [rdi], xmm13
0000707f9fbd73c2  movaps [rsi], xmm1
0000707f9fbd73c5  movaps [rdx], xmm15
0000707f9fbd73c9  movaps [rcx], xmm14
0000707f9fbd73cd  mov rax, 0x5753922B7A50
0000707f9fbd73d7  call rax
0000707f9fbd73d9  movaps xmm13, [rsp]
0000707f9fbd73de  add rsp, 0x40
0000707f9fbd73e2  vmovaps xmm0, [rsp]
0000707f9fbd73e7  vmovaps xmm1, [rsp+0x10]
0000707f9fbd73ed  vmovaps xmm2, [rsp+0x20]
0000707f9fbd73f3  vmovaps xmm3, [rsp+0x30]
0000707f9fbd73f9  vmovaps xmm4, [rsp+0x40]
0000707f9fbd73ff  vmovaps xmm5, [rsp+0x50]
0000707f9fbd7405  vmovaps xmm6, [rsp+0x60]
0000707f9fbd740b  vmovaps xmm7, [rsp+0x70]
0000707f9fbd7411  vmovaps xmm8, [rsp+0x80]
0000707f9fbd741a  vmovaps xmm9, [rsp+0x90]
0000707f9fbd7423  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd742c  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd7435  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd743e  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd7447  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd7450  add rsp, 0xF0
0000707f9fbd7457  pop r11
0000707f9fbd7459  pop r10
0000707f9fbd745b  pop r9
0000707f9fbd745d  pop r8
0000707f9fbd745f  pop rsi
0000707f9fbd7460  pop rdi
0000707f9fbd7461  pop rdx
0000707f9fbd7462  pop rcx
0000707f9fbd7463  pop rax
0000707f9fbd7464  add rsp, 0x08
0000707f9fbd7468  jmp 0x0000707F9FBD665F
0000707f9fbd746d  sub rsp, 0x08
0000707f9fbd7471  push rax
0000707f9fbd7472  push rcx
0000707f9fbd7473  push rdx
0000707f9fbd7474  push rdi
0000707f9fbd7475  push rsi
0000707f9fbd7476  push r8
0000707f9fbd7478  push r9
0000707f9fbd747a  push r10
0000707f9fbd747c  push r11
0000707f9fbd747e  sub rsp, 0xF0
0000707f9fbd7485  vmovaps [rsp], xmm0
0000707f9fbd748a  vmovaps [rsp+0x10], xmm1
0000707f9fbd7490  vmovaps [rsp+0x20], xmm2
0000707f9fbd7496  vmovaps [rsp+0x30], xmm3
0000707f9fbd749c  vmovaps [rsp+0x40], xmm4
0000707f9fbd74a2  vmovaps [rsp+0x50], xmm5
0000707f9fbd74a8  vmovaps [rsp+0x60], xmm6
0000707f9fbd74ae  vmovaps [rsp+0x70], xmm7
0000707f9fbd74b4  vmovaps [rsp+0x80], xmm8
0000707f9fbd74bd  vmovaps [rsp+0x90], xmm9
0000707f9fbd74c6  vmovaps [rsp+0xA0], xmm10
0000707f9fbd74cf  vmovaps [rsp+0xB0], xmm11
0000707f9fbd74d8  vmovaps [rsp+0xC0], xmm12
0000707f9fbd74e1  vmovaps [rsp+0xD0], xmm13
0000707f9fbd74ea  vmovaps [rsp+0xE0], xmm15
0000707f9fbd74f3  sub rsp, 0x40
0000707f9fbd74f7  lea rdi, [rsp]
0000707f9fbd74fb  lea rsi, [rsp+0x10]
0000707f9fbd7500  lea rdx, [rsp+0x20]
0000707f9fbd7505  lea rcx, [rsp+0x30]
0000707f9fbd750a  mov r8d, 0x00
0000707f9fbd7510  lea r9, [r15+0x3A8]
0000707f9fbd7517  movaps [rdi], xmm14
0000707f9fbd751b  movaps [rsi], xmm15
0000707f9fbd751f  movaps [rdx], xmm2
0000707f9fbd7522  movaps [rcx], xmm1
0000707f9fbd7525  mov rax, 0x5753922B7A50
0000707f9fbd752f  call rax
0000707f9fbd7531  movaps xmm14, [rsp]
0000707f9fbd7536  add rsp, 0x40
0000707f9fbd753a  vmovaps xmm0, [rsp]
0000707f9fbd753f  vmovaps xmm1, [rsp+0x10]
0000707f9fbd7545  vmovaps xmm2, [rsp+0x20]
0000707f9fbd754b  vmovaps xmm3, [rsp+0x30]
0000707f9fbd7551  vmovaps xmm4, [rsp+0x40]
0000707f9fbd7557  vmovaps xmm5, [rsp+0x50]
0000707f9fbd755d  vmovaps xmm6, [rsp+0x60]
0000707f9fbd7563  vmovaps xmm7, [rsp+0x70]
0000707f9fbd7569  vmovaps xmm8, [rsp+0x80]
0000707f9fbd7572  vmovaps xmm9, [rsp+0x90]
0000707f9fbd757b  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd7584  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd758d  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd7596  vmovaps xmm13, [rsp+0xD0]
0000707f9fbd759f  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd75a8  add rsp, 0xF0
0000707f9fbd75af  pop r11
0000707f9fbd75b1  pop r10
0000707f9fbd75b3  pop r9
0000707f9fbd75b5  pop r8
0000707f9fbd75b7  pop rsi
0000707f9fbd75b8  pop rdi
0000707f9fbd75b9  pop rdx
0000707f9fbd75ba  pop rcx
0000707f9fbd75bb  pop rax
0000707f9fbd75bc  add rsp, 0x08
0000707f9fbd75c0  jmp 0x0000707F9FBD6691
0000707f9fbd75c5  sub rsp, 0x08
0000707f9fbd75c9  push rax
0000707f9fbd75ca  push rcx
0000707f9fbd75cb  push rdx
0000707f9fbd75cc  push rdi
0000707f9fbd75cd  push rsi
0000707f9fbd75ce  push r8
0000707f9fbd75d0  push r9
0000707f9fbd75d2  push r10
0000707f9fbd75d4  push r11
0000707f9fbd75d6  sub rsp, 0xF0
0000707f9fbd75dd  vmovaps [rsp], xmm0
0000707f9fbd75e2  vmovaps [rsp+0x10], xmm1
0000707f9fbd75e8  vmovaps [rsp+0x20], xmm3
0000707f9fbd75ee  vmovaps [rsp+0x30], xmm4
0000707f9fbd75f4  vmovaps [rsp+0x40], xmm5
0000707f9fbd75fa  vmovaps [rsp+0x50], xmm6
0000707f9fbd7600  vmovaps [rsp+0x60], xmm7
0000707f9fbd7606  vmovaps [rsp+0x70], xmm8
0000707f9fbd760c  vmovaps [rsp+0x80], xmm9
0000707f9fbd7615  vmovaps [rsp+0x90], xmm10
0000707f9fbd761e  vmovaps [rsp+0xA0], xmm11
0000707f9fbd7627  vmovaps [rsp+0xB0], xmm12
0000707f9fbd7630  vmovaps [rsp+0xC0], xmm13
0000707f9fbd7639  vmovaps [rsp+0xD0], xmm14
0000707f9fbd7642  vmovaps [rsp+0xE0], xmm15
0000707f9fbd764b  sub rsp, 0x40
0000707f9fbd764f  lea rdi, [rsp]
0000707f9fbd7653  lea rsi, [rsp+0x10]
0000707f9fbd7658  lea rdx, [rsp+0x20]
0000707f9fbd765d  lea rcx, [rsp+0x30]
0000707f9fbd7662  mov r8d, 0x00
0000707f9fbd7668  lea r9, [r15+0x3A8]
0000707f9fbd766f  movaps [rdi], xmm2
0000707f9fbd7672  movaps [rsi], xmm15
0000707f9fbd7676  movaps [rdx], xmm12
0000707f9fbd767a  movaps [rcx], xmm1
0000707f9fbd767d  mov rax, 0x5753922B7A50
0000707f9fbd7687  call rax
0000707f9fbd7689  movaps xmm2, [rsp]
0000707f9fbd768d  add rsp, 0x40
0000707f9fbd7691  vmovaps xmm0, [rsp]
0000707f9fbd7696  vmovaps xmm1, [rsp+0x10]
0000707f9fbd769c  vmovaps xmm3, [rsp+0x20]
0000707f9fbd76a2  vmovaps xmm4, [rsp+0x30]
0000707f9fbd76a8  vmovaps xmm5, [rsp+0x40]
0000707f9fbd76ae  vmovaps xmm6, [rsp+0x50]
0000707f9fbd76b4  vmovaps xmm7, [rsp+0x60]
0000707f9fbd76ba  vmovaps xmm8, [rsp+0x70]
0000707f9fbd76c0  vmovaps xmm9, [rsp+0x80]
0000707f9fbd76c9  vmovaps xmm10, [rsp+0x90]
0000707f9fbd76d2  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd76db  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd76e4  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd76ed  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd76f6  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd76ff  add rsp, 0xF0
0000707f9fbd7706  pop r11
0000707f9fbd7708  pop r10
0000707f9fbd770a  pop r9
0000707f9fbd770c  pop r8
0000707f9fbd770e  pop rsi
0000707f9fbd770f  pop rdi
0000707f9fbd7710  pop rdx
0000707f9fbd7711  pop rcx
0000707f9fbd7712  pop rax
0000707f9fbd7713  add rsp, 0x08
0000707f9fbd7717  jmp 0x0000707F9FBD66CE
0000707f9fbd771c  sub rsp, 0x08
0000707f9fbd7720  push rax
0000707f9fbd7721  push rcx
0000707f9fbd7722  push rdx
0000707f9fbd7723  push rdi
0000707f9fbd7724  push rsi
0000707f9fbd7725  push r8
0000707f9fbd7727  push r9
0000707f9fbd7729  push r10
0000707f9fbd772b  push r11
0000707f9fbd772d  sub rsp, 0xF0
0000707f9fbd7734  vmovaps [rsp], xmm0
0000707f9fbd7739  vmovaps [rsp+0x10], xmm1
0000707f9fbd773f  vmovaps [rsp+0x20], xmm2
0000707f9fbd7745  vmovaps [rsp+0x30], xmm3
0000707f9fbd774b  vmovaps [rsp+0x40], xmm4
0000707f9fbd7751  vmovaps [rsp+0x50], xmm5
0000707f9fbd7757  vmovaps [rsp+0x60], xmm6
0000707f9fbd775d  vmovaps [rsp+0x70], xmm7
0000707f9fbd7763  vmovaps [rsp+0x80], xmm8
0000707f9fbd776c  vmovaps [rsp+0x90], xmm9
0000707f9fbd7775  vmovaps [rsp+0xA0], xmm10
0000707f9fbd777e  vmovaps [rsp+0xB0], xmm11
0000707f9fbd7787  vmovaps [rsp+0xC0], xmm13
0000707f9fbd7790  vmovaps [rsp+0xD0], xmm14
0000707f9fbd7799  vmovaps [rsp+0xE0], xmm15
0000707f9fbd77a2  sub rsp, 0x40
0000707f9fbd77a6  lea rdi, [rsp]
0000707f9fbd77aa  lea rsi, [rsp+0x10]
0000707f9fbd77af  lea rdx, [rsp+0x20]
0000707f9fbd77b4  lea rcx, [rsp+0x30]
0000707f9fbd77b9  mov r8d, 0x00
0000707f9fbd77bf  lea r9, [r15+0x3A8]
0000707f9fbd77c6  movaps [rdi], xmm12
0000707f9fbd77ca  movaps [rsi], xmm14
0000707f9fbd77ce  movaps [rdx], xmm3
0000707f9fbd77d1  movaps [rcx], xmm15
0000707f9fbd77d5  mov rax, 0x5753922B7A50
0000707f9fbd77df  call rax
0000707f9fbd77e1  movaps xmm12, [rsp]
0000707f9fbd77e6  add rsp, 0x40
0000707f9fbd77ea  vmovaps xmm0, [rsp]
0000707f9fbd77ef  vmovaps xmm1, [rsp+0x10]
0000707f9fbd77f5  vmovaps xmm2, [rsp+0x20]
0000707f9fbd77fb  vmovaps xmm3, [rsp+0x30]
0000707f9fbd7801  vmovaps xmm4, [rsp+0x40]
0000707f9fbd7807  vmovaps xmm5, [rsp+0x50]
0000707f9fbd780d  vmovaps xmm6, [rsp+0x60]
0000707f9fbd7813  vmovaps xmm7, [rsp+0x70]
0000707f9fbd7819  vmovaps xmm8, [rsp+0x80]
0000707f9fbd7822  vmovaps xmm9, [rsp+0x90]
0000707f9fbd782b  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd7834  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd783d  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd7846  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd784f  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd7858  add rsp, 0xF0
0000707f9fbd785f  pop r11
0000707f9fbd7861  pop r10
0000707f9fbd7863  pop r9
0000707f9fbd7865  pop r8
0000707f9fbd7867  pop rsi
0000707f9fbd7868  pop rdi
0000707f9fbd7869  pop rdx
0000707f9fbd786a  pop rcx
0000707f9fbd786b  pop rax
0000707f9fbd786c  add rsp, 0x08
0000707f9fbd7870  jmp 0x0000707F9FBD6728
0000707f9fbd7875  sub rsp, 0x08
0000707f9fbd7879  push rax
0000707f9fbd787a  push rcx
0000707f9fbd787b  push rdx
0000707f9fbd787c  push rdi
0000707f9fbd787d  push rsi
0000707f9fbd787e  push r8
0000707f9fbd7880  push r9
0000707f9fbd7882  push r10
0000707f9fbd7884  push r11
0000707f9fbd7886  sub rsp, 0xF0
0000707f9fbd788d  vmovaps [rsp], xmm0
0000707f9fbd7892  vmovaps [rsp+0x10], xmm1
0000707f9fbd7898  vmovaps [rsp+0x20], xmm2
0000707f9fbd789e  vmovaps [rsp+0x30], xmm3
0000707f9fbd78a4  vmovaps [rsp+0x40], xmm4
0000707f9fbd78aa  vmovaps [rsp+0x50], xmm5
0000707f9fbd78b0  vmovaps [rsp+0x60], xmm6
0000707f9fbd78b6  vmovaps [rsp+0x70], xmm7
0000707f9fbd78bc  vmovaps [rsp+0x80], xmm8
0000707f9fbd78c5  vmovaps [rsp+0x90], xmm10
0000707f9fbd78ce  vmovaps [rsp+0xA0], xmm11
0000707f9fbd78d7  vmovaps [rsp+0xB0], xmm12
0000707f9fbd78e0  vmovaps [rsp+0xC0], xmm13
0000707f9fbd78e9  vmovaps [rsp+0xD0], xmm14
0000707f9fbd78f2  vmovaps [rsp+0xE0], xmm15
0000707f9fbd78fb  sub rsp, 0x40
0000707f9fbd78ff  lea rdi, [rsp]
0000707f9fbd7903  lea rsi, [rsp+0x10]
0000707f9fbd7908  lea rdx, [rsp+0x20]
0000707f9fbd790d  lea rcx, [rsp+0x30]
0000707f9fbd7912  mov r8d, 0x00
0000707f9fbd7918  lea r9, [r15+0x3A8]
0000707f9fbd791f  movaps [rdi], xmm9
0000707f9fbd7923  movaps [rsi], xmm13
0000707f9fbd7927  movaps [rdx], xmm14
0000707f9fbd792b  movaps [rcx], xmm6
0000707f9fbd792e  mov rax, 0x5753922B7A50
0000707f9fbd7938  call rax
0000707f9fbd793a  movaps xmm9, [rsp]
0000707f9fbd793f  add rsp, 0x40
0000707f9fbd7943  vmovaps xmm0, [rsp]
0000707f9fbd7948  vmovaps xmm1, [rsp+0x10]
0000707f9fbd794e  vmovaps xmm2, [rsp+0x20]
0000707f9fbd7954  vmovaps xmm3, [rsp+0x30]
0000707f9fbd795a  vmovaps xmm4, [rsp+0x40]
0000707f9fbd7960  vmovaps xmm5, [rsp+0x50]
0000707f9fbd7966  vmovaps xmm6, [rsp+0x60]
0000707f9fbd796c  vmovaps xmm7, [rsp+0x70]
0000707f9fbd7972  vmovaps xmm8, [rsp+0x80]
0000707f9fbd797b  vmovaps xmm10, [rsp+0x90]
0000707f9fbd7984  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd798d  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd7996  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd799f  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd79a8  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd79b1  add rsp, 0xF0
0000707f9fbd79b8  pop r11
0000707f9fbd79ba  pop r10
0000707f9fbd79bc  pop r9
0000707f9fbd79be  pop r8
0000707f9fbd79c0  pop rsi
0000707f9fbd79c1  pop rdi
0000707f9fbd79c2  pop rdx
0000707f9fbd79c3  pop rcx
0000707f9fbd79c4  pop rax
0000707f9fbd79c5  add rsp, 0x08
0000707f9fbd79c9  jmp 0x0000707F9FBD67D2
0000707f9fbd79ce  sub rsp, 0x08
0000707f9fbd79d2  push rax
0000707f9fbd79d3  push rcx
0000707f9fbd79d4  push rdx
0000707f9fbd79d5  push rdi
0000707f9fbd79d6  push rsi
0000707f9fbd79d7  push r8
0000707f9fbd79d9  push r9
0000707f9fbd79db  push r10
0000707f9fbd79dd  push r11
0000707f9fbd79df  sub rsp, 0xF0
0000707f9fbd79e6  vmovaps [rsp], xmm0
0000707f9fbd79eb  vmovaps [rsp+0x10], xmm1
0000707f9fbd79f1  vmovaps [rsp+0x20], xmm2
0000707f9fbd79f7  vmovaps [rsp+0x30], xmm4
0000707f9fbd79fd  vmovaps [rsp+0x40], xmm5
0000707f9fbd7a03  vmovaps [rsp+0x50], xmm6
0000707f9fbd7a09  vmovaps [rsp+0x60], xmm7
0000707f9fbd7a0f  vmovaps [rsp+0x70], xmm8
0000707f9fbd7a15  vmovaps [rsp+0x80], xmm9
0000707f9fbd7a1e  vmovaps [rsp+0x90], xmm10
0000707f9fbd7a27  vmovaps [rsp+0xA0], xmm11
0000707f9fbd7a30  vmovaps [rsp+0xB0], xmm12
0000707f9fbd7a39  vmovaps [rsp+0xC0], xmm13
0000707f9fbd7a42  vmovaps [rsp+0xD0], xmm14
0000707f9fbd7a4b  vmovaps [rsp+0xE0], xmm15
0000707f9fbd7a54  sub rsp, 0x40
0000707f9fbd7a58  lea rdi, [rsp]
0000707f9fbd7a5c  lea rsi, [rsp+0x10]
0000707f9fbd7a61  lea rdx, [rsp+0x20]
0000707f9fbd7a66  lea rcx, [rsp+0x30]
0000707f9fbd7a6b  mov r8d, 0x00
0000707f9fbd7a71  lea r9, [r15+0x3A8]
0000707f9fbd7a78  movaps [rdi], xmm3
0000707f9fbd7a7b  movaps [rsi], xmm13
0000707f9fbd7a7f  movaps [rdx], xmm6
0000707f9fbd7a82  movaps [rcx], xmm14
0000707f9fbd7a86  mov rax, 0x5753922B7A50
0000707f9fbd7a90  call rax
0000707f9fbd7a92  movaps xmm3, [rsp]
0000707f9fbd7a96  add rsp, 0x40
0000707f9fbd7a9a  vmovaps xmm0, [rsp]
0000707f9fbd7a9f  vmovaps xmm1, [rsp+0x10]
0000707f9fbd7aa5  vmovaps xmm2, [rsp+0x20]
0000707f9fbd7aab  vmovaps xmm4, [rsp+0x30]
0000707f9fbd7ab1  vmovaps xmm5, [rsp+0x40]
0000707f9fbd7ab7  vmovaps xmm6, [rsp+0x50]
0000707f9fbd7abd  vmovaps xmm7, [rsp+0x60]
0000707f9fbd7ac3  vmovaps xmm8, [rsp+0x70]
0000707f9fbd7ac9  vmovaps xmm9, [rsp+0x80]
0000707f9fbd7ad2  vmovaps xmm10, [rsp+0x90]
0000707f9fbd7adb  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd7ae4  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd7aed  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd7af6  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd7aff  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd7b08  add rsp, 0xF0
0000707f9fbd7b0f  pop r11
0000707f9fbd7b11  pop r10
0000707f9fbd7b13  pop r9
0000707f9fbd7b15  pop r8
0000707f9fbd7b17  pop rsi
0000707f9fbd7b18  pop rdi
0000707f9fbd7b19  pop rdx
0000707f9fbd7b1a  pop rcx
0000707f9fbd7b1b  pop rax
0000707f9fbd7b1c  add rsp, 0x08
0000707f9fbd7b20  jmp 0x0000707F9FBD680F
0000707f9fbd7b25  sub rsp, 0x08
0000707f9fbd7b29  push rax
0000707f9fbd7b2a  push rcx
0000707f9fbd7b2b  push rdx
0000707f9fbd7b2c  push rdi
0000707f9fbd7b2d  push rsi
0000707f9fbd7b2e  push r8
0000707f9fbd7b30  push r9
0000707f9fbd7b32  push r10
0000707f9fbd7b34  push r11
0000707f9fbd7b36  sub rsp, 0xF0
0000707f9fbd7b3d  vmovaps [rsp], xmm0
0000707f9fbd7b42  vmovaps [rsp+0x10], xmm1
0000707f9fbd7b48  vmovaps [rsp+0x20], xmm2
0000707f9fbd7b4e  vmovaps [rsp+0x30], xmm3
0000707f9fbd7b54  vmovaps [rsp+0x40], xmm4
0000707f9fbd7b5a  vmovaps [rsp+0x50], xmm5
0000707f9fbd7b60  vmovaps [rsp+0x60], xmm7
0000707f9fbd7b66  vmovaps [rsp+0x70], xmm8
0000707f9fbd7b6c  vmovaps [rsp+0x80], xmm9
0000707f9fbd7b75  vmovaps [rsp+0x90], xmm10
0000707f9fbd7b7e  vmovaps [rsp+0xA0], xmm11
0000707f9fbd7b87  vmovaps [rsp+0xB0], xmm12
0000707f9fbd7b90  vmovaps [rsp+0xC0], xmm13
0000707f9fbd7b99  vmovaps [rsp+0xD0], xmm14
0000707f9fbd7ba2  vmovaps [rsp+0xE0], xmm15
0000707f9fbd7bab  sub rsp, 0x40
0000707f9fbd7baf  lea rdi, [rsp]
0000707f9fbd7bb3  lea rsi, [rsp+0x10]
0000707f9fbd7bb8  lea rdx, [rsp+0x20]
0000707f9fbd7bbd  lea rcx, [rsp+0x30]
0000707f9fbd7bc2  mov r8d, 0x00
0000707f9fbd7bc8  lea r9, [r15+0x3A8]
0000707f9fbd7bcf  movaps [rdi], xmm6
0000707f9fbd7bd2  movaps [rsi], xmm2
0000707f9fbd7bd5  movaps [rdx], xmm14
0000707f9fbd7bd9  movaps [rcx], xmm1
0000707f9fbd7bdc  mov rax, 0x5753922B7A50
0000707f9fbd7be6  call rax
0000707f9fbd7be8  movaps xmm6, [rsp]
0000707f9fbd7bec  add rsp, 0x40
0000707f9fbd7bf0  vmovaps xmm0, [rsp]
0000707f9fbd7bf5  vmovaps xmm1, [rsp+0x10]
0000707f9fbd7bfb  vmovaps xmm2, [rsp+0x20]
0000707f9fbd7c01  vmovaps xmm3, [rsp+0x30]
0000707f9fbd7c07  vmovaps xmm4, [rsp+0x40]
0000707f9fbd7c0d  vmovaps xmm5, [rsp+0x50]
0000707f9fbd7c13  vmovaps xmm7, [rsp+0x60]
0000707f9fbd7c19  vmovaps xmm8, [rsp+0x70]
0000707f9fbd7c1f  vmovaps xmm9, [rsp+0x80]
0000707f9fbd7c28  vmovaps xmm10, [rsp+0x90]
0000707f9fbd7c31  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd7c3a  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd7c43  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd7c4c  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd7c55  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd7c5e  add rsp, 0xF0
0000707f9fbd7c65  pop r11
0000707f9fbd7c67  pop r10
0000707f9fbd7c69  pop r9
0000707f9fbd7c6b  pop r8
0000707f9fbd7c6d  pop rsi
0000707f9fbd7c6e  pop rdi
0000707f9fbd7c6f  pop rdx
0000707f9fbd7c70  pop rcx
0000707f9fbd7c71  pop rax
0000707f9fbd7c72  add rsp, 0x08
0000707f9fbd7c76  jmp 0x0000707F9FBD683C
0000707f9fbd7c7b  sub rsp, 0x08
0000707f9fbd7c7f  push rax
0000707f9fbd7c80  push rcx
0000707f9fbd7c81  push rdx
0000707f9fbd7c82  push rdi
0000707f9fbd7c83  push rsi
0000707f9fbd7c84  push r8
0000707f9fbd7c86  push r9
0000707f9fbd7c88  push r10
0000707f9fbd7c8a  push r11
0000707f9fbd7c8c  sub rsp, 0xF0
0000707f9fbd7c93  vmovaps [rsp], xmm0
0000707f9fbd7c98  vmovaps [rsp+0x10], xmm1
0000707f9fbd7c9e  vmovaps [rsp+0x20], xmm2
0000707f9fbd7ca4  vmovaps [rsp+0x30], xmm3
0000707f9fbd7caa  vmovaps [rsp+0x40], xmm4
0000707f9fbd7cb0  vmovaps [rsp+0x50], xmm5
0000707f9fbd7cb6  vmovaps [rsp+0x60], xmm6
0000707f9fbd7cbc  vmovaps [rsp+0x70], xmm7
0000707f9fbd7cc2  vmovaps [rsp+0x80], xmm8
0000707f9fbd7ccb  vmovaps [rsp+0x90], xmm9
0000707f9fbd7cd4  vmovaps [rsp+0xA0], xmm10
0000707f9fbd7cdd  vmovaps [rsp+0xB0], xmm11
0000707f9fbd7ce6  vmovaps [rsp+0xC0], xmm12
0000707f9fbd7cef  vmovaps [rsp+0xD0], xmm14
0000707f9fbd7cf8  vmovaps [rsp+0xE0], xmm15
0000707f9fbd7d01  sub rsp, 0x40
0000707f9fbd7d05  lea rdi, [rsp]
0000707f9fbd7d09  lea rsi, [rsp+0x10]
0000707f9fbd7d0e  lea rdx, [rsp+0x20]
0000707f9fbd7d13  lea rcx, [rsp+0x30]
0000707f9fbd7d18  mov r8d, 0x00
0000707f9fbd7d1e  lea r9, [r15+0x3A8]
0000707f9fbd7d25  movaps [rdi], xmm13
0000707f9fbd7d29  movaps [rsi], xmm12
0000707f9fbd7d2d  movaps [rdx], xmm14
0000707f9fbd7d31  movaps [rcx], xmm1
0000707f9fbd7d34  mov rax, 0x5753922B7A50
0000707f9fbd7d3e  call rax
0000707f9fbd7d40  movaps xmm13, [rsp]
0000707f9fbd7d45  add rsp, 0x40
0000707f9fbd7d49  vmovaps xmm0, [rsp]
0000707f9fbd7d4e  vmovaps xmm1, [rsp+0x10]
0000707f9fbd7d54  vmovaps xmm2, [rsp+0x20]
0000707f9fbd7d5a  vmovaps xmm3, [rsp+0x30]
0000707f9fbd7d60  vmovaps xmm4, [rsp+0x40]
0000707f9fbd7d66  vmovaps xmm5, [rsp+0x50]
0000707f9fbd7d6c  vmovaps xmm6, [rsp+0x60]
0000707f9fbd7d72  vmovaps xmm7, [rsp+0x70]
0000707f9fbd7d78  vmovaps xmm8, [rsp+0x80]
0000707f9fbd7d81  vmovaps xmm9, [rsp+0x90]
0000707f9fbd7d8a  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd7d93  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd7d9c  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd7da5  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd7dae  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd7db7  add rsp, 0xF0
0000707f9fbd7dbe  pop r11
0000707f9fbd7dc0  pop r10
0000707f9fbd7dc2  pop r9
0000707f9fbd7dc4  pop r8
0000707f9fbd7dc6  pop rsi
0000707f9fbd7dc7  pop rdi
0000707f9fbd7dc8  pop rdx
0000707f9fbd7dc9  pop rcx
0000707f9fbd7dca  pop rax
0000707f9fbd7dcb  add rsp, 0x08
0000707f9fbd7dcf  jmp 0x0000707F9FBD686E
0000707f9fbd7dd4  sub rsp, 0x08
0000707f9fbd7dd8  push rax
0000707f9fbd7dd9  push rcx
0000707f9fbd7dda  push rdx
0000707f9fbd7ddb  push rdi
0000707f9fbd7ddc  push rsi
0000707f9fbd7ddd  push r8
0000707f9fbd7ddf  push r9
0000707f9fbd7de1  push r10
0000707f9fbd7de3  push r11
0000707f9fbd7de5  sub rsp, 0xF0
0000707f9fbd7dec  vmovaps [rsp], xmm0
0000707f9fbd7df1  vmovaps [rsp+0x10], xmm1
0000707f9fbd7df7  vmovaps [rsp+0x20], xmm2
0000707f9fbd7dfd  vmovaps [rsp+0x30], xmm3
0000707f9fbd7e03  vmovaps [rsp+0x40], xmm4
0000707f9fbd7e09  vmovaps [rsp+0x50], xmm5
0000707f9fbd7e0f  vmovaps [rsp+0x60], xmm6
0000707f9fbd7e15  vmovaps [rsp+0x70], xmm7
0000707f9fbd7e1b  vmovaps [rsp+0x80], xmm8
0000707f9fbd7e24  vmovaps [rsp+0x90], xmm9
0000707f9fbd7e2d  vmovaps [rsp+0xA0], xmm10
0000707f9fbd7e36  vmovaps [rsp+0xB0], xmm11
0000707f9fbd7e3f  vmovaps [rsp+0xC0], xmm13
0000707f9fbd7e48  vmovaps [rsp+0xD0], xmm14
0000707f9fbd7e51  vmovaps [rsp+0xE0], xmm15
0000707f9fbd7e5a  sub rsp, 0x40
0000707f9fbd7e5e  lea rdi, [rsp]
0000707f9fbd7e62  lea rsi, [rsp+0x10]
0000707f9fbd7e67  lea rdx, [rsp+0x20]
0000707f9fbd7e6c  lea rcx, [rsp+0x30]
0000707f9fbd7e71  mov r8d, 0x00
0000707f9fbd7e77  lea r9, [r15+0x3A8]
0000707f9fbd7e7e  movaps [rdi], xmm12
0000707f9fbd7e82  movaps [rsi], xmm3
0000707f9fbd7e85  movaps [rdx], xmm14
0000707f9fbd7e89  movaps [rcx], xmm5
0000707f9fbd7e8c  mov rax, 0x5753922B7A50
0000707f9fbd7e96  call rax
0000707f9fbd7e98  movaps xmm12, [rsp]
0000707f9fbd7e9d  add rsp, 0x40
0000707f9fbd7ea1  vmovaps xmm0, [rsp]
0000707f9fbd7ea6  vmovaps xmm1, [rsp+0x10]
0000707f9fbd7eac  vmovaps xmm2, [rsp+0x20]
0000707f9fbd7eb2  vmovaps xmm3, [rsp+0x30]
0000707f9fbd7eb8  vmovaps xmm4, [rsp+0x40]
0000707f9fbd7ebe  vmovaps xmm5, [rsp+0x50]
0000707f9fbd7ec4  vmovaps xmm6, [rsp+0x60]
0000707f9fbd7eca  vmovaps xmm7, [rsp+0x70]
0000707f9fbd7ed0  vmovaps xmm8, [rsp+0x80]
0000707f9fbd7ed9  vmovaps xmm9, [rsp+0x90]
0000707f9fbd7ee2  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd7eeb  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd7ef4  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd7efd  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd7f06  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd7f0f  add rsp, 0xF0
0000707f9fbd7f16  pop r11
0000707f9fbd7f18  pop r10
0000707f9fbd7f1a  pop r9
0000707f9fbd7f1c  pop r8
0000707f9fbd7f1e  pop rsi
0000707f9fbd7f1f  pop rdi
0000707f9fbd7f20  pop rdx
0000707f9fbd7f21  pop rcx
0000707f9fbd7f22  pop rax
0000707f9fbd7f23  add rsp, 0x08
0000707f9fbd7f27  jmp 0x0000707F9FBD68CB
0000707f9fbd7f2c  sub rsp, 0x08
0000707f9fbd7f30  push rax
0000707f9fbd7f31  push rcx
0000707f9fbd7f32  push rdx
0000707f9fbd7f33  push rdi
0000707f9fbd7f34  push rsi
0000707f9fbd7f35  push r8
0000707f9fbd7f37  push r9
0000707f9fbd7f39  push r10
0000707f9fbd7f3b  push r11
0000707f9fbd7f3d  sub rsp, 0xF0
0000707f9fbd7f44  vmovaps [rsp], xmm0
0000707f9fbd7f49  vmovaps [rsp+0x10], xmm1
0000707f9fbd7f4f  vmovaps [rsp+0x20], xmm2
0000707f9fbd7f55  vmovaps [rsp+0x30], xmm3
0000707f9fbd7f5b  vmovaps [rsp+0x40], xmm4
0000707f9fbd7f61  vmovaps [rsp+0x50], xmm5
0000707f9fbd7f67  vmovaps [rsp+0x60], xmm6
0000707f9fbd7f6d  vmovaps [rsp+0x70], xmm7
0000707f9fbd7f73  vmovaps [rsp+0x80], xmm8
0000707f9fbd7f7c  vmovaps [rsp+0x90], xmm9
0000707f9fbd7f85  vmovaps [rsp+0xA0], xmm11
0000707f9fbd7f8e  vmovaps [rsp+0xB0], xmm12
0000707f9fbd7f97  vmovaps [rsp+0xC0], xmm13
0000707f9fbd7fa0  vmovaps [rsp+0xD0], xmm14
0000707f9fbd7fa9  vmovaps [rsp+0xE0], xmm15
0000707f9fbd7fb2  sub rsp, 0x40
0000707f9fbd7fb6  lea rdi, [rsp]
0000707f9fbd7fba  lea rsi, [rsp+0x10]
0000707f9fbd7fbf  lea rdx, [rsp+0x20]
0000707f9fbd7fc4  lea rcx, [rsp+0x30]
0000707f9fbd7fc9  mov r8d, 0x00
0000707f9fbd7fcf  lea r9, [r15+0x3A8]
0000707f9fbd7fd6  movaps [rdi], xmm10
0000707f9fbd7fda  movaps [rsi], xmm9
0000707f9fbd7fde  movaps [rdx], xmm7
0000707f9fbd7fe1  movaps [rcx], xmm14
0000707f9fbd7fe5  mov rax, 0x5753922B7A50
0000707f9fbd7fef  call rax
0000707f9fbd7ff1  movaps xmm10, [rsp]
0000707f9fbd7ff6  add rsp, 0x40
0000707f9fbd7ffa  vmovaps xmm0, [rsp]
0000707f9fbd7fff  vmovaps xmm1, [rsp+0x10]
0000707f9fbd8005  vmovaps xmm2, [rsp+0x20]
0000707f9fbd800b  vmovaps xmm3, [rsp+0x30]
0000707f9fbd8011  vmovaps xmm4, [rsp+0x40]
0000707f9fbd8017  vmovaps xmm5, [rsp+0x50]
0000707f9fbd801d  vmovaps xmm6, [rsp+0x60]
0000707f9fbd8023  vmovaps xmm7, [rsp+0x70]
0000707f9fbd8029  vmovaps xmm8, [rsp+0x80]
0000707f9fbd8032  vmovaps xmm9, [rsp+0x90]
0000707f9fbd803b  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd8044  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd804d  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd8056  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd805f  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd8068  add rsp, 0xF0
0000707f9fbd806f  pop r11
0000707f9fbd8071  pop r10
0000707f9fbd8073  pop r9
0000707f9fbd8075  pop r8
0000707f9fbd8077  pop rsi
0000707f9fbd8078  pop rdi
0000707f9fbd8079  pop rdx
0000707f9fbd807a  pop rcx
0000707f9fbd807b  pop rax
0000707f9fbd807c  add rsp, 0x08
0000707f9fbd8080  jmp 0x0000707F9FBD68F1
0000707f9fbd8085  call 0x0000707F9FAE45A0
0000707f9fbd808a  jmp 0x0000707F9FBD68FE
0000707f9fbd808f  sub rsp, 0x08
0000707f9fbd8093  push rax
0000707f9fbd8094  push rcx
0000707f9fbd8095  push rdx
0000707f9fbd8096  push rdi
0000707f9fbd8097  push rsi
0000707f9fbd8098  push r8
0000707f9fbd809a  push r9
0000707f9fbd809c  push r10
0000707f9fbd809e  push r11
0000707f9fbd80a0  sub rsp, 0xF0
0000707f9fbd80a7  vmovaps [rsp], xmm0
0000707f9fbd80ac  vmovaps [rsp+0x10], xmm1
0000707f9fbd80b2  vmovaps [rsp+0x20], xmm2
0000707f9fbd80b8  vmovaps [rsp+0x30], xmm3
0000707f9fbd80be  vmovaps [rsp+0x40], xmm4
0000707f9fbd80c4  vmovaps [rsp+0x50], xmm6
0000707f9fbd80ca  vmovaps [rsp+0x60], xmm7
0000707f9fbd80d0  vmovaps [rsp+0x70], xmm8
0000707f9fbd80d6  vmovaps [rsp+0x80], xmm9
0000707f9fbd80df  vmovaps [rsp+0x90], xmm10
0000707f9fbd80e8  vmovaps [rsp+0xA0], xmm11
0000707f9fbd80f1  vmovaps [rsp+0xB0], xmm12
0000707f9fbd80fa  vmovaps [rsp+0xC0], xmm13
0000707f9fbd8103  vmovaps [rsp+0xD0], xmm14
0000707f9fbd810c  vmovaps [rsp+0xE0], xmm15
0000707f9fbd8115  sub rsp, 0x40
0000707f9fbd8119  lea rdi, [rsp]
0000707f9fbd811d  lea rsi, [rsp+0x10]
0000707f9fbd8122  lea rdx, [rsp+0x20]
0000707f9fbd8127  lea rcx, [rsp+0x30]
0000707f9fbd812c  mov r8d, 0x00
0000707f9fbd8132  lea r9, [r15+0x3A8]
0000707f9fbd8139  movaps [rdi], xmm5
0000707f9fbd813c  movaps [rsi], xmm6
0000707f9fbd813f  movaps [rdx], xmm7
0000707f9fbd8142  movaps [rcx], xmm9
0000707f9fbd8146  mov rax, 0x5753922B7A50
0000707f9fbd8150  call rax
0000707f9fbd8152  movaps xmm5, [rsp]
0000707f9fbd8156  add rsp, 0x40
0000707f9fbd815a  vmovaps xmm0, [rsp]
0000707f9fbd815f  vmovaps xmm1, [rsp+0x10]
0000707f9fbd8165  vmovaps xmm2, [rsp+0x20]
0000707f9fbd816b  vmovaps xmm3, [rsp+0x30]
0000707f9fbd8171  vmovaps xmm4, [rsp+0x40]
0000707f9fbd8177  vmovaps xmm6, [rsp+0x50]
0000707f9fbd817d  vmovaps xmm7, [rsp+0x60]
0000707f9fbd8183  vmovaps xmm8, [rsp+0x70]
0000707f9fbd8189  vmovaps xmm9, [rsp+0x80]
0000707f9fbd8192  vmovaps xmm10, [rsp+0x90]
0000707f9fbd819b  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd81a4  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd81ad  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd81b6  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd81bf  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd81c8  add rsp, 0xF0
0000707f9fbd81cf  pop r11
0000707f9fbd81d1  pop r10
0000707f9fbd81d3  pop r9
0000707f9fbd81d5  pop r8
0000707f9fbd81d7  pop rsi
0000707f9fbd81d8  pop rdi
0000707f9fbd81d9  pop rdx
0000707f9fbd81da  pop rcx
0000707f9fbd81db  pop rax
0000707f9fbd81dc  add rsp, 0x08
0000707f9fbd81e0  jmp 0x0000707F9FBD6930
0000707f9fbd81e5  sub rsp, 0x08
0000707f9fbd81e9  push rax
0000707f9fbd81ea  push rcx
0000707f9fbd81eb  push rdx
0000707f9fbd81ec  push rdi
0000707f9fbd81ed  push rsi
0000707f9fbd81ee  push r8
0000707f9fbd81f0  push r9
0000707f9fbd81f2  push r10
0000707f9fbd81f4  push r11
0000707f9fbd81f6  sub rsp, 0xF0
0000707f9fbd81fd  vmovaps [rsp], xmm0
0000707f9fbd8202  vmovaps [rsp+0x10], xmm1
0000707f9fbd8208  vmovaps [rsp+0x20], xmm2
0000707f9fbd820e  vmovaps [rsp+0x30], xmm3
0000707f9fbd8214  vmovaps [rsp+0x40], xmm4
0000707f9fbd821a  vmovaps [rsp+0x50], xmm5
0000707f9fbd8220  vmovaps [rsp+0x60], xmm6
0000707f9fbd8226  vmovaps [rsp+0x70], xmm8
0000707f9fbd822c  vmovaps [rsp+0x80], xmm9
0000707f9fbd8235  vmovaps [rsp+0x90], xmm10
0000707f9fbd823e  vmovaps [rsp+0xA0], xmm11
0000707f9fbd8247  vmovaps [rsp+0xB0], xmm12
0000707f9fbd8250  vmovaps [rsp+0xC0], xmm13
0000707f9fbd8259  vmovaps [rsp+0xD0], xmm14
0000707f9fbd8262  vmovaps [rsp+0xE0], xmm15
0000707f9fbd826b  sub rsp, 0x40
0000707f9fbd826f  lea rdi, [rsp]
0000707f9fbd8273  lea rsi, [rsp+0x10]
0000707f9fbd8278  lea rdx, [rsp+0x20]
0000707f9fbd827d  lea rcx, [rsp+0x30]
0000707f9fbd8282  mov r8d, 0x00
0000707f9fbd8288  lea r9, [r15+0x3A8]
0000707f9fbd828f  movaps [rdi], xmm7
0000707f9fbd8292  movaps [rsi], xmm13
0000707f9fbd8296  movaps [rdx], xmm1
0000707f9fbd8299  movaps [rcx], xmm9
0000707f9fbd829d  mov rax, 0x5753922B7A50
0000707f9fbd82a7  call rax
0000707f9fbd82a9  movaps xmm7, [rsp]
0000707f9fbd82ad  add rsp, 0x40
0000707f9fbd82b1  vmovaps xmm0, [rsp]
0000707f9fbd82b6  vmovaps xmm1, [rsp+0x10]
0000707f9fbd82bc  vmovaps xmm2, [rsp+0x20]
0000707f9fbd82c2  vmovaps xmm3, [rsp+0x30]
0000707f9fbd82c8  vmovaps xmm4, [rsp+0x40]
0000707f9fbd82ce  vmovaps xmm5, [rsp+0x50]
0000707f9fbd82d4  vmovaps xmm6, [rsp+0x60]
0000707f9fbd82da  vmovaps xmm8, [rsp+0x70]
0000707f9fbd82e0  vmovaps xmm9, [rsp+0x80]
0000707f9fbd82e9  vmovaps xmm10, [rsp+0x90]
0000707f9fbd82f2  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd82fb  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd8304  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd830d  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd8316  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd831f  add rsp, 0xF0
0000707f9fbd8326  pop r11
0000707f9fbd8328  pop r10
0000707f9fbd832a  pop r9
0000707f9fbd832c  pop r8
0000707f9fbd832e  pop rsi
0000707f9fbd832f  pop rdi
0000707f9fbd8330  pop rdx
0000707f9fbd8331  pop rcx
0000707f9fbd8332  pop rax
0000707f9fbd8333  add rsp, 0x08
0000707f9fbd8337  jmp 0x0000707F9FBD6955
0000707f9fbd833c  call 0x0000707F9FAE3320
0000707f9fbd8341  jmp 0x0000707F9FBD6978
0000707f9fbd8346  call 0x0000707F9FADE950
0000707f9fbd834b  jmp 0x0000707F9FBD6982
0000707f9fbd8350  sub rsp, 0x08
0000707f9fbd8354  push rax
0000707f9fbd8355  push rcx
0000707f9fbd8356  push rdx
0000707f9fbd8357  push rdi
0000707f9fbd8358  push rsi
0000707f9fbd8359  push r8
0000707f9fbd835b  push r9
0000707f9fbd835d  push r10
0000707f9fbd835f  push r11
0000707f9fbd8361  sub rsp, 0xF0
0000707f9fbd8368  vmovaps [rsp], xmm0
0000707f9fbd836d  vmovaps [rsp+0x10], xmm1
0000707f9fbd8373  vmovaps [rsp+0x20], xmm3
0000707f9fbd8379  vmovaps [rsp+0x30], xmm4
0000707f9fbd837f  vmovaps [rsp+0x40], xmm5
0000707f9fbd8385  vmovaps [rsp+0x50], xmm6
0000707f9fbd838b  vmovaps [rsp+0x60], xmm7
0000707f9fbd8391  vmovaps [rsp+0x70], xmm8
0000707f9fbd8397  vmovaps [rsp+0x80], xmm9
0000707f9fbd83a0  vmovaps [rsp+0x90], xmm10
0000707f9fbd83a9  vmovaps [rsp+0xA0], xmm11
0000707f9fbd83b2  vmovaps [rsp+0xB0], xmm12
0000707f9fbd83bb  vmovaps [rsp+0xC0], xmm13
0000707f9fbd83c4  vmovaps [rsp+0xD0], xmm14
0000707f9fbd83cd  vmovaps [rsp+0xE0], xmm15
0000707f9fbd83d6  sub rsp, 0x40
0000707f9fbd83da  lea rdi, [rsp]
0000707f9fbd83de  lea rsi, [rsp+0x10]
0000707f9fbd83e3  lea rdx, [rsp+0x20]
0000707f9fbd83e8  lea rcx, [rsp+0x30]
0000707f9fbd83ed  mov r8d, 0x00
0000707f9fbd83f3  lea r9, [r15+0x3A8]
0000707f9fbd83fa  movaps [rdi], xmm2
0000707f9fbd83fd  movaps [rsi], xmm12
0000707f9fbd8401  movaps [rdx], xmm6
0000707f9fbd8404  movaps [rcx], xmm3
0000707f9fbd8407  mov rax, 0x5753922B7A50
0000707f9fbd8411  call rax
0000707f9fbd8413  movaps xmm2, [rsp]
0000707f9fbd8417  add rsp, 0x40
0000707f9fbd841b  vmovaps xmm0, [rsp]
0000707f9fbd8420  vmovaps xmm1, [rsp+0x10]
0000707f9fbd8426  vmovaps xmm3, [rsp+0x20]
0000707f9fbd842c  vmovaps xmm4, [rsp+0x30]
0000707f9fbd8432  vmovaps xmm5, [rsp+0x40]
0000707f9fbd8438  vmovaps xmm6, [rsp+0x50]
0000707f9fbd843e  vmovaps xmm7, [rsp+0x60]
0000707f9fbd8444  vmovaps xmm8, [rsp+0x70]
0000707f9fbd844a  vmovaps xmm9, [rsp+0x80]
0000707f9fbd8453  vmovaps xmm10, [rsp+0x90]
0000707f9fbd845c  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd8465  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd846e  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd8477  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd8480  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd8489  add rsp, 0xF0
0000707f9fbd8490  pop r11
0000707f9fbd8492  pop r10
0000707f9fbd8494  pop r9
0000707f9fbd8496  pop r8
0000707f9fbd8498  pop rsi
0000707f9fbd8499  pop rdi
0000707f9fbd849a  pop rdx
0000707f9fbd849b  pop rcx
0000707f9fbd849c  pop rax
0000707f9fbd849d  add rsp, 0x08
0000707f9fbd84a1  jmp 0x0000707F9FBD69C8
0000707f9fbd84a6  sub rsp, 0x08
0000707f9fbd84aa  push rax
0000707f9fbd84ab  push rcx
0000707f9fbd84ac  push rdx
0000707f9fbd84ad  push rdi
0000707f9fbd84ae  push rsi
0000707f9fbd84af  push r8
0000707f9fbd84b1  push r9
0000707f9fbd84b3  push r10
0000707f9fbd84b5  push r11
0000707f9fbd84b7  sub rsp, 0xF0
0000707f9fbd84be  vmovaps [rsp], xmm0
0000707f9fbd84c3  vmovaps [rsp+0x10], xmm1
0000707f9fbd84c9  vmovaps [rsp+0x20], xmm2
0000707f9fbd84cf  vmovaps [rsp+0x30], xmm3
0000707f9fbd84d5  vmovaps [rsp+0x40], xmm4
0000707f9fbd84db  vmovaps [rsp+0x50], xmm5
0000707f9fbd84e1  vmovaps [rsp+0x60], xmm7
0000707f9fbd84e7  vmovaps [rsp+0x70], xmm8
0000707f9fbd84ed  vmovaps [rsp+0x80], xmm9
0000707f9fbd84f6  vmovaps [rsp+0x90], xmm10
0000707f9fbd84ff  vmovaps [rsp+0xA0], xmm11
0000707f9fbd8508  vmovaps [rsp+0xB0], xmm12
0000707f9fbd8511  vmovaps [rsp+0xC0], xmm13
0000707f9fbd851a  vmovaps [rsp+0xD0], xmm14
0000707f9fbd8523  vmovaps [rsp+0xE0], xmm15
0000707f9fbd852c  sub rsp, 0x40
0000707f9fbd8530  lea rdi, [rsp]
0000707f9fbd8534  lea rsi, [rsp+0x10]
0000707f9fbd8539  lea rdx, [rsp+0x20]
0000707f9fbd853e  lea rcx, [rsp+0x30]
0000707f9fbd8543  mov r8d, 0x00
0000707f9fbd8549  lea r9, [r15+0x3A8]
0000707f9fbd8550  movaps [rdi], xmm6
0000707f9fbd8553  movaps [rsi], xmm10
0000707f9fbd8557  movaps [rdx], xmm12
0000707f9fbd855b  movaps [rcx], xmm1
0000707f9fbd855e  mov rax, 0x5753922B7A50
0000707f9fbd8568  call rax
0000707f9fbd856a  movaps xmm6, [rsp]
0000707f9fbd856e  add rsp, 0x40
0000707f9fbd8572  vmovaps xmm0, [rsp]
0000707f9fbd8577  vmovaps xmm1, [rsp+0x10]
0000707f9fbd857d  vmovaps xmm2, [rsp+0x20]
0000707f9fbd8583  vmovaps xmm3, [rsp+0x30]
0000707f9fbd8589  vmovaps xmm4, [rsp+0x40]
0000707f9fbd858f  vmovaps xmm5, [rsp+0x50]
0000707f9fbd8595  vmovaps xmm7, [rsp+0x60]
0000707f9fbd859b  vmovaps xmm8, [rsp+0x70]
0000707f9fbd85a1  vmovaps xmm9, [rsp+0x80]
0000707f9fbd85aa  vmovaps xmm10, [rsp+0x90]
0000707f9fbd85b3  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd85bc  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd85c5  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd85ce  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd85d7  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd85e0  add rsp, 0xF0
0000707f9fbd85e7  pop r11
0000707f9fbd85e9  pop r10
0000707f9fbd85eb  pop r9
0000707f9fbd85ed  pop r8
0000707f9fbd85ef  pop rsi
0000707f9fbd85f0  pop rdi
0000707f9fbd85f1  pop rdx
0000707f9fbd85f2  pop rcx
0000707f9fbd85f3  pop rax
0000707f9fbd85f4  add rsp, 0x08
0000707f9fbd85f8  jmp 0x0000707F9FBD69F6
0000707f9fbd85fd  sub rsp, 0x08
0000707f9fbd8601  push rax
0000707f9fbd8602  push rcx
0000707f9fbd8603  push rdx
0000707f9fbd8604  push rdi
0000707f9fbd8605  push rsi
0000707f9fbd8606  push r8
0000707f9fbd8608  push r9
0000707f9fbd860a  push r10
0000707f9fbd860c  push r11
0000707f9fbd860e  sub rsp, 0xF0
0000707f9fbd8615  vmovaps [rsp], xmm0
0000707f9fbd861a  vmovaps [rsp+0x10], xmm1
0000707f9fbd8620  vmovaps [rsp+0x20], xmm2
0000707f9fbd8626  vmovaps [rsp+0x30], xmm3
0000707f9fbd862c  vmovaps [rsp+0x40], xmm4
0000707f9fbd8632  vmovaps [rsp+0x50], xmm5
0000707f9fbd8638  vmovaps [rsp+0x60], xmm6
0000707f9fbd863e  vmovaps [rsp+0x70], xmm7
0000707f9fbd8644  vmovaps [rsp+0x80], xmm8
0000707f9fbd864d  vmovaps [rsp+0x90], xmm9
0000707f9fbd8656  vmovaps [rsp+0xA0], xmm11
0000707f9fbd865f  vmovaps [rsp+0xB0], xmm12
0000707f9fbd8668  vmovaps [rsp+0xC0], xmm13
0000707f9fbd8671  vmovaps [rsp+0xD0], xmm14
0000707f9fbd867a  vmovaps [rsp+0xE0], xmm15
0000707f9fbd8683  sub rsp, 0x40
0000707f9fbd8687  lea rdi, [rsp]
0000707f9fbd868b  lea rsi, [rsp+0x10]
0000707f9fbd8690  lea rdx, [rsp+0x20]
0000707f9fbd8695  lea rcx, [rsp+0x30]
0000707f9fbd869a  mov r8d, 0x00
0000707f9fbd86a0  lea r9, [r15+0x3A8]
0000707f9fbd86a7  movaps [rdi], xmm10
0000707f9fbd86ab  movaps [rsi], xmm5
0000707f9fbd86ae  movaps [rdx], xmm12
0000707f9fbd86b2  movaps [rcx], xmm1
0000707f9fbd86b5  mov rax, 0x5753922B7A50
0000707f9fbd86bf  call rax
0000707f9fbd86c1  movaps xmm10, [rsp]
0000707f9fbd86c6  add rsp, 0x40
0000707f9fbd86ca  vmovaps xmm0, [rsp]
0000707f9fbd86cf  vmovaps xmm1, [rsp+0x10]
0000707f9fbd86d5  vmovaps xmm2, [rsp+0x20]
0000707f9fbd86db  vmovaps xmm3, [rsp+0x30]
0000707f9fbd86e1  vmovaps xmm4, [rsp+0x40]
0000707f9fbd86e7  vmovaps xmm5, [rsp+0x50]
0000707f9fbd86ed  vmovaps xmm6, [rsp+0x60]
0000707f9fbd86f3  vmovaps xmm7, [rsp+0x70]
0000707f9fbd86f9  vmovaps xmm8, [rsp+0x80]
0000707f9fbd8702  vmovaps xmm9, [rsp+0x90]
0000707f9fbd870b  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd8714  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd871d  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd8726  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd872f  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd8738  add rsp, 0xF0
0000707f9fbd873f  pop r11
0000707f9fbd8741  pop r10
0000707f9fbd8743  pop r9
0000707f9fbd8745  pop r8
0000707f9fbd8747  pop rsi
0000707f9fbd8748  pop rdi
0000707f9fbd8749  pop rdx
0000707f9fbd874a  pop rcx
0000707f9fbd874b  pop rax
0000707f9fbd874c  add rsp, 0x08
0000707f9fbd8750  jmp 0x0000707F9FBD6A25
0000707f9fbd8755  sub rsp, 0x08
0000707f9fbd8759  push rax
0000707f9fbd875a  push rcx
0000707f9fbd875b  push rdx
0000707f9fbd875c  push rdi
0000707f9fbd875d  push rsi
0000707f9fbd875e  push r8
0000707f9fbd8760  push r9
0000707f9fbd8762  push r10
0000707f9fbd8764  push r11
0000707f9fbd8766  sub rsp, 0xF0
0000707f9fbd876d  vmovaps [rsp], xmm0
0000707f9fbd8772  vmovaps [rsp+0x10], xmm1
0000707f9fbd8778  vmovaps [rsp+0x20], xmm2
0000707f9fbd877e  vmovaps [rsp+0x30], xmm3
0000707f9fbd8784  vmovaps [rsp+0x40], xmm4
0000707f9fbd878a  vmovaps [rsp+0x50], xmm5
0000707f9fbd8790  vmovaps [rsp+0x60], xmm6
0000707f9fbd8796  vmovaps [rsp+0x70], xmm7
0000707f9fbd879c  vmovaps [rsp+0x80], xmm8
0000707f9fbd87a5  vmovaps [rsp+0x90], xmm9
0000707f9fbd87ae  vmovaps [rsp+0xA0], xmm10
0000707f9fbd87b7  vmovaps [rsp+0xB0], xmm11
0000707f9fbd87c0  vmovaps [rsp+0xC0], xmm13
0000707f9fbd87c9  vmovaps [rsp+0xD0], xmm14
0000707f9fbd87d2  vmovaps [rsp+0xE0], xmm15
0000707f9fbd87db  sub rsp, 0x40
0000707f9fbd87df  lea rdi, [rsp]
0000707f9fbd87e3  lea rsi, [rsp+0x10]
0000707f9fbd87e8  lea rdx, [rsp+0x20]
0000707f9fbd87ed  lea rcx, [rsp+0x30]
0000707f9fbd87f2  mov r8d, 0x00
0000707f9fbd87f8  lea r9, [r15+0x3A8]
0000707f9fbd87ff  movaps [rdi], xmm12
0000707f9fbd8803  movaps [rsi], xmm7
0000707f9fbd8806  movaps [rdx], xmm15
0000707f9fbd880a  movaps [rcx], xmm1
0000707f9fbd880d  mov rax, 0x5753922B7A50
0000707f9fbd8817  call rax
0000707f9fbd8819  movaps xmm12, [rsp]
0000707f9fbd881e  add rsp, 0x40
0000707f9fbd8822  vmovaps xmm0, [rsp]
0000707f9fbd8827  vmovaps xmm1, [rsp+0x10]
0000707f9fbd882d  vmovaps xmm2, [rsp+0x20]
0000707f9fbd8833  vmovaps xmm3, [rsp+0x30]
0000707f9fbd8839  vmovaps xmm4, [rsp+0x40]
0000707f9fbd883f  vmovaps xmm5, [rsp+0x50]
0000707f9fbd8845  vmovaps xmm6, [rsp+0x60]
0000707f9fbd884b  vmovaps xmm7, [rsp+0x70]
0000707f9fbd8851  vmovaps xmm8, [rsp+0x80]
0000707f9fbd885a  vmovaps xmm9, [rsp+0x90]
0000707f9fbd8863  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd886c  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd8875  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd887e  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd8887  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd8890  add rsp, 0xF0
0000707f9fbd8897  pop r11
0000707f9fbd8899  pop r10
0000707f9fbd889b  pop r9
0000707f9fbd889d  pop r8
0000707f9fbd889f  pop rsi
0000707f9fbd88a0  pop rdi
0000707f9fbd88a1  pop rdx
0000707f9fbd88a2  pop rcx
0000707f9fbd88a3  pop rax
0000707f9fbd88a4  add rsp, 0x08
0000707f9fbd88a8  jmp 0x0000707F9FBD6A4E
0000707f9fbd88ad  call 0x0000707F9FAD64F0
0000707f9fbd88b2  jmp 0x0000707F9FBD6A58
0000707f9fbd88b7  call 0x0000707F9FAE5820
0000707f9fbd88bc  jmp 0x0000707F9FBD6A62
0000707f9fbd88c1  sub rsp, 0x08
0000707f9fbd88c5  push rax
0000707f9fbd88c6  push rcx
0000707f9fbd88c7  push rdx
0000707f9fbd88c8  push rdi
0000707f9fbd88c9  push rsi
0000707f9fbd88ca  push r8
0000707f9fbd88cc  push r9
0000707f9fbd88ce  push r10
0000707f9fbd88d0  push r11
0000707f9fbd88d2  sub rsp, 0xF0
0000707f9fbd88d9  vmovaps [rsp], xmm0
0000707f9fbd88de  vmovaps [rsp+0x10], xmm1
0000707f9fbd88e4  vmovaps [rsp+0x20], xmm2
0000707f9fbd88ea  vmovaps [rsp+0x30], xmm3
0000707f9fbd88f0  vmovaps [rsp+0x40], xmm4
0000707f9fbd88f6  vmovaps [rsp+0x50], xmm5
0000707f9fbd88fc  vmovaps [rsp+0x60], xmm6
0000707f9fbd8902  vmovaps [rsp+0x70], xmm8
0000707f9fbd8908  vmovaps [rsp+0x80], xmm9
0000707f9fbd8911  vmovaps [rsp+0x90], xmm10
0000707f9fbd891a  vmovaps [rsp+0xA0], xmm11
0000707f9fbd8923  vmovaps [rsp+0xB0], xmm12
0000707f9fbd892c  vmovaps [rsp+0xC0], xmm13
0000707f9fbd8935  vmovaps [rsp+0xD0], xmm14
0000707f9fbd893e  vmovaps [rsp+0xE0], xmm15
0000707f9fbd8947  sub rsp, 0x40
0000707f9fbd894b  lea rdi, [rsp]
0000707f9fbd894f  lea rsi, [rsp+0x10]
0000707f9fbd8954  lea rdx, [rsp+0x20]
0000707f9fbd8959  lea rcx, [rsp+0x30]
0000707f9fbd895e  mov r8d, 0x00
0000707f9fbd8964  lea r9, [r15+0x3A8]
0000707f9fbd896b  movaps [rdi], xmm7
0000707f9fbd896e  movaps [rsi], xmm2
0000707f9fbd8971  movaps [rdx], xmm9
0000707f9fbd8975  movaps [rcx], xmm11
0000707f9fbd8979  mov rax, 0x5753922B7A50
0000707f9fbd8983  call rax
0000707f9fbd8985  movaps xmm7, [rsp]
0000707f9fbd8989  add rsp, 0x40
0000707f9fbd898d  vmovaps xmm0, [rsp]
0000707f9fbd8992  vmovaps xmm1, [rsp+0x10]
0000707f9fbd8998  vmovaps xmm2, [rsp+0x20]
0000707f9fbd899e  vmovaps xmm3, [rsp+0x30]
0000707f9fbd89a4  vmovaps xmm4, [rsp+0x40]
0000707f9fbd89aa  vmovaps xmm5, [rsp+0x50]
0000707f9fbd89b0  vmovaps xmm6, [rsp+0x60]
0000707f9fbd89b6  vmovaps xmm8, [rsp+0x70]
0000707f9fbd89bc  vmovaps xmm9, [rsp+0x80]
0000707f9fbd89c5  vmovaps xmm10, [rsp+0x90]
0000707f9fbd89ce  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd89d7  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd89e0  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd89e9  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd89f2  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd89fb  add rsp, 0xF0
0000707f9fbd8a02  pop r11
0000707f9fbd8a04  pop r10
0000707f9fbd8a06  pop r9
0000707f9fbd8a08  pop r8
0000707f9fbd8a0a  pop rsi
0000707f9fbd8a0b  pop rdi
0000707f9fbd8a0c  pop rdx
0000707f9fbd8a0d  pop rcx
0000707f9fbd8a0e  pop rax
0000707f9fbd8a0f  add rsp, 0x08
0000707f9fbd8a13  jmp 0x0000707F9FBD6A96
0000707f9fbd8a18  sub rsp, 0x08
0000707f9fbd8a1c  push rax
0000707f9fbd8a1d  push rcx
0000707f9fbd8a1e  push rdx
0000707f9fbd8a1f  push rdi
0000707f9fbd8a20  push rsi
0000707f9fbd8a21  push r8
0000707f9fbd8a23  push r9
0000707f9fbd8a25  push r10
0000707f9fbd8a27  push r11
0000707f9fbd8a29  sub rsp, 0xF0
0000707f9fbd8a30  vmovaps [rsp], xmm0
0000707f9fbd8a35  vmovaps [rsp+0x10], xmm1
0000707f9fbd8a3b  vmovaps [rsp+0x20], xmm2
0000707f9fbd8a41  vmovaps [rsp+0x30], xmm3
0000707f9fbd8a47  vmovaps [rsp+0x40], xmm4
0000707f9fbd8a4d  vmovaps [rsp+0x50], xmm5
0000707f9fbd8a53  vmovaps [rsp+0x60], xmm6
0000707f9fbd8a59  vmovaps [rsp+0x70], xmm7
0000707f9fbd8a5f  vmovaps [rsp+0x80], xmm8
0000707f9fbd8a68  vmovaps [rsp+0x90], xmm10
0000707f9fbd8a71  vmovaps [rsp+0xA0], xmm11
0000707f9fbd8a7a  vmovaps [rsp+0xB0], xmm12
0000707f9fbd8a83  vmovaps [rsp+0xC0], xmm13
0000707f9fbd8a8c  vmovaps [rsp+0xD0], xmm14
0000707f9fbd8a95  vmovaps [rsp+0xE0], xmm15
0000707f9fbd8a9e  sub rsp, 0x40
0000707f9fbd8aa2  lea rdi, [rsp]
0000707f9fbd8aa6  lea rsi, [rsp+0x10]
0000707f9fbd8aab  lea rdx, [rsp+0x20]
0000707f9fbd8ab0  lea rcx, [rsp+0x30]
0000707f9fbd8ab5  mov r8d, 0x00
0000707f9fbd8abb  lea r9, [r15+0x3A8]
0000707f9fbd8ac2  movaps [rdi], xmm9
0000707f9fbd8ac6  movaps [rsi], xmm6
0000707f9fbd8ac9  movaps [rdx], xmm1
0000707f9fbd8acc  movaps [rcx], xmm11
0000707f9fbd8ad0  mov rax, 0x5753922B7A50
0000707f9fbd8ada  call rax
0000707f9fbd8adc  movaps xmm9, [rsp]
0000707f9fbd8ae1  add rsp, 0x40
0000707f9fbd8ae5  vmovaps xmm0, [rsp]
0000707f9fbd8aea  vmovaps xmm1, [rsp+0x10]
0000707f9fbd8af0  vmovaps xmm2, [rsp+0x20]
0000707f9fbd8af6  vmovaps xmm3, [rsp+0x30]
0000707f9fbd8afc  vmovaps xmm4, [rsp+0x40]
0000707f9fbd8b02  vmovaps xmm5, [rsp+0x50]
0000707f9fbd8b08  vmovaps xmm6, [rsp+0x60]
0000707f9fbd8b0e  vmovaps xmm7, [rsp+0x70]
0000707f9fbd8b14  vmovaps xmm8, [rsp+0x80]
0000707f9fbd8b1d  vmovaps xmm10, [rsp+0x90]
0000707f9fbd8b26  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd8b2f  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd8b38  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd8b41  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd8b4a  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd8b53  add rsp, 0xF0
0000707f9fbd8b5a  pop r11
0000707f9fbd8b5c  pop r10
0000707f9fbd8b5e  pop r9
0000707f9fbd8b60  pop r8
0000707f9fbd8b62  pop rsi
0000707f9fbd8b63  pop rdi
0000707f9fbd8b64  pop rdx
0000707f9fbd8b65  pop rcx
0000707f9fbd8b66  pop rax
0000707f9fbd8b67  add rsp, 0x08
0000707f9fbd8b6b  jmp 0x0000707F9FBD6ABC
0000707f9fbd8b70  sub rsp, 0x08
0000707f9fbd8b74  push rax
0000707f9fbd8b75  push rcx
0000707f9fbd8b76  push rdx
0000707f9fbd8b77  push rdi
0000707f9fbd8b78  push rsi
0000707f9fbd8b79  push r8
0000707f9fbd8b7b  push r9
0000707f9fbd8b7d  push r10
0000707f9fbd8b7f  push r11
0000707f9fbd8b81  sub rsp, 0xF0
0000707f9fbd8b88  vmovaps [rsp], xmm0
0000707f9fbd8b8d  vmovaps [rsp+0x10], xmm1
0000707f9fbd8b93  vmovaps [rsp+0x20], xmm2
0000707f9fbd8b99  vmovaps [rsp+0x30], xmm3
0000707f9fbd8b9f  vmovaps [rsp+0x40], xmm4
0000707f9fbd8ba5  vmovaps [rsp+0x50], xmm5
0000707f9fbd8bab  vmovaps [rsp+0x60], xmm6
0000707f9fbd8bb1  vmovaps [rsp+0x70], xmm7
0000707f9fbd8bb7  vmovaps [rsp+0x80], xmm8
0000707f9fbd8bc0  vmovaps [rsp+0x90], xmm9
0000707f9fbd8bc9  vmovaps [rsp+0xA0], xmm10
0000707f9fbd8bd2  vmovaps [rsp+0xB0], xmm12
0000707f9fbd8bdb  vmovaps [rsp+0xC0], xmm13
0000707f9fbd8be4  vmovaps [rsp+0xD0], xmm14
0000707f9fbd8bed  vmovaps [rsp+0xE0], xmm15
0000707f9fbd8bf6  sub rsp, 0x40
0000707f9fbd8bfa  lea rdi, [rsp]
0000707f9fbd8bfe  lea rsi, [rsp+0x10]
0000707f9fbd8c03  lea rdx, [rsp+0x20]
0000707f9fbd8c08  lea rcx, [rsp+0x30]
0000707f9fbd8c0d  mov r8d, 0x00
0000707f9fbd8c13  lea r9, [r15+0x3A8]
0000707f9fbd8c1a  movaps [rdi], xmm11
0000707f9fbd8c1e  movaps [rsi], xmm10
0000707f9fbd8c22  movaps [rdx], xmm8
0000707f9fbd8c26  movaps [rcx], xmm1
0000707f9fbd8c29  mov rax, 0x5753922B7A50
0000707f9fbd8c33  call rax
0000707f9fbd8c35  movaps xmm11, [rsp]
0000707f9fbd8c3a  add rsp, 0x40
0000707f9fbd8c3e  vmovaps xmm0, [rsp]
0000707f9fbd8c43  vmovaps xmm1, [rsp+0x10]
0000707f9fbd8c49  vmovaps xmm2, [rsp+0x20]
0000707f9fbd8c4f  vmovaps xmm3, [rsp+0x30]
0000707f9fbd8c55  vmovaps xmm4, [rsp+0x40]
0000707f9fbd8c5b  vmovaps xmm5, [rsp+0x50]
0000707f9fbd8c61  vmovaps xmm6, [rsp+0x60]
0000707f9fbd8c67  vmovaps xmm7, [rsp+0x70]
0000707f9fbd8c6d  vmovaps xmm8, [rsp+0x80]
0000707f9fbd8c76  vmovaps xmm9, [rsp+0x90]
0000707f9fbd8c7f  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd8c88  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd8c91  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd8c9a  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd8ca3  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd8cac  add rsp, 0xF0
0000707f9fbd8cb3  pop r11
0000707f9fbd8cb5  pop r10
0000707f9fbd8cb7  pop r9
0000707f9fbd8cb9  pop r8
0000707f9fbd8cbb  pop rsi
0000707f9fbd8cbc  pop rdi
0000707f9fbd8cbd  pop rdx
0000707f9fbd8cbe  pop rcx
0000707f9fbd8cbf  pop rax
0000707f9fbd8cc0  add rsp, 0x08
0000707f9fbd8cc4  jmp 0x0000707F9FBD6AE2
0000707f9fbd8cc9  sub rsp, 0x08
0000707f9fbd8ccd  push rax
0000707f9fbd8cce  push rcx
0000707f9fbd8ccf  push rdx
0000707f9fbd8cd0  push rdi
0000707f9fbd8cd1  push rsi
0000707f9fbd8cd2  push r8
0000707f9fbd8cd4  push r9
0000707f9fbd8cd6  push r10
0000707f9fbd8cd8  push r11
0000707f9fbd8cda  sub rsp, 0xF0
0000707f9fbd8ce1  vmovaps [rsp], xmm0
0000707f9fbd8ce6  vmovaps [rsp+0x10], xmm1
0000707f9fbd8cec  vmovaps [rsp+0x20], xmm2
0000707f9fbd8cf2  vmovaps [rsp+0x30], xmm3
0000707f9fbd8cf8  vmovaps [rsp+0x40], xmm4
0000707f9fbd8cfe  vmovaps [rsp+0x50], xmm5
0000707f9fbd8d04  vmovaps [rsp+0x60], xmm6
0000707f9fbd8d0a  vmovaps [rsp+0x70], xmm7
0000707f9fbd8d10  vmovaps [rsp+0x80], xmm8
0000707f9fbd8d19  vmovaps [rsp+0x90], xmm9
0000707f9fbd8d22  vmovaps [rsp+0xA0], xmm11
0000707f9fbd8d2b  vmovaps [rsp+0xB0], xmm12
0000707f9fbd8d34  vmovaps [rsp+0xC0], xmm13
0000707f9fbd8d3d  vmovaps [rsp+0xD0], xmm14
0000707f9fbd8d46  vmovaps [rsp+0xE0], xmm15
0000707f9fbd8d4f  sub rsp, 0x40
0000707f9fbd8d53  lea rdi, [rsp]
0000707f9fbd8d57  lea rsi, [rsp+0x10]
0000707f9fbd8d5c  lea rdx, [rsp+0x20]
0000707f9fbd8d61  lea rcx, [rsp+0x30]
0000707f9fbd8d66  mov r8d, 0x00
0000707f9fbd8d6c  lea r9, [r15+0x3A8]
0000707f9fbd8d73  movaps [rdi], xmm10
0000707f9fbd8d77  movaps [rsi], xmm12
0000707f9fbd8d7b  movaps [rdx], xmm13
0000707f9fbd8d7f  movaps [rcx], xmm1
0000707f9fbd8d82  mov rax, 0x5753922B7A50
0000707f9fbd8d8c  call rax
0000707f9fbd8d8e  movaps xmm10, [rsp]
0000707f9fbd8d93  add rsp, 0x40
0000707f9fbd8d97  vmovaps xmm0, [rsp]
0000707f9fbd8d9c  vmovaps xmm1, [rsp+0x10]
0000707f9fbd8da2  vmovaps xmm2, [rsp+0x20]
0000707f9fbd8da8  vmovaps xmm3, [rsp+0x30]
0000707f9fbd8dae  vmovaps xmm4, [rsp+0x40]
0000707f9fbd8db4  vmovaps xmm5, [rsp+0x50]
0000707f9fbd8dba  vmovaps xmm6, [rsp+0x60]
0000707f9fbd8dc0  vmovaps xmm7, [rsp+0x70]
0000707f9fbd8dc6  vmovaps xmm8, [rsp+0x80]
0000707f9fbd8dcf  vmovaps xmm9, [rsp+0x90]
0000707f9fbd8dd8  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd8de1  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd8dea  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd8df3  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd8dfc  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd8e05  add rsp, 0xF0
0000707f9fbd8e0c  pop r11
0000707f9fbd8e0e  pop r10
0000707f9fbd8e10  pop r9
0000707f9fbd8e12  pop r8
0000707f9fbd8e14  pop rsi
0000707f9fbd8e15  pop rdi
0000707f9fbd8e16  pop rdx
0000707f9fbd8e17  pop rcx
0000707f9fbd8e18  pop rax
0000707f9fbd8e19  add rsp, 0x08
0000707f9fbd8e1d  jmp 0x0000707F9FBD6B08
0000707f9fbd8e22  call 0x0000707F9FAD64F0
0000707f9fbd8e27  jmp 0x0000707F9FBD6B12
0000707f9fbd8e2c  call 0x0000707F9FAE3320
0000707f9fbd8e31  jmp 0x0000707F9FBD6B1C
0000707f9fbd8e36  sub rsp, 0x08
0000707f9fbd8e3a  push rax
0000707f9fbd8e3b  push rcx
0000707f9fbd8e3c  push rdx
0000707f9fbd8e3d  push rdi
0000707f9fbd8e3e  push rsi
0000707f9fbd8e3f  push r8
0000707f9fbd8e41  push r9
0000707f9fbd8e43  push r10
0000707f9fbd8e45  push r11
0000707f9fbd8e47  sub rsp, 0xF0
0000707f9fbd8e4e  vmovaps [rsp], xmm0
0000707f9fbd8e53  vmovaps [rsp+0x10], xmm1
0000707f9fbd8e59  vmovaps [rsp+0x20], xmm2
0000707f9fbd8e5f  vmovaps [rsp+0x30], xmm3
0000707f9fbd8e65  vmovaps [rsp+0x40], xmm4
0000707f9fbd8e6b  vmovaps [rsp+0x50], xmm5
0000707f9fbd8e71  vmovaps [rsp+0x60], xmm6
0000707f9fbd8e77  vmovaps [rsp+0x70], xmm7
0000707f9fbd8e7d  vmovaps [rsp+0x80], xmm9
0000707f9fbd8e86  vmovaps [rsp+0x90], xmm10
0000707f9fbd8e8f  vmovaps [rsp+0xA0], xmm11
0000707f9fbd8e98  vmovaps [rsp+0xB0], xmm12
0000707f9fbd8ea1  vmovaps [rsp+0xC0], xmm13
0000707f9fbd8eaa  vmovaps [rsp+0xD0], xmm14
0000707f9fbd8eb3  vmovaps [rsp+0xE0], xmm15
0000707f9fbd8ebc  sub rsp, 0x40
0000707f9fbd8ec0  lea rdi, [rsp]
0000707f9fbd8ec4  lea rsi, [rsp+0x10]
0000707f9fbd8ec9  lea rdx, [rsp+0x20]
0000707f9fbd8ece  lea rcx, [rsp+0x30]
0000707f9fbd8ed3  mov r8d, 0x00
0000707f9fbd8ed9  lea r9, [r15+0x3A8]
0000707f9fbd8ee0  movaps [rdi], xmm8
0000707f9fbd8ee4  movaps [rsi], xmm7
0000707f9fbd8ee7  movaps [rdx], xmm4
0000707f9fbd8eea  movaps [rcx], xmm12
0000707f9fbd8eee  mov rax, 0x5753922B7A50
0000707f9fbd8ef8  call rax
0000707f9fbd8efa  movaps xmm8, [rsp]
0000707f9fbd8eff  add rsp, 0x40
0000707f9fbd8f03  vmovaps xmm0, [rsp]
0000707f9fbd8f08  vmovaps xmm1, [rsp+0x10]
0000707f9fbd8f0e  vmovaps xmm2, [rsp+0x20]
0000707f9fbd8f14  vmovaps xmm3, [rsp+0x30]
0000707f9fbd8f1a  vmovaps xmm4, [rsp+0x40]
0000707f9fbd8f20  vmovaps xmm5, [rsp+0x50]
0000707f9fbd8f26  vmovaps xmm6, [rsp+0x60]
0000707f9fbd8f2c  vmovaps xmm7, [rsp+0x70]
0000707f9fbd8f32  vmovaps xmm9, [rsp+0x80]
0000707f9fbd8f3b  vmovaps xmm10, [rsp+0x90]
0000707f9fbd8f44  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd8f4d  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd8f56  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd8f5f  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd8f68  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd8f71  add rsp, 0xF0
0000707f9fbd8f78  pop r11
0000707f9fbd8f7a  pop r10
0000707f9fbd8f7c  pop r9
0000707f9fbd8f7e  pop r8
0000707f9fbd8f80  pop rsi
0000707f9fbd8f81  pop rdi
0000707f9fbd8f82  pop rdx
0000707f9fbd8f83  pop rcx
0000707f9fbd8f84  pop rax
0000707f9fbd8f85  add rsp, 0x08
0000707f9fbd8f89  jmp 0x0000707F9FBD6B45
0000707f9fbd8f8e  sub rsp, 0x08
0000707f9fbd8f92  push rax
0000707f9fbd8f93  push rcx
0000707f9fbd8f94  push rdx
0000707f9fbd8f95  push rdi
0000707f9fbd8f96  push rsi
0000707f9fbd8f97  push r8
0000707f9fbd8f99  push r9
0000707f9fbd8f9b  push r10
0000707f9fbd8f9d  push r11
0000707f9fbd8f9f  sub rsp, 0xF0
0000707f9fbd8fa6  vmovaps [rsp], xmm0
0000707f9fbd8fab  vmovaps [rsp+0x10], xmm1
0000707f9fbd8fb1  vmovaps [rsp+0x20], xmm2
0000707f9fbd8fb7  vmovaps [rsp+0x30], xmm3
0000707f9fbd8fbd  vmovaps [rsp+0x40], xmm4
0000707f9fbd8fc3  vmovaps [rsp+0x50], xmm5
0000707f9fbd8fc9  vmovaps [rsp+0x60], xmm6
0000707f9fbd8fcf  vmovaps [rsp+0x70], xmm8
0000707f9fbd8fd5  vmovaps [rsp+0x80], xmm9
0000707f9fbd8fde  vmovaps [rsp+0x90], xmm10
0000707f9fbd8fe7  vmovaps [rsp+0xA0], xmm11
0000707f9fbd8ff0  vmovaps [rsp+0xB0], xmm12
0000707f9fbd8ff9  vmovaps [rsp+0xC0], xmm13
0000707f9fbd9002  vmovaps [rsp+0xD0], xmm14
0000707f9fbd900b  vmovaps [rsp+0xE0], xmm15
0000707f9fbd9014  sub rsp, 0x40
0000707f9fbd9018  lea rdi, [rsp]
0000707f9fbd901c  lea rsi, [rsp+0x10]
0000707f9fbd9021  lea rdx, [rsp+0x20]
0000707f9fbd9026  lea rcx, [rsp+0x30]
0000707f9fbd902b  mov r8d, 0x00
0000707f9fbd9031  lea r9, [r15+0x3A8]
0000707f9fbd9038  movaps [rdi], xmm7
0000707f9fbd903b  movaps [rsi], xmm9
0000707f9fbd903f  movaps [rdx], xmm14
0000707f9fbd9043  movaps [rcx], xmm12
0000707f9fbd9047  mov rax, 0x5753922B7A50
0000707f9fbd9051  call rax
0000707f9fbd9053  movaps xmm7, [rsp]
0000707f9fbd9057  add rsp, 0x40
0000707f9fbd905b  vmovaps xmm0, [rsp]
0000707f9fbd9060  vmovaps xmm1, [rsp+0x10]
0000707f9fbd9066  vmovaps xmm2, [rsp+0x20]
0000707f9fbd906c  vmovaps xmm3, [rsp+0x30]
0000707f9fbd9072  vmovaps xmm4, [rsp+0x40]
0000707f9fbd9078  vmovaps xmm5, [rsp+0x50]
0000707f9fbd907e  vmovaps xmm6, [rsp+0x60]
0000707f9fbd9084  vmovaps xmm8, [rsp+0x70]
0000707f9fbd908a  vmovaps xmm9, [rsp+0x80]
0000707f9fbd9093  vmovaps xmm10, [rsp+0x90]
0000707f9fbd909c  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd90a5  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd90ae  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd90b7  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd90c0  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd90c9  add rsp, 0xF0
0000707f9fbd90d0  pop r11
0000707f9fbd90d2  pop r10
0000707f9fbd90d4  pop r9
0000707f9fbd90d6  pop r8
0000707f9fbd90d8  pop rsi
0000707f9fbd90d9  pop rdi
0000707f9fbd90da  pop rdx
0000707f9fbd90db  pop rcx
0000707f9fbd90dc  pop rax
0000707f9fbd90dd  add rsp, 0x08
0000707f9fbd90e1  jmp 0x0000707F9FBD6B6D
0000707f9fbd90e6  sub rsp, 0x08
0000707f9fbd90ea  push rax
0000707f9fbd90eb  push rcx
0000707f9fbd90ec  push rdx
0000707f9fbd90ed  push rdi
0000707f9fbd90ee  push rsi
0000707f9fbd90ef  push r8
0000707f9fbd90f1  push r9
0000707f9fbd90f3  push r10
0000707f9fbd90f5  push r11
0000707f9fbd90f7  sub rsp, 0xF0
0000707f9fbd90fe  vmovaps [rsp], xmm0
0000707f9fbd9103  vmovaps [rsp+0x10], xmm1
0000707f9fbd9109  vmovaps [rsp+0x20], xmm2
0000707f9fbd910f  vmovaps [rsp+0x30], xmm3
0000707f9fbd9115  vmovaps [rsp+0x40], xmm4
0000707f9fbd911b  vmovaps [rsp+0x50], xmm5
0000707f9fbd9121  vmovaps [rsp+0x60], xmm6
0000707f9fbd9127  vmovaps [rsp+0x70], xmm7
0000707f9fbd912d  vmovaps [rsp+0x80], xmm8
0000707f9fbd9136  vmovaps [rsp+0x90], xmm9
0000707f9fbd913f  vmovaps [rsp+0xA0], xmm10
0000707f9fbd9148  vmovaps [rsp+0xB0], xmm11
0000707f9fbd9151  vmovaps [rsp+0xC0], xmm13
0000707f9fbd915a  vmovaps [rsp+0xD0], xmm14
0000707f9fbd9163  vmovaps [rsp+0xE0], xmm15
0000707f9fbd916c  sub rsp, 0x40
0000707f9fbd9170  lea rdi, [rsp]
0000707f9fbd9174  lea rsi, [rsp+0x10]
0000707f9fbd9179  lea rdx, [rsp+0x20]
0000707f9fbd917e  lea rcx, [rsp+0x30]
0000707f9fbd9183  mov r8d, 0x00
0000707f9fbd9189  lea r9, [r15+0x3A8]
0000707f9fbd9190  movaps [rdi], xmm12
0000707f9fbd9194  movaps [rsi], xmm11
0000707f9fbd9198  movaps [rdx], xmm15
0000707f9fbd919c  movaps [rcx], xmm14
0000707f9fbd91a0  mov rax, 0x5753922B7A50
0000707f9fbd91aa  call rax
0000707f9fbd91ac  movaps xmm12, [rsp]
0000707f9fbd91b1  add rsp, 0x40
0000707f9fbd91b5  vmovaps xmm0, [rsp]
0000707f9fbd91ba  vmovaps xmm1, [rsp+0x10]
0000707f9fbd91c0  vmovaps xmm2, [rsp+0x20]
0000707f9fbd91c6  vmovaps xmm3, [rsp+0x30]
0000707f9fbd91cc  vmovaps xmm4, [rsp+0x40]
0000707f9fbd91d2  vmovaps xmm5, [rsp+0x50]
0000707f9fbd91d8  vmovaps xmm6, [rsp+0x60]
0000707f9fbd91de  vmovaps xmm7, [rsp+0x70]
0000707f9fbd91e4  vmovaps xmm8, [rsp+0x80]
0000707f9fbd91ed  vmovaps xmm9, [rsp+0x90]
0000707f9fbd91f6  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd91ff  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd9208  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd9211  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd921a  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd9223  add rsp, 0xF0
0000707f9fbd922a  pop r11
0000707f9fbd922c  pop r10
0000707f9fbd922e  pop r9
0000707f9fbd9230  pop r8
0000707f9fbd9232  pop rsi
0000707f9fbd9233  pop rdi
0000707f9fbd9234  pop rdx
0000707f9fbd9235  pop rcx
0000707f9fbd9236  pop rax
0000707f9fbd9237  add rsp, 0x08
0000707f9fbd923b  jmp 0x0000707F9FBD6B96
0000707f9fbd9240  sub rsp, 0x08
0000707f9fbd9244  push rax
0000707f9fbd9245  push rcx
0000707f9fbd9246  push rdx
0000707f9fbd9247  push rdi
0000707f9fbd9248  push rsi
0000707f9fbd9249  push r8
0000707f9fbd924b  push r9
0000707f9fbd924d  push r10
0000707f9fbd924f  push r11
0000707f9fbd9251  sub rsp, 0xF0
0000707f9fbd9258  vmovaps [rsp], xmm0
0000707f9fbd925d  vmovaps [rsp+0x10], xmm1
0000707f9fbd9263  vmovaps [rsp+0x20], xmm2
0000707f9fbd9269  vmovaps [rsp+0x30], xmm3
0000707f9fbd926f  vmovaps [rsp+0x40], xmm4
0000707f9fbd9275  vmovaps [rsp+0x50], xmm5
0000707f9fbd927b  vmovaps [rsp+0x60], xmm6
0000707f9fbd9281  vmovaps [rsp+0x70], xmm7
0000707f9fbd9287  vmovaps [rsp+0x80], xmm8
0000707f9fbd9290  vmovaps [rsp+0x90], xmm9
0000707f9fbd9299  vmovaps [rsp+0xA0], xmm10
0000707f9fbd92a2  vmovaps [rsp+0xB0], xmm12
0000707f9fbd92ab  vmovaps [rsp+0xC0], xmm13
0000707f9fbd92b4  vmovaps [rsp+0xD0], xmm14
0000707f9fbd92bd  vmovaps [rsp+0xE0], xmm15
0000707f9fbd92c6  sub rsp, 0x40
0000707f9fbd92ca  lea rdi, [rsp]
0000707f9fbd92ce  lea rsi, [rsp+0x10]
0000707f9fbd92d3  lea rdx, [rsp+0x20]
0000707f9fbd92d8  lea rcx, [rsp+0x30]
0000707f9fbd92dd  mov r8d, 0x00
0000707f9fbd92e3  lea r9, [r15+0x3A8]
0000707f9fbd92ea  movaps [rdi], xmm11
0000707f9fbd92ee  movaps [rsi], xmm10
0000707f9fbd92f2  movaps [rdx], xmm13
0000707f9fbd92f6  movaps [rcx], xmm15
0000707f9fbd92fa  mov rax, 0x5753922B7A50
0000707f9fbd9304  call rax
0000707f9fbd9306  movaps xmm11, [rsp]
0000707f9fbd930b  add rsp, 0x40
0000707f9fbd930f  vmovaps xmm0, [rsp]
0000707f9fbd9314  vmovaps xmm1, [rsp+0x10]
0000707f9fbd931a  vmovaps xmm2, [rsp+0x20]
0000707f9fbd9320  vmovaps xmm3, [rsp+0x30]
0000707f9fbd9326  vmovaps xmm4, [rsp+0x40]
0000707f9fbd932c  vmovaps xmm5, [rsp+0x50]
0000707f9fbd9332  vmovaps xmm6, [rsp+0x60]
0000707f9fbd9338  vmovaps xmm7, [rsp+0x70]
0000707f9fbd933e  vmovaps xmm8, [rsp+0x80]
0000707f9fbd9347  vmovaps xmm9, [rsp+0x90]
0000707f9fbd9350  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd9359  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd9362  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd936b  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd9374  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd937d  add rsp, 0xF0
0000707f9fbd9384  pop r11
0000707f9fbd9386  pop r10
0000707f9fbd9388  pop r9
0000707f9fbd938a  pop r8
0000707f9fbd938c  pop rsi
0000707f9fbd938d  pop rdi
0000707f9fbd938e  pop rdx
0000707f9fbd938f  pop rcx
0000707f9fbd9390  pop rax
0000707f9fbd9391  add rsp, 0x08
0000707f9fbd9395  jmp 0x0000707F9FBD6BBF
0000707f9fbd939a  call 0x0000707F9FAE5820
0000707f9fbd939f  jmp 0x0000707F9FBD6BCC
0000707f9fbd93a4  call 0x0000707F9FAE45A0
0000707f9fbd93a9  jmp 0x0000707F9FBD6BD9
0000707f9fbd93ae  sub rsp, 0x08
0000707f9fbd93b2  push rax
0000707f9fbd93b3  push rcx
0000707f9fbd93b4  push rdx
0000707f9fbd93b5  push rdi
0000707f9fbd93b6  push rsi
0000707f9fbd93b7  push r8
0000707f9fbd93b9  push r9
0000707f9fbd93bb  push r10
0000707f9fbd93bd  push r11
0000707f9fbd93bf  sub rsp, 0xF0
0000707f9fbd93c6  vmovaps [rsp], xmm0
0000707f9fbd93cb  vmovaps [rsp+0x10], xmm1
0000707f9fbd93d1  vmovaps [rsp+0x20], xmm2
0000707f9fbd93d7  vmovaps [rsp+0x30], xmm3
0000707f9fbd93dd  vmovaps [rsp+0x40], xmm4
0000707f9fbd93e3  vmovaps [rsp+0x50], xmm5
0000707f9fbd93e9  vmovaps [rsp+0x60], xmm6
0000707f9fbd93ef  vmovaps [rsp+0x70], xmm7
0000707f9fbd93f5  vmovaps [rsp+0x80], xmm8
0000707f9fbd93fe  vmovaps [rsp+0x90], xmm9
0000707f9fbd9407  vmovaps [rsp+0xA0], xmm11
0000707f9fbd9410  vmovaps [rsp+0xB0], xmm12
0000707f9fbd9419  vmovaps [rsp+0xC0], xmm13
0000707f9fbd9422  vmovaps [rsp+0xD0], xmm14
0000707f9fbd942b  vmovaps [rsp+0xE0], xmm15
0000707f9fbd9434  sub rsp, 0x40
0000707f9fbd9438  lea rdi, [rsp]
0000707f9fbd943c  lea rsi, [rsp+0x10]
0000707f9fbd9441  lea rdx, [rsp+0x20]
0000707f9fbd9446  lea rcx, [rsp+0x30]
0000707f9fbd944b  mov r8d, 0x00
0000707f9fbd9451  lea r9, [r15+0x3A8]
0000707f9fbd9458  movaps [rdi], xmm10
0000707f9fbd945c  movaps [rsi], xmm8
0000707f9fbd9460  movaps [rdx], xmm1
0000707f9fbd9463  movaps [rcx], xmm13
0000707f9fbd9467  mov rax, 0x5753922B7A50
0000707f9fbd9471  call rax
0000707f9fbd9473  movaps xmm10, [rsp]
0000707f9fbd9478  add rsp, 0x40
0000707f9fbd947c  vmovaps xmm0, [rsp]
0000707f9fbd9481  vmovaps xmm1, [rsp+0x10]
0000707f9fbd9487  vmovaps xmm2, [rsp+0x20]
0000707f9fbd948d  vmovaps xmm3, [rsp+0x30]
0000707f9fbd9493  vmovaps xmm4, [rsp+0x40]
0000707f9fbd9499  vmovaps xmm5, [rsp+0x50]
0000707f9fbd949f  vmovaps xmm6, [rsp+0x60]
0000707f9fbd94a5  vmovaps xmm7, [rsp+0x70]
0000707f9fbd94ab  vmovaps xmm8, [rsp+0x80]
0000707f9fbd94b4  vmovaps xmm9, [rsp+0x90]
0000707f9fbd94bd  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd94c6  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd94cf  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd94d8  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd94e1  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd94ea  add rsp, 0xF0
0000707f9fbd94f1  pop r11
0000707f9fbd94f3  pop r10
0000707f9fbd94f5  pop r9
0000707f9fbd94f7  pop r8
0000707f9fbd94f9  pop rsi
0000707f9fbd94fa  pop rdi
0000707f9fbd94fb  pop rdx
0000707f9fbd94fc  pop rcx
0000707f9fbd94fd  pop rax
0000707f9fbd94fe  add rsp, 0x08
0000707f9fbd9502  jmp 0x0000707F9FBD6C0F
0000707f9fbd9507  call 0x0000707F9FAD64F0
0000707f9fbd950c  jmp 0x0000707F9FBD6C21
0000707f9fbd9511  sub rsp, 0x08
0000707f9fbd9515  push rax
0000707f9fbd9516  push rcx
0000707f9fbd9517  push rdx
0000707f9fbd9518  push rdi
0000707f9fbd9519  push rsi
0000707f9fbd951a  push r8
0000707f9fbd951c  push r9
0000707f9fbd951e  push r10
0000707f9fbd9520  push r11
0000707f9fbd9522  sub rsp, 0xF0
0000707f9fbd9529  vmovaps [rsp], xmm0
0000707f9fbd952e  vmovaps [rsp+0x10], xmm1
0000707f9fbd9534  vmovaps [rsp+0x20], xmm2
0000707f9fbd953a  vmovaps [rsp+0x30], xmm3
0000707f9fbd9540  vmovaps [rsp+0x40], xmm4
0000707f9fbd9546  vmovaps [rsp+0x50], xmm5
0000707f9fbd954c  vmovaps [rsp+0x60], xmm6
0000707f9fbd9552  vmovaps [rsp+0x70], xmm7
0000707f9fbd9558  vmovaps [rsp+0x80], xmm8
0000707f9fbd9561  vmovaps [rsp+0x90], xmm10
0000707f9fbd956a  vmovaps [rsp+0xA0], xmm11
0000707f9fbd9573  vmovaps [rsp+0xB0], xmm12
0000707f9fbd957c  vmovaps [rsp+0xC0], xmm13
0000707f9fbd9585  vmovaps [rsp+0xD0], xmm14
0000707f9fbd958e  vmovaps [rsp+0xE0], xmm15
0000707f9fbd9597  sub rsp, 0x40
0000707f9fbd959b  lea rdi, [rsp]
0000707f9fbd959f  lea rsi, [rsp+0x10]
0000707f9fbd95a4  lea rdx, [rsp+0x20]
0000707f9fbd95a9  lea rcx, [rsp+0x30]
0000707f9fbd95ae  mov r8d, 0x00
0000707f9fbd95b4  lea r9, [r15+0x3A8]
0000707f9fbd95bb  movaps [rdi], xmm9
0000707f9fbd95bf  movaps [rsi], xmm7
0000707f9fbd95c2  movaps [rdx], xmm14
0000707f9fbd95c6  movaps [rcx], xmm13
0000707f9fbd95ca  mov rax, 0x5753922B7A50
0000707f9fbd95d4  call rax
0000707f9fbd95d6  movaps xmm9, [rsp]
0000707f9fbd95db  add rsp, 0x40
0000707f9fbd95df  vmovaps xmm0, [rsp]
0000707f9fbd95e4  vmovaps xmm1, [rsp+0x10]
0000707f9fbd95ea  vmovaps xmm2, [rsp+0x20]
0000707f9fbd95f0  vmovaps xmm3, [rsp+0x30]
0000707f9fbd95f6  vmovaps xmm4, [rsp+0x40]
0000707f9fbd95fc  vmovaps xmm5, [rsp+0x50]
0000707f9fbd9602  vmovaps xmm6, [rsp+0x60]
0000707f9fbd9608  vmovaps xmm7, [rsp+0x70]
0000707f9fbd960e  vmovaps xmm8, [rsp+0x80]
0000707f9fbd9617  vmovaps xmm10, [rsp+0x90]
0000707f9fbd9620  vmovaps xmm11, [rsp+0xA0]
0000707f9fbd9629  vmovaps xmm12, [rsp+0xB0]
0000707f9fbd9632  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd963b  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd9644  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd964d  add rsp, 0xF0
0000707f9fbd9654  pop r11
0000707f9fbd9656  pop r10
0000707f9fbd9658  pop r9
0000707f9fbd965a  pop r8
0000707f9fbd965c  pop rsi
0000707f9fbd965d  pop rdi
0000707f9fbd965e  pop rdx
0000707f9fbd965f  pop rcx
0000707f9fbd9660  pop rax
0000707f9fbd9661  add rsp, 0x08
0000707f9fbd9665  jmp 0x0000707F9FBD6C4F
0000707f9fbd966a  sub rsp, 0x08
0000707f9fbd966e  push rax
0000707f9fbd966f  push rcx
0000707f9fbd9670  push rdx
0000707f9fbd9671  push rdi
0000707f9fbd9672  push rsi
0000707f9fbd9673  push r8
0000707f9fbd9675  push r9
0000707f9fbd9677  push r10
0000707f9fbd9679  push r11
0000707f9fbd967b  sub rsp, 0xF0
0000707f9fbd9682  vmovaps [rsp], xmm0
0000707f9fbd9687  vmovaps [rsp+0x10], xmm1
0000707f9fbd968d  vmovaps [rsp+0x20], xmm2
0000707f9fbd9693  vmovaps [rsp+0x30], xmm3
0000707f9fbd9699  vmovaps [rsp+0x40], xmm4
0000707f9fbd969f  vmovaps [rsp+0x50], xmm5
0000707f9fbd96a5  vmovaps [rsp+0x60], xmm6
0000707f9fbd96ab  vmovaps [rsp+0x70], xmm7
0000707f9fbd96b1  vmovaps [rsp+0x80], xmm8
0000707f9fbd96ba  vmovaps [rsp+0x90], xmm9
0000707f9fbd96c3  vmovaps [rsp+0xA0], xmm10
0000707f9fbd96cc  vmovaps [rsp+0xB0], xmm11
0000707f9fbd96d5  vmovaps [rsp+0xC0], xmm12
0000707f9fbd96de  vmovaps [rsp+0xD0], xmm14
0000707f9fbd96e7  vmovaps [rsp+0xE0], xmm15
0000707f9fbd96f0  sub rsp, 0x40
0000707f9fbd96f4  lea rdi, [rsp]
0000707f9fbd96f8  lea rsi, [rsp+0x10]
0000707f9fbd96fd  lea rdx, [rsp+0x20]
0000707f9fbd9702  lea rcx, [rsp+0x30]
0000707f9fbd9707  mov r8d, 0x00
0000707f9fbd970d  lea r9, [r15+0x3A8]
0000707f9fbd9714  movaps [rdi], xmm13
0000707f9fbd9718  movaps [rsi], xmm12
0000707f9fbd971c  movaps [rdx], xmm15
0000707f9fbd9720  movaps [rcx], xmm14
0000707f9fbd9724  mov rax, 0x5753922B7A50
0000707f9fbd972e  call rax
0000707f9fbd9730  movaps xmm13, [rsp]
0000707f9fbd9735  add rsp, 0x40
0000707f9fbd9739  vmovaps xmm0, [rsp]
0000707f9fbd973e  vmovaps xmm1, [rsp+0x10]
0000707f9fbd9744  vmovaps xmm2, [rsp+0x20]
0000707f9fbd974a  vmovaps xmm3, [rsp+0x30]
0000707f9fbd9750  vmovaps xmm4, [rsp+0x40]
0000707f9fbd9756  vmovaps xmm5, [rsp+0x50]
0000707f9fbd975c  vmovaps xmm6, [rsp+0x60]
0000707f9fbd9762  vmovaps xmm7, [rsp+0x70]
0000707f9fbd9768  vmovaps xmm8, [rsp+0x80]
0000707f9fbd9771  vmovaps xmm9, [rsp+0x90]
0000707f9fbd977a  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd9783  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd978c  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd9795  vmovaps xmm14, [rsp+0xD0]
0000707f9fbd979e  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd97a7  add rsp, 0xF0
0000707f9fbd97ae  pop r11
0000707f9fbd97b0  pop r10
0000707f9fbd97b2  pop r9
0000707f9fbd97b4  pop r8
0000707f9fbd97b6  pop rsi
0000707f9fbd97b7  pop rdi
0000707f9fbd97b8  pop rdx
0000707f9fbd97b9  pop rcx
0000707f9fbd97ba  pop rax
0000707f9fbd97bb  add rsp, 0x08
0000707f9fbd97bf  jmp 0x0000707F9FBD6C7D
0000707f9fbd97c4  sub rsp, 0x08
0000707f9fbd97c8  push rax
0000707f9fbd97c9  push rcx
0000707f9fbd97ca  push rdx
0000707f9fbd97cb  push rdi
0000707f9fbd97cc  push rsi
0000707f9fbd97cd  push r8
0000707f9fbd97cf  push r9
0000707f9fbd97d1  push r10
0000707f9fbd97d3  push r11
0000707f9fbd97d5  sub rsp, 0xF0
0000707f9fbd97dc  vmovaps [rsp], xmm0
0000707f9fbd97e1  vmovaps [rsp+0x10], xmm1
0000707f9fbd97e7  vmovaps [rsp+0x20], xmm2
0000707f9fbd97ed  vmovaps [rsp+0x30], xmm3
0000707f9fbd97f3  vmovaps [rsp+0x40], xmm4
0000707f9fbd97f9  vmovaps [rsp+0x50], xmm5
0000707f9fbd97ff  vmovaps [rsp+0x60], xmm6
0000707f9fbd9805  vmovaps [rsp+0x70], xmm7
0000707f9fbd980b  vmovaps [rsp+0x80], xmm8
0000707f9fbd9814  vmovaps [rsp+0x90], xmm9
0000707f9fbd981d  vmovaps [rsp+0xA0], xmm10
0000707f9fbd9826  vmovaps [rsp+0xB0], xmm11
0000707f9fbd982f  vmovaps [rsp+0xC0], xmm12
0000707f9fbd9838  vmovaps [rsp+0xD0], xmm13
0000707f9fbd9841  vmovaps [rsp+0xE0], xmm15
0000707f9fbd984a  sub rsp, 0x40
0000707f9fbd984e  lea rdi, [rsp]
0000707f9fbd9852  lea rsi, [rsp+0x10]
0000707f9fbd9857  lea rdx, [rsp+0x20]
0000707f9fbd985c  lea rcx, [rsp+0x30]
0000707f9fbd9861  mov r8d, 0x00
0000707f9fbd9867  lea r9, [r15+0x3A8]
0000707f9fbd986e  movaps [rdi], xmm14
0000707f9fbd9872  movaps [rsi], xmm11
0000707f9fbd9876  movaps [rdx], xmm1
0000707f9fbd9879  movaps [rcx], xmm15
0000707f9fbd987d  mov rax, 0x5753922B7A50
0000707f9fbd9887  call rax
0000707f9fbd9889  movaps xmm14, [rsp]
0000707f9fbd988e  add rsp, 0x40
0000707f9fbd9892  vmovaps xmm0, [rsp]
0000707f9fbd9897  vmovaps xmm1, [rsp+0x10]
0000707f9fbd989d  vmovaps xmm2, [rsp+0x20]
0000707f9fbd98a3  vmovaps xmm3, [rsp+0x30]
0000707f9fbd98a9  vmovaps xmm4, [rsp+0x40]
0000707f9fbd98af  vmovaps xmm5, [rsp+0x50]
0000707f9fbd98b5  vmovaps xmm6, [rsp+0x60]
0000707f9fbd98bb  vmovaps xmm7, [rsp+0x70]
0000707f9fbd98c1  vmovaps xmm8, [rsp+0x80]
0000707f9fbd98ca  vmovaps xmm9, [rsp+0x90]
0000707f9fbd98d3  vmovaps xmm10, [rsp+0xA0]
0000707f9fbd98dc  vmovaps xmm11, [rsp+0xB0]
0000707f9fbd98e5  vmovaps xmm12, [rsp+0xC0]
0000707f9fbd98ee  vmovaps xmm13, [rsp+0xD0]
0000707f9fbd98f7  vmovaps xmm15, [rsp+0xE0]
0000707f9fbd9900  add rsp, 0xF0
0000707f9fbd9907  pop r11
0000707f9fbd9909  pop r10
0000707f9fbd990b  pop r9
0000707f9fbd990d  pop r8
0000707f9fbd990f  pop rsi
0000707f9fbd9910  pop rdi
0000707f9fbd9911  pop rdx
0000707f9fbd9912  pop rcx
0000707f9fbd9913  pop rax
0000707f9fbd9914  add rsp, 0x08
0000707f9fbd9918  jmp 0x0000707F9FBD6CAB
0000707f9fbd991d  call 0x0000707F9FAACF70
0000707f9fbd9922  jmp 0x0000707F9FBD6CB9
0000707f9fbd9927  call 0x0000707F9FA0C380
0000707f9fbd992c  jmp 0x0000707F9FBD6CC3
0000707f9fbd9931  call 0x0000707F9FA08C20
0000707f9fbd9936  jmp 0x0000707F9FBD6CCD
0000707f9fbd993b  call 0x0000707F9FA0D600
0000707f9fbd9940  jmp 0x0000707F9FBD6CD7
0000707f9fbd9945  int3
0000707f9fbd9946  nop [rax+rax*1], ax
0000707f9fbd994f  nop
0000707f9fbd9950  mov eax, [r15+0x48]
0000707f9fbd9954  lea r14d, [eax+0x01]
0000707f9fbd9959  mov [rsp+0x10], r14d
0000707f9fbd995e  mov r14d, r14d
0000707f9fbd9961  mov [r15+0x48], r14
0000707f9fbd9965  xor eax, eax
0000707f9fbd9967  mov r14d, [rsp+0x10]
0000707f9fbd996c  cmp r14d, 0x1F4
0000707f9fbd9973  cmc
0000707f9fbd9974  lahf
0000707f9fbd9975  seto al
0000707f9fbd9978  mov [r15+0x108], eax
0000707f9fbd997f  mov eax, [r15+0x108]
0000707f9fbd9986  sahf
0000707f9fbd9987  jnz 0x0000707F9FBD99B9
0000707f9fbd9989  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd9991  jz 0x0000707F9FBDD2E0
0000707f9fbd9997  nop [rax+rax*1], ax
0000707f9fbd99a0  nop [rax+rax*1], eax
0000707f9fbd99a8  mov eax, 0x410670
0000707f9fbd99ad  mov [r15+0x100], rax
0000707f9fbd99b4  jmp 0x0000707F9F9FE110
0000707f9fbd99b9  cmp dword ptr [r15+0x318], 0x00
0000707f9fbd99c1  jz 0x0000707F9FBD99F0
0000707f9fbd99c7  nop [rax+rax*1], ax
0000707f9fbd99d0  nop [rax+rax*1], eax
0000707f9fbd99d8  mov eax, 0x4104EC
0000707f9fbd99dd  mov [r15+0x100], rax
0000707f9fbd99e4  jmp 0x0000707F9F9FE110
0000707f9fbd99e9  int3
0000707f9fbd99ea  int3
0000707f9fbd99eb  nop [rax+rax*1], eax
0000707f9fbd99f0  mov rax, [r15+0x40]
0000707f9fbd99f4  vxorps xmm1, xmm1, xmm1
0000707f9fbd99f8  vpbroadcastq xmm1, xmm1
0000707f9fbd99fd  vxorps xmm15, xmm15, xmm15
0000707f9fbd9a02  vpbroadcastq xmm15, xmm15
0000707f9fbd9a07  lea r14, [rax+0x30]
0000707f9fbd9a0b  mov r12, [r13+r14*1]
0000707f9fbd9a10  lea r14, [rax+0x38]
0000707f9fbd9a14  mov r11, [r13+r14*1]
0000707f9fbd9a19  movq xmm14, r12
0000707f9fbd9a1e  movq xmm13, r11
0000707f9fbd9a23  movq xmm14, xmm14
0000707f9fbd9a28  movq xmm13, xmm13
0000707f9fbd9a2d  vmovaps [rsp+0x10], xmm13
0000707f9fbd9a33  movq xmm13, xmm13
0000707f9fbd9a38  movaps [r15+0x270], xmm13
0000707f9fbd9a40  movaps xmm13, [r15+0x160]
0000707f9fbd9a48  vmovaps [rsp+0x20], xmm13
0000707f9fbd9a4e  vmovaps xmm12, [rsp+0x20]
0000707f9fbd9a54  por xmm13, xmm12
0000707f9fbd9a59  lea r14, [rax+0x20]
0000707f9fbd9a5d  mov r12, [r13+r14*1]
0000707f9fbd9a62  lea r14, [rax+0x28]
0000707f9fbd9a66  mov r11, [r13+r14*1]
0000707f9fbd9a6b  movq xmm12, r12
0000707f9fbd9a70  movq xmm11, r11
0000707f9fbd9a75  movq xmm12, xmm12
0000707f9fbd9a7a  movq xmm11, xmm11
0000707f9fbd9a7f  movaps xmm10, [r15+0x2D0]
0000707f9fbd9a87  vmovaps [rsp+0x20], xmm10
0000707f9fbd9a8d  vmovaps xmm9, [rsp+0x20]
0000707f9fbd9a93  por xmm10, xmm9
0000707f9fbd9a98  movaps xmm9, [r15+0x300]
0000707f9fbd9aa0  vmovaps [rsp+0x20], xmm9
0000707f9fbd9aa6  vmovaps xmm8, [rsp+0x20]
0000707f9fbd9aac  por xmm9, xmm8
0000707f9fbd9ab1  movaps xmm8, [r15+0x2B0]
0000707f9fbd9ab9  vmovaps [rsp+0x20], xmm8
0000707f9fbd9abf  vmovaps xmm7, [rsp+0x20]
0000707f9fbd9ac5  por xmm8, xmm7
0000707f9fbd9aca  movaps xmm7, [r15+0x180]
0000707f9fbd9ad2  vmovaps [rsp+0x20], xmm7
0000707f9fbd9ad8  vmovaps xmm6, [rsp+0x20]
0000707f9fbd9ade  por xmm7, xmm6
0000707f9fbd9ae2  lea r14, [rax+0x10]
0000707f9fbd9ae6  mov r12, [r13+r14*1]
0000707f9fbd9aeb  lea r14, [rax+0x18]
0000707f9fbd9aef  mov r11, [r13+r14*1]
0000707f9fbd9af4  movq xmm6, r12
0000707f9fbd9af9  movq xmm5, r11
0000707f9fbd9afe  movq xmm6, xmm6
0000707f9fbd9b02  movq xmm5, xmm5
0000707f9fbd9b06  movaps xmm4, [r15+0x200]
0000707f9fbd9b0e  vmovaps [rsp+0x20], xmm4
0000707f9fbd9b14  vmovaps xmm3, [rsp+0x20]
0000707f9fbd9b1a  por xmm4, xmm3
0000707f9fbd9b1e  movaps xmm3, [r15+0x1F0]
0000707f9fbd9b26  vmovaps [rsp+0x20], xmm3
0000707f9fbd9b2c  vmovaps xmm2, [rsp+0x20]
0000707f9fbd9b32  por xmm3, xmm2
0000707f9fbd9b36  movaps xmm2, [r15+0x2E0]
0000707f9fbd9b3e  vmovaps [rsp+0x20], xmm2
0000707f9fbd9b44  vmovaps [rsp+0x30], xmm1
0000707f9fbd9b4a  vmovaps xmm1, [rsp+0x20]
0000707f9fbd9b50  por xmm2, xmm1
0000707f9fbd9b54  movaps xmm1, [r15+0x2A0]
0000707f9fbd9b5c  vmovaps [rsp+0x20], xmm1
0000707f9fbd9b62  vmovaps [rsp+0x40], xmm15
0000707f9fbd9b68  vmovaps xmm15, [rsp+0x20]
0000707f9fbd9b6e  por xmm1, xmm15
0000707f9fbd9b73  movaps xmm15, [r15+0x280]
0000707f9fbd9b7b  vmovaps [rsp+0x20], xmm15
0000707f9fbd9b81  vmovaps [rsp+0x50], xmm1
0000707f9fbd9b87  vmovaps xmm1, [rsp+0x20]
0000707f9fbd9b8d  por xmm15, xmm1
0000707f9fbd9b92  movaps xmm1, [r15+0x1C0]
0000707f9fbd9b9a  vmovaps [rsp+0x20], xmm1
0000707f9fbd9ba0  vmovaps [rsp+0x60], xmm15
0000707f9fbd9ba6  vmovaps xmm15, [rsp+0x20]
0000707f9fbd9bac  por xmm1, xmm15
0000707f9fbd9bb1  movaps xmm15, [r15+0x210]
0000707f9fbd9bb9  vmovaps [rsp+0x20], xmm15
0000707f9fbd9bbf  vmovaps [rsp+0x70], xmm1
0000707f9fbd9bc5  vmovaps xmm1, [rsp+0x20]
0000707f9fbd9bcb  por xmm15, xmm1
0000707f9fbd9bd0  mov r14, [r13+rax*1]
0000707f9fbd9bd5  vmovq xmm1, r14
0000707f9fbd9bda  vpbroadcastq xmm1, xmm1
0000707f9fbd9bdf  vmovaps [rsp+0x20], xmm1
0000707f9fbd9be5  vxorps xmm1, xmm1, xmm1
0000707f9fbd9be9  vpbroadcastq xmm1, xmm1
0000707f9fbd9bee  mov r14, [r15+0xF8]
0000707f9fbd9bf5  vmovaps [rsp+0x80], xmm1
0000707f9fbd9bfe  movups xmm1, [r13+r14*1]
0000707f9fbd9c04  vmovaps [rsp+0x90], xmm1
0000707f9fbd9c0d  vxorps xmm1, xmm1, xmm1
0000707f9fbd9c11  vpbroadcastq xmm1, xmm1
0000707f9fbd9c16  lea r12, [rax+0x08]
0000707f9fbd9c1a  mov rax, [r13+r12*1]
0000707f9fbd9c1f  vmovaps [rsp+0xA0], xmm1
0000707f9fbd9c28  movq xmm1, rax
0000707f9fbd9c2d  movaps [r15+0x240], xmm1
0000707f9fbd9c35  mov rax, [r15+0x50]
0000707f9fbd9c39  mov [r15+0x60], rax
0000707f9fbd9c3d  mov qword ptr [r15+0x58], 0x40
0000707f9fbd9c45  vmovaps xmm1, [rsp+0x30]
0000707f9fbd9c4b  vmovaps [rsp+0x30], xmm15
0000707f9fbd9c51  vmovaps xmm15, [rsp+0x90]
0000707f9fbd9c5a  vmovaps [rsp+0x90], xmm14
0000707f9fbd9c63  vmovaps xmm14, [rsp+0x20]
0000707f9fbd9c69  vmovaps [rsp+0x20], xmm13
0000707f9fbd9c6f  vmovaps [rsp+0xB0], xmm12
0000707f9fbd9c78  movaps xmm13, xmm1
0000707f9fbd9c7c  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd9c87  vptest xmm12, xmm12
0000707f9fbd9c8c  jnz 0x0000707F9FBDA72F
0000707f9fbd9c92  movaps xmm1, [r15+0x250]
0000707f9fbd9c9a  vmovaps xmm15, [rsp+0x40]
0000707f9fbd9ca0  vmovaps [rsp+0x40], xmm13
0000707f9fbd9ca6  movaps xmm12, xmm15
0000707f9fbd9caa  vfmadd231pd xmm12, xmm1, xmm14
0000707f9fbd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
0000707f9fbd9cb5  vptest xmm13, xmm13
0000707f9fbd9cba  jnz 0x0000707F9FBDA888
0000707f9fbd9cc0  movaps xmm15, [r15+0x1E0]
0000707f9fbd9cc8  vmovaps [rsp+0xC0], xmm15
0000707f9fbd9cd1  vmovaps xmm13, [rsp+0xC0]
0000707f9fbd9cda  por xmm15, xmm13
0000707f9fbd9cdf  movaps xmm13, [r15+0x1D0]
0000707f9fbd9ce7  vmovaps [rsp+0xC0], xmm13
0000707f9fbd9cf0  vmovaps [rsp+0xD0], xmm1
0000707f9fbd9cf9  vmovaps xmm1, [rsp+0xC0]
0000707f9fbd9d02  por xmm13, xmm1
0000707f9fbd9d07  movaps xmm1, [r15+0x2C0]
0000707f9fbd9d0f  vmovaps [rsp+0xC0], xmm1
0000707f9fbd9d18  vmovaps [rsp+0xE0], xmm15
0000707f9fbd9d21  vmovaps xmm15, [rsp+0xC0]
0000707f9fbd9d2a  por xmm1, xmm15
0000707f9fbd9d2f  movaps xmm15, [r15+0x290]
0000707f9fbd9d37  vmovaps [rsp+0xC0], xmm15
0000707f9fbd9d40  vmovaps [rsp+0xF0], xmm1
0000707f9fbd9d49  vmovaps xmm1, [rsp+0xC0]
0000707f9fbd9d52  por xmm15, xmm1
0000707f9fbd9d57  movaps xmm1, [r15+0x260]
0000707f9fbd9d5f  vmovaps [rsp+0xC0], xmm1
0000707f9fbd9d68  vmovaps [rsp+0x100], xmm15
0000707f9fbd9d71  vmovaps xmm15, [rsp+0xC0]
0000707f9fbd9d7a  por xmm1, xmm15
0000707f9fbd9d7f  vmovaps xmm15, [rsp+0xD0]
0000707f9fbd9d88  vmovaps [rsp+0xC0], xmm1
0000707f9fbd9d91  vmovaps xmm1, [rsp+0xD0]
0000707f9fbd9d9a  por xmm15, xmm1
0000707f9fbd9d9f  lea r12, [r14+0xC0]
0000707f9fbd9da6  movups xmm1, [r13+r12*1]
0000707f9fbd9dac  mov [rsp+0xD0], rax
0000707f9fbd9db4  xor eax, eax
0000707f9fbd9db6  mov r12d, 0x40
0000707f9fbd9dbc  mov r11d, 0x200
0000707f9fbd9dc2  cmp r12, r11
0000707f9fbd9dc5  cmc
0000707f9fbd9dc6  lahf
0000707f9fbd9dc7  seto al
0000707f9fbd9dca  mov [r15+0x108], eax
0000707f9fbd9dd1  vmovaps [rsp+0x110], xmm1
0000707f9fbd9dda  vmovaps xmm1, [rsp+0x80]
0000707f9fbd9de3  vmovaps [rsp+0x80], xmm15
0000707f9fbd9dec  vmovaps xmm15, [rsp+0x110]
0000707f9fbd9df5  vmovaps [rsp+0x110], xmm13
0000707f9fbd9dfe  vmovaps [rsp+0x120], xmm12
0000707f9fbd9e07  movaps xmm13, xmm1
0000707f9fbd9e0b  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd9e16  vptest xmm12, xmm12
0000707f9fbd9e1b  jnz 0x0000707F9FBDA9EB
0000707f9fbd9e21  lea rax, [r14+0xB0]
0000707f9fbd9e28  movups xmm1, [r13+rax*1]
0000707f9fbd9e2e  vmovaps xmm15, [rsp+0xA0]
0000707f9fbd9e37  vmovaps [rsp+0xA0], xmm13
0000707f9fbd9e40  movaps xmm12, xmm15
0000707f9fbd9e44  vfmadd231pd xmm12, xmm1, xmm14
0000707f9fbd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
0000707f9fbd9e4f  vptest xmm13, xmm13
0000707f9fbd9e54  jnz 0x0000707F9FBDAB4E
0000707f9fbd9e5a  vmovaps xmm1, [rsp+0x30]
0000707f9fbd9e60  vmovaps xmm15, [rsp+0x30]
0000707f9fbd9e66  por xmm1, xmm15
0000707f9fbd9e6b  movaps [r15+0x210], xmm1
0000707f9fbd9e73  vmovaps xmm15, [rsp+0x70]
0000707f9fbd9e79  vmovaps xmm14, [rsp+0x70]
0000707f9fbd9e7f  por xmm15, xmm14
0000707f9fbd9e84  movaps [r15+0x1C0], xmm15
0000707f9fbd9e8c  vmovaps xmm14, [rsp+0x60]
0000707f9fbd9e92  vmovaps xmm13, [rsp+0x60]
0000707f9fbd9e98  por xmm14, xmm13
0000707f9fbd9e9d  movaps [r15+0x280], xmm14
0000707f9fbd9ea5  vmovaps xmm13, [rsp+0x50]
0000707f9fbd9eab  vmovaps [rsp+0x30], xmm1
0000707f9fbd9eb1  vmovaps xmm1, [rsp+0x50]
0000707f9fbd9eb7  por xmm13, xmm1
0000707f9fbd9ebc  movaps [r15+0x2A0], xmm13
0000707f9fbd9ec4  vmovaps [rsp+0x50], xmm2
0000707f9fbd9eca  vmovaps xmm1, [rsp+0x50]
0000707f9fbd9ed0  por xmm2, xmm1
0000707f9fbd9ed4  movaps [r15+0x2E0], xmm2
0000707f9fbd9edc  vmovaps [rsp+0x50], xmm3
0000707f9fbd9ee2  vmovaps xmm1, [rsp+0x50]
0000707f9fbd9ee8  por xmm3, xmm1
0000707f9fbd9eec  movaps [r15+0x1F0], xmm3
0000707f9fbd9ef4  vmovaps xmm1, [rsp+0x80]
0000707f9fbd9efd  vmovaps [rsp+0x50], xmm15
0000707f9fbd9f03  vmovaps xmm15, [rsp+0x80]
0000707f9fbd9f0c  por xmm1, xmm15
0000707f9fbd9f11  movaps [r15+0x250], xmm1
0000707f9fbd9f19  vmovaps xmm1, [rsp+0xC0]
0000707f9fbd9f22  vmovaps xmm15, [rsp+0xC0]
0000707f9fbd9f2b  por xmm1, xmm15
0000707f9fbd9f30  movaps [r15+0x260], xmm1
0000707f9fbd9f38  vmovaps xmm15, [rsp+0x100]
0000707f9fbd9f41  vmovaps [rsp+0x60], xmm1
0000707f9fbd9f47  vmovaps xmm1, [rsp+0x100]
0000707f9fbd9f50  por xmm15, xmm1
0000707f9fbd9f55  movaps [r15+0x290], xmm15
0000707f9fbd9f5d  vmovaps xmm1, [rsp+0xF0]
0000707f9fbd9f66  vmovaps [rsp+0x70], xmm15
0000707f9fbd9f6c  vmovaps xmm15, [rsp+0xF0]
0000707f9fbd9f75  por xmm1, xmm15
0000707f9fbd9f7a  movaps [r15+0x2C0], xmm1
0000707f9fbd9f82  movq xmm15, qword ptr [r15+0x240]
0000707f9fbd9f8b  vmovaps [rsp+0x80], xmm15
0000707f9fbd9f94  vpermilpd xmm15, xmm15, 0x00
0000707f9fbd9f9a  vmovaps [rsp+0xC0], xmm1
0000707f9fbd9fa3  vmovaps xmm1, [rsp+0x40]
0000707f9fbd9fa9  vmovaps [rsp+0x40], xmm15
0000707f9fbd9faf  vmovaps xmm15, [rsp+0x30]
0000707f9fbd9fb5  vmovaps [rsp+0x30], xmm14
0000707f9fbd9fbb  vmovaps xmm14, [rsp+0x40]
0000707f9fbd9fc1  vmovaps [rsp+0x40], xmm13
0000707f9fbd9fc7  vmovaps [rsp+0xF0], xmm12
0000707f9fbd9fd0  movaps xmm13, xmm1
0000707f9fbd9fd4  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000707f9fbd9fdf  vptest xmm12, xmm12
0000707f9fbd9fe4  jnz 0x0000707F9FBDACA7
0000707f9fbd9fea  vmovaps xmm1, [rsp+0x80]
0000707f9fbd9ff3  vpermilpd xmm1, xmm1, 0x00
0000707f9fbd9ff9  vmovaps xmm15, [rsp+0xA0]
0000707f9fbda002  movaps xmm14, xmm15
0000707f9fbda006  vfmadd231pd xmm14, xmm2, xmm1
0000707f9fbda00b  vcmppd xmm12, xmm14, xmm14, 0x03
0000707f9fbda011  vptest xmm12, xmm12
0000707f9fbda016  jnz 0x0000707F9FBDAE00
0000707f9fbda01c  vmovaps xmm1, [rsp+0x80]
0000707f9fbda025  vpermilpd xmm1, xmm1, 0x00
0000707f9fbda02b  vmovaps xmm15, [rsp+0x120]
0000707f9fbda034  vmovaps xmm12, [rsp+0x50]
0000707f9fbda03a  vmovaps [rsp+0x50], xmm14
0000707f9fbda040  movaps xmm2, xmm15
0000707f9fbda044  vfmadd231pd xmm2, xmm12, xmm1
0000707f9fbda049  vcmppd xmm14, xmm2, xmm2, 0x03
0000707f9fbda04e  vptest xmm14, xmm14
0000707f9fbda053  jnz 0x0000707F9FBDAF58
0000707f9fbda059  vmovaps xmm1, [rsp+0x110]
0000707f9fbda062  vmovaps xmm15, [rsp+0x110]
0000707f9fbda06b  por xmm1, xmm15
0000707f9fbda070  movaps [r15+0x1D0], xmm1
0000707f9fbda078  vmovaps xmm15, [rsp+0x80]
0000707f9fbda081  vpermilpd xmm15, xmm15, 0x00
0000707f9fbda087  vmovaps xmm14, [rsp+0xF0]
0000707f9fbda090  vmovaps [rsp+0x80], xmm1
0000707f9fbda099  movaps xmm12, xmm14
0000707f9fbda09d  vfmadd231pd xmm12, xmm3, xmm15
0000707f9fbda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
0000707f9fbda0a8  vptest xmm1, xmm1
0000707f9fbda0ad  jnz 0x0000707F9FBDB0AF
0000707f9fbda0b3  vmovaps [rsp+0xA0], xmm4
0000707f9fbda0bc  vmovaps xmm1, [rsp+0xA0]
0000707f9fbda0c5  por xmm4, xmm1
0000707f9fbda0c9  movaps [r15+0x200], xmm4
0000707f9fbda0d1  vmovaps xmm1, [rsp+0xE0]
0000707f9fbda0da  vmovaps xmm15, [rsp+0xE0]
0000707f9fbda0e3  por xmm1, xmm15
0000707f9fbda0e8  movaps [r15+0x1E0], xmm1
0000707f9fbda0f0  vmovaps [rsp+0xA0], xmm8
0000707f9fbda0f9  vmovaps xmm1, [rsp+0xA0]
0000707f9fbda102  por xmm8, xmm1
0000707f9fbda107  movaps [r15+0x2B0], xmm8
0000707f9fbda10f  vmovaps [rsp+0xA0], xmm9
0000707f9fbda118  vmovaps xmm1, [rsp+0xA0]
0000707f9fbda121  por xmm9, xmm1
0000707f9fbda126  movaps [r15+0x300], xmm9
0000707f9fbda12e  vmovaps [rsp+0xA0], xmm6
0000707f9fbda137  vpermilpd xmm6, xmm6, 0x00
0000707f9fbda13d  vmovaps xmm14, [rsp+0x60]
0000707f9fbda143  movaps xmm9, xmm13
0000707f9fbda147  vfmadd231pd xmm9, xmm14, xmm6
0000707f9fbda14c  vcmppd xmm3, xmm9, xmm9, 0x03
0000707f9fbda152  vptest xmm3, xmm3
0000707f9fbda157  jnz 0x0000707F9FBDB208
0000707f9fbda15d  vmovaps xmm14, [rsp+0xA0]
0000707f9fbda166  vpermilpd xmm14, xmm14, 0x00
0000707f9fbda16c  vmovaps xmm13, [rsp+0x50]
0000707f9fbda172  vmovaps xmm6, [rsp+0xC0]
0000707f9fbda17b  vmovaps [rsp+0x50], xmm1
0000707f9fbda181  movaps xmm3, xmm13
0000707f9fbda185  vfmadd231pd xmm3, xmm6, xmm14
0000707f9fbda18a  vcmppd xmm1, xmm3, xmm3, 0x03
0000707f9fbda18f  vptest xmm1, xmm1
0000707f9fbda194  jnz 0x0000707F9FBDB361
0000707f9fbda19a  vmovaps xmm1, [rsp+0xA0]
0000707f9fbda1a3  vpermilpd xmm1, xmm1, 0x00
0000707f9fbda1a9  vmovaps xmm14, [rsp+0x30]
0000707f9fbda1af  movaps xmm6, xmm2
0000707f9fbda1b2  vfmadd231pd xmm6, xmm14, xmm1
0000707f9fbda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
0000707f9fbda1bc  vptest xmm13, xmm13
0000707f9fbda1c1  jnz 0x0000707F9FBDB4B8
0000707f9fbda1c7  vmovaps xmm1, [rsp+0xA0]
0000707f9fbda1d0  vpermilpd xmm1, xmm1, 0x00
0000707f9fbda1d6  vmovaps xmm14, [rsp+0x80]
0000707f9fbda1df  movaps xmm13, xmm12
0000707f9fbda1e3  vfmadd231pd xmm13, xmm14, xmm1
0000707f9fbda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
0000707f9fbda1ee  vptest xmm2, xmm2
0000707f9fbda1f3  jnz 0x0000707F9FBDB60E
0000707f9fbda1f9  vmovaps [rsp+0x30], xmm7
0000707f9fbda1ff  vmovaps xmm1, [rsp+0x30]
0000707f9fbda205  por xmm7, xmm1
0000707f9fbda209  movaps [r15+0x180], xmm7
0000707f9fbda211  vmovaps [rsp+0x30], xmm10
0000707f9fbda217  vmovaps xmm1, [rsp+0x30]
0000707f9fbda21d  por xmm10, xmm1
0000707f9fbda222  movaps [r15+0x2D0], xmm10
0000707f9fbda22a  vmovaps [rsp+0x30], xmm5
0000707f9fbda230  vpermilpd xmm5, xmm5, 0x00
0000707f9fbda236  vmovaps xmm14, [rsp+0x50]
0000707f9fbda23c  movaps xmm12, xmm3
0000707f9fbda240  vfmadd231pd xmm12, xmm14, xmm5
0000707f9fbda245  vcmppd xmm10, xmm12, xmm12, 0x03
0000707f9fbda24b  vptest xmm10, xmm10
0000707f9fbda250  jnz 0x0000707F9FBDB767
0000707f9fbda256  vmovaps xmm14, [rsp+0x30]
0000707f9fbda25c  vpermilpd xmm14, xmm14, 0x00
0000707f9fbda262  movaps xmm10, xmm9
0000707f9fbda266  vfmadd231pd xmm10, xmm7, xmm14
0000707f9fbda26b  vcmppd xmm5, xmm10, xmm10, 0x03
0000707f9fbda271  vptest xmm5, xmm5
0000707f9fbda276  jnz 0x0000707F9FBDB8BF
0000707f9fbda27c  lea rax, [r14+0x80]
0000707f9fbda283  movups xmm14, [r13+rax*1]
0000707f9fbda289  movaps [r15+0x2F0], xmm14
0000707f9fbda291  vmovaps xmm9, [rsp+0x30]
0000707f9fbda297  vpermilpd xmm9, xmm9, 0x00
0000707f9fbda29d  vmovaps xmm7, [rsp+0x70]
0000707f9fbda2a3  movaps xmm5, xmm6
0000707f9fbda2a6  vfmadd231pd xmm5, xmm7, xmm9
0000707f9fbda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
0000707f9fbda2b0  vptest xmm3, xmm3
0000707f9fbda2b5  jnz 0x0000707F9FBDBA22
0000707f9fbda2bb  vmovaps xmm9, [rsp+0x30]
0000707f9fbda2c1  vpermilpd xmm9, xmm9, 0x00
0000707f9fbda2c7  movaps xmm7, xmm13
0000707f9fbda2cb  vfmadd231pd xmm7, xmm1, xmm9
0000707f9fbda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
0000707f9fbda2d5  vptest xmm6, xmm6
0000707f9fbda2da  jnz 0x0000707F9FBDBB78
0000707f9fbda2e0  vmovaps xmm1, [rsp+0x20]
0000707f9fbda2e6  vmovaps xmm13, [rsp+0x20]
0000707f9fbda2ec  por xmm1, xmm13
0000707f9fbda2f1  movaps [r15+0x160], xmm1
0000707f9fbda2f9  lea rax, [r14+0x40]
0000707f9fbda2fd  movups xmm13, [r13+rax*1]
0000707f9fbda303  lea rax, [r14+0x50]
0000707f9fbda307  movups xmm9, [r13+rax*1]
0000707f9fbda30d  movaps [r15+0x1B0], xmm13
0000707f9fbda315  movaps [r15+0x1A0], xmm9
0000707f9fbda31d  movaps xmm6, [r15+0x190]
0000707f9fbda325  vmovaps xmm3, [rsp+0xB0]
0000707f9fbda32e  vpermilpd xmm3, xmm3, 0x00
0000707f9fbda334  vmovaps [rsp+0x20], xmm1
0000707f9fbda33a  movaps xmm2, xmm12
0000707f9fbda33e  vfmadd231pd xmm2, xmm6, xmm3
0000707f9fbda343  vcmppd xmm1, xmm2, xmm2, 0x03
0000707f9fbda348  vptest xmm1, xmm1
0000707f9fbda34d  jnz 0x0000707F9FBDBCE3
0000707f9fbda353  vmovaps xmm1, [rsp+0xB0]
0000707f9fbda35c  vpermilpd xmm1, xmm1, 0x00
0000707f9fbda362  vmovaps xmm12, [rsp+0x20]
0000707f9fbda368  movaps xmm6, xmm10
0000707f9fbda36c  vfmadd231pd xmm6, xmm12, xmm1
0000707f9fbda371  vcmppd xmm3, xmm6, xmm6, 0x03
0000707f9fbda376  vptest xmm3, xmm3
0000707f9fbda37b  jnz 0x0000707F9FBDBE39
0000707f9fbda381  vmovaps xmm1, [rsp+0xB0]
0000707f9fbda38a  vpermilpd xmm1, xmm1, 0x00
0000707f9fbda390  vmovaps xmm12, [rsp+0x40]
0000707f9fbda396  movaps xmm10, xmm5
0000707f9fbda39a  vfmadd231pd xmm10, xmm12, xmm1
0000707f9fbda39f  vcmppd xmm3, xmm10, xmm10, 0x03
0000707f9fbda3a5  vptest xmm3, xmm3
0000707f9fbda3aa  jnz 0x0000707F9FBDBF90
0000707f9fbda3b0  vmovaps xmm1, [rsp+0xB0]
0000707f9fbda3b9  vpermilpd xmm1, xmm1, 0x00
0000707f9fbda3bf  movaps xmm12, xmm7
0000707f9fbda3c3  vfmadd231pd xmm12, xmm15, xmm1
0000707f9fbda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
0000707f9fbda3ce  vptest xmm5, xmm5
0000707f9fbda3d3  jnz 0x0000707F9FBDC0E8
0000707f9fbda3d9  lea rax, [r14+0x60]
0000707f9fbda3dd  movups xmm1, [r13+rax*1]
0000707f9fbda3e3  lea rax, [r14+0x70]
0000707f9fbda3e7  movups xmm15, [r13+rax*1]
0000707f9fbda3ed  movaps [r15+0x150], xmm1
0000707f9fbda3f5  movaps [r15+0x120], xmm15
0000707f9fbda3fd  vmovaps [rsp+0x20], xmm11
0000707f9fbda403  vpermilpd xmm11, xmm11, 0x00
0000707f9fbda409  movaps xmm7, xmm2
0000707f9fbda40c  vfmadd231pd xmm7, xmm9, xmm11
0000707f9fbda411  vcmppd xmm5, xmm7, xmm7, 0x03
0000707f9fbda416  vptest xmm5, xmm5
0000707f9fbda41b  jnz 0x0000707F9FBDC254
0000707f9fbda421  vmovaps xmm11, [rsp+0x20]
0000707f9fbda427  vpermilpd xmm11, xmm11, 0x00
0000707f9fbda42d  movaps xmm9, xmm6
0000707f9fbda431  vfmadd231pd xmm9, xmm1, xmm11
0000707f9fbda436  vcmppd xmm5, xmm9, xmm9, 0x03
0000707f9fbda43c  vptest xmm5, xmm5
0000707f9fbda441  jnz 0x0000707F9FBDC3AB
0000707f9fbda447  vmovaps xmm1, [rsp+0x20]
0000707f9fbda44d  vpermilpd xmm1, xmm1, 0x00
0000707f9fbda453  movaps xmm11, xmm10
0000707f9fbda457  vfmadd231pd xmm11, xmm8, xmm1
0000707f9fbda45c  vcmppd xmm6, xmm11, xmm11, 0x03
0000707f9fbda462  vptest xmm6, xmm6
0000707f9fbda467  jnz 0x0000707F9FBDC503
0000707f9fbda46d  vmovaps xmm1, [rsp+0x20]
0000707f9fbda473  vpermilpd xmm1, xmm1, 0x00
0000707f9fbda479  movaps xmm10, xmm12
0000707f9fbda47d  vfmadd231pd xmm10, xmm13, xmm1
0000707f9fbda482  vcmppd xmm8, xmm10, xmm10, 0x03
0000707f9fbda488  vptest xmm8, xmm8
0000707f9fbda48d  jnz 0x0000707F9FBDC65C
0000707f9fbda493  lea rax, [r14+0x20]
0000707f9fbda497  movups xmm1, [r13+rax*1]
0000707f9fbda49d  lea rax, [r14+0x30]
0000707f9fbda4a1  movups xmm13, [r13+rax*1]
0000707f9fbda4a7  vmovaps xmm12, [rsp+0x90]
0000707f9fbda4b0  vpermilpd xmm12, xmm12, 0x00
0000707f9fbda4b6  movaps xmm8, xmm7
0000707f9fbda4ba  vfmadd231pd xmm8, xmm4, xmm12
0000707f9fbda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
0000707f9fbda4c5  vptest xmm6, xmm6
0000707f9fbda4ca  jnz 0x0000707F9FBDC7C9
0000707f9fbda4d0  vmovaps xmm12, [rsp+0x90]
0000707f9fbda4d9  vpermilpd xmm12, xmm12, 0x00
0000707f9fbda4df  movaps xmm7, xmm9
0000707f9fbda4e3  vfmadd231pd xmm7, xmm14, xmm12
0000707f9fbda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
0000707f9fbda4ed  vptest xmm6, xmm6
0000707f9fbda4f2  jnz 0x0000707F9FBDC921
0000707f9fbda4f8  vmovaps xmm14, [rsp+0x90]
0000707f9fbda501  vpermilpd xmm14, xmm14, 0x00
0000707f9fbda507  movaps xmm12, xmm11
0000707f9fbda50b  vfmadd231pd xmm12, xmm15, xmm14
0000707f9fbda510  vcmppd xmm9, xmm12, xmm12, 0x03
0000707f9fbda516  vptest xmm9, xmm9
0000707f9fbda51b  jnz 0x0000707F9FBDCA79
0000707f9fbda521  vmovaps xmm15, [rsp+0x90]
0000707f9fbda52a  vpermilpd xmm15, xmm15, 0x00
0000707f9fbda530  movaps xmm11, xmm10
0000707f9fbda534  vfmadd231pd xmm11, xmm13, xmm15
0000707f9fbda539  vcmppd xmm14, xmm11, xmm11, 0x03
0000707f9fbda53f  vptest xmm14, xmm14
0000707f9fbda544  jnz 0x0000707F9FBDCBD3
0000707f9fbda54a  lea rax, [r14+0x90]
0000707f9fbda551  movups xmm15, [r13+rax*1]
0000707f9fbda557  lea rax, [r14+0xA0]
0000707f9fbda55e  movups xmm14, [r13+rax*1]
0000707f9fbda564  movaps [r15+0x140], xmm15
0000707f9fbda56c  movaps [r15+0x130], xmm14
0000707f9fbda574  vmovaps xmm13, [rsp+0x10]
0000707f9fbda57a  vpermilpd xmm13, xmm13, 0x00
0000707f9fbda580  movaps xmm10, xmm8
0000707f9fbda584  vfmadd231pd xmm10, xmm1, xmm13
0000707f9fbda589  vcmppd xmm9, xmm10, xmm10, 0x03
0000707f9fbda58f  vptest xmm9, xmm9
0000707f9fbda594  jnz 0x0000707F9FBDCD41
0000707f9fbda59a  movaps [r15+0x220], xmm10
0000707f9fbda5a2  lea rax, [r14+0x10]
0000707f9fbda5a6  movups xmm1, [r13+rax*1]
0000707f9fbda5ac  movaps [r15+0x240], xmm1
0000707f9fbda5b4  vmovaps xmm13, [rsp+0x10]
0000707f9fbda5ba  vpermilpd xmm13, xmm13, 0x00
0000707f9fbda5c0  movaps xmm9, xmm7
0000707f9fbda5c4  vfmadd231pd xmm9, xmm14, xmm13
0000707f9fbda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
0000707f9fbda5cf  vptest xmm8, xmm8
0000707f9fbda5d4  jnz 0x0000707F9FBDCEA4
0000707f9fbda5da  movaps [r15+0x110], xmm9
0000707f9fbda5e2  vmovaps xmm14, [rsp+0x10]
0000707f9fbda5e8  vpermilpd xmm14, xmm14, 0x00
0000707f9fbda5ee  movaps xmm13, xmm12
0000707f9fbda5f2  vfmadd231pd xmm13, xmm15, xmm14
0000707f9fbda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
0000707f9fbda5fd  vptest xmm8, xmm8
0000707f9fbda602  jnz 0x0000707F9FBDCFFD
0000707f9fbda608  movaps [r15+0x170], xmm13
0000707f9fbda610  vmovaps xmm15, [rsp+0x10]
0000707f9fbda616  vpermilpd xmm15, xmm15, 0x00
0000707f9fbda61c  movaps xmm14, xmm11
0000707f9fbda620  vfmadd231pd xmm14, xmm1, xmm15
0000707f9fbda625  vcmppd xmm12, xmm14, xmm14, 0x03
0000707f9fbda62b  vptest xmm12, xmm12
0000707f9fbda630  jnz 0x0000707F9FBDD157
0000707f9fbda636  movaps [r15+0x230], xmm14
0000707f9fbda63e  mov rax, [rsp+0xD0]
0000707f9fbda646  movups [r13+rax*1], xmm9
0000707f9fbda64c  lea r14, [rax+0x10]
0000707f9fbda650  movups [r13+r14*1], xmm13
0000707f9fbda656  lea r14, [rax+0x20]
0000707f9fbda65a  movups [r13+r14*1], xmm10
0000707f9fbda660  lea r14, [rax+0x30]
0000707f9fbda664  movups [r13+r14*1], xmm14
0000707f9fbda66a  mov eax, [r15+0x108]
0000707f9fbda671  sahf
0000707f9fbda672  jnz 0x0000707F9FBDA6A4
0000707f9fbda674  cmp dword ptr [r15+0x318], 0x00
0000707f9fbda67c  jz 0x0000707F9FBD9950
0000707f9fbda682  nop [rax+rax*1], ax
0000707f9fbda68b  nop [rax+rax*1], eax
0000707f9fbda693  mov eax, 0x410664
0000707f9fbda698  mov [r15+0x100], rax
0000707f9fbda69f  jmp 0x0000707F9F9FE110
0000707f9fbda6a4  cmp dword ptr [r15+0x318], 0x00
0000707f9fbda6ac  jz 0x0000707F9FBD6050
0000707f9fbda6b2  nop [rax+rax*1], ax
0000707f9fbda6bb  nop [rax+rax*1], eax
0000707f9fbda6c3  mov eax, 0x4104F0
0000707f9fbda6c8  mov [r15+0x100], rax
0000707f9fbda6cf  jmp 0x0000707F9F9FE110
0000707f9fbda6d4  int3
0000707f9fbda6d5  call 0x0000707F9FAE27E0
0000707f9fbda6da  jmp 0x0000707F9FBD9A10
0000707f9fbda6df  call 0x0000707F9FAE1570
0000707f9fbda6e4  jmp 0x0000707F9FBD9A19
0000707f9fbda6e9  call 0x0000707F9FAE27E0
0000707f9fbda6ee  jmp 0x0000707F9FBD9A62
0000707f9fbda6f3  call 0x0000707F9FAE1570
0000707f9fbda6f8  jmp 0x0000707F9FBD9A6B
0000707f9fbda6fd  call 0x0000707F9FAE27E0
0000707f9fbda702  jmp 0x0000707F9FBD9AEB
0000707f9fbda707  call 0x0000707F9FAE1570
0000707f9fbda70c  jmp 0x0000707F9FBD9AF4
0000707f9fbda711  call 0x0000707F9FA0DC20
0000707f9fbda716  jmp 0x0000707F9FBD9BD5
0000707f9fbda71b  call 0x0000707F9FAD64F0
0000707f9fbda720  jmp 0x0000707F9FBD9C04
0000707f9fbda725  call 0x0000707F9FAB47C0
0000707f9fbda72a  jmp 0x0000707F9FBD9C1F
0000707f9fbda72f  sub rsp, 0x08
0000707f9fbda733  push rax
0000707f9fbda734  push rcx
0000707f9fbda735  push rdx
0000707f9fbda736  push rdi
0000707f9fbda737  push rsi
0000707f9fbda738  push r8
0000707f9fbda73a  push r9
0000707f9fbda73c  push r10
0000707f9fbda73e  push r11
0000707f9fbda740  sub rsp, 0xF0
0000707f9fbda747  vmovaps [rsp], xmm0
0000707f9fbda74c  vmovaps [rsp+0x10], xmm1
0000707f9fbda752  vmovaps [rsp+0x20], xmm2
0000707f9fbda758  vmovaps [rsp+0x30], xmm3
0000707f9fbda75e  vmovaps [rsp+0x40], xmm4
0000707f9fbda764  vmovaps [rsp+0x50], xmm5
0000707f9fbda76a  vmovaps [rsp+0x60], xmm6
0000707f9fbda770  vmovaps [rsp+0x70], xmm7
0000707f9fbda776  vmovaps [rsp+0x80], xmm8
0000707f9fbda77f  vmovaps [rsp+0x90], xmm9
0000707f9fbda788  vmovaps [rsp+0xA0], xmm10
0000707f9fbda791  vmovaps [rsp+0xB0], xmm11
0000707f9fbda79a  vmovaps [rsp+0xC0], xmm12
0000707f9fbda7a3  vmovaps [rsp+0xD0], xmm14
0000707f9fbda7ac  vmovaps [rsp+0xE0], xmm15
0000707f9fbda7b5  sub rsp, 0x40
0000707f9fbda7b9  lea rdi, [rsp]
0000707f9fbda7bd  lea rsi, [rsp+0x10]
0000707f9fbda7c2  lea rdx, [rsp+0x20]
0000707f9fbda7c7  lea rcx, [rsp+0x30]
0000707f9fbda7cc  mov r8d, 0x00
0000707f9fbda7d2  lea r9, [r15+0x3A8]
0000707f9fbda7d9  movaps [rdi], xmm13
0000707f9fbda7dd  movaps [rsi], xmm1
0000707f9fbda7e0  movaps [rdx], xmm15
0000707f9fbda7e4  movaps [rcx], xmm14
0000707f9fbda7e8  mov rax, 0x5753922B7A50
0000707f9fbda7f2  call rax
0000707f9fbda7f4  movaps xmm13, [rsp]
0000707f9fbda7f9  add rsp, 0x40
0000707f9fbda7fd  vmovaps xmm0, [rsp]
0000707f9fbda802  vmovaps xmm1, [rsp+0x10]
0000707f9fbda808  vmovaps xmm2, [rsp+0x20]
0000707f9fbda80e  vmovaps xmm3, [rsp+0x30]
0000707f9fbda814  vmovaps xmm4, [rsp+0x40]
0000707f9fbda81a  vmovaps xmm5, [rsp+0x50]
0000707f9fbda820  vmovaps xmm6, [rsp+0x60]
0000707f9fbda826  vmovaps xmm7, [rsp+0x70]
0000707f9fbda82c  vmovaps xmm8, [rsp+0x80]
0000707f9fbda835  vmovaps xmm9, [rsp+0x90]
0000707f9fbda83e  vmovaps xmm10, [rsp+0xA0]
0000707f9fbda847  vmovaps xmm11, [rsp+0xB0]
0000707f9fbda850  vmovaps xmm12, [rsp+0xC0]
0000707f9fbda859  vmovaps xmm14, [rsp+0xD0]
0000707f9fbda862  vmovaps xmm15, [rsp+0xE0]
0000707f9fbda86b  add rsp, 0xF0
0000707f9fbda872  pop r11
0000707f9fbda874  pop r10
0000707f9fbda876  pop r9
0000707f9fbda878  pop r8
0000707f9fbda87a  pop rsi
0000707f9fbda87b  pop rdi
0000707f9fbda87c  pop rdx
0000707f9fbda87d  pop rcx
0000707f9fbda87e  pop rax
0000707f9fbda87f  add rsp, 0x08
0000707f9fbda883  jmp 0x0000707F9FBD9C92
0000707f9fbda888  sub rsp, 0x08
0000707f9fbda88c  push rax
0000707f9fbda88d  push rcx
0000707f9fbda88e  push rdx
0000707f9fbda88f  push rdi
0000707f9fbda890  push rsi
0000707f9fbda891  push r8
0000707f9fbda893  push r9
0000707f9fbda895  push r10
0000707f9fbda897  push r11
0000707f9fbda899  sub rsp, 0xF0
0000707f9fbda8a0  vmovaps [rsp], xmm0
0000707f9fbda8a5  vmovaps [rsp+0x10], xmm1
0000707f9fbda8ab  vmovaps [rsp+0x20], xmm2
0000707f9fbda8b1  vmovaps [rsp+0x30], xmm3
0000707f9fbda8b7  vmovaps [rsp+0x40], xmm4
0000707f9fbda8bd  vmovaps [rsp+0x50], xmm5
0000707f9fbda8c3  vmovaps [rsp+0x60], xmm6
0000707f9fbda8c9  vmovaps [rsp+0x70], xmm7
0000707f9fbda8cf  vmovaps [rsp+0x80], xmm8
0000707f9fbda8d8  vmovaps [rsp+0x90], xmm9
0000707f9fbda8e1  vmovaps [rsp+0xA0], xmm10
0000707f9fbda8ea  vmovaps [rsp+0xB0], xmm11
0000707f9fbda8f3  vmovaps [rsp+0xC0], xmm13
0000707f9fbda8fc  vmovaps [rsp+0xD0], xmm14
0000707f9fbda905  vmovaps [rsp+0xE0], xmm15
0000707f9fbda90e  sub rsp, 0x40
0000707f9fbda912  lea rdi, [rsp]
0000707f9fbda916  lea rsi, [rsp+0x10]
0000707f9fbda91b  lea rdx, [rsp+0x20]
0000707f9fbda920  lea rcx, [rsp+0x30]
0000707f9fbda925  mov r8d, 0x00
0000707f9fbda92b  lea r9, [r15+0x3A8]
0000707f9fbda932  movaps [rdi], xmm12
0000707f9fbda936  movaps [rsi], xmm15
0000707f9fbda93a  movaps [rdx], xmm1
0000707f9fbda93d  movaps [rcx], xmm14
0000707f9fbda941  mov rax, 0x5753922B7A50
0000707f9fbda94b  call rax
0000707f9fbda94d  movaps xmm12, [rsp]
0000707f9fbda952  add rsp, 0x40
0000707f9fbda956  vmovaps xmm0, [rsp]
0000707f9fbda95b  vmovaps xmm1, [rsp+0x10]
0000707f9fbda961  vmovaps xmm2, [rsp+0x20]
0000707f9fbda967  vmovaps xmm3, [rsp+0x30]
0000707f9fbda96d  vmovaps xmm4, [rsp+0x40]
0000707f9fbda973  vmovaps xmm5, [rsp+0x50]
0000707f9fbda979  vmovaps xmm6, [rsp+0x60]
0000707f9fbda97f  vmovaps xmm7, [rsp+0x70]
0000707f9fbda985  vmovaps xmm8, [rsp+0x80]
0000707f9fbda98e  vmovaps xmm9, [rsp+0x90]
0000707f9fbda997  vmovaps xmm10, [rsp+0xA0]
0000707f9fbda9a0  vmovaps xmm11, [rsp+0xB0]
0000707f9fbda9a9  vmovaps xmm13, [rsp+0xC0]
0000707f9fbda9b2  vmovaps xmm14, [rsp+0xD0]
0000707f9fbda9bb  vmovaps xmm15, [rsp+0xE0]
0000707f9fbda9c4  add rsp, 0xF0
0000707f9fbda9cb  pop r11
0000707f9fbda9cd  pop r10
0000707f9fbda9cf  pop r9
0000707f9fbda9d1  pop r8
0000707f9fbda9d3  pop rsi
0000707f9fbda9d4  pop rdi
0000707f9fbda9d5  pop rdx
0000707f9fbda9d6  pop rcx
0000707f9fbda9d7  pop rax
0000707f9fbda9d8  add rsp, 0x08
0000707f9fbda9dc  jmp 0x0000707F9FBD9CC0
0000707f9fbda9e1  call 0x0000707F9FAB52F0
0000707f9fbda9e6  jmp 0x0000707F9FBD9DAC
0000707f9fbda9eb  sub rsp, 0x08
0000707f9fbda9ef  push rax
0000707f9fbda9f0  push rcx
0000707f9fbda9f1  push rdx
0000707f9fbda9f2  push rdi
0000707f9fbda9f3  push rsi
0000707f9fbda9f4  push r8
0000707f9fbda9f6  push r9
0000707f9fbda9f8  push r10
0000707f9fbda9fa  push r11
0000707f9fbda9fc  sub rsp, 0xF0
0000707f9fbdaa03  vmovaps [rsp], xmm0
0000707f9fbdaa08  vmovaps [rsp+0x10], xmm1
0000707f9fbdaa0e  vmovaps [rsp+0x20], xmm2
0000707f9fbdaa14  vmovaps [rsp+0x30], xmm3
0000707f9fbdaa1a  vmovaps [rsp+0x40], xmm4
0000707f9fbdaa20  vmovaps [rsp+0x50], xmm5
0000707f9fbdaa26  vmovaps [rsp+0x60], xmm6
0000707f9fbdaa2c  vmovaps [rsp+0x70], xmm7
0000707f9fbdaa32  vmovaps [rsp+0x80], xmm8
0000707f9fbdaa3b  vmovaps [rsp+0x90], xmm9
0000707f9fbdaa44  vmovaps [rsp+0xA0], xmm10
0000707f9fbdaa4d  vmovaps [rsp+0xB0], xmm11
0000707f9fbdaa56  vmovaps [rsp+0xC0], xmm12
0000707f9fbdaa5f  vmovaps [rsp+0xD0], xmm14
0000707f9fbdaa68  vmovaps [rsp+0xE0], xmm15
0000707f9fbdaa71  sub rsp, 0x40
0000707f9fbdaa75  lea rdi, [rsp]
0000707f9fbdaa79  lea rsi, [rsp+0x10]
0000707f9fbdaa7e  lea rdx, [rsp+0x20]
0000707f9fbdaa83  lea rcx, [rsp+0x30]
0000707f9fbdaa88  mov r8d, 0x00
0000707f9fbdaa8e  lea r9, [r15+0x3A8]
0000707f9fbdaa95  movaps [rdi], xmm13
0000707f9fbdaa99  movaps [rsi], xmm1
0000707f9fbdaa9c  movaps [rdx], xmm15
0000707f9fbdaaa0  movaps [rcx], xmm14
0000707f9fbdaaa4  mov rax, 0x5753922B7A50
0000707f9fbdaaae  call rax
0000707f9fbdaab0  movaps xmm13, [rsp]
0000707f9fbdaab5  add rsp, 0x40
0000707f9fbdaab9  vmovaps xmm0, [rsp]
0000707f9fbdaabe  vmovaps xmm1, [rsp+0x10]
0000707f9fbdaac4  vmovaps xmm2, [rsp+0x20]
0000707f9fbdaaca  vmovaps xmm3, [rsp+0x30]
0000707f9fbdaad0  vmovaps xmm4, [rsp+0x40]
0000707f9fbdaad6  vmovaps xmm5, [rsp+0x50]
0000707f9fbdaadc  vmovaps xmm6, [rsp+0x60]
0000707f9fbdaae2  vmovaps xmm7, [rsp+0x70]
0000707f9fbdaae8  vmovaps xmm8, [rsp+0x80]
0000707f9fbdaaf1  vmovaps xmm9, [rsp+0x90]
0000707f9fbdaafa  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdab03  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdab0c  vmovaps xmm12, [rsp+0xC0]
0000707f9fbdab15  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdab1e  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdab27  add rsp, 0xF0
0000707f9fbdab2e  pop r11
0000707f9fbdab30  pop r10
0000707f9fbdab32  pop r9
0000707f9fbdab34  pop r8
0000707f9fbdab36  pop rsi
0000707f9fbdab37  pop rdi
0000707f9fbdab38  pop rdx
0000707f9fbdab39  pop rcx
0000707f9fbdab3a  pop rax
0000707f9fbdab3b  add rsp, 0x08
0000707f9fbdab3f  jmp 0x0000707F9FBD9E21
0000707f9fbdab44  call 0x0000707F9F9FF430
0000707f9fbdab49  jmp 0x0000707F9FBD9E2E
0000707f9fbdab4e  sub rsp, 0x08
0000707f9fbdab52  push rax
0000707f9fbdab53  push rcx
0000707f9fbdab54  push rdx
0000707f9fbdab55  push rdi
0000707f9fbdab56  push rsi
0000707f9fbdab57  push r8
0000707f9fbdab59  push r9
0000707f9fbdab5b  push r10
0000707f9fbdab5d  push r11
0000707f9fbdab5f  sub rsp, 0xF0
0000707f9fbdab66  vmovaps [rsp], xmm0
0000707f9fbdab6b  vmovaps [rsp+0x10], xmm1
0000707f9fbdab71  vmovaps [rsp+0x20], xmm2
0000707f9fbdab77  vmovaps [rsp+0x30], xmm3
0000707f9fbdab7d  vmovaps [rsp+0x40], xmm4
0000707f9fbdab83  vmovaps [rsp+0x50], xmm5
0000707f9fbdab89  vmovaps [rsp+0x60], xmm6
0000707f9fbdab8f  vmovaps [rsp+0x70], xmm7
0000707f9fbdab95  vmovaps [rsp+0x80], xmm8
0000707f9fbdab9e  vmovaps [rsp+0x90], xmm9
0000707f9fbdaba7  vmovaps [rsp+0xA0], xmm10
0000707f9fbdabb0  vmovaps [rsp+0xB0], xmm11
0000707f9fbdabb9  vmovaps [rsp+0xC0], xmm13
0000707f9fbdabc2  vmovaps [rsp+0xD0], xmm14
0000707f9fbdabcb  vmovaps [rsp+0xE0], xmm15
0000707f9fbdabd4  sub rsp, 0x40
0000707f9fbdabd8  lea rdi, [rsp]
0000707f9fbdabdc  lea rsi, [rsp+0x10]
0000707f9fbdabe1  lea rdx, [rsp+0x20]
0000707f9fbdabe6  lea rcx, [rsp+0x30]
0000707f9fbdabeb  mov r8d, 0x00
0000707f9fbdabf1  lea r9, [r15+0x3A8]
0000707f9fbdabf8  movaps [rdi], xmm12
0000707f9fbdabfc  movaps [rsi], xmm15
0000707f9fbdac00  movaps [rdx], xmm1
0000707f9fbdac03  movaps [rcx], xmm14
0000707f9fbdac07  mov rax, 0x5753922B7A50
0000707f9fbdac11  call rax
0000707f9fbdac13  movaps xmm12, [rsp]
0000707f9fbdac18  add rsp, 0x40
0000707f9fbdac1c  vmovaps xmm0, [rsp]
0000707f9fbdac21  vmovaps xmm1, [rsp+0x10]
0000707f9fbdac27  vmovaps xmm2, [rsp+0x20]
0000707f9fbdac2d  vmovaps xmm3, [rsp+0x30]
0000707f9fbdac33  vmovaps xmm4, [rsp+0x40]
0000707f9fbdac39  vmovaps xmm5, [rsp+0x50]
0000707f9fbdac3f  vmovaps xmm6, [rsp+0x60]
0000707f9fbdac45  vmovaps xmm7, [rsp+0x70]
0000707f9fbdac4b  vmovaps xmm8, [rsp+0x80]
0000707f9fbdac54  vmovaps xmm9, [rsp+0x90]
0000707f9fbdac5d  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdac66  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdac6f  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdac78  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdac81  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdac8a  add rsp, 0xF0
0000707f9fbdac91  pop r11
0000707f9fbdac93  pop r10
0000707f9fbdac95  pop r9
0000707f9fbdac97  pop r8
0000707f9fbdac99  pop rsi
0000707f9fbdac9a  pop rdi
0000707f9fbdac9b  pop rdx
0000707f9fbdac9c  pop rcx
0000707f9fbdac9d  pop rax
0000707f9fbdac9e  add rsp, 0x08
0000707f9fbdaca2  jmp 0x0000707F9FBD9E5A
0000707f9fbdaca7  sub rsp, 0x08
0000707f9fbdacab  push rax
0000707f9fbdacac  push rcx
0000707f9fbdacad  push rdx
0000707f9fbdacae  push rdi
0000707f9fbdacaf  push rsi
0000707f9fbdacb0  push r8
0000707f9fbdacb2  push r9
0000707f9fbdacb4  push r10
0000707f9fbdacb6  push r11
0000707f9fbdacb8  sub rsp, 0xF0
0000707f9fbdacbf  vmovaps [rsp], xmm0
0000707f9fbdacc4  vmovaps [rsp+0x10], xmm1
0000707f9fbdacca  vmovaps [rsp+0x20], xmm2
0000707f9fbdacd0  vmovaps [rsp+0x30], xmm3
0000707f9fbdacd6  vmovaps [rsp+0x40], xmm4
0000707f9fbdacdc  vmovaps [rsp+0x50], xmm5
0000707f9fbdace2  vmovaps [rsp+0x60], xmm6
0000707f9fbdace8  vmovaps [rsp+0x70], xmm7
0000707f9fbdacee  vmovaps [rsp+0x80], xmm8
0000707f9fbdacf7  vmovaps [rsp+0x90], xmm9
0000707f9fbdad00  vmovaps [rsp+0xA0], xmm10
0000707f9fbdad09  vmovaps [rsp+0xB0], xmm11
0000707f9fbdad12  vmovaps [rsp+0xC0], xmm12
0000707f9fbdad1b  vmovaps [rsp+0xD0], xmm14
0000707f9fbdad24  vmovaps [rsp+0xE0], xmm15
0000707f9fbdad2d  sub rsp, 0x40
0000707f9fbdad31  lea rdi, [rsp]
0000707f9fbdad35  lea rsi, [rsp+0x10]
0000707f9fbdad3a  lea rdx, [rsp+0x20]
0000707f9fbdad3f  lea rcx, [rsp+0x30]
0000707f9fbdad44  mov r8d, 0x00
0000707f9fbdad4a  lea r9, [r15+0x3A8]
0000707f9fbdad51  movaps [rdi], xmm13
0000707f9fbdad55  movaps [rsi], xmm1
0000707f9fbdad58  movaps [rdx], xmm15
0000707f9fbdad5c  movaps [rcx], xmm14
0000707f9fbdad60  mov rax, 0x5753922B7A50
0000707f9fbdad6a  call rax
0000707f9fbdad6c  movaps xmm13, [rsp]
0000707f9fbdad71  add rsp, 0x40
0000707f9fbdad75  vmovaps xmm0, [rsp]
0000707f9fbdad7a  vmovaps xmm1, [rsp+0x10]
0000707f9fbdad80  vmovaps xmm2, [rsp+0x20]
0000707f9fbdad86  vmovaps xmm3, [rsp+0x30]
0000707f9fbdad8c  vmovaps xmm4, [rsp+0x40]
0000707f9fbdad92  vmovaps xmm5, [rsp+0x50]
0000707f9fbdad98  vmovaps xmm6, [rsp+0x60]
0000707f9fbdad9e  vmovaps xmm7, [rsp+0x70]
0000707f9fbdada4  vmovaps xmm8, [rsp+0x80]
0000707f9fbdadad  vmovaps xmm9, [rsp+0x90]
0000707f9fbdadb6  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdadbf  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdadc8  vmovaps xmm12, [rsp+0xC0]
0000707f9fbdadd1  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdadda  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdade3  add rsp, 0xF0
0000707f9fbdadea  pop r11
0000707f9fbdadec  pop r10
0000707f9fbdadee  pop r9
0000707f9fbdadf0  pop r8
0000707f9fbdadf2  pop rsi
0000707f9fbdadf3  pop rdi
0000707f9fbdadf4  pop rdx
0000707f9fbdadf5  pop rcx
0000707f9fbdadf6  pop rax
0000707f9fbdadf7  add rsp, 0x08
0000707f9fbdadfb  jmp 0x0000707F9FBD9FEA
0000707f9fbdae00  sub rsp, 0x08
0000707f9fbdae04  push rax
0000707f9fbdae05  push rcx
0000707f9fbdae06  push rdx
0000707f9fbdae07  push rdi
0000707f9fbdae08  push rsi
0000707f9fbdae09  push r8
0000707f9fbdae0b  push r9
0000707f9fbdae0d  push r10
0000707f9fbdae0f  push r11
0000707f9fbdae11  sub rsp, 0xF0
0000707f9fbdae18  vmovaps [rsp], xmm0
0000707f9fbdae1d  vmovaps [rsp+0x10], xmm1
0000707f9fbdae23  vmovaps [rsp+0x20], xmm2
0000707f9fbdae29  vmovaps [rsp+0x30], xmm3
0000707f9fbdae2f  vmovaps [rsp+0x40], xmm4
0000707f9fbdae35  vmovaps [rsp+0x50], xmm5
0000707f9fbdae3b  vmovaps [rsp+0x60], xmm6
0000707f9fbdae41  vmovaps [rsp+0x70], xmm7
0000707f9fbdae47  vmovaps [rsp+0x80], xmm8
0000707f9fbdae50  vmovaps [rsp+0x90], xmm9
0000707f9fbdae59  vmovaps [rsp+0xA0], xmm10
0000707f9fbdae62  vmovaps [rsp+0xB0], xmm11
0000707f9fbdae6b  vmovaps [rsp+0xC0], xmm12
0000707f9fbdae74  vmovaps [rsp+0xD0], xmm13
0000707f9fbdae7d  vmovaps [rsp+0xE0], xmm15
0000707f9fbdae86  sub rsp, 0x40
0000707f9fbdae8a  lea rdi, [rsp]
0000707f9fbdae8e  lea rsi, [rsp+0x10]
0000707f9fbdae93  lea rdx, [rsp+0x20]
0000707f9fbdae98  lea rcx, [rsp+0x30]
0000707f9fbdae9d  mov r8d, 0x00
0000707f9fbdaea3  lea r9, [r15+0x3A8]
0000707f9fbdaeaa  movaps [rdi], xmm14
0000707f9fbdaeae  movaps [rsi], xmm15
0000707f9fbdaeb2  movaps [rdx], xmm2
0000707f9fbdaeb5  movaps [rcx], xmm1
0000707f9fbdaeb8  mov rax, 0x5753922B7A50
0000707f9fbdaec2  call rax
0000707f9fbdaec4  movaps xmm14, [rsp]
0000707f9fbdaec9  add rsp, 0x40
0000707f9fbdaecd  vmovaps xmm0, [rsp]
0000707f9fbdaed2  vmovaps xmm1, [rsp+0x10]
0000707f9fbdaed8  vmovaps xmm2, [rsp+0x20]
0000707f9fbdaede  vmovaps xmm3, [rsp+0x30]
0000707f9fbdaee4  vmovaps xmm4, [rsp+0x40]
0000707f9fbdaeea  vmovaps xmm5, [rsp+0x50]
0000707f9fbdaef0  vmovaps xmm6, [rsp+0x60]
0000707f9fbdaef6  vmovaps xmm7, [rsp+0x70]
0000707f9fbdaefc  vmovaps xmm8, [rsp+0x80]
0000707f9fbdaf05  vmovaps xmm9, [rsp+0x90]
0000707f9fbdaf0e  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdaf17  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdaf20  vmovaps xmm12, [rsp+0xC0]
0000707f9fbdaf29  vmovaps xmm13, [rsp+0xD0]
0000707f9fbdaf32  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdaf3b  add rsp, 0xF0
0000707f9fbdaf42  pop r11
0000707f9fbdaf44  pop r10
0000707f9fbdaf46  pop r9
0000707f9fbdaf48  pop r8
0000707f9fbdaf4a  pop rsi
0000707f9fbdaf4b  pop rdi
0000707f9fbdaf4c  pop rdx
0000707f9fbdaf4d  pop rcx
0000707f9fbdaf4e  pop rax
0000707f9fbdaf4f  add rsp, 0x08
0000707f9fbdaf53  jmp 0x0000707F9FBDA01C
0000707f9fbdaf58  sub rsp, 0x08
0000707f9fbdaf5c  push rax
0000707f9fbdaf5d  push rcx
0000707f9fbdaf5e  push rdx
0000707f9fbdaf5f  push rdi
0000707f9fbdaf60  push rsi
0000707f9fbdaf61  push r8
0000707f9fbdaf63  push r9
0000707f9fbdaf65  push r10
0000707f9fbdaf67  push r11
0000707f9fbdaf69  sub rsp, 0xF0
0000707f9fbdaf70  vmovaps [rsp], xmm0
0000707f9fbdaf75  vmovaps [rsp+0x10], xmm1
0000707f9fbdaf7b  vmovaps [rsp+0x20], xmm3
0000707f9fbdaf81  vmovaps [rsp+0x30], xmm4
0000707f9fbdaf87  vmovaps [rsp+0x40], xmm5
0000707f9fbdaf8d  vmovaps [rsp+0x50], xmm6
0000707f9fbdaf93  vmovaps [rsp+0x60], xmm7
0000707f9fbdaf99  vmovaps [rsp+0x70], xmm8
0000707f9fbdaf9f  vmovaps [rsp+0x80], xmm9
0000707f9fbdafa8  vmovaps [rsp+0x90], xmm10
0000707f9fbdafb1  vmovaps [rsp+0xA0], xmm11
0000707f9fbdafba  vmovaps [rsp+0xB0], xmm12
0000707f9fbdafc3  vmovaps [rsp+0xC0], xmm13
0000707f9fbdafcc  vmovaps [rsp+0xD0], xmm14
0000707f9fbdafd5  vmovaps [rsp+0xE0], xmm15
0000707f9fbdafde  sub rsp, 0x40
0000707f9fbdafe2  lea rdi, [rsp]
0000707f9fbdafe6  lea rsi, [rsp+0x10]
0000707f9fbdafeb  lea rdx, [rsp+0x20]
0000707f9fbdaff0  lea rcx, [rsp+0x30]
0000707f9fbdaff5  mov r8d, 0x00
0000707f9fbdaffb  lea r9, [r15+0x3A8]
0000707f9fbdb002  movaps [rdi], xmm2
0000707f9fbdb005  movaps [rsi], xmm15
0000707f9fbdb009  movaps [rdx], xmm12
0000707f9fbdb00d  movaps [rcx], xmm1
0000707f9fbdb010  mov rax, 0x5753922B7A50
0000707f9fbdb01a  call rax
0000707f9fbdb01c  movaps xmm2, [rsp]
0000707f9fbdb020  add rsp, 0x40
0000707f9fbdb024  vmovaps xmm0, [rsp]
0000707f9fbdb029  vmovaps xmm1, [rsp+0x10]
0000707f9fbdb02f  vmovaps xmm3, [rsp+0x20]
0000707f9fbdb035  vmovaps xmm4, [rsp+0x30]
0000707f9fbdb03b  vmovaps xmm5, [rsp+0x40]
0000707f9fbdb041  vmovaps xmm6, [rsp+0x50]
0000707f9fbdb047  vmovaps xmm7, [rsp+0x60]
0000707f9fbdb04d  vmovaps xmm8, [rsp+0x70]
0000707f9fbdb053  vmovaps xmm9, [rsp+0x80]
0000707f9fbdb05c  vmovaps xmm10, [rsp+0x90]
0000707f9fbdb065  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdb06e  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdb077  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdb080  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdb089  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdb092  add rsp, 0xF0
0000707f9fbdb099  pop r11
0000707f9fbdb09b  pop r10
0000707f9fbdb09d  pop r9
0000707f9fbdb09f  pop r8
0000707f9fbdb0a1  pop rsi
0000707f9fbdb0a2  pop rdi
0000707f9fbdb0a3  pop rdx
0000707f9fbdb0a4  pop rcx
0000707f9fbdb0a5  pop rax
0000707f9fbdb0a6  add rsp, 0x08
0000707f9fbdb0aa  jmp 0x0000707F9FBDA059
0000707f9fbdb0af  sub rsp, 0x08
0000707f9fbdb0b3  push rax
0000707f9fbdb0b4  push rcx
0000707f9fbdb0b5  push rdx
0000707f9fbdb0b6  push rdi
0000707f9fbdb0b7  push rsi
0000707f9fbdb0b8  push r8
0000707f9fbdb0ba  push r9
0000707f9fbdb0bc  push r10
0000707f9fbdb0be  push r11
0000707f9fbdb0c0  sub rsp, 0xF0
0000707f9fbdb0c7  vmovaps [rsp], xmm0
0000707f9fbdb0cc  vmovaps [rsp+0x10], xmm1
0000707f9fbdb0d2  vmovaps [rsp+0x20], xmm2
0000707f9fbdb0d8  vmovaps [rsp+0x30], xmm3
0000707f9fbdb0de  vmovaps [rsp+0x40], xmm4
0000707f9fbdb0e4  vmovaps [rsp+0x50], xmm5
0000707f9fbdb0ea  vmovaps [rsp+0x60], xmm6
0000707f9fbdb0f0  vmovaps [rsp+0x70], xmm7
0000707f9fbdb0f6  vmovaps [rsp+0x80], xmm8
0000707f9fbdb0ff  vmovaps [rsp+0x90], xmm9
0000707f9fbdb108  vmovaps [rsp+0xA0], xmm10
0000707f9fbdb111  vmovaps [rsp+0xB0], xmm11
0000707f9fbdb11a  vmovaps [rsp+0xC0], xmm13
0000707f9fbdb123  vmovaps [rsp+0xD0], xmm14
0000707f9fbdb12c  vmovaps [rsp+0xE0], xmm15
0000707f9fbdb135  sub rsp, 0x40
0000707f9fbdb139  lea rdi, [rsp]
0000707f9fbdb13d  lea rsi, [rsp+0x10]
0000707f9fbdb142  lea rdx, [rsp+0x20]
0000707f9fbdb147  lea rcx, [rsp+0x30]
0000707f9fbdb14c  mov r8d, 0x00
0000707f9fbdb152  lea r9, [r15+0x3A8]
0000707f9fbdb159  movaps [rdi], xmm12
0000707f9fbdb15d  movaps [rsi], xmm14
0000707f9fbdb161  movaps [rdx], xmm3
0000707f9fbdb164  movaps [rcx], xmm15
0000707f9fbdb168  mov rax, 0x5753922B7A50
0000707f9fbdb172  call rax
0000707f9fbdb174  movaps xmm12, [rsp]
0000707f9fbdb179  add rsp, 0x40
0000707f9fbdb17d  vmovaps xmm0, [rsp]
0000707f9fbdb182  vmovaps xmm1, [rsp+0x10]
0000707f9fbdb188  vmovaps xmm2, [rsp+0x20]
0000707f9fbdb18e  vmovaps xmm3, [rsp+0x30]
0000707f9fbdb194  vmovaps xmm4, [rsp+0x40]
0000707f9fbdb19a  vmovaps xmm5, [rsp+0x50]
0000707f9fbdb1a0  vmovaps xmm6, [rsp+0x60]
0000707f9fbdb1a6  vmovaps xmm7, [rsp+0x70]
0000707f9fbdb1ac  vmovaps xmm8, [rsp+0x80]
0000707f9fbdb1b5  vmovaps xmm9, [rsp+0x90]
0000707f9fbdb1be  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdb1c7  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdb1d0  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdb1d9  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdb1e2  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdb1eb  add rsp, 0xF0
0000707f9fbdb1f2  pop r11
0000707f9fbdb1f4  pop r10
0000707f9fbdb1f6  pop r9
0000707f9fbdb1f8  pop r8
0000707f9fbdb1fa  pop rsi
0000707f9fbdb1fb  pop rdi
0000707f9fbdb1fc  pop rdx
0000707f9fbdb1fd  pop rcx
0000707f9fbdb1fe  pop rax
0000707f9fbdb1ff  add rsp, 0x08
0000707f9fbdb203  jmp 0x0000707F9FBDA0B3
0000707f9fbdb208  sub rsp, 0x08
0000707f9fbdb20c  push rax
0000707f9fbdb20d  push rcx
0000707f9fbdb20e  push rdx
0000707f9fbdb20f  push rdi
0000707f9fbdb210  push rsi
0000707f9fbdb211  push r8
0000707f9fbdb213  push r9
0000707f9fbdb215  push r10
0000707f9fbdb217  push r11
0000707f9fbdb219  sub rsp, 0xF0
0000707f9fbdb220  vmovaps [rsp], xmm0
0000707f9fbdb225  vmovaps [rsp+0x10], xmm1
0000707f9fbdb22b  vmovaps [rsp+0x20], xmm2
0000707f9fbdb231  vmovaps [rsp+0x30], xmm3
0000707f9fbdb237  vmovaps [rsp+0x40], xmm4
0000707f9fbdb23d  vmovaps [rsp+0x50], xmm5
0000707f9fbdb243  vmovaps [rsp+0x60], xmm6
0000707f9fbdb249  vmovaps [rsp+0x70], xmm7
0000707f9fbdb24f  vmovaps [rsp+0x80], xmm8
0000707f9fbdb258  vmovaps [rsp+0x90], xmm10
0000707f9fbdb261  vmovaps [rsp+0xA0], xmm11
0000707f9fbdb26a  vmovaps [rsp+0xB0], xmm12
0000707f9fbdb273  vmovaps [rsp+0xC0], xmm13
0000707f9fbdb27c  vmovaps [rsp+0xD0], xmm14
0000707f9fbdb285  vmovaps [rsp+0xE0], xmm15
0000707f9fbdb28e  sub rsp, 0x40
0000707f9fbdb292  lea rdi, [rsp]
0000707f9fbdb296  lea rsi, [rsp+0x10]
0000707f9fbdb29b  lea rdx, [rsp+0x20]
0000707f9fbdb2a0  lea rcx, [rsp+0x30]
0000707f9fbdb2a5  mov r8d, 0x00
0000707f9fbdb2ab  lea r9, [r15+0x3A8]
0000707f9fbdb2b2  movaps [rdi], xmm9
0000707f9fbdb2b6  movaps [rsi], xmm13
0000707f9fbdb2ba  movaps [rdx], xmm14
0000707f9fbdb2be  movaps [rcx], xmm6
0000707f9fbdb2c1  mov rax, 0x5753922B7A50
0000707f9fbdb2cb  call rax
0000707f9fbdb2cd  movaps xmm9, [rsp]
0000707f9fbdb2d2  add rsp, 0x40
0000707f9fbdb2d6  vmovaps xmm0, [rsp]
0000707f9fbdb2db  vmovaps xmm1, [rsp+0x10]
0000707f9fbdb2e1  vmovaps xmm2, [rsp+0x20]
0000707f9fbdb2e7  vmovaps xmm3, [rsp+0x30]
0000707f9fbdb2ed  vmovaps xmm4, [rsp+0x40]
0000707f9fbdb2f3  vmovaps xmm5, [rsp+0x50]
0000707f9fbdb2f9  vmovaps xmm6, [rsp+0x60]
0000707f9fbdb2ff  vmovaps xmm7, [rsp+0x70]
0000707f9fbdb305  vmovaps xmm8, [rsp+0x80]
0000707f9fbdb30e  vmovaps xmm10, [rsp+0x90]
0000707f9fbdb317  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdb320  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdb329  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdb332  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdb33b  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdb344  add rsp, 0xF0
0000707f9fbdb34b  pop r11
0000707f9fbdb34d  pop r10
0000707f9fbdb34f  pop r9
0000707f9fbdb351  pop r8
0000707f9fbdb353  pop rsi
0000707f9fbdb354  pop rdi
0000707f9fbdb355  pop rdx
0000707f9fbdb356  pop rcx
0000707f9fbdb357  pop rax
0000707f9fbdb358  add rsp, 0x08
0000707f9fbdb35c  jmp 0x0000707F9FBDA15D
0000707f9fbdb361  sub rsp, 0x08
0000707f9fbdb365  push rax
0000707f9fbdb366  push rcx
0000707f9fbdb367  push rdx
0000707f9fbdb368  push rdi
0000707f9fbdb369  push rsi
0000707f9fbdb36a  push r8
0000707f9fbdb36c  push r9
0000707f9fbdb36e  push r10
0000707f9fbdb370  push r11
0000707f9fbdb372  sub rsp, 0xF0
0000707f9fbdb379  vmovaps [rsp], xmm0
0000707f9fbdb37e  vmovaps [rsp+0x10], xmm1
0000707f9fbdb384  vmovaps [rsp+0x20], xmm2
0000707f9fbdb38a  vmovaps [rsp+0x30], xmm4
0000707f9fbdb390  vmovaps [rsp+0x40], xmm5
0000707f9fbdb396  vmovaps [rsp+0x50], xmm6
0000707f9fbdb39c  vmovaps [rsp+0x60], xmm7
0000707f9fbdb3a2  vmovaps [rsp+0x70], xmm8
0000707f9fbdb3a8  vmovaps [rsp+0x80], xmm9
0000707f9fbdb3b1  vmovaps [rsp+0x90], xmm10
0000707f9fbdb3ba  vmovaps [rsp+0xA0], xmm11
0000707f9fbdb3c3  vmovaps [rsp+0xB0], xmm12
0000707f9fbdb3cc  vmovaps [rsp+0xC0], xmm13
0000707f9fbdb3d5  vmovaps [rsp+0xD0], xmm14
0000707f9fbdb3de  vmovaps [rsp+0xE0], xmm15
0000707f9fbdb3e7  sub rsp, 0x40
0000707f9fbdb3eb  lea rdi, [rsp]
0000707f9fbdb3ef  lea rsi, [rsp+0x10]
0000707f9fbdb3f4  lea rdx, [rsp+0x20]
0000707f9fbdb3f9  lea rcx, [rsp+0x30]
0000707f9fbdb3fe  mov r8d, 0x00
0000707f9fbdb404  lea r9, [r15+0x3A8]
0000707f9fbdb40b  movaps [rdi], xmm3
0000707f9fbdb40e  movaps [rsi], xmm13
0000707f9fbdb412  movaps [rdx], xmm6
0000707f9fbdb415  movaps [rcx], xmm14
0000707f9fbdb419  mov rax, 0x5753922B7A50
0000707f9fbdb423  call rax
0000707f9fbdb425  movaps xmm3, [rsp]
0000707f9fbdb429  add rsp, 0x40
0000707f9fbdb42d  vmovaps xmm0, [rsp]
0000707f9fbdb432  vmovaps xmm1, [rsp+0x10]
0000707f9fbdb438  vmovaps xmm2, [rsp+0x20]
0000707f9fbdb43e  vmovaps xmm4, [rsp+0x30]
0000707f9fbdb444  vmovaps xmm5, [rsp+0x40]
0000707f9fbdb44a  vmovaps xmm6, [rsp+0x50]
0000707f9fbdb450  vmovaps xmm7, [rsp+0x60]
0000707f9fbdb456  vmovaps xmm8, [rsp+0x70]
0000707f9fbdb45c  vmovaps xmm9, [rsp+0x80]
0000707f9fbdb465  vmovaps xmm10, [rsp+0x90]
0000707f9fbdb46e  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdb477  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdb480  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdb489  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdb492  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdb49b  add rsp, 0xF0
0000707f9fbdb4a2  pop r11
0000707f9fbdb4a4  pop r10
0000707f9fbdb4a6  pop r9
0000707f9fbdb4a8  pop r8
0000707f9fbdb4aa  pop rsi
0000707f9fbdb4ab  pop rdi
0000707f9fbdb4ac  pop rdx
0000707f9fbdb4ad  pop rcx
0000707f9fbdb4ae  pop rax
0000707f9fbdb4af  add rsp, 0x08
0000707f9fbdb4b3  jmp 0x0000707F9FBDA19A
0000707f9fbdb4b8  sub rsp, 0x08
0000707f9fbdb4bc  push rax
0000707f9fbdb4bd  push rcx
0000707f9fbdb4be  push rdx
0000707f9fbdb4bf  push rdi
0000707f9fbdb4c0  push rsi
0000707f9fbdb4c1  push r8
0000707f9fbdb4c3  push r9
0000707f9fbdb4c5  push r10
0000707f9fbdb4c7  push r11
0000707f9fbdb4c9  sub rsp, 0xF0
0000707f9fbdb4d0  vmovaps [rsp], xmm0
0000707f9fbdb4d5  vmovaps [rsp+0x10], xmm1
0000707f9fbdb4db  vmovaps [rsp+0x20], xmm2
0000707f9fbdb4e1  vmovaps [rsp+0x30], xmm3
0000707f9fbdb4e7  vmovaps [rsp+0x40], xmm4
0000707f9fbdb4ed  vmovaps [rsp+0x50], xmm5
0000707f9fbdb4f3  vmovaps [rsp+0x60], xmm7
0000707f9fbdb4f9  vmovaps [rsp+0x70], xmm8
0000707f9fbdb4ff  vmovaps [rsp+0x80], xmm9
0000707f9fbdb508  vmovaps [rsp+0x90], xmm10
0000707f9fbdb511  vmovaps [rsp+0xA0], xmm11
0000707f9fbdb51a  vmovaps [rsp+0xB0], xmm12
0000707f9fbdb523  vmovaps [rsp+0xC0], xmm13
0000707f9fbdb52c  vmovaps [rsp+0xD0], xmm14
0000707f9fbdb535  vmovaps [rsp+0xE0], xmm15
0000707f9fbdb53e  sub rsp, 0x40
0000707f9fbdb542  lea rdi, [rsp]
0000707f9fbdb546  lea rsi, [rsp+0x10]
0000707f9fbdb54b  lea rdx, [rsp+0x20]
0000707f9fbdb550  lea rcx, [rsp+0x30]
0000707f9fbdb555  mov r8d, 0x00
0000707f9fbdb55b  lea r9, [r15+0x3A8]
0000707f9fbdb562  movaps [rdi], xmm6
0000707f9fbdb565  movaps [rsi], xmm2
0000707f9fbdb568  movaps [rdx], xmm14
0000707f9fbdb56c  movaps [rcx], xmm1
0000707f9fbdb56f  mov rax, 0x5753922B7A50
0000707f9fbdb579  call rax
0000707f9fbdb57b  movaps xmm6, [rsp]
0000707f9fbdb57f  add rsp, 0x40
0000707f9fbdb583  vmovaps xmm0, [rsp]
0000707f9fbdb588  vmovaps xmm1, [rsp+0x10]
0000707f9fbdb58e  vmovaps xmm2, [rsp+0x20]
0000707f9fbdb594  vmovaps xmm3, [rsp+0x30]
0000707f9fbdb59a  vmovaps xmm4, [rsp+0x40]
0000707f9fbdb5a0  vmovaps xmm5, [rsp+0x50]
0000707f9fbdb5a6  vmovaps xmm7, [rsp+0x60]
0000707f9fbdb5ac  vmovaps xmm8, [rsp+0x70]
0000707f9fbdb5b2  vmovaps xmm9, [rsp+0x80]
0000707f9fbdb5bb  vmovaps xmm10, [rsp+0x90]
0000707f9fbdb5c4  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdb5cd  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdb5d6  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdb5df  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdb5e8  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdb5f1  add rsp, 0xF0
0000707f9fbdb5f8  pop r11
0000707f9fbdb5fa  pop r10
0000707f9fbdb5fc  pop r9
0000707f9fbdb5fe  pop r8
0000707f9fbdb600  pop rsi
0000707f9fbdb601  pop rdi
0000707f9fbdb602  pop rdx
0000707f9fbdb603  pop rcx
0000707f9fbdb604  pop rax
0000707f9fbdb605  add rsp, 0x08
0000707f9fbdb609  jmp 0x0000707F9FBDA1C7
0000707f9fbdb60e  sub rsp, 0x08
0000707f9fbdb612  push rax
0000707f9fbdb613  push rcx
0000707f9fbdb614  push rdx
0000707f9fbdb615  push rdi
0000707f9fbdb616  push rsi
0000707f9fbdb617  push r8
0000707f9fbdb619  push r9
0000707f9fbdb61b  push r10
0000707f9fbdb61d  push r11
0000707f9fbdb61f  sub rsp, 0xF0
0000707f9fbdb626  vmovaps [rsp], xmm0
0000707f9fbdb62b  vmovaps [rsp+0x10], xmm1
0000707f9fbdb631  vmovaps [rsp+0x20], xmm2
0000707f9fbdb637  vmovaps [rsp+0x30], xmm3
0000707f9fbdb63d  vmovaps [rsp+0x40], xmm4
0000707f9fbdb643  vmovaps [rsp+0x50], xmm5
0000707f9fbdb649  vmovaps [rsp+0x60], xmm6
0000707f9fbdb64f  vmovaps [rsp+0x70], xmm7
0000707f9fbdb655  vmovaps [rsp+0x80], xmm8
0000707f9fbdb65e  vmovaps [rsp+0x90], xmm9
0000707f9fbdb667  vmovaps [rsp+0xA0], xmm10
0000707f9fbdb670  vmovaps [rsp+0xB0], xmm11
0000707f9fbdb679  vmovaps [rsp+0xC0], xmm12
0000707f9fbdb682  vmovaps [rsp+0xD0], xmm14
0000707f9fbdb68b  vmovaps [rsp+0xE0], xmm15
0000707f9fbdb694  sub rsp, 0x40
0000707f9fbdb698  lea rdi, [rsp]
0000707f9fbdb69c  lea rsi, [rsp+0x10]
0000707f9fbdb6a1  lea rdx, [rsp+0x20]
0000707f9fbdb6a6  lea rcx, [rsp+0x30]
0000707f9fbdb6ab  mov r8d, 0x00
0000707f9fbdb6b1  lea r9, [r15+0x3A8]
0000707f9fbdb6b8  movaps [rdi], xmm13
0000707f9fbdb6bc  movaps [rsi], xmm12
0000707f9fbdb6c0  movaps [rdx], xmm14
0000707f9fbdb6c4  movaps [rcx], xmm1
0000707f9fbdb6c7  mov rax, 0x5753922B7A50
0000707f9fbdb6d1  call rax
0000707f9fbdb6d3  movaps xmm13, [rsp]
0000707f9fbdb6d8  add rsp, 0x40
0000707f9fbdb6dc  vmovaps xmm0, [rsp]
0000707f9fbdb6e1  vmovaps xmm1, [rsp+0x10]
0000707f9fbdb6e7  vmovaps xmm2, [rsp+0x20]
0000707f9fbdb6ed  vmovaps xmm3, [rsp+0x30]
0000707f9fbdb6f3  vmovaps xmm4, [rsp+0x40]
0000707f9fbdb6f9  vmovaps xmm5, [rsp+0x50]
0000707f9fbdb6ff  vmovaps xmm6, [rsp+0x60]
0000707f9fbdb705  vmovaps xmm7, [rsp+0x70]
0000707f9fbdb70b  vmovaps xmm8, [rsp+0x80]
0000707f9fbdb714  vmovaps xmm9, [rsp+0x90]
0000707f9fbdb71d  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdb726  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdb72f  vmovaps xmm12, [rsp+0xC0]
0000707f9fbdb738  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdb741  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdb74a  add rsp, 0xF0
0000707f9fbdb751  pop r11
0000707f9fbdb753  pop r10
0000707f9fbdb755  pop r9
0000707f9fbdb757  pop r8
0000707f9fbdb759  pop rsi
0000707f9fbdb75a  pop rdi
0000707f9fbdb75b  pop rdx
0000707f9fbdb75c  pop rcx
0000707f9fbdb75d  pop rax
0000707f9fbdb75e  add rsp, 0x08
0000707f9fbdb762  jmp 0x0000707F9FBDA1F9
0000707f9fbdb767  sub rsp, 0x08
0000707f9fbdb76b  push rax
0000707f9fbdb76c  push rcx
0000707f9fbdb76d  push rdx
0000707f9fbdb76e  push rdi
0000707f9fbdb76f  push rsi
0000707f9fbdb770  push r8
0000707f9fbdb772  push r9
0000707f9fbdb774  push r10
0000707f9fbdb776  push r11
0000707f9fbdb778  sub rsp, 0xF0
0000707f9fbdb77f  vmovaps [rsp], xmm0
0000707f9fbdb784  vmovaps [rsp+0x10], xmm1
0000707f9fbdb78a  vmovaps [rsp+0x20], xmm2
0000707f9fbdb790  vmovaps [rsp+0x30], xmm3
0000707f9fbdb796  vmovaps [rsp+0x40], xmm4
0000707f9fbdb79c  vmovaps [rsp+0x50], xmm5
0000707f9fbdb7a2  vmovaps [rsp+0x60], xmm6
0000707f9fbdb7a8  vmovaps [rsp+0x70], xmm7
0000707f9fbdb7ae  vmovaps [rsp+0x80], xmm8
0000707f9fbdb7b7  vmovaps [rsp+0x90], xmm9
0000707f9fbdb7c0  vmovaps [rsp+0xA0], xmm10
0000707f9fbdb7c9  vmovaps [rsp+0xB0], xmm11
0000707f9fbdb7d2  vmovaps [rsp+0xC0], xmm13
0000707f9fbdb7db  vmovaps [rsp+0xD0], xmm14
0000707f9fbdb7e4  vmovaps [rsp+0xE0], xmm15
0000707f9fbdb7ed  sub rsp, 0x40
0000707f9fbdb7f1  lea rdi, [rsp]
0000707f9fbdb7f5  lea rsi, [rsp+0x10]
0000707f9fbdb7fa  lea rdx, [rsp+0x20]
0000707f9fbdb7ff  lea rcx, [rsp+0x30]
0000707f9fbdb804  mov r8d, 0x00
0000707f9fbdb80a  lea r9, [r15+0x3A8]
0000707f9fbdb811  movaps [rdi], xmm12
0000707f9fbdb815  movaps [rsi], xmm3
0000707f9fbdb818  movaps [rdx], xmm14
0000707f9fbdb81c  movaps [rcx], xmm5
0000707f9fbdb81f  mov rax, 0x5753922B7A50
0000707f9fbdb829  call rax
0000707f9fbdb82b  movaps xmm12, [rsp]
0000707f9fbdb830  add rsp, 0x40
0000707f9fbdb834  vmovaps xmm0, [rsp]
0000707f9fbdb839  vmovaps xmm1, [rsp+0x10]
0000707f9fbdb83f  vmovaps xmm2, [rsp+0x20]
0000707f9fbdb845  vmovaps xmm3, [rsp+0x30]
0000707f9fbdb84b  vmovaps xmm4, [rsp+0x40]
0000707f9fbdb851  vmovaps xmm5, [rsp+0x50]
0000707f9fbdb857  vmovaps xmm6, [rsp+0x60]
0000707f9fbdb85d  vmovaps xmm7, [rsp+0x70]
0000707f9fbdb863  vmovaps xmm8, [rsp+0x80]
0000707f9fbdb86c  vmovaps xmm9, [rsp+0x90]
0000707f9fbdb875  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdb87e  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdb887  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdb890  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdb899  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdb8a2  add rsp, 0xF0
0000707f9fbdb8a9  pop r11
0000707f9fbdb8ab  pop r10
0000707f9fbdb8ad  pop r9
0000707f9fbdb8af  pop r8
0000707f9fbdb8b1  pop rsi
0000707f9fbdb8b2  pop rdi
0000707f9fbdb8b3  pop rdx
0000707f9fbdb8b4  pop rcx
0000707f9fbdb8b5  pop rax
0000707f9fbdb8b6  add rsp, 0x08
0000707f9fbdb8ba  jmp 0x0000707F9FBDA256
0000707f9fbdb8bf  sub rsp, 0x08
0000707f9fbdb8c3  push rax
0000707f9fbdb8c4  push rcx
0000707f9fbdb8c5  push rdx
0000707f9fbdb8c6  push rdi
0000707f9fbdb8c7  push rsi
0000707f9fbdb8c8  push r8
0000707f9fbdb8ca  push r9
0000707f9fbdb8cc  push r10
0000707f9fbdb8ce  push r11
0000707f9fbdb8d0  sub rsp, 0xF0
0000707f9fbdb8d7  vmovaps [rsp], xmm0
0000707f9fbdb8dc  vmovaps [rsp+0x10], xmm1
0000707f9fbdb8e2  vmovaps [rsp+0x20], xmm2
0000707f9fbdb8e8  vmovaps [rsp+0x30], xmm3
0000707f9fbdb8ee  vmovaps [rsp+0x40], xmm4
0000707f9fbdb8f4  vmovaps [rsp+0x50], xmm5
0000707f9fbdb8fa  vmovaps [rsp+0x60], xmm6
0000707f9fbdb900  vmovaps [rsp+0x70], xmm7
0000707f9fbdb906  vmovaps [rsp+0x80], xmm8
0000707f9fbdb90f  vmovaps [rsp+0x90], xmm9
0000707f9fbdb918  vmovaps [rsp+0xA0], xmm11
0000707f9fbdb921  vmovaps [rsp+0xB0], xmm12
0000707f9fbdb92a  vmovaps [rsp+0xC0], xmm13
0000707f9fbdb933  vmovaps [rsp+0xD0], xmm14
0000707f9fbdb93c  vmovaps [rsp+0xE0], xmm15
0000707f9fbdb945  sub rsp, 0x40
0000707f9fbdb949  lea rdi, [rsp]
0000707f9fbdb94d  lea rsi, [rsp+0x10]
0000707f9fbdb952  lea rdx, [rsp+0x20]
0000707f9fbdb957  lea rcx, [rsp+0x30]
0000707f9fbdb95c  mov r8d, 0x00
0000707f9fbdb962  lea r9, [r15+0x3A8]
0000707f9fbdb969  movaps [rdi], xmm10
0000707f9fbdb96d  movaps [rsi], xmm9
0000707f9fbdb971  movaps [rdx], xmm7
0000707f9fbdb974  movaps [rcx], xmm14
0000707f9fbdb978  mov rax, 0x5753922B7A50
0000707f9fbdb982  call rax
0000707f9fbdb984  movaps xmm10, [rsp]
0000707f9fbdb989  add rsp, 0x40
0000707f9fbdb98d  vmovaps xmm0, [rsp]
0000707f9fbdb992  vmovaps xmm1, [rsp+0x10]
0000707f9fbdb998  vmovaps xmm2, [rsp+0x20]
0000707f9fbdb99e  vmovaps xmm3, [rsp+0x30]
0000707f9fbdb9a4  vmovaps xmm4, [rsp+0x40]
0000707f9fbdb9aa  vmovaps xmm5, [rsp+0x50]
0000707f9fbdb9b0  vmovaps xmm6, [rsp+0x60]
0000707f9fbdb9b6  vmovaps xmm7, [rsp+0x70]
0000707f9fbdb9bc  vmovaps xmm8, [rsp+0x80]
0000707f9fbdb9c5  vmovaps xmm9, [rsp+0x90]
0000707f9fbdb9ce  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdb9d7  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdb9e0  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdb9e9  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdb9f2  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdb9fb  add rsp, 0xF0
0000707f9fbdba02  pop r11
0000707f9fbdba04  pop r10
0000707f9fbdba06  pop r9
0000707f9fbdba08  pop r8
0000707f9fbdba0a  pop rsi
0000707f9fbdba0b  pop rdi
0000707f9fbdba0c  pop rdx
0000707f9fbdba0d  pop rcx
0000707f9fbdba0e  pop rax
0000707f9fbdba0f  add rsp, 0x08
0000707f9fbdba13  jmp 0x0000707F9FBDA27C
0000707f9fbdba18  call 0x0000707F9FA0D4E0
0000707f9fbdba1d  jmp 0x0000707F9FBDA289
0000707f9fbdba22  sub rsp, 0x08
0000707f9fbdba26  push rax
0000707f9fbdba27  push rcx
0000707f9fbdba28  push rdx
0000707f9fbdba29  push rdi
0000707f9fbdba2a  push rsi
0000707f9fbdba2b  push r8
0000707f9fbdba2d  push r9
0000707f9fbdba2f  push r10
0000707f9fbdba31  push r11
0000707f9fbdba33  sub rsp, 0xF0
0000707f9fbdba3a  vmovaps [rsp], xmm0
0000707f9fbdba3f  vmovaps [rsp+0x10], xmm1
0000707f9fbdba45  vmovaps [rsp+0x20], xmm2
0000707f9fbdba4b  vmovaps [rsp+0x30], xmm3
0000707f9fbdba51  vmovaps [rsp+0x40], xmm4
0000707f9fbdba57  vmovaps [rsp+0x50], xmm6
0000707f9fbdba5d  vmovaps [rsp+0x60], xmm7
0000707f9fbdba63  vmovaps [rsp+0x70], xmm8
0000707f9fbdba69  vmovaps [rsp+0x80], xmm9
0000707f9fbdba72  vmovaps [rsp+0x90], xmm10
0000707f9fbdba7b  vmovaps [rsp+0xA0], xmm11
0000707f9fbdba84  vmovaps [rsp+0xB0], xmm12
0000707f9fbdba8d  vmovaps [rsp+0xC0], xmm13
0000707f9fbdba96  vmovaps [rsp+0xD0], xmm14
0000707f9fbdba9f  vmovaps [rsp+0xE0], xmm15
0000707f9fbdbaa8  sub rsp, 0x40
0000707f9fbdbaac  lea rdi, [rsp]
0000707f9fbdbab0  lea rsi, [rsp+0x10]
0000707f9fbdbab5  lea rdx, [rsp+0x20]
0000707f9fbdbaba  lea rcx, [rsp+0x30]
0000707f9fbdbabf  mov r8d, 0x00
0000707f9fbdbac5  lea r9, [r15+0x3A8]
0000707f9fbdbacc  movaps [rdi], xmm5
0000707f9fbdbacf  movaps [rsi], xmm6
0000707f9fbdbad2  movaps [rdx], xmm7
0000707f9fbdbad5  movaps [rcx], xmm9
0000707f9fbdbad9  mov rax, 0x5753922B7A50
0000707f9fbdbae3  call rax
0000707f9fbdbae5  movaps xmm5, [rsp]
0000707f9fbdbae9  add rsp, 0x40
0000707f9fbdbaed  vmovaps xmm0, [rsp]
0000707f9fbdbaf2  vmovaps xmm1, [rsp+0x10]
0000707f9fbdbaf8  vmovaps xmm2, [rsp+0x20]
0000707f9fbdbafe  vmovaps xmm3, [rsp+0x30]
0000707f9fbdbb04  vmovaps xmm4, [rsp+0x40]
0000707f9fbdbb0a  vmovaps xmm6, [rsp+0x50]
0000707f9fbdbb10  vmovaps xmm7, [rsp+0x60]
0000707f9fbdbb16  vmovaps xmm8, [rsp+0x70]
0000707f9fbdbb1c  vmovaps xmm9, [rsp+0x80]
0000707f9fbdbb25  vmovaps xmm10, [rsp+0x90]
0000707f9fbdbb2e  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdbb37  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdbb40  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdbb49  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdbb52  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdbb5b  add rsp, 0xF0
0000707f9fbdbb62  pop r11
0000707f9fbdbb64  pop r10
0000707f9fbdbb66  pop r9
0000707f9fbdbb68  pop r8
0000707f9fbdbb6a  pop rsi
0000707f9fbdbb6b  pop rdi
0000707f9fbdbb6c  pop rdx
0000707f9fbdbb6d  pop rcx
0000707f9fbdbb6e  pop rax
0000707f9fbdbb6f  add rsp, 0x08
0000707f9fbdbb73  jmp 0x0000707F9FBDA2BB
0000707f9fbdbb78  sub rsp, 0x08
0000707f9fbdbb7c  push rax
0000707f9fbdbb7d  push rcx
0000707f9fbdbb7e  push rdx
0000707f9fbdbb7f  push rdi
0000707f9fbdbb80  push rsi
0000707f9fbdbb81  push r8
0000707f9fbdbb83  push r9
0000707f9fbdbb85  push r10
0000707f9fbdbb87  push r11
0000707f9fbdbb89  sub rsp, 0xF0
0000707f9fbdbb90  vmovaps [rsp], xmm0
0000707f9fbdbb95  vmovaps [rsp+0x10], xmm1
0000707f9fbdbb9b  vmovaps [rsp+0x20], xmm2
0000707f9fbdbba1  vmovaps [rsp+0x30], xmm3
0000707f9fbdbba7  vmovaps [rsp+0x40], xmm4
0000707f9fbdbbad  vmovaps [rsp+0x50], xmm5
0000707f9fbdbbb3  vmovaps [rsp+0x60], xmm6
0000707f9fbdbbb9  vmovaps [rsp+0x70], xmm8
0000707f9fbdbbbf  vmovaps [rsp+0x80], xmm9
0000707f9fbdbbc8  vmovaps [rsp+0x90], xmm10
0000707f9fbdbbd1  vmovaps [rsp+0xA0], xmm11
0000707f9fbdbbda  vmovaps [rsp+0xB0], xmm12
0000707f9fbdbbe3  vmovaps [rsp+0xC0], xmm13
0000707f9fbdbbec  vmovaps [rsp+0xD0], xmm14
0000707f9fbdbbf5  vmovaps [rsp+0xE0], xmm15
0000707f9fbdbbfe  sub rsp, 0x40
0000707f9fbdbc02  lea rdi, [rsp]
0000707f9fbdbc06  lea rsi, [rsp+0x10]
0000707f9fbdbc0b  lea rdx, [rsp+0x20]
0000707f9fbdbc10  lea rcx, [rsp+0x30]
0000707f9fbdbc15  mov r8d, 0x00
0000707f9fbdbc1b  lea r9, [r15+0x3A8]
0000707f9fbdbc22  movaps [rdi], xmm7
0000707f9fbdbc25  movaps [rsi], xmm13
0000707f9fbdbc29  movaps [rdx], xmm1
0000707f9fbdbc2c  movaps [rcx], xmm9
0000707f9fbdbc30  mov rax, 0x5753922B7A50
0000707f9fbdbc3a  call rax
0000707f9fbdbc3c  movaps xmm7, [rsp]
0000707f9fbdbc40  add rsp, 0x40
0000707f9fbdbc44  vmovaps xmm0, [rsp]
0000707f9fbdbc49  vmovaps xmm1, [rsp+0x10]
0000707f9fbdbc4f  vmovaps xmm2, [rsp+0x20]
0000707f9fbdbc55  vmovaps xmm3, [rsp+0x30]
0000707f9fbdbc5b  vmovaps xmm4, [rsp+0x40]
0000707f9fbdbc61  vmovaps xmm5, [rsp+0x50]
0000707f9fbdbc67  vmovaps xmm6, [rsp+0x60]
0000707f9fbdbc6d  vmovaps xmm8, [rsp+0x70]
0000707f9fbdbc73  vmovaps xmm9, [rsp+0x80]
0000707f9fbdbc7c  vmovaps xmm10, [rsp+0x90]
0000707f9fbdbc85  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdbc8e  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdbc97  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdbca0  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdbca9  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdbcb2  add rsp, 0xF0
0000707f9fbdbcb9  pop r11
0000707f9fbdbcbb  pop r10
0000707f9fbdbcbd  pop r9
0000707f9fbdbcbf  pop r8
0000707f9fbdbcc1  pop rsi
0000707f9fbdbcc2  pop rdi
0000707f9fbdbcc3  pop rdx
0000707f9fbdbcc4  pop rcx
0000707f9fbdbcc5  pop rax
0000707f9fbdbcc6  add rsp, 0x08
0000707f9fbdbcca  jmp 0x0000707F9FBDA2E0
0000707f9fbdbccf  call 0x0000707F9FA0C260
0000707f9fbdbcd4  jmp 0x0000707F9FBDA303
0000707f9fbdbcd9  call 0x0000707F9FA07890
0000707f9fbdbcde  jmp 0x0000707F9FBDA30D
0000707f9fbdbce3  sub rsp, 0x08
0000707f9fbdbce7  push rax
0000707f9fbdbce8  push rcx
0000707f9fbdbce9  push rdx
0000707f9fbdbcea  push rdi
0000707f9fbdbceb  push rsi
0000707f9fbdbcec  push r8
0000707f9fbdbcee  push r9
0000707f9fbdbcf0  push r10
0000707f9fbdbcf2  push r11
0000707f9fbdbcf4  sub rsp, 0xF0
0000707f9fbdbcfb  vmovaps [rsp], xmm0
0000707f9fbdbd00  vmovaps [rsp+0x10], xmm1
0000707f9fbdbd06  vmovaps [rsp+0x20], xmm3
0000707f9fbdbd0c  vmovaps [rsp+0x30], xmm4
0000707f9fbdbd12  vmovaps [rsp+0x40], xmm5
0000707f9fbdbd18  vmovaps [rsp+0x50], xmm6
0000707f9fbdbd1e  vmovaps [rsp+0x60], xmm7
0000707f9fbdbd24  vmovaps [rsp+0x70], xmm8
0000707f9fbdbd2a  vmovaps [rsp+0x80], xmm9
0000707f9fbdbd33  vmovaps [rsp+0x90], xmm10
0000707f9fbdbd3c  vmovaps [rsp+0xA0], xmm11
0000707f9fbdbd45  vmovaps [rsp+0xB0], xmm12
0000707f9fbdbd4e  vmovaps [rsp+0xC0], xmm13
0000707f9fbdbd57  vmovaps [rsp+0xD0], xmm14
0000707f9fbdbd60  vmovaps [rsp+0xE0], xmm15
0000707f9fbdbd69  sub rsp, 0x40
0000707f9fbdbd6d  lea rdi, [rsp]
0000707f9fbdbd71  lea rsi, [rsp+0x10]
0000707f9fbdbd76  lea rdx, [rsp+0x20]
0000707f9fbdbd7b  lea rcx, [rsp+0x30]
0000707f9fbdbd80  mov r8d, 0x00
0000707f9fbdbd86  lea r9, [r15+0x3A8]
0000707f9fbdbd8d  movaps [rdi], xmm2
0000707f9fbdbd90  movaps [rsi], xmm12
0000707f9fbdbd94  movaps [rdx], xmm6
0000707f9fbdbd97  movaps [rcx], xmm3
0000707f9fbdbd9a  mov rax, 0x5753922B7A50
0000707f9fbdbda4  call rax
0000707f9fbdbda6  movaps xmm2, [rsp]
0000707f9fbdbdaa  add rsp, 0x40
0000707f9fbdbdae  vmovaps xmm0, [rsp]
0000707f9fbdbdb3  vmovaps xmm1, [rsp+0x10]
0000707f9fbdbdb9  vmovaps xmm3, [rsp+0x20]
0000707f9fbdbdbf  vmovaps xmm4, [rsp+0x30]
0000707f9fbdbdc5  vmovaps xmm5, [rsp+0x40]
0000707f9fbdbdcb  vmovaps xmm6, [rsp+0x50]
0000707f9fbdbdd1  vmovaps xmm7, [rsp+0x60]
0000707f9fbdbdd7  vmovaps xmm8, [rsp+0x70]
0000707f9fbdbddd  vmovaps xmm9, [rsp+0x80]
0000707f9fbdbde6  vmovaps xmm10, [rsp+0x90]
0000707f9fbdbdef  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdbdf8  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdbe01  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdbe0a  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdbe13  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdbe1c  add rsp, 0xF0
0000707f9fbdbe23  pop r11
0000707f9fbdbe25  pop r10
0000707f9fbdbe27  pop r9
0000707f9fbdbe29  pop r8
0000707f9fbdbe2b  pop rsi
0000707f9fbdbe2c  pop rdi
0000707f9fbdbe2d  pop rdx
0000707f9fbdbe2e  pop rcx
0000707f9fbdbe2f  pop rax
0000707f9fbdbe30  add rsp, 0x08
0000707f9fbdbe34  jmp 0x0000707F9FBDA353
0000707f9fbdbe39  sub rsp, 0x08
0000707f9fbdbe3d  push rax
0000707f9fbdbe3e  push rcx
0000707f9fbdbe3f  push rdx
0000707f9fbdbe40  push rdi
0000707f9fbdbe41  push rsi
0000707f9fbdbe42  push r8
0000707f9fbdbe44  push r9
0000707f9fbdbe46  push r10
0000707f9fbdbe48  push r11
0000707f9fbdbe4a  sub rsp, 0xF0
0000707f9fbdbe51  vmovaps [rsp], xmm0
0000707f9fbdbe56  vmovaps [rsp+0x10], xmm1
0000707f9fbdbe5c  vmovaps [rsp+0x20], xmm2
0000707f9fbdbe62  vmovaps [rsp+0x30], xmm3
0000707f9fbdbe68  vmovaps [rsp+0x40], xmm4
0000707f9fbdbe6e  vmovaps [rsp+0x50], xmm5
0000707f9fbdbe74  vmovaps [rsp+0x60], xmm7
0000707f9fbdbe7a  vmovaps [rsp+0x70], xmm8
0000707f9fbdbe80  vmovaps [rsp+0x80], xmm9
0000707f9fbdbe89  vmovaps [rsp+0x90], xmm10
0000707f9fbdbe92  vmovaps [rsp+0xA0], xmm11
0000707f9fbdbe9b  vmovaps [rsp+0xB0], xmm12
0000707f9fbdbea4  vmovaps [rsp+0xC0], xmm13
0000707f9fbdbead  vmovaps [rsp+0xD0], xmm14
0000707f9fbdbeb6  vmovaps [rsp+0xE0], xmm15
0000707f9fbdbebf  sub rsp, 0x40
0000707f9fbdbec3  lea rdi, [rsp]
0000707f9fbdbec7  lea rsi, [rsp+0x10]
0000707f9fbdbecc  lea rdx, [rsp+0x20]
0000707f9fbdbed1  lea rcx, [rsp+0x30]
0000707f9fbdbed6  mov r8d, 0x00
0000707f9fbdbedc  lea r9, [r15+0x3A8]
0000707f9fbdbee3  movaps [rdi], xmm6
0000707f9fbdbee6  movaps [rsi], xmm10
0000707f9fbdbeea  movaps [rdx], xmm12
0000707f9fbdbeee  movaps [rcx], xmm1
0000707f9fbdbef1  mov rax, 0x5753922B7A50
0000707f9fbdbefb  call rax
0000707f9fbdbefd  movaps xmm6, [rsp]
0000707f9fbdbf01  add rsp, 0x40
0000707f9fbdbf05  vmovaps xmm0, [rsp]
0000707f9fbdbf0a  vmovaps xmm1, [rsp+0x10]
0000707f9fbdbf10  vmovaps xmm2, [rsp+0x20]
0000707f9fbdbf16  vmovaps xmm3, [rsp+0x30]
0000707f9fbdbf1c  vmovaps xmm4, [rsp+0x40]
0000707f9fbdbf22  vmovaps xmm5, [rsp+0x50]
0000707f9fbdbf28  vmovaps xmm7, [rsp+0x60]
0000707f9fbdbf2e  vmovaps xmm8, [rsp+0x70]
0000707f9fbdbf34  vmovaps xmm9, [rsp+0x80]
0000707f9fbdbf3d  vmovaps xmm10, [rsp+0x90]
0000707f9fbdbf46  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdbf4f  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdbf58  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdbf61  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdbf6a  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdbf73  add rsp, 0xF0
0000707f9fbdbf7a  pop r11
0000707f9fbdbf7c  pop r10
0000707f9fbdbf7e  pop r9
0000707f9fbdbf80  pop r8
0000707f9fbdbf82  pop rsi
0000707f9fbdbf83  pop rdi
0000707f9fbdbf84  pop rdx
0000707f9fbdbf85  pop rcx
0000707f9fbdbf86  pop rax
0000707f9fbdbf87  add rsp, 0x08
0000707f9fbdbf8b  jmp 0x0000707F9FBDA381
0000707f9fbdbf90  sub rsp, 0x08
0000707f9fbdbf94  push rax
0000707f9fbdbf95  push rcx
0000707f9fbdbf96  push rdx
0000707f9fbdbf97  push rdi
0000707f9fbdbf98  push rsi
0000707f9fbdbf99  push r8
0000707f9fbdbf9b  push r9
0000707f9fbdbf9d  push r10
0000707f9fbdbf9f  push r11
0000707f9fbdbfa1  sub rsp, 0xF0
0000707f9fbdbfa8  vmovaps [rsp], xmm0
0000707f9fbdbfad  vmovaps [rsp+0x10], xmm1
0000707f9fbdbfb3  vmovaps [rsp+0x20], xmm2
0000707f9fbdbfb9  vmovaps [rsp+0x30], xmm3
0000707f9fbdbfbf  vmovaps [rsp+0x40], xmm4
0000707f9fbdbfc5  vmovaps [rsp+0x50], xmm5
0000707f9fbdbfcb  vmovaps [rsp+0x60], xmm6
0000707f9fbdbfd1  vmovaps [rsp+0x70], xmm7
0000707f9fbdbfd7  vmovaps [rsp+0x80], xmm8
0000707f9fbdbfe0  vmovaps [rsp+0x90], xmm9
0000707f9fbdbfe9  vmovaps [rsp+0xA0], xmm11
0000707f9fbdbff2  vmovaps [rsp+0xB0], xmm12
0000707f9fbdbffb  vmovaps [rsp+0xC0], xmm13
0000707f9fbdc004  vmovaps [rsp+0xD0], xmm14
0000707f9fbdc00d  vmovaps [rsp+0xE0], xmm15
0000707f9fbdc016  sub rsp, 0x40
0000707f9fbdc01a  lea rdi, [rsp]
0000707f9fbdc01e  lea rsi, [rsp+0x10]
0000707f9fbdc023  lea rdx, [rsp+0x20]
0000707f9fbdc028  lea rcx, [rsp+0x30]
0000707f9fbdc02d  mov r8d, 0x00
0000707f9fbdc033  lea r9, [r15+0x3A8]
0000707f9fbdc03a  movaps [rdi], xmm10
0000707f9fbdc03e  movaps [rsi], xmm5
0000707f9fbdc041  movaps [rdx], xmm12
0000707f9fbdc045  movaps [rcx], xmm1
0000707f9fbdc048  mov rax, 0x5753922B7A50
0000707f9fbdc052  call rax
0000707f9fbdc054  movaps xmm10, [rsp]
0000707f9fbdc059  add rsp, 0x40
0000707f9fbdc05d  vmovaps xmm0, [rsp]
0000707f9fbdc062  vmovaps xmm1, [rsp+0x10]
0000707f9fbdc068  vmovaps xmm2, [rsp+0x20]
0000707f9fbdc06e  vmovaps xmm3, [rsp+0x30]
0000707f9fbdc074  vmovaps xmm4, [rsp+0x40]
0000707f9fbdc07a  vmovaps xmm5, [rsp+0x50]
0000707f9fbdc080  vmovaps xmm6, [rsp+0x60]
0000707f9fbdc086  vmovaps xmm7, [rsp+0x70]
0000707f9fbdc08c  vmovaps xmm8, [rsp+0x80]
0000707f9fbdc095  vmovaps xmm9, [rsp+0x90]
0000707f9fbdc09e  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdc0a7  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdc0b0  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdc0b9  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdc0c2  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdc0cb  add rsp, 0xF0
0000707f9fbdc0d2  pop r11
0000707f9fbdc0d4  pop r10
0000707f9fbdc0d6  pop r9
0000707f9fbdc0d8  pop r8
0000707f9fbdc0da  pop rsi
0000707f9fbdc0db  pop rdi
0000707f9fbdc0dc  pop rdx
0000707f9fbdc0dd  pop rcx
0000707f9fbdc0de  pop rax
0000707f9fbdc0df  add rsp, 0x08
0000707f9fbdc0e3  jmp 0x0000707F9FBDA3B0
0000707f9fbdc0e8  sub rsp, 0x08
0000707f9fbdc0ec  push rax
0000707f9fbdc0ed  push rcx
0000707f9fbdc0ee  push rdx
0000707f9fbdc0ef  push rdi
0000707f9fbdc0f0  push rsi
0000707f9fbdc0f1  push r8
0000707f9fbdc0f3  push r9
0000707f9fbdc0f5  push r10
0000707f9fbdc0f7  push r11
0000707f9fbdc0f9  sub rsp, 0xF0
0000707f9fbdc100  vmovaps [rsp], xmm0
0000707f9fbdc105  vmovaps [rsp+0x10], xmm1
0000707f9fbdc10b  vmovaps [rsp+0x20], xmm2
0000707f9fbdc111  vmovaps [rsp+0x30], xmm3
0000707f9fbdc117  vmovaps [rsp+0x40], xmm4
0000707f9fbdc11d  vmovaps [rsp+0x50], xmm5
0000707f9fbdc123  vmovaps [rsp+0x60], xmm6
0000707f9fbdc129  vmovaps [rsp+0x70], xmm7
0000707f9fbdc12f  vmovaps [rsp+0x80], xmm8
0000707f9fbdc138  vmovaps [rsp+0x90], xmm9
0000707f9fbdc141  vmovaps [rsp+0xA0], xmm10
0000707f9fbdc14a  vmovaps [rsp+0xB0], xmm11
0000707f9fbdc153  vmovaps [rsp+0xC0], xmm13
0000707f9fbdc15c  vmovaps [rsp+0xD0], xmm14
0000707f9fbdc165  vmovaps [rsp+0xE0], xmm15
0000707f9fbdc16e  sub rsp, 0x40
0000707f9fbdc172  lea rdi, [rsp]
0000707f9fbdc176  lea rsi, [rsp+0x10]
0000707f9fbdc17b  lea rdx, [rsp+0x20]
0000707f9fbdc180  lea rcx, [rsp+0x30]
0000707f9fbdc185  mov r8d, 0x00
0000707f9fbdc18b  lea r9, [r15+0x3A8]
0000707f9fbdc192  movaps [rdi], xmm12
0000707f9fbdc196  movaps [rsi], xmm7
0000707f9fbdc199  movaps [rdx], xmm15
0000707f9fbdc19d  movaps [rcx], xmm1
0000707f9fbdc1a0  mov rax, 0x5753922B7A50
0000707f9fbdc1aa  call rax
0000707f9fbdc1ac  movaps xmm12, [rsp]
0000707f9fbdc1b1  add rsp, 0x40
0000707f9fbdc1b5  vmovaps xmm0, [rsp]
0000707f9fbdc1ba  vmovaps xmm1, [rsp+0x10]
0000707f9fbdc1c0  vmovaps xmm2, [rsp+0x20]
0000707f9fbdc1c6  vmovaps xmm3, [rsp+0x30]
0000707f9fbdc1cc  vmovaps xmm4, [rsp+0x40]
0000707f9fbdc1d2  vmovaps xmm5, [rsp+0x50]
0000707f9fbdc1d8  vmovaps xmm6, [rsp+0x60]
0000707f9fbdc1de  vmovaps xmm7, [rsp+0x70]
0000707f9fbdc1e4  vmovaps xmm8, [rsp+0x80]
0000707f9fbdc1ed  vmovaps xmm9, [rsp+0x90]
0000707f9fbdc1f6  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdc1ff  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdc208  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdc211  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdc21a  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdc223  add rsp, 0xF0
0000707f9fbdc22a  pop r11
0000707f9fbdc22c  pop r10
0000707f9fbdc22e  pop r9
0000707f9fbdc230  pop r8
0000707f9fbdc232  pop rsi
0000707f9fbdc233  pop rdi
0000707f9fbdc234  pop rdx
0000707f9fbdc235  pop rcx
0000707f9fbdc236  pop rax
0000707f9fbdc237  add rsp, 0x08
0000707f9fbdc23b  jmp 0x0000707F9FBDA3D9
0000707f9fbdc240  call 0x0000707F9F9FF430
0000707f9fbdc245  jmp 0x0000707F9FBDA3E3
0000707f9fbdc24a  call 0x0000707F9FA0E760
0000707f9fbdc24f  jmp 0x0000707F9FBDA3ED
0000707f9fbdc254  sub rsp, 0x08
0000707f9fbdc258  push rax
0000707f9fbdc259  push rcx
0000707f9fbdc25a  push rdx
0000707f9fbdc25b  push rdi
0000707f9fbdc25c  push rsi
0000707f9fbdc25d  push r8
0000707f9fbdc25f  push r9
0000707f9fbdc261  push r10
0000707f9fbdc263  push r11
0000707f9fbdc265  sub rsp, 0xF0
0000707f9fbdc26c  vmovaps [rsp], xmm0
0000707f9fbdc271  vmovaps [rsp+0x10], xmm1
0000707f9fbdc277  vmovaps [rsp+0x20], xmm2
0000707f9fbdc27d  vmovaps [rsp+0x30], xmm3
0000707f9fbdc283  vmovaps [rsp+0x40], xmm4
0000707f9fbdc289  vmovaps [rsp+0x50], xmm5
0000707f9fbdc28f  vmovaps [rsp+0x60], xmm6
0000707f9fbdc295  vmovaps [rsp+0x70], xmm8
0000707f9fbdc29b  vmovaps [rsp+0x80], xmm9
0000707f9fbdc2a4  vmovaps [rsp+0x90], xmm10
0000707f9fbdc2ad  vmovaps [rsp+0xA0], xmm11
0000707f9fbdc2b6  vmovaps [rsp+0xB0], xmm12
0000707f9fbdc2bf  vmovaps [rsp+0xC0], xmm13
0000707f9fbdc2c8  vmovaps [rsp+0xD0], xmm14
0000707f9fbdc2d1  vmovaps [rsp+0xE0], xmm15
0000707f9fbdc2da  sub rsp, 0x40
0000707f9fbdc2de  lea rdi, [rsp]
0000707f9fbdc2e2  lea rsi, [rsp+0x10]
0000707f9fbdc2e7  lea rdx, [rsp+0x20]
0000707f9fbdc2ec  lea rcx, [rsp+0x30]
0000707f9fbdc2f1  mov r8d, 0x00
0000707f9fbdc2f7  lea r9, [r15+0x3A8]
0000707f9fbdc2fe  movaps [rdi], xmm7
0000707f9fbdc301  movaps [rsi], xmm2
0000707f9fbdc304  movaps [rdx], xmm9
0000707f9fbdc308  movaps [rcx], xmm11
0000707f9fbdc30c  mov rax, 0x5753922B7A50
0000707f9fbdc316  call rax
0000707f9fbdc318  movaps xmm7, [rsp]
0000707f9fbdc31c  add rsp, 0x40
0000707f9fbdc320  vmovaps xmm0, [rsp]
0000707f9fbdc325  vmovaps xmm1, [rsp+0x10]
0000707f9fbdc32b  vmovaps xmm2, [rsp+0x20]
0000707f9fbdc331  vmovaps xmm3, [rsp+0x30]
0000707f9fbdc337  vmovaps xmm4, [rsp+0x40]
0000707f9fbdc33d  vmovaps xmm5, [rsp+0x50]
0000707f9fbdc343  vmovaps xmm6, [rsp+0x60]
0000707f9fbdc349  vmovaps xmm8, [rsp+0x70]
0000707f9fbdc34f  vmovaps xmm9, [rsp+0x80]
0000707f9fbdc358  vmovaps xmm10, [rsp+0x90]
0000707f9fbdc361  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdc36a  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdc373  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdc37c  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdc385  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdc38e  add rsp, 0xF0
0000707f9fbdc395  pop r11
0000707f9fbdc397  pop r10
0000707f9fbdc399  pop r9
0000707f9fbdc39b  pop r8
0000707f9fbdc39d  pop rsi
0000707f9fbdc39e  pop rdi
0000707f9fbdc39f  pop rdx
0000707f9fbdc3a0  pop rcx
0000707f9fbdc3a1  pop rax
0000707f9fbdc3a2  add rsp, 0x08
0000707f9fbdc3a6  jmp 0x0000707F9FBDA421
0000707f9fbdc3ab  sub rsp, 0x08
0000707f9fbdc3af  push rax
0000707f9fbdc3b0  push rcx
0000707f9fbdc3b1  push rdx
0000707f9fbdc3b2  push rdi
0000707f9fbdc3b3  push rsi
0000707f9fbdc3b4  push r8
0000707f9fbdc3b6  push r9
0000707f9fbdc3b8  push r10
0000707f9fbdc3ba  push r11
0000707f9fbdc3bc  sub rsp, 0xF0
0000707f9fbdc3c3  vmovaps [rsp], xmm0
0000707f9fbdc3c8  vmovaps [rsp+0x10], xmm1
0000707f9fbdc3ce  vmovaps [rsp+0x20], xmm2
0000707f9fbdc3d4  vmovaps [rsp+0x30], xmm3
0000707f9fbdc3da  vmovaps [rsp+0x40], xmm4
0000707f9fbdc3e0  vmovaps [rsp+0x50], xmm5
0000707f9fbdc3e6  vmovaps [rsp+0x60], xmm6
0000707f9fbdc3ec  vmovaps [rsp+0x70], xmm7
0000707f9fbdc3f2  vmovaps [rsp+0x80], xmm8
0000707f9fbdc3fb  vmovaps [rsp+0x90], xmm10
0000707f9fbdc404  vmovaps [rsp+0xA0], xmm11
0000707f9fbdc40d  vmovaps [rsp+0xB0], xmm12
0000707f9fbdc416  vmovaps [rsp+0xC0], xmm13
0000707f9fbdc41f  vmovaps [rsp+0xD0], xmm14
0000707f9fbdc428  vmovaps [rsp+0xE0], xmm15
0000707f9fbdc431  sub rsp, 0x40
0000707f9fbdc435  lea rdi, [rsp]
0000707f9fbdc439  lea rsi, [rsp+0x10]
0000707f9fbdc43e  lea rdx, [rsp+0x20]
0000707f9fbdc443  lea rcx, [rsp+0x30]
0000707f9fbdc448  mov r8d, 0x00
0000707f9fbdc44e  lea r9, [r15+0x3A8]
0000707f9fbdc455  movaps [rdi], xmm9
0000707f9fbdc459  movaps [rsi], xmm6
0000707f9fbdc45c  movaps [rdx], xmm1
0000707f9fbdc45f  movaps [rcx], xmm11
0000707f9fbdc463  mov rax, 0x5753922B7A50
0000707f9fbdc46d  call rax
0000707f9fbdc46f  movaps xmm9, [rsp]
0000707f9fbdc474  add rsp, 0x40
0000707f9fbdc478  vmovaps xmm0, [rsp]
0000707f9fbdc47d  vmovaps xmm1, [rsp+0x10]
0000707f9fbdc483  vmovaps xmm2, [rsp+0x20]
0000707f9fbdc489  vmovaps xmm3, [rsp+0x30]
0000707f9fbdc48f  vmovaps xmm4, [rsp+0x40]
0000707f9fbdc495  vmovaps xmm5, [rsp+0x50]
0000707f9fbdc49b  vmovaps xmm6, [rsp+0x60]
0000707f9fbdc4a1  vmovaps xmm7, [rsp+0x70]
0000707f9fbdc4a7  vmovaps xmm8, [rsp+0x80]
0000707f9fbdc4b0  vmovaps xmm10, [rsp+0x90]
0000707f9fbdc4b9  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdc4c2  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdc4cb  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdc4d4  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdc4dd  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdc4e6  add rsp, 0xF0
0000707f9fbdc4ed  pop r11
0000707f9fbdc4ef  pop r10
0000707f9fbdc4f1  pop r9
0000707f9fbdc4f3  pop r8
0000707f9fbdc4f5  pop rsi
0000707f9fbdc4f6  pop rdi
0000707f9fbdc4f7  pop rdx
0000707f9fbdc4f8  pop rcx
0000707f9fbdc4f9  pop rax
0000707f9fbdc4fa  add rsp, 0x08
0000707f9fbdc4fe  jmp 0x0000707F9FBDA447
0000707f9fbdc503  sub rsp, 0x08
0000707f9fbdc507  push rax
0000707f9fbdc508  push rcx
0000707f9fbdc509  push rdx
0000707f9fbdc50a  push rdi
0000707f9fbdc50b  push rsi
0000707f9fbdc50c  push r8
0000707f9fbdc50e  push r9
0000707f9fbdc510  push r10
0000707f9fbdc512  push r11
0000707f9fbdc514  sub rsp, 0xF0
0000707f9fbdc51b  vmovaps [rsp], xmm0
0000707f9fbdc520  vmovaps [rsp+0x10], xmm1
0000707f9fbdc526  vmovaps [rsp+0x20], xmm2
0000707f9fbdc52c  vmovaps [rsp+0x30], xmm3
0000707f9fbdc532  vmovaps [rsp+0x40], xmm4
0000707f9fbdc538  vmovaps [rsp+0x50], xmm5
0000707f9fbdc53e  vmovaps [rsp+0x60], xmm6
0000707f9fbdc544  vmovaps [rsp+0x70], xmm7
0000707f9fbdc54a  vmovaps [rsp+0x80], xmm8
0000707f9fbdc553  vmovaps [rsp+0x90], xmm9
0000707f9fbdc55c  vmovaps [rsp+0xA0], xmm10
0000707f9fbdc565  vmovaps [rsp+0xB0], xmm12
0000707f9fbdc56e  vmovaps [rsp+0xC0], xmm13
0000707f9fbdc577  vmovaps [rsp+0xD0], xmm14
0000707f9fbdc580  vmovaps [rsp+0xE0], xmm15
0000707f9fbdc589  sub rsp, 0x40
0000707f9fbdc58d  lea rdi, [rsp]
0000707f9fbdc591  lea rsi, [rsp+0x10]
0000707f9fbdc596  lea rdx, [rsp+0x20]
0000707f9fbdc59b  lea rcx, [rsp+0x30]
0000707f9fbdc5a0  mov r8d, 0x00
0000707f9fbdc5a6  lea r9, [r15+0x3A8]
0000707f9fbdc5ad  movaps [rdi], xmm11
0000707f9fbdc5b1  movaps [rsi], xmm10
0000707f9fbdc5b5  movaps [rdx], xmm8
0000707f9fbdc5b9  movaps [rcx], xmm1
0000707f9fbdc5bc  mov rax, 0x5753922B7A50
0000707f9fbdc5c6  call rax
0000707f9fbdc5c8  movaps xmm11, [rsp]
0000707f9fbdc5cd  add rsp, 0x40
0000707f9fbdc5d1  vmovaps xmm0, [rsp]
0000707f9fbdc5d6  vmovaps xmm1, [rsp+0x10]
0000707f9fbdc5dc  vmovaps xmm2, [rsp+0x20]
0000707f9fbdc5e2  vmovaps xmm3, [rsp+0x30]
0000707f9fbdc5e8  vmovaps xmm4, [rsp+0x40]
0000707f9fbdc5ee  vmovaps xmm5, [rsp+0x50]
0000707f9fbdc5f4  vmovaps xmm6, [rsp+0x60]
0000707f9fbdc5fa  vmovaps xmm7, [rsp+0x70]
0000707f9fbdc600  vmovaps xmm8, [rsp+0x80]
0000707f9fbdc609  vmovaps xmm9, [rsp+0x90]
0000707f9fbdc612  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdc61b  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdc624  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdc62d  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdc636  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdc63f  add rsp, 0xF0
0000707f9fbdc646  pop r11
0000707f9fbdc648  pop r10
0000707f9fbdc64a  pop r9
0000707f9fbdc64c  pop r8
0000707f9fbdc64e  pop rsi
0000707f9fbdc64f  pop rdi
0000707f9fbdc650  pop rdx
0000707f9fbdc651  pop rcx
0000707f9fbdc652  pop rax
0000707f9fbdc653  add rsp, 0x08
0000707f9fbdc657  jmp 0x0000707F9FBDA46D
0000707f9fbdc65c  sub rsp, 0x08
0000707f9fbdc660  push rax
0000707f9fbdc661  push rcx
0000707f9fbdc662  push rdx
0000707f9fbdc663  push rdi
0000707f9fbdc664  push rsi
0000707f9fbdc665  push r8
0000707f9fbdc667  push r9
0000707f9fbdc669  push r10
0000707f9fbdc66b  push r11
0000707f9fbdc66d  sub rsp, 0xF0
0000707f9fbdc674  vmovaps [rsp], xmm0
0000707f9fbdc679  vmovaps [rsp+0x10], xmm1
0000707f9fbdc67f  vmovaps [rsp+0x20], xmm2
0000707f9fbdc685  vmovaps [rsp+0x30], xmm3
0000707f9fbdc68b  vmovaps [rsp+0x40], xmm4
0000707f9fbdc691  vmovaps [rsp+0x50], xmm5
0000707f9fbdc697  vmovaps [rsp+0x60], xmm6
0000707f9fbdc69d  vmovaps [rsp+0x70], xmm7
0000707f9fbdc6a3  vmovaps [rsp+0x80], xmm8
0000707f9fbdc6ac  vmovaps [rsp+0x90], xmm9
0000707f9fbdc6b5  vmovaps [rsp+0xA0], xmm11
0000707f9fbdc6be  vmovaps [rsp+0xB0], xmm12
0000707f9fbdc6c7  vmovaps [rsp+0xC0], xmm13
0000707f9fbdc6d0  vmovaps [rsp+0xD0], xmm14
0000707f9fbdc6d9  vmovaps [rsp+0xE0], xmm15
0000707f9fbdc6e2  sub rsp, 0x40
0000707f9fbdc6e6  lea rdi, [rsp]
0000707f9fbdc6ea  lea rsi, [rsp+0x10]
0000707f9fbdc6ef  lea rdx, [rsp+0x20]
0000707f9fbdc6f4  lea rcx, [rsp+0x30]
0000707f9fbdc6f9  mov r8d, 0x00
0000707f9fbdc6ff  lea r9, [r15+0x3A8]
0000707f9fbdc706  movaps [rdi], xmm10
0000707f9fbdc70a  movaps [rsi], xmm12
0000707f9fbdc70e  movaps [rdx], xmm13
0000707f9fbdc712  movaps [rcx], xmm1
0000707f9fbdc715  mov rax, 0x5753922B7A50
0000707f9fbdc71f  call rax
0000707f9fbdc721  movaps xmm10, [rsp]
0000707f9fbdc726  add rsp, 0x40
0000707f9fbdc72a  vmovaps xmm0, [rsp]
0000707f9fbdc72f  vmovaps xmm1, [rsp+0x10]
0000707f9fbdc735  vmovaps xmm2, [rsp+0x20]
0000707f9fbdc73b  vmovaps xmm3, [rsp+0x30]
0000707f9fbdc741  vmovaps xmm4, [rsp+0x40]
0000707f9fbdc747  vmovaps xmm5, [rsp+0x50]
0000707f9fbdc74d  vmovaps xmm6, [rsp+0x60]
0000707f9fbdc753  vmovaps xmm7, [rsp+0x70]
0000707f9fbdc759  vmovaps xmm8, [rsp+0x80]
0000707f9fbdc762  vmovaps xmm9, [rsp+0x90]
0000707f9fbdc76b  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdc774  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdc77d  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdc786  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdc78f  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdc798  add rsp, 0xF0
0000707f9fbdc79f  pop r11
0000707f9fbdc7a1  pop r10
0000707f9fbdc7a3  pop r9
0000707f9fbdc7a5  pop r8
0000707f9fbdc7a7  pop rsi
0000707f9fbdc7a8  pop rdi
0000707f9fbdc7a9  pop rdx
0000707f9fbdc7aa  pop rcx
0000707f9fbdc7ab  pop rax
0000707f9fbdc7ac  add rsp, 0x08
0000707f9fbdc7b0  jmp 0x0000707F9FBDA493
0000707f9fbdc7b5  call 0x0000707F9F9FF430
0000707f9fbdc7ba  jmp 0x0000707F9FBDA49D
0000707f9fbdc7bf  call 0x0000707F9FA0C260
0000707f9fbdc7c4  jmp 0x0000707F9FBDA4A7
0000707f9fbdc7c9  sub rsp, 0x08
0000707f9fbdc7cd  push rax
0000707f9fbdc7ce  push rcx
0000707f9fbdc7cf  push rdx
0000707f9fbdc7d0  push rdi
0000707f9fbdc7d1  push rsi
0000707f9fbdc7d2  push r8
0000707f9fbdc7d4  push r9
0000707f9fbdc7d6  push r10
0000707f9fbdc7d8  push r11
0000707f9fbdc7da  sub rsp, 0xF0
0000707f9fbdc7e1  vmovaps [rsp], xmm0
0000707f9fbdc7e6  vmovaps [rsp+0x10], xmm1
0000707f9fbdc7ec  vmovaps [rsp+0x20], xmm2
0000707f9fbdc7f2  vmovaps [rsp+0x30], xmm3
0000707f9fbdc7f8  vmovaps [rsp+0x40], xmm4
0000707f9fbdc7fe  vmovaps [rsp+0x50], xmm5
0000707f9fbdc804  vmovaps [rsp+0x60], xmm6
0000707f9fbdc80a  vmovaps [rsp+0x70], xmm7
0000707f9fbdc810  vmovaps [rsp+0x80], xmm9
0000707f9fbdc819  vmovaps [rsp+0x90], xmm10
0000707f9fbdc822  vmovaps [rsp+0xA0], xmm11
0000707f9fbdc82b  vmovaps [rsp+0xB0], xmm12
0000707f9fbdc834  vmovaps [rsp+0xC0], xmm13
0000707f9fbdc83d  vmovaps [rsp+0xD0], xmm14
0000707f9fbdc846  vmovaps [rsp+0xE0], xmm15
0000707f9fbdc84f  sub rsp, 0x40
0000707f9fbdc853  lea rdi, [rsp]
0000707f9fbdc857  lea rsi, [rsp+0x10]
0000707f9fbdc85c  lea rdx, [rsp+0x20]
0000707f9fbdc861  lea rcx, [rsp+0x30]
0000707f9fbdc866  mov r8d, 0x00
0000707f9fbdc86c  lea r9, [r15+0x3A8]
0000707f9fbdc873  movaps [rdi], xmm8
0000707f9fbdc877  movaps [rsi], xmm7
0000707f9fbdc87a  movaps [rdx], xmm4
0000707f9fbdc87d  movaps [rcx], xmm12
0000707f9fbdc881  mov rax, 0x5753922B7A50
0000707f9fbdc88b  call rax
0000707f9fbdc88d  movaps xmm8, [rsp]
0000707f9fbdc892  add rsp, 0x40
0000707f9fbdc896  vmovaps xmm0, [rsp]
0000707f9fbdc89b  vmovaps xmm1, [rsp+0x10]
0000707f9fbdc8a1  vmovaps xmm2, [rsp+0x20]
0000707f9fbdc8a7  vmovaps xmm3, [rsp+0x30]
0000707f9fbdc8ad  vmovaps xmm4, [rsp+0x40]
0000707f9fbdc8b3  vmovaps xmm5, [rsp+0x50]
0000707f9fbdc8b9  vmovaps xmm6, [rsp+0x60]
0000707f9fbdc8bf  vmovaps xmm7, [rsp+0x70]
0000707f9fbdc8c5  vmovaps xmm9, [rsp+0x80]
0000707f9fbdc8ce  vmovaps xmm10, [rsp+0x90]
0000707f9fbdc8d7  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdc8e0  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdc8e9  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdc8f2  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdc8fb  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdc904  add rsp, 0xF0
0000707f9fbdc90b  pop r11
0000707f9fbdc90d  pop r10
0000707f9fbdc90f  pop r9
0000707f9fbdc911  pop r8
0000707f9fbdc913  pop rsi
0000707f9fbdc914  pop rdi
0000707f9fbdc915  pop rdx
0000707f9fbdc916  pop rcx
0000707f9fbdc917  pop rax
0000707f9fbdc918  add rsp, 0x08
0000707f9fbdc91c  jmp 0x0000707F9FBDA4D0
0000707f9fbdc921  sub rsp, 0x08
0000707f9fbdc925  push rax
0000707f9fbdc926  push rcx
0000707f9fbdc927  push rdx
0000707f9fbdc928  push rdi
0000707f9fbdc929  push rsi
0000707f9fbdc92a  push r8
0000707f9fbdc92c  push r9
0000707f9fbdc92e  push r10
0000707f9fbdc930  push r11
0000707f9fbdc932  sub rsp, 0xF0
0000707f9fbdc939  vmovaps [rsp], xmm0
0000707f9fbdc93e  vmovaps [rsp+0x10], xmm1
0000707f9fbdc944  vmovaps [rsp+0x20], xmm2
0000707f9fbdc94a  vmovaps [rsp+0x30], xmm3
0000707f9fbdc950  vmovaps [rsp+0x40], xmm4
0000707f9fbdc956  vmovaps [rsp+0x50], xmm5
0000707f9fbdc95c  vmovaps [rsp+0x60], xmm6
0000707f9fbdc962  vmovaps [rsp+0x70], xmm8
0000707f9fbdc968  vmovaps [rsp+0x80], xmm9
0000707f9fbdc971  vmovaps [rsp+0x90], xmm10
0000707f9fbdc97a  vmovaps [rsp+0xA0], xmm11
0000707f9fbdc983  vmovaps [rsp+0xB0], xmm12
0000707f9fbdc98c  vmovaps [rsp+0xC0], xmm13
0000707f9fbdc995  vmovaps [rsp+0xD0], xmm14
0000707f9fbdc99e  vmovaps [rsp+0xE0], xmm15
0000707f9fbdc9a7  sub rsp, 0x40
0000707f9fbdc9ab  lea rdi, [rsp]
0000707f9fbdc9af  lea rsi, [rsp+0x10]
0000707f9fbdc9b4  lea rdx, [rsp+0x20]
0000707f9fbdc9b9  lea rcx, [rsp+0x30]
0000707f9fbdc9be  mov r8d, 0x00
0000707f9fbdc9c4  lea r9, [r15+0x3A8]
0000707f9fbdc9cb  movaps [rdi], xmm7
0000707f9fbdc9ce  movaps [rsi], xmm9
0000707f9fbdc9d2  movaps [rdx], xmm14
0000707f9fbdc9d6  movaps [rcx], xmm12
0000707f9fbdc9da  mov rax, 0x5753922B7A50
0000707f9fbdc9e4  call rax
0000707f9fbdc9e6  movaps xmm7, [rsp]
0000707f9fbdc9ea  add rsp, 0x40
0000707f9fbdc9ee  vmovaps xmm0, [rsp]
0000707f9fbdc9f3  vmovaps xmm1, [rsp+0x10]
0000707f9fbdc9f9  vmovaps xmm2, [rsp+0x20]
0000707f9fbdc9ff  vmovaps xmm3, [rsp+0x30]
0000707f9fbdca05  vmovaps xmm4, [rsp+0x40]
0000707f9fbdca0b  vmovaps xmm5, [rsp+0x50]
0000707f9fbdca11  vmovaps xmm6, [rsp+0x60]
0000707f9fbdca17  vmovaps xmm8, [rsp+0x70]
0000707f9fbdca1d  vmovaps xmm9, [rsp+0x80]
0000707f9fbdca26  vmovaps xmm10, [rsp+0x90]
0000707f9fbdca2f  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdca38  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdca41  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdca4a  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdca53  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdca5c  add rsp, 0xF0
0000707f9fbdca63  pop r11
0000707f9fbdca65  pop r10
0000707f9fbdca67  pop r9
0000707f9fbdca69  pop r8
0000707f9fbdca6b  pop rsi
0000707f9fbdca6c  pop rdi
0000707f9fbdca6d  pop rdx
0000707f9fbdca6e  pop rcx
0000707f9fbdca6f  pop rax
0000707f9fbdca70  add rsp, 0x08
0000707f9fbdca74  jmp 0x0000707F9FBDA4F8
0000707f9fbdca79  sub rsp, 0x08
0000707f9fbdca7d  push rax
0000707f9fbdca7e  push rcx
0000707f9fbdca7f  push rdx
0000707f9fbdca80  push rdi
0000707f9fbdca81  push rsi
0000707f9fbdca82  push r8
0000707f9fbdca84  push r9
0000707f9fbdca86  push r10
0000707f9fbdca88  push r11
0000707f9fbdca8a  sub rsp, 0xF0
0000707f9fbdca91  vmovaps [rsp], xmm0
0000707f9fbdca96  vmovaps [rsp+0x10], xmm1
0000707f9fbdca9c  vmovaps [rsp+0x20], xmm2
0000707f9fbdcaa2  vmovaps [rsp+0x30], xmm3
0000707f9fbdcaa8  vmovaps [rsp+0x40], xmm4
0000707f9fbdcaae  vmovaps [rsp+0x50], xmm5
0000707f9fbdcab4  vmovaps [rsp+0x60], xmm6
0000707f9fbdcaba  vmovaps [rsp+0x70], xmm7
0000707f9fbdcac0  vmovaps [rsp+0x80], xmm8
0000707f9fbdcac9  vmovaps [rsp+0x90], xmm9
0000707f9fbdcad2  vmovaps [rsp+0xA0], xmm10
0000707f9fbdcadb  vmovaps [rsp+0xB0], xmm11
0000707f9fbdcae4  vmovaps [rsp+0xC0], xmm13
0000707f9fbdcaed  vmovaps [rsp+0xD0], xmm14
0000707f9fbdcaf6  vmovaps [rsp+0xE0], xmm15
0000707f9fbdcaff  sub rsp, 0x40
0000707f9fbdcb03  lea rdi, [rsp]
0000707f9fbdcb07  lea rsi, [rsp+0x10]
0000707f9fbdcb0c  lea rdx, [rsp+0x20]
0000707f9fbdcb11  lea rcx, [rsp+0x30]
0000707f9fbdcb16  mov r8d, 0x00
0000707f9fbdcb1c  lea r9, [r15+0x3A8]
0000707f9fbdcb23  movaps [rdi], xmm12
0000707f9fbdcb27  movaps [rsi], xmm11
0000707f9fbdcb2b  movaps [rdx], xmm15
0000707f9fbdcb2f  movaps [rcx], xmm14
0000707f9fbdcb33  mov rax, 0x5753922B7A50
0000707f9fbdcb3d  call rax
0000707f9fbdcb3f  movaps xmm12, [rsp]
0000707f9fbdcb44  add rsp, 0x40
0000707f9fbdcb48  vmovaps xmm0, [rsp]
0000707f9fbdcb4d  vmovaps xmm1, [rsp+0x10]
0000707f9fbdcb53  vmovaps xmm2, [rsp+0x20]
0000707f9fbdcb59  vmovaps xmm3, [rsp+0x30]
0000707f9fbdcb5f  vmovaps xmm4, [rsp+0x40]
0000707f9fbdcb65  vmovaps xmm5, [rsp+0x50]
0000707f9fbdcb6b  vmovaps xmm6, [rsp+0x60]
0000707f9fbdcb71  vmovaps xmm7, [rsp+0x70]
0000707f9fbdcb77  vmovaps xmm8, [rsp+0x80]
0000707f9fbdcb80  vmovaps xmm9, [rsp+0x90]
0000707f9fbdcb89  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdcb92  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdcb9b  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdcba4  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdcbad  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdcbb6  add rsp, 0xF0
0000707f9fbdcbbd  pop r11
0000707f9fbdcbbf  pop r10
0000707f9fbdcbc1  pop r9
0000707f9fbdcbc3  pop r8
0000707f9fbdcbc5  pop rsi
0000707f9fbdcbc6  pop rdi
0000707f9fbdcbc7  pop rdx
0000707f9fbdcbc8  pop rcx
0000707f9fbdcbc9  pop rax
0000707f9fbdcbca  add rsp, 0x08
0000707f9fbdcbce  jmp 0x0000707F9FBDA521
0000707f9fbdcbd3  sub rsp, 0x08
0000707f9fbdcbd7  push rax
0000707f9fbdcbd8  push rcx
0000707f9fbdcbd9  push rdx
0000707f9fbdcbda  push rdi
0000707f9fbdcbdb  push rsi
0000707f9fbdcbdc  push r8
0000707f9fbdcbde  push r9
0000707f9fbdcbe0  push r10
0000707f9fbdcbe2  push r11
0000707f9fbdcbe4  sub rsp, 0xF0
0000707f9fbdcbeb  vmovaps [rsp], xmm0
0000707f9fbdcbf0  vmovaps [rsp+0x10], xmm1
0000707f9fbdcbf6  vmovaps [rsp+0x20], xmm2
0000707f9fbdcbfc  vmovaps [rsp+0x30], xmm3
0000707f9fbdcc02  vmovaps [rsp+0x40], xmm4
0000707f9fbdcc08  vmovaps [rsp+0x50], xmm5
0000707f9fbdcc0e  vmovaps [rsp+0x60], xmm6
0000707f9fbdcc14  vmovaps [rsp+0x70], xmm7
0000707f9fbdcc1a  vmovaps [rsp+0x80], xmm8
0000707f9fbdcc23  vmovaps [rsp+0x90], xmm9
0000707f9fbdcc2c  vmovaps [rsp+0xA0], xmm10
0000707f9fbdcc35  vmovaps [rsp+0xB0], xmm12
0000707f9fbdcc3e  vmovaps [rsp+0xC0], xmm13
0000707f9fbdcc47  vmovaps [rsp+0xD0], xmm14
0000707f9fbdcc50  vmovaps [rsp+0xE0], xmm15
0000707f9fbdcc59  sub rsp, 0x40
0000707f9fbdcc5d  lea rdi, [rsp]
0000707f9fbdcc61  lea rsi, [rsp+0x10]
0000707f9fbdcc66  lea rdx, [rsp+0x20]
0000707f9fbdcc6b  lea rcx, [rsp+0x30]
0000707f9fbdcc70  mov r8d, 0x00
0000707f9fbdcc76  lea r9, [r15+0x3A8]
0000707f9fbdcc7d  movaps [rdi], xmm11
0000707f9fbdcc81  movaps [rsi], xmm10
0000707f9fbdcc85  movaps [rdx], xmm13
0000707f9fbdcc89  movaps [rcx], xmm15
0000707f9fbdcc8d  mov rax, 0x5753922B7A50
0000707f9fbdcc97  call rax
0000707f9fbdcc99  movaps xmm11, [rsp]
0000707f9fbdcc9e  add rsp, 0x40
0000707f9fbdcca2  vmovaps xmm0, [rsp]
0000707f9fbdcca7  vmovaps xmm1, [rsp+0x10]
0000707f9fbdccad  vmovaps xmm2, [rsp+0x20]
0000707f9fbdccb3  vmovaps xmm3, [rsp+0x30]
0000707f9fbdccb9  vmovaps xmm4, [rsp+0x40]
0000707f9fbdccbf  vmovaps xmm5, [rsp+0x50]
0000707f9fbdccc5  vmovaps xmm6, [rsp+0x60]
0000707f9fbdcccb  vmovaps xmm7, [rsp+0x70]
0000707f9fbdccd1  vmovaps xmm8, [rsp+0x80]
0000707f9fbdccda  vmovaps xmm9, [rsp+0x90]
0000707f9fbdcce3  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdccec  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdccf5  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdccfe  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdcd07  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdcd10  add rsp, 0xF0
0000707f9fbdcd17  pop r11
0000707f9fbdcd19  pop r10
0000707f9fbdcd1b  pop r9
0000707f9fbdcd1d  pop r8
0000707f9fbdcd1f  pop rsi
0000707f9fbdcd20  pop rdi
0000707f9fbdcd21  pop rdx
0000707f9fbdcd22  pop rcx
0000707f9fbdcd23  pop rax
0000707f9fbdcd24  add rsp, 0x08
0000707f9fbdcd28  jmp 0x0000707F9FBDA54A
0000707f9fbdcd2d  call 0x0000707F9FA0E760
0000707f9fbdcd32  jmp 0x0000707F9FBDA557
0000707f9fbdcd37  call 0x0000707F9FA0D4E0
0000707f9fbdcd3c  jmp 0x0000707F9FBDA564
0000707f9fbdcd41  sub rsp, 0x08
0000707f9fbdcd45  push rax
0000707f9fbdcd46  push rcx
0000707f9fbdcd47  push rdx
0000707f9fbdcd48  push rdi
0000707f9fbdcd49  push rsi
0000707f9fbdcd4a  push r8
0000707f9fbdcd4c  push r9
0000707f9fbdcd4e  push r10
0000707f9fbdcd50  push r11
0000707f9fbdcd52  sub rsp, 0xF0
0000707f9fbdcd59  vmovaps [rsp], xmm0
0000707f9fbdcd5e  vmovaps [rsp+0x10], xmm1
0000707f9fbdcd64  vmovaps [rsp+0x20], xmm2
0000707f9fbdcd6a  vmovaps [rsp+0x30], xmm3
0000707f9fbdcd70  vmovaps [rsp+0x40], xmm4
0000707f9fbdcd76  vmovaps [rsp+0x50], xmm5
0000707f9fbdcd7c  vmovaps [rsp+0x60], xmm6
0000707f9fbdcd82  vmovaps [rsp+0x70], xmm7
0000707f9fbdcd88  vmovaps [rsp+0x80], xmm8
0000707f9fbdcd91  vmovaps [rsp+0x90], xmm9
0000707f9fbdcd9a  vmovaps [rsp+0xA0], xmm11
0000707f9fbdcda3  vmovaps [rsp+0xB0], xmm12
0000707f9fbdcdac  vmovaps [rsp+0xC0], xmm13
0000707f9fbdcdb5  vmovaps [rsp+0xD0], xmm14
0000707f9fbdcdbe  vmovaps [rsp+0xE0], xmm15
0000707f9fbdcdc7  sub rsp, 0x40
0000707f9fbdcdcb  lea rdi, [rsp]
0000707f9fbdcdcf  lea rsi, [rsp+0x10]
0000707f9fbdcdd4  lea rdx, [rsp+0x20]
0000707f9fbdcdd9  lea rcx, [rsp+0x30]
0000707f9fbdcdde  mov r8d, 0x00
0000707f9fbdcde4  lea r9, [r15+0x3A8]
0000707f9fbdcdeb  movaps [rdi], xmm10
0000707f9fbdcdef  movaps [rsi], xmm8
0000707f9fbdcdf3  movaps [rdx], xmm1
0000707f9fbdcdf6  movaps [rcx], xmm13
0000707f9fbdcdfa  mov rax, 0x5753922B7A50
0000707f9fbdce04  call rax
0000707f9fbdce06  movaps xmm10, [rsp]
0000707f9fbdce0b  add rsp, 0x40
0000707f9fbdce0f  vmovaps xmm0, [rsp]
0000707f9fbdce14  vmovaps xmm1, [rsp+0x10]
0000707f9fbdce1a  vmovaps xmm2, [rsp+0x20]
0000707f9fbdce20  vmovaps xmm3, [rsp+0x30]
0000707f9fbdce26  vmovaps xmm4, [rsp+0x40]
0000707f9fbdce2c  vmovaps xmm5, [rsp+0x50]
0000707f9fbdce32  vmovaps xmm6, [rsp+0x60]
0000707f9fbdce38  vmovaps xmm7, [rsp+0x70]
0000707f9fbdce3e  vmovaps xmm8, [rsp+0x80]
0000707f9fbdce47  vmovaps xmm9, [rsp+0x90]
0000707f9fbdce50  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdce59  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdce62  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdce6b  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdce74  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdce7d  add rsp, 0xF0
0000707f9fbdce84  pop r11
0000707f9fbdce86  pop r10
0000707f9fbdce88  pop r9
0000707f9fbdce8a  pop r8
0000707f9fbdce8c  pop rsi
0000707f9fbdce8d  pop rdi
0000707f9fbdce8e  pop rdx
0000707f9fbdce8f  pop rcx
0000707f9fbdce90  pop rax
0000707f9fbdce91  add rsp, 0x08
0000707f9fbdce95  jmp 0x0000707F9FBDA59A
0000707f9fbdce9a  call 0x0000707F9F9FF430
0000707f9fbdce9f  jmp 0x0000707F9FBDA5AC
0000707f9fbdcea4  sub rsp, 0x08
0000707f9fbdcea8  push rax
0000707f9fbdcea9  push rcx
0000707f9fbdceaa  push rdx
0000707f9fbdceab  push rdi
0000707f9fbdceac  push rsi
0000707f9fbdcead  push r8
0000707f9fbdceaf  push r9
0000707f9fbdceb1  push r10
0000707f9fbdceb3  push r11
0000707f9fbdceb5  sub rsp, 0xF0
0000707f9fbdcebc  vmovaps [rsp], xmm0
0000707f9fbdcec1  vmovaps [rsp+0x10], xmm1
0000707f9fbdcec7  vmovaps [rsp+0x20], xmm2
0000707f9fbdcecd  vmovaps [rsp+0x30], xmm3
0000707f9fbdced3  vmovaps [rsp+0x40], xmm4
0000707f9fbdced9  vmovaps [rsp+0x50], xmm5
0000707f9fbdcedf  vmovaps [rsp+0x60], xmm6
0000707f9fbdcee5  vmovaps [rsp+0x70], xmm7
0000707f9fbdceeb  vmovaps [rsp+0x80], xmm8
0000707f9fbdcef4  vmovaps [rsp+0x90], xmm10
0000707f9fbdcefd  vmovaps [rsp+0xA0], xmm11
0000707f9fbdcf06  vmovaps [rsp+0xB0], xmm12
0000707f9fbdcf0f  vmovaps [rsp+0xC0], xmm13
0000707f9fbdcf18  vmovaps [rsp+0xD0], xmm14
0000707f9fbdcf21  vmovaps [rsp+0xE0], xmm15
0000707f9fbdcf2a  sub rsp, 0x40
0000707f9fbdcf2e  lea rdi, [rsp]
0000707f9fbdcf32  lea rsi, [rsp+0x10]
0000707f9fbdcf37  lea rdx, [rsp+0x20]
0000707f9fbdcf3c  lea rcx, [rsp+0x30]
0000707f9fbdcf41  mov r8d, 0x00
0000707f9fbdcf47  lea r9, [r15+0x3A8]
0000707f9fbdcf4e  movaps [rdi], xmm9
0000707f9fbdcf52  movaps [rsi], xmm7
0000707f9fbdcf55  movaps [rdx], xmm14
0000707f9fbdcf59  movaps [rcx], xmm13
0000707f9fbdcf5d  mov rax, 0x5753922B7A50
0000707f9fbdcf67  call rax
0000707f9fbdcf69  movaps xmm9, [rsp]
0000707f9fbdcf6e  add rsp, 0x40
0000707f9fbdcf72  vmovaps xmm0, [rsp]
0000707f9fbdcf77  vmovaps xmm1, [rsp+0x10]
0000707f9fbdcf7d  vmovaps xmm2, [rsp+0x20]
0000707f9fbdcf83  vmovaps xmm3, [rsp+0x30]
0000707f9fbdcf89  vmovaps xmm4, [rsp+0x40]
0000707f9fbdcf8f  vmovaps xmm5, [rsp+0x50]
0000707f9fbdcf95  vmovaps xmm6, [rsp+0x60]
0000707f9fbdcf9b  vmovaps xmm7, [rsp+0x70]
0000707f9fbdcfa1  vmovaps xmm8, [rsp+0x80]
0000707f9fbdcfaa  vmovaps xmm10, [rsp+0x90]
0000707f9fbdcfb3  vmovaps xmm11, [rsp+0xA0]
0000707f9fbdcfbc  vmovaps xmm12, [rsp+0xB0]
0000707f9fbdcfc5  vmovaps xmm13, [rsp+0xC0]
0000707f9fbdcfce  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdcfd7  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdcfe0  add rsp, 0xF0
0000707f9fbdcfe7  pop r11
0000707f9fbdcfe9  pop r10
0000707f9fbdcfeb  pop r9
0000707f9fbdcfed  pop r8
0000707f9fbdcfef  pop rsi
0000707f9fbdcff0  pop rdi
0000707f9fbdcff1  pop rdx
0000707f9fbdcff2  pop rcx
0000707f9fbdcff3  pop rax
0000707f9fbdcff4  add rsp, 0x08
0000707f9fbdcff8  jmp 0x0000707F9FBDA5DA
0000707f9fbdcffd  sub rsp, 0x08
0000707f9fbdd001  push rax
0000707f9fbdd002  push rcx
0000707f9fbdd003  push rdx
0000707f9fbdd004  push rdi
0000707f9fbdd005  push rsi
0000707f9fbdd006  push r8
0000707f9fbdd008  push r9
0000707f9fbdd00a  push r10
0000707f9fbdd00c  push r11
0000707f9fbdd00e  sub rsp, 0xF0
0000707f9fbdd015  vmovaps [rsp], xmm0
0000707f9fbdd01a  vmovaps [rsp+0x10], xmm1
0000707f9fbdd020  vmovaps [rsp+0x20], xmm2
0000707f9fbdd026  vmovaps [rsp+0x30], xmm3
0000707f9fbdd02c  vmovaps [rsp+0x40], xmm4
0000707f9fbdd032  vmovaps [rsp+0x50], xmm5
0000707f9fbdd038  vmovaps [rsp+0x60], xmm6
0000707f9fbdd03e  vmovaps [rsp+0x70], xmm7
0000707f9fbdd044  vmovaps [rsp+0x80], xmm8
0000707f9fbdd04d  vmovaps [rsp+0x90], xmm9
0000707f9fbdd056  vmovaps [rsp+0xA0], xmm10
0000707f9fbdd05f  vmovaps [rsp+0xB0], xmm11
0000707f9fbdd068  vmovaps [rsp+0xC0], xmm12
0000707f9fbdd071  vmovaps [rsp+0xD0], xmm14
0000707f9fbdd07a  vmovaps [rsp+0xE0], xmm15
0000707f9fbdd083  sub rsp, 0x40
0000707f9fbdd087  lea rdi, [rsp]
0000707f9fbdd08b  lea rsi, [rsp+0x10]
0000707f9fbdd090  lea rdx, [rsp+0x20]
0000707f9fbdd095  lea rcx, [rsp+0x30]
0000707f9fbdd09a  mov r8d, 0x00
0000707f9fbdd0a0  lea r9, [r15+0x3A8]
0000707f9fbdd0a7  movaps [rdi], xmm13
0000707f9fbdd0ab  movaps [rsi], xmm12
0000707f9fbdd0af  movaps [rdx], xmm15
0000707f9fbdd0b3  movaps [rcx], xmm14
0000707f9fbdd0b7  mov rax, 0x5753922B7A50
0000707f9fbdd0c1  call rax
0000707f9fbdd0c3  movaps xmm13, [rsp]
0000707f9fbdd0c8  add rsp, 0x40
0000707f9fbdd0cc  vmovaps xmm0, [rsp]
0000707f9fbdd0d1  vmovaps xmm1, [rsp+0x10]
0000707f9fbdd0d7  vmovaps xmm2, [rsp+0x20]
0000707f9fbdd0dd  vmovaps xmm3, [rsp+0x30]
0000707f9fbdd0e3  vmovaps xmm4, [rsp+0x40]
0000707f9fbdd0e9  vmovaps xmm5, [rsp+0x50]
0000707f9fbdd0ef  vmovaps xmm6, [rsp+0x60]
0000707f9fbdd0f5  vmovaps xmm7, [rsp+0x70]
0000707f9fbdd0fb  vmovaps xmm8, [rsp+0x80]
0000707f9fbdd104  vmovaps xmm9, [rsp+0x90]
0000707f9fbdd10d  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdd116  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdd11f  vmovaps xmm12, [rsp+0xC0]
0000707f9fbdd128  vmovaps xmm14, [rsp+0xD0]
0000707f9fbdd131  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdd13a  add rsp, 0xF0
0000707f9fbdd141  pop r11
0000707f9fbdd143  pop r10
0000707f9fbdd145  pop r9
0000707f9fbdd147  pop r8
0000707f9fbdd149  pop rsi
0000707f9fbdd14a  pop rdi
0000707f9fbdd14b  pop rdx
0000707f9fbdd14c  pop rcx
0000707f9fbdd14d  pop rax
0000707f9fbdd14e  add rsp, 0x08
0000707f9fbdd152  jmp 0x0000707F9FBDA608
0000707f9fbdd157  sub rsp, 0x08
0000707f9fbdd15b  push rax
0000707f9fbdd15c  push rcx
0000707f9fbdd15d  push rdx
0000707f9fbdd15e  push rdi
0000707f9fbdd15f  push rsi
0000707f9fbdd160  push r8
0000707f9fbdd162  push r9
0000707f9fbdd164  push r10
0000707f9fbdd166  push r11
0000707f9fbdd168  sub rsp, 0xF0
0000707f9fbdd16f  vmovaps [rsp], xmm0
0000707f9fbdd174  vmovaps [rsp+0x10], xmm1
0000707f9fbdd17a  vmovaps [rsp+0x20], xmm2
0000707f9fbdd180  vmovaps [rsp+0x30], xmm3
0000707f9fbdd186  vmovaps [rsp+0x40], xmm4
0000707f9fbdd18c  vmovaps [rsp+0x50], xmm5
0000707f9fbdd192  vmovaps [rsp+0x60], xmm6
0000707f9fbdd198  vmovaps [rsp+0x70], xmm7
0000707f9fbdd19e  vmovaps [rsp+0x80], xmm8
0000707f9fbdd1a7  vmovaps [rsp+0x90], xmm9
0000707f9fbdd1b0  vmovaps [rsp+0xA0], xmm10
0000707f9fbdd1b9  vmovaps [rsp+0xB0], xmm11
0000707f9fbdd1c2  vmovaps [rsp+0xC0], xmm12
0000707f9fbdd1cb  vmovaps [rsp+0xD0], xmm13
0000707f9fbdd1d4  vmovaps [rsp+0xE0], xmm15
0000707f9fbdd1dd  sub rsp, 0x40
0000707f9fbdd1e1  lea rdi, [rsp]
0000707f9fbdd1e5  lea rsi, [rsp+0x10]
0000707f9fbdd1ea  lea rdx, [rsp+0x20]
0000707f9fbdd1ef  lea rcx, [rsp+0x30]
0000707f9fbdd1f4  mov r8d, 0x00
0000707f9fbdd1fa  lea r9, [r15+0x3A8]
0000707f9fbdd201  movaps [rdi], xmm14
0000707f9fbdd205  movaps [rsi], xmm11
0000707f9fbdd209  movaps [rdx], xmm1
0000707f9fbdd20c  movaps [rcx], xmm15
0000707f9fbdd210  mov rax, 0x5753922B7A50
0000707f9fbdd21a  call rax
0000707f9fbdd21c  movaps xmm14, [rsp]
0000707f9fbdd221  add rsp, 0x40
0000707f9fbdd225  vmovaps xmm0, [rsp]
0000707f9fbdd22a  vmovaps xmm1, [rsp+0x10]
0000707f9fbdd230  vmovaps xmm2, [rsp+0x20]
0000707f9fbdd236  vmovaps xmm3, [rsp+0x30]
0000707f9fbdd23c  vmovaps xmm4, [rsp+0x40]
0000707f9fbdd242  vmovaps xmm5, [rsp+0x50]
0000707f9fbdd248  vmovaps xmm6, [rsp+0x60]
0000707f9fbdd24e  vmovaps xmm7, [rsp+0x70]
0000707f9fbdd254  vmovaps xmm8, [rsp+0x80]
0000707f9fbdd25d  vmovaps xmm9, [rsp+0x90]
0000707f9fbdd266  vmovaps xmm10, [rsp+0xA0]
0000707f9fbdd26f  vmovaps xmm11, [rsp+0xB0]
0000707f9fbdd278  vmovaps xmm12, [rsp+0xC0]
0000707f9fbdd281  vmovaps xmm13, [rsp+0xD0]
0000707f9fbdd28a  vmovaps xmm15, [rsp+0xE0]
0000707f9fbdd293  add rsp, 0xF0
0000707f9fbdd29a  pop r11
0000707f9fbdd29c  pop r10
0000707f9fbdd29e  pop r9
0000707f9fbdd2a0  pop r8
0000707f9fbdd2a2  pop rsi
0000707f9fbdd2a3  pop rdi
0000707f9fbdd2a4  pop rdx
0000707f9fbdd2a5  pop rcx
0000707f9fbdd2a6  pop rax
0000707f9fbdd2a7  add rsp, 0x08
0000707f9fbdd2ab  jmp 0x0000707F9FBDA636
0000707f9fbdd2b0  call 0x0000707F9FA079B0
0000707f9fbdd2b5  jmp 0x0000707F9FBDA64C
0000707f9fbdd2ba  call 0x0000707F9FAE3440
0000707f9fbdd2bf  jmp 0x0000707F9FBDA656
0000707f9fbdd2c4  call 0x0000707F9FADFCE0
0000707f9fbdd2c9  jmp 0x0000707F9FBDA660
0000707f9fbdd2ce  call 0x0000707F9FAE46C0
0000707f9fbdd2d3  jmp 0x0000707F9FBDA66A
0000707f9fbdd2d8  int3
0000707f9fbdd2d9  nop [rax], eax
0000707f9fbdd2e0  mov qword ptr [r15+0x40], 0x430000
0000707f9fbdd2e8  mov eax, 0x430C50
0000707f9fbdd2ed  mov r14, [r13+rax*1]
0000707f9fbdd2f2  movq xmm1, r14
0000707f9fbdd2f7  mov rax, [r15+0x50]
0000707f9fbdd2fb  movups xmm15, [r13+rax*1]
0000707f9fbdd301  movaps [r15+0x120], xmm15
0000707f9fbdd309  mov qword ptr [r15+0x48], 0x10
0000707f9fbdd311  xor eax, eax
0000707f9fbdd313  mov r14d, 0x10
0000707f9fbdd319  mov r12d, 0x200
0000707f9fbdd31f  cmp r14, r12
0000707f9fbdd322  cmc
0000707f9fbdd323  lahf
0000707f9fbdd324  seto al
0000707f9fbdd327  mov [r15+0x108], eax
0000707f9fbdd32e  pextrq rax, xmm15, 0x01
0000707f9fbdd335  movq xmm14, rax
0000707f9fbdd33a  movaps [r15+0x130], xmm14
0000707f9fbdd342  movq rax, xmm1
0000707f9fbdd347  movq r14, xmm15
0000707f9fbdd34c  vmovq xmm1, rax
0000707f9fbdd351  vmovq xmm15, r14
0000707f9fbdd356  movaps xmm13, xmm1
0000707f9fbdd35a  addsd xmm13, xmm15
0000707f9fbdd35f  ucomisd xmm13, xmm13
0000707f9fbdd364  jp 0x0000707F9FBDD423
0000707f9fbdd36a  movq xmm13, xmm13
0000707f9fbdd36f  movq rax, xmm13
0000707f9fbdd374  movq r14, xmm14
0000707f9fbdd379  vmovq xmm1, rax
0000707f9fbdd37e  vmovq xmm15, r14
0000707f9fbdd383  movaps xmm14, xmm1
0000707f9fbdd387  addsd xmm14, xmm15
0000707f9fbdd38c  ucomisd xmm14, xmm14
0000707f9fbdd391  jp 0x0000707F9FBDD46B
0000707f9fbdd397  movq xmm14, xmm14
0000707f9fbdd39c  movaps [r15+0x110], xmm14
0000707f9fbdd3a4  mov eax, [r15+0x108]
0000707f9fbdd3ab  sahf
0000707f9fbdd3ac  jnz 0x0000707F9FBDD3DE
0000707f9fbdd3ae  cmp dword ptr [r15+0x318], 0x00
0000707f9fbdd3b6  jz 0x0000707F9FBDD680
0000707f9fbdd3bc  nop [rax+rax*1], ax
0000707f9fbdd3c5  nop [rax+rax*1], eax
0000707f9fbdd3cd  mov eax, 0x410698
0000707f9fbdd3d2  mov [r15+0x100], rax
0000707f9fbdd3d9  jmp 0x0000707F9F9FE110
0000707f9fbdd3de  cmp dword ptr [r15+0x318], 0x00
0000707f9fbdd3e6  jz 0x0000707F9FBDD4C0
0000707f9fbdd3ec  nop [rax+rax*1], ax
0000707f9fbdd3f5  nop [rax+rax*1], eax
0000707f9fbdd3fd  mov eax, 0x41067C
0000707f9fbdd402  mov [r15+0x100], rax
0000707f9fbdd409  jmp 0x0000707F9F9FE110
0000707f9fbdd40e  int3
0000707f9fbdd40f  call 0x0000707F9FA0DC20
0000707f9fbdd414  jmp 0x0000707F9FBDD2F2
0000707f9fbdd419  call 0x0000707F9FA0E760
0000707f9fbdd41e  jmp 0x0000707F9FBDD301
0000707f9fbdd423  ucomisd xmm1, xmm15
0000707f9fbdd428  jp 0x0000707F9FBDD437
0000707f9fbdd42a  movaps xmm13, [0x0000707F9F7FE060]
0000707f9fbdd432  jmp 0x0000707F9FBDD36A
0000707f9fbdd437  vxorps xmm0, xmm1, xmm15
0000707f9fbdd43c  pextrw eax, xmm0, 0x03
0000707f9fbdd441  and eax, 0x7FF8
0000707f9fbdd446  cmp eax, 0x08
0000707f9fbdd449  jnz 0x0000707F9FBDD36A
0000707f9fbdd44f  movq rax, xmm15
0000707f9fbdd454  shl rax, 0x0D
0000707f9fbdd458  jbe 0x0000707F9FBDD36A
0000707f9fbdd45e  vorps xmm13, xmm15, [0x0000707F9F7FE070]
0000707f9fbdd466  jmp 0x0000707F9FBDD36A
0000707f9fbdd46b  ucomisd xmm1, xmm15
0000707f9fbdd470  jp 0x0000707F9FBDD47F
0000707f9fbdd472  movaps xmm14, [0x0000707F9F7FE060]
0000707f9fbdd47a  jmp 0x0000707F9FBDD397
0000707f9fbdd47f  vxorps xmm0, xmm1, xmm15
0000707f9fbdd484  pextrw eax, xmm0, 0x03
0000707f9fbdd489  and eax, 0x7FF8
0000707f9fbdd48e  cmp eax, 0x08
0000707f9fbdd491  jnz 0x0000707F9FBDD397
0000707f9fbdd497  movq rax, xmm15
0000707f9fbdd49c  shl rax, 0x0D
0000707f9fbdd4a0  jbe 0x0000707F9FBDD397
0000707f9fbdd4a6  vorps xmm14, xmm15, [0x0000707F9F7FE070]
0000707f9fbdd4ae  jmp 0x0000707F9FBDD397
0000707f9fbdd4b3  int3
0000707f9fbdd4b4  nop [rax+rax*1], ax
0000707f9fbdd4bd  nop [rax], eax
0000707f9fbdd4c0  mov rax, [r15+0x48]
0000707f9fbdd4c4  mov r14, [r15+0x50]
0000707f9fbdd4c8  lea r12, [r14+rax*1]
0000707f9fbdd4cc  movups xmm1, [r13+r12*1]
0000707f9fbdd4d2  movaps [r15+0x120], xmm1
0000707f9fbdd4da  lea r14, [rax+0x10]
0000707f9fbdd4de  mov [r15+0x48], r14
0000707f9fbdd4e2  xor eax, eax
0000707f9fbdd4e4  mov r12d, 0x200
0000707f9fbdd4ea  cmp r14, r12
0000707f9fbdd4ed  cmc
0000707f9fbdd4ee  lahf
0000707f9fbdd4ef  seto al
0000707f9fbdd4f2  mov [r15+0x108], eax
0000707f9fbdd4f9  pextrq rax, xmm1, 0x01
0000707f9fbdd500  movq xmm15, rax
0000707f9fbdd505  movaps [r15+0x130], xmm15
0000707f9fbdd50d  movaps xmm14, [r15+0x110]
0000707f9fbdd515  movq rax, xmm14
0000707f9fbdd51a  movq r14, xmm1
0000707f9fbdd51f  vmovq xmm1, rax
0000707f9fbdd524  vmovq xmm14, r14
0000707f9fbdd529  movaps xmm13, xmm1
0000707f9fbdd52d  addsd xmm13, xmm14
0000707f9fbdd532  ucomisd xmm13, xmm13
0000707f9fbdd537  jp 0x0000707F9FBDD5EC
0000707f9fbdd53d  movq xmm13, xmm13
0000707f9fbdd542  movq rax, xmm13
0000707f9fbdd547  movq r14, xmm15
0000707f9fbdd54c  vmovq xmm1, rax
0000707f9fbdd551  vmovq xmm15, r14
0000707f9fbdd556  movaps xmm14, xmm1
0000707f9fbdd55a  addsd xmm14, xmm15
0000707f9fbdd55f  ucomisd xmm14, xmm14
0000707f9fbdd564  jp 0x0000707F9FBDD634
0000707f9fbdd56a  movq xmm14, xmm14
0000707f9fbdd56f  movaps [r15+0x110], xmm14
0000707f9fbdd577  mov eax, [r15+0x108]
0000707f9fbdd57e  sahf
0000707f9fbdd57f  jnz 0x0000707F9FBDD5B1
0000707f9fbdd581  cmp dword ptr [r15+0x318], 0x00
0000707f9fbdd589  jz 0x0000707F9FBDD680
0000707f9fbdd58f  nop [rax+rax*1], ax
0000707f9fbdd598  nop [rax+rax*1], eax
0000707f9fbdd5a0  mov eax, 0x410698
0000707f9fbdd5a5  mov [r15+0x100], rax
0000707f9fbdd5ac  jmp 0x0000707F9F9FE110
0000707f9fbdd5b1  cmp dword ptr [r15+0x318], 0x00
0000707f9fbdd5b9  jz 0x0000707F9FBDD4C0
0000707f9fbdd5bf  nop [rax+rax*1], ax
0000707f9fbdd5c8  nop [rax+rax*1], eax
0000707f9fbdd5d0  mov eax, 0x41067C
0000707f9fbdd5d5  mov [r15+0x100], rax
0000707f9fbdd5dc  jmp 0x0000707F9F9FE110
0000707f9fbdd5e1  int3
0000707f9fbdd5e2  call 0x0000707F9FAB52F0
0000707f9fbdd5e7  jmp 0x0000707F9FBDD4D2
0000707f9fbdd5ec  ucomisd xmm1, xmm14
0000707f9fbdd5f1  jp 0x0000707F9FBDD600
0000707f9fbdd5f3  movaps xmm13, [0x0000707F9F7FE060]
0000707f9fbdd5fb  jmp 0x0000707F9FBDD53D
0000707f9fbdd600  vxorps xmm0, xmm1, xmm14
0000707f9fbdd605  pextrw eax, xmm0, 0x03
0000707f9fbdd60a  and eax, 0x7FF8
0000707f9fbdd60f  cmp eax, 0x08
0000707f9fbdd612  jnz 0x0000707F9FBDD53D
0000707f9fbdd618  movq rax, xmm14
0000707f9fbdd61d  shl rax, 0x0D
0000707f9fbdd621  jbe 0x0000707F9FBDD53D
0000707f9fbdd627  vorps xmm13, xmm14, [0x0000707F9F7FE070]
0000707f9fbdd62f  jmp 0x0000707F9FBDD53D
0000707f9fbdd634  ucomisd xmm1, xmm15
0000707f9fbdd639  jp 0x0000707F9FBDD648
0000707f9fbdd63b  movaps xmm14, [0x0000707F9F7FE060]
0000707f9fbdd643  jmp 0x0000707F9FBDD56A
0000707f9fbdd648  vxorps xmm0, xmm1, xmm15
0000707f9fbdd64d  pextrw eax, xmm0, 0x03
0000707f9fbdd652  and eax, 0x7FF8
0000707f9fbdd657  cmp eax, 0x08
0000707f9fbdd65a  jnz 0x0000707F9FBDD56A
0000707f9fbdd660  movq rax, xmm15
0000707f9fbdd665  shl rax, 0x0D
0000707f9fbdd669  jbe 0x0000707F9FBDD56A
0000707f9fbdd66f  vorps xmm14, xmm15, [0x0000707F9F7FE070]
0000707f9fbdd677  jmp 0x0000707F9FBDD56A
0000707f9fbdd67c  int3
0000707f9fbdd67d  nop [rax], eax
0000707f9fbdd680  mov rax, [r15+0xF8]
0000707f9fbdd687  lea r14, [rax+0x1A0]
0000707f9fbdd68e  mov r12, [r13+r14*1]
0000707f9fbdd693  lea r14, [rax+0x1A8]
0000707f9fbdd69a  mov r11, [r13+r14*1]
0000707f9fbdd69f  mov [r15+0xA0], r12
0000707f9fbdd6a6  mov [r15+0x98], r11
0000707f9fbdd6ad  mov r14, [r15+0x40]
0000707f9fbdd6b1  lea r12, [r14+0xC50]
0000707f9fbdd6b8  movaps xmm1, [r15+0x110]
0000707f9fbdd6c0  movq r14, xmm1
0000707f9fbdd6c5  mov [r13+r12*1], r14
0000707f9fbdd6ca  lea r14, [rax+0x190]
0000707f9fbdd6d1  mov r12, [r13+r14*1]
0000707f9fbdd6d6  lea r14, [rax+0x198]
0000707f9fbdd6dd  mov r11, [r13+r14*1]
0000707f9fbdd6e2  mov [r15+0xE8], r12
0000707f9fbdd6e9  mov [r15+0xF0], r11
0000707f9fbdd6f0  lea r14, [rax+0x180]
0000707f9fbdd6f7  mov r12, [r13+r14*1]
0000707f9fbdd6fc  lea r14, [rax+0x188]
0000707f9fbdd703  mov r10, [r13+r14*1]
0000707f9fbdd708  movq xmm1, r12
0000707f9fbdd70d  movq xmm15, r10
0000707f9fbdd712  movq xmm1, xmm1
0000707f9fbdd716  movq xmm1, xmm1
0000707f9fbdd71a  movaps [r15+0x1A0], xmm1
0000707f9fbdd722  movq xmm15, xmm15
0000707f9fbdd727  movq xmm15, xmm15
0000707f9fbdd72c  movaps [r15+0x190], xmm15
0000707f9fbdd734  lea r14, [rax+0x170]
0000707f9fbdd73b  mov r12, [r13+r14*1]
0000707f9fbdd740  lea r14, [rax+0x178]
0000707f9fbdd747  mov r10, [r13+r14*1]
0000707f9fbdd74c  movq xmm1, r12
0000707f9fbdd751  movq xmm15, r10
0000707f9fbdd756  movq xmm1, xmm1
0000707f9fbdd75a  movq xmm1, xmm1
0000707f9fbdd75e  movaps [r15+0x1C0], xmm1
0000707f9fbdd766  movq xmm15, xmm15
0000707f9fbdd76b  movq xmm15, xmm15
0000707f9fbdd770  movaps [r15+0x1B0], xmm15
0000707f9fbdd778  lea r14, [rax+0x160]
0000707f9fbdd77f  mov r12, [r13+r14*1]
0000707f9fbdd784  lea r14, [rax+0x168]
0000707f9fbdd78b  mov r10, [r13+r14*1]
0000707f9fbdd790  movq xmm1, r12
0000707f9fbdd795  movq xmm15, r10
0000707f9fbdd79a  movq xmm1, xmm1
0000707f9fbdd79e  movq xmm1, xmm1
0000707f9fbdd7a2  movaps [r15+0x1E0], xmm1
0000707f9fbdd7aa  movq xmm15, xmm15
0000707f9fbdd7af  movq xmm15, xmm15
0000707f9fbdd7b4  movaps [r15+0x1D0], xmm15
0000707f9fbdd7bc  lea r14, [rax+0x150]
0000707f9fbdd7c3  mov r12, [r13+r14*1]
0000707f9fbdd7c8  lea r14, [rax+0x158]
0000707f9fbdd7cf  mov r10, [r13+r14*1]
0000707f9fbdd7d4  movq xmm1, r12
0000707f9fbdd7d9  movq xmm15, r10
0000707f9fbdd7de  movq xmm1, xmm1
0000707f9fbdd7e2  movq xmm1, xmm1
0000707f9fbdd7e6  movaps [r15+0x200], xmm1
0000707f9fbdd7ee  movq xmm15, xmm15
0000707f9fbdd7f3  movq xmm15, xmm15
0000707f9fbdd7f8  movaps [r15+0x1F0], xmm15
0000707f9fbdd800  lea r14, [rax+0x1B0]
0000707f9fbdd807  mov [r15+0xF8], r14
0000707f9fbdd80e  mov [r15+0x100], r11
0000707f9fbdd815  jmp 0x0000707F9FBCE5C0
0000707f9fbdd81a  int3
0000707f9fbdd81b  call 0x0000707F9FAE27E0
0000707f9fbdd820  jmp 0x0000707F9FBDD693
0000707f9fbdd825  call 0x0000707F9FAE1570
0000707f9fbdd82a  jmp 0x0000707F9FBDD69F
0000707f9fbdd82f  call 0x0000707F9FAC3FE0
0000707f9fbdd834  jmp 0x0000707F9FBDD6CA
0000707f9fbdd839  call 0x0000707F9FAE27E0
0000707f9fbdd83e  jmp 0x0000707F9FBDD6D6
0000707f9fbdd843  call 0x0000707F9FAE1570
0000707f9fbdd848  jmp 0x0000707F9FBDD6E2
0000707f9fbdd84d  call 0x0000707F9FAE27E0
0000707f9fbdd852  jmp 0x0000707F9FBDD6FC
0000707f9fbdd857  call 0x0000707F9FAE0300
0000707f9fbdd85c  jmp 0x0000707F9FBDD708
0000707f9fbdd861  call 0x0000707F9FAE27E0
0000707f9fbdd866  jmp 0x0000707F9FBDD740
0000707f9fbdd86b  call 0x0000707F9FAE0300
0000707f9fbdd870  jmp 0x0000707F9FBDD74C
0000707f9fbdd875  call 0x0000707F9FAE27E0
0000707f9fbdd87a  jmp 0x0000707F9FBDD784
0000707f9fbdd87f  call 0x0000707F9FAE0300
0000707f9fbdd884  jmp 0x0000707F9FBDD790
0000707f9fbdd889  call 0x0000707F9FAE27E0
0000707f9fbdd88e  jmp 0x0000707F9FBDD7C8
0000707f9fbdd893  call 0x0000707F9FAE0300
0000707f9fbdd898  jmp 0x0000707F9FBDD7D4
0000707f9fbdd89d  int3
0000707f9fbdd89e  nop
0000707f9fbdd8a0  mov qword ptr [r15+0x100], 0x04
0000707f9fbdd8ab  mov esi, 0x00
0000707f9fbdd8b0  mov edx, 0x09
0000707f9fbdd8b5  mov rdi, 0x7FFD11DBFD70
0000707f9fbdd8bf  mov rax, 0x57539214A970
0000707f9fbdd8c9  call rax
0000707f9fbdd8cb  cmp dword ptr [r15+0x318], 0x00
0000707f9fbdd8d3  jnz 0x0000707F9F9FE110
0000707f9fbdd8d9  jmp 0x0000707F9F9FE0A0
0000707f9fbdd8de  int3
0000707f9fbdd8df  int3
