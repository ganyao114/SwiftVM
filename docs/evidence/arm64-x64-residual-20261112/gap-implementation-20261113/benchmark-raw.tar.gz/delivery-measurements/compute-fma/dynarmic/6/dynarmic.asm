00007957b0dce69b  nop [rax+rax*1], eax
00007957b0dce6a0  mov rax, [r15+0xF8]
00007957b0dce6a7  lea r14, [rax-0x1B0]
00007957b0dce6ae  mov [r15+0xF8], r14
00007957b0dce6b5  lea rax, [r14+0x1A0]
00007957b0dce6bc  mov r12, [r15+0xA0]
00007957b0dce6c3  mov r11, [r15+0x98]
00007957b0dce6ca  mov [r13+rax*1], r12
00007957b0dce6cf  lea rax, [r14+0x1A8]
00007957b0dce6d6  mov [r13+rax*1], r11
00007957b0dce6db  mov eax, 0x420A30
00007957b0dce6e0  movups xmm1, [r13+rax*1]
00007957b0dce6e6  mov eax, 0x4209C0
00007957b0dce6eb  movups xmm15, [r13+rax*1]
00007957b0dce6f1  mov eax, 0x420A50
00007957b0dce6f6  movups xmm14, [r13+rax*1]
00007957b0dce6fc  mov eax, 0x4209F0
00007957b0dce701  movups xmm13, [r13+rax*1]
00007957b0dce707  mov qword ptr [r15+0x98], 0x430C60
00007957b0dce712  mov eax, 0x420A60
00007957b0dce717  movups xmm12, [r13+rax*1]
00007957b0dce71d  mov eax, 0x430C60
00007957b0dce722  movups [r13+rax*1], xmm1
00007957b0dce728  mov eax, 0x430C70
00007957b0dce72d  movups [r13+rax*1], xmm15
00007957b0dce733  mov eax, 0x430C80
00007957b0dce738  movups [r13+rax*1], xmm14
00007957b0dce73e  mov eax, 0x430C90
00007957b0dce743  movups [r13+rax*1], xmm13
00007957b0dce749  mov eax, 0x4209B0
00007957b0dce74e  movups xmm14, [r13+rax*1]
00007957b0dce754  mov eax, 0x4209A0
00007957b0dce759  movups xmm13, [r13+rax*1]
00007957b0dce75f  mov eax, 0x430D60
00007957b0dce764  movups [r13+rax*1], xmm1
00007957b0dce76a  mov eax, 0x430D70
00007957b0dce76f  movups [r13+rax*1], xmm15
00007957b0dce775  mov eax, 0x430CA0
00007957b0dce77a  movups [r13+rax*1], xmm12
00007957b0dce780  mov eax, 0x430CB0
00007957b0dce785  movups [r13+rax*1], xmm14
00007957b0dce78b  mov eax, 0x420990
00007957b0dce790  movups xmm1, [r13+rax*1]
00007957b0dce796  mov eax, 0x420A00
00007957b0dce79b  movups xmm15, [r13+rax*1]
00007957b0dce7a1  mov eax, 0x430CC0
00007957b0dce7a6  movups [r13+rax*1], xmm13
00007957b0dce7ac  mov eax, 0x430CD0
00007957b0dce7b1  movups [r13+rax*1], xmm1
00007957b0dce7b7  mov eax, 0x420A10
00007957b0dce7bc  movups xmm1, [r13+rax*1]
00007957b0dce7c2  mov eax, 0x4209E0
00007957b0dce7c7  movups xmm14, [r13+rax*1]
00007957b0dce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007957b0dce7d5  mov eax, 0x430CE0
00007957b0dce7da  movups [r13+rax*1], xmm15
00007957b0dce7e0  mov eax, 0x430CF0
00007957b0dce7e5  movups [r13+rax*1], xmm1
00007957b0dce7eb  mov eax, 0x420A80
00007957b0dce7f0  movups xmm1, [r13+rax*1]
00007957b0dce7f6  mov eax, 0x420A90
00007957b0dce7fb  movups xmm15, [r13+rax*1]
00007957b0dce801  movaps [r15+0x150], xmm15
00007957b0dce809  mov qword ptr [r15+0xA0], 0x3E8
00007957b0dce814  mov eax, 0x430D00
00007957b0dce819  movups [r13+rax*1], xmm14
00007957b0dce81f  mov eax, 0x430D10
00007957b0dce824  movups [r13+rax*1], xmm1
00007957b0dce82a  mov eax, 0x420A70
00007957b0dce82f  movups xmm1, [r13+rax*1]
00007957b0dce835  mov eax, 0x420A20
00007957b0dce83a  movups xmm14, [r13+rax*1]
00007957b0dce840  movaps [r15+0x140], xmm14
00007957b0dce848  lea rax, [r14+0x150]
00007957b0dce84f  movq xmm13, qword ptr [r15+0x200]
00007957b0dce858  movq xmm12, qword ptr [r15+0x1F0]
00007957b0dce861  movq r12, xmm13
00007957b0dce866  movq r11, xmm12
00007957b0dce86b  mov [r13+rax*1], r12
00007957b0dce870  lea rax, [r14+0x158]
00007957b0dce877  mov [r13+rax*1], r11
00007957b0dce87c  mov eax, 0x430D20
00007957b0dce881  movups [r13+rax*1], xmm15
00007957b0dce887  mov eax, 0x430D30
00007957b0dce88c  movups [r13+rax*1], xmm1
00007957b0dce892  mov eax, 0x420A40
00007957b0dce897  movups xmm1, [r13+rax*1]
00007957b0dce89d  mov eax, 0x420AA8
00007957b0dce8a2  mov r12, [r13+rax*1]
00007957b0dce8a7  movq xmm15, r12
00007957b0dce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007957b0dce8b4  mov eax, 0x430D40
00007957b0dce8b9  movups [r13+rax*1], xmm14
00007957b0dce8bf  mov eax, 0x430D50
00007957b0dce8c4  movups [r13+rax*1], xmm1
00007957b0dce8ca  mov eax, 0x420B10
00007957b0dce8cf  movups xmm1, [r13+rax*1]
00007957b0dce8d5  movq rax, xmm15
00007957b0dce8da  mov r12d, 0x430D80
00007957b0dce8e0  mov [r13+r12*1], rax
00007957b0dce8e5  mov eax, 0x420AF0
00007957b0dce8ea  movups xmm15, [r13+rax*1]
00007957b0dce8f0  mov eax, 0x420B00
00007957b0dce8f5  movups xmm14, [r13+rax*1]
00007957b0dce8fb  lea rax, [r14+0x130]
00007957b0dce902  movups [r13+rax*1], xmm1
00007957b0dce908  lea rax, [r14+0x160]
00007957b0dce90f  movq xmm1, qword ptr [r15+0x1E0]
00007957b0dce918  movq xmm13, qword ptr [r15+0x1D0]
00007957b0dce921  movq r12, xmm1
00007957b0dce926  movq r11, xmm13
00007957b0dce92b  mov [r13+rax*1], r12
00007957b0dce930  lea rax, [r14+0x168]
00007957b0dce937  mov [r13+rax*1], r11
00007957b0dce93c  lea rax, [r14+0x110]
00007957b0dce943  movups [r13+rax*1], xmm15
00007957b0dce949  lea rax, [r14+0x120]
00007957b0dce950  movups [r13+rax*1], xmm14
00007957b0dce956  mov eax, 0x420AB0
00007957b0dce95b  movups xmm1, [r13+rax*1]
00007957b0dce961  mov eax, 0x420AC0
00007957b0dce966  movups xmm15, [r13+rax*1]
00007957b0dce96c  movaps [r15+0x120], xmm15
00007957b0dce974  lea rax, [r14+0x170]
00007957b0dce97b  movq xmm14, qword ptr [r15+0x1C0]
00007957b0dce984  movq xmm13, qword ptr [r15+0x1B0]
00007957b0dce98d  movq r12, xmm14
00007957b0dce992  movq r11, xmm13
00007957b0dce997  mov [r13+rax*1], r12
00007957b0dce99c  lea rax, [r14+0x178]
00007957b0dce9a3  mov [r13+rax*1], r11
00007957b0dce9a8  lea rax, [r14+0x180]
00007957b0dce9af  movq xmm14, qword ptr [r15+0x1A0]
00007957b0dce9b8  movq xmm13, qword ptr [r15+0x190]
00007957b0dce9c1  movq r12, xmm14
00007957b0dce9c6  movq r11, xmm13
00007957b0dce9cb  mov [r13+rax*1], r12
00007957b0dce9d0  lea rax, [r14+0x188]
00007957b0dce9d7  mov [r13+rax*1], r11
00007957b0dce9dc  lea rax, [r14+0xD0]
00007957b0dce9e3  movups [r13+rax*1], xmm1
00007957b0dce9e9  lea rax, [r14+0xE0]
00007957b0dce9f0  movups [r13+rax*1], xmm15
00007957b0dce9f6  mov eax, 0x420AD0
00007957b0dce9fb  movups xmm1, [r13+rax*1]
00007957b0dcea01  mov eax, 0x420AE0
00007957b0dcea06  movups xmm15, [r13+rax*1]
00007957b0dcea0c  movaps [r15+0x110], xmm1
00007957b0dcea14  movaps [r15+0x130], xmm15
00007957b0dcea1c  lea rax, [r14+0x190]
00007957b0dcea23  mov r12, [r15+0xE8]
00007957b0dcea2a  mov r11, [r15+0xF0]
00007957b0dcea31  mov [r13+rax*1], r12
00007957b0dcea36  lea rax, [r14+0x198]
00007957b0dcea3d  mov [r13+rax*1], r11
00007957b0dcea42  mov eax, 0x430D88
00007957b0dcea47  mov r12d, 0x421DF8D3
00007957b0dcea4d  mov [r13+rax*1], r12d
00007957b0dcea52  lea rax, [r14+0xF0]
00007957b0dcea59  movups [r13+rax*1], xmm1
00007957b0dcea5f  lea rax, [r14+0x100]
00007957b0dcea66  movups [r13+rax*1], xmm15
00007957b0dcea6c  lea rax, [r14+0xD0]
00007957b0dcea73  mov [r15], rax
00007957b0dcea76  mov qword ptr [r15+0x08], 0x430C60
00007957b0dcea7e  mov qword ptr [r15+0x10], 0x12C
00007957b0dcea86  mov qword ptr [r15+0xF0], 0x410284
00007957b0dcea91  mov r14d, [r15+0x320]
00007957b0dcea98  mov eax, 0x410284
00007957b0dcea9d  mov rcx, 0x7957B0DD07C0
00007957b0dceaa7  mov [r15+r14*8+0x328], rax
00007957b0dceaaf  mov [r15+r14*8+0x368], rcx
00007957b0dceab7  add r14d, 0x01
00007957b0dceabb  and r14d, 0x07
00007957b0dceabf  mov [r15+0x320], r14d
00007957b0dceac6  cmp dword ptr [r15+0x318], 0x00
00007957b0dceace  jz 0x00007957B0DCED70
00007957b0dcead4  nop [rax+rax*1], ax
00007957b0dceadd  nop [rax+rax*1], eax
00007957b0dceae5  mov eax, 0x4106BC
00007957b0dceaea  mov [r15+0x100], rax
00007957b0dceaf1  jmp 0x00007957B0BFE110
00007957b0dceaf6  int3
00007957b0dceaf7  call 0x00007957B0C0BC20
00007957b0dceafc  jmp 0x00007957B0DCE6CF
00007957b0dceb01  call 0x00007957B0C0A9A0
00007957b0dceb06  jmp 0x00007957B0DCE6DB
00007957b0dceb0b  call 0x00007957B0BFF430
00007957b0dceb10  jmp 0x00007957B0DCE6E6
00007957b0dceb15  call 0x00007957B0C0E760
00007957b0dceb1a  jmp 0x00007957B0DCE6F1
00007957b0dceb1f  call 0x00007957B0C0D4E0
00007957b0dceb24  jmp 0x00007957B0DCE6FC
00007957b0dceb29  call 0x00007957B0C0C260
00007957b0dceb2e  jmp 0x00007957B0DCE707
00007957b0dceb33  call 0x00007957B0C0AFE0
00007957b0dceb38  jmp 0x00007957B0DCE71D
00007957b0dceb3d  call 0x00007957B0BFF540
00007957b0dceb42  jmp 0x00007957B0DCE728
00007957b0dceb47  call 0x00007957B0C0E880
00007957b0dceb4c  jmp 0x00007957B0DCE733
00007957b0dceb51  call 0x00007957B0C0D600
00007957b0dceb56  jmp 0x00007957B0DCE73E
00007957b0dceb5b  call 0x00007957B0C0C380
00007957b0dceb60  jmp 0x00007957B0DCE749
00007957b0dceb65  call 0x00007957B0C0D4E0
00007957b0dceb6a  jmp 0x00007957B0DCE754
00007957b0dceb6f  call 0x00007957B0C0C260
00007957b0dceb74  jmp 0x00007957B0DCE75F
00007957b0dceb79  call 0x00007957B0BFF540
00007957b0dceb7e  jmp 0x00007957B0DCE76A
00007957b0dceb83  call 0x00007957B0C0E880
00007957b0dceb88  jmp 0x00007957B0DCE775
00007957b0dceb8d  call 0x00007957B0C0B100
00007957b0dceb92  jmp 0x00007957B0DCE780
00007957b0dceb97  call 0x00007957B0C0D600
00007957b0dceb9c  jmp 0x00007957B0DCE78B
00007957b0dceba1  call 0x00007957B0BFF430
00007957b0dceba6  jmp 0x00007957B0DCE796
00007957b0dcebab  call 0x00007957B0C0E760
00007957b0dcebb0  jmp 0x00007957B0DCE7A1
00007957b0dcebb5  call 0x00007957B0C0C380
00007957b0dcebba  jmp 0x00007957B0DCE7AC
00007957b0dcebbf  call 0x00007957B0BFF540
00007957b0dcebc4  jmp 0x00007957B0DCE7B7
00007957b0dcebc9  call 0x00007957B0BFF430
00007957b0dcebce  jmp 0x00007957B0DCE7C2
00007957b0dcebd3  call 0x00007957B0C0D4E0
00007957b0dcebd8  jmp 0x00007957B0DCE7CD
00007957b0dcebdd  call 0x00007957B0C0E880
00007957b0dcebe2  jmp 0x00007957B0DCE7E0
00007957b0dcebe7  call 0x00007957B0BFF540
00007957b0dcebec  jmp 0x00007957B0DCE7EB
00007957b0dcebf1  call 0x00007957B0BFF430
00007957b0dcebf6  jmp 0x00007957B0DCE7F6
00007957b0dcebfb  call 0x00007957B0C0E760
00007957b0dcec00  jmp 0x00007957B0DCE801
00007957b0dcec05  call 0x00007957B0C0D600
00007957b0dcec0a  jmp 0x00007957B0DCE81F
00007957b0dcec0f  call 0x00007957B0BFF540
00007957b0dcec14  jmp 0x00007957B0DCE82A
00007957b0dcec19  call 0x00007957B0BFF430
00007957b0dcec1e  jmp 0x00007957B0DCE835
00007957b0dcec23  call 0x00007957B0C0D4E0
00007957b0dcec28  jmp 0x00007957B0DCE840
00007957b0dcec2d  call 0x00007957B0C0BC20
00007957b0dcec32  jmp 0x00007957B0DCE870
00007957b0dcec37  call 0x00007957B0C0A9A0
00007957b0dcec3c  jmp 0x00007957B0DCE87C
00007957b0dcec41  call 0x00007957B0C0E880
00007957b0dcec46  jmp 0x00007957B0DCE887
00007957b0dcec4b  call 0x00007957B0BFF540
00007957b0dcec50  jmp 0x00007957B0DCE892
00007957b0dcec55  call 0x00007957B0BFF430
00007957b0dcec5a  jmp 0x00007957B0DCE89D
00007957b0dcec5f  call 0x00007957B0C0B720
00007957b0dcec64  jmp 0x00007957B0DCE8A7
00007957b0dcec69  call 0x00007957B0C0D600
00007957b0dcec6e  jmp 0x00007957B0DCE8BF
00007957b0dcec73  call 0x00007957B0BFF540
00007957b0dcec78  jmp 0x00007957B0DCE8CA
00007957b0dcec7d  call 0x00007957B0BFF430
00007957b0dcec82  jmp 0x00007957B0DCE8D5
00007957b0dcec87  call 0x00007957B0CB4CB0
00007957b0dcec8c  jmp 0x00007957B0DCE8E5
00007957b0dcec91  call 0x00007957B0C0E760
00007957b0dcec96  jmp 0x00007957B0DCE8F0
00007957b0dcec9b  call 0x00007957B0C0D4E0
00007957b0dceca0  jmp 0x00007957B0DCE8FB
00007957b0dceca5  call 0x00007957B0BFF540
00007957b0dcecaa  jmp 0x00007957B0DCE908
00007957b0dcecaf  call 0x00007957B0C0BC20
00007957b0dcecb4  jmp 0x00007957B0DCE930
00007957b0dcecb9  call 0x00007957B0C0A9A0
00007957b0dcecbe  jmp 0x00007957B0DCE93C
00007957b0dcecc3  call 0x00007957B0C0E880
00007957b0dcecc8  jmp 0x00007957B0DCE949
00007957b0dceccd  call 0x00007957B0C0D600
00007957b0dcecd2  jmp 0x00007957B0DCE956
00007957b0dcecd7  call 0x00007957B0BFF430
00007957b0dcecdc  jmp 0x00007957B0DCE961
00007957b0dcece1  call 0x00007957B0C0E760
00007957b0dcece6  jmp 0x00007957B0DCE96C
00007957b0dceceb  call 0x00007957B0C0BC20
00007957b0dcecf0  jmp 0x00007957B0DCE99C
00007957b0dcecf5  call 0x00007957B0C0A9A0
00007957b0dcecfa  jmp 0x00007957B0DCE9A8
00007957b0dcecff  call 0x00007957B0C0BC20
00007957b0dced04  jmp 0x00007957B0DCE9D0
00007957b0dced09  call 0x00007957B0C0A9A0
00007957b0dced0e  jmp 0x00007957B0DCE9DC
00007957b0dced13  call 0x00007957B0BFF540
00007957b0dced18  jmp 0x00007957B0DCE9E9
00007957b0dced1d  call 0x00007957B0C0E880
00007957b0dced22  jmp 0x00007957B0DCE9F6
00007957b0dced27  call 0x00007957B0BFF430
00007957b0dced2c  jmp 0x00007957B0DCEA01
00007957b0dced31  call 0x00007957B0C0E760
00007957b0dced36  jmp 0x00007957B0DCEA0C
00007957b0dced3b  call 0x00007957B0C0BC20
00007957b0dced40  jmp 0x00007957B0DCEA36
00007957b0dced45  call 0x00007957B0C0A9A0
00007957b0dced4a  jmp 0x00007957B0DCEA42
00007957b0dced4f  call 0x00007957B0C0BAE0
00007957b0dced54  jmp 0x00007957B0DCEA52
00007957b0dced59  call 0x00007957B0BFF540
00007957b0dced5e  jmp 0x00007957B0DCEA5F
00007957b0dced63  call 0x00007957B0C0E880
00007957b0dced68  jmp 0x00007957B0DCEA6C
00007957b0dced6d  int3
00007957b0dced6e  nop
00007957b0dced70  mov rax, [r15]
00007957b0dced73  lea r14, [rax+0x20]
00007957b0dced77  mov r12, [r13+r14*1]
00007957b0dced7c  mov r14, [r15+0x10]
00007957b0dced80  lea r11, [r12+r14*1]
00007957b0dced84  mov [r15+0x40], r11
00007957b0dced88  lea r12, [rax+0x20]
00007957b0dced8c  mov [r13+r12*1], r11
00007957b0dced91  test r14, r14
00007957b0dced94  setz r14b
00007957b0dced98  movzx r14, r14b
00007957b0dced9c  mov [rsp+0x414], r14b
00007957b0dceda4  cmp byte ptr [rsp+0x414], 0x00
00007957b0dcedac  jz 0x00007957B0DCEDDE
00007957b0dcedae  cmp dword ptr [r15+0x318], 0x00
00007957b0dcedb6  mov eax, 0x410934
00007957b0dcedbb  mov [r15+0x100], rax
00007957b0dcedc2  jz 0x00007957B0BFE0A0
00007957b0dcedc8  nop [rax+rax*1], eax
00007957b0dcedcd  mov eax, 0x410934
00007957b0dcedd2  mov [r15+0x100], rax
00007957b0dcedd9  jmp 0x00007957B0BFE110
00007957b0dcedde  cmp dword ptr [r15+0x318], 0x00
00007957b0dcede6  jz 0x00007957B0DCEE30
00007957b0dcedec  nop [rax+rax*1], ax
00007957b0dcedf5  nop [rax+rax*1], eax
00007957b0dcedfd  mov eax, 0x4106CC
00007957b0dcee02  mov [r15+0x100], rax
00007957b0dcee09  jmp 0x00007957B0BFE110
00007957b0dcee0e  int3
00007957b0dcee0f  call 0x00007957B0CE27E0
00007957b0dcee14  jmp 0x00007957B0DCED7C
00007957b0dcee19  call 0x00007957B0CC0860
00007957b0dcee1e  jmp 0x00007957B0DCED91
00007957b0dcee23  int3
00007957b0dcee24  nop [rax+rax*1], ax
00007957b0dcee2d  nop [rax], eax
00007957b0dcee30  mov rax, [r15+0xF8]
00007957b0dcee37  lea r14, [rax-0x150]
00007957b0dcee3e  mov [r15+0xF8], r14
00007957b0dcee45  mov rax, [r15]
00007957b0dcee48  lea r12, [rax+0x68]
00007957b0dcee4c  mov r11, [r13+r12*1]
00007957b0dcee51  mov [r15+0x88], r11
00007957b0dcee58  lea r12, [rax+0x28]
00007957b0dcee5c  mov [r15+0x40], r12
00007957b0dcee60  mov [r15+0x48], r14
00007957b0dcee64  mov qword ptr [r15+0x50], 0x420B20
00007957b0dcee6c  lea rax, [r14+0x100]
00007957b0dcee73  mov r12, [r15+0xE8]
00007957b0dcee7a  mov r11, [r15+0xD8]
00007957b0dcee81  mov [r13+rax*1], r12
00007957b0dcee86  lea rax, [r14+0x108]
00007957b0dcee8d  mov [r13+rax*1], r11
00007957b0dcee92  lea rax, [r14+0x110]
00007957b0dcee99  mov r12, [r15+0xD0]
00007957b0dceea0  mov r11, [r15+0xC8]
00007957b0dceea7  mov [r13+rax*1], r12
00007957b0dceeac  lea rax, [r14+0x118]
00007957b0dceeb3  mov [r13+rax*1], r11
00007957b0dceeb8  lea rax, [r14+0x120]
00007957b0dceebf  mov r12, [r15+0xC0]
00007957b0dceec6  mov r11, [r15+0xB8]
00007957b0dceecd  mov [r13+rax*1], r12
00007957b0dceed2  lea rax, [r14+0x128]
00007957b0dceed9  mov [r13+rax*1], r11
00007957b0dceede  lea rax, [r14+0x130]
00007957b0dceee5  mov r12, [r15+0xB0]
00007957b0dceeec  mov r11, [r15+0xA8]
00007957b0dceef3  mov [r13+rax*1], r12
00007957b0dceef8  lea rax, [r14+0x138]
00007957b0dceeff  mov [r13+rax*1], r11
00007957b0dcef04  lea rax, [r14+0x140]
00007957b0dcef0b  mov r12, [r15+0xA0]
00007957b0dcef12  mov r11, [r15+0x98]
00007957b0dcef19  mov [r13+rax*1], r12
00007957b0dcef1e  lea rax, [r14+0x148]
00007957b0dcef25  mov [r13+rax*1], r11
00007957b0dcef2a  cmp dword ptr [r15+0x318], 0x00
00007957b0dcef32  jz 0x00007957B0DCEFD0
00007957b0dcef38  nop [rax+rax*1], ax
00007957b0dcef41  nop [rax+rax*1], eax
00007957b0dcef49  mov eax, 0x410704
00007957b0dcef4e  mov [r15+0x100], rax
00007957b0dcef55  jmp 0x00007957B0BFE110
00007957b0dcef5a  int3
00007957b0dcef5b  call 0x00007957B0CC0370
00007957b0dcef60  jmp 0x00007957B0DCEE51
00007957b0dcef65  call 0x00007957B0C0BC20
00007957b0dcef6a  jmp 0x00007957B0DCEE86
00007957b0dcef6f  call 0x00007957B0C0A9A0
00007957b0dcef74  jmp 0x00007957B0DCEE92
00007957b0dcef79  call 0x00007957B0C0BC20
00007957b0dcef7e  jmp 0x00007957B0DCEEAC
00007957b0dcef83  call 0x00007957B0C0A9A0
00007957b0dcef88  jmp 0x00007957B0DCEEB8
00007957b0dcef8d  call 0x00007957B0C0BC20
00007957b0dcef92  jmp 0x00007957B0DCEED2
00007957b0dcef97  call 0x00007957B0C0A9A0
00007957b0dcef9c  jmp 0x00007957B0DCEEDE
00007957b0dcefa1  call 0x00007957B0C0BC20
00007957b0dcefa6  jmp 0x00007957B0DCEEF8
00007957b0dcefab  call 0x00007957B0C0A9A0
00007957b0dcefb0  jmp 0x00007957B0DCEF04
00007957b0dcefb5  call 0x00007957B0C0BC20
00007957b0dcefba  jmp 0x00007957B0DCEF1E
00007957b0dcefbf  call 0x00007957B0C0A9A0
00007957b0dcefc4  jmp 0x00007957B0DCEF2A
00007957b0dcefc9  int3
00007957b0dcefca  nop [rax+rax*1], ax
00007957b0dcefd0  mov rax, [r15+0x08]
00007957b0dcefd4  movzx r14d, byte ptr [r13+rax*1]
00007957b0dcefda  movzx r14d, r14b
00007957b0dcefde  mov [rsp+0x10], r14d
00007957b0dcefe3  mov r14d, r14d
00007957b0dcefe6  mov [r15+0x58], r14
00007957b0dcefea  lea r14, [rax+0x01]
00007957b0dcefee  mov [r15+0x08], r14
00007957b0dceff2  mov rax, [r15+0x88]
00007957b0dceff9  lea r14, [rax+0x01]
00007957b0dceffd  mov r12, [r15]
00007957b0dcf000  lea r11, [r12+0x68]
00007957b0dcf005  mov [r13+r11*1], r14
00007957b0dcf00a  lea r14, [r12+rax*1]
00007957b0dcf00e  mov [r15+0x60], r14
00007957b0dcf012  lea rax, [r14+0x28]
00007957b0dcf016  mov r11d, [rsp+0x10]
00007957b0dcf01b  movzx r14d, r11b
00007957b0dcf01f  mov [r13+rax*1], r14b
00007957b0dcf024  lea rax, [r12+0x68]
00007957b0dcf029  mov r14, [r13+rax*1]
00007957b0dcf02e  mov [r15+0x88], r14
00007957b0dcf035  xor eax, eax
00007957b0dcf037  mov r12d, 0x40
00007957b0dcf03d  cmp r14, r12
00007957b0dcf040  cmc
00007957b0dcf041  lahf
00007957b0dcf042  seto al
00007957b0dcf045  mov [r15+0x108], eax
00007957b0dcf04c  mov eax, [r15+0x108]
00007957b0dcf053  sahf
00007957b0dcf054  jnz 0x00007957B0DCF086
00007957b0dcf056  cmp dword ptr [r15+0x318], 0x00
00007957b0dcf05e  jz 0x00007957B0DCF170
00007957b0dcf064  nop [rax+rax*1], ax
00007957b0dcf06d  nop [rax+rax*1], eax
00007957b0dcf075  mov eax, 0x410724
00007957b0dcf07a  mov [r15+0x100], rax
00007957b0dcf081  jmp 0x00007957B0BFE110
00007957b0dcf086  cmp dword ptr [r15+0x318], 0x00
00007957b0dcf08e  jz 0x00007957B0DCF0E0
00007957b0dcf094  nop [rax+rax*1], ax
00007957b0dcf09d  nop [rax+rax*1], eax
00007957b0dcf0a5  mov eax, 0x4106FC
00007957b0dcf0aa  mov [r15+0x100], rax
00007957b0dcf0b1  jmp 0x00007957B0BFE110
00007957b0dcf0b6  int3
00007957b0dcf0b7  call 0x00007957B0C0D860
00007957b0dcf0bc  jmp 0x00007957B0DCEFDA
00007957b0dcf0c1  call 0x00007957B0CB36E0
00007957b0dcf0c6  jmp 0x00007957B0DCF00A
00007957b0dcf0cb  call 0x00007957B0C0DD60
00007957b0dcf0d0  jmp 0x00007957B0DCF024
00007957b0dcf0d5  call 0x00007957B0C0DC20
00007957b0dcf0da  jmp 0x00007957B0DCF02E
00007957b0dcf0df  int3
00007957b0dcf0e0  mov rax, [r15+0x10]
00007957b0dcf0e4  lea r14, [rax-0x01]
00007957b0dcf0e8  mov [r15+0x10], r14
00007957b0dcf0ec  test r14, r14
00007957b0dcf0ef  setz r14b
00007957b0dcf0f3  movzx r14, r14b
00007957b0dcf0f7  mov [rsp+0x414], r14b
00007957b0dcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007957b0dcf107  jz 0x00007957B0DCF139
00007957b0dcf109  cmp dword ptr [r15+0x318], 0x00
00007957b0dcf111  jz 0x00007957B0DD0670
00007957b0dcf117  nop [rax+rax*1], ax
00007957b0dcf120  nop [rax+rax*1], eax
00007957b0dcf128  mov eax, 0x41091C
00007957b0dcf12d  mov [r15+0x100], rax
00007957b0dcf134  jmp 0x00007957B0BFE110
00007957b0dcf139  cmp dword ptr [r15+0x318], 0x00
00007957b0dcf141  jz 0x00007957B0DCEFD0
00007957b0dcf147  nop [rax+rax*1], ax
00007957b0dcf150  nop [rax+rax*1], eax
00007957b0dcf158  mov eax, 0x410704
00007957b0dcf15d  mov [r15+0x100], rax
00007957b0dcf164  jmp 0x00007957B0BFE110
00007957b0dcf169  int3
00007957b0dcf16a  int3
00007957b0dcf16b  nop [rax+rax*1], eax
00007957b0dcf170  mov rax, [r15+0x40]
00007957b0dcf174  movzx r14d, byte ptr [r13+rax*1]
00007957b0dcf17a  movaps xmm1, [r15+0x110]
00007957b0dcf182  pinsrb xmm1, r14d, 0x00
00007957b0dcf189  lea r14, [rax+0x01]
00007957b0dcf18d  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf193  movaps xmm15, [r15+0x120]
00007957b0dcf19b  pinsrb xmm15, r12d, 0x00
00007957b0dcf1a2  lea r14, [rax+0x02]
00007957b0dcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf1ac  movaps xmm14, [r15+0x130]
00007957b0dcf1b4  pinsrb xmm14, r12d, 0x00
00007957b0dcf1bb  lea r14, [rax+0x03]
00007957b0dcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf1c5  movaps xmm13, [r15+0x140]
00007957b0dcf1cd  pinsrb xmm13, r12d, 0x00
00007957b0dcf1d4  lea r14, [rax+0x04]
00007957b0dcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf1de  pinsrb xmm1, r12d, 0x01
00007957b0dcf1e5  lea r14, [rax+0x05]
00007957b0dcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf1ef  pinsrb xmm15, r12d, 0x01
00007957b0dcf1f6  lea r14, [rax+0x06]
00007957b0dcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf200  pinsrb xmm14, r12d, 0x01
00007957b0dcf207  lea r14, [rax+0x07]
00007957b0dcf20b  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf211  pinsrb xmm13, r12d, 0x01
00007957b0dcf218  lea r14, [rax+0x08]
00007957b0dcf21c  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf222  pinsrb xmm1, r12d, 0x02
00007957b0dcf229  lea r14, [rax+0x09]
00007957b0dcf22d  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf233  pinsrb xmm15, r12d, 0x02
00007957b0dcf23a  lea r14, [rax+0x0A]
00007957b0dcf23e  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf244  pinsrb xmm14, r12d, 0x02
00007957b0dcf24b  lea r14, [rax+0x0B]
00007957b0dcf24f  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf255  pinsrb xmm13, r12d, 0x02
00007957b0dcf25c  lea r14, [rax+0x0C]
00007957b0dcf260  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf266  pinsrb xmm1, r12d, 0x03
00007957b0dcf26d  lea r14, [rax+0x0D]
00007957b0dcf271  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf277  pinsrb xmm15, r12d, 0x03
00007957b0dcf27e  lea r14, [rax+0x0E]
00007957b0dcf282  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf288  pinsrb xmm14, r12d, 0x03
00007957b0dcf28f  lea r14, [rax+0x0F]
00007957b0dcf293  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf299  pinsrb xmm13, r12d, 0x03
00007957b0dcf2a0  lea r14, [rax+0x10]
00007957b0dcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf2aa  pinsrb xmm1, r12d, 0x04
00007957b0dcf2b1  lea r14, [rax+0x11]
00007957b0dcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf2bb  pinsrb xmm15, r12d, 0x04
00007957b0dcf2c2  lea r14, [rax+0x12]
00007957b0dcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf2cc  pinsrb xmm14, r12d, 0x04
00007957b0dcf2d3  lea r14, [rax+0x13]
00007957b0dcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf2dd  pinsrb xmm13, r12d, 0x04
00007957b0dcf2e4  lea r14, [rax+0x14]
00007957b0dcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf2ee  pinsrb xmm1, r12d, 0x05
00007957b0dcf2f5  lea r14, [rax+0x15]
00007957b0dcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf2ff  pinsrb xmm15, r12d, 0x05
00007957b0dcf306  lea r14, [rax+0x16]
00007957b0dcf30a  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf310  pinsrb xmm14, r12d, 0x05
00007957b0dcf317  lea r14, [rax+0x17]
00007957b0dcf31b  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf321  pinsrb xmm13, r12d, 0x05
00007957b0dcf328  lea r14, [rax+0x18]
00007957b0dcf32c  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf332  pinsrb xmm1, r12d, 0x06
00007957b0dcf339  lea r14, [rax+0x19]
00007957b0dcf33d  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf343  pinsrb xmm15, r12d, 0x06
00007957b0dcf34a  lea r14, [rax+0x1A]
00007957b0dcf34e  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf354  pinsrb xmm14, r12d, 0x06
00007957b0dcf35b  lea r14, [rax+0x1B]
00007957b0dcf35f  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf365  pinsrb xmm13, r12d, 0x06
00007957b0dcf36c  lea r14, [rax+0x1C]
00007957b0dcf370  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf376  pinsrb xmm1, r12d, 0x07
00007957b0dcf37d  lea r14, [rax+0x1D]
00007957b0dcf381  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf387  pinsrb xmm15, r12d, 0x07
00007957b0dcf38e  lea r14, [rax+0x1E]
00007957b0dcf392  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf398  pinsrb xmm14, r12d, 0x07
00007957b0dcf39f  lea r14, [rax+0x1F]
00007957b0dcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf3a9  pinsrb xmm13, r12d, 0x07
00007957b0dcf3b0  lea r14, [rax+0x20]
00007957b0dcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf3ba  pinsrb xmm1, r12d, 0x08
00007957b0dcf3c1  lea r14, [rax+0x21]
00007957b0dcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf3cb  pinsrb xmm15, r12d, 0x08
00007957b0dcf3d2  lea r14, [rax+0x22]
00007957b0dcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf3dc  pinsrb xmm14, r12d, 0x08
00007957b0dcf3e3  lea r14, [rax+0x23]
00007957b0dcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf3ed  pinsrb xmm13, r12d, 0x08
00007957b0dcf3f4  lea r14, [rax+0x24]
00007957b0dcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf3fe  pinsrb xmm1, r12d, 0x09
00007957b0dcf405  lea r14, [rax+0x25]
00007957b0dcf409  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf40f  pinsrb xmm15, r12d, 0x09
00007957b0dcf416  lea r14, [rax+0x26]
00007957b0dcf41a  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf420  pinsrb xmm14, r12d, 0x09
00007957b0dcf427  lea r14, [rax+0x27]
00007957b0dcf42b  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf431  pinsrb xmm13, r12d, 0x09
00007957b0dcf438  lea r14, [rax+0x28]
00007957b0dcf43c  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf442  pinsrb xmm1, r12d, 0x0A
00007957b0dcf449  lea r14, [rax+0x29]
00007957b0dcf44d  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf453  pinsrb xmm15, r12d, 0x0A
00007957b0dcf45a  lea r14, [rax+0x2A]
00007957b0dcf45e  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf464  pinsrb xmm14, r12d, 0x0A
00007957b0dcf46b  lea r14, [rax+0x2B]
00007957b0dcf46f  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf475  pinsrb xmm13, r12d, 0x0A
00007957b0dcf47c  lea r14, [rax+0x2C]
00007957b0dcf480  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf486  pinsrb xmm1, r12d, 0x0B
00007957b0dcf48d  lea r14, [rax+0x2D]
00007957b0dcf491  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf497  pinsrb xmm15, r12d, 0x0B
00007957b0dcf49e  lea r14, [rax+0x2E]
00007957b0dcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf4a8  pinsrb xmm14, r12d, 0x0B
00007957b0dcf4af  lea r14, [rax+0x2F]
00007957b0dcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf4b9  pinsrb xmm13, r12d, 0x0B
00007957b0dcf4c0  lea r14, [rax+0x30]
00007957b0dcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf4ca  pinsrb xmm1, r12d, 0x0C
00007957b0dcf4d1  lea r14, [rax+0x31]
00007957b0dcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf4db  pinsrb xmm15, r12d, 0x0C
00007957b0dcf4e2  lea r14, [rax+0x32]
00007957b0dcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf4ec  pinsrb xmm14, r12d, 0x0C
00007957b0dcf4f3  lea r14, [rax+0x33]
00007957b0dcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf4fd  pinsrb xmm13, r12d, 0x0C
00007957b0dcf504  lea r14, [rax+0x34]
00007957b0dcf508  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf50e  pinsrb xmm1, r12d, 0x0D
00007957b0dcf515  lea r14, [rax+0x35]
00007957b0dcf519  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf51f  pinsrb xmm15, r12d, 0x0D
00007957b0dcf526  lea r14, [rax+0x36]
00007957b0dcf52a  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf530  pinsrb xmm14, r12d, 0x0D
00007957b0dcf537  lea r14, [rax+0x37]
00007957b0dcf53b  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf541  pinsrb xmm13, r12d, 0x0D
00007957b0dcf548  lea r14, [rax+0x38]
00007957b0dcf54c  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf552  pinsrb xmm1, r12d, 0x0E
00007957b0dcf559  lea r14, [rax+0x39]
00007957b0dcf55d  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf563  pinsrb xmm15, r12d, 0x0E
00007957b0dcf56a  lea r14, [rax+0x3A]
00007957b0dcf56e  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf574  pinsrb xmm14, r12d, 0x0E
00007957b0dcf57b  lea r14, [rax+0x3B]
00007957b0dcf57f  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf585  pinsrb xmm13, r12d, 0x0E
00007957b0dcf58c  lea r14, [rax+0x3C]
00007957b0dcf590  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf596  pinsrb xmm1, r12d, 0x0F
00007957b0dcf59d  movaps [r15+0x110], xmm1
00007957b0dcf5a5  lea r14, [rax+0x3D]
00007957b0dcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf5af  pinsrb xmm15, r12d, 0x0F
00007957b0dcf5b6  movaps [r15+0x120], xmm15
00007957b0dcf5be  lea r14, [rax+0x3E]
00007957b0dcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007957b0dcf5c8  pinsrb xmm14, r12d, 0x0F
00007957b0dcf5cf  movaps [r15+0x130], xmm14
00007957b0dcf5d7  lea r14, [rax+0x3F]
00007957b0dcf5db  movzx eax, byte ptr [r13+r14*1]
00007957b0dcf5e1  pinsrb xmm13, eax, 0x0F
00007957b0dcf5e8  movaps [r15+0x140], xmm13
00007957b0dcf5f0  movq xmm1, qword ptr [r15+0x120]
00007957b0dcf5f9  pmovzxbw xmm1, xmm1
00007957b0dcf5fe  psllw xmm1, 0x00
00007957b0dcf603  movaps [r15+0x150], xmm1
00007957b0dcf60b  movq xmm1, qword ptr [r15+0x130]
00007957b0dcf614  pmovzxbw xmm1, xmm1
00007957b0dcf619  psllw xmm1, 0x00
00007957b0dcf61e  movaps [r15+0x160], xmm1
00007957b0dcf626  movq xmm1, qword ptr [r15+0x110]
00007957b0dcf62f  pmovzxbw xmm1, xmm1
00007957b0dcf634  psllw xmm1, 0x00
00007957b0dcf639  movaps [r15+0x170], xmm1
00007957b0dcf641  movaps xmm15, [r15+0x110]
00007957b0dcf649  pextrq rax, xmm15, 0x01
00007957b0dcf650  movq xmm15, rax
00007957b0dcf655  pmovzxbw xmm15, xmm15
00007957b0dcf65b  psllw xmm15, 0x00
00007957b0dcf661  movaps [r15+0x180], xmm15
00007957b0dcf669  movaps xmm14, [r15+0x120]
00007957b0dcf671  pextrq rax, xmm14, 0x01
00007957b0dcf678  movq xmm14, rax
00007957b0dcf67d  pmovzxbw xmm14, xmm14
00007957b0dcf683  psllw xmm14, 0x00
00007957b0dcf689  movaps [r15+0x210], xmm14
00007957b0dcf691  movaps xmm13, [r15+0x130]
00007957b0dcf699  pextrq rax, xmm13, 0x01
00007957b0dcf6a0  movq xmm13, rax
00007957b0dcf6a5  pmovzxbw xmm13, xmm13
00007957b0dcf6ab  psllw xmm13, 0x00
00007957b0dcf6b1  movaps [r15+0x220], xmm13
00007957b0dcf6b9  movq xmm12, qword ptr [r15+0x140]
00007957b0dcf6c2  pmovzxbw xmm12, xmm12
00007957b0dcf6c8  psllw xmm12, 0x00
00007957b0dcf6ce  movaps [r15+0x250], xmm12
00007957b0dcf6d6  movaps xmm12, [r15+0x140]
00007957b0dcf6de  pextrq rax, xmm12, 0x01
00007957b0dcf6e5  movq xmm12, rax
00007957b0dcf6ea  pmovzxbw xmm12, xmm12
00007957b0dcf6f0  psllw xmm12, 0x00
00007957b0dcf6f6  movaps [r15+0x110], xmm12
00007957b0dcf6fe  movq xmm11, qword ptr [r15+0x150]
00007957b0dcf707  pmovzxwd xmm11, xmm11
00007957b0dcf70d  pslld xmm11, 0x10
00007957b0dcf713  movq xmm10, qword ptr [r15+0x160]
00007957b0dcf71c  pmovzxwd xmm10, xmm10
00007957b0dcf722  pslld xmm10, 0x08
00007957b0dcf728  pextrq rax, xmm1, 0x01
00007957b0dcf72f  movq xmm1, rax
00007957b0dcf734  pmovzxwd xmm1, xmm1
00007957b0dcf739  pslld xmm1, 0x00
00007957b0dcf73e  movaps [r15+0x260], xmm1
00007957b0dcf746  pextrq rax, xmm15, 0x01
00007957b0dcf74d  movq xmm15, rax
00007957b0dcf752  pmovzxwd xmm15, xmm15
00007957b0dcf758  pslld xmm15, 0x00
00007957b0dcf75e  movaps [r15+0x270], xmm15
00007957b0dcf766  movq xmm9, qword ptr [r15+0x170]
00007957b0dcf76f  pmovzxwd xmm9, xmm9
00007957b0dcf775  pslld xmm9, 0x00
00007957b0dcf77b  pextrq rax, xmm14, 0x01
00007957b0dcf782  movq xmm14, rax
00007957b0dcf787  pmovzxwd xmm14, xmm14
00007957b0dcf78d  pslld xmm14, 0x10
00007957b0dcf793  movaps [r15+0x280], xmm14
00007957b0dcf79b  movq xmm8, qword ptr [r15+0x180]
00007957b0dcf7a4  pmovzxwd xmm8, xmm8
00007957b0dcf7aa  pslld xmm8, 0x00
00007957b0dcf7b0  movq xmm7, qword ptr [r15+0x210]
00007957b0dcf7b9  pmovzxwd xmm7, xmm7
00007957b0dcf7be  pslld xmm7, 0x10
00007957b0dcf7c3  movaps xmm6, [r15+0x150]
00007957b0dcf7cb  pextrq rax, xmm6, 0x01
00007957b0dcf7d2  movq xmm6, rax
00007957b0dcf7d7  pmovzxwd xmm6, xmm6
00007957b0dcf7dc  pslld xmm6, 0x10
00007957b0dcf7e1  por xmm11, xmm10
00007957b0dcf7e6  movaps [r15+0x230], xmm11
00007957b0dcf7ee  pextrq rax, xmm13, 0x01
00007957b0dcf7f5  movq xmm13, rax
00007957b0dcf7fa  pmovzxwd xmm13, xmm13
00007957b0dcf800  pslld xmm13, 0x08
00007957b0dcf806  movaps [r15+0x240], xmm13
00007957b0dcf80e  movq xmm10, qword ptr [r15+0x220]
00007957b0dcf817  pmovzxwd xmm10, xmm10
00007957b0dcf81d  pslld xmm10, 0x08
00007957b0dcf823  movaps xmm5, [r15+0x160]
00007957b0dcf82b  pextrq rax, xmm5, 0x01
00007957b0dcf832  movq xmm5, rax
00007957b0dcf837  pmovzxwd xmm5, xmm5
00007957b0dcf83c  pslld xmm5, 0x08
00007957b0dcf841  pslld xmm9, 0x18
00007957b0dcf847  pslld xmm15, 0x18
00007957b0dcf84d  pslld xmm8, 0x18
00007957b0dcf853  movq xmm4, qword ptr [r15+0x250]
00007957b0dcf85c  pmovzxwd xmm4, xmm4
00007957b0dcf861  pslld xmm4, 0x00
00007957b0dcf866  por xmm14, xmm13
00007957b0dcf86b  por xmm7, xmm10
00007957b0dcf870  movaps [r15+0x210], xmm7
00007957b0dcf878  pslld xmm1, 0x18
00007957b0dcf87d  movaps [r15+0x220], xmm1
00007957b0dcf885  por xmm6, xmm5
00007957b0dcf889  por xmm11, xmm9
00007957b0dcf88e  movaps [r15+0x160], xmm11
00007957b0dcf896  pextrq rax, xmm12, 0x01
00007957b0dcf89d  movq xmm13, rax
00007957b0dcf8a2  pmovzxwd xmm13, xmm13
00007957b0dcf8a8  pslld xmm13, 0x00
00007957b0dcf8ae  movaps [r15+0x170], xmm13
00007957b0dcf8b6  movq xmm12, qword ptr [r15+0x110]
00007957b0dcf8bf  pmovzxwd xmm12, xmm12
00007957b0dcf8c5  pslld xmm12, 0x00
00007957b0dcf8cb  por xmm14, xmm15
00007957b0dcf8d0  por xmm7, xmm8
00007957b0dcf8d5  movaps xmm15, [r15+0x250]
00007957b0dcf8dd  pextrq rax, xmm15, 0x01
00007957b0dcf8e4  movq xmm15, rax
00007957b0dcf8e9  pmovzxwd xmm15, xmm15
00007957b0dcf8ef  pslld xmm15, 0x00
00007957b0dcf8f5  movaps [r15+0x180], xmm15
00007957b0dcf8fd  por xmm6, xmm1
00007957b0dcf901  movaps [r15+0x150], xmm6
00007957b0dcf909  por xmm11, xmm4
00007957b0dcf90e  movaps [r15+0x140], xmm11
00007957b0dcf916  por xmm7, xmm12
00007957b0dcf91b  movaps [r15+0x110], xmm7
00007957b0dcf923  por xmm14, xmm13
00007957b0dcf928  movaps [r15+0x120], xmm14
00007957b0dcf930  por xmm6, xmm15
00007957b0dcf935  movaps [r15+0x130], xmm6
00007957b0dcf93d  mov rax, [r15+0xF8]
00007957b0dcf944  lea r14, [rax+0x20]
00007957b0dcf948  movups [r13+r14*1], xmm7
00007957b0dcf94e  lea r14, [rax+0x30]
00007957b0dcf952  movups [r13+r14*1], xmm14
00007957b0dcf958  movups [r13+rax*1], xmm11
00007957b0dcf95e  lea r14, [rax+0x10]
00007957b0dcf962  movups [r13+r14*1], xmm6
00007957b0dcf968  mov r14d, [r13+rax*1]
00007957b0dcf96d  mov rax, [r15+0x48]
00007957b0dcf971  mov [r15+0x68], rax
00007957b0dcf975  mov qword ptr [r15+0x58], 0x04
00007957b0dcf97d  lea r12, [rax+0x04]
00007957b0dcf981  mov r11d, [r13+r12*1]
00007957b0dcf986  mov [rsp+0x10], r11d
00007957b0dcf98b  mov r11d, r11d
00007957b0dcf98e  mov [r15+0x70], r11
00007957b0dcf992  lea r12, [rax+0x38]
00007957b0dcf996  mov r11d, [r13+r12*1]
00007957b0dcf99b  lea r12, [rax+0x24]
00007957b0dcf99f  mov r10d, [r13+r12*1]
00007957b0dcf9a4  mov [rsp+0x20], r10d
00007957b0dcf9a9  mov r10d, r10d
00007957b0dcf9ac  mov [r15+0x90], r10
00007957b0dcf9b3  mov [rsp+0x30], rax
00007957b0dcf9b8  xor eax, eax
00007957b0dcf9ba  mov r12d, 0x04
00007957b0dcf9c0  mov r10d, 0xC0
00007957b0dcf9c6  cmp r12, r10
00007957b0dcf9c9  cmc
00007957b0dcf9ca  lahf
00007957b0dcf9cb  seto al
00007957b0dcf9ce  mov [r15+0x108], eax
00007957b0dcf9d5  mov eax, [rsp+0x10]
00007957b0dcf9d9  mov r12d, [rsp+0x10]
00007957b0dcf9de  shrd eax, r12d, 0x07
00007957b0dcf9e3  mov [rsp+0x10], r11d
00007957b0dcf9e8  mov r10d, [rsp+0x10]
00007957b0dcf9ed  shrd r11d, r10d, 0x11
00007957b0dcf9f2  mov r9d, [rsp+0x20]
00007957b0dcf9f7  lea r8d, [r9d+r14d*1]
00007957b0dcf9fc  rorx r14d, r12d, 0x12
00007957b0dcfa02  xor eax, r14d
00007957b0dcfa05  rorx r14d, r10d, 0x13
00007957b0dcfa0b  xor r11d, r14d
00007957b0dcfa0e  mov [rsp+0x10], r11d
00007957b0dcfa13  mov r11d, r11d
00007957b0dcfa16  mov [r15+0x88], r11
00007957b0dcfa1d  mov [rsp+0x20], r12d
00007957b0dcfa22  shr r12d, 0x03
00007957b0dcfa26  xor eax, r12d
00007957b0dcfa29  mov [rsp+0x40], eax
00007957b0dcfa2d  mov eax, eax
00007957b0dcfa2f  mov [r15+0x80], rax
00007957b0dcfa36  shr r10d, 0x0A
00007957b0dcfa3a  mov eax, [rsp+0x10]
00007957b0dcfa3e  xor eax, r10d
00007957b0dcfa41  mov [rsp+0x10], eax
00007957b0dcfa45  mov eax, eax
00007957b0dcfa47  mov [r15+0x78], rax
00007957b0dcfa4b  mov eax, [rsp+0x40]
00007957b0dcfa4f  lea r14d, [r8d+eax*1]
00007957b0dcfa54  mov eax, [rsp+0x10]
00007957b0dcfa58  lea r12d, [r14d+eax*1]
00007957b0dcfa5d  mov rax, [rsp+0x30]
00007957b0dcfa62  lea r14, [rax+0x40]
00007957b0dcfa66  mov [r13+r14*1], r12d
00007957b0dcfa6b  mov eax, [rsp+0x20]
00007957b0dcfa6f  mov eax, eax
00007957b0dcfa71  mov [r15+0x60], rax
00007957b0dcfa75  mov eax, [r15+0x108]
00007957b0dcfa7c  sahf
00007957b0dcfa7d  jnz 0x00007957B0DCFAAF
00007957b0dcfa7f  cmp dword ptr [r15+0x318], 0x00
00007957b0dcfa87  jz 0x00007957B0DCFF70
00007957b0dcfa8d  nop [rax+rax*1], ax
00007957b0dcfa96  nop [rax+rax*1], eax
00007957b0dcfa9e  mov eax, 0x410820
00007957b0dcfaa3  mov [r15+0x100], rax
00007957b0dcfaaa  jmp 0x00007957B0BFE110
00007957b0dcfaaf  cmp dword ptr [r15+0x318], 0x00
00007957b0dcfab7  jz 0x00007957B0DCFDC0
00007957b0dcfabd  nop [rax+rax*1], ax
00007957b0dcfac6  nop [rax+rax*1], eax
00007957b0dcface  mov eax, 0x4107D8
00007957b0dcfad3  mov [r15+0x100], rax
00007957b0dcfada  jmp 0x00007957B0BFE110
00007957b0dcfadf  int3
00007957b0dcfae0  call 0x00007957B0C0D860
00007957b0dcfae5  jmp 0x00007957B0DCF17A
00007957b0dcfaea  call 0x00007957B0CE2420
00007957b0dcfaef  jmp 0x00007957B0DCF193
00007957b0dcfaf4  call 0x00007957B0CE2420
00007957b0dcfaf9  jmp 0x00007957B0DCF1AC
00007957b0dcfafe  call 0x00007957B0CE2420
00007957b0dcfb03  jmp 0x00007957B0DCF1C5
00007957b0dcfb08  call 0x00007957B0CE2420
00007957b0dcfb0d  jmp 0x00007957B0DCF1DE
00007957b0dcfb12  call 0x00007957B0CE2420
00007957b0dcfb17  jmp 0x00007957B0DCF1EF
00007957b0dcfb1c  call 0x00007957B0CE2420
00007957b0dcfb21  jmp 0x00007957B0DCF200
00007957b0dcfb26  call 0x00007957B0CE2420
00007957b0dcfb2b  jmp 0x00007957B0DCF211
00007957b0dcfb30  call 0x00007957B0CE2420
00007957b0dcfb35  jmp 0x00007957B0DCF222
00007957b0dcfb3a  call 0x00007957B0CE2420
00007957b0dcfb3f  jmp 0x00007957B0DCF233
00007957b0dcfb44  call 0x00007957B0CE2420
00007957b0dcfb49  jmp 0x00007957B0DCF244
00007957b0dcfb4e  call 0x00007957B0CE2420
00007957b0dcfb53  jmp 0x00007957B0DCF255
00007957b0dcfb58  call 0x00007957B0CE2420
00007957b0dcfb5d  jmp 0x00007957B0DCF266
00007957b0dcfb62  call 0x00007957B0CE2420
00007957b0dcfb67  jmp 0x00007957B0DCF277
00007957b0dcfb6c  call 0x00007957B0CE2420
00007957b0dcfb71  jmp 0x00007957B0DCF288
00007957b0dcfb76  call 0x00007957B0CE2420
00007957b0dcfb7b  jmp 0x00007957B0DCF299
00007957b0dcfb80  call 0x00007957B0CE2420
00007957b0dcfb85  jmp 0x00007957B0DCF2AA
00007957b0dcfb8a  call 0x00007957B0CE2420
00007957b0dcfb8f  jmp 0x00007957B0DCF2BB
00007957b0dcfb94  call 0x00007957B0CE2420
00007957b0dcfb99  jmp 0x00007957B0DCF2CC
00007957b0dcfb9e  call 0x00007957B0CE2420
00007957b0dcfba3  jmp 0x00007957B0DCF2DD
00007957b0dcfba8  call 0x00007957B0CE2420
00007957b0dcfbad  jmp 0x00007957B0DCF2EE
00007957b0dcfbb2  call 0x00007957B0CE2420
00007957b0dcfbb7  jmp 0x00007957B0DCF2FF
00007957b0dcfbbc  call 0x00007957B0CE2420
00007957b0dcfbc1  jmp 0x00007957B0DCF310
00007957b0dcfbc6  call 0x00007957B0CE2420
00007957b0dcfbcb  jmp 0x00007957B0DCF321
00007957b0dcfbd0  call 0x00007957B0CE2420
00007957b0dcfbd5  jmp 0x00007957B0DCF332
00007957b0dcfbda  call 0x00007957B0CE2420
00007957b0dcfbdf  jmp 0x00007957B0DCF343
00007957b0dcfbe4  call 0x00007957B0CE2420
00007957b0dcfbe9  jmp 0x00007957B0DCF354
00007957b0dcfbee  call 0x00007957B0CE2420
00007957b0dcfbf3  jmp 0x00007957B0DCF365
00007957b0dcfbf8  call 0x00007957B0CE2420
00007957b0dcfbfd  jmp 0x00007957B0DCF376
00007957b0dcfc02  call 0x00007957B0CE2420
00007957b0dcfc07  jmp 0x00007957B0DCF387
00007957b0dcfc0c  call 0x00007957B0CE2420
00007957b0dcfc11  jmp 0x00007957B0DCF398
00007957b0dcfc16  call 0x00007957B0CE2420
00007957b0dcfc1b  jmp 0x00007957B0DCF3A9
00007957b0dcfc20  call 0x00007957B0CE2420
00007957b0dcfc25  jmp 0x00007957B0DCF3BA
00007957b0dcfc2a  call 0x00007957B0CE2420
00007957b0dcfc2f  jmp 0x00007957B0DCF3CB
00007957b0dcfc34  call 0x00007957B0CE2420
00007957b0dcfc39  jmp 0x00007957B0DCF3DC
00007957b0dcfc3e  call 0x00007957B0CE2420
00007957b0dcfc43  jmp 0x00007957B0DCF3ED
00007957b0dcfc48  call 0x00007957B0CE2420
00007957b0dcfc4d  jmp 0x00007957B0DCF3FE
00007957b0dcfc52  call 0x00007957B0CE2420
00007957b0dcfc57  jmp 0x00007957B0DCF40F
00007957b0dcfc5c  call 0x00007957B0CE2420
00007957b0dcfc61  jmp 0x00007957B0DCF420
00007957b0dcfc66  call 0x00007957B0CE2420
00007957b0dcfc6b  jmp 0x00007957B0DCF431
00007957b0dcfc70  call 0x00007957B0CE2420
00007957b0dcfc75  jmp 0x00007957B0DCF442
00007957b0dcfc7a  call 0x00007957B0CE2420
00007957b0dcfc7f  jmp 0x00007957B0DCF453
00007957b0dcfc84  call 0x00007957B0CE2420
00007957b0dcfc89  jmp 0x00007957B0DCF464
00007957b0dcfc8e  call 0x00007957B0CE2420
00007957b0dcfc93  jmp 0x00007957B0DCF475
00007957b0dcfc98  call 0x00007957B0CE2420
00007957b0dcfc9d  jmp 0x00007957B0DCF486
00007957b0dcfca2  call 0x00007957B0CE2420
00007957b0dcfca7  jmp 0x00007957B0DCF497
00007957b0dcfcac  call 0x00007957B0CE2420
00007957b0dcfcb1  jmp 0x00007957B0DCF4A8
00007957b0dcfcb6  call 0x00007957B0CE2420
00007957b0dcfcbb  jmp 0x00007957B0DCF4B9
00007957b0dcfcc0  call 0x00007957B0CE2420
00007957b0dcfcc5  jmp 0x00007957B0DCF4CA
00007957b0dcfcca  call 0x00007957B0CE2420
00007957b0dcfccf  jmp 0x00007957B0DCF4DB
00007957b0dcfcd4  call 0x00007957B0CE2420
00007957b0dcfcd9  jmp 0x00007957B0DCF4EC
00007957b0dcfcde  call 0x00007957B0CE2420
00007957b0dcfce3  jmp 0x00007957B0DCF4FD
00007957b0dcfce8  call 0x00007957B0CE2420
00007957b0dcfced  jmp 0x00007957B0DCF50E
00007957b0dcfcf2  call 0x00007957B0CE2420
00007957b0dcfcf7  jmp 0x00007957B0DCF51F
00007957b0dcfcfc  call 0x00007957B0CE2420
00007957b0dcfd01  jmp 0x00007957B0DCF530
00007957b0dcfd06  call 0x00007957B0CE2420
00007957b0dcfd0b  jmp 0x00007957B0DCF541
00007957b0dcfd10  call 0x00007957B0CE2420
00007957b0dcfd15  jmp 0x00007957B0DCF552
00007957b0dcfd1a  call 0x00007957B0CE2420
00007957b0dcfd1f  jmp 0x00007957B0DCF563
00007957b0dcfd24  call 0x00007957B0CE2420
00007957b0dcfd29  jmp 0x00007957B0DCF574
00007957b0dcfd2e  call 0x00007957B0CE2420
00007957b0dcfd33  jmp 0x00007957B0DCF585
00007957b0dcfd38  call 0x00007957B0CE2420
00007957b0dcfd3d  jmp 0x00007957B0DCF596
00007957b0dcfd42  call 0x00007957B0CE2420
00007957b0dcfd47  jmp 0x00007957B0DCF5AF
00007957b0dcfd4c  call 0x00007957B0CE2420
00007957b0dcfd51  jmp 0x00007957B0DCF5C8
00007957b0dcfd56  call 0x00007957B0CD5610
00007957b0dcfd5b  jmp 0x00007957B0DCF5E1
00007957b0dcfd60  call 0x00007957B0CDC580
00007957b0dcfd65  jmp 0x00007957B0DCF94E
00007957b0dcfd6a  call 0x00007957B0CE46C0
00007957b0dcfd6f  jmp 0x00007957B0DCF958
00007957b0dcfd74  call 0x00007957B0C09E90
00007957b0dcfd79  jmp 0x00007957B0DCF95E
00007957b0dcfd7e  call 0x00007957B0CDB310
00007957b0dcfd83  jmp 0x00007957B0DCF968
00007957b0dcfd88  call 0x00007957B0C0DAE0
00007957b0dcfd8d  jmp 0x00007957B0DCF96D
00007957b0dcfd92  call 0x00007957B0CC0230
00007957b0dcfd97  jmp 0x00007957B0DCF986
00007957b0dcfd9c  call 0x00007957B0CC0230
00007957b0dcfda1  jmp 0x00007957B0DCF99B
00007957b0dcfda6  call 0x00007957B0CBEFC0
00007957b0dcfdab  jmp 0x00007957B0DCF9A4
00007957b0dcfdb0  call 0x00007957B0CE2BA0
00007957b0dcfdb5  jmp 0x00007957B0DCFA6B
00007957b0dcfdba  int3
00007957b0dcfdbb  nop [rax+rax*1], eax
00007957b0dcfdc0  mov rax, [r15+0x48]
00007957b0dcfdc4  mov r14, [r15+0x58]
00007957b0dcfdc8  lea r12, [rax+r14*1]
00007957b0dcfdcc  mov [r15+0x68], r12
00007957b0dcfdd0  lea rax, [r14+0x04]
00007957b0dcfdd4  mov [r15+0x58], rax
00007957b0dcfdd8  lea r14, [r12+0x04]
00007957b0dcfddd  mov r11d, [r13+r14*1]
00007957b0dcfde2  mov [rsp+0x10], r11d
00007957b0dcfde7  mov r11d, r11d
00007957b0dcfdea  mov [r15+0x70], r11
00007957b0dcfdee  lea r14, [r12+0x38]
00007957b0dcfdf3  mov r11d, [r13+r14*1]
00007957b0dcfdf8  lea r14, [r12+0x24]
00007957b0dcfdfd  mov r10d, [r13+r14*1]
00007957b0dcfe02  mov [rsp+0x20], r10d
00007957b0dcfe07  mov r10d, r10d
00007957b0dcfe0a  mov [r15+0x90], r10
00007957b0dcfe11  mov [rsp+0x30], rax
00007957b0dcfe16  xor eax, eax
00007957b0dcfe18  mov r14, [rsp+0x30]
00007957b0dcfe1d  mov r10d, 0xC0
00007957b0dcfe23  cmp r14, r10
00007957b0dcfe26  cmc
00007957b0dcfe27  lahf
00007957b0dcfe28  seto al
00007957b0dcfe2b  mov [r15+0x108], eax
00007957b0dcfe32  mov eax, [rsp+0x10]
00007957b0dcfe36  mov r14d, [rsp+0x10]
00007957b0dcfe3b  shrd eax, r14d, 0x07
00007957b0dcfe40  mov [rsp+0x10], r11d
00007957b0dcfe45  mov r10d, [rsp+0x10]
00007957b0dcfe4a  shrd r11d, r10d, 0x11
00007957b0dcfe4f  mov r9d, [r15+0x60]
00007957b0dcfe53  mov r8d, [rsp+0x20]
00007957b0dcfe58  lea ebp, [r8d+r9d*1]
00007957b0dcfe5d  rorx r9d, r14d, 0x12
00007957b0dcfe63  xor eax, r9d
00007957b0dcfe66  rorx r9d, r10d, 0x13
00007957b0dcfe6c  xor r11d, r9d
00007957b0dcfe6f  mov [rsp+0x10], r11d
00007957b0dcfe74  mov r11d, r11d
00007957b0dcfe77  mov [r15+0x88], r11
00007957b0dcfe7e  mov [rsp+0x20], r14d
00007957b0dcfe83  shr r14d, 0x03
00007957b0dcfe87  xor eax, r14d
00007957b0dcfe8a  mov [rsp+0x30], eax
00007957b0dcfe8e  mov eax, eax
00007957b0dcfe90  mov [r15+0x80], rax
00007957b0dcfe97  shr r10d, 0x0A
00007957b0dcfe9b  mov eax, [rsp+0x10]
00007957b0dcfe9f  xor eax, r10d
00007957b0dcfea2  mov [rsp+0x10], eax
00007957b0dcfea6  mov eax, eax
00007957b0dcfea8  mov [r15+0x78], rax
00007957b0dcfeac  mov eax, [rsp+0x30]
00007957b0dcfeb0  lea r14d, [ebp+eax*1]
00007957b0dcfeb6  mov eax, [rsp+0x10]
00007957b0dcfeba  lea r11d, [r14d+eax*1]
00007957b0dcfebf  lea rax, [r12+0x40]
00007957b0dcfec4  mov [r13+rax*1], r11d
00007957b0dcfec9  mov eax, [rsp+0x20]
00007957b0dcfecd  mov eax, eax
00007957b0dcfecf  mov [r15+0x60], rax
00007957b0dcfed3  mov eax, [r15+0x108]
00007957b0dcfeda  sahf
00007957b0dcfedb  jnz 0x00007957B0DCFF0D
00007957b0dcfedd  cmp dword ptr [r15+0x318], 0x00
00007957b0dcfee5  jz 0x00007957B0DCFF70
00007957b0dcfeeb  nop [rax+rax*1], ax
00007957b0dcfef4  nop [rax+rax*1], eax
00007957b0dcfefc  mov eax, 0x410820
00007957b0dcff01  mov [r15+0x100], rax
00007957b0dcff08  jmp 0x00007957B0BFE110
00007957b0dcff0d  cmp dword ptr [r15+0x318], 0x00
00007957b0dcff15  jz 0x00007957B0DCFDC0
00007957b0dcff1b  nop [rax+rax*1], ax
00007957b0dcff24  nop [rax+rax*1], eax
00007957b0dcff2c  mov eax, 0x4107D8
00007957b0dcff31  mov [r15+0x100], rax
00007957b0dcff38  jmp 0x00007957B0BFE110
00007957b0dcff3d  int3
00007957b0dcff3e  call 0x00007957B0CE1430
00007957b0dcff43  jmp 0x00007957B0DCFDE2
00007957b0dcff48  call 0x00007957B0CE1430
00007957b0dcff4d  jmp 0x00007957B0DCFDF8
00007957b0dcff52  call 0x00007957B0CE01C0
00007957b0dcff57  jmp 0x00007957B0DCFE02
00007957b0dcff5c  call 0x00007957B0C0A860
00007957b0dcff61  jmp 0x00007957B0DCFEC9
00007957b0dcff66  int3
00007957b0dcff67  nop [rax+rax*1], ax
00007957b0dcff70  mov rax, [r15]
00007957b0dcff73  mov r14d, [r13+rax*1]
00007957b0dcff78  lea r12, [rax+0x04]
00007957b0dcff7c  mov r11d, [r13+r12*1]
00007957b0dcff81  mov [rsp+0x10], r14d
00007957b0dcff86  mov r14d, r14d
00007957b0dcff89  mov [r15+0x78], r14
00007957b0dcff8d  mov [rsp+0x20], r11d
00007957b0dcff92  mov r11d, r11d
00007957b0dcff95  mov [r15+0x80], r11
00007957b0dcff9c  lea r14, [rax+0x08]
00007957b0dcffa0  mov r12d, [r13+r14*1]
00007957b0dcffa5  lea r14, [rax+0x0C]
00007957b0dcffa9  mov r11d, [r13+r14*1]
00007957b0dcffae  mov [rsp+0x30], r12d
00007957b0dcffb3  mov r12d, r12d
00007957b0dcffb6  mov [r15+0x70], r12
00007957b0dcffba  mov [rsp+0x40], r11d
00007957b0dcffbf  mov r11d, r11d
00007957b0dcffc2  mov [r15+0x68], r11
00007957b0dcffc6  lea r14, [rax+0x18]
00007957b0dcffca  mov r12d, [r13+r14*1]
00007957b0dcffcf  lea r14, [rax+0x1C]
00007957b0dcffd3  mov r11d, [r13+r14*1]
00007957b0dcffd8  mov [rsp+0x50], r12d
00007957b0dcffdd  mov r12d, r12d
00007957b0dcffe0  mov [r15+0x58], r12
00007957b0dcffe4  mov [rsp+0x60], r11d
00007957b0dcffe9  mov r11d, r11d
00007957b0dcffec  mov [r15+0x60], r11
00007957b0dcfff0  lea r14, [rax+0x10]
00007957b0dcfff4  mov r12d, [r13+r14*1]
00007957b0dcfff9  lea r14, [rax+0x14]
00007957b0dcfffd  mov eax, [r13+r14*1]
00007957b0dd0002  mov [rsp+0x70], r12d
00007957b0dd0007  mov r12d, r12d
00007957b0dd000a  mov [r15+0x18], r12
00007957b0dd000e  mov [rsp+0x80], eax
00007957b0dd0015  mov eax, eax
00007957b0dd0017  mov [r15+0x90], rax
00007957b0dd001e  mov eax, [rsp+0x70]
00007957b0dd0022  mov eax, eax
00007957b0dd0024  mov [r15+0x30], rax
00007957b0dd0028  mov eax, [rsp+0x50]
00007957b0dd002c  mov eax, eax
00007957b0dd002e  mov [r15+0xA0], rax
00007957b0dd0035  mov eax, [rsp+0x30]
00007957b0dd0039  mov eax, eax
00007957b0dd003b  mov [r15+0x28], rax
00007957b0dd003f  mov eax, [rsp+0x20]
00007957b0dd0043  mov eax, eax
00007957b0dd0045  mov [r15+0x98], rax
00007957b0dd004c  mov eax, [rsp+0x10]
00007957b0dd0050  mov eax, eax
00007957b0dd0052  mov [r15+0x38], rax
00007957b0dd0056  mov eax, [rsp+0x70]
00007957b0dd005a  mov r14d, [rsp+0x70]
00007957b0dd005f  shrd eax, r14d, 0x06
00007957b0dd0064  mov [rsp+0x70], r14d
00007957b0dd0069  mov r12d, [rsp+0x80]
00007957b0dd0071  and r14d, r12d
00007957b0dd0074  mov r11d, [rsp+0x10]
00007957b0dd0079  mov r10d, [rsp+0x10]
00007957b0dd007e  shrd r11d, r10d, 0x02
00007957b0dd0083  mov [rsp+0x10], r12d
00007957b0dd0088  mov r12d, r12d
00007957b0dd008b  mov [r15+0x20], r12
00007957b0dd008f  mov r12, [r15+0x50]
00007957b0dd0093  mov r9d, [r13+r12*1]
00007957b0dd0098  mov r12d, [rsp+0x50]
00007957b0dd009d  mov r8d, [rsp+0x70]
00007957b0dd00a2  andn ebp, r8d, r12d
00007957b0dd00a7  mov edi, [rsp+0x60]
00007957b0dd00ab  lea esi, [r14d+edi*1]
00007957b0dd00b0  rorx r14d, r8d, 0x0B
00007957b0dd00b6  xor eax, r14d
00007957b0dd00b9  rorx r14d, r10d, 0x0D
00007957b0dd00bf  xor r11d, r14d
00007957b0dd00c2  lea edi, [esi+ebp*1]
00007957b0dd00c6  mov r14, [r15+0x48]
00007957b0dd00ca  mov ebp, [r13+r14*1]
00007957b0dd00cf  mov r14d, [rsp+0x30]
00007957b0dd00d4  mov esi, [rsp+0x20]
00007957b0dd00d8  and r14d, esi
00007957b0dd00db  mov [rsp+0x20], r14d
00007957b0dd00e0  mov r14d, r14d
00007957b0dd00e3  mov [r15+0xD8], r14
00007957b0dd00ea  lea r14d, [edi+r9d*1]
00007957b0dd00ef  mov r9d, [rsp+0x30]
00007957b0dd00f4  xor r9d, esi
00007957b0dd00f7  rorx edi, r8d, 0x19
00007957b0dd00fd  xor eax, edi
00007957b0dd00ff  and r9d, r10d
00007957b0dd0102  rorx edi, r10d, 0x16
00007957b0dd0108  xor r11d, edi
00007957b0dd010b  mov [rsp+0x30], r11d
00007957b0dd0110  mov r11d, r11d
00007957b0dd0113  mov [r15+0xD0], r11
00007957b0dd011a  lea r11d, [r14d+ebp*1]
00007957b0dd011f  mov r10d, [rsp+0x20]
00007957b0dd0124  xor r9d, r10d
00007957b0dd0127  lea r14d, [r11d+eax*1]
00007957b0dd012c  mov qword ptr [r15+0x88], 0x04
00007957b0dd0137  mov eax, [rsp+0x30]
00007957b0dd013b  lea r11d, [r9d+eax*1]
00007957b0dd0140  mov eax, [rsp+0x40]
00007957b0dd0144  lea r10d, [r14d+eax*1]
00007957b0dd0149  mov r10d, r10d
00007957b0dd014c  mov [r15+0xB8], r10
00007957b0dd0153  xor eax, eax
00007957b0dd0155  mov r10d, 0x04
00007957b0dd015b  mov r9d, 0x100
00007957b0dd0161  cmp r10, r9
00007957b0dd0164  cmc
00007957b0dd0165  lahf
00007957b0dd0166  seto al
00007957b0dd0169  mov [r15+0x108], eax
00007957b0dd0170  lea eax, [r11d+r14d*1]
00007957b0dd0175  mov eax, eax
00007957b0dd0177  mov [r15+0xA8], rax
00007957b0dd017e  mov r12d, r12d
00007957b0dd0181  mov [r15+0xB0], r12
00007957b0dd0188  mov eax, [rsp+0x10]
00007957b0dd018c  mov eax, eax
00007957b0dd018e  mov [r15+0xC0], rax
00007957b0dd0195  mov r8d, r8d
00007957b0dd0198  mov [r15+0xC8], r8
00007957b0dd019f  mov eax, [r15+0x108]
00007957b0dd01a6  sahf
00007957b0dd01a7  jnz 0x00007957B0DD01D9
00007957b0dd01a9  cmp dword ptr [r15+0x318], 0x00
00007957b0dd01b1  jz 0x00007957B0DD04A0
00007957b0dd01b7  nop [rax+rax*1], ax
00007957b0dd01c0  nop [rax+rax*1], eax
00007957b0dd01c8  mov eax, 0x4108E0
00007957b0dd01cd  mov [r15+0x100], rax
00007957b0dd01d4  jmp 0x00007957B0BFE110
00007957b0dd01d9  cmp dword ptr [r15+0x318], 0x00
00007957b0dd01e1  jz 0x00007957B0DD0270
00007957b0dd01e7  nop [rax+rax*1], ax
00007957b0dd01f0  nop [rax+rax*1], eax
00007957b0dd01f8  mov eax, 0x410854
00007957b0dd01fd  mov [r15+0x100], rax
00007957b0dd0204  jmp 0x00007957B0BFE110
00007957b0dd0209  int3
00007957b0dd020a  call 0x00007957B0C0DAE0
00007957b0dd020f  jmp 0x00007957B0DCFF78
00007957b0dd0214  call 0x00007957B0CC0230
00007957b0dd0219  jmp 0x00007957B0DCFF81
00007957b0dd021e  call 0x00007957B0CE26A0
00007957b0dd0223  jmp 0x00007957B0DCFFA5
00007957b0dd0228  call 0x00007957B0CE1430
00007957b0dd022d  jmp 0x00007957B0DCFFAE
00007957b0dd0232  call 0x00007957B0CE26A0
00007957b0dd0237  jmp 0x00007957B0DCFFCF
00007957b0dd023c  call 0x00007957B0CE1430
00007957b0dd0241  jmp 0x00007957B0DCFFD8
00007957b0dd0246  call 0x00007957B0CE26A0
00007957b0dd024b  jmp 0x00007957B0DCFFF9
00007957b0dd0250  call 0x00007957B0CD5890
00007957b0dd0255  jmp 0x00007957B0DD0002
00007957b0dd025a  call 0x00007957B0CBDD50
00007957b0dd025f  jmp 0x00007957B0DD0098
00007957b0dd0264  call 0x00007957B0CDA580
00007957b0dd0269  jmp 0x00007957B0DD00CF
00007957b0dd026e  int3
00007957b0dd026f  nop
00007957b0dd0270  mov eax, [r15+0xB8]
00007957b0dd0277  mov [rsp+0x10], eax
00007957b0dd027b  mov eax, eax
00007957b0dd027d  mov [r15+0x30], rax
00007957b0dd0281  mov eax, [r15+0xC0]
00007957b0dd0288  mov [rsp+0x20], eax
00007957b0dd028c  mov eax, eax
00007957b0dd028e  mov [r15+0xA0], rax
00007957b0dd0295  mov eax, [r15+0x28]
00007957b0dd0299  mov r14d, [r15+0x98]
00007957b0dd02a0  mov [rsp+0x30], r14d
00007957b0dd02a5  mov r14d, r14d
00007957b0dd02a8  mov [r15+0x28], r14
00007957b0dd02ac  mov r14d, [r15+0x38]
00007957b0dd02b0  mov [rsp+0x40], r14d
00007957b0dd02b5  mov r14d, r14d
00007957b0dd02b8  mov [r15+0x98], r14
00007957b0dd02bf  mov r14d, [r15+0xA8]
00007957b0dd02c6  mov [rsp+0x50], r14d
00007957b0dd02cb  mov r14d, r14d
00007957b0dd02ce  mov [r15+0x38], r14
00007957b0dd02d2  mov r14d, [rsp+0x10]
00007957b0dd02d7  mov r12d, [rsp+0x10]
00007957b0dd02dc  shrd r14d, r12d, 0x06
00007957b0dd02e1  mov r11d, [r15+0xC8]
00007957b0dd02e8  mov [rsp+0x10], r12d
00007957b0dd02ed  and r12d, r11d
00007957b0dd02f0  mov r10d, [rsp+0x50]
00007957b0dd02f5  mov r9d, [rsp+0x50]
00007957b0dd02fa  shrd r10d, r9d, 0x02
00007957b0dd02ff  mov [rsp+0x50], r11d
00007957b0dd0304  mov r11d, r11d
00007957b0dd0307  mov [r15+0x20], r11
00007957b0dd030b  mov r11, [r15+0x88]
00007957b0dd0312  mov r8, [r15+0x50]
00007957b0dd0316  lea rbp, [r8+r11*1]
00007957b0dd031a  mov r8d, [r13+rbp*1]
00007957b0dd031f  mov ebp, [rsp+0x20]
00007957b0dd0323  mov edi, [rsp+0x10]
00007957b0dd0327  andn esi, edi, ebp
00007957b0dd032c  mov edx, [r15+0xB0]
00007957b0dd0333  lea ecx, [r12d+edx*1]
00007957b0dd0338  rorx r12d, edi, 0x0B
00007957b0dd033e  xor r14d, r12d
00007957b0dd0341  rorx r12d, r9d, 0x0D
00007957b0dd0347  xor r10d, r12d
00007957b0dd034a  lea r12d, [ecx+esi*1]
00007957b0dd034f  mov rsi, [r15+0x48]
00007957b0dd0353  lea rdx, [rsi+r11*1]
00007957b0dd0357  mov esi, [r13+rdx*1]
00007957b0dd035c  mov edx, [rsp+0x30]
00007957b0dd0360  mov ecx, [rsp+0x40]
00007957b0dd0364  and edx, ecx
00007957b0dd0366  mov [rsp+0x10], edx
00007957b0dd036a  mov edx, edx
00007957b0dd036c  mov [r15+0xD8], rdx
00007957b0dd0373  lea edx, [r12d+r8d*1]
00007957b0dd0378  mov r12d, [rsp+0x30]
00007957b0dd037d  xor r12d, ecx
00007957b0dd0380  rorx r8d, edi, 0x19
00007957b0dd0386  xor r14d, r8d
00007957b0dd0389  and r12d, r9d
00007957b0dd038c  rorx r8d, r9d, 0x16
00007957b0dd0392  xor r10d, r8d
00007957b0dd0395  mov [rsp+0x20], r10d
00007957b0dd039a  mov r10d, r10d
00007957b0dd039d  mov [r15+0xD0], r10
00007957b0dd03a4  lea r10d, [edx+esi*1]
00007957b0dd03a9  mov r9d, [rsp+0x10]
00007957b0dd03ae  xor r12d, r9d
00007957b0dd03b1  lea r9d, [r10d+r14d*1]
00007957b0dd03b6  lea r14, [r11+0x04]
00007957b0dd03ba  mov [r15+0x88], r14
00007957b0dd03c1  mov r11d, [rsp+0x20]
00007957b0dd03c6  lea r10d, [r12d+r11d*1]
00007957b0dd03cb  lea r11d, [r9d+eax*1]
00007957b0dd03d0  mov r11d, r11d
00007957b0dd03d3  mov [r15+0xB8], r11
00007957b0dd03da  xor eax, eax
00007957b0dd03dc  mov r12d, 0x100
00007957b0dd03e2  cmp r14, r12
00007957b0dd03e5  cmc
00007957b0dd03e6  lahf
00007957b0dd03e7  seto al
00007957b0dd03ea  mov [r15+0x108], eax
00007957b0dd03f1  lea eax, [r10d+r9d*1]
00007957b0dd03f6  mov eax, eax
00007957b0dd03f8  mov [r15+0xA8], rax
00007957b0dd03ff  mov ebp, ebp
00007957b0dd0401  mov [r15+0xB0], rbp
00007957b0dd0408  mov eax, [rsp+0x50]
00007957b0dd040c  mov eax, eax
00007957b0dd040e  mov [r15+0xC0], rax
00007957b0dd0415  mov edi, edi
00007957b0dd0417  mov [r15+0xC8], rdi
00007957b0dd041e  mov eax, [r15+0x108]
00007957b0dd0425  sahf
00007957b0dd0426  jnz 0x00007957B0DD0458
00007957b0dd0428  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0430  jz 0x00007957B0DD04A0
00007957b0dd0436  nop [rax+rax*1], ax
00007957b0dd043f  nop [rax+rax*1], eax
00007957b0dd0447  mov eax, 0x4108E0
00007957b0dd044c  mov [r15+0x100], rax
00007957b0dd0453  jmp 0x00007957B0BFE110
00007957b0dd0458  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0460  jz 0x00007957B0DD0270
00007957b0dd0466  nop [rax+rax*1], ax
00007957b0dd046f  nop [rax+rax*1], eax
00007957b0dd0477  mov eax, 0x410854
00007957b0dd047c  mov [r15+0x100], rax
00007957b0dd0483  jmp 0x00007957B0BFE110
00007957b0dd0488  int3
00007957b0dd0489  call 0x00007957B0C49010
00007957b0dd048e  jmp 0x00007957B0DD031F
00007957b0dd0493  call 0x00007957B0C25930
00007957b0dd0498  jmp 0x00007957B0DD035C
00007957b0dd049d  int3
00007957b0dd049e  nop
00007957b0dd04a0  mov eax, [r15+0x98]
00007957b0dd04a7  mov r14d, [r15+0x70]
00007957b0dd04ab  lea r12d, [eax+r14d*1]
00007957b0dd04b0  mov eax, [r15+0x28]
00007957b0dd04b4  mov r14d, [r15+0x68]
00007957b0dd04b8  lea r11d, [eax+r14d*1]
00007957b0dd04bd  mov qword ptr [r15+0x88], 0x00
00007957b0dd04c8  mov eax, [r15+0xA8]
00007957b0dd04cf  mov r14d, [r15+0x78]
00007957b0dd04d3  lea r10d, [eax+r14d*1]
00007957b0dd04d8  mov [rsp+0x10], r10d
00007957b0dd04dd  mov r10d, r10d
00007957b0dd04e0  mov [r15+0x78], r10
00007957b0dd04e4  mov eax, [r15+0x38]
00007957b0dd04e8  mov r14d, [r15+0x80]
00007957b0dd04ef  lea r10d, [eax+r14d*1]
00007957b0dd04f4  mov [rsp+0x20], r10d
00007957b0dd04f9  mov r10d, r10d
00007957b0dd04fc  mov [r15+0x80], r10
00007957b0dd0503  mov rax, [r15]
00007957b0dd0506  lea r14, [rax+0x08]
00007957b0dd050a  mov [r13+r14*1], r12d
00007957b0dd050f  lea r14, [rax+0x0C]
00007957b0dd0513  mov [r13+r14*1], r11d
00007957b0dd0518  mov r14d, [r15+0xB8]
00007957b0dd051f  mov r12d, [r15+0x18]
00007957b0dd0523  lea r11d, [r14d+r12d*1]
00007957b0dd0528  mov [rsp+0x30], r11d
00007957b0dd052d  mov r11d, r11d
00007957b0dd0530  mov [r15+0x68], r11
00007957b0dd0534  mov r14d, [r15+0x30]
00007957b0dd0538  mov r12d, [r15+0x90]
00007957b0dd053f  lea r11d, [r14d+r12d*1]
00007957b0dd0544  mov [rsp+0x40], r11d
00007957b0dd0549  mov r11d, r11d
00007957b0dd054c  mov [r15+0x70], r11
00007957b0dd0550  mov r14d, [r15+0x20]
00007957b0dd0554  mov r12d, [r15+0x58]
00007957b0dd0558  lea r11d, [r14d+r12d*1]
00007957b0dd055d  mov [rsp+0x50], r11d
00007957b0dd0562  mov r11d, r11d
00007957b0dd0565  mov [r15+0x58], r11
00007957b0dd0569  mov r14d, [r15+0xA0]
00007957b0dd0570  mov r12d, [r15+0x60]
00007957b0dd0574  lea r11d, [r14d+r12d*1]
00007957b0dd0579  mov [rsp+0x60], r11d
00007957b0dd057e  mov r11d, r11d
00007957b0dd0581  mov [r15+0x60], r11
00007957b0dd0585  mov r14d, [rsp+0x10]
00007957b0dd058a  mov [r13+rax*1], r14d
00007957b0dd058f  lea r14, [rax+0x04]
00007957b0dd0593  mov r12d, [rsp+0x20]
00007957b0dd0598  mov [r13+r14*1], r12d
00007957b0dd059d  lea r14, [rax+0x10]
00007957b0dd05a1  mov r12d, [rsp+0x30]
00007957b0dd05a6  mov [r13+r14*1], r12d
00007957b0dd05ab  lea r14, [rax+0x14]
00007957b0dd05af  mov r12d, [rsp+0x40]
00007957b0dd05b4  mov [r13+r14*1], r12d
00007957b0dd05b9  lea r14, [rax+0x18]
00007957b0dd05bd  mov r12d, [rsp+0x50]
00007957b0dd05c2  mov [r13+r14*1], r12d
00007957b0dd05c7  lea r14, [rax+0x1C]
00007957b0dd05cb  mov r12d, [rsp+0x60]
00007957b0dd05d0  mov [r13+r14*1], r12d
00007957b0dd05d5  lea r14, [rax+0x68]
00007957b0dd05d9  xor eax, eax
00007957b0dd05db  mov [r13+r14*1], rax
00007957b0dd05e0  cmp dword ptr [r15+0x318], 0x00
00007957b0dd05e8  jz 0x00007957B0DCF0E0
00007957b0dd05ee  nop [rax+rax*1], ax
00007957b0dd05f7  nop [rax+rax*1], eax
00007957b0dd05ff  mov eax, 0x4106FC
00007957b0dd0604  mov [r15+0x100], rax
00007957b0dd060b  jmp 0x00007957B0BFE110
00007957b0dd0610  int3
00007957b0dd0611  call 0x00007957B0CE2BA0
00007957b0dd0616  jmp 0x00007957B0DD050F
00007957b0dd061b  call 0x00007957B0CE1920
00007957b0dd0620  jmp 0x00007957B0DD0518
00007957b0dd0625  call 0x00007957B0C0DFE0
00007957b0dd062a  jmp 0x00007957B0DD058F
00007957b0dd062f  call 0x00007957B0CE2BA0
00007957b0dd0634  jmp 0x00007957B0DD059D
00007957b0dd0639  call 0x00007957B0CE2BA0
00007957b0dd063e  jmp 0x00007957B0DD05AB
00007957b0dd0643  call 0x00007957B0CE2BA0
00007957b0dd0648  jmp 0x00007957B0DD05B9
00007957b0dd064d  call 0x00007957B0CE2BA0
00007957b0dd0652  jmp 0x00007957B0DD05C7
00007957b0dd0657  call 0x00007957B0CE2BA0
00007957b0dd065c  jmp 0x00007957B0DD05D5
00007957b0dd0661  call 0x00007957B0CD5EB0
00007957b0dd0666  jmp 0x00007957B0DD05E0
00007957b0dd066b  int3
00007957b0dd066c  nop [rax], eax
00007957b0dd0670  mov rax, [r15+0xF8]
00007957b0dd0677  lea r14, [rax+0x140]
00007957b0dd067e  mov r12, [r13+r14*1]
00007957b0dd0683  lea r14, [rax+0x148]
00007957b0dd068a  mov r11, [r13+r14*1]
00007957b0dd068f  mov [r15+0xA0], r12
00007957b0dd0696  mov [r15+0x98], r11
00007957b0dd069d  lea r14, [rax+0x130]
00007957b0dd06a4  mov r12, [r13+r14*1]
00007957b0dd06a9  lea r14, [rax+0x138]
00007957b0dd06b0  mov r11, [r13+r14*1]
00007957b0dd06b5  mov [r15+0xB0], r12
00007957b0dd06bc  mov [r15+0xA8], r11
00007957b0dd06c3  lea r14, [rax+0x120]
00007957b0dd06ca  mov r12, [r13+r14*1]
00007957b0dd06cf  lea r14, [rax+0x128]
00007957b0dd06d6  mov r11, [r13+r14*1]
00007957b0dd06db  mov [r15+0xC0], r12
00007957b0dd06e2  mov [r15+0xB8], r11
00007957b0dd06e9  lea r14, [rax+0x110]
00007957b0dd06f0  mov r12, [r13+r14*1]
00007957b0dd06f5  lea r14, [rax+0x118]
00007957b0dd06fc  mov r11, [r13+r14*1]
00007957b0dd0701  mov [r15+0xD0], r12
00007957b0dd0708  mov [r15+0xC8], r11
00007957b0dd070f  lea r14, [rax+0x100]
00007957b0dd0716  mov r12, [r13+r14*1]
00007957b0dd071b  lea r14, [rax+0x108]
00007957b0dd0722  mov r11, [r13+r14*1]
00007957b0dd0727  mov [r15+0xE8], r12
00007957b0dd072e  mov [r15+0xD8], r11
00007957b0dd0735  lea r14, [rax+0x150]
00007957b0dd073c  mov [r15+0xF8], r14
00007957b0dd0743  mov rax, [r15+0xF0]
00007957b0dd074a  mov [r15+0x100], rax
00007957b0dd0751  jmp 0x00007957B0DCE5C0
00007957b0dd0756  int3
00007957b0dd0757  call 0x00007957B0CE27E0
00007957b0dd075c  jmp 0x00007957B0DD0683
00007957b0dd0761  call 0x00007957B0CE1570
00007957b0dd0766  jmp 0x00007957B0DD068F
00007957b0dd076b  call 0x00007957B0CE27E0
00007957b0dd0770  jmp 0x00007957B0DD06A9
00007957b0dd0775  call 0x00007957B0CE1570
00007957b0dd077a  jmp 0x00007957B0DD06B5
00007957b0dd077f  call 0x00007957B0CE27E0
00007957b0dd0784  jmp 0x00007957B0DD06CF
00007957b0dd0789  call 0x00007957B0CE1570
00007957b0dd078e  jmp 0x00007957B0DD06DB
00007957b0dd0793  call 0x00007957B0CE27E0
00007957b0dd0798  jmp 0x00007957B0DD06F5
00007957b0dd079d  call 0x00007957B0CE1570
00007957b0dd07a2  jmp 0x00007957B0DD0701
00007957b0dd07a7  call 0x00007957B0CE27E0
00007957b0dd07ac  jmp 0x00007957B0DD071B
00007957b0dd07b1  call 0x00007957B0CE1570
00007957b0dd07b6  jmp 0x00007957B0DD0727
00007957b0dd07bb  int3
00007957b0dd07bc  nop [rax], eax
00007957b0dd07c0  mov eax, [r15+0xA0]
00007957b0dd07c7  mov [rsp+0x10], eax
00007957b0dd07cb  xor eax, eax
00007957b0dd07cd  mov r14d, [rsp+0x10]
00007957b0dd07d2  sub r14d, 0x01
00007957b0dd07d6  cmc
00007957b0dd07d7  lahf
00007957b0dd07d8  seto al
00007957b0dd07db  mov [r15+0x108], eax
00007957b0dd07e2  mov r14d, r14d
00007957b0dd07e5  mov [r15+0xA0], r14
00007957b0dd07ec  mov eax, [r15+0x108]
00007957b0dd07f3  sahf
00007957b0dd07f4  jnz 0x00007957B0DD0826
00007957b0dd07f6  cmp dword ptr [r15+0x318], 0x00
00007957b0dd07fe  jz 0x00007957B0DD0900
00007957b0dd0804  nop [rax+rax*1], ax
00007957b0dd080d  nop [rax+rax*1], eax
00007957b0dd0815  mov eax, 0x41028C
00007957b0dd081a  mov [r15+0x100], rax
00007957b0dd0821  jmp 0x00007957B0BFE110
00007957b0dd0826  cmp dword ptr [r15+0x318], 0x00
00007957b0dd082e  jz 0x00007957B0DD0860
00007957b0dd0834  nop [rax+rax*1], ax
00007957b0dd083d  nop [rax+rax*1], eax
00007957b0dd0845  mov eax, 0x410274
00007957b0dd084a  mov [r15+0x100], rax
00007957b0dd0851  jmp 0x00007957B0BFE110
00007957b0dd0856  int3
00007957b0dd0857  int3
00007957b0dd0858  nop [rax+rax*1], eax
00007957b0dd0860  mov rax, [r15+0xF8]
00007957b0dd0867  lea r14, [rax+0xD0]
00007957b0dd086e  mov [r15], r14
00007957b0dd0871  mov rax, [r15+0x98]
00007957b0dd0878  mov [r15+0x08], rax
00007957b0dd087c  mov qword ptr [r15+0x10], 0x12C
00007957b0dd0884  mov qword ptr [r15+0xF0], 0x410284
00007957b0dd088f  mov r14d, [r15+0x320]
00007957b0dd0896  mov eax, 0x410284
00007957b0dd089b  mov rcx, 0x7957B0DD07C0
00007957b0dd08a5  mov [r15+r14*8+0x328], rax
00007957b0dd08ad  mov [r15+r14*8+0x368], rcx
00007957b0dd08b5  add r14d, 0x01
00007957b0dd08b9  and r14d, 0x07
00007957b0dd08bd  mov [r15+0x320], r14d
00007957b0dd08c4  cmp dword ptr [r15+0x318], 0x00
00007957b0dd08cc  jz 0x00007957B0DCED70
00007957b0dd08d2  nop [rax+rax*1], ax
00007957b0dd08db  nop [rax+rax*1], eax
00007957b0dd08e3  mov eax, 0x4106BC
00007957b0dd08e8  mov [r15+0x100], rax
00007957b0dd08ef  jmp 0x00007957B0BFE110
00007957b0dd08f4  int3
00007957b0dd08f5  int3
00007957b0dd08f6  nop [rax+rax*1], ax
00007957b0dd08ff  nop
00007957b0dd0900  mov rax, [r15+0xF8]
00007957b0dd0907  lea r14, [rax+0xF0]
00007957b0dd090e  mov r12, [r13+r14*1]
00007957b0dd0913  mov [r15+0x98], r12
00007957b0dd091a  mov qword ptr [r15+0x40], 0x80
00007957b0dd0922  lea r14, [rax+0xD0]
00007957b0dd0929  mov [r15], r14
00007957b0dd092c  lea r14, [rax+0x14C]
00007957b0dd0933  mov [r15+0x08], r14
00007957b0dd0937  mov qword ptr [r15+0x10], 0x01
00007957b0dd093f  lea r14, [rax+0x14C]
00007957b0dd0946  mov eax, 0x80
00007957b0dd094b  mov [r13+r14*1], al
00007957b0dd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007957b0dd095b  mov r14d, [r15+0x320]
00007957b0dd0962  mov eax, 0x4102A8
00007957b0dd0967  mov rcx, 0x7957B0DD09E0
00007957b0dd0971  mov [r15+r14*8+0x328], rax
00007957b0dd0979  mov [r15+r14*8+0x368], rcx
00007957b0dd0981  add r14d, 0x01
00007957b0dd0985  and r14d, 0x07
00007957b0dd0989  mov [r15+0x320], r14d
00007957b0dd0990  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0998  jz 0x00007957B0DCED70
00007957b0dd099e  nop [rax+rax*1], ax
00007957b0dd09a7  nop [rax+rax*1], eax
00007957b0dd09af  mov eax, 0x4106BC
00007957b0dd09b4  mov [r15+0x100], rax
00007957b0dd09bb  jmp 0x00007957B0BFE110
00007957b0dd09c0  int3
00007957b0dd09c1  call 0x00007957B0CE27E0
00007957b0dd09c6  jmp 0x00007957B0DD0913
00007957b0dd09cb  call 0x00007957B0CD5AF0
00007957b0dd09d0  jmp 0x00007957B0DD0950
00007957b0dd09d5  int3
00007957b0dd09d6  nop [rax+rax*1], ax
00007957b0dd09df  nop
00007957b0dd09e0  mov rax, [r15+0xF8]
00007957b0dd09e7  lea r14, [rax+0x138]
00007957b0dd09ee  mov r12, [r13+r14*1]
00007957b0dd09f3  mov [r15+0x40], r12
00007957b0dd09f7  lea r14, [rax+0x148]
00007957b0dd09fe  xor eax, eax
00007957b0dd0a00  mov [r13+r14*1], al
00007957b0dd0a05  xor eax, eax
00007957b0dd0a07  mov r14d, 0x38
00007957b0dd0a0d  cmp r12, r14
00007957b0dd0a10  cmc
00007957b0dd0a11  lahf
00007957b0dd0a12  seto al
00007957b0dd0a15  mov [r15+0x108], eax
00007957b0dd0a1c  mov eax, [r15+0x108]
00007957b0dd0a23  sahf
00007957b0dd0a24  jz 0x00007957B0DD0A56
00007957b0dd0a26  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0a2e  jz 0x00007957B0DD0AA0
00007957b0dd0a34  nop [rax+rax*1], ax
00007957b0dd0a3d  nop [rax+rax*1], eax
00007957b0dd0a45  mov eax, 0x4102B8
00007957b0dd0a4a  mov [r15+0x100], rax
00007957b0dd0a51  jmp 0x00007957B0BFE110
00007957b0dd0a56  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0a5e  jz 0x00007957B0DD0BF0
00007957b0dd0a64  nop [rax+rax*1], ax
00007957b0dd0a6d  nop [rax+rax*1], eax
00007957b0dd0a75  mov eax, 0x4102D4
00007957b0dd0a7a  mov [r15+0x100], rax
00007957b0dd0a81  jmp 0x00007957B0BFE110
00007957b0dd0a86  int3
00007957b0dd0a87  call 0x00007957B0CE27E0
00007957b0dd0a8c  jmp 0x00007957B0DD09F3
00007957b0dd0a91  call 0x00007957B0CD5AF0
00007957b0dd0a96  jmp 0x00007957B0DD0A05
00007957b0dd0a9b  int3
00007957b0dd0a9c  nop [rax], eax
00007957b0dd0aa0  mov rax, [r15+0xF8]
00007957b0dd0aa7  lea r14, [rax+0xD0]
00007957b0dd0aae  mov [r15], r14
00007957b0dd0ab1  lea r14, [rax+0x148]
00007957b0dd0ab8  mov [r15+0x08], r14
00007957b0dd0abc  mov qword ptr [r15+0x10], 0x01
00007957b0dd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007957b0dd0acf  mov r14d, [r15+0x320]
00007957b0dd0ad6  mov eax, 0x4102C8
00007957b0dd0adb  mov rcx, 0x7957B0DD0B40
00007957b0dd0ae5  mov [r15+r14*8+0x328], rax
00007957b0dd0aed  mov [r15+r14*8+0x368], rcx
00007957b0dd0af5  add r14d, 0x01
00007957b0dd0af9  and r14d, 0x07
00007957b0dd0afd  mov [r15+0x320], r14d
00007957b0dd0b04  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0b0c  jz 0x00007957B0DCED70
00007957b0dd0b12  nop [rax+rax*1], ax
00007957b0dd0b1b  nop [rax+rax*1], eax
00007957b0dd0b23  mov eax, 0x4106BC
00007957b0dd0b28  mov [r15+0x100], rax
00007957b0dd0b2f  jmp 0x00007957B0BFE110
00007957b0dd0b34  int3
00007957b0dd0b35  int3
00007957b0dd0b36  nop [rax+rax*1], ax
00007957b0dd0b3f  nop
00007957b0dd0b40  mov rax, [r15+0xF8]
00007957b0dd0b47  lea r14, [rax+0x138]
00007957b0dd0b4e  mov rax, [r13+r14*1]
00007957b0dd0b53  mov [r15+0x40], rax
00007957b0dd0b57  mov [rsp+0x10], rax
00007957b0dd0b5c  xor eax, eax
00007957b0dd0b5e  mov r14, [rsp+0x10]
00007957b0dd0b63  mov r12d, 0x38
00007957b0dd0b69  cmp r14, r12
00007957b0dd0b6c  cmc
00007957b0dd0b6d  lahf
00007957b0dd0b6e  seto al
00007957b0dd0b71  mov [r15+0x108], eax
00007957b0dd0b78  mov eax, [r15+0x108]
00007957b0dd0b7f  sahf
00007957b0dd0b80  jnz 0x00007957B0DD0BB2
00007957b0dd0b82  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0b8a  jz 0x00007957B0DD0BF0
00007957b0dd0b90  nop [rax+rax*1], ax
00007957b0dd0b99  nop [rax+rax*1], eax
00007957b0dd0ba1  mov eax, 0x4102D4
00007957b0dd0ba6  mov [r15+0x100], rax
00007957b0dd0bad  jmp 0x00007957B0BFE110
00007957b0dd0bb2  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0bba  jz 0x00007957B0DD0AA0
00007957b0dd0bc0  nop [rax+rax*1], ax
00007957b0dd0bc9  nop [rax+rax*1], eax
00007957b0dd0bd1  mov eax, 0x4102B8
00007957b0dd0bd6  mov [r15+0x100], rax
00007957b0dd0bdd  jmp 0x00007957B0BFE110
00007957b0dd0be2  int3
00007957b0dd0be3  call 0x00007957B0CD59C0
00007957b0dd0be8  jmp 0x00007957B0DD0B53
00007957b0dd0bed  int3
00007957b0dd0bee  nop
00007957b0dd0bf0  mov rax, [r15+0x98]
00007957b0dd0bf7  rorx r14, rax, 0x3D
00007957b0dd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007957b0dd0c01  mov rax, [r15+0xF8]
00007957b0dd0c08  lea r12, [rax+0xD0]
00007957b0dd0c0f  mov [r15], r12
00007957b0dd0c12  lea r12, [rax+0x140]
00007957b0dd0c19  mov [r15+0x08], r12
00007957b0dd0c1d  mov qword ptr [r15+0x10], 0x08
00007957b0dd0c25  bswap r14
00007957b0dd0c28  mov [r15+0x40], r14
00007957b0dd0c2c  lea r12, [rax+0x140]
00007957b0dd0c33  mov [r13+r12*1], r14
00007957b0dd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007957b0dd0c43  mov r14d, [r15+0x320]
00007957b0dd0c4a  mov eax, 0x4102F0
00007957b0dd0c4f  mov rcx, 0x7957B0DD0CC0
00007957b0dd0c59  mov [r15+r14*8+0x328], rax
00007957b0dd0c61  mov [r15+r14*8+0x368], rcx
00007957b0dd0c69  add r14d, 0x01
00007957b0dd0c6d  and r14d, 0x07
00007957b0dd0c71  mov [r15+0x320], r14d
00007957b0dd0c78  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0c80  jz 0x00007957B0DCED70
00007957b0dd0c86  nop [rax+rax*1], ax
00007957b0dd0c8f  nop [rax+rax*1], eax
00007957b0dd0c97  mov eax, 0x4106BC
00007957b0dd0c9c  mov [r15+0x100], rax
00007957b0dd0ca3  jmp 0x00007957B0BFE110
00007957b0dd0ca8  int3
00007957b0dd0ca9  call 0x00007957B0CC3FE0
00007957b0dd0cae  jmp 0x00007957B0DD0C38
00007957b0dd0cb3  int3
00007957b0dd0cb4  nop [rax+rax*1], ax
00007957b0dd0cbd  nop [rax], eax
00007957b0dd0cc0  mov rax, [r15+0xF8]
00007957b0dd0cc7  lea r14, [rax+0xD0]
00007957b0dd0cce  mov r12d, [r13+r14*1]
00007957b0dd0cd3  lea r14, [rax+0xD4]
00007957b0dd0cda  mov r11d, [r13+r14*1]
00007957b0dd0cdf  lea r14, [rax+0xD8]
00007957b0dd0ce6  mov r10d, [r13+r14*1]
00007957b0dd0ceb  lea r14, [rax+0xDC]
00007957b0dd0cf2  mov r9d, [r13+r14*1]
00007957b0dd0cf7  mov qword ptr [r15+0x48], 0x430C20
00007957b0dd0cff  mov qword ptr [r15+0xA0], 0x00
00007957b0dd0d0a  bswap r12d
00007957b0dd0d0d  bswap r11d
00007957b0dd0d10  mov qword ptr [r15+0x98], 0x430D8C
00007957b0dd0d1b  mov r14d, 0x430C20
00007957b0dd0d21  mov [r13+r14*1], r12d
00007957b0dd0d26  mov r14d, 0x430C24
00007957b0dd0d2c  mov [r13+r14*1], r11d
00007957b0dd0d31  bswap r10d
00007957b0dd0d34  bswap r9d
00007957b0dd0d37  lea r14, [rax+0xE0]
00007957b0dd0d3e  mov r12d, [r13+r14*1]
00007957b0dd0d43  lea r14, [rax+0xE4]
00007957b0dd0d4a  mov r11d, [r13+r14*1]
00007957b0dd0d4f  mov r14d, 0x430C28
00007957b0dd0d55  mov [r13+r14*1], r10d
00007957b0dd0d5a  mov r14d, 0x430C2C
00007957b0dd0d60  mov [r13+r14*1], r9d
00007957b0dd0d65  bswap r12d
00007957b0dd0d68  bswap r11d
00007957b0dd0d6b  mov [rsp+0x10], r11d
00007957b0dd0d70  mov r11d, r11d
00007957b0dd0d73  mov [r15+0x58], r11
00007957b0dd0d77  lea r14, [rax+0xE8]
00007957b0dd0d7e  mov r11d, [r13+r14*1]
00007957b0dd0d83  lea r14, [rax+0xEC]
00007957b0dd0d8a  mov eax, [r13+r14*1]
00007957b0dd0d8f  mov [rsp+0x20], eax
00007957b0dd0d93  mov eax, eax
00007957b0dd0d95  mov [r15+0x60], rax
00007957b0dd0d99  mov eax, 0x430C30
00007957b0dd0d9e  mov [r13+rax*1], r12d
00007957b0dd0da3  mov eax, 0x430C34
00007957b0dd0da8  mov r14d, [rsp+0x10]
00007957b0dd0dad  mov [r13+rax*1], r14d
00007957b0dd0db2  bswap r11d
00007957b0dd0db5  mov [rsp+0x10], r11d
00007957b0dd0dba  mov r11d, r11d
00007957b0dd0dbd  mov [r15+0x40], r11
00007957b0dd0dc1  mov eax, [rsp+0x20]
00007957b0dd0dc5  bswap eax
00007957b0dd0dc7  mov [rsp+0x20], eax
00007957b0dd0dcb  mov eax, eax
00007957b0dd0dcd  mov [r15+0x50], rax
00007957b0dd0dd1  mov eax, 0x430C38
00007957b0dd0dd6  mov r14d, [rsp+0x10]
00007957b0dd0ddb  mov [r13+rax*1], r14d
00007957b0dd0de0  mov eax, 0x430C3C
00007957b0dd0de5  mov r14d, [rsp+0x20]
00007957b0dd0dea  mov [r13+rax*1], r14d
00007957b0dd0def  mov eax, [r15+0xA0]
00007957b0dd0df6  lea r14d, [eax+0x11]
00007957b0dd0dfb  mov r14d, r14d
00007957b0dd0dfe  mov [r15], r14
00007957b0dd0e01  mov qword ptr [r15+0xF0], 0x41034C
00007957b0dd0e0c  mov r14d, [r15+0x320]
00007957b0dd0e13  mov eax, 0x41034C
00007957b0dd0e18  mov rcx, 0x7957B0DD0F90
00007957b0dd0e22  mov [r15+r14*8+0x328], rax
00007957b0dd0e2a  mov [r15+r14*8+0x368], rcx
00007957b0dd0e32  add r14d, 0x01
00007957b0dd0e36  and r14d, 0x07
00007957b0dd0e3a  mov [r15+0x320], r14d
00007957b0dd0e41  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0e49  jz 0x00007957B0DD0F20
00007957b0dd0e4f  nop [rax+rax*1], ax
00007957b0dd0e58  nop [rax+rax*1], eax
00007957b0dd0e60  mov eax, 0x410938
00007957b0dd0e65  mov [r15+0x100], rax
00007957b0dd0e6c  jmp 0x00007957B0BFE110
00007957b0dd0e71  int3
00007957b0dd0e72  call 0x00007957B0CE26A0
00007957b0dd0e77  jmp 0x00007957B0DD0CD3
00007957b0dd0e7c  call 0x00007957B0CE1430
00007957b0dd0e81  jmp 0x00007957B0DD0CDF
00007957b0dd0e86  call 0x00007957B0CE01C0
00007957b0dd0e8b  jmp 0x00007957B0DD0CEB
00007957b0dd0e90  call 0x00007957B0CDEF50
00007957b0dd0e95  jmp 0x00007957B0DD0CF7
00007957b0dd0e9a  call 0x00007957B0CE2BA0
00007957b0dd0e9f  jmp 0x00007957B0DD0D26
00007957b0dd0ea4  call 0x00007957B0CE1920
00007957b0dd0ea9  jmp 0x00007957B0DD0D31
00007957b0dd0eae  call 0x00007957B0CE26A0
00007957b0dd0eb3  jmp 0x00007957B0DD0D43
00007957b0dd0eb8  call 0x00007957B0CE1430
00007957b0dd0ebd  jmp 0x00007957B0DD0D4F
00007957b0dd0ec2  call 0x00007957B0CE06B0
00007957b0dd0ec7  jmp 0x00007957B0DD0D5A
00007957b0dd0ecc  call 0x00007957B0CDF440
00007957b0dd0ed1  jmp 0x00007957B0DD0D65
00007957b0dd0ed6  call 0x00007957B0CE1430
00007957b0dd0edb  jmp 0x00007957B0DD0D83
00007957b0dd0ee0  call 0x00007957B0CD5890
00007957b0dd0ee5  jmp 0x00007957B0DD0D8F
00007957b0dd0eea  call 0x00007957B0C0BAE0
00007957b0dd0eef  jmp 0x00007957B0DD0DA3
00007957b0dd0ef4  call 0x00007957B0C0DFE0
00007957b0dd0ef9  jmp 0x00007957B0DD0DB2
00007957b0dd0efe  call 0x00007957B0C0DFE0
00007957b0dd0f03  jmp 0x00007957B0DD0DE0
00007957b0dd0f08  call 0x00007957B0C0DFE0
00007957b0dd0f0d  jmp 0x00007957B0DD0DEF
00007957b0dd0f12  int3
00007957b0dd0f13  nop [rax+rax*1], ax
00007957b0dd0f1c  nop [rax], eax
00007957b0dd0f20  mov eax, [r15]
00007957b0dd0f23  mov [rsp+0x10], eax
00007957b0dd0f27  shr eax, 0x10
00007957b0dd0f2a  mov r14d, [rsp+0x10]
00007957b0dd0f2f  xor r14d, eax
00007957b0dd0f32  imul r14d, r14d, 0x7FEB352D
00007957b0dd0f39  mov eax, 0x846CA68B
00007957b0dd0f3e  mov eax, eax
00007957b0dd0f40  mov [r15+0x48], rax
00007957b0dd0f44  mov [rsp+0x10], r14d
00007957b0dd0f49  shr r14d, 0x0F
00007957b0dd0f4d  mov eax, [rsp+0x10]
00007957b0dd0f51  xor eax, r14d
00007957b0dd0f54  imul eax, eax, 0x846CA68B
00007957b0dd0f5a  mov [rsp+0x10], eax
00007957b0dd0f5e  mov eax, eax
00007957b0dd0f60  mov [r15+0x40], rax
00007957b0dd0f64  mov eax, [rsp+0x10]
00007957b0dd0f68  shr eax, 0x10
00007957b0dd0f6b  mov r14d, [rsp+0x10]
00007957b0dd0f70  xor r14d, eax
00007957b0dd0f73  mov r14d, r14d
00007957b0dd0f76  mov [r15], r14
00007957b0dd0f79  mov rax, [r15+0xF0]
00007957b0dd0f80  mov [r15+0x100], rax
00007957b0dd0f87  jmp 0x00007957B0DCE5C0
00007957b0dd0f8c  int3
00007957b0dd0f8d  int3
00007957b0dd0f8e  nop
00007957b0dd0f90  mov rax, [r15+0xA0]
00007957b0dd0f97  mov [rsp+0x10], rax
00007957b0dd0f9c  shl rax, 0x02
00007957b0dd0fa0  mov r14, [r15+0x98]
00007957b0dd0fa7  lea r12, [r14+rax*1]
00007957b0dd0fab  mov eax, [r15]
00007957b0dd0fae  mov [r13+r12*1], eax
00007957b0dd0fb3  mov rax, [rsp+0x10]
00007957b0dd0fb8  lea r14, [rax+0x01]
00007957b0dd0fbc  mov [r15+0xA0], r14
00007957b0dd0fc3  xor eax, eax
00007957b0dd0fc5  mov r12d, 0x400
00007957b0dd0fcb  cmp r14, r12
00007957b0dd0fce  cmc
00007957b0dd0fcf  lahf
00007957b0dd0fd0  seto al
00007957b0dd0fd3  mov [r15+0x108], eax
00007957b0dd0fda  mov eax, [r15+0x108]
00007957b0dd0fe1  sahf
00007957b0dd0fe2  jnz 0x00007957B0DD1014
00007957b0dd0fe4  cmp dword ptr [r15+0x318], 0x00
00007957b0dd0fec  jz 0x00007957B0DD10E0
00007957b0dd0ff2  nop [rax+rax*1], ax
00007957b0dd0ffb  nop [rax+rax*1], eax
00007957b0dd1003  mov eax, 0x41035C
00007957b0dd1008  mov [r15+0x100], rax
00007957b0dd100f  jmp 0x00007957B0BFE110
00007957b0dd1014  cmp dword ptr [r15+0x318], 0x00
00007957b0dd101c  jz 0x00007957B0DD1050
00007957b0dd1022  nop [rax+rax*1], ax
00007957b0dd102b  nop [rax+rax*1], eax
00007957b0dd1033  mov eax, 0x410344
00007957b0dd1038  mov [r15+0x100], rax
00007957b0dd103f  jmp 0x00007957B0BFE110
00007957b0dd1044  int3
00007957b0dd1045  call 0x00007957B0CB4B70
00007957b0dd104a  jmp 0x00007957B0DD0FB3
00007957b0dd104f  int3
00007957b0dd1050  mov eax, [r15+0xA0]
00007957b0dd1057  lea r14d, [eax+0x11]
00007957b0dd105c  mov r14d, r14d
00007957b0dd105f  mov [r15], r14
00007957b0dd1062  mov qword ptr [r15+0xF0], 0x41034C
00007957b0dd106d  mov r14d, [r15+0x320]
00007957b0dd1074  mov eax, 0x41034C
00007957b0dd1079  mov rcx, 0x7957B0DD0F90
00007957b0dd1083  mov [r15+r14*8+0x328], rax
00007957b0dd108b  mov [r15+r14*8+0x368], rcx
00007957b0dd1093  add r14d, 0x01
00007957b0dd1097  and r14d, 0x07
00007957b0dd109b  mov [r15+0x320], r14d
00007957b0dd10a2  cmp dword ptr [r15+0x318], 0x00
00007957b0dd10aa  jz 0x00007957B0DD0F20
00007957b0dd10b0  nop [rax+rax*1], ax
00007957b0dd10b9  nop [rax+rax*1], eax
00007957b0dd10c1  mov eax, 0x410938
00007957b0dd10c6  mov [r15+0x100], rax
00007957b0dd10cd  jmp 0x00007957B0BFE110
00007957b0dd10d2  int3
00007957b0dd10d3  int3
00007957b0dd10d4  nop [rax+rax*1], ax
00007957b0dd10dd  nop [rax], eax
00007957b0dd10e0  mov qword ptr [r15+0x40], 0x01
00007957b0dd10e8  cmp dword ptr [r15+0x318], 0x00
00007957b0dd10f0  jz 0x00007957B0DD1120
00007957b0dd10f6  nop [rax+rax*1], ax
00007957b0dd10ff  nop [rax+rax*1], eax
00007957b0dd1107  mov eax, 0x410378
00007957b0dd110c  mov [r15+0x100], rax
00007957b0dd1113  jmp 0x00007957B0BFE110
00007957b0dd1118  int3
00007957b0dd1119  int3
00007957b0dd111a  nop [rax+rax*1], ax
00007957b0dd1120  mov rax, [r15+0x40]
00007957b0dd1124  mov [rsp+0x10], rax
00007957b0dd1129  shl rax, 0x02
00007957b0dd112d  mov r14, [r15+0x98]
00007957b0dd1134  lea r12, [r14+rax*1]
00007957b0dd1138  mov eax, [r13+r12*1]
00007957b0dd113d  mov [rsp+0x20], eax
00007957b0dd1141  mov eax, eax
00007957b0dd1143  mov [r15+0x48], rax
00007957b0dd1147  mov rax, [rsp+0x10]
00007957b0dd114c  mov [r15+0x50], rax
00007957b0dd1150  mov eax, [r15+0x50]
00007957b0dd1154  lea r12d, [eax-0x01]
00007957b0dd1159  mov r12d, r12d
00007957b0dd115c  mov [r15+0x58], r12
00007957b0dd1160  mov rax, [r15+0x58]
00007957b0dd1164  mov r12d, eax
00007957b0dd1167  mov r12d, r12d
00007957b0dd116a  shl r12, 0x02
00007957b0dd116e  lea rax, [r14+r12*1]
00007957b0dd1172  mov r14d, [r13+rax*1]
00007957b0dd1177  mov [rsp+0x10], r14d
00007957b0dd117c  mov r14d, r14d
00007957b0dd117f  mov [r15+0x60], r14
00007957b0dd1183  xor eax, eax
00007957b0dd1185  mov r14d, [rsp+0x10]
00007957b0dd118a  mov r12d, [rsp+0x20]
00007957b0dd118f  cmp r14d, r12d
00007957b0dd1192  cmc
00007957b0dd1193  lahf
00007957b0dd1194  seto al
00007957b0dd1197  mov [r15+0x108], eax
00007957b0dd119e  mov eax, [r15+0x108]
00007957b0dd11a5  sahf
00007957b0dd11a6  cmc
00007957b0dd11a7  jbe 0x00007957B0DD11D9
00007957b0dd11a9  cmp dword ptr [r15+0x318], 0x00
00007957b0dd11b1  jz 0x00007957B0DD1220
00007957b0dd11b7  nop [rax+rax*1], ax
00007957b0dd11c0  nop [rax+rax*1], eax
00007957b0dd11c8  mov eax, 0x410390
00007957b0dd11cd  mov [r15+0x100], rax
00007957b0dd11d4  jmp 0x00007957B0BFE110
00007957b0dd11d9  cmp dword ptr [r15+0x318], 0x00
00007957b0dd11e1  jz 0x00007957B0DD14C0
00007957b0dd11e7  nop [rax+rax*1], ax
00007957b0dd11f0  nop [rax+rax*1], eax
00007957b0dd11f8  mov eax, 0x410368
00007957b0dd11fd  mov [r15+0x100], rax
00007957b0dd1204  jmp 0x00007957B0BFE110
00007957b0dd1209  int3
00007957b0dd120a  call 0x00007957B0CB4690
00007957b0dd120f  jmp 0x00007957B0DD113D
00007957b0dd1214  call 0x00007957B0C0DAE0
00007957b0dd1219  jmp 0x00007957B0DD1177
00007957b0dd121e  int3
00007957b0dd121f  nop
00007957b0dd1220  mov rax, [r15+0x50]
00007957b0dd1224  mov [rsp+0x10], rax
00007957b0dd1229  shl rax, 0x02
00007957b0dd122d  mov r14, [r15+0x98]
00007957b0dd1234  lea r12, [r14+rax*1]
00007957b0dd1238  mov eax, [r15+0x60]
00007957b0dd123c  mov [r13+r12*1], eax
00007957b0dd1241  mov rax, [rsp+0x10]
00007957b0dd1246  lea r14, [rax-0x01]
00007957b0dd124a  mov [r15+0x50], r14
00007957b0dd124e  mov rax, [r15+0x58]
00007957b0dd1252  test rax, rax
00007957b0dd1255  setz al
00007957b0dd1258  movzx rax, al
00007957b0dd125c  mov [rsp+0x414], al
00007957b0dd1263  cmp byte ptr [rsp+0x414], 0x00
00007957b0dd126b  jz 0x00007957B0DD129D
00007957b0dd126d  cmp dword ptr [r15+0x318], 0x00
00007957b0dd1275  jz 0x00007957B0DD12E0
00007957b0dd127b  nop [rax+rax*1], ax
00007957b0dd1284  nop [rax+rax*1], eax
00007957b0dd128c  mov eax, 0x41039C
00007957b0dd1291  mov [r15+0x100], rax
00007957b0dd1298  jmp 0x00007957B0BFE110
00007957b0dd129d  cmp dword ptr [r15+0x318], 0x00
00007957b0dd12a5  jz 0x00007957B0DD13E0
00007957b0dd12ab  nop [rax+rax*1], ax
00007957b0dd12b4  nop [rax+rax*1], eax
00007957b0dd12bc  mov eax, 0x410380
00007957b0dd12c1  mov [r15+0x100], rax
00007957b0dd12c8  jmp 0x00007957B0BFE110
00007957b0dd12cd  int3
00007957b0dd12ce  call 0x00007957B0CB4B70
00007957b0dd12d3  jmp 0x00007957B0DD1241
00007957b0dd12d8  int3
00007957b0dd12d9  nop [rax], eax
00007957b0dd12e0  cmp dword ptr [r15+0x318], 0x00
00007957b0dd12e8  jz 0x00007957B0DD1320
00007957b0dd12ee  nop [rax+rax*1], ax
00007957b0dd12f7  nop [rax+rax*1], eax
00007957b0dd12ff  mov eax, 0x410364
00007957b0dd1304  mov [r15+0x100], rax
00007957b0dd130b  jmp 0x00007957B0BFE110
00007957b0dd1310  int3
00007957b0dd1311  int3
00007957b0dd1312  nop [rax+rax*1], ax
00007957b0dd131b  nop [rax+rax*1], eax
00007957b0dd1320  mov qword ptr [r15+0x50], 0x00
00007957b0dd1328  mov rax, [r15+0x40]
00007957b0dd132c  lea r14, [rax+0x01]
00007957b0dd1330  mov [r15+0x40], r14
00007957b0dd1334  mov rax, [r15+0x98]
00007957b0dd133b  mov r12d, [r15+0x48]
00007957b0dd133f  mov [r13+rax*1], r12d
00007957b0dd1344  xor eax, eax
00007957b0dd1346  mov r12d, 0x400
00007957b0dd134c  cmp r14, r12
00007957b0dd134f  cmc
00007957b0dd1350  lahf
00007957b0dd1351  seto al
00007957b0dd1354  mov [r15+0x108], eax
00007957b0dd135b  mov eax, [r15+0x108]
00007957b0dd1362  sahf
00007957b0dd1363  jz 0x00007957B0DD1395
00007957b0dd1365  cmp dword ptr [r15+0x318], 0x00
00007957b0dd136d  jz 0x00007957B0DD1120
00007957b0dd1373  nop [rax+rax*1], ax
00007957b0dd137c  nop [rax+rax*1], eax
00007957b0dd1384  mov eax, 0x410378
00007957b0dd1389  mov [r15+0x100], rax
00007957b0dd1390  jmp 0x00007957B0BFE110
00007957b0dd1395  cmp dword ptr [r15+0x318], 0x00
00007957b0dd139d  jz 0x00007957B0DD1580
00007957b0dd13a3  nop [rax+rax*1], ax
00007957b0dd13ac  nop [rax+rax*1], eax
00007957b0dd13b4  mov eax, 0x4103A0
00007957b0dd13b9  mov [r15+0x100], rax
00007957b0dd13c0  jmp 0x00007957B0BFE110
00007957b0dd13c5  int3
00007957b0dd13c6  call 0x00007957B0C0BAE0
00007957b0dd13cb  jmp 0x00007957B0DD1344
00007957b0dd13d0  int3
00007957b0dd13d1  nop [rax+rax*1], ax
00007957b0dd13da  nop [rax+rax*1], ax
00007957b0dd13e0  mov eax, [r15+0x50]
00007957b0dd13e4  lea r14d, [eax-0x01]
00007957b0dd13e9  mov r14d, r14d
00007957b0dd13ec  mov [r15+0x58], r14
00007957b0dd13f0  mov rax, [r15+0x58]
00007957b0dd13f4  mov r14d, eax
00007957b0dd13f7  mov r14d, r14d
00007957b0dd13fa  shl r14, 0x02
00007957b0dd13fe  mov rax, [r15+0x98]
00007957b0dd1405  lea r12, [rax+r14*1]
00007957b0dd1409  mov eax, [r13+r12*1]
00007957b0dd140e  mov [rsp+0x10], eax
00007957b0dd1412  mov eax, eax
00007957b0dd1414  mov [r15+0x60], rax
00007957b0dd1418  mov eax, [r15+0x48]
00007957b0dd141c  mov [rsp+0x20], eax
00007957b0dd1420  xor eax, eax
00007957b0dd1422  mov r14d, [rsp+0x10]
00007957b0dd1427  mov r12d, [rsp+0x20]
00007957b0dd142c  cmp r14d, r12d
00007957b0dd142f  cmc
00007957b0dd1430  lahf
00007957b0dd1431  seto al
00007957b0dd1434  mov [r15+0x108], eax
00007957b0dd143b  mov eax, [r15+0x108]
00007957b0dd1442  sahf
00007957b0dd1443  cmc
00007957b0dd1444  jbe 0x00007957B0DD1476
00007957b0dd1446  cmp dword ptr [r15+0x318], 0x00
00007957b0dd144e  jz 0x00007957B0DD1220
00007957b0dd1454  nop [rax+rax*1], ax
00007957b0dd145d  nop [rax+rax*1], eax
00007957b0dd1465  mov eax, 0x410390
00007957b0dd146a  mov [r15+0x100], rax
00007957b0dd1471  jmp 0x00007957B0BFE110
00007957b0dd1476  cmp dword ptr [r15+0x318], 0x00
00007957b0dd147e  jz 0x00007957B0DD14C0
00007957b0dd1484  nop [rax+rax*1], ax
00007957b0dd148d  nop [rax+rax*1], eax
00007957b0dd1495  mov eax, 0x410368
00007957b0dd149a  mov [r15+0x100], rax
00007957b0dd14a1  jmp 0x00007957B0BFE110
00007957b0dd14a6  int3
00007957b0dd14a7  call 0x00007957B0CB4690
00007957b0dd14ac  jmp 0x00007957B0DD140E
00007957b0dd14b1  int3
00007957b0dd14b2  nop [rax+rax*1], ax
00007957b0dd14bb  nop [rax+rax*1], eax
00007957b0dd14c0  mov rax, [r15+0x40]
00007957b0dd14c4  lea r14, [rax+0x01]
00007957b0dd14c8  mov [r15+0x40], r14
00007957b0dd14cc  mov rax, [r15+0x50]
00007957b0dd14d0  mov r12d, eax
00007957b0dd14d3  mov r12d, r12d
00007957b0dd14d6  shl r12, 0x02
00007957b0dd14da  mov rax, [r15+0x98]
00007957b0dd14e1  lea r11, [rax+r12*1]
00007957b0dd14e5  mov eax, [r15+0x48]
00007957b0dd14e9  mov [r13+r11*1], eax
00007957b0dd14ee  xor eax, eax
00007957b0dd14f0  mov r12d, 0x400
00007957b0dd14f6  cmp r14, r12
00007957b0dd14f9  cmc
00007957b0dd14fa  lahf
00007957b0dd14fb  seto al
00007957b0dd14fe  mov [r15+0x108], eax
00007957b0dd1505  mov eax, [r15+0x108]
00007957b0dd150c  sahf
00007957b0dd150d  jz 0x00007957B0DD153F
00007957b0dd150f  cmp dword ptr [r15+0x318], 0x00
00007957b0dd1517  jz 0x00007957B0DD1120
00007957b0dd151d  nop [rax+rax*1], ax
00007957b0dd1526  nop [rax+rax*1], eax
00007957b0dd152e  mov eax, 0x410378
00007957b0dd1533  mov [r15+0x100], rax
00007957b0dd153a  jmp 0x00007957B0BFE110
00007957b0dd153f  cmp dword ptr [r15+0x318], 0x00
00007957b0dd1547  jz 0x00007957B0DD1580
00007957b0dd154d  nop [rax+rax*1], ax
00007957b0dd1556  nop [rax+rax*1], eax
00007957b0dd155e  mov eax, 0x4103A0
00007957b0dd1563  mov [r15+0x100], rax
00007957b0dd156a  jmp 0x00007957B0BFE110
00007957b0dd156f  int3
00007957b0dd1570  call 0x00007957B0CA4270
00007957b0dd1575  jmp 0x00007957B0DD14EE
00007957b0dd157a  int3
00007957b0dd157b  nop [rax+rax*1], eax
00007957b0dd1580  mov qword ptr [r15+0x40], 0x430000
00007957b0dd1588  mov eax, 0x430C40
00007957b0dd158d  mov r14, [r13+rax*1]
00007957b0dd1592  mov rax, [r15+0x98]
00007957b0dd1599  mov r12d, [r13+rax*1]
00007957b0dd159e  lea r11, [rax+0x04]
00007957b0dd15a2  mov eax, [r13+r11*1]
00007957b0dd15a7  mov r12d, r12d
00007957b0dd15aa  mov [r15+0x68], r12
00007957b0dd15ae  mov eax, eax
00007957b0dd15b0  mov [r15+0x60], rax
00007957b0dd15b4  mov rax, [r15+0x68]
00007957b0dd15b8  mov [r15+0x68], rax
00007957b0dd15bc  mov qword ptr [r15+0x58], 0x02
00007957b0dd15c4  mov [rsp+0x10], rax
00007957b0dd15c9  xor eax, eax
00007957b0dd15cb  mov r12d, 0x02
00007957b0dd15d1  mov r11d, 0x400
00007957b0dd15d7  cmp r12, r11
00007957b0dd15da  cmc
00007957b0dd15db  lahf
00007957b0dd15dc  seto al
00007957b0dd15df  mov [r15+0x108], eax
00007957b0dd15e6  mov rax, [r15+0x60]
00007957b0dd15ea  mov r12d, 0x02
00007957b0dd15f0  imul rax, r12
00007957b0dd15f4  mov [r15+0x50], rax
00007957b0dd15f8  mov rax, [rsp+0x10]
00007957b0dd15fd  lea r12, [rax+r14*1]
00007957b0dd1601  mov [r15+0x48], r12
00007957b0dd1605  mov eax, [r15+0x108]
00007957b0dd160c  sahf
00007957b0dd160d  jnz 0x00007957B0DD163F
00007957b0dd160f  cmp dword ptr [r15+0x318], 0x00
00007957b0dd1617  jz 0x00007957B0DD17B0
00007957b0dd161d  nop [rax+rax*1], ax
00007957b0dd1626  nop [rax+rax*1], eax
00007957b0dd162e  mov eax, 0x4103D0
00007957b0dd1633  mov [r15+0x100], rax
00007957b0dd163a  jmp 0x00007957B0BFE110
00007957b0dd163f  cmp dword ptr [r15+0x318], 0x00
00007957b0dd1647  jz 0x00007957B0DD1690
00007957b0dd164d  nop [rax+rax*1], ax
00007957b0dd1656  nop [rax+rax*1], eax
00007957b0dd165e  mov eax, 0x4103B0
00007957b0dd1663  mov [r15+0x100], rax
00007957b0dd166a  jmp 0x00007957B0BFE110
00007957b0dd166f  int3
00007957b0dd1670  call 0x00007957B0C0DC20
00007957b0dd1675  jmp 0x00007957B0DD1592
00007957b0dd167a  call 0x00007957B0C0B5E0
00007957b0dd167f  jmp 0x00007957B0DD159E
00007957b0dd1684  call 0x00007957B0CA3D90
00007957b0dd1689  jmp 0x00007957B0DD15A7
00007957b0dd168e  int3
00007957b0dd168f  nop
00007957b0dd1690  mov rax, [r15+0x98]
00007957b0dd1697  mov r14, [r15+0x58]
00007957b0dd169b  mov [rsp+0x10], r14
00007957b0dd16a0  shl r14, 0x02
00007957b0dd16a4  lea r12, [rax+r14*1]
00007957b0dd16a8  mov eax, [r13+r12*1]
00007957b0dd16ad  lea r14, [r12+0x04]
00007957b0dd16b2  mov r12d, [r13+r14*1]
00007957b0dd16b7  mov eax, eax
00007957b0dd16b9  mov [r15+0x68], rax
00007957b0dd16bd  mov r12d, r12d
00007957b0dd16c0  mov [r15+0x60], r12
00007957b0dd16c4  mov rax, [r15+0x68]
00007957b0dd16c8  mov [rsp+0x20], rax
00007957b0dd16cd  mov r14, [rsp+0x10]
00007957b0dd16d2  imul rax, r14
00007957b0dd16d6  mov r12, [rsp+0x20]
00007957b0dd16db  lea r11, [r12+rax*1]
00007957b0dd16df  mov [r15+0x68], r11
00007957b0dd16e3  lea rax, [r14+0x02]
00007957b0dd16e7  mov [r15+0x58], rax
00007957b0dd16eb  mov [rsp+0x10], rax
00007957b0dd16f0  xor eax, eax
00007957b0dd16f2  mov r14, [rsp+0x10]
00007957b0dd16f7  mov r12d, 0x400
00007957b0dd16fd  cmp r14, r12
00007957b0dd1700  cmc
00007957b0dd1701  lahf
00007957b0dd1702  seto al
00007957b0dd1705  mov [r15+0x108], eax
00007957b0dd170c  mov rax, [r15+0x50]
00007957b0dd1710  mov r12, [r15+0x60]
00007957b0dd1714  imul r14, r12
00007957b0dd1718  lea r12, [rax+r14*1]
00007957b0dd171c  mov [r15+0x50], r12
00007957b0dd1720  mov rax, [r15+0x48]
00007957b0dd1724  lea r14, [r11+rax*1]
00007957b0dd1728  mov [r15+0x48], r14
00007957b0dd172c  mov eax, [r15+0x108]
00007957b0dd1733  sahf
00007957b0dd1734  jnz 0x00007957B0DD1766
00007957b0dd1736  cmp dword ptr [r15+0x318], 0x00
00007957b0dd173e  jz 0x00007957B0DD17B0
00007957b0dd1744  nop [rax+rax*1], ax
00007957b0dd174d  nop [rax+rax*1], eax
00007957b0dd1755  mov eax, 0x4103D0
00007957b0dd175a  mov [r15+0x100], rax
00007957b0dd1761  jmp 0x00007957B0BFE110
00007957b0dd1766  cmp dword ptr [r15+0x318], 0x00
00007957b0dd176e  jz 0x00007957B0DD1690
00007957b0dd1774  nop [rax+rax*1], ax
00007957b0dd177d  nop [rax+rax*1], eax
00007957b0dd1785  mov eax, 0x4103B0
00007957b0dd178a  mov [r15+0x100], rax
00007957b0dd1791  jmp 0x00007957B0BFE110
00007957b0dd1796  int3
00007957b0dd1797  call 0x00007957B0CB4690
00007957b0dd179c  jmp 0x00007957B0DD16AD
00007957b0dd17a1  call 0x00007957B0CE26A0
00007957b0dd17a6  jmp 0x00007957B0DD16B7
00007957b0dd17ab  int3
00007957b0dd17ac  nop [rax], eax
00007957b0dd17b0  mov qword ptr [r15+0x98], 0x00
00007957b0dd17bb  mov rax, [r15+0x50]
00007957b0dd17bf  mov r14, [r15+0x48]
00007957b0dd17c3  lea r12, [rax+r14*1]
00007957b0dd17c7  mov [r15+0x48], r12
00007957b0dd17cb  mov rax, [r15+0x40]
00007957b0dd17cf  lea r14, [rax+0xC40]
00007957b0dd17d6  mov [r13+r14*1], r12
00007957b0dd17db  mov qword ptr [r15], 0x01
00007957b0dd17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007957b0dd17ed  mov r14d, [r15+0x320]
00007957b0dd17f4  mov eax, 0x4103E8
00007957b0dd17f9  mov rcx, 0x7957B0DD1860
00007957b0dd1803  mov [r15+r14*8+0x328], rax
00007957b0dd180b  mov [r15+r14*8+0x368], rcx
00007957b0dd1813  add r14d, 0x01
00007957b0dd1817  and r14d, 0x07
00007957b0dd181b  mov [r15+0x320], r14d
00007957b0dd1822  cmp dword ptr [r15+0x318], 0x00
00007957b0dd182a  jz 0x00007957B0DD0F20
00007957b0dd1830  nop [rax+rax*1], ax
00007957b0dd1839  nop [rax+rax*1], eax
00007957b0dd1841  mov eax, 0x410938
00007957b0dd1846  mov [r15+0x100], rax
00007957b0dd184d  jmp 0x00007957B0BFE110
00007957b0dd1852  int3
00007957b0dd1853  call 0x00007957B0CE2CE0
00007957b0dd1858  jmp 0x00007957B0DD17DB
00007957b0dd185d  int3
00007957b0dd185e  nop
00007957b0dd1860  mov eax, [r15+0x98]
00007957b0dd1867  lea r14d, [eax+0x01]
00007957b0dd186c  mov [rsp+0x10], r14d
00007957b0dd1871  mov r14d, r14d
00007957b0dd1874  mov [r15+0x98], r14
00007957b0dd187b  xor eax, eax
00007957b0dd187d  mov r14d, [rsp+0x10]
00007957b0dd1882  cmp r14d, 0x10000
00007957b0dd1889  cmc
00007957b0dd188a  lahf
00007957b0dd188b  seto al
00007957b0dd188e  mov [r15+0x108], eax
00007957b0dd1895  mov eax, [r15+0x108]
00007957b0dd189c  sahf
00007957b0dd189d  jnz 0x00007957B0DD18CF
00007957b0dd189f  cmp dword ptr [r15+0x318], 0x00
00007957b0dd18a7  jz 0x00007957B0DD19A0
00007957b0dd18ad  nop [rax+rax*1], ax
00007957b0dd18b6  nop [rax+rax*1], eax
00007957b0dd18be  mov eax, 0x4103F4
00007957b0dd18c3  mov [r15+0x100], rax
00007957b0dd18ca  jmp 0x00007957B0BFE110
00007957b0dd18cf  cmp dword ptr [r15+0x318], 0x00
00007957b0dd18d7  jz 0x00007957B0DD1910
00007957b0dd18dd  nop [rax+rax*1], ax
00007957b0dd18e6  nop [rax+rax*1], eax
00007957b0dd18ee  mov eax, 0x4103E0
00007957b0dd18f3  mov [r15+0x100], rax
00007957b0dd18fa  jmp 0x00007957B0BFE110
00007957b0dd18ff  int3
00007957b0dd1900  int3
00007957b0dd1901  nop [rax+rax*1], ax
00007957b0dd190a  nop [rax+rax*1], ax
00007957b0dd1910  mov eax, [r15]
00007957b0dd1913  mov r14d, [r15+0x98]
00007957b0dd191a  lea r12d, [eax+r14d*1]
00007957b0dd191f  mov r12d, r12d
00007957b0dd1922  mov [r15], r12
00007957b0dd1925  mov qword ptr [r15+0xF0], 0x4103E8
00007957b0dd1930  mov r14d, [r15+0x320]
00007957b0dd1937  mov eax, 0x4103E8
00007957b0dd193c  mov rcx, 0x7957B0DD1860
00007957b0dd1946  mov [r15+r14*8+0x328], rax
00007957b0dd194e  mov [r15+r14*8+0x368], rcx
00007957b0dd1956  add r14d, 0x01
00007957b0dd195a  and r14d, 0x07
00007957b0dd195e  mov [r15+0x320], r14d
00007957b0dd1965  cmp dword ptr [r15+0x318], 0x00
00007957b0dd196d  jz 0x00007957B0DD0F20
00007957b0dd1973  nop [rax+rax*1], ax
00007957b0dd197c  nop [rax+rax*1], eax
00007957b0dd1984  mov eax, 0x410938
00007957b0dd1989  mov [r15+0x100], rax
00007957b0dd1990  jmp 0x00007957B0BFE110
00007957b0dd1995  int3
00007957b0dd1996  int3
00007957b0dd1997  nop [rax+rax*1], ax
00007957b0dd19a0  vmovaps xmm1, [0x00007957B09FE010]
00007957b0dd19a8  movq xmm1, xmm1
00007957b0dd19ac  movaps [r15+0x110], xmm1
00007957b0dd19b4  mov eax, 0x420AA0
00007957b0dd19b9  mov r14, [r13+rax*1]
00007957b0dd19be  movq xmm1, r14
00007957b0dd19c3  movaps [r15+0x120], xmm1
00007957b0dd19cb  vmovaps xmm1, [0x00007957B09FE020]
00007957b0dd19d3  movq xmm1, xmm1
00007957b0dd19d7  movaps [r15+0x140], xmm1
00007957b0dd19df  vmovaps xmm1, [0x00007957B09FE030]
00007957b0dd19e7  vpbroadcastq xmm1, xmm1
00007957b0dd19ec  movaps [r15+0x150], xmm1
00007957b0dd19f4  mov qword ptr [r15+0x40], 0x02
00007957b0dd19fc  vmovaps xmm15, [0x00007957B09FE040]
00007957b0dd1a04  movq xmm15, xmm15
00007957b0dd1a09  movaps [r15+0x160], xmm15
00007957b0dd1a11  vmovaps xmm15, [0x00007957B09FE050]
00007957b0dd1a19  vpbroadcastq xmm15, xmm15
00007957b0dd1a1e  movaps [r15+0x130], xmm15
00007957b0dd1a26  mov rax, [r15+0x40]
00007957b0dd1a2a  vmovq xmm14, rax
00007957b0dd1a2f  vpbroadcastq xmm14, xmm14
00007957b0dd1a34  movaps [r15+0x170], xmm14
00007957b0dd1a3c  mov eax, 0x4209D0
00007957b0dd1a41  movups xmm13, [r13+rax*1]
00007957b0dd1a47  mov qword ptr [r15+0x40], 0x431D90
00007957b0dd1a4f  mov eax, [r15]
00007957b0dd1a52  mov r14d, 0x430C48
00007957b0dd1a58  mov [r13+r14*1], eax
00007957b0dd1a5d  mov qword ptr [r15+0x50], 0x431F90
00007957b0dd1a65  vpmovqd xmm12, xmm13
00007957b0dd1a6b  pxor xmm11, xmm11
00007957b0dd1a70  punpcklqdq xmm12, xmm11
00007957b0dd1a75  movaps [r15+0x210], xmm12
00007957b0dd1a7d  movq xmm12, qword ptr [r15+0x140]
00007957b0dd1a86  movq xmm11, qword ptr [r15+0x120]
00007957b0dd1a8f  psubd xmm12, xmm11
00007957b0dd1a94  movq xmm12, xmm12
00007957b0dd1a99  paddq xmm13, xmm14
00007957b0dd1a9e  movaps [r15+0x180], xmm13
00007957b0dd1aa6  movq xmm14, qword ptr [r15+0x160]
00007957b0dd1aaf  paddd xmm11, xmm14
00007957b0dd1ab4  movq xmm11, xmm11
00007957b0dd1ab9  movq xmm11, xmm11
00007957b0dd1abe  movaps [r15+0x120], xmm11
00007957b0dd1ac6  pmovzxdq xmm12, xmm12
00007957b0dd1acc  psllq xmm12, 0x00
00007957b0dd1ad2  movq xmm14, qword ptr [r15+0x210]
00007957b0dd1adb  movq xmm13, qword ptr [r15+0x110]
00007957b0dd1ae4  paddd xmm14, xmm13
00007957b0dd1ae9  movq xmm14, xmm14
00007957b0dd1aee  vcvtuqq2pd xmm12, xmm12
00007957b0dd1af4  pmovzxdq xmm14, xmm14
00007957b0dd1afa  psllq xmm14, 0x00
00007957b0dd1b00  vcvtuqq2pd xmm14, xmm14
00007957b0dd1b06  movaps xmm13, xmm12
00007957b0dd1b0a  mulpd xmm13, xmm1
00007957b0dd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007957b0dd1b15  ptest xmm11, xmm11
00007957b0dd1b1b  jnz 0x00007957B0DD1C0F
00007957b0dd1b21  movaps [r15+0x220], xmm13
00007957b0dd1b29  mov eax, 0x431F90
00007957b0dd1b2e  movups [r13+rax*1], xmm13
00007957b0dd1b34  movaps xmm1, xmm14
00007957b0dd1b38  mulpd xmm1, xmm15
00007957b0dd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007957b0dd1b42  ptest xmm13, xmm13
00007957b0dd1b48  jnz 0x00007957B0DD1D5C
00007957b0dd1b4e  movaps [r15+0x210], xmm1
00007957b0dd1b56  mov eax, 0x431D90
00007957b0dd1b5b  movups [r13+rax*1], xmm1
00007957b0dd1b61  mov qword ptr [r15+0x48], 0x10
00007957b0dd1b69  xor eax, eax
00007957b0dd1b6b  mov r14d, 0x10
00007957b0dd1b71  mov r12d, 0x200
00007957b0dd1b77  cmp r14, r12
00007957b0dd1b7a  cmc
00007957b0dd1b7b  lahf
00007957b0dd1b7c  seto al
00007957b0dd1b7f  mov [r15+0x108], eax
00007957b0dd1b86  mov eax, [r15+0x108]
00007957b0dd1b8d  sahf
00007957b0dd1b8e  jnz 0x00007957B0DD1BC0
00007957b0dd1b90  cmp dword ptr [r15+0x318], 0x00
00007957b0dd1b98  jz 0x00007957B0DD2300
00007957b0dd1b9e  nop [rax+rax*1], ax
00007957b0dd1ba7  nop [rax+rax*1], eax
00007957b0dd1baf  mov eax, 0x410480
00007957b0dd1bb4  mov [r15+0x100], rax
00007957b0dd1bbb  jmp 0x00007957B0BFE110
00007957b0dd1bc0  cmp dword ptr [r15+0x318], 0x00
00007957b0dd1bc8  jz 0x00007957B0DD1EB0
00007957b0dd1bce  nop [rax+rax*1], ax
00007957b0dd1bd7  nop [rax+rax*1], eax
00007957b0dd1bdf  mov eax, 0x410440
00007957b0dd1be4  mov [r15+0x100], rax
00007957b0dd1beb  jmp 0x00007957B0BFE110
00007957b0dd1bf0  int3
00007957b0dd1bf1  call 0x00007957B0C0DC20
00007957b0dd1bf6  jmp 0x00007957B0DD19BE
00007957b0dd1bfb  call 0x00007957B0C0C260
00007957b0dd1c00  jmp 0x00007957B0DD1A47
00007957b0dd1c05  call 0x00007957B0CD5D70
00007957b0dd1c0a  jmp 0x00007957B0DD1A5D
00007957b0dd1c0f  sub rsp, 0x08
00007957b0dd1c13  push rax
00007957b0dd1c14  push rcx
00007957b0dd1c15  push rdx
00007957b0dd1c16  push rdi
00007957b0dd1c17  push rsi
00007957b0dd1c18  push r8
00007957b0dd1c1a  push r9
00007957b0dd1c1c  push r10
00007957b0dd1c1e  push r11
00007957b0dd1c20  sub rsp, 0xF0
00007957b0dd1c27  vmovaps [rsp], xmm0
00007957b0dd1c2c  vmovaps [rsp+0x10], xmm1
00007957b0dd1c32  vmovaps [rsp+0x20], xmm2
00007957b0dd1c38  vmovaps [rsp+0x30], xmm3
00007957b0dd1c3e  vmovaps [rsp+0x40], xmm4
00007957b0dd1c44  vmovaps [rsp+0x50], xmm5
00007957b0dd1c4a  vmovaps [rsp+0x60], xmm6
00007957b0dd1c50  vmovaps [rsp+0x70], xmm7
00007957b0dd1c56  vmovaps [rsp+0x80], xmm8
00007957b0dd1c5f  vmovaps [rsp+0x90], xmm9
00007957b0dd1c68  vmovaps [rsp+0xA0], xmm10
00007957b0dd1c71  vmovaps [rsp+0xB0], xmm11
00007957b0dd1c7a  vmovaps [rsp+0xC0], xmm12
00007957b0dd1c83  vmovaps [rsp+0xD0], xmm14
00007957b0dd1c8c  vmovaps [rsp+0xE0], xmm15
00007957b0dd1c95  sub rsp, 0x30
00007957b0dd1c99  movaps [rsp], xmm13
00007957b0dd1c9e  movaps [rsp+0x10], xmm12
00007957b0dd1ca4  movaps [rsp+0x20], xmm1
00007957b0dd1ca9  lea rdi, [rsp]
00007957b0dd1cad  mov esi, 0x00
00007957b0dd1cb2  mov rax, 0x56E396DF1530
00007957b0dd1cbc  call rax
00007957b0dd1cbe  movaps xmm13, [rsp]
00007957b0dd1cc3  add rsp, 0x30
00007957b0dd1cc7  vmovaps xmm0, [rsp]
00007957b0dd1ccc  vmovaps xmm1, [rsp+0x10]
00007957b0dd1cd2  vmovaps xmm2, [rsp+0x20]
00007957b0dd1cd8  vmovaps xmm3, [rsp+0x30]
00007957b0dd1cde  vmovaps xmm4, [rsp+0x40]
00007957b0dd1ce4  vmovaps xmm5, [rsp+0x50]
00007957b0dd1cea  vmovaps xmm6, [rsp+0x60]
00007957b0dd1cf0  vmovaps xmm7, [rsp+0x70]
00007957b0dd1cf6  vmovaps xmm8, [rsp+0x80]
00007957b0dd1cff  vmovaps xmm9, [rsp+0x90]
00007957b0dd1d08  vmovaps xmm10, [rsp+0xA0]
00007957b0dd1d11  vmovaps xmm11, [rsp+0xB0]
00007957b0dd1d1a  vmovaps xmm12, [rsp+0xC0]
00007957b0dd1d23  vmovaps xmm14, [rsp+0xD0]
00007957b0dd1d2c  vmovaps xmm15, [rsp+0xE0]
00007957b0dd1d35  add rsp, 0xF0
00007957b0dd1d3c  pop r11
00007957b0dd1d3e  pop r10
00007957b0dd1d40  pop r9
00007957b0dd1d42  pop r8
00007957b0dd1d44  pop rsi
00007957b0dd1d45  pop rdi
00007957b0dd1d46  pop rdx
00007957b0dd1d47  pop rcx
00007957b0dd1d48  pop rax
00007957b0dd1d49  add rsp, 0x08
00007957b0dd1d4d  jmp 0x00007957B0DD1B21
00007957b0dd1d52  call 0x00007957B0C0C380
00007957b0dd1d57  jmp 0x00007957B0DD1B34
00007957b0dd1d5c  sub rsp, 0x08
00007957b0dd1d60  push rax
00007957b0dd1d61  push rcx
00007957b0dd1d62  push rdx
00007957b0dd1d63  push rdi
00007957b0dd1d64  push rsi
00007957b0dd1d65  push r8
00007957b0dd1d67  push r9
00007957b0dd1d69  push r10
00007957b0dd1d6b  push r11
00007957b0dd1d6d  sub rsp, 0xF0
00007957b0dd1d74  vmovaps [rsp], xmm0
00007957b0dd1d79  vmovaps [rsp+0x10], xmm2
00007957b0dd1d7f  vmovaps [rsp+0x20], xmm3
00007957b0dd1d85  vmovaps [rsp+0x30], xmm4
00007957b0dd1d8b  vmovaps [rsp+0x40], xmm5
00007957b0dd1d91  vmovaps [rsp+0x50], xmm6
00007957b0dd1d97  vmovaps [rsp+0x60], xmm7
00007957b0dd1d9d  vmovaps [rsp+0x70], xmm8
00007957b0dd1da3  vmovaps [rsp+0x80], xmm9
00007957b0dd1dac  vmovaps [rsp+0x90], xmm10
00007957b0dd1db5  vmovaps [rsp+0xA0], xmm11
00007957b0dd1dbe  vmovaps [rsp+0xB0], xmm12
00007957b0dd1dc7  vmovaps [rsp+0xC0], xmm13
00007957b0dd1dd0  vmovaps [rsp+0xD0], xmm14
00007957b0dd1dd9  vmovaps [rsp+0xE0], xmm15
00007957b0dd1de2  sub rsp, 0x30
00007957b0dd1de6  movaps [rsp], xmm1
00007957b0dd1dea  movaps [rsp+0x10], xmm14
00007957b0dd1df0  movaps [rsp+0x20], xmm15
00007957b0dd1df6  lea rdi, [rsp]
00007957b0dd1dfa  mov esi, 0x00
00007957b0dd1dff  mov rax, 0x56E396DF1530
00007957b0dd1e09  call rax
00007957b0dd1e0b  movaps xmm1, [rsp]
00007957b0dd1e0f  add rsp, 0x30
00007957b0dd1e13  vmovaps xmm0, [rsp]
00007957b0dd1e18  vmovaps xmm2, [rsp+0x10]
00007957b0dd1e1e  vmovaps xmm3, [rsp+0x20]
00007957b0dd1e24  vmovaps xmm4, [rsp+0x30]
00007957b0dd1e2a  vmovaps xmm5, [rsp+0x40]
00007957b0dd1e30  vmovaps xmm6, [rsp+0x50]
00007957b0dd1e36  vmovaps xmm7, [rsp+0x60]
00007957b0dd1e3c  vmovaps xmm8, [rsp+0x70]
00007957b0dd1e42  vmovaps xmm9, [rsp+0x80]
00007957b0dd1e4b  vmovaps xmm10, [rsp+0x90]
00007957b0dd1e54  vmovaps xmm11, [rsp+0xA0]
00007957b0dd1e5d  vmovaps xmm12, [rsp+0xB0]
00007957b0dd1e66  vmovaps xmm13, [rsp+0xC0]
00007957b0dd1e6f  vmovaps xmm14, [rsp+0xD0]
00007957b0dd1e78  vmovaps xmm15, [rsp+0xE0]
00007957b0dd1e81  add rsp, 0xF0
00007957b0dd1e88  pop r11
00007957b0dd1e8a  pop r10
00007957b0dd1e8c  pop r9
00007957b0dd1e8e  pop r8
00007957b0dd1e90  pop rsi
00007957b0dd1e91  pop rdi
00007957b0dd1e92  pop rdx
00007957b0dd1e93  pop rcx
00007957b0dd1e94  pop rax
00007957b0dd1e95  add rsp, 0x08
00007957b0dd1e99  jmp 0x00007957B0DD1B4E
00007957b0dd1e9e  call 0x00007957B0BFF540
00007957b0dd1ea3  jmp 0x00007957B0DD1B61
00007957b0dd1ea8  int3
00007957b0dd1ea9  nop [rax], eax
00007957b0dd1eb0  movaps xmm1, [r15+0x180]
00007957b0dd1eb8  vpmovqd xmm15, xmm1
00007957b0dd1ebe  pxor xmm14, xmm14
00007957b0dd1ec3  punpcklqdq xmm15, xmm14
00007957b0dd1ec8  movaps [r15+0x210], xmm15
00007957b0dd1ed0  movq xmm15, qword ptr [r15+0x140]
00007957b0dd1ed9  movq xmm14, qword ptr [r15+0x120]
00007957b0dd1ee2  psubd xmm15, xmm14
00007957b0dd1ee7  movq xmm15, xmm15
00007957b0dd1eec  movaps xmm13, [r15+0x170]
00007957b0dd1ef4  paddq xmm1, xmm13
00007957b0dd1ef9  movaps [r15+0x180], xmm1
00007957b0dd1f01  movq xmm1, qword ptr [r15+0x160]
00007957b0dd1f0a  paddd xmm14, xmm1
00007957b0dd1f0f  movq xmm14, xmm14
00007957b0dd1f14  movq xmm14, xmm14
00007957b0dd1f19  movaps [r15+0x120], xmm14
00007957b0dd1f21  pmovzxdq xmm15, xmm15
00007957b0dd1f27  psllq xmm15, 0x00
00007957b0dd1f2d  movq xmm1, qword ptr [r15+0x210]
00007957b0dd1f36  movq xmm14, qword ptr [r15+0x110]
00007957b0dd1f3f  paddd xmm1, xmm14
00007957b0dd1f44  movq xmm1, xmm1
00007957b0dd1f48  vcvtuqq2pd xmm15, xmm15
00007957b0dd1f4e  pmovzxdq xmm1, xmm1
00007957b0dd1f53  psllq xmm1, 0x00
00007957b0dd1f58  vcvtuqq2pd xmm1, xmm1
00007957b0dd1f5e  movaps xmm14, [r15+0x150]
00007957b0dd1f66  movaps xmm13, xmm15
00007957b0dd1f6a  mulpd xmm13, xmm14
00007957b0dd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd1f75  ptest xmm12, xmm12
00007957b0dd1f7b  jnz 0x00007957B0DD205E
00007957b0dd1f81  movaps [r15+0x220], xmm13
00007957b0dd1f89  mov rax, [r15+0x48]
00007957b0dd1f8d  mov r14, [r15+0x50]
00007957b0dd1f91  lea r12, [r14+rax*1]
00007957b0dd1f95  movups [r13+r12*1], xmm13
00007957b0dd1f9b  movaps xmm15, [r15+0x130]
00007957b0dd1fa3  movaps xmm14, xmm1
00007957b0dd1fa7  mulpd xmm14, xmm15
00007957b0dd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007957b0dd1fb2  ptest xmm13, xmm13
00007957b0dd1fb8  jnz 0x00007957B0DD21AC
00007957b0dd1fbe  movaps [r15+0x210], xmm14
00007957b0dd1fc6  mov r14, [r15+0x40]
00007957b0dd1fca  lea r12, [r14+rax*1]
00007957b0dd1fce  movups [r13+r12*1], xmm14
00007957b0dd1fd4  lea r14, [rax+0x10]
00007957b0dd1fd8  mov [r15+0x48], r14
00007957b0dd1fdc  xor eax, eax
00007957b0dd1fde  mov r12d, 0x200
00007957b0dd1fe4  cmp r14, r12
00007957b0dd1fe7  cmc
00007957b0dd1fe8  lahf
00007957b0dd1fe9  seto al
00007957b0dd1fec  mov [r15+0x108], eax
00007957b0dd1ff3  mov eax, [r15+0x108]
00007957b0dd1ffa  sahf
00007957b0dd1ffb  jnz 0x00007957B0DD202D
00007957b0dd1ffd  cmp dword ptr [r15+0x318], 0x00
00007957b0dd2005  jz 0x00007957B0DD2300
00007957b0dd200b  nop [rax+rax*1], ax
00007957b0dd2014  nop [rax+rax*1], eax
00007957b0dd201c  mov eax, 0x410480
00007957b0dd2021  mov [r15+0x100], rax
00007957b0dd2028  jmp 0x00007957B0BFE110
00007957b0dd202d  cmp dword ptr [r15+0x318], 0x00
00007957b0dd2035  jz 0x00007957B0DD1EB0
00007957b0dd203b  nop [rax+rax*1], ax
00007957b0dd2044  nop [rax+rax*1], eax
00007957b0dd204c  mov eax, 0x410440
00007957b0dd2051  mov [r15+0x100], rax
00007957b0dd2058  jmp 0x00007957B0BFE110
00007957b0dd205d  int3
00007957b0dd205e  sub rsp, 0x08
00007957b0dd2062  push rax
00007957b0dd2063  push rcx
00007957b0dd2064  push rdx
00007957b0dd2065  push rdi
00007957b0dd2066  push rsi
00007957b0dd2067  push r8
00007957b0dd2069  push r9
00007957b0dd206b  push r10
00007957b0dd206d  push r11
00007957b0dd206f  sub rsp, 0xF0
00007957b0dd2076  vmovaps [rsp], xmm0
00007957b0dd207b  vmovaps [rsp+0x10], xmm1
00007957b0dd2081  vmovaps [rsp+0x20], xmm2
00007957b0dd2087  vmovaps [rsp+0x30], xmm3
00007957b0dd208d  vmovaps [rsp+0x40], xmm4
00007957b0dd2093  vmovaps [rsp+0x50], xmm5
00007957b0dd2099  vmovaps [rsp+0x60], xmm6
00007957b0dd209f  vmovaps [rsp+0x70], xmm7
00007957b0dd20a5  vmovaps [rsp+0x80], xmm8
00007957b0dd20ae  vmovaps [rsp+0x90], xmm9
00007957b0dd20b7  vmovaps [rsp+0xA0], xmm10
00007957b0dd20c0  vmovaps [rsp+0xB0], xmm11
00007957b0dd20c9  vmovaps [rsp+0xC0], xmm12
00007957b0dd20d2  vmovaps [rsp+0xD0], xmm14
00007957b0dd20db  vmovaps [rsp+0xE0], xmm15
00007957b0dd20e4  sub rsp, 0x30
00007957b0dd20e8  movaps [rsp], xmm13
00007957b0dd20ed  movaps [rsp+0x10], xmm15
00007957b0dd20f3  movaps [rsp+0x20], xmm14
00007957b0dd20f9  lea rdi, [rsp]
00007957b0dd20fd  mov esi, 0x00
00007957b0dd2102  mov rax, 0x56E396DF1530
00007957b0dd210c  call rax
00007957b0dd210e  movaps xmm13, [rsp]
00007957b0dd2113  add rsp, 0x30
00007957b0dd2117  vmovaps xmm0, [rsp]
00007957b0dd211c  vmovaps xmm1, [rsp+0x10]
00007957b0dd2122  vmovaps xmm2, [rsp+0x20]
00007957b0dd2128  vmovaps xmm3, [rsp+0x30]
00007957b0dd212e  vmovaps xmm4, [rsp+0x40]
00007957b0dd2134  vmovaps xmm5, [rsp+0x50]
00007957b0dd213a  vmovaps xmm6, [rsp+0x60]
00007957b0dd2140  vmovaps xmm7, [rsp+0x70]
00007957b0dd2146  vmovaps xmm8, [rsp+0x80]
00007957b0dd214f  vmovaps xmm9, [rsp+0x90]
00007957b0dd2158  vmovaps xmm10, [rsp+0xA0]
00007957b0dd2161  vmovaps xmm11, [rsp+0xB0]
00007957b0dd216a  vmovaps xmm12, [rsp+0xC0]
00007957b0dd2173  vmovaps xmm14, [rsp+0xD0]
00007957b0dd217c  vmovaps xmm15, [rsp+0xE0]
00007957b0dd2185  add rsp, 0xF0
00007957b0dd218c  pop r11
00007957b0dd218e  pop r10
00007957b0dd2190  pop r9
00007957b0dd2192  pop r8
00007957b0dd2194  pop rsi
00007957b0dd2195  pop rdi
00007957b0dd2196  pop rdx
00007957b0dd2197  pop rcx
00007957b0dd2198  pop rax
00007957b0dd2199  add rsp, 0x08
00007957b0dd219d  jmp 0x00007957B0DD1F81
00007957b0dd21a2  call 0x00007957B0CC2240
00007957b0dd21a7  jmp 0x00007957B0DD1F9B
00007957b0dd21ac  sub rsp, 0x08
00007957b0dd21b0  push rax
00007957b0dd21b1  push rcx
00007957b0dd21b2  push rdx
00007957b0dd21b3  push rdi
00007957b0dd21b4  push rsi
00007957b0dd21b5  push r8
00007957b0dd21b7  push r9
00007957b0dd21b9  push r10
00007957b0dd21bb  push r11
00007957b0dd21bd  sub rsp, 0xF0
00007957b0dd21c4  vmovaps [rsp], xmm0
00007957b0dd21c9  vmovaps [rsp+0x10], xmm1
00007957b0dd21cf  vmovaps [rsp+0x20], xmm2
00007957b0dd21d5  vmovaps [rsp+0x30], xmm3
00007957b0dd21db  vmovaps [rsp+0x40], xmm4
00007957b0dd21e1  vmovaps [rsp+0x50], xmm5
00007957b0dd21e7  vmovaps [rsp+0x60], xmm6
00007957b0dd21ed  vmovaps [rsp+0x70], xmm7
00007957b0dd21f3  vmovaps [rsp+0x80], xmm8
00007957b0dd21fc  vmovaps [rsp+0x90], xmm9
00007957b0dd2205  vmovaps [rsp+0xA0], xmm10
00007957b0dd220e  vmovaps [rsp+0xB0], xmm11
00007957b0dd2217  vmovaps [rsp+0xC0], xmm12
00007957b0dd2220  vmovaps [rsp+0xD0], xmm13
00007957b0dd2229  vmovaps [rsp+0xE0], xmm15
00007957b0dd2232  sub rsp, 0x30
00007957b0dd2236  movaps [rsp], xmm14
00007957b0dd223b  movaps [rsp+0x10], xmm1
00007957b0dd2240  movaps [rsp+0x20], xmm15
00007957b0dd2246  lea rdi, [rsp]
00007957b0dd224a  mov esi, 0x00
00007957b0dd224f  mov rax, 0x56E396DF1530
00007957b0dd2259  call rax
00007957b0dd225b  movaps xmm14, [rsp]
00007957b0dd2260  add rsp, 0x30
00007957b0dd2264  vmovaps xmm0, [rsp]
00007957b0dd2269  vmovaps xmm1, [rsp+0x10]
00007957b0dd226f  vmovaps xmm2, [rsp+0x20]
00007957b0dd2275  vmovaps xmm3, [rsp+0x30]
00007957b0dd227b  vmovaps xmm4, [rsp+0x40]
00007957b0dd2281  vmovaps xmm5, [rsp+0x50]
00007957b0dd2287  vmovaps xmm6, [rsp+0x60]
00007957b0dd228d  vmovaps xmm7, [rsp+0x70]
00007957b0dd2293  vmovaps xmm8, [rsp+0x80]
00007957b0dd229c  vmovaps xmm9, [rsp+0x90]
00007957b0dd22a5  vmovaps xmm10, [rsp+0xA0]
00007957b0dd22ae  vmovaps xmm11, [rsp+0xB0]
00007957b0dd22b7  vmovaps xmm12, [rsp+0xC0]
00007957b0dd22c0  vmovaps xmm13, [rsp+0xD0]
00007957b0dd22c9  vmovaps xmm15, [rsp+0xE0]
00007957b0dd22d2  add rsp, 0xF0
00007957b0dd22d9  pop r11
00007957b0dd22db  pop r10
00007957b0dd22dd  pop r9
00007957b0dd22df  pop r8
00007957b0dd22e1  pop rsi
00007957b0dd22e2  pop rdi
00007957b0dd22e3  pop rdx
00007957b0dd22e4  pop rcx
00007957b0dd22e5  pop rax
00007957b0dd22e6  add rsp, 0x08
00007957b0dd22ea  jmp 0x00007957B0DD1FBE
00007957b0dd22ef  call 0x00007957B0CC34C0
00007957b0dd22f4  jmp 0x00007957B0DD1FD4
00007957b0dd22f9  int3
00007957b0dd22fa  nop [rax+rax*1], ax
00007957b0dd2300  mov rax, [r15+0x50]
00007957b0dd2304  movups xmm1, [r13+rax*1]
00007957b0dd230a  lea r14, [rax+0x10]
00007957b0dd230e  movups xmm15, [r13+r14*1]
00007957b0dd2314  mov qword ptr [r15+0x48], 0x00
00007957b0dd231c  lea r14, [rax+0x40]
00007957b0dd2320  movups xmm14, [r13+r14*1]
00007957b0dd2326  lea r14, [rax+0x50]
00007957b0dd232a  movups xmm13, [r13+r14*1]
00007957b0dd2330  lea r14, [rax+0x80]
00007957b0dd2337  movups xmm12, [r13+r14*1]
00007957b0dd233d  lea r14, [rax+0x90]
00007957b0dd2344  movups xmm11, [r13+r14*1]
00007957b0dd234a  mov r14, [r15+0xF8]
00007957b0dd2351  movups [r13+r14*1], xmm1
00007957b0dd2357  lea r12, [rax+0x20]
00007957b0dd235b  movups xmm1, [r13+r12*1]
00007957b0dd2361  lea r12, [rax+0x30]
00007957b0dd2365  movups xmm10, [r13+r12*1]
00007957b0dd236b  lea r12, [rax+0xC0]
00007957b0dd2372  movups xmm9, [r13+r12*1]
00007957b0dd2378  lea r12, [rax+0xD0]
00007957b0dd237f  movups xmm8, [r13+r12*1]
00007957b0dd2385  lea r12, [rax+0x100]
00007957b0dd238c  movups xmm7, [r13+r12*1]
00007957b0dd2392  lea r12, [rax+0x110]
00007957b0dd2399  movups xmm6, [r13+r12*1]
00007957b0dd239f  lea r12, [rax+0x140]
00007957b0dd23a6  movups xmm5, [r13+r12*1]
00007957b0dd23ac  lea r12, [rax+0x150]
00007957b0dd23b3  movups xmm4, [r13+r12*1]
00007957b0dd23b9  lea r12, [r14+0xB0]
00007957b0dd23c0  movups [r13+r12*1], xmm10
00007957b0dd23c6  lea r12, [r14+0xC0]
00007957b0dd23cd  movups [r13+r12*1], xmm1
00007957b0dd23d3  lea r12, [rax+0x180]
00007957b0dd23da  movups xmm1, [r13+r12*1]
00007957b0dd23e0  lea r12, [rax+0x190]
00007957b0dd23e7  movups xmm10, [r13+r12*1]
00007957b0dd23ed  lea r12, [rax+0x1C0]
00007957b0dd23f4  movups xmm3, [r13+r12*1]
00007957b0dd23fa  lea r12, [rax+0x1D0]
00007957b0dd2401  movups xmm2, [r13+r12*1]
00007957b0dd2407  lea r12, [rax+0x60]
00007957b0dd240b  vmovaps [rsp+0x10], xmm1
00007957b0dd2411  movups xmm1, [r13+r12*1]
00007957b0dd2417  lea r12, [rax+0x70]
00007957b0dd241b  vmovaps [rsp+0x20], xmm1
00007957b0dd2421  movups xmm1, [r13+r12*1]
00007957b0dd2427  lea r12, [r14+0x70]
00007957b0dd242b  movups [r13+r12*1], xmm10
00007957b0dd2431  lea r12, [r14+0x80]
00007957b0dd2438  vmovaps xmm10, [rsp+0x10]
00007957b0dd243e  movups [r13+r12*1], xmm10
00007957b0dd2444  lea r12, [rax+0xA0]
00007957b0dd244b  movups xmm10, [r13+r12*1]
00007957b0dd2451  lea r12, [rax+0xB0]
00007957b0dd2458  vmovaps [rsp+0x10], xmm1
00007957b0dd245e  movups xmm1, [r13+r12*1]
00007957b0dd2464  lea r12, [r14+0x90]
00007957b0dd246b  movups [r13+r12*1], xmm2
00007957b0dd2471  lea r12, [r14+0xA0]
00007957b0dd2478  movups [r13+r12*1], xmm3
00007957b0dd247e  lea r12, [rax+0xE0]
00007957b0dd2485  movups xmm3, [r13+r12*1]
00007957b0dd248b  lea r12, [rax+0xF0]
00007957b0dd2492  movups xmm2, [r13+r12*1]
00007957b0dd2498  lea r12, [rax+0x120]
00007957b0dd249f  vmovaps [rsp+0x30], xmm1
00007957b0dd24a5  movups xmm1, [r13+r12*1]
00007957b0dd24ab  lea r12, [rax+0x130]
00007957b0dd24b2  vmovaps [rsp+0x40], xmm1
00007957b0dd24b8  movups xmm1, [r13+r12*1]
00007957b0dd24be  vmovaps [rsp+0x50], xmm1
00007957b0dd24c4  vmovaps xmm1, [rsp+0x40]
00007957b0dd24ca  movaps [r15+0x190], xmm1
00007957b0dd24d2  lea r12, [rax+0x160]
00007957b0dd24d9  vmovaps [rsp+0x40], xmm1
00007957b0dd24df  movups xmm1, [r13+r12*1]
00007957b0dd24e5  lea r12, [rax+0x170]
00007957b0dd24ec  vmovaps [rsp+0x60], xmm1
00007957b0dd24f2  movups xmm1, [r13+r12*1]
00007957b0dd24f8  lea r12, [rax+0x1A0]
00007957b0dd24ff  vmovaps [rsp+0x70], xmm1
00007957b0dd2505  movups xmm1, [r13+r12*1]
00007957b0dd250b  lea r12, [rax+0x1B0]
00007957b0dd2512  vmovaps [rsp+0x80], xmm1
00007957b0dd251b  movups xmm1, [r13+r12*1]
00007957b0dd2521  lea r12, [rax+0x1E0]
00007957b0dd2528  vmovaps [rsp+0x90], xmm1
00007957b0dd2531  movups xmm1, [r13+r12*1]
00007957b0dd2537  lea r12, [rax+0x1F0]
00007957b0dd253e  vmovaps [rsp+0xA0], xmm1
00007957b0dd2547  movups xmm1, [r13+r12*1]
00007957b0dd254d  mov qword ptr [r15+0x50], 0x432190
00007957b0dd2555  lea rax, [r14+0x50]
00007957b0dd2559  vmovaps [rsp+0xB0], xmm1
00007957b0dd2562  vmovaps xmm1, [rsp+0x60]
00007957b0dd2568  movups [r13+rax*1], xmm1
00007957b0dd256e  lea rax, [r14+0x60]
00007957b0dd2572  movups [r13+rax*1], xmm5
00007957b0dd2578  lea rax, [r14+0x40]
00007957b0dd257c  vmovaps xmm1, [rsp+0x70]
00007957b0dd2582  movups [r13+rax*1], xmm1
00007957b0dd2588  lea rax, [r14+0x20]
00007957b0dd258c  vmovaps xmm1, [rsp+0xA0]
00007957b0dd2595  movups [r13+rax*1], xmm1
00007957b0dd259b  lea rax, [r14+0x30]
00007957b0dd259f  vmovaps xmm1, [rsp+0x90]
00007957b0dd25a8  movups [r13+rax*1], xmm1
00007957b0dd25ae  lea rax, [r14+0x10]
00007957b0dd25b2  vmovaps xmm1, [rsp+0xB0]
00007957b0dd25bb  movups [r13+rax*1], xmm1
00007957b0dd25c1  mov rax, [r15+0x40]
00007957b0dd25c5  vxorps xmm1, xmm1, xmm1
00007957b0dd25c9  vpbroadcastq xmm1, xmm1
00007957b0dd25ce  vxorps xmm5, xmm5, xmm5
00007957b0dd25d2  vpbroadcastq xmm5, xmm5
00007957b0dd25d7  lea r12, [rax+0x30]
00007957b0dd25db  mov r11, [r13+r12*1]
00007957b0dd25e0  lea r12, [rax+0x38]
00007957b0dd25e4  mov r10, [r13+r12*1]
00007957b0dd25e9  vmovaps [rsp+0x60], xmm1
00007957b0dd25ef  movq xmm1, r11
00007957b0dd25f4  vmovaps [rsp+0x70], xmm1
00007957b0dd25fa  movq xmm1, r10
00007957b0dd25ff  vmovaps [rsp+0x90], xmm1
00007957b0dd2608  vmovaps xmm1, [rsp+0x70]
00007957b0dd260e  movq xmm1, xmm1
00007957b0dd2612  vmovaps [rsp+0x70], xmm1
00007957b0dd2618  vmovaps xmm1, [rsp+0x90]
00007957b0dd2621  movq xmm1, xmm1
00007957b0dd2625  vmovaps [rsp+0x90], xmm1
00007957b0dd262e  movq xmm1, xmm1
00007957b0dd2632  movaps [r15+0x270], xmm1
00007957b0dd263a  vmovaps [rsp+0xA0], xmm7
00007957b0dd2643  vmovaps xmm1, [rsp+0xA0]
00007957b0dd264c  por xmm7, xmm1
00007957b0dd2650  lea r12, [rax+0x20]
00007957b0dd2654  mov r11, [r13+r12*1]
00007957b0dd2659  lea r12, [rax+0x28]
00007957b0dd265d  mov r10, [r13+r12*1]
00007957b0dd2662  movq xmm1, r11
00007957b0dd2667  vmovaps [rsp+0xA0], xmm1
00007957b0dd2670  movq xmm1, r10
00007957b0dd2675  vmovaps [rsp+0xB0], xmm1
00007957b0dd267e  vmovaps xmm1, [rsp+0xA0]
00007957b0dd2687  movq xmm1, xmm1
00007957b0dd268b  vmovaps [rsp+0xA0], xmm1
00007957b0dd2694  vmovaps xmm1, [rsp+0xB0]
00007957b0dd269d  movq xmm1, xmm1
00007957b0dd26a1  vmovaps [rsp+0xB0], xmm2
00007957b0dd26aa  vmovaps [rsp+0xC0], xmm1
00007957b0dd26b3  vmovaps xmm1, [rsp+0xB0]
00007957b0dd26bc  por xmm2, xmm1
00007957b0dd26c0  vmovaps [rsp+0xB0], xmm3
00007957b0dd26c9  vmovaps xmm1, [rsp+0xB0]
00007957b0dd26d2  por xmm3, xmm1
00007957b0dd26d6  vmovaps [rsp+0xB0], xmm4
00007957b0dd26df  vmovaps xmm1, [rsp+0xB0]
00007957b0dd26e8  por xmm4, xmm1
00007957b0dd26ec  vmovaps [rsp+0xB0], xmm9
00007957b0dd26f5  vmovaps xmm1, [rsp+0xB0]
00007957b0dd26fe  por xmm9, xmm1
00007957b0dd2703  lea r12, [rax+0x10]
00007957b0dd2707  mov r11, [r13+r12*1]
00007957b0dd270c  lea r12, [rax+0x18]
00007957b0dd2710  mov r10, [r13+r12*1]
00007957b0dd2715  movq xmm1, r11
00007957b0dd271a  vmovaps [rsp+0xB0], xmm1
00007957b0dd2723  movq xmm1, r10
00007957b0dd2728  vmovaps [rsp+0xD0], xmm1
00007957b0dd2731  vmovaps xmm1, [rsp+0xB0]
00007957b0dd273a  movq xmm1, xmm1
00007957b0dd273e  vmovaps [rsp+0xB0], xmm1
00007957b0dd2747  vmovaps xmm1, [rsp+0xD0]
00007957b0dd2750  movq xmm1, xmm1
00007957b0dd2754  vmovaps [rsp+0xD0], xmm1
00007957b0dd275d  vmovaps xmm1, [rsp+0x80]
00007957b0dd2766  vmovaps [rsp+0xE0], xmm15
00007957b0dd276f  vmovaps xmm15, [rsp+0x80]
00007957b0dd2778  por xmm1, xmm15
00007957b0dd277d  vmovaps xmm15, [rsp+0x10]
00007957b0dd2783  vmovaps [rsp+0x80], xmm1
00007957b0dd278c  vmovaps xmm1, [rsp+0x10]
00007957b0dd2792  por xmm15, xmm1
00007957b0dd2797  vmovaps xmm1, [rsp+0x20]
00007957b0dd279d  vmovaps [rsp+0x10], xmm15
00007957b0dd27a3  vmovaps xmm15, [rsp+0x20]
00007957b0dd27a9  por xmm1, xmm15
00007957b0dd27ae  vmovaps [rsp+0x20], xmm6
00007957b0dd27b4  vmovaps xmm15, [rsp+0x20]
00007957b0dd27ba  por xmm6, xmm15
00007957b0dd27bf  vmovaps [rsp+0x20], xmm11
00007957b0dd27c5  vmovaps xmm15, [rsp+0x20]
00007957b0dd27cb  por xmm11, xmm15
00007957b0dd27d0  vmovaps [rsp+0x20], xmm13
00007957b0dd27d6  vmovaps xmm15, [rsp+0x20]
00007957b0dd27dc  por xmm13, xmm15
00007957b0dd27e1  vmovaps [rsp+0x20], xmm14
00007957b0dd27e7  vmovaps xmm15, [rsp+0x20]
00007957b0dd27ed  por xmm14, xmm15
00007957b0dd27f2  mov r12, [r13+rax*1]
00007957b0dd27f7  vmovq xmm15, r12
00007957b0dd27fc  vpbroadcastq xmm15, xmm15
00007957b0dd2801  vmovaps [rsp+0x20], xmm1
00007957b0dd2807  vxorps xmm1, xmm1, xmm1
00007957b0dd280b  vpbroadcastq xmm1, xmm1
00007957b0dd2810  vmovaps [rsp+0xF0], xmm1
00007957b0dd2819  movups xmm1, [r13+r14*1]
00007957b0dd281f  vmovaps [rsp+0x100], xmm1
00007957b0dd2828  vxorps xmm1, xmm1, xmm1
00007957b0dd282c  vpbroadcastq xmm1, xmm1
00007957b0dd2831  lea r12, [rax+0x08]
00007957b0dd2835  mov rax, [r13+r12*1]
00007957b0dd283a  vmovaps [rsp+0x110], xmm1
00007957b0dd2843  movq xmm1, rax
00007957b0dd2848  movaps [r15+0x240], xmm1
00007957b0dd2850  mov qword ptr [r15+0x60], 0x432190
00007957b0dd2858  mov qword ptr [r15+0x58], 0x40
00007957b0dd2860  vmovaps xmm1, [rsp+0x60]
00007957b0dd2866  vmovaps [rsp+0x60], xmm15
00007957b0dd286c  vmovaps xmm15, [rsp+0x100]
00007957b0dd2875  vmovaps [rsp+0x100], xmm14
00007957b0dd287e  vmovaps xmm14, [rsp+0x60]
00007957b0dd2884  vmovaps [rsp+0x60], xmm13
00007957b0dd288a  vmovaps [rsp+0x120], xmm12
00007957b0dd2893  movaps xmm13, xmm1
00007957b0dd2897  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd28a2  vptest xmm12, xmm12
00007957b0dd28a7  jnz 0x00007957B0DD3482
00007957b0dd28ad  vmovaps xmm1, [rsp+0xE0]
00007957b0dd28b6  movaps xmm15, xmm5
00007957b0dd28ba  vfmadd231pd xmm15, xmm1, xmm14
00007957b0dd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007957b0dd28c5  vptest xmm12, xmm12
00007957b0dd28ca  jnz 0x00007957B0DD35DB
00007957b0dd28d0  vmovaps xmm12, [rsp+0x50]
00007957b0dd28d6  vmovaps xmm5, [rsp+0x50]
00007957b0dd28dc  por xmm12, xmm5
00007957b0dd28e1  vmovaps xmm5, [rsp+0x30]
00007957b0dd28e7  vmovaps [rsp+0x50], xmm1
00007957b0dd28ed  vmovaps xmm1, [rsp+0x30]
00007957b0dd28f3  por xmm5, xmm1
00007957b0dd28f7  vmovaps [rsp+0x30], xmm10
00007957b0dd28fd  vmovaps xmm1, [rsp+0x30]
00007957b0dd2903  por xmm10, xmm1
00007957b0dd2908  vmovaps [rsp+0x30], xmm8
00007957b0dd290e  vmovaps xmm1, [rsp+0x30]
00007957b0dd2914  por xmm8, xmm1
00007957b0dd2919  vmovaps xmm1, [rsp+0x120]
00007957b0dd2922  vmovaps [rsp+0x30], xmm15
00007957b0dd2928  vmovaps xmm15, [rsp+0x120]
00007957b0dd2931  por xmm1, xmm15
00007957b0dd2936  vmovaps xmm15, [rsp+0x50]
00007957b0dd293c  vmovaps [rsp+0xE0], xmm1
00007957b0dd2945  vmovaps xmm1, [rsp+0x50]
00007957b0dd294b  por xmm15, xmm1
00007957b0dd2950  lea rax, [r14+0xC0]
00007957b0dd2957  movups xmm1, [r13+rax*1]
00007957b0dd295d  xor eax, eax
00007957b0dd295f  mov r12d, 0x40
00007957b0dd2965  mov r11d, 0x200
00007957b0dd296b  cmp r12, r11
00007957b0dd296e  cmc
00007957b0dd296f  lahf
00007957b0dd2970  seto al
00007957b0dd2973  mov [r15+0x108], eax
00007957b0dd297a  vmovaps [rsp+0x50], xmm1
00007957b0dd2980  vmovaps xmm1, [rsp+0xF0]
00007957b0dd2989  vmovaps [rsp+0xF0], xmm15
00007957b0dd2992  vmovaps xmm15, [rsp+0x50]
00007957b0dd2998  vmovaps [rsp+0x50], xmm13
00007957b0dd299e  vmovaps [rsp+0x120], xmm12
00007957b0dd29a7  movaps xmm13, xmm1
00007957b0dd29ab  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd29b6  vptest xmm12, xmm12
00007957b0dd29bb  jnz 0x00007957B0DD373D
00007957b0dd29c1  lea rax, [r14+0xB0]
00007957b0dd29c8  movups xmm1, [r13+rax*1]
00007957b0dd29ce  vmovaps xmm15, [rsp+0x110]
00007957b0dd29d7  vmovaps [rsp+0x110], xmm13
00007957b0dd29e0  movaps xmm12, xmm15
00007957b0dd29e4  vfmadd231pd xmm12, xmm1, xmm14
00007957b0dd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007957b0dd29ef  vptest xmm13, xmm13
00007957b0dd29f4  jnz 0x00007957B0DD38A0
00007957b0dd29fa  vmovaps xmm1, [rsp+0x100]
00007957b0dd2a03  vmovaps xmm15, [rsp+0x100]
00007957b0dd2a0c  por xmm1, xmm15
00007957b0dd2a11  movaps [r15+0x210], xmm1
00007957b0dd2a19  vmovaps xmm15, [rsp+0x60]
00007957b0dd2a1f  vmovaps xmm14, [rsp+0x60]
00007957b0dd2a25  por xmm15, xmm14
00007957b0dd2a2a  movaps [r15+0x1C0], xmm15
00007957b0dd2a32  vmovaps [rsp+0x60], xmm11
00007957b0dd2a38  vmovaps xmm14, [rsp+0x60]
00007957b0dd2a3e  por xmm11, xmm14
00007957b0dd2a43  movaps [r15+0x280], xmm11
00007957b0dd2a4b  vmovaps [rsp+0x60], xmm6
00007957b0dd2a51  vmovaps xmm14, [rsp+0x60]
00007957b0dd2a57  por xmm6, xmm14
00007957b0dd2a5c  movaps [r15+0x2A0], xmm6
00007957b0dd2a64  vmovaps xmm14, [rsp+0x20]
00007957b0dd2a6a  vmovaps xmm13, [rsp+0x20]
00007957b0dd2a70  por xmm14, xmm13
00007957b0dd2a75  movaps [r15+0x2E0], xmm14
00007957b0dd2a7d  vmovaps xmm13, [rsp+0x10]
00007957b0dd2a83  vmovaps [rsp+0x20], xmm1
00007957b0dd2a89  vmovaps xmm1, [rsp+0x10]
00007957b0dd2a8f  por xmm13, xmm1
00007957b0dd2a94  movaps [r15+0x1F0], xmm13
00007957b0dd2a9c  vmovaps xmm1, [rsp+0xF0]
00007957b0dd2aa5  vmovaps [rsp+0x10], xmm15
00007957b0dd2aab  vmovaps xmm15, [rsp+0xF0]
00007957b0dd2ab4  por xmm1, xmm15
00007957b0dd2ab9  movaps [r15+0x250], xmm1
00007957b0dd2ac1  vmovaps xmm1, [rsp+0xE0]
00007957b0dd2aca  vmovaps xmm15, [rsp+0xE0]
00007957b0dd2ad3  por xmm1, xmm15
00007957b0dd2ad8  movaps [r15+0x260], xmm1
00007957b0dd2ae0  vmovaps [rsp+0x60], xmm8
00007957b0dd2ae6  vmovaps xmm15, [rsp+0x60]
00007957b0dd2aec  por xmm8, xmm15
00007957b0dd2af1  movaps [r15+0x290], xmm8
00007957b0dd2af9  vmovaps [rsp+0x60], xmm10
00007957b0dd2aff  vmovaps xmm15, [rsp+0x60]
00007957b0dd2b05  por xmm10, xmm15
00007957b0dd2b0a  movaps [r15+0x2C0], xmm10
00007957b0dd2b12  movq xmm15, qword ptr [r15+0x240]
00007957b0dd2b1b  vmovaps [rsp+0x60], xmm15
00007957b0dd2b21  vpermilpd xmm15, xmm15, 0x00
00007957b0dd2b27  vmovaps [rsp+0xE0], xmm1
00007957b0dd2b30  vmovaps xmm1, [rsp+0x50]
00007957b0dd2b36  vmovaps [rsp+0x50], xmm15
00007957b0dd2b3c  vmovaps xmm15, [rsp+0x20]
00007957b0dd2b42  vmovaps [rsp+0x20], xmm14
00007957b0dd2b48  vmovaps xmm14, [rsp+0x50]
00007957b0dd2b4e  vmovaps [rsp+0x50], xmm13
00007957b0dd2b54  vmovaps [rsp+0xF0], xmm12
00007957b0dd2b5d  movaps xmm13, xmm1
00007957b0dd2b61  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd2b6c  vptest xmm12, xmm12
00007957b0dd2b71  jnz 0x00007957B0DD39F9
00007957b0dd2b77  vmovaps xmm1, [rsp+0x60]
00007957b0dd2b7d  vpermilpd xmm1, xmm1, 0x00
00007957b0dd2b83  vmovaps xmm15, [rsp+0x110]
00007957b0dd2b8c  vmovaps xmm14, [rsp+0x20]
00007957b0dd2b92  vmovaps [rsp+0x20], xmm13
00007957b0dd2b98  movaps xmm12, xmm15
00007957b0dd2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007957b0dd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007957b0dd2ba7  vptest xmm13, xmm13
00007957b0dd2bac  jnz 0x00007957B0DD3B52
00007957b0dd2bb2  vmovaps xmm1, [rsp+0x60]
00007957b0dd2bb8  vpermilpd xmm1, xmm1, 0x00
00007957b0dd2bbe  vmovaps xmm15, [rsp+0x30]
00007957b0dd2bc4  vmovaps xmm14, [rsp+0x10]
00007957b0dd2bca  vmovaps [rsp+0x10], xmm12
00007957b0dd2bd0  movaps xmm13, xmm15
00007957b0dd2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007957b0dd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd2bdf  vptest xmm12, xmm12
00007957b0dd2be4  jnz 0x00007957B0DD3CAB
00007957b0dd2bea  vmovaps [rsp+0x30], xmm5
00007957b0dd2bf0  vmovaps xmm1, [rsp+0x30]
00007957b0dd2bf6  por xmm5, xmm1
00007957b0dd2bfa  movaps [r15+0x1D0], xmm5
00007957b0dd2c02  vmovaps xmm1, [rsp+0x60]
00007957b0dd2c08  vpermilpd xmm1, xmm1, 0x00
00007957b0dd2c0e  vmovaps xmm15, [rsp+0xF0]
00007957b0dd2c17  vmovaps xmm14, [rsp+0x50]
00007957b0dd2c1d  vmovaps [rsp+0x30], xmm13
00007957b0dd2c23  movaps xmm12, xmm15
00007957b0dd2c27  vfmadd231pd xmm12, xmm14, xmm1
00007957b0dd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007957b0dd2c32  vptest xmm13, xmm13
00007957b0dd2c37  jnz 0x00007957B0DD3E04
00007957b0dd2c3d  vmovaps xmm1, [rsp+0x80]
00007957b0dd2c46  vmovaps xmm15, [rsp+0x80]
00007957b0dd2c4f  por xmm1, xmm15
00007957b0dd2c54  movaps [r15+0x200], xmm1
00007957b0dd2c5c  vmovaps xmm15, [rsp+0x120]
00007957b0dd2c65  vmovaps xmm14, [rsp+0x120]
00007957b0dd2c6e  por xmm15, xmm14
00007957b0dd2c73  movaps [r15+0x1E0], xmm15
00007957b0dd2c7b  vmovaps [rsp+0x50], xmm4
00007957b0dd2c81  vmovaps xmm13, [rsp+0x50]
00007957b0dd2c87  por xmm4, xmm13
00007957b0dd2c8c  movaps [r15+0x2B0], xmm4
00007957b0dd2c94  vmovaps [rsp+0x50], xmm3
00007957b0dd2c9a  vmovaps xmm13, [rsp+0x50]
00007957b0dd2ca0  por xmm3, xmm13
00007957b0dd2ca5  movaps [r15+0x300], xmm3
00007957b0dd2cad  vmovaps xmm15, [rsp+0xB0]
00007957b0dd2cb6  vpermilpd xmm15, xmm15, 0x00
00007957b0dd2cbc  vmovaps xmm3, [rsp+0x20]
00007957b0dd2cc2  vmovaps [rsp+0x20], xmm1
00007957b0dd2cc8  vmovaps xmm1, [rsp+0xE0]
00007957b0dd2cd1  vmovaps [rsp+0x50], xmm14
00007957b0dd2cd7  vmovaps [rsp+0x60], xmm13
00007957b0dd2cdd  movaps xmm14, xmm3
00007957b0dd2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007957b0dd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007957b0dd2cec  vptest xmm13, xmm13
00007957b0dd2cf1  jnz 0x00007957B0DD3F5D
00007957b0dd2cf7  vmovaps xmm1, [rsp+0xB0]
00007957b0dd2d00  vpermilpd xmm1, xmm1, 0x00
00007957b0dd2d06  vmovaps xmm15, [rsp+0x10]
00007957b0dd2d0c  movaps xmm13, xmm15
00007957b0dd2d10  vfmadd231pd xmm13, xmm10, xmm1
00007957b0dd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007957b0dd2d1b  vptest xmm3, xmm3
00007957b0dd2d20  jnz 0x00007957B0DD40B5
00007957b0dd2d26  vmovaps xmm1, [rsp+0xB0]
00007957b0dd2d2f  vpermilpd xmm1, xmm1, 0x00
00007957b0dd2d35  vmovaps xmm15, [rsp+0x30]
00007957b0dd2d3b  movaps xmm10, xmm15
00007957b0dd2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007957b0dd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007957b0dd2d4a  vptest xmm3, xmm3
00007957b0dd2d4f  jnz 0x00007957B0DD420E
00007957b0dd2d55  vmovaps xmm1, [rsp+0xB0]
00007957b0dd2d5e  vpermilpd xmm1, xmm1, 0x00
00007957b0dd2d64  movaps xmm15, xmm12
00007957b0dd2d68  vfmadd231pd xmm15, xmm5, xmm1
00007957b0dd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007957b0dd2d73  vptest xmm11, xmm11
00007957b0dd2d78  jnz 0x00007957B0DD4367
00007957b0dd2d7e  vmovaps [rsp+0x10], xmm9
00007957b0dd2d84  vmovaps xmm1, [rsp+0x10]
00007957b0dd2d8a  por xmm9, xmm1
00007957b0dd2d8f  movaps [r15+0x180], xmm9
00007957b0dd2d97  vmovaps [rsp+0x10], xmm2
00007957b0dd2d9d  vmovaps xmm1, [rsp+0x10]
00007957b0dd2da3  por xmm2, xmm1
00007957b0dd2da7  movaps [r15+0x2D0], xmm2
00007957b0dd2daf  vmovaps xmm12, [rsp+0xD0]
00007957b0dd2db8  vpermilpd xmm12, xmm12, 0x00
00007957b0dd2dbe  vmovaps xmm11, [rsp+0x60]
00007957b0dd2dc4  movaps xmm5, xmm13
00007957b0dd2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007957b0dd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007957b0dd2dd2  vptest xmm3, xmm3
00007957b0dd2dd7  jnz 0x00007957B0DD44BF
00007957b0dd2ddd  vmovaps xmm13, [rsp+0xD0]
00007957b0dd2de6  vpermilpd xmm13, xmm13, 0x00
00007957b0dd2dec  movaps xmm12, xmm14
00007957b0dd2df0  vfmadd231pd xmm12, xmm9, xmm13
00007957b0dd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007957b0dd2dfb  vptest xmm11, xmm11
00007957b0dd2e00  jnz 0x00007957B0DD4617
00007957b0dd2e06  lea rax, [r14+0x80]
00007957b0dd2e0d  movups xmm14, [r13+rax*1]
00007957b0dd2e13  movaps [r15+0x2F0], xmm14
00007957b0dd2e1b  vmovaps xmm13, [rsp+0xD0]
00007957b0dd2e24  vpermilpd xmm13, xmm13, 0x00
00007957b0dd2e2a  movaps xmm11, xmm10
00007957b0dd2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007957b0dd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007957b0dd2e39  vptest xmm9, xmm9
00007957b0dd2e3e  jnz 0x00007957B0DD477B
00007957b0dd2e44  vmovaps xmm13, [rsp+0xD0]
00007957b0dd2e4d  vpermilpd xmm13, xmm13, 0x00
00007957b0dd2e53  movaps xmm10, xmm15
00007957b0dd2e57  vfmadd231pd xmm10, xmm1, xmm13
00007957b0dd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007957b0dd2e62  vptest xmm9, xmm9
00007957b0dd2e67  jnz 0x00007957B0DD48D5
00007957b0dd2e6d  vmovaps [rsp+0x10], xmm7
00007957b0dd2e73  vmovaps xmm1, [rsp+0x10]
00007957b0dd2e79  por xmm7, xmm1
00007957b0dd2e7d  movaps [r15+0x160], xmm7
00007957b0dd2e85  lea rax, [r14+0x40]
00007957b0dd2e89  movups xmm1, [r13+rax*1]
00007957b0dd2e8f  lea rax, [r14+0x50]
00007957b0dd2e93  movups xmm15, [r13+rax*1]
00007957b0dd2e99  movaps [r15+0x1B0], xmm1
00007957b0dd2ea1  movaps [r15+0x1A0], xmm15
00007957b0dd2ea9  vmovaps xmm13, [rsp+0xA0]
00007957b0dd2eb2  vpermilpd xmm13, xmm13, 0x00
00007957b0dd2eb8  vmovaps xmm9, [rsp+0x40]
00007957b0dd2ebe  movaps xmm8, xmm5
00007957b0dd2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007957b0dd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007957b0dd2ecd  vptest xmm3, xmm3
00007957b0dd2ed2  jnz 0x00007957B0DD4A42
00007957b0dd2ed8  vmovaps xmm13, [rsp+0xA0]
00007957b0dd2ee1  vpermilpd xmm13, xmm13, 0x00
00007957b0dd2ee7  movaps xmm9, xmm12
00007957b0dd2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007957b0dd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007957b0dd2ef6  vptest xmm5, xmm5
00007957b0dd2efb  jnz 0x00007957B0DD4B9B
00007957b0dd2f01  vmovaps xmm13, [rsp+0xA0]
00007957b0dd2f0a  vpermilpd xmm13, xmm13, 0x00
00007957b0dd2f10  movaps xmm12, xmm11
00007957b0dd2f14  vfmadd231pd xmm12, xmm6, xmm13
00007957b0dd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007957b0dd2f1f  vptest xmm7, xmm7
00007957b0dd2f24  jnz 0x00007957B0DD4CF4
00007957b0dd2f2a  vmovaps xmm13, [rsp+0xA0]
00007957b0dd2f33  vpermilpd xmm13, xmm13, 0x00
00007957b0dd2f39  vmovaps xmm11, [rsp+0x50]
00007957b0dd2f3f  movaps xmm7, xmm10
00007957b0dd2f43  vfmadd231pd xmm7, xmm11, xmm13
00007957b0dd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007957b0dd2f4d  vptest xmm6, xmm6
00007957b0dd2f52  jnz 0x00007957B0DD4E4D
00007957b0dd2f58  lea rax, [r14+0x60]
00007957b0dd2f5c  movups xmm13, [r13+rax*1]
00007957b0dd2f62  lea rax, [r14+0x70]
00007957b0dd2f66  movups xmm11, [r13+rax*1]
00007957b0dd2f6c  movaps [r15+0x150], xmm13
00007957b0dd2f74  movaps [r15+0x120], xmm11
00007957b0dd2f7c  vmovaps xmm10, [rsp+0xC0]
00007957b0dd2f85  vpermilpd xmm10, xmm10, 0x00
00007957b0dd2f8b  movaps xmm6, xmm8
00007957b0dd2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007957b0dd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007957b0dd2f99  vptest xmm5, xmm5
00007957b0dd2f9e  jnz 0x00007957B0DD4FB9
00007957b0dd2fa4  vmovaps xmm15, [rsp+0xC0]
00007957b0dd2fad  vpermilpd xmm15, xmm15, 0x00
00007957b0dd2fb3  movaps xmm10, xmm9
00007957b0dd2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007957b0dd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007957b0dd2fc2  vptest xmm8, xmm8
00007957b0dd2fc7  jnz 0x00007957B0DD5111
00007957b0dd2fcd  vmovaps xmm15, [rsp+0xC0]
00007957b0dd2fd6  vpermilpd xmm15, xmm15, 0x00
00007957b0dd2fdc  movaps xmm13, xmm12
00007957b0dd2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007957b0dd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007957b0dd2feb  vptest xmm9, xmm9
00007957b0dd2ff0  jnz 0x00007957B0DD526B
00007957b0dd2ff6  vmovaps xmm15, [rsp+0xC0]
00007957b0dd2fff  vpermilpd xmm15, xmm15, 0x00
00007957b0dd3005  movaps xmm12, xmm7
00007957b0dd3009  vfmadd231pd xmm12, xmm1, xmm15
00007957b0dd300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007957b0dd3014  vptest xmm9, xmm9
00007957b0dd3019  jnz 0x00007957B0DD53C4
00007957b0dd301f  lea rax, [r14+0x20]
00007957b0dd3023  movups xmm1, [r13+rax*1]
00007957b0dd3029  lea rax, [r14+0x30]
00007957b0dd302d  movups xmm15, [r13+rax*1]
00007957b0dd3033  vmovaps xmm9, [rsp+0x70]
00007957b0dd3039  vpermilpd xmm9, xmm9, 0x00
00007957b0dd303f  vmovaps xmm8, [rsp+0x20]
00007957b0dd3045  movaps xmm7, xmm6
00007957b0dd3048  vfmadd231pd xmm7, xmm8, xmm9
00007957b0dd304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007957b0dd3052  vptest xmm5, xmm5
00007957b0dd3057  jnz 0x00007957B0DD5530
00007957b0dd305d  vmovaps xmm9, [rsp+0x70]
00007957b0dd3063  vpermilpd xmm9, xmm9, 0x00
00007957b0dd3069  movaps xmm8, xmm10
00007957b0dd306d  vfmadd231pd xmm8, xmm14, xmm9
00007957b0dd3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007957b0dd3078  vptest xmm6, xmm6
00007957b0dd307d  jnz 0x00007957B0DD5687
00007957b0dd3083  vmovaps xmm14, [rsp+0x70]
00007957b0dd3089  vpermilpd xmm14, xmm14, 0x00
00007957b0dd308f  movaps xmm10, xmm13
00007957b0dd3093  vfmadd231pd xmm10, xmm11, xmm14
00007957b0dd3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007957b0dd309e  vptest xmm9, xmm9
00007957b0dd30a3  jnz 0x00007957B0DD57E1
00007957b0dd30a9  vmovaps xmm14, [rsp+0x70]
00007957b0dd30af  vpermilpd xmm14, xmm14, 0x00
00007957b0dd30b5  movaps xmm13, xmm12
00007957b0dd30b9  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007957b0dd30c4  vptest xmm11, xmm11
00007957b0dd30c9  jnz 0x00007957B0DD593B
00007957b0dd30cf  lea rax, [r14+0x90]
00007957b0dd30d6  movups xmm15, [r13+rax*1]
00007957b0dd30dc  lea rax, [r14+0xA0]
00007957b0dd30e3  movups xmm14, [r13+rax*1]
00007957b0dd30e9  movaps [r15+0x140], xmm15
00007957b0dd30f1  movaps [r15+0x130], xmm14
00007957b0dd30f9  vmovaps xmm12, [rsp+0x90]
00007957b0dd3102  vpermilpd xmm12, xmm12, 0x00
00007957b0dd3108  movaps xmm11, xmm7
00007957b0dd310c  vfmadd231pd xmm11, xmm1, xmm12
00007957b0dd3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007957b0dd3117  vptest xmm9, xmm9
00007957b0dd311c  jnz 0x00007957B0DD5AA9
00007957b0dd3122  movaps [r15+0x220], xmm11
00007957b0dd312a  lea rax, [r14+0x10]
00007957b0dd312e  movups xmm1, [r13+rax*1]
00007957b0dd3134  movaps [r15+0x240], xmm1
00007957b0dd313c  vmovaps xmm12, [rsp+0x90]
00007957b0dd3145  vpermilpd xmm12, xmm12, 0x00
00007957b0dd314b  movaps xmm9, xmm8
00007957b0dd314f  vfmadd231pd xmm9, xmm14, xmm12
00007957b0dd3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007957b0dd315a  vptest xmm7, xmm7
00007957b0dd315f  jnz 0x00007957B0DD5C0B
00007957b0dd3165  movaps [r15+0x110], xmm9
00007957b0dd316d  vmovaps xmm14, [rsp+0x90]
00007957b0dd3176  vpermilpd xmm14, xmm14, 0x00
00007957b0dd317c  movaps xmm12, xmm10
00007957b0dd3180  vfmadd231pd xmm12, xmm15, xmm14
00007957b0dd3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007957b0dd318b  vptest xmm8, xmm8
00007957b0dd3190  jnz 0x00007957B0DD5D65
00007957b0dd3196  movaps [r15+0x170], xmm12
00007957b0dd319e  vmovaps xmm15, [rsp+0x90]
00007957b0dd31a7  vpermilpd xmm15, xmm15, 0x00
00007957b0dd31ad  movaps xmm14, xmm13
00007957b0dd31b1  vfmadd231pd xmm14, xmm1, xmm15
00007957b0dd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007957b0dd31bc  vptest xmm10, xmm10
00007957b0dd31c1  jnz 0x00007957B0DD5EBF
00007957b0dd31c7  movaps [r15+0x230], xmm14
00007957b0dd31cf  mov eax, 0x432190
00007957b0dd31d4  movups [r13+rax*1], xmm9
00007957b0dd31da  mov eax, 0x4321A0
00007957b0dd31df  movups [r13+rax*1], xmm12
00007957b0dd31e5  mov eax, 0x4321B0
00007957b0dd31ea  movups [r13+rax*1], xmm11
00007957b0dd31f0  mov eax, 0x4321C0
00007957b0dd31f5  movups [r13+rax*1], xmm14
00007957b0dd31fb  mov eax, [r15+0x108]
00007957b0dd3202  sahf
00007957b0dd3203  jnz 0x00007957B0DD3235
00007957b0dd3205  cmp dword ptr [r15+0x318], 0x00
00007957b0dd320d  jz 0x00007957B0DD9950
00007957b0dd3213  nop [rax+rax*1], ax
00007957b0dd321c  nop [rax+rax*1], eax
00007957b0dd3224  mov eax, 0x410664
00007957b0dd3229  mov [r15+0x100], rax
00007957b0dd3230  jmp 0x00007957B0BFE110
00007957b0dd3235  cmp dword ptr [r15+0x318], 0x00
00007957b0dd323d  jz 0x00007957B0DD6050
00007957b0dd3243  nop [rax+rax*1], ax
00007957b0dd324c  nop [rax+rax*1], eax
00007957b0dd3254  mov eax, 0x4104F0
00007957b0dd3259  mov [r15+0x100], rax
00007957b0dd3260  jmp 0x00007957B0BFE110
00007957b0dd3265  int3
00007957b0dd3266  call 0x00007957B0BFF430
00007957b0dd326b  jmp 0x00007957B0DD230A
00007957b0dd3270  call 0x00007957B0CE5820
00007957b0dd3275  jmp 0x00007957B0DD2314
00007957b0dd327a  call 0x00007957B0CE45A0
00007957b0dd327f  jmp 0x00007957B0DD2326
00007957b0dd3284  call 0x00007957B0CE3320
00007957b0dd3289  jmp 0x00007957B0DD2330
00007957b0dd328e  call 0x00007957B0CE20A0
00007957b0dd3293  jmp 0x00007957B0DD233D
00007957b0dd3298  call 0x00007957B0CE0E30
00007957b0dd329d  jmp 0x00007957B0DD234A
00007957b0dd32a2  call 0x00007957B0CD6600
00007957b0dd32a7  jmp 0x00007957B0DD2357
00007957b0dd32ac  call 0x00007957B0CB52F0
00007957b0dd32b1  jmp 0x00007957B0DD2361
00007957b0dd32b6  call 0x00007957B0CBE9C0
00007957b0dd32bb  jmp 0x00007957B0DD236B
00007957b0dd32c0  call 0x00007957B0CBD750
00007957b0dd32c5  jmp 0x00007957B0DD2378
00007957b0dd32ca  call 0x00007957B0CBC4E0
00007957b0dd32cf  jmp 0x00007957B0DD2385
00007957b0dd32d4  call 0x00007957B0CBB270
00007957b0dd32d9  jmp 0x00007957B0DD2392
00007957b0dd32de  call 0x00007957B0CBA000
00007957b0dd32e3  jmp 0x00007957B0DD239F
00007957b0dd32e8  call 0x00007957B0CB8D90
00007957b0dd32ed  jmp 0x00007957B0DD23AC
00007957b0dd32f2  call 0x00007957B0CB8A20
00007957b0dd32f7  jmp 0x00007957B0DD23B9
00007957b0dd32fc  call 0x00007957B0CBEAE0
00007957b0dd3301  jmp 0x00007957B0DD23C6
00007957b0dd3306  call 0x00007957B0CB5400
00007957b0dd330b  jmp 0x00007957B0DD23D3
00007957b0dd3310  call 0x00007957B0CB52F0
00007957b0dd3315  jmp 0x00007957B0DD23E0
00007957b0dd331a  call 0x00007957B0CBE9C0
00007957b0dd331f  jmp 0x00007957B0DD23ED
00007957b0dd3324  call 0x00007957B0CB77B0
00007957b0dd3329  jmp 0x00007957B0DD23FA
00007957b0dd332e  call 0x00007957B0CB6550
00007957b0dd3333  jmp 0x00007957B0DD2407
00007957b0dd3338  call 0x00007957B0CB52F0
00007957b0dd333d  jmp 0x00007957B0DD2417
00007957b0dd3342  call 0x00007957B0CB52F0
00007957b0dd3347  jmp 0x00007957B0DD2427
00007957b0dd334c  call 0x00007957B0CBEAE0
00007957b0dd3351  jmp 0x00007957B0DD2431
00007957b0dd3356  call 0x00007957B0CBEAE0
00007957b0dd335b  jmp 0x00007957B0DD2444
00007957b0dd3360  call 0x00007957B0CBE9C0
00007957b0dd3365  jmp 0x00007957B0DD2451
00007957b0dd336a  call 0x00007957B0CB52F0
00007957b0dd336f  jmp 0x00007957B0DD2464
00007957b0dd3374  call 0x00007957B0CB6660
00007957b0dd3379  jmp 0x00007957B0DD2471
00007957b0dd337e  call 0x00007957B0CB78C0
00007957b0dd3383  jmp 0x00007957B0DD247E
00007957b0dd3388  call 0x00007957B0CB77B0
00007957b0dd338d  jmp 0x00007957B0DD248B
00007957b0dd3392  call 0x00007957B0CB6550
00007957b0dd3397  jmp 0x00007957B0DD2498
00007957b0dd339c  call 0x00007957B0CB52F0
00007957b0dd33a1  jmp 0x00007957B0DD24AB
00007957b0dd33a6  call 0x00007957B0CB52F0
00007957b0dd33ab  jmp 0x00007957B0DD24BE
00007957b0dd33b0  call 0x00007957B0CB52F0
00007957b0dd33b5  jmp 0x00007957B0DD24E5
00007957b0dd33ba  call 0x00007957B0CB52F0
00007957b0dd33bf  jmp 0x00007957B0DD24F8
00007957b0dd33c4  call 0x00007957B0CB52F0
00007957b0dd33c9  jmp 0x00007957B0DD250B
00007957b0dd33ce  call 0x00007957B0CB52F0
00007957b0dd33d3  jmp 0x00007957B0DD2521
00007957b0dd33d8  call 0x00007957B0CB52F0
00007957b0dd33dd  jmp 0x00007957B0DD2537
00007957b0dd33e2  call 0x00007957B0CB52F0
00007957b0dd33e7  jmp 0x00007957B0DD254D
00007957b0dd33ec  call 0x00007957B0BFF540
00007957b0dd33f1  jmp 0x00007957B0DD256E
00007957b0dd33f6  call 0x00007957B0C02FE0
00007957b0dd33fb  jmp 0x00007957B0DD2578
00007957b0dd3400  call 0x00007957B0BFF540
00007957b0dd3405  jmp 0x00007957B0DD2588
00007957b0dd340a  call 0x00007957B0BFF540
00007957b0dd340f  jmp 0x00007957B0DD259B
00007957b0dd3414  call 0x00007957B0BFF540
00007957b0dd3419  jmp 0x00007957B0DD25AE
00007957b0dd341e  call 0x00007957B0BFF540
00007957b0dd3423  jmp 0x00007957B0DD25C1
00007957b0dd3428  call 0x00007957B0CC0370
00007957b0dd342d  jmp 0x00007957B0DD25E0
00007957b0dd3432  call 0x00007957B0CBF100
00007957b0dd3437  jmp 0x00007957B0DD25E9
00007957b0dd343c  call 0x00007957B0CC0370
00007957b0dd3441  jmp 0x00007957B0DD2659
00007957b0dd3446  call 0x00007957B0CBF100
00007957b0dd344b  jmp 0x00007957B0DD2662
00007957b0dd3450  call 0x00007957B0CC0370
00007957b0dd3455  jmp 0x00007957B0DD270C
00007957b0dd345a  call 0x00007957B0CBF100
00007957b0dd345f  jmp 0x00007957B0DD2715
00007957b0dd3464  call 0x00007957B0C0B720
00007957b0dd3469  jmp 0x00007957B0DD27F7
00007957b0dd346e  call 0x00007957B0CD64F0
00007957b0dd3473  jmp 0x00007957B0DD281F
00007957b0dd3478  call 0x00007957B0CB47C0
00007957b0dd347d  jmp 0x00007957B0DD283A
00007957b0dd3482  sub rsp, 0x08
00007957b0dd3486  push rax
00007957b0dd3487  push rcx
00007957b0dd3488  push rdx
00007957b0dd3489  push rdi
00007957b0dd348a  push rsi
00007957b0dd348b  push r8
00007957b0dd348d  push r9
00007957b0dd348f  push r10
00007957b0dd3491  push r11
00007957b0dd3493  sub rsp, 0xF0
00007957b0dd349a  vmovaps [rsp], xmm0
00007957b0dd349f  vmovaps [rsp+0x10], xmm1
00007957b0dd34a5  vmovaps [rsp+0x20], xmm2
00007957b0dd34ab  vmovaps [rsp+0x30], xmm3
00007957b0dd34b1  vmovaps [rsp+0x40], xmm4
00007957b0dd34b7  vmovaps [rsp+0x50], xmm5
00007957b0dd34bd  vmovaps [rsp+0x60], xmm6
00007957b0dd34c3  vmovaps [rsp+0x70], xmm7
00007957b0dd34c9  vmovaps [rsp+0x80], xmm8
00007957b0dd34d2  vmovaps [rsp+0x90], xmm9
00007957b0dd34db  vmovaps [rsp+0xA0], xmm10
00007957b0dd34e4  vmovaps [rsp+0xB0], xmm11
00007957b0dd34ed  vmovaps [rsp+0xC0], xmm12
00007957b0dd34f6  vmovaps [rsp+0xD0], xmm14
00007957b0dd34ff  vmovaps [rsp+0xE0], xmm15
00007957b0dd3508  sub rsp, 0x40
00007957b0dd350c  lea rdi, [rsp]
00007957b0dd3510  lea rsi, [rsp+0x10]
00007957b0dd3515  lea rdx, [rsp+0x20]
00007957b0dd351a  lea rcx, [rsp+0x30]
00007957b0dd351f  mov r8d, 0x00
00007957b0dd3525  lea r9, [r15+0x3A8]
00007957b0dd352c  movaps [rdi], xmm13
00007957b0dd3530  movaps [rsi], xmm1
00007957b0dd3533  movaps [rdx], xmm15
00007957b0dd3537  movaps [rcx], xmm14
00007957b0dd353b  mov rax, 0x56E396DF1A50
00007957b0dd3545  call rax
00007957b0dd3547  movaps xmm13, [rsp]
00007957b0dd354c  add rsp, 0x40
00007957b0dd3550  vmovaps xmm0, [rsp]
00007957b0dd3555  vmovaps xmm1, [rsp+0x10]
00007957b0dd355b  vmovaps xmm2, [rsp+0x20]
00007957b0dd3561  vmovaps xmm3, [rsp+0x30]
00007957b0dd3567  vmovaps xmm4, [rsp+0x40]
00007957b0dd356d  vmovaps xmm5, [rsp+0x50]
00007957b0dd3573  vmovaps xmm6, [rsp+0x60]
00007957b0dd3579  vmovaps xmm7, [rsp+0x70]
00007957b0dd357f  vmovaps xmm8, [rsp+0x80]
00007957b0dd3588  vmovaps xmm9, [rsp+0x90]
00007957b0dd3591  vmovaps xmm10, [rsp+0xA0]
00007957b0dd359a  vmovaps xmm11, [rsp+0xB0]
00007957b0dd35a3  vmovaps xmm12, [rsp+0xC0]
00007957b0dd35ac  vmovaps xmm14, [rsp+0xD0]
00007957b0dd35b5  vmovaps xmm15, [rsp+0xE0]
00007957b0dd35be  add rsp, 0xF0
00007957b0dd35c5  pop r11
00007957b0dd35c7  pop r10
00007957b0dd35c9  pop r9
00007957b0dd35cb  pop r8
00007957b0dd35cd  pop rsi
00007957b0dd35ce  pop rdi
00007957b0dd35cf  pop rdx
00007957b0dd35d0  pop rcx
00007957b0dd35d1  pop rax
00007957b0dd35d2  add rsp, 0x08
00007957b0dd35d6  jmp 0x00007957B0DD28AD
00007957b0dd35db  sub rsp, 0x08
00007957b0dd35df  push rax
00007957b0dd35e0  push rcx
00007957b0dd35e1  push rdx
00007957b0dd35e2  push rdi
00007957b0dd35e3  push rsi
00007957b0dd35e4  push r8
00007957b0dd35e6  push r9
00007957b0dd35e8  push r10
00007957b0dd35ea  push r11
00007957b0dd35ec  sub rsp, 0xF0
00007957b0dd35f3  vmovaps [rsp], xmm0
00007957b0dd35f8  vmovaps [rsp+0x10], xmm1
00007957b0dd35fe  vmovaps [rsp+0x20], xmm2
00007957b0dd3604  vmovaps [rsp+0x30], xmm3
00007957b0dd360a  vmovaps [rsp+0x40], xmm4
00007957b0dd3610  vmovaps [rsp+0x50], xmm5
00007957b0dd3616  vmovaps [rsp+0x60], xmm6
00007957b0dd361c  vmovaps [rsp+0x70], xmm7
00007957b0dd3622  vmovaps [rsp+0x80], xmm8
00007957b0dd362b  vmovaps [rsp+0x90], xmm9
00007957b0dd3634  vmovaps [rsp+0xA0], xmm10
00007957b0dd363d  vmovaps [rsp+0xB0], xmm11
00007957b0dd3646  vmovaps [rsp+0xC0], xmm12
00007957b0dd364f  vmovaps [rsp+0xD0], xmm13
00007957b0dd3658  vmovaps [rsp+0xE0], xmm14
00007957b0dd3661  sub rsp, 0x40
00007957b0dd3665  lea rdi, [rsp]
00007957b0dd3669  lea rsi, [rsp+0x10]
00007957b0dd366e  lea rdx, [rsp+0x20]
00007957b0dd3673  lea rcx, [rsp+0x30]
00007957b0dd3678  mov r8d, 0x00
00007957b0dd367e  lea r9, [r15+0x3A8]
00007957b0dd3685  movaps [rdi], xmm15
00007957b0dd3689  movaps [rsi], xmm5
00007957b0dd368c  movaps [rdx], xmm1
00007957b0dd368f  movaps [rcx], xmm14
00007957b0dd3693  mov rax, 0x56E396DF1A50
00007957b0dd369d  call rax
00007957b0dd369f  movaps xmm15, [rsp]
00007957b0dd36a4  add rsp, 0x40
00007957b0dd36a8  vmovaps xmm0, [rsp]
00007957b0dd36ad  vmovaps xmm1, [rsp+0x10]
00007957b0dd36b3  vmovaps xmm2, [rsp+0x20]
00007957b0dd36b9  vmovaps xmm3, [rsp+0x30]
00007957b0dd36bf  vmovaps xmm4, [rsp+0x40]
00007957b0dd36c5  vmovaps xmm5, [rsp+0x50]
00007957b0dd36cb  vmovaps xmm6, [rsp+0x60]
00007957b0dd36d1  vmovaps xmm7, [rsp+0x70]
00007957b0dd36d7  vmovaps xmm8, [rsp+0x80]
00007957b0dd36e0  vmovaps xmm9, [rsp+0x90]
00007957b0dd36e9  vmovaps xmm10, [rsp+0xA0]
00007957b0dd36f2  vmovaps xmm11, [rsp+0xB0]
00007957b0dd36fb  vmovaps xmm12, [rsp+0xC0]
00007957b0dd3704  vmovaps xmm13, [rsp+0xD0]
00007957b0dd370d  vmovaps xmm14, [rsp+0xE0]
00007957b0dd3716  add rsp, 0xF0
00007957b0dd371d  pop r11
00007957b0dd371f  pop r10
00007957b0dd3721  pop r9
00007957b0dd3723  pop r8
00007957b0dd3725  pop rsi
00007957b0dd3726  pop rdi
00007957b0dd3727  pop rdx
00007957b0dd3728  pop rcx
00007957b0dd3729  pop rax
00007957b0dd372a  add rsp, 0x08
00007957b0dd372e  jmp 0x00007957B0DD28D0
00007957b0dd3733  call 0x00007957B0BFF430
00007957b0dd3738  jmp 0x00007957B0DD295D
00007957b0dd373d  sub rsp, 0x08
00007957b0dd3741  push rax
00007957b0dd3742  push rcx
00007957b0dd3743  push rdx
00007957b0dd3744  push rdi
00007957b0dd3745  push rsi
00007957b0dd3746  push r8
00007957b0dd3748  push r9
00007957b0dd374a  push r10
00007957b0dd374c  push r11
00007957b0dd374e  sub rsp, 0xF0
00007957b0dd3755  vmovaps [rsp], xmm0
00007957b0dd375a  vmovaps [rsp+0x10], xmm1
00007957b0dd3760  vmovaps [rsp+0x20], xmm2
00007957b0dd3766  vmovaps [rsp+0x30], xmm3
00007957b0dd376c  vmovaps [rsp+0x40], xmm4
00007957b0dd3772  vmovaps [rsp+0x50], xmm5
00007957b0dd3778  vmovaps [rsp+0x60], xmm6
00007957b0dd377e  vmovaps [rsp+0x70], xmm7
00007957b0dd3784  vmovaps [rsp+0x80], xmm8
00007957b0dd378d  vmovaps [rsp+0x90], xmm9
00007957b0dd3796  vmovaps [rsp+0xA0], xmm10
00007957b0dd379f  vmovaps [rsp+0xB0], xmm11
00007957b0dd37a8  vmovaps [rsp+0xC0], xmm12
00007957b0dd37b1  vmovaps [rsp+0xD0], xmm14
00007957b0dd37ba  vmovaps [rsp+0xE0], xmm15
00007957b0dd37c3  sub rsp, 0x40
00007957b0dd37c7  lea rdi, [rsp]
00007957b0dd37cb  lea rsi, [rsp+0x10]
00007957b0dd37d0  lea rdx, [rsp+0x20]
00007957b0dd37d5  lea rcx, [rsp+0x30]
00007957b0dd37da  mov r8d, 0x00
00007957b0dd37e0  lea r9, [r15+0x3A8]
00007957b0dd37e7  movaps [rdi], xmm13
00007957b0dd37eb  movaps [rsi], xmm1
00007957b0dd37ee  movaps [rdx], xmm15
00007957b0dd37f2  movaps [rcx], xmm14
00007957b0dd37f6  mov rax, 0x56E396DF1A50
00007957b0dd3800  call rax
00007957b0dd3802  movaps xmm13, [rsp]
00007957b0dd3807  add rsp, 0x40
00007957b0dd380b  vmovaps xmm0, [rsp]
00007957b0dd3810  vmovaps xmm1, [rsp+0x10]
00007957b0dd3816  vmovaps xmm2, [rsp+0x20]
00007957b0dd381c  vmovaps xmm3, [rsp+0x30]
00007957b0dd3822  vmovaps xmm4, [rsp+0x40]
00007957b0dd3828  vmovaps xmm5, [rsp+0x50]
00007957b0dd382e  vmovaps xmm6, [rsp+0x60]
00007957b0dd3834  vmovaps xmm7, [rsp+0x70]
00007957b0dd383a  vmovaps xmm8, [rsp+0x80]
00007957b0dd3843  vmovaps xmm9, [rsp+0x90]
00007957b0dd384c  vmovaps xmm10, [rsp+0xA0]
00007957b0dd3855  vmovaps xmm11, [rsp+0xB0]
00007957b0dd385e  vmovaps xmm12, [rsp+0xC0]
00007957b0dd3867  vmovaps xmm14, [rsp+0xD0]
00007957b0dd3870  vmovaps xmm15, [rsp+0xE0]
00007957b0dd3879  add rsp, 0xF0
00007957b0dd3880  pop r11
00007957b0dd3882  pop r10
00007957b0dd3884  pop r9
00007957b0dd3886  pop r8
00007957b0dd3888  pop rsi
00007957b0dd3889  pop rdi
00007957b0dd388a  pop rdx
00007957b0dd388b  pop rcx
00007957b0dd388c  pop rax
00007957b0dd388d  add rsp, 0x08
00007957b0dd3891  jmp 0x00007957B0DD29C1
00007957b0dd3896  call 0x00007957B0BFF430
00007957b0dd389b  jmp 0x00007957B0DD29CE
00007957b0dd38a0  sub rsp, 0x08
00007957b0dd38a4  push rax
00007957b0dd38a5  push rcx
00007957b0dd38a6  push rdx
00007957b0dd38a7  push rdi
00007957b0dd38a8  push rsi
00007957b0dd38a9  push r8
00007957b0dd38ab  push r9
00007957b0dd38ad  push r10
00007957b0dd38af  push r11
00007957b0dd38b1  sub rsp, 0xF0
00007957b0dd38b8  vmovaps [rsp], xmm0
00007957b0dd38bd  vmovaps [rsp+0x10], xmm1
00007957b0dd38c3  vmovaps [rsp+0x20], xmm2
00007957b0dd38c9  vmovaps [rsp+0x30], xmm3
00007957b0dd38cf  vmovaps [rsp+0x40], xmm4
00007957b0dd38d5  vmovaps [rsp+0x50], xmm5
00007957b0dd38db  vmovaps [rsp+0x60], xmm6
00007957b0dd38e1  vmovaps [rsp+0x70], xmm7
00007957b0dd38e7  vmovaps [rsp+0x80], xmm8
00007957b0dd38f0  vmovaps [rsp+0x90], xmm9
00007957b0dd38f9  vmovaps [rsp+0xA0], xmm10
00007957b0dd3902  vmovaps [rsp+0xB0], xmm11
00007957b0dd390b  vmovaps [rsp+0xC0], xmm13
00007957b0dd3914  vmovaps [rsp+0xD0], xmm14
00007957b0dd391d  vmovaps [rsp+0xE0], xmm15
00007957b0dd3926  sub rsp, 0x40
00007957b0dd392a  lea rdi, [rsp]
00007957b0dd392e  lea rsi, [rsp+0x10]
00007957b0dd3933  lea rdx, [rsp+0x20]
00007957b0dd3938  lea rcx, [rsp+0x30]
00007957b0dd393d  mov r8d, 0x00
00007957b0dd3943  lea r9, [r15+0x3A8]
00007957b0dd394a  movaps [rdi], xmm12
00007957b0dd394e  movaps [rsi], xmm15
00007957b0dd3952  movaps [rdx], xmm1
00007957b0dd3955  movaps [rcx], xmm14
00007957b0dd3959  mov rax, 0x56E396DF1A50
00007957b0dd3963  call rax
00007957b0dd3965  movaps xmm12, [rsp]
00007957b0dd396a  add rsp, 0x40
00007957b0dd396e  vmovaps xmm0, [rsp]
00007957b0dd3973  vmovaps xmm1, [rsp+0x10]
00007957b0dd3979  vmovaps xmm2, [rsp+0x20]
00007957b0dd397f  vmovaps xmm3, [rsp+0x30]
00007957b0dd3985  vmovaps xmm4, [rsp+0x40]
00007957b0dd398b  vmovaps xmm5, [rsp+0x50]
00007957b0dd3991  vmovaps xmm6, [rsp+0x60]
00007957b0dd3997  vmovaps xmm7, [rsp+0x70]
00007957b0dd399d  vmovaps xmm8, [rsp+0x80]
00007957b0dd39a6  vmovaps xmm9, [rsp+0x90]
00007957b0dd39af  vmovaps xmm10, [rsp+0xA0]
00007957b0dd39b8  vmovaps xmm11, [rsp+0xB0]
00007957b0dd39c1  vmovaps xmm13, [rsp+0xC0]
00007957b0dd39ca  vmovaps xmm14, [rsp+0xD0]
00007957b0dd39d3  vmovaps xmm15, [rsp+0xE0]
00007957b0dd39dc  add rsp, 0xF0
00007957b0dd39e3  pop r11
00007957b0dd39e5  pop r10
00007957b0dd39e7  pop r9
00007957b0dd39e9  pop r8
00007957b0dd39eb  pop rsi
00007957b0dd39ec  pop rdi
00007957b0dd39ed  pop rdx
00007957b0dd39ee  pop rcx
00007957b0dd39ef  pop rax
00007957b0dd39f0  add rsp, 0x08
00007957b0dd39f4  jmp 0x00007957B0DD29FA
00007957b0dd39f9  sub rsp, 0x08
00007957b0dd39fd  push rax
00007957b0dd39fe  push rcx
00007957b0dd39ff  push rdx
00007957b0dd3a00  push rdi
00007957b0dd3a01  push rsi
00007957b0dd3a02  push r8
00007957b0dd3a04  push r9
00007957b0dd3a06  push r10
00007957b0dd3a08  push r11
00007957b0dd3a0a  sub rsp, 0xF0
00007957b0dd3a11  vmovaps [rsp], xmm0
00007957b0dd3a16  vmovaps [rsp+0x10], xmm1
00007957b0dd3a1c  vmovaps [rsp+0x20], xmm2
00007957b0dd3a22  vmovaps [rsp+0x30], xmm3
00007957b0dd3a28  vmovaps [rsp+0x40], xmm4
00007957b0dd3a2e  vmovaps [rsp+0x50], xmm5
00007957b0dd3a34  vmovaps [rsp+0x60], xmm6
00007957b0dd3a3a  vmovaps [rsp+0x70], xmm7
00007957b0dd3a40  vmovaps [rsp+0x80], xmm8
00007957b0dd3a49  vmovaps [rsp+0x90], xmm9
00007957b0dd3a52  vmovaps [rsp+0xA0], xmm10
00007957b0dd3a5b  vmovaps [rsp+0xB0], xmm11
00007957b0dd3a64  vmovaps [rsp+0xC0], xmm12
00007957b0dd3a6d  vmovaps [rsp+0xD0], xmm14
00007957b0dd3a76  vmovaps [rsp+0xE0], xmm15
00007957b0dd3a7f  sub rsp, 0x40
00007957b0dd3a83  lea rdi, [rsp]
00007957b0dd3a87  lea rsi, [rsp+0x10]
00007957b0dd3a8c  lea rdx, [rsp+0x20]
00007957b0dd3a91  lea rcx, [rsp+0x30]
00007957b0dd3a96  mov r8d, 0x00
00007957b0dd3a9c  lea r9, [r15+0x3A8]
00007957b0dd3aa3  movaps [rdi], xmm13
00007957b0dd3aa7  movaps [rsi], xmm1
00007957b0dd3aaa  movaps [rdx], xmm15
00007957b0dd3aae  movaps [rcx], xmm14
00007957b0dd3ab2  mov rax, 0x56E396DF1A50
00007957b0dd3abc  call rax
00007957b0dd3abe  movaps xmm13, [rsp]
00007957b0dd3ac3  add rsp, 0x40
00007957b0dd3ac7  vmovaps xmm0, [rsp]
00007957b0dd3acc  vmovaps xmm1, [rsp+0x10]
00007957b0dd3ad2  vmovaps xmm2, [rsp+0x20]
00007957b0dd3ad8  vmovaps xmm3, [rsp+0x30]
00007957b0dd3ade  vmovaps xmm4, [rsp+0x40]
00007957b0dd3ae4  vmovaps xmm5, [rsp+0x50]
00007957b0dd3aea  vmovaps xmm6, [rsp+0x60]
00007957b0dd3af0  vmovaps xmm7, [rsp+0x70]
00007957b0dd3af6  vmovaps xmm8, [rsp+0x80]
00007957b0dd3aff  vmovaps xmm9, [rsp+0x90]
00007957b0dd3b08  vmovaps xmm10, [rsp+0xA0]
00007957b0dd3b11  vmovaps xmm11, [rsp+0xB0]
00007957b0dd3b1a  vmovaps xmm12, [rsp+0xC0]
00007957b0dd3b23  vmovaps xmm14, [rsp+0xD0]
00007957b0dd3b2c  vmovaps xmm15, [rsp+0xE0]
00007957b0dd3b35  add rsp, 0xF0
00007957b0dd3b3c  pop r11
00007957b0dd3b3e  pop r10
00007957b0dd3b40  pop r9
00007957b0dd3b42  pop r8
00007957b0dd3b44  pop rsi
00007957b0dd3b45  pop rdi
00007957b0dd3b46  pop rdx
00007957b0dd3b47  pop rcx
00007957b0dd3b48  pop rax
00007957b0dd3b49  add rsp, 0x08
00007957b0dd3b4d  jmp 0x00007957B0DD2B77
00007957b0dd3b52  sub rsp, 0x08
00007957b0dd3b56  push rax
00007957b0dd3b57  push rcx
00007957b0dd3b58  push rdx
00007957b0dd3b59  push rdi
00007957b0dd3b5a  push rsi
00007957b0dd3b5b  push r8
00007957b0dd3b5d  push r9
00007957b0dd3b5f  push r10
00007957b0dd3b61  push r11
00007957b0dd3b63  sub rsp, 0xF0
00007957b0dd3b6a  vmovaps [rsp], xmm0
00007957b0dd3b6f  vmovaps [rsp+0x10], xmm1
00007957b0dd3b75  vmovaps [rsp+0x20], xmm2
00007957b0dd3b7b  vmovaps [rsp+0x30], xmm3
00007957b0dd3b81  vmovaps [rsp+0x40], xmm4
00007957b0dd3b87  vmovaps [rsp+0x50], xmm5
00007957b0dd3b8d  vmovaps [rsp+0x60], xmm6
00007957b0dd3b93  vmovaps [rsp+0x70], xmm7
00007957b0dd3b99  vmovaps [rsp+0x80], xmm8
00007957b0dd3ba2  vmovaps [rsp+0x90], xmm9
00007957b0dd3bab  vmovaps [rsp+0xA0], xmm10
00007957b0dd3bb4  vmovaps [rsp+0xB0], xmm11
00007957b0dd3bbd  vmovaps [rsp+0xC0], xmm13
00007957b0dd3bc6  vmovaps [rsp+0xD0], xmm14
00007957b0dd3bcf  vmovaps [rsp+0xE0], xmm15
00007957b0dd3bd8  sub rsp, 0x40
00007957b0dd3bdc  lea rdi, [rsp]
00007957b0dd3be0  lea rsi, [rsp+0x10]
00007957b0dd3be5  lea rdx, [rsp+0x20]
00007957b0dd3bea  lea rcx, [rsp+0x30]
00007957b0dd3bef  mov r8d, 0x00
00007957b0dd3bf5  lea r9, [r15+0x3A8]
00007957b0dd3bfc  movaps [rdi], xmm12
00007957b0dd3c00  movaps [rsi], xmm15
00007957b0dd3c04  movaps [rdx], xmm14
00007957b0dd3c08  movaps [rcx], xmm1
00007957b0dd3c0b  mov rax, 0x56E396DF1A50
00007957b0dd3c15  call rax
00007957b0dd3c17  movaps xmm12, [rsp]
00007957b0dd3c1c  add rsp, 0x40
00007957b0dd3c20  vmovaps xmm0, [rsp]
00007957b0dd3c25  vmovaps xmm1, [rsp+0x10]
00007957b0dd3c2b  vmovaps xmm2, [rsp+0x20]
00007957b0dd3c31  vmovaps xmm3, [rsp+0x30]
00007957b0dd3c37  vmovaps xmm4, [rsp+0x40]
00007957b0dd3c3d  vmovaps xmm5, [rsp+0x50]
00007957b0dd3c43  vmovaps xmm6, [rsp+0x60]
00007957b0dd3c49  vmovaps xmm7, [rsp+0x70]
00007957b0dd3c4f  vmovaps xmm8, [rsp+0x80]
00007957b0dd3c58  vmovaps xmm9, [rsp+0x90]
00007957b0dd3c61  vmovaps xmm10, [rsp+0xA0]
00007957b0dd3c6a  vmovaps xmm11, [rsp+0xB0]
00007957b0dd3c73  vmovaps xmm13, [rsp+0xC0]
00007957b0dd3c7c  vmovaps xmm14, [rsp+0xD0]
00007957b0dd3c85  vmovaps xmm15, [rsp+0xE0]
00007957b0dd3c8e  add rsp, 0xF0
00007957b0dd3c95  pop r11
00007957b0dd3c97  pop r10
00007957b0dd3c99  pop r9
00007957b0dd3c9b  pop r8
00007957b0dd3c9d  pop rsi
00007957b0dd3c9e  pop rdi
00007957b0dd3c9f  pop rdx
00007957b0dd3ca0  pop rcx
00007957b0dd3ca1  pop rax
00007957b0dd3ca2  add rsp, 0x08
00007957b0dd3ca6  jmp 0x00007957B0DD2BB2
00007957b0dd3cab  sub rsp, 0x08
00007957b0dd3caf  push rax
00007957b0dd3cb0  push rcx
00007957b0dd3cb1  push rdx
00007957b0dd3cb2  push rdi
00007957b0dd3cb3  push rsi
00007957b0dd3cb4  push r8
00007957b0dd3cb6  push r9
00007957b0dd3cb8  push r10
00007957b0dd3cba  push r11
00007957b0dd3cbc  sub rsp, 0xF0
00007957b0dd3cc3  vmovaps [rsp], xmm0
00007957b0dd3cc8  vmovaps [rsp+0x10], xmm1
00007957b0dd3cce  vmovaps [rsp+0x20], xmm2
00007957b0dd3cd4  vmovaps [rsp+0x30], xmm3
00007957b0dd3cda  vmovaps [rsp+0x40], xmm4
00007957b0dd3ce0  vmovaps [rsp+0x50], xmm5
00007957b0dd3ce6  vmovaps [rsp+0x60], xmm6
00007957b0dd3cec  vmovaps [rsp+0x70], xmm7
00007957b0dd3cf2  vmovaps [rsp+0x80], xmm8
00007957b0dd3cfb  vmovaps [rsp+0x90], xmm9
00007957b0dd3d04  vmovaps [rsp+0xA0], xmm10
00007957b0dd3d0d  vmovaps [rsp+0xB0], xmm11
00007957b0dd3d16  vmovaps [rsp+0xC0], xmm12
00007957b0dd3d1f  vmovaps [rsp+0xD0], xmm14
00007957b0dd3d28  vmovaps [rsp+0xE0], xmm15
00007957b0dd3d31  sub rsp, 0x40
00007957b0dd3d35  lea rdi, [rsp]
00007957b0dd3d39  lea rsi, [rsp+0x10]
00007957b0dd3d3e  lea rdx, [rsp+0x20]
00007957b0dd3d43  lea rcx, [rsp+0x30]
00007957b0dd3d48  mov r8d, 0x00
00007957b0dd3d4e  lea r9, [r15+0x3A8]
00007957b0dd3d55  movaps [rdi], xmm13
00007957b0dd3d59  movaps [rsi], xmm15
00007957b0dd3d5d  movaps [rdx], xmm14
00007957b0dd3d61  movaps [rcx], xmm1
00007957b0dd3d64  mov rax, 0x56E396DF1A50
00007957b0dd3d6e  call rax
00007957b0dd3d70  movaps xmm13, [rsp]
00007957b0dd3d75  add rsp, 0x40
00007957b0dd3d79  vmovaps xmm0, [rsp]
00007957b0dd3d7e  vmovaps xmm1, [rsp+0x10]
00007957b0dd3d84  vmovaps xmm2, [rsp+0x20]
00007957b0dd3d8a  vmovaps xmm3, [rsp+0x30]
00007957b0dd3d90  vmovaps xmm4, [rsp+0x40]
00007957b0dd3d96  vmovaps xmm5, [rsp+0x50]
00007957b0dd3d9c  vmovaps xmm6, [rsp+0x60]
00007957b0dd3da2  vmovaps xmm7, [rsp+0x70]
00007957b0dd3da8  vmovaps xmm8, [rsp+0x80]
00007957b0dd3db1  vmovaps xmm9, [rsp+0x90]
00007957b0dd3dba  vmovaps xmm10, [rsp+0xA0]
00007957b0dd3dc3  vmovaps xmm11, [rsp+0xB0]
00007957b0dd3dcc  vmovaps xmm12, [rsp+0xC0]
00007957b0dd3dd5  vmovaps xmm14, [rsp+0xD0]
00007957b0dd3dde  vmovaps xmm15, [rsp+0xE0]
00007957b0dd3de7  add rsp, 0xF0
00007957b0dd3dee  pop r11
00007957b0dd3df0  pop r10
00007957b0dd3df2  pop r9
00007957b0dd3df4  pop r8
00007957b0dd3df6  pop rsi
00007957b0dd3df7  pop rdi
00007957b0dd3df8  pop rdx
00007957b0dd3df9  pop rcx
00007957b0dd3dfa  pop rax
00007957b0dd3dfb  add rsp, 0x08
00007957b0dd3dff  jmp 0x00007957B0DD2BEA
00007957b0dd3e04  sub rsp, 0x08
00007957b0dd3e08  push rax
00007957b0dd3e09  push rcx
00007957b0dd3e0a  push rdx
00007957b0dd3e0b  push rdi
00007957b0dd3e0c  push rsi
00007957b0dd3e0d  push r8
00007957b0dd3e0f  push r9
00007957b0dd3e11  push r10
00007957b0dd3e13  push r11
00007957b0dd3e15  sub rsp, 0xF0
00007957b0dd3e1c  vmovaps [rsp], xmm0
00007957b0dd3e21  vmovaps [rsp+0x10], xmm1
00007957b0dd3e27  vmovaps [rsp+0x20], xmm2
00007957b0dd3e2d  vmovaps [rsp+0x30], xmm3
00007957b0dd3e33  vmovaps [rsp+0x40], xmm4
00007957b0dd3e39  vmovaps [rsp+0x50], xmm5
00007957b0dd3e3f  vmovaps [rsp+0x60], xmm6
00007957b0dd3e45  vmovaps [rsp+0x70], xmm7
00007957b0dd3e4b  vmovaps [rsp+0x80], xmm8
00007957b0dd3e54  vmovaps [rsp+0x90], xmm9
00007957b0dd3e5d  vmovaps [rsp+0xA0], xmm10
00007957b0dd3e66  vmovaps [rsp+0xB0], xmm11
00007957b0dd3e6f  vmovaps [rsp+0xC0], xmm13
00007957b0dd3e78  vmovaps [rsp+0xD0], xmm14
00007957b0dd3e81  vmovaps [rsp+0xE0], xmm15
00007957b0dd3e8a  sub rsp, 0x40
00007957b0dd3e8e  lea rdi, [rsp]
00007957b0dd3e92  lea rsi, [rsp+0x10]
00007957b0dd3e97  lea rdx, [rsp+0x20]
00007957b0dd3e9c  lea rcx, [rsp+0x30]
00007957b0dd3ea1  mov r8d, 0x00
00007957b0dd3ea7  lea r9, [r15+0x3A8]
00007957b0dd3eae  movaps [rdi], xmm12
00007957b0dd3eb2  movaps [rsi], xmm15
00007957b0dd3eb6  movaps [rdx], xmm14
00007957b0dd3eba  movaps [rcx], xmm1
00007957b0dd3ebd  mov rax, 0x56E396DF1A50
00007957b0dd3ec7  call rax
00007957b0dd3ec9  movaps xmm12, [rsp]
00007957b0dd3ece  add rsp, 0x40
00007957b0dd3ed2  vmovaps xmm0, [rsp]
00007957b0dd3ed7  vmovaps xmm1, [rsp+0x10]
00007957b0dd3edd  vmovaps xmm2, [rsp+0x20]
00007957b0dd3ee3  vmovaps xmm3, [rsp+0x30]
00007957b0dd3ee9  vmovaps xmm4, [rsp+0x40]
00007957b0dd3eef  vmovaps xmm5, [rsp+0x50]
00007957b0dd3ef5  vmovaps xmm6, [rsp+0x60]
00007957b0dd3efb  vmovaps xmm7, [rsp+0x70]
00007957b0dd3f01  vmovaps xmm8, [rsp+0x80]
00007957b0dd3f0a  vmovaps xmm9, [rsp+0x90]
00007957b0dd3f13  vmovaps xmm10, [rsp+0xA0]
00007957b0dd3f1c  vmovaps xmm11, [rsp+0xB0]
00007957b0dd3f25  vmovaps xmm13, [rsp+0xC0]
00007957b0dd3f2e  vmovaps xmm14, [rsp+0xD0]
00007957b0dd3f37  vmovaps xmm15, [rsp+0xE0]
00007957b0dd3f40  add rsp, 0xF0
00007957b0dd3f47  pop r11
00007957b0dd3f49  pop r10
00007957b0dd3f4b  pop r9
00007957b0dd3f4d  pop r8
00007957b0dd3f4f  pop rsi
00007957b0dd3f50  pop rdi
00007957b0dd3f51  pop rdx
00007957b0dd3f52  pop rcx
00007957b0dd3f53  pop rax
00007957b0dd3f54  add rsp, 0x08
00007957b0dd3f58  jmp 0x00007957B0DD2C3D
00007957b0dd3f5d  sub rsp, 0x08
00007957b0dd3f61  push rax
00007957b0dd3f62  push rcx
00007957b0dd3f63  push rdx
00007957b0dd3f64  push rdi
00007957b0dd3f65  push rsi
00007957b0dd3f66  push r8
00007957b0dd3f68  push r9
00007957b0dd3f6a  push r10
00007957b0dd3f6c  push r11
00007957b0dd3f6e  sub rsp, 0xF0
00007957b0dd3f75  vmovaps [rsp], xmm0
00007957b0dd3f7a  vmovaps [rsp+0x10], xmm1
00007957b0dd3f80  vmovaps [rsp+0x20], xmm2
00007957b0dd3f86  vmovaps [rsp+0x30], xmm3
00007957b0dd3f8c  vmovaps [rsp+0x40], xmm4
00007957b0dd3f92  vmovaps [rsp+0x50], xmm5
00007957b0dd3f98  vmovaps [rsp+0x60], xmm6
00007957b0dd3f9e  vmovaps [rsp+0x70], xmm7
00007957b0dd3fa4  vmovaps [rsp+0x80], xmm8
00007957b0dd3fad  vmovaps [rsp+0x90], xmm9
00007957b0dd3fb6  vmovaps [rsp+0xA0], xmm10
00007957b0dd3fbf  vmovaps [rsp+0xB0], xmm11
00007957b0dd3fc8  vmovaps [rsp+0xC0], xmm12
00007957b0dd3fd1  vmovaps [rsp+0xD0], xmm13
00007957b0dd3fda  vmovaps [rsp+0xE0], xmm15
00007957b0dd3fe3  sub rsp, 0x40
00007957b0dd3fe7  lea rdi, [rsp]
00007957b0dd3feb  lea rsi, [rsp+0x10]
00007957b0dd3ff0  lea rdx, [rsp+0x20]
00007957b0dd3ff5  lea rcx, [rsp+0x30]
00007957b0dd3ffa  mov r8d, 0x00
00007957b0dd4000  lea r9, [r15+0x3A8]
00007957b0dd4007  movaps [rdi], xmm14
00007957b0dd400b  movaps [rsi], xmm3
00007957b0dd400e  movaps [rdx], xmm1
00007957b0dd4011  movaps [rcx], xmm15
00007957b0dd4015  mov rax, 0x56E396DF1A50
00007957b0dd401f  call rax
00007957b0dd4021  movaps xmm14, [rsp]
00007957b0dd4026  add rsp, 0x40
00007957b0dd402a  vmovaps xmm0, [rsp]
00007957b0dd402f  vmovaps xmm1, [rsp+0x10]
00007957b0dd4035  vmovaps xmm2, [rsp+0x20]
00007957b0dd403b  vmovaps xmm3, [rsp+0x30]
00007957b0dd4041  vmovaps xmm4, [rsp+0x40]
00007957b0dd4047  vmovaps xmm5, [rsp+0x50]
00007957b0dd404d  vmovaps xmm6, [rsp+0x60]
00007957b0dd4053  vmovaps xmm7, [rsp+0x70]
00007957b0dd4059  vmovaps xmm8, [rsp+0x80]
00007957b0dd4062  vmovaps xmm9, [rsp+0x90]
00007957b0dd406b  vmovaps xmm10, [rsp+0xA0]
00007957b0dd4074  vmovaps xmm11, [rsp+0xB0]
00007957b0dd407d  vmovaps xmm12, [rsp+0xC0]
00007957b0dd4086  vmovaps xmm13, [rsp+0xD0]
00007957b0dd408f  vmovaps xmm15, [rsp+0xE0]
00007957b0dd4098  add rsp, 0xF0
00007957b0dd409f  pop r11
00007957b0dd40a1  pop r10
00007957b0dd40a3  pop r9
00007957b0dd40a5  pop r8
00007957b0dd40a7  pop rsi
00007957b0dd40a8  pop rdi
00007957b0dd40a9  pop rdx
00007957b0dd40aa  pop rcx
00007957b0dd40ab  pop rax
00007957b0dd40ac  add rsp, 0x08
00007957b0dd40b0  jmp 0x00007957B0DD2CF7
00007957b0dd40b5  sub rsp, 0x08
00007957b0dd40b9  push rax
00007957b0dd40ba  push rcx
00007957b0dd40bb  push rdx
00007957b0dd40bc  push rdi
00007957b0dd40bd  push rsi
00007957b0dd40be  push r8
00007957b0dd40c0  push r9
00007957b0dd40c2  push r10
00007957b0dd40c4  push r11
00007957b0dd40c6  sub rsp, 0xF0
00007957b0dd40cd  vmovaps [rsp], xmm0
00007957b0dd40d2  vmovaps [rsp+0x10], xmm1
00007957b0dd40d8  vmovaps [rsp+0x20], xmm2
00007957b0dd40de  vmovaps [rsp+0x30], xmm3
00007957b0dd40e4  vmovaps [rsp+0x40], xmm4
00007957b0dd40ea  vmovaps [rsp+0x50], xmm5
00007957b0dd40f0  vmovaps [rsp+0x60], xmm6
00007957b0dd40f6  vmovaps [rsp+0x70], xmm7
00007957b0dd40fc  vmovaps [rsp+0x80], xmm8
00007957b0dd4105  vmovaps [rsp+0x90], xmm9
00007957b0dd410e  vmovaps [rsp+0xA0], xmm10
00007957b0dd4117  vmovaps [rsp+0xB0], xmm11
00007957b0dd4120  vmovaps [rsp+0xC0], xmm12
00007957b0dd4129  vmovaps [rsp+0xD0], xmm14
00007957b0dd4132  vmovaps [rsp+0xE0], xmm15
00007957b0dd413b  sub rsp, 0x40
00007957b0dd413f  lea rdi, [rsp]
00007957b0dd4143  lea rsi, [rsp+0x10]
00007957b0dd4148  lea rdx, [rsp+0x20]
00007957b0dd414d  lea rcx, [rsp+0x30]
00007957b0dd4152  mov r8d, 0x00
00007957b0dd4158  lea r9, [r15+0x3A8]
00007957b0dd415f  movaps [rdi], xmm13
00007957b0dd4163  movaps [rsi], xmm15
00007957b0dd4167  movaps [rdx], xmm10
00007957b0dd416b  movaps [rcx], xmm1
00007957b0dd416e  mov rax, 0x56E396DF1A50
00007957b0dd4178  call rax
00007957b0dd417a  movaps xmm13, [rsp]
00007957b0dd417f  add rsp, 0x40
00007957b0dd4183  vmovaps xmm0, [rsp]
00007957b0dd4188  vmovaps xmm1, [rsp+0x10]
00007957b0dd418e  vmovaps xmm2, [rsp+0x20]
00007957b0dd4194  vmovaps xmm3, [rsp+0x30]
00007957b0dd419a  vmovaps xmm4, [rsp+0x40]
00007957b0dd41a0  vmovaps xmm5, [rsp+0x50]
00007957b0dd41a6  vmovaps xmm6, [rsp+0x60]
00007957b0dd41ac  vmovaps xmm7, [rsp+0x70]
00007957b0dd41b2  vmovaps xmm8, [rsp+0x80]
00007957b0dd41bb  vmovaps xmm9, [rsp+0x90]
00007957b0dd41c4  vmovaps xmm10, [rsp+0xA0]
00007957b0dd41cd  vmovaps xmm11, [rsp+0xB0]
00007957b0dd41d6  vmovaps xmm12, [rsp+0xC0]
00007957b0dd41df  vmovaps xmm14, [rsp+0xD0]
00007957b0dd41e8  vmovaps xmm15, [rsp+0xE0]
00007957b0dd41f1  add rsp, 0xF0
00007957b0dd41f8  pop r11
00007957b0dd41fa  pop r10
00007957b0dd41fc  pop r9
00007957b0dd41fe  pop r8
00007957b0dd4200  pop rsi
00007957b0dd4201  pop rdi
00007957b0dd4202  pop rdx
00007957b0dd4203  pop rcx
00007957b0dd4204  pop rax
00007957b0dd4205  add rsp, 0x08
00007957b0dd4209  jmp 0x00007957B0DD2D26
00007957b0dd420e  sub rsp, 0x08
00007957b0dd4212  push rax
00007957b0dd4213  push rcx
00007957b0dd4214  push rdx
00007957b0dd4215  push rdi
00007957b0dd4216  push rsi
00007957b0dd4217  push r8
00007957b0dd4219  push r9
00007957b0dd421b  push r10
00007957b0dd421d  push r11
00007957b0dd421f  sub rsp, 0xF0
00007957b0dd4226  vmovaps [rsp], xmm0
00007957b0dd422b  vmovaps [rsp+0x10], xmm1
00007957b0dd4231  vmovaps [rsp+0x20], xmm2
00007957b0dd4237  vmovaps [rsp+0x30], xmm3
00007957b0dd423d  vmovaps [rsp+0x40], xmm4
00007957b0dd4243  vmovaps [rsp+0x50], xmm5
00007957b0dd4249  vmovaps [rsp+0x60], xmm6
00007957b0dd424f  vmovaps [rsp+0x70], xmm7
00007957b0dd4255  vmovaps [rsp+0x80], xmm8
00007957b0dd425e  vmovaps [rsp+0x90], xmm9
00007957b0dd4267  vmovaps [rsp+0xA0], xmm11
00007957b0dd4270  vmovaps [rsp+0xB0], xmm12
00007957b0dd4279  vmovaps [rsp+0xC0], xmm13
00007957b0dd4282  vmovaps [rsp+0xD0], xmm14
00007957b0dd428b  vmovaps [rsp+0xE0], xmm15
00007957b0dd4294  sub rsp, 0x40
00007957b0dd4298  lea rdi, [rsp]
00007957b0dd429c  lea rsi, [rsp+0x10]
00007957b0dd42a1  lea rdx, [rsp+0x20]
00007957b0dd42a6  lea rcx, [rsp+0x30]
00007957b0dd42ab  mov r8d, 0x00
00007957b0dd42b1  lea r9, [r15+0x3A8]
00007957b0dd42b8  movaps [rdi], xmm10
00007957b0dd42bc  movaps [rsi], xmm15
00007957b0dd42c0  movaps [rdx], xmm11
00007957b0dd42c4  movaps [rcx], xmm1
00007957b0dd42c7  mov rax, 0x56E396DF1A50
00007957b0dd42d1  call rax
00007957b0dd42d3  movaps xmm10, [rsp]
00007957b0dd42d8  add rsp, 0x40
00007957b0dd42dc  vmovaps xmm0, [rsp]
00007957b0dd42e1  vmovaps xmm1, [rsp+0x10]
00007957b0dd42e7  vmovaps xmm2, [rsp+0x20]
00007957b0dd42ed  vmovaps xmm3, [rsp+0x30]
00007957b0dd42f3  vmovaps xmm4, [rsp+0x40]
00007957b0dd42f9  vmovaps xmm5, [rsp+0x50]
00007957b0dd42ff  vmovaps xmm6, [rsp+0x60]
00007957b0dd4305  vmovaps xmm7, [rsp+0x70]
00007957b0dd430b  vmovaps xmm8, [rsp+0x80]
00007957b0dd4314  vmovaps xmm9, [rsp+0x90]
00007957b0dd431d  vmovaps xmm11, [rsp+0xA0]
00007957b0dd4326  vmovaps xmm12, [rsp+0xB0]
00007957b0dd432f  vmovaps xmm13, [rsp+0xC0]
00007957b0dd4338  vmovaps xmm14, [rsp+0xD0]
00007957b0dd4341  vmovaps xmm15, [rsp+0xE0]
00007957b0dd434a  add rsp, 0xF0
00007957b0dd4351  pop r11
00007957b0dd4353  pop r10
00007957b0dd4355  pop r9
00007957b0dd4357  pop r8
00007957b0dd4359  pop rsi
00007957b0dd435a  pop rdi
00007957b0dd435b  pop rdx
00007957b0dd435c  pop rcx
00007957b0dd435d  pop rax
00007957b0dd435e  add rsp, 0x08
00007957b0dd4362  jmp 0x00007957B0DD2D55
00007957b0dd4367  sub rsp, 0x08
00007957b0dd436b  push rax
00007957b0dd436c  push rcx
00007957b0dd436d  push rdx
00007957b0dd436e  push rdi
00007957b0dd436f  push rsi
00007957b0dd4370  push r8
00007957b0dd4372  push r9
00007957b0dd4374  push r10
00007957b0dd4376  push r11
00007957b0dd4378  sub rsp, 0xF0
00007957b0dd437f  vmovaps [rsp], xmm0
00007957b0dd4384  vmovaps [rsp+0x10], xmm1
00007957b0dd438a  vmovaps [rsp+0x20], xmm2
00007957b0dd4390  vmovaps [rsp+0x30], xmm3
00007957b0dd4396  vmovaps [rsp+0x40], xmm4
00007957b0dd439c  vmovaps [rsp+0x50], xmm5
00007957b0dd43a2  vmovaps [rsp+0x60], xmm6
00007957b0dd43a8  vmovaps [rsp+0x70], xmm7
00007957b0dd43ae  vmovaps [rsp+0x80], xmm8
00007957b0dd43b7  vmovaps [rsp+0x90], xmm9
00007957b0dd43c0  vmovaps [rsp+0xA0], xmm10
00007957b0dd43c9  vmovaps [rsp+0xB0], xmm11
00007957b0dd43d2  vmovaps [rsp+0xC0], xmm12
00007957b0dd43db  vmovaps [rsp+0xD0], xmm13
00007957b0dd43e4  vmovaps [rsp+0xE0], xmm14
00007957b0dd43ed  sub rsp, 0x40
00007957b0dd43f1  lea rdi, [rsp]
00007957b0dd43f5  lea rsi, [rsp+0x10]
00007957b0dd43fa  lea rdx, [rsp+0x20]
00007957b0dd43ff  lea rcx, [rsp+0x30]
00007957b0dd4404  mov r8d, 0x00
00007957b0dd440a  lea r9, [r15+0x3A8]
00007957b0dd4411  movaps [rdi], xmm15
00007957b0dd4415  movaps [rsi], xmm12
00007957b0dd4419  movaps [rdx], xmm5
00007957b0dd441c  movaps [rcx], xmm1
00007957b0dd441f  mov rax, 0x56E396DF1A50
00007957b0dd4429  call rax
00007957b0dd442b  movaps xmm15, [rsp]
00007957b0dd4430  add rsp, 0x40
00007957b0dd4434  vmovaps xmm0, [rsp]
00007957b0dd4439  vmovaps xmm1, [rsp+0x10]
00007957b0dd443f  vmovaps xmm2, [rsp+0x20]
00007957b0dd4445  vmovaps xmm3, [rsp+0x30]
00007957b0dd444b  vmovaps xmm4, [rsp+0x40]
00007957b0dd4451  vmovaps xmm5, [rsp+0x50]
00007957b0dd4457  vmovaps xmm6, [rsp+0x60]
00007957b0dd445d  vmovaps xmm7, [rsp+0x70]
00007957b0dd4463  vmovaps xmm8, [rsp+0x80]
00007957b0dd446c  vmovaps xmm9, [rsp+0x90]
00007957b0dd4475  vmovaps xmm10, [rsp+0xA0]
00007957b0dd447e  vmovaps xmm11, [rsp+0xB0]
00007957b0dd4487  vmovaps xmm12, [rsp+0xC0]
00007957b0dd4490  vmovaps xmm13, [rsp+0xD0]
00007957b0dd4499  vmovaps xmm14, [rsp+0xE0]
00007957b0dd44a2  add rsp, 0xF0
00007957b0dd44a9  pop r11
00007957b0dd44ab  pop r10
00007957b0dd44ad  pop r9
00007957b0dd44af  pop r8
00007957b0dd44b1  pop rsi
00007957b0dd44b2  pop rdi
00007957b0dd44b3  pop rdx
00007957b0dd44b4  pop rcx
00007957b0dd44b5  pop rax
00007957b0dd44b6  add rsp, 0x08
00007957b0dd44ba  jmp 0x00007957B0DD2D7E
00007957b0dd44bf  sub rsp, 0x08
00007957b0dd44c3  push rax
00007957b0dd44c4  push rcx
00007957b0dd44c5  push rdx
00007957b0dd44c6  push rdi
00007957b0dd44c7  push rsi
00007957b0dd44c8  push r8
00007957b0dd44ca  push r9
00007957b0dd44cc  push r10
00007957b0dd44ce  push r11
00007957b0dd44d0  sub rsp, 0xF0
00007957b0dd44d7  vmovaps [rsp], xmm0
00007957b0dd44dc  vmovaps [rsp+0x10], xmm1
00007957b0dd44e2  vmovaps [rsp+0x20], xmm2
00007957b0dd44e8  vmovaps [rsp+0x30], xmm3
00007957b0dd44ee  vmovaps [rsp+0x40], xmm4
00007957b0dd44f4  vmovaps [rsp+0x50], xmm6
00007957b0dd44fa  vmovaps [rsp+0x60], xmm7
00007957b0dd4500  vmovaps [rsp+0x70], xmm8
00007957b0dd4506  vmovaps [rsp+0x80], xmm9
00007957b0dd450f  vmovaps [rsp+0x90], xmm10
00007957b0dd4518  vmovaps [rsp+0xA0], xmm11
00007957b0dd4521  vmovaps [rsp+0xB0], xmm12
00007957b0dd452a  vmovaps [rsp+0xC0], xmm13
00007957b0dd4533  vmovaps [rsp+0xD0], xmm14
00007957b0dd453c  vmovaps [rsp+0xE0], xmm15
00007957b0dd4545  sub rsp, 0x40
00007957b0dd4549  lea rdi, [rsp]
00007957b0dd454d  lea rsi, [rsp+0x10]
00007957b0dd4552  lea rdx, [rsp+0x20]
00007957b0dd4557  lea rcx, [rsp+0x30]
00007957b0dd455c  mov r8d, 0x00
00007957b0dd4562  lea r9, [r15+0x3A8]
00007957b0dd4569  movaps [rdi], xmm5
00007957b0dd456c  movaps [rsi], xmm13
00007957b0dd4570  movaps [rdx], xmm11
00007957b0dd4574  movaps [rcx], xmm12
00007957b0dd4578  mov rax, 0x56E396DF1A50
00007957b0dd4582  call rax
00007957b0dd4584  movaps xmm5, [rsp]
00007957b0dd4588  add rsp, 0x40
00007957b0dd458c  vmovaps xmm0, [rsp]
00007957b0dd4591  vmovaps xmm1, [rsp+0x10]
00007957b0dd4597  vmovaps xmm2, [rsp+0x20]
00007957b0dd459d  vmovaps xmm3, [rsp+0x30]
00007957b0dd45a3  vmovaps xmm4, [rsp+0x40]
00007957b0dd45a9  vmovaps xmm6, [rsp+0x50]
00007957b0dd45af  vmovaps xmm7, [rsp+0x60]
00007957b0dd45b5  vmovaps xmm8, [rsp+0x70]
00007957b0dd45bb  vmovaps xmm9, [rsp+0x80]
00007957b0dd45c4  vmovaps xmm10, [rsp+0x90]
00007957b0dd45cd  vmovaps xmm11, [rsp+0xA0]
00007957b0dd45d6  vmovaps xmm12, [rsp+0xB0]
00007957b0dd45df  vmovaps xmm13, [rsp+0xC0]
00007957b0dd45e8  vmovaps xmm14, [rsp+0xD0]
00007957b0dd45f1  vmovaps xmm15, [rsp+0xE0]
00007957b0dd45fa  add rsp, 0xF0
00007957b0dd4601  pop r11
00007957b0dd4603  pop r10
00007957b0dd4605  pop r9
00007957b0dd4607  pop r8
00007957b0dd4609  pop rsi
00007957b0dd460a  pop rdi
00007957b0dd460b  pop rdx
00007957b0dd460c  pop rcx
00007957b0dd460d  pop rax
00007957b0dd460e  add rsp, 0x08
00007957b0dd4612  jmp 0x00007957B0DD2DDD
00007957b0dd4617  sub rsp, 0x08
00007957b0dd461b  push rax
00007957b0dd461c  push rcx
00007957b0dd461d  push rdx
00007957b0dd461e  push rdi
00007957b0dd461f  push rsi
00007957b0dd4620  push r8
00007957b0dd4622  push r9
00007957b0dd4624  push r10
00007957b0dd4626  push r11
00007957b0dd4628  sub rsp, 0xF0
00007957b0dd462f  vmovaps [rsp], xmm0
00007957b0dd4634  vmovaps [rsp+0x10], xmm1
00007957b0dd463a  vmovaps [rsp+0x20], xmm2
00007957b0dd4640  vmovaps [rsp+0x30], xmm3
00007957b0dd4646  vmovaps [rsp+0x40], xmm4
00007957b0dd464c  vmovaps [rsp+0x50], xmm5
00007957b0dd4652  vmovaps [rsp+0x60], xmm6
00007957b0dd4658  vmovaps [rsp+0x70], xmm7
00007957b0dd465e  vmovaps [rsp+0x80], xmm8
00007957b0dd4667  vmovaps [rsp+0x90], xmm9
00007957b0dd4670  vmovaps [rsp+0xA0], xmm10
00007957b0dd4679  vmovaps [rsp+0xB0], xmm11
00007957b0dd4682  vmovaps [rsp+0xC0], xmm13
00007957b0dd468b  vmovaps [rsp+0xD0], xmm14
00007957b0dd4694  vmovaps [rsp+0xE0], xmm15
00007957b0dd469d  sub rsp, 0x40
00007957b0dd46a1  lea rdi, [rsp]
00007957b0dd46a5  lea rsi, [rsp+0x10]
00007957b0dd46aa  lea rdx, [rsp+0x20]
00007957b0dd46af  lea rcx, [rsp+0x30]
00007957b0dd46b4  mov r8d, 0x00
00007957b0dd46ba  lea r9, [r15+0x3A8]
00007957b0dd46c1  movaps [rdi], xmm12
00007957b0dd46c5  movaps [rsi], xmm14
00007957b0dd46c9  movaps [rdx], xmm9
00007957b0dd46cd  movaps [rcx], xmm13
00007957b0dd46d1  mov rax, 0x56E396DF1A50
00007957b0dd46db  call rax
00007957b0dd46dd  movaps xmm12, [rsp]
00007957b0dd46e2  add rsp, 0x40
00007957b0dd46e6  vmovaps xmm0, [rsp]
00007957b0dd46eb  vmovaps xmm1, [rsp+0x10]
00007957b0dd46f1  vmovaps xmm2, [rsp+0x20]
00007957b0dd46f7  vmovaps xmm3, [rsp+0x30]
00007957b0dd46fd  vmovaps xmm4, [rsp+0x40]
00007957b0dd4703  vmovaps xmm5, [rsp+0x50]
00007957b0dd4709  vmovaps xmm6, [rsp+0x60]
00007957b0dd470f  vmovaps xmm7, [rsp+0x70]
00007957b0dd4715  vmovaps xmm8, [rsp+0x80]
00007957b0dd471e  vmovaps xmm9, [rsp+0x90]
00007957b0dd4727  vmovaps xmm10, [rsp+0xA0]
00007957b0dd4730  vmovaps xmm11, [rsp+0xB0]
00007957b0dd4739  vmovaps xmm13, [rsp+0xC0]
00007957b0dd4742  vmovaps xmm14, [rsp+0xD0]
00007957b0dd474b  vmovaps xmm15, [rsp+0xE0]
00007957b0dd4754  add rsp, 0xF0
00007957b0dd475b  pop r11
00007957b0dd475d  pop r10
00007957b0dd475f  pop r9
00007957b0dd4761  pop r8
00007957b0dd4763  pop rsi
00007957b0dd4764  pop rdi
00007957b0dd4765  pop rdx
00007957b0dd4766  pop rcx
00007957b0dd4767  pop rax
00007957b0dd4768  add rsp, 0x08
00007957b0dd476c  jmp 0x00007957B0DD2E06
00007957b0dd4771  call 0x00007957B0C0D4E0
00007957b0dd4776  jmp 0x00007957B0DD2E13
00007957b0dd477b  sub rsp, 0x08
00007957b0dd477f  push rax
00007957b0dd4780  push rcx
00007957b0dd4781  push rdx
00007957b0dd4782  push rdi
00007957b0dd4783  push rsi
00007957b0dd4784  push r8
00007957b0dd4786  push r9
00007957b0dd4788  push r10
00007957b0dd478a  push r11
00007957b0dd478c  sub rsp, 0xF0
00007957b0dd4793  vmovaps [rsp], xmm0
00007957b0dd4798  vmovaps [rsp+0x10], xmm1
00007957b0dd479e  vmovaps [rsp+0x20], xmm2
00007957b0dd47a4  vmovaps [rsp+0x30], xmm3
00007957b0dd47aa  vmovaps [rsp+0x40], xmm4
00007957b0dd47b0  vmovaps [rsp+0x50], xmm5
00007957b0dd47b6  vmovaps [rsp+0x60], xmm6
00007957b0dd47bc  vmovaps [rsp+0x70], xmm7
00007957b0dd47c2  vmovaps [rsp+0x80], xmm8
00007957b0dd47cb  vmovaps [rsp+0x90], xmm9
00007957b0dd47d4  vmovaps [rsp+0xA0], xmm10
00007957b0dd47dd  vmovaps [rsp+0xB0], xmm12
00007957b0dd47e6  vmovaps [rsp+0xC0], xmm13
00007957b0dd47ef  vmovaps [rsp+0xD0], xmm14
00007957b0dd47f8  vmovaps [rsp+0xE0], xmm15
00007957b0dd4801  sub rsp, 0x40
00007957b0dd4805  lea rdi, [rsp]
00007957b0dd4809  lea rsi, [rsp+0x10]
00007957b0dd480e  lea rdx, [rsp+0x20]
00007957b0dd4813  lea rcx, [rsp+0x30]
00007957b0dd4818  mov r8d, 0x00
00007957b0dd481e  lea r9, [r15+0x3A8]
00007957b0dd4825  movaps [rdi], xmm11
00007957b0dd4829  movaps [rsi], xmm10
00007957b0dd482d  movaps [rdx], xmm8
00007957b0dd4831  movaps [rcx], xmm13
00007957b0dd4835  mov rax, 0x56E396DF1A50
00007957b0dd483f  call rax
00007957b0dd4841  movaps xmm11, [rsp]
00007957b0dd4846  add rsp, 0x40
00007957b0dd484a  vmovaps xmm0, [rsp]
00007957b0dd484f  vmovaps xmm1, [rsp+0x10]
00007957b0dd4855  vmovaps xmm2, [rsp+0x20]
00007957b0dd485b  vmovaps xmm3, [rsp+0x30]
00007957b0dd4861  vmovaps xmm4, [rsp+0x40]
00007957b0dd4867  vmovaps xmm5, [rsp+0x50]
00007957b0dd486d  vmovaps xmm6, [rsp+0x60]
00007957b0dd4873  vmovaps xmm7, [rsp+0x70]
00007957b0dd4879  vmovaps xmm8, [rsp+0x80]
00007957b0dd4882  vmovaps xmm9, [rsp+0x90]
00007957b0dd488b  vmovaps xmm10, [rsp+0xA0]
00007957b0dd4894  vmovaps xmm12, [rsp+0xB0]
00007957b0dd489d  vmovaps xmm13, [rsp+0xC0]
00007957b0dd48a6  vmovaps xmm14, [rsp+0xD0]
00007957b0dd48af  vmovaps xmm15, [rsp+0xE0]
00007957b0dd48b8  add rsp, 0xF0
00007957b0dd48bf  pop r11
00007957b0dd48c1  pop r10
00007957b0dd48c3  pop r9
00007957b0dd48c5  pop r8
00007957b0dd48c7  pop rsi
00007957b0dd48c8  pop rdi
00007957b0dd48c9  pop rdx
00007957b0dd48ca  pop rcx
00007957b0dd48cb  pop rax
00007957b0dd48cc  add rsp, 0x08
00007957b0dd48d0  jmp 0x00007957B0DD2E44
00007957b0dd48d5  sub rsp, 0x08
00007957b0dd48d9  push rax
00007957b0dd48da  push rcx
00007957b0dd48db  push rdx
00007957b0dd48dc  push rdi
00007957b0dd48dd  push rsi
00007957b0dd48de  push r8
00007957b0dd48e0  push r9
00007957b0dd48e2  push r10
00007957b0dd48e4  push r11
00007957b0dd48e6  sub rsp, 0xF0
00007957b0dd48ed  vmovaps [rsp], xmm0
00007957b0dd48f2  vmovaps [rsp+0x10], xmm1
00007957b0dd48f8  vmovaps [rsp+0x20], xmm2
00007957b0dd48fe  vmovaps [rsp+0x30], xmm3
00007957b0dd4904  vmovaps [rsp+0x40], xmm4
00007957b0dd490a  vmovaps [rsp+0x50], xmm5
00007957b0dd4910  vmovaps [rsp+0x60], xmm6
00007957b0dd4916  vmovaps [rsp+0x70], xmm7
00007957b0dd491c  vmovaps [rsp+0x80], xmm8
00007957b0dd4925  vmovaps [rsp+0x90], xmm9
00007957b0dd492e  vmovaps [rsp+0xA0], xmm11
00007957b0dd4937  vmovaps [rsp+0xB0], xmm12
00007957b0dd4940  vmovaps [rsp+0xC0], xmm13
00007957b0dd4949  vmovaps [rsp+0xD0], xmm14
00007957b0dd4952  vmovaps [rsp+0xE0], xmm15
00007957b0dd495b  sub rsp, 0x40
00007957b0dd495f  lea rdi, [rsp]
00007957b0dd4963  lea rsi, [rsp+0x10]
00007957b0dd4968  lea rdx, [rsp+0x20]
00007957b0dd496d  lea rcx, [rsp+0x30]
00007957b0dd4972  mov r8d, 0x00
00007957b0dd4978  lea r9, [r15+0x3A8]
00007957b0dd497f  movaps [rdi], xmm10
00007957b0dd4983  movaps [rsi], xmm15
00007957b0dd4987  movaps [rdx], xmm1
00007957b0dd498a  movaps [rcx], xmm13
00007957b0dd498e  mov rax, 0x56E396DF1A50
00007957b0dd4998  call rax
00007957b0dd499a  movaps xmm10, [rsp]
00007957b0dd499f  add rsp, 0x40
00007957b0dd49a3  vmovaps xmm0, [rsp]
00007957b0dd49a8  vmovaps xmm1, [rsp+0x10]
00007957b0dd49ae  vmovaps xmm2, [rsp+0x20]
00007957b0dd49b4  vmovaps xmm3, [rsp+0x30]
00007957b0dd49ba  vmovaps xmm4, [rsp+0x40]
00007957b0dd49c0  vmovaps xmm5, [rsp+0x50]
00007957b0dd49c6  vmovaps xmm6, [rsp+0x60]
00007957b0dd49cc  vmovaps xmm7, [rsp+0x70]
00007957b0dd49d2  vmovaps xmm8, [rsp+0x80]
00007957b0dd49db  vmovaps xmm9, [rsp+0x90]
00007957b0dd49e4  vmovaps xmm11, [rsp+0xA0]
00007957b0dd49ed  vmovaps xmm12, [rsp+0xB0]
00007957b0dd49f6  vmovaps xmm13, [rsp+0xC0]
00007957b0dd49ff  vmovaps xmm14, [rsp+0xD0]
00007957b0dd4a08  vmovaps xmm15, [rsp+0xE0]
00007957b0dd4a11  add rsp, 0xF0
00007957b0dd4a18  pop r11
00007957b0dd4a1a  pop r10
00007957b0dd4a1c  pop r9
00007957b0dd4a1e  pop r8
00007957b0dd4a20  pop rsi
00007957b0dd4a21  pop rdi
00007957b0dd4a22  pop rdx
00007957b0dd4a23  pop rcx
00007957b0dd4a24  pop rax
00007957b0dd4a25  add rsp, 0x08
00007957b0dd4a29  jmp 0x00007957B0DD2E6D
00007957b0dd4a2e  call 0x00007957B0BFF430
00007957b0dd4a33  jmp 0x00007957B0DD2E8F
00007957b0dd4a38  call 0x00007957B0C0E760
00007957b0dd4a3d  jmp 0x00007957B0DD2E99
00007957b0dd4a42  sub rsp, 0x08
00007957b0dd4a46  push rax
00007957b0dd4a47  push rcx
00007957b0dd4a48  push rdx
00007957b0dd4a49  push rdi
00007957b0dd4a4a  push rsi
00007957b0dd4a4b  push r8
00007957b0dd4a4d  push r9
00007957b0dd4a4f  push r10
00007957b0dd4a51  push r11
00007957b0dd4a53  sub rsp, 0xF0
00007957b0dd4a5a  vmovaps [rsp], xmm0
00007957b0dd4a5f  vmovaps [rsp+0x10], xmm1
00007957b0dd4a65  vmovaps [rsp+0x20], xmm2
00007957b0dd4a6b  vmovaps [rsp+0x30], xmm3
00007957b0dd4a71  vmovaps [rsp+0x40], xmm4
00007957b0dd4a77  vmovaps [rsp+0x50], xmm5
00007957b0dd4a7d  vmovaps [rsp+0x60], xmm6
00007957b0dd4a83  vmovaps [rsp+0x70], xmm7
00007957b0dd4a89  vmovaps [rsp+0x80], xmm9
00007957b0dd4a92  vmovaps [rsp+0x90], xmm10
00007957b0dd4a9b  vmovaps [rsp+0xA0], xmm11
00007957b0dd4aa4  vmovaps [rsp+0xB0], xmm12
00007957b0dd4aad  vmovaps [rsp+0xC0], xmm13
00007957b0dd4ab6  vmovaps [rsp+0xD0], xmm14
00007957b0dd4abf  vmovaps [rsp+0xE0], xmm15
00007957b0dd4ac8  sub rsp, 0x40
00007957b0dd4acc  lea rdi, [rsp]
00007957b0dd4ad0  lea rsi, [rsp+0x10]
00007957b0dd4ad5  lea rdx, [rsp+0x20]
00007957b0dd4ada  lea rcx, [rsp+0x30]
00007957b0dd4adf  mov r8d, 0x00
00007957b0dd4ae5  lea r9, [r15+0x3A8]
00007957b0dd4aec  movaps [rdi], xmm8
00007957b0dd4af0  movaps [rsi], xmm5
00007957b0dd4af3  movaps [rdx], xmm9
00007957b0dd4af7  movaps [rcx], xmm13
00007957b0dd4afb  mov rax, 0x56E396DF1A50
00007957b0dd4b05  call rax
00007957b0dd4b07  movaps xmm8, [rsp]
00007957b0dd4b0c  add rsp, 0x40
00007957b0dd4b10  vmovaps xmm0, [rsp]
00007957b0dd4b15  vmovaps xmm1, [rsp+0x10]
00007957b0dd4b1b  vmovaps xmm2, [rsp+0x20]
00007957b0dd4b21  vmovaps xmm3, [rsp+0x30]
00007957b0dd4b27  vmovaps xmm4, [rsp+0x40]
00007957b0dd4b2d  vmovaps xmm5, [rsp+0x50]
00007957b0dd4b33  vmovaps xmm6, [rsp+0x60]
00007957b0dd4b39  vmovaps xmm7, [rsp+0x70]
00007957b0dd4b3f  vmovaps xmm9, [rsp+0x80]
00007957b0dd4b48  vmovaps xmm10, [rsp+0x90]
00007957b0dd4b51  vmovaps xmm11, [rsp+0xA0]
00007957b0dd4b5a  vmovaps xmm12, [rsp+0xB0]
00007957b0dd4b63  vmovaps xmm13, [rsp+0xC0]
00007957b0dd4b6c  vmovaps xmm14, [rsp+0xD0]
00007957b0dd4b75  vmovaps xmm15, [rsp+0xE0]
00007957b0dd4b7e  add rsp, 0xF0
00007957b0dd4b85  pop r11
00007957b0dd4b87  pop r10
00007957b0dd4b89  pop r9
00007957b0dd4b8b  pop r8
00007957b0dd4b8d  pop rsi
00007957b0dd4b8e  pop rdi
00007957b0dd4b8f  pop rdx
00007957b0dd4b90  pop rcx
00007957b0dd4b91  pop rax
00007957b0dd4b92  add rsp, 0x08
00007957b0dd4b96  jmp 0x00007957B0DD2ED8
00007957b0dd4b9b  sub rsp, 0x08
00007957b0dd4b9f  push rax
00007957b0dd4ba0  push rcx
00007957b0dd4ba1  push rdx
00007957b0dd4ba2  push rdi
00007957b0dd4ba3  push rsi
00007957b0dd4ba4  push r8
00007957b0dd4ba6  push r9
00007957b0dd4ba8  push r10
00007957b0dd4baa  push r11
00007957b0dd4bac  sub rsp, 0xF0
00007957b0dd4bb3  vmovaps [rsp], xmm0
00007957b0dd4bb8  vmovaps [rsp+0x10], xmm1
00007957b0dd4bbe  vmovaps [rsp+0x20], xmm2
00007957b0dd4bc4  vmovaps [rsp+0x30], xmm3
00007957b0dd4bca  vmovaps [rsp+0x40], xmm4
00007957b0dd4bd0  vmovaps [rsp+0x50], xmm5
00007957b0dd4bd6  vmovaps [rsp+0x60], xmm6
00007957b0dd4bdc  vmovaps [rsp+0x70], xmm7
00007957b0dd4be2  vmovaps [rsp+0x80], xmm8
00007957b0dd4beb  vmovaps [rsp+0x90], xmm10
00007957b0dd4bf4  vmovaps [rsp+0xA0], xmm11
00007957b0dd4bfd  vmovaps [rsp+0xB0], xmm12
00007957b0dd4c06  vmovaps [rsp+0xC0], xmm13
00007957b0dd4c0f  vmovaps [rsp+0xD0], xmm14
00007957b0dd4c18  vmovaps [rsp+0xE0], xmm15
00007957b0dd4c21  sub rsp, 0x40
00007957b0dd4c25  lea rdi, [rsp]
00007957b0dd4c29  lea rsi, [rsp+0x10]
00007957b0dd4c2e  lea rdx, [rsp+0x20]
00007957b0dd4c33  lea rcx, [rsp+0x30]
00007957b0dd4c38  mov r8d, 0x00
00007957b0dd4c3e  lea r9, [r15+0x3A8]
00007957b0dd4c45  movaps [rdi], xmm9
00007957b0dd4c49  movaps [rsi], xmm12
00007957b0dd4c4d  movaps [rdx], xmm7
00007957b0dd4c50  movaps [rcx], xmm13
00007957b0dd4c54  mov rax, 0x56E396DF1A50
00007957b0dd4c5e  call rax
00007957b0dd4c60  movaps xmm9, [rsp]
00007957b0dd4c65  add rsp, 0x40
00007957b0dd4c69  vmovaps xmm0, [rsp]
00007957b0dd4c6e  vmovaps xmm1, [rsp+0x10]
00007957b0dd4c74  vmovaps xmm2, [rsp+0x20]
00007957b0dd4c7a  vmovaps xmm3, [rsp+0x30]
00007957b0dd4c80  vmovaps xmm4, [rsp+0x40]
00007957b0dd4c86  vmovaps xmm5, [rsp+0x50]
00007957b0dd4c8c  vmovaps xmm6, [rsp+0x60]
00007957b0dd4c92  vmovaps xmm7, [rsp+0x70]
00007957b0dd4c98  vmovaps xmm8, [rsp+0x80]
00007957b0dd4ca1  vmovaps xmm10, [rsp+0x90]
00007957b0dd4caa  vmovaps xmm11, [rsp+0xA0]
00007957b0dd4cb3  vmovaps xmm12, [rsp+0xB0]
00007957b0dd4cbc  vmovaps xmm13, [rsp+0xC0]
00007957b0dd4cc5  vmovaps xmm14, [rsp+0xD0]
00007957b0dd4cce  vmovaps xmm15, [rsp+0xE0]
00007957b0dd4cd7  add rsp, 0xF0
00007957b0dd4cde  pop r11
00007957b0dd4ce0  pop r10
00007957b0dd4ce2  pop r9
00007957b0dd4ce4  pop r8
00007957b0dd4ce6  pop rsi
00007957b0dd4ce7  pop rdi
00007957b0dd4ce8  pop rdx
00007957b0dd4ce9  pop rcx
00007957b0dd4cea  pop rax
00007957b0dd4ceb  add rsp, 0x08
00007957b0dd4cef  jmp 0x00007957B0DD2F01
00007957b0dd4cf4  sub rsp, 0x08
00007957b0dd4cf8  push rax
00007957b0dd4cf9  push rcx
00007957b0dd4cfa  push rdx
00007957b0dd4cfb  push rdi
00007957b0dd4cfc  push rsi
00007957b0dd4cfd  push r8
00007957b0dd4cff  push r9
00007957b0dd4d01  push r10
00007957b0dd4d03  push r11
00007957b0dd4d05  sub rsp, 0xF0
00007957b0dd4d0c  vmovaps [rsp], xmm0
00007957b0dd4d11  vmovaps [rsp+0x10], xmm1
00007957b0dd4d17  vmovaps [rsp+0x20], xmm2
00007957b0dd4d1d  vmovaps [rsp+0x30], xmm3
00007957b0dd4d23  vmovaps [rsp+0x40], xmm4
00007957b0dd4d29  vmovaps [rsp+0x50], xmm5
00007957b0dd4d2f  vmovaps [rsp+0x60], xmm6
00007957b0dd4d35  vmovaps [rsp+0x70], xmm7
00007957b0dd4d3b  vmovaps [rsp+0x80], xmm8
00007957b0dd4d44  vmovaps [rsp+0x90], xmm9
00007957b0dd4d4d  vmovaps [rsp+0xA0], xmm10
00007957b0dd4d56  vmovaps [rsp+0xB0], xmm11
00007957b0dd4d5f  vmovaps [rsp+0xC0], xmm13
00007957b0dd4d68  vmovaps [rsp+0xD0], xmm14
00007957b0dd4d71  vmovaps [rsp+0xE0], xmm15
00007957b0dd4d7a  sub rsp, 0x40
00007957b0dd4d7e  lea rdi, [rsp]
00007957b0dd4d82  lea rsi, [rsp+0x10]
00007957b0dd4d87  lea rdx, [rsp+0x20]
00007957b0dd4d8c  lea rcx, [rsp+0x30]
00007957b0dd4d91  mov r8d, 0x00
00007957b0dd4d97  lea r9, [r15+0x3A8]
00007957b0dd4d9e  movaps [rdi], xmm12
00007957b0dd4da2  movaps [rsi], xmm11
00007957b0dd4da6  movaps [rdx], xmm6
00007957b0dd4da9  movaps [rcx], xmm13
00007957b0dd4dad  mov rax, 0x56E396DF1A50
00007957b0dd4db7  call rax
00007957b0dd4db9  movaps xmm12, [rsp]
00007957b0dd4dbe  add rsp, 0x40
00007957b0dd4dc2  vmovaps xmm0, [rsp]
00007957b0dd4dc7  vmovaps xmm1, [rsp+0x10]
00007957b0dd4dcd  vmovaps xmm2, [rsp+0x20]
00007957b0dd4dd3  vmovaps xmm3, [rsp+0x30]
00007957b0dd4dd9  vmovaps xmm4, [rsp+0x40]
00007957b0dd4ddf  vmovaps xmm5, [rsp+0x50]
00007957b0dd4de5  vmovaps xmm6, [rsp+0x60]
00007957b0dd4deb  vmovaps xmm7, [rsp+0x70]
00007957b0dd4df1  vmovaps xmm8, [rsp+0x80]
00007957b0dd4dfa  vmovaps xmm9, [rsp+0x90]
00007957b0dd4e03  vmovaps xmm10, [rsp+0xA0]
00007957b0dd4e0c  vmovaps xmm11, [rsp+0xB0]
00007957b0dd4e15  vmovaps xmm13, [rsp+0xC0]
00007957b0dd4e1e  vmovaps xmm14, [rsp+0xD0]
00007957b0dd4e27  vmovaps xmm15, [rsp+0xE0]
00007957b0dd4e30  add rsp, 0xF0
00007957b0dd4e37  pop r11
00007957b0dd4e39  pop r10
00007957b0dd4e3b  pop r9
00007957b0dd4e3d  pop r8
00007957b0dd4e3f  pop rsi
00007957b0dd4e40  pop rdi
00007957b0dd4e41  pop rdx
00007957b0dd4e42  pop rcx
00007957b0dd4e43  pop rax
00007957b0dd4e44  add rsp, 0x08
00007957b0dd4e48  jmp 0x00007957B0DD2F2A
00007957b0dd4e4d  sub rsp, 0x08
00007957b0dd4e51  push rax
00007957b0dd4e52  push rcx
00007957b0dd4e53  push rdx
00007957b0dd4e54  push rdi
00007957b0dd4e55  push rsi
00007957b0dd4e56  push r8
00007957b0dd4e58  push r9
00007957b0dd4e5a  push r10
00007957b0dd4e5c  push r11
00007957b0dd4e5e  sub rsp, 0xF0
00007957b0dd4e65  vmovaps [rsp], xmm0
00007957b0dd4e6a  vmovaps [rsp+0x10], xmm1
00007957b0dd4e70  vmovaps [rsp+0x20], xmm2
00007957b0dd4e76  vmovaps [rsp+0x30], xmm3
00007957b0dd4e7c  vmovaps [rsp+0x40], xmm4
00007957b0dd4e82  vmovaps [rsp+0x50], xmm5
00007957b0dd4e88  vmovaps [rsp+0x60], xmm6
00007957b0dd4e8e  vmovaps [rsp+0x70], xmm8
00007957b0dd4e94  vmovaps [rsp+0x80], xmm9
00007957b0dd4e9d  vmovaps [rsp+0x90], xmm10
00007957b0dd4ea6  vmovaps [rsp+0xA0], xmm11
00007957b0dd4eaf  vmovaps [rsp+0xB0], xmm12
00007957b0dd4eb8  vmovaps [rsp+0xC0], xmm13
00007957b0dd4ec1  vmovaps [rsp+0xD0], xmm14
00007957b0dd4eca  vmovaps [rsp+0xE0], xmm15
00007957b0dd4ed3  sub rsp, 0x40
00007957b0dd4ed7  lea rdi, [rsp]
00007957b0dd4edb  lea rsi, [rsp+0x10]
00007957b0dd4ee0  lea rdx, [rsp+0x20]
00007957b0dd4ee5  lea rcx, [rsp+0x30]
00007957b0dd4eea  mov r8d, 0x00
00007957b0dd4ef0  lea r9, [r15+0x3A8]
00007957b0dd4ef7  movaps [rdi], xmm7
00007957b0dd4efa  movaps [rsi], xmm10
00007957b0dd4efe  movaps [rdx], xmm11
00007957b0dd4f02  movaps [rcx], xmm13
00007957b0dd4f06  mov rax, 0x56E396DF1A50
00007957b0dd4f10  call rax
00007957b0dd4f12  movaps xmm7, [rsp]
00007957b0dd4f16  add rsp, 0x40
00007957b0dd4f1a  vmovaps xmm0, [rsp]
00007957b0dd4f1f  vmovaps xmm1, [rsp+0x10]
00007957b0dd4f25  vmovaps xmm2, [rsp+0x20]
00007957b0dd4f2b  vmovaps xmm3, [rsp+0x30]
00007957b0dd4f31  vmovaps xmm4, [rsp+0x40]
00007957b0dd4f37  vmovaps xmm5, [rsp+0x50]
00007957b0dd4f3d  vmovaps xmm6, [rsp+0x60]
00007957b0dd4f43  vmovaps xmm8, [rsp+0x70]
00007957b0dd4f49  vmovaps xmm9, [rsp+0x80]
00007957b0dd4f52  vmovaps xmm10, [rsp+0x90]
00007957b0dd4f5b  vmovaps xmm11, [rsp+0xA0]
00007957b0dd4f64  vmovaps xmm12, [rsp+0xB0]
00007957b0dd4f6d  vmovaps xmm13, [rsp+0xC0]
00007957b0dd4f76  vmovaps xmm14, [rsp+0xD0]
00007957b0dd4f7f  vmovaps xmm15, [rsp+0xE0]
00007957b0dd4f88  add rsp, 0xF0
00007957b0dd4f8f  pop r11
00007957b0dd4f91  pop r10
00007957b0dd4f93  pop r9
00007957b0dd4f95  pop r8
00007957b0dd4f97  pop rsi
00007957b0dd4f98  pop rdi
00007957b0dd4f99  pop rdx
00007957b0dd4f9a  pop rcx
00007957b0dd4f9b  pop rax
00007957b0dd4f9c  add rsp, 0x08
00007957b0dd4fa0  jmp 0x00007957B0DD2F58
00007957b0dd4fa5  call 0x00007957B0C0C260
00007957b0dd4faa  jmp 0x00007957B0DD2F62
00007957b0dd4faf  call 0x00007957B0C09D70
00007957b0dd4fb4  jmp 0x00007957B0DD2F6C
00007957b0dd4fb9  sub rsp, 0x08
00007957b0dd4fbd  push rax
00007957b0dd4fbe  push rcx
00007957b0dd4fbf  push rdx
00007957b0dd4fc0  push rdi
00007957b0dd4fc1  push rsi
00007957b0dd4fc2  push r8
00007957b0dd4fc4  push r9
00007957b0dd4fc6  push r10
00007957b0dd4fc8  push r11
00007957b0dd4fca  sub rsp, 0xF0
00007957b0dd4fd1  vmovaps [rsp], xmm0
00007957b0dd4fd6  vmovaps [rsp+0x10], xmm1
00007957b0dd4fdc  vmovaps [rsp+0x20], xmm2
00007957b0dd4fe2  vmovaps [rsp+0x30], xmm3
00007957b0dd4fe8  vmovaps [rsp+0x40], xmm4
00007957b0dd4fee  vmovaps [rsp+0x50], xmm5
00007957b0dd4ff4  vmovaps [rsp+0x60], xmm7
00007957b0dd4ffa  vmovaps [rsp+0x70], xmm8
00007957b0dd5000  vmovaps [rsp+0x80], xmm9
00007957b0dd5009  vmovaps [rsp+0x90], xmm10
00007957b0dd5012  vmovaps [rsp+0xA0], xmm11
00007957b0dd501b  vmovaps [rsp+0xB0], xmm12
00007957b0dd5024  vmovaps [rsp+0xC0], xmm13
00007957b0dd502d  vmovaps [rsp+0xD0], xmm14
00007957b0dd5036  vmovaps [rsp+0xE0], xmm15
00007957b0dd503f  sub rsp, 0x40
00007957b0dd5043  lea rdi, [rsp]
00007957b0dd5047  lea rsi, [rsp+0x10]
00007957b0dd504c  lea rdx, [rsp+0x20]
00007957b0dd5051  lea rcx, [rsp+0x30]
00007957b0dd5056  mov r8d, 0x00
00007957b0dd505c  lea r9, [r15+0x3A8]
00007957b0dd5063  movaps [rdi], xmm6
00007957b0dd5066  movaps [rsi], xmm8
00007957b0dd506a  movaps [rdx], xmm15
00007957b0dd506e  movaps [rcx], xmm10
00007957b0dd5072  mov rax, 0x56E396DF1A50
00007957b0dd507c  call rax
00007957b0dd507e  movaps xmm6, [rsp]
00007957b0dd5082  add rsp, 0x40
00007957b0dd5086  vmovaps xmm0, [rsp]
00007957b0dd508b  vmovaps xmm1, [rsp+0x10]
00007957b0dd5091  vmovaps xmm2, [rsp+0x20]
00007957b0dd5097  vmovaps xmm3, [rsp+0x30]
00007957b0dd509d  vmovaps xmm4, [rsp+0x40]
00007957b0dd50a3  vmovaps xmm5, [rsp+0x50]
00007957b0dd50a9  vmovaps xmm7, [rsp+0x60]
00007957b0dd50af  vmovaps xmm8, [rsp+0x70]
00007957b0dd50b5  vmovaps xmm9, [rsp+0x80]
00007957b0dd50be  vmovaps xmm10, [rsp+0x90]
00007957b0dd50c7  vmovaps xmm11, [rsp+0xA0]
00007957b0dd50d0  vmovaps xmm12, [rsp+0xB0]
00007957b0dd50d9  vmovaps xmm13, [rsp+0xC0]
00007957b0dd50e2  vmovaps xmm14, [rsp+0xD0]
00007957b0dd50eb  vmovaps xmm15, [rsp+0xE0]
00007957b0dd50f4  add rsp, 0xF0
00007957b0dd50fb  pop r11
00007957b0dd50fd  pop r10
00007957b0dd50ff  pop r9
00007957b0dd5101  pop r8
00007957b0dd5103  pop rsi
00007957b0dd5104  pop rdi
00007957b0dd5105  pop rdx
00007957b0dd5106  pop rcx
00007957b0dd5107  pop rax
00007957b0dd5108  add rsp, 0x08
00007957b0dd510c  jmp 0x00007957B0DD2FA4
00007957b0dd5111  sub rsp, 0x08
00007957b0dd5115  push rax
00007957b0dd5116  push rcx
00007957b0dd5117  push rdx
00007957b0dd5118  push rdi
00007957b0dd5119  push rsi
00007957b0dd511a  push r8
00007957b0dd511c  push r9
00007957b0dd511e  push r10
00007957b0dd5120  push r11
00007957b0dd5122  sub rsp, 0xF0
00007957b0dd5129  vmovaps [rsp], xmm0
00007957b0dd512e  vmovaps [rsp+0x10], xmm1
00007957b0dd5134  vmovaps [rsp+0x20], xmm2
00007957b0dd513a  vmovaps [rsp+0x30], xmm3
00007957b0dd5140  vmovaps [rsp+0x40], xmm4
00007957b0dd5146  vmovaps [rsp+0x50], xmm5
00007957b0dd514c  vmovaps [rsp+0x60], xmm6
00007957b0dd5152  vmovaps [rsp+0x70], xmm7
00007957b0dd5158  vmovaps [rsp+0x80], xmm8
00007957b0dd5161  vmovaps [rsp+0x90], xmm9
00007957b0dd516a  vmovaps [rsp+0xA0], xmm11
00007957b0dd5173  vmovaps [rsp+0xB0], xmm12
00007957b0dd517c  vmovaps [rsp+0xC0], xmm13
00007957b0dd5185  vmovaps [rsp+0xD0], xmm14
00007957b0dd518e  vmovaps [rsp+0xE0], xmm15
00007957b0dd5197  sub rsp, 0x40
00007957b0dd519b  lea rdi, [rsp]
00007957b0dd519f  lea rsi, [rsp+0x10]
00007957b0dd51a4  lea rdx, [rsp+0x20]
00007957b0dd51a9  lea rcx, [rsp+0x30]
00007957b0dd51ae  mov r8d, 0x00
00007957b0dd51b4  lea r9, [r15+0x3A8]
00007957b0dd51bb  movaps [rdi], xmm10
00007957b0dd51bf  movaps [rsi], xmm9
00007957b0dd51c3  movaps [rdx], xmm13
00007957b0dd51c7  movaps [rcx], xmm15
00007957b0dd51cb  mov rax, 0x56E396DF1A50
00007957b0dd51d5  call rax
00007957b0dd51d7  movaps xmm10, [rsp]
00007957b0dd51dc  add rsp, 0x40
00007957b0dd51e0  vmovaps xmm0, [rsp]
00007957b0dd51e5  vmovaps xmm1, [rsp+0x10]
00007957b0dd51eb  vmovaps xmm2, [rsp+0x20]
00007957b0dd51f1  vmovaps xmm3, [rsp+0x30]
00007957b0dd51f7  vmovaps xmm4, [rsp+0x40]
00007957b0dd51fd  vmovaps xmm5, [rsp+0x50]
00007957b0dd5203  vmovaps xmm6, [rsp+0x60]
00007957b0dd5209  vmovaps xmm7, [rsp+0x70]
00007957b0dd520f  vmovaps xmm8, [rsp+0x80]
00007957b0dd5218  vmovaps xmm9, [rsp+0x90]
00007957b0dd5221  vmovaps xmm11, [rsp+0xA0]
00007957b0dd522a  vmovaps xmm12, [rsp+0xB0]
00007957b0dd5233  vmovaps xmm13, [rsp+0xC0]
00007957b0dd523c  vmovaps xmm14, [rsp+0xD0]
00007957b0dd5245  vmovaps xmm15, [rsp+0xE0]
00007957b0dd524e  add rsp, 0xF0
00007957b0dd5255  pop r11
00007957b0dd5257  pop r10
00007957b0dd5259  pop r9
00007957b0dd525b  pop r8
00007957b0dd525d  pop rsi
00007957b0dd525e  pop rdi
00007957b0dd525f  pop rdx
00007957b0dd5260  pop rcx
00007957b0dd5261  pop rax
00007957b0dd5262  add rsp, 0x08
00007957b0dd5266  jmp 0x00007957B0DD2FCD
00007957b0dd526b  sub rsp, 0x08
00007957b0dd526f  push rax
00007957b0dd5270  push rcx
00007957b0dd5271  push rdx
00007957b0dd5272  push rdi
00007957b0dd5273  push rsi
00007957b0dd5274  push r8
00007957b0dd5276  push r9
00007957b0dd5278  push r10
00007957b0dd527a  push r11
00007957b0dd527c  sub rsp, 0xF0
00007957b0dd5283  vmovaps [rsp], xmm0
00007957b0dd5288  vmovaps [rsp+0x10], xmm1
00007957b0dd528e  vmovaps [rsp+0x20], xmm2
00007957b0dd5294  vmovaps [rsp+0x30], xmm3
00007957b0dd529a  vmovaps [rsp+0x40], xmm4
00007957b0dd52a0  vmovaps [rsp+0x50], xmm5
00007957b0dd52a6  vmovaps [rsp+0x60], xmm6
00007957b0dd52ac  vmovaps [rsp+0x70], xmm7
00007957b0dd52b2  vmovaps [rsp+0x80], xmm8
00007957b0dd52bb  vmovaps [rsp+0x90], xmm9
00007957b0dd52c4  vmovaps [rsp+0xA0], xmm10
00007957b0dd52cd  vmovaps [rsp+0xB0], xmm11
00007957b0dd52d6  vmovaps [rsp+0xC0], xmm12
00007957b0dd52df  vmovaps [rsp+0xD0], xmm14
00007957b0dd52e8  vmovaps [rsp+0xE0], xmm15
00007957b0dd52f1  sub rsp, 0x40
00007957b0dd52f5  lea rdi, [rsp]
00007957b0dd52f9  lea rsi, [rsp+0x10]
00007957b0dd52fe  lea rdx, [rsp+0x20]
00007957b0dd5303  lea rcx, [rsp+0x30]
00007957b0dd5308  mov r8d, 0x00
00007957b0dd530e  lea r9, [r15+0x3A8]
00007957b0dd5315  movaps [rdi], xmm13
00007957b0dd5319  movaps [rsi], xmm12
00007957b0dd531d  movaps [rdx], xmm4
00007957b0dd5320  movaps [rcx], xmm15
00007957b0dd5324  mov rax, 0x56E396DF1A50
00007957b0dd532e  call rax
00007957b0dd5330  movaps xmm13, [rsp]
00007957b0dd5335  add rsp, 0x40
00007957b0dd5339  vmovaps xmm0, [rsp]
00007957b0dd533e  vmovaps xmm1, [rsp+0x10]
00007957b0dd5344  vmovaps xmm2, [rsp+0x20]
00007957b0dd534a  vmovaps xmm3, [rsp+0x30]
00007957b0dd5350  vmovaps xmm4, [rsp+0x40]
00007957b0dd5356  vmovaps xmm5, [rsp+0x50]
00007957b0dd535c  vmovaps xmm6, [rsp+0x60]
00007957b0dd5362  vmovaps xmm7, [rsp+0x70]
00007957b0dd5368  vmovaps xmm8, [rsp+0x80]
00007957b0dd5371  vmovaps xmm9, [rsp+0x90]
00007957b0dd537a  vmovaps xmm10, [rsp+0xA0]
00007957b0dd5383  vmovaps xmm11, [rsp+0xB0]
00007957b0dd538c  vmovaps xmm12, [rsp+0xC0]
00007957b0dd5395  vmovaps xmm14, [rsp+0xD0]
00007957b0dd539e  vmovaps xmm15, [rsp+0xE0]
00007957b0dd53a7  add rsp, 0xF0
00007957b0dd53ae  pop r11
00007957b0dd53b0  pop r10
00007957b0dd53b2  pop r9
00007957b0dd53b4  pop r8
00007957b0dd53b6  pop rsi
00007957b0dd53b7  pop rdi
00007957b0dd53b8  pop rdx
00007957b0dd53b9  pop rcx
00007957b0dd53ba  pop rax
00007957b0dd53bb  add rsp, 0x08
00007957b0dd53bf  jmp 0x00007957B0DD2FF6
00007957b0dd53c4  sub rsp, 0x08
00007957b0dd53c8  push rax
00007957b0dd53c9  push rcx
00007957b0dd53ca  push rdx
00007957b0dd53cb  push rdi
00007957b0dd53cc  push rsi
00007957b0dd53cd  push r8
00007957b0dd53cf  push r9
00007957b0dd53d1  push r10
00007957b0dd53d3  push r11
00007957b0dd53d5  sub rsp, 0xF0
00007957b0dd53dc  vmovaps [rsp], xmm0
00007957b0dd53e1  vmovaps [rsp+0x10], xmm1
00007957b0dd53e7  vmovaps [rsp+0x20], xmm2
00007957b0dd53ed  vmovaps [rsp+0x30], xmm3
00007957b0dd53f3  vmovaps [rsp+0x40], xmm4
00007957b0dd53f9  vmovaps [rsp+0x50], xmm5
00007957b0dd53ff  vmovaps [rsp+0x60], xmm6
00007957b0dd5405  vmovaps [rsp+0x70], xmm7
00007957b0dd540b  vmovaps [rsp+0x80], xmm8
00007957b0dd5414  vmovaps [rsp+0x90], xmm9
00007957b0dd541d  vmovaps [rsp+0xA0], xmm10
00007957b0dd5426  vmovaps [rsp+0xB0], xmm11
00007957b0dd542f  vmovaps [rsp+0xC0], xmm13
00007957b0dd5438  vmovaps [rsp+0xD0], xmm14
00007957b0dd5441  vmovaps [rsp+0xE0], xmm15
00007957b0dd544a  sub rsp, 0x40
00007957b0dd544e  lea rdi, [rsp]
00007957b0dd5452  lea rsi, [rsp+0x10]
00007957b0dd5457  lea rdx, [rsp+0x20]
00007957b0dd545c  lea rcx, [rsp+0x30]
00007957b0dd5461  mov r8d, 0x00
00007957b0dd5467  lea r9, [r15+0x3A8]
00007957b0dd546e  movaps [rdi], xmm12
00007957b0dd5472  movaps [rsi], xmm7
00007957b0dd5475  movaps [rdx], xmm1
00007957b0dd5478  movaps [rcx], xmm15
00007957b0dd547c  mov rax, 0x56E396DF1A50
00007957b0dd5486  call rax
00007957b0dd5488  movaps xmm12, [rsp]
00007957b0dd548d  add rsp, 0x40
00007957b0dd5491  vmovaps xmm0, [rsp]
00007957b0dd5496  vmovaps xmm1, [rsp+0x10]
00007957b0dd549c  vmovaps xmm2, [rsp+0x20]
00007957b0dd54a2  vmovaps xmm3, [rsp+0x30]
00007957b0dd54a8  vmovaps xmm4, [rsp+0x40]
00007957b0dd54ae  vmovaps xmm5, [rsp+0x50]
00007957b0dd54b4  vmovaps xmm6, [rsp+0x60]
00007957b0dd54ba  vmovaps xmm7, [rsp+0x70]
00007957b0dd54c0  vmovaps xmm8, [rsp+0x80]
00007957b0dd54c9  vmovaps xmm9, [rsp+0x90]
00007957b0dd54d2  vmovaps xmm10, [rsp+0xA0]
00007957b0dd54db  vmovaps xmm11, [rsp+0xB0]
00007957b0dd54e4  vmovaps xmm13, [rsp+0xC0]
00007957b0dd54ed  vmovaps xmm14, [rsp+0xD0]
00007957b0dd54f6  vmovaps xmm15, [rsp+0xE0]
00007957b0dd54ff  add rsp, 0xF0
00007957b0dd5506  pop r11
00007957b0dd5508  pop r10
00007957b0dd550a  pop r9
00007957b0dd550c  pop r8
00007957b0dd550e  pop rsi
00007957b0dd550f  pop rdi
00007957b0dd5510  pop rdx
00007957b0dd5511  pop rcx
00007957b0dd5512  pop rax
00007957b0dd5513  add rsp, 0x08
00007957b0dd5517  jmp 0x00007957B0DD301F
00007957b0dd551c  call 0x00007957B0BFF430
00007957b0dd5521  jmp 0x00007957B0DD3029
00007957b0dd5526  call 0x00007957B0C0E760
00007957b0dd552b  jmp 0x00007957B0DD3033
00007957b0dd5530  sub rsp, 0x08
00007957b0dd5534  push rax
00007957b0dd5535  push rcx
00007957b0dd5536  push rdx
00007957b0dd5537  push rdi
00007957b0dd5538  push rsi
00007957b0dd5539  push r8
00007957b0dd553b  push r9
00007957b0dd553d  push r10
00007957b0dd553f  push r11
00007957b0dd5541  sub rsp, 0xF0
00007957b0dd5548  vmovaps [rsp], xmm0
00007957b0dd554d  vmovaps [rsp+0x10], xmm1
00007957b0dd5553  vmovaps [rsp+0x20], xmm2
00007957b0dd5559  vmovaps [rsp+0x30], xmm3
00007957b0dd555f  vmovaps [rsp+0x40], xmm4
00007957b0dd5565  vmovaps [rsp+0x50], xmm5
00007957b0dd556b  vmovaps [rsp+0x60], xmm6
00007957b0dd5571  vmovaps [rsp+0x70], xmm8
00007957b0dd5577  vmovaps [rsp+0x80], xmm9
00007957b0dd5580  vmovaps [rsp+0x90], xmm10
00007957b0dd5589  vmovaps [rsp+0xA0], xmm11
00007957b0dd5592  vmovaps [rsp+0xB0], xmm12
00007957b0dd559b  vmovaps [rsp+0xC0], xmm13
00007957b0dd55a4  vmovaps [rsp+0xD0], xmm14
00007957b0dd55ad  vmovaps [rsp+0xE0], xmm15
00007957b0dd55b6  sub rsp, 0x40
00007957b0dd55ba  lea rdi, [rsp]
00007957b0dd55be  lea rsi, [rsp+0x10]
00007957b0dd55c3  lea rdx, [rsp+0x20]
00007957b0dd55c8  lea rcx, [rsp+0x30]
00007957b0dd55cd  mov r8d, 0x00
00007957b0dd55d3  lea r9, [r15+0x3A8]
00007957b0dd55da  movaps [rdi], xmm7
00007957b0dd55dd  movaps [rsi], xmm6
00007957b0dd55e0  movaps [rdx], xmm8
00007957b0dd55e4  movaps [rcx], xmm9
00007957b0dd55e8  mov rax, 0x56E396DF1A50
00007957b0dd55f2  call rax
00007957b0dd55f4  movaps xmm7, [rsp]
00007957b0dd55f8  add rsp, 0x40
00007957b0dd55fc  vmovaps xmm0, [rsp]
00007957b0dd5601  vmovaps xmm1, [rsp+0x10]
00007957b0dd5607  vmovaps xmm2, [rsp+0x20]
00007957b0dd560d  vmovaps xmm3, [rsp+0x30]
00007957b0dd5613  vmovaps xmm4, [rsp+0x40]
00007957b0dd5619  vmovaps xmm5, [rsp+0x50]
00007957b0dd561f  vmovaps xmm6, [rsp+0x60]
00007957b0dd5625  vmovaps xmm8, [rsp+0x70]
00007957b0dd562b  vmovaps xmm9, [rsp+0x80]
00007957b0dd5634  vmovaps xmm10, [rsp+0x90]
00007957b0dd563d  vmovaps xmm11, [rsp+0xA0]
00007957b0dd5646  vmovaps xmm12, [rsp+0xB0]
00007957b0dd564f  vmovaps xmm13, [rsp+0xC0]
00007957b0dd5658  vmovaps xmm14, [rsp+0xD0]
00007957b0dd5661  vmovaps xmm15, [rsp+0xE0]
00007957b0dd566a  add rsp, 0xF0
00007957b0dd5671  pop r11
00007957b0dd5673  pop r10
00007957b0dd5675  pop r9
00007957b0dd5677  pop r8
00007957b0dd5679  pop rsi
00007957b0dd567a  pop rdi
00007957b0dd567b  pop rdx
00007957b0dd567c  pop rcx
00007957b0dd567d  pop rax
00007957b0dd567e  add rsp, 0x08
00007957b0dd5682  jmp 0x00007957B0DD305D
00007957b0dd5687  sub rsp, 0x08
00007957b0dd568b  push rax
00007957b0dd568c  push rcx
00007957b0dd568d  push rdx
00007957b0dd568e  push rdi
00007957b0dd568f  push rsi
00007957b0dd5690  push r8
00007957b0dd5692  push r9
00007957b0dd5694  push r10
00007957b0dd5696  push r11
00007957b0dd5698  sub rsp, 0xF0
00007957b0dd569f  vmovaps [rsp], xmm0
00007957b0dd56a4  vmovaps [rsp+0x10], xmm1
00007957b0dd56aa  vmovaps [rsp+0x20], xmm2
00007957b0dd56b0  vmovaps [rsp+0x30], xmm3
00007957b0dd56b6  vmovaps [rsp+0x40], xmm4
00007957b0dd56bc  vmovaps [rsp+0x50], xmm5
00007957b0dd56c2  vmovaps [rsp+0x60], xmm6
00007957b0dd56c8  vmovaps [rsp+0x70], xmm7
00007957b0dd56ce  vmovaps [rsp+0x80], xmm9
00007957b0dd56d7  vmovaps [rsp+0x90], xmm10
00007957b0dd56e0  vmovaps [rsp+0xA0], xmm11
00007957b0dd56e9  vmovaps [rsp+0xB0], xmm12
00007957b0dd56f2  vmovaps [rsp+0xC0], xmm13
00007957b0dd56fb  vmovaps [rsp+0xD0], xmm14
00007957b0dd5704  vmovaps [rsp+0xE0], xmm15
00007957b0dd570d  sub rsp, 0x40
00007957b0dd5711  lea rdi, [rsp]
00007957b0dd5715  lea rsi, [rsp+0x10]
00007957b0dd571a  lea rdx, [rsp+0x20]
00007957b0dd571f  lea rcx, [rsp+0x30]
00007957b0dd5724  mov r8d, 0x00
00007957b0dd572a  lea r9, [r15+0x3A8]
00007957b0dd5731  movaps [rdi], xmm8
00007957b0dd5735  movaps [rsi], xmm10
00007957b0dd5739  movaps [rdx], xmm14
00007957b0dd573d  movaps [rcx], xmm9
00007957b0dd5741  mov rax, 0x56E396DF1A50
00007957b0dd574b  call rax
00007957b0dd574d  movaps xmm8, [rsp]
00007957b0dd5752  add rsp, 0x40
00007957b0dd5756  vmovaps xmm0, [rsp]
00007957b0dd575b  vmovaps xmm1, [rsp+0x10]
00007957b0dd5761  vmovaps xmm2, [rsp+0x20]
00007957b0dd5767  vmovaps xmm3, [rsp+0x30]
00007957b0dd576d  vmovaps xmm4, [rsp+0x40]
00007957b0dd5773  vmovaps xmm5, [rsp+0x50]
00007957b0dd5779  vmovaps xmm6, [rsp+0x60]
00007957b0dd577f  vmovaps xmm7, [rsp+0x70]
00007957b0dd5785  vmovaps xmm9, [rsp+0x80]
00007957b0dd578e  vmovaps xmm10, [rsp+0x90]
00007957b0dd5797  vmovaps xmm11, [rsp+0xA0]
00007957b0dd57a0  vmovaps xmm12, [rsp+0xB0]
00007957b0dd57a9  vmovaps xmm13, [rsp+0xC0]
00007957b0dd57b2  vmovaps xmm14, [rsp+0xD0]
00007957b0dd57bb  vmovaps xmm15, [rsp+0xE0]
00007957b0dd57c4  add rsp, 0xF0
00007957b0dd57cb  pop r11
00007957b0dd57cd  pop r10
00007957b0dd57cf  pop r9
00007957b0dd57d1  pop r8
00007957b0dd57d3  pop rsi
00007957b0dd57d4  pop rdi
00007957b0dd57d5  pop rdx
00007957b0dd57d6  pop rcx
00007957b0dd57d7  pop rax
00007957b0dd57d8  add rsp, 0x08
00007957b0dd57dc  jmp 0x00007957B0DD3083
00007957b0dd57e1  sub rsp, 0x08
00007957b0dd57e5  push rax
00007957b0dd57e6  push rcx
00007957b0dd57e7  push rdx
00007957b0dd57e8  push rdi
00007957b0dd57e9  push rsi
00007957b0dd57ea  push r8
00007957b0dd57ec  push r9
00007957b0dd57ee  push r10
00007957b0dd57f0  push r11
00007957b0dd57f2  sub rsp, 0xF0
00007957b0dd57f9  vmovaps [rsp], xmm0
00007957b0dd57fe  vmovaps [rsp+0x10], xmm1
00007957b0dd5804  vmovaps [rsp+0x20], xmm2
00007957b0dd580a  vmovaps [rsp+0x30], xmm3
00007957b0dd5810  vmovaps [rsp+0x40], xmm4
00007957b0dd5816  vmovaps [rsp+0x50], xmm5
00007957b0dd581c  vmovaps [rsp+0x60], xmm6
00007957b0dd5822  vmovaps [rsp+0x70], xmm7
00007957b0dd5828  vmovaps [rsp+0x80], xmm8
00007957b0dd5831  vmovaps [rsp+0x90], xmm9
00007957b0dd583a  vmovaps [rsp+0xA0], xmm11
00007957b0dd5843  vmovaps [rsp+0xB0], xmm12
00007957b0dd584c  vmovaps [rsp+0xC0], xmm13
00007957b0dd5855  vmovaps [rsp+0xD0], xmm14
00007957b0dd585e  vmovaps [rsp+0xE0], xmm15
00007957b0dd5867  sub rsp, 0x40
00007957b0dd586b  lea rdi, [rsp]
00007957b0dd586f  lea rsi, [rsp+0x10]
00007957b0dd5874  lea rdx, [rsp+0x20]
00007957b0dd5879  lea rcx, [rsp+0x30]
00007957b0dd587e  mov r8d, 0x00
00007957b0dd5884  lea r9, [r15+0x3A8]
00007957b0dd588b  movaps [rdi], xmm10
00007957b0dd588f  movaps [rsi], xmm13
00007957b0dd5893  movaps [rdx], xmm11
00007957b0dd5897  movaps [rcx], xmm14
00007957b0dd589b  mov rax, 0x56E396DF1A50
00007957b0dd58a5  call rax
00007957b0dd58a7  movaps xmm10, [rsp]
00007957b0dd58ac  add rsp, 0x40
00007957b0dd58b0  vmovaps xmm0, [rsp]
00007957b0dd58b5  vmovaps xmm1, [rsp+0x10]
00007957b0dd58bb  vmovaps xmm2, [rsp+0x20]
00007957b0dd58c1  vmovaps xmm3, [rsp+0x30]
00007957b0dd58c7  vmovaps xmm4, [rsp+0x40]
00007957b0dd58cd  vmovaps xmm5, [rsp+0x50]
00007957b0dd58d3  vmovaps xmm6, [rsp+0x60]
00007957b0dd58d9  vmovaps xmm7, [rsp+0x70]
00007957b0dd58df  vmovaps xmm8, [rsp+0x80]
00007957b0dd58e8  vmovaps xmm9, [rsp+0x90]
00007957b0dd58f1  vmovaps xmm11, [rsp+0xA0]
00007957b0dd58fa  vmovaps xmm12, [rsp+0xB0]
00007957b0dd5903  vmovaps xmm13, [rsp+0xC0]
00007957b0dd590c  vmovaps xmm14, [rsp+0xD0]
00007957b0dd5915  vmovaps xmm15, [rsp+0xE0]
00007957b0dd591e  add rsp, 0xF0
00007957b0dd5925  pop r11
00007957b0dd5927  pop r10
00007957b0dd5929  pop r9
00007957b0dd592b  pop r8
00007957b0dd592d  pop rsi
00007957b0dd592e  pop rdi
00007957b0dd592f  pop rdx
00007957b0dd5930  pop rcx
00007957b0dd5931  pop rax
00007957b0dd5932  add rsp, 0x08
00007957b0dd5936  jmp 0x00007957B0DD30A9
00007957b0dd593b  sub rsp, 0x08
00007957b0dd593f  push rax
00007957b0dd5940  push rcx
00007957b0dd5941  push rdx
00007957b0dd5942  push rdi
00007957b0dd5943  push rsi
00007957b0dd5944  push r8
00007957b0dd5946  push r9
00007957b0dd5948  push r10
00007957b0dd594a  push r11
00007957b0dd594c  sub rsp, 0xF0
00007957b0dd5953  vmovaps [rsp], xmm0
00007957b0dd5958  vmovaps [rsp+0x10], xmm1
00007957b0dd595e  vmovaps [rsp+0x20], xmm2
00007957b0dd5964  vmovaps [rsp+0x30], xmm3
00007957b0dd596a  vmovaps [rsp+0x40], xmm4
00007957b0dd5970  vmovaps [rsp+0x50], xmm5
00007957b0dd5976  vmovaps [rsp+0x60], xmm6
00007957b0dd597c  vmovaps [rsp+0x70], xmm7
00007957b0dd5982  vmovaps [rsp+0x80], xmm8
00007957b0dd598b  vmovaps [rsp+0x90], xmm9
00007957b0dd5994  vmovaps [rsp+0xA0], xmm10
00007957b0dd599d  vmovaps [rsp+0xB0], xmm11
00007957b0dd59a6  vmovaps [rsp+0xC0], xmm12
00007957b0dd59af  vmovaps [rsp+0xD0], xmm14
00007957b0dd59b8  vmovaps [rsp+0xE0], xmm15
00007957b0dd59c1  sub rsp, 0x40
00007957b0dd59c5  lea rdi, [rsp]
00007957b0dd59c9  lea rsi, [rsp+0x10]
00007957b0dd59ce  lea rdx, [rsp+0x20]
00007957b0dd59d3  lea rcx, [rsp+0x30]
00007957b0dd59d8  mov r8d, 0x00
00007957b0dd59de  lea r9, [r15+0x3A8]
00007957b0dd59e5  movaps [rdi], xmm13
00007957b0dd59e9  movaps [rsi], xmm12
00007957b0dd59ed  movaps [rdx], xmm15
00007957b0dd59f1  movaps [rcx], xmm14
00007957b0dd59f5  mov rax, 0x56E396DF1A50
00007957b0dd59ff  call rax
00007957b0dd5a01  movaps xmm13, [rsp]
00007957b0dd5a06  add rsp, 0x40
00007957b0dd5a0a  vmovaps xmm0, [rsp]
00007957b0dd5a0f  vmovaps xmm1, [rsp+0x10]
00007957b0dd5a15  vmovaps xmm2, [rsp+0x20]
00007957b0dd5a1b  vmovaps xmm3, [rsp+0x30]
00007957b0dd5a21  vmovaps xmm4, [rsp+0x40]
00007957b0dd5a27  vmovaps xmm5, [rsp+0x50]
00007957b0dd5a2d  vmovaps xmm6, [rsp+0x60]
00007957b0dd5a33  vmovaps xmm7, [rsp+0x70]
00007957b0dd5a39  vmovaps xmm8, [rsp+0x80]
00007957b0dd5a42  vmovaps xmm9, [rsp+0x90]
00007957b0dd5a4b  vmovaps xmm10, [rsp+0xA0]
00007957b0dd5a54  vmovaps xmm11, [rsp+0xB0]
00007957b0dd5a5d  vmovaps xmm12, [rsp+0xC0]
00007957b0dd5a66  vmovaps xmm14, [rsp+0xD0]
00007957b0dd5a6f  vmovaps xmm15, [rsp+0xE0]
00007957b0dd5a78  add rsp, 0xF0
00007957b0dd5a7f  pop r11
00007957b0dd5a81  pop r10
00007957b0dd5a83  pop r9
00007957b0dd5a85  pop r8
00007957b0dd5a87  pop rsi
00007957b0dd5a88  pop rdi
00007957b0dd5a89  pop rdx
00007957b0dd5a8a  pop rcx
00007957b0dd5a8b  pop rax
00007957b0dd5a8c  add rsp, 0x08
00007957b0dd5a90  jmp 0x00007957B0DD30CF
00007957b0dd5a95  call 0x00007957B0C0E760
00007957b0dd5a9a  jmp 0x00007957B0DD30DC
00007957b0dd5a9f  call 0x00007957B0C0D4E0
00007957b0dd5aa4  jmp 0x00007957B0DD30E9
00007957b0dd5aa9  sub rsp, 0x08
00007957b0dd5aad  push rax
00007957b0dd5aae  push rcx
00007957b0dd5aaf  push rdx
00007957b0dd5ab0  push rdi
00007957b0dd5ab1  push rsi
00007957b0dd5ab2  push r8
00007957b0dd5ab4  push r9
00007957b0dd5ab6  push r10
00007957b0dd5ab8  push r11
00007957b0dd5aba  sub rsp, 0xF0
00007957b0dd5ac1  vmovaps [rsp], xmm0
00007957b0dd5ac6  vmovaps [rsp+0x10], xmm1
00007957b0dd5acc  vmovaps [rsp+0x20], xmm2
00007957b0dd5ad2  vmovaps [rsp+0x30], xmm3
00007957b0dd5ad8  vmovaps [rsp+0x40], xmm4
00007957b0dd5ade  vmovaps [rsp+0x50], xmm5
00007957b0dd5ae4  vmovaps [rsp+0x60], xmm6
00007957b0dd5aea  vmovaps [rsp+0x70], xmm7
00007957b0dd5af0  vmovaps [rsp+0x80], xmm8
00007957b0dd5af9  vmovaps [rsp+0x90], xmm9
00007957b0dd5b02  vmovaps [rsp+0xA0], xmm10
00007957b0dd5b0b  vmovaps [rsp+0xB0], xmm12
00007957b0dd5b14  vmovaps [rsp+0xC0], xmm13
00007957b0dd5b1d  vmovaps [rsp+0xD0], xmm14
00007957b0dd5b26  vmovaps [rsp+0xE0], xmm15
00007957b0dd5b2f  sub rsp, 0x40
00007957b0dd5b33  lea rdi, [rsp]
00007957b0dd5b37  lea rsi, [rsp+0x10]
00007957b0dd5b3c  lea rdx, [rsp+0x20]
00007957b0dd5b41  lea rcx, [rsp+0x30]
00007957b0dd5b46  mov r8d, 0x00
00007957b0dd5b4c  lea r9, [r15+0x3A8]
00007957b0dd5b53  movaps [rdi], xmm11
00007957b0dd5b57  movaps [rsi], xmm7
00007957b0dd5b5a  movaps [rdx], xmm1
00007957b0dd5b5d  movaps [rcx], xmm12
00007957b0dd5b61  mov rax, 0x56E396DF1A50
00007957b0dd5b6b  call rax
00007957b0dd5b6d  movaps xmm11, [rsp]
00007957b0dd5b72  add rsp, 0x40
00007957b0dd5b76  vmovaps xmm0, [rsp]
00007957b0dd5b7b  vmovaps xmm1, [rsp+0x10]
00007957b0dd5b81  vmovaps xmm2, [rsp+0x20]
00007957b0dd5b87  vmovaps xmm3, [rsp+0x30]
00007957b0dd5b8d  vmovaps xmm4, [rsp+0x40]
00007957b0dd5b93  vmovaps xmm5, [rsp+0x50]
00007957b0dd5b99  vmovaps xmm6, [rsp+0x60]
00007957b0dd5b9f  vmovaps xmm7, [rsp+0x70]
00007957b0dd5ba5  vmovaps xmm8, [rsp+0x80]
00007957b0dd5bae  vmovaps xmm9, [rsp+0x90]
00007957b0dd5bb7  vmovaps xmm10, [rsp+0xA0]
00007957b0dd5bc0  vmovaps xmm12, [rsp+0xB0]
00007957b0dd5bc9  vmovaps xmm13, [rsp+0xC0]
00007957b0dd5bd2  vmovaps xmm14, [rsp+0xD0]
00007957b0dd5bdb  vmovaps xmm15, [rsp+0xE0]
00007957b0dd5be4  add rsp, 0xF0
00007957b0dd5beb  pop r11
00007957b0dd5bed  pop r10
00007957b0dd5bef  pop r9
00007957b0dd5bf1  pop r8
00007957b0dd5bf3  pop rsi
00007957b0dd5bf4  pop rdi
00007957b0dd5bf5  pop rdx
00007957b0dd5bf6  pop rcx
00007957b0dd5bf7  pop rax
00007957b0dd5bf8  add rsp, 0x08
00007957b0dd5bfc  jmp 0x00007957B0DD3122
00007957b0dd5c01  call 0x00007957B0BFF430
00007957b0dd5c06  jmp 0x00007957B0DD3134
00007957b0dd5c0b  sub rsp, 0x08
00007957b0dd5c0f  push rax
00007957b0dd5c10  push rcx
00007957b0dd5c11  push rdx
00007957b0dd5c12  push rdi
00007957b0dd5c13  push rsi
00007957b0dd5c14  push r8
00007957b0dd5c16  push r9
00007957b0dd5c18  push r10
00007957b0dd5c1a  push r11
00007957b0dd5c1c  sub rsp, 0xF0
00007957b0dd5c23  vmovaps [rsp], xmm0
00007957b0dd5c28  vmovaps [rsp+0x10], xmm1
00007957b0dd5c2e  vmovaps [rsp+0x20], xmm2
00007957b0dd5c34  vmovaps [rsp+0x30], xmm3
00007957b0dd5c3a  vmovaps [rsp+0x40], xmm4
00007957b0dd5c40  vmovaps [rsp+0x50], xmm5
00007957b0dd5c46  vmovaps [rsp+0x60], xmm6
00007957b0dd5c4c  vmovaps [rsp+0x70], xmm7
00007957b0dd5c52  vmovaps [rsp+0x80], xmm8
00007957b0dd5c5b  vmovaps [rsp+0x90], xmm10
00007957b0dd5c64  vmovaps [rsp+0xA0], xmm11
00007957b0dd5c6d  vmovaps [rsp+0xB0], xmm12
00007957b0dd5c76  vmovaps [rsp+0xC0], xmm13
00007957b0dd5c7f  vmovaps [rsp+0xD0], xmm14
00007957b0dd5c88  vmovaps [rsp+0xE0], xmm15
00007957b0dd5c91  sub rsp, 0x40
00007957b0dd5c95  lea rdi, [rsp]
00007957b0dd5c99  lea rsi, [rsp+0x10]
00007957b0dd5c9e  lea rdx, [rsp+0x20]
00007957b0dd5ca3  lea rcx, [rsp+0x30]
00007957b0dd5ca8  mov r8d, 0x00
00007957b0dd5cae  lea r9, [r15+0x3A8]
00007957b0dd5cb5  movaps [rdi], xmm9
00007957b0dd5cb9  movaps [rsi], xmm8
00007957b0dd5cbd  movaps [rdx], xmm14
00007957b0dd5cc1  movaps [rcx], xmm12
00007957b0dd5cc5  mov rax, 0x56E396DF1A50
00007957b0dd5ccf  call rax
00007957b0dd5cd1  movaps xmm9, [rsp]
00007957b0dd5cd6  add rsp, 0x40
00007957b0dd5cda  vmovaps xmm0, [rsp]
00007957b0dd5cdf  vmovaps xmm1, [rsp+0x10]
00007957b0dd5ce5  vmovaps xmm2, [rsp+0x20]
00007957b0dd5ceb  vmovaps xmm3, [rsp+0x30]
00007957b0dd5cf1  vmovaps xmm4, [rsp+0x40]
00007957b0dd5cf7  vmovaps xmm5, [rsp+0x50]
00007957b0dd5cfd  vmovaps xmm6, [rsp+0x60]
00007957b0dd5d03  vmovaps xmm7, [rsp+0x70]
00007957b0dd5d09  vmovaps xmm8, [rsp+0x80]
00007957b0dd5d12  vmovaps xmm10, [rsp+0x90]
00007957b0dd5d1b  vmovaps xmm11, [rsp+0xA0]
00007957b0dd5d24  vmovaps xmm12, [rsp+0xB0]
00007957b0dd5d2d  vmovaps xmm13, [rsp+0xC0]
00007957b0dd5d36  vmovaps xmm14, [rsp+0xD0]
00007957b0dd5d3f  vmovaps xmm15, [rsp+0xE0]
00007957b0dd5d48  add rsp, 0xF0
00007957b0dd5d4f  pop r11
00007957b0dd5d51  pop r10
00007957b0dd5d53  pop r9
00007957b0dd5d55  pop r8
00007957b0dd5d57  pop rsi
00007957b0dd5d58  pop rdi
00007957b0dd5d59  pop rdx
00007957b0dd5d5a  pop rcx
00007957b0dd5d5b  pop rax
00007957b0dd5d5c  add rsp, 0x08
00007957b0dd5d60  jmp 0x00007957B0DD3165
00007957b0dd5d65  sub rsp, 0x08
00007957b0dd5d69  push rax
00007957b0dd5d6a  push rcx
00007957b0dd5d6b  push rdx
00007957b0dd5d6c  push rdi
00007957b0dd5d6d  push rsi
00007957b0dd5d6e  push r8
00007957b0dd5d70  push r9
00007957b0dd5d72  push r10
00007957b0dd5d74  push r11
00007957b0dd5d76  sub rsp, 0xF0
00007957b0dd5d7d  vmovaps [rsp], xmm0
00007957b0dd5d82  vmovaps [rsp+0x10], xmm1
00007957b0dd5d88  vmovaps [rsp+0x20], xmm2
00007957b0dd5d8e  vmovaps [rsp+0x30], xmm3
00007957b0dd5d94  vmovaps [rsp+0x40], xmm4
00007957b0dd5d9a  vmovaps [rsp+0x50], xmm5
00007957b0dd5da0  vmovaps [rsp+0x60], xmm6
00007957b0dd5da6  vmovaps [rsp+0x70], xmm7
00007957b0dd5dac  vmovaps [rsp+0x80], xmm8
00007957b0dd5db5  vmovaps [rsp+0x90], xmm9
00007957b0dd5dbe  vmovaps [rsp+0xA0], xmm10
00007957b0dd5dc7  vmovaps [rsp+0xB0], xmm11
00007957b0dd5dd0  vmovaps [rsp+0xC0], xmm13
00007957b0dd5dd9  vmovaps [rsp+0xD0], xmm14
00007957b0dd5de2  vmovaps [rsp+0xE0], xmm15
00007957b0dd5deb  sub rsp, 0x40
00007957b0dd5def  lea rdi, [rsp]
00007957b0dd5df3  lea rsi, [rsp+0x10]
00007957b0dd5df8  lea rdx, [rsp+0x20]
00007957b0dd5dfd  lea rcx, [rsp+0x30]
00007957b0dd5e02  mov r8d, 0x00
00007957b0dd5e08  lea r9, [r15+0x3A8]
00007957b0dd5e0f  movaps [rdi], xmm12
00007957b0dd5e13  movaps [rsi], xmm10
00007957b0dd5e17  movaps [rdx], xmm15
00007957b0dd5e1b  movaps [rcx], xmm14
00007957b0dd5e1f  mov rax, 0x56E396DF1A50
00007957b0dd5e29  call rax
00007957b0dd5e2b  movaps xmm12, [rsp]
00007957b0dd5e30  add rsp, 0x40
00007957b0dd5e34  vmovaps xmm0, [rsp]
00007957b0dd5e39  vmovaps xmm1, [rsp+0x10]
00007957b0dd5e3f  vmovaps xmm2, [rsp+0x20]
00007957b0dd5e45  vmovaps xmm3, [rsp+0x30]
00007957b0dd5e4b  vmovaps xmm4, [rsp+0x40]
00007957b0dd5e51  vmovaps xmm5, [rsp+0x50]
00007957b0dd5e57  vmovaps xmm6, [rsp+0x60]
00007957b0dd5e5d  vmovaps xmm7, [rsp+0x70]
00007957b0dd5e63  vmovaps xmm8, [rsp+0x80]
00007957b0dd5e6c  vmovaps xmm9, [rsp+0x90]
00007957b0dd5e75  vmovaps xmm10, [rsp+0xA0]
00007957b0dd5e7e  vmovaps xmm11, [rsp+0xB0]
00007957b0dd5e87  vmovaps xmm13, [rsp+0xC0]
00007957b0dd5e90  vmovaps xmm14, [rsp+0xD0]
00007957b0dd5e99  vmovaps xmm15, [rsp+0xE0]
00007957b0dd5ea2  add rsp, 0xF0
00007957b0dd5ea9  pop r11
00007957b0dd5eab  pop r10
00007957b0dd5ead  pop r9
00007957b0dd5eaf  pop r8
00007957b0dd5eb1  pop rsi
00007957b0dd5eb2  pop rdi
00007957b0dd5eb3  pop rdx
00007957b0dd5eb4  pop rcx
00007957b0dd5eb5  pop rax
00007957b0dd5eb6  add rsp, 0x08
00007957b0dd5eba  jmp 0x00007957B0DD3196
00007957b0dd5ebf  sub rsp, 0x08
00007957b0dd5ec3  push rax
00007957b0dd5ec4  push rcx
00007957b0dd5ec5  push rdx
00007957b0dd5ec6  push rdi
00007957b0dd5ec7  push rsi
00007957b0dd5ec8  push r8
00007957b0dd5eca  push r9
00007957b0dd5ecc  push r10
00007957b0dd5ece  push r11
00007957b0dd5ed0  sub rsp, 0xF0
00007957b0dd5ed7  vmovaps [rsp], xmm0
00007957b0dd5edc  vmovaps [rsp+0x10], xmm1
00007957b0dd5ee2  vmovaps [rsp+0x20], xmm2
00007957b0dd5ee8  vmovaps [rsp+0x30], xmm3
00007957b0dd5eee  vmovaps [rsp+0x40], xmm4
00007957b0dd5ef4  vmovaps [rsp+0x50], xmm5
00007957b0dd5efa  vmovaps [rsp+0x60], xmm6
00007957b0dd5f00  vmovaps [rsp+0x70], xmm7
00007957b0dd5f06  vmovaps [rsp+0x80], xmm8
00007957b0dd5f0f  vmovaps [rsp+0x90], xmm9
00007957b0dd5f18  vmovaps [rsp+0xA0], xmm10
00007957b0dd5f21  vmovaps [rsp+0xB0], xmm11
00007957b0dd5f2a  vmovaps [rsp+0xC0], xmm12
00007957b0dd5f33  vmovaps [rsp+0xD0], xmm13
00007957b0dd5f3c  vmovaps [rsp+0xE0], xmm15
00007957b0dd5f45  sub rsp, 0x40
00007957b0dd5f49  lea rdi, [rsp]
00007957b0dd5f4d  lea rsi, [rsp+0x10]
00007957b0dd5f52  lea rdx, [rsp+0x20]
00007957b0dd5f57  lea rcx, [rsp+0x30]
00007957b0dd5f5c  mov r8d, 0x00
00007957b0dd5f62  lea r9, [r15+0x3A8]
00007957b0dd5f69  movaps [rdi], xmm14
00007957b0dd5f6d  movaps [rsi], xmm13
00007957b0dd5f71  movaps [rdx], xmm1
00007957b0dd5f74  movaps [rcx], xmm15
00007957b0dd5f78  mov rax, 0x56E396DF1A50
00007957b0dd5f82  call rax
00007957b0dd5f84  movaps xmm14, [rsp]
00007957b0dd5f89  add rsp, 0x40
00007957b0dd5f8d  vmovaps xmm0, [rsp]
00007957b0dd5f92  vmovaps xmm1, [rsp+0x10]
00007957b0dd5f98  vmovaps xmm2, [rsp+0x20]
00007957b0dd5f9e  vmovaps xmm3, [rsp+0x30]
00007957b0dd5fa4  vmovaps xmm4, [rsp+0x40]
00007957b0dd5faa  vmovaps xmm5, [rsp+0x50]
00007957b0dd5fb0  vmovaps xmm6, [rsp+0x60]
00007957b0dd5fb6  vmovaps xmm7, [rsp+0x70]
00007957b0dd5fbc  vmovaps xmm8, [rsp+0x80]
00007957b0dd5fc5  vmovaps xmm9, [rsp+0x90]
00007957b0dd5fce  vmovaps xmm10, [rsp+0xA0]
00007957b0dd5fd7  vmovaps xmm11, [rsp+0xB0]
00007957b0dd5fe0  vmovaps xmm12, [rsp+0xC0]
00007957b0dd5fe9  vmovaps xmm13, [rsp+0xD0]
00007957b0dd5ff2  vmovaps xmm15, [rsp+0xE0]
00007957b0dd5ffb  add rsp, 0xF0
00007957b0dd6002  pop r11
00007957b0dd6004  pop r10
00007957b0dd6006  pop r9
00007957b0dd6008  pop r8
00007957b0dd600a  pop rsi
00007957b0dd600b  pop rdi
00007957b0dd600c  pop rdx
00007957b0dd600d  pop rcx
00007957b0dd600e  pop rax
00007957b0dd600f  add rsp, 0x08
00007957b0dd6013  jmp 0x00007957B0DD31C7
00007957b0dd6018  call 0x00007957B0C079B0
00007957b0dd601d  jmp 0x00007957B0DD31DA
00007957b0dd6022  call 0x00007957B0C0B100
00007957b0dd6027  jmp 0x00007957B0DD31E5
00007957b0dd602c  call 0x00007957B0C09E90
00007957b0dd6031  jmp 0x00007957B0DD31F0
00007957b0dd6036  call 0x00007957B0C0D600
00007957b0dd603b  jmp 0x00007957B0DD31FB
00007957b0dd6040  int3
00007957b0dd6041  nop [rax+rax*1], ax
00007957b0dd604a  nop [rax+rax*1], ax
00007957b0dd6050  mov rax, [r15+0x40]
00007957b0dd6054  mov r14, [r15+0x58]
00007957b0dd6058  lea r12, [rax+r14*1]
00007957b0dd605c  vxorps xmm1, xmm1, xmm1
00007957b0dd6060  vpbroadcastq xmm1, xmm1
00007957b0dd6065  vxorps xmm15, xmm15, xmm15
00007957b0dd606a  vpbroadcastq xmm15, xmm15
00007957b0dd606f  lea rax, [r12+0x30]
00007957b0dd6074  mov r11, [r13+rax*1]
00007957b0dd6079  lea rax, [r12+0x38]
00007957b0dd607e  mov r10, [r13+rax*1]
00007957b0dd6083  movq xmm14, r11
00007957b0dd6088  movq xmm13, r10
00007957b0dd608d  movq xmm14, xmm14
00007957b0dd6092  movq xmm13, xmm13
00007957b0dd6097  vmovaps [rsp+0x10], xmm13
00007957b0dd609d  movq xmm13, xmm13
00007957b0dd60a2  movaps [r15+0x270], xmm13
00007957b0dd60aa  movaps xmm13, [r15+0x160]
00007957b0dd60b2  vmovaps [rsp+0x20], xmm13
00007957b0dd60b8  vmovaps xmm12, [rsp+0x20]
00007957b0dd60be  por xmm13, xmm12
00007957b0dd60c3  lea rax, [r12+0x20]
00007957b0dd60c8  mov r11, [r13+rax*1]
00007957b0dd60cd  lea rax, [r12+0x28]
00007957b0dd60d2  mov r10, [r13+rax*1]
00007957b0dd60d7  movq xmm12, r11
00007957b0dd60dc  movq xmm11, r10
00007957b0dd60e1  movq xmm12, xmm12
00007957b0dd60e6  movq xmm11, xmm11
00007957b0dd60eb  movaps xmm10, [r15+0x2D0]
00007957b0dd60f3  vmovaps [rsp+0x20], xmm10
00007957b0dd60f9  vmovaps xmm9, [rsp+0x20]
00007957b0dd60ff  por xmm10, xmm9
00007957b0dd6104  movaps xmm9, [r15+0x300]
00007957b0dd610c  vmovaps [rsp+0x20], xmm9
00007957b0dd6112  vmovaps xmm8, [rsp+0x20]
00007957b0dd6118  por xmm9, xmm8
00007957b0dd611d  movaps xmm8, [r15+0x2B0]
00007957b0dd6125  vmovaps [rsp+0x20], xmm8
00007957b0dd612b  vmovaps xmm7, [rsp+0x20]
00007957b0dd6131  por xmm8, xmm7
00007957b0dd6136  movaps xmm7, [r15+0x180]
00007957b0dd613e  vmovaps [rsp+0x20], xmm7
00007957b0dd6144  vmovaps xmm6, [rsp+0x20]
00007957b0dd614a  por xmm7, xmm6
00007957b0dd614e  lea rax, [r12+0x10]
00007957b0dd6153  mov r11, [r13+rax*1]
00007957b0dd6158  lea rax, [r12+0x18]
00007957b0dd615d  mov r10, [r13+rax*1]
00007957b0dd6162  movq xmm6, r11
00007957b0dd6167  movq xmm5, r10
00007957b0dd616c  movq xmm6, xmm6
00007957b0dd6170  movq xmm5, xmm5
00007957b0dd6174  movaps xmm4, [r15+0x200]
00007957b0dd617c  vmovaps [rsp+0x20], xmm4
00007957b0dd6182  vmovaps xmm3, [rsp+0x20]
00007957b0dd6188  por xmm4, xmm3
00007957b0dd618c  movaps xmm3, [r15+0x1F0]
00007957b0dd6194  vmovaps [rsp+0x20], xmm3
00007957b0dd619a  vmovaps xmm2, [rsp+0x20]
00007957b0dd61a0  por xmm3, xmm2
00007957b0dd61a4  movaps xmm2, [r15+0x2E0]
00007957b0dd61ac  vmovaps [rsp+0x20], xmm2
00007957b0dd61b2  vmovaps [rsp+0x30], xmm1
00007957b0dd61b8  vmovaps xmm1, [rsp+0x20]
00007957b0dd61be  por xmm2, xmm1
00007957b0dd61c2  movaps xmm1, [r15+0x2A0]
00007957b0dd61ca  vmovaps [rsp+0x20], xmm1
00007957b0dd61d0  vmovaps [rsp+0x40], xmm15
00007957b0dd61d6  vmovaps xmm15, [rsp+0x20]
00007957b0dd61dc  por xmm1, xmm15
00007957b0dd61e1  movaps xmm15, [r15+0x280]
00007957b0dd61e9  vmovaps [rsp+0x20], xmm15
00007957b0dd61ef  vmovaps [rsp+0x50], xmm1
00007957b0dd61f5  vmovaps xmm1, [rsp+0x20]
00007957b0dd61fb  por xmm15, xmm1
00007957b0dd6200  movaps xmm1, [r15+0x1C0]
00007957b0dd6208  vmovaps [rsp+0x20], xmm1
00007957b0dd620e  vmovaps [rsp+0x60], xmm15
00007957b0dd6214  vmovaps xmm15, [rsp+0x20]
00007957b0dd621a  por xmm1, xmm15
00007957b0dd621f  movaps xmm15, [r15+0x210]
00007957b0dd6227  vmovaps [rsp+0x20], xmm15
00007957b0dd622d  vmovaps [rsp+0x70], xmm1
00007957b0dd6233  vmovaps xmm1, [rsp+0x20]
00007957b0dd6239  por xmm15, xmm1
00007957b0dd623e  mov rax, [r13+r12*1]
00007957b0dd6243  vmovq xmm1, rax
00007957b0dd6248  vpbroadcastq xmm1, xmm1
00007957b0dd624d  vmovaps [rsp+0x20], xmm1
00007957b0dd6253  vxorps xmm1, xmm1, xmm1
00007957b0dd6257  vpbroadcastq xmm1, xmm1
00007957b0dd625c  mov rax, [r15+0xF8]
00007957b0dd6263  vmovaps [rsp+0x80], xmm1
00007957b0dd626c  movups xmm1, [r13+rax*1]
00007957b0dd6272  vmovaps [rsp+0x90], xmm1
00007957b0dd627b  vxorps xmm1, xmm1, xmm1
00007957b0dd627f  vpbroadcastq xmm1, xmm1
00007957b0dd6284  lea r11, [r12+0x08]
00007957b0dd6289  mov r12, [r13+r11*1]
00007957b0dd628e  vmovaps [rsp+0xA0], xmm1
00007957b0dd6297  movq xmm1, r12
00007957b0dd629c  movaps [r15+0x240], xmm1
00007957b0dd62a4  mov r12, [r15+0x50]
00007957b0dd62a8  lea r11, [r12+r14*1]
00007957b0dd62ac  mov [r15+0x60], r11
00007957b0dd62b0  lea r12, [r14+0x40]
00007957b0dd62b4  mov [r15+0x58], r12
00007957b0dd62b8  vmovaps xmm1, [rsp+0x30]
00007957b0dd62be  vmovaps [rsp+0x30], xmm15
00007957b0dd62c4  vmovaps xmm15, [rsp+0x90]
00007957b0dd62cd  vmovaps [rsp+0x90], xmm14
00007957b0dd62d6  vmovaps xmm14, [rsp+0x20]
00007957b0dd62dc  vmovaps [rsp+0x20], xmm13
00007957b0dd62e2  vmovaps [rsp+0xB0], xmm12
00007957b0dd62eb  movaps xmm13, xmm1
00007957b0dd62ef  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd62fa  vptest xmm12, xmm12
00007957b0dd62ff  jnz 0x00007957B0DD6D9C
00007957b0dd6305  movaps xmm1, [r15+0x250]
00007957b0dd630d  vmovaps xmm15, [rsp+0x40]
00007957b0dd6313  vmovaps [rsp+0x40], xmm13
00007957b0dd6319  movaps xmm12, xmm15
00007957b0dd631d  vfmadd231pd xmm12, xmm1, xmm14
00007957b0dd6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007957b0dd6328  vptest xmm13, xmm13
00007957b0dd632d  jnz 0x00007957B0DD6EF5
00007957b0dd6333  movaps xmm15, [r15+0x1E0]
00007957b0dd633b  vmovaps [rsp+0xC0], xmm15
00007957b0dd6344  vmovaps xmm13, [rsp+0xC0]
00007957b0dd634d  por xmm15, xmm13
00007957b0dd6352  movaps xmm13, [r15+0x1D0]
00007957b0dd635a  vmovaps [rsp+0xC0], xmm13
00007957b0dd6363  vmovaps [rsp+0xD0], xmm1
00007957b0dd636c  vmovaps xmm1, [rsp+0xC0]
00007957b0dd6375  por xmm13, xmm1
00007957b0dd637a  movaps xmm1, [r15+0x2C0]
00007957b0dd6382  vmovaps [rsp+0xC0], xmm1
00007957b0dd638b  vmovaps [rsp+0xE0], xmm15
00007957b0dd6394  vmovaps xmm15, [rsp+0xC0]
00007957b0dd639d  por xmm1, xmm15
00007957b0dd63a2  movaps xmm15, [r15+0x290]
00007957b0dd63aa  vmovaps [rsp+0xC0], xmm15
00007957b0dd63b3  vmovaps [rsp+0xF0], xmm1
00007957b0dd63bc  vmovaps xmm1, [rsp+0xC0]
00007957b0dd63c5  por xmm15, xmm1
00007957b0dd63ca  movaps xmm1, [r15+0x260]
00007957b0dd63d2  vmovaps [rsp+0xC0], xmm1
00007957b0dd63db  vmovaps [rsp+0x100], xmm15
00007957b0dd63e4  vmovaps xmm15, [rsp+0xC0]
00007957b0dd63ed  por xmm1, xmm15
00007957b0dd63f2  vmovaps xmm15, [rsp+0xD0]
00007957b0dd63fb  vmovaps [rsp+0xC0], xmm1
00007957b0dd6404  vmovaps xmm1, [rsp+0xD0]
00007957b0dd640d  por xmm15, xmm1
00007957b0dd6412  lea r14, [rax+0xC0]
00007957b0dd6419  movups xmm1, [r13+r14*1]
00007957b0dd641f  mov [rsp+0xD0], rax
00007957b0dd6427  xor eax, eax
00007957b0dd6429  mov r14d, 0x200
00007957b0dd642f  cmp r12, r14
00007957b0dd6432  cmc
00007957b0dd6433  lahf
00007957b0dd6434  seto al
00007957b0dd6437  mov [r15+0x108], eax
00007957b0dd643e  vmovaps [rsp+0x110], xmm1
00007957b0dd6447  vmovaps xmm1, [rsp+0x80]
00007957b0dd6450  vmovaps [rsp+0x80], xmm15
00007957b0dd6459  vmovaps xmm15, [rsp+0x110]
00007957b0dd6462  vmovaps [rsp+0x110], xmm13
00007957b0dd646b  vmovaps [rsp+0x120], xmm12
00007957b0dd6474  movaps xmm13, xmm1
00007957b0dd6478  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd6483  vptest xmm12, xmm12
00007957b0dd6488  jnz 0x00007957B0DD7058
00007957b0dd648e  mov rax, [rsp+0xD0]
00007957b0dd6496  lea r14, [rax+0xB0]
00007957b0dd649d  movups xmm1, [r13+r14*1]
00007957b0dd64a3  vmovaps xmm15, [rsp+0xA0]
00007957b0dd64ac  vmovaps [rsp+0xA0], xmm13
00007957b0dd64b5  movaps xmm12, xmm15
00007957b0dd64b9  vfmadd231pd xmm12, xmm1, xmm14
00007957b0dd64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007957b0dd64c4  vptest xmm13, xmm13
00007957b0dd64c9  jnz 0x00007957B0DD71BB
00007957b0dd64cf  vmovaps xmm1, [rsp+0x30]
00007957b0dd64d5  vmovaps xmm15, [rsp+0x30]
00007957b0dd64db  por xmm1, xmm15
00007957b0dd64e0  movaps [r15+0x210], xmm1
00007957b0dd64e8  vmovaps xmm15, [rsp+0x70]
00007957b0dd64ee  vmovaps xmm14, [rsp+0x70]
00007957b0dd64f4  por xmm15, xmm14
00007957b0dd64f9  movaps [r15+0x1C0], xmm15
00007957b0dd6501  vmovaps xmm14, [rsp+0x60]
00007957b0dd6507  vmovaps xmm13, [rsp+0x60]
00007957b0dd650d  por xmm14, xmm13
00007957b0dd6512  movaps [r15+0x280], xmm14
00007957b0dd651a  vmovaps xmm13, [rsp+0x50]
00007957b0dd6520  vmovaps [rsp+0x30], xmm1
00007957b0dd6526  vmovaps xmm1, [rsp+0x50]
00007957b0dd652c  por xmm13, xmm1
00007957b0dd6531  movaps [r15+0x2A0], xmm13
00007957b0dd6539  vmovaps [rsp+0x50], xmm2
00007957b0dd653f  vmovaps xmm1, [rsp+0x50]
00007957b0dd6545  por xmm2, xmm1
00007957b0dd6549  movaps [r15+0x2E0], xmm2
00007957b0dd6551  vmovaps [rsp+0x50], xmm3
00007957b0dd6557  vmovaps xmm1, [rsp+0x50]
00007957b0dd655d  por xmm3, xmm1
00007957b0dd6561  movaps [r15+0x1F0], xmm3
00007957b0dd6569  vmovaps xmm1, [rsp+0x80]
00007957b0dd6572  vmovaps [rsp+0x50], xmm15
00007957b0dd6578  vmovaps xmm15, [rsp+0x80]
00007957b0dd6581  por xmm1, xmm15
00007957b0dd6586  movaps [r15+0x250], xmm1
00007957b0dd658e  vmovaps xmm1, [rsp+0xC0]
00007957b0dd6597  vmovaps xmm15, [rsp+0xC0]
00007957b0dd65a0  por xmm1, xmm15
00007957b0dd65a5  movaps [r15+0x260], xmm1
00007957b0dd65ad  vmovaps xmm15, [rsp+0x100]
00007957b0dd65b6  vmovaps [rsp+0x60], xmm1
00007957b0dd65bc  vmovaps xmm1, [rsp+0x100]
00007957b0dd65c5  por xmm15, xmm1
00007957b0dd65ca  movaps [r15+0x290], xmm15
00007957b0dd65d2  vmovaps xmm1, [rsp+0xF0]
00007957b0dd65db  vmovaps [rsp+0x70], xmm15
00007957b0dd65e1  vmovaps xmm15, [rsp+0xF0]
00007957b0dd65ea  por xmm1, xmm15
00007957b0dd65ef  movaps [r15+0x2C0], xmm1
00007957b0dd65f7  movq xmm15, qword ptr [r15+0x240]
00007957b0dd6600  vmovaps [rsp+0x80], xmm15
00007957b0dd6609  vpermilpd xmm15, xmm15, 0x00
00007957b0dd660f  vmovaps [rsp+0xC0], xmm1
00007957b0dd6618  vmovaps xmm1, [rsp+0x40]
00007957b0dd661e  vmovaps [rsp+0x40], xmm15
00007957b0dd6624  vmovaps xmm15, [rsp+0x30]
00007957b0dd662a  vmovaps [rsp+0x30], xmm14
00007957b0dd6630  vmovaps xmm14, [rsp+0x40]
00007957b0dd6636  vmovaps [rsp+0x40], xmm13
00007957b0dd663c  vmovaps [rsp+0xD0], xmm12
00007957b0dd6645  movaps xmm13, xmm1
00007957b0dd6649  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd6654  vptest xmm12, xmm12
00007957b0dd6659  jnz 0x00007957B0DD7314
00007957b0dd665f  vmovaps xmm1, [rsp+0x80]
00007957b0dd6668  vpermilpd xmm1, xmm1, 0x00
00007957b0dd666e  vmovaps xmm15, [rsp+0xA0]
00007957b0dd6677  movaps xmm14, xmm15
00007957b0dd667b  vfmadd231pd xmm14, xmm2, xmm1
00007957b0dd6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007957b0dd6686  vptest xmm12, xmm12
00007957b0dd668b  jnz 0x00007957B0DD746D
00007957b0dd6691  vmovaps xmm1, [rsp+0x80]
00007957b0dd669a  vpermilpd xmm1, xmm1, 0x00
00007957b0dd66a0  vmovaps xmm15, [rsp+0x120]
00007957b0dd66a9  vmovaps xmm12, [rsp+0x50]
00007957b0dd66af  vmovaps [rsp+0x50], xmm14
00007957b0dd66b5  movaps xmm2, xmm15
00007957b0dd66b9  vfmadd231pd xmm2, xmm12, xmm1
00007957b0dd66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007957b0dd66c3  vptest xmm14, xmm14
00007957b0dd66c8  jnz 0x00007957B0DD75C5
00007957b0dd66ce  vmovaps xmm1, [rsp+0x110]
00007957b0dd66d7  vmovaps xmm15, [rsp+0x110]
00007957b0dd66e0  por xmm1, xmm15
00007957b0dd66e5  movaps [r15+0x1D0], xmm1
00007957b0dd66ed  vmovaps xmm15, [rsp+0x80]
00007957b0dd66f6  vpermilpd xmm15, xmm15, 0x00
00007957b0dd66fc  vmovaps xmm14, [rsp+0xD0]
00007957b0dd6705  vmovaps [rsp+0x80], xmm1
00007957b0dd670e  movaps xmm12, xmm14
00007957b0dd6712  vfmadd231pd xmm12, xmm3, xmm15
00007957b0dd6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007957b0dd671d  vptest xmm1, xmm1
00007957b0dd6722  jnz 0x00007957B0DD771C
00007957b0dd6728  vmovaps [rsp+0xA0], xmm4
00007957b0dd6731  vmovaps xmm1, [rsp+0xA0]
00007957b0dd673a  por xmm4, xmm1
00007957b0dd673e  movaps [r15+0x200], xmm4
00007957b0dd6746  vmovaps xmm1, [rsp+0xE0]
00007957b0dd674f  vmovaps xmm15, [rsp+0xE0]
00007957b0dd6758  por xmm1, xmm15
00007957b0dd675d  movaps [r15+0x1E0], xmm1
00007957b0dd6765  vmovaps [rsp+0xA0], xmm8
00007957b0dd676e  vmovaps xmm1, [rsp+0xA0]
00007957b0dd6777  por xmm8, xmm1
00007957b0dd677c  movaps [r15+0x2B0], xmm8
00007957b0dd6784  vmovaps [rsp+0xA0], xmm9
00007957b0dd678d  vmovaps xmm1, [rsp+0xA0]
00007957b0dd6796  por xmm9, xmm1
00007957b0dd679b  movaps [r15+0x300], xmm9
00007957b0dd67a3  vmovaps [rsp+0xA0], xmm6
00007957b0dd67ac  vpermilpd xmm6, xmm6, 0x00
00007957b0dd67b2  vmovaps xmm14, [rsp+0x60]
00007957b0dd67b8  movaps xmm9, xmm13
00007957b0dd67bc  vfmadd231pd xmm9, xmm14, xmm6
00007957b0dd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007957b0dd67c7  vptest xmm3, xmm3
00007957b0dd67cc  jnz 0x00007957B0DD7875
00007957b0dd67d2  vmovaps xmm14, [rsp+0xA0]
00007957b0dd67db  vpermilpd xmm14, xmm14, 0x00
00007957b0dd67e1  vmovaps xmm13, [rsp+0x50]
00007957b0dd67e7  vmovaps xmm6, [rsp+0xC0]
00007957b0dd67f0  vmovaps [rsp+0x50], xmm1
00007957b0dd67f6  movaps xmm3, xmm13
00007957b0dd67fa  vfmadd231pd xmm3, xmm6, xmm14
00007957b0dd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007957b0dd6804  vptest xmm1, xmm1
00007957b0dd6809  jnz 0x00007957B0DD79CE
00007957b0dd680f  vmovaps xmm1, [rsp+0xA0]
00007957b0dd6818  vpermilpd xmm1, xmm1, 0x00
00007957b0dd681e  vmovaps xmm14, [rsp+0x30]
00007957b0dd6824  movaps xmm6, xmm2
00007957b0dd6827  vfmadd231pd xmm6, xmm14, xmm1
00007957b0dd682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007957b0dd6831  vptest xmm13, xmm13
00007957b0dd6836  jnz 0x00007957B0DD7B25
00007957b0dd683c  vmovaps xmm1, [rsp+0xA0]
00007957b0dd6845  vpermilpd xmm1, xmm1, 0x00
00007957b0dd684b  vmovaps xmm14, [rsp+0x80]
00007957b0dd6854  movaps xmm13, xmm12
00007957b0dd6858  vfmadd231pd xmm13, xmm14, xmm1
00007957b0dd685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007957b0dd6863  vptest xmm2, xmm2
00007957b0dd6868  jnz 0x00007957B0DD7C7B
00007957b0dd686e  vmovaps [rsp+0x30], xmm7
00007957b0dd6874  vmovaps xmm1, [rsp+0x30]
00007957b0dd687a  por xmm7, xmm1
00007957b0dd687e  movaps [r15+0x180], xmm7
00007957b0dd6886  vmovaps [rsp+0x30], xmm10
00007957b0dd688c  vmovaps xmm1, [rsp+0x30]
00007957b0dd6892  por xmm10, xmm1
00007957b0dd6897  movaps [r15+0x2D0], xmm10
00007957b0dd689f  vmovaps [rsp+0x30], xmm5
00007957b0dd68a5  vpermilpd xmm5, xmm5, 0x00
00007957b0dd68ab  vmovaps xmm14, [rsp+0x50]
00007957b0dd68b1  movaps xmm12, xmm3
00007957b0dd68b5  vfmadd231pd xmm12, xmm14, xmm5
00007957b0dd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007957b0dd68c0  vptest xmm10, xmm10
00007957b0dd68c5  jnz 0x00007957B0DD7DD4
00007957b0dd68cb  vmovaps xmm14, [rsp+0x30]
00007957b0dd68d1  vpermilpd xmm14, xmm14, 0x00
00007957b0dd68d7  movaps xmm10, xmm9
00007957b0dd68db  vfmadd231pd xmm10, xmm7, xmm14
00007957b0dd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007957b0dd68e6  vptest xmm5, xmm5
00007957b0dd68eb  jnz 0x00007957B0DD7F2C
00007957b0dd68f1  lea r14, [rax+0x80]
00007957b0dd68f8  movups xmm14, [r13+r14*1]
00007957b0dd68fe  movaps [r15+0x2F0], xmm14
00007957b0dd6906  vmovaps xmm9, [rsp+0x30]
00007957b0dd690c  vpermilpd xmm9, xmm9, 0x00
00007957b0dd6912  vmovaps xmm7, [rsp+0x70]
00007957b0dd6918  movaps xmm5, xmm6
00007957b0dd691b  vfmadd231pd xmm5, xmm7, xmm9
00007957b0dd6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007957b0dd6925  vptest xmm3, xmm3
00007957b0dd692a  jnz 0x00007957B0DD808F
00007957b0dd6930  vmovaps xmm9, [rsp+0x30]
00007957b0dd6936  vpermilpd xmm9, xmm9, 0x00
00007957b0dd693c  movaps xmm7, xmm13
00007957b0dd6940  vfmadd231pd xmm7, xmm1, xmm9
00007957b0dd6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007957b0dd694a  vptest xmm6, xmm6
00007957b0dd694f  jnz 0x00007957B0DD81E5
00007957b0dd6955  vmovaps xmm1, [rsp+0x20]
00007957b0dd695b  vmovaps xmm13, [rsp+0x20]
00007957b0dd6961  por xmm1, xmm13
00007957b0dd6966  movaps [r15+0x160], xmm1
00007957b0dd696e  lea r14, [rax+0x40]
00007957b0dd6972  movups xmm13, [r13+r14*1]
00007957b0dd6978  lea r14, [rax+0x50]
00007957b0dd697c  movups xmm9, [r13+r14*1]
00007957b0dd6982  movaps [r15+0x1B0], xmm13
00007957b0dd698a  movaps [r15+0x1A0], xmm9
00007957b0dd6992  movaps xmm6, [r15+0x190]
00007957b0dd699a  vmovaps xmm3, [rsp+0xB0]
00007957b0dd69a3  vpermilpd xmm3, xmm3, 0x00
00007957b0dd69a9  vmovaps [rsp+0x20], xmm1
00007957b0dd69af  movaps xmm2, xmm12
00007957b0dd69b3  vfmadd231pd xmm2, xmm6, xmm3
00007957b0dd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007957b0dd69bd  vptest xmm1, xmm1
00007957b0dd69c2  jnz 0x00007957B0DD8350
00007957b0dd69c8  vmovaps xmm1, [rsp+0xB0]
00007957b0dd69d1  vpermilpd xmm1, xmm1, 0x00
00007957b0dd69d7  vmovaps xmm12, [rsp+0x20]
00007957b0dd69dd  movaps xmm6, xmm10
00007957b0dd69e1  vfmadd231pd xmm6, xmm12, xmm1
00007957b0dd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007957b0dd69eb  vptest xmm3, xmm3
00007957b0dd69f0  jnz 0x00007957B0DD84A6
00007957b0dd69f6  vmovaps xmm1, [rsp+0xB0]
00007957b0dd69ff  vpermilpd xmm1, xmm1, 0x00
00007957b0dd6a05  vmovaps xmm12, [rsp+0x40]
00007957b0dd6a0b  movaps xmm10, xmm5
00007957b0dd6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007957b0dd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007957b0dd6a1a  vptest xmm3, xmm3
00007957b0dd6a1f  jnz 0x00007957B0DD85FD
00007957b0dd6a25  vmovaps xmm1, [rsp+0xB0]
00007957b0dd6a2e  vpermilpd xmm1, xmm1, 0x00
00007957b0dd6a34  movaps xmm12, xmm7
00007957b0dd6a38  vfmadd231pd xmm12, xmm15, xmm1
00007957b0dd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007957b0dd6a43  vptest xmm5, xmm5
00007957b0dd6a48  jnz 0x00007957B0DD8755
00007957b0dd6a4e  lea r14, [rax+0x60]
00007957b0dd6a52  movups xmm1, [r13+r14*1]
00007957b0dd6a58  lea r14, [rax+0x70]
00007957b0dd6a5c  movups xmm15, [r13+r14*1]
00007957b0dd6a62  movaps [r15+0x150], xmm1
00007957b0dd6a6a  movaps [r15+0x120], xmm15
00007957b0dd6a72  vmovaps [rsp+0x20], xmm11
00007957b0dd6a78  vpermilpd xmm11, xmm11, 0x00
00007957b0dd6a7e  movaps xmm7, xmm2
00007957b0dd6a81  vfmadd231pd xmm7, xmm9, xmm11
00007957b0dd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007957b0dd6a8b  vptest xmm5, xmm5
00007957b0dd6a90  jnz 0x00007957B0DD88C1
00007957b0dd6a96  vmovaps xmm11, [rsp+0x20]
00007957b0dd6a9c  vpermilpd xmm11, xmm11, 0x00
00007957b0dd6aa2  movaps xmm9, xmm6
00007957b0dd6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007957b0dd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007957b0dd6ab1  vptest xmm5, xmm5
00007957b0dd6ab6  jnz 0x00007957B0DD8A18
00007957b0dd6abc  vmovaps xmm1, [rsp+0x20]
00007957b0dd6ac2  vpermilpd xmm1, xmm1, 0x00
00007957b0dd6ac8  movaps xmm11, xmm10
00007957b0dd6acc  vfmadd231pd xmm11, xmm8, xmm1
00007957b0dd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007957b0dd6ad7  vptest xmm6, xmm6
00007957b0dd6adc  jnz 0x00007957B0DD8B70
00007957b0dd6ae2  vmovaps xmm1, [rsp+0x20]
00007957b0dd6ae8  vpermilpd xmm1, xmm1, 0x00
00007957b0dd6aee  movaps xmm10, xmm12
00007957b0dd6af2  vfmadd231pd xmm10, xmm13, xmm1
00007957b0dd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007957b0dd6afd  vptest xmm8, xmm8
00007957b0dd6b02  jnz 0x00007957B0DD8CC9
00007957b0dd6b08  lea r14, [rax+0x20]
00007957b0dd6b0c  movups xmm1, [r13+r14*1]
00007957b0dd6b12  lea r14, [rax+0x30]
00007957b0dd6b16  movups xmm13, [r13+r14*1]
00007957b0dd6b1c  vmovaps xmm12, [rsp+0x90]
00007957b0dd6b25  vpermilpd xmm12, xmm12, 0x00
00007957b0dd6b2b  movaps xmm8, xmm7
00007957b0dd6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007957b0dd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007957b0dd6b3a  vptest xmm6, xmm6
00007957b0dd6b3f  jnz 0x00007957B0DD8E36
00007957b0dd6b45  vmovaps xmm12, [rsp+0x90]
00007957b0dd6b4e  vpermilpd xmm12, xmm12, 0x00
00007957b0dd6b54  movaps xmm7, xmm9
00007957b0dd6b58  vfmadd231pd xmm7, xmm14, xmm12
00007957b0dd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007957b0dd6b62  vptest xmm6, xmm6
00007957b0dd6b67  jnz 0x00007957B0DD8F8E
00007957b0dd6b6d  vmovaps xmm14, [rsp+0x90]
00007957b0dd6b76  vpermilpd xmm14, xmm14, 0x00
00007957b0dd6b7c  movaps xmm12, xmm11
00007957b0dd6b80  vfmadd231pd xmm12, xmm15, xmm14
00007957b0dd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007957b0dd6b8b  vptest xmm9, xmm9
00007957b0dd6b90  jnz 0x00007957B0DD90E6
00007957b0dd6b96  vmovaps xmm15, [rsp+0x90]
00007957b0dd6b9f  vpermilpd xmm15, xmm15, 0x00
00007957b0dd6ba5  movaps xmm11, xmm10
00007957b0dd6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007957b0dd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007957b0dd6bb4  vptest xmm14, xmm14
00007957b0dd6bb9  jnz 0x00007957B0DD9240
00007957b0dd6bbf  lea r14, [rax+0x90]
00007957b0dd6bc6  movups xmm15, [r13+r14*1]
00007957b0dd6bcc  lea r14, [rax+0xA0]
00007957b0dd6bd3  movups xmm14, [r13+r14*1]
00007957b0dd6bd9  movaps [r15+0x140], xmm15
00007957b0dd6be1  movaps [r15+0x130], xmm14
00007957b0dd6be9  vmovaps xmm13, [rsp+0x10]
00007957b0dd6bef  vpermilpd xmm13, xmm13, 0x00
00007957b0dd6bf5  movaps xmm10, xmm8
00007957b0dd6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007957b0dd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007957b0dd6c04  vptest xmm9, xmm9
00007957b0dd6c09  jnz 0x00007957B0DD93AE
00007957b0dd6c0f  movaps [r15+0x220], xmm10
00007957b0dd6c17  lea r14, [rax+0x10]
00007957b0dd6c1b  movups xmm1, [r13+r14*1]
00007957b0dd6c21  movaps [r15+0x240], xmm1
00007957b0dd6c29  vmovaps xmm13, [rsp+0x10]
00007957b0dd6c2f  vpermilpd xmm13, xmm13, 0x00
00007957b0dd6c35  movaps xmm9, xmm7
00007957b0dd6c39  vfmadd231pd xmm9, xmm14, xmm13
00007957b0dd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007957b0dd6c44  vptest xmm8, xmm8
00007957b0dd6c49  jnz 0x00007957B0DD9511
00007957b0dd6c4f  movaps [r15+0x110], xmm9
00007957b0dd6c57  vmovaps xmm14, [rsp+0x10]
00007957b0dd6c5d  vpermilpd xmm14, xmm14, 0x00
00007957b0dd6c63  movaps xmm13, xmm12
00007957b0dd6c67  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007957b0dd6c72  vptest xmm8, xmm8
00007957b0dd6c77  jnz 0x00007957B0DD966A
00007957b0dd6c7d  movaps [r15+0x170], xmm13
00007957b0dd6c85  vmovaps xmm15, [rsp+0x10]
00007957b0dd6c8b  vpermilpd xmm15, xmm15, 0x00
00007957b0dd6c91  movaps xmm14, xmm11
00007957b0dd6c95  vfmadd231pd xmm14, xmm1, xmm15
00007957b0dd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007957b0dd6ca0  vptest xmm12, xmm12
00007957b0dd6ca5  jnz 0x00007957B0DD97C4
00007957b0dd6cab  movaps [r15+0x230], xmm14
00007957b0dd6cb3  movups [r13+r11*1], xmm9
00007957b0dd6cb9  lea rax, [r11+0x10]
00007957b0dd6cbd  movups [r13+rax*1], xmm13
00007957b0dd6cc3  lea rax, [r11+0x20]
00007957b0dd6cc7  movups [r13+rax*1], xmm10
00007957b0dd6ccd  lea rax, [r11+0x30]
00007957b0dd6cd1  movups [r13+rax*1], xmm14
00007957b0dd6cd7  mov eax, [r15+0x108]
00007957b0dd6cde  sahf
00007957b0dd6cdf  jnz 0x00007957B0DD6D11
00007957b0dd6ce1  cmp dword ptr [r15+0x318], 0x00
00007957b0dd6ce9  jz 0x00007957B0DD9950
00007957b0dd6cef  nop [rax+rax*1], ax
00007957b0dd6cf8  nop [rax+rax*1], eax
00007957b0dd6d00  mov eax, 0x410664
00007957b0dd6d05  mov [r15+0x100], rax
00007957b0dd6d0c  jmp 0x00007957B0BFE110
00007957b0dd6d11  cmp dword ptr [r15+0x318], 0x00
00007957b0dd6d19  jz 0x00007957B0DD6050
00007957b0dd6d1f  nop [rax+rax*1], ax
00007957b0dd6d28  nop [rax+rax*1], eax
00007957b0dd6d30  mov eax, 0x4104F0
00007957b0dd6d35  mov [r15+0x100], rax
00007957b0dd6d3c  jmp 0x00007957B0BFE110
00007957b0dd6d41  int3
00007957b0dd6d42  call 0x00007957B0C0A4B0
00007957b0dd6d47  jmp 0x00007957B0DD6079
00007957b0dd6d4c  call 0x00007957B0C09240
00007957b0dd6d51  jmp 0x00007957B0DD6083
00007957b0dd6d56  call 0x00007957B0C0A4B0
00007957b0dd6d5b  jmp 0x00007957B0DD60CD
00007957b0dd6d60  call 0x00007957B0C09240
00007957b0dd6d65  jmp 0x00007957B0DD60D7
00007957b0dd6d6a  call 0x00007957B0C0A4B0
00007957b0dd6d6f  jmp 0x00007957B0DD6158
00007957b0dd6d74  call 0x00007957B0C09240
00007957b0dd6d79  jmp 0x00007957B0DD6162
00007957b0dd6d7e  call 0x00007957B0CB47C0
00007957b0dd6d83  jmp 0x00007957B0DD6243
00007957b0dd6d88  call 0x00007957B0BFF430
00007957b0dd6d8d  jmp 0x00007957B0DD6272
00007957b0dd6d92  call 0x00007957B0CB0CE0
00007957b0dd6d97  jmp 0x00007957B0DD628E
00007957b0dd6d9c  sub rsp, 0x08
00007957b0dd6da0  push rax
00007957b0dd6da1  push rcx
00007957b0dd6da2  push rdx
00007957b0dd6da3  push rdi
00007957b0dd6da4  push rsi
00007957b0dd6da5  push r8
00007957b0dd6da7  push r9
00007957b0dd6da9  push r10
00007957b0dd6dab  push r11
00007957b0dd6dad  sub rsp, 0xF0
00007957b0dd6db4  vmovaps [rsp], xmm0
00007957b0dd6db9  vmovaps [rsp+0x10], xmm1
00007957b0dd6dbf  vmovaps [rsp+0x20], xmm2
00007957b0dd6dc5  vmovaps [rsp+0x30], xmm3
00007957b0dd6dcb  vmovaps [rsp+0x40], xmm4
00007957b0dd6dd1  vmovaps [rsp+0x50], xmm5
00007957b0dd6dd7  vmovaps [rsp+0x60], xmm6
00007957b0dd6ddd  vmovaps [rsp+0x70], xmm7
00007957b0dd6de3  vmovaps [rsp+0x80], xmm8
00007957b0dd6dec  vmovaps [rsp+0x90], xmm9
00007957b0dd6df5  vmovaps [rsp+0xA0], xmm10
00007957b0dd6dfe  vmovaps [rsp+0xB0], xmm11
00007957b0dd6e07  vmovaps [rsp+0xC0], xmm12
00007957b0dd6e10  vmovaps [rsp+0xD0], xmm14
00007957b0dd6e19  vmovaps [rsp+0xE0], xmm15
00007957b0dd6e22  sub rsp, 0x40
00007957b0dd6e26  lea rdi, [rsp]
00007957b0dd6e2a  lea rsi, [rsp+0x10]
00007957b0dd6e2f  lea rdx, [rsp+0x20]
00007957b0dd6e34  lea rcx, [rsp+0x30]
00007957b0dd6e39  mov r8d, 0x00
00007957b0dd6e3f  lea r9, [r15+0x3A8]
00007957b0dd6e46  movaps [rdi], xmm13
00007957b0dd6e4a  movaps [rsi], xmm1
00007957b0dd6e4d  movaps [rdx], xmm15
00007957b0dd6e51  movaps [rcx], xmm14
00007957b0dd6e55  mov rax, 0x56E396DF1A50
00007957b0dd6e5f  call rax
00007957b0dd6e61  movaps xmm13, [rsp]
00007957b0dd6e66  add rsp, 0x40
00007957b0dd6e6a  vmovaps xmm0, [rsp]
00007957b0dd6e6f  vmovaps xmm1, [rsp+0x10]
00007957b0dd6e75  vmovaps xmm2, [rsp+0x20]
00007957b0dd6e7b  vmovaps xmm3, [rsp+0x30]
00007957b0dd6e81  vmovaps xmm4, [rsp+0x40]
00007957b0dd6e87  vmovaps xmm5, [rsp+0x50]
00007957b0dd6e8d  vmovaps xmm6, [rsp+0x60]
00007957b0dd6e93  vmovaps xmm7, [rsp+0x70]
00007957b0dd6e99  vmovaps xmm8, [rsp+0x80]
00007957b0dd6ea2  vmovaps xmm9, [rsp+0x90]
00007957b0dd6eab  vmovaps xmm10, [rsp+0xA0]
00007957b0dd6eb4  vmovaps xmm11, [rsp+0xB0]
00007957b0dd6ebd  vmovaps xmm12, [rsp+0xC0]
00007957b0dd6ec6  vmovaps xmm14, [rsp+0xD0]
00007957b0dd6ecf  vmovaps xmm15, [rsp+0xE0]
00007957b0dd6ed8  add rsp, 0xF0
00007957b0dd6edf  pop r11
00007957b0dd6ee1  pop r10
00007957b0dd6ee3  pop r9
00007957b0dd6ee5  pop r8
00007957b0dd6ee7  pop rsi
00007957b0dd6ee8  pop rdi
00007957b0dd6ee9  pop rdx
00007957b0dd6eea  pop rcx
00007957b0dd6eeb  pop rax
00007957b0dd6eec  add rsp, 0x08
00007957b0dd6ef0  jmp 0x00007957B0DD6305
00007957b0dd6ef5  sub rsp, 0x08
00007957b0dd6ef9  push rax
00007957b0dd6efa  push rcx
00007957b0dd6efb  push rdx
00007957b0dd6efc  push rdi
00007957b0dd6efd  push rsi
00007957b0dd6efe  push r8
00007957b0dd6f00  push r9
00007957b0dd6f02  push r10
00007957b0dd6f04  push r11
00007957b0dd6f06  sub rsp, 0xF0
00007957b0dd6f0d  vmovaps [rsp], xmm0
00007957b0dd6f12  vmovaps [rsp+0x10], xmm1
00007957b0dd6f18  vmovaps [rsp+0x20], xmm2
00007957b0dd6f1e  vmovaps [rsp+0x30], xmm3
00007957b0dd6f24  vmovaps [rsp+0x40], xmm4
00007957b0dd6f2a  vmovaps [rsp+0x50], xmm5
00007957b0dd6f30  vmovaps [rsp+0x60], xmm6
00007957b0dd6f36  vmovaps [rsp+0x70], xmm7
00007957b0dd6f3c  vmovaps [rsp+0x80], xmm8
00007957b0dd6f45  vmovaps [rsp+0x90], xmm9
00007957b0dd6f4e  vmovaps [rsp+0xA0], xmm10
00007957b0dd6f57  vmovaps [rsp+0xB0], xmm11
00007957b0dd6f60  vmovaps [rsp+0xC0], xmm13
00007957b0dd6f69  vmovaps [rsp+0xD0], xmm14
00007957b0dd6f72  vmovaps [rsp+0xE0], xmm15
00007957b0dd6f7b  sub rsp, 0x40
00007957b0dd6f7f  lea rdi, [rsp]
00007957b0dd6f83  lea rsi, [rsp+0x10]
00007957b0dd6f88  lea rdx, [rsp+0x20]
00007957b0dd6f8d  lea rcx, [rsp+0x30]
00007957b0dd6f92  mov r8d, 0x00
00007957b0dd6f98  lea r9, [r15+0x3A8]
00007957b0dd6f9f  movaps [rdi], xmm12
00007957b0dd6fa3  movaps [rsi], xmm15
00007957b0dd6fa7  movaps [rdx], xmm1
00007957b0dd6faa  movaps [rcx], xmm14
00007957b0dd6fae  mov rax, 0x56E396DF1A50
00007957b0dd6fb8  call rax
00007957b0dd6fba  movaps xmm12, [rsp]
00007957b0dd6fbf  add rsp, 0x40
00007957b0dd6fc3  vmovaps xmm0, [rsp]
00007957b0dd6fc8  vmovaps xmm1, [rsp+0x10]
00007957b0dd6fce  vmovaps xmm2, [rsp+0x20]
00007957b0dd6fd4  vmovaps xmm3, [rsp+0x30]
00007957b0dd6fda  vmovaps xmm4, [rsp+0x40]
00007957b0dd6fe0  vmovaps xmm5, [rsp+0x50]
00007957b0dd6fe6  vmovaps xmm6, [rsp+0x60]
00007957b0dd6fec  vmovaps xmm7, [rsp+0x70]
00007957b0dd6ff2  vmovaps xmm8, [rsp+0x80]
00007957b0dd6ffb  vmovaps xmm9, [rsp+0x90]
00007957b0dd7004  vmovaps xmm10, [rsp+0xA0]
00007957b0dd700d  vmovaps xmm11, [rsp+0xB0]
00007957b0dd7016  vmovaps xmm13, [rsp+0xC0]
00007957b0dd701f  vmovaps xmm14, [rsp+0xD0]
00007957b0dd7028  vmovaps xmm15, [rsp+0xE0]
00007957b0dd7031  add rsp, 0xF0
00007957b0dd7038  pop r11
00007957b0dd703a  pop r10
00007957b0dd703c  pop r9
00007957b0dd703e  pop r8
00007957b0dd7040  pop rsi
00007957b0dd7041  pop rdi
00007957b0dd7042  pop rdx
00007957b0dd7043  pop rcx
00007957b0dd7044  pop rax
00007957b0dd7045  add rsp, 0x08
00007957b0dd7049  jmp 0x00007957B0DD6333
00007957b0dd704e  call 0x00007957B0CD64F0
00007957b0dd7053  jmp 0x00007957B0DD641F
00007957b0dd7058  sub rsp, 0x08
00007957b0dd705c  push rax
00007957b0dd705d  push rcx
00007957b0dd705e  push rdx
00007957b0dd705f  push rdi
00007957b0dd7060  push rsi
00007957b0dd7061  push r8
00007957b0dd7063  push r9
00007957b0dd7065  push r10
00007957b0dd7067  push r11
00007957b0dd7069  sub rsp, 0xF0
00007957b0dd7070  vmovaps [rsp], xmm0
00007957b0dd7075  vmovaps [rsp+0x10], xmm1
00007957b0dd707b  vmovaps [rsp+0x20], xmm2
00007957b0dd7081  vmovaps [rsp+0x30], xmm3
00007957b0dd7087  vmovaps [rsp+0x40], xmm4
00007957b0dd708d  vmovaps [rsp+0x50], xmm5
00007957b0dd7093  vmovaps [rsp+0x60], xmm6
00007957b0dd7099  vmovaps [rsp+0x70], xmm7
00007957b0dd709f  vmovaps [rsp+0x80], xmm8
00007957b0dd70a8  vmovaps [rsp+0x90], xmm9
00007957b0dd70b1  vmovaps [rsp+0xA0], xmm10
00007957b0dd70ba  vmovaps [rsp+0xB0], xmm11
00007957b0dd70c3  vmovaps [rsp+0xC0], xmm12
00007957b0dd70cc  vmovaps [rsp+0xD0], xmm14
00007957b0dd70d5  vmovaps [rsp+0xE0], xmm15
00007957b0dd70de  sub rsp, 0x40
00007957b0dd70e2  lea rdi, [rsp]
00007957b0dd70e6  lea rsi, [rsp+0x10]
00007957b0dd70eb  lea rdx, [rsp+0x20]
00007957b0dd70f0  lea rcx, [rsp+0x30]
00007957b0dd70f5  mov r8d, 0x00
00007957b0dd70fb  lea r9, [r15+0x3A8]
00007957b0dd7102  movaps [rdi], xmm13
00007957b0dd7106  movaps [rsi], xmm1
00007957b0dd7109  movaps [rdx], xmm15
00007957b0dd710d  movaps [rcx], xmm14
00007957b0dd7111  mov rax, 0x56E396DF1A50
00007957b0dd711b  call rax
00007957b0dd711d  movaps xmm13, [rsp]
00007957b0dd7122  add rsp, 0x40
00007957b0dd7126  vmovaps xmm0, [rsp]
00007957b0dd712b  vmovaps xmm1, [rsp+0x10]
00007957b0dd7131  vmovaps xmm2, [rsp+0x20]
00007957b0dd7137  vmovaps xmm3, [rsp+0x30]
00007957b0dd713d  vmovaps xmm4, [rsp+0x40]
00007957b0dd7143  vmovaps xmm5, [rsp+0x50]
00007957b0dd7149  vmovaps xmm6, [rsp+0x60]
00007957b0dd714f  vmovaps xmm7, [rsp+0x70]
00007957b0dd7155  vmovaps xmm8, [rsp+0x80]
00007957b0dd715e  vmovaps xmm9, [rsp+0x90]
00007957b0dd7167  vmovaps xmm10, [rsp+0xA0]
00007957b0dd7170  vmovaps xmm11, [rsp+0xB0]
00007957b0dd7179  vmovaps xmm12, [rsp+0xC0]
00007957b0dd7182  vmovaps xmm14, [rsp+0xD0]
00007957b0dd718b  vmovaps xmm15, [rsp+0xE0]
00007957b0dd7194  add rsp, 0xF0
00007957b0dd719b  pop r11
00007957b0dd719d  pop r10
00007957b0dd719f  pop r9
00007957b0dd71a1  pop r8
00007957b0dd71a3  pop rsi
00007957b0dd71a4  pop rdi
00007957b0dd71a5  pop rdx
00007957b0dd71a6  pop rcx
00007957b0dd71a7  pop rax
00007957b0dd71a8  add rsp, 0x08
00007957b0dd71ac  jmp 0x00007957B0DD648E
00007957b0dd71b1  call 0x00007957B0CD64F0
00007957b0dd71b6  jmp 0x00007957B0DD64A3
00007957b0dd71bb  sub rsp, 0x08
00007957b0dd71bf  push rax
00007957b0dd71c0  push rcx
00007957b0dd71c1  push rdx
00007957b0dd71c2  push rdi
00007957b0dd71c3  push rsi
00007957b0dd71c4  push r8
00007957b0dd71c6  push r9
00007957b0dd71c8  push r10
00007957b0dd71ca  push r11
00007957b0dd71cc  sub rsp, 0xF0
00007957b0dd71d3  vmovaps [rsp], xmm0
00007957b0dd71d8  vmovaps [rsp+0x10], xmm1
00007957b0dd71de  vmovaps [rsp+0x20], xmm2
00007957b0dd71e4  vmovaps [rsp+0x30], xmm3
00007957b0dd71ea  vmovaps [rsp+0x40], xmm4
00007957b0dd71f0  vmovaps [rsp+0x50], xmm5
00007957b0dd71f6  vmovaps [rsp+0x60], xmm6
00007957b0dd71fc  vmovaps [rsp+0x70], xmm7
00007957b0dd7202  vmovaps [rsp+0x80], xmm8
00007957b0dd720b  vmovaps [rsp+0x90], xmm9
00007957b0dd7214  vmovaps [rsp+0xA0], xmm10
00007957b0dd721d  vmovaps [rsp+0xB0], xmm11
00007957b0dd7226  vmovaps [rsp+0xC0], xmm13
00007957b0dd722f  vmovaps [rsp+0xD0], xmm14
00007957b0dd7238  vmovaps [rsp+0xE0], xmm15
00007957b0dd7241  sub rsp, 0x40
00007957b0dd7245  lea rdi, [rsp]
00007957b0dd7249  lea rsi, [rsp+0x10]
00007957b0dd724e  lea rdx, [rsp+0x20]
00007957b0dd7253  lea rcx, [rsp+0x30]
00007957b0dd7258  mov r8d, 0x00
00007957b0dd725e  lea r9, [r15+0x3A8]
00007957b0dd7265  movaps [rdi], xmm12
00007957b0dd7269  movaps [rsi], xmm15
00007957b0dd726d  movaps [rdx], xmm1
00007957b0dd7270  movaps [rcx], xmm14
00007957b0dd7274  mov rax, 0x56E396DF1A50
00007957b0dd727e  call rax
00007957b0dd7280  movaps xmm12, [rsp]
00007957b0dd7285  add rsp, 0x40
00007957b0dd7289  vmovaps xmm0, [rsp]
00007957b0dd728e  vmovaps xmm1, [rsp+0x10]
00007957b0dd7294  vmovaps xmm2, [rsp+0x20]
00007957b0dd729a  vmovaps xmm3, [rsp+0x30]
00007957b0dd72a0  vmovaps xmm4, [rsp+0x40]
00007957b0dd72a6  vmovaps xmm5, [rsp+0x50]
00007957b0dd72ac  vmovaps xmm6, [rsp+0x60]
00007957b0dd72b2  vmovaps xmm7, [rsp+0x70]
00007957b0dd72b8  vmovaps xmm8, [rsp+0x80]
00007957b0dd72c1  vmovaps xmm9, [rsp+0x90]
00007957b0dd72ca  vmovaps xmm10, [rsp+0xA0]
00007957b0dd72d3  vmovaps xmm11, [rsp+0xB0]
00007957b0dd72dc  vmovaps xmm13, [rsp+0xC0]
00007957b0dd72e5  vmovaps xmm14, [rsp+0xD0]
00007957b0dd72ee  vmovaps xmm15, [rsp+0xE0]
00007957b0dd72f7  add rsp, 0xF0
00007957b0dd72fe  pop r11
00007957b0dd7300  pop r10
00007957b0dd7302  pop r9
00007957b0dd7304  pop r8
00007957b0dd7306  pop rsi
00007957b0dd7307  pop rdi
00007957b0dd7308  pop rdx
00007957b0dd7309  pop rcx
00007957b0dd730a  pop rax
00007957b0dd730b  add rsp, 0x08
00007957b0dd730f  jmp 0x00007957B0DD64CF
00007957b0dd7314  sub rsp, 0x08
00007957b0dd7318  push rax
00007957b0dd7319  push rcx
00007957b0dd731a  push rdx
00007957b0dd731b  push rdi
00007957b0dd731c  push rsi
00007957b0dd731d  push r8
00007957b0dd731f  push r9
00007957b0dd7321  push r10
00007957b0dd7323  push r11
00007957b0dd7325  sub rsp, 0xF0
00007957b0dd732c  vmovaps [rsp], xmm0
00007957b0dd7331  vmovaps [rsp+0x10], xmm1
00007957b0dd7337  vmovaps [rsp+0x20], xmm2
00007957b0dd733d  vmovaps [rsp+0x30], xmm3
00007957b0dd7343  vmovaps [rsp+0x40], xmm4
00007957b0dd7349  vmovaps [rsp+0x50], xmm5
00007957b0dd734f  vmovaps [rsp+0x60], xmm6
00007957b0dd7355  vmovaps [rsp+0x70], xmm7
00007957b0dd735b  vmovaps [rsp+0x80], xmm8
00007957b0dd7364  vmovaps [rsp+0x90], xmm9
00007957b0dd736d  vmovaps [rsp+0xA0], xmm10
00007957b0dd7376  vmovaps [rsp+0xB0], xmm11
00007957b0dd737f  vmovaps [rsp+0xC0], xmm12
00007957b0dd7388  vmovaps [rsp+0xD0], xmm14
00007957b0dd7391  vmovaps [rsp+0xE0], xmm15
00007957b0dd739a  sub rsp, 0x40
00007957b0dd739e  lea rdi, [rsp]
00007957b0dd73a2  lea rsi, [rsp+0x10]
00007957b0dd73a7  lea rdx, [rsp+0x20]
00007957b0dd73ac  lea rcx, [rsp+0x30]
00007957b0dd73b1  mov r8d, 0x00
00007957b0dd73b7  lea r9, [r15+0x3A8]
00007957b0dd73be  movaps [rdi], xmm13
00007957b0dd73c2  movaps [rsi], xmm1
00007957b0dd73c5  movaps [rdx], xmm15
00007957b0dd73c9  movaps [rcx], xmm14
00007957b0dd73cd  mov rax, 0x56E396DF1A50
00007957b0dd73d7  call rax
00007957b0dd73d9  movaps xmm13, [rsp]
00007957b0dd73de  add rsp, 0x40
00007957b0dd73e2  vmovaps xmm0, [rsp]
00007957b0dd73e7  vmovaps xmm1, [rsp+0x10]
00007957b0dd73ed  vmovaps xmm2, [rsp+0x20]
00007957b0dd73f3  vmovaps xmm3, [rsp+0x30]
00007957b0dd73f9  vmovaps xmm4, [rsp+0x40]
00007957b0dd73ff  vmovaps xmm5, [rsp+0x50]
00007957b0dd7405  vmovaps xmm6, [rsp+0x60]
00007957b0dd740b  vmovaps xmm7, [rsp+0x70]
00007957b0dd7411  vmovaps xmm8, [rsp+0x80]
00007957b0dd741a  vmovaps xmm9, [rsp+0x90]
00007957b0dd7423  vmovaps xmm10, [rsp+0xA0]
00007957b0dd742c  vmovaps xmm11, [rsp+0xB0]
00007957b0dd7435  vmovaps xmm12, [rsp+0xC0]
00007957b0dd743e  vmovaps xmm14, [rsp+0xD0]
00007957b0dd7447  vmovaps xmm15, [rsp+0xE0]
00007957b0dd7450  add rsp, 0xF0
00007957b0dd7457  pop r11
00007957b0dd7459  pop r10
00007957b0dd745b  pop r9
00007957b0dd745d  pop r8
00007957b0dd745f  pop rsi
00007957b0dd7460  pop rdi
00007957b0dd7461  pop rdx
00007957b0dd7462  pop rcx
00007957b0dd7463  pop rax
00007957b0dd7464  add rsp, 0x08
00007957b0dd7468  jmp 0x00007957B0DD665F
00007957b0dd746d  sub rsp, 0x08
00007957b0dd7471  push rax
00007957b0dd7472  push rcx
00007957b0dd7473  push rdx
00007957b0dd7474  push rdi
00007957b0dd7475  push rsi
00007957b0dd7476  push r8
00007957b0dd7478  push r9
00007957b0dd747a  push r10
00007957b0dd747c  push r11
00007957b0dd747e  sub rsp, 0xF0
00007957b0dd7485  vmovaps [rsp], xmm0
00007957b0dd748a  vmovaps [rsp+0x10], xmm1
00007957b0dd7490  vmovaps [rsp+0x20], xmm2
00007957b0dd7496  vmovaps [rsp+0x30], xmm3
00007957b0dd749c  vmovaps [rsp+0x40], xmm4
00007957b0dd74a2  vmovaps [rsp+0x50], xmm5
00007957b0dd74a8  vmovaps [rsp+0x60], xmm6
00007957b0dd74ae  vmovaps [rsp+0x70], xmm7
00007957b0dd74b4  vmovaps [rsp+0x80], xmm8
00007957b0dd74bd  vmovaps [rsp+0x90], xmm9
00007957b0dd74c6  vmovaps [rsp+0xA0], xmm10
00007957b0dd74cf  vmovaps [rsp+0xB0], xmm11
00007957b0dd74d8  vmovaps [rsp+0xC0], xmm12
00007957b0dd74e1  vmovaps [rsp+0xD0], xmm13
00007957b0dd74ea  vmovaps [rsp+0xE0], xmm15
00007957b0dd74f3  sub rsp, 0x40
00007957b0dd74f7  lea rdi, [rsp]
00007957b0dd74fb  lea rsi, [rsp+0x10]
00007957b0dd7500  lea rdx, [rsp+0x20]
00007957b0dd7505  lea rcx, [rsp+0x30]
00007957b0dd750a  mov r8d, 0x00
00007957b0dd7510  lea r9, [r15+0x3A8]
00007957b0dd7517  movaps [rdi], xmm14
00007957b0dd751b  movaps [rsi], xmm15
00007957b0dd751f  movaps [rdx], xmm2
00007957b0dd7522  movaps [rcx], xmm1
00007957b0dd7525  mov rax, 0x56E396DF1A50
00007957b0dd752f  call rax
00007957b0dd7531  movaps xmm14, [rsp]
00007957b0dd7536  add rsp, 0x40
00007957b0dd753a  vmovaps xmm0, [rsp]
00007957b0dd753f  vmovaps xmm1, [rsp+0x10]
00007957b0dd7545  vmovaps xmm2, [rsp+0x20]
00007957b0dd754b  vmovaps xmm3, [rsp+0x30]
00007957b0dd7551  vmovaps xmm4, [rsp+0x40]
00007957b0dd7557  vmovaps xmm5, [rsp+0x50]
00007957b0dd755d  vmovaps xmm6, [rsp+0x60]
00007957b0dd7563  vmovaps xmm7, [rsp+0x70]
00007957b0dd7569  vmovaps xmm8, [rsp+0x80]
00007957b0dd7572  vmovaps xmm9, [rsp+0x90]
00007957b0dd757b  vmovaps xmm10, [rsp+0xA0]
00007957b0dd7584  vmovaps xmm11, [rsp+0xB0]
00007957b0dd758d  vmovaps xmm12, [rsp+0xC0]
00007957b0dd7596  vmovaps xmm13, [rsp+0xD0]
00007957b0dd759f  vmovaps xmm15, [rsp+0xE0]
00007957b0dd75a8  add rsp, 0xF0
00007957b0dd75af  pop r11
00007957b0dd75b1  pop r10
00007957b0dd75b3  pop r9
00007957b0dd75b5  pop r8
00007957b0dd75b7  pop rsi
00007957b0dd75b8  pop rdi
00007957b0dd75b9  pop rdx
00007957b0dd75ba  pop rcx
00007957b0dd75bb  pop rax
00007957b0dd75bc  add rsp, 0x08
00007957b0dd75c0  jmp 0x00007957B0DD6691
00007957b0dd75c5  sub rsp, 0x08
00007957b0dd75c9  push rax
00007957b0dd75ca  push rcx
00007957b0dd75cb  push rdx
00007957b0dd75cc  push rdi
00007957b0dd75cd  push rsi
00007957b0dd75ce  push r8
00007957b0dd75d0  push r9
00007957b0dd75d2  push r10
00007957b0dd75d4  push r11
00007957b0dd75d6  sub rsp, 0xF0
00007957b0dd75dd  vmovaps [rsp], xmm0
00007957b0dd75e2  vmovaps [rsp+0x10], xmm1
00007957b0dd75e8  vmovaps [rsp+0x20], xmm3
00007957b0dd75ee  vmovaps [rsp+0x30], xmm4
00007957b0dd75f4  vmovaps [rsp+0x40], xmm5
00007957b0dd75fa  vmovaps [rsp+0x50], xmm6
00007957b0dd7600  vmovaps [rsp+0x60], xmm7
00007957b0dd7606  vmovaps [rsp+0x70], xmm8
00007957b0dd760c  vmovaps [rsp+0x80], xmm9
00007957b0dd7615  vmovaps [rsp+0x90], xmm10
00007957b0dd761e  vmovaps [rsp+0xA0], xmm11
00007957b0dd7627  vmovaps [rsp+0xB0], xmm12
00007957b0dd7630  vmovaps [rsp+0xC0], xmm13
00007957b0dd7639  vmovaps [rsp+0xD0], xmm14
00007957b0dd7642  vmovaps [rsp+0xE0], xmm15
00007957b0dd764b  sub rsp, 0x40
00007957b0dd764f  lea rdi, [rsp]
00007957b0dd7653  lea rsi, [rsp+0x10]
00007957b0dd7658  lea rdx, [rsp+0x20]
00007957b0dd765d  lea rcx, [rsp+0x30]
00007957b0dd7662  mov r8d, 0x00
00007957b0dd7668  lea r9, [r15+0x3A8]
00007957b0dd766f  movaps [rdi], xmm2
00007957b0dd7672  movaps [rsi], xmm15
00007957b0dd7676  movaps [rdx], xmm12
00007957b0dd767a  movaps [rcx], xmm1
00007957b0dd767d  mov rax, 0x56E396DF1A50
00007957b0dd7687  call rax
00007957b0dd7689  movaps xmm2, [rsp]
00007957b0dd768d  add rsp, 0x40
00007957b0dd7691  vmovaps xmm0, [rsp]
00007957b0dd7696  vmovaps xmm1, [rsp+0x10]
00007957b0dd769c  vmovaps xmm3, [rsp+0x20]
00007957b0dd76a2  vmovaps xmm4, [rsp+0x30]
00007957b0dd76a8  vmovaps xmm5, [rsp+0x40]
00007957b0dd76ae  vmovaps xmm6, [rsp+0x50]
00007957b0dd76b4  vmovaps xmm7, [rsp+0x60]
00007957b0dd76ba  vmovaps xmm8, [rsp+0x70]
00007957b0dd76c0  vmovaps xmm9, [rsp+0x80]
00007957b0dd76c9  vmovaps xmm10, [rsp+0x90]
00007957b0dd76d2  vmovaps xmm11, [rsp+0xA0]
00007957b0dd76db  vmovaps xmm12, [rsp+0xB0]
00007957b0dd76e4  vmovaps xmm13, [rsp+0xC0]
00007957b0dd76ed  vmovaps xmm14, [rsp+0xD0]
00007957b0dd76f6  vmovaps xmm15, [rsp+0xE0]
00007957b0dd76ff  add rsp, 0xF0
00007957b0dd7706  pop r11
00007957b0dd7708  pop r10
00007957b0dd770a  pop r9
00007957b0dd770c  pop r8
00007957b0dd770e  pop rsi
00007957b0dd770f  pop rdi
00007957b0dd7710  pop rdx
00007957b0dd7711  pop rcx
00007957b0dd7712  pop rax
00007957b0dd7713  add rsp, 0x08
00007957b0dd7717  jmp 0x00007957B0DD66CE
00007957b0dd771c  sub rsp, 0x08
00007957b0dd7720  push rax
00007957b0dd7721  push rcx
00007957b0dd7722  push rdx
00007957b0dd7723  push rdi
00007957b0dd7724  push rsi
00007957b0dd7725  push r8
00007957b0dd7727  push r9
00007957b0dd7729  push r10
00007957b0dd772b  push r11
00007957b0dd772d  sub rsp, 0xF0
00007957b0dd7734  vmovaps [rsp], xmm0
00007957b0dd7739  vmovaps [rsp+0x10], xmm1
00007957b0dd773f  vmovaps [rsp+0x20], xmm2
00007957b0dd7745  vmovaps [rsp+0x30], xmm3
00007957b0dd774b  vmovaps [rsp+0x40], xmm4
00007957b0dd7751  vmovaps [rsp+0x50], xmm5
00007957b0dd7757  vmovaps [rsp+0x60], xmm6
00007957b0dd775d  vmovaps [rsp+0x70], xmm7
00007957b0dd7763  vmovaps [rsp+0x80], xmm8
00007957b0dd776c  vmovaps [rsp+0x90], xmm9
00007957b0dd7775  vmovaps [rsp+0xA0], xmm10
00007957b0dd777e  vmovaps [rsp+0xB0], xmm11
00007957b0dd7787  vmovaps [rsp+0xC0], xmm13
00007957b0dd7790  vmovaps [rsp+0xD0], xmm14
00007957b0dd7799  vmovaps [rsp+0xE0], xmm15
00007957b0dd77a2  sub rsp, 0x40
00007957b0dd77a6  lea rdi, [rsp]
00007957b0dd77aa  lea rsi, [rsp+0x10]
00007957b0dd77af  lea rdx, [rsp+0x20]
00007957b0dd77b4  lea rcx, [rsp+0x30]
00007957b0dd77b9  mov r8d, 0x00
00007957b0dd77bf  lea r9, [r15+0x3A8]
00007957b0dd77c6  movaps [rdi], xmm12
00007957b0dd77ca  movaps [rsi], xmm14
00007957b0dd77ce  movaps [rdx], xmm3
00007957b0dd77d1  movaps [rcx], xmm15
00007957b0dd77d5  mov rax, 0x56E396DF1A50
00007957b0dd77df  call rax
00007957b0dd77e1  movaps xmm12, [rsp]
00007957b0dd77e6  add rsp, 0x40
00007957b0dd77ea  vmovaps xmm0, [rsp]
00007957b0dd77ef  vmovaps xmm1, [rsp+0x10]
00007957b0dd77f5  vmovaps xmm2, [rsp+0x20]
00007957b0dd77fb  vmovaps xmm3, [rsp+0x30]
00007957b0dd7801  vmovaps xmm4, [rsp+0x40]
00007957b0dd7807  vmovaps xmm5, [rsp+0x50]
00007957b0dd780d  vmovaps xmm6, [rsp+0x60]
00007957b0dd7813  vmovaps xmm7, [rsp+0x70]
00007957b0dd7819  vmovaps xmm8, [rsp+0x80]
00007957b0dd7822  vmovaps xmm9, [rsp+0x90]
00007957b0dd782b  vmovaps xmm10, [rsp+0xA0]
00007957b0dd7834  vmovaps xmm11, [rsp+0xB0]
00007957b0dd783d  vmovaps xmm13, [rsp+0xC0]
00007957b0dd7846  vmovaps xmm14, [rsp+0xD0]
00007957b0dd784f  vmovaps xmm15, [rsp+0xE0]
00007957b0dd7858  add rsp, 0xF0
00007957b0dd785f  pop r11
00007957b0dd7861  pop r10
00007957b0dd7863  pop r9
00007957b0dd7865  pop r8
00007957b0dd7867  pop rsi
00007957b0dd7868  pop rdi
00007957b0dd7869  pop rdx
00007957b0dd786a  pop rcx
00007957b0dd786b  pop rax
00007957b0dd786c  add rsp, 0x08
00007957b0dd7870  jmp 0x00007957B0DD6728
00007957b0dd7875  sub rsp, 0x08
00007957b0dd7879  push rax
00007957b0dd787a  push rcx
00007957b0dd787b  push rdx
00007957b0dd787c  push rdi
00007957b0dd787d  push rsi
00007957b0dd787e  push r8
00007957b0dd7880  push r9
00007957b0dd7882  push r10
00007957b0dd7884  push r11
00007957b0dd7886  sub rsp, 0xF0
00007957b0dd788d  vmovaps [rsp], xmm0
00007957b0dd7892  vmovaps [rsp+0x10], xmm1
00007957b0dd7898  vmovaps [rsp+0x20], xmm2
00007957b0dd789e  vmovaps [rsp+0x30], xmm3
00007957b0dd78a4  vmovaps [rsp+0x40], xmm4
00007957b0dd78aa  vmovaps [rsp+0x50], xmm5
00007957b0dd78b0  vmovaps [rsp+0x60], xmm6
00007957b0dd78b6  vmovaps [rsp+0x70], xmm7
00007957b0dd78bc  vmovaps [rsp+0x80], xmm8
00007957b0dd78c5  vmovaps [rsp+0x90], xmm10
00007957b0dd78ce  vmovaps [rsp+0xA0], xmm11
00007957b0dd78d7  vmovaps [rsp+0xB0], xmm12
00007957b0dd78e0  vmovaps [rsp+0xC0], xmm13
00007957b0dd78e9  vmovaps [rsp+0xD0], xmm14
00007957b0dd78f2  vmovaps [rsp+0xE0], xmm15
00007957b0dd78fb  sub rsp, 0x40
00007957b0dd78ff  lea rdi, [rsp]
00007957b0dd7903  lea rsi, [rsp+0x10]
00007957b0dd7908  lea rdx, [rsp+0x20]
00007957b0dd790d  lea rcx, [rsp+0x30]
00007957b0dd7912  mov r8d, 0x00
00007957b0dd7918  lea r9, [r15+0x3A8]
00007957b0dd791f  movaps [rdi], xmm9
00007957b0dd7923  movaps [rsi], xmm13
00007957b0dd7927  movaps [rdx], xmm14
00007957b0dd792b  movaps [rcx], xmm6
00007957b0dd792e  mov rax, 0x56E396DF1A50
00007957b0dd7938  call rax
00007957b0dd793a  movaps xmm9, [rsp]
00007957b0dd793f  add rsp, 0x40
00007957b0dd7943  vmovaps xmm0, [rsp]
00007957b0dd7948  vmovaps xmm1, [rsp+0x10]
00007957b0dd794e  vmovaps xmm2, [rsp+0x20]
00007957b0dd7954  vmovaps xmm3, [rsp+0x30]
00007957b0dd795a  vmovaps xmm4, [rsp+0x40]
00007957b0dd7960  vmovaps xmm5, [rsp+0x50]
00007957b0dd7966  vmovaps xmm6, [rsp+0x60]
00007957b0dd796c  vmovaps xmm7, [rsp+0x70]
00007957b0dd7972  vmovaps xmm8, [rsp+0x80]
00007957b0dd797b  vmovaps xmm10, [rsp+0x90]
00007957b0dd7984  vmovaps xmm11, [rsp+0xA0]
00007957b0dd798d  vmovaps xmm12, [rsp+0xB0]
00007957b0dd7996  vmovaps xmm13, [rsp+0xC0]
00007957b0dd799f  vmovaps xmm14, [rsp+0xD0]
00007957b0dd79a8  vmovaps xmm15, [rsp+0xE0]
00007957b0dd79b1  add rsp, 0xF0
00007957b0dd79b8  pop r11
00007957b0dd79ba  pop r10
00007957b0dd79bc  pop r9
00007957b0dd79be  pop r8
00007957b0dd79c0  pop rsi
00007957b0dd79c1  pop rdi
00007957b0dd79c2  pop rdx
00007957b0dd79c3  pop rcx
00007957b0dd79c4  pop rax
00007957b0dd79c5  add rsp, 0x08
00007957b0dd79c9  jmp 0x00007957B0DD67D2
00007957b0dd79ce  sub rsp, 0x08
00007957b0dd79d2  push rax
00007957b0dd79d3  push rcx
00007957b0dd79d4  push rdx
00007957b0dd79d5  push rdi
00007957b0dd79d6  push rsi
00007957b0dd79d7  push r8
00007957b0dd79d9  push r9
00007957b0dd79db  push r10
00007957b0dd79dd  push r11
00007957b0dd79df  sub rsp, 0xF0
00007957b0dd79e6  vmovaps [rsp], xmm0
00007957b0dd79eb  vmovaps [rsp+0x10], xmm1
00007957b0dd79f1  vmovaps [rsp+0x20], xmm2
00007957b0dd79f7  vmovaps [rsp+0x30], xmm4
00007957b0dd79fd  vmovaps [rsp+0x40], xmm5
00007957b0dd7a03  vmovaps [rsp+0x50], xmm6
00007957b0dd7a09  vmovaps [rsp+0x60], xmm7
00007957b0dd7a0f  vmovaps [rsp+0x70], xmm8
00007957b0dd7a15  vmovaps [rsp+0x80], xmm9
00007957b0dd7a1e  vmovaps [rsp+0x90], xmm10
00007957b0dd7a27  vmovaps [rsp+0xA0], xmm11
00007957b0dd7a30  vmovaps [rsp+0xB0], xmm12
00007957b0dd7a39  vmovaps [rsp+0xC0], xmm13
00007957b0dd7a42  vmovaps [rsp+0xD0], xmm14
00007957b0dd7a4b  vmovaps [rsp+0xE0], xmm15
00007957b0dd7a54  sub rsp, 0x40
00007957b0dd7a58  lea rdi, [rsp]
00007957b0dd7a5c  lea rsi, [rsp+0x10]
00007957b0dd7a61  lea rdx, [rsp+0x20]
00007957b0dd7a66  lea rcx, [rsp+0x30]
00007957b0dd7a6b  mov r8d, 0x00
00007957b0dd7a71  lea r9, [r15+0x3A8]
00007957b0dd7a78  movaps [rdi], xmm3
00007957b0dd7a7b  movaps [rsi], xmm13
00007957b0dd7a7f  movaps [rdx], xmm6
00007957b0dd7a82  movaps [rcx], xmm14
00007957b0dd7a86  mov rax, 0x56E396DF1A50
00007957b0dd7a90  call rax
00007957b0dd7a92  movaps xmm3, [rsp]
00007957b0dd7a96  add rsp, 0x40
00007957b0dd7a9a  vmovaps xmm0, [rsp]
00007957b0dd7a9f  vmovaps xmm1, [rsp+0x10]
00007957b0dd7aa5  vmovaps xmm2, [rsp+0x20]
00007957b0dd7aab  vmovaps xmm4, [rsp+0x30]
00007957b0dd7ab1  vmovaps xmm5, [rsp+0x40]
00007957b0dd7ab7  vmovaps xmm6, [rsp+0x50]
00007957b0dd7abd  vmovaps xmm7, [rsp+0x60]
00007957b0dd7ac3  vmovaps xmm8, [rsp+0x70]
00007957b0dd7ac9  vmovaps xmm9, [rsp+0x80]
00007957b0dd7ad2  vmovaps xmm10, [rsp+0x90]
00007957b0dd7adb  vmovaps xmm11, [rsp+0xA0]
00007957b0dd7ae4  vmovaps xmm12, [rsp+0xB0]
00007957b0dd7aed  vmovaps xmm13, [rsp+0xC0]
00007957b0dd7af6  vmovaps xmm14, [rsp+0xD0]
00007957b0dd7aff  vmovaps xmm15, [rsp+0xE0]
00007957b0dd7b08  add rsp, 0xF0
00007957b0dd7b0f  pop r11
00007957b0dd7b11  pop r10
00007957b0dd7b13  pop r9
00007957b0dd7b15  pop r8
00007957b0dd7b17  pop rsi
00007957b0dd7b18  pop rdi
00007957b0dd7b19  pop rdx
00007957b0dd7b1a  pop rcx
00007957b0dd7b1b  pop rax
00007957b0dd7b1c  add rsp, 0x08
00007957b0dd7b20  jmp 0x00007957B0DD680F
00007957b0dd7b25  sub rsp, 0x08
00007957b0dd7b29  push rax
00007957b0dd7b2a  push rcx
00007957b0dd7b2b  push rdx
00007957b0dd7b2c  push rdi
00007957b0dd7b2d  push rsi
00007957b0dd7b2e  push r8
00007957b0dd7b30  push r9
00007957b0dd7b32  push r10
00007957b0dd7b34  push r11
00007957b0dd7b36  sub rsp, 0xF0
00007957b0dd7b3d  vmovaps [rsp], xmm0
00007957b0dd7b42  vmovaps [rsp+0x10], xmm1
00007957b0dd7b48  vmovaps [rsp+0x20], xmm2
00007957b0dd7b4e  vmovaps [rsp+0x30], xmm3
00007957b0dd7b54  vmovaps [rsp+0x40], xmm4
00007957b0dd7b5a  vmovaps [rsp+0x50], xmm5
00007957b0dd7b60  vmovaps [rsp+0x60], xmm7
00007957b0dd7b66  vmovaps [rsp+0x70], xmm8
00007957b0dd7b6c  vmovaps [rsp+0x80], xmm9
00007957b0dd7b75  vmovaps [rsp+0x90], xmm10
00007957b0dd7b7e  vmovaps [rsp+0xA0], xmm11
00007957b0dd7b87  vmovaps [rsp+0xB0], xmm12
00007957b0dd7b90  vmovaps [rsp+0xC0], xmm13
00007957b0dd7b99  vmovaps [rsp+0xD0], xmm14
00007957b0dd7ba2  vmovaps [rsp+0xE0], xmm15
00007957b0dd7bab  sub rsp, 0x40
00007957b0dd7baf  lea rdi, [rsp]
00007957b0dd7bb3  lea rsi, [rsp+0x10]
00007957b0dd7bb8  lea rdx, [rsp+0x20]
00007957b0dd7bbd  lea rcx, [rsp+0x30]
00007957b0dd7bc2  mov r8d, 0x00
00007957b0dd7bc8  lea r9, [r15+0x3A8]
00007957b0dd7bcf  movaps [rdi], xmm6
00007957b0dd7bd2  movaps [rsi], xmm2
00007957b0dd7bd5  movaps [rdx], xmm14
00007957b0dd7bd9  movaps [rcx], xmm1
00007957b0dd7bdc  mov rax, 0x56E396DF1A50
00007957b0dd7be6  call rax
00007957b0dd7be8  movaps xmm6, [rsp]
00007957b0dd7bec  add rsp, 0x40
00007957b0dd7bf0  vmovaps xmm0, [rsp]
00007957b0dd7bf5  vmovaps xmm1, [rsp+0x10]
00007957b0dd7bfb  vmovaps xmm2, [rsp+0x20]
00007957b0dd7c01  vmovaps xmm3, [rsp+0x30]
00007957b0dd7c07  vmovaps xmm4, [rsp+0x40]
00007957b0dd7c0d  vmovaps xmm5, [rsp+0x50]
00007957b0dd7c13  vmovaps xmm7, [rsp+0x60]
00007957b0dd7c19  vmovaps xmm8, [rsp+0x70]
00007957b0dd7c1f  vmovaps xmm9, [rsp+0x80]
00007957b0dd7c28  vmovaps xmm10, [rsp+0x90]
00007957b0dd7c31  vmovaps xmm11, [rsp+0xA0]
00007957b0dd7c3a  vmovaps xmm12, [rsp+0xB0]
00007957b0dd7c43  vmovaps xmm13, [rsp+0xC0]
00007957b0dd7c4c  vmovaps xmm14, [rsp+0xD0]
00007957b0dd7c55  vmovaps xmm15, [rsp+0xE0]
00007957b0dd7c5e  add rsp, 0xF0
00007957b0dd7c65  pop r11
00007957b0dd7c67  pop r10
00007957b0dd7c69  pop r9
00007957b0dd7c6b  pop r8
00007957b0dd7c6d  pop rsi
00007957b0dd7c6e  pop rdi
00007957b0dd7c6f  pop rdx
00007957b0dd7c70  pop rcx
00007957b0dd7c71  pop rax
00007957b0dd7c72  add rsp, 0x08
00007957b0dd7c76  jmp 0x00007957B0DD683C
00007957b0dd7c7b  sub rsp, 0x08
00007957b0dd7c7f  push rax
00007957b0dd7c80  push rcx
00007957b0dd7c81  push rdx
00007957b0dd7c82  push rdi
00007957b0dd7c83  push rsi
00007957b0dd7c84  push r8
00007957b0dd7c86  push r9
00007957b0dd7c88  push r10
00007957b0dd7c8a  push r11
00007957b0dd7c8c  sub rsp, 0xF0
00007957b0dd7c93  vmovaps [rsp], xmm0
00007957b0dd7c98  vmovaps [rsp+0x10], xmm1
00007957b0dd7c9e  vmovaps [rsp+0x20], xmm2
00007957b0dd7ca4  vmovaps [rsp+0x30], xmm3
00007957b0dd7caa  vmovaps [rsp+0x40], xmm4
00007957b0dd7cb0  vmovaps [rsp+0x50], xmm5
00007957b0dd7cb6  vmovaps [rsp+0x60], xmm6
00007957b0dd7cbc  vmovaps [rsp+0x70], xmm7
00007957b0dd7cc2  vmovaps [rsp+0x80], xmm8
00007957b0dd7ccb  vmovaps [rsp+0x90], xmm9
00007957b0dd7cd4  vmovaps [rsp+0xA0], xmm10
00007957b0dd7cdd  vmovaps [rsp+0xB0], xmm11
00007957b0dd7ce6  vmovaps [rsp+0xC0], xmm12
00007957b0dd7cef  vmovaps [rsp+0xD0], xmm14
00007957b0dd7cf8  vmovaps [rsp+0xE0], xmm15
00007957b0dd7d01  sub rsp, 0x40
00007957b0dd7d05  lea rdi, [rsp]
00007957b0dd7d09  lea rsi, [rsp+0x10]
00007957b0dd7d0e  lea rdx, [rsp+0x20]
00007957b0dd7d13  lea rcx, [rsp+0x30]
00007957b0dd7d18  mov r8d, 0x00
00007957b0dd7d1e  lea r9, [r15+0x3A8]
00007957b0dd7d25  movaps [rdi], xmm13
00007957b0dd7d29  movaps [rsi], xmm12
00007957b0dd7d2d  movaps [rdx], xmm14
00007957b0dd7d31  movaps [rcx], xmm1
00007957b0dd7d34  mov rax, 0x56E396DF1A50
00007957b0dd7d3e  call rax
00007957b0dd7d40  movaps xmm13, [rsp]
00007957b0dd7d45  add rsp, 0x40
00007957b0dd7d49  vmovaps xmm0, [rsp]
00007957b0dd7d4e  vmovaps xmm1, [rsp+0x10]
00007957b0dd7d54  vmovaps xmm2, [rsp+0x20]
00007957b0dd7d5a  vmovaps xmm3, [rsp+0x30]
00007957b0dd7d60  vmovaps xmm4, [rsp+0x40]
00007957b0dd7d66  vmovaps xmm5, [rsp+0x50]
00007957b0dd7d6c  vmovaps xmm6, [rsp+0x60]
00007957b0dd7d72  vmovaps xmm7, [rsp+0x70]
00007957b0dd7d78  vmovaps xmm8, [rsp+0x80]
00007957b0dd7d81  vmovaps xmm9, [rsp+0x90]
00007957b0dd7d8a  vmovaps xmm10, [rsp+0xA0]
00007957b0dd7d93  vmovaps xmm11, [rsp+0xB0]
00007957b0dd7d9c  vmovaps xmm12, [rsp+0xC0]
00007957b0dd7da5  vmovaps xmm14, [rsp+0xD0]
00007957b0dd7dae  vmovaps xmm15, [rsp+0xE0]
00007957b0dd7db7  add rsp, 0xF0
00007957b0dd7dbe  pop r11
00007957b0dd7dc0  pop r10
00007957b0dd7dc2  pop r9
00007957b0dd7dc4  pop r8
00007957b0dd7dc6  pop rsi
00007957b0dd7dc7  pop rdi
00007957b0dd7dc8  pop rdx
00007957b0dd7dc9  pop rcx
00007957b0dd7dca  pop rax
00007957b0dd7dcb  add rsp, 0x08
00007957b0dd7dcf  jmp 0x00007957B0DD686E
00007957b0dd7dd4  sub rsp, 0x08
00007957b0dd7dd8  push rax
00007957b0dd7dd9  push rcx
00007957b0dd7dda  push rdx
00007957b0dd7ddb  push rdi
00007957b0dd7ddc  push rsi
00007957b0dd7ddd  push r8
00007957b0dd7ddf  push r9
00007957b0dd7de1  push r10
00007957b0dd7de3  push r11
00007957b0dd7de5  sub rsp, 0xF0
00007957b0dd7dec  vmovaps [rsp], xmm0
00007957b0dd7df1  vmovaps [rsp+0x10], xmm1
00007957b0dd7df7  vmovaps [rsp+0x20], xmm2
00007957b0dd7dfd  vmovaps [rsp+0x30], xmm3
00007957b0dd7e03  vmovaps [rsp+0x40], xmm4
00007957b0dd7e09  vmovaps [rsp+0x50], xmm5
00007957b0dd7e0f  vmovaps [rsp+0x60], xmm6
00007957b0dd7e15  vmovaps [rsp+0x70], xmm7
00007957b0dd7e1b  vmovaps [rsp+0x80], xmm8
00007957b0dd7e24  vmovaps [rsp+0x90], xmm9
00007957b0dd7e2d  vmovaps [rsp+0xA0], xmm10
00007957b0dd7e36  vmovaps [rsp+0xB0], xmm11
00007957b0dd7e3f  vmovaps [rsp+0xC0], xmm13
00007957b0dd7e48  vmovaps [rsp+0xD0], xmm14
00007957b0dd7e51  vmovaps [rsp+0xE0], xmm15
00007957b0dd7e5a  sub rsp, 0x40
00007957b0dd7e5e  lea rdi, [rsp]
00007957b0dd7e62  lea rsi, [rsp+0x10]
00007957b0dd7e67  lea rdx, [rsp+0x20]
00007957b0dd7e6c  lea rcx, [rsp+0x30]
00007957b0dd7e71  mov r8d, 0x00
00007957b0dd7e77  lea r9, [r15+0x3A8]
00007957b0dd7e7e  movaps [rdi], xmm12
00007957b0dd7e82  movaps [rsi], xmm3
00007957b0dd7e85  movaps [rdx], xmm14
00007957b0dd7e89  movaps [rcx], xmm5
00007957b0dd7e8c  mov rax, 0x56E396DF1A50
00007957b0dd7e96  call rax
00007957b0dd7e98  movaps xmm12, [rsp]
00007957b0dd7e9d  add rsp, 0x40
00007957b0dd7ea1  vmovaps xmm0, [rsp]
00007957b0dd7ea6  vmovaps xmm1, [rsp+0x10]
00007957b0dd7eac  vmovaps xmm2, [rsp+0x20]
00007957b0dd7eb2  vmovaps xmm3, [rsp+0x30]
00007957b0dd7eb8  vmovaps xmm4, [rsp+0x40]
00007957b0dd7ebe  vmovaps xmm5, [rsp+0x50]
00007957b0dd7ec4  vmovaps xmm6, [rsp+0x60]
00007957b0dd7eca  vmovaps xmm7, [rsp+0x70]
00007957b0dd7ed0  vmovaps xmm8, [rsp+0x80]
00007957b0dd7ed9  vmovaps xmm9, [rsp+0x90]
00007957b0dd7ee2  vmovaps xmm10, [rsp+0xA0]
00007957b0dd7eeb  vmovaps xmm11, [rsp+0xB0]
00007957b0dd7ef4  vmovaps xmm13, [rsp+0xC0]
00007957b0dd7efd  vmovaps xmm14, [rsp+0xD0]
00007957b0dd7f06  vmovaps xmm15, [rsp+0xE0]
00007957b0dd7f0f  add rsp, 0xF0
00007957b0dd7f16  pop r11
00007957b0dd7f18  pop r10
00007957b0dd7f1a  pop r9
00007957b0dd7f1c  pop r8
00007957b0dd7f1e  pop rsi
00007957b0dd7f1f  pop rdi
00007957b0dd7f20  pop rdx
00007957b0dd7f21  pop rcx
00007957b0dd7f22  pop rax
00007957b0dd7f23  add rsp, 0x08
00007957b0dd7f27  jmp 0x00007957B0DD68CB
00007957b0dd7f2c  sub rsp, 0x08
00007957b0dd7f30  push rax
00007957b0dd7f31  push rcx
00007957b0dd7f32  push rdx
00007957b0dd7f33  push rdi
00007957b0dd7f34  push rsi
00007957b0dd7f35  push r8
00007957b0dd7f37  push r9
00007957b0dd7f39  push r10
00007957b0dd7f3b  push r11
00007957b0dd7f3d  sub rsp, 0xF0
00007957b0dd7f44  vmovaps [rsp], xmm0
00007957b0dd7f49  vmovaps [rsp+0x10], xmm1
00007957b0dd7f4f  vmovaps [rsp+0x20], xmm2
00007957b0dd7f55  vmovaps [rsp+0x30], xmm3
00007957b0dd7f5b  vmovaps [rsp+0x40], xmm4
00007957b0dd7f61  vmovaps [rsp+0x50], xmm5
00007957b0dd7f67  vmovaps [rsp+0x60], xmm6
00007957b0dd7f6d  vmovaps [rsp+0x70], xmm7
00007957b0dd7f73  vmovaps [rsp+0x80], xmm8
00007957b0dd7f7c  vmovaps [rsp+0x90], xmm9
00007957b0dd7f85  vmovaps [rsp+0xA0], xmm11
00007957b0dd7f8e  vmovaps [rsp+0xB0], xmm12
00007957b0dd7f97  vmovaps [rsp+0xC0], xmm13
00007957b0dd7fa0  vmovaps [rsp+0xD0], xmm14
00007957b0dd7fa9  vmovaps [rsp+0xE0], xmm15
00007957b0dd7fb2  sub rsp, 0x40
00007957b0dd7fb6  lea rdi, [rsp]
00007957b0dd7fba  lea rsi, [rsp+0x10]
00007957b0dd7fbf  lea rdx, [rsp+0x20]
00007957b0dd7fc4  lea rcx, [rsp+0x30]
00007957b0dd7fc9  mov r8d, 0x00
00007957b0dd7fcf  lea r9, [r15+0x3A8]
00007957b0dd7fd6  movaps [rdi], xmm10
00007957b0dd7fda  movaps [rsi], xmm9
00007957b0dd7fde  movaps [rdx], xmm7
00007957b0dd7fe1  movaps [rcx], xmm14
00007957b0dd7fe5  mov rax, 0x56E396DF1A50
00007957b0dd7fef  call rax
00007957b0dd7ff1  movaps xmm10, [rsp]
00007957b0dd7ff6  add rsp, 0x40
00007957b0dd7ffa  vmovaps xmm0, [rsp]
00007957b0dd7fff  vmovaps xmm1, [rsp+0x10]
00007957b0dd8005  vmovaps xmm2, [rsp+0x20]
00007957b0dd800b  vmovaps xmm3, [rsp+0x30]
00007957b0dd8011  vmovaps xmm4, [rsp+0x40]
00007957b0dd8017  vmovaps xmm5, [rsp+0x50]
00007957b0dd801d  vmovaps xmm6, [rsp+0x60]
00007957b0dd8023  vmovaps xmm7, [rsp+0x70]
00007957b0dd8029  vmovaps xmm8, [rsp+0x80]
00007957b0dd8032  vmovaps xmm9, [rsp+0x90]
00007957b0dd803b  vmovaps xmm11, [rsp+0xA0]
00007957b0dd8044  vmovaps xmm12, [rsp+0xB0]
00007957b0dd804d  vmovaps xmm13, [rsp+0xC0]
00007957b0dd8056  vmovaps xmm14, [rsp+0xD0]
00007957b0dd805f  vmovaps xmm15, [rsp+0xE0]
00007957b0dd8068  add rsp, 0xF0
00007957b0dd806f  pop r11
00007957b0dd8071  pop r10
00007957b0dd8073  pop r9
00007957b0dd8075  pop r8
00007957b0dd8077  pop rsi
00007957b0dd8078  pop rdi
00007957b0dd8079  pop rdx
00007957b0dd807a  pop rcx
00007957b0dd807b  pop rax
00007957b0dd807c  add rsp, 0x08
00007957b0dd8080  jmp 0x00007957B0DD68F1
00007957b0dd8085  call 0x00007957B0CE45A0
00007957b0dd808a  jmp 0x00007957B0DD68FE
00007957b0dd808f  sub rsp, 0x08
00007957b0dd8093  push rax
00007957b0dd8094  push rcx
00007957b0dd8095  push rdx
00007957b0dd8096  push rdi
00007957b0dd8097  push rsi
00007957b0dd8098  push r8
00007957b0dd809a  push r9
00007957b0dd809c  push r10
00007957b0dd809e  push r11
00007957b0dd80a0  sub rsp, 0xF0
00007957b0dd80a7  vmovaps [rsp], xmm0
00007957b0dd80ac  vmovaps [rsp+0x10], xmm1
00007957b0dd80b2  vmovaps [rsp+0x20], xmm2
00007957b0dd80b8  vmovaps [rsp+0x30], xmm3
00007957b0dd80be  vmovaps [rsp+0x40], xmm4
00007957b0dd80c4  vmovaps [rsp+0x50], xmm6
00007957b0dd80ca  vmovaps [rsp+0x60], xmm7
00007957b0dd80d0  vmovaps [rsp+0x70], xmm8
00007957b0dd80d6  vmovaps [rsp+0x80], xmm9
00007957b0dd80df  vmovaps [rsp+0x90], xmm10
00007957b0dd80e8  vmovaps [rsp+0xA0], xmm11
00007957b0dd80f1  vmovaps [rsp+0xB0], xmm12
00007957b0dd80fa  vmovaps [rsp+0xC0], xmm13
00007957b0dd8103  vmovaps [rsp+0xD0], xmm14
00007957b0dd810c  vmovaps [rsp+0xE0], xmm15
00007957b0dd8115  sub rsp, 0x40
00007957b0dd8119  lea rdi, [rsp]
00007957b0dd811d  lea rsi, [rsp+0x10]
00007957b0dd8122  lea rdx, [rsp+0x20]
00007957b0dd8127  lea rcx, [rsp+0x30]
00007957b0dd812c  mov r8d, 0x00
00007957b0dd8132  lea r9, [r15+0x3A8]
00007957b0dd8139  movaps [rdi], xmm5
00007957b0dd813c  movaps [rsi], xmm6
00007957b0dd813f  movaps [rdx], xmm7
00007957b0dd8142  movaps [rcx], xmm9
00007957b0dd8146  mov rax, 0x56E396DF1A50
00007957b0dd8150  call rax
00007957b0dd8152  movaps xmm5, [rsp]
00007957b0dd8156  add rsp, 0x40
00007957b0dd815a  vmovaps xmm0, [rsp]
00007957b0dd815f  vmovaps xmm1, [rsp+0x10]
00007957b0dd8165  vmovaps xmm2, [rsp+0x20]
00007957b0dd816b  vmovaps xmm3, [rsp+0x30]
00007957b0dd8171  vmovaps xmm4, [rsp+0x40]
00007957b0dd8177  vmovaps xmm6, [rsp+0x50]
00007957b0dd817d  vmovaps xmm7, [rsp+0x60]
00007957b0dd8183  vmovaps xmm8, [rsp+0x70]
00007957b0dd8189  vmovaps xmm9, [rsp+0x80]
00007957b0dd8192  vmovaps xmm10, [rsp+0x90]
00007957b0dd819b  vmovaps xmm11, [rsp+0xA0]
00007957b0dd81a4  vmovaps xmm12, [rsp+0xB0]
00007957b0dd81ad  vmovaps xmm13, [rsp+0xC0]
00007957b0dd81b6  vmovaps xmm14, [rsp+0xD0]
00007957b0dd81bf  vmovaps xmm15, [rsp+0xE0]
00007957b0dd81c8  add rsp, 0xF0
00007957b0dd81cf  pop r11
00007957b0dd81d1  pop r10
00007957b0dd81d3  pop r9
00007957b0dd81d5  pop r8
00007957b0dd81d7  pop rsi
00007957b0dd81d8  pop rdi
00007957b0dd81d9  pop rdx
00007957b0dd81da  pop rcx
00007957b0dd81db  pop rax
00007957b0dd81dc  add rsp, 0x08
00007957b0dd81e0  jmp 0x00007957B0DD6930
00007957b0dd81e5  sub rsp, 0x08
00007957b0dd81e9  push rax
00007957b0dd81ea  push rcx
00007957b0dd81eb  push rdx
00007957b0dd81ec  push rdi
00007957b0dd81ed  push rsi
00007957b0dd81ee  push r8
00007957b0dd81f0  push r9
00007957b0dd81f2  push r10
00007957b0dd81f4  push r11
00007957b0dd81f6  sub rsp, 0xF0
00007957b0dd81fd  vmovaps [rsp], xmm0
00007957b0dd8202  vmovaps [rsp+0x10], xmm1
00007957b0dd8208  vmovaps [rsp+0x20], xmm2
00007957b0dd820e  vmovaps [rsp+0x30], xmm3
00007957b0dd8214  vmovaps [rsp+0x40], xmm4
00007957b0dd821a  vmovaps [rsp+0x50], xmm5
00007957b0dd8220  vmovaps [rsp+0x60], xmm6
00007957b0dd8226  vmovaps [rsp+0x70], xmm8
00007957b0dd822c  vmovaps [rsp+0x80], xmm9
00007957b0dd8235  vmovaps [rsp+0x90], xmm10
00007957b0dd823e  vmovaps [rsp+0xA0], xmm11
00007957b0dd8247  vmovaps [rsp+0xB0], xmm12
00007957b0dd8250  vmovaps [rsp+0xC0], xmm13
00007957b0dd8259  vmovaps [rsp+0xD0], xmm14
00007957b0dd8262  vmovaps [rsp+0xE0], xmm15
00007957b0dd826b  sub rsp, 0x40
00007957b0dd826f  lea rdi, [rsp]
00007957b0dd8273  lea rsi, [rsp+0x10]
00007957b0dd8278  lea rdx, [rsp+0x20]
00007957b0dd827d  lea rcx, [rsp+0x30]
00007957b0dd8282  mov r8d, 0x00
00007957b0dd8288  lea r9, [r15+0x3A8]
00007957b0dd828f  movaps [rdi], xmm7
00007957b0dd8292  movaps [rsi], xmm13
00007957b0dd8296  movaps [rdx], xmm1
00007957b0dd8299  movaps [rcx], xmm9
00007957b0dd829d  mov rax, 0x56E396DF1A50
00007957b0dd82a7  call rax
00007957b0dd82a9  movaps xmm7, [rsp]
00007957b0dd82ad  add rsp, 0x40
00007957b0dd82b1  vmovaps xmm0, [rsp]
00007957b0dd82b6  vmovaps xmm1, [rsp+0x10]
00007957b0dd82bc  vmovaps xmm2, [rsp+0x20]
00007957b0dd82c2  vmovaps xmm3, [rsp+0x30]
00007957b0dd82c8  vmovaps xmm4, [rsp+0x40]
00007957b0dd82ce  vmovaps xmm5, [rsp+0x50]
00007957b0dd82d4  vmovaps xmm6, [rsp+0x60]
00007957b0dd82da  vmovaps xmm8, [rsp+0x70]
00007957b0dd82e0  vmovaps xmm9, [rsp+0x80]
00007957b0dd82e9  vmovaps xmm10, [rsp+0x90]
00007957b0dd82f2  vmovaps xmm11, [rsp+0xA0]
00007957b0dd82fb  vmovaps xmm12, [rsp+0xB0]
00007957b0dd8304  vmovaps xmm13, [rsp+0xC0]
00007957b0dd830d  vmovaps xmm14, [rsp+0xD0]
00007957b0dd8316  vmovaps xmm15, [rsp+0xE0]
00007957b0dd831f  add rsp, 0xF0
00007957b0dd8326  pop r11
00007957b0dd8328  pop r10
00007957b0dd832a  pop r9
00007957b0dd832c  pop r8
00007957b0dd832e  pop rsi
00007957b0dd832f  pop rdi
00007957b0dd8330  pop rdx
00007957b0dd8331  pop rcx
00007957b0dd8332  pop rax
00007957b0dd8333  add rsp, 0x08
00007957b0dd8337  jmp 0x00007957B0DD6955
00007957b0dd833c  call 0x00007957B0CE3320
00007957b0dd8341  jmp 0x00007957B0DD6978
00007957b0dd8346  call 0x00007957B0CDE950
00007957b0dd834b  jmp 0x00007957B0DD6982
00007957b0dd8350  sub rsp, 0x08
00007957b0dd8354  push rax
00007957b0dd8355  push rcx
00007957b0dd8356  push rdx
00007957b0dd8357  push rdi
00007957b0dd8358  push rsi
00007957b0dd8359  push r8
00007957b0dd835b  push r9
00007957b0dd835d  push r10
00007957b0dd835f  push r11
00007957b0dd8361  sub rsp, 0xF0
00007957b0dd8368  vmovaps [rsp], xmm0
00007957b0dd836d  vmovaps [rsp+0x10], xmm1
00007957b0dd8373  vmovaps [rsp+0x20], xmm3
00007957b0dd8379  vmovaps [rsp+0x30], xmm4
00007957b0dd837f  vmovaps [rsp+0x40], xmm5
00007957b0dd8385  vmovaps [rsp+0x50], xmm6
00007957b0dd838b  vmovaps [rsp+0x60], xmm7
00007957b0dd8391  vmovaps [rsp+0x70], xmm8
00007957b0dd8397  vmovaps [rsp+0x80], xmm9
00007957b0dd83a0  vmovaps [rsp+0x90], xmm10
00007957b0dd83a9  vmovaps [rsp+0xA0], xmm11
00007957b0dd83b2  vmovaps [rsp+0xB0], xmm12
00007957b0dd83bb  vmovaps [rsp+0xC0], xmm13
00007957b0dd83c4  vmovaps [rsp+0xD0], xmm14
00007957b0dd83cd  vmovaps [rsp+0xE0], xmm15
00007957b0dd83d6  sub rsp, 0x40
00007957b0dd83da  lea rdi, [rsp]
00007957b0dd83de  lea rsi, [rsp+0x10]
00007957b0dd83e3  lea rdx, [rsp+0x20]
00007957b0dd83e8  lea rcx, [rsp+0x30]
00007957b0dd83ed  mov r8d, 0x00
00007957b0dd83f3  lea r9, [r15+0x3A8]
00007957b0dd83fa  movaps [rdi], xmm2
00007957b0dd83fd  movaps [rsi], xmm12
00007957b0dd8401  movaps [rdx], xmm6
00007957b0dd8404  movaps [rcx], xmm3
00007957b0dd8407  mov rax, 0x56E396DF1A50
00007957b0dd8411  call rax
00007957b0dd8413  movaps xmm2, [rsp]
00007957b0dd8417  add rsp, 0x40
00007957b0dd841b  vmovaps xmm0, [rsp]
00007957b0dd8420  vmovaps xmm1, [rsp+0x10]
00007957b0dd8426  vmovaps xmm3, [rsp+0x20]
00007957b0dd842c  vmovaps xmm4, [rsp+0x30]
00007957b0dd8432  vmovaps xmm5, [rsp+0x40]
00007957b0dd8438  vmovaps xmm6, [rsp+0x50]
00007957b0dd843e  vmovaps xmm7, [rsp+0x60]
00007957b0dd8444  vmovaps xmm8, [rsp+0x70]
00007957b0dd844a  vmovaps xmm9, [rsp+0x80]
00007957b0dd8453  vmovaps xmm10, [rsp+0x90]
00007957b0dd845c  vmovaps xmm11, [rsp+0xA0]
00007957b0dd8465  vmovaps xmm12, [rsp+0xB0]
00007957b0dd846e  vmovaps xmm13, [rsp+0xC0]
00007957b0dd8477  vmovaps xmm14, [rsp+0xD0]
00007957b0dd8480  vmovaps xmm15, [rsp+0xE0]
00007957b0dd8489  add rsp, 0xF0
00007957b0dd8490  pop r11
00007957b0dd8492  pop r10
00007957b0dd8494  pop r9
00007957b0dd8496  pop r8
00007957b0dd8498  pop rsi
00007957b0dd8499  pop rdi
00007957b0dd849a  pop rdx
00007957b0dd849b  pop rcx
00007957b0dd849c  pop rax
00007957b0dd849d  add rsp, 0x08
00007957b0dd84a1  jmp 0x00007957B0DD69C8
00007957b0dd84a6  sub rsp, 0x08
00007957b0dd84aa  push rax
00007957b0dd84ab  push rcx
00007957b0dd84ac  push rdx
00007957b0dd84ad  push rdi
00007957b0dd84ae  push rsi
00007957b0dd84af  push r8
00007957b0dd84b1  push r9
00007957b0dd84b3  push r10
00007957b0dd84b5  push r11
00007957b0dd84b7  sub rsp, 0xF0
00007957b0dd84be  vmovaps [rsp], xmm0
00007957b0dd84c3  vmovaps [rsp+0x10], xmm1
00007957b0dd84c9  vmovaps [rsp+0x20], xmm2
00007957b0dd84cf  vmovaps [rsp+0x30], xmm3
00007957b0dd84d5  vmovaps [rsp+0x40], xmm4
00007957b0dd84db  vmovaps [rsp+0x50], xmm5
00007957b0dd84e1  vmovaps [rsp+0x60], xmm7
00007957b0dd84e7  vmovaps [rsp+0x70], xmm8
00007957b0dd84ed  vmovaps [rsp+0x80], xmm9
00007957b0dd84f6  vmovaps [rsp+0x90], xmm10
00007957b0dd84ff  vmovaps [rsp+0xA0], xmm11
00007957b0dd8508  vmovaps [rsp+0xB0], xmm12
00007957b0dd8511  vmovaps [rsp+0xC0], xmm13
00007957b0dd851a  vmovaps [rsp+0xD0], xmm14
00007957b0dd8523  vmovaps [rsp+0xE0], xmm15
00007957b0dd852c  sub rsp, 0x40
00007957b0dd8530  lea rdi, [rsp]
00007957b0dd8534  lea rsi, [rsp+0x10]
00007957b0dd8539  lea rdx, [rsp+0x20]
00007957b0dd853e  lea rcx, [rsp+0x30]
00007957b0dd8543  mov r8d, 0x00
00007957b0dd8549  lea r9, [r15+0x3A8]
00007957b0dd8550  movaps [rdi], xmm6
00007957b0dd8553  movaps [rsi], xmm10
00007957b0dd8557  movaps [rdx], xmm12
00007957b0dd855b  movaps [rcx], xmm1
00007957b0dd855e  mov rax, 0x56E396DF1A50
00007957b0dd8568  call rax
00007957b0dd856a  movaps xmm6, [rsp]
00007957b0dd856e  add rsp, 0x40
00007957b0dd8572  vmovaps xmm0, [rsp]
00007957b0dd8577  vmovaps xmm1, [rsp+0x10]
00007957b0dd857d  vmovaps xmm2, [rsp+0x20]
00007957b0dd8583  vmovaps xmm3, [rsp+0x30]
00007957b0dd8589  vmovaps xmm4, [rsp+0x40]
00007957b0dd858f  vmovaps xmm5, [rsp+0x50]
00007957b0dd8595  vmovaps xmm7, [rsp+0x60]
00007957b0dd859b  vmovaps xmm8, [rsp+0x70]
00007957b0dd85a1  vmovaps xmm9, [rsp+0x80]
00007957b0dd85aa  vmovaps xmm10, [rsp+0x90]
00007957b0dd85b3  vmovaps xmm11, [rsp+0xA0]
00007957b0dd85bc  vmovaps xmm12, [rsp+0xB0]
00007957b0dd85c5  vmovaps xmm13, [rsp+0xC0]
00007957b0dd85ce  vmovaps xmm14, [rsp+0xD0]
00007957b0dd85d7  vmovaps xmm15, [rsp+0xE0]
00007957b0dd85e0  add rsp, 0xF0
00007957b0dd85e7  pop r11
00007957b0dd85e9  pop r10
00007957b0dd85eb  pop r9
00007957b0dd85ed  pop r8
00007957b0dd85ef  pop rsi
00007957b0dd85f0  pop rdi
00007957b0dd85f1  pop rdx
00007957b0dd85f2  pop rcx
00007957b0dd85f3  pop rax
00007957b0dd85f4  add rsp, 0x08
00007957b0dd85f8  jmp 0x00007957B0DD69F6
00007957b0dd85fd  sub rsp, 0x08
00007957b0dd8601  push rax
00007957b0dd8602  push rcx
00007957b0dd8603  push rdx
00007957b0dd8604  push rdi
00007957b0dd8605  push rsi
00007957b0dd8606  push r8
00007957b0dd8608  push r9
00007957b0dd860a  push r10
00007957b0dd860c  push r11
00007957b0dd860e  sub rsp, 0xF0
00007957b0dd8615  vmovaps [rsp], xmm0
00007957b0dd861a  vmovaps [rsp+0x10], xmm1
00007957b0dd8620  vmovaps [rsp+0x20], xmm2
00007957b0dd8626  vmovaps [rsp+0x30], xmm3
00007957b0dd862c  vmovaps [rsp+0x40], xmm4
00007957b0dd8632  vmovaps [rsp+0x50], xmm5
00007957b0dd8638  vmovaps [rsp+0x60], xmm6
00007957b0dd863e  vmovaps [rsp+0x70], xmm7
00007957b0dd8644  vmovaps [rsp+0x80], xmm8
00007957b0dd864d  vmovaps [rsp+0x90], xmm9
00007957b0dd8656  vmovaps [rsp+0xA0], xmm11
00007957b0dd865f  vmovaps [rsp+0xB0], xmm12
00007957b0dd8668  vmovaps [rsp+0xC0], xmm13
00007957b0dd8671  vmovaps [rsp+0xD0], xmm14
00007957b0dd867a  vmovaps [rsp+0xE0], xmm15
00007957b0dd8683  sub rsp, 0x40
00007957b0dd8687  lea rdi, [rsp]
00007957b0dd868b  lea rsi, [rsp+0x10]
00007957b0dd8690  lea rdx, [rsp+0x20]
00007957b0dd8695  lea rcx, [rsp+0x30]
00007957b0dd869a  mov r8d, 0x00
00007957b0dd86a0  lea r9, [r15+0x3A8]
00007957b0dd86a7  movaps [rdi], xmm10
00007957b0dd86ab  movaps [rsi], xmm5
00007957b0dd86ae  movaps [rdx], xmm12
00007957b0dd86b2  movaps [rcx], xmm1
00007957b0dd86b5  mov rax, 0x56E396DF1A50
00007957b0dd86bf  call rax
00007957b0dd86c1  movaps xmm10, [rsp]
00007957b0dd86c6  add rsp, 0x40
00007957b0dd86ca  vmovaps xmm0, [rsp]
00007957b0dd86cf  vmovaps xmm1, [rsp+0x10]
00007957b0dd86d5  vmovaps xmm2, [rsp+0x20]
00007957b0dd86db  vmovaps xmm3, [rsp+0x30]
00007957b0dd86e1  vmovaps xmm4, [rsp+0x40]
00007957b0dd86e7  vmovaps xmm5, [rsp+0x50]
00007957b0dd86ed  vmovaps xmm6, [rsp+0x60]
00007957b0dd86f3  vmovaps xmm7, [rsp+0x70]
00007957b0dd86f9  vmovaps xmm8, [rsp+0x80]
00007957b0dd8702  vmovaps xmm9, [rsp+0x90]
00007957b0dd870b  vmovaps xmm11, [rsp+0xA0]
00007957b0dd8714  vmovaps xmm12, [rsp+0xB0]
00007957b0dd871d  vmovaps xmm13, [rsp+0xC0]
00007957b0dd8726  vmovaps xmm14, [rsp+0xD0]
00007957b0dd872f  vmovaps xmm15, [rsp+0xE0]
00007957b0dd8738  add rsp, 0xF0
00007957b0dd873f  pop r11
00007957b0dd8741  pop r10
00007957b0dd8743  pop r9
00007957b0dd8745  pop r8
00007957b0dd8747  pop rsi
00007957b0dd8748  pop rdi
00007957b0dd8749  pop rdx
00007957b0dd874a  pop rcx
00007957b0dd874b  pop rax
00007957b0dd874c  add rsp, 0x08
00007957b0dd8750  jmp 0x00007957B0DD6A25
00007957b0dd8755  sub rsp, 0x08
00007957b0dd8759  push rax
00007957b0dd875a  push rcx
00007957b0dd875b  push rdx
00007957b0dd875c  push rdi
00007957b0dd875d  push rsi
00007957b0dd875e  push r8
00007957b0dd8760  push r9
00007957b0dd8762  push r10
00007957b0dd8764  push r11
00007957b0dd8766  sub rsp, 0xF0
00007957b0dd876d  vmovaps [rsp], xmm0
00007957b0dd8772  vmovaps [rsp+0x10], xmm1
00007957b0dd8778  vmovaps [rsp+0x20], xmm2
00007957b0dd877e  vmovaps [rsp+0x30], xmm3
00007957b0dd8784  vmovaps [rsp+0x40], xmm4
00007957b0dd878a  vmovaps [rsp+0x50], xmm5
00007957b0dd8790  vmovaps [rsp+0x60], xmm6
00007957b0dd8796  vmovaps [rsp+0x70], xmm7
00007957b0dd879c  vmovaps [rsp+0x80], xmm8
00007957b0dd87a5  vmovaps [rsp+0x90], xmm9
00007957b0dd87ae  vmovaps [rsp+0xA0], xmm10
00007957b0dd87b7  vmovaps [rsp+0xB0], xmm11
00007957b0dd87c0  vmovaps [rsp+0xC0], xmm13
00007957b0dd87c9  vmovaps [rsp+0xD0], xmm14
00007957b0dd87d2  vmovaps [rsp+0xE0], xmm15
00007957b0dd87db  sub rsp, 0x40
00007957b0dd87df  lea rdi, [rsp]
00007957b0dd87e3  lea rsi, [rsp+0x10]
00007957b0dd87e8  lea rdx, [rsp+0x20]
00007957b0dd87ed  lea rcx, [rsp+0x30]
00007957b0dd87f2  mov r8d, 0x00
00007957b0dd87f8  lea r9, [r15+0x3A8]
00007957b0dd87ff  movaps [rdi], xmm12
00007957b0dd8803  movaps [rsi], xmm7
00007957b0dd8806  movaps [rdx], xmm15
00007957b0dd880a  movaps [rcx], xmm1
00007957b0dd880d  mov rax, 0x56E396DF1A50
00007957b0dd8817  call rax
00007957b0dd8819  movaps xmm12, [rsp]
00007957b0dd881e  add rsp, 0x40
00007957b0dd8822  vmovaps xmm0, [rsp]
00007957b0dd8827  vmovaps xmm1, [rsp+0x10]
00007957b0dd882d  vmovaps xmm2, [rsp+0x20]
00007957b0dd8833  vmovaps xmm3, [rsp+0x30]
00007957b0dd8839  vmovaps xmm4, [rsp+0x40]
00007957b0dd883f  vmovaps xmm5, [rsp+0x50]
00007957b0dd8845  vmovaps xmm6, [rsp+0x60]
00007957b0dd884b  vmovaps xmm7, [rsp+0x70]
00007957b0dd8851  vmovaps xmm8, [rsp+0x80]
00007957b0dd885a  vmovaps xmm9, [rsp+0x90]
00007957b0dd8863  vmovaps xmm10, [rsp+0xA0]
00007957b0dd886c  vmovaps xmm11, [rsp+0xB0]
00007957b0dd8875  vmovaps xmm13, [rsp+0xC0]
00007957b0dd887e  vmovaps xmm14, [rsp+0xD0]
00007957b0dd8887  vmovaps xmm15, [rsp+0xE0]
00007957b0dd8890  add rsp, 0xF0
00007957b0dd8897  pop r11
00007957b0dd8899  pop r10
00007957b0dd889b  pop r9
00007957b0dd889d  pop r8
00007957b0dd889f  pop rsi
00007957b0dd88a0  pop rdi
00007957b0dd88a1  pop rdx
00007957b0dd88a2  pop rcx
00007957b0dd88a3  pop rax
00007957b0dd88a4  add rsp, 0x08
00007957b0dd88a8  jmp 0x00007957B0DD6A4E
00007957b0dd88ad  call 0x00007957B0CD64F0
00007957b0dd88b2  jmp 0x00007957B0DD6A58
00007957b0dd88b7  call 0x00007957B0CE5820
00007957b0dd88bc  jmp 0x00007957B0DD6A62
00007957b0dd88c1  sub rsp, 0x08
00007957b0dd88c5  push rax
00007957b0dd88c6  push rcx
00007957b0dd88c7  push rdx
00007957b0dd88c8  push rdi
00007957b0dd88c9  push rsi
00007957b0dd88ca  push r8
00007957b0dd88cc  push r9
00007957b0dd88ce  push r10
00007957b0dd88d0  push r11
00007957b0dd88d2  sub rsp, 0xF0
00007957b0dd88d9  vmovaps [rsp], xmm0
00007957b0dd88de  vmovaps [rsp+0x10], xmm1
00007957b0dd88e4  vmovaps [rsp+0x20], xmm2
00007957b0dd88ea  vmovaps [rsp+0x30], xmm3
00007957b0dd88f0  vmovaps [rsp+0x40], xmm4
00007957b0dd88f6  vmovaps [rsp+0x50], xmm5
00007957b0dd88fc  vmovaps [rsp+0x60], xmm6
00007957b0dd8902  vmovaps [rsp+0x70], xmm8
00007957b0dd8908  vmovaps [rsp+0x80], xmm9
00007957b0dd8911  vmovaps [rsp+0x90], xmm10
00007957b0dd891a  vmovaps [rsp+0xA0], xmm11
00007957b0dd8923  vmovaps [rsp+0xB0], xmm12
00007957b0dd892c  vmovaps [rsp+0xC0], xmm13
00007957b0dd8935  vmovaps [rsp+0xD0], xmm14
00007957b0dd893e  vmovaps [rsp+0xE0], xmm15
00007957b0dd8947  sub rsp, 0x40
00007957b0dd894b  lea rdi, [rsp]
00007957b0dd894f  lea rsi, [rsp+0x10]
00007957b0dd8954  lea rdx, [rsp+0x20]
00007957b0dd8959  lea rcx, [rsp+0x30]
00007957b0dd895e  mov r8d, 0x00
00007957b0dd8964  lea r9, [r15+0x3A8]
00007957b0dd896b  movaps [rdi], xmm7
00007957b0dd896e  movaps [rsi], xmm2
00007957b0dd8971  movaps [rdx], xmm9
00007957b0dd8975  movaps [rcx], xmm11
00007957b0dd8979  mov rax, 0x56E396DF1A50
00007957b0dd8983  call rax
00007957b0dd8985  movaps xmm7, [rsp]
00007957b0dd8989  add rsp, 0x40
00007957b0dd898d  vmovaps xmm0, [rsp]
00007957b0dd8992  vmovaps xmm1, [rsp+0x10]
00007957b0dd8998  vmovaps xmm2, [rsp+0x20]
00007957b0dd899e  vmovaps xmm3, [rsp+0x30]
00007957b0dd89a4  vmovaps xmm4, [rsp+0x40]
00007957b0dd89aa  vmovaps xmm5, [rsp+0x50]
00007957b0dd89b0  vmovaps xmm6, [rsp+0x60]
00007957b0dd89b6  vmovaps xmm8, [rsp+0x70]
00007957b0dd89bc  vmovaps xmm9, [rsp+0x80]
00007957b0dd89c5  vmovaps xmm10, [rsp+0x90]
00007957b0dd89ce  vmovaps xmm11, [rsp+0xA0]
00007957b0dd89d7  vmovaps xmm12, [rsp+0xB0]
00007957b0dd89e0  vmovaps xmm13, [rsp+0xC0]
00007957b0dd89e9  vmovaps xmm14, [rsp+0xD0]
00007957b0dd89f2  vmovaps xmm15, [rsp+0xE0]
00007957b0dd89fb  add rsp, 0xF0
00007957b0dd8a02  pop r11
00007957b0dd8a04  pop r10
00007957b0dd8a06  pop r9
00007957b0dd8a08  pop r8
00007957b0dd8a0a  pop rsi
00007957b0dd8a0b  pop rdi
00007957b0dd8a0c  pop rdx
00007957b0dd8a0d  pop rcx
00007957b0dd8a0e  pop rax
00007957b0dd8a0f  add rsp, 0x08
00007957b0dd8a13  jmp 0x00007957B0DD6A96
00007957b0dd8a18  sub rsp, 0x08
00007957b0dd8a1c  push rax
00007957b0dd8a1d  push rcx
00007957b0dd8a1e  push rdx
00007957b0dd8a1f  push rdi
00007957b0dd8a20  push rsi
00007957b0dd8a21  push r8
00007957b0dd8a23  push r9
00007957b0dd8a25  push r10
00007957b0dd8a27  push r11
00007957b0dd8a29  sub rsp, 0xF0
00007957b0dd8a30  vmovaps [rsp], xmm0
00007957b0dd8a35  vmovaps [rsp+0x10], xmm1
00007957b0dd8a3b  vmovaps [rsp+0x20], xmm2
00007957b0dd8a41  vmovaps [rsp+0x30], xmm3
00007957b0dd8a47  vmovaps [rsp+0x40], xmm4
00007957b0dd8a4d  vmovaps [rsp+0x50], xmm5
00007957b0dd8a53  vmovaps [rsp+0x60], xmm6
00007957b0dd8a59  vmovaps [rsp+0x70], xmm7
00007957b0dd8a5f  vmovaps [rsp+0x80], xmm8
00007957b0dd8a68  vmovaps [rsp+0x90], xmm10
00007957b0dd8a71  vmovaps [rsp+0xA0], xmm11
00007957b0dd8a7a  vmovaps [rsp+0xB0], xmm12
00007957b0dd8a83  vmovaps [rsp+0xC0], xmm13
00007957b0dd8a8c  vmovaps [rsp+0xD0], xmm14
00007957b0dd8a95  vmovaps [rsp+0xE0], xmm15
00007957b0dd8a9e  sub rsp, 0x40
00007957b0dd8aa2  lea rdi, [rsp]
00007957b0dd8aa6  lea rsi, [rsp+0x10]
00007957b0dd8aab  lea rdx, [rsp+0x20]
00007957b0dd8ab0  lea rcx, [rsp+0x30]
00007957b0dd8ab5  mov r8d, 0x00
00007957b0dd8abb  lea r9, [r15+0x3A8]
00007957b0dd8ac2  movaps [rdi], xmm9
00007957b0dd8ac6  movaps [rsi], xmm6
00007957b0dd8ac9  movaps [rdx], xmm1
00007957b0dd8acc  movaps [rcx], xmm11
00007957b0dd8ad0  mov rax, 0x56E396DF1A50
00007957b0dd8ada  call rax
00007957b0dd8adc  movaps xmm9, [rsp]
00007957b0dd8ae1  add rsp, 0x40
00007957b0dd8ae5  vmovaps xmm0, [rsp]
00007957b0dd8aea  vmovaps xmm1, [rsp+0x10]
00007957b0dd8af0  vmovaps xmm2, [rsp+0x20]
00007957b0dd8af6  vmovaps xmm3, [rsp+0x30]
00007957b0dd8afc  vmovaps xmm4, [rsp+0x40]
00007957b0dd8b02  vmovaps xmm5, [rsp+0x50]
00007957b0dd8b08  vmovaps xmm6, [rsp+0x60]
00007957b0dd8b0e  vmovaps xmm7, [rsp+0x70]
00007957b0dd8b14  vmovaps xmm8, [rsp+0x80]
00007957b0dd8b1d  vmovaps xmm10, [rsp+0x90]
00007957b0dd8b26  vmovaps xmm11, [rsp+0xA0]
00007957b0dd8b2f  vmovaps xmm12, [rsp+0xB0]
00007957b0dd8b38  vmovaps xmm13, [rsp+0xC0]
00007957b0dd8b41  vmovaps xmm14, [rsp+0xD0]
00007957b0dd8b4a  vmovaps xmm15, [rsp+0xE0]
00007957b0dd8b53  add rsp, 0xF0
00007957b0dd8b5a  pop r11
00007957b0dd8b5c  pop r10
00007957b0dd8b5e  pop r9
00007957b0dd8b60  pop r8
00007957b0dd8b62  pop rsi
00007957b0dd8b63  pop rdi
00007957b0dd8b64  pop rdx
00007957b0dd8b65  pop rcx
00007957b0dd8b66  pop rax
00007957b0dd8b67  add rsp, 0x08
00007957b0dd8b6b  jmp 0x00007957B0DD6ABC
00007957b0dd8b70  sub rsp, 0x08
00007957b0dd8b74  push rax
00007957b0dd8b75  push rcx
00007957b0dd8b76  push rdx
00007957b0dd8b77  push rdi
00007957b0dd8b78  push rsi
00007957b0dd8b79  push r8
00007957b0dd8b7b  push r9
00007957b0dd8b7d  push r10
00007957b0dd8b7f  push r11
00007957b0dd8b81  sub rsp, 0xF0
00007957b0dd8b88  vmovaps [rsp], xmm0
00007957b0dd8b8d  vmovaps [rsp+0x10], xmm1
00007957b0dd8b93  vmovaps [rsp+0x20], xmm2
00007957b0dd8b99  vmovaps [rsp+0x30], xmm3
00007957b0dd8b9f  vmovaps [rsp+0x40], xmm4
00007957b0dd8ba5  vmovaps [rsp+0x50], xmm5
00007957b0dd8bab  vmovaps [rsp+0x60], xmm6
00007957b0dd8bb1  vmovaps [rsp+0x70], xmm7
00007957b0dd8bb7  vmovaps [rsp+0x80], xmm8
00007957b0dd8bc0  vmovaps [rsp+0x90], xmm9
00007957b0dd8bc9  vmovaps [rsp+0xA0], xmm10
00007957b0dd8bd2  vmovaps [rsp+0xB0], xmm12
00007957b0dd8bdb  vmovaps [rsp+0xC0], xmm13
00007957b0dd8be4  vmovaps [rsp+0xD0], xmm14
00007957b0dd8bed  vmovaps [rsp+0xE0], xmm15
00007957b0dd8bf6  sub rsp, 0x40
00007957b0dd8bfa  lea rdi, [rsp]
00007957b0dd8bfe  lea rsi, [rsp+0x10]
00007957b0dd8c03  lea rdx, [rsp+0x20]
00007957b0dd8c08  lea rcx, [rsp+0x30]
00007957b0dd8c0d  mov r8d, 0x00
00007957b0dd8c13  lea r9, [r15+0x3A8]
00007957b0dd8c1a  movaps [rdi], xmm11
00007957b0dd8c1e  movaps [rsi], xmm10
00007957b0dd8c22  movaps [rdx], xmm8
00007957b0dd8c26  movaps [rcx], xmm1
00007957b0dd8c29  mov rax, 0x56E396DF1A50
00007957b0dd8c33  call rax
00007957b0dd8c35  movaps xmm11, [rsp]
00007957b0dd8c3a  add rsp, 0x40
00007957b0dd8c3e  vmovaps xmm0, [rsp]
00007957b0dd8c43  vmovaps xmm1, [rsp+0x10]
00007957b0dd8c49  vmovaps xmm2, [rsp+0x20]
00007957b0dd8c4f  vmovaps xmm3, [rsp+0x30]
00007957b0dd8c55  vmovaps xmm4, [rsp+0x40]
00007957b0dd8c5b  vmovaps xmm5, [rsp+0x50]
00007957b0dd8c61  vmovaps xmm6, [rsp+0x60]
00007957b0dd8c67  vmovaps xmm7, [rsp+0x70]
00007957b0dd8c6d  vmovaps xmm8, [rsp+0x80]
00007957b0dd8c76  vmovaps xmm9, [rsp+0x90]
00007957b0dd8c7f  vmovaps xmm10, [rsp+0xA0]
00007957b0dd8c88  vmovaps xmm12, [rsp+0xB0]
00007957b0dd8c91  vmovaps xmm13, [rsp+0xC0]
00007957b0dd8c9a  vmovaps xmm14, [rsp+0xD0]
00007957b0dd8ca3  vmovaps xmm15, [rsp+0xE0]
00007957b0dd8cac  add rsp, 0xF0
00007957b0dd8cb3  pop r11
00007957b0dd8cb5  pop r10
00007957b0dd8cb7  pop r9
00007957b0dd8cb9  pop r8
00007957b0dd8cbb  pop rsi
00007957b0dd8cbc  pop rdi
00007957b0dd8cbd  pop rdx
00007957b0dd8cbe  pop rcx
00007957b0dd8cbf  pop rax
00007957b0dd8cc0  add rsp, 0x08
00007957b0dd8cc4  jmp 0x00007957B0DD6AE2
00007957b0dd8cc9  sub rsp, 0x08
00007957b0dd8ccd  push rax
00007957b0dd8cce  push rcx
00007957b0dd8ccf  push rdx
00007957b0dd8cd0  push rdi
00007957b0dd8cd1  push rsi
00007957b0dd8cd2  push r8
00007957b0dd8cd4  push r9
00007957b0dd8cd6  push r10
00007957b0dd8cd8  push r11
00007957b0dd8cda  sub rsp, 0xF0
00007957b0dd8ce1  vmovaps [rsp], xmm0
00007957b0dd8ce6  vmovaps [rsp+0x10], xmm1
00007957b0dd8cec  vmovaps [rsp+0x20], xmm2
00007957b0dd8cf2  vmovaps [rsp+0x30], xmm3
00007957b0dd8cf8  vmovaps [rsp+0x40], xmm4
00007957b0dd8cfe  vmovaps [rsp+0x50], xmm5
00007957b0dd8d04  vmovaps [rsp+0x60], xmm6
00007957b0dd8d0a  vmovaps [rsp+0x70], xmm7
00007957b0dd8d10  vmovaps [rsp+0x80], xmm8
00007957b0dd8d19  vmovaps [rsp+0x90], xmm9
00007957b0dd8d22  vmovaps [rsp+0xA0], xmm11
00007957b0dd8d2b  vmovaps [rsp+0xB0], xmm12
00007957b0dd8d34  vmovaps [rsp+0xC0], xmm13
00007957b0dd8d3d  vmovaps [rsp+0xD0], xmm14
00007957b0dd8d46  vmovaps [rsp+0xE0], xmm15
00007957b0dd8d4f  sub rsp, 0x40
00007957b0dd8d53  lea rdi, [rsp]
00007957b0dd8d57  lea rsi, [rsp+0x10]
00007957b0dd8d5c  lea rdx, [rsp+0x20]
00007957b0dd8d61  lea rcx, [rsp+0x30]
00007957b0dd8d66  mov r8d, 0x00
00007957b0dd8d6c  lea r9, [r15+0x3A8]
00007957b0dd8d73  movaps [rdi], xmm10
00007957b0dd8d77  movaps [rsi], xmm12
00007957b0dd8d7b  movaps [rdx], xmm13
00007957b0dd8d7f  movaps [rcx], xmm1
00007957b0dd8d82  mov rax, 0x56E396DF1A50
00007957b0dd8d8c  call rax
00007957b0dd8d8e  movaps xmm10, [rsp]
00007957b0dd8d93  add rsp, 0x40
00007957b0dd8d97  vmovaps xmm0, [rsp]
00007957b0dd8d9c  vmovaps xmm1, [rsp+0x10]
00007957b0dd8da2  vmovaps xmm2, [rsp+0x20]
00007957b0dd8da8  vmovaps xmm3, [rsp+0x30]
00007957b0dd8dae  vmovaps xmm4, [rsp+0x40]
00007957b0dd8db4  vmovaps xmm5, [rsp+0x50]
00007957b0dd8dba  vmovaps xmm6, [rsp+0x60]
00007957b0dd8dc0  vmovaps xmm7, [rsp+0x70]
00007957b0dd8dc6  vmovaps xmm8, [rsp+0x80]
00007957b0dd8dcf  vmovaps xmm9, [rsp+0x90]
00007957b0dd8dd8  vmovaps xmm11, [rsp+0xA0]
00007957b0dd8de1  vmovaps xmm12, [rsp+0xB0]
00007957b0dd8dea  vmovaps xmm13, [rsp+0xC0]
00007957b0dd8df3  vmovaps xmm14, [rsp+0xD0]
00007957b0dd8dfc  vmovaps xmm15, [rsp+0xE0]
00007957b0dd8e05  add rsp, 0xF0
00007957b0dd8e0c  pop r11
00007957b0dd8e0e  pop r10
00007957b0dd8e10  pop r9
00007957b0dd8e12  pop r8
00007957b0dd8e14  pop rsi
00007957b0dd8e15  pop rdi
00007957b0dd8e16  pop rdx
00007957b0dd8e17  pop rcx
00007957b0dd8e18  pop rax
00007957b0dd8e19  add rsp, 0x08
00007957b0dd8e1d  jmp 0x00007957B0DD6B08
00007957b0dd8e22  call 0x00007957B0CD64F0
00007957b0dd8e27  jmp 0x00007957B0DD6B12
00007957b0dd8e2c  call 0x00007957B0CE3320
00007957b0dd8e31  jmp 0x00007957B0DD6B1C
00007957b0dd8e36  sub rsp, 0x08
00007957b0dd8e3a  push rax
00007957b0dd8e3b  push rcx
00007957b0dd8e3c  push rdx
00007957b0dd8e3d  push rdi
00007957b0dd8e3e  push rsi
00007957b0dd8e3f  push r8
00007957b0dd8e41  push r9
00007957b0dd8e43  push r10
00007957b0dd8e45  push r11
00007957b0dd8e47  sub rsp, 0xF0
00007957b0dd8e4e  vmovaps [rsp], xmm0
00007957b0dd8e53  vmovaps [rsp+0x10], xmm1
00007957b0dd8e59  vmovaps [rsp+0x20], xmm2
00007957b0dd8e5f  vmovaps [rsp+0x30], xmm3
00007957b0dd8e65  vmovaps [rsp+0x40], xmm4
00007957b0dd8e6b  vmovaps [rsp+0x50], xmm5
00007957b0dd8e71  vmovaps [rsp+0x60], xmm6
00007957b0dd8e77  vmovaps [rsp+0x70], xmm7
00007957b0dd8e7d  vmovaps [rsp+0x80], xmm9
00007957b0dd8e86  vmovaps [rsp+0x90], xmm10
00007957b0dd8e8f  vmovaps [rsp+0xA0], xmm11
00007957b0dd8e98  vmovaps [rsp+0xB0], xmm12
00007957b0dd8ea1  vmovaps [rsp+0xC0], xmm13
00007957b0dd8eaa  vmovaps [rsp+0xD0], xmm14
00007957b0dd8eb3  vmovaps [rsp+0xE0], xmm15
00007957b0dd8ebc  sub rsp, 0x40
00007957b0dd8ec0  lea rdi, [rsp]
00007957b0dd8ec4  lea rsi, [rsp+0x10]
00007957b0dd8ec9  lea rdx, [rsp+0x20]
00007957b0dd8ece  lea rcx, [rsp+0x30]
00007957b0dd8ed3  mov r8d, 0x00
00007957b0dd8ed9  lea r9, [r15+0x3A8]
00007957b0dd8ee0  movaps [rdi], xmm8
00007957b0dd8ee4  movaps [rsi], xmm7
00007957b0dd8ee7  movaps [rdx], xmm4
00007957b0dd8eea  movaps [rcx], xmm12
00007957b0dd8eee  mov rax, 0x56E396DF1A50
00007957b0dd8ef8  call rax
00007957b0dd8efa  movaps xmm8, [rsp]
00007957b0dd8eff  add rsp, 0x40
00007957b0dd8f03  vmovaps xmm0, [rsp]
00007957b0dd8f08  vmovaps xmm1, [rsp+0x10]
00007957b0dd8f0e  vmovaps xmm2, [rsp+0x20]
00007957b0dd8f14  vmovaps xmm3, [rsp+0x30]
00007957b0dd8f1a  vmovaps xmm4, [rsp+0x40]
00007957b0dd8f20  vmovaps xmm5, [rsp+0x50]
00007957b0dd8f26  vmovaps xmm6, [rsp+0x60]
00007957b0dd8f2c  vmovaps xmm7, [rsp+0x70]
00007957b0dd8f32  vmovaps xmm9, [rsp+0x80]
00007957b0dd8f3b  vmovaps xmm10, [rsp+0x90]
00007957b0dd8f44  vmovaps xmm11, [rsp+0xA0]
00007957b0dd8f4d  vmovaps xmm12, [rsp+0xB0]
00007957b0dd8f56  vmovaps xmm13, [rsp+0xC0]
00007957b0dd8f5f  vmovaps xmm14, [rsp+0xD0]
00007957b0dd8f68  vmovaps xmm15, [rsp+0xE0]
00007957b0dd8f71  add rsp, 0xF0
00007957b0dd8f78  pop r11
00007957b0dd8f7a  pop r10
00007957b0dd8f7c  pop r9
00007957b0dd8f7e  pop r8
00007957b0dd8f80  pop rsi
00007957b0dd8f81  pop rdi
00007957b0dd8f82  pop rdx
00007957b0dd8f83  pop rcx
00007957b0dd8f84  pop rax
00007957b0dd8f85  add rsp, 0x08
00007957b0dd8f89  jmp 0x00007957B0DD6B45
00007957b0dd8f8e  sub rsp, 0x08
00007957b0dd8f92  push rax
00007957b0dd8f93  push rcx
00007957b0dd8f94  push rdx
00007957b0dd8f95  push rdi
00007957b0dd8f96  push rsi
00007957b0dd8f97  push r8
00007957b0dd8f99  push r9
00007957b0dd8f9b  push r10
00007957b0dd8f9d  push r11
00007957b0dd8f9f  sub rsp, 0xF0
00007957b0dd8fa6  vmovaps [rsp], xmm0
00007957b0dd8fab  vmovaps [rsp+0x10], xmm1
00007957b0dd8fb1  vmovaps [rsp+0x20], xmm2
00007957b0dd8fb7  vmovaps [rsp+0x30], xmm3
00007957b0dd8fbd  vmovaps [rsp+0x40], xmm4
00007957b0dd8fc3  vmovaps [rsp+0x50], xmm5
00007957b0dd8fc9  vmovaps [rsp+0x60], xmm6
00007957b0dd8fcf  vmovaps [rsp+0x70], xmm8
00007957b0dd8fd5  vmovaps [rsp+0x80], xmm9
00007957b0dd8fde  vmovaps [rsp+0x90], xmm10
00007957b0dd8fe7  vmovaps [rsp+0xA0], xmm11
00007957b0dd8ff0  vmovaps [rsp+0xB0], xmm12
00007957b0dd8ff9  vmovaps [rsp+0xC0], xmm13
00007957b0dd9002  vmovaps [rsp+0xD0], xmm14
00007957b0dd900b  vmovaps [rsp+0xE0], xmm15
00007957b0dd9014  sub rsp, 0x40
00007957b0dd9018  lea rdi, [rsp]
00007957b0dd901c  lea rsi, [rsp+0x10]
00007957b0dd9021  lea rdx, [rsp+0x20]
00007957b0dd9026  lea rcx, [rsp+0x30]
00007957b0dd902b  mov r8d, 0x00
00007957b0dd9031  lea r9, [r15+0x3A8]
00007957b0dd9038  movaps [rdi], xmm7
00007957b0dd903b  movaps [rsi], xmm9
00007957b0dd903f  movaps [rdx], xmm14
00007957b0dd9043  movaps [rcx], xmm12
00007957b0dd9047  mov rax, 0x56E396DF1A50
00007957b0dd9051  call rax
00007957b0dd9053  movaps xmm7, [rsp]
00007957b0dd9057  add rsp, 0x40
00007957b0dd905b  vmovaps xmm0, [rsp]
00007957b0dd9060  vmovaps xmm1, [rsp+0x10]
00007957b0dd9066  vmovaps xmm2, [rsp+0x20]
00007957b0dd906c  vmovaps xmm3, [rsp+0x30]
00007957b0dd9072  vmovaps xmm4, [rsp+0x40]
00007957b0dd9078  vmovaps xmm5, [rsp+0x50]
00007957b0dd907e  vmovaps xmm6, [rsp+0x60]
00007957b0dd9084  vmovaps xmm8, [rsp+0x70]
00007957b0dd908a  vmovaps xmm9, [rsp+0x80]
00007957b0dd9093  vmovaps xmm10, [rsp+0x90]
00007957b0dd909c  vmovaps xmm11, [rsp+0xA0]
00007957b0dd90a5  vmovaps xmm12, [rsp+0xB0]
00007957b0dd90ae  vmovaps xmm13, [rsp+0xC0]
00007957b0dd90b7  vmovaps xmm14, [rsp+0xD0]
00007957b0dd90c0  vmovaps xmm15, [rsp+0xE0]
00007957b0dd90c9  add rsp, 0xF0
00007957b0dd90d0  pop r11
00007957b0dd90d2  pop r10
00007957b0dd90d4  pop r9
00007957b0dd90d6  pop r8
00007957b0dd90d8  pop rsi
00007957b0dd90d9  pop rdi
00007957b0dd90da  pop rdx
00007957b0dd90db  pop rcx
00007957b0dd90dc  pop rax
00007957b0dd90dd  add rsp, 0x08
00007957b0dd90e1  jmp 0x00007957B0DD6B6D
00007957b0dd90e6  sub rsp, 0x08
00007957b0dd90ea  push rax
00007957b0dd90eb  push rcx
00007957b0dd90ec  push rdx
00007957b0dd90ed  push rdi
00007957b0dd90ee  push rsi
00007957b0dd90ef  push r8
00007957b0dd90f1  push r9
00007957b0dd90f3  push r10
00007957b0dd90f5  push r11
00007957b0dd90f7  sub rsp, 0xF0
00007957b0dd90fe  vmovaps [rsp], xmm0
00007957b0dd9103  vmovaps [rsp+0x10], xmm1
00007957b0dd9109  vmovaps [rsp+0x20], xmm2
00007957b0dd910f  vmovaps [rsp+0x30], xmm3
00007957b0dd9115  vmovaps [rsp+0x40], xmm4
00007957b0dd911b  vmovaps [rsp+0x50], xmm5
00007957b0dd9121  vmovaps [rsp+0x60], xmm6
00007957b0dd9127  vmovaps [rsp+0x70], xmm7
00007957b0dd912d  vmovaps [rsp+0x80], xmm8
00007957b0dd9136  vmovaps [rsp+0x90], xmm9
00007957b0dd913f  vmovaps [rsp+0xA0], xmm10
00007957b0dd9148  vmovaps [rsp+0xB0], xmm11
00007957b0dd9151  vmovaps [rsp+0xC0], xmm13
00007957b0dd915a  vmovaps [rsp+0xD0], xmm14
00007957b0dd9163  vmovaps [rsp+0xE0], xmm15
00007957b0dd916c  sub rsp, 0x40
00007957b0dd9170  lea rdi, [rsp]
00007957b0dd9174  lea rsi, [rsp+0x10]
00007957b0dd9179  lea rdx, [rsp+0x20]
00007957b0dd917e  lea rcx, [rsp+0x30]
00007957b0dd9183  mov r8d, 0x00
00007957b0dd9189  lea r9, [r15+0x3A8]
00007957b0dd9190  movaps [rdi], xmm12
00007957b0dd9194  movaps [rsi], xmm11
00007957b0dd9198  movaps [rdx], xmm15
00007957b0dd919c  movaps [rcx], xmm14
00007957b0dd91a0  mov rax, 0x56E396DF1A50
00007957b0dd91aa  call rax
00007957b0dd91ac  movaps xmm12, [rsp]
00007957b0dd91b1  add rsp, 0x40
00007957b0dd91b5  vmovaps xmm0, [rsp]
00007957b0dd91ba  vmovaps xmm1, [rsp+0x10]
00007957b0dd91c0  vmovaps xmm2, [rsp+0x20]
00007957b0dd91c6  vmovaps xmm3, [rsp+0x30]
00007957b0dd91cc  vmovaps xmm4, [rsp+0x40]
00007957b0dd91d2  vmovaps xmm5, [rsp+0x50]
00007957b0dd91d8  vmovaps xmm6, [rsp+0x60]
00007957b0dd91de  vmovaps xmm7, [rsp+0x70]
00007957b0dd91e4  vmovaps xmm8, [rsp+0x80]
00007957b0dd91ed  vmovaps xmm9, [rsp+0x90]
00007957b0dd91f6  vmovaps xmm10, [rsp+0xA0]
00007957b0dd91ff  vmovaps xmm11, [rsp+0xB0]
00007957b0dd9208  vmovaps xmm13, [rsp+0xC0]
00007957b0dd9211  vmovaps xmm14, [rsp+0xD0]
00007957b0dd921a  vmovaps xmm15, [rsp+0xE0]
00007957b0dd9223  add rsp, 0xF0
00007957b0dd922a  pop r11
00007957b0dd922c  pop r10
00007957b0dd922e  pop r9
00007957b0dd9230  pop r8
00007957b0dd9232  pop rsi
00007957b0dd9233  pop rdi
00007957b0dd9234  pop rdx
00007957b0dd9235  pop rcx
00007957b0dd9236  pop rax
00007957b0dd9237  add rsp, 0x08
00007957b0dd923b  jmp 0x00007957B0DD6B96
00007957b0dd9240  sub rsp, 0x08
00007957b0dd9244  push rax
00007957b0dd9245  push rcx
00007957b0dd9246  push rdx
00007957b0dd9247  push rdi
00007957b0dd9248  push rsi
00007957b0dd9249  push r8
00007957b0dd924b  push r9
00007957b0dd924d  push r10
00007957b0dd924f  push r11
00007957b0dd9251  sub rsp, 0xF0
00007957b0dd9258  vmovaps [rsp], xmm0
00007957b0dd925d  vmovaps [rsp+0x10], xmm1
00007957b0dd9263  vmovaps [rsp+0x20], xmm2
00007957b0dd9269  vmovaps [rsp+0x30], xmm3
00007957b0dd926f  vmovaps [rsp+0x40], xmm4
00007957b0dd9275  vmovaps [rsp+0x50], xmm5
00007957b0dd927b  vmovaps [rsp+0x60], xmm6
00007957b0dd9281  vmovaps [rsp+0x70], xmm7
00007957b0dd9287  vmovaps [rsp+0x80], xmm8
00007957b0dd9290  vmovaps [rsp+0x90], xmm9
00007957b0dd9299  vmovaps [rsp+0xA0], xmm10
00007957b0dd92a2  vmovaps [rsp+0xB0], xmm12
00007957b0dd92ab  vmovaps [rsp+0xC0], xmm13
00007957b0dd92b4  vmovaps [rsp+0xD0], xmm14
00007957b0dd92bd  vmovaps [rsp+0xE0], xmm15
00007957b0dd92c6  sub rsp, 0x40
00007957b0dd92ca  lea rdi, [rsp]
00007957b0dd92ce  lea rsi, [rsp+0x10]
00007957b0dd92d3  lea rdx, [rsp+0x20]
00007957b0dd92d8  lea rcx, [rsp+0x30]
00007957b0dd92dd  mov r8d, 0x00
00007957b0dd92e3  lea r9, [r15+0x3A8]
00007957b0dd92ea  movaps [rdi], xmm11
00007957b0dd92ee  movaps [rsi], xmm10
00007957b0dd92f2  movaps [rdx], xmm13
00007957b0dd92f6  movaps [rcx], xmm15
00007957b0dd92fa  mov rax, 0x56E396DF1A50
00007957b0dd9304  call rax
00007957b0dd9306  movaps xmm11, [rsp]
00007957b0dd930b  add rsp, 0x40
00007957b0dd930f  vmovaps xmm0, [rsp]
00007957b0dd9314  vmovaps xmm1, [rsp+0x10]
00007957b0dd931a  vmovaps xmm2, [rsp+0x20]
00007957b0dd9320  vmovaps xmm3, [rsp+0x30]
00007957b0dd9326  vmovaps xmm4, [rsp+0x40]
00007957b0dd932c  vmovaps xmm5, [rsp+0x50]
00007957b0dd9332  vmovaps xmm6, [rsp+0x60]
00007957b0dd9338  vmovaps xmm7, [rsp+0x70]
00007957b0dd933e  vmovaps xmm8, [rsp+0x80]
00007957b0dd9347  vmovaps xmm9, [rsp+0x90]
00007957b0dd9350  vmovaps xmm10, [rsp+0xA0]
00007957b0dd9359  vmovaps xmm12, [rsp+0xB0]
00007957b0dd9362  vmovaps xmm13, [rsp+0xC0]
00007957b0dd936b  vmovaps xmm14, [rsp+0xD0]
00007957b0dd9374  vmovaps xmm15, [rsp+0xE0]
00007957b0dd937d  add rsp, 0xF0
00007957b0dd9384  pop r11
00007957b0dd9386  pop r10
00007957b0dd9388  pop r9
00007957b0dd938a  pop r8
00007957b0dd938c  pop rsi
00007957b0dd938d  pop rdi
00007957b0dd938e  pop rdx
00007957b0dd938f  pop rcx
00007957b0dd9390  pop rax
00007957b0dd9391  add rsp, 0x08
00007957b0dd9395  jmp 0x00007957B0DD6BBF
00007957b0dd939a  call 0x00007957B0CE5820
00007957b0dd939f  jmp 0x00007957B0DD6BCC
00007957b0dd93a4  call 0x00007957B0CE45A0
00007957b0dd93a9  jmp 0x00007957B0DD6BD9
00007957b0dd93ae  sub rsp, 0x08
00007957b0dd93b2  push rax
00007957b0dd93b3  push rcx
00007957b0dd93b4  push rdx
00007957b0dd93b5  push rdi
00007957b0dd93b6  push rsi
00007957b0dd93b7  push r8
00007957b0dd93b9  push r9
00007957b0dd93bb  push r10
00007957b0dd93bd  push r11
00007957b0dd93bf  sub rsp, 0xF0
00007957b0dd93c6  vmovaps [rsp], xmm0
00007957b0dd93cb  vmovaps [rsp+0x10], xmm1
00007957b0dd93d1  vmovaps [rsp+0x20], xmm2
00007957b0dd93d7  vmovaps [rsp+0x30], xmm3
00007957b0dd93dd  vmovaps [rsp+0x40], xmm4
00007957b0dd93e3  vmovaps [rsp+0x50], xmm5
00007957b0dd93e9  vmovaps [rsp+0x60], xmm6
00007957b0dd93ef  vmovaps [rsp+0x70], xmm7
00007957b0dd93f5  vmovaps [rsp+0x80], xmm8
00007957b0dd93fe  vmovaps [rsp+0x90], xmm9
00007957b0dd9407  vmovaps [rsp+0xA0], xmm11
00007957b0dd9410  vmovaps [rsp+0xB0], xmm12
00007957b0dd9419  vmovaps [rsp+0xC0], xmm13
00007957b0dd9422  vmovaps [rsp+0xD0], xmm14
00007957b0dd942b  vmovaps [rsp+0xE0], xmm15
00007957b0dd9434  sub rsp, 0x40
00007957b0dd9438  lea rdi, [rsp]
00007957b0dd943c  lea rsi, [rsp+0x10]
00007957b0dd9441  lea rdx, [rsp+0x20]
00007957b0dd9446  lea rcx, [rsp+0x30]
00007957b0dd944b  mov r8d, 0x00
00007957b0dd9451  lea r9, [r15+0x3A8]
00007957b0dd9458  movaps [rdi], xmm10
00007957b0dd945c  movaps [rsi], xmm8
00007957b0dd9460  movaps [rdx], xmm1
00007957b0dd9463  movaps [rcx], xmm13
00007957b0dd9467  mov rax, 0x56E396DF1A50
00007957b0dd9471  call rax
00007957b0dd9473  movaps xmm10, [rsp]
00007957b0dd9478  add rsp, 0x40
00007957b0dd947c  vmovaps xmm0, [rsp]
00007957b0dd9481  vmovaps xmm1, [rsp+0x10]
00007957b0dd9487  vmovaps xmm2, [rsp+0x20]
00007957b0dd948d  vmovaps xmm3, [rsp+0x30]
00007957b0dd9493  vmovaps xmm4, [rsp+0x40]
00007957b0dd9499  vmovaps xmm5, [rsp+0x50]
00007957b0dd949f  vmovaps xmm6, [rsp+0x60]
00007957b0dd94a5  vmovaps xmm7, [rsp+0x70]
00007957b0dd94ab  vmovaps xmm8, [rsp+0x80]
00007957b0dd94b4  vmovaps xmm9, [rsp+0x90]
00007957b0dd94bd  vmovaps xmm11, [rsp+0xA0]
00007957b0dd94c6  vmovaps xmm12, [rsp+0xB0]
00007957b0dd94cf  vmovaps xmm13, [rsp+0xC0]
00007957b0dd94d8  vmovaps xmm14, [rsp+0xD0]
00007957b0dd94e1  vmovaps xmm15, [rsp+0xE0]
00007957b0dd94ea  add rsp, 0xF0
00007957b0dd94f1  pop r11
00007957b0dd94f3  pop r10
00007957b0dd94f5  pop r9
00007957b0dd94f7  pop r8
00007957b0dd94f9  pop rsi
00007957b0dd94fa  pop rdi
00007957b0dd94fb  pop rdx
00007957b0dd94fc  pop rcx
00007957b0dd94fd  pop rax
00007957b0dd94fe  add rsp, 0x08
00007957b0dd9502  jmp 0x00007957B0DD6C0F
00007957b0dd9507  call 0x00007957B0CD64F0
00007957b0dd950c  jmp 0x00007957B0DD6C21
00007957b0dd9511  sub rsp, 0x08
00007957b0dd9515  push rax
00007957b0dd9516  push rcx
00007957b0dd9517  push rdx
00007957b0dd9518  push rdi
00007957b0dd9519  push rsi
00007957b0dd951a  push r8
00007957b0dd951c  push r9
00007957b0dd951e  push r10
00007957b0dd9520  push r11
00007957b0dd9522  sub rsp, 0xF0
00007957b0dd9529  vmovaps [rsp], xmm0
00007957b0dd952e  vmovaps [rsp+0x10], xmm1
00007957b0dd9534  vmovaps [rsp+0x20], xmm2
00007957b0dd953a  vmovaps [rsp+0x30], xmm3
00007957b0dd9540  vmovaps [rsp+0x40], xmm4
00007957b0dd9546  vmovaps [rsp+0x50], xmm5
00007957b0dd954c  vmovaps [rsp+0x60], xmm6
00007957b0dd9552  vmovaps [rsp+0x70], xmm7
00007957b0dd9558  vmovaps [rsp+0x80], xmm8
00007957b0dd9561  vmovaps [rsp+0x90], xmm10
00007957b0dd956a  vmovaps [rsp+0xA0], xmm11
00007957b0dd9573  vmovaps [rsp+0xB0], xmm12
00007957b0dd957c  vmovaps [rsp+0xC0], xmm13
00007957b0dd9585  vmovaps [rsp+0xD0], xmm14
00007957b0dd958e  vmovaps [rsp+0xE0], xmm15
00007957b0dd9597  sub rsp, 0x40
00007957b0dd959b  lea rdi, [rsp]
00007957b0dd959f  lea rsi, [rsp+0x10]
00007957b0dd95a4  lea rdx, [rsp+0x20]
00007957b0dd95a9  lea rcx, [rsp+0x30]
00007957b0dd95ae  mov r8d, 0x00
00007957b0dd95b4  lea r9, [r15+0x3A8]
00007957b0dd95bb  movaps [rdi], xmm9
00007957b0dd95bf  movaps [rsi], xmm7
00007957b0dd95c2  movaps [rdx], xmm14
00007957b0dd95c6  movaps [rcx], xmm13
00007957b0dd95ca  mov rax, 0x56E396DF1A50
00007957b0dd95d4  call rax
00007957b0dd95d6  movaps xmm9, [rsp]
00007957b0dd95db  add rsp, 0x40
00007957b0dd95df  vmovaps xmm0, [rsp]
00007957b0dd95e4  vmovaps xmm1, [rsp+0x10]
00007957b0dd95ea  vmovaps xmm2, [rsp+0x20]
00007957b0dd95f0  vmovaps xmm3, [rsp+0x30]
00007957b0dd95f6  vmovaps xmm4, [rsp+0x40]
00007957b0dd95fc  vmovaps xmm5, [rsp+0x50]
00007957b0dd9602  vmovaps xmm6, [rsp+0x60]
00007957b0dd9608  vmovaps xmm7, [rsp+0x70]
00007957b0dd960e  vmovaps xmm8, [rsp+0x80]
00007957b0dd9617  vmovaps xmm10, [rsp+0x90]
00007957b0dd9620  vmovaps xmm11, [rsp+0xA0]
00007957b0dd9629  vmovaps xmm12, [rsp+0xB0]
00007957b0dd9632  vmovaps xmm13, [rsp+0xC0]
00007957b0dd963b  vmovaps xmm14, [rsp+0xD0]
00007957b0dd9644  vmovaps xmm15, [rsp+0xE0]
00007957b0dd964d  add rsp, 0xF0
00007957b0dd9654  pop r11
00007957b0dd9656  pop r10
00007957b0dd9658  pop r9
00007957b0dd965a  pop r8
00007957b0dd965c  pop rsi
00007957b0dd965d  pop rdi
00007957b0dd965e  pop rdx
00007957b0dd965f  pop rcx
00007957b0dd9660  pop rax
00007957b0dd9661  add rsp, 0x08
00007957b0dd9665  jmp 0x00007957B0DD6C4F
00007957b0dd966a  sub rsp, 0x08
00007957b0dd966e  push rax
00007957b0dd966f  push rcx
00007957b0dd9670  push rdx
00007957b0dd9671  push rdi
00007957b0dd9672  push rsi
00007957b0dd9673  push r8
00007957b0dd9675  push r9
00007957b0dd9677  push r10
00007957b0dd9679  push r11
00007957b0dd967b  sub rsp, 0xF0
00007957b0dd9682  vmovaps [rsp], xmm0
00007957b0dd9687  vmovaps [rsp+0x10], xmm1
00007957b0dd968d  vmovaps [rsp+0x20], xmm2
00007957b0dd9693  vmovaps [rsp+0x30], xmm3
00007957b0dd9699  vmovaps [rsp+0x40], xmm4
00007957b0dd969f  vmovaps [rsp+0x50], xmm5
00007957b0dd96a5  vmovaps [rsp+0x60], xmm6
00007957b0dd96ab  vmovaps [rsp+0x70], xmm7
00007957b0dd96b1  vmovaps [rsp+0x80], xmm8
00007957b0dd96ba  vmovaps [rsp+0x90], xmm9
00007957b0dd96c3  vmovaps [rsp+0xA0], xmm10
00007957b0dd96cc  vmovaps [rsp+0xB0], xmm11
00007957b0dd96d5  vmovaps [rsp+0xC0], xmm12
00007957b0dd96de  vmovaps [rsp+0xD0], xmm14
00007957b0dd96e7  vmovaps [rsp+0xE0], xmm15
00007957b0dd96f0  sub rsp, 0x40
00007957b0dd96f4  lea rdi, [rsp]
00007957b0dd96f8  lea rsi, [rsp+0x10]
00007957b0dd96fd  lea rdx, [rsp+0x20]
00007957b0dd9702  lea rcx, [rsp+0x30]
00007957b0dd9707  mov r8d, 0x00
00007957b0dd970d  lea r9, [r15+0x3A8]
00007957b0dd9714  movaps [rdi], xmm13
00007957b0dd9718  movaps [rsi], xmm12
00007957b0dd971c  movaps [rdx], xmm15
00007957b0dd9720  movaps [rcx], xmm14
00007957b0dd9724  mov rax, 0x56E396DF1A50
00007957b0dd972e  call rax
00007957b0dd9730  movaps xmm13, [rsp]
00007957b0dd9735  add rsp, 0x40
00007957b0dd9739  vmovaps xmm0, [rsp]
00007957b0dd973e  vmovaps xmm1, [rsp+0x10]
00007957b0dd9744  vmovaps xmm2, [rsp+0x20]
00007957b0dd974a  vmovaps xmm3, [rsp+0x30]
00007957b0dd9750  vmovaps xmm4, [rsp+0x40]
00007957b0dd9756  vmovaps xmm5, [rsp+0x50]
00007957b0dd975c  vmovaps xmm6, [rsp+0x60]
00007957b0dd9762  vmovaps xmm7, [rsp+0x70]
00007957b0dd9768  vmovaps xmm8, [rsp+0x80]
00007957b0dd9771  vmovaps xmm9, [rsp+0x90]
00007957b0dd977a  vmovaps xmm10, [rsp+0xA0]
00007957b0dd9783  vmovaps xmm11, [rsp+0xB0]
00007957b0dd978c  vmovaps xmm12, [rsp+0xC0]
00007957b0dd9795  vmovaps xmm14, [rsp+0xD0]
00007957b0dd979e  vmovaps xmm15, [rsp+0xE0]
00007957b0dd97a7  add rsp, 0xF0
00007957b0dd97ae  pop r11
00007957b0dd97b0  pop r10
00007957b0dd97b2  pop r9
00007957b0dd97b4  pop r8
00007957b0dd97b6  pop rsi
00007957b0dd97b7  pop rdi
00007957b0dd97b8  pop rdx
00007957b0dd97b9  pop rcx
00007957b0dd97ba  pop rax
00007957b0dd97bb  add rsp, 0x08
00007957b0dd97bf  jmp 0x00007957B0DD6C7D
00007957b0dd97c4  sub rsp, 0x08
00007957b0dd97c8  push rax
00007957b0dd97c9  push rcx
00007957b0dd97ca  push rdx
00007957b0dd97cb  push rdi
00007957b0dd97cc  push rsi
00007957b0dd97cd  push r8
00007957b0dd97cf  push r9
00007957b0dd97d1  push r10
00007957b0dd97d3  push r11
00007957b0dd97d5  sub rsp, 0xF0
00007957b0dd97dc  vmovaps [rsp], xmm0
00007957b0dd97e1  vmovaps [rsp+0x10], xmm1
00007957b0dd97e7  vmovaps [rsp+0x20], xmm2
00007957b0dd97ed  vmovaps [rsp+0x30], xmm3
00007957b0dd97f3  vmovaps [rsp+0x40], xmm4
00007957b0dd97f9  vmovaps [rsp+0x50], xmm5
00007957b0dd97ff  vmovaps [rsp+0x60], xmm6
00007957b0dd9805  vmovaps [rsp+0x70], xmm7
00007957b0dd980b  vmovaps [rsp+0x80], xmm8
00007957b0dd9814  vmovaps [rsp+0x90], xmm9
00007957b0dd981d  vmovaps [rsp+0xA0], xmm10
00007957b0dd9826  vmovaps [rsp+0xB0], xmm11
00007957b0dd982f  vmovaps [rsp+0xC0], xmm12
00007957b0dd9838  vmovaps [rsp+0xD0], xmm13
00007957b0dd9841  vmovaps [rsp+0xE0], xmm15
00007957b0dd984a  sub rsp, 0x40
00007957b0dd984e  lea rdi, [rsp]
00007957b0dd9852  lea rsi, [rsp+0x10]
00007957b0dd9857  lea rdx, [rsp+0x20]
00007957b0dd985c  lea rcx, [rsp+0x30]
00007957b0dd9861  mov r8d, 0x00
00007957b0dd9867  lea r9, [r15+0x3A8]
00007957b0dd986e  movaps [rdi], xmm14
00007957b0dd9872  movaps [rsi], xmm11
00007957b0dd9876  movaps [rdx], xmm1
00007957b0dd9879  movaps [rcx], xmm15
00007957b0dd987d  mov rax, 0x56E396DF1A50
00007957b0dd9887  call rax
00007957b0dd9889  movaps xmm14, [rsp]
00007957b0dd988e  add rsp, 0x40
00007957b0dd9892  vmovaps xmm0, [rsp]
00007957b0dd9897  vmovaps xmm1, [rsp+0x10]
00007957b0dd989d  vmovaps xmm2, [rsp+0x20]
00007957b0dd98a3  vmovaps xmm3, [rsp+0x30]
00007957b0dd98a9  vmovaps xmm4, [rsp+0x40]
00007957b0dd98af  vmovaps xmm5, [rsp+0x50]
00007957b0dd98b5  vmovaps xmm6, [rsp+0x60]
00007957b0dd98bb  vmovaps xmm7, [rsp+0x70]
00007957b0dd98c1  vmovaps xmm8, [rsp+0x80]
00007957b0dd98ca  vmovaps xmm9, [rsp+0x90]
00007957b0dd98d3  vmovaps xmm10, [rsp+0xA0]
00007957b0dd98dc  vmovaps xmm11, [rsp+0xB0]
00007957b0dd98e5  vmovaps xmm12, [rsp+0xC0]
00007957b0dd98ee  vmovaps xmm13, [rsp+0xD0]
00007957b0dd98f7  vmovaps xmm15, [rsp+0xE0]
00007957b0dd9900  add rsp, 0xF0
00007957b0dd9907  pop r11
00007957b0dd9909  pop r10
00007957b0dd990b  pop r9
00007957b0dd990d  pop r8
00007957b0dd990f  pop rsi
00007957b0dd9910  pop rdi
00007957b0dd9911  pop rdx
00007957b0dd9912  pop rcx
00007957b0dd9913  pop rax
00007957b0dd9914  add rsp, 0x08
00007957b0dd9918  jmp 0x00007957B0DD6CAB
00007957b0dd991d  call 0x00007957B0CACF70
00007957b0dd9922  jmp 0x00007957B0DD6CB9
00007957b0dd9927  call 0x00007957B0C0C380
00007957b0dd992c  jmp 0x00007957B0DD6CC3
00007957b0dd9931  call 0x00007957B0C08C20
00007957b0dd9936  jmp 0x00007957B0DD6CCD
00007957b0dd993b  call 0x00007957B0C0D600
00007957b0dd9940  jmp 0x00007957B0DD6CD7
00007957b0dd9945  int3
00007957b0dd9946  nop [rax+rax*1], ax
00007957b0dd994f  nop
00007957b0dd9950  mov eax, [r15+0x48]
00007957b0dd9954  lea r14d, [eax+0x01]
00007957b0dd9959  mov [rsp+0x10], r14d
00007957b0dd995e  mov r14d, r14d
00007957b0dd9961  mov [r15+0x48], r14
00007957b0dd9965  xor eax, eax
00007957b0dd9967  mov r14d, [rsp+0x10]
00007957b0dd996c  cmp r14d, 0x1F4
00007957b0dd9973  cmc
00007957b0dd9974  lahf
00007957b0dd9975  seto al
00007957b0dd9978  mov [r15+0x108], eax
00007957b0dd997f  mov eax, [r15+0x108]
00007957b0dd9986  sahf
00007957b0dd9987  jnz 0x00007957B0DD99B9
00007957b0dd9989  cmp dword ptr [r15+0x318], 0x00
00007957b0dd9991  jz 0x00007957B0DDD2E0
00007957b0dd9997  nop [rax+rax*1], ax
00007957b0dd99a0  nop [rax+rax*1], eax
00007957b0dd99a8  mov eax, 0x410670
00007957b0dd99ad  mov [r15+0x100], rax
00007957b0dd99b4  jmp 0x00007957B0BFE110
00007957b0dd99b9  cmp dword ptr [r15+0x318], 0x00
00007957b0dd99c1  jz 0x00007957B0DD99F0
00007957b0dd99c7  nop [rax+rax*1], ax
00007957b0dd99d0  nop [rax+rax*1], eax
00007957b0dd99d8  mov eax, 0x4104EC
00007957b0dd99dd  mov [r15+0x100], rax
00007957b0dd99e4  jmp 0x00007957B0BFE110
00007957b0dd99e9  int3
00007957b0dd99ea  int3
00007957b0dd99eb  nop [rax+rax*1], eax
00007957b0dd99f0  mov rax, [r15+0x40]
00007957b0dd99f4  vxorps xmm1, xmm1, xmm1
00007957b0dd99f8  vpbroadcastq xmm1, xmm1
00007957b0dd99fd  vxorps xmm15, xmm15, xmm15
00007957b0dd9a02  vpbroadcastq xmm15, xmm15
00007957b0dd9a07  lea r14, [rax+0x30]
00007957b0dd9a0b  mov r12, [r13+r14*1]
00007957b0dd9a10  lea r14, [rax+0x38]
00007957b0dd9a14  mov r11, [r13+r14*1]
00007957b0dd9a19  movq xmm14, r12
00007957b0dd9a1e  movq xmm13, r11
00007957b0dd9a23  movq xmm14, xmm14
00007957b0dd9a28  movq xmm13, xmm13
00007957b0dd9a2d  vmovaps [rsp+0x10], xmm13
00007957b0dd9a33  movq xmm13, xmm13
00007957b0dd9a38  movaps [r15+0x270], xmm13
00007957b0dd9a40  movaps xmm13, [r15+0x160]
00007957b0dd9a48  vmovaps [rsp+0x20], xmm13
00007957b0dd9a4e  vmovaps xmm12, [rsp+0x20]
00007957b0dd9a54  por xmm13, xmm12
00007957b0dd9a59  lea r14, [rax+0x20]
00007957b0dd9a5d  mov r12, [r13+r14*1]
00007957b0dd9a62  lea r14, [rax+0x28]
00007957b0dd9a66  mov r11, [r13+r14*1]
00007957b0dd9a6b  movq xmm12, r12
00007957b0dd9a70  movq xmm11, r11
00007957b0dd9a75  movq xmm12, xmm12
00007957b0dd9a7a  movq xmm11, xmm11
00007957b0dd9a7f  movaps xmm10, [r15+0x2D0]
00007957b0dd9a87  vmovaps [rsp+0x20], xmm10
00007957b0dd9a8d  vmovaps xmm9, [rsp+0x20]
00007957b0dd9a93  por xmm10, xmm9
00007957b0dd9a98  movaps xmm9, [r15+0x300]
00007957b0dd9aa0  vmovaps [rsp+0x20], xmm9
00007957b0dd9aa6  vmovaps xmm8, [rsp+0x20]
00007957b0dd9aac  por xmm9, xmm8
00007957b0dd9ab1  movaps xmm8, [r15+0x2B0]
00007957b0dd9ab9  vmovaps [rsp+0x20], xmm8
00007957b0dd9abf  vmovaps xmm7, [rsp+0x20]
00007957b0dd9ac5  por xmm8, xmm7
00007957b0dd9aca  movaps xmm7, [r15+0x180]
00007957b0dd9ad2  vmovaps [rsp+0x20], xmm7
00007957b0dd9ad8  vmovaps xmm6, [rsp+0x20]
00007957b0dd9ade  por xmm7, xmm6
00007957b0dd9ae2  lea r14, [rax+0x10]
00007957b0dd9ae6  mov r12, [r13+r14*1]
00007957b0dd9aeb  lea r14, [rax+0x18]
00007957b0dd9aef  mov r11, [r13+r14*1]
00007957b0dd9af4  movq xmm6, r12
00007957b0dd9af9  movq xmm5, r11
00007957b0dd9afe  movq xmm6, xmm6
00007957b0dd9b02  movq xmm5, xmm5
00007957b0dd9b06  movaps xmm4, [r15+0x200]
00007957b0dd9b0e  vmovaps [rsp+0x20], xmm4
00007957b0dd9b14  vmovaps xmm3, [rsp+0x20]
00007957b0dd9b1a  por xmm4, xmm3
00007957b0dd9b1e  movaps xmm3, [r15+0x1F0]
00007957b0dd9b26  vmovaps [rsp+0x20], xmm3
00007957b0dd9b2c  vmovaps xmm2, [rsp+0x20]
00007957b0dd9b32  por xmm3, xmm2
00007957b0dd9b36  movaps xmm2, [r15+0x2E0]
00007957b0dd9b3e  vmovaps [rsp+0x20], xmm2
00007957b0dd9b44  vmovaps [rsp+0x30], xmm1
00007957b0dd9b4a  vmovaps xmm1, [rsp+0x20]
00007957b0dd9b50  por xmm2, xmm1
00007957b0dd9b54  movaps xmm1, [r15+0x2A0]
00007957b0dd9b5c  vmovaps [rsp+0x20], xmm1
00007957b0dd9b62  vmovaps [rsp+0x40], xmm15
00007957b0dd9b68  vmovaps xmm15, [rsp+0x20]
00007957b0dd9b6e  por xmm1, xmm15
00007957b0dd9b73  movaps xmm15, [r15+0x280]
00007957b0dd9b7b  vmovaps [rsp+0x20], xmm15
00007957b0dd9b81  vmovaps [rsp+0x50], xmm1
00007957b0dd9b87  vmovaps xmm1, [rsp+0x20]
00007957b0dd9b8d  por xmm15, xmm1
00007957b0dd9b92  movaps xmm1, [r15+0x1C0]
00007957b0dd9b9a  vmovaps [rsp+0x20], xmm1
00007957b0dd9ba0  vmovaps [rsp+0x60], xmm15
00007957b0dd9ba6  vmovaps xmm15, [rsp+0x20]
00007957b0dd9bac  por xmm1, xmm15
00007957b0dd9bb1  movaps xmm15, [r15+0x210]
00007957b0dd9bb9  vmovaps [rsp+0x20], xmm15
00007957b0dd9bbf  vmovaps [rsp+0x70], xmm1
00007957b0dd9bc5  vmovaps xmm1, [rsp+0x20]
00007957b0dd9bcb  por xmm15, xmm1
00007957b0dd9bd0  mov r14, [r13+rax*1]
00007957b0dd9bd5  vmovq xmm1, r14
00007957b0dd9bda  vpbroadcastq xmm1, xmm1
00007957b0dd9bdf  vmovaps [rsp+0x20], xmm1
00007957b0dd9be5  vxorps xmm1, xmm1, xmm1
00007957b0dd9be9  vpbroadcastq xmm1, xmm1
00007957b0dd9bee  mov r14, [r15+0xF8]
00007957b0dd9bf5  vmovaps [rsp+0x80], xmm1
00007957b0dd9bfe  movups xmm1, [r13+r14*1]
00007957b0dd9c04  vmovaps [rsp+0x90], xmm1
00007957b0dd9c0d  vxorps xmm1, xmm1, xmm1
00007957b0dd9c11  vpbroadcastq xmm1, xmm1
00007957b0dd9c16  lea r12, [rax+0x08]
00007957b0dd9c1a  mov rax, [r13+r12*1]
00007957b0dd9c1f  vmovaps [rsp+0xA0], xmm1
00007957b0dd9c28  movq xmm1, rax
00007957b0dd9c2d  movaps [r15+0x240], xmm1
00007957b0dd9c35  mov rax, [r15+0x50]
00007957b0dd9c39  mov [r15+0x60], rax
00007957b0dd9c3d  mov qword ptr [r15+0x58], 0x40
00007957b0dd9c45  vmovaps xmm1, [rsp+0x30]
00007957b0dd9c4b  vmovaps [rsp+0x30], xmm15
00007957b0dd9c51  vmovaps xmm15, [rsp+0x90]
00007957b0dd9c5a  vmovaps [rsp+0x90], xmm14
00007957b0dd9c63  vmovaps xmm14, [rsp+0x20]
00007957b0dd9c69  vmovaps [rsp+0x20], xmm13
00007957b0dd9c6f  vmovaps [rsp+0xB0], xmm12
00007957b0dd9c78  movaps xmm13, xmm1
00007957b0dd9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd9c87  vptest xmm12, xmm12
00007957b0dd9c8c  jnz 0x00007957B0DDA72F
00007957b0dd9c92  movaps xmm1, [r15+0x250]
00007957b0dd9c9a  vmovaps xmm15, [rsp+0x40]
00007957b0dd9ca0  vmovaps [rsp+0x40], xmm13
00007957b0dd9ca6  movaps xmm12, xmm15
00007957b0dd9caa  vfmadd231pd xmm12, xmm1, xmm14
00007957b0dd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007957b0dd9cb5  vptest xmm13, xmm13
00007957b0dd9cba  jnz 0x00007957B0DDA888
00007957b0dd9cc0  movaps xmm15, [r15+0x1E0]
00007957b0dd9cc8  vmovaps [rsp+0xC0], xmm15
00007957b0dd9cd1  vmovaps xmm13, [rsp+0xC0]
00007957b0dd9cda  por xmm15, xmm13
00007957b0dd9cdf  movaps xmm13, [r15+0x1D0]
00007957b0dd9ce7  vmovaps [rsp+0xC0], xmm13
00007957b0dd9cf0  vmovaps [rsp+0xD0], xmm1
00007957b0dd9cf9  vmovaps xmm1, [rsp+0xC0]
00007957b0dd9d02  por xmm13, xmm1
00007957b0dd9d07  movaps xmm1, [r15+0x2C0]
00007957b0dd9d0f  vmovaps [rsp+0xC0], xmm1
00007957b0dd9d18  vmovaps [rsp+0xE0], xmm15
00007957b0dd9d21  vmovaps xmm15, [rsp+0xC0]
00007957b0dd9d2a  por xmm1, xmm15
00007957b0dd9d2f  movaps xmm15, [r15+0x290]
00007957b0dd9d37  vmovaps [rsp+0xC0], xmm15
00007957b0dd9d40  vmovaps [rsp+0xF0], xmm1
00007957b0dd9d49  vmovaps xmm1, [rsp+0xC0]
00007957b0dd9d52  por xmm15, xmm1
00007957b0dd9d57  movaps xmm1, [r15+0x260]
00007957b0dd9d5f  vmovaps [rsp+0xC0], xmm1
00007957b0dd9d68  vmovaps [rsp+0x100], xmm15
00007957b0dd9d71  vmovaps xmm15, [rsp+0xC0]
00007957b0dd9d7a  por xmm1, xmm15
00007957b0dd9d7f  vmovaps xmm15, [rsp+0xD0]
00007957b0dd9d88  vmovaps [rsp+0xC0], xmm1
00007957b0dd9d91  vmovaps xmm1, [rsp+0xD0]
00007957b0dd9d9a  por xmm15, xmm1
00007957b0dd9d9f  lea r12, [r14+0xC0]
00007957b0dd9da6  movups xmm1, [r13+r12*1]
00007957b0dd9dac  mov [rsp+0xD0], rax
00007957b0dd9db4  xor eax, eax
00007957b0dd9db6  mov r12d, 0x40
00007957b0dd9dbc  mov r11d, 0x200
00007957b0dd9dc2  cmp r12, r11
00007957b0dd9dc5  cmc
00007957b0dd9dc6  lahf
00007957b0dd9dc7  seto al
00007957b0dd9dca  mov [r15+0x108], eax
00007957b0dd9dd1  vmovaps [rsp+0x110], xmm1
00007957b0dd9dda  vmovaps xmm1, [rsp+0x80]
00007957b0dd9de3  vmovaps [rsp+0x80], xmm15
00007957b0dd9dec  vmovaps xmm15, [rsp+0x110]
00007957b0dd9df5  vmovaps [rsp+0x110], xmm13
00007957b0dd9dfe  vmovaps [rsp+0x120], xmm12
00007957b0dd9e07  movaps xmm13, xmm1
00007957b0dd9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd9e16  vptest xmm12, xmm12
00007957b0dd9e1b  jnz 0x00007957B0DDA9EB
00007957b0dd9e21  lea rax, [r14+0xB0]
00007957b0dd9e28  movups xmm1, [r13+rax*1]
00007957b0dd9e2e  vmovaps xmm15, [rsp+0xA0]
00007957b0dd9e37  vmovaps [rsp+0xA0], xmm13
00007957b0dd9e40  movaps xmm12, xmm15
00007957b0dd9e44  vfmadd231pd xmm12, xmm1, xmm14
00007957b0dd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007957b0dd9e4f  vptest xmm13, xmm13
00007957b0dd9e54  jnz 0x00007957B0DDAB4E
00007957b0dd9e5a  vmovaps xmm1, [rsp+0x30]
00007957b0dd9e60  vmovaps xmm15, [rsp+0x30]
00007957b0dd9e66  por xmm1, xmm15
00007957b0dd9e6b  movaps [r15+0x210], xmm1
00007957b0dd9e73  vmovaps xmm15, [rsp+0x70]
00007957b0dd9e79  vmovaps xmm14, [rsp+0x70]
00007957b0dd9e7f  por xmm15, xmm14
00007957b0dd9e84  movaps [r15+0x1C0], xmm15
00007957b0dd9e8c  vmovaps xmm14, [rsp+0x60]
00007957b0dd9e92  vmovaps xmm13, [rsp+0x60]
00007957b0dd9e98  por xmm14, xmm13
00007957b0dd9e9d  movaps [r15+0x280], xmm14
00007957b0dd9ea5  vmovaps xmm13, [rsp+0x50]
00007957b0dd9eab  vmovaps [rsp+0x30], xmm1
00007957b0dd9eb1  vmovaps xmm1, [rsp+0x50]
00007957b0dd9eb7  por xmm13, xmm1
00007957b0dd9ebc  movaps [r15+0x2A0], xmm13
00007957b0dd9ec4  vmovaps [rsp+0x50], xmm2
00007957b0dd9eca  vmovaps xmm1, [rsp+0x50]
00007957b0dd9ed0  por xmm2, xmm1
00007957b0dd9ed4  movaps [r15+0x2E0], xmm2
00007957b0dd9edc  vmovaps [rsp+0x50], xmm3
00007957b0dd9ee2  vmovaps xmm1, [rsp+0x50]
00007957b0dd9ee8  por xmm3, xmm1
00007957b0dd9eec  movaps [r15+0x1F0], xmm3
00007957b0dd9ef4  vmovaps xmm1, [rsp+0x80]
00007957b0dd9efd  vmovaps [rsp+0x50], xmm15
00007957b0dd9f03  vmovaps xmm15, [rsp+0x80]
00007957b0dd9f0c  por xmm1, xmm15
00007957b0dd9f11  movaps [r15+0x250], xmm1
00007957b0dd9f19  vmovaps xmm1, [rsp+0xC0]
00007957b0dd9f22  vmovaps xmm15, [rsp+0xC0]
00007957b0dd9f2b  por xmm1, xmm15
00007957b0dd9f30  movaps [r15+0x260], xmm1
00007957b0dd9f38  vmovaps xmm15, [rsp+0x100]
00007957b0dd9f41  vmovaps [rsp+0x60], xmm1
00007957b0dd9f47  vmovaps xmm1, [rsp+0x100]
00007957b0dd9f50  por xmm15, xmm1
00007957b0dd9f55  movaps [r15+0x290], xmm15
00007957b0dd9f5d  vmovaps xmm1, [rsp+0xF0]
00007957b0dd9f66  vmovaps [rsp+0x70], xmm15
00007957b0dd9f6c  vmovaps xmm15, [rsp+0xF0]
00007957b0dd9f75  por xmm1, xmm15
00007957b0dd9f7a  movaps [r15+0x2C0], xmm1
00007957b0dd9f82  movq xmm15, qword ptr [r15+0x240]
00007957b0dd9f8b  vmovaps [rsp+0x80], xmm15
00007957b0dd9f94  vpermilpd xmm15, xmm15, 0x00
00007957b0dd9f9a  vmovaps [rsp+0xC0], xmm1
00007957b0dd9fa3  vmovaps xmm1, [rsp+0x40]
00007957b0dd9fa9  vmovaps [rsp+0x40], xmm15
00007957b0dd9faf  vmovaps xmm15, [rsp+0x30]
00007957b0dd9fb5  vmovaps [rsp+0x30], xmm14
00007957b0dd9fbb  vmovaps xmm14, [rsp+0x40]
00007957b0dd9fc1  vmovaps [rsp+0x40], xmm13
00007957b0dd9fc7  vmovaps [rsp+0xF0], xmm12
00007957b0dd9fd0  movaps xmm13, xmm1
00007957b0dd9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007957b0dd9fdf  vptest xmm12, xmm12
00007957b0dd9fe4  jnz 0x00007957B0DDACA7
00007957b0dd9fea  vmovaps xmm1, [rsp+0x80]
00007957b0dd9ff3  vpermilpd xmm1, xmm1, 0x00
00007957b0dd9ff9  vmovaps xmm15, [rsp+0xA0]
00007957b0dda002  movaps xmm14, xmm15
00007957b0dda006  vfmadd231pd xmm14, xmm2, xmm1
00007957b0dda00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007957b0dda011  vptest xmm12, xmm12
00007957b0dda016  jnz 0x00007957B0DDAE00
00007957b0dda01c  vmovaps xmm1, [rsp+0x80]
00007957b0dda025  vpermilpd xmm1, xmm1, 0x00
00007957b0dda02b  vmovaps xmm15, [rsp+0x120]
00007957b0dda034  vmovaps xmm12, [rsp+0x50]
00007957b0dda03a  vmovaps [rsp+0x50], xmm14
00007957b0dda040  movaps xmm2, xmm15
00007957b0dda044  vfmadd231pd xmm2, xmm12, xmm1
00007957b0dda049  vcmppd xmm14, xmm2, xmm2, 0x03
00007957b0dda04e  vptest xmm14, xmm14
00007957b0dda053  jnz 0x00007957B0DDAF58
00007957b0dda059  vmovaps xmm1, [rsp+0x110]
00007957b0dda062  vmovaps xmm15, [rsp+0x110]
00007957b0dda06b  por xmm1, xmm15
00007957b0dda070  movaps [r15+0x1D0], xmm1
00007957b0dda078  vmovaps xmm15, [rsp+0x80]
00007957b0dda081  vpermilpd xmm15, xmm15, 0x00
00007957b0dda087  vmovaps xmm14, [rsp+0xF0]
00007957b0dda090  vmovaps [rsp+0x80], xmm1
00007957b0dda099  movaps xmm12, xmm14
00007957b0dda09d  vfmadd231pd xmm12, xmm3, xmm15
00007957b0dda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007957b0dda0a8  vptest xmm1, xmm1
00007957b0dda0ad  jnz 0x00007957B0DDB0AF
00007957b0dda0b3  vmovaps [rsp+0xA0], xmm4
00007957b0dda0bc  vmovaps xmm1, [rsp+0xA0]
00007957b0dda0c5  por xmm4, xmm1
00007957b0dda0c9  movaps [r15+0x200], xmm4
00007957b0dda0d1  vmovaps xmm1, [rsp+0xE0]
00007957b0dda0da  vmovaps xmm15, [rsp+0xE0]
00007957b0dda0e3  por xmm1, xmm15
00007957b0dda0e8  movaps [r15+0x1E0], xmm1
00007957b0dda0f0  vmovaps [rsp+0xA0], xmm8
00007957b0dda0f9  vmovaps xmm1, [rsp+0xA0]
00007957b0dda102  por xmm8, xmm1
00007957b0dda107  movaps [r15+0x2B0], xmm8
00007957b0dda10f  vmovaps [rsp+0xA0], xmm9
00007957b0dda118  vmovaps xmm1, [rsp+0xA0]
00007957b0dda121  por xmm9, xmm1
00007957b0dda126  movaps [r15+0x300], xmm9
00007957b0dda12e  vmovaps [rsp+0xA0], xmm6
00007957b0dda137  vpermilpd xmm6, xmm6, 0x00
00007957b0dda13d  vmovaps xmm14, [rsp+0x60]
00007957b0dda143  movaps xmm9, xmm13
00007957b0dda147  vfmadd231pd xmm9, xmm14, xmm6
00007957b0dda14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007957b0dda152  vptest xmm3, xmm3
00007957b0dda157  jnz 0x00007957B0DDB208
00007957b0dda15d  vmovaps xmm14, [rsp+0xA0]
00007957b0dda166  vpermilpd xmm14, xmm14, 0x00
00007957b0dda16c  vmovaps xmm13, [rsp+0x50]
00007957b0dda172  vmovaps xmm6, [rsp+0xC0]
00007957b0dda17b  vmovaps [rsp+0x50], xmm1
00007957b0dda181  movaps xmm3, xmm13
00007957b0dda185  vfmadd231pd xmm3, xmm6, xmm14
00007957b0dda18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007957b0dda18f  vptest xmm1, xmm1
00007957b0dda194  jnz 0x00007957B0DDB361
00007957b0dda19a  vmovaps xmm1, [rsp+0xA0]
00007957b0dda1a3  vpermilpd xmm1, xmm1, 0x00
00007957b0dda1a9  vmovaps xmm14, [rsp+0x30]
00007957b0dda1af  movaps xmm6, xmm2
00007957b0dda1b2  vfmadd231pd xmm6, xmm14, xmm1
00007957b0dda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007957b0dda1bc  vptest xmm13, xmm13
00007957b0dda1c1  jnz 0x00007957B0DDB4B8
00007957b0dda1c7  vmovaps xmm1, [rsp+0xA0]
00007957b0dda1d0  vpermilpd xmm1, xmm1, 0x00
00007957b0dda1d6  vmovaps xmm14, [rsp+0x80]
00007957b0dda1df  movaps xmm13, xmm12
00007957b0dda1e3  vfmadd231pd xmm13, xmm14, xmm1
00007957b0dda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007957b0dda1ee  vptest xmm2, xmm2
00007957b0dda1f3  jnz 0x00007957B0DDB60E
00007957b0dda1f9  vmovaps [rsp+0x30], xmm7
00007957b0dda1ff  vmovaps xmm1, [rsp+0x30]
00007957b0dda205  por xmm7, xmm1
00007957b0dda209  movaps [r15+0x180], xmm7
00007957b0dda211  vmovaps [rsp+0x30], xmm10
00007957b0dda217  vmovaps xmm1, [rsp+0x30]
00007957b0dda21d  por xmm10, xmm1
00007957b0dda222  movaps [r15+0x2D0], xmm10
00007957b0dda22a  vmovaps [rsp+0x30], xmm5
00007957b0dda230  vpermilpd xmm5, xmm5, 0x00
00007957b0dda236  vmovaps xmm14, [rsp+0x50]
00007957b0dda23c  movaps xmm12, xmm3
00007957b0dda240  vfmadd231pd xmm12, xmm14, xmm5
00007957b0dda245  vcmppd xmm10, xmm12, xmm12, 0x03
00007957b0dda24b  vptest xmm10, xmm10
00007957b0dda250  jnz 0x00007957B0DDB767
00007957b0dda256  vmovaps xmm14, [rsp+0x30]
00007957b0dda25c  vpermilpd xmm14, xmm14, 0x00
00007957b0dda262  movaps xmm10, xmm9
00007957b0dda266  vfmadd231pd xmm10, xmm7, xmm14
00007957b0dda26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007957b0dda271  vptest xmm5, xmm5
00007957b0dda276  jnz 0x00007957B0DDB8BF
00007957b0dda27c  lea rax, [r14+0x80]
00007957b0dda283  movups xmm14, [r13+rax*1]
00007957b0dda289  movaps [r15+0x2F0], xmm14
00007957b0dda291  vmovaps xmm9, [rsp+0x30]
00007957b0dda297  vpermilpd xmm9, xmm9, 0x00
00007957b0dda29d  vmovaps xmm7, [rsp+0x70]
00007957b0dda2a3  movaps xmm5, xmm6
00007957b0dda2a6  vfmadd231pd xmm5, xmm7, xmm9
00007957b0dda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007957b0dda2b0  vptest xmm3, xmm3
00007957b0dda2b5  jnz 0x00007957B0DDBA22
00007957b0dda2bb  vmovaps xmm9, [rsp+0x30]
00007957b0dda2c1  vpermilpd xmm9, xmm9, 0x00
00007957b0dda2c7  movaps xmm7, xmm13
00007957b0dda2cb  vfmadd231pd xmm7, xmm1, xmm9
00007957b0dda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007957b0dda2d5  vptest xmm6, xmm6
00007957b0dda2da  jnz 0x00007957B0DDBB78
00007957b0dda2e0  vmovaps xmm1, [rsp+0x20]
00007957b0dda2e6  vmovaps xmm13, [rsp+0x20]
00007957b0dda2ec  por xmm1, xmm13
00007957b0dda2f1  movaps [r15+0x160], xmm1
00007957b0dda2f9  lea rax, [r14+0x40]
00007957b0dda2fd  movups xmm13, [r13+rax*1]
00007957b0dda303  lea rax, [r14+0x50]
00007957b0dda307  movups xmm9, [r13+rax*1]
00007957b0dda30d  movaps [r15+0x1B0], xmm13
00007957b0dda315  movaps [r15+0x1A0], xmm9
00007957b0dda31d  movaps xmm6, [r15+0x190]
00007957b0dda325  vmovaps xmm3, [rsp+0xB0]
00007957b0dda32e  vpermilpd xmm3, xmm3, 0x00
00007957b0dda334  vmovaps [rsp+0x20], xmm1
00007957b0dda33a  movaps xmm2, xmm12
00007957b0dda33e  vfmadd231pd xmm2, xmm6, xmm3
00007957b0dda343  vcmppd xmm1, xmm2, xmm2, 0x03
00007957b0dda348  vptest xmm1, xmm1
00007957b0dda34d  jnz 0x00007957B0DDBCE3
00007957b0dda353  vmovaps xmm1, [rsp+0xB0]
00007957b0dda35c  vpermilpd xmm1, xmm1, 0x00
00007957b0dda362  vmovaps xmm12, [rsp+0x20]
00007957b0dda368  movaps xmm6, xmm10
00007957b0dda36c  vfmadd231pd xmm6, xmm12, xmm1
00007957b0dda371  vcmppd xmm3, xmm6, xmm6, 0x03
00007957b0dda376  vptest xmm3, xmm3
00007957b0dda37b  jnz 0x00007957B0DDBE39
00007957b0dda381  vmovaps xmm1, [rsp+0xB0]
00007957b0dda38a  vpermilpd xmm1, xmm1, 0x00
00007957b0dda390  vmovaps xmm12, [rsp+0x40]
00007957b0dda396  movaps xmm10, xmm5
00007957b0dda39a  vfmadd231pd xmm10, xmm12, xmm1
00007957b0dda39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007957b0dda3a5  vptest xmm3, xmm3
00007957b0dda3aa  jnz 0x00007957B0DDBF90
00007957b0dda3b0  vmovaps xmm1, [rsp+0xB0]
00007957b0dda3b9  vpermilpd xmm1, xmm1, 0x00
00007957b0dda3bf  movaps xmm12, xmm7
00007957b0dda3c3  vfmadd231pd xmm12, xmm15, xmm1
00007957b0dda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007957b0dda3ce  vptest xmm5, xmm5
00007957b0dda3d3  jnz 0x00007957B0DDC0E8
00007957b0dda3d9  lea rax, [r14+0x60]
00007957b0dda3dd  movups xmm1, [r13+rax*1]
00007957b0dda3e3  lea rax, [r14+0x70]
00007957b0dda3e7  movups xmm15, [r13+rax*1]
00007957b0dda3ed  movaps [r15+0x150], xmm1
00007957b0dda3f5  movaps [r15+0x120], xmm15
00007957b0dda3fd  vmovaps [rsp+0x20], xmm11
00007957b0dda403  vpermilpd xmm11, xmm11, 0x00
00007957b0dda409  movaps xmm7, xmm2
00007957b0dda40c  vfmadd231pd xmm7, xmm9, xmm11
00007957b0dda411  vcmppd xmm5, xmm7, xmm7, 0x03
00007957b0dda416  vptest xmm5, xmm5
00007957b0dda41b  jnz 0x00007957B0DDC254
00007957b0dda421  vmovaps xmm11, [rsp+0x20]
00007957b0dda427  vpermilpd xmm11, xmm11, 0x00
00007957b0dda42d  movaps xmm9, xmm6
00007957b0dda431  vfmadd231pd xmm9, xmm1, xmm11
00007957b0dda436  vcmppd xmm5, xmm9, xmm9, 0x03
00007957b0dda43c  vptest xmm5, xmm5
00007957b0dda441  jnz 0x00007957B0DDC3AB
00007957b0dda447  vmovaps xmm1, [rsp+0x20]
00007957b0dda44d  vpermilpd xmm1, xmm1, 0x00
00007957b0dda453  movaps xmm11, xmm10
00007957b0dda457  vfmadd231pd xmm11, xmm8, xmm1
00007957b0dda45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007957b0dda462  vptest xmm6, xmm6
00007957b0dda467  jnz 0x00007957B0DDC503
00007957b0dda46d  vmovaps xmm1, [rsp+0x20]
00007957b0dda473  vpermilpd xmm1, xmm1, 0x00
00007957b0dda479  movaps xmm10, xmm12
00007957b0dda47d  vfmadd231pd xmm10, xmm13, xmm1
00007957b0dda482  vcmppd xmm8, xmm10, xmm10, 0x03
00007957b0dda488  vptest xmm8, xmm8
00007957b0dda48d  jnz 0x00007957B0DDC65C
00007957b0dda493  lea rax, [r14+0x20]
00007957b0dda497  movups xmm1, [r13+rax*1]
00007957b0dda49d  lea rax, [r14+0x30]
00007957b0dda4a1  movups xmm13, [r13+rax*1]
00007957b0dda4a7  vmovaps xmm12, [rsp+0x90]
00007957b0dda4b0  vpermilpd xmm12, xmm12, 0x00
00007957b0dda4b6  movaps xmm8, xmm7
00007957b0dda4ba  vfmadd231pd xmm8, xmm4, xmm12
00007957b0dda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007957b0dda4c5  vptest xmm6, xmm6
00007957b0dda4ca  jnz 0x00007957B0DDC7C9
00007957b0dda4d0  vmovaps xmm12, [rsp+0x90]
00007957b0dda4d9  vpermilpd xmm12, xmm12, 0x00
00007957b0dda4df  movaps xmm7, xmm9
00007957b0dda4e3  vfmadd231pd xmm7, xmm14, xmm12
00007957b0dda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007957b0dda4ed  vptest xmm6, xmm6
00007957b0dda4f2  jnz 0x00007957B0DDC921
00007957b0dda4f8  vmovaps xmm14, [rsp+0x90]
00007957b0dda501  vpermilpd xmm14, xmm14, 0x00
00007957b0dda507  movaps xmm12, xmm11
00007957b0dda50b  vfmadd231pd xmm12, xmm15, xmm14
00007957b0dda510  vcmppd xmm9, xmm12, xmm12, 0x03
00007957b0dda516  vptest xmm9, xmm9
00007957b0dda51b  jnz 0x00007957B0DDCA79
00007957b0dda521  vmovaps xmm15, [rsp+0x90]
00007957b0dda52a  vpermilpd xmm15, xmm15, 0x00
00007957b0dda530  movaps xmm11, xmm10
00007957b0dda534  vfmadd231pd xmm11, xmm13, xmm15
00007957b0dda539  vcmppd xmm14, xmm11, xmm11, 0x03
00007957b0dda53f  vptest xmm14, xmm14
00007957b0dda544  jnz 0x00007957B0DDCBD3
00007957b0dda54a  lea rax, [r14+0x90]
00007957b0dda551  movups xmm15, [r13+rax*1]
00007957b0dda557  lea rax, [r14+0xA0]
00007957b0dda55e  movups xmm14, [r13+rax*1]
00007957b0dda564  movaps [r15+0x140], xmm15
00007957b0dda56c  movaps [r15+0x130], xmm14
00007957b0dda574  vmovaps xmm13, [rsp+0x10]
00007957b0dda57a  vpermilpd xmm13, xmm13, 0x00
00007957b0dda580  movaps xmm10, xmm8
00007957b0dda584  vfmadd231pd xmm10, xmm1, xmm13
00007957b0dda589  vcmppd xmm9, xmm10, xmm10, 0x03
00007957b0dda58f  vptest xmm9, xmm9
00007957b0dda594  jnz 0x00007957B0DDCD41
00007957b0dda59a  movaps [r15+0x220], xmm10
00007957b0dda5a2  lea rax, [r14+0x10]
00007957b0dda5a6  movups xmm1, [r13+rax*1]
00007957b0dda5ac  movaps [r15+0x240], xmm1
00007957b0dda5b4  vmovaps xmm13, [rsp+0x10]
00007957b0dda5ba  vpermilpd xmm13, xmm13, 0x00
00007957b0dda5c0  movaps xmm9, xmm7
00007957b0dda5c4  vfmadd231pd xmm9, xmm14, xmm13
00007957b0dda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007957b0dda5cf  vptest xmm8, xmm8
00007957b0dda5d4  jnz 0x00007957B0DDCEA4
00007957b0dda5da  movaps [r15+0x110], xmm9
00007957b0dda5e2  vmovaps xmm14, [rsp+0x10]
00007957b0dda5e8  vpermilpd xmm14, xmm14, 0x00
00007957b0dda5ee  movaps xmm13, xmm12
00007957b0dda5f2  vfmadd231pd xmm13, xmm15, xmm14
00007957b0dda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007957b0dda5fd  vptest xmm8, xmm8
00007957b0dda602  jnz 0x00007957B0DDCFFD
00007957b0dda608  movaps [r15+0x170], xmm13
00007957b0dda610  vmovaps xmm15, [rsp+0x10]
00007957b0dda616  vpermilpd xmm15, xmm15, 0x00
00007957b0dda61c  movaps xmm14, xmm11
00007957b0dda620  vfmadd231pd xmm14, xmm1, xmm15
00007957b0dda625  vcmppd xmm12, xmm14, xmm14, 0x03
00007957b0dda62b  vptest xmm12, xmm12
00007957b0dda630  jnz 0x00007957B0DDD157
00007957b0dda636  movaps [r15+0x230], xmm14
00007957b0dda63e  mov rax, [rsp+0xD0]
00007957b0dda646  movups [r13+rax*1], xmm9
00007957b0dda64c  lea r14, [rax+0x10]
00007957b0dda650  movups [r13+r14*1], xmm13
00007957b0dda656  lea r14, [rax+0x20]
00007957b0dda65a  movups [r13+r14*1], xmm10
00007957b0dda660  lea r14, [rax+0x30]
00007957b0dda664  movups [r13+r14*1], xmm14
00007957b0dda66a  mov eax, [r15+0x108]
00007957b0dda671  sahf
00007957b0dda672  jnz 0x00007957B0DDA6A4
00007957b0dda674  cmp dword ptr [r15+0x318], 0x00
00007957b0dda67c  jz 0x00007957B0DD9950
00007957b0dda682  nop [rax+rax*1], ax
00007957b0dda68b  nop [rax+rax*1], eax
00007957b0dda693  mov eax, 0x410664
00007957b0dda698  mov [r15+0x100], rax
00007957b0dda69f  jmp 0x00007957B0BFE110
00007957b0dda6a4  cmp dword ptr [r15+0x318], 0x00
00007957b0dda6ac  jz 0x00007957B0DD6050
00007957b0dda6b2  nop [rax+rax*1], ax
00007957b0dda6bb  nop [rax+rax*1], eax
00007957b0dda6c3  mov eax, 0x4104F0
00007957b0dda6c8  mov [r15+0x100], rax
00007957b0dda6cf  jmp 0x00007957B0BFE110
00007957b0dda6d4  int3
00007957b0dda6d5  call 0x00007957B0CE27E0
00007957b0dda6da  jmp 0x00007957B0DD9A10
00007957b0dda6df  call 0x00007957B0CE1570
00007957b0dda6e4  jmp 0x00007957B0DD9A19
00007957b0dda6e9  call 0x00007957B0CE27E0
00007957b0dda6ee  jmp 0x00007957B0DD9A62
00007957b0dda6f3  call 0x00007957B0CE1570
00007957b0dda6f8  jmp 0x00007957B0DD9A6B
00007957b0dda6fd  call 0x00007957B0CE27E0
00007957b0dda702  jmp 0x00007957B0DD9AEB
00007957b0dda707  call 0x00007957B0CE1570
00007957b0dda70c  jmp 0x00007957B0DD9AF4
00007957b0dda711  call 0x00007957B0C0DC20
00007957b0dda716  jmp 0x00007957B0DD9BD5
00007957b0dda71b  call 0x00007957B0CD64F0
00007957b0dda720  jmp 0x00007957B0DD9C04
00007957b0dda725  call 0x00007957B0CB47C0
00007957b0dda72a  jmp 0x00007957B0DD9C1F
00007957b0dda72f  sub rsp, 0x08
00007957b0dda733  push rax
00007957b0dda734  push rcx
00007957b0dda735  push rdx
00007957b0dda736  push rdi
00007957b0dda737  push rsi
00007957b0dda738  push r8
00007957b0dda73a  push r9
00007957b0dda73c  push r10
00007957b0dda73e  push r11
00007957b0dda740  sub rsp, 0xF0
00007957b0dda747  vmovaps [rsp], xmm0
00007957b0dda74c  vmovaps [rsp+0x10], xmm1
00007957b0dda752  vmovaps [rsp+0x20], xmm2
00007957b0dda758  vmovaps [rsp+0x30], xmm3
00007957b0dda75e  vmovaps [rsp+0x40], xmm4
00007957b0dda764  vmovaps [rsp+0x50], xmm5
00007957b0dda76a  vmovaps [rsp+0x60], xmm6
00007957b0dda770  vmovaps [rsp+0x70], xmm7
00007957b0dda776  vmovaps [rsp+0x80], xmm8
00007957b0dda77f  vmovaps [rsp+0x90], xmm9
00007957b0dda788  vmovaps [rsp+0xA0], xmm10
00007957b0dda791  vmovaps [rsp+0xB0], xmm11
00007957b0dda79a  vmovaps [rsp+0xC0], xmm12
00007957b0dda7a3  vmovaps [rsp+0xD0], xmm14
00007957b0dda7ac  vmovaps [rsp+0xE0], xmm15
00007957b0dda7b5  sub rsp, 0x40
00007957b0dda7b9  lea rdi, [rsp]
00007957b0dda7bd  lea rsi, [rsp+0x10]
00007957b0dda7c2  lea rdx, [rsp+0x20]
00007957b0dda7c7  lea rcx, [rsp+0x30]
00007957b0dda7cc  mov r8d, 0x00
00007957b0dda7d2  lea r9, [r15+0x3A8]
00007957b0dda7d9  movaps [rdi], xmm13
00007957b0dda7dd  movaps [rsi], xmm1
00007957b0dda7e0  movaps [rdx], xmm15
00007957b0dda7e4  movaps [rcx], xmm14
00007957b0dda7e8  mov rax, 0x56E396DF1A50
00007957b0dda7f2  call rax
00007957b0dda7f4  movaps xmm13, [rsp]
00007957b0dda7f9  add rsp, 0x40
00007957b0dda7fd  vmovaps xmm0, [rsp]
00007957b0dda802  vmovaps xmm1, [rsp+0x10]
00007957b0dda808  vmovaps xmm2, [rsp+0x20]
00007957b0dda80e  vmovaps xmm3, [rsp+0x30]
00007957b0dda814  vmovaps xmm4, [rsp+0x40]
00007957b0dda81a  vmovaps xmm5, [rsp+0x50]
00007957b0dda820  vmovaps xmm6, [rsp+0x60]
00007957b0dda826  vmovaps xmm7, [rsp+0x70]
00007957b0dda82c  vmovaps xmm8, [rsp+0x80]
00007957b0dda835  vmovaps xmm9, [rsp+0x90]
00007957b0dda83e  vmovaps xmm10, [rsp+0xA0]
00007957b0dda847  vmovaps xmm11, [rsp+0xB0]
00007957b0dda850  vmovaps xmm12, [rsp+0xC0]
00007957b0dda859  vmovaps xmm14, [rsp+0xD0]
00007957b0dda862  vmovaps xmm15, [rsp+0xE0]
00007957b0dda86b  add rsp, 0xF0
00007957b0dda872  pop r11
00007957b0dda874  pop r10
00007957b0dda876  pop r9
00007957b0dda878  pop r8
00007957b0dda87a  pop rsi
00007957b0dda87b  pop rdi
00007957b0dda87c  pop rdx
00007957b0dda87d  pop rcx
00007957b0dda87e  pop rax
00007957b0dda87f  add rsp, 0x08
00007957b0dda883  jmp 0x00007957B0DD9C92
00007957b0dda888  sub rsp, 0x08
00007957b0dda88c  push rax
00007957b0dda88d  push rcx
00007957b0dda88e  push rdx
00007957b0dda88f  push rdi
00007957b0dda890  push rsi
00007957b0dda891  push r8
00007957b0dda893  push r9
00007957b0dda895  push r10
00007957b0dda897  push r11
00007957b0dda899  sub rsp, 0xF0
00007957b0dda8a0  vmovaps [rsp], xmm0
00007957b0dda8a5  vmovaps [rsp+0x10], xmm1
00007957b0dda8ab  vmovaps [rsp+0x20], xmm2
00007957b0dda8b1  vmovaps [rsp+0x30], xmm3
00007957b0dda8b7  vmovaps [rsp+0x40], xmm4
00007957b0dda8bd  vmovaps [rsp+0x50], xmm5
00007957b0dda8c3  vmovaps [rsp+0x60], xmm6
00007957b0dda8c9  vmovaps [rsp+0x70], xmm7
00007957b0dda8cf  vmovaps [rsp+0x80], xmm8
00007957b0dda8d8  vmovaps [rsp+0x90], xmm9
00007957b0dda8e1  vmovaps [rsp+0xA0], xmm10
00007957b0dda8ea  vmovaps [rsp+0xB0], xmm11
00007957b0dda8f3  vmovaps [rsp+0xC0], xmm13
00007957b0dda8fc  vmovaps [rsp+0xD0], xmm14
00007957b0dda905  vmovaps [rsp+0xE0], xmm15
00007957b0dda90e  sub rsp, 0x40
00007957b0dda912  lea rdi, [rsp]
00007957b0dda916  lea rsi, [rsp+0x10]
00007957b0dda91b  lea rdx, [rsp+0x20]
00007957b0dda920  lea rcx, [rsp+0x30]
00007957b0dda925  mov r8d, 0x00
00007957b0dda92b  lea r9, [r15+0x3A8]
00007957b0dda932  movaps [rdi], xmm12
00007957b0dda936  movaps [rsi], xmm15
00007957b0dda93a  movaps [rdx], xmm1
00007957b0dda93d  movaps [rcx], xmm14
00007957b0dda941  mov rax, 0x56E396DF1A50
00007957b0dda94b  call rax
00007957b0dda94d  movaps xmm12, [rsp]
00007957b0dda952  add rsp, 0x40
00007957b0dda956  vmovaps xmm0, [rsp]
00007957b0dda95b  vmovaps xmm1, [rsp+0x10]
00007957b0dda961  vmovaps xmm2, [rsp+0x20]
00007957b0dda967  vmovaps xmm3, [rsp+0x30]
00007957b0dda96d  vmovaps xmm4, [rsp+0x40]
00007957b0dda973  vmovaps xmm5, [rsp+0x50]
00007957b0dda979  vmovaps xmm6, [rsp+0x60]
00007957b0dda97f  vmovaps xmm7, [rsp+0x70]
00007957b0dda985  vmovaps xmm8, [rsp+0x80]
00007957b0dda98e  vmovaps xmm9, [rsp+0x90]
00007957b0dda997  vmovaps xmm10, [rsp+0xA0]
00007957b0dda9a0  vmovaps xmm11, [rsp+0xB0]
00007957b0dda9a9  vmovaps xmm13, [rsp+0xC0]
00007957b0dda9b2  vmovaps xmm14, [rsp+0xD0]
00007957b0dda9bb  vmovaps xmm15, [rsp+0xE0]
00007957b0dda9c4  add rsp, 0xF0
00007957b0dda9cb  pop r11
00007957b0dda9cd  pop r10
00007957b0dda9cf  pop r9
00007957b0dda9d1  pop r8
00007957b0dda9d3  pop rsi
00007957b0dda9d4  pop rdi
00007957b0dda9d5  pop rdx
00007957b0dda9d6  pop rcx
00007957b0dda9d7  pop rax
00007957b0dda9d8  add rsp, 0x08
00007957b0dda9dc  jmp 0x00007957B0DD9CC0
00007957b0dda9e1  call 0x00007957B0CB52F0
00007957b0dda9e6  jmp 0x00007957B0DD9DAC
00007957b0dda9eb  sub rsp, 0x08
00007957b0dda9ef  push rax
00007957b0dda9f0  push rcx
00007957b0dda9f1  push rdx
00007957b0dda9f2  push rdi
00007957b0dda9f3  push rsi
00007957b0dda9f4  push r8
00007957b0dda9f6  push r9
00007957b0dda9f8  push r10
00007957b0dda9fa  push r11
00007957b0dda9fc  sub rsp, 0xF0
00007957b0ddaa03  vmovaps [rsp], xmm0
00007957b0ddaa08  vmovaps [rsp+0x10], xmm1
00007957b0ddaa0e  vmovaps [rsp+0x20], xmm2
00007957b0ddaa14  vmovaps [rsp+0x30], xmm3
00007957b0ddaa1a  vmovaps [rsp+0x40], xmm4
00007957b0ddaa20  vmovaps [rsp+0x50], xmm5
00007957b0ddaa26  vmovaps [rsp+0x60], xmm6
00007957b0ddaa2c  vmovaps [rsp+0x70], xmm7
00007957b0ddaa32  vmovaps [rsp+0x80], xmm8
00007957b0ddaa3b  vmovaps [rsp+0x90], xmm9
00007957b0ddaa44  vmovaps [rsp+0xA0], xmm10
00007957b0ddaa4d  vmovaps [rsp+0xB0], xmm11
00007957b0ddaa56  vmovaps [rsp+0xC0], xmm12
00007957b0ddaa5f  vmovaps [rsp+0xD0], xmm14
00007957b0ddaa68  vmovaps [rsp+0xE0], xmm15
00007957b0ddaa71  sub rsp, 0x40
00007957b0ddaa75  lea rdi, [rsp]
00007957b0ddaa79  lea rsi, [rsp+0x10]
00007957b0ddaa7e  lea rdx, [rsp+0x20]
00007957b0ddaa83  lea rcx, [rsp+0x30]
00007957b0ddaa88  mov r8d, 0x00
00007957b0ddaa8e  lea r9, [r15+0x3A8]
00007957b0ddaa95  movaps [rdi], xmm13
00007957b0ddaa99  movaps [rsi], xmm1
00007957b0ddaa9c  movaps [rdx], xmm15
00007957b0ddaaa0  movaps [rcx], xmm14
00007957b0ddaaa4  mov rax, 0x56E396DF1A50
00007957b0ddaaae  call rax
00007957b0ddaab0  movaps xmm13, [rsp]
00007957b0ddaab5  add rsp, 0x40
00007957b0ddaab9  vmovaps xmm0, [rsp]
00007957b0ddaabe  vmovaps xmm1, [rsp+0x10]
00007957b0ddaac4  vmovaps xmm2, [rsp+0x20]
00007957b0ddaaca  vmovaps xmm3, [rsp+0x30]
00007957b0ddaad0  vmovaps xmm4, [rsp+0x40]
00007957b0ddaad6  vmovaps xmm5, [rsp+0x50]
00007957b0ddaadc  vmovaps xmm6, [rsp+0x60]
00007957b0ddaae2  vmovaps xmm7, [rsp+0x70]
00007957b0ddaae8  vmovaps xmm8, [rsp+0x80]
00007957b0ddaaf1  vmovaps xmm9, [rsp+0x90]
00007957b0ddaafa  vmovaps xmm10, [rsp+0xA0]
00007957b0ddab03  vmovaps xmm11, [rsp+0xB0]
00007957b0ddab0c  vmovaps xmm12, [rsp+0xC0]
00007957b0ddab15  vmovaps xmm14, [rsp+0xD0]
00007957b0ddab1e  vmovaps xmm15, [rsp+0xE0]
00007957b0ddab27  add rsp, 0xF0
00007957b0ddab2e  pop r11
00007957b0ddab30  pop r10
00007957b0ddab32  pop r9
00007957b0ddab34  pop r8
00007957b0ddab36  pop rsi
00007957b0ddab37  pop rdi
00007957b0ddab38  pop rdx
00007957b0ddab39  pop rcx
00007957b0ddab3a  pop rax
00007957b0ddab3b  add rsp, 0x08
00007957b0ddab3f  jmp 0x00007957B0DD9E21
00007957b0ddab44  call 0x00007957B0BFF430
00007957b0ddab49  jmp 0x00007957B0DD9E2E
00007957b0ddab4e  sub rsp, 0x08
00007957b0ddab52  push rax
00007957b0ddab53  push rcx
00007957b0ddab54  push rdx
00007957b0ddab55  push rdi
00007957b0ddab56  push rsi
00007957b0ddab57  push r8
00007957b0ddab59  push r9
00007957b0ddab5b  push r10
00007957b0ddab5d  push r11
00007957b0ddab5f  sub rsp, 0xF0
00007957b0ddab66  vmovaps [rsp], xmm0
00007957b0ddab6b  vmovaps [rsp+0x10], xmm1
00007957b0ddab71  vmovaps [rsp+0x20], xmm2
00007957b0ddab77  vmovaps [rsp+0x30], xmm3
00007957b0ddab7d  vmovaps [rsp+0x40], xmm4
00007957b0ddab83  vmovaps [rsp+0x50], xmm5
00007957b0ddab89  vmovaps [rsp+0x60], xmm6
00007957b0ddab8f  vmovaps [rsp+0x70], xmm7
00007957b0ddab95  vmovaps [rsp+0x80], xmm8
00007957b0ddab9e  vmovaps [rsp+0x90], xmm9
00007957b0ddaba7  vmovaps [rsp+0xA0], xmm10
00007957b0ddabb0  vmovaps [rsp+0xB0], xmm11
00007957b0ddabb9  vmovaps [rsp+0xC0], xmm13
00007957b0ddabc2  vmovaps [rsp+0xD0], xmm14
00007957b0ddabcb  vmovaps [rsp+0xE0], xmm15
00007957b0ddabd4  sub rsp, 0x40
00007957b0ddabd8  lea rdi, [rsp]
00007957b0ddabdc  lea rsi, [rsp+0x10]
00007957b0ddabe1  lea rdx, [rsp+0x20]
00007957b0ddabe6  lea rcx, [rsp+0x30]
00007957b0ddabeb  mov r8d, 0x00
00007957b0ddabf1  lea r9, [r15+0x3A8]
00007957b0ddabf8  movaps [rdi], xmm12
00007957b0ddabfc  movaps [rsi], xmm15
00007957b0ddac00  movaps [rdx], xmm1
00007957b0ddac03  movaps [rcx], xmm14
00007957b0ddac07  mov rax, 0x56E396DF1A50
00007957b0ddac11  call rax
00007957b0ddac13  movaps xmm12, [rsp]
00007957b0ddac18  add rsp, 0x40
00007957b0ddac1c  vmovaps xmm0, [rsp]
00007957b0ddac21  vmovaps xmm1, [rsp+0x10]
00007957b0ddac27  vmovaps xmm2, [rsp+0x20]
00007957b0ddac2d  vmovaps xmm3, [rsp+0x30]
00007957b0ddac33  vmovaps xmm4, [rsp+0x40]
00007957b0ddac39  vmovaps xmm5, [rsp+0x50]
00007957b0ddac3f  vmovaps xmm6, [rsp+0x60]
00007957b0ddac45  vmovaps xmm7, [rsp+0x70]
00007957b0ddac4b  vmovaps xmm8, [rsp+0x80]
00007957b0ddac54  vmovaps xmm9, [rsp+0x90]
00007957b0ddac5d  vmovaps xmm10, [rsp+0xA0]
00007957b0ddac66  vmovaps xmm11, [rsp+0xB0]
00007957b0ddac6f  vmovaps xmm13, [rsp+0xC0]
00007957b0ddac78  vmovaps xmm14, [rsp+0xD0]
00007957b0ddac81  vmovaps xmm15, [rsp+0xE0]
00007957b0ddac8a  add rsp, 0xF0
00007957b0ddac91  pop r11
00007957b0ddac93  pop r10
00007957b0ddac95  pop r9
00007957b0ddac97  pop r8
00007957b0ddac99  pop rsi
00007957b0ddac9a  pop rdi
00007957b0ddac9b  pop rdx
00007957b0ddac9c  pop rcx
00007957b0ddac9d  pop rax
00007957b0ddac9e  add rsp, 0x08
00007957b0ddaca2  jmp 0x00007957B0DD9E5A
00007957b0ddaca7  sub rsp, 0x08
00007957b0ddacab  push rax
00007957b0ddacac  push rcx
00007957b0ddacad  push rdx
00007957b0ddacae  push rdi
00007957b0ddacaf  push rsi
00007957b0ddacb0  push r8
00007957b0ddacb2  push r9
00007957b0ddacb4  push r10
00007957b0ddacb6  push r11
00007957b0ddacb8  sub rsp, 0xF0
00007957b0ddacbf  vmovaps [rsp], xmm0
00007957b0ddacc4  vmovaps [rsp+0x10], xmm1
00007957b0ddacca  vmovaps [rsp+0x20], xmm2
00007957b0ddacd0  vmovaps [rsp+0x30], xmm3
00007957b0ddacd6  vmovaps [rsp+0x40], xmm4
00007957b0ddacdc  vmovaps [rsp+0x50], xmm5
00007957b0ddace2  vmovaps [rsp+0x60], xmm6
00007957b0ddace8  vmovaps [rsp+0x70], xmm7
00007957b0ddacee  vmovaps [rsp+0x80], xmm8
00007957b0ddacf7  vmovaps [rsp+0x90], xmm9
00007957b0ddad00  vmovaps [rsp+0xA0], xmm10
00007957b0ddad09  vmovaps [rsp+0xB0], xmm11
00007957b0ddad12  vmovaps [rsp+0xC0], xmm12
00007957b0ddad1b  vmovaps [rsp+0xD0], xmm14
00007957b0ddad24  vmovaps [rsp+0xE0], xmm15
00007957b0ddad2d  sub rsp, 0x40
00007957b0ddad31  lea rdi, [rsp]
00007957b0ddad35  lea rsi, [rsp+0x10]
00007957b0ddad3a  lea rdx, [rsp+0x20]
00007957b0ddad3f  lea rcx, [rsp+0x30]
00007957b0ddad44  mov r8d, 0x00
00007957b0ddad4a  lea r9, [r15+0x3A8]
00007957b0ddad51  movaps [rdi], xmm13
00007957b0ddad55  movaps [rsi], xmm1
00007957b0ddad58  movaps [rdx], xmm15
00007957b0ddad5c  movaps [rcx], xmm14
00007957b0ddad60  mov rax, 0x56E396DF1A50
00007957b0ddad6a  call rax
00007957b0ddad6c  movaps xmm13, [rsp]
00007957b0ddad71  add rsp, 0x40
00007957b0ddad75  vmovaps xmm0, [rsp]
00007957b0ddad7a  vmovaps xmm1, [rsp+0x10]
00007957b0ddad80  vmovaps xmm2, [rsp+0x20]
00007957b0ddad86  vmovaps xmm3, [rsp+0x30]
00007957b0ddad8c  vmovaps xmm4, [rsp+0x40]
00007957b0ddad92  vmovaps xmm5, [rsp+0x50]
00007957b0ddad98  vmovaps xmm6, [rsp+0x60]
00007957b0ddad9e  vmovaps xmm7, [rsp+0x70]
00007957b0ddada4  vmovaps xmm8, [rsp+0x80]
00007957b0ddadad  vmovaps xmm9, [rsp+0x90]
00007957b0ddadb6  vmovaps xmm10, [rsp+0xA0]
00007957b0ddadbf  vmovaps xmm11, [rsp+0xB0]
00007957b0ddadc8  vmovaps xmm12, [rsp+0xC0]
00007957b0ddadd1  vmovaps xmm14, [rsp+0xD0]
00007957b0ddadda  vmovaps xmm15, [rsp+0xE0]
00007957b0ddade3  add rsp, 0xF0
00007957b0ddadea  pop r11
00007957b0ddadec  pop r10
00007957b0ddadee  pop r9
00007957b0ddadf0  pop r8
00007957b0ddadf2  pop rsi
00007957b0ddadf3  pop rdi
00007957b0ddadf4  pop rdx
00007957b0ddadf5  pop rcx
00007957b0ddadf6  pop rax
00007957b0ddadf7  add rsp, 0x08
00007957b0ddadfb  jmp 0x00007957B0DD9FEA
00007957b0ddae00  sub rsp, 0x08
00007957b0ddae04  push rax
00007957b0ddae05  push rcx
00007957b0ddae06  push rdx
00007957b0ddae07  push rdi
00007957b0ddae08  push rsi
00007957b0ddae09  push r8
00007957b0ddae0b  push r9
00007957b0ddae0d  push r10
00007957b0ddae0f  push r11
00007957b0ddae11  sub rsp, 0xF0
00007957b0ddae18  vmovaps [rsp], xmm0
00007957b0ddae1d  vmovaps [rsp+0x10], xmm1
00007957b0ddae23  vmovaps [rsp+0x20], xmm2
00007957b0ddae29  vmovaps [rsp+0x30], xmm3
00007957b0ddae2f  vmovaps [rsp+0x40], xmm4
00007957b0ddae35  vmovaps [rsp+0x50], xmm5
00007957b0ddae3b  vmovaps [rsp+0x60], xmm6
00007957b0ddae41  vmovaps [rsp+0x70], xmm7
00007957b0ddae47  vmovaps [rsp+0x80], xmm8
00007957b0ddae50  vmovaps [rsp+0x90], xmm9
00007957b0ddae59  vmovaps [rsp+0xA0], xmm10
00007957b0ddae62  vmovaps [rsp+0xB0], xmm11
00007957b0ddae6b  vmovaps [rsp+0xC0], xmm12
00007957b0ddae74  vmovaps [rsp+0xD0], xmm13
00007957b0ddae7d  vmovaps [rsp+0xE0], xmm15
00007957b0ddae86  sub rsp, 0x40
00007957b0ddae8a  lea rdi, [rsp]
00007957b0ddae8e  lea rsi, [rsp+0x10]
00007957b0ddae93  lea rdx, [rsp+0x20]
00007957b0ddae98  lea rcx, [rsp+0x30]
00007957b0ddae9d  mov r8d, 0x00
00007957b0ddaea3  lea r9, [r15+0x3A8]
00007957b0ddaeaa  movaps [rdi], xmm14
00007957b0ddaeae  movaps [rsi], xmm15
00007957b0ddaeb2  movaps [rdx], xmm2
00007957b0ddaeb5  movaps [rcx], xmm1
00007957b0ddaeb8  mov rax, 0x56E396DF1A50
00007957b0ddaec2  call rax
00007957b0ddaec4  movaps xmm14, [rsp]
00007957b0ddaec9  add rsp, 0x40
00007957b0ddaecd  vmovaps xmm0, [rsp]
00007957b0ddaed2  vmovaps xmm1, [rsp+0x10]
00007957b0ddaed8  vmovaps xmm2, [rsp+0x20]
00007957b0ddaede  vmovaps xmm3, [rsp+0x30]
00007957b0ddaee4  vmovaps xmm4, [rsp+0x40]
00007957b0ddaeea  vmovaps xmm5, [rsp+0x50]
00007957b0ddaef0  vmovaps xmm6, [rsp+0x60]
00007957b0ddaef6  vmovaps xmm7, [rsp+0x70]
00007957b0ddaefc  vmovaps xmm8, [rsp+0x80]
00007957b0ddaf05  vmovaps xmm9, [rsp+0x90]
00007957b0ddaf0e  vmovaps xmm10, [rsp+0xA0]
00007957b0ddaf17  vmovaps xmm11, [rsp+0xB0]
00007957b0ddaf20  vmovaps xmm12, [rsp+0xC0]
00007957b0ddaf29  vmovaps xmm13, [rsp+0xD0]
00007957b0ddaf32  vmovaps xmm15, [rsp+0xE0]
00007957b0ddaf3b  add rsp, 0xF0
00007957b0ddaf42  pop r11
00007957b0ddaf44  pop r10
00007957b0ddaf46  pop r9
00007957b0ddaf48  pop r8
00007957b0ddaf4a  pop rsi
00007957b0ddaf4b  pop rdi
00007957b0ddaf4c  pop rdx
00007957b0ddaf4d  pop rcx
00007957b0ddaf4e  pop rax
00007957b0ddaf4f  add rsp, 0x08
00007957b0ddaf53  jmp 0x00007957B0DDA01C
00007957b0ddaf58  sub rsp, 0x08
00007957b0ddaf5c  push rax
00007957b0ddaf5d  push rcx
00007957b0ddaf5e  push rdx
00007957b0ddaf5f  push rdi
00007957b0ddaf60  push rsi
00007957b0ddaf61  push r8
00007957b0ddaf63  push r9
00007957b0ddaf65  push r10
00007957b0ddaf67  push r11
00007957b0ddaf69  sub rsp, 0xF0
00007957b0ddaf70  vmovaps [rsp], xmm0
00007957b0ddaf75  vmovaps [rsp+0x10], xmm1
00007957b0ddaf7b  vmovaps [rsp+0x20], xmm3
00007957b0ddaf81  vmovaps [rsp+0x30], xmm4
00007957b0ddaf87  vmovaps [rsp+0x40], xmm5
00007957b0ddaf8d  vmovaps [rsp+0x50], xmm6
00007957b0ddaf93  vmovaps [rsp+0x60], xmm7
00007957b0ddaf99  vmovaps [rsp+0x70], xmm8
00007957b0ddaf9f  vmovaps [rsp+0x80], xmm9
00007957b0ddafa8  vmovaps [rsp+0x90], xmm10
00007957b0ddafb1  vmovaps [rsp+0xA0], xmm11
00007957b0ddafba  vmovaps [rsp+0xB0], xmm12
00007957b0ddafc3  vmovaps [rsp+0xC0], xmm13
00007957b0ddafcc  vmovaps [rsp+0xD0], xmm14
00007957b0ddafd5  vmovaps [rsp+0xE0], xmm15
00007957b0ddafde  sub rsp, 0x40
00007957b0ddafe2  lea rdi, [rsp]
00007957b0ddafe6  lea rsi, [rsp+0x10]
00007957b0ddafeb  lea rdx, [rsp+0x20]
00007957b0ddaff0  lea rcx, [rsp+0x30]
00007957b0ddaff5  mov r8d, 0x00
00007957b0ddaffb  lea r9, [r15+0x3A8]
00007957b0ddb002  movaps [rdi], xmm2
00007957b0ddb005  movaps [rsi], xmm15
00007957b0ddb009  movaps [rdx], xmm12
00007957b0ddb00d  movaps [rcx], xmm1
00007957b0ddb010  mov rax, 0x56E396DF1A50
00007957b0ddb01a  call rax
00007957b0ddb01c  movaps xmm2, [rsp]
00007957b0ddb020  add rsp, 0x40
00007957b0ddb024  vmovaps xmm0, [rsp]
00007957b0ddb029  vmovaps xmm1, [rsp+0x10]
00007957b0ddb02f  vmovaps xmm3, [rsp+0x20]
00007957b0ddb035  vmovaps xmm4, [rsp+0x30]
00007957b0ddb03b  vmovaps xmm5, [rsp+0x40]
00007957b0ddb041  vmovaps xmm6, [rsp+0x50]
00007957b0ddb047  vmovaps xmm7, [rsp+0x60]
00007957b0ddb04d  vmovaps xmm8, [rsp+0x70]
00007957b0ddb053  vmovaps xmm9, [rsp+0x80]
00007957b0ddb05c  vmovaps xmm10, [rsp+0x90]
00007957b0ddb065  vmovaps xmm11, [rsp+0xA0]
00007957b0ddb06e  vmovaps xmm12, [rsp+0xB0]
00007957b0ddb077  vmovaps xmm13, [rsp+0xC0]
00007957b0ddb080  vmovaps xmm14, [rsp+0xD0]
00007957b0ddb089  vmovaps xmm15, [rsp+0xE0]
00007957b0ddb092  add rsp, 0xF0
00007957b0ddb099  pop r11
00007957b0ddb09b  pop r10
00007957b0ddb09d  pop r9
00007957b0ddb09f  pop r8
00007957b0ddb0a1  pop rsi
00007957b0ddb0a2  pop rdi
00007957b0ddb0a3  pop rdx
00007957b0ddb0a4  pop rcx
00007957b0ddb0a5  pop rax
00007957b0ddb0a6  add rsp, 0x08
00007957b0ddb0aa  jmp 0x00007957B0DDA059
00007957b0ddb0af  sub rsp, 0x08
00007957b0ddb0b3  push rax
00007957b0ddb0b4  push rcx
00007957b0ddb0b5  push rdx
00007957b0ddb0b6  push rdi
00007957b0ddb0b7  push rsi
00007957b0ddb0b8  push r8
00007957b0ddb0ba  push r9
00007957b0ddb0bc  push r10
00007957b0ddb0be  push r11
00007957b0ddb0c0  sub rsp, 0xF0
00007957b0ddb0c7  vmovaps [rsp], xmm0
00007957b0ddb0cc  vmovaps [rsp+0x10], xmm1
00007957b0ddb0d2  vmovaps [rsp+0x20], xmm2
00007957b0ddb0d8  vmovaps [rsp+0x30], xmm3
00007957b0ddb0de  vmovaps [rsp+0x40], xmm4
00007957b0ddb0e4  vmovaps [rsp+0x50], xmm5
00007957b0ddb0ea  vmovaps [rsp+0x60], xmm6
00007957b0ddb0f0  vmovaps [rsp+0x70], xmm7
00007957b0ddb0f6  vmovaps [rsp+0x80], xmm8
00007957b0ddb0ff  vmovaps [rsp+0x90], xmm9
00007957b0ddb108  vmovaps [rsp+0xA0], xmm10
00007957b0ddb111  vmovaps [rsp+0xB0], xmm11
00007957b0ddb11a  vmovaps [rsp+0xC0], xmm13
00007957b0ddb123  vmovaps [rsp+0xD0], xmm14
00007957b0ddb12c  vmovaps [rsp+0xE0], xmm15
00007957b0ddb135  sub rsp, 0x40
00007957b0ddb139  lea rdi, [rsp]
00007957b0ddb13d  lea rsi, [rsp+0x10]
00007957b0ddb142  lea rdx, [rsp+0x20]
00007957b0ddb147  lea rcx, [rsp+0x30]
00007957b0ddb14c  mov r8d, 0x00
00007957b0ddb152  lea r9, [r15+0x3A8]
00007957b0ddb159  movaps [rdi], xmm12
00007957b0ddb15d  movaps [rsi], xmm14
00007957b0ddb161  movaps [rdx], xmm3
00007957b0ddb164  movaps [rcx], xmm15
00007957b0ddb168  mov rax, 0x56E396DF1A50
00007957b0ddb172  call rax
00007957b0ddb174  movaps xmm12, [rsp]
00007957b0ddb179  add rsp, 0x40
00007957b0ddb17d  vmovaps xmm0, [rsp]
00007957b0ddb182  vmovaps xmm1, [rsp+0x10]
00007957b0ddb188  vmovaps xmm2, [rsp+0x20]
00007957b0ddb18e  vmovaps xmm3, [rsp+0x30]
00007957b0ddb194  vmovaps xmm4, [rsp+0x40]
00007957b0ddb19a  vmovaps xmm5, [rsp+0x50]
00007957b0ddb1a0  vmovaps xmm6, [rsp+0x60]
00007957b0ddb1a6  vmovaps xmm7, [rsp+0x70]
00007957b0ddb1ac  vmovaps xmm8, [rsp+0x80]
00007957b0ddb1b5  vmovaps xmm9, [rsp+0x90]
00007957b0ddb1be  vmovaps xmm10, [rsp+0xA0]
00007957b0ddb1c7  vmovaps xmm11, [rsp+0xB0]
00007957b0ddb1d0  vmovaps xmm13, [rsp+0xC0]
00007957b0ddb1d9  vmovaps xmm14, [rsp+0xD0]
00007957b0ddb1e2  vmovaps xmm15, [rsp+0xE0]
00007957b0ddb1eb  add rsp, 0xF0
00007957b0ddb1f2  pop r11
00007957b0ddb1f4  pop r10
00007957b0ddb1f6  pop r9
00007957b0ddb1f8  pop r8
00007957b0ddb1fa  pop rsi
00007957b0ddb1fb  pop rdi
00007957b0ddb1fc  pop rdx
00007957b0ddb1fd  pop rcx
00007957b0ddb1fe  pop rax
00007957b0ddb1ff  add rsp, 0x08
00007957b0ddb203  jmp 0x00007957B0DDA0B3
00007957b0ddb208  sub rsp, 0x08
00007957b0ddb20c  push rax
00007957b0ddb20d  push rcx
00007957b0ddb20e  push rdx
00007957b0ddb20f  push rdi
00007957b0ddb210  push rsi
00007957b0ddb211  push r8
00007957b0ddb213  push r9
00007957b0ddb215  push r10
00007957b0ddb217  push r11
00007957b0ddb219  sub rsp, 0xF0
00007957b0ddb220  vmovaps [rsp], xmm0
00007957b0ddb225  vmovaps [rsp+0x10], xmm1
00007957b0ddb22b  vmovaps [rsp+0x20], xmm2
00007957b0ddb231  vmovaps [rsp+0x30], xmm3
00007957b0ddb237  vmovaps [rsp+0x40], xmm4
00007957b0ddb23d  vmovaps [rsp+0x50], xmm5
00007957b0ddb243  vmovaps [rsp+0x60], xmm6
00007957b0ddb249  vmovaps [rsp+0x70], xmm7
00007957b0ddb24f  vmovaps [rsp+0x80], xmm8
00007957b0ddb258  vmovaps [rsp+0x90], xmm10
00007957b0ddb261  vmovaps [rsp+0xA0], xmm11
00007957b0ddb26a  vmovaps [rsp+0xB0], xmm12
00007957b0ddb273  vmovaps [rsp+0xC0], xmm13
00007957b0ddb27c  vmovaps [rsp+0xD0], xmm14
00007957b0ddb285  vmovaps [rsp+0xE0], xmm15
00007957b0ddb28e  sub rsp, 0x40
00007957b0ddb292  lea rdi, [rsp]
00007957b0ddb296  lea rsi, [rsp+0x10]
00007957b0ddb29b  lea rdx, [rsp+0x20]
00007957b0ddb2a0  lea rcx, [rsp+0x30]
00007957b0ddb2a5  mov r8d, 0x00
00007957b0ddb2ab  lea r9, [r15+0x3A8]
00007957b0ddb2b2  movaps [rdi], xmm9
00007957b0ddb2b6  movaps [rsi], xmm13
00007957b0ddb2ba  movaps [rdx], xmm14
00007957b0ddb2be  movaps [rcx], xmm6
00007957b0ddb2c1  mov rax, 0x56E396DF1A50
00007957b0ddb2cb  call rax
00007957b0ddb2cd  movaps xmm9, [rsp]
00007957b0ddb2d2  add rsp, 0x40
00007957b0ddb2d6  vmovaps xmm0, [rsp]
00007957b0ddb2db  vmovaps xmm1, [rsp+0x10]
00007957b0ddb2e1  vmovaps xmm2, [rsp+0x20]
00007957b0ddb2e7  vmovaps xmm3, [rsp+0x30]
00007957b0ddb2ed  vmovaps xmm4, [rsp+0x40]
00007957b0ddb2f3  vmovaps xmm5, [rsp+0x50]
00007957b0ddb2f9  vmovaps xmm6, [rsp+0x60]
00007957b0ddb2ff  vmovaps xmm7, [rsp+0x70]
00007957b0ddb305  vmovaps xmm8, [rsp+0x80]
00007957b0ddb30e  vmovaps xmm10, [rsp+0x90]
00007957b0ddb317  vmovaps xmm11, [rsp+0xA0]
00007957b0ddb320  vmovaps xmm12, [rsp+0xB0]
00007957b0ddb329  vmovaps xmm13, [rsp+0xC0]
00007957b0ddb332  vmovaps xmm14, [rsp+0xD0]
00007957b0ddb33b  vmovaps xmm15, [rsp+0xE0]
00007957b0ddb344  add rsp, 0xF0
00007957b0ddb34b  pop r11
00007957b0ddb34d  pop r10
00007957b0ddb34f  pop r9
00007957b0ddb351  pop r8
00007957b0ddb353  pop rsi
00007957b0ddb354  pop rdi
00007957b0ddb355  pop rdx
00007957b0ddb356  pop rcx
00007957b0ddb357  pop rax
00007957b0ddb358  add rsp, 0x08
00007957b0ddb35c  jmp 0x00007957B0DDA15D
00007957b0ddb361  sub rsp, 0x08
00007957b0ddb365  push rax
00007957b0ddb366  push rcx
00007957b0ddb367  push rdx
00007957b0ddb368  push rdi
00007957b0ddb369  push rsi
00007957b0ddb36a  push r8
00007957b0ddb36c  push r9
00007957b0ddb36e  push r10
00007957b0ddb370  push r11
00007957b0ddb372  sub rsp, 0xF0
00007957b0ddb379  vmovaps [rsp], xmm0
00007957b0ddb37e  vmovaps [rsp+0x10], xmm1
00007957b0ddb384  vmovaps [rsp+0x20], xmm2
00007957b0ddb38a  vmovaps [rsp+0x30], xmm4
00007957b0ddb390  vmovaps [rsp+0x40], xmm5
00007957b0ddb396  vmovaps [rsp+0x50], xmm6
00007957b0ddb39c  vmovaps [rsp+0x60], xmm7
00007957b0ddb3a2  vmovaps [rsp+0x70], xmm8
00007957b0ddb3a8  vmovaps [rsp+0x80], xmm9
00007957b0ddb3b1  vmovaps [rsp+0x90], xmm10
00007957b0ddb3ba  vmovaps [rsp+0xA0], xmm11
00007957b0ddb3c3  vmovaps [rsp+0xB0], xmm12
00007957b0ddb3cc  vmovaps [rsp+0xC0], xmm13
00007957b0ddb3d5  vmovaps [rsp+0xD0], xmm14
00007957b0ddb3de  vmovaps [rsp+0xE0], xmm15
00007957b0ddb3e7  sub rsp, 0x40
00007957b0ddb3eb  lea rdi, [rsp]
00007957b0ddb3ef  lea rsi, [rsp+0x10]
00007957b0ddb3f4  lea rdx, [rsp+0x20]
00007957b0ddb3f9  lea rcx, [rsp+0x30]
00007957b0ddb3fe  mov r8d, 0x00
00007957b0ddb404  lea r9, [r15+0x3A8]
00007957b0ddb40b  movaps [rdi], xmm3
00007957b0ddb40e  movaps [rsi], xmm13
00007957b0ddb412  movaps [rdx], xmm6
00007957b0ddb415  movaps [rcx], xmm14
00007957b0ddb419  mov rax, 0x56E396DF1A50
00007957b0ddb423  call rax
00007957b0ddb425  movaps xmm3, [rsp]
00007957b0ddb429  add rsp, 0x40
00007957b0ddb42d  vmovaps xmm0, [rsp]
00007957b0ddb432  vmovaps xmm1, [rsp+0x10]
00007957b0ddb438  vmovaps xmm2, [rsp+0x20]
00007957b0ddb43e  vmovaps xmm4, [rsp+0x30]
00007957b0ddb444  vmovaps xmm5, [rsp+0x40]
00007957b0ddb44a  vmovaps xmm6, [rsp+0x50]
00007957b0ddb450  vmovaps xmm7, [rsp+0x60]
00007957b0ddb456  vmovaps xmm8, [rsp+0x70]
00007957b0ddb45c  vmovaps xmm9, [rsp+0x80]
00007957b0ddb465  vmovaps xmm10, [rsp+0x90]
00007957b0ddb46e  vmovaps xmm11, [rsp+0xA0]
00007957b0ddb477  vmovaps xmm12, [rsp+0xB0]
00007957b0ddb480  vmovaps xmm13, [rsp+0xC0]
00007957b0ddb489  vmovaps xmm14, [rsp+0xD0]
00007957b0ddb492  vmovaps xmm15, [rsp+0xE0]
00007957b0ddb49b  add rsp, 0xF0
00007957b0ddb4a2  pop r11
00007957b0ddb4a4  pop r10
00007957b0ddb4a6  pop r9
00007957b0ddb4a8  pop r8
00007957b0ddb4aa  pop rsi
00007957b0ddb4ab  pop rdi
00007957b0ddb4ac  pop rdx
00007957b0ddb4ad  pop rcx
00007957b0ddb4ae  pop rax
00007957b0ddb4af  add rsp, 0x08
00007957b0ddb4b3  jmp 0x00007957B0DDA19A
00007957b0ddb4b8  sub rsp, 0x08
00007957b0ddb4bc  push rax
00007957b0ddb4bd  push rcx
00007957b0ddb4be  push rdx
00007957b0ddb4bf  push rdi
00007957b0ddb4c0  push rsi
00007957b0ddb4c1  push r8
00007957b0ddb4c3  push r9
00007957b0ddb4c5  push r10
00007957b0ddb4c7  push r11
00007957b0ddb4c9  sub rsp, 0xF0
00007957b0ddb4d0  vmovaps [rsp], xmm0
00007957b0ddb4d5  vmovaps [rsp+0x10], xmm1
00007957b0ddb4db  vmovaps [rsp+0x20], xmm2
00007957b0ddb4e1  vmovaps [rsp+0x30], xmm3
00007957b0ddb4e7  vmovaps [rsp+0x40], xmm4
00007957b0ddb4ed  vmovaps [rsp+0x50], xmm5
00007957b0ddb4f3  vmovaps [rsp+0x60], xmm7
00007957b0ddb4f9  vmovaps [rsp+0x70], xmm8
00007957b0ddb4ff  vmovaps [rsp+0x80], xmm9
00007957b0ddb508  vmovaps [rsp+0x90], xmm10
00007957b0ddb511  vmovaps [rsp+0xA0], xmm11
00007957b0ddb51a  vmovaps [rsp+0xB0], xmm12
00007957b0ddb523  vmovaps [rsp+0xC0], xmm13
00007957b0ddb52c  vmovaps [rsp+0xD0], xmm14
00007957b0ddb535  vmovaps [rsp+0xE0], xmm15
00007957b0ddb53e  sub rsp, 0x40
00007957b0ddb542  lea rdi, [rsp]
00007957b0ddb546  lea rsi, [rsp+0x10]
00007957b0ddb54b  lea rdx, [rsp+0x20]
00007957b0ddb550  lea rcx, [rsp+0x30]
00007957b0ddb555  mov r8d, 0x00
00007957b0ddb55b  lea r9, [r15+0x3A8]
00007957b0ddb562  movaps [rdi], xmm6
00007957b0ddb565  movaps [rsi], xmm2
00007957b0ddb568  movaps [rdx], xmm14
00007957b0ddb56c  movaps [rcx], xmm1
00007957b0ddb56f  mov rax, 0x56E396DF1A50
00007957b0ddb579  call rax
00007957b0ddb57b  movaps xmm6, [rsp]
00007957b0ddb57f  add rsp, 0x40
00007957b0ddb583  vmovaps xmm0, [rsp]
00007957b0ddb588  vmovaps xmm1, [rsp+0x10]
00007957b0ddb58e  vmovaps xmm2, [rsp+0x20]
00007957b0ddb594  vmovaps xmm3, [rsp+0x30]
00007957b0ddb59a  vmovaps xmm4, [rsp+0x40]
00007957b0ddb5a0  vmovaps xmm5, [rsp+0x50]
00007957b0ddb5a6  vmovaps xmm7, [rsp+0x60]
00007957b0ddb5ac  vmovaps xmm8, [rsp+0x70]
00007957b0ddb5b2  vmovaps xmm9, [rsp+0x80]
00007957b0ddb5bb  vmovaps xmm10, [rsp+0x90]
00007957b0ddb5c4  vmovaps xmm11, [rsp+0xA0]
00007957b0ddb5cd  vmovaps xmm12, [rsp+0xB0]
00007957b0ddb5d6  vmovaps xmm13, [rsp+0xC0]
00007957b0ddb5df  vmovaps xmm14, [rsp+0xD0]
00007957b0ddb5e8  vmovaps xmm15, [rsp+0xE0]
00007957b0ddb5f1  add rsp, 0xF0
00007957b0ddb5f8  pop r11
00007957b0ddb5fa  pop r10
00007957b0ddb5fc  pop r9
00007957b0ddb5fe  pop r8
00007957b0ddb600  pop rsi
00007957b0ddb601  pop rdi
00007957b0ddb602  pop rdx
00007957b0ddb603  pop rcx
00007957b0ddb604  pop rax
00007957b0ddb605  add rsp, 0x08
00007957b0ddb609  jmp 0x00007957B0DDA1C7
00007957b0ddb60e  sub rsp, 0x08
00007957b0ddb612  push rax
00007957b0ddb613  push rcx
00007957b0ddb614  push rdx
00007957b0ddb615  push rdi
00007957b0ddb616  push rsi
00007957b0ddb617  push r8
00007957b0ddb619  push r9
00007957b0ddb61b  push r10
00007957b0ddb61d  push r11
00007957b0ddb61f  sub rsp, 0xF0
00007957b0ddb626  vmovaps [rsp], xmm0
00007957b0ddb62b  vmovaps [rsp+0x10], xmm1
00007957b0ddb631  vmovaps [rsp+0x20], xmm2
00007957b0ddb637  vmovaps [rsp+0x30], xmm3
00007957b0ddb63d  vmovaps [rsp+0x40], xmm4
00007957b0ddb643  vmovaps [rsp+0x50], xmm5
00007957b0ddb649  vmovaps [rsp+0x60], xmm6
00007957b0ddb64f  vmovaps [rsp+0x70], xmm7
00007957b0ddb655  vmovaps [rsp+0x80], xmm8
00007957b0ddb65e  vmovaps [rsp+0x90], xmm9
00007957b0ddb667  vmovaps [rsp+0xA0], xmm10
00007957b0ddb670  vmovaps [rsp+0xB0], xmm11
00007957b0ddb679  vmovaps [rsp+0xC0], xmm12
00007957b0ddb682  vmovaps [rsp+0xD0], xmm14
00007957b0ddb68b  vmovaps [rsp+0xE0], xmm15
00007957b0ddb694  sub rsp, 0x40
00007957b0ddb698  lea rdi, [rsp]
00007957b0ddb69c  lea rsi, [rsp+0x10]
00007957b0ddb6a1  lea rdx, [rsp+0x20]
00007957b0ddb6a6  lea rcx, [rsp+0x30]
00007957b0ddb6ab  mov r8d, 0x00
00007957b0ddb6b1  lea r9, [r15+0x3A8]
00007957b0ddb6b8  movaps [rdi], xmm13
00007957b0ddb6bc  movaps [rsi], xmm12
00007957b0ddb6c0  movaps [rdx], xmm14
00007957b0ddb6c4  movaps [rcx], xmm1
00007957b0ddb6c7  mov rax, 0x56E396DF1A50
00007957b0ddb6d1  call rax
00007957b0ddb6d3  movaps xmm13, [rsp]
00007957b0ddb6d8  add rsp, 0x40
00007957b0ddb6dc  vmovaps xmm0, [rsp]
00007957b0ddb6e1  vmovaps xmm1, [rsp+0x10]
00007957b0ddb6e7  vmovaps xmm2, [rsp+0x20]
00007957b0ddb6ed  vmovaps xmm3, [rsp+0x30]
00007957b0ddb6f3  vmovaps xmm4, [rsp+0x40]
00007957b0ddb6f9  vmovaps xmm5, [rsp+0x50]
00007957b0ddb6ff  vmovaps xmm6, [rsp+0x60]
00007957b0ddb705  vmovaps xmm7, [rsp+0x70]
00007957b0ddb70b  vmovaps xmm8, [rsp+0x80]
00007957b0ddb714  vmovaps xmm9, [rsp+0x90]
00007957b0ddb71d  vmovaps xmm10, [rsp+0xA0]
00007957b0ddb726  vmovaps xmm11, [rsp+0xB0]
00007957b0ddb72f  vmovaps xmm12, [rsp+0xC0]
00007957b0ddb738  vmovaps xmm14, [rsp+0xD0]
00007957b0ddb741  vmovaps xmm15, [rsp+0xE0]
00007957b0ddb74a  add rsp, 0xF0
00007957b0ddb751  pop r11
00007957b0ddb753  pop r10
00007957b0ddb755  pop r9
00007957b0ddb757  pop r8
00007957b0ddb759  pop rsi
00007957b0ddb75a  pop rdi
00007957b0ddb75b  pop rdx
00007957b0ddb75c  pop rcx
00007957b0ddb75d  pop rax
00007957b0ddb75e  add rsp, 0x08
00007957b0ddb762  jmp 0x00007957B0DDA1F9
00007957b0ddb767  sub rsp, 0x08
00007957b0ddb76b  push rax
00007957b0ddb76c  push rcx
00007957b0ddb76d  push rdx
00007957b0ddb76e  push rdi
00007957b0ddb76f  push rsi
00007957b0ddb770  push r8
00007957b0ddb772  push r9
00007957b0ddb774  push r10
00007957b0ddb776  push r11
00007957b0ddb778  sub rsp, 0xF0
00007957b0ddb77f  vmovaps [rsp], xmm0
00007957b0ddb784  vmovaps [rsp+0x10], xmm1
00007957b0ddb78a  vmovaps [rsp+0x20], xmm2
00007957b0ddb790  vmovaps [rsp+0x30], xmm3
00007957b0ddb796  vmovaps [rsp+0x40], xmm4
00007957b0ddb79c  vmovaps [rsp+0x50], xmm5
00007957b0ddb7a2  vmovaps [rsp+0x60], xmm6
00007957b0ddb7a8  vmovaps [rsp+0x70], xmm7
00007957b0ddb7ae  vmovaps [rsp+0x80], xmm8
00007957b0ddb7b7  vmovaps [rsp+0x90], xmm9
00007957b0ddb7c0  vmovaps [rsp+0xA0], xmm10
00007957b0ddb7c9  vmovaps [rsp+0xB0], xmm11
00007957b0ddb7d2  vmovaps [rsp+0xC0], xmm13
00007957b0ddb7db  vmovaps [rsp+0xD0], xmm14
00007957b0ddb7e4  vmovaps [rsp+0xE0], xmm15
00007957b0ddb7ed  sub rsp, 0x40
00007957b0ddb7f1  lea rdi, [rsp]
00007957b0ddb7f5  lea rsi, [rsp+0x10]
00007957b0ddb7fa  lea rdx, [rsp+0x20]
00007957b0ddb7ff  lea rcx, [rsp+0x30]
00007957b0ddb804  mov r8d, 0x00
00007957b0ddb80a  lea r9, [r15+0x3A8]
00007957b0ddb811  movaps [rdi], xmm12
00007957b0ddb815  movaps [rsi], xmm3
00007957b0ddb818  movaps [rdx], xmm14
00007957b0ddb81c  movaps [rcx], xmm5
00007957b0ddb81f  mov rax, 0x56E396DF1A50
00007957b0ddb829  call rax
00007957b0ddb82b  movaps xmm12, [rsp]
00007957b0ddb830  add rsp, 0x40
00007957b0ddb834  vmovaps xmm0, [rsp]
00007957b0ddb839  vmovaps xmm1, [rsp+0x10]
00007957b0ddb83f  vmovaps xmm2, [rsp+0x20]
00007957b0ddb845  vmovaps xmm3, [rsp+0x30]
00007957b0ddb84b  vmovaps xmm4, [rsp+0x40]
00007957b0ddb851  vmovaps xmm5, [rsp+0x50]
00007957b0ddb857  vmovaps xmm6, [rsp+0x60]
00007957b0ddb85d  vmovaps xmm7, [rsp+0x70]
00007957b0ddb863  vmovaps xmm8, [rsp+0x80]
00007957b0ddb86c  vmovaps xmm9, [rsp+0x90]
00007957b0ddb875  vmovaps xmm10, [rsp+0xA0]
00007957b0ddb87e  vmovaps xmm11, [rsp+0xB0]
00007957b0ddb887  vmovaps xmm13, [rsp+0xC0]
00007957b0ddb890  vmovaps xmm14, [rsp+0xD0]
00007957b0ddb899  vmovaps xmm15, [rsp+0xE0]
00007957b0ddb8a2  add rsp, 0xF0
00007957b0ddb8a9  pop r11
00007957b0ddb8ab  pop r10
00007957b0ddb8ad  pop r9
00007957b0ddb8af  pop r8
00007957b0ddb8b1  pop rsi
00007957b0ddb8b2  pop rdi
00007957b0ddb8b3  pop rdx
00007957b0ddb8b4  pop rcx
00007957b0ddb8b5  pop rax
00007957b0ddb8b6  add rsp, 0x08
00007957b0ddb8ba  jmp 0x00007957B0DDA256
00007957b0ddb8bf  sub rsp, 0x08
00007957b0ddb8c3  push rax
00007957b0ddb8c4  push rcx
00007957b0ddb8c5  push rdx
00007957b0ddb8c6  push rdi
00007957b0ddb8c7  push rsi
00007957b0ddb8c8  push r8
00007957b0ddb8ca  push r9
00007957b0ddb8cc  push r10
00007957b0ddb8ce  push r11
00007957b0ddb8d0  sub rsp, 0xF0
00007957b0ddb8d7  vmovaps [rsp], xmm0
00007957b0ddb8dc  vmovaps [rsp+0x10], xmm1
00007957b0ddb8e2  vmovaps [rsp+0x20], xmm2
00007957b0ddb8e8  vmovaps [rsp+0x30], xmm3
00007957b0ddb8ee  vmovaps [rsp+0x40], xmm4
00007957b0ddb8f4  vmovaps [rsp+0x50], xmm5
00007957b0ddb8fa  vmovaps [rsp+0x60], xmm6
00007957b0ddb900  vmovaps [rsp+0x70], xmm7
00007957b0ddb906  vmovaps [rsp+0x80], xmm8
00007957b0ddb90f  vmovaps [rsp+0x90], xmm9
00007957b0ddb918  vmovaps [rsp+0xA0], xmm11
00007957b0ddb921  vmovaps [rsp+0xB0], xmm12
00007957b0ddb92a  vmovaps [rsp+0xC0], xmm13
00007957b0ddb933  vmovaps [rsp+0xD0], xmm14
00007957b0ddb93c  vmovaps [rsp+0xE0], xmm15
00007957b0ddb945  sub rsp, 0x40
00007957b0ddb949  lea rdi, [rsp]
00007957b0ddb94d  lea rsi, [rsp+0x10]
00007957b0ddb952  lea rdx, [rsp+0x20]
00007957b0ddb957  lea rcx, [rsp+0x30]
00007957b0ddb95c  mov r8d, 0x00
00007957b0ddb962  lea r9, [r15+0x3A8]
00007957b0ddb969  movaps [rdi], xmm10
00007957b0ddb96d  movaps [rsi], xmm9
00007957b0ddb971  movaps [rdx], xmm7
00007957b0ddb974  movaps [rcx], xmm14
00007957b0ddb978  mov rax, 0x56E396DF1A50
00007957b0ddb982  call rax
00007957b0ddb984  movaps xmm10, [rsp]
00007957b0ddb989  add rsp, 0x40
00007957b0ddb98d  vmovaps xmm0, [rsp]
00007957b0ddb992  vmovaps xmm1, [rsp+0x10]
00007957b0ddb998  vmovaps xmm2, [rsp+0x20]
00007957b0ddb99e  vmovaps xmm3, [rsp+0x30]
00007957b0ddb9a4  vmovaps xmm4, [rsp+0x40]
00007957b0ddb9aa  vmovaps xmm5, [rsp+0x50]
00007957b0ddb9b0  vmovaps xmm6, [rsp+0x60]
00007957b0ddb9b6  vmovaps xmm7, [rsp+0x70]
00007957b0ddb9bc  vmovaps xmm8, [rsp+0x80]
00007957b0ddb9c5  vmovaps xmm9, [rsp+0x90]
00007957b0ddb9ce  vmovaps xmm11, [rsp+0xA0]
00007957b0ddb9d7  vmovaps xmm12, [rsp+0xB0]
00007957b0ddb9e0  vmovaps xmm13, [rsp+0xC0]
00007957b0ddb9e9  vmovaps xmm14, [rsp+0xD0]
00007957b0ddb9f2  vmovaps xmm15, [rsp+0xE0]
00007957b0ddb9fb  add rsp, 0xF0
00007957b0ddba02  pop r11
00007957b0ddba04  pop r10
00007957b0ddba06  pop r9
00007957b0ddba08  pop r8
00007957b0ddba0a  pop rsi
00007957b0ddba0b  pop rdi
00007957b0ddba0c  pop rdx
00007957b0ddba0d  pop rcx
00007957b0ddba0e  pop rax
00007957b0ddba0f  add rsp, 0x08
00007957b0ddba13  jmp 0x00007957B0DDA27C
00007957b0ddba18  call 0x00007957B0C0D4E0
00007957b0ddba1d  jmp 0x00007957B0DDA289
00007957b0ddba22  sub rsp, 0x08
00007957b0ddba26  push rax
00007957b0ddba27  push rcx
00007957b0ddba28  push rdx
00007957b0ddba29  push rdi
00007957b0ddba2a  push rsi
00007957b0ddba2b  push r8
00007957b0ddba2d  push r9
00007957b0ddba2f  push r10
00007957b0ddba31  push r11
00007957b0ddba33  sub rsp, 0xF0
00007957b0ddba3a  vmovaps [rsp], xmm0
00007957b0ddba3f  vmovaps [rsp+0x10], xmm1
00007957b0ddba45  vmovaps [rsp+0x20], xmm2
00007957b0ddba4b  vmovaps [rsp+0x30], xmm3
00007957b0ddba51  vmovaps [rsp+0x40], xmm4
00007957b0ddba57  vmovaps [rsp+0x50], xmm6
00007957b0ddba5d  vmovaps [rsp+0x60], xmm7
00007957b0ddba63  vmovaps [rsp+0x70], xmm8
00007957b0ddba69  vmovaps [rsp+0x80], xmm9
00007957b0ddba72  vmovaps [rsp+0x90], xmm10
00007957b0ddba7b  vmovaps [rsp+0xA0], xmm11
00007957b0ddba84  vmovaps [rsp+0xB0], xmm12
00007957b0ddba8d  vmovaps [rsp+0xC0], xmm13
00007957b0ddba96  vmovaps [rsp+0xD0], xmm14
00007957b0ddba9f  vmovaps [rsp+0xE0], xmm15
00007957b0ddbaa8  sub rsp, 0x40
00007957b0ddbaac  lea rdi, [rsp]
00007957b0ddbab0  lea rsi, [rsp+0x10]
00007957b0ddbab5  lea rdx, [rsp+0x20]
00007957b0ddbaba  lea rcx, [rsp+0x30]
00007957b0ddbabf  mov r8d, 0x00
00007957b0ddbac5  lea r9, [r15+0x3A8]
00007957b0ddbacc  movaps [rdi], xmm5
00007957b0ddbacf  movaps [rsi], xmm6
00007957b0ddbad2  movaps [rdx], xmm7
00007957b0ddbad5  movaps [rcx], xmm9
00007957b0ddbad9  mov rax, 0x56E396DF1A50
00007957b0ddbae3  call rax
00007957b0ddbae5  movaps xmm5, [rsp]
00007957b0ddbae9  add rsp, 0x40
00007957b0ddbaed  vmovaps xmm0, [rsp]
00007957b0ddbaf2  vmovaps xmm1, [rsp+0x10]
00007957b0ddbaf8  vmovaps xmm2, [rsp+0x20]
00007957b0ddbafe  vmovaps xmm3, [rsp+0x30]
00007957b0ddbb04  vmovaps xmm4, [rsp+0x40]
00007957b0ddbb0a  vmovaps xmm6, [rsp+0x50]
00007957b0ddbb10  vmovaps xmm7, [rsp+0x60]
00007957b0ddbb16  vmovaps xmm8, [rsp+0x70]
00007957b0ddbb1c  vmovaps xmm9, [rsp+0x80]
00007957b0ddbb25  vmovaps xmm10, [rsp+0x90]
00007957b0ddbb2e  vmovaps xmm11, [rsp+0xA0]
00007957b0ddbb37  vmovaps xmm12, [rsp+0xB0]
00007957b0ddbb40  vmovaps xmm13, [rsp+0xC0]
00007957b0ddbb49  vmovaps xmm14, [rsp+0xD0]
00007957b0ddbb52  vmovaps xmm15, [rsp+0xE0]
00007957b0ddbb5b  add rsp, 0xF0
00007957b0ddbb62  pop r11
00007957b0ddbb64  pop r10
00007957b0ddbb66  pop r9
00007957b0ddbb68  pop r8
00007957b0ddbb6a  pop rsi
00007957b0ddbb6b  pop rdi
00007957b0ddbb6c  pop rdx
00007957b0ddbb6d  pop rcx
00007957b0ddbb6e  pop rax
00007957b0ddbb6f  add rsp, 0x08
00007957b0ddbb73  jmp 0x00007957B0DDA2BB
00007957b0ddbb78  sub rsp, 0x08
00007957b0ddbb7c  push rax
00007957b0ddbb7d  push rcx
00007957b0ddbb7e  push rdx
00007957b0ddbb7f  push rdi
00007957b0ddbb80  push rsi
00007957b0ddbb81  push r8
00007957b0ddbb83  push r9
00007957b0ddbb85  push r10
00007957b0ddbb87  push r11
00007957b0ddbb89  sub rsp, 0xF0
00007957b0ddbb90  vmovaps [rsp], xmm0
00007957b0ddbb95  vmovaps [rsp+0x10], xmm1
00007957b0ddbb9b  vmovaps [rsp+0x20], xmm2
00007957b0ddbba1  vmovaps [rsp+0x30], xmm3
00007957b0ddbba7  vmovaps [rsp+0x40], xmm4
00007957b0ddbbad  vmovaps [rsp+0x50], xmm5
00007957b0ddbbb3  vmovaps [rsp+0x60], xmm6
00007957b0ddbbb9  vmovaps [rsp+0x70], xmm8
00007957b0ddbbbf  vmovaps [rsp+0x80], xmm9
00007957b0ddbbc8  vmovaps [rsp+0x90], xmm10
00007957b0ddbbd1  vmovaps [rsp+0xA0], xmm11
00007957b0ddbbda  vmovaps [rsp+0xB0], xmm12
00007957b0ddbbe3  vmovaps [rsp+0xC0], xmm13
00007957b0ddbbec  vmovaps [rsp+0xD0], xmm14
00007957b0ddbbf5  vmovaps [rsp+0xE0], xmm15
00007957b0ddbbfe  sub rsp, 0x40
00007957b0ddbc02  lea rdi, [rsp]
00007957b0ddbc06  lea rsi, [rsp+0x10]
00007957b0ddbc0b  lea rdx, [rsp+0x20]
00007957b0ddbc10  lea rcx, [rsp+0x30]
00007957b0ddbc15  mov r8d, 0x00
00007957b0ddbc1b  lea r9, [r15+0x3A8]
00007957b0ddbc22  movaps [rdi], xmm7
00007957b0ddbc25  movaps [rsi], xmm13
00007957b0ddbc29  movaps [rdx], xmm1
00007957b0ddbc2c  movaps [rcx], xmm9
00007957b0ddbc30  mov rax, 0x56E396DF1A50
00007957b0ddbc3a  call rax
00007957b0ddbc3c  movaps xmm7, [rsp]
00007957b0ddbc40  add rsp, 0x40
00007957b0ddbc44  vmovaps xmm0, [rsp]
00007957b0ddbc49  vmovaps xmm1, [rsp+0x10]
00007957b0ddbc4f  vmovaps xmm2, [rsp+0x20]
00007957b0ddbc55  vmovaps xmm3, [rsp+0x30]
00007957b0ddbc5b  vmovaps xmm4, [rsp+0x40]
00007957b0ddbc61  vmovaps xmm5, [rsp+0x50]
00007957b0ddbc67  vmovaps xmm6, [rsp+0x60]
00007957b0ddbc6d  vmovaps xmm8, [rsp+0x70]
00007957b0ddbc73  vmovaps xmm9, [rsp+0x80]
00007957b0ddbc7c  vmovaps xmm10, [rsp+0x90]
00007957b0ddbc85  vmovaps xmm11, [rsp+0xA0]
00007957b0ddbc8e  vmovaps xmm12, [rsp+0xB0]
00007957b0ddbc97  vmovaps xmm13, [rsp+0xC0]
00007957b0ddbca0  vmovaps xmm14, [rsp+0xD0]
00007957b0ddbca9  vmovaps xmm15, [rsp+0xE0]
00007957b0ddbcb2  add rsp, 0xF0
00007957b0ddbcb9  pop r11
00007957b0ddbcbb  pop r10
00007957b0ddbcbd  pop r9
00007957b0ddbcbf  pop r8
00007957b0ddbcc1  pop rsi
00007957b0ddbcc2  pop rdi
00007957b0ddbcc3  pop rdx
00007957b0ddbcc4  pop rcx
00007957b0ddbcc5  pop rax
00007957b0ddbcc6  add rsp, 0x08
00007957b0ddbcca  jmp 0x00007957B0DDA2E0
00007957b0ddbccf  call 0x00007957B0C0C260
00007957b0ddbcd4  jmp 0x00007957B0DDA303
00007957b0ddbcd9  call 0x00007957B0C07890
00007957b0ddbcde  jmp 0x00007957B0DDA30D
00007957b0ddbce3  sub rsp, 0x08
00007957b0ddbce7  push rax
00007957b0ddbce8  push rcx
00007957b0ddbce9  push rdx
00007957b0ddbcea  push rdi
00007957b0ddbceb  push rsi
00007957b0ddbcec  push r8
00007957b0ddbcee  push r9
00007957b0ddbcf0  push r10
00007957b0ddbcf2  push r11
00007957b0ddbcf4  sub rsp, 0xF0
00007957b0ddbcfb  vmovaps [rsp], xmm0
00007957b0ddbd00  vmovaps [rsp+0x10], xmm1
00007957b0ddbd06  vmovaps [rsp+0x20], xmm3
00007957b0ddbd0c  vmovaps [rsp+0x30], xmm4
00007957b0ddbd12  vmovaps [rsp+0x40], xmm5
00007957b0ddbd18  vmovaps [rsp+0x50], xmm6
00007957b0ddbd1e  vmovaps [rsp+0x60], xmm7
00007957b0ddbd24  vmovaps [rsp+0x70], xmm8
00007957b0ddbd2a  vmovaps [rsp+0x80], xmm9
00007957b0ddbd33  vmovaps [rsp+0x90], xmm10
00007957b0ddbd3c  vmovaps [rsp+0xA0], xmm11
00007957b0ddbd45  vmovaps [rsp+0xB0], xmm12
00007957b0ddbd4e  vmovaps [rsp+0xC0], xmm13
00007957b0ddbd57  vmovaps [rsp+0xD0], xmm14
00007957b0ddbd60  vmovaps [rsp+0xE0], xmm15
00007957b0ddbd69  sub rsp, 0x40
00007957b0ddbd6d  lea rdi, [rsp]
00007957b0ddbd71  lea rsi, [rsp+0x10]
00007957b0ddbd76  lea rdx, [rsp+0x20]
00007957b0ddbd7b  lea rcx, [rsp+0x30]
00007957b0ddbd80  mov r8d, 0x00
00007957b0ddbd86  lea r9, [r15+0x3A8]
00007957b0ddbd8d  movaps [rdi], xmm2
00007957b0ddbd90  movaps [rsi], xmm12
00007957b0ddbd94  movaps [rdx], xmm6
00007957b0ddbd97  movaps [rcx], xmm3
00007957b0ddbd9a  mov rax, 0x56E396DF1A50
00007957b0ddbda4  call rax
00007957b0ddbda6  movaps xmm2, [rsp]
00007957b0ddbdaa  add rsp, 0x40
00007957b0ddbdae  vmovaps xmm0, [rsp]
00007957b0ddbdb3  vmovaps xmm1, [rsp+0x10]
00007957b0ddbdb9  vmovaps xmm3, [rsp+0x20]
00007957b0ddbdbf  vmovaps xmm4, [rsp+0x30]
00007957b0ddbdc5  vmovaps xmm5, [rsp+0x40]
00007957b0ddbdcb  vmovaps xmm6, [rsp+0x50]
00007957b0ddbdd1  vmovaps xmm7, [rsp+0x60]
00007957b0ddbdd7  vmovaps xmm8, [rsp+0x70]
00007957b0ddbddd  vmovaps xmm9, [rsp+0x80]
00007957b0ddbde6  vmovaps xmm10, [rsp+0x90]
00007957b0ddbdef  vmovaps xmm11, [rsp+0xA0]
00007957b0ddbdf8  vmovaps xmm12, [rsp+0xB0]
00007957b0ddbe01  vmovaps xmm13, [rsp+0xC0]
00007957b0ddbe0a  vmovaps xmm14, [rsp+0xD0]
00007957b0ddbe13  vmovaps xmm15, [rsp+0xE0]
00007957b0ddbe1c  add rsp, 0xF0
00007957b0ddbe23  pop r11
00007957b0ddbe25  pop r10
00007957b0ddbe27  pop r9
00007957b0ddbe29  pop r8
00007957b0ddbe2b  pop rsi
00007957b0ddbe2c  pop rdi
00007957b0ddbe2d  pop rdx
00007957b0ddbe2e  pop rcx
00007957b0ddbe2f  pop rax
00007957b0ddbe30  add rsp, 0x08
00007957b0ddbe34  jmp 0x00007957B0DDA353
00007957b0ddbe39  sub rsp, 0x08
00007957b0ddbe3d  push rax
00007957b0ddbe3e  push rcx
00007957b0ddbe3f  push rdx
00007957b0ddbe40  push rdi
00007957b0ddbe41  push rsi
00007957b0ddbe42  push r8
00007957b0ddbe44  push r9
00007957b0ddbe46  push r10
00007957b0ddbe48  push r11
00007957b0ddbe4a  sub rsp, 0xF0
00007957b0ddbe51  vmovaps [rsp], xmm0
00007957b0ddbe56  vmovaps [rsp+0x10], xmm1
00007957b0ddbe5c  vmovaps [rsp+0x20], xmm2
00007957b0ddbe62  vmovaps [rsp+0x30], xmm3
00007957b0ddbe68  vmovaps [rsp+0x40], xmm4
00007957b0ddbe6e  vmovaps [rsp+0x50], xmm5
00007957b0ddbe74  vmovaps [rsp+0x60], xmm7
00007957b0ddbe7a  vmovaps [rsp+0x70], xmm8
00007957b0ddbe80  vmovaps [rsp+0x80], xmm9
00007957b0ddbe89  vmovaps [rsp+0x90], xmm10
00007957b0ddbe92  vmovaps [rsp+0xA0], xmm11
00007957b0ddbe9b  vmovaps [rsp+0xB0], xmm12
00007957b0ddbea4  vmovaps [rsp+0xC0], xmm13
00007957b0ddbead  vmovaps [rsp+0xD0], xmm14
00007957b0ddbeb6  vmovaps [rsp+0xE0], xmm15
00007957b0ddbebf  sub rsp, 0x40
00007957b0ddbec3  lea rdi, [rsp]
00007957b0ddbec7  lea rsi, [rsp+0x10]
00007957b0ddbecc  lea rdx, [rsp+0x20]
00007957b0ddbed1  lea rcx, [rsp+0x30]
00007957b0ddbed6  mov r8d, 0x00
00007957b0ddbedc  lea r9, [r15+0x3A8]
00007957b0ddbee3  movaps [rdi], xmm6
00007957b0ddbee6  movaps [rsi], xmm10
00007957b0ddbeea  movaps [rdx], xmm12
00007957b0ddbeee  movaps [rcx], xmm1
00007957b0ddbef1  mov rax, 0x56E396DF1A50
00007957b0ddbefb  call rax
00007957b0ddbefd  movaps xmm6, [rsp]
00007957b0ddbf01  add rsp, 0x40
00007957b0ddbf05  vmovaps xmm0, [rsp]
00007957b0ddbf0a  vmovaps xmm1, [rsp+0x10]
00007957b0ddbf10  vmovaps xmm2, [rsp+0x20]
00007957b0ddbf16  vmovaps xmm3, [rsp+0x30]
00007957b0ddbf1c  vmovaps xmm4, [rsp+0x40]
00007957b0ddbf22  vmovaps xmm5, [rsp+0x50]
00007957b0ddbf28  vmovaps xmm7, [rsp+0x60]
00007957b0ddbf2e  vmovaps xmm8, [rsp+0x70]
00007957b0ddbf34  vmovaps xmm9, [rsp+0x80]
00007957b0ddbf3d  vmovaps xmm10, [rsp+0x90]
00007957b0ddbf46  vmovaps xmm11, [rsp+0xA0]
00007957b0ddbf4f  vmovaps xmm12, [rsp+0xB0]
00007957b0ddbf58  vmovaps xmm13, [rsp+0xC0]
00007957b0ddbf61  vmovaps xmm14, [rsp+0xD0]
00007957b0ddbf6a  vmovaps xmm15, [rsp+0xE0]
00007957b0ddbf73  add rsp, 0xF0
00007957b0ddbf7a  pop r11
00007957b0ddbf7c  pop r10
00007957b0ddbf7e  pop r9
00007957b0ddbf80  pop r8
00007957b0ddbf82  pop rsi
00007957b0ddbf83  pop rdi
00007957b0ddbf84  pop rdx
00007957b0ddbf85  pop rcx
00007957b0ddbf86  pop rax
00007957b0ddbf87  add rsp, 0x08
00007957b0ddbf8b  jmp 0x00007957B0DDA381
00007957b0ddbf90  sub rsp, 0x08
00007957b0ddbf94  push rax
00007957b0ddbf95  push rcx
00007957b0ddbf96  push rdx
00007957b0ddbf97  push rdi
00007957b0ddbf98  push rsi
00007957b0ddbf99  push r8
00007957b0ddbf9b  push r9
00007957b0ddbf9d  push r10
00007957b0ddbf9f  push r11
00007957b0ddbfa1  sub rsp, 0xF0
00007957b0ddbfa8  vmovaps [rsp], xmm0
00007957b0ddbfad  vmovaps [rsp+0x10], xmm1
00007957b0ddbfb3  vmovaps [rsp+0x20], xmm2
00007957b0ddbfb9  vmovaps [rsp+0x30], xmm3
00007957b0ddbfbf  vmovaps [rsp+0x40], xmm4
00007957b0ddbfc5  vmovaps [rsp+0x50], xmm5
00007957b0ddbfcb  vmovaps [rsp+0x60], xmm6
00007957b0ddbfd1  vmovaps [rsp+0x70], xmm7
00007957b0ddbfd7  vmovaps [rsp+0x80], xmm8
00007957b0ddbfe0  vmovaps [rsp+0x90], xmm9
00007957b0ddbfe9  vmovaps [rsp+0xA0], xmm11
00007957b0ddbff2  vmovaps [rsp+0xB0], xmm12
00007957b0ddbffb  vmovaps [rsp+0xC0], xmm13
00007957b0ddc004  vmovaps [rsp+0xD0], xmm14
00007957b0ddc00d  vmovaps [rsp+0xE0], xmm15
00007957b0ddc016  sub rsp, 0x40
00007957b0ddc01a  lea rdi, [rsp]
00007957b0ddc01e  lea rsi, [rsp+0x10]
00007957b0ddc023  lea rdx, [rsp+0x20]
00007957b0ddc028  lea rcx, [rsp+0x30]
00007957b0ddc02d  mov r8d, 0x00
00007957b0ddc033  lea r9, [r15+0x3A8]
00007957b0ddc03a  movaps [rdi], xmm10
00007957b0ddc03e  movaps [rsi], xmm5
00007957b0ddc041  movaps [rdx], xmm12
00007957b0ddc045  movaps [rcx], xmm1
00007957b0ddc048  mov rax, 0x56E396DF1A50
00007957b0ddc052  call rax
00007957b0ddc054  movaps xmm10, [rsp]
00007957b0ddc059  add rsp, 0x40
00007957b0ddc05d  vmovaps xmm0, [rsp]
00007957b0ddc062  vmovaps xmm1, [rsp+0x10]
00007957b0ddc068  vmovaps xmm2, [rsp+0x20]
00007957b0ddc06e  vmovaps xmm3, [rsp+0x30]
00007957b0ddc074  vmovaps xmm4, [rsp+0x40]
00007957b0ddc07a  vmovaps xmm5, [rsp+0x50]
00007957b0ddc080  vmovaps xmm6, [rsp+0x60]
00007957b0ddc086  vmovaps xmm7, [rsp+0x70]
00007957b0ddc08c  vmovaps xmm8, [rsp+0x80]
00007957b0ddc095  vmovaps xmm9, [rsp+0x90]
00007957b0ddc09e  vmovaps xmm11, [rsp+0xA0]
00007957b0ddc0a7  vmovaps xmm12, [rsp+0xB0]
00007957b0ddc0b0  vmovaps xmm13, [rsp+0xC0]
00007957b0ddc0b9  vmovaps xmm14, [rsp+0xD0]
00007957b0ddc0c2  vmovaps xmm15, [rsp+0xE0]
00007957b0ddc0cb  add rsp, 0xF0
00007957b0ddc0d2  pop r11
00007957b0ddc0d4  pop r10
00007957b0ddc0d6  pop r9
00007957b0ddc0d8  pop r8
00007957b0ddc0da  pop rsi
00007957b0ddc0db  pop rdi
00007957b0ddc0dc  pop rdx
00007957b0ddc0dd  pop rcx
00007957b0ddc0de  pop rax
00007957b0ddc0df  add rsp, 0x08
00007957b0ddc0e3  jmp 0x00007957B0DDA3B0
00007957b0ddc0e8  sub rsp, 0x08
00007957b0ddc0ec  push rax
00007957b0ddc0ed  push rcx
00007957b0ddc0ee  push rdx
00007957b0ddc0ef  push rdi
00007957b0ddc0f0  push rsi
00007957b0ddc0f1  push r8
00007957b0ddc0f3  push r9
00007957b0ddc0f5  push r10
00007957b0ddc0f7  push r11
00007957b0ddc0f9  sub rsp, 0xF0
00007957b0ddc100  vmovaps [rsp], xmm0
00007957b0ddc105  vmovaps [rsp+0x10], xmm1
00007957b0ddc10b  vmovaps [rsp+0x20], xmm2
00007957b0ddc111  vmovaps [rsp+0x30], xmm3
00007957b0ddc117  vmovaps [rsp+0x40], xmm4
00007957b0ddc11d  vmovaps [rsp+0x50], xmm5
00007957b0ddc123  vmovaps [rsp+0x60], xmm6
00007957b0ddc129  vmovaps [rsp+0x70], xmm7
00007957b0ddc12f  vmovaps [rsp+0x80], xmm8
00007957b0ddc138  vmovaps [rsp+0x90], xmm9
00007957b0ddc141  vmovaps [rsp+0xA0], xmm10
00007957b0ddc14a  vmovaps [rsp+0xB0], xmm11
00007957b0ddc153  vmovaps [rsp+0xC0], xmm13
00007957b0ddc15c  vmovaps [rsp+0xD0], xmm14
00007957b0ddc165  vmovaps [rsp+0xE0], xmm15
00007957b0ddc16e  sub rsp, 0x40
00007957b0ddc172  lea rdi, [rsp]
00007957b0ddc176  lea rsi, [rsp+0x10]
00007957b0ddc17b  lea rdx, [rsp+0x20]
00007957b0ddc180  lea rcx, [rsp+0x30]
00007957b0ddc185  mov r8d, 0x00
00007957b0ddc18b  lea r9, [r15+0x3A8]
00007957b0ddc192  movaps [rdi], xmm12
00007957b0ddc196  movaps [rsi], xmm7
00007957b0ddc199  movaps [rdx], xmm15
00007957b0ddc19d  movaps [rcx], xmm1
00007957b0ddc1a0  mov rax, 0x56E396DF1A50
00007957b0ddc1aa  call rax
00007957b0ddc1ac  movaps xmm12, [rsp]
00007957b0ddc1b1  add rsp, 0x40
00007957b0ddc1b5  vmovaps xmm0, [rsp]
00007957b0ddc1ba  vmovaps xmm1, [rsp+0x10]
00007957b0ddc1c0  vmovaps xmm2, [rsp+0x20]
00007957b0ddc1c6  vmovaps xmm3, [rsp+0x30]
00007957b0ddc1cc  vmovaps xmm4, [rsp+0x40]
00007957b0ddc1d2  vmovaps xmm5, [rsp+0x50]
00007957b0ddc1d8  vmovaps xmm6, [rsp+0x60]
00007957b0ddc1de  vmovaps xmm7, [rsp+0x70]
00007957b0ddc1e4  vmovaps xmm8, [rsp+0x80]
00007957b0ddc1ed  vmovaps xmm9, [rsp+0x90]
00007957b0ddc1f6  vmovaps xmm10, [rsp+0xA0]
00007957b0ddc1ff  vmovaps xmm11, [rsp+0xB0]
00007957b0ddc208  vmovaps xmm13, [rsp+0xC0]
00007957b0ddc211  vmovaps xmm14, [rsp+0xD0]
00007957b0ddc21a  vmovaps xmm15, [rsp+0xE0]
00007957b0ddc223  add rsp, 0xF0
00007957b0ddc22a  pop r11
00007957b0ddc22c  pop r10
00007957b0ddc22e  pop r9
00007957b0ddc230  pop r8
00007957b0ddc232  pop rsi
00007957b0ddc233  pop rdi
00007957b0ddc234  pop rdx
00007957b0ddc235  pop rcx
00007957b0ddc236  pop rax
00007957b0ddc237  add rsp, 0x08
00007957b0ddc23b  jmp 0x00007957B0DDA3D9
00007957b0ddc240  call 0x00007957B0BFF430
00007957b0ddc245  jmp 0x00007957B0DDA3E3
00007957b0ddc24a  call 0x00007957B0C0E760
00007957b0ddc24f  jmp 0x00007957B0DDA3ED
00007957b0ddc254  sub rsp, 0x08
00007957b0ddc258  push rax
00007957b0ddc259  push rcx
00007957b0ddc25a  push rdx
00007957b0ddc25b  push rdi
00007957b0ddc25c  push rsi
00007957b0ddc25d  push r8
00007957b0ddc25f  push r9
00007957b0ddc261  push r10
00007957b0ddc263  push r11
00007957b0ddc265  sub rsp, 0xF0
00007957b0ddc26c  vmovaps [rsp], xmm0
00007957b0ddc271  vmovaps [rsp+0x10], xmm1
00007957b0ddc277  vmovaps [rsp+0x20], xmm2
00007957b0ddc27d  vmovaps [rsp+0x30], xmm3
00007957b0ddc283  vmovaps [rsp+0x40], xmm4
00007957b0ddc289  vmovaps [rsp+0x50], xmm5
00007957b0ddc28f  vmovaps [rsp+0x60], xmm6
00007957b0ddc295  vmovaps [rsp+0x70], xmm8
00007957b0ddc29b  vmovaps [rsp+0x80], xmm9
00007957b0ddc2a4  vmovaps [rsp+0x90], xmm10
00007957b0ddc2ad  vmovaps [rsp+0xA0], xmm11
00007957b0ddc2b6  vmovaps [rsp+0xB0], xmm12
00007957b0ddc2bf  vmovaps [rsp+0xC0], xmm13
00007957b0ddc2c8  vmovaps [rsp+0xD0], xmm14
00007957b0ddc2d1  vmovaps [rsp+0xE0], xmm15
00007957b0ddc2da  sub rsp, 0x40
00007957b0ddc2de  lea rdi, [rsp]
00007957b0ddc2e2  lea rsi, [rsp+0x10]
00007957b0ddc2e7  lea rdx, [rsp+0x20]
00007957b0ddc2ec  lea rcx, [rsp+0x30]
00007957b0ddc2f1  mov r8d, 0x00
00007957b0ddc2f7  lea r9, [r15+0x3A8]
00007957b0ddc2fe  movaps [rdi], xmm7
00007957b0ddc301  movaps [rsi], xmm2
00007957b0ddc304  movaps [rdx], xmm9
00007957b0ddc308  movaps [rcx], xmm11
00007957b0ddc30c  mov rax, 0x56E396DF1A50
00007957b0ddc316  call rax
00007957b0ddc318  movaps xmm7, [rsp]
00007957b0ddc31c  add rsp, 0x40
00007957b0ddc320  vmovaps xmm0, [rsp]
00007957b0ddc325  vmovaps xmm1, [rsp+0x10]
00007957b0ddc32b  vmovaps xmm2, [rsp+0x20]
00007957b0ddc331  vmovaps xmm3, [rsp+0x30]
00007957b0ddc337  vmovaps xmm4, [rsp+0x40]
00007957b0ddc33d  vmovaps xmm5, [rsp+0x50]
00007957b0ddc343  vmovaps xmm6, [rsp+0x60]
00007957b0ddc349  vmovaps xmm8, [rsp+0x70]
00007957b0ddc34f  vmovaps xmm9, [rsp+0x80]
00007957b0ddc358  vmovaps xmm10, [rsp+0x90]
00007957b0ddc361  vmovaps xmm11, [rsp+0xA0]
00007957b0ddc36a  vmovaps xmm12, [rsp+0xB0]
00007957b0ddc373  vmovaps xmm13, [rsp+0xC0]
00007957b0ddc37c  vmovaps xmm14, [rsp+0xD0]
00007957b0ddc385  vmovaps xmm15, [rsp+0xE0]
00007957b0ddc38e  add rsp, 0xF0
00007957b0ddc395  pop r11
00007957b0ddc397  pop r10
00007957b0ddc399  pop r9
00007957b0ddc39b  pop r8
00007957b0ddc39d  pop rsi
00007957b0ddc39e  pop rdi
00007957b0ddc39f  pop rdx
00007957b0ddc3a0  pop rcx
00007957b0ddc3a1  pop rax
00007957b0ddc3a2  add rsp, 0x08
00007957b0ddc3a6  jmp 0x00007957B0DDA421
00007957b0ddc3ab  sub rsp, 0x08
00007957b0ddc3af  push rax
00007957b0ddc3b0  push rcx
00007957b0ddc3b1  push rdx
00007957b0ddc3b2  push rdi
00007957b0ddc3b3  push rsi
00007957b0ddc3b4  push r8
00007957b0ddc3b6  push r9
00007957b0ddc3b8  push r10
00007957b0ddc3ba  push r11
00007957b0ddc3bc  sub rsp, 0xF0
00007957b0ddc3c3  vmovaps [rsp], xmm0
00007957b0ddc3c8  vmovaps [rsp+0x10], xmm1
00007957b0ddc3ce  vmovaps [rsp+0x20], xmm2
00007957b0ddc3d4  vmovaps [rsp+0x30], xmm3
00007957b0ddc3da  vmovaps [rsp+0x40], xmm4
00007957b0ddc3e0  vmovaps [rsp+0x50], xmm5
00007957b0ddc3e6  vmovaps [rsp+0x60], xmm6
00007957b0ddc3ec  vmovaps [rsp+0x70], xmm7
00007957b0ddc3f2  vmovaps [rsp+0x80], xmm8
00007957b0ddc3fb  vmovaps [rsp+0x90], xmm10
00007957b0ddc404  vmovaps [rsp+0xA0], xmm11
00007957b0ddc40d  vmovaps [rsp+0xB0], xmm12
00007957b0ddc416  vmovaps [rsp+0xC0], xmm13
00007957b0ddc41f  vmovaps [rsp+0xD0], xmm14
00007957b0ddc428  vmovaps [rsp+0xE0], xmm15
00007957b0ddc431  sub rsp, 0x40
00007957b0ddc435  lea rdi, [rsp]
00007957b0ddc439  lea rsi, [rsp+0x10]
00007957b0ddc43e  lea rdx, [rsp+0x20]
00007957b0ddc443  lea rcx, [rsp+0x30]
00007957b0ddc448  mov r8d, 0x00
00007957b0ddc44e  lea r9, [r15+0x3A8]
00007957b0ddc455  movaps [rdi], xmm9
00007957b0ddc459  movaps [rsi], xmm6
00007957b0ddc45c  movaps [rdx], xmm1
00007957b0ddc45f  movaps [rcx], xmm11
00007957b0ddc463  mov rax, 0x56E396DF1A50
00007957b0ddc46d  call rax
00007957b0ddc46f  movaps xmm9, [rsp]
00007957b0ddc474  add rsp, 0x40
00007957b0ddc478  vmovaps xmm0, [rsp]
00007957b0ddc47d  vmovaps xmm1, [rsp+0x10]
00007957b0ddc483  vmovaps xmm2, [rsp+0x20]
00007957b0ddc489  vmovaps xmm3, [rsp+0x30]
00007957b0ddc48f  vmovaps xmm4, [rsp+0x40]
00007957b0ddc495  vmovaps xmm5, [rsp+0x50]
00007957b0ddc49b  vmovaps xmm6, [rsp+0x60]
00007957b0ddc4a1  vmovaps xmm7, [rsp+0x70]
00007957b0ddc4a7  vmovaps xmm8, [rsp+0x80]
00007957b0ddc4b0  vmovaps xmm10, [rsp+0x90]
00007957b0ddc4b9  vmovaps xmm11, [rsp+0xA0]
00007957b0ddc4c2  vmovaps xmm12, [rsp+0xB0]
00007957b0ddc4cb  vmovaps xmm13, [rsp+0xC0]
00007957b0ddc4d4  vmovaps xmm14, [rsp+0xD0]
00007957b0ddc4dd  vmovaps xmm15, [rsp+0xE0]
00007957b0ddc4e6  add rsp, 0xF0
00007957b0ddc4ed  pop r11
00007957b0ddc4ef  pop r10
00007957b0ddc4f1  pop r9
00007957b0ddc4f3  pop r8
00007957b0ddc4f5  pop rsi
00007957b0ddc4f6  pop rdi
00007957b0ddc4f7  pop rdx
00007957b0ddc4f8  pop rcx
00007957b0ddc4f9  pop rax
00007957b0ddc4fa  add rsp, 0x08
00007957b0ddc4fe  jmp 0x00007957B0DDA447
00007957b0ddc503  sub rsp, 0x08
00007957b0ddc507  push rax
00007957b0ddc508  push rcx
00007957b0ddc509  push rdx
00007957b0ddc50a  push rdi
00007957b0ddc50b  push rsi
00007957b0ddc50c  push r8
00007957b0ddc50e  push r9
00007957b0ddc510  push r10
00007957b0ddc512  push r11
00007957b0ddc514  sub rsp, 0xF0
00007957b0ddc51b  vmovaps [rsp], xmm0
00007957b0ddc520  vmovaps [rsp+0x10], xmm1
00007957b0ddc526  vmovaps [rsp+0x20], xmm2
00007957b0ddc52c  vmovaps [rsp+0x30], xmm3
00007957b0ddc532  vmovaps [rsp+0x40], xmm4
00007957b0ddc538  vmovaps [rsp+0x50], xmm5
00007957b0ddc53e  vmovaps [rsp+0x60], xmm6
00007957b0ddc544  vmovaps [rsp+0x70], xmm7
00007957b0ddc54a  vmovaps [rsp+0x80], xmm8
00007957b0ddc553  vmovaps [rsp+0x90], xmm9
00007957b0ddc55c  vmovaps [rsp+0xA0], xmm10
00007957b0ddc565  vmovaps [rsp+0xB0], xmm12
00007957b0ddc56e  vmovaps [rsp+0xC0], xmm13
00007957b0ddc577  vmovaps [rsp+0xD0], xmm14
00007957b0ddc580  vmovaps [rsp+0xE0], xmm15
00007957b0ddc589  sub rsp, 0x40
00007957b0ddc58d  lea rdi, [rsp]
00007957b0ddc591  lea rsi, [rsp+0x10]
00007957b0ddc596  lea rdx, [rsp+0x20]
00007957b0ddc59b  lea rcx, [rsp+0x30]
00007957b0ddc5a0  mov r8d, 0x00
00007957b0ddc5a6  lea r9, [r15+0x3A8]
00007957b0ddc5ad  movaps [rdi], xmm11
00007957b0ddc5b1  movaps [rsi], xmm10
00007957b0ddc5b5  movaps [rdx], xmm8
00007957b0ddc5b9  movaps [rcx], xmm1
00007957b0ddc5bc  mov rax, 0x56E396DF1A50
00007957b0ddc5c6  call rax
00007957b0ddc5c8  movaps xmm11, [rsp]
00007957b0ddc5cd  add rsp, 0x40
00007957b0ddc5d1  vmovaps xmm0, [rsp]
00007957b0ddc5d6  vmovaps xmm1, [rsp+0x10]
00007957b0ddc5dc  vmovaps xmm2, [rsp+0x20]
00007957b0ddc5e2  vmovaps xmm3, [rsp+0x30]
00007957b0ddc5e8  vmovaps xmm4, [rsp+0x40]
00007957b0ddc5ee  vmovaps xmm5, [rsp+0x50]
00007957b0ddc5f4  vmovaps xmm6, [rsp+0x60]
00007957b0ddc5fa  vmovaps xmm7, [rsp+0x70]
00007957b0ddc600  vmovaps xmm8, [rsp+0x80]
00007957b0ddc609  vmovaps xmm9, [rsp+0x90]
00007957b0ddc612  vmovaps xmm10, [rsp+0xA0]
00007957b0ddc61b  vmovaps xmm12, [rsp+0xB0]
00007957b0ddc624  vmovaps xmm13, [rsp+0xC0]
00007957b0ddc62d  vmovaps xmm14, [rsp+0xD0]
00007957b0ddc636  vmovaps xmm15, [rsp+0xE0]
00007957b0ddc63f  add rsp, 0xF0
00007957b0ddc646  pop r11
00007957b0ddc648  pop r10
00007957b0ddc64a  pop r9
00007957b0ddc64c  pop r8
00007957b0ddc64e  pop rsi
00007957b0ddc64f  pop rdi
00007957b0ddc650  pop rdx
00007957b0ddc651  pop rcx
00007957b0ddc652  pop rax
00007957b0ddc653  add rsp, 0x08
00007957b0ddc657  jmp 0x00007957B0DDA46D
00007957b0ddc65c  sub rsp, 0x08
00007957b0ddc660  push rax
00007957b0ddc661  push rcx
00007957b0ddc662  push rdx
00007957b0ddc663  push rdi
00007957b0ddc664  push rsi
00007957b0ddc665  push r8
00007957b0ddc667  push r9
00007957b0ddc669  push r10
00007957b0ddc66b  push r11
00007957b0ddc66d  sub rsp, 0xF0
00007957b0ddc674  vmovaps [rsp], xmm0
00007957b0ddc679  vmovaps [rsp+0x10], xmm1
00007957b0ddc67f  vmovaps [rsp+0x20], xmm2
00007957b0ddc685  vmovaps [rsp+0x30], xmm3
00007957b0ddc68b  vmovaps [rsp+0x40], xmm4
00007957b0ddc691  vmovaps [rsp+0x50], xmm5
00007957b0ddc697  vmovaps [rsp+0x60], xmm6
00007957b0ddc69d  vmovaps [rsp+0x70], xmm7
00007957b0ddc6a3  vmovaps [rsp+0x80], xmm8
00007957b0ddc6ac  vmovaps [rsp+0x90], xmm9
00007957b0ddc6b5  vmovaps [rsp+0xA0], xmm11
00007957b0ddc6be  vmovaps [rsp+0xB0], xmm12
00007957b0ddc6c7  vmovaps [rsp+0xC0], xmm13
00007957b0ddc6d0  vmovaps [rsp+0xD0], xmm14
00007957b0ddc6d9  vmovaps [rsp+0xE0], xmm15
00007957b0ddc6e2  sub rsp, 0x40
00007957b0ddc6e6  lea rdi, [rsp]
00007957b0ddc6ea  lea rsi, [rsp+0x10]
00007957b0ddc6ef  lea rdx, [rsp+0x20]
00007957b0ddc6f4  lea rcx, [rsp+0x30]
00007957b0ddc6f9  mov r8d, 0x00
00007957b0ddc6ff  lea r9, [r15+0x3A8]
00007957b0ddc706  movaps [rdi], xmm10
00007957b0ddc70a  movaps [rsi], xmm12
00007957b0ddc70e  movaps [rdx], xmm13
00007957b0ddc712  movaps [rcx], xmm1
00007957b0ddc715  mov rax, 0x56E396DF1A50
00007957b0ddc71f  call rax
00007957b0ddc721  movaps xmm10, [rsp]
00007957b0ddc726  add rsp, 0x40
00007957b0ddc72a  vmovaps xmm0, [rsp]
00007957b0ddc72f  vmovaps xmm1, [rsp+0x10]
00007957b0ddc735  vmovaps xmm2, [rsp+0x20]
00007957b0ddc73b  vmovaps xmm3, [rsp+0x30]
00007957b0ddc741  vmovaps xmm4, [rsp+0x40]
00007957b0ddc747  vmovaps xmm5, [rsp+0x50]
00007957b0ddc74d  vmovaps xmm6, [rsp+0x60]
00007957b0ddc753  vmovaps xmm7, [rsp+0x70]
00007957b0ddc759  vmovaps xmm8, [rsp+0x80]
00007957b0ddc762  vmovaps xmm9, [rsp+0x90]
00007957b0ddc76b  vmovaps xmm11, [rsp+0xA0]
00007957b0ddc774  vmovaps xmm12, [rsp+0xB0]
00007957b0ddc77d  vmovaps xmm13, [rsp+0xC0]
00007957b0ddc786  vmovaps xmm14, [rsp+0xD0]
00007957b0ddc78f  vmovaps xmm15, [rsp+0xE0]
00007957b0ddc798  add rsp, 0xF0
00007957b0ddc79f  pop r11
00007957b0ddc7a1  pop r10
00007957b0ddc7a3  pop r9
00007957b0ddc7a5  pop r8
00007957b0ddc7a7  pop rsi
00007957b0ddc7a8  pop rdi
00007957b0ddc7a9  pop rdx
00007957b0ddc7aa  pop rcx
00007957b0ddc7ab  pop rax
00007957b0ddc7ac  add rsp, 0x08
00007957b0ddc7b0  jmp 0x00007957B0DDA493
00007957b0ddc7b5  call 0x00007957B0BFF430
00007957b0ddc7ba  jmp 0x00007957B0DDA49D
00007957b0ddc7bf  call 0x00007957B0C0C260
00007957b0ddc7c4  jmp 0x00007957B0DDA4A7
00007957b0ddc7c9  sub rsp, 0x08
00007957b0ddc7cd  push rax
00007957b0ddc7ce  push rcx
00007957b0ddc7cf  push rdx
00007957b0ddc7d0  push rdi
00007957b0ddc7d1  push rsi
00007957b0ddc7d2  push r8
00007957b0ddc7d4  push r9
00007957b0ddc7d6  push r10
00007957b0ddc7d8  push r11
00007957b0ddc7da  sub rsp, 0xF0
00007957b0ddc7e1  vmovaps [rsp], xmm0
00007957b0ddc7e6  vmovaps [rsp+0x10], xmm1
00007957b0ddc7ec  vmovaps [rsp+0x20], xmm2
00007957b0ddc7f2  vmovaps [rsp+0x30], xmm3
00007957b0ddc7f8  vmovaps [rsp+0x40], xmm4
00007957b0ddc7fe  vmovaps [rsp+0x50], xmm5
00007957b0ddc804  vmovaps [rsp+0x60], xmm6
00007957b0ddc80a  vmovaps [rsp+0x70], xmm7
00007957b0ddc810  vmovaps [rsp+0x80], xmm9
00007957b0ddc819  vmovaps [rsp+0x90], xmm10
00007957b0ddc822  vmovaps [rsp+0xA0], xmm11
00007957b0ddc82b  vmovaps [rsp+0xB0], xmm12
00007957b0ddc834  vmovaps [rsp+0xC0], xmm13
00007957b0ddc83d  vmovaps [rsp+0xD0], xmm14
00007957b0ddc846  vmovaps [rsp+0xE0], xmm15
00007957b0ddc84f  sub rsp, 0x40
00007957b0ddc853  lea rdi, [rsp]
00007957b0ddc857  lea rsi, [rsp+0x10]
00007957b0ddc85c  lea rdx, [rsp+0x20]
00007957b0ddc861  lea rcx, [rsp+0x30]
00007957b0ddc866  mov r8d, 0x00
00007957b0ddc86c  lea r9, [r15+0x3A8]
00007957b0ddc873  movaps [rdi], xmm8
00007957b0ddc877  movaps [rsi], xmm7
00007957b0ddc87a  movaps [rdx], xmm4
00007957b0ddc87d  movaps [rcx], xmm12
00007957b0ddc881  mov rax, 0x56E396DF1A50
00007957b0ddc88b  call rax
00007957b0ddc88d  movaps xmm8, [rsp]
00007957b0ddc892  add rsp, 0x40
00007957b0ddc896  vmovaps xmm0, [rsp]
00007957b0ddc89b  vmovaps xmm1, [rsp+0x10]
00007957b0ddc8a1  vmovaps xmm2, [rsp+0x20]
00007957b0ddc8a7  vmovaps xmm3, [rsp+0x30]
00007957b0ddc8ad  vmovaps xmm4, [rsp+0x40]
00007957b0ddc8b3  vmovaps xmm5, [rsp+0x50]
00007957b0ddc8b9  vmovaps xmm6, [rsp+0x60]
00007957b0ddc8bf  vmovaps xmm7, [rsp+0x70]
00007957b0ddc8c5  vmovaps xmm9, [rsp+0x80]
00007957b0ddc8ce  vmovaps xmm10, [rsp+0x90]
00007957b0ddc8d7  vmovaps xmm11, [rsp+0xA0]
00007957b0ddc8e0  vmovaps xmm12, [rsp+0xB0]
00007957b0ddc8e9  vmovaps xmm13, [rsp+0xC0]
00007957b0ddc8f2  vmovaps xmm14, [rsp+0xD0]
00007957b0ddc8fb  vmovaps xmm15, [rsp+0xE0]
00007957b0ddc904  add rsp, 0xF0
00007957b0ddc90b  pop r11
00007957b0ddc90d  pop r10
00007957b0ddc90f  pop r9
00007957b0ddc911  pop r8
00007957b0ddc913  pop rsi
00007957b0ddc914  pop rdi
00007957b0ddc915  pop rdx
00007957b0ddc916  pop rcx
00007957b0ddc917  pop rax
00007957b0ddc918  add rsp, 0x08
00007957b0ddc91c  jmp 0x00007957B0DDA4D0
00007957b0ddc921  sub rsp, 0x08
00007957b0ddc925  push rax
00007957b0ddc926  push rcx
00007957b0ddc927  push rdx
00007957b0ddc928  push rdi
00007957b0ddc929  push rsi
00007957b0ddc92a  push r8
00007957b0ddc92c  push r9
00007957b0ddc92e  push r10
00007957b0ddc930  push r11
00007957b0ddc932  sub rsp, 0xF0
00007957b0ddc939  vmovaps [rsp], xmm0
00007957b0ddc93e  vmovaps [rsp+0x10], xmm1
00007957b0ddc944  vmovaps [rsp+0x20], xmm2
00007957b0ddc94a  vmovaps [rsp+0x30], xmm3
00007957b0ddc950  vmovaps [rsp+0x40], xmm4
00007957b0ddc956  vmovaps [rsp+0x50], xmm5
00007957b0ddc95c  vmovaps [rsp+0x60], xmm6
00007957b0ddc962  vmovaps [rsp+0x70], xmm8
00007957b0ddc968  vmovaps [rsp+0x80], xmm9
00007957b0ddc971  vmovaps [rsp+0x90], xmm10
00007957b0ddc97a  vmovaps [rsp+0xA0], xmm11
00007957b0ddc983  vmovaps [rsp+0xB0], xmm12
00007957b0ddc98c  vmovaps [rsp+0xC0], xmm13
00007957b0ddc995  vmovaps [rsp+0xD0], xmm14
00007957b0ddc99e  vmovaps [rsp+0xE0], xmm15
00007957b0ddc9a7  sub rsp, 0x40
00007957b0ddc9ab  lea rdi, [rsp]
00007957b0ddc9af  lea rsi, [rsp+0x10]
00007957b0ddc9b4  lea rdx, [rsp+0x20]
00007957b0ddc9b9  lea rcx, [rsp+0x30]
00007957b0ddc9be  mov r8d, 0x00
00007957b0ddc9c4  lea r9, [r15+0x3A8]
00007957b0ddc9cb  movaps [rdi], xmm7
00007957b0ddc9ce  movaps [rsi], xmm9
00007957b0ddc9d2  movaps [rdx], xmm14
00007957b0ddc9d6  movaps [rcx], xmm12
00007957b0ddc9da  mov rax, 0x56E396DF1A50
00007957b0ddc9e4  call rax
00007957b0ddc9e6  movaps xmm7, [rsp]
00007957b0ddc9ea  add rsp, 0x40
00007957b0ddc9ee  vmovaps xmm0, [rsp]
00007957b0ddc9f3  vmovaps xmm1, [rsp+0x10]
00007957b0ddc9f9  vmovaps xmm2, [rsp+0x20]
00007957b0ddc9ff  vmovaps xmm3, [rsp+0x30]
00007957b0ddca05  vmovaps xmm4, [rsp+0x40]
00007957b0ddca0b  vmovaps xmm5, [rsp+0x50]
00007957b0ddca11  vmovaps xmm6, [rsp+0x60]
00007957b0ddca17  vmovaps xmm8, [rsp+0x70]
00007957b0ddca1d  vmovaps xmm9, [rsp+0x80]
00007957b0ddca26  vmovaps xmm10, [rsp+0x90]
00007957b0ddca2f  vmovaps xmm11, [rsp+0xA0]
00007957b0ddca38  vmovaps xmm12, [rsp+0xB0]
00007957b0ddca41  vmovaps xmm13, [rsp+0xC0]
00007957b0ddca4a  vmovaps xmm14, [rsp+0xD0]
00007957b0ddca53  vmovaps xmm15, [rsp+0xE0]
00007957b0ddca5c  add rsp, 0xF0
00007957b0ddca63  pop r11
00007957b0ddca65  pop r10
00007957b0ddca67  pop r9
00007957b0ddca69  pop r8
00007957b0ddca6b  pop rsi
00007957b0ddca6c  pop rdi
00007957b0ddca6d  pop rdx
00007957b0ddca6e  pop rcx
00007957b0ddca6f  pop rax
00007957b0ddca70  add rsp, 0x08
00007957b0ddca74  jmp 0x00007957B0DDA4F8
00007957b0ddca79  sub rsp, 0x08
00007957b0ddca7d  push rax
00007957b0ddca7e  push rcx
00007957b0ddca7f  push rdx
00007957b0ddca80  push rdi
00007957b0ddca81  push rsi
00007957b0ddca82  push r8
00007957b0ddca84  push r9
00007957b0ddca86  push r10
00007957b0ddca88  push r11
00007957b0ddca8a  sub rsp, 0xF0
00007957b0ddca91  vmovaps [rsp], xmm0
00007957b0ddca96  vmovaps [rsp+0x10], xmm1
00007957b0ddca9c  vmovaps [rsp+0x20], xmm2
00007957b0ddcaa2  vmovaps [rsp+0x30], xmm3
00007957b0ddcaa8  vmovaps [rsp+0x40], xmm4
00007957b0ddcaae  vmovaps [rsp+0x50], xmm5
00007957b0ddcab4  vmovaps [rsp+0x60], xmm6
00007957b0ddcaba  vmovaps [rsp+0x70], xmm7
00007957b0ddcac0  vmovaps [rsp+0x80], xmm8
00007957b0ddcac9  vmovaps [rsp+0x90], xmm9
00007957b0ddcad2  vmovaps [rsp+0xA0], xmm10
00007957b0ddcadb  vmovaps [rsp+0xB0], xmm11
00007957b0ddcae4  vmovaps [rsp+0xC0], xmm13
00007957b0ddcaed  vmovaps [rsp+0xD0], xmm14
00007957b0ddcaf6  vmovaps [rsp+0xE0], xmm15
00007957b0ddcaff  sub rsp, 0x40
00007957b0ddcb03  lea rdi, [rsp]
00007957b0ddcb07  lea rsi, [rsp+0x10]
00007957b0ddcb0c  lea rdx, [rsp+0x20]
00007957b0ddcb11  lea rcx, [rsp+0x30]
00007957b0ddcb16  mov r8d, 0x00
00007957b0ddcb1c  lea r9, [r15+0x3A8]
00007957b0ddcb23  movaps [rdi], xmm12
00007957b0ddcb27  movaps [rsi], xmm11
00007957b0ddcb2b  movaps [rdx], xmm15
00007957b0ddcb2f  movaps [rcx], xmm14
00007957b0ddcb33  mov rax, 0x56E396DF1A50
00007957b0ddcb3d  call rax
00007957b0ddcb3f  movaps xmm12, [rsp]
00007957b0ddcb44  add rsp, 0x40
00007957b0ddcb48  vmovaps xmm0, [rsp]
00007957b0ddcb4d  vmovaps xmm1, [rsp+0x10]
00007957b0ddcb53  vmovaps xmm2, [rsp+0x20]
00007957b0ddcb59  vmovaps xmm3, [rsp+0x30]
00007957b0ddcb5f  vmovaps xmm4, [rsp+0x40]
00007957b0ddcb65  vmovaps xmm5, [rsp+0x50]
00007957b0ddcb6b  vmovaps xmm6, [rsp+0x60]
00007957b0ddcb71  vmovaps xmm7, [rsp+0x70]
00007957b0ddcb77  vmovaps xmm8, [rsp+0x80]
00007957b0ddcb80  vmovaps xmm9, [rsp+0x90]
00007957b0ddcb89  vmovaps xmm10, [rsp+0xA0]
00007957b0ddcb92  vmovaps xmm11, [rsp+0xB0]
00007957b0ddcb9b  vmovaps xmm13, [rsp+0xC0]
00007957b0ddcba4  vmovaps xmm14, [rsp+0xD0]
00007957b0ddcbad  vmovaps xmm15, [rsp+0xE0]
00007957b0ddcbb6  add rsp, 0xF0
00007957b0ddcbbd  pop r11
00007957b0ddcbbf  pop r10
00007957b0ddcbc1  pop r9
00007957b0ddcbc3  pop r8
00007957b0ddcbc5  pop rsi
00007957b0ddcbc6  pop rdi
00007957b0ddcbc7  pop rdx
00007957b0ddcbc8  pop rcx
00007957b0ddcbc9  pop rax
00007957b0ddcbca  add rsp, 0x08
00007957b0ddcbce  jmp 0x00007957B0DDA521
00007957b0ddcbd3  sub rsp, 0x08
00007957b0ddcbd7  push rax
00007957b0ddcbd8  push rcx
00007957b0ddcbd9  push rdx
00007957b0ddcbda  push rdi
00007957b0ddcbdb  push rsi
00007957b0ddcbdc  push r8
00007957b0ddcbde  push r9
00007957b0ddcbe0  push r10
00007957b0ddcbe2  push r11
00007957b0ddcbe4  sub rsp, 0xF0
00007957b0ddcbeb  vmovaps [rsp], xmm0
00007957b0ddcbf0  vmovaps [rsp+0x10], xmm1
00007957b0ddcbf6  vmovaps [rsp+0x20], xmm2
00007957b0ddcbfc  vmovaps [rsp+0x30], xmm3
00007957b0ddcc02  vmovaps [rsp+0x40], xmm4
00007957b0ddcc08  vmovaps [rsp+0x50], xmm5
00007957b0ddcc0e  vmovaps [rsp+0x60], xmm6
00007957b0ddcc14  vmovaps [rsp+0x70], xmm7
00007957b0ddcc1a  vmovaps [rsp+0x80], xmm8
00007957b0ddcc23  vmovaps [rsp+0x90], xmm9
00007957b0ddcc2c  vmovaps [rsp+0xA0], xmm10
00007957b0ddcc35  vmovaps [rsp+0xB0], xmm12
00007957b0ddcc3e  vmovaps [rsp+0xC0], xmm13
00007957b0ddcc47  vmovaps [rsp+0xD0], xmm14
00007957b0ddcc50  vmovaps [rsp+0xE0], xmm15
00007957b0ddcc59  sub rsp, 0x40
00007957b0ddcc5d  lea rdi, [rsp]
00007957b0ddcc61  lea rsi, [rsp+0x10]
00007957b0ddcc66  lea rdx, [rsp+0x20]
00007957b0ddcc6b  lea rcx, [rsp+0x30]
00007957b0ddcc70  mov r8d, 0x00
00007957b0ddcc76  lea r9, [r15+0x3A8]
00007957b0ddcc7d  movaps [rdi], xmm11
00007957b0ddcc81  movaps [rsi], xmm10
00007957b0ddcc85  movaps [rdx], xmm13
00007957b0ddcc89  movaps [rcx], xmm15
00007957b0ddcc8d  mov rax, 0x56E396DF1A50
00007957b0ddcc97  call rax
00007957b0ddcc99  movaps xmm11, [rsp]
00007957b0ddcc9e  add rsp, 0x40
00007957b0ddcca2  vmovaps xmm0, [rsp]
00007957b0ddcca7  vmovaps xmm1, [rsp+0x10]
00007957b0ddccad  vmovaps xmm2, [rsp+0x20]
00007957b0ddccb3  vmovaps xmm3, [rsp+0x30]
00007957b0ddccb9  vmovaps xmm4, [rsp+0x40]
00007957b0ddccbf  vmovaps xmm5, [rsp+0x50]
00007957b0ddccc5  vmovaps xmm6, [rsp+0x60]
00007957b0ddcccb  vmovaps xmm7, [rsp+0x70]
00007957b0ddccd1  vmovaps xmm8, [rsp+0x80]
00007957b0ddccda  vmovaps xmm9, [rsp+0x90]
00007957b0ddcce3  vmovaps xmm10, [rsp+0xA0]
00007957b0ddccec  vmovaps xmm12, [rsp+0xB0]
00007957b0ddccf5  vmovaps xmm13, [rsp+0xC0]
00007957b0ddccfe  vmovaps xmm14, [rsp+0xD0]
00007957b0ddcd07  vmovaps xmm15, [rsp+0xE0]
00007957b0ddcd10  add rsp, 0xF0
00007957b0ddcd17  pop r11
00007957b0ddcd19  pop r10
00007957b0ddcd1b  pop r9
00007957b0ddcd1d  pop r8
00007957b0ddcd1f  pop rsi
00007957b0ddcd20  pop rdi
00007957b0ddcd21  pop rdx
00007957b0ddcd22  pop rcx
00007957b0ddcd23  pop rax
00007957b0ddcd24  add rsp, 0x08
00007957b0ddcd28  jmp 0x00007957B0DDA54A
00007957b0ddcd2d  call 0x00007957B0C0E760
00007957b0ddcd32  jmp 0x00007957B0DDA557
00007957b0ddcd37  call 0x00007957B0C0D4E0
00007957b0ddcd3c  jmp 0x00007957B0DDA564
00007957b0ddcd41  sub rsp, 0x08
00007957b0ddcd45  push rax
00007957b0ddcd46  push rcx
00007957b0ddcd47  push rdx
00007957b0ddcd48  push rdi
00007957b0ddcd49  push rsi
00007957b0ddcd4a  push r8
00007957b0ddcd4c  push r9
00007957b0ddcd4e  push r10
00007957b0ddcd50  push r11
00007957b0ddcd52  sub rsp, 0xF0
00007957b0ddcd59  vmovaps [rsp], xmm0
00007957b0ddcd5e  vmovaps [rsp+0x10], xmm1
00007957b0ddcd64  vmovaps [rsp+0x20], xmm2
00007957b0ddcd6a  vmovaps [rsp+0x30], xmm3
00007957b0ddcd70  vmovaps [rsp+0x40], xmm4
00007957b0ddcd76  vmovaps [rsp+0x50], xmm5
00007957b0ddcd7c  vmovaps [rsp+0x60], xmm6
00007957b0ddcd82  vmovaps [rsp+0x70], xmm7
00007957b0ddcd88  vmovaps [rsp+0x80], xmm8
00007957b0ddcd91  vmovaps [rsp+0x90], xmm9
00007957b0ddcd9a  vmovaps [rsp+0xA0], xmm11
00007957b0ddcda3  vmovaps [rsp+0xB0], xmm12
00007957b0ddcdac  vmovaps [rsp+0xC0], xmm13
00007957b0ddcdb5  vmovaps [rsp+0xD0], xmm14
00007957b0ddcdbe  vmovaps [rsp+0xE0], xmm15
00007957b0ddcdc7  sub rsp, 0x40
00007957b0ddcdcb  lea rdi, [rsp]
00007957b0ddcdcf  lea rsi, [rsp+0x10]
00007957b0ddcdd4  lea rdx, [rsp+0x20]
00007957b0ddcdd9  lea rcx, [rsp+0x30]
00007957b0ddcdde  mov r8d, 0x00
00007957b0ddcde4  lea r9, [r15+0x3A8]
00007957b0ddcdeb  movaps [rdi], xmm10
00007957b0ddcdef  movaps [rsi], xmm8
00007957b0ddcdf3  movaps [rdx], xmm1
00007957b0ddcdf6  movaps [rcx], xmm13
00007957b0ddcdfa  mov rax, 0x56E396DF1A50
00007957b0ddce04  call rax
00007957b0ddce06  movaps xmm10, [rsp]
00007957b0ddce0b  add rsp, 0x40
00007957b0ddce0f  vmovaps xmm0, [rsp]
00007957b0ddce14  vmovaps xmm1, [rsp+0x10]
00007957b0ddce1a  vmovaps xmm2, [rsp+0x20]
00007957b0ddce20  vmovaps xmm3, [rsp+0x30]
00007957b0ddce26  vmovaps xmm4, [rsp+0x40]
00007957b0ddce2c  vmovaps xmm5, [rsp+0x50]
00007957b0ddce32  vmovaps xmm6, [rsp+0x60]
00007957b0ddce38  vmovaps xmm7, [rsp+0x70]
00007957b0ddce3e  vmovaps xmm8, [rsp+0x80]
00007957b0ddce47  vmovaps xmm9, [rsp+0x90]
00007957b0ddce50  vmovaps xmm11, [rsp+0xA0]
00007957b0ddce59  vmovaps xmm12, [rsp+0xB0]
00007957b0ddce62  vmovaps xmm13, [rsp+0xC0]
00007957b0ddce6b  vmovaps xmm14, [rsp+0xD0]
00007957b0ddce74  vmovaps xmm15, [rsp+0xE0]
00007957b0ddce7d  add rsp, 0xF0
00007957b0ddce84  pop r11
00007957b0ddce86  pop r10
00007957b0ddce88  pop r9
00007957b0ddce8a  pop r8
00007957b0ddce8c  pop rsi
00007957b0ddce8d  pop rdi
00007957b0ddce8e  pop rdx
00007957b0ddce8f  pop rcx
00007957b0ddce90  pop rax
00007957b0ddce91  add rsp, 0x08
00007957b0ddce95  jmp 0x00007957B0DDA59A
00007957b0ddce9a  call 0x00007957B0BFF430
00007957b0ddce9f  jmp 0x00007957B0DDA5AC
00007957b0ddcea4  sub rsp, 0x08
00007957b0ddcea8  push rax
00007957b0ddcea9  push rcx
00007957b0ddceaa  push rdx
00007957b0ddceab  push rdi
00007957b0ddceac  push rsi
00007957b0ddcead  push r8
00007957b0ddceaf  push r9
00007957b0ddceb1  push r10
00007957b0ddceb3  push r11
00007957b0ddceb5  sub rsp, 0xF0
00007957b0ddcebc  vmovaps [rsp], xmm0
00007957b0ddcec1  vmovaps [rsp+0x10], xmm1
00007957b0ddcec7  vmovaps [rsp+0x20], xmm2
00007957b0ddcecd  vmovaps [rsp+0x30], xmm3
00007957b0ddced3  vmovaps [rsp+0x40], xmm4
00007957b0ddced9  vmovaps [rsp+0x50], xmm5
00007957b0ddcedf  vmovaps [rsp+0x60], xmm6
00007957b0ddcee5  vmovaps [rsp+0x70], xmm7
00007957b0ddceeb  vmovaps [rsp+0x80], xmm8
00007957b0ddcef4  vmovaps [rsp+0x90], xmm10
00007957b0ddcefd  vmovaps [rsp+0xA0], xmm11
00007957b0ddcf06  vmovaps [rsp+0xB0], xmm12
00007957b0ddcf0f  vmovaps [rsp+0xC0], xmm13
00007957b0ddcf18  vmovaps [rsp+0xD0], xmm14
00007957b0ddcf21  vmovaps [rsp+0xE0], xmm15
00007957b0ddcf2a  sub rsp, 0x40
00007957b0ddcf2e  lea rdi, [rsp]
00007957b0ddcf32  lea rsi, [rsp+0x10]
00007957b0ddcf37  lea rdx, [rsp+0x20]
00007957b0ddcf3c  lea rcx, [rsp+0x30]
00007957b0ddcf41  mov r8d, 0x00
00007957b0ddcf47  lea r9, [r15+0x3A8]
00007957b0ddcf4e  movaps [rdi], xmm9
00007957b0ddcf52  movaps [rsi], xmm7
00007957b0ddcf55  movaps [rdx], xmm14
00007957b0ddcf59  movaps [rcx], xmm13
00007957b0ddcf5d  mov rax, 0x56E396DF1A50
00007957b0ddcf67  call rax
00007957b0ddcf69  movaps xmm9, [rsp]
00007957b0ddcf6e  add rsp, 0x40
00007957b0ddcf72  vmovaps xmm0, [rsp]
00007957b0ddcf77  vmovaps xmm1, [rsp+0x10]
00007957b0ddcf7d  vmovaps xmm2, [rsp+0x20]
00007957b0ddcf83  vmovaps xmm3, [rsp+0x30]
00007957b0ddcf89  vmovaps xmm4, [rsp+0x40]
00007957b0ddcf8f  vmovaps xmm5, [rsp+0x50]
00007957b0ddcf95  vmovaps xmm6, [rsp+0x60]
00007957b0ddcf9b  vmovaps xmm7, [rsp+0x70]
00007957b0ddcfa1  vmovaps xmm8, [rsp+0x80]
00007957b0ddcfaa  vmovaps xmm10, [rsp+0x90]
00007957b0ddcfb3  vmovaps xmm11, [rsp+0xA0]
00007957b0ddcfbc  vmovaps xmm12, [rsp+0xB0]
00007957b0ddcfc5  vmovaps xmm13, [rsp+0xC0]
00007957b0ddcfce  vmovaps xmm14, [rsp+0xD0]
00007957b0ddcfd7  vmovaps xmm15, [rsp+0xE0]
00007957b0ddcfe0  add rsp, 0xF0
00007957b0ddcfe7  pop r11
00007957b0ddcfe9  pop r10
00007957b0ddcfeb  pop r9
00007957b0ddcfed  pop r8
00007957b0ddcfef  pop rsi
00007957b0ddcff0  pop rdi
00007957b0ddcff1  pop rdx
00007957b0ddcff2  pop rcx
00007957b0ddcff3  pop rax
00007957b0ddcff4  add rsp, 0x08
00007957b0ddcff8  jmp 0x00007957B0DDA5DA
00007957b0ddcffd  sub rsp, 0x08
00007957b0ddd001  push rax
00007957b0ddd002  push rcx
00007957b0ddd003  push rdx
00007957b0ddd004  push rdi
00007957b0ddd005  push rsi
00007957b0ddd006  push r8
00007957b0ddd008  push r9
00007957b0ddd00a  push r10
00007957b0ddd00c  push r11
00007957b0ddd00e  sub rsp, 0xF0
00007957b0ddd015  vmovaps [rsp], xmm0
00007957b0ddd01a  vmovaps [rsp+0x10], xmm1
00007957b0ddd020  vmovaps [rsp+0x20], xmm2
00007957b0ddd026  vmovaps [rsp+0x30], xmm3
00007957b0ddd02c  vmovaps [rsp+0x40], xmm4
00007957b0ddd032  vmovaps [rsp+0x50], xmm5
00007957b0ddd038  vmovaps [rsp+0x60], xmm6
00007957b0ddd03e  vmovaps [rsp+0x70], xmm7
00007957b0ddd044  vmovaps [rsp+0x80], xmm8
00007957b0ddd04d  vmovaps [rsp+0x90], xmm9
00007957b0ddd056  vmovaps [rsp+0xA0], xmm10
00007957b0ddd05f  vmovaps [rsp+0xB0], xmm11
00007957b0ddd068  vmovaps [rsp+0xC0], xmm12
00007957b0ddd071  vmovaps [rsp+0xD0], xmm14
00007957b0ddd07a  vmovaps [rsp+0xE0], xmm15
00007957b0ddd083  sub rsp, 0x40
00007957b0ddd087  lea rdi, [rsp]
00007957b0ddd08b  lea rsi, [rsp+0x10]
00007957b0ddd090  lea rdx, [rsp+0x20]
00007957b0ddd095  lea rcx, [rsp+0x30]
00007957b0ddd09a  mov r8d, 0x00
00007957b0ddd0a0  lea r9, [r15+0x3A8]
00007957b0ddd0a7  movaps [rdi], xmm13
00007957b0ddd0ab  movaps [rsi], xmm12
00007957b0ddd0af  movaps [rdx], xmm15
00007957b0ddd0b3  movaps [rcx], xmm14
00007957b0ddd0b7  mov rax, 0x56E396DF1A50
00007957b0ddd0c1  call rax
00007957b0ddd0c3  movaps xmm13, [rsp]
00007957b0ddd0c8  add rsp, 0x40
00007957b0ddd0cc  vmovaps xmm0, [rsp]
00007957b0ddd0d1  vmovaps xmm1, [rsp+0x10]
00007957b0ddd0d7  vmovaps xmm2, [rsp+0x20]
00007957b0ddd0dd  vmovaps xmm3, [rsp+0x30]
00007957b0ddd0e3  vmovaps xmm4, [rsp+0x40]
00007957b0ddd0e9  vmovaps xmm5, [rsp+0x50]
00007957b0ddd0ef  vmovaps xmm6, [rsp+0x60]
00007957b0ddd0f5  vmovaps xmm7, [rsp+0x70]
00007957b0ddd0fb  vmovaps xmm8, [rsp+0x80]
00007957b0ddd104  vmovaps xmm9, [rsp+0x90]
00007957b0ddd10d  vmovaps xmm10, [rsp+0xA0]
00007957b0ddd116  vmovaps xmm11, [rsp+0xB0]
00007957b0ddd11f  vmovaps xmm12, [rsp+0xC0]
00007957b0ddd128  vmovaps xmm14, [rsp+0xD0]
00007957b0ddd131  vmovaps xmm15, [rsp+0xE0]
00007957b0ddd13a  add rsp, 0xF0
00007957b0ddd141  pop r11
00007957b0ddd143  pop r10
00007957b0ddd145  pop r9
00007957b0ddd147  pop r8
00007957b0ddd149  pop rsi
00007957b0ddd14a  pop rdi
00007957b0ddd14b  pop rdx
00007957b0ddd14c  pop rcx
00007957b0ddd14d  pop rax
00007957b0ddd14e  add rsp, 0x08
00007957b0ddd152  jmp 0x00007957B0DDA608
00007957b0ddd157  sub rsp, 0x08
00007957b0ddd15b  push rax
00007957b0ddd15c  push rcx
00007957b0ddd15d  push rdx
00007957b0ddd15e  push rdi
00007957b0ddd15f  push rsi
00007957b0ddd160  push r8
00007957b0ddd162  push r9
00007957b0ddd164  push r10
00007957b0ddd166  push r11
00007957b0ddd168  sub rsp, 0xF0
00007957b0ddd16f  vmovaps [rsp], xmm0
00007957b0ddd174  vmovaps [rsp+0x10], xmm1
00007957b0ddd17a  vmovaps [rsp+0x20], xmm2
00007957b0ddd180  vmovaps [rsp+0x30], xmm3
00007957b0ddd186  vmovaps [rsp+0x40], xmm4
00007957b0ddd18c  vmovaps [rsp+0x50], xmm5
00007957b0ddd192  vmovaps [rsp+0x60], xmm6
00007957b0ddd198  vmovaps [rsp+0x70], xmm7
00007957b0ddd19e  vmovaps [rsp+0x80], xmm8
00007957b0ddd1a7  vmovaps [rsp+0x90], xmm9
00007957b0ddd1b0  vmovaps [rsp+0xA0], xmm10
00007957b0ddd1b9  vmovaps [rsp+0xB0], xmm11
00007957b0ddd1c2  vmovaps [rsp+0xC0], xmm12
00007957b0ddd1cb  vmovaps [rsp+0xD0], xmm13
00007957b0ddd1d4  vmovaps [rsp+0xE0], xmm15
00007957b0ddd1dd  sub rsp, 0x40
00007957b0ddd1e1  lea rdi, [rsp]
00007957b0ddd1e5  lea rsi, [rsp+0x10]
00007957b0ddd1ea  lea rdx, [rsp+0x20]
00007957b0ddd1ef  lea rcx, [rsp+0x30]
00007957b0ddd1f4  mov r8d, 0x00
00007957b0ddd1fa  lea r9, [r15+0x3A8]
00007957b0ddd201  movaps [rdi], xmm14
00007957b0ddd205  movaps [rsi], xmm11
00007957b0ddd209  movaps [rdx], xmm1
00007957b0ddd20c  movaps [rcx], xmm15
00007957b0ddd210  mov rax, 0x56E396DF1A50
00007957b0ddd21a  call rax
00007957b0ddd21c  movaps xmm14, [rsp]
00007957b0ddd221  add rsp, 0x40
00007957b0ddd225  vmovaps xmm0, [rsp]
00007957b0ddd22a  vmovaps xmm1, [rsp+0x10]
00007957b0ddd230  vmovaps xmm2, [rsp+0x20]
00007957b0ddd236  vmovaps xmm3, [rsp+0x30]
00007957b0ddd23c  vmovaps xmm4, [rsp+0x40]
00007957b0ddd242  vmovaps xmm5, [rsp+0x50]
00007957b0ddd248  vmovaps xmm6, [rsp+0x60]
00007957b0ddd24e  vmovaps xmm7, [rsp+0x70]
00007957b0ddd254  vmovaps xmm8, [rsp+0x80]
00007957b0ddd25d  vmovaps xmm9, [rsp+0x90]
00007957b0ddd266  vmovaps xmm10, [rsp+0xA0]
00007957b0ddd26f  vmovaps xmm11, [rsp+0xB0]
00007957b0ddd278  vmovaps xmm12, [rsp+0xC0]
00007957b0ddd281  vmovaps xmm13, [rsp+0xD0]
00007957b0ddd28a  vmovaps xmm15, [rsp+0xE0]
00007957b0ddd293  add rsp, 0xF0
00007957b0ddd29a  pop r11
00007957b0ddd29c  pop r10
00007957b0ddd29e  pop r9
00007957b0ddd2a0  pop r8
00007957b0ddd2a2  pop rsi
00007957b0ddd2a3  pop rdi
00007957b0ddd2a4  pop rdx
00007957b0ddd2a5  pop rcx
00007957b0ddd2a6  pop rax
00007957b0ddd2a7  add rsp, 0x08
00007957b0ddd2ab  jmp 0x00007957B0DDA636
00007957b0ddd2b0  call 0x00007957B0C079B0
00007957b0ddd2b5  jmp 0x00007957B0DDA64C
00007957b0ddd2ba  call 0x00007957B0CE3440
00007957b0ddd2bf  jmp 0x00007957B0DDA656
00007957b0ddd2c4  call 0x00007957B0CDFCE0
00007957b0ddd2c9  jmp 0x00007957B0DDA660
00007957b0ddd2ce  call 0x00007957B0CE46C0
00007957b0ddd2d3  jmp 0x00007957B0DDA66A
00007957b0ddd2d8  int3
00007957b0ddd2d9  nop [rax], eax
00007957b0ddd2e0  mov qword ptr [r15+0x40], 0x430000
00007957b0ddd2e8  mov eax, 0x430C50
00007957b0ddd2ed  mov r14, [r13+rax*1]
00007957b0ddd2f2  movq xmm1, r14
00007957b0ddd2f7  mov rax, [r15+0x50]
00007957b0ddd2fb  movups xmm15, [r13+rax*1]
00007957b0ddd301  movaps [r15+0x120], xmm15
00007957b0ddd309  mov qword ptr [r15+0x48], 0x10
00007957b0ddd311  xor eax, eax
00007957b0ddd313  mov r14d, 0x10
00007957b0ddd319  mov r12d, 0x200
00007957b0ddd31f  cmp r14, r12
00007957b0ddd322  cmc
00007957b0ddd323  lahf
00007957b0ddd324  seto al
00007957b0ddd327  mov [r15+0x108], eax
00007957b0ddd32e  pextrq rax, xmm15, 0x01
00007957b0ddd335  movq xmm14, rax
00007957b0ddd33a  movaps [r15+0x130], xmm14
00007957b0ddd342  movq rax, xmm1
00007957b0ddd347  movq r14, xmm15
00007957b0ddd34c  vmovq xmm1, rax
00007957b0ddd351  vmovq xmm15, r14
00007957b0ddd356  movaps xmm13, xmm1
00007957b0ddd35a  addsd xmm13, xmm15
00007957b0ddd35f  ucomisd xmm13, xmm13
00007957b0ddd364  jp 0x00007957B0DDD423
00007957b0ddd36a  movq xmm13, xmm13
00007957b0ddd36f  movq rax, xmm13
00007957b0ddd374  movq r14, xmm14
00007957b0ddd379  vmovq xmm1, rax
00007957b0ddd37e  vmovq xmm15, r14
00007957b0ddd383  movaps xmm14, xmm1
00007957b0ddd387  addsd xmm14, xmm15
00007957b0ddd38c  ucomisd xmm14, xmm14
00007957b0ddd391  jp 0x00007957B0DDD46B
00007957b0ddd397  movq xmm14, xmm14
00007957b0ddd39c  movaps [r15+0x110], xmm14
00007957b0ddd3a4  mov eax, [r15+0x108]
00007957b0ddd3ab  sahf
00007957b0ddd3ac  jnz 0x00007957B0DDD3DE
00007957b0ddd3ae  cmp dword ptr [r15+0x318], 0x00
00007957b0ddd3b6  jz 0x00007957B0DDD680
00007957b0ddd3bc  nop [rax+rax*1], ax
00007957b0ddd3c5  nop [rax+rax*1], eax
00007957b0ddd3cd  mov eax, 0x410698
00007957b0ddd3d2  mov [r15+0x100], rax
00007957b0ddd3d9  jmp 0x00007957B0BFE110
00007957b0ddd3de  cmp dword ptr [r15+0x318], 0x00
00007957b0ddd3e6  jz 0x00007957B0DDD4C0
00007957b0ddd3ec  nop [rax+rax*1], ax
00007957b0ddd3f5  nop [rax+rax*1], eax
00007957b0ddd3fd  mov eax, 0x41067C
00007957b0ddd402  mov [r15+0x100], rax
00007957b0ddd409  jmp 0x00007957B0BFE110
00007957b0ddd40e  int3
00007957b0ddd40f  call 0x00007957B0C0DC20
00007957b0ddd414  jmp 0x00007957B0DDD2F2
00007957b0ddd419  call 0x00007957B0C0E760
00007957b0ddd41e  jmp 0x00007957B0DDD301
00007957b0ddd423  ucomisd xmm1, xmm15
00007957b0ddd428  jp 0x00007957B0DDD437
00007957b0ddd42a  movaps xmm13, [0x00007957B09FE060]
00007957b0ddd432  jmp 0x00007957B0DDD36A
00007957b0ddd437  vxorps xmm0, xmm1, xmm15
00007957b0ddd43c  pextrw eax, xmm0, 0x03
00007957b0ddd441  and eax, 0x7FF8
00007957b0ddd446  cmp eax, 0x08
00007957b0ddd449  jnz 0x00007957B0DDD36A
00007957b0ddd44f  movq rax, xmm15
00007957b0ddd454  shl rax, 0x0D
00007957b0ddd458  jbe 0x00007957B0DDD36A
00007957b0ddd45e  vorps xmm13, xmm15, [0x00007957B09FE070]
00007957b0ddd466  jmp 0x00007957B0DDD36A
00007957b0ddd46b  ucomisd xmm1, xmm15
00007957b0ddd470  jp 0x00007957B0DDD47F
00007957b0ddd472  movaps xmm14, [0x00007957B09FE060]
00007957b0ddd47a  jmp 0x00007957B0DDD397
00007957b0ddd47f  vxorps xmm0, xmm1, xmm15
00007957b0ddd484  pextrw eax, xmm0, 0x03
00007957b0ddd489  and eax, 0x7FF8
00007957b0ddd48e  cmp eax, 0x08
00007957b0ddd491  jnz 0x00007957B0DDD397
00007957b0ddd497  movq rax, xmm15
00007957b0ddd49c  shl rax, 0x0D
00007957b0ddd4a0  jbe 0x00007957B0DDD397
00007957b0ddd4a6  vorps xmm14, xmm15, [0x00007957B09FE070]
00007957b0ddd4ae  jmp 0x00007957B0DDD397
00007957b0ddd4b3  int3
00007957b0ddd4b4  nop [rax+rax*1], ax
00007957b0ddd4bd  nop [rax], eax
00007957b0ddd4c0  mov rax, [r15+0x48]
00007957b0ddd4c4  mov r14, [r15+0x50]
00007957b0ddd4c8  lea r12, [r14+rax*1]
00007957b0ddd4cc  movups xmm1, [r13+r12*1]
00007957b0ddd4d2  movaps [r15+0x120], xmm1
00007957b0ddd4da  lea r14, [rax+0x10]
00007957b0ddd4de  mov [r15+0x48], r14
00007957b0ddd4e2  xor eax, eax
00007957b0ddd4e4  mov r12d, 0x200
00007957b0ddd4ea  cmp r14, r12
00007957b0ddd4ed  cmc
00007957b0ddd4ee  lahf
00007957b0ddd4ef  seto al
00007957b0ddd4f2  mov [r15+0x108], eax
00007957b0ddd4f9  pextrq rax, xmm1, 0x01
00007957b0ddd500  movq xmm15, rax
00007957b0ddd505  movaps [r15+0x130], xmm15
00007957b0ddd50d  movaps xmm14, [r15+0x110]
00007957b0ddd515  movq rax, xmm14
00007957b0ddd51a  movq r14, xmm1
00007957b0ddd51f  vmovq xmm1, rax
00007957b0ddd524  vmovq xmm14, r14
00007957b0ddd529  movaps xmm13, xmm1
00007957b0ddd52d  addsd xmm13, xmm14
00007957b0ddd532  ucomisd xmm13, xmm13
00007957b0ddd537  jp 0x00007957B0DDD5EC
00007957b0ddd53d  movq xmm13, xmm13
00007957b0ddd542  movq rax, xmm13
00007957b0ddd547  movq r14, xmm15
00007957b0ddd54c  vmovq xmm1, rax
00007957b0ddd551  vmovq xmm15, r14
00007957b0ddd556  movaps xmm14, xmm1
00007957b0ddd55a  addsd xmm14, xmm15
00007957b0ddd55f  ucomisd xmm14, xmm14
00007957b0ddd564  jp 0x00007957B0DDD634
00007957b0ddd56a  movq xmm14, xmm14
00007957b0ddd56f  movaps [r15+0x110], xmm14
00007957b0ddd577  mov eax, [r15+0x108]
00007957b0ddd57e  sahf
00007957b0ddd57f  jnz 0x00007957B0DDD5B1
00007957b0ddd581  cmp dword ptr [r15+0x318], 0x00
00007957b0ddd589  jz 0x00007957B0DDD680
00007957b0ddd58f  nop [rax+rax*1], ax
00007957b0ddd598  nop [rax+rax*1], eax
00007957b0ddd5a0  mov eax, 0x410698
00007957b0ddd5a5  mov [r15+0x100], rax
00007957b0ddd5ac  jmp 0x00007957B0BFE110
00007957b0ddd5b1  cmp dword ptr [r15+0x318], 0x00
00007957b0ddd5b9  jz 0x00007957B0DDD4C0
00007957b0ddd5bf  nop [rax+rax*1], ax
00007957b0ddd5c8  nop [rax+rax*1], eax
00007957b0ddd5d0  mov eax, 0x41067C
00007957b0ddd5d5  mov [r15+0x100], rax
00007957b0ddd5dc  jmp 0x00007957B0BFE110
00007957b0ddd5e1  int3
00007957b0ddd5e2  call 0x00007957B0CB52F0
00007957b0ddd5e7  jmp 0x00007957B0DDD4D2
00007957b0ddd5ec  ucomisd xmm1, xmm14
00007957b0ddd5f1  jp 0x00007957B0DDD600
00007957b0ddd5f3  movaps xmm13, [0x00007957B09FE060]
00007957b0ddd5fb  jmp 0x00007957B0DDD53D
00007957b0ddd600  vxorps xmm0, xmm1, xmm14
00007957b0ddd605  pextrw eax, xmm0, 0x03
00007957b0ddd60a  and eax, 0x7FF8
00007957b0ddd60f  cmp eax, 0x08
00007957b0ddd612  jnz 0x00007957B0DDD53D
00007957b0ddd618  movq rax, xmm14
00007957b0ddd61d  shl rax, 0x0D
00007957b0ddd621  jbe 0x00007957B0DDD53D
00007957b0ddd627  vorps xmm13, xmm14, [0x00007957B09FE070]
00007957b0ddd62f  jmp 0x00007957B0DDD53D
00007957b0ddd634  ucomisd xmm1, xmm15
00007957b0ddd639  jp 0x00007957B0DDD648
00007957b0ddd63b  movaps xmm14, [0x00007957B09FE060]
00007957b0ddd643  jmp 0x00007957B0DDD56A
00007957b0ddd648  vxorps xmm0, xmm1, xmm15
00007957b0ddd64d  pextrw eax, xmm0, 0x03
00007957b0ddd652  and eax, 0x7FF8
00007957b0ddd657  cmp eax, 0x08
00007957b0ddd65a  jnz 0x00007957B0DDD56A
00007957b0ddd660  movq rax, xmm15
00007957b0ddd665  shl rax, 0x0D
00007957b0ddd669  jbe 0x00007957B0DDD56A
00007957b0ddd66f  vorps xmm14, xmm15, [0x00007957B09FE070]
00007957b0ddd677  jmp 0x00007957B0DDD56A
00007957b0ddd67c  int3
00007957b0ddd67d  nop [rax], eax
00007957b0ddd680  mov rax, [r15+0xF8]
00007957b0ddd687  lea r14, [rax+0x1A0]
00007957b0ddd68e  mov r12, [r13+r14*1]
00007957b0ddd693  lea r14, [rax+0x1A8]
00007957b0ddd69a  mov r11, [r13+r14*1]
00007957b0ddd69f  mov [r15+0xA0], r12
00007957b0ddd6a6  mov [r15+0x98], r11
00007957b0ddd6ad  mov r14, [r15+0x40]
00007957b0ddd6b1  lea r12, [r14+0xC50]
00007957b0ddd6b8  movaps xmm1, [r15+0x110]
00007957b0ddd6c0  movq r14, xmm1
00007957b0ddd6c5  mov [r13+r12*1], r14
00007957b0ddd6ca  lea r14, [rax+0x190]
00007957b0ddd6d1  mov r12, [r13+r14*1]
00007957b0ddd6d6  lea r14, [rax+0x198]
00007957b0ddd6dd  mov r11, [r13+r14*1]
00007957b0ddd6e2  mov [r15+0xE8], r12
00007957b0ddd6e9  mov [r15+0xF0], r11
00007957b0ddd6f0  lea r14, [rax+0x180]
00007957b0ddd6f7  mov r12, [r13+r14*1]
00007957b0ddd6fc  lea r14, [rax+0x188]
00007957b0ddd703  mov r10, [r13+r14*1]
00007957b0ddd708  movq xmm1, r12
00007957b0ddd70d  movq xmm15, r10
00007957b0ddd712  movq xmm1, xmm1
00007957b0ddd716  movq xmm1, xmm1
00007957b0ddd71a  movaps [r15+0x1A0], xmm1
00007957b0ddd722  movq xmm15, xmm15
00007957b0ddd727  movq xmm15, xmm15
00007957b0ddd72c  movaps [r15+0x190], xmm15
00007957b0ddd734  lea r14, [rax+0x170]
00007957b0ddd73b  mov r12, [r13+r14*1]
00007957b0ddd740  lea r14, [rax+0x178]
00007957b0ddd747  mov r10, [r13+r14*1]
00007957b0ddd74c  movq xmm1, r12
00007957b0ddd751  movq xmm15, r10
00007957b0ddd756  movq xmm1, xmm1
00007957b0ddd75a  movq xmm1, xmm1
00007957b0ddd75e  movaps [r15+0x1C0], xmm1
00007957b0ddd766  movq xmm15, xmm15
00007957b0ddd76b  movq xmm15, xmm15
00007957b0ddd770  movaps [r15+0x1B0], xmm15
00007957b0ddd778  lea r14, [rax+0x160]
00007957b0ddd77f  mov r12, [r13+r14*1]
00007957b0ddd784  lea r14, [rax+0x168]
00007957b0ddd78b  mov r10, [r13+r14*1]
00007957b0ddd790  movq xmm1, r12
00007957b0ddd795  movq xmm15, r10
00007957b0ddd79a  movq xmm1, xmm1
00007957b0ddd79e  movq xmm1, xmm1
00007957b0ddd7a2  movaps [r15+0x1E0], xmm1
00007957b0ddd7aa  movq xmm15, xmm15
00007957b0ddd7af  movq xmm15, xmm15
00007957b0ddd7b4  movaps [r15+0x1D0], xmm15
00007957b0ddd7bc  lea r14, [rax+0x150]
00007957b0ddd7c3  mov r12, [r13+r14*1]
00007957b0ddd7c8  lea r14, [rax+0x158]
00007957b0ddd7cf  mov r10, [r13+r14*1]
00007957b0ddd7d4  movq xmm1, r12
00007957b0ddd7d9  movq xmm15, r10
00007957b0ddd7de  movq xmm1, xmm1
00007957b0ddd7e2  movq xmm1, xmm1
00007957b0ddd7e6  movaps [r15+0x200], xmm1
00007957b0ddd7ee  movq xmm15, xmm15
00007957b0ddd7f3  movq xmm15, xmm15
00007957b0ddd7f8  movaps [r15+0x1F0], xmm15
00007957b0ddd800  lea r14, [rax+0x1B0]
00007957b0ddd807  mov [r15+0xF8], r14
00007957b0ddd80e  mov [r15+0x100], r11
00007957b0ddd815  jmp 0x00007957B0DCE5C0
00007957b0ddd81a  int3
00007957b0ddd81b  call 0x00007957B0CE27E0
00007957b0ddd820  jmp 0x00007957B0DDD693
00007957b0ddd825  call 0x00007957B0CE1570
00007957b0ddd82a  jmp 0x00007957B0DDD69F
00007957b0ddd82f  call 0x00007957B0CC3FE0
00007957b0ddd834  jmp 0x00007957B0DDD6CA
00007957b0ddd839  call 0x00007957B0CE27E0
00007957b0ddd83e  jmp 0x00007957B0DDD6D6
00007957b0ddd843  call 0x00007957B0CE1570
00007957b0ddd848  jmp 0x00007957B0DDD6E2
00007957b0ddd84d  call 0x00007957B0CE27E0
00007957b0ddd852  jmp 0x00007957B0DDD6FC
00007957b0ddd857  call 0x00007957B0CE0300
00007957b0ddd85c  jmp 0x00007957B0DDD708
00007957b0ddd861  call 0x00007957B0CE27E0
00007957b0ddd866  jmp 0x00007957B0DDD740
00007957b0ddd86b  call 0x00007957B0CE0300
00007957b0ddd870  jmp 0x00007957B0DDD74C
00007957b0ddd875  call 0x00007957B0CE27E0
00007957b0ddd87a  jmp 0x00007957B0DDD784
00007957b0ddd87f  call 0x00007957B0CE0300
00007957b0ddd884  jmp 0x00007957B0DDD790
00007957b0ddd889  call 0x00007957B0CE27E0
00007957b0ddd88e  jmp 0x00007957B0DDD7C8
00007957b0ddd893  call 0x00007957B0CE0300
00007957b0ddd898  jmp 0x00007957B0DDD7D4
00007957b0ddd89d  int3
00007957b0ddd89e  nop
00007957b0ddd8a0  mov qword ptr [r15+0x100], 0x04
00007957b0ddd8ab  mov esi, 0x00
00007957b0ddd8b0  mov edx, 0x09
00007957b0ddd8b5  mov rdi, 0x7FFF50EBD8C0
00007957b0ddd8bf  mov rax, 0x56E396C84970
00007957b0ddd8c9  call rax
00007957b0ddd8cb  cmp dword ptr [r15+0x318], 0x00
00007957b0ddd8d3  jnz 0x00007957B0BFE110
00007957b0ddd8d9  jmp 0x00007957B0BFE0A0
00007957b0ddd8de  int3
00007957b0ddd8df  int3
