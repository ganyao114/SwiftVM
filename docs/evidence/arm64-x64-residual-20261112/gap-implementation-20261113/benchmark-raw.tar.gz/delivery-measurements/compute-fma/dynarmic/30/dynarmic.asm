000077a0e99ce69b  nop [rax+rax*1], eax
000077a0e99ce6a0  mov rax, [r15+0xF8]
000077a0e99ce6a7  lea r14, [rax-0x1B0]
000077a0e99ce6ae  mov [r15+0xF8], r14
000077a0e99ce6b5  lea rax, [r14+0x1A0]
000077a0e99ce6bc  mov r12, [r15+0xA0]
000077a0e99ce6c3  mov r11, [r15+0x98]
000077a0e99ce6ca  mov [r13+rax*1], r12
000077a0e99ce6cf  lea rax, [r14+0x1A8]
000077a0e99ce6d6  mov [r13+rax*1], r11
000077a0e99ce6db  mov eax, 0x420A30
000077a0e99ce6e0  movups xmm1, [r13+rax*1]
000077a0e99ce6e6  mov eax, 0x4209C0
000077a0e99ce6eb  movups xmm15, [r13+rax*1]
000077a0e99ce6f1  mov eax, 0x420A50
000077a0e99ce6f6  movups xmm14, [r13+rax*1]
000077a0e99ce6fc  mov eax, 0x4209F0
000077a0e99ce701  movups xmm13, [r13+rax*1]
000077a0e99ce707  mov qword ptr [r15+0x98], 0x430C60
000077a0e99ce712  mov eax, 0x420A60
000077a0e99ce717  movups xmm12, [r13+rax*1]
000077a0e99ce71d  mov eax, 0x430C60
000077a0e99ce722  movups [r13+rax*1], xmm1
000077a0e99ce728  mov eax, 0x430C70
000077a0e99ce72d  movups [r13+rax*1], xmm15
000077a0e99ce733  mov eax, 0x430C80
000077a0e99ce738  movups [r13+rax*1], xmm14
000077a0e99ce73e  mov eax, 0x430C90
000077a0e99ce743  movups [r13+rax*1], xmm13
000077a0e99ce749  mov eax, 0x4209B0
000077a0e99ce74e  movups xmm14, [r13+rax*1]
000077a0e99ce754  mov eax, 0x4209A0
000077a0e99ce759  movups xmm13, [r13+rax*1]
000077a0e99ce75f  mov eax, 0x430D60
000077a0e99ce764  movups [r13+rax*1], xmm1
000077a0e99ce76a  mov eax, 0x430D70
000077a0e99ce76f  movups [r13+rax*1], xmm15
000077a0e99ce775  mov eax, 0x430CA0
000077a0e99ce77a  movups [r13+rax*1], xmm12
000077a0e99ce780  mov eax, 0x430CB0
000077a0e99ce785  movups [r13+rax*1], xmm14
000077a0e99ce78b  mov eax, 0x420990
000077a0e99ce790  movups xmm1, [r13+rax*1]
000077a0e99ce796  mov eax, 0x420A00
000077a0e99ce79b  movups xmm15, [r13+rax*1]
000077a0e99ce7a1  mov eax, 0x430CC0
000077a0e99ce7a6  movups [r13+rax*1], xmm13
000077a0e99ce7ac  mov eax, 0x430CD0
000077a0e99ce7b1  movups [r13+rax*1], xmm1
000077a0e99ce7b7  mov eax, 0x420A10
000077a0e99ce7bc  movups xmm1, [r13+rax*1]
000077a0e99ce7c2  mov eax, 0x4209E0
000077a0e99ce7c7  movups xmm14, [r13+rax*1]
000077a0e99ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000077a0e99ce7d5  mov eax, 0x430CE0
000077a0e99ce7da  movups [r13+rax*1], xmm15
000077a0e99ce7e0  mov eax, 0x430CF0
000077a0e99ce7e5  movups [r13+rax*1], xmm1
000077a0e99ce7eb  mov eax, 0x420A80
000077a0e99ce7f0  movups xmm1, [r13+rax*1]
000077a0e99ce7f6  mov eax, 0x420A90
000077a0e99ce7fb  movups xmm15, [r13+rax*1]
000077a0e99ce801  movaps [r15+0x150], xmm15
000077a0e99ce809  mov qword ptr [r15+0xA0], 0x3E8
000077a0e99ce814  mov eax, 0x430D00
000077a0e99ce819  movups [r13+rax*1], xmm14
000077a0e99ce81f  mov eax, 0x430D10
000077a0e99ce824  movups [r13+rax*1], xmm1
000077a0e99ce82a  mov eax, 0x420A70
000077a0e99ce82f  movups xmm1, [r13+rax*1]
000077a0e99ce835  mov eax, 0x420A20
000077a0e99ce83a  movups xmm14, [r13+rax*1]
000077a0e99ce840  movaps [r15+0x140], xmm14
000077a0e99ce848  lea rax, [r14+0x150]
000077a0e99ce84f  movq xmm13, qword ptr [r15+0x200]
000077a0e99ce858  movq xmm12, qword ptr [r15+0x1F0]
000077a0e99ce861  movq r12, xmm13
000077a0e99ce866  movq r11, xmm12
000077a0e99ce86b  mov [r13+rax*1], r12
000077a0e99ce870  lea rax, [r14+0x158]
000077a0e99ce877  mov [r13+rax*1], r11
000077a0e99ce87c  mov eax, 0x430D20
000077a0e99ce881  movups [r13+rax*1], xmm15
000077a0e99ce887  mov eax, 0x430D30
000077a0e99ce88c  movups [r13+rax*1], xmm1
000077a0e99ce892  mov eax, 0x420A40
000077a0e99ce897  movups xmm1, [r13+rax*1]
000077a0e99ce89d  mov eax, 0x420AA8
000077a0e99ce8a2  mov r12, [r13+rax*1]
000077a0e99ce8a7  movq xmm15, r12
000077a0e99ce8ac  mov qword ptr [r15+0x40], 0x420AB0
000077a0e99ce8b4  mov eax, 0x430D40
000077a0e99ce8b9  movups [r13+rax*1], xmm14
000077a0e99ce8bf  mov eax, 0x430D50
000077a0e99ce8c4  movups [r13+rax*1], xmm1
000077a0e99ce8ca  mov eax, 0x420B10
000077a0e99ce8cf  movups xmm1, [r13+rax*1]
000077a0e99ce8d5  movq rax, xmm15
000077a0e99ce8da  mov r12d, 0x430D80
000077a0e99ce8e0  mov [r13+r12*1], rax
000077a0e99ce8e5  mov eax, 0x420AF0
000077a0e99ce8ea  movups xmm15, [r13+rax*1]
000077a0e99ce8f0  mov eax, 0x420B00
000077a0e99ce8f5  movups xmm14, [r13+rax*1]
000077a0e99ce8fb  lea rax, [r14+0x130]
000077a0e99ce902  movups [r13+rax*1], xmm1
000077a0e99ce908  lea rax, [r14+0x160]
000077a0e99ce90f  movq xmm1, qword ptr [r15+0x1E0]
000077a0e99ce918  movq xmm13, qword ptr [r15+0x1D0]
000077a0e99ce921  movq r12, xmm1
000077a0e99ce926  movq r11, xmm13
000077a0e99ce92b  mov [r13+rax*1], r12
000077a0e99ce930  lea rax, [r14+0x168]
000077a0e99ce937  mov [r13+rax*1], r11
000077a0e99ce93c  lea rax, [r14+0x110]
000077a0e99ce943  movups [r13+rax*1], xmm15
000077a0e99ce949  lea rax, [r14+0x120]
000077a0e99ce950  movups [r13+rax*1], xmm14
000077a0e99ce956  mov eax, 0x420AB0
000077a0e99ce95b  movups xmm1, [r13+rax*1]
000077a0e99ce961  mov eax, 0x420AC0
000077a0e99ce966  movups xmm15, [r13+rax*1]
000077a0e99ce96c  movaps [r15+0x120], xmm15
000077a0e99ce974  lea rax, [r14+0x170]
000077a0e99ce97b  movq xmm14, qword ptr [r15+0x1C0]
000077a0e99ce984  movq xmm13, qword ptr [r15+0x1B0]
000077a0e99ce98d  movq r12, xmm14
000077a0e99ce992  movq r11, xmm13
000077a0e99ce997  mov [r13+rax*1], r12
000077a0e99ce99c  lea rax, [r14+0x178]
000077a0e99ce9a3  mov [r13+rax*1], r11
000077a0e99ce9a8  lea rax, [r14+0x180]
000077a0e99ce9af  movq xmm14, qword ptr [r15+0x1A0]
000077a0e99ce9b8  movq xmm13, qword ptr [r15+0x190]
000077a0e99ce9c1  movq r12, xmm14
000077a0e99ce9c6  movq r11, xmm13
000077a0e99ce9cb  mov [r13+rax*1], r12
000077a0e99ce9d0  lea rax, [r14+0x188]
000077a0e99ce9d7  mov [r13+rax*1], r11
000077a0e99ce9dc  lea rax, [r14+0xD0]
000077a0e99ce9e3  movups [r13+rax*1], xmm1
000077a0e99ce9e9  lea rax, [r14+0xE0]
000077a0e99ce9f0  movups [r13+rax*1], xmm15
000077a0e99ce9f6  mov eax, 0x420AD0
000077a0e99ce9fb  movups xmm1, [r13+rax*1]
000077a0e99cea01  mov eax, 0x420AE0
000077a0e99cea06  movups xmm15, [r13+rax*1]
000077a0e99cea0c  movaps [r15+0x110], xmm1
000077a0e99cea14  movaps [r15+0x130], xmm15
000077a0e99cea1c  lea rax, [r14+0x190]
000077a0e99cea23  mov r12, [r15+0xE8]
000077a0e99cea2a  mov r11, [r15+0xF0]
000077a0e99cea31  mov [r13+rax*1], r12
000077a0e99cea36  lea rax, [r14+0x198]
000077a0e99cea3d  mov [r13+rax*1], r11
000077a0e99cea42  mov eax, 0x430D88
000077a0e99cea47  mov r12d, 0x421DF8D3
000077a0e99cea4d  mov [r13+rax*1], r12d
000077a0e99cea52  lea rax, [r14+0xF0]
000077a0e99cea59  movups [r13+rax*1], xmm1
000077a0e99cea5f  lea rax, [r14+0x100]
000077a0e99cea66  movups [r13+rax*1], xmm15
000077a0e99cea6c  lea rax, [r14+0xD0]
000077a0e99cea73  mov [r15], rax
000077a0e99cea76  mov qword ptr [r15+0x08], 0x430C60
000077a0e99cea7e  mov qword ptr [r15+0x10], 0x12C
000077a0e99cea86  mov qword ptr [r15+0xF0], 0x410284
000077a0e99cea91  mov r14d, [r15+0x320]
000077a0e99cea98  mov eax, 0x410284
000077a0e99cea9d  mov rcx, 0x77A0E99D07C0
000077a0e99ceaa7  mov [r15+r14*8+0x328], rax
000077a0e99ceaaf  mov [r15+r14*8+0x368], rcx
000077a0e99ceab7  add r14d, 0x01
000077a0e99ceabb  and r14d, 0x07
000077a0e99ceabf  mov [r15+0x320], r14d
000077a0e99ceac6  cmp dword ptr [r15+0x318], 0x00
000077a0e99ceace  jz 0x000077A0E99CED70
000077a0e99cead4  nop [rax+rax*1], ax
000077a0e99ceadd  nop [rax+rax*1], eax
000077a0e99ceae5  mov eax, 0x4106BC
000077a0e99ceaea  mov [r15+0x100], rax
000077a0e99ceaf1  jmp 0x000077A0E97FE110
000077a0e99ceaf6  int3
000077a0e99ceaf7  call 0x000077A0E980BC20
000077a0e99ceafc  jmp 0x000077A0E99CE6CF
000077a0e99ceb01  call 0x000077A0E980A9A0
000077a0e99ceb06  jmp 0x000077A0E99CE6DB
000077a0e99ceb0b  call 0x000077A0E97FF430
000077a0e99ceb10  jmp 0x000077A0E99CE6E6
000077a0e99ceb15  call 0x000077A0E980E760
000077a0e99ceb1a  jmp 0x000077A0E99CE6F1
000077a0e99ceb1f  call 0x000077A0E980D4E0
000077a0e99ceb24  jmp 0x000077A0E99CE6FC
000077a0e99ceb29  call 0x000077A0E980C260
000077a0e99ceb2e  jmp 0x000077A0E99CE707
000077a0e99ceb33  call 0x000077A0E980AFE0
000077a0e99ceb38  jmp 0x000077A0E99CE71D
000077a0e99ceb3d  call 0x000077A0E97FF540
000077a0e99ceb42  jmp 0x000077A0E99CE728
000077a0e99ceb47  call 0x000077A0E980E880
000077a0e99ceb4c  jmp 0x000077A0E99CE733
000077a0e99ceb51  call 0x000077A0E980D600
000077a0e99ceb56  jmp 0x000077A0E99CE73E
000077a0e99ceb5b  call 0x000077A0E980C380
000077a0e99ceb60  jmp 0x000077A0E99CE749
000077a0e99ceb65  call 0x000077A0E980D4E0
000077a0e99ceb6a  jmp 0x000077A0E99CE754
000077a0e99ceb6f  call 0x000077A0E980C260
000077a0e99ceb74  jmp 0x000077A0E99CE75F
000077a0e99ceb79  call 0x000077A0E97FF540
000077a0e99ceb7e  jmp 0x000077A0E99CE76A
000077a0e99ceb83  call 0x000077A0E980E880
000077a0e99ceb88  jmp 0x000077A0E99CE775
000077a0e99ceb8d  call 0x000077A0E980B100
000077a0e99ceb92  jmp 0x000077A0E99CE780
000077a0e99ceb97  call 0x000077A0E980D600
000077a0e99ceb9c  jmp 0x000077A0E99CE78B
000077a0e99ceba1  call 0x000077A0E97FF430
000077a0e99ceba6  jmp 0x000077A0E99CE796
000077a0e99cebab  call 0x000077A0E980E760
000077a0e99cebb0  jmp 0x000077A0E99CE7A1
000077a0e99cebb5  call 0x000077A0E980C380
000077a0e99cebba  jmp 0x000077A0E99CE7AC
000077a0e99cebbf  call 0x000077A0E97FF540
000077a0e99cebc4  jmp 0x000077A0E99CE7B7
000077a0e99cebc9  call 0x000077A0E97FF430
000077a0e99cebce  jmp 0x000077A0E99CE7C2
000077a0e99cebd3  call 0x000077A0E980D4E0
000077a0e99cebd8  jmp 0x000077A0E99CE7CD
000077a0e99cebdd  call 0x000077A0E980E880
000077a0e99cebe2  jmp 0x000077A0E99CE7E0
000077a0e99cebe7  call 0x000077A0E97FF540
000077a0e99cebec  jmp 0x000077A0E99CE7EB
000077a0e99cebf1  call 0x000077A0E97FF430
000077a0e99cebf6  jmp 0x000077A0E99CE7F6
000077a0e99cebfb  call 0x000077A0E980E760
000077a0e99cec00  jmp 0x000077A0E99CE801
000077a0e99cec05  call 0x000077A0E980D600
000077a0e99cec0a  jmp 0x000077A0E99CE81F
000077a0e99cec0f  call 0x000077A0E97FF540
000077a0e99cec14  jmp 0x000077A0E99CE82A
000077a0e99cec19  call 0x000077A0E97FF430
000077a0e99cec1e  jmp 0x000077A0E99CE835
000077a0e99cec23  call 0x000077A0E980D4E0
000077a0e99cec28  jmp 0x000077A0E99CE840
000077a0e99cec2d  call 0x000077A0E980BC20
000077a0e99cec32  jmp 0x000077A0E99CE870
000077a0e99cec37  call 0x000077A0E980A9A0
000077a0e99cec3c  jmp 0x000077A0E99CE87C
000077a0e99cec41  call 0x000077A0E980E880
000077a0e99cec46  jmp 0x000077A0E99CE887
000077a0e99cec4b  call 0x000077A0E97FF540
000077a0e99cec50  jmp 0x000077A0E99CE892
000077a0e99cec55  call 0x000077A0E97FF430
000077a0e99cec5a  jmp 0x000077A0E99CE89D
000077a0e99cec5f  call 0x000077A0E980B720
000077a0e99cec64  jmp 0x000077A0E99CE8A7
000077a0e99cec69  call 0x000077A0E980D600
000077a0e99cec6e  jmp 0x000077A0E99CE8BF
000077a0e99cec73  call 0x000077A0E97FF540
000077a0e99cec78  jmp 0x000077A0E99CE8CA
000077a0e99cec7d  call 0x000077A0E97FF430
000077a0e99cec82  jmp 0x000077A0E99CE8D5
000077a0e99cec87  call 0x000077A0E98B4CB0
000077a0e99cec8c  jmp 0x000077A0E99CE8E5
000077a0e99cec91  call 0x000077A0E980E760
000077a0e99cec96  jmp 0x000077A0E99CE8F0
000077a0e99cec9b  call 0x000077A0E980D4E0
000077a0e99ceca0  jmp 0x000077A0E99CE8FB
000077a0e99ceca5  call 0x000077A0E97FF540
000077a0e99cecaa  jmp 0x000077A0E99CE908
000077a0e99cecaf  call 0x000077A0E980BC20
000077a0e99cecb4  jmp 0x000077A0E99CE930
000077a0e99cecb9  call 0x000077A0E980A9A0
000077a0e99cecbe  jmp 0x000077A0E99CE93C
000077a0e99cecc3  call 0x000077A0E980E880
000077a0e99cecc8  jmp 0x000077A0E99CE949
000077a0e99ceccd  call 0x000077A0E980D600
000077a0e99cecd2  jmp 0x000077A0E99CE956
000077a0e99cecd7  call 0x000077A0E97FF430
000077a0e99cecdc  jmp 0x000077A0E99CE961
000077a0e99cece1  call 0x000077A0E980E760
000077a0e99cece6  jmp 0x000077A0E99CE96C
000077a0e99ceceb  call 0x000077A0E980BC20
000077a0e99cecf0  jmp 0x000077A0E99CE99C
000077a0e99cecf5  call 0x000077A0E980A9A0
000077a0e99cecfa  jmp 0x000077A0E99CE9A8
000077a0e99cecff  call 0x000077A0E980BC20
000077a0e99ced04  jmp 0x000077A0E99CE9D0
000077a0e99ced09  call 0x000077A0E980A9A0
000077a0e99ced0e  jmp 0x000077A0E99CE9DC
000077a0e99ced13  call 0x000077A0E97FF540
000077a0e99ced18  jmp 0x000077A0E99CE9E9
000077a0e99ced1d  call 0x000077A0E980E880
000077a0e99ced22  jmp 0x000077A0E99CE9F6
000077a0e99ced27  call 0x000077A0E97FF430
000077a0e99ced2c  jmp 0x000077A0E99CEA01
000077a0e99ced31  call 0x000077A0E980E760
000077a0e99ced36  jmp 0x000077A0E99CEA0C
000077a0e99ced3b  call 0x000077A0E980BC20
000077a0e99ced40  jmp 0x000077A0E99CEA36
000077a0e99ced45  call 0x000077A0E980A9A0
000077a0e99ced4a  jmp 0x000077A0E99CEA42
000077a0e99ced4f  call 0x000077A0E980BAE0
000077a0e99ced54  jmp 0x000077A0E99CEA52
000077a0e99ced59  call 0x000077A0E97FF540
000077a0e99ced5e  jmp 0x000077A0E99CEA5F
000077a0e99ced63  call 0x000077A0E980E880
000077a0e99ced68  jmp 0x000077A0E99CEA6C
000077a0e99ced6d  int3
000077a0e99ced6e  nop
000077a0e99ced70  mov rax, [r15]
000077a0e99ced73  lea r14, [rax+0x20]
000077a0e99ced77  mov r12, [r13+r14*1]
000077a0e99ced7c  mov r14, [r15+0x10]
000077a0e99ced80  lea r11, [r12+r14*1]
000077a0e99ced84  mov [r15+0x40], r11
000077a0e99ced88  lea r12, [rax+0x20]
000077a0e99ced8c  mov [r13+r12*1], r11
000077a0e99ced91  test r14, r14
000077a0e99ced94  setz r14b
000077a0e99ced98  movzx r14, r14b
000077a0e99ced9c  mov [rsp+0x414], r14b
000077a0e99ceda4  cmp byte ptr [rsp+0x414], 0x00
000077a0e99cedac  jz 0x000077A0E99CEDDE
000077a0e99cedae  cmp dword ptr [r15+0x318], 0x00
000077a0e99cedb6  mov eax, 0x410934
000077a0e99cedbb  mov [r15+0x100], rax
000077a0e99cedc2  jz 0x000077A0E97FE0A0
000077a0e99cedc8  nop [rax+rax*1], eax
000077a0e99cedcd  mov eax, 0x410934
000077a0e99cedd2  mov [r15+0x100], rax
000077a0e99cedd9  jmp 0x000077A0E97FE110
000077a0e99cedde  cmp dword ptr [r15+0x318], 0x00
000077a0e99cede6  jz 0x000077A0E99CEE30
000077a0e99cedec  nop [rax+rax*1], ax
000077a0e99cedf5  nop [rax+rax*1], eax
000077a0e99cedfd  mov eax, 0x4106CC
000077a0e99cee02  mov [r15+0x100], rax
000077a0e99cee09  jmp 0x000077A0E97FE110
000077a0e99cee0e  int3
000077a0e99cee0f  call 0x000077A0E98E27E0
000077a0e99cee14  jmp 0x000077A0E99CED7C
000077a0e99cee19  call 0x000077A0E98C0860
000077a0e99cee1e  jmp 0x000077A0E99CED91
000077a0e99cee23  int3
000077a0e99cee24  nop [rax+rax*1], ax
000077a0e99cee2d  nop [rax], eax
000077a0e99cee30  mov rax, [r15+0xF8]
000077a0e99cee37  lea r14, [rax-0x150]
000077a0e99cee3e  mov [r15+0xF8], r14
000077a0e99cee45  mov rax, [r15]
000077a0e99cee48  lea r12, [rax+0x68]
000077a0e99cee4c  mov r11, [r13+r12*1]
000077a0e99cee51  mov [r15+0x88], r11
000077a0e99cee58  lea r12, [rax+0x28]
000077a0e99cee5c  mov [r15+0x40], r12
000077a0e99cee60  mov [r15+0x48], r14
000077a0e99cee64  mov qword ptr [r15+0x50], 0x420B20
000077a0e99cee6c  lea rax, [r14+0x100]
000077a0e99cee73  mov r12, [r15+0xE8]
000077a0e99cee7a  mov r11, [r15+0xD8]
000077a0e99cee81  mov [r13+rax*1], r12
000077a0e99cee86  lea rax, [r14+0x108]
000077a0e99cee8d  mov [r13+rax*1], r11
000077a0e99cee92  lea rax, [r14+0x110]
000077a0e99cee99  mov r12, [r15+0xD0]
000077a0e99ceea0  mov r11, [r15+0xC8]
000077a0e99ceea7  mov [r13+rax*1], r12
000077a0e99ceeac  lea rax, [r14+0x118]
000077a0e99ceeb3  mov [r13+rax*1], r11
000077a0e99ceeb8  lea rax, [r14+0x120]
000077a0e99ceebf  mov r12, [r15+0xC0]
000077a0e99ceec6  mov r11, [r15+0xB8]
000077a0e99ceecd  mov [r13+rax*1], r12
000077a0e99ceed2  lea rax, [r14+0x128]
000077a0e99ceed9  mov [r13+rax*1], r11
000077a0e99ceede  lea rax, [r14+0x130]
000077a0e99ceee5  mov r12, [r15+0xB0]
000077a0e99ceeec  mov r11, [r15+0xA8]
000077a0e99ceef3  mov [r13+rax*1], r12
000077a0e99ceef8  lea rax, [r14+0x138]
000077a0e99ceeff  mov [r13+rax*1], r11
000077a0e99cef04  lea rax, [r14+0x140]
000077a0e99cef0b  mov r12, [r15+0xA0]
000077a0e99cef12  mov r11, [r15+0x98]
000077a0e99cef19  mov [r13+rax*1], r12
000077a0e99cef1e  lea rax, [r14+0x148]
000077a0e99cef25  mov [r13+rax*1], r11
000077a0e99cef2a  cmp dword ptr [r15+0x318], 0x00
000077a0e99cef32  jz 0x000077A0E99CEFD0
000077a0e99cef38  nop [rax+rax*1], ax
000077a0e99cef41  nop [rax+rax*1], eax
000077a0e99cef49  mov eax, 0x410704
000077a0e99cef4e  mov [r15+0x100], rax
000077a0e99cef55  jmp 0x000077A0E97FE110
000077a0e99cef5a  int3
000077a0e99cef5b  call 0x000077A0E98C0370
000077a0e99cef60  jmp 0x000077A0E99CEE51
000077a0e99cef65  call 0x000077A0E980BC20
000077a0e99cef6a  jmp 0x000077A0E99CEE86
000077a0e99cef6f  call 0x000077A0E980A9A0
000077a0e99cef74  jmp 0x000077A0E99CEE92
000077a0e99cef79  call 0x000077A0E980BC20
000077a0e99cef7e  jmp 0x000077A0E99CEEAC
000077a0e99cef83  call 0x000077A0E980A9A0
000077a0e99cef88  jmp 0x000077A0E99CEEB8
000077a0e99cef8d  call 0x000077A0E980BC20
000077a0e99cef92  jmp 0x000077A0E99CEED2
000077a0e99cef97  call 0x000077A0E980A9A0
000077a0e99cef9c  jmp 0x000077A0E99CEEDE
000077a0e99cefa1  call 0x000077A0E980BC20
000077a0e99cefa6  jmp 0x000077A0E99CEEF8
000077a0e99cefab  call 0x000077A0E980A9A0
000077a0e99cefb0  jmp 0x000077A0E99CEF04
000077a0e99cefb5  call 0x000077A0E980BC20
000077a0e99cefba  jmp 0x000077A0E99CEF1E
000077a0e99cefbf  call 0x000077A0E980A9A0
000077a0e99cefc4  jmp 0x000077A0E99CEF2A
000077a0e99cefc9  int3
000077a0e99cefca  nop [rax+rax*1], ax
000077a0e99cefd0  mov rax, [r15+0x08]
000077a0e99cefd4  movzx r14d, byte ptr [r13+rax*1]
000077a0e99cefda  movzx r14d, r14b
000077a0e99cefde  mov [rsp+0x10], r14d
000077a0e99cefe3  mov r14d, r14d
000077a0e99cefe6  mov [r15+0x58], r14
000077a0e99cefea  lea r14, [rax+0x01]
000077a0e99cefee  mov [r15+0x08], r14
000077a0e99ceff2  mov rax, [r15+0x88]
000077a0e99ceff9  lea r14, [rax+0x01]
000077a0e99ceffd  mov r12, [r15]
000077a0e99cf000  lea r11, [r12+0x68]
000077a0e99cf005  mov [r13+r11*1], r14
000077a0e99cf00a  lea r14, [r12+rax*1]
000077a0e99cf00e  mov [r15+0x60], r14
000077a0e99cf012  lea rax, [r14+0x28]
000077a0e99cf016  mov r11d, [rsp+0x10]
000077a0e99cf01b  movzx r14d, r11b
000077a0e99cf01f  mov [r13+rax*1], r14b
000077a0e99cf024  lea rax, [r12+0x68]
000077a0e99cf029  mov r14, [r13+rax*1]
000077a0e99cf02e  mov [r15+0x88], r14
000077a0e99cf035  xor eax, eax
000077a0e99cf037  mov r12d, 0x40
000077a0e99cf03d  cmp r14, r12
000077a0e99cf040  cmc
000077a0e99cf041  lahf
000077a0e99cf042  seto al
000077a0e99cf045  mov [r15+0x108], eax
000077a0e99cf04c  mov eax, [r15+0x108]
000077a0e99cf053  sahf
000077a0e99cf054  jnz 0x000077A0E99CF086
000077a0e99cf056  cmp dword ptr [r15+0x318], 0x00
000077a0e99cf05e  jz 0x000077A0E99CF170
000077a0e99cf064  nop [rax+rax*1], ax
000077a0e99cf06d  nop [rax+rax*1], eax
000077a0e99cf075  mov eax, 0x410724
000077a0e99cf07a  mov [r15+0x100], rax
000077a0e99cf081  jmp 0x000077A0E97FE110
000077a0e99cf086  cmp dword ptr [r15+0x318], 0x00
000077a0e99cf08e  jz 0x000077A0E99CF0E0
000077a0e99cf094  nop [rax+rax*1], ax
000077a0e99cf09d  nop [rax+rax*1], eax
000077a0e99cf0a5  mov eax, 0x4106FC
000077a0e99cf0aa  mov [r15+0x100], rax
000077a0e99cf0b1  jmp 0x000077A0E97FE110
000077a0e99cf0b6  int3
000077a0e99cf0b7  call 0x000077A0E980D860
000077a0e99cf0bc  jmp 0x000077A0E99CEFDA
000077a0e99cf0c1  call 0x000077A0E98B36E0
000077a0e99cf0c6  jmp 0x000077A0E99CF00A
000077a0e99cf0cb  call 0x000077A0E980DD60
000077a0e99cf0d0  jmp 0x000077A0E99CF024
000077a0e99cf0d5  call 0x000077A0E980DC20
000077a0e99cf0da  jmp 0x000077A0E99CF02E
000077a0e99cf0df  int3
000077a0e99cf0e0  mov rax, [r15+0x10]
000077a0e99cf0e4  lea r14, [rax-0x01]
000077a0e99cf0e8  mov [r15+0x10], r14
000077a0e99cf0ec  test r14, r14
000077a0e99cf0ef  setz r14b
000077a0e99cf0f3  movzx r14, r14b
000077a0e99cf0f7  mov [rsp+0x414], r14b
000077a0e99cf0ff  cmp byte ptr [rsp+0x414], 0x00
000077a0e99cf107  jz 0x000077A0E99CF139
000077a0e99cf109  cmp dword ptr [r15+0x318], 0x00
000077a0e99cf111  jz 0x000077A0E99D0670
000077a0e99cf117  nop [rax+rax*1], ax
000077a0e99cf120  nop [rax+rax*1], eax
000077a0e99cf128  mov eax, 0x41091C
000077a0e99cf12d  mov [r15+0x100], rax
000077a0e99cf134  jmp 0x000077A0E97FE110
000077a0e99cf139  cmp dword ptr [r15+0x318], 0x00
000077a0e99cf141  jz 0x000077A0E99CEFD0
000077a0e99cf147  nop [rax+rax*1], ax
000077a0e99cf150  nop [rax+rax*1], eax
000077a0e99cf158  mov eax, 0x410704
000077a0e99cf15d  mov [r15+0x100], rax
000077a0e99cf164  jmp 0x000077A0E97FE110
000077a0e99cf169  int3
000077a0e99cf16a  int3
000077a0e99cf16b  nop [rax+rax*1], eax
000077a0e99cf170  mov rax, [r15+0x40]
000077a0e99cf174  movzx r14d, byte ptr [r13+rax*1]
000077a0e99cf17a  movaps xmm1, [r15+0x110]
000077a0e99cf182  pinsrb xmm1, r14d, 0x00
000077a0e99cf189  lea r14, [rax+0x01]
000077a0e99cf18d  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf193  movaps xmm15, [r15+0x120]
000077a0e99cf19b  pinsrb xmm15, r12d, 0x00
000077a0e99cf1a2  lea r14, [rax+0x02]
000077a0e99cf1a6  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf1ac  movaps xmm14, [r15+0x130]
000077a0e99cf1b4  pinsrb xmm14, r12d, 0x00
000077a0e99cf1bb  lea r14, [rax+0x03]
000077a0e99cf1bf  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf1c5  movaps xmm13, [r15+0x140]
000077a0e99cf1cd  pinsrb xmm13, r12d, 0x00
000077a0e99cf1d4  lea r14, [rax+0x04]
000077a0e99cf1d8  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf1de  pinsrb xmm1, r12d, 0x01
000077a0e99cf1e5  lea r14, [rax+0x05]
000077a0e99cf1e9  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf1ef  pinsrb xmm15, r12d, 0x01
000077a0e99cf1f6  lea r14, [rax+0x06]
000077a0e99cf1fa  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf200  pinsrb xmm14, r12d, 0x01
000077a0e99cf207  lea r14, [rax+0x07]
000077a0e99cf20b  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf211  pinsrb xmm13, r12d, 0x01
000077a0e99cf218  lea r14, [rax+0x08]
000077a0e99cf21c  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf222  pinsrb xmm1, r12d, 0x02
000077a0e99cf229  lea r14, [rax+0x09]
000077a0e99cf22d  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf233  pinsrb xmm15, r12d, 0x02
000077a0e99cf23a  lea r14, [rax+0x0A]
000077a0e99cf23e  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf244  pinsrb xmm14, r12d, 0x02
000077a0e99cf24b  lea r14, [rax+0x0B]
000077a0e99cf24f  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf255  pinsrb xmm13, r12d, 0x02
000077a0e99cf25c  lea r14, [rax+0x0C]
000077a0e99cf260  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf266  pinsrb xmm1, r12d, 0x03
000077a0e99cf26d  lea r14, [rax+0x0D]
000077a0e99cf271  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf277  pinsrb xmm15, r12d, 0x03
000077a0e99cf27e  lea r14, [rax+0x0E]
000077a0e99cf282  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf288  pinsrb xmm14, r12d, 0x03
000077a0e99cf28f  lea r14, [rax+0x0F]
000077a0e99cf293  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf299  pinsrb xmm13, r12d, 0x03
000077a0e99cf2a0  lea r14, [rax+0x10]
000077a0e99cf2a4  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf2aa  pinsrb xmm1, r12d, 0x04
000077a0e99cf2b1  lea r14, [rax+0x11]
000077a0e99cf2b5  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf2bb  pinsrb xmm15, r12d, 0x04
000077a0e99cf2c2  lea r14, [rax+0x12]
000077a0e99cf2c6  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf2cc  pinsrb xmm14, r12d, 0x04
000077a0e99cf2d3  lea r14, [rax+0x13]
000077a0e99cf2d7  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf2dd  pinsrb xmm13, r12d, 0x04
000077a0e99cf2e4  lea r14, [rax+0x14]
000077a0e99cf2e8  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf2ee  pinsrb xmm1, r12d, 0x05
000077a0e99cf2f5  lea r14, [rax+0x15]
000077a0e99cf2f9  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf2ff  pinsrb xmm15, r12d, 0x05
000077a0e99cf306  lea r14, [rax+0x16]
000077a0e99cf30a  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf310  pinsrb xmm14, r12d, 0x05
000077a0e99cf317  lea r14, [rax+0x17]
000077a0e99cf31b  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf321  pinsrb xmm13, r12d, 0x05
000077a0e99cf328  lea r14, [rax+0x18]
000077a0e99cf32c  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf332  pinsrb xmm1, r12d, 0x06
000077a0e99cf339  lea r14, [rax+0x19]
000077a0e99cf33d  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf343  pinsrb xmm15, r12d, 0x06
000077a0e99cf34a  lea r14, [rax+0x1A]
000077a0e99cf34e  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf354  pinsrb xmm14, r12d, 0x06
000077a0e99cf35b  lea r14, [rax+0x1B]
000077a0e99cf35f  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf365  pinsrb xmm13, r12d, 0x06
000077a0e99cf36c  lea r14, [rax+0x1C]
000077a0e99cf370  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf376  pinsrb xmm1, r12d, 0x07
000077a0e99cf37d  lea r14, [rax+0x1D]
000077a0e99cf381  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf387  pinsrb xmm15, r12d, 0x07
000077a0e99cf38e  lea r14, [rax+0x1E]
000077a0e99cf392  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf398  pinsrb xmm14, r12d, 0x07
000077a0e99cf39f  lea r14, [rax+0x1F]
000077a0e99cf3a3  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf3a9  pinsrb xmm13, r12d, 0x07
000077a0e99cf3b0  lea r14, [rax+0x20]
000077a0e99cf3b4  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf3ba  pinsrb xmm1, r12d, 0x08
000077a0e99cf3c1  lea r14, [rax+0x21]
000077a0e99cf3c5  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf3cb  pinsrb xmm15, r12d, 0x08
000077a0e99cf3d2  lea r14, [rax+0x22]
000077a0e99cf3d6  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf3dc  pinsrb xmm14, r12d, 0x08
000077a0e99cf3e3  lea r14, [rax+0x23]
000077a0e99cf3e7  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf3ed  pinsrb xmm13, r12d, 0x08
000077a0e99cf3f4  lea r14, [rax+0x24]
000077a0e99cf3f8  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf3fe  pinsrb xmm1, r12d, 0x09
000077a0e99cf405  lea r14, [rax+0x25]
000077a0e99cf409  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf40f  pinsrb xmm15, r12d, 0x09
000077a0e99cf416  lea r14, [rax+0x26]
000077a0e99cf41a  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf420  pinsrb xmm14, r12d, 0x09
000077a0e99cf427  lea r14, [rax+0x27]
000077a0e99cf42b  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf431  pinsrb xmm13, r12d, 0x09
000077a0e99cf438  lea r14, [rax+0x28]
000077a0e99cf43c  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf442  pinsrb xmm1, r12d, 0x0A
000077a0e99cf449  lea r14, [rax+0x29]
000077a0e99cf44d  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf453  pinsrb xmm15, r12d, 0x0A
000077a0e99cf45a  lea r14, [rax+0x2A]
000077a0e99cf45e  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf464  pinsrb xmm14, r12d, 0x0A
000077a0e99cf46b  lea r14, [rax+0x2B]
000077a0e99cf46f  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf475  pinsrb xmm13, r12d, 0x0A
000077a0e99cf47c  lea r14, [rax+0x2C]
000077a0e99cf480  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf486  pinsrb xmm1, r12d, 0x0B
000077a0e99cf48d  lea r14, [rax+0x2D]
000077a0e99cf491  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf497  pinsrb xmm15, r12d, 0x0B
000077a0e99cf49e  lea r14, [rax+0x2E]
000077a0e99cf4a2  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf4a8  pinsrb xmm14, r12d, 0x0B
000077a0e99cf4af  lea r14, [rax+0x2F]
000077a0e99cf4b3  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf4b9  pinsrb xmm13, r12d, 0x0B
000077a0e99cf4c0  lea r14, [rax+0x30]
000077a0e99cf4c4  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf4ca  pinsrb xmm1, r12d, 0x0C
000077a0e99cf4d1  lea r14, [rax+0x31]
000077a0e99cf4d5  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf4db  pinsrb xmm15, r12d, 0x0C
000077a0e99cf4e2  lea r14, [rax+0x32]
000077a0e99cf4e6  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf4ec  pinsrb xmm14, r12d, 0x0C
000077a0e99cf4f3  lea r14, [rax+0x33]
000077a0e99cf4f7  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf4fd  pinsrb xmm13, r12d, 0x0C
000077a0e99cf504  lea r14, [rax+0x34]
000077a0e99cf508  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf50e  pinsrb xmm1, r12d, 0x0D
000077a0e99cf515  lea r14, [rax+0x35]
000077a0e99cf519  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf51f  pinsrb xmm15, r12d, 0x0D
000077a0e99cf526  lea r14, [rax+0x36]
000077a0e99cf52a  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf530  pinsrb xmm14, r12d, 0x0D
000077a0e99cf537  lea r14, [rax+0x37]
000077a0e99cf53b  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf541  pinsrb xmm13, r12d, 0x0D
000077a0e99cf548  lea r14, [rax+0x38]
000077a0e99cf54c  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf552  pinsrb xmm1, r12d, 0x0E
000077a0e99cf559  lea r14, [rax+0x39]
000077a0e99cf55d  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf563  pinsrb xmm15, r12d, 0x0E
000077a0e99cf56a  lea r14, [rax+0x3A]
000077a0e99cf56e  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf574  pinsrb xmm14, r12d, 0x0E
000077a0e99cf57b  lea r14, [rax+0x3B]
000077a0e99cf57f  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf585  pinsrb xmm13, r12d, 0x0E
000077a0e99cf58c  lea r14, [rax+0x3C]
000077a0e99cf590  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf596  pinsrb xmm1, r12d, 0x0F
000077a0e99cf59d  movaps [r15+0x110], xmm1
000077a0e99cf5a5  lea r14, [rax+0x3D]
000077a0e99cf5a9  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf5af  pinsrb xmm15, r12d, 0x0F
000077a0e99cf5b6  movaps [r15+0x120], xmm15
000077a0e99cf5be  lea r14, [rax+0x3E]
000077a0e99cf5c2  movzx r12d, byte ptr [r13+r14*1]
000077a0e99cf5c8  pinsrb xmm14, r12d, 0x0F
000077a0e99cf5cf  movaps [r15+0x130], xmm14
000077a0e99cf5d7  lea r14, [rax+0x3F]
000077a0e99cf5db  movzx eax, byte ptr [r13+r14*1]
000077a0e99cf5e1  pinsrb xmm13, eax, 0x0F
000077a0e99cf5e8  movaps [r15+0x140], xmm13
000077a0e99cf5f0  movq xmm1, qword ptr [r15+0x120]
000077a0e99cf5f9  pmovzxbw xmm1, xmm1
000077a0e99cf5fe  psllw xmm1, 0x00
000077a0e99cf603  movaps [r15+0x150], xmm1
000077a0e99cf60b  movq xmm1, qword ptr [r15+0x130]
000077a0e99cf614  pmovzxbw xmm1, xmm1
000077a0e99cf619  psllw xmm1, 0x00
000077a0e99cf61e  movaps [r15+0x160], xmm1
000077a0e99cf626  movq xmm1, qword ptr [r15+0x110]
000077a0e99cf62f  pmovzxbw xmm1, xmm1
000077a0e99cf634  psllw xmm1, 0x00
000077a0e99cf639  movaps [r15+0x170], xmm1
000077a0e99cf641  movaps xmm15, [r15+0x110]
000077a0e99cf649  pextrq rax, xmm15, 0x01
000077a0e99cf650  movq xmm15, rax
000077a0e99cf655  pmovzxbw xmm15, xmm15
000077a0e99cf65b  psllw xmm15, 0x00
000077a0e99cf661  movaps [r15+0x180], xmm15
000077a0e99cf669  movaps xmm14, [r15+0x120]
000077a0e99cf671  pextrq rax, xmm14, 0x01
000077a0e99cf678  movq xmm14, rax
000077a0e99cf67d  pmovzxbw xmm14, xmm14
000077a0e99cf683  psllw xmm14, 0x00
000077a0e99cf689  movaps [r15+0x210], xmm14
000077a0e99cf691  movaps xmm13, [r15+0x130]
000077a0e99cf699  pextrq rax, xmm13, 0x01
000077a0e99cf6a0  movq xmm13, rax
000077a0e99cf6a5  pmovzxbw xmm13, xmm13
000077a0e99cf6ab  psllw xmm13, 0x00
000077a0e99cf6b1  movaps [r15+0x220], xmm13
000077a0e99cf6b9  movq xmm12, qword ptr [r15+0x140]
000077a0e99cf6c2  pmovzxbw xmm12, xmm12
000077a0e99cf6c8  psllw xmm12, 0x00
000077a0e99cf6ce  movaps [r15+0x250], xmm12
000077a0e99cf6d6  movaps xmm12, [r15+0x140]
000077a0e99cf6de  pextrq rax, xmm12, 0x01
000077a0e99cf6e5  movq xmm12, rax
000077a0e99cf6ea  pmovzxbw xmm12, xmm12
000077a0e99cf6f0  psllw xmm12, 0x00
000077a0e99cf6f6  movaps [r15+0x110], xmm12
000077a0e99cf6fe  movq xmm11, qword ptr [r15+0x150]
000077a0e99cf707  pmovzxwd xmm11, xmm11
000077a0e99cf70d  pslld xmm11, 0x10
000077a0e99cf713  movq xmm10, qword ptr [r15+0x160]
000077a0e99cf71c  pmovzxwd xmm10, xmm10
000077a0e99cf722  pslld xmm10, 0x08
000077a0e99cf728  pextrq rax, xmm1, 0x01
000077a0e99cf72f  movq xmm1, rax
000077a0e99cf734  pmovzxwd xmm1, xmm1
000077a0e99cf739  pslld xmm1, 0x00
000077a0e99cf73e  movaps [r15+0x260], xmm1
000077a0e99cf746  pextrq rax, xmm15, 0x01
000077a0e99cf74d  movq xmm15, rax
000077a0e99cf752  pmovzxwd xmm15, xmm15
000077a0e99cf758  pslld xmm15, 0x00
000077a0e99cf75e  movaps [r15+0x270], xmm15
000077a0e99cf766  movq xmm9, qword ptr [r15+0x170]
000077a0e99cf76f  pmovzxwd xmm9, xmm9
000077a0e99cf775  pslld xmm9, 0x00
000077a0e99cf77b  pextrq rax, xmm14, 0x01
000077a0e99cf782  movq xmm14, rax
000077a0e99cf787  pmovzxwd xmm14, xmm14
000077a0e99cf78d  pslld xmm14, 0x10
000077a0e99cf793  movaps [r15+0x280], xmm14
000077a0e99cf79b  movq xmm8, qword ptr [r15+0x180]
000077a0e99cf7a4  pmovzxwd xmm8, xmm8
000077a0e99cf7aa  pslld xmm8, 0x00
000077a0e99cf7b0  movq xmm7, qword ptr [r15+0x210]
000077a0e99cf7b9  pmovzxwd xmm7, xmm7
000077a0e99cf7be  pslld xmm7, 0x10
000077a0e99cf7c3  movaps xmm6, [r15+0x150]
000077a0e99cf7cb  pextrq rax, xmm6, 0x01
000077a0e99cf7d2  movq xmm6, rax
000077a0e99cf7d7  pmovzxwd xmm6, xmm6
000077a0e99cf7dc  pslld xmm6, 0x10
000077a0e99cf7e1  por xmm11, xmm10
000077a0e99cf7e6  movaps [r15+0x230], xmm11
000077a0e99cf7ee  pextrq rax, xmm13, 0x01
000077a0e99cf7f5  movq xmm13, rax
000077a0e99cf7fa  pmovzxwd xmm13, xmm13
000077a0e99cf800  pslld xmm13, 0x08
000077a0e99cf806  movaps [r15+0x240], xmm13
000077a0e99cf80e  movq xmm10, qword ptr [r15+0x220]
000077a0e99cf817  pmovzxwd xmm10, xmm10
000077a0e99cf81d  pslld xmm10, 0x08
000077a0e99cf823  movaps xmm5, [r15+0x160]
000077a0e99cf82b  pextrq rax, xmm5, 0x01
000077a0e99cf832  movq xmm5, rax
000077a0e99cf837  pmovzxwd xmm5, xmm5
000077a0e99cf83c  pslld xmm5, 0x08
000077a0e99cf841  pslld xmm9, 0x18
000077a0e99cf847  pslld xmm15, 0x18
000077a0e99cf84d  pslld xmm8, 0x18
000077a0e99cf853  movq xmm4, qword ptr [r15+0x250]
000077a0e99cf85c  pmovzxwd xmm4, xmm4
000077a0e99cf861  pslld xmm4, 0x00
000077a0e99cf866  por xmm14, xmm13
000077a0e99cf86b  por xmm7, xmm10
000077a0e99cf870  movaps [r15+0x210], xmm7
000077a0e99cf878  pslld xmm1, 0x18
000077a0e99cf87d  movaps [r15+0x220], xmm1
000077a0e99cf885  por xmm6, xmm5
000077a0e99cf889  por xmm11, xmm9
000077a0e99cf88e  movaps [r15+0x160], xmm11
000077a0e99cf896  pextrq rax, xmm12, 0x01
000077a0e99cf89d  movq xmm13, rax
000077a0e99cf8a2  pmovzxwd xmm13, xmm13
000077a0e99cf8a8  pslld xmm13, 0x00
000077a0e99cf8ae  movaps [r15+0x170], xmm13
000077a0e99cf8b6  movq xmm12, qword ptr [r15+0x110]
000077a0e99cf8bf  pmovzxwd xmm12, xmm12
000077a0e99cf8c5  pslld xmm12, 0x00
000077a0e99cf8cb  por xmm14, xmm15
000077a0e99cf8d0  por xmm7, xmm8
000077a0e99cf8d5  movaps xmm15, [r15+0x250]
000077a0e99cf8dd  pextrq rax, xmm15, 0x01
000077a0e99cf8e4  movq xmm15, rax
000077a0e99cf8e9  pmovzxwd xmm15, xmm15
000077a0e99cf8ef  pslld xmm15, 0x00
000077a0e99cf8f5  movaps [r15+0x180], xmm15
000077a0e99cf8fd  por xmm6, xmm1
000077a0e99cf901  movaps [r15+0x150], xmm6
000077a0e99cf909  por xmm11, xmm4
000077a0e99cf90e  movaps [r15+0x140], xmm11
000077a0e99cf916  por xmm7, xmm12
000077a0e99cf91b  movaps [r15+0x110], xmm7
000077a0e99cf923  por xmm14, xmm13
000077a0e99cf928  movaps [r15+0x120], xmm14
000077a0e99cf930  por xmm6, xmm15
000077a0e99cf935  movaps [r15+0x130], xmm6
000077a0e99cf93d  mov rax, [r15+0xF8]
000077a0e99cf944  lea r14, [rax+0x20]
000077a0e99cf948  movups [r13+r14*1], xmm7
000077a0e99cf94e  lea r14, [rax+0x30]
000077a0e99cf952  movups [r13+r14*1], xmm14
000077a0e99cf958  movups [r13+rax*1], xmm11
000077a0e99cf95e  lea r14, [rax+0x10]
000077a0e99cf962  movups [r13+r14*1], xmm6
000077a0e99cf968  mov r14d, [r13+rax*1]
000077a0e99cf96d  mov rax, [r15+0x48]
000077a0e99cf971  mov [r15+0x68], rax
000077a0e99cf975  mov qword ptr [r15+0x58], 0x04
000077a0e99cf97d  lea r12, [rax+0x04]
000077a0e99cf981  mov r11d, [r13+r12*1]
000077a0e99cf986  mov [rsp+0x10], r11d
000077a0e99cf98b  mov r11d, r11d
000077a0e99cf98e  mov [r15+0x70], r11
000077a0e99cf992  lea r12, [rax+0x38]
000077a0e99cf996  mov r11d, [r13+r12*1]
000077a0e99cf99b  lea r12, [rax+0x24]
000077a0e99cf99f  mov r10d, [r13+r12*1]
000077a0e99cf9a4  mov [rsp+0x20], r10d
000077a0e99cf9a9  mov r10d, r10d
000077a0e99cf9ac  mov [r15+0x90], r10
000077a0e99cf9b3  mov [rsp+0x30], rax
000077a0e99cf9b8  xor eax, eax
000077a0e99cf9ba  mov r12d, 0x04
000077a0e99cf9c0  mov r10d, 0xC0
000077a0e99cf9c6  cmp r12, r10
000077a0e99cf9c9  cmc
000077a0e99cf9ca  lahf
000077a0e99cf9cb  seto al
000077a0e99cf9ce  mov [r15+0x108], eax
000077a0e99cf9d5  mov eax, [rsp+0x10]
000077a0e99cf9d9  mov r12d, [rsp+0x10]
000077a0e99cf9de  shrd eax, r12d, 0x07
000077a0e99cf9e3  mov [rsp+0x10], r11d
000077a0e99cf9e8  mov r10d, [rsp+0x10]
000077a0e99cf9ed  shrd r11d, r10d, 0x11
000077a0e99cf9f2  mov r9d, [rsp+0x20]
000077a0e99cf9f7  lea r8d, [r9d+r14d*1]
000077a0e99cf9fc  rorx r14d, r12d, 0x12
000077a0e99cfa02  xor eax, r14d
000077a0e99cfa05  rorx r14d, r10d, 0x13
000077a0e99cfa0b  xor r11d, r14d
000077a0e99cfa0e  mov [rsp+0x10], r11d
000077a0e99cfa13  mov r11d, r11d
000077a0e99cfa16  mov [r15+0x88], r11
000077a0e99cfa1d  mov [rsp+0x20], r12d
000077a0e99cfa22  shr r12d, 0x03
000077a0e99cfa26  xor eax, r12d
000077a0e99cfa29  mov [rsp+0x40], eax
000077a0e99cfa2d  mov eax, eax
000077a0e99cfa2f  mov [r15+0x80], rax
000077a0e99cfa36  shr r10d, 0x0A
000077a0e99cfa3a  mov eax, [rsp+0x10]
000077a0e99cfa3e  xor eax, r10d
000077a0e99cfa41  mov [rsp+0x10], eax
000077a0e99cfa45  mov eax, eax
000077a0e99cfa47  mov [r15+0x78], rax
000077a0e99cfa4b  mov eax, [rsp+0x40]
000077a0e99cfa4f  lea r14d, [r8d+eax*1]
000077a0e99cfa54  mov eax, [rsp+0x10]
000077a0e99cfa58  lea r12d, [r14d+eax*1]
000077a0e99cfa5d  mov rax, [rsp+0x30]
000077a0e99cfa62  lea r14, [rax+0x40]
000077a0e99cfa66  mov [r13+r14*1], r12d
000077a0e99cfa6b  mov eax, [rsp+0x20]
000077a0e99cfa6f  mov eax, eax
000077a0e99cfa71  mov [r15+0x60], rax
000077a0e99cfa75  mov eax, [r15+0x108]
000077a0e99cfa7c  sahf
000077a0e99cfa7d  jnz 0x000077A0E99CFAAF
000077a0e99cfa7f  cmp dword ptr [r15+0x318], 0x00
000077a0e99cfa87  jz 0x000077A0E99CFF70
000077a0e99cfa8d  nop [rax+rax*1], ax
000077a0e99cfa96  nop [rax+rax*1], eax
000077a0e99cfa9e  mov eax, 0x410820
000077a0e99cfaa3  mov [r15+0x100], rax
000077a0e99cfaaa  jmp 0x000077A0E97FE110
000077a0e99cfaaf  cmp dword ptr [r15+0x318], 0x00
000077a0e99cfab7  jz 0x000077A0E99CFDC0
000077a0e99cfabd  nop [rax+rax*1], ax
000077a0e99cfac6  nop [rax+rax*1], eax
000077a0e99cface  mov eax, 0x4107D8
000077a0e99cfad3  mov [r15+0x100], rax
000077a0e99cfada  jmp 0x000077A0E97FE110
000077a0e99cfadf  int3
000077a0e99cfae0  call 0x000077A0E980D860
000077a0e99cfae5  jmp 0x000077A0E99CF17A
000077a0e99cfaea  call 0x000077A0E98E2420
000077a0e99cfaef  jmp 0x000077A0E99CF193
000077a0e99cfaf4  call 0x000077A0E98E2420
000077a0e99cfaf9  jmp 0x000077A0E99CF1AC
000077a0e99cfafe  call 0x000077A0E98E2420
000077a0e99cfb03  jmp 0x000077A0E99CF1C5
000077a0e99cfb08  call 0x000077A0E98E2420
000077a0e99cfb0d  jmp 0x000077A0E99CF1DE
000077a0e99cfb12  call 0x000077A0E98E2420
000077a0e99cfb17  jmp 0x000077A0E99CF1EF
000077a0e99cfb1c  call 0x000077A0E98E2420
000077a0e99cfb21  jmp 0x000077A0E99CF200
000077a0e99cfb26  call 0x000077A0E98E2420
000077a0e99cfb2b  jmp 0x000077A0E99CF211
000077a0e99cfb30  call 0x000077A0E98E2420
000077a0e99cfb35  jmp 0x000077A0E99CF222
000077a0e99cfb3a  call 0x000077A0E98E2420
000077a0e99cfb3f  jmp 0x000077A0E99CF233
000077a0e99cfb44  call 0x000077A0E98E2420
000077a0e99cfb49  jmp 0x000077A0E99CF244
000077a0e99cfb4e  call 0x000077A0E98E2420
000077a0e99cfb53  jmp 0x000077A0E99CF255
000077a0e99cfb58  call 0x000077A0E98E2420
000077a0e99cfb5d  jmp 0x000077A0E99CF266
000077a0e99cfb62  call 0x000077A0E98E2420
000077a0e99cfb67  jmp 0x000077A0E99CF277
000077a0e99cfb6c  call 0x000077A0E98E2420
000077a0e99cfb71  jmp 0x000077A0E99CF288
000077a0e99cfb76  call 0x000077A0E98E2420
000077a0e99cfb7b  jmp 0x000077A0E99CF299
000077a0e99cfb80  call 0x000077A0E98E2420
000077a0e99cfb85  jmp 0x000077A0E99CF2AA
000077a0e99cfb8a  call 0x000077A0E98E2420
000077a0e99cfb8f  jmp 0x000077A0E99CF2BB
000077a0e99cfb94  call 0x000077A0E98E2420
000077a0e99cfb99  jmp 0x000077A0E99CF2CC
000077a0e99cfb9e  call 0x000077A0E98E2420
000077a0e99cfba3  jmp 0x000077A0E99CF2DD
000077a0e99cfba8  call 0x000077A0E98E2420
000077a0e99cfbad  jmp 0x000077A0E99CF2EE
000077a0e99cfbb2  call 0x000077A0E98E2420
000077a0e99cfbb7  jmp 0x000077A0E99CF2FF
000077a0e99cfbbc  call 0x000077A0E98E2420
000077a0e99cfbc1  jmp 0x000077A0E99CF310
000077a0e99cfbc6  call 0x000077A0E98E2420
000077a0e99cfbcb  jmp 0x000077A0E99CF321
000077a0e99cfbd0  call 0x000077A0E98E2420
000077a0e99cfbd5  jmp 0x000077A0E99CF332
000077a0e99cfbda  call 0x000077A0E98E2420
000077a0e99cfbdf  jmp 0x000077A0E99CF343
000077a0e99cfbe4  call 0x000077A0E98E2420
000077a0e99cfbe9  jmp 0x000077A0E99CF354
000077a0e99cfbee  call 0x000077A0E98E2420
000077a0e99cfbf3  jmp 0x000077A0E99CF365
000077a0e99cfbf8  call 0x000077A0E98E2420
000077a0e99cfbfd  jmp 0x000077A0E99CF376
000077a0e99cfc02  call 0x000077A0E98E2420
000077a0e99cfc07  jmp 0x000077A0E99CF387
000077a0e99cfc0c  call 0x000077A0E98E2420
000077a0e99cfc11  jmp 0x000077A0E99CF398
000077a0e99cfc16  call 0x000077A0E98E2420
000077a0e99cfc1b  jmp 0x000077A0E99CF3A9
000077a0e99cfc20  call 0x000077A0E98E2420
000077a0e99cfc25  jmp 0x000077A0E99CF3BA
000077a0e99cfc2a  call 0x000077A0E98E2420
000077a0e99cfc2f  jmp 0x000077A0E99CF3CB
000077a0e99cfc34  call 0x000077A0E98E2420
000077a0e99cfc39  jmp 0x000077A0E99CF3DC
000077a0e99cfc3e  call 0x000077A0E98E2420
000077a0e99cfc43  jmp 0x000077A0E99CF3ED
000077a0e99cfc48  call 0x000077A0E98E2420
000077a0e99cfc4d  jmp 0x000077A0E99CF3FE
000077a0e99cfc52  call 0x000077A0E98E2420
000077a0e99cfc57  jmp 0x000077A0E99CF40F
000077a0e99cfc5c  call 0x000077A0E98E2420
000077a0e99cfc61  jmp 0x000077A0E99CF420
000077a0e99cfc66  call 0x000077A0E98E2420
000077a0e99cfc6b  jmp 0x000077A0E99CF431
000077a0e99cfc70  call 0x000077A0E98E2420
000077a0e99cfc75  jmp 0x000077A0E99CF442
000077a0e99cfc7a  call 0x000077A0E98E2420
000077a0e99cfc7f  jmp 0x000077A0E99CF453
000077a0e99cfc84  call 0x000077A0E98E2420
000077a0e99cfc89  jmp 0x000077A0E99CF464
000077a0e99cfc8e  call 0x000077A0E98E2420
000077a0e99cfc93  jmp 0x000077A0E99CF475
000077a0e99cfc98  call 0x000077A0E98E2420
000077a0e99cfc9d  jmp 0x000077A0E99CF486
000077a0e99cfca2  call 0x000077A0E98E2420
000077a0e99cfca7  jmp 0x000077A0E99CF497
000077a0e99cfcac  call 0x000077A0E98E2420
000077a0e99cfcb1  jmp 0x000077A0E99CF4A8
000077a0e99cfcb6  call 0x000077A0E98E2420
000077a0e99cfcbb  jmp 0x000077A0E99CF4B9
000077a0e99cfcc0  call 0x000077A0E98E2420
000077a0e99cfcc5  jmp 0x000077A0E99CF4CA
000077a0e99cfcca  call 0x000077A0E98E2420
000077a0e99cfccf  jmp 0x000077A0E99CF4DB
000077a0e99cfcd4  call 0x000077A0E98E2420
000077a0e99cfcd9  jmp 0x000077A0E99CF4EC
000077a0e99cfcde  call 0x000077A0E98E2420
000077a0e99cfce3  jmp 0x000077A0E99CF4FD
000077a0e99cfce8  call 0x000077A0E98E2420
000077a0e99cfced  jmp 0x000077A0E99CF50E
000077a0e99cfcf2  call 0x000077A0E98E2420
000077a0e99cfcf7  jmp 0x000077A0E99CF51F
000077a0e99cfcfc  call 0x000077A0E98E2420
000077a0e99cfd01  jmp 0x000077A0E99CF530
000077a0e99cfd06  call 0x000077A0E98E2420
000077a0e99cfd0b  jmp 0x000077A0E99CF541
000077a0e99cfd10  call 0x000077A0E98E2420
000077a0e99cfd15  jmp 0x000077A0E99CF552
000077a0e99cfd1a  call 0x000077A0E98E2420
000077a0e99cfd1f  jmp 0x000077A0E99CF563
000077a0e99cfd24  call 0x000077A0E98E2420
000077a0e99cfd29  jmp 0x000077A0E99CF574
000077a0e99cfd2e  call 0x000077A0E98E2420
000077a0e99cfd33  jmp 0x000077A0E99CF585
000077a0e99cfd38  call 0x000077A0E98E2420
000077a0e99cfd3d  jmp 0x000077A0E99CF596
000077a0e99cfd42  call 0x000077A0E98E2420
000077a0e99cfd47  jmp 0x000077A0E99CF5AF
000077a0e99cfd4c  call 0x000077A0E98E2420
000077a0e99cfd51  jmp 0x000077A0E99CF5C8
000077a0e99cfd56  call 0x000077A0E98D5610
000077a0e99cfd5b  jmp 0x000077A0E99CF5E1
000077a0e99cfd60  call 0x000077A0E98DC580
000077a0e99cfd65  jmp 0x000077A0E99CF94E
000077a0e99cfd6a  call 0x000077A0E98E46C0
000077a0e99cfd6f  jmp 0x000077A0E99CF958
000077a0e99cfd74  call 0x000077A0E9809E90
000077a0e99cfd79  jmp 0x000077A0E99CF95E
000077a0e99cfd7e  call 0x000077A0E98DB310
000077a0e99cfd83  jmp 0x000077A0E99CF968
000077a0e99cfd88  call 0x000077A0E980DAE0
000077a0e99cfd8d  jmp 0x000077A0E99CF96D
000077a0e99cfd92  call 0x000077A0E98C0230
000077a0e99cfd97  jmp 0x000077A0E99CF986
000077a0e99cfd9c  call 0x000077A0E98C0230
000077a0e99cfda1  jmp 0x000077A0E99CF99B
000077a0e99cfda6  call 0x000077A0E98BEFC0
000077a0e99cfdab  jmp 0x000077A0E99CF9A4
000077a0e99cfdb0  call 0x000077A0E98E2BA0
000077a0e99cfdb5  jmp 0x000077A0E99CFA6B
000077a0e99cfdba  int3
000077a0e99cfdbb  nop [rax+rax*1], eax
000077a0e99cfdc0  mov rax, [r15+0x48]
000077a0e99cfdc4  mov r14, [r15+0x58]
000077a0e99cfdc8  lea r12, [rax+r14*1]
000077a0e99cfdcc  mov [r15+0x68], r12
000077a0e99cfdd0  lea rax, [r14+0x04]
000077a0e99cfdd4  mov [r15+0x58], rax
000077a0e99cfdd8  lea r14, [r12+0x04]
000077a0e99cfddd  mov r11d, [r13+r14*1]
000077a0e99cfde2  mov [rsp+0x10], r11d
000077a0e99cfde7  mov r11d, r11d
000077a0e99cfdea  mov [r15+0x70], r11
000077a0e99cfdee  lea r14, [r12+0x38]
000077a0e99cfdf3  mov r11d, [r13+r14*1]
000077a0e99cfdf8  lea r14, [r12+0x24]
000077a0e99cfdfd  mov r10d, [r13+r14*1]
000077a0e99cfe02  mov [rsp+0x20], r10d
000077a0e99cfe07  mov r10d, r10d
000077a0e99cfe0a  mov [r15+0x90], r10
000077a0e99cfe11  mov [rsp+0x30], rax
000077a0e99cfe16  xor eax, eax
000077a0e99cfe18  mov r14, [rsp+0x30]
000077a0e99cfe1d  mov r10d, 0xC0
000077a0e99cfe23  cmp r14, r10
000077a0e99cfe26  cmc
000077a0e99cfe27  lahf
000077a0e99cfe28  seto al
000077a0e99cfe2b  mov [r15+0x108], eax
000077a0e99cfe32  mov eax, [rsp+0x10]
000077a0e99cfe36  mov r14d, [rsp+0x10]
000077a0e99cfe3b  shrd eax, r14d, 0x07
000077a0e99cfe40  mov [rsp+0x10], r11d
000077a0e99cfe45  mov r10d, [rsp+0x10]
000077a0e99cfe4a  shrd r11d, r10d, 0x11
000077a0e99cfe4f  mov r9d, [r15+0x60]
000077a0e99cfe53  mov r8d, [rsp+0x20]
000077a0e99cfe58  lea ebp, [r8d+r9d*1]
000077a0e99cfe5d  rorx r9d, r14d, 0x12
000077a0e99cfe63  xor eax, r9d
000077a0e99cfe66  rorx r9d, r10d, 0x13
000077a0e99cfe6c  xor r11d, r9d
000077a0e99cfe6f  mov [rsp+0x10], r11d
000077a0e99cfe74  mov r11d, r11d
000077a0e99cfe77  mov [r15+0x88], r11
000077a0e99cfe7e  mov [rsp+0x20], r14d
000077a0e99cfe83  shr r14d, 0x03
000077a0e99cfe87  xor eax, r14d
000077a0e99cfe8a  mov [rsp+0x30], eax
000077a0e99cfe8e  mov eax, eax
000077a0e99cfe90  mov [r15+0x80], rax
000077a0e99cfe97  shr r10d, 0x0A
000077a0e99cfe9b  mov eax, [rsp+0x10]
000077a0e99cfe9f  xor eax, r10d
000077a0e99cfea2  mov [rsp+0x10], eax
000077a0e99cfea6  mov eax, eax
000077a0e99cfea8  mov [r15+0x78], rax
000077a0e99cfeac  mov eax, [rsp+0x30]
000077a0e99cfeb0  lea r14d, [ebp+eax*1]
000077a0e99cfeb6  mov eax, [rsp+0x10]
000077a0e99cfeba  lea r11d, [r14d+eax*1]
000077a0e99cfebf  lea rax, [r12+0x40]
000077a0e99cfec4  mov [r13+rax*1], r11d
000077a0e99cfec9  mov eax, [rsp+0x20]
000077a0e99cfecd  mov eax, eax
000077a0e99cfecf  mov [r15+0x60], rax
000077a0e99cfed3  mov eax, [r15+0x108]
000077a0e99cfeda  sahf
000077a0e99cfedb  jnz 0x000077A0E99CFF0D
000077a0e99cfedd  cmp dword ptr [r15+0x318], 0x00
000077a0e99cfee5  jz 0x000077A0E99CFF70
000077a0e99cfeeb  nop [rax+rax*1], ax
000077a0e99cfef4  nop [rax+rax*1], eax
000077a0e99cfefc  mov eax, 0x410820
000077a0e99cff01  mov [r15+0x100], rax
000077a0e99cff08  jmp 0x000077A0E97FE110
000077a0e99cff0d  cmp dword ptr [r15+0x318], 0x00
000077a0e99cff15  jz 0x000077A0E99CFDC0
000077a0e99cff1b  nop [rax+rax*1], ax
000077a0e99cff24  nop [rax+rax*1], eax
000077a0e99cff2c  mov eax, 0x4107D8
000077a0e99cff31  mov [r15+0x100], rax
000077a0e99cff38  jmp 0x000077A0E97FE110
000077a0e99cff3d  int3
000077a0e99cff3e  call 0x000077A0E98E1430
000077a0e99cff43  jmp 0x000077A0E99CFDE2
000077a0e99cff48  call 0x000077A0E98E1430
000077a0e99cff4d  jmp 0x000077A0E99CFDF8
000077a0e99cff52  call 0x000077A0E98E01C0
000077a0e99cff57  jmp 0x000077A0E99CFE02
000077a0e99cff5c  call 0x000077A0E980A860
000077a0e99cff61  jmp 0x000077A0E99CFEC9
000077a0e99cff66  int3
000077a0e99cff67  nop [rax+rax*1], ax
000077a0e99cff70  mov rax, [r15]
000077a0e99cff73  mov r14d, [r13+rax*1]
000077a0e99cff78  lea r12, [rax+0x04]
000077a0e99cff7c  mov r11d, [r13+r12*1]
000077a0e99cff81  mov [rsp+0x10], r14d
000077a0e99cff86  mov r14d, r14d
000077a0e99cff89  mov [r15+0x78], r14
000077a0e99cff8d  mov [rsp+0x20], r11d
000077a0e99cff92  mov r11d, r11d
000077a0e99cff95  mov [r15+0x80], r11
000077a0e99cff9c  lea r14, [rax+0x08]
000077a0e99cffa0  mov r12d, [r13+r14*1]
000077a0e99cffa5  lea r14, [rax+0x0C]
000077a0e99cffa9  mov r11d, [r13+r14*1]
000077a0e99cffae  mov [rsp+0x30], r12d
000077a0e99cffb3  mov r12d, r12d
000077a0e99cffb6  mov [r15+0x70], r12
000077a0e99cffba  mov [rsp+0x40], r11d
000077a0e99cffbf  mov r11d, r11d
000077a0e99cffc2  mov [r15+0x68], r11
000077a0e99cffc6  lea r14, [rax+0x18]
000077a0e99cffca  mov r12d, [r13+r14*1]
000077a0e99cffcf  lea r14, [rax+0x1C]
000077a0e99cffd3  mov r11d, [r13+r14*1]
000077a0e99cffd8  mov [rsp+0x50], r12d
000077a0e99cffdd  mov r12d, r12d
000077a0e99cffe0  mov [r15+0x58], r12
000077a0e99cffe4  mov [rsp+0x60], r11d
000077a0e99cffe9  mov r11d, r11d
000077a0e99cffec  mov [r15+0x60], r11
000077a0e99cfff0  lea r14, [rax+0x10]
000077a0e99cfff4  mov r12d, [r13+r14*1]
000077a0e99cfff9  lea r14, [rax+0x14]
000077a0e99cfffd  mov eax, [r13+r14*1]
000077a0e99d0002  mov [rsp+0x70], r12d
000077a0e99d0007  mov r12d, r12d
000077a0e99d000a  mov [r15+0x18], r12
000077a0e99d000e  mov [rsp+0x80], eax
000077a0e99d0015  mov eax, eax
000077a0e99d0017  mov [r15+0x90], rax
000077a0e99d001e  mov eax, [rsp+0x70]
000077a0e99d0022  mov eax, eax
000077a0e99d0024  mov [r15+0x30], rax
000077a0e99d0028  mov eax, [rsp+0x50]
000077a0e99d002c  mov eax, eax
000077a0e99d002e  mov [r15+0xA0], rax
000077a0e99d0035  mov eax, [rsp+0x30]
000077a0e99d0039  mov eax, eax
000077a0e99d003b  mov [r15+0x28], rax
000077a0e99d003f  mov eax, [rsp+0x20]
000077a0e99d0043  mov eax, eax
000077a0e99d0045  mov [r15+0x98], rax
000077a0e99d004c  mov eax, [rsp+0x10]
000077a0e99d0050  mov eax, eax
000077a0e99d0052  mov [r15+0x38], rax
000077a0e99d0056  mov eax, [rsp+0x70]
000077a0e99d005a  mov r14d, [rsp+0x70]
000077a0e99d005f  shrd eax, r14d, 0x06
000077a0e99d0064  mov [rsp+0x70], r14d
000077a0e99d0069  mov r12d, [rsp+0x80]
000077a0e99d0071  and r14d, r12d
000077a0e99d0074  mov r11d, [rsp+0x10]
000077a0e99d0079  mov r10d, [rsp+0x10]
000077a0e99d007e  shrd r11d, r10d, 0x02
000077a0e99d0083  mov [rsp+0x10], r12d
000077a0e99d0088  mov r12d, r12d
000077a0e99d008b  mov [r15+0x20], r12
000077a0e99d008f  mov r12, [r15+0x50]
000077a0e99d0093  mov r9d, [r13+r12*1]
000077a0e99d0098  mov r12d, [rsp+0x50]
000077a0e99d009d  mov r8d, [rsp+0x70]
000077a0e99d00a2  andn ebp, r8d, r12d
000077a0e99d00a7  mov edi, [rsp+0x60]
000077a0e99d00ab  lea esi, [r14d+edi*1]
000077a0e99d00b0  rorx r14d, r8d, 0x0B
000077a0e99d00b6  xor eax, r14d
000077a0e99d00b9  rorx r14d, r10d, 0x0D
000077a0e99d00bf  xor r11d, r14d
000077a0e99d00c2  lea edi, [esi+ebp*1]
000077a0e99d00c6  mov r14, [r15+0x48]
000077a0e99d00ca  mov ebp, [r13+r14*1]
000077a0e99d00cf  mov r14d, [rsp+0x30]
000077a0e99d00d4  mov esi, [rsp+0x20]
000077a0e99d00d8  and r14d, esi
000077a0e99d00db  mov [rsp+0x20], r14d
000077a0e99d00e0  mov r14d, r14d
000077a0e99d00e3  mov [r15+0xD8], r14
000077a0e99d00ea  lea r14d, [edi+r9d*1]
000077a0e99d00ef  mov r9d, [rsp+0x30]
000077a0e99d00f4  xor r9d, esi
000077a0e99d00f7  rorx edi, r8d, 0x19
000077a0e99d00fd  xor eax, edi
000077a0e99d00ff  and r9d, r10d
000077a0e99d0102  rorx edi, r10d, 0x16
000077a0e99d0108  xor r11d, edi
000077a0e99d010b  mov [rsp+0x30], r11d
000077a0e99d0110  mov r11d, r11d
000077a0e99d0113  mov [r15+0xD0], r11
000077a0e99d011a  lea r11d, [r14d+ebp*1]
000077a0e99d011f  mov r10d, [rsp+0x20]
000077a0e99d0124  xor r9d, r10d
000077a0e99d0127  lea r14d, [r11d+eax*1]
000077a0e99d012c  mov qword ptr [r15+0x88], 0x04
000077a0e99d0137  mov eax, [rsp+0x30]
000077a0e99d013b  lea r11d, [r9d+eax*1]
000077a0e99d0140  mov eax, [rsp+0x40]
000077a0e99d0144  lea r10d, [r14d+eax*1]
000077a0e99d0149  mov r10d, r10d
000077a0e99d014c  mov [r15+0xB8], r10
000077a0e99d0153  xor eax, eax
000077a0e99d0155  mov r10d, 0x04
000077a0e99d015b  mov r9d, 0x100
000077a0e99d0161  cmp r10, r9
000077a0e99d0164  cmc
000077a0e99d0165  lahf
000077a0e99d0166  seto al
000077a0e99d0169  mov [r15+0x108], eax
000077a0e99d0170  lea eax, [r11d+r14d*1]
000077a0e99d0175  mov eax, eax
000077a0e99d0177  mov [r15+0xA8], rax
000077a0e99d017e  mov r12d, r12d
000077a0e99d0181  mov [r15+0xB0], r12
000077a0e99d0188  mov eax, [rsp+0x10]
000077a0e99d018c  mov eax, eax
000077a0e99d018e  mov [r15+0xC0], rax
000077a0e99d0195  mov r8d, r8d
000077a0e99d0198  mov [r15+0xC8], r8
000077a0e99d019f  mov eax, [r15+0x108]
000077a0e99d01a6  sahf
000077a0e99d01a7  jnz 0x000077A0E99D01D9
000077a0e99d01a9  cmp dword ptr [r15+0x318], 0x00
000077a0e99d01b1  jz 0x000077A0E99D04A0
000077a0e99d01b7  nop [rax+rax*1], ax
000077a0e99d01c0  nop [rax+rax*1], eax
000077a0e99d01c8  mov eax, 0x4108E0
000077a0e99d01cd  mov [r15+0x100], rax
000077a0e99d01d4  jmp 0x000077A0E97FE110
000077a0e99d01d9  cmp dword ptr [r15+0x318], 0x00
000077a0e99d01e1  jz 0x000077A0E99D0270
000077a0e99d01e7  nop [rax+rax*1], ax
000077a0e99d01f0  nop [rax+rax*1], eax
000077a0e99d01f8  mov eax, 0x410854
000077a0e99d01fd  mov [r15+0x100], rax
000077a0e99d0204  jmp 0x000077A0E97FE110
000077a0e99d0209  int3
000077a0e99d020a  call 0x000077A0E980DAE0
000077a0e99d020f  jmp 0x000077A0E99CFF78
000077a0e99d0214  call 0x000077A0E98C0230
000077a0e99d0219  jmp 0x000077A0E99CFF81
000077a0e99d021e  call 0x000077A0E98E26A0
000077a0e99d0223  jmp 0x000077A0E99CFFA5
000077a0e99d0228  call 0x000077A0E98E1430
000077a0e99d022d  jmp 0x000077A0E99CFFAE
000077a0e99d0232  call 0x000077A0E98E26A0
000077a0e99d0237  jmp 0x000077A0E99CFFCF
000077a0e99d023c  call 0x000077A0E98E1430
000077a0e99d0241  jmp 0x000077A0E99CFFD8
000077a0e99d0246  call 0x000077A0E98E26A0
000077a0e99d024b  jmp 0x000077A0E99CFFF9
000077a0e99d0250  call 0x000077A0E98D5890
000077a0e99d0255  jmp 0x000077A0E99D0002
000077a0e99d025a  call 0x000077A0E98BDD50
000077a0e99d025f  jmp 0x000077A0E99D0098
000077a0e99d0264  call 0x000077A0E98DA580
000077a0e99d0269  jmp 0x000077A0E99D00CF
000077a0e99d026e  int3
000077a0e99d026f  nop
000077a0e99d0270  mov eax, [r15+0xB8]
000077a0e99d0277  mov [rsp+0x10], eax
000077a0e99d027b  mov eax, eax
000077a0e99d027d  mov [r15+0x30], rax
000077a0e99d0281  mov eax, [r15+0xC0]
000077a0e99d0288  mov [rsp+0x20], eax
000077a0e99d028c  mov eax, eax
000077a0e99d028e  mov [r15+0xA0], rax
000077a0e99d0295  mov eax, [r15+0x28]
000077a0e99d0299  mov r14d, [r15+0x98]
000077a0e99d02a0  mov [rsp+0x30], r14d
000077a0e99d02a5  mov r14d, r14d
000077a0e99d02a8  mov [r15+0x28], r14
000077a0e99d02ac  mov r14d, [r15+0x38]
000077a0e99d02b0  mov [rsp+0x40], r14d
000077a0e99d02b5  mov r14d, r14d
000077a0e99d02b8  mov [r15+0x98], r14
000077a0e99d02bf  mov r14d, [r15+0xA8]
000077a0e99d02c6  mov [rsp+0x50], r14d
000077a0e99d02cb  mov r14d, r14d
000077a0e99d02ce  mov [r15+0x38], r14
000077a0e99d02d2  mov r14d, [rsp+0x10]
000077a0e99d02d7  mov r12d, [rsp+0x10]
000077a0e99d02dc  shrd r14d, r12d, 0x06
000077a0e99d02e1  mov r11d, [r15+0xC8]
000077a0e99d02e8  mov [rsp+0x10], r12d
000077a0e99d02ed  and r12d, r11d
000077a0e99d02f0  mov r10d, [rsp+0x50]
000077a0e99d02f5  mov r9d, [rsp+0x50]
000077a0e99d02fa  shrd r10d, r9d, 0x02
000077a0e99d02ff  mov [rsp+0x50], r11d
000077a0e99d0304  mov r11d, r11d
000077a0e99d0307  mov [r15+0x20], r11
000077a0e99d030b  mov r11, [r15+0x88]
000077a0e99d0312  mov r8, [r15+0x50]
000077a0e99d0316  lea rbp, [r8+r11*1]
000077a0e99d031a  mov r8d, [r13+rbp*1]
000077a0e99d031f  mov ebp, [rsp+0x20]
000077a0e99d0323  mov edi, [rsp+0x10]
000077a0e99d0327  andn esi, edi, ebp
000077a0e99d032c  mov edx, [r15+0xB0]
000077a0e99d0333  lea ecx, [r12d+edx*1]
000077a0e99d0338  rorx r12d, edi, 0x0B
000077a0e99d033e  xor r14d, r12d
000077a0e99d0341  rorx r12d, r9d, 0x0D
000077a0e99d0347  xor r10d, r12d
000077a0e99d034a  lea r12d, [ecx+esi*1]
000077a0e99d034f  mov rsi, [r15+0x48]
000077a0e99d0353  lea rdx, [rsi+r11*1]
000077a0e99d0357  mov esi, [r13+rdx*1]
000077a0e99d035c  mov edx, [rsp+0x30]
000077a0e99d0360  mov ecx, [rsp+0x40]
000077a0e99d0364  and edx, ecx
000077a0e99d0366  mov [rsp+0x10], edx
000077a0e99d036a  mov edx, edx
000077a0e99d036c  mov [r15+0xD8], rdx
000077a0e99d0373  lea edx, [r12d+r8d*1]
000077a0e99d0378  mov r12d, [rsp+0x30]
000077a0e99d037d  xor r12d, ecx
000077a0e99d0380  rorx r8d, edi, 0x19
000077a0e99d0386  xor r14d, r8d
000077a0e99d0389  and r12d, r9d
000077a0e99d038c  rorx r8d, r9d, 0x16
000077a0e99d0392  xor r10d, r8d
000077a0e99d0395  mov [rsp+0x20], r10d
000077a0e99d039a  mov r10d, r10d
000077a0e99d039d  mov [r15+0xD0], r10
000077a0e99d03a4  lea r10d, [edx+esi*1]
000077a0e99d03a9  mov r9d, [rsp+0x10]
000077a0e99d03ae  xor r12d, r9d
000077a0e99d03b1  lea r9d, [r10d+r14d*1]
000077a0e99d03b6  lea r14, [r11+0x04]
000077a0e99d03ba  mov [r15+0x88], r14
000077a0e99d03c1  mov r11d, [rsp+0x20]
000077a0e99d03c6  lea r10d, [r12d+r11d*1]
000077a0e99d03cb  lea r11d, [r9d+eax*1]
000077a0e99d03d0  mov r11d, r11d
000077a0e99d03d3  mov [r15+0xB8], r11
000077a0e99d03da  xor eax, eax
000077a0e99d03dc  mov r12d, 0x100
000077a0e99d03e2  cmp r14, r12
000077a0e99d03e5  cmc
000077a0e99d03e6  lahf
000077a0e99d03e7  seto al
000077a0e99d03ea  mov [r15+0x108], eax
000077a0e99d03f1  lea eax, [r10d+r9d*1]
000077a0e99d03f6  mov eax, eax
000077a0e99d03f8  mov [r15+0xA8], rax
000077a0e99d03ff  mov ebp, ebp
000077a0e99d0401  mov [r15+0xB0], rbp
000077a0e99d0408  mov eax, [rsp+0x50]
000077a0e99d040c  mov eax, eax
000077a0e99d040e  mov [r15+0xC0], rax
000077a0e99d0415  mov edi, edi
000077a0e99d0417  mov [r15+0xC8], rdi
000077a0e99d041e  mov eax, [r15+0x108]
000077a0e99d0425  sahf
000077a0e99d0426  jnz 0x000077A0E99D0458
000077a0e99d0428  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0430  jz 0x000077A0E99D04A0
000077a0e99d0436  nop [rax+rax*1], ax
000077a0e99d043f  nop [rax+rax*1], eax
000077a0e99d0447  mov eax, 0x4108E0
000077a0e99d044c  mov [r15+0x100], rax
000077a0e99d0453  jmp 0x000077A0E97FE110
000077a0e99d0458  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0460  jz 0x000077A0E99D0270
000077a0e99d0466  nop [rax+rax*1], ax
000077a0e99d046f  nop [rax+rax*1], eax
000077a0e99d0477  mov eax, 0x410854
000077a0e99d047c  mov [r15+0x100], rax
000077a0e99d0483  jmp 0x000077A0E97FE110
000077a0e99d0488  int3
000077a0e99d0489  call 0x000077A0E9849010
000077a0e99d048e  jmp 0x000077A0E99D031F
000077a0e99d0493  call 0x000077A0E9825930
000077a0e99d0498  jmp 0x000077A0E99D035C
000077a0e99d049d  int3
000077a0e99d049e  nop
000077a0e99d04a0  mov eax, [r15+0x98]
000077a0e99d04a7  mov r14d, [r15+0x70]
000077a0e99d04ab  lea r12d, [eax+r14d*1]
000077a0e99d04b0  mov eax, [r15+0x28]
000077a0e99d04b4  mov r14d, [r15+0x68]
000077a0e99d04b8  lea r11d, [eax+r14d*1]
000077a0e99d04bd  mov qword ptr [r15+0x88], 0x00
000077a0e99d04c8  mov eax, [r15+0xA8]
000077a0e99d04cf  mov r14d, [r15+0x78]
000077a0e99d04d3  lea r10d, [eax+r14d*1]
000077a0e99d04d8  mov [rsp+0x10], r10d
000077a0e99d04dd  mov r10d, r10d
000077a0e99d04e0  mov [r15+0x78], r10
000077a0e99d04e4  mov eax, [r15+0x38]
000077a0e99d04e8  mov r14d, [r15+0x80]
000077a0e99d04ef  lea r10d, [eax+r14d*1]
000077a0e99d04f4  mov [rsp+0x20], r10d
000077a0e99d04f9  mov r10d, r10d
000077a0e99d04fc  mov [r15+0x80], r10
000077a0e99d0503  mov rax, [r15]
000077a0e99d0506  lea r14, [rax+0x08]
000077a0e99d050a  mov [r13+r14*1], r12d
000077a0e99d050f  lea r14, [rax+0x0C]
000077a0e99d0513  mov [r13+r14*1], r11d
000077a0e99d0518  mov r14d, [r15+0xB8]
000077a0e99d051f  mov r12d, [r15+0x18]
000077a0e99d0523  lea r11d, [r14d+r12d*1]
000077a0e99d0528  mov [rsp+0x30], r11d
000077a0e99d052d  mov r11d, r11d
000077a0e99d0530  mov [r15+0x68], r11
000077a0e99d0534  mov r14d, [r15+0x30]
000077a0e99d0538  mov r12d, [r15+0x90]
000077a0e99d053f  lea r11d, [r14d+r12d*1]
000077a0e99d0544  mov [rsp+0x40], r11d
000077a0e99d0549  mov r11d, r11d
000077a0e99d054c  mov [r15+0x70], r11
000077a0e99d0550  mov r14d, [r15+0x20]
000077a0e99d0554  mov r12d, [r15+0x58]
000077a0e99d0558  lea r11d, [r14d+r12d*1]
000077a0e99d055d  mov [rsp+0x50], r11d
000077a0e99d0562  mov r11d, r11d
000077a0e99d0565  mov [r15+0x58], r11
000077a0e99d0569  mov r14d, [r15+0xA0]
000077a0e99d0570  mov r12d, [r15+0x60]
000077a0e99d0574  lea r11d, [r14d+r12d*1]
000077a0e99d0579  mov [rsp+0x60], r11d
000077a0e99d057e  mov r11d, r11d
000077a0e99d0581  mov [r15+0x60], r11
000077a0e99d0585  mov r14d, [rsp+0x10]
000077a0e99d058a  mov [r13+rax*1], r14d
000077a0e99d058f  lea r14, [rax+0x04]
000077a0e99d0593  mov r12d, [rsp+0x20]
000077a0e99d0598  mov [r13+r14*1], r12d
000077a0e99d059d  lea r14, [rax+0x10]
000077a0e99d05a1  mov r12d, [rsp+0x30]
000077a0e99d05a6  mov [r13+r14*1], r12d
000077a0e99d05ab  lea r14, [rax+0x14]
000077a0e99d05af  mov r12d, [rsp+0x40]
000077a0e99d05b4  mov [r13+r14*1], r12d
000077a0e99d05b9  lea r14, [rax+0x18]
000077a0e99d05bd  mov r12d, [rsp+0x50]
000077a0e99d05c2  mov [r13+r14*1], r12d
000077a0e99d05c7  lea r14, [rax+0x1C]
000077a0e99d05cb  mov r12d, [rsp+0x60]
000077a0e99d05d0  mov [r13+r14*1], r12d
000077a0e99d05d5  lea r14, [rax+0x68]
000077a0e99d05d9  xor eax, eax
000077a0e99d05db  mov [r13+r14*1], rax
000077a0e99d05e0  cmp dword ptr [r15+0x318], 0x00
000077a0e99d05e8  jz 0x000077A0E99CF0E0
000077a0e99d05ee  nop [rax+rax*1], ax
000077a0e99d05f7  nop [rax+rax*1], eax
000077a0e99d05ff  mov eax, 0x4106FC
000077a0e99d0604  mov [r15+0x100], rax
000077a0e99d060b  jmp 0x000077A0E97FE110
000077a0e99d0610  int3
000077a0e99d0611  call 0x000077A0E98E2BA0
000077a0e99d0616  jmp 0x000077A0E99D050F
000077a0e99d061b  call 0x000077A0E98E1920
000077a0e99d0620  jmp 0x000077A0E99D0518
000077a0e99d0625  call 0x000077A0E980DFE0
000077a0e99d062a  jmp 0x000077A0E99D058F
000077a0e99d062f  call 0x000077A0E98E2BA0
000077a0e99d0634  jmp 0x000077A0E99D059D
000077a0e99d0639  call 0x000077A0E98E2BA0
000077a0e99d063e  jmp 0x000077A0E99D05AB
000077a0e99d0643  call 0x000077A0E98E2BA0
000077a0e99d0648  jmp 0x000077A0E99D05B9
000077a0e99d064d  call 0x000077A0E98E2BA0
000077a0e99d0652  jmp 0x000077A0E99D05C7
000077a0e99d0657  call 0x000077A0E98E2BA0
000077a0e99d065c  jmp 0x000077A0E99D05D5
000077a0e99d0661  call 0x000077A0E98D5EB0
000077a0e99d0666  jmp 0x000077A0E99D05E0
000077a0e99d066b  int3
000077a0e99d066c  nop [rax], eax
000077a0e99d0670  mov rax, [r15+0xF8]
000077a0e99d0677  lea r14, [rax+0x140]
000077a0e99d067e  mov r12, [r13+r14*1]
000077a0e99d0683  lea r14, [rax+0x148]
000077a0e99d068a  mov r11, [r13+r14*1]
000077a0e99d068f  mov [r15+0xA0], r12
000077a0e99d0696  mov [r15+0x98], r11
000077a0e99d069d  lea r14, [rax+0x130]
000077a0e99d06a4  mov r12, [r13+r14*1]
000077a0e99d06a9  lea r14, [rax+0x138]
000077a0e99d06b0  mov r11, [r13+r14*1]
000077a0e99d06b5  mov [r15+0xB0], r12
000077a0e99d06bc  mov [r15+0xA8], r11
000077a0e99d06c3  lea r14, [rax+0x120]
000077a0e99d06ca  mov r12, [r13+r14*1]
000077a0e99d06cf  lea r14, [rax+0x128]
000077a0e99d06d6  mov r11, [r13+r14*1]
000077a0e99d06db  mov [r15+0xC0], r12
000077a0e99d06e2  mov [r15+0xB8], r11
000077a0e99d06e9  lea r14, [rax+0x110]
000077a0e99d06f0  mov r12, [r13+r14*1]
000077a0e99d06f5  lea r14, [rax+0x118]
000077a0e99d06fc  mov r11, [r13+r14*1]
000077a0e99d0701  mov [r15+0xD0], r12
000077a0e99d0708  mov [r15+0xC8], r11
000077a0e99d070f  lea r14, [rax+0x100]
000077a0e99d0716  mov r12, [r13+r14*1]
000077a0e99d071b  lea r14, [rax+0x108]
000077a0e99d0722  mov r11, [r13+r14*1]
000077a0e99d0727  mov [r15+0xE8], r12
000077a0e99d072e  mov [r15+0xD8], r11
000077a0e99d0735  lea r14, [rax+0x150]
000077a0e99d073c  mov [r15+0xF8], r14
000077a0e99d0743  mov rax, [r15+0xF0]
000077a0e99d074a  mov [r15+0x100], rax
000077a0e99d0751  jmp 0x000077A0E99CE5C0
000077a0e99d0756  int3
000077a0e99d0757  call 0x000077A0E98E27E0
000077a0e99d075c  jmp 0x000077A0E99D0683
000077a0e99d0761  call 0x000077A0E98E1570
000077a0e99d0766  jmp 0x000077A0E99D068F
000077a0e99d076b  call 0x000077A0E98E27E0
000077a0e99d0770  jmp 0x000077A0E99D06A9
000077a0e99d0775  call 0x000077A0E98E1570
000077a0e99d077a  jmp 0x000077A0E99D06B5
000077a0e99d077f  call 0x000077A0E98E27E0
000077a0e99d0784  jmp 0x000077A0E99D06CF
000077a0e99d0789  call 0x000077A0E98E1570
000077a0e99d078e  jmp 0x000077A0E99D06DB
000077a0e99d0793  call 0x000077A0E98E27E0
000077a0e99d0798  jmp 0x000077A0E99D06F5
000077a0e99d079d  call 0x000077A0E98E1570
000077a0e99d07a2  jmp 0x000077A0E99D0701
000077a0e99d07a7  call 0x000077A0E98E27E0
000077a0e99d07ac  jmp 0x000077A0E99D071B
000077a0e99d07b1  call 0x000077A0E98E1570
000077a0e99d07b6  jmp 0x000077A0E99D0727
000077a0e99d07bb  int3
000077a0e99d07bc  nop [rax], eax
000077a0e99d07c0  mov eax, [r15+0xA0]
000077a0e99d07c7  mov [rsp+0x10], eax
000077a0e99d07cb  xor eax, eax
000077a0e99d07cd  mov r14d, [rsp+0x10]
000077a0e99d07d2  sub r14d, 0x01
000077a0e99d07d6  cmc
000077a0e99d07d7  lahf
000077a0e99d07d8  seto al
000077a0e99d07db  mov [r15+0x108], eax
000077a0e99d07e2  mov r14d, r14d
000077a0e99d07e5  mov [r15+0xA0], r14
000077a0e99d07ec  mov eax, [r15+0x108]
000077a0e99d07f3  sahf
000077a0e99d07f4  jnz 0x000077A0E99D0826
000077a0e99d07f6  cmp dword ptr [r15+0x318], 0x00
000077a0e99d07fe  jz 0x000077A0E99D0900
000077a0e99d0804  nop [rax+rax*1], ax
000077a0e99d080d  nop [rax+rax*1], eax
000077a0e99d0815  mov eax, 0x41028C
000077a0e99d081a  mov [r15+0x100], rax
000077a0e99d0821  jmp 0x000077A0E97FE110
000077a0e99d0826  cmp dword ptr [r15+0x318], 0x00
000077a0e99d082e  jz 0x000077A0E99D0860
000077a0e99d0834  nop [rax+rax*1], ax
000077a0e99d083d  nop [rax+rax*1], eax
000077a0e99d0845  mov eax, 0x410274
000077a0e99d084a  mov [r15+0x100], rax
000077a0e99d0851  jmp 0x000077A0E97FE110
000077a0e99d0856  int3
000077a0e99d0857  int3
000077a0e99d0858  nop [rax+rax*1], eax
000077a0e99d0860  mov rax, [r15+0xF8]
000077a0e99d0867  lea r14, [rax+0xD0]
000077a0e99d086e  mov [r15], r14
000077a0e99d0871  mov rax, [r15+0x98]
000077a0e99d0878  mov [r15+0x08], rax
000077a0e99d087c  mov qword ptr [r15+0x10], 0x12C
000077a0e99d0884  mov qword ptr [r15+0xF0], 0x410284
000077a0e99d088f  mov r14d, [r15+0x320]
000077a0e99d0896  mov eax, 0x410284
000077a0e99d089b  mov rcx, 0x77A0E99D07C0
000077a0e99d08a5  mov [r15+r14*8+0x328], rax
000077a0e99d08ad  mov [r15+r14*8+0x368], rcx
000077a0e99d08b5  add r14d, 0x01
000077a0e99d08b9  and r14d, 0x07
000077a0e99d08bd  mov [r15+0x320], r14d
000077a0e99d08c4  cmp dword ptr [r15+0x318], 0x00
000077a0e99d08cc  jz 0x000077A0E99CED70
000077a0e99d08d2  nop [rax+rax*1], ax
000077a0e99d08db  nop [rax+rax*1], eax
000077a0e99d08e3  mov eax, 0x4106BC
000077a0e99d08e8  mov [r15+0x100], rax
000077a0e99d08ef  jmp 0x000077A0E97FE110
000077a0e99d08f4  int3
000077a0e99d08f5  int3
000077a0e99d08f6  nop [rax+rax*1], ax
000077a0e99d08ff  nop
000077a0e99d0900  mov rax, [r15+0xF8]
000077a0e99d0907  lea r14, [rax+0xF0]
000077a0e99d090e  mov r12, [r13+r14*1]
000077a0e99d0913  mov [r15+0x98], r12
000077a0e99d091a  mov qword ptr [r15+0x40], 0x80
000077a0e99d0922  lea r14, [rax+0xD0]
000077a0e99d0929  mov [r15], r14
000077a0e99d092c  lea r14, [rax+0x14C]
000077a0e99d0933  mov [r15+0x08], r14
000077a0e99d0937  mov qword ptr [r15+0x10], 0x01
000077a0e99d093f  lea r14, [rax+0x14C]
000077a0e99d0946  mov eax, 0x80
000077a0e99d094b  mov [r13+r14*1], al
000077a0e99d0950  mov qword ptr [r15+0xF0], 0x4102A8
000077a0e99d095b  mov r14d, [r15+0x320]
000077a0e99d0962  mov eax, 0x4102A8
000077a0e99d0967  mov rcx, 0x77A0E99D09E0
000077a0e99d0971  mov [r15+r14*8+0x328], rax
000077a0e99d0979  mov [r15+r14*8+0x368], rcx
000077a0e99d0981  add r14d, 0x01
000077a0e99d0985  and r14d, 0x07
000077a0e99d0989  mov [r15+0x320], r14d
000077a0e99d0990  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0998  jz 0x000077A0E99CED70
000077a0e99d099e  nop [rax+rax*1], ax
000077a0e99d09a7  nop [rax+rax*1], eax
000077a0e99d09af  mov eax, 0x4106BC
000077a0e99d09b4  mov [r15+0x100], rax
000077a0e99d09bb  jmp 0x000077A0E97FE110
000077a0e99d09c0  int3
000077a0e99d09c1  call 0x000077A0E98E27E0
000077a0e99d09c6  jmp 0x000077A0E99D0913
000077a0e99d09cb  call 0x000077A0E98D5AF0
000077a0e99d09d0  jmp 0x000077A0E99D0950
000077a0e99d09d5  int3
000077a0e99d09d6  nop [rax+rax*1], ax
000077a0e99d09df  nop
000077a0e99d09e0  mov rax, [r15+0xF8]
000077a0e99d09e7  lea r14, [rax+0x138]
000077a0e99d09ee  mov r12, [r13+r14*1]
000077a0e99d09f3  mov [r15+0x40], r12
000077a0e99d09f7  lea r14, [rax+0x148]
000077a0e99d09fe  xor eax, eax
000077a0e99d0a00  mov [r13+r14*1], al
000077a0e99d0a05  xor eax, eax
000077a0e99d0a07  mov r14d, 0x38
000077a0e99d0a0d  cmp r12, r14
000077a0e99d0a10  cmc
000077a0e99d0a11  lahf
000077a0e99d0a12  seto al
000077a0e99d0a15  mov [r15+0x108], eax
000077a0e99d0a1c  mov eax, [r15+0x108]
000077a0e99d0a23  sahf
000077a0e99d0a24  jz 0x000077A0E99D0A56
000077a0e99d0a26  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0a2e  jz 0x000077A0E99D0AA0
000077a0e99d0a34  nop [rax+rax*1], ax
000077a0e99d0a3d  nop [rax+rax*1], eax
000077a0e99d0a45  mov eax, 0x4102B8
000077a0e99d0a4a  mov [r15+0x100], rax
000077a0e99d0a51  jmp 0x000077A0E97FE110
000077a0e99d0a56  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0a5e  jz 0x000077A0E99D0BF0
000077a0e99d0a64  nop [rax+rax*1], ax
000077a0e99d0a6d  nop [rax+rax*1], eax
000077a0e99d0a75  mov eax, 0x4102D4
000077a0e99d0a7a  mov [r15+0x100], rax
000077a0e99d0a81  jmp 0x000077A0E97FE110
000077a0e99d0a86  int3
000077a0e99d0a87  call 0x000077A0E98E27E0
000077a0e99d0a8c  jmp 0x000077A0E99D09F3
000077a0e99d0a91  call 0x000077A0E98D5AF0
000077a0e99d0a96  jmp 0x000077A0E99D0A05
000077a0e99d0a9b  int3
000077a0e99d0a9c  nop [rax], eax
000077a0e99d0aa0  mov rax, [r15+0xF8]
000077a0e99d0aa7  lea r14, [rax+0xD0]
000077a0e99d0aae  mov [r15], r14
000077a0e99d0ab1  lea r14, [rax+0x148]
000077a0e99d0ab8  mov [r15+0x08], r14
000077a0e99d0abc  mov qword ptr [r15+0x10], 0x01
000077a0e99d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000077a0e99d0acf  mov r14d, [r15+0x320]
000077a0e99d0ad6  mov eax, 0x4102C8
000077a0e99d0adb  mov rcx, 0x77A0E99D0B40
000077a0e99d0ae5  mov [r15+r14*8+0x328], rax
000077a0e99d0aed  mov [r15+r14*8+0x368], rcx
000077a0e99d0af5  add r14d, 0x01
000077a0e99d0af9  and r14d, 0x07
000077a0e99d0afd  mov [r15+0x320], r14d
000077a0e99d0b04  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0b0c  jz 0x000077A0E99CED70
000077a0e99d0b12  nop [rax+rax*1], ax
000077a0e99d0b1b  nop [rax+rax*1], eax
000077a0e99d0b23  mov eax, 0x4106BC
000077a0e99d0b28  mov [r15+0x100], rax
000077a0e99d0b2f  jmp 0x000077A0E97FE110
000077a0e99d0b34  int3
000077a0e99d0b35  int3
000077a0e99d0b36  nop [rax+rax*1], ax
000077a0e99d0b3f  nop
000077a0e99d0b40  mov rax, [r15+0xF8]
000077a0e99d0b47  lea r14, [rax+0x138]
000077a0e99d0b4e  mov rax, [r13+r14*1]
000077a0e99d0b53  mov [r15+0x40], rax
000077a0e99d0b57  mov [rsp+0x10], rax
000077a0e99d0b5c  xor eax, eax
000077a0e99d0b5e  mov r14, [rsp+0x10]
000077a0e99d0b63  mov r12d, 0x38
000077a0e99d0b69  cmp r14, r12
000077a0e99d0b6c  cmc
000077a0e99d0b6d  lahf
000077a0e99d0b6e  seto al
000077a0e99d0b71  mov [r15+0x108], eax
000077a0e99d0b78  mov eax, [r15+0x108]
000077a0e99d0b7f  sahf
000077a0e99d0b80  jnz 0x000077A0E99D0BB2
000077a0e99d0b82  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0b8a  jz 0x000077A0E99D0BF0
000077a0e99d0b90  nop [rax+rax*1], ax
000077a0e99d0b99  nop [rax+rax*1], eax
000077a0e99d0ba1  mov eax, 0x4102D4
000077a0e99d0ba6  mov [r15+0x100], rax
000077a0e99d0bad  jmp 0x000077A0E97FE110
000077a0e99d0bb2  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0bba  jz 0x000077A0E99D0AA0
000077a0e99d0bc0  nop [rax+rax*1], ax
000077a0e99d0bc9  nop [rax+rax*1], eax
000077a0e99d0bd1  mov eax, 0x4102B8
000077a0e99d0bd6  mov [r15+0x100], rax
000077a0e99d0bdd  jmp 0x000077A0E97FE110
000077a0e99d0be2  int3
000077a0e99d0be3  call 0x000077A0E98D59C0
000077a0e99d0be8  jmp 0x000077A0E99D0B53
000077a0e99d0bed  int3
000077a0e99d0bee  nop
000077a0e99d0bf0  mov rax, [r15+0x98]
000077a0e99d0bf7  rorx r14, rax, 0x3D
000077a0e99d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000077a0e99d0c01  mov rax, [r15+0xF8]
000077a0e99d0c08  lea r12, [rax+0xD0]
000077a0e99d0c0f  mov [r15], r12
000077a0e99d0c12  lea r12, [rax+0x140]
000077a0e99d0c19  mov [r15+0x08], r12
000077a0e99d0c1d  mov qword ptr [r15+0x10], 0x08
000077a0e99d0c25  bswap r14
000077a0e99d0c28  mov [r15+0x40], r14
000077a0e99d0c2c  lea r12, [rax+0x140]
000077a0e99d0c33  mov [r13+r12*1], r14
000077a0e99d0c38  mov qword ptr [r15+0xF0], 0x4102F0
000077a0e99d0c43  mov r14d, [r15+0x320]
000077a0e99d0c4a  mov eax, 0x4102F0
000077a0e99d0c4f  mov rcx, 0x77A0E99D0CC0
000077a0e99d0c59  mov [r15+r14*8+0x328], rax
000077a0e99d0c61  mov [r15+r14*8+0x368], rcx
000077a0e99d0c69  add r14d, 0x01
000077a0e99d0c6d  and r14d, 0x07
000077a0e99d0c71  mov [r15+0x320], r14d
000077a0e99d0c78  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0c80  jz 0x000077A0E99CED70
000077a0e99d0c86  nop [rax+rax*1], ax
000077a0e99d0c8f  nop [rax+rax*1], eax
000077a0e99d0c97  mov eax, 0x4106BC
000077a0e99d0c9c  mov [r15+0x100], rax
000077a0e99d0ca3  jmp 0x000077A0E97FE110
000077a0e99d0ca8  int3
000077a0e99d0ca9  call 0x000077A0E98C3FE0
000077a0e99d0cae  jmp 0x000077A0E99D0C38
000077a0e99d0cb3  int3
000077a0e99d0cb4  nop [rax+rax*1], ax
000077a0e99d0cbd  nop [rax], eax
000077a0e99d0cc0  mov rax, [r15+0xF8]
000077a0e99d0cc7  lea r14, [rax+0xD0]
000077a0e99d0cce  mov r12d, [r13+r14*1]
000077a0e99d0cd3  lea r14, [rax+0xD4]
000077a0e99d0cda  mov r11d, [r13+r14*1]
000077a0e99d0cdf  lea r14, [rax+0xD8]
000077a0e99d0ce6  mov r10d, [r13+r14*1]
000077a0e99d0ceb  lea r14, [rax+0xDC]
000077a0e99d0cf2  mov r9d, [r13+r14*1]
000077a0e99d0cf7  mov qword ptr [r15+0x48], 0x430C20
000077a0e99d0cff  mov qword ptr [r15+0xA0], 0x00
000077a0e99d0d0a  bswap r12d
000077a0e99d0d0d  bswap r11d
000077a0e99d0d10  mov qword ptr [r15+0x98], 0x430D8C
000077a0e99d0d1b  mov r14d, 0x430C20
000077a0e99d0d21  mov [r13+r14*1], r12d
000077a0e99d0d26  mov r14d, 0x430C24
000077a0e99d0d2c  mov [r13+r14*1], r11d
000077a0e99d0d31  bswap r10d
000077a0e99d0d34  bswap r9d
000077a0e99d0d37  lea r14, [rax+0xE0]
000077a0e99d0d3e  mov r12d, [r13+r14*1]
000077a0e99d0d43  lea r14, [rax+0xE4]
000077a0e99d0d4a  mov r11d, [r13+r14*1]
000077a0e99d0d4f  mov r14d, 0x430C28
000077a0e99d0d55  mov [r13+r14*1], r10d
000077a0e99d0d5a  mov r14d, 0x430C2C
000077a0e99d0d60  mov [r13+r14*1], r9d
000077a0e99d0d65  bswap r12d
000077a0e99d0d68  bswap r11d
000077a0e99d0d6b  mov [rsp+0x10], r11d
000077a0e99d0d70  mov r11d, r11d
000077a0e99d0d73  mov [r15+0x58], r11
000077a0e99d0d77  lea r14, [rax+0xE8]
000077a0e99d0d7e  mov r11d, [r13+r14*1]
000077a0e99d0d83  lea r14, [rax+0xEC]
000077a0e99d0d8a  mov eax, [r13+r14*1]
000077a0e99d0d8f  mov [rsp+0x20], eax
000077a0e99d0d93  mov eax, eax
000077a0e99d0d95  mov [r15+0x60], rax
000077a0e99d0d99  mov eax, 0x430C30
000077a0e99d0d9e  mov [r13+rax*1], r12d
000077a0e99d0da3  mov eax, 0x430C34
000077a0e99d0da8  mov r14d, [rsp+0x10]
000077a0e99d0dad  mov [r13+rax*1], r14d
000077a0e99d0db2  bswap r11d
000077a0e99d0db5  mov [rsp+0x10], r11d
000077a0e99d0dba  mov r11d, r11d
000077a0e99d0dbd  mov [r15+0x40], r11
000077a0e99d0dc1  mov eax, [rsp+0x20]
000077a0e99d0dc5  bswap eax
000077a0e99d0dc7  mov [rsp+0x20], eax
000077a0e99d0dcb  mov eax, eax
000077a0e99d0dcd  mov [r15+0x50], rax
000077a0e99d0dd1  mov eax, 0x430C38
000077a0e99d0dd6  mov r14d, [rsp+0x10]
000077a0e99d0ddb  mov [r13+rax*1], r14d
000077a0e99d0de0  mov eax, 0x430C3C
000077a0e99d0de5  mov r14d, [rsp+0x20]
000077a0e99d0dea  mov [r13+rax*1], r14d
000077a0e99d0def  mov eax, [r15+0xA0]
000077a0e99d0df6  lea r14d, [eax+0x11]
000077a0e99d0dfb  mov r14d, r14d
000077a0e99d0dfe  mov [r15], r14
000077a0e99d0e01  mov qword ptr [r15+0xF0], 0x41034C
000077a0e99d0e0c  mov r14d, [r15+0x320]
000077a0e99d0e13  mov eax, 0x41034C
000077a0e99d0e18  mov rcx, 0x77A0E99D0F90
000077a0e99d0e22  mov [r15+r14*8+0x328], rax
000077a0e99d0e2a  mov [r15+r14*8+0x368], rcx
000077a0e99d0e32  add r14d, 0x01
000077a0e99d0e36  and r14d, 0x07
000077a0e99d0e3a  mov [r15+0x320], r14d
000077a0e99d0e41  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0e49  jz 0x000077A0E99D0F20
000077a0e99d0e4f  nop [rax+rax*1], ax
000077a0e99d0e58  nop [rax+rax*1], eax
000077a0e99d0e60  mov eax, 0x410938
000077a0e99d0e65  mov [r15+0x100], rax
000077a0e99d0e6c  jmp 0x000077A0E97FE110
000077a0e99d0e71  int3
000077a0e99d0e72  call 0x000077A0E98E26A0
000077a0e99d0e77  jmp 0x000077A0E99D0CD3
000077a0e99d0e7c  call 0x000077A0E98E1430
000077a0e99d0e81  jmp 0x000077A0E99D0CDF
000077a0e99d0e86  call 0x000077A0E98E01C0
000077a0e99d0e8b  jmp 0x000077A0E99D0CEB
000077a0e99d0e90  call 0x000077A0E98DEF50
000077a0e99d0e95  jmp 0x000077A0E99D0CF7
000077a0e99d0e9a  call 0x000077A0E98E2BA0
000077a0e99d0e9f  jmp 0x000077A0E99D0D26
000077a0e99d0ea4  call 0x000077A0E98E1920
000077a0e99d0ea9  jmp 0x000077A0E99D0D31
000077a0e99d0eae  call 0x000077A0E98E26A0
000077a0e99d0eb3  jmp 0x000077A0E99D0D43
000077a0e99d0eb8  call 0x000077A0E98E1430
000077a0e99d0ebd  jmp 0x000077A0E99D0D4F
000077a0e99d0ec2  call 0x000077A0E98E06B0
000077a0e99d0ec7  jmp 0x000077A0E99D0D5A
000077a0e99d0ecc  call 0x000077A0E98DF440
000077a0e99d0ed1  jmp 0x000077A0E99D0D65
000077a0e99d0ed6  call 0x000077A0E98E1430
000077a0e99d0edb  jmp 0x000077A0E99D0D83
000077a0e99d0ee0  call 0x000077A0E98D5890
000077a0e99d0ee5  jmp 0x000077A0E99D0D8F
000077a0e99d0eea  call 0x000077A0E980BAE0
000077a0e99d0eef  jmp 0x000077A0E99D0DA3
000077a0e99d0ef4  call 0x000077A0E980DFE0
000077a0e99d0ef9  jmp 0x000077A0E99D0DB2
000077a0e99d0efe  call 0x000077A0E980DFE0
000077a0e99d0f03  jmp 0x000077A0E99D0DE0
000077a0e99d0f08  call 0x000077A0E980DFE0
000077a0e99d0f0d  jmp 0x000077A0E99D0DEF
000077a0e99d0f12  int3
000077a0e99d0f13  nop [rax+rax*1], ax
000077a0e99d0f1c  nop [rax], eax
000077a0e99d0f20  mov eax, [r15]
000077a0e99d0f23  mov [rsp+0x10], eax
000077a0e99d0f27  shr eax, 0x10
000077a0e99d0f2a  mov r14d, [rsp+0x10]
000077a0e99d0f2f  xor r14d, eax
000077a0e99d0f32  imul r14d, r14d, 0x7FEB352D
000077a0e99d0f39  mov eax, 0x846CA68B
000077a0e99d0f3e  mov eax, eax
000077a0e99d0f40  mov [r15+0x48], rax
000077a0e99d0f44  mov [rsp+0x10], r14d
000077a0e99d0f49  shr r14d, 0x0F
000077a0e99d0f4d  mov eax, [rsp+0x10]
000077a0e99d0f51  xor eax, r14d
000077a0e99d0f54  imul eax, eax, 0x846CA68B
000077a0e99d0f5a  mov [rsp+0x10], eax
000077a0e99d0f5e  mov eax, eax
000077a0e99d0f60  mov [r15+0x40], rax
000077a0e99d0f64  mov eax, [rsp+0x10]
000077a0e99d0f68  shr eax, 0x10
000077a0e99d0f6b  mov r14d, [rsp+0x10]
000077a0e99d0f70  xor r14d, eax
000077a0e99d0f73  mov r14d, r14d
000077a0e99d0f76  mov [r15], r14
000077a0e99d0f79  mov rax, [r15+0xF0]
000077a0e99d0f80  mov [r15+0x100], rax
000077a0e99d0f87  jmp 0x000077A0E99CE5C0
000077a0e99d0f8c  int3
000077a0e99d0f8d  int3
000077a0e99d0f8e  nop
000077a0e99d0f90  mov rax, [r15+0xA0]
000077a0e99d0f97  mov [rsp+0x10], rax
000077a0e99d0f9c  shl rax, 0x02
000077a0e99d0fa0  mov r14, [r15+0x98]
000077a0e99d0fa7  lea r12, [r14+rax*1]
000077a0e99d0fab  mov eax, [r15]
000077a0e99d0fae  mov [r13+r12*1], eax
000077a0e99d0fb3  mov rax, [rsp+0x10]
000077a0e99d0fb8  lea r14, [rax+0x01]
000077a0e99d0fbc  mov [r15+0xA0], r14
000077a0e99d0fc3  xor eax, eax
000077a0e99d0fc5  mov r12d, 0x400
000077a0e99d0fcb  cmp r14, r12
000077a0e99d0fce  cmc
000077a0e99d0fcf  lahf
000077a0e99d0fd0  seto al
000077a0e99d0fd3  mov [r15+0x108], eax
000077a0e99d0fda  mov eax, [r15+0x108]
000077a0e99d0fe1  sahf
000077a0e99d0fe2  jnz 0x000077A0E99D1014
000077a0e99d0fe4  cmp dword ptr [r15+0x318], 0x00
000077a0e99d0fec  jz 0x000077A0E99D10E0
000077a0e99d0ff2  nop [rax+rax*1], ax
000077a0e99d0ffb  nop [rax+rax*1], eax
000077a0e99d1003  mov eax, 0x41035C
000077a0e99d1008  mov [r15+0x100], rax
000077a0e99d100f  jmp 0x000077A0E97FE110
000077a0e99d1014  cmp dword ptr [r15+0x318], 0x00
000077a0e99d101c  jz 0x000077A0E99D1050
000077a0e99d1022  nop [rax+rax*1], ax
000077a0e99d102b  nop [rax+rax*1], eax
000077a0e99d1033  mov eax, 0x410344
000077a0e99d1038  mov [r15+0x100], rax
000077a0e99d103f  jmp 0x000077A0E97FE110
000077a0e99d1044  int3
000077a0e99d1045  call 0x000077A0E98B4B70
000077a0e99d104a  jmp 0x000077A0E99D0FB3
000077a0e99d104f  int3
000077a0e99d1050  mov eax, [r15+0xA0]
000077a0e99d1057  lea r14d, [eax+0x11]
000077a0e99d105c  mov r14d, r14d
000077a0e99d105f  mov [r15], r14
000077a0e99d1062  mov qword ptr [r15+0xF0], 0x41034C
000077a0e99d106d  mov r14d, [r15+0x320]
000077a0e99d1074  mov eax, 0x41034C
000077a0e99d1079  mov rcx, 0x77A0E99D0F90
000077a0e99d1083  mov [r15+r14*8+0x328], rax
000077a0e99d108b  mov [r15+r14*8+0x368], rcx
000077a0e99d1093  add r14d, 0x01
000077a0e99d1097  and r14d, 0x07
000077a0e99d109b  mov [r15+0x320], r14d
000077a0e99d10a2  cmp dword ptr [r15+0x318], 0x00
000077a0e99d10aa  jz 0x000077A0E99D0F20
000077a0e99d10b0  nop [rax+rax*1], ax
000077a0e99d10b9  nop [rax+rax*1], eax
000077a0e99d10c1  mov eax, 0x410938
000077a0e99d10c6  mov [r15+0x100], rax
000077a0e99d10cd  jmp 0x000077A0E97FE110
000077a0e99d10d2  int3
000077a0e99d10d3  int3
000077a0e99d10d4  nop [rax+rax*1], ax
000077a0e99d10dd  nop [rax], eax
000077a0e99d10e0  mov qword ptr [r15+0x40], 0x01
000077a0e99d10e8  cmp dword ptr [r15+0x318], 0x00
000077a0e99d10f0  jz 0x000077A0E99D1120
000077a0e99d10f6  nop [rax+rax*1], ax
000077a0e99d10ff  nop [rax+rax*1], eax
000077a0e99d1107  mov eax, 0x410378
000077a0e99d110c  mov [r15+0x100], rax
000077a0e99d1113  jmp 0x000077A0E97FE110
000077a0e99d1118  int3
000077a0e99d1119  int3
000077a0e99d111a  nop [rax+rax*1], ax
000077a0e99d1120  mov rax, [r15+0x40]
000077a0e99d1124  mov [rsp+0x10], rax
000077a0e99d1129  shl rax, 0x02
000077a0e99d112d  mov r14, [r15+0x98]
000077a0e99d1134  lea r12, [r14+rax*1]
000077a0e99d1138  mov eax, [r13+r12*1]
000077a0e99d113d  mov [rsp+0x20], eax
000077a0e99d1141  mov eax, eax
000077a0e99d1143  mov [r15+0x48], rax
000077a0e99d1147  mov rax, [rsp+0x10]
000077a0e99d114c  mov [r15+0x50], rax
000077a0e99d1150  mov eax, [r15+0x50]
000077a0e99d1154  lea r12d, [eax-0x01]
000077a0e99d1159  mov r12d, r12d
000077a0e99d115c  mov [r15+0x58], r12
000077a0e99d1160  mov rax, [r15+0x58]
000077a0e99d1164  mov r12d, eax
000077a0e99d1167  mov r12d, r12d
000077a0e99d116a  shl r12, 0x02
000077a0e99d116e  lea rax, [r14+r12*1]
000077a0e99d1172  mov r14d, [r13+rax*1]
000077a0e99d1177  mov [rsp+0x10], r14d
000077a0e99d117c  mov r14d, r14d
000077a0e99d117f  mov [r15+0x60], r14
000077a0e99d1183  xor eax, eax
000077a0e99d1185  mov r14d, [rsp+0x10]
000077a0e99d118a  mov r12d, [rsp+0x20]
000077a0e99d118f  cmp r14d, r12d
000077a0e99d1192  cmc
000077a0e99d1193  lahf
000077a0e99d1194  seto al
000077a0e99d1197  mov [r15+0x108], eax
000077a0e99d119e  mov eax, [r15+0x108]
000077a0e99d11a5  sahf
000077a0e99d11a6  cmc
000077a0e99d11a7  jbe 0x000077A0E99D11D9
000077a0e99d11a9  cmp dword ptr [r15+0x318], 0x00
000077a0e99d11b1  jz 0x000077A0E99D1220
000077a0e99d11b7  nop [rax+rax*1], ax
000077a0e99d11c0  nop [rax+rax*1], eax
000077a0e99d11c8  mov eax, 0x410390
000077a0e99d11cd  mov [r15+0x100], rax
000077a0e99d11d4  jmp 0x000077A0E97FE110
000077a0e99d11d9  cmp dword ptr [r15+0x318], 0x00
000077a0e99d11e1  jz 0x000077A0E99D14C0
000077a0e99d11e7  nop [rax+rax*1], ax
000077a0e99d11f0  nop [rax+rax*1], eax
000077a0e99d11f8  mov eax, 0x410368
000077a0e99d11fd  mov [r15+0x100], rax
000077a0e99d1204  jmp 0x000077A0E97FE110
000077a0e99d1209  int3
000077a0e99d120a  call 0x000077A0E98B4690
000077a0e99d120f  jmp 0x000077A0E99D113D
000077a0e99d1214  call 0x000077A0E980DAE0
000077a0e99d1219  jmp 0x000077A0E99D1177
000077a0e99d121e  int3
000077a0e99d121f  nop
000077a0e99d1220  mov rax, [r15+0x50]
000077a0e99d1224  mov [rsp+0x10], rax
000077a0e99d1229  shl rax, 0x02
000077a0e99d122d  mov r14, [r15+0x98]
000077a0e99d1234  lea r12, [r14+rax*1]
000077a0e99d1238  mov eax, [r15+0x60]
000077a0e99d123c  mov [r13+r12*1], eax
000077a0e99d1241  mov rax, [rsp+0x10]
000077a0e99d1246  lea r14, [rax-0x01]
000077a0e99d124a  mov [r15+0x50], r14
000077a0e99d124e  mov rax, [r15+0x58]
000077a0e99d1252  test rax, rax
000077a0e99d1255  setz al
000077a0e99d1258  movzx rax, al
000077a0e99d125c  mov [rsp+0x414], al
000077a0e99d1263  cmp byte ptr [rsp+0x414], 0x00
000077a0e99d126b  jz 0x000077A0E99D129D
000077a0e99d126d  cmp dword ptr [r15+0x318], 0x00
000077a0e99d1275  jz 0x000077A0E99D12E0
000077a0e99d127b  nop [rax+rax*1], ax
000077a0e99d1284  nop [rax+rax*1], eax
000077a0e99d128c  mov eax, 0x41039C
000077a0e99d1291  mov [r15+0x100], rax
000077a0e99d1298  jmp 0x000077A0E97FE110
000077a0e99d129d  cmp dword ptr [r15+0x318], 0x00
000077a0e99d12a5  jz 0x000077A0E99D13E0
000077a0e99d12ab  nop [rax+rax*1], ax
000077a0e99d12b4  nop [rax+rax*1], eax
000077a0e99d12bc  mov eax, 0x410380
000077a0e99d12c1  mov [r15+0x100], rax
000077a0e99d12c8  jmp 0x000077A0E97FE110
000077a0e99d12cd  int3
000077a0e99d12ce  call 0x000077A0E98B4B70
000077a0e99d12d3  jmp 0x000077A0E99D1241
000077a0e99d12d8  int3
000077a0e99d12d9  nop [rax], eax
000077a0e99d12e0  cmp dword ptr [r15+0x318], 0x00
000077a0e99d12e8  jz 0x000077A0E99D1320
000077a0e99d12ee  nop [rax+rax*1], ax
000077a0e99d12f7  nop [rax+rax*1], eax
000077a0e99d12ff  mov eax, 0x410364
000077a0e99d1304  mov [r15+0x100], rax
000077a0e99d130b  jmp 0x000077A0E97FE110
000077a0e99d1310  int3
000077a0e99d1311  int3
000077a0e99d1312  nop [rax+rax*1], ax
000077a0e99d131b  nop [rax+rax*1], eax
000077a0e99d1320  mov qword ptr [r15+0x50], 0x00
000077a0e99d1328  mov rax, [r15+0x40]
000077a0e99d132c  lea r14, [rax+0x01]
000077a0e99d1330  mov [r15+0x40], r14
000077a0e99d1334  mov rax, [r15+0x98]
000077a0e99d133b  mov r12d, [r15+0x48]
000077a0e99d133f  mov [r13+rax*1], r12d
000077a0e99d1344  xor eax, eax
000077a0e99d1346  mov r12d, 0x400
000077a0e99d134c  cmp r14, r12
000077a0e99d134f  cmc
000077a0e99d1350  lahf
000077a0e99d1351  seto al
000077a0e99d1354  mov [r15+0x108], eax
000077a0e99d135b  mov eax, [r15+0x108]
000077a0e99d1362  sahf
000077a0e99d1363  jz 0x000077A0E99D1395
000077a0e99d1365  cmp dword ptr [r15+0x318], 0x00
000077a0e99d136d  jz 0x000077A0E99D1120
000077a0e99d1373  nop [rax+rax*1], ax
000077a0e99d137c  nop [rax+rax*1], eax
000077a0e99d1384  mov eax, 0x410378
000077a0e99d1389  mov [r15+0x100], rax
000077a0e99d1390  jmp 0x000077A0E97FE110
000077a0e99d1395  cmp dword ptr [r15+0x318], 0x00
000077a0e99d139d  jz 0x000077A0E99D1580
000077a0e99d13a3  nop [rax+rax*1], ax
000077a0e99d13ac  nop [rax+rax*1], eax
000077a0e99d13b4  mov eax, 0x4103A0
000077a0e99d13b9  mov [r15+0x100], rax
000077a0e99d13c0  jmp 0x000077A0E97FE110
000077a0e99d13c5  int3
000077a0e99d13c6  call 0x000077A0E980BAE0
000077a0e99d13cb  jmp 0x000077A0E99D1344
000077a0e99d13d0  int3
000077a0e99d13d1  nop [rax+rax*1], ax
000077a0e99d13da  nop [rax+rax*1], ax
000077a0e99d13e0  mov eax, [r15+0x50]
000077a0e99d13e4  lea r14d, [eax-0x01]
000077a0e99d13e9  mov r14d, r14d
000077a0e99d13ec  mov [r15+0x58], r14
000077a0e99d13f0  mov rax, [r15+0x58]
000077a0e99d13f4  mov r14d, eax
000077a0e99d13f7  mov r14d, r14d
000077a0e99d13fa  shl r14, 0x02
000077a0e99d13fe  mov rax, [r15+0x98]
000077a0e99d1405  lea r12, [rax+r14*1]
000077a0e99d1409  mov eax, [r13+r12*1]
000077a0e99d140e  mov [rsp+0x10], eax
000077a0e99d1412  mov eax, eax
000077a0e99d1414  mov [r15+0x60], rax
000077a0e99d1418  mov eax, [r15+0x48]
000077a0e99d141c  mov [rsp+0x20], eax
000077a0e99d1420  xor eax, eax
000077a0e99d1422  mov r14d, [rsp+0x10]
000077a0e99d1427  mov r12d, [rsp+0x20]
000077a0e99d142c  cmp r14d, r12d
000077a0e99d142f  cmc
000077a0e99d1430  lahf
000077a0e99d1431  seto al
000077a0e99d1434  mov [r15+0x108], eax
000077a0e99d143b  mov eax, [r15+0x108]
000077a0e99d1442  sahf
000077a0e99d1443  cmc
000077a0e99d1444  jbe 0x000077A0E99D1476
000077a0e99d1446  cmp dword ptr [r15+0x318], 0x00
000077a0e99d144e  jz 0x000077A0E99D1220
000077a0e99d1454  nop [rax+rax*1], ax
000077a0e99d145d  nop [rax+rax*1], eax
000077a0e99d1465  mov eax, 0x410390
000077a0e99d146a  mov [r15+0x100], rax
000077a0e99d1471  jmp 0x000077A0E97FE110
000077a0e99d1476  cmp dword ptr [r15+0x318], 0x00
000077a0e99d147e  jz 0x000077A0E99D14C0
000077a0e99d1484  nop [rax+rax*1], ax
000077a0e99d148d  nop [rax+rax*1], eax
000077a0e99d1495  mov eax, 0x410368
000077a0e99d149a  mov [r15+0x100], rax
000077a0e99d14a1  jmp 0x000077A0E97FE110
000077a0e99d14a6  int3
000077a0e99d14a7  call 0x000077A0E98B4690
000077a0e99d14ac  jmp 0x000077A0E99D140E
000077a0e99d14b1  int3
000077a0e99d14b2  nop [rax+rax*1], ax
000077a0e99d14bb  nop [rax+rax*1], eax
000077a0e99d14c0  mov rax, [r15+0x40]
000077a0e99d14c4  lea r14, [rax+0x01]
000077a0e99d14c8  mov [r15+0x40], r14
000077a0e99d14cc  mov rax, [r15+0x50]
000077a0e99d14d0  mov r12d, eax
000077a0e99d14d3  mov r12d, r12d
000077a0e99d14d6  shl r12, 0x02
000077a0e99d14da  mov rax, [r15+0x98]
000077a0e99d14e1  lea r11, [rax+r12*1]
000077a0e99d14e5  mov eax, [r15+0x48]
000077a0e99d14e9  mov [r13+r11*1], eax
000077a0e99d14ee  xor eax, eax
000077a0e99d14f0  mov r12d, 0x400
000077a0e99d14f6  cmp r14, r12
000077a0e99d14f9  cmc
000077a0e99d14fa  lahf
000077a0e99d14fb  seto al
000077a0e99d14fe  mov [r15+0x108], eax
000077a0e99d1505  mov eax, [r15+0x108]
000077a0e99d150c  sahf
000077a0e99d150d  jz 0x000077A0E99D153F
000077a0e99d150f  cmp dword ptr [r15+0x318], 0x00
000077a0e99d1517  jz 0x000077A0E99D1120
000077a0e99d151d  nop [rax+rax*1], ax
000077a0e99d1526  nop [rax+rax*1], eax
000077a0e99d152e  mov eax, 0x410378
000077a0e99d1533  mov [r15+0x100], rax
000077a0e99d153a  jmp 0x000077A0E97FE110
000077a0e99d153f  cmp dword ptr [r15+0x318], 0x00
000077a0e99d1547  jz 0x000077A0E99D1580
000077a0e99d154d  nop [rax+rax*1], ax
000077a0e99d1556  nop [rax+rax*1], eax
000077a0e99d155e  mov eax, 0x4103A0
000077a0e99d1563  mov [r15+0x100], rax
000077a0e99d156a  jmp 0x000077A0E97FE110
000077a0e99d156f  int3
000077a0e99d1570  call 0x000077A0E98A4270
000077a0e99d1575  jmp 0x000077A0E99D14EE
000077a0e99d157a  int3
000077a0e99d157b  nop [rax+rax*1], eax
000077a0e99d1580  mov qword ptr [r15+0x40], 0x430000
000077a0e99d1588  mov eax, 0x430C40
000077a0e99d158d  mov r14, [r13+rax*1]
000077a0e99d1592  mov rax, [r15+0x98]
000077a0e99d1599  mov r12d, [r13+rax*1]
000077a0e99d159e  lea r11, [rax+0x04]
000077a0e99d15a2  mov eax, [r13+r11*1]
000077a0e99d15a7  mov r12d, r12d
000077a0e99d15aa  mov [r15+0x68], r12
000077a0e99d15ae  mov eax, eax
000077a0e99d15b0  mov [r15+0x60], rax
000077a0e99d15b4  mov rax, [r15+0x68]
000077a0e99d15b8  mov [r15+0x68], rax
000077a0e99d15bc  mov qword ptr [r15+0x58], 0x02
000077a0e99d15c4  mov [rsp+0x10], rax
000077a0e99d15c9  xor eax, eax
000077a0e99d15cb  mov r12d, 0x02
000077a0e99d15d1  mov r11d, 0x400
000077a0e99d15d7  cmp r12, r11
000077a0e99d15da  cmc
000077a0e99d15db  lahf
000077a0e99d15dc  seto al
000077a0e99d15df  mov [r15+0x108], eax
000077a0e99d15e6  mov rax, [r15+0x60]
000077a0e99d15ea  mov r12d, 0x02
000077a0e99d15f0  imul rax, r12
000077a0e99d15f4  mov [r15+0x50], rax
000077a0e99d15f8  mov rax, [rsp+0x10]
000077a0e99d15fd  lea r12, [rax+r14*1]
000077a0e99d1601  mov [r15+0x48], r12
000077a0e99d1605  mov eax, [r15+0x108]
000077a0e99d160c  sahf
000077a0e99d160d  jnz 0x000077A0E99D163F
000077a0e99d160f  cmp dword ptr [r15+0x318], 0x00
000077a0e99d1617  jz 0x000077A0E99D17B0
000077a0e99d161d  nop [rax+rax*1], ax
000077a0e99d1626  nop [rax+rax*1], eax
000077a0e99d162e  mov eax, 0x4103D0
000077a0e99d1633  mov [r15+0x100], rax
000077a0e99d163a  jmp 0x000077A0E97FE110
000077a0e99d163f  cmp dword ptr [r15+0x318], 0x00
000077a0e99d1647  jz 0x000077A0E99D1690
000077a0e99d164d  nop [rax+rax*1], ax
000077a0e99d1656  nop [rax+rax*1], eax
000077a0e99d165e  mov eax, 0x4103B0
000077a0e99d1663  mov [r15+0x100], rax
000077a0e99d166a  jmp 0x000077A0E97FE110
000077a0e99d166f  int3
000077a0e99d1670  call 0x000077A0E980DC20
000077a0e99d1675  jmp 0x000077A0E99D1592
000077a0e99d167a  call 0x000077A0E980B5E0
000077a0e99d167f  jmp 0x000077A0E99D159E
000077a0e99d1684  call 0x000077A0E98A3D90
000077a0e99d1689  jmp 0x000077A0E99D15A7
000077a0e99d168e  int3
000077a0e99d168f  nop
000077a0e99d1690  mov rax, [r15+0x98]
000077a0e99d1697  mov r14, [r15+0x58]
000077a0e99d169b  mov [rsp+0x10], r14
000077a0e99d16a0  shl r14, 0x02
000077a0e99d16a4  lea r12, [rax+r14*1]
000077a0e99d16a8  mov eax, [r13+r12*1]
000077a0e99d16ad  lea r14, [r12+0x04]
000077a0e99d16b2  mov r12d, [r13+r14*1]
000077a0e99d16b7  mov eax, eax
000077a0e99d16b9  mov [r15+0x68], rax
000077a0e99d16bd  mov r12d, r12d
000077a0e99d16c0  mov [r15+0x60], r12
000077a0e99d16c4  mov rax, [r15+0x68]
000077a0e99d16c8  mov [rsp+0x20], rax
000077a0e99d16cd  mov r14, [rsp+0x10]
000077a0e99d16d2  imul rax, r14
000077a0e99d16d6  mov r12, [rsp+0x20]
000077a0e99d16db  lea r11, [r12+rax*1]
000077a0e99d16df  mov [r15+0x68], r11
000077a0e99d16e3  lea rax, [r14+0x02]
000077a0e99d16e7  mov [r15+0x58], rax
000077a0e99d16eb  mov [rsp+0x10], rax
000077a0e99d16f0  xor eax, eax
000077a0e99d16f2  mov r14, [rsp+0x10]
000077a0e99d16f7  mov r12d, 0x400
000077a0e99d16fd  cmp r14, r12
000077a0e99d1700  cmc
000077a0e99d1701  lahf
000077a0e99d1702  seto al
000077a0e99d1705  mov [r15+0x108], eax
000077a0e99d170c  mov rax, [r15+0x50]
000077a0e99d1710  mov r12, [r15+0x60]
000077a0e99d1714  imul r14, r12
000077a0e99d1718  lea r12, [rax+r14*1]
000077a0e99d171c  mov [r15+0x50], r12
000077a0e99d1720  mov rax, [r15+0x48]
000077a0e99d1724  lea r14, [r11+rax*1]
000077a0e99d1728  mov [r15+0x48], r14
000077a0e99d172c  mov eax, [r15+0x108]
000077a0e99d1733  sahf
000077a0e99d1734  jnz 0x000077A0E99D1766
000077a0e99d1736  cmp dword ptr [r15+0x318], 0x00
000077a0e99d173e  jz 0x000077A0E99D17B0
000077a0e99d1744  nop [rax+rax*1], ax
000077a0e99d174d  nop [rax+rax*1], eax
000077a0e99d1755  mov eax, 0x4103D0
000077a0e99d175a  mov [r15+0x100], rax
000077a0e99d1761  jmp 0x000077A0E97FE110
000077a0e99d1766  cmp dword ptr [r15+0x318], 0x00
000077a0e99d176e  jz 0x000077A0E99D1690
000077a0e99d1774  nop [rax+rax*1], ax
000077a0e99d177d  nop [rax+rax*1], eax
000077a0e99d1785  mov eax, 0x4103B0
000077a0e99d178a  mov [r15+0x100], rax
000077a0e99d1791  jmp 0x000077A0E97FE110
000077a0e99d1796  int3
000077a0e99d1797  call 0x000077A0E98B4690
000077a0e99d179c  jmp 0x000077A0E99D16AD
000077a0e99d17a1  call 0x000077A0E98E26A0
000077a0e99d17a6  jmp 0x000077A0E99D16B7
000077a0e99d17ab  int3
000077a0e99d17ac  nop [rax], eax
000077a0e99d17b0  mov qword ptr [r15+0x98], 0x00
000077a0e99d17bb  mov rax, [r15+0x50]
000077a0e99d17bf  mov r14, [r15+0x48]
000077a0e99d17c3  lea r12, [rax+r14*1]
000077a0e99d17c7  mov [r15+0x48], r12
000077a0e99d17cb  mov rax, [r15+0x40]
000077a0e99d17cf  lea r14, [rax+0xC40]
000077a0e99d17d6  mov [r13+r14*1], r12
000077a0e99d17db  mov qword ptr [r15], 0x01
000077a0e99d17e2  mov qword ptr [r15+0xF0], 0x4103E8
000077a0e99d17ed  mov r14d, [r15+0x320]
000077a0e99d17f4  mov eax, 0x4103E8
000077a0e99d17f9  mov rcx, 0x77A0E99D1860
000077a0e99d1803  mov [r15+r14*8+0x328], rax
000077a0e99d180b  mov [r15+r14*8+0x368], rcx
000077a0e99d1813  add r14d, 0x01
000077a0e99d1817  and r14d, 0x07
000077a0e99d181b  mov [r15+0x320], r14d
000077a0e99d1822  cmp dword ptr [r15+0x318], 0x00
000077a0e99d182a  jz 0x000077A0E99D0F20
000077a0e99d1830  nop [rax+rax*1], ax
000077a0e99d1839  nop [rax+rax*1], eax
000077a0e99d1841  mov eax, 0x410938
000077a0e99d1846  mov [r15+0x100], rax
000077a0e99d184d  jmp 0x000077A0E97FE110
000077a0e99d1852  int3
000077a0e99d1853  call 0x000077A0E98E2CE0
000077a0e99d1858  jmp 0x000077A0E99D17DB
000077a0e99d185d  int3
000077a0e99d185e  nop
000077a0e99d1860  mov eax, [r15+0x98]
000077a0e99d1867  lea r14d, [eax+0x01]
000077a0e99d186c  mov [rsp+0x10], r14d
000077a0e99d1871  mov r14d, r14d
000077a0e99d1874  mov [r15+0x98], r14
000077a0e99d187b  xor eax, eax
000077a0e99d187d  mov r14d, [rsp+0x10]
000077a0e99d1882  cmp r14d, 0x10000
000077a0e99d1889  cmc
000077a0e99d188a  lahf
000077a0e99d188b  seto al
000077a0e99d188e  mov [r15+0x108], eax
000077a0e99d1895  mov eax, [r15+0x108]
000077a0e99d189c  sahf
000077a0e99d189d  jnz 0x000077A0E99D18CF
000077a0e99d189f  cmp dword ptr [r15+0x318], 0x00
000077a0e99d18a7  jz 0x000077A0E99D19A0
000077a0e99d18ad  nop [rax+rax*1], ax
000077a0e99d18b6  nop [rax+rax*1], eax
000077a0e99d18be  mov eax, 0x4103F4
000077a0e99d18c3  mov [r15+0x100], rax
000077a0e99d18ca  jmp 0x000077A0E97FE110
000077a0e99d18cf  cmp dword ptr [r15+0x318], 0x00
000077a0e99d18d7  jz 0x000077A0E99D1910
000077a0e99d18dd  nop [rax+rax*1], ax
000077a0e99d18e6  nop [rax+rax*1], eax
000077a0e99d18ee  mov eax, 0x4103E0
000077a0e99d18f3  mov [r15+0x100], rax
000077a0e99d18fa  jmp 0x000077A0E97FE110
000077a0e99d18ff  int3
000077a0e99d1900  int3
000077a0e99d1901  nop [rax+rax*1], ax
000077a0e99d190a  nop [rax+rax*1], ax
000077a0e99d1910  mov eax, [r15]
000077a0e99d1913  mov r14d, [r15+0x98]
000077a0e99d191a  lea r12d, [eax+r14d*1]
000077a0e99d191f  mov r12d, r12d
000077a0e99d1922  mov [r15], r12
000077a0e99d1925  mov qword ptr [r15+0xF0], 0x4103E8
000077a0e99d1930  mov r14d, [r15+0x320]
000077a0e99d1937  mov eax, 0x4103E8
000077a0e99d193c  mov rcx, 0x77A0E99D1860
000077a0e99d1946  mov [r15+r14*8+0x328], rax
000077a0e99d194e  mov [r15+r14*8+0x368], rcx
000077a0e99d1956  add r14d, 0x01
000077a0e99d195a  and r14d, 0x07
000077a0e99d195e  mov [r15+0x320], r14d
000077a0e99d1965  cmp dword ptr [r15+0x318], 0x00
000077a0e99d196d  jz 0x000077A0E99D0F20
000077a0e99d1973  nop [rax+rax*1], ax
000077a0e99d197c  nop [rax+rax*1], eax
000077a0e99d1984  mov eax, 0x410938
000077a0e99d1989  mov [r15+0x100], rax
000077a0e99d1990  jmp 0x000077A0E97FE110
000077a0e99d1995  int3
000077a0e99d1996  int3
000077a0e99d1997  nop [rax+rax*1], ax
000077a0e99d19a0  vmovaps xmm1, [0x000077A0E95FE010]
000077a0e99d19a8  movq xmm1, xmm1
000077a0e99d19ac  movaps [r15+0x110], xmm1
000077a0e99d19b4  mov eax, 0x420AA0
000077a0e99d19b9  mov r14, [r13+rax*1]
000077a0e99d19be  movq xmm1, r14
000077a0e99d19c3  movaps [r15+0x120], xmm1
000077a0e99d19cb  vmovaps xmm1, [0x000077A0E95FE020]
000077a0e99d19d3  movq xmm1, xmm1
000077a0e99d19d7  movaps [r15+0x140], xmm1
000077a0e99d19df  vmovaps xmm1, [0x000077A0E95FE030]
000077a0e99d19e7  vpbroadcastq xmm1, xmm1
000077a0e99d19ec  movaps [r15+0x150], xmm1
000077a0e99d19f4  mov qword ptr [r15+0x40], 0x02
000077a0e99d19fc  vmovaps xmm15, [0x000077A0E95FE040]
000077a0e99d1a04  movq xmm15, xmm15
000077a0e99d1a09  movaps [r15+0x160], xmm15
000077a0e99d1a11  vmovaps xmm15, [0x000077A0E95FE050]
000077a0e99d1a19  vpbroadcastq xmm15, xmm15
000077a0e99d1a1e  movaps [r15+0x130], xmm15
000077a0e99d1a26  mov rax, [r15+0x40]
000077a0e99d1a2a  vmovq xmm14, rax
000077a0e99d1a2f  vpbroadcastq xmm14, xmm14
000077a0e99d1a34  movaps [r15+0x170], xmm14
000077a0e99d1a3c  mov eax, 0x4209D0
000077a0e99d1a41  movups xmm13, [r13+rax*1]
000077a0e99d1a47  mov qword ptr [r15+0x40], 0x431D90
000077a0e99d1a4f  mov eax, [r15]
000077a0e99d1a52  mov r14d, 0x430C48
000077a0e99d1a58  mov [r13+r14*1], eax
000077a0e99d1a5d  mov qword ptr [r15+0x50], 0x431F90
000077a0e99d1a65  vpmovqd xmm12, xmm13
000077a0e99d1a6b  pxor xmm11, xmm11
000077a0e99d1a70  punpcklqdq xmm12, xmm11
000077a0e99d1a75  movaps [r15+0x210], xmm12
000077a0e99d1a7d  movq xmm12, qword ptr [r15+0x140]
000077a0e99d1a86  movq xmm11, qword ptr [r15+0x120]
000077a0e99d1a8f  psubd xmm12, xmm11
000077a0e99d1a94  movq xmm12, xmm12
000077a0e99d1a99  paddq xmm13, xmm14
000077a0e99d1a9e  movaps [r15+0x180], xmm13
000077a0e99d1aa6  movq xmm14, qword ptr [r15+0x160]
000077a0e99d1aaf  paddd xmm11, xmm14
000077a0e99d1ab4  movq xmm11, xmm11
000077a0e99d1ab9  movq xmm11, xmm11
000077a0e99d1abe  movaps [r15+0x120], xmm11
000077a0e99d1ac6  pmovzxdq xmm12, xmm12
000077a0e99d1acc  psllq xmm12, 0x00
000077a0e99d1ad2  movq xmm14, qword ptr [r15+0x210]
000077a0e99d1adb  movq xmm13, qword ptr [r15+0x110]
000077a0e99d1ae4  paddd xmm14, xmm13
000077a0e99d1ae9  movq xmm14, xmm14
000077a0e99d1aee  vcvtuqq2pd xmm12, xmm12
000077a0e99d1af4  pmovzxdq xmm14, xmm14
000077a0e99d1afa  psllq xmm14, 0x00
000077a0e99d1b00  vcvtuqq2pd xmm14, xmm14
000077a0e99d1b06  movaps xmm13, xmm12
000077a0e99d1b0a  mulpd xmm13, xmm1
000077a0e99d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000077a0e99d1b15  ptest xmm11, xmm11
000077a0e99d1b1b  jnz 0x000077A0E99D1C0F
000077a0e99d1b21  movaps [r15+0x220], xmm13
000077a0e99d1b29  mov eax, 0x431F90
000077a0e99d1b2e  movups [r13+rax*1], xmm13
000077a0e99d1b34  movaps xmm1, xmm14
000077a0e99d1b38  mulpd xmm1, xmm15
000077a0e99d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000077a0e99d1b42  ptest xmm13, xmm13
000077a0e99d1b48  jnz 0x000077A0E99D1D5C
000077a0e99d1b4e  movaps [r15+0x210], xmm1
000077a0e99d1b56  mov eax, 0x431D90
000077a0e99d1b5b  movups [r13+rax*1], xmm1
000077a0e99d1b61  mov qword ptr [r15+0x48], 0x10
000077a0e99d1b69  xor eax, eax
000077a0e99d1b6b  mov r14d, 0x10
000077a0e99d1b71  mov r12d, 0x200
000077a0e99d1b77  cmp r14, r12
000077a0e99d1b7a  cmc
000077a0e99d1b7b  lahf
000077a0e99d1b7c  seto al
000077a0e99d1b7f  mov [r15+0x108], eax
000077a0e99d1b86  mov eax, [r15+0x108]
000077a0e99d1b8d  sahf
000077a0e99d1b8e  jnz 0x000077A0E99D1BC0
000077a0e99d1b90  cmp dword ptr [r15+0x318], 0x00
000077a0e99d1b98  jz 0x000077A0E99D2300
000077a0e99d1b9e  nop [rax+rax*1], ax
000077a0e99d1ba7  nop [rax+rax*1], eax
000077a0e99d1baf  mov eax, 0x410480
000077a0e99d1bb4  mov [r15+0x100], rax
000077a0e99d1bbb  jmp 0x000077A0E97FE110
000077a0e99d1bc0  cmp dword ptr [r15+0x318], 0x00
000077a0e99d1bc8  jz 0x000077A0E99D1EB0
000077a0e99d1bce  nop [rax+rax*1], ax
000077a0e99d1bd7  nop [rax+rax*1], eax
000077a0e99d1bdf  mov eax, 0x410440
000077a0e99d1be4  mov [r15+0x100], rax
000077a0e99d1beb  jmp 0x000077A0E97FE110
000077a0e99d1bf0  int3
000077a0e99d1bf1  call 0x000077A0E980DC20
000077a0e99d1bf6  jmp 0x000077A0E99D19BE
000077a0e99d1bfb  call 0x000077A0E980C260
000077a0e99d1c00  jmp 0x000077A0E99D1A47
000077a0e99d1c05  call 0x000077A0E98D5D70
000077a0e99d1c0a  jmp 0x000077A0E99D1A5D
000077a0e99d1c0f  sub rsp, 0x08
000077a0e99d1c13  push rax
000077a0e99d1c14  push rcx
000077a0e99d1c15  push rdx
000077a0e99d1c16  push rdi
000077a0e99d1c17  push rsi
000077a0e99d1c18  push r8
000077a0e99d1c1a  push r9
000077a0e99d1c1c  push r10
000077a0e99d1c1e  push r11
000077a0e99d1c20  sub rsp, 0xF0
000077a0e99d1c27  vmovaps [rsp], xmm0
000077a0e99d1c2c  vmovaps [rsp+0x10], xmm1
000077a0e99d1c32  vmovaps [rsp+0x20], xmm2
000077a0e99d1c38  vmovaps [rsp+0x30], xmm3
000077a0e99d1c3e  vmovaps [rsp+0x40], xmm4
000077a0e99d1c44  vmovaps [rsp+0x50], xmm5
000077a0e99d1c4a  vmovaps [rsp+0x60], xmm6
000077a0e99d1c50  vmovaps [rsp+0x70], xmm7
000077a0e99d1c56  vmovaps [rsp+0x80], xmm8
000077a0e99d1c5f  vmovaps [rsp+0x90], xmm9
000077a0e99d1c68  vmovaps [rsp+0xA0], xmm10
000077a0e99d1c71  vmovaps [rsp+0xB0], xmm11
000077a0e99d1c7a  vmovaps [rsp+0xC0], xmm12
000077a0e99d1c83  vmovaps [rsp+0xD0], xmm14
000077a0e99d1c8c  vmovaps [rsp+0xE0], xmm15
000077a0e99d1c95  sub rsp, 0x30
000077a0e99d1c99  movaps [rsp], xmm13
000077a0e99d1c9e  movaps [rsp+0x10], xmm12
000077a0e99d1ca4  movaps [rsp+0x20], xmm1
000077a0e99d1ca9  lea rdi, [rsp]
000077a0e99d1cad  mov esi, 0x00
000077a0e99d1cb2  mov rax, 0x60CAA235B530
000077a0e99d1cbc  call rax
000077a0e99d1cbe  movaps xmm13, [rsp]
000077a0e99d1cc3  add rsp, 0x30
000077a0e99d1cc7  vmovaps xmm0, [rsp]
000077a0e99d1ccc  vmovaps xmm1, [rsp+0x10]
000077a0e99d1cd2  vmovaps xmm2, [rsp+0x20]
000077a0e99d1cd8  vmovaps xmm3, [rsp+0x30]
000077a0e99d1cde  vmovaps xmm4, [rsp+0x40]
000077a0e99d1ce4  vmovaps xmm5, [rsp+0x50]
000077a0e99d1cea  vmovaps xmm6, [rsp+0x60]
000077a0e99d1cf0  vmovaps xmm7, [rsp+0x70]
000077a0e99d1cf6  vmovaps xmm8, [rsp+0x80]
000077a0e99d1cff  vmovaps xmm9, [rsp+0x90]
000077a0e99d1d08  vmovaps xmm10, [rsp+0xA0]
000077a0e99d1d11  vmovaps xmm11, [rsp+0xB0]
000077a0e99d1d1a  vmovaps xmm12, [rsp+0xC0]
000077a0e99d1d23  vmovaps xmm14, [rsp+0xD0]
000077a0e99d1d2c  vmovaps xmm15, [rsp+0xE0]
000077a0e99d1d35  add rsp, 0xF0
000077a0e99d1d3c  pop r11
000077a0e99d1d3e  pop r10
000077a0e99d1d40  pop r9
000077a0e99d1d42  pop r8
000077a0e99d1d44  pop rsi
000077a0e99d1d45  pop rdi
000077a0e99d1d46  pop rdx
000077a0e99d1d47  pop rcx
000077a0e99d1d48  pop rax
000077a0e99d1d49  add rsp, 0x08
000077a0e99d1d4d  jmp 0x000077A0E99D1B21
000077a0e99d1d52  call 0x000077A0E980C380
000077a0e99d1d57  jmp 0x000077A0E99D1B34
000077a0e99d1d5c  sub rsp, 0x08
000077a0e99d1d60  push rax
000077a0e99d1d61  push rcx
000077a0e99d1d62  push rdx
000077a0e99d1d63  push rdi
000077a0e99d1d64  push rsi
000077a0e99d1d65  push r8
000077a0e99d1d67  push r9
000077a0e99d1d69  push r10
000077a0e99d1d6b  push r11
000077a0e99d1d6d  sub rsp, 0xF0
000077a0e99d1d74  vmovaps [rsp], xmm0
000077a0e99d1d79  vmovaps [rsp+0x10], xmm2
000077a0e99d1d7f  vmovaps [rsp+0x20], xmm3
000077a0e99d1d85  vmovaps [rsp+0x30], xmm4
000077a0e99d1d8b  vmovaps [rsp+0x40], xmm5
000077a0e99d1d91  vmovaps [rsp+0x50], xmm6
000077a0e99d1d97  vmovaps [rsp+0x60], xmm7
000077a0e99d1d9d  vmovaps [rsp+0x70], xmm8
000077a0e99d1da3  vmovaps [rsp+0x80], xmm9
000077a0e99d1dac  vmovaps [rsp+0x90], xmm10
000077a0e99d1db5  vmovaps [rsp+0xA0], xmm11
000077a0e99d1dbe  vmovaps [rsp+0xB0], xmm12
000077a0e99d1dc7  vmovaps [rsp+0xC0], xmm13
000077a0e99d1dd0  vmovaps [rsp+0xD0], xmm14
000077a0e99d1dd9  vmovaps [rsp+0xE0], xmm15
000077a0e99d1de2  sub rsp, 0x30
000077a0e99d1de6  movaps [rsp], xmm1
000077a0e99d1dea  movaps [rsp+0x10], xmm14
000077a0e99d1df0  movaps [rsp+0x20], xmm15
000077a0e99d1df6  lea rdi, [rsp]
000077a0e99d1dfa  mov esi, 0x00
000077a0e99d1dff  mov rax, 0x60CAA235B530
000077a0e99d1e09  call rax
000077a0e99d1e0b  movaps xmm1, [rsp]
000077a0e99d1e0f  add rsp, 0x30
000077a0e99d1e13  vmovaps xmm0, [rsp]
000077a0e99d1e18  vmovaps xmm2, [rsp+0x10]
000077a0e99d1e1e  vmovaps xmm3, [rsp+0x20]
000077a0e99d1e24  vmovaps xmm4, [rsp+0x30]
000077a0e99d1e2a  vmovaps xmm5, [rsp+0x40]
000077a0e99d1e30  vmovaps xmm6, [rsp+0x50]
000077a0e99d1e36  vmovaps xmm7, [rsp+0x60]
000077a0e99d1e3c  vmovaps xmm8, [rsp+0x70]
000077a0e99d1e42  vmovaps xmm9, [rsp+0x80]
000077a0e99d1e4b  vmovaps xmm10, [rsp+0x90]
000077a0e99d1e54  vmovaps xmm11, [rsp+0xA0]
000077a0e99d1e5d  vmovaps xmm12, [rsp+0xB0]
000077a0e99d1e66  vmovaps xmm13, [rsp+0xC0]
000077a0e99d1e6f  vmovaps xmm14, [rsp+0xD0]
000077a0e99d1e78  vmovaps xmm15, [rsp+0xE0]
000077a0e99d1e81  add rsp, 0xF0
000077a0e99d1e88  pop r11
000077a0e99d1e8a  pop r10
000077a0e99d1e8c  pop r9
000077a0e99d1e8e  pop r8
000077a0e99d1e90  pop rsi
000077a0e99d1e91  pop rdi
000077a0e99d1e92  pop rdx
000077a0e99d1e93  pop rcx
000077a0e99d1e94  pop rax
000077a0e99d1e95  add rsp, 0x08
000077a0e99d1e99  jmp 0x000077A0E99D1B4E
000077a0e99d1e9e  call 0x000077A0E97FF540
000077a0e99d1ea3  jmp 0x000077A0E99D1B61
000077a0e99d1ea8  int3
000077a0e99d1ea9  nop [rax], eax
000077a0e99d1eb0  movaps xmm1, [r15+0x180]
000077a0e99d1eb8  vpmovqd xmm15, xmm1
000077a0e99d1ebe  pxor xmm14, xmm14
000077a0e99d1ec3  punpcklqdq xmm15, xmm14
000077a0e99d1ec8  movaps [r15+0x210], xmm15
000077a0e99d1ed0  movq xmm15, qword ptr [r15+0x140]
000077a0e99d1ed9  movq xmm14, qword ptr [r15+0x120]
000077a0e99d1ee2  psubd xmm15, xmm14
000077a0e99d1ee7  movq xmm15, xmm15
000077a0e99d1eec  movaps xmm13, [r15+0x170]
000077a0e99d1ef4  paddq xmm1, xmm13
000077a0e99d1ef9  movaps [r15+0x180], xmm1
000077a0e99d1f01  movq xmm1, qword ptr [r15+0x160]
000077a0e99d1f0a  paddd xmm14, xmm1
000077a0e99d1f0f  movq xmm14, xmm14
000077a0e99d1f14  movq xmm14, xmm14
000077a0e99d1f19  movaps [r15+0x120], xmm14
000077a0e99d1f21  pmovzxdq xmm15, xmm15
000077a0e99d1f27  psllq xmm15, 0x00
000077a0e99d1f2d  movq xmm1, qword ptr [r15+0x210]
000077a0e99d1f36  movq xmm14, qword ptr [r15+0x110]
000077a0e99d1f3f  paddd xmm1, xmm14
000077a0e99d1f44  movq xmm1, xmm1
000077a0e99d1f48  vcvtuqq2pd xmm15, xmm15
000077a0e99d1f4e  pmovzxdq xmm1, xmm1
000077a0e99d1f53  psllq xmm1, 0x00
000077a0e99d1f58  vcvtuqq2pd xmm1, xmm1
000077a0e99d1f5e  movaps xmm14, [r15+0x150]
000077a0e99d1f66  movaps xmm13, xmm15
000077a0e99d1f6a  mulpd xmm13, xmm14
000077a0e99d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d1f75  ptest xmm12, xmm12
000077a0e99d1f7b  jnz 0x000077A0E99D205E
000077a0e99d1f81  movaps [r15+0x220], xmm13
000077a0e99d1f89  mov rax, [r15+0x48]
000077a0e99d1f8d  mov r14, [r15+0x50]
000077a0e99d1f91  lea r12, [r14+rax*1]
000077a0e99d1f95  movups [r13+r12*1], xmm13
000077a0e99d1f9b  movaps xmm15, [r15+0x130]
000077a0e99d1fa3  movaps xmm14, xmm1
000077a0e99d1fa7  mulpd xmm14, xmm15
000077a0e99d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000077a0e99d1fb2  ptest xmm13, xmm13
000077a0e99d1fb8  jnz 0x000077A0E99D21AC
000077a0e99d1fbe  movaps [r15+0x210], xmm14
000077a0e99d1fc6  mov r14, [r15+0x40]
000077a0e99d1fca  lea r12, [r14+rax*1]
000077a0e99d1fce  movups [r13+r12*1], xmm14
000077a0e99d1fd4  lea r14, [rax+0x10]
000077a0e99d1fd8  mov [r15+0x48], r14
000077a0e99d1fdc  xor eax, eax
000077a0e99d1fde  mov r12d, 0x200
000077a0e99d1fe4  cmp r14, r12
000077a0e99d1fe7  cmc
000077a0e99d1fe8  lahf
000077a0e99d1fe9  seto al
000077a0e99d1fec  mov [r15+0x108], eax
000077a0e99d1ff3  mov eax, [r15+0x108]
000077a0e99d1ffa  sahf
000077a0e99d1ffb  jnz 0x000077A0E99D202D
000077a0e99d1ffd  cmp dword ptr [r15+0x318], 0x00
000077a0e99d2005  jz 0x000077A0E99D2300
000077a0e99d200b  nop [rax+rax*1], ax
000077a0e99d2014  nop [rax+rax*1], eax
000077a0e99d201c  mov eax, 0x410480
000077a0e99d2021  mov [r15+0x100], rax
000077a0e99d2028  jmp 0x000077A0E97FE110
000077a0e99d202d  cmp dword ptr [r15+0x318], 0x00
000077a0e99d2035  jz 0x000077A0E99D1EB0
000077a0e99d203b  nop [rax+rax*1], ax
000077a0e99d2044  nop [rax+rax*1], eax
000077a0e99d204c  mov eax, 0x410440
000077a0e99d2051  mov [r15+0x100], rax
000077a0e99d2058  jmp 0x000077A0E97FE110
000077a0e99d205d  int3
000077a0e99d205e  sub rsp, 0x08
000077a0e99d2062  push rax
000077a0e99d2063  push rcx
000077a0e99d2064  push rdx
000077a0e99d2065  push rdi
000077a0e99d2066  push rsi
000077a0e99d2067  push r8
000077a0e99d2069  push r9
000077a0e99d206b  push r10
000077a0e99d206d  push r11
000077a0e99d206f  sub rsp, 0xF0
000077a0e99d2076  vmovaps [rsp], xmm0
000077a0e99d207b  vmovaps [rsp+0x10], xmm1
000077a0e99d2081  vmovaps [rsp+0x20], xmm2
000077a0e99d2087  vmovaps [rsp+0x30], xmm3
000077a0e99d208d  vmovaps [rsp+0x40], xmm4
000077a0e99d2093  vmovaps [rsp+0x50], xmm5
000077a0e99d2099  vmovaps [rsp+0x60], xmm6
000077a0e99d209f  vmovaps [rsp+0x70], xmm7
000077a0e99d20a5  vmovaps [rsp+0x80], xmm8
000077a0e99d20ae  vmovaps [rsp+0x90], xmm9
000077a0e99d20b7  vmovaps [rsp+0xA0], xmm10
000077a0e99d20c0  vmovaps [rsp+0xB0], xmm11
000077a0e99d20c9  vmovaps [rsp+0xC0], xmm12
000077a0e99d20d2  vmovaps [rsp+0xD0], xmm14
000077a0e99d20db  vmovaps [rsp+0xE0], xmm15
000077a0e99d20e4  sub rsp, 0x30
000077a0e99d20e8  movaps [rsp], xmm13
000077a0e99d20ed  movaps [rsp+0x10], xmm15
000077a0e99d20f3  movaps [rsp+0x20], xmm14
000077a0e99d20f9  lea rdi, [rsp]
000077a0e99d20fd  mov esi, 0x00
000077a0e99d2102  mov rax, 0x60CAA235B530
000077a0e99d210c  call rax
000077a0e99d210e  movaps xmm13, [rsp]
000077a0e99d2113  add rsp, 0x30
000077a0e99d2117  vmovaps xmm0, [rsp]
000077a0e99d211c  vmovaps xmm1, [rsp+0x10]
000077a0e99d2122  vmovaps xmm2, [rsp+0x20]
000077a0e99d2128  vmovaps xmm3, [rsp+0x30]
000077a0e99d212e  vmovaps xmm4, [rsp+0x40]
000077a0e99d2134  vmovaps xmm5, [rsp+0x50]
000077a0e99d213a  vmovaps xmm6, [rsp+0x60]
000077a0e99d2140  vmovaps xmm7, [rsp+0x70]
000077a0e99d2146  vmovaps xmm8, [rsp+0x80]
000077a0e99d214f  vmovaps xmm9, [rsp+0x90]
000077a0e99d2158  vmovaps xmm10, [rsp+0xA0]
000077a0e99d2161  vmovaps xmm11, [rsp+0xB0]
000077a0e99d216a  vmovaps xmm12, [rsp+0xC0]
000077a0e99d2173  vmovaps xmm14, [rsp+0xD0]
000077a0e99d217c  vmovaps xmm15, [rsp+0xE0]
000077a0e99d2185  add rsp, 0xF0
000077a0e99d218c  pop r11
000077a0e99d218e  pop r10
000077a0e99d2190  pop r9
000077a0e99d2192  pop r8
000077a0e99d2194  pop rsi
000077a0e99d2195  pop rdi
000077a0e99d2196  pop rdx
000077a0e99d2197  pop rcx
000077a0e99d2198  pop rax
000077a0e99d2199  add rsp, 0x08
000077a0e99d219d  jmp 0x000077A0E99D1F81
000077a0e99d21a2  call 0x000077A0E98C2240
000077a0e99d21a7  jmp 0x000077A0E99D1F9B
000077a0e99d21ac  sub rsp, 0x08
000077a0e99d21b0  push rax
000077a0e99d21b1  push rcx
000077a0e99d21b2  push rdx
000077a0e99d21b3  push rdi
000077a0e99d21b4  push rsi
000077a0e99d21b5  push r8
000077a0e99d21b7  push r9
000077a0e99d21b9  push r10
000077a0e99d21bb  push r11
000077a0e99d21bd  sub rsp, 0xF0
000077a0e99d21c4  vmovaps [rsp], xmm0
000077a0e99d21c9  vmovaps [rsp+0x10], xmm1
000077a0e99d21cf  vmovaps [rsp+0x20], xmm2
000077a0e99d21d5  vmovaps [rsp+0x30], xmm3
000077a0e99d21db  vmovaps [rsp+0x40], xmm4
000077a0e99d21e1  vmovaps [rsp+0x50], xmm5
000077a0e99d21e7  vmovaps [rsp+0x60], xmm6
000077a0e99d21ed  vmovaps [rsp+0x70], xmm7
000077a0e99d21f3  vmovaps [rsp+0x80], xmm8
000077a0e99d21fc  vmovaps [rsp+0x90], xmm9
000077a0e99d2205  vmovaps [rsp+0xA0], xmm10
000077a0e99d220e  vmovaps [rsp+0xB0], xmm11
000077a0e99d2217  vmovaps [rsp+0xC0], xmm12
000077a0e99d2220  vmovaps [rsp+0xD0], xmm13
000077a0e99d2229  vmovaps [rsp+0xE0], xmm15
000077a0e99d2232  sub rsp, 0x30
000077a0e99d2236  movaps [rsp], xmm14
000077a0e99d223b  movaps [rsp+0x10], xmm1
000077a0e99d2240  movaps [rsp+0x20], xmm15
000077a0e99d2246  lea rdi, [rsp]
000077a0e99d224a  mov esi, 0x00
000077a0e99d224f  mov rax, 0x60CAA235B530
000077a0e99d2259  call rax
000077a0e99d225b  movaps xmm14, [rsp]
000077a0e99d2260  add rsp, 0x30
000077a0e99d2264  vmovaps xmm0, [rsp]
000077a0e99d2269  vmovaps xmm1, [rsp+0x10]
000077a0e99d226f  vmovaps xmm2, [rsp+0x20]
000077a0e99d2275  vmovaps xmm3, [rsp+0x30]
000077a0e99d227b  vmovaps xmm4, [rsp+0x40]
000077a0e99d2281  vmovaps xmm5, [rsp+0x50]
000077a0e99d2287  vmovaps xmm6, [rsp+0x60]
000077a0e99d228d  vmovaps xmm7, [rsp+0x70]
000077a0e99d2293  vmovaps xmm8, [rsp+0x80]
000077a0e99d229c  vmovaps xmm9, [rsp+0x90]
000077a0e99d22a5  vmovaps xmm10, [rsp+0xA0]
000077a0e99d22ae  vmovaps xmm11, [rsp+0xB0]
000077a0e99d22b7  vmovaps xmm12, [rsp+0xC0]
000077a0e99d22c0  vmovaps xmm13, [rsp+0xD0]
000077a0e99d22c9  vmovaps xmm15, [rsp+0xE0]
000077a0e99d22d2  add rsp, 0xF0
000077a0e99d22d9  pop r11
000077a0e99d22db  pop r10
000077a0e99d22dd  pop r9
000077a0e99d22df  pop r8
000077a0e99d22e1  pop rsi
000077a0e99d22e2  pop rdi
000077a0e99d22e3  pop rdx
000077a0e99d22e4  pop rcx
000077a0e99d22e5  pop rax
000077a0e99d22e6  add rsp, 0x08
000077a0e99d22ea  jmp 0x000077A0E99D1FBE
000077a0e99d22ef  call 0x000077A0E98C34C0
000077a0e99d22f4  jmp 0x000077A0E99D1FD4
000077a0e99d22f9  int3
000077a0e99d22fa  nop [rax+rax*1], ax
000077a0e99d2300  mov rax, [r15+0x50]
000077a0e99d2304  movups xmm1, [r13+rax*1]
000077a0e99d230a  lea r14, [rax+0x10]
000077a0e99d230e  movups xmm15, [r13+r14*1]
000077a0e99d2314  mov qword ptr [r15+0x48], 0x00
000077a0e99d231c  lea r14, [rax+0x40]
000077a0e99d2320  movups xmm14, [r13+r14*1]
000077a0e99d2326  lea r14, [rax+0x50]
000077a0e99d232a  movups xmm13, [r13+r14*1]
000077a0e99d2330  lea r14, [rax+0x80]
000077a0e99d2337  movups xmm12, [r13+r14*1]
000077a0e99d233d  lea r14, [rax+0x90]
000077a0e99d2344  movups xmm11, [r13+r14*1]
000077a0e99d234a  mov r14, [r15+0xF8]
000077a0e99d2351  movups [r13+r14*1], xmm1
000077a0e99d2357  lea r12, [rax+0x20]
000077a0e99d235b  movups xmm1, [r13+r12*1]
000077a0e99d2361  lea r12, [rax+0x30]
000077a0e99d2365  movups xmm10, [r13+r12*1]
000077a0e99d236b  lea r12, [rax+0xC0]
000077a0e99d2372  movups xmm9, [r13+r12*1]
000077a0e99d2378  lea r12, [rax+0xD0]
000077a0e99d237f  movups xmm8, [r13+r12*1]
000077a0e99d2385  lea r12, [rax+0x100]
000077a0e99d238c  movups xmm7, [r13+r12*1]
000077a0e99d2392  lea r12, [rax+0x110]
000077a0e99d2399  movups xmm6, [r13+r12*1]
000077a0e99d239f  lea r12, [rax+0x140]
000077a0e99d23a6  movups xmm5, [r13+r12*1]
000077a0e99d23ac  lea r12, [rax+0x150]
000077a0e99d23b3  movups xmm4, [r13+r12*1]
000077a0e99d23b9  lea r12, [r14+0xB0]
000077a0e99d23c0  movups [r13+r12*1], xmm10
000077a0e99d23c6  lea r12, [r14+0xC0]
000077a0e99d23cd  movups [r13+r12*1], xmm1
000077a0e99d23d3  lea r12, [rax+0x180]
000077a0e99d23da  movups xmm1, [r13+r12*1]
000077a0e99d23e0  lea r12, [rax+0x190]
000077a0e99d23e7  movups xmm10, [r13+r12*1]
000077a0e99d23ed  lea r12, [rax+0x1C0]
000077a0e99d23f4  movups xmm3, [r13+r12*1]
000077a0e99d23fa  lea r12, [rax+0x1D0]
000077a0e99d2401  movups xmm2, [r13+r12*1]
000077a0e99d2407  lea r12, [rax+0x60]
000077a0e99d240b  vmovaps [rsp+0x10], xmm1
000077a0e99d2411  movups xmm1, [r13+r12*1]
000077a0e99d2417  lea r12, [rax+0x70]
000077a0e99d241b  vmovaps [rsp+0x20], xmm1
000077a0e99d2421  movups xmm1, [r13+r12*1]
000077a0e99d2427  lea r12, [r14+0x70]
000077a0e99d242b  movups [r13+r12*1], xmm10
000077a0e99d2431  lea r12, [r14+0x80]
000077a0e99d2438  vmovaps xmm10, [rsp+0x10]
000077a0e99d243e  movups [r13+r12*1], xmm10
000077a0e99d2444  lea r12, [rax+0xA0]
000077a0e99d244b  movups xmm10, [r13+r12*1]
000077a0e99d2451  lea r12, [rax+0xB0]
000077a0e99d2458  vmovaps [rsp+0x10], xmm1
000077a0e99d245e  movups xmm1, [r13+r12*1]
000077a0e99d2464  lea r12, [r14+0x90]
000077a0e99d246b  movups [r13+r12*1], xmm2
000077a0e99d2471  lea r12, [r14+0xA0]
000077a0e99d2478  movups [r13+r12*1], xmm3
000077a0e99d247e  lea r12, [rax+0xE0]
000077a0e99d2485  movups xmm3, [r13+r12*1]
000077a0e99d248b  lea r12, [rax+0xF0]
000077a0e99d2492  movups xmm2, [r13+r12*1]
000077a0e99d2498  lea r12, [rax+0x120]
000077a0e99d249f  vmovaps [rsp+0x30], xmm1
000077a0e99d24a5  movups xmm1, [r13+r12*1]
000077a0e99d24ab  lea r12, [rax+0x130]
000077a0e99d24b2  vmovaps [rsp+0x40], xmm1
000077a0e99d24b8  movups xmm1, [r13+r12*1]
000077a0e99d24be  vmovaps [rsp+0x50], xmm1
000077a0e99d24c4  vmovaps xmm1, [rsp+0x40]
000077a0e99d24ca  movaps [r15+0x190], xmm1
000077a0e99d24d2  lea r12, [rax+0x160]
000077a0e99d24d9  vmovaps [rsp+0x40], xmm1
000077a0e99d24df  movups xmm1, [r13+r12*1]
000077a0e99d24e5  lea r12, [rax+0x170]
000077a0e99d24ec  vmovaps [rsp+0x60], xmm1
000077a0e99d24f2  movups xmm1, [r13+r12*1]
000077a0e99d24f8  lea r12, [rax+0x1A0]
000077a0e99d24ff  vmovaps [rsp+0x70], xmm1
000077a0e99d2505  movups xmm1, [r13+r12*1]
000077a0e99d250b  lea r12, [rax+0x1B0]
000077a0e99d2512  vmovaps [rsp+0x80], xmm1
000077a0e99d251b  movups xmm1, [r13+r12*1]
000077a0e99d2521  lea r12, [rax+0x1E0]
000077a0e99d2528  vmovaps [rsp+0x90], xmm1
000077a0e99d2531  movups xmm1, [r13+r12*1]
000077a0e99d2537  lea r12, [rax+0x1F0]
000077a0e99d253e  vmovaps [rsp+0xA0], xmm1
000077a0e99d2547  movups xmm1, [r13+r12*1]
000077a0e99d254d  mov qword ptr [r15+0x50], 0x432190
000077a0e99d2555  lea rax, [r14+0x50]
000077a0e99d2559  vmovaps [rsp+0xB0], xmm1
000077a0e99d2562  vmovaps xmm1, [rsp+0x60]
000077a0e99d2568  movups [r13+rax*1], xmm1
000077a0e99d256e  lea rax, [r14+0x60]
000077a0e99d2572  movups [r13+rax*1], xmm5
000077a0e99d2578  lea rax, [r14+0x40]
000077a0e99d257c  vmovaps xmm1, [rsp+0x70]
000077a0e99d2582  movups [r13+rax*1], xmm1
000077a0e99d2588  lea rax, [r14+0x20]
000077a0e99d258c  vmovaps xmm1, [rsp+0xA0]
000077a0e99d2595  movups [r13+rax*1], xmm1
000077a0e99d259b  lea rax, [r14+0x30]
000077a0e99d259f  vmovaps xmm1, [rsp+0x90]
000077a0e99d25a8  movups [r13+rax*1], xmm1
000077a0e99d25ae  lea rax, [r14+0x10]
000077a0e99d25b2  vmovaps xmm1, [rsp+0xB0]
000077a0e99d25bb  movups [r13+rax*1], xmm1
000077a0e99d25c1  mov rax, [r15+0x40]
000077a0e99d25c5  vxorps xmm1, xmm1, xmm1
000077a0e99d25c9  vpbroadcastq xmm1, xmm1
000077a0e99d25ce  vxorps xmm5, xmm5, xmm5
000077a0e99d25d2  vpbroadcastq xmm5, xmm5
000077a0e99d25d7  lea r12, [rax+0x30]
000077a0e99d25db  mov r11, [r13+r12*1]
000077a0e99d25e0  lea r12, [rax+0x38]
000077a0e99d25e4  mov r10, [r13+r12*1]
000077a0e99d25e9  vmovaps [rsp+0x60], xmm1
000077a0e99d25ef  movq xmm1, r11
000077a0e99d25f4  vmovaps [rsp+0x70], xmm1
000077a0e99d25fa  movq xmm1, r10
000077a0e99d25ff  vmovaps [rsp+0x90], xmm1
000077a0e99d2608  vmovaps xmm1, [rsp+0x70]
000077a0e99d260e  movq xmm1, xmm1
000077a0e99d2612  vmovaps [rsp+0x70], xmm1
000077a0e99d2618  vmovaps xmm1, [rsp+0x90]
000077a0e99d2621  movq xmm1, xmm1
000077a0e99d2625  vmovaps [rsp+0x90], xmm1
000077a0e99d262e  movq xmm1, xmm1
000077a0e99d2632  movaps [r15+0x270], xmm1
000077a0e99d263a  vmovaps [rsp+0xA0], xmm7
000077a0e99d2643  vmovaps xmm1, [rsp+0xA0]
000077a0e99d264c  por xmm7, xmm1
000077a0e99d2650  lea r12, [rax+0x20]
000077a0e99d2654  mov r11, [r13+r12*1]
000077a0e99d2659  lea r12, [rax+0x28]
000077a0e99d265d  mov r10, [r13+r12*1]
000077a0e99d2662  movq xmm1, r11
000077a0e99d2667  vmovaps [rsp+0xA0], xmm1
000077a0e99d2670  movq xmm1, r10
000077a0e99d2675  vmovaps [rsp+0xB0], xmm1
000077a0e99d267e  vmovaps xmm1, [rsp+0xA0]
000077a0e99d2687  movq xmm1, xmm1
000077a0e99d268b  vmovaps [rsp+0xA0], xmm1
000077a0e99d2694  vmovaps xmm1, [rsp+0xB0]
000077a0e99d269d  movq xmm1, xmm1
000077a0e99d26a1  vmovaps [rsp+0xB0], xmm2
000077a0e99d26aa  vmovaps [rsp+0xC0], xmm1
000077a0e99d26b3  vmovaps xmm1, [rsp+0xB0]
000077a0e99d26bc  por xmm2, xmm1
000077a0e99d26c0  vmovaps [rsp+0xB0], xmm3
000077a0e99d26c9  vmovaps xmm1, [rsp+0xB0]
000077a0e99d26d2  por xmm3, xmm1
000077a0e99d26d6  vmovaps [rsp+0xB0], xmm4
000077a0e99d26df  vmovaps xmm1, [rsp+0xB0]
000077a0e99d26e8  por xmm4, xmm1
000077a0e99d26ec  vmovaps [rsp+0xB0], xmm9
000077a0e99d26f5  vmovaps xmm1, [rsp+0xB0]
000077a0e99d26fe  por xmm9, xmm1
000077a0e99d2703  lea r12, [rax+0x10]
000077a0e99d2707  mov r11, [r13+r12*1]
000077a0e99d270c  lea r12, [rax+0x18]
000077a0e99d2710  mov r10, [r13+r12*1]
000077a0e99d2715  movq xmm1, r11
000077a0e99d271a  vmovaps [rsp+0xB0], xmm1
000077a0e99d2723  movq xmm1, r10
000077a0e99d2728  vmovaps [rsp+0xD0], xmm1
000077a0e99d2731  vmovaps xmm1, [rsp+0xB0]
000077a0e99d273a  movq xmm1, xmm1
000077a0e99d273e  vmovaps [rsp+0xB0], xmm1
000077a0e99d2747  vmovaps xmm1, [rsp+0xD0]
000077a0e99d2750  movq xmm1, xmm1
000077a0e99d2754  vmovaps [rsp+0xD0], xmm1
000077a0e99d275d  vmovaps xmm1, [rsp+0x80]
000077a0e99d2766  vmovaps [rsp+0xE0], xmm15
000077a0e99d276f  vmovaps xmm15, [rsp+0x80]
000077a0e99d2778  por xmm1, xmm15
000077a0e99d277d  vmovaps xmm15, [rsp+0x10]
000077a0e99d2783  vmovaps [rsp+0x80], xmm1
000077a0e99d278c  vmovaps xmm1, [rsp+0x10]
000077a0e99d2792  por xmm15, xmm1
000077a0e99d2797  vmovaps xmm1, [rsp+0x20]
000077a0e99d279d  vmovaps [rsp+0x10], xmm15
000077a0e99d27a3  vmovaps xmm15, [rsp+0x20]
000077a0e99d27a9  por xmm1, xmm15
000077a0e99d27ae  vmovaps [rsp+0x20], xmm6
000077a0e99d27b4  vmovaps xmm15, [rsp+0x20]
000077a0e99d27ba  por xmm6, xmm15
000077a0e99d27bf  vmovaps [rsp+0x20], xmm11
000077a0e99d27c5  vmovaps xmm15, [rsp+0x20]
000077a0e99d27cb  por xmm11, xmm15
000077a0e99d27d0  vmovaps [rsp+0x20], xmm13
000077a0e99d27d6  vmovaps xmm15, [rsp+0x20]
000077a0e99d27dc  por xmm13, xmm15
000077a0e99d27e1  vmovaps [rsp+0x20], xmm14
000077a0e99d27e7  vmovaps xmm15, [rsp+0x20]
000077a0e99d27ed  por xmm14, xmm15
000077a0e99d27f2  mov r12, [r13+rax*1]
000077a0e99d27f7  vmovq xmm15, r12
000077a0e99d27fc  vpbroadcastq xmm15, xmm15
000077a0e99d2801  vmovaps [rsp+0x20], xmm1
000077a0e99d2807  vxorps xmm1, xmm1, xmm1
000077a0e99d280b  vpbroadcastq xmm1, xmm1
000077a0e99d2810  vmovaps [rsp+0xF0], xmm1
000077a0e99d2819  movups xmm1, [r13+r14*1]
000077a0e99d281f  vmovaps [rsp+0x100], xmm1
000077a0e99d2828  vxorps xmm1, xmm1, xmm1
000077a0e99d282c  vpbroadcastq xmm1, xmm1
000077a0e99d2831  lea r12, [rax+0x08]
000077a0e99d2835  mov rax, [r13+r12*1]
000077a0e99d283a  vmovaps [rsp+0x110], xmm1
000077a0e99d2843  movq xmm1, rax
000077a0e99d2848  movaps [r15+0x240], xmm1
000077a0e99d2850  mov qword ptr [r15+0x60], 0x432190
000077a0e99d2858  mov qword ptr [r15+0x58], 0x40
000077a0e99d2860  vmovaps xmm1, [rsp+0x60]
000077a0e99d2866  vmovaps [rsp+0x60], xmm15
000077a0e99d286c  vmovaps xmm15, [rsp+0x100]
000077a0e99d2875  vmovaps [rsp+0x100], xmm14
000077a0e99d287e  vmovaps xmm14, [rsp+0x60]
000077a0e99d2884  vmovaps [rsp+0x60], xmm13
000077a0e99d288a  vmovaps [rsp+0x120], xmm12
000077a0e99d2893  movaps xmm13, xmm1
000077a0e99d2897  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d289c  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d28a2  vptest xmm12, xmm12
000077a0e99d28a7  jnz 0x000077A0E99D3482
000077a0e99d28ad  vmovaps xmm1, [rsp+0xE0]
000077a0e99d28b6  movaps xmm15, xmm5
000077a0e99d28ba  vfmadd231pd xmm15, xmm1, xmm14
000077a0e99d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
000077a0e99d28c5  vptest xmm12, xmm12
000077a0e99d28ca  jnz 0x000077A0E99D35DB
000077a0e99d28d0  vmovaps xmm12, [rsp+0x50]
000077a0e99d28d6  vmovaps xmm5, [rsp+0x50]
000077a0e99d28dc  por xmm12, xmm5
000077a0e99d28e1  vmovaps xmm5, [rsp+0x30]
000077a0e99d28e7  vmovaps [rsp+0x50], xmm1
000077a0e99d28ed  vmovaps xmm1, [rsp+0x30]
000077a0e99d28f3  por xmm5, xmm1
000077a0e99d28f7  vmovaps [rsp+0x30], xmm10
000077a0e99d28fd  vmovaps xmm1, [rsp+0x30]
000077a0e99d2903  por xmm10, xmm1
000077a0e99d2908  vmovaps [rsp+0x30], xmm8
000077a0e99d290e  vmovaps xmm1, [rsp+0x30]
000077a0e99d2914  por xmm8, xmm1
000077a0e99d2919  vmovaps xmm1, [rsp+0x120]
000077a0e99d2922  vmovaps [rsp+0x30], xmm15
000077a0e99d2928  vmovaps xmm15, [rsp+0x120]
000077a0e99d2931  por xmm1, xmm15
000077a0e99d2936  vmovaps xmm15, [rsp+0x50]
000077a0e99d293c  vmovaps [rsp+0xE0], xmm1
000077a0e99d2945  vmovaps xmm1, [rsp+0x50]
000077a0e99d294b  por xmm15, xmm1
000077a0e99d2950  lea rax, [r14+0xC0]
000077a0e99d2957  movups xmm1, [r13+rax*1]
000077a0e99d295d  xor eax, eax
000077a0e99d295f  mov r12d, 0x40
000077a0e99d2965  mov r11d, 0x200
000077a0e99d296b  cmp r12, r11
000077a0e99d296e  cmc
000077a0e99d296f  lahf
000077a0e99d2970  seto al
000077a0e99d2973  mov [r15+0x108], eax
000077a0e99d297a  vmovaps [rsp+0x50], xmm1
000077a0e99d2980  vmovaps xmm1, [rsp+0xF0]
000077a0e99d2989  vmovaps [rsp+0xF0], xmm15
000077a0e99d2992  vmovaps xmm15, [rsp+0x50]
000077a0e99d2998  vmovaps [rsp+0x50], xmm13
000077a0e99d299e  vmovaps [rsp+0x120], xmm12
000077a0e99d29a7  movaps xmm13, xmm1
000077a0e99d29ab  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d29b6  vptest xmm12, xmm12
000077a0e99d29bb  jnz 0x000077A0E99D373D
000077a0e99d29c1  lea rax, [r14+0xB0]
000077a0e99d29c8  movups xmm1, [r13+rax*1]
000077a0e99d29ce  vmovaps xmm15, [rsp+0x110]
000077a0e99d29d7  vmovaps [rsp+0x110], xmm13
000077a0e99d29e0  movaps xmm12, xmm15
000077a0e99d29e4  vfmadd231pd xmm12, xmm1, xmm14
000077a0e99d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
000077a0e99d29ef  vptest xmm13, xmm13
000077a0e99d29f4  jnz 0x000077A0E99D38A0
000077a0e99d29fa  vmovaps xmm1, [rsp+0x100]
000077a0e99d2a03  vmovaps xmm15, [rsp+0x100]
000077a0e99d2a0c  por xmm1, xmm15
000077a0e99d2a11  movaps [r15+0x210], xmm1
000077a0e99d2a19  vmovaps xmm15, [rsp+0x60]
000077a0e99d2a1f  vmovaps xmm14, [rsp+0x60]
000077a0e99d2a25  por xmm15, xmm14
000077a0e99d2a2a  movaps [r15+0x1C0], xmm15
000077a0e99d2a32  vmovaps [rsp+0x60], xmm11
000077a0e99d2a38  vmovaps xmm14, [rsp+0x60]
000077a0e99d2a3e  por xmm11, xmm14
000077a0e99d2a43  movaps [r15+0x280], xmm11
000077a0e99d2a4b  vmovaps [rsp+0x60], xmm6
000077a0e99d2a51  vmovaps xmm14, [rsp+0x60]
000077a0e99d2a57  por xmm6, xmm14
000077a0e99d2a5c  movaps [r15+0x2A0], xmm6
000077a0e99d2a64  vmovaps xmm14, [rsp+0x20]
000077a0e99d2a6a  vmovaps xmm13, [rsp+0x20]
000077a0e99d2a70  por xmm14, xmm13
000077a0e99d2a75  movaps [r15+0x2E0], xmm14
000077a0e99d2a7d  vmovaps xmm13, [rsp+0x10]
000077a0e99d2a83  vmovaps [rsp+0x20], xmm1
000077a0e99d2a89  vmovaps xmm1, [rsp+0x10]
000077a0e99d2a8f  por xmm13, xmm1
000077a0e99d2a94  movaps [r15+0x1F0], xmm13
000077a0e99d2a9c  vmovaps xmm1, [rsp+0xF0]
000077a0e99d2aa5  vmovaps [rsp+0x10], xmm15
000077a0e99d2aab  vmovaps xmm15, [rsp+0xF0]
000077a0e99d2ab4  por xmm1, xmm15
000077a0e99d2ab9  movaps [r15+0x250], xmm1
000077a0e99d2ac1  vmovaps xmm1, [rsp+0xE0]
000077a0e99d2aca  vmovaps xmm15, [rsp+0xE0]
000077a0e99d2ad3  por xmm1, xmm15
000077a0e99d2ad8  movaps [r15+0x260], xmm1
000077a0e99d2ae0  vmovaps [rsp+0x60], xmm8
000077a0e99d2ae6  vmovaps xmm15, [rsp+0x60]
000077a0e99d2aec  por xmm8, xmm15
000077a0e99d2af1  movaps [r15+0x290], xmm8
000077a0e99d2af9  vmovaps [rsp+0x60], xmm10
000077a0e99d2aff  vmovaps xmm15, [rsp+0x60]
000077a0e99d2b05  por xmm10, xmm15
000077a0e99d2b0a  movaps [r15+0x2C0], xmm10
000077a0e99d2b12  movq xmm15, qword ptr [r15+0x240]
000077a0e99d2b1b  vmovaps [rsp+0x60], xmm15
000077a0e99d2b21  vpermilpd xmm15, xmm15, 0x00
000077a0e99d2b27  vmovaps [rsp+0xE0], xmm1
000077a0e99d2b30  vmovaps xmm1, [rsp+0x50]
000077a0e99d2b36  vmovaps [rsp+0x50], xmm15
000077a0e99d2b3c  vmovaps xmm15, [rsp+0x20]
000077a0e99d2b42  vmovaps [rsp+0x20], xmm14
000077a0e99d2b48  vmovaps xmm14, [rsp+0x50]
000077a0e99d2b4e  vmovaps [rsp+0x50], xmm13
000077a0e99d2b54  vmovaps [rsp+0xF0], xmm12
000077a0e99d2b5d  movaps xmm13, xmm1
000077a0e99d2b61  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d2b6c  vptest xmm12, xmm12
000077a0e99d2b71  jnz 0x000077A0E99D39F9
000077a0e99d2b77  vmovaps xmm1, [rsp+0x60]
000077a0e99d2b7d  vpermilpd xmm1, xmm1, 0x00
000077a0e99d2b83  vmovaps xmm15, [rsp+0x110]
000077a0e99d2b8c  vmovaps xmm14, [rsp+0x20]
000077a0e99d2b92  vmovaps [rsp+0x20], xmm13
000077a0e99d2b98  movaps xmm12, xmm15
000077a0e99d2b9c  vfmadd231pd xmm12, xmm14, xmm1
000077a0e99d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
000077a0e99d2ba7  vptest xmm13, xmm13
000077a0e99d2bac  jnz 0x000077A0E99D3B52
000077a0e99d2bb2  vmovaps xmm1, [rsp+0x60]
000077a0e99d2bb8  vpermilpd xmm1, xmm1, 0x00
000077a0e99d2bbe  vmovaps xmm15, [rsp+0x30]
000077a0e99d2bc4  vmovaps xmm14, [rsp+0x10]
000077a0e99d2bca  vmovaps [rsp+0x10], xmm12
000077a0e99d2bd0  movaps xmm13, xmm15
000077a0e99d2bd4  vfmadd231pd xmm13, xmm14, xmm1
000077a0e99d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d2bdf  vptest xmm12, xmm12
000077a0e99d2be4  jnz 0x000077A0E99D3CAB
000077a0e99d2bea  vmovaps [rsp+0x30], xmm5
000077a0e99d2bf0  vmovaps xmm1, [rsp+0x30]
000077a0e99d2bf6  por xmm5, xmm1
000077a0e99d2bfa  movaps [r15+0x1D0], xmm5
000077a0e99d2c02  vmovaps xmm1, [rsp+0x60]
000077a0e99d2c08  vpermilpd xmm1, xmm1, 0x00
000077a0e99d2c0e  vmovaps xmm15, [rsp+0xF0]
000077a0e99d2c17  vmovaps xmm14, [rsp+0x50]
000077a0e99d2c1d  vmovaps [rsp+0x30], xmm13
000077a0e99d2c23  movaps xmm12, xmm15
000077a0e99d2c27  vfmadd231pd xmm12, xmm14, xmm1
000077a0e99d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
000077a0e99d2c32  vptest xmm13, xmm13
000077a0e99d2c37  jnz 0x000077A0E99D3E04
000077a0e99d2c3d  vmovaps xmm1, [rsp+0x80]
000077a0e99d2c46  vmovaps xmm15, [rsp+0x80]
000077a0e99d2c4f  por xmm1, xmm15
000077a0e99d2c54  movaps [r15+0x200], xmm1
000077a0e99d2c5c  vmovaps xmm15, [rsp+0x120]
000077a0e99d2c65  vmovaps xmm14, [rsp+0x120]
000077a0e99d2c6e  por xmm15, xmm14
000077a0e99d2c73  movaps [r15+0x1E0], xmm15
000077a0e99d2c7b  vmovaps [rsp+0x50], xmm4
000077a0e99d2c81  vmovaps xmm13, [rsp+0x50]
000077a0e99d2c87  por xmm4, xmm13
000077a0e99d2c8c  movaps [r15+0x2B0], xmm4
000077a0e99d2c94  vmovaps [rsp+0x50], xmm3
000077a0e99d2c9a  vmovaps xmm13, [rsp+0x50]
000077a0e99d2ca0  por xmm3, xmm13
000077a0e99d2ca5  movaps [r15+0x300], xmm3
000077a0e99d2cad  vmovaps xmm15, [rsp+0xB0]
000077a0e99d2cb6  vpermilpd xmm15, xmm15, 0x00
000077a0e99d2cbc  vmovaps xmm3, [rsp+0x20]
000077a0e99d2cc2  vmovaps [rsp+0x20], xmm1
000077a0e99d2cc8  vmovaps xmm1, [rsp+0xE0]
000077a0e99d2cd1  vmovaps [rsp+0x50], xmm14
000077a0e99d2cd7  vmovaps [rsp+0x60], xmm13
000077a0e99d2cdd  movaps xmm14, xmm3
000077a0e99d2ce1  vfmadd231pd xmm14, xmm1, xmm15
000077a0e99d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
000077a0e99d2cec  vptest xmm13, xmm13
000077a0e99d2cf1  jnz 0x000077A0E99D3F5D
000077a0e99d2cf7  vmovaps xmm1, [rsp+0xB0]
000077a0e99d2d00  vpermilpd xmm1, xmm1, 0x00
000077a0e99d2d06  vmovaps xmm15, [rsp+0x10]
000077a0e99d2d0c  movaps xmm13, xmm15
000077a0e99d2d10  vfmadd231pd xmm13, xmm10, xmm1
000077a0e99d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
000077a0e99d2d1b  vptest xmm3, xmm3
000077a0e99d2d20  jnz 0x000077A0E99D40B5
000077a0e99d2d26  vmovaps xmm1, [rsp+0xB0]
000077a0e99d2d2f  vpermilpd xmm1, xmm1, 0x00
000077a0e99d2d35  vmovaps xmm15, [rsp+0x30]
000077a0e99d2d3b  movaps xmm10, xmm15
000077a0e99d2d3f  vfmadd231pd xmm10, xmm11, xmm1
000077a0e99d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
000077a0e99d2d4a  vptest xmm3, xmm3
000077a0e99d2d4f  jnz 0x000077A0E99D420E
000077a0e99d2d55  vmovaps xmm1, [rsp+0xB0]
000077a0e99d2d5e  vpermilpd xmm1, xmm1, 0x00
000077a0e99d2d64  movaps xmm15, xmm12
000077a0e99d2d68  vfmadd231pd xmm15, xmm5, xmm1
000077a0e99d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
000077a0e99d2d73  vptest xmm11, xmm11
000077a0e99d2d78  jnz 0x000077A0E99D4367
000077a0e99d2d7e  vmovaps [rsp+0x10], xmm9
000077a0e99d2d84  vmovaps xmm1, [rsp+0x10]
000077a0e99d2d8a  por xmm9, xmm1
000077a0e99d2d8f  movaps [r15+0x180], xmm9
000077a0e99d2d97  vmovaps [rsp+0x10], xmm2
000077a0e99d2d9d  vmovaps xmm1, [rsp+0x10]
000077a0e99d2da3  por xmm2, xmm1
000077a0e99d2da7  movaps [r15+0x2D0], xmm2
000077a0e99d2daf  vmovaps xmm12, [rsp+0xD0]
000077a0e99d2db8  vpermilpd xmm12, xmm12, 0x00
000077a0e99d2dbe  vmovaps xmm11, [rsp+0x60]
000077a0e99d2dc4  movaps xmm5, xmm13
000077a0e99d2dc8  vfmadd231pd xmm5, xmm11, xmm12
000077a0e99d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
000077a0e99d2dd2  vptest xmm3, xmm3
000077a0e99d2dd7  jnz 0x000077A0E99D44BF
000077a0e99d2ddd  vmovaps xmm13, [rsp+0xD0]
000077a0e99d2de6  vpermilpd xmm13, xmm13, 0x00
000077a0e99d2dec  movaps xmm12, xmm14
000077a0e99d2df0  vfmadd231pd xmm12, xmm9, xmm13
000077a0e99d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
000077a0e99d2dfb  vptest xmm11, xmm11
000077a0e99d2e00  jnz 0x000077A0E99D4617
000077a0e99d2e06  lea rax, [r14+0x80]
000077a0e99d2e0d  movups xmm14, [r13+rax*1]
000077a0e99d2e13  movaps [r15+0x2F0], xmm14
000077a0e99d2e1b  vmovaps xmm13, [rsp+0xD0]
000077a0e99d2e24  vpermilpd xmm13, xmm13, 0x00
000077a0e99d2e2a  movaps xmm11, xmm10
000077a0e99d2e2e  vfmadd231pd xmm11, xmm8, xmm13
000077a0e99d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
000077a0e99d2e39  vptest xmm9, xmm9
000077a0e99d2e3e  jnz 0x000077A0E99D477B
000077a0e99d2e44  vmovaps xmm13, [rsp+0xD0]
000077a0e99d2e4d  vpermilpd xmm13, xmm13, 0x00
000077a0e99d2e53  movaps xmm10, xmm15
000077a0e99d2e57  vfmadd231pd xmm10, xmm1, xmm13
000077a0e99d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
000077a0e99d2e62  vptest xmm9, xmm9
000077a0e99d2e67  jnz 0x000077A0E99D48D5
000077a0e99d2e6d  vmovaps [rsp+0x10], xmm7
000077a0e99d2e73  vmovaps xmm1, [rsp+0x10]
000077a0e99d2e79  por xmm7, xmm1
000077a0e99d2e7d  movaps [r15+0x160], xmm7
000077a0e99d2e85  lea rax, [r14+0x40]
000077a0e99d2e89  movups xmm1, [r13+rax*1]
000077a0e99d2e8f  lea rax, [r14+0x50]
000077a0e99d2e93  movups xmm15, [r13+rax*1]
000077a0e99d2e99  movaps [r15+0x1B0], xmm1
000077a0e99d2ea1  movaps [r15+0x1A0], xmm15
000077a0e99d2ea9  vmovaps xmm13, [rsp+0xA0]
000077a0e99d2eb2  vpermilpd xmm13, xmm13, 0x00
000077a0e99d2eb8  vmovaps xmm9, [rsp+0x40]
000077a0e99d2ebe  movaps xmm8, xmm5
000077a0e99d2ec2  vfmadd231pd xmm8, xmm9, xmm13
000077a0e99d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
000077a0e99d2ecd  vptest xmm3, xmm3
000077a0e99d2ed2  jnz 0x000077A0E99D4A42
000077a0e99d2ed8  vmovaps xmm13, [rsp+0xA0]
000077a0e99d2ee1  vpermilpd xmm13, xmm13, 0x00
000077a0e99d2ee7  movaps xmm9, xmm12
000077a0e99d2eeb  vfmadd231pd xmm9, xmm7, xmm13
000077a0e99d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
000077a0e99d2ef6  vptest xmm5, xmm5
000077a0e99d2efb  jnz 0x000077A0E99D4B9B
000077a0e99d2f01  vmovaps xmm13, [rsp+0xA0]
000077a0e99d2f0a  vpermilpd xmm13, xmm13, 0x00
000077a0e99d2f10  movaps xmm12, xmm11
000077a0e99d2f14  vfmadd231pd xmm12, xmm6, xmm13
000077a0e99d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
000077a0e99d2f1f  vptest xmm7, xmm7
000077a0e99d2f24  jnz 0x000077A0E99D4CF4
000077a0e99d2f2a  vmovaps xmm13, [rsp+0xA0]
000077a0e99d2f33  vpermilpd xmm13, xmm13, 0x00
000077a0e99d2f39  vmovaps xmm11, [rsp+0x50]
000077a0e99d2f3f  movaps xmm7, xmm10
000077a0e99d2f43  vfmadd231pd xmm7, xmm11, xmm13
000077a0e99d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
000077a0e99d2f4d  vptest xmm6, xmm6
000077a0e99d2f52  jnz 0x000077A0E99D4E4D
000077a0e99d2f58  lea rax, [r14+0x60]
000077a0e99d2f5c  movups xmm13, [r13+rax*1]
000077a0e99d2f62  lea rax, [r14+0x70]
000077a0e99d2f66  movups xmm11, [r13+rax*1]
000077a0e99d2f6c  movaps [r15+0x150], xmm13
000077a0e99d2f74  movaps [r15+0x120], xmm11
000077a0e99d2f7c  vmovaps xmm10, [rsp+0xC0]
000077a0e99d2f85  vpermilpd xmm10, xmm10, 0x00
000077a0e99d2f8b  movaps xmm6, xmm8
000077a0e99d2f8f  vfmadd231pd xmm6, xmm15, xmm10
000077a0e99d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
000077a0e99d2f99  vptest xmm5, xmm5
000077a0e99d2f9e  jnz 0x000077A0E99D4FB9
000077a0e99d2fa4  vmovaps xmm15, [rsp+0xC0]
000077a0e99d2fad  vpermilpd xmm15, xmm15, 0x00
000077a0e99d2fb3  movaps xmm10, xmm9
000077a0e99d2fb7  vfmadd231pd xmm10, xmm13, xmm15
000077a0e99d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
000077a0e99d2fc2  vptest xmm8, xmm8
000077a0e99d2fc7  jnz 0x000077A0E99D5111
000077a0e99d2fcd  vmovaps xmm15, [rsp+0xC0]
000077a0e99d2fd6  vpermilpd xmm15, xmm15, 0x00
000077a0e99d2fdc  movaps xmm13, xmm12
000077a0e99d2fe0  vfmadd231pd xmm13, xmm4, xmm15
000077a0e99d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
000077a0e99d2feb  vptest xmm9, xmm9
000077a0e99d2ff0  jnz 0x000077A0E99D526B
000077a0e99d2ff6  vmovaps xmm15, [rsp+0xC0]
000077a0e99d2fff  vpermilpd xmm15, xmm15, 0x00
000077a0e99d3005  movaps xmm12, xmm7
000077a0e99d3009  vfmadd231pd xmm12, xmm1, xmm15
000077a0e99d300e  vcmppd xmm9, xmm12, xmm12, 0x03
000077a0e99d3014  vptest xmm9, xmm9
000077a0e99d3019  jnz 0x000077A0E99D53C4
000077a0e99d301f  lea rax, [r14+0x20]
000077a0e99d3023  movups xmm1, [r13+rax*1]
000077a0e99d3029  lea rax, [r14+0x30]
000077a0e99d302d  movups xmm15, [r13+rax*1]
000077a0e99d3033  vmovaps xmm9, [rsp+0x70]
000077a0e99d3039  vpermilpd xmm9, xmm9, 0x00
000077a0e99d303f  vmovaps xmm8, [rsp+0x20]
000077a0e99d3045  movaps xmm7, xmm6
000077a0e99d3048  vfmadd231pd xmm7, xmm8, xmm9
000077a0e99d304d  vcmppd xmm5, xmm7, xmm7, 0x03
000077a0e99d3052  vptest xmm5, xmm5
000077a0e99d3057  jnz 0x000077A0E99D5530
000077a0e99d305d  vmovaps xmm9, [rsp+0x70]
000077a0e99d3063  vpermilpd xmm9, xmm9, 0x00
000077a0e99d3069  movaps xmm8, xmm10
000077a0e99d306d  vfmadd231pd xmm8, xmm14, xmm9
000077a0e99d3072  vcmppd xmm6, xmm8, xmm8, 0x03
000077a0e99d3078  vptest xmm6, xmm6
000077a0e99d307d  jnz 0x000077A0E99D5687
000077a0e99d3083  vmovaps xmm14, [rsp+0x70]
000077a0e99d3089  vpermilpd xmm14, xmm14, 0x00
000077a0e99d308f  movaps xmm10, xmm13
000077a0e99d3093  vfmadd231pd xmm10, xmm11, xmm14
000077a0e99d3098  vcmppd xmm9, xmm10, xmm10, 0x03
000077a0e99d309e  vptest xmm9, xmm9
000077a0e99d30a3  jnz 0x000077A0E99D57E1
000077a0e99d30a9  vmovaps xmm14, [rsp+0x70]
000077a0e99d30af  vpermilpd xmm14, xmm14, 0x00
000077a0e99d30b5  movaps xmm13, xmm12
000077a0e99d30b9  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d30be  vcmppd xmm11, xmm13, xmm13, 0x03
000077a0e99d30c4  vptest xmm11, xmm11
000077a0e99d30c9  jnz 0x000077A0E99D593B
000077a0e99d30cf  lea rax, [r14+0x90]
000077a0e99d30d6  movups xmm15, [r13+rax*1]
000077a0e99d30dc  lea rax, [r14+0xA0]
000077a0e99d30e3  movups xmm14, [r13+rax*1]
000077a0e99d30e9  movaps [r15+0x140], xmm15
000077a0e99d30f1  movaps [r15+0x130], xmm14
000077a0e99d30f9  vmovaps xmm12, [rsp+0x90]
000077a0e99d3102  vpermilpd xmm12, xmm12, 0x00
000077a0e99d3108  movaps xmm11, xmm7
000077a0e99d310c  vfmadd231pd xmm11, xmm1, xmm12
000077a0e99d3111  vcmppd xmm9, xmm11, xmm11, 0x03
000077a0e99d3117  vptest xmm9, xmm9
000077a0e99d311c  jnz 0x000077A0E99D5AA9
000077a0e99d3122  movaps [r15+0x220], xmm11
000077a0e99d312a  lea rax, [r14+0x10]
000077a0e99d312e  movups xmm1, [r13+rax*1]
000077a0e99d3134  movaps [r15+0x240], xmm1
000077a0e99d313c  vmovaps xmm12, [rsp+0x90]
000077a0e99d3145  vpermilpd xmm12, xmm12, 0x00
000077a0e99d314b  movaps xmm9, xmm8
000077a0e99d314f  vfmadd231pd xmm9, xmm14, xmm12
000077a0e99d3154  vcmppd xmm7, xmm9, xmm9, 0x03
000077a0e99d315a  vptest xmm7, xmm7
000077a0e99d315f  jnz 0x000077A0E99D5C0B
000077a0e99d3165  movaps [r15+0x110], xmm9
000077a0e99d316d  vmovaps xmm14, [rsp+0x90]
000077a0e99d3176  vpermilpd xmm14, xmm14, 0x00
000077a0e99d317c  movaps xmm12, xmm10
000077a0e99d3180  vfmadd231pd xmm12, xmm15, xmm14
000077a0e99d3185  vcmppd xmm8, xmm12, xmm12, 0x03
000077a0e99d318b  vptest xmm8, xmm8
000077a0e99d3190  jnz 0x000077A0E99D5D65
000077a0e99d3196  movaps [r15+0x170], xmm12
000077a0e99d319e  vmovaps xmm15, [rsp+0x90]
000077a0e99d31a7  vpermilpd xmm15, xmm15, 0x00
000077a0e99d31ad  movaps xmm14, xmm13
000077a0e99d31b1  vfmadd231pd xmm14, xmm1, xmm15
000077a0e99d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
000077a0e99d31bc  vptest xmm10, xmm10
000077a0e99d31c1  jnz 0x000077A0E99D5EBF
000077a0e99d31c7  movaps [r15+0x230], xmm14
000077a0e99d31cf  mov eax, 0x432190
000077a0e99d31d4  movups [r13+rax*1], xmm9
000077a0e99d31da  mov eax, 0x4321A0
000077a0e99d31df  movups [r13+rax*1], xmm12
000077a0e99d31e5  mov eax, 0x4321B0
000077a0e99d31ea  movups [r13+rax*1], xmm11
000077a0e99d31f0  mov eax, 0x4321C0
000077a0e99d31f5  movups [r13+rax*1], xmm14
000077a0e99d31fb  mov eax, [r15+0x108]
000077a0e99d3202  sahf
000077a0e99d3203  jnz 0x000077A0E99D3235
000077a0e99d3205  cmp dword ptr [r15+0x318], 0x00
000077a0e99d320d  jz 0x000077A0E99D9950
000077a0e99d3213  nop [rax+rax*1], ax
000077a0e99d321c  nop [rax+rax*1], eax
000077a0e99d3224  mov eax, 0x410664
000077a0e99d3229  mov [r15+0x100], rax
000077a0e99d3230  jmp 0x000077A0E97FE110
000077a0e99d3235  cmp dword ptr [r15+0x318], 0x00
000077a0e99d323d  jz 0x000077A0E99D6050
000077a0e99d3243  nop [rax+rax*1], ax
000077a0e99d324c  nop [rax+rax*1], eax
000077a0e99d3254  mov eax, 0x4104F0
000077a0e99d3259  mov [r15+0x100], rax
000077a0e99d3260  jmp 0x000077A0E97FE110
000077a0e99d3265  int3
000077a0e99d3266  call 0x000077A0E97FF430
000077a0e99d326b  jmp 0x000077A0E99D230A
000077a0e99d3270  call 0x000077A0E98E5820
000077a0e99d3275  jmp 0x000077A0E99D2314
000077a0e99d327a  call 0x000077A0E98E45A0
000077a0e99d327f  jmp 0x000077A0E99D2326
000077a0e99d3284  call 0x000077A0E98E3320
000077a0e99d3289  jmp 0x000077A0E99D2330
000077a0e99d328e  call 0x000077A0E98E20A0
000077a0e99d3293  jmp 0x000077A0E99D233D
000077a0e99d3298  call 0x000077A0E98E0E30
000077a0e99d329d  jmp 0x000077A0E99D234A
000077a0e99d32a2  call 0x000077A0E98D6600
000077a0e99d32a7  jmp 0x000077A0E99D2357
000077a0e99d32ac  call 0x000077A0E98B52F0
000077a0e99d32b1  jmp 0x000077A0E99D2361
000077a0e99d32b6  call 0x000077A0E98BE9C0
000077a0e99d32bb  jmp 0x000077A0E99D236B
000077a0e99d32c0  call 0x000077A0E98BD750
000077a0e99d32c5  jmp 0x000077A0E99D2378
000077a0e99d32ca  call 0x000077A0E98BC4E0
000077a0e99d32cf  jmp 0x000077A0E99D2385
000077a0e99d32d4  call 0x000077A0E98BB270
000077a0e99d32d9  jmp 0x000077A0E99D2392
000077a0e99d32de  call 0x000077A0E98BA000
000077a0e99d32e3  jmp 0x000077A0E99D239F
000077a0e99d32e8  call 0x000077A0E98B8D90
000077a0e99d32ed  jmp 0x000077A0E99D23AC
000077a0e99d32f2  call 0x000077A0E98B8A20
000077a0e99d32f7  jmp 0x000077A0E99D23B9
000077a0e99d32fc  call 0x000077A0E98BEAE0
000077a0e99d3301  jmp 0x000077A0E99D23C6
000077a0e99d3306  call 0x000077A0E98B5400
000077a0e99d330b  jmp 0x000077A0E99D23D3
000077a0e99d3310  call 0x000077A0E98B52F0
000077a0e99d3315  jmp 0x000077A0E99D23E0
000077a0e99d331a  call 0x000077A0E98BE9C0
000077a0e99d331f  jmp 0x000077A0E99D23ED
000077a0e99d3324  call 0x000077A0E98B77B0
000077a0e99d3329  jmp 0x000077A0E99D23FA
000077a0e99d332e  call 0x000077A0E98B6550
000077a0e99d3333  jmp 0x000077A0E99D2407
000077a0e99d3338  call 0x000077A0E98B52F0
000077a0e99d333d  jmp 0x000077A0E99D2417
000077a0e99d3342  call 0x000077A0E98B52F0
000077a0e99d3347  jmp 0x000077A0E99D2427
000077a0e99d334c  call 0x000077A0E98BEAE0
000077a0e99d3351  jmp 0x000077A0E99D2431
000077a0e99d3356  call 0x000077A0E98BEAE0
000077a0e99d335b  jmp 0x000077A0E99D2444
000077a0e99d3360  call 0x000077A0E98BE9C0
000077a0e99d3365  jmp 0x000077A0E99D2451
000077a0e99d336a  call 0x000077A0E98B52F0
000077a0e99d336f  jmp 0x000077A0E99D2464
000077a0e99d3374  call 0x000077A0E98B6660
000077a0e99d3379  jmp 0x000077A0E99D2471
000077a0e99d337e  call 0x000077A0E98B78C0
000077a0e99d3383  jmp 0x000077A0E99D247E
000077a0e99d3388  call 0x000077A0E98B77B0
000077a0e99d338d  jmp 0x000077A0E99D248B
000077a0e99d3392  call 0x000077A0E98B6550
000077a0e99d3397  jmp 0x000077A0E99D2498
000077a0e99d339c  call 0x000077A0E98B52F0
000077a0e99d33a1  jmp 0x000077A0E99D24AB
000077a0e99d33a6  call 0x000077A0E98B52F0
000077a0e99d33ab  jmp 0x000077A0E99D24BE
000077a0e99d33b0  call 0x000077A0E98B52F0
000077a0e99d33b5  jmp 0x000077A0E99D24E5
000077a0e99d33ba  call 0x000077A0E98B52F0
000077a0e99d33bf  jmp 0x000077A0E99D24F8
000077a0e99d33c4  call 0x000077A0E98B52F0
000077a0e99d33c9  jmp 0x000077A0E99D250B
000077a0e99d33ce  call 0x000077A0E98B52F0
000077a0e99d33d3  jmp 0x000077A0E99D2521
000077a0e99d33d8  call 0x000077A0E98B52F0
000077a0e99d33dd  jmp 0x000077A0E99D2537
000077a0e99d33e2  call 0x000077A0E98B52F0
000077a0e99d33e7  jmp 0x000077A0E99D254D
000077a0e99d33ec  call 0x000077A0E97FF540
000077a0e99d33f1  jmp 0x000077A0E99D256E
000077a0e99d33f6  call 0x000077A0E9802FE0
000077a0e99d33fb  jmp 0x000077A0E99D2578
000077a0e99d3400  call 0x000077A0E97FF540
000077a0e99d3405  jmp 0x000077A0E99D2588
000077a0e99d340a  call 0x000077A0E97FF540
000077a0e99d340f  jmp 0x000077A0E99D259B
000077a0e99d3414  call 0x000077A0E97FF540
000077a0e99d3419  jmp 0x000077A0E99D25AE
000077a0e99d341e  call 0x000077A0E97FF540
000077a0e99d3423  jmp 0x000077A0E99D25C1
000077a0e99d3428  call 0x000077A0E98C0370
000077a0e99d342d  jmp 0x000077A0E99D25E0
000077a0e99d3432  call 0x000077A0E98BF100
000077a0e99d3437  jmp 0x000077A0E99D25E9
000077a0e99d343c  call 0x000077A0E98C0370
000077a0e99d3441  jmp 0x000077A0E99D2659
000077a0e99d3446  call 0x000077A0E98BF100
000077a0e99d344b  jmp 0x000077A0E99D2662
000077a0e99d3450  call 0x000077A0E98C0370
000077a0e99d3455  jmp 0x000077A0E99D270C
000077a0e99d345a  call 0x000077A0E98BF100
000077a0e99d345f  jmp 0x000077A0E99D2715
000077a0e99d3464  call 0x000077A0E980B720
000077a0e99d3469  jmp 0x000077A0E99D27F7
000077a0e99d346e  call 0x000077A0E98D64F0
000077a0e99d3473  jmp 0x000077A0E99D281F
000077a0e99d3478  call 0x000077A0E98B47C0
000077a0e99d347d  jmp 0x000077A0E99D283A
000077a0e99d3482  sub rsp, 0x08
000077a0e99d3486  push rax
000077a0e99d3487  push rcx
000077a0e99d3488  push rdx
000077a0e99d3489  push rdi
000077a0e99d348a  push rsi
000077a0e99d348b  push r8
000077a0e99d348d  push r9
000077a0e99d348f  push r10
000077a0e99d3491  push r11
000077a0e99d3493  sub rsp, 0xF0
000077a0e99d349a  vmovaps [rsp], xmm0
000077a0e99d349f  vmovaps [rsp+0x10], xmm1
000077a0e99d34a5  vmovaps [rsp+0x20], xmm2
000077a0e99d34ab  vmovaps [rsp+0x30], xmm3
000077a0e99d34b1  vmovaps [rsp+0x40], xmm4
000077a0e99d34b7  vmovaps [rsp+0x50], xmm5
000077a0e99d34bd  vmovaps [rsp+0x60], xmm6
000077a0e99d34c3  vmovaps [rsp+0x70], xmm7
000077a0e99d34c9  vmovaps [rsp+0x80], xmm8
000077a0e99d34d2  vmovaps [rsp+0x90], xmm9
000077a0e99d34db  vmovaps [rsp+0xA0], xmm10
000077a0e99d34e4  vmovaps [rsp+0xB0], xmm11
000077a0e99d34ed  vmovaps [rsp+0xC0], xmm12
000077a0e99d34f6  vmovaps [rsp+0xD0], xmm14
000077a0e99d34ff  vmovaps [rsp+0xE0], xmm15
000077a0e99d3508  sub rsp, 0x40
000077a0e99d350c  lea rdi, [rsp]
000077a0e99d3510  lea rsi, [rsp+0x10]
000077a0e99d3515  lea rdx, [rsp+0x20]
000077a0e99d351a  lea rcx, [rsp+0x30]
000077a0e99d351f  mov r8d, 0x00
000077a0e99d3525  lea r9, [r15+0x3A8]
000077a0e99d352c  movaps [rdi], xmm13
000077a0e99d3530  movaps [rsi], xmm1
000077a0e99d3533  movaps [rdx], xmm15
000077a0e99d3537  movaps [rcx], xmm14
000077a0e99d353b  mov rax, 0x60CAA235BA50
000077a0e99d3545  call rax
000077a0e99d3547  movaps xmm13, [rsp]
000077a0e99d354c  add rsp, 0x40
000077a0e99d3550  vmovaps xmm0, [rsp]
000077a0e99d3555  vmovaps xmm1, [rsp+0x10]
000077a0e99d355b  vmovaps xmm2, [rsp+0x20]
000077a0e99d3561  vmovaps xmm3, [rsp+0x30]
000077a0e99d3567  vmovaps xmm4, [rsp+0x40]
000077a0e99d356d  vmovaps xmm5, [rsp+0x50]
000077a0e99d3573  vmovaps xmm6, [rsp+0x60]
000077a0e99d3579  vmovaps xmm7, [rsp+0x70]
000077a0e99d357f  vmovaps xmm8, [rsp+0x80]
000077a0e99d3588  vmovaps xmm9, [rsp+0x90]
000077a0e99d3591  vmovaps xmm10, [rsp+0xA0]
000077a0e99d359a  vmovaps xmm11, [rsp+0xB0]
000077a0e99d35a3  vmovaps xmm12, [rsp+0xC0]
000077a0e99d35ac  vmovaps xmm14, [rsp+0xD0]
000077a0e99d35b5  vmovaps xmm15, [rsp+0xE0]
000077a0e99d35be  add rsp, 0xF0
000077a0e99d35c5  pop r11
000077a0e99d35c7  pop r10
000077a0e99d35c9  pop r9
000077a0e99d35cb  pop r8
000077a0e99d35cd  pop rsi
000077a0e99d35ce  pop rdi
000077a0e99d35cf  pop rdx
000077a0e99d35d0  pop rcx
000077a0e99d35d1  pop rax
000077a0e99d35d2  add rsp, 0x08
000077a0e99d35d6  jmp 0x000077A0E99D28AD
000077a0e99d35db  sub rsp, 0x08
000077a0e99d35df  push rax
000077a0e99d35e0  push rcx
000077a0e99d35e1  push rdx
000077a0e99d35e2  push rdi
000077a0e99d35e3  push rsi
000077a0e99d35e4  push r8
000077a0e99d35e6  push r9
000077a0e99d35e8  push r10
000077a0e99d35ea  push r11
000077a0e99d35ec  sub rsp, 0xF0
000077a0e99d35f3  vmovaps [rsp], xmm0
000077a0e99d35f8  vmovaps [rsp+0x10], xmm1
000077a0e99d35fe  vmovaps [rsp+0x20], xmm2
000077a0e99d3604  vmovaps [rsp+0x30], xmm3
000077a0e99d360a  vmovaps [rsp+0x40], xmm4
000077a0e99d3610  vmovaps [rsp+0x50], xmm5
000077a0e99d3616  vmovaps [rsp+0x60], xmm6
000077a0e99d361c  vmovaps [rsp+0x70], xmm7
000077a0e99d3622  vmovaps [rsp+0x80], xmm8
000077a0e99d362b  vmovaps [rsp+0x90], xmm9
000077a0e99d3634  vmovaps [rsp+0xA0], xmm10
000077a0e99d363d  vmovaps [rsp+0xB0], xmm11
000077a0e99d3646  vmovaps [rsp+0xC0], xmm12
000077a0e99d364f  vmovaps [rsp+0xD0], xmm13
000077a0e99d3658  vmovaps [rsp+0xE0], xmm14
000077a0e99d3661  sub rsp, 0x40
000077a0e99d3665  lea rdi, [rsp]
000077a0e99d3669  lea rsi, [rsp+0x10]
000077a0e99d366e  lea rdx, [rsp+0x20]
000077a0e99d3673  lea rcx, [rsp+0x30]
000077a0e99d3678  mov r8d, 0x00
000077a0e99d367e  lea r9, [r15+0x3A8]
000077a0e99d3685  movaps [rdi], xmm15
000077a0e99d3689  movaps [rsi], xmm5
000077a0e99d368c  movaps [rdx], xmm1
000077a0e99d368f  movaps [rcx], xmm14
000077a0e99d3693  mov rax, 0x60CAA235BA50
000077a0e99d369d  call rax
000077a0e99d369f  movaps xmm15, [rsp]
000077a0e99d36a4  add rsp, 0x40
000077a0e99d36a8  vmovaps xmm0, [rsp]
000077a0e99d36ad  vmovaps xmm1, [rsp+0x10]
000077a0e99d36b3  vmovaps xmm2, [rsp+0x20]
000077a0e99d36b9  vmovaps xmm3, [rsp+0x30]
000077a0e99d36bf  vmovaps xmm4, [rsp+0x40]
000077a0e99d36c5  vmovaps xmm5, [rsp+0x50]
000077a0e99d36cb  vmovaps xmm6, [rsp+0x60]
000077a0e99d36d1  vmovaps xmm7, [rsp+0x70]
000077a0e99d36d7  vmovaps xmm8, [rsp+0x80]
000077a0e99d36e0  vmovaps xmm9, [rsp+0x90]
000077a0e99d36e9  vmovaps xmm10, [rsp+0xA0]
000077a0e99d36f2  vmovaps xmm11, [rsp+0xB0]
000077a0e99d36fb  vmovaps xmm12, [rsp+0xC0]
000077a0e99d3704  vmovaps xmm13, [rsp+0xD0]
000077a0e99d370d  vmovaps xmm14, [rsp+0xE0]
000077a0e99d3716  add rsp, 0xF0
000077a0e99d371d  pop r11
000077a0e99d371f  pop r10
000077a0e99d3721  pop r9
000077a0e99d3723  pop r8
000077a0e99d3725  pop rsi
000077a0e99d3726  pop rdi
000077a0e99d3727  pop rdx
000077a0e99d3728  pop rcx
000077a0e99d3729  pop rax
000077a0e99d372a  add rsp, 0x08
000077a0e99d372e  jmp 0x000077A0E99D28D0
000077a0e99d3733  call 0x000077A0E97FF430
000077a0e99d3738  jmp 0x000077A0E99D295D
000077a0e99d373d  sub rsp, 0x08
000077a0e99d3741  push rax
000077a0e99d3742  push rcx
000077a0e99d3743  push rdx
000077a0e99d3744  push rdi
000077a0e99d3745  push rsi
000077a0e99d3746  push r8
000077a0e99d3748  push r9
000077a0e99d374a  push r10
000077a0e99d374c  push r11
000077a0e99d374e  sub rsp, 0xF0
000077a0e99d3755  vmovaps [rsp], xmm0
000077a0e99d375a  vmovaps [rsp+0x10], xmm1
000077a0e99d3760  vmovaps [rsp+0x20], xmm2
000077a0e99d3766  vmovaps [rsp+0x30], xmm3
000077a0e99d376c  vmovaps [rsp+0x40], xmm4
000077a0e99d3772  vmovaps [rsp+0x50], xmm5
000077a0e99d3778  vmovaps [rsp+0x60], xmm6
000077a0e99d377e  vmovaps [rsp+0x70], xmm7
000077a0e99d3784  vmovaps [rsp+0x80], xmm8
000077a0e99d378d  vmovaps [rsp+0x90], xmm9
000077a0e99d3796  vmovaps [rsp+0xA0], xmm10
000077a0e99d379f  vmovaps [rsp+0xB0], xmm11
000077a0e99d37a8  vmovaps [rsp+0xC0], xmm12
000077a0e99d37b1  vmovaps [rsp+0xD0], xmm14
000077a0e99d37ba  vmovaps [rsp+0xE0], xmm15
000077a0e99d37c3  sub rsp, 0x40
000077a0e99d37c7  lea rdi, [rsp]
000077a0e99d37cb  lea rsi, [rsp+0x10]
000077a0e99d37d0  lea rdx, [rsp+0x20]
000077a0e99d37d5  lea rcx, [rsp+0x30]
000077a0e99d37da  mov r8d, 0x00
000077a0e99d37e0  lea r9, [r15+0x3A8]
000077a0e99d37e7  movaps [rdi], xmm13
000077a0e99d37eb  movaps [rsi], xmm1
000077a0e99d37ee  movaps [rdx], xmm15
000077a0e99d37f2  movaps [rcx], xmm14
000077a0e99d37f6  mov rax, 0x60CAA235BA50
000077a0e99d3800  call rax
000077a0e99d3802  movaps xmm13, [rsp]
000077a0e99d3807  add rsp, 0x40
000077a0e99d380b  vmovaps xmm0, [rsp]
000077a0e99d3810  vmovaps xmm1, [rsp+0x10]
000077a0e99d3816  vmovaps xmm2, [rsp+0x20]
000077a0e99d381c  vmovaps xmm3, [rsp+0x30]
000077a0e99d3822  vmovaps xmm4, [rsp+0x40]
000077a0e99d3828  vmovaps xmm5, [rsp+0x50]
000077a0e99d382e  vmovaps xmm6, [rsp+0x60]
000077a0e99d3834  vmovaps xmm7, [rsp+0x70]
000077a0e99d383a  vmovaps xmm8, [rsp+0x80]
000077a0e99d3843  vmovaps xmm9, [rsp+0x90]
000077a0e99d384c  vmovaps xmm10, [rsp+0xA0]
000077a0e99d3855  vmovaps xmm11, [rsp+0xB0]
000077a0e99d385e  vmovaps xmm12, [rsp+0xC0]
000077a0e99d3867  vmovaps xmm14, [rsp+0xD0]
000077a0e99d3870  vmovaps xmm15, [rsp+0xE0]
000077a0e99d3879  add rsp, 0xF0
000077a0e99d3880  pop r11
000077a0e99d3882  pop r10
000077a0e99d3884  pop r9
000077a0e99d3886  pop r8
000077a0e99d3888  pop rsi
000077a0e99d3889  pop rdi
000077a0e99d388a  pop rdx
000077a0e99d388b  pop rcx
000077a0e99d388c  pop rax
000077a0e99d388d  add rsp, 0x08
000077a0e99d3891  jmp 0x000077A0E99D29C1
000077a0e99d3896  call 0x000077A0E97FF430
000077a0e99d389b  jmp 0x000077A0E99D29CE
000077a0e99d38a0  sub rsp, 0x08
000077a0e99d38a4  push rax
000077a0e99d38a5  push rcx
000077a0e99d38a6  push rdx
000077a0e99d38a7  push rdi
000077a0e99d38a8  push rsi
000077a0e99d38a9  push r8
000077a0e99d38ab  push r9
000077a0e99d38ad  push r10
000077a0e99d38af  push r11
000077a0e99d38b1  sub rsp, 0xF0
000077a0e99d38b8  vmovaps [rsp], xmm0
000077a0e99d38bd  vmovaps [rsp+0x10], xmm1
000077a0e99d38c3  vmovaps [rsp+0x20], xmm2
000077a0e99d38c9  vmovaps [rsp+0x30], xmm3
000077a0e99d38cf  vmovaps [rsp+0x40], xmm4
000077a0e99d38d5  vmovaps [rsp+0x50], xmm5
000077a0e99d38db  vmovaps [rsp+0x60], xmm6
000077a0e99d38e1  vmovaps [rsp+0x70], xmm7
000077a0e99d38e7  vmovaps [rsp+0x80], xmm8
000077a0e99d38f0  vmovaps [rsp+0x90], xmm9
000077a0e99d38f9  vmovaps [rsp+0xA0], xmm10
000077a0e99d3902  vmovaps [rsp+0xB0], xmm11
000077a0e99d390b  vmovaps [rsp+0xC0], xmm13
000077a0e99d3914  vmovaps [rsp+0xD0], xmm14
000077a0e99d391d  vmovaps [rsp+0xE0], xmm15
000077a0e99d3926  sub rsp, 0x40
000077a0e99d392a  lea rdi, [rsp]
000077a0e99d392e  lea rsi, [rsp+0x10]
000077a0e99d3933  lea rdx, [rsp+0x20]
000077a0e99d3938  lea rcx, [rsp+0x30]
000077a0e99d393d  mov r8d, 0x00
000077a0e99d3943  lea r9, [r15+0x3A8]
000077a0e99d394a  movaps [rdi], xmm12
000077a0e99d394e  movaps [rsi], xmm15
000077a0e99d3952  movaps [rdx], xmm1
000077a0e99d3955  movaps [rcx], xmm14
000077a0e99d3959  mov rax, 0x60CAA235BA50
000077a0e99d3963  call rax
000077a0e99d3965  movaps xmm12, [rsp]
000077a0e99d396a  add rsp, 0x40
000077a0e99d396e  vmovaps xmm0, [rsp]
000077a0e99d3973  vmovaps xmm1, [rsp+0x10]
000077a0e99d3979  vmovaps xmm2, [rsp+0x20]
000077a0e99d397f  vmovaps xmm3, [rsp+0x30]
000077a0e99d3985  vmovaps xmm4, [rsp+0x40]
000077a0e99d398b  vmovaps xmm5, [rsp+0x50]
000077a0e99d3991  vmovaps xmm6, [rsp+0x60]
000077a0e99d3997  vmovaps xmm7, [rsp+0x70]
000077a0e99d399d  vmovaps xmm8, [rsp+0x80]
000077a0e99d39a6  vmovaps xmm9, [rsp+0x90]
000077a0e99d39af  vmovaps xmm10, [rsp+0xA0]
000077a0e99d39b8  vmovaps xmm11, [rsp+0xB0]
000077a0e99d39c1  vmovaps xmm13, [rsp+0xC0]
000077a0e99d39ca  vmovaps xmm14, [rsp+0xD0]
000077a0e99d39d3  vmovaps xmm15, [rsp+0xE0]
000077a0e99d39dc  add rsp, 0xF0
000077a0e99d39e3  pop r11
000077a0e99d39e5  pop r10
000077a0e99d39e7  pop r9
000077a0e99d39e9  pop r8
000077a0e99d39eb  pop rsi
000077a0e99d39ec  pop rdi
000077a0e99d39ed  pop rdx
000077a0e99d39ee  pop rcx
000077a0e99d39ef  pop rax
000077a0e99d39f0  add rsp, 0x08
000077a0e99d39f4  jmp 0x000077A0E99D29FA
000077a0e99d39f9  sub rsp, 0x08
000077a0e99d39fd  push rax
000077a0e99d39fe  push rcx
000077a0e99d39ff  push rdx
000077a0e99d3a00  push rdi
000077a0e99d3a01  push rsi
000077a0e99d3a02  push r8
000077a0e99d3a04  push r9
000077a0e99d3a06  push r10
000077a0e99d3a08  push r11
000077a0e99d3a0a  sub rsp, 0xF0
000077a0e99d3a11  vmovaps [rsp], xmm0
000077a0e99d3a16  vmovaps [rsp+0x10], xmm1
000077a0e99d3a1c  vmovaps [rsp+0x20], xmm2
000077a0e99d3a22  vmovaps [rsp+0x30], xmm3
000077a0e99d3a28  vmovaps [rsp+0x40], xmm4
000077a0e99d3a2e  vmovaps [rsp+0x50], xmm5
000077a0e99d3a34  vmovaps [rsp+0x60], xmm6
000077a0e99d3a3a  vmovaps [rsp+0x70], xmm7
000077a0e99d3a40  vmovaps [rsp+0x80], xmm8
000077a0e99d3a49  vmovaps [rsp+0x90], xmm9
000077a0e99d3a52  vmovaps [rsp+0xA0], xmm10
000077a0e99d3a5b  vmovaps [rsp+0xB0], xmm11
000077a0e99d3a64  vmovaps [rsp+0xC0], xmm12
000077a0e99d3a6d  vmovaps [rsp+0xD0], xmm14
000077a0e99d3a76  vmovaps [rsp+0xE0], xmm15
000077a0e99d3a7f  sub rsp, 0x40
000077a0e99d3a83  lea rdi, [rsp]
000077a0e99d3a87  lea rsi, [rsp+0x10]
000077a0e99d3a8c  lea rdx, [rsp+0x20]
000077a0e99d3a91  lea rcx, [rsp+0x30]
000077a0e99d3a96  mov r8d, 0x00
000077a0e99d3a9c  lea r9, [r15+0x3A8]
000077a0e99d3aa3  movaps [rdi], xmm13
000077a0e99d3aa7  movaps [rsi], xmm1
000077a0e99d3aaa  movaps [rdx], xmm15
000077a0e99d3aae  movaps [rcx], xmm14
000077a0e99d3ab2  mov rax, 0x60CAA235BA50
000077a0e99d3abc  call rax
000077a0e99d3abe  movaps xmm13, [rsp]
000077a0e99d3ac3  add rsp, 0x40
000077a0e99d3ac7  vmovaps xmm0, [rsp]
000077a0e99d3acc  vmovaps xmm1, [rsp+0x10]
000077a0e99d3ad2  vmovaps xmm2, [rsp+0x20]
000077a0e99d3ad8  vmovaps xmm3, [rsp+0x30]
000077a0e99d3ade  vmovaps xmm4, [rsp+0x40]
000077a0e99d3ae4  vmovaps xmm5, [rsp+0x50]
000077a0e99d3aea  vmovaps xmm6, [rsp+0x60]
000077a0e99d3af0  vmovaps xmm7, [rsp+0x70]
000077a0e99d3af6  vmovaps xmm8, [rsp+0x80]
000077a0e99d3aff  vmovaps xmm9, [rsp+0x90]
000077a0e99d3b08  vmovaps xmm10, [rsp+0xA0]
000077a0e99d3b11  vmovaps xmm11, [rsp+0xB0]
000077a0e99d3b1a  vmovaps xmm12, [rsp+0xC0]
000077a0e99d3b23  vmovaps xmm14, [rsp+0xD0]
000077a0e99d3b2c  vmovaps xmm15, [rsp+0xE0]
000077a0e99d3b35  add rsp, 0xF0
000077a0e99d3b3c  pop r11
000077a0e99d3b3e  pop r10
000077a0e99d3b40  pop r9
000077a0e99d3b42  pop r8
000077a0e99d3b44  pop rsi
000077a0e99d3b45  pop rdi
000077a0e99d3b46  pop rdx
000077a0e99d3b47  pop rcx
000077a0e99d3b48  pop rax
000077a0e99d3b49  add rsp, 0x08
000077a0e99d3b4d  jmp 0x000077A0E99D2B77
000077a0e99d3b52  sub rsp, 0x08
000077a0e99d3b56  push rax
000077a0e99d3b57  push rcx
000077a0e99d3b58  push rdx
000077a0e99d3b59  push rdi
000077a0e99d3b5a  push rsi
000077a0e99d3b5b  push r8
000077a0e99d3b5d  push r9
000077a0e99d3b5f  push r10
000077a0e99d3b61  push r11
000077a0e99d3b63  sub rsp, 0xF0
000077a0e99d3b6a  vmovaps [rsp], xmm0
000077a0e99d3b6f  vmovaps [rsp+0x10], xmm1
000077a0e99d3b75  vmovaps [rsp+0x20], xmm2
000077a0e99d3b7b  vmovaps [rsp+0x30], xmm3
000077a0e99d3b81  vmovaps [rsp+0x40], xmm4
000077a0e99d3b87  vmovaps [rsp+0x50], xmm5
000077a0e99d3b8d  vmovaps [rsp+0x60], xmm6
000077a0e99d3b93  vmovaps [rsp+0x70], xmm7
000077a0e99d3b99  vmovaps [rsp+0x80], xmm8
000077a0e99d3ba2  vmovaps [rsp+0x90], xmm9
000077a0e99d3bab  vmovaps [rsp+0xA0], xmm10
000077a0e99d3bb4  vmovaps [rsp+0xB0], xmm11
000077a0e99d3bbd  vmovaps [rsp+0xC0], xmm13
000077a0e99d3bc6  vmovaps [rsp+0xD0], xmm14
000077a0e99d3bcf  vmovaps [rsp+0xE0], xmm15
000077a0e99d3bd8  sub rsp, 0x40
000077a0e99d3bdc  lea rdi, [rsp]
000077a0e99d3be0  lea rsi, [rsp+0x10]
000077a0e99d3be5  lea rdx, [rsp+0x20]
000077a0e99d3bea  lea rcx, [rsp+0x30]
000077a0e99d3bef  mov r8d, 0x00
000077a0e99d3bf5  lea r9, [r15+0x3A8]
000077a0e99d3bfc  movaps [rdi], xmm12
000077a0e99d3c00  movaps [rsi], xmm15
000077a0e99d3c04  movaps [rdx], xmm14
000077a0e99d3c08  movaps [rcx], xmm1
000077a0e99d3c0b  mov rax, 0x60CAA235BA50
000077a0e99d3c15  call rax
000077a0e99d3c17  movaps xmm12, [rsp]
000077a0e99d3c1c  add rsp, 0x40
000077a0e99d3c20  vmovaps xmm0, [rsp]
000077a0e99d3c25  vmovaps xmm1, [rsp+0x10]
000077a0e99d3c2b  vmovaps xmm2, [rsp+0x20]
000077a0e99d3c31  vmovaps xmm3, [rsp+0x30]
000077a0e99d3c37  vmovaps xmm4, [rsp+0x40]
000077a0e99d3c3d  vmovaps xmm5, [rsp+0x50]
000077a0e99d3c43  vmovaps xmm6, [rsp+0x60]
000077a0e99d3c49  vmovaps xmm7, [rsp+0x70]
000077a0e99d3c4f  vmovaps xmm8, [rsp+0x80]
000077a0e99d3c58  vmovaps xmm9, [rsp+0x90]
000077a0e99d3c61  vmovaps xmm10, [rsp+0xA0]
000077a0e99d3c6a  vmovaps xmm11, [rsp+0xB0]
000077a0e99d3c73  vmovaps xmm13, [rsp+0xC0]
000077a0e99d3c7c  vmovaps xmm14, [rsp+0xD0]
000077a0e99d3c85  vmovaps xmm15, [rsp+0xE0]
000077a0e99d3c8e  add rsp, 0xF0
000077a0e99d3c95  pop r11
000077a0e99d3c97  pop r10
000077a0e99d3c99  pop r9
000077a0e99d3c9b  pop r8
000077a0e99d3c9d  pop rsi
000077a0e99d3c9e  pop rdi
000077a0e99d3c9f  pop rdx
000077a0e99d3ca0  pop rcx
000077a0e99d3ca1  pop rax
000077a0e99d3ca2  add rsp, 0x08
000077a0e99d3ca6  jmp 0x000077A0E99D2BB2
000077a0e99d3cab  sub rsp, 0x08
000077a0e99d3caf  push rax
000077a0e99d3cb0  push rcx
000077a0e99d3cb1  push rdx
000077a0e99d3cb2  push rdi
000077a0e99d3cb3  push rsi
000077a0e99d3cb4  push r8
000077a0e99d3cb6  push r9
000077a0e99d3cb8  push r10
000077a0e99d3cba  push r11
000077a0e99d3cbc  sub rsp, 0xF0
000077a0e99d3cc3  vmovaps [rsp], xmm0
000077a0e99d3cc8  vmovaps [rsp+0x10], xmm1
000077a0e99d3cce  vmovaps [rsp+0x20], xmm2
000077a0e99d3cd4  vmovaps [rsp+0x30], xmm3
000077a0e99d3cda  vmovaps [rsp+0x40], xmm4
000077a0e99d3ce0  vmovaps [rsp+0x50], xmm5
000077a0e99d3ce6  vmovaps [rsp+0x60], xmm6
000077a0e99d3cec  vmovaps [rsp+0x70], xmm7
000077a0e99d3cf2  vmovaps [rsp+0x80], xmm8
000077a0e99d3cfb  vmovaps [rsp+0x90], xmm9
000077a0e99d3d04  vmovaps [rsp+0xA0], xmm10
000077a0e99d3d0d  vmovaps [rsp+0xB0], xmm11
000077a0e99d3d16  vmovaps [rsp+0xC0], xmm12
000077a0e99d3d1f  vmovaps [rsp+0xD0], xmm14
000077a0e99d3d28  vmovaps [rsp+0xE0], xmm15
000077a0e99d3d31  sub rsp, 0x40
000077a0e99d3d35  lea rdi, [rsp]
000077a0e99d3d39  lea rsi, [rsp+0x10]
000077a0e99d3d3e  lea rdx, [rsp+0x20]
000077a0e99d3d43  lea rcx, [rsp+0x30]
000077a0e99d3d48  mov r8d, 0x00
000077a0e99d3d4e  lea r9, [r15+0x3A8]
000077a0e99d3d55  movaps [rdi], xmm13
000077a0e99d3d59  movaps [rsi], xmm15
000077a0e99d3d5d  movaps [rdx], xmm14
000077a0e99d3d61  movaps [rcx], xmm1
000077a0e99d3d64  mov rax, 0x60CAA235BA50
000077a0e99d3d6e  call rax
000077a0e99d3d70  movaps xmm13, [rsp]
000077a0e99d3d75  add rsp, 0x40
000077a0e99d3d79  vmovaps xmm0, [rsp]
000077a0e99d3d7e  vmovaps xmm1, [rsp+0x10]
000077a0e99d3d84  vmovaps xmm2, [rsp+0x20]
000077a0e99d3d8a  vmovaps xmm3, [rsp+0x30]
000077a0e99d3d90  vmovaps xmm4, [rsp+0x40]
000077a0e99d3d96  vmovaps xmm5, [rsp+0x50]
000077a0e99d3d9c  vmovaps xmm6, [rsp+0x60]
000077a0e99d3da2  vmovaps xmm7, [rsp+0x70]
000077a0e99d3da8  vmovaps xmm8, [rsp+0x80]
000077a0e99d3db1  vmovaps xmm9, [rsp+0x90]
000077a0e99d3dba  vmovaps xmm10, [rsp+0xA0]
000077a0e99d3dc3  vmovaps xmm11, [rsp+0xB0]
000077a0e99d3dcc  vmovaps xmm12, [rsp+0xC0]
000077a0e99d3dd5  vmovaps xmm14, [rsp+0xD0]
000077a0e99d3dde  vmovaps xmm15, [rsp+0xE0]
000077a0e99d3de7  add rsp, 0xF0
000077a0e99d3dee  pop r11
000077a0e99d3df0  pop r10
000077a0e99d3df2  pop r9
000077a0e99d3df4  pop r8
000077a0e99d3df6  pop rsi
000077a0e99d3df7  pop rdi
000077a0e99d3df8  pop rdx
000077a0e99d3df9  pop rcx
000077a0e99d3dfa  pop rax
000077a0e99d3dfb  add rsp, 0x08
000077a0e99d3dff  jmp 0x000077A0E99D2BEA
000077a0e99d3e04  sub rsp, 0x08
000077a0e99d3e08  push rax
000077a0e99d3e09  push rcx
000077a0e99d3e0a  push rdx
000077a0e99d3e0b  push rdi
000077a0e99d3e0c  push rsi
000077a0e99d3e0d  push r8
000077a0e99d3e0f  push r9
000077a0e99d3e11  push r10
000077a0e99d3e13  push r11
000077a0e99d3e15  sub rsp, 0xF0
000077a0e99d3e1c  vmovaps [rsp], xmm0
000077a0e99d3e21  vmovaps [rsp+0x10], xmm1
000077a0e99d3e27  vmovaps [rsp+0x20], xmm2
000077a0e99d3e2d  vmovaps [rsp+0x30], xmm3
000077a0e99d3e33  vmovaps [rsp+0x40], xmm4
000077a0e99d3e39  vmovaps [rsp+0x50], xmm5
000077a0e99d3e3f  vmovaps [rsp+0x60], xmm6
000077a0e99d3e45  vmovaps [rsp+0x70], xmm7
000077a0e99d3e4b  vmovaps [rsp+0x80], xmm8
000077a0e99d3e54  vmovaps [rsp+0x90], xmm9
000077a0e99d3e5d  vmovaps [rsp+0xA0], xmm10
000077a0e99d3e66  vmovaps [rsp+0xB0], xmm11
000077a0e99d3e6f  vmovaps [rsp+0xC0], xmm13
000077a0e99d3e78  vmovaps [rsp+0xD0], xmm14
000077a0e99d3e81  vmovaps [rsp+0xE0], xmm15
000077a0e99d3e8a  sub rsp, 0x40
000077a0e99d3e8e  lea rdi, [rsp]
000077a0e99d3e92  lea rsi, [rsp+0x10]
000077a0e99d3e97  lea rdx, [rsp+0x20]
000077a0e99d3e9c  lea rcx, [rsp+0x30]
000077a0e99d3ea1  mov r8d, 0x00
000077a0e99d3ea7  lea r9, [r15+0x3A8]
000077a0e99d3eae  movaps [rdi], xmm12
000077a0e99d3eb2  movaps [rsi], xmm15
000077a0e99d3eb6  movaps [rdx], xmm14
000077a0e99d3eba  movaps [rcx], xmm1
000077a0e99d3ebd  mov rax, 0x60CAA235BA50
000077a0e99d3ec7  call rax
000077a0e99d3ec9  movaps xmm12, [rsp]
000077a0e99d3ece  add rsp, 0x40
000077a0e99d3ed2  vmovaps xmm0, [rsp]
000077a0e99d3ed7  vmovaps xmm1, [rsp+0x10]
000077a0e99d3edd  vmovaps xmm2, [rsp+0x20]
000077a0e99d3ee3  vmovaps xmm3, [rsp+0x30]
000077a0e99d3ee9  vmovaps xmm4, [rsp+0x40]
000077a0e99d3eef  vmovaps xmm5, [rsp+0x50]
000077a0e99d3ef5  vmovaps xmm6, [rsp+0x60]
000077a0e99d3efb  vmovaps xmm7, [rsp+0x70]
000077a0e99d3f01  vmovaps xmm8, [rsp+0x80]
000077a0e99d3f0a  vmovaps xmm9, [rsp+0x90]
000077a0e99d3f13  vmovaps xmm10, [rsp+0xA0]
000077a0e99d3f1c  vmovaps xmm11, [rsp+0xB0]
000077a0e99d3f25  vmovaps xmm13, [rsp+0xC0]
000077a0e99d3f2e  vmovaps xmm14, [rsp+0xD0]
000077a0e99d3f37  vmovaps xmm15, [rsp+0xE0]
000077a0e99d3f40  add rsp, 0xF0
000077a0e99d3f47  pop r11
000077a0e99d3f49  pop r10
000077a0e99d3f4b  pop r9
000077a0e99d3f4d  pop r8
000077a0e99d3f4f  pop rsi
000077a0e99d3f50  pop rdi
000077a0e99d3f51  pop rdx
000077a0e99d3f52  pop rcx
000077a0e99d3f53  pop rax
000077a0e99d3f54  add rsp, 0x08
000077a0e99d3f58  jmp 0x000077A0E99D2C3D
000077a0e99d3f5d  sub rsp, 0x08
000077a0e99d3f61  push rax
000077a0e99d3f62  push rcx
000077a0e99d3f63  push rdx
000077a0e99d3f64  push rdi
000077a0e99d3f65  push rsi
000077a0e99d3f66  push r8
000077a0e99d3f68  push r9
000077a0e99d3f6a  push r10
000077a0e99d3f6c  push r11
000077a0e99d3f6e  sub rsp, 0xF0
000077a0e99d3f75  vmovaps [rsp], xmm0
000077a0e99d3f7a  vmovaps [rsp+0x10], xmm1
000077a0e99d3f80  vmovaps [rsp+0x20], xmm2
000077a0e99d3f86  vmovaps [rsp+0x30], xmm3
000077a0e99d3f8c  vmovaps [rsp+0x40], xmm4
000077a0e99d3f92  vmovaps [rsp+0x50], xmm5
000077a0e99d3f98  vmovaps [rsp+0x60], xmm6
000077a0e99d3f9e  vmovaps [rsp+0x70], xmm7
000077a0e99d3fa4  vmovaps [rsp+0x80], xmm8
000077a0e99d3fad  vmovaps [rsp+0x90], xmm9
000077a0e99d3fb6  vmovaps [rsp+0xA0], xmm10
000077a0e99d3fbf  vmovaps [rsp+0xB0], xmm11
000077a0e99d3fc8  vmovaps [rsp+0xC0], xmm12
000077a0e99d3fd1  vmovaps [rsp+0xD0], xmm13
000077a0e99d3fda  vmovaps [rsp+0xE0], xmm15
000077a0e99d3fe3  sub rsp, 0x40
000077a0e99d3fe7  lea rdi, [rsp]
000077a0e99d3feb  lea rsi, [rsp+0x10]
000077a0e99d3ff0  lea rdx, [rsp+0x20]
000077a0e99d3ff5  lea rcx, [rsp+0x30]
000077a0e99d3ffa  mov r8d, 0x00
000077a0e99d4000  lea r9, [r15+0x3A8]
000077a0e99d4007  movaps [rdi], xmm14
000077a0e99d400b  movaps [rsi], xmm3
000077a0e99d400e  movaps [rdx], xmm1
000077a0e99d4011  movaps [rcx], xmm15
000077a0e99d4015  mov rax, 0x60CAA235BA50
000077a0e99d401f  call rax
000077a0e99d4021  movaps xmm14, [rsp]
000077a0e99d4026  add rsp, 0x40
000077a0e99d402a  vmovaps xmm0, [rsp]
000077a0e99d402f  vmovaps xmm1, [rsp+0x10]
000077a0e99d4035  vmovaps xmm2, [rsp+0x20]
000077a0e99d403b  vmovaps xmm3, [rsp+0x30]
000077a0e99d4041  vmovaps xmm4, [rsp+0x40]
000077a0e99d4047  vmovaps xmm5, [rsp+0x50]
000077a0e99d404d  vmovaps xmm6, [rsp+0x60]
000077a0e99d4053  vmovaps xmm7, [rsp+0x70]
000077a0e99d4059  vmovaps xmm8, [rsp+0x80]
000077a0e99d4062  vmovaps xmm9, [rsp+0x90]
000077a0e99d406b  vmovaps xmm10, [rsp+0xA0]
000077a0e99d4074  vmovaps xmm11, [rsp+0xB0]
000077a0e99d407d  vmovaps xmm12, [rsp+0xC0]
000077a0e99d4086  vmovaps xmm13, [rsp+0xD0]
000077a0e99d408f  vmovaps xmm15, [rsp+0xE0]
000077a0e99d4098  add rsp, 0xF0
000077a0e99d409f  pop r11
000077a0e99d40a1  pop r10
000077a0e99d40a3  pop r9
000077a0e99d40a5  pop r8
000077a0e99d40a7  pop rsi
000077a0e99d40a8  pop rdi
000077a0e99d40a9  pop rdx
000077a0e99d40aa  pop rcx
000077a0e99d40ab  pop rax
000077a0e99d40ac  add rsp, 0x08
000077a0e99d40b0  jmp 0x000077A0E99D2CF7
000077a0e99d40b5  sub rsp, 0x08
000077a0e99d40b9  push rax
000077a0e99d40ba  push rcx
000077a0e99d40bb  push rdx
000077a0e99d40bc  push rdi
000077a0e99d40bd  push rsi
000077a0e99d40be  push r8
000077a0e99d40c0  push r9
000077a0e99d40c2  push r10
000077a0e99d40c4  push r11
000077a0e99d40c6  sub rsp, 0xF0
000077a0e99d40cd  vmovaps [rsp], xmm0
000077a0e99d40d2  vmovaps [rsp+0x10], xmm1
000077a0e99d40d8  vmovaps [rsp+0x20], xmm2
000077a0e99d40de  vmovaps [rsp+0x30], xmm3
000077a0e99d40e4  vmovaps [rsp+0x40], xmm4
000077a0e99d40ea  vmovaps [rsp+0x50], xmm5
000077a0e99d40f0  vmovaps [rsp+0x60], xmm6
000077a0e99d40f6  vmovaps [rsp+0x70], xmm7
000077a0e99d40fc  vmovaps [rsp+0x80], xmm8
000077a0e99d4105  vmovaps [rsp+0x90], xmm9
000077a0e99d410e  vmovaps [rsp+0xA0], xmm10
000077a0e99d4117  vmovaps [rsp+0xB0], xmm11
000077a0e99d4120  vmovaps [rsp+0xC0], xmm12
000077a0e99d4129  vmovaps [rsp+0xD0], xmm14
000077a0e99d4132  vmovaps [rsp+0xE0], xmm15
000077a0e99d413b  sub rsp, 0x40
000077a0e99d413f  lea rdi, [rsp]
000077a0e99d4143  lea rsi, [rsp+0x10]
000077a0e99d4148  lea rdx, [rsp+0x20]
000077a0e99d414d  lea rcx, [rsp+0x30]
000077a0e99d4152  mov r8d, 0x00
000077a0e99d4158  lea r9, [r15+0x3A8]
000077a0e99d415f  movaps [rdi], xmm13
000077a0e99d4163  movaps [rsi], xmm15
000077a0e99d4167  movaps [rdx], xmm10
000077a0e99d416b  movaps [rcx], xmm1
000077a0e99d416e  mov rax, 0x60CAA235BA50
000077a0e99d4178  call rax
000077a0e99d417a  movaps xmm13, [rsp]
000077a0e99d417f  add rsp, 0x40
000077a0e99d4183  vmovaps xmm0, [rsp]
000077a0e99d4188  vmovaps xmm1, [rsp+0x10]
000077a0e99d418e  vmovaps xmm2, [rsp+0x20]
000077a0e99d4194  vmovaps xmm3, [rsp+0x30]
000077a0e99d419a  vmovaps xmm4, [rsp+0x40]
000077a0e99d41a0  vmovaps xmm5, [rsp+0x50]
000077a0e99d41a6  vmovaps xmm6, [rsp+0x60]
000077a0e99d41ac  vmovaps xmm7, [rsp+0x70]
000077a0e99d41b2  vmovaps xmm8, [rsp+0x80]
000077a0e99d41bb  vmovaps xmm9, [rsp+0x90]
000077a0e99d41c4  vmovaps xmm10, [rsp+0xA0]
000077a0e99d41cd  vmovaps xmm11, [rsp+0xB0]
000077a0e99d41d6  vmovaps xmm12, [rsp+0xC0]
000077a0e99d41df  vmovaps xmm14, [rsp+0xD0]
000077a0e99d41e8  vmovaps xmm15, [rsp+0xE0]
000077a0e99d41f1  add rsp, 0xF0
000077a0e99d41f8  pop r11
000077a0e99d41fa  pop r10
000077a0e99d41fc  pop r9
000077a0e99d41fe  pop r8
000077a0e99d4200  pop rsi
000077a0e99d4201  pop rdi
000077a0e99d4202  pop rdx
000077a0e99d4203  pop rcx
000077a0e99d4204  pop rax
000077a0e99d4205  add rsp, 0x08
000077a0e99d4209  jmp 0x000077A0E99D2D26
000077a0e99d420e  sub rsp, 0x08
000077a0e99d4212  push rax
000077a0e99d4213  push rcx
000077a0e99d4214  push rdx
000077a0e99d4215  push rdi
000077a0e99d4216  push rsi
000077a0e99d4217  push r8
000077a0e99d4219  push r9
000077a0e99d421b  push r10
000077a0e99d421d  push r11
000077a0e99d421f  sub rsp, 0xF0
000077a0e99d4226  vmovaps [rsp], xmm0
000077a0e99d422b  vmovaps [rsp+0x10], xmm1
000077a0e99d4231  vmovaps [rsp+0x20], xmm2
000077a0e99d4237  vmovaps [rsp+0x30], xmm3
000077a0e99d423d  vmovaps [rsp+0x40], xmm4
000077a0e99d4243  vmovaps [rsp+0x50], xmm5
000077a0e99d4249  vmovaps [rsp+0x60], xmm6
000077a0e99d424f  vmovaps [rsp+0x70], xmm7
000077a0e99d4255  vmovaps [rsp+0x80], xmm8
000077a0e99d425e  vmovaps [rsp+0x90], xmm9
000077a0e99d4267  vmovaps [rsp+0xA0], xmm11
000077a0e99d4270  vmovaps [rsp+0xB0], xmm12
000077a0e99d4279  vmovaps [rsp+0xC0], xmm13
000077a0e99d4282  vmovaps [rsp+0xD0], xmm14
000077a0e99d428b  vmovaps [rsp+0xE0], xmm15
000077a0e99d4294  sub rsp, 0x40
000077a0e99d4298  lea rdi, [rsp]
000077a0e99d429c  lea rsi, [rsp+0x10]
000077a0e99d42a1  lea rdx, [rsp+0x20]
000077a0e99d42a6  lea rcx, [rsp+0x30]
000077a0e99d42ab  mov r8d, 0x00
000077a0e99d42b1  lea r9, [r15+0x3A8]
000077a0e99d42b8  movaps [rdi], xmm10
000077a0e99d42bc  movaps [rsi], xmm15
000077a0e99d42c0  movaps [rdx], xmm11
000077a0e99d42c4  movaps [rcx], xmm1
000077a0e99d42c7  mov rax, 0x60CAA235BA50
000077a0e99d42d1  call rax
000077a0e99d42d3  movaps xmm10, [rsp]
000077a0e99d42d8  add rsp, 0x40
000077a0e99d42dc  vmovaps xmm0, [rsp]
000077a0e99d42e1  vmovaps xmm1, [rsp+0x10]
000077a0e99d42e7  vmovaps xmm2, [rsp+0x20]
000077a0e99d42ed  vmovaps xmm3, [rsp+0x30]
000077a0e99d42f3  vmovaps xmm4, [rsp+0x40]
000077a0e99d42f9  vmovaps xmm5, [rsp+0x50]
000077a0e99d42ff  vmovaps xmm6, [rsp+0x60]
000077a0e99d4305  vmovaps xmm7, [rsp+0x70]
000077a0e99d430b  vmovaps xmm8, [rsp+0x80]
000077a0e99d4314  vmovaps xmm9, [rsp+0x90]
000077a0e99d431d  vmovaps xmm11, [rsp+0xA0]
000077a0e99d4326  vmovaps xmm12, [rsp+0xB0]
000077a0e99d432f  vmovaps xmm13, [rsp+0xC0]
000077a0e99d4338  vmovaps xmm14, [rsp+0xD0]
000077a0e99d4341  vmovaps xmm15, [rsp+0xE0]
000077a0e99d434a  add rsp, 0xF0
000077a0e99d4351  pop r11
000077a0e99d4353  pop r10
000077a0e99d4355  pop r9
000077a0e99d4357  pop r8
000077a0e99d4359  pop rsi
000077a0e99d435a  pop rdi
000077a0e99d435b  pop rdx
000077a0e99d435c  pop rcx
000077a0e99d435d  pop rax
000077a0e99d435e  add rsp, 0x08
000077a0e99d4362  jmp 0x000077A0E99D2D55
000077a0e99d4367  sub rsp, 0x08
000077a0e99d436b  push rax
000077a0e99d436c  push rcx
000077a0e99d436d  push rdx
000077a0e99d436e  push rdi
000077a0e99d436f  push rsi
000077a0e99d4370  push r8
000077a0e99d4372  push r9
000077a0e99d4374  push r10
000077a0e99d4376  push r11
000077a0e99d4378  sub rsp, 0xF0
000077a0e99d437f  vmovaps [rsp], xmm0
000077a0e99d4384  vmovaps [rsp+0x10], xmm1
000077a0e99d438a  vmovaps [rsp+0x20], xmm2
000077a0e99d4390  vmovaps [rsp+0x30], xmm3
000077a0e99d4396  vmovaps [rsp+0x40], xmm4
000077a0e99d439c  vmovaps [rsp+0x50], xmm5
000077a0e99d43a2  vmovaps [rsp+0x60], xmm6
000077a0e99d43a8  vmovaps [rsp+0x70], xmm7
000077a0e99d43ae  vmovaps [rsp+0x80], xmm8
000077a0e99d43b7  vmovaps [rsp+0x90], xmm9
000077a0e99d43c0  vmovaps [rsp+0xA0], xmm10
000077a0e99d43c9  vmovaps [rsp+0xB0], xmm11
000077a0e99d43d2  vmovaps [rsp+0xC0], xmm12
000077a0e99d43db  vmovaps [rsp+0xD0], xmm13
000077a0e99d43e4  vmovaps [rsp+0xE0], xmm14
000077a0e99d43ed  sub rsp, 0x40
000077a0e99d43f1  lea rdi, [rsp]
000077a0e99d43f5  lea rsi, [rsp+0x10]
000077a0e99d43fa  lea rdx, [rsp+0x20]
000077a0e99d43ff  lea rcx, [rsp+0x30]
000077a0e99d4404  mov r8d, 0x00
000077a0e99d440a  lea r9, [r15+0x3A8]
000077a0e99d4411  movaps [rdi], xmm15
000077a0e99d4415  movaps [rsi], xmm12
000077a0e99d4419  movaps [rdx], xmm5
000077a0e99d441c  movaps [rcx], xmm1
000077a0e99d441f  mov rax, 0x60CAA235BA50
000077a0e99d4429  call rax
000077a0e99d442b  movaps xmm15, [rsp]
000077a0e99d4430  add rsp, 0x40
000077a0e99d4434  vmovaps xmm0, [rsp]
000077a0e99d4439  vmovaps xmm1, [rsp+0x10]
000077a0e99d443f  vmovaps xmm2, [rsp+0x20]
000077a0e99d4445  vmovaps xmm3, [rsp+0x30]
000077a0e99d444b  vmovaps xmm4, [rsp+0x40]
000077a0e99d4451  vmovaps xmm5, [rsp+0x50]
000077a0e99d4457  vmovaps xmm6, [rsp+0x60]
000077a0e99d445d  vmovaps xmm7, [rsp+0x70]
000077a0e99d4463  vmovaps xmm8, [rsp+0x80]
000077a0e99d446c  vmovaps xmm9, [rsp+0x90]
000077a0e99d4475  vmovaps xmm10, [rsp+0xA0]
000077a0e99d447e  vmovaps xmm11, [rsp+0xB0]
000077a0e99d4487  vmovaps xmm12, [rsp+0xC0]
000077a0e99d4490  vmovaps xmm13, [rsp+0xD0]
000077a0e99d4499  vmovaps xmm14, [rsp+0xE0]
000077a0e99d44a2  add rsp, 0xF0
000077a0e99d44a9  pop r11
000077a0e99d44ab  pop r10
000077a0e99d44ad  pop r9
000077a0e99d44af  pop r8
000077a0e99d44b1  pop rsi
000077a0e99d44b2  pop rdi
000077a0e99d44b3  pop rdx
000077a0e99d44b4  pop rcx
000077a0e99d44b5  pop rax
000077a0e99d44b6  add rsp, 0x08
000077a0e99d44ba  jmp 0x000077A0E99D2D7E
000077a0e99d44bf  sub rsp, 0x08
000077a0e99d44c3  push rax
000077a0e99d44c4  push rcx
000077a0e99d44c5  push rdx
000077a0e99d44c6  push rdi
000077a0e99d44c7  push rsi
000077a0e99d44c8  push r8
000077a0e99d44ca  push r9
000077a0e99d44cc  push r10
000077a0e99d44ce  push r11
000077a0e99d44d0  sub rsp, 0xF0
000077a0e99d44d7  vmovaps [rsp], xmm0
000077a0e99d44dc  vmovaps [rsp+0x10], xmm1
000077a0e99d44e2  vmovaps [rsp+0x20], xmm2
000077a0e99d44e8  vmovaps [rsp+0x30], xmm3
000077a0e99d44ee  vmovaps [rsp+0x40], xmm4
000077a0e99d44f4  vmovaps [rsp+0x50], xmm6
000077a0e99d44fa  vmovaps [rsp+0x60], xmm7
000077a0e99d4500  vmovaps [rsp+0x70], xmm8
000077a0e99d4506  vmovaps [rsp+0x80], xmm9
000077a0e99d450f  vmovaps [rsp+0x90], xmm10
000077a0e99d4518  vmovaps [rsp+0xA0], xmm11
000077a0e99d4521  vmovaps [rsp+0xB0], xmm12
000077a0e99d452a  vmovaps [rsp+0xC0], xmm13
000077a0e99d4533  vmovaps [rsp+0xD0], xmm14
000077a0e99d453c  vmovaps [rsp+0xE0], xmm15
000077a0e99d4545  sub rsp, 0x40
000077a0e99d4549  lea rdi, [rsp]
000077a0e99d454d  lea rsi, [rsp+0x10]
000077a0e99d4552  lea rdx, [rsp+0x20]
000077a0e99d4557  lea rcx, [rsp+0x30]
000077a0e99d455c  mov r8d, 0x00
000077a0e99d4562  lea r9, [r15+0x3A8]
000077a0e99d4569  movaps [rdi], xmm5
000077a0e99d456c  movaps [rsi], xmm13
000077a0e99d4570  movaps [rdx], xmm11
000077a0e99d4574  movaps [rcx], xmm12
000077a0e99d4578  mov rax, 0x60CAA235BA50
000077a0e99d4582  call rax
000077a0e99d4584  movaps xmm5, [rsp]
000077a0e99d4588  add rsp, 0x40
000077a0e99d458c  vmovaps xmm0, [rsp]
000077a0e99d4591  vmovaps xmm1, [rsp+0x10]
000077a0e99d4597  vmovaps xmm2, [rsp+0x20]
000077a0e99d459d  vmovaps xmm3, [rsp+0x30]
000077a0e99d45a3  vmovaps xmm4, [rsp+0x40]
000077a0e99d45a9  vmovaps xmm6, [rsp+0x50]
000077a0e99d45af  vmovaps xmm7, [rsp+0x60]
000077a0e99d45b5  vmovaps xmm8, [rsp+0x70]
000077a0e99d45bb  vmovaps xmm9, [rsp+0x80]
000077a0e99d45c4  vmovaps xmm10, [rsp+0x90]
000077a0e99d45cd  vmovaps xmm11, [rsp+0xA0]
000077a0e99d45d6  vmovaps xmm12, [rsp+0xB0]
000077a0e99d45df  vmovaps xmm13, [rsp+0xC0]
000077a0e99d45e8  vmovaps xmm14, [rsp+0xD0]
000077a0e99d45f1  vmovaps xmm15, [rsp+0xE0]
000077a0e99d45fa  add rsp, 0xF0
000077a0e99d4601  pop r11
000077a0e99d4603  pop r10
000077a0e99d4605  pop r9
000077a0e99d4607  pop r8
000077a0e99d4609  pop rsi
000077a0e99d460a  pop rdi
000077a0e99d460b  pop rdx
000077a0e99d460c  pop rcx
000077a0e99d460d  pop rax
000077a0e99d460e  add rsp, 0x08
000077a0e99d4612  jmp 0x000077A0E99D2DDD
000077a0e99d4617  sub rsp, 0x08
000077a0e99d461b  push rax
000077a0e99d461c  push rcx
000077a0e99d461d  push rdx
000077a0e99d461e  push rdi
000077a0e99d461f  push rsi
000077a0e99d4620  push r8
000077a0e99d4622  push r9
000077a0e99d4624  push r10
000077a0e99d4626  push r11
000077a0e99d4628  sub rsp, 0xF0
000077a0e99d462f  vmovaps [rsp], xmm0
000077a0e99d4634  vmovaps [rsp+0x10], xmm1
000077a0e99d463a  vmovaps [rsp+0x20], xmm2
000077a0e99d4640  vmovaps [rsp+0x30], xmm3
000077a0e99d4646  vmovaps [rsp+0x40], xmm4
000077a0e99d464c  vmovaps [rsp+0x50], xmm5
000077a0e99d4652  vmovaps [rsp+0x60], xmm6
000077a0e99d4658  vmovaps [rsp+0x70], xmm7
000077a0e99d465e  vmovaps [rsp+0x80], xmm8
000077a0e99d4667  vmovaps [rsp+0x90], xmm9
000077a0e99d4670  vmovaps [rsp+0xA0], xmm10
000077a0e99d4679  vmovaps [rsp+0xB0], xmm11
000077a0e99d4682  vmovaps [rsp+0xC0], xmm13
000077a0e99d468b  vmovaps [rsp+0xD0], xmm14
000077a0e99d4694  vmovaps [rsp+0xE0], xmm15
000077a0e99d469d  sub rsp, 0x40
000077a0e99d46a1  lea rdi, [rsp]
000077a0e99d46a5  lea rsi, [rsp+0x10]
000077a0e99d46aa  lea rdx, [rsp+0x20]
000077a0e99d46af  lea rcx, [rsp+0x30]
000077a0e99d46b4  mov r8d, 0x00
000077a0e99d46ba  lea r9, [r15+0x3A8]
000077a0e99d46c1  movaps [rdi], xmm12
000077a0e99d46c5  movaps [rsi], xmm14
000077a0e99d46c9  movaps [rdx], xmm9
000077a0e99d46cd  movaps [rcx], xmm13
000077a0e99d46d1  mov rax, 0x60CAA235BA50
000077a0e99d46db  call rax
000077a0e99d46dd  movaps xmm12, [rsp]
000077a0e99d46e2  add rsp, 0x40
000077a0e99d46e6  vmovaps xmm0, [rsp]
000077a0e99d46eb  vmovaps xmm1, [rsp+0x10]
000077a0e99d46f1  vmovaps xmm2, [rsp+0x20]
000077a0e99d46f7  vmovaps xmm3, [rsp+0x30]
000077a0e99d46fd  vmovaps xmm4, [rsp+0x40]
000077a0e99d4703  vmovaps xmm5, [rsp+0x50]
000077a0e99d4709  vmovaps xmm6, [rsp+0x60]
000077a0e99d470f  vmovaps xmm7, [rsp+0x70]
000077a0e99d4715  vmovaps xmm8, [rsp+0x80]
000077a0e99d471e  vmovaps xmm9, [rsp+0x90]
000077a0e99d4727  vmovaps xmm10, [rsp+0xA0]
000077a0e99d4730  vmovaps xmm11, [rsp+0xB0]
000077a0e99d4739  vmovaps xmm13, [rsp+0xC0]
000077a0e99d4742  vmovaps xmm14, [rsp+0xD0]
000077a0e99d474b  vmovaps xmm15, [rsp+0xE0]
000077a0e99d4754  add rsp, 0xF0
000077a0e99d475b  pop r11
000077a0e99d475d  pop r10
000077a0e99d475f  pop r9
000077a0e99d4761  pop r8
000077a0e99d4763  pop rsi
000077a0e99d4764  pop rdi
000077a0e99d4765  pop rdx
000077a0e99d4766  pop rcx
000077a0e99d4767  pop rax
000077a0e99d4768  add rsp, 0x08
000077a0e99d476c  jmp 0x000077A0E99D2E06
000077a0e99d4771  call 0x000077A0E980D4E0
000077a0e99d4776  jmp 0x000077A0E99D2E13
000077a0e99d477b  sub rsp, 0x08
000077a0e99d477f  push rax
000077a0e99d4780  push rcx
000077a0e99d4781  push rdx
000077a0e99d4782  push rdi
000077a0e99d4783  push rsi
000077a0e99d4784  push r8
000077a0e99d4786  push r9
000077a0e99d4788  push r10
000077a0e99d478a  push r11
000077a0e99d478c  sub rsp, 0xF0
000077a0e99d4793  vmovaps [rsp], xmm0
000077a0e99d4798  vmovaps [rsp+0x10], xmm1
000077a0e99d479e  vmovaps [rsp+0x20], xmm2
000077a0e99d47a4  vmovaps [rsp+0x30], xmm3
000077a0e99d47aa  vmovaps [rsp+0x40], xmm4
000077a0e99d47b0  vmovaps [rsp+0x50], xmm5
000077a0e99d47b6  vmovaps [rsp+0x60], xmm6
000077a0e99d47bc  vmovaps [rsp+0x70], xmm7
000077a0e99d47c2  vmovaps [rsp+0x80], xmm8
000077a0e99d47cb  vmovaps [rsp+0x90], xmm9
000077a0e99d47d4  vmovaps [rsp+0xA0], xmm10
000077a0e99d47dd  vmovaps [rsp+0xB0], xmm12
000077a0e99d47e6  vmovaps [rsp+0xC0], xmm13
000077a0e99d47ef  vmovaps [rsp+0xD0], xmm14
000077a0e99d47f8  vmovaps [rsp+0xE0], xmm15
000077a0e99d4801  sub rsp, 0x40
000077a0e99d4805  lea rdi, [rsp]
000077a0e99d4809  lea rsi, [rsp+0x10]
000077a0e99d480e  lea rdx, [rsp+0x20]
000077a0e99d4813  lea rcx, [rsp+0x30]
000077a0e99d4818  mov r8d, 0x00
000077a0e99d481e  lea r9, [r15+0x3A8]
000077a0e99d4825  movaps [rdi], xmm11
000077a0e99d4829  movaps [rsi], xmm10
000077a0e99d482d  movaps [rdx], xmm8
000077a0e99d4831  movaps [rcx], xmm13
000077a0e99d4835  mov rax, 0x60CAA235BA50
000077a0e99d483f  call rax
000077a0e99d4841  movaps xmm11, [rsp]
000077a0e99d4846  add rsp, 0x40
000077a0e99d484a  vmovaps xmm0, [rsp]
000077a0e99d484f  vmovaps xmm1, [rsp+0x10]
000077a0e99d4855  vmovaps xmm2, [rsp+0x20]
000077a0e99d485b  vmovaps xmm3, [rsp+0x30]
000077a0e99d4861  vmovaps xmm4, [rsp+0x40]
000077a0e99d4867  vmovaps xmm5, [rsp+0x50]
000077a0e99d486d  vmovaps xmm6, [rsp+0x60]
000077a0e99d4873  vmovaps xmm7, [rsp+0x70]
000077a0e99d4879  vmovaps xmm8, [rsp+0x80]
000077a0e99d4882  vmovaps xmm9, [rsp+0x90]
000077a0e99d488b  vmovaps xmm10, [rsp+0xA0]
000077a0e99d4894  vmovaps xmm12, [rsp+0xB0]
000077a0e99d489d  vmovaps xmm13, [rsp+0xC0]
000077a0e99d48a6  vmovaps xmm14, [rsp+0xD0]
000077a0e99d48af  vmovaps xmm15, [rsp+0xE0]
000077a0e99d48b8  add rsp, 0xF0
000077a0e99d48bf  pop r11
000077a0e99d48c1  pop r10
000077a0e99d48c3  pop r9
000077a0e99d48c5  pop r8
000077a0e99d48c7  pop rsi
000077a0e99d48c8  pop rdi
000077a0e99d48c9  pop rdx
000077a0e99d48ca  pop rcx
000077a0e99d48cb  pop rax
000077a0e99d48cc  add rsp, 0x08
000077a0e99d48d0  jmp 0x000077A0E99D2E44
000077a0e99d48d5  sub rsp, 0x08
000077a0e99d48d9  push rax
000077a0e99d48da  push rcx
000077a0e99d48db  push rdx
000077a0e99d48dc  push rdi
000077a0e99d48dd  push rsi
000077a0e99d48de  push r8
000077a0e99d48e0  push r9
000077a0e99d48e2  push r10
000077a0e99d48e4  push r11
000077a0e99d48e6  sub rsp, 0xF0
000077a0e99d48ed  vmovaps [rsp], xmm0
000077a0e99d48f2  vmovaps [rsp+0x10], xmm1
000077a0e99d48f8  vmovaps [rsp+0x20], xmm2
000077a0e99d48fe  vmovaps [rsp+0x30], xmm3
000077a0e99d4904  vmovaps [rsp+0x40], xmm4
000077a0e99d490a  vmovaps [rsp+0x50], xmm5
000077a0e99d4910  vmovaps [rsp+0x60], xmm6
000077a0e99d4916  vmovaps [rsp+0x70], xmm7
000077a0e99d491c  vmovaps [rsp+0x80], xmm8
000077a0e99d4925  vmovaps [rsp+0x90], xmm9
000077a0e99d492e  vmovaps [rsp+0xA0], xmm11
000077a0e99d4937  vmovaps [rsp+0xB0], xmm12
000077a0e99d4940  vmovaps [rsp+0xC0], xmm13
000077a0e99d4949  vmovaps [rsp+0xD0], xmm14
000077a0e99d4952  vmovaps [rsp+0xE0], xmm15
000077a0e99d495b  sub rsp, 0x40
000077a0e99d495f  lea rdi, [rsp]
000077a0e99d4963  lea rsi, [rsp+0x10]
000077a0e99d4968  lea rdx, [rsp+0x20]
000077a0e99d496d  lea rcx, [rsp+0x30]
000077a0e99d4972  mov r8d, 0x00
000077a0e99d4978  lea r9, [r15+0x3A8]
000077a0e99d497f  movaps [rdi], xmm10
000077a0e99d4983  movaps [rsi], xmm15
000077a0e99d4987  movaps [rdx], xmm1
000077a0e99d498a  movaps [rcx], xmm13
000077a0e99d498e  mov rax, 0x60CAA235BA50
000077a0e99d4998  call rax
000077a0e99d499a  movaps xmm10, [rsp]
000077a0e99d499f  add rsp, 0x40
000077a0e99d49a3  vmovaps xmm0, [rsp]
000077a0e99d49a8  vmovaps xmm1, [rsp+0x10]
000077a0e99d49ae  vmovaps xmm2, [rsp+0x20]
000077a0e99d49b4  vmovaps xmm3, [rsp+0x30]
000077a0e99d49ba  vmovaps xmm4, [rsp+0x40]
000077a0e99d49c0  vmovaps xmm5, [rsp+0x50]
000077a0e99d49c6  vmovaps xmm6, [rsp+0x60]
000077a0e99d49cc  vmovaps xmm7, [rsp+0x70]
000077a0e99d49d2  vmovaps xmm8, [rsp+0x80]
000077a0e99d49db  vmovaps xmm9, [rsp+0x90]
000077a0e99d49e4  vmovaps xmm11, [rsp+0xA0]
000077a0e99d49ed  vmovaps xmm12, [rsp+0xB0]
000077a0e99d49f6  vmovaps xmm13, [rsp+0xC0]
000077a0e99d49ff  vmovaps xmm14, [rsp+0xD0]
000077a0e99d4a08  vmovaps xmm15, [rsp+0xE0]
000077a0e99d4a11  add rsp, 0xF0
000077a0e99d4a18  pop r11
000077a0e99d4a1a  pop r10
000077a0e99d4a1c  pop r9
000077a0e99d4a1e  pop r8
000077a0e99d4a20  pop rsi
000077a0e99d4a21  pop rdi
000077a0e99d4a22  pop rdx
000077a0e99d4a23  pop rcx
000077a0e99d4a24  pop rax
000077a0e99d4a25  add rsp, 0x08
000077a0e99d4a29  jmp 0x000077A0E99D2E6D
000077a0e99d4a2e  call 0x000077A0E97FF430
000077a0e99d4a33  jmp 0x000077A0E99D2E8F
000077a0e99d4a38  call 0x000077A0E980E760
000077a0e99d4a3d  jmp 0x000077A0E99D2E99
000077a0e99d4a42  sub rsp, 0x08
000077a0e99d4a46  push rax
000077a0e99d4a47  push rcx
000077a0e99d4a48  push rdx
000077a0e99d4a49  push rdi
000077a0e99d4a4a  push rsi
000077a0e99d4a4b  push r8
000077a0e99d4a4d  push r9
000077a0e99d4a4f  push r10
000077a0e99d4a51  push r11
000077a0e99d4a53  sub rsp, 0xF0
000077a0e99d4a5a  vmovaps [rsp], xmm0
000077a0e99d4a5f  vmovaps [rsp+0x10], xmm1
000077a0e99d4a65  vmovaps [rsp+0x20], xmm2
000077a0e99d4a6b  vmovaps [rsp+0x30], xmm3
000077a0e99d4a71  vmovaps [rsp+0x40], xmm4
000077a0e99d4a77  vmovaps [rsp+0x50], xmm5
000077a0e99d4a7d  vmovaps [rsp+0x60], xmm6
000077a0e99d4a83  vmovaps [rsp+0x70], xmm7
000077a0e99d4a89  vmovaps [rsp+0x80], xmm9
000077a0e99d4a92  vmovaps [rsp+0x90], xmm10
000077a0e99d4a9b  vmovaps [rsp+0xA0], xmm11
000077a0e99d4aa4  vmovaps [rsp+0xB0], xmm12
000077a0e99d4aad  vmovaps [rsp+0xC0], xmm13
000077a0e99d4ab6  vmovaps [rsp+0xD0], xmm14
000077a0e99d4abf  vmovaps [rsp+0xE0], xmm15
000077a0e99d4ac8  sub rsp, 0x40
000077a0e99d4acc  lea rdi, [rsp]
000077a0e99d4ad0  lea rsi, [rsp+0x10]
000077a0e99d4ad5  lea rdx, [rsp+0x20]
000077a0e99d4ada  lea rcx, [rsp+0x30]
000077a0e99d4adf  mov r8d, 0x00
000077a0e99d4ae5  lea r9, [r15+0x3A8]
000077a0e99d4aec  movaps [rdi], xmm8
000077a0e99d4af0  movaps [rsi], xmm5
000077a0e99d4af3  movaps [rdx], xmm9
000077a0e99d4af7  movaps [rcx], xmm13
000077a0e99d4afb  mov rax, 0x60CAA235BA50
000077a0e99d4b05  call rax
000077a0e99d4b07  movaps xmm8, [rsp]
000077a0e99d4b0c  add rsp, 0x40
000077a0e99d4b10  vmovaps xmm0, [rsp]
000077a0e99d4b15  vmovaps xmm1, [rsp+0x10]
000077a0e99d4b1b  vmovaps xmm2, [rsp+0x20]
000077a0e99d4b21  vmovaps xmm3, [rsp+0x30]
000077a0e99d4b27  vmovaps xmm4, [rsp+0x40]
000077a0e99d4b2d  vmovaps xmm5, [rsp+0x50]
000077a0e99d4b33  vmovaps xmm6, [rsp+0x60]
000077a0e99d4b39  vmovaps xmm7, [rsp+0x70]
000077a0e99d4b3f  vmovaps xmm9, [rsp+0x80]
000077a0e99d4b48  vmovaps xmm10, [rsp+0x90]
000077a0e99d4b51  vmovaps xmm11, [rsp+0xA0]
000077a0e99d4b5a  vmovaps xmm12, [rsp+0xB0]
000077a0e99d4b63  vmovaps xmm13, [rsp+0xC0]
000077a0e99d4b6c  vmovaps xmm14, [rsp+0xD0]
000077a0e99d4b75  vmovaps xmm15, [rsp+0xE0]
000077a0e99d4b7e  add rsp, 0xF0
000077a0e99d4b85  pop r11
000077a0e99d4b87  pop r10
000077a0e99d4b89  pop r9
000077a0e99d4b8b  pop r8
000077a0e99d4b8d  pop rsi
000077a0e99d4b8e  pop rdi
000077a0e99d4b8f  pop rdx
000077a0e99d4b90  pop rcx
000077a0e99d4b91  pop rax
000077a0e99d4b92  add rsp, 0x08
000077a0e99d4b96  jmp 0x000077A0E99D2ED8
000077a0e99d4b9b  sub rsp, 0x08
000077a0e99d4b9f  push rax
000077a0e99d4ba0  push rcx
000077a0e99d4ba1  push rdx
000077a0e99d4ba2  push rdi
000077a0e99d4ba3  push rsi
000077a0e99d4ba4  push r8
000077a0e99d4ba6  push r9
000077a0e99d4ba8  push r10
000077a0e99d4baa  push r11
000077a0e99d4bac  sub rsp, 0xF0
000077a0e99d4bb3  vmovaps [rsp], xmm0
000077a0e99d4bb8  vmovaps [rsp+0x10], xmm1
000077a0e99d4bbe  vmovaps [rsp+0x20], xmm2
000077a0e99d4bc4  vmovaps [rsp+0x30], xmm3
000077a0e99d4bca  vmovaps [rsp+0x40], xmm4
000077a0e99d4bd0  vmovaps [rsp+0x50], xmm5
000077a0e99d4bd6  vmovaps [rsp+0x60], xmm6
000077a0e99d4bdc  vmovaps [rsp+0x70], xmm7
000077a0e99d4be2  vmovaps [rsp+0x80], xmm8
000077a0e99d4beb  vmovaps [rsp+0x90], xmm10
000077a0e99d4bf4  vmovaps [rsp+0xA0], xmm11
000077a0e99d4bfd  vmovaps [rsp+0xB0], xmm12
000077a0e99d4c06  vmovaps [rsp+0xC0], xmm13
000077a0e99d4c0f  vmovaps [rsp+0xD0], xmm14
000077a0e99d4c18  vmovaps [rsp+0xE0], xmm15
000077a0e99d4c21  sub rsp, 0x40
000077a0e99d4c25  lea rdi, [rsp]
000077a0e99d4c29  lea rsi, [rsp+0x10]
000077a0e99d4c2e  lea rdx, [rsp+0x20]
000077a0e99d4c33  lea rcx, [rsp+0x30]
000077a0e99d4c38  mov r8d, 0x00
000077a0e99d4c3e  lea r9, [r15+0x3A8]
000077a0e99d4c45  movaps [rdi], xmm9
000077a0e99d4c49  movaps [rsi], xmm12
000077a0e99d4c4d  movaps [rdx], xmm7
000077a0e99d4c50  movaps [rcx], xmm13
000077a0e99d4c54  mov rax, 0x60CAA235BA50
000077a0e99d4c5e  call rax
000077a0e99d4c60  movaps xmm9, [rsp]
000077a0e99d4c65  add rsp, 0x40
000077a0e99d4c69  vmovaps xmm0, [rsp]
000077a0e99d4c6e  vmovaps xmm1, [rsp+0x10]
000077a0e99d4c74  vmovaps xmm2, [rsp+0x20]
000077a0e99d4c7a  vmovaps xmm3, [rsp+0x30]
000077a0e99d4c80  vmovaps xmm4, [rsp+0x40]
000077a0e99d4c86  vmovaps xmm5, [rsp+0x50]
000077a0e99d4c8c  vmovaps xmm6, [rsp+0x60]
000077a0e99d4c92  vmovaps xmm7, [rsp+0x70]
000077a0e99d4c98  vmovaps xmm8, [rsp+0x80]
000077a0e99d4ca1  vmovaps xmm10, [rsp+0x90]
000077a0e99d4caa  vmovaps xmm11, [rsp+0xA0]
000077a0e99d4cb3  vmovaps xmm12, [rsp+0xB0]
000077a0e99d4cbc  vmovaps xmm13, [rsp+0xC0]
000077a0e99d4cc5  vmovaps xmm14, [rsp+0xD0]
000077a0e99d4cce  vmovaps xmm15, [rsp+0xE0]
000077a0e99d4cd7  add rsp, 0xF0
000077a0e99d4cde  pop r11
000077a0e99d4ce0  pop r10
000077a0e99d4ce2  pop r9
000077a0e99d4ce4  pop r8
000077a0e99d4ce6  pop rsi
000077a0e99d4ce7  pop rdi
000077a0e99d4ce8  pop rdx
000077a0e99d4ce9  pop rcx
000077a0e99d4cea  pop rax
000077a0e99d4ceb  add rsp, 0x08
000077a0e99d4cef  jmp 0x000077A0E99D2F01
000077a0e99d4cf4  sub rsp, 0x08
000077a0e99d4cf8  push rax
000077a0e99d4cf9  push rcx
000077a0e99d4cfa  push rdx
000077a0e99d4cfb  push rdi
000077a0e99d4cfc  push rsi
000077a0e99d4cfd  push r8
000077a0e99d4cff  push r9
000077a0e99d4d01  push r10
000077a0e99d4d03  push r11
000077a0e99d4d05  sub rsp, 0xF0
000077a0e99d4d0c  vmovaps [rsp], xmm0
000077a0e99d4d11  vmovaps [rsp+0x10], xmm1
000077a0e99d4d17  vmovaps [rsp+0x20], xmm2
000077a0e99d4d1d  vmovaps [rsp+0x30], xmm3
000077a0e99d4d23  vmovaps [rsp+0x40], xmm4
000077a0e99d4d29  vmovaps [rsp+0x50], xmm5
000077a0e99d4d2f  vmovaps [rsp+0x60], xmm6
000077a0e99d4d35  vmovaps [rsp+0x70], xmm7
000077a0e99d4d3b  vmovaps [rsp+0x80], xmm8
000077a0e99d4d44  vmovaps [rsp+0x90], xmm9
000077a0e99d4d4d  vmovaps [rsp+0xA0], xmm10
000077a0e99d4d56  vmovaps [rsp+0xB0], xmm11
000077a0e99d4d5f  vmovaps [rsp+0xC0], xmm13
000077a0e99d4d68  vmovaps [rsp+0xD0], xmm14
000077a0e99d4d71  vmovaps [rsp+0xE0], xmm15
000077a0e99d4d7a  sub rsp, 0x40
000077a0e99d4d7e  lea rdi, [rsp]
000077a0e99d4d82  lea rsi, [rsp+0x10]
000077a0e99d4d87  lea rdx, [rsp+0x20]
000077a0e99d4d8c  lea rcx, [rsp+0x30]
000077a0e99d4d91  mov r8d, 0x00
000077a0e99d4d97  lea r9, [r15+0x3A8]
000077a0e99d4d9e  movaps [rdi], xmm12
000077a0e99d4da2  movaps [rsi], xmm11
000077a0e99d4da6  movaps [rdx], xmm6
000077a0e99d4da9  movaps [rcx], xmm13
000077a0e99d4dad  mov rax, 0x60CAA235BA50
000077a0e99d4db7  call rax
000077a0e99d4db9  movaps xmm12, [rsp]
000077a0e99d4dbe  add rsp, 0x40
000077a0e99d4dc2  vmovaps xmm0, [rsp]
000077a0e99d4dc7  vmovaps xmm1, [rsp+0x10]
000077a0e99d4dcd  vmovaps xmm2, [rsp+0x20]
000077a0e99d4dd3  vmovaps xmm3, [rsp+0x30]
000077a0e99d4dd9  vmovaps xmm4, [rsp+0x40]
000077a0e99d4ddf  vmovaps xmm5, [rsp+0x50]
000077a0e99d4de5  vmovaps xmm6, [rsp+0x60]
000077a0e99d4deb  vmovaps xmm7, [rsp+0x70]
000077a0e99d4df1  vmovaps xmm8, [rsp+0x80]
000077a0e99d4dfa  vmovaps xmm9, [rsp+0x90]
000077a0e99d4e03  vmovaps xmm10, [rsp+0xA0]
000077a0e99d4e0c  vmovaps xmm11, [rsp+0xB0]
000077a0e99d4e15  vmovaps xmm13, [rsp+0xC0]
000077a0e99d4e1e  vmovaps xmm14, [rsp+0xD0]
000077a0e99d4e27  vmovaps xmm15, [rsp+0xE0]
000077a0e99d4e30  add rsp, 0xF0
000077a0e99d4e37  pop r11
000077a0e99d4e39  pop r10
000077a0e99d4e3b  pop r9
000077a0e99d4e3d  pop r8
000077a0e99d4e3f  pop rsi
000077a0e99d4e40  pop rdi
000077a0e99d4e41  pop rdx
000077a0e99d4e42  pop rcx
000077a0e99d4e43  pop rax
000077a0e99d4e44  add rsp, 0x08
000077a0e99d4e48  jmp 0x000077A0E99D2F2A
000077a0e99d4e4d  sub rsp, 0x08
000077a0e99d4e51  push rax
000077a0e99d4e52  push rcx
000077a0e99d4e53  push rdx
000077a0e99d4e54  push rdi
000077a0e99d4e55  push rsi
000077a0e99d4e56  push r8
000077a0e99d4e58  push r9
000077a0e99d4e5a  push r10
000077a0e99d4e5c  push r11
000077a0e99d4e5e  sub rsp, 0xF0
000077a0e99d4e65  vmovaps [rsp], xmm0
000077a0e99d4e6a  vmovaps [rsp+0x10], xmm1
000077a0e99d4e70  vmovaps [rsp+0x20], xmm2
000077a0e99d4e76  vmovaps [rsp+0x30], xmm3
000077a0e99d4e7c  vmovaps [rsp+0x40], xmm4
000077a0e99d4e82  vmovaps [rsp+0x50], xmm5
000077a0e99d4e88  vmovaps [rsp+0x60], xmm6
000077a0e99d4e8e  vmovaps [rsp+0x70], xmm8
000077a0e99d4e94  vmovaps [rsp+0x80], xmm9
000077a0e99d4e9d  vmovaps [rsp+0x90], xmm10
000077a0e99d4ea6  vmovaps [rsp+0xA0], xmm11
000077a0e99d4eaf  vmovaps [rsp+0xB0], xmm12
000077a0e99d4eb8  vmovaps [rsp+0xC0], xmm13
000077a0e99d4ec1  vmovaps [rsp+0xD0], xmm14
000077a0e99d4eca  vmovaps [rsp+0xE0], xmm15
000077a0e99d4ed3  sub rsp, 0x40
000077a0e99d4ed7  lea rdi, [rsp]
000077a0e99d4edb  lea rsi, [rsp+0x10]
000077a0e99d4ee0  lea rdx, [rsp+0x20]
000077a0e99d4ee5  lea rcx, [rsp+0x30]
000077a0e99d4eea  mov r8d, 0x00
000077a0e99d4ef0  lea r9, [r15+0x3A8]
000077a0e99d4ef7  movaps [rdi], xmm7
000077a0e99d4efa  movaps [rsi], xmm10
000077a0e99d4efe  movaps [rdx], xmm11
000077a0e99d4f02  movaps [rcx], xmm13
000077a0e99d4f06  mov rax, 0x60CAA235BA50
000077a0e99d4f10  call rax
000077a0e99d4f12  movaps xmm7, [rsp]
000077a0e99d4f16  add rsp, 0x40
000077a0e99d4f1a  vmovaps xmm0, [rsp]
000077a0e99d4f1f  vmovaps xmm1, [rsp+0x10]
000077a0e99d4f25  vmovaps xmm2, [rsp+0x20]
000077a0e99d4f2b  vmovaps xmm3, [rsp+0x30]
000077a0e99d4f31  vmovaps xmm4, [rsp+0x40]
000077a0e99d4f37  vmovaps xmm5, [rsp+0x50]
000077a0e99d4f3d  vmovaps xmm6, [rsp+0x60]
000077a0e99d4f43  vmovaps xmm8, [rsp+0x70]
000077a0e99d4f49  vmovaps xmm9, [rsp+0x80]
000077a0e99d4f52  vmovaps xmm10, [rsp+0x90]
000077a0e99d4f5b  vmovaps xmm11, [rsp+0xA0]
000077a0e99d4f64  vmovaps xmm12, [rsp+0xB0]
000077a0e99d4f6d  vmovaps xmm13, [rsp+0xC0]
000077a0e99d4f76  vmovaps xmm14, [rsp+0xD0]
000077a0e99d4f7f  vmovaps xmm15, [rsp+0xE0]
000077a0e99d4f88  add rsp, 0xF0
000077a0e99d4f8f  pop r11
000077a0e99d4f91  pop r10
000077a0e99d4f93  pop r9
000077a0e99d4f95  pop r8
000077a0e99d4f97  pop rsi
000077a0e99d4f98  pop rdi
000077a0e99d4f99  pop rdx
000077a0e99d4f9a  pop rcx
000077a0e99d4f9b  pop rax
000077a0e99d4f9c  add rsp, 0x08
000077a0e99d4fa0  jmp 0x000077A0E99D2F58
000077a0e99d4fa5  call 0x000077A0E980C260
000077a0e99d4faa  jmp 0x000077A0E99D2F62
000077a0e99d4faf  call 0x000077A0E9809D70
000077a0e99d4fb4  jmp 0x000077A0E99D2F6C
000077a0e99d4fb9  sub rsp, 0x08
000077a0e99d4fbd  push rax
000077a0e99d4fbe  push rcx
000077a0e99d4fbf  push rdx
000077a0e99d4fc0  push rdi
000077a0e99d4fc1  push rsi
000077a0e99d4fc2  push r8
000077a0e99d4fc4  push r9
000077a0e99d4fc6  push r10
000077a0e99d4fc8  push r11
000077a0e99d4fca  sub rsp, 0xF0
000077a0e99d4fd1  vmovaps [rsp], xmm0
000077a0e99d4fd6  vmovaps [rsp+0x10], xmm1
000077a0e99d4fdc  vmovaps [rsp+0x20], xmm2
000077a0e99d4fe2  vmovaps [rsp+0x30], xmm3
000077a0e99d4fe8  vmovaps [rsp+0x40], xmm4
000077a0e99d4fee  vmovaps [rsp+0x50], xmm5
000077a0e99d4ff4  vmovaps [rsp+0x60], xmm7
000077a0e99d4ffa  vmovaps [rsp+0x70], xmm8
000077a0e99d5000  vmovaps [rsp+0x80], xmm9
000077a0e99d5009  vmovaps [rsp+0x90], xmm10
000077a0e99d5012  vmovaps [rsp+0xA0], xmm11
000077a0e99d501b  vmovaps [rsp+0xB0], xmm12
000077a0e99d5024  vmovaps [rsp+0xC0], xmm13
000077a0e99d502d  vmovaps [rsp+0xD0], xmm14
000077a0e99d5036  vmovaps [rsp+0xE0], xmm15
000077a0e99d503f  sub rsp, 0x40
000077a0e99d5043  lea rdi, [rsp]
000077a0e99d5047  lea rsi, [rsp+0x10]
000077a0e99d504c  lea rdx, [rsp+0x20]
000077a0e99d5051  lea rcx, [rsp+0x30]
000077a0e99d5056  mov r8d, 0x00
000077a0e99d505c  lea r9, [r15+0x3A8]
000077a0e99d5063  movaps [rdi], xmm6
000077a0e99d5066  movaps [rsi], xmm8
000077a0e99d506a  movaps [rdx], xmm15
000077a0e99d506e  movaps [rcx], xmm10
000077a0e99d5072  mov rax, 0x60CAA235BA50
000077a0e99d507c  call rax
000077a0e99d507e  movaps xmm6, [rsp]
000077a0e99d5082  add rsp, 0x40
000077a0e99d5086  vmovaps xmm0, [rsp]
000077a0e99d508b  vmovaps xmm1, [rsp+0x10]
000077a0e99d5091  vmovaps xmm2, [rsp+0x20]
000077a0e99d5097  vmovaps xmm3, [rsp+0x30]
000077a0e99d509d  vmovaps xmm4, [rsp+0x40]
000077a0e99d50a3  vmovaps xmm5, [rsp+0x50]
000077a0e99d50a9  vmovaps xmm7, [rsp+0x60]
000077a0e99d50af  vmovaps xmm8, [rsp+0x70]
000077a0e99d50b5  vmovaps xmm9, [rsp+0x80]
000077a0e99d50be  vmovaps xmm10, [rsp+0x90]
000077a0e99d50c7  vmovaps xmm11, [rsp+0xA0]
000077a0e99d50d0  vmovaps xmm12, [rsp+0xB0]
000077a0e99d50d9  vmovaps xmm13, [rsp+0xC0]
000077a0e99d50e2  vmovaps xmm14, [rsp+0xD0]
000077a0e99d50eb  vmovaps xmm15, [rsp+0xE0]
000077a0e99d50f4  add rsp, 0xF0
000077a0e99d50fb  pop r11
000077a0e99d50fd  pop r10
000077a0e99d50ff  pop r9
000077a0e99d5101  pop r8
000077a0e99d5103  pop rsi
000077a0e99d5104  pop rdi
000077a0e99d5105  pop rdx
000077a0e99d5106  pop rcx
000077a0e99d5107  pop rax
000077a0e99d5108  add rsp, 0x08
000077a0e99d510c  jmp 0x000077A0E99D2FA4
000077a0e99d5111  sub rsp, 0x08
000077a0e99d5115  push rax
000077a0e99d5116  push rcx
000077a0e99d5117  push rdx
000077a0e99d5118  push rdi
000077a0e99d5119  push rsi
000077a0e99d511a  push r8
000077a0e99d511c  push r9
000077a0e99d511e  push r10
000077a0e99d5120  push r11
000077a0e99d5122  sub rsp, 0xF0
000077a0e99d5129  vmovaps [rsp], xmm0
000077a0e99d512e  vmovaps [rsp+0x10], xmm1
000077a0e99d5134  vmovaps [rsp+0x20], xmm2
000077a0e99d513a  vmovaps [rsp+0x30], xmm3
000077a0e99d5140  vmovaps [rsp+0x40], xmm4
000077a0e99d5146  vmovaps [rsp+0x50], xmm5
000077a0e99d514c  vmovaps [rsp+0x60], xmm6
000077a0e99d5152  vmovaps [rsp+0x70], xmm7
000077a0e99d5158  vmovaps [rsp+0x80], xmm8
000077a0e99d5161  vmovaps [rsp+0x90], xmm9
000077a0e99d516a  vmovaps [rsp+0xA0], xmm11
000077a0e99d5173  vmovaps [rsp+0xB0], xmm12
000077a0e99d517c  vmovaps [rsp+0xC0], xmm13
000077a0e99d5185  vmovaps [rsp+0xD0], xmm14
000077a0e99d518e  vmovaps [rsp+0xE0], xmm15
000077a0e99d5197  sub rsp, 0x40
000077a0e99d519b  lea rdi, [rsp]
000077a0e99d519f  lea rsi, [rsp+0x10]
000077a0e99d51a4  lea rdx, [rsp+0x20]
000077a0e99d51a9  lea rcx, [rsp+0x30]
000077a0e99d51ae  mov r8d, 0x00
000077a0e99d51b4  lea r9, [r15+0x3A8]
000077a0e99d51bb  movaps [rdi], xmm10
000077a0e99d51bf  movaps [rsi], xmm9
000077a0e99d51c3  movaps [rdx], xmm13
000077a0e99d51c7  movaps [rcx], xmm15
000077a0e99d51cb  mov rax, 0x60CAA235BA50
000077a0e99d51d5  call rax
000077a0e99d51d7  movaps xmm10, [rsp]
000077a0e99d51dc  add rsp, 0x40
000077a0e99d51e0  vmovaps xmm0, [rsp]
000077a0e99d51e5  vmovaps xmm1, [rsp+0x10]
000077a0e99d51eb  vmovaps xmm2, [rsp+0x20]
000077a0e99d51f1  vmovaps xmm3, [rsp+0x30]
000077a0e99d51f7  vmovaps xmm4, [rsp+0x40]
000077a0e99d51fd  vmovaps xmm5, [rsp+0x50]
000077a0e99d5203  vmovaps xmm6, [rsp+0x60]
000077a0e99d5209  vmovaps xmm7, [rsp+0x70]
000077a0e99d520f  vmovaps xmm8, [rsp+0x80]
000077a0e99d5218  vmovaps xmm9, [rsp+0x90]
000077a0e99d5221  vmovaps xmm11, [rsp+0xA0]
000077a0e99d522a  vmovaps xmm12, [rsp+0xB0]
000077a0e99d5233  vmovaps xmm13, [rsp+0xC0]
000077a0e99d523c  vmovaps xmm14, [rsp+0xD0]
000077a0e99d5245  vmovaps xmm15, [rsp+0xE0]
000077a0e99d524e  add rsp, 0xF0
000077a0e99d5255  pop r11
000077a0e99d5257  pop r10
000077a0e99d5259  pop r9
000077a0e99d525b  pop r8
000077a0e99d525d  pop rsi
000077a0e99d525e  pop rdi
000077a0e99d525f  pop rdx
000077a0e99d5260  pop rcx
000077a0e99d5261  pop rax
000077a0e99d5262  add rsp, 0x08
000077a0e99d5266  jmp 0x000077A0E99D2FCD
000077a0e99d526b  sub rsp, 0x08
000077a0e99d526f  push rax
000077a0e99d5270  push rcx
000077a0e99d5271  push rdx
000077a0e99d5272  push rdi
000077a0e99d5273  push rsi
000077a0e99d5274  push r8
000077a0e99d5276  push r9
000077a0e99d5278  push r10
000077a0e99d527a  push r11
000077a0e99d527c  sub rsp, 0xF0
000077a0e99d5283  vmovaps [rsp], xmm0
000077a0e99d5288  vmovaps [rsp+0x10], xmm1
000077a0e99d528e  vmovaps [rsp+0x20], xmm2
000077a0e99d5294  vmovaps [rsp+0x30], xmm3
000077a0e99d529a  vmovaps [rsp+0x40], xmm4
000077a0e99d52a0  vmovaps [rsp+0x50], xmm5
000077a0e99d52a6  vmovaps [rsp+0x60], xmm6
000077a0e99d52ac  vmovaps [rsp+0x70], xmm7
000077a0e99d52b2  vmovaps [rsp+0x80], xmm8
000077a0e99d52bb  vmovaps [rsp+0x90], xmm9
000077a0e99d52c4  vmovaps [rsp+0xA0], xmm10
000077a0e99d52cd  vmovaps [rsp+0xB0], xmm11
000077a0e99d52d6  vmovaps [rsp+0xC0], xmm12
000077a0e99d52df  vmovaps [rsp+0xD0], xmm14
000077a0e99d52e8  vmovaps [rsp+0xE0], xmm15
000077a0e99d52f1  sub rsp, 0x40
000077a0e99d52f5  lea rdi, [rsp]
000077a0e99d52f9  lea rsi, [rsp+0x10]
000077a0e99d52fe  lea rdx, [rsp+0x20]
000077a0e99d5303  lea rcx, [rsp+0x30]
000077a0e99d5308  mov r8d, 0x00
000077a0e99d530e  lea r9, [r15+0x3A8]
000077a0e99d5315  movaps [rdi], xmm13
000077a0e99d5319  movaps [rsi], xmm12
000077a0e99d531d  movaps [rdx], xmm4
000077a0e99d5320  movaps [rcx], xmm15
000077a0e99d5324  mov rax, 0x60CAA235BA50
000077a0e99d532e  call rax
000077a0e99d5330  movaps xmm13, [rsp]
000077a0e99d5335  add rsp, 0x40
000077a0e99d5339  vmovaps xmm0, [rsp]
000077a0e99d533e  vmovaps xmm1, [rsp+0x10]
000077a0e99d5344  vmovaps xmm2, [rsp+0x20]
000077a0e99d534a  vmovaps xmm3, [rsp+0x30]
000077a0e99d5350  vmovaps xmm4, [rsp+0x40]
000077a0e99d5356  vmovaps xmm5, [rsp+0x50]
000077a0e99d535c  vmovaps xmm6, [rsp+0x60]
000077a0e99d5362  vmovaps xmm7, [rsp+0x70]
000077a0e99d5368  vmovaps xmm8, [rsp+0x80]
000077a0e99d5371  vmovaps xmm9, [rsp+0x90]
000077a0e99d537a  vmovaps xmm10, [rsp+0xA0]
000077a0e99d5383  vmovaps xmm11, [rsp+0xB0]
000077a0e99d538c  vmovaps xmm12, [rsp+0xC0]
000077a0e99d5395  vmovaps xmm14, [rsp+0xD0]
000077a0e99d539e  vmovaps xmm15, [rsp+0xE0]
000077a0e99d53a7  add rsp, 0xF0
000077a0e99d53ae  pop r11
000077a0e99d53b0  pop r10
000077a0e99d53b2  pop r9
000077a0e99d53b4  pop r8
000077a0e99d53b6  pop rsi
000077a0e99d53b7  pop rdi
000077a0e99d53b8  pop rdx
000077a0e99d53b9  pop rcx
000077a0e99d53ba  pop rax
000077a0e99d53bb  add rsp, 0x08
000077a0e99d53bf  jmp 0x000077A0E99D2FF6
000077a0e99d53c4  sub rsp, 0x08
000077a0e99d53c8  push rax
000077a0e99d53c9  push rcx
000077a0e99d53ca  push rdx
000077a0e99d53cb  push rdi
000077a0e99d53cc  push rsi
000077a0e99d53cd  push r8
000077a0e99d53cf  push r9
000077a0e99d53d1  push r10
000077a0e99d53d3  push r11
000077a0e99d53d5  sub rsp, 0xF0
000077a0e99d53dc  vmovaps [rsp], xmm0
000077a0e99d53e1  vmovaps [rsp+0x10], xmm1
000077a0e99d53e7  vmovaps [rsp+0x20], xmm2
000077a0e99d53ed  vmovaps [rsp+0x30], xmm3
000077a0e99d53f3  vmovaps [rsp+0x40], xmm4
000077a0e99d53f9  vmovaps [rsp+0x50], xmm5
000077a0e99d53ff  vmovaps [rsp+0x60], xmm6
000077a0e99d5405  vmovaps [rsp+0x70], xmm7
000077a0e99d540b  vmovaps [rsp+0x80], xmm8
000077a0e99d5414  vmovaps [rsp+0x90], xmm9
000077a0e99d541d  vmovaps [rsp+0xA0], xmm10
000077a0e99d5426  vmovaps [rsp+0xB0], xmm11
000077a0e99d542f  vmovaps [rsp+0xC0], xmm13
000077a0e99d5438  vmovaps [rsp+0xD0], xmm14
000077a0e99d5441  vmovaps [rsp+0xE0], xmm15
000077a0e99d544a  sub rsp, 0x40
000077a0e99d544e  lea rdi, [rsp]
000077a0e99d5452  lea rsi, [rsp+0x10]
000077a0e99d5457  lea rdx, [rsp+0x20]
000077a0e99d545c  lea rcx, [rsp+0x30]
000077a0e99d5461  mov r8d, 0x00
000077a0e99d5467  lea r9, [r15+0x3A8]
000077a0e99d546e  movaps [rdi], xmm12
000077a0e99d5472  movaps [rsi], xmm7
000077a0e99d5475  movaps [rdx], xmm1
000077a0e99d5478  movaps [rcx], xmm15
000077a0e99d547c  mov rax, 0x60CAA235BA50
000077a0e99d5486  call rax
000077a0e99d5488  movaps xmm12, [rsp]
000077a0e99d548d  add rsp, 0x40
000077a0e99d5491  vmovaps xmm0, [rsp]
000077a0e99d5496  vmovaps xmm1, [rsp+0x10]
000077a0e99d549c  vmovaps xmm2, [rsp+0x20]
000077a0e99d54a2  vmovaps xmm3, [rsp+0x30]
000077a0e99d54a8  vmovaps xmm4, [rsp+0x40]
000077a0e99d54ae  vmovaps xmm5, [rsp+0x50]
000077a0e99d54b4  vmovaps xmm6, [rsp+0x60]
000077a0e99d54ba  vmovaps xmm7, [rsp+0x70]
000077a0e99d54c0  vmovaps xmm8, [rsp+0x80]
000077a0e99d54c9  vmovaps xmm9, [rsp+0x90]
000077a0e99d54d2  vmovaps xmm10, [rsp+0xA0]
000077a0e99d54db  vmovaps xmm11, [rsp+0xB0]
000077a0e99d54e4  vmovaps xmm13, [rsp+0xC0]
000077a0e99d54ed  vmovaps xmm14, [rsp+0xD0]
000077a0e99d54f6  vmovaps xmm15, [rsp+0xE0]
000077a0e99d54ff  add rsp, 0xF0
000077a0e99d5506  pop r11
000077a0e99d5508  pop r10
000077a0e99d550a  pop r9
000077a0e99d550c  pop r8
000077a0e99d550e  pop rsi
000077a0e99d550f  pop rdi
000077a0e99d5510  pop rdx
000077a0e99d5511  pop rcx
000077a0e99d5512  pop rax
000077a0e99d5513  add rsp, 0x08
000077a0e99d5517  jmp 0x000077A0E99D301F
000077a0e99d551c  call 0x000077A0E97FF430
000077a0e99d5521  jmp 0x000077A0E99D3029
000077a0e99d5526  call 0x000077A0E980E760
000077a0e99d552b  jmp 0x000077A0E99D3033
000077a0e99d5530  sub rsp, 0x08
000077a0e99d5534  push rax
000077a0e99d5535  push rcx
000077a0e99d5536  push rdx
000077a0e99d5537  push rdi
000077a0e99d5538  push rsi
000077a0e99d5539  push r8
000077a0e99d553b  push r9
000077a0e99d553d  push r10
000077a0e99d553f  push r11
000077a0e99d5541  sub rsp, 0xF0
000077a0e99d5548  vmovaps [rsp], xmm0
000077a0e99d554d  vmovaps [rsp+0x10], xmm1
000077a0e99d5553  vmovaps [rsp+0x20], xmm2
000077a0e99d5559  vmovaps [rsp+0x30], xmm3
000077a0e99d555f  vmovaps [rsp+0x40], xmm4
000077a0e99d5565  vmovaps [rsp+0x50], xmm5
000077a0e99d556b  vmovaps [rsp+0x60], xmm6
000077a0e99d5571  vmovaps [rsp+0x70], xmm8
000077a0e99d5577  vmovaps [rsp+0x80], xmm9
000077a0e99d5580  vmovaps [rsp+0x90], xmm10
000077a0e99d5589  vmovaps [rsp+0xA0], xmm11
000077a0e99d5592  vmovaps [rsp+0xB0], xmm12
000077a0e99d559b  vmovaps [rsp+0xC0], xmm13
000077a0e99d55a4  vmovaps [rsp+0xD0], xmm14
000077a0e99d55ad  vmovaps [rsp+0xE0], xmm15
000077a0e99d55b6  sub rsp, 0x40
000077a0e99d55ba  lea rdi, [rsp]
000077a0e99d55be  lea rsi, [rsp+0x10]
000077a0e99d55c3  lea rdx, [rsp+0x20]
000077a0e99d55c8  lea rcx, [rsp+0x30]
000077a0e99d55cd  mov r8d, 0x00
000077a0e99d55d3  lea r9, [r15+0x3A8]
000077a0e99d55da  movaps [rdi], xmm7
000077a0e99d55dd  movaps [rsi], xmm6
000077a0e99d55e0  movaps [rdx], xmm8
000077a0e99d55e4  movaps [rcx], xmm9
000077a0e99d55e8  mov rax, 0x60CAA235BA50
000077a0e99d55f2  call rax
000077a0e99d55f4  movaps xmm7, [rsp]
000077a0e99d55f8  add rsp, 0x40
000077a0e99d55fc  vmovaps xmm0, [rsp]
000077a0e99d5601  vmovaps xmm1, [rsp+0x10]
000077a0e99d5607  vmovaps xmm2, [rsp+0x20]
000077a0e99d560d  vmovaps xmm3, [rsp+0x30]
000077a0e99d5613  vmovaps xmm4, [rsp+0x40]
000077a0e99d5619  vmovaps xmm5, [rsp+0x50]
000077a0e99d561f  vmovaps xmm6, [rsp+0x60]
000077a0e99d5625  vmovaps xmm8, [rsp+0x70]
000077a0e99d562b  vmovaps xmm9, [rsp+0x80]
000077a0e99d5634  vmovaps xmm10, [rsp+0x90]
000077a0e99d563d  vmovaps xmm11, [rsp+0xA0]
000077a0e99d5646  vmovaps xmm12, [rsp+0xB0]
000077a0e99d564f  vmovaps xmm13, [rsp+0xC0]
000077a0e99d5658  vmovaps xmm14, [rsp+0xD0]
000077a0e99d5661  vmovaps xmm15, [rsp+0xE0]
000077a0e99d566a  add rsp, 0xF0
000077a0e99d5671  pop r11
000077a0e99d5673  pop r10
000077a0e99d5675  pop r9
000077a0e99d5677  pop r8
000077a0e99d5679  pop rsi
000077a0e99d567a  pop rdi
000077a0e99d567b  pop rdx
000077a0e99d567c  pop rcx
000077a0e99d567d  pop rax
000077a0e99d567e  add rsp, 0x08
000077a0e99d5682  jmp 0x000077A0E99D305D
000077a0e99d5687  sub rsp, 0x08
000077a0e99d568b  push rax
000077a0e99d568c  push rcx
000077a0e99d568d  push rdx
000077a0e99d568e  push rdi
000077a0e99d568f  push rsi
000077a0e99d5690  push r8
000077a0e99d5692  push r9
000077a0e99d5694  push r10
000077a0e99d5696  push r11
000077a0e99d5698  sub rsp, 0xF0
000077a0e99d569f  vmovaps [rsp], xmm0
000077a0e99d56a4  vmovaps [rsp+0x10], xmm1
000077a0e99d56aa  vmovaps [rsp+0x20], xmm2
000077a0e99d56b0  vmovaps [rsp+0x30], xmm3
000077a0e99d56b6  vmovaps [rsp+0x40], xmm4
000077a0e99d56bc  vmovaps [rsp+0x50], xmm5
000077a0e99d56c2  vmovaps [rsp+0x60], xmm6
000077a0e99d56c8  vmovaps [rsp+0x70], xmm7
000077a0e99d56ce  vmovaps [rsp+0x80], xmm9
000077a0e99d56d7  vmovaps [rsp+0x90], xmm10
000077a0e99d56e0  vmovaps [rsp+0xA0], xmm11
000077a0e99d56e9  vmovaps [rsp+0xB0], xmm12
000077a0e99d56f2  vmovaps [rsp+0xC0], xmm13
000077a0e99d56fb  vmovaps [rsp+0xD0], xmm14
000077a0e99d5704  vmovaps [rsp+0xE0], xmm15
000077a0e99d570d  sub rsp, 0x40
000077a0e99d5711  lea rdi, [rsp]
000077a0e99d5715  lea rsi, [rsp+0x10]
000077a0e99d571a  lea rdx, [rsp+0x20]
000077a0e99d571f  lea rcx, [rsp+0x30]
000077a0e99d5724  mov r8d, 0x00
000077a0e99d572a  lea r9, [r15+0x3A8]
000077a0e99d5731  movaps [rdi], xmm8
000077a0e99d5735  movaps [rsi], xmm10
000077a0e99d5739  movaps [rdx], xmm14
000077a0e99d573d  movaps [rcx], xmm9
000077a0e99d5741  mov rax, 0x60CAA235BA50
000077a0e99d574b  call rax
000077a0e99d574d  movaps xmm8, [rsp]
000077a0e99d5752  add rsp, 0x40
000077a0e99d5756  vmovaps xmm0, [rsp]
000077a0e99d575b  vmovaps xmm1, [rsp+0x10]
000077a0e99d5761  vmovaps xmm2, [rsp+0x20]
000077a0e99d5767  vmovaps xmm3, [rsp+0x30]
000077a0e99d576d  vmovaps xmm4, [rsp+0x40]
000077a0e99d5773  vmovaps xmm5, [rsp+0x50]
000077a0e99d5779  vmovaps xmm6, [rsp+0x60]
000077a0e99d577f  vmovaps xmm7, [rsp+0x70]
000077a0e99d5785  vmovaps xmm9, [rsp+0x80]
000077a0e99d578e  vmovaps xmm10, [rsp+0x90]
000077a0e99d5797  vmovaps xmm11, [rsp+0xA0]
000077a0e99d57a0  vmovaps xmm12, [rsp+0xB0]
000077a0e99d57a9  vmovaps xmm13, [rsp+0xC0]
000077a0e99d57b2  vmovaps xmm14, [rsp+0xD0]
000077a0e99d57bb  vmovaps xmm15, [rsp+0xE0]
000077a0e99d57c4  add rsp, 0xF0
000077a0e99d57cb  pop r11
000077a0e99d57cd  pop r10
000077a0e99d57cf  pop r9
000077a0e99d57d1  pop r8
000077a0e99d57d3  pop rsi
000077a0e99d57d4  pop rdi
000077a0e99d57d5  pop rdx
000077a0e99d57d6  pop rcx
000077a0e99d57d7  pop rax
000077a0e99d57d8  add rsp, 0x08
000077a0e99d57dc  jmp 0x000077A0E99D3083
000077a0e99d57e1  sub rsp, 0x08
000077a0e99d57e5  push rax
000077a0e99d57e6  push rcx
000077a0e99d57e7  push rdx
000077a0e99d57e8  push rdi
000077a0e99d57e9  push rsi
000077a0e99d57ea  push r8
000077a0e99d57ec  push r9
000077a0e99d57ee  push r10
000077a0e99d57f0  push r11
000077a0e99d57f2  sub rsp, 0xF0
000077a0e99d57f9  vmovaps [rsp], xmm0
000077a0e99d57fe  vmovaps [rsp+0x10], xmm1
000077a0e99d5804  vmovaps [rsp+0x20], xmm2
000077a0e99d580a  vmovaps [rsp+0x30], xmm3
000077a0e99d5810  vmovaps [rsp+0x40], xmm4
000077a0e99d5816  vmovaps [rsp+0x50], xmm5
000077a0e99d581c  vmovaps [rsp+0x60], xmm6
000077a0e99d5822  vmovaps [rsp+0x70], xmm7
000077a0e99d5828  vmovaps [rsp+0x80], xmm8
000077a0e99d5831  vmovaps [rsp+0x90], xmm9
000077a0e99d583a  vmovaps [rsp+0xA0], xmm11
000077a0e99d5843  vmovaps [rsp+0xB0], xmm12
000077a0e99d584c  vmovaps [rsp+0xC0], xmm13
000077a0e99d5855  vmovaps [rsp+0xD0], xmm14
000077a0e99d585e  vmovaps [rsp+0xE0], xmm15
000077a0e99d5867  sub rsp, 0x40
000077a0e99d586b  lea rdi, [rsp]
000077a0e99d586f  lea rsi, [rsp+0x10]
000077a0e99d5874  lea rdx, [rsp+0x20]
000077a0e99d5879  lea rcx, [rsp+0x30]
000077a0e99d587e  mov r8d, 0x00
000077a0e99d5884  lea r9, [r15+0x3A8]
000077a0e99d588b  movaps [rdi], xmm10
000077a0e99d588f  movaps [rsi], xmm13
000077a0e99d5893  movaps [rdx], xmm11
000077a0e99d5897  movaps [rcx], xmm14
000077a0e99d589b  mov rax, 0x60CAA235BA50
000077a0e99d58a5  call rax
000077a0e99d58a7  movaps xmm10, [rsp]
000077a0e99d58ac  add rsp, 0x40
000077a0e99d58b0  vmovaps xmm0, [rsp]
000077a0e99d58b5  vmovaps xmm1, [rsp+0x10]
000077a0e99d58bb  vmovaps xmm2, [rsp+0x20]
000077a0e99d58c1  vmovaps xmm3, [rsp+0x30]
000077a0e99d58c7  vmovaps xmm4, [rsp+0x40]
000077a0e99d58cd  vmovaps xmm5, [rsp+0x50]
000077a0e99d58d3  vmovaps xmm6, [rsp+0x60]
000077a0e99d58d9  vmovaps xmm7, [rsp+0x70]
000077a0e99d58df  vmovaps xmm8, [rsp+0x80]
000077a0e99d58e8  vmovaps xmm9, [rsp+0x90]
000077a0e99d58f1  vmovaps xmm11, [rsp+0xA0]
000077a0e99d58fa  vmovaps xmm12, [rsp+0xB0]
000077a0e99d5903  vmovaps xmm13, [rsp+0xC0]
000077a0e99d590c  vmovaps xmm14, [rsp+0xD0]
000077a0e99d5915  vmovaps xmm15, [rsp+0xE0]
000077a0e99d591e  add rsp, 0xF0
000077a0e99d5925  pop r11
000077a0e99d5927  pop r10
000077a0e99d5929  pop r9
000077a0e99d592b  pop r8
000077a0e99d592d  pop rsi
000077a0e99d592e  pop rdi
000077a0e99d592f  pop rdx
000077a0e99d5930  pop rcx
000077a0e99d5931  pop rax
000077a0e99d5932  add rsp, 0x08
000077a0e99d5936  jmp 0x000077A0E99D30A9
000077a0e99d593b  sub rsp, 0x08
000077a0e99d593f  push rax
000077a0e99d5940  push rcx
000077a0e99d5941  push rdx
000077a0e99d5942  push rdi
000077a0e99d5943  push rsi
000077a0e99d5944  push r8
000077a0e99d5946  push r9
000077a0e99d5948  push r10
000077a0e99d594a  push r11
000077a0e99d594c  sub rsp, 0xF0
000077a0e99d5953  vmovaps [rsp], xmm0
000077a0e99d5958  vmovaps [rsp+0x10], xmm1
000077a0e99d595e  vmovaps [rsp+0x20], xmm2
000077a0e99d5964  vmovaps [rsp+0x30], xmm3
000077a0e99d596a  vmovaps [rsp+0x40], xmm4
000077a0e99d5970  vmovaps [rsp+0x50], xmm5
000077a0e99d5976  vmovaps [rsp+0x60], xmm6
000077a0e99d597c  vmovaps [rsp+0x70], xmm7
000077a0e99d5982  vmovaps [rsp+0x80], xmm8
000077a0e99d598b  vmovaps [rsp+0x90], xmm9
000077a0e99d5994  vmovaps [rsp+0xA0], xmm10
000077a0e99d599d  vmovaps [rsp+0xB0], xmm11
000077a0e99d59a6  vmovaps [rsp+0xC0], xmm12
000077a0e99d59af  vmovaps [rsp+0xD0], xmm14
000077a0e99d59b8  vmovaps [rsp+0xE0], xmm15
000077a0e99d59c1  sub rsp, 0x40
000077a0e99d59c5  lea rdi, [rsp]
000077a0e99d59c9  lea rsi, [rsp+0x10]
000077a0e99d59ce  lea rdx, [rsp+0x20]
000077a0e99d59d3  lea rcx, [rsp+0x30]
000077a0e99d59d8  mov r8d, 0x00
000077a0e99d59de  lea r9, [r15+0x3A8]
000077a0e99d59e5  movaps [rdi], xmm13
000077a0e99d59e9  movaps [rsi], xmm12
000077a0e99d59ed  movaps [rdx], xmm15
000077a0e99d59f1  movaps [rcx], xmm14
000077a0e99d59f5  mov rax, 0x60CAA235BA50
000077a0e99d59ff  call rax
000077a0e99d5a01  movaps xmm13, [rsp]
000077a0e99d5a06  add rsp, 0x40
000077a0e99d5a0a  vmovaps xmm0, [rsp]
000077a0e99d5a0f  vmovaps xmm1, [rsp+0x10]
000077a0e99d5a15  vmovaps xmm2, [rsp+0x20]
000077a0e99d5a1b  vmovaps xmm3, [rsp+0x30]
000077a0e99d5a21  vmovaps xmm4, [rsp+0x40]
000077a0e99d5a27  vmovaps xmm5, [rsp+0x50]
000077a0e99d5a2d  vmovaps xmm6, [rsp+0x60]
000077a0e99d5a33  vmovaps xmm7, [rsp+0x70]
000077a0e99d5a39  vmovaps xmm8, [rsp+0x80]
000077a0e99d5a42  vmovaps xmm9, [rsp+0x90]
000077a0e99d5a4b  vmovaps xmm10, [rsp+0xA0]
000077a0e99d5a54  vmovaps xmm11, [rsp+0xB0]
000077a0e99d5a5d  vmovaps xmm12, [rsp+0xC0]
000077a0e99d5a66  vmovaps xmm14, [rsp+0xD0]
000077a0e99d5a6f  vmovaps xmm15, [rsp+0xE0]
000077a0e99d5a78  add rsp, 0xF0
000077a0e99d5a7f  pop r11
000077a0e99d5a81  pop r10
000077a0e99d5a83  pop r9
000077a0e99d5a85  pop r8
000077a0e99d5a87  pop rsi
000077a0e99d5a88  pop rdi
000077a0e99d5a89  pop rdx
000077a0e99d5a8a  pop rcx
000077a0e99d5a8b  pop rax
000077a0e99d5a8c  add rsp, 0x08
000077a0e99d5a90  jmp 0x000077A0E99D30CF
000077a0e99d5a95  call 0x000077A0E980E760
000077a0e99d5a9a  jmp 0x000077A0E99D30DC
000077a0e99d5a9f  call 0x000077A0E980D4E0
000077a0e99d5aa4  jmp 0x000077A0E99D30E9
000077a0e99d5aa9  sub rsp, 0x08
000077a0e99d5aad  push rax
000077a0e99d5aae  push rcx
000077a0e99d5aaf  push rdx
000077a0e99d5ab0  push rdi
000077a0e99d5ab1  push rsi
000077a0e99d5ab2  push r8
000077a0e99d5ab4  push r9
000077a0e99d5ab6  push r10
000077a0e99d5ab8  push r11
000077a0e99d5aba  sub rsp, 0xF0
000077a0e99d5ac1  vmovaps [rsp], xmm0
000077a0e99d5ac6  vmovaps [rsp+0x10], xmm1
000077a0e99d5acc  vmovaps [rsp+0x20], xmm2
000077a0e99d5ad2  vmovaps [rsp+0x30], xmm3
000077a0e99d5ad8  vmovaps [rsp+0x40], xmm4
000077a0e99d5ade  vmovaps [rsp+0x50], xmm5
000077a0e99d5ae4  vmovaps [rsp+0x60], xmm6
000077a0e99d5aea  vmovaps [rsp+0x70], xmm7
000077a0e99d5af0  vmovaps [rsp+0x80], xmm8
000077a0e99d5af9  vmovaps [rsp+0x90], xmm9
000077a0e99d5b02  vmovaps [rsp+0xA0], xmm10
000077a0e99d5b0b  vmovaps [rsp+0xB0], xmm12
000077a0e99d5b14  vmovaps [rsp+0xC0], xmm13
000077a0e99d5b1d  vmovaps [rsp+0xD0], xmm14
000077a0e99d5b26  vmovaps [rsp+0xE0], xmm15
000077a0e99d5b2f  sub rsp, 0x40
000077a0e99d5b33  lea rdi, [rsp]
000077a0e99d5b37  lea rsi, [rsp+0x10]
000077a0e99d5b3c  lea rdx, [rsp+0x20]
000077a0e99d5b41  lea rcx, [rsp+0x30]
000077a0e99d5b46  mov r8d, 0x00
000077a0e99d5b4c  lea r9, [r15+0x3A8]
000077a0e99d5b53  movaps [rdi], xmm11
000077a0e99d5b57  movaps [rsi], xmm7
000077a0e99d5b5a  movaps [rdx], xmm1
000077a0e99d5b5d  movaps [rcx], xmm12
000077a0e99d5b61  mov rax, 0x60CAA235BA50
000077a0e99d5b6b  call rax
000077a0e99d5b6d  movaps xmm11, [rsp]
000077a0e99d5b72  add rsp, 0x40
000077a0e99d5b76  vmovaps xmm0, [rsp]
000077a0e99d5b7b  vmovaps xmm1, [rsp+0x10]
000077a0e99d5b81  vmovaps xmm2, [rsp+0x20]
000077a0e99d5b87  vmovaps xmm3, [rsp+0x30]
000077a0e99d5b8d  vmovaps xmm4, [rsp+0x40]
000077a0e99d5b93  vmovaps xmm5, [rsp+0x50]
000077a0e99d5b99  vmovaps xmm6, [rsp+0x60]
000077a0e99d5b9f  vmovaps xmm7, [rsp+0x70]
000077a0e99d5ba5  vmovaps xmm8, [rsp+0x80]
000077a0e99d5bae  vmovaps xmm9, [rsp+0x90]
000077a0e99d5bb7  vmovaps xmm10, [rsp+0xA0]
000077a0e99d5bc0  vmovaps xmm12, [rsp+0xB0]
000077a0e99d5bc9  vmovaps xmm13, [rsp+0xC0]
000077a0e99d5bd2  vmovaps xmm14, [rsp+0xD0]
000077a0e99d5bdb  vmovaps xmm15, [rsp+0xE0]
000077a0e99d5be4  add rsp, 0xF0
000077a0e99d5beb  pop r11
000077a0e99d5bed  pop r10
000077a0e99d5bef  pop r9
000077a0e99d5bf1  pop r8
000077a0e99d5bf3  pop rsi
000077a0e99d5bf4  pop rdi
000077a0e99d5bf5  pop rdx
000077a0e99d5bf6  pop rcx
000077a0e99d5bf7  pop rax
000077a0e99d5bf8  add rsp, 0x08
000077a0e99d5bfc  jmp 0x000077A0E99D3122
000077a0e99d5c01  call 0x000077A0E97FF430
000077a0e99d5c06  jmp 0x000077A0E99D3134
000077a0e99d5c0b  sub rsp, 0x08
000077a0e99d5c0f  push rax
000077a0e99d5c10  push rcx
000077a0e99d5c11  push rdx
000077a0e99d5c12  push rdi
000077a0e99d5c13  push rsi
000077a0e99d5c14  push r8
000077a0e99d5c16  push r9
000077a0e99d5c18  push r10
000077a0e99d5c1a  push r11
000077a0e99d5c1c  sub rsp, 0xF0
000077a0e99d5c23  vmovaps [rsp], xmm0
000077a0e99d5c28  vmovaps [rsp+0x10], xmm1
000077a0e99d5c2e  vmovaps [rsp+0x20], xmm2
000077a0e99d5c34  vmovaps [rsp+0x30], xmm3
000077a0e99d5c3a  vmovaps [rsp+0x40], xmm4
000077a0e99d5c40  vmovaps [rsp+0x50], xmm5
000077a0e99d5c46  vmovaps [rsp+0x60], xmm6
000077a0e99d5c4c  vmovaps [rsp+0x70], xmm7
000077a0e99d5c52  vmovaps [rsp+0x80], xmm8
000077a0e99d5c5b  vmovaps [rsp+0x90], xmm10
000077a0e99d5c64  vmovaps [rsp+0xA0], xmm11
000077a0e99d5c6d  vmovaps [rsp+0xB0], xmm12
000077a0e99d5c76  vmovaps [rsp+0xC0], xmm13
000077a0e99d5c7f  vmovaps [rsp+0xD0], xmm14
000077a0e99d5c88  vmovaps [rsp+0xE0], xmm15
000077a0e99d5c91  sub rsp, 0x40
000077a0e99d5c95  lea rdi, [rsp]
000077a0e99d5c99  lea rsi, [rsp+0x10]
000077a0e99d5c9e  lea rdx, [rsp+0x20]
000077a0e99d5ca3  lea rcx, [rsp+0x30]
000077a0e99d5ca8  mov r8d, 0x00
000077a0e99d5cae  lea r9, [r15+0x3A8]
000077a0e99d5cb5  movaps [rdi], xmm9
000077a0e99d5cb9  movaps [rsi], xmm8
000077a0e99d5cbd  movaps [rdx], xmm14
000077a0e99d5cc1  movaps [rcx], xmm12
000077a0e99d5cc5  mov rax, 0x60CAA235BA50
000077a0e99d5ccf  call rax
000077a0e99d5cd1  movaps xmm9, [rsp]
000077a0e99d5cd6  add rsp, 0x40
000077a0e99d5cda  vmovaps xmm0, [rsp]
000077a0e99d5cdf  vmovaps xmm1, [rsp+0x10]
000077a0e99d5ce5  vmovaps xmm2, [rsp+0x20]
000077a0e99d5ceb  vmovaps xmm3, [rsp+0x30]
000077a0e99d5cf1  vmovaps xmm4, [rsp+0x40]
000077a0e99d5cf7  vmovaps xmm5, [rsp+0x50]
000077a0e99d5cfd  vmovaps xmm6, [rsp+0x60]
000077a0e99d5d03  vmovaps xmm7, [rsp+0x70]
000077a0e99d5d09  vmovaps xmm8, [rsp+0x80]
000077a0e99d5d12  vmovaps xmm10, [rsp+0x90]
000077a0e99d5d1b  vmovaps xmm11, [rsp+0xA0]
000077a0e99d5d24  vmovaps xmm12, [rsp+0xB0]
000077a0e99d5d2d  vmovaps xmm13, [rsp+0xC0]
000077a0e99d5d36  vmovaps xmm14, [rsp+0xD0]
000077a0e99d5d3f  vmovaps xmm15, [rsp+0xE0]
000077a0e99d5d48  add rsp, 0xF0
000077a0e99d5d4f  pop r11
000077a0e99d5d51  pop r10
000077a0e99d5d53  pop r9
000077a0e99d5d55  pop r8
000077a0e99d5d57  pop rsi
000077a0e99d5d58  pop rdi
000077a0e99d5d59  pop rdx
000077a0e99d5d5a  pop rcx
000077a0e99d5d5b  pop rax
000077a0e99d5d5c  add rsp, 0x08
000077a0e99d5d60  jmp 0x000077A0E99D3165
000077a0e99d5d65  sub rsp, 0x08
000077a0e99d5d69  push rax
000077a0e99d5d6a  push rcx
000077a0e99d5d6b  push rdx
000077a0e99d5d6c  push rdi
000077a0e99d5d6d  push rsi
000077a0e99d5d6e  push r8
000077a0e99d5d70  push r9
000077a0e99d5d72  push r10
000077a0e99d5d74  push r11
000077a0e99d5d76  sub rsp, 0xF0
000077a0e99d5d7d  vmovaps [rsp], xmm0
000077a0e99d5d82  vmovaps [rsp+0x10], xmm1
000077a0e99d5d88  vmovaps [rsp+0x20], xmm2
000077a0e99d5d8e  vmovaps [rsp+0x30], xmm3
000077a0e99d5d94  vmovaps [rsp+0x40], xmm4
000077a0e99d5d9a  vmovaps [rsp+0x50], xmm5
000077a0e99d5da0  vmovaps [rsp+0x60], xmm6
000077a0e99d5da6  vmovaps [rsp+0x70], xmm7
000077a0e99d5dac  vmovaps [rsp+0x80], xmm8
000077a0e99d5db5  vmovaps [rsp+0x90], xmm9
000077a0e99d5dbe  vmovaps [rsp+0xA0], xmm10
000077a0e99d5dc7  vmovaps [rsp+0xB0], xmm11
000077a0e99d5dd0  vmovaps [rsp+0xC0], xmm13
000077a0e99d5dd9  vmovaps [rsp+0xD0], xmm14
000077a0e99d5de2  vmovaps [rsp+0xE0], xmm15
000077a0e99d5deb  sub rsp, 0x40
000077a0e99d5def  lea rdi, [rsp]
000077a0e99d5df3  lea rsi, [rsp+0x10]
000077a0e99d5df8  lea rdx, [rsp+0x20]
000077a0e99d5dfd  lea rcx, [rsp+0x30]
000077a0e99d5e02  mov r8d, 0x00
000077a0e99d5e08  lea r9, [r15+0x3A8]
000077a0e99d5e0f  movaps [rdi], xmm12
000077a0e99d5e13  movaps [rsi], xmm10
000077a0e99d5e17  movaps [rdx], xmm15
000077a0e99d5e1b  movaps [rcx], xmm14
000077a0e99d5e1f  mov rax, 0x60CAA235BA50
000077a0e99d5e29  call rax
000077a0e99d5e2b  movaps xmm12, [rsp]
000077a0e99d5e30  add rsp, 0x40
000077a0e99d5e34  vmovaps xmm0, [rsp]
000077a0e99d5e39  vmovaps xmm1, [rsp+0x10]
000077a0e99d5e3f  vmovaps xmm2, [rsp+0x20]
000077a0e99d5e45  vmovaps xmm3, [rsp+0x30]
000077a0e99d5e4b  vmovaps xmm4, [rsp+0x40]
000077a0e99d5e51  vmovaps xmm5, [rsp+0x50]
000077a0e99d5e57  vmovaps xmm6, [rsp+0x60]
000077a0e99d5e5d  vmovaps xmm7, [rsp+0x70]
000077a0e99d5e63  vmovaps xmm8, [rsp+0x80]
000077a0e99d5e6c  vmovaps xmm9, [rsp+0x90]
000077a0e99d5e75  vmovaps xmm10, [rsp+0xA0]
000077a0e99d5e7e  vmovaps xmm11, [rsp+0xB0]
000077a0e99d5e87  vmovaps xmm13, [rsp+0xC0]
000077a0e99d5e90  vmovaps xmm14, [rsp+0xD0]
000077a0e99d5e99  vmovaps xmm15, [rsp+0xE0]
000077a0e99d5ea2  add rsp, 0xF0
000077a0e99d5ea9  pop r11
000077a0e99d5eab  pop r10
000077a0e99d5ead  pop r9
000077a0e99d5eaf  pop r8
000077a0e99d5eb1  pop rsi
000077a0e99d5eb2  pop rdi
000077a0e99d5eb3  pop rdx
000077a0e99d5eb4  pop rcx
000077a0e99d5eb5  pop rax
000077a0e99d5eb6  add rsp, 0x08
000077a0e99d5eba  jmp 0x000077A0E99D3196
000077a0e99d5ebf  sub rsp, 0x08
000077a0e99d5ec3  push rax
000077a0e99d5ec4  push rcx
000077a0e99d5ec5  push rdx
000077a0e99d5ec6  push rdi
000077a0e99d5ec7  push rsi
000077a0e99d5ec8  push r8
000077a0e99d5eca  push r9
000077a0e99d5ecc  push r10
000077a0e99d5ece  push r11
000077a0e99d5ed0  sub rsp, 0xF0
000077a0e99d5ed7  vmovaps [rsp], xmm0
000077a0e99d5edc  vmovaps [rsp+0x10], xmm1
000077a0e99d5ee2  vmovaps [rsp+0x20], xmm2
000077a0e99d5ee8  vmovaps [rsp+0x30], xmm3
000077a0e99d5eee  vmovaps [rsp+0x40], xmm4
000077a0e99d5ef4  vmovaps [rsp+0x50], xmm5
000077a0e99d5efa  vmovaps [rsp+0x60], xmm6
000077a0e99d5f00  vmovaps [rsp+0x70], xmm7
000077a0e99d5f06  vmovaps [rsp+0x80], xmm8
000077a0e99d5f0f  vmovaps [rsp+0x90], xmm9
000077a0e99d5f18  vmovaps [rsp+0xA0], xmm10
000077a0e99d5f21  vmovaps [rsp+0xB0], xmm11
000077a0e99d5f2a  vmovaps [rsp+0xC0], xmm12
000077a0e99d5f33  vmovaps [rsp+0xD0], xmm13
000077a0e99d5f3c  vmovaps [rsp+0xE0], xmm15
000077a0e99d5f45  sub rsp, 0x40
000077a0e99d5f49  lea rdi, [rsp]
000077a0e99d5f4d  lea rsi, [rsp+0x10]
000077a0e99d5f52  lea rdx, [rsp+0x20]
000077a0e99d5f57  lea rcx, [rsp+0x30]
000077a0e99d5f5c  mov r8d, 0x00
000077a0e99d5f62  lea r9, [r15+0x3A8]
000077a0e99d5f69  movaps [rdi], xmm14
000077a0e99d5f6d  movaps [rsi], xmm13
000077a0e99d5f71  movaps [rdx], xmm1
000077a0e99d5f74  movaps [rcx], xmm15
000077a0e99d5f78  mov rax, 0x60CAA235BA50
000077a0e99d5f82  call rax
000077a0e99d5f84  movaps xmm14, [rsp]
000077a0e99d5f89  add rsp, 0x40
000077a0e99d5f8d  vmovaps xmm0, [rsp]
000077a0e99d5f92  vmovaps xmm1, [rsp+0x10]
000077a0e99d5f98  vmovaps xmm2, [rsp+0x20]
000077a0e99d5f9e  vmovaps xmm3, [rsp+0x30]
000077a0e99d5fa4  vmovaps xmm4, [rsp+0x40]
000077a0e99d5faa  vmovaps xmm5, [rsp+0x50]
000077a0e99d5fb0  vmovaps xmm6, [rsp+0x60]
000077a0e99d5fb6  vmovaps xmm7, [rsp+0x70]
000077a0e99d5fbc  vmovaps xmm8, [rsp+0x80]
000077a0e99d5fc5  vmovaps xmm9, [rsp+0x90]
000077a0e99d5fce  vmovaps xmm10, [rsp+0xA0]
000077a0e99d5fd7  vmovaps xmm11, [rsp+0xB0]
000077a0e99d5fe0  vmovaps xmm12, [rsp+0xC0]
000077a0e99d5fe9  vmovaps xmm13, [rsp+0xD0]
000077a0e99d5ff2  vmovaps xmm15, [rsp+0xE0]
000077a0e99d5ffb  add rsp, 0xF0
000077a0e99d6002  pop r11
000077a0e99d6004  pop r10
000077a0e99d6006  pop r9
000077a0e99d6008  pop r8
000077a0e99d600a  pop rsi
000077a0e99d600b  pop rdi
000077a0e99d600c  pop rdx
000077a0e99d600d  pop rcx
000077a0e99d600e  pop rax
000077a0e99d600f  add rsp, 0x08
000077a0e99d6013  jmp 0x000077A0E99D31C7
000077a0e99d6018  call 0x000077A0E98079B0
000077a0e99d601d  jmp 0x000077A0E99D31DA
000077a0e99d6022  call 0x000077A0E980B100
000077a0e99d6027  jmp 0x000077A0E99D31E5
000077a0e99d602c  call 0x000077A0E9809E90
000077a0e99d6031  jmp 0x000077A0E99D31F0
000077a0e99d6036  call 0x000077A0E980D600
000077a0e99d603b  jmp 0x000077A0E99D31FB
000077a0e99d6040  int3
000077a0e99d6041  nop [rax+rax*1], ax
000077a0e99d604a  nop [rax+rax*1], ax
000077a0e99d6050  mov rax, [r15+0x40]
000077a0e99d6054  mov r14, [r15+0x58]
000077a0e99d6058  lea r12, [rax+r14*1]
000077a0e99d605c  vxorps xmm1, xmm1, xmm1
000077a0e99d6060  vpbroadcastq xmm1, xmm1
000077a0e99d6065  vxorps xmm15, xmm15, xmm15
000077a0e99d606a  vpbroadcastq xmm15, xmm15
000077a0e99d606f  lea rax, [r12+0x30]
000077a0e99d6074  mov r11, [r13+rax*1]
000077a0e99d6079  lea rax, [r12+0x38]
000077a0e99d607e  mov r10, [r13+rax*1]
000077a0e99d6083  movq xmm14, r11
000077a0e99d6088  movq xmm13, r10
000077a0e99d608d  movq xmm14, xmm14
000077a0e99d6092  movq xmm13, xmm13
000077a0e99d6097  vmovaps [rsp+0x10], xmm13
000077a0e99d609d  movq xmm13, xmm13
000077a0e99d60a2  movaps [r15+0x270], xmm13
000077a0e99d60aa  movaps xmm13, [r15+0x160]
000077a0e99d60b2  vmovaps [rsp+0x20], xmm13
000077a0e99d60b8  vmovaps xmm12, [rsp+0x20]
000077a0e99d60be  por xmm13, xmm12
000077a0e99d60c3  lea rax, [r12+0x20]
000077a0e99d60c8  mov r11, [r13+rax*1]
000077a0e99d60cd  lea rax, [r12+0x28]
000077a0e99d60d2  mov r10, [r13+rax*1]
000077a0e99d60d7  movq xmm12, r11
000077a0e99d60dc  movq xmm11, r10
000077a0e99d60e1  movq xmm12, xmm12
000077a0e99d60e6  movq xmm11, xmm11
000077a0e99d60eb  movaps xmm10, [r15+0x2D0]
000077a0e99d60f3  vmovaps [rsp+0x20], xmm10
000077a0e99d60f9  vmovaps xmm9, [rsp+0x20]
000077a0e99d60ff  por xmm10, xmm9
000077a0e99d6104  movaps xmm9, [r15+0x300]
000077a0e99d610c  vmovaps [rsp+0x20], xmm9
000077a0e99d6112  vmovaps xmm8, [rsp+0x20]
000077a0e99d6118  por xmm9, xmm8
000077a0e99d611d  movaps xmm8, [r15+0x2B0]
000077a0e99d6125  vmovaps [rsp+0x20], xmm8
000077a0e99d612b  vmovaps xmm7, [rsp+0x20]
000077a0e99d6131  por xmm8, xmm7
000077a0e99d6136  movaps xmm7, [r15+0x180]
000077a0e99d613e  vmovaps [rsp+0x20], xmm7
000077a0e99d6144  vmovaps xmm6, [rsp+0x20]
000077a0e99d614a  por xmm7, xmm6
000077a0e99d614e  lea rax, [r12+0x10]
000077a0e99d6153  mov r11, [r13+rax*1]
000077a0e99d6158  lea rax, [r12+0x18]
000077a0e99d615d  mov r10, [r13+rax*1]
000077a0e99d6162  movq xmm6, r11
000077a0e99d6167  movq xmm5, r10
000077a0e99d616c  movq xmm6, xmm6
000077a0e99d6170  movq xmm5, xmm5
000077a0e99d6174  movaps xmm4, [r15+0x200]
000077a0e99d617c  vmovaps [rsp+0x20], xmm4
000077a0e99d6182  vmovaps xmm3, [rsp+0x20]
000077a0e99d6188  por xmm4, xmm3
000077a0e99d618c  movaps xmm3, [r15+0x1F0]
000077a0e99d6194  vmovaps [rsp+0x20], xmm3
000077a0e99d619a  vmovaps xmm2, [rsp+0x20]
000077a0e99d61a0  por xmm3, xmm2
000077a0e99d61a4  movaps xmm2, [r15+0x2E0]
000077a0e99d61ac  vmovaps [rsp+0x20], xmm2
000077a0e99d61b2  vmovaps [rsp+0x30], xmm1
000077a0e99d61b8  vmovaps xmm1, [rsp+0x20]
000077a0e99d61be  por xmm2, xmm1
000077a0e99d61c2  movaps xmm1, [r15+0x2A0]
000077a0e99d61ca  vmovaps [rsp+0x20], xmm1
000077a0e99d61d0  vmovaps [rsp+0x40], xmm15
000077a0e99d61d6  vmovaps xmm15, [rsp+0x20]
000077a0e99d61dc  por xmm1, xmm15
000077a0e99d61e1  movaps xmm15, [r15+0x280]
000077a0e99d61e9  vmovaps [rsp+0x20], xmm15
000077a0e99d61ef  vmovaps [rsp+0x50], xmm1
000077a0e99d61f5  vmovaps xmm1, [rsp+0x20]
000077a0e99d61fb  por xmm15, xmm1
000077a0e99d6200  movaps xmm1, [r15+0x1C0]
000077a0e99d6208  vmovaps [rsp+0x20], xmm1
000077a0e99d620e  vmovaps [rsp+0x60], xmm15
000077a0e99d6214  vmovaps xmm15, [rsp+0x20]
000077a0e99d621a  por xmm1, xmm15
000077a0e99d621f  movaps xmm15, [r15+0x210]
000077a0e99d6227  vmovaps [rsp+0x20], xmm15
000077a0e99d622d  vmovaps [rsp+0x70], xmm1
000077a0e99d6233  vmovaps xmm1, [rsp+0x20]
000077a0e99d6239  por xmm15, xmm1
000077a0e99d623e  mov rax, [r13+r12*1]
000077a0e99d6243  vmovq xmm1, rax
000077a0e99d6248  vpbroadcastq xmm1, xmm1
000077a0e99d624d  vmovaps [rsp+0x20], xmm1
000077a0e99d6253  vxorps xmm1, xmm1, xmm1
000077a0e99d6257  vpbroadcastq xmm1, xmm1
000077a0e99d625c  mov rax, [r15+0xF8]
000077a0e99d6263  vmovaps [rsp+0x80], xmm1
000077a0e99d626c  movups xmm1, [r13+rax*1]
000077a0e99d6272  vmovaps [rsp+0x90], xmm1
000077a0e99d627b  vxorps xmm1, xmm1, xmm1
000077a0e99d627f  vpbroadcastq xmm1, xmm1
000077a0e99d6284  lea r11, [r12+0x08]
000077a0e99d6289  mov r12, [r13+r11*1]
000077a0e99d628e  vmovaps [rsp+0xA0], xmm1
000077a0e99d6297  movq xmm1, r12
000077a0e99d629c  movaps [r15+0x240], xmm1
000077a0e99d62a4  mov r12, [r15+0x50]
000077a0e99d62a8  lea r11, [r12+r14*1]
000077a0e99d62ac  mov [r15+0x60], r11
000077a0e99d62b0  lea r12, [r14+0x40]
000077a0e99d62b4  mov [r15+0x58], r12
000077a0e99d62b8  vmovaps xmm1, [rsp+0x30]
000077a0e99d62be  vmovaps [rsp+0x30], xmm15
000077a0e99d62c4  vmovaps xmm15, [rsp+0x90]
000077a0e99d62cd  vmovaps [rsp+0x90], xmm14
000077a0e99d62d6  vmovaps xmm14, [rsp+0x20]
000077a0e99d62dc  vmovaps [rsp+0x20], xmm13
000077a0e99d62e2  vmovaps [rsp+0xB0], xmm12
000077a0e99d62eb  movaps xmm13, xmm1
000077a0e99d62ef  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d62fa  vptest xmm12, xmm12
000077a0e99d62ff  jnz 0x000077A0E99D6D9C
000077a0e99d6305  movaps xmm1, [r15+0x250]
000077a0e99d630d  vmovaps xmm15, [rsp+0x40]
000077a0e99d6313  vmovaps [rsp+0x40], xmm13
000077a0e99d6319  movaps xmm12, xmm15
000077a0e99d631d  vfmadd231pd xmm12, xmm1, xmm14
000077a0e99d6322  vcmppd xmm13, xmm12, xmm12, 0x03
000077a0e99d6328  vptest xmm13, xmm13
000077a0e99d632d  jnz 0x000077A0E99D6EF5
000077a0e99d6333  movaps xmm15, [r15+0x1E0]
000077a0e99d633b  vmovaps [rsp+0xC0], xmm15
000077a0e99d6344  vmovaps xmm13, [rsp+0xC0]
000077a0e99d634d  por xmm15, xmm13
000077a0e99d6352  movaps xmm13, [r15+0x1D0]
000077a0e99d635a  vmovaps [rsp+0xC0], xmm13
000077a0e99d6363  vmovaps [rsp+0xD0], xmm1
000077a0e99d636c  vmovaps xmm1, [rsp+0xC0]
000077a0e99d6375  por xmm13, xmm1
000077a0e99d637a  movaps xmm1, [r15+0x2C0]
000077a0e99d6382  vmovaps [rsp+0xC0], xmm1
000077a0e99d638b  vmovaps [rsp+0xE0], xmm15
000077a0e99d6394  vmovaps xmm15, [rsp+0xC0]
000077a0e99d639d  por xmm1, xmm15
000077a0e99d63a2  movaps xmm15, [r15+0x290]
000077a0e99d63aa  vmovaps [rsp+0xC0], xmm15
000077a0e99d63b3  vmovaps [rsp+0xF0], xmm1
000077a0e99d63bc  vmovaps xmm1, [rsp+0xC0]
000077a0e99d63c5  por xmm15, xmm1
000077a0e99d63ca  movaps xmm1, [r15+0x260]
000077a0e99d63d2  vmovaps [rsp+0xC0], xmm1
000077a0e99d63db  vmovaps [rsp+0x100], xmm15
000077a0e99d63e4  vmovaps xmm15, [rsp+0xC0]
000077a0e99d63ed  por xmm1, xmm15
000077a0e99d63f2  vmovaps xmm15, [rsp+0xD0]
000077a0e99d63fb  vmovaps [rsp+0xC0], xmm1
000077a0e99d6404  vmovaps xmm1, [rsp+0xD0]
000077a0e99d640d  por xmm15, xmm1
000077a0e99d6412  lea r14, [rax+0xC0]
000077a0e99d6419  movups xmm1, [r13+r14*1]
000077a0e99d641f  mov [rsp+0xD0], rax
000077a0e99d6427  xor eax, eax
000077a0e99d6429  mov r14d, 0x200
000077a0e99d642f  cmp r12, r14
000077a0e99d6432  cmc
000077a0e99d6433  lahf
000077a0e99d6434  seto al
000077a0e99d6437  mov [r15+0x108], eax
000077a0e99d643e  vmovaps [rsp+0x110], xmm1
000077a0e99d6447  vmovaps xmm1, [rsp+0x80]
000077a0e99d6450  vmovaps [rsp+0x80], xmm15
000077a0e99d6459  vmovaps xmm15, [rsp+0x110]
000077a0e99d6462  vmovaps [rsp+0x110], xmm13
000077a0e99d646b  vmovaps [rsp+0x120], xmm12
000077a0e99d6474  movaps xmm13, xmm1
000077a0e99d6478  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d647d  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d6483  vptest xmm12, xmm12
000077a0e99d6488  jnz 0x000077A0E99D7058
000077a0e99d648e  mov rax, [rsp+0xD0]
000077a0e99d6496  lea r14, [rax+0xB0]
000077a0e99d649d  movups xmm1, [r13+r14*1]
000077a0e99d64a3  vmovaps xmm15, [rsp+0xA0]
000077a0e99d64ac  vmovaps [rsp+0xA0], xmm13
000077a0e99d64b5  movaps xmm12, xmm15
000077a0e99d64b9  vfmadd231pd xmm12, xmm1, xmm14
000077a0e99d64be  vcmppd xmm13, xmm12, xmm12, 0x03
000077a0e99d64c4  vptest xmm13, xmm13
000077a0e99d64c9  jnz 0x000077A0E99D71BB
000077a0e99d64cf  vmovaps xmm1, [rsp+0x30]
000077a0e99d64d5  vmovaps xmm15, [rsp+0x30]
000077a0e99d64db  por xmm1, xmm15
000077a0e99d64e0  movaps [r15+0x210], xmm1
000077a0e99d64e8  vmovaps xmm15, [rsp+0x70]
000077a0e99d64ee  vmovaps xmm14, [rsp+0x70]
000077a0e99d64f4  por xmm15, xmm14
000077a0e99d64f9  movaps [r15+0x1C0], xmm15
000077a0e99d6501  vmovaps xmm14, [rsp+0x60]
000077a0e99d6507  vmovaps xmm13, [rsp+0x60]
000077a0e99d650d  por xmm14, xmm13
000077a0e99d6512  movaps [r15+0x280], xmm14
000077a0e99d651a  vmovaps xmm13, [rsp+0x50]
000077a0e99d6520  vmovaps [rsp+0x30], xmm1
000077a0e99d6526  vmovaps xmm1, [rsp+0x50]
000077a0e99d652c  por xmm13, xmm1
000077a0e99d6531  movaps [r15+0x2A0], xmm13
000077a0e99d6539  vmovaps [rsp+0x50], xmm2
000077a0e99d653f  vmovaps xmm1, [rsp+0x50]
000077a0e99d6545  por xmm2, xmm1
000077a0e99d6549  movaps [r15+0x2E0], xmm2
000077a0e99d6551  vmovaps [rsp+0x50], xmm3
000077a0e99d6557  vmovaps xmm1, [rsp+0x50]
000077a0e99d655d  por xmm3, xmm1
000077a0e99d6561  movaps [r15+0x1F0], xmm3
000077a0e99d6569  vmovaps xmm1, [rsp+0x80]
000077a0e99d6572  vmovaps [rsp+0x50], xmm15
000077a0e99d6578  vmovaps xmm15, [rsp+0x80]
000077a0e99d6581  por xmm1, xmm15
000077a0e99d6586  movaps [r15+0x250], xmm1
000077a0e99d658e  vmovaps xmm1, [rsp+0xC0]
000077a0e99d6597  vmovaps xmm15, [rsp+0xC0]
000077a0e99d65a0  por xmm1, xmm15
000077a0e99d65a5  movaps [r15+0x260], xmm1
000077a0e99d65ad  vmovaps xmm15, [rsp+0x100]
000077a0e99d65b6  vmovaps [rsp+0x60], xmm1
000077a0e99d65bc  vmovaps xmm1, [rsp+0x100]
000077a0e99d65c5  por xmm15, xmm1
000077a0e99d65ca  movaps [r15+0x290], xmm15
000077a0e99d65d2  vmovaps xmm1, [rsp+0xF0]
000077a0e99d65db  vmovaps [rsp+0x70], xmm15
000077a0e99d65e1  vmovaps xmm15, [rsp+0xF0]
000077a0e99d65ea  por xmm1, xmm15
000077a0e99d65ef  movaps [r15+0x2C0], xmm1
000077a0e99d65f7  movq xmm15, qword ptr [r15+0x240]
000077a0e99d6600  vmovaps [rsp+0x80], xmm15
000077a0e99d6609  vpermilpd xmm15, xmm15, 0x00
000077a0e99d660f  vmovaps [rsp+0xC0], xmm1
000077a0e99d6618  vmovaps xmm1, [rsp+0x40]
000077a0e99d661e  vmovaps [rsp+0x40], xmm15
000077a0e99d6624  vmovaps xmm15, [rsp+0x30]
000077a0e99d662a  vmovaps [rsp+0x30], xmm14
000077a0e99d6630  vmovaps xmm14, [rsp+0x40]
000077a0e99d6636  vmovaps [rsp+0x40], xmm13
000077a0e99d663c  vmovaps [rsp+0xD0], xmm12
000077a0e99d6645  movaps xmm13, xmm1
000077a0e99d6649  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d664e  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d6654  vptest xmm12, xmm12
000077a0e99d6659  jnz 0x000077A0E99D7314
000077a0e99d665f  vmovaps xmm1, [rsp+0x80]
000077a0e99d6668  vpermilpd xmm1, xmm1, 0x00
000077a0e99d666e  vmovaps xmm15, [rsp+0xA0]
000077a0e99d6677  movaps xmm14, xmm15
000077a0e99d667b  vfmadd231pd xmm14, xmm2, xmm1
000077a0e99d6680  vcmppd xmm12, xmm14, xmm14, 0x03
000077a0e99d6686  vptest xmm12, xmm12
000077a0e99d668b  jnz 0x000077A0E99D746D
000077a0e99d6691  vmovaps xmm1, [rsp+0x80]
000077a0e99d669a  vpermilpd xmm1, xmm1, 0x00
000077a0e99d66a0  vmovaps xmm15, [rsp+0x120]
000077a0e99d66a9  vmovaps xmm12, [rsp+0x50]
000077a0e99d66af  vmovaps [rsp+0x50], xmm14
000077a0e99d66b5  movaps xmm2, xmm15
000077a0e99d66b9  vfmadd231pd xmm2, xmm12, xmm1
000077a0e99d66be  vcmppd xmm14, xmm2, xmm2, 0x03
000077a0e99d66c3  vptest xmm14, xmm14
000077a0e99d66c8  jnz 0x000077A0E99D75C5
000077a0e99d66ce  vmovaps xmm1, [rsp+0x110]
000077a0e99d66d7  vmovaps xmm15, [rsp+0x110]
000077a0e99d66e0  por xmm1, xmm15
000077a0e99d66e5  movaps [r15+0x1D0], xmm1
000077a0e99d66ed  vmovaps xmm15, [rsp+0x80]
000077a0e99d66f6  vpermilpd xmm15, xmm15, 0x00
000077a0e99d66fc  vmovaps xmm14, [rsp+0xD0]
000077a0e99d6705  vmovaps [rsp+0x80], xmm1
000077a0e99d670e  movaps xmm12, xmm14
000077a0e99d6712  vfmadd231pd xmm12, xmm3, xmm15
000077a0e99d6717  vcmppd xmm1, xmm12, xmm12, 0x03
000077a0e99d671d  vptest xmm1, xmm1
000077a0e99d6722  jnz 0x000077A0E99D771C
000077a0e99d6728  vmovaps [rsp+0xA0], xmm4
000077a0e99d6731  vmovaps xmm1, [rsp+0xA0]
000077a0e99d673a  por xmm4, xmm1
000077a0e99d673e  movaps [r15+0x200], xmm4
000077a0e99d6746  vmovaps xmm1, [rsp+0xE0]
000077a0e99d674f  vmovaps xmm15, [rsp+0xE0]
000077a0e99d6758  por xmm1, xmm15
000077a0e99d675d  movaps [r15+0x1E0], xmm1
000077a0e99d6765  vmovaps [rsp+0xA0], xmm8
000077a0e99d676e  vmovaps xmm1, [rsp+0xA0]
000077a0e99d6777  por xmm8, xmm1
000077a0e99d677c  movaps [r15+0x2B0], xmm8
000077a0e99d6784  vmovaps [rsp+0xA0], xmm9
000077a0e99d678d  vmovaps xmm1, [rsp+0xA0]
000077a0e99d6796  por xmm9, xmm1
000077a0e99d679b  movaps [r15+0x300], xmm9
000077a0e99d67a3  vmovaps [rsp+0xA0], xmm6
000077a0e99d67ac  vpermilpd xmm6, xmm6, 0x00
000077a0e99d67b2  vmovaps xmm14, [rsp+0x60]
000077a0e99d67b8  movaps xmm9, xmm13
000077a0e99d67bc  vfmadd231pd xmm9, xmm14, xmm6
000077a0e99d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
000077a0e99d67c7  vptest xmm3, xmm3
000077a0e99d67cc  jnz 0x000077A0E99D7875
000077a0e99d67d2  vmovaps xmm14, [rsp+0xA0]
000077a0e99d67db  vpermilpd xmm14, xmm14, 0x00
000077a0e99d67e1  vmovaps xmm13, [rsp+0x50]
000077a0e99d67e7  vmovaps xmm6, [rsp+0xC0]
000077a0e99d67f0  vmovaps [rsp+0x50], xmm1
000077a0e99d67f6  movaps xmm3, xmm13
000077a0e99d67fa  vfmadd231pd xmm3, xmm6, xmm14
000077a0e99d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
000077a0e99d6804  vptest xmm1, xmm1
000077a0e99d6809  jnz 0x000077A0E99D79CE
000077a0e99d680f  vmovaps xmm1, [rsp+0xA0]
000077a0e99d6818  vpermilpd xmm1, xmm1, 0x00
000077a0e99d681e  vmovaps xmm14, [rsp+0x30]
000077a0e99d6824  movaps xmm6, xmm2
000077a0e99d6827  vfmadd231pd xmm6, xmm14, xmm1
000077a0e99d682c  vcmppd xmm13, xmm6, xmm6, 0x03
000077a0e99d6831  vptest xmm13, xmm13
000077a0e99d6836  jnz 0x000077A0E99D7B25
000077a0e99d683c  vmovaps xmm1, [rsp+0xA0]
000077a0e99d6845  vpermilpd xmm1, xmm1, 0x00
000077a0e99d684b  vmovaps xmm14, [rsp+0x80]
000077a0e99d6854  movaps xmm13, xmm12
000077a0e99d6858  vfmadd231pd xmm13, xmm14, xmm1
000077a0e99d685d  vcmppd xmm2, xmm13, xmm13, 0x03
000077a0e99d6863  vptest xmm2, xmm2
000077a0e99d6868  jnz 0x000077A0E99D7C7B
000077a0e99d686e  vmovaps [rsp+0x30], xmm7
000077a0e99d6874  vmovaps xmm1, [rsp+0x30]
000077a0e99d687a  por xmm7, xmm1
000077a0e99d687e  movaps [r15+0x180], xmm7
000077a0e99d6886  vmovaps [rsp+0x30], xmm10
000077a0e99d688c  vmovaps xmm1, [rsp+0x30]
000077a0e99d6892  por xmm10, xmm1
000077a0e99d6897  movaps [r15+0x2D0], xmm10
000077a0e99d689f  vmovaps [rsp+0x30], xmm5
000077a0e99d68a5  vpermilpd xmm5, xmm5, 0x00
000077a0e99d68ab  vmovaps xmm14, [rsp+0x50]
000077a0e99d68b1  movaps xmm12, xmm3
000077a0e99d68b5  vfmadd231pd xmm12, xmm14, xmm5
000077a0e99d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
000077a0e99d68c0  vptest xmm10, xmm10
000077a0e99d68c5  jnz 0x000077A0E99D7DD4
000077a0e99d68cb  vmovaps xmm14, [rsp+0x30]
000077a0e99d68d1  vpermilpd xmm14, xmm14, 0x00
000077a0e99d68d7  movaps xmm10, xmm9
000077a0e99d68db  vfmadd231pd xmm10, xmm7, xmm14
000077a0e99d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
000077a0e99d68e6  vptest xmm5, xmm5
000077a0e99d68eb  jnz 0x000077A0E99D7F2C
000077a0e99d68f1  lea r14, [rax+0x80]
000077a0e99d68f8  movups xmm14, [r13+r14*1]
000077a0e99d68fe  movaps [r15+0x2F0], xmm14
000077a0e99d6906  vmovaps xmm9, [rsp+0x30]
000077a0e99d690c  vpermilpd xmm9, xmm9, 0x00
000077a0e99d6912  vmovaps xmm7, [rsp+0x70]
000077a0e99d6918  movaps xmm5, xmm6
000077a0e99d691b  vfmadd231pd xmm5, xmm7, xmm9
000077a0e99d6920  vcmppd xmm3, xmm5, xmm5, 0x03
000077a0e99d6925  vptest xmm3, xmm3
000077a0e99d692a  jnz 0x000077A0E99D808F
000077a0e99d6930  vmovaps xmm9, [rsp+0x30]
000077a0e99d6936  vpermilpd xmm9, xmm9, 0x00
000077a0e99d693c  movaps xmm7, xmm13
000077a0e99d6940  vfmadd231pd xmm7, xmm1, xmm9
000077a0e99d6945  vcmppd xmm6, xmm7, xmm7, 0x03
000077a0e99d694a  vptest xmm6, xmm6
000077a0e99d694f  jnz 0x000077A0E99D81E5
000077a0e99d6955  vmovaps xmm1, [rsp+0x20]
000077a0e99d695b  vmovaps xmm13, [rsp+0x20]
000077a0e99d6961  por xmm1, xmm13
000077a0e99d6966  movaps [r15+0x160], xmm1
000077a0e99d696e  lea r14, [rax+0x40]
000077a0e99d6972  movups xmm13, [r13+r14*1]
000077a0e99d6978  lea r14, [rax+0x50]
000077a0e99d697c  movups xmm9, [r13+r14*1]
000077a0e99d6982  movaps [r15+0x1B0], xmm13
000077a0e99d698a  movaps [r15+0x1A0], xmm9
000077a0e99d6992  movaps xmm6, [r15+0x190]
000077a0e99d699a  vmovaps xmm3, [rsp+0xB0]
000077a0e99d69a3  vpermilpd xmm3, xmm3, 0x00
000077a0e99d69a9  vmovaps [rsp+0x20], xmm1
000077a0e99d69af  movaps xmm2, xmm12
000077a0e99d69b3  vfmadd231pd xmm2, xmm6, xmm3
000077a0e99d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
000077a0e99d69bd  vptest xmm1, xmm1
000077a0e99d69c2  jnz 0x000077A0E99D8350
000077a0e99d69c8  vmovaps xmm1, [rsp+0xB0]
000077a0e99d69d1  vpermilpd xmm1, xmm1, 0x00
000077a0e99d69d7  vmovaps xmm12, [rsp+0x20]
000077a0e99d69dd  movaps xmm6, xmm10
000077a0e99d69e1  vfmadd231pd xmm6, xmm12, xmm1
000077a0e99d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
000077a0e99d69eb  vptest xmm3, xmm3
000077a0e99d69f0  jnz 0x000077A0E99D84A6
000077a0e99d69f6  vmovaps xmm1, [rsp+0xB0]
000077a0e99d69ff  vpermilpd xmm1, xmm1, 0x00
000077a0e99d6a05  vmovaps xmm12, [rsp+0x40]
000077a0e99d6a0b  movaps xmm10, xmm5
000077a0e99d6a0f  vfmadd231pd xmm10, xmm12, xmm1
000077a0e99d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
000077a0e99d6a1a  vptest xmm3, xmm3
000077a0e99d6a1f  jnz 0x000077A0E99D85FD
000077a0e99d6a25  vmovaps xmm1, [rsp+0xB0]
000077a0e99d6a2e  vpermilpd xmm1, xmm1, 0x00
000077a0e99d6a34  movaps xmm12, xmm7
000077a0e99d6a38  vfmadd231pd xmm12, xmm15, xmm1
000077a0e99d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
000077a0e99d6a43  vptest xmm5, xmm5
000077a0e99d6a48  jnz 0x000077A0E99D8755
000077a0e99d6a4e  lea r14, [rax+0x60]
000077a0e99d6a52  movups xmm1, [r13+r14*1]
000077a0e99d6a58  lea r14, [rax+0x70]
000077a0e99d6a5c  movups xmm15, [r13+r14*1]
000077a0e99d6a62  movaps [r15+0x150], xmm1
000077a0e99d6a6a  movaps [r15+0x120], xmm15
000077a0e99d6a72  vmovaps [rsp+0x20], xmm11
000077a0e99d6a78  vpermilpd xmm11, xmm11, 0x00
000077a0e99d6a7e  movaps xmm7, xmm2
000077a0e99d6a81  vfmadd231pd xmm7, xmm9, xmm11
000077a0e99d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
000077a0e99d6a8b  vptest xmm5, xmm5
000077a0e99d6a90  jnz 0x000077A0E99D88C1
000077a0e99d6a96  vmovaps xmm11, [rsp+0x20]
000077a0e99d6a9c  vpermilpd xmm11, xmm11, 0x00
000077a0e99d6aa2  movaps xmm9, xmm6
000077a0e99d6aa6  vfmadd231pd xmm9, xmm1, xmm11
000077a0e99d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
000077a0e99d6ab1  vptest xmm5, xmm5
000077a0e99d6ab6  jnz 0x000077A0E99D8A18
000077a0e99d6abc  vmovaps xmm1, [rsp+0x20]
000077a0e99d6ac2  vpermilpd xmm1, xmm1, 0x00
000077a0e99d6ac8  movaps xmm11, xmm10
000077a0e99d6acc  vfmadd231pd xmm11, xmm8, xmm1
000077a0e99d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
000077a0e99d6ad7  vptest xmm6, xmm6
000077a0e99d6adc  jnz 0x000077A0E99D8B70
000077a0e99d6ae2  vmovaps xmm1, [rsp+0x20]
000077a0e99d6ae8  vpermilpd xmm1, xmm1, 0x00
000077a0e99d6aee  movaps xmm10, xmm12
000077a0e99d6af2  vfmadd231pd xmm10, xmm13, xmm1
000077a0e99d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
000077a0e99d6afd  vptest xmm8, xmm8
000077a0e99d6b02  jnz 0x000077A0E99D8CC9
000077a0e99d6b08  lea r14, [rax+0x20]
000077a0e99d6b0c  movups xmm1, [r13+r14*1]
000077a0e99d6b12  lea r14, [rax+0x30]
000077a0e99d6b16  movups xmm13, [r13+r14*1]
000077a0e99d6b1c  vmovaps xmm12, [rsp+0x90]
000077a0e99d6b25  vpermilpd xmm12, xmm12, 0x00
000077a0e99d6b2b  movaps xmm8, xmm7
000077a0e99d6b2f  vfmadd231pd xmm8, xmm4, xmm12
000077a0e99d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
000077a0e99d6b3a  vptest xmm6, xmm6
000077a0e99d6b3f  jnz 0x000077A0E99D8E36
000077a0e99d6b45  vmovaps xmm12, [rsp+0x90]
000077a0e99d6b4e  vpermilpd xmm12, xmm12, 0x00
000077a0e99d6b54  movaps xmm7, xmm9
000077a0e99d6b58  vfmadd231pd xmm7, xmm14, xmm12
000077a0e99d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
000077a0e99d6b62  vptest xmm6, xmm6
000077a0e99d6b67  jnz 0x000077A0E99D8F8E
000077a0e99d6b6d  vmovaps xmm14, [rsp+0x90]
000077a0e99d6b76  vpermilpd xmm14, xmm14, 0x00
000077a0e99d6b7c  movaps xmm12, xmm11
000077a0e99d6b80  vfmadd231pd xmm12, xmm15, xmm14
000077a0e99d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
000077a0e99d6b8b  vptest xmm9, xmm9
000077a0e99d6b90  jnz 0x000077A0E99D90E6
000077a0e99d6b96  vmovaps xmm15, [rsp+0x90]
000077a0e99d6b9f  vpermilpd xmm15, xmm15, 0x00
000077a0e99d6ba5  movaps xmm11, xmm10
000077a0e99d6ba9  vfmadd231pd xmm11, xmm13, xmm15
000077a0e99d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
000077a0e99d6bb4  vptest xmm14, xmm14
000077a0e99d6bb9  jnz 0x000077A0E99D9240
000077a0e99d6bbf  lea r14, [rax+0x90]
000077a0e99d6bc6  movups xmm15, [r13+r14*1]
000077a0e99d6bcc  lea r14, [rax+0xA0]
000077a0e99d6bd3  movups xmm14, [r13+r14*1]
000077a0e99d6bd9  movaps [r15+0x140], xmm15
000077a0e99d6be1  movaps [r15+0x130], xmm14
000077a0e99d6be9  vmovaps xmm13, [rsp+0x10]
000077a0e99d6bef  vpermilpd xmm13, xmm13, 0x00
000077a0e99d6bf5  movaps xmm10, xmm8
000077a0e99d6bf9  vfmadd231pd xmm10, xmm1, xmm13
000077a0e99d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
000077a0e99d6c04  vptest xmm9, xmm9
000077a0e99d6c09  jnz 0x000077A0E99D93AE
000077a0e99d6c0f  movaps [r15+0x220], xmm10
000077a0e99d6c17  lea r14, [rax+0x10]
000077a0e99d6c1b  movups xmm1, [r13+r14*1]
000077a0e99d6c21  movaps [r15+0x240], xmm1
000077a0e99d6c29  vmovaps xmm13, [rsp+0x10]
000077a0e99d6c2f  vpermilpd xmm13, xmm13, 0x00
000077a0e99d6c35  movaps xmm9, xmm7
000077a0e99d6c39  vfmadd231pd xmm9, xmm14, xmm13
000077a0e99d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
000077a0e99d6c44  vptest xmm8, xmm8
000077a0e99d6c49  jnz 0x000077A0E99D9511
000077a0e99d6c4f  movaps [r15+0x110], xmm9
000077a0e99d6c57  vmovaps xmm14, [rsp+0x10]
000077a0e99d6c5d  vpermilpd xmm14, xmm14, 0x00
000077a0e99d6c63  movaps xmm13, xmm12
000077a0e99d6c67  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
000077a0e99d6c72  vptest xmm8, xmm8
000077a0e99d6c77  jnz 0x000077A0E99D966A
000077a0e99d6c7d  movaps [r15+0x170], xmm13
000077a0e99d6c85  vmovaps xmm15, [rsp+0x10]
000077a0e99d6c8b  vpermilpd xmm15, xmm15, 0x00
000077a0e99d6c91  movaps xmm14, xmm11
000077a0e99d6c95  vfmadd231pd xmm14, xmm1, xmm15
000077a0e99d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
000077a0e99d6ca0  vptest xmm12, xmm12
000077a0e99d6ca5  jnz 0x000077A0E99D97C4
000077a0e99d6cab  movaps [r15+0x230], xmm14
000077a0e99d6cb3  movups [r13+r11*1], xmm9
000077a0e99d6cb9  lea rax, [r11+0x10]
000077a0e99d6cbd  movups [r13+rax*1], xmm13
000077a0e99d6cc3  lea rax, [r11+0x20]
000077a0e99d6cc7  movups [r13+rax*1], xmm10
000077a0e99d6ccd  lea rax, [r11+0x30]
000077a0e99d6cd1  movups [r13+rax*1], xmm14
000077a0e99d6cd7  mov eax, [r15+0x108]
000077a0e99d6cde  sahf
000077a0e99d6cdf  jnz 0x000077A0E99D6D11
000077a0e99d6ce1  cmp dword ptr [r15+0x318], 0x00
000077a0e99d6ce9  jz 0x000077A0E99D9950
000077a0e99d6cef  nop [rax+rax*1], ax
000077a0e99d6cf8  nop [rax+rax*1], eax
000077a0e99d6d00  mov eax, 0x410664
000077a0e99d6d05  mov [r15+0x100], rax
000077a0e99d6d0c  jmp 0x000077A0E97FE110
000077a0e99d6d11  cmp dword ptr [r15+0x318], 0x00
000077a0e99d6d19  jz 0x000077A0E99D6050
000077a0e99d6d1f  nop [rax+rax*1], ax
000077a0e99d6d28  nop [rax+rax*1], eax
000077a0e99d6d30  mov eax, 0x4104F0
000077a0e99d6d35  mov [r15+0x100], rax
000077a0e99d6d3c  jmp 0x000077A0E97FE110
000077a0e99d6d41  int3
000077a0e99d6d42  call 0x000077A0E980A4B0
000077a0e99d6d47  jmp 0x000077A0E99D6079
000077a0e99d6d4c  call 0x000077A0E9809240
000077a0e99d6d51  jmp 0x000077A0E99D6083
000077a0e99d6d56  call 0x000077A0E980A4B0
000077a0e99d6d5b  jmp 0x000077A0E99D60CD
000077a0e99d6d60  call 0x000077A0E9809240
000077a0e99d6d65  jmp 0x000077A0E99D60D7
000077a0e99d6d6a  call 0x000077A0E980A4B0
000077a0e99d6d6f  jmp 0x000077A0E99D6158
000077a0e99d6d74  call 0x000077A0E9809240
000077a0e99d6d79  jmp 0x000077A0E99D6162
000077a0e99d6d7e  call 0x000077A0E98B47C0
000077a0e99d6d83  jmp 0x000077A0E99D6243
000077a0e99d6d88  call 0x000077A0E97FF430
000077a0e99d6d8d  jmp 0x000077A0E99D6272
000077a0e99d6d92  call 0x000077A0E98B0CE0
000077a0e99d6d97  jmp 0x000077A0E99D628E
000077a0e99d6d9c  sub rsp, 0x08
000077a0e99d6da0  push rax
000077a0e99d6da1  push rcx
000077a0e99d6da2  push rdx
000077a0e99d6da3  push rdi
000077a0e99d6da4  push rsi
000077a0e99d6da5  push r8
000077a0e99d6da7  push r9
000077a0e99d6da9  push r10
000077a0e99d6dab  push r11
000077a0e99d6dad  sub rsp, 0xF0
000077a0e99d6db4  vmovaps [rsp], xmm0
000077a0e99d6db9  vmovaps [rsp+0x10], xmm1
000077a0e99d6dbf  vmovaps [rsp+0x20], xmm2
000077a0e99d6dc5  vmovaps [rsp+0x30], xmm3
000077a0e99d6dcb  vmovaps [rsp+0x40], xmm4
000077a0e99d6dd1  vmovaps [rsp+0x50], xmm5
000077a0e99d6dd7  vmovaps [rsp+0x60], xmm6
000077a0e99d6ddd  vmovaps [rsp+0x70], xmm7
000077a0e99d6de3  vmovaps [rsp+0x80], xmm8
000077a0e99d6dec  vmovaps [rsp+0x90], xmm9
000077a0e99d6df5  vmovaps [rsp+0xA0], xmm10
000077a0e99d6dfe  vmovaps [rsp+0xB0], xmm11
000077a0e99d6e07  vmovaps [rsp+0xC0], xmm12
000077a0e99d6e10  vmovaps [rsp+0xD0], xmm14
000077a0e99d6e19  vmovaps [rsp+0xE0], xmm15
000077a0e99d6e22  sub rsp, 0x40
000077a0e99d6e26  lea rdi, [rsp]
000077a0e99d6e2a  lea rsi, [rsp+0x10]
000077a0e99d6e2f  lea rdx, [rsp+0x20]
000077a0e99d6e34  lea rcx, [rsp+0x30]
000077a0e99d6e39  mov r8d, 0x00
000077a0e99d6e3f  lea r9, [r15+0x3A8]
000077a0e99d6e46  movaps [rdi], xmm13
000077a0e99d6e4a  movaps [rsi], xmm1
000077a0e99d6e4d  movaps [rdx], xmm15
000077a0e99d6e51  movaps [rcx], xmm14
000077a0e99d6e55  mov rax, 0x60CAA235BA50
000077a0e99d6e5f  call rax
000077a0e99d6e61  movaps xmm13, [rsp]
000077a0e99d6e66  add rsp, 0x40
000077a0e99d6e6a  vmovaps xmm0, [rsp]
000077a0e99d6e6f  vmovaps xmm1, [rsp+0x10]
000077a0e99d6e75  vmovaps xmm2, [rsp+0x20]
000077a0e99d6e7b  vmovaps xmm3, [rsp+0x30]
000077a0e99d6e81  vmovaps xmm4, [rsp+0x40]
000077a0e99d6e87  vmovaps xmm5, [rsp+0x50]
000077a0e99d6e8d  vmovaps xmm6, [rsp+0x60]
000077a0e99d6e93  vmovaps xmm7, [rsp+0x70]
000077a0e99d6e99  vmovaps xmm8, [rsp+0x80]
000077a0e99d6ea2  vmovaps xmm9, [rsp+0x90]
000077a0e99d6eab  vmovaps xmm10, [rsp+0xA0]
000077a0e99d6eb4  vmovaps xmm11, [rsp+0xB0]
000077a0e99d6ebd  vmovaps xmm12, [rsp+0xC0]
000077a0e99d6ec6  vmovaps xmm14, [rsp+0xD0]
000077a0e99d6ecf  vmovaps xmm15, [rsp+0xE0]
000077a0e99d6ed8  add rsp, 0xF0
000077a0e99d6edf  pop r11
000077a0e99d6ee1  pop r10
000077a0e99d6ee3  pop r9
000077a0e99d6ee5  pop r8
000077a0e99d6ee7  pop rsi
000077a0e99d6ee8  pop rdi
000077a0e99d6ee9  pop rdx
000077a0e99d6eea  pop rcx
000077a0e99d6eeb  pop rax
000077a0e99d6eec  add rsp, 0x08
000077a0e99d6ef0  jmp 0x000077A0E99D6305
000077a0e99d6ef5  sub rsp, 0x08
000077a0e99d6ef9  push rax
000077a0e99d6efa  push rcx
000077a0e99d6efb  push rdx
000077a0e99d6efc  push rdi
000077a0e99d6efd  push rsi
000077a0e99d6efe  push r8
000077a0e99d6f00  push r9
000077a0e99d6f02  push r10
000077a0e99d6f04  push r11
000077a0e99d6f06  sub rsp, 0xF0
000077a0e99d6f0d  vmovaps [rsp], xmm0
000077a0e99d6f12  vmovaps [rsp+0x10], xmm1
000077a0e99d6f18  vmovaps [rsp+0x20], xmm2
000077a0e99d6f1e  vmovaps [rsp+0x30], xmm3
000077a0e99d6f24  vmovaps [rsp+0x40], xmm4
000077a0e99d6f2a  vmovaps [rsp+0x50], xmm5
000077a0e99d6f30  vmovaps [rsp+0x60], xmm6
000077a0e99d6f36  vmovaps [rsp+0x70], xmm7
000077a0e99d6f3c  vmovaps [rsp+0x80], xmm8
000077a0e99d6f45  vmovaps [rsp+0x90], xmm9
000077a0e99d6f4e  vmovaps [rsp+0xA0], xmm10
000077a0e99d6f57  vmovaps [rsp+0xB0], xmm11
000077a0e99d6f60  vmovaps [rsp+0xC0], xmm13
000077a0e99d6f69  vmovaps [rsp+0xD0], xmm14
000077a0e99d6f72  vmovaps [rsp+0xE0], xmm15
000077a0e99d6f7b  sub rsp, 0x40
000077a0e99d6f7f  lea rdi, [rsp]
000077a0e99d6f83  lea rsi, [rsp+0x10]
000077a0e99d6f88  lea rdx, [rsp+0x20]
000077a0e99d6f8d  lea rcx, [rsp+0x30]
000077a0e99d6f92  mov r8d, 0x00
000077a0e99d6f98  lea r9, [r15+0x3A8]
000077a0e99d6f9f  movaps [rdi], xmm12
000077a0e99d6fa3  movaps [rsi], xmm15
000077a0e99d6fa7  movaps [rdx], xmm1
000077a0e99d6faa  movaps [rcx], xmm14
000077a0e99d6fae  mov rax, 0x60CAA235BA50
000077a0e99d6fb8  call rax
000077a0e99d6fba  movaps xmm12, [rsp]
000077a0e99d6fbf  add rsp, 0x40
000077a0e99d6fc3  vmovaps xmm0, [rsp]
000077a0e99d6fc8  vmovaps xmm1, [rsp+0x10]
000077a0e99d6fce  vmovaps xmm2, [rsp+0x20]
000077a0e99d6fd4  vmovaps xmm3, [rsp+0x30]
000077a0e99d6fda  vmovaps xmm4, [rsp+0x40]
000077a0e99d6fe0  vmovaps xmm5, [rsp+0x50]
000077a0e99d6fe6  vmovaps xmm6, [rsp+0x60]
000077a0e99d6fec  vmovaps xmm7, [rsp+0x70]
000077a0e99d6ff2  vmovaps xmm8, [rsp+0x80]
000077a0e99d6ffb  vmovaps xmm9, [rsp+0x90]
000077a0e99d7004  vmovaps xmm10, [rsp+0xA0]
000077a0e99d700d  vmovaps xmm11, [rsp+0xB0]
000077a0e99d7016  vmovaps xmm13, [rsp+0xC0]
000077a0e99d701f  vmovaps xmm14, [rsp+0xD0]
000077a0e99d7028  vmovaps xmm15, [rsp+0xE0]
000077a0e99d7031  add rsp, 0xF0
000077a0e99d7038  pop r11
000077a0e99d703a  pop r10
000077a0e99d703c  pop r9
000077a0e99d703e  pop r8
000077a0e99d7040  pop rsi
000077a0e99d7041  pop rdi
000077a0e99d7042  pop rdx
000077a0e99d7043  pop rcx
000077a0e99d7044  pop rax
000077a0e99d7045  add rsp, 0x08
000077a0e99d7049  jmp 0x000077A0E99D6333
000077a0e99d704e  call 0x000077A0E98D64F0
000077a0e99d7053  jmp 0x000077A0E99D641F
000077a0e99d7058  sub rsp, 0x08
000077a0e99d705c  push rax
000077a0e99d705d  push rcx
000077a0e99d705e  push rdx
000077a0e99d705f  push rdi
000077a0e99d7060  push rsi
000077a0e99d7061  push r8
000077a0e99d7063  push r9
000077a0e99d7065  push r10
000077a0e99d7067  push r11
000077a0e99d7069  sub rsp, 0xF0
000077a0e99d7070  vmovaps [rsp], xmm0
000077a0e99d7075  vmovaps [rsp+0x10], xmm1
000077a0e99d707b  vmovaps [rsp+0x20], xmm2
000077a0e99d7081  vmovaps [rsp+0x30], xmm3
000077a0e99d7087  vmovaps [rsp+0x40], xmm4
000077a0e99d708d  vmovaps [rsp+0x50], xmm5
000077a0e99d7093  vmovaps [rsp+0x60], xmm6
000077a0e99d7099  vmovaps [rsp+0x70], xmm7
000077a0e99d709f  vmovaps [rsp+0x80], xmm8
000077a0e99d70a8  vmovaps [rsp+0x90], xmm9
000077a0e99d70b1  vmovaps [rsp+0xA0], xmm10
000077a0e99d70ba  vmovaps [rsp+0xB0], xmm11
000077a0e99d70c3  vmovaps [rsp+0xC0], xmm12
000077a0e99d70cc  vmovaps [rsp+0xD0], xmm14
000077a0e99d70d5  vmovaps [rsp+0xE0], xmm15
000077a0e99d70de  sub rsp, 0x40
000077a0e99d70e2  lea rdi, [rsp]
000077a0e99d70e6  lea rsi, [rsp+0x10]
000077a0e99d70eb  lea rdx, [rsp+0x20]
000077a0e99d70f0  lea rcx, [rsp+0x30]
000077a0e99d70f5  mov r8d, 0x00
000077a0e99d70fb  lea r9, [r15+0x3A8]
000077a0e99d7102  movaps [rdi], xmm13
000077a0e99d7106  movaps [rsi], xmm1
000077a0e99d7109  movaps [rdx], xmm15
000077a0e99d710d  movaps [rcx], xmm14
000077a0e99d7111  mov rax, 0x60CAA235BA50
000077a0e99d711b  call rax
000077a0e99d711d  movaps xmm13, [rsp]
000077a0e99d7122  add rsp, 0x40
000077a0e99d7126  vmovaps xmm0, [rsp]
000077a0e99d712b  vmovaps xmm1, [rsp+0x10]
000077a0e99d7131  vmovaps xmm2, [rsp+0x20]
000077a0e99d7137  vmovaps xmm3, [rsp+0x30]
000077a0e99d713d  vmovaps xmm4, [rsp+0x40]
000077a0e99d7143  vmovaps xmm5, [rsp+0x50]
000077a0e99d7149  vmovaps xmm6, [rsp+0x60]
000077a0e99d714f  vmovaps xmm7, [rsp+0x70]
000077a0e99d7155  vmovaps xmm8, [rsp+0x80]
000077a0e99d715e  vmovaps xmm9, [rsp+0x90]
000077a0e99d7167  vmovaps xmm10, [rsp+0xA0]
000077a0e99d7170  vmovaps xmm11, [rsp+0xB0]
000077a0e99d7179  vmovaps xmm12, [rsp+0xC0]
000077a0e99d7182  vmovaps xmm14, [rsp+0xD0]
000077a0e99d718b  vmovaps xmm15, [rsp+0xE0]
000077a0e99d7194  add rsp, 0xF0
000077a0e99d719b  pop r11
000077a0e99d719d  pop r10
000077a0e99d719f  pop r9
000077a0e99d71a1  pop r8
000077a0e99d71a3  pop rsi
000077a0e99d71a4  pop rdi
000077a0e99d71a5  pop rdx
000077a0e99d71a6  pop rcx
000077a0e99d71a7  pop rax
000077a0e99d71a8  add rsp, 0x08
000077a0e99d71ac  jmp 0x000077A0E99D648E
000077a0e99d71b1  call 0x000077A0E98D64F0
000077a0e99d71b6  jmp 0x000077A0E99D64A3
000077a0e99d71bb  sub rsp, 0x08
000077a0e99d71bf  push rax
000077a0e99d71c0  push rcx
000077a0e99d71c1  push rdx
000077a0e99d71c2  push rdi
000077a0e99d71c3  push rsi
000077a0e99d71c4  push r8
000077a0e99d71c6  push r9
000077a0e99d71c8  push r10
000077a0e99d71ca  push r11
000077a0e99d71cc  sub rsp, 0xF0
000077a0e99d71d3  vmovaps [rsp], xmm0
000077a0e99d71d8  vmovaps [rsp+0x10], xmm1
000077a0e99d71de  vmovaps [rsp+0x20], xmm2
000077a0e99d71e4  vmovaps [rsp+0x30], xmm3
000077a0e99d71ea  vmovaps [rsp+0x40], xmm4
000077a0e99d71f0  vmovaps [rsp+0x50], xmm5
000077a0e99d71f6  vmovaps [rsp+0x60], xmm6
000077a0e99d71fc  vmovaps [rsp+0x70], xmm7
000077a0e99d7202  vmovaps [rsp+0x80], xmm8
000077a0e99d720b  vmovaps [rsp+0x90], xmm9
000077a0e99d7214  vmovaps [rsp+0xA0], xmm10
000077a0e99d721d  vmovaps [rsp+0xB0], xmm11
000077a0e99d7226  vmovaps [rsp+0xC0], xmm13
000077a0e99d722f  vmovaps [rsp+0xD0], xmm14
000077a0e99d7238  vmovaps [rsp+0xE0], xmm15
000077a0e99d7241  sub rsp, 0x40
000077a0e99d7245  lea rdi, [rsp]
000077a0e99d7249  lea rsi, [rsp+0x10]
000077a0e99d724e  lea rdx, [rsp+0x20]
000077a0e99d7253  lea rcx, [rsp+0x30]
000077a0e99d7258  mov r8d, 0x00
000077a0e99d725e  lea r9, [r15+0x3A8]
000077a0e99d7265  movaps [rdi], xmm12
000077a0e99d7269  movaps [rsi], xmm15
000077a0e99d726d  movaps [rdx], xmm1
000077a0e99d7270  movaps [rcx], xmm14
000077a0e99d7274  mov rax, 0x60CAA235BA50
000077a0e99d727e  call rax
000077a0e99d7280  movaps xmm12, [rsp]
000077a0e99d7285  add rsp, 0x40
000077a0e99d7289  vmovaps xmm0, [rsp]
000077a0e99d728e  vmovaps xmm1, [rsp+0x10]
000077a0e99d7294  vmovaps xmm2, [rsp+0x20]
000077a0e99d729a  vmovaps xmm3, [rsp+0x30]
000077a0e99d72a0  vmovaps xmm4, [rsp+0x40]
000077a0e99d72a6  vmovaps xmm5, [rsp+0x50]
000077a0e99d72ac  vmovaps xmm6, [rsp+0x60]
000077a0e99d72b2  vmovaps xmm7, [rsp+0x70]
000077a0e99d72b8  vmovaps xmm8, [rsp+0x80]
000077a0e99d72c1  vmovaps xmm9, [rsp+0x90]
000077a0e99d72ca  vmovaps xmm10, [rsp+0xA0]
000077a0e99d72d3  vmovaps xmm11, [rsp+0xB0]
000077a0e99d72dc  vmovaps xmm13, [rsp+0xC0]
000077a0e99d72e5  vmovaps xmm14, [rsp+0xD0]
000077a0e99d72ee  vmovaps xmm15, [rsp+0xE0]
000077a0e99d72f7  add rsp, 0xF0
000077a0e99d72fe  pop r11
000077a0e99d7300  pop r10
000077a0e99d7302  pop r9
000077a0e99d7304  pop r8
000077a0e99d7306  pop rsi
000077a0e99d7307  pop rdi
000077a0e99d7308  pop rdx
000077a0e99d7309  pop rcx
000077a0e99d730a  pop rax
000077a0e99d730b  add rsp, 0x08
000077a0e99d730f  jmp 0x000077A0E99D64CF
000077a0e99d7314  sub rsp, 0x08
000077a0e99d7318  push rax
000077a0e99d7319  push rcx
000077a0e99d731a  push rdx
000077a0e99d731b  push rdi
000077a0e99d731c  push rsi
000077a0e99d731d  push r8
000077a0e99d731f  push r9
000077a0e99d7321  push r10
000077a0e99d7323  push r11
000077a0e99d7325  sub rsp, 0xF0
000077a0e99d732c  vmovaps [rsp], xmm0
000077a0e99d7331  vmovaps [rsp+0x10], xmm1
000077a0e99d7337  vmovaps [rsp+0x20], xmm2
000077a0e99d733d  vmovaps [rsp+0x30], xmm3
000077a0e99d7343  vmovaps [rsp+0x40], xmm4
000077a0e99d7349  vmovaps [rsp+0x50], xmm5
000077a0e99d734f  vmovaps [rsp+0x60], xmm6
000077a0e99d7355  vmovaps [rsp+0x70], xmm7
000077a0e99d735b  vmovaps [rsp+0x80], xmm8
000077a0e99d7364  vmovaps [rsp+0x90], xmm9
000077a0e99d736d  vmovaps [rsp+0xA0], xmm10
000077a0e99d7376  vmovaps [rsp+0xB0], xmm11
000077a0e99d737f  vmovaps [rsp+0xC0], xmm12
000077a0e99d7388  vmovaps [rsp+0xD0], xmm14
000077a0e99d7391  vmovaps [rsp+0xE0], xmm15
000077a0e99d739a  sub rsp, 0x40
000077a0e99d739e  lea rdi, [rsp]
000077a0e99d73a2  lea rsi, [rsp+0x10]
000077a0e99d73a7  lea rdx, [rsp+0x20]
000077a0e99d73ac  lea rcx, [rsp+0x30]
000077a0e99d73b1  mov r8d, 0x00
000077a0e99d73b7  lea r9, [r15+0x3A8]
000077a0e99d73be  movaps [rdi], xmm13
000077a0e99d73c2  movaps [rsi], xmm1
000077a0e99d73c5  movaps [rdx], xmm15
000077a0e99d73c9  movaps [rcx], xmm14
000077a0e99d73cd  mov rax, 0x60CAA235BA50
000077a0e99d73d7  call rax
000077a0e99d73d9  movaps xmm13, [rsp]
000077a0e99d73de  add rsp, 0x40
000077a0e99d73e2  vmovaps xmm0, [rsp]
000077a0e99d73e7  vmovaps xmm1, [rsp+0x10]
000077a0e99d73ed  vmovaps xmm2, [rsp+0x20]
000077a0e99d73f3  vmovaps xmm3, [rsp+0x30]
000077a0e99d73f9  vmovaps xmm4, [rsp+0x40]
000077a0e99d73ff  vmovaps xmm5, [rsp+0x50]
000077a0e99d7405  vmovaps xmm6, [rsp+0x60]
000077a0e99d740b  vmovaps xmm7, [rsp+0x70]
000077a0e99d7411  vmovaps xmm8, [rsp+0x80]
000077a0e99d741a  vmovaps xmm9, [rsp+0x90]
000077a0e99d7423  vmovaps xmm10, [rsp+0xA0]
000077a0e99d742c  vmovaps xmm11, [rsp+0xB0]
000077a0e99d7435  vmovaps xmm12, [rsp+0xC0]
000077a0e99d743e  vmovaps xmm14, [rsp+0xD0]
000077a0e99d7447  vmovaps xmm15, [rsp+0xE0]
000077a0e99d7450  add rsp, 0xF0
000077a0e99d7457  pop r11
000077a0e99d7459  pop r10
000077a0e99d745b  pop r9
000077a0e99d745d  pop r8
000077a0e99d745f  pop rsi
000077a0e99d7460  pop rdi
000077a0e99d7461  pop rdx
000077a0e99d7462  pop rcx
000077a0e99d7463  pop rax
000077a0e99d7464  add rsp, 0x08
000077a0e99d7468  jmp 0x000077A0E99D665F
000077a0e99d746d  sub rsp, 0x08
000077a0e99d7471  push rax
000077a0e99d7472  push rcx
000077a0e99d7473  push rdx
000077a0e99d7474  push rdi
000077a0e99d7475  push rsi
000077a0e99d7476  push r8
000077a0e99d7478  push r9
000077a0e99d747a  push r10
000077a0e99d747c  push r11
000077a0e99d747e  sub rsp, 0xF0
000077a0e99d7485  vmovaps [rsp], xmm0
000077a0e99d748a  vmovaps [rsp+0x10], xmm1
000077a0e99d7490  vmovaps [rsp+0x20], xmm2
000077a0e99d7496  vmovaps [rsp+0x30], xmm3
000077a0e99d749c  vmovaps [rsp+0x40], xmm4
000077a0e99d74a2  vmovaps [rsp+0x50], xmm5
000077a0e99d74a8  vmovaps [rsp+0x60], xmm6
000077a0e99d74ae  vmovaps [rsp+0x70], xmm7
000077a0e99d74b4  vmovaps [rsp+0x80], xmm8
000077a0e99d74bd  vmovaps [rsp+0x90], xmm9
000077a0e99d74c6  vmovaps [rsp+0xA0], xmm10
000077a0e99d74cf  vmovaps [rsp+0xB0], xmm11
000077a0e99d74d8  vmovaps [rsp+0xC0], xmm12
000077a0e99d74e1  vmovaps [rsp+0xD0], xmm13
000077a0e99d74ea  vmovaps [rsp+0xE0], xmm15
000077a0e99d74f3  sub rsp, 0x40
000077a0e99d74f7  lea rdi, [rsp]
000077a0e99d74fb  lea rsi, [rsp+0x10]
000077a0e99d7500  lea rdx, [rsp+0x20]
000077a0e99d7505  lea rcx, [rsp+0x30]
000077a0e99d750a  mov r8d, 0x00
000077a0e99d7510  lea r9, [r15+0x3A8]
000077a0e99d7517  movaps [rdi], xmm14
000077a0e99d751b  movaps [rsi], xmm15
000077a0e99d751f  movaps [rdx], xmm2
000077a0e99d7522  movaps [rcx], xmm1
000077a0e99d7525  mov rax, 0x60CAA235BA50
000077a0e99d752f  call rax
000077a0e99d7531  movaps xmm14, [rsp]
000077a0e99d7536  add rsp, 0x40
000077a0e99d753a  vmovaps xmm0, [rsp]
000077a0e99d753f  vmovaps xmm1, [rsp+0x10]
000077a0e99d7545  vmovaps xmm2, [rsp+0x20]
000077a0e99d754b  vmovaps xmm3, [rsp+0x30]
000077a0e99d7551  vmovaps xmm4, [rsp+0x40]
000077a0e99d7557  vmovaps xmm5, [rsp+0x50]
000077a0e99d755d  vmovaps xmm6, [rsp+0x60]
000077a0e99d7563  vmovaps xmm7, [rsp+0x70]
000077a0e99d7569  vmovaps xmm8, [rsp+0x80]
000077a0e99d7572  vmovaps xmm9, [rsp+0x90]
000077a0e99d757b  vmovaps xmm10, [rsp+0xA0]
000077a0e99d7584  vmovaps xmm11, [rsp+0xB0]
000077a0e99d758d  vmovaps xmm12, [rsp+0xC0]
000077a0e99d7596  vmovaps xmm13, [rsp+0xD0]
000077a0e99d759f  vmovaps xmm15, [rsp+0xE0]
000077a0e99d75a8  add rsp, 0xF0
000077a0e99d75af  pop r11
000077a0e99d75b1  pop r10
000077a0e99d75b3  pop r9
000077a0e99d75b5  pop r8
000077a0e99d75b7  pop rsi
000077a0e99d75b8  pop rdi
000077a0e99d75b9  pop rdx
000077a0e99d75ba  pop rcx
000077a0e99d75bb  pop rax
000077a0e99d75bc  add rsp, 0x08
000077a0e99d75c0  jmp 0x000077A0E99D6691
000077a0e99d75c5  sub rsp, 0x08
000077a0e99d75c9  push rax
000077a0e99d75ca  push rcx
000077a0e99d75cb  push rdx
000077a0e99d75cc  push rdi
000077a0e99d75cd  push rsi
000077a0e99d75ce  push r8
000077a0e99d75d0  push r9
000077a0e99d75d2  push r10
000077a0e99d75d4  push r11
000077a0e99d75d6  sub rsp, 0xF0
000077a0e99d75dd  vmovaps [rsp], xmm0
000077a0e99d75e2  vmovaps [rsp+0x10], xmm1
000077a0e99d75e8  vmovaps [rsp+0x20], xmm3
000077a0e99d75ee  vmovaps [rsp+0x30], xmm4
000077a0e99d75f4  vmovaps [rsp+0x40], xmm5
000077a0e99d75fa  vmovaps [rsp+0x50], xmm6
000077a0e99d7600  vmovaps [rsp+0x60], xmm7
000077a0e99d7606  vmovaps [rsp+0x70], xmm8
000077a0e99d760c  vmovaps [rsp+0x80], xmm9
000077a0e99d7615  vmovaps [rsp+0x90], xmm10
000077a0e99d761e  vmovaps [rsp+0xA0], xmm11
000077a0e99d7627  vmovaps [rsp+0xB0], xmm12
000077a0e99d7630  vmovaps [rsp+0xC0], xmm13
000077a0e99d7639  vmovaps [rsp+0xD0], xmm14
000077a0e99d7642  vmovaps [rsp+0xE0], xmm15
000077a0e99d764b  sub rsp, 0x40
000077a0e99d764f  lea rdi, [rsp]
000077a0e99d7653  lea rsi, [rsp+0x10]
000077a0e99d7658  lea rdx, [rsp+0x20]
000077a0e99d765d  lea rcx, [rsp+0x30]
000077a0e99d7662  mov r8d, 0x00
000077a0e99d7668  lea r9, [r15+0x3A8]
000077a0e99d766f  movaps [rdi], xmm2
000077a0e99d7672  movaps [rsi], xmm15
000077a0e99d7676  movaps [rdx], xmm12
000077a0e99d767a  movaps [rcx], xmm1
000077a0e99d767d  mov rax, 0x60CAA235BA50
000077a0e99d7687  call rax
000077a0e99d7689  movaps xmm2, [rsp]
000077a0e99d768d  add rsp, 0x40
000077a0e99d7691  vmovaps xmm0, [rsp]
000077a0e99d7696  vmovaps xmm1, [rsp+0x10]
000077a0e99d769c  vmovaps xmm3, [rsp+0x20]
000077a0e99d76a2  vmovaps xmm4, [rsp+0x30]
000077a0e99d76a8  vmovaps xmm5, [rsp+0x40]
000077a0e99d76ae  vmovaps xmm6, [rsp+0x50]
000077a0e99d76b4  vmovaps xmm7, [rsp+0x60]
000077a0e99d76ba  vmovaps xmm8, [rsp+0x70]
000077a0e99d76c0  vmovaps xmm9, [rsp+0x80]
000077a0e99d76c9  vmovaps xmm10, [rsp+0x90]
000077a0e99d76d2  vmovaps xmm11, [rsp+0xA0]
000077a0e99d76db  vmovaps xmm12, [rsp+0xB0]
000077a0e99d76e4  vmovaps xmm13, [rsp+0xC0]
000077a0e99d76ed  vmovaps xmm14, [rsp+0xD0]
000077a0e99d76f6  vmovaps xmm15, [rsp+0xE0]
000077a0e99d76ff  add rsp, 0xF0
000077a0e99d7706  pop r11
000077a0e99d7708  pop r10
000077a0e99d770a  pop r9
000077a0e99d770c  pop r8
000077a0e99d770e  pop rsi
000077a0e99d770f  pop rdi
000077a0e99d7710  pop rdx
000077a0e99d7711  pop rcx
000077a0e99d7712  pop rax
000077a0e99d7713  add rsp, 0x08
000077a0e99d7717  jmp 0x000077A0E99D66CE
000077a0e99d771c  sub rsp, 0x08
000077a0e99d7720  push rax
000077a0e99d7721  push rcx
000077a0e99d7722  push rdx
000077a0e99d7723  push rdi
000077a0e99d7724  push rsi
000077a0e99d7725  push r8
000077a0e99d7727  push r9
000077a0e99d7729  push r10
000077a0e99d772b  push r11
000077a0e99d772d  sub rsp, 0xF0
000077a0e99d7734  vmovaps [rsp], xmm0
000077a0e99d7739  vmovaps [rsp+0x10], xmm1
000077a0e99d773f  vmovaps [rsp+0x20], xmm2
000077a0e99d7745  vmovaps [rsp+0x30], xmm3
000077a0e99d774b  vmovaps [rsp+0x40], xmm4
000077a0e99d7751  vmovaps [rsp+0x50], xmm5
000077a0e99d7757  vmovaps [rsp+0x60], xmm6
000077a0e99d775d  vmovaps [rsp+0x70], xmm7
000077a0e99d7763  vmovaps [rsp+0x80], xmm8
000077a0e99d776c  vmovaps [rsp+0x90], xmm9
000077a0e99d7775  vmovaps [rsp+0xA0], xmm10
000077a0e99d777e  vmovaps [rsp+0xB0], xmm11
000077a0e99d7787  vmovaps [rsp+0xC0], xmm13
000077a0e99d7790  vmovaps [rsp+0xD0], xmm14
000077a0e99d7799  vmovaps [rsp+0xE0], xmm15
000077a0e99d77a2  sub rsp, 0x40
000077a0e99d77a6  lea rdi, [rsp]
000077a0e99d77aa  lea rsi, [rsp+0x10]
000077a0e99d77af  lea rdx, [rsp+0x20]
000077a0e99d77b4  lea rcx, [rsp+0x30]
000077a0e99d77b9  mov r8d, 0x00
000077a0e99d77bf  lea r9, [r15+0x3A8]
000077a0e99d77c6  movaps [rdi], xmm12
000077a0e99d77ca  movaps [rsi], xmm14
000077a0e99d77ce  movaps [rdx], xmm3
000077a0e99d77d1  movaps [rcx], xmm15
000077a0e99d77d5  mov rax, 0x60CAA235BA50
000077a0e99d77df  call rax
000077a0e99d77e1  movaps xmm12, [rsp]
000077a0e99d77e6  add rsp, 0x40
000077a0e99d77ea  vmovaps xmm0, [rsp]
000077a0e99d77ef  vmovaps xmm1, [rsp+0x10]
000077a0e99d77f5  vmovaps xmm2, [rsp+0x20]
000077a0e99d77fb  vmovaps xmm3, [rsp+0x30]
000077a0e99d7801  vmovaps xmm4, [rsp+0x40]
000077a0e99d7807  vmovaps xmm5, [rsp+0x50]
000077a0e99d780d  vmovaps xmm6, [rsp+0x60]
000077a0e99d7813  vmovaps xmm7, [rsp+0x70]
000077a0e99d7819  vmovaps xmm8, [rsp+0x80]
000077a0e99d7822  vmovaps xmm9, [rsp+0x90]
000077a0e99d782b  vmovaps xmm10, [rsp+0xA0]
000077a0e99d7834  vmovaps xmm11, [rsp+0xB0]
000077a0e99d783d  vmovaps xmm13, [rsp+0xC0]
000077a0e99d7846  vmovaps xmm14, [rsp+0xD0]
000077a0e99d784f  vmovaps xmm15, [rsp+0xE0]
000077a0e99d7858  add rsp, 0xF0
000077a0e99d785f  pop r11
000077a0e99d7861  pop r10
000077a0e99d7863  pop r9
000077a0e99d7865  pop r8
000077a0e99d7867  pop rsi
000077a0e99d7868  pop rdi
000077a0e99d7869  pop rdx
000077a0e99d786a  pop rcx
000077a0e99d786b  pop rax
000077a0e99d786c  add rsp, 0x08
000077a0e99d7870  jmp 0x000077A0E99D6728
000077a0e99d7875  sub rsp, 0x08
000077a0e99d7879  push rax
000077a0e99d787a  push rcx
000077a0e99d787b  push rdx
000077a0e99d787c  push rdi
000077a0e99d787d  push rsi
000077a0e99d787e  push r8
000077a0e99d7880  push r9
000077a0e99d7882  push r10
000077a0e99d7884  push r11
000077a0e99d7886  sub rsp, 0xF0
000077a0e99d788d  vmovaps [rsp], xmm0
000077a0e99d7892  vmovaps [rsp+0x10], xmm1
000077a0e99d7898  vmovaps [rsp+0x20], xmm2
000077a0e99d789e  vmovaps [rsp+0x30], xmm3
000077a0e99d78a4  vmovaps [rsp+0x40], xmm4
000077a0e99d78aa  vmovaps [rsp+0x50], xmm5
000077a0e99d78b0  vmovaps [rsp+0x60], xmm6
000077a0e99d78b6  vmovaps [rsp+0x70], xmm7
000077a0e99d78bc  vmovaps [rsp+0x80], xmm8
000077a0e99d78c5  vmovaps [rsp+0x90], xmm10
000077a0e99d78ce  vmovaps [rsp+0xA0], xmm11
000077a0e99d78d7  vmovaps [rsp+0xB0], xmm12
000077a0e99d78e0  vmovaps [rsp+0xC0], xmm13
000077a0e99d78e9  vmovaps [rsp+0xD0], xmm14
000077a0e99d78f2  vmovaps [rsp+0xE0], xmm15
000077a0e99d78fb  sub rsp, 0x40
000077a0e99d78ff  lea rdi, [rsp]
000077a0e99d7903  lea rsi, [rsp+0x10]
000077a0e99d7908  lea rdx, [rsp+0x20]
000077a0e99d790d  lea rcx, [rsp+0x30]
000077a0e99d7912  mov r8d, 0x00
000077a0e99d7918  lea r9, [r15+0x3A8]
000077a0e99d791f  movaps [rdi], xmm9
000077a0e99d7923  movaps [rsi], xmm13
000077a0e99d7927  movaps [rdx], xmm14
000077a0e99d792b  movaps [rcx], xmm6
000077a0e99d792e  mov rax, 0x60CAA235BA50
000077a0e99d7938  call rax
000077a0e99d793a  movaps xmm9, [rsp]
000077a0e99d793f  add rsp, 0x40
000077a0e99d7943  vmovaps xmm0, [rsp]
000077a0e99d7948  vmovaps xmm1, [rsp+0x10]
000077a0e99d794e  vmovaps xmm2, [rsp+0x20]
000077a0e99d7954  vmovaps xmm3, [rsp+0x30]
000077a0e99d795a  vmovaps xmm4, [rsp+0x40]
000077a0e99d7960  vmovaps xmm5, [rsp+0x50]
000077a0e99d7966  vmovaps xmm6, [rsp+0x60]
000077a0e99d796c  vmovaps xmm7, [rsp+0x70]
000077a0e99d7972  vmovaps xmm8, [rsp+0x80]
000077a0e99d797b  vmovaps xmm10, [rsp+0x90]
000077a0e99d7984  vmovaps xmm11, [rsp+0xA0]
000077a0e99d798d  vmovaps xmm12, [rsp+0xB0]
000077a0e99d7996  vmovaps xmm13, [rsp+0xC0]
000077a0e99d799f  vmovaps xmm14, [rsp+0xD0]
000077a0e99d79a8  vmovaps xmm15, [rsp+0xE0]
000077a0e99d79b1  add rsp, 0xF0
000077a0e99d79b8  pop r11
000077a0e99d79ba  pop r10
000077a0e99d79bc  pop r9
000077a0e99d79be  pop r8
000077a0e99d79c0  pop rsi
000077a0e99d79c1  pop rdi
000077a0e99d79c2  pop rdx
000077a0e99d79c3  pop rcx
000077a0e99d79c4  pop rax
000077a0e99d79c5  add rsp, 0x08
000077a0e99d79c9  jmp 0x000077A0E99D67D2
000077a0e99d79ce  sub rsp, 0x08
000077a0e99d79d2  push rax
000077a0e99d79d3  push rcx
000077a0e99d79d4  push rdx
000077a0e99d79d5  push rdi
000077a0e99d79d6  push rsi
000077a0e99d79d7  push r8
000077a0e99d79d9  push r9
000077a0e99d79db  push r10
000077a0e99d79dd  push r11
000077a0e99d79df  sub rsp, 0xF0
000077a0e99d79e6  vmovaps [rsp], xmm0
000077a0e99d79eb  vmovaps [rsp+0x10], xmm1
000077a0e99d79f1  vmovaps [rsp+0x20], xmm2
000077a0e99d79f7  vmovaps [rsp+0x30], xmm4
000077a0e99d79fd  vmovaps [rsp+0x40], xmm5
000077a0e99d7a03  vmovaps [rsp+0x50], xmm6
000077a0e99d7a09  vmovaps [rsp+0x60], xmm7
000077a0e99d7a0f  vmovaps [rsp+0x70], xmm8
000077a0e99d7a15  vmovaps [rsp+0x80], xmm9
000077a0e99d7a1e  vmovaps [rsp+0x90], xmm10
000077a0e99d7a27  vmovaps [rsp+0xA0], xmm11
000077a0e99d7a30  vmovaps [rsp+0xB0], xmm12
000077a0e99d7a39  vmovaps [rsp+0xC0], xmm13
000077a0e99d7a42  vmovaps [rsp+0xD0], xmm14
000077a0e99d7a4b  vmovaps [rsp+0xE0], xmm15
000077a0e99d7a54  sub rsp, 0x40
000077a0e99d7a58  lea rdi, [rsp]
000077a0e99d7a5c  lea rsi, [rsp+0x10]
000077a0e99d7a61  lea rdx, [rsp+0x20]
000077a0e99d7a66  lea rcx, [rsp+0x30]
000077a0e99d7a6b  mov r8d, 0x00
000077a0e99d7a71  lea r9, [r15+0x3A8]
000077a0e99d7a78  movaps [rdi], xmm3
000077a0e99d7a7b  movaps [rsi], xmm13
000077a0e99d7a7f  movaps [rdx], xmm6
000077a0e99d7a82  movaps [rcx], xmm14
000077a0e99d7a86  mov rax, 0x60CAA235BA50
000077a0e99d7a90  call rax
000077a0e99d7a92  movaps xmm3, [rsp]
000077a0e99d7a96  add rsp, 0x40
000077a0e99d7a9a  vmovaps xmm0, [rsp]
000077a0e99d7a9f  vmovaps xmm1, [rsp+0x10]
000077a0e99d7aa5  vmovaps xmm2, [rsp+0x20]
000077a0e99d7aab  vmovaps xmm4, [rsp+0x30]
000077a0e99d7ab1  vmovaps xmm5, [rsp+0x40]
000077a0e99d7ab7  vmovaps xmm6, [rsp+0x50]
000077a0e99d7abd  vmovaps xmm7, [rsp+0x60]
000077a0e99d7ac3  vmovaps xmm8, [rsp+0x70]
000077a0e99d7ac9  vmovaps xmm9, [rsp+0x80]
000077a0e99d7ad2  vmovaps xmm10, [rsp+0x90]
000077a0e99d7adb  vmovaps xmm11, [rsp+0xA0]
000077a0e99d7ae4  vmovaps xmm12, [rsp+0xB0]
000077a0e99d7aed  vmovaps xmm13, [rsp+0xC0]
000077a0e99d7af6  vmovaps xmm14, [rsp+0xD0]
000077a0e99d7aff  vmovaps xmm15, [rsp+0xE0]
000077a0e99d7b08  add rsp, 0xF0
000077a0e99d7b0f  pop r11
000077a0e99d7b11  pop r10
000077a0e99d7b13  pop r9
000077a0e99d7b15  pop r8
000077a0e99d7b17  pop rsi
000077a0e99d7b18  pop rdi
000077a0e99d7b19  pop rdx
000077a0e99d7b1a  pop rcx
000077a0e99d7b1b  pop rax
000077a0e99d7b1c  add rsp, 0x08
000077a0e99d7b20  jmp 0x000077A0E99D680F
000077a0e99d7b25  sub rsp, 0x08
000077a0e99d7b29  push rax
000077a0e99d7b2a  push rcx
000077a0e99d7b2b  push rdx
000077a0e99d7b2c  push rdi
000077a0e99d7b2d  push rsi
000077a0e99d7b2e  push r8
000077a0e99d7b30  push r9
000077a0e99d7b32  push r10
000077a0e99d7b34  push r11
000077a0e99d7b36  sub rsp, 0xF0
000077a0e99d7b3d  vmovaps [rsp], xmm0
000077a0e99d7b42  vmovaps [rsp+0x10], xmm1
000077a0e99d7b48  vmovaps [rsp+0x20], xmm2
000077a0e99d7b4e  vmovaps [rsp+0x30], xmm3
000077a0e99d7b54  vmovaps [rsp+0x40], xmm4
000077a0e99d7b5a  vmovaps [rsp+0x50], xmm5
000077a0e99d7b60  vmovaps [rsp+0x60], xmm7
000077a0e99d7b66  vmovaps [rsp+0x70], xmm8
000077a0e99d7b6c  vmovaps [rsp+0x80], xmm9
000077a0e99d7b75  vmovaps [rsp+0x90], xmm10
000077a0e99d7b7e  vmovaps [rsp+0xA0], xmm11
000077a0e99d7b87  vmovaps [rsp+0xB0], xmm12
000077a0e99d7b90  vmovaps [rsp+0xC0], xmm13
000077a0e99d7b99  vmovaps [rsp+0xD0], xmm14
000077a0e99d7ba2  vmovaps [rsp+0xE0], xmm15
000077a0e99d7bab  sub rsp, 0x40
000077a0e99d7baf  lea rdi, [rsp]
000077a0e99d7bb3  lea rsi, [rsp+0x10]
000077a0e99d7bb8  lea rdx, [rsp+0x20]
000077a0e99d7bbd  lea rcx, [rsp+0x30]
000077a0e99d7bc2  mov r8d, 0x00
000077a0e99d7bc8  lea r9, [r15+0x3A8]
000077a0e99d7bcf  movaps [rdi], xmm6
000077a0e99d7bd2  movaps [rsi], xmm2
000077a0e99d7bd5  movaps [rdx], xmm14
000077a0e99d7bd9  movaps [rcx], xmm1
000077a0e99d7bdc  mov rax, 0x60CAA235BA50
000077a0e99d7be6  call rax
000077a0e99d7be8  movaps xmm6, [rsp]
000077a0e99d7bec  add rsp, 0x40
000077a0e99d7bf0  vmovaps xmm0, [rsp]
000077a0e99d7bf5  vmovaps xmm1, [rsp+0x10]
000077a0e99d7bfb  vmovaps xmm2, [rsp+0x20]
000077a0e99d7c01  vmovaps xmm3, [rsp+0x30]
000077a0e99d7c07  vmovaps xmm4, [rsp+0x40]
000077a0e99d7c0d  vmovaps xmm5, [rsp+0x50]
000077a0e99d7c13  vmovaps xmm7, [rsp+0x60]
000077a0e99d7c19  vmovaps xmm8, [rsp+0x70]
000077a0e99d7c1f  vmovaps xmm9, [rsp+0x80]
000077a0e99d7c28  vmovaps xmm10, [rsp+0x90]
000077a0e99d7c31  vmovaps xmm11, [rsp+0xA0]
000077a0e99d7c3a  vmovaps xmm12, [rsp+0xB0]
000077a0e99d7c43  vmovaps xmm13, [rsp+0xC0]
000077a0e99d7c4c  vmovaps xmm14, [rsp+0xD0]
000077a0e99d7c55  vmovaps xmm15, [rsp+0xE0]
000077a0e99d7c5e  add rsp, 0xF0
000077a0e99d7c65  pop r11
000077a0e99d7c67  pop r10
000077a0e99d7c69  pop r9
000077a0e99d7c6b  pop r8
000077a0e99d7c6d  pop rsi
000077a0e99d7c6e  pop rdi
000077a0e99d7c6f  pop rdx
000077a0e99d7c70  pop rcx
000077a0e99d7c71  pop rax
000077a0e99d7c72  add rsp, 0x08
000077a0e99d7c76  jmp 0x000077A0E99D683C
000077a0e99d7c7b  sub rsp, 0x08
000077a0e99d7c7f  push rax
000077a0e99d7c80  push rcx
000077a0e99d7c81  push rdx
000077a0e99d7c82  push rdi
000077a0e99d7c83  push rsi
000077a0e99d7c84  push r8
000077a0e99d7c86  push r9
000077a0e99d7c88  push r10
000077a0e99d7c8a  push r11
000077a0e99d7c8c  sub rsp, 0xF0
000077a0e99d7c93  vmovaps [rsp], xmm0
000077a0e99d7c98  vmovaps [rsp+0x10], xmm1
000077a0e99d7c9e  vmovaps [rsp+0x20], xmm2
000077a0e99d7ca4  vmovaps [rsp+0x30], xmm3
000077a0e99d7caa  vmovaps [rsp+0x40], xmm4
000077a0e99d7cb0  vmovaps [rsp+0x50], xmm5
000077a0e99d7cb6  vmovaps [rsp+0x60], xmm6
000077a0e99d7cbc  vmovaps [rsp+0x70], xmm7
000077a0e99d7cc2  vmovaps [rsp+0x80], xmm8
000077a0e99d7ccb  vmovaps [rsp+0x90], xmm9
000077a0e99d7cd4  vmovaps [rsp+0xA0], xmm10
000077a0e99d7cdd  vmovaps [rsp+0xB0], xmm11
000077a0e99d7ce6  vmovaps [rsp+0xC0], xmm12
000077a0e99d7cef  vmovaps [rsp+0xD0], xmm14
000077a0e99d7cf8  vmovaps [rsp+0xE0], xmm15
000077a0e99d7d01  sub rsp, 0x40
000077a0e99d7d05  lea rdi, [rsp]
000077a0e99d7d09  lea rsi, [rsp+0x10]
000077a0e99d7d0e  lea rdx, [rsp+0x20]
000077a0e99d7d13  lea rcx, [rsp+0x30]
000077a0e99d7d18  mov r8d, 0x00
000077a0e99d7d1e  lea r9, [r15+0x3A8]
000077a0e99d7d25  movaps [rdi], xmm13
000077a0e99d7d29  movaps [rsi], xmm12
000077a0e99d7d2d  movaps [rdx], xmm14
000077a0e99d7d31  movaps [rcx], xmm1
000077a0e99d7d34  mov rax, 0x60CAA235BA50
000077a0e99d7d3e  call rax
000077a0e99d7d40  movaps xmm13, [rsp]
000077a0e99d7d45  add rsp, 0x40
000077a0e99d7d49  vmovaps xmm0, [rsp]
000077a0e99d7d4e  vmovaps xmm1, [rsp+0x10]
000077a0e99d7d54  vmovaps xmm2, [rsp+0x20]
000077a0e99d7d5a  vmovaps xmm3, [rsp+0x30]
000077a0e99d7d60  vmovaps xmm4, [rsp+0x40]
000077a0e99d7d66  vmovaps xmm5, [rsp+0x50]
000077a0e99d7d6c  vmovaps xmm6, [rsp+0x60]
000077a0e99d7d72  vmovaps xmm7, [rsp+0x70]
000077a0e99d7d78  vmovaps xmm8, [rsp+0x80]
000077a0e99d7d81  vmovaps xmm9, [rsp+0x90]
000077a0e99d7d8a  vmovaps xmm10, [rsp+0xA0]
000077a0e99d7d93  vmovaps xmm11, [rsp+0xB0]
000077a0e99d7d9c  vmovaps xmm12, [rsp+0xC0]
000077a0e99d7da5  vmovaps xmm14, [rsp+0xD0]
000077a0e99d7dae  vmovaps xmm15, [rsp+0xE0]
000077a0e99d7db7  add rsp, 0xF0
000077a0e99d7dbe  pop r11
000077a0e99d7dc0  pop r10
000077a0e99d7dc2  pop r9
000077a0e99d7dc4  pop r8
000077a0e99d7dc6  pop rsi
000077a0e99d7dc7  pop rdi
000077a0e99d7dc8  pop rdx
000077a0e99d7dc9  pop rcx
000077a0e99d7dca  pop rax
000077a0e99d7dcb  add rsp, 0x08
000077a0e99d7dcf  jmp 0x000077A0E99D686E
000077a0e99d7dd4  sub rsp, 0x08
000077a0e99d7dd8  push rax
000077a0e99d7dd9  push rcx
000077a0e99d7dda  push rdx
000077a0e99d7ddb  push rdi
000077a0e99d7ddc  push rsi
000077a0e99d7ddd  push r8
000077a0e99d7ddf  push r9
000077a0e99d7de1  push r10
000077a0e99d7de3  push r11
000077a0e99d7de5  sub rsp, 0xF0
000077a0e99d7dec  vmovaps [rsp], xmm0
000077a0e99d7df1  vmovaps [rsp+0x10], xmm1
000077a0e99d7df7  vmovaps [rsp+0x20], xmm2
000077a0e99d7dfd  vmovaps [rsp+0x30], xmm3
000077a0e99d7e03  vmovaps [rsp+0x40], xmm4
000077a0e99d7e09  vmovaps [rsp+0x50], xmm5
000077a0e99d7e0f  vmovaps [rsp+0x60], xmm6
000077a0e99d7e15  vmovaps [rsp+0x70], xmm7
000077a0e99d7e1b  vmovaps [rsp+0x80], xmm8
000077a0e99d7e24  vmovaps [rsp+0x90], xmm9
000077a0e99d7e2d  vmovaps [rsp+0xA0], xmm10
000077a0e99d7e36  vmovaps [rsp+0xB0], xmm11
000077a0e99d7e3f  vmovaps [rsp+0xC0], xmm13
000077a0e99d7e48  vmovaps [rsp+0xD0], xmm14
000077a0e99d7e51  vmovaps [rsp+0xE0], xmm15
000077a0e99d7e5a  sub rsp, 0x40
000077a0e99d7e5e  lea rdi, [rsp]
000077a0e99d7e62  lea rsi, [rsp+0x10]
000077a0e99d7e67  lea rdx, [rsp+0x20]
000077a0e99d7e6c  lea rcx, [rsp+0x30]
000077a0e99d7e71  mov r8d, 0x00
000077a0e99d7e77  lea r9, [r15+0x3A8]
000077a0e99d7e7e  movaps [rdi], xmm12
000077a0e99d7e82  movaps [rsi], xmm3
000077a0e99d7e85  movaps [rdx], xmm14
000077a0e99d7e89  movaps [rcx], xmm5
000077a0e99d7e8c  mov rax, 0x60CAA235BA50
000077a0e99d7e96  call rax
000077a0e99d7e98  movaps xmm12, [rsp]
000077a0e99d7e9d  add rsp, 0x40
000077a0e99d7ea1  vmovaps xmm0, [rsp]
000077a0e99d7ea6  vmovaps xmm1, [rsp+0x10]
000077a0e99d7eac  vmovaps xmm2, [rsp+0x20]
000077a0e99d7eb2  vmovaps xmm3, [rsp+0x30]
000077a0e99d7eb8  vmovaps xmm4, [rsp+0x40]
000077a0e99d7ebe  vmovaps xmm5, [rsp+0x50]
000077a0e99d7ec4  vmovaps xmm6, [rsp+0x60]
000077a0e99d7eca  vmovaps xmm7, [rsp+0x70]
000077a0e99d7ed0  vmovaps xmm8, [rsp+0x80]
000077a0e99d7ed9  vmovaps xmm9, [rsp+0x90]
000077a0e99d7ee2  vmovaps xmm10, [rsp+0xA0]
000077a0e99d7eeb  vmovaps xmm11, [rsp+0xB0]
000077a0e99d7ef4  vmovaps xmm13, [rsp+0xC0]
000077a0e99d7efd  vmovaps xmm14, [rsp+0xD0]
000077a0e99d7f06  vmovaps xmm15, [rsp+0xE0]
000077a0e99d7f0f  add rsp, 0xF0
000077a0e99d7f16  pop r11
000077a0e99d7f18  pop r10
000077a0e99d7f1a  pop r9
000077a0e99d7f1c  pop r8
000077a0e99d7f1e  pop rsi
000077a0e99d7f1f  pop rdi
000077a0e99d7f20  pop rdx
000077a0e99d7f21  pop rcx
000077a0e99d7f22  pop rax
000077a0e99d7f23  add rsp, 0x08
000077a0e99d7f27  jmp 0x000077A0E99D68CB
000077a0e99d7f2c  sub rsp, 0x08
000077a0e99d7f30  push rax
000077a0e99d7f31  push rcx
000077a0e99d7f32  push rdx
000077a0e99d7f33  push rdi
000077a0e99d7f34  push rsi
000077a0e99d7f35  push r8
000077a0e99d7f37  push r9
000077a0e99d7f39  push r10
000077a0e99d7f3b  push r11
000077a0e99d7f3d  sub rsp, 0xF0
000077a0e99d7f44  vmovaps [rsp], xmm0
000077a0e99d7f49  vmovaps [rsp+0x10], xmm1
000077a0e99d7f4f  vmovaps [rsp+0x20], xmm2
000077a0e99d7f55  vmovaps [rsp+0x30], xmm3
000077a0e99d7f5b  vmovaps [rsp+0x40], xmm4
000077a0e99d7f61  vmovaps [rsp+0x50], xmm5
000077a0e99d7f67  vmovaps [rsp+0x60], xmm6
000077a0e99d7f6d  vmovaps [rsp+0x70], xmm7
000077a0e99d7f73  vmovaps [rsp+0x80], xmm8
000077a0e99d7f7c  vmovaps [rsp+0x90], xmm9
000077a0e99d7f85  vmovaps [rsp+0xA0], xmm11
000077a0e99d7f8e  vmovaps [rsp+0xB0], xmm12
000077a0e99d7f97  vmovaps [rsp+0xC0], xmm13
000077a0e99d7fa0  vmovaps [rsp+0xD0], xmm14
000077a0e99d7fa9  vmovaps [rsp+0xE0], xmm15
000077a0e99d7fb2  sub rsp, 0x40
000077a0e99d7fb6  lea rdi, [rsp]
000077a0e99d7fba  lea rsi, [rsp+0x10]
000077a0e99d7fbf  lea rdx, [rsp+0x20]
000077a0e99d7fc4  lea rcx, [rsp+0x30]
000077a0e99d7fc9  mov r8d, 0x00
000077a0e99d7fcf  lea r9, [r15+0x3A8]
000077a0e99d7fd6  movaps [rdi], xmm10
000077a0e99d7fda  movaps [rsi], xmm9
000077a0e99d7fde  movaps [rdx], xmm7
000077a0e99d7fe1  movaps [rcx], xmm14
000077a0e99d7fe5  mov rax, 0x60CAA235BA50
000077a0e99d7fef  call rax
000077a0e99d7ff1  movaps xmm10, [rsp]
000077a0e99d7ff6  add rsp, 0x40
000077a0e99d7ffa  vmovaps xmm0, [rsp]
000077a0e99d7fff  vmovaps xmm1, [rsp+0x10]
000077a0e99d8005  vmovaps xmm2, [rsp+0x20]
000077a0e99d800b  vmovaps xmm3, [rsp+0x30]
000077a0e99d8011  vmovaps xmm4, [rsp+0x40]
000077a0e99d8017  vmovaps xmm5, [rsp+0x50]
000077a0e99d801d  vmovaps xmm6, [rsp+0x60]
000077a0e99d8023  vmovaps xmm7, [rsp+0x70]
000077a0e99d8029  vmovaps xmm8, [rsp+0x80]
000077a0e99d8032  vmovaps xmm9, [rsp+0x90]
000077a0e99d803b  vmovaps xmm11, [rsp+0xA0]
000077a0e99d8044  vmovaps xmm12, [rsp+0xB0]
000077a0e99d804d  vmovaps xmm13, [rsp+0xC0]
000077a0e99d8056  vmovaps xmm14, [rsp+0xD0]
000077a0e99d805f  vmovaps xmm15, [rsp+0xE0]
000077a0e99d8068  add rsp, 0xF0
000077a0e99d806f  pop r11
000077a0e99d8071  pop r10
000077a0e99d8073  pop r9
000077a0e99d8075  pop r8
000077a0e99d8077  pop rsi
000077a0e99d8078  pop rdi
000077a0e99d8079  pop rdx
000077a0e99d807a  pop rcx
000077a0e99d807b  pop rax
000077a0e99d807c  add rsp, 0x08
000077a0e99d8080  jmp 0x000077A0E99D68F1
000077a0e99d8085  call 0x000077A0E98E45A0
000077a0e99d808a  jmp 0x000077A0E99D68FE
000077a0e99d808f  sub rsp, 0x08
000077a0e99d8093  push rax
000077a0e99d8094  push rcx
000077a0e99d8095  push rdx
000077a0e99d8096  push rdi
000077a0e99d8097  push rsi
000077a0e99d8098  push r8
000077a0e99d809a  push r9
000077a0e99d809c  push r10
000077a0e99d809e  push r11
000077a0e99d80a0  sub rsp, 0xF0
000077a0e99d80a7  vmovaps [rsp], xmm0
000077a0e99d80ac  vmovaps [rsp+0x10], xmm1
000077a0e99d80b2  vmovaps [rsp+0x20], xmm2
000077a0e99d80b8  vmovaps [rsp+0x30], xmm3
000077a0e99d80be  vmovaps [rsp+0x40], xmm4
000077a0e99d80c4  vmovaps [rsp+0x50], xmm6
000077a0e99d80ca  vmovaps [rsp+0x60], xmm7
000077a0e99d80d0  vmovaps [rsp+0x70], xmm8
000077a0e99d80d6  vmovaps [rsp+0x80], xmm9
000077a0e99d80df  vmovaps [rsp+0x90], xmm10
000077a0e99d80e8  vmovaps [rsp+0xA0], xmm11
000077a0e99d80f1  vmovaps [rsp+0xB0], xmm12
000077a0e99d80fa  vmovaps [rsp+0xC0], xmm13
000077a0e99d8103  vmovaps [rsp+0xD0], xmm14
000077a0e99d810c  vmovaps [rsp+0xE0], xmm15
000077a0e99d8115  sub rsp, 0x40
000077a0e99d8119  lea rdi, [rsp]
000077a0e99d811d  lea rsi, [rsp+0x10]
000077a0e99d8122  lea rdx, [rsp+0x20]
000077a0e99d8127  lea rcx, [rsp+0x30]
000077a0e99d812c  mov r8d, 0x00
000077a0e99d8132  lea r9, [r15+0x3A8]
000077a0e99d8139  movaps [rdi], xmm5
000077a0e99d813c  movaps [rsi], xmm6
000077a0e99d813f  movaps [rdx], xmm7
000077a0e99d8142  movaps [rcx], xmm9
000077a0e99d8146  mov rax, 0x60CAA235BA50
000077a0e99d8150  call rax
000077a0e99d8152  movaps xmm5, [rsp]
000077a0e99d8156  add rsp, 0x40
000077a0e99d815a  vmovaps xmm0, [rsp]
000077a0e99d815f  vmovaps xmm1, [rsp+0x10]
000077a0e99d8165  vmovaps xmm2, [rsp+0x20]
000077a0e99d816b  vmovaps xmm3, [rsp+0x30]
000077a0e99d8171  vmovaps xmm4, [rsp+0x40]
000077a0e99d8177  vmovaps xmm6, [rsp+0x50]
000077a0e99d817d  vmovaps xmm7, [rsp+0x60]
000077a0e99d8183  vmovaps xmm8, [rsp+0x70]
000077a0e99d8189  vmovaps xmm9, [rsp+0x80]
000077a0e99d8192  vmovaps xmm10, [rsp+0x90]
000077a0e99d819b  vmovaps xmm11, [rsp+0xA0]
000077a0e99d81a4  vmovaps xmm12, [rsp+0xB0]
000077a0e99d81ad  vmovaps xmm13, [rsp+0xC0]
000077a0e99d81b6  vmovaps xmm14, [rsp+0xD0]
000077a0e99d81bf  vmovaps xmm15, [rsp+0xE0]
000077a0e99d81c8  add rsp, 0xF0
000077a0e99d81cf  pop r11
000077a0e99d81d1  pop r10
000077a0e99d81d3  pop r9
000077a0e99d81d5  pop r8
000077a0e99d81d7  pop rsi
000077a0e99d81d8  pop rdi
000077a0e99d81d9  pop rdx
000077a0e99d81da  pop rcx
000077a0e99d81db  pop rax
000077a0e99d81dc  add rsp, 0x08
000077a0e99d81e0  jmp 0x000077A0E99D6930
000077a0e99d81e5  sub rsp, 0x08
000077a0e99d81e9  push rax
000077a0e99d81ea  push rcx
000077a0e99d81eb  push rdx
000077a0e99d81ec  push rdi
000077a0e99d81ed  push rsi
000077a0e99d81ee  push r8
000077a0e99d81f0  push r9
000077a0e99d81f2  push r10
000077a0e99d81f4  push r11
000077a0e99d81f6  sub rsp, 0xF0
000077a0e99d81fd  vmovaps [rsp], xmm0
000077a0e99d8202  vmovaps [rsp+0x10], xmm1
000077a0e99d8208  vmovaps [rsp+0x20], xmm2
000077a0e99d820e  vmovaps [rsp+0x30], xmm3
000077a0e99d8214  vmovaps [rsp+0x40], xmm4
000077a0e99d821a  vmovaps [rsp+0x50], xmm5
000077a0e99d8220  vmovaps [rsp+0x60], xmm6
000077a0e99d8226  vmovaps [rsp+0x70], xmm8
000077a0e99d822c  vmovaps [rsp+0x80], xmm9
000077a0e99d8235  vmovaps [rsp+0x90], xmm10
000077a0e99d823e  vmovaps [rsp+0xA0], xmm11
000077a0e99d8247  vmovaps [rsp+0xB0], xmm12
000077a0e99d8250  vmovaps [rsp+0xC0], xmm13
000077a0e99d8259  vmovaps [rsp+0xD0], xmm14
000077a0e99d8262  vmovaps [rsp+0xE0], xmm15
000077a0e99d826b  sub rsp, 0x40
000077a0e99d826f  lea rdi, [rsp]
000077a0e99d8273  lea rsi, [rsp+0x10]
000077a0e99d8278  lea rdx, [rsp+0x20]
000077a0e99d827d  lea rcx, [rsp+0x30]
000077a0e99d8282  mov r8d, 0x00
000077a0e99d8288  lea r9, [r15+0x3A8]
000077a0e99d828f  movaps [rdi], xmm7
000077a0e99d8292  movaps [rsi], xmm13
000077a0e99d8296  movaps [rdx], xmm1
000077a0e99d8299  movaps [rcx], xmm9
000077a0e99d829d  mov rax, 0x60CAA235BA50
000077a0e99d82a7  call rax
000077a0e99d82a9  movaps xmm7, [rsp]
000077a0e99d82ad  add rsp, 0x40
000077a0e99d82b1  vmovaps xmm0, [rsp]
000077a0e99d82b6  vmovaps xmm1, [rsp+0x10]
000077a0e99d82bc  vmovaps xmm2, [rsp+0x20]
000077a0e99d82c2  vmovaps xmm3, [rsp+0x30]
000077a0e99d82c8  vmovaps xmm4, [rsp+0x40]
000077a0e99d82ce  vmovaps xmm5, [rsp+0x50]
000077a0e99d82d4  vmovaps xmm6, [rsp+0x60]
000077a0e99d82da  vmovaps xmm8, [rsp+0x70]
000077a0e99d82e0  vmovaps xmm9, [rsp+0x80]
000077a0e99d82e9  vmovaps xmm10, [rsp+0x90]
000077a0e99d82f2  vmovaps xmm11, [rsp+0xA0]
000077a0e99d82fb  vmovaps xmm12, [rsp+0xB0]
000077a0e99d8304  vmovaps xmm13, [rsp+0xC0]
000077a0e99d830d  vmovaps xmm14, [rsp+0xD0]
000077a0e99d8316  vmovaps xmm15, [rsp+0xE0]
000077a0e99d831f  add rsp, 0xF0
000077a0e99d8326  pop r11
000077a0e99d8328  pop r10
000077a0e99d832a  pop r9
000077a0e99d832c  pop r8
000077a0e99d832e  pop rsi
000077a0e99d832f  pop rdi
000077a0e99d8330  pop rdx
000077a0e99d8331  pop rcx
000077a0e99d8332  pop rax
000077a0e99d8333  add rsp, 0x08
000077a0e99d8337  jmp 0x000077A0E99D6955
000077a0e99d833c  call 0x000077A0E98E3320
000077a0e99d8341  jmp 0x000077A0E99D6978
000077a0e99d8346  call 0x000077A0E98DE950
000077a0e99d834b  jmp 0x000077A0E99D6982
000077a0e99d8350  sub rsp, 0x08
000077a0e99d8354  push rax
000077a0e99d8355  push rcx
000077a0e99d8356  push rdx
000077a0e99d8357  push rdi
000077a0e99d8358  push rsi
000077a0e99d8359  push r8
000077a0e99d835b  push r9
000077a0e99d835d  push r10
000077a0e99d835f  push r11
000077a0e99d8361  sub rsp, 0xF0
000077a0e99d8368  vmovaps [rsp], xmm0
000077a0e99d836d  vmovaps [rsp+0x10], xmm1
000077a0e99d8373  vmovaps [rsp+0x20], xmm3
000077a0e99d8379  vmovaps [rsp+0x30], xmm4
000077a0e99d837f  vmovaps [rsp+0x40], xmm5
000077a0e99d8385  vmovaps [rsp+0x50], xmm6
000077a0e99d838b  vmovaps [rsp+0x60], xmm7
000077a0e99d8391  vmovaps [rsp+0x70], xmm8
000077a0e99d8397  vmovaps [rsp+0x80], xmm9
000077a0e99d83a0  vmovaps [rsp+0x90], xmm10
000077a0e99d83a9  vmovaps [rsp+0xA0], xmm11
000077a0e99d83b2  vmovaps [rsp+0xB0], xmm12
000077a0e99d83bb  vmovaps [rsp+0xC0], xmm13
000077a0e99d83c4  vmovaps [rsp+0xD0], xmm14
000077a0e99d83cd  vmovaps [rsp+0xE0], xmm15
000077a0e99d83d6  sub rsp, 0x40
000077a0e99d83da  lea rdi, [rsp]
000077a0e99d83de  lea rsi, [rsp+0x10]
000077a0e99d83e3  lea rdx, [rsp+0x20]
000077a0e99d83e8  lea rcx, [rsp+0x30]
000077a0e99d83ed  mov r8d, 0x00
000077a0e99d83f3  lea r9, [r15+0x3A8]
000077a0e99d83fa  movaps [rdi], xmm2
000077a0e99d83fd  movaps [rsi], xmm12
000077a0e99d8401  movaps [rdx], xmm6
000077a0e99d8404  movaps [rcx], xmm3
000077a0e99d8407  mov rax, 0x60CAA235BA50
000077a0e99d8411  call rax
000077a0e99d8413  movaps xmm2, [rsp]
000077a0e99d8417  add rsp, 0x40
000077a0e99d841b  vmovaps xmm0, [rsp]
000077a0e99d8420  vmovaps xmm1, [rsp+0x10]
000077a0e99d8426  vmovaps xmm3, [rsp+0x20]
000077a0e99d842c  vmovaps xmm4, [rsp+0x30]
000077a0e99d8432  vmovaps xmm5, [rsp+0x40]
000077a0e99d8438  vmovaps xmm6, [rsp+0x50]
000077a0e99d843e  vmovaps xmm7, [rsp+0x60]
000077a0e99d8444  vmovaps xmm8, [rsp+0x70]
000077a0e99d844a  vmovaps xmm9, [rsp+0x80]
000077a0e99d8453  vmovaps xmm10, [rsp+0x90]
000077a0e99d845c  vmovaps xmm11, [rsp+0xA0]
000077a0e99d8465  vmovaps xmm12, [rsp+0xB0]
000077a0e99d846e  vmovaps xmm13, [rsp+0xC0]
000077a0e99d8477  vmovaps xmm14, [rsp+0xD0]
000077a0e99d8480  vmovaps xmm15, [rsp+0xE0]
000077a0e99d8489  add rsp, 0xF0
000077a0e99d8490  pop r11
000077a0e99d8492  pop r10
000077a0e99d8494  pop r9
000077a0e99d8496  pop r8
000077a0e99d8498  pop rsi
000077a0e99d8499  pop rdi
000077a0e99d849a  pop rdx
000077a0e99d849b  pop rcx
000077a0e99d849c  pop rax
000077a0e99d849d  add rsp, 0x08
000077a0e99d84a1  jmp 0x000077A0E99D69C8
000077a0e99d84a6  sub rsp, 0x08
000077a0e99d84aa  push rax
000077a0e99d84ab  push rcx
000077a0e99d84ac  push rdx
000077a0e99d84ad  push rdi
000077a0e99d84ae  push rsi
000077a0e99d84af  push r8
000077a0e99d84b1  push r9
000077a0e99d84b3  push r10
000077a0e99d84b5  push r11
000077a0e99d84b7  sub rsp, 0xF0
000077a0e99d84be  vmovaps [rsp], xmm0
000077a0e99d84c3  vmovaps [rsp+0x10], xmm1
000077a0e99d84c9  vmovaps [rsp+0x20], xmm2
000077a0e99d84cf  vmovaps [rsp+0x30], xmm3
000077a0e99d84d5  vmovaps [rsp+0x40], xmm4
000077a0e99d84db  vmovaps [rsp+0x50], xmm5
000077a0e99d84e1  vmovaps [rsp+0x60], xmm7
000077a0e99d84e7  vmovaps [rsp+0x70], xmm8
000077a0e99d84ed  vmovaps [rsp+0x80], xmm9
000077a0e99d84f6  vmovaps [rsp+0x90], xmm10
000077a0e99d84ff  vmovaps [rsp+0xA0], xmm11
000077a0e99d8508  vmovaps [rsp+0xB0], xmm12
000077a0e99d8511  vmovaps [rsp+0xC0], xmm13
000077a0e99d851a  vmovaps [rsp+0xD0], xmm14
000077a0e99d8523  vmovaps [rsp+0xE0], xmm15
000077a0e99d852c  sub rsp, 0x40
000077a0e99d8530  lea rdi, [rsp]
000077a0e99d8534  lea rsi, [rsp+0x10]
000077a0e99d8539  lea rdx, [rsp+0x20]
000077a0e99d853e  lea rcx, [rsp+0x30]
000077a0e99d8543  mov r8d, 0x00
000077a0e99d8549  lea r9, [r15+0x3A8]
000077a0e99d8550  movaps [rdi], xmm6
000077a0e99d8553  movaps [rsi], xmm10
000077a0e99d8557  movaps [rdx], xmm12
000077a0e99d855b  movaps [rcx], xmm1
000077a0e99d855e  mov rax, 0x60CAA235BA50
000077a0e99d8568  call rax
000077a0e99d856a  movaps xmm6, [rsp]
000077a0e99d856e  add rsp, 0x40
000077a0e99d8572  vmovaps xmm0, [rsp]
000077a0e99d8577  vmovaps xmm1, [rsp+0x10]
000077a0e99d857d  vmovaps xmm2, [rsp+0x20]
000077a0e99d8583  vmovaps xmm3, [rsp+0x30]
000077a0e99d8589  vmovaps xmm4, [rsp+0x40]
000077a0e99d858f  vmovaps xmm5, [rsp+0x50]
000077a0e99d8595  vmovaps xmm7, [rsp+0x60]
000077a0e99d859b  vmovaps xmm8, [rsp+0x70]
000077a0e99d85a1  vmovaps xmm9, [rsp+0x80]
000077a0e99d85aa  vmovaps xmm10, [rsp+0x90]
000077a0e99d85b3  vmovaps xmm11, [rsp+0xA0]
000077a0e99d85bc  vmovaps xmm12, [rsp+0xB0]
000077a0e99d85c5  vmovaps xmm13, [rsp+0xC0]
000077a0e99d85ce  vmovaps xmm14, [rsp+0xD0]
000077a0e99d85d7  vmovaps xmm15, [rsp+0xE0]
000077a0e99d85e0  add rsp, 0xF0
000077a0e99d85e7  pop r11
000077a0e99d85e9  pop r10
000077a0e99d85eb  pop r9
000077a0e99d85ed  pop r8
000077a0e99d85ef  pop rsi
000077a0e99d85f0  pop rdi
000077a0e99d85f1  pop rdx
000077a0e99d85f2  pop rcx
000077a0e99d85f3  pop rax
000077a0e99d85f4  add rsp, 0x08
000077a0e99d85f8  jmp 0x000077A0E99D69F6
000077a0e99d85fd  sub rsp, 0x08
000077a0e99d8601  push rax
000077a0e99d8602  push rcx
000077a0e99d8603  push rdx
000077a0e99d8604  push rdi
000077a0e99d8605  push rsi
000077a0e99d8606  push r8
000077a0e99d8608  push r9
000077a0e99d860a  push r10
000077a0e99d860c  push r11
000077a0e99d860e  sub rsp, 0xF0
000077a0e99d8615  vmovaps [rsp], xmm0
000077a0e99d861a  vmovaps [rsp+0x10], xmm1
000077a0e99d8620  vmovaps [rsp+0x20], xmm2
000077a0e99d8626  vmovaps [rsp+0x30], xmm3
000077a0e99d862c  vmovaps [rsp+0x40], xmm4
000077a0e99d8632  vmovaps [rsp+0x50], xmm5
000077a0e99d8638  vmovaps [rsp+0x60], xmm6
000077a0e99d863e  vmovaps [rsp+0x70], xmm7
000077a0e99d8644  vmovaps [rsp+0x80], xmm8
000077a0e99d864d  vmovaps [rsp+0x90], xmm9
000077a0e99d8656  vmovaps [rsp+0xA0], xmm11
000077a0e99d865f  vmovaps [rsp+0xB0], xmm12
000077a0e99d8668  vmovaps [rsp+0xC0], xmm13
000077a0e99d8671  vmovaps [rsp+0xD0], xmm14
000077a0e99d867a  vmovaps [rsp+0xE0], xmm15
000077a0e99d8683  sub rsp, 0x40
000077a0e99d8687  lea rdi, [rsp]
000077a0e99d868b  lea rsi, [rsp+0x10]
000077a0e99d8690  lea rdx, [rsp+0x20]
000077a0e99d8695  lea rcx, [rsp+0x30]
000077a0e99d869a  mov r8d, 0x00
000077a0e99d86a0  lea r9, [r15+0x3A8]
000077a0e99d86a7  movaps [rdi], xmm10
000077a0e99d86ab  movaps [rsi], xmm5
000077a0e99d86ae  movaps [rdx], xmm12
000077a0e99d86b2  movaps [rcx], xmm1
000077a0e99d86b5  mov rax, 0x60CAA235BA50
000077a0e99d86bf  call rax
000077a0e99d86c1  movaps xmm10, [rsp]
000077a0e99d86c6  add rsp, 0x40
000077a0e99d86ca  vmovaps xmm0, [rsp]
000077a0e99d86cf  vmovaps xmm1, [rsp+0x10]
000077a0e99d86d5  vmovaps xmm2, [rsp+0x20]
000077a0e99d86db  vmovaps xmm3, [rsp+0x30]
000077a0e99d86e1  vmovaps xmm4, [rsp+0x40]
000077a0e99d86e7  vmovaps xmm5, [rsp+0x50]
000077a0e99d86ed  vmovaps xmm6, [rsp+0x60]
000077a0e99d86f3  vmovaps xmm7, [rsp+0x70]
000077a0e99d86f9  vmovaps xmm8, [rsp+0x80]
000077a0e99d8702  vmovaps xmm9, [rsp+0x90]
000077a0e99d870b  vmovaps xmm11, [rsp+0xA0]
000077a0e99d8714  vmovaps xmm12, [rsp+0xB0]
000077a0e99d871d  vmovaps xmm13, [rsp+0xC0]
000077a0e99d8726  vmovaps xmm14, [rsp+0xD0]
000077a0e99d872f  vmovaps xmm15, [rsp+0xE0]
000077a0e99d8738  add rsp, 0xF0
000077a0e99d873f  pop r11
000077a0e99d8741  pop r10
000077a0e99d8743  pop r9
000077a0e99d8745  pop r8
000077a0e99d8747  pop rsi
000077a0e99d8748  pop rdi
000077a0e99d8749  pop rdx
000077a0e99d874a  pop rcx
000077a0e99d874b  pop rax
000077a0e99d874c  add rsp, 0x08
000077a0e99d8750  jmp 0x000077A0E99D6A25
000077a0e99d8755  sub rsp, 0x08
000077a0e99d8759  push rax
000077a0e99d875a  push rcx
000077a0e99d875b  push rdx
000077a0e99d875c  push rdi
000077a0e99d875d  push rsi
000077a0e99d875e  push r8
000077a0e99d8760  push r9
000077a0e99d8762  push r10
000077a0e99d8764  push r11
000077a0e99d8766  sub rsp, 0xF0
000077a0e99d876d  vmovaps [rsp], xmm0
000077a0e99d8772  vmovaps [rsp+0x10], xmm1
000077a0e99d8778  vmovaps [rsp+0x20], xmm2
000077a0e99d877e  vmovaps [rsp+0x30], xmm3
000077a0e99d8784  vmovaps [rsp+0x40], xmm4
000077a0e99d878a  vmovaps [rsp+0x50], xmm5
000077a0e99d8790  vmovaps [rsp+0x60], xmm6
000077a0e99d8796  vmovaps [rsp+0x70], xmm7
000077a0e99d879c  vmovaps [rsp+0x80], xmm8
000077a0e99d87a5  vmovaps [rsp+0x90], xmm9
000077a0e99d87ae  vmovaps [rsp+0xA0], xmm10
000077a0e99d87b7  vmovaps [rsp+0xB0], xmm11
000077a0e99d87c0  vmovaps [rsp+0xC0], xmm13
000077a0e99d87c9  vmovaps [rsp+0xD0], xmm14
000077a0e99d87d2  vmovaps [rsp+0xE0], xmm15
000077a0e99d87db  sub rsp, 0x40
000077a0e99d87df  lea rdi, [rsp]
000077a0e99d87e3  lea rsi, [rsp+0x10]
000077a0e99d87e8  lea rdx, [rsp+0x20]
000077a0e99d87ed  lea rcx, [rsp+0x30]
000077a0e99d87f2  mov r8d, 0x00
000077a0e99d87f8  lea r9, [r15+0x3A8]
000077a0e99d87ff  movaps [rdi], xmm12
000077a0e99d8803  movaps [rsi], xmm7
000077a0e99d8806  movaps [rdx], xmm15
000077a0e99d880a  movaps [rcx], xmm1
000077a0e99d880d  mov rax, 0x60CAA235BA50
000077a0e99d8817  call rax
000077a0e99d8819  movaps xmm12, [rsp]
000077a0e99d881e  add rsp, 0x40
000077a0e99d8822  vmovaps xmm0, [rsp]
000077a0e99d8827  vmovaps xmm1, [rsp+0x10]
000077a0e99d882d  vmovaps xmm2, [rsp+0x20]
000077a0e99d8833  vmovaps xmm3, [rsp+0x30]
000077a0e99d8839  vmovaps xmm4, [rsp+0x40]
000077a0e99d883f  vmovaps xmm5, [rsp+0x50]
000077a0e99d8845  vmovaps xmm6, [rsp+0x60]
000077a0e99d884b  vmovaps xmm7, [rsp+0x70]
000077a0e99d8851  vmovaps xmm8, [rsp+0x80]
000077a0e99d885a  vmovaps xmm9, [rsp+0x90]
000077a0e99d8863  vmovaps xmm10, [rsp+0xA0]
000077a0e99d886c  vmovaps xmm11, [rsp+0xB0]
000077a0e99d8875  vmovaps xmm13, [rsp+0xC0]
000077a0e99d887e  vmovaps xmm14, [rsp+0xD0]
000077a0e99d8887  vmovaps xmm15, [rsp+0xE0]
000077a0e99d8890  add rsp, 0xF0
000077a0e99d8897  pop r11
000077a0e99d8899  pop r10
000077a0e99d889b  pop r9
000077a0e99d889d  pop r8
000077a0e99d889f  pop rsi
000077a0e99d88a0  pop rdi
000077a0e99d88a1  pop rdx
000077a0e99d88a2  pop rcx
000077a0e99d88a3  pop rax
000077a0e99d88a4  add rsp, 0x08
000077a0e99d88a8  jmp 0x000077A0E99D6A4E
000077a0e99d88ad  call 0x000077A0E98D64F0
000077a0e99d88b2  jmp 0x000077A0E99D6A58
000077a0e99d88b7  call 0x000077A0E98E5820
000077a0e99d88bc  jmp 0x000077A0E99D6A62
000077a0e99d88c1  sub rsp, 0x08
000077a0e99d88c5  push rax
000077a0e99d88c6  push rcx
000077a0e99d88c7  push rdx
000077a0e99d88c8  push rdi
000077a0e99d88c9  push rsi
000077a0e99d88ca  push r8
000077a0e99d88cc  push r9
000077a0e99d88ce  push r10
000077a0e99d88d0  push r11
000077a0e99d88d2  sub rsp, 0xF0
000077a0e99d88d9  vmovaps [rsp], xmm0
000077a0e99d88de  vmovaps [rsp+0x10], xmm1
000077a0e99d88e4  vmovaps [rsp+0x20], xmm2
000077a0e99d88ea  vmovaps [rsp+0x30], xmm3
000077a0e99d88f0  vmovaps [rsp+0x40], xmm4
000077a0e99d88f6  vmovaps [rsp+0x50], xmm5
000077a0e99d88fc  vmovaps [rsp+0x60], xmm6
000077a0e99d8902  vmovaps [rsp+0x70], xmm8
000077a0e99d8908  vmovaps [rsp+0x80], xmm9
000077a0e99d8911  vmovaps [rsp+0x90], xmm10
000077a0e99d891a  vmovaps [rsp+0xA0], xmm11
000077a0e99d8923  vmovaps [rsp+0xB0], xmm12
000077a0e99d892c  vmovaps [rsp+0xC0], xmm13
000077a0e99d8935  vmovaps [rsp+0xD0], xmm14
000077a0e99d893e  vmovaps [rsp+0xE0], xmm15
000077a0e99d8947  sub rsp, 0x40
000077a0e99d894b  lea rdi, [rsp]
000077a0e99d894f  lea rsi, [rsp+0x10]
000077a0e99d8954  lea rdx, [rsp+0x20]
000077a0e99d8959  lea rcx, [rsp+0x30]
000077a0e99d895e  mov r8d, 0x00
000077a0e99d8964  lea r9, [r15+0x3A8]
000077a0e99d896b  movaps [rdi], xmm7
000077a0e99d896e  movaps [rsi], xmm2
000077a0e99d8971  movaps [rdx], xmm9
000077a0e99d8975  movaps [rcx], xmm11
000077a0e99d8979  mov rax, 0x60CAA235BA50
000077a0e99d8983  call rax
000077a0e99d8985  movaps xmm7, [rsp]
000077a0e99d8989  add rsp, 0x40
000077a0e99d898d  vmovaps xmm0, [rsp]
000077a0e99d8992  vmovaps xmm1, [rsp+0x10]
000077a0e99d8998  vmovaps xmm2, [rsp+0x20]
000077a0e99d899e  vmovaps xmm3, [rsp+0x30]
000077a0e99d89a4  vmovaps xmm4, [rsp+0x40]
000077a0e99d89aa  vmovaps xmm5, [rsp+0x50]
000077a0e99d89b0  vmovaps xmm6, [rsp+0x60]
000077a0e99d89b6  vmovaps xmm8, [rsp+0x70]
000077a0e99d89bc  vmovaps xmm9, [rsp+0x80]
000077a0e99d89c5  vmovaps xmm10, [rsp+0x90]
000077a0e99d89ce  vmovaps xmm11, [rsp+0xA0]
000077a0e99d89d7  vmovaps xmm12, [rsp+0xB0]
000077a0e99d89e0  vmovaps xmm13, [rsp+0xC0]
000077a0e99d89e9  vmovaps xmm14, [rsp+0xD0]
000077a0e99d89f2  vmovaps xmm15, [rsp+0xE0]
000077a0e99d89fb  add rsp, 0xF0
000077a0e99d8a02  pop r11
000077a0e99d8a04  pop r10
000077a0e99d8a06  pop r9
000077a0e99d8a08  pop r8
000077a0e99d8a0a  pop rsi
000077a0e99d8a0b  pop rdi
000077a0e99d8a0c  pop rdx
000077a0e99d8a0d  pop rcx
000077a0e99d8a0e  pop rax
000077a0e99d8a0f  add rsp, 0x08
000077a0e99d8a13  jmp 0x000077A0E99D6A96
000077a0e99d8a18  sub rsp, 0x08
000077a0e99d8a1c  push rax
000077a0e99d8a1d  push rcx
000077a0e99d8a1e  push rdx
000077a0e99d8a1f  push rdi
000077a0e99d8a20  push rsi
000077a0e99d8a21  push r8
000077a0e99d8a23  push r9
000077a0e99d8a25  push r10
000077a0e99d8a27  push r11
000077a0e99d8a29  sub rsp, 0xF0
000077a0e99d8a30  vmovaps [rsp], xmm0
000077a0e99d8a35  vmovaps [rsp+0x10], xmm1
000077a0e99d8a3b  vmovaps [rsp+0x20], xmm2
000077a0e99d8a41  vmovaps [rsp+0x30], xmm3
000077a0e99d8a47  vmovaps [rsp+0x40], xmm4
000077a0e99d8a4d  vmovaps [rsp+0x50], xmm5
000077a0e99d8a53  vmovaps [rsp+0x60], xmm6
000077a0e99d8a59  vmovaps [rsp+0x70], xmm7
000077a0e99d8a5f  vmovaps [rsp+0x80], xmm8
000077a0e99d8a68  vmovaps [rsp+0x90], xmm10
000077a0e99d8a71  vmovaps [rsp+0xA0], xmm11
000077a0e99d8a7a  vmovaps [rsp+0xB0], xmm12
000077a0e99d8a83  vmovaps [rsp+0xC0], xmm13
000077a0e99d8a8c  vmovaps [rsp+0xD0], xmm14
000077a0e99d8a95  vmovaps [rsp+0xE0], xmm15
000077a0e99d8a9e  sub rsp, 0x40
000077a0e99d8aa2  lea rdi, [rsp]
000077a0e99d8aa6  lea rsi, [rsp+0x10]
000077a0e99d8aab  lea rdx, [rsp+0x20]
000077a0e99d8ab0  lea rcx, [rsp+0x30]
000077a0e99d8ab5  mov r8d, 0x00
000077a0e99d8abb  lea r9, [r15+0x3A8]
000077a0e99d8ac2  movaps [rdi], xmm9
000077a0e99d8ac6  movaps [rsi], xmm6
000077a0e99d8ac9  movaps [rdx], xmm1
000077a0e99d8acc  movaps [rcx], xmm11
000077a0e99d8ad0  mov rax, 0x60CAA235BA50
000077a0e99d8ada  call rax
000077a0e99d8adc  movaps xmm9, [rsp]
000077a0e99d8ae1  add rsp, 0x40
000077a0e99d8ae5  vmovaps xmm0, [rsp]
000077a0e99d8aea  vmovaps xmm1, [rsp+0x10]
000077a0e99d8af0  vmovaps xmm2, [rsp+0x20]
000077a0e99d8af6  vmovaps xmm3, [rsp+0x30]
000077a0e99d8afc  vmovaps xmm4, [rsp+0x40]
000077a0e99d8b02  vmovaps xmm5, [rsp+0x50]
000077a0e99d8b08  vmovaps xmm6, [rsp+0x60]
000077a0e99d8b0e  vmovaps xmm7, [rsp+0x70]
000077a0e99d8b14  vmovaps xmm8, [rsp+0x80]
000077a0e99d8b1d  vmovaps xmm10, [rsp+0x90]
000077a0e99d8b26  vmovaps xmm11, [rsp+0xA0]
000077a0e99d8b2f  vmovaps xmm12, [rsp+0xB0]
000077a0e99d8b38  vmovaps xmm13, [rsp+0xC0]
000077a0e99d8b41  vmovaps xmm14, [rsp+0xD0]
000077a0e99d8b4a  vmovaps xmm15, [rsp+0xE0]
000077a0e99d8b53  add rsp, 0xF0
000077a0e99d8b5a  pop r11
000077a0e99d8b5c  pop r10
000077a0e99d8b5e  pop r9
000077a0e99d8b60  pop r8
000077a0e99d8b62  pop rsi
000077a0e99d8b63  pop rdi
000077a0e99d8b64  pop rdx
000077a0e99d8b65  pop rcx
000077a0e99d8b66  pop rax
000077a0e99d8b67  add rsp, 0x08
000077a0e99d8b6b  jmp 0x000077A0E99D6ABC
000077a0e99d8b70  sub rsp, 0x08
000077a0e99d8b74  push rax
000077a0e99d8b75  push rcx
000077a0e99d8b76  push rdx
000077a0e99d8b77  push rdi
000077a0e99d8b78  push rsi
000077a0e99d8b79  push r8
000077a0e99d8b7b  push r9
000077a0e99d8b7d  push r10
000077a0e99d8b7f  push r11
000077a0e99d8b81  sub rsp, 0xF0
000077a0e99d8b88  vmovaps [rsp], xmm0
000077a0e99d8b8d  vmovaps [rsp+0x10], xmm1
000077a0e99d8b93  vmovaps [rsp+0x20], xmm2
000077a0e99d8b99  vmovaps [rsp+0x30], xmm3
000077a0e99d8b9f  vmovaps [rsp+0x40], xmm4
000077a0e99d8ba5  vmovaps [rsp+0x50], xmm5
000077a0e99d8bab  vmovaps [rsp+0x60], xmm6
000077a0e99d8bb1  vmovaps [rsp+0x70], xmm7
000077a0e99d8bb7  vmovaps [rsp+0x80], xmm8
000077a0e99d8bc0  vmovaps [rsp+0x90], xmm9
000077a0e99d8bc9  vmovaps [rsp+0xA0], xmm10
000077a0e99d8bd2  vmovaps [rsp+0xB0], xmm12
000077a0e99d8bdb  vmovaps [rsp+0xC0], xmm13
000077a0e99d8be4  vmovaps [rsp+0xD0], xmm14
000077a0e99d8bed  vmovaps [rsp+0xE0], xmm15
000077a0e99d8bf6  sub rsp, 0x40
000077a0e99d8bfa  lea rdi, [rsp]
000077a0e99d8bfe  lea rsi, [rsp+0x10]
000077a0e99d8c03  lea rdx, [rsp+0x20]
000077a0e99d8c08  lea rcx, [rsp+0x30]
000077a0e99d8c0d  mov r8d, 0x00
000077a0e99d8c13  lea r9, [r15+0x3A8]
000077a0e99d8c1a  movaps [rdi], xmm11
000077a0e99d8c1e  movaps [rsi], xmm10
000077a0e99d8c22  movaps [rdx], xmm8
000077a0e99d8c26  movaps [rcx], xmm1
000077a0e99d8c29  mov rax, 0x60CAA235BA50
000077a0e99d8c33  call rax
000077a0e99d8c35  movaps xmm11, [rsp]
000077a0e99d8c3a  add rsp, 0x40
000077a0e99d8c3e  vmovaps xmm0, [rsp]
000077a0e99d8c43  vmovaps xmm1, [rsp+0x10]
000077a0e99d8c49  vmovaps xmm2, [rsp+0x20]
000077a0e99d8c4f  vmovaps xmm3, [rsp+0x30]
000077a0e99d8c55  vmovaps xmm4, [rsp+0x40]
000077a0e99d8c5b  vmovaps xmm5, [rsp+0x50]
000077a0e99d8c61  vmovaps xmm6, [rsp+0x60]
000077a0e99d8c67  vmovaps xmm7, [rsp+0x70]
000077a0e99d8c6d  vmovaps xmm8, [rsp+0x80]
000077a0e99d8c76  vmovaps xmm9, [rsp+0x90]
000077a0e99d8c7f  vmovaps xmm10, [rsp+0xA0]
000077a0e99d8c88  vmovaps xmm12, [rsp+0xB0]
000077a0e99d8c91  vmovaps xmm13, [rsp+0xC0]
000077a0e99d8c9a  vmovaps xmm14, [rsp+0xD0]
000077a0e99d8ca3  vmovaps xmm15, [rsp+0xE0]
000077a0e99d8cac  add rsp, 0xF0
000077a0e99d8cb3  pop r11
000077a0e99d8cb5  pop r10
000077a0e99d8cb7  pop r9
000077a0e99d8cb9  pop r8
000077a0e99d8cbb  pop rsi
000077a0e99d8cbc  pop rdi
000077a0e99d8cbd  pop rdx
000077a0e99d8cbe  pop rcx
000077a0e99d8cbf  pop rax
000077a0e99d8cc0  add rsp, 0x08
000077a0e99d8cc4  jmp 0x000077A0E99D6AE2
000077a0e99d8cc9  sub rsp, 0x08
000077a0e99d8ccd  push rax
000077a0e99d8cce  push rcx
000077a0e99d8ccf  push rdx
000077a0e99d8cd0  push rdi
000077a0e99d8cd1  push rsi
000077a0e99d8cd2  push r8
000077a0e99d8cd4  push r9
000077a0e99d8cd6  push r10
000077a0e99d8cd8  push r11
000077a0e99d8cda  sub rsp, 0xF0
000077a0e99d8ce1  vmovaps [rsp], xmm0
000077a0e99d8ce6  vmovaps [rsp+0x10], xmm1
000077a0e99d8cec  vmovaps [rsp+0x20], xmm2
000077a0e99d8cf2  vmovaps [rsp+0x30], xmm3
000077a0e99d8cf8  vmovaps [rsp+0x40], xmm4
000077a0e99d8cfe  vmovaps [rsp+0x50], xmm5
000077a0e99d8d04  vmovaps [rsp+0x60], xmm6
000077a0e99d8d0a  vmovaps [rsp+0x70], xmm7
000077a0e99d8d10  vmovaps [rsp+0x80], xmm8
000077a0e99d8d19  vmovaps [rsp+0x90], xmm9
000077a0e99d8d22  vmovaps [rsp+0xA0], xmm11
000077a0e99d8d2b  vmovaps [rsp+0xB0], xmm12
000077a0e99d8d34  vmovaps [rsp+0xC0], xmm13
000077a0e99d8d3d  vmovaps [rsp+0xD0], xmm14
000077a0e99d8d46  vmovaps [rsp+0xE0], xmm15
000077a0e99d8d4f  sub rsp, 0x40
000077a0e99d8d53  lea rdi, [rsp]
000077a0e99d8d57  lea rsi, [rsp+0x10]
000077a0e99d8d5c  lea rdx, [rsp+0x20]
000077a0e99d8d61  lea rcx, [rsp+0x30]
000077a0e99d8d66  mov r8d, 0x00
000077a0e99d8d6c  lea r9, [r15+0x3A8]
000077a0e99d8d73  movaps [rdi], xmm10
000077a0e99d8d77  movaps [rsi], xmm12
000077a0e99d8d7b  movaps [rdx], xmm13
000077a0e99d8d7f  movaps [rcx], xmm1
000077a0e99d8d82  mov rax, 0x60CAA235BA50
000077a0e99d8d8c  call rax
000077a0e99d8d8e  movaps xmm10, [rsp]
000077a0e99d8d93  add rsp, 0x40
000077a0e99d8d97  vmovaps xmm0, [rsp]
000077a0e99d8d9c  vmovaps xmm1, [rsp+0x10]
000077a0e99d8da2  vmovaps xmm2, [rsp+0x20]
000077a0e99d8da8  vmovaps xmm3, [rsp+0x30]
000077a0e99d8dae  vmovaps xmm4, [rsp+0x40]
000077a0e99d8db4  vmovaps xmm5, [rsp+0x50]
000077a0e99d8dba  vmovaps xmm6, [rsp+0x60]
000077a0e99d8dc0  vmovaps xmm7, [rsp+0x70]
000077a0e99d8dc6  vmovaps xmm8, [rsp+0x80]
000077a0e99d8dcf  vmovaps xmm9, [rsp+0x90]
000077a0e99d8dd8  vmovaps xmm11, [rsp+0xA0]
000077a0e99d8de1  vmovaps xmm12, [rsp+0xB0]
000077a0e99d8dea  vmovaps xmm13, [rsp+0xC0]
000077a0e99d8df3  vmovaps xmm14, [rsp+0xD0]
000077a0e99d8dfc  vmovaps xmm15, [rsp+0xE0]
000077a0e99d8e05  add rsp, 0xF0
000077a0e99d8e0c  pop r11
000077a0e99d8e0e  pop r10
000077a0e99d8e10  pop r9
000077a0e99d8e12  pop r8
000077a0e99d8e14  pop rsi
000077a0e99d8e15  pop rdi
000077a0e99d8e16  pop rdx
000077a0e99d8e17  pop rcx
000077a0e99d8e18  pop rax
000077a0e99d8e19  add rsp, 0x08
000077a0e99d8e1d  jmp 0x000077A0E99D6B08
000077a0e99d8e22  call 0x000077A0E98D64F0
000077a0e99d8e27  jmp 0x000077A0E99D6B12
000077a0e99d8e2c  call 0x000077A0E98E3320
000077a0e99d8e31  jmp 0x000077A0E99D6B1C
000077a0e99d8e36  sub rsp, 0x08
000077a0e99d8e3a  push rax
000077a0e99d8e3b  push rcx
000077a0e99d8e3c  push rdx
000077a0e99d8e3d  push rdi
000077a0e99d8e3e  push rsi
000077a0e99d8e3f  push r8
000077a0e99d8e41  push r9
000077a0e99d8e43  push r10
000077a0e99d8e45  push r11
000077a0e99d8e47  sub rsp, 0xF0
000077a0e99d8e4e  vmovaps [rsp], xmm0
000077a0e99d8e53  vmovaps [rsp+0x10], xmm1
000077a0e99d8e59  vmovaps [rsp+0x20], xmm2
000077a0e99d8e5f  vmovaps [rsp+0x30], xmm3
000077a0e99d8e65  vmovaps [rsp+0x40], xmm4
000077a0e99d8e6b  vmovaps [rsp+0x50], xmm5
000077a0e99d8e71  vmovaps [rsp+0x60], xmm6
000077a0e99d8e77  vmovaps [rsp+0x70], xmm7
000077a0e99d8e7d  vmovaps [rsp+0x80], xmm9
000077a0e99d8e86  vmovaps [rsp+0x90], xmm10
000077a0e99d8e8f  vmovaps [rsp+0xA0], xmm11
000077a0e99d8e98  vmovaps [rsp+0xB0], xmm12
000077a0e99d8ea1  vmovaps [rsp+0xC0], xmm13
000077a0e99d8eaa  vmovaps [rsp+0xD0], xmm14
000077a0e99d8eb3  vmovaps [rsp+0xE0], xmm15
000077a0e99d8ebc  sub rsp, 0x40
000077a0e99d8ec0  lea rdi, [rsp]
000077a0e99d8ec4  lea rsi, [rsp+0x10]
000077a0e99d8ec9  lea rdx, [rsp+0x20]
000077a0e99d8ece  lea rcx, [rsp+0x30]
000077a0e99d8ed3  mov r8d, 0x00
000077a0e99d8ed9  lea r9, [r15+0x3A8]
000077a0e99d8ee0  movaps [rdi], xmm8
000077a0e99d8ee4  movaps [rsi], xmm7
000077a0e99d8ee7  movaps [rdx], xmm4
000077a0e99d8eea  movaps [rcx], xmm12
000077a0e99d8eee  mov rax, 0x60CAA235BA50
000077a0e99d8ef8  call rax
000077a0e99d8efa  movaps xmm8, [rsp]
000077a0e99d8eff  add rsp, 0x40
000077a0e99d8f03  vmovaps xmm0, [rsp]
000077a0e99d8f08  vmovaps xmm1, [rsp+0x10]
000077a0e99d8f0e  vmovaps xmm2, [rsp+0x20]
000077a0e99d8f14  vmovaps xmm3, [rsp+0x30]
000077a0e99d8f1a  vmovaps xmm4, [rsp+0x40]
000077a0e99d8f20  vmovaps xmm5, [rsp+0x50]
000077a0e99d8f26  vmovaps xmm6, [rsp+0x60]
000077a0e99d8f2c  vmovaps xmm7, [rsp+0x70]
000077a0e99d8f32  vmovaps xmm9, [rsp+0x80]
000077a0e99d8f3b  vmovaps xmm10, [rsp+0x90]
000077a0e99d8f44  vmovaps xmm11, [rsp+0xA0]
000077a0e99d8f4d  vmovaps xmm12, [rsp+0xB0]
000077a0e99d8f56  vmovaps xmm13, [rsp+0xC0]
000077a0e99d8f5f  vmovaps xmm14, [rsp+0xD0]
000077a0e99d8f68  vmovaps xmm15, [rsp+0xE0]
000077a0e99d8f71  add rsp, 0xF0
000077a0e99d8f78  pop r11
000077a0e99d8f7a  pop r10
000077a0e99d8f7c  pop r9
000077a0e99d8f7e  pop r8
000077a0e99d8f80  pop rsi
000077a0e99d8f81  pop rdi
000077a0e99d8f82  pop rdx
000077a0e99d8f83  pop rcx
000077a0e99d8f84  pop rax
000077a0e99d8f85  add rsp, 0x08
000077a0e99d8f89  jmp 0x000077A0E99D6B45
000077a0e99d8f8e  sub rsp, 0x08
000077a0e99d8f92  push rax
000077a0e99d8f93  push rcx
000077a0e99d8f94  push rdx
000077a0e99d8f95  push rdi
000077a0e99d8f96  push rsi
000077a0e99d8f97  push r8
000077a0e99d8f99  push r9
000077a0e99d8f9b  push r10
000077a0e99d8f9d  push r11
000077a0e99d8f9f  sub rsp, 0xF0
000077a0e99d8fa6  vmovaps [rsp], xmm0
000077a0e99d8fab  vmovaps [rsp+0x10], xmm1
000077a0e99d8fb1  vmovaps [rsp+0x20], xmm2
000077a0e99d8fb7  vmovaps [rsp+0x30], xmm3
000077a0e99d8fbd  vmovaps [rsp+0x40], xmm4
000077a0e99d8fc3  vmovaps [rsp+0x50], xmm5
000077a0e99d8fc9  vmovaps [rsp+0x60], xmm6
000077a0e99d8fcf  vmovaps [rsp+0x70], xmm8
000077a0e99d8fd5  vmovaps [rsp+0x80], xmm9
000077a0e99d8fde  vmovaps [rsp+0x90], xmm10
000077a0e99d8fe7  vmovaps [rsp+0xA0], xmm11
000077a0e99d8ff0  vmovaps [rsp+0xB0], xmm12
000077a0e99d8ff9  vmovaps [rsp+0xC0], xmm13
000077a0e99d9002  vmovaps [rsp+0xD0], xmm14
000077a0e99d900b  vmovaps [rsp+0xE0], xmm15
000077a0e99d9014  sub rsp, 0x40
000077a0e99d9018  lea rdi, [rsp]
000077a0e99d901c  lea rsi, [rsp+0x10]
000077a0e99d9021  lea rdx, [rsp+0x20]
000077a0e99d9026  lea rcx, [rsp+0x30]
000077a0e99d902b  mov r8d, 0x00
000077a0e99d9031  lea r9, [r15+0x3A8]
000077a0e99d9038  movaps [rdi], xmm7
000077a0e99d903b  movaps [rsi], xmm9
000077a0e99d903f  movaps [rdx], xmm14
000077a0e99d9043  movaps [rcx], xmm12
000077a0e99d9047  mov rax, 0x60CAA235BA50
000077a0e99d9051  call rax
000077a0e99d9053  movaps xmm7, [rsp]
000077a0e99d9057  add rsp, 0x40
000077a0e99d905b  vmovaps xmm0, [rsp]
000077a0e99d9060  vmovaps xmm1, [rsp+0x10]
000077a0e99d9066  vmovaps xmm2, [rsp+0x20]
000077a0e99d906c  vmovaps xmm3, [rsp+0x30]
000077a0e99d9072  vmovaps xmm4, [rsp+0x40]
000077a0e99d9078  vmovaps xmm5, [rsp+0x50]
000077a0e99d907e  vmovaps xmm6, [rsp+0x60]
000077a0e99d9084  vmovaps xmm8, [rsp+0x70]
000077a0e99d908a  vmovaps xmm9, [rsp+0x80]
000077a0e99d9093  vmovaps xmm10, [rsp+0x90]
000077a0e99d909c  vmovaps xmm11, [rsp+0xA0]
000077a0e99d90a5  vmovaps xmm12, [rsp+0xB0]
000077a0e99d90ae  vmovaps xmm13, [rsp+0xC0]
000077a0e99d90b7  vmovaps xmm14, [rsp+0xD0]
000077a0e99d90c0  vmovaps xmm15, [rsp+0xE0]
000077a0e99d90c9  add rsp, 0xF0
000077a0e99d90d0  pop r11
000077a0e99d90d2  pop r10
000077a0e99d90d4  pop r9
000077a0e99d90d6  pop r8
000077a0e99d90d8  pop rsi
000077a0e99d90d9  pop rdi
000077a0e99d90da  pop rdx
000077a0e99d90db  pop rcx
000077a0e99d90dc  pop rax
000077a0e99d90dd  add rsp, 0x08
000077a0e99d90e1  jmp 0x000077A0E99D6B6D
000077a0e99d90e6  sub rsp, 0x08
000077a0e99d90ea  push rax
000077a0e99d90eb  push rcx
000077a0e99d90ec  push rdx
000077a0e99d90ed  push rdi
000077a0e99d90ee  push rsi
000077a0e99d90ef  push r8
000077a0e99d90f1  push r9
000077a0e99d90f3  push r10
000077a0e99d90f5  push r11
000077a0e99d90f7  sub rsp, 0xF0
000077a0e99d90fe  vmovaps [rsp], xmm0
000077a0e99d9103  vmovaps [rsp+0x10], xmm1
000077a0e99d9109  vmovaps [rsp+0x20], xmm2
000077a0e99d910f  vmovaps [rsp+0x30], xmm3
000077a0e99d9115  vmovaps [rsp+0x40], xmm4
000077a0e99d911b  vmovaps [rsp+0x50], xmm5
000077a0e99d9121  vmovaps [rsp+0x60], xmm6
000077a0e99d9127  vmovaps [rsp+0x70], xmm7
000077a0e99d912d  vmovaps [rsp+0x80], xmm8
000077a0e99d9136  vmovaps [rsp+0x90], xmm9
000077a0e99d913f  vmovaps [rsp+0xA0], xmm10
000077a0e99d9148  vmovaps [rsp+0xB0], xmm11
000077a0e99d9151  vmovaps [rsp+0xC0], xmm13
000077a0e99d915a  vmovaps [rsp+0xD0], xmm14
000077a0e99d9163  vmovaps [rsp+0xE0], xmm15
000077a0e99d916c  sub rsp, 0x40
000077a0e99d9170  lea rdi, [rsp]
000077a0e99d9174  lea rsi, [rsp+0x10]
000077a0e99d9179  lea rdx, [rsp+0x20]
000077a0e99d917e  lea rcx, [rsp+0x30]
000077a0e99d9183  mov r8d, 0x00
000077a0e99d9189  lea r9, [r15+0x3A8]
000077a0e99d9190  movaps [rdi], xmm12
000077a0e99d9194  movaps [rsi], xmm11
000077a0e99d9198  movaps [rdx], xmm15
000077a0e99d919c  movaps [rcx], xmm14
000077a0e99d91a0  mov rax, 0x60CAA235BA50
000077a0e99d91aa  call rax
000077a0e99d91ac  movaps xmm12, [rsp]
000077a0e99d91b1  add rsp, 0x40
000077a0e99d91b5  vmovaps xmm0, [rsp]
000077a0e99d91ba  vmovaps xmm1, [rsp+0x10]
000077a0e99d91c0  vmovaps xmm2, [rsp+0x20]
000077a0e99d91c6  vmovaps xmm3, [rsp+0x30]
000077a0e99d91cc  vmovaps xmm4, [rsp+0x40]
000077a0e99d91d2  vmovaps xmm5, [rsp+0x50]
000077a0e99d91d8  vmovaps xmm6, [rsp+0x60]
000077a0e99d91de  vmovaps xmm7, [rsp+0x70]
000077a0e99d91e4  vmovaps xmm8, [rsp+0x80]
000077a0e99d91ed  vmovaps xmm9, [rsp+0x90]
000077a0e99d91f6  vmovaps xmm10, [rsp+0xA0]
000077a0e99d91ff  vmovaps xmm11, [rsp+0xB0]
000077a0e99d9208  vmovaps xmm13, [rsp+0xC0]
000077a0e99d9211  vmovaps xmm14, [rsp+0xD0]
000077a0e99d921a  vmovaps xmm15, [rsp+0xE0]
000077a0e99d9223  add rsp, 0xF0
000077a0e99d922a  pop r11
000077a0e99d922c  pop r10
000077a0e99d922e  pop r9
000077a0e99d9230  pop r8
000077a0e99d9232  pop rsi
000077a0e99d9233  pop rdi
000077a0e99d9234  pop rdx
000077a0e99d9235  pop rcx
000077a0e99d9236  pop rax
000077a0e99d9237  add rsp, 0x08
000077a0e99d923b  jmp 0x000077A0E99D6B96
000077a0e99d9240  sub rsp, 0x08
000077a0e99d9244  push rax
000077a0e99d9245  push rcx
000077a0e99d9246  push rdx
000077a0e99d9247  push rdi
000077a0e99d9248  push rsi
000077a0e99d9249  push r8
000077a0e99d924b  push r9
000077a0e99d924d  push r10
000077a0e99d924f  push r11
000077a0e99d9251  sub rsp, 0xF0
000077a0e99d9258  vmovaps [rsp], xmm0
000077a0e99d925d  vmovaps [rsp+0x10], xmm1
000077a0e99d9263  vmovaps [rsp+0x20], xmm2
000077a0e99d9269  vmovaps [rsp+0x30], xmm3
000077a0e99d926f  vmovaps [rsp+0x40], xmm4
000077a0e99d9275  vmovaps [rsp+0x50], xmm5
000077a0e99d927b  vmovaps [rsp+0x60], xmm6
000077a0e99d9281  vmovaps [rsp+0x70], xmm7
000077a0e99d9287  vmovaps [rsp+0x80], xmm8
000077a0e99d9290  vmovaps [rsp+0x90], xmm9
000077a0e99d9299  vmovaps [rsp+0xA0], xmm10
000077a0e99d92a2  vmovaps [rsp+0xB0], xmm12
000077a0e99d92ab  vmovaps [rsp+0xC0], xmm13
000077a0e99d92b4  vmovaps [rsp+0xD0], xmm14
000077a0e99d92bd  vmovaps [rsp+0xE0], xmm15
000077a0e99d92c6  sub rsp, 0x40
000077a0e99d92ca  lea rdi, [rsp]
000077a0e99d92ce  lea rsi, [rsp+0x10]
000077a0e99d92d3  lea rdx, [rsp+0x20]
000077a0e99d92d8  lea rcx, [rsp+0x30]
000077a0e99d92dd  mov r8d, 0x00
000077a0e99d92e3  lea r9, [r15+0x3A8]
000077a0e99d92ea  movaps [rdi], xmm11
000077a0e99d92ee  movaps [rsi], xmm10
000077a0e99d92f2  movaps [rdx], xmm13
000077a0e99d92f6  movaps [rcx], xmm15
000077a0e99d92fa  mov rax, 0x60CAA235BA50
000077a0e99d9304  call rax
000077a0e99d9306  movaps xmm11, [rsp]
000077a0e99d930b  add rsp, 0x40
000077a0e99d930f  vmovaps xmm0, [rsp]
000077a0e99d9314  vmovaps xmm1, [rsp+0x10]
000077a0e99d931a  vmovaps xmm2, [rsp+0x20]
000077a0e99d9320  vmovaps xmm3, [rsp+0x30]
000077a0e99d9326  vmovaps xmm4, [rsp+0x40]
000077a0e99d932c  vmovaps xmm5, [rsp+0x50]
000077a0e99d9332  vmovaps xmm6, [rsp+0x60]
000077a0e99d9338  vmovaps xmm7, [rsp+0x70]
000077a0e99d933e  vmovaps xmm8, [rsp+0x80]
000077a0e99d9347  vmovaps xmm9, [rsp+0x90]
000077a0e99d9350  vmovaps xmm10, [rsp+0xA0]
000077a0e99d9359  vmovaps xmm12, [rsp+0xB0]
000077a0e99d9362  vmovaps xmm13, [rsp+0xC0]
000077a0e99d936b  vmovaps xmm14, [rsp+0xD0]
000077a0e99d9374  vmovaps xmm15, [rsp+0xE0]
000077a0e99d937d  add rsp, 0xF0
000077a0e99d9384  pop r11
000077a0e99d9386  pop r10
000077a0e99d9388  pop r9
000077a0e99d938a  pop r8
000077a0e99d938c  pop rsi
000077a0e99d938d  pop rdi
000077a0e99d938e  pop rdx
000077a0e99d938f  pop rcx
000077a0e99d9390  pop rax
000077a0e99d9391  add rsp, 0x08
000077a0e99d9395  jmp 0x000077A0E99D6BBF
000077a0e99d939a  call 0x000077A0E98E5820
000077a0e99d939f  jmp 0x000077A0E99D6BCC
000077a0e99d93a4  call 0x000077A0E98E45A0
000077a0e99d93a9  jmp 0x000077A0E99D6BD9
000077a0e99d93ae  sub rsp, 0x08
000077a0e99d93b2  push rax
000077a0e99d93b3  push rcx
000077a0e99d93b4  push rdx
000077a0e99d93b5  push rdi
000077a0e99d93b6  push rsi
000077a0e99d93b7  push r8
000077a0e99d93b9  push r9
000077a0e99d93bb  push r10
000077a0e99d93bd  push r11
000077a0e99d93bf  sub rsp, 0xF0
000077a0e99d93c6  vmovaps [rsp], xmm0
000077a0e99d93cb  vmovaps [rsp+0x10], xmm1
000077a0e99d93d1  vmovaps [rsp+0x20], xmm2
000077a0e99d93d7  vmovaps [rsp+0x30], xmm3
000077a0e99d93dd  vmovaps [rsp+0x40], xmm4
000077a0e99d93e3  vmovaps [rsp+0x50], xmm5
000077a0e99d93e9  vmovaps [rsp+0x60], xmm6
000077a0e99d93ef  vmovaps [rsp+0x70], xmm7
000077a0e99d93f5  vmovaps [rsp+0x80], xmm8
000077a0e99d93fe  vmovaps [rsp+0x90], xmm9
000077a0e99d9407  vmovaps [rsp+0xA0], xmm11
000077a0e99d9410  vmovaps [rsp+0xB0], xmm12
000077a0e99d9419  vmovaps [rsp+0xC0], xmm13
000077a0e99d9422  vmovaps [rsp+0xD0], xmm14
000077a0e99d942b  vmovaps [rsp+0xE0], xmm15
000077a0e99d9434  sub rsp, 0x40
000077a0e99d9438  lea rdi, [rsp]
000077a0e99d943c  lea rsi, [rsp+0x10]
000077a0e99d9441  lea rdx, [rsp+0x20]
000077a0e99d9446  lea rcx, [rsp+0x30]
000077a0e99d944b  mov r8d, 0x00
000077a0e99d9451  lea r9, [r15+0x3A8]
000077a0e99d9458  movaps [rdi], xmm10
000077a0e99d945c  movaps [rsi], xmm8
000077a0e99d9460  movaps [rdx], xmm1
000077a0e99d9463  movaps [rcx], xmm13
000077a0e99d9467  mov rax, 0x60CAA235BA50
000077a0e99d9471  call rax
000077a0e99d9473  movaps xmm10, [rsp]
000077a0e99d9478  add rsp, 0x40
000077a0e99d947c  vmovaps xmm0, [rsp]
000077a0e99d9481  vmovaps xmm1, [rsp+0x10]
000077a0e99d9487  vmovaps xmm2, [rsp+0x20]
000077a0e99d948d  vmovaps xmm3, [rsp+0x30]
000077a0e99d9493  vmovaps xmm4, [rsp+0x40]
000077a0e99d9499  vmovaps xmm5, [rsp+0x50]
000077a0e99d949f  vmovaps xmm6, [rsp+0x60]
000077a0e99d94a5  vmovaps xmm7, [rsp+0x70]
000077a0e99d94ab  vmovaps xmm8, [rsp+0x80]
000077a0e99d94b4  vmovaps xmm9, [rsp+0x90]
000077a0e99d94bd  vmovaps xmm11, [rsp+0xA0]
000077a0e99d94c6  vmovaps xmm12, [rsp+0xB0]
000077a0e99d94cf  vmovaps xmm13, [rsp+0xC0]
000077a0e99d94d8  vmovaps xmm14, [rsp+0xD0]
000077a0e99d94e1  vmovaps xmm15, [rsp+0xE0]
000077a0e99d94ea  add rsp, 0xF0
000077a0e99d94f1  pop r11
000077a0e99d94f3  pop r10
000077a0e99d94f5  pop r9
000077a0e99d94f7  pop r8
000077a0e99d94f9  pop rsi
000077a0e99d94fa  pop rdi
000077a0e99d94fb  pop rdx
000077a0e99d94fc  pop rcx
000077a0e99d94fd  pop rax
000077a0e99d94fe  add rsp, 0x08
000077a0e99d9502  jmp 0x000077A0E99D6C0F
000077a0e99d9507  call 0x000077A0E98D64F0
000077a0e99d950c  jmp 0x000077A0E99D6C21
000077a0e99d9511  sub rsp, 0x08
000077a0e99d9515  push rax
000077a0e99d9516  push rcx
000077a0e99d9517  push rdx
000077a0e99d9518  push rdi
000077a0e99d9519  push rsi
000077a0e99d951a  push r8
000077a0e99d951c  push r9
000077a0e99d951e  push r10
000077a0e99d9520  push r11
000077a0e99d9522  sub rsp, 0xF0
000077a0e99d9529  vmovaps [rsp], xmm0
000077a0e99d952e  vmovaps [rsp+0x10], xmm1
000077a0e99d9534  vmovaps [rsp+0x20], xmm2
000077a0e99d953a  vmovaps [rsp+0x30], xmm3
000077a0e99d9540  vmovaps [rsp+0x40], xmm4
000077a0e99d9546  vmovaps [rsp+0x50], xmm5
000077a0e99d954c  vmovaps [rsp+0x60], xmm6
000077a0e99d9552  vmovaps [rsp+0x70], xmm7
000077a0e99d9558  vmovaps [rsp+0x80], xmm8
000077a0e99d9561  vmovaps [rsp+0x90], xmm10
000077a0e99d956a  vmovaps [rsp+0xA0], xmm11
000077a0e99d9573  vmovaps [rsp+0xB0], xmm12
000077a0e99d957c  vmovaps [rsp+0xC0], xmm13
000077a0e99d9585  vmovaps [rsp+0xD0], xmm14
000077a0e99d958e  vmovaps [rsp+0xE0], xmm15
000077a0e99d9597  sub rsp, 0x40
000077a0e99d959b  lea rdi, [rsp]
000077a0e99d959f  lea rsi, [rsp+0x10]
000077a0e99d95a4  lea rdx, [rsp+0x20]
000077a0e99d95a9  lea rcx, [rsp+0x30]
000077a0e99d95ae  mov r8d, 0x00
000077a0e99d95b4  lea r9, [r15+0x3A8]
000077a0e99d95bb  movaps [rdi], xmm9
000077a0e99d95bf  movaps [rsi], xmm7
000077a0e99d95c2  movaps [rdx], xmm14
000077a0e99d95c6  movaps [rcx], xmm13
000077a0e99d95ca  mov rax, 0x60CAA235BA50
000077a0e99d95d4  call rax
000077a0e99d95d6  movaps xmm9, [rsp]
000077a0e99d95db  add rsp, 0x40
000077a0e99d95df  vmovaps xmm0, [rsp]
000077a0e99d95e4  vmovaps xmm1, [rsp+0x10]
000077a0e99d95ea  vmovaps xmm2, [rsp+0x20]
000077a0e99d95f0  vmovaps xmm3, [rsp+0x30]
000077a0e99d95f6  vmovaps xmm4, [rsp+0x40]
000077a0e99d95fc  vmovaps xmm5, [rsp+0x50]
000077a0e99d9602  vmovaps xmm6, [rsp+0x60]
000077a0e99d9608  vmovaps xmm7, [rsp+0x70]
000077a0e99d960e  vmovaps xmm8, [rsp+0x80]
000077a0e99d9617  vmovaps xmm10, [rsp+0x90]
000077a0e99d9620  vmovaps xmm11, [rsp+0xA0]
000077a0e99d9629  vmovaps xmm12, [rsp+0xB0]
000077a0e99d9632  vmovaps xmm13, [rsp+0xC0]
000077a0e99d963b  vmovaps xmm14, [rsp+0xD0]
000077a0e99d9644  vmovaps xmm15, [rsp+0xE0]
000077a0e99d964d  add rsp, 0xF0
000077a0e99d9654  pop r11
000077a0e99d9656  pop r10
000077a0e99d9658  pop r9
000077a0e99d965a  pop r8
000077a0e99d965c  pop rsi
000077a0e99d965d  pop rdi
000077a0e99d965e  pop rdx
000077a0e99d965f  pop rcx
000077a0e99d9660  pop rax
000077a0e99d9661  add rsp, 0x08
000077a0e99d9665  jmp 0x000077A0E99D6C4F
000077a0e99d966a  sub rsp, 0x08
000077a0e99d966e  push rax
000077a0e99d966f  push rcx
000077a0e99d9670  push rdx
000077a0e99d9671  push rdi
000077a0e99d9672  push rsi
000077a0e99d9673  push r8
000077a0e99d9675  push r9
000077a0e99d9677  push r10
000077a0e99d9679  push r11
000077a0e99d967b  sub rsp, 0xF0
000077a0e99d9682  vmovaps [rsp], xmm0
000077a0e99d9687  vmovaps [rsp+0x10], xmm1
000077a0e99d968d  vmovaps [rsp+0x20], xmm2
000077a0e99d9693  vmovaps [rsp+0x30], xmm3
000077a0e99d9699  vmovaps [rsp+0x40], xmm4
000077a0e99d969f  vmovaps [rsp+0x50], xmm5
000077a0e99d96a5  vmovaps [rsp+0x60], xmm6
000077a0e99d96ab  vmovaps [rsp+0x70], xmm7
000077a0e99d96b1  vmovaps [rsp+0x80], xmm8
000077a0e99d96ba  vmovaps [rsp+0x90], xmm9
000077a0e99d96c3  vmovaps [rsp+0xA0], xmm10
000077a0e99d96cc  vmovaps [rsp+0xB0], xmm11
000077a0e99d96d5  vmovaps [rsp+0xC0], xmm12
000077a0e99d96de  vmovaps [rsp+0xD0], xmm14
000077a0e99d96e7  vmovaps [rsp+0xE0], xmm15
000077a0e99d96f0  sub rsp, 0x40
000077a0e99d96f4  lea rdi, [rsp]
000077a0e99d96f8  lea rsi, [rsp+0x10]
000077a0e99d96fd  lea rdx, [rsp+0x20]
000077a0e99d9702  lea rcx, [rsp+0x30]
000077a0e99d9707  mov r8d, 0x00
000077a0e99d970d  lea r9, [r15+0x3A8]
000077a0e99d9714  movaps [rdi], xmm13
000077a0e99d9718  movaps [rsi], xmm12
000077a0e99d971c  movaps [rdx], xmm15
000077a0e99d9720  movaps [rcx], xmm14
000077a0e99d9724  mov rax, 0x60CAA235BA50
000077a0e99d972e  call rax
000077a0e99d9730  movaps xmm13, [rsp]
000077a0e99d9735  add rsp, 0x40
000077a0e99d9739  vmovaps xmm0, [rsp]
000077a0e99d973e  vmovaps xmm1, [rsp+0x10]
000077a0e99d9744  vmovaps xmm2, [rsp+0x20]
000077a0e99d974a  vmovaps xmm3, [rsp+0x30]
000077a0e99d9750  vmovaps xmm4, [rsp+0x40]
000077a0e99d9756  vmovaps xmm5, [rsp+0x50]
000077a0e99d975c  vmovaps xmm6, [rsp+0x60]
000077a0e99d9762  vmovaps xmm7, [rsp+0x70]
000077a0e99d9768  vmovaps xmm8, [rsp+0x80]
000077a0e99d9771  vmovaps xmm9, [rsp+0x90]
000077a0e99d977a  vmovaps xmm10, [rsp+0xA0]
000077a0e99d9783  vmovaps xmm11, [rsp+0xB0]
000077a0e99d978c  vmovaps xmm12, [rsp+0xC0]
000077a0e99d9795  vmovaps xmm14, [rsp+0xD0]
000077a0e99d979e  vmovaps xmm15, [rsp+0xE0]
000077a0e99d97a7  add rsp, 0xF0
000077a0e99d97ae  pop r11
000077a0e99d97b0  pop r10
000077a0e99d97b2  pop r9
000077a0e99d97b4  pop r8
000077a0e99d97b6  pop rsi
000077a0e99d97b7  pop rdi
000077a0e99d97b8  pop rdx
000077a0e99d97b9  pop rcx
000077a0e99d97ba  pop rax
000077a0e99d97bb  add rsp, 0x08
000077a0e99d97bf  jmp 0x000077A0E99D6C7D
000077a0e99d97c4  sub rsp, 0x08
000077a0e99d97c8  push rax
000077a0e99d97c9  push rcx
000077a0e99d97ca  push rdx
000077a0e99d97cb  push rdi
000077a0e99d97cc  push rsi
000077a0e99d97cd  push r8
000077a0e99d97cf  push r9
000077a0e99d97d1  push r10
000077a0e99d97d3  push r11
000077a0e99d97d5  sub rsp, 0xF0
000077a0e99d97dc  vmovaps [rsp], xmm0
000077a0e99d97e1  vmovaps [rsp+0x10], xmm1
000077a0e99d97e7  vmovaps [rsp+0x20], xmm2
000077a0e99d97ed  vmovaps [rsp+0x30], xmm3
000077a0e99d97f3  vmovaps [rsp+0x40], xmm4
000077a0e99d97f9  vmovaps [rsp+0x50], xmm5
000077a0e99d97ff  vmovaps [rsp+0x60], xmm6
000077a0e99d9805  vmovaps [rsp+0x70], xmm7
000077a0e99d980b  vmovaps [rsp+0x80], xmm8
000077a0e99d9814  vmovaps [rsp+0x90], xmm9
000077a0e99d981d  vmovaps [rsp+0xA0], xmm10
000077a0e99d9826  vmovaps [rsp+0xB0], xmm11
000077a0e99d982f  vmovaps [rsp+0xC0], xmm12
000077a0e99d9838  vmovaps [rsp+0xD0], xmm13
000077a0e99d9841  vmovaps [rsp+0xE0], xmm15
000077a0e99d984a  sub rsp, 0x40
000077a0e99d984e  lea rdi, [rsp]
000077a0e99d9852  lea rsi, [rsp+0x10]
000077a0e99d9857  lea rdx, [rsp+0x20]
000077a0e99d985c  lea rcx, [rsp+0x30]
000077a0e99d9861  mov r8d, 0x00
000077a0e99d9867  lea r9, [r15+0x3A8]
000077a0e99d986e  movaps [rdi], xmm14
000077a0e99d9872  movaps [rsi], xmm11
000077a0e99d9876  movaps [rdx], xmm1
000077a0e99d9879  movaps [rcx], xmm15
000077a0e99d987d  mov rax, 0x60CAA235BA50
000077a0e99d9887  call rax
000077a0e99d9889  movaps xmm14, [rsp]
000077a0e99d988e  add rsp, 0x40
000077a0e99d9892  vmovaps xmm0, [rsp]
000077a0e99d9897  vmovaps xmm1, [rsp+0x10]
000077a0e99d989d  vmovaps xmm2, [rsp+0x20]
000077a0e99d98a3  vmovaps xmm3, [rsp+0x30]
000077a0e99d98a9  vmovaps xmm4, [rsp+0x40]
000077a0e99d98af  vmovaps xmm5, [rsp+0x50]
000077a0e99d98b5  vmovaps xmm6, [rsp+0x60]
000077a0e99d98bb  vmovaps xmm7, [rsp+0x70]
000077a0e99d98c1  vmovaps xmm8, [rsp+0x80]
000077a0e99d98ca  vmovaps xmm9, [rsp+0x90]
000077a0e99d98d3  vmovaps xmm10, [rsp+0xA0]
000077a0e99d98dc  vmovaps xmm11, [rsp+0xB0]
000077a0e99d98e5  vmovaps xmm12, [rsp+0xC0]
000077a0e99d98ee  vmovaps xmm13, [rsp+0xD0]
000077a0e99d98f7  vmovaps xmm15, [rsp+0xE0]
000077a0e99d9900  add rsp, 0xF0
000077a0e99d9907  pop r11
000077a0e99d9909  pop r10
000077a0e99d990b  pop r9
000077a0e99d990d  pop r8
000077a0e99d990f  pop rsi
000077a0e99d9910  pop rdi
000077a0e99d9911  pop rdx
000077a0e99d9912  pop rcx
000077a0e99d9913  pop rax
000077a0e99d9914  add rsp, 0x08
000077a0e99d9918  jmp 0x000077A0E99D6CAB
000077a0e99d991d  call 0x000077A0E98ACF70
000077a0e99d9922  jmp 0x000077A0E99D6CB9
000077a0e99d9927  call 0x000077A0E980C380
000077a0e99d992c  jmp 0x000077A0E99D6CC3
000077a0e99d9931  call 0x000077A0E9808C20
000077a0e99d9936  jmp 0x000077A0E99D6CCD
000077a0e99d993b  call 0x000077A0E980D600
000077a0e99d9940  jmp 0x000077A0E99D6CD7
000077a0e99d9945  int3
000077a0e99d9946  nop [rax+rax*1], ax
000077a0e99d994f  nop
000077a0e99d9950  mov eax, [r15+0x48]
000077a0e99d9954  lea r14d, [eax+0x01]
000077a0e99d9959  mov [rsp+0x10], r14d
000077a0e99d995e  mov r14d, r14d
000077a0e99d9961  mov [r15+0x48], r14
000077a0e99d9965  xor eax, eax
000077a0e99d9967  mov r14d, [rsp+0x10]
000077a0e99d996c  cmp r14d, 0x1F4
000077a0e99d9973  cmc
000077a0e99d9974  lahf
000077a0e99d9975  seto al
000077a0e99d9978  mov [r15+0x108], eax
000077a0e99d997f  mov eax, [r15+0x108]
000077a0e99d9986  sahf
000077a0e99d9987  jnz 0x000077A0E99D99B9
000077a0e99d9989  cmp dword ptr [r15+0x318], 0x00
000077a0e99d9991  jz 0x000077A0E99DD2E0
000077a0e99d9997  nop [rax+rax*1], ax
000077a0e99d99a0  nop [rax+rax*1], eax
000077a0e99d99a8  mov eax, 0x410670
000077a0e99d99ad  mov [r15+0x100], rax
000077a0e99d99b4  jmp 0x000077A0E97FE110
000077a0e99d99b9  cmp dword ptr [r15+0x318], 0x00
000077a0e99d99c1  jz 0x000077A0E99D99F0
000077a0e99d99c7  nop [rax+rax*1], ax
000077a0e99d99d0  nop [rax+rax*1], eax
000077a0e99d99d8  mov eax, 0x4104EC
000077a0e99d99dd  mov [r15+0x100], rax
000077a0e99d99e4  jmp 0x000077A0E97FE110
000077a0e99d99e9  int3
000077a0e99d99ea  int3
000077a0e99d99eb  nop [rax+rax*1], eax
000077a0e99d99f0  mov rax, [r15+0x40]
000077a0e99d99f4  vxorps xmm1, xmm1, xmm1
000077a0e99d99f8  vpbroadcastq xmm1, xmm1
000077a0e99d99fd  vxorps xmm15, xmm15, xmm15
000077a0e99d9a02  vpbroadcastq xmm15, xmm15
000077a0e99d9a07  lea r14, [rax+0x30]
000077a0e99d9a0b  mov r12, [r13+r14*1]
000077a0e99d9a10  lea r14, [rax+0x38]
000077a0e99d9a14  mov r11, [r13+r14*1]
000077a0e99d9a19  movq xmm14, r12
000077a0e99d9a1e  movq xmm13, r11
000077a0e99d9a23  movq xmm14, xmm14
000077a0e99d9a28  movq xmm13, xmm13
000077a0e99d9a2d  vmovaps [rsp+0x10], xmm13
000077a0e99d9a33  movq xmm13, xmm13
000077a0e99d9a38  movaps [r15+0x270], xmm13
000077a0e99d9a40  movaps xmm13, [r15+0x160]
000077a0e99d9a48  vmovaps [rsp+0x20], xmm13
000077a0e99d9a4e  vmovaps xmm12, [rsp+0x20]
000077a0e99d9a54  por xmm13, xmm12
000077a0e99d9a59  lea r14, [rax+0x20]
000077a0e99d9a5d  mov r12, [r13+r14*1]
000077a0e99d9a62  lea r14, [rax+0x28]
000077a0e99d9a66  mov r11, [r13+r14*1]
000077a0e99d9a6b  movq xmm12, r12
000077a0e99d9a70  movq xmm11, r11
000077a0e99d9a75  movq xmm12, xmm12
000077a0e99d9a7a  movq xmm11, xmm11
000077a0e99d9a7f  movaps xmm10, [r15+0x2D0]
000077a0e99d9a87  vmovaps [rsp+0x20], xmm10
000077a0e99d9a8d  vmovaps xmm9, [rsp+0x20]
000077a0e99d9a93  por xmm10, xmm9
000077a0e99d9a98  movaps xmm9, [r15+0x300]
000077a0e99d9aa0  vmovaps [rsp+0x20], xmm9
000077a0e99d9aa6  vmovaps xmm8, [rsp+0x20]
000077a0e99d9aac  por xmm9, xmm8
000077a0e99d9ab1  movaps xmm8, [r15+0x2B0]
000077a0e99d9ab9  vmovaps [rsp+0x20], xmm8
000077a0e99d9abf  vmovaps xmm7, [rsp+0x20]
000077a0e99d9ac5  por xmm8, xmm7
000077a0e99d9aca  movaps xmm7, [r15+0x180]
000077a0e99d9ad2  vmovaps [rsp+0x20], xmm7
000077a0e99d9ad8  vmovaps xmm6, [rsp+0x20]
000077a0e99d9ade  por xmm7, xmm6
000077a0e99d9ae2  lea r14, [rax+0x10]
000077a0e99d9ae6  mov r12, [r13+r14*1]
000077a0e99d9aeb  lea r14, [rax+0x18]
000077a0e99d9aef  mov r11, [r13+r14*1]
000077a0e99d9af4  movq xmm6, r12
000077a0e99d9af9  movq xmm5, r11
000077a0e99d9afe  movq xmm6, xmm6
000077a0e99d9b02  movq xmm5, xmm5
000077a0e99d9b06  movaps xmm4, [r15+0x200]
000077a0e99d9b0e  vmovaps [rsp+0x20], xmm4
000077a0e99d9b14  vmovaps xmm3, [rsp+0x20]
000077a0e99d9b1a  por xmm4, xmm3
000077a0e99d9b1e  movaps xmm3, [r15+0x1F0]
000077a0e99d9b26  vmovaps [rsp+0x20], xmm3
000077a0e99d9b2c  vmovaps xmm2, [rsp+0x20]
000077a0e99d9b32  por xmm3, xmm2
000077a0e99d9b36  movaps xmm2, [r15+0x2E0]
000077a0e99d9b3e  vmovaps [rsp+0x20], xmm2
000077a0e99d9b44  vmovaps [rsp+0x30], xmm1
000077a0e99d9b4a  vmovaps xmm1, [rsp+0x20]
000077a0e99d9b50  por xmm2, xmm1
000077a0e99d9b54  movaps xmm1, [r15+0x2A0]
000077a0e99d9b5c  vmovaps [rsp+0x20], xmm1
000077a0e99d9b62  vmovaps [rsp+0x40], xmm15
000077a0e99d9b68  vmovaps xmm15, [rsp+0x20]
000077a0e99d9b6e  por xmm1, xmm15
000077a0e99d9b73  movaps xmm15, [r15+0x280]
000077a0e99d9b7b  vmovaps [rsp+0x20], xmm15
000077a0e99d9b81  vmovaps [rsp+0x50], xmm1
000077a0e99d9b87  vmovaps xmm1, [rsp+0x20]
000077a0e99d9b8d  por xmm15, xmm1
000077a0e99d9b92  movaps xmm1, [r15+0x1C0]
000077a0e99d9b9a  vmovaps [rsp+0x20], xmm1
000077a0e99d9ba0  vmovaps [rsp+0x60], xmm15
000077a0e99d9ba6  vmovaps xmm15, [rsp+0x20]
000077a0e99d9bac  por xmm1, xmm15
000077a0e99d9bb1  movaps xmm15, [r15+0x210]
000077a0e99d9bb9  vmovaps [rsp+0x20], xmm15
000077a0e99d9bbf  vmovaps [rsp+0x70], xmm1
000077a0e99d9bc5  vmovaps xmm1, [rsp+0x20]
000077a0e99d9bcb  por xmm15, xmm1
000077a0e99d9bd0  mov r14, [r13+rax*1]
000077a0e99d9bd5  vmovq xmm1, r14
000077a0e99d9bda  vpbroadcastq xmm1, xmm1
000077a0e99d9bdf  vmovaps [rsp+0x20], xmm1
000077a0e99d9be5  vxorps xmm1, xmm1, xmm1
000077a0e99d9be9  vpbroadcastq xmm1, xmm1
000077a0e99d9bee  mov r14, [r15+0xF8]
000077a0e99d9bf5  vmovaps [rsp+0x80], xmm1
000077a0e99d9bfe  movups xmm1, [r13+r14*1]
000077a0e99d9c04  vmovaps [rsp+0x90], xmm1
000077a0e99d9c0d  vxorps xmm1, xmm1, xmm1
000077a0e99d9c11  vpbroadcastq xmm1, xmm1
000077a0e99d9c16  lea r12, [rax+0x08]
000077a0e99d9c1a  mov rax, [r13+r12*1]
000077a0e99d9c1f  vmovaps [rsp+0xA0], xmm1
000077a0e99d9c28  movq xmm1, rax
000077a0e99d9c2d  movaps [r15+0x240], xmm1
000077a0e99d9c35  mov rax, [r15+0x50]
000077a0e99d9c39  mov [r15+0x60], rax
000077a0e99d9c3d  mov qword ptr [r15+0x58], 0x40
000077a0e99d9c45  vmovaps xmm1, [rsp+0x30]
000077a0e99d9c4b  vmovaps [rsp+0x30], xmm15
000077a0e99d9c51  vmovaps xmm15, [rsp+0x90]
000077a0e99d9c5a  vmovaps [rsp+0x90], xmm14
000077a0e99d9c63  vmovaps xmm14, [rsp+0x20]
000077a0e99d9c69  vmovaps [rsp+0x20], xmm13
000077a0e99d9c6f  vmovaps [rsp+0xB0], xmm12
000077a0e99d9c78  movaps xmm13, xmm1
000077a0e99d9c7c  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d9c87  vptest xmm12, xmm12
000077a0e99d9c8c  jnz 0x000077A0E99DA72F
000077a0e99d9c92  movaps xmm1, [r15+0x250]
000077a0e99d9c9a  vmovaps xmm15, [rsp+0x40]
000077a0e99d9ca0  vmovaps [rsp+0x40], xmm13
000077a0e99d9ca6  movaps xmm12, xmm15
000077a0e99d9caa  vfmadd231pd xmm12, xmm1, xmm14
000077a0e99d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
000077a0e99d9cb5  vptest xmm13, xmm13
000077a0e99d9cba  jnz 0x000077A0E99DA888
000077a0e99d9cc0  movaps xmm15, [r15+0x1E0]
000077a0e99d9cc8  vmovaps [rsp+0xC0], xmm15
000077a0e99d9cd1  vmovaps xmm13, [rsp+0xC0]
000077a0e99d9cda  por xmm15, xmm13
000077a0e99d9cdf  movaps xmm13, [r15+0x1D0]
000077a0e99d9ce7  vmovaps [rsp+0xC0], xmm13
000077a0e99d9cf0  vmovaps [rsp+0xD0], xmm1
000077a0e99d9cf9  vmovaps xmm1, [rsp+0xC0]
000077a0e99d9d02  por xmm13, xmm1
000077a0e99d9d07  movaps xmm1, [r15+0x2C0]
000077a0e99d9d0f  vmovaps [rsp+0xC0], xmm1
000077a0e99d9d18  vmovaps [rsp+0xE0], xmm15
000077a0e99d9d21  vmovaps xmm15, [rsp+0xC0]
000077a0e99d9d2a  por xmm1, xmm15
000077a0e99d9d2f  movaps xmm15, [r15+0x290]
000077a0e99d9d37  vmovaps [rsp+0xC0], xmm15
000077a0e99d9d40  vmovaps [rsp+0xF0], xmm1
000077a0e99d9d49  vmovaps xmm1, [rsp+0xC0]
000077a0e99d9d52  por xmm15, xmm1
000077a0e99d9d57  movaps xmm1, [r15+0x260]
000077a0e99d9d5f  vmovaps [rsp+0xC0], xmm1
000077a0e99d9d68  vmovaps [rsp+0x100], xmm15
000077a0e99d9d71  vmovaps xmm15, [rsp+0xC0]
000077a0e99d9d7a  por xmm1, xmm15
000077a0e99d9d7f  vmovaps xmm15, [rsp+0xD0]
000077a0e99d9d88  vmovaps [rsp+0xC0], xmm1
000077a0e99d9d91  vmovaps xmm1, [rsp+0xD0]
000077a0e99d9d9a  por xmm15, xmm1
000077a0e99d9d9f  lea r12, [r14+0xC0]
000077a0e99d9da6  movups xmm1, [r13+r12*1]
000077a0e99d9dac  mov [rsp+0xD0], rax
000077a0e99d9db4  xor eax, eax
000077a0e99d9db6  mov r12d, 0x40
000077a0e99d9dbc  mov r11d, 0x200
000077a0e99d9dc2  cmp r12, r11
000077a0e99d9dc5  cmc
000077a0e99d9dc6  lahf
000077a0e99d9dc7  seto al
000077a0e99d9dca  mov [r15+0x108], eax
000077a0e99d9dd1  vmovaps [rsp+0x110], xmm1
000077a0e99d9dda  vmovaps xmm1, [rsp+0x80]
000077a0e99d9de3  vmovaps [rsp+0x80], xmm15
000077a0e99d9dec  vmovaps xmm15, [rsp+0x110]
000077a0e99d9df5  vmovaps [rsp+0x110], xmm13
000077a0e99d9dfe  vmovaps [rsp+0x120], xmm12
000077a0e99d9e07  movaps xmm13, xmm1
000077a0e99d9e0b  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d9e16  vptest xmm12, xmm12
000077a0e99d9e1b  jnz 0x000077A0E99DA9EB
000077a0e99d9e21  lea rax, [r14+0xB0]
000077a0e99d9e28  movups xmm1, [r13+rax*1]
000077a0e99d9e2e  vmovaps xmm15, [rsp+0xA0]
000077a0e99d9e37  vmovaps [rsp+0xA0], xmm13
000077a0e99d9e40  movaps xmm12, xmm15
000077a0e99d9e44  vfmadd231pd xmm12, xmm1, xmm14
000077a0e99d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
000077a0e99d9e4f  vptest xmm13, xmm13
000077a0e99d9e54  jnz 0x000077A0E99DAB4E
000077a0e99d9e5a  vmovaps xmm1, [rsp+0x30]
000077a0e99d9e60  vmovaps xmm15, [rsp+0x30]
000077a0e99d9e66  por xmm1, xmm15
000077a0e99d9e6b  movaps [r15+0x210], xmm1
000077a0e99d9e73  vmovaps xmm15, [rsp+0x70]
000077a0e99d9e79  vmovaps xmm14, [rsp+0x70]
000077a0e99d9e7f  por xmm15, xmm14
000077a0e99d9e84  movaps [r15+0x1C0], xmm15
000077a0e99d9e8c  vmovaps xmm14, [rsp+0x60]
000077a0e99d9e92  vmovaps xmm13, [rsp+0x60]
000077a0e99d9e98  por xmm14, xmm13
000077a0e99d9e9d  movaps [r15+0x280], xmm14
000077a0e99d9ea5  vmovaps xmm13, [rsp+0x50]
000077a0e99d9eab  vmovaps [rsp+0x30], xmm1
000077a0e99d9eb1  vmovaps xmm1, [rsp+0x50]
000077a0e99d9eb7  por xmm13, xmm1
000077a0e99d9ebc  movaps [r15+0x2A0], xmm13
000077a0e99d9ec4  vmovaps [rsp+0x50], xmm2
000077a0e99d9eca  vmovaps xmm1, [rsp+0x50]
000077a0e99d9ed0  por xmm2, xmm1
000077a0e99d9ed4  movaps [r15+0x2E0], xmm2
000077a0e99d9edc  vmovaps [rsp+0x50], xmm3
000077a0e99d9ee2  vmovaps xmm1, [rsp+0x50]
000077a0e99d9ee8  por xmm3, xmm1
000077a0e99d9eec  movaps [r15+0x1F0], xmm3
000077a0e99d9ef4  vmovaps xmm1, [rsp+0x80]
000077a0e99d9efd  vmovaps [rsp+0x50], xmm15
000077a0e99d9f03  vmovaps xmm15, [rsp+0x80]
000077a0e99d9f0c  por xmm1, xmm15
000077a0e99d9f11  movaps [r15+0x250], xmm1
000077a0e99d9f19  vmovaps xmm1, [rsp+0xC0]
000077a0e99d9f22  vmovaps xmm15, [rsp+0xC0]
000077a0e99d9f2b  por xmm1, xmm15
000077a0e99d9f30  movaps [r15+0x260], xmm1
000077a0e99d9f38  vmovaps xmm15, [rsp+0x100]
000077a0e99d9f41  vmovaps [rsp+0x60], xmm1
000077a0e99d9f47  vmovaps xmm1, [rsp+0x100]
000077a0e99d9f50  por xmm15, xmm1
000077a0e99d9f55  movaps [r15+0x290], xmm15
000077a0e99d9f5d  vmovaps xmm1, [rsp+0xF0]
000077a0e99d9f66  vmovaps [rsp+0x70], xmm15
000077a0e99d9f6c  vmovaps xmm15, [rsp+0xF0]
000077a0e99d9f75  por xmm1, xmm15
000077a0e99d9f7a  movaps [r15+0x2C0], xmm1
000077a0e99d9f82  movq xmm15, qword ptr [r15+0x240]
000077a0e99d9f8b  vmovaps [rsp+0x80], xmm15
000077a0e99d9f94  vpermilpd xmm15, xmm15, 0x00
000077a0e99d9f9a  vmovaps [rsp+0xC0], xmm1
000077a0e99d9fa3  vmovaps xmm1, [rsp+0x40]
000077a0e99d9fa9  vmovaps [rsp+0x40], xmm15
000077a0e99d9faf  vmovaps xmm15, [rsp+0x30]
000077a0e99d9fb5  vmovaps [rsp+0x30], xmm14
000077a0e99d9fbb  vmovaps xmm14, [rsp+0x40]
000077a0e99d9fc1  vmovaps [rsp+0x40], xmm13
000077a0e99d9fc7  vmovaps [rsp+0xF0], xmm12
000077a0e99d9fd0  movaps xmm13, xmm1
000077a0e99d9fd4  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
000077a0e99d9fdf  vptest xmm12, xmm12
000077a0e99d9fe4  jnz 0x000077A0E99DACA7
000077a0e99d9fea  vmovaps xmm1, [rsp+0x80]
000077a0e99d9ff3  vpermilpd xmm1, xmm1, 0x00
000077a0e99d9ff9  vmovaps xmm15, [rsp+0xA0]
000077a0e99da002  movaps xmm14, xmm15
000077a0e99da006  vfmadd231pd xmm14, xmm2, xmm1
000077a0e99da00b  vcmppd xmm12, xmm14, xmm14, 0x03
000077a0e99da011  vptest xmm12, xmm12
000077a0e99da016  jnz 0x000077A0E99DAE00
000077a0e99da01c  vmovaps xmm1, [rsp+0x80]
000077a0e99da025  vpermilpd xmm1, xmm1, 0x00
000077a0e99da02b  vmovaps xmm15, [rsp+0x120]
000077a0e99da034  vmovaps xmm12, [rsp+0x50]
000077a0e99da03a  vmovaps [rsp+0x50], xmm14
000077a0e99da040  movaps xmm2, xmm15
000077a0e99da044  vfmadd231pd xmm2, xmm12, xmm1
000077a0e99da049  vcmppd xmm14, xmm2, xmm2, 0x03
000077a0e99da04e  vptest xmm14, xmm14
000077a0e99da053  jnz 0x000077A0E99DAF58
000077a0e99da059  vmovaps xmm1, [rsp+0x110]
000077a0e99da062  vmovaps xmm15, [rsp+0x110]
000077a0e99da06b  por xmm1, xmm15
000077a0e99da070  movaps [r15+0x1D0], xmm1
000077a0e99da078  vmovaps xmm15, [rsp+0x80]
000077a0e99da081  vpermilpd xmm15, xmm15, 0x00
000077a0e99da087  vmovaps xmm14, [rsp+0xF0]
000077a0e99da090  vmovaps [rsp+0x80], xmm1
000077a0e99da099  movaps xmm12, xmm14
000077a0e99da09d  vfmadd231pd xmm12, xmm3, xmm15
000077a0e99da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
000077a0e99da0a8  vptest xmm1, xmm1
000077a0e99da0ad  jnz 0x000077A0E99DB0AF
000077a0e99da0b3  vmovaps [rsp+0xA0], xmm4
000077a0e99da0bc  vmovaps xmm1, [rsp+0xA0]
000077a0e99da0c5  por xmm4, xmm1
000077a0e99da0c9  movaps [r15+0x200], xmm4
000077a0e99da0d1  vmovaps xmm1, [rsp+0xE0]
000077a0e99da0da  vmovaps xmm15, [rsp+0xE0]
000077a0e99da0e3  por xmm1, xmm15
000077a0e99da0e8  movaps [r15+0x1E0], xmm1
000077a0e99da0f0  vmovaps [rsp+0xA0], xmm8
000077a0e99da0f9  vmovaps xmm1, [rsp+0xA0]
000077a0e99da102  por xmm8, xmm1
000077a0e99da107  movaps [r15+0x2B0], xmm8
000077a0e99da10f  vmovaps [rsp+0xA0], xmm9
000077a0e99da118  vmovaps xmm1, [rsp+0xA0]
000077a0e99da121  por xmm9, xmm1
000077a0e99da126  movaps [r15+0x300], xmm9
000077a0e99da12e  vmovaps [rsp+0xA0], xmm6
000077a0e99da137  vpermilpd xmm6, xmm6, 0x00
000077a0e99da13d  vmovaps xmm14, [rsp+0x60]
000077a0e99da143  movaps xmm9, xmm13
000077a0e99da147  vfmadd231pd xmm9, xmm14, xmm6
000077a0e99da14c  vcmppd xmm3, xmm9, xmm9, 0x03
000077a0e99da152  vptest xmm3, xmm3
000077a0e99da157  jnz 0x000077A0E99DB208
000077a0e99da15d  vmovaps xmm14, [rsp+0xA0]
000077a0e99da166  vpermilpd xmm14, xmm14, 0x00
000077a0e99da16c  vmovaps xmm13, [rsp+0x50]
000077a0e99da172  vmovaps xmm6, [rsp+0xC0]
000077a0e99da17b  vmovaps [rsp+0x50], xmm1
000077a0e99da181  movaps xmm3, xmm13
000077a0e99da185  vfmadd231pd xmm3, xmm6, xmm14
000077a0e99da18a  vcmppd xmm1, xmm3, xmm3, 0x03
000077a0e99da18f  vptest xmm1, xmm1
000077a0e99da194  jnz 0x000077A0E99DB361
000077a0e99da19a  vmovaps xmm1, [rsp+0xA0]
000077a0e99da1a3  vpermilpd xmm1, xmm1, 0x00
000077a0e99da1a9  vmovaps xmm14, [rsp+0x30]
000077a0e99da1af  movaps xmm6, xmm2
000077a0e99da1b2  vfmadd231pd xmm6, xmm14, xmm1
000077a0e99da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
000077a0e99da1bc  vptest xmm13, xmm13
000077a0e99da1c1  jnz 0x000077A0E99DB4B8
000077a0e99da1c7  vmovaps xmm1, [rsp+0xA0]
000077a0e99da1d0  vpermilpd xmm1, xmm1, 0x00
000077a0e99da1d6  vmovaps xmm14, [rsp+0x80]
000077a0e99da1df  movaps xmm13, xmm12
000077a0e99da1e3  vfmadd231pd xmm13, xmm14, xmm1
000077a0e99da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
000077a0e99da1ee  vptest xmm2, xmm2
000077a0e99da1f3  jnz 0x000077A0E99DB60E
000077a0e99da1f9  vmovaps [rsp+0x30], xmm7
000077a0e99da1ff  vmovaps xmm1, [rsp+0x30]
000077a0e99da205  por xmm7, xmm1
000077a0e99da209  movaps [r15+0x180], xmm7
000077a0e99da211  vmovaps [rsp+0x30], xmm10
000077a0e99da217  vmovaps xmm1, [rsp+0x30]
000077a0e99da21d  por xmm10, xmm1
000077a0e99da222  movaps [r15+0x2D0], xmm10
000077a0e99da22a  vmovaps [rsp+0x30], xmm5
000077a0e99da230  vpermilpd xmm5, xmm5, 0x00
000077a0e99da236  vmovaps xmm14, [rsp+0x50]
000077a0e99da23c  movaps xmm12, xmm3
000077a0e99da240  vfmadd231pd xmm12, xmm14, xmm5
000077a0e99da245  vcmppd xmm10, xmm12, xmm12, 0x03
000077a0e99da24b  vptest xmm10, xmm10
000077a0e99da250  jnz 0x000077A0E99DB767
000077a0e99da256  vmovaps xmm14, [rsp+0x30]
000077a0e99da25c  vpermilpd xmm14, xmm14, 0x00
000077a0e99da262  movaps xmm10, xmm9
000077a0e99da266  vfmadd231pd xmm10, xmm7, xmm14
000077a0e99da26b  vcmppd xmm5, xmm10, xmm10, 0x03
000077a0e99da271  vptest xmm5, xmm5
000077a0e99da276  jnz 0x000077A0E99DB8BF
000077a0e99da27c  lea rax, [r14+0x80]
000077a0e99da283  movups xmm14, [r13+rax*1]
000077a0e99da289  movaps [r15+0x2F0], xmm14
000077a0e99da291  vmovaps xmm9, [rsp+0x30]
000077a0e99da297  vpermilpd xmm9, xmm9, 0x00
000077a0e99da29d  vmovaps xmm7, [rsp+0x70]
000077a0e99da2a3  movaps xmm5, xmm6
000077a0e99da2a6  vfmadd231pd xmm5, xmm7, xmm9
000077a0e99da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
000077a0e99da2b0  vptest xmm3, xmm3
000077a0e99da2b5  jnz 0x000077A0E99DBA22
000077a0e99da2bb  vmovaps xmm9, [rsp+0x30]
000077a0e99da2c1  vpermilpd xmm9, xmm9, 0x00
000077a0e99da2c7  movaps xmm7, xmm13
000077a0e99da2cb  vfmadd231pd xmm7, xmm1, xmm9
000077a0e99da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
000077a0e99da2d5  vptest xmm6, xmm6
000077a0e99da2da  jnz 0x000077A0E99DBB78
000077a0e99da2e0  vmovaps xmm1, [rsp+0x20]
000077a0e99da2e6  vmovaps xmm13, [rsp+0x20]
000077a0e99da2ec  por xmm1, xmm13
000077a0e99da2f1  movaps [r15+0x160], xmm1
000077a0e99da2f9  lea rax, [r14+0x40]
000077a0e99da2fd  movups xmm13, [r13+rax*1]
000077a0e99da303  lea rax, [r14+0x50]
000077a0e99da307  movups xmm9, [r13+rax*1]
000077a0e99da30d  movaps [r15+0x1B0], xmm13
000077a0e99da315  movaps [r15+0x1A0], xmm9
000077a0e99da31d  movaps xmm6, [r15+0x190]
000077a0e99da325  vmovaps xmm3, [rsp+0xB0]
000077a0e99da32e  vpermilpd xmm3, xmm3, 0x00
000077a0e99da334  vmovaps [rsp+0x20], xmm1
000077a0e99da33a  movaps xmm2, xmm12
000077a0e99da33e  vfmadd231pd xmm2, xmm6, xmm3
000077a0e99da343  vcmppd xmm1, xmm2, xmm2, 0x03
000077a0e99da348  vptest xmm1, xmm1
000077a0e99da34d  jnz 0x000077A0E99DBCE3
000077a0e99da353  vmovaps xmm1, [rsp+0xB0]
000077a0e99da35c  vpermilpd xmm1, xmm1, 0x00
000077a0e99da362  vmovaps xmm12, [rsp+0x20]
000077a0e99da368  movaps xmm6, xmm10
000077a0e99da36c  vfmadd231pd xmm6, xmm12, xmm1
000077a0e99da371  vcmppd xmm3, xmm6, xmm6, 0x03
000077a0e99da376  vptest xmm3, xmm3
000077a0e99da37b  jnz 0x000077A0E99DBE39
000077a0e99da381  vmovaps xmm1, [rsp+0xB0]
000077a0e99da38a  vpermilpd xmm1, xmm1, 0x00
000077a0e99da390  vmovaps xmm12, [rsp+0x40]
000077a0e99da396  movaps xmm10, xmm5
000077a0e99da39a  vfmadd231pd xmm10, xmm12, xmm1
000077a0e99da39f  vcmppd xmm3, xmm10, xmm10, 0x03
000077a0e99da3a5  vptest xmm3, xmm3
000077a0e99da3aa  jnz 0x000077A0E99DBF90
000077a0e99da3b0  vmovaps xmm1, [rsp+0xB0]
000077a0e99da3b9  vpermilpd xmm1, xmm1, 0x00
000077a0e99da3bf  movaps xmm12, xmm7
000077a0e99da3c3  vfmadd231pd xmm12, xmm15, xmm1
000077a0e99da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
000077a0e99da3ce  vptest xmm5, xmm5
000077a0e99da3d3  jnz 0x000077A0E99DC0E8
000077a0e99da3d9  lea rax, [r14+0x60]
000077a0e99da3dd  movups xmm1, [r13+rax*1]
000077a0e99da3e3  lea rax, [r14+0x70]
000077a0e99da3e7  movups xmm15, [r13+rax*1]
000077a0e99da3ed  movaps [r15+0x150], xmm1
000077a0e99da3f5  movaps [r15+0x120], xmm15
000077a0e99da3fd  vmovaps [rsp+0x20], xmm11
000077a0e99da403  vpermilpd xmm11, xmm11, 0x00
000077a0e99da409  movaps xmm7, xmm2
000077a0e99da40c  vfmadd231pd xmm7, xmm9, xmm11
000077a0e99da411  vcmppd xmm5, xmm7, xmm7, 0x03
000077a0e99da416  vptest xmm5, xmm5
000077a0e99da41b  jnz 0x000077A0E99DC254
000077a0e99da421  vmovaps xmm11, [rsp+0x20]
000077a0e99da427  vpermilpd xmm11, xmm11, 0x00
000077a0e99da42d  movaps xmm9, xmm6
000077a0e99da431  vfmadd231pd xmm9, xmm1, xmm11
000077a0e99da436  vcmppd xmm5, xmm9, xmm9, 0x03
000077a0e99da43c  vptest xmm5, xmm5
000077a0e99da441  jnz 0x000077A0E99DC3AB
000077a0e99da447  vmovaps xmm1, [rsp+0x20]
000077a0e99da44d  vpermilpd xmm1, xmm1, 0x00
000077a0e99da453  movaps xmm11, xmm10
000077a0e99da457  vfmadd231pd xmm11, xmm8, xmm1
000077a0e99da45c  vcmppd xmm6, xmm11, xmm11, 0x03
000077a0e99da462  vptest xmm6, xmm6
000077a0e99da467  jnz 0x000077A0E99DC503
000077a0e99da46d  vmovaps xmm1, [rsp+0x20]
000077a0e99da473  vpermilpd xmm1, xmm1, 0x00
000077a0e99da479  movaps xmm10, xmm12
000077a0e99da47d  vfmadd231pd xmm10, xmm13, xmm1
000077a0e99da482  vcmppd xmm8, xmm10, xmm10, 0x03
000077a0e99da488  vptest xmm8, xmm8
000077a0e99da48d  jnz 0x000077A0E99DC65C
000077a0e99da493  lea rax, [r14+0x20]
000077a0e99da497  movups xmm1, [r13+rax*1]
000077a0e99da49d  lea rax, [r14+0x30]
000077a0e99da4a1  movups xmm13, [r13+rax*1]
000077a0e99da4a7  vmovaps xmm12, [rsp+0x90]
000077a0e99da4b0  vpermilpd xmm12, xmm12, 0x00
000077a0e99da4b6  movaps xmm8, xmm7
000077a0e99da4ba  vfmadd231pd xmm8, xmm4, xmm12
000077a0e99da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
000077a0e99da4c5  vptest xmm6, xmm6
000077a0e99da4ca  jnz 0x000077A0E99DC7C9
000077a0e99da4d0  vmovaps xmm12, [rsp+0x90]
000077a0e99da4d9  vpermilpd xmm12, xmm12, 0x00
000077a0e99da4df  movaps xmm7, xmm9
000077a0e99da4e3  vfmadd231pd xmm7, xmm14, xmm12
000077a0e99da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
000077a0e99da4ed  vptest xmm6, xmm6
000077a0e99da4f2  jnz 0x000077A0E99DC921
000077a0e99da4f8  vmovaps xmm14, [rsp+0x90]
000077a0e99da501  vpermilpd xmm14, xmm14, 0x00
000077a0e99da507  movaps xmm12, xmm11
000077a0e99da50b  vfmadd231pd xmm12, xmm15, xmm14
000077a0e99da510  vcmppd xmm9, xmm12, xmm12, 0x03
000077a0e99da516  vptest xmm9, xmm9
000077a0e99da51b  jnz 0x000077A0E99DCA79
000077a0e99da521  vmovaps xmm15, [rsp+0x90]
000077a0e99da52a  vpermilpd xmm15, xmm15, 0x00
000077a0e99da530  movaps xmm11, xmm10
000077a0e99da534  vfmadd231pd xmm11, xmm13, xmm15
000077a0e99da539  vcmppd xmm14, xmm11, xmm11, 0x03
000077a0e99da53f  vptest xmm14, xmm14
000077a0e99da544  jnz 0x000077A0E99DCBD3
000077a0e99da54a  lea rax, [r14+0x90]
000077a0e99da551  movups xmm15, [r13+rax*1]
000077a0e99da557  lea rax, [r14+0xA0]
000077a0e99da55e  movups xmm14, [r13+rax*1]
000077a0e99da564  movaps [r15+0x140], xmm15
000077a0e99da56c  movaps [r15+0x130], xmm14
000077a0e99da574  vmovaps xmm13, [rsp+0x10]
000077a0e99da57a  vpermilpd xmm13, xmm13, 0x00
000077a0e99da580  movaps xmm10, xmm8
000077a0e99da584  vfmadd231pd xmm10, xmm1, xmm13
000077a0e99da589  vcmppd xmm9, xmm10, xmm10, 0x03
000077a0e99da58f  vptest xmm9, xmm9
000077a0e99da594  jnz 0x000077A0E99DCD41
000077a0e99da59a  movaps [r15+0x220], xmm10
000077a0e99da5a2  lea rax, [r14+0x10]
000077a0e99da5a6  movups xmm1, [r13+rax*1]
000077a0e99da5ac  movaps [r15+0x240], xmm1
000077a0e99da5b4  vmovaps xmm13, [rsp+0x10]
000077a0e99da5ba  vpermilpd xmm13, xmm13, 0x00
000077a0e99da5c0  movaps xmm9, xmm7
000077a0e99da5c4  vfmadd231pd xmm9, xmm14, xmm13
000077a0e99da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
000077a0e99da5cf  vptest xmm8, xmm8
000077a0e99da5d4  jnz 0x000077A0E99DCEA4
000077a0e99da5da  movaps [r15+0x110], xmm9
000077a0e99da5e2  vmovaps xmm14, [rsp+0x10]
000077a0e99da5e8  vpermilpd xmm14, xmm14, 0x00
000077a0e99da5ee  movaps xmm13, xmm12
000077a0e99da5f2  vfmadd231pd xmm13, xmm15, xmm14
000077a0e99da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
000077a0e99da5fd  vptest xmm8, xmm8
000077a0e99da602  jnz 0x000077A0E99DCFFD
000077a0e99da608  movaps [r15+0x170], xmm13
000077a0e99da610  vmovaps xmm15, [rsp+0x10]
000077a0e99da616  vpermilpd xmm15, xmm15, 0x00
000077a0e99da61c  movaps xmm14, xmm11
000077a0e99da620  vfmadd231pd xmm14, xmm1, xmm15
000077a0e99da625  vcmppd xmm12, xmm14, xmm14, 0x03
000077a0e99da62b  vptest xmm12, xmm12
000077a0e99da630  jnz 0x000077A0E99DD157
000077a0e99da636  movaps [r15+0x230], xmm14
000077a0e99da63e  mov rax, [rsp+0xD0]
000077a0e99da646  movups [r13+rax*1], xmm9
000077a0e99da64c  lea r14, [rax+0x10]
000077a0e99da650  movups [r13+r14*1], xmm13
000077a0e99da656  lea r14, [rax+0x20]
000077a0e99da65a  movups [r13+r14*1], xmm10
000077a0e99da660  lea r14, [rax+0x30]
000077a0e99da664  movups [r13+r14*1], xmm14
000077a0e99da66a  mov eax, [r15+0x108]
000077a0e99da671  sahf
000077a0e99da672  jnz 0x000077A0E99DA6A4
000077a0e99da674  cmp dword ptr [r15+0x318], 0x00
000077a0e99da67c  jz 0x000077A0E99D9950
000077a0e99da682  nop [rax+rax*1], ax
000077a0e99da68b  nop [rax+rax*1], eax
000077a0e99da693  mov eax, 0x410664
000077a0e99da698  mov [r15+0x100], rax
000077a0e99da69f  jmp 0x000077A0E97FE110
000077a0e99da6a4  cmp dword ptr [r15+0x318], 0x00
000077a0e99da6ac  jz 0x000077A0E99D6050
000077a0e99da6b2  nop [rax+rax*1], ax
000077a0e99da6bb  nop [rax+rax*1], eax
000077a0e99da6c3  mov eax, 0x4104F0
000077a0e99da6c8  mov [r15+0x100], rax
000077a0e99da6cf  jmp 0x000077A0E97FE110
000077a0e99da6d4  int3
000077a0e99da6d5  call 0x000077A0E98E27E0
000077a0e99da6da  jmp 0x000077A0E99D9A10
000077a0e99da6df  call 0x000077A0E98E1570
000077a0e99da6e4  jmp 0x000077A0E99D9A19
000077a0e99da6e9  call 0x000077A0E98E27E0
000077a0e99da6ee  jmp 0x000077A0E99D9A62
000077a0e99da6f3  call 0x000077A0E98E1570
000077a0e99da6f8  jmp 0x000077A0E99D9A6B
000077a0e99da6fd  call 0x000077A0E98E27E0
000077a0e99da702  jmp 0x000077A0E99D9AEB
000077a0e99da707  call 0x000077A0E98E1570
000077a0e99da70c  jmp 0x000077A0E99D9AF4
000077a0e99da711  call 0x000077A0E980DC20
000077a0e99da716  jmp 0x000077A0E99D9BD5
000077a0e99da71b  call 0x000077A0E98D64F0
000077a0e99da720  jmp 0x000077A0E99D9C04
000077a0e99da725  call 0x000077A0E98B47C0
000077a0e99da72a  jmp 0x000077A0E99D9C1F
000077a0e99da72f  sub rsp, 0x08
000077a0e99da733  push rax
000077a0e99da734  push rcx
000077a0e99da735  push rdx
000077a0e99da736  push rdi
000077a0e99da737  push rsi
000077a0e99da738  push r8
000077a0e99da73a  push r9
000077a0e99da73c  push r10
000077a0e99da73e  push r11
000077a0e99da740  sub rsp, 0xF0
000077a0e99da747  vmovaps [rsp], xmm0
000077a0e99da74c  vmovaps [rsp+0x10], xmm1
000077a0e99da752  vmovaps [rsp+0x20], xmm2
000077a0e99da758  vmovaps [rsp+0x30], xmm3
000077a0e99da75e  vmovaps [rsp+0x40], xmm4
000077a0e99da764  vmovaps [rsp+0x50], xmm5
000077a0e99da76a  vmovaps [rsp+0x60], xmm6
000077a0e99da770  vmovaps [rsp+0x70], xmm7
000077a0e99da776  vmovaps [rsp+0x80], xmm8
000077a0e99da77f  vmovaps [rsp+0x90], xmm9
000077a0e99da788  vmovaps [rsp+0xA0], xmm10
000077a0e99da791  vmovaps [rsp+0xB0], xmm11
000077a0e99da79a  vmovaps [rsp+0xC0], xmm12
000077a0e99da7a3  vmovaps [rsp+0xD0], xmm14
000077a0e99da7ac  vmovaps [rsp+0xE0], xmm15
000077a0e99da7b5  sub rsp, 0x40
000077a0e99da7b9  lea rdi, [rsp]
000077a0e99da7bd  lea rsi, [rsp+0x10]
000077a0e99da7c2  lea rdx, [rsp+0x20]
000077a0e99da7c7  lea rcx, [rsp+0x30]
000077a0e99da7cc  mov r8d, 0x00
000077a0e99da7d2  lea r9, [r15+0x3A8]
000077a0e99da7d9  movaps [rdi], xmm13
000077a0e99da7dd  movaps [rsi], xmm1
000077a0e99da7e0  movaps [rdx], xmm15
000077a0e99da7e4  movaps [rcx], xmm14
000077a0e99da7e8  mov rax, 0x60CAA235BA50
000077a0e99da7f2  call rax
000077a0e99da7f4  movaps xmm13, [rsp]
000077a0e99da7f9  add rsp, 0x40
000077a0e99da7fd  vmovaps xmm0, [rsp]
000077a0e99da802  vmovaps xmm1, [rsp+0x10]
000077a0e99da808  vmovaps xmm2, [rsp+0x20]
000077a0e99da80e  vmovaps xmm3, [rsp+0x30]
000077a0e99da814  vmovaps xmm4, [rsp+0x40]
000077a0e99da81a  vmovaps xmm5, [rsp+0x50]
000077a0e99da820  vmovaps xmm6, [rsp+0x60]
000077a0e99da826  vmovaps xmm7, [rsp+0x70]
000077a0e99da82c  vmovaps xmm8, [rsp+0x80]
000077a0e99da835  vmovaps xmm9, [rsp+0x90]
000077a0e99da83e  vmovaps xmm10, [rsp+0xA0]
000077a0e99da847  vmovaps xmm11, [rsp+0xB0]
000077a0e99da850  vmovaps xmm12, [rsp+0xC0]
000077a0e99da859  vmovaps xmm14, [rsp+0xD0]
000077a0e99da862  vmovaps xmm15, [rsp+0xE0]
000077a0e99da86b  add rsp, 0xF0
000077a0e99da872  pop r11
000077a0e99da874  pop r10
000077a0e99da876  pop r9
000077a0e99da878  pop r8
000077a0e99da87a  pop rsi
000077a0e99da87b  pop rdi
000077a0e99da87c  pop rdx
000077a0e99da87d  pop rcx
000077a0e99da87e  pop rax
000077a0e99da87f  add rsp, 0x08
000077a0e99da883  jmp 0x000077A0E99D9C92
000077a0e99da888  sub rsp, 0x08
000077a0e99da88c  push rax
000077a0e99da88d  push rcx
000077a0e99da88e  push rdx
000077a0e99da88f  push rdi
000077a0e99da890  push rsi
000077a0e99da891  push r8
000077a0e99da893  push r9
000077a0e99da895  push r10
000077a0e99da897  push r11
000077a0e99da899  sub rsp, 0xF0
000077a0e99da8a0  vmovaps [rsp], xmm0
000077a0e99da8a5  vmovaps [rsp+0x10], xmm1
000077a0e99da8ab  vmovaps [rsp+0x20], xmm2
000077a0e99da8b1  vmovaps [rsp+0x30], xmm3
000077a0e99da8b7  vmovaps [rsp+0x40], xmm4
000077a0e99da8bd  vmovaps [rsp+0x50], xmm5
000077a0e99da8c3  vmovaps [rsp+0x60], xmm6
000077a0e99da8c9  vmovaps [rsp+0x70], xmm7
000077a0e99da8cf  vmovaps [rsp+0x80], xmm8
000077a0e99da8d8  vmovaps [rsp+0x90], xmm9
000077a0e99da8e1  vmovaps [rsp+0xA0], xmm10
000077a0e99da8ea  vmovaps [rsp+0xB0], xmm11
000077a0e99da8f3  vmovaps [rsp+0xC0], xmm13
000077a0e99da8fc  vmovaps [rsp+0xD0], xmm14
000077a0e99da905  vmovaps [rsp+0xE0], xmm15
000077a0e99da90e  sub rsp, 0x40
000077a0e99da912  lea rdi, [rsp]
000077a0e99da916  lea rsi, [rsp+0x10]
000077a0e99da91b  lea rdx, [rsp+0x20]
000077a0e99da920  lea rcx, [rsp+0x30]
000077a0e99da925  mov r8d, 0x00
000077a0e99da92b  lea r9, [r15+0x3A8]
000077a0e99da932  movaps [rdi], xmm12
000077a0e99da936  movaps [rsi], xmm15
000077a0e99da93a  movaps [rdx], xmm1
000077a0e99da93d  movaps [rcx], xmm14
000077a0e99da941  mov rax, 0x60CAA235BA50
000077a0e99da94b  call rax
000077a0e99da94d  movaps xmm12, [rsp]
000077a0e99da952  add rsp, 0x40
000077a0e99da956  vmovaps xmm0, [rsp]
000077a0e99da95b  vmovaps xmm1, [rsp+0x10]
000077a0e99da961  vmovaps xmm2, [rsp+0x20]
000077a0e99da967  vmovaps xmm3, [rsp+0x30]
000077a0e99da96d  vmovaps xmm4, [rsp+0x40]
000077a0e99da973  vmovaps xmm5, [rsp+0x50]
000077a0e99da979  vmovaps xmm6, [rsp+0x60]
000077a0e99da97f  vmovaps xmm7, [rsp+0x70]
000077a0e99da985  vmovaps xmm8, [rsp+0x80]
000077a0e99da98e  vmovaps xmm9, [rsp+0x90]
000077a0e99da997  vmovaps xmm10, [rsp+0xA0]
000077a0e99da9a0  vmovaps xmm11, [rsp+0xB0]
000077a0e99da9a9  vmovaps xmm13, [rsp+0xC0]
000077a0e99da9b2  vmovaps xmm14, [rsp+0xD0]
000077a0e99da9bb  vmovaps xmm15, [rsp+0xE0]
000077a0e99da9c4  add rsp, 0xF0
000077a0e99da9cb  pop r11
000077a0e99da9cd  pop r10
000077a0e99da9cf  pop r9
000077a0e99da9d1  pop r8
000077a0e99da9d3  pop rsi
000077a0e99da9d4  pop rdi
000077a0e99da9d5  pop rdx
000077a0e99da9d6  pop rcx
000077a0e99da9d7  pop rax
000077a0e99da9d8  add rsp, 0x08
000077a0e99da9dc  jmp 0x000077A0E99D9CC0
000077a0e99da9e1  call 0x000077A0E98B52F0
000077a0e99da9e6  jmp 0x000077A0E99D9DAC
000077a0e99da9eb  sub rsp, 0x08
000077a0e99da9ef  push rax
000077a0e99da9f0  push rcx
000077a0e99da9f1  push rdx
000077a0e99da9f2  push rdi
000077a0e99da9f3  push rsi
000077a0e99da9f4  push r8
000077a0e99da9f6  push r9
000077a0e99da9f8  push r10
000077a0e99da9fa  push r11
000077a0e99da9fc  sub rsp, 0xF0
000077a0e99daa03  vmovaps [rsp], xmm0
000077a0e99daa08  vmovaps [rsp+0x10], xmm1
000077a0e99daa0e  vmovaps [rsp+0x20], xmm2
000077a0e99daa14  vmovaps [rsp+0x30], xmm3
000077a0e99daa1a  vmovaps [rsp+0x40], xmm4
000077a0e99daa20  vmovaps [rsp+0x50], xmm5
000077a0e99daa26  vmovaps [rsp+0x60], xmm6
000077a0e99daa2c  vmovaps [rsp+0x70], xmm7
000077a0e99daa32  vmovaps [rsp+0x80], xmm8
000077a0e99daa3b  vmovaps [rsp+0x90], xmm9
000077a0e99daa44  vmovaps [rsp+0xA0], xmm10
000077a0e99daa4d  vmovaps [rsp+0xB0], xmm11
000077a0e99daa56  vmovaps [rsp+0xC0], xmm12
000077a0e99daa5f  vmovaps [rsp+0xD0], xmm14
000077a0e99daa68  vmovaps [rsp+0xE0], xmm15
000077a0e99daa71  sub rsp, 0x40
000077a0e99daa75  lea rdi, [rsp]
000077a0e99daa79  lea rsi, [rsp+0x10]
000077a0e99daa7e  lea rdx, [rsp+0x20]
000077a0e99daa83  lea rcx, [rsp+0x30]
000077a0e99daa88  mov r8d, 0x00
000077a0e99daa8e  lea r9, [r15+0x3A8]
000077a0e99daa95  movaps [rdi], xmm13
000077a0e99daa99  movaps [rsi], xmm1
000077a0e99daa9c  movaps [rdx], xmm15
000077a0e99daaa0  movaps [rcx], xmm14
000077a0e99daaa4  mov rax, 0x60CAA235BA50
000077a0e99daaae  call rax
000077a0e99daab0  movaps xmm13, [rsp]
000077a0e99daab5  add rsp, 0x40
000077a0e99daab9  vmovaps xmm0, [rsp]
000077a0e99daabe  vmovaps xmm1, [rsp+0x10]
000077a0e99daac4  vmovaps xmm2, [rsp+0x20]
000077a0e99daaca  vmovaps xmm3, [rsp+0x30]
000077a0e99daad0  vmovaps xmm4, [rsp+0x40]
000077a0e99daad6  vmovaps xmm5, [rsp+0x50]
000077a0e99daadc  vmovaps xmm6, [rsp+0x60]
000077a0e99daae2  vmovaps xmm7, [rsp+0x70]
000077a0e99daae8  vmovaps xmm8, [rsp+0x80]
000077a0e99daaf1  vmovaps xmm9, [rsp+0x90]
000077a0e99daafa  vmovaps xmm10, [rsp+0xA0]
000077a0e99dab03  vmovaps xmm11, [rsp+0xB0]
000077a0e99dab0c  vmovaps xmm12, [rsp+0xC0]
000077a0e99dab15  vmovaps xmm14, [rsp+0xD0]
000077a0e99dab1e  vmovaps xmm15, [rsp+0xE0]
000077a0e99dab27  add rsp, 0xF0
000077a0e99dab2e  pop r11
000077a0e99dab30  pop r10
000077a0e99dab32  pop r9
000077a0e99dab34  pop r8
000077a0e99dab36  pop rsi
000077a0e99dab37  pop rdi
000077a0e99dab38  pop rdx
000077a0e99dab39  pop rcx
000077a0e99dab3a  pop rax
000077a0e99dab3b  add rsp, 0x08
000077a0e99dab3f  jmp 0x000077A0E99D9E21
000077a0e99dab44  call 0x000077A0E97FF430
000077a0e99dab49  jmp 0x000077A0E99D9E2E
000077a0e99dab4e  sub rsp, 0x08
000077a0e99dab52  push rax
000077a0e99dab53  push rcx
000077a0e99dab54  push rdx
000077a0e99dab55  push rdi
000077a0e99dab56  push rsi
000077a0e99dab57  push r8
000077a0e99dab59  push r9
000077a0e99dab5b  push r10
000077a0e99dab5d  push r11
000077a0e99dab5f  sub rsp, 0xF0
000077a0e99dab66  vmovaps [rsp], xmm0
000077a0e99dab6b  vmovaps [rsp+0x10], xmm1
000077a0e99dab71  vmovaps [rsp+0x20], xmm2
000077a0e99dab77  vmovaps [rsp+0x30], xmm3
000077a0e99dab7d  vmovaps [rsp+0x40], xmm4
000077a0e99dab83  vmovaps [rsp+0x50], xmm5
000077a0e99dab89  vmovaps [rsp+0x60], xmm6
000077a0e99dab8f  vmovaps [rsp+0x70], xmm7
000077a0e99dab95  vmovaps [rsp+0x80], xmm8
000077a0e99dab9e  vmovaps [rsp+0x90], xmm9
000077a0e99daba7  vmovaps [rsp+0xA0], xmm10
000077a0e99dabb0  vmovaps [rsp+0xB0], xmm11
000077a0e99dabb9  vmovaps [rsp+0xC0], xmm13
000077a0e99dabc2  vmovaps [rsp+0xD0], xmm14
000077a0e99dabcb  vmovaps [rsp+0xE0], xmm15
000077a0e99dabd4  sub rsp, 0x40
000077a0e99dabd8  lea rdi, [rsp]
000077a0e99dabdc  lea rsi, [rsp+0x10]
000077a0e99dabe1  lea rdx, [rsp+0x20]
000077a0e99dabe6  lea rcx, [rsp+0x30]
000077a0e99dabeb  mov r8d, 0x00
000077a0e99dabf1  lea r9, [r15+0x3A8]
000077a0e99dabf8  movaps [rdi], xmm12
000077a0e99dabfc  movaps [rsi], xmm15
000077a0e99dac00  movaps [rdx], xmm1
000077a0e99dac03  movaps [rcx], xmm14
000077a0e99dac07  mov rax, 0x60CAA235BA50
000077a0e99dac11  call rax
000077a0e99dac13  movaps xmm12, [rsp]
000077a0e99dac18  add rsp, 0x40
000077a0e99dac1c  vmovaps xmm0, [rsp]
000077a0e99dac21  vmovaps xmm1, [rsp+0x10]
000077a0e99dac27  vmovaps xmm2, [rsp+0x20]
000077a0e99dac2d  vmovaps xmm3, [rsp+0x30]
000077a0e99dac33  vmovaps xmm4, [rsp+0x40]
000077a0e99dac39  vmovaps xmm5, [rsp+0x50]
000077a0e99dac3f  vmovaps xmm6, [rsp+0x60]
000077a0e99dac45  vmovaps xmm7, [rsp+0x70]
000077a0e99dac4b  vmovaps xmm8, [rsp+0x80]
000077a0e99dac54  vmovaps xmm9, [rsp+0x90]
000077a0e99dac5d  vmovaps xmm10, [rsp+0xA0]
000077a0e99dac66  vmovaps xmm11, [rsp+0xB0]
000077a0e99dac6f  vmovaps xmm13, [rsp+0xC0]
000077a0e99dac78  vmovaps xmm14, [rsp+0xD0]
000077a0e99dac81  vmovaps xmm15, [rsp+0xE0]
000077a0e99dac8a  add rsp, 0xF0
000077a0e99dac91  pop r11
000077a0e99dac93  pop r10
000077a0e99dac95  pop r9
000077a0e99dac97  pop r8
000077a0e99dac99  pop rsi
000077a0e99dac9a  pop rdi
000077a0e99dac9b  pop rdx
000077a0e99dac9c  pop rcx
000077a0e99dac9d  pop rax
000077a0e99dac9e  add rsp, 0x08
000077a0e99daca2  jmp 0x000077A0E99D9E5A
000077a0e99daca7  sub rsp, 0x08
000077a0e99dacab  push rax
000077a0e99dacac  push rcx
000077a0e99dacad  push rdx
000077a0e99dacae  push rdi
000077a0e99dacaf  push rsi
000077a0e99dacb0  push r8
000077a0e99dacb2  push r9
000077a0e99dacb4  push r10
000077a0e99dacb6  push r11
000077a0e99dacb8  sub rsp, 0xF0
000077a0e99dacbf  vmovaps [rsp], xmm0
000077a0e99dacc4  vmovaps [rsp+0x10], xmm1
000077a0e99dacca  vmovaps [rsp+0x20], xmm2
000077a0e99dacd0  vmovaps [rsp+0x30], xmm3
000077a0e99dacd6  vmovaps [rsp+0x40], xmm4
000077a0e99dacdc  vmovaps [rsp+0x50], xmm5
000077a0e99dace2  vmovaps [rsp+0x60], xmm6
000077a0e99dace8  vmovaps [rsp+0x70], xmm7
000077a0e99dacee  vmovaps [rsp+0x80], xmm8
000077a0e99dacf7  vmovaps [rsp+0x90], xmm9
000077a0e99dad00  vmovaps [rsp+0xA0], xmm10
000077a0e99dad09  vmovaps [rsp+0xB0], xmm11
000077a0e99dad12  vmovaps [rsp+0xC0], xmm12
000077a0e99dad1b  vmovaps [rsp+0xD0], xmm14
000077a0e99dad24  vmovaps [rsp+0xE0], xmm15
000077a0e99dad2d  sub rsp, 0x40
000077a0e99dad31  lea rdi, [rsp]
000077a0e99dad35  lea rsi, [rsp+0x10]
000077a0e99dad3a  lea rdx, [rsp+0x20]
000077a0e99dad3f  lea rcx, [rsp+0x30]
000077a0e99dad44  mov r8d, 0x00
000077a0e99dad4a  lea r9, [r15+0x3A8]
000077a0e99dad51  movaps [rdi], xmm13
000077a0e99dad55  movaps [rsi], xmm1
000077a0e99dad58  movaps [rdx], xmm15
000077a0e99dad5c  movaps [rcx], xmm14
000077a0e99dad60  mov rax, 0x60CAA235BA50
000077a0e99dad6a  call rax
000077a0e99dad6c  movaps xmm13, [rsp]
000077a0e99dad71  add rsp, 0x40
000077a0e99dad75  vmovaps xmm0, [rsp]
000077a0e99dad7a  vmovaps xmm1, [rsp+0x10]
000077a0e99dad80  vmovaps xmm2, [rsp+0x20]
000077a0e99dad86  vmovaps xmm3, [rsp+0x30]
000077a0e99dad8c  vmovaps xmm4, [rsp+0x40]
000077a0e99dad92  vmovaps xmm5, [rsp+0x50]
000077a0e99dad98  vmovaps xmm6, [rsp+0x60]
000077a0e99dad9e  vmovaps xmm7, [rsp+0x70]
000077a0e99dada4  vmovaps xmm8, [rsp+0x80]
000077a0e99dadad  vmovaps xmm9, [rsp+0x90]
000077a0e99dadb6  vmovaps xmm10, [rsp+0xA0]
000077a0e99dadbf  vmovaps xmm11, [rsp+0xB0]
000077a0e99dadc8  vmovaps xmm12, [rsp+0xC0]
000077a0e99dadd1  vmovaps xmm14, [rsp+0xD0]
000077a0e99dadda  vmovaps xmm15, [rsp+0xE0]
000077a0e99dade3  add rsp, 0xF0
000077a0e99dadea  pop r11
000077a0e99dadec  pop r10
000077a0e99dadee  pop r9
000077a0e99dadf0  pop r8
000077a0e99dadf2  pop rsi
000077a0e99dadf3  pop rdi
000077a0e99dadf4  pop rdx
000077a0e99dadf5  pop rcx
000077a0e99dadf6  pop rax
000077a0e99dadf7  add rsp, 0x08
000077a0e99dadfb  jmp 0x000077A0E99D9FEA
000077a0e99dae00  sub rsp, 0x08
000077a0e99dae04  push rax
000077a0e99dae05  push rcx
000077a0e99dae06  push rdx
000077a0e99dae07  push rdi
000077a0e99dae08  push rsi
000077a0e99dae09  push r8
000077a0e99dae0b  push r9
000077a0e99dae0d  push r10
000077a0e99dae0f  push r11
000077a0e99dae11  sub rsp, 0xF0
000077a0e99dae18  vmovaps [rsp], xmm0
000077a0e99dae1d  vmovaps [rsp+0x10], xmm1
000077a0e99dae23  vmovaps [rsp+0x20], xmm2
000077a0e99dae29  vmovaps [rsp+0x30], xmm3
000077a0e99dae2f  vmovaps [rsp+0x40], xmm4
000077a0e99dae35  vmovaps [rsp+0x50], xmm5
000077a0e99dae3b  vmovaps [rsp+0x60], xmm6
000077a0e99dae41  vmovaps [rsp+0x70], xmm7
000077a0e99dae47  vmovaps [rsp+0x80], xmm8
000077a0e99dae50  vmovaps [rsp+0x90], xmm9
000077a0e99dae59  vmovaps [rsp+0xA0], xmm10
000077a0e99dae62  vmovaps [rsp+0xB0], xmm11
000077a0e99dae6b  vmovaps [rsp+0xC0], xmm12
000077a0e99dae74  vmovaps [rsp+0xD0], xmm13
000077a0e99dae7d  vmovaps [rsp+0xE0], xmm15
000077a0e99dae86  sub rsp, 0x40
000077a0e99dae8a  lea rdi, [rsp]
000077a0e99dae8e  lea rsi, [rsp+0x10]
000077a0e99dae93  lea rdx, [rsp+0x20]
000077a0e99dae98  lea rcx, [rsp+0x30]
000077a0e99dae9d  mov r8d, 0x00
000077a0e99daea3  lea r9, [r15+0x3A8]
000077a0e99daeaa  movaps [rdi], xmm14
000077a0e99daeae  movaps [rsi], xmm15
000077a0e99daeb2  movaps [rdx], xmm2
000077a0e99daeb5  movaps [rcx], xmm1
000077a0e99daeb8  mov rax, 0x60CAA235BA50
000077a0e99daec2  call rax
000077a0e99daec4  movaps xmm14, [rsp]
000077a0e99daec9  add rsp, 0x40
000077a0e99daecd  vmovaps xmm0, [rsp]
000077a0e99daed2  vmovaps xmm1, [rsp+0x10]
000077a0e99daed8  vmovaps xmm2, [rsp+0x20]
000077a0e99daede  vmovaps xmm3, [rsp+0x30]
000077a0e99daee4  vmovaps xmm4, [rsp+0x40]
000077a0e99daeea  vmovaps xmm5, [rsp+0x50]
000077a0e99daef0  vmovaps xmm6, [rsp+0x60]
000077a0e99daef6  vmovaps xmm7, [rsp+0x70]
000077a0e99daefc  vmovaps xmm8, [rsp+0x80]
000077a0e99daf05  vmovaps xmm9, [rsp+0x90]
000077a0e99daf0e  vmovaps xmm10, [rsp+0xA0]
000077a0e99daf17  vmovaps xmm11, [rsp+0xB0]
000077a0e99daf20  vmovaps xmm12, [rsp+0xC0]
000077a0e99daf29  vmovaps xmm13, [rsp+0xD0]
000077a0e99daf32  vmovaps xmm15, [rsp+0xE0]
000077a0e99daf3b  add rsp, 0xF0
000077a0e99daf42  pop r11
000077a0e99daf44  pop r10
000077a0e99daf46  pop r9
000077a0e99daf48  pop r8
000077a0e99daf4a  pop rsi
000077a0e99daf4b  pop rdi
000077a0e99daf4c  pop rdx
000077a0e99daf4d  pop rcx
000077a0e99daf4e  pop rax
000077a0e99daf4f  add rsp, 0x08
000077a0e99daf53  jmp 0x000077A0E99DA01C
000077a0e99daf58  sub rsp, 0x08
000077a0e99daf5c  push rax
000077a0e99daf5d  push rcx
000077a0e99daf5e  push rdx
000077a0e99daf5f  push rdi
000077a0e99daf60  push rsi
000077a0e99daf61  push r8
000077a0e99daf63  push r9
000077a0e99daf65  push r10
000077a0e99daf67  push r11
000077a0e99daf69  sub rsp, 0xF0
000077a0e99daf70  vmovaps [rsp], xmm0
000077a0e99daf75  vmovaps [rsp+0x10], xmm1
000077a0e99daf7b  vmovaps [rsp+0x20], xmm3
000077a0e99daf81  vmovaps [rsp+0x30], xmm4
000077a0e99daf87  vmovaps [rsp+0x40], xmm5
000077a0e99daf8d  vmovaps [rsp+0x50], xmm6
000077a0e99daf93  vmovaps [rsp+0x60], xmm7
000077a0e99daf99  vmovaps [rsp+0x70], xmm8
000077a0e99daf9f  vmovaps [rsp+0x80], xmm9
000077a0e99dafa8  vmovaps [rsp+0x90], xmm10
000077a0e99dafb1  vmovaps [rsp+0xA0], xmm11
000077a0e99dafba  vmovaps [rsp+0xB0], xmm12
000077a0e99dafc3  vmovaps [rsp+0xC0], xmm13
000077a0e99dafcc  vmovaps [rsp+0xD0], xmm14
000077a0e99dafd5  vmovaps [rsp+0xE0], xmm15
000077a0e99dafde  sub rsp, 0x40
000077a0e99dafe2  lea rdi, [rsp]
000077a0e99dafe6  lea rsi, [rsp+0x10]
000077a0e99dafeb  lea rdx, [rsp+0x20]
000077a0e99daff0  lea rcx, [rsp+0x30]
000077a0e99daff5  mov r8d, 0x00
000077a0e99daffb  lea r9, [r15+0x3A8]
000077a0e99db002  movaps [rdi], xmm2
000077a0e99db005  movaps [rsi], xmm15
000077a0e99db009  movaps [rdx], xmm12
000077a0e99db00d  movaps [rcx], xmm1
000077a0e99db010  mov rax, 0x60CAA235BA50
000077a0e99db01a  call rax
000077a0e99db01c  movaps xmm2, [rsp]
000077a0e99db020  add rsp, 0x40
000077a0e99db024  vmovaps xmm0, [rsp]
000077a0e99db029  vmovaps xmm1, [rsp+0x10]
000077a0e99db02f  vmovaps xmm3, [rsp+0x20]
000077a0e99db035  vmovaps xmm4, [rsp+0x30]
000077a0e99db03b  vmovaps xmm5, [rsp+0x40]
000077a0e99db041  vmovaps xmm6, [rsp+0x50]
000077a0e99db047  vmovaps xmm7, [rsp+0x60]
000077a0e99db04d  vmovaps xmm8, [rsp+0x70]
000077a0e99db053  vmovaps xmm9, [rsp+0x80]
000077a0e99db05c  vmovaps xmm10, [rsp+0x90]
000077a0e99db065  vmovaps xmm11, [rsp+0xA0]
000077a0e99db06e  vmovaps xmm12, [rsp+0xB0]
000077a0e99db077  vmovaps xmm13, [rsp+0xC0]
000077a0e99db080  vmovaps xmm14, [rsp+0xD0]
000077a0e99db089  vmovaps xmm15, [rsp+0xE0]
000077a0e99db092  add rsp, 0xF0
000077a0e99db099  pop r11
000077a0e99db09b  pop r10
000077a0e99db09d  pop r9
000077a0e99db09f  pop r8
000077a0e99db0a1  pop rsi
000077a0e99db0a2  pop rdi
000077a0e99db0a3  pop rdx
000077a0e99db0a4  pop rcx
000077a0e99db0a5  pop rax
000077a0e99db0a6  add rsp, 0x08
000077a0e99db0aa  jmp 0x000077A0E99DA059
000077a0e99db0af  sub rsp, 0x08
000077a0e99db0b3  push rax
000077a0e99db0b4  push rcx
000077a0e99db0b5  push rdx
000077a0e99db0b6  push rdi
000077a0e99db0b7  push rsi
000077a0e99db0b8  push r8
000077a0e99db0ba  push r9
000077a0e99db0bc  push r10
000077a0e99db0be  push r11
000077a0e99db0c0  sub rsp, 0xF0
000077a0e99db0c7  vmovaps [rsp], xmm0
000077a0e99db0cc  vmovaps [rsp+0x10], xmm1
000077a0e99db0d2  vmovaps [rsp+0x20], xmm2
000077a0e99db0d8  vmovaps [rsp+0x30], xmm3
000077a0e99db0de  vmovaps [rsp+0x40], xmm4
000077a0e99db0e4  vmovaps [rsp+0x50], xmm5
000077a0e99db0ea  vmovaps [rsp+0x60], xmm6
000077a0e99db0f0  vmovaps [rsp+0x70], xmm7
000077a0e99db0f6  vmovaps [rsp+0x80], xmm8
000077a0e99db0ff  vmovaps [rsp+0x90], xmm9
000077a0e99db108  vmovaps [rsp+0xA0], xmm10
000077a0e99db111  vmovaps [rsp+0xB0], xmm11
000077a0e99db11a  vmovaps [rsp+0xC0], xmm13
000077a0e99db123  vmovaps [rsp+0xD0], xmm14
000077a0e99db12c  vmovaps [rsp+0xE0], xmm15
000077a0e99db135  sub rsp, 0x40
000077a0e99db139  lea rdi, [rsp]
000077a0e99db13d  lea rsi, [rsp+0x10]
000077a0e99db142  lea rdx, [rsp+0x20]
000077a0e99db147  lea rcx, [rsp+0x30]
000077a0e99db14c  mov r8d, 0x00
000077a0e99db152  lea r9, [r15+0x3A8]
000077a0e99db159  movaps [rdi], xmm12
000077a0e99db15d  movaps [rsi], xmm14
000077a0e99db161  movaps [rdx], xmm3
000077a0e99db164  movaps [rcx], xmm15
000077a0e99db168  mov rax, 0x60CAA235BA50
000077a0e99db172  call rax
000077a0e99db174  movaps xmm12, [rsp]
000077a0e99db179  add rsp, 0x40
000077a0e99db17d  vmovaps xmm0, [rsp]
000077a0e99db182  vmovaps xmm1, [rsp+0x10]
000077a0e99db188  vmovaps xmm2, [rsp+0x20]
000077a0e99db18e  vmovaps xmm3, [rsp+0x30]
000077a0e99db194  vmovaps xmm4, [rsp+0x40]
000077a0e99db19a  vmovaps xmm5, [rsp+0x50]
000077a0e99db1a0  vmovaps xmm6, [rsp+0x60]
000077a0e99db1a6  vmovaps xmm7, [rsp+0x70]
000077a0e99db1ac  vmovaps xmm8, [rsp+0x80]
000077a0e99db1b5  vmovaps xmm9, [rsp+0x90]
000077a0e99db1be  vmovaps xmm10, [rsp+0xA0]
000077a0e99db1c7  vmovaps xmm11, [rsp+0xB0]
000077a0e99db1d0  vmovaps xmm13, [rsp+0xC0]
000077a0e99db1d9  vmovaps xmm14, [rsp+0xD0]
000077a0e99db1e2  vmovaps xmm15, [rsp+0xE0]
000077a0e99db1eb  add rsp, 0xF0
000077a0e99db1f2  pop r11
000077a0e99db1f4  pop r10
000077a0e99db1f6  pop r9
000077a0e99db1f8  pop r8
000077a0e99db1fa  pop rsi
000077a0e99db1fb  pop rdi
000077a0e99db1fc  pop rdx
000077a0e99db1fd  pop rcx
000077a0e99db1fe  pop rax
000077a0e99db1ff  add rsp, 0x08
000077a0e99db203  jmp 0x000077A0E99DA0B3
000077a0e99db208  sub rsp, 0x08
000077a0e99db20c  push rax
000077a0e99db20d  push rcx
000077a0e99db20e  push rdx
000077a0e99db20f  push rdi
000077a0e99db210  push rsi
000077a0e99db211  push r8
000077a0e99db213  push r9
000077a0e99db215  push r10
000077a0e99db217  push r11
000077a0e99db219  sub rsp, 0xF0
000077a0e99db220  vmovaps [rsp], xmm0
000077a0e99db225  vmovaps [rsp+0x10], xmm1
000077a0e99db22b  vmovaps [rsp+0x20], xmm2
000077a0e99db231  vmovaps [rsp+0x30], xmm3
000077a0e99db237  vmovaps [rsp+0x40], xmm4
000077a0e99db23d  vmovaps [rsp+0x50], xmm5
000077a0e99db243  vmovaps [rsp+0x60], xmm6
000077a0e99db249  vmovaps [rsp+0x70], xmm7
000077a0e99db24f  vmovaps [rsp+0x80], xmm8
000077a0e99db258  vmovaps [rsp+0x90], xmm10
000077a0e99db261  vmovaps [rsp+0xA0], xmm11
000077a0e99db26a  vmovaps [rsp+0xB0], xmm12
000077a0e99db273  vmovaps [rsp+0xC0], xmm13
000077a0e99db27c  vmovaps [rsp+0xD0], xmm14
000077a0e99db285  vmovaps [rsp+0xE0], xmm15
000077a0e99db28e  sub rsp, 0x40
000077a0e99db292  lea rdi, [rsp]
000077a0e99db296  lea rsi, [rsp+0x10]
000077a0e99db29b  lea rdx, [rsp+0x20]
000077a0e99db2a0  lea rcx, [rsp+0x30]
000077a0e99db2a5  mov r8d, 0x00
000077a0e99db2ab  lea r9, [r15+0x3A8]
000077a0e99db2b2  movaps [rdi], xmm9
000077a0e99db2b6  movaps [rsi], xmm13
000077a0e99db2ba  movaps [rdx], xmm14
000077a0e99db2be  movaps [rcx], xmm6
000077a0e99db2c1  mov rax, 0x60CAA235BA50
000077a0e99db2cb  call rax
000077a0e99db2cd  movaps xmm9, [rsp]
000077a0e99db2d2  add rsp, 0x40
000077a0e99db2d6  vmovaps xmm0, [rsp]
000077a0e99db2db  vmovaps xmm1, [rsp+0x10]
000077a0e99db2e1  vmovaps xmm2, [rsp+0x20]
000077a0e99db2e7  vmovaps xmm3, [rsp+0x30]
000077a0e99db2ed  vmovaps xmm4, [rsp+0x40]
000077a0e99db2f3  vmovaps xmm5, [rsp+0x50]
000077a0e99db2f9  vmovaps xmm6, [rsp+0x60]
000077a0e99db2ff  vmovaps xmm7, [rsp+0x70]
000077a0e99db305  vmovaps xmm8, [rsp+0x80]
000077a0e99db30e  vmovaps xmm10, [rsp+0x90]
000077a0e99db317  vmovaps xmm11, [rsp+0xA0]
000077a0e99db320  vmovaps xmm12, [rsp+0xB0]
000077a0e99db329  vmovaps xmm13, [rsp+0xC0]
000077a0e99db332  vmovaps xmm14, [rsp+0xD0]
000077a0e99db33b  vmovaps xmm15, [rsp+0xE0]
000077a0e99db344  add rsp, 0xF0
000077a0e99db34b  pop r11
000077a0e99db34d  pop r10
000077a0e99db34f  pop r9
000077a0e99db351  pop r8
000077a0e99db353  pop rsi
000077a0e99db354  pop rdi
000077a0e99db355  pop rdx
000077a0e99db356  pop rcx
000077a0e99db357  pop rax
000077a0e99db358  add rsp, 0x08
000077a0e99db35c  jmp 0x000077A0E99DA15D
000077a0e99db361  sub rsp, 0x08
000077a0e99db365  push rax
000077a0e99db366  push rcx
000077a0e99db367  push rdx
000077a0e99db368  push rdi
000077a0e99db369  push rsi
000077a0e99db36a  push r8
000077a0e99db36c  push r9
000077a0e99db36e  push r10
000077a0e99db370  push r11
000077a0e99db372  sub rsp, 0xF0
000077a0e99db379  vmovaps [rsp], xmm0
000077a0e99db37e  vmovaps [rsp+0x10], xmm1
000077a0e99db384  vmovaps [rsp+0x20], xmm2
000077a0e99db38a  vmovaps [rsp+0x30], xmm4
000077a0e99db390  vmovaps [rsp+0x40], xmm5
000077a0e99db396  vmovaps [rsp+0x50], xmm6
000077a0e99db39c  vmovaps [rsp+0x60], xmm7
000077a0e99db3a2  vmovaps [rsp+0x70], xmm8
000077a0e99db3a8  vmovaps [rsp+0x80], xmm9
000077a0e99db3b1  vmovaps [rsp+0x90], xmm10
000077a0e99db3ba  vmovaps [rsp+0xA0], xmm11
000077a0e99db3c3  vmovaps [rsp+0xB0], xmm12
000077a0e99db3cc  vmovaps [rsp+0xC0], xmm13
000077a0e99db3d5  vmovaps [rsp+0xD0], xmm14
000077a0e99db3de  vmovaps [rsp+0xE0], xmm15
000077a0e99db3e7  sub rsp, 0x40
000077a0e99db3eb  lea rdi, [rsp]
000077a0e99db3ef  lea rsi, [rsp+0x10]
000077a0e99db3f4  lea rdx, [rsp+0x20]
000077a0e99db3f9  lea rcx, [rsp+0x30]
000077a0e99db3fe  mov r8d, 0x00
000077a0e99db404  lea r9, [r15+0x3A8]
000077a0e99db40b  movaps [rdi], xmm3
000077a0e99db40e  movaps [rsi], xmm13
000077a0e99db412  movaps [rdx], xmm6
000077a0e99db415  movaps [rcx], xmm14
000077a0e99db419  mov rax, 0x60CAA235BA50
000077a0e99db423  call rax
000077a0e99db425  movaps xmm3, [rsp]
000077a0e99db429  add rsp, 0x40
000077a0e99db42d  vmovaps xmm0, [rsp]
000077a0e99db432  vmovaps xmm1, [rsp+0x10]
000077a0e99db438  vmovaps xmm2, [rsp+0x20]
000077a0e99db43e  vmovaps xmm4, [rsp+0x30]
000077a0e99db444  vmovaps xmm5, [rsp+0x40]
000077a0e99db44a  vmovaps xmm6, [rsp+0x50]
000077a0e99db450  vmovaps xmm7, [rsp+0x60]
000077a0e99db456  vmovaps xmm8, [rsp+0x70]
000077a0e99db45c  vmovaps xmm9, [rsp+0x80]
000077a0e99db465  vmovaps xmm10, [rsp+0x90]
000077a0e99db46e  vmovaps xmm11, [rsp+0xA0]
000077a0e99db477  vmovaps xmm12, [rsp+0xB0]
000077a0e99db480  vmovaps xmm13, [rsp+0xC0]
000077a0e99db489  vmovaps xmm14, [rsp+0xD0]
000077a0e99db492  vmovaps xmm15, [rsp+0xE0]
000077a0e99db49b  add rsp, 0xF0
000077a0e99db4a2  pop r11
000077a0e99db4a4  pop r10
000077a0e99db4a6  pop r9
000077a0e99db4a8  pop r8
000077a0e99db4aa  pop rsi
000077a0e99db4ab  pop rdi
000077a0e99db4ac  pop rdx
000077a0e99db4ad  pop rcx
000077a0e99db4ae  pop rax
000077a0e99db4af  add rsp, 0x08
000077a0e99db4b3  jmp 0x000077A0E99DA19A
000077a0e99db4b8  sub rsp, 0x08
000077a0e99db4bc  push rax
000077a0e99db4bd  push rcx
000077a0e99db4be  push rdx
000077a0e99db4bf  push rdi
000077a0e99db4c0  push rsi
000077a0e99db4c1  push r8
000077a0e99db4c3  push r9
000077a0e99db4c5  push r10
000077a0e99db4c7  push r11
000077a0e99db4c9  sub rsp, 0xF0
000077a0e99db4d0  vmovaps [rsp], xmm0
000077a0e99db4d5  vmovaps [rsp+0x10], xmm1
000077a0e99db4db  vmovaps [rsp+0x20], xmm2
000077a0e99db4e1  vmovaps [rsp+0x30], xmm3
000077a0e99db4e7  vmovaps [rsp+0x40], xmm4
000077a0e99db4ed  vmovaps [rsp+0x50], xmm5
000077a0e99db4f3  vmovaps [rsp+0x60], xmm7
000077a0e99db4f9  vmovaps [rsp+0x70], xmm8
000077a0e99db4ff  vmovaps [rsp+0x80], xmm9
000077a0e99db508  vmovaps [rsp+0x90], xmm10
000077a0e99db511  vmovaps [rsp+0xA0], xmm11
000077a0e99db51a  vmovaps [rsp+0xB0], xmm12
000077a0e99db523  vmovaps [rsp+0xC0], xmm13
000077a0e99db52c  vmovaps [rsp+0xD0], xmm14
000077a0e99db535  vmovaps [rsp+0xE0], xmm15
000077a0e99db53e  sub rsp, 0x40
000077a0e99db542  lea rdi, [rsp]
000077a0e99db546  lea rsi, [rsp+0x10]
000077a0e99db54b  lea rdx, [rsp+0x20]
000077a0e99db550  lea rcx, [rsp+0x30]
000077a0e99db555  mov r8d, 0x00
000077a0e99db55b  lea r9, [r15+0x3A8]
000077a0e99db562  movaps [rdi], xmm6
000077a0e99db565  movaps [rsi], xmm2
000077a0e99db568  movaps [rdx], xmm14
000077a0e99db56c  movaps [rcx], xmm1
000077a0e99db56f  mov rax, 0x60CAA235BA50
000077a0e99db579  call rax
000077a0e99db57b  movaps xmm6, [rsp]
000077a0e99db57f  add rsp, 0x40
000077a0e99db583  vmovaps xmm0, [rsp]
000077a0e99db588  vmovaps xmm1, [rsp+0x10]
000077a0e99db58e  vmovaps xmm2, [rsp+0x20]
000077a0e99db594  vmovaps xmm3, [rsp+0x30]
000077a0e99db59a  vmovaps xmm4, [rsp+0x40]
000077a0e99db5a0  vmovaps xmm5, [rsp+0x50]
000077a0e99db5a6  vmovaps xmm7, [rsp+0x60]
000077a0e99db5ac  vmovaps xmm8, [rsp+0x70]
000077a0e99db5b2  vmovaps xmm9, [rsp+0x80]
000077a0e99db5bb  vmovaps xmm10, [rsp+0x90]
000077a0e99db5c4  vmovaps xmm11, [rsp+0xA0]
000077a0e99db5cd  vmovaps xmm12, [rsp+0xB0]
000077a0e99db5d6  vmovaps xmm13, [rsp+0xC0]
000077a0e99db5df  vmovaps xmm14, [rsp+0xD0]
000077a0e99db5e8  vmovaps xmm15, [rsp+0xE0]
000077a0e99db5f1  add rsp, 0xF0
000077a0e99db5f8  pop r11
000077a0e99db5fa  pop r10
000077a0e99db5fc  pop r9
000077a0e99db5fe  pop r8
000077a0e99db600  pop rsi
000077a0e99db601  pop rdi
000077a0e99db602  pop rdx
000077a0e99db603  pop rcx
000077a0e99db604  pop rax
000077a0e99db605  add rsp, 0x08
000077a0e99db609  jmp 0x000077A0E99DA1C7
000077a0e99db60e  sub rsp, 0x08
000077a0e99db612  push rax
000077a0e99db613  push rcx
000077a0e99db614  push rdx
000077a0e99db615  push rdi
000077a0e99db616  push rsi
000077a0e99db617  push r8
000077a0e99db619  push r9
000077a0e99db61b  push r10
000077a0e99db61d  push r11
000077a0e99db61f  sub rsp, 0xF0
000077a0e99db626  vmovaps [rsp], xmm0
000077a0e99db62b  vmovaps [rsp+0x10], xmm1
000077a0e99db631  vmovaps [rsp+0x20], xmm2
000077a0e99db637  vmovaps [rsp+0x30], xmm3
000077a0e99db63d  vmovaps [rsp+0x40], xmm4
000077a0e99db643  vmovaps [rsp+0x50], xmm5
000077a0e99db649  vmovaps [rsp+0x60], xmm6
000077a0e99db64f  vmovaps [rsp+0x70], xmm7
000077a0e99db655  vmovaps [rsp+0x80], xmm8
000077a0e99db65e  vmovaps [rsp+0x90], xmm9
000077a0e99db667  vmovaps [rsp+0xA0], xmm10
000077a0e99db670  vmovaps [rsp+0xB0], xmm11
000077a0e99db679  vmovaps [rsp+0xC0], xmm12
000077a0e99db682  vmovaps [rsp+0xD0], xmm14
000077a0e99db68b  vmovaps [rsp+0xE0], xmm15
000077a0e99db694  sub rsp, 0x40
000077a0e99db698  lea rdi, [rsp]
000077a0e99db69c  lea rsi, [rsp+0x10]
000077a0e99db6a1  lea rdx, [rsp+0x20]
000077a0e99db6a6  lea rcx, [rsp+0x30]
000077a0e99db6ab  mov r8d, 0x00
000077a0e99db6b1  lea r9, [r15+0x3A8]
000077a0e99db6b8  movaps [rdi], xmm13
000077a0e99db6bc  movaps [rsi], xmm12
000077a0e99db6c0  movaps [rdx], xmm14
000077a0e99db6c4  movaps [rcx], xmm1
000077a0e99db6c7  mov rax, 0x60CAA235BA50
000077a0e99db6d1  call rax
000077a0e99db6d3  movaps xmm13, [rsp]
000077a0e99db6d8  add rsp, 0x40
000077a0e99db6dc  vmovaps xmm0, [rsp]
000077a0e99db6e1  vmovaps xmm1, [rsp+0x10]
000077a0e99db6e7  vmovaps xmm2, [rsp+0x20]
000077a0e99db6ed  vmovaps xmm3, [rsp+0x30]
000077a0e99db6f3  vmovaps xmm4, [rsp+0x40]
000077a0e99db6f9  vmovaps xmm5, [rsp+0x50]
000077a0e99db6ff  vmovaps xmm6, [rsp+0x60]
000077a0e99db705  vmovaps xmm7, [rsp+0x70]
000077a0e99db70b  vmovaps xmm8, [rsp+0x80]
000077a0e99db714  vmovaps xmm9, [rsp+0x90]
000077a0e99db71d  vmovaps xmm10, [rsp+0xA0]
000077a0e99db726  vmovaps xmm11, [rsp+0xB0]
000077a0e99db72f  vmovaps xmm12, [rsp+0xC0]
000077a0e99db738  vmovaps xmm14, [rsp+0xD0]
000077a0e99db741  vmovaps xmm15, [rsp+0xE0]
000077a0e99db74a  add rsp, 0xF0
000077a0e99db751  pop r11
000077a0e99db753  pop r10
000077a0e99db755  pop r9
000077a0e99db757  pop r8
000077a0e99db759  pop rsi
000077a0e99db75a  pop rdi
000077a0e99db75b  pop rdx
000077a0e99db75c  pop rcx
000077a0e99db75d  pop rax
000077a0e99db75e  add rsp, 0x08
000077a0e99db762  jmp 0x000077A0E99DA1F9
000077a0e99db767  sub rsp, 0x08
000077a0e99db76b  push rax
000077a0e99db76c  push rcx
000077a0e99db76d  push rdx
000077a0e99db76e  push rdi
000077a0e99db76f  push rsi
000077a0e99db770  push r8
000077a0e99db772  push r9
000077a0e99db774  push r10
000077a0e99db776  push r11
000077a0e99db778  sub rsp, 0xF0
000077a0e99db77f  vmovaps [rsp], xmm0
000077a0e99db784  vmovaps [rsp+0x10], xmm1
000077a0e99db78a  vmovaps [rsp+0x20], xmm2
000077a0e99db790  vmovaps [rsp+0x30], xmm3
000077a0e99db796  vmovaps [rsp+0x40], xmm4
000077a0e99db79c  vmovaps [rsp+0x50], xmm5
000077a0e99db7a2  vmovaps [rsp+0x60], xmm6
000077a0e99db7a8  vmovaps [rsp+0x70], xmm7
000077a0e99db7ae  vmovaps [rsp+0x80], xmm8
000077a0e99db7b7  vmovaps [rsp+0x90], xmm9
000077a0e99db7c0  vmovaps [rsp+0xA0], xmm10
000077a0e99db7c9  vmovaps [rsp+0xB0], xmm11
000077a0e99db7d2  vmovaps [rsp+0xC0], xmm13
000077a0e99db7db  vmovaps [rsp+0xD0], xmm14
000077a0e99db7e4  vmovaps [rsp+0xE0], xmm15
000077a0e99db7ed  sub rsp, 0x40
000077a0e99db7f1  lea rdi, [rsp]
000077a0e99db7f5  lea rsi, [rsp+0x10]
000077a0e99db7fa  lea rdx, [rsp+0x20]
000077a0e99db7ff  lea rcx, [rsp+0x30]
000077a0e99db804  mov r8d, 0x00
000077a0e99db80a  lea r9, [r15+0x3A8]
000077a0e99db811  movaps [rdi], xmm12
000077a0e99db815  movaps [rsi], xmm3
000077a0e99db818  movaps [rdx], xmm14
000077a0e99db81c  movaps [rcx], xmm5
000077a0e99db81f  mov rax, 0x60CAA235BA50
000077a0e99db829  call rax
000077a0e99db82b  movaps xmm12, [rsp]
000077a0e99db830  add rsp, 0x40
000077a0e99db834  vmovaps xmm0, [rsp]
000077a0e99db839  vmovaps xmm1, [rsp+0x10]
000077a0e99db83f  vmovaps xmm2, [rsp+0x20]
000077a0e99db845  vmovaps xmm3, [rsp+0x30]
000077a0e99db84b  vmovaps xmm4, [rsp+0x40]
000077a0e99db851  vmovaps xmm5, [rsp+0x50]
000077a0e99db857  vmovaps xmm6, [rsp+0x60]
000077a0e99db85d  vmovaps xmm7, [rsp+0x70]
000077a0e99db863  vmovaps xmm8, [rsp+0x80]
000077a0e99db86c  vmovaps xmm9, [rsp+0x90]
000077a0e99db875  vmovaps xmm10, [rsp+0xA0]
000077a0e99db87e  vmovaps xmm11, [rsp+0xB0]
000077a0e99db887  vmovaps xmm13, [rsp+0xC0]
000077a0e99db890  vmovaps xmm14, [rsp+0xD0]
000077a0e99db899  vmovaps xmm15, [rsp+0xE0]
000077a0e99db8a2  add rsp, 0xF0
000077a0e99db8a9  pop r11
000077a0e99db8ab  pop r10
000077a0e99db8ad  pop r9
000077a0e99db8af  pop r8
000077a0e99db8b1  pop rsi
000077a0e99db8b2  pop rdi
000077a0e99db8b3  pop rdx
000077a0e99db8b4  pop rcx
000077a0e99db8b5  pop rax
000077a0e99db8b6  add rsp, 0x08
000077a0e99db8ba  jmp 0x000077A0E99DA256
000077a0e99db8bf  sub rsp, 0x08
000077a0e99db8c3  push rax
000077a0e99db8c4  push rcx
000077a0e99db8c5  push rdx
000077a0e99db8c6  push rdi
000077a0e99db8c7  push rsi
000077a0e99db8c8  push r8
000077a0e99db8ca  push r9
000077a0e99db8cc  push r10
000077a0e99db8ce  push r11
000077a0e99db8d0  sub rsp, 0xF0
000077a0e99db8d7  vmovaps [rsp], xmm0
000077a0e99db8dc  vmovaps [rsp+0x10], xmm1
000077a0e99db8e2  vmovaps [rsp+0x20], xmm2
000077a0e99db8e8  vmovaps [rsp+0x30], xmm3
000077a0e99db8ee  vmovaps [rsp+0x40], xmm4
000077a0e99db8f4  vmovaps [rsp+0x50], xmm5
000077a0e99db8fa  vmovaps [rsp+0x60], xmm6
000077a0e99db900  vmovaps [rsp+0x70], xmm7
000077a0e99db906  vmovaps [rsp+0x80], xmm8
000077a0e99db90f  vmovaps [rsp+0x90], xmm9
000077a0e99db918  vmovaps [rsp+0xA0], xmm11
000077a0e99db921  vmovaps [rsp+0xB0], xmm12
000077a0e99db92a  vmovaps [rsp+0xC0], xmm13
000077a0e99db933  vmovaps [rsp+0xD0], xmm14
000077a0e99db93c  vmovaps [rsp+0xE0], xmm15
000077a0e99db945  sub rsp, 0x40
000077a0e99db949  lea rdi, [rsp]
000077a0e99db94d  lea rsi, [rsp+0x10]
000077a0e99db952  lea rdx, [rsp+0x20]
000077a0e99db957  lea rcx, [rsp+0x30]
000077a0e99db95c  mov r8d, 0x00
000077a0e99db962  lea r9, [r15+0x3A8]
000077a0e99db969  movaps [rdi], xmm10
000077a0e99db96d  movaps [rsi], xmm9
000077a0e99db971  movaps [rdx], xmm7
000077a0e99db974  movaps [rcx], xmm14
000077a0e99db978  mov rax, 0x60CAA235BA50
000077a0e99db982  call rax
000077a0e99db984  movaps xmm10, [rsp]
000077a0e99db989  add rsp, 0x40
000077a0e99db98d  vmovaps xmm0, [rsp]
000077a0e99db992  vmovaps xmm1, [rsp+0x10]
000077a0e99db998  vmovaps xmm2, [rsp+0x20]
000077a0e99db99e  vmovaps xmm3, [rsp+0x30]
000077a0e99db9a4  vmovaps xmm4, [rsp+0x40]
000077a0e99db9aa  vmovaps xmm5, [rsp+0x50]
000077a0e99db9b0  vmovaps xmm6, [rsp+0x60]
000077a0e99db9b6  vmovaps xmm7, [rsp+0x70]
000077a0e99db9bc  vmovaps xmm8, [rsp+0x80]
000077a0e99db9c5  vmovaps xmm9, [rsp+0x90]
000077a0e99db9ce  vmovaps xmm11, [rsp+0xA0]
000077a0e99db9d7  vmovaps xmm12, [rsp+0xB0]
000077a0e99db9e0  vmovaps xmm13, [rsp+0xC0]
000077a0e99db9e9  vmovaps xmm14, [rsp+0xD0]
000077a0e99db9f2  vmovaps xmm15, [rsp+0xE0]
000077a0e99db9fb  add rsp, 0xF0
000077a0e99dba02  pop r11
000077a0e99dba04  pop r10
000077a0e99dba06  pop r9
000077a0e99dba08  pop r8
000077a0e99dba0a  pop rsi
000077a0e99dba0b  pop rdi
000077a0e99dba0c  pop rdx
000077a0e99dba0d  pop rcx
000077a0e99dba0e  pop rax
000077a0e99dba0f  add rsp, 0x08
000077a0e99dba13  jmp 0x000077A0E99DA27C
000077a0e99dba18  call 0x000077A0E980D4E0
000077a0e99dba1d  jmp 0x000077A0E99DA289
000077a0e99dba22  sub rsp, 0x08
000077a0e99dba26  push rax
000077a0e99dba27  push rcx
000077a0e99dba28  push rdx
000077a0e99dba29  push rdi
000077a0e99dba2a  push rsi
000077a0e99dba2b  push r8
000077a0e99dba2d  push r9
000077a0e99dba2f  push r10
000077a0e99dba31  push r11
000077a0e99dba33  sub rsp, 0xF0
000077a0e99dba3a  vmovaps [rsp], xmm0
000077a0e99dba3f  vmovaps [rsp+0x10], xmm1
000077a0e99dba45  vmovaps [rsp+0x20], xmm2
000077a0e99dba4b  vmovaps [rsp+0x30], xmm3
000077a0e99dba51  vmovaps [rsp+0x40], xmm4
000077a0e99dba57  vmovaps [rsp+0x50], xmm6
000077a0e99dba5d  vmovaps [rsp+0x60], xmm7
000077a0e99dba63  vmovaps [rsp+0x70], xmm8
000077a0e99dba69  vmovaps [rsp+0x80], xmm9
000077a0e99dba72  vmovaps [rsp+0x90], xmm10
000077a0e99dba7b  vmovaps [rsp+0xA0], xmm11
000077a0e99dba84  vmovaps [rsp+0xB0], xmm12
000077a0e99dba8d  vmovaps [rsp+0xC0], xmm13
000077a0e99dba96  vmovaps [rsp+0xD0], xmm14
000077a0e99dba9f  vmovaps [rsp+0xE0], xmm15
000077a0e99dbaa8  sub rsp, 0x40
000077a0e99dbaac  lea rdi, [rsp]
000077a0e99dbab0  lea rsi, [rsp+0x10]
000077a0e99dbab5  lea rdx, [rsp+0x20]
000077a0e99dbaba  lea rcx, [rsp+0x30]
000077a0e99dbabf  mov r8d, 0x00
000077a0e99dbac5  lea r9, [r15+0x3A8]
000077a0e99dbacc  movaps [rdi], xmm5
000077a0e99dbacf  movaps [rsi], xmm6
000077a0e99dbad2  movaps [rdx], xmm7
000077a0e99dbad5  movaps [rcx], xmm9
000077a0e99dbad9  mov rax, 0x60CAA235BA50
000077a0e99dbae3  call rax
000077a0e99dbae5  movaps xmm5, [rsp]
000077a0e99dbae9  add rsp, 0x40
000077a0e99dbaed  vmovaps xmm0, [rsp]
000077a0e99dbaf2  vmovaps xmm1, [rsp+0x10]
000077a0e99dbaf8  vmovaps xmm2, [rsp+0x20]
000077a0e99dbafe  vmovaps xmm3, [rsp+0x30]
000077a0e99dbb04  vmovaps xmm4, [rsp+0x40]
000077a0e99dbb0a  vmovaps xmm6, [rsp+0x50]
000077a0e99dbb10  vmovaps xmm7, [rsp+0x60]
000077a0e99dbb16  vmovaps xmm8, [rsp+0x70]
000077a0e99dbb1c  vmovaps xmm9, [rsp+0x80]
000077a0e99dbb25  vmovaps xmm10, [rsp+0x90]
000077a0e99dbb2e  vmovaps xmm11, [rsp+0xA0]
000077a0e99dbb37  vmovaps xmm12, [rsp+0xB0]
000077a0e99dbb40  vmovaps xmm13, [rsp+0xC0]
000077a0e99dbb49  vmovaps xmm14, [rsp+0xD0]
000077a0e99dbb52  vmovaps xmm15, [rsp+0xE0]
000077a0e99dbb5b  add rsp, 0xF0
000077a0e99dbb62  pop r11
000077a0e99dbb64  pop r10
000077a0e99dbb66  pop r9
000077a0e99dbb68  pop r8
000077a0e99dbb6a  pop rsi
000077a0e99dbb6b  pop rdi
000077a0e99dbb6c  pop rdx
000077a0e99dbb6d  pop rcx
000077a0e99dbb6e  pop rax
000077a0e99dbb6f  add rsp, 0x08
000077a0e99dbb73  jmp 0x000077A0E99DA2BB
000077a0e99dbb78  sub rsp, 0x08
000077a0e99dbb7c  push rax
000077a0e99dbb7d  push rcx
000077a0e99dbb7e  push rdx
000077a0e99dbb7f  push rdi
000077a0e99dbb80  push rsi
000077a0e99dbb81  push r8
000077a0e99dbb83  push r9
000077a0e99dbb85  push r10
000077a0e99dbb87  push r11
000077a0e99dbb89  sub rsp, 0xF0
000077a0e99dbb90  vmovaps [rsp], xmm0
000077a0e99dbb95  vmovaps [rsp+0x10], xmm1
000077a0e99dbb9b  vmovaps [rsp+0x20], xmm2
000077a0e99dbba1  vmovaps [rsp+0x30], xmm3
000077a0e99dbba7  vmovaps [rsp+0x40], xmm4
000077a0e99dbbad  vmovaps [rsp+0x50], xmm5
000077a0e99dbbb3  vmovaps [rsp+0x60], xmm6
000077a0e99dbbb9  vmovaps [rsp+0x70], xmm8
000077a0e99dbbbf  vmovaps [rsp+0x80], xmm9
000077a0e99dbbc8  vmovaps [rsp+0x90], xmm10
000077a0e99dbbd1  vmovaps [rsp+0xA0], xmm11
000077a0e99dbbda  vmovaps [rsp+0xB0], xmm12
000077a0e99dbbe3  vmovaps [rsp+0xC0], xmm13
000077a0e99dbbec  vmovaps [rsp+0xD0], xmm14
000077a0e99dbbf5  vmovaps [rsp+0xE0], xmm15
000077a0e99dbbfe  sub rsp, 0x40
000077a0e99dbc02  lea rdi, [rsp]
000077a0e99dbc06  lea rsi, [rsp+0x10]
000077a0e99dbc0b  lea rdx, [rsp+0x20]
000077a0e99dbc10  lea rcx, [rsp+0x30]
000077a0e99dbc15  mov r8d, 0x00
000077a0e99dbc1b  lea r9, [r15+0x3A8]
000077a0e99dbc22  movaps [rdi], xmm7
000077a0e99dbc25  movaps [rsi], xmm13
000077a0e99dbc29  movaps [rdx], xmm1
000077a0e99dbc2c  movaps [rcx], xmm9
000077a0e99dbc30  mov rax, 0x60CAA235BA50
000077a0e99dbc3a  call rax
000077a0e99dbc3c  movaps xmm7, [rsp]
000077a0e99dbc40  add rsp, 0x40
000077a0e99dbc44  vmovaps xmm0, [rsp]
000077a0e99dbc49  vmovaps xmm1, [rsp+0x10]
000077a0e99dbc4f  vmovaps xmm2, [rsp+0x20]
000077a0e99dbc55  vmovaps xmm3, [rsp+0x30]
000077a0e99dbc5b  vmovaps xmm4, [rsp+0x40]
000077a0e99dbc61  vmovaps xmm5, [rsp+0x50]
000077a0e99dbc67  vmovaps xmm6, [rsp+0x60]
000077a0e99dbc6d  vmovaps xmm8, [rsp+0x70]
000077a0e99dbc73  vmovaps xmm9, [rsp+0x80]
000077a0e99dbc7c  vmovaps xmm10, [rsp+0x90]
000077a0e99dbc85  vmovaps xmm11, [rsp+0xA0]
000077a0e99dbc8e  vmovaps xmm12, [rsp+0xB0]
000077a0e99dbc97  vmovaps xmm13, [rsp+0xC0]
000077a0e99dbca0  vmovaps xmm14, [rsp+0xD0]
000077a0e99dbca9  vmovaps xmm15, [rsp+0xE0]
000077a0e99dbcb2  add rsp, 0xF0
000077a0e99dbcb9  pop r11
000077a0e99dbcbb  pop r10
000077a0e99dbcbd  pop r9
000077a0e99dbcbf  pop r8
000077a0e99dbcc1  pop rsi
000077a0e99dbcc2  pop rdi
000077a0e99dbcc3  pop rdx
000077a0e99dbcc4  pop rcx
000077a0e99dbcc5  pop rax
000077a0e99dbcc6  add rsp, 0x08
000077a0e99dbcca  jmp 0x000077A0E99DA2E0
000077a0e99dbccf  call 0x000077A0E980C260
000077a0e99dbcd4  jmp 0x000077A0E99DA303
000077a0e99dbcd9  call 0x000077A0E9807890
000077a0e99dbcde  jmp 0x000077A0E99DA30D
000077a0e99dbce3  sub rsp, 0x08
000077a0e99dbce7  push rax
000077a0e99dbce8  push rcx
000077a0e99dbce9  push rdx
000077a0e99dbcea  push rdi
000077a0e99dbceb  push rsi
000077a0e99dbcec  push r8
000077a0e99dbcee  push r9
000077a0e99dbcf0  push r10
000077a0e99dbcf2  push r11
000077a0e99dbcf4  sub rsp, 0xF0
000077a0e99dbcfb  vmovaps [rsp], xmm0
000077a0e99dbd00  vmovaps [rsp+0x10], xmm1
000077a0e99dbd06  vmovaps [rsp+0x20], xmm3
000077a0e99dbd0c  vmovaps [rsp+0x30], xmm4
000077a0e99dbd12  vmovaps [rsp+0x40], xmm5
000077a0e99dbd18  vmovaps [rsp+0x50], xmm6
000077a0e99dbd1e  vmovaps [rsp+0x60], xmm7
000077a0e99dbd24  vmovaps [rsp+0x70], xmm8
000077a0e99dbd2a  vmovaps [rsp+0x80], xmm9
000077a0e99dbd33  vmovaps [rsp+0x90], xmm10
000077a0e99dbd3c  vmovaps [rsp+0xA0], xmm11
000077a0e99dbd45  vmovaps [rsp+0xB0], xmm12
000077a0e99dbd4e  vmovaps [rsp+0xC0], xmm13
000077a0e99dbd57  vmovaps [rsp+0xD0], xmm14
000077a0e99dbd60  vmovaps [rsp+0xE0], xmm15
000077a0e99dbd69  sub rsp, 0x40
000077a0e99dbd6d  lea rdi, [rsp]
000077a0e99dbd71  lea rsi, [rsp+0x10]
000077a0e99dbd76  lea rdx, [rsp+0x20]
000077a0e99dbd7b  lea rcx, [rsp+0x30]
000077a0e99dbd80  mov r8d, 0x00
000077a0e99dbd86  lea r9, [r15+0x3A8]
000077a0e99dbd8d  movaps [rdi], xmm2
000077a0e99dbd90  movaps [rsi], xmm12
000077a0e99dbd94  movaps [rdx], xmm6
000077a0e99dbd97  movaps [rcx], xmm3
000077a0e99dbd9a  mov rax, 0x60CAA235BA50
000077a0e99dbda4  call rax
000077a0e99dbda6  movaps xmm2, [rsp]
000077a0e99dbdaa  add rsp, 0x40
000077a0e99dbdae  vmovaps xmm0, [rsp]
000077a0e99dbdb3  vmovaps xmm1, [rsp+0x10]
000077a0e99dbdb9  vmovaps xmm3, [rsp+0x20]
000077a0e99dbdbf  vmovaps xmm4, [rsp+0x30]
000077a0e99dbdc5  vmovaps xmm5, [rsp+0x40]
000077a0e99dbdcb  vmovaps xmm6, [rsp+0x50]
000077a0e99dbdd1  vmovaps xmm7, [rsp+0x60]
000077a0e99dbdd7  vmovaps xmm8, [rsp+0x70]
000077a0e99dbddd  vmovaps xmm9, [rsp+0x80]
000077a0e99dbde6  vmovaps xmm10, [rsp+0x90]
000077a0e99dbdef  vmovaps xmm11, [rsp+0xA0]
000077a0e99dbdf8  vmovaps xmm12, [rsp+0xB0]
000077a0e99dbe01  vmovaps xmm13, [rsp+0xC0]
000077a0e99dbe0a  vmovaps xmm14, [rsp+0xD0]
000077a0e99dbe13  vmovaps xmm15, [rsp+0xE0]
000077a0e99dbe1c  add rsp, 0xF0
000077a0e99dbe23  pop r11
000077a0e99dbe25  pop r10
000077a0e99dbe27  pop r9
000077a0e99dbe29  pop r8
000077a0e99dbe2b  pop rsi
000077a0e99dbe2c  pop rdi
000077a0e99dbe2d  pop rdx
000077a0e99dbe2e  pop rcx
000077a0e99dbe2f  pop rax
000077a0e99dbe30  add rsp, 0x08
000077a0e99dbe34  jmp 0x000077A0E99DA353
000077a0e99dbe39  sub rsp, 0x08
000077a0e99dbe3d  push rax
000077a0e99dbe3e  push rcx
000077a0e99dbe3f  push rdx
000077a0e99dbe40  push rdi
000077a0e99dbe41  push rsi
000077a0e99dbe42  push r8
000077a0e99dbe44  push r9
000077a0e99dbe46  push r10
000077a0e99dbe48  push r11
000077a0e99dbe4a  sub rsp, 0xF0
000077a0e99dbe51  vmovaps [rsp], xmm0
000077a0e99dbe56  vmovaps [rsp+0x10], xmm1
000077a0e99dbe5c  vmovaps [rsp+0x20], xmm2
000077a0e99dbe62  vmovaps [rsp+0x30], xmm3
000077a0e99dbe68  vmovaps [rsp+0x40], xmm4
000077a0e99dbe6e  vmovaps [rsp+0x50], xmm5
000077a0e99dbe74  vmovaps [rsp+0x60], xmm7
000077a0e99dbe7a  vmovaps [rsp+0x70], xmm8
000077a0e99dbe80  vmovaps [rsp+0x80], xmm9
000077a0e99dbe89  vmovaps [rsp+0x90], xmm10
000077a0e99dbe92  vmovaps [rsp+0xA0], xmm11
000077a0e99dbe9b  vmovaps [rsp+0xB0], xmm12
000077a0e99dbea4  vmovaps [rsp+0xC0], xmm13
000077a0e99dbead  vmovaps [rsp+0xD0], xmm14
000077a0e99dbeb6  vmovaps [rsp+0xE0], xmm15
000077a0e99dbebf  sub rsp, 0x40
000077a0e99dbec3  lea rdi, [rsp]
000077a0e99dbec7  lea rsi, [rsp+0x10]
000077a0e99dbecc  lea rdx, [rsp+0x20]
000077a0e99dbed1  lea rcx, [rsp+0x30]
000077a0e99dbed6  mov r8d, 0x00
000077a0e99dbedc  lea r9, [r15+0x3A8]
000077a0e99dbee3  movaps [rdi], xmm6
000077a0e99dbee6  movaps [rsi], xmm10
000077a0e99dbeea  movaps [rdx], xmm12
000077a0e99dbeee  movaps [rcx], xmm1
000077a0e99dbef1  mov rax, 0x60CAA235BA50
000077a0e99dbefb  call rax
000077a0e99dbefd  movaps xmm6, [rsp]
000077a0e99dbf01  add rsp, 0x40
000077a0e99dbf05  vmovaps xmm0, [rsp]
000077a0e99dbf0a  vmovaps xmm1, [rsp+0x10]
000077a0e99dbf10  vmovaps xmm2, [rsp+0x20]
000077a0e99dbf16  vmovaps xmm3, [rsp+0x30]
000077a0e99dbf1c  vmovaps xmm4, [rsp+0x40]
000077a0e99dbf22  vmovaps xmm5, [rsp+0x50]
000077a0e99dbf28  vmovaps xmm7, [rsp+0x60]
000077a0e99dbf2e  vmovaps xmm8, [rsp+0x70]
000077a0e99dbf34  vmovaps xmm9, [rsp+0x80]
000077a0e99dbf3d  vmovaps xmm10, [rsp+0x90]
000077a0e99dbf46  vmovaps xmm11, [rsp+0xA0]
000077a0e99dbf4f  vmovaps xmm12, [rsp+0xB0]
000077a0e99dbf58  vmovaps xmm13, [rsp+0xC0]
000077a0e99dbf61  vmovaps xmm14, [rsp+0xD0]
000077a0e99dbf6a  vmovaps xmm15, [rsp+0xE0]
000077a0e99dbf73  add rsp, 0xF0
000077a0e99dbf7a  pop r11
000077a0e99dbf7c  pop r10
000077a0e99dbf7e  pop r9
000077a0e99dbf80  pop r8
000077a0e99dbf82  pop rsi
000077a0e99dbf83  pop rdi
000077a0e99dbf84  pop rdx
000077a0e99dbf85  pop rcx
000077a0e99dbf86  pop rax
000077a0e99dbf87  add rsp, 0x08
000077a0e99dbf8b  jmp 0x000077A0E99DA381
000077a0e99dbf90  sub rsp, 0x08
000077a0e99dbf94  push rax
000077a0e99dbf95  push rcx
000077a0e99dbf96  push rdx
000077a0e99dbf97  push rdi
000077a0e99dbf98  push rsi
000077a0e99dbf99  push r8
000077a0e99dbf9b  push r9
000077a0e99dbf9d  push r10
000077a0e99dbf9f  push r11
000077a0e99dbfa1  sub rsp, 0xF0
000077a0e99dbfa8  vmovaps [rsp], xmm0
000077a0e99dbfad  vmovaps [rsp+0x10], xmm1
000077a0e99dbfb3  vmovaps [rsp+0x20], xmm2
000077a0e99dbfb9  vmovaps [rsp+0x30], xmm3
000077a0e99dbfbf  vmovaps [rsp+0x40], xmm4
000077a0e99dbfc5  vmovaps [rsp+0x50], xmm5
000077a0e99dbfcb  vmovaps [rsp+0x60], xmm6
000077a0e99dbfd1  vmovaps [rsp+0x70], xmm7
000077a0e99dbfd7  vmovaps [rsp+0x80], xmm8
000077a0e99dbfe0  vmovaps [rsp+0x90], xmm9
000077a0e99dbfe9  vmovaps [rsp+0xA0], xmm11
000077a0e99dbff2  vmovaps [rsp+0xB0], xmm12
000077a0e99dbffb  vmovaps [rsp+0xC0], xmm13
000077a0e99dc004  vmovaps [rsp+0xD0], xmm14
000077a0e99dc00d  vmovaps [rsp+0xE0], xmm15
000077a0e99dc016  sub rsp, 0x40
000077a0e99dc01a  lea rdi, [rsp]
000077a0e99dc01e  lea rsi, [rsp+0x10]
000077a0e99dc023  lea rdx, [rsp+0x20]
000077a0e99dc028  lea rcx, [rsp+0x30]
000077a0e99dc02d  mov r8d, 0x00
000077a0e99dc033  lea r9, [r15+0x3A8]
000077a0e99dc03a  movaps [rdi], xmm10
000077a0e99dc03e  movaps [rsi], xmm5
000077a0e99dc041  movaps [rdx], xmm12
000077a0e99dc045  movaps [rcx], xmm1
000077a0e99dc048  mov rax, 0x60CAA235BA50
000077a0e99dc052  call rax
000077a0e99dc054  movaps xmm10, [rsp]
000077a0e99dc059  add rsp, 0x40
000077a0e99dc05d  vmovaps xmm0, [rsp]
000077a0e99dc062  vmovaps xmm1, [rsp+0x10]
000077a0e99dc068  vmovaps xmm2, [rsp+0x20]
000077a0e99dc06e  vmovaps xmm3, [rsp+0x30]
000077a0e99dc074  vmovaps xmm4, [rsp+0x40]
000077a0e99dc07a  vmovaps xmm5, [rsp+0x50]
000077a0e99dc080  vmovaps xmm6, [rsp+0x60]
000077a0e99dc086  vmovaps xmm7, [rsp+0x70]
000077a0e99dc08c  vmovaps xmm8, [rsp+0x80]
000077a0e99dc095  vmovaps xmm9, [rsp+0x90]
000077a0e99dc09e  vmovaps xmm11, [rsp+0xA0]
000077a0e99dc0a7  vmovaps xmm12, [rsp+0xB0]
000077a0e99dc0b0  vmovaps xmm13, [rsp+0xC0]
000077a0e99dc0b9  vmovaps xmm14, [rsp+0xD0]
000077a0e99dc0c2  vmovaps xmm15, [rsp+0xE0]
000077a0e99dc0cb  add rsp, 0xF0
000077a0e99dc0d2  pop r11
000077a0e99dc0d4  pop r10
000077a0e99dc0d6  pop r9
000077a0e99dc0d8  pop r8
000077a0e99dc0da  pop rsi
000077a0e99dc0db  pop rdi
000077a0e99dc0dc  pop rdx
000077a0e99dc0dd  pop rcx
000077a0e99dc0de  pop rax
000077a0e99dc0df  add rsp, 0x08
000077a0e99dc0e3  jmp 0x000077A0E99DA3B0
000077a0e99dc0e8  sub rsp, 0x08
000077a0e99dc0ec  push rax
000077a0e99dc0ed  push rcx
000077a0e99dc0ee  push rdx
000077a0e99dc0ef  push rdi
000077a0e99dc0f0  push rsi
000077a0e99dc0f1  push r8
000077a0e99dc0f3  push r9
000077a0e99dc0f5  push r10
000077a0e99dc0f7  push r11
000077a0e99dc0f9  sub rsp, 0xF0
000077a0e99dc100  vmovaps [rsp], xmm0
000077a0e99dc105  vmovaps [rsp+0x10], xmm1
000077a0e99dc10b  vmovaps [rsp+0x20], xmm2
000077a0e99dc111  vmovaps [rsp+0x30], xmm3
000077a0e99dc117  vmovaps [rsp+0x40], xmm4
000077a0e99dc11d  vmovaps [rsp+0x50], xmm5
000077a0e99dc123  vmovaps [rsp+0x60], xmm6
000077a0e99dc129  vmovaps [rsp+0x70], xmm7
000077a0e99dc12f  vmovaps [rsp+0x80], xmm8
000077a0e99dc138  vmovaps [rsp+0x90], xmm9
000077a0e99dc141  vmovaps [rsp+0xA0], xmm10
000077a0e99dc14a  vmovaps [rsp+0xB0], xmm11
000077a0e99dc153  vmovaps [rsp+0xC0], xmm13
000077a0e99dc15c  vmovaps [rsp+0xD0], xmm14
000077a0e99dc165  vmovaps [rsp+0xE0], xmm15
000077a0e99dc16e  sub rsp, 0x40
000077a0e99dc172  lea rdi, [rsp]
000077a0e99dc176  lea rsi, [rsp+0x10]
000077a0e99dc17b  lea rdx, [rsp+0x20]
000077a0e99dc180  lea rcx, [rsp+0x30]
000077a0e99dc185  mov r8d, 0x00
000077a0e99dc18b  lea r9, [r15+0x3A8]
000077a0e99dc192  movaps [rdi], xmm12
000077a0e99dc196  movaps [rsi], xmm7
000077a0e99dc199  movaps [rdx], xmm15
000077a0e99dc19d  movaps [rcx], xmm1
000077a0e99dc1a0  mov rax, 0x60CAA235BA50
000077a0e99dc1aa  call rax
000077a0e99dc1ac  movaps xmm12, [rsp]
000077a0e99dc1b1  add rsp, 0x40
000077a0e99dc1b5  vmovaps xmm0, [rsp]
000077a0e99dc1ba  vmovaps xmm1, [rsp+0x10]
000077a0e99dc1c0  vmovaps xmm2, [rsp+0x20]
000077a0e99dc1c6  vmovaps xmm3, [rsp+0x30]
000077a0e99dc1cc  vmovaps xmm4, [rsp+0x40]
000077a0e99dc1d2  vmovaps xmm5, [rsp+0x50]
000077a0e99dc1d8  vmovaps xmm6, [rsp+0x60]
000077a0e99dc1de  vmovaps xmm7, [rsp+0x70]
000077a0e99dc1e4  vmovaps xmm8, [rsp+0x80]
000077a0e99dc1ed  vmovaps xmm9, [rsp+0x90]
000077a0e99dc1f6  vmovaps xmm10, [rsp+0xA0]
000077a0e99dc1ff  vmovaps xmm11, [rsp+0xB0]
000077a0e99dc208  vmovaps xmm13, [rsp+0xC0]
000077a0e99dc211  vmovaps xmm14, [rsp+0xD0]
000077a0e99dc21a  vmovaps xmm15, [rsp+0xE0]
000077a0e99dc223  add rsp, 0xF0
000077a0e99dc22a  pop r11
000077a0e99dc22c  pop r10
000077a0e99dc22e  pop r9
000077a0e99dc230  pop r8
000077a0e99dc232  pop rsi
000077a0e99dc233  pop rdi
000077a0e99dc234  pop rdx
000077a0e99dc235  pop rcx
000077a0e99dc236  pop rax
000077a0e99dc237  add rsp, 0x08
000077a0e99dc23b  jmp 0x000077A0E99DA3D9
000077a0e99dc240  call 0x000077A0E97FF430
000077a0e99dc245  jmp 0x000077A0E99DA3E3
000077a0e99dc24a  call 0x000077A0E980E760
000077a0e99dc24f  jmp 0x000077A0E99DA3ED
000077a0e99dc254  sub rsp, 0x08
000077a0e99dc258  push rax
000077a0e99dc259  push rcx
000077a0e99dc25a  push rdx
000077a0e99dc25b  push rdi
000077a0e99dc25c  push rsi
000077a0e99dc25d  push r8
000077a0e99dc25f  push r9
000077a0e99dc261  push r10
000077a0e99dc263  push r11
000077a0e99dc265  sub rsp, 0xF0
000077a0e99dc26c  vmovaps [rsp], xmm0
000077a0e99dc271  vmovaps [rsp+0x10], xmm1
000077a0e99dc277  vmovaps [rsp+0x20], xmm2
000077a0e99dc27d  vmovaps [rsp+0x30], xmm3
000077a0e99dc283  vmovaps [rsp+0x40], xmm4
000077a0e99dc289  vmovaps [rsp+0x50], xmm5
000077a0e99dc28f  vmovaps [rsp+0x60], xmm6
000077a0e99dc295  vmovaps [rsp+0x70], xmm8
000077a0e99dc29b  vmovaps [rsp+0x80], xmm9
000077a0e99dc2a4  vmovaps [rsp+0x90], xmm10
000077a0e99dc2ad  vmovaps [rsp+0xA0], xmm11
000077a0e99dc2b6  vmovaps [rsp+0xB0], xmm12
000077a0e99dc2bf  vmovaps [rsp+0xC0], xmm13
000077a0e99dc2c8  vmovaps [rsp+0xD0], xmm14
000077a0e99dc2d1  vmovaps [rsp+0xE0], xmm15
000077a0e99dc2da  sub rsp, 0x40
000077a0e99dc2de  lea rdi, [rsp]
000077a0e99dc2e2  lea rsi, [rsp+0x10]
000077a0e99dc2e7  lea rdx, [rsp+0x20]
000077a0e99dc2ec  lea rcx, [rsp+0x30]
000077a0e99dc2f1  mov r8d, 0x00
000077a0e99dc2f7  lea r9, [r15+0x3A8]
000077a0e99dc2fe  movaps [rdi], xmm7
000077a0e99dc301  movaps [rsi], xmm2
000077a0e99dc304  movaps [rdx], xmm9
000077a0e99dc308  movaps [rcx], xmm11
000077a0e99dc30c  mov rax, 0x60CAA235BA50
000077a0e99dc316  call rax
000077a0e99dc318  movaps xmm7, [rsp]
000077a0e99dc31c  add rsp, 0x40
000077a0e99dc320  vmovaps xmm0, [rsp]
000077a0e99dc325  vmovaps xmm1, [rsp+0x10]
000077a0e99dc32b  vmovaps xmm2, [rsp+0x20]
000077a0e99dc331  vmovaps xmm3, [rsp+0x30]
000077a0e99dc337  vmovaps xmm4, [rsp+0x40]
000077a0e99dc33d  vmovaps xmm5, [rsp+0x50]
000077a0e99dc343  vmovaps xmm6, [rsp+0x60]
000077a0e99dc349  vmovaps xmm8, [rsp+0x70]
000077a0e99dc34f  vmovaps xmm9, [rsp+0x80]
000077a0e99dc358  vmovaps xmm10, [rsp+0x90]
000077a0e99dc361  vmovaps xmm11, [rsp+0xA0]
000077a0e99dc36a  vmovaps xmm12, [rsp+0xB0]
000077a0e99dc373  vmovaps xmm13, [rsp+0xC0]
000077a0e99dc37c  vmovaps xmm14, [rsp+0xD0]
000077a0e99dc385  vmovaps xmm15, [rsp+0xE0]
000077a0e99dc38e  add rsp, 0xF0
000077a0e99dc395  pop r11
000077a0e99dc397  pop r10
000077a0e99dc399  pop r9
000077a0e99dc39b  pop r8
000077a0e99dc39d  pop rsi
000077a0e99dc39e  pop rdi
000077a0e99dc39f  pop rdx
000077a0e99dc3a0  pop rcx
000077a0e99dc3a1  pop rax
000077a0e99dc3a2  add rsp, 0x08
000077a0e99dc3a6  jmp 0x000077A0E99DA421
000077a0e99dc3ab  sub rsp, 0x08
000077a0e99dc3af  push rax
000077a0e99dc3b0  push rcx
000077a0e99dc3b1  push rdx
000077a0e99dc3b2  push rdi
000077a0e99dc3b3  push rsi
000077a0e99dc3b4  push r8
000077a0e99dc3b6  push r9
000077a0e99dc3b8  push r10
000077a0e99dc3ba  push r11
000077a0e99dc3bc  sub rsp, 0xF0
000077a0e99dc3c3  vmovaps [rsp], xmm0
000077a0e99dc3c8  vmovaps [rsp+0x10], xmm1
000077a0e99dc3ce  vmovaps [rsp+0x20], xmm2
000077a0e99dc3d4  vmovaps [rsp+0x30], xmm3
000077a0e99dc3da  vmovaps [rsp+0x40], xmm4
000077a0e99dc3e0  vmovaps [rsp+0x50], xmm5
000077a0e99dc3e6  vmovaps [rsp+0x60], xmm6
000077a0e99dc3ec  vmovaps [rsp+0x70], xmm7
000077a0e99dc3f2  vmovaps [rsp+0x80], xmm8
000077a0e99dc3fb  vmovaps [rsp+0x90], xmm10
000077a0e99dc404  vmovaps [rsp+0xA0], xmm11
000077a0e99dc40d  vmovaps [rsp+0xB0], xmm12
000077a0e99dc416  vmovaps [rsp+0xC0], xmm13
000077a0e99dc41f  vmovaps [rsp+0xD0], xmm14
000077a0e99dc428  vmovaps [rsp+0xE0], xmm15
000077a0e99dc431  sub rsp, 0x40
000077a0e99dc435  lea rdi, [rsp]
000077a0e99dc439  lea rsi, [rsp+0x10]
000077a0e99dc43e  lea rdx, [rsp+0x20]
000077a0e99dc443  lea rcx, [rsp+0x30]
000077a0e99dc448  mov r8d, 0x00
000077a0e99dc44e  lea r9, [r15+0x3A8]
000077a0e99dc455  movaps [rdi], xmm9
000077a0e99dc459  movaps [rsi], xmm6
000077a0e99dc45c  movaps [rdx], xmm1
000077a0e99dc45f  movaps [rcx], xmm11
000077a0e99dc463  mov rax, 0x60CAA235BA50
000077a0e99dc46d  call rax
000077a0e99dc46f  movaps xmm9, [rsp]
000077a0e99dc474  add rsp, 0x40
000077a0e99dc478  vmovaps xmm0, [rsp]
000077a0e99dc47d  vmovaps xmm1, [rsp+0x10]
000077a0e99dc483  vmovaps xmm2, [rsp+0x20]
000077a0e99dc489  vmovaps xmm3, [rsp+0x30]
000077a0e99dc48f  vmovaps xmm4, [rsp+0x40]
000077a0e99dc495  vmovaps xmm5, [rsp+0x50]
000077a0e99dc49b  vmovaps xmm6, [rsp+0x60]
000077a0e99dc4a1  vmovaps xmm7, [rsp+0x70]
000077a0e99dc4a7  vmovaps xmm8, [rsp+0x80]
000077a0e99dc4b0  vmovaps xmm10, [rsp+0x90]
000077a0e99dc4b9  vmovaps xmm11, [rsp+0xA0]
000077a0e99dc4c2  vmovaps xmm12, [rsp+0xB0]
000077a0e99dc4cb  vmovaps xmm13, [rsp+0xC0]
000077a0e99dc4d4  vmovaps xmm14, [rsp+0xD0]
000077a0e99dc4dd  vmovaps xmm15, [rsp+0xE0]
000077a0e99dc4e6  add rsp, 0xF0
000077a0e99dc4ed  pop r11
000077a0e99dc4ef  pop r10
000077a0e99dc4f1  pop r9
000077a0e99dc4f3  pop r8
000077a0e99dc4f5  pop rsi
000077a0e99dc4f6  pop rdi
000077a0e99dc4f7  pop rdx
000077a0e99dc4f8  pop rcx
000077a0e99dc4f9  pop rax
000077a0e99dc4fa  add rsp, 0x08
000077a0e99dc4fe  jmp 0x000077A0E99DA447
000077a0e99dc503  sub rsp, 0x08
000077a0e99dc507  push rax
000077a0e99dc508  push rcx
000077a0e99dc509  push rdx
000077a0e99dc50a  push rdi
000077a0e99dc50b  push rsi
000077a0e99dc50c  push r8
000077a0e99dc50e  push r9
000077a0e99dc510  push r10
000077a0e99dc512  push r11
000077a0e99dc514  sub rsp, 0xF0
000077a0e99dc51b  vmovaps [rsp], xmm0
000077a0e99dc520  vmovaps [rsp+0x10], xmm1
000077a0e99dc526  vmovaps [rsp+0x20], xmm2
000077a0e99dc52c  vmovaps [rsp+0x30], xmm3
000077a0e99dc532  vmovaps [rsp+0x40], xmm4
000077a0e99dc538  vmovaps [rsp+0x50], xmm5
000077a0e99dc53e  vmovaps [rsp+0x60], xmm6
000077a0e99dc544  vmovaps [rsp+0x70], xmm7
000077a0e99dc54a  vmovaps [rsp+0x80], xmm8
000077a0e99dc553  vmovaps [rsp+0x90], xmm9
000077a0e99dc55c  vmovaps [rsp+0xA0], xmm10
000077a0e99dc565  vmovaps [rsp+0xB0], xmm12
000077a0e99dc56e  vmovaps [rsp+0xC0], xmm13
000077a0e99dc577  vmovaps [rsp+0xD0], xmm14
000077a0e99dc580  vmovaps [rsp+0xE0], xmm15
000077a0e99dc589  sub rsp, 0x40
000077a0e99dc58d  lea rdi, [rsp]
000077a0e99dc591  lea rsi, [rsp+0x10]
000077a0e99dc596  lea rdx, [rsp+0x20]
000077a0e99dc59b  lea rcx, [rsp+0x30]
000077a0e99dc5a0  mov r8d, 0x00
000077a0e99dc5a6  lea r9, [r15+0x3A8]
000077a0e99dc5ad  movaps [rdi], xmm11
000077a0e99dc5b1  movaps [rsi], xmm10
000077a0e99dc5b5  movaps [rdx], xmm8
000077a0e99dc5b9  movaps [rcx], xmm1
000077a0e99dc5bc  mov rax, 0x60CAA235BA50
000077a0e99dc5c6  call rax
000077a0e99dc5c8  movaps xmm11, [rsp]
000077a0e99dc5cd  add rsp, 0x40
000077a0e99dc5d1  vmovaps xmm0, [rsp]
000077a0e99dc5d6  vmovaps xmm1, [rsp+0x10]
000077a0e99dc5dc  vmovaps xmm2, [rsp+0x20]
000077a0e99dc5e2  vmovaps xmm3, [rsp+0x30]
000077a0e99dc5e8  vmovaps xmm4, [rsp+0x40]
000077a0e99dc5ee  vmovaps xmm5, [rsp+0x50]
000077a0e99dc5f4  vmovaps xmm6, [rsp+0x60]
000077a0e99dc5fa  vmovaps xmm7, [rsp+0x70]
000077a0e99dc600  vmovaps xmm8, [rsp+0x80]
000077a0e99dc609  vmovaps xmm9, [rsp+0x90]
000077a0e99dc612  vmovaps xmm10, [rsp+0xA0]
000077a0e99dc61b  vmovaps xmm12, [rsp+0xB0]
000077a0e99dc624  vmovaps xmm13, [rsp+0xC0]
000077a0e99dc62d  vmovaps xmm14, [rsp+0xD0]
000077a0e99dc636  vmovaps xmm15, [rsp+0xE0]
000077a0e99dc63f  add rsp, 0xF0
000077a0e99dc646  pop r11
000077a0e99dc648  pop r10
000077a0e99dc64a  pop r9
000077a0e99dc64c  pop r8
000077a0e99dc64e  pop rsi
000077a0e99dc64f  pop rdi
000077a0e99dc650  pop rdx
000077a0e99dc651  pop rcx
000077a0e99dc652  pop rax
000077a0e99dc653  add rsp, 0x08
000077a0e99dc657  jmp 0x000077A0E99DA46D
000077a0e99dc65c  sub rsp, 0x08
000077a0e99dc660  push rax
000077a0e99dc661  push rcx
000077a0e99dc662  push rdx
000077a0e99dc663  push rdi
000077a0e99dc664  push rsi
000077a0e99dc665  push r8
000077a0e99dc667  push r9
000077a0e99dc669  push r10
000077a0e99dc66b  push r11
000077a0e99dc66d  sub rsp, 0xF0
000077a0e99dc674  vmovaps [rsp], xmm0
000077a0e99dc679  vmovaps [rsp+0x10], xmm1
000077a0e99dc67f  vmovaps [rsp+0x20], xmm2
000077a0e99dc685  vmovaps [rsp+0x30], xmm3
000077a0e99dc68b  vmovaps [rsp+0x40], xmm4
000077a0e99dc691  vmovaps [rsp+0x50], xmm5
000077a0e99dc697  vmovaps [rsp+0x60], xmm6
000077a0e99dc69d  vmovaps [rsp+0x70], xmm7
000077a0e99dc6a3  vmovaps [rsp+0x80], xmm8
000077a0e99dc6ac  vmovaps [rsp+0x90], xmm9
000077a0e99dc6b5  vmovaps [rsp+0xA0], xmm11
000077a0e99dc6be  vmovaps [rsp+0xB0], xmm12
000077a0e99dc6c7  vmovaps [rsp+0xC0], xmm13
000077a0e99dc6d0  vmovaps [rsp+0xD0], xmm14
000077a0e99dc6d9  vmovaps [rsp+0xE0], xmm15
000077a0e99dc6e2  sub rsp, 0x40
000077a0e99dc6e6  lea rdi, [rsp]
000077a0e99dc6ea  lea rsi, [rsp+0x10]
000077a0e99dc6ef  lea rdx, [rsp+0x20]
000077a0e99dc6f4  lea rcx, [rsp+0x30]
000077a0e99dc6f9  mov r8d, 0x00
000077a0e99dc6ff  lea r9, [r15+0x3A8]
000077a0e99dc706  movaps [rdi], xmm10
000077a0e99dc70a  movaps [rsi], xmm12
000077a0e99dc70e  movaps [rdx], xmm13
000077a0e99dc712  movaps [rcx], xmm1
000077a0e99dc715  mov rax, 0x60CAA235BA50
000077a0e99dc71f  call rax
000077a0e99dc721  movaps xmm10, [rsp]
000077a0e99dc726  add rsp, 0x40
000077a0e99dc72a  vmovaps xmm0, [rsp]
000077a0e99dc72f  vmovaps xmm1, [rsp+0x10]
000077a0e99dc735  vmovaps xmm2, [rsp+0x20]
000077a0e99dc73b  vmovaps xmm3, [rsp+0x30]
000077a0e99dc741  vmovaps xmm4, [rsp+0x40]
000077a0e99dc747  vmovaps xmm5, [rsp+0x50]
000077a0e99dc74d  vmovaps xmm6, [rsp+0x60]
000077a0e99dc753  vmovaps xmm7, [rsp+0x70]
000077a0e99dc759  vmovaps xmm8, [rsp+0x80]
000077a0e99dc762  vmovaps xmm9, [rsp+0x90]
000077a0e99dc76b  vmovaps xmm11, [rsp+0xA0]
000077a0e99dc774  vmovaps xmm12, [rsp+0xB0]
000077a0e99dc77d  vmovaps xmm13, [rsp+0xC0]
000077a0e99dc786  vmovaps xmm14, [rsp+0xD0]
000077a0e99dc78f  vmovaps xmm15, [rsp+0xE0]
000077a0e99dc798  add rsp, 0xF0
000077a0e99dc79f  pop r11
000077a0e99dc7a1  pop r10
000077a0e99dc7a3  pop r9
000077a0e99dc7a5  pop r8
000077a0e99dc7a7  pop rsi
000077a0e99dc7a8  pop rdi
000077a0e99dc7a9  pop rdx
000077a0e99dc7aa  pop rcx
000077a0e99dc7ab  pop rax
000077a0e99dc7ac  add rsp, 0x08
000077a0e99dc7b0  jmp 0x000077A0E99DA493
000077a0e99dc7b5  call 0x000077A0E97FF430
000077a0e99dc7ba  jmp 0x000077A0E99DA49D
000077a0e99dc7bf  call 0x000077A0E980C260
000077a0e99dc7c4  jmp 0x000077A0E99DA4A7
000077a0e99dc7c9  sub rsp, 0x08
000077a0e99dc7cd  push rax
000077a0e99dc7ce  push rcx
000077a0e99dc7cf  push rdx
000077a0e99dc7d0  push rdi
000077a0e99dc7d1  push rsi
000077a0e99dc7d2  push r8
000077a0e99dc7d4  push r9
000077a0e99dc7d6  push r10
000077a0e99dc7d8  push r11
000077a0e99dc7da  sub rsp, 0xF0
000077a0e99dc7e1  vmovaps [rsp], xmm0
000077a0e99dc7e6  vmovaps [rsp+0x10], xmm1
000077a0e99dc7ec  vmovaps [rsp+0x20], xmm2
000077a0e99dc7f2  vmovaps [rsp+0x30], xmm3
000077a0e99dc7f8  vmovaps [rsp+0x40], xmm4
000077a0e99dc7fe  vmovaps [rsp+0x50], xmm5
000077a0e99dc804  vmovaps [rsp+0x60], xmm6
000077a0e99dc80a  vmovaps [rsp+0x70], xmm7
000077a0e99dc810  vmovaps [rsp+0x80], xmm9
000077a0e99dc819  vmovaps [rsp+0x90], xmm10
000077a0e99dc822  vmovaps [rsp+0xA0], xmm11
000077a0e99dc82b  vmovaps [rsp+0xB0], xmm12
000077a0e99dc834  vmovaps [rsp+0xC0], xmm13
000077a0e99dc83d  vmovaps [rsp+0xD0], xmm14
000077a0e99dc846  vmovaps [rsp+0xE0], xmm15
000077a0e99dc84f  sub rsp, 0x40
000077a0e99dc853  lea rdi, [rsp]
000077a0e99dc857  lea rsi, [rsp+0x10]
000077a0e99dc85c  lea rdx, [rsp+0x20]
000077a0e99dc861  lea rcx, [rsp+0x30]
000077a0e99dc866  mov r8d, 0x00
000077a0e99dc86c  lea r9, [r15+0x3A8]
000077a0e99dc873  movaps [rdi], xmm8
000077a0e99dc877  movaps [rsi], xmm7
000077a0e99dc87a  movaps [rdx], xmm4
000077a0e99dc87d  movaps [rcx], xmm12
000077a0e99dc881  mov rax, 0x60CAA235BA50
000077a0e99dc88b  call rax
000077a0e99dc88d  movaps xmm8, [rsp]
000077a0e99dc892  add rsp, 0x40
000077a0e99dc896  vmovaps xmm0, [rsp]
000077a0e99dc89b  vmovaps xmm1, [rsp+0x10]
000077a0e99dc8a1  vmovaps xmm2, [rsp+0x20]
000077a0e99dc8a7  vmovaps xmm3, [rsp+0x30]
000077a0e99dc8ad  vmovaps xmm4, [rsp+0x40]
000077a0e99dc8b3  vmovaps xmm5, [rsp+0x50]
000077a0e99dc8b9  vmovaps xmm6, [rsp+0x60]
000077a0e99dc8bf  vmovaps xmm7, [rsp+0x70]
000077a0e99dc8c5  vmovaps xmm9, [rsp+0x80]
000077a0e99dc8ce  vmovaps xmm10, [rsp+0x90]
000077a0e99dc8d7  vmovaps xmm11, [rsp+0xA0]
000077a0e99dc8e0  vmovaps xmm12, [rsp+0xB0]
000077a0e99dc8e9  vmovaps xmm13, [rsp+0xC0]
000077a0e99dc8f2  vmovaps xmm14, [rsp+0xD0]
000077a0e99dc8fb  vmovaps xmm15, [rsp+0xE0]
000077a0e99dc904  add rsp, 0xF0
000077a0e99dc90b  pop r11
000077a0e99dc90d  pop r10
000077a0e99dc90f  pop r9
000077a0e99dc911  pop r8
000077a0e99dc913  pop rsi
000077a0e99dc914  pop rdi
000077a0e99dc915  pop rdx
000077a0e99dc916  pop rcx
000077a0e99dc917  pop rax
000077a0e99dc918  add rsp, 0x08
000077a0e99dc91c  jmp 0x000077A0E99DA4D0
000077a0e99dc921  sub rsp, 0x08
000077a0e99dc925  push rax
000077a0e99dc926  push rcx
000077a0e99dc927  push rdx
000077a0e99dc928  push rdi
000077a0e99dc929  push rsi
000077a0e99dc92a  push r8
000077a0e99dc92c  push r9
000077a0e99dc92e  push r10
000077a0e99dc930  push r11
000077a0e99dc932  sub rsp, 0xF0
000077a0e99dc939  vmovaps [rsp], xmm0
000077a0e99dc93e  vmovaps [rsp+0x10], xmm1
000077a0e99dc944  vmovaps [rsp+0x20], xmm2
000077a0e99dc94a  vmovaps [rsp+0x30], xmm3
000077a0e99dc950  vmovaps [rsp+0x40], xmm4
000077a0e99dc956  vmovaps [rsp+0x50], xmm5
000077a0e99dc95c  vmovaps [rsp+0x60], xmm6
000077a0e99dc962  vmovaps [rsp+0x70], xmm8
000077a0e99dc968  vmovaps [rsp+0x80], xmm9
000077a0e99dc971  vmovaps [rsp+0x90], xmm10
000077a0e99dc97a  vmovaps [rsp+0xA0], xmm11
000077a0e99dc983  vmovaps [rsp+0xB0], xmm12
000077a0e99dc98c  vmovaps [rsp+0xC0], xmm13
000077a0e99dc995  vmovaps [rsp+0xD0], xmm14
000077a0e99dc99e  vmovaps [rsp+0xE0], xmm15
000077a0e99dc9a7  sub rsp, 0x40
000077a0e99dc9ab  lea rdi, [rsp]
000077a0e99dc9af  lea rsi, [rsp+0x10]
000077a0e99dc9b4  lea rdx, [rsp+0x20]
000077a0e99dc9b9  lea rcx, [rsp+0x30]
000077a0e99dc9be  mov r8d, 0x00
000077a0e99dc9c4  lea r9, [r15+0x3A8]
000077a0e99dc9cb  movaps [rdi], xmm7
000077a0e99dc9ce  movaps [rsi], xmm9
000077a0e99dc9d2  movaps [rdx], xmm14
000077a0e99dc9d6  movaps [rcx], xmm12
000077a0e99dc9da  mov rax, 0x60CAA235BA50
000077a0e99dc9e4  call rax
000077a0e99dc9e6  movaps xmm7, [rsp]
000077a0e99dc9ea  add rsp, 0x40
000077a0e99dc9ee  vmovaps xmm0, [rsp]
000077a0e99dc9f3  vmovaps xmm1, [rsp+0x10]
000077a0e99dc9f9  vmovaps xmm2, [rsp+0x20]
000077a0e99dc9ff  vmovaps xmm3, [rsp+0x30]
000077a0e99dca05  vmovaps xmm4, [rsp+0x40]
000077a0e99dca0b  vmovaps xmm5, [rsp+0x50]
000077a0e99dca11  vmovaps xmm6, [rsp+0x60]
000077a0e99dca17  vmovaps xmm8, [rsp+0x70]
000077a0e99dca1d  vmovaps xmm9, [rsp+0x80]
000077a0e99dca26  vmovaps xmm10, [rsp+0x90]
000077a0e99dca2f  vmovaps xmm11, [rsp+0xA0]
000077a0e99dca38  vmovaps xmm12, [rsp+0xB0]
000077a0e99dca41  vmovaps xmm13, [rsp+0xC0]
000077a0e99dca4a  vmovaps xmm14, [rsp+0xD0]
000077a0e99dca53  vmovaps xmm15, [rsp+0xE0]
000077a0e99dca5c  add rsp, 0xF0
000077a0e99dca63  pop r11
000077a0e99dca65  pop r10
000077a0e99dca67  pop r9
000077a0e99dca69  pop r8
000077a0e99dca6b  pop rsi
000077a0e99dca6c  pop rdi
000077a0e99dca6d  pop rdx
000077a0e99dca6e  pop rcx
000077a0e99dca6f  pop rax
000077a0e99dca70  add rsp, 0x08
000077a0e99dca74  jmp 0x000077A0E99DA4F8
000077a0e99dca79  sub rsp, 0x08
000077a0e99dca7d  push rax
000077a0e99dca7e  push rcx
000077a0e99dca7f  push rdx
000077a0e99dca80  push rdi
000077a0e99dca81  push rsi
000077a0e99dca82  push r8
000077a0e99dca84  push r9
000077a0e99dca86  push r10
000077a0e99dca88  push r11
000077a0e99dca8a  sub rsp, 0xF0
000077a0e99dca91  vmovaps [rsp], xmm0
000077a0e99dca96  vmovaps [rsp+0x10], xmm1
000077a0e99dca9c  vmovaps [rsp+0x20], xmm2
000077a0e99dcaa2  vmovaps [rsp+0x30], xmm3
000077a0e99dcaa8  vmovaps [rsp+0x40], xmm4
000077a0e99dcaae  vmovaps [rsp+0x50], xmm5
000077a0e99dcab4  vmovaps [rsp+0x60], xmm6
000077a0e99dcaba  vmovaps [rsp+0x70], xmm7
000077a0e99dcac0  vmovaps [rsp+0x80], xmm8
000077a0e99dcac9  vmovaps [rsp+0x90], xmm9
000077a0e99dcad2  vmovaps [rsp+0xA0], xmm10
000077a0e99dcadb  vmovaps [rsp+0xB0], xmm11
000077a0e99dcae4  vmovaps [rsp+0xC0], xmm13
000077a0e99dcaed  vmovaps [rsp+0xD0], xmm14
000077a0e99dcaf6  vmovaps [rsp+0xE0], xmm15
000077a0e99dcaff  sub rsp, 0x40
000077a0e99dcb03  lea rdi, [rsp]
000077a0e99dcb07  lea rsi, [rsp+0x10]
000077a0e99dcb0c  lea rdx, [rsp+0x20]
000077a0e99dcb11  lea rcx, [rsp+0x30]
000077a0e99dcb16  mov r8d, 0x00
000077a0e99dcb1c  lea r9, [r15+0x3A8]
000077a0e99dcb23  movaps [rdi], xmm12
000077a0e99dcb27  movaps [rsi], xmm11
000077a0e99dcb2b  movaps [rdx], xmm15
000077a0e99dcb2f  movaps [rcx], xmm14
000077a0e99dcb33  mov rax, 0x60CAA235BA50
000077a0e99dcb3d  call rax
000077a0e99dcb3f  movaps xmm12, [rsp]
000077a0e99dcb44  add rsp, 0x40
000077a0e99dcb48  vmovaps xmm0, [rsp]
000077a0e99dcb4d  vmovaps xmm1, [rsp+0x10]
000077a0e99dcb53  vmovaps xmm2, [rsp+0x20]
000077a0e99dcb59  vmovaps xmm3, [rsp+0x30]
000077a0e99dcb5f  vmovaps xmm4, [rsp+0x40]
000077a0e99dcb65  vmovaps xmm5, [rsp+0x50]
000077a0e99dcb6b  vmovaps xmm6, [rsp+0x60]
000077a0e99dcb71  vmovaps xmm7, [rsp+0x70]
000077a0e99dcb77  vmovaps xmm8, [rsp+0x80]
000077a0e99dcb80  vmovaps xmm9, [rsp+0x90]
000077a0e99dcb89  vmovaps xmm10, [rsp+0xA0]
000077a0e99dcb92  vmovaps xmm11, [rsp+0xB0]
000077a0e99dcb9b  vmovaps xmm13, [rsp+0xC0]
000077a0e99dcba4  vmovaps xmm14, [rsp+0xD0]
000077a0e99dcbad  vmovaps xmm15, [rsp+0xE0]
000077a0e99dcbb6  add rsp, 0xF0
000077a0e99dcbbd  pop r11
000077a0e99dcbbf  pop r10
000077a0e99dcbc1  pop r9
000077a0e99dcbc3  pop r8
000077a0e99dcbc5  pop rsi
000077a0e99dcbc6  pop rdi
000077a0e99dcbc7  pop rdx
000077a0e99dcbc8  pop rcx
000077a0e99dcbc9  pop rax
000077a0e99dcbca  add rsp, 0x08
000077a0e99dcbce  jmp 0x000077A0E99DA521
000077a0e99dcbd3  sub rsp, 0x08
000077a0e99dcbd7  push rax
000077a0e99dcbd8  push rcx
000077a0e99dcbd9  push rdx
000077a0e99dcbda  push rdi
000077a0e99dcbdb  push rsi
000077a0e99dcbdc  push r8
000077a0e99dcbde  push r9
000077a0e99dcbe0  push r10
000077a0e99dcbe2  push r11
000077a0e99dcbe4  sub rsp, 0xF0
000077a0e99dcbeb  vmovaps [rsp], xmm0
000077a0e99dcbf0  vmovaps [rsp+0x10], xmm1
000077a0e99dcbf6  vmovaps [rsp+0x20], xmm2
000077a0e99dcbfc  vmovaps [rsp+0x30], xmm3
000077a0e99dcc02  vmovaps [rsp+0x40], xmm4
000077a0e99dcc08  vmovaps [rsp+0x50], xmm5
000077a0e99dcc0e  vmovaps [rsp+0x60], xmm6
000077a0e99dcc14  vmovaps [rsp+0x70], xmm7
000077a0e99dcc1a  vmovaps [rsp+0x80], xmm8
000077a0e99dcc23  vmovaps [rsp+0x90], xmm9
000077a0e99dcc2c  vmovaps [rsp+0xA0], xmm10
000077a0e99dcc35  vmovaps [rsp+0xB0], xmm12
000077a0e99dcc3e  vmovaps [rsp+0xC0], xmm13
000077a0e99dcc47  vmovaps [rsp+0xD0], xmm14
000077a0e99dcc50  vmovaps [rsp+0xE0], xmm15
000077a0e99dcc59  sub rsp, 0x40
000077a0e99dcc5d  lea rdi, [rsp]
000077a0e99dcc61  lea rsi, [rsp+0x10]
000077a0e99dcc66  lea rdx, [rsp+0x20]
000077a0e99dcc6b  lea rcx, [rsp+0x30]
000077a0e99dcc70  mov r8d, 0x00
000077a0e99dcc76  lea r9, [r15+0x3A8]
000077a0e99dcc7d  movaps [rdi], xmm11
000077a0e99dcc81  movaps [rsi], xmm10
000077a0e99dcc85  movaps [rdx], xmm13
000077a0e99dcc89  movaps [rcx], xmm15
000077a0e99dcc8d  mov rax, 0x60CAA235BA50
000077a0e99dcc97  call rax
000077a0e99dcc99  movaps xmm11, [rsp]
000077a0e99dcc9e  add rsp, 0x40
000077a0e99dcca2  vmovaps xmm0, [rsp]
000077a0e99dcca7  vmovaps xmm1, [rsp+0x10]
000077a0e99dccad  vmovaps xmm2, [rsp+0x20]
000077a0e99dccb3  vmovaps xmm3, [rsp+0x30]
000077a0e99dccb9  vmovaps xmm4, [rsp+0x40]
000077a0e99dccbf  vmovaps xmm5, [rsp+0x50]
000077a0e99dccc5  vmovaps xmm6, [rsp+0x60]
000077a0e99dcccb  vmovaps xmm7, [rsp+0x70]
000077a0e99dccd1  vmovaps xmm8, [rsp+0x80]
000077a0e99dccda  vmovaps xmm9, [rsp+0x90]
000077a0e99dcce3  vmovaps xmm10, [rsp+0xA0]
000077a0e99dccec  vmovaps xmm12, [rsp+0xB0]
000077a0e99dccf5  vmovaps xmm13, [rsp+0xC0]
000077a0e99dccfe  vmovaps xmm14, [rsp+0xD0]
000077a0e99dcd07  vmovaps xmm15, [rsp+0xE0]
000077a0e99dcd10  add rsp, 0xF0
000077a0e99dcd17  pop r11
000077a0e99dcd19  pop r10
000077a0e99dcd1b  pop r9
000077a0e99dcd1d  pop r8
000077a0e99dcd1f  pop rsi
000077a0e99dcd20  pop rdi
000077a0e99dcd21  pop rdx
000077a0e99dcd22  pop rcx
000077a0e99dcd23  pop rax
000077a0e99dcd24  add rsp, 0x08
000077a0e99dcd28  jmp 0x000077A0E99DA54A
000077a0e99dcd2d  call 0x000077A0E980E760
000077a0e99dcd32  jmp 0x000077A0E99DA557
000077a0e99dcd37  call 0x000077A0E980D4E0
000077a0e99dcd3c  jmp 0x000077A0E99DA564
000077a0e99dcd41  sub rsp, 0x08
000077a0e99dcd45  push rax
000077a0e99dcd46  push rcx
000077a0e99dcd47  push rdx
000077a0e99dcd48  push rdi
000077a0e99dcd49  push rsi
000077a0e99dcd4a  push r8
000077a0e99dcd4c  push r9
000077a0e99dcd4e  push r10
000077a0e99dcd50  push r11
000077a0e99dcd52  sub rsp, 0xF0
000077a0e99dcd59  vmovaps [rsp], xmm0
000077a0e99dcd5e  vmovaps [rsp+0x10], xmm1
000077a0e99dcd64  vmovaps [rsp+0x20], xmm2
000077a0e99dcd6a  vmovaps [rsp+0x30], xmm3
000077a0e99dcd70  vmovaps [rsp+0x40], xmm4
000077a0e99dcd76  vmovaps [rsp+0x50], xmm5
000077a0e99dcd7c  vmovaps [rsp+0x60], xmm6
000077a0e99dcd82  vmovaps [rsp+0x70], xmm7
000077a0e99dcd88  vmovaps [rsp+0x80], xmm8
000077a0e99dcd91  vmovaps [rsp+0x90], xmm9
000077a0e99dcd9a  vmovaps [rsp+0xA0], xmm11
000077a0e99dcda3  vmovaps [rsp+0xB0], xmm12
000077a0e99dcdac  vmovaps [rsp+0xC0], xmm13
000077a0e99dcdb5  vmovaps [rsp+0xD0], xmm14
000077a0e99dcdbe  vmovaps [rsp+0xE0], xmm15
000077a0e99dcdc7  sub rsp, 0x40
000077a0e99dcdcb  lea rdi, [rsp]
000077a0e99dcdcf  lea rsi, [rsp+0x10]
000077a0e99dcdd4  lea rdx, [rsp+0x20]
000077a0e99dcdd9  lea rcx, [rsp+0x30]
000077a0e99dcdde  mov r8d, 0x00
000077a0e99dcde4  lea r9, [r15+0x3A8]
000077a0e99dcdeb  movaps [rdi], xmm10
000077a0e99dcdef  movaps [rsi], xmm8
000077a0e99dcdf3  movaps [rdx], xmm1
000077a0e99dcdf6  movaps [rcx], xmm13
000077a0e99dcdfa  mov rax, 0x60CAA235BA50
000077a0e99dce04  call rax
000077a0e99dce06  movaps xmm10, [rsp]
000077a0e99dce0b  add rsp, 0x40
000077a0e99dce0f  vmovaps xmm0, [rsp]
000077a0e99dce14  vmovaps xmm1, [rsp+0x10]
000077a0e99dce1a  vmovaps xmm2, [rsp+0x20]
000077a0e99dce20  vmovaps xmm3, [rsp+0x30]
000077a0e99dce26  vmovaps xmm4, [rsp+0x40]
000077a0e99dce2c  vmovaps xmm5, [rsp+0x50]
000077a0e99dce32  vmovaps xmm6, [rsp+0x60]
000077a0e99dce38  vmovaps xmm7, [rsp+0x70]
000077a0e99dce3e  vmovaps xmm8, [rsp+0x80]
000077a0e99dce47  vmovaps xmm9, [rsp+0x90]
000077a0e99dce50  vmovaps xmm11, [rsp+0xA0]
000077a0e99dce59  vmovaps xmm12, [rsp+0xB0]
000077a0e99dce62  vmovaps xmm13, [rsp+0xC0]
000077a0e99dce6b  vmovaps xmm14, [rsp+0xD0]
000077a0e99dce74  vmovaps xmm15, [rsp+0xE0]
000077a0e99dce7d  add rsp, 0xF0
000077a0e99dce84  pop r11
000077a0e99dce86  pop r10
000077a0e99dce88  pop r9
000077a0e99dce8a  pop r8
000077a0e99dce8c  pop rsi
000077a0e99dce8d  pop rdi
000077a0e99dce8e  pop rdx
000077a0e99dce8f  pop rcx
000077a0e99dce90  pop rax
000077a0e99dce91  add rsp, 0x08
000077a0e99dce95  jmp 0x000077A0E99DA59A
000077a0e99dce9a  call 0x000077A0E97FF430
000077a0e99dce9f  jmp 0x000077A0E99DA5AC
000077a0e99dcea4  sub rsp, 0x08
000077a0e99dcea8  push rax
000077a0e99dcea9  push rcx
000077a0e99dceaa  push rdx
000077a0e99dceab  push rdi
000077a0e99dceac  push rsi
000077a0e99dcead  push r8
000077a0e99dceaf  push r9
000077a0e99dceb1  push r10
000077a0e99dceb3  push r11
000077a0e99dceb5  sub rsp, 0xF0
000077a0e99dcebc  vmovaps [rsp], xmm0
000077a0e99dcec1  vmovaps [rsp+0x10], xmm1
000077a0e99dcec7  vmovaps [rsp+0x20], xmm2
000077a0e99dcecd  vmovaps [rsp+0x30], xmm3
000077a0e99dced3  vmovaps [rsp+0x40], xmm4
000077a0e99dced9  vmovaps [rsp+0x50], xmm5
000077a0e99dcedf  vmovaps [rsp+0x60], xmm6
000077a0e99dcee5  vmovaps [rsp+0x70], xmm7
000077a0e99dceeb  vmovaps [rsp+0x80], xmm8
000077a0e99dcef4  vmovaps [rsp+0x90], xmm10
000077a0e99dcefd  vmovaps [rsp+0xA0], xmm11
000077a0e99dcf06  vmovaps [rsp+0xB0], xmm12
000077a0e99dcf0f  vmovaps [rsp+0xC0], xmm13
000077a0e99dcf18  vmovaps [rsp+0xD0], xmm14
000077a0e99dcf21  vmovaps [rsp+0xE0], xmm15
000077a0e99dcf2a  sub rsp, 0x40
000077a0e99dcf2e  lea rdi, [rsp]
000077a0e99dcf32  lea rsi, [rsp+0x10]
000077a0e99dcf37  lea rdx, [rsp+0x20]
000077a0e99dcf3c  lea rcx, [rsp+0x30]
000077a0e99dcf41  mov r8d, 0x00
000077a0e99dcf47  lea r9, [r15+0x3A8]
000077a0e99dcf4e  movaps [rdi], xmm9
000077a0e99dcf52  movaps [rsi], xmm7
000077a0e99dcf55  movaps [rdx], xmm14
000077a0e99dcf59  movaps [rcx], xmm13
000077a0e99dcf5d  mov rax, 0x60CAA235BA50
000077a0e99dcf67  call rax
000077a0e99dcf69  movaps xmm9, [rsp]
000077a0e99dcf6e  add rsp, 0x40
000077a0e99dcf72  vmovaps xmm0, [rsp]
000077a0e99dcf77  vmovaps xmm1, [rsp+0x10]
000077a0e99dcf7d  vmovaps xmm2, [rsp+0x20]
000077a0e99dcf83  vmovaps xmm3, [rsp+0x30]
000077a0e99dcf89  vmovaps xmm4, [rsp+0x40]
000077a0e99dcf8f  vmovaps xmm5, [rsp+0x50]
000077a0e99dcf95  vmovaps xmm6, [rsp+0x60]
000077a0e99dcf9b  vmovaps xmm7, [rsp+0x70]
000077a0e99dcfa1  vmovaps xmm8, [rsp+0x80]
000077a0e99dcfaa  vmovaps xmm10, [rsp+0x90]
000077a0e99dcfb3  vmovaps xmm11, [rsp+0xA0]
000077a0e99dcfbc  vmovaps xmm12, [rsp+0xB0]
000077a0e99dcfc5  vmovaps xmm13, [rsp+0xC0]
000077a0e99dcfce  vmovaps xmm14, [rsp+0xD0]
000077a0e99dcfd7  vmovaps xmm15, [rsp+0xE0]
000077a0e99dcfe0  add rsp, 0xF0
000077a0e99dcfe7  pop r11
000077a0e99dcfe9  pop r10
000077a0e99dcfeb  pop r9
000077a0e99dcfed  pop r8
000077a0e99dcfef  pop rsi
000077a0e99dcff0  pop rdi
000077a0e99dcff1  pop rdx
000077a0e99dcff2  pop rcx
000077a0e99dcff3  pop rax
000077a0e99dcff4  add rsp, 0x08
000077a0e99dcff8  jmp 0x000077A0E99DA5DA
000077a0e99dcffd  sub rsp, 0x08
000077a0e99dd001  push rax
000077a0e99dd002  push rcx
000077a0e99dd003  push rdx
000077a0e99dd004  push rdi
000077a0e99dd005  push rsi
000077a0e99dd006  push r8
000077a0e99dd008  push r9
000077a0e99dd00a  push r10
000077a0e99dd00c  push r11
000077a0e99dd00e  sub rsp, 0xF0
000077a0e99dd015  vmovaps [rsp], xmm0
000077a0e99dd01a  vmovaps [rsp+0x10], xmm1
000077a0e99dd020  vmovaps [rsp+0x20], xmm2
000077a0e99dd026  vmovaps [rsp+0x30], xmm3
000077a0e99dd02c  vmovaps [rsp+0x40], xmm4
000077a0e99dd032  vmovaps [rsp+0x50], xmm5
000077a0e99dd038  vmovaps [rsp+0x60], xmm6
000077a0e99dd03e  vmovaps [rsp+0x70], xmm7
000077a0e99dd044  vmovaps [rsp+0x80], xmm8
000077a0e99dd04d  vmovaps [rsp+0x90], xmm9
000077a0e99dd056  vmovaps [rsp+0xA0], xmm10
000077a0e99dd05f  vmovaps [rsp+0xB0], xmm11
000077a0e99dd068  vmovaps [rsp+0xC0], xmm12
000077a0e99dd071  vmovaps [rsp+0xD0], xmm14
000077a0e99dd07a  vmovaps [rsp+0xE0], xmm15
000077a0e99dd083  sub rsp, 0x40
000077a0e99dd087  lea rdi, [rsp]
000077a0e99dd08b  lea rsi, [rsp+0x10]
000077a0e99dd090  lea rdx, [rsp+0x20]
000077a0e99dd095  lea rcx, [rsp+0x30]
000077a0e99dd09a  mov r8d, 0x00
000077a0e99dd0a0  lea r9, [r15+0x3A8]
000077a0e99dd0a7  movaps [rdi], xmm13
000077a0e99dd0ab  movaps [rsi], xmm12
000077a0e99dd0af  movaps [rdx], xmm15
000077a0e99dd0b3  movaps [rcx], xmm14
000077a0e99dd0b7  mov rax, 0x60CAA235BA50
000077a0e99dd0c1  call rax
000077a0e99dd0c3  movaps xmm13, [rsp]
000077a0e99dd0c8  add rsp, 0x40
000077a0e99dd0cc  vmovaps xmm0, [rsp]
000077a0e99dd0d1  vmovaps xmm1, [rsp+0x10]
000077a0e99dd0d7  vmovaps xmm2, [rsp+0x20]
000077a0e99dd0dd  vmovaps xmm3, [rsp+0x30]
000077a0e99dd0e3  vmovaps xmm4, [rsp+0x40]
000077a0e99dd0e9  vmovaps xmm5, [rsp+0x50]
000077a0e99dd0ef  vmovaps xmm6, [rsp+0x60]
000077a0e99dd0f5  vmovaps xmm7, [rsp+0x70]
000077a0e99dd0fb  vmovaps xmm8, [rsp+0x80]
000077a0e99dd104  vmovaps xmm9, [rsp+0x90]
000077a0e99dd10d  vmovaps xmm10, [rsp+0xA0]
000077a0e99dd116  vmovaps xmm11, [rsp+0xB0]
000077a0e99dd11f  vmovaps xmm12, [rsp+0xC0]
000077a0e99dd128  vmovaps xmm14, [rsp+0xD0]
000077a0e99dd131  vmovaps xmm15, [rsp+0xE0]
000077a0e99dd13a  add rsp, 0xF0
000077a0e99dd141  pop r11
000077a0e99dd143  pop r10
000077a0e99dd145  pop r9
000077a0e99dd147  pop r8
000077a0e99dd149  pop rsi
000077a0e99dd14a  pop rdi
000077a0e99dd14b  pop rdx
000077a0e99dd14c  pop rcx
000077a0e99dd14d  pop rax
000077a0e99dd14e  add rsp, 0x08
000077a0e99dd152  jmp 0x000077A0E99DA608
000077a0e99dd157  sub rsp, 0x08
000077a0e99dd15b  push rax
000077a0e99dd15c  push rcx
000077a0e99dd15d  push rdx
000077a0e99dd15e  push rdi
000077a0e99dd15f  push rsi
000077a0e99dd160  push r8
000077a0e99dd162  push r9
000077a0e99dd164  push r10
000077a0e99dd166  push r11
000077a0e99dd168  sub rsp, 0xF0
000077a0e99dd16f  vmovaps [rsp], xmm0
000077a0e99dd174  vmovaps [rsp+0x10], xmm1
000077a0e99dd17a  vmovaps [rsp+0x20], xmm2
000077a0e99dd180  vmovaps [rsp+0x30], xmm3
000077a0e99dd186  vmovaps [rsp+0x40], xmm4
000077a0e99dd18c  vmovaps [rsp+0x50], xmm5
000077a0e99dd192  vmovaps [rsp+0x60], xmm6
000077a0e99dd198  vmovaps [rsp+0x70], xmm7
000077a0e99dd19e  vmovaps [rsp+0x80], xmm8
000077a0e99dd1a7  vmovaps [rsp+0x90], xmm9
000077a0e99dd1b0  vmovaps [rsp+0xA0], xmm10
000077a0e99dd1b9  vmovaps [rsp+0xB0], xmm11
000077a0e99dd1c2  vmovaps [rsp+0xC0], xmm12
000077a0e99dd1cb  vmovaps [rsp+0xD0], xmm13
000077a0e99dd1d4  vmovaps [rsp+0xE0], xmm15
000077a0e99dd1dd  sub rsp, 0x40
000077a0e99dd1e1  lea rdi, [rsp]
000077a0e99dd1e5  lea rsi, [rsp+0x10]
000077a0e99dd1ea  lea rdx, [rsp+0x20]
000077a0e99dd1ef  lea rcx, [rsp+0x30]
000077a0e99dd1f4  mov r8d, 0x00
000077a0e99dd1fa  lea r9, [r15+0x3A8]
000077a0e99dd201  movaps [rdi], xmm14
000077a0e99dd205  movaps [rsi], xmm11
000077a0e99dd209  movaps [rdx], xmm1
000077a0e99dd20c  movaps [rcx], xmm15
000077a0e99dd210  mov rax, 0x60CAA235BA50
000077a0e99dd21a  call rax
000077a0e99dd21c  movaps xmm14, [rsp]
000077a0e99dd221  add rsp, 0x40
000077a0e99dd225  vmovaps xmm0, [rsp]
000077a0e99dd22a  vmovaps xmm1, [rsp+0x10]
000077a0e99dd230  vmovaps xmm2, [rsp+0x20]
000077a0e99dd236  vmovaps xmm3, [rsp+0x30]
000077a0e99dd23c  vmovaps xmm4, [rsp+0x40]
000077a0e99dd242  vmovaps xmm5, [rsp+0x50]
000077a0e99dd248  vmovaps xmm6, [rsp+0x60]
000077a0e99dd24e  vmovaps xmm7, [rsp+0x70]
000077a0e99dd254  vmovaps xmm8, [rsp+0x80]
000077a0e99dd25d  vmovaps xmm9, [rsp+0x90]
000077a0e99dd266  vmovaps xmm10, [rsp+0xA0]
000077a0e99dd26f  vmovaps xmm11, [rsp+0xB0]
000077a0e99dd278  vmovaps xmm12, [rsp+0xC0]
000077a0e99dd281  vmovaps xmm13, [rsp+0xD0]
000077a0e99dd28a  vmovaps xmm15, [rsp+0xE0]
000077a0e99dd293  add rsp, 0xF0
000077a0e99dd29a  pop r11
000077a0e99dd29c  pop r10
000077a0e99dd29e  pop r9
000077a0e99dd2a0  pop r8
000077a0e99dd2a2  pop rsi
000077a0e99dd2a3  pop rdi
000077a0e99dd2a4  pop rdx
000077a0e99dd2a5  pop rcx
000077a0e99dd2a6  pop rax
000077a0e99dd2a7  add rsp, 0x08
000077a0e99dd2ab  jmp 0x000077A0E99DA636
000077a0e99dd2b0  call 0x000077A0E98079B0
000077a0e99dd2b5  jmp 0x000077A0E99DA64C
000077a0e99dd2ba  call 0x000077A0E98E3440
000077a0e99dd2bf  jmp 0x000077A0E99DA656
000077a0e99dd2c4  call 0x000077A0E98DFCE0
000077a0e99dd2c9  jmp 0x000077A0E99DA660
000077a0e99dd2ce  call 0x000077A0E98E46C0
000077a0e99dd2d3  jmp 0x000077A0E99DA66A
000077a0e99dd2d8  int3
000077a0e99dd2d9  nop [rax], eax
000077a0e99dd2e0  mov qword ptr [r15+0x40], 0x430000
000077a0e99dd2e8  mov eax, 0x430C50
000077a0e99dd2ed  mov r14, [r13+rax*1]
000077a0e99dd2f2  movq xmm1, r14
000077a0e99dd2f7  mov rax, [r15+0x50]
000077a0e99dd2fb  movups xmm15, [r13+rax*1]
000077a0e99dd301  movaps [r15+0x120], xmm15
000077a0e99dd309  mov qword ptr [r15+0x48], 0x10
000077a0e99dd311  xor eax, eax
000077a0e99dd313  mov r14d, 0x10
000077a0e99dd319  mov r12d, 0x200
000077a0e99dd31f  cmp r14, r12
000077a0e99dd322  cmc
000077a0e99dd323  lahf
000077a0e99dd324  seto al
000077a0e99dd327  mov [r15+0x108], eax
000077a0e99dd32e  pextrq rax, xmm15, 0x01
000077a0e99dd335  movq xmm14, rax
000077a0e99dd33a  movaps [r15+0x130], xmm14
000077a0e99dd342  movq rax, xmm1
000077a0e99dd347  movq r14, xmm15
000077a0e99dd34c  vmovq xmm1, rax
000077a0e99dd351  vmovq xmm15, r14
000077a0e99dd356  movaps xmm13, xmm1
000077a0e99dd35a  addsd xmm13, xmm15
000077a0e99dd35f  ucomisd xmm13, xmm13
000077a0e99dd364  jp 0x000077A0E99DD423
000077a0e99dd36a  movq xmm13, xmm13
000077a0e99dd36f  movq rax, xmm13
000077a0e99dd374  movq r14, xmm14
000077a0e99dd379  vmovq xmm1, rax
000077a0e99dd37e  vmovq xmm15, r14
000077a0e99dd383  movaps xmm14, xmm1
000077a0e99dd387  addsd xmm14, xmm15
000077a0e99dd38c  ucomisd xmm14, xmm14
000077a0e99dd391  jp 0x000077A0E99DD46B
000077a0e99dd397  movq xmm14, xmm14
000077a0e99dd39c  movaps [r15+0x110], xmm14
000077a0e99dd3a4  mov eax, [r15+0x108]
000077a0e99dd3ab  sahf
000077a0e99dd3ac  jnz 0x000077A0E99DD3DE
000077a0e99dd3ae  cmp dword ptr [r15+0x318], 0x00
000077a0e99dd3b6  jz 0x000077A0E99DD680
000077a0e99dd3bc  nop [rax+rax*1], ax
000077a0e99dd3c5  nop [rax+rax*1], eax
000077a0e99dd3cd  mov eax, 0x410698
000077a0e99dd3d2  mov [r15+0x100], rax
000077a0e99dd3d9  jmp 0x000077A0E97FE110
000077a0e99dd3de  cmp dword ptr [r15+0x318], 0x00
000077a0e99dd3e6  jz 0x000077A0E99DD4C0
000077a0e99dd3ec  nop [rax+rax*1], ax
000077a0e99dd3f5  nop [rax+rax*1], eax
000077a0e99dd3fd  mov eax, 0x41067C
000077a0e99dd402  mov [r15+0x100], rax
000077a0e99dd409  jmp 0x000077A0E97FE110
000077a0e99dd40e  int3
000077a0e99dd40f  call 0x000077A0E980DC20
000077a0e99dd414  jmp 0x000077A0E99DD2F2
000077a0e99dd419  call 0x000077A0E980E760
000077a0e99dd41e  jmp 0x000077A0E99DD301
000077a0e99dd423  ucomisd xmm1, xmm15
000077a0e99dd428  jp 0x000077A0E99DD437
000077a0e99dd42a  movaps xmm13, [0x000077A0E95FE060]
000077a0e99dd432  jmp 0x000077A0E99DD36A
000077a0e99dd437  vxorps xmm0, xmm1, xmm15
000077a0e99dd43c  pextrw eax, xmm0, 0x03
000077a0e99dd441  and eax, 0x7FF8
000077a0e99dd446  cmp eax, 0x08
000077a0e99dd449  jnz 0x000077A0E99DD36A
000077a0e99dd44f  movq rax, xmm15
000077a0e99dd454  shl rax, 0x0D
000077a0e99dd458  jbe 0x000077A0E99DD36A
000077a0e99dd45e  vorps xmm13, xmm15, [0x000077A0E95FE070]
000077a0e99dd466  jmp 0x000077A0E99DD36A
000077a0e99dd46b  ucomisd xmm1, xmm15
000077a0e99dd470  jp 0x000077A0E99DD47F
000077a0e99dd472  movaps xmm14, [0x000077A0E95FE060]
000077a0e99dd47a  jmp 0x000077A0E99DD397
000077a0e99dd47f  vxorps xmm0, xmm1, xmm15
000077a0e99dd484  pextrw eax, xmm0, 0x03
000077a0e99dd489  and eax, 0x7FF8
000077a0e99dd48e  cmp eax, 0x08
000077a0e99dd491  jnz 0x000077A0E99DD397
000077a0e99dd497  movq rax, xmm15
000077a0e99dd49c  shl rax, 0x0D
000077a0e99dd4a0  jbe 0x000077A0E99DD397
000077a0e99dd4a6  vorps xmm14, xmm15, [0x000077A0E95FE070]
000077a0e99dd4ae  jmp 0x000077A0E99DD397
000077a0e99dd4b3  int3
000077a0e99dd4b4  nop [rax+rax*1], ax
000077a0e99dd4bd  nop [rax], eax
000077a0e99dd4c0  mov rax, [r15+0x48]
000077a0e99dd4c4  mov r14, [r15+0x50]
000077a0e99dd4c8  lea r12, [r14+rax*1]
000077a0e99dd4cc  movups xmm1, [r13+r12*1]
000077a0e99dd4d2  movaps [r15+0x120], xmm1
000077a0e99dd4da  lea r14, [rax+0x10]
000077a0e99dd4de  mov [r15+0x48], r14
000077a0e99dd4e2  xor eax, eax
000077a0e99dd4e4  mov r12d, 0x200
000077a0e99dd4ea  cmp r14, r12
000077a0e99dd4ed  cmc
000077a0e99dd4ee  lahf
000077a0e99dd4ef  seto al
000077a0e99dd4f2  mov [r15+0x108], eax
000077a0e99dd4f9  pextrq rax, xmm1, 0x01
000077a0e99dd500  movq xmm15, rax
000077a0e99dd505  movaps [r15+0x130], xmm15
000077a0e99dd50d  movaps xmm14, [r15+0x110]
000077a0e99dd515  movq rax, xmm14
000077a0e99dd51a  movq r14, xmm1
000077a0e99dd51f  vmovq xmm1, rax
000077a0e99dd524  vmovq xmm14, r14
000077a0e99dd529  movaps xmm13, xmm1
000077a0e99dd52d  addsd xmm13, xmm14
000077a0e99dd532  ucomisd xmm13, xmm13
000077a0e99dd537  jp 0x000077A0E99DD5EC
000077a0e99dd53d  movq xmm13, xmm13
000077a0e99dd542  movq rax, xmm13
000077a0e99dd547  movq r14, xmm15
000077a0e99dd54c  vmovq xmm1, rax
000077a0e99dd551  vmovq xmm15, r14
000077a0e99dd556  movaps xmm14, xmm1
000077a0e99dd55a  addsd xmm14, xmm15
000077a0e99dd55f  ucomisd xmm14, xmm14
000077a0e99dd564  jp 0x000077A0E99DD634
000077a0e99dd56a  movq xmm14, xmm14
000077a0e99dd56f  movaps [r15+0x110], xmm14
000077a0e99dd577  mov eax, [r15+0x108]
000077a0e99dd57e  sahf
000077a0e99dd57f  jnz 0x000077A0E99DD5B1
000077a0e99dd581  cmp dword ptr [r15+0x318], 0x00
000077a0e99dd589  jz 0x000077A0E99DD680
000077a0e99dd58f  nop [rax+rax*1], ax
000077a0e99dd598  nop [rax+rax*1], eax
000077a0e99dd5a0  mov eax, 0x410698
000077a0e99dd5a5  mov [r15+0x100], rax
000077a0e99dd5ac  jmp 0x000077A0E97FE110
000077a0e99dd5b1  cmp dword ptr [r15+0x318], 0x00
000077a0e99dd5b9  jz 0x000077A0E99DD4C0
000077a0e99dd5bf  nop [rax+rax*1], ax
000077a0e99dd5c8  nop [rax+rax*1], eax
000077a0e99dd5d0  mov eax, 0x41067C
000077a0e99dd5d5  mov [r15+0x100], rax
000077a0e99dd5dc  jmp 0x000077A0E97FE110
000077a0e99dd5e1  int3
000077a0e99dd5e2  call 0x000077A0E98B52F0
000077a0e99dd5e7  jmp 0x000077A0E99DD4D2
000077a0e99dd5ec  ucomisd xmm1, xmm14
000077a0e99dd5f1  jp 0x000077A0E99DD600
000077a0e99dd5f3  movaps xmm13, [0x000077A0E95FE060]
000077a0e99dd5fb  jmp 0x000077A0E99DD53D
000077a0e99dd600  vxorps xmm0, xmm1, xmm14
000077a0e99dd605  pextrw eax, xmm0, 0x03
000077a0e99dd60a  and eax, 0x7FF8
000077a0e99dd60f  cmp eax, 0x08
000077a0e99dd612  jnz 0x000077A0E99DD53D
000077a0e99dd618  movq rax, xmm14
000077a0e99dd61d  shl rax, 0x0D
000077a0e99dd621  jbe 0x000077A0E99DD53D
000077a0e99dd627  vorps xmm13, xmm14, [0x000077A0E95FE070]
000077a0e99dd62f  jmp 0x000077A0E99DD53D
000077a0e99dd634  ucomisd xmm1, xmm15
000077a0e99dd639  jp 0x000077A0E99DD648
000077a0e99dd63b  movaps xmm14, [0x000077A0E95FE060]
000077a0e99dd643  jmp 0x000077A0E99DD56A
000077a0e99dd648  vxorps xmm0, xmm1, xmm15
000077a0e99dd64d  pextrw eax, xmm0, 0x03
000077a0e99dd652  and eax, 0x7FF8
000077a0e99dd657  cmp eax, 0x08
000077a0e99dd65a  jnz 0x000077A0E99DD56A
000077a0e99dd660  movq rax, xmm15
000077a0e99dd665  shl rax, 0x0D
000077a0e99dd669  jbe 0x000077A0E99DD56A
000077a0e99dd66f  vorps xmm14, xmm15, [0x000077A0E95FE070]
000077a0e99dd677  jmp 0x000077A0E99DD56A
000077a0e99dd67c  int3
000077a0e99dd67d  nop [rax], eax
000077a0e99dd680  mov rax, [r15+0xF8]
000077a0e99dd687  lea r14, [rax+0x1A0]
000077a0e99dd68e  mov r12, [r13+r14*1]
000077a0e99dd693  lea r14, [rax+0x1A8]
000077a0e99dd69a  mov r11, [r13+r14*1]
000077a0e99dd69f  mov [r15+0xA0], r12
000077a0e99dd6a6  mov [r15+0x98], r11
000077a0e99dd6ad  mov r14, [r15+0x40]
000077a0e99dd6b1  lea r12, [r14+0xC50]
000077a0e99dd6b8  movaps xmm1, [r15+0x110]
000077a0e99dd6c0  movq r14, xmm1
000077a0e99dd6c5  mov [r13+r12*1], r14
000077a0e99dd6ca  lea r14, [rax+0x190]
000077a0e99dd6d1  mov r12, [r13+r14*1]
000077a0e99dd6d6  lea r14, [rax+0x198]
000077a0e99dd6dd  mov r11, [r13+r14*1]
000077a0e99dd6e2  mov [r15+0xE8], r12
000077a0e99dd6e9  mov [r15+0xF0], r11
000077a0e99dd6f0  lea r14, [rax+0x180]
000077a0e99dd6f7  mov r12, [r13+r14*1]
000077a0e99dd6fc  lea r14, [rax+0x188]
000077a0e99dd703  mov r10, [r13+r14*1]
000077a0e99dd708  movq xmm1, r12
000077a0e99dd70d  movq xmm15, r10
000077a0e99dd712  movq xmm1, xmm1
000077a0e99dd716  movq xmm1, xmm1
000077a0e99dd71a  movaps [r15+0x1A0], xmm1
000077a0e99dd722  movq xmm15, xmm15
000077a0e99dd727  movq xmm15, xmm15
000077a0e99dd72c  movaps [r15+0x190], xmm15
000077a0e99dd734  lea r14, [rax+0x170]
000077a0e99dd73b  mov r12, [r13+r14*1]
000077a0e99dd740  lea r14, [rax+0x178]
000077a0e99dd747  mov r10, [r13+r14*1]
000077a0e99dd74c  movq xmm1, r12
000077a0e99dd751  movq xmm15, r10
000077a0e99dd756  movq xmm1, xmm1
000077a0e99dd75a  movq xmm1, xmm1
000077a0e99dd75e  movaps [r15+0x1C0], xmm1
000077a0e99dd766  movq xmm15, xmm15
000077a0e99dd76b  movq xmm15, xmm15
000077a0e99dd770  movaps [r15+0x1B0], xmm15
000077a0e99dd778  lea r14, [rax+0x160]
000077a0e99dd77f  mov r12, [r13+r14*1]
000077a0e99dd784  lea r14, [rax+0x168]
000077a0e99dd78b  mov r10, [r13+r14*1]
000077a0e99dd790  movq xmm1, r12
000077a0e99dd795  movq xmm15, r10
000077a0e99dd79a  movq xmm1, xmm1
000077a0e99dd79e  movq xmm1, xmm1
000077a0e99dd7a2  movaps [r15+0x1E0], xmm1
000077a0e99dd7aa  movq xmm15, xmm15
000077a0e99dd7af  movq xmm15, xmm15
000077a0e99dd7b4  movaps [r15+0x1D0], xmm15
000077a0e99dd7bc  lea r14, [rax+0x150]
000077a0e99dd7c3  mov r12, [r13+r14*1]
000077a0e99dd7c8  lea r14, [rax+0x158]
000077a0e99dd7cf  mov r10, [r13+r14*1]
000077a0e99dd7d4  movq xmm1, r12
000077a0e99dd7d9  movq xmm15, r10
000077a0e99dd7de  movq xmm1, xmm1
000077a0e99dd7e2  movq xmm1, xmm1
000077a0e99dd7e6  movaps [r15+0x200], xmm1
000077a0e99dd7ee  movq xmm15, xmm15
000077a0e99dd7f3  movq xmm15, xmm15
000077a0e99dd7f8  movaps [r15+0x1F0], xmm15
000077a0e99dd800  lea r14, [rax+0x1B0]
000077a0e99dd807  mov [r15+0xF8], r14
000077a0e99dd80e  mov [r15+0x100], r11
000077a0e99dd815  jmp 0x000077A0E99CE5C0
000077a0e99dd81a  int3
000077a0e99dd81b  call 0x000077A0E98E27E0
000077a0e99dd820  jmp 0x000077A0E99DD693
000077a0e99dd825  call 0x000077A0E98E1570
000077a0e99dd82a  jmp 0x000077A0E99DD69F
000077a0e99dd82f  call 0x000077A0E98C3FE0
000077a0e99dd834  jmp 0x000077A0E99DD6CA
000077a0e99dd839  call 0x000077A0E98E27E0
000077a0e99dd83e  jmp 0x000077A0E99DD6D6
000077a0e99dd843  call 0x000077A0E98E1570
000077a0e99dd848  jmp 0x000077A0E99DD6E2
000077a0e99dd84d  call 0x000077A0E98E27E0
000077a0e99dd852  jmp 0x000077A0E99DD6FC
000077a0e99dd857  call 0x000077A0E98E0300
000077a0e99dd85c  jmp 0x000077A0E99DD708
000077a0e99dd861  call 0x000077A0E98E27E0
000077a0e99dd866  jmp 0x000077A0E99DD740
000077a0e99dd86b  call 0x000077A0E98E0300
000077a0e99dd870  jmp 0x000077A0E99DD74C
000077a0e99dd875  call 0x000077A0E98E27E0
000077a0e99dd87a  jmp 0x000077A0E99DD784
000077a0e99dd87f  call 0x000077A0E98E0300
000077a0e99dd884  jmp 0x000077A0E99DD790
000077a0e99dd889  call 0x000077A0E98E27E0
000077a0e99dd88e  jmp 0x000077A0E99DD7C8
000077a0e99dd893  call 0x000077A0E98E0300
000077a0e99dd898  jmp 0x000077A0E99DD7D4
000077a0e99dd89d  int3
000077a0e99dd89e  nop
000077a0e99dd8a0  mov qword ptr [r15+0x100], 0x04
000077a0e99dd8ab  mov esi, 0x00
000077a0e99dd8b0  mov edx, 0x09
000077a0e99dd8b5  mov rdi, 0x7FFD342930A0
000077a0e99dd8bf  mov rax, 0x60CAA21EE970
000077a0e99dd8c9  call rax
000077a0e99dd8cb  cmp dword ptr [r15+0x318], 0x00
000077a0e99dd8d3  jnz 0x000077A0E97FE110
000077a0e99dd8d9  jmp 0x000077A0E97FE0A0
000077a0e99dd8de  int3
000077a0e99dd8df  int3
