00007f4f7cbce69b  nop [rax+rax*1], eax
00007f4f7cbce6a0  mov rax, [r15+0xF8]
00007f4f7cbce6a7  lea r14, [rax-0x1B0]
00007f4f7cbce6ae  mov [r15+0xF8], r14
00007f4f7cbce6b5  lea rax, [r14+0x1A0]
00007f4f7cbce6bc  mov r12, [r15+0xA0]
00007f4f7cbce6c3  mov r11, [r15+0x98]
00007f4f7cbce6ca  mov [r13+rax*1], r12
00007f4f7cbce6cf  lea rax, [r14+0x1A8]
00007f4f7cbce6d6  mov [r13+rax*1], r11
00007f4f7cbce6db  mov eax, 0x420A30
00007f4f7cbce6e0  movups xmm1, [r13+rax*1]
00007f4f7cbce6e6  mov eax, 0x4209C0
00007f4f7cbce6eb  movups xmm15, [r13+rax*1]
00007f4f7cbce6f1  mov eax, 0x420A50
00007f4f7cbce6f6  movups xmm14, [r13+rax*1]
00007f4f7cbce6fc  mov eax, 0x4209F0
00007f4f7cbce701  movups xmm13, [r13+rax*1]
00007f4f7cbce707  mov qword ptr [r15+0x98], 0x430C60
00007f4f7cbce712  mov eax, 0x420A60
00007f4f7cbce717  movups xmm12, [r13+rax*1]
00007f4f7cbce71d  mov eax, 0x430C60
00007f4f7cbce722  movups [r13+rax*1], xmm1
00007f4f7cbce728  mov eax, 0x430C70
00007f4f7cbce72d  movups [r13+rax*1], xmm15
00007f4f7cbce733  mov eax, 0x430C80
00007f4f7cbce738  movups [r13+rax*1], xmm14
00007f4f7cbce73e  mov eax, 0x430C90
00007f4f7cbce743  movups [r13+rax*1], xmm13
00007f4f7cbce749  mov eax, 0x4209B0
00007f4f7cbce74e  movups xmm14, [r13+rax*1]
00007f4f7cbce754  mov eax, 0x4209A0
00007f4f7cbce759  movups xmm13, [r13+rax*1]
00007f4f7cbce75f  mov eax, 0x430D60
00007f4f7cbce764  movups [r13+rax*1], xmm1
00007f4f7cbce76a  mov eax, 0x430D70
00007f4f7cbce76f  movups [r13+rax*1], xmm15
00007f4f7cbce775  mov eax, 0x430CA0
00007f4f7cbce77a  movups [r13+rax*1], xmm12
00007f4f7cbce780  mov eax, 0x430CB0
00007f4f7cbce785  movups [r13+rax*1], xmm14
00007f4f7cbce78b  mov eax, 0x420990
00007f4f7cbce790  movups xmm1, [r13+rax*1]
00007f4f7cbce796  mov eax, 0x420A00
00007f4f7cbce79b  movups xmm15, [r13+rax*1]
00007f4f7cbce7a1  mov eax, 0x430CC0
00007f4f7cbce7a6  movups [r13+rax*1], xmm13
00007f4f7cbce7ac  mov eax, 0x430CD0
00007f4f7cbce7b1  movups [r13+rax*1], xmm1
00007f4f7cbce7b7  mov eax, 0x420A10
00007f4f7cbce7bc  movups xmm1, [r13+rax*1]
00007f4f7cbce7c2  mov eax, 0x4209E0
00007f4f7cbce7c7  movups xmm14, [r13+rax*1]
00007f4f7cbce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007f4f7cbce7d5  mov eax, 0x430CE0
00007f4f7cbce7da  movups [r13+rax*1], xmm15
00007f4f7cbce7e0  mov eax, 0x430CF0
00007f4f7cbce7e5  movups [r13+rax*1], xmm1
00007f4f7cbce7eb  mov eax, 0x420A80
00007f4f7cbce7f0  movups xmm1, [r13+rax*1]
00007f4f7cbce7f6  mov eax, 0x420A90
00007f4f7cbce7fb  movups xmm15, [r13+rax*1]
00007f4f7cbce801  movaps [r15+0x150], xmm15
00007f4f7cbce809  mov qword ptr [r15+0xA0], 0x3E8
00007f4f7cbce814  mov eax, 0x430D00
00007f4f7cbce819  movups [r13+rax*1], xmm14
00007f4f7cbce81f  mov eax, 0x430D10
00007f4f7cbce824  movups [r13+rax*1], xmm1
00007f4f7cbce82a  mov eax, 0x420A70
00007f4f7cbce82f  movups xmm1, [r13+rax*1]
00007f4f7cbce835  mov eax, 0x420A20
00007f4f7cbce83a  movups xmm14, [r13+rax*1]
00007f4f7cbce840  movaps [r15+0x140], xmm14
00007f4f7cbce848  lea rax, [r14+0x150]
00007f4f7cbce84f  movq xmm13, qword ptr [r15+0x200]
00007f4f7cbce858  movq xmm12, qword ptr [r15+0x1F0]
00007f4f7cbce861  movq r12, xmm13
00007f4f7cbce866  movq r11, xmm12
00007f4f7cbce86b  mov [r13+rax*1], r12
00007f4f7cbce870  lea rax, [r14+0x158]
00007f4f7cbce877  mov [r13+rax*1], r11
00007f4f7cbce87c  mov eax, 0x430D20
00007f4f7cbce881  movups [r13+rax*1], xmm15
00007f4f7cbce887  mov eax, 0x430D30
00007f4f7cbce88c  movups [r13+rax*1], xmm1
00007f4f7cbce892  mov eax, 0x420A40
00007f4f7cbce897  movups xmm1, [r13+rax*1]
00007f4f7cbce89d  mov eax, 0x420AA8
00007f4f7cbce8a2  mov r12, [r13+rax*1]
00007f4f7cbce8a7  movq xmm15, r12
00007f4f7cbce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007f4f7cbce8b4  mov eax, 0x430D40
00007f4f7cbce8b9  movups [r13+rax*1], xmm14
00007f4f7cbce8bf  mov eax, 0x430D50
00007f4f7cbce8c4  movups [r13+rax*1], xmm1
00007f4f7cbce8ca  mov eax, 0x420B10
00007f4f7cbce8cf  movups xmm1, [r13+rax*1]
00007f4f7cbce8d5  movq rax, xmm15
00007f4f7cbce8da  mov r12d, 0x430D80
00007f4f7cbce8e0  mov [r13+r12*1], rax
00007f4f7cbce8e5  mov eax, 0x420AF0
00007f4f7cbce8ea  movups xmm15, [r13+rax*1]
00007f4f7cbce8f0  mov eax, 0x420B00
00007f4f7cbce8f5  movups xmm14, [r13+rax*1]
00007f4f7cbce8fb  lea rax, [r14+0x130]
00007f4f7cbce902  movups [r13+rax*1], xmm1
00007f4f7cbce908  lea rax, [r14+0x160]
00007f4f7cbce90f  movq xmm1, qword ptr [r15+0x1E0]
00007f4f7cbce918  movq xmm13, qword ptr [r15+0x1D0]
00007f4f7cbce921  movq r12, xmm1
00007f4f7cbce926  movq r11, xmm13
00007f4f7cbce92b  mov [r13+rax*1], r12
00007f4f7cbce930  lea rax, [r14+0x168]
00007f4f7cbce937  mov [r13+rax*1], r11
00007f4f7cbce93c  lea rax, [r14+0x110]
00007f4f7cbce943  movups [r13+rax*1], xmm15
00007f4f7cbce949  lea rax, [r14+0x120]
00007f4f7cbce950  movups [r13+rax*1], xmm14
00007f4f7cbce956  mov eax, 0x420AB0
00007f4f7cbce95b  movups xmm1, [r13+rax*1]
00007f4f7cbce961  mov eax, 0x420AC0
00007f4f7cbce966  movups xmm15, [r13+rax*1]
00007f4f7cbce96c  movaps [r15+0x120], xmm15
00007f4f7cbce974  lea rax, [r14+0x170]
00007f4f7cbce97b  movq xmm14, qword ptr [r15+0x1C0]
00007f4f7cbce984  movq xmm13, qword ptr [r15+0x1B0]
00007f4f7cbce98d  movq r12, xmm14
00007f4f7cbce992  movq r11, xmm13
00007f4f7cbce997  mov [r13+rax*1], r12
00007f4f7cbce99c  lea rax, [r14+0x178]
00007f4f7cbce9a3  mov [r13+rax*1], r11
00007f4f7cbce9a8  lea rax, [r14+0x180]
00007f4f7cbce9af  movq xmm14, qword ptr [r15+0x1A0]
00007f4f7cbce9b8  movq xmm13, qword ptr [r15+0x190]
00007f4f7cbce9c1  movq r12, xmm14
00007f4f7cbce9c6  movq r11, xmm13
00007f4f7cbce9cb  mov [r13+rax*1], r12
00007f4f7cbce9d0  lea rax, [r14+0x188]
00007f4f7cbce9d7  mov [r13+rax*1], r11
00007f4f7cbce9dc  lea rax, [r14+0xD0]
00007f4f7cbce9e3  movups [r13+rax*1], xmm1
00007f4f7cbce9e9  lea rax, [r14+0xE0]
00007f4f7cbce9f0  movups [r13+rax*1], xmm15
00007f4f7cbce9f6  mov eax, 0x420AD0
00007f4f7cbce9fb  movups xmm1, [r13+rax*1]
00007f4f7cbcea01  mov eax, 0x420AE0
00007f4f7cbcea06  movups xmm15, [r13+rax*1]
00007f4f7cbcea0c  movaps [r15+0x110], xmm1
00007f4f7cbcea14  movaps [r15+0x130], xmm15
00007f4f7cbcea1c  lea rax, [r14+0x190]
00007f4f7cbcea23  mov r12, [r15+0xE8]
00007f4f7cbcea2a  mov r11, [r15+0xF0]
00007f4f7cbcea31  mov [r13+rax*1], r12
00007f4f7cbcea36  lea rax, [r14+0x198]
00007f4f7cbcea3d  mov [r13+rax*1], r11
00007f4f7cbcea42  mov eax, 0x430D88
00007f4f7cbcea47  mov r12d, 0x421DF8D3
00007f4f7cbcea4d  mov [r13+rax*1], r12d
00007f4f7cbcea52  lea rax, [r14+0xF0]
00007f4f7cbcea59  movups [r13+rax*1], xmm1
00007f4f7cbcea5f  lea rax, [r14+0x100]
00007f4f7cbcea66  movups [r13+rax*1], xmm15
00007f4f7cbcea6c  lea rax, [r14+0xD0]
00007f4f7cbcea73  mov [r15], rax
00007f4f7cbcea76  mov qword ptr [r15+0x08], 0x430C60
00007f4f7cbcea7e  mov qword ptr [r15+0x10], 0x12C
00007f4f7cbcea86  mov qword ptr [r15+0xF0], 0x410284
00007f4f7cbcea91  mov r14d, [r15+0x320]
00007f4f7cbcea98  mov eax, 0x410284
00007f4f7cbcea9d  mov rcx, 0x7F4F7CBD07C0
00007f4f7cbceaa7  mov [r15+r14*8+0x328], rax
00007f4f7cbceaaf  mov [r15+r14*8+0x368], rcx
00007f4f7cbceab7  add r14d, 0x01
00007f4f7cbceabb  and r14d, 0x07
00007f4f7cbceabf  mov [r15+0x320], r14d
00007f4f7cbceac6  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbceace  jz 0x00007F4F7CBCED70
00007f4f7cbcead4  nop [rax+rax*1], ax
00007f4f7cbceadd  nop [rax+rax*1], eax
00007f4f7cbceae5  mov eax, 0x4106BC
00007f4f7cbceaea  mov [r15+0x100], rax
00007f4f7cbceaf1  jmp 0x00007F4F7C9FE110
00007f4f7cbceaf6  int3
00007f4f7cbceaf7  call 0x00007F4F7CA0BC20
00007f4f7cbceafc  jmp 0x00007F4F7CBCE6CF
00007f4f7cbceb01  call 0x00007F4F7CA0A9A0
00007f4f7cbceb06  jmp 0x00007F4F7CBCE6DB
00007f4f7cbceb0b  call 0x00007F4F7C9FF430
00007f4f7cbceb10  jmp 0x00007F4F7CBCE6E6
00007f4f7cbceb15  call 0x00007F4F7CA0E760
00007f4f7cbceb1a  jmp 0x00007F4F7CBCE6F1
00007f4f7cbceb1f  call 0x00007F4F7CA0D4E0
00007f4f7cbceb24  jmp 0x00007F4F7CBCE6FC
00007f4f7cbceb29  call 0x00007F4F7CA0C260
00007f4f7cbceb2e  jmp 0x00007F4F7CBCE707
00007f4f7cbceb33  call 0x00007F4F7CA0AFE0
00007f4f7cbceb38  jmp 0x00007F4F7CBCE71D
00007f4f7cbceb3d  call 0x00007F4F7C9FF540
00007f4f7cbceb42  jmp 0x00007F4F7CBCE728
00007f4f7cbceb47  call 0x00007F4F7CA0E880
00007f4f7cbceb4c  jmp 0x00007F4F7CBCE733
00007f4f7cbceb51  call 0x00007F4F7CA0D600
00007f4f7cbceb56  jmp 0x00007F4F7CBCE73E
00007f4f7cbceb5b  call 0x00007F4F7CA0C380
00007f4f7cbceb60  jmp 0x00007F4F7CBCE749
00007f4f7cbceb65  call 0x00007F4F7CA0D4E0
00007f4f7cbceb6a  jmp 0x00007F4F7CBCE754
00007f4f7cbceb6f  call 0x00007F4F7CA0C260
00007f4f7cbceb74  jmp 0x00007F4F7CBCE75F
00007f4f7cbceb79  call 0x00007F4F7C9FF540
00007f4f7cbceb7e  jmp 0x00007F4F7CBCE76A
00007f4f7cbceb83  call 0x00007F4F7CA0E880
00007f4f7cbceb88  jmp 0x00007F4F7CBCE775
00007f4f7cbceb8d  call 0x00007F4F7CA0B100
00007f4f7cbceb92  jmp 0x00007F4F7CBCE780
00007f4f7cbceb97  call 0x00007F4F7CA0D600
00007f4f7cbceb9c  jmp 0x00007F4F7CBCE78B
00007f4f7cbceba1  call 0x00007F4F7C9FF430
00007f4f7cbceba6  jmp 0x00007F4F7CBCE796
00007f4f7cbcebab  call 0x00007F4F7CA0E760
00007f4f7cbcebb0  jmp 0x00007F4F7CBCE7A1
00007f4f7cbcebb5  call 0x00007F4F7CA0C380
00007f4f7cbcebba  jmp 0x00007F4F7CBCE7AC
00007f4f7cbcebbf  call 0x00007F4F7C9FF540
00007f4f7cbcebc4  jmp 0x00007F4F7CBCE7B7
00007f4f7cbcebc9  call 0x00007F4F7C9FF430
00007f4f7cbcebce  jmp 0x00007F4F7CBCE7C2
00007f4f7cbcebd3  call 0x00007F4F7CA0D4E0
00007f4f7cbcebd8  jmp 0x00007F4F7CBCE7CD
00007f4f7cbcebdd  call 0x00007F4F7CA0E880
00007f4f7cbcebe2  jmp 0x00007F4F7CBCE7E0
00007f4f7cbcebe7  call 0x00007F4F7C9FF540
00007f4f7cbcebec  jmp 0x00007F4F7CBCE7EB
00007f4f7cbcebf1  call 0x00007F4F7C9FF430
00007f4f7cbcebf6  jmp 0x00007F4F7CBCE7F6
00007f4f7cbcebfb  call 0x00007F4F7CA0E760
00007f4f7cbcec00  jmp 0x00007F4F7CBCE801
00007f4f7cbcec05  call 0x00007F4F7CA0D600
00007f4f7cbcec0a  jmp 0x00007F4F7CBCE81F
00007f4f7cbcec0f  call 0x00007F4F7C9FF540
00007f4f7cbcec14  jmp 0x00007F4F7CBCE82A
00007f4f7cbcec19  call 0x00007F4F7C9FF430
00007f4f7cbcec1e  jmp 0x00007F4F7CBCE835
00007f4f7cbcec23  call 0x00007F4F7CA0D4E0
00007f4f7cbcec28  jmp 0x00007F4F7CBCE840
00007f4f7cbcec2d  call 0x00007F4F7CA0BC20
00007f4f7cbcec32  jmp 0x00007F4F7CBCE870
00007f4f7cbcec37  call 0x00007F4F7CA0A9A0
00007f4f7cbcec3c  jmp 0x00007F4F7CBCE87C
00007f4f7cbcec41  call 0x00007F4F7CA0E880
00007f4f7cbcec46  jmp 0x00007F4F7CBCE887
00007f4f7cbcec4b  call 0x00007F4F7C9FF540
00007f4f7cbcec50  jmp 0x00007F4F7CBCE892
00007f4f7cbcec55  call 0x00007F4F7C9FF430
00007f4f7cbcec5a  jmp 0x00007F4F7CBCE89D
00007f4f7cbcec5f  call 0x00007F4F7CA0B720
00007f4f7cbcec64  jmp 0x00007F4F7CBCE8A7
00007f4f7cbcec69  call 0x00007F4F7CA0D600
00007f4f7cbcec6e  jmp 0x00007F4F7CBCE8BF
00007f4f7cbcec73  call 0x00007F4F7C9FF540
00007f4f7cbcec78  jmp 0x00007F4F7CBCE8CA
00007f4f7cbcec7d  call 0x00007F4F7C9FF430
00007f4f7cbcec82  jmp 0x00007F4F7CBCE8D5
00007f4f7cbcec87  call 0x00007F4F7CAB4CB0
00007f4f7cbcec8c  jmp 0x00007F4F7CBCE8E5
00007f4f7cbcec91  call 0x00007F4F7CA0E760
00007f4f7cbcec96  jmp 0x00007F4F7CBCE8F0
00007f4f7cbcec9b  call 0x00007F4F7CA0D4E0
00007f4f7cbceca0  jmp 0x00007F4F7CBCE8FB
00007f4f7cbceca5  call 0x00007F4F7C9FF540
00007f4f7cbcecaa  jmp 0x00007F4F7CBCE908
00007f4f7cbcecaf  call 0x00007F4F7CA0BC20
00007f4f7cbcecb4  jmp 0x00007F4F7CBCE930
00007f4f7cbcecb9  call 0x00007F4F7CA0A9A0
00007f4f7cbcecbe  jmp 0x00007F4F7CBCE93C
00007f4f7cbcecc3  call 0x00007F4F7CA0E880
00007f4f7cbcecc8  jmp 0x00007F4F7CBCE949
00007f4f7cbceccd  call 0x00007F4F7CA0D600
00007f4f7cbcecd2  jmp 0x00007F4F7CBCE956
00007f4f7cbcecd7  call 0x00007F4F7C9FF430
00007f4f7cbcecdc  jmp 0x00007F4F7CBCE961
00007f4f7cbcece1  call 0x00007F4F7CA0E760
00007f4f7cbcece6  jmp 0x00007F4F7CBCE96C
00007f4f7cbceceb  call 0x00007F4F7CA0BC20
00007f4f7cbcecf0  jmp 0x00007F4F7CBCE99C
00007f4f7cbcecf5  call 0x00007F4F7CA0A9A0
00007f4f7cbcecfa  jmp 0x00007F4F7CBCE9A8
00007f4f7cbcecff  call 0x00007F4F7CA0BC20
00007f4f7cbced04  jmp 0x00007F4F7CBCE9D0
00007f4f7cbced09  call 0x00007F4F7CA0A9A0
00007f4f7cbced0e  jmp 0x00007F4F7CBCE9DC
00007f4f7cbced13  call 0x00007F4F7C9FF540
00007f4f7cbced18  jmp 0x00007F4F7CBCE9E9
00007f4f7cbced1d  call 0x00007F4F7CA0E880
00007f4f7cbced22  jmp 0x00007F4F7CBCE9F6
00007f4f7cbced27  call 0x00007F4F7C9FF430
00007f4f7cbced2c  jmp 0x00007F4F7CBCEA01
00007f4f7cbced31  call 0x00007F4F7CA0E760
00007f4f7cbced36  jmp 0x00007F4F7CBCEA0C
00007f4f7cbced3b  call 0x00007F4F7CA0BC20
00007f4f7cbced40  jmp 0x00007F4F7CBCEA36
00007f4f7cbced45  call 0x00007F4F7CA0A9A0
00007f4f7cbced4a  jmp 0x00007F4F7CBCEA42
00007f4f7cbced4f  call 0x00007F4F7CA0BAE0
00007f4f7cbced54  jmp 0x00007F4F7CBCEA52
00007f4f7cbced59  call 0x00007F4F7C9FF540
00007f4f7cbced5e  jmp 0x00007F4F7CBCEA5F
00007f4f7cbced63  call 0x00007F4F7CA0E880
00007f4f7cbced68  jmp 0x00007F4F7CBCEA6C
00007f4f7cbced6d  int3
00007f4f7cbced6e  nop
00007f4f7cbced70  mov rax, [r15]
00007f4f7cbced73  lea r14, [rax+0x20]
00007f4f7cbced77  mov r12, [r13+r14*1]
00007f4f7cbced7c  mov r14, [r15+0x10]
00007f4f7cbced80  lea r11, [r12+r14*1]
00007f4f7cbced84  mov [r15+0x40], r11
00007f4f7cbced88  lea r12, [rax+0x20]
00007f4f7cbced8c  mov [r13+r12*1], r11
00007f4f7cbced91  test r14, r14
00007f4f7cbced94  setz r14b
00007f4f7cbced98  movzx r14, r14b
00007f4f7cbced9c  mov [rsp+0x414], r14b
00007f4f7cbceda4  cmp byte ptr [rsp+0x414], 0x00
00007f4f7cbcedac  jz 0x00007F4F7CBCEDDE
00007f4f7cbcedae  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcedb6  mov eax, 0x410934
00007f4f7cbcedbb  mov [r15+0x100], rax
00007f4f7cbcedc2  jz 0x00007F4F7C9FE0A0
00007f4f7cbcedc8  nop [rax+rax*1], eax
00007f4f7cbcedcd  mov eax, 0x410934
00007f4f7cbcedd2  mov [r15+0x100], rax
00007f4f7cbcedd9  jmp 0x00007F4F7C9FE110
00007f4f7cbcedde  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcede6  jz 0x00007F4F7CBCEE30
00007f4f7cbcedec  nop [rax+rax*1], ax
00007f4f7cbcedf5  nop [rax+rax*1], eax
00007f4f7cbcedfd  mov eax, 0x4106CC
00007f4f7cbcee02  mov [r15+0x100], rax
00007f4f7cbcee09  jmp 0x00007F4F7C9FE110
00007f4f7cbcee0e  int3
00007f4f7cbcee0f  call 0x00007F4F7CAE27E0
00007f4f7cbcee14  jmp 0x00007F4F7CBCED7C
00007f4f7cbcee19  call 0x00007F4F7CAC0860
00007f4f7cbcee1e  jmp 0x00007F4F7CBCED91
00007f4f7cbcee23  int3
00007f4f7cbcee24  nop [rax+rax*1], ax
00007f4f7cbcee2d  nop [rax], eax
00007f4f7cbcee30  mov rax, [r15+0xF8]
00007f4f7cbcee37  lea r14, [rax-0x150]
00007f4f7cbcee3e  mov [r15+0xF8], r14
00007f4f7cbcee45  mov rax, [r15]
00007f4f7cbcee48  lea r12, [rax+0x68]
00007f4f7cbcee4c  mov r11, [r13+r12*1]
00007f4f7cbcee51  mov [r15+0x88], r11
00007f4f7cbcee58  lea r12, [rax+0x28]
00007f4f7cbcee5c  mov [r15+0x40], r12
00007f4f7cbcee60  mov [r15+0x48], r14
00007f4f7cbcee64  mov qword ptr [r15+0x50], 0x420B20
00007f4f7cbcee6c  lea rax, [r14+0x100]
00007f4f7cbcee73  mov r12, [r15+0xE8]
00007f4f7cbcee7a  mov r11, [r15+0xD8]
00007f4f7cbcee81  mov [r13+rax*1], r12
00007f4f7cbcee86  lea rax, [r14+0x108]
00007f4f7cbcee8d  mov [r13+rax*1], r11
00007f4f7cbcee92  lea rax, [r14+0x110]
00007f4f7cbcee99  mov r12, [r15+0xD0]
00007f4f7cbceea0  mov r11, [r15+0xC8]
00007f4f7cbceea7  mov [r13+rax*1], r12
00007f4f7cbceeac  lea rax, [r14+0x118]
00007f4f7cbceeb3  mov [r13+rax*1], r11
00007f4f7cbceeb8  lea rax, [r14+0x120]
00007f4f7cbceebf  mov r12, [r15+0xC0]
00007f4f7cbceec6  mov r11, [r15+0xB8]
00007f4f7cbceecd  mov [r13+rax*1], r12
00007f4f7cbceed2  lea rax, [r14+0x128]
00007f4f7cbceed9  mov [r13+rax*1], r11
00007f4f7cbceede  lea rax, [r14+0x130]
00007f4f7cbceee5  mov r12, [r15+0xB0]
00007f4f7cbceeec  mov r11, [r15+0xA8]
00007f4f7cbceef3  mov [r13+rax*1], r12
00007f4f7cbceef8  lea rax, [r14+0x138]
00007f4f7cbceeff  mov [r13+rax*1], r11
00007f4f7cbcef04  lea rax, [r14+0x140]
00007f4f7cbcef0b  mov r12, [r15+0xA0]
00007f4f7cbcef12  mov r11, [r15+0x98]
00007f4f7cbcef19  mov [r13+rax*1], r12
00007f4f7cbcef1e  lea rax, [r14+0x148]
00007f4f7cbcef25  mov [r13+rax*1], r11
00007f4f7cbcef2a  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcef32  jz 0x00007F4F7CBCEFD0
00007f4f7cbcef38  nop [rax+rax*1], ax
00007f4f7cbcef41  nop [rax+rax*1], eax
00007f4f7cbcef49  mov eax, 0x410704
00007f4f7cbcef4e  mov [r15+0x100], rax
00007f4f7cbcef55  jmp 0x00007F4F7C9FE110
00007f4f7cbcef5a  int3
00007f4f7cbcef5b  call 0x00007F4F7CAC0370
00007f4f7cbcef60  jmp 0x00007F4F7CBCEE51
00007f4f7cbcef65  call 0x00007F4F7CA0BC20
00007f4f7cbcef6a  jmp 0x00007F4F7CBCEE86
00007f4f7cbcef6f  call 0x00007F4F7CA0A9A0
00007f4f7cbcef74  jmp 0x00007F4F7CBCEE92
00007f4f7cbcef79  call 0x00007F4F7CA0BC20
00007f4f7cbcef7e  jmp 0x00007F4F7CBCEEAC
00007f4f7cbcef83  call 0x00007F4F7CA0A9A0
00007f4f7cbcef88  jmp 0x00007F4F7CBCEEB8
00007f4f7cbcef8d  call 0x00007F4F7CA0BC20
00007f4f7cbcef92  jmp 0x00007F4F7CBCEED2
00007f4f7cbcef97  call 0x00007F4F7CA0A9A0
00007f4f7cbcef9c  jmp 0x00007F4F7CBCEEDE
00007f4f7cbcefa1  call 0x00007F4F7CA0BC20
00007f4f7cbcefa6  jmp 0x00007F4F7CBCEEF8
00007f4f7cbcefab  call 0x00007F4F7CA0A9A0
00007f4f7cbcefb0  jmp 0x00007F4F7CBCEF04
00007f4f7cbcefb5  call 0x00007F4F7CA0BC20
00007f4f7cbcefba  jmp 0x00007F4F7CBCEF1E
00007f4f7cbcefbf  call 0x00007F4F7CA0A9A0
00007f4f7cbcefc4  jmp 0x00007F4F7CBCEF2A
00007f4f7cbcefc9  int3
00007f4f7cbcefca  nop [rax+rax*1], ax
00007f4f7cbcefd0  mov rax, [r15+0x08]
00007f4f7cbcefd4  movzx r14d, byte ptr [r13+rax*1]
00007f4f7cbcefda  movzx r14d, r14b
00007f4f7cbcefde  mov [rsp+0x10], r14d
00007f4f7cbcefe3  mov r14d, r14d
00007f4f7cbcefe6  mov [r15+0x58], r14
00007f4f7cbcefea  lea r14, [rax+0x01]
00007f4f7cbcefee  mov [r15+0x08], r14
00007f4f7cbceff2  mov rax, [r15+0x88]
00007f4f7cbceff9  lea r14, [rax+0x01]
00007f4f7cbceffd  mov r12, [r15]
00007f4f7cbcf000  lea r11, [r12+0x68]
00007f4f7cbcf005  mov [r13+r11*1], r14
00007f4f7cbcf00a  lea r14, [r12+rax*1]
00007f4f7cbcf00e  mov [r15+0x60], r14
00007f4f7cbcf012  lea rax, [r14+0x28]
00007f4f7cbcf016  mov r11d, [rsp+0x10]
00007f4f7cbcf01b  movzx r14d, r11b
00007f4f7cbcf01f  mov [r13+rax*1], r14b
00007f4f7cbcf024  lea rax, [r12+0x68]
00007f4f7cbcf029  mov r14, [r13+rax*1]
00007f4f7cbcf02e  mov [r15+0x88], r14
00007f4f7cbcf035  xor eax, eax
00007f4f7cbcf037  mov r12d, 0x40
00007f4f7cbcf03d  cmp r14, r12
00007f4f7cbcf040  cmc
00007f4f7cbcf041  lahf
00007f4f7cbcf042  seto al
00007f4f7cbcf045  mov [r15+0x108], eax
00007f4f7cbcf04c  mov eax, [r15+0x108]
00007f4f7cbcf053  sahf
00007f4f7cbcf054  jnz 0x00007F4F7CBCF086
00007f4f7cbcf056  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcf05e  jz 0x00007F4F7CBCF170
00007f4f7cbcf064  nop [rax+rax*1], ax
00007f4f7cbcf06d  nop [rax+rax*1], eax
00007f4f7cbcf075  mov eax, 0x410724
00007f4f7cbcf07a  mov [r15+0x100], rax
00007f4f7cbcf081  jmp 0x00007F4F7C9FE110
00007f4f7cbcf086  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcf08e  jz 0x00007F4F7CBCF0E0
00007f4f7cbcf094  nop [rax+rax*1], ax
00007f4f7cbcf09d  nop [rax+rax*1], eax
00007f4f7cbcf0a5  mov eax, 0x4106FC
00007f4f7cbcf0aa  mov [r15+0x100], rax
00007f4f7cbcf0b1  jmp 0x00007F4F7C9FE110
00007f4f7cbcf0b6  int3
00007f4f7cbcf0b7  call 0x00007F4F7CA0D860
00007f4f7cbcf0bc  jmp 0x00007F4F7CBCEFDA
00007f4f7cbcf0c1  call 0x00007F4F7CAB36E0
00007f4f7cbcf0c6  jmp 0x00007F4F7CBCF00A
00007f4f7cbcf0cb  call 0x00007F4F7CA0DD60
00007f4f7cbcf0d0  jmp 0x00007F4F7CBCF024
00007f4f7cbcf0d5  call 0x00007F4F7CA0DC20
00007f4f7cbcf0da  jmp 0x00007F4F7CBCF02E
00007f4f7cbcf0df  int3
00007f4f7cbcf0e0  mov rax, [r15+0x10]
00007f4f7cbcf0e4  lea r14, [rax-0x01]
00007f4f7cbcf0e8  mov [r15+0x10], r14
00007f4f7cbcf0ec  test r14, r14
00007f4f7cbcf0ef  setz r14b
00007f4f7cbcf0f3  movzx r14, r14b
00007f4f7cbcf0f7  mov [rsp+0x414], r14b
00007f4f7cbcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007f4f7cbcf107  jz 0x00007F4F7CBCF139
00007f4f7cbcf109  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcf111  jz 0x00007F4F7CBD0670
00007f4f7cbcf117  nop [rax+rax*1], ax
00007f4f7cbcf120  nop [rax+rax*1], eax
00007f4f7cbcf128  mov eax, 0x41091C
00007f4f7cbcf12d  mov [r15+0x100], rax
00007f4f7cbcf134  jmp 0x00007F4F7C9FE110
00007f4f7cbcf139  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcf141  jz 0x00007F4F7CBCEFD0
00007f4f7cbcf147  nop [rax+rax*1], ax
00007f4f7cbcf150  nop [rax+rax*1], eax
00007f4f7cbcf158  mov eax, 0x410704
00007f4f7cbcf15d  mov [r15+0x100], rax
00007f4f7cbcf164  jmp 0x00007F4F7C9FE110
00007f4f7cbcf169  int3
00007f4f7cbcf16a  int3
00007f4f7cbcf16b  nop [rax+rax*1], eax
00007f4f7cbcf170  mov rax, [r15+0x40]
00007f4f7cbcf174  movzx r14d, byte ptr [r13+rax*1]
00007f4f7cbcf17a  movaps xmm1, [r15+0x110]
00007f4f7cbcf182  pinsrb xmm1, r14d, 0x00
00007f4f7cbcf189  lea r14, [rax+0x01]
00007f4f7cbcf18d  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf193  movaps xmm15, [r15+0x120]
00007f4f7cbcf19b  pinsrb xmm15, r12d, 0x00
00007f4f7cbcf1a2  lea r14, [rax+0x02]
00007f4f7cbcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf1ac  movaps xmm14, [r15+0x130]
00007f4f7cbcf1b4  pinsrb xmm14, r12d, 0x00
00007f4f7cbcf1bb  lea r14, [rax+0x03]
00007f4f7cbcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf1c5  movaps xmm13, [r15+0x140]
00007f4f7cbcf1cd  pinsrb xmm13, r12d, 0x00
00007f4f7cbcf1d4  lea r14, [rax+0x04]
00007f4f7cbcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf1de  pinsrb xmm1, r12d, 0x01
00007f4f7cbcf1e5  lea r14, [rax+0x05]
00007f4f7cbcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf1ef  pinsrb xmm15, r12d, 0x01
00007f4f7cbcf1f6  lea r14, [rax+0x06]
00007f4f7cbcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf200  pinsrb xmm14, r12d, 0x01
00007f4f7cbcf207  lea r14, [rax+0x07]
00007f4f7cbcf20b  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf211  pinsrb xmm13, r12d, 0x01
00007f4f7cbcf218  lea r14, [rax+0x08]
00007f4f7cbcf21c  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf222  pinsrb xmm1, r12d, 0x02
00007f4f7cbcf229  lea r14, [rax+0x09]
00007f4f7cbcf22d  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf233  pinsrb xmm15, r12d, 0x02
00007f4f7cbcf23a  lea r14, [rax+0x0A]
00007f4f7cbcf23e  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf244  pinsrb xmm14, r12d, 0x02
00007f4f7cbcf24b  lea r14, [rax+0x0B]
00007f4f7cbcf24f  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf255  pinsrb xmm13, r12d, 0x02
00007f4f7cbcf25c  lea r14, [rax+0x0C]
00007f4f7cbcf260  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf266  pinsrb xmm1, r12d, 0x03
00007f4f7cbcf26d  lea r14, [rax+0x0D]
00007f4f7cbcf271  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf277  pinsrb xmm15, r12d, 0x03
00007f4f7cbcf27e  lea r14, [rax+0x0E]
00007f4f7cbcf282  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf288  pinsrb xmm14, r12d, 0x03
00007f4f7cbcf28f  lea r14, [rax+0x0F]
00007f4f7cbcf293  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf299  pinsrb xmm13, r12d, 0x03
00007f4f7cbcf2a0  lea r14, [rax+0x10]
00007f4f7cbcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf2aa  pinsrb xmm1, r12d, 0x04
00007f4f7cbcf2b1  lea r14, [rax+0x11]
00007f4f7cbcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf2bb  pinsrb xmm15, r12d, 0x04
00007f4f7cbcf2c2  lea r14, [rax+0x12]
00007f4f7cbcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf2cc  pinsrb xmm14, r12d, 0x04
00007f4f7cbcf2d3  lea r14, [rax+0x13]
00007f4f7cbcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf2dd  pinsrb xmm13, r12d, 0x04
00007f4f7cbcf2e4  lea r14, [rax+0x14]
00007f4f7cbcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf2ee  pinsrb xmm1, r12d, 0x05
00007f4f7cbcf2f5  lea r14, [rax+0x15]
00007f4f7cbcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf2ff  pinsrb xmm15, r12d, 0x05
00007f4f7cbcf306  lea r14, [rax+0x16]
00007f4f7cbcf30a  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf310  pinsrb xmm14, r12d, 0x05
00007f4f7cbcf317  lea r14, [rax+0x17]
00007f4f7cbcf31b  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf321  pinsrb xmm13, r12d, 0x05
00007f4f7cbcf328  lea r14, [rax+0x18]
00007f4f7cbcf32c  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf332  pinsrb xmm1, r12d, 0x06
00007f4f7cbcf339  lea r14, [rax+0x19]
00007f4f7cbcf33d  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf343  pinsrb xmm15, r12d, 0x06
00007f4f7cbcf34a  lea r14, [rax+0x1A]
00007f4f7cbcf34e  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf354  pinsrb xmm14, r12d, 0x06
00007f4f7cbcf35b  lea r14, [rax+0x1B]
00007f4f7cbcf35f  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf365  pinsrb xmm13, r12d, 0x06
00007f4f7cbcf36c  lea r14, [rax+0x1C]
00007f4f7cbcf370  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf376  pinsrb xmm1, r12d, 0x07
00007f4f7cbcf37d  lea r14, [rax+0x1D]
00007f4f7cbcf381  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf387  pinsrb xmm15, r12d, 0x07
00007f4f7cbcf38e  lea r14, [rax+0x1E]
00007f4f7cbcf392  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf398  pinsrb xmm14, r12d, 0x07
00007f4f7cbcf39f  lea r14, [rax+0x1F]
00007f4f7cbcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf3a9  pinsrb xmm13, r12d, 0x07
00007f4f7cbcf3b0  lea r14, [rax+0x20]
00007f4f7cbcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf3ba  pinsrb xmm1, r12d, 0x08
00007f4f7cbcf3c1  lea r14, [rax+0x21]
00007f4f7cbcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf3cb  pinsrb xmm15, r12d, 0x08
00007f4f7cbcf3d2  lea r14, [rax+0x22]
00007f4f7cbcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf3dc  pinsrb xmm14, r12d, 0x08
00007f4f7cbcf3e3  lea r14, [rax+0x23]
00007f4f7cbcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf3ed  pinsrb xmm13, r12d, 0x08
00007f4f7cbcf3f4  lea r14, [rax+0x24]
00007f4f7cbcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf3fe  pinsrb xmm1, r12d, 0x09
00007f4f7cbcf405  lea r14, [rax+0x25]
00007f4f7cbcf409  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf40f  pinsrb xmm15, r12d, 0x09
00007f4f7cbcf416  lea r14, [rax+0x26]
00007f4f7cbcf41a  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf420  pinsrb xmm14, r12d, 0x09
00007f4f7cbcf427  lea r14, [rax+0x27]
00007f4f7cbcf42b  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf431  pinsrb xmm13, r12d, 0x09
00007f4f7cbcf438  lea r14, [rax+0x28]
00007f4f7cbcf43c  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf442  pinsrb xmm1, r12d, 0x0A
00007f4f7cbcf449  lea r14, [rax+0x29]
00007f4f7cbcf44d  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf453  pinsrb xmm15, r12d, 0x0A
00007f4f7cbcf45a  lea r14, [rax+0x2A]
00007f4f7cbcf45e  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf464  pinsrb xmm14, r12d, 0x0A
00007f4f7cbcf46b  lea r14, [rax+0x2B]
00007f4f7cbcf46f  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf475  pinsrb xmm13, r12d, 0x0A
00007f4f7cbcf47c  lea r14, [rax+0x2C]
00007f4f7cbcf480  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf486  pinsrb xmm1, r12d, 0x0B
00007f4f7cbcf48d  lea r14, [rax+0x2D]
00007f4f7cbcf491  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf497  pinsrb xmm15, r12d, 0x0B
00007f4f7cbcf49e  lea r14, [rax+0x2E]
00007f4f7cbcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf4a8  pinsrb xmm14, r12d, 0x0B
00007f4f7cbcf4af  lea r14, [rax+0x2F]
00007f4f7cbcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf4b9  pinsrb xmm13, r12d, 0x0B
00007f4f7cbcf4c0  lea r14, [rax+0x30]
00007f4f7cbcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf4ca  pinsrb xmm1, r12d, 0x0C
00007f4f7cbcf4d1  lea r14, [rax+0x31]
00007f4f7cbcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf4db  pinsrb xmm15, r12d, 0x0C
00007f4f7cbcf4e2  lea r14, [rax+0x32]
00007f4f7cbcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf4ec  pinsrb xmm14, r12d, 0x0C
00007f4f7cbcf4f3  lea r14, [rax+0x33]
00007f4f7cbcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf4fd  pinsrb xmm13, r12d, 0x0C
00007f4f7cbcf504  lea r14, [rax+0x34]
00007f4f7cbcf508  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf50e  pinsrb xmm1, r12d, 0x0D
00007f4f7cbcf515  lea r14, [rax+0x35]
00007f4f7cbcf519  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf51f  pinsrb xmm15, r12d, 0x0D
00007f4f7cbcf526  lea r14, [rax+0x36]
00007f4f7cbcf52a  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf530  pinsrb xmm14, r12d, 0x0D
00007f4f7cbcf537  lea r14, [rax+0x37]
00007f4f7cbcf53b  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf541  pinsrb xmm13, r12d, 0x0D
00007f4f7cbcf548  lea r14, [rax+0x38]
00007f4f7cbcf54c  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf552  pinsrb xmm1, r12d, 0x0E
00007f4f7cbcf559  lea r14, [rax+0x39]
00007f4f7cbcf55d  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf563  pinsrb xmm15, r12d, 0x0E
00007f4f7cbcf56a  lea r14, [rax+0x3A]
00007f4f7cbcf56e  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf574  pinsrb xmm14, r12d, 0x0E
00007f4f7cbcf57b  lea r14, [rax+0x3B]
00007f4f7cbcf57f  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf585  pinsrb xmm13, r12d, 0x0E
00007f4f7cbcf58c  lea r14, [rax+0x3C]
00007f4f7cbcf590  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf596  pinsrb xmm1, r12d, 0x0F
00007f4f7cbcf59d  movaps [r15+0x110], xmm1
00007f4f7cbcf5a5  lea r14, [rax+0x3D]
00007f4f7cbcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf5af  pinsrb xmm15, r12d, 0x0F
00007f4f7cbcf5b6  movaps [r15+0x120], xmm15
00007f4f7cbcf5be  lea r14, [rax+0x3E]
00007f4f7cbcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007f4f7cbcf5c8  pinsrb xmm14, r12d, 0x0F
00007f4f7cbcf5cf  movaps [r15+0x130], xmm14
00007f4f7cbcf5d7  lea r14, [rax+0x3F]
00007f4f7cbcf5db  movzx eax, byte ptr [r13+r14*1]
00007f4f7cbcf5e1  pinsrb xmm13, eax, 0x0F
00007f4f7cbcf5e8  movaps [r15+0x140], xmm13
00007f4f7cbcf5f0  movq xmm1, qword ptr [r15+0x120]
00007f4f7cbcf5f9  pmovzxbw xmm1, xmm1
00007f4f7cbcf5fe  psllw xmm1, 0x00
00007f4f7cbcf603  movaps [r15+0x150], xmm1
00007f4f7cbcf60b  movq xmm1, qword ptr [r15+0x130]
00007f4f7cbcf614  pmovzxbw xmm1, xmm1
00007f4f7cbcf619  psllw xmm1, 0x00
00007f4f7cbcf61e  movaps [r15+0x160], xmm1
00007f4f7cbcf626  movq xmm1, qword ptr [r15+0x110]
00007f4f7cbcf62f  pmovzxbw xmm1, xmm1
00007f4f7cbcf634  psllw xmm1, 0x00
00007f4f7cbcf639  movaps [r15+0x170], xmm1
00007f4f7cbcf641  movaps xmm15, [r15+0x110]
00007f4f7cbcf649  pextrq rax, xmm15, 0x01
00007f4f7cbcf650  movq xmm15, rax
00007f4f7cbcf655  pmovzxbw xmm15, xmm15
00007f4f7cbcf65b  psllw xmm15, 0x00
00007f4f7cbcf661  movaps [r15+0x180], xmm15
00007f4f7cbcf669  movaps xmm14, [r15+0x120]
00007f4f7cbcf671  pextrq rax, xmm14, 0x01
00007f4f7cbcf678  movq xmm14, rax
00007f4f7cbcf67d  pmovzxbw xmm14, xmm14
00007f4f7cbcf683  psllw xmm14, 0x00
00007f4f7cbcf689  movaps [r15+0x210], xmm14
00007f4f7cbcf691  movaps xmm13, [r15+0x130]
00007f4f7cbcf699  pextrq rax, xmm13, 0x01
00007f4f7cbcf6a0  movq xmm13, rax
00007f4f7cbcf6a5  pmovzxbw xmm13, xmm13
00007f4f7cbcf6ab  psllw xmm13, 0x00
00007f4f7cbcf6b1  movaps [r15+0x220], xmm13
00007f4f7cbcf6b9  movq xmm12, qword ptr [r15+0x140]
00007f4f7cbcf6c2  pmovzxbw xmm12, xmm12
00007f4f7cbcf6c8  psllw xmm12, 0x00
00007f4f7cbcf6ce  movaps [r15+0x250], xmm12
00007f4f7cbcf6d6  movaps xmm12, [r15+0x140]
00007f4f7cbcf6de  pextrq rax, xmm12, 0x01
00007f4f7cbcf6e5  movq xmm12, rax
00007f4f7cbcf6ea  pmovzxbw xmm12, xmm12
00007f4f7cbcf6f0  psllw xmm12, 0x00
00007f4f7cbcf6f6  movaps [r15+0x110], xmm12
00007f4f7cbcf6fe  movq xmm11, qword ptr [r15+0x150]
00007f4f7cbcf707  pmovzxwd xmm11, xmm11
00007f4f7cbcf70d  pslld xmm11, 0x10
00007f4f7cbcf713  movq xmm10, qword ptr [r15+0x160]
00007f4f7cbcf71c  pmovzxwd xmm10, xmm10
00007f4f7cbcf722  pslld xmm10, 0x08
00007f4f7cbcf728  pextrq rax, xmm1, 0x01
00007f4f7cbcf72f  movq xmm1, rax
00007f4f7cbcf734  pmovzxwd xmm1, xmm1
00007f4f7cbcf739  pslld xmm1, 0x00
00007f4f7cbcf73e  movaps [r15+0x260], xmm1
00007f4f7cbcf746  pextrq rax, xmm15, 0x01
00007f4f7cbcf74d  movq xmm15, rax
00007f4f7cbcf752  pmovzxwd xmm15, xmm15
00007f4f7cbcf758  pslld xmm15, 0x00
00007f4f7cbcf75e  movaps [r15+0x270], xmm15
00007f4f7cbcf766  movq xmm9, qword ptr [r15+0x170]
00007f4f7cbcf76f  pmovzxwd xmm9, xmm9
00007f4f7cbcf775  pslld xmm9, 0x00
00007f4f7cbcf77b  pextrq rax, xmm14, 0x01
00007f4f7cbcf782  movq xmm14, rax
00007f4f7cbcf787  pmovzxwd xmm14, xmm14
00007f4f7cbcf78d  pslld xmm14, 0x10
00007f4f7cbcf793  movaps [r15+0x280], xmm14
00007f4f7cbcf79b  movq xmm8, qword ptr [r15+0x180]
00007f4f7cbcf7a4  pmovzxwd xmm8, xmm8
00007f4f7cbcf7aa  pslld xmm8, 0x00
00007f4f7cbcf7b0  movq xmm7, qword ptr [r15+0x210]
00007f4f7cbcf7b9  pmovzxwd xmm7, xmm7
00007f4f7cbcf7be  pslld xmm7, 0x10
00007f4f7cbcf7c3  movaps xmm6, [r15+0x150]
00007f4f7cbcf7cb  pextrq rax, xmm6, 0x01
00007f4f7cbcf7d2  movq xmm6, rax
00007f4f7cbcf7d7  pmovzxwd xmm6, xmm6
00007f4f7cbcf7dc  pslld xmm6, 0x10
00007f4f7cbcf7e1  por xmm11, xmm10
00007f4f7cbcf7e6  movaps [r15+0x230], xmm11
00007f4f7cbcf7ee  pextrq rax, xmm13, 0x01
00007f4f7cbcf7f5  movq xmm13, rax
00007f4f7cbcf7fa  pmovzxwd xmm13, xmm13
00007f4f7cbcf800  pslld xmm13, 0x08
00007f4f7cbcf806  movaps [r15+0x240], xmm13
00007f4f7cbcf80e  movq xmm10, qword ptr [r15+0x220]
00007f4f7cbcf817  pmovzxwd xmm10, xmm10
00007f4f7cbcf81d  pslld xmm10, 0x08
00007f4f7cbcf823  movaps xmm5, [r15+0x160]
00007f4f7cbcf82b  pextrq rax, xmm5, 0x01
00007f4f7cbcf832  movq xmm5, rax
00007f4f7cbcf837  pmovzxwd xmm5, xmm5
00007f4f7cbcf83c  pslld xmm5, 0x08
00007f4f7cbcf841  pslld xmm9, 0x18
00007f4f7cbcf847  pslld xmm15, 0x18
00007f4f7cbcf84d  pslld xmm8, 0x18
00007f4f7cbcf853  movq xmm4, qword ptr [r15+0x250]
00007f4f7cbcf85c  pmovzxwd xmm4, xmm4
00007f4f7cbcf861  pslld xmm4, 0x00
00007f4f7cbcf866  por xmm14, xmm13
00007f4f7cbcf86b  por xmm7, xmm10
00007f4f7cbcf870  movaps [r15+0x210], xmm7
00007f4f7cbcf878  pslld xmm1, 0x18
00007f4f7cbcf87d  movaps [r15+0x220], xmm1
00007f4f7cbcf885  por xmm6, xmm5
00007f4f7cbcf889  por xmm11, xmm9
00007f4f7cbcf88e  movaps [r15+0x160], xmm11
00007f4f7cbcf896  pextrq rax, xmm12, 0x01
00007f4f7cbcf89d  movq xmm13, rax
00007f4f7cbcf8a2  pmovzxwd xmm13, xmm13
00007f4f7cbcf8a8  pslld xmm13, 0x00
00007f4f7cbcf8ae  movaps [r15+0x170], xmm13
00007f4f7cbcf8b6  movq xmm12, qword ptr [r15+0x110]
00007f4f7cbcf8bf  pmovzxwd xmm12, xmm12
00007f4f7cbcf8c5  pslld xmm12, 0x00
00007f4f7cbcf8cb  por xmm14, xmm15
00007f4f7cbcf8d0  por xmm7, xmm8
00007f4f7cbcf8d5  movaps xmm15, [r15+0x250]
00007f4f7cbcf8dd  pextrq rax, xmm15, 0x01
00007f4f7cbcf8e4  movq xmm15, rax
00007f4f7cbcf8e9  pmovzxwd xmm15, xmm15
00007f4f7cbcf8ef  pslld xmm15, 0x00
00007f4f7cbcf8f5  movaps [r15+0x180], xmm15
00007f4f7cbcf8fd  por xmm6, xmm1
00007f4f7cbcf901  movaps [r15+0x150], xmm6
00007f4f7cbcf909  por xmm11, xmm4
00007f4f7cbcf90e  movaps [r15+0x140], xmm11
00007f4f7cbcf916  por xmm7, xmm12
00007f4f7cbcf91b  movaps [r15+0x110], xmm7
00007f4f7cbcf923  por xmm14, xmm13
00007f4f7cbcf928  movaps [r15+0x120], xmm14
00007f4f7cbcf930  por xmm6, xmm15
00007f4f7cbcf935  movaps [r15+0x130], xmm6
00007f4f7cbcf93d  mov rax, [r15+0xF8]
00007f4f7cbcf944  lea r14, [rax+0x20]
00007f4f7cbcf948  movups [r13+r14*1], xmm7
00007f4f7cbcf94e  lea r14, [rax+0x30]
00007f4f7cbcf952  movups [r13+r14*1], xmm14
00007f4f7cbcf958  movups [r13+rax*1], xmm11
00007f4f7cbcf95e  lea r14, [rax+0x10]
00007f4f7cbcf962  movups [r13+r14*1], xmm6
00007f4f7cbcf968  mov r14d, [r13+rax*1]
00007f4f7cbcf96d  mov rax, [r15+0x48]
00007f4f7cbcf971  mov [r15+0x68], rax
00007f4f7cbcf975  mov qword ptr [r15+0x58], 0x04
00007f4f7cbcf97d  lea r12, [rax+0x04]
00007f4f7cbcf981  mov r11d, [r13+r12*1]
00007f4f7cbcf986  mov [rsp+0x10], r11d
00007f4f7cbcf98b  mov r11d, r11d
00007f4f7cbcf98e  mov [r15+0x70], r11
00007f4f7cbcf992  lea r12, [rax+0x38]
00007f4f7cbcf996  mov r11d, [r13+r12*1]
00007f4f7cbcf99b  lea r12, [rax+0x24]
00007f4f7cbcf99f  mov r10d, [r13+r12*1]
00007f4f7cbcf9a4  mov [rsp+0x20], r10d
00007f4f7cbcf9a9  mov r10d, r10d
00007f4f7cbcf9ac  mov [r15+0x90], r10
00007f4f7cbcf9b3  mov [rsp+0x30], rax
00007f4f7cbcf9b8  xor eax, eax
00007f4f7cbcf9ba  mov r12d, 0x04
00007f4f7cbcf9c0  mov r10d, 0xC0
00007f4f7cbcf9c6  cmp r12, r10
00007f4f7cbcf9c9  cmc
00007f4f7cbcf9ca  lahf
00007f4f7cbcf9cb  seto al
00007f4f7cbcf9ce  mov [r15+0x108], eax
00007f4f7cbcf9d5  mov eax, [rsp+0x10]
00007f4f7cbcf9d9  mov r12d, [rsp+0x10]
00007f4f7cbcf9de  shrd eax, r12d, 0x07
00007f4f7cbcf9e3  mov [rsp+0x10], r11d
00007f4f7cbcf9e8  mov r10d, [rsp+0x10]
00007f4f7cbcf9ed  shrd r11d, r10d, 0x11
00007f4f7cbcf9f2  mov r9d, [rsp+0x20]
00007f4f7cbcf9f7  lea r8d, [r9d+r14d*1]
00007f4f7cbcf9fc  rorx r14d, r12d, 0x12
00007f4f7cbcfa02  xor eax, r14d
00007f4f7cbcfa05  rorx r14d, r10d, 0x13
00007f4f7cbcfa0b  xor r11d, r14d
00007f4f7cbcfa0e  mov [rsp+0x10], r11d
00007f4f7cbcfa13  mov r11d, r11d
00007f4f7cbcfa16  mov [r15+0x88], r11
00007f4f7cbcfa1d  mov [rsp+0x20], r12d
00007f4f7cbcfa22  shr r12d, 0x03
00007f4f7cbcfa26  xor eax, r12d
00007f4f7cbcfa29  mov [rsp+0x40], eax
00007f4f7cbcfa2d  mov eax, eax
00007f4f7cbcfa2f  mov [r15+0x80], rax
00007f4f7cbcfa36  shr r10d, 0x0A
00007f4f7cbcfa3a  mov eax, [rsp+0x10]
00007f4f7cbcfa3e  xor eax, r10d
00007f4f7cbcfa41  mov [rsp+0x10], eax
00007f4f7cbcfa45  mov eax, eax
00007f4f7cbcfa47  mov [r15+0x78], rax
00007f4f7cbcfa4b  mov eax, [rsp+0x40]
00007f4f7cbcfa4f  lea r14d, [r8d+eax*1]
00007f4f7cbcfa54  mov eax, [rsp+0x10]
00007f4f7cbcfa58  lea r12d, [r14d+eax*1]
00007f4f7cbcfa5d  mov rax, [rsp+0x30]
00007f4f7cbcfa62  lea r14, [rax+0x40]
00007f4f7cbcfa66  mov [r13+r14*1], r12d
00007f4f7cbcfa6b  mov eax, [rsp+0x20]
00007f4f7cbcfa6f  mov eax, eax
00007f4f7cbcfa71  mov [r15+0x60], rax
00007f4f7cbcfa75  mov eax, [r15+0x108]
00007f4f7cbcfa7c  sahf
00007f4f7cbcfa7d  jnz 0x00007F4F7CBCFAAF
00007f4f7cbcfa7f  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcfa87  jz 0x00007F4F7CBCFF70
00007f4f7cbcfa8d  nop [rax+rax*1], ax
00007f4f7cbcfa96  nop [rax+rax*1], eax
00007f4f7cbcfa9e  mov eax, 0x410820
00007f4f7cbcfaa3  mov [r15+0x100], rax
00007f4f7cbcfaaa  jmp 0x00007F4F7C9FE110
00007f4f7cbcfaaf  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcfab7  jz 0x00007F4F7CBCFDC0
00007f4f7cbcfabd  nop [rax+rax*1], ax
00007f4f7cbcfac6  nop [rax+rax*1], eax
00007f4f7cbcface  mov eax, 0x4107D8
00007f4f7cbcfad3  mov [r15+0x100], rax
00007f4f7cbcfada  jmp 0x00007F4F7C9FE110
00007f4f7cbcfadf  int3
00007f4f7cbcfae0  call 0x00007F4F7CA0D860
00007f4f7cbcfae5  jmp 0x00007F4F7CBCF17A
00007f4f7cbcfaea  call 0x00007F4F7CAE2420
00007f4f7cbcfaef  jmp 0x00007F4F7CBCF193
00007f4f7cbcfaf4  call 0x00007F4F7CAE2420
00007f4f7cbcfaf9  jmp 0x00007F4F7CBCF1AC
00007f4f7cbcfafe  call 0x00007F4F7CAE2420
00007f4f7cbcfb03  jmp 0x00007F4F7CBCF1C5
00007f4f7cbcfb08  call 0x00007F4F7CAE2420
00007f4f7cbcfb0d  jmp 0x00007F4F7CBCF1DE
00007f4f7cbcfb12  call 0x00007F4F7CAE2420
00007f4f7cbcfb17  jmp 0x00007F4F7CBCF1EF
00007f4f7cbcfb1c  call 0x00007F4F7CAE2420
00007f4f7cbcfb21  jmp 0x00007F4F7CBCF200
00007f4f7cbcfb26  call 0x00007F4F7CAE2420
00007f4f7cbcfb2b  jmp 0x00007F4F7CBCF211
00007f4f7cbcfb30  call 0x00007F4F7CAE2420
00007f4f7cbcfb35  jmp 0x00007F4F7CBCF222
00007f4f7cbcfb3a  call 0x00007F4F7CAE2420
00007f4f7cbcfb3f  jmp 0x00007F4F7CBCF233
00007f4f7cbcfb44  call 0x00007F4F7CAE2420
00007f4f7cbcfb49  jmp 0x00007F4F7CBCF244
00007f4f7cbcfb4e  call 0x00007F4F7CAE2420
00007f4f7cbcfb53  jmp 0x00007F4F7CBCF255
00007f4f7cbcfb58  call 0x00007F4F7CAE2420
00007f4f7cbcfb5d  jmp 0x00007F4F7CBCF266
00007f4f7cbcfb62  call 0x00007F4F7CAE2420
00007f4f7cbcfb67  jmp 0x00007F4F7CBCF277
00007f4f7cbcfb6c  call 0x00007F4F7CAE2420
00007f4f7cbcfb71  jmp 0x00007F4F7CBCF288
00007f4f7cbcfb76  call 0x00007F4F7CAE2420
00007f4f7cbcfb7b  jmp 0x00007F4F7CBCF299
00007f4f7cbcfb80  call 0x00007F4F7CAE2420
00007f4f7cbcfb85  jmp 0x00007F4F7CBCF2AA
00007f4f7cbcfb8a  call 0x00007F4F7CAE2420
00007f4f7cbcfb8f  jmp 0x00007F4F7CBCF2BB
00007f4f7cbcfb94  call 0x00007F4F7CAE2420
00007f4f7cbcfb99  jmp 0x00007F4F7CBCF2CC
00007f4f7cbcfb9e  call 0x00007F4F7CAE2420
00007f4f7cbcfba3  jmp 0x00007F4F7CBCF2DD
00007f4f7cbcfba8  call 0x00007F4F7CAE2420
00007f4f7cbcfbad  jmp 0x00007F4F7CBCF2EE
00007f4f7cbcfbb2  call 0x00007F4F7CAE2420
00007f4f7cbcfbb7  jmp 0x00007F4F7CBCF2FF
00007f4f7cbcfbbc  call 0x00007F4F7CAE2420
00007f4f7cbcfbc1  jmp 0x00007F4F7CBCF310
00007f4f7cbcfbc6  call 0x00007F4F7CAE2420
00007f4f7cbcfbcb  jmp 0x00007F4F7CBCF321
00007f4f7cbcfbd0  call 0x00007F4F7CAE2420
00007f4f7cbcfbd5  jmp 0x00007F4F7CBCF332
00007f4f7cbcfbda  call 0x00007F4F7CAE2420
00007f4f7cbcfbdf  jmp 0x00007F4F7CBCF343
00007f4f7cbcfbe4  call 0x00007F4F7CAE2420
00007f4f7cbcfbe9  jmp 0x00007F4F7CBCF354
00007f4f7cbcfbee  call 0x00007F4F7CAE2420
00007f4f7cbcfbf3  jmp 0x00007F4F7CBCF365
00007f4f7cbcfbf8  call 0x00007F4F7CAE2420
00007f4f7cbcfbfd  jmp 0x00007F4F7CBCF376
00007f4f7cbcfc02  call 0x00007F4F7CAE2420
00007f4f7cbcfc07  jmp 0x00007F4F7CBCF387
00007f4f7cbcfc0c  call 0x00007F4F7CAE2420
00007f4f7cbcfc11  jmp 0x00007F4F7CBCF398
00007f4f7cbcfc16  call 0x00007F4F7CAE2420
00007f4f7cbcfc1b  jmp 0x00007F4F7CBCF3A9
00007f4f7cbcfc20  call 0x00007F4F7CAE2420
00007f4f7cbcfc25  jmp 0x00007F4F7CBCF3BA
00007f4f7cbcfc2a  call 0x00007F4F7CAE2420
00007f4f7cbcfc2f  jmp 0x00007F4F7CBCF3CB
00007f4f7cbcfc34  call 0x00007F4F7CAE2420
00007f4f7cbcfc39  jmp 0x00007F4F7CBCF3DC
00007f4f7cbcfc3e  call 0x00007F4F7CAE2420
00007f4f7cbcfc43  jmp 0x00007F4F7CBCF3ED
00007f4f7cbcfc48  call 0x00007F4F7CAE2420
00007f4f7cbcfc4d  jmp 0x00007F4F7CBCF3FE
00007f4f7cbcfc52  call 0x00007F4F7CAE2420
00007f4f7cbcfc57  jmp 0x00007F4F7CBCF40F
00007f4f7cbcfc5c  call 0x00007F4F7CAE2420
00007f4f7cbcfc61  jmp 0x00007F4F7CBCF420
00007f4f7cbcfc66  call 0x00007F4F7CAE2420
00007f4f7cbcfc6b  jmp 0x00007F4F7CBCF431
00007f4f7cbcfc70  call 0x00007F4F7CAE2420
00007f4f7cbcfc75  jmp 0x00007F4F7CBCF442
00007f4f7cbcfc7a  call 0x00007F4F7CAE2420
00007f4f7cbcfc7f  jmp 0x00007F4F7CBCF453
00007f4f7cbcfc84  call 0x00007F4F7CAE2420
00007f4f7cbcfc89  jmp 0x00007F4F7CBCF464
00007f4f7cbcfc8e  call 0x00007F4F7CAE2420
00007f4f7cbcfc93  jmp 0x00007F4F7CBCF475
00007f4f7cbcfc98  call 0x00007F4F7CAE2420
00007f4f7cbcfc9d  jmp 0x00007F4F7CBCF486
00007f4f7cbcfca2  call 0x00007F4F7CAE2420
00007f4f7cbcfca7  jmp 0x00007F4F7CBCF497
00007f4f7cbcfcac  call 0x00007F4F7CAE2420
00007f4f7cbcfcb1  jmp 0x00007F4F7CBCF4A8
00007f4f7cbcfcb6  call 0x00007F4F7CAE2420
00007f4f7cbcfcbb  jmp 0x00007F4F7CBCF4B9
00007f4f7cbcfcc0  call 0x00007F4F7CAE2420
00007f4f7cbcfcc5  jmp 0x00007F4F7CBCF4CA
00007f4f7cbcfcca  call 0x00007F4F7CAE2420
00007f4f7cbcfccf  jmp 0x00007F4F7CBCF4DB
00007f4f7cbcfcd4  call 0x00007F4F7CAE2420
00007f4f7cbcfcd9  jmp 0x00007F4F7CBCF4EC
00007f4f7cbcfcde  call 0x00007F4F7CAE2420
00007f4f7cbcfce3  jmp 0x00007F4F7CBCF4FD
00007f4f7cbcfce8  call 0x00007F4F7CAE2420
00007f4f7cbcfced  jmp 0x00007F4F7CBCF50E
00007f4f7cbcfcf2  call 0x00007F4F7CAE2420
00007f4f7cbcfcf7  jmp 0x00007F4F7CBCF51F
00007f4f7cbcfcfc  call 0x00007F4F7CAE2420
00007f4f7cbcfd01  jmp 0x00007F4F7CBCF530
00007f4f7cbcfd06  call 0x00007F4F7CAE2420
00007f4f7cbcfd0b  jmp 0x00007F4F7CBCF541
00007f4f7cbcfd10  call 0x00007F4F7CAE2420
00007f4f7cbcfd15  jmp 0x00007F4F7CBCF552
00007f4f7cbcfd1a  call 0x00007F4F7CAE2420
00007f4f7cbcfd1f  jmp 0x00007F4F7CBCF563
00007f4f7cbcfd24  call 0x00007F4F7CAE2420
00007f4f7cbcfd29  jmp 0x00007F4F7CBCF574
00007f4f7cbcfd2e  call 0x00007F4F7CAE2420
00007f4f7cbcfd33  jmp 0x00007F4F7CBCF585
00007f4f7cbcfd38  call 0x00007F4F7CAE2420
00007f4f7cbcfd3d  jmp 0x00007F4F7CBCF596
00007f4f7cbcfd42  call 0x00007F4F7CAE2420
00007f4f7cbcfd47  jmp 0x00007F4F7CBCF5AF
00007f4f7cbcfd4c  call 0x00007F4F7CAE2420
00007f4f7cbcfd51  jmp 0x00007F4F7CBCF5C8
00007f4f7cbcfd56  call 0x00007F4F7CAD5610
00007f4f7cbcfd5b  jmp 0x00007F4F7CBCF5E1
00007f4f7cbcfd60  call 0x00007F4F7CADC580
00007f4f7cbcfd65  jmp 0x00007F4F7CBCF94E
00007f4f7cbcfd6a  call 0x00007F4F7CAE46C0
00007f4f7cbcfd6f  jmp 0x00007F4F7CBCF958
00007f4f7cbcfd74  call 0x00007F4F7CA09E90
00007f4f7cbcfd79  jmp 0x00007F4F7CBCF95E
00007f4f7cbcfd7e  call 0x00007F4F7CADB310
00007f4f7cbcfd83  jmp 0x00007F4F7CBCF968
00007f4f7cbcfd88  call 0x00007F4F7CA0DAE0
00007f4f7cbcfd8d  jmp 0x00007F4F7CBCF96D
00007f4f7cbcfd92  call 0x00007F4F7CAC0230
00007f4f7cbcfd97  jmp 0x00007F4F7CBCF986
00007f4f7cbcfd9c  call 0x00007F4F7CAC0230
00007f4f7cbcfda1  jmp 0x00007F4F7CBCF99B
00007f4f7cbcfda6  call 0x00007F4F7CABEFC0
00007f4f7cbcfdab  jmp 0x00007F4F7CBCF9A4
00007f4f7cbcfdb0  call 0x00007F4F7CAE2BA0
00007f4f7cbcfdb5  jmp 0x00007F4F7CBCFA6B
00007f4f7cbcfdba  int3
00007f4f7cbcfdbb  nop [rax+rax*1], eax
00007f4f7cbcfdc0  mov rax, [r15+0x48]
00007f4f7cbcfdc4  mov r14, [r15+0x58]
00007f4f7cbcfdc8  lea r12, [rax+r14*1]
00007f4f7cbcfdcc  mov [r15+0x68], r12
00007f4f7cbcfdd0  lea rax, [r14+0x04]
00007f4f7cbcfdd4  mov [r15+0x58], rax
00007f4f7cbcfdd8  lea r14, [r12+0x04]
00007f4f7cbcfddd  mov r11d, [r13+r14*1]
00007f4f7cbcfde2  mov [rsp+0x10], r11d
00007f4f7cbcfde7  mov r11d, r11d
00007f4f7cbcfdea  mov [r15+0x70], r11
00007f4f7cbcfdee  lea r14, [r12+0x38]
00007f4f7cbcfdf3  mov r11d, [r13+r14*1]
00007f4f7cbcfdf8  lea r14, [r12+0x24]
00007f4f7cbcfdfd  mov r10d, [r13+r14*1]
00007f4f7cbcfe02  mov [rsp+0x20], r10d
00007f4f7cbcfe07  mov r10d, r10d
00007f4f7cbcfe0a  mov [r15+0x90], r10
00007f4f7cbcfe11  mov [rsp+0x30], rax
00007f4f7cbcfe16  xor eax, eax
00007f4f7cbcfe18  mov r14, [rsp+0x30]
00007f4f7cbcfe1d  mov r10d, 0xC0
00007f4f7cbcfe23  cmp r14, r10
00007f4f7cbcfe26  cmc
00007f4f7cbcfe27  lahf
00007f4f7cbcfe28  seto al
00007f4f7cbcfe2b  mov [r15+0x108], eax
00007f4f7cbcfe32  mov eax, [rsp+0x10]
00007f4f7cbcfe36  mov r14d, [rsp+0x10]
00007f4f7cbcfe3b  shrd eax, r14d, 0x07
00007f4f7cbcfe40  mov [rsp+0x10], r11d
00007f4f7cbcfe45  mov r10d, [rsp+0x10]
00007f4f7cbcfe4a  shrd r11d, r10d, 0x11
00007f4f7cbcfe4f  mov r9d, [r15+0x60]
00007f4f7cbcfe53  mov r8d, [rsp+0x20]
00007f4f7cbcfe58  lea ebp, [r8d+r9d*1]
00007f4f7cbcfe5d  rorx r9d, r14d, 0x12
00007f4f7cbcfe63  xor eax, r9d
00007f4f7cbcfe66  rorx r9d, r10d, 0x13
00007f4f7cbcfe6c  xor r11d, r9d
00007f4f7cbcfe6f  mov [rsp+0x10], r11d
00007f4f7cbcfe74  mov r11d, r11d
00007f4f7cbcfe77  mov [r15+0x88], r11
00007f4f7cbcfe7e  mov [rsp+0x20], r14d
00007f4f7cbcfe83  shr r14d, 0x03
00007f4f7cbcfe87  xor eax, r14d
00007f4f7cbcfe8a  mov [rsp+0x30], eax
00007f4f7cbcfe8e  mov eax, eax
00007f4f7cbcfe90  mov [r15+0x80], rax
00007f4f7cbcfe97  shr r10d, 0x0A
00007f4f7cbcfe9b  mov eax, [rsp+0x10]
00007f4f7cbcfe9f  xor eax, r10d
00007f4f7cbcfea2  mov [rsp+0x10], eax
00007f4f7cbcfea6  mov eax, eax
00007f4f7cbcfea8  mov [r15+0x78], rax
00007f4f7cbcfeac  mov eax, [rsp+0x30]
00007f4f7cbcfeb0  lea r14d, [ebp+eax*1]
00007f4f7cbcfeb6  mov eax, [rsp+0x10]
00007f4f7cbcfeba  lea r11d, [r14d+eax*1]
00007f4f7cbcfebf  lea rax, [r12+0x40]
00007f4f7cbcfec4  mov [r13+rax*1], r11d
00007f4f7cbcfec9  mov eax, [rsp+0x20]
00007f4f7cbcfecd  mov eax, eax
00007f4f7cbcfecf  mov [r15+0x60], rax
00007f4f7cbcfed3  mov eax, [r15+0x108]
00007f4f7cbcfeda  sahf
00007f4f7cbcfedb  jnz 0x00007F4F7CBCFF0D
00007f4f7cbcfedd  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcfee5  jz 0x00007F4F7CBCFF70
00007f4f7cbcfeeb  nop [rax+rax*1], ax
00007f4f7cbcfef4  nop [rax+rax*1], eax
00007f4f7cbcfefc  mov eax, 0x410820
00007f4f7cbcff01  mov [r15+0x100], rax
00007f4f7cbcff08  jmp 0x00007F4F7C9FE110
00007f4f7cbcff0d  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbcff15  jz 0x00007F4F7CBCFDC0
00007f4f7cbcff1b  nop [rax+rax*1], ax
00007f4f7cbcff24  nop [rax+rax*1], eax
00007f4f7cbcff2c  mov eax, 0x4107D8
00007f4f7cbcff31  mov [r15+0x100], rax
00007f4f7cbcff38  jmp 0x00007F4F7C9FE110
00007f4f7cbcff3d  int3
00007f4f7cbcff3e  call 0x00007F4F7CAE1430
00007f4f7cbcff43  jmp 0x00007F4F7CBCFDE2
00007f4f7cbcff48  call 0x00007F4F7CAE1430
00007f4f7cbcff4d  jmp 0x00007F4F7CBCFDF8
00007f4f7cbcff52  call 0x00007F4F7CAE01C0
00007f4f7cbcff57  jmp 0x00007F4F7CBCFE02
00007f4f7cbcff5c  call 0x00007F4F7CA0A860
00007f4f7cbcff61  jmp 0x00007F4F7CBCFEC9
00007f4f7cbcff66  int3
00007f4f7cbcff67  nop [rax+rax*1], ax
00007f4f7cbcff70  mov rax, [r15]
00007f4f7cbcff73  mov r14d, [r13+rax*1]
00007f4f7cbcff78  lea r12, [rax+0x04]
00007f4f7cbcff7c  mov r11d, [r13+r12*1]
00007f4f7cbcff81  mov [rsp+0x10], r14d
00007f4f7cbcff86  mov r14d, r14d
00007f4f7cbcff89  mov [r15+0x78], r14
00007f4f7cbcff8d  mov [rsp+0x20], r11d
00007f4f7cbcff92  mov r11d, r11d
00007f4f7cbcff95  mov [r15+0x80], r11
00007f4f7cbcff9c  lea r14, [rax+0x08]
00007f4f7cbcffa0  mov r12d, [r13+r14*1]
00007f4f7cbcffa5  lea r14, [rax+0x0C]
00007f4f7cbcffa9  mov r11d, [r13+r14*1]
00007f4f7cbcffae  mov [rsp+0x30], r12d
00007f4f7cbcffb3  mov r12d, r12d
00007f4f7cbcffb6  mov [r15+0x70], r12
00007f4f7cbcffba  mov [rsp+0x40], r11d
00007f4f7cbcffbf  mov r11d, r11d
00007f4f7cbcffc2  mov [r15+0x68], r11
00007f4f7cbcffc6  lea r14, [rax+0x18]
00007f4f7cbcffca  mov r12d, [r13+r14*1]
00007f4f7cbcffcf  lea r14, [rax+0x1C]
00007f4f7cbcffd3  mov r11d, [r13+r14*1]
00007f4f7cbcffd8  mov [rsp+0x50], r12d
00007f4f7cbcffdd  mov r12d, r12d
00007f4f7cbcffe0  mov [r15+0x58], r12
00007f4f7cbcffe4  mov [rsp+0x60], r11d
00007f4f7cbcffe9  mov r11d, r11d
00007f4f7cbcffec  mov [r15+0x60], r11
00007f4f7cbcfff0  lea r14, [rax+0x10]
00007f4f7cbcfff4  mov r12d, [r13+r14*1]
00007f4f7cbcfff9  lea r14, [rax+0x14]
00007f4f7cbcfffd  mov eax, [r13+r14*1]
00007f4f7cbd0002  mov [rsp+0x70], r12d
00007f4f7cbd0007  mov r12d, r12d
00007f4f7cbd000a  mov [r15+0x18], r12
00007f4f7cbd000e  mov [rsp+0x80], eax
00007f4f7cbd0015  mov eax, eax
00007f4f7cbd0017  mov [r15+0x90], rax
00007f4f7cbd001e  mov eax, [rsp+0x70]
00007f4f7cbd0022  mov eax, eax
00007f4f7cbd0024  mov [r15+0x30], rax
00007f4f7cbd0028  mov eax, [rsp+0x50]
00007f4f7cbd002c  mov eax, eax
00007f4f7cbd002e  mov [r15+0xA0], rax
00007f4f7cbd0035  mov eax, [rsp+0x30]
00007f4f7cbd0039  mov eax, eax
00007f4f7cbd003b  mov [r15+0x28], rax
00007f4f7cbd003f  mov eax, [rsp+0x20]
00007f4f7cbd0043  mov eax, eax
00007f4f7cbd0045  mov [r15+0x98], rax
00007f4f7cbd004c  mov eax, [rsp+0x10]
00007f4f7cbd0050  mov eax, eax
00007f4f7cbd0052  mov [r15+0x38], rax
00007f4f7cbd0056  mov eax, [rsp+0x70]
00007f4f7cbd005a  mov r14d, [rsp+0x70]
00007f4f7cbd005f  shrd eax, r14d, 0x06
00007f4f7cbd0064  mov [rsp+0x70], r14d
00007f4f7cbd0069  mov r12d, [rsp+0x80]
00007f4f7cbd0071  and r14d, r12d
00007f4f7cbd0074  mov r11d, [rsp+0x10]
00007f4f7cbd0079  mov r10d, [rsp+0x10]
00007f4f7cbd007e  shrd r11d, r10d, 0x02
00007f4f7cbd0083  mov [rsp+0x10], r12d
00007f4f7cbd0088  mov r12d, r12d
00007f4f7cbd008b  mov [r15+0x20], r12
00007f4f7cbd008f  mov r12, [r15+0x50]
00007f4f7cbd0093  mov r9d, [r13+r12*1]
00007f4f7cbd0098  mov r12d, [rsp+0x50]
00007f4f7cbd009d  mov r8d, [rsp+0x70]
00007f4f7cbd00a2  andn ebp, r8d, r12d
00007f4f7cbd00a7  mov edi, [rsp+0x60]
00007f4f7cbd00ab  lea esi, [r14d+edi*1]
00007f4f7cbd00b0  rorx r14d, r8d, 0x0B
00007f4f7cbd00b6  xor eax, r14d
00007f4f7cbd00b9  rorx r14d, r10d, 0x0D
00007f4f7cbd00bf  xor r11d, r14d
00007f4f7cbd00c2  lea edi, [esi+ebp*1]
00007f4f7cbd00c6  mov r14, [r15+0x48]
00007f4f7cbd00ca  mov ebp, [r13+r14*1]
00007f4f7cbd00cf  mov r14d, [rsp+0x30]
00007f4f7cbd00d4  mov esi, [rsp+0x20]
00007f4f7cbd00d8  and r14d, esi
00007f4f7cbd00db  mov [rsp+0x20], r14d
00007f4f7cbd00e0  mov r14d, r14d
00007f4f7cbd00e3  mov [r15+0xD8], r14
00007f4f7cbd00ea  lea r14d, [edi+r9d*1]
00007f4f7cbd00ef  mov r9d, [rsp+0x30]
00007f4f7cbd00f4  xor r9d, esi
00007f4f7cbd00f7  rorx edi, r8d, 0x19
00007f4f7cbd00fd  xor eax, edi
00007f4f7cbd00ff  and r9d, r10d
00007f4f7cbd0102  rorx edi, r10d, 0x16
00007f4f7cbd0108  xor r11d, edi
00007f4f7cbd010b  mov [rsp+0x30], r11d
00007f4f7cbd0110  mov r11d, r11d
00007f4f7cbd0113  mov [r15+0xD0], r11
00007f4f7cbd011a  lea r11d, [r14d+ebp*1]
00007f4f7cbd011f  mov r10d, [rsp+0x20]
00007f4f7cbd0124  xor r9d, r10d
00007f4f7cbd0127  lea r14d, [r11d+eax*1]
00007f4f7cbd012c  mov qword ptr [r15+0x88], 0x04
00007f4f7cbd0137  mov eax, [rsp+0x30]
00007f4f7cbd013b  lea r11d, [r9d+eax*1]
00007f4f7cbd0140  mov eax, [rsp+0x40]
00007f4f7cbd0144  lea r10d, [r14d+eax*1]
00007f4f7cbd0149  mov r10d, r10d
00007f4f7cbd014c  mov [r15+0xB8], r10
00007f4f7cbd0153  xor eax, eax
00007f4f7cbd0155  mov r10d, 0x04
00007f4f7cbd015b  mov r9d, 0x100
00007f4f7cbd0161  cmp r10, r9
00007f4f7cbd0164  cmc
00007f4f7cbd0165  lahf
00007f4f7cbd0166  seto al
00007f4f7cbd0169  mov [r15+0x108], eax
00007f4f7cbd0170  lea eax, [r11d+r14d*1]
00007f4f7cbd0175  mov eax, eax
00007f4f7cbd0177  mov [r15+0xA8], rax
00007f4f7cbd017e  mov r12d, r12d
00007f4f7cbd0181  mov [r15+0xB0], r12
00007f4f7cbd0188  mov eax, [rsp+0x10]
00007f4f7cbd018c  mov eax, eax
00007f4f7cbd018e  mov [r15+0xC0], rax
00007f4f7cbd0195  mov r8d, r8d
00007f4f7cbd0198  mov [r15+0xC8], r8
00007f4f7cbd019f  mov eax, [r15+0x108]
00007f4f7cbd01a6  sahf
00007f4f7cbd01a7  jnz 0x00007F4F7CBD01D9
00007f4f7cbd01a9  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd01b1  jz 0x00007F4F7CBD04A0
00007f4f7cbd01b7  nop [rax+rax*1], ax
00007f4f7cbd01c0  nop [rax+rax*1], eax
00007f4f7cbd01c8  mov eax, 0x4108E0
00007f4f7cbd01cd  mov [r15+0x100], rax
00007f4f7cbd01d4  jmp 0x00007F4F7C9FE110
00007f4f7cbd01d9  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd01e1  jz 0x00007F4F7CBD0270
00007f4f7cbd01e7  nop [rax+rax*1], ax
00007f4f7cbd01f0  nop [rax+rax*1], eax
00007f4f7cbd01f8  mov eax, 0x410854
00007f4f7cbd01fd  mov [r15+0x100], rax
00007f4f7cbd0204  jmp 0x00007F4F7C9FE110
00007f4f7cbd0209  int3
00007f4f7cbd020a  call 0x00007F4F7CA0DAE0
00007f4f7cbd020f  jmp 0x00007F4F7CBCFF78
00007f4f7cbd0214  call 0x00007F4F7CAC0230
00007f4f7cbd0219  jmp 0x00007F4F7CBCFF81
00007f4f7cbd021e  call 0x00007F4F7CAE26A0
00007f4f7cbd0223  jmp 0x00007F4F7CBCFFA5
00007f4f7cbd0228  call 0x00007F4F7CAE1430
00007f4f7cbd022d  jmp 0x00007F4F7CBCFFAE
00007f4f7cbd0232  call 0x00007F4F7CAE26A0
00007f4f7cbd0237  jmp 0x00007F4F7CBCFFCF
00007f4f7cbd023c  call 0x00007F4F7CAE1430
00007f4f7cbd0241  jmp 0x00007F4F7CBCFFD8
00007f4f7cbd0246  call 0x00007F4F7CAE26A0
00007f4f7cbd024b  jmp 0x00007F4F7CBCFFF9
00007f4f7cbd0250  call 0x00007F4F7CAD5890
00007f4f7cbd0255  jmp 0x00007F4F7CBD0002
00007f4f7cbd025a  call 0x00007F4F7CABDD50
00007f4f7cbd025f  jmp 0x00007F4F7CBD0098
00007f4f7cbd0264  call 0x00007F4F7CADA580
00007f4f7cbd0269  jmp 0x00007F4F7CBD00CF
00007f4f7cbd026e  int3
00007f4f7cbd026f  nop
00007f4f7cbd0270  mov eax, [r15+0xB8]
00007f4f7cbd0277  mov [rsp+0x10], eax
00007f4f7cbd027b  mov eax, eax
00007f4f7cbd027d  mov [r15+0x30], rax
00007f4f7cbd0281  mov eax, [r15+0xC0]
00007f4f7cbd0288  mov [rsp+0x20], eax
00007f4f7cbd028c  mov eax, eax
00007f4f7cbd028e  mov [r15+0xA0], rax
00007f4f7cbd0295  mov eax, [r15+0x28]
00007f4f7cbd0299  mov r14d, [r15+0x98]
00007f4f7cbd02a0  mov [rsp+0x30], r14d
00007f4f7cbd02a5  mov r14d, r14d
00007f4f7cbd02a8  mov [r15+0x28], r14
00007f4f7cbd02ac  mov r14d, [r15+0x38]
00007f4f7cbd02b0  mov [rsp+0x40], r14d
00007f4f7cbd02b5  mov r14d, r14d
00007f4f7cbd02b8  mov [r15+0x98], r14
00007f4f7cbd02bf  mov r14d, [r15+0xA8]
00007f4f7cbd02c6  mov [rsp+0x50], r14d
00007f4f7cbd02cb  mov r14d, r14d
00007f4f7cbd02ce  mov [r15+0x38], r14
00007f4f7cbd02d2  mov r14d, [rsp+0x10]
00007f4f7cbd02d7  mov r12d, [rsp+0x10]
00007f4f7cbd02dc  shrd r14d, r12d, 0x06
00007f4f7cbd02e1  mov r11d, [r15+0xC8]
00007f4f7cbd02e8  mov [rsp+0x10], r12d
00007f4f7cbd02ed  and r12d, r11d
00007f4f7cbd02f0  mov r10d, [rsp+0x50]
00007f4f7cbd02f5  mov r9d, [rsp+0x50]
00007f4f7cbd02fa  shrd r10d, r9d, 0x02
00007f4f7cbd02ff  mov [rsp+0x50], r11d
00007f4f7cbd0304  mov r11d, r11d
00007f4f7cbd0307  mov [r15+0x20], r11
00007f4f7cbd030b  mov r11, [r15+0x88]
00007f4f7cbd0312  mov r8, [r15+0x50]
00007f4f7cbd0316  lea rbp, [r8+r11*1]
00007f4f7cbd031a  mov r8d, [r13+rbp*1]
00007f4f7cbd031f  mov ebp, [rsp+0x20]
00007f4f7cbd0323  mov edi, [rsp+0x10]
00007f4f7cbd0327  andn esi, edi, ebp
00007f4f7cbd032c  mov edx, [r15+0xB0]
00007f4f7cbd0333  lea ecx, [r12d+edx*1]
00007f4f7cbd0338  rorx r12d, edi, 0x0B
00007f4f7cbd033e  xor r14d, r12d
00007f4f7cbd0341  rorx r12d, r9d, 0x0D
00007f4f7cbd0347  xor r10d, r12d
00007f4f7cbd034a  lea r12d, [ecx+esi*1]
00007f4f7cbd034f  mov rsi, [r15+0x48]
00007f4f7cbd0353  lea rdx, [rsi+r11*1]
00007f4f7cbd0357  mov esi, [r13+rdx*1]
00007f4f7cbd035c  mov edx, [rsp+0x30]
00007f4f7cbd0360  mov ecx, [rsp+0x40]
00007f4f7cbd0364  and edx, ecx
00007f4f7cbd0366  mov [rsp+0x10], edx
00007f4f7cbd036a  mov edx, edx
00007f4f7cbd036c  mov [r15+0xD8], rdx
00007f4f7cbd0373  lea edx, [r12d+r8d*1]
00007f4f7cbd0378  mov r12d, [rsp+0x30]
00007f4f7cbd037d  xor r12d, ecx
00007f4f7cbd0380  rorx r8d, edi, 0x19
00007f4f7cbd0386  xor r14d, r8d
00007f4f7cbd0389  and r12d, r9d
00007f4f7cbd038c  rorx r8d, r9d, 0x16
00007f4f7cbd0392  xor r10d, r8d
00007f4f7cbd0395  mov [rsp+0x20], r10d
00007f4f7cbd039a  mov r10d, r10d
00007f4f7cbd039d  mov [r15+0xD0], r10
00007f4f7cbd03a4  lea r10d, [edx+esi*1]
00007f4f7cbd03a9  mov r9d, [rsp+0x10]
00007f4f7cbd03ae  xor r12d, r9d
00007f4f7cbd03b1  lea r9d, [r10d+r14d*1]
00007f4f7cbd03b6  lea r14, [r11+0x04]
00007f4f7cbd03ba  mov [r15+0x88], r14
00007f4f7cbd03c1  mov r11d, [rsp+0x20]
00007f4f7cbd03c6  lea r10d, [r12d+r11d*1]
00007f4f7cbd03cb  lea r11d, [r9d+eax*1]
00007f4f7cbd03d0  mov r11d, r11d
00007f4f7cbd03d3  mov [r15+0xB8], r11
00007f4f7cbd03da  xor eax, eax
00007f4f7cbd03dc  mov r12d, 0x100
00007f4f7cbd03e2  cmp r14, r12
00007f4f7cbd03e5  cmc
00007f4f7cbd03e6  lahf
00007f4f7cbd03e7  seto al
00007f4f7cbd03ea  mov [r15+0x108], eax
00007f4f7cbd03f1  lea eax, [r10d+r9d*1]
00007f4f7cbd03f6  mov eax, eax
00007f4f7cbd03f8  mov [r15+0xA8], rax
00007f4f7cbd03ff  mov ebp, ebp
00007f4f7cbd0401  mov [r15+0xB0], rbp
00007f4f7cbd0408  mov eax, [rsp+0x50]
00007f4f7cbd040c  mov eax, eax
00007f4f7cbd040e  mov [r15+0xC0], rax
00007f4f7cbd0415  mov edi, edi
00007f4f7cbd0417  mov [r15+0xC8], rdi
00007f4f7cbd041e  mov eax, [r15+0x108]
00007f4f7cbd0425  sahf
00007f4f7cbd0426  jnz 0x00007F4F7CBD0458
00007f4f7cbd0428  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0430  jz 0x00007F4F7CBD04A0
00007f4f7cbd0436  nop [rax+rax*1], ax
00007f4f7cbd043f  nop [rax+rax*1], eax
00007f4f7cbd0447  mov eax, 0x4108E0
00007f4f7cbd044c  mov [r15+0x100], rax
00007f4f7cbd0453  jmp 0x00007F4F7C9FE110
00007f4f7cbd0458  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0460  jz 0x00007F4F7CBD0270
00007f4f7cbd0466  nop [rax+rax*1], ax
00007f4f7cbd046f  nop [rax+rax*1], eax
00007f4f7cbd0477  mov eax, 0x410854
00007f4f7cbd047c  mov [r15+0x100], rax
00007f4f7cbd0483  jmp 0x00007F4F7C9FE110
00007f4f7cbd0488  int3
00007f4f7cbd0489  call 0x00007F4F7CA49010
00007f4f7cbd048e  jmp 0x00007F4F7CBD031F
00007f4f7cbd0493  call 0x00007F4F7CA25930
00007f4f7cbd0498  jmp 0x00007F4F7CBD035C
00007f4f7cbd049d  int3
00007f4f7cbd049e  nop
00007f4f7cbd04a0  mov eax, [r15+0x98]
00007f4f7cbd04a7  mov r14d, [r15+0x70]
00007f4f7cbd04ab  lea r12d, [eax+r14d*1]
00007f4f7cbd04b0  mov eax, [r15+0x28]
00007f4f7cbd04b4  mov r14d, [r15+0x68]
00007f4f7cbd04b8  lea r11d, [eax+r14d*1]
00007f4f7cbd04bd  mov qword ptr [r15+0x88], 0x00
00007f4f7cbd04c8  mov eax, [r15+0xA8]
00007f4f7cbd04cf  mov r14d, [r15+0x78]
00007f4f7cbd04d3  lea r10d, [eax+r14d*1]
00007f4f7cbd04d8  mov [rsp+0x10], r10d
00007f4f7cbd04dd  mov r10d, r10d
00007f4f7cbd04e0  mov [r15+0x78], r10
00007f4f7cbd04e4  mov eax, [r15+0x38]
00007f4f7cbd04e8  mov r14d, [r15+0x80]
00007f4f7cbd04ef  lea r10d, [eax+r14d*1]
00007f4f7cbd04f4  mov [rsp+0x20], r10d
00007f4f7cbd04f9  mov r10d, r10d
00007f4f7cbd04fc  mov [r15+0x80], r10
00007f4f7cbd0503  mov rax, [r15]
00007f4f7cbd0506  lea r14, [rax+0x08]
00007f4f7cbd050a  mov [r13+r14*1], r12d
00007f4f7cbd050f  lea r14, [rax+0x0C]
00007f4f7cbd0513  mov [r13+r14*1], r11d
00007f4f7cbd0518  mov r14d, [r15+0xB8]
00007f4f7cbd051f  mov r12d, [r15+0x18]
00007f4f7cbd0523  lea r11d, [r14d+r12d*1]
00007f4f7cbd0528  mov [rsp+0x30], r11d
00007f4f7cbd052d  mov r11d, r11d
00007f4f7cbd0530  mov [r15+0x68], r11
00007f4f7cbd0534  mov r14d, [r15+0x30]
00007f4f7cbd0538  mov r12d, [r15+0x90]
00007f4f7cbd053f  lea r11d, [r14d+r12d*1]
00007f4f7cbd0544  mov [rsp+0x40], r11d
00007f4f7cbd0549  mov r11d, r11d
00007f4f7cbd054c  mov [r15+0x70], r11
00007f4f7cbd0550  mov r14d, [r15+0x20]
00007f4f7cbd0554  mov r12d, [r15+0x58]
00007f4f7cbd0558  lea r11d, [r14d+r12d*1]
00007f4f7cbd055d  mov [rsp+0x50], r11d
00007f4f7cbd0562  mov r11d, r11d
00007f4f7cbd0565  mov [r15+0x58], r11
00007f4f7cbd0569  mov r14d, [r15+0xA0]
00007f4f7cbd0570  mov r12d, [r15+0x60]
00007f4f7cbd0574  lea r11d, [r14d+r12d*1]
00007f4f7cbd0579  mov [rsp+0x60], r11d
00007f4f7cbd057e  mov r11d, r11d
00007f4f7cbd0581  mov [r15+0x60], r11
00007f4f7cbd0585  mov r14d, [rsp+0x10]
00007f4f7cbd058a  mov [r13+rax*1], r14d
00007f4f7cbd058f  lea r14, [rax+0x04]
00007f4f7cbd0593  mov r12d, [rsp+0x20]
00007f4f7cbd0598  mov [r13+r14*1], r12d
00007f4f7cbd059d  lea r14, [rax+0x10]
00007f4f7cbd05a1  mov r12d, [rsp+0x30]
00007f4f7cbd05a6  mov [r13+r14*1], r12d
00007f4f7cbd05ab  lea r14, [rax+0x14]
00007f4f7cbd05af  mov r12d, [rsp+0x40]
00007f4f7cbd05b4  mov [r13+r14*1], r12d
00007f4f7cbd05b9  lea r14, [rax+0x18]
00007f4f7cbd05bd  mov r12d, [rsp+0x50]
00007f4f7cbd05c2  mov [r13+r14*1], r12d
00007f4f7cbd05c7  lea r14, [rax+0x1C]
00007f4f7cbd05cb  mov r12d, [rsp+0x60]
00007f4f7cbd05d0  mov [r13+r14*1], r12d
00007f4f7cbd05d5  lea r14, [rax+0x68]
00007f4f7cbd05d9  xor eax, eax
00007f4f7cbd05db  mov [r13+r14*1], rax
00007f4f7cbd05e0  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd05e8  jz 0x00007F4F7CBCF0E0
00007f4f7cbd05ee  nop [rax+rax*1], ax
00007f4f7cbd05f7  nop [rax+rax*1], eax
00007f4f7cbd05ff  mov eax, 0x4106FC
00007f4f7cbd0604  mov [r15+0x100], rax
00007f4f7cbd060b  jmp 0x00007F4F7C9FE110
00007f4f7cbd0610  int3
00007f4f7cbd0611  call 0x00007F4F7CAE2BA0
00007f4f7cbd0616  jmp 0x00007F4F7CBD050F
00007f4f7cbd061b  call 0x00007F4F7CAE1920
00007f4f7cbd0620  jmp 0x00007F4F7CBD0518
00007f4f7cbd0625  call 0x00007F4F7CA0DFE0
00007f4f7cbd062a  jmp 0x00007F4F7CBD058F
00007f4f7cbd062f  call 0x00007F4F7CAE2BA0
00007f4f7cbd0634  jmp 0x00007F4F7CBD059D
00007f4f7cbd0639  call 0x00007F4F7CAE2BA0
00007f4f7cbd063e  jmp 0x00007F4F7CBD05AB
00007f4f7cbd0643  call 0x00007F4F7CAE2BA0
00007f4f7cbd0648  jmp 0x00007F4F7CBD05B9
00007f4f7cbd064d  call 0x00007F4F7CAE2BA0
00007f4f7cbd0652  jmp 0x00007F4F7CBD05C7
00007f4f7cbd0657  call 0x00007F4F7CAE2BA0
00007f4f7cbd065c  jmp 0x00007F4F7CBD05D5
00007f4f7cbd0661  call 0x00007F4F7CAD5EB0
00007f4f7cbd0666  jmp 0x00007F4F7CBD05E0
00007f4f7cbd066b  int3
00007f4f7cbd066c  nop [rax], eax
00007f4f7cbd0670  mov rax, [r15+0xF8]
00007f4f7cbd0677  lea r14, [rax+0x140]
00007f4f7cbd067e  mov r12, [r13+r14*1]
00007f4f7cbd0683  lea r14, [rax+0x148]
00007f4f7cbd068a  mov r11, [r13+r14*1]
00007f4f7cbd068f  mov [r15+0xA0], r12
00007f4f7cbd0696  mov [r15+0x98], r11
00007f4f7cbd069d  lea r14, [rax+0x130]
00007f4f7cbd06a4  mov r12, [r13+r14*1]
00007f4f7cbd06a9  lea r14, [rax+0x138]
00007f4f7cbd06b0  mov r11, [r13+r14*1]
00007f4f7cbd06b5  mov [r15+0xB0], r12
00007f4f7cbd06bc  mov [r15+0xA8], r11
00007f4f7cbd06c3  lea r14, [rax+0x120]
00007f4f7cbd06ca  mov r12, [r13+r14*1]
00007f4f7cbd06cf  lea r14, [rax+0x128]
00007f4f7cbd06d6  mov r11, [r13+r14*1]
00007f4f7cbd06db  mov [r15+0xC0], r12
00007f4f7cbd06e2  mov [r15+0xB8], r11
00007f4f7cbd06e9  lea r14, [rax+0x110]
00007f4f7cbd06f0  mov r12, [r13+r14*1]
00007f4f7cbd06f5  lea r14, [rax+0x118]
00007f4f7cbd06fc  mov r11, [r13+r14*1]
00007f4f7cbd0701  mov [r15+0xD0], r12
00007f4f7cbd0708  mov [r15+0xC8], r11
00007f4f7cbd070f  lea r14, [rax+0x100]
00007f4f7cbd0716  mov r12, [r13+r14*1]
00007f4f7cbd071b  lea r14, [rax+0x108]
00007f4f7cbd0722  mov r11, [r13+r14*1]
00007f4f7cbd0727  mov [r15+0xE8], r12
00007f4f7cbd072e  mov [r15+0xD8], r11
00007f4f7cbd0735  lea r14, [rax+0x150]
00007f4f7cbd073c  mov [r15+0xF8], r14
00007f4f7cbd0743  mov rax, [r15+0xF0]
00007f4f7cbd074a  mov [r15+0x100], rax
00007f4f7cbd0751  jmp 0x00007F4F7CBCE5C0
00007f4f7cbd0756  int3
00007f4f7cbd0757  call 0x00007F4F7CAE27E0
00007f4f7cbd075c  jmp 0x00007F4F7CBD0683
00007f4f7cbd0761  call 0x00007F4F7CAE1570
00007f4f7cbd0766  jmp 0x00007F4F7CBD068F
00007f4f7cbd076b  call 0x00007F4F7CAE27E0
00007f4f7cbd0770  jmp 0x00007F4F7CBD06A9
00007f4f7cbd0775  call 0x00007F4F7CAE1570
00007f4f7cbd077a  jmp 0x00007F4F7CBD06B5
00007f4f7cbd077f  call 0x00007F4F7CAE27E0
00007f4f7cbd0784  jmp 0x00007F4F7CBD06CF
00007f4f7cbd0789  call 0x00007F4F7CAE1570
00007f4f7cbd078e  jmp 0x00007F4F7CBD06DB
00007f4f7cbd0793  call 0x00007F4F7CAE27E0
00007f4f7cbd0798  jmp 0x00007F4F7CBD06F5
00007f4f7cbd079d  call 0x00007F4F7CAE1570
00007f4f7cbd07a2  jmp 0x00007F4F7CBD0701
00007f4f7cbd07a7  call 0x00007F4F7CAE27E0
00007f4f7cbd07ac  jmp 0x00007F4F7CBD071B
00007f4f7cbd07b1  call 0x00007F4F7CAE1570
00007f4f7cbd07b6  jmp 0x00007F4F7CBD0727
00007f4f7cbd07bb  int3
00007f4f7cbd07bc  nop [rax], eax
00007f4f7cbd07c0  mov eax, [r15+0xA0]
00007f4f7cbd07c7  mov [rsp+0x10], eax
00007f4f7cbd07cb  xor eax, eax
00007f4f7cbd07cd  mov r14d, [rsp+0x10]
00007f4f7cbd07d2  sub r14d, 0x01
00007f4f7cbd07d6  cmc
00007f4f7cbd07d7  lahf
00007f4f7cbd07d8  seto al
00007f4f7cbd07db  mov [r15+0x108], eax
00007f4f7cbd07e2  mov r14d, r14d
00007f4f7cbd07e5  mov [r15+0xA0], r14
00007f4f7cbd07ec  mov eax, [r15+0x108]
00007f4f7cbd07f3  sahf
00007f4f7cbd07f4  jnz 0x00007F4F7CBD0826
00007f4f7cbd07f6  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd07fe  jz 0x00007F4F7CBD0900
00007f4f7cbd0804  nop [rax+rax*1], ax
00007f4f7cbd080d  nop [rax+rax*1], eax
00007f4f7cbd0815  mov eax, 0x41028C
00007f4f7cbd081a  mov [r15+0x100], rax
00007f4f7cbd0821  jmp 0x00007F4F7C9FE110
00007f4f7cbd0826  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd082e  jz 0x00007F4F7CBD0860
00007f4f7cbd0834  nop [rax+rax*1], ax
00007f4f7cbd083d  nop [rax+rax*1], eax
00007f4f7cbd0845  mov eax, 0x410274
00007f4f7cbd084a  mov [r15+0x100], rax
00007f4f7cbd0851  jmp 0x00007F4F7C9FE110
00007f4f7cbd0856  int3
00007f4f7cbd0857  int3
00007f4f7cbd0858  nop [rax+rax*1], eax
00007f4f7cbd0860  mov rax, [r15+0xF8]
00007f4f7cbd0867  lea r14, [rax+0xD0]
00007f4f7cbd086e  mov [r15], r14
00007f4f7cbd0871  mov rax, [r15+0x98]
00007f4f7cbd0878  mov [r15+0x08], rax
00007f4f7cbd087c  mov qword ptr [r15+0x10], 0x12C
00007f4f7cbd0884  mov qword ptr [r15+0xF0], 0x410284
00007f4f7cbd088f  mov r14d, [r15+0x320]
00007f4f7cbd0896  mov eax, 0x410284
00007f4f7cbd089b  mov rcx, 0x7F4F7CBD07C0
00007f4f7cbd08a5  mov [r15+r14*8+0x328], rax
00007f4f7cbd08ad  mov [r15+r14*8+0x368], rcx
00007f4f7cbd08b5  add r14d, 0x01
00007f4f7cbd08b9  and r14d, 0x07
00007f4f7cbd08bd  mov [r15+0x320], r14d
00007f4f7cbd08c4  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd08cc  jz 0x00007F4F7CBCED70
00007f4f7cbd08d2  nop [rax+rax*1], ax
00007f4f7cbd08db  nop [rax+rax*1], eax
00007f4f7cbd08e3  mov eax, 0x4106BC
00007f4f7cbd08e8  mov [r15+0x100], rax
00007f4f7cbd08ef  jmp 0x00007F4F7C9FE110
00007f4f7cbd08f4  int3
00007f4f7cbd08f5  int3
00007f4f7cbd08f6  nop [rax+rax*1], ax
00007f4f7cbd08ff  nop
00007f4f7cbd0900  mov rax, [r15+0xF8]
00007f4f7cbd0907  lea r14, [rax+0xF0]
00007f4f7cbd090e  mov r12, [r13+r14*1]
00007f4f7cbd0913  mov [r15+0x98], r12
00007f4f7cbd091a  mov qword ptr [r15+0x40], 0x80
00007f4f7cbd0922  lea r14, [rax+0xD0]
00007f4f7cbd0929  mov [r15], r14
00007f4f7cbd092c  lea r14, [rax+0x14C]
00007f4f7cbd0933  mov [r15+0x08], r14
00007f4f7cbd0937  mov qword ptr [r15+0x10], 0x01
00007f4f7cbd093f  lea r14, [rax+0x14C]
00007f4f7cbd0946  mov eax, 0x80
00007f4f7cbd094b  mov [r13+r14*1], al
00007f4f7cbd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007f4f7cbd095b  mov r14d, [r15+0x320]
00007f4f7cbd0962  mov eax, 0x4102A8
00007f4f7cbd0967  mov rcx, 0x7F4F7CBD09E0
00007f4f7cbd0971  mov [r15+r14*8+0x328], rax
00007f4f7cbd0979  mov [r15+r14*8+0x368], rcx
00007f4f7cbd0981  add r14d, 0x01
00007f4f7cbd0985  and r14d, 0x07
00007f4f7cbd0989  mov [r15+0x320], r14d
00007f4f7cbd0990  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0998  jz 0x00007F4F7CBCED70
00007f4f7cbd099e  nop [rax+rax*1], ax
00007f4f7cbd09a7  nop [rax+rax*1], eax
00007f4f7cbd09af  mov eax, 0x4106BC
00007f4f7cbd09b4  mov [r15+0x100], rax
00007f4f7cbd09bb  jmp 0x00007F4F7C9FE110
00007f4f7cbd09c0  int3
00007f4f7cbd09c1  call 0x00007F4F7CAE27E0
00007f4f7cbd09c6  jmp 0x00007F4F7CBD0913
00007f4f7cbd09cb  call 0x00007F4F7CAD5AF0
00007f4f7cbd09d0  jmp 0x00007F4F7CBD0950
00007f4f7cbd09d5  int3
00007f4f7cbd09d6  nop [rax+rax*1], ax
00007f4f7cbd09df  nop
00007f4f7cbd09e0  mov rax, [r15+0xF8]
00007f4f7cbd09e7  lea r14, [rax+0x138]
00007f4f7cbd09ee  mov r12, [r13+r14*1]
00007f4f7cbd09f3  mov [r15+0x40], r12
00007f4f7cbd09f7  lea r14, [rax+0x148]
00007f4f7cbd09fe  xor eax, eax
00007f4f7cbd0a00  mov [r13+r14*1], al
00007f4f7cbd0a05  xor eax, eax
00007f4f7cbd0a07  mov r14d, 0x38
00007f4f7cbd0a0d  cmp r12, r14
00007f4f7cbd0a10  cmc
00007f4f7cbd0a11  lahf
00007f4f7cbd0a12  seto al
00007f4f7cbd0a15  mov [r15+0x108], eax
00007f4f7cbd0a1c  mov eax, [r15+0x108]
00007f4f7cbd0a23  sahf
00007f4f7cbd0a24  jz 0x00007F4F7CBD0A56
00007f4f7cbd0a26  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0a2e  jz 0x00007F4F7CBD0AA0
00007f4f7cbd0a34  nop [rax+rax*1], ax
00007f4f7cbd0a3d  nop [rax+rax*1], eax
00007f4f7cbd0a45  mov eax, 0x4102B8
00007f4f7cbd0a4a  mov [r15+0x100], rax
00007f4f7cbd0a51  jmp 0x00007F4F7C9FE110
00007f4f7cbd0a56  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0a5e  jz 0x00007F4F7CBD0BF0
00007f4f7cbd0a64  nop [rax+rax*1], ax
00007f4f7cbd0a6d  nop [rax+rax*1], eax
00007f4f7cbd0a75  mov eax, 0x4102D4
00007f4f7cbd0a7a  mov [r15+0x100], rax
00007f4f7cbd0a81  jmp 0x00007F4F7C9FE110
00007f4f7cbd0a86  int3
00007f4f7cbd0a87  call 0x00007F4F7CAE27E0
00007f4f7cbd0a8c  jmp 0x00007F4F7CBD09F3
00007f4f7cbd0a91  call 0x00007F4F7CAD5AF0
00007f4f7cbd0a96  jmp 0x00007F4F7CBD0A05
00007f4f7cbd0a9b  int3
00007f4f7cbd0a9c  nop [rax], eax
00007f4f7cbd0aa0  mov rax, [r15+0xF8]
00007f4f7cbd0aa7  lea r14, [rax+0xD0]
00007f4f7cbd0aae  mov [r15], r14
00007f4f7cbd0ab1  lea r14, [rax+0x148]
00007f4f7cbd0ab8  mov [r15+0x08], r14
00007f4f7cbd0abc  mov qword ptr [r15+0x10], 0x01
00007f4f7cbd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007f4f7cbd0acf  mov r14d, [r15+0x320]
00007f4f7cbd0ad6  mov eax, 0x4102C8
00007f4f7cbd0adb  mov rcx, 0x7F4F7CBD0B40
00007f4f7cbd0ae5  mov [r15+r14*8+0x328], rax
00007f4f7cbd0aed  mov [r15+r14*8+0x368], rcx
00007f4f7cbd0af5  add r14d, 0x01
00007f4f7cbd0af9  and r14d, 0x07
00007f4f7cbd0afd  mov [r15+0x320], r14d
00007f4f7cbd0b04  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0b0c  jz 0x00007F4F7CBCED70
00007f4f7cbd0b12  nop [rax+rax*1], ax
00007f4f7cbd0b1b  nop [rax+rax*1], eax
00007f4f7cbd0b23  mov eax, 0x4106BC
00007f4f7cbd0b28  mov [r15+0x100], rax
00007f4f7cbd0b2f  jmp 0x00007F4F7C9FE110
00007f4f7cbd0b34  int3
00007f4f7cbd0b35  int3
00007f4f7cbd0b36  nop [rax+rax*1], ax
00007f4f7cbd0b3f  nop
00007f4f7cbd0b40  mov rax, [r15+0xF8]
00007f4f7cbd0b47  lea r14, [rax+0x138]
00007f4f7cbd0b4e  mov rax, [r13+r14*1]
00007f4f7cbd0b53  mov [r15+0x40], rax
00007f4f7cbd0b57  mov [rsp+0x10], rax
00007f4f7cbd0b5c  xor eax, eax
00007f4f7cbd0b5e  mov r14, [rsp+0x10]
00007f4f7cbd0b63  mov r12d, 0x38
00007f4f7cbd0b69  cmp r14, r12
00007f4f7cbd0b6c  cmc
00007f4f7cbd0b6d  lahf
00007f4f7cbd0b6e  seto al
00007f4f7cbd0b71  mov [r15+0x108], eax
00007f4f7cbd0b78  mov eax, [r15+0x108]
00007f4f7cbd0b7f  sahf
00007f4f7cbd0b80  jnz 0x00007F4F7CBD0BB2
00007f4f7cbd0b82  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0b8a  jz 0x00007F4F7CBD0BF0
00007f4f7cbd0b90  nop [rax+rax*1], ax
00007f4f7cbd0b99  nop [rax+rax*1], eax
00007f4f7cbd0ba1  mov eax, 0x4102D4
00007f4f7cbd0ba6  mov [r15+0x100], rax
00007f4f7cbd0bad  jmp 0x00007F4F7C9FE110
00007f4f7cbd0bb2  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0bba  jz 0x00007F4F7CBD0AA0
00007f4f7cbd0bc0  nop [rax+rax*1], ax
00007f4f7cbd0bc9  nop [rax+rax*1], eax
00007f4f7cbd0bd1  mov eax, 0x4102B8
00007f4f7cbd0bd6  mov [r15+0x100], rax
00007f4f7cbd0bdd  jmp 0x00007F4F7C9FE110
00007f4f7cbd0be2  int3
00007f4f7cbd0be3  call 0x00007F4F7CAD59C0
00007f4f7cbd0be8  jmp 0x00007F4F7CBD0B53
00007f4f7cbd0bed  int3
00007f4f7cbd0bee  nop
00007f4f7cbd0bf0  mov rax, [r15+0x98]
00007f4f7cbd0bf7  rorx r14, rax, 0x3D
00007f4f7cbd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007f4f7cbd0c01  mov rax, [r15+0xF8]
00007f4f7cbd0c08  lea r12, [rax+0xD0]
00007f4f7cbd0c0f  mov [r15], r12
00007f4f7cbd0c12  lea r12, [rax+0x140]
00007f4f7cbd0c19  mov [r15+0x08], r12
00007f4f7cbd0c1d  mov qword ptr [r15+0x10], 0x08
00007f4f7cbd0c25  bswap r14
00007f4f7cbd0c28  mov [r15+0x40], r14
00007f4f7cbd0c2c  lea r12, [rax+0x140]
00007f4f7cbd0c33  mov [r13+r12*1], r14
00007f4f7cbd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007f4f7cbd0c43  mov r14d, [r15+0x320]
00007f4f7cbd0c4a  mov eax, 0x4102F0
00007f4f7cbd0c4f  mov rcx, 0x7F4F7CBD0CC0
00007f4f7cbd0c59  mov [r15+r14*8+0x328], rax
00007f4f7cbd0c61  mov [r15+r14*8+0x368], rcx
00007f4f7cbd0c69  add r14d, 0x01
00007f4f7cbd0c6d  and r14d, 0x07
00007f4f7cbd0c71  mov [r15+0x320], r14d
00007f4f7cbd0c78  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0c80  jz 0x00007F4F7CBCED70
00007f4f7cbd0c86  nop [rax+rax*1], ax
00007f4f7cbd0c8f  nop [rax+rax*1], eax
00007f4f7cbd0c97  mov eax, 0x4106BC
00007f4f7cbd0c9c  mov [r15+0x100], rax
00007f4f7cbd0ca3  jmp 0x00007F4F7C9FE110
00007f4f7cbd0ca8  int3
00007f4f7cbd0ca9  call 0x00007F4F7CAC3FE0
00007f4f7cbd0cae  jmp 0x00007F4F7CBD0C38
00007f4f7cbd0cb3  int3
00007f4f7cbd0cb4  nop [rax+rax*1], ax
00007f4f7cbd0cbd  nop [rax], eax
00007f4f7cbd0cc0  mov rax, [r15+0xF8]
00007f4f7cbd0cc7  lea r14, [rax+0xD0]
00007f4f7cbd0cce  mov r12d, [r13+r14*1]
00007f4f7cbd0cd3  lea r14, [rax+0xD4]
00007f4f7cbd0cda  mov r11d, [r13+r14*1]
00007f4f7cbd0cdf  lea r14, [rax+0xD8]
00007f4f7cbd0ce6  mov r10d, [r13+r14*1]
00007f4f7cbd0ceb  lea r14, [rax+0xDC]
00007f4f7cbd0cf2  mov r9d, [r13+r14*1]
00007f4f7cbd0cf7  mov qword ptr [r15+0x48], 0x430C20
00007f4f7cbd0cff  mov qword ptr [r15+0xA0], 0x00
00007f4f7cbd0d0a  bswap r12d
00007f4f7cbd0d0d  bswap r11d
00007f4f7cbd0d10  mov qword ptr [r15+0x98], 0x430D8C
00007f4f7cbd0d1b  mov r14d, 0x430C20
00007f4f7cbd0d21  mov [r13+r14*1], r12d
00007f4f7cbd0d26  mov r14d, 0x430C24
00007f4f7cbd0d2c  mov [r13+r14*1], r11d
00007f4f7cbd0d31  bswap r10d
00007f4f7cbd0d34  bswap r9d
00007f4f7cbd0d37  lea r14, [rax+0xE0]
00007f4f7cbd0d3e  mov r12d, [r13+r14*1]
00007f4f7cbd0d43  lea r14, [rax+0xE4]
00007f4f7cbd0d4a  mov r11d, [r13+r14*1]
00007f4f7cbd0d4f  mov r14d, 0x430C28
00007f4f7cbd0d55  mov [r13+r14*1], r10d
00007f4f7cbd0d5a  mov r14d, 0x430C2C
00007f4f7cbd0d60  mov [r13+r14*1], r9d
00007f4f7cbd0d65  bswap r12d
00007f4f7cbd0d68  bswap r11d
00007f4f7cbd0d6b  mov [rsp+0x10], r11d
00007f4f7cbd0d70  mov r11d, r11d
00007f4f7cbd0d73  mov [r15+0x58], r11
00007f4f7cbd0d77  lea r14, [rax+0xE8]
00007f4f7cbd0d7e  mov r11d, [r13+r14*1]
00007f4f7cbd0d83  lea r14, [rax+0xEC]
00007f4f7cbd0d8a  mov eax, [r13+r14*1]
00007f4f7cbd0d8f  mov [rsp+0x20], eax
00007f4f7cbd0d93  mov eax, eax
00007f4f7cbd0d95  mov [r15+0x60], rax
00007f4f7cbd0d99  mov eax, 0x430C30
00007f4f7cbd0d9e  mov [r13+rax*1], r12d
00007f4f7cbd0da3  mov eax, 0x430C34
00007f4f7cbd0da8  mov r14d, [rsp+0x10]
00007f4f7cbd0dad  mov [r13+rax*1], r14d
00007f4f7cbd0db2  bswap r11d
00007f4f7cbd0db5  mov [rsp+0x10], r11d
00007f4f7cbd0dba  mov r11d, r11d
00007f4f7cbd0dbd  mov [r15+0x40], r11
00007f4f7cbd0dc1  mov eax, [rsp+0x20]
00007f4f7cbd0dc5  bswap eax
00007f4f7cbd0dc7  mov [rsp+0x20], eax
00007f4f7cbd0dcb  mov eax, eax
00007f4f7cbd0dcd  mov [r15+0x50], rax
00007f4f7cbd0dd1  mov eax, 0x430C38
00007f4f7cbd0dd6  mov r14d, [rsp+0x10]
00007f4f7cbd0ddb  mov [r13+rax*1], r14d
00007f4f7cbd0de0  mov eax, 0x430C3C
00007f4f7cbd0de5  mov r14d, [rsp+0x20]
00007f4f7cbd0dea  mov [r13+rax*1], r14d
00007f4f7cbd0def  mov eax, [r15+0xA0]
00007f4f7cbd0df6  lea r14d, [eax+0x11]
00007f4f7cbd0dfb  mov r14d, r14d
00007f4f7cbd0dfe  mov [r15], r14
00007f4f7cbd0e01  mov qword ptr [r15+0xF0], 0x41034C
00007f4f7cbd0e0c  mov r14d, [r15+0x320]
00007f4f7cbd0e13  mov eax, 0x41034C
00007f4f7cbd0e18  mov rcx, 0x7F4F7CBD0F90
00007f4f7cbd0e22  mov [r15+r14*8+0x328], rax
00007f4f7cbd0e2a  mov [r15+r14*8+0x368], rcx
00007f4f7cbd0e32  add r14d, 0x01
00007f4f7cbd0e36  and r14d, 0x07
00007f4f7cbd0e3a  mov [r15+0x320], r14d
00007f4f7cbd0e41  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0e49  jz 0x00007F4F7CBD0F20
00007f4f7cbd0e4f  nop [rax+rax*1], ax
00007f4f7cbd0e58  nop [rax+rax*1], eax
00007f4f7cbd0e60  mov eax, 0x410938
00007f4f7cbd0e65  mov [r15+0x100], rax
00007f4f7cbd0e6c  jmp 0x00007F4F7C9FE110
00007f4f7cbd0e71  int3
00007f4f7cbd0e72  call 0x00007F4F7CAE26A0
00007f4f7cbd0e77  jmp 0x00007F4F7CBD0CD3
00007f4f7cbd0e7c  call 0x00007F4F7CAE1430
00007f4f7cbd0e81  jmp 0x00007F4F7CBD0CDF
00007f4f7cbd0e86  call 0x00007F4F7CAE01C0
00007f4f7cbd0e8b  jmp 0x00007F4F7CBD0CEB
00007f4f7cbd0e90  call 0x00007F4F7CADEF50
00007f4f7cbd0e95  jmp 0x00007F4F7CBD0CF7
00007f4f7cbd0e9a  call 0x00007F4F7CAE2BA0
00007f4f7cbd0e9f  jmp 0x00007F4F7CBD0D26
00007f4f7cbd0ea4  call 0x00007F4F7CAE1920
00007f4f7cbd0ea9  jmp 0x00007F4F7CBD0D31
00007f4f7cbd0eae  call 0x00007F4F7CAE26A0
00007f4f7cbd0eb3  jmp 0x00007F4F7CBD0D43
00007f4f7cbd0eb8  call 0x00007F4F7CAE1430
00007f4f7cbd0ebd  jmp 0x00007F4F7CBD0D4F
00007f4f7cbd0ec2  call 0x00007F4F7CAE06B0
00007f4f7cbd0ec7  jmp 0x00007F4F7CBD0D5A
00007f4f7cbd0ecc  call 0x00007F4F7CADF440
00007f4f7cbd0ed1  jmp 0x00007F4F7CBD0D65
00007f4f7cbd0ed6  call 0x00007F4F7CAE1430
00007f4f7cbd0edb  jmp 0x00007F4F7CBD0D83
00007f4f7cbd0ee0  call 0x00007F4F7CAD5890
00007f4f7cbd0ee5  jmp 0x00007F4F7CBD0D8F
00007f4f7cbd0eea  call 0x00007F4F7CA0BAE0
00007f4f7cbd0eef  jmp 0x00007F4F7CBD0DA3
00007f4f7cbd0ef4  call 0x00007F4F7CA0DFE0
00007f4f7cbd0ef9  jmp 0x00007F4F7CBD0DB2
00007f4f7cbd0efe  call 0x00007F4F7CA0DFE0
00007f4f7cbd0f03  jmp 0x00007F4F7CBD0DE0
00007f4f7cbd0f08  call 0x00007F4F7CA0DFE0
00007f4f7cbd0f0d  jmp 0x00007F4F7CBD0DEF
00007f4f7cbd0f12  int3
00007f4f7cbd0f13  nop [rax+rax*1], ax
00007f4f7cbd0f1c  nop [rax], eax
00007f4f7cbd0f20  mov eax, [r15]
00007f4f7cbd0f23  mov [rsp+0x10], eax
00007f4f7cbd0f27  shr eax, 0x10
00007f4f7cbd0f2a  mov r14d, [rsp+0x10]
00007f4f7cbd0f2f  xor r14d, eax
00007f4f7cbd0f32  imul r14d, r14d, 0x7FEB352D
00007f4f7cbd0f39  mov eax, 0x846CA68B
00007f4f7cbd0f3e  mov eax, eax
00007f4f7cbd0f40  mov [r15+0x48], rax
00007f4f7cbd0f44  mov [rsp+0x10], r14d
00007f4f7cbd0f49  shr r14d, 0x0F
00007f4f7cbd0f4d  mov eax, [rsp+0x10]
00007f4f7cbd0f51  xor eax, r14d
00007f4f7cbd0f54  imul eax, eax, 0x846CA68B
00007f4f7cbd0f5a  mov [rsp+0x10], eax
00007f4f7cbd0f5e  mov eax, eax
00007f4f7cbd0f60  mov [r15+0x40], rax
00007f4f7cbd0f64  mov eax, [rsp+0x10]
00007f4f7cbd0f68  shr eax, 0x10
00007f4f7cbd0f6b  mov r14d, [rsp+0x10]
00007f4f7cbd0f70  xor r14d, eax
00007f4f7cbd0f73  mov r14d, r14d
00007f4f7cbd0f76  mov [r15], r14
00007f4f7cbd0f79  mov rax, [r15+0xF0]
00007f4f7cbd0f80  mov [r15+0x100], rax
00007f4f7cbd0f87  jmp 0x00007F4F7CBCE5C0
00007f4f7cbd0f8c  int3
00007f4f7cbd0f8d  int3
00007f4f7cbd0f8e  nop
00007f4f7cbd0f90  mov rax, [r15+0xA0]
00007f4f7cbd0f97  mov [rsp+0x10], rax
00007f4f7cbd0f9c  shl rax, 0x02
00007f4f7cbd0fa0  mov r14, [r15+0x98]
00007f4f7cbd0fa7  lea r12, [r14+rax*1]
00007f4f7cbd0fab  mov eax, [r15]
00007f4f7cbd0fae  mov [r13+r12*1], eax
00007f4f7cbd0fb3  mov rax, [rsp+0x10]
00007f4f7cbd0fb8  lea r14, [rax+0x01]
00007f4f7cbd0fbc  mov [r15+0xA0], r14
00007f4f7cbd0fc3  xor eax, eax
00007f4f7cbd0fc5  mov r12d, 0x400
00007f4f7cbd0fcb  cmp r14, r12
00007f4f7cbd0fce  cmc
00007f4f7cbd0fcf  lahf
00007f4f7cbd0fd0  seto al
00007f4f7cbd0fd3  mov [r15+0x108], eax
00007f4f7cbd0fda  mov eax, [r15+0x108]
00007f4f7cbd0fe1  sahf
00007f4f7cbd0fe2  jnz 0x00007F4F7CBD1014
00007f4f7cbd0fe4  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd0fec  jz 0x00007F4F7CBD10E0
00007f4f7cbd0ff2  nop [rax+rax*1], ax
00007f4f7cbd0ffb  nop [rax+rax*1], eax
00007f4f7cbd1003  mov eax, 0x41035C
00007f4f7cbd1008  mov [r15+0x100], rax
00007f4f7cbd100f  jmp 0x00007F4F7C9FE110
00007f4f7cbd1014  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd101c  jz 0x00007F4F7CBD1050
00007f4f7cbd1022  nop [rax+rax*1], ax
00007f4f7cbd102b  nop [rax+rax*1], eax
00007f4f7cbd1033  mov eax, 0x410344
00007f4f7cbd1038  mov [r15+0x100], rax
00007f4f7cbd103f  jmp 0x00007F4F7C9FE110
00007f4f7cbd1044  int3
00007f4f7cbd1045  call 0x00007F4F7CAB4B70
00007f4f7cbd104a  jmp 0x00007F4F7CBD0FB3
00007f4f7cbd104f  int3
00007f4f7cbd1050  mov eax, [r15+0xA0]
00007f4f7cbd1057  lea r14d, [eax+0x11]
00007f4f7cbd105c  mov r14d, r14d
00007f4f7cbd105f  mov [r15], r14
00007f4f7cbd1062  mov qword ptr [r15+0xF0], 0x41034C
00007f4f7cbd106d  mov r14d, [r15+0x320]
00007f4f7cbd1074  mov eax, 0x41034C
00007f4f7cbd1079  mov rcx, 0x7F4F7CBD0F90
00007f4f7cbd1083  mov [r15+r14*8+0x328], rax
00007f4f7cbd108b  mov [r15+r14*8+0x368], rcx
00007f4f7cbd1093  add r14d, 0x01
00007f4f7cbd1097  and r14d, 0x07
00007f4f7cbd109b  mov [r15+0x320], r14d
00007f4f7cbd10a2  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd10aa  jz 0x00007F4F7CBD0F20
00007f4f7cbd10b0  nop [rax+rax*1], ax
00007f4f7cbd10b9  nop [rax+rax*1], eax
00007f4f7cbd10c1  mov eax, 0x410938
00007f4f7cbd10c6  mov [r15+0x100], rax
00007f4f7cbd10cd  jmp 0x00007F4F7C9FE110
00007f4f7cbd10d2  int3
00007f4f7cbd10d3  int3
00007f4f7cbd10d4  nop [rax+rax*1], ax
00007f4f7cbd10dd  nop [rax], eax
00007f4f7cbd10e0  mov qword ptr [r15+0x40], 0x01
00007f4f7cbd10e8  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd10f0  jz 0x00007F4F7CBD1120
00007f4f7cbd10f6  nop [rax+rax*1], ax
00007f4f7cbd10ff  nop [rax+rax*1], eax
00007f4f7cbd1107  mov eax, 0x410378
00007f4f7cbd110c  mov [r15+0x100], rax
00007f4f7cbd1113  jmp 0x00007F4F7C9FE110
00007f4f7cbd1118  int3
00007f4f7cbd1119  int3
00007f4f7cbd111a  nop [rax+rax*1], ax
00007f4f7cbd1120  mov rax, [r15+0x40]
00007f4f7cbd1124  mov [rsp+0x10], rax
00007f4f7cbd1129  shl rax, 0x02
00007f4f7cbd112d  mov r14, [r15+0x98]
00007f4f7cbd1134  lea r12, [r14+rax*1]
00007f4f7cbd1138  mov eax, [r13+r12*1]
00007f4f7cbd113d  mov [rsp+0x20], eax
00007f4f7cbd1141  mov eax, eax
00007f4f7cbd1143  mov [r15+0x48], rax
00007f4f7cbd1147  mov rax, [rsp+0x10]
00007f4f7cbd114c  mov [r15+0x50], rax
00007f4f7cbd1150  mov eax, [r15+0x50]
00007f4f7cbd1154  lea r12d, [eax-0x01]
00007f4f7cbd1159  mov r12d, r12d
00007f4f7cbd115c  mov [r15+0x58], r12
00007f4f7cbd1160  mov rax, [r15+0x58]
00007f4f7cbd1164  mov r12d, eax
00007f4f7cbd1167  mov r12d, r12d
00007f4f7cbd116a  shl r12, 0x02
00007f4f7cbd116e  lea rax, [r14+r12*1]
00007f4f7cbd1172  mov r14d, [r13+rax*1]
00007f4f7cbd1177  mov [rsp+0x10], r14d
00007f4f7cbd117c  mov r14d, r14d
00007f4f7cbd117f  mov [r15+0x60], r14
00007f4f7cbd1183  xor eax, eax
00007f4f7cbd1185  mov r14d, [rsp+0x10]
00007f4f7cbd118a  mov r12d, [rsp+0x20]
00007f4f7cbd118f  cmp r14d, r12d
00007f4f7cbd1192  cmc
00007f4f7cbd1193  lahf
00007f4f7cbd1194  seto al
00007f4f7cbd1197  mov [r15+0x108], eax
00007f4f7cbd119e  mov eax, [r15+0x108]
00007f4f7cbd11a5  sahf
00007f4f7cbd11a6  cmc
00007f4f7cbd11a7  jbe 0x00007F4F7CBD11D9
00007f4f7cbd11a9  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd11b1  jz 0x00007F4F7CBD1220
00007f4f7cbd11b7  nop [rax+rax*1], ax
00007f4f7cbd11c0  nop [rax+rax*1], eax
00007f4f7cbd11c8  mov eax, 0x410390
00007f4f7cbd11cd  mov [r15+0x100], rax
00007f4f7cbd11d4  jmp 0x00007F4F7C9FE110
00007f4f7cbd11d9  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd11e1  jz 0x00007F4F7CBD14C0
00007f4f7cbd11e7  nop [rax+rax*1], ax
00007f4f7cbd11f0  nop [rax+rax*1], eax
00007f4f7cbd11f8  mov eax, 0x410368
00007f4f7cbd11fd  mov [r15+0x100], rax
00007f4f7cbd1204  jmp 0x00007F4F7C9FE110
00007f4f7cbd1209  int3
00007f4f7cbd120a  call 0x00007F4F7CAB4690
00007f4f7cbd120f  jmp 0x00007F4F7CBD113D
00007f4f7cbd1214  call 0x00007F4F7CA0DAE0
00007f4f7cbd1219  jmp 0x00007F4F7CBD1177
00007f4f7cbd121e  int3
00007f4f7cbd121f  nop
00007f4f7cbd1220  mov rax, [r15+0x50]
00007f4f7cbd1224  mov [rsp+0x10], rax
00007f4f7cbd1229  shl rax, 0x02
00007f4f7cbd122d  mov r14, [r15+0x98]
00007f4f7cbd1234  lea r12, [r14+rax*1]
00007f4f7cbd1238  mov eax, [r15+0x60]
00007f4f7cbd123c  mov [r13+r12*1], eax
00007f4f7cbd1241  mov rax, [rsp+0x10]
00007f4f7cbd1246  lea r14, [rax-0x01]
00007f4f7cbd124a  mov [r15+0x50], r14
00007f4f7cbd124e  mov rax, [r15+0x58]
00007f4f7cbd1252  test rax, rax
00007f4f7cbd1255  setz al
00007f4f7cbd1258  movzx rax, al
00007f4f7cbd125c  mov [rsp+0x414], al
00007f4f7cbd1263  cmp byte ptr [rsp+0x414], 0x00
00007f4f7cbd126b  jz 0x00007F4F7CBD129D
00007f4f7cbd126d  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd1275  jz 0x00007F4F7CBD12E0
00007f4f7cbd127b  nop [rax+rax*1], ax
00007f4f7cbd1284  nop [rax+rax*1], eax
00007f4f7cbd128c  mov eax, 0x41039C
00007f4f7cbd1291  mov [r15+0x100], rax
00007f4f7cbd1298  jmp 0x00007F4F7C9FE110
00007f4f7cbd129d  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd12a5  jz 0x00007F4F7CBD13E0
00007f4f7cbd12ab  nop [rax+rax*1], ax
00007f4f7cbd12b4  nop [rax+rax*1], eax
00007f4f7cbd12bc  mov eax, 0x410380
00007f4f7cbd12c1  mov [r15+0x100], rax
00007f4f7cbd12c8  jmp 0x00007F4F7C9FE110
00007f4f7cbd12cd  int3
00007f4f7cbd12ce  call 0x00007F4F7CAB4B70
00007f4f7cbd12d3  jmp 0x00007F4F7CBD1241
00007f4f7cbd12d8  int3
00007f4f7cbd12d9  nop [rax], eax
00007f4f7cbd12e0  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd12e8  jz 0x00007F4F7CBD1320
00007f4f7cbd12ee  nop [rax+rax*1], ax
00007f4f7cbd12f7  nop [rax+rax*1], eax
00007f4f7cbd12ff  mov eax, 0x410364
00007f4f7cbd1304  mov [r15+0x100], rax
00007f4f7cbd130b  jmp 0x00007F4F7C9FE110
00007f4f7cbd1310  int3
00007f4f7cbd1311  int3
00007f4f7cbd1312  nop [rax+rax*1], ax
00007f4f7cbd131b  nop [rax+rax*1], eax
00007f4f7cbd1320  mov qword ptr [r15+0x50], 0x00
00007f4f7cbd1328  mov rax, [r15+0x40]
00007f4f7cbd132c  lea r14, [rax+0x01]
00007f4f7cbd1330  mov [r15+0x40], r14
00007f4f7cbd1334  mov rax, [r15+0x98]
00007f4f7cbd133b  mov r12d, [r15+0x48]
00007f4f7cbd133f  mov [r13+rax*1], r12d
00007f4f7cbd1344  xor eax, eax
00007f4f7cbd1346  mov r12d, 0x400
00007f4f7cbd134c  cmp r14, r12
00007f4f7cbd134f  cmc
00007f4f7cbd1350  lahf
00007f4f7cbd1351  seto al
00007f4f7cbd1354  mov [r15+0x108], eax
00007f4f7cbd135b  mov eax, [r15+0x108]
00007f4f7cbd1362  sahf
00007f4f7cbd1363  jz 0x00007F4F7CBD1395
00007f4f7cbd1365  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd136d  jz 0x00007F4F7CBD1120
00007f4f7cbd1373  nop [rax+rax*1], ax
00007f4f7cbd137c  nop [rax+rax*1], eax
00007f4f7cbd1384  mov eax, 0x410378
00007f4f7cbd1389  mov [r15+0x100], rax
00007f4f7cbd1390  jmp 0x00007F4F7C9FE110
00007f4f7cbd1395  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd139d  jz 0x00007F4F7CBD1580
00007f4f7cbd13a3  nop [rax+rax*1], ax
00007f4f7cbd13ac  nop [rax+rax*1], eax
00007f4f7cbd13b4  mov eax, 0x4103A0
00007f4f7cbd13b9  mov [r15+0x100], rax
00007f4f7cbd13c0  jmp 0x00007F4F7C9FE110
00007f4f7cbd13c5  int3
00007f4f7cbd13c6  call 0x00007F4F7CA0BAE0
00007f4f7cbd13cb  jmp 0x00007F4F7CBD1344
00007f4f7cbd13d0  int3
00007f4f7cbd13d1  nop [rax+rax*1], ax
00007f4f7cbd13da  nop [rax+rax*1], ax
00007f4f7cbd13e0  mov eax, [r15+0x50]
00007f4f7cbd13e4  lea r14d, [eax-0x01]
00007f4f7cbd13e9  mov r14d, r14d
00007f4f7cbd13ec  mov [r15+0x58], r14
00007f4f7cbd13f0  mov rax, [r15+0x58]
00007f4f7cbd13f4  mov r14d, eax
00007f4f7cbd13f7  mov r14d, r14d
00007f4f7cbd13fa  shl r14, 0x02
00007f4f7cbd13fe  mov rax, [r15+0x98]
00007f4f7cbd1405  lea r12, [rax+r14*1]
00007f4f7cbd1409  mov eax, [r13+r12*1]
00007f4f7cbd140e  mov [rsp+0x10], eax
00007f4f7cbd1412  mov eax, eax
00007f4f7cbd1414  mov [r15+0x60], rax
00007f4f7cbd1418  mov eax, [r15+0x48]
00007f4f7cbd141c  mov [rsp+0x20], eax
00007f4f7cbd1420  xor eax, eax
00007f4f7cbd1422  mov r14d, [rsp+0x10]
00007f4f7cbd1427  mov r12d, [rsp+0x20]
00007f4f7cbd142c  cmp r14d, r12d
00007f4f7cbd142f  cmc
00007f4f7cbd1430  lahf
00007f4f7cbd1431  seto al
00007f4f7cbd1434  mov [r15+0x108], eax
00007f4f7cbd143b  mov eax, [r15+0x108]
00007f4f7cbd1442  sahf
00007f4f7cbd1443  cmc
00007f4f7cbd1444  jbe 0x00007F4F7CBD1476
00007f4f7cbd1446  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd144e  jz 0x00007F4F7CBD1220
00007f4f7cbd1454  nop [rax+rax*1], ax
00007f4f7cbd145d  nop [rax+rax*1], eax
00007f4f7cbd1465  mov eax, 0x410390
00007f4f7cbd146a  mov [r15+0x100], rax
00007f4f7cbd1471  jmp 0x00007F4F7C9FE110
00007f4f7cbd1476  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd147e  jz 0x00007F4F7CBD14C0
00007f4f7cbd1484  nop [rax+rax*1], ax
00007f4f7cbd148d  nop [rax+rax*1], eax
00007f4f7cbd1495  mov eax, 0x410368
00007f4f7cbd149a  mov [r15+0x100], rax
00007f4f7cbd14a1  jmp 0x00007F4F7C9FE110
00007f4f7cbd14a6  int3
00007f4f7cbd14a7  call 0x00007F4F7CAB4690
00007f4f7cbd14ac  jmp 0x00007F4F7CBD140E
00007f4f7cbd14b1  int3
00007f4f7cbd14b2  nop [rax+rax*1], ax
00007f4f7cbd14bb  nop [rax+rax*1], eax
00007f4f7cbd14c0  mov rax, [r15+0x40]
00007f4f7cbd14c4  lea r14, [rax+0x01]
00007f4f7cbd14c8  mov [r15+0x40], r14
00007f4f7cbd14cc  mov rax, [r15+0x50]
00007f4f7cbd14d0  mov r12d, eax
00007f4f7cbd14d3  mov r12d, r12d
00007f4f7cbd14d6  shl r12, 0x02
00007f4f7cbd14da  mov rax, [r15+0x98]
00007f4f7cbd14e1  lea r11, [rax+r12*1]
00007f4f7cbd14e5  mov eax, [r15+0x48]
00007f4f7cbd14e9  mov [r13+r11*1], eax
00007f4f7cbd14ee  xor eax, eax
00007f4f7cbd14f0  mov r12d, 0x400
00007f4f7cbd14f6  cmp r14, r12
00007f4f7cbd14f9  cmc
00007f4f7cbd14fa  lahf
00007f4f7cbd14fb  seto al
00007f4f7cbd14fe  mov [r15+0x108], eax
00007f4f7cbd1505  mov eax, [r15+0x108]
00007f4f7cbd150c  sahf
00007f4f7cbd150d  jz 0x00007F4F7CBD153F
00007f4f7cbd150f  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd1517  jz 0x00007F4F7CBD1120
00007f4f7cbd151d  nop [rax+rax*1], ax
00007f4f7cbd1526  nop [rax+rax*1], eax
00007f4f7cbd152e  mov eax, 0x410378
00007f4f7cbd1533  mov [r15+0x100], rax
00007f4f7cbd153a  jmp 0x00007F4F7C9FE110
00007f4f7cbd153f  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd1547  jz 0x00007F4F7CBD1580
00007f4f7cbd154d  nop [rax+rax*1], ax
00007f4f7cbd1556  nop [rax+rax*1], eax
00007f4f7cbd155e  mov eax, 0x4103A0
00007f4f7cbd1563  mov [r15+0x100], rax
00007f4f7cbd156a  jmp 0x00007F4F7C9FE110
00007f4f7cbd156f  int3
00007f4f7cbd1570  call 0x00007F4F7CAA4270
00007f4f7cbd1575  jmp 0x00007F4F7CBD14EE
00007f4f7cbd157a  int3
00007f4f7cbd157b  nop [rax+rax*1], eax
00007f4f7cbd1580  mov qword ptr [r15+0x40], 0x430000
00007f4f7cbd1588  mov eax, 0x430C40
00007f4f7cbd158d  mov r14, [r13+rax*1]
00007f4f7cbd1592  mov rax, [r15+0x98]
00007f4f7cbd1599  mov r12d, [r13+rax*1]
00007f4f7cbd159e  lea r11, [rax+0x04]
00007f4f7cbd15a2  mov eax, [r13+r11*1]
00007f4f7cbd15a7  mov r12d, r12d
00007f4f7cbd15aa  mov [r15+0x68], r12
00007f4f7cbd15ae  mov eax, eax
00007f4f7cbd15b0  mov [r15+0x60], rax
00007f4f7cbd15b4  mov rax, [r15+0x68]
00007f4f7cbd15b8  mov [r15+0x68], rax
00007f4f7cbd15bc  mov qword ptr [r15+0x58], 0x02
00007f4f7cbd15c4  mov [rsp+0x10], rax
00007f4f7cbd15c9  xor eax, eax
00007f4f7cbd15cb  mov r12d, 0x02
00007f4f7cbd15d1  mov r11d, 0x400
00007f4f7cbd15d7  cmp r12, r11
00007f4f7cbd15da  cmc
00007f4f7cbd15db  lahf
00007f4f7cbd15dc  seto al
00007f4f7cbd15df  mov [r15+0x108], eax
00007f4f7cbd15e6  mov rax, [r15+0x60]
00007f4f7cbd15ea  mov r12d, 0x02
00007f4f7cbd15f0  imul rax, r12
00007f4f7cbd15f4  mov [r15+0x50], rax
00007f4f7cbd15f8  mov rax, [rsp+0x10]
00007f4f7cbd15fd  lea r12, [rax+r14*1]
00007f4f7cbd1601  mov [r15+0x48], r12
00007f4f7cbd1605  mov eax, [r15+0x108]
00007f4f7cbd160c  sahf
00007f4f7cbd160d  jnz 0x00007F4F7CBD163F
00007f4f7cbd160f  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd1617  jz 0x00007F4F7CBD17B0
00007f4f7cbd161d  nop [rax+rax*1], ax
00007f4f7cbd1626  nop [rax+rax*1], eax
00007f4f7cbd162e  mov eax, 0x4103D0
00007f4f7cbd1633  mov [r15+0x100], rax
00007f4f7cbd163a  jmp 0x00007F4F7C9FE110
00007f4f7cbd163f  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd1647  jz 0x00007F4F7CBD1690
00007f4f7cbd164d  nop [rax+rax*1], ax
00007f4f7cbd1656  nop [rax+rax*1], eax
00007f4f7cbd165e  mov eax, 0x4103B0
00007f4f7cbd1663  mov [r15+0x100], rax
00007f4f7cbd166a  jmp 0x00007F4F7C9FE110
00007f4f7cbd166f  int3
00007f4f7cbd1670  call 0x00007F4F7CA0DC20
00007f4f7cbd1675  jmp 0x00007F4F7CBD1592
00007f4f7cbd167a  call 0x00007F4F7CA0B5E0
00007f4f7cbd167f  jmp 0x00007F4F7CBD159E
00007f4f7cbd1684  call 0x00007F4F7CAA3D90
00007f4f7cbd1689  jmp 0x00007F4F7CBD15A7
00007f4f7cbd168e  int3
00007f4f7cbd168f  nop
00007f4f7cbd1690  mov rax, [r15+0x98]
00007f4f7cbd1697  mov r14, [r15+0x58]
00007f4f7cbd169b  mov [rsp+0x10], r14
00007f4f7cbd16a0  shl r14, 0x02
00007f4f7cbd16a4  lea r12, [rax+r14*1]
00007f4f7cbd16a8  mov eax, [r13+r12*1]
00007f4f7cbd16ad  lea r14, [r12+0x04]
00007f4f7cbd16b2  mov r12d, [r13+r14*1]
00007f4f7cbd16b7  mov eax, eax
00007f4f7cbd16b9  mov [r15+0x68], rax
00007f4f7cbd16bd  mov r12d, r12d
00007f4f7cbd16c0  mov [r15+0x60], r12
00007f4f7cbd16c4  mov rax, [r15+0x68]
00007f4f7cbd16c8  mov [rsp+0x20], rax
00007f4f7cbd16cd  mov r14, [rsp+0x10]
00007f4f7cbd16d2  imul rax, r14
00007f4f7cbd16d6  mov r12, [rsp+0x20]
00007f4f7cbd16db  lea r11, [r12+rax*1]
00007f4f7cbd16df  mov [r15+0x68], r11
00007f4f7cbd16e3  lea rax, [r14+0x02]
00007f4f7cbd16e7  mov [r15+0x58], rax
00007f4f7cbd16eb  mov [rsp+0x10], rax
00007f4f7cbd16f0  xor eax, eax
00007f4f7cbd16f2  mov r14, [rsp+0x10]
00007f4f7cbd16f7  mov r12d, 0x400
00007f4f7cbd16fd  cmp r14, r12
00007f4f7cbd1700  cmc
00007f4f7cbd1701  lahf
00007f4f7cbd1702  seto al
00007f4f7cbd1705  mov [r15+0x108], eax
00007f4f7cbd170c  mov rax, [r15+0x50]
00007f4f7cbd1710  mov r12, [r15+0x60]
00007f4f7cbd1714  imul r14, r12
00007f4f7cbd1718  lea r12, [rax+r14*1]
00007f4f7cbd171c  mov [r15+0x50], r12
00007f4f7cbd1720  mov rax, [r15+0x48]
00007f4f7cbd1724  lea r14, [r11+rax*1]
00007f4f7cbd1728  mov [r15+0x48], r14
00007f4f7cbd172c  mov eax, [r15+0x108]
00007f4f7cbd1733  sahf
00007f4f7cbd1734  jnz 0x00007F4F7CBD1766
00007f4f7cbd1736  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd173e  jz 0x00007F4F7CBD17B0
00007f4f7cbd1744  nop [rax+rax*1], ax
00007f4f7cbd174d  nop [rax+rax*1], eax
00007f4f7cbd1755  mov eax, 0x4103D0
00007f4f7cbd175a  mov [r15+0x100], rax
00007f4f7cbd1761  jmp 0x00007F4F7C9FE110
00007f4f7cbd1766  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd176e  jz 0x00007F4F7CBD1690
00007f4f7cbd1774  nop [rax+rax*1], ax
00007f4f7cbd177d  nop [rax+rax*1], eax
00007f4f7cbd1785  mov eax, 0x4103B0
00007f4f7cbd178a  mov [r15+0x100], rax
00007f4f7cbd1791  jmp 0x00007F4F7C9FE110
00007f4f7cbd1796  int3
00007f4f7cbd1797  call 0x00007F4F7CAB4690
00007f4f7cbd179c  jmp 0x00007F4F7CBD16AD
00007f4f7cbd17a1  call 0x00007F4F7CAE26A0
00007f4f7cbd17a6  jmp 0x00007F4F7CBD16B7
00007f4f7cbd17ab  int3
00007f4f7cbd17ac  nop [rax], eax
00007f4f7cbd17b0  mov qword ptr [r15+0x98], 0x00
00007f4f7cbd17bb  mov rax, [r15+0x50]
00007f4f7cbd17bf  mov r14, [r15+0x48]
00007f4f7cbd17c3  lea r12, [rax+r14*1]
00007f4f7cbd17c7  mov [r15+0x48], r12
00007f4f7cbd17cb  mov rax, [r15+0x40]
00007f4f7cbd17cf  lea r14, [rax+0xC40]
00007f4f7cbd17d6  mov [r13+r14*1], r12
00007f4f7cbd17db  mov qword ptr [r15], 0x01
00007f4f7cbd17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007f4f7cbd17ed  mov r14d, [r15+0x320]
00007f4f7cbd17f4  mov eax, 0x4103E8
00007f4f7cbd17f9  mov rcx, 0x7F4F7CBD1860
00007f4f7cbd1803  mov [r15+r14*8+0x328], rax
00007f4f7cbd180b  mov [r15+r14*8+0x368], rcx
00007f4f7cbd1813  add r14d, 0x01
00007f4f7cbd1817  and r14d, 0x07
00007f4f7cbd181b  mov [r15+0x320], r14d
00007f4f7cbd1822  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd182a  jz 0x00007F4F7CBD0F20
00007f4f7cbd1830  nop [rax+rax*1], ax
00007f4f7cbd1839  nop [rax+rax*1], eax
00007f4f7cbd1841  mov eax, 0x410938
00007f4f7cbd1846  mov [r15+0x100], rax
00007f4f7cbd184d  jmp 0x00007F4F7C9FE110
00007f4f7cbd1852  int3
00007f4f7cbd1853  call 0x00007F4F7CAE2CE0
00007f4f7cbd1858  jmp 0x00007F4F7CBD17DB
00007f4f7cbd185d  int3
00007f4f7cbd185e  nop
00007f4f7cbd1860  mov eax, [r15+0x98]
00007f4f7cbd1867  lea r14d, [eax+0x01]
00007f4f7cbd186c  mov [rsp+0x10], r14d
00007f4f7cbd1871  mov r14d, r14d
00007f4f7cbd1874  mov [r15+0x98], r14
00007f4f7cbd187b  xor eax, eax
00007f4f7cbd187d  mov r14d, [rsp+0x10]
00007f4f7cbd1882  cmp r14d, 0x10000
00007f4f7cbd1889  cmc
00007f4f7cbd188a  lahf
00007f4f7cbd188b  seto al
00007f4f7cbd188e  mov [r15+0x108], eax
00007f4f7cbd1895  mov eax, [r15+0x108]
00007f4f7cbd189c  sahf
00007f4f7cbd189d  jnz 0x00007F4F7CBD18CF
00007f4f7cbd189f  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd18a7  jz 0x00007F4F7CBD19A0
00007f4f7cbd18ad  nop [rax+rax*1], ax
00007f4f7cbd18b6  nop [rax+rax*1], eax
00007f4f7cbd18be  mov eax, 0x4103F4
00007f4f7cbd18c3  mov [r15+0x100], rax
00007f4f7cbd18ca  jmp 0x00007F4F7C9FE110
00007f4f7cbd18cf  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd18d7  jz 0x00007F4F7CBD1910
00007f4f7cbd18dd  nop [rax+rax*1], ax
00007f4f7cbd18e6  nop [rax+rax*1], eax
00007f4f7cbd18ee  mov eax, 0x4103E0
00007f4f7cbd18f3  mov [r15+0x100], rax
00007f4f7cbd18fa  jmp 0x00007F4F7C9FE110
00007f4f7cbd18ff  int3
00007f4f7cbd1900  int3
00007f4f7cbd1901  nop [rax+rax*1], ax
00007f4f7cbd190a  nop [rax+rax*1], ax
00007f4f7cbd1910  mov eax, [r15]
00007f4f7cbd1913  mov r14d, [r15+0x98]
00007f4f7cbd191a  lea r12d, [eax+r14d*1]
00007f4f7cbd191f  mov r12d, r12d
00007f4f7cbd1922  mov [r15], r12
00007f4f7cbd1925  mov qword ptr [r15+0xF0], 0x4103E8
00007f4f7cbd1930  mov r14d, [r15+0x320]
00007f4f7cbd1937  mov eax, 0x4103E8
00007f4f7cbd193c  mov rcx, 0x7F4F7CBD1860
00007f4f7cbd1946  mov [r15+r14*8+0x328], rax
00007f4f7cbd194e  mov [r15+r14*8+0x368], rcx
00007f4f7cbd1956  add r14d, 0x01
00007f4f7cbd195a  and r14d, 0x07
00007f4f7cbd195e  mov [r15+0x320], r14d
00007f4f7cbd1965  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd196d  jz 0x00007F4F7CBD0F20
00007f4f7cbd1973  nop [rax+rax*1], ax
00007f4f7cbd197c  nop [rax+rax*1], eax
00007f4f7cbd1984  mov eax, 0x410938
00007f4f7cbd1989  mov [r15+0x100], rax
00007f4f7cbd1990  jmp 0x00007F4F7C9FE110
00007f4f7cbd1995  int3
00007f4f7cbd1996  int3
00007f4f7cbd1997  nop [rax+rax*1], ax
00007f4f7cbd19a0  vmovaps xmm1, [0x00007F4F7C7FE010]
00007f4f7cbd19a8  movq xmm1, xmm1
00007f4f7cbd19ac  movaps [r15+0x110], xmm1
00007f4f7cbd19b4  mov eax, 0x420AA0
00007f4f7cbd19b9  mov r14, [r13+rax*1]
00007f4f7cbd19be  movq xmm1, r14
00007f4f7cbd19c3  movaps [r15+0x120], xmm1
00007f4f7cbd19cb  vmovaps xmm1, [0x00007F4F7C7FE020]
00007f4f7cbd19d3  movq xmm1, xmm1
00007f4f7cbd19d7  movaps [r15+0x140], xmm1
00007f4f7cbd19df  vmovaps xmm1, [0x00007F4F7C7FE030]
00007f4f7cbd19e7  vpbroadcastq xmm1, xmm1
00007f4f7cbd19ec  movaps [r15+0x150], xmm1
00007f4f7cbd19f4  mov qword ptr [r15+0x40], 0x02
00007f4f7cbd19fc  vmovaps xmm15, [0x00007F4F7C7FE040]
00007f4f7cbd1a04  movq xmm15, xmm15
00007f4f7cbd1a09  movaps [r15+0x160], xmm15
00007f4f7cbd1a11  vmovaps xmm15, [0x00007F4F7C7FE050]
00007f4f7cbd1a19  vpbroadcastq xmm15, xmm15
00007f4f7cbd1a1e  movaps [r15+0x130], xmm15
00007f4f7cbd1a26  mov rax, [r15+0x40]
00007f4f7cbd1a2a  vmovq xmm14, rax
00007f4f7cbd1a2f  vpbroadcastq xmm14, xmm14
00007f4f7cbd1a34  movaps [r15+0x170], xmm14
00007f4f7cbd1a3c  mov eax, 0x4209D0
00007f4f7cbd1a41  movups xmm13, [r13+rax*1]
00007f4f7cbd1a47  mov qword ptr [r15+0x40], 0x431D90
00007f4f7cbd1a4f  mov eax, [r15]
00007f4f7cbd1a52  mov r14d, 0x430C48
00007f4f7cbd1a58  mov [r13+r14*1], eax
00007f4f7cbd1a5d  mov qword ptr [r15+0x50], 0x431F90
00007f4f7cbd1a65  vpmovqd xmm12, xmm13
00007f4f7cbd1a6b  pxor xmm11, xmm11
00007f4f7cbd1a70  punpcklqdq xmm12, xmm11
00007f4f7cbd1a75  movaps [r15+0x210], xmm12
00007f4f7cbd1a7d  movq xmm12, qword ptr [r15+0x140]
00007f4f7cbd1a86  movq xmm11, qword ptr [r15+0x120]
00007f4f7cbd1a8f  psubd xmm12, xmm11
00007f4f7cbd1a94  movq xmm12, xmm12
00007f4f7cbd1a99  paddq xmm13, xmm14
00007f4f7cbd1a9e  movaps [r15+0x180], xmm13
00007f4f7cbd1aa6  movq xmm14, qword ptr [r15+0x160]
00007f4f7cbd1aaf  paddd xmm11, xmm14
00007f4f7cbd1ab4  movq xmm11, xmm11
00007f4f7cbd1ab9  movq xmm11, xmm11
00007f4f7cbd1abe  movaps [r15+0x120], xmm11
00007f4f7cbd1ac6  pmovzxdq xmm12, xmm12
00007f4f7cbd1acc  psllq xmm12, 0x00
00007f4f7cbd1ad2  movq xmm14, qword ptr [r15+0x210]
00007f4f7cbd1adb  movq xmm13, qword ptr [r15+0x110]
00007f4f7cbd1ae4  paddd xmm14, xmm13
00007f4f7cbd1ae9  movq xmm14, xmm14
00007f4f7cbd1aee  vcvtuqq2pd xmm12, xmm12
00007f4f7cbd1af4  pmovzxdq xmm14, xmm14
00007f4f7cbd1afa  psllq xmm14, 0x00
00007f4f7cbd1b00  vcvtuqq2pd xmm14, xmm14
00007f4f7cbd1b06  movaps xmm13, xmm12
00007f4f7cbd1b0a  mulpd xmm13, xmm1
00007f4f7cbd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007f4f7cbd1b15  ptest xmm11, xmm11
00007f4f7cbd1b1b  jnz 0x00007F4F7CBD1C0F
00007f4f7cbd1b21  movaps [r15+0x220], xmm13
00007f4f7cbd1b29  mov eax, 0x431F90
00007f4f7cbd1b2e  movups [r13+rax*1], xmm13
00007f4f7cbd1b34  movaps xmm1, xmm14
00007f4f7cbd1b38  mulpd xmm1, xmm15
00007f4f7cbd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007f4f7cbd1b42  ptest xmm13, xmm13
00007f4f7cbd1b48  jnz 0x00007F4F7CBD1D5C
00007f4f7cbd1b4e  movaps [r15+0x210], xmm1
00007f4f7cbd1b56  mov eax, 0x431D90
00007f4f7cbd1b5b  movups [r13+rax*1], xmm1
00007f4f7cbd1b61  mov qword ptr [r15+0x48], 0x10
00007f4f7cbd1b69  xor eax, eax
00007f4f7cbd1b6b  mov r14d, 0x10
00007f4f7cbd1b71  mov r12d, 0x200
00007f4f7cbd1b77  cmp r14, r12
00007f4f7cbd1b7a  cmc
00007f4f7cbd1b7b  lahf
00007f4f7cbd1b7c  seto al
00007f4f7cbd1b7f  mov [r15+0x108], eax
00007f4f7cbd1b86  mov eax, [r15+0x108]
00007f4f7cbd1b8d  sahf
00007f4f7cbd1b8e  jnz 0x00007F4F7CBD1BC0
00007f4f7cbd1b90  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd1b98  jz 0x00007F4F7CBD2300
00007f4f7cbd1b9e  nop [rax+rax*1], ax
00007f4f7cbd1ba7  nop [rax+rax*1], eax
00007f4f7cbd1baf  mov eax, 0x410480
00007f4f7cbd1bb4  mov [r15+0x100], rax
00007f4f7cbd1bbb  jmp 0x00007F4F7C9FE110
00007f4f7cbd1bc0  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd1bc8  jz 0x00007F4F7CBD1EB0
00007f4f7cbd1bce  nop [rax+rax*1], ax
00007f4f7cbd1bd7  nop [rax+rax*1], eax
00007f4f7cbd1bdf  mov eax, 0x410440
00007f4f7cbd1be4  mov [r15+0x100], rax
00007f4f7cbd1beb  jmp 0x00007F4F7C9FE110
00007f4f7cbd1bf0  int3
00007f4f7cbd1bf1  call 0x00007F4F7CA0DC20
00007f4f7cbd1bf6  jmp 0x00007F4F7CBD19BE
00007f4f7cbd1bfb  call 0x00007F4F7CA0C260
00007f4f7cbd1c00  jmp 0x00007F4F7CBD1A47
00007f4f7cbd1c05  call 0x00007F4F7CAD5D70
00007f4f7cbd1c0a  jmp 0x00007F4F7CBD1A5D
00007f4f7cbd1c0f  sub rsp, 0x08
00007f4f7cbd1c13  push rax
00007f4f7cbd1c14  push rcx
00007f4f7cbd1c15  push rdx
00007f4f7cbd1c16  push rdi
00007f4f7cbd1c17  push rsi
00007f4f7cbd1c18  push r8
00007f4f7cbd1c1a  push r9
00007f4f7cbd1c1c  push r10
00007f4f7cbd1c1e  push r11
00007f4f7cbd1c20  sub rsp, 0xF0
00007f4f7cbd1c27  vmovaps [rsp], xmm0
00007f4f7cbd1c2c  vmovaps [rsp+0x10], xmm1
00007f4f7cbd1c32  vmovaps [rsp+0x20], xmm2
00007f4f7cbd1c38  vmovaps [rsp+0x30], xmm3
00007f4f7cbd1c3e  vmovaps [rsp+0x40], xmm4
00007f4f7cbd1c44  vmovaps [rsp+0x50], xmm5
00007f4f7cbd1c4a  vmovaps [rsp+0x60], xmm6
00007f4f7cbd1c50  vmovaps [rsp+0x70], xmm7
00007f4f7cbd1c56  vmovaps [rsp+0x80], xmm8
00007f4f7cbd1c5f  vmovaps [rsp+0x90], xmm9
00007f4f7cbd1c68  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd1c71  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd1c7a  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd1c83  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd1c8c  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd1c95  sub rsp, 0x30
00007f4f7cbd1c99  movaps [rsp], xmm13
00007f4f7cbd1c9e  movaps [rsp+0x10], xmm12
00007f4f7cbd1ca4  movaps [rsp+0x20], xmm1
00007f4f7cbd1ca9  lea rdi, [rsp]
00007f4f7cbd1cad  mov esi, 0x00
00007f4f7cbd1cb2  mov rax, 0x643999485530
00007f4f7cbd1cbc  call rax
00007f4f7cbd1cbe  movaps xmm13, [rsp]
00007f4f7cbd1cc3  add rsp, 0x30
00007f4f7cbd1cc7  vmovaps xmm0, [rsp]
00007f4f7cbd1ccc  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd1cd2  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd1cd8  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd1cde  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd1ce4  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd1cea  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd1cf0  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd1cf6  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd1cff  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd1d08  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd1d11  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd1d1a  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd1d23  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd1d2c  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd1d35  add rsp, 0xF0
00007f4f7cbd1d3c  pop r11
00007f4f7cbd1d3e  pop r10
00007f4f7cbd1d40  pop r9
00007f4f7cbd1d42  pop r8
00007f4f7cbd1d44  pop rsi
00007f4f7cbd1d45  pop rdi
00007f4f7cbd1d46  pop rdx
00007f4f7cbd1d47  pop rcx
00007f4f7cbd1d48  pop rax
00007f4f7cbd1d49  add rsp, 0x08
00007f4f7cbd1d4d  jmp 0x00007F4F7CBD1B21
00007f4f7cbd1d52  call 0x00007F4F7CA0C380
00007f4f7cbd1d57  jmp 0x00007F4F7CBD1B34
00007f4f7cbd1d5c  sub rsp, 0x08
00007f4f7cbd1d60  push rax
00007f4f7cbd1d61  push rcx
00007f4f7cbd1d62  push rdx
00007f4f7cbd1d63  push rdi
00007f4f7cbd1d64  push rsi
00007f4f7cbd1d65  push r8
00007f4f7cbd1d67  push r9
00007f4f7cbd1d69  push r10
00007f4f7cbd1d6b  push r11
00007f4f7cbd1d6d  sub rsp, 0xF0
00007f4f7cbd1d74  vmovaps [rsp], xmm0
00007f4f7cbd1d79  vmovaps [rsp+0x10], xmm2
00007f4f7cbd1d7f  vmovaps [rsp+0x20], xmm3
00007f4f7cbd1d85  vmovaps [rsp+0x30], xmm4
00007f4f7cbd1d8b  vmovaps [rsp+0x40], xmm5
00007f4f7cbd1d91  vmovaps [rsp+0x50], xmm6
00007f4f7cbd1d97  vmovaps [rsp+0x60], xmm7
00007f4f7cbd1d9d  vmovaps [rsp+0x70], xmm8
00007f4f7cbd1da3  vmovaps [rsp+0x80], xmm9
00007f4f7cbd1dac  vmovaps [rsp+0x90], xmm10
00007f4f7cbd1db5  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd1dbe  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd1dc7  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd1dd0  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd1dd9  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd1de2  sub rsp, 0x30
00007f4f7cbd1de6  movaps [rsp], xmm1
00007f4f7cbd1dea  movaps [rsp+0x10], xmm14
00007f4f7cbd1df0  movaps [rsp+0x20], xmm15
00007f4f7cbd1df6  lea rdi, [rsp]
00007f4f7cbd1dfa  mov esi, 0x00
00007f4f7cbd1dff  mov rax, 0x643999485530
00007f4f7cbd1e09  call rax
00007f4f7cbd1e0b  movaps xmm1, [rsp]
00007f4f7cbd1e0f  add rsp, 0x30
00007f4f7cbd1e13  vmovaps xmm0, [rsp]
00007f4f7cbd1e18  vmovaps xmm2, [rsp+0x10]
00007f4f7cbd1e1e  vmovaps xmm3, [rsp+0x20]
00007f4f7cbd1e24  vmovaps xmm4, [rsp+0x30]
00007f4f7cbd1e2a  vmovaps xmm5, [rsp+0x40]
00007f4f7cbd1e30  vmovaps xmm6, [rsp+0x50]
00007f4f7cbd1e36  vmovaps xmm7, [rsp+0x60]
00007f4f7cbd1e3c  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd1e42  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd1e4b  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd1e54  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd1e5d  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd1e66  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd1e6f  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd1e78  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd1e81  add rsp, 0xF0
00007f4f7cbd1e88  pop r11
00007f4f7cbd1e8a  pop r10
00007f4f7cbd1e8c  pop r9
00007f4f7cbd1e8e  pop r8
00007f4f7cbd1e90  pop rsi
00007f4f7cbd1e91  pop rdi
00007f4f7cbd1e92  pop rdx
00007f4f7cbd1e93  pop rcx
00007f4f7cbd1e94  pop rax
00007f4f7cbd1e95  add rsp, 0x08
00007f4f7cbd1e99  jmp 0x00007F4F7CBD1B4E
00007f4f7cbd1e9e  call 0x00007F4F7C9FF540
00007f4f7cbd1ea3  jmp 0x00007F4F7CBD1B61
00007f4f7cbd1ea8  int3
00007f4f7cbd1ea9  nop [rax], eax
00007f4f7cbd1eb0  movaps xmm1, [r15+0x180]
00007f4f7cbd1eb8  vpmovqd xmm15, xmm1
00007f4f7cbd1ebe  pxor xmm14, xmm14
00007f4f7cbd1ec3  punpcklqdq xmm15, xmm14
00007f4f7cbd1ec8  movaps [r15+0x210], xmm15
00007f4f7cbd1ed0  movq xmm15, qword ptr [r15+0x140]
00007f4f7cbd1ed9  movq xmm14, qword ptr [r15+0x120]
00007f4f7cbd1ee2  psubd xmm15, xmm14
00007f4f7cbd1ee7  movq xmm15, xmm15
00007f4f7cbd1eec  movaps xmm13, [r15+0x170]
00007f4f7cbd1ef4  paddq xmm1, xmm13
00007f4f7cbd1ef9  movaps [r15+0x180], xmm1
00007f4f7cbd1f01  movq xmm1, qword ptr [r15+0x160]
00007f4f7cbd1f0a  paddd xmm14, xmm1
00007f4f7cbd1f0f  movq xmm14, xmm14
00007f4f7cbd1f14  movq xmm14, xmm14
00007f4f7cbd1f19  movaps [r15+0x120], xmm14
00007f4f7cbd1f21  pmovzxdq xmm15, xmm15
00007f4f7cbd1f27  psllq xmm15, 0x00
00007f4f7cbd1f2d  movq xmm1, qword ptr [r15+0x210]
00007f4f7cbd1f36  movq xmm14, qword ptr [r15+0x110]
00007f4f7cbd1f3f  paddd xmm1, xmm14
00007f4f7cbd1f44  movq xmm1, xmm1
00007f4f7cbd1f48  vcvtuqq2pd xmm15, xmm15
00007f4f7cbd1f4e  pmovzxdq xmm1, xmm1
00007f4f7cbd1f53  psllq xmm1, 0x00
00007f4f7cbd1f58  vcvtuqq2pd xmm1, xmm1
00007f4f7cbd1f5e  movaps xmm14, [r15+0x150]
00007f4f7cbd1f66  movaps xmm13, xmm15
00007f4f7cbd1f6a  mulpd xmm13, xmm14
00007f4f7cbd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd1f75  ptest xmm12, xmm12
00007f4f7cbd1f7b  jnz 0x00007F4F7CBD205E
00007f4f7cbd1f81  movaps [r15+0x220], xmm13
00007f4f7cbd1f89  mov rax, [r15+0x48]
00007f4f7cbd1f8d  mov r14, [r15+0x50]
00007f4f7cbd1f91  lea r12, [r14+rax*1]
00007f4f7cbd1f95  movups [r13+r12*1], xmm13
00007f4f7cbd1f9b  movaps xmm15, [r15+0x130]
00007f4f7cbd1fa3  movaps xmm14, xmm1
00007f4f7cbd1fa7  mulpd xmm14, xmm15
00007f4f7cbd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007f4f7cbd1fb2  ptest xmm13, xmm13
00007f4f7cbd1fb8  jnz 0x00007F4F7CBD21AC
00007f4f7cbd1fbe  movaps [r15+0x210], xmm14
00007f4f7cbd1fc6  mov r14, [r15+0x40]
00007f4f7cbd1fca  lea r12, [r14+rax*1]
00007f4f7cbd1fce  movups [r13+r12*1], xmm14
00007f4f7cbd1fd4  lea r14, [rax+0x10]
00007f4f7cbd1fd8  mov [r15+0x48], r14
00007f4f7cbd1fdc  xor eax, eax
00007f4f7cbd1fde  mov r12d, 0x200
00007f4f7cbd1fe4  cmp r14, r12
00007f4f7cbd1fe7  cmc
00007f4f7cbd1fe8  lahf
00007f4f7cbd1fe9  seto al
00007f4f7cbd1fec  mov [r15+0x108], eax
00007f4f7cbd1ff3  mov eax, [r15+0x108]
00007f4f7cbd1ffa  sahf
00007f4f7cbd1ffb  jnz 0x00007F4F7CBD202D
00007f4f7cbd1ffd  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd2005  jz 0x00007F4F7CBD2300
00007f4f7cbd200b  nop [rax+rax*1], ax
00007f4f7cbd2014  nop [rax+rax*1], eax
00007f4f7cbd201c  mov eax, 0x410480
00007f4f7cbd2021  mov [r15+0x100], rax
00007f4f7cbd2028  jmp 0x00007F4F7C9FE110
00007f4f7cbd202d  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd2035  jz 0x00007F4F7CBD1EB0
00007f4f7cbd203b  nop [rax+rax*1], ax
00007f4f7cbd2044  nop [rax+rax*1], eax
00007f4f7cbd204c  mov eax, 0x410440
00007f4f7cbd2051  mov [r15+0x100], rax
00007f4f7cbd2058  jmp 0x00007F4F7C9FE110
00007f4f7cbd205d  int3
00007f4f7cbd205e  sub rsp, 0x08
00007f4f7cbd2062  push rax
00007f4f7cbd2063  push rcx
00007f4f7cbd2064  push rdx
00007f4f7cbd2065  push rdi
00007f4f7cbd2066  push rsi
00007f4f7cbd2067  push r8
00007f4f7cbd2069  push r9
00007f4f7cbd206b  push r10
00007f4f7cbd206d  push r11
00007f4f7cbd206f  sub rsp, 0xF0
00007f4f7cbd2076  vmovaps [rsp], xmm0
00007f4f7cbd207b  vmovaps [rsp+0x10], xmm1
00007f4f7cbd2081  vmovaps [rsp+0x20], xmm2
00007f4f7cbd2087  vmovaps [rsp+0x30], xmm3
00007f4f7cbd208d  vmovaps [rsp+0x40], xmm4
00007f4f7cbd2093  vmovaps [rsp+0x50], xmm5
00007f4f7cbd2099  vmovaps [rsp+0x60], xmm6
00007f4f7cbd209f  vmovaps [rsp+0x70], xmm7
00007f4f7cbd20a5  vmovaps [rsp+0x80], xmm8
00007f4f7cbd20ae  vmovaps [rsp+0x90], xmm9
00007f4f7cbd20b7  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd20c0  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd20c9  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd20d2  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd20db  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd20e4  sub rsp, 0x30
00007f4f7cbd20e8  movaps [rsp], xmm13
00007f4f7cbd20ed  movaps [rsp+0x10], xmm15
00007f4f7cbd20f3  movaps [rsp+0x20], xmm14
00007f4f7cbd20f9  lea rdi, [rsp]
00007f4f7cbd20fd  mov esi, 0x00
00007f4f7cbd2102  mov rax, 0x643999485530
00007f4f7cbd210c  call rax
00007f4f7cbd210e  movaps xmm13, [rsp]
00007f4f7cbd2113  add rsp, 0x30
00007f4f7cbd2117  vmovaps xmm0, [rsp]
00007f4f7cbd211c  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd2122  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd2128  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd212e  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd2134  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd213a  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd2140  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd2146  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd214f  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd2158  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd2161  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd216a  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd2173  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd217c  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd2185  add rsp, 0xF0
00007f4f7cbd218c  pop r11
00007f4f7cbd218e  pop r10
00007f4f7cbd2190  pop r9
00007f4f7cbd2192  pop r8
00007f4f7cbd2194  pop rsi
00007f4f7cbd2195  pop rdi
00007f4f7cbd2196  pop rdx
00007f4f7cbd2197  pop rcx
00007f4f7cbd2198  pop rax
00007f4f7cbd2199  add rsp, 0x08
00007f4f7cbd219d  jmp 0x00007F4F7CBD1F81
00007f4f7cbd21a2  call 0x00007F4F7CAC2240
00007f4f7cbd21a7  jmp 0x00007F4F7CBD1F9B
00007f4f7cbd21ac  sub rsp, 0x08
00007f4f7cbd21b0  push rax
00007f4f7cbd21b1  push rcx
00007f4f7cbd21b2  push rdx
00007f4f7cbd21b3  push rdi
00007f4f7cbd21b4  push rsi
00007f4f7cbd21b5  push r8
00007f4f7cbd21b7  push r9
00007f4f7cbd21b9  push r10
00007f4f7cbd21bb  push r11
00007f4f7cbd21bd  sub rsp, 0xF0
00007f4f7cbd21c4  vmovaps [rsp], xmm0
00007f4f7cbd21c9  vmovaps [rsp+0x10], xmm1
00007f4f7cbd21cf  vmovaps [rsp+0x20], xmm2
00007f4f7cbd21d5  vmovaps [rsp+0x30], xmm3
00007f4f7cbd21db  vmovaps [rsp+0x40], xmm4
00007f4f7cbd21e1  vmovaps [rsp+0x50], xmm5
00007f4f7cbd21e7  vmovaps [rsp+0x60], xmm6
00007f4f7cbd21ed  vmovaps [rsp+0x70], xmm7
00007f4f7cbd21f3  vmovaps [rsp+0x80], xmm8
00007f4f7cbd21fc  vmovaps [rsp+0x90], xmm9
00007f4f7cbd2205  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd220e  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd2217  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd2220  vmovaps [rsp+0xD0], xmm13
00007f4f7cbd2229  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd2232  sub rsp, 0x30
00007f4f7cbd2236  movaps [rsp], xmm14
00007f4f7cbd223b  movaps [rsp+0x10], xmm1
00007f4f7cbd2240  movaps [rsp+0x20], xmm15
00007f4f7cbd2246  lea rdi, [rsp]
00007f4f7cbd224a  mov esi, 0x00
00007f4f7cbd224f  mov rax, 0x643999485530
00007f4f7cbd2259  call rax
00007f4f7cbd225b  movaps xmm14, [rsp]
00007f4f7cbd2260  add rsp, 0x30
00007f4f7cbd2264  vmovaps xmm0, [rsp]
00007f4f7cbd2269  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd226f  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd2275  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd227b  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd2281  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd2287  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd228d  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd2293  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd229c  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd22a5  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd22ae  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd22b7  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd22c0  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbd22c9  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd22d2  add rsp, 0xF0
00007f4f7cbd22d9  pop r11
00007f4f7cbd22db  pop r10
00007f4f7cbd22dd  pop r9
00007f4f7cbd22df  pop r8
00007f4f7cbd22e1  pop rsi
00007f4f7cbd22e2  pop rdi
00007f4f7cbd22e3  pop rdx
00007f4f7cbd22e4  pop rcx
00007f4f7cbd22e5  pop rax
00007f4f7cbd22e6  add rsp, 0x08
00007f4f7cbd22ea  jmp 0x00007F4F7CBD1FBE
00007f4f7cbd22ef  call 0x00007F4F7CAC34C0
00007f4f7cbd22f4  jmp 0x00007F4F7CBD1FD4
00007f4f7cbd22f9  int3
00007f4f7cbd22fa  nop [rax+rax*1], ax
00007f4f7cbd2300  mov rax, [r15+0x50]
00007f4f7cbd2304  movups xmm1, [r13+rax*1]
00007f4f7cbd230a  lea r14, [rax+0x10]
00007f4f7cbd230e  movups xmm15, [r13+r14*1]
00007f4f7cbd2314  mov qword ptr [r15+0x48], 0x00
00007f4f7cbd231c  lea r14, [rax+0x40]
00007f4f7cbd2320  movups xmm14, [r13+r14*1]
00007f4f7cbd2326  lea r14, [rax+0x50]
00007f4f7cbd232a  movups xmm13, [r13+r14*1]
00007f4f7cbd2330  lea r14, [rax+0x80]
00007f4f7cbd2337  movups xmm12, [r13+r14*1]
00007f4f7cbd233d  lea r14, [rax+0x90]
00007f4f7cbd2344  movups xmm11, [r13+r14*1]
00007f4f7cbd234a  mov r14, [r15+0xF8]
00007f4f7cbd2351  movups [r13+r14*1], xmm1
00007f4f7cbd2357  lea r12, [rax+0x20]
00007f4f7cbd235b  movups xmm1, [r13+r12*1]
00007f4f7cbd2361  lea r12, [rax+0x30]
00007f4f7cbd2365  movups xmm10, [r13+r12*1]
00007f4f7cbd236b  lea r12, [rax+0xC0]
00007f4f7cbd2372  movups xmm9, [r13+r12*1]
00007f4f7cbd2378  lea r12, [rax+0xD0]
00007f4f7cbd237f  movups xmm8, [r13+r12*1]
00007f4f7cbd2385  lea r12, [rax+0x100]
00007f4f7cbd238c  movups xmm7, [r13+r12*1]
00007f4f7cbd2392  lea r12, [rax+0x110]
00007f4f7cbd2399  movups xmm6, [r13+r12*1]
00007f4f7cbd239f  lea r12, [rax+0x140]
00007f4f7cbd23a6  movups xmm5, [r13+r12*1]
00007f4f7cbd23ac  lea r12, [rax+0x150]
00007f4f7cbd23b3  movups xmm4, [r13+r12*1]
00007f4f7cbd23b9  lea r12, [r14+0xB0]
00007f4f7cbd23c0  movups [r13+r12*1], xmm10
00007f4f7cbd23c6  lea r12, [r14+0xC0]
00007f4f7cbd23cd  movups [r13+r12*1], xmm1
00007f4f7cbd23d3  lea r12, [rax+0x180]
00007f4f7cbd23da  movups xmm1, [r13+r12*1]
00007f4f7cbd23e0  lea r12, [rax+0x190]
00007f4f7cbd23e7  movups xmm10, [r13+r12*1]
00007f4f7cbd23ed  lea r12, [rax+0x1C0]
00007f4f7cbd23f4  movups xmm3, [r13+r12*1]
00007f4f7cbd23fa  lea r12, [rax+0x1D0]
00007f4f7cbd2401  movups xmm2, [r13+r12*1]
00007f4f7cbd2407  lea r12, [rax+0x60]
00007f4f7cbd240b  vmovaps [rsp+0x10], xmm1
00007f4f7cbd2411  movups xmm1, [r13+r12*1]
00007f4f7cbd2417  lea r12, [rax+0x70]
00007f4f7cbd241b  vmovaps [rsp+0x20], xmm1
00007f4f7cbd2421  movups xmm1, [r13+r12*1]
00007f4f7cbd2427  lea r12, [r14+0x70]
00007f4f7cbd242b  movups [r13+r12*1], xmm10
00007f4f7cbd2431  lea r12, [r14+0x80]
00007f4f7cbd2438  vmovaps xmm10, [rsp+0x10]
00007f4f7cbd243e  movups [r13+r12*1], xmm10
00007f4f7cbd2444  lea r12, [rax+0xA0]
00007f4f7cbd244b  movups xmm10, [r13+r12*1]
00007f4f7cbd2451  lea r12, [rax+0xB0]
00007f4f7cbd2458  vmovaps [rsp+0x10], xmm1
00007f4f7cbd245e  movups xmm1, [r13+r12*1]
00007f4f7cbd2464  lea r12, [r14+0x90]
00007f4f7cbd246b  movups [r13+r12*1], xmm2
00007f4f7cbd2471  lea r12, [r14+0xA0]
00007f4f7cbd2478  movups [r13+r12*1], xmm3
00007f4f7cbd247e  lea r12, [rax+0xE0]
00007f4f7cbd2485  movups xmm3, [r13+r12*1]
00007f4f7cbd248b  lea r12, [rax+0xF0]
00007f4f7cbd2492  movups xmm2, [r13+r12*1]
00007f4f7cbd2498  lea r12, [rax+0x120]
00007f4f7cbd249f  vmovaps [rsp+0x30], xmm1
00007f4f7cbd24a5  movups xmm1, [r13+r12*1]
00007f4f7cbd24ab  lea r12, [rax+0x130]
00007f4f7cbd24b2  vmovaps [rsp+0x40], xmm1
00007f4f7cbd24b8  movups xmm1, [r13+r12*1]
00007f4f7cbd24be  vmovaps [rsp+0x50], xmm1
00007f4f7cbd24c4  vmovaps xmm1, [rsp+0x40]
00007f4f7cbd24ca  movaps [r15+0x190], xmm1
00007f4f7cbd24d2  lea r12, [rax+0x160]
00007f4f7cbd24d9  vmovaps [rsp+0x40], xmm1
00007f4f7cbd24df  movups xmm1, [r13+r12*1]
00007f4f7cbd24e5  lea r12, [rax+0x170]
00007f4f7cbd24ec  vmovaps [rsp+0x60], xmm1
00007f4f7cbd24f2  movups xmm1, [r13+r12*1]
00007f4f7cbd24f8  lea r12, [rax+0x1A0]
00007f4f7cbd24ff  vmovaps [rsp+0x70], xmm1
00007f4f7cbd2505  movups xmm1, [r13+r12*1]
00007f4f7cbd250b  lea r12, [rax+0x1B0]
00007f4f7cbd2512  vmovaps [rsp+0x80], xmm1
00007f4f7cbd251b  movups xmm1, [r13+r12*1]
00007f4f7cbd2521  lea r12, [rax+0x1E0]
00007f4f7cbd2528  vmovaps [rsp+0x90], xmm1
00007f4f7cbd2531  movups xmm1, [r13+r12*1]
00007f4f7cbd2537  lea r12, [rax+0x1F0]
00007f4f7cbd253e  vmovaps [rsp+0xA0], xmm1
00007f4f7cbd2547  movups xmm1, [r13+r12*1]
00007f4f7cbd254d  mov qword ptr [r15+0x50], 0x432190
00007f4f7cbd2555  lea rax, [r14+0x50]
00007f4f7cbd2559  vmovaps [rsp+0xB0], xmm1
00007f4f7cbd2562  vmovaps xmm1, [rsp+0x60]
00007f4f7cbd2568  movups [r13+rax*1], xmm1
00007f4f7cbd256e  lea rax, [r14+0x60]
00007f4f7cbd2572  movups [r13+rax*1], xmm5
00007f4f7cbd2578  lea rax, [r14+0x40]
00007f4f7cbd257c  vmovaps xmm1, [rsp+0x70]
00007f4f7cbd2582  movups [r13+rax*1], xmm1
00007f4f7cbd2588  lea rax, [r14+0x20]
00007f4f7cbd258c  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbd2595  movups [r13+rax*1], xmm1
00007f4f7cbd259b  lea rax, [r14+0x30]
00007f4f7cbd259f  vmovaps xmm1, [rsp+0x90]
00007f4f7cbd25a8  movups [r13+rax*1], xmm1
00007f4f7cbd25ae  lea rax, [r14+0x10]
00007f4f7cbd25b2  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd25bb  movups [r13+rax*1], xmm1
00007f4f7cbd25c1  mov rax, [r15+0x40]
00007f4f7cbd25c5  vxorps xmm1, xmm1, xmm1
00007f4f7cbd25c9  vpbroadcastq xmm1, xmm1
00007f4f7cbd25ce  vxorps xmm5, xmm5, xmm5
00007f4f7cbd25d2  vpbroadcastq xmm5, xmm5
00007f4f7cbd25d7  lea r12, [rax+0x30]
00007f4f7cbd25db  mov r11, [r13+r12*1]
00007f4f7cbd25e0  lea r12, [rax+0x38]
00007f4f7cbd25e4  mov r10, [r13+r12*1]
00007f4f7cbd25e9  vmovaps [rsp+0x60], xmm1
00007f4f7cbd25ef  movq xmm1, r11
00007f4f7cbd25f4  vmovaps [rsp+0x70], xmm1
00007f4f7cbd25fa  movq xmm1, r10
00007f4f7cbd25ff  vmovaps [rsp+0x90], xmm1
00007f4f7cbd2608  vmovaps xmm1, [rsp+0x70]
00007f4f7cbd260e  movq xmm1, xmm1
00007f4f7cbd2612  vmovaps [rsp+0x70], xmm1
00007f4f7cbd2618  vmovaps xmm1, [rsp+0x90]
00007f4f7cbd2621  movq xmm1, xmm1
00007f4f7cbd2625  vmovaps [rsp+0x90], xmm1
00007f4f7cbd262e  movq xmm1, xmm1
00007f4f7cbd2632  movaps [r15+0x270], xmm1
00007f4f7cbd263a  vmovaps [rsp+0xA0], xmm7
00007f4f7cbd2643  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbd264c  por xmm7, xmm1
00007f4f7cbd2650  lea r12, [rax+0x20]
00007f4f7cbd2654  mov r11, [r13+r12*1]
00007f4f7cbd2659  lea r12, [rax+0x28]
00007f4f7cbd265d  mov r10, [r13+r12*1]
00007f4f7cbd2662  movq xmm1, r11
00007f4f7cbd2667  vmovaps [rsp+0xA0], xmm1
00007f4f7cbd2670  movq xmm1, r10
00007f4f7cbd2675  vmovaps [rsp+0xB0], xmm1
00007f4f7cbd267e  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbd2687  movq xmm1, xmm1
00007f4f7cbd268b  vmovaps [rsp+0xA0], xmm1
00007f4f7cbd2694  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd269d  movq xmm1, xmm1
00007f4f7cbd26a1  vmovaps [rsp+0xB0], xmm2
00007f4f7cbd26aa  vmovaps [rsp+0xC0], xmm1
00007f4f7cbd26b3  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd26bc  por xmm2, xmm1
00007f4f7cbd26c0  vmovaps [rsp+0xB0], xmm3
00007f4f7cbd26c9  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd26d2  por xmm3, xmm1
00007f4f7cbd26d6  vmovaps [rsp+0xB0], xmm4
00007f4f7cbd26df  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd26e8  por xmm4, xmm1
00007f4f7cbd26ec  vmovaps [rsp+0xB0], xmm9
00007f4f7cbd26f5  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd26fe  por xmm9, xmm1
00007f4f7cbd2703  lea r12, [rax+0x10]
00007f4f7cbd2707  mov r11, [r13+r12*1]
00007f4f7cbd270c  lea r12, [rax+0x18]
00007f4f7cbd2710  mov r10, [r13+r12*1]
00007f4f7cbd2715  movq xmm1, r11
00007f4f7cbd271a  vmovaps [rsp+0xB0], xmm1
00007f4f7cbd2723  movq xmm1, r10
00007f4f7cbd2728  vmovaps [rsp+0xD0], xmm1
00007f4f7cbd2731  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd273a  movq xmm1, xmm1
00007f4f7cbd273e  vmovaps [rsp+0xB0], xmm1
00007f4f7cbd2747  vmovaps xmm1, [rsp+0xD0]
00007f4f7cbd2750  movq xmm1, xmm1
00007f4f7cbd2754  vmovaps [rsp+0xD0], xmm1
00007f4f7cbd275d  vmovaps xmm1, [rsp+0x80]
00007f4f7cbd2766  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd276f  vmovaps xmm15, [rsp+0x80]
00007f4f7cbd2778  por xmm1, xmm15
00007f4f7cbd277d  vmovaps xmm15, [rsp+0x10]
00007f4f7cbd2783  vmovaps [rsp+0x80], xmm1
00007f4f7cbd278c  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd2792  por xmm15, xmm1
00007f4f7cbd2797  vmovaps xmm1, [rsp+0x20]
00007f4f7cbd279d  vmovaps [rsp+0x10], xmm15
00007f4f7cbd27a3  vmovaps xmm15, [rsp+0x20]
00007f4f7cbd27a9  por xmm1, xmm15
00007f4f7cbd27ae  vmovaps [rsp+0x20], xmm6
00007f4f7cbd27b4  vmovaps xmm15, [rsp+0x20]
00007f4f7cbd27ba  por xmm6, xmm15
00007f4f7cbd27bf  vmovaps [rsp+0x20], xmm11
00007f4f7cbd27c5  vmovaps xmm15, [rsp+0x20]
00007f4f7cbd27cb  por xmm11, xmm15
00007f4f7cbd27d0  vmovaps [rsp+0x20], xmm13
00007f4f7cbd27d6  vmovaps xmm15, [rsp+0x20]
00007f4f7cbd27dc  por xmm13, xmm15
00007f4f7cbd27e1  vmovaps [rsp+0x20], xmm14
00007f4f7cbd27e7  vmovaps xmm15, [rsp+0x20]
00007f4f7cbd27ed  por xmm14, xmm15
00007f4f7cbd27f2  mov r12, [r13+rax*1]
00007f4f7cbd27f7  vmovq xmm15, r12
00007f4f7cbd27fc  vpbroadcastq xmm15, xmm15
00007f4f7cbd2801  vmovaps [rsp+0x20], xmm1
00007f4f7cbd2807  vxorps xmm1, xmm1, xmm1
00007f4f7cbd280b  vpbroadcastq xmm1, xmm1
00007f4f7cbd2810  vmovaps [rsp+0xF0], xmm1
00007f4f7cbd2819  movups xmm1, [r13+r14*1]
00007f4f7cbd281f  vmovaps [rsp+0x100], xmm1
00007f4f7cbd2828  vxorps xmm1, xmm1, xmm1
00007f4f7cbd282c  vpbroadcastq xmm1, xmm1
00007f4f7cbd2831  lea r12, [rax+0x08]
00007f4f7cbd2835  mov rax, [r13+r12*1]
00007f4f7cbd283a  vmovaps [rsp+0x110], xmm1
00007f4f7cbd2843  movq xmm1, rax
00007f4f7cbd2848  movaps [r15+0x240], xmm1
00007f4f7cbd2850  mov qword ptr [r15+0x60], 0x432190
00007f4f7cbd2858  mov qword ptr [r15+0x58], 0x40
00007f4f7cbd2860  vmovaps xmm1, [rsp+0x60]
00007f4f7cbd2866  vmovaps [rsp+0x60], xmm15
00007f4f7cbd286c  vmovaps xmm15, [rsp+0x100]
00007f4f7cbd2875  vmovaps [rsp+0x100], xmm14
00007f4f7cbd287e  vmovaps xmm14, [rsp+0x60]
00007f4f7cbd2884  vmovaps [rsp+0x60], xmm13
00007f4f7cbd288a  vmovaps [rsp+0x120], xmm12
00007f4f7cbd2893  movaps xmm13, xmm1
00007f4f7cbd2897  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd28a2  vptest xmm12, xmm12
00007f4f7cbd28a7  jnz 0x00007F4F7CBD3482
00007f4f7cbd28ad  vmovaps xmm1, [rsp+0xE0]
00007f4f7cbd28b6  movaps xmm15, xmm5
00007f4f7cbd28ba  vfmadd231pd xmm15, xmm1, xmm14
00007f4f7cbd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007f4f7cbd28c5  vptest xmm12, xmm12
00007f4f7cbd28ca  jnz 0x00007F4F7CBD35DB
00007f4f7cbd28d0  vmovaps xmm12, [rsp+0x50]
00007f4f7cbd28d6  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd28dc  por xmm12, xmm5
00007f4f7cbd28e1  vmovaps xmm5, [rsp+0x30]
00007f4f7cbd28e7  vmovaps [rsp+0x50], xmm1
00007f4f7cbd28ed  vmovaps xmm1, [rsp+0x30]
00007f4f7cbd28f3  por xmm5, xmm1
00007f4f7cbd28f7  vmovaps [rsp+0x30], xmm10
00007f4f7cbd28fd  vmovaps xmm1, [rsp+0x30]
00007f4f7cbd2903  por xmm10, xmm1
00007f4f7cbd2908  vmovaps [rsp+0x30], xmm8
00007f4f7cbd290e  vmovaps xmm1, [rsp+0x30]
00007f4f7cbd2914  por xmm8, xmm1
00007f4f7cbd2919  vmovaps xmm1, [rsp+0x120]
00007f4f7cbd2922  vmovaps [rsp+0x30], xmm15
00007f4f7cbd2928  vmovaps xmm15, [rsp+0x120]
00007f4f7cbd2931  por xmm1, xmm15
00007f4f7cbd2936  vmovaps xmm15, [rsp+0x50]
00007f4f7cbd293c  vmovaps [rsp+0xE0], xmm1
00007f4f7cbd2945  vmovaps xmm1, [rsp+0x50]
00007f4f7cbd294b  por xmm15, xmm1
00007f4f7cbd2950  lea rax, [r14+0xC0]
00007f4f7cbd2957  movups xmm1, [r13+rax*1]
00007f4f7cbd295d  xor eax, eax
00007f4f7cbd295f  mov r12d, 0x40
00007f4f7cbd2965  mov r11d, 0x200
00007f4f7cbd296b  cmp r12, r11
00007f4f7cbd296e  cmc
00007f4f7cbd296f  lahf
00007f4f7cbd2970  seto al
00007f4f7cbd2973  mov [r15+0x108], eax
00007f4f7cbd297a  vmovaps [rsp+0x50], xmm1
00007f4f7cbd2980  vmovaps xmm1, [rsp+0xF0]
00007f4f7cbd2989  vmovaps [rsp+0xF0], xmm15
00007f4f7cbd2992  vmovaps xmm15, [rsp+0x50]
00007f4f7cbd2998  vmovaps [rsp+0x50], xmm13
00007f4f7cbd299e  vmovaps [rsp+0x120], xmm12
00007f4f7cbd29a7  movaps xmm13, xmm1
00007f4f7cbd29ab  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd29b6  vptest xmm12, xmm12
00007f4f7cbd29bb  jnz 0x00007F4F7CBD373D
00007f4f7cbd29c1  lea rax, [r14+0xB0]
00007f4f7cbd29c8  movups xmm1, [r13+rax*1]
00007f4f7cbd29ce  vmovaps xmm15, [rsp+0x110]
00007f4f7cbd29d7  vmovaps [rsp+0x110], xmm13
00007f4f7cbd29e0  movaps xmm12, xmm15
00007f4f7cbd29e4  vfmadd231pd xmm12, xmm1, xmm14
00007f4f7cbd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007f4f7cbd29ef  vptest xmm13, xmm13
00007f4f7cbd29f4  jnz 0x00007F4F7CBD38A0
00007f4f7cbd29fa  vmovaps xmm1, [rsp+0x100]
00007f4f7cbd2a03  vmovaps xmm15, [rsp+0x100]
00007f4f7cbd2a0c  por xmm1, xmm15
00007f4f7cbd2a11  movaps [r15+0x210], xmm1
00007f4f7cbd2a19  vmovaps xmm15, [rsp+0x60]
00007f4f7cbd2a1f  vmovaps xmm14, [rsp+0x60]
00007f4f7cbd2a25  por xmm15, xmm14
00007f4f7cbd2a2a  movaps [r15+0x1C0], xmm15
00007f4f7cbd2a32  vmovaps [rsp+0x60], xmm11
00007f4f7cbd2a38  vmovaps xmm14, [rsp+0x60]
00007f4f7cbd2a3e  por xmm11, xmm14
00007f4f7cbd2a43  movaps [r15+0x280], xmm11
00007f4f7cbd2a4b  vmovaps [rsp+0x60], xmm6
00007f4f7cbd2a51  vmovaps xmm14, [rsp+0x60]
00007f4f7cbd2a57  por xmm6, xmm14
00007f4f7cbd2a5c  movaps [r15+0x2A0], xmm6
00007f4f7cbd2a64  vmovaps xmm14, [rsp+0x20]
00007f4f7cbd2a6a  vmovaps xmm13, [rsp+0x20]
00007f4f7cbd2a70  por xmm14, xmm13
00007f4f7cbd2a75  movaps [r15+0x2E0], xmm14
00007f4f7cbd2a7d  vmovaps xmm13, [rsp+0x10]
00007f4f7cbd2a83  vmovaps [rsp+0x20], xmm1
00007f4f7cbd2a89  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd2a8f  por xmm13, xmm1
00007f4f7cbd2a94  movaps [r15+0x1F0], xmm13
00007f4f7cbd2a9c  vmovaps xmm1, [rsp+0xF0]
00007f4f7cbd2aa5  vmovaps [rsp+0x10], xmm15
00007f4f7cbd2aab  vmovaps xmm15, [rsp+0xF0]
00007f4f7cbd2ab4  por xmm1, xmm15
00007f4f7cbd2ab9  movaps [r15+0x250], xmm1
00007f4f7cbd2ac1  vmovaps xmm1, [rsp+0xE0]
00007f4f7cbd2aca  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd2ad3  por xmm1, xmm15
00007f4f7cbd2ad8  movaps [r15+0x260], xmm1
00007f4f7cbd2ae0  vmovaps [rsp+0x60], xmm8
00007f4f7cbd2ae6  vmovaps xmm15, [rsp+0x60]
00007f4f7cbd2aec  por xmm8, xmm15
00007f4f7cbd2af1  movaps [r15+0x290], xmm8
00007f4f7cbd2af9  vmovaps [rsp+0x60], xmm10
00007f4f7cbd2aff  vmovaps xmm15, [rsp+0x60]
00007f4f7cbd2b05  por xmm10, xmm15
00007f4f7cbd2b0a  movaps [r15+0x2C0], xmm10
00007f4f7cbd2b12  movq xmm15, qword ptr [r15+0x240]
00007f4f7cbd2b1b  vmovaps [rsp+0x60], xmm15
00007f4f7cbd2b21  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd2b27  vmovaps [rsp+0xE0], xmm1
00007f4f7cbd2b30  vmovaps xmm1, [rsp+0x50]
00007f4f7cbd2b36  vmovaps [rsp+0x50], xmm15
00007f4f7cbd2b3c  vmovaps xmm15, [rsp+0x20]
00007f4f7cbd2b42  vmovaps [rsp+0x20], xmm14
00007f4f7cbd2b48  vmovaps xmm14, [rsp+0x50]
00007f4f7cbd2b4e  vmovaps [rsp+0x50], xmm13
00007f4f7cbd2b54  vmovaps [rsp+0xF0], xmm12
00007f4f7cbd2b5d  movaps xmm13, xmm1
00007f4f7cbd2b61  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd2b6c  vptest xmm12, xmm12
00007f4f7cbd2b71  jnz 0x00007F4F7CBD39F9
00007f4f7cbd2b77  vmovaps xmm1, [rsp+0x60]
00007f4f7cbd2b7d  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd2b83  vmovaps xmm15, [rsp+0x110]
00007f4f7cbd2b8c  vmovaps xmm14, [rsp+0x20]
00007f4f7cbd2b92  vmovaps [rsp+0x20], xmm13
00007f4f7cbd2b98  movaps xmm12, xmm15
00007f4f7cbd2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007f4f7cbd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007f4f7cbd2ba7  vptest xmm13, xmm13
00007f4f7cbd2bac  jnz 0x00007F4F7CBD3B52
00007f4f7cbd2bb2  vmovaps xmm1, [rsp+0x60]
00007f4f7cbd2bb8  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd2bbe  vmovaps xmm15, [rsp+0x30]
00007f4f7cbd2bc4  vmovaps xmm14, [rsp+0x10]
00007f4f7cbd2bca  vmovaps [rsp+0x10], xmm12
00007f4f7cbd2bd0  movaps xmm13, xmm15
00007f4f7cbd2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007f4f7cbd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd2bdf  vptest xmm12, xmm12
00007f4f7cbd2be4  jnz 0x00007F4F7CBD3CAB
00007f4f7cbd2bea  vmovaps [rsp+0x30], xmm5
00007f4f7cbd2bf0  vmovaps xmm1, [rsp+0x30]
00007f4f7cbd2bf6  por xmm5, xmm1
00007f4f7cbd2bfa  movaps [r15+0x1D0], xmm5
00007f4f7cbd2c02  vmovaps xmm1, [rsp+0x60]
00007f4f7cbd2c08  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd2c0e  vmovaps xmm15, [rsp+0xF0]
00007f4f7cbd2c17  vmovaps xmm14, [rsp+0x50]
00007f4f7cbd2c1d  vmovaps [rsp+0x30], xmm13
00007f4f7cbd2c23  movaps xmm12, xmm15
00007f4f7cbd2c27  vfmadd231pd xmm12, xmm14, xmm1
00007f4f7cbd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007f4f7cbd2c32  vptest xmm13, xmm13
00007f4f7cbd2c37  jnz 0x00007F4F7CBD3E04
00007f4f7cbd2c3d  vmovaps xmm1, [rsp+0x80]
00007f4f7cbd2c46  vmovaps xmm15, [rsp+0x80]
00007f4f7cbd2c4f  por xmm1, xmm15
00007f4f7cbd2c54  movaps [r15+0x200], xmm1
00007f4f7cbd2c5c  vmovaps xmm15, [rsp+0x120]
00007f4f7cbd2c65  vmovaps xmm14, [rsp+0x120]
00007f4f7cbd2c6e  por xmm15, xmm14
00007f4f7cbd2c73  movaps [r15+0x1E0], xmm15
00007f4f7cbd2c7b  vmovaps [rsp+0x50], xmm4
00007f4f7cbd2c81  vmovaps xmm13, [rsp+0x50]
00007f4f7cbd2c87  por xmm4, xmm13
00007f4f7cbd2c8c  movaps [r15+0x2B0], xmm4
00007f4f7cbd2c94  vmovaps [rsp+0x50], xmm3
00007f4f7cbd2c9a  vmovaps xmm13, [rsp+0x50]
00007f4f7cbd2ca0  por xmm3, xmm13
00007f4f7cbd2ca5  movaps [r15+0x300], xmm3
00007f4f7cbd2cad  vmovaps xmm15, [rsp+0xB0]
00007f4f7cbd2cb6  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd2cbc  vmovaps xmm3, [rsp+0x20]
00007f4f7cbd2cc2  vmovaps [rsp+0x20], xmm1
00007f4f7cbd2cc8  vmovaps xmm1, [rsp+0xE0]
00007f4f7cbd2cd1  vmovaps [rsp+0x50], xmm14
00007f4f7cbd2cd7  vmovaps [rsp+0x60], xmm13
00007f4f7cbd2cdd  movaps xmm14, xmm3
00007f4f7cbd2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007f4f7cbd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007f4f7cbd2cec  vptest xmm13, xmm13
00007f4f7cbd2cf1  jnz 0x00007F4F7CBD3F5D
00007f4f7cbd2cf7  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd2d00  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd2d06  vmovaps xmm15, [rsp+0x10]
00007f4f7cbd2d0c  movaps xmm13, xmm15
00007f4f7cbd2d10  vfmadd231pd xmm13, xmm10, xmm1
00007f4f7cbd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007f4f7cbd2d1b  vptest xmm3, xmm3
00007f4f7cbd2d20  jnz 0x00007F4F7CBD40B5
00007f4f7cbd2d26  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd2d2f  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd2d35  vmovaps xmm15, [rsp+0x30]
00007f4f7cbd2d3b  movaps xmm10, xmm15
00007f4f7cbd2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007f4f7cbd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007f4f7cbd2d4a  vptest xmm3, xmm3
00007f4f7cbd2d4f  jnz 0x00007F4F7CBD420E
00007f4f7cbd2d55  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd2d5e  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd2d64  movaps xmm15, xmm12
00007f4f7cbd2d68  vfmadd231pd xmm15, xmm5, xmm1
00007f4f7cbd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007f4f7cbd2d73  vptest xmm11, xmm11
00007f4f7cbd2d78  jnz 0x00007F4F7CBD4367
00007f4f7cbd2d7e  vmovaps [rsp+0x10], xmm9
00007f4f7cbd2d84  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd2d8a  por xmm9, xmm1
00007f4f7cbd2d8f  movaps [r15+0x180], xmm9
00007f4f7cbd2d97  vmovaps [rsp+0x10], xmm2
00007f4f7cbd2d9d  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd2da3  por xmm2, xmm1
00007f4f7cbd2da7  movaps [r15+0x2D0], xmm2
00007f4f7cbd2daf  vmovaps xmm12, [rsp+0xD0]
00007f4f7cbd2db8  vpermilpd xmm12, xmm12, 0x00
00007f4f7cbd2dbe  vmovaps xmm11, [rsp+0x60]
00007f4f7cbd2dc4  movaps xmm5, xmm13
00007f4f7cbd2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007f4f7cbd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007f4f7cbd2dd2  vptest xmm3, xmm3
00007f4f7cbd2dd7  jnz 0x00007F4F7CBD44BF
00007f4f7cbd2ddd  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbd2de6  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbd2dec  movaps xmm12, xmm14
00007f4f7cbd2df0  vfmadd231pd xmm12, xmm9, xmm13
00007f4f7cbd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007f4f7cbd2dfb  vptest xmm11, xmm11
00007f4f7cbd2e00  jnz 0x00007F4F7CBD4617
00007f4f7cbd2e06  lea rax, [r14+0x80]
00007f4f7cbd2e0d  movups xmm14, [r13+rax*1]
00007f4f7cbd2e13  movaps [r15+0x2F0], xmm14
00007f4f7cbd2e1b  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbd2e24  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbd2e2a  movaps xmm11, xmm10
00007f4f7cbd2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007f4f7cbd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007f4f7cbd2e39  vptest xmm9, xmm9
00007f4f7cbd2e3e  jnz 0x00007F4F7CBD477B
00007f4f7cbd2e44  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbd2e4d  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbd2e53  movaps xmm10, xmm15
00007f4f7cbd2e57  vfmadd231pd xmm10, xmm1, xmm13
00007f4f7cbd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007f4f7cbd2e62  vptest xmm9, xmm9
00007f4f7cbd2e67  jnz 0x00007F4F7CBD48D5
00007f4f7cbd2e6d  vmovaps [rsp+0x10], xmm7
00007f4f7cbd2e73  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd2e79  por xmm7, xmm1
00007f4f7cbd2e7d  movaps [r15+0x160], xmm7
00007f4f7cbd2e85  lea rax, [r14+0x40]
00007f4f7cbd2e89  movups xmm1, [r13+rax*1]
00007f4f7cbd2e8f  lea rax, [r14+0x50]
00007f4f7cbd2e93  movups xmm15, [r13+rax*1]
00007f4f7cbd2e99  movaps [r15+0x1B0], xmm1
00007f4f7cbd2ea1  movaps [r15+0x1A0], xmm15
00007f4f7cbd2ea9  vmovaps xmm13, [rsp+0xA0]
00007f4f7cbd2eb2  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbd2eb8  vmovaps xmm9, [rsp+0x40]
00007f4f7cbd2ebe  movaps xmm8, xmm5
00007f4f7cbd2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007f4f7cbd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007f4f7cbd2ecd  vptest xmm3, xmm3
00007f4f7cbd2ed2  jnz 0x00007F4F7CBD4A42
00007f4f7cbd2ed8  vmovaps xmm13, [rsp+0xA0]
00007f4f7cbd2ee1  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbd2ee7  movaps xmm9, xmm12
00007f4f7cbd2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007f4f7cbd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007f4f7cbd2ef6  vptest xmm5, xmm5
00007f4f7cbd2efb  jnz 0x00007F4F7CBD4B9B
00007f4f7cbd2f01  vmovaps xmm13, [rsp+0xA0]
00007f4f7cbd2f0a  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbd2f10  movaps xmm12, xmm11
00007f4f7cbd2f14  vfmadd231pd xmm12, xmm6, xmm13
00007f4f7cbd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007f4f7cbd2f1f  vptest xmm7, xmm7
00007f4f7cbd2f24  jnz 0x00007F4F7CBD4CF4
00007f4f7cbd2f2a  vmovaps xmm13, [rsp+0xA0]
00007f4f7cbd2f33  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbd2f39  vmovaps xmm11, [rsp+0x50]
00007f4f7cbd2f3f  movaps xmm7, xmm10
00007f4f7cbd2f43  vfmadd231pd xmm7, xmm11, xmm13
00007f4f7cbd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4f7cbd2f4d  vptest xmm6, xmm6
00007f4f7cbd2f52  jnz 0x00007F4F7CBD4E4D
00007f4f7cbd2f58  lea rax, [r14+0x60]
00007f4f7cbd2f5c  movups xmm13, [r13+rax*1]
00007f4f7cbd2f62  lea rax, [r14+0x70]
00007f4f7cbd2f66  movups xmm11, [r13+rax*1]
00007f4f7cbd2f6c  movaps [r15+0x150], xmm13
00007f4f7cbd2f74  movaps [r15+0x120], xmm11
00007f4f7cbd2f7c  vmovaps xmm10, [rsp+0xC0]
00007f4f7cbd2f85  vpermilpd xmm10, xmm10, 0x00
00007f4f7cbd2f8b  movaps xmm6, xmm8
00007f4f7cbd2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007f4f7cbd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007f4f7cbd2f99  vptest xmm5, xmm5
00007f4f7cbd2f9e  jnz 0x00007F4F7CBD4FB9
00007f4f7cbd2fa4  vmovaps xmm15, [rsp+0xC0]
00007f4f7cbd2fad  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd2fb3  movaps xmm10, xmm9
00007f4f7cbd2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007f4f7cbd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007f4f7cbd2fc2  vptest xmm8, xmm8
00007f4f7cbd2fc7  jnz 0x00007F4F7CBD5111
00007f4f7cbd2fcd  vmovaps xmm15, [rsp+0xC0]
00007f4f7cbd2fd6  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd2fdc  movaps xmm13, xmm12
00007f4f7cbd2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007f4f7cbd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007f4f7cbd2feb  vptest xmm9, xmm9
00007f4f7cbd2ff0  jnz 0x00007F4F7CBD526B
00007f4f7cbd2ff6  vmovaps xmm15, [rsp+0xC0]
00007f4f7cbd2fff  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd3005  movaps xmm12, xmm7
00007f4f7cbd3009  vfmadd231pd xmm12, xmm1, xmm15
00007f4f7cbd300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007f4f7cbd3014  vptest xmm9, xmm9
00007f4f7cbd3019  jnz 0x00007F4F7CBD53C4
00007f4f7cbd301f  lea rax, [r14+0x20]
00007f4f7cbd3023  movups xmm1, [r13+rax*1]
00007f4f7cbd3029  lea rax, [r14+0x30]
00007f4f7cbd302d  movups xmm15, [r13+rax*1]
00007f4f7cbd3033  vmovaps xmm9, [rsp+0x70]
00007f4f7cbd3039  vpermilpd xmm9, xmm9, 0x00
00007f4f7cbd303f  vmovaps xmm8, [rsp+0x20]
00007f4f7cbd3045  movaps xmm7, xmm6
00007f4f7cbd3048  vfmadd231pd xmm7, xmm8, xmm9
00007f4f7cbd304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007f4f7cbd3052  vptest xmm5, xmm5
00007f4f7cbd3057  jnz 0x00007F4F7CBD5530
00007f4f7cbd305d  vmovaps xmm9, [rsp+0x70]
00007f4f7cbd3063  vpermilpd xmm9, xmm9, 0x00
00007f4f7cbd3069  movaps xmm8, xmm10
00007f4f7cbd306d  vfmadd231pd xmm8, xmm14, xmm9
00007f4f7cbd3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007f4f7cbd3078  vptest xmm6, xmm6
00007f4f7cbd307d  jnz 0x00007F4F7CBD5687
00007f4f7cbd3083  vmovaps xmm14, [rsp+0x70]
00007f4f7cbd3089  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbd308f  movaps xmm10, xmm13
00007f4f7cbd3093  vfmadd231pd xmm10, xmm11, xmm14
00007f4f7cbd3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007f4f7cbd309e  vptest xmm9, xmm9
00007f4f7cbd30a3  jnz 0x00007F4F7CBD57E1
00007f4f7cbd30a9  vmovaps xmm14, [rsp+0x70]
00007f4f7cbd30af  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbd30b5  movaps xmm13, xmm12
00007f4f7cbd30b9  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007f4f7cbd30c4  vptest xmm11, xmm11
00007f4f7cbd30c9  jnz 0x00007F4F7CBD593B
00007f4f7cbd30cf  lea rax, [r14+0x90]
00007f4f7cbd30d6  movups xmm15, [r13+rax*1]
00007f4f7cbd30dc  lea rax, [r14+0xA0]
00007f4f7cbd30e3  movups xmm14, [r13+rax*1]
00007f4f7cbd30e9  movaps [r15+0x140], xmm15
00007f4f7cbd30f1  movaps [r15+0x130], xmm14
00007f4f7cbd30f9  vmovaps xmm12, [rsp+0x90]
00007f4f7cbd3102  vpermilpd xmm12, xmm12, 0x00
00007f4f7cbd3108  movaps xmm11, xmm7
00007f4f7cbd310c  vfmadd231pd xmm11, xmm1, xmm12
00007f4f7cbd3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007f4f7cbd3117  vptest xmm9, xmm9
00007f4f7cbd311c  jnz 0x00007F4F7CBD5AA9
00007f4f7cbd3122  movaps [r15+0x220], xmm11
00007f4f7cbd312a  lea rax, [r14+0x10]
00007f4f7cbd312e  movups xmm1, [r13+rax*1]
00007f4f7cbd3134  movaps [r15+0x240], xmm1
00007f4f7cbd313c  vmovaps xmm12, [rsp+0x90]
00007f4f7cbd3145  vpermilpd xmm12, xmm12, 0x00
00007f4f7cbd314b  movaps xmm9, xmm8
00007f4f7cbd314f  vfmadd231pd xmm9, xmm14, xmm12
00007f4f7cbd3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007f4f7cbd315a  vptest xmm7, xmm7
00007f4f7cbd315f  jnz 0x00007F4F7CBD5C0B
00007f4f7cbd3165  movaps [r15+0x110], xmm9
00007f4f7cbd316d  vmovaps xmm14, [rsp+0x90]
00007f4f7cbd3176  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbd317c  movaps xmm12, xmm10
00007f4f7cbd3180  vfmadd231pd xmm12, xmm15, xmm14
00007f4f7cbd3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007f4f7cbd318b  vptest xmm8, xmm8
00007f4f7cbd3190  jnz 0x00007F4F7CBD5D65
00007f4f7cbd3196  movaps [r15+0x170], xmm12
00007f4f7cbd319e  vmovaps xmm15, [rsp+0x90]
00007f4f7cbd31a7  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd31ad  movaps xmm14, xmm13
00007f4f7cbd31b1  vfmadd231pd xmm14, xmm1, xmm15
00007f4f7cbd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007f4f7cbd31bc  vptest xmm10, xmm10
00007f4f7cbd31c1  jnz 0x00007F4F7CBD5EBF
00007f4f7cbd31c7  movaps [r15+0x230], xmm14
00007f4f7cbd31cf  mov eax, 0x432190
00007f4f7cbd31d4  movups [r13+rax*1], xmm9
00007f4f7cbd31da  mov eax, 0x4321A0
00007f4f7cbd31df  movups [r13+rax*1], xmm12
00007f4f7cbd31e5  mov eax, 0x4321B0
00007f4f7cbd31ea  movups [r13+rax*1], xmm11
00007f4f7cbd31f0  mov eax, 0x4321C0
00007f4f7cbd31f5  movups [r13+rax*1], xmm14
00007f4f7cbd31fb  mov eax, [r15+0x108]
00007f4f7cbd3202  sahf
00007f4f7cbd3203  jnz 0x00007F4F7CBD3235
00007f4f7cbd3205  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd320d  jz 0x00007F4F7CBD9950
00007f4f7cbd3213  nop [rax+rax*1], ax
00007f4f7cbd321c  nop [rax+rax*1], eax
00007f4f7cbd3224  mov eax, 0x410664
00007f4f7cbd3229  mov [r15+0x100], rax
00007f4f7cbd3230  jmp 0x00007F4F7C9FE110
00007f4f7cbd3235  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd323d  jz 0x00007F4F7CBD6050
00007f4f7cbd3243  nop [rax+rax*1], ax
00007f4f7cbd324c  nop [rax+rax*1], eax
00007f4f7cbd3254  mov eax, 0x4104F0
00007f4f7cbd3259  mov [r15+0x100], rax
00007f4f7cbd3260  jmp 0x00007F4F7C9FE110
00007f4f7cbd3265  int3
00007f4f7cbd3266  call 0x00007F4F7C9FF430
00007f4f7cbd326b  jmp 0x00007F4F7CBD230A
00007f4f7cbd3270  call 0x00007F4F7CAE5820
00007f4f7cbd3275  jmp 0x00007F4F7CBD2314
00007f4f7cbd327a  call 0x00007F4F7CAE45A0
00007f4f7cbd327f  jmp 0x00007F4F7CBD2326
00007f4f7cbd3284  call 0x00007F4F7CAE3320
00007f4f7cbd3289  jmp 0x00007F4F7CBD2330
00007f4f7cbd328e  call 0x00007F4F7CAE20A0
00007f4f7cbd3293  jmp 0x00007F4F7CBD233D
00007f4f7cbd3298  call 0x00007F4F7CAE0E30
00007f4f7cbd329d  jmp 0x00007F4F7CBD234A
00007f4f7cbd32a2  call 0x00007F4F7CAD6600
00007f4f7cbd32a7  jmp 0x00007F4F7CBD2357
00007f4f7cbd32ac  call 0x00007F4F7CAB52F0
00007f4f7cbd32b1  jmp 0x00007F4F7CBD2361
00007f4f7cbd32b6  call 0x00007F4F7CABE9C0
00007f4f7cbd32bb  jmp 0x00007F4F7CBD236B
00007f4f7cbd32c0  call 0x00007F4F7CABD750
00007f4f7cbd32c5  jmp 0x00007F4F7CBD2378
00007f4f7cbd32ca  call 0x00007F4F7CABC4E0
00007f4f7cbd32cf  jmp 0x00007F4F7CBD2385
00007f4f7cbd32d4  call 0x00007F4F7CABB270
00007f4f7cbd32d9  jmp 0x00007F4F7CBD2392
00007f4f7cbd32de  call 0x00007F4F7CABA000
00007f4f7cbd32e3  jmp 0x00007F4F7CBD239F
00007f4f7cbd32e8  call 0x00007F4F7CAB8D90
00007f4f7cbd32ed  jmp 0x00007F4F7CBD23AC
00007f4f7cbd32f2  call 0x00007F4F7CAB8A20
00007f4f7cbd32f7  jmp 0x00007F4F7CBD23B9
00007f4f7cbd32fc  call 0x00007F4F7CABEAE0
00007f4f7cbd3301  jmp 0x00007F4F7CBD23C6
00007f4f7cbd3306  call 0x00007F4F7CAB5400
00007f4f7cbd330b  jmp 0x00007F4F7CBD23D3
00007f4f7cbd3310  call 0x00007F4F7CAB52F0
00007f4f7cbd3315  jmp 0x00007F4F7CBD23E0
00007f4f7cbd331a  call 0x00007F4F7CABE9C0
00007f4f7cbd331f  jmp 0x00007F4F7CBD23ED
00007f4f7cbd3324  call 0x00007F4F7CAB77B0
00007f4f7cbd3329  jmp 0x00007F4F7CBD23FA
00007f4f7cbd332e  call 0x00007F4F7CAB6550
00007f4f7cbd3333  jmp 0x00007F4F7CBD2407
00007f4f7cbd3338  call 0x00007F4F7CAB52F0
00007f4f7cbd333d  jmp 0x00007F4F7CBD2417
00007f4f7cbd3342  call 0x00007F4F7CAB52F0
00007f4f7cbd3347  jmp 0x00007F4F7CBD2427
00007f4f7cbd334c  call 0x00007F4F7CABEAE0
00007f4f7cbd3351  jmp 0x00007F4F7CBD2431
00007f4f7cbd3356  call 0x00007F4F7CABEAE0
00007f4f7cbd335b  jmp 0x00007F4F7CBD2444
00007f4f7cbd3360  call 0x00007F4F7CABE9C0
00007f4f7cbd3365  jmp 0x00007F4F7CBD2451
00007f4f7cbd336a  call 0x00007F4F7CAB52F0
00007f4f7cbd336f  jmp 0x00007F4F7CBD2464
00007f4f7cbd3374  call 0x00007F4F7CAB6660
00007f4f7cbd3379  jmp 0x00007F4F7CBD2471
00007f4f7cbd337e  call 0x00007F4F7CAB78C0
00007f4f7cbd3383  jmp 0x00007F4F7CBD247E
00007f4f7cbd3388  call 0x00007F4F7CAB77B0
00007f4f7cbd338d  jmp 0x00007F4F7CBD248B
00007f4f7cbd3392  call 0x00007F4F7CAB6550
00007f4f7cbd3397  jmp 0x00007F4F7CBD2498
00007f4f7cbd339c  call 0x00007F4F7CAB52F0
00007f4f7cbd33a1  jmp 0x00007F4F7CBD24AB
00007f4f7cbd33a6  call 0x00007F4F7CAB52F0
00007f4f7cbd33ab  jmp 0x00007F4F7CBD24BE
00007f4f7cbd33b0  call 0x00007F4F7CAB52F0
00007f4f7cbd33b5  jmp 0x00007F4F7CBD24E5
00007f4f7cbd33ba  call 0x00007F4F7CAB52F0
00007f4f7cbd33bf  jmp 0x00007F4F7CBD24F8
00007f4f7cbd33c4  call 0x00007F4F7CAB52F0
00007f4f7cbd33c9  jmp 0x00007F4F7CBD250B
00007f4f7cbd33ce  call 0x00007F4F7CAB52F0
00007f4f7cbd33d3  jmp 0x00007F4F7CBD2521
00007f4f7cbd33d8  call 0x00007F4F7CAB52F0
00007f4f7cbd33dd  jmp 0x00007F4F7CBD2537
00007f4f7cbd33e2  call 0x00007F4F7CAB52F0
00007f4f7cbd33e7  jmp 0x00007F4F7CBD254D
00007f4f7cbd33ec  call 0x00007F4F7C9FF540
00007f4f7cbd33f1  jmp 0x00007F4F7CBD256E
00007f4f7cbd33f6  call 0x00007F4F7CA02FE0
00007f4f7cbd33fb  jmp 0x00007F4F7CBD2578
00007f4f7cbd3400  call 0x00007F4F7C9FF540
00007f4f7cbd3405  jmp 0x00007F4F7CBD2588
00007f4f7cbd340a  call 0x00007F4F7C9FF540
00007f4f7cbd340f  jmp 0x00007F4F7CBD259B
00007f4f7cbd3414  call 0x00007F4F7C9FF540
00007f4f7cbd3419  jmp 0x00007F4F7CBD25AE
00007f4f7cbd341e  call 0x00007F4F7C9FF540
00007f4f7cbd3423  jmp 0x00007F4F7CBD25C1
00007f4f7cbd3428  call 0x00007F4F7CAC0370
00007f4f7cbd342d  jmp 0x00007F4F7CBD25E0
00007f4f7cbd3432  call 0x00007F4F7CABF100
00007f4f7cbd3437  jmp 0x00007F4F7CBD25E9
00007f4f7cbd343c  call 0x00007F4F7CAC0370
00007f4f7cbd3441  jmp 0x00007F4F7CBD2659
00007f4f7cbd3446  call 0x00007F4F7CABF100
00007f4f7cbd344b  jmp 0x00007F4F7CBD2662
00007f4f7cbd3450  call 0x00007F4F7CAC0370
00007f4f7cbd3455  jmp 0x00007F4F7CBD270C
00007f4f7cbd345a  call 0x00007F4F7CABF100
00007f4f7cbd345f  jmp 0x00007F4F7CBD2715
00007f4f7cbd3464  call 0x00007F4F7CA0B720
00007f4f7cbd3469  jmp 0x00007F4F7CBD27F7
00007f4f7cbd346e  call 0x00007F4F7CAD64F0
00007f4f7cbd3473  jmp 0x00007F4F7CBD281F
00007f4f7cbd3478  call 0x00007F4F7CAB47C0
00007f4f7cbd347d  jmp 0x00007F4F7CBD283A
00007f4f7cbd3482  sub rsp, 0x08
00007f4f7cbd3486  push rax
00007f4f7cbd3487  push rcx
00007f4f7cbd3488  push rdx
00007f4f7cbd3489  push rdi
00007f4f7cbd348a  push rsi
00007f4f7cbd348b  push r8
00007f4f7cbd348d  push r9
00007f4f7cbd348f  push r10
00007f4f7cbd3491  push r11
00007f4f7cbd3493  sub rsp, 0xF0
00007f4f7cbd349a  vmovaps [rsp], xmm0
00007f4f7cbd349f  vmovaps [rsp+0x10], xmm1
00007f4f7cbd34a5  vmovaps [rsp+0x20], xmm2
00007f4f7cbd34ab  vmovaps [rsp+0x30], xmm3
00007f4f7cbd34b1  vmovaps [rsp+0x40], xmm4
00007f4f7cbd34b7  vmovaps [rsp+0x50], xmm5
00007f4f7cbd34bd  vmovaps [rsp+0x60], xmm6
00007f4f7cbd34c3  vmovaps [rsp+0x70], xmm7
00007f4f7cbd34c9  vmovaps [rsp+0x80], xmm8
00007f4f7cbd34d2  vmovaps [rsp+0x90], xmm9
00007f4f7cbd34db  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd34e4  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd34ed  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd34f6  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd34ff  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd3508  sub rsp, 0x40
00007f4f7cbd350c  lea rdi, [rsp]
00007f4f7cbd3510  lea rsi, [rsp+0x10]
00007f4f7cbd3515  lea rdx, [rsp+0x20]
00007f4f7cbd351a  lea rcx, [rsp+0x30]
00007f4f7cbd351f  mov r8d, 0x00
00007f4f7cbd3525  lea r9, [r15+0x3A8]
00007f4f7cbd352c  movaps [rdi], xmm13
00007f4f7cbd3530  movaps [rsi], xmm1
00007f4f7cbd3533  movaps [rdx], xmm15
00007f4f7cbd3537  movaps [rcx], xmm14
00007f4f7cbd353b  mov rax, 0x643999485A50
00007f4f7cbd3545  call rax
00007f4f7cbd3547  movaps xmm13, [rsp]
00007f4f7cbd354c  add rsp, 0x40
00007f4f7cbd3550  vmovaps xmm0, [rsp]
00007f4f7cbd3555  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd355b  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd3561  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd3567  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd356d  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd3573  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd3579  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd357f  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd3588  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd3591  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd359a  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd35a3  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd35ac  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd35b5  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd35be  add rsp, 0xF0
00007f4f7cbd35c5  pop r11
00007f4f7cbd35c7  pop r10
00007f4f7cbd35c9  pop r9
00007f4f7cbd35cb  pop r8
00007f4f7cbd35cd  pop rsi
00007f4f7cbd35ce  pop rdi
00007f4f7cbd35cf  pop rdx
00007f4f7cbd35d0  pop rcx
00007f4f7cbd35d1  pop rax
00007f4f7cbd35d2  add rsp, 0x08
00007f4f7cbd35d6  jmp 0x00007F4F7CBD28AD
00007f4f7cbd35db  sub rsp, 0x08
00007f4f7cbd35df  push rax
00007f4f7cbd35e0  push rcx
00007f4f7cbd35e1  push rdx
00007f4f7cbd35e2  push rdi
00007f4f7cbd35e3  push rsi
00007f4f7cbd35e4  push r8
00007f4f7cbd35e6  push r9
00007f4f7cbd35e8  push r10
00007f4f7cbd35ea  push r11
00007f4f7cbd35ec  sub rsp, 0xF0
00007f4f7cbd35f3  vmovaps [rsp], xmm0
00007f4f7cbd35f8  vmovaps [rsp+0x10], xmm1
00007f4f7cbd35fe  vmovaps [rsp+0x20], xmm2
00007f4f7cbd3604  vmovaps [rsp+0x30], xmm3
00007f4f7cbd360a  vmovaps [rsp+0x40], xmm4
00007f4f7cbd3610  vmovaps [rsp+0x50], xmm5
00007f4f7cbd3616  vmovaps [rsp+0x60], xmm6
00007f4f7cbd361c  vmovaps [rsp+0x70], xmm7
00007f4f7cbd3622  vmovaps [rsp+0x80], xmm8
00007f4f7cbd362b  vmovaps [rsp+0x90], xmm9
00007f4f7cbd3634  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd363d  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd3646  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd364f  vmovaps [rsp+0xD0], xmm13
00007f4f7cbd3658  vmovaps [rsp+0xE0], xmm14
00007f4f7cbd3661  sub rsp, 0x40
00007f4f7cbd3665  lea rdi, [rsp]
00007f4f7cbd3669  lea rsi, [rsp+0x10]
00007f4f7cbd366e  lea rdx, [rsp+0x20]
00007f4f7cbd3673  lea rcx, [rsp+0x30]
00007f4f7cbd3678  mov r8d, 0x00
00007f4f7cbd367e  lea r9, [r15+0x3A8]
00007f4f7cbd3685  movaps [rdi], xmm15
00007f4f7cbd3689  movaps [rsi], xmm5
00007f4f7cbd368c  movaps [rdx], xmm1
00007f4f7cbd368f  movaps [rcx], xmm14
00007f4f7cbd3693  mov rax, 0x643999485A50
00007f4f7cbd369d  call rax
00007f4f7cbd369f  movaps xmm15, [rsp]
00007f4f7cbd36a4  add rsp, 0x40
00007f4f7cbd36a8  vmovaps xmm0, [rsp]
00007f4f7cbd36ad  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd36b3  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd36b9  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd36bf  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd36c5  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd36cb  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd36d1  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd36d7  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd36e0  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd36e9  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd36f2  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd36fb  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd3704  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbd370d  vmovaps xmm14, [rsp+0xE0]
00007f4f7cbd3716  add rsp, 0xF0
00007f4f7cbd371d  pop r11
00007f4f7cbd371f  pop r10
00007f4f7cbd3721  pop r9
00007f4f7cbd3723  pop r8
00007f4f7cbd3725  pop rsi
00007f4f7cbd3726  pop rdi
00007f4f7cbd3727  pop rdx
00007f4f7cbd3728  pop rcx
00007f4f7cbd3729  pop rax
00007f4f7cbd372a  add rsp, 0x08
00007f4f7cbd372e  jmp 0x00007F4F7CBD28D0
00007f4f7cbd3733  call 0x00007F4F7C9FF430
00007f4f7cbd3738  jmp 0x00007F4F7CBD295D
00007f4f7cbd373d  sub rsp, 0x08
00007f4f7cbd3741  push rax
00007f4f7cbd3742  push rcx
00007f4f7cbd3743  push rdx
00007f4f7cbd3744  push rdi
00007f4f7cbd3745  push rsi
00007f4f7cbd3746  push r8
00007f4f7cbd3748  push r9
00007f4f7cbd374a  push r10
00007f4f7cbd374c  push r11
00007f4f7cbd374e  sub rsp, 0xF0
00007f4f7cbd3755  vmovaps [rsp], xmm0
00007f4f7cbd375a  vmovaps [rsp+0x10], xmm1
00007f4f7cbd3760  vmovaps [rsp+0x20], xmm2
00007f4f7cbd3766  vmovaps [rsp+0x30], xmm3
00007f4f7cbd376c  vmovaps [rsp+0x40], xmm4
00007f4f7cbd3772  vmovaps [rsp+0x50], xmm5
00007f4f7cbd3778  vmovaps [rsp+0x60], xmm6
00007f4f7cbd377e  vmovaps [rsp+0x70], xmm7
00007f4f7cbd3784  vmovaps [rsp+0x80], xmm8
00007f4f7cbd378d  vmovaps [rsp+0x90], xmm9
00007f4f7cbd3796  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd379f  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd37a8  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd37b1  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd37ba  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd37c3  sub rsp, 0x40
00007f4f7cbd37c7  lea rdi, [rsp]
00007f4f7cbd37cb  lea rsi, [rsp+0x10]
00007f4f7cbd37d0  lea rdx, [rsp+0x20]
00007f4f7cbd37d5  lea rcx, [rsp+0x30]
00007f4f7cbd37da  mov r8d, 0x00
00007f4f7cbd37e0  lea r9, [r15+0x3A8]
00007f4f7cbd37e7  movaps [rdi], xmm13
00007f4f7cbd37eb  movaps [rsi], xmm1
00007f4f7cbd37ee  movaps [rdx], xmm15
00007f4f7cbd37f2  movaps [rcx], xmm14
00007f4f7cbd37f6  mov rax, 0x643999485A50
00007f4f7cbd3800  call rax
00007f4f7cbd3802  movaps xmm13, [rsp]
00007f4f7cbd3807  add rsp, 0x40
00007f4f7cbd380b  vmovaps xmm0, [rsp]
00007f4f7cbd3810  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd3816  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd381c  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd3822  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd3828  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd382e  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd3834  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd383a  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd3843  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd384c  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd3855  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd385e  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd3867  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd3870  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd3879  add rsp, 0xF0
00007f4f7cbd3880  pop r11
00007f4f7cbd3882  pop r10
00007f4f7cbd3884  pop r9
00007f4f7cbd3886  pop r8
00007f4f7cbd3888  pop rsi
00007f4f7cbd3889  pop rdi
00007f4f7cbd388a  pop rdx
00007f4f7cbd388b  pop rcx
00007f4f7cbd388c  pop rax
00007f4f7cbd388d  add rsp, 0x08
00007f4f7cbd3891  jmp 0x00007F4F7CBD29C1
00007f4f7cbd3896  call 0x00007F4F7C9FF430
00007f4f7cbd389b  jmp 0x00007F4F7CBD29CE
00007f4f7cbd38a0  sub rsp, 0x08
00007f4f7cbd38a4  push rax
00007f4f7cbd38a5  push rcx
00007f4f7cbd38a6  push rdx
00007f4f7cbd38a7  push rdi
00007f4f7cbd38a8  push rsi
00007f4f7cbd38a9  push r8
00007f4f7cbd38ab  push r9
00007f4f7cbd38ad  push r10
00007f4f7cbd38af  push r11
00007f4f7cbd38b1  sub rsp, 0xF0
00007f4f7cbd38b8  vmovaps [rsp], xmm0
00007f4f7cbd38bd  vmovaps [rsp+0x10], xmm1
00007f4f7cbd38c3  vmovaps [rsp+0x20], xmm2
00007f4f7cbd38c9  vmovaps [rsp+0x30], xmm3
00007f4f7cbd38cf  vmovaps [rsp+0x40], xmm4
00007f4f7cbd38d5  vmovaps [rsp+0x50], xmm5
00007f4f7cbd38db  vmovaps [rsp+0x60], xmm6
00007f4f7cbd38e1  vmovaps [rsp+0x70], xmm7
00007f4f7cbd38e7  vmovaps [rsp+0x80], xmm8
00007f4f7cbd38f0  vmovaps [rsp+0x90], xmm9
00007f4f7cbd38f9  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd3902  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd390b  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd3914  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd391d  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd3926  sub rsp, 0x40
00007f4f7cbd392a  lea rdi, [rsp]
00007f4f7cbd392e  lea rsi, [rsp+0x10]
00007f4f7cbd3933  lea rdx, [rsp+0x20]
00007f4f7cbd3938  lea rcx, [rsp+0x30]
00007f4f7cbd393d  mov r8d, 0x00
00007f4f7cbd3943  lea r9, [r15+0x3A8]
00007f4f7cbd394a  movaps [rdi], xmm12
00007f4f7cbd394e  movaps [rsi], xmm15
00007f4f7cbd3952  movaps [rdx], xmm1
00007f4f7cbd3955  movaps [rcx], xmm14
00007f4f7cbd3959  mov rax, 0x643999485A50
00007f4f7cbd3963  call rax
00007f4f7cbd3965  movaps xmm12, [rsp]
00007f4f7cbd396a  add rsp, 0x40
00007f4f7cbd396e  vmovaps xmm0, [rsp]
00007f4f7cbd3973  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd3979  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd397f  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd3985  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd398b  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd3991  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd3997  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd399d  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd39a6  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd39af  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd39b8  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd39c1  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd39ca  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd39d3  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd39dc  add rsp, 0xF0
00007f4f7cbd39e3  pop r11
00007f4f7cbd39e5  pop r10
00007f4f7cbd39e7  pop r9
00007f4f7cbd39e9  pop r8
00007f4f7cbd39eb  pop rsi
00007f4f7cbd39ec  pop rdi
00007f4f7cbd39ed  pop rdx
00007f4f7cbd39ee  pop rcx
00007f4f7cbd39ef  pop rax
00007f4f7cbd39f0  add rsp, 0x08
00007f4f7cbd39f4  jmp 0x00007F4F7CBD29FA
00007f4f7cbd39f9  sub rsp, 0x08
00007f4f7cbd39fd  push rax
00007f4f7cbd39fe  push rcx
00007f4f7cbd39ff  push rdx
00007f4f7cbd3a00  push rdi
00007f4f7cbd3a01  push rsi
00007f4f7cbd3a02  push r8
00007f4f7cbd3a04  push r9
00007f4f7cbd3a06  push r10
00007f4f7cbd3a08  push r11
00007f4f7cbd3a0a  sub rsp, 0xF0
00007f4f7cbd3a11  vmovaps [rsp], xmm0
00007f4f7cbd3a16  vmovaps [rsp+0x10], xmm1
00007f4f7cbd3a1c  vmovaps [rsp+0x20], xmm2
00007f4f7cbd3a22  vmovaps [rsp+0x30], xmm3
00007f4f7cbd3a28  vmovaps [rsp+0x40], xmm4
00007f4f7cbd3a2e  vmovaps [rsp+0x50], xmm5
00007f4f7cbd3a34  vmovaps [rsp+0x60], xmm6
00007f4f7cbd3a3a  vmovaps [rsp+0x70], xmm7
00007f4f7cbd3a40  vmovaps [rsp+0x80], xmm8
00007f4f7cbd3a49  vmovaps [rsp+0x90], xmm9
00007f4f7cbd3a52  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd3a5b  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd3a64  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd3a6d  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd3a76  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd3a7f  sub rsp, 0x40
00007f4f7cbd3a83  lea rdi, [rsp]
00007f4f7cbd3a87  lea rsi, [rsp+0x10]
00007f4f7cbd3a8c  lea rdx, [rsp+0x20]
00007f4f7cbd3a91  lea rcx, [rsp+0x30]
00007f4f7cbd3a96  mov r8d, 0x00
00007f4f7cbd3a9c  lea r9, [r15+0x3A8]
00007f4f7cbd3aa3  movaps [rdi], xmm13
00007f4f7cbd3aa7  movaps [rsi], xmm1
00007f4f7cbd3aaa  movaps [rdx], xmm15
00007f4f7cbd3aae  movaps [rcx], xmm14
00007f4f7cbd3ab2  mov rax, 0x643999485A50
00007f4f7cbd3abc  call rax
00007f4f7cbd3abe  movaps xmm13, [rsp]
00007f4f7cbd3ac3  add rsp, 0x40
00007f4f7cbd3ac7  vmovaps xmm0, [rsp]
00007f4f7cbd3acc  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd3ad2  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd3ad8  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd3ade  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd3ae4  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd3aea  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd3af0  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd3af6  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd3aff  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd3b08  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd3b11  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd3b1a  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd3b23  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd3b2c  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd3b35  add rsp, 0xF0
00007f4f7cbd3b3c  pop r11
00007f4f7cbd3b3e  pop r10
00007f4f7cbd3b40  pop r9
00007f4f7cbd3b42  pop r8
00007f4f7cbd3b44  pop rsi
00007f4f7cbd3b45  pop rdi
00007f4f7cbd3b46  pop rdx
00007f4f7cbd3b47  pop rcx
00007f4f7cbd3b48  pop rax
00007f4f7cbd3b49  add rsp, 0x08
00007f4f7cbd3b4d  jmp 0x00007F4F7CBD2B77
00007f4f7cbd3b52  sub rsp, 0x08
00007f4f7cbd3b56  push rax
00007f4f7cbd3b57  push rcx
00007f4f7cbd3b58  push rdx
00007f4f7cbd3b59  push rdi
00007f4f7cbd3b5a  push rsi
00007f4f7cbd3b5b  push r8
00007f4f7cbd3b5d  push r9
00007f4f7cbd3b5f  push r10
00007f4f7cbd3b61  push r11
00007f4f7cbd3b63  sub rsp, 0xF0
00007f4f7cbd3b6a  vmovaps [rsp], xmm0
00007f4f7cbd3b6f  vmovaps [rsp+0x10], xmm1
00007f4f7cbd3b75  vmovaps [rsp+0x20], xmm2
00007f4f7cbd3b7b  vmovaps [rsp+0x30], xmm3
00007f4f7cbd3b81  vmovaps [rsp+0x40], xmm4
00007f4f7cbd3b87  vmovaps [rsp+0x50], xmm5
00007f4f7cbd3b8d  vmovaps [rsp+0x60], xmm6
00007f4f7cbd3b93  vmovaps [rsp+0x70], xmm7
00007f4f7cbd3b99  vmovaps [rsp+0x80], xmm8
00007f4f7cbd3ba2  vmovaps [rsp+0x90], xmm9
00007f4f7cbd3bab  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd3bb4  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd3bbd  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd3bc6  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd3bcf  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd3bd8  sub rsp, 0x40
00007f4f7cbd3bdc  lea rdi, [rsp]
00007f4f7cbd3be0  lea rsi, [rsp+0x10]
00007f4f7cbd3be5  lea rdx, [rsp+0x20]
00007f4f7cbd3bea  lea rcx, [rsp+0x30]
00007f4f7cbd3bef  mov r8d, 0x00
00007f4f7cbd3bf5  lea r9, [r15+0x3A8]
00007f4f7cbd3bfc  movaps [rdi], xmm12
00007f4f7cbd3c00  movaps [rsi], xmm15
00007f4f7cbd3c04  movaps [rdx], xmm14
00007f4f7cbd3c08  movaps [rcx], xmm1
00007f4f7cbd3c0b  mov rax, 0x643999485A50
00007f4f7cbd3c15  call rax
00007f4f7cbd3c17  movaps xmm12, [rsp]
00007f4f7cbd3c1c  add rsp, 0x40
00007f4f7cbd3c20  vmovaps xmm0, [rsp]
00007f4f7cbd3c25  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd3c2b  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd3c31  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd3c37  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd3c3d  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd3c43  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd3c49  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd3c4f  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd3c58  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd3c61  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd3c6a  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd3c73  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd3c7c  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd3c85  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd3c8e  add rsp, 0xF0
00007f4f7cbd3c95  pop r11
00007f4f7cbd3c97  pop r10
00007f4f7cbd3c99  pop r9
00007f4f7cbd3c9b  pop r8
00007f4f7cbd3c9d  pop rsi
00007f4f7cbd3c9e  pop rdi
00007f4f7cbd3c9f  pop rdx
00007f4f7cbd3ca0  pop rcx
00007f4f7cbd3ca1  pop rax
00007f4f7cbd3ca2  add rsp, 0x08
00007f4f7cbd3ca6  jmp 0x00007F4F7CBD2BB2
00007f4f7cbd3cab  sub rsp, 0x08
00007f4f7cbd3caf  push rax
00007f4f7cbd3cb0  push rcx
00007f4f7cbd3cb1  push rdx
00007f4f7cbd3cb2  push rdi
00007f4f7cbd3cb3  push rsi
00007f4f7cbd3cb4  push r8
00007f4f7cbd3cb6  push r9
00007f4f7cbd3cb8  push r10
00007f4f7cbd3cba  push r11
00007f4f7cbd3cbc  sub rsp, 0xF0
00007f4f7cbd3cc3  vmovaps [rsp], xmm0
00007f4f7cbd3cc8  vmovaps [rsp+0x10], xmm1
00007f4f7cbd3cce  vmovaps [rsp+0x20], xmm2
00007f4f7cbd3cd4  vmovaps [rsp+0x30], xmm3
00007f4f7cbd3cda  vmovaps [rsp+0x40], xmm4
00007f4f7cbd3ce0  vmovaps [rsp+0x50], xmm5
00007f4f7cbd3ce6  vmovaps [rsp+0x60], xmm6
00007f4f7cbd3cec  vmovaps [rsp+0x70], xmm7
00007f4f7cbd3cf2  vmovaps [rsp+0x80], xmm8
00007f4f7cbd3cfb  vmovaps [rsp+0x90], xmm9
00007f4f7cbd3d04  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd3d0d  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd3d16  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd3d1f  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd3d28  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd3d31  sub rsp, 0x40
00007f4f7cbd3d35  lea rdi, [rsp]
00007f4f7cbd3d39  lea rsi, [rsp+0x10]
00007f4f7cbd3d3e  lea rdx, [rsp+0x20]
00007f4f7cbd3d43  lea rcx, [rsp+0x30]
00007f4f7cbd3d48  mov r8d, 0x00
00007f4f7cbd3d4e  lea r9, [r15+0x3A8]
00007f4f7cbd3d55  movaps [rdi], xmm13
00007f4f7cbd3d59  movaps [rsi], xmm15
00007f4f7cbd3d5d  movaps [rdx], xmm14
00007f4f7cbd3d61  movaps [rcx], xmm1
00007f4f7cbd3d64  mov rax, 0x643999485A50
00007f4f7cbd3d6e  call rax
00007f4f7cbd3d70  movaps xmm13, [rsp]
00007f4f7cbd3d75  add rsp, 0x40
00007f4f7cbd3d79  vmovaps xmm0, [rsp]
00007f4f7cbd3d7e  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd3d84  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd3d8a  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd3d90  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd3d96  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd3d9c  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd3da2  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd3da8  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd3db1  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd3dba  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd3dc3  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd3dcc  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd3dd5  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd3dde  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd3de7  add rsp, 0xF0
00007f4f7cbd3dee  pop r11
00007f4f7cbd3df0  pop r10
00007f4f7cbd3df2  pop r9
00007f4f7cbd3df4  pop r8
00007f4f7cbd3df6  pop rsi
00007f4f7cbd3df7  pop rdi
00007f4f7cbd3df8  pop rdx
00007f4f7cbd3df9  pop rcx
00007f4f7cbd3dfa  pop rax
00007f4f7cbd3dfb  add rsp, 0x08
00007f4f7cbd3dff  jmp 0x00007F4F7CBD2BEA
00007f4f7cbd3e04  sub rsp, 0x08
00007f4f7cbd3e08  push rax
00007f4f7cbd3e09  push rcx
00007f4f7cbd3e0a  push rdx
00007f4f7cbd3e0b  push rdi
00007f4f7cbd3e0c  push rsi
00007f4f7cbd3e0d  push r8
00007f4f7cbd3e0f  push r9
00007f4f7cbd3e11  push r10
00007f4f7cbd3e13  push r11
00007f4f7cbd3e15  sub rsp, 0xF0
00007f4f7cbd3e1c  vmovaps [rsp], xmm0
00007f4f7cbd3e21  vmovaps [rsp+0x10], xmm1
00007f4f7cbd3e27  vmovaps [rsp+0x20], xmm2
00007f4f7cbd3e2d  vmovaps [rsp+0x30], xmm3
00007f4f7cbd3e33  vmovaps [rsp+0x40], xmm4
00007f4f7cbd3e39  vmovaps [rsp+0x50], xmm5
00007f4f7cbd3e3f  vmovaps [rsp+0x60], xmm6
00007f4f7cbd3e45  vmovaps [rsp+0x70], xmm7
00007f4f7cbd3e4b  vmovaps [rsp+0x80], xmm8
00007f4f7cbd3e54  vmovaps [rsp+0x90], xmm9
00007f4f7cbd3e5d  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd3e66  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd3e6f  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd3e78  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd3e81  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd3e8a  sub rsp, 0x40
00007f4f7cbd3e8e  lea rdi, [rsp]
00007f4f7cbd3e92  lea rsi, [rsp+0x10]
00007f4f7cbd3e97  lea rdx, [rsp+0x20]
00007f4f7cbd3e9c  lea rcx, [rsp+0x30]
00007f4f7cbd3ea1  mov r8d, 0x00
00007f4f7cbd3ea7  lea r9, [r15+0x3A8]
00007f4f7cbd3eae  movaps [rdi], xmm12
00007f4f7cbd3eb2  movaps [rsi], xmm15
00007f4f7cbd3eb6  movaps [rdx], xmm14
00007f4f7cbd3eba  movaps [rcx], xmm1
00007f4f7cbd3ebd  mov rax, 0x643999485A50
00007f4f7cbd3ec7  call rax
00007f4f7cbd3ec9  movaps xmm12, [rsp]
00007f4f7cbd3ece  add rsp, 0x40
00007f4f7cbd3ed2  vmovaps xmm0, [rsp]
00007f4f7cbd3ed7  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd3edd  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd3ee3  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd3ee9  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd3eef  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd3ef5  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd3efb  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd3f01  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd3f0a  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd3f13  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd3f1c  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd3f25  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd3f2e  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd3f37  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd3f40  add rsp, 0xF0
00007f4f7cbd3f47  pop r11
00007f4f7cbd3f49  pop r10
00007f4f7cbd3f4b  pop r9
00007f4f7cbd3f4d  pop r8
00007f4f7cbd3f4f  pop rsi
00007f4f7cbd3f50  pop rdi
00007f4f7cbd3f51  pop rdx
00007f4f7cbd3f52  pop rcx
00007f4f7cbd3f53  pop rax
00007f4f7cbd3f54  add rsp, 0x08
00007f4f7cbd3f58  jmp 0x00007F4F7CBD2C3D
00007f4f7cbd3f5d  sub rsp, 0x08
00007f4f7cbd3f61  push rax
00007f4f7cbd3f62  push rcx
00007f4f7cbd3f63  push rdx
00007f4f7cbd3f64  push rdi
00007f4f7cbd3f65  push rsi
00007f4f7cbd3f66  push r8
00007f4f7cbd3f68  push r9
00007f4f7cbd3f6a  push r10
00007f4f7cbd3f6c  push r11
00007f4f7cbd3f6e  sub rsp, 0xF0
00007f4f7cbd3f75  vmovaps [rsp], xmm0
00007f4f7cbd3f7a  vmovaps [rsp+0x10], xmm1
00007f4f7cbd3f80  vmovaps [rsp+0x20], xmm2
00007f4f7cbd3f86  vmovaps [rsp+0x30], xmm3
00007f4f7cbd3f8c  vmovaps [rsp+0x40], xmm4
00007f4f7cbd3f92  vmovaps [rsp+0x50], xmm5
00007f4f7cbd3f98  vmovaps [rsp+0x60], xmm6
00007f4f7cbd3f9e  vmovaps [rsp+0x70], xmm7
00007f4f7cbd3fa4  vmovaps [rsp+0x80], xmm8
00007f4f7cbd3fad  vmovaps [rsp+0x90], xmm9
00007f4f7cbd3fb6  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd3fbf  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd3fc8  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd3fd1  vmovaps [rsp+0xD0], xmm13
00007f4f7cbd3fda  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd3fe3  sub rsp, 0x40
00007f4f7cbd3fe7  lea rdi, [rsp]
00007f4f7cbd3feb  lea rsi, [rsp+0x10]
00007f4f7cbd3ff0  lea rdx, [rsp+0x20]
00007f4f7cbd3ff5  lea rcx, [rsp+0x30]
00007f4f7cbd3ffa  mov r8d, 0x00
00007f4f7cbd4000  lea r9, [r15+0x3A8]
00007f4f7cbd4007  movaps [rdi], xmm14
00007f4f7cbd400b  movaps [rsi], xmm3
00007f4f7cbd400e  movaps [rdx], xmm1
00007f4f7cbd4011  movaps [rcx], xmm15
00007f4f7cbd4015  mov rax, 0x643999485A50
00007f4f7cbd401f  call rax
00007f4f7cbd4021  movaps xmm14, [rsp]
00007f4f7cbd4026  add rsp, 0x40
00007f4f7cbd402a  vmovaps xmm0, [rsp]
00007f4f7cbd402f  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd4035  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd403b  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd4041  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd4047  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd404d  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd4053  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd4059  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd4062  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd406b  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd4074  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd407d  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd4086  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbd408f  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd4098  add rsp, 0xF0
00007f4f7cbd409f  pop r11
00007f4f7cbd40a1  pop r10
00007f4f7cbd40a3  pop r9
00007f4f7cbd40a5  pop r8
00007f4f7cbd40a7  pop rsi
00007f4f7cbd40a8  pop rdi
00007f4f7cbd40a9  pop rdx
00007f4f7cbd40aa  pop rcx
00007f4f7cbd40ab  pop rax
00007f4f7cbd40ac  add rsp, 0x08
00007f4f7cbd40b0  jmp 0x00007F4F7CBD2CF7
00007f4f7cbd40b5  sub rsp, 0x08
00007f4f7cbd40b9  push rax
00007f4f7cbd40ba  push rcx
00007f4f7cbd40bb  push rdx
00007f4f7cbd40bc  push rdi
00007f4f7cbd40bd  push rsi
00007f4f7cbd40be  push r8
00007f4f7cbd40c0  push r9
00007f4f7cbd40c2  push r10
00007f4f7cbd40c4  push r11
00007f4f7cbd40c6  sub rsp, 0xF0
00007f4f7cbd40cd  vmovaps [rsp], xmm0
00007f4f7cbd40d2  vmovaps [rsp+0x10], xmm1
00007f4f7cbd40d8  vmovaps [rsp+0x20], xmm2
00007f4f7cbd40de  vmovaps [rsp+0x30], xmm3
00007f4f7cbd40e4  vmovaps [rsp+0x40], xmm4
00007f4f7cbd40ea  vmovaps [rsp+0x50], xmm5
00007f4f7cbd40f0  vmovaps [rsp+0x60], xmm6
00007f4f7cbd40f6  vmovaps [rsp+0x70], xmm7
00007f4f7cbd40fc  vmovaps [rsp+0x80], xmm8
00007f4f7cbd4105  vmovaps [rsp+0x90], xmm9
00007f4f7cbd410e  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd4117  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd4120  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd4129  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd4132  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd413b  sub rsp, 0x40
00007f4f7cbd413f  lea rdi, [rsp]
00007f4f7cbd4143  lea rsi, [rsp+0x10]
00007f4f7cbd4148  lea rdx, [rsp+0x20]
00007f4f7cbd414d  lea rcx, [rsp+0x30]
00007f4f7cbd4152  mov r8d, 0x00
00007f4f7cbd4158  lea r9, [r15+0x3A8]
00007f4f7cbd415f  movaps [rdi], xmm13
00007f4f7cbd4163  movaps [rsi], xmm15
00007f4f7cbd4167  movaps [rdx], xmm10
00007f4f7cbd416b  movaps [rcx], xmm1
00007f4f7cbd416e  mov rax, 0x643999485A50
00007f4f7cbd4178  call rax
00007f4f7cbd417a  movaps xmm13, [rsp]
00007f4f7cbd417f  add rsp, 0x40
00007f4f7cbd4183  vmovaps xmm0, [rsp]
00007f4f7cbd4188  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd418e  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd4194  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd419a  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd41a0  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd41a6  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd41ac  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd41b2  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd41bb  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd41c4  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd41cd  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd41d6  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd41df  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd41e8  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd41f1  add rsp, 0xF0
00007f4f7cbd41f8  pop r11
00007f4f7cbd41fa  pop r10
00007f4f7cbd41fc  pop r9
00007f4f7cbd41fe  pop r8
00007f4f7cbd4200  pop rsi
00007f4f7cbd4201  pop rdi
00007f4f7cbd4202  pop rdx
00007f4f7cbd4203  pop rcx
00007f4f7cbd4204  pop rax
00007f4f7cbd4205  add rsp, 0x08
00007f4f7cbd4209  jmp 0x00007F4F7CBD2D26
00007f4f7cbd420e  sub rsp, 0x08
00007f4f7cbd4212  push rax
00007f4f7cbd4213  push rcx
00007f4f7cbd4214  push rdx
00007f4f7cbd4215  push rdi
00007f4f7cbd4216  push rsi
00007f4f7cbd4217  push r8
00007f4f7cbd4219  push r9
00007f4f7cbd421b  push r10
00007f4f7cbd421d  push r11
00007f4f7cbd421f  sub rsp, 0xF0
00007f4f7cbd4226  vmovaps [rsp], xmm0
00007f4f7cbd422b  vmovaps [rsp+0x10], xmm1
00007f4f7cbd4231  vmovaps [rsp+0x20], xmm2
00007f4f7cbd4237  vmovaps [rsp+0x30], xmm3
00007f4f7cbd423d  vmovaps [rsp+0x40], xmm4
00007f4f7cbd4243  vmovaps [rsp+0x50], xmm5
00007f4f7cbd4249  vmovaps [rsp+0x60], xmm6
00007f4f7cbd424f  vmovaps [rsp+0x70], xmm7
00007f4f7cbd4255  vmovaps [rsp+0x80], xmm8
00007f4f7cbd425e  vmovaps [rsp+0x90], xmm9
00007f4f7cbd4267  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd4270  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd4279  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd4282  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd428b  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd4294  sub rsp, 0x40
00007f4f7cbd4298  lea rdi, [rsp]
00007f4f7cbd429c  lea rsi, [rsp+0x10]
00007f4f7cbd42a1  lea rdx, [rsp+0x20]
00007f4f7cbd42a6  lea rcx, [rsp+0x30]
00007f4f7cbd42ab  mov r8d, 0x00
00007f4f7cbd42b1  lea r9, [r15+0x3A8]
00007f4f7cbd42b8  movaps [rdi], xmm10
00007f4f7cbd42bc  movaps [rsi], xmm15
00007f4f7cbd42c0  movaps [rdx], xmm11
00007f4f7cbd42c4  movaps [rcx], xmm1
00007f4f7cbd42c7  mov rax, 0x643999485A50
00007f4f7cbd42d1  call rax
00007f4f7cbd42d3  movaps xmm10, [rsp]
00007f4f7cbd42d8  add rsp, 0x40
00007f4f7cbd42dc  vmovaps xmm0, [rsp]
00007f4f7cbd42e1  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd42e7  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd42ed  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd42f3  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd42f9  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd42ff  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd4305  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd430b  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd4314  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd431d  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd4326  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd432f  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd4338  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd4341  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd434a  add rsp, 0xF0
00007f4f7cbd4351  pop r11
00007f4f7cbd4353  pop r10
00007f4f7cbd4355  pop r9
00007f4f7cbd4357  pop r8
00007f4f7cbd4359  pop rsi
00007f4f7cbd435a  pop rdi
00007f4f7cbd435b  pop rdx
00007f4f7cbd435c  pop rcx
00007f4f7cbd435d  pop rax
00007f4f7cbd435e  add rsp, 0x08
00007f4f7cbd4362  jmp 0x00007F4F7CBD2D55
00007f4f7cbd4367  sub rsp, 0x08
00007f4f7cbd436b  push rax
00007f4f7cbd436c  push rcx
00007f4f7cbd436d  push rdx
00007f4f7cbd436e  push rdi
00007f4f7cbd436f  push rsi
00007f4f7cbd4370  push r8
00007f4f7cbd4372  push r9
00007f4f7cbd4374  push r10
00007f4f7cbd4376  push r11
00007f4f7cbd4378  sub rsp, 0xF0
00007f4f7cbd437f  vmovaps [rsp], xmm0
00007f4f7cbd4384  vmovaps [rsp+0x10], xmm1
00007f4f7cbd438a  vmovaps [rsp+0x20], xmm2
00007f4f7cbd4390  vmovaps [rsp+0x30], xmm3
00007f4f7cbd4396  vmovaps [rsp+0x40], xmm4
00007f4f7cbd439c  vmovaps [rsp+0x50], xmm5
00007f4f7cbd43a2  vmovaps [rsp+0x60], xmm6
00007f4f7cbd43a8  vmovaps [rsp+0x70], xmm7
00007f4f7cbd43ae  vmovaps [rsp+0x80], xmm8
00007f4f7cbd43b7  vmovaps [rsp+0x90], xmm9
00007f4f7cbd43c0  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd43c9  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd43d2  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd43db  vmovaps [rsp+0xD0], xmm13
00007f4f7cbd43e4  vmovaps [rsp+0xE0], xmm14
00007f4f7cbd43ed  sub rsp, 0x40
00007f4f7cbd43f1  lea rdi, [rsp]
00007f4f7cbd43f5  lea rsi, [rsp+0x10]
00007f4f7cbd43fa  lea rdx, [rsp+0x20]
00007f4f7cbd43ff  lea rcx, [rsp+0x30]
00007f4f7cbd4404  mov r8d, 0x00
00007f4f7cbd440a  lea r9, [r15+0x3A8]
00007f4f7cbd4411  movaps [rdi], xmm15
00007f4f7cbd4415  movaps [rsi], xmm12
00007f4f7cbd4419  movaps [rdx], xmm5
00007f4f7cbd441c  movaps [rcx], xmm1
00007f4f7cbd441f  mov rax, 0x643999485A50
00007f4f7cbd4429  call rax
00007f4f7cbd442b  movaps xmm15, [rsp]
00007f4f7cbd4430  add rsp, 0x40
00007f4f7cbd4434  vmovaps xmm0, [rsp]
00007f4f7cbd4439  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd443f  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd4445  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd444b  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd4451  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd4457  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd445d  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd4463  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd446c  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd4475  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd447e  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd4487  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd4490  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbd4499  vmovaps xmm14, [rsp+0xE0]
00007f4f7cbd44a2  add rsp, 0xF0
00007f4f7cbd44a9  pop r11
00007f4f7cbd44ab  pop r10
00007f4f7cbd44ad  pop r9
00007f4f7cbd44af  pop r8
00007f4f7cbd44b1  pop rsi
00007f4f7cbd44b2  pop rdi
00007f4f7cbd44b3  pop rdx
00007f4f7cbd44b4  pop rcx
00007f4f7cbd44b5  pop rax
00007f4f7cbd44b6  add rsp, 0x08
00007f4f7cbd44ba  jmp 0x00007F4F7CBD2D7E
00007f4f7cbd44bf  sub rsp, 0x08
00007f4f7cbd44c3  push rax
00007f4f7cbd44c4  push rcx
00007f4f7cbd44c5  push rdx
00007f4f7cbd44c6  push rdi
00007f4f7cbd44c7  push rsi
00007f4f7cbd44c8  push r8
00007f4f7cbd44ca  push r9
00007f4f7cbd44cc  push r10
00007f4f7cbd44ce  push r11
00007f4f7cbd44d0  sub rsp, 0xF0
00007f4f7cbd44d7  vmovaps [rsp], xmm0
00007f4f7cbd44dc  vmovaps [rsp+0x10], xmm1
00007f4f7cbd44e2  vmovaps [rsp+0x20], xmm2
00007f4f7cbd44e8  vmovaps [rsp+0x30], xmm3
00007f4f7cbd44ee  vmovaps [rsp+0x40], xmm4
00007f4f7cbd44f4  vmovaps [rsp+0x50], xmm6
00007f4f7cbd44fa  vmovaps [rsp+0x60], xmm7
00007f4f7cbd4500  vmovaps [rsp+0x70], xmm8
00007f4f7cbd4506  vmovaps [rsp+0x80], xmm9
00007f4f7cbd450f  vmovaps [rsp+0x90], xmm10
00007f4f7cbd4518  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd4521  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd452a  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd4533  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd453c  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd4545  sub rsp, 0x40
00007f4f7cbd4549  lea rdi, [rsp]
00007f4f7cbd454d  lea rsi, [rsp+0x10]
00007f4f7cbd4552  lea rdx, [rsp+0x20]
00007f4f7cbd4557  lea rcx, [rsp+0x30]
00007f4f7cbd455c  mov r8d, 0x00
00007f4f7cbd4562  lea r9, [r15+0x3A8]
00007f4f7cbd4569  movaps [rdi], xmm5
00007f4f7cbd456c  movaps [rsi], xmm13
00007f4f7cbd4570  movaps [rdx], xmm11
00007f4f7cbd4574  movaps [rcx], xmm12
00007f4f7cbd4578  mov rax, 0x643999485A50
00007f4f7cbd4582  call rax
00007f4f7cbd4584  movaps xmm5, [rsp]
00007f4f7cbd4588  add rsp, 0x40
00007f4f7cbd458c  vmovaps xmm0, [rsp]
00007f4f7cbd4591  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd4597  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd459d  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd45a3  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd45a9  vmovaps xmm6, [rsp+0x50]
00007f4f7cbd45af  vmovaps xmm7, [rsp+0x60]
00007f4f7cbd45b5  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd45bb  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd45c4  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd45cd  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd45d6  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd45df  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd45e8  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd45f1  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd45fa  add rsp, 0xF0
00007f4f7cbd4601  pop r11
00007f4f7cbd4603  pop r10
00007f4f7cbd4605  pop r9
00007f4f7cbd4607  pop r8
00007f4f7cbd4609  pop rsi
00007f4f7cbd460a  pop rdi
00007f4f7cbd460b  pop rdx
00007f4f7cbd460c  pop rcx
00007f4f7cbd460d  pop rax
00007f4f7cbd460e  add rsp, 0x08
00007f4f7cbd4612  jmp 0x00007F4F7CBD2DDD
00007f4f7cbd4617  sub rsp, 0x08
00007f4f7cbd461b  push rax
00007f4f7cbd461c  push rcx
00007f4f7cbd461d  push rdx
00007f4f7cbd461e  push rdi
00007f4f7cbd461f  push rsi
00007f4f7cbd4620  push r8
00007f4f7cbd4622  push r9
00007f4f7cbd4624  push r10
00007f4f7cbd4626  push r11
00007f4f7cbd4628  sub rsp, 0xF0
00007f4f7cbd462f  vmovaps [rsp], xmm0
00007f4f7cbd4634  vmovaps [rsp+0x10], xmm1
00007f4f7cbd463a  vmovaps [rsp+0x20], xmm2
00007f4f7cbd4640  vmovaps [rsp+0x30], xmm3
00007f4f7cbd4646  vmovaps [rsp+0x40], xmm4
00007f4f7cbd464c  vmovaps [rsp+0x50], xmm5
00007f4f7cbd4652  vmovaps [rsp+0x60], xmm6
00007f4f7cbd4658  vmovaps [rsp+0x70], xmm7
00007f4f7cbd465e  vmovaps [rsp+0x80], xmm8
00007f4f7cbd4667  vmovaps [rsp+0x90], xmm9
00007f4f7cbd4670  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd4679  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd4682  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd468b  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd4694  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd469d  sub rsp, 0x40
00007f4f7cbd46a1  lea rdi, [rsp]
00007f4f7cbd46a5  lea rsi, [rsp+0x10]
00007f4f7cbd46aa  lea rdx, [rsp+0x20]
00007f4f7cbd46af  lea rcx, [rsp+0x30]
00007f4f7cbd46b4  mov r8d, 0x00
00007f4f7cbd46ba  lea r9, [r15+0x3A8]
00007f4f7cbd46c1  movaps [rdi], xmm12
00007f4f7cbd46c5  movaps [rsi], xmm14
00007f4f7cbd46c9  movaps [rdx], xmm9
00007f4f7cbd46cd  movaps [rcx], xmm13
00007f4f7cbd46d1  mov rax, 0x643999485A50
00007f4f7cbd46db  call rax
00007f4f7cbd46dd  movaps xmm12, [rsp]
00007f4f7cbd46e2  add rsp, 0x40
00007f4f7cbd46e6  vmovaps xmm0, [rsp]
00007f4f7cbd46eb  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd46f1  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd46f7  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd46fd  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd4703  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd4709  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd470f  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd4715  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd471e  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd4727  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd4730  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd4739  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd4742  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd474b  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd4754  add rsp, 0xF0
00007f4f7cbd475b  pop r11
00007f4f7cbd475d  pop r10
00007f4f7cbd475f  pop r9
00007f4f7cbd4761  pop r8
00007f4f7cbd4763  pop rsi
00007f4f7cbd4764  pop rdi
00007f4f7cbd4765  pop rdx
00007f4f7cbd4766  pop rcx
00007f4f7cbd4767  pop rax
00007f4f7cbd4768  add rsp, 0x08
00007f4f7cbd476c  jmp 0x00007F4F7CBD2E06
00007f4f7cbd4771  call 0x00007F4F7CA0D4E0
00007f4f7cbd4776  jmp 0x00007F4F7CBD2E13
00007f4f7cbd477b  sub rsp, 0x08
00007f4f7cbd477f  push rax
00007f4f7cbd4780  push rcx
00007f4f7cbd4781  push rdx
00007f4f7cbd4782  push rdi
00007f4f7cbd4783  push rsi
00007f4f7cbd4784  push r8
00007f4f7cbd4786  push r9
00007f4f7cbd4788  push r10
00007f4f7cbd478a  push r11
00007f4f7cbd478c  sub rsp, 0xF0
00007f4f7cbd4793  vmovaps [rsp], xmm0
00007f4f7cbd4798  vmovaps [rsp+0x10], xmm1
00007f4f7cbd479e  vmovaps [rsp+0x20], xmm2
00007f4f7cbd47a4  vmovaps [rsp+0x30], xmm3
00007f4f7cbd47aa  vmovaps [rsp+0x40], xmm4
00007f4f7cbd47b0  vmovaps [rsp+0x50], xmm5
00007f4f7cbd47b6  vmovaps [rsp+0x60], xmm6
00007f4f7cbd47bc  vmovaps [rsp+0x70], xmm7
00007f4f7cbd47c2  vmovaps [rsp+0x80], xmm8
00007f4f7cbd47cb  vmovaps [rsp+0x90], xmm9
00007f4f7cbd47d4  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd47dd  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd47e6  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd47ef  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd47f8  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd4801  sub rsp, 0x40
00007f4f7cbd4805  lea rdi, [rsp]
00007f4f7cbd4809  lea rsi, [rsp+0x10]
00007f4f7cbd480e  lea rdx, [rsp+0x20]
00007f4f7cbd4813  lea rcx, [rsp+0x30]
00007f4f7cbd4818  mov r8d, 0x00
00007f4f7cbd481e  lea r9, [r15+0x3A8]
00007f4f7cbd4825  movaps [rdi], xmm11
00007f4f7cbd4829  movaps [rsi], xmm10
00007f4f7cbd482d  movaps [rdx], xmm8
00007f4f7cbd4831  movaps [rcx], xmm13
00007f4f7cbd4835  mov rax, 0x643999485A50
00007f4f7cbd483f  call rax
00007f4f7cbd4841  movaps xmm11, [rsp]
00007f4f7cbd4846  add rsp, 0x40
00007f4f7cbd484a  vmovaps xmm0, [rsp]
00007f4f7cbd484f  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd4855  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd485b  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd4861  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd4867  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd486d  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd4873  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd4879  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd4882  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd488b  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd4894  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd489d  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd48a6  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd48af  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd48b8  add rsp, 0xF0
00007f4f7cbd48bf  pop r11
00007f4f7cbd48c1  pop r10
00007f4f7cbd48c3  pop r9
00007f4f7cbd48c5  pop r8
00007f4f7cbd48c7  pop rsi
00007f4f7cbd48c8  pop rdi
00007f4f7cbd48c9  pop rdx
00007f4f7cbd48ca  pop rcx
00007f4f7cbd48cb  pop rax
00007f4f7cbd48cc  add rsp, 0x08
00007f4f7cbd48d0  jmp 0x00007F4F7CBD2E44
00007f4f7cbd48d5  sub rsp, 0x08
00007f4f7cbd48d9  push rax
00007f4f7cbd48da  push rcx
00007f4f7cbd48db  push rdx
00007f4f7cbd48dc  push rdi
00007f4f7cbd48dd  push rsi
00007f4f7cbd48de  push r8
00007f4f7cbd48e0  push r9
00007f4f7cbd48e2  push r10
00007f4f7cbd48e4  push r11
00007f4f7cbd48e6  sub rsp, 0xF0
00007f4f7cbd48ed  vmovaps [rsp], xmm0
00007f4f7cbd48f2  vmovaps [rsp+0x10], xmm1
00007f4f7cbd48f8  vmovaps [rsp+0x20], xmm2
00007f4f7cbd48fe  vmovaps [rsp+0x30], xmm3
00007f4f7cbd4904  vmovaps [rsp+0x40], xmm4
00007f4f7cbd490a  vmovaps [rsp+0x50], xmm5
00007f4f7cbd4910  vmovaps [rsp+0x60], xmm6
00007f4f7cbd4916  vmovaps [rsp+0x70], xmm7
00007f4f7cbd491c  vmovaps [rsp+0x80], xmm8
00007f4f7cbd4925  vmovaps [rsp+0x90], xmm9
00007f4f7cbd492e  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd4937  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd4940  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd4949  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd4952  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd495b  sub rsp, 0x40
00007f4f7cbd495f  lea rdi, [rsp]
00007f4f7cbd4963  lea rsi, [rsp+0x10]
00007f4f7cbd4968  lea rdx, [rsp+0x20]
00007f4f7cbd496d  lea rcx, [rsp+0x30]
00007f4f7cbd4972  mov r8d, 0x00
00007f4f7cbd4978  lea r9, [r15+0x3A8]
00007f4f7cbd497f  movaps [rdi], xmm10
00007f4f7cbd4983  movaps [rsi], xmm15
00007f4f7cbd4987  movaps [rdx], xmm1
00007f4f7cbd498a  movaps [rcx], xmm13
00007f4f7cbd498e  mov rax, 0x643999485A50
00007f4f7cbd4998  call rax
00007f4f7cbd499a  movaps xmm10, [rsp]
00007f4f7cbd499f  add rsp, 0x40
00007f4f7cbd49a3  vmovaps xmm0, [rsp]
00007f4f7cbd49a8  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd49ae  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd49b4  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd49ba  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd49c0  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd49c6  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd49cc  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd49d2  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd49db  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd49e4  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd49ed  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd49f6  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd49ff  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd4a08  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd4a11  add rsp, 0xF0
00007f4f7cbd4a18  pop r11
00007f4f7cbd4a1a  pop r10
00007f4f7cbd4a1c  pop r9
00007f4f7cbd4a1e  pop r8
00007f4f7cbd4a20  pop rsi
00007f4f7cbd4a21  pop rdi
00007f4f7cbd4a22  pop rdx
00007f4f7cbd4a23  pop rcx
00007f4f7cbd4a24  pop rax
00007f4f7cbd4a25  add rsp, 0x08
00007f4f7cbd4a29  jmp 0x00007F4F7CBD2E6D
00007f4f7cbd4a2e  call 0x00007F4F7C9FF430
00007f4f7cbd4a33  jmp 0x00007F4F7CBD2E8F
00007f4f7cbd4a38  call 0x00007F4F7CA0E760
00007f4f7cbd4a3d  jmp 0x00007F4F7CBD2E99
00007f4f7cbd4a42  sub rsp, 0x08
00007f4f7cbd4a46  push rax
00007f4f7cbd4a47  push rcx
00007f4f7cbd4a48  push rdx
00007f4f7cbd4a49  push rdi
00007f4f7cbd4a4a  push rsi
00007f4f7cbd4a4b  push r8
00007f4f7cbd4a4d  push r9
00007f4f7cbd4a4f  push r10
00007f4f7cbd4a51  push r11
00007f4f7cbd4a53  sub rsp, 0xF0
00007f4f7cbd4a5a  vmovaps [rsp], xmm0
00007f4f7cbd4a5f  vmovaps [rsp+0x10], xmm1
00007f4f7cbd4a65  vmovaps [rsp+0x20], xmm2
00007f4f7cbd4a6b  vmovaps [rsp+0x30], xmm3
00007f4f7cbd4a71  vmovaps [rsp+0x40], xmm4
00007f4f7cbd4a77  vmovaps [rsp+0x50], xmm5
00007f4f7cbd4a7d  vmovaps [rsp+0x60], xmm6
00007f4f7cbd4a83  vmovaps [rsp+0x70], xmm7
00007f4f7cbd4a89  vmovaps [rsp+0x80], xmm9
00007f4f7cbd4a92  vmovaps [rsp+0x90], xmm10
00007f4f7cbd4a9b  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd4aa4  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd4aad  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd4ab6  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd4abf  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd4ac8  sub rsp, 0x40
00007f4f7cbd4acc  lea rdi, [rsp]
00007f4f7cbd4ad0  lea rsi, [rsp+0x10]
00007f4f7cbd4ad5  lea rdx, [rsp+0x20]
00007f4f7cbd4ada  lea rcx, [rsp+0x30]
00007f4f7cbd4adf  mov r8d, 0x00
00007f4f7cbd4ae5  lea r9, [r15+0x3A8]
00007f4f7cbd4aec  movaps [rdi], xmm8
00007f4f7cbd4af0  movaps [rsi], xmm5
00007f4f7cbd4af3  movaps [rdx], xmm9
00007f4f7cbd4af7  movaps [rcx], xmm13
00007f4f7cbd4afb  mov rax, 0x643999485A50
00007f4f7cbd4b05  call rax
00007f4f7cbd4b07  movaps xmm8, [rsp]
00007f4f7cbd4b0c  add rsp, 0x40
00007f4f7cbd4b10  vmovaps xmm0, [rsp]
00007f4f7cbd4b15  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd4b1b  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd4b21  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd4b27  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd4b2d  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd4b33  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd4b39  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd4b3f  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd4b48  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd4b51  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd4b5a  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd4b63  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd4b6c  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd4b75  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd4b7e  add rsp, 0xF0
00007f4f7cbd4b85  pop r11
00007f4f7cbd4b87  pop r10
00007f4f7cbd4b89  pop r9
00007f4f7cbd4b8b  pop r8
00007f4f7cbd4b8d  pop rsi
00007f4f7cbd4b8e  pop rdi
00007f4f7cbd4b8f  pop rdx
00007f4f7cbd4b90  pop rcx
00007f4f7cbd4b91  pop rax
00007f4f7cbd4b92  add rsp, 0x08
00007f4f7cbd4b96  jmp 0x00007F4F7CBD2ED8
00007f4f7cbd4b9b  sub rsp, 0x08
00007f4f7cbd4b9f  push rax
00007f4f7cbd4ba0  push rcx
00007f4f7cbd4ba1  push rdx
00007f4f7cbd4ba2  push rdi
00007f4f7cbd4ba3  push rsi
00007f4f7cbd4ba4  push r8
00007f4f7cbd4ba6  push r9
00007f4f7cbd4ba8  push r10
00007f4f7cbd4baa  push r11
00007f4f7cbd4bac  sub rsp, 0xF0
00007f4f7cbd4bb3  vmovaps [rsp], xmm0
00007f4f7cbd4bb8  vmovaps [rsp+0x10], xmm1
00007f4f7cbd4bbe  vmovaps [rsp+0x20], xmm2
00007f4f7cbd4bc4  vmovaps [rsp+0x30], xmm3
00007f4f7cbd4bca  vmovaps [rsp+0x40], xmm4
00007f4f7cbd4bd0  vmovaps [rsp+0x50], xmm5
00007f4f7cbd4bd6  vmovaps [rsp+0x60], xmm6
00007f4f7cbd4bdc  vmovaps [rsp+0x70], xmm7
00007f4f7cbd4be2  vmovaps [rsp+0x80], xmm8
00007f4f7cbd4beb  vmovaps [rsp+0x90], xmm10
00007f4f7cbd4bf4  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd4bfd  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd4c06  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd4c0f  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd4c18  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd4c21  sub rsp, 0x40
00007f4f7cbd4c25  lea rdi, [rsp]
00007f4f7cbd4c29  lea rsi, [rsp+0x10]
00007f4f7cbd4c2e  lea rdx, [rsp+0x20]
00007f4f7cbd4c33  lea rcx, [rsp+0x30]
00007f4f7cbd4c38  mov r8d, 0x00
00007f4f7cbd4c3e  lea r9, [r15+0x3A8]
00007f4f7cbd4c45  movaps [rdi], xmm9
00007f4f7cbd4c49  movaps [rsi], xmm12
00007f4f7cbd4c4d  movaps [rdx], xmm7
00007f4f7cbd4c50  movaps [rcx], xmm13
00007f4f7cbd4c54  mov rax, 0x643999485A50
00007f4f7cbd4c5e  call rax
00007f4f7cbd4c60  movaps xmm9, [rsp]
00007f4f7cbd4c65  add rsp, 0x40
00007f4f7cbd4c69  vmovaps xmm0, [rsp]
00007f4f7cbd4c6e  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd4c74  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd4c7a  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd4c80  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd4c86  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd4c8c  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd4c92  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd4c98  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd4ca1  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd4caa  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd4cb3  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd4cbc  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd4cc5  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd4cce  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd4cd7  add rsp, 0xF0
00007f4f7cbd4cde  pop r11
00007f4f7cbd4ce0  pop r10
00007f4f7cbd4ce2  pop r9
00007f4f7cbd4ce4  pop r8
00007f4f7cbd4ce6  pop rsi
00007f4f7cbd4ce7  pop rdi
00007f4f7cbd4ce8  pop rdx
00007f4f7cbd4ce9  pop rcx
00007f4f7cbd4cea  pop rax
00007f4f7cbd4ceb  add rsp, 0x08
00007f4f7cbd4cef  jmp 0x00007F4F7CBD2F01
00007f4f7cbd4cf4  sub rsp, 0x08
00007f4f7cbd4cf8  push rax
00007f4f7cbd4cf9  push rcx
00007f4f7cbd4cfa  push rdx
00007f4f7cbd4cfb  push rdi
00007f4f7cbd4cfc  push rsi
00007f4f7cbd4cfd  push r8
00007f4f7cbd4cff  push r9
00007f4f7cbd4d01  push r10
00007f4f7cbd4d03  push r11
00007f4f7cbd4d05  sub rsp, 0xF0
00007f4f7cbd4d0c  vmovaps [rsp], xmm0
00007f4f7cbd4d11  vmovaps [rsp+0x10], xmm1
00007f4f7cbd4d17  vmovaps [rsp+0x20], xmm2
00007f4f7cbd4d1d  vmovaps [rsp+0x30], xmm3
00007f4f7cbd4d23  vmovaps [rsp+0x40], xmm4
00007f4f7cbd4d29  vmovaps [rsp+0x50], xmm5
00007f4f7cbd4d2f  vmovaps [rsp+0x60], xmm6
00007f4f7cbd4d35  vmovaps [rsp+0x70], xmm7
00007f4f7cbd4d3b  vmovaps [rsp+0x80], xmm8
00007f4f7cbd4d44  vmovaps [rsp+0x90], xmm9
00007f4f7cbd4d4d  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd4d56  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd4d5f  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd4d68  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd4d71  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd4d7a  sub rsp, 0x40
00007f4f7cbd4d7e  lea rdi, [rsp]
00007f4f7cbd4d82  lea rsi, [rsp+0x10]
00007f4f7cbd4d87  lea rdx, [rsp+0x20]
00007f4f7cbd4d8c  lea rcx, [rsp+0x30]
00007f4f7cbd4d91  mov r8d, 0x00
00007f4f7cbd4d97  lea r9, [r15+0x3A8]
00007f4f7cbd4d9e  movaps [rdi], xmm12
00007f4f7cbd4da2  movaps [rsi], xmm11
00007f4f7cbd4da6  movaps [rdx], xmm6
00007f4f7cbd4da9  movaps [rcx], xmm13
00007f4f7cbd4dad  mov rax, 0x643999485A50
00007f4f7cbd4db7  call rax
00007f4f7cbd4db9  movaps xmm12, [rsp]
00007f4f7cbd4dbe  add rsp, 0x40
00007f4f7cbd4dc2  vmovaps xmm0, [rsp]
00007f4f7cbd4dc7  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd4dcd  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd4dd3  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd4dd9  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd4ddf  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd4de5  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd4deb  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd4df1  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd4dfa  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd4e03  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd4e0c  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd4e15  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd4e1e  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd4e27  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd4e30  add rsp, 0xF0
00007f4f7cbd4e37  pop r11
00007f4f7cbd4e39  pop r10
00007f4f7cbd4e3b  pop r9
00007f4f7cbd4e3d  pop r8
00007f4f7cbd4e3f  pop rsi
00007f4f7cbd4e40  pop rdi
00007f4f7cbd4e41  pop rdx
00007f4f7cbd4e42  pop rcx
00007f4f7cbd4e43  pop rax
00007f4f7cbd4e44  add rsp, 0x08
00007f4f7cbd4e48  jmp 0x00007F4F7CBD2F2A
00007f4f7cbd4e4d  sub rsp, 0x08
00007f4f7cbd4e51  push rax
00007f4f7cbd4e52  push rcx
00007f4f7cbd4e53  push rdx
00007f4f7cbd4e54  push rdi
00007f4f7cbd4e55  push rsi
00007f4f7cbd4e56  push r8
00007f4f7cbd4e58  push r9
00007f4f7cbd4e5a  push r10
00007f4f7cbd4e5c  push r11
00007f4f7cbd4e5e  sub rsp, 0xF0
00007f4f7cbd4e65  vmovaps [rsp], xmm0
00007f4f7cbd4e6a  vmovaps [rsp+0x10], xmm1
00007f4f7cbd4e70  vmovaps [rsp+0x20], xmm2
00007f4f7cbd4e76  vmovaps [rsp+0x30], xmm3
00007f4f7cbd4e7c  vmovaps [rsp+0x40], xmm4
00007f4f7cbd4e82  vmovaps [rsp+0x50], xmm5
00007f4f7cbd4e88  vmovaps [rsp+0x60], xmm6
00007f4f7cbd4e8e  vmovaps [rsp+0x70], xmm8
00007f4f7cbd4e94  vmovaps [rsp+0x80], xmm9
00007f4f7cbd4e9d  vmovaps [rsp+0x90], xmm10
00007f4f7cbd4ea6  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd4eaf  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd4eb8  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd4ec1  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd4eca  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd4ed3  sub rsp, 0x40
00007f4f7cbd4ed7  lea rdi, [rsp]
00007f4f7cbd4edb  lea rsi, [rsp+0x10]
00007f4f7cbd4ee0  lea rdx, [rsp+0x20]
00007f4f7cbd4ee5  lea rcx, [rsp+0x30]
00007f4f7cbd4eea  mov r8d, 0x00
00007f4f7cbd4ef0  lea r9, [r15+0x3A8]
00007f4f7cbd4ef7  movaps [rdi], xmm7
00007f4f7cbd4efa  movaps [rsi], xmm10
00007f4f7cbd4efe  movaps [rdx], xmm11
00007f4f7cbd4f02  movaps [rcx], xmm13
00007f4f7cbd4f06  mov rax, 0x643999485A50
00007f4f7cbd4f10  call rax
00007f4f7cbd4f12  movaps xmm7, [rsp]
00007f4f7cbd4f16  add rsp, 0x40
00007f4f7cbd4f1a  vmovaps xmm0, [rsp]
00007f4f7cbd4f1f  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd4f25  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd4f2b  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd4f31  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd4f37  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd4f3d  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd4f43  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd4f49  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd4f52  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd4f5b  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd4f64  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd4f6d  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd4f76  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd4f7f  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd4f88  add rsp, 0xF0
00007f4f7cbd4f8f  pop r11
00007f4f7cbd4f91  pop r10
00007f4f7cbd4f93  pop r9
00007f4f7cbd4f95  pop r8
00007f4f7cbd4f97  pop rsi
00007f4f7cbd4f98  pop rdi
00007f4f7cbd4f99  pop rdx
00007f4f7cbd4f9a  pop rcx
00007f4f7cbd4f9b  pop rax
00007f4f7cbd4f9c  add rsp, 0x08
00007f4f7cbd4fa0  jmp 0x00007F4F7CBD2F58
00007f4f7cbd4fa5  call 0x00007F4F7CA0C260
00007f4f7cbd4faa  jmp 0x00007F4F7CBD2F62
00007f4f7cbd4faf  call 0x00007F4F7CA09D70
00007f4f7cbd4fb4  jmp 0x00007F4F7CBD2F6C
00007f4f7cbd4fb9  sub rsp, 0x08
00007f4f7cbd4fbd  push rax
00007f4f7cbd4fbe  push rcx
00007f4f7cbd4fbf  push rdx
00007f4f7cbd4fc0  push rdi
00007f4f7cbd4fc1  push rsi
00007f4f7cbd4fc2  push r8
00007f4f7cbd4fc4  push r9
00007f4f7cbd4fc6  push r10
00007f4f7cbd4fc8  push r11
00007f4f7cbd4fca  sub rsp, 0xF0
00007f4f7cbd4fd1  vmovaps [rsp], xmm0
00007f4f7cbd4fd6  vmovaps [rsp+0x10], xmm1
00007f4f7cbd4fdc  vmovaps [rsp+0x20], xmm2
00007f4f7cbd4fe2  vmovaps [rsp+0x30], xmm3
00007f4f7cbd4fe8  vmovaps [rsp+0x40], xmm4
00007f4f7cbd4fee  vmovaps [rsp+0x50], xmm5
00007f4f7cbd4ff4  vmovaps [rsp+0x60], xmm7
00007f4f7cbd4ffa  vmovaps [rsp+0x70], xmm8
00007f4f7cbd5000  vmovaps [rsp+0x80], xmm9
00007f4f7cbd5009  vmovaps [rsp+0x90], xmm10
00007f4f7cbd5012  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd501b  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd5024  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd502d  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd5036  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd503f  sub rsp, 0x40
00007f4f7cbd5043  lea rdi, [rsp]
00007f4f7cbd5047  lea rsi, [rsp+0x10]
00007f4f7cbd504c  lea rdx, [rsp+0x20]
00007f4f7cbd5051  lea rcx, [rsp+0x30]
00007f4f7cbd5056  mov r8d, 0x00
00007f4f7cbd505c  lea r9, [r15+0x3A8]
00007f4f7cbd5063  movaps [rdi], xmm6
00007f4f7cbd5066  movaps [rsi], xmm8
00007f4f7cbd506a  movaps [rdx], xmm15
00007f4f7cbd506e  movaps [rcx], xmm10
00007f4f7cbd5072  mov rax, 0x643999485A50
00007f4f7cbd507c  call rax
00007f4f7cbd507e  movaps xmm6, [rsp]
00007f4f7cbd5082  add rsp, 0x40
00007f4f7cbd5086  vmovaps xmm0, [rsp]
00007f4f7cbd508b  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd5091  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd5097  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd509d  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd50a3  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd50a9  vmovaps xmm7, [rsp+0x60]
00007f4f7cbd50af  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd50b5  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd50be  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd50c7  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd50d0  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd50d9  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd50e2  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd50eb  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd50f4  add rsp, 0xF0
00007f4f7cbd50fb  pop r11
00007f4f7cbd50fd  pop r10
00007f4f7cbd50ff  pop r9
00007f4f7cbd5101  pop r8
00007f4f7cbd5103  pop rsi
00007f4f7cbd5104  pop rdi
00007f4f7cbd5105  pop rdx
00007f4f7cbd5106  pop rcx
00007f4f7cbd5107  pop rax
00007f4f7cbd5108  add rsp, 0x08
00007f4f7cbd510c  jmp 0x00007F4F7CBD2FA4
00007f4f7cbd5111  sub rsp, 0x08
00007f4f7cbd5115  push rax
00007f4f7cbd5116  push rcx
00007f4f7cbd5117  push rdx
00007f4f7cbd5118  push rdi
00007f4f7cbd5119  push rsi
00007f4f7cbd511a  push r8
00007f4f7cbd511c  push r9
00007f4f7cbd511e  push r10
00007f4f7cbd5120  push r11
00007f4f7cbd5122  sub rsp, 0xF0
00007f4f7cbd5129  vmovaps [rsp], xmm0
00007f4f7cbd512e  vmovaps [rsp+0x10], xmm1
00007f4f7cbd5134  vmovaps [rsp+0x20], xmm2
00007f4f7cbd513a  vmovaps [rsp+0x30], xmm3
00007f4f7cbd5140  vmovaps [rsp+0x40], xmm4
00007f4f7cbd5146  vmovaps [rsp+0x50], xmm5
00007f4f7cbd514c  vmovaps [rsp+0x60], xmm6
00007f4f7cbd5152  vmovaps [rsp+0x70], xmm7
00007f4f7cbd5158  vmovaps [rsp+0x80], xmm8
00007f4f7cbd5161  vmovaps [rsp+0x90], xmm9
00007f4f7cbd516a  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd5173  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd517c  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd5185  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd518e  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd5197  sub rsp, 0x40
00007f4f7cbd519b  lea rdi, [rsp]
00007f4f7cbd519f  lea rsi, [rsp+0x10]
00007f4f7cbd51a4  lea rdx, [rsp+0x20]
00007f4f7cbd51a9  lea rcx, [rsp+0x30]
00007f4f7cbd51ae  mov r8d, 0x00
00007f4f7cbd51b4  lea r9, [r15+0x3A8]
00007f4f7cbd51bb  movaps [rdi], xmm10
00007f4f7cbd51bf  movaps [rsi], xmm9
00007f4f7cbd51c3  movaps [rdx], xmm13
00007f4f7cbd51c7  movaps [rcx], xmm15
00007f4f7cbd51cb  mov rax, 0x643999485A50
00007f4f7cbd51d5  call rax
00007f4f7cbd51d7  movaps xmm10, [rsp]
00007f4f7cbd51dc  add rsp, 0x40
00007f4f7cbd51e0  vmovaps xmm0, [rsp]
00007f4f7cbd51e5  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd51eb  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd51f1  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd51f7  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd51fd  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd5203  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd5209  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd520f  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd5218  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd5221  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd522a  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd5233  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd523c  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd5245  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd524e  add rsp, 0xF0
00007f4f7cbd5255  pop r11
00007f4f7cbd5257  pop r10
00007f4f7cbd5259  pop r9
00007f4f7cbd525b  pop r8
00007f4f7cbd525d  pop rsi
00007f4f7cbd525e  pop rdi
00007f4f7cbd525f  pop rdx
00007f4f7cbd5260  pop rcx
00007f4f7cbd5261  pop rax
00007f4f7cbd5262  add rsp, 0x08
00007f4f7cbd5266  jmp 0x00007F4F7CBD2FCD
00007f4f7cbd526b  sub rsp, 0x08
00007f4f7cbd526f  push rax
00007f4f7cbd5270  push rcx
00007f4f7cbd5271  push rdx
00007f4f7cbd5272  push rdi
00007f4f7cbd5273  push rsi
00007f4f7cbd5274  push r8
00007f4f7cbd5276  push r9
00007f4f7cbd5278  push r10
00007f4f7cbd527a  push r11
00007f4f7cbd527c  sub rsp, 0xF0
00007f4f7cbd5283  vmovaps [rsp], xmm0
00007f4f7cbd5288  vmovaps [rsp+0x10], xmm1
00007f4f7cbd528e  vmovaps [rsp+0x20], xmm2
00007f4f7cbd5294  vmovaps [rsp+0x30], xmm3
00007f4f7cbd529a  vmovaps [rsp+0x40], xmm4
00007f4f7cbd52a0  vmovaps [rsp+0x50], xmm5
00007f4f7cbd52a6  vmovaps [rsp+0x60], xmm6
00007f4f7cbd52ac  vmovaps [rsp+0x70], xmm7
00007f4f7cbd52b2  vmovaps [rsp+0x80], xmm8
00007f4f7cbd52bb  vmovaps [rsp+0x90], xmm9
00007f4f7cbd52c4  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd52cd  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd52d6  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd52df  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd52e8  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd52f1  sub rsp, 0x40
00007f4f7cbd52f5  lea rdi, [rsp]
00007f4f7cbd52f9  lea rsi, [rsp+0x10]
00007f4f7cbd52fe  lea rdx, [rsp+0x20]
00007f4f7cbd5303  lea rcx, [rsp+0x30]
00007f4f7cbd5308  mov r8d, 0x00
00007f4f7cbd530e  lea r9, [r15+0x3A8]
00007f4f7cbd5315  movaps [rdi], xmm13
00007f4f7cbd5319  movaps [rsi], xmm12
00007f4f7cbd531d  movaps [rdx], xmm4
00007f4f7cbd5320  movaps [rcx], xmm15
00007f4f7cbd5324  mov rax, 0x643999485A50
00007f4f7cbd532e  call rax
00007f4f7cbd5330  movaps xmm13, [rsp]
00007f4f7cbd5335  add rsp, 0x40
00007f4f7cbd5339  vmovaps xmm0, [rsp]
00007f4f7cbd533e  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd5344  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd534a  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd5350  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd5356  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd535c  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd5362  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd5368  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd5371  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd537a  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd5383  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd538c  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd5395  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd539e  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd53a7  add rsp, 0xF0
00007f4f7cbd53ae  pop r11
00007f4f7cbd53b0  pop r10
00007f4f7cbd53b2  pop r9
00007f4f7cbd53b4  pop r8
00007f4f7cbd53b6  pop rsi
00007f4f7cbd53b7  pop rdi
00007f4f7cbd53b8  pop rdx
00007f4f7cbd53b9  pop rcx
00007f4f7cbd53ba  pop rax
00007f4f7cbd53bb  add rsp, 0x08
00007f4f7cbd53bf  jmp 0x00007F4F7CBD2FF6
00007f4f7cbd53c4  sub rsp, 0x08
00007f4f7cbd53c8  push rax
00007f4f7cbd53c9  push rcx
00007f4f7cbd53ca  push rdx
00007f4f7cbd53cb  push rdi
00007f4f7cbd53cc  push rsi
00007f4f7cbd53cd  push r8
00007f4f7cbd53cf  push r9
00007f4f7cbd53d1  push r10
00007f4f7cbd53d3  push r11
00007f4f7cbd53d5  sub rsp, 0xF0
00007f4f7cbd53dc  vmovaps [rsp], xmm0
00007f4f7cbd53e1  vmovaps [rsp+0x10], xmm1
00007f4f7cbd53e7  vmovaps [rsp+0x20], xmm2
00007f4f7cbd53ed  vmovaps [rsp+0x30], xmm3
00007f4f7cbd53f3  vmovaps [rsp+0x40], xmm4
00007f4f7cbd53f9  vmovaps [rsp+0x50], xmm5
00007f4f7cbd53ff  vmovaps [rsp+0x60], xmm6
00007f4f7cbd5405  vmovaps [rsp+0x70], xmm7
00007f4f7cbd540b  vmovaps [rsp+0x80], xmm8
00007f4f7cbd5414  vmovaps [rsp+0x90], xmm9
00007f4f7cbd541d  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd5426  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd542f  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd5438  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd5441  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd544a  sub rsp, 0x40
00007f4f7cbd544e  lea rdi, [rsp]
00007f4f7cbd5452  lea rsi, [rsp+0x10]
00007f4f7cbd5457  lea rdx, [rsp+0x20]
00007f4f7cbd545c  lea rcx, [rsp+0x30]
00007f4f7cbd5461  mov r8d, 0x00
00007f4f7cbd5467  lea r9, [r15+0x3A8]
00007f4f7cbd546e  movaps [rdi], xmm12
00007f4f7cbd5472  movaps [rsi], xmm7
00007f4f7cbd5475  movaps [rdx], xmm1
00007f4f7cbd5478  movaps [rcx], xmm15
00007f4f7cbd547c  mov rax, 0x643999485A50
00007f4f7cbd5486  call rax
00007f4f7cbd5488  movaps xmm12, [rsp]
00007f4f7cbd548d  add rsp, 0x40
00007f4f7cbd5491  vmovaps xmm0, [rsp]
00007f4f7cbd5496  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd549c  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd54a2  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd54a8  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd54ae  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd54b4  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd54ba  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd54c0  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd54c9  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd54d2  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd54db  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd54e4  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd54ed  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd54f6  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd54ff  add rsp, 0xF0
00007f4f7cbd5506  pop r11
00007f4f7cbd5508  pop r10
00007f4f7cbd550a  pop r9
00007f4f7cbd550c  pop r8
00007f4f7cbd550e  pop rsi
00007f4f7cbd550f  pop rdi
00007f4f7cbd5510  pop rdx
00007f4f7cbd5511  pop rcx
00007f4f7cbd5512  pop rax
00007f4f7cbd5513  add rsp, 0x08
00007f4f7cbd5517  jmp 0x00007F4F7CBD301F
00007f4f7cbd551c  call 0x00007F4F7C9FF430
00007f4f7cbd5521  jmp 0x00007F4F7CBD3029
00007f4f7cbd5526  call 0x00007F4F7CA0E760
00007f4f7cbd552b  jmp 0x00007F4F7CBD3033
00007f4f7cbd5530  sub rsp, 0x08
00007f4f7cbd5534  push rax
00007f4f7cbd5535  push rcx
00007f4f7cbd5536  push rdx
00007f4f7cbd5537  push rdi
00007f4f7cbd5538  push rsi
00007f4f7cbd5539  push r8
00007f4f7cbd553b  push r9
00007f4f7cbd553d  push r10
00007f4f7cbd553f  push r11
00007f4f7cbd5541  sub rsp, 0xF0
00007f4f7cbd5548  vmovaps [rsp], xmm0
00007f4f7cbd554d  vmovaps [rsp+0x10], xmm1
00007f4f7cbd5553  vmovaps [rsp+0x20], xmm2
00007f4f7cbd5559  vmovaps [rsp+0x30], xmm3
00007f4f7cbd555f  vmovaps [rsp+0x40], xmm4
00007f4f7cbd5565  vmovaps [rsp+0x50], xmm5
00007f4f7cbd556b  vmovaps [rsp+0x60], xmm6
00007f4f7cbd5571  vmovaps [rsp+0x70], xmm8
00007f4f7cbd5577  vmovaps [rsp+0x80], xmm9
00007f4f7cbd5580  vmovaps [rsp+0x90], xmm10
00007f4f7cbd5589  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd5592  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd559b  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd55a4  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd55ad  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd55b6  sub rsp, 0x40
00007f4f7cbd55ba  lea rdi, [rsp]
00007f4f7cbd55be  lea rsi, [rsp+0x10]
00007f4f7cbd55c3  lea rdx, [rsp+0x20]
00007f4f7cbd55c8  lea rcx, [rsp+0x30]
00007f4f7cbd55cd  mov r8d, 0x00
00007f4f7cbd55d3  lea r9, [r15+0x3A8]
00007f4f7cbd55da  movaps [rdi], xmm7
00007f4f7cbd55dd  movaps [rsi], xmm6
00007f4f7cbd55e0  movaps [rdx], xmm8
00007f4f7cbd55e4  movaps [rcx], xmm9
00007f4f7cbd55e8  mov rax, 0x643999485A50
00007f4f7cbd55f2  call rax
00007f4f7cbd55f4  movaps xmm7, [rsp]
00007f4f7cbd55f8  add rsp, 0x40
00007f4f7cbd55fc  vmovaps xmm0, [rsp]
00007f4f7cbd5601  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd5607  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd560d  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd5613  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd5619  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd561f  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd5625  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd562b  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd5634  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd563d  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd5646  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd564f  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd5658  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd5661  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd566a  add rsp, 0xF0
00007f4f7cbd5671  pop r11
00007f4f7cbd5673  pop r10
00007f4f7cbd5675  pop r9
00007f4f7cbd5677  pop r8
00007f4f7cbd5679  pop rsi
00007f4f7cbd567a  pop rdi
00007f4f7cbd567b  pop rdx
00007f4f7cbd567c  pop rcx
00007f4f7cbd567d  pop rax
00007f4f7cbd567e  add rsp, 0x08
00007f4f7cbd5682  jmp 0x00007F4F7CBD305D
00007f4f7cbd5687  sub rsp, 0x08
00007f4f7cbd568b  push rax
00007f4f7cbd568c  push rcx
00007f4f7cbd568d  push rdx
00007f4f7cbd568e  push rdi
00007f4f7cbd568f  push rsi
00007f4f7cbd5690  push r8
00007f4f7cbd5692  push r9
00007f4f7cbd5694  push r10
00007f4f7cbd5696  push r11
00007f4f7cbd5698  sub rsp, 0xF0
00007f4f7cbd569f  vmovaps [rsp], xmm0
00007f4f7cbd56a4  vmovaps [rsp+0x10], xmm1
00007f4f7cbd56aa  vmovaps [rsp+0x20], xmm2
00007f4f7cbd56b0  vmovaps [rsp+0x30], xmm3
00007f4f7cbd56b6  vmovaps [rsp+0x40], xmm4
00007f4f7cbd56bc  vmovaps [rsp+0x50], xmm5
00007f4f7cbd56c2  vmovaps [rsp+0x60], xmm6
00007f4f7cbd56c8  vmovaps [rsp+0x70], xmm7
00007f4f7cbd56ce  vmovaps [rsp+0x80], xmm9
00007f4f7cbd56d7  vmovaps [rsp+0x90], xmm10
00007f4f7cbd56e0  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd56e9  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd56f2  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd56fb  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd5704  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd570d  sub rsp, 0x40
00007f4f7cbd5711  lea rdi, [rsp]
00007f4f7cbd5715  lea rsi, [rsp+0x10]
00007f4f7cbd571a  lea rdx, [rsp+0x20]
00007f4f7cbd571f  lea rcx, [rsp+0x30]
00007f4f7cbd5724  mov r8d, 0x00
00007f4f7cbd572a  lea r9, [r15+0x3A8]
00007f4f7cbd5731  movaps [rdi], xmm8
00007f4f7cbd5735  movaps [rsi], xmm10
00007f4f7cbd5739  movaps [rdx], xmm14
00007f4f7cbd573d  movaps [rcx], xmm9
00007f4f7cbd5741  mov rax, 0x643999485A50
00007f4f7cbd574b  call rax
00007f4f7cbd574d  movaps xmm8, [rsp]
00007f4f7cbd5752  add rsp, 0x40
00007f4f7cbd5756  vmovaps xmm0, [rsp]
00007f4f7cbd575b  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd5761  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd5767  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd576d  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd5773  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd5779  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd577f  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd5785  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd578e  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd5797  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd57a0  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd57a9  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd57b2  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd57bb  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd57c4  add rsp, 0xF0
00007f4f7cbd57cb  pop r11
00007f4f7cbd57cd  pop r10
00007f4f7cbd57cf  pop r9
00007f4f7cbd57d1  pop r8
00007f4f7cbd57d3  pop rsi
00007f4f7cbd57d4  pop rdi
00007f4f7cbd57d5  pop rdx
00007f4f7cbd57d6  pop rcx
00007f4f7cbd57d7  pop rax
00007f4f7cbd57d8  add rsp, 0x08
00007f4f7cbd57dc  jmp 0x00007F4F7CBD3083
00007f4f7cbd57e1  sub rsp, 0x08
00007f4f7cbd57e5  push rax
00007f4f7cbd57e6  push rcx
00007f4f7cbd57e7  push rdx
00007f4f7cbd57e8  push rdi
00007f4f7cbd57e9  push rsi
00007f4f7cbd57ea  push r8
00007f4f7cbd57ec  push r9
00007f4f7cbd57ee  push r10
00007f4f7cbd57f0  push r11
00007f4f7cbd57f2  sub rsp, 0xF0
00007f4f7cbd57f9  vmovaps [rsp], xmm0
00007f4f7cbd57fe  vmovaps [rsp+0x10], xmm1
00007f4f7cbd5804  vmovaps [rsp+0x20], xmm2
00007f4f7cbd580a  vmovaps [rsp+0x30], xmm3
00007f4f7cbd5810  vmovaps [rsp+0x40], xmm4
00007f4f7cbd5816  vmovaps [rsp+0x50], xmm5
00007f4f7cbd581c  vmovaps [rsp+0x60], xmm6
00007f4f7cbd5822  vmovaps [rsp+0x70], xmm7
00007f4f7cbd5828  vmovaps [rsp+0x80], xmm8
00007f4f7cbd5831  vmovaps [rsp+0x90], xmm9
00007f4f7cbd583a  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd5843  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd584c  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd5855  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd585e  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd5867  sub rsp, 0x40
00007f4f7cbd586b  lea rdi, [rsp]
00007f4f7cbd586f  lea rsi, [rsp+0x10]
00007f4f7cbd5874  lea rdx, [rsp+0x20]
00007f4f7cbd5879  lea rcx, [rsp+0x30]
00007f4f7cbd587e  mov r8d, 0x00
00007f4f7cbd5884  lea r9, [r15+0x3A8]
00007f4f7cbd588b  movaps [rdi], xmm10
00007f4f7cbd588f  movaps [rsi], xmm13
00007f4f7cbd5893  movaps [rdx], xmm11
00007f4f7cbd5897  movaps [rcx], xmm14
00007f4f7cbd589b  mov rax, 0x643999485A50
00007f4f7cbd58a5  call rax
00007f4f7cbd58a7  movaps xmm10, [rsp]
00007f4f7cbd58ac  add rsp, 0x40
00007f4f7cbd58b0  vmovaps xmm0, [rsp]
00007f4f7cbd58b5  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd58bb  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd58c1  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd58c7  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd58cd  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd58d3  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd58d9  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd58df  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd58e8  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd58f1  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd58fa  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd5903  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd590c  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd5915  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd591e  add rsp, 0xF0
00007f4f7cbd5925  pop r11
00007f4f7cbd5927  pop r10
00007f4f7cbd5929  pop r9
00007f4f7cbd592b  pop r8
00007f4f7cbd592d  pop rsi
00007f4f7cbd592e  pop rdi
00007f4f7cbd592f  pop rdx
00007f4f7cbd5930  pop rcx
00007f4f7cbd5931  pop rax
00007f4f7cbd5932  add rsp, 0x08
00007f4f7cbd5936  jmp 0x00007F4F7CBD30A9
00007f4f7cbd593b  sub rsp, 0x08
00007f4f7cbd593f  push rax
00007f4f7cbd5940  push rcx
00007f4f7cbd5941  push rdx
00007f4f7cbd5942  push rdi
00007f4f7cbd5943  push rsi
00007f4f7cbd5944  push r8
00007f4f7cbd5946  push r9
00007f4f7cbd5948  push r10
00007f4f7cbd594a  push r11
00007f4f7cbd594c  sub rsp, 0xF0
00007f4f7cbd5953  vmovaps [rsp], xmm0
00007f4f7cbd5958  vmovaps [rsp+0x10], xmm1
00007f4f7cbd595e  vmovaps [rsp+0x20], xmm2
00007f4f7cbd5964  vmovaps [rsp+0x30], xmm3
00007f4f7cbd596a  vmovaps [rsp+0x40], xmm4
00007f4f7cbd5970  vmovaps [rsp+0x50], xmm5
00007f4f7cbd5976  vmovaps [rsp+0x60], xmm6
00007f4f7cbd597c  vmovaps [rsp+0x70], xmm7
00007f4f7cbd5982  vmovaps [rsp+0x80], xmm8
00007f4f7cbd598b  vmovaps [rsp+0x90], xmm9
00007f4f7cbd5994  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd599d  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd59a6  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd59af  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd59b8  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd59c1  sub rsp, 0x40
00007f4f7cbd59c5  lea rdi, [rsp]
00007f4f7cbd59c9  lea rsi, [rsp+0x10]
00007f4f7cbd59ce  lea rdx, [rsp+0x20]
00007f4f7cbd59d3  lea rcx, [rsp+0x30]
00007f4f7cbd59d8  mov r8d, 0x00
00007f4f7cbd59de  lea r9, [r15+0x3A8]
00007f4f7cbd59e5  movaps [rdi], xmm13
00007f4f7cbd59e9  movaps [rsi], xmm12
00007f4f7cbd59ed  movaps [rdx], xmm15
00007f4f7cbd59f1  movaps [rcx], xmm14
00007f4f7cbd59f5  mov rax, 0x643999485A50
00007f4f7cbd59ff  call rax
00007f4f7cbd5a01  movaps xmm13, [rsp]
00007f4f7cbd5a06  add rsp, 0x40
00007f4f7cbd5a0a  vmovaps xmm0, [rsp]
00007f4f7cbd5a0f  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd5a15  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd5a1b  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd5a21  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd5a27  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd5a2d  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd5a33  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd5a39  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd5a42  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd5a4b  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd5a54  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd5a5d  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd5a66  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd5a6f  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd5a78  add rsp, 0xF0
00007f4f7cbd5a7f  pop r11
00007f4f7cbd5a81  pop r10
00007f4f7cbd5a83  pop r9
00007f4f7cbd5a85  pop r8
00007f4f7cbd5a87  pop rsi
00007f4f7cbd5a88  pop rdi
00007f4f7cbd5a89  pop rdx
00007f4f7cbd5a8a  pop rcx
00007f4f7cbd5a8b  pop rax
00007f4f7cbd5a8c  add rsp, 0x08
00007f4f7cbd5a90  jmp 0x00007F4F7CBD30CF
00007f4f7cbd5a95  call 0x00007F4F7CA0E760
00007f4f7cbd5a9a  jmp 0x00007F4F7CBD30DC
00007f4f7cbd5a9f  call 0x00007F4F7CA0D4E0
00007f4f7cbd5aa4  jmp 0x00007F4F7CBD30E9
00007f4f7cbd5aa9  sub rsp, 0x08
00007f4f7cbd5aad  push rax
00007f4f7cbd5aae  push rcx
00007f4f7cbd5aaf  push rdx
00007f4f7cbd5ab0  push rdi
00007f4f7cbd5ab1  push rsi
00007f4f7cbd5ab2  push r8
00007f4f7cbd5ab4  push r9
00007f4f7cbd5ab6  push r10
00007f4f7cbd5ab8  push r11
00007f4f7cbd5aba  sub rsp, 0xF0
00007f4f7cbd5ac1  vmovaps [rsp], xmm0
00007f4f7cbd5ac6  vmovaps [rsp+0x10], xmm1
00007f4f7cbd5acc  vmovaps [rsp+0x20], xmm2
00007f4f7cbd5ad2  vmovaps [rsp+0x30], xmm3
00007f4f7cbd5ad8  vmovaps [rsp+0x40], xmm4
00007f4f7cbd5ade  vmovaps [rsp+0x50], xmm5
00007f4f7cbd5ae4  vmovaps [rsp+0x60], xmm6
00007f4f7cbd5aea  vmovaps [rsp+0x70], xmm7
00007f4f7cbd5af0  vmovaps [rsp+0x80], xmm8
00007f4f7cbd5af9  vmovaps [rsp+0x90], xmm9
00007f4f7cbd5b02  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd5b0b  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd5b14  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd5b1d  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd5b26  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd5b2f  sub rsp, 0x40
00007f4f7cbd5b33  lea rdi, [rsp]
00007f4f7cbd5b37  lea rsi, [rsp+0x10]
00007f4f7cbd5b3c  lea rdx, [rsp+0x20]
00007f4f7cbd5b41  lea rcx, [rsp+0x30]
00007f4f7cbd5b46  mov r8d, 0x00
00007f4f7cbd5b4c  lea r9, [r15+0x3A8]
00007f4f7cbd5b53  movaps [rdi], xmm11
00007f4f7cbd5b57  movaps [rsi], xmm7
00007f4f7cbd5b5a  movaps [rdx], xmm1
00007f4f7cbd5b5d  movaps [rcx], xmm12
00007f4f7cbd5b61  mov rax, 0x643999485A50
00007f4f7cbd5b6b  call rax
00007f4f7cbd5b6d  movaps xmm11, [rsp]
00007f4f7cbd5b72  add rsp, 0x40
00007f4f7cbd5b76  vmovaps xmm0, [rsp]
00007f4f7cbd5b7b  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd5b81  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd5b87  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd5b8d  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd5b93  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd5b99  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd5b9f  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd5ba5  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd5bae  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd5bb7  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd5bc0  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd5bc9  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd5bd2  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd5bdb  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd5be4  add rsp, 0xF0
00007f4f7cbd5beb  pop r11
00007f4f7cbd5bed  pop r10
00007f4f7cbd5bef  pop r9
00007f4f7cbd5bf1  pop r8
00007f4f7cbd5bf3  pop rsi
00007f4f7cbd5bf4  pop rdi
00007f4f7cbd5bf5  pop rdx
00007f4f7cbd5bf6  pop rcx
00007f4f7cbd5bf7  pop rax
00007f4f7cbd5bf8  add rsp, 0x08
00007f4f7cbd5bfc  jmp 0x00007F4F7CBD3122
00007f4f7cbd5c01  call 0x00007F4F7C9FF430
00007f4f7cbd5c06  jmp 0x00007F4F7CBD3134
00007f4f7cbd5c0b  sub rsp, 0x08
00007f4f7cbd5c0f  push rax
00007f4f7cbd5c10  push rcx
00007f4f7cbd5c11  push rdx
00007f4f7cbd5c12  push rdi
00007f4f7cbd5c13  push rsi
00007f4f7cbd5c14  push r8
00007f4f7cbd5c16  push r9
00007f4f7cbd5c18  push r10
00007f4f7cbd5c1a  push r11
00007f4f7cbd5c1c  sub rsp, 0xF0
00007f4f7cbd5c23  vmovaps [rsp], xmm0
00007f4f7cbd5c28  vmovaps [rsp+0x10], xmm1
00007f4f7cbd5c2e  vmovaps [rsp+0x20], xmm2
00007f4f7cbd5c34  vmovaps [rsp+0x30], xmm3
00007f4f7cbd5c3a  vmovaps [rsp+0x40], xmm4
00007f4f7cbd5c40  vmovaps [rsp+0x50], xmm5
00007f4f7cbd5c46  vmovaps [rsp+0x60], xmm6
00007f4f7cbd5c4c  vmovaps [rsp+0x70], xmm7
00007f4f7cbd5c52  vmovaps [rsp+0x80], xmm8
00007f4f7cbd5c5b  vmovaps [rsp+0x90], xmm10
00007f4f7cbd5c64  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd5c6d  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd5c76  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd5c7f  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd5c88  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd5c91  sub rsp, 0x40
00007f4f7cbd5c95  lea rdi, [rsp]
00007f4f7cbd5c99  lea rsi, [rsp+0x10]
00007f4f7cbd5c9e  lea rdx, [rsp+0x20]
00007f4f7cbd5ca3  lea rcx, [rsp+0x30]
00007f4f7cbd5ca8  mov r8d, 0x00
00007f4f7cbd5cae  lea r9, [r15+0x3A8]
00007f4f7cbd5cb5  movaps [rdi], xmm9
00007f4f7cbd5cb9  movaps [rsi], xmm8
00007f4f7cbd5cbd  movaps [rdx], xmm14
00007f4f7cbd5cc1  movaps [rcx], xmm12
00007f4f7cbd5cc5  mov rax, 0x643999485A50
00007f4f7cbd5ccf  call rax
00007f4f7cbd5cd1  movaps xmm9, [rsp]
00007f4f7cbd5cd6  add rsp, 0x40
00007f4f7cbd5cda  vmovaps xmm0, [rsp]
00007f4f7cbd5cdf  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd5ce5  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd5ceb  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd5cf1  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd5cf7  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd5cfd  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd5d03  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd5d09  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd5d12  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd5d1b  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd5d24  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd5d2d  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd5d36  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd5d3f  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd5d48  add rsp, 0xF0
00007f4f7cbd5d4f  pop r11
00007f4f7cbd5d51  pop r10
00007f4f7cbd5d53  pop r9
00007f4f7cbd5d55  pop r8
00007f4f7cbd5d57  pop rsi
00007f4f7cbd5d58  pop rdi
00007f4f7cbd5d59  pop rdx
00007f4f7cbd5d5a  pop rcx
00007f4f7cbd5d5b  pop rax
00007f4f7cbd5d5c  add rsp, 0x08
00007f4f7cbd5d60  jmp 0x00007F4F7CBD3165
00007f4f7cbd5d65  sub rsp, 0x08
00007f4f7cbd5d69  push rax
00007f4f7cbd5d6a  push rcx
00007f4f7cbd5d6b  push rdx
00007f4f7cbd5d6c  push rdi
00007f4f7cbd5d6d  push rsi
00007f4f7cbd5d6e  push r8
00007f4f7cbd5d70  push r9
00007f4f7cbd5d72  push r10
00007f4f7cbd5d74  push r11
00007f4f7cbd5d76  sub rsp, 0xF0
00007f4f7cbd5d7d  vmovaps [rsp], xmm0
00007f4f7cbd5d82  vmovaps [rsp+0x10], xmm1
00007f4f7cbd5d88  vmovaps [rsp+0x20], xmm2
00007f4f7cbd5d8e  vmovaps [rsp+0x30], xmm3
00007f4f7cbd5d94  vmovaps [rsp+0x40], xmm4
00007f4f7cbd5d9a  vmovaps [rsp+0x50], xmm5
00007f4f7cbd5da0  vmovaps [rsp+0x60], xmm6
00007f4f7cbd5da6  vmovaps [rsp+0x70], xmm7
00007f4f7cbd5dac  vmovaps [rsp+0x80], xmm8
00007f4f7cbd5db5  vmovaps [rsp+0x90], xmm9
00007f4f7cbd5dbe  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd5dc7  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd5dd0  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd5dd9  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd5de2  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd5deb  sub rsp, 0x40
00007f4f7cbd5def  lea rdi, [rsp]
00007f4f7cbd5df3  lea rsi, [rsp+0x10]
00007f4f7cbd5df8  lea rdx, [rsp+0x20]
00007f4f7cbd5dfd  lea rcx, [rsp+0x30]
00007f4f7cbd5e02  mov r8d, 0x00
00007f4f7cbd5e08  lea r9, [r15+0x3A8]
00007f4f7cbd5e0f  movaps [rdi], xmm12
00007f4f7cbd5e13  movaps [rsi], xmm10
00007f4f7cbd5e17  movaps [rdx], xmm15
00007f4f7cbd5e1b  movaps [rcx], xmm14
00007f4f7cbd5e1f  mov rax, 0x643999485A50
00007f4f7cbd5e29  call rax
00007f4f7cbd5e2b  movaps xmm12, [rsp]
00007f4f7cbd5e30  add rsp, 0x40
00007f4f7cbd5e34  vmovaps xmm0, [rsp]
00007f4f7cbd5e39  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd5e3f  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd5e45  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd5e4b  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd5e51  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd5e57  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd5e5d  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd5e63  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd5e6c  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd5e75  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd5e7e  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd5e87  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd5e90  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd5e99  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd5ea2  add rsp, 0xF0
00007f4f7cbd5ea9  pop r11
00007f4f7cbd5eab  pop r10
00007f4f7cbd5ead  pop r9
00007f4f7cbd5eaf  pop r8
00007f4f7cbd5eb1  pop rsi
00007f4f7cbd5eb2  pop rdi
00007f4f7cbd5eb3  pop rdx
00007f4f7cbd5eb4  pop rcx
00007f4f7cbd5eb5  pop rax
00007f4f7cbd5eb6  add rsp, 0x08
00007f4f7cbd5eba  jmp 0x00007F4F7CBD3196
00007f4f7cbd5ebf  sub rsp, 0x08
00007f4f7cbd5ec3  push rax
00007f4f7cbd5ec4  push rcx
00007f4f7cbd5ec5  push rdx
00007f4f7cbd5ec6  push rdi
00007f4f7cbd5ec7  push rsi
00007f4f7cbd5ec8  push r8
00007f4f7cbd5eca  push r9
00007f4f7cbd5ecc  push r10
00007f4f7cbd5ece  push r11
00007f4f7cbd5ed0  sub rsp, 0xF0
00007f4f7cbd5ed7  vmovaps [rsp], xmm0
00007f4f7cbd5edc  vmovaps [rsp+0x10], xmm1
00007f4f7cbd5ee2  vmovaps [rsp+0x20], xmm2
00007f4f7cbd5ee8  vmovaps [rsp+0x30], xmm3
00007f4f7cbd5eee  vmovaps [rsp+0x40], xmm4
00007f4f7cbd5ef4  vmovaps [rsp+0x50], xmm5
00007f4f7cbd5efa  vmovaps [rsp+0x60], xmm6
00007f4f7cbd5f00  vmovaps [rsp+0x70], xmm7
00007f4f7cbd5f06  vmovaps [rsp+0x80], xmm8
00007f4f7cbd5f0f  vmovaps [rsp+0x90], xmm9
00007f4f7cbd5f18  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd5f21  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd5f2a  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd5f33  vmovaps [rsp+0xD0], xmm13
00007f4f7cbd5f3c  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd5f45  sub rsp, 0x40
00007f4f7cbd5f49  lea rdi, [rsp]
00007f4f7cbd5f4d  lea rsi, [rsp+0x10]
00007f4f7cbd5f52  lea rdx, [rsp+0x20]
00007f4f7cbd5f57  lea rcx, [rsp+0x30]
00007f4f7cbd5f5c  mov r8d, 0x00
00007f4f7cbd5f62  lea r9, [r15+0x3A8]
00007f4f7cbd5f69  movaps [rdi], xmm14
00007f4f7cbd5f6d  movaps [rsi], xmm13
00007f4f7cbd5f71  movaps [rdx], xmm1
00007f4f7cbd5f74  movaps [rcx], xmm15
00007f4f7cbd5f78  mov rax, 0x643999485A50
00007f4f7cbd5f82  call rax
00007f4f7cbd5f84  movaps xmm14, [rsp]
00007f4f7cbd5f89  add rsp, 0x40
00007f4f7cbd5f8d  vmovaps xmm0, [rsp]
00007f4f7cbd5f92  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd5f98  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd5f9e  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd5fa4  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd5faa  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd5fb0  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd5fb6  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd5fbc  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd5fc5  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd5fce  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd5fd7  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd5fe0  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd5fe9  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbd5ff2  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd5ffb  add rsp, 0xF0
00007f4f7cbd6002  pop r11
00007f4f7cbd6004  pop r10
00007f4f7cbd6006  pop r9
00007f4f7cbd6008  pop r8
00007f4f7cbd600a  pop rsi
00007f4f7cbd600b  pop rdi
00007f4f7cbd600c  pop rdx
00007f4f7cbd600d  pop rcx
00007f4f7cbd600e  pop rax
00007f4f7cbd600f  add rsp, 0x08
00007f4f7cbd6013  jmp 0x00007F4F7CBD31C7
00007f4f7cbd6018  call 0x00007F4F7CA079B0
00007f4f7cbd601d  jmp 0x00007F4F7CBD31DA
00007f4f7cbd6022  call 0x00007F4F7CA0B100
00007f4f7cbd6027  jmp 0x00007F4F7CBD31E5
00007f4f7cbd602c  call 0x00007F4F7CA09E90
00007f4f7cbd6031  jmp 0x00007F4F7CBD31F0
00007f4f7cbd6036  call 0x00007F4F7CA0D600
00007f4f7cbd603b  jmp 0x00007F4F7CBD31FB
00007f4f7cbd6040  int3
00007f4f7cbd6041  nop [rax+rax*1], ax
00007f4f7cbd604a  nop [rax+rax*1], ax
00007f4f7cbd6050  mov rax, [r15+0x40]
00007f4f7cbd6054  mov r14, [r15+0x58]
00007f4f7cbd6058  lea r12, [rax+r14*1]
00007f4f7cbd605c  vxorps xmm1, xmm1, xmm1
00007f4f7cbd6060  vpbroadcastq xmm1, xmm1
00007f4f7cbd6065  vxorps xmm15, xmm15, xmm15
00007f4f7cbd606a  vpbroadcastq xmm15, xmm15
00007f4f7cbd606f  lea rax, [r12+0x30]
00007f4f7cbd6074  mov r11, [r13+rax*1]
00007f4f7cbd6079  lea rax, [r12+0x38]
00007f4f7cbd607e  mov r10, [r13+rax*1]
00007f4f7cbd6083  movq xmm14, r11
00007f4f7cbd6088  movq xmm13, r10
00007f4f7cbd608d  movq xmm14, xmm14
00007f4f7cbd6092  movq xmm13, xmm13
00007f4f7cbd6097  vmovaps [rsp+0x10], xmm13
00007f4f7cbd609d  movq xmm13, xmm13
00007f4f7cbd60a2  movaps [r15+0x270], xmm13
00007f4f7cbd60aa  movaps xmm13, [r15+0x160]
00007f4f7cbd60b2  vmovaps [rsp+0x20], xmm13
00007f4f7cbd60b8  vmovaps xmm12, [rsp+0x20]
00007f4f7cbd60be  por xmm13, xmm12
00007f4f7cbd60c3  lea rax, [r12+0x20]
00007f4f7cbd60c8  mov r11, [r13+rax*1]
00007f4f7cbd60cd  lea rax, [r12+0x28]
00007f4f7cbd60d2  mov r10, [r13+rax*1]
00007f4f7cbd60d7  movq xmm12, r11
00007f4f7cbd60dc  movq xmm11, r10
00007f4f7cbd60e1  movq xmm12, xmm12
00007f4f7cbd60e6  movq xmm11, xmm11
00007f4f7cbd60eb  movaps xmm10, [r15+0x2D0]
00007f4f7cbd60f3  vmovaps [rsp+0x20], xmm10
00007f4f7cbd60f9  vmovaps xmm9, [rsp+0x20]
00007f4f7cbd60ff  por xmm10, xmm9
00007f4f7cbd6104  movaps xmm9, [r15+0x300]
00007f4f7cbd610c  vmovaps [rsp+0x20], xmm9
00007f4f7cbd6112  vmovaps xmm8, [rsp+0x20]
00007f4f7cbd6118  por xmm9, xmm8
00007f4f7cbd611d  movaps xmm8, [r15+0x2B0]
00007f4f7cbd6125  vmovaps [rsp+0x20], xmm8
00007f4f7cbd612b  vmovaps xmm7, [rsp+0x20]
00007f4f7cbd6131  por xmm8, xmm7
00007f4f7cbd6136  movaps xmm7, [r15+0x180]
00007f4f7cbd613e  vmovaps [rsp+0x20], xmm7
00007f4f7cbd6144  vmovaps xmm6, [rsp+0x20]
00007f4f7cbd614a  por xmm7, xmm6
00007f4f7cbd614e  lea rax, [r12+0x10]
00007f4f7cbd6153  mov r11, [r13+rax*1]
00007f4f7cbd6158  lea rax, [r12+0x18]
00007f4f7cbd615d  mov r10, [r13+rax*1]
00007f4f7cbd6162  movq xmm6, r11
00007f4f7cbd6167  movq xmm5, r10
00007f4f7cbd616c  movq xmm6, xmm6
00007f4f7cbd6170  movq xmm5, xmm5
00007f4f7cbd6174  movaps xmm4, [r15+0x200]
00007f4f7cbd617c  vmovaps [rsp+0x20], xmm4
00007f4f7cbd6182  vmovaps xmm3, [rsp+0x20]
00007f4f7cbd6188  por xmm4, xmm3
00007f4f7cbd618c  movaps xmm3, [r15+0x1F0]
00007f4f7cbd6194  vmovaps [rsp+0x20], xmm3
00007f4f7cbd619a  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd61a0  por xmm3, xmm2
00007f4f7cbd61a4  movaps xmm2, [r15+0x2E0]
00007f4f7cbd61ac  vmovaps [rsp+0x20], xmm2
00007f4f7cbd61b2  vmovaps [rsp+0x30], xmm1
00007f4f7cbd61b8  vmovaps xmm1, [rsp+0x20]
00007f4f7cbd61be  por xmm2, xmm1
00007f4f7cbd61c2  movaps xmm1, [r15+0x2A0]
00007f4f7cbd61ca  vmovaps [rsp+0x20], xmm1
00007f4f7cbd61d0  vmovaps [rsp+0x40], xmm15
00007f4f7cbd61d6  vmovaps xmm15, [rsp+0x20]
00007f4f7cbd61dc  por xmm1, xmm15
00007f4f7cbd61e1  movaps xmm15, [r15+0x280]
00007f4f7cbd61e9  vmovaps [rsp+0x20], xmm15
00007f4f7cbd61ef  vmovaps [rsp+0x50], xmm1
00007f4f7cbd61f5  vmovaps xmm1, [rsp+0x20]
00007f4f7cbd61fb  por xmm15, xmm1
00007f4f7cbd6200  movaps xmm1, [r15+0x1C0]
00007f4f7cbd6208  vmovaps [rsp+0x20], xmm1
00007f4f7cbd620e  vmovaps [rsp+0x60], xmm15
00007f4f7cbd6214  vmovaps xmm15, [rsp+0x20]
00007f4f7cbd621a  por xmm1, xmm15
00007f4f7cbd621f  movaps xmm15, [r15+0x210]
00007f4f7cbd6227  vmovaps [rsp+0x20], xmm15
00007f4f7cbd622d  vmovaps [rsp+0x70], xmm1
00007f4f7cbd6233  vmovaps xmm1, [rsp+0x20]
00007f4f7cbd6239  por xmm15, xmm1
00007f4f7cbd623e  mov rax, [r13+r12*1]
00007f4f7cbd6243  vmovq xmm1, rax
00007f4f7cbd6248  vpbroadcastq xmm1, xmm1
00007f4f7cbd624d  vmovaps [rsp+0x20], xmm1
00007f4f7cbd6253  vxorps xmm1, xmm1, xmm1
00007f4f7cbd6257  vpbroadcastq xmm1, xmm1
00007f4f7cbd625c  mov rax, [r15+0xF8]
00007f4f7cbd6263  vmovaps [rsp+0x80], xmm1
00007f4f7cbd626c  movups xmm1, [r13+rax*1]
00007f4f7cbd6272  vmovaps [rsp+0x90], xmm1
00007f4f7cbd627b  vxorps xmm1, xmm1, xmm1
00007f4f7cbd627f  vpbroadcastq xmm1, xmm1
00007f4f7cbd6284  lea r11, [r12+0x08]
00007f4f7cbd6289  mov r12, [r13+r11*1]
00007f4f7cbd628e  vmovaps [rsp+0xA0], xmm1
00007f4f7cbd6297  movq xmm1, r12
00007f4f7cbd629c  movaps [r15+0x240], xmm1
00007f4f7cbd62a4  mov r12, [r15+0x50]
00007f4f7cbd62a8  lea r11, [r12+r14*1]
00007f4f7cbd62ac  mov [r15+0x60], r11
00007f4f7cbd62b0  lea r12, [r14+0x40]
00007f4f7cbd62b4  mov [r15+0x58], r12
00007f4f7cbd62b8  vmovaps xmm1, [rsp+0x30]
00007f4f7cbd62be  vmovaps [rsp+0x30], xmm15
00007f4f7cbd62c4  vmovaps xmm15, [rsp+0x90]
00007f4f7cbd62cd  vmovaps [rsp+0x90], xmm14
00007f4f7cbd62d6  vmovaps xmm14, [rsp+0x20]
00007f4f7cbd62dc  vmovaps [rsp+0x20], xmm13
00007f4f7cbd62e2  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd62eb  movaps xmm13, xmm1
00007f4f7cbd62ef  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd62fa  vptest xmm12, xmm12
00007f4f7cbd62ff  jnz 0x00007F4F7CBD6D9C
00007f4f7cbd6305  movaps xmm1, [r15+0x250]
00007f4f7cbd630d  vmovaps xmm15, [rsp+0x40]
00007f4f7cbd6313  vmovaps [rsp+0x40], xmm13
00007f4f7cbd6319  movaps xmm12, xmm15
00007f4f7cbd631d  vfmadd231pd xmm12, xmm1, xmm14
00007f4f7cbd6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007f4f7cbd6328  vptest xmm13, xmm13
00007f4f7cbd632d  jnz 0x00007F4F7CBD6EF5
00007f4f7cbd6333  movaps xmm15, [r15+0x1E0]
00007f4f7cbd633b  vmovaps [rsp+0xC0], xmm15
00007f4f7cbd6344  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd634d  por xmm15, xmm13
00007f4f7cbd6352  movaps xmm13, [r15+0x1D0]
00007f4f7cbd635a  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd6363  vmovaps [rsp+0xD0], xmm1
00007f4f7cbd636c  vmovaps xmm1, [rsp+0xC0]
00007f4f7cbd6375  por xmm13, xmm1
00007f4f7cbd637a  movaps xmm1, [r15+0x2C0]
00007f4f7cbd6382  vmovaps [rsp+0xC0], xmm1
00007f4f7cbd638b  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd6394  vmovaps xmm15, [rsp+0xC0]
00007f4f7cbd639d  por xmm1, xmm15
00007f4f7cbd63a2  movaps xmm15, [r15+0x290]
00007f4f7cbd63aa  vmovaps [rsp+0xC0], xmm15
00007f4f7cbd63b3  vmovaps [rsp+0xF0], xmm1
00007f4f7cbd63bc  vmovaps xmm1, [rsp+0xC0]
00007f4f7cbd63c5  por xmm15, xmm1
00007f4f7cbd63ca  movaps xmm1, [r15+0x260]
00007f4f7cbd63d2  vmovaps [rsp+0xC0], xmm1
00007f4f7cbd63db  vmovaps [rsp+0x100], xmm15
00007f4f7cbd63e4  vmovaps xmm15, [rsp+0xC0]
00007f4f7cbd63ed  por xmm1, xmm15
00007f4f7cbd63f2  vmovaps xmm15, [rsp+0xD0]
00007f4f7cbd63fb  vmovaps [rsp+0xC0], xmm1
00007f4f7cbd6404  vmovaps xmm1, [rsp+0xD0]
00007f4f7cbd640d  por xmm15, xmm1
00007f4f7cbd6412  lea r14, [rax+0xC0]
00007f4f7cbd6419  movups xmm1, [r13+r14*1]
00007f4f7cbd641f  mov [rsp+0xD0], rax
00007f4f7cbd6427  xor eax, eax
00007f4f7cbd6429  mov r14d, 0x200
00007f4f7cbd642f  cmp r12, r14
00007f4f7cbd6432  cmc
00007f4f7cbd6433  lahf
00007f4f7cbd6434  seto al
00007f4f7cbd6437  mov [r15+0x108], eax
00007f4f7cbd643e  vmovaps [rsp+0x110], xmm1
00007f4f7cbd6447  vmovaps xmm1, [rsp+0x80]
00007f4f7cbd6450  vmovaps [rsp+0x80], xmm15
00007f4f7cbd6459  vmovaps xmm15, [rsp+0x110]
00007f4f7cbd6462  vmovaps [rsp+0x110], xmm13
00007f4f7cbd646b  vmovaps [rsp+0x120], xmm12
00007f4f7cbd6474  movaps xmm13, xmm1
00007f4f7cbd6478  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd6483  vptest xmm12, xmm12
00007f4f7cbd6488  jnz 0x00007F4F7CBD7058
00007f4f7cbd648e  mov rax, [rsp+0xD0]
00007f4f7cbd6496  lea r14, [rax+0xB0]
00007f4f7cbd649d  movups xmm1, [r13+r14*1]
00007f4f7cbd64a3  vmovaps xmm15, [rsp+0xA0]
00007f4f7cbd64ac  vmovaps [rsp+0xA0], xmm13
00007f4f7cbd64b5  movaps xmm12, xmm15
00007f4f7cbd64b9  vfmadd231pd xmm12, xmm1, xmm14
00007f4f7cbd64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007f4f7cbd64c4  vptest xmm13, xmm13
00007f4f7cbd64c9  jnz 0x00007F4F7CBD71BB
00007f4f7cbd64cf  vmovaps xmm1, [rsp+0x30]
00007f4f7cbd64d5  vmovaps xmm15, [rsp+0x30]
00007f4f7cbd64db  por xmm1, xmm15
00007f4f7cbd64e0  movaps [r15+0x210], xmm1
00007f4f7cbd64e8  vmovaps xmm15, [rsp+0x70]
00007f4f7cbd64ee  vmovaps xmm14, [rsp+0x70]
00007f4f7cbd64f4  por xmm15, xmm14
00007f4f7cbd64f9  movaps [r15+0x1C0], xmm15
00007f4f7cbd6501  vmovaps xmm14, [rsp+0x60]
00007f4f7cbd6507  vmovaps xmm13, [rsp+0x60]
00007f4f7cbd650d  por xmm14, xmm13
00007f4f7cbd6512  movaps [r15+0x280], xmm14
00007f4f7cbd651a  vmovaps xmm13, [rsp+0x50]
00007f4f7cbd6520  vmovaps [rsp+0x30], xmm1
00007f4f7cbd6526  vmovaps xmm1, [rsp+0x50]
00007f4f7cbd652c  por xmm13, xmm1
00007f4f7cbd6531  movaps [r15+0x2A0], xmm13
00007f4f7cbd6539  vmovaps [rsp+0x50], xmm2
00007f4f7cbd653f  vmovaps xmm1, [rsp+0x50]
00007f4f7cbd6545  por xmm2, xmm1
00007f4f7cbd6549  movaps [r15+0x2E0], xmm2
00007f4f7cbd6551  vmovaps [rsp+0x50], xmm3
00007f4f7cbd6557  vmovaps xmm1, [rsp+0x50]
00007f4f7cbd655d  por xmm3, xmm1
00007f4f7cbd6561  movaps [r15+0x1F0], xmm3
00007f4f7cbd6569  vmovaps xmm1, [rsp+0x80]
00007f4f7cbd6572  vmovaps [rsp+0x50], xmm15
00007f4f7cbd6578  vmovaps xmm15, [rsp+0x80]
00007f4f7cbd6581  por xmm1, xmm15
00007f4f7cbd6586  movaps [r15+0x250], xmm1
00007f4f7cbd658e  vmovaps xmm1, [rsp+0xC0]
00007f4f7cbd6597  vmovaps xmm15, [rsp+0xC0]
00007f4f7cbd65a0  por xmm1, xmm15
00007f4f7cbd65a5  movaps [r15+0x260], xmm1
00007f4f7cbd65ad  vmovaps xmm15, [rsp+0x100]
00007f4f7cbd65b6  vmovaps [rsp+0x60], xmm1
00007f4f7cbd65bc  vmovaps xmm1, [rsp+0x100]
00007f4f7cbd65c5  por xmm15, xmm1
00007f4f7cbd65ca  movaps [r15+0x290], xmm15
00007f4f7cbd65d2  vmovaps xmm1, [rsp+0xF0]
00007f4f7cbd65db  vmovaps [rsp+0x70], xmm15
00007f4f7cbd65e1  vmovaps xmm15, [rsp+0xF0]
00007f4f7cbd65ea  por xmm1, xmm15
00007f4f7cbd65ef  movaps [r15+0x2C0], xmm1
00007f4f7cbd65f7  movq xmm15, qword ptr [r15+0x240]
00007f4f7cbd6600  vmovaps [rsp+0x80], xmm15
00007f4f7cbd6609  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd660f  vmovaps [rsp+0xC0], xmm1
00007f4f7cbd6618  vmovaps xmm1, [rsp+0x40]
00007f4f7cbd661e  vmovaps [rsp+0x40], xmm15
00007f4f7cbd6624  vmovaps xmm15, [rsp+0x30]
00007f4f7cbd662a  vmovaps [rsp+0x30], xmm14
00007f4f7cbd6630  vmovaps xmm14, [rsp+0x40]
00007f4f7cbd6636  vmovaps [rsp+0x40], xmm13
00007f4f7cbd663c  vmovaps [rsp+0xD0], xmm12
00007f4f7cbd6645  movaps xmm13, xmm1
00007f4f7cbd6649  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd6654  vptest xmm12, xmm12
00007f4f7cbd6659  jnz 0x00007F4F7CBD7314
00007f4f7cbd665f  vmovaps xmm1, [rsp+0x80]
00007f4f7cbd6668  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd666e  vmovaps xmm15, [rsp+0xA0]
00007f4f7cbd6677  movaps xmm14, xmm15
00007f4f7cbd667b  vfmadd231pd xmm14, xmm2, xmm1
00007f4f7cbd6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007f4f7cbd6686  vptest xmm12, xmm12
00007f4f7cbd668b  jnz 0x00007F4F7CBD746D
00007f4f7cbd6691  vmovaps xmm1, [rsp+0x80]
00007f4f7cbd669a  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd66a0  vmovaps xmm15, [rsp+0x120]
00007f4f7cbd66a9  vmovaps xmm12, [rsp+0x50]
00007f4f7cbd66af  vmovaps [rsp+0x50], xmm14
00007f4f7cbd66b5  movaps xmm2, xmm15
00007f4f7cbd66b9  vfmadd231pd xmm2, xmm12, xmm1
00007f4f7cbd66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007f4f7cbd66c3  vptest xmm14, xmm14
00007f4f7cbd66c8  jnz 0x00007F4F7CBD75C5
00007f4f7cbd66ce  vmovaps xmm1, [rsp+0x110]
00007f4f7cbd66d7  vmovaps xmm15, [rsp+0x110]
00007f4f7cbd66e0  por xmm1, xmm15
00007f4f7cbd66e5  movaps [r15+0x1D0], xmm1
00007f4f7cbd66ed  vmovaps xmm15, [rsp+0x80]
00007f4f7cbd66f6  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd66fc  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd6705  vmovaps [rsp+0x80], xmm1
00007f4f7cbd670e  movaps xmm12, xmm14
00007f4f7cbd6712  vfmadd231pd xmm12, xmm3, xmm15
00007f4f7cbd6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007f4f7cbd671d  vptest xmm1, xmm1
00007f4f7cbd6722  jnz 0x00007F4F7CBD771C
00007f4f7cbd6728  vmovaps [rsp+0xA0], xmm4
00007f4f7cbd6731  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbd673a  por xmm4, xmm1
00007f4f7cbd673e  movaps [r15+0x200], xmm4
00007f4f7cbd6746  vmovaps xmm1, [rsp+0xE0]
00007f4f7cbd674f  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd6758  por xmm1, xmm15
00007f4f7cbd675d  movaps [r15+0x1E0], xmm1
00007f4f7cbd6765  vmovaps [rsp+0xA0], xmm8
00007f4f7cbd676e  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbd6777  por xmm8, xmm1
00007f4f7cbd677c  movaps [r15+0x2B0], xmm8
00007f4f7cbd6784  vmovaps [rsp+0xA0], xmm9
00007f4f7cbd678d  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbd6796  por xmm9, xmm1
00007f4f7cbd679b  movaps [r15+0x300], xmm9
00007f4f7cbd67a3  vmovaps [rsp+0xA0], xmm6
00007f4f7cbd67ac  vpermilpd xmm6, xmm6, 0x00
00007f4f7cbd67b2  vmovaps xmm14, [rsp+0x60]
00007f4f7cbd67b8  movaps xmm9, xmm13
00007f4f7cbd67bc  vfmadd231pd xmm9, xmm14, xmm6
00007f4f7cbd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007f4f7cbd67c7  vptest xmm3, xmm3
00007f4f7cbd67cc  jnz 0x00007F4F7CBD7875
00007f4f7cbd67d2  vmovaps xmm14, [rsp+0xA0]
00007f4f7cbd67db  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbd67e1  vmovaps xmm13, [rsp+0x50]
00007f4f7cbd67e7  vmovaps xmm6, [rsp+0xC0]
00007f4f7cbd67f0  vmovaps [rsp+0x50], xmm1
00007f4f7cbd67f6  movaps xmm3, xmm13
00007f4f7cbd67fa  vfmadd231pd xmm3, xmm6, xmm14
00007f4f7cbd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007f4f7cbd6804  vptest xmm1, xmm1
00007f4f7cbd6809  jnz 0x00007F4F7CBD79CE
00007f4f7cbd680f  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbd6818  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd681e  vmovaps xmm14, [rsp+0x30]
00007f4f7cbd6824  movaps xmm6, xmm2
00007f4f7cbd6827  vfmadd231pd xmm6, xmm14, xmm1
00007f4f7cbd682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007f4f7cbd6831  vptest xmm13, xmm13
00007f4f7cbd6836  jnz 0x00007F4F7CBD7B25
00007f4f7cbd683c  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbd6845  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd684b  vmovaps xmm14, [rsp+0x80]
00007f4f7cbd6854  movaps xmm13, xmm12
00007f4f7cbd6858  vfmadd231pd xmm13, xmm14, xmm1
00007f4f7cbd685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007f4f7cbd6863  vptest xmm2, xmm2
00007f4f7cbd6868  jnz 0x00007F4F7CBD7C7B
00007f4f7cbd686e  vmovaps [rsp+0x30], xmm7
00007f4f7cbd6874  vmovaps xmm1, [rsp+0x30]
00007f4f7cbd687a  por xmm7, xmm1
00007f4f7cbd687e  movaps [r15+0x180], xmm7
00007f4f7cbd6886  vmovaps [rsp+0x30], xmm10
00007f4f7cbd688c  vmovaps xmm1, [rsp+0x30]
00007f4f7cbd6892  por xmm10, xmm1
00007f4f7cbd6897  movaps [r15+0x2D0], xmm10
00007f4f7cbd689f  vmovaps [rsp+0x30], xmm5
00007f4f7cbd68a5  vpermilpd xmm5, xmm5, 0x00
00007f4f7cbd68ab  vmovaps xmm14, [rsp+0x50]
00007f4f7cbd68b1  movaps xmm12, xmm3
00007f4f7cbd68b5  vfmadd231pd xmm12, xmm14, xmm5
00007f4f7cbd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007f4f7cbd68c0  vptest xmm10, xmm10
00007f4f7cbd68c5  jnz 0x00007F4F7CBD7DD4
00007f4f7cbd68cb  vmovaps xmm14, [rsp+0x30]
00007f4f7cbd68d1  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbd68d7  movaps xmm10, xmm9
00007f4f7cbd68db  vfmadd231pd xmm10, xmm7, xmm14
00007f4f7cbd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007f4f7cbd68e6  vptest xmm5, xmm5
00007f4f7cbd68eb  jnz 0x00007F4F7CBD7F2C
00007f4f7cbd68f1  lea r14, [rax+0x80]
00007f4f7cbd68f8  movups xmm14, [r13+r14*1]
00007f4f7cbd68fe  movaps [r15+0x2F0], xmm14
00007f4f7cbd6906  vmovaps xmm9, [rsp+0x30]
00007f4f7cbd690c  vpermilpd xmm9, xmm9, 0x00
00007f4f7cbd6912  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd6918  movaps xmm5, xmm6
00007f4f7cbd691b  vfmadd231pd xmm5, xmm7, xmm9
00007f4f7cbd6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007f4f7cbd6925  vptest xmm3, xmm3
00007f4f7cbd692a  jnz 0x00007F4F7CBD808F
00007f4f7cbd6930  vmovaps xmm9, [rsp+0x30]
00007f4f7cbd6936  vpermilpd xmm9, xmm9, 0x00
00007f4f7cbd693c  movaps xmm7, xmm13
00007f4f7cbd6940  vfmadd231pd xmm7, xmm1, xmm9
00007f4f7cbd6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4f7cbd694a  vptest xmm6, xmm6
00007f4f7cbd694f  jnz 0x00007F4F7CBD81E5
00007f4f7cbd6955  vmovaps xmm1, [rsp+0x20]
00007f4f7cbd695b  vmovaps xmm13, [rsp+0x20]
00007f4f7cbd6961  por xmm1, xmm13
00007f4f7cbd6966  movaps [r15+0x160], xmm1
00007f4f7cbd696e  lea r14, [rax+0x40]
00007f4f7cbd6972  movups xmm13, [r13+r14*1]
00007f4f7cbd6978  lea r14, [rax+0x50]
00007f4f7cbd697c  movups xmm9, [r13+r14*1]
00007f4f7cbd6982  movaps [r15+0x1B0], xmm13
00007f4f7cbd698a  movaps [r15+0x1A0], xmm9
00007f4f7cbd6992  movaps xmm6, [r15+0x190]
00007f4f7cbd699a  vmovaps xmm3, [rsp+0xB0]
00007f4f7cbd69a3  vpermilpd xmm3, xmm3, 0x00
00007f4f7cbd69a9  vmovaps [rsp+0x20], xmm1
00007f4f7cbd69af  movaps xmm2, xmm12
00007f4f7cbd69b3  vfmadd231pd xmm2, xmm6, xmm3
00007f4f7cbd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007f4f7cbd69bd  vptest xmm1, xmm1
00007f4f7cbd69c2  jnz 0x00007F4F7CBD8350
00007f4f7cbd69c8  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd69d1  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd69d7  vmovaps xmm12, [rsp+0x20]
00007f4f7cbd69dd  movaps xmm6, xmm10
00007f4f7cbd69e1  vfmadd231pd xmm6, xmm12, xmm1
00007f4f7cbd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007f4f7cbd69eb  vptest xmm3, xmm3
00007f4f7cbd69f0  jnz 0x00007F4F7CBD84A6
00007f4f7cbd69f6  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd69ff  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd6a05  vmovaps xmm12, [rsp+0x40]
00007f4f7cbd6a0b  movaps xmm10, xmm5
00007f4f7cbd6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007f4f7cbd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007f4f7cbd6a1a  vptest xmm3, xmm3
00007f4f7cbd6a1f  jnz 0x00007F4F7CBD85FD
00007f4f7cbd6a25  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbd6a2e  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd6a34  movaps xmm12, xmm7
00007f4f7cbd6a38  vfmadd231pd xmm12, xmm15, xmm1
00007f4f7cbd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007f4f7cbd6a43  vptest xmm5, xmm5
00007f4f7cbd6a48  jnz 0x00007F4F7CBD8755
00007f4f7cbd6a4e  lea r14, [rax+0x60]
00007f4f7cbd6a52  movups xmm1, [r13+r14*1]
00007f4f7cbd6a58  lea r14, [rax+0x70]
00007f4f7cbd6a5c  movups xmm15, [r13+r14*1]
00007f4f7cbd6a62  movaps [r15+0x150], xmm1
00007f4f7cbd6a6a  movaps [r15+0x120], xmm15
00007f4f7cbd6a72  vmovaps [rsp+0x20], xmm11
00007f4f7cbd6a78  vpermilpd xmm11, xmm11, 0x00
00007f4f7cbd6a7e  movaps xmm7, xmm2
00007f4f7cbd6a81  vfmadd231pd xmm7, xmm9, xmm11
00007f4f7cbd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007f4f7cbd6a8b  vptest xmm5, xmm5
00007f4f7cbd6a90  jnz 0x00007F4F7CBD88C1
00007f4f7cbd6a96  vmovaps xmm11, [rsp+0x20]
00007f4f7cbd6a9c  vpermilpd xmm11, xmm11, 0x00
00007f4f7cbd6aa2  movaps xmm9, xmm6
00007f4f7cbd6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007f4f7cbd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007f4f7cbd6ab1  vptest xmm5, xmm5
00007f4f7cbd6ab6  jnz 0x00007F4F7CBD8A18
00007f4f7cbd6abc  vmovaps xmm1, [rsp+0x20]
00007f4f7cbd6ac2  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd6ac8  movaps xmm11, xmm10
00007f4f7cbd6acc  vfmadd231pd xmm11, xmm8, xmm1
00007f4f7cbd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007f4f7cbd6ad7  vptest xmm6, xmm6
00007f4f7cbd6adc  jnz 0x00007F4F7CBD8B70
00007f4f7cbd6ae2  vmovaps xmm1, [rsp+0x20]
00007f4f7cbd6ae8  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd6aee  movaps xmm10, xmm12
00007f4f7cbd6af2  vfmadd231pd xmm10, xmm13, xmm1
00007f4f7cbd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007f4f7cbd6afd  vptest xmm8, xmm8
00007f4f7cbd6b02  jnz 0x00007F4F7CBD8CC9
00007f4f7cbd6b08  lea r14, [rax+0x20]
00007f4f7cbd6b0c  movups xmm1, [r13+r14*1]
00007f4f7cbd6b12  lea r14, [rax+0x30]
00007f4f7cbd6b16  movups xmm13, [r13+r14*1]
00007f4f7cbd6b1c  vmovaps xmm12, [rsp+0x90]
00007f4f7cbd6b25  vpermilpd xmm12, xmm12, 0x00
00007f4f7cbd6b2b  movaps xmm8, xmm7
00007f4f7cbd6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007f4f7cbd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007f4f7cbd6b3a  vptest xmm6, xmm6
00007f4f7cbd6b3f  jnz 0x00007F4F7CBD8E36
00007f4f7cbd6b45  vmovaps xmm12, [rsp+0x90]
00007f4f7cbd6b4e  vpermilpd xmm12, xmm12, 0x00
00007f4f7cbd6b54  movaps xmm7, xmm9
00007f4f7cbd6b58  vfmadd231pd xmm7, xmm14, xmm12
00007f4f7cbd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4f7cbd6b62  vptest xmm6, xmm6
00007f4f7cbd6b67  jnz 0x00007F4F7CBD8F8E
00007f4f7cbd6b6d  vmovaps xmm14, [rsp+0x90]
00007f4f7cbd6b76  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbd6b7c  movaps xmm12, xmm11
00007f4f7cbd6b80  vfmadd231pd xmm12, xmm15, xmm14
00007f4f7cbd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007f4f7cbd6b8b  vptest xmm9, xmm9
00007f4f7cbd6b90  jnz 0x00007F4F7CBD90E6
00007f4f7cbd6b96  vmovaps xmm15, [rsp+0x90]
00007f4f7cbd6b9f  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd6ba5  movaps xmm11, xmm10
00007f4f7cbd6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007f4f7cbd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007f4f7cbd6bb4  vptest xmm14, xmm14
00007f4f7cbd6bb9  jnz 0x00007F4F7CBD9240
00007f4f7cbd6bbf  lea r14, [rax+0x90]
00007f4f7cbd6bc6  movups xmm15, [r13+r14*1]
00007f4f7cbd6bcc  lea r14, [rax+0xA0]
00007f4f7cbd6bd3  movups xmm14, [r13+r14*1]
00007f4f7cbd6bd9  movaps [r15+0x140], xmm15
00007f4f7cbd6be1  movaps [r15+0x130], xmm14
00007f4f7cbd6be9  vmovaps xmm13, [rsp+0x10]
00007f4f7cbd6bef  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbd6bf5  movaps xmm10, xmm8
00007f4f7cbd6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007f4f7cbd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007f4f7cbd6c04  vptest xmm9, xmm9
00007f4f7cbd6c09  jnz 0x00007F4F7CBD93AE
00007f4f7cbd6c0f  movaps [r15+0x220], xmm10
00007f4f7cbd6c17  lea r14, [rax+0x10]
00007f4f7cbd6c1b  movups xmm1, [r13+r14*1]
00007f4f7cbd6c21  movaps [r15+0x240], xmm1
00007f4f7cbd6c29  vmovaps xmm13, [rsp+0x10]
00007f4f7cbd6c2f  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbd6c35  movaps xmm9, xmm7
00007f4f7cbd6c39  vfmadd231pd xmm9, xmm14, xmm13
00007f4f7cbd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007f4f7cbd6c44  vptest xmm8, xmm8
00007f4f7cbd6c49  jnz 0x00007F4F7CBD9511
00007f4f7cbd6c4f  movaps [r15+0x110], xmm9
00007f4f7cbd6c57  vmovaps xmm14, [rsp+0x10]
00007f4f7cbd6c5d  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbd6c63  movaps xmm13, xmm12
00007f4f7cbd6c67  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007f4f7cbd6c72  vptest xmm8, xmm8
00007f4f7cbd6c77  jnz 0x00007F4F7CBD966A
00007f4f7cbd6c7d  movaps [r15+0x170], xmm13
00007f4f7cbd6c85  vmovaps xmm15, [rsp+0x10]
00007f4f7cbd6c8b  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd6c91  movaps xmm14, xmm11
00007f4f7cbd6c95  vfmadd231pd xmm14, xmm1, xmm15
00007f4f7cbd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007f4f7cbd6ca0  vptest xmm12, xmm12
00007f4f7cbd6ca5  jnz 0x00007F4F7CBD97C4
00007f4f7cbd6cab  movaps [r15+0x230], xmm14
00007f4f7cbd6cb3  movups [r13+r11*1], xmm9
00007f4f7cbd6cb9  lea rax, [r11+0x10]
00007f4f7cbd6cbd  movups [r13+rax*1], xmm13
00007f4f7cbd6cc3  lea rax, [r11+0x20]
00007f4f7cbd6cc7  movups [r13+rax*1], xmm10
00007f4f7cbd6ccd  lea rax, [r11+0x30]
00007f4f7cbd6cd1  movups [r13+rax*1], xmm14
00007f4f7cbd6cd7  mov eax, [r15+0x108]
00007f4f7cbd6cde  sahf
00007f4f7cbd6cdf  jnz 0x00007F4F7CBD6D11
00007f4f7cbd6ce1  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd6ce9  jz 0x00007F4F7CBD9950
00007f4f7cbd6cef  nop [rax+rax*1], ax
00007f4f7cbd6cf8  nop [rax+rax*1], eax
00007f4f7cbd6d00  mov eax, 0x410664
00007f4f7cbd6d05  mov [r15+0x100], rax
00007f4f7cbd6d0c  jmp 0x00007F4F7C9FE110
00007f4f7cbd6d11  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd6d19  jz 0x00007F4F7CBD6050
00007f4f7cbd6d1f  nop [rax+rax*1], ax
00007f4f7cbd6d28  nop [rax+rax*1], eax
00007f4f7cbd6d30  mov eax, 0x4104F0
00007f4f7cbd6d35  mov [r15+0x100], rax
00007f4f7cbd6d3c  jmp 0x00007F4F7C9FE110
00007f4f7cbd6d41  int3
00007f4f7cbd6d42  call 0x00007F4F7CA0A4B0
00007f4f7cbd6d47  jmp 0x00007F4F7CBD6079
00007f4f7cbd6d4c  call 0x00007F4F7CA09240
00007f4f7cbd6d51  jmp 0x00007F4F7CBD6083
00007f4f7cbd6d56  call 0x00007F4F7CA0A4B0
00007f4f7cbd6d5b  jmp 0x00007F4F7CBD60CD
00007f4f7cbd6d60  call 0x00007F4F7CA09240
00007f4f7cbd6d65  jmp 0x00007F4F7CBD60D7
00007f4f7cbd6d6a  call 0x00007F4F7CA0A4B0
00007f4f7cbd6d6f  jmp 0x00007F4F7CBD6158
00007f4f7cbd6d74  call 0x00007F4F7CA09240
00007f4f7cbd6d79  jmp 0x00007F4F7CBD6162
00007f4f7cbd6d7e  call 0x00007F4F7CAB47C0
00007f4f7cbd6d83  jmp 0x00007F4F7CBD6243
00007f4f7cbd6d88  call 0x00007F4F7C9FF430
00007f4f7cbd6d8d  jmp 0x00007F4F7CBD6272
00007f4f7cbd6d92  call 0x00007F4F7CAB0CE0
00007f4f7cbd6d97  jmp 0x00007F4F7CBD628E
00007f4f7cbd6d9c  sub rsp, 0x08
00007f4f7cbd6da0  push rax
00007f4f7cbd6da1  push rcx
00007f4f7cbd6da2  push rdx
00007f4f7cbd6da3  push rdi
00007f4f7cbd6da4  push rsi
00007f4f7cbd6da5  push r8
00007f4f7cbd6da7  push r9
00007f4f7cbd6da9  push r10
00007f4f7cbd6dab  push r11
00007f4f7cbd6dad  sub rsp, 0xF0
00007f4f7cbd6db4  vmovaps [rsp], xmm0
00007f4f7cbd6db9  vmovaps [rsp+0x10], xmm1
00007f4f7cbd6dbf  vmovaps [rsp+0x20], xmm2
00007f4f7cbd6dc5  vmovaps [rsp+0x30], xmm3
00007f4f7cbd6dcb  vmovaps [rsp+0x40], xmm4
00007f4f7cbd6dd1  vmovaps [rsp+0x50], xmm5
00007f4f7cbd6dd7  vmovaps [rsp+0x60], xmm6
00007f4f7cbd6ddd  vmovaps [rsp+0x70], xmm7
00007f4f7cbd6de3  vmovaps [rsp+0x80], xmm8
00007f4f7cbd6dec  vmovaps [rsp+0x90], xmm9
00007f4f7cbd6df5  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd6dfe  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd6e07  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd6e10  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd6e19  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd6e22  sub rsp, 0x40
00007f4f7cbd6e26  lea rdi, [rsp]
00007f4f7cbd6e2a  lea rsi, [rsp+0x10]
00007f4f7cbd6e2f  lea rdx, [rsp+0x20]
00007f4f7cbd6e34  lea rcx, [rsp+0x30]
00007f4f7cbd6e39  mov r8d, 0x00
00007f4f7cbd6e3f  lea r9, [r15+0x3A8]
00007f4f7cbd6e46  movaps [rdi], xmm13
00007f4f7cbd6e4a  movaps [rsi], xmm1
00007f4f7cbd6e4d  movaps [rdx], xmm15
00007f4f7cbd6e51  movaps [rcx], xmm14
00007f4f7cbd6e55  mov rax, 0x643999485A50
00007f4f7cbd6e5f  call rax
00007f4f7cbd6e61  movaps xmm13, [rsp]
00007f4f7cbd6e66  add rsp, 0x40
00007f4f7cbd6e6a  vmovaps xmm0, [rsp]
00007f4f7cbd6e6f  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd6e75  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd6e7b  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd6e81  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd6e87  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd6e8d  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd6e93  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd6e99  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd6ea2  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd6eab  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd6eb4  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd6ebd  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd6ec6  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd6ecf  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd6ed8  add rsp, 0xF0
00007f4f7cbd6edf  pop r11
00007f4f7cbd6ee1  pop r10
00007f4f7cbd6ee3  pop r9
00007f4f7cbd6ee5  pop r8
00007f4f7cbd6ee7  pop rsi
00007f4f7cbd6ee8  pop rdi
00007f4f7cbd6ee9  pop rdx
00007f4f7cbd6eea  pop rcx
00007f4f7cbd6eeb  pop rax
00007f4f7cbd6eec  add rsp, 0x08
00007f4f7cbd6ef0  jmp 0x00007F4F7CBD6305
00007f4f7cbd6ef5  sub rsp, 0x08
00007f4f7cbd6ef9  push rax
00007f4f7cbd6efa  push rcx
00007f4f7cbd6efb  push rdx
00007f4f7cbd6efc  push rdi
00007f4f7cbd6efd  push rsi
00007f4f7cbd6efe  push r8
00007f4f7cbd6f00  push r9
00007f4f7cbd6f02  push r10
00007f4f7cbd6f04  push r11
00007f4f7cbd6f06  sub rsp, 0xF0
00007f4f7cbd6f0d  vmovaps [rsp], xmm0
00007f4f7cbd6f12  vmovaps [rsp+0x10], xmm1
00007f4f7cbd6f18  vmovaps [rsp+0x20], xmm2
00007f4f7cbd6f1e  vmovaps [rsp+0x30], xmm3
00007f4f7cbd6f24  vmovaps [rsp+0x40], xmm4
00007f4f7cbd6f2a  vmovaps [rsp+0x50], xmm5
00007f4f7cbd6f30  vmovaps [rsp+0x60], xmm6
00007f4f7cbd6f36  vmovaps [rsp+0x70], xmm7
00007f4f7cbd6f3c  vmovaps [rsp+0x80], xmm8
00007f4f7cbd6f45  vmovaps [rsp+0x90], xmm9
00007f4f7cbd6f4e  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd6f57  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd6f60  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd6f69  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd6f72  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd6f7b  sub rsp, 0x40
00007f4f7cbd6f7f  lea rdi, [rsp]
00007f4f7cbd6f83  lea rsi, [rsp+0x10]
00007f4f7cbd6f88  lea rdx, [rsp+0x20]
00007f4f7cbd6f8d  lea rcx, [rsp+0x30]
00007f4f7cbd6f92  mov r8d, 0x00
00007f4f7cbd6f98  lea r9, [r15+0x3A8]
00007f4f7cbd6f9f  movaps [rdi], xmm12
00007f4f7cbd6fa3  movaps [rsi], xmm15
00007f4f7cbd6fa7  movaps [rdx], xmm1
00007f4f7cbd6faa  movaps [rcx], xmm14
00007f4f7cbd6fae  mov rax, 0x643999485A50
00007f4f7cbd6fb8  call rax
00007f4f7cbd6fba  movaps xmm12, [rsp]
00007f4f7cbd6fbf  add rsp, 0x40
00007f4f7cbd6fc3  vmovaps xmm0, [rsp]
00007f4f7cbd6fc8  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd6fce  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd6fd4  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd6fda  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd6fe0  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd6fe6  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd6fec  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd6ff2  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd6ffb  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd7004  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd700d  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd7016  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd701f  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd7028  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd7031  add rsp, 0xF0
00007f4f7cbd7038  pop r11
00007f4f7cbd703a  pop r10
00007f4f7cbd703c  pop r9
00007f4f7cbd703e  pop r8
00007f4f7cbd7040  pop rsi
00007f4f7cbd7041  pop rdi
00007f4f7cbd7042  pop rdx
00007f4f7cbd7043  pop rcx
00007f4f7cbd7044  pop rax
00007f4f7cbd7045  add rsp, 0x08
00007f4f7cbd7049  jmp 0x00007F4F7CBD6333
00007f4f7cbd704e  call 0x00007F4F7CAD64F0
00007f4f7cbd7053  jmp 0x00007F4F7CBD641F
00007f4f7cbd7058  sub rsp, 0x08
00007f4f7cbd705c  push rax
00007f4f7cbd705d  push rcx
00007f4f7cbd705e  push rdx
00007f4f7cbd705f  push rdi
00007f4f7cbd7060  push rsi
00007f4f7cbd7061  push r8
00007f4f7cbd7063  push r9
00007f4f7cbd7065  push r10
00007f4f7cbd7067  push r11
00007f4f7cbd7069  sub rsp, 0xF0
00007f4f7cbd7070  vmovaps [rsp], xmm0
00007f4f7cbd7075  vmovaps [rsp+0x10], xmm1
00007f4f7cbd707b  vmovaps [rsp+0x20], xmm2
00007f4f7cbd7081  vmovaps [rsp+0x30], xmm3
00007f4f7cbd7087  vmovaps [rsp+0x40], xmm4
00007f4f7cbd708d  vmovaps [rsp+0x50], xmm5
00007f4f7cbd7093  vmovaps [rsp+0x60], xmm6
00007f4f7cbd7099  vmovaps [rsp+0x70], xmm7
00007f4f7cbd709f  vmovaps [rsp+0x80], xmm8
00007f4f7cbd70a8  vmovaps [rsp+0x90], xmm9
00007f4f7cbd70b1  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd70ba  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd70c3  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd70cc  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd70d5  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd70de  sub rsp, 0x40
00007f4f7cbd70e2  lea rdi, [rsp]
00007f4f7cbd70e6  lea rsi, [rsp+0x10]
00007f4f7cbd70eb  lea rdx, [rsp+0x20]
00007f4f7cbd70f0  lea rcx, [rsp+0x30]
00007f4f7cbd70f5  mov r8d, 0x00
00007f4f7cbd70fb  lea r9, [r15+0x3A8]
00007f4f7cbd7102  movaps [rdi], xmm13
00007f4f7cbd7106  movaps [rsi], xmm1
00007f4f7cbd7109  movaps [rdx], xmm15
00007f4f7cbd710d  movaps [rcx], xmm14
00007f4f7cbd7111  mov rax, 0x643999485A50
00007f4f7cbd711b  call rax
00007f4f7cbd711d  movaps xmm13, [rsp]
00007f4f7cbd7122  add rsp, 0x40
00007f4f7cbd7126  vmovaps xmm0, [rsp]
00007f4f7cbd712b  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd7131  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd7137  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd713d  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd7143  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd7149  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd714f  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd7155  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd715e  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd7167  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd7170  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd7179  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd7182  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd718b  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd7194  add rsp, 0xF0
00007f4f7cbd719b  pop r11
00007f4f7cbd719d  pop r10
00007f4f7cbd719f  pop r9
00007f4f7cbd71a1  pop r8
00007f4f7cbd71a3  pop rsi
00007f4f7cbd71a4  pop rdi
00007f4f7cbd71a5  pop rdx
00007f4f7cbd71a6  pop rcx
00007f4f7cbd71a7  pop rax
00007f4f7cbd71a8  add rsp, 0x08
00007f4f7cbd71ac  jmp 0x00007F4F7CBD648E
00007f4f7cbd71b1  call 0x00007F4F7CAD64F0
00007f4f7cbd71b6  jmp 0x00007F4F7CBD64A3
00007f4f7cbd71bb  sub rsp, 0x08
00007f4f7cbd71bf  push rax
00007f4f7cbd71c0  push rcx
00007f4f7cbd71c1  push rdx
00007f4f7cbd71c2  push rdi
00007f4f7cbd71c3  push rsi
00007f4f7cbd71c4  push r8
00007f4f7cbd71c6  push r9
00007f4f7cbd71c8  push r10
00007f4f7cbd71ca  push r11
00007f4f7cbd71cc  sub rsp, 0xF0
00007f4f7cbd71d3  vmovaps [rsp], xmm0
00007f4f7cbd71d8  vmovaps [rsp+0x10], xmm1
00007f4f7cbd71de  vmovaps [rsp+0x20], xmm2
00007f4f7cbd71e4  vmovaps [rsp+0x30], xmm3
00007f4f7cbd71ea  vmovaps [rsp+0x40], xmm4
00007f4f7cbd71f0  vmovaps [rsp+0x50], xmm5
00007f4f7cbd71f6  vmovaps [rsp+0x60], xmm6
00007f4f7cbd71fc  vmovaps [rsp+0x70], xmm7
00007f4f7cbd7202  vmovaps [rsp+0x80], xmm8
00007f4f7cbd720b  vmovaps [rsp+0x90], xmm9
00007f4f7cbd7214  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd721d  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd7226  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd722f  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd7238  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd7241  sub rsp, 0x40
00007f4f7cbd7245  lea rdi, [rsp]
00007f4f7cbd7249  lea rsi, [rsp+0x10]
00007f4f7cbd724e  lea rdx, [rsp+0x20]
00007f4f7cbd7253  lea rcx, [rsp+0x30]
00007f4f7cbd7258  mov r8d, 0x00
00007f4f7cbd725e  lea r9, [r15+0x3A8]
00007f4f7cbd7265  movaps [rdi], xmm12
00007f4f7cbd7269  movaps [rsi], xmm15
00007f4f7cbd726d  movaps [rdx], xmm1
00007f4f7cbd7270  movaps [rcx], xmm14
00007f4f7cbd7274  mov rax, 0x643999485A50
00007f4f7cbd727e  call rax
00007f4f7cbd7280  movaps xmm12, [rsp]
00007f4f7cbd7285  add rsp, 0x40
00007f4f7cbd7289  vmovaps xmm0, [rsp]
00007f4f7cbd728e  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd7294  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd729a  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd72a0  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd72a6  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd72ac  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd72b2  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd72b8  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd72c1  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd72ca  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd72d3  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd72dc  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd72e5  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd72ee  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd72f7  add rsp, 0xF0
00007f4f7cbd72fe  pop r11
00007f4f7cbd7300  pop r10
00007f4f7cbd7302  pop r9
00007f4f7cbd7304  pop r8
00007f4f7cbd7306  pop rsi
00007f4f7cbd7307  pop rdi
00007f4f7cbd7308  pop rdx
00007f4f7cbd7309  pop rcx
00007f4f7cbd730a  pop rax
00007f4f7cbd730b  add rsp, 0x08
00007f4f7cbd730f  jmp 0x00007F4F7CBD64CF
00007f4f7cbd7314  sub rsp, 0x08
00007f4f7cbd7318  push rax
00007f4f7cbd7319  push rcx
00007f4f7cbd731a  push rdx
00007f4f7cbd731b  push rdi
00007f4f7cbd731c  push rsi
00007f4f7cbd731d  push r8
00007f4f7cbd731f  push r9
00007f4f7cbd7321  push r10
00007f4f7cbd7323  push r11
00007f4f7cbd7325  sub rsp, 0xF0
00007f4f7cbd732c  vmovaps [rsp], xmm0
00007f4f7cbd7331  vmovaps [rsp+0x10], xmm1
00007f4f7cbd7337  vmovaps [rsp+0x20], xmm2
00007f4f7cbd733d  vmovaps [rsp+0x30], xmm3
00007f4f7cbd7343  vmovaps [rsp+0x40], xmm4
00007f4f7cbd7349  vmovaps [rsp+0x50], xmm5
00007f4f7cbd734f  vmovaps [rsp+0x60], xmm6
00007f4f7cbd7355  vmovaps [rsp+0x70], xmm7
00007f4f7cbd735b  vmovaps [rsp+0x80], xmm8
00007f4f7cbd7364  vmovaps [rsp+0x90], xmm9
00007f4f7cbd736d  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd7376  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd737f  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd7388  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd7391  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd739a  sub rsp, 0x40
00007f4f7cbd739e  lea rdi, [rsp]
00007f4f7cbd73a2  lea rsi, [rsp+0x10]
00007f4f7cbd73a7  lea rdx, [rsp+0x20]
00007f4f7cbd73ac  lea rcx, [rsp+0x30]
00007f4f7cbd73b1  mov r8d, 0x00
00007f4f7cbd73b7  lea r9, [r15+0x3A8]
00007f4f7cbd73be  movaps [rdi], xmm13
00007f4f7cbd73c2  movaps [rsi], xmm1
00007f4f7cbd73c5  movaps [rdx], xmm15
00007f4f7cbd73c9  movaps [rcx], xmm14
00007f4f7cbd73cd  mov rax, 0x643999485A50
00007f4f7cbd73d7  call rax
00007f4f7cbd73d9  movaps xmm13, [rsp]
00007f4f7cbd73de  add rsp, 0x40
00007f4f7cbd73e2  vmovaps xmm0, [rsp]
00007f4f7cbd73e7  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd73ed  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd73f3  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd73f9  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd73ff  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd7405  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd740b  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd7411  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd741a  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd7423  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd742c  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd7435  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd743e  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd7447  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd7450  add rsp, 0xF0
00007f4f7cbd7457  pop r11
00007f4f7cbd7459  pop r10
00007f4f7cbd745b  pop r9
00007f4f7cbd745d  pop r8
00007f4f7cbd745f  pop rsi
00007f4f7cbd7460  pop rdi
00007f4f7cbd7461  pop rdx
00007f4f7cbd7462  pop rcx
00007f4f7cbd7463  pop rax
00007f4f7cbd7464  add rsp, 0x08
00007f4f7cbd7468  jmp 0x00007F4F7CBD665F
00007f4f7cbd746d  sub rsp, 0x08
00007f4f7cbd7471  push rax
00007f4f7cbd7472  push rcx
00007f4f7cbd7473  push rdx
00007f4f7cbd7474  push rdi
00007f4f7cbd7475  push rsi
00007f4f7cbd7476  push r8
00007f4f7cbd7478  push r9
00007f4f7cbd747a  push r10
00007f4f7cbd747c  push r11
00007f4f7cbd747e  sub rsp, 0xF0
00007f4f7cbd7485  vmovaps [rsp], xmm0
00007f4f7cbd748a  vmovaps [rsp+0x10], xmm1
00007f4f7cbd7490  vmovaps [rsp+0x20], xmm2
00007f4f7cbd7496  vmovaps [rsp+0x30], xmm3
00007f4f7cbd749c  vmovaps [rsp+0x40], xmm4
00007f4f7cbd74a2  vmovaps [rsp+0x50], xmm5
00007f4f7cbd74a8  vmovaps [rsp+0x60], xmm6
00007f4f7cbd74ae  vmovaps [rsp+0x70], xmm7
00007f4f7cbd74b4  vmovaps [rsp+0x80], xmm8
00007f4f7cbd74bd  vmovaps [rsp+0x90], xmm9
00007f4f7cbd74c6  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd74cf  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd74d8  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd74e1  vmovaps [rsp+0xD0], xmm13
00007f4f7cbd74ea  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd74f3  sub rsp, 0x40
00007f4f7cbd74f7  lea rdi, [rsp]
00007f4f7cbd74fb  lea rsi, [rsp+0x10]
00007f4f7cbd7500  lea rdx, [rsp+0x20]
00007f4f7cbd7505  lea rcx, [rsp+0x30]
00007f4f7cbd750a  mov r8d, 0x00
00007f4f7cbd7510  lea r9, [r15+0x3A8]
00007f4f7cbd7517  movaps [rdi], xmm14
00007f4f7cbd751b  movaps [rsi], xmm15
00007f4f7cbd751f  movaps [rdx], xmm2
00007f4f7cbd7522  movaps [rcx], xmm1
00007f4f7cbd7525  mov rax, 0x643999485A50
00007f4f7cbd752f  call rax
00007f4f7cbd7531  movaps xmm14, [rsp]
00007f4f7cbd7536  add rsp, 0x40
00007f4f7cbd753a  vmovaps xmm0, [rsp]
00007f4f7cbd753f  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd7545  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd754b  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd7551  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd7557  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd755d  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd7563  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd7569  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd7572  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd757b  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd7584  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd758d  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd7596  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbd759f  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd75a8  add rsp, 0xF0
00007f4f7cbd75af  pop r11
00007f4f7cbd75b1  pop r10
00007f4f7cbd75b3  pop r9
00007f4f7cbd75b5  pop r8
00007f4f7cbd75b7  pop rsi
00007f4f7cbd75b8  pop rdi
00007f4f7cbd75b9  pop rdx
00007f4f7cbd75ba  pop rcx
00007f4f7cbd75bb  pop rax
00007f4f7cbd75bc  add rsp, 0x08
00007f4f7cbd75c0  jmp 0x00007F4F7CBD6691
00007f4f7cbd75c5  sub rsp, 0x08
00007f4f7cbd75c9  push rax
00007f4f7cbd75ca  push rcx
00007f4f7cbd75cb  push rdx
00007f4f7cbd75cc  push rdi
00007f4f7cbd75cd  push rsi
00007f4f7cbd75ce  push r8
00007f4f7cbd75d0  push r9
00007f4f7cbd75d2  push r10
00007f4f7cbd75d4  push r11
00007f4f7cbd75d6  sub rsp, 0xF0
00007f4f7cbd75dd  vmovaps [rsp], xmm0
00007f4f7cbd75e2  vmovaps [rsp+0x10], xmm1
00007f4f7cbd75e8  vmovaps [rsp+0x20], xmm3
00007f4f7cbd75ee  vmovaps [rsp+0x30], xmm4
00007f4f7cbd75f4  vmovaps [rsp+0x40], xmm5
00007f4f7cbd75fa  vmovaps [rsp+0x50], xmm6
00007f4f7cbd7600  vmovaps [rsp+0x60], xmm7
00007f4f7cbd7606  vmovaps [rsp+0x70], xmm8
00007f4f7cbd760c  vmovaps [rsp+0x80], xmm9
00007f4f7cbd7615  vmovaps [rsp+0x90], xmm10
00007f4f7cbd761e  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd7627  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd7630  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd7639  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd7642  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd764b  sub rsp, 0x40
00007f4f7cbd764f  lea rdi, [rsp]
00007f4f7cbd7653  lea rsi, [rsp+0x10]
00007f4f7cbd7658  lea rdx, [rsp+0x20]
00007f4f7cbd765d  lea rcx, [rsp+0x30]
00007f4f7cbd7662  mov r8d, 0x00
00007f4f7cbd7668  lea r9, [r15+0x3A8]
00007f4f7cbd766f  movaps [rdi], xmm2
00007f4f7cbd7672  movaps [rsi], xmm15
00007f4f7cbd7676  movaps [rdx], xmm12
00007f4f7cbd767a  movaps [rcx], xmm1
00007f4f7cbd767d  mov rax, 0x643999485A50
00007f4f7cbd7687  call rax
00007f4f7cbd7689  movaps xmm2, [rsp]
00007f4f7cbd768d  add rsp, 0x40
00007f4f7cbd7691  vmovaps xmm0, [rsp]
00007f4f7cbd7696  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd769c  vmovaps xmm3, [rsp+0x20]
00007f4f7cbd76a2  vmovaps xmm4, [rsp+0x30]
00007f4f7cbd76a8  vmovaps xmm5, [rsp+0x40]
00007f4f7cbd76ae  vmovaps xmm6, [rsp+0x50]
00007f4f7cbd76b4  vmovaps xmm7, [rsp+0x60]
00007f4f7cbd76ba  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd76c0  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd76c9  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd76d2  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd76db  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd76e4  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd76ed  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd76f6  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd76ff  add rsp, 0xF0
00007f4f7cbd7706  pop r11
00007f4f7cbd7708  pop r10
00007f4f7cbd770a  pop r9
00007f4f7cbd770c  pop r8
00007f4f7cbd770e  pop rsi
00007f4f7cbd770f  pop rdi
00007f4f7cbd7710  pop rdx
00007f4f7cbd7711  pop rcx
00007f4f7cbd7712  pop rax
00007f4f7cbd7713  add rsp, 0x08
00007f4f7cbd7717  jmp 0x00007F4F7CBD66CE
00007f4f7cbd771c  sub rsp, 0x08
00007f4f7cbd7720  push rax
00007f4f7cbd7721  push rcx
00007f4f7cbd7722  push rdx
00007f4f7cbd7723  push rdi
00007f4f7cbd7724  push rsi
00007f4f7cbd7725  push r8
00007f4f7cbd7727  push r9
00007f4f7cbd7729  push r10
00007f4f7cbd772b  push r11
00007f4f7cbd772d  sub rsp, 0xF0
00007f4f7cbd7734  vmovaps [rsp], xmm0
00007f4f7cbd7739  vmovaps [rsp+0x10], xmm1
00007f4f7cbd773f  vmovaps [rsp+0x20], xmm2
00007f4f7cbd7745  vmovaps [rsp+0x30], xmm3
00007f4f7cbd774b  vmovaps [rsp+0x40], xmm4
00007f4f7cbd7751  vmovaps [rsp+0x50], xmm5
00007f4f7cbd7757  vmovaps [rsp+0x60], xmm6
00007f4f7cbd775d  vmovaps [rsp+0x70], xmm7
00007f4f7cbd7763  vmovaps [rsp+0x80], xmm8
00007f4f7cbd776c  vmovaps [rsp+0x90], xmm9
00007f4f7cbd7775  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd777e  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd7787  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd7790  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd7799  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd77a2  sub rsp, 0x40
00007f4f7cbd77a6  lea rdi, [rsp]
00007f4f7cbd77aa  lea rsi, [rsp+0x10]
00007f4f7cbd77af  lea rdx, [rsp+0x20]
00007f4f7cbd77b4  lea rcx, [rsp+0x30]
00007f4f7cbd77b9  mov r8d, 0x00
00007f4f7cbd77bf  lea r9, [r15+0x3A8]
00007f4f7cbd77c6  movaps [rdi], xmm12
00007f4f7cbd77ca  movaps [rsi], xmm14
00007f4f7cbd77ce  movaps [rdx], xmm3
00007f4f7cbd77d1  movaps [rcx], xmm15
00007f4f7cbd77d5  mov rax, 0x643999485A50
00007f4f7cbd77df  call rax
00007f4f7cbd77e1  movaps xmm12, [rsp]
00007f4f7cbd77e6  add rsp, 0x40
00007f4f7cbd77ea  vmovaps xmm0, [rsp]
00007f4f7cbd77ef  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd77f5  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd77fb  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd7801  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd7807  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd780d  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd7813  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd7819  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd7822  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd782b  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd7834  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd783d  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd7846  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd784f  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd7858  add rsp, 0xF0
00007f4f7cbd785f  pop r11
00007f4f7cbd7861  pop r10
00007f4f7cbd7863  pop r9
00007f4f7cbd7865  pop r8
00007f4f7cbd7867  pop rsi
00007f4f7cbd7868  pop rdi
00007f4f7cbd7869  pop rdx
00007f4f7cbd786a  pop rcx
00007f4f7cbd786b  pop rax
00007f4f7cbd786c  add rsp, 0x08
00007f4f7cbd7870  jmp 0x00007F4F7CBD6728
00007f4f7cbd7875  sub rsp, 0x08
00007f4f7cbd7879  push rax
00007f4f7cbd787a  push rcx
00007f4f7cbd787b  push rdx
00007f4f7cbd787c  push rdi
00007f4f7cbd787d  push rsi
00007f4f7cbd787e  push r8
00007f4f7cbd7880  push r9
00007f4f7cbd7882  push r10
00007f4f7cbd7884  push r11
00007f4f7cbd7886  sub rsp, 0xF0
00007f4f7cbd788d  vmovaps [rsp], xmm0
00007f4f7cbd7892  vmovaps [rsp+0x10], xmm1
00007f4f7cbd7898  vmovaps [rsp+0x20], xmm2
00007f4f7cbd789e  vmovaps [rsp+0x30], xmm3
00007f4f7cbd78a4  vmovaps [rsp+0x40], xmm4
00007f4f7cbd78aa  vmovaps [rsp+0x50], xmm5
00007f4f7cbd78b0  vmovaps [rsp+0x60], xmm6
00007f4f7cbd78b6  vmovaps [rsp+0x70], xmm7
00007f4f7cbd78bc  vmovaps [rsp+0x80], xmm8
00007f4f7cbd78c5  vmovaps [rsp+0x90], xmm10
00007f4f7cbd78ce  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd78d7  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd78e0  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd78e9  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd78f2  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd78fb  sub rsp, 0x40
00007f4f7cbd78ff  lea rdi, [rsp]
00007f4f7cbd7903  lea rsi, [rsp+0x10]
00007f4f7cbd7908  lea rdx, [rsp+0x20]
00007f4f7cbd790d  lea rcx, [rsp+0x30]
00007f4f7cbd7912  mov r8d, 0x00
00007f4f7cbd7918  lea r9, [r15+0x3A8]
00007f4f7cbd791f  movaps [rdi], xmm9
00007f4f7cbd7923  movaps [rsi], xmm13
00007f4f7cbd7927  movaps [rdx], xmm14
00007f4f7cbd792b  movaps [rcx], xmm6
00007f4f7cbd792e  mov rax, 0x643999485A50
00007f4f7cbd7938  call rax
00007f4f7cbd793a  movaps xmm9, [rsp]
00007f4f7cbd793f  add rsp, 0x40
00007f4f7cbd7943  vmovaps xmm0, [rsp]
00007f4f7cbd7948  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd794e  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd7954  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd795a  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd7960  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd7966  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd796c  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd7972  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd797b  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd7984  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd798d  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd7996  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd799f  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd79a8  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd79b1  add rsp, 0xF0
00007f4f7cbd79b8  pop r11
00007f4f7cbd79ba  pop r10
00007f4f7cbd79bc  pop r9
00007f4f7cbd79be  pop r8
00007f4f7cbd79c0  pop rsi
00007f4f7cbd79c1  pop rdi
00007f4f7cbd79c2  pop rdx
00007f4f7cbd79c3  pop rcx
00007f4f7cbd79c4  pop rax
00007f4f7cbd79c5  add rsp, 0x08
00007f4f7cbd79c9  jmp 0x00007F4F7CBD67D2
00007f4f7cbd79ce  sub rsp, 0x08
00007f4f7cbd79d2  push rax
00007f4f7cbd79d3  push rcx
00007f4f7cbd79d4  push rdx
00007f4f7cbd79d5  push rdi
00007f4f7cbd79d6  push rsi
00007f4f7cbd79d7  push r8
00007f4f7cbd79d9  push r9
00007f4f7cbd79db  push r10
00007f4f7cbd79dd  push r11
00007f4f7cbd79df  sub rsp, 0xF0
00007f4f7cbd79e6  vmovaps [rsp], xmm0
00007f4f7cbd79eb  vmovaps [rsp+0x10], xmm1
00007f4f7cbd79f1  vmovaps [rsp+0x20], xmm2
00007f4f7cbd79f7  vmovaps [rsp+0x30], xmm4
00007f4f7cbd79fd  vmovaps [rsp+0x40], xmm5
00007f4f7cbd7a03  vmovaps [rsp+0x50], xmm6
00007f4f7cbd7a09  vmovaps [rsp+0x60], xmm7
00007f4f7cbd7a0f  vmovaps [rsp+0x70], xmm8
00007f4f7cbd7a15  vmovaps [rsp+0x80], xmm9
00007f4f7cbd7a1e  vmovaps [rsp+0x90], xmm10
00007f4f7cbd7a27  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd7a30  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd7a39  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd7a42  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd7a4b  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd7a54  sub rsp, 0x40
00007f4f7cbd7a58  lea rdi, [rsp]
00007f4f7cbd7a5c  lea rsi, [rsp+0x10]
00007f4f7cbd7a61  lea rdx, [rsp+0x20]
00007f4f7cbd7a66  lea rcx, [rsp+0x30]
00007f4f7cbd7a6b  mov r8d, 0x00
00007f4f7cbd7a71  lea r9, [r15+0x3A8]
00007f4f7cbd7a78  movaps [rdi], xmm3
00007f4f7cbd7a7b  movaps [rsi], xmm13
00007f4f7cbd7a7f  movaps [rdx], xmm6
00007f4f7cbd7a82  movaps [rcx], xmm14
00007f4f7cbd7a86  mov rax, 0x643999485A50
00007f4f7cbd7a90  call rax
00007f4f7cbd7a92  movaps xmm3, [rsp]
00007f4f7cbd7a96  add rsp, 0x40
00007f4f7cbd7a9a  vmovaps xmm0, [rsp]
00007f4f7cbd7a9f  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd7aa5  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd7aab  vmovaps xmm4, [rsp+0x30]
00007f4f7cbd7ab1  vmovaps xmm5, [rsp+0x40]
00007f4f7cbd7ab7  vmovaps xmm6, [rsp+0x50]
00007f4f7cbd7abd  vmovaps xmm7, [rsp+0x60]
00007f4f7cbd7ac3  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd7ac9  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd7ad2  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd7adb  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd7ae4  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd7aed  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd7af6  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd7aff  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd7b08  add rsp, 0xF0
00007f4f7cbd7b0f  pop r11
00007f4f7cbd7b11  pop r10
00007f4f7cbd7b13  pop r9
00007f4f7cbd7b15  pop r8
00007f4f7cbd7b17  pop rsi
00007f4f7cbd7b18  pop rdi
00007f4f7cbd7b19  pop rdx
00007f4f7cbd7b1a  pop rcx
00007f4f7cbd7b1b  pop rax
00007f4f7cbd7b1c  add rsp, 0x08
00007f4f7cbd7b20  jmp 0x00007F4F7CBD680F
00007f4f7cbd7b25  sub rsp, 0x08
00007f4f7cbd7b29  push rax
00007f4f7cbd7b2a  push rcx
00007f4f7cbd7b2b  push rdx
00007f4f7cbd7b2c  push rdi
00007f4f7cbd7b2d  push rsi
00007f4f7cbd7b2e  push r8
00007f4f7cbd7b30  push r9
00007f4f7cbd7b32  push r10
00007f4f7cbd7b34  push r11
00007f4f7cbd7b36  sub rsp, 0xF0
00007f4f7cbd7b3d  vmovaps [rsp], xmm0
00007f4f7cbd7b42  vmovaps [rsp+0x10], xmm1
00007f4f7cbd7b48  vmovaps [rsp+0x20], xmm2
00007f4f7cbd7b4e  vmovaps [rsp+0x30], xmm3
00007f4f7cbd7b54  vmovaps [rsp+0x40], xmm4
00007f4f7cbd7b5a  vmovaps [rsp+0x50], xmm5
00007f4f7cbd7b60  vmovaps [rsp+0x60], xmm7
00007f4f7cbd7b66  vmovaps [rsp+0x70], xmm8
00007f4f7cbd7b6c  vmovaps [rsp+0x80], xmm9
00007f4f7cbd7b75  vmovaps [rsp+0x90], xmm10
00007f4f7cbd7b7e  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd7b87  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd7b90  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd7b99  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd7ba2  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd7bab  sub rsp, 0x40
00007f4f7cbd7baf  lea rdi, [rsp]
00007f4f7cbd7bb3  lea rsi, [rsp+0x10]
00007f4f7cbd7bb8  lea rdx, [rsp+0x20]
00007f4f7cbd7bbd  lea rcx, [rsp+0x30]
00007f4f7cbd7bc2  mov r8d, 0x00
00007f4f7cbd7bc8  lea r9, [r15+0x3A8]
00007f4f7cbd7bcf  movaps [rdi], xmm6
00007f4f7cbd7bd2  movaps [rsi], xmm2
00007f4f7cbd7bd5  movaps [rdx], xmm14
00007f4f7cbd7bd9  movaps [rcx], xmm1
00007f4f7cbd7bdc  mov rax, 0x643999485A50
00007f4f7cbd7be6  call rax
00007f4f7cbd7be8  movaps xmm6, [rsp]
00007f4f7cbd7bec  add rsp, 0x40
00007f4f7cbd7bf0  vmovaps xmm0, [rsp]
00007f4f7cbd7bf5  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd7bfb  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd7c01  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd7c07  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd7c0d  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd7c13  vmovaps xmm7, [rsp+0x60]
00007f4f7cbd7c19  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd7c1f  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd7c28  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd7c31  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd7c3a  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd7c43  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd7c4c  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd7c55  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd7c5e  add rsp, 0xF0
00007f4f7cbd7c65  pop r11
00007f4f7cbd7c67  pop r10
00007f4f7cbd7c69  pop r9
00007f4f7cbd7c6b  pop r8
00007f4f7cbd7c6d  pop rsi
00007f4f7cbd7c6e  pop rdi
00007f4f7cbd7c6f  pop rdx
00007f4f7cbd7c70  pop rcx
00007f4f7cbd7c71  pop rax
00007f4f7cbd7c72  add rsp, 0x08
00007f4f7cbd7c76  jmp 0x00007F4F7CBD683C
00007f4f7cbd7c7b  sub rsp, 0x08
00007f4f7cbd7c7f  push rax
00007f4f7cbd7c80  push rcx
00007f4f7cbd7c81  push rdx
00007f4f7cbd7c82  push rdi
00007f4f7cbd7c83  push rsi
00007f4f7cbd7c84  push r8
00007f4f7cbd7c86  push r9
00007f4f7cbd7c88  push r10
00007f4f7cbd7c8a  push r11
00007f4f7cbd7c8c  sub rsp, 0xF0
00007f4f7cbd7c93  vmovaps [rsp], xmm0
00007f4f7cbd7c98  vmovaps [rsp+0x10], xmm1
00007f4f7cbd7c9e  vmovaps [rsp+0x20], xmm2
00007f4f7cbd7ca4  vmovaps [rsp+0x30], xmm3
00007f4f7cbd7caa  vmovaps [rsp+0x40], xmm4
00007f4f7cbd7cb0  vmovaps [rsp+0x50], xmm5
00007f4f7cbd7cb6  vmovaps [rsp+0x60], xmm6
00007f4f7cbd7cbc  vmovaps [rsp+0x70], xmm7
00007f4f7cbd7cc2  vmovaps [rsp+0x80], xmm8
00007f4f7cbd7ccb  vmovaps [rsp+0x90], xmm9
00007f4f7cbd7cd4  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd7cdd  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd7ce6  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd7cef  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd7cf8  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd7d01  sub rsp, 0x40
00007f4f7cbd7d05  lea rdi, [rsp]
00007f4f7cbd7d09  lea rsi, [rsp+0x10]
00007f4f7cbd7d0e  lea rdx, [rsp+0x20]
00007f4f7cbd7d13  lea rcx, [rsp+0x30]
00007f4f7cbd7d18  mov r8d, 0x00
00007f4f7cbd7d1e  lea r9, [r15+0x3A8]
00007f4f7cbd7d25  movaps [rdi], xmm13
00007f4f7cbd7d29  movaps [rsi], xmm12
00007f4f7cbd7d2d  movaps [rdx], xmm14
00007f4f7cbd7d31  movaps [rcx], xmm1
00007f4f7cbd7d34  mov rax, 0x643999485A50
00007f4f7cbd7d3e  call rax
00007f4f7cbd7d40  movaps xmm13, [rsp]
00007f4f7cbd7d45  add rsp, 0x40
00007f4f7cbd7d49  vmovaps xmm0, [rsp]
00007f4f7cbd7d4e  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd7d54  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd7d5a  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd7d60  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd7d66  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd7d6c  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd7d72  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd7d78  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd7d81  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd7d8a  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd7d93  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd7d9c  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd7da5  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd7dae  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd7db7  add rsp, 0xF0
00007f4f7cbd7dbe  pop r11
00007f4f7cbd7dc0  pop r10
00007f4f7cbd7dc2  pop r9
00007f4f7cbd7dc4  pop r8
00007f4f7cbd7dc6  pop rsi
00007f4f7cbd7dc7  pop rdi
00007f4f7cbd7dc8  pop rdx
00007f4f7cbd7dc9  pop rcx
00007f4f7cbd7dca  pop rax
00007f4f7cbd7dcb  add rsp, 0x08
00007f4f7cbd7dcf  jmp 0x00007F4F7CBD686E
00007f4f7cbd7dd4  sub rsp, 0x08
00007f4f7cbd7dd8  push rax
00007f4f7cbd7dd9  push rcx
00007f4f7cbd7dda  push rdx
00007f4f7cbd7ddb  push rdi
00007f4f7cbd7ddc  push rsi
00007f4f7cbd7ddd  push r8
00007f4f7cbd7ddf  push r9
00007f4f7cbd7de1  push r10
00007f4f7cbd7de3  push r11
00007f4f7cbd7de5  sub rsp, 0xF0
00007f4f7cbd7dec  vmovaps [rsp], xmm0
00007f4f7cbd7df1  vmovaps [rsp+0x10], xmm1
00007f4f7cbd7df7  vmovaps [rsp+0x20], xmm2
00007f4f7cbd7dfd  vmovaps [rsp+0x30], xmm3
00007f4f7cbd7e03  vmovaps [rsp+0x40], xmm4
00007f4f7cbd7e09  vmovaps [rsp+0x50], xmm5
00007f4f7cbd7e0f  vmovaps [rsp+0x60], xmm6
00007f4f7cbd7e15  vmovaps [rsp+0x70], xmm7
00007f4f7cbd7e1b  vmovaps [rsp+0x80], xmm8
00007f4f7cbd7e24  vmovaps [rsp+0x90], xmm9
00007f4f7cbd7e2d  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd7e36  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd7e3f  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd7e48  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd7e51  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd7e5a  sub rsp, 0x40
00007f4f7cbd7e5e  lea rdi, [rsp]
00007f4f7cbd7e62  lea rsi, [rsp+0x10]
00007f4f7cbd7e67  lea rdx, [rsp+0x20]
00007f4f7cbd7e6c  lea rcx, [rsp+0x30]
00007f4f7cbd7e71  mov r8d, 0x00
00007f4f7cbd7e77  lea r9, [r15+0x3A8]
00007f4f7cbd7e7e  movaps [rdi], xmm12
00007f4f7cbd7e82  movaps [rsi], xmm3
00007f4f7cbd7e85  movaps [rdx], xmm14
00007f4f7cbd7e89  movaps [rcx], xmm5
00007f4f7cbd7e8c  mov rax, 0x643999485A50
00007f4f7cbd7e96  call rax
00007f4f7cbd7e98  movaps xmm12, [rsp]
00007f4f7cbd7e9d  add rsp, 0x40
00007f4f7cbd7ea1  vmovaps xmm0, [rsp]
00007f4f7cbd7ea6  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd7eac  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd7eb2  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd7eb8  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd7ebe  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd7ec4  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd7eca  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd7ed0  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd7ed9  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd7ee2  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd7eeb  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd7ef4  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd7efd  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd7f06  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd7f0f  add rsp, 0xF0
00007f4f7cbd7f16  pop r11
00007f4f7cbd7f18  pop r10
00007f4f7cbd7f1a  pop r9
00007f4f7cbd7f1c  pop r8
00007f4f7cbd7f1e  pop rsi
00007f4f7cbd7f1f  pop rdi
00007f4f7cbd7f20  pop rdx
00007f4f7cbd7f21  pop rcx
00007f4f7cbd7f22  pop rax
00007f4f7cbd7f23  add rsp, 0x08
00007f4f7cbd7f27  jmp 0x00007F4F7CBD68CB
00007f4f7cbd7f2c  sub rsp, 0x08
00007f4f7cbd7f30  push rax
00007f4f7cbd7f31  push rcx
00007f4f7cbd7f32  push rdx
00007f4f7cbd7f33  push rdi
00007f4f7cbd7f34  push rsi
00007f4f7cbd7f35  push r8
00007f4f7cbd7f37  push r9
00007f4f7cbd7f39  push r10
00007f4f7cbd7f3b  push r11
00007f4f7cbd7f3d  sub rsp, 0xF0
00007f4f7cbd7f44  vmovaps [rsp], xmm0
00007f4f7cbd7f49  vmovaps [rsp+0x10], xmm1
00007f4f7cbd7f4f  vmovaps [rsp+0x20], xmm2
00007f4f7cbd7f55  vmovaps [rsp+0x30], xmm3
00007f4f7cbd7f5b  vmovaps [rsp+0x40], xmm4
00007f4f7cbd7f61  vmovaps [rsp+0x50], xmm5
00007f4f7cbd7f67  vmovaps [rsp+0x60], xmm6
00007f4f7cbd7f6d  vmovaps [rsp+0x70], xmm7
00007f4f7cbd7f73  vmovaps [rsp+0x80], xmm8
00007f4f7cbd7f7c  vmovaps [rsp+0x90], xmm9
00007f4f7cbd7f85  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd7f8e  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd7f97  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd7fa0  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd7fa9  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd7fb2  sub rsp, 0x40
00007f4f7cbd7fb6  lea rdi, [rsp]
00007f4f7cbd7fba  lea rsi, [rsp+0x10]
00007f4f7cbd7fbf  lea rdx, [rsp+0x20]
00007f4f7cbd7fc4  lea rcx, [rsp+0x30]
00007f4f7cbd7fc9  mov r8d, 0x00
00007f4f7cbd7fcf  lea r9, [r15+0x3A8]
00007f4f7cbd7fd6  movaps [rdi], xmm10
00007f4f7cbd7fda  movaps [rsi], xmm9
00007f4f7cbd7fde  movaps [rdx], xmm7
00007f4f7cbd7fe1  movaps [rcx], xmm14
00007f4f7cbd7fe5  mov rax, 0x643999485A50
00007f4f7cbd7fef  call rax
00007f4f7cbd7ff1  movaps xmm10, [rsp]
00007f4f7cbd7ff6  add rsp, 0x40
00007f4f7cbd7ffa  vmovaps xmm0, [rsp]
00007f4f7cbd7fff  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd8005  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd800b  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd8011  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd8017  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd801d  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd8023  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd8029  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd8032  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd803b  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd8044  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd804d  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd8056  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd805f  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd8068  add rsp, 0xF0
00007f4f7cbd806f  pop r11
00007f4f7cbd8071  pop r10
00007f4f7cbd8073  pop r9
00007f4f7cbd8075  pop r8
00007f4f7cbd8077  pop rsi
00007f4f7cbd8078  pop rdi
00007f4f7cbd8079  pop rdx
00007f4f7cbd807a  pop rcx
00007f4f7cbd807b  pop rax
00007f4f7cbd807c  add rsp, 0x08
00007f4f7cbd8080  jmp 0x00007F4F7CBD68F1
00007f4f7cbd8085  call 0x00007F4F7CAE45A0
00007f4f7cbd808a  jmp 0x00007F4F7CBD68FE
00007f4f7cbd808f  sub rsp, 0x08
00007f4f7cbd8093  push rax
00007f4f7cbd8094  push rcx
00007f4f7cbd8095  push rdx
00007f4f7cbd8096  push rdi
00007f4f7cbd8097  push rsi
00007f4f7cbd8098  push r8
00007f4f7cbd809a  push r9
00007f4f7cbd809c  push r10
00007f4f7cbd809e  push r11
00007f4f7cbd80a0  sub rsp, 0xF0
00007f4f7cbd80a7  vmovaps [rsp], xmm0
00007f4f7cbd80ac  vmovaps [rsp+0x10], xmm1
00007f4f7cbd80b2  vmovaps [rsp+0x20], xmm2
00007f4f7cbd80b8  vmovaps [rsp+0x30], xmm3
00007f4f7cbd80be  vmovaps [rsp+0x40], xmm4
00007f4f7cbd80c4  vmovaps [rsp+0x50], xmm6
00007f4f7cbd80ca  vmovaps [rsp+0x60], xmm7
00007f4f7cbd80d0  vmovaps [rsp+0x70], xmm8
00007f4f7cbd80d6  vmovaps [rsp+0x80], xmm9
00007f4f7cbd80df  vmovaps [rsp+0x90], xmm10
00007f4f7cbd80e8  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd80f1  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd80fa  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd8103  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd810c  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd8115  sub rsp, 0x40
00007f4f7cbd8119  lea rdi, [rsp]
00007f4f7cbd811d  lea rsi, [rsp+0x10]
00007f4f7cbd8122  lea rdx, [rsp+0x20]
00007f4f7cbd8127  lea rcx, [rsp+0x30]
00007f4f7cbd812c  mov r8d, 0x00
00007f4f7cbd8132  lea r9, [r15+0x3A8]
00007f4f7cbd8139  movaps [rdi], xmm5
00007f4f7cbd813c  movaps [rsi], xmm6
00007f4f7cbd813f  movaps [rdx], xmm7
00007f4f7cbd8142  movaps [rcx], xmm9
00007f4f7cbd8146  mov rax, 0x643999485A50
00007f4f7cbd8150  call rax
00007f4f7cbd8152  movaps xmm5, [rsp]
00007f4f7cbd8156  add rsp, 0x40
00007f4f7cbd815a  vmovaps xmm0, [rsp]
00007f4f7cbd815f  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd8165  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd816b  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd8171  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd8177  vmovaps xmm6, [rsp+0x50]
00007f4f7cbd817d  vmovaps xmm7, [rsp+0x60]
00007f4f7cbd8183  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd8189  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd8192  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd819b  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd81a4  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd81ad  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd81b6  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd81bf  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd81c8  add rsp, 0xF0
00007f4f7cbd81cf  pop r11
00007f4f7cbd81d1  pop r10
00007f4f7cbd81d3  pop r9
00007f4f7cbd81d5  pop r8
00007f4f7cbd81d7  pop rsi
00007f4f7cbd81d8  pop rdi
00007f4f7cbd81d9  pop rdx
00007f4f7cbd81da  pop rcx
00007f4f7cbd81db  pop rax
00007f4f7cbd81dc  add rsp, 0x08
00007f4f7cbd81e0  jmp 0x00007F4F7CBD6930
00007f4f7cbd81e5  sub rsp, 0x08
00007f4f7cbd81e9  push rax
00007f4f7cbd81ea  push rcx
00007f4f7cbd81eb  push rdx
00007f4f7cbd81ec  push rdi
00007f4f7cbd81ed  push rsi
00007f4f7cbd81ee  push r8
00007f4f7cbd81f0  push r9
00007f4f7cbd81f2  push r10
00007f4f7cbd81f4  push r11
00007f4f7cbd81f6  sub rsp, 0xF0
00007f4f7cbd81fd  vmovaps [rsp], xmm0
00007f4f7cbd8202  vmovaps [rsp+0x10], xmm1
00007f4f7cbd8208  vmovaps [rsp+0x20], xmm2
00007f4f7cbd820e  vmovaps [rsp+0x30], xmm3
00007f4f7cbd8214  vmovaps [rsp+0x40], xmm4
00007f4f7cbd821a  vmovaps [rsp+0x50], xmm5
00007f4f7cbd8220  vmovaps [rsp+0x60], xmm6
00007f4f7cbd8226  vmovaps [rsp+0x70], xmm8
00007f4f7cbd822c  vmovaps [rsp+0x80], xmm9
00007f4f7cbd8235  vmovaps [rsp+0x90], xmm10
00007f4f7cbd823e  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd8247  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd8250  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd8259  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd8262  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd826b  sub rsp, 0x40
00007f4f7cbd826f  lea rdi, [rsp]
00007f4f7cbd8273  lea rsi, [rsp+0x10]
00007f4f7cbd8278  lea rdx, [rsp+0x20]
00007f4f7cbd827d  lea rcx, [rsp+0x30]
00007f4f7cbd8282  mov r8d, 0x00
00007f4f7cbd8288  lea r9, [r15+0x3A8]
00007f4f7cbd828f  movaps [rdi], xmm7
00007f4f7cbd8292  movaps [rsi], xmm13
00007f4f7cbd8296  movaps [rdx], xmm1
00007f4f7cbd8299  movaps [rcx], xmm9
00007f4f7cbd829d  mov rax, 0x643999485A50
00007f4f7cbd82a7  call rax
00007f4f7cbd82a9  movaps xmm7, [rsp]
00007f4f7cbd82ad  add rsp, 0x40
00007f4f7cbd82b1  vmovaps xmm0, [rsp]
00007f4f7cbd82b6  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd82bc  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd82c2  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd82c8  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd82ce  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd82d4  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd82da  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd82e0  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd82e9  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd82f2  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd82fb  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd8304  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd830d  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd8316  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd831f  add rsp, 0xF0
00007f4f7cbd8326  pop r11
00007f4f7cbd8328  pop r10
00007f4f7cbd832a  pop r9
00007f4f7cbd832c  pop r8
00007f4f7cbd832e  pop rsi
00007f4f7cbd832f  pop rdi
00007f4f7cbd8330  pop rdx
00007f4f7cbd8331  pop rcx
00007f4f7cbd8332  pop rax
00007f4f7cbd8333  add rsp, 0x08
00007f4f7cbd8337  jmp 0x00007F4F7CBD6955
00007f4f7cbd833c  call 0x00007F4F7CAE3320
00007f4f7cbd8341  jmp 0x00007F4F7CBD6978
00007f4f7cbd8346  call 0x00007F4F7CADE950
00007f4f7cbd834b  jmp 0x00007F4F7CBD6982
00007f4f7cbd8350  sub rsp, 0x08
00007f4f7cbd8354  push rax
00007f4f7cbd8355  push rcx
00007f4f7cbd8356  push rdx
00007f4f7cbd8357  push rdi
00007f4f7cbd8358  push rsi
00007f4f7cbd8359  push r8
00007f4f7cbd835b  push r9
00007f4f7cbd835d  push r10
00007f4f7cbd835f  push r11
00007f4f7cbd8361  sub rsp, 0xF0
00007f4f7cbd8368  vmovaps [rsp], xmm0
00007f4f7cbd836d  vmovaps [rsp+0x10], xmm1
00007f4f7cbd8373  vmovaps [rsp+0x20], xmm3
00007f4f7cbd8379  vmovaps [rsp+0x30], xmm4
00007f4f7cbd837f  vmovaps [rsp+0x40], xmm5
00007f4f7cbd8385  vmovaps [rsp+0x50], xmm6
00007f4f7cbd838b  vmovaps [rsp+0x60], xmm7
00007f4f7cbd8391  vmovaps [rsp+0x70], xmm8
00007f4f7cbd8397  vmovaps [rsp+0x80], xmm9
00007f4f7cbd83a0  vmovaps [rsp+0x90], xmm10
00007f4f7cbd83a9  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd83b2  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd83bb  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd83c4  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd83cd  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd83d6  sub rsp, 0x40
00007f4f7cbd83da  lea rdi, [rsp]
00007f4f7cbd83de  lea rsi, [rsp+0x10]
00007f4f7cbd83e3  lea rdx, [rsp+0x20]
00007f4f7cbd83e8  lea rcx, [rsp+0x30]
00007f4f7cbd83ed  mov r8d, 0x00
00007f4f7cbd83f3  lea r9, [r15+0x3A8]
00007f4f7cbd83fa  movaps [rdi], xmm2
00007f4f7cbd83fd  movaps [rsi], xmm12
00007f4f7cbd8401  movaps [rdx], xmm6
00007f4f7cbd8404  movaps [rcx], xmm3
00007f4f7cbd8407  mov rax, 0x643999485A50
00007f4f7cbd8411  call rax
00007f4f7cbd8413  movaps xmm2, [rsp]
00007f4f7cbd8417  add rsp, 0x40
00007f4f7cbd841b  vmovaps xmm0, [rsp]
00007f4f7cbd8420  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd8426  vmovaps xmm3, [rsp+0x20]
00007f4f7cbd842c  vmovaps xmm4, [rsp+0x30]
00007f4f7cbd8432  vmovaps xmm5, [rsp+0x40]
00007f4f7cbd8438  vmovaps xmm6, [rsp+0x50]
00007f4f7cbd843e  vmovaps xmm7, [rsp+0x60]
00007f4f7cbd8444  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd844a  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd8453  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd845c  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd8465  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd846e  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd8477  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd8480  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd8489  add rsp, 0xF0
00007f4f7cbd8490  pop r11
00007f4f7cbd8492  pop r10
00007f4f7cbd8494  pop r9
00007f4f7cbd8496  pop r8
00007f4f7cbd8498  pop rsi
00007f4f7cbd8499  pop rdi
00007f4f7cbd849a  pop rdx
00007f4f7cbd849b  pop rcx
00007f4f7cbd849c  pop rax
00007f4f7cbd849d  add rsp, 0x08
00007f4f7cbd84a1  jmp 0x00007F4F7CBD69C8
00007f4f7cbd84a6  sub rsp, 0x08
00007f4f7cbd84aa  push rax
00007f4f7cbd84ab  push rcx
00007f4f7cbd84ac  push rdx
00007f4f7cbd84ad  push rdi
00007f4f7cbd84ae  push rsi
00007f4f7cbd84af  push r8
00007f4f7cbd84b1  push r9
00007f4f7cbd84b3  push r10
00007f4f7cbd84b5  push r11
00007f4f7cbd84b7  sub rsp, 0xF0
00007f4f7cbd84be  vmovaps [rsp], xmm0
00007f4f7cbd84c3  vmovaps [rsp+0x10], xmm1
00007f4f7cbd84c9  vmovaps [rsp+0x20], xmm2
00007f4f7cbd84cf  vmovaps [rsp+0x30], xmm3
00007f4f7cbd84d5  vmovaps [rsp+0x40], xmm4
00007f4f7cbd84db  vmovaps [rsp+0x50], xmm5
00007f4f7cbd84e1  vmovaps [rsp+0x60], xmm7
00007f4f7cbd84e7  vmovaps [rsp+0x70], xmm8
00007f4f7cbd84ed  vmovaps [rsp+0x80], xmm9
00007f4f7cbd84f6  vmovaps [rsp+0x90], xmm10
00007f4f7cbd84ff  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd8508  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd8511  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd851a  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd8523  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd852c  sub rsp, 0x40
00007f4f7cbd8530  lea rdi, [rsp]
00007f4f7cbd8534  lea rsi, [rsp+0x10]
00007f4f7cbd8539  lea rdx, [rsp+0x20]
00007f4f7cbd853e  lea rcx, [rsp+0x30]
00007f4f7cbd8543  mov r8d, 0x00
00007f4f7cbd8549  lea r9, [r15+0x3A8]
00007f4f7cbd8550  movaps [rdi], xmm6
00007f4f7cbd8553  movaps [rsi], xmm10
00007f4f7cbd8557  movaps [rdx], xmm12
00007f4f7cbd855b  movaps [rcx], xmm1
00007f4f7cbd855e  mov rax, 0x643999485A50
00007f4f7cbd8568  call rax
00007f4f7cbd856a  movaps xmm6, [rsp]
00007f4f7cbd856e  add rsp, 0x40
00007f4f7cbd8572  vmovaps xmm0, [rsp]
00007f4f7cbd8577  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd857d  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd8583  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd8589  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd858f  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd8595  vmovaps xmm7, [rsp+0x60]
00007f4f7cbd859b  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd85a1  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd85aa  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd85b3  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd85bc  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd85c5  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd85ce  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd85d7  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd85e0  add rsp, 0xF0
00007f4f7cbd85e7  pop r11
00007f4f7cbd85e9  pop r10
00007f4f7cbd85eb  pop r9
00007f4f7cbd85ed  pop r8
00007f4f7cbd85ef  pop rsi
00007f4f7cbd85f0  pop rdi
00007f4f7cbd85f1  pop rdx
00007f4f7cbd85f2  pop rcx
00007f4f7cbd85f3  pop rax
00007f4f7cbd85f4  add rsp, 0x08
00007f4f7cbd85f8  jmp 0x00007F4F7CBD69F6
00007f4f7cbd85fd  sub rsp, 0x08
00007f4f7cbd8601  push rax
00007f4f7cbd8602  push rcx
00007f4f7cbd8603  push rdx
00007f4f7cbd8604  push rdi
00007f4f7cbd8605  push rsi
00007f4f7cbd8606  push r8
00007f4f7cbd8608  push r9
00007f4f7cbd860a  push r10
00007f4f7cbd860c  push r11
00007f4f7cbd860e  sub rsp, 0xF0
00007f4f7cbd8615  vmovaps [rsp], xmm0
00007f4f7cbd861a  vmovaps [rsp+0x10], xmm1
00007f4f7cbd8620  vmovaps [rsp+0x20], xmm2
00007f4f7cbd8626  vmovaps [rsp+0x30], xmm3
00007f4f7cbd862c  vmovaps [rsp+0x40], xmm4
00007f4f7cbd8632  vmovaps [rsp+0x50], xmm5
00007f4f7cbd8638  vmovaps [rsp+0x60], xmm6
00007f4f7cbd863e  vmovaps [rsp+0x70], xmm7
00007f4f7cbd8644  vmovaps [rsp+0x80], xmm8
00007f4f7cbd864d  vmovaps [rsp+0x90], xmm9
00007f4f7cbd8656  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd865f  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd8668  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd8671  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd867a  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd8683  sub rsp, 0x40
00007f4f7cbd8687  lea rdi, [rsp]
00007f4f7cbd868b  lea rsi, [rsp+0x10]
00007f4f7cbd8690  lea rdx, [rsp+0x20]
00007f4f7cbd8695  lea rcx, [rsp+0x30]
00007f4f7cbd869a  mov r8d, 0x00
00007f4f7cbd86a0  lea r9, [r15+0x3A8]
00007f4f7cbd86a7  movaps [rdi], xmm10
00007f4f7cbd86ab  movaps [rsi], xmm5
00007f4f7cbd86ae  movaps [rdx], xmm12
00007f4f7cbd86b2  movaps [rcx], xmm1
00007f4f7cbd86b5  mov rax, 0x643999485A50
00007f4f7cbd86bf  call rax
00007f4f7cbd86c1  movaps xmm10, [rsp]
00007f4f7cbd86c6  add rsp, 0x40
00007f4f7cbd86ca  vmovaps xmm0, [rsp]
00007f4f7cbd86cf  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd86d5  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd86db  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd86e1  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd86e7  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd86ed  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd86f3  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd86f9  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd8702  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd870b  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd8714  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd871d  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd8726  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd872f  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd8738  add rsp, 0xF0
00007f4f7cbd873f  pop r11
00007f4f7cbd8741  pop r10
00007f4f7cbd8743  pop r9
00007f4f7cbd8745  pop r8
00007f4f7cbd8747  pop rsi
00007f4f7cbd8748  pop rdi
00007f4f7cbd8749  pop rdx
00007f4f7cbd874a  pop rcx
00007f4f7cbd874b  pop rax
00007f4f7cbd874c  add rsp, 0x08
00007f4f7cbd8750  jmp 0x00007F4F7CBD6A25
00007f4f7cbd8755  sub rsp, 0x08
00007f4f7cbd8759  push rax
00007f4f7cbd875a  push rcx
00007f4f7cbd875b  push rdx
00007f4f7cbd875c  push rdi
00007f4f7cbd875d  push rsi
00007f4f7cbd875e  push r8
00007f4f7cbd8760  push r9
00007f4f7cbd8762  push r10
00007f4f7cbd8764  push r11
00007f4f7cbd8766  sub rsp, 0xF0
00007f4f7cbd876d  vmovaps [rsp], xmm0
00007f4f7cbd8772  vmovaps [rsp+0x10], xmm1
00007f4f7cbd8778  vmovaps [rsp+0x20], xmm2
00007f4f7cbd877e  vmovaps [rsp+0x30], xmm3
00007f4f7cbd8784  vmovaps [rsp+0x40], xmm4
00007f4f7cbd878a  vmovaps [rsp+0x50], xmm5
00007f4f7cbd8790  vmovaps [rsp+0x60], xmm6
00007f4f7cbd8796  vmovaps [rsp+0x70], xmm7
00007f4f7cbd879c  vmovaps [rsp+0x80], xmm8
00007f4f7cbd87a5  vmovaps [rsp+0x90], xmm9
00007f4f7cbd87ae  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd87b7  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd87c0  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd87c9  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd87d2  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd87db  sub rsp, 0x40
00007f4f7cbd87df  lea rdi, [rsp]
00007f4f7cbd87e3  lea rsi, [rsp+0x10]
00007f4f7cbd87e8  lea rdx, [rsp+0x20]
00007f4f7cbd87ed  lea rcx, [rsp+0x30]
00007f4f7cbd87f2  mov r8d, 0x00
00007f4f7cbd87f8  lea r9, [r15+0x3A8]
00007f4f7cbd87ff  movaps [rdi], xmm12
00007f4f7cbd8803  movaps [rsi], xmm7
00007f4f7cbd8806  movaps [rdx], xmm15
00007f4f7cbd880a  movaps [rcx], xmm1
00007f4f7cbd880d  mov rax, 0x643999485A50
00007f4f7cbd8817  call rax
00007f4f7cbd8819  movaps xmm12, [rsp]
00007f4f7cbd881e  add rsp, 0x40
00007f4f7cbd8822  vmovaps xmm0, [rsp]
00007f4f7cbd8827  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd882d  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd8833  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd8839  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd883f  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd8845  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd884b  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd8851  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd885a  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd8863  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd886c  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd8875  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd887e  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd8887  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd8890  add rsp, 0xF0
00007f4f7cbd8897  pop r11
00007f4f7cbd8899  pop r10
00007f4f7cbd889b  pop r9
00007f4f7cbd889d  pop r8
00007f4f7cbd889f  pop rsi
00007f4f7cbd88a0  pop rdi
00007f4f7cbd88a1  pop rdx
00007f4f7cbd88a2  pop rcx
00007f4f7cbd88a3  pop rax
00007f4f7cbd88a4  add rsp, 0x08
00007f4f7cbd88a8  jmp 0x00007F4F7CBD6A4E
00007f4f7cbd88ad  call 0x00007F4F7CAD64F0
00007f4f7cbd88b2  jmp 0x00007F4F7CBD6A58
00007f4f7cbd88b7  call 0x00007F4F7CAE5820
00007f4f7cbd88bc  jmp 0x00007F4F7CBD6A62
00007f4f7cbd88c1  sub rsp, 0x08
00007f4f7cbd88c5  push rax
00007f4f7cbd88c6  push rcx
00007f4f7cbd88c7  push rdx
00007f4f7cbd88c8  push rdi
00007f4f7cbd88c9  push rsi
00007f4f7cbd88ca  push r8
00007f4f7cbd88cc  push r9
00007f4f7cbd88ce  push r10
00007f4f7cbd88d0  push r11
00007f4f7cbd88d2  sub rsp, 0xF0
00007f4f7cbd88d9  vmovaps [rsp], xmm0
00007f4f7cbd88de  vmovaps [rsp+0x10], xmm1
00007f4f7cbd88e4  vmovaps [rsp+0x20], xmm2
00007f4f7cbd88ea  vmovaps [rsp+0x30], xmm3
00007f4f7cbd88f0  vmovaps [rsp+0x40], xmm4
00007f4f7cbd88f6  vmovaps [rsp+0x50], xmm5
00007f4f7cbd88fc  vmovaps [rsp+0x60], xmm6
00007f4f7cbd8902  vmovaps [rsp+0x70], xmm8
00007f4f7cbd8908  vmovaps [rsp+0x80], xmm9
00007f4f7cbd8911  vmovaps [rsp+0x90], xmm10
00007f4f7cbd891a  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd8923  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd892c  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd8935  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd893e  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd8947  sub rsp, 0x40
00007f4f7cbd894b  lea rdi, [rsp]
00007f4f7cbd894f  lea rsi, [rsp+0x10]
00007f4f7cbd8954  lea rdx, [rsp+0x20]
00007f4f7cbd8959  lea rcx, [rsp+0x30]
00007f4f7cbd895e  mov r8d, 0x00
00007f4f7cbd8964  lea r9, [r15+0x3A8]
00007f4f7cbd896b  movaps [rdi], xmm7
00007f4f7cbd896e  movaps [rsi], xmm2
00007f4f7cbd8971  movaps [rdx], xmm9
00007f4f7cbd8975  movaps [rcx], xmm11
00007f4f7cbd8979  mov rax, 0x643999485A50
00007f4f7cbd8983  call rax
00007f4f7cbd8985  movaps xmm7, [rsp]
00007f4f7cbd8989  add rsp, 0x40
00007f4f7cbd898d  vmovaps xmm0, [rsp]
00007f4f7cbd8992  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd8998  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd899e  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd89a4  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd89aa  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd89b0  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd89b6  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd89bc  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd89c5  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd89ce  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd89d7  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd89e0  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd89e9  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd89f2  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd89fb  add rsp, 0xF0
00007f4f7cbd8a02  pop r11
00007f4f7cbd8a04  pop r10
00007f4f7cbd8a06  pop r9
00007f4f7cbd8a08  pop r8
00007f4f7cbd8a0a  pop rsi
00007f4f7cbd8a0b  pop rdi
00007f4f7cbd8a0c  pop rdx
00007f4f7cbd8a0d  pop rcx
00007f4f7cbd8a0e  pop rax
00007f4f7cbd8a0f  add rsp, 0x08
00007f4f7cbd8a13  jmp 0x00007F4F7CBD6A96
00007f4f7cbd8a18  sub rsp, 0x08
00007f4f7cbd8a1c  push rax
00007f4f7cbd8a1d  push rcx
00007f4f7cbd8a1e  push rdx
00007f4f7cbd8a1f  push rdi
00007f4f7cbd8a20  push rsi
00007f4f7cbd8a21  push r8
00007f4f7cbd8a23  push r9
00007f4f7cbd8a25  push r10
00007f4f7cbd8a27  push r11
00007f4f7cbd8a29  sub rsp, 0xF0
00007f4f7cbd8a30  vmovaps [rsp], xmm0
00007f4f7cbd8a35  vmovaps [rsp+0x10], xmm1
00007f4f7cbd8a3b  vmovaps [rsp+0x20], xmm2
00007f4f7cbd8a41  vmovaps [rsp+0x30], xmm3
00007f4f7cbd8a47  vmovaps [rsp+0x40], xmm4
00007f4f7cbd8a4d  vmovaps [rsp+0x50], xmm5
00007f4f7cbd8a53  vmovaps [rsp+0x60], xmm6
00007f4f7cbd8a59  vmovaps [rsp+0x70], xmm7
00007f4f7cbd8a5f  vmovaps [rsp+0x80], xmm8
00007f4f7cbd8a68  vmovaps [rsp+0x90], xmm10
00007f4f7cbd8a71  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd8a7a  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd8a83  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd8a8c  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd8a95  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd8a9e  sub rsp, 0x40
00007f4f7cbd8aa2  lea rdi, [rsp]
00007f4f7cbd8aa6  lea rsi, [rsp+0x10]
00007f4f7cbd8aab  lea rdx, [rsp+0x20]
00007f4f7cbd8ab0  lea rcx, [rsp+0x30]
00007f4f7cbd8ab5  mov r8d, 0x00
00007f4f7cbd8abb  lea r9, [r15+0x3A8]
00007f4f7cbd8ac2  movaps [rdi], xmm9
00007f4f7cbd8ac6  movaps [rsi], xmm6
00007f4f7cbd8ac9  movaps [rdx], xmm1
00007f4f7cbd8acc  movaps [rcx], xmm11
00007f4f7cbd8ad0  mov rax, 0x643999485A50
00007f4f7cbd8ada  call rax
00007f4f7cbd8adc  movaps xmm9, [rsp]
00007f4f7cbd8ae1  add rsp, 0x40
00007f4f7cbd8ae5  vmovaps xmm0, [rsp]
00007f4f7cbd8aea  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd8af0  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd8af6  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd8afc  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd8b02  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd8b08  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd8b0e  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd8b14  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd8b1d  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd8b26  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd8b2f  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd8b38  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd8b41  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd8b4a  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd8b53  add rsp, 0xF0
00007f4f7cbd8b5a  pop r11
00007f4f7cbd8b5c  pop r10
00007f4f7cbd8b5e  pop r9
00007f4f7cbd8b60  pop r8
00007f4f7cbd8b62  pop rsi
00007f4f7cbd8b63  pop rdi
00007f4f7cbd8b64  pop rdx
00007f4f7cbd8b65  pop rcx
00007f4f7cbd8b66  pop rax
00007f4f7cbd8b67  add rsp, 0x08
00007f4f7cbd8b6b  jmp 0x00007F4F7CBD6ABC
00007f4f7cbd8b70  sub rsp, 0x08
00007f4f7cbd8b74  push rax
00007f4f7cbd8b75  push rcx
00007f4f7cbd8b76  push rdx
00007f4f7cbd8b77  push rdi
00007f4f7cbd8b78  push rsi
00007f4f7cbd8b79  push r8
00007f4f7cbd8b7b  push r9
00007f4f7cbd8b7d  push r10
00007f4f7cbd8b7f  push r11
00007f4f7cbd8b81  sub rsp, 0xF0
00007f4f7cbd8b88  vmovaps [rsp], xmm0
00007f4f7cbd8b8d  vmovaps [rsp+0x10], xmm1
00007f4f7cbd8b93  vmovaps [rsp+0x20], xmm2
00007f4f7cbd8b99  vmovaps [rsp+0x30], xmm3
00007f4f7cbd8b9f  vmovaps [rsp+0x40], xmm4
00007f4f7cbd8ba5  vmovaps [rsp+0x50], xmm5
00007f4f7cbd8bab  vmovaps [rsp+0x60], xmm6
00007f4f7cbd8bb1  vmovaps [rsp+0x70], xmm7
00007f4f7cbd8bb7  vmovaps [rsp+0x80], xmm8
00007f4f7cbd8bc0  vmovaps [rsp+0x90], xmm9
00007f4f7cbd8bc9  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd8bd2  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd8bdb  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd8be4  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd8bed  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd8bf6  sub rsp, 0x40
00007f4f7cbd8bfa  lea rdi, [rsp]
00007f4f7cbd8bfe  lea rsi, [rsp+0x10]
00007f4f7cbd8c03  lea rdx, [rsp+0x20]
00007f4f7cbd8c08  lea rcx, [rsp+0x30]
00007f4f7cbd8c0d  mov r8d, 0x00
00007f4f7cbd8c13  lea r9, [r15+0x3A8]
00007f4f7cbd8c1a  movaps [rdi], xmm11
00007f4f7cbd8c1e  movaps [rsi], xmm10
00007f4f7cbd8c22  movaps [rdx], xmm8
00007f4f7cbd8c26  movaps [rcx], xmm1
00007f4f7cbd8c29  mov rax, 0x643999485A50
00007f4f7cbd8c33  call rax
00007f4f7cbd8c35  movaps xmm11, [rsp]
00007f4f7cbd8c3a  add rsp, 0x40
00007f4f7cbd8c3e  vmovaps xmm0, [rsp]
00007f4f7cbd8c43  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd8c49  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd8c4f  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd8c55  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd8c5b  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd8c61  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd8c67  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd8c6d  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd8c76  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd8c7f  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd8c88  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd8c91  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd8c9a  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd8ca3  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd8cac  add rsp, 0xF0
00007f4f7cbd8cb3  pop r11
00007f4f7cbd8cb5  pop r10
00007f4f7cbd8cb7  pop r9
00007f4f7cbd8cb9  pop r8
00007f4f7cbd8cbb  pop rsi
00007f4f7cbd8cbc  pop rdi
00007f4f7cbd8cbd  pop rdx
00007f4f7cbd8cbe  pop rcx
00007f4f7cbd8cbf  pop rax
00007f4f7cbd8cc0  add rsp, 0x08
00007f4f7cbd8cc4  jmp 0x00007F4F7CBD6AE2
00007f4f7cbd8cc9  sub rsp, 0x08
00007f4f7cbd8ccd  push rax
00007f4f7cbd8cce  push rcx
00007f4f7cbd8ccf  push rdx
00007f4f7cbd8cd0  push rdi
00007f4f7cbd8cd1  push rsi
00007f4f7cbd8cd2  push r8
00007f4f7cbd8cd4  push r9
00007f4f7cbd8cd6  push r10
00007f4f7cbd8cd8  push r11
00007f4f7cbd8cda  sub rsp, 0xF0
00007f4f7cbd8ce1  vmovaps [rsp], xmm0
00007f4f7cbd8ce6  vmovaps [rsp+0x10], xmm1
00007f4f7cbd8cec  vmovaps [rsp+0x20], xmm2
00007f4f7cbd8cf2  vmovaps [rsp+0x30], xmm3
00007f4f7cbd8cf8  vmovaps [rsp+0x40], xmm4
00007f4f7cbd8cfe  vmovaps [rsp+0x50], xmm5
00007f4f7cbd8d04  vmovaps [rsp+0x60], xmm6
00007f4f7cbd8d0a  vmovaps [rsp+0x70], xmm7
00007f4f7cbd8d10  vmovaps [rsp+0x80], xmm8
00007f4f7cbd8d19  vmovaps [rsp+0x90], xmm9
00007f4f7cbd8d22  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd8d2b  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd8d34  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd8d3d  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd8d46  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd8d4f  sub rsp, 0x40
00007f4f7cbd8d53  lea rdi, [rsp]
00007f4f7cbd8d57  lea rsi, [rsp+0x10]
00007f4f7cbd8d5c  lea rdx, [rsp+0x20]
00007f4f7cbd8d61  lea rcx, [rsp+0x30]
00007f4f7cbd8d66  mov r8d, 0x00
00007f4f7cbd8d6c  lea r9, [r15+0x3A8]
00007f4f7cbd8d73  movaps [rdi], xmm10
00007f4f7cbd8d77  movaps [rsi], xmm12
00007f4f7cbd8d7b  movaps [rdx], xmm13
00007f4f7cbd8d7f  movaps [rcx], xmm1
00007f4f7cbd8d82  mov rax, 0x643999485A50
00007f4f7cbd8d8c  call rax
00007f4f7cbd8d8e  movaps xmm10, [rsp]
00007f4f7cbd8d93  add rsp, 0x40
00007f4f7cbd8d97  vmovaps xmm0, [rsp]
00007f4f7cbd8d9c  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd8da2  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd8da8  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd8dae  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd8db4  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd8dba  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd8dc0  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd8dc6  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd8dcf  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd8dd8  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd8de1  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd8dea  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd8df3  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd8dfc  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd8e05  add rsp, 0xF0
00007f4f7cbd8e0c  pop r11
00007f4f7cbd8e0e  pop r10
00007f4f7cbd8e10  pop r9
00007f4f7cbd8e12  pop r8
00007f4f7cbd8e14  pop rsi
00007f4f7cbd8e15  pop rdi
00007f4f7cbd8e16  pop rdx
00007f4f7cbd8e17  pop rcx
00007f4f7cbd8e18  pop rax
00007f4f7cbd8e19  add rsp, 0x08
00007f4f7cbd8e1d  jmp 0x00007F4F7CBD6B08
00007f4f7cbd8e22  call 0x00007F4F7CAD64F0
00007f4f7cbd8e27  jmp 0x00007F4F7CBD6B12
00007f4f7cbd8e2c  call 0x00007F4F7CAE3320
00007f4f7cbd8e31  jmp 0x00007F4F7CBD6B1C
00007f4f7cbd8e36  sub rsp, 0x08
00007f4f7cbd8e3a  push rax
00007f4f7cbd8e3b  push rcx
00007f4f7cbd8e3c  push rdx
00007f4f7cbd8e3d  push rdi
00007f4f7cbd8e3e  push rsi
00007f4f7cbd8e3f  push r8
00007f4f7cbd8e41  push r9
00007f4f7cbd8e43  push r10
00007f4f7cbd8e45  push r11
00007f4f7cbd8e47  sub rsp, 0xF0
00007f4f7cbd8e4e  vmovaps [rsp], xmm0
00007f4f7cbd8e53  vmovaps [rsp+0x10], xmm1
00007f4f7cbd8e59  vmovaps [rsp+0x20], xmm2
00007f4f7cbd8e5f  vmovaps [rsp+0x30], xmm3
00007f4f7cbd8e65  vmovaps [rsp+0x40], xmm4
00007f4f7cbd8e6b  vmovaps [rsp+0x50], xmm5
00007f4f7cbd8e71  vmovaps [rsp+0x60], xmm6
00007f4f7cbd8e77  vmovaps [rsp+0x70], xmm7
00007f4f7cbd8e7d  vmovaps [rsp+0x80], xmm9
00007f4f7cbd8e86  vmovaps [rsp+0x90], xmm10
00007f4f7cbd8e8f  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd8e98  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd8ea1  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd8eaa  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd8eb3  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd8ebc  sub rsp, 0x40
00007f4f7cbd8ec0  lea rdi, [rsp]
00007f4f7cbd8ec4  lea rsi, [rsp+0x10]
00007f4f7cbd8ec9  lea rdx, [rsp+0x20]
00007f4f7cbd8ece  lea rcx, [rsp+0x30]
00007f4f7cbd8ed3  mov r8d, 0x00
00007f4f7cbd8ed9  lea r9, [r15+0x3A8]
00007f4f7cbd8ee0  movaps [rdi], xmm8
00007f4f7cbd8ee4  movaps [rsi], xmm7
00007f4f7cbd8ee7  movaps [rdx], xmm4
00007f4f7cbd8eea  movaps [rcx], xmm12
00007f4f7cbd8eee  mov rax, 0x643999485A50
00007f4f7cbd8ef8  call rax
00007f4f7cbd8efa  movaps xmm8, [rsp]
00007f4f7cbd8eff  add rsp, 0x40
00007f4f7cbd8f03  vmovaps xmm0, [rsp]
00007f4f7cbd8f08  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd8f0e  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd8f14  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd8f1a  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd8f20  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd8f26  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd8f2c  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd8f32  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd8f3b  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd8f44  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd8f4d  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd8f56  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd8f5f  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd8f68  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd8f71  add rsp, 0xF0
00007f4f7cbd8f78  pop r11
00007f4f7cbd8f7a  pop r10
00007f4f7cbd8f7c  pop r9
00007f4f7cbd8f7e  pop r8
00007f4f7cbd8f80  pop rsi
00007f4f7cbd8f81  pop rdi
00007f4f7cbd8f82  pop rdx
00007f4f7cbd8f83  pop rcx
00007f4f7cbd8f84  pop rax
00007f4f7cbd8f85  add rsp, 0x08
00007f4f7cbd8f89  jmp 0x00007F4F7CBD6B45
00007f4f7cbd8f8e  sub rsp, 0x08
00007f4f7cbd8f92  push rax
00007f4f7cbd8f93  push rcx
00007f4f7cbd8f94  push rdx
00007f4f7cbd8f95  push rdi
00007f4f7cbd8f96  push rsi
00007f4f7cbd8f97  push r8
00007f4f7cbd8f99  push r9
00007f4f7cbd8f9b  push r10
00007f4f7cbd8f9d  push r11
00007f4f7cbd8f9f  sub rsp, 0xF0
00007f4f7cbd8fa6  vmovaps [rsp], xmm0
00007f4f7cbd8fab  vmovaps [rsp+0x10], xmm1
00007f4f7cbd8fb1  vmovaps [rsp+0x20], xmm2
00007f4f7cbd8fb7  vmovaps [rsp+0x30], xmm3
00007f4f7cbd8fbd  vmovaps [rsp+0x40], xmm4
00007f4f7cbd8fc3  vmovaps [rsp+0x50], xmm5
00007f4f7cbd8fc9  vmovaps [rsp+0x60], xmm6
00007f4f7cbd8fcf  vmovaps [rsp+0x70], xmm8
00007f4f7cbd8fd5  vmovaps [rsp+0x80], xmm9
00007f4f7cbd8fde  vmovaps [rsp+0x90], xmm10
00007f4f7cbd8fe7  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd8ff0  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd8ff9  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd9002  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd900b  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd9014  sub rsp, 0x40
00007f4f7cbd9018  lea rdi, [rsp]
00007f4f7cbd901c  lea rsi, [rsp+0x10]
00007f4f7cbd9021  lea rdx, [rsp+0x20]
00007f4f7cbd9026  lea rcx, [rsp+0x30]
00007f4f7cbd902b  mov r8d, 0x00
00007f4f7cbd9031  lea r9, [r15+0x3A8]
00007f4f7cbd9038  movaps [rdi], xmm7
00007f4f7cbd903b  movaps [rsi], xmm9
00007f4f7cbd903f  movaps [rdx], xmm14
00007f4f7cbd9043  movaps [rcx], xmm12
00007f4f7cbd9047  mov rax, 0x643999485A50
00007f4f7cbd9051  call rax
00007f4f7cbd9053  movaps xmm7, [rsp]
00007f4f7cbd9057  add rsp, 0x40
00007f4f7cbd905b  vmovaps xmm0, [rsp]
00007f4f7cbd9060  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd9066  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd906c  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd9072  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd9078  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd907e  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd9084  vmovaps xmm8, [rsp+0x70]
00007f4f7cbd908a  vmovaps xmm9, [rsp+0x80]
00007f4f7cbd9093  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd909c  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd90a5  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd90ae  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd90b7  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd90c0  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd90c9  add rsp, 0xF0
00007f4f7cbd90d0  pop r11
00007f4f7cbd90d2  pop r10
00007f4f7cbd90d4  pop r9
00007f4f7cbd90d6  pop r8
00007f4f7cbd90d8  pop rsi
00007f4f7cbd90d9  pop rdi
00007f4f7cbd90da  pop rdx
00007f4f7cbd90db  pop rcx
00007f4f7cbd90dc  pop rax
00007f4f7cbd90dd  add rsp, 0x08
00007f4f7cbd90e1  jmp 0x00007F4F7CBD6B6D
00007f4f7cbd90e6  sub rsp, 0x08
00007f4f7cbd90ea  push rax
00007f4f7cbd90eb  push rcx
00007f4f7cbd90ec  push rdx
00007f4f7cbd90ed  push rdi
00007f4f7cbd90ee  push rsi
00007f4f7cbd90ef  push r8
00007f4f7cbd90f1  push r9
00007f4f7cbd90f3  push r10
00007f4f7cbd90f5  push r11
00007f4f7cbd90f7  sub rsp, 0xF0
00007f4f7cbd90fe  vmovaps [rsp], xmm0
00007f4f7cbd9103  vmovaps [rsp+0x10], xmm1
00007f4f7cbd9109  vmovaps [rsp+0x20], xmm2
00007f4f7cbd910f  vmovaps [rsp+0x30], xmm3
00007f4f7cbd9115  vmovaps [rsp+0x40], xmm4
00007f4f7cbd911b  vmovaps [rsp+0x50], xmm5
00007f4f7cbd9121  vmovaps [rsp+0x60], xmm6
00007f4f7cbd9127  vmovaps [rsp+0x70], xmm7
00007f4f7cbd912d  vmovaps [rsp+0x80], xmm8
00007f4f7cbd9136  vmovaps [rsp+0x90], xmm9
00007f4f7cbd913f  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd9148  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd9151  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd915a  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd9163  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd916c  sub rsp, 0x40
00007f4f7cbd9170  lea rdi, [rsp]
00007f4f7cbd9174  lea rsi, [rsp+0x10]
00007f4f7cbd9179  lea rdx, [rsp+0x20]
00007f4f7cbd917e  lea rcx, [rsp+0x30]
00007f4f7cbd9183  mov r8d, 0x00
00007f4f7cbd9189  lea r9, [r15+0x3A8]
00007f4f7cbd9190  movaps [rdi], xmm12
00007f4f7cbd9194  movaps [rsi], xmm11
00007f4f7cbd9198  movaps [rdx], xmm15
00007f4f7cbd919c  movaps [rcx], xmm14
00007f4f7cbd91a0  mov rax, 0x643999485A50
00007f4f7cbd91aa  call rax
00007f4f7cbd91ac  movaps xmm12, [rsp]
00007f4f7cbd91b1  add rsp, 0x40
00007f4f7cbd91b5  vmovaps xmm0, [rsp]
00007f4f7cbd91ba  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd91c0  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd91c6  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd91cc  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd91d2  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd91d8  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd91de  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd91e4  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd91ed  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd91f6  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd91ff  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd9208  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd9211  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd921a  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd9223  add rsp, 0xF0
00007f4f7cbd922a  pop r11
00007f4f7cbd922c  pop r10
00007f4f7cbd922e  pop r9
00007f4f7cbd9230  pop r8
00007f4f7cbd9232  pop rsi
00007f4f7cbd9233  pop rdi
00007f4f7cbd9234  pop rdx
00007f4f7cbd9235  pop rcx
00007f4f7cbd9236  pop rax
00007f4f7cbd9237  add rsp, 0x08
00007f4f7cbd923b  jmp 0x00007F4F7CBD6B96
00007f4f7cbd9240  sub rsp, 0x08
00007f4f7cbd9244  push rax
00007f4f7cbd9245  push rcx
00007f4f7cbd9246  push rdx
00007f4f7cbd9247  push rdi
00007f4f7cbd9248  push rsi
00007f4f7cbd9249  push r8
00007f4f7cbd924b  push r9
00007f4f7cbd924d  push r10
00007f4f7cbd924f  push r11
00007f4f7cbd9251  sub rsp, 0xF0
00007f4f7cbd9258  vmovaps [rsp], xmm0
00007f4f7cbd925d  vmovaps [rsp+0x10], xmm1
00007f4f7cbd9263  vmovaps [rsp+0x20], xmm2
00007f4f7cbd9269  vmovaps [rsp+0x30], xmm3
00007f4f7cbd926f  vmovaps [rsp+0x40], xmm4
00007f4f7cbd9275  vmovaps [rsp+0x50], xmm5
00007f4f7cbd927b  vmovaps [rsp+0x60], xmm6
00007f4f7cbd9281  vmovaps [rsp+0x70], xmm7
00007f4f7cbd9287  vmovaps [rsp+0x80], xmm8
00007f4f7cbd9290  vmovaps [rsp+0x90], xmm9
00007f4f7cbd9299  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd92a2  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd92ab  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd92b4  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd92bd  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd92c6  sub rsp, 0x40
00007f4f7cbd92ca  lea rdi, [rsp]
00007f4f7cbd92ce  lea rsi, [rsp+0x10]
00007f4f7cbd92d3  lea rdx, [rsp+0x20]
00007f4f7cbd92d8  lea rcx, [rsp+0x30]
00007f4f7cbd92dd  mov r8d, 0x00
00007f4f7cbd92e3  lea r9, [r15+0x3A8]
00007f4f7cbd92ea  movaps [rdi], xmm11
00007f4f7cbd92ee  movaps [rsi], xmm10
00007f4f7cbd92f2  movaps [rdx], xmm13
00007f4f7cbd92f6  movaps [rcx], xmm15
00007f4f7cbd92fa  mov rax, 0x643999485A50
00007f4f7cbd9304  call rax
00007f4f7cbd9306  movaps xmm11, [rsp]
00007f4f7cbd930b  add rsp, 0x40
00007f4f7cbd930f  vmovaps xmm0, [rsp]
00007f4f7cbd9314  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd931a  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd9320  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd9326  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd932c  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd9332  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd9338  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd933e  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd9347  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd9350  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd9359  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd9362  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd936b  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd9374  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd937d  add rsp, 0xF0
00007f4f7cbd9384  pop r11
00007f4f7cbd9386  pop r10
00007f4f7cbd9388  pop r9
00007f4f7cbd938a  pop r8
00007f4f7cbd938c  pop rsi
00007f4f7cbd938d  pop rdi
00007f4f7cbd938e  pop rdx
00007f4f7cbd938f  pop rcx
00007f4f7cbd9390  pop rax
00007f4f7cbd9391  add rsp, 0x08
00007f4f7cbd9395  jmp 0x00007F4F7CBD6BBF
00007f4f7cbd939a  call 0x00007F4F7CAE5820
00007f4f7cbd939f  jmp 0x00007F4F7CBD6BCC
00007f4f7cbd93a4  call 0x00007F4F7CAE45A0
00007f4f7cbd93a9  jmp 0x00007F4F7CBD6BD9
00007f4f7cbd93ae  sub rsp, 0x08
00007f4f7cbd93b2  push rax
00007f4f7cbd93b3  push rcx
00007f4f7cbd93b4  push rdx
00007f4f7cbd93b5  push rdi
00007f4f7cbd93b6  push rsi
00007f4f7cbd93b7  push r8
00007f4f7cbd93b9  push r9
00007f4f7cbd93bb  push r10
00007f4f7cbd93bd  push r11
00007f4f7cbd93bf  sub rsp, 0xF0
00007f4f7cbd93c6  vmovaps [rsp], xmm0
00007f4f7cbd93cb  vmovaps [rsp+0x10], xmm1
00007f4f7cbd93d1  vmovaps [rsp+0x20], xmm2
00007f4f7cbd93d7  vmovaps [rsp+0x30], xmm3
00007f4f7cbd93dd  vmovaps [rsp+0x40], xmm4
00007f4f7cbd93e3  vmovaps [rsp+0x50], xmm5
00007f4f7cbd93e9  vmovaps [rsp+0x60], xmm6
00007f4f7cbd93ef  vmovaps [rsp+0x70], xmm7
00007f4f7cbd93f5  vmovaps [rsp+0x80], xmm8
00007f4f7cbd93fe  vmovaps [rsp+0x90], xmm9
00007f4f7cbd9407  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd9410  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd9419  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd9422  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd942b  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd9434  sub rsp, 0x40
00007f4f7cbd9438  lea rdi, [rsp]
00007f4f7cbd943c  lea rsi, [rsp+0x10]
00007f4f7cbd9441  lea rdx, [rsp+0x20]
00007f4f7cbd9446  lea rcx, [rsp+0x30]
00007f4f7cbd944b  mov r8d, 0x00
00007f4f7cbd9451  lea r9, [r15+0x3A8]
00007f4f7cbd9458  movaps [rdi], xmm10
00007f4f7cbd945c  movaps [rsi], xmm8
00007f4f7cbd9460  movaps [rdx], xmm1
00007f4f7cbd9463  movaps [rcx], xmm13
00007f4f7cbd9467  mov rax, 0x643999485A50
00007f4f7cbd9471  call rax
00007f4f7cbd9473  movaps xmm10, [rsp]
00007f4f7cbd9478  add rsp, 0x40
00007f4f7cbd947c  vmovaps xmm0, [rsp]
00007f4f7cbd9481  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd9487  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd948d  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd9493  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd9499  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd949f  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd94a5  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd94ab  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd94b4  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd94bd  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd94c6  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd94cf  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd94d8  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd94e1  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd94ea  add rsp, 0xF0
00007f4f7cbd94f1  pop r11
00007f4f7cbd94f3  pop r10
00007f4f7cbd94f5  pop r9
00007f4f7cbd94f7  pop r8
00007f4f7cbd94f9  pop rsi
00007f4f7cbd94fa  pop rdi
00007f4f7cbd94fb  pop rdx
00007f4f7cbd94fc  pop rcx
00007f4f7cbd94fd  pop rax
00007f4f7cbd94fe  add rsp, 0x08
00007f4f7cbd9502  jmp 0x00007F4F7CBD6C0F
00007f4f7cbd9507  call 0x00007F4F7CAD64F0
00007f4f7cbd950c  jmp 0x00007F4F7CBD6C21
00007f4f7cbd9511  sub rsp, 0x08
00007f4f7cbd9515  push rax
00007f4f7cbd9516  push rcx
00007f4f7cbd9517  push rdx
00007f4f7cbd9518  push rdi
00007f4f7cbd9519  push rsi
00007f4f7cbd951a  push r8
00007f4f7cbd951c  push r9
00007f4f7cbd951e  push r10
00007f4f7cbd9520  push r11
00007f4f7cbd9522  sub rsp, 0xF0
00007f4f7cbd9529  vmovaps [rsp], xmm0
00007f4f7cbd952e  vmovaps [rsp+0x10], xmm1
00007f4f7cbd9534  vmovaps [rsp+0x20], xmm2
00007f4f7cbd953a  vmovaps [rsp+0x30], xmm3
00007f4f7cbd9540  vmovaps [rsp+0x40], xmm4
00007f4f7cbd9546  vmovaps [rsp+0x50], xmm5
00007f4f7cbd954c  vmovaps [rsp+0x60], xmm6
00007f4f7cbd9552  vmovaps [rsp+0x70], xmm7
00007f4f7cbd9558  vmovaps [rsp+0x80], xmm8
00007f4f7cbd9561  vmovaps [rsp+0x90], xmm10
00007f4f7cbd956a  vmovaps [rsp+0xA0], xmm11
00007f4f7cbd9573  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd957c  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd9585  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd958e  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd9597  sub rsp, 0x40
00007f4f7cbd959b  lea rdi, [rsp]
00007f4f7cbd959f  lea rsi, [rsp+0x10]
00007f4f7cbd95a4  lea rdx, [rsp+0x20]
00007f4f7cbd95a9  lea rcx, [rsp+0x30]
00007f4f7cbd95ae  mov r8d, 0x00
00007f4f7cbd95b4  lea r9, [r15+0x3A8]
00007f4f7cbd95bb  movaps [rdi], xmm9
00007f4f7cbd95bf  movaps [rsi], xmm7
00007f4f7cbd95c2  movaps [rdx], xmm14
00007f4f7cbd95c6  movaps [rcx], xmm13
00007f4f7cbd95ca  mov rax, 0x643999485A50
00007f4f7cbd95d4  call rax
00007f4f7cbd95d6  movaps xmm9, [rsp]
00007f4f7cbd95db  add rsp, 0x40
00007f4f7cbd95df  vmovaps xmm0, [rsp]
00007f4f7cbd95e4  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd95ea  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd95f0  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd95f6  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd95fc  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd9602  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd9608  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd960e  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd9617  vmovaps xmm10, [rsp+0x90]
00007f4f7cbd9620  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbd9629  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbd9632  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd963b  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd9644  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd964d  add rsp, 0xF0
00007f4f7cbd9654  pop r11
00007f4f7cbd9656  pop r10
00007f4f7cbd9658  pop r9
00007f4f7cbd965a  pop r8
00007f4f7cbd965c  pop rsi
00007f4f7cbd965d  pop rdi
00007f4f7cbd965e  pop rdx
00007f4f7cbd965f  pop rcx
00007f4f7cbd9660  pop rax
00007f4f7cbd9661  add rsp, 0x08
00007f4f7cbd9665  jmp 0x00007F4F7CBD6C4F
00007f4f7cbd966a  sub rsp, 0x08
00007f4f7cbd966e  push rax
00007f4f7cbd966f  push rcx
00007f4f7cbd9670  push rdx
00007f4f7cbd9671  push rdi
00007f4f7cbd9672  push rsi
00007f4f7cbd9673  push r8
00007f4f7cbd9675  push r9
00007f4f7cbd9677  push r10
00007f4f7cbd9679  push r11
00007f4f7cbd967b  sub rsp, 0xF0
00007f4f7cbd9682  vmovaps [rsp], xmm0
00007f4f7cbd9687  vmovaps [rsp+0x10], xmm1
00007f4f7cbd968d  vmovaps [rsp+0x20], xmm2
00007f4f7cbd9693  vmovaps [rsp+0x30], xmm3
00007f4f7cbd9699  vmovaps [rsp+0x40], xmm4
00007f4f7cbd969f  vmovaps [rsp+0x50], xmm5
00007f4f7cbd96a5  vmovaps [rsp+0x60], xmm6
00007f4f7cbd96ab  vmovaps [rsp+0x70], xmm7
00007f4f7cbd96b1  vmovaps [rsp+0x80], xmm8
00007f4f7cbd96ba  vmovaps [rsp+0x90], xmm9
00007f4f7cbd96c3  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd96cc  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd96d5  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd96de  vmovaps [rsp+0xD0], xmm14
00007f4f7cbd96e7  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd96f0  sub rsp, 0x40
00007f4f7cbd96f4  lea rdi, [rsp]
00007f4f7cbd96f8  lea rsi, [rsp+0x10]
00007f4f7cbd96fd  lea rdx, [rsp+0x20]
00007f4f7cbd9702  lea rcx, [rsp+0x30]
00007f4f7cbd9707  mov r8d, 0x00
00007f4f7cbd970d  lea r9, [r15+0x3A8]
00007f4f7cbd9714  movaps [rdi], xmm13
00007f4f7cbd9718  movaps [rsi], xmm12
00007f4f7cbd971c  movaps [rdx], xmm15
00007f4f7cbd9720  movaps [rcx], xmm14
00007f4f7cbd9724  mov rax, 0x643999485A50
00007f4f7cbd972e  call rax
00007f4f7cbd9730  movaps xmm13, [rsp]
00007f4f7cbd9735  add rsp, 0x40
00007f4f7cbd9739  vmovaps xmm0, [rsp]
00007f4f7cbd973e  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd9744  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd974a  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd9750  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd9756  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd975c  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd9762  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd9768  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd9771  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd977a  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd9783  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd978c  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd9795  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbd979e  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd97a7  add rsp, 0xF0
00007f4f7cbd97ae  pop r11
00007f4f7cbd97b0  pop r10
00007f4f7cbd97b2  pop r9
00007f4f7cbd97b4  pop r8
00007f4f7cbd97b6  pop rsi
00007f4f7cbd97b7  pop rdi
00007f4f7cbd97b8  pop rdx
00007f4f7cbd97b9  pop rcx
00007f4f7cbd97ba  pop rax
00007f4f7cbd97bb  add rsp, 0x08
00007f4f7cbd97bf  jmp 0x00007F4F7CBD6C7D
00007f4f7cbd97c4  sub rsp, 0x08
00007f4f7cbd97c8  push rax
00007f4f7cbd97c9  push rcx
00007f4f7cbd97ca  push rdx
00007f4f7cbd97cb  push rdi
00007f4f7cbd97cc  push rsi
00007f4f7cbd97cd  push r8
00007f4f7cbd97cf  push r9
00007f4f7cbd97d1  push r10
00007f4f7cbd97d3  push r11
00007f4f7cbd97d5  sub rsp, 0xF0
00007f4f7cbd97dc  vmovaps [rsp], xmm0
00007f4f7cbd97e1  vmovaps [rsp+0x10], xmm1
00007f4f7cbd97e7  vmovaps [rsp+0x20], xmm2
00007f4f7cbd97ed  vmovaps [rsp+0x30], xmm3
00007f4f7cbd97f3  vmovaps [rsp+0x40], xmm4
00007f4f7cbd97f9  vmovaps [rsp+0x50], xmm5
00007f4f7cbd97ff  vmovaps [rsp+0x60], xmm6
00007f4f7cbd9805  vmovaps [rsp+0x70], xmm7
00007f4f7cbd980b  vmovaps [rsp+0x80], xmm8
00007f4f7cbd9814  vmovaps [rsp+0x90], xmm9
00007f4f7cbd981d  vmovaps [rsp+0xA0], xmm10
00007f4f7cbd9826  vmovaps [rsp+0xB0], xmm11
00007f4f7cbd982f  vmovaps [rsp+0xC0], xmm12
00007f4f7cbd9838  vmovaps [rsp+0xD0], xmm13
00007f4f7cbd9841  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd984a  sub rsp, 0x40
00007f4f7cbd984e  lea rdi, [rsp]
00007f4f7cbd9852  lea rsi, [rsp+0x10]
00007f4f7cbd9857  lea rdx, [rsp+0x20]
00007f4f7cbd985c  lea rcx, [rsp+0x30]
00007f4f7cbd9861  mov r8d, 0x00
00007f4f7cbd9867  lea r9, [r15+0x3A8]
00007f4f7cbd986e  movaps [rdi], xmm14
00007f4f7cbd9872  movaps [rsi], xmm11
00007f4f7cbd9876  movaps [rdx], xmm1
00007f4f7cbd9879  movaps [rcx], xmm15
00007f4f7cbd987d  mov rax, 0x643999485A50
00007f4f7cbd9887  call rax
00007f4f7cbd9889  movaps xmm14, [rsp]
00007f4f7cbd988e  add rsp, 0x40
00007f4f7cbd9892  vmovaps xmm0, [rsp]
00007f4f7cbd9897  vmovaps xmm1, [rsp+0x10]
00007f4f7cbd989d  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd98a3  vmovaps xmm3, [rsp+0x30]
00007f4f7cbd98a9  vmovaps xmm4, [rsp+0x40]
00007f4f7cbd98af  vmovaps xmm5, [rsp+0x50]
00007f4f7cbd98b5  vmovaps xmm6, [rsp+0x60]
00007f4f7cbd98bb  vmovaps xmm7, [rsp+0x70]
00007f4f7cbd98c1  vmovaps xmm8, [rsp+0x80]
00007f4f7cbd98ca  vmovaps xmm9, [rsp+0x90]
00007f4f7cbd98d3  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbd98dc  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbd98e5  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbd98ee  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbd98f7  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbd9900  add rsp, 0xF0
00007f4f7cbd9907  pop r11
00007f4f7cbd9909  pop r10
00007f4f7cbd990b  pop r9
00007f4f7cbd990d  pop r8
00007f4f7cbd990f  pop rsi
00007f4f7cbd9910  pop rdi
00007f4f7cbd9911  pop rdx
00007f4f7cbd9912  pop rcx
00007f4f7cbd9913  pop rax
00007f4f7cbd9914  add rsp, 0x08
00007f4f7cbd9918  jmp 0x00007F4F7CBD6CAB
00007f4f7cbd991d  call 0x00007F4F7CAACF70
00007f4f7cbd9922  jmp 0x00007F4F7CBD6CB9
00007f4f7cbd9927  call 0x00007F4F7CA0C380
00007f4f7cbd992c  jmp 0x00007F4F7CBD6CC3
00007f4f7cbd9931  call 0x00007F4F7CA08C20
00007f4f7cbd9936  jmp 0x00007F4F7CBD6CCD
00007f4f7cbd993b  call 0x00007F4F7CA0D600
00007f4f7cbd9940  jmp 0x00007F4F7CBD6CD7
00007f4f7cbd9945  int3
00007f4f7cbd9946  nop [rax+rax*1], ax
00007f4f7cbd994f  nop
00007f4f7cbd9950  mov eax, [r15+0x48]
00007f4f7cbd9954  lea r14d, [eax+0x01]
00007f4f7cbd9959  mov [rsp+0x10], r14d
00007f4f7cbd995e  mov r14d, r14d
00007f4f7cbd9961  mov [r15+0x48], r14
00007f4f7cbd9965  xor eax, eax
00007f4f7cbd9967  mov r14d, [rsp+0x10]
00007f4f7cbd996c  cmp r14d, 0x1F4
00007f4f7cbd9973  cmc
00007f4f7cbd9974  lahf
00007f4f7cbd9975  seto al
00007f4f7cbd9978  mov [r15+0x108], eax
00007f4f7cbd997f  mov eax, [r15+0x108]
00007f4f7cbd9986  sahf
00007f4f7cbd9987  jnz 0x00007F4F7CBD99B9
00007f4f7cbd9989  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd9991  jz 0x00007F4F7CBDD2E0
00007f4f7cbd9997  nop [rax+rax*1], ax
00007f4f7cbd99a0  nop [rax+rax*1], eax
00007f4f7cbd99a8  mov eax, 0x410670
00007f4f7cbd99ad  mov [r15+0x100], rax
00007f4f7cbd99b4  jmp 0x00007F4F7C9FE110
00007f4f7cbd99b9  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbd99c1  jz 0x00007F4F7CBD99F0
00007f4f7cbd99c7  nop [rax+rax*1], ax
00007f4f7cbd99d0  nop [rax+rax*1], eax
00007f4f7cbd99d8  mov eax, 0x4104EC
00007f4f7cbd99dd  mov [r15+0x100], rax
00007f4f7cbd99e4  jmp 0x00007F4F7C9FE110
00007f4f7cbd99e9  int3
00007f4f7cbd99ea  int3
00007f4f7cbd99eb  nop [rax+rax*1], eax
00007f4f7cbd99f0  mov rax, [r15+0x40]
00007f4f7cbd99f4  vxorps xmm1, xmm1, xmm1
00007f4f7cbd99f8  vpbroadcastq xmm1, xmm1
00007f4f7cbd99fd  vxorps xmm15, xmm15, xmm15
00007f4f7cbd9a02  vpbroadcastq xmm15, xmm15
00007f4f7cbd9a07  lea r14, [rax+0x30]
00007f4f7cbd9a0b  mov r12, [r13+r14*1]
00007f4f7cbd9a10  lea r14, [rax+0x38]
00007f4f7cbd9a14  mov r11, [r13+r14*1]
00007f4f7cbd9a19  movq xmm14, r12
00007f4f7cbd9a1e  movq xmm13, r11
00007f4f7cbd9a23  movq xmm14, xmm14
00007f4f7cbd9a28  movq xmm13, xmm13
00007f4f7cbd9a2d  vmovaps [rsp+0x10], xmm13
00007f4f7cbd9a33  movq xmm13, xmm13
00007f4f7cbd9a38  movaps [r15+0x270], xmm13
00007f4f7cbd9a40  movaps xmm13, [r15+0x160]
00007f4f7cbd9a48  vmovaps [rsp+0x20], xmm13
00007f4f7cbd9a4e  vmovaps xmm12, [rsp+0x20]
00007f4f7cbd9a54  por xmm13, xmm12
00007f4f7cbd9a59  lea r14, [rax+0x20]
00007f4f7cbd9a5d  mov r12, [r13+r14*1]
00007f4f7cbd9a62  lea r14, [rax+0x28]
00007f4f7cbd9a66  mov r11, [r13+r14*1]
00007f4f7cbd9a6b  movq xmm12, r12
00007f4f7cbd9a70  movq xmm11, r11
00007f4f7cbd9a75  movq xmm12, xmm12
00007f4f7cbd9a7a  movq xmm11, xmm11
00007f4f7cbd9a7f  movaps xmm10, [r15+0x2D0]
00007f4f7cbd9a87  vmovaps [rsp+0x20], xmm10
00007f4f7cbd9a8d  vmovaps xmm9, [rsp+0x20]
00007f4f7cbd9a93  por xmm10, xmm9
00007f4f7cbd9a98  movaps xmm9, [r15+0x300]
00007f4f7cbd9aa0  vmovaps [rsp+0x20], xmm9
00007f4f7cbd9aa6  vmovaps xmm8, [rsp+0x20]
00007f4f7cbd9aac  por xmm9, xmm8
00007f4f7cbd9ab1  movaps xmm8, [r15+0x2B0]
00007f4f7cbd9ab9  vmovaps [rsp+0x20], xmm8
00007f4f7cbd9abf  vmovaps xmm7, [rsp+0x20]
00007f4f7cbd9ac5  por xmm8, xmm7
00007f4f7cbd9aca  movaps xmm7, [r15+0x180]
00007f4f7cbd9ad2  vmovaps [rsp+0x20], xmm7
00007f4f7cbd9ad8  vmovaps xmm6, [rsp+0x20]
00007f4f7cbd9ade  por xmm7, xmm6
00007f4f7cbd9ae2  lea r14, [rax+0x10]
00007f4f7cbd9ae6  mov r12, [r13+r14*1]
00007f4f7cbd9aeb  lea r14, [rax+0x18]
00007f4f7cbd9aef  mov r11, [r13+r14*1]
00007f4f7cbd9af4  movq xmm6, r12
00007f4f7cbd9af9  movq xmm5, r11
00007f4f7cbd9afe  movq xmm6, xmm6
00007f4f7cbd9b02  movq xmm5, xmm5
00007f4f7cbd9b06  movaps xmm4, [r15+0x200]
00007f4f7cbd9b0e  vmovaps [rsp+0x20], xmm4
00007f4f7cbd9b14  vmovaps xmm3, [rsp+0x20]
00007f4f7cbd9b1a  por xmm4, xmm3
00007f4f7cbd9b1e  movaps xmm3, [r15+0x1F0]
00007f4f7cbd9b26  vmovaps [rsp+0x20], xmm3
00007f4f7cbd9b2c  vmovaps xmm2, [rsp+0x20]
00007f4f7cbd9b32  por xmm3, xmm2
00007f4f7cbd9b36  movaps xmm2, [r15+0x2E0]
00007f4f7cbd9b3e  vmovaps [rsp+0x20], xmm2
00007f4f7cbd9b44  vmovaps [rsp+0x30], xmm1
00007f4f7cbd9b4a  vmovaps xmm1, [rsp+0x20]
00007f4f7cbd9b50  por xmm2, xmm1
00007f4f7cbd9b54  movaps xmm1, [r15+0x2A0]
00007f4f7cbd9b5c  vmovaps [rsp+0x20], xmm1
00007f4f7cbd9b62  vmovaps [rsp+0x40], xmm15
00007f4f7cbd9b68  vmovaps xmm15, [rsp+0x20]
00007f4f7cbd9b6e  por xmm1, xmm15
00007f4f7cbd9b73  movaps xmm15, [r15+0x280]
00007f4f7cbd9b7b  vmovaps [rsp+0x20], xmm15
00007f4f7cbd9b81  vmovaps [rsp+0x50], xmm1
00007f4f7cbd9b87  vmovaps xmm1, [rsp+0x20]
00007f4f7cbd9b8d  por xmm15, xmm1
00007f4f7cbd9b92  movaps xmm1, [r15+0x1C0]
00007f4f7cbd9b9a  vmovaps [rsp+0x20], xmm1
00007f4f7cbd9ba0  vmovaps [rsp+0x60], xmm15
00007f4f7cbd9ba6  vmovaps xmm15, [rsp+0x20]
00007f4f7cbd9bac  por xmm1, xmm15
00007f4f7cbd9bb1  movaps xmm15, [r15+0x210]
00007f4f7cbd9bb9  vmovaps [rsp+0x20], xmm15
00007f4f7cbd9bbf  vmovaps [rsp+0x70], xmm1
00007f4f7cbd9bc5  vmovaps xmm1, [rsp+0x20]
00007f4f7cbd9bcb  por xmm15, xmm1
00007f4f7cbd9bd0  mov r14, [r13+rax*1]
00007f4f7cbd9bd5  vmovq xmm1, r14
00007f4f7cbd9bda  vpbroadcastq xmm1, xmm1
00007f4f7cbd9bdf  vmovaps [rsp+0x20], xmm1
00007f4f7cbd9be5  vxorps xmm1, xmm1, xmm1
00007f4f7cbd9be9  vpbroadcastq xmm1, xmm1
00007f4f7cbd9bee  mov r14, [r15+0xF8]
00007f4f7cbd9bf5  vmovaps [rsp+0x80], xmm1
00007f4f7cbd9bfe  movups xmm1, [r13+r14*1]
00007f4f7cbd9c04  vmovaps [rsp+0x90], xmm1
00007f4f7cbd9c0d  vxorps xmm1, xmm1, xmm1
00007f4f7cbd9c11  vpbroadcastq xmm1, xmm1
00007f4f7cbd9c16  lea r12, [rax+0x08]
00007f4f7cbd9c1a  mov rax, [r13+r12*1]
00007f4f7cbd9c1f  vmovaps [rsp+0xA0], xmm1
00007f4f7cbd9c28  movq xmm1, rax
00007f4f7cbd9c2d  movaps [r15+0x240], xmm1
00007f4f7cbd9c35  mov rax, [r15+0x50]
00007f4f7cbd9c39  mov [r15+0x60], rax
00007f4f7cbd9c3d  mov qword ptr [r15+0x58], 0x40
00007f4f7cbd9c45  vmovaps xmm1, [rsp+0x30]
00007f4f7cbd9c4b  vmovaps [rsp+0x30], xmm15
00007f4f7cbd9c51  vmovaps xmm15, [rsp+0x90]
00007f4f7cbd9c5a  vmovaps [rsp+0x90], xmm14
00007f4f7cbd9c63  vmovaps xmm14, [rsp+0x20]
00007f4f7cbd9c69  vmovaps [rsp+0x20], xmm13
00007f4f7cbd9c6f  vmovaps [rsp+0xB0], xmm12
00007f4f7cbd9c78  movaps xmm13, xmm1
00007f4f7cbd9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd9c87  vptest xmm12, xmm12
00007f4f7cbd9c8c  jnz 0x00007F4F7CBDA72F
00007f4f7cbd9c92  movaps xmm1, [r15+0x250]
00007f4f7cbd9c9a  vmovaps xmm15, [rsp+0x40]
00007f4f7cbd9ca0  vmovaps [rsp+0x40], xmm13
00007f4f7cbd9ca6  movaps xmm12, xmm15
00007f4f7cbd9caa  vfmadd231pd xmm12, xmm1, xmm14
00007f4f7cbd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007f4f7cbd9cb5  vptest xmm13, xmm13
00007f4f7cbd9cba  jnz 0x00007F4F7CBDA888
00007f4f7cbd9cc0  movaps xmm15, [r15+0x1E0]
00007f4f7cbd9cc8  vmovaps [rsp+0xC0], xmm15
00007f4f7cbd9cd1  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbd9cda  por xmm15, xmm13
00007f4f7cbd9cdf  movaps xmm13, [r15+0x1D0]
00007f4f7cbd9ce7  vmovaps [rsp+0xC0], xmm13
00007f4f7cbd9cf0  vmovaps [rsp+0xD0], xmm1
00007f4f7cbd9cf9  vmovaps xmm1, [rsp+0xC0]
00007f4f7cbd9d02  por xmm13, xmm1
00007f4f7cbd9d07  movaps xmm1, [r15+0x2C0]
00007f4f7cbd9d0f  vmovaps [rsp+0xC0], xmm1
00007f4f7cbd9d18  vmovaps [rsp+0xE0], xmm15
00007f4f7cbd9d21  vmovaps xmm15, [rsp+0xC0]
00007f4f7cbd9d2a  por xmm1, xmm15
00007f4f7cbd9d2f  movaps xmm15, [r15+0x290]
00007f4f7cbd9d37  vmovaps [rsp+0xC0], xmm15
00007f4f7cbd9d40  vmovaps [rsp+0xF0], xmm1
00007f4f7cbd9d49  vmovaps xmm1, [rsp+0xC0]
00007f4f7cbd9d52  por xmm15, xmm1
00007f4f7cbd9d57  movaps xmm1, [r15+0x260]
00007f4f7cbd9d5f  vmovaps [rsp+0xC0], xmm1
00007f4f7cbd9d68  vmovaps [rsp+0x100], xmm15
00007f4f7cbd9d71  vmovaps xmm15, [rsp+0xC0]
00007f4f7cbd9d7a  por xmm1, xmm15
00007f4f7cbd9d7f  vmovaps xmm15, [rsp+0xD0]
00007f4f7cbd9d88  vmovaps [rsp+0xC0], xmm1
00007f4f7cbd9d91  vmovaps xmm1, [rsp+0xD0]
00007f4f7cbd9d9a  por xmm15, xmm1
00007f4f7cbd9d9f  lea r12, [r14+0xC0]
00007f4f7cbd9da6  movups xmm1, [r13+r12*1]
00007f4f7cbd9dac  mov [rsp+0xD0], rax
00007f4f7cbd9db4  xor eax, eax
00007f4f7cbd9db6  mov r12d, 0x40
00007f4f7cbd9dbc  mov r11d, 0x200
00007f4f7cbd9dc2  cmp r12, r11
00007f4f7cbd9dc5  cmc
00007f4f7cbd9dc6  lahf
00007f4f7cbd9dc7  seto al
00007f4f7cbd9dca  mov [r15+0x108], eax
00007f4f7cbd9dd1  vmovaps [rsp+0x110], xmm1
00007f4f7cbd9dda  vmovaps xmm1, [rsp+0x80]
00007f4f7cbd9de3  vmovaps [rsp+0x80], xmm15
00007f4f7cbd9dec  vmovaps xmm15, [rsp+0x110]
00007f4f7cbd9df5  vmovaps [rsp+0x110], xmm13
00007f4f7cbd9dfe  vmovaps [rsp+0x120], xmm12
00007f4f7cbd9e07  movaps xmm13, xmm1
00007f4f7cbd9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd9e16  vptest xmm12, xmm12
00007f4f7cbd9e1b  jnz 0x00007F4F7CBDA9EB
00007f4f7cbd9e21  lea rax, [r14+0xB0]
00007f4f7cbd9e28  movups xmm1, [r13+rax*1]
00007f4f7cbd9e2e  vmovaps xmm15, [rsp+0xA0]
00007f4f7cbd9e37  vmovaps [rsp+0xA0], xmm13
00007f4f7cbd9e40  movaps xmm12, xmm15
00007f4f7cbd9e44  vfmadd231pd xmm12, xmm1, xmm14
00007f4f7cbd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007f4f7cbd9e4f  vptest xmm13, xmm13
00007f4f7cbd9e54  jnz 0x00007F4F7CBDAB4E
00007f4f7cbd9e5a  vmovaps xmm1, [rsp+0x30]
00007f4f7cbd9e60  vmovaps xmm15, [rsp+0x30]
00007f4f7cbd9e66  por xmm1, xmm15
00007f4f7cbd9e6b  movaps [r15+0x210], xmm1
00007f4f7cbd9e73  vmovaps xmm15, [rsp+0x70]
00007f4f7cbd9e79  vmovaps xmm14, [rsp+0x70]
00007f4f7cbd9e7f  por xmm15, xmm14
00007f4f7cbd9e84  movaps [r15+0x1C0], xmm15
00007f4f7cbd9e8c  vmovaps xmm14, [rsp+0x60]
00007f4f7cbd9e92  vmovaps xmm13, [rsp+0x60]
00007f4f7cbd9e98  por xmm14, xmm13
00007f4f7cbd9e9d  movaps [r15+0x280], xmm14
00007f4f7cbd9ea5  vmovaps xmm13, [rsp+0x50]
00007f4f7cbd9eab  vmovaps [rsp+0x30], xmm1
00007f4f7cbd9eb1  vmovaps xmm1, [rsp+0x50]
00007f4f7cbd9eb7  por xmm13, xmm1
00007f4f7cbd9ebc  movaps [r15+0x2A0], xmm13
00007f4f7cbd9ec4  vmovaps [rsp+0x50], xmm2
00007f4f7cbd9eca  vmovaps xmm1, [rsp+0x50]
00007f4f7cbd9ed0  por xmm2, xmm1
00007f4f7cbd9ed4  movaps [r15+0x2E0], xmm2
00007f4f7cbd9edc  vmovaps [rsp+0x50], xmm3
00007f4f7cbd9ee2  vmovaps xmm1, [rsp+0x50]
00007f4f7cbd9ee8  por xmm3, xmm1
00007f4f7cbd9eec  movaps [r15+0x1F0], xmm3
00007f4f7cbd9ef4  vmovaps xmm1, [rsp+0x80]
00007f4f7cbd9efd  vmovaps [rsp+0x50], xmm15
00007f4f7cbd9f03  vmovaps xmm15, [rsp+0x80]
00007f4f7cbd9f0c  por xmm1, xmm15
00007f4f7cbd9f11  movaps [r15+0x250], xmm1
00007f4f7cbd9f19  vmovaps xmm1, [rsp+0xC0]
00007f4f7cbd9f22  vmovaps xmm15, [rsp+0xC0]
00007f4f7cbd9f2b  por xmm1, xmm15
00007f4f7cbd9f30  movaps [r15+0x260], xmm1
00007f4f7cbd9f38  vmovaps xmm15, [rsp+0x100]
00007f4f7cbd9f41  vmovaps [rsp+0x60], xmm1
00007f4f7cbd9f47  vmovaps xmm1, [rsp+0x100]
00007f4f7cbd9f50  por xmm15, xmm1
00007f4f7cbd9f55  movaps [r15+0x290], xmm15
00007f4f7cbd9f5d  vmovaps xmm1, [rsp+0xF0]
00007f4f7cbd9f66  vmovaps [rsp+0x70], xmm15
00007f4f7cbd9f6c  vmovaps xmm15, [rsp+0xF0]
00007f4f7cbd9f75  por xmm1, xmm15
00007f4f7cbd9f7a  movaps [r15+0x2C0], xmm1
00007f4f7cbd9f82  movq xmm15, qword ptr [r15+0x240]
00007f4f7cbd9f8b  vmovaps [rsp+0x80], xmm15
00007f4f7cbd9f94  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbd9f9a  vmovaps [rsp+0xC0], xmm1
00007f4f7cbd9fa3  vmovaps xmm1, [rsp+0x40]
00007f4f7cbd9fa9  vmovaps [rsp+0x40], xmm15
00007f4f7cbd9faf  vmovaps xmm15, [rsp+0x30]
00007f4f7cbd9fb5  vmovaps [rsp+0x30], xmm14
00007f4f7cbd9fbb  vmovaps xmm14, [rsp+0x40]
00007f4f7cbd9fc1  vmovaps [rsp+0x40], xmm13
00007f4f7cbd9fc7  vmovaps [rsp+0xF0], xmm12
00007f4f7cbd9fd0  movaps xmm13, xmm1
00007f4f7cbd9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4f7cbd9fdf  vptest xmm12, xmm12
00007f4f7cbd9fe4  jnz 0x00007F4F7CBDACA7
00007f4f7cbd9fea  vmovaps xmm1, [rsp+0x80]
00007f4f7cbd9ff3  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbd9ff9  vmovaps xmm15, [rsp+0xA0]
00007f4f7cbda002  movaps xmm14, xmm15
00007f4f7cbda006  vfmadd231pd xmm14, xmm2, xmm1
00007f4f7cbda00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007f4f7cbda011  vptest xmm12, xmm12
00007f4f7cbda016  jnz 0x00007F4F7CBDAE00
00007f4f7cbda01c  vmovaps xmm1, [rsp+0x80]
00007f4f7cbda025  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbda02b  vmovaps xmm15, [rsp+0x120]
00007f4f7cbda034  vmovaps xmm12, [rsp+0x50]
00007f4f7cbda03a  vmovaps [rsp+0x50], xmm14
00007f4f7cbda040  movaps xmm2, xmm15
00007f4f7cbda044  vfmadd231pd xmm2, xmm12, xmm1
00007f4f7cbda049  vcmppd xmm14, xmm2, xmm2, 0x03
00007f4f7cbda04e  vptest xmm14, xmm14
00007f4f7cbda053  jnz 0x00007F4F7CBDAF58
00007f4f7cbda059  vmovaps xmm1, [rsp+0x110]
00007f4f7cbda062  vmovaps xmm15, [rsp+0x110]
00007f4f7cbda06b  por xmm1, xmm15
00007f4f7cbda070  movaps [r15+0x1D0], xmm1
00007f4f7cbda078  vmovaps xmm15, [rsp+0x80]
00007f4f7cbda081  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbda087  vmovaps xmm14, [rsp+0xF0]
00007f4f7cbda090  vmovaps [rsp+0x80], xmm1
00007f4f7cbda099  movaps xmm12, xmm14
00007f4f7cbda09d  vfmadd231pd xmm12, xmm3, xmm15
00007f4f7cbda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007f4f7cbda0a8  vptest xmm1, xmm1
00007f4f7cbda0ad  jnz 0x00007F4F7CBDB0AF
00007f4f7cbda0b3  vmovaps [rsp+0xA0], xmm4
00007f4f7cbda0bc  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbda0c5  por xmm4, xmm1
00007f4f7cbda0c9  movaps [r15+0x200], xmm4
00007f4f7cbda0d1  vmovaps xmm1, [rsp+0xE0]
00007f4f7cbda0da  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbda0e3  por xmm1, xmm15
00007f4f7cbda0e8  movaps [r15+0x1E0], xmm1
00007f4f7cbda0f0  vmovaps [rsp+0xA0], xmm8
00007f4f7cbda0f9  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbda102  por xmm8, xmm1
00007f4f7cbda107  movaps [r15+0x2B0], xmm8
00007f4f7cbda10f  vmovaps [rsp+0xA0], xmm9
00007f4f7cbda118  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbda121  por xmm9, xmm1
00007f4f7cbda126  movaps [r15+0x300], xmm9
00007f4f7cbda12e  vmovaps [rsp+0xA0], xmm6
00007f4f7cbda137  vpermilpd xmm6, xmm6, 0x00
00007f4f7cbda13d  vmovaps xmm14, [rsp+0x60]
00007f4f7cbda143  movaps xmm9, xmm13
00007f4f7cbda147  vfmadd231pd xmm9, xmm14, xmm6
00007f4f7cbda14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007f4f7cbda152  vptest xmm3, xmm3
00007f4f7cbda157  jnz 0x00007F4F7CBDB208
00007f4f7cbda15d  vmovaps xmm14, [rsp+0xA0]
00007f4f7cbda166  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbda16c  vmovaps xmm13, [rsp+0x50]
00007f4f7cbda172  vmovaps xmm6, [rsp+0xC0]
00007f4f7cbda17b  vmovaps [rsp+0x50], xmm1
00007f4f7cbda181  movaps xmm3, xmm13
00007f4f7cbda185  vfmadd231pd xmm3, xmm6, xmm14
00007f4f7cbda18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007f4f7cbda18f  vptest xmm1, xmm1
00007f4f7cbda194  jnz 0x00007F4F7CBDB361
00007f4f7cbda19a  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbda1a3  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbda1a9  vmovaps xmm14, [rsp+0x30]
00007f4f7cbda1af  movaps xmm6, xmm2
00007f4f7cbda1b2  vfmadd231pd xmm6, xmm14, xmm1
00007f4f7cbda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007f4f7cbda1bc  vptest xmm13, xmm13
00007f4f7cbda1c1  jnz 0x00007F4F7CBDB4B8
00007f4f7cbda1c7  vmovaps xmm1, [rsp+0xA0]
00007f4f7cbda1d0  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbda1d6  vmovaps xmm14, [rsp+0x80]
00007f4f7cbda1df  movaps xmm13, xmm12
00007f4f7cbda1e3  vfmadd231pd xmm13, xmm14, xmm1
00007f4f7cbda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007f4f7cbda1ee  vptest xmm2, xmm2
00007f4f7cbda1f3  jnz 0x00007F4F7CBDB60E
00007f4f7cbda1f9  vmovaps [rsp+0x30], xmm7
00007f4f7cbda1ff  vmovaps xmm1, [rsp+0x30]
00007f4f7cbda205  por xmm7, xmm1
00007f4f7cbda209  movaps [r15+0x180], xmm7
00007f4f7cbda211  vmovaps [rsp+0x30], xmm10
00007f4f7cbda217  vmovaps xmm1, [rsp+0x30]
00007f4f7cbda21d  por xmm10, xmm1
00007f4f7cbda222  movaps [r15+0x2D0], xmm10
00007f4f7cbda22a  vmovaps [rsp+0x30], xmm5
00007f4f7cbda230  vpermilpd xmm5, xmm5, 0x00
00007f4f7cbda236  vmovaps xmm14, [rsp+0x50]
00007f4f7cbda23c  movaps xmm12, xmm3
00007f4f7cbda240  vfmadd231pd xmm12, xmm14, xmm5
00007f4f7cbda245  vcmppd xmm10, xmm12, xmm12, 0x03
00007f4f7cbda24b  vptest xmm10, xmm10
00007f4f7cbda250  jnz 0x00007F4F7CBDB767
00007f4f7cbda256  vmovaps xmm14, [rsp+0x30]
00007f4f7cbda25c  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbda262  movaps xmm10, xmm9
00007f4f7cbda266  vfmadd231pd xmm10, xmm7, xmm14
00007f4f7cbda26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007f4f7cbda271  vptest xmm5, xmm5
00007f4f7cbda276  jnz 0x00007F4F7CBDB8BF
00007f4f7cbda27c  lea rax, [r14+0x80]
00007f4f7cbda283  movups xmm14, [r13+rax*1]
00007f4f7cbda289  movaps [r15+0x2F0], xmm14
00007f4f7cbda291  vmovaps xmm9, [rsp+0x30]
00007f4f7cbda297  vpermilpd xmm9, xmm9, 0x00
00007f4f7cbda29d  vmovaps xmm7, [rsp+0x70]
00007f4f7cbda2a3  movaps xmm5, xmm6
00007f4f7cbda2a6  vfmadd231pd xmm5, xmm7, xmm9
00007f4f7cbda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007f4f7cbda2b0  vptest xmm3, xmm3
00007f4f7cbda2b5  jnz 0x00007F4F7CBDBA22
00007f4f7cbda2bb  vmovaps xmm9, [rsp+0x30]
00007f4f7cbda2c1  vpermilpd xmm9, xmm9, 0x00
00007f4f7cbda2c7  movaps xmm7, xmm13
00007f4f7cbda2cb  vfmadd231pd xmm7, xmm1, xmm9
00007f4f7cbda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4f7cbda2d5  vptest xmm6, xmm6
00007f4f7cbda2da  jnz 0x00007F4F7CBDBB78
00007f4f7cbda2e0  vmovaps xmm1, [rsp+0x20]
00007f4f7cbda2e6  vmovaps xmm13, [rsp+0x20]
00007f4f7cbda2ec  por xmm1, xmm13
00007f4f7cbda2f1  movaps [r15+0x160], xmm1
00007f4f7cbda2f9  lea rax, [r14+0x40]
00007f4f7cbda2fd  movups xmm13, [r13+rax*1]
00007f4f7cbda303  lea rax, [r14+0x50]
00007f4f7cbda307  movups xmm9, [r13+rax*1]
00007f4f7cbda30d  movaps [r15+0x1B0], xmm13
00007f4f7cbda315  movaps [r15+0x1A0], xmm9
00007f4f7cbda31d  movaps xmm6, [r15+0x190]
00007f4f7cbda325  vmovaps xmm3, [rsp+0xB0]
00007f4f7cbda32e  vpermilpd xmm3, xmm3, 0x00
00007f4f7cbda334  vmovaps [rsp+0x20], xmm1
00007f4f7cbda33a  movaps xmm2, xmm12
00007f4f7cbda33e  vfmadd231pd xmm2, xmm6, xmm3
00007f4f7cbda343  vcmppd xmm1, xmm2, xmm2, 0x03
00007f4f7cbda348  vptest xmm1, xmm1
00007f4f7cbda34d  jnz 0x00007F4F7CBDBCE3
00007f4f7cbda353  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbda35c  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbda362  vmovaps xmm12, [rsp+0x20]
00007f4f7cbda368  movaps xmm6, xmm10
00007f4f7cbda36c  vfmadd231pd xmm6, xmm12, xmm1
00007f4f7cbda371  vcmppd xmm3, xmm6, xmm6, 0x03
00007f4f7cbda376  vptest xmm3, xmm3
00007f4f7cbda37b  jnz 0x00007F4F7CBDBE39
00007f4f7cbda381  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbda38a  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbda390  vmovaps xmm12, [rsp+0x40]
00007f4f7cbda396  movaps xmm10, xmm5
00007f4f7cbda39a  vfmadd231pd xmm10, xmm12, xmm1
00007f4f7cbda39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007f4f7cbda3a5  vptest xmm3, xmm3
00007f4f7cbda3aa  jnz 0x00007F4F7CBDBF90
00007f4f7cbda3b0  vmovaps xmm1, [rsp+0xB0]
00007f4f7cbda3b9  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbda3bf  movaps xmm12, xmm7
00007f4f7cbda3c3  vfmadd231pd xmm12, xmm15, xmm1
00007f4f7cbda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007f4f7cbda3ce  vptest xmm5, xmm5
00007f4f7cbda3d3  jnz 0x00007F4F7CBDC0E8
00007f4f7cbda3d9  lea rax, [r14+0x60]
00007f4f7cbda3dd  movups xmm1, [r13+rax*1]
00007f4f7cbda3e3  lea rax, [r14+0x70]
00007f4f7cbda3e7  movups xmm15, [r13+rax*1]
00007f4f7cbda3ed  movaps [r15+0x150], xmm1
00007f4f7cbda3f5  movaps [r15+0x120], xmm15
00007f4f7cbda3fd  vmovaps [rsp+0x20], xmm11
00007f4f7cbda403  vpermilpd xmm11, xmm11, 0x00
00007f4f7cbda409  movaps xmm7, xmm2
00007f4f7cbda40c  vfmadd231pd xmm7, xmm9, xmm11
00007f4f7cbda411  vcmppd xmm5, xmm7, xmm7, 0x03
00007f4f7cbda416  vptest xmm5, xmm5
00007f4f7cbda41b  jnz 0x00007F4F7CBDC254
00007f4f7cbda421  vmovaps xmm11, [rsp+0x20]
00007f4f7cbda427  vpermilpd xmm11, xmm11, 0x00
00007f4f7cbda42d  movaps xmm9, xmm6
00007f4f7cbda431  vfmadd231pd xmm9, xmm1, xmm11
00007f4f7cbda436  vcmppd xmm5, xmm9, xmm9, 0x03
00007f4f7cbda43c  vptest xmm5, xmm5
00007f4f7cbda441  jnz 0x00007F4F7CBDC3AB
00007f4f7cbda447  vmovaps xmm1, [rsp+0x20]
00007f4f7cbda44d  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbda453  movaps xmm11, xmm10
00007f4f7cbda457  vfmadd231pd xmm11, xmm8, xmm1
00007f4f7cbda45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007f4f7cbda462  vptest xmm6, xmm6
00007f4f7cbda467  jnz 0x00007F4F7CBDC503
00007f4f7cbda46d  vmovaps xmm1, [rsp+0x20]
00007f4f7cbda473  vpermilpd xmm1, xmm1, 0x00
00007f4f7cbda479  movaps xmm10, xmm12
00007f4f7cbda47d  vfmadd231pd xmm10, xmm13, xmm1
00007f4f7cbda482  vcmppd xmm8, xmm10, xmm10, 0x03
00007f4f7cbda488  vptest xmm8, xmm8
00007f4f7cbda48d  jnz 0x00007F4F7CBDC65C
00007f4f7cbda493  lea rax, [r14+0x20]
00007f4f7cbda497  movups xmm1, [r13+rax*1]
00007f4f7cbda49d  lea rax, [r14+0x30]
00007f4f7cbda4a1  movups xmm13, [r13+rax*1]
00007f4f7cbda4a7  vmovaps xmm12, [rsp+0x90]
00007f4f7cbda4b0  vpermilpd xmm12, xmm12, 0x00
00007f4f7cbda4b6  movaps xmm8, xmm7
00007f4f7cbda4ba  vfmadd231pd xmm8, xmm4, xmm12
00007f4f7cbda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007f4f7cbda4c5  vptest xmm6, xmm6
00007f4f7cbda4ca  jnz 0x00007F4F7CBDC7C9
00007f4f7cbda4d0  vmovaps xmm12, [rsp+0x90]
00007f4f7cbda4d9  vpermilpd xmm12, xmm12, 0x00
00007f4f7cbda4df  movaps xmm7, xmm9
00007f4f7cbda4e3  vfmadd231pd xmm7, xmm14, xmm12
00007f4f7cbda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4f7cbda4ed  vptest xmm6, xmm6
00007f4f7cbda4f2  jnz 0x00007F4F7CBDC921
00007f4f7cbda4f8  vmovaps xmm14, [rsp+0x90]
00007f4f7cbda501  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbda507  movaps xmm12, xmm11
00007f4f7cbda50b  vfmadd231pd xmm12, xmm15, xmm14
00007f4f7cbda510  vcmppd xmm9, xmm12, xmm12, 0x03
00007f4f7cbda516  vptest xmm9, xmm9
00007f4f7cbda51b  jnz 0x00007F4F7CBDCA79
00007f4f7cbda521  vmovaps xmm15, [rsp+0x90]
00007f4f7cbda52a  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbda530  movaps xmm11, xmm10
00007f4f7cbda534  vfmadd231pd xmm11, xmm13, xmm15
00007f4f7cbda539  vcmppd xmm14, xmm11, xmm11, 0x03
00007f4f7cbda53f  vptest xmm14, xmm14
00007f4f7cbda544  jnz 0x00007F4F7CBDCBD3
00007f4f7cbda54a  lea rax, [r14+0x90]
00007f4f7cbda551  movups xmm15, [r13+rax*1]
00007f4f7cbda557  lea rax, [r14+0xA0]
00007f4f7cbda55e  movups xmm14, [r13+rax*1]
00007f4f7cbda564  movaps [r15+0x140], xmm15
00007f4f7cbda56c  movaps [r15+0x130], xmm14
00007f4f7cbda574  vmovaps xmm13, [rsp+0x10]
00007f4f7cbda57a  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbda580  movaps xmm10, xmm8
00007f4f7cbda584  vfmadd231pd xmm10, xmm1, xmm13
00007f4f7cbda589  vcmppd xmm9, xmm10, xmm10, 0x03
00007f4f7cbda58f  vptest xmm9, xmm9
00007f4f7cbda594  jnz 0x00007F4F7CBDCD41
00007f4f7cbda59a  movaps [r15+0x220], xmm10
00007f4f7cbda5a2  lea rax, [r14+0x10]
00007f4f7cbda5a6  movups xmm1, [r13+rax*1]
00007f4f7cbda5ac  movaps [r15+0x240], xmm1
00007f4f7cbda5b4  vmovaps xmm13, [rsp+0x10]
00007f4f7cbda5ba  vpermilpd xmm13, xmm13, 0x00
00007f4f7cbda5c0  movaps xmm9, xmm7
00007f4f7cbda5c4  vfmadd231pd xmm9, xmm14, xmm13
00007f4f7cbda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007f4f7cbda5cf  vptest xmm8, xmm8
00007f4f7cbda5d4  jnz 0x00007F4F7CBDCEA4
00007f4f7cbda5da  movaps [r15+0x110], xmm9
00007f4f7cbda5e2  vmovaps xmm14, [rsp+0x10]
00007f4f7cbda5e8  vpermilpd xmm14, xmm14, 0x00
00007f4f7cbda5ee  movaps xmm13, xmm12
00007f4f7cbda5f2  vfmadd231pd xmm13, xmm15, xmm14
00007f4f7cbda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007f4f7cbda5fd  vptest xmm8, xmm8
00007f4f7cbda602  jnz 0x00007F4F7CBDCFFD
00007f4f7cbda608  movaps [r15+0x170], xmm13
00007f4f7cbda610  vmovaps xmm15, [rsp+0x10]
00007f4f7cbda616  vpermilpd xmm15, xmm15, 0x00
00007f4f7cbda61c  movaps xmm14, xmm11
00007f4f7cbda620  vfmadd231pd xmm14, xmm1, xmm15
00007f4f7cbda625  vcmppd xmm12, xmm14, xmm14, 0x03
00007f4f7cbda62b  vptest xmm12, xmm12
00007f4f7cbda630  jnz 0x00007F4F7CBDD157
00007f4f7cbda636  movaps [r15+0x230], xmm14
00007f4f7cbda63e  mov rax, [rsp+0xD0]
00007f4f7cbda646  movups [r13+rax*1], xmm9
00007f4f7cbda64c  lea r14, [rax+0x10]
00007f4f7cbda650  movups [r13+r14*1], xmm13
00007f4f7cbda656  lea r14, [rax+0x20]
00007f4f7cbda65a  movups [r13+r14*1], xmm10
00007f4f7cbda660  lea r14, [rax+0x30]
00007f4f7cbda664  movups [r13+r14*1], xmm14
00007f4f7cbda66a  mov eax, [r15+0x108]
00007f4f7cbda671  sahf
00007f4f7cbda672  jnz 0x00007F4F7CBDA6A4
00007f4f7cbda674  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbda67c  jz 0x00007F4F7CBD9950
00007f4f7cbda682  nop [rax+rax*1], ax
00007f4f7cbda68b  nop [rax+rax*1], eax
00007f4f7cbda693  mov eax, 0x410664
00007f4f7cbda698  mov [r15+0x100], rax
00007f4f7cbda69f  jmp 0x00007F4F7C9FE110
00007f4f7cbda6a4  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbda6ac  jz 0x00007F4F7CBD6050
00007f4f7cbda6b2  nop [rax+rax*1], ax
00007f4f7cbda6bb  nop [rax+rax*1], eax
00007f4f7cbda6c3  mov eax, 0x4104F0
00007f4f7cbda6c8  mov [r15+0x100], rax
00007f4f7cbda6cf  jmp 0x00007F4F7C9FE110
00007f4f7cbda6d4  int3
00007f4f7cbda6d5  call 0x00007F4F7CAE27E0
00007f4f7cbda6da  jmp 0x00007F4F7CBD9A10
00007f4f7cbda6df  call 0x00007F4F7CAE1570
00007f4f7cbda6e4  jmp 0x00007F4F7CBD9A19
00007f4f7cbda6e9  call 0x00007F4F7CAE27E0
00007f4f7cbda6ee  jmp 0x00007F4F7CBD9A62
00007f4f7cbda6f3  call 0x00007F4F7CAE1570
00007f4f7cbda6f8  jmp 0x00007F4F7CBD9A6B
00007f4f7cbda6fd  call 0x00007F4F7CAE27E0
00007f4f7cbda702  jmp 0x00007F4F7CBD9AEB
00007f4f7cbda707  call 0x00007F4F7CAE1570
00007f4f7cbda70c  jmp 0x00007F4F7CBD9AF4
00007f4f7cbda711  call 0x00007F4F7CA0DC20
00007f4f7cbda716  jmp 0x00007F4F7CBD9BD5
00007f4f7cbda71b  call 0x00007F4F7CAD64F0
00007f4f7cbda720  jmp 0x00007F4F7CBD9C04
00007f4f7cbda725  call 0x00007F4F7CAB47C0
00007f4f7cbda72a  jmp 0x00007F4F7CBD9C1F
00007f4f7cbda72f  sub rsp, 0x08
00007f4f7cbda733  push rax
00007f4f7cbda734  push rcx
00007f4f7cbda735  push rdx
00007f4f7cbda736  push rdi
00007f4f7cbda737  push rsi
00007f4f7cbda738  push r8
00007f4f7cbda73a  push r9
00007f4f7cbda73c  push r10
00007f4f7cbda73e  push r11
00007f4f7cbda740  sub rsp, 0xF0
00007f4f7cbda747  vmovaps [rsp], xmm0
00007f4f7cbda74c  vmovaps [rsp+0x10], xmm1
00007f4f7cbda752  vmovaps [rsp+0x20], xmm2
00007f4f7cbda758  vmovaps [rsp+0x30], xmm3
00007f4f7cbda75e  vmovaps [rsp+0x40], xmm4
00007f4f7cbda764  vmovaps [rsp+0x50], xmm5
00007f4f7cbda76a  vmovaps [rsp+0x60], xmm6
00007f4f7cbda770  vmovaps [rsp+0x70], xmm7
00007f4f7cbda776  vmovaps [rsp+0x80], xmm8
00007f4f7cbda77f  vmovaps [rsp+0x90], xmm9
00007f4f7cbda788  vmovaps [rsp+0xA0], xmm10
00007f4f7cbda791  vmovaps [rsp+0xB0], xmm11
00007f4f7cbda79a  vmovaps [rsp+0xC0], xmm12
00007f4f7cbda7a3  vmovaps [rsp+0xD0], xmm14
00007f4f7cbda7ac  vmovaps [rsp+0xE0], xmm15
00007f4f7cbda7b5  sub rsp, 0x40
00007f4f7cbda7b9  lea rdi, [rsp]
00007f4f7cbda7bd  lea rsi, [rsp+0x10]
00007f4f7cbda7c2  lea rdx, [rsp+0x20]
00007f4f7cbda7c7  lea rcx, [rsp+0x30]
00007f4f7cbda7cc  mov r8d, 0x00
00007f4f7cbda7d2  lea r9, [r15+0x3A8]
00007f4f7cbda7d9  movaps [rdi], xmm13
00007f4f7cbda7dd  movaps [rsi], xmm1
00007f4f7cbda7e0  movaps [rdx], xmm15
00007f4f7cbda7e4  movaps [rcx], xmm14
00007f4f7cbda7e8  mov rax, 0x643999485A50
00007f4f7cbda7f2  call rax
00007f4f7cbda7f4  movaps xmm13, [rsp]
00007f4f7cbda7f9  add rsp, 0x40
00007f4f7cbda7fd  vmovaps xmm0, [rsp]
00007f4f7cbda802  vmovaps xmm1, [rsp+0x10]
00007f4f7cbda808  vmovaps xmm2, [rsp+0x20]
00007f4f7cbda80e  vmovaps xmm3, [rsp+0x30]
00007f4f7cbda814  vmovaps xmm4, [rsp+0x40]
00007f4f7cbda81a  vmovaps xmm5, [rsp+0x50]
00007f4f7cbda820  vmovaps xmm6, [rsp+0x60]
00007f4f7cbda826  vmovaps xmm7, [rsp+0x70]
00007f4f7cbda82c  vmovaps xmm8, [rsp+0x80]
00007f4f7cbda835  vmovaps xmm9, [rsp+0x90]
00007f4f7cbda83e  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbda847  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbda850  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbda859  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbda862  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbda86b  add rsp, 0xF0
00007f4f7cbda872  pop r11
00007f4f7cbda874  pop r10
00007f4f7cbda876  pop r9
00007f4f7cbda878  pop r8
00007f4f7cbda87a  pop rsi
00007f4f7cbda87b  pop rdi
00007f4f7cbda87c  pop rdx
00007f4f7cbda87d  pop rcx
00007f4f7cbda87e  pop rax
00007f4f7cbda87f  add rsp, 0x08
00007f4f7cbda883  jmp 0x00007F4F7CBD9C92
00007f4f7cbda888  sub rsp, 0x08
00007f4f7cbda88c  push rax
00007f4f7cbda88d  push rcx
00007f4f7cbda88e  push rdx
00007f4f7cbda88f  push rdi
00007f4f7cbda890  push rsi
00007f4f7cbda891  push r8
00007f4f7cbda893  push r9
00007f4f7cbda895  push r10
00007f4f7cbda897  push r11
00007f4f7cbda899  sub rsp, 0xF0
00007f4f7cbda8a0  vmovaps [rsp], xmm0
00007f4f7cbda8a5  vmovaps [rsp+0x10], xmm1
00007f4f7cbda8ab  vmovaps [rsp+0x20], xmm2
00007f4f7cbda8b1  vmovaps [rsp+0x30], xmm3
00007f4f7cbda8b7  vmovaps [rsp+0x40], xmm4
00007f4f7cbda8bd  vmovaps [rsp+0x50], xmm5
00007f4f7cbda8c3  vmovaps [rsp+0x60], xmm6
00007f4f7cbda8c9  vmovaps [rsp+0x70], xmm7
00007f4f7cbda8cf  vmovaps [rsp+0x80], xmm8
00007f4f7cbda8d8  vmovaps [rsp+0x90], xmm9
00007f4f7cbda8e1  vmovaps [rsp+0xA0], xmm10
00007f4f7cbda8ea  vmovaps [rsp+0xB0], xmm11
00007f4f7cbda8f3  vmovaps [rsp+0xC0], xmm13
00007f4f7cbda8fc  vmovaps [rsp+0xD0], xmm14
00007f4f7cbda905  vmovaps [rsp+0xE0], xmm15
00007f4f7cbda90e  sub rsp, 0x40
00007f4f7cbda912  lea rdi, [rsp]
00007f4f7cbda916  lea rsi, [rsp+0x10]
00007f4f7cbda91b  lea rdx, [rsp+0x20]
00007f4f7cbda920  lea rcx, [rsp+0x30]
00007f4f7cbda925  mov r8d, 0x00
00007f4f7cbda92b  lea r9, [r15+0x3A8]
00007f4f7cbda932  movaps [rdi], xmm12
00007f4f7cbda936  movaps [rsi], xmm15
00007f4f7cbda93a  movaps [rdx], xmm1
00007f4f7cbda93d  movaps [rcx], xmm14
00007f4f7cbda941  mov rax, 0x643999485A50
00007f4f7cbda94b  call rax
00007f4f7cbda94d  movaps xmm12, [rsp]
00007f4f7cbda952  add rsp, 0x40
00007f4f7cbda956  vmovaps xmm0, [rsp]
00007f4f7cbda95b  vmovaps xmm1, [rsp+0x10]
00007f4f7cbda961  vmovaps xmm2, [rsp+0x20]
00007f4f7cbda967  vmovaps xmm3, [rsp+0x30]
00007f4f7cbda96d  vmovaps xmm4, [rsp+0x40]
00007f4f7cbda973  vmovaps xmm5, [rsp+0x50]
00007f4f7cbda979  vmovaps xmm6, [rsp+0x60]
00007f4f7cbda97f  vmovaps xmm7, [rsp+0x70]
00007f4f7cbda985  vmovaps xmm8, [rsp+0x80]
00007f4f7cbda98e  vmovaps xmm9, [rsp+0x90]
00007f4f7cbda997  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbda9a0  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbda9a9  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbda9b2  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbda9bb  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbda9c4  add rsp, 0xF0
00007f4f7cbda9cb  pop r11
00007f4f7cbda9cd  pop r10
00007f4f7cbda9cf  pop r9
00007f4f7cbda9d1  pop r8
00007f4f7cbda9d3  pop rsi
00007f4f7cbda9d4  pop rdi
00007f4f7cbda9d5  pop rdx
00007f4f7cbda9d6  pop rcx
00007f4f7cbda9d7  pop rax
00007f4f7cbda9d8  add rsp, 0x08
00007f4f7cbda9dc  jmp 0x00007F4F7CBD9CC0
00007f4f7cbda9e1  call 0x00007F4F7CAB52F0
00007f4f7cbda9e6  jmp 0x00007F4F7CBD9DAC
00007f4f7cbda9eb  sub rsp, 0x08
00007f4f7cbda9ef  push rax
00007f4f7cbda9f0  push rcx
00007f4f7cbda9f1  push rdx
00007f4f7cbda9f2  push rdi
00007f4f7cbda9f3  push rsi
00007f4f7cbda9f4  push r8
00007f4f7cbda9f6  push r9
00007f4f7cbda9f8  push r10
00007f4f7cbda9fa  push r11
00007f4f7cbda9fc  sub rsp, 0xF0
00007f4f7cbdaa03  vmovaps [rsp], xmm0
00007f4f7cbdaa08  vmovaps [rsp+0x10], xmm1
00007f4f7cbdaa0e  vmovaps [rsp+0x20], xmm2
00007f4f7cbdaa14  vmovaps [rsp+0x30], xmm3
00007f4f7cbdaa1a  vmovaps [rsp+0x40], xmm4
00007f4f7cbdaa20  vmovaps [rsp+0x50], xmm5
00007f4f7cbdaa26  vmovaps [rsp+0x60], xmm6
00007f4f7cbdaa2c  vmovaps [rsp+0x70], xmm7
00007f4f7cbdaa32  vmovaps [rsp+0x80], xmm8
00007f4f7cbdaa3b  vmovaps [rsp+0x90], xmm9
00007f4f7cbdaa44  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdaa4d  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdaa56  vmovaps [rsp+0xC0], xmm12
00007f4f7cbdaa5f  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdaa68  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdaa71  sub rsp, 0x40
00007f4f7cbdaa75  lea rdi, [rsp]
00007f4f7cbdaa79  lea rsi, [rsp+0x10]
00007f4f7cbdaa7e  lea rdx, [rsp+0x20]
00007f4f7cbdaa83  lea rcx, [rsp+0x30]
00007f4f7cbdaa88  mov r8d, 0x00
00007f4f7cbdaa8e  lea r9, [r15+0x3A8]
00007f4f7cbdaa95  movaps [rdi], xmm13
00007f4f7cbdaa99  movaps [rsi], xmm1
00007f4f7cbdaa9c  movaps [rdx], xmm15
00007f4f7cbdaaa0  movaps [rcx], xmm14
00007f4f7cbdaaa4  mov rax, 0x643999485A50
00007f4f7cbdaaae  call rax
00007f4f7cbdaab0  movaps xmm13, [rsp]
00007f4f7cbdaab5  add rsp, 0x40
00007f4f7cbdaab9  vmovaps xmm0, [rsp]
00007f4f7cbdaabe  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdaac4  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdaaca  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdaad0  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdaad6  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdaadc  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdaae2  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdaae8  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdaaf1  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdaafa  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdab03  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdab0c  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbdab15  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdab1e  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdab27  add rsp, 0xF0
00007f4f7cbdab2e  pop r11
00007f4f7cbdab30  pop r10
00007f4f7cbdab32  pop r9
00007f4f7cbdab34  pop r8
00007f4f7cbdab36  pop rsi
00007f4f7cbdab37  pop rdi
00007f4f7cbdab38  pop rdx
00007f4f7cbdab39  pop rcx
00007f4f7cbdab3a  pop rax
00007f4f7cbdab3b  add rsp, 0x08
00007f4f7cbdab3f  jmp 0x00007F4F7CBD9E21
00007f4f7cbdab44  call 0x00007F4F7C9FF430
00007f4f7cbdab49  jmp 0x00007F4F7CBD9E2E
00007f4f7cbdab4e  sub rsp, 0x08
00007f4f7cbdab52  push rax
00007f4f7cbdab53  push rcx
00007f4f7cbdab54  push rdx
00007f4f7cbdab55  push rdi
00007f4f7cbdab56  push rsi
00007f4f7cbdab57  push r8
00007f4f7cbdab59  push r9
00007f4f7cbdab5b  push r10
00007f4f7cbdab5d  push r11
00007f4f7cbdab5f  sub rsp, 0xF0
00007f4f7cbdab66  vmovaps [rsp], xmm0
00007f4f7cbdab6b  vmovaps [rsp+0x10], xmm1
00007f4f7cbdab71  vmovaps [rsp+0x20], xmm2
00007f4f7cbdab77  vmovaps [rsp+0x30], xmm3
00007f4f7cbdab7d  vmovaps [rsp+0x40], xmm4
00007f4f7cbdab83  vmovaps [rsp+0x50], xmm5
00007f4f7cbdab89  vmovaps [rsp+0x60], xmm6
00007f4f7cbdab8f  vmovaps [rsp+0x70], xmm7
00007f4f7cbdab95  vmovaps [rsp+0x80], xmm8
00007f4f7cbdab9e  vmovaps [rsp+0x90], xmm9
00007f4f7cbdaba7  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdabb0  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdabb9  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdabc2  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdabcb  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdabd4  sub rsp, 0x40
00007f4f7cbdabd8  lea rdi, [rsp]
00007f4f7cbdabdc  lea rsi, [rsp+0x10]
00007f4f7cbdabe1  lea rdx, [rsp+0x20]
00007f4f7cbdabe6  lea rcx, [rsp+0x30]
00007f4f7cbdabeb  mov r8d, 0x00
00007f4f7cbdabf1  lea r9, [r15+0x3A8]
00007f4f7cbdabf8  movaps [rdi], xmm12
00007f4f7cbdabfc  movaps [rsi], xmm15
00007f4f7cbdac00  movaps [rdx], xmm1
00007f4f7cbdac03  movaps [rcx], xmm14
00007f4f7cbdac07  mov rax, 0x643999485A50
00007f4f7cbdac11  call rax
00007f4f7cbdac13  movaps xmm12, [rsp]
00007f4f7cbdac18  add rsp, 0x40
00007f4f7cbdac1c  vmovaps xmm0, [rsp]
00007f4f7cbdac21  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdac27  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdac2d  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdac33  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdac39  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdac3f  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdac45  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdac4b  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdac54  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdac5d  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdac66  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdac6f  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdac78  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdac81  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdac8a  add rsp, 0xF0
00007f4f7cbdac91  pop r11
00007f4f7cbdac93  pop r10
00007f4f7cbdac95  pop r9
00007f4f7cbdac97  pop r8
00007f4f7cbdac99  pop rsi
00007f4f7cbdac9a  pop rdi
00007f4f7cbdac9b  pop rdx
00007f4f7cbdac9c  pop rcx
00007f4f7cbdac9d  pop rax
00007f4f7cbdac9e  add rsp, 0x08
00007f4f7cbdaca2  jmp 0x00007F4F7CBD9E5A
00007f4f7cbdaca7  sub rsp, 0x08
00007f4f7cbdacab  push rax
00007f4f7cbdacac  push rcx
00007f4f7cbdacad  push rdx
00007f4f7cbdacae  push rdi
00007f4f7cbdacaf  push rsi
00007f4f7cbdacb0  push r8
00007f4f7cbdacb2  push r9
00007f4f7cbdacb4  push r10
00007f4f7cbdacb6  push r11
00007f4f7cbdacb8  sub rsp, 0xF0
00007f4f7cbdacbf  vmovaps [rsp], xmm0
00007f4f7cbdacc4  vmovaps [rsp+0x10], xmm1
00007f4f7cbdacca  vmovaps [rsp+0x20], xmm2
00007f4f7cbdacd0  vmovaps [rsp+0x30], xmm3
00007f4f7cbdacd6  vmovaps [rsp+0x40], xmm4
00007f4f7cbdacdc  vmovaps [rsp+0x50], xmm5
00007f4f7cbdace2  vmovaps [rsp+0x60], xmm6
00007f4f7cbdace8  vmovaps [rsp+0x70], xmm7
00007f4f7cbdacee  vmovaps [rsp+0x80], xmm8
00007f4f7cbdacf7  vmovaps [rsp+0x90], xmm9
00007f4f7cbdad00  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdad09  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdad12  vmovaps [rsp+0xC0], xmm12
00007f4f7cbdad1b  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdad24  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdad2d  sub rsp, 0x40
00007f4f7cbdad31  lea rdi, [rsp]
00007f4f7cbdad35  lea rsi, [rsp+0x10]
00007f4f7cbdad3a  lea rdx, [rsp+0x20]
00007f4f7cbdad3f  lea rcx, [rsp+0x30]
00007f4f7cbdad44  mov r8d, 0x00
00007f4f7cbdad4a  lea r9, [r15+0x3A8]
00007f4f7cbdad51  movaps [rdi], xmm13
00007f4f7cbdad55  movaps [rsi], xmm1
00007f4f7cbdad58  movaps [rdx], xmm15
00007f4f7cbdad5c  movaps [rcx], xmm14
00007f4f7cbdad60  mov rax, 0x643999485A50
00007f4f7cbdad6a  call rax
00007f4f7cbdad6c  movaps xmm13, [rsp]
00007f4f7cbdad71  add rsp, 0x40
00007f4f7cbdad75  vmovaps xmm0, [rsp]
00007f4f7cbdad7a  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdad80  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdad86  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdad8c  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdad92  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdad98  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdad9e  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdada4  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdadad  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdadb6  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdadbf  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdadc8  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbdadd1  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdadda  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdade3  add rsp, 0xF0
00007f4f7cbdadea  pop r11
00007f4f7cbdadec  pop r10
00007f4f7cbdadee  pop r9
00007f4f7cbdadf0  pop r8
00007f4f7cbdadf2  pop rsi
00007f4f7cbdadf3  pop rdi
00007f4f7cbdadf4  pop rdx
00007f4f7cbdadf5  pop rcx
00007f4f7cbdadf6  pop rax
00007f4f7cbdadf7  add rsp, 0x08
00007f4f7cbdadfb  jmp 0x00007F4F7CBD9FEA
00007f4f7cbdae00  sub rsp, 0x08
00007f4f7cbdae04  push rax
00007f4f7cbdae05  push rcx
00007f4f7cbdae06  push rdx
00007f4f7cbdae07  push rdi
00007f4f7cbdae08  push rsi
00007f4f7cbdae09  push r8
00007f4f7cbdae0b  push r9
00007f4f7cbdae0d  push r10
00007f4f7cbdae0f  push r11
00007f4f7cbdae11  sub rsp, 0xF0
00007f4f7cbdae18  vmovaps [rsp], xmm0
00007f4f7cbdae1d  vmovaps [rsp+0x10], xmm1
00007f4f7cbdae23  vmovaps [rsp+0x20], xmm2
00007f4f7cbdae29  vmovaps [rsp+0x30], xmm3
00007f4f7cbdae2f  vmovaps [rsp+0x40], xmm4
00007f4f7cbdae35  vmovaps [rsp+0x50], xmm5
00007f4f7cbdae3b  vmovaps [rsp+0x60], xmm6
00007f4f7cbdae41  vmovaps [rsp+0x70], xmm7
00007f4f7cbdae47  vmovaps [rsp+0x80], xmm8
00007f4f7cbdae50  vmovaps [rsp+0x90], xmm9
00007f4f7cbdae59  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdae62  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdae6b  vmovaps [rsp+0xC0], xmm12
00007f4f7cbdae74  vmovaps [rsp+0xD0], xmm13
00007f4f7cbdae7d  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdae86  sub rsp, 0x40
00007f4f7cbdae8a  lea rdi, [rsp]
00007f4f7cbdae8e  lea rsi, [rsp+0x10]
00007f4f7cbdae93  lea rdx, [rsp+0x20]
00007f4f7cbdae98  lea rcx, [rsp+0x30]
00007f4f7cbdae9d  mov r8d, 0x00
00007f4f7cbdaea3  lea r9, [r15+0x3A8]
00007f4f7cbdaeaa  movaps [rdi], xmm14
00007f4f7cbdaeae  movaps [rsi], xmm15
00007f4f7cbdaeb2  movaps [rdx], xmm2
00007f4f7cbdaeb5  movaps [rcx], xmm1
00007f4f7cbdaeb8  mov rax, 0x643999485A50
00007f4f7cbdaec2  call rax
00007f4f7cbdaec4  movaps xmm14, [rsp]
00007f4f7cbdaec9  add rsp, 0x40
00007f4f7cbdaecd  vmovaps xmm0, [rsp]
00007f4f7cbdaed2  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdaed8  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdaede  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdaee4  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdaeea  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdaef0  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdaef6  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdaefc  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdaf05  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdaf0e  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdaf17  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdaf20  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbdaf29  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbdaf32  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdaf3b  add rsp, 0xF0
00007f4f7cbdaf42  pop r11
00007f4f7cbdaf44  pop r10
00007f4f7cbdaf46  pop r9
00007f4f7cbdaf48  pop r8
00007f4f7cbdaf4a  pop rsi
00007f4f7cbdaf4b  pop rdi
00007f4f7cbdaf4c  pop rdx
00007f4f7cbdaf4d  pop rcx
00007f4f7cbdaf4e  pop rax
00007f4f7cbdaf4f  add rsp, 0x08
00007f4f7cbdaf53  jmp 0x00007F4F7CBDA01C
00007f4f7cbdaf58  sub rsp, 0x08
00007f4f7cbdaf5c  push rax
00007f4f7cbdaf5d  push rcx
00007f4f7cbdaf5e  push rdx
00007f4f7cbdaf5f  push rdi
00007f4f7cbdaf60  push rsi
00007f4f7cbdaf61  push r8
00007f4f7cbdaf63  push r9
00007f4f7cbdaf65  push r10
00007f4f7cbdaf67  push r11
00007f4f7cbdaf69  sub rsp, 0xF0
00007f4f7cbdaf70  vmovaps [rsp], xmm0
00007f4f7cbdaf75  vmovaps [rsp+0x10], xmm1
00007f4f7cbdaf7b  vmovaps [rsp+0x20], xmm3
00007f4f7cbdaf81  vmovaps [rsp+0x30], xmm4
00007f4f7cbdaf87  vmovaps [rsp+0x40], xmm5
00007f4f7cbdaf8d  vmovaps [rsp+0x50], xmm6
00007f4f7cbdaf93  vmovaps [rsp+0x60], xmm7
00007f4f7cbdaf99  vmovaps [rsp+0x70], xmm8
00007f4f7cbdaf9f  vmovaps [rsp+0x80], xmm9
00007f4f7cbdafa8  vmovaps [rsp+0x90], xmm10
00007f4f7cbdafb1  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdafba  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdafc3  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdafcc  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdafd5  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdafde  sub rsp, 0x40
00007f4f7cbdafe2  lea rdi, [rsp]
00007f4f7cbdafe6  lea rsi, [rsp+0x10]
00007f4f7cbdafeb  lea rdx, [rsp+0x20]
00007f4f7cbdaff0  lea rcx, [rsp+0x30]
00007f4f7cbdaff5  mov r8d, 0x00
00007f4f7cbdaffb  lea r9, [r15+0x3A8]
00007f4f7cbdb002  movaps [rdi], xmm2
00007f4f7cbdb005  movaps [rsi], xmm15
00007f4f7cbdb009  movaps [rdx], xmm12
00007f4f7cbdb00d  movaps [rcx], xmm1
00007f4f7cbdb010  mov rax, 0x643999485A50
00007f4f7cbdb01a  call rax
00007f4f7cbdb01c  movaps xmm2, [rsp]
00007f4f7cbdb020  add rsp, 0x40
00007f4f7cbdb024  vmovaps xmm0, [rsp]
00007f4f7cbdb029  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdb02f  vmovaps xmm3, [rsp+0x20]
00007f4f7cbdb035  vmovaps xmm4, [rsp+0x30]
00007f4f7cbdb03b  vmovaps xmm5, [rsp+0x40]
00007f4f7cbdb041  vmovaps xmm6, [rsp+0x50]
00007f4f7cbdb047  vmovaps xmm7, [rsp+0x60]
00007f4f7cbdb04d  vmovaps xmm8, [rsp+0x70]
00007f4f7cbdb053  vmovaps xmm9, [rsp+0x80]
00007f4f7cbdb05c  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdb065  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdb06e  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdb077  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdb080  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdb089  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdb092  add rsp, 0xF0
00007f4f7cbdb099  pop r11
00007f4f7cbdb09b  pop r10
00007f4f7cbdb09d  pop r9
00007f4f7cbdb09f  pop r8
00007f4f7cbdb0a1  pop rsi
00007f4f7cbdb0a2  pop rdi
00007f4f7cbdb0a3  pop rdx
00007f4f7cbdb0a4  pop rcx
00007f4f7cbdb0a5  pop rax
00007f4f7cbdb0a6  add rsp, 0x08
00007f4f7cbdb0aa  jmp 0x00007F4F7CBDA059
00007f4f7cbdb0af  sub rsp, 0x08
00007f4f7cbdb0b3  push rax
00007f4f7cbdb0b4  push rcx
00007f4f7cbdb0b5  push rdx
00007f4f7cbdb0b6  push rdi
00007f4f7cbdb0b7  push rsi
00007f4f7cbdb0b8  push r8
00007f4f7cbdb0ba  push r9
00007f4f7cbdb0bc  push r10
00007f4f7cbdb0be  push r11
00007f4f7cbdb0c0  sub rsp, 0xF0
00007f4f7cbdb0c7  vmovaps [rsp], xmm0
00007f4f7cbdb0cc  vmovaps [rsp+0x10], xmm1
00007f4f7cbdb0d2  vmovaps [rsp+0x20], xmm2
00007f4f7cbdb0d8  vmovaps [rsp+0x30], xmm3
00007f4f7cbdb0de  vmovaps [rsp+0x40], xmm4
00007f4f7cbdb0e4  vmovaps [rsp+0x50], xmm5
00007f4f7cbdb0ea  vmovaps [rsp+0x60], xmm6
00007f4f7cbdb0f0  vmovaps [rsp+0x70], xmm7
00007f4f7cbdb0f6  vmovaps [rsp+0x80], xmm8
00007f4f7cbdb0ff  vmovaps [rsp+0x90], xmm9
00007f4f7cbdb108  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdb111  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdb11a  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdb123  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdb12c  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdb135  sub rsp, 0x40
00007f4f7cbdb139  lea rdi, [rsp]
00007f4f7cbdb13d  lea rsi, [rsp+0x10]
00007f4f7cbdb142  lea rdx, [rsp+0x20]
00007f4f7cbdb147  lea rcx, [rsp+0x30]
00007f4f7cbdb14c  mov r8d, 0x00
00007f4f7cbdb152  lea r9, [r15+0x3A8]
00007f4f7cbdb159  movaps [rdi], xmm12
00007f4f7cbdb15d  movaps [rsi], xmm14
00007f4f7cbdb161  movaps [rdx], xmm3
00007f4f7cbdb164  movaps [rcx], xmm15
00007f4f7cbdb168  mov rax, 0x643999485A50
00007f4f7cbdb172  call rax
00007f4f7cbdb174  movaps xmm12, [rsp]
00007f4f7cbdb179  add rsp, 0x40
00007f4f7cbdb17d  vmovaps xmm0, [rsp]
00007f4f7cbdb182  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdb188  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdb18e  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdb194  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdb19a  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdb1a0  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdb1a6  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdb1ac  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdb1b5  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdb1be  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdb1c7  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdb1d0  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdb1d9  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdb1e2  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdb1eb  add rsp, 0xF0
00007f4f7cbdb1f2  pop r11
00007f4f7cbdb1f4  pop r10
00007f4f7cbdb1f6  pop r9
00007f4f7cbdb1f8  pop r8
00007f4f7cbdb1fa  pop rsi
00007f4f7cbdb1fb  pop rdi
00007f4f7cbdb1fc  pop rdx
00007f4f7cbdb1fd  pop rcx
00007f4f7cbdb1fe  pop rax
00007f4f7cbdb1ff  add rsp, 0x08
00007f4f7cbdb203  jmp 0x00007F4F7CBDA0B3
00007f4f7cbdb208  sub rsp, 0x08
00007f4f7cbdb20c  push rax
00007f4f7cbdb20d  push rcx
00007f4f7cbdb20e  push rdx
00007f4f7cbdb20f  push rdi
00007f4f7cbdb210  push rsi
00007f4f7cbdb211  push r8
00007f4f7cbdb213  push r9
00007f4f7cbdb215  push r10
00007f4f7cbdb217  push r11
00007f4f7cbdb219  sub rsp, 0xF0
00007f4f7cbdb220  vmovaps [rsp], xmm0
00007f4f7cbdb225  vmovaps [rsp+0x10], xmm1
00007f4f7cbdb22b  vmovaps [rsp+0x20], xmm2
00007f4f7cbdb231  vmovaps [rsp+0x30], xmm3
00007f4f7cbdb237  vmovaps [rsp+0x40], xmm4
00007f4f7cbdb23d  vmovaps [rsp+0x50], xmm5
00007f4f7cbdb243  vmovaps [rsp+0x60], xmm6
00007f4f7cbdb249  vmovaps [rsp+0x70], xmm7
00007f4f7cbdb24f  vmovaps [rsp+0x80], xmm8
00007f4f7cbdb258  vmovaps [rsp+0x90], xmm10
00007f4f7cbdb261  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdb26a  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdb273  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdb27c  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdb285  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdb28e  sub rsp, 0x40
00007f4f7cbdb292  lea rdi, [rsp]
00007f4f7cbdb296  lea rsi, [rsp+0x10]
00007f4f7cbdb29b  lea rdx, [rsp+0x20]
00007f4f7cbdb2a0  lea rcx, [rsp+0x30]
00007f4f7cbdb2a5  mov r8d, 0x00
00007f4f7cbdb2ab  lea r9, [r15+0x3A8]
00007f4f7cbdb2b2  movaps [rdi], xmm9
00007f4f7cbdb2b6  movaps [rsi], xmm13
00007f4f7cbdb2ba  movaps [rdx], xmm14
00007f4f7cbdb2be  movaps [rcx], xmm6
00007f4f7cbdb2c1  mov rax, 0x643999485A50
00007f4f7cbdb2cb  call rax
00007f4f7cbdb2cd  movaps xmm9, [rsp]
00007f4f7cbdb2d2  add rsp, 0x40
00007f4f7cbdb2d6  vmovaps xmm0, [rsp]
00007f4f7cbdb2db  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdb2e1  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdb2e7  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdb2ed  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdb2f3  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdb2f9  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdb2ff  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdb305  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdb30e  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdb317  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdb320  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdb329  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdb332  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdb33b  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdb344  add rsp, 0xF0
00007f4f7cbdb34b  pop r11
00007f4f7cbdb34d  pop r10
00007f4f7cbdb34f  pop r9
00007f4f7cbdb351  pop r8
00007f4f7cbdb353  pop rsi
00007f4f7cbdb354  pop rdi
00007f4f7cbdb355  pop rdx
00007f4f7cbdb356  pop rcx
00007f4f7cbdb357  pop rax
00007f4f7cbdb358  add rsp, 0x08
00007f4f7cbdb35c  jmp 0x00007F4F7CBDA15D
00007f4f7cbdb361  sub rsp, 0x08
00007f4f7cbdb365  push rax
00007f4f7cbdb366  push rcx
00007f4f7cbdb367  push rdx
00007f4f7cbdb368  push rdi
00007f4f7cbdb369  push rsi
00007f4f7cbdb36a  push r8
00007f4f7cbdb36c  push r9
00007f4f7cbdb36e  push r10
00007f4f7cbdb370  push r11
00007f4f7cbdb372  sub rsp, 0xF0
00007f4f7cbdb379  vmovaps [rsp], xmm0
00007f4f7cbdb37e  vmovaps [rsp+0x10], xmm1
00007f4f7cbdb384  vmovaps [rsp+0x20], xmm2
00007f4f7cbdb38a  vmovaps [rsp+0x30], xmm4
00007f4f7cbdb390  vmovaps [rsp+0x40], xmm5
00007f4f7cbdb396  vmovaps [rsp+0x50], xmm6
00007f4f7cbdb39c  vmovaps [rsp+0x60], xmm7
00007f4f7cbdb3a2  vmovaps [rsp+0x70], xmm8
00007f4f7cbdb3a8  vmovaps [rsp+0x80], xmm9
00007f4f7cbdb3b1  vmovaps [rsp+0x90], xmm10
00007f4f7cbdb3ba  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdb3c3  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdb3cc  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdb3d5  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdb3de  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdb3e7  sub rsp, 0x40
00007f4f7cbdb3eb  lea rdi, [rsp]
00007f4f7cbdb3ef  lea rsi, [rsp+0x10]
00007f4f7cbdb3f4  lea rdx, [rsp+0x20]
00007f4f7cbdb3f9  lea rcx, [rsp+0x30]
00007f4f7cbdb3fe  mov r8d, 0x00
00007f4f7cbdb404  lea r9, [r15+0x3A8]
00007f4f7cbdb40b  movaps [rdi], xmm3
00007f4f7cbdb40e  movaps [rsi], xmm13
00007f4f7cbdb412  movaps [rdx], xmm6
00007f4f7cbdb415  movaps [rcx], xmm14
00007f4f7cbdb419  mov rax, 0x643999485A50
00007f4f7cbdb423  call rax
00007f4f7cbdb425  movaps xmm3, [rsp]
00007f4f7cbdb429  add rsp, 0x40
00007f4f7cbdb42d  vmovaps xmm0, [rsp]
00007f4f7cbdb432  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdb438  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdb43e  vmovaps xmm4, [rsp+0x30]
00007f4f7cbdb444  vmovaps xmm5, [rsp+0x40]
00007f4f7cbdb44a  vmovaps xmm6, [rsp+0x50]
00007f4f7cbdb450  vmovaps xmm7, [rsp+0x60]
00007f4f7cbdb456  vmovaps xmm8, [rsp+0x70]
00007f4f7cbdb45c  vmovaps xmm9, [rsp+0x80]
00007f4f7cbdb465  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdb46e  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdb477  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdb480  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdb489  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdb492  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdb49b  add rsp, 0xF0
00007f4f7cbdb4a2  pop r11
00007f4f7cbdb4a4  pop r10
00007f4f7cbdb4a6  pop r9
00007f4f7cbdb4a8  pop r8
00007f4f7cbdb4aa  pop rsi
00007f4f7cbdb4ab  pop rdi
00007f4f7cbdb4ac  pop rdx
00007f4f7cbdb4ad  pop rcx
00007f4f7cbdb4ae  pop rax
00007f4f7cbdb4af  add rsp, 0x08
00007f4f7cbdb4b3  jmp 0x00007F4F7CBDA19A
00007f4f7cbdb4b8  sub rsp, 0x08
00007f4f7cbdb4bc  push rax
00007f4f7cbdb4bd  push rcx
00007f4f7cbdb4be  push rdx
00007f4f7cbdb4bf  push rdi
00007f4f7cbdb4c0  push rsi
00007f4f7cbdb4c1  push r8
00007f4f7cbdb4c3  push r9
00007f4f7cbdb4c5  push r10
00007f4f7cbdb4c7  push r11
00007f4f7cbdb4c9  sub rsp, 0xF0
00007f4f7cbdb4d0  vmovaps [rsp], xmm0
00007f4f7cbdb4d5  vmovaps [rsp+0x10], xmm1
00007f4f7cbdb4db  vmovaps [rsp+0x20], xmm2
00007f4f7cbdb4e1  vmovaps [rsp+0x30], xmm3
00007f4f7cbdb4e7  vmovaps [rsp+0x40], xmm4
00007f4f7cbdb4ed  vmovaps [rsp+0x50], xmm5
00007f4f7cbdb4f3  vmovaps [rsp+0x60], xmm7
00007f4f7cbdb4f9  vmovaps [rsp+0x70], xmm8
00007f4f7cbdb4ff  vmovaps [rsp+0x80], xmm9
00007f4f7cbdb508  vmovaps [rsp+0x90], xmm10
00007f4f7cbdb511  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdb51a  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdb523  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdb52c  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdb535  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdb53e  sub rsp, 0x40
00007f4f7cbdb542  lea rdi, [rsp]
00007f4f7cbdb546  lea rsi, [rsp+0x10]
00007f4f7cbdb54b  lea rdx, [rsp+0x20]
00007f4f7cbdb550  lea rcx, [rsp+0x30]
00007f4f7cbdb555  mov r8d, 0x00
00007f4f7cbdb55b  lea r9, [r15+0x3A8]
00007f4f7cbdb562  movaps [rdi], xmm6
00007f4f7cbdb565  movaps [rsi], xmm2
00007f4f7cbdb568  movaps [rdx], xmm14
00007f4f7cbdb56c  movaps [rcx], xmm1
00007f4f7cbdb56f  mov rax, 0x643999485A50
00007f4f7cbdb579  call rax
00007f4f7cbdb57b  movaps xmm6, [rsp]
00007f4f7cbdb57f  add rsp, 0x40
00007f4f7cbdb583  vmovaps xmm0, [rsp]
00007f4f7cbdb588  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdb58e  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdb594  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdb59a  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdb5a0  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdb5a6  vmovaps xmm7, [rsp+0x60]
00007f4f7cbdb5ac  vmovaps xmm8, [rsp+0x70]
00007f4f7cbdb5b2  vmovaps xmm9, [rsp+0x80]
00007f4f7cbdb5bb  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdb5c4  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdb5cd  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdb5d6  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdb5df  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdb5e8  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdb5f1  add rsp, 0xF0
00007f4f7cbdb5f8  pop r11
00007f4f7cbdb5fa  pop r10
00007f4f7cbdb5fc  pop r9
00007f4f7cbdb5fe  pop r8
00007f4f7cbdb600  pop rsi
00007f4f7cbdb601  pop rdi
00007f4f7cbdb602  pop rdx
00007f4f7cbdb603  pop rcx
00007f4f7cbdb604  pop rax
00007f4f7cbdb605  add rsp, 0x08
00007f4f7cbdb609  jmp 0x00007F4F7CBDA1C7
00007f4f7cbdb60e  sub rsp, 0x08
00007f4f7cbdb612  push rax
00007f4f7cbdb613  push rcx
00007f4f7cbdb614  push rdx
00007f4f7cbdb615  push rdi
00007f4f7cbdb616  push rsi
00007f4f7cbdb617  push r8
00007f4f7cbdb619  push r9
00007f4f7cbdb61b  push r10
00007f4f7cbdb61d  push r11
00007f4f7cbdb61f  sub rsp, 0xF0
00007f4f7cbdb626  vmovaps [rsp], xmm0
00007f4f7cbdb62b  vmovaps [rsp+0x10], xmm1
00007f4f7cbdb631  vmovaps [rsp+0x20], xmm2
00007f4f7cbdb637  vmovaps [rsp+0x30], xmm3
00007f4f7cbdb63d  vmovaps [rsp+0x40], xmm4
00007f4f7cbdb643  vmovaps [rsp+0x50], xmm5
00007f4f7cbdb649  vmovaps [rsp+0x60], xmm6
00007f4f7cbdb64f  vmovaps [rsp+0x70], xmm7
00007f4f7cbdb655  vmovaps [rsp+0x80], xmm8
00007f4f7cbdb65e  vmovaps [rsp+0x90], xmm9
00007f4f7cbdb667  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdb670  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdb679  vmovaps [rsp+0xC0], xmm12
00007f4f7cbdb682  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdb68b  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdb694  sub rsp, 0x40
00007f4f7cbdb698  lea rdi, [rsp]
00007f4f7cbdb69c  lea rsi, [rsp+0x10]
00007f4f7cbdb6a1  lea rdx, [rsp+0x20]
00007f4f7cbdb6a6  lea rcx, [rsp+0x30]
00007f4f7cbdb6ab  mov r8d, 0x00
00007f4f7cbdb6b1  lea r9, [r15+0x3A8]
00007f4f7cbdb6b8  movaps [rdi], xmm13
00007f4f7cbdb6bc  movaps [rsi], xmm12
00007f4f7cbdb6c0  movaps [rdx], xmm14
00007f4f7cbdb6c4  movaps [rcx], xmm1
00007f4f7cbdb6c7  mov rax, 0x643999485A50
00007f4f7cbdb6d1  call rax
00007f4f7cbdb6d3  movaps xmm13, [rsp]
00007f4f7cbdb6d8  add rsp, 0x40
00007f4f7cbdb6dc  vmovaps xmm0, [rsp]
00007f4f7cbdb6e1  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdb6e7  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdb6ed  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdb6f3  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdb6f9  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdb6ff  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdb705  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdb70b  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdb714  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdb71d  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdb726  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdb72f  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbdb738  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdb741  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdb74a  add rsp, 0xF0
00007f4f7cbdb751  pop r11
00007f4f7cbdb753  pop r10
00007f4f7cbdb755  pop r9
00007f4f7cbdb757  pop r8
00007f4f7cbdb759  pop rsi
00007f4f7cbdb75a  pop rdi
00007f4f7cbdb75b  pop rdx
00007f4f7cbdb75c  pop rcx
00007f4f7cbdb75d  pop rax
00007f4f7cbdb75e  add rsp, 0x08
00007f4f7cbdb762  jmp 0x00007F4F7CBDA1F9
00007f4f7cbdb767  sub rsp, 0x08
00007f4f7cbdb76b  push rax
00007f4f7cbdb76c  push rcx
00007f4f7cbdb76d  push rdx
00007f4f7cbdb76e  push rdi
00007f4f7cbdb76f  push rsi
00007f4f7cbdb770  push r8
00007f4f7cbdb772  push r9
00007f4f7cbdb774  push r10
00007f4f7cbdb776  push r11
00007f4f7cbdb778  sub rsp, 0xF0
00007f4f7cbdb77f  vmovaps [rsp], xmm0
00007f4f7cbdb784  vmovaps [rsp+0x10], xmm1
00007f4f7cbdb78a  vmovaps [rsp+0x20], xmm2
00007f4f7cbdb790  vmovaps [rsp+0x30], xmm3
00007f4f7cbdb796  vmovaps [rsp+0x40], xmm4
00007f4f7cbdb79c  vmovaps [rsp+0x50], xmm5
00007f4f7cbdb7a2  vmovaps [rsp+0x60], xmm6
00007f4f7cbdb7a8  vmovaps [rsp+0x70], xmm7
00007f4f7cbdb7ae  vmovaps [rsp+0x80], xmm8
00007f4f7cbdb7b7  vmovaps [rsp+0x90], xmm9
00007f4f7cbdb7c0  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdb7c9  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdb7d2  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdb7db  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdb7e4  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdb7ed  sub rsp, 0x40
00007f4f7cbdb7f1  lea rdi, [rsp]
00007f4f7cbdb7f5  lea rsi, [rsp+0x10]
00007f4f7cbdb7fa  lea rdx, [rsp+0x20]
00007f4f7cbdb7ff  lea rcx, [rsp+0x30]
00007f4f7cbdb804  mov r8d, 0x00
00007f4f7cbdb80a  lea r9, [r15+0x3A8]
00007f4f7cbdb811  movaps [rdi], xmm12
00007f4f7cbdb815  movaps [rsi], xmm3
00007f4f7cbdb818  movaps [rdx], xmm14
00007f4f7cbdb81c  movaps [rcx], xmm5
00007f4f7cbdb81f  mov rax, 0x643999485A50
00007f4f7cbdb829  call rax
00007f4f7cbdb82b  movaps xmm12, [rsp]
00007f4f7cbdb830  add rsp, 0x40
00007f4f7cbdb834  vmovaps xmm0, [rsp]
00007f4f7cbdb839  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdb83f  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdb845  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdb84b  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdb851  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdb857  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdb85d  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdb863  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdb86c  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdb875  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdb87e  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdb887  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdb890  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdb899  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdb8a2  add rsp, 0xF0
00007f4f7cbdb8a9  pop r11
00007f4f7cbdb8ab  pop r10
00007f4f7cbdb8ad  pop r9
00007f4f7cbdb8af  pop r8
00007f4f7cbdb8b1  pop rsi
00007f4f7cbdb8b2  pop rdi
00007f4f7cbdb8b3  pop rdx
00007f4f7cbdb8b4  pop rcx
00007f4f7cbdb8b5  pop rax
00007f4f7cbdb8b6  add rsp, 0x08
00007f4f7cbdb8ba  jmp 0x00007F4F7CBDA256
00007f4f7cbdb8bf  sub rsp, 0x08
00007f4f7cbdb8c3  push rax
00007f4f7cbdb8c4  push rcx
00007f4f7cbdb8c5  push rdx
00007f4f7cbdb8c6  push rdi
00007f4f7cbdb8c7  push rsi
00007f4f7cbdb8c8  push r8
00007f4f7cbdb8ca  push r9
00007f4f7cbdb8cc  push r10
00007f4f7cbdb8ce  push r11
00007f4f7cbdb8d0  sub rsp, 0xF0
00007f4f7cbdb8d7  vmovaps [rsp], xmm0
00007f4f7cbdb8dc  vmovaps [rsp+0x10], xmm1
00007f4f7cbdb8e2  vmovaps [rsp+0x20], xmm2
00007f4f7cbdb8e8  vmovaps [rsp+0x30], xmm3
00007f4f7cbdb8ee  vmovaps [rsp+0x40], xmm4
00007f4f7cbdb8f4  vmovaps [rsp+0x50], xmm5
00007f4f7cbdb8fa  vmovaps [rsp+0x60], xmm6
00007f4f7cbdb900  vmovaps [rsp+0x70], xmm7
00007f4f7cbdb906  vmovaps [rsp+0x80], xmm8
00007f4f7cbdb90f  vmovaps [rsp+0x90], xmm9
00007f4f7cbdb918  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdb921  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdb92a  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdb933  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdb93c  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdb945  sub rsp, 0x40
00007f4f7cbdb949  lea rdi, [rsp]
00007f4f7cbdb94d  lea rsi, [rsp+0x10]
00007f4f7cbdb952  lea rdx, [rsp+0x20]
00007f4f7cbdb957  lea rcx, [rsp+0x30]
00007f4f7cbdb95c  mov r8d, 0x00
00007f4f7cbdb962  lea r9, [r15+0x3A8]
00007f4f7cbdb969  movaps [rdi], xmm10
00007f4f7cbdb96d  movaps [rsi], xmm9
00007f4f7cbdb971  movaps [rdx], xmm7
00007f4f7cbdb974  movaps [rcx], xmm14
00007f4f7cbdb978  mov rax, 0x643999485A50
00007f4f7cbdb982  call rax
00007f4f7cbdb984  movaps xmm10, [rsp]
00007f4f7cbdb989  add rsp, 0x40
00007f4f7cbdb98d  vmovaps xmm0, [rsp]
00007f4f7cbdb992  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdb998  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdb99e  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdb9a4  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdb9aa  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdb9b0  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdb9b6  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdb9bc  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdb9c5  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdb9ce  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdb9d7  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdb9e0  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdb9e9  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdb9f2  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdb9fb  add rsp, 0xF0
00007f4f7cbdba02  pop r11
00007f4f7cbdba04  pop r10
00007f4f7cbdba06  pop r9
00007f4f7cbdba08  pop r8
00007f4f7cbdba0a  pop rsi
00007f4f7cbdba0b  pop rdi
00007f4f7cbdba0c  pop rdx
00007f4f7cbdba0d  pop rcx
00007f4f7cbdba0e  pop rax
00007f4f7cbdba0f  add rsp, 0x08
00007f4f7cbdba13  jmp 0x00007F4F7CBDA27C
00007f4f7cbdba18  call 0x00007F4F7CA0D4E0
00007f4f7cbdba1d  jmp 0x00007F4F7CBDA289
00007f4f7cbdba22  sub rsp, 0x08
00007f4f7cbdba26  push rax
00007f4f7cbdba27  push rcx
00007f4f7cbdba28  push rdx
00007f4f7cbdba29  push rdi
00007f4f7cbdba2a  push rsi
00007f4f7cbdba2b  push r8
00007f4f7cbdba2d  push r9
00007f4f7cbdba2f  push r10
00007f4f7cbdba31  push r11
00007f4f7cbdba33  sub rsp, 0xF0
00007f4f7cbdba3a  vmovaps [rsp], xmm0
00007f4f7cbdba3f  vmovaps [rsp+0x10], xmm1
00007f4f7cbdba45  vmovaps [rsp+0x20], xmm2
00007f4f7cbdba4b  vmovaps [rsp+0x30], xmm3
00007f4f7cbdba51  vmovaps [rsp+0x40], xmm4
00007f4f7cbdba57  vmovaps [rsp+0x50], xmm6
00007f4f7cbdba5d  vmovaps [rsp+0x60], xmm7
00007f4f7cbdba63  vmovaps [rsp+0x70], xmm8
00007f4f7cbdba69  vmovaps [rsp+0x80], xmm9
00007f4f7cbdba72  vmovaps [rsp+0x90], xmm10
00007f4f7cbdba7b  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdba84  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdba8d  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdba96  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdba9f  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdbaa8  sub rsp, 0x40
00007f4f7cbdbaac  lea rdi, [rsp]
00007f4f7cbdbab0  lea rsi, [rsp+0x10]
00007f4f7cbdbab5  lea rdx, [rsp+0x20]
00007f4f7cbdbaba  lea rcx, [rsp+0x30]
00007f4f7cbdbabf  mov r8d, 0x00
00007f4f7cbdbac5  lea r9, [r15+0x3A8]
00007f4f7cbdbacc  movaps [rdi], xmm5
00007f4f7cbdbacf  movaps [rsi], xmm6
00007f4f7cbdbad2  movaps [rdx], xmm7
00007f4f7cbdbad5  movaps [rcx], xmm9
00007f4f7cbdbad9  mov rax, 0x643999485A50
00007f4f7cbdbae3  call rax
00007f4f7cbdbae5  movaps xmm5, [rsp]
00007f4f7cbdbae9  add rsp, 0x40
00007f4f7cbdbaed  vmovaps xmm0, [rsp]
00007f4f7cbdbaf2  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdbaf8  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdbafe  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdbb04  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdbb0a  vmovaps xmm6, [rsp+0x50]
00007f4f7cbdbb10  vmovaps xmm7, [rsp+0x60]
00007f4f7cbdbb16  vmovaps xmm8, [rsp+0x70]
00007f4f7cbdbb1c  vmovaps xmm9, [rsp+0x80]
00007f4f7cbdbb25  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdbb2e  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdbb37  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdbb40  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdbb49  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdbb52  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdbb5b  add rsp, 0xF0
00007f4f7cbdbb62  pop r11
00007f4f7cbdbb64  pop r10
00007f4f7cbdbb66  pop r9
00007f4f7cbdbb68  pop r8
00007f4f7cbdbb6a  pop rsi
00007f4f7cbdbb6b  pop rdi
00007f4f7cbdbb6c  pop rdx
00007f4f7cbdbb6d  pop rcx
00007f4f7cbdbb6e  pop rax
00007f4f7cbdbb6f  add rsp, 0x08
00007f4f7cbdbb73  jmp 0x00007F4F7CBDA2BB
00007f4f7cbdbb78  sub rsp, 0x08
00007f4f7cbdbb7c  push rax
00007f4f7cbdbb7d  push rcx
00007f4f7cbdbb7e  push rdx
00007f4f7cbdbb7f  push rdi
00007f4f7cbdbb80  push rsi
00007f4f7cbdbb81  push r8
00007f4f7cbdbb83  push r9
00007f4f7cbdbb85  push r10
00007f4f7cbdbb87  push r11
00007f4f7cbdbb89  sub rsp, 0xF0
00007f4f7cbdbb90  vmovaps [rsp], xmm0
00007f4f7cbdbb95  vmovaps [rsp+0x10], xmm1
00007f4f7cbdbb9b  vmovaps [rsp+0x20], xmm2
00007f4f7cbdbba1  vmovaps [rsp+0x30], xmm3
00007f4f7cbdbba7  vmovaps [rsp+0x40], xmm4
00007f4f7cbdbbad  vmovaps [rsp+0x50], xmm5
00007f4f7cbdbbb3  vmovaps [rsp+0x60], xmm6
00007f4f7cbdbbb9  vmovaps [rsp+0x70], xmm8
00007f4f7cbdbbbf  vmovaps [rsp+0x80], xmm9
00007f4f7cbdbbc8  vmovaps [rsp+0x90], xmm10
00007f4f7cbdbbd1  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdbbda  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdbbe3  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdbbec  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdbbf5  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdbbfe  sub rsp, 0x40
00007f4f7cbdbc02  lea rdi, [rsp]
00007f4f7cbdbc06  lea rsi, [rsp+0x10]
00007f4f7cbdbc0b  lea rdx, [rsp+0x20]
00007f4f7cbdbc10  lea rcx, [rsp+0x30]
00007f4f7cbdbc15  mov r8d, 0x00
00007f4f7cbdbc1b  lea r9, [r15+0x3A8]
00007f4f7cbdbc22  movaps [rdi], xmm7
00007f4f7cbdbc25  movaps [rsi], xmm13
00007f4f7cbdbc29  movaps [rdx], xmm1
00007f4f7cbdbc2c  movaps [rcx], xmm9
00007f4f7cbdbc30  mov rax, 0x643999485A50
00007f4f7cbdbc3a  call rax
00007f4f7cbdbc3c  movaps xmm7, [rsp]
00007f4f7cbdbc40  add rsp, 0x40
00007f4f7cbdbc44  vmovaps xmm0, [rsp]
00007f4f7cbdbc49  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdbc4f  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdbc55  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdbc5b  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdbc61  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdbc67  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdbc6d  vmovaps xmm8, [rsp+0x70]
00007f4f7cbdbc73  vmovaps xmm9, [rsp+0x80]
00007f4f7cbdbc7c  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdbc85  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdbc8e  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdbc97  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdbca0  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdbca9  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdbcb2  add rsp, 0xF0
00007f4f7cbdbcb9  pop r11
00007f4f7cbdbcbb  pop r10
00007f4f7cbdbcbd  pop r9
00007f4f7cbdbcbf  pop r8
00007f4f7cbdbcc1  pop rsi
00007f4f7cbdbcc2  pop rdi
00007f4f7cbdbcc3  pop rdx
00007f4f7cbdbcc4  pop rcx
00007f4f7cbdbcc5  pop rax
00007f4f7cbdbcc6  add rsp, 0x08
00007f4f7cbdbcca  jmp 0x00007F4F7CBDA2E0
00007f4f7cbdbccf  call 0x00007F4F7CA0C260
00007f4f7cbdbcd4  jmp 0x00007F4F7CBDA303
00007f4f7cbdbcd9  call 0x00007F4F7CA07890
00007f4f7cbdbcde  jmp 0x00007F4F7CBDA30D
00007f4f7cbdbce3  sub rsp, 0x08
00007f4f7cbdbce7  push rax
00007f4f7cbdbce8  push rcx
00007f4f7cbdbce9  push rdx
00007f4f7cbdbcea  push rdi
00007f4f7cbdbceb  push rsi
00007f4f7cbdbcec  push r8
00007f4f7cbdbcee  push r9
00007f4f7cbdbcf0  push r10
00007f4f7cbdbcf2  push r11
00007f4f7cbdbcf4  sub rsp, 0xF0
00007f4f7cbdbcfb  vmovaps [rsp], xmm0
00007f4f7cbdbd00  vmovaps [rsp+0x10], xmm1
00007f4f7cbdbd06  vmovaps [rsp+0x20], xmm3
00007f4f7cbdbd0c  vmovaps [rsp+0x30], xmm4
00007f4f7cbdbd12  vmovaps [rsp+0x40], xmm5
00007f4f7cbdbd18  vmovaps [rsp+0x50], xmm6
00007f4f7cbdbd1e  vmovaps [rsp+0x60], xmm7
00007f4f7cbdbd24  vmovaps [rsp+0x70], xmm8
00007f4f7cbdbd2a  vmovaps [rsp+0x80], xmm9
00007f4f7cbdbd33  vmovaps [rsp+0x90], xmm10
00007f4f7cbdbd3c  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdbd45  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdbd4e  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdbd57  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdbd60  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdbd69  sub rsp, 0x40
00007f4f7cbdbd6d  lea rdi, [rsp]
00007f4f7cbdbd71  lea rsi, [rsp+0x10]
00007f4f7cbdbd76  lea rdx, [rsp+0x20]
00007f4f7cbdbd7b  lea rcx, [rsp+0x30]
00007f4f7cbdbd80  mov r8d, 0x00
00007f4f7cbdbd86  lea r9, [r15+0x3A8]
00007f4f7cbdbd8d  movaps [rdi], xmm2
00007f4f7cbdbd90  movaps [rsi], xmm12
00007f4f7cbdbd94  movaps [rdx], xmm6
00007f4f7cbdbd97  movaps [rcx], xmm3
00007f4f7cbdbd9a  mov rax, 0x643999485A50
00007f4f7cbdbda4  call rax
00007f4f7cbdbda6  movaps xmm2, [rsp]
00007f4f7cbdbdaa  add rsp, 0x40
00007f4f7cbdbdae  vmovaps xmm0, [rsp]
00007f4f7cbdbdb3  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdbdb9  vmovaps xmm3, [rsp+0x20]
00007f4f7cbdbdbf  vmovaps xmm4, [rsp+0x30]
00007f4f7cbdbdc5  vmovaps xmm5, [rsp+0x40]
00007f4f7cbdbdcb  vmovaps xmm6, [rsp+0x50]
00007f4f7cbdbdd1  vmovaps xmm7, [rsp+0x60]
00007f4f7cbdbdd7  vmovaps xmm8, [rsp+0x70]
00007f4f7cbdbddd  vmovaps xmm9, [rsp+0x80]
00007f4f7cbdbde6  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdbdef  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdbdf8  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdbe01  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdbe0a  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdbe13  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdbe1c  add rsp, 0xF0
00007f4f7cbdbe23  pop r11
00007f4f7cbdbe25  pop r10
00007f4f7cbdbe27  pop r9
00007f4f7cbdbe29  pop r8
00007f4f7cbdbe2b  pop rsi
00007f4f7cbdbe2c  pop rdi
00007f4f7cbdbe2d  pop rdx
00007f4f7cbdbe2e  pop rcx
00007f4f7cbdbe2f  pop rax
00007f4f7cbdbe30  add rsp, 0x08
00007f4f7cbdbe34  jmp 0x00007F4F7CBDA353
00007f4f7cbdbe39  sub rsp, 0x08
00007f4f7cbdbe3d  push rax
00007f4f7cbdbe3e  push rcx
00007f4f7cbdbe3f  push rdx
00007f4f7cbdbe40  push rdi
00007f4f7cbdbe41  push rsi
00007f4f7cbdbe42  push r8
00007f4f7cbdbe44  push r9
00007f4f7cbdbe46  push r10
00007f4f7cbdbe48  push r11
00007f4f7cbdbe4a  sub rsp, 0xF0
00007f4f7cbdbe51  vmovaps [rsp], xmm0
00007f4f7cbdbe56  vmovaps [rsp+0x10], xmm1
00007f4f7cbdbe5c  vmovaps [rsp+0x20], xmm2
00007f4f7cbdbe62  vmovaps [rsp+0x30], xmm3
00007f4f7cbdbe68  vmovaps [rsp+0x40], xmm4
00007f4f7cbdbe6e  vmovaps [rsp+0x50], xmm5
00007f4f7cbdbe74  vmovaps [rsp+0x60], xmm7
00007f4f7cbdbe7a  vmovaps [rsp+0x70], xmm8
00007f4f7cbdbe80  vmovaps [rsp+0x80], xmm9
00007f4f7cbdbe89  vmovaps [rsp+0x90], xmm10
00007f4f7cbdbe92  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdbe9b  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdbea4  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdbead  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdbeb6  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdbebf  sub rsp, 0x40
00007f4f7cbdbec3  lea rdi, [rsp]
00007f4f7cbdbec7  lea rsi, [rsp+0x10]
00007f4f7cbdbecc  lea rdx, [rsp+0x20]
00007f4f7cbdbed1  lea rcx, [rsp+0x30]
00007f4f7cbdbed6  mov r8d, 0x00
00007f4f7cbdbedc  lea r9, [r15+0x3A8]
00007f4f7cbdbee3  movaps [rdi], xmm6
00007f4f7cbdbee6  movaps [rsi], xmm10
00007f4f7cbdbeea  movaps [rdx], xmm12
00007f4f7cbdbeee  movaps [rcx], xmm1
00007f4f7cbdbef1  mov rax, 0x643999485A50
00007f4f7cbdbefb  call rax
00007f4f7cbdbefd  movaps xmm6, [rsp]
00007f4f7cbdbf01  add rsp, 0x40
00007f4f7cbdbf05  vmovaps xmm0, [rsp]
00007f4f7cbdbf0a  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdbf10  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdbf16  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdbf1c  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdbf22  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdbf28  vmovaps xmm7, [rsp+0x60]
00007f4f7cbdbf2e  vmovaps xmm8, [rsp+0x70]
00007f4f7cbdbf34  vmovaps xmm9, [rsp+0x80]
00007f4f7cbdbf3d  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdbf46  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdbf4f  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdbf58  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdbf61  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdbf6a  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdbf73  add rsp, 0xF0
00007f4f7cbdbf7a  pop r11
00007f4f7cbdbf7c  pop r10
00007f4f7cbdbf7e  pop r9
00007f4f7cbdbf80  pop r8
00007f4f7cbdbf82  pop rsi
00007f4f7cbdbf83  pop rdi
00007f4f7cbdbf84  pop rdx
00007f4f7cbdbf85  pop rcx
00007f4f7cbdbf86  pop rax
00007f4f7cbdbf87  add rsp, 0x08
00007f4f7cbdbf8b  jmp 0x00007F4F7CBDA381
00007f4f7cbdbf90  sub rsp, 0x08
00007f4f7cbdbf94  push rax
00007f4f7cbdbf95  push rcx
00007f4f7cbdbf96  push rdx
00007f4f7cbdbf97  push rdi
00007f4f7cbdbf98  push rsi
00007f4f7cbdbf99  push r8
00007f4f7cbdbf9b  push r9
00007f4f7cbdbf9d  push r10
00007f4f7cbdbf9f  push r11
00007f4f7cbdbfa1  sub rsp, 0xF0
00007f4f7cbdbfa8  vmovaps [rsp], xmm0
00007f4f7cbdbfad  vmovaps [rsp+0x10], xmm1
00007f4f7cbdbfb3  vmovaps [rsp+0x20], xmm2
00007f4f7cbdbfb9  vmovaps [rsp+0x30], xmm3
00007f4f7cbdbfbf  vmovaps [rsp+0x40], xmm4
00007f4f7cbdbfc5  vmovaps [rsp+0x50], xmm5
00007f4f7cbdbfcb  vmovaps [rsp+0x60], xmm6
00007f4f7cbdbfd1  vmovaps [rsp+0x70], xmm7
00007f4f7cbdbfd7  vmovaps [rsp+0x80], xmm8
00007f4f7cbdbfe0  vmovaps [rsp+0x90], xmm9
00007f4f7cbdbfe9  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdbff2  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdbffb  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdc004  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdc00d  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdc016  sub rsp, 0x40
00007f4f7cbdc01a  lea rdi, [rsp]
00007f4f7cbdc01e  lea rsi, [rsp+0x10]
00007f4f7cbdc023  lea rdx, [rsp+0x20]
00007f4f7cbdc028  lea rcx, [rsp+0x30]
00007f4f7cbdc02d  mov r8d, 0x00
00007f4f7cbdc033  lea r9, [r15+0x3A8]
00007f4f7cbdc03a  movaps [rdi], xmm10
00007f4f7cbdc03e  movaps [rsi], xmm5
00007f4f7cbdc041  movaps [rdx], xmm12
00007f4f7cbdc045  movaps [rcx], xmm1
00007f4f7cbdc048  mov rax, 0x643999485A50
00007f4f7cbdc052  call rax
00007f4f7cbdc054  movaps xmm10, [rsp]
00007f4f7cbdc059  add rsp, 0x40
00007f4f7cbdc05d  vmovaps xmm0, [rsp]
00007f4f7cbdc062  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdc068  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdc06e  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdc074  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdc07a  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdc080  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdc086  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdc08c  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdc095  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdc09e  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdc0a7  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdc0b0  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdc0b9  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdc0c2  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdc0cb  add rsp, 0xF0
00007f4f7cbdc0d2  pop r11
00007f4f7cbdc0d4  pop r10
00007f4f7cbdc0d6  pop r9
00007f4f7cbdc0d8  pop r8
00007f4f7cbdc0da  pop rsi
00007f4f7cbdc0db  pop rdi
00007f4f7cbdc0dc  pop rdx
00007f4f7cbdc0dd  pop rcx
00007f4f7cbdc0de  pop rax
00007f4f7cbdc0df  add rsp, 0x08
00007f4f7cbdc0e3  jmp 0x00007F4F7CBDA3B0
00007f4f7cbdc0e8  sub rsp, 0x08
00007f4f7cbdc0ec  push rax
00007f4f7cbdc0ed  push rcx
00007f4f7cbdc0ee  push rdx
00007f4f7cbdc0ef  push rdi
00007f4f7cbdc0f0  push rsi
00007f4f7cbdc0f1  push r8
00007f4f7cbdc0f3  push r9
00007f4f7cbdc0f5  push r10
00007f4f7cbdc0f7  push r11
00007f4f7cbdc0f9  sub rsp, 0xF0
00007f4f7cbdc100  vmovaps [rsp], xmm0
00007f4f7cbdc105  vmovaps [rsp+0x10], xmm1
00007f4f7cbdc10b  vmovaps [rsp+0x20], xmm2
00007f4f7cbdc111  vmovaps [rsp+0x30], xmm3
00007f4f7cbdc117  vmovaps [rsp+0x40], xmm4
00007f4f7cbdc11d  vmovaps [rsp+0x50], xmm5
00007f4f7cbdc123  vmovaps [rsp+0x60], xmm6
00007f4f7cbdc129  vmovaps [rsp+0x70], xmm7
00007f4f7cbdc12f  vmovaps [rsp+0x80], xmm8
00007f4f7cbdc138  vmovaps [rsp+0x90], xmm9
00007f4f7cbdc141  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdc14a  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdc153  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdc15c  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdc165  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdc16e  sub rsp, 0x40
00007f4f7cbdc172  lea rdi, [rsp]
00007f4f7cbdc176  lea rsi, [rsp+0x10]
00007f4f7cbdc17b  lea rdx, [rsp+0x20]
00007f4f7cbdc180  lea rcx, [rsp+0x30]
00007f4f7cbdc185  mov r8d, 0x00
00007f4f7cbdc18b  lea r9, [r15+0x3A8]
00007f4f7cbdc192  movaps [rdi], xmm12
00007f4f7cbdc196  movaps [rsi], xmm7
00007f4f7cbdc199  movaps [rdx], xmm15
00007f4f7cbdc19d  movaps [rcx], xmm1
00007f4f7cbdc1a0  mov rax, 0x643999485A50
00007f4f7cbdc1aa  call rax
00007f4f7cbdc1ac  movaps xmm12, [rsp]
00007f4f7cbdc1b1  add rsp, 0x40
00007f4f7cbdc1b5  vmovaps xmm0, [rsp]
00007f4f7cbdc1ba  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdc1c0  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdc1c6  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdc1cc  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdc1d2  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdc1d8  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdc1de  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdc1e4  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdc1ed  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdc1f6  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdc1ff  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdc208  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdc211  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdc21a  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdc223  add rsp, 0xF0
00007f4f7cbdc22a  pop r11
00007f4f7cbdc22c  pop r10
00007f4f7cbdc22e  pop r9
00007f4f7cbdc230  pop r8
00007f4f7cbdc232  pop rsi
00007f4f7cbdc233  pop rdi
00007f4f7cbdc234  pop rdx
00007f4f7cbdc235  pop rcx
00007f4f7cbdc236  pop rax
00007f4f7cbdc237  add rsp, 0x08
00007f4f7cbdc23b  jmp 0x00007F4F7CBDA3D9
00007f4f7cbdc240  call 0x00007F4F7C9FF430
00007f4f7cbdc245  jmp 0x00007F4F7CBDA3E3
00007f4f7cbdc24a  call 0x00007F4F7CA0E760
00007f4f7cbdc24f  jmp 0x00007F4F7CBDA3ED
00007f4f7cbdc254  sub rsp, 0x08
00007f4f7cbdc258  push rax
00007f4f7cbdc259  push rcx
00007f4f7cbdc25a  push rdx
00007f4f7cbdc25b  push rdi
00007f4f7cbdc25c  push rsi
00007f4f7cbdc25d  push r8
00007f4f7cbdc25f  push r9
00007f4f7cbdc261  push r10
00007f4f7cbdc263  push r11
00007f4f7cbdc265  sub rsp, 0xF0
00007f4f7cbdc26c  vmovaps [rsp], xmm0
00007f4f7cbdc271  vmovaps [rsp+0x10], xmm1
00007f4f7cbdc277  vmovaps [rsp+0x20], xmm2
00007f4f7cbdc27d  vmovaps [rsp+0x30], xmm3
00007f4f7cbdc283  vmovaps [rsp+0x40], xmm4
00007f4f7cbdc289  vmovaps [rsp+0x50], xmm5
00007f4f7cbdc28f  vmovaps [rsp+0x60], xmm6
00007f4f7cbdc295  vmovaps [rsp+0x70], xmm8
00007f4f7cbdc29b  vmovaps [rsp+0x80], xmm9
00007f4f7cbdc2a4  vmovaps [rsp+0x90], xmm10
00007f4f7cbdc2ad  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdc2b6  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdc2bf  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdc2c8  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdc2d1  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdc2da  sub rsp, 0x40
00007f4f7cbdc2de  lea rdi, [rsp]
00007f4f7cbdc2e2  lea rsi, [rsp+0x10]
00007f4f7cbdc2e7  lea rdx, [rsp+0x20]
00007f4f7cbdc2ec  lea rcx, [rsp+0x30]
00007f4f7cbdc2f1  mov r8d, 0x00
00007f4f7cbdc2f7  lea r9, [r15+0x3A8]
00007f4f7cbdc2fe  movaps [rdi], xmm7
00007f4f7cbdc301  movaps [rsi], xmm2
00007f4f7cbdc304  movaps [rdx], xmm9
00007f4f7cbdc308  movaps [rcx], xmm11
00007f4f7cbdc30c  mov rax, 0x643999485A50
00007f4f7cbdc316  call rax
00007f4f7cbdc318  movaps xmm7, [rsp]
00007f4f7cbdc31c  add rsp, 0x40
00007f4f7cbdc320  vmovaps xmm0, [rsp]
00007f4f7cbdc325  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdc32b  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdc331  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdc337  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdc33d  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdc343  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdc349  vmovaps xmm8, [rsp+0x70]
00007f4f7cbdc34f  vmovaps xmm9, [rsp+0x80]
00007f4f7cbdc358  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdc361  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdc36a  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdc373  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdc37c  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdc385  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdc38e  add rsp, 0xF0
00007f4f7cbdc395  pop r11
00007f4f7cbdc397  pop r10
00007f4f7cbdc399  pop r9
00007f4f7cbdc39b  pop r8
00007f4f7cbdc39d  pop rsi
00007f4f7cbdc39e  pop rdi
00007f4f7cbdc39f  pop rdx
00007f4f7cbdc3a0  pop rcx
00007f4f7cbdc3a1  pop rax
00007f4f7cbdc3a2  add rsp, 0x08
00007f4f7cbdc3a6  jmp 0x00007F4F7CBDA421
00007f4f7cbdc3ab  sub rsp, 0x08
00007f4f7cbdc3af  push rax
00007f4f7cbdc3b0  push rcx
00007f4f7cbdc3b1  push rdx
00007f4f7cbdc3b2  push rdi
00007f4f7cbdc3b3  push rsi
00007f4f7cbdc3b4  push r8
00007f4f7cbdc3b6  push r9
00007f4f7cbdc3b8  push r10
00007f4f7cbdc3ba  push r11
00007f4f7cbdc3bc  sub rsp, 0xF0
00007f4f7cbdc3c3  vmovaps [rsp], xmm0
00007f4f7cbdc3c8  vmovaps [rsp+0x10], xmm1
00007f4f7cbdc3ce  vmovaps [rsp+0x20], xmm2
00007f4f7cbdc3d4  vmovaps [rsp+0x30], xmm3
00007f4f7cbdc3da  vmovaps [rsp+0x40], xmm4
00007f4f7cbdc3e0  vmovaps [rsp+0x50], xmm5
00007f4f7cbdc3e6  vmovaps [rsp+0x60], xmm6
00007f4f7cbdc3ec  vmovaps [rsp+0x70], xmm7
00007f4f7cbdc3f2  vmovaps [rsp+0x80], xmm8
00007f4f7cbdc3fb  vmovaps [rsp+0x90], xmm10
00007f4f7cbdc404  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdc40d  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdc416  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdc41f  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdc428  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdc431  sub rsp, 0x40
00007f4f7cbdc435  lea rdi, [rsp]
00007f4f7cbdc439  lea rsi, [rsp+0x10]
00007f4f7cbdc43e  lea rdx, [rsp+0x20]
00007f4f7cbdc443  lea rcx, [rsp+0x30]
00007f4f7cbdc448  mov r8d, 0x00
00007f4f7cbdc44e  lea r9, [r15+0x3A8]
00007f4f7cbdc455  movaps [rdi], xmm9
00007f4f7cbdc459  movaps [rsi], xmm6
00007f4f7cbdc45c  movaps [rdx], xmm1
00007f4f7cbdc45f  movaps [rcx], xmm11
00007f4f7cbdc463  mov rax, 0x643999485A50
00007f4f7cbdc46d  call rax
00007f4f7cbdc46f  movaps xmm9, [rsp]
00007f4f7cbdc474  add rsp, 0x40
00007f4f7cbdc478  vmovaps xmm0, [rsp]
00007f4f7cbdc47d  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdc483  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdc489  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdc48f  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdc495  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdc49b  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdc4a1  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdc4a7  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdc4b0  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdc4b9  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdc4c2  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdc4cb  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdc4d4  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdc4dd  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdc4e6  add rsp, 0xF0
00007f4f7cbdc4ed  pop r11
00007f4f7cbdc4ef  pop r10
00007f4f7cbdc4f1  pop r9
00007f4f7cbdc4f3  pop r8
00007f4f7cbdc4f5  pop rsi
00007f4f7cbdc4f6  pop rdi
00007f4f7cbdc4f7  pop rdx
00007f4f7cbdc4f8  pop rcx
00007f4f7cbdc4f9  pop rax
00007f4f7cbdc4fa  add rsp, 0x08
00007f4f7cbdc4fe  jmp 0x00007F4F7CBDA447
00007f4f7cbdc503  sub rsp, 0x08
00007f4f7cbdc507  push rax
00007f4f7cbdc508  push rcx
00007f4f7cbdc509  push rdx
00007f4f7cbdc50a  push rdi
00007f4f7cbdc50b  push rsi
00007f4f7cbdc50c  push r8
00007f4f7cbdc50e  push r9
00007f4f7cbdc510  push r10
00007f4f7cbdc512  push r11
00007f4f7cbdc514  sub rsp, 0xF0
00007f4f7cbdc51b  vmovaps [rsp], xmm0
00007f4f7cbdc520  vmovaps [rsp+0x10], xmm1
00007f4f7cbdc526  vmovaps [rsp+0x20], xmm2
00007f4f7cbdc52c  vmovaps [rsp+0x30], xmm3
00007f4f7cbdc532  vmovaps [rsp+0x40], xmm4
00007f4f7cbdc538  vmovaps [rsp+0x50], xmm5
00007f4f7cbdc53e  vmovaps [rsp+0x60], xmm6
00007f4f7cbdc544  vmovaps [rsp+0x70], xmm7
00007f4f7cbdc54a  vmovaps [rsp+0x80], xmm8
00007f4f7cbdc553  vmovaps [rsp+0x90], xmm9
00007f4f7cbdc55c  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdc565  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdc56e  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdc577  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdc580  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdc589  sub rsp, 0x40
00007f4f7cbdc58d  lea rdi, [rsp]
00007f4f7cbdc591  lea rsi, [rsp+0x10]
00007f4f7cbdc596  lea rdx, [rsp+0x20]
00007f4f7cbdc59b  lea rcx, [rsp+0x30]
00007f4f7cbdc5a0  mov r8d, 0x00
00007f4f7cbdc5a6  lea r9, [r15+0x3A8]
00007f4f7cbdc5ad  movaps [rdi], xmm11
00007f4f7cbdc5b1  movaps [rsi], xmm10
00007f4f7cbdc5b5  movaps [rdx], xmm8
00007f4f7cbdc5b9  movaps [rcx], xmm1
00007f4f7cbdc5bc  mov rax, 0x643999485A50
00007f4f7cbdc5c6  call rax
00007f4f7cbdc5c8  movaps xmm11, [rsp]
00007f4f7cbdc5cd  add rsp, 0x40
00007f4f7cbdc5d1  vmovaps xmm0, [rsp]
00007f4f7cbdc5d6  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdc5dc  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdc5e2  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdc5e8  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdc5ee  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdc5f4  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdc5fa  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdc600  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdc609  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdc612  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdc61b  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdc624  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdc62d  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdc636  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdc63f  add rsp, 0xF0
00007f4f7cbdc646  pop r11
00007f4f7cbdc648  pop r10
00007f4f7cbdc64a  pop r9
00007f4f7cbdc64c  pop r8
00007f4f7cbdc64e  pop rsi
00007f4f7cbdc64f  pop rdi
00007f4f7cbdc650  pop rdx
00007f4f7cbdc651  pop rcx
00007f4f7cbdc652  pop rax
00007f4f7cbdc653  add rsp, 0x08
00007f4f7cbdc657  jmp 0x00007F4F7CBDA46D
00007f4f7cbdc65c  sub rsp, 0x08
00007f4f7cbdc660  push rax
00007f4f7cbdc661  push rcx
00007f4f7cbdc662  push rdx
00007f4f7cbdc663  push rdi
00007f4f7cbdc664  push rsi
00007f4f7cbdc665  push r8
00007f4f7cbdc667  push r9
00007f4f7cbdc669  push r10
00007f4f7cbdc66b  push r11
00007f4f7cbdc66d  sub rsp, 0xF0
00007f4f7cbdc674  vmovaps [rsp], xmm0
00007f4f7cbdc679  vmovaps [rsp+0x10], xmm1
00007f4f7cbdc67f  vmovaps [rsp+0x20], xmm2
00007f4f7cbdc685  vmovaps [rsp+0x30], xmm3
00007f4f7cbdc68b  vmovaps [rsp+0x40], xmm4
00007f4f7cbdc691  vmovaps [rsp+0x50], xmm5
00007f4f7cbdc697  vmovaps [rsp+0x60], xmm6
00007f4f7cbdc69d  vmovaps [rsp+0x70], xmm7
00007f4f7cbdc6a3  vmovaps [rsp+0x80], xmm8
00007f4f7cbdc6ac  vmovaps [rsp+0x90], xmm9
00007f4f7cbdc6b5  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdc6be  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdc6c7  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdc6d0  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdc6d9  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdc6e2  sub rsp, 0x40
00007f4f7cbdc6e6  lea rdi, [rsp]
00007f4f7cbdc6ea  lea rsi, [rsp+0x10]
00007f4f7cbdc6ef  lea rdx, [rsp+0x20]
00007f4f7cbdc6f4  lea rcx, [rsp+0x30]
00007f4f7cbdc6f9  mov r8d, 0x00
00007f4f7cbdc6ff  lea r9, [r15+0x3A8]
00007f4f7cbdc706  movaps [rdi], xmm10
00007f4f7cbdc70a  movaps [rsi], xmm12
00007f4f7cbdc70e  movaps [rdx], xmm13
00007f4f7cbdc712  movaps [rcx], xmm1
00007f4f7cbdc715  mov rax, 0x643999485A50
00007f4f7cbdc71f  call rax
00007f4f7cbdc721  movaps xmm10, [rsp]
00007f4f7cbdc726  add rsp, 0x40
00007f4f7cbdc72a  vmovaps xmm0, [rsp]
00007f4f7cbdc72f  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdc735  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdc73b  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdc741  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdc747  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdc74d  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdc753  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdc759  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdc762  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdc76b  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdc774  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdc77d  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdc786  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdc78f  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdc798  add rsp, 0xF0
00007f4f7cbdc79f  pop r11
00007f4f7cbdc7a1  pop r10
00007f4f7cbdc7a3  pop r9
00007f4f7cbdc7a5  pop r8
00007f4f7cbdc7a7  pop rsi
00007f4f7cbdc7a8  pop rdi
00007f4f7cbdc7a9  pop rdx
00007f4f7cbdc7aa  pop rcx
00007f4f7cbdc7ab  pop rax
00007f4f7cbdc7ac  add rsp, 0x08
00007f4f7cbdc7b0  jmp 0x00007F4F7CBDA493
00007f4f7cbdc7b5  call 0x00007F4F7C9FF430
00007f4f7cbdc7ba  jmp 0x00007F4F7CBDA49D
00007f4f7cbdc7bf  call 0x00007F4F7CA0C260
00007f4f7cbdc7c4  jmp 0x00007F4F7CBDA4A7
00007f4f7cbdc7c9  sub rsp, 0x08
00007f4f7cbdc7cd  push rax
00007f4f7cbdc7ce  push rcx
00007f4f7cbdc7cf  push rdx
00007f4f7cbdc7d0  push rdi
00007f4f7cbdc7d1  push rsi
00007f4f7cbdc7d2  push r8
00007f4f7cbdc7d4  push r9
00007f4f7cbdc7d6  push r10
00007f4f7cbdc7d8  push r11
00007f4f7cbdc7da  sub rsp, 0xF0
00007f4f7cbdc7e1  vmovaps [rsp], xmm0
00007f4f7cbdc7e6  vmovaps [rsp+0x10], xmm1
00007f4f7cbdc7ec  vmovaps [rsp+0x20], xmm2
00007f4f7cbdc7f2  vmovaps [rsp+0x30], xmm3
00007f4f7cbdc7f8  vmovaps [rsp+0x40], xmm4
00007f4f7cbdc7fe  vmovaps [rsp+0x50], xmm5
00007f4f7cbdc804  vmovaps [rsp+0x60], xmm6
00007f4f7cbdc80a  vmovaps [rsp+0x70], xmm7
00007f4f7cbdc810  vmovaps [rsp+0x80], xmm9
00007f4f7cbdc819  vmovaps [rsp+0x90], xmm10
00007f4f7cbdc822  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdc82b  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdc834  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdc83d  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdc846  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdc84f  sub rsp, 0x40
00007f4f7cbdc853  lea rdi, [rsp]
00007f4f7cbdc857  lea rsi, [rsp+0x10]
00007f4f7cbdc85c  lea rdx, [rsp+0x20]
00007f4f7cbdc861  lea rcx, [rsp+0x30]
00007f4f7cbdc866  mov r8d, 0x00
00007f4f7cbdc86c  lea r9, [r15+0x3A8]
00007f4f7cbdc873  movaps [rdi], xmm8
00007f4f7cbdc877  movaps [rsi], xmm7
00007f4f7cbdc87a  movaps [rdx], xmm4
00007f4f7cbdc87d  movaps [rcx], xmm12
00007f4f7cbdc881  mov rax, 0x643999485A50
00007f4f7cbdc88b  call rax
00007f4f7cbdc88d  movaps xmm8, [rsp]
00007f4f7cbdc892  add rsp, 0x40
00007f4f7cbdc896  vmovaps xmm0, [rsp]
00007f4f7cbdc89b  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdc8a1  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdc8a7  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdc8ad  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdc8b3  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdc8b9  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdc8bf  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdc8c5  vmovaps xmm9, [rsp+0x80]
00007f4f7cbdc8ce  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdc8d7  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdc8e0  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdc8e9  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdc8f2  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdc8fb  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdc904  add rsp, 0xF0
00007f4f7cbdc90b  pop r11
00007f4f7cbdc90d  pop r10
00007f4f7cbdc90f  pop r9
00007f4f7cbdc911  pop r8
00007f4f7cbdc913  pop rsi
00007f4f7cbdc914  pop rdi
00007f4f7cbdc915  pop rdx
00007f4f7cbdc916  pop rcx
00007f4f7cbdc917  pop rax
00007f4f7cbdc918  add rsp, 0x08
00007f4f7cbdc91c  jmp 0x00007F4F7CBDA4D0
00007f4f7cbdc921  sub rsp, 0x08
00007f4f7cbdc925  push rax
00007f4f7cbdc926  push rcx
00007f4f7cbdc927  push rdx
00007f4f7cbdc928  push rdi
00007f4f7cbdc929  push rsi
00007f4f7cbdc92a  push r8
00007f4f7cbdc92c  push r9
00007f4f7cbdc92e  push r10
00007f4f7cbdc930  push r11
00007f4f7cbdc932  sub rsp, 0xF0
00007f4f7cbdc939  vmovaps [rsp], xmm0
00007f4f7cbdc93e  vmovaps [rsp+0x10], xmm1
00007f4f7cbdc944  vmovaps [rsp+0x20], xmm2
00007f4f7cbdc94a  vmovaps [rsp+0x30], xmm3
00007f4f7cbdc950  vmovaps [rsp+0x40], xmm4
00007f4f7cbdc956  vmovaps [rsp+0x50], xmm5
00007f4f7cbdc95c  vmovaps [rsp+0x60], xmm6
00007f4f7cbdc962  vmovaps [rsp+0x70], xmm8
00007f4f7cbdc968  vmovaps [rsp+0x80], xmm9
00007f4f7cbdc971  vmovaps [rsp+0x90], xmm10
00007f4f7cbdc97a  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdc983  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdc98c  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdc995  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdc99e  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdc9a7  sub rsp, 0x40
00007f4f7cbdc9ab  lea rdi, [rsp]
00007f4f7cbdc9af  lea rsi, [rsp+0x10]
00007f4f7cbdc9b4  lea rdx, [rsp+0x20]
00007f4f7cbdc9b9  lea rcx, [rsp+0x30]
00007f4f7cbdc9be  mov r8d, 0x00
00007f4f7cbdc9c4  lea r9, [r15+0x3A8]
00007f4f7cbdc9cb  movaps [rdi], xmm7
00007f4f7cbdc9ce  movaps [rsi], xmm9
00007f4f7cbdc9d2  movaps [rdx], xmm14
00007f4f7cbdc9d6  movaps [rcx], xmm12
00007f4f7cbdc9da  mov rax, 0x643999485A50
00007f4f7cbdc9e4  call rax
00007f4f7cbdc9e6  movaps xmm7, [rsp]
00007f4f7cbdc9ea  add rsp, 0x40
00007f4f7cbdc9ee  vmovaps xmm0, [rsp]
00007f4f7cbdc9f3  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdc9f9  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdc9ff  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdca05  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdca0b  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdca11  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdca17  vmovaps xmm8, [rsp+0x70]
00007f4f7cbdca1d  vmovaps xmm9, [rsp+0x80]
00007f4f7cbdca26  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdca2f  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdca38  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdca41  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdca4a  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdca53  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdca5c  add rsp, 0xF0
00007f4f7cbdca63  pop r11
00007f4f7cbdca65  pop r10
00007f4f7cbdca67  pop r9
00007f4f7cbdca69  pop r8
00007f4f7cbdca6b  pop rsi
00007f4f7cbdca6c  pop rdi
00007f4f7cbdca6d  pop rdx
00007f4f7cbdca6e  pop rcx
00007f4f7cbdca6f  pop rax
00007f4f7cbdca70  add rsp, 0x08
00007f4f7cbdca74  jmp 0x00007F4F7CBDA4F8
00007f4f7cbdca79  sub rsp, 0x08
00007f4f7cbdca7d  push rax
00007f4f7cbdca7e  push rcx
00007f4f7cbdca7f  push rdx
00007f4f7cbdca80  push rdi
00007f4f7cbdca81  push rsi
00007f4f7cbdca82  push r8
00007f4f7cbdca84  push r9
00007f4f7cbdca86  push r10
00007f4f7cbdca88  push r11
00007f4f7cbdca8a  sub rsp, 0xF0
00007f4f7cbdca91  vmovaps [rsp], xmm0
00007f4f7cbdca96  vmovaps [rsp+0x10], xmm1
00007f4f7cbdca9c  vmovaps [rsp+0x20], xmm2
00007f4f7cbdcaa2  vmovaps [rsp+0x30], xmm3
00007f4f7cbdcaa8  vmovaps [rsp+0x40], xmm4
00007f4f7cbdcaae  vmovaps [rsp+0x50], xmm5
00007f4f7cbdcab4  vmovaps [rsp+0x60], xmm6
00007f4f7cbdcaba  vmovaps [rsp+0x70], xmm7
00007f4f7cbdcac0  vmovaps [rsp+0x80], xmm8
00007f4f7cbdcac9  vmovaps [rsp+0x90], xmm9
00007f4f7cbdcad2  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdcadb  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdcae4  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdcaed  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdcaf6  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdcaff  sub rsp, 0x40
00007f4f7cbdcb03  lea rdi, [rsp]
00007f4f7cbdcb07  lea rsi, [rsp+0x10]
00007f4f7cbdcb0c  lea rdx, [rsp+0x20]
00007f4f7cbdcb11  lea rcx, [rsp+0x30]
00007f4f7cbdcb16  mov r8d, 0x00
00007f4f7cbdcb1c  lea r9, [r15+0x3A8]
00007f4f7cbdcb23  movaps [rdi], xmm12
00007f4f7cbdcb27  movaps [rsi], xmm11
00007f4f7cbdcb2b  movaps [rdx], xmm15
00007f4f7cbdcb2f  movaps [rcx], xmm14
00007f4f7cbdcb33  mov rax, 0x643999485A50
00007f4f7cbdcb3d  call rax
00007f4f7cbdcb3f  movaps xmm12, [rsp]
00007f4f7cbdcb44  add rsp, 0x40
00007f4f7cbdcb48  vmovaps xmm0, [rsp]
00007f4f7cbdcb4d  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdcb53  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdcb59  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdcb5f  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdcb65  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdcb6b  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdcb71  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdcb77  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdcb80  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdcb89  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdcb92  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdcb9b  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdcba4  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdcbad  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdcbb6  add rsp, 0xF0
00007f4f7cbdcbbd  pop r11
00007f4f7cbdcbbf  pop r10
00007f4f7cbdcbc1  pop r9
00007f4f7cbdcbc3  pop r8
00007f4f7cbdcbc5  pop rsi
00007f4f7cbdcbc6  pop rdi
00007f4f7cbdcbc7  pop rdx
00007f4f7cbdcbc8  pop rcx
00007f4f7cbdcbc9  pop rax
00007f4f7cbdcbca  add rsp, 0x08
00007f4f7cbdcbce  jmp 0x00007F4F7CBDA521
00007f4f7cbdcbd3  sub rsp, 0x08
00007f4f7cbdcbd7  push rax
00007f4f7cbdcbd8  push rcx
00007f4f7cbdcbd9  push rdx
00007f4f7cbdcbda  push rdi
00007f4f7cbdcbdb  push rsi
00007f4f7cbdcbdc  push r8
00007f4f7cbdcbde  push r9
00007f4f7cbdcbe0  push r10
00007f4f7cbdcbe2  push r11
00007f4f7cbdcbe4  sub rsp, 0xF0
00007f4f7cbdcbeb  vmovaps [rsp], xmm0
00007f4f7cbdcbf0  vmovaps [rsp+0x10], xmm1
00007f4f7cbdcbf6  vmovaps [rsp+0x20], xmm2
00007f4f7cbdcbfc  vmovaps [rsp+0x30], xmm3
00007f4f7cbdcc02  vmovaps [rsp+0x40], xmm4
00007f4f7cbdcc08  vmovaps [rsp+0x50], xmm5
00007f4f7cbdcc0e  vmovaps [rsp+0x60], xmm6
00007f4f7cbdcc14  vmovaps [rsp+0x70], xmm7
00007f4f7cbdcc1a  vmovaps [rsp+0x80], xmm8
00007f4f7cbdcc23  vmovaps [rsp+0x90], xmm9
00007f4f7cbdcc2c  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdcc35  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdcc3e  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdcc47  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdcc50  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdcc59  sub rsp, 0x40
00007f4f7cbdcc5d  lea rdi, [rsp]
00007f4f7cbdcc61  lea rsi, [rsp+0x10]
00007f4f7cbdcc66  lea rdx, [rsp+0x20]
00007f4f7cbdcc6b  lea rcx, [rsp+0x30]
00007f4f7cbdcc70  mov r8d, 0x00
00007f4f7cbdcc76  lea r9, [r15+0x3A8]
00007f4f7cbdcc7d  movaps [rdi], xmm11
00007f4f7cbdcc81  movaps [rsi], xmm10
00007f4f7cbdcc85  movaps [rdx], xmm13
00007f4f7cbdcc89  movaps [rcx], xmm15
00007f4f7cbdcc8d  mov rax, 0x643999485A50
00007f4f7cbdcc97  call rax
00007f4f7cbdcc99  movaps xmm11, [rsp]
00007f4f7cbdcc9e  add rsp, 0x40
00007f4f7cbdcca2  vmovaps xmm0, [rsp]
00007f4f7cbdcca7  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdccad  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdccb3  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdccb9  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdccbf  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdccc5  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdcccb  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdccd1  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdccda  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdcce3  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdccec  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdccf5  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdccfe  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdcd07  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdcd10  add rsp, 0xF0
00007f4f7cbdcd17  pop r11
00007f4f7cbdcd19  pop r10
00007f4f7cbdcd1b  pop r9
00007f4f7cbdcd1d  pop r8
00007f4f7cbdcd1f  pop rsi
00007f4f7cbdcd20  pop rdi
00007f4f7cbdcd21  pop rdx
00007f4f7cbdcd22  pop rcx
00007f4f7cbdcd23  pop rax
00007f4f7cbdcd24  add rsp, 0x08
00007f4f7cbdcd28  jmp 0x00007F4F7CBDA54A
00007f4f7cbdcd2d  call 0x00007F4F7CA0E760
00007f4f7cbdcd32  jmp 0x00007F4F7CBDA557
00007f4f7cbdcd37  call 0x00007F4F7CA0D4E0
00007f4f7cbdcd3c  jmp 0x00007F4F7CBDA564
00007f4f7cbdcd41  sub rsp, 0x08
00007f4f7cbdcd45  push rax
00007f4f7cbdcd46  push rcx
00007f4f7cbdcd47  push rdx
00007f4f7cbdcd48  push rdi
00007f4f7cbdcd49  push rsi
00007f4f7cbdcd4a  push r8
00007f4f7cbdcd4c  push r9
00007f4f7cbdcd4e  push r10
00007f4f7cbdcd50  push r11
00007f4f7cbdcd52  sub rsp, 0xF0
00007f4f7cbdcd59  vmovaps [rsp], xmm0
00007f4f7cbdcd5e  vmovaps [rsp+0x10], xmm1
00007f4f7cbdcd64  vmovaps [rsp+0x20], xmm2
00007f4f7cbdcd6a  vmovaps [rsp+0x30], xmm3
00007f4f7cbdcd70  vmovaps [rsp+0x40], xmm4
00007f4f7cbdcd76  vmovaps [rsp+0x50], xmm5
00007f4f7cbdcd7c  vmovaps [rsp+0x60], xmm6
00007f4f7cbdcd82  vmovaps [rsp+0x70], xmm7
00007f4f7cbdcd88  vmovaps [rsp+0x80], xmm8
00007f4f7cbdcd91  vmovaps [rsp+0x90], xmm9
00007f4f7cbdcd9a  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdcda3  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdcdac  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdcdb5  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdcdbe  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdcdc7  sub rsp, 0x40
00007f4f7cbdcdcb  lea rdi, [rsp]
00007f4f7cbdcdcf  lea rsi, [rsp+0x10]
00007f4f7cbdcdd4  lea rdx, [rsp+0x20]
00007f4f7cbdcdd9  lea rcx, [rsp+0x30]
00007f4f7cbdcdde  mov r8d, 0x00
00007f4f7cbdcde4  lea r9, [r15+0x3A8]
00007f4f7cbdcdeb  movaps [rdi], xmm10
00007f4f7cbdcdef  movaps [rsi], xmm8
00007f4f7cbdcdf3  movaps [rdx], xmm1
00007f4f7cbdcdf6  movaps [rcx], xmm13
00007f4f7cbdcdfa  mov rax, 0x643999485A50
00007f4f7cbdce04  call rax
00007f4f7cbdce06  movaps xmm10, [rsp]
00007f4f7cbdce0b  add rsp, 0x40
00007f4f7cbdce0f  vmovaps xmm0, [rsp]
00007f4f7cbdce14  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdce1a  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdce20  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdce26  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdce2c  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdce32  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdce38  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdce3e  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdce47  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdce50  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdce59  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdce62  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdce6b  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdce74  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdce7d  add rsp, 0xF0
00007f4f7cbdce84  pop r11
00007f4f7cbdce86  pop r10
00007f4f7cbdce88  pop r9
00007f4f7cbdce8a  pop r8
00007f4f7cbdce8c  pop rsi
00007f4f7cbdce8d  pop rdi
00007f4f7cbdce8e  pop rdx
00007f4f7cbdce8f  pop rcx
00007f4f7cbdce90  pop rax
00007f4f7cbdce91  add rsp, 0x08
00007f4f7cbdce95  jmp 0x00007F4F7CBDA59A
00007f4f7cbdce9a  call 0x00007F4F7C9FF430
00007f4f7cbdce9f  jmp 0x00007F4F7CBDA5AC
00007f4f7cbdcea4  sub rsp, 0x08
00007f4f7cbdcea8  push rax
00007f4f7cbdcea9  push rcx
00007f4f7cbdceaa  push rdx
00007f4f7cbdceab  push rdi
00007f4f7cbdceac  push rsi
00007f4f7cbdcead  push r8
00007f4f7cbdceaf  push r9
00007f4f7cbdceb1  push r10
00007f4f7cbdceb3  push r11
00007f4f7cbdceb5  sub rsp, 0xF0
00007f4f7cbdcebc  vmovaps [rsp], xmm0
00007f4f7cbdcec1  vmovaps [rsp+0x10], xmm1
00007f4f7cbdcec7  vmovaps [rsp+0x20], xmm2
00007f4f7cbdcecd  vmovaps [rsp+0x30], xmm3
00007f4f7cbdced3  vmovaps [rsp+0x40], xmm4
00007f4f7cbdced9  vmovaps [rsp+0x50], xmm5
00007f4f7cbdcedf  vmovaps [rsp+0x60], xmm6
00007f4f7cbdcee5  vmovaps [rsp+0x70], xmm7
00007f4f7cbdceeb  vmovaps [rsp+0x80], xmm8
00007f4f7cbdcef4  vmovaps [rsp+0x90], xmm10
00007f4f7cbdcefd  vmovaps [rsp+0xA0], xmm11
00007f4f7cbdcf06  vmovaps [rsp+0xB0], xmm12
00007f4f7cbdcf0f  vmovaps [rsp+0xC0], xmm13
00007f4f7cbdcf18  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdcf21  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdcf2a  sub rsp, 0x40
00007f4f7cbdcf2e  lea rdi, [rsp]
00007f4f7cbdcf32  lea rsi, [rsp+0x10]
00007f4f7cbdcf37  lea rdx, [rsp+0x20]
00007f4f7cbdcf3c  lea rcx, [rsp+0x30]
00007f4f7cbdcf41  mov r8d, 0x00
00007f4f7cbdcf47  lea r9, [r15+0x3A8]
00007f4f7cbdcf4e  movaps [rdi], xmm9
00007f4f7cbdcf52  movaps [rsi], xmm7
00007f4f7cbdcf55  movaps [rdx], xmm14
00007f4f7cbdcf59  movaps [rcx], xmm13
00007f4f7cbdcf5d  mov rax, 0x643999485A50
00007f4f7cbdcf67  call rax
00007f4f7cbdcf69  movaps xmm9, [rsp]
00007f4f7cbdcf6e  add rsp, 0x40
00007f4f7cbdcf72  vmovaps xmm0, [rsp]
00007f4f7cbdcf77  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdcf7d  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdcf83  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdcf89  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdcf8f  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdcf95  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdcf9b  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdcfa1  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdcfaa  vmovaps xmm10, [rsp+0x90]
00007f4f7cbdcfb3  vmovaps xmm11, [rsp+0xA0]
00007f4f7cbdcfbc  vmovaps xmm12, [rsp+0xB0]
00007f4f7cbdcfc5  vmovaps xmm13, [rsp+0xC0]
00007f4f7cbdcfce  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdcfd7  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdcfe0  add rsp, 0xF0
00007f4f7cbdcfe7  pop r11
00007f4f7cbdcfe9  pop r10
00007f4f7cbdcfeb  pop r9
00007f4f7cbdcfed  pop r8
00007f4f7cbdcfef  pop rsi
00007f4f7cbdcff0  pop rdi
00007f4f7cbdcff1  pop rdx
00007f4f7cbdcff2  pop rcx
00007f4f7cbdcff3  pop rax
00007f4f7cbdcff4  add rsp, 0x08
00007f4f7cbdcff8  jmp 0x00007F4F7CBDA5DA
00007f4f7cbdcffd  sub rsp, 0x08
00007f4f7cbdd001  push rax
00007f4f7cbdd002  push rcx
00007f4f7cbdd003  push rdx
00007f4f7cbdd004  push rdi
00007f4f7cbdd005  push rsi
00007f4f7cbdd006  push r8
00007f4f7cbdd008  push r9
00007f4f7cbdd00a  push r10
00007f4f7cbdd00c  push r11
00007f4f7cbdd00e  sub rsp, 0xF0
00007f4f7cbdd015  vmovaps [rsp], xmm0
00007f4f7cbdd01a  vmovaps [rsp+0x10], xmm1
00007f4f7cbdd020  vmovaps [rsp+0x20], xmm2
00007f4f7cbdd026  vmovaps [rsp+0x30], xmm3
00007f4f7cbdd02c  vmovaps [rsp+0x40], xmm4
00007f4f7cbdd032  vmovaps [rsp+0x50], xmm5
00007f4f7cbdd038  vmovaps [rsp+0x60], xmm6
00007f4f7cbdd03e  vmovaps [rsp+0x70], xmm7
00007f4f7cbdd044  vmovaps [rsp+0x80], xmm8
00007f4f7cbdd04d  vmovaps [rsp+0x90], xmm9
00007f4f7cbdd056  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdd05f  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdd068  vmovaps [rsp+0xC0], xmm12
00007f4f7cbdd071  vmovaps [rsp+0xD0], xmm14
00007f4f7cbdd07a  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdd083  sub rsp, 0x40
00007f4f7cbdd087  lea rdi, [rsp]
00007f4f7cbdd08b  lea rsi, [rsp+0x10]
00007f4f7cbdd090  lea rdx, [rsp+0x20]
00007f4f7cbdd095  lea rcx, [rsp+0x30]
00007f4f7cbdd09a  mov r8d, 0x00
00007f4f7cbdd0a0  lea r9, [r15+0x3A8]
00007f4f7cbdd0a7  movaps [rdi], xmm13
00007f4f7cbdd0ab  movaps [rsi], xmm12
00007f4f7cbdd0af  movaps [rdx], xmm15
00007f4f7cbdd0b3  movaps [rcx], xmm14
00007f4f7cbdd0b7  mov rax, 0x643999485A50
00007f4f7cbdd0c1  call rax
00007f4f7cbdd0c3  movaps xmm13, [rsp]
00007f4f7cbdd0c8  add rsp, 0x40
00007f4f7cbdd0cc  vmovaps xmm0, [rsp]
00007f4f7cbdd0d1  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdd0d7  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdd0dd  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdd0e3  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdd0e9  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdd0ef  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdd0f5  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdd0fb  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdd104  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdd10d  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdd116  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdd11f  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbdd128  vmovaps xmm14, [rsp+0xD0]
00007f4f7cbdd131  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdd13a  add rsp, 0xF0
00007f4f7cbdd141  pop r11
00007f4f7cbdd143  pop r10
00007f4f7cbdd145  pop r9
00007f4f7cbdd147  pop r8
00007f4f7cbdd149  pop rsi
00007f4f7cbdd14a  pop rdi
00007f4f7cbdd14b  pop rdx
00007f4f7cbdd14c  pop rcx
00007f4f7cbdd14d  pop rax
00007f4f7cbdd14e  add rsp, 0x08
00007f4f7cbdd152  jmp 0x00007F4F7CBDA608
00007f4f7cbdd157  sub rsp, 0x08
00007f4f7cbdd15b  push rax
00007f4f7cbdd15c  push rcx
00007f4f7cbdd15d  push rdx
00007f4f7cbdd15e  push rdi
00007f4f7cbdd15f  push rsi
00007f4f7cbdd160  push r8
00007f4f7cbdd162  push r9
00007f4f7cbdd164  push r10
00007f4f7cbdd166  push r11
00007f4f7cbdd168  sub rsp, 0xF0
00007f4f7cbdd16f  vmovaps [rsp], xmm0
00007f4f7cbdd174  vmovaps [rsp+0x10], xmm1
00007f4f7cbdd17a  vmovaps [rsp+0x20], xmm2
00007f4f7cbdd180  vmovaps [rsp+0x30], xmm3
00007f4f7cbdd186  vmovaps [rsp+0x40], xmm4
00007f4f7cbdd18c  vmovaps [rsp+0x50], xmm5
00007f4f7cbdd192  vmovaps [rsp+0x60], xmm6
00007f4f7cbdd198  vmovaps [rsp+0x70], xmm7
00007f4f7cbdd19e  vmovaps [rsp+0x80], xmm8
00007f4f7cbdd1a7  vmovaps [rsp+0x90], xmm9
00007f4f7cbdd1b0  vmovaps [rsp+0xA0], xmm10
00007f4f7cbdd1b9  vmovaps [rsp+0xB0], xmm11
00007f4f7cbdd1c2  vmovaps [rsp+0xC0], xmm12
00007f4f7cbdd1cb  vmovaps [rsp+0xD0], xmm13
00007f4f7cbdd1d4  vmovaps [rsp+0xE0], xmm15
00007f4f7cbdd1dd  sub rsp, 0x40
00007f4f7cbdd1e1  lea rdi, [rsp]
00007f4f7cbdd1e5  lea rsi, [rsp+0x10]
00007f4f7cbdd1ea  lea rdx, [rsp+0x20]
00007f4f7cbdd1ef  lea rcx, [rsp+0x30]
00007f4f7cbdd1f4  mov r8d, 0x00
00007f4f7cbdd1fa  lea r9, [r15+0x3A8]
00007f4f7cbdd201  movaps [rdi], xmm14
00007f4f7cbdd205  movaps [rsi], xmm11
00007f4f7cbdd209  movaps [rdx], xmm1
00007f4f7cbdd20c  movaps [rcx], xmm15
00007f4f7cbdd210  mov rax, 0x643999485A50
00007f4f7cbdd21a  call rax
00007f4f7cbdd21c  movaps xmm14, [rsp]
00007f4f7cbdd221  add rsp, 0x40
00007f4f7cbdd225  vmovaps xmm0, [rsp]
00007f4f7cbdd22a  vmovaps xmm1, [rsp+0x10]
00007f4f7cbdd230  vmovaps xmm2, [rsp+0x20]
00007f4f7cbdd236  vmovaps xmm3, [rsp+0x30]
00007f4f7cbdd23c  vmovaps xmm4, [rsp+0x40]
00007f4f7cbdd242  vmovaps xmm5, [rsp+0x50]
00007f4f7cbdd248  vmovaps xmm6, [rsp+0x60]
00007f4f7cbdd24e  vmovaps xmm7, [rsp+0x70]
00007f4f7cbdd254  vmovaps xmm8, [rsp+0x80]
00007f4f7cbdd25d  vmovaps xmm9, [rsp+0x90]
00007f4f7cbdd266  vmovaps xmm10, [rsp+0xA0]
00007f4f7cbdd26f  vmovaps xmm11, [rsp+0xB0]
00007f4f7cbdd278  vmovaps xmm12, [rsp+0xC0]
00007f4f7cbdd281  vmovaps xmm13, [rsp+0xD0]
00007f4f7cbdd28a  vmovaps xmm15, [rsp+0xE0]
00007f4f7cbdd293  add rsp, 0xF0
00007f4f7cbdd29a  pop r11
00007f4f7cbdd29c  pop r10
00007f4f7cbdd29e  pop r9
00007f4f7cbdd2a0  pop r8
00007f4f7cbdd2a2  pop rsi
00007f4f7cbdd2a3  pop rdi
00007f4f7cbdd2a4  pop rdx
00007f4f7cbdd2a5  pop rcx
00007f4f7cbdd2a6  pop rax
00007f4f7cbdd2a7  add rsp, 0x08
00007f4f7cbdd2ab  jmp 0x00007F4F7CBDA636
00007f4f7cbdd2b0  call 0x00007F4F7CA079B0
00007f4f7cbdd2b5  jmp 0x00007F4F7CBDA64C
00007f4f7cbdd2ba  call 0x00007F4F7CAE3440
00007f4f7cbdd2bf  jmp 0x00007F4F7CBDA656
00007f4f7cbdd2c4  call 0x00007F4F7CADFCE0
00007f4f7cbdd2c9  jmp 0x00007F4F7CBDA660
00007f4f7cbdd2ce  call 0x00007F4F7CAE46C0
00007f4f7cbdd2d3  jmp 0x00007F4F7CBDA66A
00007f4f7cbdd2d8  int3
00007f4f7cbdd2d9  nop [rax], eax
00007f4f7cbdd2e0  mov qword ptr [r15+0x40], 0x430000
00007f4f7cbdd2e8  mov eax, 0x430C50
00007f4f7cbdd2ed  mov r14, [r13+rax*1]
00007f4f7cbdd2f2  movq xmm1, r14
00007f4f7cbdd2f7  mov rax, [r15+0x50]
00007f4f7cbdd2fb  movups xmm15, [r13+rax*1]
00007f4f7cbdd301  movaps [r15+0x120], xmm15
00007f4f7cbdd309  mov qword ptr [r15+0x48], 0x10
00007f4f7cbdd311  xor eax, eax
00007f4f7cbdd313  mov r14d, 0x10
00007f4f7cbdd319  mov r12d, 0x200
00007f4f7cbdd31f  cmp r14, r12
00007f4f7cbdd322  cmc
00007f4f7cbdd323  lahf
00007f4f7cbdd324  seto al
00007f4f7cbdd327  mov [r15+0x108], eax
00007f4f7cbdd32e  pextrq rax, xmm15, 0x01
00007f4f7cbdd335  movq xmm14, rax
00007f4f7cbdd33a  movaps [r15+0x130], xmm14
00007f4f7cbdd342  movq rax, xmm1
00007f4f7cbdd347  movq r14, xmm15
00007f4f7cbdd34c  vmovq xmm1, rax
00007f4f7cbdd351  vmovq xmm15, r14
00007f4f7cbdd356  movaps xmm13, xmm1
00007f4f7cbdd35a  addsd xmm13, xmm15
00007f4f7cbdd35f  ucomisd xmm13, xmm13
00007f4f7cbdd364  jp 0x00007F4F7CBDD423
00007f4f7cbdd36a  movq xmm13, xmm13
00007f4f7cbdd36f  movq rax, xmm13
00007f4f7cbdd374  movq r14, xmm14
00007f4f7cbdd379  vmovq xmm1, rax
00007f4f7cbdd37e  vmovq xmm15, r14
00007f4f7cbdd383  movaps xmm14, xmm1
00007f4f7cbdd387  addsd xmm14, xmm15
00007f4f7cbdd38c  ucomisd xmm14, xmm14
00007f4f7cbdd391  jp 0x00007F4F7CBDD46B
00007f4f7cbdd397  movq xmm14, xmm14
00007f4f7cbdd39c  movaps [r15+0x110], xmm14
00007f4f7cbdd3a4  mov eax, [r15+0x108]
00007f4f7cbdd3ab  sahf
00007f4f7cbdd3ac  jnz 0x00007F4F7CBDD3DE
00007f4f7cbdd3ae  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbdd3b6  jz 0x00007F4F7CBDD680
00007f4f7cbdd3bc  nop [rax+rax*1], ax
00007f4f7cbdd3c5  nop [rax+rax*1], eax
00007f4f7cbdd3cd  mov eax, 0x410698
00007f4f7cbdd3d2  mov [r15+0x100], rax
00007f4f7cbdd3d9  jmp 0x00007F4F7C9FE110
00007f4f7cbdd3de  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbdd3e6  jz 0x00007F4F7CBDD4C0
00007f4f7cbdd3ec  nop [rax+rax*1], ax
00007f4f7cbdd3f5  nop [rax+rax*1], eax
00007f4f7cbdd3fd  mov eax, 0x41067C
00007f4f7cbdd402  mov [r15+0x100], rax
00007f4f7cbdd409  jmp 0x00007F4F7C9FE110
00007f4f7cbdd40e  int3
00007f4f7cbdd40f  call 0x00007F4F7CA0DC20
00007f4f7cbdd414  jmp 0x00007F4F7CBDD2F2
00007f4f7cbdd419  call 0x00007F4F7CA0E760
00007f4f7cbdd41e  jmp 0x00007F4F7CBDD301
00007f4f7cbdd423  ucomisd xmm1, xmm15
00007f4f7cbdd428  jp 0x00007F4F7CBDD437
00007f4f7cbdd42a  movaps xmm13, [0x00007F4F7C7FE060]
00007f4f7cbdd432  jmp 0x00007F4F7CBDD36A
00007f4f7cbdd437  vxorps xmm0, xmm1, xmm15
00007f4f7cbdd43c  pextrw eax, xmm0, 0x03
00007f4f7cbdd441  and eax, 0x7FF8
00007f4f7cbdd446  cmp eax, 0x08
00007f4f7cbdd449  jnz 0x00007F4F7CBDD36A
00007f4f7cbdd44f  movq rax, xmm15
00007f4f7cbdd454  shl rax, 0x0D
00007f4f7cbdd458  jbe 0x00007F4F7CBDD36A
00007f4f7cbdd45e  vorps xmm13, xmm15, [0x00007F4F7C7FE070]
00007f4f7cbdd466  jmp 0x00007F4F7CBDD36A
00007f4f7cbdd46b  ucomisd xmm1, xmm15
00007f4f7cbdd470  jp 0x00007F4F7CBDD47F
00007f4f7cbdd472  movaps xmm14, [0x00007F4F7C7FE060]
00007f4f7cbdd47a  jmp 0x00007F4F7CBDD397
00007f4f7cbdd47f  vxorps xmm0, xmm1, xmm15
00007f4f7cbdd484  pextrw eax, xmm0, 0x03
00007f4f7cbdd489  and eax, 0x7FF8
00007f4f7cbdd48e  cmp eax, 0x08
00007f4f7cbdd491  jnz 0x00007F4F7CBDD397
00007f4f7cbdd497  movq rax, xmm15
00007f4f7cbdd49c  shl rax, 0x0D
00007f4f7cbdd4a0  jbe 0x00007F4F7CBDD397
00007f4f7cbdd4a6  vorps xmm14, xmm15, [0x00007F4F7C7FE070]
00007f4f7cbdd4ae  jmp 0x00007F4F7CBDD397
00007f4f7cbdd4b3  int3
00007f4f7cbdd4b4  nop [rax+rax*1], ax
00007f4f7cbdd4bd  nop [rax], eax
00007f4f7cbdd4c0  mov rax, [r15+0x48]
00007f4f7cbdd4c4  mov r14, [r15+0x50]
00007f4f7cbdd4c8  lea r12, [r14+rax*1]
00007f4f7cbdd4cc  movups xmm1, [r13+r12*1]
00007f4f7cbdd4d2  movaps [r15+0x120], xmm1
00007f4f7cbdd4da  lea r14, [rax+0x10]
00007f4f7cbdd4de  mov [r15+0x48], r14
00007f4f7cbdd4e2  xor eax, eax
00007f4f7cbdd4e4  mov r12d, 0x200
00007f4f7cbdd4ea  cmp r14, r12
00007f4f7cbdd4ed  cmc
00007f4f7cbdd4ee  lahf
00007f4f7cbdd4ef  seto al
00007f4f7cbdd4f2  mov [r15+0x108], eax
00007f4f7cbdd4f9  pextrq rax, xmm1, 0x01
00007f4f7cbdd500  movq xmm15, rax
00007f4f7cbdd505  movaps [r15+0x130], xmm15
00007f4f7cbdd50d  movaps xmm14, [r15+0x110]
00007f4f7cbdd515  movq rax, xmm14
00007f4f7cbdd51a  movq r14, xmm1
00007f4f7cbdd51f  vmovq xmm1, rax
00007f4f7cbdd524  vmovq xmm14, r14
00007f4f7cbdd529  movaps xmm13, xmm1
00007f4f7cbdd52d  addsd xmm13, xmm14
00007f4f7cbdd532  ucomisd xmm13, xmm13
00007f4f7cbdd537  jp 0x00007F4F7CBDD5EC
00007f4f7cbdd53d  movq xmm13, xmm13
00007f4f7cbdd542  movq rax, xmm13
00007f4f7cbdd547  movq r14, xmm15
00007f4f7cbdd54c  vmovq xmm1, rax
00007f4f7cbdd551  vmovq xmm15, r14
00007f4f7cbdd556  movaps xmm14, xmm1
00007f4f7cbdd55a  addsd xmm14, xmm15
00007f4f7cbdd55f  ucomisd xmm14, xmm14
00007f4f7cbdd564  jp 0x00007F4F7CBDD634
00007f4f7cbdd56a  movq xmm14, xmm14
00007f4f7cbdd56f  movaps [r15+0x110], xmm14
00007f4f7cbdd577  mov eax, [r15+0x108]
00007f4f7cbdd57e  sahf
00007f4f7cbdd57f  jnz 0x00007F4F7CBDD5B1
00007f4f7cbdd581  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbdd589  jz 0x00007F4F7CBDD680
00007f4f7cbdd58f  nop [rax+rax*1], ax
00007f4f7cbdd598  nop [rax+rax*1], eax
00007f4f7cbdd5a0  mov eax, 0x410698
00007f4f7cbdd5a5  mov [r15+0x100], rax
00007f4f7cbdd5ac  jmp 0x00007F4F7C9FE110
00007f4f7cbdd5b1  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbdd5b9  jz 0x00007F4F7CBDD4C0
00007f4f7cbdd5bf  nop [rax+rax*1], ax
00007f4f7cbdd5c8  nop [rax+rax*1], eax
00007f4f7cbdd5d0  mov eax, 0x41067C
00007f4f7cbdd5d5  mov [r15+0x100], rax
00007f4f7cbdd5dc  jmp 0x00007F4F7C9FE110
00007f4f7cbdd5e1  int3
00007f4f7cbdd5e2  call 0x00007F4F7CAB52F0
00007f4f7cbdd5e7  jmp 0x00007F4F7CBDD4D2
00007f4f7cbdd5ec  ucomisd xmm1, xmm14
00007f4f7cbdd5f1  jp 0x00007F4F7CBDD600
00007f4f7cbdd5f3  movaps xmm13, [0x00007F4F7C7FE060]
00007f4f7cbdd5fb  jmp 0x00007F4F7CBDD53D
00007f4f7cbdd600  vxorps xmm0, xmm1, xmm14
00007f4f7cbdd605  pextrw eax, xmm0, 0x03
00007f4f7cbdd60a  and eax, 0x7FF8
00007f4f7cbdd60f  cmp eax, 0x08
00007f4f7cbdd612  jnz 0x00007F4F7CBDD53D
00007f4f7cbdd618  movq rax, xmm14
00007f4f7cbdd61d  shl rax, 0x0D
00007f4f7cbdd621  jbe 0x00007F4F7CBDD53D
00007f4f7cbdd627  vorps xmm13, xmm14, [0x00007F4F7C7FE070]
00007f4f7cbdd62f  jmp 0x00007F4F7CBDD53D
00007f4f7cbdd634  ucomisd xmm1, xmm15
00007f4f7cbdd639  jp 0x00007F4F7CBDD648
00007f4f7cbdd63b  movaps xmm14, [0x00007F4F7C7FE060]
00007f4f7cbdd643  jmp 0x00007F4F7CBDD56A
00007f4f7cbdd648  vxorps xmm0, xmm1, xmm15
00007f4f7cbdd64d  pextrw eax, xmm0, 0x03
00007f4f7cbdd652  and eax, 0x7FF8
00007f4f7cbdd657  cmp eax, 0x08
00007f4f7cbdd65a  jnz 0x00007F4F7CBDD56A
00007f4f7cbdd660  movq rax, xmm15
00007f4f7cbdd665  shl rax, 0x0D
00007f4f7cbdd669  jbe 0x00007F4F7CBDD56A
00007f4f7cbdd66f  vorps xmm14, xmm15, [0x00007F4F7C7FE070]
00007f4f7cbdd677  jmp 0x00007F4F7CBDD56A
00007f4f7cbdd67c  int3
00007f4f7cbdd67d  nop [rax], eax
00007f4f7cbdd680  mov rax, [r15+0xF8]
00007f4f7cbdd687  lea r14, [rax+0x1A0]
00007f4f7cbdd68e  mov r12, [r13+r14*1]
00007f4f7cbdd693  lea r14, [rax+0x1A8]
00007f4f7cbdd69a  mov r11, [r13+r14*1]
00007f4f7cbdd69f  mov [r15+0xA0], r12
00007f4f7cbdd6a6  mov [r15+0x98], r11
00007f4f7cbdd6ad  mov r14, [r15+0x40]
00007f4f7cbdd6b1  lea r12, [r14+0xC50]
00007f4f7cbdd6b8  movaps xmm1, [r15+0x110]
00007f4f7cbdd6c0  movq r14, xmm1
00007f4f7cbdd6c5  mov [r13+r12*1], r14
00007f4f7cbdd6ca  lea r14, [rax+0x190]
00007f4f7cbdd6d1  mov r12, [r13+r14*1]
00007f4f7cbdd6d6  lea r14, [rax+0x198]
00007f4f7cbdd6dd  mov r11, [r13+r14*1]
00007f4f7cbdd6e2  mov [r15+0xE8], r12
00007f4f7cbdd6e9  mov [r15+0xF0], r11
00007f4f7cbdd6f0  lea r14, [rax+0x180]
00007f4f7cbdd6f7  mov r12, [r13+r14*1]
00007f4f7cbdd6fc  lea r14, [rax+0x188]
00007f4f7cbdd703  mov r10, [r13+r14*1]
00007f4f7cbdd708  movq xmm1, r12
00007f4f7cbdd70d  movq xmm15, r10
00007f4f7cbdd712  movq xmm1, xmm1
00007f4f7cbdd716  movq xmm1, xmm1
00007f4f7cbdd71a  movaps [r15+0x1A0], xmm1
00007f4f7cbdd722  movq xmm15, xmm15
00007f4f7cbdd727  movq xmm15, xmm15
00007f4f7cbdd72c  movaps [r15+0x190], xmm15
00007f4f7cbdd734  lea r14, [rax+0x170]
00007f4f7cbdd73b  mov r12, [r13+r14*1]
00007f4f7cbdd740  lea r14, [rax+0x178]
00007f4f7cbdd747  mov r10, [r13+r14*1]
00007f4f7cbdd74c  movq xmm1, r12
00007f4f7cbdd751  movq xmm15, r10
00007f4f7cbdd756  movq xmm1, xmm1
00007f4f7cbdd75a  movq xmm1, xmm1
00007f4f7cbdd75e  movaps [r15+0x1C0], xmm1
00007f4f7cbdd766  movq xmm15, xmm15
00007f4f7cbdd76b  movq xmm15, xmm15
00007f4f7cbdd770  movaps [r15+0x1B0], xmm15
00007f4f7cbdd778  lea r14, [rax+0x160]
00007f4f7cbdd77f  mov r12, [r13+r14*1]
00007f4f7cbdd784  lea r14, [rax+0x168]
00007f4f7cbdd78b  mov r10, [r13+r14*1]
00007f4f7cbdd790  movq xmm1, r12
00007f4f7cbdd795  movq xmm15, r10
00007f4f7cbdd79a  movq xmm1, xmm1
00007f4f7cbdd79e  movq xmm1, xmm1
00007f4f7cbdd7a2  movaps [r15+0x1E0], xmm1
00007f4f7cbdd7aa  movq xmm15, xmm15
00007f4f7cbdd7af  movq xmm15, xmm15
00007f4f7cbdd7b4  movaps [r15+0x1D0], xmm15
00007f4f7cbdd7bc  lea r14, [rax+0x150]
00007f4f7cbdd7c3  mov r12, [r13+r14*1]
00007f4f7cbdd7c8  lea r14, [rax+0x158]
00007f4f7cbdd7cf  mov r10, [r13+r14*1]
00007f4f7cbdd7d4  movq xmm1, r12
00007f4f7cbdd7d9  movq xmm15, r10
00007f4f7cbdd7de  movq xmm1, xmm1
00007f4f7cbdd7e2  movq xmm1, xmm1
00007f4f7cbdd7e6  movaps [r15+0x200], xmm1
00007f4f7cbdd7ee  movq xmm15, xmm15
00007f4f7cbdd7f3  movq xmm15, xmm15
00007f4f7cbdd7f8  movaps [r15+0x1F0], xmm15
00007f4f7cbdd800  lea r14, [rax+0x1B0]
00007f4f7cbdd807  mov [r15+0xF8], r14
00007f4f7cbdd80e  mov [r15+0x100], r11
00007f4f7cbdd815  jmp 0x00007F4F7CBCE5C0
00007f4f7cbdd81a  int3
00007f4f7cbdd81b  call 0x00007F4F7CAE27E0
00007f4f7cbdd820  jmp 0x00007F4F7CBDD693
00007f4f7cbdd825  call 0x00007F4F7CAE1570
00007f4f7cbdd82a  jmp 0x00007F4F7CBDD69F
00007f4f7cbdd82f  call 0x00007F4F7CAC3FE0
00007f4f7cbdd834  jmp 0x00007F4F7CBDD6CA
00007f4f7cbdd839  call 0x00007F4F7CAE27E0
00007f4f7cbdd83e  jmp 0x00007F4F7CBDD6D6
00007f4f7cbdd843  call 0x00007F4F7CAE1570
00007f4f7cbdd848  jmp 0x00007F4F7CBDD6E2
00007f4f7cbdd84d  call 0x00007F4F7CAE27E0
00007f4f7cbdd852  jmp 0x00007F4F7CBDD6FC
00007f4f7cbdd857  call 0x00007F4F7CAE0300
00007f4f7cbdd85c  jmp 0x00007F4F7CBDD708
00007f4f7cbdd861  call 0x00007F4F7CAE27E0
00007f4f7cbdd866  jmp 0x00007F4F7CBDD740
00007f4f7cbdd86b  call 0x00007F4F7CAE0300
00007f4f7cbdd870  jmp 0x00007F4F7CBDD74C
00007f4f7cbdd875  call 0x00007F4F7CAE27E0
00007f4f7cbdd87a  jmp 0x00007F4F7CBDD784
00007f4f7cbdd87f  call 0x00007F4F7CAE0300
00007f4f7cbdd884  jmp 0x00007F4F7CBDD790
00007f4f7cbdd889  call 0x00007F4F7CAE27E0
00007f4f7cbdd88e  jmp 0x00007F4F7CBDD7C8
00007f4f7cbdd893  call 0x00007F4F7CAE0300
00007f4f7cbdd898  jmp 0x00007F4F7CBDD7D4
00007f4f7cbdd89d  int3
00007f4f7cbdd89e  nop
00007f4f7cbdd8a0  mov qword ptr [r15+0x100], 0x04
00007f4f7cbdd8ab  mov esi, 0x00
00007f4f7cbdd8b0  mov edx, 0x09
00007f4f7cbdd8b5  mov rdi, 0x7FFF03F6EB20
00007f4f7cbdd8bf  mov rax, 0x643999318970
00007f4f7cbdd8c9  call rax
00007f4f7cbdd8cb  cmp dword ptr [r15+0x318], 0x00
00007f4f7cbdd8d3  jnz 0x00007F4F7C9FE110
00007f4f7cbdd8d9  jmp 0x00007F4F7C9FE0A0
00007f4f7cbdd8de  int3
00007f4f7cbdd8df  int3
