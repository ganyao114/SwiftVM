0000781a8ffce69b  nop [rax+rax*1], eax
0000781a8ffce6a0  mov rax, [r15+0xF8]
0000781a8ffce6a7  lea r14, [rax-0x1B0]
0000781a8ffce6ae  mov [r15+0xF8], r14
0000781a8ffce6b5  lea rax, [r14+0x1A0]
0000781a8ffce6bc  mov r12, [r15+0xA0]
0000781a8ffce6c3  mov r11, [r15+0x98]
0000781a8ffce6ca  mov [r13+rax*1], r12
0000781a8ffce6cf  lea rax, [r14+0x1A8]
0000781a8ffce6d6  mov [r13+rax*1], r11
0000781a8ffce6db  mov eax, 0x420A30
0000781a8ffce6e0  movups xmm1, [r13+rax*1]
0000781a8ffce6e6  mov eax, 0x4209C0
0000781a8ffce6eb  movups xmm15, [r13+rax*1]
0000781a8ffce6f1  mov eax, 0x420A50
0000781a8ffce6f6  movups xmm14, [r13+rax*1]
0000781a8ffce6fc  mov eax, 0x4209F0
0000781a8ffce701  movups xmm13, [r13+rax*1]
0000781a8ffce707  mov qword ptr [r15+0x98], 0x430C60
0000781a8ffce712  mov eax, 0x420A60
0000781a8ffce717  movups xmm12, [r13+rax*1]
0000781a8ffce71d  mov eax, 0x430C60
0000781a8ffce722  movups [r13+rax*1], xmm1
0000781a8ffce728  mov eax, 0x430C70
0000781a8ffce72d  movups [r13+rax*1], xmm15
0000781a8ffce733  mov eax, 0x430C80
0000781a8ffce738  movups [r13+rax*1], xmm14
0000781a8ffce73e  mov eax, 0x430C90
0000781a8ffce743  movups [r13+rax*1], xmm13
0000781a8ffce749  mov eax, 0x4209B0
0000781a8ffce74e  movups xmm14, [r13+rax*1]
0000781a8ffce754  mov eax, 0x4209A0
0000781a8ffce759  movups xmm13, [r13+rax*1]
0000781a8ffce75f  mov eax, 0x430D60
0000781a8ffce764  movups [r13+rax*1], xmm1
0000781a8ffce76a  mov eax, 0x430D70
0000781a8ffce76f  movups [r13+rax*1], xmm15
0000781a8ffce775  mov eax, 0x430CA0
0000781a8ffce77a  movups [r13+rax*1], xmm12
0000781a8ffce780  mov eax, 0x430CB0
0000781a8ffce785  movups [r13+rax*1], xmm14
0000781a8ffce78b  mov eax, 0x420990
0000781a8ffce790  movups xmm1, [r13+rax*1]
0000781a8ffce796  mov eax, 0x420A00
0000781a8ffce79b  movups xmm15, [r13+rax*1]
0000781a8ffce7a1  mov eax, 0x430CC0
0000781a8ffce7a6  movups [r13+rax*1], xmm13
0000781a8ffce7ac  mov eax, 0x430CD0
0000781a8ffce7b1  movups [r13+rax*1], xmm1
0000781a8ffce7b7  mov eax, 0x420A10
0000781a8ffce7bc  movups xmm1, [r13+rax*1]
0000781a8ffce7c2  mov eax, 0x4209E0
0000781a8ffce7c7  movups xmm14, [r13+rax*1]
0000781a8ffce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000781a8ffce7d5  mov eax, 0x430CE0
0000781a8ffce7da  movups [r13+rax*1], xmm15
0000781a8ffce7e0  mov eax, 0x430CF0
0000781a8ffce7e5  movups [r13+rax*1], xmm1
0000781a8ffce7eb  mov eax, 0x420A80
0000781a8ffce7f0  movups xmm1, [r13+rax*1]
0000781a8ffce7f6  mov eax, 0x420A90
0000781a8ffce7fb  movups xmm15, [r13+rax*1]
0000781a8ffce801  movaps [r15+0x150], xmm15
0000781a8ffce809  mov qword ptr [r15+0xA0], 0x3E8
0000781a8ffce814  mov eax, 0x430D00
0000781a8ffce819  movups [r13+rax*1], xmm14
0000781a8ffce81f  mov eax, 0x430D10
0000781a8ffce824  movups [r13+rax*1], xmm1
0000781a8ffce82a  mov eax, 0x420A70
0000781a8ffce82f  movups xmm1, [r13+rax*1]
0000781a8ffce835  mov eax, 0x420A20
0000781a8ffce83a  movups xmm14, [r13+rax*1]
0000781a8ffce840  movaps [r15+0x140], xmm14
0000781a8ffce848  lea rax, [r14+0x150]
0000781a8ffce84f  movq xmm13, qword ptr [r15+0x200]
0000781a8ffce858  movq xmm12, qword ptr [r15+0x1F0]
0000781a8ffce861  movq r12, xmm13
0000781a8ffce866  movq r11, xmm12
0000781a8ffce86b  mov [r13+rax*1], r12
0000781a8ffce870  lea rax, [r14+0x158]
0000781a8ffce877  mov [r13+rax*1], r11
0000781a8ffce87c  mov eax, 0x430D20
0000781a8ffce881  movups [r13+rax*1], xmm15
0000781a8ffce887  mov eax, 0x430D30
0000781a8ffce88c  movups [r13+rax*1], xmm1
0000781a8ffce892  mov eax, 0x420A40
0000781a8ffce897  movups xmm1, [r13+rax*1]
0000781a8ffce89d  mov eax, 0x420AA8
0000781a8ffce8a2  mov r12, [r13+rax*1]
0000781a8ffce8a7  movq xmm15, r12
0000781a8ffce8ac  mov qword ptr [r15+0x40], 0x420AB0
0000781a8ffce8b4  mov eax, 0x430D40
0000781a8ffce8b9  movups [r13+rax*1], xmm14
0000781a8ffce8bf  mov eax, 0x430D50
0000781a8ffce8c4  movups [r13+rax*1], xmm1
0000781a8ffce8ca  mov eax, 0x420B10
0000781a8ffce8cf  movups xmm1, [r13+rax*1]
0000781a8ffce8d5  movq rax, xmm15
0000781a8ffce8da  mov r12d, 0x430D80
0000781a8ffce8e0  mov [r13+r12*1], rax
0000781a8ffce8e5  mov eax, 0x420AF0
0000781a8ffce8ea  movups xmm15, [r13+rax*1]
0000781a8ffce8f0  mov eax, 0x420B00
0000781a8ffce8f5  movups xmm14, [r13+rax*1]
0000781a8ffce8fb  lea rax, [r14+0x130]
0000781a8ffce902  movups [r13+rax*1], xmm1
0000781a8ffce908  lea rax, [r14+0x160]
0000781a8ffce90f  movq xmm1, qword ptr [r15+0x1E0]
0000781a8ffce918  movq xmm13, qword ptr [r15+0x1D0]
0000781a8ffce921  movq r12, xmm1
0000781a8ffce926  movq r11, xmm13
0000781a8ffce92b  mov [r13+rax*1], r12
0000781a8ffce930  lea rax, [r14+0x168]
0000781a8ffce937  mov [r13+rax*1], r11
0000781a8ffce93c  lea rax, [r14+0x110]
0000781a8ffce943  movups [r13+rax*1], xmm15
0000781a8ffce949  lea rax, [r14+0x120]
0000781a8ffce950  movups [r13+rax*1], xmm14
0000781a8ffce956  mov eax, 0x420AB0
0000781a8ffce95b  movups xmm1, [r13+rax*1]
0000781a8ffce961  mov eax, 0x420AC0
0000781a8ffce966  movups xmm15, [r13+rax*1]
0000781a8ffce96c  movaps [r15+0x120], xmm15
0000781a8ffce974  lea rax, [r14+0x170]
0000781a8ffce97b  movq xmm14, qword ptr [r15+0x1C0]
0000781a8ffce984  movq xmm13, qword ptr [r15+0x1B0]
0000781a8ffce98d  movq r12, xmm14
0000781a8ffce992  movq r11, xmm13
0000781a8ffce997  mov [r13+rax*1], r12
0000781a8ffce99c  lea rax, [r14+0x178]
0000781a8ffce9a3  mov [r13+rax*1], r11
0000781a8ffce9a8  lea rax, [r14+0x180]
0000781a8ffce9af  movq xmm14, qword ptr [r15+0x1A0]
0000781a8ffce9b8  movq xmm13, qword ptr [r15+0x190]
0000781a8ffce9c1  movq r12, xmm14
0000781a8ffce9c6  movq r11, xmm13
0000781a8ffce9cb  mov [r13+rax*1], r12
0000781a8ffce9d0  lea rax, [r14+0x188]
0000781a8ffce9d7  mov [r13+rax*1], r11
0000781a8ffce9dc  lea rax, [r14+0xD0]
0000781a8ffce9e3  movups [r13+rax*1], xmm1
0000781a8ffce9e9  lea rax, [r14+0xE0]
0000781a8ffce9f0  movups [r13+rax*1], xmm15
0000781a8ffce9f6  mov eax, 0x420AD0
0000781a8ffce9fb  movups xmm1, [r13+rax*1]
0000781a8ffcea01  mov eax, 0x420AE0
0000781a8ffcea06  movups xmm15, [r13+rax*1]
0000781a8ffcea0c  movaps [r15+0x110], xmm1
0000781a8ffcea14  movaps [r15+0x130], xmm15
0000781a8ffcea1c  lea rax, [r14+0x190]
0000781a8ffcea23  mov r12, [r15+0xE8]
0000781a8ffcea2a  mov r11, [r15+0xF0]
0000781a8ffcea31  mov [r13+rax*1], r12
0000781a8ffcea36  lea rax, [r14+0x198]
0000781a8ffcea3d  mov [r13+rax*1], r11
0000781a8ffcea42  mov eax, 0x430D88
0000781a8ffcea47  mov r12d, 0x421DF8D3
0000781a8ffcea4d  mov [r13+rax*1], r12d
0000781a8ffcea52  lea rax, [r14+0xF0]
0000781a8ffcea59  movups [r13+rax*1], xmm1
0000781a8ffcea5f  lea rax, [r14+0x100]
0000781a8ffcea66  movups [r13+rax*1], xmm15
0000781a8ffcea6c  lea rax, [r14+0xD0]
0000781a8ffcea73  mov [r15], rax
0000781a8ffcea76  mov qword ptr [r15+0x08], 0x430C60
0000781a8ffcea7e  mov qword ptr [r15+0x10], 0x12C
0000781a8ffcea86  mov qword ptr [r15+0xF0], 0x410284
0000781a8ffcea91  mov r14d, [r15+0x320]
0000781a8ffcea98  mov eax, 0x410284
0000781a8ffcea9d  mov rcx, 0x781A8FFD07C0
0000781a8ffceaa7  mov [r15+r14*8+0x328], rax
0000781a8ffceaaf  mov [r15+r14*8+0x368], rcx
0000781a8ffceab7  add r14d, 0x01
0000781a8ffceabb  and r14d, 0x07
0000781a8ffceabf  mov [r15+0x320], r14d
0000781a8ffceac6  cmp dword ptr [r15+0x318], 0x00
0000781a8ffceace  jz 0x0000781A8FFCED70
0000781a8ffcead4  nop [rax+rax*1], ax
0000781a8ffceadd  nop [rax+rax*1], eax
0000781a8ffceae5  mov eax, 0x4106BC
0000781a8ffceaea  mov [r15+0x100], rax
0000781a8ffceaf1  jmp 0x0000781A8FDFE110
0000781a8ffceaf6  int3
0000781a8ffceaf7  call 0x0000781A8FE0BC20
0000781a8ffceafc  jmp 0x0000781A8FFCE6CF
0000781a8ffceb01  call 0x0000781A8FE0A9A0
0000781a8ffceb06  jmp 0x0000781A8FFCE6DB
0000781a8ffceb0b  call 0x0000781A8FDFF430
0000781a8ffceb10  jmp 0x0000781A8FFCE6E6
0000781a8ffceb15  call 0x0000781A8FE0E760
0000781a8ffceb1a  jmp 0x0000781A8FFCE6F1
0000781a8ffceb1f  call 0x0000781A8FE0D4E0
0000781a8ffceb24  jmp 0x0000781A8FFCE6FC
0000781a8ffceb29  call 0x0000781A8FE0C260
0000781a8ffceb2e  jmp 0x0000781A8FFCE707
0000781a8ffceb33  call 0x0000781A8FE0AFE0
0000781a8ffceb38  jmp 0x0000781A8FFCE71D
0000781a8ffceb3d  call 0x0000781A8FDFF540
0000781a8ffceb42  jmp 0x0000781A8FFCE728
0000781a8ffceb47  call 0x0000781A8FE0E880
0000781a8ffceb4c  jmp 0x0000781A8FFCE733
0000781a8ffceb51  call 0x0000781A8FE0D600
0000781a8ffceb56  jmp 0x0000781A8FFCE73E
0000781a8ffceb5b  call 0x0000781A8FE0C380
0000781a8ffceb60  jmp 0x0000781A8FFCE749
0000781a8ffceb65  call 0x0000781A8FE0D4E0
0000781a8ffceb6a  jmp 0x0000781A8FFCE754
0000781a8ffceb6f  call 0x0000781A8FE0C260
0000781a8ffceb74  jmp 0x0000781A8FFCE75F
0000781a8ffceb79  call 0x0000781A8FDFF540
0000781a8ffceb7e  jmp 0x0000781A8FFCE76A
0000781a8ffceb83  call 0x0000781A8FE0E880
0000781a8ffceb88  jmp 0x0000781A8FFCE775
0000781a8ffceb8d  call 0x0000781A8FE0B100
0000781a8ffceb92  jmp 0x0000781A8FFCE780
0000781a8ffceb97  call 0x0000781A8FE0D600
0000781a8ffceb9c  jmp 0x0000781A8FFCE78B
0000781a8ffceba1  call 0x0000781A8FDFF430
0000781a8ffceba6  jmp 0x0000781A8FFCE796
0000781a8ffcebab  call 0x0000781A8FE0E760
0000781a8ffcebb0  jmp 0x0000781A8FFCE7A1
0000781a8ffcebb5  call 0x0000781A8FE0C380
0000781a8ffcebba  jmp 0x0000781A8FFCE7AC
0000781a8ffcebbf  call 0x0000781A8FDFF540
0000781a8ffcebc4  jmp 0x0000781A8FFCE7B7
0000781a8ffcebc9  call 0x0000781A8FDFF430
0000781a8ffcebce  jmp 0x0000781A8FFCE7C2
0000781a8ffcebd3  call 0x0000781A8FE0D4E0
0000781a8ffcebd8  jmp 0x0000781A8FFCE7CD
0000781a8ffcebdd  call 0x0000781A8FE0E880
0000781a8ffcebe2  jmp 0x0000781A8FFCE7E0
0000781a8ffcebe7  call 0x0000781A8FDFF540
0000781a8ffcebec  jmp 0x0000781A8FFCE7EB
0000781a8ffcebf1  call 0x0000781A8FDFF430
0000781a8ffcebf6  jmp 0x0000781A8FFCE7F6
0000781a8ffcebfb  call 0x0000781A8FE0E760
0000781a8ffcec00  jmp 0x0000781A8FFCE801
0000781a8ffcec05  call 0x0000781A8FE0D600
0000781a8ffcec0a  jmp 0x0000781A8FFCE81F
0000781a8ffcec0f  call 0x0000781A8FDFF540
0000781a8ffcec14  jmp 0x0000781A8FFCE82A
0000781a8ffcec19  call 0x0000781A8FDFF430
0000781a8ffcec1e  jmp 0x0000781A8FFCE835
0000781a8ffcec23  call 0x0000781A8FE0D4E0
0000781a8ffcec28  jmp 0x0000781A8FFCE840
0000781a8ffcec2d  call 0x0000781A8FE0BC20
0000781a8ffcec32  jmp 0x0000781A8FFCE870
0000781a8ffcec37  call 0x0000781A8FE0A9A0
0000781a8ffcec3c  jmp 0x0000781A8FFCE87C
0000781a8ffcec41  call 0x0000781A8FE0E880
0000781a8ffcec46  jmp 0x0000781A8FFCE887
0000781a8ffcec4b  call 0x0000781A8FDFF540
0000781a8ffcec50  jmp 0x0000781A8FFCE892
0000781a8ffcec55  call 0x0000781A8FDFF430
0000781a8ffcec5a  jmp 0x0000781A8FFCE89D
0000781a8ffcec5f  call 0x0000781A8FE0B720
0000781a8ffcec64  jmp 0x0000781A8FFCE8A7
0000781a8ffcec69  call 0x0000781A8FE0D600
0000781a8ffcec6e  jmp 0x0000781A8FFCE8BF
0000781a8ffcec73  call 0x0000781A8FDFF540
0000781a8ffcec78  jmp 0x0000781A8FFCE8CA
0000781a8ffcec7d  call 0x0000781A8FDFF430
0000781a8ffcec82  jmp 0x0000781A8FFCE8D5
0000781a8ffcec87  call 0x0000781A8FEB4CB0
0000781a8ffcec8c  jmp 0x0000781A8FFCE8E5
0000781a8ffcec91  call 0x0000781A8FE0E760
0000781a8ffcec96  jmp 0x0000781A8FFCE8F0
0000781a8ffcec9b  call 0x0000781A8FE0D4E0
0000781a8ffceca0  jmp 0x0000781A8FFCE8FB
0000781a8ffceca5  call 0x0000781A8FDFF540
0000781a8ffcecaa  jmp 0x0000781A8FFCE908
0000781a8ffcecaf  call 0x0000781A8FE0BC20
0000781a8ffcecb4  jmp 0x0000781A8FFCE930
0000781a8ffcecb9  call 0x0000781A8FE0A9A0
0000781a8ffcecbe  jmp 0x0000781A8FFCE93C
0000781a8ffcecc3  call 0x0000781A8FE0E880
0000781a8ffcecc8  jmp 0x0000781A8FFCE949
0000781a8ffceccd  call 0x0000781A8FE0D600
0000781a8ffcecd2  jmp 0x0000781A8FFCE956
0000781a8ffcecd7  call 0x0000781A8FDFF430
0000781a8ffcecdc  jmp 0x0000781A8FFCE961
0000781a8ffcece1  call 0x0000781A8FE0E760
0000781a8ffcece6  jmp 0x0000781A8FFCE96C
0000781a8ffceceb  call 0x0000781A8FE0BC20
0000781a8ffcecf0  jmp 0x0000781A8FFCE99C
0000781a8ffcecf5  call 0x0000781A8FE0A9A0
0000781a8ffcecfa  jmp 0x0000781A8FFCE9A8
0000781a8ffcecff  call 0x0000781A8FE0BC20
0000781a8ffced04  jmp 0x0000781A8FFCE9D0
0000781a8ffced09  call 0x0000781A8FE0A9A0
0000781a8ffced0e  jmp 0x0000781A8FFCE9DC
0000781a8ffced13  call 0x0000781A8FDFF540
0000781a8ffced18  jmp 0x0000781A8FFCE9E9
0000781a8ffced1d  call 0x0000781A8FE0E880
0000781a8ffced22  jmp 0x0000781A8FFCE9F6
0000781a8ffced27  call 0x0000781A8FDFF430
0000781a8ffced2c  jmp 0x0000781A8FFCEA01
0000781a8ffced31  call 0x0000781A8FE0E760
0000781a8ffced36  jmp 0x0000781A8FFCEA0C
0000781a8ffced3b  call 0x0000781A8FE0BC20
0000781a8ffced40  jmp 0x0000781A8FFCEA36
0000781a8ffced45  call 0x0000781A8FE0A9A0
0000781a8ffced4a  jmp 0x0000781A8FFCEA42
0000781a8ffced4f  call 0x0000781A8FE0BAE0
0000781a8ffced54  jmp 0x0000781A8FFCEA52
0000781a8ffced59  call 0x0000781A8FDFF540
0000781a8ffced5e  jmp 0x0000781A8FFCEA5F
0000781a8ffced63  call 0x0000781A8FE0E880
0000781a8ffced68  jmp 0x0000781A8FFCEA6C
0000781a8ffced6d  int3
0000781a8ffced6e  nop
0000781a8ffced70  mov rax, [r15]
0000781a8ffced73  lea r14, [rax+0x20]
0000781a8ffced77  mov r12, [r13+r14*1]
0000781a8ffced7c  mov r14, [r15+0x10]
0000781a8ffced80  lea r11, [r12+r14*1]
0000781a8ffced84  mov [r15+0x40], r11
0000781a8ffced88  lea r12, [rax+0x20]
0000781a8ffced8c  mov [r13+r12*1], r11
0000781a8ffced91  test r14, r14
0000781a8ffced94  setz r14b
0000781a8ffced98  movzx r14, r14b
0000781a8ffced9c  mov [rsp+0x414], r14b
0000781a8ffceda4  cmp byte ptr [rsp+0x414], 0x00
0000781a8ffcedac  jz 0x0000781A8FFCEDDE
0000781a8ffcedae  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcedb6  mov eax, 0x410934
0000781a8ffcedbb  mov [r15+0x100], rax
0000781a8ffcedc2  jz 0x0000781A8FDFE0A0
0000781a8ffcedc8  nop [rax+rax*1], eax
0000781a8ffcedcd  mov eax, 0x410934
0000781a8ffcedd2  mov [r15+0x100], rax
0000781a8ffcedd9  jmp 0x0000781A8FDFE110
0000781a8ffcedde  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcede6  jz 0x0000781A8FFCEE30
0000781a8ffcedec  nop [rax+rax*1], ax
0000781a8ffcedf5  nop [rax+rax*1], eax
0000781a8ffcedfd  mov eax, 0x4106CC
0000781a8ffcee02  mov [r15+0x100], rax
0000781a8ffcee09  jmp 0x0000781A8FDFE110
0000781a8ffcee0e  int3
0000781a8ffcee0f  call 0x0000781A8FEE27E0
0000781a8ffcee14  jmp 0x0000781A8FFCED7C
0000781a8ffcee19  call 0x0000781A8FEC0860
0000781a8ffcee1e  jmp 0x0000781A8FFCED91
0000781a8ffcee23  int3
0000781a8ffcee24  nop [rax+rax*1], ax
0000781a8ffcee2d  nop [rax], eax
0000781a8ffcee30  mov rax, [r15+0xF8]
0000781a8ffcee37  lea r14, [rax-0x150]
0000781a8ffcee3e  mov [r15+0xF8], r14
0000781a8ffcee45  mov rax, [r15]
0000781a8ffcee48  lea r12, [rax+0x68]
0000781a8ffcee4c  mov r11, [r13+r12*1]
0000781a8ffcee51  mov [r15+0x88], r11
0000781a8ffcee58  lea r12, [rax+0x28]
0000781a8ffcee5c  mov [r15+0x40], r12
0000781a8ffcee60  mov [r15+0x48], r14
0000781a8ffcee64  mov qword ptr [r15+0x50], 0x420B20
0000781a8ffcee6c  lea rax, [r14+0x100]
0000781a8ffcee73  mov r12, [r15+0xE8]
0000781a8ffcee7a  mov r11, [r15+0xD8]
0000781a8ffcee81  mov [r13+rax*1], r12
0000781a8ffcee86  lea rax, [r14+0x108]
0000781a8ffcee8d  mov [r13+rax*1], r11
0000781a8ffcee92  lea rax, [r14+0x110]
0000781a8ffcee99  mov r12, [r15+0xD0]
0000781a8ffceea0  mov r11, [r15+0xC8]
0000781a8ffceea7  mov [r13+rax*1], r12
0000781a8ffceeac  lea rax, [r14+0x118]
0000781a8ffceeb3  mov [r13+rax*1], r11
0000781a8ffceeb8  lea rax, [r14+0x120]
0000781a8ffceebf  mov r12, [r15+0xC0]
0000781a8ffceec6  mov r11, [r15+0xB8]
0000781a8ffceecd  mov [r13+rax*1], r12
0000781a8ffceed2  lea rax, [r14+0x128]
0000781a8ffceed9  mov [r13+rax*1], r11
0000781a8ffceede  lea rax, [r14+0x130]
0000781a8ffceee5  mov r12, [r15+0xB0]
0000781a8ffceeec  mov r11, [r15+0xA8]
0000781a8ffceef3  mov [r13+rax*1], r12
0000781a8ffceef8  lea rax, [r14+0x138]
0000781a8ffceeff  mov [r13+rax*1], r11
0000781a8ffcef04  lea rax, [r14+0x140]
0000781a8ffcef0b  mov r12, [r15+0xA0]
0000781a8ffcef12  mov r11, [r15+0x98]
0000781a8ffcef19  mov [r13+rax*1], r12
0000781a8ffcef1e  lea rax, [r14+0x148]
0000781a8ffcef25  mov [r13+rax*1], r11
0000781a8ffcef2a  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcef32  jz 0x0000781A8FFCEFD0
0000781a8ffcef38  nop [rax+rax*1], ax
0000781a8ffcef41  nop [rax+rax*1], eax
0000781a8ffcef49  mov eax, 0x410704
0000781a8ffcef4e  mov [r15+0x100], rax
0000781a8ffcef55  jmp 0x0000781A8FDFE110
0000781a8ffcef5a  int3
0000781a8ffcef5b  call 0x0000781A8FEC0370
0000781a8ffcef60  jmp 0x0000781A8FFCEE51
0000781a8ffcef65  call 0x0000781A8FE0BC20
0000781a8ffcef6a  jmp 0x0000781A8FFCEE86
0000781a8ffcef6f  call 0x0000781A8FE0A9A0
0000781a8ffcef74  jmp 0x0000781A8FFCEE92
0000781a8ffcef79  call 0x0000781A8FE0BC20
0000781a8ffcef7e  jmp 0x0000781A8FFCEEAC
0000781a8ffcef83  call 0x0000781A8FE0A9A0
0000781a8ffcef88  jmp 0x0000781A8FFCEEB8
0000781a8ffcef8d  call 0x0000781A8FE0BC20
0000781a8ffcef92  jmp 0x0000781A8FFCEED2
0000781a8ffcef97  call 0x0000781A8FE0A9A0
0000781a8ffcef9c  jmp 0x0000781A8FFCEEDE
0000781a8ffcefa1  call 0x0000781A8FE0BC20
0000781a8ffcefa6  jmp 0x0000781A8FFCEEF8
0000781a8ffcefab  call 0x0000781A8FE0A9A0
0000781a8ffcefb0  jmp 0x0000781A8FFCEF04
0000781a8ffcefb5  call 0x0000781A8FE0BC20
0000781a8ffcefba  jmp 0x0000781A8FFCEF1E
0000781a8ffcefbf  call 0x0000781A8FE0A9A0
0000781a8ffcefc4  jmp 0x0000781A8FFCEF2A
0000781a8ffcefc9  int3
0000781a8ffcefca  nop [rax+rax*1], ax
0000781a8ffcefd0  mov rax, [r15+0x08]
0000781a8ffcefd4  movzx r14d, byte ptr [r13+rax*1]
0000781a8ffcefda  movzx r14d, r14b
0000781a8ffcefde  mov [rsp+0x10], r14d
0000781a8ffcefe3  mov r14d, r14d
0000781a8ffcefe6  mov [r15+0x58], r14
0000781a8ffcefea  lea r14, [rax+0x01]
0000781a8ffcefee  mov [r15+0x08], r14
0000781a8ffceff2  mov rax, [r15+0x88]
0000781a8ffceff9  lea r14, [rax+0x01]
0000781a8ffceffd  mov r12, [r15]
0000781a8ffcf000  lea r11, [r12+0x68]
0000781a8ffcf005  mov [r13+r11*1], r14
0000781a8ffcf00a  lea r14, [r12+rax*1]
0000781a8ffcf00e  mov [r15+0x60], r14
0000781a8ffcf012  lea rax, [r14+0x28]
0000781a8ffcf016  mov r11d, [rsp+0x10]
0000781a8ffcf01b  movzx r14d, r11b
0000781a8ffcf01f  mov [r13+rax*1], r14b
0000781a8ffcf024  lea rax, [r12+0x68]
0000781a8ffcf029  mov r14, [r13+rax*1]
0000781a8ffcf02e  mov [r15+0x88], r14
0000781a8ffcf035  xor eax, eax
0000781a8ffcf037  mov r12d, 0x40
0000781a8ffcf03d  cmp r14, r12
0000781a8ffcf040  cmc
0000781a8ffcf041  lahf
0000781a8ffcf042  seto al
0000781a8ffcf045  mov [r15+0x108], eax
0000781a8ffcf04c  mov eax, [r15+0x108]
0000781a8ffcf053  sahf
0000781a8ffcf054  jnz 0x0000781A8FFCF086
0000781a8ffcf056  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcf05e  jz 0x0000781A8FFCF170
0000781a8ffcf064  nop [rax+rax*1], ax
0000781a8ffcf06d  nop [rax+rax*1], eax
0000781a8ffcf075  mov eax, 0x410724
0000781a8ffcf07a  mov [r15+0x100], rax
0000781a8ffcf081  jmp 0x0000781A8FDFE110
0000781a8ffcf086  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcf08e  jz 0x0000781A8FFCF0E0
0000781a8ffcf094  nop [rax+rax*1], ax
0000781a8ffcf09d  nop [rax+rax*1], eax
0000781a8ffcf0a5  mov eax, 0x4106FC
0000781a8ffcf0aa  mov [r15+0x100], rax
0000781a8ffcf0b1  jmp 0x0000781A8FDFE110
0000781a8ffcf0b6  int3
0000781a8ffcf0b7  call 0x0000781A8FE0D860
0000781a8ffcf0bc  jmp 0x0000781A8FFCEFDA
0000781a8ffcf0c1  call 0x0000781A8FEB36E0
0000781a8ffcf0c6  jmp 0x0000781A8FFCF00A
0000781a8ffcf0cb  call 0x0000781A8FE0DD60
0000781a8ffcf0d0  jmp 0x0000781A8FFCF024
0000781a8ffcf0d5  call 0x0000781A8FE0DC20
0000781a8ffcf0da  jmp 0x0000781A8FFCF02E
0000781a8ffcf0df  int3
0000781a8ffcf0e0  mov rax, [r15+0x10]
0000781a8ffcf0e4  lea r14, [rax-0x01]
0000781a8ffcf0e8  mov [r15+0x10], r14
0000781a8ffcf0ec  test r14, r14
0000781a8ffcf0ef  setz r14b
0000781a8ffcf0f3  movzx r14, r14b
0000781a8ffcf0f7  mov [rsp+0x414], r14b
0000781a8ffcf0ff  cmp byte ptr [rsp+0x414], 0x00
0000781a8ffcf107  jz 0x0000781A8FFCF139
0000781a8ffcf109  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcf111  jz 0x0000781A8FFD0670
0000781a8ffcf117  nop [rax+rax*1], ax
0000781a8ffcf120  nop [rax+rax*1], eax
0000781a8ffcf128  mov eax, 0x41091C
0000781a8ffcf12d  mov [r15+0x100], rax
0000781a8ffcf134  jmp 0x0000781A8FDFE110
0000781a8ffcf139  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcf141  jz 0x0000781A8FFCEFD0
0000781a8ffcf147  nop [rax+rax*1], ax
0000781a8ffcf150  nop [rax+rax*1], eax
0000781a8ffcf158  mov eax, 0x410704
0000781a8ffcf15d  mov [r15+0x100], rax
0000781a8ffcf164  jmp 0x0000781A8FDFE110
0000781a8ffcf169  int3
0000781a8ffcf16a  int3
0000781a8ffcf16b  nop [rax+rax*1], eax
0000781a8ffcf170  mov rax, [r15+0x40]
0000781a8ffcf174  movzx r14d, byte ptr [r13+rax*1]
0000781a8ffcf17a  movaps xmm1, [r15+0x110]
0000781a8ffcf182  pinsrb xmm1, r14d, 0x00
0000781a8ffcf189  lea r14, [rax+0x01]
0000781a8ffcf18d  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf193  movaps xmm15, [r15+0x120]
0000781a8ffcf19b  pinsrb xmm15, r12d, 0x00
0000781a8ffcf1a2  lea r14, [rax+0x02]
0000781a8ffcf1a6  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf1ac  movaps xmm14, [r15+0x130]
0000781a8ffcf1b4  pinsrb xmm14, r12d, 0x00
0000781a8ffcf1bb  lea r14, [rax+0x03]
0000781a8ffcf1bf  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf1c5  movaps xmm13, [r15+0x140]
0000781a8ffcf1cd  pinsrb xmm13, r12d, 0x00
0000781a8ffcf1d4  lea r14, [rax+0x04]
0000781a8ffcf1d8  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf1de  pinsrb xmm1, r12d, 0x01
0000781a8ffcf1e5  lea r14, [rax+0x05]
0000781a8ffcf1e9  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf1ef  pinsrb xmm15, r12d, 0x01
0000781a8ffcf1f6  lea r14, [rax+0x06]
0000781a8ffcf1fa  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf200  pinsrb xmm14, r12d, 0x01
0000781a8ffcf207  lea r14, [rax+0x07]
0000781a8ffcf20b  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf211  pinsrb xmm13, r12d, 0x01
0000781a8ffcf218  lea r14, [rax+0x08]
0000781a8ffcf21c  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf222  pinsrb xmm1, r12d, 0x02
0000781a8ffcf229  lea r14, [rax+0x09]
0000781a8ffcf22d  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf233  pinsrb xmm15, r12d, 0x02
0000781a8ffcf23a  lea r14, [rax+0x0A]
0000781a8ffcf23e  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf244  pinsrb xmm14, r12d, 0x02
0000781a8ffcf24b  lea r14, [rax+0x0B]
0000781a8ffcf24f  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf255  pinsrb xmm13, r12d, 0x02
0000781a8ffcf25c  lea r14, [rax+0x0C]
0000781a8ffcf260  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf266  pinsrb xmm1, r12d, 0x03
0000781a8ffcf26d  lea r14, [rax+0x0D]
0000781a8ffcf271  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf277  pinsrb xmm15, r12d, 0x03
0000781a8ffcf27e  lea r14, [rax+0x0E]
0000781a8ffcf282  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf288  pinsrb xmm14, r12d, 0x03
0000781a8ffcf28f  lea r14, [rax+0x0F]
0000781a8ffcf293  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf299  pinsrb xmm13, r12d, 0x03
0000781a8ffcf2a0  lea r14, [rax+0x10]
0000781a8ffcf2a4  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf2aa  pinsrb xmm1, r12d, 0x04
0000781a8ffcf2b1  lea r14, [rax+0x11]
0000781a8ffcf2b5  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf2bb  pinsrb xmm15, r12d, 0x04
0000781a8ffcf2c2  lea r14, [rax+0x12]
0000781a8ffcf2c6  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf2cc  pinsrb xmm14, r12d, 0x04
0000781a8ffcf2d3  lea r14, [rax+0x13]
0000781a8ffcf2d7  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf2dd  pinsrb xmm13, r12d, 0x04
0000781a8ffcf2e4  lea r14, [rax+0x14]
0000781a8ffcf2e8  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf2ee  pinsrb xmm1, r12d, 0x05
0000781a8ffcf2f5  lea r14, [rax+0x15]
0000781a8ffcf2f9  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf2ff  pinsrb xmm15, r12d, 0x05
0000781a8ffcf306  lea r14, [rax+0x16]
0000781a8ffcf30a  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf310  pinsrb xmm14, r12d, 0x05
0000781a8ffcf317  lea r14, [rax+0x17]
0000781a8ffcf31b  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf321  pinsrb xmm13, r12d, 0x05
0000781a8ffcf328  lea r14, [rax+0x18]
0000781a8ffcf32c  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf332  pinsrb xmm1, r12d, 0x06
0000781a8ffcf339  lea r14, [rax+0x19]
0000781a8ffcf33d  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf343  pinsrb xmm15, r12d, 0x06
0000781a8ffcf34a  lea r14, [rax+0x1A]
0000781a8ffcf34e  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf354  pinsrb xmm14, r12d, 0x06
0000781a8ffcf35b  lea r14, [rax+0x1B]
0000781a8ffcf35f  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf365  pinsrb xmm13, r12d, 0x06
0000781a8ffcf36c  lea r14, [rax+0x1C]
0000781a8ffcf370  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf376  pinsrb xmm1, r12d, 0x07
0000781a8ffcf37d  lea r14, [rax+0x1D]
0000781a8ffcf381  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf387  pinsrb xmm15, r12d, 0x07
0000781a8ffcf38e  lea r14, [rax+0x1E]
0000781a8ffcf392  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf398  pinsrb xmm14, r12d, 0x07
0000781a8ffcf39f  lea r14, [rax+0x1F]
0000781a8ffcf3a3  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf3a9  pinsrb xmm13, r12d, 0x07
0000781a8ffcf3b0  lea r14, [rax+0x20]
0000781a8ffcf3b4  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf3ba  pinsrb xmm1, r12d, 0x08
0000781a8ffcf3c1  lea r14, [rax+0x21]
0000781a8ffcf3c5  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf3cb  pinsrb xmm15, r12d, 0x08
0000781a8ffcf3d2  lea r14, [rax+0x22]
0000781a8ffcf3d6  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf3dc  pinsrb xmm14, r12d, 0x08
0000781a8ffcf3e3  lea r14, [rax+0x23]
0000781a8ffcf3e7  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf3ed  pinsrb xmm13, r12d, 0x08
0000781a8ffcf3f4  lea r14, [rax+0x24]
0000781a8ffcf3f8  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf3fe  pinsrb xmm1, r12d, 0x09
0000781a8ffcf405  lea r14, [rax+0x25]
0000781a8ffcf409  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf40f  pinsrb xmm15, r12d, 0x09
0000781a8ffcf416  lea r14, [rax+0x26]
0000781a8ffcf41a  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf420  pinsrb xmm14, r12d, 0x09
0000781a8ffcf427  lea r14, [rax+0x27]
0000781a8ffcf42b  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf431  pinsrb xmm13, r12d, 0x09
0000781a8ffcf438  lea r14, [rax+0x28]
0000781a8ffcf43c  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf442  pinsrb xmm1, r12d, 0x0A
0000781a8ffcf449  lea r14, [rax+0x29]
0000781a8ffcf44d  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf453  pinsrb xmm15, r12d, 0x0A
0000781a8ffcf45a  lea r14, [rax+0x2A]
0000781a8ffcf45e  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf464  pinsrb xmm14, r12d, 0x0A
0000781a8ffcf46b  lea r14, [rax+0x2B]
0000781a8ffcf46f  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf475  pinsrb xmm13, r12d, 0x0A
0000781a8ffcf47c  lea r14, [rax+0x2C]
0000781a8ffcf480  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf486  pinsrb xmm1, r12d, 0x0B
0000781a8ffcf48d  lea r14, [rax+0x2D]
0000781a8ffcf491  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf497  pinsrb xmm15, r12d, 0x0B
0000781a8ffcf49e  lea r14, [rax+0x2E]
0000781a8ffcf4a2  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf4a8  pinsrb xmm14, r12d, 0x0B
0000781a8ffcf4af  lea r14, [rax+0x2F]
0000781a8ffcf4b3  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf4b9  pinsrb xmm13, r12d, 0x0B
0000781a8ffcf4c0  lea r14, [rax+0x30]
0000781a8ffcf4c4  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf4ca  pinsrb xmm1, r12d, 0x0C
0000781a8ffcf4d1  lea r14, [rax+0x31]
0000781a8ffcf4d5  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf4db  pinsrb xmm15, r12d, 0x0C
0000781a8ffcf4e2  lea r14, [rax+0x32]
0000781a8ffcf4e6  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf4ec  pinsrb xmm14, r12d, 0x0C
0000781a8ffcf4f3  lea r14, [rax+0x33]
0000781a8ffcf4f7  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf4fd  pinsrb xmm13, r12d, 0x0C
0000781a8ffcf504  lea r14, [rax+0x34]
0000781a8ffcf508  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf50e  pinsrb xmm1, r12d, 0x0D
0000781a8ffcf515  lea r14, [rax+0x35]
0000781a8ffcf519  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf51f  pinsrb xmm15, r12d, 0x0D
0000781a8ffcf526  lea r14, [rax+0x36]
0000781a8ffcf52a  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf530  pinsrb xmm14, r12d, 0x0D
0000781a8ffcf537  lea r14, [rax+0x37]
0000781a8ffcf53b  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf541  pinsrb xmm13, r12d, 0x0D
0000781a8ffcf548  lea r14, [rax+0x38]
0000781a8ffcf54c  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf552  pinsrb xmm1, r12d, 0x0E
0000781a8ffcf559  lea r14, [rax+0x39]
0000781a8ffcf55d  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf563  pinsrb xmm15, r12d, 0x0E
0000781a8ffcf56a  lea r14, [rax+0x3A]
0000781a8ffcf56e  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf574  pinsrb xmm14, r12d, 0x0E
0000781a8ffcf57b  lea r14, [rax+0x3B]
0000781a8ffcf57f  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf585  pinsrb xmm13, r12d, 0x0E
0000781a8ffcf58c  lea r14, [rax+0x3C]
0000781a8ffcf590  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf596  pinsrb xmm1, r12d, 0x0F
0000781a8ffcf59d  movaps [r15+0x110], xmm1
0000781a8ffcf5a5  lea r14, [rax+0x3D]
0000781a8ffcf5a9  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf5af  pinsrb xmm15, r12d, 0x0F
0000781a8ffcf5b6  movaps [r15+0x120], xmm15
0000781a8ffcf5be  lea r14, [rax+0x3E]
0000781a8ffcf5c2  movzx r12d, byte ptr [r13+r14*1]
0000781a8ffcf5c8  pinsrb xmm14, r12d, 0x0F
0000781a8ffcf5cf  movaps [r15+0x130], xmm14
0000781a8ffcf5d7  lea r14, [rax+0x3F]
0000781a8ffcf5db  movzx eax, byte ptr [r13+r14*1]
0000781a8ffcf5e1  pinsrb xmm13, eax, 0x0F
0000781a8ffcf5e8  movaps [r15+0x140], xmm13
0000781a8ffcf5f0  movq xmm1, qword ptr [r15+0x120]
0000781a8ffcf5f9  pmovzxbw xmm1, xmm1
0000781a8ffcf5fe  psllw xmm1, 0x00
0000781a8ffcf603  movaps [r15+0x150], xmm1
0000781a8ffcf60b  movq xmm1, qword ptr [r15+0x130]
0000781a8ffcf614  pmovzxbw xmm1, xmm1
0000781a8ffcf619  psllw xmm1, 0x00
0000781a8ffcf61e  movaps [r15+0x160], xmm1
0000781a8ffcf626  movq xmm1, qword ptr [r15+0x110]
0000781a8ffcf62f  pmovzxbw xmm1, xmm1
0000781a8ffcf634  psllw xmm1, 0x00
0000781a8ffcf639  movaps [r15+0x170], xmm1
0000781a8ffcf641  movaps xmm15, [r15+0x110]
0000781a8ffcf649  pextrq rax, xmm15, 0x01
0000781a8ffcf650  movq xmm15, rax
0000781a8ffcf655  pmovzxbw xmm15, xmm15
0000781a8ffcf65b  psllw xmm15, 0x00
0000781a8ffcf661  movaps [r15+0x180], xmm15
0000781a8ffcf669  movaps xmm14, [r15+0x120]
0000781a8ffcf671  pextrq rax, xmm14, 0x01
0000781a8ffcf678  movq xmm14, rax
0000781a8ffcf67d  pmovzxbw xmm14, xmm14
0000781a8ffcf683  psllw xmm14, 0x00
0000781a8ffcf689  movaps [r15+0x210], xmm14
0000781a8ffcf691  movaps xmm13, [r15+0x130]
0000781a8ffcf699  pextrq rax, xmm13, 0x01
0000781a8ffcf6a0  movq xmm13, rax
0000781a8ffcf6a5  pmovzxbw xmm13, xmm13
0000781a8ffcf6ab  psllw xmm13, 0x00
0000781a8ffcf6b1  movaps [r15+0x220], xmm13
0000781a8ffcf6b9  movq xmm12, qword ptr [r15+0x140]
0000781a8ffcf6c2  pmovzxbw xmm12, xmm12
0000781a8ffcf6c8  psllw xmm12, 0x00
0000781a8ffcf6ce  movaps [r15+0x250], xmm12
0000781a8ffcf6d6  movaps xmm12, [r15+0x140]
0000781a8ffcf6de  pextrq rax, xmm12, 0x01
0000781a8ffcf6e5  movq xmm12, rax
0000781a8ffcf6ea  pmovzxbw xmm12, xmm12
0000781a8ffcf6f0  psllw xmm12, 0x00
0000781a8ffcf6f6  movaps [r15+0x110], xmm12
0000781a8ffcf6fe  movq xmm11, qword ptr [r15+0x150]
0000781a8ffcf707  pmovzxwd xmm11, xmm11
0000781a8ffcf70d  pslld xmm11, 0x10
0000781a8ffcf713  movq xmm10, qword ptr [r15+0x160]
0000781a8ffcf71c  pmovzxwd xmm10, xmm10
0000781a8ffcf722  pslld xmm10, 0x08
0000781a8ffcf728  pextrq rax, xmm1, 0x01
0000781a8ffcf72f  movq xmm1, rax
0000781a8ffcf734  pmovzxwd xmm1, xmm1
0000781a8ffcf739  pslld xmm1, 0x00
0000781a8ffcf73e  movaps [r15+0x260], xmm1
0000781a8ffcf746  pextrq rax, xmm15, 0x01
0000781a8ffcf74d  movq xmm15, rax
0000781a8ffcf752  pmovzxwd xmm15, xmm15
0000781a8ffcf758  pslld xmm15, 0x00
0000781a8ffcf75e  movaps [r15+0x270], xmm15
0000781a8ffcf766  movq xmm9, qword ptr [r15+0x170]
0000781a8ffcf76f  pmovzxwd xmm9, xmm9
0000781a8ffcf775  pslld xmm9, 0x00
0000781a8ffcf77b  pextrq rax, xmm14, 0x01
0000781a8ffcf782  movq xmm14, rax
0000781a8ffcf787  pmovzxwd xmm14, xmm14
0000781a8ffcf78d  pslld xmm14, 0x10
0000781a8ffcf793  movaps [r15+0x280], xmm14
0000781a8ffcf79b  movq xmm8, qword ptr [r15+0x180]
0000781a8ffcf7a4  pmovzxwd xmm8, xmm8
0000781a8ffcf7aa  pslld xmm8, 0x00
0000781a8ffcf7b0  movq xmm7, qword ptr [r15+0x210]
0000781a8ffcf7b9  pmovzxwd xmm7, xmm7
0000781a8ffcf7be  pslld xmm7, 0x10
0000781a8ffcf7c3  movaps xmm6, [r15+0x150]
0000781a8ffcf7cb  pextrq rax, xmm6, 0x01
0000781a8ffcf7d2  movq xmm6, rax
0000781a8ffcf7d7  pmovzxwd xmm6, xmm6
0000781a8ffcf7dc  pslld xmm6, 0x10
0000781a8ffcf7e1  por xmm11, xmm10
0000781a8ffcf7e6  movaps [r15+0x230], xmm11
0000781a8ffcf7ee  pextrq rax, xmm13, 0x01
0000781a8ffcf7f5  movq xmm13, rax
0000781a8ffcf7fa  pmovzxwd xmm13, xmm13
0000781a8ffcf800  pslld xmm13, 0x08
0000781a8ffcf806  movaps [r15+0x240], xmm13
0000781a8ffcf80e  movq xmm10, qword ptr [r15+0x220]
0000781a8ffcf817  pmovzxwd xmm10, xmm10
0000781a8ffcf81d  pslld xmm10, 0x08
0000781a8ffcf823  movaps xmm5, [r15+0x160]
0000781a8ffcf82b  pextrq rax, xmm5, 0x01
0000781a8ffcf832  movq xmm5, rax
0000781a8ffcf837  pmovzxwd xmm5, xmm5
0000781a8ffcf83c  pslld xmm5, 0x08
0000781a8ffcf841  pslld xmm9, 0x18
0000781a8ffcf847  pslld xmm15, 0x18
0000781a8ffcf84d  pslld xmm8, 0x18
0000781a8ffcf853  movq xmm4, qword ptr [r15+0x250]
0000781a8ffcf85c  pmovzxwd xmm4, xmm4
0000781a8ffcf861  pslld xmm4, 0x00
0000781a8ffcf866  por xmm14, xmm13
0000781a8ffcf86b  por xmm7, xmm10
0000781a8ffcf870  movaps [r15+0x210], xmm7
0000781a8ffcf878  pslld xmm1, 0x18
0000781a8ffcf87d  movaps [r15+0x220], xmm1
0000781a8ffcf885  por xmm6, xmm5
0000781a8ffcf889  por xmm11, xmm9
0000781a8ffcf88e  movaps [r15+0x160], xmm11
0000781a8ffcf896  pextrq rax, xmm12, 0x01
0000781a8ffcf89d  movq xmm13, rax
0000781a8ffcf8a2  pmovzxwd xmm13, xmm13
0000781a8ffcf8a8  pslld xmm13, 0x00
0000781a8ffcf8ae  movaps [r15+0x170], xmm13
0000781a8ffcf8b6  movq xmm12, qword ptr [r15+0x110]
0000781a8ffcf8bf  pmovzxwd xmm12, xmm12
0000781a8ffcf8c5  pslld xmm12, 0x00
0000781a8ffcf8cb  por xmm14, xmm15
0000781a8ffcf8d0  por xmm7, xmm8
0000781a8ffcf8d5  movaps xmm15, [r15+0x250]
0000781a8ffcf8dd  pextrq rax, xmm15, 0x01
0000781a8ffcf8e4  movq xmm15, rax
0000781a8ffcf8e9  pmovzxwd xmm15, xmm15
0000781a8ffcf8ef  pslld xmm15, 0x00
0000781a8ffcf8f5  movaps [r15+0x180], xmm15
0000781a8ffcf8fd  por xmm6, xmm1
0000781a8ffcf901  movaps [r15+0x150], xmm6
0000781a8ffcf909  por xmm11, xmm4
0000781a8ffcf90e  movaps [r15+0x140], xmm11
0000781a8ffcf916  por xmm7, xmm12
0000781a8ffcf91b  movaps [r15+0x110], xmm7
0000781a8ffcf923  por xmm14, xmm13
0000781a8ffcf928  movaps [r15+0x120], xmm14
0000781a8ffcf930  por xmm6, xmm15
0000781a8ffcf935  movaps [r15+0x130], xmm6
0000781a8ffcf93d  mov rax, [r15+0xF8]
0000781a8ffcf944  lea r14, [rax+0x20]
0000781a8ffcf948  movups [r13+r14*1], xmm7
0000781a8ffcf94e  lea r14, [rax+0x30]
0000781a8ffcf952  movups [r13+r14*1], xmm14
0000781a8ffcf958  movups [r13+rax*1], xmm11
0000781a8ffcf95e  lea r14, [rax+0x10]
0000781a8ffcf962  movups [r13+r14*1], xmm6
0000781a8ffcf968  mov r14d, [r13+rax*1]
0000781a8ffcf96d  mov rax, [r15+0x48]
0000781a8ffcf971  mov [r15+0x68], rax
0000781a8ffcf975  mov qword ptr [r15+0x58], 0x04
0000781a8ffcf97d  lea r12, [rax+0x04]
0000781a8ffcf981  mov r11d, [r13+r12*1]
0000781a8ffcf986  mov [rsp+0x10], r11d
0000781a8ffcf98b  mov r11d, r11d
0000781a8ffcf98e  mov [r15+0x70], r11
0000781a8ffcf992  lea r12, [rax+0x38]
0000781a8ffcf996  mov r11d, [r13+r12*1]
0000781a8ffcf99b  lea r12, [rax+0x24]
0000781a8ffcf99f  mov r10d, [r13+r12*1]
0000781a8ffcf9a4  mov [rsp+0x20], r10d
0000781a8ffcf9a9  mov r10d, r10d
0000781a8ffcf9ac  mov [r15+0x90], r10
0000781a8ffcf9b3  mov [rsp+0x30], rax
0000781a8ffcf9b8  xor eax, eax
0000781a8ffcf9ba  mov r12d, 0x04
0000781a8ffcf9c0  mov r10d, 0xC0
0000781a8ffcf9c6  cmp r12, r10
0000781a8ffcf9c9  cmc
0000781a8ffcf9ca  lahf
0000781a8ffcf9cb  seto al
0000781a8ffcf9ce  mov [r15+0x108], eax
0000781a8ffcf9d5  mov eax, [rsp+0x10]
0000781a8ffcf9d9  mov r12d, [rsp+0x10]
0000781a8ffcf9de  shrd eax, r12d, 0x07
0000781a8ffcf9e3  mov [rsp+0x10], r11d
0000781a8ffcf9e8  mov r10d, [rsp+0x10]
0000781a8ffcf9ed  shrd r11d, r10d, 0x11
0000781a8ffcf9f2  mov r9d, [rsp+0x20]
0000781a8ffcf9f7  lea r8d, [r9d+r14d*1]
0000781a8ffcf9fc  rorx r14d, r12d, 0x12
0000781a8ffcfa02  xor eax, r14d
0000781a8ffcfa05  rorx r14d, r10d, 0x13
0000781a8ffcfa0b  xor r11d, r14d
0000781a8ffcfa0e  mov [rsp+0x10], r11d
0000781a8ffcfa13  mov r11d, r11d
0000781a8ffcfa16  mov [r15+0x88], r11
0000781a8ffcfa1d  mov [rsp+0x20], r12d
0000781a8ffcfa22  shr r12d, 0x03
0000781a8ffcfa26  xor eax, r12d
0000781a8ffcfa29  mov [rsp+0x40], eax
0000781a8ffcfa2d  mov eax, eax
0000781a8ffcfa2f  mov [r15+0x80], rax
0000781a8ffcfa36  shr r10d, 0x0A
0000781a8ffcfa3a  mov eax, [rsp+0x10]
0000781a8ffcfa3e  xor eax, r10d
0000781a8ffcfa41  mov [rsp+0x10], eax
0000781a8ffcfa45  mov eax, eax
0000781a8ffcfa47  mov [r15+0x78], rax
0000781a8ffcfa4b  mov eax, [rsp+0x40]
0000781a8ffcfa4f  lea r14d, [r8d+eax*1]
0000781a8ffcfa54  mov eax, [rsp+0x10]
0000781a8ffcfa58  lea r12d, [r14d+eax*1]
0000781a8ffcfa5d  mov rax, [rsp+0x30]
0000781a8ffcfa62  lea r14, [rax+0x40]
0000781a8ffcfa66  mov [r13+r14*1], r12d
0000781a8ffcfa6b  mov eax, [rsp+0x20]
0000781a8ffcfa6f  mov eax, eax
0000781a8ffcfa71  mov [r15+0x60], rax
0000781a8ffcfa75  mov eax, [r15+0x108]
0000781a8ffcfa7c  sahf
0000781a8ffcfa7d  jnz 0x0000781A8FFCFAAF
0000781a8ffcfa7f  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcfa87  jz 0x0000781A8FFCFF70
0000781a8ffcfa8d  nop [rax+rax*1], ax
0000781a8ffcfa96  nop [rax+rax*1], eax
0000781a8ffcfa9e  mov eax, 0x410820
0000781a8ffcfaa3  mov [r15+0x100], rax
0000781a8ffcfaaa  jmp 0x0000781A8FDFE110
0000781a8ffcfaaf  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcfab7  jz 0x0000781A8FFCFDC0
0000781a8ffcfabd  nop [rax+rax*1], ax
0000781a8ffcfac6  nop [rax+rax*1], eax
0000781a8ffcface  mov eax, 0x4107D8
0000781a8ffcfad3  mov [r15+0x100], rax
0000781a8ffcfada  jmp 0x0000781A8FDFE110
0000781a8ffcfadf  int3
0000781a8ffcfae0  call 0x0000781A8FE0D860
0000781a8ffcfae5  jmp 0x0000781A8FFCF17A
0000781a8ffcfaea  call 0x0000781A8FEE2420
0000781a8ffcfaef  jmp 0x0000781A8FFCF193
0000781a8ffcfaf4  call 0x0000781A8FEE2420
0000781a8ffcfaf9  jmp 0x0000781A8FFCF1AC
0000781a8ffcfafe  call 0x0000781A8FEE2420
0000781a8ffcfb03  jmp 0x0000781A8FFCF1C5
0000781a8ffcfb08  call 0x0000781A8FEE2420
0000781a8ffcfb0d  jmp 0x0000781A8FFCF1DE
0000781a8ffcfb12  call 0x0000781A8FEE2420
0000781a8ffcfb17  jmp 0x0000781A8FFCF1EF
0000781a8ffcfb1c  call 0x0000781A8FEE2420
0000781a8ffcfb21  jmp 0x0000781A8FFCF200
0000781a8ffcfb26  call 0x0000781A8FEE2420
0000781a8ffcfb2b  jmp 0x0000781A8FFCF211
0000781a8ffcfb30  call 0x0000781A8FEE2420
0000781a8ffcfb35  jmp 0x0000781A8FFCF222
0000781a8ffcfb3a  call 0x0000781A8FEE2420
0000781a8ffcfb3f  jmp 0x0000781A8FFCF233
0000781a8ffcfb44  call 0x0000781A8FEE2420
0000781a8ffcfb49  jmp 0x0000781A8FFCF244
0000781a8ffcfb4e  call 0x0000781A8FEE2420
0000781a8ffcfb53  jmp 0x0000781A8FFCF255
0000781a8ffcfb58  call 0x0000781A8FEE2420
0000781a8ffcfb5d  jmp 0x0000781A8FFCF266
0000781a8ffcfb62  call 0x0000781A8FEE2420
0000781a8ffcfb67  jmp 0x0000781A8FFCF277
0000781a8ffcfb6c  call 0x0000781A8FEE2420
0000781a8ffcfb71  jmp 0x0000781A8FFCF288
0000781a8ffcfb76  call 0x0000781A8FEE2420
0000781a8ffcfb7b  jmp 0x0000781A8FFCF299
0000781a8ffcfb80  call 0x0000781A8FEE2420
0000781a8ffcfb85  jmp 0x0000781A8FFCF2AA
0000781a8ffcfb8a  call 0x0000781A8FEE2420
0000781a8ffcfb8f  jmp 0x0000781A8FFCF2BB
0000781a8ffcfb94  call 0x0000781A8FEE2420
0000781a8ffcfb99  jmp 0x0000781A8FFCF2CC
0000781a8ffcfb9e  call 0x0000781A8FEE2420
0000781a8ffcfba3  jmp 0x0000781A8FFCF2DD
0000781a8ffcfba8  call 0x0000781A8FEE2420
0000781a8ffcfbad  jmp 0x0000781A8FFCF2EE
0000781a8ffcfbb2  call 0x0000781A8FEE2420
0000781a8ffcfbb7  jmp 0x0000781A8FFCF2FF
0000781a8ffcfbbc  call 0x0000781A8FEE2420
0000781a8ffcfbc1  jmp 0x0000781A8FFCF310
0000781a8ffcfbc6  call 0x0000781A8FEE2420
0000781a8ffcfbcb  jmp 0x0000781A8FFCF321
0000781a8ffcfbd0  call 0x0000781A8FEE2420
0000781a8ffcfbd5  jmp 0x0000781A8FFCF332
0000781a8ffcfbda  call 0x0000781A8FEE2420
0000781a8ffcfbdf  jmp 0x0000781A8FFCF343
0000781a8ffcfbe4  call 0x0000781A8FEE2420
0000781a8ffcfbe9  jmp 0x0000781A8FFCF354
0000781a8ffcfbee  call 0x0000781A8FEE2420
0000781a8ffcfbf3  jmp 0x0000781A8FFCF365
0000781a8ffcfbf8  call 0x0000781A8FEE2420
0000781a8ffcfbfd  jmp 0x0000781A8FFCF376
0000781a8ffcfc02  call 0x0000781A8FEE2420
0000781a8ffcfc07  jmp 0x0000781A8FFCF387
0000781a8ffcfc0c  call 0x0000781A8FEE2420
0000781a8ffcfc11  jmp 0x0000781A8FFCF398
0000781a8ffcfc16  call 0x0000781A8FEE2420
0000781a8ffcfc1b  jmp 0x0000781A8FFCF3A9
0000781a8ffcfc20  call 0x0000781A8FEE2420
0000781a8ffcfc25  jmp 0x0000781A8FFCF3BA
0000781a8ffcfc2a  call 0x0000781A8FEE2420
0000781a8ffcfc2f  jmp 0x0000781A8FFCF3CB
0000781a8ffcfc34  call 0x0000781A8FEE2420
0000781a8ffcfc39  jmp 0x0000781A8FFCF3DC
0000781a8ffcfc3e  call 0x0000781A8FEE2420
0000781a8ffcfc43  jmp 0x0000781A8FFCF3ED
0000781a8ffcfc48  call 0x0000781A8FEE2420
0000781a8ffcfc4d  jmp 0x0000781A8FFCF3FE
0000781a8ffcfc52  call 0x0000781A8FEE2420
0000781a8ffcfc57  jmp 0x0000781A8FFCF40F
0000781a8ffcfc5c  call 0x0000781A8FEE2420
0000781a8ffcfc61  jmp 0x0000781A8FFCF420
0000781a8ffcfc66  call 0x0000781A8FEE2420
0000781a8ffcfc6b  jmp 0x0000781A8FFCF431
0000781a8ffcfc70  call 0x0000781A8FEE2420
0000781a8ffcfc75  jmp 0x0000781A8FFCF442
0000781a8ffcfc7a  call 0x0000781A8FEE2420
0000781a8ffcfc7f  jmp 0x0000781A8FFCF453
0000781a8ffcfc84  call 0x0000781A8FEE2420
0000781a8ffcfc89  jmp 0x0000781A8FFCF464
0000781a8ffcfc8e  call 0x0000781A8FEE2420
0000781a8ffcfc93  jmp 0x0000781A8FFCF475
0000781a8ffcfc98  call 0x0000781A8FEE2420
0000781a8ffcfc9d  jmp 0x0000781A8FFCF486
0000781a8ffcfca2  call 0x0000781A8FEE2420
0000781a8ffcfca7  jmp 0x0000781A8FFCF497
0000781a8ffcfcac  call 0x0000781A8FEE2420
0000781a8ffcfcb1  jmp 0x0000781A8FFCF4A8
0000781a8ffcfcb6  call 0x0000781A8FEE2420
0000781a8ffcfcbb  jmp 0x0000781A8FFCF4B9
0000781a8ffcfcc0  call 0x0000781A8FEE2420
0000781a8ffcfcc5  jmp 0x0000781A8FFCF4CA
0000781a8ffcfcca  call 0x0000781A8FEE2420
0000781a8ffcfccf  jmp 0x0000781A8FFCF4DB
0000781a8ffcfcd4  call 0x0000781A8FEE2420
0000781a8ffcfcd9  jmp 0x0000781A8FFCF4EC
0000781a8ffcfcde  call 0x0000781A8FEE2420
0000781a8ffcfce3  jmp 0x0000781A8FFCF4FD
0000781a8ffcfce8  call 0x0000781A8FEE2420
0000781a8ffcfced  jmp 0x0000781A8FFCF50E
0000781a8ffcfcf2  call 0x0000781A8FEE2420
0000781a8ffcfcf7  jmp 0x0000781A8FFCF51F
0000781a8ffcfcfc  call 0x0000781A8FEE2420
0000781a8ffcfd01  jmp 0x0000781A8FFCF530
0000781a8ffcfd06  call 0x0000781A8FEE2420
0000781a8ffcfd0b  jmp 0x0000781A8FFCF541
0000781a8ffcfd10  call 0x0000781A8FEE2420
0000781a8ffcfd15  jmp 0x0000781A8FFCF552
0000781a8ffcfd1a  call 0x0000781A8FEE2420
0000781a8ffcfd1f  jmp 0x0000781A8FFCF563
0000781a8ffcfd24  call 0x0000781A8FEE2420
0000781a8ffcfd29  jmp 0x0000781A8FFCF574
0000781a8ffcfd2e  call 0x0000781A8FEE2420
0000781a8ffcfd33  jmp 0x0000781A8FFCF585
0000781a8ffcfd38  call 0x0000781A8FEE2420
0000781a8ffcfd3d  jmp 0x0000781A8FFCF596
0000781a8ffcfd42  call 0x0000781A8FEE2420
0000781a8ffcfd47  jmp 0x0000781A8FFCF5AF
0000781a8ffcfd4c  call 0x0000781A8FEE2420
0000781a8ffcfd51  jmp 0x0000781A8FFCF5C8
0000781a8ffcfd56  call 0x0000781A8FED5610
0000781a8ffcfd5b  jmp 0x0000781A8FFCF5E1
0000781a8ffcfd60  call 0x0000781A8FEDC580
0000781a8ffcfd65  jmp 0x0000781A8FFCF94E
0000781a8ffcfd6a  call 0x0000781A8FEE46C0
0000781a8ffcfd6f  jmp 0x0000781A8FFCF958
0000781a8ffcfd74  call 0x0000781A8FE09E90
0000781a8ffcfd79  jmp 0x0000781A8FFCF95E
0000781a8ffcfd7e  call 0x0000781A8FEDB310
0000781a8ffcfd83  jmp 0x0000781A8FFCF968
0000781a8ffcfd88  call 0x0000781A8FE0DAE0
0000781a8ffcfd8d  jmp 0x0000781A8FFCF96D
0000781a8ffcfd92  call 0x0000781A8FEC0230
0000781a8ffcfd97  jmp 0x0000781A8FFCF986
0000781a8ffcfd9c  call 0x0000781A8FEC0230
0000781a8ffcfda1  jmp 0x0000781A8FFCF99B
0000781a8ffcfda6  call 0x0000781A8FEBEFC0
0000781a8ffcfdab  jmp 0x0000781A8FFCF9A4
0000781a8ffcfdb0  call 0x0000781A8FEE2BA0
0000781a8ffcfdb5  jmp 0x0000781A8FFCFA6B
0000781a8ffcfdba  int3
0000781a8ffcfdbb  nop [rax+rax*1], eax
0000781a8ffcfdc0  mov rax, [r15+0x48]
0000781a8ffcfdc4  mov r14, [r15+0x58]
0000781a8ffcfdc8  lea r12, [rax+r14*1]
0000781a8ffcfdcc  mov [r15+0x68], r12
0000781a8ffcfdd0  lea rax, [r14+0x04]
0000781a8ffcfdd4  mov [r15+0x58], rax
0000781a8ffcfdd8  lea r14, [r12+0x04]
0000781a8ffcfddd  mov r11d, [r13+r14*1]
0000781a8ffcfde2  mov [rsp+0x10], r11d
0000781a8ffcfde7  mov r11d, r11d
0000781a8ffcfdea  mov [r15+0x70], r11
0000781a8ffcfdee  lea r14, [r12+0x38]
0000781a8ffcfdf3  mov r11d, [r13+r14*1]
0000781a8ffcfdf8  lea r14, [r12+0x24]
0000781a8ffcfdfd  mov r10d, [r13+r14*1]
0000781a8ffcfe02  mov [rsp+0x20], r10d
0000781a8ffcfe07  mov r10d, r10d
0000781a8ffcfe0a  mov [r15+0x90], r10
0000781a8ffcfe11  mov [rsp+0x30], rax
0000781a8ffcfe16  xor eax, eax
0000781a8ffcfe18  mov r14, [rsp+0x30]
0000781a8ffcfe1d  mov r10d, 0xC0
0000781a8ffcfe23  cmp r14, r10
0000781a8ffcfe26  cmc
0000781a8ffcfe27  lahf
0000781a8ffcfe28  seto al
0000781a8ffcfe2b  mov [r15+0x108], eax
0000781a8ffcfe32  mov eax, [rsp+0x10]
0000781a8ffcfe36  mov r14d, [rsp+0x10]
0000781a8ffcfe3b  shrd eax, r14d, 0x07
0000781a8ffcfe40  mov [rsp+0x10], r11d
0000781a8ffcfe45  mov r10d, [rsp+0x10]
0000781a8ffcfe4a  shrd r11d, r10d, 0x11
0000781a8ffcfe4f  mov r9d, [r15+0x60]
0000781a8ffcfe53  mov r8d, [rsp+0x20]
0000781a8ffcfe58  lea ebp, [r8d+r9d*1]
0000781a8ffcfe5d  rorx r9d, r14d, 0x12
0000781a8ffcfe63  xor eax, r9d
0000781a8ffcfe66  rorx r9d, r10d, 0x13
0000781a8ffcfe6c  xor r11d, r9d
0000781a8ffcfe6f  mov [rsp+0x10], r11d
0000781a8ffcfe74  mov r11d, r11d
0000781a8ffcfe77  mov [r15+0x88], r11
0000781a8ffcfe7e  mov [rsp+0x20], r14d
0000781a8ffcfe83  shr r14d, 0x03
0000781a8ffcfe87  xor eax, r14d
0000781a8ffcfe8a  mov [rsp+0x30], eax
0000781a8ffcfe8e  mov eax, eax
0000781a8ffcfe90  mov [r15+0x80], rax
0000781a8ffcfe97  shr r10d, 0x0A
0000781a8ffcfe9b  mov eax, [rsp+0x10]
0000781a8ffcfe9f  xor eax, r10d
0000781a8ffcfea2  mov [rsp+0x10], eax
0000781a8ffcfea6  mov eax, eax
0000781a8ffcfea8  mov [r15+0x78], rax
0000781a8ffcfeac  mov eax, [rsp+0x30]
0000781a8ffcfeb0  lea r14d, [ebp+eax*1]
0000781a8ffcfeb6  mov eax, [rsp+0x10]
0000781a8ffcfeba  lea r11d, [r14d+eax*1]
0000781a8ffcfebf  lea rax, [r12+0x40]
0000781a8ffcfec4  mov [r13+rax*1], r11d
0000781a8ffcfec9  mov eax, [rsp+0x20]
0000781a8ffcfecd  mov eax, eax
0000781a8ffcfecf  mov [r15+0x60], rax
0000781a8ffcfed3  mov eax, [r15+0x108]
0000781a8ffcfeda  sahf
0000781a8ffcfedb  jnz 0x0000781A8FFCFF0D
0000781a8ffcfedd  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcfee5  jz 0x0000781A8FFCFF70
0000781a8ffcfeeb  nop [rax+rax*1], ax
0000781a8ffcfef4  nop [rax+rax*1], eax
0000781a8ffcfefc  mov eax, 0x410820
0000781a8ffcff01  mov [r15+0x100], rax
0000781a8ffcff08  jmp 0x0000781A8FDFE110
0000781a8ffcff0d  cmp dword ptr [r15+0x318], 0x00
0000781a8ffcff15  jz 0x0000781A8FFCFDC0
0000781a8ffcff1b  nop [rax+rax*1], ax
0000781a8ffcff24  nop [rax+rax*1], eax
0000781a8ffcff2c  mov eax, 0x4107D8
0000781a8ffcff31  mov [r15+0x100], rax
0000781a8ffcff38  jmp 0x0000781A8FDFE110
0000781a8ffcff3d  int3
0000781a8ffcff3e  call 0x0000781A8FEE1430
0000781a8ffcff43  jmp 0x0000781A8FFCFDE2
0000781a8ffcff48  call 0x0000781A8FEE1430
0000781a8ffcff4d  jmp 0x0000781A8FFCFDF8
0000781a8ffcff52  call 0x0000781A8FEE01C0
0000781a8ffcff57  jmp 0x0000781A8FFCFE02
0000781a8ffcff5c  call 0x0000781A8FE0A860
0000781a8ffcff61  jmp 0x0000781A8FFCFEC9
0000781a8ffcff66  int3
0000781a8ffcff67  nop [rax+rax*1], ax
0000781a8ffcff70  mov rax, [r15]
0000781a8ffcff73  mov r14d, [r13+rax*1]
0000781a8ffcff78  lea r12, [rax+0x04]
0000781a8ffcff7c  mov r11d, [r13+r12*1]
0000781a8ffcff81  mov [rsp+0x10], r14d
0000781a8ffcff86  mov r14d, r14d
0000781a8ffcff89  mov [r15+0x78], r14
0000781a8ffcff8d  mov [rsp+0x20], r11d
0000781a8ffcff92  mov r11d, r11d
0000781a8ffcff95  mov [r15+0x80], r11
0000781a8ffcff9c  lea r14, [rax+0x08]
0000781a8ffcffa0  mov r12d, [r13+r14*1]
0000781a8ffcffa5  lea r14, [rax+0x0C]
0000781a8ffcffa9  mov r11d, [r13+r14*1]
0000781a8ffcffae  mov [rsp+0x30], r12d
0000781a8ffcffb3  mov r12d, r12d
0000781a8ffcffb6  mov [r15+0x70], r12
0000781a8ffcffba  mov [rsp+0x40], r11d
0000781a8ffcffbf  mov r11d, r11d
0000781a8ffcffc2  mov [r15+0x68], r11
0000781a8ffcffc6  lea r14, [rax+0x18]
0000781a8ffcffca  mov r12d, [r13+r14*1]
0000781a8ffcffcf  lea r14, [rax+0x1C]
0000781a8ffcffd3  mov r11d, [r13+r14*1]
0000781a8ffcffd8  mov [rsp+0x50], r12d
0000781a8ffcffdd  mov r12d, r12d
0000781a8ffcffe0  mov [r15+0x58], r12
0000781a8ffcffe4  mov [rsp+0x60], r11d
0000781a8ffcffe9  mov r11d, r11d
0000781a8ffcffec  mov [r15+0x60], r11
0000781a8ffcfff0  lea r14, [rax+0x10]
0000781a8ffcfff4  mov r12d, [r13+r14*1]
0000781a8ffcfff9  lea r14, [rax+0x14]
0000781a8ffcfffd  mov eax, [r13+r14*1]
0000781a8ffd0002  mov [rsp+0x70], r12d
0000781a8ffd0007  mov r12d, r12d
0000781a8ffd000a  mov [r15+0x18], r12
0000781a8ffd000e  mov [rsp+0x80], eax
0000781a8ffd0015  mov eax, eax
0000781a8ffd0017  mov [r15+0x90], rax
0000781a8ffd001e  mov eax, [rsp+0x70]
0000781a8ffd0022  mov eax, eax
0000781a8ffd0024  mov [r15+0x30], rax
0000781a8ffd0028  mov eax, [rsp+0x50]
0000781a8ffd002c  mov eax, eax
0000781a8ffd002e  mov [r15+0xA0], rax
0000781a8ffd0035  mov eax, [rsp+0x30]
0000781a8ffd0039  mov eax, eax
0000781a8ffd003b  mov [r15+0x28], rax
0000781a8ffd003f  mov eax, [rsp+0x20]
0000781a8ffd0043  mov eax, eax
0000781a8ffd0045  mov [r15+0x98], rax
0000781a8ffd004c  mov eax, [rsp+0x10]
0000781a8ffd0050  mov eax, eax
0000781a8ffd0052  mov [r15+0x38], rax
0000781a8ffd0056  mov eax, [rsp+0x70]
0000781a8ffd005a  mov r14d, [rsp+0x70]
0000781a8ffd005f  shrd eax, r14d, 0x06
0000781a8ffd0064  mov [rsp+0x70], r14d
0000781a8ffd0069  mov r12d, [rsp+0x80]
0000781a8ffd0071  and r14d, r12d
0000781a8ffd0074  mov r11d, [rsp+0x10]
0000781a8ffd0079  mov r10d, [rsp+0x10]
0000781a8ffd007e  shrd r11d, r10d, 0x02
0000781a8ffd0083  mov [rsp+0x10], r12d
0000781a8ffd0088  mov r12d, r12d
0000781a8ffd008b  mov [r15+0x20], r12
0000781a8ffd008f  mov r12, [r15+0x50]
0000781a8ffd0093  mov r9d, [r13+r12*1]
0000781a8ffd0098  mov r12d, [rsp+0x50]
0000781a8ffd009d  mov r8d, [rsp+0x70]
0000781a8ffd00a2  andn ebp, r8d, r12d
0000781a8ffd00a7  mov edi, [rsp+0x60]
0000781a8ffd00ab  lea esi, [r14d+edi*1]
0000781a8ffd00b0  rorx r14d, r8d, 0x0B
0000781a8ffd00b6  xor eax, r14d
0000781a8ffd00b9  rorx r14d, r10d, 0x0D
0000781a8ffd00bf  xor r11d, r14d
0000781a8ffd00c2  lea edi, [esi+ebp*1]
0000781a8ffd00c6  mov r14, [r15+0x48]
0000781a8ffd00ca  mov ebp, [r13+r14*1]
0000781a8ffd00cf  mov r14d, [rsp+0x30]
0000781a8ffd00d4  mov esi, [rsp+0x20]
0000781a8ffd00d8  and r14d, esi
0000781a8ffd00db  mov [rsp+0x20], r14d
0000781a8ffd00e0  mov r14d, r14d
0000781a8ffd00e3  mov [r15+0xD8], r14
0000781a8ffd00ea  lea r14d, [edi+r9d*1]
0000781a8ffd00ef  mov r9d, [rsp+0x30]
0000781a8ffd00f4  xor r9d, esi
0000781a8ffd00f7  rorx edi, r8d, 0x19
0000781a8ffd00fd  xor eax, edi
0000781a8ffd00ff  and r9d, r10d
0000781a8ffd0102  rorx edi, r10d, 0x16
0000781a8ffd0108  xor r11d, edi
0000781a8ffd010b  mov [rsp+0x30], r11d
0000781a8ffd0110  mov r11d, r11d
0000781a8ffd0113  mov [r15+0xD0], r11
0000781a8ffd011a  lea r11d, [r14d+ebp*1]
0000781a8ffd011f  mov r10d, [rsp+0x20]
0000781a8ffd0124  xor r9d, r10d
0000781a8ffd0127  lea r14d, [r11d+eax*1]
0000781a8ffd012c  mov qword ptr [r15+0x88], 0x04
0000781a8ffd0137  mov eax, [rsp+0x30]
0000781a8ffd013b  lea r11d, [r9d+eax*1]
0000781a8ffd0140  mov eax, [rsp+0x40]
0000781a8ffd0144  lea r10d, [r14d+eax*1]
0000781a8ffd0149  mov r10d, r10d
0000781a8ffd014c  mov [r15+0xB8], r10
0000781a8ffd0153  xor eax, eax
0000781a8ffd0155  mov r10d, 0x04
0000781a8ffd015b  mov r9d, 0x100
0000781a8ffd0161  cmp r10, r9
0000781a8ffd0164  cmc
0000781a8ffd0165  lahf
0000781a8ffd0166  seto al
0000781a8ffd0169  mov [r15+0x108], eax
0000781a8ffd0170  lea eax, [r11d+r14d*1]
0000781a8ffd0175  mov eax, eax
0000781a8ffd0177  mov [r15+0xA8], rax
0000781a8ffd017e  mov r12d, r12d
0000781a8ffd0181  mov [r15+0xB0], r12
0000781a8ffd0188  mov eax, [rsp+0x10]
0000781a8ffd018c  mov eax, eax
0000781a8ffd018e  mov [r15+0xC0], rax
0000781a8ffd0195  mov r8d, r8d
0000781a8ffd0198  mov [r15+0xC8], r8
0000781a8ffd019f  mov eax, [r15+0x108]
0000781a8ffd01a6  sahf
0000781a8ffd01a7  jnz 0x0000781A8FFD01D9
0000781a8ffd01a9  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd01b1  jz 0x0000781A8FFD04A0
0000781a8ffd01b7  nop [rax+rax*1], ax
0000781a8ffd01c0  nop [rax+rax*1], eax
0000781a8ffd01c8  mov eax, 0x4108E0
0000781a8ffd01cd  mov [r15+0x100], rax
0000781a8ffd01d4  jmp 0x0000781A8FDFE110
0000781a8ffd01d9  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd01e1  jz 0x0000781A8FFD0270
0000781a8ffd01e7  nop [rax+rax*1], ax
0000781a8ffd01f0  nop [rax+rax*1], eax
0000781a8ffd01f8  mov eax, 0x410854
0000781a8ffd01fd  mov [r15+0x100], rax
0000781a8ffd0204  jmp 0x0000781A8FDFE110
0000781a8ffd0209  int3
0000781a8ffd020a  call 0x0000781A8FE0DAE0
0000781a8ffd020f  jmp 0x0000781A8FFCFF78
0000781a8ffd0214  call 0x0000781A8FEC0230
0000781a8ffd0219  jmp 0x0000781A8FFCFF81
0000781a8ffd021e  call 0x0000781A8FEE26A0
0000781a8ffd0223  jmp 0x0000781A8FFCFFA5
0000781a8ffd0228  call 0x0000781A8FEE1430
0000781a8ffd022d  jmp 0x0000781A8FFCFFAE
0000781a8ffd0232  call 0x0000781A8FEE26A0
0000781a8ffd0237  jmp 0x0000781A8FFCFFCF
0000781a8ffd023c  call 0x0000781A8FEE1430
0000781a8ffd0241  jmp 0x0000781A8FFCFFD8
0000781a8ffd0246  call 0x0000781A8FEE26A0
0000781a8ffd024b  jmp 0x0000781A8FFCFFF9
0000781a8ffd0250  call 0x0000781A8FED5890
0000781a8ffd0255  jmp 0x0000781A8FFD0002
0000781a8ffd025a  call 0x0000781A8FEBDD50
0000781a8ffd025f  jmp 0x0000781A8FFD0098
0000781a8ffd0264  call 0x0000781A8FEDA580
0000781a8ffd0269  jmp 0x0000781A8FFD00CF
0000781a8ffd026e  int3
0000781a8ffd026f  nop
0000781a8ffd0270  mov eax, [r15+0xB8]
0000781a8ffd0277  mov [rsp+0x10], eax
0000781a8ffd027b  mov eax, eax
0000781a8ffd027d  mov [r15+0x30], rax
0000781a8ffd0281  mov eax, [r15+0xC0]
0000781a8ffd0288  mov [rsp+0x20], eax
0000781a8ffd028c  mov eax, eax
0000781a8ffd028e  mov [r15+0xA0], rax
0000781a8ffd0295  mov eax, [r15+0x28]
0000781a8ffd0299  mov r14d, [r15+0x98]
0000781a8ffd02a0  mov [rsp+0x30], r14d
0000781a8ffd02a5  mov r14d, r14d
0000781a8ffd02a8  mov [r15+0x28], r14
0000781a8ffd02ac  mov r14d, [r15+0x38]
0000781a8ffd02b0  mov [rsp+0x40], r14d
0000781a8ffd02b5  mov r14d, r14d
0000781a8ffd02b8  mov [r15+0x98], r14
0000781a8ffd02bf  mov r14d, [r15+0xA8]
0000781a8ffd02c6  mov [rsp+0x50], r14d
0000781a8ffd02cb  mov r14d, r14d
0000781a8ffd02ce  mov [r15+0x38], r14
0000781a8ffd02d2  mov r14d, [rsp+0x10]
0000781a8ffd02d7  mov r12d, [rsp+0x10]
0000781a8ffd02dc  shrd r14d, r12d, 0x06
0000781a8ffd02e1  mov r11d, [r15+0xC8]
0000781a8ffd02e8  mov [rsp+0x10], r12d
0000781a8ffd02ed  and r12d, r11d
0000781a8ffd02f0  mov r10d, [rsp+0x50]
0000781a8ffd02f5  mov r9d, [rsp+0x50]
0000781a8ffd02fa  shrd r10d, r9d, 0x02
0000781a8ffd02ff  mov [rsp+0x50], r11d
0000781a8ffd0304  mov r11d, r11d
0000781a8ffd0307  mov [r15+0x20], r11
0000781a8ffd030b  mov r11, [r15+0x88]
0000781a8ffd0312  mov r8, [r15+0x50]
0000781a8ffd0316  lea rbp, [r8+r11*1]
0000781a8ffd031a  mov r8d, [r13+rbp*1]
0000781a8ffd031f  mov ebp, [rsp+0x20]
0000781a8ffd0323  mov edi, [rsp+0x10]
0000781a8ffd0327  andn esi, edi, ebp
0000781a8ffd032c  mov edx, [r15+0xB0]
0000781a8ffd0333  lea ecx, [r12d+edx*1]
0000781a8ffd0338  rorx r12d, edi, 0x0B
0000781a8ffd033e  xor r14d, r12d
0000781a8ffd0341  rorx r12d, r9d, 0x0D
0000781a8ffd0347  xor r10d, r12d
0000781a8ffd034a  lea r12d, [ecx+esi*1]
0000781a8ffd034f  mov rsi, [r15+0x48]
0000781a8ffd0353  lea rdx, [rsi+r11*1]
0000781a8ffd0357  mov esi, [r13+rdx*1]
0000781a8ffd035c  mov edx, [rsp+0x30]
0000781a8ffd0360  mov ecx, [rsp+0x40]
0000781a8ffd0364  and edx, ecx
0000781a8ffd0366  mov [rsp+0x10], edx
0000781a8ffd036a  mov edx, edx
0000781a8ffd036c  mov [r15+0xD8], rdx
0000781a8ffd0373  lea edx, [r12d+r8d*1]
0000781a8ffd0378  mov r12d, [rsp+0x30]
0000781a8ffd037d  xor r12d, ecx
0000781a8ffd0380  rorx r8d, edi, 0x19
0000781a8ffd0386  xor r14d, r8d
0000781a8ffd0389  and r12d, r9d
0000781a8ffd038c  rorx r8d, r9d, 0x16
0000781a8ffd0392  xor r10d, r8d
0000781a8ffd0395  mov [rsp+0x20], r10d
0000781a8ffd039a  mov r10d, r10d
0000781a8ffd039d  mov [r15+0xD0], r10
0000781a8ffd03a4  lea r10d, [edx+esi*1]
0000781a8ffd03a9  mov r9d, [rsp+0x10]
0000781a8ffd03ae  xor r12d, r9d
0000781a8ffd03b1  lea r9d, [r10d+r14d*1]
0000781a8ffd03b6  lea r14, [r11+0x04]
0000781a8ffd03ba  mov [r15+0x88], r14
0000781a8ffd03c1  mov r11d, [rsp+0x20]
0000781a8ffd03c6  lea r10d, [r12d+r11d*1]
0000781a8ffd03cb  lea r11d, [r9d+eax*1]
0000781a8ffd03d0  mov r11d, r11d
0000781a8ffd03d3  mov [r15+0xB8], r11
0000781a8ffd03da  xor eax, eax
0000781a8ffd03dc  mov r12d, 0x100
0000781a8ffd03e2  cmp r14, r12
0000781a8ffd03e5  cmc
0000781a8ffd03e6  lahf
0000781a8ffd03e7  seto al
0000781a8ffd03ea  mov [r15+0x108], eax
0000781a8ffd03f1  lea eax, [r10d+r9d*1]
0000781a8ffd03f6  mov eax, eax
0000781a8ffd03f8  mov [r15+0xA8], rax
0000781a8ffd03ff  mov ebp, ebp
0000781a8ffd0401  mov [r15+0xB0], rbp
0000781a8ffd0408  mov eax, [rsp+0x50]
0000781a8ffd040c  mov eax, eax
0000781a8ffd040e  mov [r15+0xC0], rax
0000781a8ffd0415  mov edi, edi
0000781a8ffd0417  mov [r15+0xC8], rdi
0000781a8ffd041e  mov eax, [r15+0x108]
0000781a8ffd0425  sahf
0000781a8ffd0426  jnz 0x0000781A8FFD0458
0000781a8ffd0428  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0430  jz 0x0000781A8FFD04A0
0000781a8ffd0436  nop [rax+rax*1], ax
0000781a8ffd043f  nop [rax+rax*1], eax
0000781a8ffd0447  mov eax, 0x4108E0
0000781a8ffd044c  mov [r15+0x100], rax
0000781a8ffd0453  jmp 0x0000781A8FDFE110
0000781a8ffd0458  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0460  jz 0x0000781A8FFD0270
0000781a8ffd0466  nop [rax+rax*1], ax
0000781a8ffd046f  nop [rax+rax*1], eax
0000781a8ffd0477  mov eax, 0x410854
0000781a8ffd047c  mov [r15+0x100], rax
0000781a8ffd0483  jmp 0x0000781A8FDFE110
0000781a8ffd0488  int3
0000781a8ffd0489  call 0x0000781A8FE49010
0000781a8ffd048e  jmp 0x0000781A8FFD031F
0000781a8ffd0493  call 0x0000781A8FE25930
0000781a8ffd0498  jmp 0x0000781A8FFD035C
0000781a8ffd049d  int3
0000781a8ffd049e  nop
0000781a8ffd04a0  mov eax, [r15+0x98]
0000781a8ffd04a7  mov r14d, [r15+0x70]
0000781a8ffd04ab  lea r12d, [eax+r14d*1]
0000781a8ffd04b0  mov eax, [r15+0x28]
0000781a8ffd04b4  mov r14d, [r15+0x68]
0000781a8ffd04b8  lea r11d, [eax+r14d*1]
0000781a8ffd04bd  mov qword ptr [r15+0x88], 0x00
0000781a8ffd04c8  mov eax, [r15+0xA8]
0000781a8ffd04cf  mov r14d, [r15+0x78]
0000781a8ffd04d3  lea r10d, [eax+r14d*1]
0000781a8ffd04d8  mov [rsp+0x10], r10d
0000781a8ffd04dd  mov r10d, r10d
0000781a8ffd04e0  mov [r15+0x78], r10
0000781a8ffd04e4  mov eax, [r15+0x38]
0000781a8ffd04e8  mov r14d, [r15+0x80]
0000781a8ffd04ef  lea r10d, [eax+r14d*1]
0000781a8ffd04f4  mov [rsp+0x20], r10d
0000781a8ffd04f9  mov r10d, r10d
0000781a8ffd04fc  mov [r15+0x80], r10
0000781a8ffd0503  mov rax, [r15]
0000781a8ffd0506  lea r14, [rax+0x08]
0000781a8ffd050a  mov [r13+r14*1], r12d
0000781a8ffd050f  lea r14, [rax+0x0C]
0000781a8ffd0513  mov [r13+r14*1], r11d
0000781a8ffd0518  mov r14d, [r15+0xB8]
0000781a8ffd051f  mov r12d, [r15+0x18]
0000781a8ffd0523  lea r11d, [r14d+r12d*1]
0000781a8ffd0528  mov [rsp+0x30], r11d
0000781a8ffd052d  mov r11d, r11d
0000781a8ffd0530  mov [r15+0x68], r11
0000781a8ffd0534  mov r14d, [r15+0x30]
0000781a8ffd0538  mov r12d, [r15+0x90]
0000781a8ffd053f  lea r11d, [r14d+r12d*1]
0000781a8ffd0544  mov [rsp+0x40], r11d
0000781a8ffd0549  mov r11d, r11d
0000781a8ffd054c  mov [r15+0x70], r11
0000781a8ffd0550  mov r14d, [r15+0x20]
0000781a8ffd0554  mov r12d, [r15+0x58]
0000781a8ffd0558  lea r11d, [r14d+r12d*1]
0000781a8ffd055d  mov [rsp+0x50], r11d
0000781a8ffd0562  mov r11d, r11d
0000781a8ffd0565  mov [r15+0x58], r11
0000781a8ffd0569  mov r14d, [r15+0xA0]
0000781a8ffd0570  mov r12d, [r15+0x60]
0000781a8ffd0574  lea r11d, [r14d+r12d*1]
0000781a8ffd0579  mov [rsp+0x60], r11d
0000781a8ffd057e  mov r11d, r11d
0000781a8ffd0581  mov [r15+0x60], r11
0000781a8ffd0585  mov r14d, [rsp+0x10]
0000781a8ffd058a  mov [r13+rax*1], r14d
0000781a8ffd058f  lea r14, [rax+0x04]
0000781a8ffd0593  mov r12d, [rsp+0x20]
0000781a8ffd0598  mov [r13+r14*1], r12d
0000781a8ffd059d  lea r14, [rax+0x10]
0000781a8ffd05a1  mov r12d, [rsp+0x30]
0000781a8ffd05a6  mov [r13+r14*1], r12d
0000781a8ffd05ab  lea r14, [rax+0x14]
0000781a8ffd05af  mov r12d, [rsp+0x40]
0000781a8ffd05b4  mov [r13+r14*1], r12d
0000781a8ffd05b9  lea r14, [rax+0x18]
0000781a8ffd05bd  mov r12d, [rsp+0x50]
0000781a8ffd05c2  mov [r13+r14*1], r12d
0000781a8ffd05c7  lea r14, [rax+0x1C]
0000781a8ffd05cb  mov r12d, [rsp+0x60]
0000781a8ffd05d0  mov [r13+r14*1], r12d
0000781a8ffd05d5  lea r14, [rax+0x68]
0000781a8ffd05d9  xor eax, eax
0000781a8ffd05db  mov [r13+r14*1], rax
0000781a8ffd05e0  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd05e8  jz 0x0000781A8FFCF0E0
0000781a8ffd05ee  nop [rax+rax*1], ax
0000781a8ffd05f7  nop [rax+rax*1], eax
0000781a8ffd05ff  mov eax, 0x4106FC
0000781a8ffd0604  mov [r15+0x100], rax
0000781a8ffd060b  jmp 0x0000781A8FDFE110
0000781a8ffd0610  int3
0000781a8ffd0611  call 0x0000781A8FEE2BA0
0000781a8ffd0616  jmp 0x0000781A8FFD050F
0000781a8ffd061b  call 0x0000781A8FEE1920
0000781a8ffd0620  jmp 0x0000781A8FFD0518
0000781a8ffd0625  call 0x0000781A8FE0DFE0
0000781a8ffd062a  jmp 0x0000781A8FFD058F
0000781a8ffd062f  call 0x0000781A8FEE2BA0
0000781a8ffd0634  jmp 0x0000781A8FFD059D
0000781a8ffd0639  call 0x0000781A8FEE2BA0
0000781a8ffd063e  jmp 0x0000781A8FFD05AB
0000781a8ffd0643  call 0x0000781A8FEE2BA0
0000781a8ffd0648  jmp 0x0000781A8FFD05B9
0000781a8ffd064d  call 0x0000781A8FEE2BA0
0000781a8ffd0652  jmp 0x0000781A8FFD05C7
0000781a8ffd0657  call 0x0000781A8FEE2BA0
0000781a8ffd065c  jmp 0x0000781A8FFD05D5
0000781a8ffd0661  call 0x0000781A8FED5EB0
0000781a8ffd0666  jmp 0x0000781A8FFD05E0
0000781a8ffd066b  int3
0000781a8ffd066c  nop [rax], eax
0000781a8ffd0670  mov rax, [r15+0xF8]
0000781a8ffd0677  lea r14, [rax+0x140]
0000781a8ffd067e  mov r12, [r13+r14*1]
0000781a8ffd0683  lea r14, [rax+0x148]
0000781a8ffd068a  mov r11, [r13+r14*1]
0000781a8ffd068f  mov [r15+0xA0], r12
0000781a8ffd0696  mov [r15+0x98], r11
0000781a8ffd069d  lea r14, [rax+0x130]
0000781a8ffd06a4  mov r12, [r13+r14*1]
0000781a8ffd06a9  lea r14, [rax+0x138]
0000781a8ffd06b0  mov r11, [r13+r14*1]
0000781a8ffd06b5  mov [r15+0xB0], r12
0000781a8ffd06bc  mov [r15+0xA8], r11
0000781a8ffd06c3  lea r14, [rax+0x120]
0000781a8ffd06ca  mov r12, [r13+r14*1]
0000781a8ffd06cf  lea r14, [rax+0x128]
0000781a8ffd06d6  mov r11, [r13+r14*1]
0000781a8ffd06db  mov [r15+0xC0], r12
0000781a8ffd06e2  mov [r15+0xB8], r11
0000781a8ffd06e9  lea r14, [rax+0x110]
0000781a8ffd06f0  mov r12, [r13+r14*1]
0000781a8ffd06f5  lea r14, [rax+0x118]
0000781a8ffd06fc  mov r11, [r13+r14*1]
0000781a8ffd0701  mov [r15+0xD0], r12
0000781a8ffd0708  mov [r15+0xC8], r11
0000781a8ffd070f  lea r14, [rax+0x100]
0000781a8ffd0716  mov r12, [r13+r14*1]
0000781a8ffd071b  lea r14, [rax+0x108]
0000781a8ffd0722  mov r11, [r13+r14*1]
0000781a8ffd0727  mov [r15+0xE8], r12
0000781a8ffd072e  mov [r15+0xD8], r11
0000781a8ffd0735  lea r14, [rax+0x150]
0000781a8ffd073c  mov [r15+0xF8], r14
0000781a8ffd0743  mov rax, [r15+0xF0]
0000781a8ffd074a  mov [r15+0x100], rax
0000781a8ffd0751  jmp 0x0000781A8FFCE5C0
0000781a8ffd0756  int3
0000781a8ffd0757  call 0x0000781A8FEE27E0
0000781a8ffd075c  jmp 0x0000781A8FFD0683
0000781a8ffd0761  call 0x0000781A8FEE1570
0000781a8ffd0766  jmp 0x0000781A8FFD068F
0000781a8ffd076b  call 0x0000781A8FEE27E0
0000781a8ffd0770  jmp 0x0000781A8FFD06A9
0000781a8ffd0775  call 0x0000781A8FEE1570
0000781a8ffd077a  jmp 0x0000781A8FFD06B5
0000781a8ffd077f  call 0x0000781A8FEE27E0
0000781a8ffd0784  jmp 0x0000781A8FFD06CF
0000781a8ffd0789  call 0x0000781A8FEE1570
0000781a8ffd078e  jmp 0x0000781A8FFD06DB
0000781a8ffd0793  call 0x0000781A8FEE27E0
0000781a8ffd0798  jmp 0x0000781A8FFD06F5
0000781a8ffd079d  call 0x0000781A8FEE1570
0000781a8ffd07a2  jmp 0x0000781A8FFD0701
0000781a8ffd07a7  call 0x0000781A8FEE27E0
0000781a8ffd07ac  jmp 0x0000781A8FFD071B
0000781a8ffd07b1  call 0x0000781A8FEE1570
0000781a8ffd07b6  jmp 0x0000781A8FFD0727
0000781a8ffd07bb  int3
0000781a8ffd07bc  nop [rax], eax
0000781a8ffd07c0  mov eax, [r15+0xA0]
0000781a8ffd07c7  mov [rsp+0x10], eax
0000781a8ffd07cb  xor eax, eax
0000781a8ffd07cd  mov r14d, [rsp+0x10]
0000781a8ffd07d2  sub r14d, 0x01
0000781a8ffd07d6  cmc
0000781a8ffd07d7  lahf
0000781a8ffd07d8  seto al
0000781a8ffd07db  mov [r15+0x108], eax
0000781a8ffd07e2  mov r14d, r14d
0000781a8ffd07e5  mov [r15+0xA0], r14
0000781a8ffd07ec  mov eax, [r15+0x108]
0000781a8ffd07f3  sahf
0000781a8ffd07f4  jnz 0x0000781A8FFD0826
0000781a8ffd07f6  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd07fe  jz 0x0000781A8FFD0900
0000781a8ffd0804  nop [rax+rax*1], ax
0000781a8ffd080d  nop [rax+rax*1], eax
0000781a8ffd0815  mov eax, 0x41028C
0000781a8ffd081a  mov [r15+0x100], rax
0000781a8ffd0821  jmp 0x0000781A8FDFE110
0000781a8ffd0826  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd082e  jz 0x0000781A8FFD0860
0000781a8ffd0834  nop [rax+rax*1], ax
0000781a8ffd083d  nop [rax+rax*1], eax
0000781a8ffd0845  mov eax, 0x410274
0000781a8ffd084a  mov [r15+0x100], rax
0000781a8ffd0851  jmp 0x0000781A8FDFE110
0000781a8ffd0856  int3
0000781a8ffd0857  int3
0000781a8ffd0858  nop [rax+rax*1], eax
0000781a8ffd0860  mov rax, [r15+0xF8]
0000781a8ffd0867  lea r14, [rax+0xD0]
0000781a8ffd086e  mov [r15], r14
0000781a8ffd0871  mov rax, [r15+0x98]
0000781a8ffd0878  mov [r15+0x08], rax
0000781a8ffd087c  mov qword ptr [r15+0x10], 0x12C
0000781a8ffd0884  mov qword ptr [r15+0xF0], 0x410284
0000781a8ffd088f  mov r14d, [r15+0x320]
0000781a8ffd0896  mov eax, 0x410284
0000781a8ffd089b  mov rcx, 0x781A8FFD07C0
0000781a8ffd08a5  mov [r15+r14*8+0x328], rax
0000781a8ffd08ad  mov [r15+r14*8+0x368], rcx
0000781a8ffd08b5  add r14d, 0x01
0000781a8ffd08b9  and r14d, 0x07
0000781a8ffd08bd  mov [r15+0x320], r14d
0000781a8ffd08c4  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd08cc  jz 0x0000781A8FFCED70
0000781a8ffd08d2  nop [rax+rax*1], ax
0000781a8ffd08db  nop [rax+rax*1], eax
0000781a8ffd08e3  mov eax, 0x4106BC
0000781a8ffd08e8  mov [r15+0x100], rax
0000781a8ffd08ef  jmp 0x0000781A8FDFE110
0000781a8ffd08f4  int3
0000781a8ffd08f5  int3
0000781a8ffd08f6  nop [rax+rax*1], ax
0000781a8ffd08ff  nop
0000781a8ffd0900  mov rax, [r15+0xF8]
0000781a8ffd0907  lea r14, [rax+0xF0]
0000781a8ffd090e  mov r12, [r13+r14*1]
0000781a8ffd0913  mov [r15+0x98], r12
0000781a8ffd091a  mov qword ptr [r15+0x40], 0x80
0000781a8ffd0922  lea r14, [rax+0xD0]
0000781a8ffd0929  mov [r15], r14
0000781a8ffd092c  lea r14, [rax+0x14C]
0000781a8ffd0933  mov [r15+0x08], r14
0000781a8ffd0937  mov qword ptr [r15+0x10], 0x01
0000781a8ffd093f  lea r14, [rax+0x14C]
0000781a8ffd0946  mov eax, 0x80
0000781a8ffd094b  mov [r13+r14*1], al
0000781a8ffd0950  mov qword ptr [r15+0xF0], 0x4102A8
0000781a8ffd095b  mov r14d, [r15+0x320]
0000781a8ffd0962  mov eax, 0x4102A8
0000781a8ffd0967  mov rcx, 0x781A8FFD09E0
0000781a8ffd0971  mov [r15+r14*8+0x328], rax
0000781a8ffd0979  mov [r15+r14*8+0x368], rcx
0000781a8ffd0981  add r14d, 0x01
0000781a8ffd0985  and r14d, 0x07
0000781a8ffd0989  mov [r15+0x320], r14d
0000781a8ffd0990  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0998  jz 0x0000781A8FFCED70
0000781a8ffd099e  nop [rax+rax*1], ax
0000781a8ffd09a7  nop [rax+rax*1], eax
0000781a8ffd09af  mov eax, 0x4106BC
0000781a8ffd09b4  mov [r15+0x100], rax
0000781a8ffd09bb  jmp 0x0000781A8FDFE110
0000781a8ffd09c0  int3
0000781a8ffd09c1  call 0x0000781A8FEE27E0
0000781a8ffd09c6  jmp 0x0000781A8FFD0913
0000781a8ffd09cb  call 0x0000781A8FED5AF0
0000781a8ffd09d0  jmp 0x0000781A8FFD0950
0000781a8ffd09d5  int3
0000781a8ffd09d6  nop [rax+rax*1], ax
0000781a8ffd09df  nop
0000781a8ffd09e0  mov rax, [r15+0xF8]
0000781a8ffd09e7  lea r14, [rax+0x138]
0000781a8ffd09ee  mov r12, [r13+r14*1]
0000781a8ffd09f3  mov [r15+0x40], r12
0000781a8ffd09f7  lea r14, [rax+0x148]
0000781a8ffd09fe  xor eax, eax
0000781a8ffd0a00  mov [r13+r14*1], al
0000781a8ffd0a05  xor eax, eax
0000781a8ffd0a07  mov r14d, 0x38
0000781a8ffd0a0d  cmp r12, r14
0000781a8ffd0a10  cmc
0000781a8ffd0a11  lahf
0000781a8ffd0a12  seto al
0000781a8ffd0a15  mov [r15+0x108], eax
0000781a8ffd0a1c  mov eax, [r15+0x108]
0000781a8ffd0a23  sahf
0000781a8ffd0a24  jz 0x0000781A8FFD0A56
0000781a8ffd0a26  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0a2e  jz 0x0000781A8FFD0AA0
0000781a8ffd0a34  nop [rax+rax*1], ax
0000781a8ffd0a3d  nop [rax+rax*1], eax
0000781a8ffd0a45  mov eax, 0x4102B8
0000781a8ffd0a4a  mov [r15+0x100], rax
0000781a8ffd0a51  jmp 0x0000781A8FDFE110
0000781a8ffd0a56  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0a5e  jz 0x0000781A8FFD0BF0
0000781a8ffd0a64  nop [rax+rax*1], ax
0000781a8ffd0a6d  nop [rax+rax*1], eax
0000781a8ffd0a75  mov eax, 0x4102D4
0000781a8ffd0a7a  mov [r15+0x100], rax
0000781a8ffd0a81  jmp 0x0000781A8FDFE110
0000781a8ffd0a86  int3
0000781a8ffd0a87  call 0x0000781A8FEE27E0
0000781a8ffd0a8c  jmp 0x0000781A8FFD09F3
0000781a8ffd0a91  call 0x0000781A8FED5AF0
0000781a8ffd0a96  jmp 0x0000781A8FFD0A05
0000781a8ffd0a9b  int3
0000781a8ffd0a9c  nop [rax], eax
0000781a8ffd0aa0  mov rax, [r15+0xF8]
0000781a8ffd0aa7  lea r14, [rax+0xD0]
0000781a8ffd0aae  mov [r15], r14
0000781a8ffd0ab1  lea r14, [rax+0x148]
0000781a8ffd0ab8  mov [r15+0x08], r14
0000781a8ffd0abc  mov qword ptr [r15+0x10], 0x01
0000781a8ffd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
0000781a8ffd0acf  mov r14d, [r15+0x320]
0000781a8ffd0ad6  mov eax, 0x4102C8
0000781a8ffd0adb  mov rcx, 0x781A8FFD0B40
0000781a8ffd0ae5  mov [r15+r14*8+0x328], rax
0000781a8ffd0aed  mov [r15+r14*8+0x368], rcx
0000781a8ffd0af5  add r14d, 0x01
0000781a8ffd0af9  and r14d, 0x07
0000781a8ffd0afd  mov [r15+0x320], r14d
0000781a8ffd0b04  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0b0c  jz 0x0000781A8FFCED70
0000781a8ffd0b12  nop [rax+rax*1], ax
0000781a8ffd0b1b  nop [rax+rax*1], eax
0000781a8ffd0b23  mov eax, 0x4106BC
0000781a8ffd0b28  mov [r15+0x100], rax
0000781a8ffd0b2f  jmp 0x0000781A8FDFE110
0000781a8ffd0b34  int3
0000781a8ffd0b35  int3
0000781a8ffd0b36  nop [rax+rax*1], ax
0000781a8ffd0b3f  nop
0000781a8ffd0b40  mov rax, [r15+0xF8]
0000781a8ffd0b47  lea r14, [rax+0x138]
0000781a8ffd0b4e  mov rax, [r13+r14*1]
0000781a8ffd0b53  mov [r15+0x40], rax
0000781a8ffd0b57  mov [rsp+0x10], rax
0000781a8ffd0b5c  xor eax, eax
0000781a8ffd0b5e  mov r14, [rsp+0x10]
0000781a8ffd0b63  mov r12d, 0x38
0000781a8ffd0b69  cmp r14, r12
0000781a8ffd0b6c  cmc
0000781a8ffd0b6d  lahf
0000781a8ffd0b6e  seto al
0000781a8ffd0b71  mov [r15+0x108], eax
0000781a8ffd0b78  mov eax, [r15+0x108]
0000781a8ffd0b7f  sahf
0000781a8ffd0b80  jnz 0x0000781A8FFD0BB2
0000781a8ffd0b82  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0b8a  jz 0x0000781A8FFD0BF0
0000781a8ffd0b90  nop [rax+rax*1], ax
0000781a8ffd0b99  nop [rax+rax*1], eax
0000781a8ffd0ba1  mov eax, 0x4102D4
0000781a8ffd0ba6  mov [r15+0x100], rax
0000781a8ffd0bad  jmp 0x0000781A8FDFE110
0000781a8ffd0bb2  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0bba  jz 0x0000781A8FFD0AA0
0000781a8ffd0bc0  nop [rax+rax*1], ax
0000781a8ffd0bc9  nop [rax+rax*1], eax
0000781a8ffd0bd1  mov eax, 0x4102B8
0000781a8ffd0bd6  mov [r15+0x100], rax
0000781a8ffd0bdd  jmp 0x0000781A8FDFE110
0000781a8ffd0be2  int3
0000781a8ffd0be3  call 0x0000781A8FED59C0
0000781a8ffd0be8  jmp 0x0000781A8FFD0B53
0000781a8ffd0bed  int3
0000781a8ffd0bee  nop
0000781a8ffd0bf0  mov rax, [r15+0x98]
0000781a8ffd0bf7  rorx r14, rax, 0x3D
0000781a8ffd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
0000781a8ffd0c01  mov rax, [r15+0xF8]
0000781a8ffd0c08  lea r12, [rax+0xD0]
0000781a8ffd0c0f  mov [r15], r12
0000781a8ffd0c12  lea r12, [rax+0x140]
0000781a8ffd0c19  mov [r15+0x08], r12
0000781a8ffd0c1d  mov qword ptr [r15+0x10], 0x08
0000781a8ffd0c25  bswap r14
0000781a8ffd0c28  mov [r15+0x40], r14
0000781a8ffd0c2c  lea r12, [rax+0x140]
0000781a8ffd0c33  mov [r13+r12*1], r14
0000781a8ffd0c38  mov qword ptr [r15+0xF0], 0x4102F0
0000781a8ffd0c43  mov r14d, [r15+0x320]
0000781a8ffd0c4a  mov eax, 0x4102F0
0000781a8ffd0c4f  mov rcx, 0x781A8FFD0CC0
0000781a8ffd0c59  mov [r15+r14*8+0x328], rax
0000781a8ffd0c61  mov [r15+r14*8+0x368], rcx
0000781a8ffd0c69  add r14d, 0x01
0000781a8ffd0c6d  and r14d, 0x07
0000781a8ffd0c71  mov [r15+0x320], r14d
0000781a8ffd0c78  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0c80  jz 0x0000781A8FFCED70
0000781a8ffd0c86  nop [rax+rax*1], ax
0000781a8ffd0c8f  nop [rax+rax*1], eax
0000781a8ffd0c97  mov eax, 0x4106BC
0000781a8ffd0c9c  mov [r15+0x100], rax
0000781a8ffd0ca3  jmp 0x0000781A8FDFE110
0000781a8ffd0ca8  int3
0000781a8ffd0ca9  call 0x0000781A8FEC3FE0
0000781a8ffd0cae  jmp 0x0000781A8FFD0C38
0000781a8ffd0cb3  int3
0000781a8ffd0cb4  nop [rax+rax*1], ax
0000781a8ffd0cbd  nop [rax], eax
0000781a8ffd0cc0  mov rax, [r15+0xF8]
0000781a8ffd0cc7  lea r14, [rax+0xD0]
0000781a8ffd0cce  mov r12d, [r13+r14*1]
0000781a8ffd0cd3  lea r14, [rax+0xD4]
0000781a8ffd0cda  mov r11d, [r13+r14*1]
0000781a8ffd0cdf  lea r14, [rax+0xD8]
0000781a8ffd0ce6  mov r10d, [r13+r14*1]
0000781a8ffd0ceb  lea r14, [rax+0xDC]
0000781a8ffd0cf2  mov r9d, [r13+r14*1]
0000781a8ffd0cf7  mov qword ptr [r15+0x48], 0x430C20
0000781a8ffd0cff  mov qword ptr [r15+0xA0], 0x00
0000781a8ffd0d0a  bswap r12d
0000781a8ffd0d0d  bswap r11d
0000781a8ffd0d10  mov qword ptr [r15+0x98], 0x430D8C
0000781a8ffd0d1b  mov r14d, 0x430C20
0000781a8ffd0d21  mov [r13+r14*1], r12d
0000781a8ffd0d26  mov r14d, 0x430C24
0000781a8ffd0d2c  mov [r13+r14*1], r11d
0000781a8ffd0d31  bswap r10d
0000781a8ffd0d34  bswap r9d
0000781a8ffd0d37  lea r14, [rax+0xE0]
0000781a8ffd0d3e  mov r12d, [r13+r14*1]
0000781a8ffd0d43  lea r14, [rax+0xE4]
0000781a8ffd0d4a  mov r11d, [r13+r14*1]
0000781a8ffd0d4f  mov r14d, 0x430C28
0000781a8ffd0d55  mov [r13+r14*1], r10d
0000781a8ffd0d5a  mov r14d, 0x430C2C
0000781a8ffd0d60  mov [r13+r14*1], r9d
0000781a8ffd0d65  bswap r12d
0000781a8ffd0d68  bswap r11d
0000781a8ffd0d6b  mov [rsp+0x10], r11d
0000781a8ffd0d70  mov r11d, r11d
0000781a8ffd0d73  mov [r15+0x58], r11
0000781a8ffd0d77  lea r14, [rax+0xE8]
0000781a8ffd0d7e  mov r11d, [r13+r14*1]
0000781a8ffd0d83  lea r14, [rax+0xEC]
0000781a8ffd0d8a  mov eax, [r13+r14*1]
0000781a8ffd0d8f  mov [rsp+0x20], eax
0000781a8ffd0d93  mov eax, eax
0000781a8ffd0d95  mov [r15+0x60], rax
0000781a8ffd0d99  mov eax, 0x430C30
0000781a8ffd0d9e  mov [r13+rax*1], r12d
0000781a8ffd0da3  mov eax, 0x430C34
0000781a8ffd0da8  mov r14d, [rsp+0x10]
0000781a8ffd0dad  mov [r13+rax*1], r14d
0000781a8ffd0db2  bswap r11d
0000781a8ffd0db5  mov [rsp+0x10], r11d
0000781a8ffd0dba  mov r11d, r11d
0000781a8ffd0dbd  mov [r15+0x40], r11
0000781a8ffd0dc1  mov eax, [rsp+0x20]
0000781a8ffd0dc5  bswap eax
0000781a8ffd0dc7  mov [rsp+0x20], eax
0000781a8ffd0dcb  mov eax, eax
0000781a8ffd0dcd  mov [r15+0x50], rax
0000781a8ffd0dd1  mov eax, 0x430C38
0000781a8ffd0dd6  mov r14d, [rsp+0x10]
0000781a8ffd0ddb  mov [r13+rax*1], r14d
0000781a8ffd0de0  mov eax, 0x430C3C
0000781a8ffd0de5  mov r14d, [rsp+0x20]
0000781a8ffd0dea  mov [r13+rax*1], r14d
0000781a8ffd0def  mov eax, [r15+0xA0]
0000781a8ffd0df6  lea r14d, [eax+0x11]
0000781a8ffd0dfb  mov r14d, r14d
0000781a8ffd0dfe  mov [r15], r14
0000781a8ffd0e01  mov qword ptr [r15+0xF0], 0x41034C
0000781a8ffd0e0c  mov r14d, [r15+0x320]
0000781a8ffd0e13  mov eax, 0x41034C
0000781a8ffd0e18  mov rcx, 0x781A8FFD0F90
0000781a8ffd0e22  mov [r15+r14*8+0x328], rax
0000781a8ffd0e2a  mov [r15+r14*8+0x368], rcx
0000781a8ffd0e32  add r14d, 0x01
0000781a8ffd0e36  and r14d, 0x07
0000781a8ffd0e3a  mov [r15+0x320], r14d
0000781a8ffd0e41  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0e49  jz 0x0000781A8FFD0F20
0000781a8ffd0e4f  nop [rax+rax*1], ax
0000781a8ffd0e58  nop [rax+rax*1], eax
0000781a8ffd0e60  mov eax, 0x410938
0000781a8ffd0e65  mov [r15+0x100], rax
0000781a8ffd0e6c  jmp 0x0000781A8FDFE110
0000781a8ffd0e71  int3
0000781a8ffd0e72  call 0x0000781A8FEE26A0
0000781a8ffd0e77  jmp 0x0000781A8FFD0CD3
0000781a8ffd0e7c  call 0x0000781A8FEE1430
0000781a8ffd0e81  jmp 0x0000781A8FFD0CDF
0000781a8ffd0e86  call 0x0000781A8FEE01C0
0000781a8ffd0e8b  jmp 0x0000781A8FFD0CEB
0000781a8ffd0e90  call 0x0000781A8FEDEF50
0000781a8ffd0e95  jmp 0x0000781A8FFD0CF7
0000781a8ffd0e9a  call 0x0000781A8FEE2BA0
0000781a8ffd0e9f  jmp 0x0000781A8FFD0D26
0000781a8ffd0ea4  call 0x0000781A8FEE1920
0000781a8ffd0ea9  jmp 0x0000781A8FFD0D31
0000781a8ffd0eae  call 0x0000781A8FEE26A0
0000781a8ffd0eb3  jmp 0x0000781A8FFD0D43
0000781a8ffd0eb8  call 0x0000781A8FEE1430
0000781a8ffd0ebd  jmp 0x0000781A8FFD0D4F
0000781a8ffd0ec2  call 0x0000781A8FEE06B0
0000781a8ffd0ec7  jmp 0x0000781A8FFD0D5A
0000781a8ffd0ecc  call 0x0000781A8FEDF440
0000781a8ffd0ed1  jmp 0x0000781A8FFD0D65
0000781a8ffd0ed6  call 0x0000781A8FEE1430
0000781a8ffd0edb  jmp 0x0000781A8FFD0D83
0000781a8ffd0ee0  call 0x0000781A8FED5890
0000781a8ffd0ee5  jmp 0x0000781A8FFD0D8F
0000781a8ffd0eea  call 0x0000781A8FE0BAE0
0000781a8ffd0eef  jmp 0x0000781A8FFD0DA3
0000781a8ffd0ef4  call 0x0000781A8FE0DFE0
0000781a8ffd0ef9  jmp 0x0000781A8FFD0DB2
0000781a8ffd0efe  call 0x0000781A8FE0DFE0
0000781a8ffd0f03  jmp 0x0000781A8FFD0DE0
0000781a8ffd0f08  call 0x0000781A8FE0DFE0
0000781a8ffd0f0d  jmp 0x0000781A8FFD0DEF
0000781a8ffd0f12  int3
0000781a8ffd0f13  nop [rax+rax*1], ax
0000781a8ffd0f1c  nop [rax], eax
0000781a8ffd0f20  mov eax, [r15]
0000781a8ffd0f23  mov [rsp+0x10], eax
0000781a8ffd0f27  shr eax, 0x10
0000781a8ffd0f2a  mov r14d, [rsp+0x10]
0000781a8ffd0f2f  xor r14d, eax
0000781a8ffd0f32  imul r14d, r14d, 0x7FEB352D
0000781a8ffd0f39  mov eax, 0x846CA68B
0000781a8ffd0f3e  mov eax, eax
0000781a8ffd0f40  mov [r15+0x48], rax
0000781a8ffd0f44  mov [rsp+0x10], r14d
0000781a8ffd0f49  shr r14d, 0x0F
0000781a8ffd0f4d  mov eax, [rsp+0x10]
0000781a8ffd0f51  xor eax, r14d
0000781a8ffd0f54  imul eax, eax, 0x846CA68B
0000781a8ffd0f5a  mov [rsp+0x10], eax
0000781a8ffd0f5e  mov eax, eax
0000781a8ffd0f60  mov [r15+0x40], rax
0000781a8ffd0f64  mov eax, [rsp+0x10]
0000781a8ffd0f68  shr eax, 0x10
0000781a8ffd0f6b  mov r14d, [rsp+0x10]
0000781a8ffd0f70  xor r14d, eax
0000781a8ffd0f73  mov r14d, r14d
0000781a8ffd0f76  mov [r15], r14
0000781a8ffd0f79  mov rax, [r15+0xF0]
0000781a8ffd0f80  mov [r15+0x100], rax
0000781a8ffd0f87  jmp 0x0000781A8FFCE5C0
0000781a8ffd0f8c  int3
0000781a8ffd0f8d  int3
0000781a8ffd0f8e  nop
0000781a8ffd0f90  mov rax, [r15+0xA0]
0000781a8ffd0f97  mov [rsp+0x10], rax
0000781a8ffd0f9c  shl rax, 0x02
0000781a8ffd0fa0  mov r14, [r15+0x98]
0000781a8ffd0fa7  lea r12, [r14+rax*1]
0000781a8ffd0fab  mov eax, [r15]
0000781a8ffd0fae  mov [r13+r12*1], eax
0000781a8ffd0fb3  mov rax, [rsp+0x10]
0000781a8ffd0fb8  lea r14, [rax+0x01]
0000781a8ffd0fbc  mov [r15+0xA0], r14
0000781a8ffd0fc3  xor eax, eax
0000781a8ffd0fc5  mov r12d, 0x400
0000781a8ffd0fcb  cmp r14, r12
0000781a8ffd0fce  cmc
0000781a8ffd0fcf  lahf
0000781a8ffd0fd0  seto al
0000781a8ffd0fd3  mov [r15+0x108], eax
0000781a8ffd0fda  mov eax, [r15+0x108]
0000781a8ffd0fe1  sahf
0000781a8ffd0fe2  jnz 0x0000781A8FFD1014
0000781a8ffd0fe4  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd0fec  jz 0x0000781A8FFD10E0
0000781a8ffd0ff2  nop [rax+rax*1], ax
0000781a8ffd0ffb  nop [rax+rax*1], eax
0000781a8ffd1003  mov eax, 0x41035C
0000781a8ffd1008  mov [r15+0x100], rax
0000781a8ffd100f  jmp 0x0000781A8FDFE110
0000781a8ffd1014  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd101c  jz 0x0000781A8FFD1050
0000781a8ffd1022  nop [rax+rax*1], ax
0000781a8ffd102b  nop [rax+rax*1], eax
0000781a8ffd1033  mov eax, 0x410344
0000781a8ffd1038  mov [r15+0x100], rax
0000781a8ffd103f  jmp 0x0000781A8FDFE110
0000781a8ffd1044  int3
0000781a8ffd1045  call 0x0000781A8FEB4B70
0000781a8ffd104a  jmp 0x0000781A8FFD0FB3
0000781a8ffd104f  int3
0000781a8ffd1050  mov eax, [r15+0xA0]
0000781a8ffd1057  lea r14d, [eax+0x11]
0000781a8ffd105c  mov r14d, r14d
0000781a8ffd105f  mov [r15], r14
0000781a8ffd1062  mov qword ptr [r15+0xF0], 0x41034C
0000781a8ffd106d  mov r14d, [r15+0x320]
0000781a8ffd1074  mov eax, 0x41034C
0000781a8ffd1079  mov rcx, 0x781A8FFD0F90
0000781a8ffd1083  mov [r15+r14*8+0x328], rax
0000781a8ffd108b  mov [r15+r14*8+0x368], rcx
0000781a8ffd1093  add r14d, 0x01
0000781a8ffd1097  and r14d, 0x07
0000781a8ffd109b  mov [r15+0x320], r14d
0000781a8ffd10a2  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd10aa  jz 0x0000781A8FFD0F20
0000781a8ffd10b0  nop [rax+rax*1], ax
0000781a8ffd10b9  nop [rax+rax*1], eax
0000781a8ffd10c1  mov eax, 0x410938
0000781a8ffd10c6  mov [r15+0x100], rax
0000781a8ffd10cd  jmp 0x0000781A8FDFE110
0000781a8ffd10d2  int3
0000781a8ffd10d3  int3
0000781a8ffd10d4  nop [rax+rax*1], ax
0000781a8ffd10dd  nop [rax], eax
0000781a8ffd10e0  mov qword ptr [r15+0x40], 0x01
0000781a8ffd10e8  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd10f0  jz 0x0000781A8FFD1120
0000781a8ffd10f6  nop [rax+rax*1], ax
0000781a8ffd10ff  nop [rax+rax*1], eax
0000781a8ffd1107  mov eax, 0x410378
0000781a8ffd110c  mov [r15+0x100], rax
0000781a8ffd1113  jmp 0x0000781A8FDFE110
0000781a8ffd1118  int3
0000781a8ffd1119  int3
0000781a8ffd111a  nop [rax+rax*1], ax
0000781a8ffd1120  mov rax, [r15+0x40]
0000781a8ffd1124  mov [rsp+0x10], rax
0000781a8ffd1129  shl rax, 0x02
0000781a8ffd112d  mov r14, [r15+0x98]
0000781a8ffd1134  lea r12, [r14+rax*1]
0000781a8ffd1138  mov eax, [r13+r12*1]
0000781a8ffd113d  mov [rsp+0x20], eax
0000781a8ffd1141  mov eax, eax
0000781a8ffd1143  mov [r15+0x48], rax
0000781a8ffd1147  mov rax, [rsp+0x10]
0000781a8ffd114c  mov [r15+0x50], rax
0000781a8ffd1150  mov eax, [r15+0x50]
0000781a8ffd1154  lea r12d, [eax-0x01]
0000781a8ffd1159  mov r12d, r12d
0000781a8ffd115c  mov [r15+0x58], r12
0000781a8ffd1160  mov rax, [r15+0x58]
0000781a8ffd1164  mov r12d, eax
0000781a8ffd1167  mov r12d, r12d
0000781a8ffd116a  shl r12, 0x02
0000781a8ffd116e  lea rax, [r14+r12*1]
0000781a8ffd1172  mov r14d, [r13+rax*1]
0000781a8ffd1177  mov [rsp+0x10], r14d
0000781a8ffd117c  mov r14d, r14d
0000781a8ffd117f  mov [r15+0x60], r14
0000781a8ffd1183  xor eax, eax
0000781a8ffd1185  mov r14d, [rsp+0x10]
0000781a8ffd118a  mov r12d, [rsp+0x20]
0000781a8ffd118f  cmp r14d, r12d
0000781a8ffd1192  cmc
0000781a8ffd1193  lahf
0000781a8ffd1194  seto al
0000781a8ffd1197  mov [r15+0x108], eax
0000781a8ffd119e  mov eax, [r15+0x108]
0000781a8ffd11a5  sahf
0000781a8ffd11a6  cmc
0000781a8ffd11a7  jbe 0x0000781A8FFD11D9
0000781a8ffd11a9  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd11b1  jz 0x0000781A8FFD1220
0000781a8ffd11b7  nop [rax+rax*1], ax
0000781a8ffd11c0  nop [rax+rax*1], eax
0000781a8ffd11c8  mov eax, 0x410390
0000781a8ffd11cd  mov [r15+0x100], rax
0000781a8ffd11d4  jmp 0x0000781A8FDFE110
0000781a8ffd11d9  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd11e1  jz 0x0000781A8FFD14C0
0000781a8ffd11e7  nop [rax+rax*1], ax
0000781a8ffd11f0  nop [rax+rax*1], eax
0000781a8ffd11f8  mov eax, 0x410368
0000781a8ffd11fd  mov [r15+0x100], rax
0000781a8ffd1204  jmp 0x0000781A8FDFE110
0000781a8ffd1209  int3
0000781a8ffd120a  call 0x0000781A8FEB4690
0000781a8ffd120f  jmp 0x0000781A8FFD113D
0000781a8ffd1214  call 0x0000781A8FE0DAE0
0000781a8ffd1219  jmp 0x0000781A8FFD1177
0000781a8ffd121e  int3
0000781a8ffd121f  nop
0000781a8ffd1220  mov rax, [r15+0x50]
0000781a8ffd1224  mov [rsp+0x10], rax
0000781a8ffd1229  shl rax, 0x02
0000781a8ffd122d  mov r14, [r15+0x98]
0000781a8ffd1234  lea r12, [r14+rax*1]
0000781a8ffd1238  mov eax, [r15+0x60]
0000781a8ffd123c  mov [r13+r12*1], eax
0000781a8ffd1241  mov rax, [rsp+0x10]
0000781a8ffd1246  lea r14, [rax-0x01]
0000781a8ffd124a  mov [r15+0x50], r14
0000781a8ffd124e  mov rax, [r15+0x58]
0000781a8ffd1252  test rax, rax
0000781a8ffd1255  setz al
0000781a8ffd1258  movzx rax, al
0000781a8ffd125c  mov [rsp+0x414], al
0000781a8ffd1263  cmp byte ptr [rsp+0x414], 0x00
0000781a8ffd126b  jz 0x0000781A8FFD129D
0000781a8ffd126d  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd1275  jz 0x0000781A8FFD12E0
0000781a8ffd127b  nop [rax+rax*1], ax
0000781a8ffd1284  nop [rax+rax*1], eax
0000781a8ffd128c  mov eax, 0x41039C
0000781a8ffd1291  mov [r15+0x100], rax
0000781a8ffd1298  jmp 0x0000781A8FDFE110
0000781a8ffd129d  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd12a5  jz 0x0000781A8FFD13E0
0000781a8ffd12ab  nop [rax+rax*1], ax
0000781a8ffd12b4  nop [rax+rax*1], eax
0000781a8ffd12bc  mov eax, 0x410380
0000781a8ffd12c1  mov [r15+0x100], rax
0000781a8ffd12c8  jmp 0x0000781A8FDFE110
0000781a8ffd12cd  int3
0000781a8ffd12ce  call 0x0000781A8FEB4B70
0000781a8ffd12d3  jmp 0x0000781A8FFD1241
0000781a8ffd12d8  int3
0000781a8ffd12d9  nop [rax], eax
0000781a8ffd12e0  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd12e8  jz 0x0000781A8FFD1320
0000781a8ffd12ee  nop [rax+rax*1], ax
0000781a8ffd12f7  nop [rax+rax*1], eax
0000781a8ffd12ff  mov eax, 0x410364
0000781a8ffd1304  mov [r15+0x100], rax
0000781a8ffd130b  jmp 0x0000781A8FDFE110
0000781a8ffd1310  int3
0000781a8ffd1311  int3
0000781a8ffd1312  nop [rax+rax*1], ax
0000781a8ffd131b  nop [rax+rax*1], eax
0000781a8ffd1320  mov qword ptr [r15+0x50], 0x00
0000781a8ffd1328  mov rax, [r15+0x40]
0000781a8ffd132c  lea r14, [rax+0x01]
0000781a8ffd1330  mov [r15+0x40], r14
0000781a8ffd1334  mov rax, [r15+0x98]
0000781a8ffd133b  mov r12d, [r15+0x48]
0000781a8ffd133f  mov [r13+rax*1], r12d
0000781a8ffd1344  xor eax, eax
0000781a8ffd1346  mov r12d, 0x400
0000781a8ffd134c  cmp r14, r12
0000781a8ffd134f  cmc
0000781a8ffd1350  lahf
0000781a8ffd1351  seto al
0000781a8ffd1354  mov [r15+0x108], eax
0000781a8ffd135b  mov eax, [r15+0x108]
0000781a8ffd1362  sahf
0000781a8ffd1363  jz 0x0000781A8FFD1395
0000781a8ffd1365  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd136d  jz 0x0000781A8FFD1120
0000781a8ffd1373  nop [rax+rax*1], ax
0000781a8ffd137c  nop [rax+rax*1], eax
0000781a8ffd1384  mov eax, 0x410378
0000781a8ffd1389  mov [r15+0x100], rax
0000781a8ffd1390  jmp 0x0000781A8FDFE110
0000781a8ffd1395  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd139d  jz 0x0000781A8FFD1580
0000781a8ffd13a3  nop [rax+rax*1], ax
0000781a8ffd13ac  nop [rax+rax*1], eax
0000781a8ffd13b4  mov eax, 0x4103A0
0000781a8ffd13b9  mov [r15+0x100], rax
0000781a8ffd13c0  jmp 0x0000781A8FDFE110
0000781a8ffd13c5  int3
0000781a8ffd13c6  call 0x0000781A8FE0BAE0
0000781a8ffd13cb  jmp 0x0000781A8FFD1344
0000781a8ffd13d0  int3
0000781a8ffd13d1  nop [rax+rax*1], ax
0000781a8ffd13da  nop [rax+rax*1], ax
0000781a8ffd13e0  mov eax, [r15+0x50]
0000781a8ffd13e4  lea r14d, [eax-0x01]
0000781a8ffd13e9  mov r14d, r14d
0000781a8ffd13ec  mov [r15+0x58], r14
0000781a8ffd13f0  mov rax, [r15+0x58]
0000781a8ffd13f4  mov r14d, eax
0000781a8ffd13f7  mov r14d, r14d
0000781a8ffd13fa  shl r14, 0x02
0000781a8ffd13fe  mov rax, [r15+0x98]
0000781a8ffd1405  lea r12, [rax+r14*1]
0000781a8ffd1409  mov eax, [r13+r12*1]
0000781a8ffd140e  mov [rsp+0x10], eax
0000781a8ffd1412  mov eax, eax
0000781a8ffd1414  mov [r15+0x60], rax
0000781a8ffd1418  mov eax, [r15+0x48]
0000781a8ffd141c  mov [rsp+0x20], eax
0000781a8ffd1420  xor eax, eax
0000781a8ffd1422  mov r14d, [rsp+0x10]
0000781a8ffd1427  mov r12d, [rsp+0x20]
0000781a8ffd142c  cmp r14d, r12d
0000781a8ffd142f  cmc
0000781a8ffd1430  lahf
0000781a8ffd1431  seto al
0000781a8ffd1434  mov [r15+0x108], eax
0000781a8ffd143b  mov eax, [r15+0x108]
0000781a8ffd1442  sahf
0000781a8ffd1443  cmc
0000781a8ffd1444  jbe 0x0000781A8FFD1476
0000781a8ffd1446  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd144e  jz 0x0000781A8FFD1220
0000781a8ffd1454  nop [rax+rax*1], ax
0000781a8ffd145d  nop [rax+rax*1], eax
0000781a8ffd1465  mov eax, 0x410390
0000781a8ffd146a  mov [r15+0x100], rax
0000781a8ffd1471  jmp 0x0000781A8FDFE110
0000781a8ffd1476  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd147e  jz 0x0000781A8FFD14C0
0000781a8ffd1484  nop [rax+rax*1], ax
0000781a8ffd148d  nop [rax+rax*1], eax
0000781a8ffd1495  mov eax, 0x410368
0000781a8ffd149a  mov [r15+0x100], rax
0000781a8ffd14a1  jmp 0x0000781A8FDFE110
0000781a8ffd14a6  int3
0000781a8ffd14a7  call 0x0000781A8FEB4690
0000781a8ffd14ac  jmp 0x0000781A8FFD140E
0000781a8ffd14b1  int3
0000781a8ffd14b2  nop [rax+rax*1], ax
0000781a8ffd14bb  nop [rax+rax*1], eax
0000781a8ffd14c0  mov rax, [r15+0x40]
0000781a8ffd14c4  lea r14, [rax+0x01]
0000781a8ffd14c8  mov [r15+0x40], r14
0000781a8ffd14cc  mov rax, [r15+0x50]
0000781a8ffd14d0  mov r12d, eax
0000781a8ffd14d3  mov r12d, r12d
0000781a8ffd14d6  shl r12, 0x02
0000781a8ffd14da  mov rax, [r15+0x98]
0000781a8ffd14e1  lea r11, [rax+r12*1]
0000781a8ffd14e5  mov eax, [r15+0x48]
0000781a8ffd14e9  mov [r13+r11*1], eax
0000781a8ffd14ee  xor eax, eax
0000781a8ffd14f0  mov r12d, 0x400
0000781a8ffd14f6  cmp r14, r12
0000781a8ffd14f9  cmc
0000781a8ffd14fa  lahf
0000781a8ffd14fb  seto al
0000781a8ffd14fe  mov [r15+0x108], eax
0000781a8ffd1505  mov eax, [r15+0x108]
0000781a8ffd150c  sahf
0000781a8ffd150d  jz 0x0000781A8FFD153F
0000781a8ffd150f  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd1517  jz 0x0000781A8FFD1120
0000781a8ffd151d  nop [rax+rax*1], ax
0000781a8ffd1526  nop [rax+rax*1], eax
0000781a8ffd152e  mov eax, 0x410378
0000781a8ffd1533  mov [r15+0x100], rax
0000781a8ffd153a  jmp 0x0000781A8FDFE110
0000781a8ffd153f  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd1547  jz 0x0000781A8FFD1580
0000781a8ffd154d  nop [rax+rax*1], ax
0000781a8ffd1556  nop [rax+rax*1], eax
0000781a8ffd155e  mov eax, 0x4103A0
0000781a8ffd1563  mov [r15+0x100], rax
0000781a8ffd156a  jmp 0x0000781A8FDFE110
0000781a8ffd156f  int3
0000781a8ffd1570  call 0x0000781A8FEA4270
0000781a8ffd1575  jmp 0x0000781A8FFD14EE
0000781a8ffd157a  int3
0000781a8ffd157b  nop [rax+rax*1], eax
0000781a8ffd1580  mov qword ptr [r15+0x40], 0x430000
0000781a8ffd1588  mov eax, 0x430C40
0000781a8ffd158d  mov r14, [r13+rax*1]
0000781a8ffd1592  mov rax, [r15+0x98]
0000781a8ffd1599  mov r12d, [r13+rax*1]
0000781a8ffd159e  lea r11, [rax+0x04]
0000781a8ffd15a2  mov eax, [r13+r11*1]
0000781a8ffd15a7  mov r12d, r12d
0000781a8ffd15aa  mov [r15+0x68], r12
0000781a8ffd15ae  mov eax, eax
0000781a8ffd15b0  mov [r15+0x60], rax
0000781a8ffd15b4  mov rax, [r15+0x68]
0000781a8ffd15b8  mov [r15+0x68], rax
0000781a8ffd15bc  mov qword ptr [r15+0x58], 0x02
0000781a8ffd15c4  mov [rsp+0x10], rax
0000781a8ffd15c9  xor eax, eax
0000781a8ffd15cb  mov r12d, 0x02
0000781a8ffd15d1  mov r11d, 0x400
0000781a8ffd15d7  cmp r12, r11
0000781a8ffd15da  cmc
0000781a8ffd15db  lahf
0000781a8ffd15dc  seto al
0000781a8ffd15df  mov [r15+0x108], eax
0000781a8ffd15e6  mov rax, [r15+0x60]
0000781a8ffd15ea  mov r12d, 0x02
0000781a8ffd15f0  imul rax, r12
0000781a8ffd15f4  mov [r15+0x50], rax
0000781a8ffd15f8  mov rax, [rsp+0x10]
0000781a8ffd15fd  lea r12, [rax+r14*1]
0000781a8ffd1601  mov [r15+0x48], r12
0000781a8ffd1605  mov eax, [r15+0x108]
0000781a8ffd160c  sahf
0000781a8ffd160d  jnz 0x0000781A8FFD163F
0000781a8ffd160f  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd1617  jz 0x0000781A8FFD17B0
0000781a8ffd161d  nop [rax+rax*1], ax
0000781a8ffd1626  nop [rax+rax*1], eax
0000781a8ffd162e  mov eax, 0x4103D0
0000781a8ffd1633  mov [r15+0x100], rax
0000781a8ffd163a  jmp 0x0000781A8FDFE110
0000781a8ffd163f  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd1647  jz 0x0000781A8FFD1690
0000781a8ffd164d  nop [rax+rax*1], ax
0000781a8ffd1656  nop [rax+rax*1], eax
0000781a8ffd165e  mov eax, 0x4103B0
0000781a8ffd1663  mov [r15+0x100], rax
0000781a8ffd166a  jmp 0x0000781A8FDFE110
0000781a8ffd166f  int3
0000781a8ffd1670  call 0x0000781A8FE0DC20
0000781a8ffd1675  jmp 0x0000781A8FFD1592
0000781a8ffd167a  call 0x0000781A8FE0B5E0
0000781a8ffd167f  jmp 0x0000781A8FFD159E
0000781a8ffd1684  call 0x0000781A8FEA3D90
0000781a8ffd1689  jmp 0x0000781A8FFD15A7
0000781a8ffd168e  int3
0000781a8ffd168f  nop
0000781a8ffd1690  mov rax, [r15+0x98]
0000781a8ffd1697  mov r14, [r15+0x58]
0000781a8ffd169b  mov [rsp+0x10], r14
0000781a8ffd16a0  shl r14, 0x02
0000781a8ffd16a4  lea r12, [rax+r14*1]
0000781a8ffd16a8  mov eax, [r13+r12*1]
0000781a8ffd16ad  lea r14, [r12+0x04]
0000781a8ffd16b2  mov r12d, [r13+r14*1]
0000781a8ffd16b7  mov eax, eax
0000781a8ffd16b9  mov [r15+0x68], rax
0000781a8ffd16bd  mov r12d, r12d
0000781a8ffd16c0  mov [r15+0x60], r12
0000781a8ffd16c4  mov rax, [r15+0x68]
0000781a8ffd16c8  mov [rsp+0x20], rax
0000781a8ffd16cd  mov r14, [rsp+0x10]
0000781a8ffd16d2  imul rax, r14
0000781a8ffd16d6  mov r12, [rsp+0x20]
0000781a8ffd16db  lea r11, [r12+rax*1]
0000781a8ffd16df  mov [r15+0x68], r11
0000781a8ffd16e3  lea rax, [r14+0x02]
0000781a8ffd16e7  mov [r15+0x58], rax
0000781a8ffd16eb  mov [rsp+0x10], rax
0000781a8ffd16f0  xor eax, eax
0000781a8ffd16f2  mov r14, [rsp+0x10]
0000781a8ffd16f7  mov r12d, 0x400
0000781a8ffd16fd  cmp r14, r12
0000781a8ffd1700  cmc
0000781a8ffd1701  lahf
0000781a8ffd1702  seto al
0000781a8ffd1705  mov [r15+0x108], eax
0000781a8ffd170c  mov rax, [r15+0x50]
0000781a8ffd1710  mov r12, [r15+0x60]
0000781a8ffd1714  imul r14, r12
0000781a8ffd1718  lea r12, [rax+r14*1]
0000781a8ffd171c  mov [r15+0x50], r12
0000781a8ffd1720  mov rax, [r15+0x48]
0000781a8ffd1724  lea r14, [r11+rax*1]
0000781a8ffd1728  mov [r15+0x48], r14
0000781a8ffd172c  mov eax, [r15+0x108]
0000781a8ffd1733  sahf
0000781a8ffd1734  jnz 0x0000781A8FFD1766
0000781a8ffd1736  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd173e  jz 0x0000781A8FFD17B0
0000781a8ffd1744  nop [rax+rax*1], ax
0000781a8ffd174d  nop [rax+rax*1], eax
0000781a8ffd1755  mov eax, 0x4103D0
0000781a8ffd175a  mov [r15+0x100], rax
0000781a8ffd1761  jmp 0x0000781A8FDFE110
0000781a8ffd1766  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd176e  jz 0x0000781A8FFD1690
0000781a8ffd1774  nop [rax+rax*1], ax
0000781a8ffd177d  nop [rax+rax*1], eax
0000781a8ffd1785  mov eax, 0x4103B0
0000781a8ffd178a  mov [r15+0x100], rax
0000781a8ffd1791  jmp 0x0000781A8FDFE110
0000781a8ffd1796  int3
0000781a8ffd1797  call 0x0000781A8FEB4690
0000781a8ffd179c  jmp 0x0000781A8FFD16AD
0000781a8ffd17a1  call 0x0000781A8FEE26A0
0000781a8ffd17a6  jmp 0x0000781A8FFD16B7
0000781a8ffd17ab  int3
0000781a8ffd17ac  nop [rax], eax
0000781a8ffd17b0  mov qword ptr [r15+0x98], 0x00
0000781a8ffd17bb  mov rax, [r15+0x50]
0000781a8ffd17bf  mov r14, [r15+0x48]
0000781a8ffd17c3  lea r12, [rax+r14*1]
0000781a8ffd17c7  mov [r15+0x48], r12
0000781a8ffd17cb  mov rax, [r15+0x40]
0000781a8ffd17cf  lea r14, [rax+0xC40]
0000781a8ffd17d6  mov [r13+r14*1], r12
0000781a8ffd17db  mov qword ptr [r15], 0x01
0000781a8ffd17e2  mov qword ptr [r15+0xF0], 0x4103E8
0000781a8ffd17ed  mov r14d, [r15+0x320]
0000781a8ffd17f4  mov eax, 0x4103E8
0000781a8ffd17f9  mov rcx, 0x781A8FFD1860
0000781a8ffd1803  mov [r15+r14*8+0x328], rax
0000781a8ffd180b  mov [r15+r14*8+0x368], rcx
0000781a8ffd1813  add r14d, 0x01
0000781a8ffd1817  and r14d, 0x07
0000781a8ffd181b  mov [r15+0x320], r14d
0000781a8ffd1822  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd182a  jz 0x0000781A8FFD0F20
0000781a8ffd1830  nop [rax+rax*1], ax
0000781a8ffd1839  nop [rax+rax*1], eax
0000781a8ffd1841  mov eax, 0x410938
0000781a8ffd1846  mov [r15+0x100], rax
0000781a8ffd184d  jmp 0x0000781A8FDFE110
0000781a8ffd1852  int3
0000781a8ffd1853  call 0x0000781A8FEE2CE0
0000781a8ffd1858  jmp 0x0000781A8FFD17DB
0000781a8ffd185d  int3
0000781a8ffd185e  nop
0000781a8ffd1860  mov eax, [r15+0x98]
0000781a8ffd1867  lea r14d, [eax+0x01]
0000781a8ffd186c  mov [rsp+0x10], r14d
0000781a8ffd1871  mov r14d, r14d
0000781a8ffd1874  mov [r15+0x98], r14
0000781a8ffd187b  xor eax, eax
0000781a8ffd187d  mov r14d, [rsp+0x10]
0000781a8ffd1882  cmp r14d, 0x10000
0000781a8ffd1889  cmc
0000781a8ffd188a  lahf
0000781a8ffd188b  seto al
0000781a8ffd188e  mov [r15+0x108], eax
0000781a8ffd1895  mov eax, [r15+0x108]
0000781a8ffd189c  sahf
0000781a8ffd189d  jnz 0x0000781A8FFD18CF
0000781a8ffd189f  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd18a7  jz 0x0000781A8FFD19A0
0000781a8ffd18ad  nop [rax+rax*1], ax
0000781a8ffd18b6  nop [rax+rax*1], eax
0000781a8ffd18be  mov eax, 0x4103F4
0000781a8ffd18c3  mov [r15+0x100], rax
0000781a8ffd18ca  jmp 0x0000781A8FDFE110
0000781a8ffd18cf  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd18d7  jz 0x0000781A8FFD1910
0000781a8ffd18dd  nop [rax+rax*1], ax
0000781a8ffd18e6  nop [rax+rax*1], eax
0000781a8ffd18ee  mov eax, 0x4103E0
0000781a8ffd18f3  mov [r15+0x100], rax
0000781a8ffd18fa  jmp 0x0000781A8FDFE110
0000781a8ffd18ff  int3
0000781a8ffd1900  int3
0000781a8ffd1901  nop [rax+rax*1], ax
0000781a8ffd190a  nop [rax+rax*1], ax
0000781a8ffd1910  mov eax, [r15]
0000781a8ffd1913  mov r14d, [r15+0x98]
0000781a8ffd191a  lea r12d, [eax+r14d*1]
0000781a8ffd191f  mov r12d, r12d
0000781a8ffd1922  mov [r15], r12
0000781a8ffd1925  mov qword ptr [r15+0xF0], 0x4103E8
0000781a8ffd1930  mov r14d, [r15+0x320]
0000781a8ffd1937  mov eax, 0x4103E8
0000781a8ffd193c  mov rcx, 0x781A8FFD1860
0000781a8ffd1946  mov [r15+r14*8+0x328], rax
0000781a8ffd194e  mov [r15+r14*8+0x368], rcx
0000781a8ffd1956  add r14d, 0x01
0000781a8ffd195a  and r14d, 0x07
0000781a8ffd195e  mov [r15+0x320], r14d
0000781a8ffd1965  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd196d  jz 0x0000781A8FFD0F20
0000781a8ffd1973  nop [rax+rax*1], ax
0000781a8ffd197c  nop [rax+rax*1], eax
0000781a8ffd1984  mov eax, 0x410938
0000781a8ffd1989  mov [r15+0x100], rax
0000781a8ffd1990  jmp 0x0000781A8FDFE110
0000781a8ffd1995  int3
0000781a8ffd1996  int3
0000781a8ffd1997  nop [rax+rax*1], ax
0000781a8ffd19a0  vmovaps xmm1, [0x0000781A8FBFE010]
0000781a8ffd19a8  movq xmm1, xmm1
0000781a8ffd19ac  movaps [r15+0x110], xmm1
0000781a8ffd19b4  mov eax, 0x420AA0
0000781a8ffd19b9  mov r14, [r13+rax*1]
0000781a8ffd19be  movq xmm1, r14
0000781a8ffd19c3  movaps [r15+0x120], xmm1
0000781a8ffd19cb  vmovaps xmm1, [0x0000781A8FBFE020]
0000781a8ffd19d3  movq xmm1, xmm1
0000781a8ffd19d7  movaps [r15+0x140], xmm1
0000781a8ffd19df  vmovaps xmm1, [0x0000781A8FBFE030]
0000781a8ffd19e7  vpbroadcastq xmm1, xmm1
0000781a8ffd19ec  movaps [r15+0x150], xmm1
0000781a8ffd19f4  mov qword ptr [r15+0x40], 0x02
0000781a8ffd19fc  vmovaps xmm15, [0x0000781A8FBFE040]
0000781a8ffd1a04  movq xmm15, xmm15
0000781a8ffd1a09  movaps [r15+0x160], xmm15
0000781a8ffd1a11  vmovaps xmm15, [0x0000781A8FBFE050]
0000781a8ffd1a19  vpbroadcastq xmm15, xmm15
0000781a8ffd1a1e  movaps [r15+0x130], xmm15
0000781a8ffd1a26  mov rax, [r15+0x40]
0000781a8ffd1a2a  vmovq xmm14, rax
0000781a8ffd1a2f  vpbroadcastq xmm14, xmm14
0000781a8ffd1a34  movaps [r15+0x170], xmm14
0000781a8ffd1a3c  mov eax, 0x4209D0
0000781a8ffd1a41  movups xmm13, [r13+rax*1]
0000781a8ffd1a47  mov qword ptr [r15+0x40], 0x431D90
0000781a8ffd1a4f  mov eax, [r15]
0000781a8ffd1a52  mov r14d, 0x430C48
0000781a8ffd1a58  mov [r13+r14*1], eax
0000781a8ffd1a5d  mov qword ptr [r15+0x50], 0x431F90
0000781a8ffd1a65  vpmovqd xmm12, xmm13
0000781a8ffd1a6b  pxor xmm11, xmm11
0000781a8ffd1a70  punpcklqdq xmm12, xmm11
0000781a8ffd1a75  movaps [r15+0x210], xmm12
0000781a8ffd1a7d  movq xmm12, qword ptr [r15+0x140]
0000781a8ffd1a86  movq xmm11, qword ptr [r15+0x120]
0000781a8ffd1a8f  psubd xmm12, xmm11
0000781a8ffd1a94  movq xmm12, xmm12
0000781a8ffd1a99  paddq xmm13, xmm14
0000781a8ffd1a9e  movaps [r15+0x180], xmm13
0000781a8ffd1aa6  movq xmm14, qword ptr [r15+0x160]
0000781a8ffd1aaf  paddd xmm11, xmm14
0000781a8ffd1ab4  movq xmm11, xmm11
0000781a8ffd1ab9  movq xmm11, xmm11
0000781a8ffd1abe  movaps [r15+0x120], xmm11
0000781a8ffd1ac6  pmovzxdq xmm12, xmm12
0000781a8ffd1acc  psllq xmm12, 0x00
0000781a8ffd1ad2  movq xmm14, qword ptr [r15+0x210]
0000781a8ffd1adb  movq xmm13, qword ptr [r15+0x110]
0000781a8ffd1ae4  paddd xmm14, xmm13
0000781a8ffd1ae9  movq xmm14, xmm14
0000781a8ffd1aee  vcvtuqq2pd xmm12, xmm12
0000781a8ffd1af4  pmovzxdq xmm14, xmm14
0000781a8ffd1afa  psllq xmm14, 0x00
0000781a8ffd1b00  vcvtuqq2pd xmm14, xmm14
0000781a8ffd1b06  movaps xmm13, xmm12
0000781a8ffd1b0a  mulpd xmm13, xmm1
0000781a8ffd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
0000781a8ffd1b15  ptest xmm11, xmm11
0000781a8ffd1b1b  jnz 0x0000781A8FFD1C0F
0000781a8ffd1b21  movaps [r15+0x220], xmm13
0000781a8ffd1b29  mov eax, 0x431F90
0000781a8ffd1b2e  movups [r13+rax*1], xmm13
0000781a8ffd1b34  movaps xmm1, xmm14
0000781a8ffd1b38  mulpd xmm1, xmm15
0000781a8ffd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
0000781a8ffd1b42  ptest xmm13, xmm13
0000781a8ffd1b48  jnz 0x0000781A8FFD1D5C
0000781a8ffd1b4e  movaps [r15+0x210], xmm1
0000781a8ffd1b56  mov eax, 0x431D90
0000781a8ffd1b5b  movups [r13+rax*1], xmm1
0000781a8ffd1b61  mov qword ptr [r15+0x48], 0x10
0000781a8ffd1b69  xor eax, eax
0000781a8ffd1b6b  mov r14d, 0x10
0000781a8ffd1b71  mov r12d, 0x200
0000781a8ffd1b77  cmp r14, r12
0000781a8ffd1b7a  cmc
0000781a8ffd1b7b  lahf
0000781a8ffd1b7c  seto al
0000781a8ffd1b7f  mov [r15+0x108], eax
0000781a8ffd1b86  mov eax, [r15+0x108]
0000781a8ffd1b8d  sahf
0000781a8ffd1b8e  jnz 0x0000781A8FFD1BC0
0000781a8ffd1b90  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd1b98  jz 0x0000781A8FFD2300
0000781a8ffd1b9e  nop [rax+rax*1], ax
0000781a8ffd1ba7  nop [rax+rax*1], eax
0000781a8ffd1baf  mov eax, 0x410480
0000781a8ffd1bb4  mov [r15+0x100], rax
0000781a8ffd1bbb  jmp 0x0000781A8FDFE110
0000781a8ffd1bc0  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd1bc8  jz 0x0000781A8FFD1EB0
0000781a8ffd1bce  nop [rax+rax*1], ax
0000781a8ffd1bd7  nop [rax+rax*1], eax
0000781a8ffd1bdf  mov eax, 0x410440
0000781a8ffd1be4  mov [r15+0x100], rax
0000781a8ffd1beb  jmp 0x0000781A8FDFE110
0000781a8ffd1bf0  int3
0000781a8ffd1bf1  call 0x0000781A8FE0DC20
0000781a8ffd1bf6  jmp 0x0000781A8FFD19BE
0000781a8ffd1bfb  call 0x0000781A8FE0C260
0000781a8ffd1c00  jmp 0x0000781A8FFD1A47
0000781a8ffd1c05  call 0x0000781A8FED5D70
0000781a8ffd1c0a  jmp 0x0000781A8FFD1A5D
0000781a8ffd1c0f  sub rsp, 0x08
0000781a8ffd1c13  push rax
0000781a8ffd1c14  push rcx
0000781a8ffd1c15  push rdx
0000781a8ffd1c16  push rdi
0000781a8ffd1c17  push rsi
0000781a8ffd1c18  push r8
0000781a8ffd1c1a  push r9
0000781a8ffd1c1c  push r10
0000781a8ffd1c1e  push r11
0000781a8ffd1c20  sub rsp, 0xF0
0000781a8ffd1c27  vmovaps [rsp], xmm0
0000781a8ffd1c2c  vmovaps [rsp+0x10], xmm1
0000781a8ffd1c32  vmovaps [rsp+0x20], xmm2
0000781a8ffd1c38  vmovaps [rsp+0x30], xmm3
0000781a8ffd1c3e  vmovaps [rsp+0x40], xmm4
0000781a8ffd1c44  vmovaps [rsp+0x50], xmm5
0000781a8ffd1c4a  vmovaps [rsp+0x60], xmm6
0000781a8ffd1c50  vmovaps [rsp+0x70], xmm7
0000781a8ffd1c56  vmovaps [rsp+0x80], xmm8
0000781a8ffd1c5f  vmovaps [rsp+0x90], xmm9
0000781a8ffd1c68  vmovaps [rsp+0xA0], xmm10
0000781a8ffd1c71  vmovaps [rsp+0xB0], xmm11
0000781a8ffd1c7a  vmovaps [rsp+0xC0], xmm12
0000781a8ffd1c83  vmovaps [rsp+0xD0], xmm14
0000781a8ffd1c8c  vmovaps [rsp+0xE0], xmm15
0000781a8ffd1c95  sub rsp, 0x30
0000781a8ffd1c99  movaps [rsp], xmm13
0000781a8ffd1c9e  movaps [rsp+0x10], xmm12
0000781a8ffd1ca4  movaps [rsp+0x20], xmm1
0000781a8ffd1ca9  lea rdi, [rsp]
0000781a8ffd1cad  mov esi, 0x00
0000781a8ffd1cb2  mov rax, 0x627DDC279530
0000781a8ffd1cbc  call rax
0000781a8ffd1cbe  movaps xmm13, [rsp]
0000781a8ffd1cc3  add rsp, 0x30
0000781a8ffd1cc7  vmovaps xmm0, [rsp]
0000781a8ffd1ccc  vmovaps xmm1, [rsp+0x10]
0000781a8ffd1cd2  vmovaps xmm2, [rsp+0x20]
0000781a8ffd1cd8  vmovaps xmm3, [rsp+0x30]
0000781a8ffd1cde  vmovaps xmm4, [rsp+0x40]
0000781a8ffd1ce4  vmovaps xmm5, [rsp+0x50]
0000781a8ffd1cea  vmovaps xmm6, [rsp+0x60]
0000781a8ffd1cf0  vmovaps xmm7, [rsp+0x70]
0000781a8ffd1cf6  vmovaps xmm8, [rsp+0x80]
0000781a8ffd1cff  vmovaps xmm9, [rsp+0x90]
0000781a8ffd1d08  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd1d11  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd1d1a  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd1d23  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd1d2c  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd1d35  add rsp, 0xF0
0000781a8ffd1d3c  pop r11
0000781a8ffd1d3e  pop r10
0000781a8ffd1d40  pop r9
0000781a8ffd1d42  pop r8
0000781a8ffd1d44  pop rsi
0000781a8ffd1d45  pop rdi
0000781a8ffd1d46  pop rdx
0000781a8ffd1d47  pop rcx
0000781a8ffd1d48  pop rax
0000781a8ffd1d49  add rsp, 0x08
0000781a8ffd1d4d  jmp 0x0000781A8FFD1B21
0000781a8ffd1d52  call 0x0000781A8FE0C380
0000781a8ffd1d57  jmp 0x0000781A8FFD1B34
0000781a8ffd1d5c  sub rsp, 0x08
0000781a8ffd1d60  push rax
0000781a8ffd1d61  push rcx
0000781a8ffd1d62  push rdx
0000781a8ffd1d63  push rdi
0000781a8ffd1d64  push rsi
0000781a8ffd1d65  push r8
0000781a8ffd1d67  push r9
0000781a8ffd1d69  push r10
0000781a8ffd1d6b  push r11
0000781a8ffd1d6d  sub rsp, 0xF0
0000781a8ffd1d74  vmovaps [rsp], xmm0
0000781a8ffd1d79  vmovaps [rsp+0x10], xmm2
0000781a8ffd1d7f  vmovaps [rsp+0x20], xmm3
0000781a8ffd1d85  vmovaps [rsp+0x30], xmm4
0000781a8ffd1d8b  vmovaps [rsp+0x40], xmm5
0000781a8ffd1d91  vmovaps [rsp+0x50], xmm6
0000781a8ffd1d97  vmovaps [rsp+0x60], xmm7
0000781a8ffd1d9d  vmovaps [rsp+0x70], xmm8
0000781a8ffd1da3  vmovaps [rsp+0x80], xmm9
0000781a8ffd1dac  vmovaps [rsp+0x90], xmm10
0000781a8ffd1db5  vmovaps [rsp+0xA0], xmm11
0000781a8ffd1dbe  vmovaps [rsp+0xB0], xmm12
0000781a8ffd1dc7  vmovaps [rsp+0xC0], xmm13
0000781a8ffd1dd0  vmovaps [rsp+0xD0], xmm14
0000781a8ffd1dd9  vmovaps [rsp+0xE0], xmm15
0000781a8ffd1de2  sub rsp, 0x30
0000781a8ffd1de6  movaps [rsp], xmm1
0000781a8ffd1dea  movaps [rsp+0x10], xmm14
0000781a8ffd1df0  movaps [rsp+0x20], xmm15
0000781a8ffd1df6  lea rdi, [rsp]
0000781a8ffd1dfa  mov esi, 0x00
0000781a8ffd1dff  mov rax, 0x627DDC279530
0000781a8ffd1e09  call rax
0000781a8ffd1e0b  movaps xmm1, [rsp]
0000781a8ffd1e0f  add rsp, 0x30
0000781a8ffd1e13  vmovaps xmm0, [rsp]
0000781a8ffd1e18  vmovaps xmm2, [rsp+0x10]
0000781a8ffd1e1e  vmovaps xmm3, [rsp+0x20]
0000781a8ffd1e24  vmovaps xmm4, [rsp+0x30]
0000781a8ffd1e2a  vmovaps xmm5, [rsp+0x40]
0000781a8ffd1e30  vmovaps xmm6, [rsp+0x50]
0000781a8ffd1e36  vmovaps xmm7, [rsp+0x60]
0000781a8ffd1e3c  vmovaps xmm8, [rsp+0x70]
0000781a8ffd1e42  vmovaps xmm9, [rsp+0x80]
0000781a8ffd1e4b  vmovaps xmm10, [rsp+0x90]
0000781a8ffd1e54  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd1e5d  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd1e66  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd1e6f  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd1e78  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd1e81  add rsp, 0xF0
0000781a8ffd1e88  pop r11
0000781a8ffd1e8a  pop r10
0000781a8ffd1e8c  pop r9
0000781a8ffd1e8e  pop r8
0000781a8ffd1e90  pop rsi
0000781a8ffd1e91  pop rdi
0000781a8ffd1e92  pop rdx
0000781a8ffd1e93  pop rcx
0000781a8ffd1e94  pop rax
0000781a8ffd1e95  add rsp, 0x08
0000781a8ffd1e99  jmp 0x0000781A8FFD1B4E
0000781a8ffd1e9e  call 0x0000781A8FDFF540
0000781a8ffd1ea3  jmp 0x0000781A8FFD1B61
0000781a8ffd1ea8  int3
0000781a8ffd1ea9  nop [rax], eax
0000781a8ffd1eb0  movaps xmm1, [r15+0x180]
0000781a8ffd1eb8  vpmovqd xmm15, xmm1
0000781a8ffd1ebe  pxor xmm14, xmm14
0000781a8ffd1ec3  punpcklqdq xmm15, xmm14
0000781a8ffd1ec8  movaps [r15+0x210], xmm15
0000781a8ffd1ed0  movq xmm15, qword ptr [r15+0x140]
0000781a8ffd1ed9  movq xmm14, qword ptr [r15+0x120]
0000781a8ffd1ee2  psubd xmm15, xmm14
0000781a8ffd1ee7  movq xmm15, xmm15
0000781a8ffd1eec  movaps xmm13, [r15+0x170]
0000781a8ffd1ef4  paddq xmm1, xmm13
0000781a8ffd1ef9  movaps [r15+0x180], xmm1
0000781a8ffd1f01  movq xmm1, qword ptr [r15+0x160]
0000781a8ffd1f0a  paddd xmm14, xmm1
0000781a8ffd1f0f  movq xmm14, xmm14
0000781a8ffd1f14  movq xmm14, xmm14
0000781a8ffd1f19  movaps [r15+0x120], xmm14
0000781a8ffd1f21  pmovzxdq xmm15, xmm15
0000781a8ffd1f27  psllq xmm15, 0x00
0000781a8ffd1f2d  movq xmm1, qword ptr [r15+0x210]
0000781a8ffd1f36  movq xmm14, qword ptr [r15+0x110]
0000781a8ffd1f3f  paddd xmm1, xmm14
0000781a8ffd1f44  movq xmm1, xmm1
0000781a8ffd1f48  vcvtuqq2pd xmm15, xmm15
0000781a8ffd1f4e  pmovzxdq xmm1, xmm1
0000781a8ffd1f53  psllq xmm1, 0x00
0000781a8ffd1f58  vcvtuqq2pd xmm1, xmm1
0000781a8ffd1f5e  movaps xmm14, [r15+0x150]
0000781a8ffd1f66  movaps xmm13, xmm15
0000781a8ffd1f6a  mulpd xmm13, xmm14
0000781a8ffd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd1f75  ptest xmm12, xmm12
0000781a8ffd1f7b  jnz 0x0000781A8FFD205E
0000781a8ffd1f81  movaps [r15+0x220], xmm13
0000781a8ffd1f89  mov rax, [r15+0x48]
0000781a8ffd1f8d  mov r14, [r15+0x50]
0000781a8ffd1f91  lea r12, [r14+rax*1]
0000781a8ffd1f95  movups [r13+r12*1], xmm13
0000781a8ffd1f9b  movaps xmm15, [r15+0x130]
0000781a8ffd1fa3  movaps xmm14, xmm1
0000781a8ffd1fa7  mulpd xmm14, xmm15
0000781a8ffd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
0000781a8ffd1fb2  ptest xmm13, xmm13
0000781a8ffd1fb8  jnz 0x0000781A8FFD21AC
0000781a8ffd1fbe  movaps [r15+0x210], xmm14
0000781a8ffd1fc6  mov r14, [r15+0x40]
0000781a8ffd1fca  lea r12, [r14+rax*1]
0000781a8ffd1fce  movups [r13+r12*1], xmm14
0000781a8ffd1fd4  lea r14, [rax+0x10]
0000781a8ffd1fd8  mov [r15+0x48], r14
0000781a8ffd1fdc  xor eax, eax
0000781a8ffd1fde  mov r12d, 0x200
0000781a8ffd1fe4  cmp r14, r12
0000781a8ffd1fe7  cmc
0000781a8ffd1fe8  lahf
0000781a8ffd1fe9  seto al
0000781a8ffd1fec  mov [r15+0x108], eax
0000781a8ffd1ff3  mov eax, [r15+0x108]
0000781a8ffd1ffa  sahf
0000781a8ffd1ffb  jnz 0x0000781A8FFD202D
0000781a8ffd1ffd  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd2005  jz 0x0000781A8FFD2300
0000781a8ffd200b  nop [rax+rax*1], ax
0000781a8ffd2014  nop [rax+rax*1], eax
0000781a8ffd201c  mov eax, 0x410480
0000781a8ffd2021  mov [r15+0x100], rax
0000781a8ffd2028  jmp 0x0000781A8FDFE110
0000781a8ffd202d  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd2035  jz 0x0000781A8FFD1EB0
0000781a8ffd203b  nop [rax+rax*1], ax
0000781a8ffd2044  nop [rax+rax*1], eax
0000781a8ffd204c  mov eax, 0x410440
0000781a8ffd2051  mov [r15+0x100], rax
0000781a8ffd2058  jmp 0x0000781A8FDFE110
0000781a8ffd205d  int3
0000781a8ffd205e  sub rsp, 0x08
0000781a8ffd2062  push rax
0000781a8ffd2063  push rcx
0000781a8ffd2064  push rdx
0000781a8ffd2065  push rdi
0000781a8ffd2066  push rsi
0000781a8ffd2067  push r8
0000781a8ffd2069  push r9
0000781a8ffd206b  push r10
0000781a8ffd206d  push r11
0000781a8ffd206f  sub rsp, 0xF0
0000781a8ffd2076  vmovaps [rsp], xmm0
0000781a8ffd207b  vmovaps [rsp+0x10], xmm1
0000781a8ffd2081  vmovaps [rsp+0x20], xmm2
0000781a8ffd2087  vmovaps [rsp+0x30], xmm3
0000781a8ffd208d  vmovaps [rsp+0x40], xmm4
0000781a8ffd2093  vmovaps [rsp+0x50], xmm5
0000781a8ffd2099  vmovaps [rsp+0x60], xmm6
0000781a8ffd209f  vmovaps [rsp+0x70], xmm7
0000781a8ffd20a5  vmovaps [rsp+0x80], xmm8
0000781a8ffd20ae  vmovaps [rsp+0x90], xmm9
0000781a8ffd20b7  vmovaps [rsp+0xA0], xmm10
0000781a8ffd20c0  vmovaps [rsp+0xB0], xmm11
0000781a8ffd20c9  vmovaps [rsp+0xC0], xmm12
0000781a8ffd20d2  vmovaps [rsp+0xD0], xmm14
0000781a8ffd20db  vmovaps [rsp+0xE0], xmm15
0000781a8ffd20e4  sub rsp, 0x30
0000781a8ffd20e8  movaps [rsp], xmm13
0000781a8ffd20ed  movaps [rsp+0x10], xmm15
0000781a8ffd20f3  movaps [rsp+0x20], xmm14
0000781a8ffd20f9  lea rdi, [rsp]
0000781a8ffd20fd  mov esi, 0x00
0000781a8ffd2102  mov rax, 0x627DDC279530
0000781a8ffd210c  call rax
0000781a8ffd210e  movaps xmm13, [rsp]
0000781a8ffd2113  add rsp, 0x30
0000781a8ffd2117  vmovaps xmm0, [rsp]
0000781a8ffd211c  vmovaps xmm1, [rsp+0x10]
0000781a8ffd2122  vmovaps xmm2, [rsp+0x20]
0000781a8ffd2128  vmovaps xmm3, [rsp+0x30]
0000781a8ffd212e  vmovaps xmm4, [rsp+0x40]
0000781a8ffd2134  vmovaps xmm5, [rsp+0x50]
0000781a8ffd213a  vmovaps xmm6, [rsp+0x60]
0000781a8ffd2140  vmovaps xmm7, [rsp+0x70]
0000781a8ffd2146  vmovaps xmm8, [rsp+0x80]
0000781a8ffd214f  vmovaps xmm9, [rsp+0x90]
0000781a8ffd2158  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd2161  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd216a  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd2173  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd217c  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd2185  add rsp, 0xF0
0000781a8ffd218c  pop r11
0000781a8ffd218e  pop r10
0000781a8ffd2190  pop r9
0000781a8ffd2192  pop r8
0000781a8ffd2194  pop rsi
0000781a8ffd2195  pop rdi
0000781a8ffd2196  pop rdx
0000781a8ffd2197  pop rcx
0000781a8ffd2198  pop rax
0000781a8ffd2199  add rsp, 0x08
0000781a8ffd219d  jmp 0x0000781A8FFD1F81
0000781a8ffd21a2  call 0x0000781A8FEC2240
0000781a8ffd21a7  jmp 0x0000781A8FFD1F9B
0000781a8ffd21ac  sub rsp, 0x08
0000781a8ffd21b0  push rax
0000781a8ffd21b1  push rcx
0000781a8ffd21b2  push rdx
0000781a8ffd21b3  push rdi
0000781a8ffd21b4  push rsi
0000781a8ffd21b5  push r8
0000781a8ffd21b7  push r9
0000781a8ffd21b9  push r10
0000781a8ffd21bb  push r11
0000781a8ffd21bd  sub rsp, 0xF0
0000781a8ffd21c4  vmovaps [rsp], xmm0
0000781a8ffd21c9  vmovaps [rsp+0x10], xmm1
0000781a8ffd21cf  vmovaps [rsp+0x20], xmm2
0000781a8ffd21d5  vmovaps [rsp+0x30], xmm3
0000781a8ffd21db  vmovaps [rsp+0x40], xmm4
0000781a8ffd21e1  vmovaps [rsp+0x50], xmm5
0000781a8ffd21e7  vmovaps [rsp+0x60], xmm6
0000781a8ffd21ed  vmovaps [rsp+0x70], xmm7
0000781a8ffd21f3  vmovaps [rsp+0x80], xmm8
0000781a8ffd21fc  vmovaps [rsp+0x90], xmm9
0000781a8ffd2205  vmovaps [rsp+0xA0], xmm10
0000781a8ffd220e  vmovaps [rsp+0xB0], xmm11
0000781a8ffd2217  vmovaps [rsp+0xC0], xmm12
0000781a8ffd2220  vmovaps [rsp+0xD0], xmm13
0000781a8ffd2229  vmovaps [rsp+0xE0], xmm15
0000781a8ffd2232  sub rsp, 0x30
0000781a8ffd2236  movaps [rsp], xmm14
0000781a8ffd223b  movaps [rsp+0x10], xmm1
0000781a8ffd2240  movaps [rsp+0x20], xmm15
0000781a8ffd2246  lea rdi, [rsp]
0000781a8ffd224a  mov esi, 0x00
0000781a8ffd224f  mov rax, 0x627DDC279530
0000781a8ffd2259  call rax
0000781a8ffd225b  movaps xmm14, [rsp]
0000781a8ffd2260  add rsp, 0x30
0000781a8ffd2264  vmovaps xmm0, [rsp]
0000781a8ffd2269  vmovaps xmm1, [rsp+0x10]
0000781a8ffd226f  vmovaps xmm2, [rsp+0x20]
0000781a8ffd2275  vmovaps xmm3, [rsp+0x30]
0000781a8ffd227b  vmovaps xmm4, [rsp+0x40]
0000781a8ffd2281  vmovaps xmm5, [rsp+0x50]
0000781a8ffd2287  vmovaps xmm6, [rsp+0x60]
0000781a8ffd228d  vmovaps xmm7, [rsp+0x70]
0000781a8ffd2293  vmovaps xmm8, [rsp+0x80]
0000781a8ffd229c  vmovaps xmm9, [rsp+0x90]
0000781a8ffd22a5  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd22ae  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd22b7  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd22c0  vmovaps xmm13, [rsp+0xD0]
0000781a8ffd22c9  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd22d2  add rsp, 0xF0
0000781a8ffd22d9  pop r11
0000781a8ffd22db  pop r10
0000781a8ffd22dd  pop r9
0000781a8ffd22df  pop r8
0000781a8ffd22e1  pop rsi
0000781a8ffd22e2  pop rdi
0000781a8ffd22e3  pop rdx
0000781a8ffd22e4  pop rcx
0000781a8ffd22e5  pop rax
0000781a8ffd22e6  add rsp, 0x08
0000781a8ffd22ea  jmp 0x0000781A8FFD1FBE
0000781a8ffd22ef  call 0x0000781A8FEC34C0
0000781a8ffd22f4  jmp 0x0000781A8FFD1FD4
0000781a8ffd22f9  int3
0000781a8ffd22fa  nop [rax+rax*1], ax
0000781a8ffd2300  mov rax, [r15+0x50]
0000781a8ffd2304  movups xmm1, [r13+rax*1]
0000781a8ffd230a  lea r14, [rax+0x10]
0000781a8ffd230e  movups xmm15, [r13+r14*1]
0000781a8ffd2314  mov qword ptr [r15+0x48], 0x00
0000781a8ffd231c  lea r14, [rax+0x40]
0000781a8ffd2320  movups xmm14, [r13+r14*1]
0000781a8ffd2326  lea r14, [rax+0x50]
0000781a8ffd232a  movups xmm13, [r13+r14*1]
0000781a8ffd2330  lea r14, [rax+0x80]
0000781a8ffd2337  movups xmm12, [r13+r14*1]
0000781a8ffd233d  lea r14, [rax+0x90]
0000781a8ffd2344  movups xmm11, [r13+r14*1]
0000781a8ffd234a  mov r14, [r15+0xF8]
0000781a8ffd2351  movups [r13+r14*1], xmm1
0000781a8ffd2357  lea r12, [rax+0x20]
0000781a8ffd235b  movups xmm1, [r13+r12*1]
0000781a8ffd2361  lea r12, [rax+0x30]
0000781a8ffd2365  movups xmm10, [r13+r12*1]
0000781a8ffd236b  lea r12, [rax+0xC0]
0000781a8ffd2372  movups xmm9, [r13+r12*1]
0000781a8ffd2378  lea r12, [rax+0xD0]
0000781a8ffd237f  movups xmm8, [r13+r12*1]
0000781a8ffd2385  lea r12, [rax+0x100]
0000781a8ffd238c  movups xmm7, [r13+r12*1]
0000781a8ffd2392  lea r12, [rax+0x110]
0000781a8ffd2399  movups xmm6, [r13+r12*1]
0000781a8ffd239f  lea r12, [rax+0x140]
0000781a8ffd23a6  movups xmm5, [r13+r12*1]
0000781a8ffd23ac  lea r12, [rax+0x150]
0000781a8ffd23b3  movups xmm4, [r13+r12*1]
0000781a8ffd23b9  lea r12, [r14+0xB0]
0000781a8ffd23c0  movups [r13+r12*1], xmm10
0000781a8ffd23c6  lea r12, [r14+0xC0]
0000781a8ffd23cd  movups [r13+r12*1], xmm1
0000781a8ffd23d3  lea r12, [rax+0x180]
0000781a8ffd23da  movups xmm1, [r13+r12*1]
0000781a8ffd23e0  lea r12, [rax+0x190]
0000781a8ffd23e7  movups xmm10, [r13+r12*1]
0000781a8ffd23ed  lea r12, [rax+0x1C0]
0000781a8ffd23f4  movups xmm3, [r13+r12*1]
0000781a8ffd23fa  lea r12, [rax+0x1D0]
0000781a8ffd2401  movups xmm2, [r13+r12*1]
0000781a8ffd2407  lea r12, [rax+0x60]
0000781a8ffd240b  vmovaps [rsp+0x10], xmm1
0000781a8ffd2411  movups xmm1, [r13+r12*1]
0000781a8ffd2417  lea r12, [rax+0x70]
0000781a8ffd241b  vmovaps [rsp+0x20], xmm1
0000781a8ffd2421  movups xmm1, [r13+r12*1]
0000781a8ffd2427  lea r12, [r14+0x70]
0000781a8ffd242b  movups [r13+r12*1], xmm10
0000781a8ffd2431  lea r12, [r14+0x80]
0000781a8ffd2438  vmovaps xmm10, [rsp+0x10]
0000781a8ffd243e  movups [r13+r12*1], xmm10
0000781a8ffd2444  lea r12, [rax+0xA0]
0000781a8ffd244b  movups xmm10, [r13+r12*1]
0000781a8ffd2451  lea r12, [rax+0xB0]
0000781a8ffd2458  vmovaps [rsp+0x10], xmm1
0000781a8ffd245e  movups xmm1, [r13+r12*1]
0000781a8ffd2464  lea r12, [r14+0x90]
0000781a8ffd246b  movups [r13+r12*1], xmm2
0000781a8ffd2471  lea r12, [r14+0xA0]
0000781a8ffd2478  movups [r13+r12*1], xmm3
0000781a8ffd247e  lea r12, [rax+0xE0]
0000781a8ffd2485  movups xmm3, [r13+r12*1]
0000781a8ffd248b  lea r12, [rax+0xF0]
0000781a8ffd2492  movups xmm2, [r13+r12*1]
0000781a8ffd2498  lea r12, [rax+0x120]
0000781a8ffd249f  vmovaps [rsp+0x30], xmm1
0000781a8ffd24a5  movups xmm1, [r13+r12*1]
0000781a8ffd24ab  lea r12, [rax+0x130]
0000781a8ffd24b2  vmovaps [rsp+0x40], xmm1
0000781a8ffd24b8  movups xmm1, [r13+r12*1]
0000781a8ffd24be  vmovaps [rsp+0x50], xmm1
0000781a8ffd24c4  vmovaps xmm1, [rsp+0x40]
0000781a8ffd24ca  movaps [r15+0x190], xmm1
0000781a8ffd24d2  lea r12, [rax+0x160]
0000781a8ffd24d9  vmovaps [rsp+0x40], xmm1
0000781a8ffd24df  movups xmm1, [r13+r12*1]
0000781a8ffd24e5  lea r12, [rax+0x170]
0000781a8ffd24ec  vmovaps [rsp+0x60], xmm1
0000781a8ffd24f2  movups xmm1, [r13+r12*1]
0000781a8ffd24f8  lea r12, [rax+0x1A0]
0000781a8ffd24ff  vmovaps [rsp+0x70], xmm1
0000781a8ffd2505  movups xmm1, [r13+r12*1]
0000781a8ffd250b  lea r12, [rax+0x1B0]
0000781a8ffd2512  vmovaps [rsp+0x80], xmm1
0000781a8ffd251b  movups xmm1, [r13+r12*1]
0000781a8ffd2521  lea r12, [rax+0x1E0]
0000781a8ffd2528  vmovaps [rsp+0x90], xmm1
0000781a8ffd2531  movups xmm1, [r13+r12*1]
0000781a8ffd2537  lea r12, [rax+0x1F0]
0000781a8ffd253e  vmovaps [rsp+0xA0], xmm1
0000781a8ffd2547  movups xmm1, [r13+r12*1]
0000781a8ffd254d  mov qword ptr [r15+0x50], 0x432190
0000781a8ffd2555  lea rax, [r14+0x50]
0000781a8ffd2559  vmovaps [rsp+0xB0], xmm1
0000781a8ffd2562  vmovaps xmm1, [rsp+0x60]
0000781a8ffd2568  movups [r13+rax*1], xmm1
0000781a8ffd256e  lea rax, [r14+0x60]
0000781a8ffd2572  movups [r13+rax*1], xmm5
0000781a8ffd2578  lea rax, [r14+0x40]
0000781a8ffd257c  vmovaps xmm1, [rsp+0x70]
0000781a8ffd2582  movups [r13+rax*1], xmm1
0000781a8ffd2588  lea rax, [r14+0x20]
0000781a8ffd258c  vmovaps xmm1, [rsp+0xA0]
0000781a8ffd2595  movups [r13+rax*1], xmm1
0000781a8ffd259b  lea rax, [r14+0x30]
0000781a8ffd259f  vmovaps xmm1, [rsp+0x90]
0000781a8ffd25a8  movups [r13+rax*1], xmm1
0000781a8ffd25ae  lea rax, [r14+0x10]
0000781a8ffd25b2  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd25bb  movups [r13+rax*1], xmm1
0000781a8ffd25c1  mov rax, [r15+0x40]
0000781a8ffd25c5  vxorps xmm1, xmm1, xmm1
0000781a8ffd25c9  vpbroadcastq xmm1, xmm1
0000781a8ffd25ce  vxorps xmm5, xmm5, xmm5
0000781a8ffd25d2  vpbroadcastq xmm5, xmm5
0000781a8ffd25d7  lea r12, [rax+0x30]
0000781a8ffd25db  mov r11, [r13+r12*1]
0000781a8ffd25e0  lea r12, [rax+0x38]
0000781a8ffd25e4  mov r10, [r13+r12*1]
0000781a8ffd25e9  vmovaps [rsp+0x60], xmm1
0000781a8ffd25ef  movq xmm1, r11
0000781a8ffd25f4  vmovaps [rsp+0x70], xmm1
0000781a8ffd25fa  movq xmm1, r10
0000781a8ffd25ff  vmovaps [rsp+0x90], xmm1
0000781a8ffd2608  vmovaps xmm1, [rsp+0x70]
0000781a8ffd260e  movq xmm1, xmm1
0000781a8ffd2612  vmovaps [rsp+0x70], xmm1
0000781a8ffd2618  vmovaps xmm1, [rsp+0x90]
0000781a8ffd2621  movq xmm1, xmm1
0000781a8ffd2625  vmovaps [rsp+0x90], xmm1
0000781a8ffd262e  movq xmm1, xmm1
0000781a8ffd2632  movaps [r15+0x270], xmm1
0000781a8ffd263a  vmovaps [rsp+0xA0], xmm7
0000781a8ffd2643  vmovaps xmm1, [rsp+0xA0]
0000781a8ffd264c  por xmm7, xmm1
0000781a8ffd2650  lea r12, [rax+0x20]
0000781a8ffd2654  mov r11, [r13+r12*1]
0000781a8ffd2659  lea r12, [rax+0x28]
0000781a8ffd265d  mov r10, [r13+r12*1]
0000781a8ffd2662  movq xmm1, r11
0000781a8ffd2667  vmovaps [rsp+0xA0], xmm1
0000781a8ffd2670  movq xmm1, r10
0000781a8ffd2675  vmovaps [rsp+0xB0], xmm1
0000781a8ffd267e  vmovaps xmm1, [rsp+0xA0]
0000781a8ffd2687  movq xmm1, xmm1
0000781a8ffd268b  vmovaps [rsp+0xA0], xmm1
0000781a8ffd2694  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd269d  movq xmm1, xmm1
0000781a8ffd26a1  vmovaps [rsp+0xB0], xmm2
0000781a8ffd26aa  vmovaps [rsp+0xC0], xmm1
0000781a8ffd26b3  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd26bc  por xmm2, xmm1
0000781a8ffd26c0  vmovaps [rsp+0xB0], xmm3
0000781a8ffd26c9  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd26d2  por xmm3, xmm1
0000781a8ffd26d6  vmovaps [rsp+0xB0], xmm4
0000781a8ffd26df  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd26e8  por xmm4, xmm1
0000781a8ffd26ec  vmovaps [rsp+0xB0], xmm9
0000781a8ffd26f5  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd26fe  por xmm9, xmm1
0000781a8ffd2703  lea r12, [rax+0x10]
0000781a8ffd2707  mov r11, [r13+r12*1]
0000781a8ffd270c  lea r12, [rax+0x18]
0000781a8ffd2710  mov r10, [r13+r12*1]
0000781a8ffd2715  movq xmm1, r11
0000781a8ffd271a  vmovaps [rsp+0xB0], xmm1
0000781a8ffd2723  movq xmm1, r10
0000781a8ffd2728  vmovaps [rsp+0xD0], xmm1
0000781a8ffd2731  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd273a  movq xmm1, xmm1
0000781a8ffd273e  vmovaps [rsp+0xB0], xmm1
0000781a8ffd2747  vmovaps xmm1, [rsp+0xD0]
0000781a8ffd2750  movq xmm1, xmm1
0000781a8ffd2754  vmovaps [rsp+0xD0], xmm1
0000781a8ffd275d  vmovaps xmm1, [rsp+0x80]
0000781a8ffd2766  vmovaps [rsp+0xE0], xmm15
0000781a8ffd276f  vmovaps xmm15, [rsp+0x80]
0000781a8ffd2778  por xmm1, xmm15
0000781a8ffd277d  vmovaps xmm15, [rsp+0x10]
0000781a8ffd2783  vmovaps [rsp+0x80], xmm1
0000781a8ffd278c  vmovaps xmm1, [rsp+0x10]
0000781a8ffd2792  por xmm15, xmm1
0000781a8ffd2797  vmovaps xmm1, [rsp+0x20]
0000781a8ffd279d  vmovaps [rsp+0x10], xmm15
0000781a8ffd27a3  vmovaps xmm15, [rsp+0x20]
0000781a8ffd27a9  por xmm1, xmm15
0000781a8ffd27ae  vmovaps [rsp+0x20], xmm6
0000781a8ffd27b4  vmovaps xmm15, [rsp+0x20]
0000781a8ffd27ba  por xmm6, xmm15
0000781a8ffd27bf  vmovaps [rsp+0x20], xmm11
0000781a8ffd27c5  vmovaps xmm15, [rsp+0x20]
0000781a8ffd27cb  por xmm11, xmm15
0000781a8ffd27d0  vmovaps [rsp+0x20], xmm13
0000781a8ffd27d6  vmovaps xmm15, [rsp+0x20]
0000781a8ffd27dc  por xmm13, xmm15
0000781a8ffd27e1  vmovaps [rsp+0x20], xmm14
0000781a8ffd27e7  vmovaps xmm15, [rsp+0x20]
0000781a8ffd27ed  por xmm14, xmm15
0000781a8ffd27f2  mov r12, [r13+rax*1]
0000781a8ffd27f7  vmovq xmm15, r12
0000781a8ffd27fc  vpbroadcastq xmm15, xmm15
0000781a8ffd2801  vmovaps [rsp+0x20], xmm1
0000781a8ffd2807  vxorps xmm1, xmm1, xmm1
0000781a8ffd280b  vpbroadcastq xmm1, xmm1
0000781a8ffd2810  vmovaps [rsp+0xF0], xmm1
0000781a8ffd2819  movups xmm1, [r13+r14*1]
0000781a8ffd281f  vmovaps [rsp+0x100], xmm1
0000781a8ffd2828  vxorps xmm1, xmm1, xmm1
0000781a8ffd282c  vpbroadcastq xmm1, xmm1
0000781a8ffd2831  lea r12, [rax+0x08]
0000781a8ffd2835  mov rax, [r13+r12*1]
0000781a8ffd283a  vmovaps [rsp+0x110], xmm1
0000781a8ffd2843  movq xmm1, rax
0000781a8ffd2848  movaps [r15+0x240], xmm1
0000781a8ffd2850  mov qword ptr [r15+0x60], 0x432190
0000781a8ffd2858  mov qword ptr [r15+0x58], 0x40
0000781a8ffd2860  vmovaps xmm1, [rsp+0x60]
0000781a8ffd2866  vmovaps [rsp+0x60], xmm15
0000781a8ffd286c  vmovaps xmm15, [rsp+0x100]
0000781a8ffd2875  vmovaps [rsp+0x100], xmm14
0000781a8ffd287e  vmovaps xmm14, [rsp+0x60]
0000781a8ffd2884  vmovaps [rsp+0x60], xmm13
0000781a8ffd288a  vmovaps [rsp+0x120], xmm12
0000781a8ffd2893  movaps xmm13, xmm1
0000781a8ffd2897  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd289c  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd28a2  vptest xmm12, xmm12
0000781a8ffd28a7  jnz 0x0000781A8FFD3482
0000781a8ffd28ad  vmovaps xmm1, [rsp+0xE0]
0000781a8ffd28b6  movaps xmm15, xmm5
0000781a8ffd28ba  vfmadd231pd xmm15, xmm1, xmm14
0000781a8ffd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
0000781a8ffd28c5  vptest xmm12, xmm12
0000781a8ffd28ca  jnz 0x0000781A8FFD35DB
0000781a8ffd28d0  vmovaps xmm12, [rsp+0x50]
0000781a8ffd28d6  vmovaps xmm5, [rsp+0x50]
0000781a8ffd28dc  por xmm12, xmm5
0000781a8ffd28e1  vmovaps xmm5, [rsp+0x30]
0000781a8ffd28e7  vmovaps [rsp+0x50], xmm1
0000781a8ffd28ed  vmovaps xmm1, [rsp+0x30]
0000781a8ffd28f3  por xmm5, xmm1
0000781a8ffd28f7  vmovaps [rsp+0x30], xmm10
0000781a8ffd28fd  vmovaps xmm1, [rsp+0x30]
0000781a8ffd2903  por xmm10, xmm1
0000781a8ffd2908  vmovaps [rsp+0x30], xmm8
0000781a8ffd290e  vmovaps xmm1, [rsp+0x30]
0000781a8ffd2914  por xmm8, xmm1
0000781a8ffd2919  vmovaps xmm1, [rsp+0x120]
0000781a8ffd2922  vmovaps [rsp+0x30], xmm15
0000781a8ffd2928  vmovaps xmm15, [rsp+0x120]
0000781a8ffd2931  por xmm1, xmm15
0000781a8ffd2936  vmovaps xmm15, [rsp+0x50]
0000781a8ffd293c  vmovaps [rsp+0xE0], xmm1
0000781a8ffd2945  vmovaps xmm1, [rsp+0x50]
0000781a8ffd294b  por xmm15, xmm1
0000781a8ffd2950  lea rax, [r14+0xC0]
0000781a8ffd2957  movups xmm1, [r13+rax*1]
0000781a8ffd295d  xor eax, eax
0000781a8ffd295f  mov r12d, 0x40
0000781a8ffd2965  mov r11d, 0x200
0000781a8ffd296b  cmp r12, r11
0000781a8ffd296e  cmc
0000781a8ffd296f  lahf
0000781a8ffd2970  seto al
0000781a8ffd2973  mov [r15+0x108], eax
0000781a8ffd297a  vmovaps [rsp+0x50], xmm1
0000781a8ffd2980  vmovaps xmm1, [rsp+0xF0]
0000781a8ffd2989  vmovaps [rsp+0xF0], xmm15
0000781a8ffd2992  vmovaps xmm15, [rsp+0x50]
0000781a8ffd2998  vmovaps [rsp+0x50], xmm13
0000781a8ffd299e  vmovaps [rsp+0x120], xmm12
0000781a8ffd29a7  movaps xmm13, xmm1
0000781a8ffd29ab  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd29b6  vptest xmm12, xmm12
0000781a8ffd29bb  jnz 0x0000781A8FFD373D
0000781a8ffd29c1  lea rax, [r14+0xB0]
0000781a8ffd29c8  movups xmm1, [r13+rax*1]
0000781a8ffd29ce  vmovaps xmm15, [rsp+0x110]
0000781a8ffd29d7  vmovaps [rsp+0x110], xmm13
0000781a8ffd29e0  movaps xmm12, xmm15
0000781a8ffd29e4  vfmadd231pd xmm12, xmm1, xmm14
0000781a8ffd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
0000781a8ffd29ef  vptest xmm13, xmm13
0000781a8ffd29f4  jnz 0x0000781A8FFD38A0
0000781a8ffd29fa  vmovaps xmm1, [rsp+0x100]
0000781a8ffd2a03  vmovaps xmm15, [rsp+0x100]
0000781a8ffd2a0c  por xmm1, xmm15
0000781a8ffd2a11  movaps [r15+0x210], xmm1
0000781a8ffd2a19  vmovaps xmm15, [rsp+0x60]
0000781a8ffd2a1f  vmovaps xmm14, [rsp+0x60]
0000781a8ffd2a25  por xmm15, xmm14
0000781a8ffd2a2a  movaps [r15+0x1C0], xmm15
0000781a8ffd2a32  vmovaps [rsp+0x60], xmm11
0000781a8ffd2a38  vmovaps xmm14, [rsp+0x60]
0000781a8ffd2a3e  por xmm11, xmm14
0000781a8ffd2a43  movaps [r15+0x280], xmm11
0000781a8ffd2a4b  vmovaps [rsp+0x60], xmm6
0000781a8ffd2a51  vmovaps xmm14, [rsp+0x60]
0000781a8ffd2a57  por xmm6, xmm14
0000781a8ffd2a5c  movaps [r15+0x2A0], xmm6
0000781a8ffd2a64  vmovaps xmm14, [rsp+0x20]
0000781a8ffd2a6a  vmovaps xmm13, [rsp+0x20]
0000781a8ffd2a70  por xmm14, xmm13
0000781a8ffd2a75  movaps [r15+0x2E0], xmm14
0000781a8ffd2a7d  vmovaps xmm13, [rsp+0x10]
0000781a8ffd2a83  vmovaps [rsp+0x20], xmm1
0000781a8ffd2a89  vmovaps xmm1, [rsp+0x10]
0000781a8ffd2a8f  por xmm13, xmm1
0000781a8ffd2a94  movaps [r15+0x1F0], xmm13
0000781a8ffd2a9c  vmovaps xmm1, [rsp+0xF0]
0000781a8ffd2aa5  vmovaps [rsp+0x10], xmm15
0000781a8ffd2aab  vmovaps xmm15, [rsp+0xF0]
0000781a8ffd2ab4  por xmm1, xmm15
0000781a8ffd2ab9  movaps [r15+0x250], xmm1
0000781a8ffd2ac1  vmovaps xmm1, [rsp+0xE0]
0000781a8ffd2aca  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd2ad3  por xmm1, xmm15
0000781a8ffd2ad8  movaps [r15+0x260], xmm1
0000781a8ffd2ae0  vmovaps [rsp+0x60], xmm8
0000781a8ffd2ae6  vmovaps xmm15, [rsp+0x60]
0000781a8ffd2aec  por xmm8, xmm15
0000781a8ffd2af1  movaps [r15+0x290], xmm8
0000781a8ffd2af9  vmovaps [rsp+0x60], xmm10
0000781a8ffd2aff  vmovaps xmm15, [rsp+0x60]
0000781a8ffd2b05  por xmm10, xmm15
0000781a8ffd2b0a  movaps [r15+0x2C0], xmm10
0000781a8ffd2b12  movq xmm15, qword ptr [r15+0x240]
0000781a8ffd2b1b  vmovaps [rsp+0x60], xmm15
0000781a8ffd2b21  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd2b27  vmovaps [rsp+0xE0], xmm1
0000781a8ffd2b30  vmovaps xmm1, [rsp+0x50]
0000781a8ffd2b36  vmovaps [rsp+0x50], xmm15
0000781a8ffd2b3c  vmovaps xmm15, [rsp+0x20]
0000781a8ffd2b42  vmovaps [rsp+0x20], xmm14
0000781a8ffd2b48  vmovaps xmm14, [rsp+0x50]
0000781a8ffd2b4e  vmovaps [rsp+0x50], xmm13
0000781a8ffd2b54  vmovaps [rsp+0xF0], xmm12
0000781a8ffd2b5d  movaps xmm13, xmm1
0000781a8ffd2b61  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd2b6c  vptest xmm12, xmm12
0000781a8ffd2b71  jnz 0x0000781A8FFD39F9
0000781a8ffd2b77  vmovaps xmm1, [rsp+0x60]
0000781a8ffd2b7d  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd2b83  vmovaps xmm15, [rsp+0x110]
0000781a8ffd2b8c  vmovaps xmm14, [rsp+0x20]
0000781a8ffd2b92  vmovaps [rsp+0x20], xmm13
0000781a8ffd2b98  movaps xmm12, xmm15
0000781a8ffd2b9c  vfmadd231pd xmm12, xmm14, xmm1
0000781a8ffd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
0000781a8ffd2ba7  vptest xmm13, xmm13
0000781a8ffd2bac  jnz 0x0000781A8FFD3B52
0000781a8ffd2bb2  vmovaps xmm1, [rsp+0x60]
0000781a8ffd2bb8  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd2bbe  vmovaps xmm15, [rsp+0x30]
0000781a8ffd2bc4  vmovaps xmm14, [rsp+0x10]
0000781a8ffd2bca  vmovaps [rsp+0x10], xmm12
0000781a8ffd2bd0  movaps xmm13, xmm15
0000781a8ffd2bd4  vfmadd231pd xmm13, xmm14, xmm1
0000781a8ffd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd2bdf  vptest xmm12, xmm12
0000781a8ffd2be4  jnz 0x0000781A8FFD3CAB
0000781a8ffd2bea  vmovaps [rsp+0x30], xmm5
0000781a8ffd2bf0  vmovaps xmm1, [rsp+0x30]
0000781a8ffd2bf6  por xmm5, xmm1
0000781a8ffd2bfa  movaps [r15+0x1D0], xmm5
0000781a8ffd2c02  vmovaps xmm1, [rsp+0x60]
0000781a8ffd2c08  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd2c0e  vmovaps xmm15, [rsp+0xF0]
0000781a8ffd2c17  vmovaps xmm14, [rsp+0x50]
0000781a8ffd2c1d  vmovaps [rsp+0x30], xmm13
0000781a8ffd2c23  movaps xmm12, xmm15
0000781a8ffd2c27  vfmadd231pd xmm12, xmm14, xmm1
0000781a8ffd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
0000781a8ffd2c32  vptest xmm13, xmm13
0000781a8ffd2c37  jnz 0x0000781A8FFD3E04
0000781a8ffd2c3d  vmovaps xmm1, [rsp+0x80]
0000781a8ffd2c46  vmovaps xmm15, [rsp+0x80]
0000781a8ffd2c4f  por xmm1, xmm15
0000781a8ffd2c54  movaps [r15+0x200], xmm1
0000781a8ffd2c5c  vmovaps xmm15, [rsp+0x120]
0000781a8ffd2c65  vmovaps xmm14, [rsp+0x120]
0000781a8ffd2c6e  por xmm15, xmm14
0000781a8ffd2c73  movaps [r15+0x1E0], xmm15
0000781a8ffd2c7b  vmovaps [rsp+0x50], xmm4
0000781a8ffd2c81  vmovaps xmm13, [rsp+0x50]
0000781a8ffd2c87  por xmm4, xmm13
0000781a8ffd2c8c  movaps [r15+0x2B0], xmm4
0000781a8ffd2c94  vmovaps [rsp+0x50], xmm3
0000781a8ffd2c9a  vmovaps xmm13, [rsp+0x50]
0000781a8ffd2ca0  por xmm3, xmm13
0000781a8ffd2ca5  movaps [r15+0x300], xmm3
0000781a8ffd2cad  vmovaps xmm15, [rsp+0xB0]
0000781a8ffd2cb6  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd2cbc  vmovaps xmm3, [rsp+0x20]
0000781a8ffd2cc2  vmovaps [rsp+0x20], xmm1
0000781a8ffd2cc8  vmovaps xmm1, [rsp+0xE0]
0000781a8ffd2cd1  vmovaps [rsp+0x50], xmm14
0000781a8ffd2cd7  vmovaps [rsp+0x60], xmm13
0000781a8ffd2cdd  movaps xmm14, xmm3
0000781a8ffd2ce1  vfmadd231pd xmm14, xmm1, xmm15
0000781a8ffd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
0000781a8ffd2cec  vptest xmm13, xmm13
0000781a8ffd2cf1  jnz 0x0000781A8FFD3F5D
0000781a8ffd2cf7  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd2d00  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd2d06  vmovaps xmm15, [rsp+0x10]
0000781a8ffd2d0c  movaps xmm13, xmm15
0000781a8ffd2d10  vfmadd231pd xmm13, xmm10, xmm1
0000781a8ffd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
0000781a8ffd2d1b  vptest xmm3, xmm3
0000781a8ffd2d20  jnz 0x0000781A8FFD40B5
0000781a8ffd2d26  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd2d2f  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd2d35  vmovaps xmm15, [rsp+0x30]
0000781a8ffd2d3b  movaps xmm10, xmm15
0000781a8ffd2d3f  vfmadd231pd xmm10, xmm11, xmm1
0000781a8ffd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
0000781a8ffd2d4a  vptest xmm3, xmm3
0000781a8ffd2d4f  jnz 0x0000781A8FFD420E
0000781a8ffd2d55  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd2d5e  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd2d64  movaps xmm15, xmm12
0000781a8ffd2d68  vfmadd231pd xmm15, xmm5, xmm1
0000781a8ffd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
0000781a8ffd2d73  vptest xmm11, xmm11
0000781a8ffd2d78  jnz 0x0000781A8FFD4367
0000781a8ffd2d7e  vmovaps [rsp+0x10], xmm9
0000781a8ffd2d84  vmovaps xmm1, [rsp+0x10]
0000781a8ffd2d8a  por xmm9, xmm1
0000781a8ffd2d8f  movaps [r15+0x180], xmm9
0000781a8ffd2d97  vmovaps [rsp+0x10], xmm2
0000781a8ffd2d9d  vmovaps xmm1, [rsp+0x10]
0000781a8ffd2da3  por xmm2, xmm1
0000781a8ffd2da7  movaps [r15+0x2D0], xmm2
0000781a8ffd2daf  vmovaps xmm12, [rsp+0xD0]
0000781a8ffd2db8  vpermilpd xmm12, xmm12, 0x00
0000781a8ffd2dbe  vmovaps xmm11, [rsp+0x60]
0000781a8ffd2dc4  movaps xmm5, xmm13
0000781a8ffd2dc8  vfmadd231pd xmm5, xmm11, xmm12
0000781a8ffd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
0000781a8ffd2dd2  vptest xmm3, xmm3
0000781a8ffd2dd7  jnz 0x0000781A8FFD44BF
0000781a8ffd2ddd  vmovaps xmm13, [rsp+0xD0]
0000781a8ffd2de6  vpermilpd xmm13, xmm13, 0x00
0000781a8ffd2dec  movaps xmm12, xmm14
0000781a8ffd2df0  vfmadd231pd xmm12, xmm9, xmm13
0000781a8ffd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
0000781a8ffd2dfb  vptest xmm11, xmm11
0000781a8ffd2e00  jnz 0x0000781A8FFD4617
0000781a8ffd2e06  lea rax, [r14+0x80]
0000781a8ffd2e0d  movups xmm14, [r13+rax*1]
0000781a8ffd2e13  movaps [r15+0x2F0], xmm14
0000781a8ffd2e1b  vmovaps xmm13, [rsp+0xD0]
0000781a8ffd2e24  vpermilpd xmm13, xmm13, 0x00
0000781a8ffd2e2a  movaps xmm11, xmm10
0000781a8ffd2e2e  vfmadd231pd xmm11, xmm8, xmm13
0000781a8ffd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
0000781a8ffd2e39  vptest xmm9, xmm9
0000781a8ffd2e3e  jnz 0x0000781A8FFD477B
0000781a8ffd2e44  vmovaps xmm13, [rsp+0xD0]
0000781a8ffd2e4d  vpermilpd xmm13, xmm13, 0x00
0000781a8ffd2e53  movaps xmm10, xmm15
0000781a8ffd2e57  vfmadd231pd xmm10, xmm1, xmm13
0000781a8ffd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
0000781a8ffd2e62  vptest xmm9, xmm9
0000781a8ffd2e67  jnz 0x0000781A8FFD48D5
0000781a8ffd2e6d  vmovaps [rsp+0x10], xmm7
0000781a8ffd2e73  vmovaps xmm1, [rsp+0x10]
0000781a8ffd2e79  por xmm7, xmm1
0000781a8ffd2e7d  movaps [r15+0x160], xmm7
0000781a8ffd2e85  lea rax, [r14+0x40]
0000781a8ffd2e89  movups xmm1, [r13+rax*1]
0000781a8ffd2e8f  lea rax, [r14+0x50]
0000781a8ffd2e93  movups xmm15, [r13+rax*1]
0000781a8ffd2e99  movaps [r15+0x1B0], xmm1
0000781a8ffd2ea1  movaps [r15+0x1A0], xmm15
0000781a8ffd2ea9  vmovaps xmm13, [rsp+0xA0]
0000781a8ffd2eb2  vpermilpd xmm13, xmm13, 0x00
0000781a8ffd2eb8  vmovaps xmm9, [rsp+0x40]
0000781a8ffd2ebe  movaps xmm8, xmm5
0000781a8ffd2ec2  vfmadd231pd xmm8, xmm9, xmm13
0000781a8ffd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
0000781a8ffd2ecd  vptest xmm3, xmm3
0000781a8ffd2ed2  jnz 0x0000781A8FFD4A42
0000781a8ffd2ed8  vmovaps xmm13, [rsp+0xA0]
0000781a8ffd2ee1  vpermilpd xmm13, xmm13, 0x00
0000781a8ffd2ee7  movaps xmm9, xmm12
0000781a8ffd2eeb  vfmadd231pd xmm9, xmm7, xmm13
0000781a8ffd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
0000781a8ffd2ef6  vptest xmm5, xmm5
0000781a8ffd2efb  jnz 0x0000781A8FFD4B9B
0000781a8ffd2f01  vmovaps xmm13, [rsp+0xA0]
0000781a8ffd2f0a  vpermilpd xmm13, xmm13, 0x00
0000781a8ffd2f10  movaps xmm12, xmm11
0000781a8ffd2f14  vfmadd231pd xmm12, xmm6, xmm13
0000781a8ffd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
0000781a8ffd2f1f  vptest xmm7, xmm7
0000781a8ffd2f24  jnz 0x0000781A8FFD4CF4
0000781a8ffd2f2a  vmovaps xmm13, [rsp+0xA0]
0000781a8ffd2f33  vpermilpd xmm13, xmm13, 0x00
0000781a8ffd2f39  vmovaps xmm11, [rsp+0x50]
0000781a8ffd2f3f  movaps xmm7, xmm10
0000781a8ffd2f43  vfmadd231pd xmm7, xmm11, xmm13
0000781a8ffd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
0000781a8ffd2f4d  vptest xmm6, xmm6
0000781a8ffd2f52  jnz 0x0000781A8FFD4E4D
0000781a8ffd2f58  lea rax, [r14+0x60]
0000781a8ffd2f5c  movups xmm13, [r13+rax*1]
0000781a8ffd2f62  lea rax, [r14+0x70]
0000781a8ffd2f66  movups xmm11, [r13+rax*1]
0000781a8ffd2f6c  movaps [r15+0x150], xmm13
0000781a8ffd2f74  movaps [r15+0x120], xmm11
0000781a8ffd2f7c  vmovaps xmm10, [rsp+0xC0]
0000781a8ffd2f85  vpermilpd xmm10, xmm10, 0x00
0000781a8ffd2f8b  movaps xmm6, xmm8
0000781a8ffd2f8f  vfmadd231pd xmm6, xmm15, xmm10
0000781a8ffd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
0000781a8ffd2f99  vptest xmm5, xmm5
0000781a8ffd2f9e  jnz 0x0000781A8FFD4FB9
0000781a8ffd2fa4  vmovaps xmm15, [rsp+0xC0]
0000781a8ffd2fad  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd2fb3  movaps xmm10, xmm9
0000781a8ffd2fb7  vfmadd231pd xmm10, xmm13, xmm15
0000781a8ffd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
0000781a8ffd2fc2  vptest xmm8, xmm8
0000781a8ffd2fc7  jnz 0x0000781A8FFD5111
0000781a8ffd2fcd  vmovaps xmm15, [rsp+0xC0]
0000781a8ffd2fd6  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd2fdc  movaps xmm13, xmm12
0000781a8ffd2fe0  vfmadd231pd xmm13, xmm4, xmm15
0000781a8ffd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
0000781a8ffd2feb  vptest xmm9, xmm9
0000781a8ffd2ff0  jnz 0x0000781A8FFD526B
0000781a8ffd2ff6  vmovaps xmm15, [rsp+0xC0]
0000781a8ffd2fff  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd3005  movaps xmm12, xmm7
0000781a8ffd3009  vfmadd231pd xmm12, xmm1, xmm15
0000781a8ffd300e  vcmppd xmm9, xmm12, xmm12, 0x03
0000781a8ffd3014  vptest xmm9, xmm9
0000781a8ffd3019  jnz 0x0000781A8FFD53C4
0000781a8ffd301f  lea rax, [r14+0x20]
0000781a8ffd3023  movups xmm1, [r13+rax*1]
0000781a8ffd3029  lea rax, [r14+0x30]
0000781a8ffd302d  movups xmm15, [r13+rax*1]
0000781a8ffd3033  vmovaps xmm9, [rsp+0x70]
0000781a8ffd3039  vpermilpd xmm9, xmm9, 0x00
0000781a8ffd303f  vmovaps xmm8, [rsp+0x20]
0000781a8ffd3045  movaps xmm7, xmm6
0000781a8ffd3048  vfmadd231pd xmm7, xmm8, xmm9
0000781a8ffd304d  vcmppd xmm5, xmm7, xmm7, 0x03
0000781a8ffd3052  vptest xmm5, xmm5
0000781a8ffd3057  jnz 0x0000781A8FFD5530
0000781a8ffd305d  vmovaps xmm9, [rsp+0x70]
0000781a8ffd3063  vpermilpd xmm9, xmm9, 0x00
0000781a8ffd3069  movaps xmm8, xmm10
0000781a8ffd306d  vfmadd231pd xmm8, xmm14, xmm9
0000781a8ffd3072  vcmppd xmm6, xmm8, xmm8, 0x03
0000781a8ffd3078  vptest xmm6, xmm6
0000781a8ffd307d  jnz 0x0000781A8FFD5687
0000781a8ffd3083  vmovaps xmm14, [rsp+0x70]
0000781a8ffd3089  vpermilpd xmm14, xmm14, 0x00
0000781a8ffd308f  movaps xmm10, xmm13
0000781a8ffd3093  vfmadd231pd xmm10, xmm11, xmm14
0000781a8ffd3098  vcmppd xmm9, xmm10, xmm10, 0x03
0000781a8ffd309e  vptest xmm9, xmm9
0000781a8ffd30a3  jnz 0x0000781A8FFD57E1
0000781a8ffd30a9  vmovaps xmm14, [rsp+0x70]
0000781a8ffd30af  vpermilpd xmm14, xmm14, 0x00
0000781a8ffd30b5  movaps xmm13, xmm12
0000781a8ffd30b9  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd30be  vcmppd xmm11, xmm13, xmm13, 0x03
0000781a8ffd30c4  vptest xmm11, xmm11
0000781a8ffd30c9  jnz 0x0000781A8FFD593B
0000781a8ffd30cf  lea rax, [r14+0x90]
0000781a8ffd30d6  movups xmm15, [r13+rax*1]
0000781a8ffd30dc  lea rax, [r14+0xA0]
0000781a8ffd30e3  movups xmm14, [r13+rax*1]
0000781a8ffd30e9  movaps [r15+0x140], xmm15
0000781a8ffd30f1  movaps [r15+0x130], xmm14
0000781a8ffd30f9  vmovaps xmm12, [rsp+0x90]
0000781a8ffd3102  vpermilpd xmm12, xmm12, 0x00
0000781a8ffd3108  movaps xmm11, xmm7
0000781a8ffd310c  vfmadd231pd xmm11, xmm1, xmm12
0000781a8ffd3111  vcmppd xmm9, xmm11, xmm11, 0x03
0000781a8ffd3117  vptest xmm9, xmm9
0000781a8ffd311c  jnz 0x0000781A8FFD5AA9
0000781a8ffd3122  movaps [r15+0x220], xmm11
0000781a8ffd312a  lea rax, [r14+0x10]
0000781a8ffd312e  movups xmm1, [r13+rax*1]
0000781a8ffd3134  movaps [r15+0x240], xmm1
0000781a8ffd313c  vmovaps xmm12, [rsp+0x90]
0000781a8ffd3145  vpermilpd xmm12, xmm12, 0x00
0000781a8ffd314b  movaps xmm9, xmm8
0000781a8ffd314f  vfmadd231pd xmm9, xmm14, xmm12
0000781a8ffd3154  vcmppd xmm7, xmm9, xmm9, 0x03
0000781a8ffd315a  vptest xmm7, xmm7
0000781a8ffd315f  jnz 0x0000781A8FFD5C0B
0000781a8ffd3165  movaps [r15+0x110], xmm9
0000781a8ffd316d  vmovaps xmm14, [rsp+0x90]
0000781a8ffd3176  vpermilpd xmm14, xmm14, 0x00
0000781a8ffd317c  movaps xmm12, xmm10
0000781a8ffd3180  vfmadd231pd xmm12, xmm15, xmm14
0000781a8ffd3185  vcmppd xmm8, xmm12, xmm12, 0x03
0000781a8ffd318b  vptest xmm8, xmm8
0000781a8ffd3190  jnz 0x0000781A8FFD5D65
0000781a8ffd3196  movaps [r15+0x170], xmm12
0000781a8ffd319e  vmovaps xmm15, [rsp+0x90]
0000781a8ffd31a7  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd31ad  movaps xmm14, xmm13
0000781a8ffd31b1  vfmadd231pd xmm14, xmm1, xmm15
0000781a8ffd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
0000781a8ffd31bc  vptest xmm10, xmm10
0000781a8ffd31c1  jnz 0x0000781A8FFD5EBF
0000781a8ffd31c7  movaps [r15+0x230], xmm14
0000781a8ffd31cf  mov eax, 0x432190
0000781a8ffd31d4  movups [r13+rax*1], xmm9
0000781a8ffd31da  mov eax, 0x4321A0
0000781a8ffd31df  movups [r13+rax*1], xmm12
0000781a8ffd31e5  mov eax, 0x4321B0
0000781a8ffd31ea  movups [r13+rax*1], xmm11
0000781a8ffd31f0  mov eax, 0x4321C0
0000781a8ffd31f5  movups [r13+rax*1], xmm14
0000781a8ffd31fb  mov eax, [r15+0x108]
0000781a8ffd3202  sahf
0000781a8ffd3203  jnz 0x0000781A8FFD3235
0000781a8ffd3205  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd320d  jz 0x0000781A8FFD9950
0000781a8ffd3213  nop [rax+rax*1], ax
0000781a8ffd321c  nop [rax+rax*1], eax
0000781a8ffd3224  mov eax, 0x410664
0000781a8ffd3229  mov [r15+0x100], rax
0000781a8ffd3230  jmp 0x0000781A8FDFE110
0000781a8ffd3235  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd323d  jz 0x0000781A8FFD6050
0000781a8ffd3243  nop [rax+rax*1], ax
0000781a8ffd324c  nop [rax+rax*1], eax
0000781a8ffd3254  mov eax, 0x4104F0
0000781a8ffd3259  mov [r15+0x100], rax
0000781a8ffd3260  jmp 0x0000781A8FDFE110
0000781a8ffd3265  int3
0000781a8ffd3266  call 0x0000781A8FDFF430
0000781a8ffd326b  jmp 0x0000781A8FFD230A
0000781a8ffd3270  call 0x0000781A8FEE5820
0000781a8ffd3275  jmp 0x0000781A8FFD2314
0000781a8ffd327a  call 0x0000781A8FEE45A0
0000781a8ffd327f  jmp 0x0000781A8FFD2326
0000781a8ffd3284  call 0x0000781A8FEE3320
0000781a8ffd3289  jmp 0x0000781A8FFD2330
0000781a8ffd328e  call 0x0000781A8FEE20A0
0000781a8ffd3293  jmp 0x0000781A8FFD233D
0000781a8ffd3298  call 0x0000781A8FEE0E30
0000781a8ffd329d  jmp 0x0000781A8FFD234A
0000781a8ffd32a2  call 0x0000781A8FED6600
0000781a8ffd32a7  jmp 0x0000781A8FFD2357
0000781a8ffd32ac  call 0x0000781A8FEB52F0
0000781a8ffd32b1  jmp 0x0000781A8FFD2361
0000781a8ffd32b6  call 0x0000781A8FEBE9C0
0000781a8ffd32bb  jmp 0x0000781A8FFD236B
0000781a8ffd32c0  call 0x0000781A8FEBD750
0000781a8ffd32c5  jmp 0x0000781A8FFD2378
0000781a8ffd32ca  call 0x0000781A8FEBC4E0
0000781a8ffd32cf  jmp 0x0000781A8FFD2385
0000781a8ffd32d4  call 0x0000781A8FEBB270
0000781a8ffd32d9  jmp 0x0000781A8FFD2392
0000781a8ffd32de  call 0x0000781A8FEBA000
0000781a8ffd32e3  jmp 0x0000781A8FFD239F
0000781a8ffd32e8  call 0x0000781A8FEB8D90
0000781a8ffd32ed  jmp 0x0000781A8FFD23AC
0000781a8ffd32f2  call 0x0000781A8FEB8A20
0000781a8ffd32f7  jmp 0x0000781A8FFD23B9
0000781a8ffd32fc  call 0x0000781A8FEBEAE0
0000781a8ffd3301  jmp 0x0000781A8FFD23C6
0000781a8ffd3306  call 0x0000781A8FEB5400
0000781a8ffd330b  jmp 0x0000781A8FFD23D3
0000781a8ffd3310  call 0x0000781A8FEB52F0
0000781a8ffd3315  jmp 0x0000781A8FFD23E0
0000781a8ffd331a  call 0x0000781A8FEBE9C0
0000781a8ffd331f  jmp 0x0000781A8FFD23ED
0000781a8ffd3324  call 0x0000781A8FEB77B0
0000781a8ffd3329  jmp 0x0000781A8FFD23FA
0000781a8ffd332e  call 0x0000781A8FEB6550
0000781a8ffd3333  jmp 0x0000781A8FFD2407
0000781a8ffd3338  call 0x0000781A8FEB52F0
0000781a8ffd333d  jmp 0x0000781A8FFD2417
0000781a8ffd3342  call 0x0000781A8FEB52F0
0000781a8ffd3347  jmp 0x0000781A8FFD2427
0000781a8ffd334c  call 0x0000781A8FEBEAE0
0000781a8ffd3351  jmp 0x0000781A8FFD2431
0000781a8ffd3356  call 0x0000781A8FEBEAE0
0000781a8ffd335b  jmp 0x0000781A8FFD2444
0000781a8ffd3360  call 0x0000781A8FEBE9C0
0000781a8ffd3365  jmp 0x0000781A8FFD2451
0000781a8ffd336a  call 0x0000781A8FEB52F0
0000781a8ffd336f  jmp 0x0000781A8FFD2464
0000781a8ffd3374  call 0x0000781A8FEB6660
0000781a8ffd3379  jmp 0x0000781A8FFD2471
0000781a8ffd337e  call 0x0000781A8FEB78C0
0000781a8ffd3383  jmp 0x0000781A8FFD247E
0000781a8ffd3388  call 0x0000781A8FEB77B0
0000781a8ffd338d  jmp 0x0000781A8FFD248B
0000781a8ffd3392  call 0x0000781A8FEB6550
0000781a8ffd3397  jmp 0x0000781A8FFD2498
0000781a8ffd339c  call 0x0000781A8FEB52F0
0000781a8ffd33a1  jmp 0x0000781A8FFD24AB
0000781a8ffd33a6  call 0x0000781A8FEB52F0
0000781a8ffd33ab  jmp 0x0000781A8FFD24BE
0000781a8ffd33b0  call 0x0000781A8FEB52F0
0000781a8ffd33b5  jmp 0x0000781A8FFD24E5
0000781a8ffd33ba  call 0x0000781A8FEB52F0
0000781a8ffd33bf  jmp 0x0000781A8FFD24F8
0000781a8ffd33c4  call 0x0000781A8FEB52F0
0000781a8ffd33c9  jmp 0x0000781A8FFD250B
0000781a8ffd33ce  call 0x0000781A8FEB52F0
0000781a8ffd33d3  jmp 0x0000781A8FFD2521
0000781a8ffd33d8  call 0x0000781A8FEB52F0
0000781a8ffd33dd  jmp 0x0000781A8FFD2537
0000781a8ffd33e2  call 0x0000781A8FEB52F0
0000781a8ffd33e7  jmp 0x0000781A8FFD254D
0000781a8ffd33ec  call 0x0000781A8FDFF540
0000781a8ffd33f1  jmp 0x0000781A8FFD256E
0000781a8ffd33f6  call 0x0000781A8FE02FE0
0000781a8ffd33fb  jmp 0x0000781A8FFD2578
0000781a8ffd3400  call 0x0000781A8FDFF540
0000781a8ffd3405  jmp 0x0000781A8FFD2588
0000781a8ffd340a  call 0x0000781A8FDFF540
0000781a8ffd340f  jmp 0x0000781A8FFD259B
0000781a8ffd3414  call 0x0000781A8FDFF540
0000781a8ffd3419  jmp 0x0000781A8FFD25AE
0000781a8ffd341e  call 0x0000781A8FDFF540
0000781a8ffd3423  jmp 0x0000781A8FFD25C1
0000781a8ffd3428  call 0x0000781A8FEC0370
0000781a8ffd342d  jmp 0x0000781A8FFD25E0
0000781a8ffd3432  call 0x0000781A8FEBF100
0000781a8ffd3437  jmp 0x0000781A8FFD25E9
0000781a8ffd343c  call 0x0000781A8FEC0370
0000781a8ffd3441  jmp 0x0000781A8FFD2659
0000781a8ffd3446  call 0x0000781A8FEBF100
0000781a8ffd344b  jmp 0x0000781A8FFD2662
0000781a8ffd3450  call 0x0000781A8FEC0370
0000781a8ffd3455  jmp 0x0000781A8FFD270C
0000781a8ffd345a  call 0x0000781A8FEBF100
0000781a8ffd345f  jmp 0x0000781A8FFD2715
0000781a8ffd3464  call 0x0000781A8FE0B720
0000781a8ffd3469  jmp 0x0000781A8FFD27F7
0000781a8ffd346e  call 0x0000781A8FED64F0
0000781a8ffd3473  jmp 0x0000781A8FFD281F
0000781a8ffd3478  call 0x0000781A8FEB47C0
0000781a8ffd347d  jmp 0x0000781A8FFD283A
0000781a8ffd3482  sub rsp, 0x08
0000781a8ffd3486  push rax
0000781a8ffd3487  push rcx
0000781a8ffd3488  push rdx
0000781a8ffd3489  push rdi
0000781a8ffd348a  push rsi
0000781a8ffd348b  push r8
0000781a8ffd348d  push r9
0000781a8ffd348f  push r10
0000781a8ffd3491  push r11
0000781a8ffd3493  sub rsp, 0xF0
0000781a8ffd349a  vmovaps [rsp], xmm0
0000781a8ffd349f  vmovaps [rsp+0x10], xmm1
0000781a8ffd34a5  vmovaps [rsp+0x20], xmm2
0000781a8ffd34ab  vmovaps [rsp+0x30], xmm3
0000781a8ffd34b1  vmovaps [rsp+0x40], xmm4
0000781a8ffd34b7  vmovaps [rsp+0x50], xmm5
0000781a8ffd34bd  vmovaps [rsp+0x60], xmm6
0000781a8ffd34c3  vmovaps [rsp+0x70], xmm7
0000781a8ffd34c9  vmovaps [rsp+0x80], xmm8
0000781a8ffd34d2  vmovaps [rsp+0x90], xmm9
0000781a8ffd34db  vmovaps [rsp+0xA0], xmm10
0000781a8ffd34e4  vmovaps [rsp+0xB0], xmm11
0000781a8ffd34ed  vmovaps [rsp+0xC0], xmm12
0000781a8ffd34f6  vmovaps [rsp+0xD0], xmm14
0000781a8ffd34ff  vmovaps [rsp+0xE0], xmm15
0000781a8ffd3508  sub rsp, 0x40
0000781a8ffd350c  lea rdi, [rsp]
0000781a8ffd3510  lea rsi, [rsp+0x10]
0000781a8ffd3515  lea rdx, [rsp+0x20]
0000781a8ffd351a  lea rcx, [rsp+0x30]
0000781a8ffd351f  mov r8d, 0x00
0000781a8ffd3525  lea r9, [r15+0x3A8]
0000781a8ffd352c  movaps [rdi], xmm13
0000781a8ffd3530  movaps [rsi], xmm1
0000781a8ffd3533  movaps [rdx], xmm15
0000781a8ffd3537  movaps [rcx], xmm14
0000781a8ffd353b  mov rax, 0x627DDC279A50
0000781a8ffd3545  call rax
0000781a8ffd3547  movaps xmm13, [rsp]
0000781a8ffd354c  add rsp, 0x40
0000781a8ffd3550  vmovaps xmm0, [rsp]
0000781a8ffd3555  vmovaps xmm1, [rsp+0x10]
0000781a8ffd355b  vmovaps xmm2, [rsp+0x20]
0000781a8ffd3561  vmovaps xmm3, [rsp+0x30]
0000781a8ffd3567  vmovaps xmm4, [rsp+0x40]
0000781a8ffd356d  vmovaps xmm5, [rsp+0x50]
0000781a8ffd3573  vmovaps xmm6, [rsp+0x60]
0000781a8ffd3579  vmovaps xmm7, [rsp+0x70]
0000781a8ffd357f  vmovaps xmm8, [rsp+0x80]
0000781a8ffd3588  vmovaps xmm9, [rsp+0x90]
0000781a8ffd3591  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd359a  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd35a3  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd35ac  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd35b5  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd35be  add rsp, 0xF0
0000781a8ffd35c5  pop r11
0000781a8ffd35c7  pop r10
0000781a8ffd35c9  pop r9
0000781a8ffd35cb  pop r8
0000781a8ffd35cd  pop rsi
0000781a8ffd35ce  pop rdi
0000781a8ffd35cf  pop rdx
0000781a8ffd35d0  pop rcx
0000781a8ffd35d1  pop rax
0000781a8ffd35d2  add rsp, 0x08
0000781a8ffd35d6  jmp 0x0000781A8FFD28AD
0000781a8ffd35db  sub rsp, 0x08
0000781a8ffd35df  push rax
0000781a8ffd35e0  push rcx
0000781a8ffd35e1  push rdx
0000781a8ffd35e2  push rdi
0000781a8ffd35e3  push rsi
0000781a8ffd35e4  push r8
0000781a8ffd35e6  push r9
0000781a8ffd35e8  push r10
0000781a8ffd35ea  push r11
0000781a8ffd35ec  sub rsp, 0xF0
0000781a8ffd35f3  vmovaps [rsp], xmm0
0000781a8ffd35f8  vmovaps [rsp+0x10], xmm1
0000781a8ffd35fe  vmovaps [rsp+0x20], xmm2
0000781a8ffd3604  vmovaps [rsp+0x30], xmm3
0000781a8ffd360a  vmovaps [rsp+0x40], xmm4
0000781a8ffd3610  vmovaps [rsp+0x50], xmm5
0000781a8ffd3616  vmovaps [rsp+0x60], xmm6
0000781a8ffd361c  vmovaps [rsp+0x70], xmm7
0000781a8ffd3622  vmovaps [rsp+0x80], xmm8
0000781a8ffd362b  vmovaps [rsp+0x90], xmm9
0000781a8ffd3634  vmovaps [rsp+0xA0], xmm10
0000781a8ffd363d  vmovaps [rsp+0xB0], xmm11
0000781a8ffd3646  vmovaps [rsp+0xC0], xmm12
0000781a8ffd364f  vmovaps [rsp+0xD0], xmm13
0000781a8ffd3658  vmovaps [rsp+0xE0], xmm14
0000781a8ffd3661  sub rsp, 0x40
0000781a8ffd3665  lea rdi, [rsp]
0000781a8ffd3669  lea rsi, [rsp+0x10]
0000781a8ffd366e  lea rdx, [rsp+0x20]
0000781a8ffd3673  lea rcx, [rsp+0x30]
0000781a8ffd3678  mov r8d, 0x00
0000781a8ffd367e  lea r9, [r15+0x3A8]
0000781a8ffd3685  movaps [rdi], xmm15
0000781a8ffd3689  movaps [rsi], xmm5
0000781a8ffd368c  movaps [rdx], xmm1
0000781a8ffd368f  movaps [rcx], xmm14
0000781a8ffd3693  mov rax, 0x627DDC279A50
0000781a8ffd369d  call rax
0000781a8ffd369f  movaps xmm15, [rsp]
0000781a8ffd36a4  add rsp, 0x40
0000781a8ffd36a8  vmovaps xmm0, [rsp]
0000781a8ffd36ad  vmovaps xmm1, [rsp+0x10]
0000781a8ffd36b3  vmovaps xmm2, [rsp+0x20]
0000781a8ffd36b9  vmovaps xmm3, [rsp+0x30]
0000781a8ffd36bf  vmovaps xmm4, [rsp+0x40]
0000781a8ffd36c5  vmovaps xmm5, [rsp+0x50]
0000781a8ffd36cb  vmovaps xmm6, [rsp+0x60]
0000781a8ffd36d1  vmovaps xmm7, [rsp+0x70]
0000781a8ffd36d7  vmovaps xmm8, [rsp+0x80]
0000781a8ffd36e0  vmovaps xmm9, [rsp+0x90]
0000781a8ffd36e9  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd36f2  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd36fb  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd3704  vmovaps xmm13, [rsp+0xD0]
0000781a8ffd370d  vmovaps xmm14, [rsp+0xE0]
0000781a8ffd3716  add rsp, 0xF0
0000781a8ffd371d  pop r11
0000781a8ffd371f  pop r10
0000781a8ffd3721  pop r9
0000781a8ffd3723  pop r8
0000781a8ffd3725  pop rsi
0000781a8ffd3726  pop rdi
0000781a8ffd3727  pop rdx
0000781a8ffd3728  pop rcx
0000781a8ffd3729  pop rax
0000781a8ffd372a  add rsp, 0x08
0000781a8ffd372e  jmp 0x0000781A8FFD28D0
0000781a8ffd3733  call 0x0000781A8FDFF430
0000781a8ffd3738  jmp 0x0000781A8FFD295D
0000781a8ffd373d  sub rsp, 0x08
0000781a8ffd3741  push rax
0000781a8ffd3742  push rcx
0000781a8ffd3743  push rdx
0000781a8ffd3744  push rdi
0000781a8ffd3745  push rsi
0000781a8ffd3746  push r8
0000781a8ffd3748  push r9
0000781a8ffd374a  push r10
0000781a8ffd374c  push r11
0000781a8ffd374e  sub rsp, 0xF0
0000781a8ffd3755  vmovaps [rsp], xmm0
0000781a8ffd375a  vmovaps [rsp+0x10], xmm1
0000781a8ffd3760  vmovaps [rsp+0x20], xmm2
0000781a8ffd3766  vmovaps [rsp+0x30], xmm3
0000781a8ffd376c  vmovaps [rsp+0x40], xmm4
0000781a8ffd3772  vmovaps [rsp+0x50], xmm5
0000781a8ffd3778  vmovaps [rsp+0x60], xmm6
0000781a8ffd377e  vmovaps [rsp+0x70], xmm7
0000781a8ffd3784  vmovaps [rsp+0x80], xmm8
0000781a8ffd378d  vmovaps [rsp+0x90], xmm9
0000781a8ffd3796  vmovaps [rsp+0xA0], xmm10
0000781a8ffd379f  vmovaps [rsp+0xB0], xmm11
0000781a8ffd37a8  vmovaps [rsp+0xC0], xmm12
0000781a8ffd37b1  vmovaps [rsp+0xD0], xmm14
0000781a8ffd37ba  vmovaps [rsp+0xE0], xmm15
0000781a8ffd37c3  sub rsp, 0x40
0000781a8ffd37c7  lea rdi, [rsp]
0000781a8ffd37cb  lea rsi, [rsp+0x10]
0000781a8ffd37d0  lea rdx, [rsp+0x20]
0000781a8ffd37d5  lea rcx, [rsp+0x30]
0000781a8ffd37da  mov r8d, 0x00
0000781a8ffd37e0  lea r9, [r15+0x3A8]
0000781a8ffd37e7  movaps [rdi], xmm13
0000781a8ffd37eb  movaps [rsi], xmm1
0000781a8ffd37ee  movaps [rdx], xmm15
0000781a8ffd37f2  movaps [rcx], xmm14
0000781a8ffd37f6  mov rax, 0x627DDC279A50
0000781a8ffd3800  call rax
0000781a8ffd3802  movaps xmm13, [rsp]
0000781a8ffd3807  add rsp, 0x40
0000781a8ffd380b  vmovaps xmm0, [rsp]
0000781a8ffd3810  vmovaps xmm1, [rsp+0x10]
0000781a8ffd3816  vmovaps xmm2, [rsp+0x20]
0000781a8ffd381c  vmovaps xmm3, [rsp+0x30]
0000781a8ffd3822  vmovaps xmm4, [rsp+0x40]
0000781a8ffd3828  vmovaps xmm5, [rsp+0x50]
0000781a8ffd382e  vmovaps xmm6, [rsp+0x60]
0000781a8ffd3834  vmovaps xmm7, [rsp+0x70]
0000781a8ffd383a  vmovaps xmm8, [rsp+0x80]
0000781a8ffd3843  vmovaps xmm9, [rsp+0x90]
0000781a8ffd384c  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd3855  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd385e  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd3867  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd3870  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd3879  add rsp, 0xF0
0000781a8ffd3880  pop r11
0000781a8ffd3882  pop r10
0000781a8ffd3884  pop r9
0000781a8ffd3886  pop r8
0000781a8ffd3888  pop rsi
0000781a8ffd3889  pop rdi
0000781a8ffd388a  pop rdx
0000781a8ffd388b  pop rcx
0000781a8ffd388c  pop rax
0000781a8ffd388d  add rsp, 0x08
0000781a8ffd3891  jmp 0x0000781A8FFD29C1
0000781a8ffd3896  call 0x0000781A8FDFF430
0000781a8ffd389b  jmp 0x0000781A8FFD29CE
0000781a8ffd38a0  sub rsp, 0x08
0000781a8ffd38a4  push rax
0000781a8ffd38a5  push rcx
0000781a8ffd38a6  push rdx
0000781a8ffd38a7  push rdi
0000781a8ffd38a8  push rsi
0000781a8ffd38a9  push r8
0000781a8ffd38ab  push r9
0000781a8ffd38ad  push r10
0000781a8ffd38af  push r11
0000781a8ffd38b1  sub rsp, 0xF0
0000781a8ffd38b8  vmovaps [rsp], xmm0
0000781a8ffd38bd  vmovaps [rsp+0x10], xmm1
0000781a8ffd38c3  vmovaps [rsp+0x20], xmm2
0000781a8ffd38c9  vmovaps [rsp+0x30], xmm3
0000781a8ffd38cf  vmovaps [rsp+0x40], xmm4
0000781a8ffd38d5  vmovaps [rsp+0x50], xmm5
0000781a8ffd38db  vmovaps [rsp+0x60], xmm6
0000781a8ffd38e1  vmovaps [rsp+0x70], xmm7
0000781a8ffd38e7  vmovaps [rsp+0x80], xmm8
0000781a8ffd38f0  vmovaps [rsp+0x90], xmm9
0000781a8ffd38f9  vmovaps [rsp+0xA0], xmm10
0000781a8ffd3902  vmovaps [rsp+0xB0], xmm11
0000781a8ffd390b  vmovaps [rsp+0xC0], xmm13
0000781a8ffd3914  vmovaps [rsp+0xD0], xmm14
0000781a8ffd391d  vmovaps [rsp+0xE0], xmm15
0000781a8ffd3926  sub rsp, 0x40
0000781a8ffd392a  lea rdi, [rsp]
0000781a8ffd392e  lea rsi, [rsp+0x10]
0000781a8ffd3933  lea rdx, [rsp+0x20]
0000781a8ffd3938  lea rcx, [rsp+0x30]
0000781a8ffd393d  mov r8d, 0x00
0000781a8ffd3943  lea r9, [r15+0x3A8]
0000781a8ffd394a  movaps [rdi], xmm12
0000781a8ffd394e  movaps [rsi], xmm15
0000781a8ffd3952  movaps [rdx], xmm1
0000781a8ffd3955  movaps [rcx], xmm14
0000781a8ffd3959  mov rax, 0x627DDC279A50
0000781a8ffd3963  call rax
0000781a8ffd3965  movaps xmm12, [rsp]
0000781a8ffd396a  add rsp, 0x40
0000781a8ffd396e  vmovaps xmm0, [rsp]
0000781a8ffd3973  vmovaps xmm1, [rsp+0x10]
0000781a8ffd3979  vmovaps xmm2, [rsp+0x20]
0000781a8ffd397f  vmovaps xmm3, [rsp+0x30]
0000781a8ffd3985  vmovaps xmm4, [rsp+0x40]
0000781a8ffd398b  vmovaps xmm5, [rsp+0x50]
0000781a8ffd3991  vmovaps xmm6, [rsp+0x60]
0000781a8ffd3997  vmovaps xmm7, [rsp+0x70]
0000781a8ffd399d  vmovaps xmm8, [rsp+0x80]
0000781a8ffd39a6  vmovaps xmm9, [rsp+0x90]
0000781a8ffd39af  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd39b8  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd39c1  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd39ca  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd39d3  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd39dc  add rsp, 0xF0
0000781a8ffd39e3  pop r11
0000781a8ffd39e5  pop r10
0000781a8ffd39e7  pop r9
0000781a8ffd39e9  pop r8
0000781a8ffd39eb  pop rsi
0000781a8ffd39ec  pop rdi
0000781a8ffd39ed  pop rdx
0000781a8ffd39ee  pop rcx
0000781a8ffd39ef  pop rax
0000781a8ffd39f0  add rsp, 0x08
0000781a8ffd39f4  jmp 0x0000781A8FFD29FA
0000781a8ffd39f9  sub rsp, 0x08
0000781a8ffd39fd  push rax
0000781a8ffd39fe  push rcx
0000781a8ffd39ff  push rdx
0000781a8ffd3a00  push rdi
0000781a8ffd3a01  push rsi
0000781a8ffd3a02  push r8
0000781a8ffd3a04  push r9
0000781a8ffd3a06  push r10
0000781a8ffd3a08  push r11
0000781a8ffd3a0a  sub rsp, 0xF0
0000781a8ffd3a11  vmovaps [rsp], xmm0
0000781a8ffd3a16  vmovaps [rsp+0x10], xmm1
0000781a8ffd3a1c  vmovaps [rsp+0x20], xmm2
0000781a8ffd3a22  vmovaps [rsp+0x30], xmm3
0000781a8ffd3a28  vmovaps [rsp+0x40], xmm4
0000781a8ffd3a2e  vmovaps [rsp+0x50], xmm5
0000781a8ffd3a34  vmovaps [rsp+0x60], xmm6
0000781a8ffd3a3a  vmovaps [rsp+0x70], xmm7
0000781a8ffd3a40  vmovaps [rsp+0x80], xmm8
0000781a8ffd3a49  vmovaps [rsp+0x90], xmm9
0000781a8ffd3a52  vmovaps [rsp+0xA0], xmm10
0000781a8ffd3a5b  vmovaps [rsp+0xB0], xmm11
0000781a8ffd3a64  vmovaps [rsp+0xC0], xmm12
0000781a8ffd3a6d  vmovaps [rsp+0xD0], xmm14
0000781a8ffd3a76  vmovaps [rsp+0xE0], xmm15
0000781a8ffd3a7f  sub rsp, 0x40
0000781a8ffd3a83  lea rdi, [rsp]
0000781a8ffd3a87  lea rsi, [rsp+0x10]
0000781a8ffd3a8c  lea rdx, [rsp+0x20]
0000781a8ffd3a91  lea rcx, [rsp+0x30]
0000781a8ffd3a96  mov r8d, 0x00
0000781a8ffd3a9c  lea r9, [r15+0x3A8]
0000781a8ffd3aa3  movaps [rdi], xmm13
0000781a8ffd3aa7  movaps [rsi], xmm1
0000781a8ffd3aaa  movaps [rdx], xmm15
0000781a8ffd3aae  movaps [rcx], xmm14
0000781a8ffd3ab2  mov rax, 0x627DDC279A50
0000781a8ffd3abc  call rax
0000781a8ffd3abe  movaps xmm13, [rsp]
0000781a8ffd3ac3  add rsp, 0x40
0000781a8ffd3ac7  vmovaps xmm0, [rsp]
0000781a8ffd3acc  vmovaps xmm1, [rsp+0x10]
0000781a8ffd3ad2  vmovaps xmm2, [rsp+0x20]
0000781a8ffd3ad8  vmovaps xmm3, [rsp+0x30]
0000781a8ffd3ade  vmovaps xmm4, [rsp+0x40]
0000781a8ffd3ae4  vmovaps xmm5, [rsp+0x50]
0000781a8ffd3aea  vmovaps xmm6, [rsp+0x60]
0000781a8ffd3af0  vmovaps xmm7, [rsp+0x70]
0000781a8ffd3af6  vmovaps xmm8, [rsp+0x80]
0000781a8ffd3aff  vmovaps xmm9, [rsp+0x90]
0000781a8ffd3b08  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd3b11  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd3b1a  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd3b23  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd3b2c  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd3b35  add rsp, 0xF0
0000781a8ffd3b3c  pop r11
0000781a8ffd3b3e  pop r10
0000781a8ffd3b40  pop r9
0000781a8ffd3b42  pop r8
0000781a8ffd3b44  pop rsi
0000781a8ffd3b45  pop rdi
0000781a8ffd3b46  pop rdx
0000781a8ffd3b47  pop rcx
0000781a8ffd3b48  pop rax
0000781a8ffd3b49  add rsp, 0x08
0000781a8ffd3b4d  jmp 0x0000781A8FFD2B77
0000781a8ffd3b52  sub rsp, 0x08
0000781a8ffd3b56  push rax
0000781a8ffd3b57  push rcx
0000781a8ffd3b58  push rdx
0000781a8ffd3b59  push rdi
0000781a8ffd3b5a  push rsi
0000781a8ffd3b5b  push r8
0000781a8ffd3b5d  push r9
0000781a8ffd3b5f  push r10
0000781a8ffd3b61  push r11
0000781a8ffd3b63  sub rsp, 0xF0
0000781a8ffd3b6a  vmovaps [rsp], xmm0
0000781a8ffd3b6f  vmovaps [rsp+0x10], xmm1
0000781a8ffd3b75  vmovaps [rsp+0x20], xmm2
0000781a8ffd3b7b  vmovaps [rsp+0x30], xmm3
0000781a8ffd3b81  vmovaps [rsp+0x40], xmm4
0000781a8ffd3b87  vmovaps [rsp+0x50], xmm5
0000781a8ffd3b8d  vmovaps [rsp+0x60], xmm6
0000781a8ffd3b93  vmovaps [rsp+0x70], xmm7
0000781a8ffd3b99  vmovaps [rsp+0x80], xmm8
0000781a8ffd3ba2  vmovaps [rsp+0x90], xmm9
0000781a8ffd3bab  vmovaps [rsp+0xA0], xmm10
0000781a8ffd3bb4  vmovaps [rsp+0xB0], xmm11
0000781a8ffd3bbd  vmovaps [rsp+0xC0], xmm13
0000781a8ffd3bc6  vmovaps [rsp+0xD0], xmm14
0000781a8ffd3bcf  vmovaps [rsp+0xE0], xmm15
0000781a8ffd3bd8  sub rsp, 0x40
0000781a8ffd3bdc  lea rdi, [rsp]
0000781a8ffd3be0  lea rsi, [rsp+0x10]
0000781a8ffd3be5  lea rdx, [rsp+0x20]
0000781a8ffd3bea  lea rcx, [rsp+0x30]
0000781a8ffd3bef  mov r8d, 0x00
0000781a8ffd3bf5  lea r9, [r15+0x3A8]
0000781a8ffd3bfc  movaps [rdi], xmm12
0000781a8ffd3c00  movaps [rsi], xmm15
0000781a8ffd3c04  movaps [rdx], xmm14
0000781a8ffd3c08  movaps [rcx], xmm1
0000781a8ffd3c0b  mov rax, 0x627DDC279A50
0000781a8ffd3c15  call rax
0000781a8ffd3c17  movaps xmm12, [rsp]
0000781a8ffd3c1c  add rsp, 0x40
0000781a8ffd3c20  vmovaps xmm0, [rsp]
0000781a8ffd3c25  vmovaps xmm1, [rsp+0x10]
0000781a8ffd3c2b  vmovaps xmm2, [rsp+0x20]
0000781a8ffd3c31  vmovaps xmm3, [rsp+0x30]
0000781a8ffd3c37  vmovaps xmm4, [rsp+0x40]
0000781a8ffd3c3d  vmovaps xmm5, [rsp+0x50]
0000781a8ffd3c43  vmovaps xmm6, [rsp+0x60]
0000781a8ffd3c49  vmovaps xmm7, [rsp+0x70]
0000781a8ffd3c4f  vmovaps xmm8, [rsp+0x80]
0000781a8ffd3c58  vmovaps xmm9, [rsp+0x90]
0000781a8ffd3c61  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd3c6a  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd3c73  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd3c7c  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd3c85  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd3c8e  add rsp, 0xF0
0000781a8ffd3c95  pop r11
0000781a8ffd3c97  pop r10
0000781a8ffd3c99  pop r9
0000781a8ffd3c9b  pop r8
0000781a8ffd3c9d  pop rsi
0000781a8ffd3c9e  pop rdi
0000781a8ffd3c9f  pop rdx
0000781a8ffd3ca0  pop rcx
0000781a8ffd3ca1  pop rax
0000781a8ffd3ca2  add rsp, 0x08
0000781a8ffd3ca6  jmp 0x0000781A8FFD2BB2
0000781a8ffd3cab  sub rsp, 0x08
0000781a8ffd3caf  push rax
0000781a8ffd3cb0  push rcx
0000781a8ffd3cb1  push rdx
0000781a8ffd3cb2  push rdi
0000781a8ffd3cb3  push rsi
0000781a8ffd3cb4  push r8
0000781a8ffd3cb6  push r9
0000781a8ffd3cb8  push r10
0000781a8ffd3cba  push r11
0000781a8ffd3cbc  sub rsp, 0xF0
0000781a8ffd3cc3  vmovaps [rsp], xmm0
0000781a8ffd3cc8  vmovaps [rsp+0x10], xmm1
0000781a8ffd3cce  vmovaps [rsp+0x20], xmm2
0000781a8ffd3cd4  vmovaps [rsp+0x30], xmm3
0000781a8ffd3cda  vmovaps [rsp+0x40], xmm4
0000781a8ffd3ce0  vmovaps [rsp+0x50], xmm5
0000781a8ffd3ce6  vmovaps [rsp+0x60], xmm6
0000781a8ffd3cec  vmovaps [rsp+0x70], xmm7
0000781a8ffd3cf2  vmovaps [rsp+0x80], xmm8
0000781a8ffd3cfb  vmovaps [rsp+0x90], xmm9
0000781a8ffd3d04  vmovaps [rsp+0xA0], xmm10
0000781a8ffd3d0d  vmovaps [rsp+0xB0], xmm11
0000781a8ffd3d16  vmovaps [rsp+0xC0], xmm12
0000781a8ffd3d1f  vmovaps [rsp+0xD0], xmm14
0000781a8ffd3d28  vmovaps [rsp+0xE0], xmm15
0000781a8ffd3d31  sub rsp, 0x40
0000781a8ffd3d35  lea rdi, [rsp]
0000781a8ffd3d39  lea rsi, [rsp+0x10]
0000781a8ffd3d3e  lea rdx, [rsp+0x20]
0000781a8ffd3d43  lea rcx, [rsp+0x30]
0000781a8ffd3d48  mov r8d, 0x00
0000781a8ffd3d4e  lea r9, [r15+0x3A8]
0000781a8ffd3d55  movaps [rdi], xmm13
0000781a8ffd3d59  movaps [rsi], xmm15
0000781a8ffd3d5d  movaps [rdx], xmm14
0000781a8ffd3d61  movaps [rcx], xmm1
0000781a8ffd3d64  mov rax, 0x627DDC279A50
0000781a8ffd3d6e  call rax
0000781a8ffd3d70  movaps xmm13, [rsp]
0000781a8ffd3d75  add rsp, 0x40
0000781a8ffd3d79  vmovaps xmm0, [rsp]
0000781a8ffd3d7e  vmovaps xmm1, [rsp+0x10]
0000781a8ffd3d84  vmovaps xmm2, [rsp+0x20]
0000781a8ffd3d8a  vmovaps xmm3, [rsp+0x30]
0000781a8ffd3d90  vmovaps xmm4, [rsp+0x40]
0000781a8ffd3d96  vmovaps xmm5, [rsp+0x50]
0000781a8ffd3d9c  vmovaps xmm6, [rsp+0x60]
0000781a8ffd3da2  vmovaps xmm7, [rsp+0x70]
0000781a8ffd3da8  vmovaps xmm8, [rsp+0x80]
0000781a8ffd3db1  vmovaps xmm9, [rsp+0x90]
0000781a8ffd3dba  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd3dc3  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd3dcc  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd3dd5  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd3dde  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd3de7  add rsp, 0xF0
0000781a8ffd3dee  pop r11
0000781a8ffd3df0  pop r10
0000781a8ffd3df2  pop r9
0000781a8ffd3df4  pop r8
0000781a8ffd3df6  pop rsi
0000781a8ffd3df7  pop rdi
0000781a8ffd3df8  pop rdx
0000781a8ffd3df9  pop rcx
0000781a8ffd3dfa  pop rax
0000781a8ffd3dfb  add rsp, 0x08
0000781a8ffd3dff  jmp 0x0000781A8FFD2BEA
0000781a8ffd3e04  sub rsp, 0x08
0000781a8ffd3e08  push rax
0000781a8ffd3e09  push rcx
0000781a8ffd3e0a  push rdx
0000781a8ffd3e0b  push rdi
0000781a8ffd3e0c  push rsi
0000781a8ffd3e0d  push r8
0000781a8ffd3e0f  push r9
0000781a8ffd3e11  push r10
0000781a8ffd3e13  push r11
0000781a8ffd3e15  sub rsp, 0xF0
0000781a8ffd3e1c  vmovaps [rsp], xmm0
0000781a8ffd3e21  vmovaps [rsp+0x10], xmm1
0000781a8ffd3e27  vmovaps [rsp+0x20], xmm2
0000781a8ffd3e2d  vmovaps [rsp+0x30], xmm3
0000781a8ffd3e33  vmovaps [rsp+0x40], xmm4
0000781a8ffd3e39  vmovaps [rsp+0x50], xmm5
0000781a8ffd3e3f  vmovaps [rsp+0x60], xmm6
0000781a8ffd3e45  vmovaps [rsp+0x70], xmm7
0000781a8ffd3e4b  vmovaps [rsp+0x80], xmm8
0000781a8ffd3e54  vmovaps [rsp+0x90], xmm9
0000781a8ffd3e5d  vmovaps [rsp+0xA0], xmm10
0000781a8ffd3e66  vmovaps [rsp+0xB0], xmm11
0000781a8ffd3e6f  vmovaps [rsp+0xC0], xmm13
0000781a8ffd3e78  vmovaps [rsp+0xD0], xmm14
0000781a8ffd3e81  vmovaps [rsp+0xE0], xmm15
0000781a8ffd3e8a  sub rsp, 0x40
0000781a8ffd3e8e  lea rdi, [rsp]
0000781a8ffd3e92  lea rsi, [rsp+0x10]
0000781a8ffd3e97  lea rdx, [rsp+0x20]
0000781a8ffd3e9c  lea rcx, [rsp+0x30]
0000781a8ffd3ea1  mov r8d, 0x00
0000781a8ffd3ea7  lea r9, [r15+0x3A8]
0000781a8ffd3eae  movaps [rdi], xmm12
0000781a8ffd3eb2  movaps [rsi], xmm15
0000781a8ffd3eb6  movaps [rdx], xmm14
0000781a8ffd3eba  movaps [rcx], xmm1
0000781a8ffd3ebd  mov rax, 0x627DDC279A50
0000781a8ffd3ec7  call rax
0000781a8ffd3ec9  movaps xmm12, [rsp]
0000781a8ffd3ece  add rsp, 0x40
0000781a8ffd3ed2  vmovaps xmm0, [rsp]
0000781a8ffd3ed7  vmovaps xmm1, [rsp+0x10]
0000781a8ffd3edd  vmovaps xmm2, [rsp+0x20]
0000781a8ffd3ee3  vmovaps xmm3, [rsp+0x30]
0000781a8ffd3ee9  vmovaps xmm4, [rsp+0x40]
0000781a8ffd3eef  vmovaps xmm5, [rsp+0x50]
0000781a8ffd3ef5  vmovaps xmm6, [rsp+0x60]
0000781a8ffd3efb  vmovaps xmm7, [rsp+0x70]
0000781a8ffd3f01  vmovaps xmm8, [rsp+0x80]
0000781a8ffd3f0a  vmovaps xmm9, [rsp+0x90]
0000781a8ffd3f13  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd3f1c  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd3f25  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd3f2e  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd3f37  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd3f40  add rsp, 0xF0
0000781a8ffd3f47  pop r11
0000781a8ffd3f49  pop r10
0000781a8ffd3f4b  pop r9
0000781a8ffd3f4d  pop r8
0000781a8ffd3f4f  pop rsi
0000781a8ffd3f50  pop rdi
0000781a8ffd3f51  pop rdx
0000781a8ffd3f52  pop rcx
0000781a8ffd3f53  pop rax
0000781a8ffd3f54  add rsp, 0x08
0000781a8ffd3f58  jmp 0x0000781A8FFD2C3D
0000781a8ffd3f5d  sub rsp, 0x08
0000781a8ffd3f61  push rax
0000781a8ffd3f62  push rcx
0000781a8ffd3f63  push rdx
0000781a8ffd3f64  push rdi
0000781a8ffd3f65  push rsi
0000781a8ffd3f66  push r8
0000781a8ffd3f68  push r9
0000781a8ffd3f6a  push r10
0000781a8ffd3f6c  push r11
0000781a8ffd3f6e  sub rsp, 0xF0
0000781a8ffd3f75  vmovaps [rsp], xmm0
0000781a8ffd3f7a  vmovaps [rsp+0x10], xmm1
0000781a8ffd3f80  vmovaps [rsp+0x20], xmm2
0000781a8ffd3f86  vmovaps [rsp+0x30], xmm3
0000781a8ffd3f8c  vmovaps [rsp+0x40], xmm4
0000781a8ffd3f92  vmovaps [rsp+0x50], xmm5
0000781a8ffd3f98  vmovaps [rsp+0x60], xmm6
0000781a8ffd3f9e  vmovaps [rsp+0x70], xmm7
0000781a8ffd3fa4  vmovaps [rsp+0x80], xmm8
0000781a8ffd3fad  vmovaps [rsp+0x90], xmm9
0000781a8ffd3fb6  vmovaps [rsp+0xA0], xmm10
0000781a8ffd3fbf  vmovaps [rsp+0xB0], xmm11
0000781a8ffd3fc8  vmovaps [rsp+0xC0], xmm12
0000781a8ffd3fd1  vmovaps [rsp+0xD0], xmm13
0000781a8ffd3fda  vmovaps [rsp+0xE0], xmm15
0000781a8ffd3fe3  sub rsp, 0x40
0000781a8ffd3fe7  lea rdi, [rsp]
0000781a8ffd3feb  lea rsi, [rsp+0x10]
0000781a8ffd3ff0  lea rdx, [rsp+0x20]
0000781a8ffd3ff5  lea rcx, [rsp+0x30]
0000781a8ffd3ffa  mov r8d, 0x00
0000781a8ffd4000  lea r9, [r15+0x3A8]
0000781a8ffd4007  movaps [rdi], xmm14
0000781a8ffd400b  movaps [rsi], xmm3
0000781a8ffd400e  movaps [rdx], xmm1
0000781a8ffd4011  movaps [rcx], xmm15
0000781a8ffd4015  mov rax, 0x627DDC279A50
0000781a8ffd401f  call rax
0000781a8ffd4021  movaps xmm14, [rsp]
0000781a8ffd4026  add rsp, 0x40
0000781a8ffd402a  vmovaps xmm0, [rsp]
0000781a8ffd402f  vmovaps xmm1, [rsp+0x10]
0000781a8ffd4035  vmovaps xmm2, [rsp+0x20]
0000781a8ffd403b  vmovaps xmm3, [rsp+0x30]
0000781a8ffd4041  vmovaps xmm4, [rsp+0x40]
0000781a8ffd4047  vmovaps xmm5, [rsp+0x50]
0000781a8ffd404d  vmovaps xmm6, [rsp+0x60]
0000781a8ffd4053  vmovaps xmm7, [rsp+0x70]
0000781a8ffd4059  vmovaps xmm8, [rsp+0x80]
0000781a8ffd4062  vmovaps xmm9, [rsp+0x90]
0000781a8ffd406b  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd4074  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd407d  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd4086  vmovaps xmm13, [rsp+0xD0]
0000781a8ffd408f  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd4098  add rsp, 0xF0
0000781a8ffd409f  pop r11
0000781a8ffd40a1  pop r10
0000781a8ffd40a3  pop r9
0000781a8ffd40a5  pop r8
0000781a8ffd40a7  pop rsi
0000781a8ffd40a8  pop rdi
0000781a8ffd40a9  pop rdx
0000781a8ffd40aa  pop rcx
0000781a8ffd40ab  pop rax
0000781a8ffd40ac  add rsp, 0x08
0000781a8ffd40b0  jmp 0x0000781A8FFD2CF7
0000781a8ffd40b5  sub rsp, 0x08
0000781a8ffd40b9  push rax
0000781a8ffd40ba  push rcx
0000781a8ffd40bb  push rdx
0000781a8ffd40bc  push rdi
0000781a8ffd40bd  push rsi
0000781a8ffd40be  push r8
0000781a8ffd40c0  push r9
0000781a8ffd40c2  push r10
0000781a8ffd40c4  push r11
0000781a8ffd40c6  sub rsp, 0xF0
0000781a8ffd40cd  vmovaps [rsp], xmm0
0000781a8ffd40d2  vmovaps [rsp+0x10], xmm1
0000781a8ffd40d8  vmovaps [rsp+0x20], xmm2
0000781a8ffd40de  vmovaps [rsp+0x30], xmm3
0000781a8ffd40e4  vmovaps [rsp+0x40], xmm4
0000781a8ffd40ea  vmovaps [rsp+0x50], xmm5
0000781a8ffd40f0  vmovaps [rsp+0x60], xmm6
0000781a8ffd40f6  vmovaps [rsp+0x70], xmm7
0000781a8ffd40fc  vmovaps [rsp+0x80], xmm8
0000781a8ffd4105  vmovaps [rsp+0x90], xmm9
0000781a8ffd410e  vmovaps [rsp+0xA0], xmm10
0000781a8ffd4117  vmovaps [rsp+0xB0], xmm11
0000781a8ffd4120  vmovaps [rsp+0xC0], xmm12
0000781a8ffd4129  vmovaps [rsp+0xD0], xmm14
0000781a8ffd4132  vmovaps [rsp+0xE0], xmm15
0000781a8ffd413b  sub rsp, 0x40
0000781a8ffd413f  lea rdi, [rsp]
0000781a8ffd4143  lea rsi, [rsp+0x10]
0000781a8ffd4148  lea rdx, [rsp+0x20]
0000781a8ffd414d  lea rcx, [rsp+0x30]
0000781a8ffd4152  mov r8d, 0x00
0000781a8ffd4158  lea r9, [r15+0x3A8]
0000781a8ffd415f  movaps [rdi], xmm13
0000781a8ffd4163  movaps [rsi], xmm15
0000781a8ffd4167  movaps [rdx], xmm10
0000781a8ffd416b  movaps [rcx], xmm1
0000781a8ffd416e  mov rax, 0x627DDC279A50
0000781a8ffd4178  call rax
0000781a8ffd417a  movaps xmm13, [rsp]
0000781a8ffd417f  add rsp, 0x40
0000781a8ffd4183  vmovaps xmm0, [rsp]
0000781a8ffd4188  vmovaps xmm1, [rsp+0x10]
0000781a8ffd418e  vmovaps xmm2, [rsp+0x20]
0000781a8ffd4194  vmovaps xmm3, [rsp+0x30]
0000781a8ffd419a  vmovaps xmm4, [rsp+0x40]
0000781a8ffd41a0  vmovaps xmm5, [rsp+0x50]
0000781a8ffd41a6  vmovaps xmm6, [rsp+0x60]
0000781a8ffd41ac  vmovaps xmm7, [rsp+0x70]
0000781a8ffd41b2  vmovaps xmm8, [rsp+0x80]
0000781a8ffd41bb  vmovaps xmm9, [rsp+0x90]
0000781a8ffd41c4  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd41cd  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd41d6  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd41df  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd41e8  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd41f1  add rsp, 0xF0
0000781a8ffd41f8  pop r11
0000781a8ffd41fa  pop r10
0000781a8ffd41fc  pop r9
0000781a8ffd41fe  pop r8
0000781a8ffd4200  pop rsi
0000781a8ffd4201  pop rdi
0000781a8ffd4202  pop rdx
0000781a8ffd4203  pop rcx
0000781a8ffd4204  pop rax
0000781a8ffd4205  add rsp, 0x08
0000781a8ffd4209  jmp 0x0000781A8FFD2D26
0000781a8ffd420e  sub rsp, 0x08
0000781a8ffd4212  push rax
0000781a8ffd4213  push rcx
0000781a8ffd4214  push rdx
0000781a8ffd4215  push rdi
0000781a8ffd4216  push rsi
0000781a8ffd4217  push r8
0000781a8ffd4219  push r9
0000781a8ffd421b  push r10
0000781a8ffd421d  push r11
0000781a8ffd421f  sub rsp, 0xF0
0000781a8ffd4226  vmovaps [rsp], xmm0
0000781a8ffd422b  vmovaps [rsp+0x10], xmm1
0000781a8ffd4231  vmovaps [rsp+0x20], xmm2
0000781a8ffd4237  vmovaps [rsp+0x30], xmm3
0000781a8ffd423d  vmovaps [rsp+0x40], xmm4
0000781a8ffd4243  vmovaps [rsp+0x50], xmm5
0000781a8ffd4249  vmovaps [rsp+0x60], xmm6
0000781a8ffd424f  vmovaps [rsp+0x70], xmm7
0000781a8ffd4255  vmovaps [rsp+0x80], xmm8
0000781a8ffd425e  vmovaps [rsp+0x90], xmm9
0000781a8ffd4267  vmovaps [rsp+0xA0], xmm11
0000781a8ffd4270  vmovaps [rsp+0xB0], xmm12
0000781a8ffd4279  vmovaps [rsp+0xC0], xmm13
0000781a8ffd4282  vmovaps [rsp+0xD0], xmm14
0000781a8ffd428b  vmovaps [rsp+0xE0], xmm15
0000781a8ffd4294  sub rsp, 0x40
0000781a8ffd4298  lea rdi, [rsp]
0000781a8ffd429c  lea rsi, [rsp+0x10]
0000781a8ffd42a1  lea rdx, [rsp+0x20]
0000781a8ffd42a6  lea rcx, [rsp+0x30]
0000781a8ffd42ab  mov r8d, 0x00
0000781a8ffd42b1  lea r9, [r15+0x3A8]
0000781a8ffd42b8  movaps [rdi], xmm10
0000781a8ffd42bc  movaps [rsi], xmm15
0000781a8ffd42c0  movaps [rdx], xmm11
0000781a8ffd42c4  movaps [rcx], xmm1
0000781a8ffd42c7  mov rax, 0x627DDC279A50
0000781a8ffd42d1  call rax
0000781a8ffd42d3  movaps xmm10, [rsp]
0000781a8ffd42d8  add rsp, 0x40
0000781a8ffd42dc  vmovaps xmm0, [rsp]
0000781a8ffd42e1  vmovaps xmm1, [rsp+0x10]
0000781a8ffd42e7  vmovaps xmm2, [rsp+0x20]
0000781a8ffd42ed  vmovaps xmm3, [rsp+0x30]
0000781a8ffd42f3  vmovaps xmm4, [rsp+0x40]
0000781a8ffd42f9  vmovaps xmm5, [rsp+0x50]
0000781a8ffd42ff  vmovaps xmm6, [rsp+0x60]
0000781a8ffd4305  vmovaps xmm7, [rsp+0x70]
0000781a8ffd430b  vmovaps xmm8, [rsp+0x80]
0000781a8ffd4314  vmovaps xmm9, [rsp+0x90]
0000781a8ffd431d  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd4326  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd432f  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd4338  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd4341  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd434a  add rsp, 0xF0
0000781a8ffd4351  pop r11
0000781a8ffd4353  pop r10
0000781a8ffd4355  pop r9
0000781a8ffd4357  pop r8
0000781a8ffd4359  pop rsi
0000781a8ffd435a  pop rdi
0000781a8ffd435b  pop rdx
0000781a8ffd435c  pop rcx
0000781a8ffd435d  pop rax
0000781a8ffd435e  add rsp, 0x08
0000781a8ffd4362  jmp 0x0000781A8FFD2D55
0000781a8ffd4367  sub rsp, 0x08
0000781a8ffd436b  push rax
0000781a8ffd436c  push rcx
0000781a8ffd436d  push rdx
0000781a8ffd436e  push rdi
0000781a8ffd436f  push rsi
0000781a8ffd4370  push r8
0000781a8ffd4372  push r9
0000781a8ffd4374  push r10
0000781a8ffd4376  push r11
0000781a8ffd4378  sub rsp, 0xF0
0000781a8ffd437f  vmovaps [rsp], xmm0
0000781a8ffd4384  vmovaps [rsp+0x10], xmm1
0000781a8ffd438a  vmovaps [rsp+0x20], xmm2
0000781a8ffd4390  vmovaps [rsp+0x30], xmm3
0000781a8ffd4396  vmovaps [rsp+0x40], xmm4
0000781a8ffd439c  vmovaps [rsp+0x50], xmm5
0000781a8ffd43a2  vmovaps [rsp+0x60], xmm6
0000781a8ffd43a8  vmovaps [rsp+0x70], xmm7
0000781a8ffd43ae  vmovaps [rsp+0x80], xmm8
0000781a8ffd43b7  vmovaps [rsp+0x90], xmm9
0000781a8ffd43c0  vmovaps [rsp+0xA0], xmm10
0000781a8ffd43c9  vmovaps [rsp+0xB0], xmm11
0000781a8ffd43d2  vmovaps [rsp+0xC0], xmm12
0000781a8ffd43db  vmovaps [rsp+0xD0], xmm13
0000781a8ffd43e4  vmovaps [rsp+0xE0], xmm14
0000781a8ffd43ed  sub rsp, 0x40
0000781a8ffd43f1  lea rdi, [rsp]
0000781a8ffd43f5  lea rsi, [rsp+0x10]
0000781a8ffd43fa  lea rdx, [rsp+0x20]
0000781a8ffd43ff  lea rcx, [rsp+0x30]
0000781a8ffd4404  mov r8d, 0x00
0000781a8ffd440a  lea r9, [r15+0x3A8]
0000781a8ffd4411  movaps [rdi], xmm15
0000781a8ffd4415  movaps [rsi], xmm12
0000781a8ffd4419  movaps [rdx], xmm5
0000781a8ffd441c  movaps [rcx], xmm1
0000781a8ffd441f  mov rax, 0x627DDC279A50
0000781a8ffd4429  call rax
0000781a8ffd442b  movaps xmm15, [rsp]
0000781a8ffd4430  add rsp, 0x40
0000781a8ffd4434  vmovaps xmm0, [rsp]
0000781a8ffd4439  vmovaps xmm1, [rsp+0x10]
0000781a8ffd443f  vmovaps xmm2, [rsp+0x20]
0000781a8ffd4445  vmovaps xmm3, [rsp+0x30]
0000781a8ffd444b  vmovaps xmm4, [rsp+0x40]
0000781a8ffd4451  vmovaps xmm5, [rsp+0x50]
0000781a8ffd4457  vmovaps xmm6, [rsp+0x60]
0000781a8ffd445d  vmovaps xmm7, [rsp+0x70]
0000781a8ffd4463  vmovaps xmm8, [rsp+0x80]
0000781a8ffd446c  vmovaps xmm9, [rsp+0x90]
0000781a8ffd4475  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd447e  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd4487  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd4490  vmovaps xmm13, [rsp+0xD0]
0000781a8ffd4499  vmovaps xmm14, [rsp+0xE0]
0000781a8ffd44a2  add rsp, 0xF0
0000781a8ffd44a9  pop r11
0000781a8ffd44ab  pop r10
0000781a8ffd44ad  pop r9
0000781a8ffd44af  pop r8
0000781a8ffd44b1  pop rsi
0000781a8ffd44b2  pop rdi
0000781a8ffd44b3  pop rdx
0000781a8ffd44b4  pop rcx
0000781a8ffd44b5  pop rax
0000781a8ffd44b6  add rsp, 0x08
0000781a8ffd44ba  jmp 0x0000781A8FFD2D7E
0000781a8ffd44bf  sub rsp, 0x08
0000781a8ffd44c3  push rax
0000781a8ffd44c4  push rcx
0000781a8ffd44c5  push rdx
0000781a8ffd44c6  push rdi
0000781a8ffd44c7  push rsi
0000781a8ffd44c8  push r8
0000781a8ffd44ca  push r9
0000781a8ffd44cc  push r10
0000781a8ffd44ce  push r11
0000781a8ffd44d0  sub rsp, 0xF0
0000781a8ffd44d7  vmovaps [rsp], xmm0
0000781a8ffd44dc  vmovaps [rsp+0x10], xmm1
0000781a8ffd44e2  vmovaps [rsp+0x20], xmm2
0000781a8ffd44e8  vmovaps [rsp+0x30], xmm3
0000781a8ffd44ee  vmovaps [rsp+0x40], xmm4
0000781a8ffd44f4  vmovaps [rsp+0x50], xmm6
0000781a8ffd44fa  vmovaps [rsp+0x60], xmm7
0000781a8ffd4500  vmovaps [rsp+0x70], xmm8
0000781a8ffd4506  vmovaps [rsp+0x80], xmm9
0000781a8ffd450f  vmovaps [rsp+0x90], xmm10
0000781a8ffd4518  vmovaps [rsp+0xA0], xmm11
0000781a8ffd4521  vmovaps [rsp+0xB0], xmm12
0000781a8ffd452a  vmovaps [rsp+0xC0], xmm13
0000781a8ffd4533  vmovaps [rsp+0xD0], xmm14
0000781a8ffd453c  vmovaps [rsp+0xE0], xmm15
0000781a8ffd4545  sub rsp, 0x40
0000781a8ffd4549  lea rdi, [rsp]
0000781a8ffd454d  lea rsi, [rsp+0x10]
0000781a8ffd4552  lea rdx, [rsp+0x20]
0000781a8ffd4557  lea rcx, [rsp+0x30]
0000781a8ffd455c  mov r8d, 0x00
0000781a8ffd4562  lea r9, [r15+0x3A8]
0000781a8ffd4569  movaps [rdi], xmm5
0000781a8ffd456c  movaps [rsi], xmm13
0000781a8ffd4570  movaps [rdx], xmm11
0000781a8ffd4574  movaps [rcx], xmm12
0000781a8ffd4578  mov rax, 0x627DDC279A50
0000781a8ffd4582  call rax
0000781a8ffd4584  movaps xmm5, [rsp]
0000781a8ffd4588  add rsp, 0x40
0000781a8ffd458c  vmovaps xmm0, [rsp]
0000781a8ffd4591  vmovaps xmm1, [rsp+0x10]
0000781a8ffd4597  vmovaps xmm2, [rsp+0x20]
0000781a8ffd459d  vmovaps xmm3, [rsp+0x30]
0000781a8ffd45a3  vmovaps xmm4, [rsp+0x40]
0000781a8ffd45a9  vmovaps xmm6, [rsp+0x50]
0000781a8ffd45af  vmovaps xmm7, [rsp+0x60]
0000781a8ffd45b5  vmovaps xmm8, [rsp+0x70]
0000781a8ffd45bb  vmovaps xmm9, [rsp+0x80]
0000781a8ffd45c4  vmovaps xmm10, [rsp+0x90]
0000781a8ffd45cd  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd45d6  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd45df  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd45e8  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd45f1  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd45fa  add rsp, 0xF0
0000781a8ffd4601  pop r11
0000781a8ffd4603  pop r10
0000781a8ffd4605  pop r9
0000781a8ffd4607  pop r8
0000781a8ffd4609  pop rsi
0000781a8ffd460a  pop rdi
0000781a8ffd460b  pop rdx
0000781a8ffd460c  pop rcx
0000781a8ffd460d  pop rax
0000781a8ffd460e  add rsp, 0x08
0000781a8ffd4612  jmp 0x0000781A8FFD2DDD
0000781a8ffd4617  sub rsp, 0x08
0000781a8ffd461b  push rax
0000781a8ffd461c  push rcx
0000781a8ffd461d  push rdx
0000781a8ffd461e  push rdi
0000781a8ffd461f  push rsi
0000781a8ffd4620  push r8
0000781a8ffd4622  push r9
0000781a8ffd4624  push r10
0000781a8ffd4626  push r11
0000781a8ffd4628  sub rsp, 0xF0
0000781a8ffd462f  vmovaps [rsp], xmm0
0000781a8ffd4634  vmovaps [rsp+0x10], xmm1
0000781a8ffd463a  vmovaps [rsp+0x20], xmm2
0000781a8ffd4640  vmovaps [rsp+0x30], xmm3
0000781a8ffd4646  vmovaps [rsp+0x40], xmm4
0000781a8ffd464c  vmovaps [rsp+0x50], xmm5
0000781a8ffd4652  vmovaps [rsp+0x60], xmm6
0000781a8ffd4658  vmovaps [rsp+0x70], xmm7
0000781a8ffd465e  vmovaps [rsp+0x80], xmm8
0000781a8ffd4667  vmovaps [rsp+0x90], xmm9
0000781a8ffd4670  vmovaps [rsp+0xA0], xmm10
0000781a8ffd4679  vmovaps [rsp+0xB0], xmm11
0000781a8ffd4682  vmovaps [rsp+0xC0], xmm13
0000781a8ffd468b  vmovaps [rsp+0xD0], xmm14
0000781a8ffd4694  vmovaps [rsp+0xE0], xmm15
0000781a8ffd469d  sub rsp, 0x40
0000781a8ffd46a1  lea rdi, [rsp]
0000781a8ffd46a5  lea rsi, [rsp+0x10]
0000781a8ffd46aa  lea rdx, [rsp+0x20]
0000781a8ffd46af  lea rcx, [rsp+0x30]
0000781a8ffd46b4  mov r8d, 0x00
0000781a8ffd46ba  lea r9, [r15+0x3A8]
0000781a8ffd46c1  movaps [rdi], xmm12
0000781a8ffd46c5  movaps [rsi], xmm14
0000781a8ffd46c9  movaps [rdx], xmm9
0000781a8ffd46cd  movaps [rcx], xmm13
0000781a8ffd46d1  mov rax, 0x627DDC279A50
0000781a8ffd46db  call rax
0000781a8ffd46dd  movaps xmm12, [rsp]
0000781a8ffd46e2  add rsp, 0x40
0000781a8ffd46e6  vmovaps xmm0, [rsp]
0000781a8ffd46eb  vmovaps xmm1, [rsp+0x10]
0000781a8ffd46f1  vmovaps xmm2, [rsp+0x20]
0000781a8ffd46f7  vmovaps xmm3, [rsp+0x30]
0000781a8ffd46fd  vmovaps xmm4, [rsp+0x40]
0000781a8ffd4703  vmovaps xmm5, [rsp+0x50]
0000781a8ffd4709  vmovaps xmm6, [rsp+0x60]
0000781a8ffd470f  vmovaps xmm7, [rsp+0x70]
0000781a8ffd4715  vmovaps xmm8, [rsp+0x80]
0000781a8ffd471e  vmovaps xmm9, [rsp+0x90]
0000781a8ffd4727  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd4730  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd4739  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd4742  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd474b  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd4754  add rsp, 0xF0
0000781a8ffd475b  pop r11
0000781a8ffd475d  pop r10
0000781a8ffd475f  pop r9
0000781a8ffd4761  pop r8
0000781a8ffd4763  pop rsi
0000781a8ffd4764  pop rdi
0000781a8ffd4765  pop rdx
0000781a8ffd4766  pop rcx
0000781a8ffd4767  pop rax
0000781a8ffd4768  add rsp, 0x08
0000781a8ffd476c  jmp 0x0000781A8FFD2E06
0000781a8ffd4771  call 0x0000781A8FE0D4E0
0000781a8ffd4776  jmp 0x0000781A8FFD2E13
0000781a8ffd477b  sub rsp, 0x08
0000781a8ffd477f  push rax
0000781a8ffd4780  push rcx
0000781a8ffd4781  push rdx
0000781a8ffd4782  push rdi
0000781a8ffd4783  push rsi
0000781a8ffd4784  push r8
0000781a8ffd4786  push r9
0000781a8ffd4788  push r10
0000781a8ffd478a  push r11
0000781a8ffd478c  sub rsp, 0xF0
0000781a8ffd4793  vmovaps [rsp], xmm0
0000781a8ffd4798  vmovaps [rsp+0x10], xmm1
0000781a8ffd479e  vmovaps [rsp+0x20], xmm2
0000781a8ffd47a4  vmovaps [rsp+0x30], xmm3
0000781a8ffd47aa  vmovaps [rsp+0x40], xmm4
0000781a8ffd47b0  vmovaps [rsp+0x50], xmm5
0000781a8ffd47b6  vmovaps [rsp+0x60], xmm6
0000781a8ffd47bc  vmovaps [rsp+0x70], xmm7
0000781a8ffd47c2  vmovaps [rsp+0x80], xmm8
0000781a8ffd47cb  vmovaps [rsp+0x90], xmm9
0000781a8ffd47d4  vmovaps [rsp+0xA0], xmm10
0000781a8ffd47dd  vmovaps [rsp+0xB0], xmm12
0000781a8ffd47e6  vmovaps [rsp+0xC0], xmm13
0000781a8ffd47ef  vmovaps [rsp+0xD0], xmm14
0000781a8ffd47f8  vmovaps [rsp+0xE0], xmm15
0000781a8ffd4801  sub rsp, 0x40
0000781a8ffd4805  lea rdi, [rsp]
0000781a8ffd4809  lea rsi, [rsp+0x10]
0000781a8ffd480e  lea rdx, [rsp+0x20]
0000781a8ffd4813  lea rcx, [rsp+0x30]
0000781a8ffd4818  mov r8d, 0x00
0000781a8ffd481e  lea r9, [r15+0x3A8]
0000781a8ffd4825  movaps [rdi], xmm11
0000781a8ffd4829  movaps [rsi], xmm10
0000781a8ffd482d  movaps [rdx], xmm8
0000781a8ffd4831  movaps [rcx], xmm13
0000781a8ffd4835  mov rax, 0x627DDC279A50
0000781a8ffd483f  call rax
0000781a8ffd4841  movaps xmm11, [rsp]
0000781a8ffd4846  add rsp, 0x40
0000781a8ffd484a  vmovaps xmm0, [rsp]
0000781a8ffd484f  vmovaps xmm1, [rsp+0x10]
0000781a8ffd4855  vmovaps xmm2, [rsp+0x20]
0000781a8ffd485b  vmovaps xmm3, [rsp+0x30]
0000781a8ffd4861  vmovaps xmm4, [rsp+0x40]
0000781a8ffd4867  vmovaps xmm5, [rsp+0x50]
0000781a8ffd486d  vmovaps xmm6, [rsp+0x60]
0000781a8ffd4873  vmovaps xmm7, [rsp+0x70]
0000781a8ffd4879  vmovaps xmm8, [rsp+0x80]
0000781a8ffd4882  vmovaps xmm9, [rsp+0x90]
0000781a8ffd488b  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd4894  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd489d  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd48a6  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd48af  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd48b8  add rsp, 0xF0
0000781a8ffd48bf  pop r11
0000781a8ffd48c1  pop r10
0000781a8ffd48c3  pop r9
0000781a8ffd48c5  pop r8
0000781a8ffd48c7  pop rsi
0000781a8ffd48c8  pop rdi
0000781a8ffd48c9  pop rdx
0000781a8ffd48ca  pop rcx
0000781a8ffd48cb  pop rax
0000781a8ffd48cc  add rsp, 0x08
0000781a8ffd48d0  jmp 0x0000781A8FFD2E44
0000781a8ffd48d5  sub rsp, 0x08
0000781a8ffd48d9  push rax
0000781a8ffd48da  push rcx
0000781a8ffd48db  push rdx
0000781a8ffd48dc  push rdi
0000781a8ffd48dd  push rsi
0000781a8ffd48de  push r8
0000781a8ffd48e0  push r9
0000781a8ffd48e2  push r10
0000781a8ffd48e4  push r11
0000781a8ffd48e6  sub rsp, 0xF0
0000781a8ffd48ed  vmovaps [rsp], xmm0
0000781a8ffd48f2  vmovaps [rsp+0x10], xmm1
0000781a8ffd48f8  vmovaps [rsp+0x20], xmm2
0000781a8ffd48fe  vmovaps [rsp+0x30], xmm3
0000781a8ffd4904  vmovaps [rsp+0x40], xmm4
0000781a8ffd490a  vmovaps [rsp+0x50], xmm5
0000781a8ffd4910  vmovaps [rsp+0x60], xmm6
0000781a8ffd4916  vmovaps [rsp+0x70], xmm7
0000781a8ffd491c  vmovaps [rsp+0x80], xmm8
0000781a8ffd4925  vmovaps [rsp+0x90], xmm9
0000781a8ffd492e  vmovaps [rsp+0xA0], xmm11
0000781a8ffd4937  vmovaps [rsp+0xB0], xmm12
0000781a8ffd4940  vmovaps [rsp+0xC0], xmm13
0000781a8ffd4949  vmovaps [rsp+0xD0], xmm14
0000781a8ffd4952  vmovaps [rsp+0xE0], xmm15
0000781a8ffd495b  sub rsp, 0x40
0000781a8ffd495f  lea rdi, [rsp]
0000781a8ffd4963  lea rsi, [rsp+0x10]
0000781a8ffd4968  lea rdx, [rsp+0x20]
0000781a8ffd496d  lea rcx, [rsp+0x30]
0000781a8ffd4972  mov r8d, 0x00
0000781a8ffd4978  lea r9, [r15+0x3A8]
0000781a8ffd497f  movaps [rdi], xmm10
0000781a8ffd4983  movaps [rsi], xmm15
0000781a8ffd4987  movaps [rdx], xmm1
0000781a8ffd498a  movaps [rcx], xmm13
0000781a8ffd498e  mov rax, 0x627DDC279A50
0000781a8ffd4998  call rax
0000781a8ffd499a  movaps xmm10, [rsp]
0000781a8ffd499f  add rsp, 0x40
0000781a8ffd49a3  vmovaps xmm0, [rsp]
0000781a8ffd49a8  vmovaps xmm1, [rsp+0x10]
0000781a8ffd49ae  vmovaps xmm2, [rsp+0x20]
0000781a8ffd49b4  vmovaps xmm3, [rsp+0x30]
0000781a8ffd49ba  vmovaps xmm4, [rsp+0x40]
0000781a8ffd49c0  vmovaps xmm5, [rsp+0x50]
0000781a8ffd49c6  vmovaps xmm6, [rsp+0x60]
0000781a8ffd49cc  vmovaps xmm7, [rsp+0x70]
0000781a8ffd49d2  vmovaps xmm8, [rsp+0x80]
0000781a8ffd49db  vmovaps xmm9, [rsp+0x90]
0000781a8ffd49e4  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd49ed  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd49f6  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd49ff  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd4a08  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd4a11  add rsp, 0xF0
0000781a8ffd4a18  pop r11
0000781a8ffd4a1a  pop r10
0000781a8ffd4a1c  pop r9
0000781a8ffd4a1e  pop r8
0000781a8ffd4a20  pop rsi
0000781a8ffd4a21  pop rdi
0000781a8ffd4a22  pop rdx
0000781a8ffd4a23  pop rcx
0000781a8ffd4a24  pop rax
0000781a8ffd4a25  add rsp, 0x08
0000781a8ffd4a29  jmp 0x0000781A8FFD2E6D
0000781a8ffd4a2e  call 0x0000781A8FDFF430
0000781a8ffd4a33  jmp 0x0000781A8FFD2E8F
0000781a8ffd4a38  call 0x0000781A8FE0E760
0000781a8ffd4a3d  jmp 0x0000781A8FFD2E99
0000781a8ffd4a42  sub rsp, 0x08
0000781a8ffd4a46  push rax
0000781a8ffd4a47  push rcx
0000781a8ffd4a48  push rdx
0000781a8ffd4a49  push rdi
0000781a8ffd4a4a  push rsi
0000781a8ffd4a4b  push r8
0000781a8ffd4a4d  push r9
0000781a8ffd4a4f  push r10
0000781a8ffd4a51  push r11
0000781a8ffd4a53  sub rsp, 0xF0
0000781a8ffd4a5a  vmovaps [rsp], xmm0
0000781a8ffd4a5f  vmovaps [rsp+0x10], xmm1
0000781a8ffd4a65  vmovaps [rsp+0x20], xmm2
0000781a8ffd4a6b  vmovaps [rsp+0x30], xmm3
0000781a8ffd4a71  vmovaps [rsp+0x40], xmm4
0000781a8ffd4a77  vmovaps [rsp+0x50], xmm5
0000781a8ffd4a7d  vmovaps [rsp+0x60], xmm6
0000781a8ffd4a83  vmovaps [rsp+0x70], xmm7
0000781a8ffd4a89  vmovaps [rsp+0x80], xmm9
0000781a8ffd4a92  vmovaps [rsp+0x90], xmm10
0000781a8ffd4a9b  vmovaps [rsp+0xA0], xmm11
0000781a8ffd4aa4  vmovaps [rsp+0xB0], xmm12
0000781a8ffd4aad  vmovaps [rsp+0xC0], xmm13
0000781a8ffd4ab6  vmovaps [rsp+0xD0], xmm14
0000781a8ffd4abf  vmovaps [rsp+0xE0], xmm15
0000781a8ffd4ac8  sub rsp, 0x40
0000781a8ffd4acc  lea rdi, [rsp]
0000781a8ffd4ad0  lea rsi, [rsp+0x10]
0000781a8ffd4ad5  lea rdx, [rsp+0x20]
0000781a8ffd4ada  lea rcx, [rsp+0x30]
0000781a8ffd4adf  mov r8d, 0x00
0000781a8ffd4ae5  lea r9, [r15+0x3A8]
0000781a8ffd4aec  movaps [rdi], xmm8
0000781a8ffd4af0  movaps [rsi], xmm5
0000781a8ffd4af3  movaps [rdx], xmm9
0000781a8ffd4af7  movaps [rcx], xmm13
0000781a8ffd4afb  mov rax, 0x627DDC279A50
0000781a8ffd4b05  call rax
0000781a8ffd4b07  movaps xmm8, [rsp]
0000781a8ffd4b0c  add rsp, 0x40
0000781a8ffd4b10  vmovaps xmm0, [rsp]
0000781a8ffd4b15  vmovaps xmm1, [rsp+0x10]
0000781a8ffd4b1b  vmovaps xmm2, [rsp+0x20]
0000781a8ffd4b21  vmovaps xmm3, [rsp+0x30]
0000781a8ffd4b27  vmovaps xmm4, [rsp+0x40]
0000781a8ffd4b2d  vmovaps xmm5, [rsp+0x50]
0000781a8ffd4b33  vmovaps xmm6, [rsp+0x60]
0000781a8ffd4b39  vmovaps xmm7, [rsp+0x70]
0000781a8ffd4b3f  vmovaps xmm9, [rsp+0x80]
0000781a8ffd4b48  vmovaps xmm10, [rsp+0x90]
0000781a8ffd4b51  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd4b5a  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd4b63  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd4b6c  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd4b75  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd4b7e  add rsp, 0xF0
0000781a8ffd4b85  pop r11
0000781a8ffd4b87  pop r10
0000781a8ffd4b89  pop r9
0000781a8ffd4b8b  pop r8
0000781a8ffd4b8d  pop rsi
0000781a8ffd4b8e  pop rdi
0000781a8ffd4b8f  pop rdx
0000781a8ffd4b90  pop rcx
0000781a8ffd4b91  pop rax
0000781a8ffd4b92  add rsp, 0x08
0000781a8ffd4b96  jmp 0x0000781A8FFD2ED8
0000781a8ffd4b9b  sub rsp, 0x08
0000781a8ffd4b9f  push rax
0000781a8ffd4ba0  push rcx
0000781a8ffd4ba1  push rdx
0000781a8ffd4ba2  push rdi
0000781a8ffd4ba3  push rsi
0000781a8ffd4ba4  push r8
0000781a8ffd4ba6  push r9
0000781a8ffd4ba8  push r10
0000781a8ffd4baa  push r11
0000781a8ffd4bac  sub rsp, 0xF0
0000781a8ffd4bb3  vmovaps [rsp], xmm0
0000781a8ffd4bb8  vmovaps [rsp+0x10], xmm1
0000781a8ffd4bbe  vmovaps [rsp+0x20], xmm2
0000781a8ffd4bc4  vmovaps [rsp+0x30], xmm3
0000781a8ffd4bca  vmovaps [rsp+0x40], xmm4
0000781a8ffd4bd0  vmovaps [rsp+0x50], xmm5
0000781a8ffd4bd6  vmovaps [rsp+0x60], xmm6
0000781a8ffd4bdc  vmovaps [rsp+0x70], xmm7
0000781a8ffd4be2  vmovaps [rsp+0x80], xmm8
0000781a8ffd4beb  vmovaps [rsp+0x90], xmm10
0000781a8ffd4bf4  vmovaps [rsp+0xA0], xmm11
0000781a8ffd4bfd  vmovaps [rsp+0xB0], xmm12
0000781a8ffd4c06  vmovaps [rsp+0xC0], xmm13
0000781a8ffd4c0f  vmovaps [rsp+0xD0], xmm14
0000781a8ffd4c18  vmovaps [rsp+0xE0], xmm15
0000781a8ffd4c21  sub rsp, 0x40
0000781a8ffd4c25  lea rdi, [rsp]
0000781a8ffd4c29  lea rsi, [rsp+0x10]
0000781a8ffd4c2e  lea rdx, [rsp+0x20]
0000781a8ffd4c33  lea rcx, [rsp+0x30]
0000781a8ffd4c38  mov r8d, 0x00
0000781a8ffd4c3e  lea r9, [r15+0x3A8]
0000781a8ffd4c45  movaps [rdi], xmm9
0000781a8ffd4c49  movaps [rsi], xmm12
0000781a8ffd4c4d  movaps [rdx], xmm7
0000781a8ffd4c50  movaps [rcx], xmm13
0000781a8ffd4c54  mov rax, 0x627DDC279A50
0000781a8ffd4c5e  call rax
0000781a8ffd4c60  movaps xmm9, [rsp]
0000781a8ffd4c65  add rsp, 0x40
0000781a8ffd4c69  vmovaps xmm0, [rsp]
0000781a8ffd4c6e  vmovaps xmm1, [rsp+0x10]
0000781a8ffd4c74  vmovaps xmm2, [rsp+0x20]
0000781a8ffd4c7a  vmovaps xmm3, [rsp+0x30]
0000781a8ffd4c80  vmovaps xmm4, [rsp+0x40]
0000781a8ffd4c86  vmovaps xmm5, [rsp+0x50]
0000781a8ffd4c8c  vmovaps xmm6, [rsp+0x60]
0000781a8ffd4c92  vmovaps xmm7, [rsp+0x70]
0000781a8ffd4c98  vmovaps xmm8, [rsp+0x80]
0000781a8ffd4ca1  vmovaps xmm10, [rsp+0x90]
0000781a8ffd4caa  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd4cb3  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd4cbc  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd4cc5  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd4cce  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd4cd7  add rsp, 0xF0
0000781a8ffd4cde  pop r11
0000781a8ffd4ce0  pop r10
0000781a8ffd4ce2  pop r9
0000781a8ffd4ce4  pop r8
0000781a8ffd4ce6  pop rsi
0000781a8ffd4ce7  pop rdi
0000781a8ffd4ce8  pop rdx
0000781a8ffd4ce9  pop rcx
0000781a8ffd4cea  pop rax
0000781a8ffd4ceb  add rsp, 0x08
0000781a8ffd4cef  jmp 0x0000781A8FFD2F01
0000781a8ffd4cf4  sub rsp, 0x08
0000781a8ffd4cf8  push rax
0000781a8ffd4cf9  push rcx
0000781a8ffd4cfa  push rdx
0000781a8ffd4cfb  push rdi
0000781a8ffd4cfc  push rsi
0000781a8ffd4cfd  push r8
0000781a8ffd4cff  push r9
0000781a8ffd4d01  push r10
0000781a8ffd4d03  push r11
0000781a8ffd4d05  sub rsp, 0xF0
0000781a8ffd4d0c  vmovaps [rsp], xmm0
0000781a8ffd4d11  vmovaps [rsp+0x10], xmm1
0000781a8ffd4d17  vmovaps [rsp+0x20], xmm2
0000781a8ffd4d1d  vmovaps [rsp+0x30], xmm3
0000781a8ffd4d23  vmovaps [rsp+0x40], xmm4
0000781a8ffd4d29  vmovaps [rsp+0x50], xmm5
0000781a8ffd4d2f  vmovaps [rsp+0x60], xmm6
0000781a8ffd4d35  vmovaps [rsp+0x70], xmm7
0000781a8ffd4d3b  vmovaps [rsp+0x80], xmm8
0000781a8ffd4d44  vmovaps [rsp+0x90], xmm9
0000781a8ffd4d4d  vmovaps [rsp+0xA0], xmm10
0000781a8ffd4d56  vmovaps [rsp+0xB0], xmm11
0000781a8ffd4d5f  vmovaps [rsp+0xC0], xmm13
0000781a8ffd4d68  vmovaps [rsp+0xD0], xmm14
0000781a8ffd4d71  vmovaps [rsp+0xE0], xmm15
0000781a8ffd4d7a  sub rsp, 0x40
0000781a8ffd4d7e  lea rdi, [rsp]
0000781a8ffd4d82  lea rsi, [rsp+0x10]
0000781a8ffd4d87  lea rdx, [rsp+0x20]
0000781a8ffd4d8c  lea rcx, [rsp+0x30]
0000781a8ffd4d91  mov r8d, 0x00
0000781a8ffd4d97  lea r9, [r15+0x3A8]
0000781a8ffd4d9e  movaps [rdi], xmm12
0000781a8ffd4da2  movaps [rsi], xmm11
0000781a8ffd4da6  movaps [rdx], xmm6
0000781a8ffd4da9  movaps [rcx], xmm13
0000781a8ffd4dad  mov rax, 0x627DDC279A50
0000781a8ffd4db7  call rax
0000781a8ffd4db9  movaps xmm12, [rsp]
0000781a8ffd4dbe  add rsp, 0x40
0000781a8ffd4dc2  vmovaps xmm0, [rsp]
0000781a8ffd4dc7  vmovaps xmm1, [rsp+0x10]
0000781a8ffd4dcd  vmovaps xmm2, [rsp+0x20]
0000781a8ffd4dd3  vmovaps xmm3, [rsp+0x30]
0000781a8ffd4dd9  vmovaps xmm4, [rsp+0x40]
0000781a8ffd4ddf  vmovaps xmm5, [rsp+0x50]
0000781a8ffd4de5  vmovaps xmm6, [rsp+0x60]
0000781a8ffd4deb  vmovaps xmm7, [rsp+0x70]
0000781a8ffd4df1  vmovaps xmm8, [rsp+0x80]
0000781a8ffd4dfa  vmovaps xmm9, [rsp+0x90]
0000781a8ffd4e03  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd4e0c  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd4e15  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd4e1e  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd4e27  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd4e30  add rsp, 0xF0
0000781a8ffd4e37  pop r11
0000781a8ffd4e39  pop r10
0000781a8ffd4e3b  pop r9
0000781a8ffd4e3d  pop r8
0000781a8ffd4e3f  pop rsi
0000781a8ffd4e40  pop rdi
0000781a8ffd4e41  pop rdx
0000781a8ffd4e42  pop rcx
0000781a8ffd4e43  pop rax
0000781a8ffd4e44  add rsp, 0x08
0000781a8ffd4e48  jmp 0x0000781A8FFD2F2A
0000781a8ffd4e4d  sub rsp, 0x08
0000781a8ffd4e51  push rax
0000781a8ffd4e52  push rcx
0000781a8ffd4e53  push rdx
0000781a8ffd4e54  push rdi
0000781a8ffd4e55  push rsi
0000781a8ffd4e56  push r8
0000781a8ffd4e58  push r9
0000781a8ffd4e5a  push r10
0000781a8ffd4e5c  push r11
0000781a8ffd4e5e  sub rsp, 0xF0
0000781a8ffd4e65  vmovaps [rsp], xmm0
0000781a8ffd4e6a  vmovaps [rsp+0x10], xmm1
0000781a8ffd4e70  vmovaps [rsp+0x20], xmm2
0000781a8ffd4e76  vmovaps [rsp+0x30], xmm3
0000781a8ffd4e7c  vmovaps [rsp+0x40], xmm4
0000781a8ffd4e82  vmovaps [rsp+0x50], xmm5
0000781a8ffd4e88  vmovaps [rsp+0x60], xmm6
0000781a8ffd4e8e  vmovaps [rsp+0x70], xmm8
0000781a8ffd4e94  vmovaps [rsp+0x80], xmm9
0000781a8ffd4e9d  vmovaps [rsp+0x90], xmm10
0000781a8ffd4ea6  vmovaps [rsp+0xA0], xmm11
0000781a8ffd4eaf  vmovaps [rsp+0xB0], xmm12
0000781a8ffd4eb8  vmovaps [rsp+0xC0], xmm13
0000781a8ffd4ec1  vmovaps [rsp+0xD0], xmm14
0000781a8ffd4eca  vmovaps [rsp+0xE0], xmm15
0000781a8ffd4ed3  sub rsp, 0x40
0000781a8ffd4ed7  lea rdi, [rsp]
0000781a8ffd4edb  lea rsi, [rsp+0x10]
0000781a8ffd4ee0  lea rdx, [rsp+0x20]
0000781a8ffd4ee5  lea rcx, [rsp+0x30]
0000781a8ffd4eea  mov r8d, 0x00
0000781a8ffd4ef0  lea r9, [r15+0x3A8]
0000781a8ffd4ef7  movaps [rdi], xmm7
0000781a8ffd4efa  movaps [rsi], xmm10
0000781a8ffd4efe  movaps [rdx], xmm11
0000781a8ffd4f02  movaps [rcx], xmm13
0000781a8ffd4f06  mov rax, 0x627DDC279A50
0000781a8ffd4f10  call rax
0000781a8ffd4f12  movaps xmm7, [rsp]
0000781a8ffd4f16  add rsp, 0x40
0000781a8ffd4f1a  vmovaps xmm0, [rsp]
0000781a8ffd4f1f  vmovaps xmm1, [rsp+0x10]
0000781a8ffd4f25  vmovaps xmm2, [rsp+0x20]
0000781a8ffd4f2b  vmovaps xmm3, [rsp+0x30]
0000781a8ffd4f31  vmovaps xmm4, [rsp+0x40]
0000781a8ffd4f37  vmovaps xmm5, [rsp+0x50]
0000781a8ffd4f3d  vmovaps xmm6, [rsp+0x60]
0000781a8ffd4f43  vmovaps xmm8, [rsp+0x70]
0000781a8ffd4f49  vmovaps xmm9, [rsp+0x80]
0000781a8ffd4f52  vmovaps xmm10, [rsp+0x90]
0000781a8ffd4f5b  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd4f64  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd4f6d  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd4f76  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd4f7f  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd4f88  add rsp, 0xF0
0000781a8ffd4f8f  pop r11
0000781a8ffd4f91  pop r10
0000781a8ffd4f93  pop r9
0000781a8ffd4f95  pop r8
0000781a8ffd4f97  pop rsi
0000781a8ffd4f98  pop rdi
0000781a8ffd4f99  pop rdx
0000781a8ffd4f9a  pop rcx
0000781a8ffd4f9b  pop rax
0000781a8ffd4f9c  add rsp, 0x08
0000781a8ffd4fa0  jmp 0x0000781A8FFD2F58
0000781a8ffd4fa5  call 0x0000781A8FE0C260
0000781a8ffd4faa  jmp 0x0000781A8FFD2F62
0000781a8ffd4faf  call 0x0000781A8FE09D70
0000781a8ffd4fb4  jmp 0x0000781A8FFD2F6C
0000781a8ffd4fb9  sub rsp, 0x08
0000781a8ffd4fbd  push rax
0000781a8ffd4fbe  push rcx
0000781a8ffd4fbf  push rdx
0000781a8ffd4fc0  push rdi
0000781a8ffd4fc1  push rsi
0000781a8ffd4fc2  push r8
0000781a8ffd4fc4  push r9
0000781a8ffd4fc6  push r10
0000781a8ffd4fc8  push r11
0000781a8ffd4fca  sub rsp, 0xF0
0000781a8ffd4fd1  vmovaps [rsp], xmm0
0000781a8ffd4fd6  vmovaps [rsp+0x10], xmm1
0000781a8ffd4fdc  vmovaps [rsp+0x20], xmm2
0000781a8ffd4fe2  vmovaps [rsp+0x30], xmm3
0000781a8ffd4fe8  vmovaps [rsp+0x40], xmm4
0000781a8ffd4fee  vmovaps [rsp+0x50], xmm5
0000781a8ffd4ff4  vmovaps [rsp+0x60], xmm7
0000781a8ffd4ffa  vmovaps [rsp+0x70], xmm8
0000781a8ffd5000  vmovaps [rsp+0x80], xmm9
0000781a8ffd5009  vmovaps [rsp+0x90], xmm10
0000781a8ffd5012  vmovaps [rsp+0xA0], xmm11
0000781a8ffd501b  vmovaps [rsp+0xB0], xmm12
0000781a8ffd5024  vmovaps [rsp+0xC0], xmm13
0000781a8ffd502d  vmovaps [rsp+0xD0], xmm14
0000781a8ffd5036  vmovaps [rsp+0xE0], xmm15
0000781a8ffd503f  sub rsp, 0x40
0000781a8ffd5043  lea rdi, [rsp]
0000781a8ffd5047  lea rsi, [rsp+0x10]
0000781a8ffd504c  lea rdx, [rsp+0x20]
0000781a8ffd5051  lea rcx, [rsp+0x30]
0000781a8ffd5056  mov r8d, 0x00
0000781a8ffd505c  lea r9, [r15+0x3A8]
0000781a8ffd5063  movaps [rdi], xmm6
0000781a8ffd5066  movaps [rsi], xmm8
0000781a8ffd506a  movaps [rdx], xmm15
0000781a8ffd506e  movaps [rcx], xmm10
0000781a8ffd5072  mov rax, 0x627DDC279A50
0000781a8ffd507c  call rax
0000781a8ffd507e  movaps xmm6, [rsp]
0000781a8ffd5082  add rsp, 0x40
0000781a8ffd5086  vmovaps xmm0, [rsp]
0000781a8ffd508b  vmovaps xmm1, [rsp+0x10]
0000781a8ffd5091  vmovaps xmm2, [rsp+0x20]
0000781a8ffd5097  vmovaps xmm3, [rsp+0x30]
0000781a8ffd509d  vmovaps xmm4, [rsp+0x40]
0000781a8ffd50a3  vmovaps xmm5, [rsp+0x50]
0000781a8ffd50a9  vmovaps xmm7, [rsp+0x60]
0000781a8ffd50af  vmovaps xmm8, [rsp+0x70]
0000781a8ffd50b5  vmovaps xmm9, [rsp+0x80]
0000781a8ffd50be  vmovaps xmm10, [rsp+0x90]
0000781a8ffd50c7  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd50d0  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd50d9  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd50e2  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd50eb  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd50f4  add rsp, 0xF0
0000781a8ffd50fb  pop r11
0000781a8ffd50fd  pop r10
0000781a8ffd50ff  pop r9
0000781a8ffd5101  pop r8
0000781a8ffd5103  pop rsi
0000781a8ffd5104  pop rdi
0000781a8ffd5105  pop rdx
0000781a8ffd5106  pop rcx
0000781a8ffd5107  pop rax
0000781a8ffd5108  add rsp, 0x08
0000781a8ffd510c  jmp 0x0000781A8FFD2FA4
0000781a8ffd5111  sub rsp, 0x08
0000781a8ffd5115  push rax
0000781a8ffd5116  push rcx
0000781a8ffd5117  push rdx
0000781a8ffd5118  push rdi
0000781a8ffd5119  push rsi
0000781a8ffd511a  push r8
0000781a8ffd511c  push r9
0000781a8ffd511e  push r10
0000781a8ffd5120  push r11
0000781a8ffd5122  sub rsp, 0xF0
0000781a8ffd5129  vmovaps [rsp], xmm0
0000781a8ffd512e  vmovaps [rsp+0x10], xmm1
0000781a8ffd5134  vmovaps [rsp+0x20], xmm2
0000781a8ffd513a  vmovaps [rsp+0x30], xmm3
0000781a8ffd5140  vmovaps [rsp+0x40], xmm4
0000781a8ffd5146  vmovaps [rsp+0x50], xmm5
0000781a8ffd514c  vmovaps [rsp+0x60], xmm6
0000781a8ffd5152  vmovaps [rsp+0x70], xmm7
0000781a8ffd5158  vmovaps [rsp+0x80], xmm8
0000781a8ffd5161  vmovaps [rsp+0x90], xmm9
0000781a8ffd516a  vmovaps [rsp+0xA0], xmm11
0000781a8ffd5173  vmovaps [rsp+0xB0], xmm12
0000781a8ffd517c  vmovaps [rsp+0xC0], xmm13
0000781a8ffd5185  vmovaps [rsp+0xD0], xmm14
0000781a8ffd518e  vmovaps [rsp+0xE0], xmm15
0000781a8ffd5197  sub rsp, 0x40
0000781a8ffd519b  lea rdi, [rsp]
0000781a8ffd519f  lea rsi, [rsp+0x10]
0000781a8ffd51a4  lea rdx, [rsp+0x20]
0000781a8ffd51a9  lea rcx, [rsp+0x30]
0000781a8ffd51ae  mov r8d, 0x00
0000781a8ffd51b4  lea r9, [r15+0x3A8]
0000781a8ffd51bb  movaps [rdi], xmm10
0000781a8ffd51bf  movaps [rsi], xmm9
0000781a8ffd51c3  movaps [rdx], xmm13
0000781a8ffd51c7  movaps [rcx], xmm15
0000781a8ffd51cb  mov rax, 0x627DDC279A50
0000781a8ffd51d5  call rax
0000781a8ffd51d7  movaps xmm10, [rsp]
0000781a8ffd51dc  add rsp, 0x40
0000781a8ffd51e0  vmovaps xmm0, [rsp]
0000781a8ffd51e5  vmovaps xmm1, [rsp+0x10]
0000781a8ffd51eb  vmovaps xmm2, [rsp+0x20]
0000781a8ffd51f1  vmovaps xmm3, [rsp+0x30]
0000781a8ffd51f7  vmovaps xmm4, [rsp+0x40]
0000781a8ffd51fd  vmovaps xmm5, [rsp+0x50]
0000781a8ffd5203  vmovaps xmm6, [rsp+0x60]
0000781a8ffd5209  vmovaps xmm7, [rsp+0x70]
0000781a8ffd520f  vmovaps xmm8, [rsp+0x80]
0000781a8ffd5218  vmovaps xmm9, [rsp+0x90]
0000781a8ffd5221  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd522a  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd5233  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd523c  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd5245  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd524e  add rsp, 0xF0
0000781a8ffd5255  pop r11
0000781a8ffd5257  pop r10
0000781a8ffd5259  pop r9
0000781a8ffd525b  pop r8
0000781a8ffd525d  pop rsi
0000781a8ffd525e  pop rdi
0000781a8ffd525f  pop rdx
0000781a8ffd5260  pop rcx
0000781a8ffd5261  pop rax
0000781a8ffd5262  add rsp, 0x08
0000781a8ffd5266  jmp 0x0000781A8FFD2FCD
0000781a8ffd526b  sub rsp, 0x08
0000781a8ffd526f  push rax
0000781a8ffd5270  push rcx
0000781a8ffd5271  push rdx
0000781a8ffd5272  push rdi
0000781a8ffd5273  push rsi
0000781a8ffd5274  push r8
0000781a8ffd5276  push r9
0000781a8ffd5278  push r10
0000781a8ffd527a  push r11
0000781a8ffd527c  sub rsp, 0xF0
0000781a8ffd5283  vmovaps [rsp], xmm0
0000781a8ffd5288  vmovaps [rsp+0x10], xmm1
0000781a8ffd528e  vmovaps [rsp+0x20], xmm2
0000781a8ffd5294  vmovaps [rsp+0x30], xmm3
0000781a8ffd529a  vmovaps [rsp+0x40], xmm4
0000781a8ffd52a0  vmovaps [rsp+0x50], xmm5
0000781a8ffd52a6  vmovaps [rsp+0x60], xmm6
0000781a8ffd52ac  vmovaps [rsp+0x70], xmm7
0000781a8ffd52b2  vmovaps [rsp+0x80], xmm8
0000781a8ffd52bb  vmovaps [rsp+0x90], xmm9
0000781a8ffd52c4  vmovaps [rsp+0xA0], xmm10
0000781a8ffd52cd  vmovaps [rsp+0xB0], xmm11
0000781a8ffd52d6  vmovaps [rsp+0xC0], xmm12
0000781a8ffd52df  vmovaps [rsp+0xD0], xmm14
0000781a8ffd52e8  vmovaps [rsp+0xE0], xmm15
0000781a8ffd52f1  sub rsp, 0x40
0000781a8ffd52f5  lea rdi, [rsp]
0000781a8ffd52f9  lea rsi, [rsp+0x10]
0000781a8ffd52fe  lea rdx, [rsp+0x20]
0000781a8ffd5303  lea rcx, [rsp+0x30]
0000781a8ffd5308  mov r8d, 0x00
0000781a8ffd530e  lea r9, [r15+0x3A8]
0000781a8ffd5315  movaps [rdi], xmm13
0000781a8ffd5319  movaps [rsi], xmm12
0000781a8ffd531d  movaps [rdx], xmm4
0000781a8ffd5320  movaps [rcx], xmm15
0000781a8ffd5324  mov rax, 0x627DDC279A50
0000781a8ffd532e  call rax
0000781a8ffd5330  movaps xmm13, [rsp]
0000781a8ffd5335  add rsp, 0x40
0000781a8ffd5339  vmovaps xmm0, [rsp]
0000781a8ffd533e  vmovaps xmm1, [rsp+0x10]
0000781a8ffd5344  vmovaps xmm2, [rsp+0x20]
0000781a8ffd534a  vmovaps xmm3, [rsp+0x30]
0000781a8ffd5350  vmovaps xmm4, [rsp+0x40]
0000781a8ffd5356  vmovaps xmm5, [rsp+0x50]
0000781a8ffd535c  vmovaps xmm6, [rsp+0x60]
0000781a8ffd5362  vmovaps xmm7, [rsp+0x70]
0000781a8ffd5368  vmovaps xmm8, [rsp+0x80]
0000781a8ffd5371  vmovaps xmm9, [rsp+0x90]
0000781a8ffd537a  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd5383  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd538c  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd5395  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd539e  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd53a7  add rsp, 0xF0
0000781a8ffd53ae  pop r11
0000781a8ffd53b0  pop r10
0000781a8ffd53b2  pop r9
0000781a8ffd53b4  pop r8
0000781a8ffd53b6  pop rsi
0000781a8ffd53b7  pop rdi
0000781a8ffd53b8  pop rdx
0000781a8ffd53b9  pop rcx
0000781a8ffd53ba  pop rax
0000781a8ffd53bb  add rsp, 0x08
0000781a8ffd53bf  jmp 0x0000781A8FFD2FF6
0000781a8ffd53c4  sub rsp, 0x08
0000781a8ffd53c8  push rax
0000781a8ffd53c9  push rcx
0000781a8ffd53ca  push rdx
0000781a8ffd53cb  push rdi
0000781a8ffd53cc  push rsi
0000781a8ffd53cd  push r8
0000781a8ffd53cf  push r9
0000781a8ffd53d1  push r10
0000781a8ffd53d3  push r11
0000781a8ffd53d5  sub rsp, 0xF0
0000781a8ffd53dc  vmovaps [rsp], xmm0
0000781a8ffd53e1  vmovaps [rsp+0x10], xmm1
0000781a8ffd53e7  vmovaps [rsp+0x20], xmm2
0000781a8ffd53ed  vmovaps [rsp+0x30], xmm3
0000781a8ffd53f3  vmovaps [rsp+0x40], xmm4
0000781a8ffd53f9  vmovaps [rsp+0x50], xmm5
0000781a8ffd53ff  vmovaps [rsp+0x60], xmm6
0000781a8ffd5405  vmovaps [rsp+0x70], xmm7
0000781a8ffd540b  vmovaps [rsp+0x80], xmm8
0000781a8ffd5414  vmovaps [rsp+0x90], xmm9
0000781a8ffd541d  vmovaps [rsp+0xA0], xmm10
0000781a8ffd5426  vmovaps [rsp+0xB0], xmm11
0000781a8ffd542f  vmovaps [rsp+0xC0], xmm13
0000781a8ffd5438  vmovaps [rsp+0xD0], xmm14
0000781a8ffd5441  vmovaps [rsp+0xE0], xmm15
0000781a8ffd544a  sub rsp, 0x40
0000781a8ffd544e  lea rdi, [rsp]
0000781a8ffd5452  lea rsi, [rsp+0x10]
0000781a8ffd5457  lea rdx, [rsp+0x20]
0000781a8ffd545c  lea rcx, [rsp+0x30]
0000781a8ffd5461  mov r8d, 0x00
0000781a8ffd5467  lea r9, [r15+0x3A8]
0000781a8ffd546e  movaps [rdi], xmm12
0000781a8ffd5472  movaps [rsi], xmm7
0000781a8ffd5475  movaps [rdx], xmm1
0000781a8ffd5478  movaps [rcx], xmm15
0000781a8ffd547c  mov rax, 0x627DDC279A50
0000781a8ffd5486  call rax
0000781a8ffd5488  movaps xmm12, [rsp]
0000781a8ffd548d  add rsp, 0x40
0000781a8ffd5491  vmovaps xmm0, [rsp]
0000781a8ffd5496  vmovaps xmm1, [rsp+0x10]
0000781a8ffd549c  vmovaps xmm2, [rsp+0x20]
0000781a8ffd54a2  vmovaps xmm3, [rsp+0x30]
0000781a8ffd54a8  vmovaps xmm4, [rsp+0x40]
0000781a8ffd54ae  vmovaps xmm5, [rsp+0x50]
0000781a8ffd54b4  vmovaps xmm6, [rsp+0x60]
0000781a8ffd54ba  vmovaps xmm7, [rsp+0x70]
0000781a8ffd54c0  vmovaps xmm8, [rsp+0x80]
0000781a8ffd54c9  vmovaps xmm9, [rsp+0x90]
0000781a8ffd54d2  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd54db  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd54e4  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd54ed  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd54f6  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd54ff  add rsp, 0xF0
0000781a8ffd5506  pop r11
0000781a8ffd5508  pop r10
0000781a8ffd550a  pop r9
0000781a8ffd550c  pop r8
0000781a8ffd550e  pop rsi
0000781a8ffd550f  pop rdi
0000781a8ffd5510  pop rdx
0000781a8ffd5511  pop rcx
0000781a8ffd5512  pop rax
0000781a8ffd5513  add rsp, 0x08
0000781a8ffd5517  jmp 0x0000781A8FFD301F
0000781a8ffd551c  call 0x0000781A8FDFF430
0000781a8ffd5521  jmp 0x0000781A8FFD3029
0000781a8ffd5526  call 0x0000781A8FE0E760
0000781a8ffd552b  jmp 0x0000781A8FFD3033
0000781a8ffd5530  sub rsp, 0x08
0000781a8ffd5534  push rax
0000781a8ffd5535  push rcx
0000781a8ffd5536  push rdx
0000781a8ffd5537  push rdi
0000781a8ffd5538  push rsi
0000781a8ffd5539  push r8
0000781a8ffd553b  push r9
0000781a8ffd553d  push r10
0000781a8ffd553f  push r11
0000781a8ffd5541  sub rsp, 0xF0
0000781a8ffd5548  vmovaps [rsp], xmm0
0000781a8ffd554d  vmovaps [rsp+0x10], xmm1
0000781a8ffd5553  vmovaps [rsp+0x20], xmm2
0000781a8ffd5559  vmovaps [rsp+0x30], xmm3
0000781a8ffd555f  vmovaps [rsp+0x40], xmm4
0000781a8ffd5565  vmovaps [rsp+0x50], xmm5
0000781a8ffd556b  vmovaps [rsp+0x60], xmm6
0000781a8ffd5571  vmovaps [rsp+0x70], xmm8
0000781a8ffd5577  vmovaps [rsp+0x80], xmm9
0000781a8ffd5580  vmovaps [rsp+0x90], xmm10
0000781a8ffd5589  vmovaps [rsp+0xA0], xmm11
0000781a8ffd5592  vmovaps [rsp+0xB0], xmm12
0000781a8ffd559b  vmovaps [rsp+0xC0], xmm13
0000781a8ffd55a4  vmovaps [rsp+0xD0], xmm14
0000781a8ffd55ad  vmovaps [rsp+0xE0], xmm15
0000781a8ffd55b6  sub rsp, 0x40
0000781a8ffd55ba  lea rdi, [rsp]
0000781a8ffd55be  lea rsi, [rsp+0x10]
0000781a8ffd55c3  lea rdx, [rsp+0x20]
0000781a8ffd55c8  lea rcx, [rsp+0x30]
0000781a8ffd55cd  mov r8d, 0x00
0000781a8ffd55d3  lea r9, [r15+0x3A8]
0000781a8ffd55da  movaps [rdi], xmm7
0000781a8ffd55dd  movaps [rsi], xmm6
0000781a8ffd55e0  movaps [rdx], xmm8
0000781a8ffd55e4  movaps [rcx], xmm9
0000781a8ffd55e8  mov rax, 0x627DDC279A50
0000781a8ffd55f2  call rax
0000781a8ffd55f4  movaps xmm7, [rsp]
0000781a8ffd55f8  add rsp, 0x40
0000781a8ffd55fc  vmovaps xmm0, [rsp]
0000781a8ffd5601  vmovaps xmm1, [rsp+0x10]
0000781a8ffd5607  vmovaps xmm2, [rsp+0x20]
0000781a8ffd560d  vmovaps xmm3, [rsp+0x30]
0000781a8ffd5613  vmovaps xmm4, [rsp+0x40]
0000781a8ffd5619  vmovaps xmm5, [rsp+0x50]
0000781a8ffd561f  vmovaps xmm6, [rsp+0x60]
0000781a8ffd5625  vmovaps xmm8, [rsp+0x70]
0000781a8ffd562b  vmovaps xmm9, [rsp+0x80]
0000781a8ffd5634  vmovaps xmm10, [rsp+0x90]
0000781a8ffd563d  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd5646  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd564f  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd5658  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd5661  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd566a  add rsp, 0xF0
0000781a8ffd5671  pop r11
0000781a8ffd5673  pop r10
0000781a8ffd5675  pop r9
0000781a8ffd5677  pop r8
0000781a8ffd5679  pop rsi
0000781a8ffd567a  pop rdi
0000781a8ffd567b  pop rdx
0000781a8ffd567c  pop rcx
0000781a8ffd567d  pop rax
0000781a8ffd567e  add rsp, 0x08
0000781a8ffd5682  jmp 0x0000781A8FFD305D
0000781a8ffd5687  sub rsp, 0x08
0000781a8ffd568b  push rax
0000781a8ffd568c  push rcx
0000781a8ffd568d  push rdx
0000781a8ffd568e  push rdi
0000781a8ffd568f  push rsi
0000781a8ffd5690  push r8
0000781a8ffd5692  push r9
0000781a8ffd5694  push r10
0000781a8ffd5696  push r11
0000781a8ffd5698  sub rsp, 0xF0
0000781a8ffd569f  vmovaps [rsp], xmm0
0000781a8ffd56a4  vmovaps [rsp+0x10], xmm1
0000781a8ffd56aa  vmovaps [rsp+0x20], xmm2
0000781a8ffd56b0  vmovaps [rsp+0x30], xmm3
0000781a8ffd56b6  vmovaps [rsp+0x40], xmm4
0000781a8ffd56bc  vmovaps [rsp+0x50], xmm5
0000781a8ffd56c2  vmovaps [rsp+0x60], xmm6
0000781a8ffd56c8  vmovaps [rsp+0x70], xmm7
0000781a8ffd56ce  vmovaps [rsp+0x80], xmm9
0000781a8ffd56d7  vmovaps [rsp+0x90], xmm10
0000781a8ffd56e0  vmovaps [rsp+0xA0], xmm11
0000781a8ffd56e9  vmovaps [rsp+0xB0], xmm12
0000781a8ffd56f2  vmovaps [rsp+0xC0], xmm13
0000781a8ffd56fb  vmovaps [rsp+0xD0], xmm14
0000781a8ffd5704  vmovaps [rsp+0xE0], xmm15
0000781a8ffd570d  sub rsp, 0x40
0000781a8ffd5711  lea rdi, [rsp]
0000781a8ffd5715  lea rsi, [rsp+0x10]
0000781a8ffd571a  lea rdx, [rsp+0x20]
0000781a8ffd571f  lea rcx, [rsp+0x30]
0000781a8ffd5724  mov r8d, 0x00
0000781a8ffd572a  lea r9, [r15+0x3A8]
0000781a8ffd5731  movaps [rdi], xmm8
0000781a8ffd5735  movaps [rsi], xmm10
0000781a8ffd5739  movaps [rdx], xmm14
0000781a8ffd573d  movaps [rcx], xmm9
0000781a8ffd5741  mov rax, 0x627DDC279A50
0000781a8ffd574b  call rax
0000781a8ffd574d  movaps xmm8, [rsp]
0000781a8ffd5752  add rsp, 0x40
0000781a8ffd5756  vmovaps xmm0, [rsp]
0000781a8ffd575b  vmovaps xmm1, [rsp+0x10]
0000781a8ffd5761  vmovaps xmm2, [rsp+0x20]
0000781a8ffd5767  vmovaps xmm3, [rsp+0x30]
0000781a8ffd576d  vmovaps xmm4, [rsp+0x40]
0000781a8ffd5773  vmovaps xmm5, [rsp+0x50]
0000781a8ffd5779  vmovaps xmm6, [rsp+0x60]
0000781a8ffd577f  vmovaps xmm7, [rsp+0x70]
0000781a8ffd5785  vmovaps xmm9, [rsp+0x80]
0000781a8ffd578e  vmovaps xmm10, [rsp+0x90]
0000781a8ffd5797  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd57a0  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd57a9  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd57b2  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd57bb  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd57c4  add rsp, 0xF0
0000781a8ffd57cb  pop r11
0000781a8ffd57cd  pop r10
0000781a8ffd57cf  pop r9
0000781a8ffd57d1  pop r8
0000781a8ffd57d3  pop rsi
0000781a8ffd57d4  pop rdi
0000781a8ffd57d5  pop rdx
0000781a8ffd57d6  pop rcx
0000781a8ffd57d7  pop rax
0000781a8ffd57d8  add rsp, 0x08
0000781a8ffd57dc  jmp 0x0000781A8FFD3083
0000781a8ffd57e1  sub rsp, 0x08
0000781a8ffd57e5  push rax
0000781a8ffd57e6  push rcx
0000781a8ffd57e7  push rdx
0000781a8ffd57e8  push rdi
0000781a8ffd57e9  push rsi
0000781a8ffd57ea  push r8
0000781a8ffd57ec  push r9
0000781a8ffd57ee  push r10
0000781a8ffd57f0  push r11
0000781a8ffd57f2  sub rsp, 0xF0
0000781a8ffd57f9  vmovaps [rsp], xmm0
0000781a8ffd57fe  vmovaps [rsp+0x10], xmm1
0000781a8ffd5804  vmovaps [rsp+0x20], xmm2
0000781a8ffd580a  vmovaps [rsp+0x30], xmm3
0000781a8ffd5810  vmovaps [rsp+0x40], xmm4
0000781a8ffd5816  vmovaps [rsp+0x50], xmm5
0000781a8ffd581c  vmovaps [rsp+0x60], xmm6
0000781a8ffd5822  vmovaps [rsp+0x70], xmm7
0000781a8ffd5828  vmovaps [rsp+0x80], xmm8
0000781a8ffd5831  vmovaps [rsp+0x90], xmm9
0000781a8ffd583a  vmovaps [rsp+0xA0], xmm11
0000781a8ffd5843  vmovaps [rsp+0xB0], xmm12
0000781a8ffd584c  vmovaps [rsp+0xC0], xmm13
0000781a8ffd5855  vmovaps [rsp+0xD0], xmm14
0000781a8ffd585e  vmovaps [rsp+0xE0], xmm15
0000781a8ffd5867  sub rsp, 0x40
0000781a8ffd586b  lea rdi, [rsp]
0000781a8ffd586f  lea rsi, [rsp+0x10]
0000781a8ffd5874  lea rdx, [rsp+0x20]
0000781a8ffd5879  lea rcx, [rsp+0x30]
0000781a8ffd587e  mov r8d, 0x00
0000781a8ffd5884  lea r9, [r15+0x3A8]
0000781a8ffd588b  movaps [rdi], xmm10
0000781a8ffd588f  movaps [rsi], xmm13
0000781a8ffd5893  movaps [rdx], xmm11
0000781a8ffd5897  movaps [rcx], xmm14
0000781a8ffd589b  mov rax, 0x627DDC279A50
0000781a8ffd58a5  call rax
0000781a8ffd58a7  movaps xmm10, [rsp]
0000781a8ffd58ac  add rsp, 0x40
0000781a8ffd58b0  vmovaps xmm0, [rsp]
0000781a8ffd58b5  vmovaps xmm1, [rsp+0x10]
0000781a8ffd58bb  vmovaps xmm2, [rsp+0x20]
0000781a8ffd58c1  vmovaps xmm3, [rsp+0x30]
0000781a8ffd58c7  vmovaps xmm4, [rsp+0x40]
0000781a8ffd58cd  vmovaps xmm5, [rsp+0x50]
0000781a8ffd58d3  vmovaps xmm6, [rsp+0x60]
0000781a8ffd58d9  vmovaps xmm7, [rsp+0x70]
0000781a8ffd58df  vmovaps xmm8, [rsp+0x80]
0000781a8ffd58e8  vmovaps xmm9, [rsp+0x90]
0000781a8ffd58f1  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd58fa  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd5903  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd590c  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd5915  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd591e  add rsp, 0xF0
0000781a8ffd5925  pop r11
0000781a8ffd5927  pop r10
0000781a8ffd5929  pop r9
0000781a8ffd592b  pop r8
0000781a8ffd592d  pop rsi
0000781a8ffd592e  pop rdi
0000781a8ffd592f  pop rdx
0000781a8ffd5930  pop rcx
0000781a8ffd5931  pop rax
0000781a8ffd5932  add rsp, 0x08
0000781a8ffd5936  jmp 0x0000781A8FFD30A9
0000781a8ffd593b  sub rsp, 0x08
0000781a8ffd593f  push rax
0000781a8ffd5940  push rcx
0000781a8ffd5941  push rdx
0000781a8ffd5942  push rdi
0000781a8ffd5943  push rsi
0000781a8ffd5944  push r8
0000781a8ffd5946  push r9
0000781a8ffd5948  push r10
0000781a8ffd594a  push r11
0000781a8ffd594c  sub rsp, 0xF0
0000781a8ffd5953  vmovaps [rsp], xmm0
0000781a8ffd5958  vmovaps [rsp+0x10], xmm1
0000781a8ffd595e  vmovaps [rsp+0x20], xmm2
0000781a8ffd5964  vmovaps [rsp+0x30], xmm3
0000781a8ffd596a  vmovaps [rsp+0x40], xmm4
0000781a8ffd5970  vmovaps [rsp+0x50], xmm5
0000781a8ffd5976  vmovaps [rsp+0x60], xmm6
0000781a8ffd597c  vmovaps [rsp+0x70], xmm7
0000781a8ffd5982  vmovaps [rsp+0x80], xmm8
0000781a8ffd598b  vmovaps [rsp+0x90], xmm9
0000781a8ffd5994  vmovaps [rsp+0xA0], xmm10
0000781a8ffd599d  vmovaps [rsp+0xB0], xmm11
0000781a8ffd59a6  vmovaps [rsp+0xC0], xmm12
0000781a8ffd59af  vmovaps [rsp+0xD0], xmm14
0000781a8ffd59b8  vmovaps [rsp+0xE0], xmm15
0000781a8ffd59c1  sub rsp, 0x40
0000781a8ffd59c5  lea rdi, [rsp]
0000781a8ffd59c9  lea rsi, [rsp+0x10]
0000781a8ffd59ce  lea rdx, [rsp+0x20]
0000781a8ffd59d3  lea rcx, [rsp+0x30]
0000781a8ffd59d8  mov r8d, 0x00
0000781a8ffd59de  lea r9, [r15+0x3A8]
0000781a8ffd59e5  movaps [rdi], xmm13
0000781a8ffd59e9  movaps [rsi], xmm12
0000781a8ffd59ed  movaps [rdx], xmm15
0000781a8ffd59f1  movaps [rcx], xmm14
0000781a8ffd59f5  mov rax, 0x627DDC279A50
0000781a8ffd59ff  call rax
0000781a8ffd5a01  movaps xmm13, [rsp]
0000781a8ffd5a06  add rsp, 0x40
0000781a8ffd5a0a  vmovaps xmm0, [rsp]
0000781a8ffd5a0f  vmovaps xmm1, [rsp+0x10]
0000781a8ffd5a15  vmovaps xmm2, [rsp+0x20]
0000781a8ffd5a1b  vmovaps xmm3, [rsp+0x30]
0000781a8ffd5a21  vmovaps xmm4, [rsp+0x40]
0000781a8ffd5a27  vmovaps xmm5, [rsp+0x50]
0000781a8ffd5a2d  vmovaps xmm6, [rsp+0x60]
0000781a8ffd5a33  vmovaps xmm7, [rsp+0x70]
0000781a8ffd5a39  vmovaps xmm8, [rsp+0x80]
0000781a8ffd5a42  vmovaps xmm9, [rsp+0x90]
0000781a8ffd5a4b  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd5a54  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd5a5d  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd5a66  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd5a6f  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd5a78  add rsp, 0xF0
0000781a8ffd5a7f  pop r11
0000781a8ffd5a81  pop r10
0000781a8ffd5a83  pop r9
0000781a8ffd5a85  pop r8
0000781a8ffd5a87  pop rsi
0000781a8ffd5a88  pop rdi
0000781a8ffd5a89  pop rdx
0000781a8ffd5a8a  pop rcx
0000781a8ffd5a8b  pop rax
0000781a8ffd5a8c  add rsp, 0x08
0000781a8ffd5a90  jmp 0x0000781A8FFD30CF
0000781a8ffd5a95  call 0x0000781A8FE0E760
0000781a8ffd5a9a  jmp 0x0000781A8FFD30DC
0000781a8ffd5a9f  call 0x0000781A8FE0D4E0
0000781a8ffd5aa4  jmp 0x0000781A8FFD30E9
0000781a8ffd5aa9  sub rsp, 0x08
0000781a8ffd5aad  push rax
0000781a8ffd5aae  push rcx
0000781a8ffd5aaf  push rdx
0000781a8ffd5ab0  push rdi
0000781a8ffd5ab1  push rsi
0000781a8ffd5ab2  push r8
0000781a8ffd5ab4  push r9
0000781a8ffd5ab6  push r10
0000781a8ffd5ab8  push r11
0000781a8ffd5aba  sub rsp, 0xF0
0000781a8ffd5ac1  vmovaps [rsp], xmm0
0000781a8ffd5ac6  vmovaps [rsp+0x10], xmm1
0000781a8ffd5acc  vmovaps [rsp+0x20], xmm2
0000781a8ffd5ad2  vmovaps [rsp+0x30], xmm3
0000781a8ffd5ad8  vmovaps [rsp+0x40], xmm4
0000781a8ffd5ade  vmovaps [rsp+0x50], xmm5
0000781a8ffd5ae4  vmovaps [rsp+0x60], xmm6
0000781a8ffd5aea  vmovaps [rsp+0x70], xmm7
0000781a8ffd5af0  vmovaps [rsp+0x80], xmm8
0000781a8ffd5af9  vmovaps [rsp+0x90], xmm9
0000781a8ffd5b02  vmovaps [rsp+0xA0], xmm10
0000781a8ffd5b0b  vmovaps [rsp+0xB0], xmm12
0000781a8ffd5b14  vmovaps [rsp+0xC0], xmm13
0000781a8ffd5b1d  vmovaps [rsp+0xD0], xmm14
0000781a8ffd5b26  vmovaps [rsp+0xE0], xmm15
0000781a8ffd5b2f  sub rsp, 0x40
0000781a8ffd5b33  lea rdi, [rsp]
0000781a8ffd5b37  lea rsi, [rsp+0x10]
0000781a8ffd5b3c  lea rdx, [rsp+0x20]
0000781a8ffd5b41  lea rcx, [rsp+0x30]
0000781a8ffd5b46  mov r8d, 0x00
0000781a8ffd5b4c  lea r9, [r15+0x3A8]
0000781a8ffd5b53  movaps [rdi], xmm11
0000781a8ffd5b57  movaps [rsi], xmm7
0000781a8ffd5b5a  movaps [rdx], xmm1
0000781a8ffd5b5d  movaps [rcx], xmm12
0000781a8ffd5b61  mov rax, 0x627DDC279A50
0000781a8ffd5b6b  call rax
0000781a8ffd5b6d  movaps xmm11, [rsp]
0000781a8ffd5b72  add rsp, 0x40
0000781a8ffd5b76  vmovaps xmm0, [rsp]
0000781a8ffd5b7b  vmovaps xmm1, [rsp+0x10]
0000781a8ffd5b81  vmovaps xmm2, [rsp+0x20]
0000781a8ffd5b87  vmovaps xmm3, [rsp+0x30]
0000781a8ffd5b8d  vmovaps xmm4, [rsp+0x40]
0000781a8ffd5b93  vmovaps xmm5, [rsp+0x50]
0000781a8ffd5b99  vmovaps xmm6, [rsp+0x60]
0000781a8ffd5b9f  vmovaps xmm7, [rsp+0x70]
0000781a8ffd5ba5  vmovaps xmm8, [rsp+0x80]
0000781a8ffd5bae  vmovaps xmm9, [rsp+0x90]
0000781a8ffd5bb7  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd5bc0  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd5bc9  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd5bd2  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd5bdb  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd5be4  add rsp, 0xF0
0000781a8ffd5beb  pop r11
0000781a8ffd5bed  pop r10
0000781a8ffd5bef  pop r9
0000781a8ffd5bf1  pop r8
0000781a8ffd5bf3  pop rsi
0000781a8ffd5bf4  pop rdi
0000781a8ffd5bf5  pop rdx
0000781a8ffd5bf6  pop rcx
0000781a8ffd5bf7  pop rax
0000781a8ffd5bf8  add rsp, 0x08
0000781a8ffd5bfc  jmp 0x0000781A8FFD3122
0000781a8ffd5c01  call 0x0000781A8FDFF430
0000781a8ffd5c06  jmp 0x0000781A8FFD3134
0000781a8ffd5c0b  sub rsp, 0x08
0000781a8ffd5c0f  push rax
0000781a8ffd5c10  push rcx
0000781a8ffd5c11  push rdx
0000781a8ffd5c12  push rdi
0000781a8ffd5c13  push rsi
0000781a8ffd5c14  push r8
0000781a8ffd5c16  push r9
0000781a8ffd5c18  push r10
0000781a8ffd5c1a  push r11
0000781a8ffd5c1c  sub rsp, 0xF0
0000781a8ffd5c23  vmovaps [rsp], xmm0
0000781a8ffd5c28  vmovaps [rsp+0x10], xmm1
0000781a8ffd5c2e  vmovaps [rsp+0x20], xmm2
0000781a8ffd5c34  vmovaps [rsp+0x30], xmm3
0000781a8ffd5c3a  vmovaps [rsp+0x40], xmm4
0000781a8ffd5c40  vmovaps [rsp+0x50], xmm5
0000781a8ffd5c46  vmovaps [rsp+0x60], xmm6
0000781a8ffd5c4c  vmovaps [rsp+0x70], xmm7
0000781a8ffd5c52  vmovaps [rsp+0x80], xmm8
0000781a8ffd5c5b  vmovaps [rsp+0x90], xmm10
0000781a8ffd5c64  vmovaps [rsp+0xA0], xmm11
0000781a8ffd5c6d  vmovaps [rsp+0xB0], xmm12
0000781a8ffd5c76  vmovaps [rsp+0xC0], xmm13
0000781a8ffd5c7f  vmovaps [rsp+0xD0], xmm14
0000781a8ffd5c88  vmovaps [rsp+0xE0], xmm15
0000781a8ffd5c91  sub rsp, 0x40
0000781a8ffd5c95  lea rdi, [rsp]
0000781a8ffd5c99  lea rsi, [rsp+0x10]
0000781a8ffd5c9e  lea rdx, [rsp+0x20]
0000781a8ffd5ca3  lea rcx, [rsp+0x30]
0000781a8ffd5ca8  mov r8d, 0x00
0000781a8ffd5cae  lea r9, [r15+0x3A8]
0000781a8ffd5cb5  movaps [rdi], xmm9
0000781a8ffd5cb9  movaps [rsi], xmm8
0000781a8ffd5cbd  movaps [rdx], xmm14
0000781a8ffd5cc1  movaps [rcx], xmm12
0000781a8ffd5cc5  mov rax, 0x627DDC279A50
0000781a8ffd5ccf  call rax
0000781a8ffd5cd1  movaps xmm9, [rsp]
0000781a8ffd5cd6  add rsp, 0x40
0000781a8ffd5cda  vmovaps xmm0, [rsp]
0000781a8ffd5cdf  vmovaps xmm1, [rsp+0x10]
0000781a8ffd5ce5  vmovaps xmm2, [rsp+0x20]
0000781a8ffd5ceb  vmovaps xmm3, [rsp+0x30]
0000781a8ffd5cf1  vmovaps xmm4, [rsp+0x40]
0000781a8ffd5cf7  vmovaps xmm5, [rsp+0x50]
0000781a8ffd5cfd  vmovaps xmm6, [rsp+0x60]
0000781a8ffd5d03  vmovaps xmm7, [rsp+0x70]
0000781a8ffd5d09  vmovaps xmm8, [rsp+0x80]
0000781a8ffd5d12  vmovaps xmm10, [rsp+0x90]
0000781a8ffd5d1b  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd5d24  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd5d2d  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd5d36  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd5d3f  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd5d48  add rsp, 0xF0
0000781a8ffd5d4f  pop r11
0000781a8ffd5d51  pop r10
0000781a8ffd5d53  pop r9
0000781a8ffd5d55  pop r8
0000781a8ffd5d57  pop rsi
0000781a8ffd5d58  pop rdi
0000781a8ffd5d59  pop rdx
0000781a8ffd5d5a  pop rcx
0000781a8ffd5d5b  pop rax
0000781a8ffd5d5c  add rsp, 0x08
0000781a8ffd5d60  jmp 0x0000781A8FFD3165
0000781a8ffd5d65  sub rsp, 0x08
0000781a8ffd5d69  push rax
0000781a8ffd5d6a  push rcx
0000781a8ffd5d6b  push rdx
0000781a8ffd5d6c  push rdi
0000781a8ffd5d6d  push rsi
0000781a8ffd5d6e  push r8
0000781a8ffd5d70  push r9
0000781a8ffd5d72  push r10
0000781a8ffd5d74  push r11
0000781a8ffd5d76  sub rsp, 0xF0
0000781a8ffd5d7d  vmovaps [rsp], xmm0
0000781a8ffd5d82  vmovaps [rsp+0x10], xmm1
0000781a8ffd5d88  vmovaps [rsp+0x20], xmm2
0000781a8ffd5d8e  vmovaps [rsp+0x30], xmm3
0000781a8ffd5d94  vmovaps [rsp+0x40], xmm4
0000781a8ffd5d9a  vmovaps [rsp+0x50], xmm5
0000781a8ffd5da0  vmovaps [rsp+0x60], xmm6
0000781a8ffd5da6  vmovaps [rsp+0x70], xmm7
0000781a8ffd5dac  vmovaps [rsp+0x80], xmm8
0000781a8ffd5db5  vmovaps [rsp+0x90], xmm9
0000781a8ffd5dbe  vmovaps [rsp+0xA0], xmm10
0000781a8ffd5dc7  vmovaps [rsp+0xB0], xmm11
0000781a8ffd5dd0  vmovaps [rsp+0xC0], xmm13
0000781a8ffd5dd9  vmovaps [rsp+0xD0], xmm14
0000781a8ffd5de2  vmovaps [rsp+0xE0], xmm15
0000781a8ffd5deb  sub rsp, 0x40
0000781a8ffd5def  lea rdi, [rsp]
0000781a8ffd5df3  lea rsi, [rsp+0x10]
0000781a8ffd5df8  lea rdx, [rsp+0x20]
0000781a8ffd5dfd  lea rcx, [rsp+0x30]
0000781a8ffd5e02  mov r8d, 0x00
0000781a8ffd5e08  lea r9, [r15+0x3A8]
0000781a8ffd5e0f  movaps [rdi], xmm12
0000781a8ffd5e13  movaps [rsi], xmm10
0000781a8ffd5e17  movaps [rdx], xmm15
0000781a8ffd5e1b  movaps [rcx], xmm14
0000781a8ffd5e1f  mov rax, 0x627DDC279A50
0000781a8ffd5e29  call rax
0000781a8ffd5e2b  movaps xmm12, [rsp]
0000781a8ffd5e30  add rsp, 0x40
0000781a8ffd5e34  vmovaps xmm0, [rsp]
0000781a8ffd5e39  vmovaps xmm1, [rsp+0x10]
0000781a8ffd5e3f  vmovaps xmm2, [rsp+0x20]
0000781a8ffd5e45  vmovaps xmm3, [rsp+0x30]
0000781a8ffd5e4b  vmovaps xmm4, [rsp+0x40]
0000781a8ffd5e51  vmovaps xmm5, [rsp+0x50]
0000781a8ffd5e57  vmovaps xmm6, [rsp+0x60]
0000781a8ffd5e5d  vmovaps xmm7, [rsp+0x70]
0000781a8ffd5e63  vmovaps xmm8, [rsp+0x80]
0000781a8ffd5e6c  vmovaps xmm9, [rsp+0x90]
0000781a8ffd5e75  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd5e7e  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd5e87  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd5e90  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd5e99  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd5ea2  add rsp, 0xF0
0000781a8ffd5ea9  pop r11
0000781a8ffd5eab  pop r10
0000781a8ffd5ead  pop r9
0000781a8ffd5eaf  pop r8
0000781a8ffd5eb1  pop rsi
0000781a8ffd5eb2  pop rdi
0000781a8ffd5eb3  pop rdx
0000781a8ffd5eb4  pop rcx
0000781a8ffd5eb5  pop rax
0000781a8ffd5eb6  add rsp, 0x08
0000781a8ffd5eba  jmp 0x0000781A8FFD3196
0000781a8ffd5ebf  sub rsp, 0x08
0000781a8ffd5ec3  push rax
0000781a8ffd5ec4  push rcx
0000781a8ffd5ec5  push rdx
0000781a8ffd5ec6  push rdi
0000781a8ffd5ec7  push rsi
0000781a8ffd5ec8  push r8
0000781a8ffd5eca  push r9
0000781a8ffd5ecc  push r10
0000781a8ffd5ece  push r11
0000781a8ffd5ed0  sub rsp, 0xF0
0000781a8ffd5ed7  vmovaps [rsp], xmm0
0000781a8ffd5edc  vmovaps [rsp+0x10], xmm1
0000781a8ffd5ee2  vmovaps [rsp+0x20], xmm2
0000781a8ffd5ee8  vmovaps [rsp+0x30], xmm3
0000781a8ffd5eee  vmovaps [rsp+0x40], xmm4
0000781a8ffd5ef4  vmovaps [rsp+0x50], xmm5
0000781a8ffd5efa  vmovaps [rsp+0x60], xmm6
0000781a8ffd5f00  vmovaps [rsp+0x70], xmm7
0000781a8ffd5f06  vmovaps [rsp+0x80], xmm8
0000781a8ffd5f0f  vmovaps [rsp+0x90], xmm9
0000781a8ffd5f18  vmovaps [rsp+0xA0], xmm10
0000781a8ffd5f21  vmovaps [rsp+0xB0], xmm11
0000781a8ffd5f2a  vmovaps [rsp+0xC0], xmm12
0000781a8ffd5f33  vmovaps [rsp+0xD0], xmm13
0000781a8ffd5f3c  vmovaps [rsp+0xE0], xmm15
0000781a8ffd5f45  sub rsp, 0x40
0000781a8ffd5f49  lea rdi, [rsp]
0000781a8ffd5f4d  lea rsi, [rsp+0x10]
0000781a8ffd5f52  lea rdx, [rsp+0x20]
0000781a8ffd5f57  lea rcx, [rsp+0x30]
0000781a8ffd5f5c  mov r8d, 0x00
0000781a8ffd5f62  lea r9, [r15+0x3A8]
0000781a8ffd5f69  movaps [rdi], xmm14
0000781a8ffd5f6d  movaps [rsi], xmm13
0000781a8ffd5f71  movaps [rdx], xmm1
0000781a8ffd5f74  movaps [rcx], xmm15
0000781a8ffd5f78  mov rax, 0x627DDC279A50
0000781a8ffd5f82  call rax
0000781a8ffd5f84  movaps xmm14, [rsp]
0000781a8ffd5f89  add rsp, 0x40
0000781a8ffd5f8d  vmovaps xmm0, [rsp]
0000781a8ffd5f92  vmovaps xmm1, [rsp+0x10]
0000781a8ffd5f98  vmovaps xmm2, [rsp+0x20]
0000781a8ffd5f9e  vmovaps xmm3, [rsp+0x30]
0000781a8ffd5fa4  vmovaps xmm4, [rsp+0x40]
0000781a8ffd5faa  vmovaps xmm5, [rsp+0x50]
0000781a8ffd5fb0  vmovaps xmm6, [rsp+0x60]
0000781a8ffd5fb6  vmovaps xmm7, [rsp+0x70]
0000781a8ffd5fbc  vmovaps xmm8, [rsp+0x80]
0000781a8ffd5fc5  vmovaps xmm9, [rsp+0x90]
0000781a8ffd5fce  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd5fd7  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd5fe0  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd5fe9  vmovaps xmm13, [rsp+0xD0]
0000781a8ffd5ff2  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd5ffb  add rsp, 0xF0
0000781a8ffd6002  pop r11
0000781a8ffd6004  pop r10
0000781a8ffd6006  pop r9
0000781a8ffd6008  pop r8
0000781a8ffd600a  pop rsi
0000781a8ffd600b  pop rdi
0000781a8ffd600c  pop rdx
0000781a8ffd600d  pop rcx
0000781a8ffd600e  pop rax
0000781a8ffd600f  add rsp, 0x08
0000781a8ffd6013  jmp 0x0000781A8FFD31C7
0000781a8ffd6018  call 0x0000781A8FE079B0
0000781a8ffd601d  jmp 0x0000781A8FFD31DA
0000781a8ffd6022  call 0x0000781A8FE0B100
0000781a8ffd6027  jmp 0x0000781A8FFD31E5
0000781a8ffd602c  call 0x0000781A8FE09E90
0000781a8ffd6031  jmp 0x0000781A8FFD31F0
0000781a8ffd6036  call 0x0000781A8FE0D600
0000781a8ffd603b  jmp 0x0000781A8FFD31FB
0000781a8ffd6040  int3
0000781a8ffd6041  nop [rax+rax*1], ax
0000781a8ffd604a  nop [rax+rax*1], ax
0000781a8ffd6050  mov rax, [r15+0x40]
0000781a8ffd6054  mov r14, [r15+0x58]
0000781a8ffd6058  lea r12, [rax+r14*1]
0000781a8ffd605c  vxorps xmm1, xmm1, xmm1
0000781a8ffd6060  vpbroadcastq xmm1, xmm1
0000781a8ffd6065  vxorps xmm15, xmm15, xmm15
0000781a8ffd606a  vpbroadcastq xmm15, xmm15
0000781a8ffd606f  lea rax, [r12+0x30]
0000781a8ffd6074  mov r11, [r13+rax*1]
0000781a8ffd6079  lea rax, [r12+0x38]
0000781a8ffd607e  mov r10, [r13+rax*1]
0000781a8ffd6083  movq xmm14, r11
0000781a8ffd6088  movq xmm13, r10
0000781a8ffd608d  movq xmm14, xmm14
0000781a8ffd6092  movq xmm13, xmm13
0000781a8ffd6097  vmovaps [rsp+0x10], xmm13
0000781a8ffd609d  movq xmm13, xmm13
0000781a8ffd60a2  movaps [r15+0x270], xmm13
0000781a8ffd60aa  movaps xmm13, [r15+0x160]
0000781a8ffd60b2  vmovaps [rsp+0x20], xmm13
0000781a8ffd60b8  vmovaps xmm12, [rsp+0x20]
0000781a8ffd60be  por xmm13, xmm12
0000781a8ffd60c3  lea rax, [r12+0x20]
0000781a8ffd60c8  mov r11, [r13+rax*1]
0000781a8ffd60cd  lea rax, [r12+0x28]
0000781a8ffd60d2  mov r10, [r13+rax*1]
0000781a8ffd60d7  movq xmm12, r11
0000781a8ffd60dc  movq xmm11, r10
0000781a8ffd60e1  movq xmm12, xmm12
0000781a8ffd60e6  movq xmm11, xmm11
0000781a8ffd60eb  movaps xmm10, [r15+0x2D0]
0000781a8ffd60f3  vmovaps [rsp+0x20], xmm10
0000781a8ffd60f9  vmovaps xmm9, [rsp+0x20]
0000781a8ffd60ff  por xmm10, xmm9
0000781a8ffd6104  movaps xmm9, [r15+0x300]
0000781a8ffd610c  vmovaps [rsp+0x20], xmm9
0000781a8ffd6112  vmovaps xmm8, [rsp+0x20]
0000781a8ffd6118  por xmm9, xmm8
0000781a8ffd611d  movaps xmm8, [r15+0x2B0]
0000781a8ffd6125  vmovaps [rsp+0x20], xmm8
0000781a8ffd612b  vmovaps xmm7, [rsp+0x20]
0000781a8ffd6131  por xmm8, xmm7
0000781a8ffd6136  movaps xmm7, [r15+0x180]
0000781a8ffd613e  vmovaps [rsp+0x20], xmm7
0000781a8ffd6144  vmovaps xmm6, [rsp+0x20]
0000781a8ffd614a  por xmm7, xmm6
0000781a8ffd614e  lea rax, [r12+0x10]
0000781a8ffd6153  mov r11, [r13+rax*1]
0000781a8ffd6158  lea rax, [r12+0x18]
0000781a8ffd615d  mov r10, [r13+rax*1]
0000781a8ffd6162  movq xmm6, r11
0000781a8ffd6167  movq xmm5, r10
0000781a8ffd616c  movq xmm6, xmm6
0000781a8ffd6170  movq xmm5, xmm5
0000781a8ffd6174  movaps xmm4, [r15+0x200]
0000781a8ffd617c  vmovaps [rsp+0x20], xmm4
0000781a8ffd6182  vmovaps xmm3, [rsp+0x20]
0000781a8ffd6188  por xmm4, xmm3
0000781a8ffd618c  movaps xmm3, [r15+0x1F0]
0000781a8ffd6194  vmovaps [rsp+0x20], xmm3
0000781a8ffd619a  vmovaps xmm2, [rsp+0x20]
0000781a8ffd61a0  por xmm3, xmm2
0000781a8ffd61a4  movaps xmm2, [r15+0x2E0]
0000781a8ffd61ac  vmovaps [rsp+0x20], xmm2
0000781a8ffd61b2  vmovaps [rsp+0x30], xmm1
0000781a8ffd61b8  vmovaps xmm1, [rsp+0x20]
0000781a8ffd61be  por xmm2, xmm1
0000781a8ffd61c2  movaps xmm1, [r15+0x2A0]
0000781a8ffd61ca  vmovaps [rsp+0x20], xmm1
0000781a8ffd61d0  vmovaps [rsp+0x40], xmm15
0000781a8ffd61d6  vmovaps xmm15, [rsp+0x20]
0000781a8ffd61dc  por xmm1, xmm15
0000781a8ffd61e1  movaps xmm15, [r15+0x280]
0000781a8ffd61e9  vmovaps [rsp+0x20], xmm15
0000781a8ffd61ef  vmovaps [rsp+0x50], xmm1
0000781a8ffd61f5  vmovaps xmm1, [rsp+0x20]
0000781a8ffd61fb  por xmm15, xmm1
0000781a8ffd6200  movaps xmm1, [r15+0x1C0]
0000781a8ffd6208  vmovaps [rsp+0x20], xmm1
0000781a8ffd620e  vmovaps [rsp+0x60], xmm15
0000781a8ffd6214  vmovaps xmm15, [rsp+0x20]
0000781a8ffd621a  por xmm1, xmm15
0000781a8ffd621f  movaps xmm15, [r15+0x210]
0000781a8ffd6227  vmovaps [rsp+0x20], xmm15
0000781a8ffd622d  vmovaps [rsp+0x70], xmm1
0000781a8ffd6233  vmovaps xmm1, [rsp+0x20]
0000781a8ffd6239  por xmm15, xmm1
0000781a8ffd623e  mov rax, [r13+r12*1]
0000781a8ffd6243  vmovq xmm1, rax
0000781a8ffd6248  vpbroadcastq xmm1, xmm1
0000781a8ffd624d  vmovaps [rsp+0x20], xmm1
0000781a8ffd6253  vxorps xmm1, xmm1, xmm1
0000781a8ffd6257  vpbroadcastq xmm1, xmm1
0000781a8ffd625c  mov rax, [r15+0xF8]
0000781a8ffd6263  vmovaps [rsp+0x80], xmm1
0000781a8ffd626c  movups xmm1, [r13+rax*1]
0000781a8ffd6272  vmovaps [rsp+0x90], xmm1
0000781a8ffd627b  vxorps xmm1, xmm1, xmm1
0000781a8ffd627f  vpbroadcastq xmm1, xmm1
0000781a8ffd6284  lea r11, [r12+0x08]
0000781a8ffd6289  mov r12, [r13+r11*1]
0000781a8ffd628e  vmovaps [rsp+0xA0], xmm1
0000781a8ffd6297  movq xmm1, r12
0000781a8ffd629c  movaps [r15+0x240], xmm1
0000781a8ffd62a4  mov r12, [r15+0x50]
0000781a8ffd62a8  lea r11, [r12+r14*1]
0000781a8ffd62ac  mov [r15+0x60], r11
0000781a8ffd62b0  lea r12, [r14+0x40]
0000781a8ffd62b4  mov [r15+0x58], r12
0000781a8ffd62b8  vmovaps xmm1, [rsp+0x30]
0000781a8ffd62be  vmovaps [rsp+0x30], xmm15
0000781a8ffd62c4  vmovaps xmm15, [rsp+0x90]
0000781a8ffd62cd  vmovaps [rsp+0x90], xmm14
0000781a8ffd62d6  vmovaps xmm14, [rsp+0x20]
0000781a8ffd62dc  vmovaps [rsp+0x20], xmm13
0000781a8ffd62e2  vmovaps [rsp+0xB0], xmm12
0000781a8ffd62eb  movaps xmm13, xmm1
0000781a8ffd62ef  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd62fa  vptest xmm12, xmm12
0000781a8ffd62ff  jnz 0x0000781A8FFD6D9C
0000781a8ffd6305  movaps xmm1, [r15+0x250]
0000781a8ffd630d  vmovaps xmm15, [rsp+0x40]
0000781a8ffd6313  vmovaps [rsp+0x40], xmm13
0000781a8ffd6319  movaps xmm12, xmm15
0000781a8ffd631d  vfmadd231pd xmm12, xmm1, xmm14
0000781a8ffd6322  vcmppd xmm13, xmm12, xmm12, 0x03
0000781a8ffd6328  vptest xmm13, xmm13
0000781a8ffd632d  jnz 0x0000781A8FFD6EF5
0000781a8ffd6333  movaps xmm15, [r15+0x1E0]
0000781a8ffd633b  vmovaps [rsp+0xC0], xmm15
0000781a8ffd6344  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd634d  por xmm15, xmm13
0000781a8ffd6352  movaps xmm13, [r15+0x1D0]
0000781a8ffd635a  vmovaps [rsp+0xC0], xmm13
0000781a8ffd6363  vmovaps [rsp+0xD0], xmm1
0000781a8ffd636c  vmovaps xmm1, [rsp+0xC0]
0000781a8ffd6375  por xmm13, xmm1
0000781a8ffd637a  movaps xmm1, [r15+0x2C0]
0000781a8ffd6382  vmovaps [rsp+0xC0], xmm1
0000781a8ffd638b  vmovaps [rsp+0xE0], xmm15
0000781a8ffd6394  vmovaps xmm15, [rsp+0xC0]
0000781a8ffd639d  por xmm1, xmm15
0000781a8ffd63a2  movaps xmm15, [r15+0x290]
0000781a8ffd63aa  vmovaps [rsp+0xC0], xmm15
0000781a8ffd63b3  vmovaps [rsp+0xF0], xmm1
0000781a8ffd63bc  vmovaps xmm1, [rsp+0xC0]
0000781a8ffd63c5  por xmm15, xmm1
0000781a8ffd63ca  movaps xmm1, [r15+0x260]
0000781a8ffd63d2  vmovaps [rsp+0xC0], xmm1
0000781a8ffd63db  vmovaps [rsp+0x100], xmm15
0000781a8ffd63e4  vmovaps xmm15, [rsp+0xC0]
0000781a8ffd63ed  por xmm1, xmm15
0000781a8ffd63f2  vmovaps xmm15, [rsp+0xD0]
0000781a8ffd63fb  vmovaps [rsp+0xC0], xmm1
0000781a8ffd6404  vmovaps xmm1, [rsp+0xD0]
0000781a8ffd640d  por xmm15, xmm1
0000781a8ffd6412  lea r14, [rax+0xC0]
0000781a8ffd6419  movups xmm1, [r13+r14*1]
0000781a8ffd641f  mov [rsp+0xD0], rax
0000781a8ffd6427  xor eax, eax
0000781a8ffd6429  mov r14d, 0x200
0000781a8ffd642f  cmp r12, r14
0000781a8ffd6432  cmc
0000781a8ffd6433  lahf
0000781a8ffd6434  seto al
0000781a8ffd6437  mov [r15+0x108], eax
0000781a8ffd643e  vmovaps [rsp+0x110], xmm1
0000781a8ffd6447  vmovaps xmm1, [rsp+0x80]
0000781a8ffd6450  vmovaps [rsp+0x80], xmm15
0000781a8ffd6459  vmovaps xmm15, [rsp+0x110]
0000781a8ffd6462  vmovaps [rsp+0x110], xmm13
0000781a8ffd646b  vmovaps [rsp+0x120], xmm12
0000781a8ffd6474  movaps xmm13, xmm1
0000781a8ffd6478  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd647d  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd6483  vptest xmm12, xmm12
0000781a8ffd6488  jnz 0x0000781A8FFD7058
0000781a8ffd648e  mov rax, [rsp+0xD0]
0000781a8ffd6496  lea r14, [rax+0xB0]
0000781a8ffd649d  movups xmm1, [r13+r14*1]
0000781a8ffd64a3  vmovaps xmm15, [rsp+0xA0]
0000781a8ffd64ac  vmovaps [rsp+0xA0], xmm13
0000781a8ffd64b5  movaps xmm12, xmm15
0000781a8ffd64b9  vfmadd231pd xmm12, xmm1, xmm14
0000781a8ffd64be  vcmppd xmm13, xmm12, xmm12, 0x03
0000781a8ffd64c4  vptest xmm13, xmm13
0000781a8ffd64c9  jnz 0x0000781A8FFD71BB
0000781a8ffd64cf  vmovaps xmm1, [rsp+0x30]
0000781a8ffd64d5  vmovaps xmm15, [rsp+0x30]
0000781a8ffd64db  por xmm1, xmm15
0000781a8ffd64e0  movaps [r15+0x210], xmm1
0000781a8ffd64e8  vmovaps xmm15, [rsp+0x70]
0000781a8ffd64ee  vmovaps xmm14, [rsp+0x70]
0000781a8ffd64f4  por xmm15, xmm14
0000781a8ffd64f9  movaps [r15+0x1C0], xmm15
0000781a8ffd6501  vmovaps xmm14, [rsp+0x60]
0000781a8ffd6507  vmovaps xmm13, [rsp+0x60]
0000781a8ffd650d  por xmm14, xmm13
0000781a8ffd6512  movaps [r15+0x280], xmm14
0000781a8ffd651a  vmovaps xmm13, [rsp+0x50]
0000781a8ffd6520  vmovaps [rsp+0x30], xmm1
0000781a8ffd6526  vmovaps xmm1, [rsp+0x50]
0000781a8ffd652c  por xmm13, xmm1
0000781a8ffd6531  movaps [r15+0x2A0], xmm13
0000781a8ffd6539  vmovaps [rsp+0x50], xmm2
0000781a8ffd653f  vmovaps xmm1, [rsp+0x50]
0000781a8ffd6545  por xmm2, xmm1
0000781a8ffd6549  movaps [r15+0x2E0], xmm2
0000781a8ffd6551  vmovaps [rsp+0x50], xmm3
0000781a8ffd6557  vmovaps xmm1, [rsp+0x50]
0000781a8ffd655d  por xmm3, xmm1
0000781a8ffd6561  movaps [r15+0x1F0], xmm3
0000781a8ffd6569  vmovaps xmm1, [rsp+0x80]
0000781a8ffd6572  vmovaps [rsp+0x50], xmm15
0000781a8ffd6578  vmovaps xmm15, [rsp+0x80]
0000781a8ffd6581  por xmm1, xmm15
0000781a8ffd6586  movaps [r15+0x250], xmm1
0000781a8ffd658e  vmovaps xmm1, [rsp+0xC0]
0000781a8ffd6597  vmovaps xmm15, [rsp+0xC0]
0000781a8ffd65a0  por xmm1, xmm15
0000781a8ffd65a5  movaps [r15+0x260], xmm1
0000781a8ffd65ad  vmovaps xmm15, [rsp+0x100]
0000781a8ffd65b6  vmovaps [rsp+0x60], xmm1
0000781a8ffd65bc  vmovaps xmm1, [rsp+0x100]
0000781a8ffd65c5  por xmm15, xmm1
0000781a8ffd65ca  movaps [r15+0x290], xmm15
0000781a8ffd65d2  vmovaps xmm1, [rsp+0xF0]
0000781a8ffd65db  vmovaps [rsp+0x70], xmm15
0000781a8ffd65e1  vmovaps xmm15, [rsp+0xF0]
0000781a8ffd65ea  por xmm1, xmm15
0000781a8ffd65ef  movaps [r15+0x2C0], xmm1
0000781a8ffd65f7  movq xmm15, qword ptr [r15+0x240]
0000781a8ffd6600  vmovaps [rsp+0x80], xmm15
0000781a8ffd6609  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd660f  vmovaps [rsp+0xC0], xmm1
0000781a8ffd6618  vmovaps xmm1, [rsp+0x40]
0000781a8ffd661e  vmovaps [rsp+0x40], xmm15
0000781a8ffd6624  vmovaps xmm15, [rsp+0x30]
0000781a8ffd662a  vmovaps [rsp+0x30], xmm14
0000781a8ffd6630  vmovaps xmm14, [rsp+0x40]
0000781a8ffd6636  vmovaps [rsp+0x40], xmm13
0000781a8ffd663c  vmovaps [rsp+0xD0], xmm12
0000781a8ffd6645  movaps xmm13, xmm1
0000781a8ffd6649  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd664e  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd6654  vptest xmm12, xmm12
0000781a8ffd6659  jnz 0x0000781A8FFD7314
0000781a8ffd665f  vmovaps xmm1, [rsp+0x80]
0000781a8ffd6668  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd666e  vmovaps xmm15, [rsp+0xA0]
0000781a8ffd6677  movaps xmm14, xmm15
0000781a8ffd667b  vfmadd231pd xmm14, xmm2, xmm1
0000781a8ffd6680  vcmppd xmm12, xmm14, xmm14, 0x03
0000781a8ffd6686  vptest xmm12, xmm12
0000781a8ffd668b  jnz 0x0000781A8FFD746D
0000781a8ffd6691  vmovaps xmm1, [rsp+0x80]
0000781a8ffd669a  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd66a0  vmovaps xmm15, [rsp+0x120]
0000781a8ffd66a9  vmovaps xmm12, [rsp+0x50]
0000781a8ffd66af  vmovaps [rsp+0x50], xmm14
0000781a8ffd66b5  movaps xmm2, xmm15
0000781a8ffd66b9  vfmadd231pd xmm2, xmm12, xmm1
0000781a8ffd66be  vcmppd xmm14, xmm2, xmm2, 0x03
0000781a8ffd66c3  vptest xmm14, xmm14
0000781a8ffd66c8  jnz 0x0000781A8FFD75C5
0000781a8ffd66ce  vmovaps xmm1, [rsp+0x110]
0000781a8ffd66d7  vmovaps xmm15, [rsp+0x110]
0000781a8ffd66e0  por xmm1, xmm15
0000781a8ffd66e5  movaps [r15+0x1D0], xmm1
0000781a8ffd66ed  vmovaps xmm15, [rsp+0x80]
0000781a8ffd66f6  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd66fc  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd6705  vmovaps [rsp+0x80], xmm1
0000781a8ffd670e  movaps xmm12, xmm14
0000781a8ffd6712  vfmadd231pd xmm12, xmm3, xmm15
0000781a8ffd6717  vcmppd xmm1, xmm12, xmm12, 0x03
0000781a8ffd671d  vptest xmm1, xmm1
0000781a8ffd6722  jnz 0x0000781A8FFD771C
0000781a8ffd6728  vmovaps [rsp+0xA0], xmm4
0000781a8ffd6731  vmovaps xmm1, [rsp+0xA0]
0000781a8ffd673a  por xmm4, xmm1
0000781a8ffd673e  movaps [r15+0x200], xmm4
0000781a8ffd6746  vmovaps xmm1, [rsp+0xE0]
0000781a8ffd674f  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd6758  por xmm1, xmm15
0000781a8ffd675d  movaps [r15+0x1E0], xmm1
0000781a8ffd6765  vmovaps [rsp+0xA0], xmm8
0000781a8ffd676e  vmovaps xmm1, [rsp+0xA0]
0000781a8ffd6777  por xmm8, xmm1
0000781a8ffd677c  movaps [r15+0x2B0], xmm8
0000781a8ffd6784  vmovaps [rsp+0xA0], xmm9
0000781a8ffd678d  vmovaps xmm1, [rsp+0xA0]
0000781a8ffd6796  por xmm9, xmm1
0000781a8ffd679b  movaps [r15+0x300], xmm9
0000781a8ffd67a3  vmovaps [rsp+0xA0], xmm6
0000781a8ffd67ac  vpermilpd xmm6, xmm6, 0x00
0000781a8ffd67b2  vmovaps xmm14, [rsp+0x60]
0000781a8ffd67b8  movaps xmm9, xmm13
0000781a8ffd67bc  vfmadd231pd xmm9, xmm14, xmm6
0000781a8ffd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
0000781a8ffd67c7  vptest xmm3, xmm3
0000781a8ffd67cc  jnz 0x0000781A8FFD7875
0000781a8ffd67d2  vmovaps xmm14, [rsp+0xA0]
0000781a8ffd67db  vpermilpd xmm14, xmm14, 0x00
0000781a8ffd67e1  vmovaps xmm13, [rsp+0x50]
0000781a8ffd67e7  vmovaps xmm6, [rsp+0xC0]
0000781a8ffd67f0  vmovaps [rsp+0x50], xmm1
0000781a8ffd67f6  movaps xmm3, xmm13
0000781a8ffd67fa  vfmadd231pd xmm3, xmm6, xmm14
0000781a8ffd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
0000781a8ffd6804  vptest xmm1, xmm1
0000781a8ffd6809  jnz 0x0000781A8FFD79CE
0000781a8ffd680f  vmovaps xmm1, [rsp+0xA0]
0000781a8ffd6818  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd681e  vmovaps xmm14, [rsp+0x30]
0000781a8ffd6824  movaps xmm6, xmm2
0000781a8ffd6827  vfmadd231pd xmm6, xmm14, xmm1
0000781a8ffd682c  vcmppd xmm13, xmm6, xmm6, 0x03
0000781a8ffd6831  vptest xmm13, xmm13
0000781a8ffd6836  jnz 0x0000781A8FFD7B25
0000781a8ffd683c  vmovaps xmm1, [rsp+0xA0]
0000781a8ffd6845  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd684b  vmovaps xmm14, [rsp+0x80]
0000781a8ffd6854  movaps xmm13, xmm12
0000781a8ffd6858  vfmadd231pd xmm13, xmm14, xmm1
0000781a8ffd685d  vcmppd xmm2, xmm13, xmm13, 0x03
0000781a8ffd6863  vptest xmm2, xmm2
0000781a8ffd6868  jnz 0x0000781A8FFD7C7B
0000781a8ffd686e  vmovaps [rsp+0x30], xmm7
0000781a8ffd6874  vmovaps xmm1, [rsp+0x30]
0000781a8ffd687a  por xmm7, xmm1
0000781a8ffd687e  movaps [r15+0x180], xmm7
0000781a8ffd6886  vmovaps [rsp+0x30], xmm10
0000781a8ffd688c  vmovaps xmm1, [rsp+0x30]
0000781a8ffd6892  por xmm10, xmm1
0000781a8ffd6897  movaps [r15+0x2D0], xmm10
0000781a8ffd689f  vmovaps [rsp+0x30], xmm5
0000781a8ffd68a5  vpermilpd xmm5, xmm5, 0x00
0000781a8ffd68ab  vmovaps xmm14, [rsp+0x50]
0000781a8ffd68b1  movaps xmm12, xmm3
0000781a8ffd68b5  vfmadd231pd xmm12, xmm14, xmm5
0000781a8ffd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
0000781a8ffd68c0  vptest xmm10, xmm10
0000781a8ffd68c5  jnz 0x0000781A8FFD7DD4
0000781a8ffd68cb  vmovaps xmm14, [rsp+0x30]
0000781a8ffd68d1  vpermilpd xmm14, xmm14, 0x00
0000781a8ffd68d7  movaps xmm10, xmm9
0000781a8ffd68db  vfmadd231pd xmm10, xmm7, xmm14
0000781a8ffd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
0000781a8ffd68e6  vptest xmm5, xmm5
0000781a8ffd68eb  jnz 0x0000781A8FFD7F2C
0000781a8ffd68f1  lea r14, [rax+0x80]
0000781a8ffd68f8  movups xmm14, [r13+r14*1]
0000781a8ffd68fe  movaps [r15+0x2F0], xmm14
0000781a8ffd6906  vmovaps xmm9, [rsp+0x30]
0000781a8ffd690c  vpermilpd xmm9, xmm9, 0x00
0000781a8ffd6912  vmovaps xmm7, [rsp+0x70]
0000781a8ffd6918  movaps xmm5, xmm6
0000781a8ffd691b  vfmadd231pd xmm5, xmm7, xmm9
0000781a8ffd6920  vcmppd xmm3, xmm5, xmm5, 0x03
0000781a8ffd6925  vptest xmm3, xmm3
0000781a8ffd692a  jnz 0x0000781A8FFD808F
0000781a8ffd6930  vmovaps xmm9, [rsp+0x30]
0000781a8ffd6936  vpermilpd xmm9, xmm9, 0x00
0000781a8ffd693c  movaps xmm7, xmm13
0000781a8ffd6940  vfmadd231pd xmm7, xmm1, xmm9
0000781a8ffd6945  vcmppd xmm6, xmm7, xmm7, 0x03
0000781a8ffd694a  vptest xmm6, xmm6
0000781a8ffd694f  jnz 0x0000781A8FFD81E5
0000781a8ffd6955  vmovaps xmm1, [rsp+0x20]
0000781a8ffd695b  vmovaps xmm13, [rsp+0x20]
0000781a8ffd6961  por xmm1, xmm13
0000781a8ffd6966  movaps [r15+0x160], xmm1
0000781a8ffd696e  lea r14, [rax+0x40]
0000781a8ffd6972  movups xmm13, [r13+r14*1]
0000781a8ffd6978  lea r14, [rax+0x50]
0000781a8ffd697c  movups xmm9, [r13+r14*1]
0000781a8ffd6982  movaps [r15+0x1B0], xmm13
0000781a8ffd698a  movaps [r15+0x1A0], xmm9
0000781a8ffd6992  movaps xmm6, [r15+0x190]
0000781a8ffd699a  vmovaps xmm3, [rsp+0xB0]
0000781a8ffd69a3  vpermilpd xmm3, xmm3, 0x00
0000781a8ffd69a9  vmovaps [rsp+0x20], xmm1
0000781a8ffd69af  movaps xmm2, xmm12
0000781a8ffd69b3  vfmadd231pd xmm2, xmm6, xmm3
0000781a8ffd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
0000781a8ffd69bd  vptest xmm1, xmm1
0000781a8ffd69c2  jnz 0x0000781A8FFD8350
0000781a8ffd69c8  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd69d1  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd69d7  vmovaps xmm12, [rsp+0x20]
0000781a8ffd69dd  movaps xmm6, xmm10
0000781a8ffd69e1  vfmadd231pd xmm6, xmm12, xmm1
0000781a8ffd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
0000781a8ffd69eb  vptest xmm3, xmm3
0000781a8ffd69f0  jnz 0x0000781A8FFD84A6
0000781a8ffd69f6  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd69ff  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd6a05  vmovaps xmm12, [rsp+0x40]
0000781a8ffd6a0b  movaps xmm10, xmm5
0000781a8ffd6a0f  vfmadd231pd xmm10, xmm12, xmm1
0000781a8ffd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
0000781a8ffd6a1a  vptest xmm3, xmm3
0000781a8ffd6a1f  jnz 0x0000781A8FFD85FD
0000781a8ffd6a25  vmovaps xmm1, [rsp+0xB0]
0000781a8ffd6a2e  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd6a34  movaps xmm12, xmm7
0000781a8ffd6a38  vfmadd231pd xmm12, xmm15, xmm1
0000781a8ffd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
0000781a8ffd6a43  vptest xmm5, xmm5
0000781a8ffd6a48  jnz 0x0000781A8FFD8755
0000781a8ffd6a4e  lea r14, [rax+0x60]
0000781a8ffd6a52  movups xmm1, [r13+r14*1]
0000781a8ffd6a58  lea r14, [rax+0x70]
0000781a8ffd6a5c  movups xmm15, [r13+r14*1]
0000781a8ffd6a62  movaps [r15+0x150], xmm1
0000781a8ffd6a6a  movaps [r15+0x120], xmm15
0000781a8ffd6a72  vmovaps [rsp+0x20], xmm11
0000781a8ffd6a78  vpermilpd xmm11, xmm11, 0x00
0000781a8ffd6a7e  movaps xmm7, xmm2
0000781a8ffd6a81  vfmadd231pd xmm7, xmm9, xmm11
0000781a8ffd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
0000781a8ffd6a8b  vptest xmm5, xmm5
0000781a8ffd6a90  jnz 0x0000781A8FFD88C1
0000781a8ffd6a96  vmovaps xmm11, [rsp+0x20]
0000781a8ffd6a9c  vpermilpd xmm11, xmm11, 0x00
0000781a8ffd6aa2  movaps xmm9, xmm6
0000781a8ffd6aa6  vfmadd231pd xmm9, xmm1, xmm11
0000781a8ffd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
0000781a8ffd6ab1  vptest xmm5, xmm5
0000781a8ffd6ab6  jnz 0x0000781A8FFD8A18
0000781a8ffd6abc  vmovaps xmm1, [rsp+0x20]
0000781a8ffd6ac2  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd6ac8  movaps xmm11, xmm10
0000781a8ffd6acc  vfmadd231pd xmm11, xmm8, xmm1
0000781a8ffd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
0000781a8ffd6ad7  vptest xmm6, xmm6
0000781a8ffd6adc  jnz 0x0000781A8FFD8B70
0000781a8ffd6ae2  vmovaps xmm1, [rsp+0x20]
0000781a8ffd6ae8  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd6aee  movaps xmm10, xmm12
0000781a8ffd6af2  vfmadd231pd xmm10, xmm13, xmm1
0000781a8ffd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
0000781a8ffd6afd  vptest xmm8, xmm8
0000781a8ffd6b02  jnz 0x0000781A8FFD8CC9
0000781a8ffd6b08  lea r14, [rax+0x20]
0000781a8ffd6b0c  movups xmm1, [r13+r14*1]
0000781a8ffd6b12  lea r14, [rax+0x30]
0000781a8ffd6b16  movups xmm13, [r13+r14*1]
0000781a8ffd6b1c  vmovaps xmm12, [rsp+0x90]
0000781a8ffd6b25  vpermilpd xmm12, xmm12, 0x00
0000781a8ffd6b2b  movaps xmm8, xmm7
0000781a8ffd6b2f  vfmadd231pd xmm8, xmm4, xmm12
0000781a8ffd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
0000781a8ffd6b3a  vptest xmm6, xmm6
0000781a8ffd6b3f  jnz 0x0000781A8FFD8E36
0000781a8ffd6b45  vmovaps xmm12, [rsp+0x90]
0000781a8ffd6b4e  vpermilpd xmm12, xmm12, 0x00
0000781a8ffd6b54  movaps xmm7, xmm9
0000781a8ffd6b58  vfmadd231pd xmm7, xmm14, xmm12
0000781a8ffd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
0000781a8ffd6b62  vptest xmm6, xmm6
0000781a8ffd6b67  jnz 0x0000781A8FFD8F8E
0000781a8ffd6b6d  vmovaps xmm14, [rsp+0x90]
0000781a8ffd6b76  vpermilpd xmm14, xmm14, 0x00
0000781a8ffd6b7c  movaps xmm12, xmm11
0000781a8ffd6b80  vfmadd231pd xmm12, xmm15, xmm14
0000781a8ffd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
0000781a8ffd6b8b  vptest xmm9, xmm9
0000781a8ffd6b90  jnz 0x0000781A8FFD90E6
0000781a8ffd6b96  vmovaps xmm15, [rsp+0x90]
0000781a8ffd6b9f  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd6ba5  movaps xmm11, xmm10
0000781a8ffd6ba9  vfmadd231pd xmm11, xmm13, xmm15
0000781a8ffd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
0000781a8ffd6bb4  vptest xmm14, xmm14
0000781a8ffd6bb9  jnz 0x0000781A8FFD9240
0000781a8ffd6bbf  lea r14, [rax+0x90]
0000781a8ffd6bc6  movups xmm15, [r13+r14*1]
0000781a8ffd6bcc  lea r14, [rax+0xA0]
0000781a8ffd6bd3  movups xmm14, [r13+r14*1]
0000781a8ffd6bd9  movaps [r15+0x140], xmm15
0000781a8ffd6be1  movaps [r15+0x130], xmm14
0000781a8ffd6be9  vmovaps xmm13, [rsp+0x10]
0000781a8ffd6bef  vpermilpd xmm13, xmm13, 0x00
0000781a8ffd6bf5  movaps xmm10, xmm8
0000781a8ffd6bf9  vfmadd231pd xmm10, xmm1, xmm13
0000781a8ffd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
0000781a8ffd6c04  vptest xmm9, xmm9
0000781a8ffd6c09  jnz 0x0000781A8FFD93AE
0000781a8ffd6c0f  movaps [r15+0x220], xmm10
0000781a8ffd6c17  lea r14, [rax+0x10]
0000781a8ffd6c1b  movups xmm1, [r13+r14*1]
0000781a8ffd6c21  movaps [r15+0x240], xmm1
0000781a8ffd6c29  vmovaps xmm13, [rsp+0x10]
0000781a8ffd6c2f  vpermilpd xmm13, xmm13, 0x00
0000781a8ffd6c35  movaps xmm9, xmm7
0000781a8ffd6c39  vfmadd231pd xmm9, xmm14, xmm13
0000781a8ffd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
0000781a8ffd6c44  vptest xmm8, xmm8
0000781a8ffd6c49  jnz 0x0000781A8FFD9511
0000781a8ffd6c4f  movaps [r15+0x110], xmm9
0000781a8ffd6c57  vmovaps xmm14, [rsp+0x10]
0000781a8ffd6c5d  vpermilpd xmm14, xmm14, 0x00
0000781a8ffd6c63  movaps xmm13, xmm12
0000781a8ffd6c67  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
0000781a8ffd6c72  vptest xmm8, xmm8
0000781a8ffd6c77  jnz 0x0000781A8FFD966A
0000781a8ffd6c7d  movaps [r15+0x170], xmm13
0000781a8ffd6c85  vmovaps xmm15, [rsp+0x10]
0000781a8ffd6c8b  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd6c91  movaps xmm14, xmm11
0000781a8ffd6c95  vfmadd231pd xmm14, xmm1, xmm15
0000781a8ffd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
0000781a8ffd6ca0  vptest xmm12, xmm12
0000781a8ffd6ca5  jnz 0x0000781A8FFD97C4
0000781a8ffd6cab  movaps [r15+0x230], xmm14
0000781a8ffd6cb3  movups [r13+r11*1], xmm9
0000781a8ffd6cb9  lea rax, [r11+0x10]
0000781a8ffd6cbd  movups [r13+rax*1], xmm13
0000781a8ffd6cc3  lea rax, [r11+0x20]
0000781a8ffd6cc7  movups [r13+rax*1], xmm10
0000781a8ffd6ccd  lea rax, [r11+0x30]
0000781a8ffd6cd1  movups [r13+rax*1], xmm14
0000781a8ffd6cd7  mov eax, [r15+0x108]
0000781a8ffd6cde  sahf
0000781a8ffd6cdf  jnz 0x0000781A8FFD6D11
0000781a8ffd6ce1  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd6ce9  jz 0x0000781A8FFD9950
0000781a8ffd6cef  nop [rax+rax*1], ax
0000781a8ffd6cf8  nop [rax+rax*1], eax
0000781a8ffd6d00  mov eax, 0x410664
0000781a8ffd6d05  mov [r15+0x100], rax
0000781a8ffd6d0c  jmp 0x0000781A8FDFE110
0000781a8ffd6d11  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd6d19  jz 0x0000781A8FFD6050
0000781a8ffd6d1f  nop [rax+rax*1], ax
0000781a8ffd6d28  nop [rax+rax*1], eax
0000781a8ffd6d30  mov eax, 0x4104F0
0000781a8ffd6d35  mov [r15+0x100], rax
0000781a8ffd6d3c  jmp 0x0000781A8FDFE110
0000781a8ffd6d41  int3
0000781a8ffd6d42  call 0x0000781A8FE0A4B0
0000781a8ffd6d47  jmp 0x0000781A8FFD6079
0000781a8ffd6d4c  call 0x0000781A8FE09240
0000781a8ffd6d51  jmp 0x0000781A8FFD6083
0000781a8ffd6d56  call 0x0000781A8FE0A4B0
0000781a8ffd6d5b  jmp 0x0000781A8FFD60CD
0000781a8ffd6d60  call 0x0000781A8FE09240
0000781a8ffd6d65  jmp 0x0000781A8FFD60D7
0000781a8ffd6d6a  call 0x0000781A8FE0A4B0
0000781a8ffd6d6f  jmp 0x0000781A8FFD6158
0000781a8ffd6d74  call 0x0000781A8FE09240
0000781a8ffd6d79  jmp 0x0000781A8FFD6162
0000781a8ffd6d7e  call 0x0000781A8FEB47C0
0000781a8ffd6d83  jmp 0x0000781A8FFD6243
0000781a8ffd6d88  call 0x0000781A8FDFF430
0000781a8ffd6d8d  jmp 0x0000781A8FFD6272
0000781a8ffd6d92  call 0x0000781A8FEB0CE0
0000781a8ffd6d97  jmp 0x0000781A8FFD628E
0000781a8ffd6d9c  sub rsp, 0x08
0000781a8ffd6da0  push rax
0000781a8ffd6da1  push rcx
0000781a8ffd6da2  push rdx
0000781a8ffd6da3  push rdi
0000781a8ffd6da4  push rsi
0000781a8ffd6da5  push r8
0000781a8ffd6da7  push r9
0000781a8ffd6da9  push r10
0000781a8ffd6dab  push r11
0000781a8ffd6dad  sub rsp, 0xF0
0000781a8ffd6db4  vmovaps [rsp], xmm0
0000781a8ffd6db9  vmovaps [rsp+0x10], xmm1
0000781a8ffd6dbf  vmovaps [rsp+0x20], xmm2
0000781a8ffd6dc5  vmovaps [rsp+0x30], xmm3
0000781a8ffd6dcb  vmovaps [rsp+0x40], xmm4
0000781a8ffd6dd1  vmovaps [rsp+0x50], xmm5
0000781a8ffd6dd7  vmovaps [rsp+0x60], xmm6
0000781a8ffd6ddd  vmovaps [rsp+0x70], xmm7
0000781a8ffd6de3  vmovaps [rsp+0x80], xmm8
0000781a8ffd6dec  vmovaps [rsp+0x90], xmm9
0000781a8ffd6df5  vmovaps [rsp+0xA0], xmm10
0000781a8ffd6dfe  vmovaps [rsp+0xB0], xmm11
0000781a8ffd6e07  vmovaps [rsp+0xC0], xmm12
0000781a8ffd6e10  vmovaps [rsp+0xD0], xmm14
0000781a8ffd6e19  vmovaps [rsp+0xE0], xmm15
0000781a8ffd6e22  sub rsp, 0x40
0000781a8ffd6e26  lea rdi, [rsp]
0000781a8ffd6e2a  lea rsi, [rsp+0x10]
0000781a8ffd6e2f  lea rdx, [rsp+0x20]
0000781a8ffd6e34  lea rcx, [rsp+0x30]
0000781a8ffd6e39  mov r8d, 0x00
0000781a8ffd6e3f  lea r9, [r15+0x3A8]
0000781a8ffd6e46  movaps [rdi], xmm13
0000781a8ffd6e4a  movaps [rsi], xmm1
0000781a8ffd6e4d  movaps [rdx], xmm15
0000781a8ffd6e51  movaps [rcx], xmm14
0000781a8ffd6e55  mov rax, 0x627DDC279A50
0000781a8ffd6e5f  call rax
0000781a8ffd6e61  movaps xmm13, [rsp]
0000781a8ffd6e66  add rsp, 0x40
0000781a8ffd6e6a  vmovaps xmm0, [rsp]
0000781a8ffd6e6f  vmovaps xmm1, [rsp+0x10]
0000781a8ffd6e75  vmovaps xmm2, [rsp+0x20]
0000781a8ffd6e7b  vmovaps xmm3, [rsp+0x30]
0000781a8ffd6e81  vmovaps xmm4, [rsp+0x40]
0000781a8ffd6e87  vmovaps xmm5, [rsp+0x50]
0000781a8ffd6e8d  vmovaps xmm6, [rsp+0x60]
0000781a8ffd6e93  vmovaps xmm7, [rsp+0x70]
0000781a8ffd6e99  vmovaps xmm8, [rsp+0x80]
0000781a8ffd6ea2  vmovaps xmm9, [rsp+0x90]
0000781a8ffd6eab  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd6eb4  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd6ebd  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd6ec6  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd6ecf  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd6ed8  add rsp, 0xF0
0000781a8ffd6edf  pop r11
0000781a8ffd6ee1  pop r10
0000781a8ffd6ee3  pop r9
0000781a8ffd6ee5  pop r8
0000781a8ffd6ee7  pop rsi
0000781a8ffd6ee8  pop rdi
0000781a8ffd6ee9  pop rdx
0000781a8ffd6eea  pop rcx
0000781a8ffd6eeb  pop rax
0000781a8ffd6eec  add rsp, 0x08
0000781a8ffd6ef0  jmp 0x0000781A8FFD6305
0000781a8ffd6ef5  sub rsp, 0x08
0000781a8ffd6ef9  push rax
0000781a8ffd6efa  push rcx
0000781a8ffd6efb  push rdx
0000781a8ffd6efc  push rdi
0000781a8ffd6efd  push rsi
0000781a8ffd6efe  push r8
0000781a8ffd6f00  push r9
0000781a8ffd6f02  push r10
0000781a8ffd6f04  push r11
0000781a8ffd6f06  sub rsp, 0xF0
0000781a8ffd6f0d  vmovaps [rsp], xmm0
0000781a8ffd6f12  vmovaps [rsp+0x10], xmm1
0000781a8ffd6f18  vmovaps [rsp+0x20], xmm2
0000781a8ffd6f1e  vmovaps [rsp+0x30], xmm3
0000781a8ffd6f24  vmovaps [rsp+0x40], xmm4
0000781a8ffd6f2a  vmovaps [rsp+0x50], xmm5
0000781a8ffd6f30  vmovaps [rsp+0x60], xmm6
0000781a8ffd6f36  vmovaps [rsp+0x70], xmm7
0000781a8ffd6f3c  vmovaps [rsp+0x80], xmm8
0000781a8ffd6f45  vmovaps [rsp+0x90], xmm9
0000781a8ffd6f4e  vmovaps [rsp+0xA0], xmm10
0000781a8ffd6f57  vmovaps [rsp+0xB0], xmm11
0000781a8ffd6f60  vmovaps [rsp+0xC0], xmm13
0000781a8ffd6f69  vmovaps [rsp+0xD0], xmm14
0000781a8ffd6f72  vmovaps [rsp+0xE0], xmm15
0000781a8ffd6f7b  sub rsp, 0x40
0000781a8ffd6f7f  lea rdi, [rsp]
0000781a8ffd6f83  lea rsi, [rsp+0x10]
0000781a8ffd6f88  lea rdx, [rsp+0x20]
0000781a8ffd6f8d  lea rcx, [rsp+0x30]
0000781a8ffd6f92  mov r8d, 0x00
0000781a8ffd6f98  lea r9, [r15+0x3A8]
0000781a8ffd6f9f  movaps [rdi], xmm12
0000781a8ffd6fa3  movaps [rsi], xmm15
0000781a8ffd6fa7  movaps [rdx], xmm1
0000781a8ffd6faa  movaps [rcx], xmm14
0000781a8ffd6fae  mov rax, 0x627DDC279A50
0000781a8ffd6fb8  call rax
0000781a8ffd6fba  movaps xmm12, [rsp]
0000781a8ffd6fbf  add rsp, 0x40
0000781a8ffd6fc3  vmovaps xmm0, [rsp]
0000781a8ffd6fc8  vmovaps xmm1, [rsp+0x10]
0000781a8ffd6fce  vmovaps xmm2, [rsp+0x20]
0000781a8ffd6fd4  vmovaps xmm3, [rsp+0x30]
0000781a8ffd6fda  vmovaps xmm4, [rsp+0x40]
0000781a8ffd6fe0  vmovaps xmm5, [rsp+0x50]
0000781a8ffd6fe6  vmovaps xmm6, [rsp+0x60]
0000781a8ffd6fec  vmovaps xmm7, [rsp+0x70]
0000781a8ffd6ff2  vmovaps xmm8, [rsp+0x80]
0000781a8ffd6ffb  vmovaps xmm9, [rsp+0x90]
0000781a8ffd7004  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd700d  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd7016  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd701f  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd7028  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd7031  add rsp, 0xF0
0000781a8ffd7038  pop r11
0000781a8ffd703a  pop r10
0000781a8ffd703c  pop r9
0000781a8ffd703e  pop r8
0000781a8ffd7040  pop rsi
0000781a8ffd7041  pop rdi
0000781a8ffd7042  pop rdx
0000781a8ffd7043  pop rcx
0000781a8ffd7044  pop rax
0000781a8ffd7045  add rsp, 0x08
0000781a8ffd7049  jmp 0x0000781A8FFD6333
0000781a8ffd704e  call 0x0000781A8FED64F0
0000781a8ffd7053  jmp 0x0000781A8FFD641F
0000781a8ffd7058  sub rsp, 0x08
0000781a8ffd705c  push rax
0000781a8ffd705d  push rcx
0000781a8ffd705e  push rdx
0000781a8ffd705f  push rdi
0000781a8ffd7060  push rsi
0000781a8ffd7061  push r8
0000781a8ffd7063  push r9
0000781a8ffd7065  push r10
0000781a8ffd7067  push r11
0000781a8ffd7069  sub rsp, 0xF0
0000781a8ffd7070  vmovaps [rsp], xmm0
0000781a8ffd7075  vmovaps [rsp+0x10], xmm1
0000781a8ffd707b  vmovaps [rsp+0x20], xmm2
0000781a8ffd7081  vmovaps [rsp+0x30], xmm3
0000781a8ffd7087  vmovaps [rsp+0x40], xmm4
0000781a8ffd708d  vmovaps [rsp+0x50], xmm5
0000781a8ffd7093  vmovaps [rsp+0x60], xmm6
0000781a8ffd7099  vmovaps [rsp+0x70], xmm7
0000781a8ffd709f  vmovaps [rsp+0x80], xmm8
0000781a8ffd70a8  vmovaps [rsp+0x90], xmm9
0000781a8ffd70b1  vmovaps [rsp+0xA0], xmm10
0000781a8ffd70ba  vmovaps [rsp+0xB0], xmm11
0000781a8ffd70c3  vmovaps [rsp+0xC0], xmm12
0000781a8ffd70cc  vmovaps [rsp+0xD0], xmm14
0000781a8ffd70d5  vmovaps [rsp+0xE0], xmm15
0000781a8ffd70de  sub rsp, 0x40
0000781a8ffd70e2  lea rdi, [rsp]
0000781a8ffd70e6  lea rsi, [rsp+0x10]
0000781a8ffd70eb  lea rdx, [rsp+0x20]
0000781a8ffd70f0  lea rcx, [rsp+0x30]
0000781a8ffd70f5  mov r8d, 0x00
0000781a8ffd70fb  lea r9, [r15+0x3A8]
0000781a8ffd7102  movaps [rdi], xmm13
0000781a8ffd7106  movaps [rsi], xmm1
0000781a8ffd7109  movaps [rdx], xmm15
0000781a8ffd710d  movaps [rcx], xmm14
0000781a8ffd7111  mov rax, 0x627DDC279A50
0000781a8ffd711b  call rax
0000781a8ffd711d  movaps xmm13, [rsp]
0000781a8ffd7122  add rsp, 0x40
0000781a8ffd7126  vmovaps xmm0, [rsp]
0000781a8ffd712b  vmovaps xmm1, [rsp+0x10]
0000781a8ffd7131  vmovaps xmm2, [rsp+0x20]
0000781a8ffd7137  vmovaps xmm3, [rsp+0x30]
0000781a8ffd713d  vmovaps xmm4, [rsp+0x40]
0000781a8ffd7143  vmovaps xmm5, [rsp+0x50]
0000781a8ffd7149  vmovaps xmm6, [rsp+0x60]
0000781a8ffd714f  vmovaps xmm7, [rsp+0x70]
0000781a8ffd7155  vmovaps xmm8, [rsp+0x80]
0000781a8ffd715e  vmovaps xmm9, [rsp+0x90]
0000781a8ffd7167  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd7170  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd7179  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd7182  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd718b  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd7194  add rsp, 0xF0
0000781a8ffd719b  pop r11
0000781a8ffd719d  pop r10
0000781a8ffd719f  pop r9
0000781a8ffd71a1  pop r8
0000781a8ffd71a3  pop rsi
0000781a8ffd71a4  pop rdi
0000781a8ffd71a5  pop rdx
0000781a8ffd71a6  pop rcx
0000781a8ffd71a7  pop rax
0000781a8ffd71a8  add rsp, 0x08
0000781a8ffd71ac  jmp 0x0000781A8FFD648E
0000781a8ffd71b1  call 0x0000781A8FED64F0
0000781a8ffd71b6  jmp 0x0000781A8FFD64A3
0000781a8ffd71bb  sub rsp, 0x08
0000781a8ffd71bf  push rax
0000781a8ffd71c0  push rcx
0000781a8ffd71c1  push rdx
0000781a8ffd71c2  push rdi
0000781a8ffd71c3  push rsi
0000781a8ffd71c4  push r8
0000781a8ffd71c6  push r9
0000781a8ffd71c8  push r10
0000781a8ffd71ca  push r11
0000781a8ffd71cc  sub rsp, 0xF0
0000781a8ffd71d3  vmovaps [rsp], xmm0
0000781a8ffd71d8  vmovaps [rsp+0x10], xmm1
0000781a8ffd71de  vmovaps [rsp+0x20], xmm2
0000781a8ffd71e4  vmovaps [rsp+0x30], xmm3
0000781a8ffd71ea  vmovaps [rsp+0x40], xmm4
0000781a8ffd71f0  vmovaps [rsp+0x50], xmm5
0000781a8ffd71f6  vmovaps [rsp+0x60], xmm6
0000781a8ffd71fc  vmovaps [rsp+0x70], xmm7
0000781a8ffd7202  vmovaps [rsp+0x80], xmm8
0000781a8ffd720b  vmovaps [rsp+0x90], xmm9
0000781a8ffd7214  vmovaps [rsp+0xA0], xmm10
0000781a8ffd721d  vmovaps [rsp+0xB0], xmm11
0000781a8ffd7226  vmovaps [rsp+0xC0], xmm13
0000781a8ffd722f  vmovaps [rsp+0xD0], xmm14
0000781a8ffd7238  vmovaps [rsp+0xE0], xmm15
0000781a8ffd7241  sub rsp, 0x40
0000781a8ffd7245  lea rdi, [rsp]
0000781a8ffd7249  lea rsi, [rsp+0x10]
0000781a8ffd724e  lea rdx, [rsp+0x20]
0000781a8ffd7253  lea rcx, [rsp+0x30]
0000781a8ffd7258  mov r8d, 0x00
0000781a8ffd725e  lea r9, [r15+0x3A8]
0000781a8ffd7265  movaps [rdi], xmm12
0000781a8ffd7269  movaps [rsi], xmm15
0000781a8ffd726d  movaps [rdx], xmm1
0000781a8ffd7270  movaps [rcx], xmm14
0000781a8ffd7274  mov rax, 0x627DDC279A50
0000781a8ffd727e  call rax
0000781a8ffd7280  movaps xmm12, [rsp]
0000781a8ffd7285  add rsp, 0x40
0000781a8ffd7289  vmovaps xmm0, [rsp]
0000781a8ffd728e  vmovaps xmm1, [rsp+0x10]
0000781a8ffd7294  vmovaps xmm2, [rsp+0x20]
0000781a8ffd729a  vmovaps xmm3, [rsp+0x30]
0000781a8ffd72a0  vmovaps xmm4, [rsp+0x40]
0000781a8ffd72a6  vmovaps xmm5, [rsp+0x50]
0000781a8ffd72ac  vmovaps xmm6, [rsp+0x60]
0000781a8ffd72b2  vmovaps xmm7, [rsp+0x70]
0000781a8ffd72b8  vmovaps xmm8, [rsp+0x80]
0000781a8ffd72c1  vmovaps xmm9, [rsp+0x90]
0000781a8ffd72ca  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd72d3  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd72dc  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd72e5  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd72ee  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd72f7  add rsp, 0xF0
0000781a8ffd72fe  pop r11
0000781a8ffd7300  pop r10
0000781a8ffd7302  pop r9
0000781a8ffd7304  pop r8
0000781a8ffd7306  pop rsi
0000781a8ffd7307  pop rdi
0000781a8ffd7308  pop rdx
0000781a8ffd7309  pop rcx
0000781a8ffd730a  pop rax
0000781a8ffd730b  add rsp, 0x08
0000781a8ffd730f  jmp 0x0000781A8FFD64CF
0000781a8ffd7314  sub rsp, 0x08
0000781a8ffd7318  push rax
0000781a8ffd7319  push rcx
0000781a8ffd731a  push rdx
0000781a8ffd731b  push rdi
0000781a8ffd731c  push rsi
0000781a8ffd731d  push r8
0000781a8ffd731f  push r9
0000781a8ffd7321  push r10
0000781a8ffd7323  push r11
0000781a8ffd7325  sub rsp, 0xF0
0000781a8ffd732c  vmovaps [rsp], xmm0
0000781a8ffd7331  vmovaps [rsp+0x10], xmm1
0000781a8ffd7337  vmovaps [rsp+0x20], xmm2
0000781a8ffd733d  vmovaps [rsp+0x30], xmm3
0000781a8ffd7343  vmovaps [rsp+0x40], xmm4
0000781a8ffd7349  vmovaps [rsp+0x50], xmm5
0000781a8ffd734f  vmovaps [rsp+0x60], xmm6
0000781a8ffd7355  vmovaps [rsp+0x70], xmm7
0000781a8ffd735b  vmovaps [rsp+0x80], xmm8
0000781a8ffd7364  vmovaps [rsp+0x90], xmm9
0000781a8ffd736d  vmovaps [rsp+0xA0], xmm10
0000781a8ffd7376  vmovaps [rsp+0xB0], xmm11
0000781a8ffd737f  vmovaps [rsp+0xC0], xmm12
0000781a8ffd7388  vmovaps [rsp+0xD0], xmm14
0000781a8ffd7391  vmovaps [rsp+0xE0], xmm15
0000781a8ffd739a  sub rsp, 0x40
0000781a8ffd739e  lea rdi, [rsp]
0000781a8ffd73a2  lea rsi, [rsp+0x10]
0000781a8ffd73a7  lea rdx, [rsp+0x20]
0000781a8ffd73ac  lea rcx, [rsp+0x30]
0000781a8ffd73b1  mov r8d, 0x00
0000781a8ffd73b7  lea r9, [r15+0x3A8]
0000781a8ffd73be  movaps [rdi], xmm13
0000781a8ffd73c2  movaps [rsi], xmm1
0000781a8ffd73c5  movaps [rdx], xmm15
0000781a8ffd73c9  movaps [rcx], xmm14
0000781a8ffd73cd  mov rax, 0x627DDC279A50
0000781a8ffd73d7  call rax
0000781a8ffd73d9  movaps xmm13, [rsp]
0000781a8ffd73de  add rsp, 0x40
0000781a8ffd73e2  vmovaps xmm0, [rsp]
0000781a8ffd73e7  vmovaps xmm1, [rsp+0x10]
0000781a8ffd73ed  vmovaps xmm2, [rsp+0x20]
0000781a8ffd73f3  vmovaps xmm3, [rsp+0x30]
0000781a8ffd73f9  vmovaps xmm4, [rsp+0x40]
0000781a8ffd73ff  vmovaps xmm5, [rsp+0x50]
0000781a8ffd7405  vmovaps xmm6, [rsp+0x60]
0000781a8ffd740b  vmovaps xmm7, [rsp+0x70]
0000781a8ffd7411  vmovaps xmm8, [rsp+0x80]
0000781a8ffd741a  vmovaps xmm9, [rsp+0x90]
0000781a8ffd7423  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd742c  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd7435  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd743e  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd7447  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd7450  add rsp, 0xF0
0000781a8ffd7457  pop r11
0000781a8ffd7459  pop r10
0000781a8ffd745b  pop r9
0000781a8ffd745d  pop r8
0000781a8ffd745f  pop rsi
0000781a8ffd7460  pop rdi
0000781a8ffd7461  pop rdx
0000781a8ffd7462  pop rcx
0000781a8ffd7463  pop rax
0000781a8ffd7464  add rsp, 0x08
0000781a8ffd7468  jmp 0x0000781A8FFD665F
0000781a8ffd746d  sub rsp, 0x08
0000781a8ffd7471  push rax
0000781a8ffd7472  push rcx
0000781a8ffd7473  push rdx
0000781a8ffd7474  push rdi
0000781a8ffd7475  push rsi
0000781a8ffd7476  push r8
0000781a8ffd7478  push r9
0000781a8ffd747a  push r10
0000781a8ffd747c  push r11
0000781a8ffd747e  sub rsp, 0xF0
0000781a8ffd7485  vmovaps [rsp], xmm0
0000781a8ffd748a  vmovaps [rsp+0x10], xmm1
0000781a8ffd7490  vmovaps [rsp+0x20], xmm2
0000781a8ffd7496  vmovaps [rsp+0x30], xmm3
0000781a8ffd749c  vmovaps [rsp+0x40], xmm4
0000781a8ffd74a2  vmovaps [rsp+0x50], xmm5
0000781a8ffd74a8  vmovaps [rsp+0x60], xmm6
0000781a8ffd74ae  vmovaps [rsp+0x70], xmm7
0000781a8ffd74b4  vmovaps [rsp+0x80], xmm8
0000781a8ffd74bd  vmovaps [rsp+0x90], xmm9
0000781a8ffd74c6  vmovaps [rsp+0xA0], xmm10
0000781a8ffd74cf  vmovaps [rsp+0xB0], xmm11
0000781a8ffd74d8  vmovaps [rsp+0xC0], xmm12
0000781a8ffd74e1  vmovaps [rsp+0xD0], xmm13
0000781a8ffd74ea  vmovaps [rsp+0xE0], xmm15
0000781a8ffd74f3  sub rsp, 0x40
0000781a8ffd74f7  lea rdi, [rsp]
0000781a8ffd74fb  lea rsi, [rsp+0x10]
0000781a8ffd7500  lea rdx, [rsp+0x20]
0000781a8ffd7505  lea rcx, [rsp+0x30]
0000781a8ffd750a  mov r8d, 0x00
0000781a8ffd7510  lea r9, [r15+0x3A8]
0000781a8ffd7517  movaps [rdi], xmm14
0000781a8ffd751b  movaps [rsi], xmm15
0000781a8ffd751f  movaps [rdx], xmm2
0000781a8ffd7522  movaps [rcx], xmm1
0000781a8ffd7525  mov rax, 0x627DDC279A50
0000781a8ffd752f  call rax
0000781a8ffd7531  movaps xmm14, [rsp]
0000781a8ffd7536  add rsp, 0x40
0000781a8ffd753a  vmovaps xmm0, [rsp]
0000781a8ffd753f  vmovaps xmm1, [rsp+0x10]
0000781a8ffd7545  vmovaps xmm2, [rsp+0x20]
0000781a8ffd754b  vmovaps xmm3, [rsp+0x30]
0000781a8ffd7551  vmovaps xmm4, [rsp+0x40]
0000781a8ffd7557  vmovaps xmm5, [rsp+0x50]
0000781a8ffd755d  vmovaps xmm6, [rsp+0x60]
0000781a8ffd7563  vmovaps xmm7, [rsp+0x70]
0000781a8ffd7569  vmovaps xmm8, [rsp+0x80]
0000781a8ffd7572  vmovaps xmm9, [rsp+0x90]
0000781a8ffd757b  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd7584  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd758d  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd7596  vmovaps xmm13, [rsp+0xD0]
0000781a8ffd759f  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd75a8  add rsp, 0xF0
0000781a8ffd75af  pop r11
0000781a8ffd75b1  pop r10
0000781a8ffd75b3  pop r9
0000781a8ffd75b5  pop r8
0000781a8ffd75b7  pop rsi
0000781a8ffd75b8  pop rdi
0000781a8ffd75b9  pop rdx
0000781a8ffd75ba  pop rcx
0000781a8ffd75bb  pop rax
0000781a8ffd75bc  add rsp, 0x08
0000781a8ffd75c0  jmp 0x0000781A8FFD6691
0000781a8ffd75c5  sub rsp, 0x08
0000781a8ffd75c9  push rax
0000781a8ffd75ca  push rcx
0000781a8ffd75cb  push rdx
0000781a8ffd75cc  push rdi
0000781a8ffd75cd  push rsi
0000781a8ffd75ce  push r8
0000781a8ffd75d0  push r9
0000781a8ffd75d2  push r10
0000781a8ffd75d4  push r11
0000781a8ffd75d6  sub rsp, 0xF0
0000781a8ffd75dd  vmovaps [rsp], xmm0
0000781a8ffd75e2  vmovaps [rsp+0x10], xmm1
0000781a8ffd75e8  vmovaps [rsp+0x20], xmm3
0000781a8ffd75ee  vmovaps [rsp+0x30], xmm4
0000781a8ffd75f4  vmovaps [rsp+0x40], xmm5
0000781a8ffd75fa  vmovaps [rsp+0x50], xmm6
0000781a8ffd7600  vmovaps [rsp+0x60], xmm7
0000781a8ffd7606  vmovaps [rsp+0x70], xmm8
0000781a8ffd760c  vmovaps [rsp+0x80], xmm9
0000781a8ffd7615  vmovaps [rsp+0x90], xmm10
0000781a8ffd761e  vmovaps [rsp+0xA0], xmm11
0000781a8ffd7627  vmovaps [rsp+0xB0], xmm12
0000781a8ffd7630  vmovaps [rsp+0xC0], xmm13
0000781a8ffd7639  vmovaps [rsp+0xD0], xmm14
0000781a8ffd7642  vmovaps [rsp+0xE0], xmm15
0000781a8ffd764b  sub rsp, 0x40
0000781a8ffd764f  lea rdi, [rsp]
0000781a8ffd7653  lea rsi, [rsp+0x10]
0000781a8ffd7658  lea rdx, [rsp+0x20]
0000781a8ffd765d  lea rcx, [rsp+0x30]
0000781a8ffd7662  mov r8d, 0x00
0000781a8ffd7668  lea r9, [r15+0x3A8]
0000781a8ffd766f  movaps [rdi], xmm2
0000781a8ffd7672  movaps [rsi], xmm15
0000781a8ffd7676  movaps [rdx], xmm12
0000781a8ffd767a  movaps [rcx], xmm1
0000781a8ffd767d  mov rax, 0x627DDC279A50
0000781a8ffd7687  call rax
0000781a8ffd7689  movaps xmm2, [rsp]
0000781a8ffd768d  add rsp, 0x40
0000781a8ffd7691  vmovaps xmm0, [rsp]
0000781a8ffd7696  vmovaps xmm1, [rsp+0x10]
0000781a8ffd769c  vmovaps xmm3, [rsp+0x20]
0000781a8ffd76a2  vmovaps xmm4, [rsp+0x30]
0000781a8ffd76a8  vmovaps xmm5, [rsp+0x40]
0000781a8ffd76ae  vmovaps xmm6, [rsp+0x50]
0000781a8ffd76b4  vmovaps xmm7, [rsp+0x60]
0000781a8ffd76ba  vmovaps xmm8, [rsp+0x70]
0000781a8ffd76c0  vmovaps xmm9, [rsp+0x80]
0000781a8ffd76c9  vmovaps xmm10, [rsp+0x90]
0000781a8ffd76d2  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd76db  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd76e4  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd76ed  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd76f6  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd76ff  add rsp, 0xF0
0000781a8ffd7706  pop r11
0000781a8ffd7708  pop r10
0000781a8ffd770a  pop r9
0000781a8ffd770c  pop r8
0000781a8ffd770e  pop rsi
0000781a8ffd770f  pop rdi
0000781a8ffd7710  pop rdx
0000781a8ffd7711  pop rcx
0000781a8ffd7712  pop rax
0000781a8ffd7713  add rsp, 0x08
0000781a8ffd7717  jmp 0x0000781A8FFD66CE
0000781a8ffd771c  sub rsp, 0x08
0000781a8ffd7720  push rax
0000781a8ffd7721  push rcx
0000781a8ffd7722  push rdx
0000781a8ffd7723  push rdi
0000781a8ffd7724  push rsi
0000781a8ffd7725  push r8
0000781a8ffd7727  push r9
0000781a8ffd7729  push r10
0000781a8ffd772b  push r11
0000781a8ffd772d  sub rsp, 0xF0
0000781a8ffd7734  vmovaps [rsp], xmm0
0000781a8ffd7739  vmovaps [rsp+0x10], xmm1
0000781a8ffd773f  vmovaps [rsp+0x20], xmm2
0000781a8ffd7745  vmovaps [rsp+0x30], xmm3
0000781a8ffd774b  vmovaps [rsp+0x40], xmm4
0000781a8ffd7751  vmovaps [rsp+0x50], xmm5
0000781a8ffd7757  vmovaps [rsp+0x60], xmm6
0000781a8ffd775d  vmovaps [rsp+0x70], xmm7
0000781a8ffd7763  vmovaps [rsp+0x80], xmm8
0000781a8ffd776c  vmovaps [rsp+0x90], xmm9
0000781a8ffd7775  vmovaps [rsp+0xA0], xmm10
0000781a8ffd777e  vmovaps [rsp+0xB0], xmm11
0000781a8ffd7787  vmovaps [rsp+0xC0], xmm13
0000781a8ffd7790  vmovaps [rsp+0xD0], xmm14
0000781a8ffd7799  vmovaps [rsp+0xE0], xmm15
0000781a8ffd77a2  sub rsp, 0x40
0000781a8ffd77a6  lea rdi, [rsp]
0000781a8ffd77aa  lea rsi, [rsp+0x10]
0000781a8ffd77af  lea rdx, [rsp+0x20]
0000781a8ffd77b4  lea rcx, [rsp+0x30]
0000781a8ffd77b9  mov r8d, 0x00
0000781a8ffd77bf  lea r9, [r15+0x3A8]
0000781a8ffd77c6  movaps [rdi], xmm12
0000781a8ffd77ca  movaps [rsi], xmm14
0000781a8ffd77ce  movaps [rdx], xmm3
0000781a8ffd77d1  movaps [rcx], xmm15
0000781a8ffd77d5  mov rax, 0x627DDC279A50
0000781a8ffd77df  call rax
0000781a8ffd77e1  movaps xmm12, [rsp]
0000781a8ffd77e6  add rsp, 0x40
0000781a8ffd77ea  vmovaps xmm0, [rsp]
0000781a8ffd77ef  vmovaps xmm1, [rsp+0x10]
0000781a8ffd77f5  vmovaps xmm2, [rsp+0x20]
0000781a8ffd77fb  vmovaps xmm3, [rsp+0x30]
0000781a8ffd7801  vmovaps xmm4, [rsp+0x40]
0000781a8ffd7807  vmovaps xmm5, [rsp+0x50]
0000781a8ffd780d  vmovaps xmm6, [rsp+0x60]
0000781a8ffd7813  vmovaps xmm7, [rsp+0x70]
0000781a8ffd7819  vmovaps xmm8, [rsp+0x80]
0000781a8ffd7822  vmovaps xmm9, [rsp+0x90]
0000781a8ffd782b  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd7834  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd783d  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd7846  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd784f  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd7858  add rsp, 0xF0
0000781a8ffd785f  pop r11
0000781a8ffd7861  pop r10
0000781a8ffd7863  pop r9
0000781a8ffd7865  pop r8
0000781a8ffd7867  pop rsi
0000781a8ffd7868  pop rdi
0000781a8ffd7869  pop rdx
0000781a8ffd786a  pop rcx
0000781a8ffd786b  pop rax
0000781a8ffd786c  add rsp, 0x08
0000781a8ffd7870  jmp 0x0000781A8FFD6728
0000781a8ffd7875  sub rsp, 0x08
0000781a8ffd7879  push rax
0000781a8ffd787a  push rcx
0000781a8ffd787b  push rdx
0000781a8ffd787c  push rdi
0000781a8ffd787d  push rsi
0000781a8ffd787e  push r8
0000781a8ffd7880  push r9
0000781a8ffd7882  push r10
0000781a8ffd7884  push r11
0000781a8ffd7886  sub rsp, 0xF0
0000781a8ffd788d  vmovaps [rsp], xmm0
0000781a8ffd7892  vmovaps [rsp+0x10], xmm1
0000781a8ffd7898  vmovaps [rsp+0x20], xmm2
0000781a8ffd789e  vmovaps [rsp+0x30], xmm3
0000781a8ffd78a4  vmovaps [rsp+0x40], xmm4
0000781a8ffd78aa  vmovaps [rsp+0x50], xmm5
0000781a8ffd78b0  vmovaps [rsp+0x60], xmm6
0000781a8ffd78b6  vmovaps [rsp+0x70], xmm7
0000781a8ffd78bc  vmovaps [rsp+0x80], xmm8
0000781a8ffd78c5  vmovaps [rsp+0x90], xmm10
0000781a8ffd78ce  vmovaps [rsp+0xA0], xmm11
0000781a8ffd78d7  vmovaps [rsp+0xB0], xmm12
0000781a8ffd78e0  vmovaps [rsp+0xC0], xmm13
0000781a8ffd78e9  vmovaps [rsp+0xD0], xmm14
0000781a8ffd78f2  vmovaps [rsp+0xE0], xmm15
0000781a8ffd78fb  sub rsp, 0x40
0000781a8ffd78ff  lea rdi, [rsp]
0000781a8ffd7903  lea rsi, [rsp+0x10]
0000781a8ffd7908  lea rdx, [rsp+0x20]
0000781a8ffd790d  lea rcx, [rsp+0x30]
0000781a8ffd7912  mov r8d, 0x00
0000781a8ffd7918  lea r9, [r15+0x3A8]
0000781a8ffd791f  movaps [rdi], xmm9
0000781a8ffd7923  movaps [rsi], xmm13
0000781a8ffd7927  movaps [rdx], xmm14
0000781a8ffd792b  movaps [rcx], xmm6
0000781a8ffd792e  mov rax, 0x627DDC279A50
0000781a8ffd7938  call rax
0000781a8ffd793a  movaps xmm9, [rsp]
0000781a8ffd793f  add rsp, 0x40
0000781a8ffd7943  vmovaps xmm0, [rsp]
0000781a8ffd7948  vmovaps xmm1, [rsp+0x10]
0000781a8ffd794e  vmovaps xmm2, [rsp+0x20]
0000781a8ffd7954  vmovaps xmm3, [rsp+0x30]
0000781a8ffd795a  vmovaps xmm4, [rsp+0x40]
0000781a8ffd7960  vmovaps xmm5, [rsp+0x50]
0000781a8ffd7966  vmovaps xmm6, [rsp+0x60]
0000781a8ffd796c  vmovaps xmm7, [rsp+0x70]
0000781a8ffd7972  vmovaps xmm8, [rsp+0x80]
0000781a8ffd797b  vmovaps xmm10, [rsp+0x90]
0000781a8ffd7984  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd798d  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd7996  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd799f  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd79a8  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd79b1  add rsp, 0xF0
0000781a8ffd79b8  pop r11
0000781a8ffd79ba  pop r10
0000781a8ffd79bc  pop r9
0000781a8ffd79be  pop r8
0000781a8ffd79c0  pop rsi
0000781a8ffd79c1  pop rdi
0000781a8ffd79c2  pop rdx
0000781a8ffd79c3  pop rcx
0000781a8ffd79c4  pop rax
0000781a8ffd79c5  add rsp, 0x08
0000781a8ffd79c9  jmp 0x0000781A8FFD67D2
0000781a8ffd79ce  sub rsp, 0x08
0000781a8ffd79d2  push rax
0000781a8ffd79d3  push rcx
0000781a8ffd79d4  push rdx
0000781a8ffd79d5  push rdi
0000781a8ffd79d6  push rsi
0000781a8ffd79d7  push r8
0000781a8ffd79d9  push r9
0000781a8ffd79db  push r10
0000781a8ffd79dd  push r11
0000781a8ffd79df  sub rsp, 0xF0
0000781a8ffd79e6  vmovaps [rsp], xmm0
0000781a8ffd79eb  vmovaps [rsp+0x10], xmm1
0000781a8ffd79f1  vmovaps [rsp+0x20], xmm2
0000781a8ffd79f7  vmovaps [rsp+0x30], xmm4
0000781a8ffd79fd  vmovaps [rsp+0x40], xmm5
0000781a8ffd7a03  vmovaps [rsp+0x50], xmm6
0000781a8ffd7a09  vmovaps [rsp+0x60], xmm7
0000781a8ffd7a0f  vmovaps [rsp+0x70], xmm8
0000781a8ffd7a15  vmovaps [rsp+0x80], xmm9
0000781a8ffd7a1e  vmovaps [rsp+0x90], xmm10
0000781a8ffd7a27  vmovaps [rsp+0xA0], xmm11
0000781a8ffd7a30  vmovaps [rsp+0xB0], xmm12
0000781a8ffd7a39  vmovaps [rsp+0xC0], xmm13
0000781a8ffd7a42  vmovaps [rsp+0xD0], xmm14
0000781a8ffd7a4b  vmovaps [rsp+0xE0], xmm15
0000781a8ffd7a54  sub rsp, 0x40
0000781a8ffd7a58  lea rdi, [rsp]
0000781a8ffd7a5c  lea rsi, [rsp+0x10]
0000781a8ffd7a61  lea rdx, [rsp+0x20]
0000781a8ffd7a66  lea rcx, [rsp+0x30]
0000781a8ffd7a6b  mov r8d, 0x00
0000781a8ffd7a71  lea r9, [r15+0x3A8]
0000781a8ffd7a78  movaps [rdi], xmm3
0000781a8ffd7a7b  movaps [rsi], xmm13
0000781a8ffd7a7f  movaps [rdx], xmm6
0000781a8ffd7a82  movaps [rcx], xmm14
0000781a8ffd7a86  mov rax, 0x627DDC279A50
0000781a8ffd7a90  call rax
0000781a8ffd7a92  movaps xmm3, [rsp]
0000781a8ffd7a96  add rsp, 0x40
0000781a8ffd7a9a  vmovaps xmm0, [rsp]
0000781a8ffd7a9f  vmovaps xmm1, [rsp+0x10]
0000781a8ffd7aa5  vmovaps xmm2, [rsp+0x20]
0000781a8ffd7aab  vmovaps xmm4, [rsp+0x30]
0000781a8ffd7ab1  vmovaps xmm5, [rsp+0x40]
0000781a8ffd7ab7  vmovaps xmm6, [rsp+0x50]
0000781a8ffd7abd  vmovaps xmm7, [rsp+0x60]
0000781a8ffd7ac3  vmovaps xmm8, [rsp+0x70]
0000781a8ffd7ac9  vmovaps xmm9, [rsp+0x80]
0000781a8ffd7ad2  vmovaps xmm10, [rsp+0x90]
0000781a8ffd7adb  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd7ae4  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd7aed  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd7af6  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd7aff  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd7b08  add rsp, 0xF0
0000781a8ffd7b0f  pop r11
0000781a8ffd7b11  pop r10
0000781a8ffd7b13  pop r9
0000781a8ffd7b15  pop r8
0000781a8ffd7b17  pop rsi
0000781a8ffd7b18  pop rdi
0000781a8ffd7b19  pop rdx
0000781a8ffd7b1a  pop rcx
0000781a8ffd7b1b  pop rax
0000781a8ffd7b1c  add rsp, 0x08
0000781a8ffd7b20  jmp 0x0000781A8FFD680F
0000781a8ffd7b25  sub rsp, 0x08
0000781a8ffd7b29  push rax
0000781a8ffd7b2a  push rcx
0000781a8ffd7b2b  push rdx
0000781a8ffd7b2c  push rdi
0000781a8ffd7b2d  push rsi
0000781a8ffd7b2e  push r8
0000781a8ffd7b30  push r9
0000781a8ffd7b32  push r10
0000781a8ffd7b34  push r11
0000781a8ffd7b36  sub rsp, 0xF0
0000781a8ffd7b3d  vmovaps [rsp], xmm0
0000781a8ffd7b42  vmovaps [rsp+0x10], xmm1
0000781a8ffd7b48  vmovaps [rsp+0x20], xmm2
0000781a8ffd7b4e  vmovaps [rsp+0x30], xmm3
0000781a8ffd7b54  vmovaps [rsp+0x40], xmm4
0000781a8ffd7b5a  vmovaps [rsp+0x50], xmm5
0000781a8ffd7b60  vmovaps [rsp+0x60], xmm7
0000781a8ffd7b66  vmovaps [rsp+0x70], xmm8
0000781a8ffd7b6c  vmovaps [rsp+0x80], xmm9
0000781a8ffd7b75  vmovaps [rsp+0x90], xmm10
0000781a8ffd7b7e  vmovaps [rsp+0xA0], xmm11
0000781a8ffd7b87  vmovaps [rsp+0xB0], xmm12
0000781a8ffd7b90  vmovaps [rsp+0xC0], xmm13
0000781a8ffd7b99  vmovaps [rsp+0xD0], xmm14
0000781a8ffd7ba2  vmovaps [rsp+0xE0], xmm15
0000781a8ffd7bab  sub rsp, 0x40
0000781a8ffd7baf  lea rdi, [rsp]
0000781a8ffd7bb3  lea rsi, [rsp+0x10]
0000781a8ffd7bb8  lea rdx, [rsp+0x20]
0000781a8ffd7bbd  lea rcx, [rsp+0x30]
0000781a8ffd7bc2  mov r8d, 0x00
0000781a8ffd7bc8  lea r9, [r15+0x3A8]
0000781a8ffd7bcf  movaps [rdi], xmm6
0000781a8ffd7bd2  movaps [rsi], xmm2
0000781a8ffd7bd5  movaps [rdx], xmm14
0000781a8ffd7bd9  movaps [rcx], xmm1
0000781a8ffd7bdc  mov rax, 0x627DDC279A50
0000781a8ffd7be6  call rax
0000781a8ffd7be8  movaps xmm6, [rsp]
0000781a8ffd7bec  add rsp, 0x40
0000781a8ffd7bf0  vmovaps xmm0, [rsp]
0000781a8ffd7bf5  vmovaps xmm1, [rsp+0x10]
0000781a8ffd7bfb  vmovaps xmm2, [rsp+0x20]
0000781a8ffd7c01  vmovaps xmm3, [rsp+0x30]
0000781a8ffd7c07  vmovaps xmm4, [rsp+0x40]
0000781a8ffd7c0d  vmovaps xmm5, [rsp+0x50]
0000781a8ffd7c13  vmovaps xmm7, [rsp+0x60]
0000781a8ffd7c19  vmovaps xmm8, [rsp+0x70]
0000781a8ffd7c1f  vmovaps xmm9, [rsp+0x80]
0000781a8ffd7c28  vmovaps xmm10, [rsp+0x90]
0000781a8ffd7c31  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd7c3a  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd7c43  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd7c4c  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd7c55  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd7c5e  add rsp, 0xF0
0000781a8ffd7c65  pop r11
0000781a8ffd7c67  pop r10
0000781a8ffd7c69  pop r9
0000781a8ffd7c6b  pop r8
0000781a8ffd7c6d  pop rsi
0000781a8ffd7c6e  pop rdi
0000781a8ffd7c6f  pop rdx
0000781a8ffd7c70  pop rcx
0000781a8ffd7c71  pop rax
0000781a8ffd7c72  add rsp, 0x08
0000781a8ffd7c76  jmp 0x0000781A8FFD683C
0000781a8ffd7c7b  sub rsp, 0x08
0000781a8ffd7c7f  push rax
0000781a8ffd7c80  push rcx
0000781a8ffd7c81  push rdx
0000781a8ffd7c82  push rdi
0000781a8ffd7c83  push rsi
0000781a8ffd7c84  push r8
0000781a8ffd7c86  push r9
0000781a8ffd7c88  push r10
0000781a8ffd7c8a  push r11
0000781a8ffd7c8c  sub rsp, 0xF0
0000781a8ffd7c93  vmovaps [rsp], xmm0
0000781a8ffd7c98  vmovaps [rsp+0x10], xmm1
0000781a8ffd7c9e  vmovaps [rsp+0x20], xmm2
0000781a8ffd7ca4  vmovaps [rsp+0x30], xmm3
0000781a8ffd7caa  vmovaps [rsp+0x40], xmm4
0000781a8ffd7cb0  vmovaps [rsp+0x50], xmm5
0000781a8ffd7cb6  vmovaps [rsp+0x60], xmm6
0000781a8ffd7cbc  vmovaps [rsp+0x70], xmm7
0000781a8ffd7cc2  vmovaps [rsp+0x80], xmm8
0000781a8ffd7ccb  vmovaps [rsp+0x90], xmm9
0000781a8ffd7cd4  vmovaps [rsp+0xA0], xmm10
0000781a8ffd7cdd  vmovaps [rsp+0xB0], xmm11
0000781a8ffd7ce6  vmovaps [rsp+0xC0], xmm12
0000781a8ffd7cef  vmovaps [rsp+0xD0], xmm14
0000781a8ffd7cf8  vmovaps [rsp+0xE0], xmm15
0000781a8ffd7d01  sub rsp, 0x40
0000781a8ffd7d05  lea rdi, [rsp]
0000781a8ffd7d09  lea rsi, [rsp+0x10]
0000781a8ffd7d0e  lea rdx, [rsp+0x20]
0000781a8ffd7d13  lea rcx, [rsp+0x30]
0000781a8ffd7d18  mov r8d, 0x00
0000781a8ffd7d1e  lea r9, [r15+0x3A8]
0000781a8ffd7d25  movaps [rdi], xmm13
0000781a8ffd7d29  movaps [rsi], xmm12
0000781a8ffd7d2d  movaps [rdx], xmm14
0000781a8ffd7d31  movaps [rcx], xmm1
0000781a8ffd7d34  mov rax, 0x627DDC279A50
0000781a8ffd7d3e  call rax
0000781a8ffd7d40  movaps xmm13, [rsp]
0000781a8ffd7d45  add rsp, 0x40
0000781a8ffd7d49  vmovaps xmm0, [rsp]
0000781a8ffd7d4e  vmovaps xmm1, [rsp+0x10]
0000781a8ffd7d54  vmovaps xmm2, [rsp+0x20]
0000781a8ffd7d5a  vmovaps xmm3, [rsp+0x30]
0000781a8ffd7d60  vmovaps xmm4, [rsp+0x40]
0000781a8ffd7d66  vmovaps xmm5, [rsp+0x50]
0000781a8ffd7d6c  vmovaps xmm6, [rsp+0x60]
0000781a8ffd7d72  vmovaps xmm7, [rsp+0x70]
0000781a8ffd7d78  vmovaps xmm8, [rsp+0x80]
0000781a8ffd7d81  vmovaps xmm9, [rsp+0x90]
0000781a8ffd7d8a  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd7d93  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd7d9c  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd7da5  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd7dae  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd7db7  add rsp, 0xF0
0000781a8ffd7dbe  pop r11
0000781a8ffd7dc0  pop r10
0000781a8ffd7dc2  pop r9
0000781a8ffd7dc4  pop r8
0000781a8ffd7dc6  pop rsi
0000781a8ffd7dc7  pop rdi
0000781a8ffd7dc8  pop rdx
0000781a8ffd7dc9  pop rcx
0000781a8ffd7dca  pop rax
0000781a8ffd7dcb  add rsp, 0x08
0000781a8ffd7dcf  jmp 0x0000781A8FFD686E
0000781a8ffd7dd4  sub rsp, 0x08
0000781a8ffd7dd8  push rax
0000781a8ffd7dd9  push rcx
0000781a8ffd7dda  push rdx
0000781a8ffd7ddb  push rdi
0000781a8ffd7ddc  push rsi
0000781a8ffd7ddd  push r8
0000781a8ffd7ddf  push r9
0000781a8ffd7de1  push r10
0000781a8ffd7de3  push r11
0000781a8ffd7de5  sub rsp, 0xF0
0000781a8ffd7dec  vmovaps [rsp], xmm0
0000781a8ffd7df1  vmovaps [rsp+0x10], xmm1
0000781a8ffd7df7  vmovaps [rsp+0x20], xmm2
0000781a8ffd7dfd  vmovaps [rsp+0x30], xmm3
0000781a8ffd7e03  vmovaps [rsp+0x40], xmm4
0000781a8ffd7e09  vmovaps [rsp+0x50], xmm5
0000781a8ffd7e0f  vmovaps [rsp+0x60], xmm6
0000781a8ffd7e15  vmovaps [rsp+0x70], xmm7
0000781a8ffd7e1b  vmovaps [rsp+0x80], xmm8
0000781a8ffd7e24  vmovaps [rsp+0x90], xmm9
0000781a8ffd7e2d  vmovaps [rsp+0xA0], xmm10
0000781a8ffd7e36  vmovaps [rsp+0xB0], xmm11
0000781a8ffd7e3f  vmovaps [rsp+0xC0], xmm13
0000781a8ffd7e48  vmovaps [rsp+0xD0], xmm14
0000781a8ffd7e51  vmovaps [rsp+0xE0], xmm15
0000781a8ffd7e5a  sub rsp, 0x40
0000781a8ffd7e5e  lea rdi, [rsp]
0000781a8ffd7e62  lea rsi, [rsp+0x10]
0000781a8ffd7e67  lea rdx, [rsp+0x20]
0000781a8ffd7e6c  lea rcx, [rsp+0x30]
0000781a8ffd7e71  mov r8d, 0x00
0000781a8ffd7e77  lea r9, [r15+0x3A8]
0000781a8ffd7e7e  movaps [rdi], xmm12
0000781a8ffd7e82  movaps [rsi], xmm3
0000781a8ffd7e85  movaps [rdx], xmm14
0000781a8ffd7e89  movaps [rcx], xmm5
0000781a8ffd7e8c  mov rax, 0x627DDC279A50
0000781a8ffd7e96  call rax
0000781a8ffd7e98  movaps xmm12, [rsp]
0000781a8ffd7e9d  add rsp, 0x40
0000781a8ffd7ea1  vmovaps xmm0, [rsp]
0000781a8ffd7ea6  vmovaps xmm1, [rsp+0x10]
0000781a8ffd7eac  vmovaps xmm2, [rsp+0x20]
0000781a8ffd7eb2  vmovaps xmm3, [rsp+0x30]
0000781a8ffd7eb8  vmovaps xmm4, [rsp+0x40]
0000781a8ffd7ebe  vmovaps xmm5, [rsp+0x50]
0000781a8ffd7ec4  vmovaps xmm6, [rsp+0x60]
0000781a8ffd7eca  vmovaps xmm7, [rsp+0x70]
0000781a8ffd7ed0  vmovaps xmm8, [rsp+0x80]
0000781a8ffd7ed9  vmovaps xmm9, [rsp+0x90]
0000781a8ffd7ee2  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd7eeb  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd7ef4  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd7efd  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd7f06  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd7f0f  add rsp, 0xF0
0000781a8ffd7f16  pop r11
0000781a8ffd7f18  pop r10
0000781a8ffd7f1a  pop r9
0000781a8ffd7f1c  pop r8
0000781a8ffd7f1e  pop rsi
0000781a8ffd7f1f  pop rdi
0000781a8ffd7f20  pop rdx
0000781a8ffd7f21  pop rcx
0000781a8ffd7f22  pop rax
0000781a8ffd7f23  add rsp, 0x08
0000781a8ffd7f27  jmp 0x0000781A8FFD68CB
0000781a8ffd7f2c  sub rsp, 0x08
0000781a8ffd7f30  push rax
0000781a8ffd7f31  push rcx
0000781a8ffd7f32  push rdx
0000781a8ffd7f33  push rdi
0000781a8ffd7f34  push rsi
0000781a8ffd7f35  push r8
0000781a8ffd7f37  push r9
0000781a8ffd7f39  push r10
0000781a8ffd7f3b  push r11
0000781a8ffd7f3d  sub rsp, 0xF0
0000781a8ffd7f44  vmovaps [rsp], xmm0
0000781a8ffd7f49  vmovaps [rsp+0x10], xmm1
0000781a8ffd7f4f  vmovaps [rsp+0x20], xmm2
0000781a8ffd7f55  vmovaps [rsp+0x30], xmm3
0000781a8ffd7f5b  vmovaps [rsp+0x40], xmm4
0000781a8ffd7f61  vmovaps [rsp+0x50], xmm5
0000781a8ffd7f67  vmovaps [rsp+0x60], xmm6
0000781a8ffd7f6d  vmovaps [rsp+0x70], xmm7
0000781a8ffd7f73  vmovaps [rsp+0x80], xmm8
0000781a8ffd7f7c  vmovaps [rsp+0x90], xmm9
0000781a8ffd7f85  vmovaps [rsp+0xA0], xmm11
0000781a8ffd7f8e  vmovaps [rsp+0xB0], xmm12
0000781a8ffd7f97  vmovaps [rsp+0xC0], xmm13
0000781a8ffd7fa0  vmovaps [rsp+0xD0], xmm14
0000781a8ffd7fa9  vmovaps [rsp+0xE0], xmm15
0000781a8ffd7fb2  sub rsp, 0x40
0000781a8ffd7fb6  lea rdi, [rsp]
0000781a8ffd7fba  lea rsi, [rsp+0x10]
0000781a8ffd7fbf  lea rdx, [rsp+0x20]
0000781a8ffd7fc4  lea rcx, [rsp+0x30]
0000781a8ffd7fc9  mov r8d, 0x00
0000781a8ffd7fcf  lea r9, [r15+0x3A8]
0000781a8ffd7fd6  movaps [rdi], xmm10
0000781a8ffd7fda  movaps [rsi], xmm9
0000781a8ffd7fde  movaps [rdx], xmm7
0000781a8ffd7fe1  movaps [rcx], xmm14
0000781a8ffd7fe5  mov rax, 0x627DDC279A50
0000781a8ffd7fef  call rax
0000781a8ffd7ff1  movaps xmm10, [rsp]
0000781a8ffd7ff6  add rsp, 0x40
0000781a8ffd7ffa  vmovaps xmm0, [rsp]
0000781a8ffd7fff  vmovaps xmm1, [rsp+0x10]
0000781a8ffd8005  vmovaps xmm2, [rsp+0x20]
0000781a8ffd800b  vmovaps xmm3, [rsp+0x30]
0000781a8ffd8011  vmovaps xmm4, [rsp+0x40]
0000781a8ffd8017  vmovaps xmm5, [rsp+0x50]
0000781a8ffd801d  vmovaps xmm6, [rsp+0x60]
0000781a8ffd8023  vmovaps xmm7, [rsp+0x70]
0000781a8ffd8029  vmovaps xmm8, [rsp+0x80]
0000781a8ffd8032  vmovaps xmm9, [rsp+0x90]
0000781a8ffd803b  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd8044  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd804d  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd8056  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd805f  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd8068  add rsp, 0xF0
0000781a8ffd806f  pop r11
0000781a8ffd8071  pop r10
0000781a8ffd8073  pop r9
0000781a8ffd8075  pop r8
0000781a8ffd8077  pop rsi
0000781a8ffd8078  pop rdi
0000781a8ffd8079  pop rdx
0000781a8ffd807a  pop rcx
0000781a8ffd807b  pop rax
0000781a8ffd807c  add rsp, 0x08
0000781a8ffd8080  jmp 0x0000781A8FFD68F1
0000781a8ffd8085  call 0x0000781A8FEE45A0
0000781a8ffd808a  jmp 0x0000781A8FFD68FE
0000781a8ffd808f  sub rsp, 0x08
0000781a8ffd8093  push rax
0000781a8ffd8094  push rcx
0000781a8ffd8095  push rdx
0000781a8ffd8096  push rdi
0000781a8ffd8097  push rsi
0000781a8ffd8098  push r8
0000781a8ffd809a  push r9
0000781a8ffd809c  push r10
0000781a8ffd809e  push r11
0000781a8ffd80a0  sub rsp, 0xF0
0000781a8ffd80a7  vmovaps [rsp], xmm0
0000781a8ffd80ac  vmovaps [rsp+0x10], xmm1
0000781a8ffd80b2  vmovaps [rsp+0x20], xmm2
0000781a8ffd80b8  vmovaps [rsp+0x30], xmm3
0000781a8ffd80be  vmovaps [rsp+0x40], xmm4
0000781a8ffd80c4  vmovaps [rsp+0x50], xmm6
0000781a8ffd80ca  vmovaps [rsp+0x60], xmm7
0000781a8ffd80d0  vmovaps [rsp+0x70], xmm8
0000781a8ffd80d6  vmovaps [rsp+0x80], xmm9
0000781a8ffd80df  vmovaps [rsp+0x90], xmm10
0000781a8ffd80e8  vmovaps [rsp+0xA0], xmm11
0000781a8ffd80f1  vmovaps [rsp+0xB0], xmm12
0000781a8ffd80fa  vmovaps [rsp+0xC0], xmm13
0000781a8ffd8103  vmovaps [rsp+0xD0], xmm14
0000781a8ffd810c  vmovaps [rsp+0xE0], xmm15
0000781a8ffd8115  sub rsp, 0x40
0000781a8ffd8119  lea rdi, [rsp]
0000781a8ffd811d  lea rsi, [rsp+0x10]
0000781a8ffd8122  lea rdx, [rsp+0x20]
0000781a8ffd8127  lea rcx, [rsp+0x30]
0000781a8ffd812c  mov r8d, 0x00
0000781a8ffd8132  lea r9, [r15+0x3A8]
0000781a8ffd8139  movaps [rdi], xmm5
0000781a8ffd813c  movaps [rsi], xmm6
0000781a8ffd813f  movaps [rdx], xmm7
0000781a8ffd8142  movaps [rcx], xmm9
0000781a8ffd8146  mov rax, 0x627DDC279A50
0000781a8ffd8150  call rax
0000781a8ffd8152  movaps xmm5, [rsp]
0000781a8ffd8156  add rsp, 0x40
0000781a8ffd815a  vmovaps xmm0, [rsp]
0000781a8ffd815f  vmovaps xmm1, [rsp+0x10]
0000781a8ffd8165  vmovaps xmm2, [rsp+0x20]
0000781a8ffd816b  vmovaps xmm3, [rsp+0x30]
0000781a8ffd8171  vmovaps xmm4, [rsp+0x40]
0000781a8ffd8177  vmovaps xmm6, [rsp+0x50]
0000781a8ffd817d  vmovaps xmm7, [rsp+0x60]
0000781a8ffd8183  vmovaps xmm8, [rsp+0x70]
0000781a8ffd8189  vmovaps xmm9, [rsp+0x80]
0000781a8ffd8192  vmovaps xmm10, [rsp+0x90]
0000781a8ffd819b  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd81a4  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd81ad  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd81b6  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd81bf  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd81c8  add rsp, 0xF0
0000781a8ffd81cf  pop r11
0000781a8ffd81d1  pop r10
0000781a8ffd81d3  pop r9
0000781a8ffd81d5  pop r8
0000781a8ffd81d7  pop rsi
0000781a8ffd81d8  pop rdi
0000781a8ffd81d9  pop rdx
0000781a8ffd81da  pop rcx
0000781a8ffd81db  pop rax
0000781a8ffd81dc  add rsp, 0x08
0000781a8ffd81e0  jmp 0x0000781A8FFD6930
0000781a8ffd81e5  sub rsp, 0x08
0000781a8ffd81e9  push rax
0000781a8ffd81ea  push rcx
0000781a8ffd81eb  push rdx
0000781a8ffd81ec  push rdi
0000781a8ffd81ed  push rsi
0000781a8ffd81ee  push r8
0000781a8ffd81f0  push r9
0000781a8ffd81f2  push r10
0000781a8ffd81f4  push r11
0000781a8ffd81f6  sub rsp, 0xF0
0000781a8ffd81fd  vmovaps [rsp], xmm0
0000781a8ffd8202  vmovaps [rsp+0x10], xmm1
0000781a8ffd8208  vmovaps [rsp+0x20], xmm2
0000781a8ffd820e  vmovaps [rsp+0x30], xmm3
0000781a8ffd8214  vmovaps [rsp+0x40], xmm4
0000781a8ffd821a  vmovaps [rsp+0x50], xmm5
0000781a8ffd8220  vmovaps [rsp+0x60], xmm6
0000781a8ffd8226  vmovaps [rsp+0x70], xmm8
0000781a8ffd822c  vmovaps [rsp+0x80], xmm9
0000781a8ffd8235  vmovaps [rsp+0x90], xmm10
0000781a8ffd823e  vmovaps [rsp+0xA0], xmm11
0000781a8ffd8247  vmovaps [rsp+0xB0], xmm12
0000781a8ffd8250  vmovaps [rsp+0xC0], xmm13
0000781a8ffd8259  vmovaps [rsp+0xD0], xmm14
0000781a8ffd8262  vmovaps [rsp+0xE0], xmm15
0000781a8ffd826b  sub rsp, 0x40
0000781a8ffd826f  lea rdi, [rsp]
0000781a8ffd8273  lea rsi, [rsp+0x10]
0000781a8ffd8278  lea rdx, [rsp+0x20]
0000781a8ffd827d  lea rcx, [rsp+0x30]
0000781a8ffd8282  mov r8d, 0x00
0000781a8ffd8288  lea r9, [r15+0x3A8]
0000781a8ffd828f  movaps [rdi], xmm7
0000781a8ffd8292  movaps [rsi], xmm13
0000781a8ffd8296  movaps [rdx], xmm1
0000781a8ffd8299  movaps [rcx], xmm9
0000781a8ffd829d  mov rax, 0x627DDC279A50
0000781a8ffd82a7  call rax
0000781a8ffd82a9  movaps xmm7, [rsp]
0000781a8ffd82ad  add rsp, 0x40
0000781a8ffd82b1  vmovaps xmm0, [rsp]
0000781a8ffd82b6  vmovaps xmm1, [rsp+0x10]
0000781a8ffd82bc  vmovaps xmm2, [rsp+0x20]
0000781a8ffd82c2  vmovaps xmm3, [rsp+0x30]
0000781a8ffd82c8  vmovaps xmm4, [rsp+0x40]
0000781a8ffd82ce  vmovaps xmm5, [rsp+0x50]
0000781a8ffd82d4  vmovaps xmm6, [rsp+0x60]
0000781a8ffd82da  vmovaps xmm8, [rsp+0x70]
0000781a8ffd82e0  vmovaps xmm9, [rsp+0x80]
0000781a8ffd82e9  vmovaps xmm10, [rsp+0x90]
0000781a8ffd82f2  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd82fb  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd8304  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd830d  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd8316  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd831f  add rsp, 0xF0
0000781a8ffd8326  pop r11
0000781a8ffd8328  pop r10
0000781a8ffd832a  pop r9
0000781a8ffd832c  pop r8
0000781a8ffd832e  pop rsi
0000781a8ffd832f  pop rdi
0000781a8ffd8330  pop rdx
0000781a8ffd8331  pop rcx
0000781a8ffd8332  pop rax
0000781a8ffd8333  add rsp, 0x08
0000781a8ffd8337  jmp 0x0000781A8FFD6955
0000781a8ffd833c  call 0x0000781A8FEE3320
0000781a8ffd8341  jmp 0x0000781A8FFD6978
0000781a8ffd8346  call 0x0000781A8FEDE950
0000781a8ffd834b  jmp 0x0000781A8FFD6982
0000781a8ffd8350  sub rsp, 0x08
0000781a8ffd8354  push rax
0000781a8ffd8355  push rcx
0000781a8ffd8356  push rdx
0000781a8ffd8357  push rdi
0000781a8ffd8358  push rsi
0000781a8ffd8359  push r8
0000781a8ffd835b  push r9
0000781a8ffd835d  push r10
0000781a8ffd835f  push r11
0000781a8ffd8361  sub rsp, 0xF0
0000781a8ffd8368  vmovaps [rsp], xmm0
0000781a8ffd836d  vmovaps [rsp+0x10], xmm1
0000781a8ffd8373  vmovaps [rsp+0x20], xmm3
0000781a8ffd8379  vmovaps [rsp+0x30], xmm4
0000781a8ffd837f  vmovaps [rsp+0x40], xmm5
0000781a8ffd8385  vmovaps [rsp+0x50], xmm6
0000781a8ffd838b  vmovaps [rsp+0x60], xmm7
0000781a8ffd8391  vmovaps [rsp+0x70], xmm8
0000781a8ffd8397  vmovaps [rsp+0x80], xmm9
0000781a8ffd83a0  vmovaps [rsp+0x90], xmm10
0000781a8ffd83a9  vmovaps [rsp+0xA0], xmm11
0000781a8ffd83b2  vmovaps [rsp+0xB0], xmm12
0000781a8ffd83bb  vmovaps [rsp+0xC0], xmm13
0000781a8ffd83c4  vmovaps [rsp+0xD0], xmm14
0000781a8ffd83cd  vmovaps [rsp+0xE0], xmm15
0000781a8ffd83d6  sub rsp, 0x40
0000781a8ffd83da  lea rdi, [rsp]
0000781a8ffd83de  lea rsi, [rsp+0x10]
0000781a8ffd83e3  lea rdx, [rsp+0x20]
0000781a8ffd83e8  lea rcx, [rsp+0x30]
0000781a8ffd83ed  mov r8d, 0x00
0000781a8ffd83f3  lea r9, [r15+0x3A8]
0000781a8ffd83fa  movaps [rdi], xmm2
0000781a8ffd83fd  movaps [rsi], xmm12
0000781a8ffd8401  movaps [rdx], xmm6
0000781a8ffd8404  movaps [rcx], xmm3
0000781a8ffd8407  mov rax, 0x627DDC279A50
0000781a8ffd8411  call rax
0000781a8ffd8413  movaps xmm2, [rsp]
0000781a8ffd8417  add rsp, 0x40
0000781a8ffd841b  vmovaps xmm0, [rsp]
0000781a8ffd8420  vmovaps xmm1, [rsp+0x10]
0000781a8ffd8426  vmovaps xmm3, [rsp+0x20]
0000781a8ffd842c  vmovaps xmm4, [rsp+0x30]
0000781a8ffd8432  vmovaps xmm5, [rsp+0x40]
0000781a8ffd8438  vmovaps xmm6, [rsp+0x50]
0000781a8ffd843e  vmovaps xmm7, [rsp+0x60]
0000781a8ffd8444  vmovaps xmm8, [rsp+0x70]
0000781a8ffd844a  vmovaps xmm9, [rsp+0x80]
0000781a8ffd8453  vmovaps xmm10, [rsp+0x90]
0000781a8ffd845c  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd8465  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd846e  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd8477  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd8480  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd8489  add rsp, 0xF0
0000781a8ffd8490  pop r11
0000781a8ffd8492  pop r10
0000781a8ffd8494  pop r9
0000781a8ffd8496  pop r8
0000781a8ffd8498  pop rsi
0000781a8ffd8499  pop rdi
0000781a8ffd849a  pop rdx
0000781a8ffd849b  pop rcx
0000781a8ffd849c  pop rax
0000781a8ffd849d  add rsp, 0x08
0000781a8ffd84a1  jmp 0x0000781A8FFD69C8
0000781a8ffd84a6  sub rsp, 0x08
0000781a8ffd84aa  push rax
0000781a8ffd84ab  push rcx
0000781a8ffd84ac  push rdx
0000781a8ffd84ad  push rdi
0000781a8ffd84ae  push rsi
0000781a8ffd84af  push r8
0000781a8ffd84b1  push r9
0000781a8ffd84b3  push r10
0000781a8ffd84b5  push r11
0000781a8ffd84b7  sub rsp, 0xF0
0000781a8ffd84be  vmovaps [rsp], xmm0
0000781a8ffd84c3  vmovaps [rsp+0x10], xmm1
0000781a8ffd84c9  vmovaps [rsp+0x20], xmm2
0000781a8ffd84cf  vmovaps [rsp+0x30], xmm3
0000781a8ffd84d5  vmovaps [rsp+0x40], xmm4
0000781a8ffd84db  vmovaps [rsp+0x50], xmm5
0000781a8ffd84e1  vmovaps [rsp+0x60], xmm7
0000781a8ffd84e7  vmovaps [rsp+0x70], xmm8
0000781a8ffd84ed  vmovaps [rsp+0x80], xmm9
0000781a8ffd84f6  vmovaps [rsp+0x90], xmm10
0000781a8ffd84ff  vmovaps [rsp+0xA0], xmm11
0000781a8ffd8508  vmovaps [rsp+0xB0], xmm12
0000781a8ffd8511  vmovaps [rsp+0xC0], xmm13
0000781a8ffd851a  vmovaps [rsp+0xD0], xmm14
0000781a8ffd8523  vmovaps [rsp+0xE0], xmm15
0000781a8ffd852c  sub rsp, 0x40
0000781a8ffd8530  lea rdi, [rsp]
0000781a8ffd8534  lea rsi, [rsp+0x10]
0000781a8ffd8539  lea rdx, [rsp+0x20]
0000781a8ffd853e  lea rcx, [rsp+0x30]
0000781a8ffd8543  mov r8d, 0x00
0000781a8ffd8549  lea r9, [r15+0x3A8]
0000781a8ffd8550  movaps [rdi], xmm6
0000781a8ffd8553  movaps [rsi], xmm10
0000781a8ffd8557  movaps [rdx], xmm12
0000781a8ffd855b  movaps [rcx], xmm1
0000781a8ffd855e  mov rax, 0x627DDC279A50
0000781a8ffd8568  call rax
0000781a8ffd856a  movaps xmm6, [rsp]
0000781a8ffd856e  add rsp, 0x40
0000781a8ffd8572  vmovaps xmm0, [rsp]
0000781a8ffd8577  vmovaps xmm1, [rsp+0x10]
0000781a8ffd857d  vmovaps xmm2, [rsp+0x20]
0000781a8ffd8583  vmovaps xmm3, [rsp+0x30]
0000781a8ffd8589  vmovaps xmm4, [rsp+0x40]
0000781a8ffd858f  vmovaps xmm5, [rsp+0x50]
0000781a8ffd8595  vmovaps xmm7, [rsp+0x60]
0000781a8ffd859b  vmovaps xmm8, [rsp+0x70]
0000781a8ffd85a1  vmovaps xmm9, [rsp+0x80]
0000781a8ffd85aa  vmovaps xmm10, [rsp+0x90]
0000781a8ffd85b3  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd85bc  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd85c5  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd85ce  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd85d7  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd85e0  add rsp, 0xF0
0000781a8ffd85e7  pop r11
0000781a8ffd85e9  pop r10
0000781a8ffd85eb  pop r9
0000781a8ffd85ed  pop r8
0000781a8ffd85ef  pop rsi
0000781a8ffd85f0  pop rdi
0000781a8ffd85f1  pop rdx
0000781a8ffd85f2  pop rcx
0000781a8ffd85f3  pop rax
0000781a8ffd85f4  add rsp, 0x08
0000781a8ffd85f8  jmp 0x0000781A8FFD69F6
0000781a8ffd85fd  sub rsp, 0x08
0000781a8ffd8601  push rax
0000781a8ffd8602  push rcx
0000781a8ffd8603  push rdx
0000781a8ffd8604  push rdi
0000781a8ffd8605  push rsi
0000781a8ffd8606  push r8
0000781a8ffd8608  push r9
0000781a8ffd860a  push r10
0000781a8ffd860c  push r11
0000781a8ffd860e  sub rsp, 0xF0
0000781a8ffd8615  vmovaps [rsp], xmm0
0000781a8ffd861a  vmovaps [rsp+0x10], xmm1
0000781a8ffd8620  vmovaps [rsp+0x20], xmm2
0000781a8ffd8626  vmovaps [rsp+0x30], xmm3
0000781a8ffd862c  vmovaps [rsp+0x40], xmm4
0000781a8ffd8632  vmovaps [rsp+0x50], xmm5
0000781a8ffd8638  vmovaps [rsp+0x60], xmm6
0000781a8ffd863e  vmovaps [rsp+0x70], xmm7
0000781a8ffd8644  vmovaps [rsp+0x80], xmm8
0000781a8ffd864d  vmovaps [rsp+0x90], xmm9
0000781a8ffd8656  vmovaps [rsp+0xA0], xmm11
0000781a8ffd865f  vmovaps [rsp+0xB0], xmm12
0000781a8ffd8668  vmovaps [rsp+0xC0], xmm13
0000781a8ffd8671  vmovaps [rsp+0xD0], xmm14
0000781a8ffd867a  vmovaps [rsp+0xE0], xmm15
0000781a8ffd8683  sub rsp, 0x40
0000781a8ffd8687  lea rdi, [rsp]
0000781a8ffd868b  lea rsi, [rsp+0x10]
0000781a8ffd8690  lea rdx, [rsp+0x20]
0000781a8ffd8695  lea rcx, [rsp+0x30]
0000781a8ffd869a  mov r8d, 0x00
0000781a8ffd86a0  lea r9, [r15+0x3A8]
0000781a8ffd86a7  movaps [rdi], xmm10
0000781a8ffd86ab  movaps [rsi], xmm5
0000781a8ffd86ae  movaps [rdx], xmm12
0000781a8ffd86b2  movaps [rcx], xmm1
0000781a8ffd86b5  mov rax, 0x627DDC279A50
0000781a8ffd86bf  call rax
0000781a8ffd86c1  movaps xmm10, [rsp]
0000781a8ffd86c6  add rsp, 0x40
0000781a8ffd86ca  vmovaps xmm0, [rsp]
0000781a8ffd86cf  vmovaps xmm1, [rsp+0x10]
0000781a8ffd86d5  vmovaps xmm2, [rsp+0x20]
0000781a8ffd86db  vmovaps xmm3, [rsp+0x30]
0000781a8ffd86e1  vmovaps xmm4, [rsp+0x40]
0000781a8ffd86e7  vmovaps xmm5, [rsp+0x50]
0000781a8ffd86ed  vmovaps xmm6, [rsp+0x60]
0000781a8ffd86f3  vmovaps xmm7, [rsp+0x70]
0000781a8ffd86f9  vmovaps xmm8, [rsp+0x80]
0000781a8ffd8702  vmovaps xmm9, [rsp+0x90]
0000781a8ffd870b  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd8714  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd871d  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd8726  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd872f  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd8738  add rsp, 0xF0
0000781a8ffd873f  pop r11
0000781a8ffd8741  pop r10
0000781a8ffd8743  pop r9
0000781a8ffd8745  pop r8
0000781a8ffd8747  pop rsi
0000781a8ffd8748  pop rdi
0000781a8ffd8749  pop rdx
0000781a8ffd874a  pop rcx
0000781a8ffd874b  pop rax
0000781a8ffd874c  add rsp, 0x08
0000781a8ffd8750  jmp 0x0000781A8FFD6A25
0000781a8ffd8755  sub rsp, 0x08
0000781a8ffd8759  push rax
0000781a8ffd875a  push rcx
0000781a8ffd875b  push rdx
0000781a8ffd875c  push rdi
0000781a8ffd875d  push rsi
0000781a8ffd875e  push r8
0000781a8ffd8760  push r9
0000781a8ffd8762  push r10
0000781a8ffd8764  push r11
0000781a8ffd8766  sub rsp, 0xF0
0000781a8ffd876d  vmovaps [rsp], xmm0
0000781a8ffd8772  vmovaps [rsp+0x10], xmm1
0000781a8ffd8778  vmovaps [rsp+0x20], xmm2
0000781a8ffd877e  vmovaps [rsp+0x30], xmm3
0000781a8ffd8784  vmovaps [rsp+0x40], xmm4
0000781a8ffd878a  vmovaps [rsp+0x50], xmm5
0000781a8ffd8790  vmovaps [rsp+0x60], xmm6
0000781a8ffd8796  vmovaps [rsp+0x70], xmm7
0000781a8ffd879c  vmovaps [rsp+0x80], xmm8
0000781a8ffd87a5  vmovaps [rsp+0x90], xmm9
0000781a8ffd87ae  vmovaps [rsp+0xA0], xmm10
0000781a8ffd87b7  vmovaps [rsp+0xB0], xmm11
0000781a8ffd87c0  vmovaps [rsp+0xC0], xmm13
0000781a8ffd87c9  vmovaps [rsp+0xD0], xmm14
0000781a8ffd87d2  vmovaps [rsp+0xE0], xmm15
0000781a8ffd87db  sub rsp, 0x40
0000781a8ffd87df  lea rdi, [rsp]
0000781a8ffd87e3  lea rsi, [rsp+0x10]
0000781a8ffd87e8  lea rdx, [rsp+0x20]
0000781a8ffd87ed  lea rcx, [rsp+0x30]
0000781a8ffd87f2  mov r8d, 0x00
0000781a8ffd87f8  lea r9, [r15+0x3A8]
0000781a8ffd87ff  movaps [rdi], xmm12
0000781a8ffd8803  movaps [rsi], xmm7
0000781a8ffd8806  movaps [rdx], xmm15
0000781a8ffd880a  movaps [rcx], xmm1
0000781a8ffd880d  mov rax, 0x627DDC279A50
0000781a8ffd8817  call rax
0000781a8ffd8819  movaps xmm12, [rsp]
0000781a8ffd881e  add rsp, 0x40
0000781a8ffd8822  vmovaps xmm0, [rsp]
0000781a8ffd8827  vmovaps xmm1, [rsp+0x10]
0000781a8ffd882d  vmovaps xmm2, [rsp+0x20]
0000781a8ffd8833  vmovaps xmm3, [rsp+0x30]
0000781a8ffd8839  vmovaps xmm4, [rsp+0x40]
0000781a8ffd883f  vmovaps xmm5, [rsp+0x50]
0000781a8ffd8845  vmovaps xmm6, [rsp+0x60]
0000781a8ffd884b  vmovaps xmm7, [rsp+0x70]
0000781a8ffd8851  vmovaps xmm8, [rsp+0x80]
0000781a8ffd885a  vmovaps xmm9, [rsp+0x90]
0000781a8ffd8863  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd886c  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd8875  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd887e  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd8887  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd8890  add rsp, 0xF0
0000781a8ffd8897  pop r11
0000781a8ffd8899  pop r10
0000781a8ffd889b  pop r9
0000781a8ffd889d  pop r8
0000781a8ffd889f  pop rsi
0000781a8ffd88a0  pop rdi
0000781a8ffd88a1  pop rdx
0000781a8ffd88a2  pop rcx
0000781a8ffd88a3  pop rax
0000781a8ffd88a4  add rsp, 0x08
0000781a8ffd88a8  jmp 0x0000781A8FFD6A4E
0000781a8ffd88ad  call 0x0000781A8FED64F0
0000781a8ffd88b2  jmp 0x0000781A8FFD6A58
0000781a8ffd88b7  call 0x0000781A8FEE5820
0000781a8ffd88bc  jmp 0x0000781A8FFD6A62
0000781a8ffd88c1  sub rsp, 0x08
0000781a8ffd88c5  push rax
0000781a8ffd88c6  push rcx
0000781a8ffd88c7  push rdx
0000781a8ffd88c8  push rdi
0000781a8ffd88c9  push rsi
0000781a8ffd88ca  push r8
0000781a8ffd88cc  push r9
0000781a8ffd88ce  push r10
0000781a8ffd88d0  push r11
0000781a8ffd88d2  sub rsp, 0xF0
0000781a8ffd88d9  vmovaps [rsp], xmm0
0000781a8ffd88de  vmovaps [rsp+0x10], xmm1
0000781a8ffd88e4  vmovaps [rsp+0x20], xmm2
0000781a8ffd88ea  vmovaps [rsp+0x30], xmm3
0000781a8ffd88f0  vmovaps [rsp+0x40], xmm4
0000781a8ffd88f6  vmovaps [rsp+0x50], xmm5
0000781a8ffd88fc  vmovaps [rsp+0x60], xmm6
0000781a8ffd8902  vmovaps [rsp+0x70], xmm8
0000781a8ffd8908  vmovaps [rsp+0x80], xmm9
0000781a8ffd8911  vmovaps [rsp+0x90], xmm10
0000781a8ffd891a  vmovaps [rsp+0xA0], xmm11
0000781a8ffd8923  vmovaps [rsp+0xB0], xmm12
0000781a8ffd892c  vmovaps [rsp+0xC0], xmm13
0000781a8ffd8935  vmovaps [rsp+0xD0], xmm14
0000781a8ffd893e  vmovaps [rsp+0xE0], xmm15
0000781a8ffd8947  sub rsp, 0x40
0000781a8ffd894b  lea rdi, [rsp]
0000781a8ffd894f  lea rsi, [rsp+0x10]
0000781a8ffd8954  lea rdx, [rsp+0x20]
0000781a8ffd8959  lea rcx, [rsp+0x30]
0000781a8ffd895e  mov r8d, 0x00
0000781a8ffd8964  lea r9, [r15+0x3A8]
0000781a8ffd896b  movaps [rdi], xmm7
0000781a8ffd896e  movaps [rsi], xmm2
0000781a8ffd8971  movaps [rdx], xmm9
0000781a8ffd8975  movaps [rcx], xmm11
0000781a8ffd8979  mov rax, 0x627DDC279A50
0000781a8ffd8983  call rax
0000781a8ffd8985  movaps xmm7, [rsp]
0000781a8ffd8989  add rsp, 0x40
0000781a8ffd898d  vmovaps xmm0, [rsp]
0000781a8ffd8992  vmovaps xmm1, [rsp+0x10]
0000781a8ffd8998  vmovaps xmm2, [rsp+0x20]
0000781a8ffd899e  vmovaps xmm3, [rsp+0x30]
0000781a8ffd89a4  vmovaps xmm4, [rsp+0x40]
0000781a8ffd89aa  vmovaps xmm5, [rsp+0x50]
0000781a8ffd89b0  vmovaps xmm6, [rsp+0x60]
0000781a8ffd89b6  vmovaps xmm8, [rsp+0x70]
0000781a8ffd89bc  vmovaps xmm9, [rsp+0x80]
0000781a8ffd89c5  vmovaps xmm10, [rsp+0x90]
0000781a8ffd89ce  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd89d7  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd89e0  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd89e9  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd89f2  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd89fb  add rsp, 0xF0
0000781a8ffd8a02  pop r11
0000781a8ffd8a04  pop r10
0000781a8ffd8a06  pop r9
0000781a8ffd8a08  pop r8
0000781a8ffd8a0a  pop rsi
0000781a8ffd8a0b  pop rdi
0000781a8ffd8a0c  pop rdx
0000781a8ffd8a0d  pop rcx
0000781a8ffd8a0e  pop rax
0000781a8ffd8a0f  add rsp, 0x08
0000781a8ffd8a13  jmp 0x0000781A8FFD6A96
0000781a8ffd8a18  sub rsp, 0x08
0000781a8ffd8a1c  push rax
0000781a8ffd8a1d  push rcx
0000781a8ffd8a1e  push rdx
0000781a8ffd8a1f  push rdi
0000781a8ffd8a20  push rsi
0000781a8ffd8a21  push r8
0000781a8ffd8a23  push r9
0000781a8ffd8a25  push r10
0000781a8ffd8a27  push r11
0000781a8ffd8a29  sub rsp, 0xF0
0000781a8ffd8a30  vmovaps [rsp], xmm0
0000781a8ffd8a35  vmovaps [rsp+0x10], xmm1
0000781a8ffd8a3b  vmovaps [rsp+0x20], xmm2
0000781a8ffd8a41  vmovaps [rsp+0x30], xmm3
0000781a8ffd8a47  vmovaps [rsp+0x40], xmm4
0000781a8ffd8a4d  vmovaps [rsp+0x50], xmm5
0000781a8ffd8a53  vmovaps [rsp+0x60], xmm6
0000781a8ffd8a59  vmovaps [rsp+0x70], xmm7
0000781a8ffd8a5f  vmovaps [rsp+0x80], xmm8
0000781a8ffd8a68  vmovaps [rsp+0x90], xmm10
0000781a8ffd8a71  vmovaps [rsp+0xA0], xmm11
0000781a8ffd8a7a  vmovaps [rsp+0xB0], xmm12
0000781a8ffd8a83  vmovaps [rsp+0xC0], xmm13
0000781a8ffd8a8c  vmovaps [rsp+0xD0], xmm14
0000781a8ffd8a95  vmovaps [rsp+0xE0], xmm15
0000781a8ffd8a9e  sub rsp, 0x40
0000781a8ffd8aa2  lea rdi, [rsp]
0000781a8ffd8aa6  lea rsi, [rsp+0x10]
0000781a8ffd8aab  lea rdx, [rsp+0x20]
0000781a8ffd8ab0  lea rcx, [rsp+0x30]
0000781a8ffd8ab5  mov r8d, 0x00
0000781a8ffd8abb  lea r9, [r15+0x3A8]
0000781a8ffd8ac2  movaps [rdi], xmm9
0000781a8ffd8ac6  movaps [rsi], xmm6
0000781a8ffd8ac9  movaps [rdx], xmm1
0000781a8ffd8acc  movaps [rcx], xmm11
0000781a8ffd8ad0  mov rax, 0x627DDC279A50
0000781a8ffd8ada  call rax
0000781a8ffd8adc  movaps xmm9, [rsp]
0000781a8ffd8ae1  add rsp, 0x40
0000781a8ffd8ae5  vmovaps xmm0, [rsp]
0000781a8ffd8aea  vmovaps xmm1, [rsp+0x10]
0000781a8ffd8af0  vmovaps xmm2, [rsp+0x20]
0000781a8ffd8af6  vmovaps xmm3, [rsp+0x30]
0000781a8ffd8afc  vmovaps xmm4, [rsp+0x40]
0000781a8ffd8b02  vmovaps xmm5, [rsp+0x50]
0000781a8ffd8b08  vmovaps xmm6, [rsp+0x60]
0000781a8ffd8b0e  vmovaps xmm7, [rsp+0x70]
0000781a8ffd8b14  vmovaps xmm8, [rsp+0x80]
0000781a8ffd8b1d  vmovaps xmm10, [rsp+0x90]
0000781a8ffd8b26  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd8b2f  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd8b38  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd8b41  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd8b4a  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd8b53  add rsp, 0xF0
0000781a8ffd8b5a  pop r11
0000781a8ffd8b5c  pop r10
0000781a8ffd8b5e  pop r9
0000781a8ffd8b60  pop r8
0000781a8ffd8b62  pop rsi
0000781a8ffd8b63  pop rdi
0000781a8ffd8b64  pop rdx
0000781a8ffd8b65  pop rcx
0000781a8ffd8b66  pop rax
0000781a8ffd8b67  add rsp, 0x08
0000781a8ffd8b6b  jmp 0x0000781A8FFD6ABC
0000781a8ffd8b70  sub rsp, 0x08
0000781a8ffd8b74  push rax
0000781a8ffd8b75  push rcx
0000781a8ffd8b76  push rdx
0000781a8ffd8b77  push rdi
0000781a8ffd8b78  push rsi
0000781a8ffd8b79  push r8
0000781a8ffd8b7b  push r9
0000781a8ffd8b7d  push r10
0000781a8ffd8b7f  push r11
0000781a8ffd8b81  sub rsp, 0xF0
0000781a8ffd8b88  vmovaps [rsp], xmm0
0000781a8ffd8b8d  vmovaps [rsp+0x10], xmm1
0000781a8ffd8b93  vmovaps [rsp+0x20], xmm2
0000781a8ffd8b99  vmovaps [rsp+0x30], xmm3
0000781a8ffd8b9f  vmovaps [rsp+0x40], xmm4
0000781a8ffd8ba5  vmovaps [rsp+0x50], xmm5
0000781a8ffd8bab  vmovaps [rsp+0x60], xmm6
0000781a8ffd8bb1  vmovaps [rsp+0x70], xmm7
0000781a8ffd8bb7  vmovaps [rsp+0x80], xmm8
0000781a8ffd8bc0  vmovaps [rsp+0x90], xmm9
0000781a8ffd8bc9  vmovaps [rsp+0xA0], xmm10
0000781a8ffd8bd2  vmovaps [rsp+0xB0], xmm12
0000781a8ffd8bdb  vmovaps [rsp+0xC0], xmm13
0000781a8ffd8be4  vmovaps [rsp+0xD0], xmm14
0000781a8ffd8bed  vmovaps [rsp+0xE0], xmm15
0000781a8ffd8bf6  sub rsp, 0x40
0000781a8ffd8bfa  lea rdi, [rsp]
0000781a8ffd8bfe  lea rsi, [rsp+0x10]
0000781a8ffd8c03  lea rdx, [rsp+0x20]
0000781a8ffd8c08  lea rcx, [rsp+0x30]
0000781a8ffd8c0d  mov r8d, 0x00
0000781a8ffd8c13  lea r9, [r15+0x3A8]
0000781a8ffd8c1a  movaps [rdi], xmm11
0000781a8ffd8c1e  movaps [rsi], xmm10
0000781a8ffd8c22  movaps [rdx], xmm8
0000781a8ffd8c26  movaps [rcx], xmm1
0000781a8ffd8c29  mov rax, 0x627DDC279A50
0000781a8ffd8c33  call rax
0000781a8ffd8c35  movaps xmm11, [rsp]
0000781a8ffd8c3a  add rsp, 0x40
0000781a8ffd8c3e  vmovaps xmm0, [rsp]
0000781a8ffd8c43  vmovaps xmm1, [rsp+0x10]
0000781a8ffd8c49  vmovaps xmm2, [rsp+0x20]
0000781a8ffd8c4f  vmovaps xmm3, [rsp+0x30]
0000781a8ffd8c55  vmovaps xmm4, [rsp+0x40]
0000781a8ffd8c5b  vmovaps xmm5, [rsp+0x50]
0000781a8ffd8c61  vmovaps xmm6, [rsp+0x60]
0000781a8ffd8c67  vmovaps xmm7, [rsp+0x70]
0000781a8ffd8c6d  vmovaps xmm8, [rsp+0x80]
0000781a8ffd8c76  vmovaps xmm9, [rsp+0x90]
0000781a8ffd8c7f  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd8c88  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd8c91  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd8c9a  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd8ca3  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd8cac  add rsp, 0xF0
0000781a8ffd8cb3  pop r11
0000781a8ffd8cb5  pop r10
0000781a8ffd8cb7  pop r9
0000781a8ffd8cb9  pop r8
0000781a8ffd8cbb  pop rsi
0000781a8ffd8cbc  pop rdi
0000781a8ffd8cbd  pop rdx
0000781a8ffd8cbe  pop rcx
0000781a8ffd8cbf  pop rax
0000781a8ffd8cc0  add rsp, 0x08
0000781a8ffd8cc4  jmp 0x0000781A8FFD6AE2
0000781a8ffd8cc9  sub rsp, 0x08
0000781a8ffd8ccd  push rax
0000781a8ffd8cce  push rcx
0000781a8ffd8ccf  push rdx
0000781a8ffd8cd0  push rdi
0000781a8ffd8cd1  push rsi
0000781a8ffd8cd2  push r8
0000781a8ffd8cd4  push r9
0000781a8ffd8cd6  push r10
0000781a8ffd8cd8  push r11
0000781a8ffd8cda  sub rsp, 0xF0
0000781a8ffd8ce1  vmovaps [rsp], xmm0
0000781a8ffd8ce6  vmovaps [rsp+0x10], xmm1
0000781a8ffd8cec  vmovaps [rsp+0x20], xmm2
0000781a8ffd8cf2  vmovaps [rsp+0x30], xmm3
0000781a8ffd8cf8  vmovaps [rsp+0x40], xmm4
0000781a8ffd8cfe  vmovaps [rsp+0x50], xmm5
0000781a8ffd8d04  vmovaps [rsp+0x60], xmm6
0000781a8ffd8d0a  vmovaps [rsp+0x70], xmm7
0000781a8ffd8d10  vmovaps [rsp+0x80], xmm8
0000781a8ffd8d19  vmovaps [rsp+0x90], xmm9
0000781a8ffd8d22  vmovaps [rsp+0xA0], xmm11
0000781a8ffd8d2b  vmovaps [rsp+0xB0], xmm12
0000781a8ffd8d34  vmovaps [rsp+0xC0], xmm13
0000781a8ffd8d3d  vmovaps [rsp+0xD0], xmm14
0000781a8ffd8d46  vmovaps [rsp+0xE0], xmm15
0000781a8ffd8d4f  sub rsp, 0x40
0000781a8ffd8d53  lea rdi, [rsp]
0000781a8ffd8d57  lea rsi, [rsp+0x10]
0000781a8ffd8d5c  lea rdx, [rsp+0x20]
0000781a8ffd8d61  lea rcx, [rsp+0x30]
0000781a8ffd8d66  mov r8d, 0x00
0000781a8ffd8d6c  lea r9, [r15+0x3A8]
0000781a8ffd8d73  movaps [rdi], xmm10
0000781a8ffd8d77  movaps [rsi], xmm12
0000781a8ffd8d7b  movaps [rdx], xmm13
0000781a8ffd8d7f  movaps [rcx], xmm1
0000781a8ffd8d82  mov rax, 0x627DDC279A50
0000781a8ffd8d8c  call rax
0000781a8ffd8d8e  movaps xmm10, [rsp]
0000781a8ffd8d93  add rsp, 0x40
0000781a8ffd8d97  vmovaps xmm0, [rsp]
0000781a8ffd8d9c  vmovaps xmm1, [rsp+0x10]
0000781a8ffd8da2  vmovaps xmm2, [rsp+0x20]
0000781a8ffd8da8  vmovaps xmm3, [rsp+0x30]
0000781a8ffd8dae  vmovaps xmm4, [rsp+0x40]
0000781a8ffd8db4  vmovaps xmm5, [rsp+0x50]
0000781a8ffd8dba  vmovaps xmm6, [rsp+0x60]
0000781a8ffd8dc0  vmovaps xmm7, [rsp+0x70]
0000781a8ffd8dc6  vmovaps xmm8, [rsp+0x80]
0000781a8ffd8dcf  vmovaps xmm9, [rsp+0x90]
0000781a8ffd8dd8  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd8de1  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd8dea  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd8df3  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd8dfc  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd8e05  add rsp, 0xF0
0000781a8ffd8e0c  pop r11
0000781a8ffd8e0e  pop r10
0000781a8ffd8e10  pop r9
0000781a8ffd8e12  pop r8
0000781a8ffd8e14  pop rsi
0000781a8ffd8e15  pop rdi
0000781a8ffd8e16  pop rdx
0000781a8ffd8e17  pop rcx
0000781a8ffd8e18  pop rax
0000781a8ffd8e19  add rsp, 0x08
0000781a8ffd8e1d  jmp 0x0000781A8FFD6B08
0000781a8ffd8e22  call 0x0000781A8FED64F0
0000781a8ffd8e27  jmp 0x0000781A8FFD6B12
0000781a8ffd8e2c  call 0x0000781A8FEE3320
0000781a8ffd8e31  jmp 0x0000781A8FFD6B1C
0000781a8ffd8e36  sub rsp, 0x08
0000781a8ffd8e3a  push rax
0000781a8ffd8e3b  push rcx
0000781a8ffd8e3c  push rdx
0000781a8ffd8e3d  push rdi
0000781a8ffd8e3e  push rsi
0000781a8ffd8e3f  push r8
0000781a8ffd8e41  push r9
0000781a8ffd8e43  push r10
0000781a8ffd8e45  push r11
0000781a8ffd8e47  sub rsp, 0xF0
0000781a8ffd8e4e  vmovaps [rsp], xmm0
0000781a8ffd8e53  vmovaps [rsp+0x10], xmm1
0000781a8ffd8e59  vmovaps [rsp+0x20], xmm2
0000781a8ffd8e5f  vmovaps [rsp+0x30], xmm3
0000781a8ffd8e65  vmovaps [rsp+0x40], xmm4
0000781a8ffd8e6b  vmovaps [rsp+0x50], xmm5
0000781a8ffd8e71  vmovaps [rsp+0x60], xmm6
0000781a8ffd8e77  vmovaps [rsp+0x70], xmm7
0000781a8ffd8e7d  vmovaps [rsp+0x80], xmm9
0000781a8ffd8e86  vmovaps [rsp+0x90], xmm10
0000781a8ffd8e8f  vmovaps [rsp+0xA0], xmm11
0000781a8ffd8e98  vmovaps [rsp+0xB0], xmm12
0000781a8ffd8ea1  vmovaps [rsp+0xC0], xmm13
0000781a8ffd8eaa  vmovaps [rsp+0xD0], xmm14
0000781a8ffd8eb3  vmovaps [rsp+0xE0], xmm15
0000781a8ffd8ebc  sub rsp, 0x40
0000781a8ffd8ec0  lea rdi, [rsp]
0000781a8ffd8ec4  lea rsi, [rsp+0x10]
0000781a8ffd8ec9  lea rdx, [rsp+0x20]
0000781a8ffd8ece  lea rcx, [rsp+0x30]
0000781a8ffd8ed3  mov r8d, 0x00
0000781a8ffd8ed9  lea r9, [r15+0x3A8]
0000781a8ffd8ee0  movaps [rdi], xmm8
0000781a8ffd8ee4  movaps [rsi], xmm7
0000781a8ffd8ee7  movaps [rdx], xmm4
0000781a8ffd8eea  movaps [rcx], xmm12
0000781a8ffd8eee  mov rax, 0x627DDC279A50
0000781a8ffd8ef8  call rax
0000781a8ffd8efa  movaps xmm8, [rsp]
0000781a8ffd8eff  add rsp, 0x40
0000781a8ffd8f03  vmovaps xmm0, [rsp]
0000781a8ffd8f08  vmovaps xmm1, [rsp+0x10]
0000781a8ffd8f0e  vmovaps xmm2, [rsp+0x20]
0000781a8ffd8f14  vmovaps xmm3, [rsp+0x30]
0000781a8ffd8f1a  vmovaps xmm4, [rsp+0x40]
0000781a8ffd8f20  vmovaps xmm5, [rsp+0x50]
0000781a8ffd8f26  vmovaps xmm6, [rsp+0x60]
0000781a8ffd8f2c  vmovaps xmm7, [rsp+0x70]
0000781a8ffd8f32  vmovaps xmm9, [rsp+0x80]
0000781a8ffd8f3b  vmovaps xmm10, [rsp+0x90]
0000781a8ffd8f44  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd8f4d  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd8f56  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd8f5f  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd8f68  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd8f71  add rsp, 0xF0
0000781a8ffd8f78  pop r11
0000781a8ffd8f7a  pop r10
0000781a8ffd8f7c  pop r9
0000781a8ffd8f7e  pop r8
0000781a8ffd8f80  pop rsi
0000781a8ffd8f81  pop rdi
0000781a8ffd8f82  pop rdx
0000781a8ffd8f83  pop rcx
0000781a8ffd8f84  pop rax
0000781a8ffd8f85  add rsp, 0x08
0000781a8ffd8f89  jmp 0x0000781A8FFD6B45
0000781a8ffd8f8e  sub rsp, 0x08
0000781a8ffd8f92  push rax
0000781a8ffd8f93  push rcx
0000781a8ffd8f94  push rdx
0000781a8ffd8f95  push rdi
0000781a8ffd8f96  push rsi
0000781a8ffd8f97  push r8
0000781a8ffd8f99  push r9
0000781a8ffd8f9b  push r10
0000781a8ffd8f9d  push r11
0000781a8ffd8f9f  sub rsp, 0xF0
0000781a8ffd8fa6  vmovaps [rsp], xmm0
0000781a8ffd8fab  vmovaps [rsp+0x10], xmm1
0000781a8ffd8fb1  vmovaps [rsp+0x20], xmm2
0000781a8ffd8fb7  vmovaps [rsp+0x30], xmm3
0000781a8ffd8fbd  vmovaps [rsp+0x40], xmm4
0000781a8ffd8fc3  vmovaps [rsp+0x50], xmm5
0000781a8ffd8fc9  vmovaps [rsp+0x60], xmm6
0000781a8ffd8fcf  vmovaps [rsp+0x70], xmm8
0000781a8ffd8fd5  vmovaps [rsp+0x80], xmm9
0000781a8ffd8fde  vmovaps [rsp+0x90], xmm10
0000781a8ffd8fe7  vmovaps [rsp+0xA0], xmm11
0000781a8ffd8ff0  vmovaps [rsp+0xB0], xmm12
0000781a8ffd8ff9  vmovaps [rsp+0xC0], xmm13
0000781a8ffd9002  vmovaps [rsp+0xD0], xmm14
0000781a8ffd900b  vmovaps [rsp+0xE0], xmm15
0000781a8ffd9014  sub rsp, 0x40
0000781a8ffd9018  lea rdi, [rsp]
0000781a8ffd901c  lea rsi, [rsp+0x10]
0000781a8ffd9021  lea rdx, [rsp+0x20]
0000781a8ffd9026  lea rcx, [rsp+0x30]
0000781a8ffd902b  mov r8d, 0x00
0000781a8ffd9031  lea r9, [r15+0x3A8]
0000781a8ffd9038  movaps [rdi], xmm7
0000781a8ffd903b  movaps [rsi], xmm9
0000781a8ffd903f  movaps [rdx], xmm14
0000781a8ffd9043  movaps [rcx], xmm12
0000781a8ffd9047  mov rax, 0x627DDC279A50
0000781a8ffd9051  call rax
0000781a8ffd9053  movaps xmm7, [rsp]
0000781a8ffd9057  add rsp, 0x40
0000781a8ffd905b  vmovaps xmm0, [rsp]
0000781a8ffd9060  vmovaps xmm1, [rsp+0x10]
0000781a8ffd9066  vmovaps xmm2, [rsp+0x20]
0000781a8ffd906c  vmovaps xmm3, [rsp+0x30]
0000781a8ffd9072  vmovaps xmm4, [rsp+0x40]
0000781a8ffd9078  vmovaps xmm5, [rsp+0x50]
0000781a8ffd907e  vmovaps xmm6, [rsp+0x60]
0000781a8ffd9084  vmovaps xmm8, [rsp+0x70]
0000781a8ffd908a  vmovaps xmm9, [rsp+0x80]
0000781a8ffd9093  vmovaps xmm10, [rsp+0x90]
0000781a8ffd909c  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd90a5  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd90ae  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd90b7  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd90c0  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd90c9  add rsp, 0xF0
0000781a8ffd90d0  pop r11
0000781a8ffd90d2  pop r10
0000781a8ffd90d4  pop r9
0000781a8ffd90d6  pop r8
0000781a8ffd90d8  pop rsi
0000781a8ffd90d9  pop rdi
0000781a8ffd90da  pop rdx
0000781a8ffd90db  pop rcx
0000781a8ffd90dc  pop rax
0000781a8ffd90dd  add rsp, 0x08
0000781a8ffd90e1  jmp 0x0000781A8FFD6B6D
0000781a8ffd90e6  sub rsp, 0x08
0000781a8ffd90ea  push rax
0000781a8ffd90eb  push rcx
0000781a8ffd90ec  push rdx
0000781a8ffd90ed  push rdi
0000781a8ffd90ee  push rsi
0000781a8ffd90ef  push r8
0000781a8ffd90f1  push r9
0000781a8ffd90f3  push r10
0000781a8ffd90f5  push r11
0000781a8ffd90f7  sub rsp, 0xF0
0000781a8ffd90fe  vmovaps [rsp], xmm0
0000781a8ffd9103  vmovaps [rsp+0x10], xmm1
0000781a8ffd9109  vmovaps [rsp+0x20], xmm2
0000781a8ffd910f  vmovaps [rsp+0x30], xmm3
0000781a8ffd9115  vmovaps [rsp+0x40], xmm4
0000781a8ffd911b  vmovaps [rsp+0x50], xmm5
0000781a8ffd9121  vmovaps [rsp+0x60], xmm6
0000781a8ffd9127  vmovaps [rsp+0x70], xmm7
0000781a8ffd912d  vmovaps [rsp+0x80], xmm8
0000781a8ffd9136  vmovaps [rsp+0x90], xmm9
0000781a8ffd913f  vmovaps [rsp+0xA0], xmm10
0000781a8ffd9148  vmovaps [rsp+0xB0], xmm11
0000781a8ffd9151  vmovaps [rsp+0xC0], xmm13
0000781a8ffd915a  vmovaps [rsp+0xD0], xmm14
0000781a8ffd9163  vmovaps [rsp+0xE0], xmm15
0000781a8ffd916c  sub rsp, 0x40
0000781a8ffd9170  lea rdi, [rsp]
0000781a8ffd9174  lea rsi, [rsp+0x10]
0000781a8ffd9179  lea rdx, [rsp+0x20]
0000781a8ffd917e  lea rcx, [rsp+0x30]
0000781a8ffd9183  mov r8d, 0x00
0000781a8ffd9189  lea r9, [r15+0x3A8]
0000781a8ffd9190  movaps [rdi], xmm12
0000781a8ffd9194  movaps [rsi], xmm11
0000781a8ffd9198  movaps [rdx], xmm15
0000781a8ffd919c  movaps [rcx], xmm14
0000781a8ffd91a0  mov rax, 0x627DDC279A50
0000781a8ffd91aa  call rax
0000781a8ffd91ac  movaps xmm12, [rsp]
0000781a8ffd91b1  add rsp, 0x40
0000781a8ffd91b5  vmovaps xmm0, [rsp]
0000781a8ffd91ba  vmovaps xmm1, [rsp+0x10]
0000781a8ffd91c0  vmovaps xmm2, [rsp+0x20]
0000781a8ffd91c6  vmovaps xmm3, [rsp+0x30]
0000781a8ffd91cc  vmovaps xmm4, [rsp+0x40]
0000781a8ffd91d2  vmovaps xmm5, [rsp+0x50]
0000781a8ffd91d8  vmovaps xmm6, [rsp+0x60]
0000781a8ffd91de  vmovaps xmm7, [rsp+0x70]
0000781a8ffd91e4  vmovaps xmm8, [rsp+0x80]
0000781a8ffd91ed  vmovaps xmm9, [rsp+0x90]
0000781a8ffd91f6  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd91ff  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd9208  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd9211  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd921a  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd9223  add rsp, 0xF0
0000781a8ffd922a  pop r11
0000781a8ffd922c  pop r10
0000781a8ffd922e  pop r9
0000781a8ffd9230  pop r8
0000781a8ffd9232  pop rsi
0000781a8ffd9233  pop rdi
0000781a8ffd9234  pop rdx
0000781a8ffd9235  pop rcx
0000781a8ffd9236  pop rax
0000781a8ffd9237  add rsp, 0x08
0000781a8ffd923b  jmp 0x0000781A8FFD6B96
0000781a8ffd9240  sub rsp, 0x08
0000781a8ffd9244  push rax
0000781a8ffd9245  push rcx
0000781a8ffd9246  push rdx
0000781a8ffd9247  push rdi
0000781a8ffd9248  push rsi
0000781a8ffd9249  push r8
0000781a8ffd924b  push r9
0000781a8ffd924d  push r10
0000781a8ffd924f  push r11
0000781a8ffd9251  sub rsp, 0xF0
0000781a8ffd9258  vmovaps [rsp], xmm0
0000781a8ffd925d  vmovaps [rsp+0x10], xmm1
0000781a8ffd9263  vmovaps [rsp+0x20], xmm2
0000781a8ffd9269  vmovaps [rsp+0x30], xmm3
0000781a8ffd926f  vmovaps [rsp+0x40], xmm4
0000781a8ffd9275  vmovaps [rsp+0x50], xmm5
0000781a8ffd927b  vmovaps [rsp+0x60], xmm6
0000781a8ffd9281  vmovaps [rsp+0x70], xmm7
0000781a8ffd9287  vmovaps [rsp+0x80], xmm8
0000781a8ffd9290  vmovaps [rsp+0x90], xmm9
0000781a8ffd9299  vmovaps [rsp+0xA0], xmm10
0000781a8ffd92a2  vmovaps [rsp+0xB0], xmm12
0000781a8ffd92ab  vmovaps [rsp+0xC0], xmm13
0000781a8ffd92b4  vmovaps [rsp+0xD0], xmm14
0000781a8ffd92bd  vmovaps [rsp+0xE0], xmm15
0000781a8ffd92c6  sub rsp, 0x40
0000781a8ffd92ca  lea rdi, [rsp]
0000781a8ffd92ce  lea rsi, [rsp+0x10]
0000781a8ffd92d3  lea rdx, [rsp+0x20]
0000781a8ffd92d8  lea rcx, [rsp+0x30]
0000781a8ffd92dd  mov r8d, 0x00
0000781a8ffd92e3  lea r9, [r15+0x3A8]
0000781a8ffd92ea  movaps [rdi], xmm11
0000781a8ffd92ee  movaps [rsi], xmm10
0000781a8ffd92f2  movaps [rdx], xmm13
0000781a8ffd92f6  movaps [rcx], xmm15
0000781a8ffd92fa  mov rax, 0x627DDC279A50
0000781a8ffd9304  call rax
0000781a8ffd9306  movaps xmm11, [rsp]
0000781a8ffd930b  add rsp, 0x40
0000781a8ffd930f  vmovaps xmm0, [rsp]
0000781a8ffd9314  vmovaps xmm1, [rsp+0x10]
0000781a8ffd931a  vmovaps xmm2, [rsp+0x20]
0000781a8ffd9320  vmovaps xmm3, [rsp+0x30]
0000781a8ffd9326  vmovaps xmm4, [rsp+0x40]
0000781a8ffd932c  vmovaps xmm5, [rsp+0x50]
0000781a8ffd9332  vmovaps xmm6, [rsp+0x60]
0000781a8ffd9338  vmovaps xmm7, [rsp+0x70]
0000781a8ffd933e  vmovaps xmm8, [rsp+0x80]
0000781a8ffd9347  vmovaps xmm9, [rsp+0x90]
0000781a8ffd9350  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd9359  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd9362  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd936b  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd9374  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd937d  add rsp, 0xF0
0000781a8ffd9384  pop r11
0000781a8ffd9386  pop r10
0000781a8ffd9388  pop r9
0000781a8ffd938a  pop r8
0000781a8ffd938c  pop rsi
0000781a8ffd938d  pop rdi
0000781a8ffd938e  pop rdx
0000781a8ffd938f  pop rcx
0000781a8ffd9390  pop rax
0000781a8ffd9391  add rsp, 0x08
0000781a8ffd9395  jmp 0x0000781A8FFD6BBF
0000781a8ffd939a  call 0x0000781A8FEE5820
0000781a8ffd939f  jmp 0x0000781A8FFD6BCC
0000781a8ffd93a4  call 0x0000781A8FEE45A0
0000781a8ffd93a9  jmp 0x0000781A8FFD6BD9
0000781a8ffd93ae  sub rsp, 0x08
0000781a8ffd93b2  push rax
0000781a8ffd93b3  push rcx
0000781a8ffd93b4  push rdx
0000781a8ffd93b5  push rdi
0000781a8ffd93b6  push rsi
0000781a8ffd93b7  push r8
0000781a8ffd93b9  push r9
0000781a8ffd93bb  push r10
0000781a8ffd93bd  push r11
0000781a8ffd93bf  sub rsp, 0xF0
0000781a8ffd93c6  vmovaps [rsp], xmm0
0000781a8ffd93cb  vmovaps [rsp+0x10], xmm1
0000781a8ffd93d1  vmovaps [rsp+0x20], xmm2
0000781a8ffd93d7  vmovaps [rsp+0x30], xmm3
0000781a8ffd93dd  vmovaps [rsp+0x40], xmm4
0000781a8ffd93e3  vmovaps [rsp+0x50], xmm5
0000781a8ffd93e9  vmovaps [rsp+0x60], xmm6
0000781a8ffd93ef  vmovaps [rsp+0x70], xmm7
0000781a8ffd93f5  vmovaps [rsp+0x80], xmm8
0000781a8ffd93fe  vmovaps [rsp+0x90], xmm9
0000781a8ffd9407  vmovaps [rsp+0xA0], xmm11
0000781a8ffd9410  vmovaps [rsp+0xB0], xmm12
0000781a8ffd9419  vmovaps [rsp+0xC0], xmm13
0000781a8ffd9422  vmovaps [rsp+0xD0], xmm14
0000781a8ffd942b  vmovaps [rsp+0xE0], xmm15
0000781a8ffd9434  sub rsp, 0x40
0000781a8ffd9438  lea rdi, [rsp]
0000781a8ffd943c  lea rsi, [rsp+0x10]
0000781a8ffd9441  lea rdx, [rsp+0x20]
0000781a8ffd9446  lea rcx, [rsp+0x30]
0000781a8ffd944b  mov r8d, 0x00
0000781a8ffd9451  lea r9, [r15+0x3A8]
0000781a8ffd9458  movaps [rdi], xmm10
0000781a8ffd945c  movaps [rsi], xmm8
0000781a8ffd9460  movaps [rdx], xmm1
0000781a8ffd9463  movaps [rcx], xmm13
0000781a8ffd9467  mov rax, 0x627DDC279A50
0000781a8ffd9471  call rax
0000781a8ffd9473  movaps xmm10, [rsp]
0000781a8ffd9478  add rsp, 0x40
0000781a8ffd947c  vmovaps xmm0, [rsp]
0000781a8ffd9481  vmovaps xmm1, [rsp+0x10]
0000781a8ffd9487  vmovaps xmm2, [rsp+0x20]
0000781a8ffd948d  vmovaps xmm3, [rsp+0x30]
0000781a8ffd9493  vmovaps xmm4, [rsp+0x40]
0000781a8ffd9499  vmovaps xmm5, [rsp+0x50]
0000781a8ffd949f  vmovaps xmm6, [rsp+0x60]
0000781a8ffd94a5  vmovaps xmm7, [rsp+0x70]
0000781a8ffd94ab  vmovaps xmm8, [rsp+0x80]
0000781a8ffd94b4  vmovaps xmm9, [rsp+0x90]
0000781a8ffd94bd  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd94c6  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd94cf  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd94d8  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd94e1  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd94ea  add rsp, 0xF0
0000781a8ffd94f1  pop r11
0000781a8ffd94f3  pop r10
0000781a8ffd94f5  pop r9
0000781a8ffd94f7  pop r8
0000781a8ffd94f9  pop rsi
0000781a8ffd94fa  pop rdi
0000781a8ffd94fb  pop rdx
0000781a8ffd94fc  pop rcx
0000781a8ffd94fd  pop rax
0000781a8ffd94fe  add rsp, 0x08
0000781a8ffd9502  jmp 0x0000781A8FFD6C0F
0000781a8ffd9507  call 0x0000781A8FED64F0
0000781a8ffd950c  jmp 0x0000781A8FFD6C21
0000781a8ffd9511  sub rsp, 0x08
0000781a8ffd9515  push rax
0000781a8ffd9516  push rcx
0000781a8ffd9517  push rdx
0000781a8ffd9518  push rdi
0000781a8ffd9519  push rsi
0000781a8ffd951a  push r8
0000781a8ffd951c  push r9
0000781a8ffd951e  push r10
0000781a8ffd9520  push r11
0000781a8ffd9522  sub rsp, 0xF0
0000781a8ffd9529  vmovaps [rsp], xmm0
0000781a8ffd952e  vmovaps [rsp+0x10], xmm1
0000781a8ffd9534  vmovaps [rsp+0x20], xmm2
0000781a8ffd953a  vmovaps [rsp+0x30], xmm3
0000781a8ffd9540  vmovaps [rsp+0x40], xmm4
0000781a8ffd9546  vmovaps [rsp+0x50], xmm5
0000781a8ffd954c  vmovaps [rsp+0x60], xmm6
0000781a8ffd9552  vmovaps [rsp+0x70], xmm7
0000781a8ffd9558  vmovaps [rsp+0x80], xmm8
0000781a8ffd9561  vmovaps [rsp+0x90], xmm10
0000781a8ffd956a  vmovaps [rsp+0xA0], xmm11
0000781a8ffd9573  vmovaps [rsp+0xB0], xmm12
0000781a8ffd957c  vmovaps [rsp+0xC0], xmm13
0000781a8ffd9585  vmovaps [rsp+0xD0], xmm14
0000781a8ffd958e  vmovaps [rsp+0xE0], xmm15
0000781a8ffd9597  sub rsp, 0x40
0000781a8ffd959b  lea rdi, [rsp]
0000781a8ffd959f  lea rsi, [rsp+0x10]
0000781a8ffd95a4  lea rdx, [rsp+0x20]
0000781a8ffd95a9  lea rcx, [rsp+0x30]
0000781a8ffd95ae  mov r8d, 0x00
0000781a8ffd95b4  lea r9, [r15+0x3A8]
0000781a8ffd95bb  movaps [rdi], xmm9
0000781a8ffd95bf  movaps [rsi], xmm7
0000781a8ffd95c2  movaps [rdx], xmm14
0000781a8ffd95c6  movaps [rcx], xmm13
0000781a8ffd95ca  mov rax, 0x627DDC279A50
0000781a8ffd95d4  call rax
0000781a8ffd95d6  movaps xmm9, [rsp]
0000781a8ffd95db  add rsp, 0x40
0000781a8ffd95df  vmovaps xmm0, [rsp]
0000781a8ffd95e4  vmovaps xmm1, [rsp+0x10]
0000781a8ffd95ea  vmovaps xmm2, [rsp+0x20]
0000781a8ffd95f0  vmovaps xmm3, [rsp+0x30]
0000781a8ffd95f6  vmovaps xmm4, [rsp+0x40]
0000781a8ffd95fc  vmovaps xmm5, [rsp+0x50]
0000781a8ffd9602  vmovaps xmm6, [rsp+0x60]
0000781a8ffd9608  vmovaps xmm7, [rsp+0x70]
0000781a8ffd960e  vmovaps xmm8, [rsp+0x80]
0000781a8ffd9617  vmovaps xmm10, [rsp+0x90]
0000781a8ffd9620  vmovaps xmm11, [rsp+0xA0]
0000781a8ffd9629  vmovaps xmm12, [rsp+0xB0]
0000781a8ffd9632  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd963b  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd9644  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd964d  add rsp, 0xF0
0000781a8ffd9654  pop r11
0000781a8ffd9656  pop r10
0000781a8ffd9658  pop r9
0000781a8ffd965a  pop r8
0000781a8ffd965c  pop rsi
0000781a8ffd965d  pop rdi
0000781a8ffd965e  pop rdx
0000781a8ffd965f  pop rcx
0000781a8ffd9660  pop rax
0000781a8ffd9661  add rsp, 0x08
0000781a8ffd9665  jmp 0x0000781A8FFD6C4F
0000781a8ffd966a  sub rsp, 0x08
0000781a8ffd966e  push rax
0000781a8ffd966f  push rcx
0000781a8ffd9670  push rdx
0000781a8ffd9671  push rdi
0000781a8ffd9672  push rsi
0000781a8ffd9673  push r8
0000781a8ffd9675  push r9
0000781a8ffd9677  push r10
0000781a8ffd9679  push r11
0000781a8ffd967b  sub rsp, 0xF0
0000781a8ffd9682  vmovaps [rsp], xmm0
0000781a8ffd9687  vmovaps [rsp+0x10], xmm1
0000781a8ffd968d  vmovaps [rsp+0x20], xmm2
0000781a8ffd9693  vmovaps [rsp+0x30], xmm3
0000781a8ffd9699  vmovaps [rsp+0x40], xmm4
0000781a8ffd969f  vmovaps [rsp+0x50], xmm5
0000781a8ffd96a5  vmovaps [rsp+0x60], xmm6
0000781a8ffd96ab  vmovaps [rsp+0x70], xmm7
0000781a8ffd96b1  vmovaps [rsp+0x80], xmm8
0000781a8ffd96ba  vmovaps [rsp+0x90], xmm9
0000781a8ffd96c3  vmovaps [rsp+0xA0], xmm10
0000781a8ffd96cc  vmovaps [rsp+0xB0], xmm11
0000781a8ffd96d5  vmovaps [rsp+0xC0], xmm12
0000781a8ffd96de  vmovaps [rsp+0xD0], xmm14
0000781a8ffd96e7  vmovaps [rsp+0xE0], xmm15
0000781a8ffd96f0  sub rsp, 0x40
0000781a8ffd96f4  lea rdi, [rsp]
0000781a8ffd96f8  lea rsi, [rsp+0x10]
0000781a8ffd96fd  lea rdx, [rsp+0x20]
0000781a8ffd9702  lea rcx, [rsp+0x30]
0000781a8ffd9707  mov r8d, 0x00
0000781a8ffd970d  lea r9, [r15+0x3A8]
0000781a8ffd9714  movaps [rdi], xmm13
0000781a8ffd9718  movaps [rsi], xmm12
0000781a8ffd971c  movaps [rdx], xmm15
0000781a8ffd9720  movaps [rcx], xmm14
0000781a8ffd9724  mov rax, 0x627DDC279A50
0000781a8ffd972e  call rax
0000781a8ffd9730  movaps xmm13, [rsp]
0000781a8ffd9735  add rsp, 0x40
0000781a8ffd9739  vmovaps xmm0, [rsp]
0000781a8ffd973e  vmovaps xmm1, [rsp+0x10]
0000781a8ffd9744  vmovaps xmm2, [rsp+0x20]
0000781a8ffd974a  vmovaps xmm3, [rsp+0x30]
0000781a8ffd9750  vmovaps xmm4, [rsp+0x40]
0000781a8ffd9756  vmovaps xmm5, [rsp+0x50]
0000781a8ffd975c  vmovaps xmm6, [rsp+0x60]
0000781a8ffd9762  vmovaps xmm7, [rsp+0x70]
0000781a8ffd9768  vmovaps xmm8, [rsp+0x80]
0000781a8ffd9771  vmovaps xmm9, [rsp+0x90]
0000781a8ffd977a  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd9783  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd978c  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd9795  vmovaps xmm14, [rsp+0xD0]
0000781a8ffd979e  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd97a7  add rsp, 0xF0
0000781a8ffd97ae  pop r11
0000781a8ffd97b0  pop r10
0000781a8ffd97b2  pop r9
0000781a8ffd97b4  pop r8
0000781a8ffd97b6  pop rsi
0000781a8ffd97b7  pop rdi
0000781a8ffd97b8  pop rdx
0000781a8ffd97b9  pop rcx
0000781a8ffd97ba  pop rax
0000781a8ffd97bb  add rsp, 0x08
0000781a8ffd97bf  jmp 0x0000781A8FFD6C7D
0000781a8ffd97c4  sub rsp, 0x08
0000781a8ffd97c8  push rax
0000781a8ffd97c9  push rcx
0000781a8ffd97ca  push rdx
0000781a8ffd97cb  push rdi
0000781a8ffd97cc  push rsi
0000781a8ffd97cd  push r8
0000781a8ffd97cf  push r9
0000781a8ffd97d1  push r10
0000781a8ffd97d3  push r11
0000781a8ffd97d5  sub rsp, 0xF0
0000781a8ffd97dc  vmovaps [rsp], xmm0
0000781a8ffd97e1  vmovaps [rsp+0x10], xmm1
0000781a8ffd97e7  vmovaps [rsp+0x20], xmm2
0000781a8ffd97ed  vmovaps [rsp+0x30], xmm3
0000781a8ffd97f3  vmovaps [rsp+0x40], xmm4
0000781a8ffd97f9  vmovaps [rsp+0x50], xmm5
0000781a8ffd97ff  vmovaps [rsp+0x60], xmm6
0000781a8ffd9805  vmovaps [rsp+0x70], xmm7
0000781a8ffd980b  vmovaps [rsp+0x80], xmm8
0000781a8ffd9814  vmovaps [rsp+0x90], xmm9
0000781a8ffd981d  vmovaps [rsp+0xA0], xmm10
0000781a8ffd9826  vmovaps [rsp+0xB0], xmm11
0000781a8ffd982f  vmovaps [rsp+0xC0], xmm12
0000781a8ffd9838  vmovaps [rsp+0xD0], xmm13
0000781a8ffd9841  vmovaps [rsp+0xE0], xmm15
0000781a8ffd984a  sub rsp, 0x40
0000781a8ffd984e  lea rdi, [rsp]
0000781a8ffd9852  lea rsi, [rsp+0x10]
0000781a8ffd9857  lea rdx, [rsp+0x20]
0000781a8ffd985c  lea rcx, [rsp+0x30]
0000781a8ffd9861  mov r8d, 0x00
0000781a8ffd9867  lea r9, [r15+0x3A8]
0000781a8ffd986e  movaps [rdi], xmm14
0000781a8ffd9872  movaps [rsi], xmm11
0000781a8ffd9876  movaps [rdx], xmm1
0000781a8ffd9879  movaps [rcx], xmm15
0000781a8ffd987d  mov rax, 0x627DDC279A50
0000781a8ffd9887  call rax
0000781a8ffd9889  movaps xmm14, [rsp]
0000781a8ffd988e  add rsp, 0x40
0000781a8ffd9892  vmovaps xmm0, [rsp]
0000781a8ffd9897  vmovaps xmm1, [rsp+0x10]
0000781a8ffd989d  vmovaps xmm2, [rsp+0x20]
0000781a8ffd98a3  vmovaps xmm3, [rsp+0x30]
0000781a8ffd98a9  vmovaps xmm4, [rsp+0x40]
0000781a8ffd98af  vmovaps xmm5, [rsp+0x50]
0000781a8ffd98b5  vmovaps xmm6, [rsp+0x60]
0000781a8ffd98bb  vmovaps xmm7, [rsp+0x70]
0000781a8ffd98c1  vmovaps xmm8, [rsp+0x80]
0000781a8ffd98ca  vmovaps xmm9, [rsp+0x90]
0000781a8ffd98d3  vmovaps xmm10, [rsp+0xA0]
0000781a8ffd98dc  vmovaps xmm11, [rsp+0xB0]
0000781a8ffd98e5  vmovaps xmm12, [rsp+0xC0]
0000781a8ffd98ee  vmovaps xmm13, [rsp+0xD0]
0000781a8ffd98f7  vmovaps xmm15, [rsp+0xE0]
0000781a8ffd9900  add rsp, 0xF0
0000781a8ffd9907  pop r11
0000781a8ffd9909  pop r10
0000781a8ffd990b  pop r9
0000781a8ffd990d  pop r8
0000781a8ffd990f  pop rsi
0000781a8ffd9910  pop rdi
0000781a8ffd9911  pop rdx
0000781a8ffd9912  pop rcx
0000781a8ffd9913  pop rax
0000781a8ffd9914  add rsp, 0x08
0000781a8ffd9918  jmp 0x0000781A8FFD6CAB
0000781a8ffd991d  call 0x0000781A8FEACF70
0000781a8ffd9922  jmp 0x0000781A8FFD6CB9
0000781a8ffd9927  call 0x0000781A8FE0C380
0000781a8ffd992c  jmp 0x0000781A8FFD6CC3
0000781a8ffd9931  call 0x0000781A8FE08C20
0000781a8ffd9936  jmp 0x0000781A8FFD6CCD
0000781a8ffd993b  call 0x0000781A8FE0D600
0000781a8ffd9940  jmp 0x0000781A8FFD6CD7
0000781a8ffd9945  int3
0000781a8ffd9946  nop [rax+rax*1], ax
0000781a8ffd994f  nop
0000781a8ffd9950  mov eax, [r15+0x48]
0000781a8ffd9954  lea r14d, [eax+0x01]
0000781a8ffd9959  mov [rsp+0x10], r14d
0000781a8ffd995e  mov r14d, r14d
0000781a8ffd9961  mov [r15+0x48], r14
0000781a8ffd9965  xor eax, eax
0000781a8ffd9967  mov r14d, [rsp+0x10]
0000781a8ffd996c  cmp r14d, 0x1F4
0000781a8ffd9973  cmc
0000781a8ffd9974  lahf
0000781a8ffd9975  seto al
0000781a8ffd9978  mov [r15+0x108], eax
0000781a8ffd997f  mov eax, [r15+0x108]
0000781a8ffd9986  sahf
0000781a8ffd9987  jnz 0x0000781A8FFD99B9
0000781a8ffd9989  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd9991  jz 0x0000781A8FFDD2E0
0000781a8ffd9997  nop [rax+rax*1], ax
0000781a8ffd99a0  nop [rax+rax*1], eax
0000781a8ffd99a8  mov eax, 0x410670
0000781a8ffd99ad  mov [r15+0x100], rax
0000781a8ffd99b4  jmp 0x0000781A8FDFE110
0000781a8ffd99b9  cmp dword ptr [r15+0x318], 0x00
0000781a8ffd99c1  jz 0x0000781A8FFD99F0
0000781a8ffd99c7  nop [rax+rax*1], ax
0000781a8ffd99d0  nop [rax+rax*1], eax
0000781a8ffd99d8  mov eax, 0x4104EC
0000781a8ffd99dd  mov [r15+0x100], rax
0000781a8ffd99e4  jmp 0x0000781A8FDFE110
0000781a8ffd99e9  int3
0000781a8ffd99ea  int3
0000781a8ffd99eb  nop [rax+rax*1], eax
0000781a8ffd99f0  mov rax, [r15+0x40]
0000781a8ffd99f4  vxorps xmm1, xmm1, xmm1
0000781a8ffd99f8  vpbroadcastq xmm1, xmm1
0000781a8ffd99fd  vxorps xmm15, xmm15, xmm15
0000781a8ffd9a02  vpbroadcastq xmm15, xmm15
0000781a8ffd9a07  lea r14, [rax+0x30]
0000781a8ffd9a0b  mov r12, [r13+r14*1]
0000781a8ffd9a10  lea r14, [rax+0x38]
0000781a8ffd9a14  mov r11, [r13+r14*1]
0000781a8ffd9a19  movq xmm14, r12
0000781a8ffd9a1e  movq xmm13, r11
0000781a8ffd9a23  movq xmm14, xmm14
0000781a8ffd9a28  movq xmm13, xmm13
0000781a8ffd9a2d  vmovaps [rsp+0x10], xmm13
0000781a8ffd9a33  movq xmm13, xmm13
0000781a8ffd9a38  movaps [r15+0x270], xmm13
0000781a8ffd9a40  movaps xmm13, [r15+0x160]
0000781a8ffd9a48  vmovaps [rsp+0x20], xmm13
0000781a8ffd9a4e  vmovaps xmm12, [rsp+0x20]
0000781a8ffd9a54  por xmm13, xmm12
0000781a8ffd9a59  lea r14, [rax+0x20]
0000781a8ffd9a5d  mov r12, [r13+r14*1]
0000781a8ffd9a62  lea r14, [rax+0x28]
0000781a8ffd9a66  mov r11, [r13+r14*1]
0000781a8ffd9a6b  movq xmm12, r12
0000781a8ffd9a70  movq xmm11, r11
0000781a8ffd9a75  movq xmm12, xmm12
0000781a8ffd9a7a  movq xmm11, xmm11
0000781a8ffd9a7f  movaps xmm10, [r15+0x2D0]
0000781a8ffd9a87  vmovaps [rsp+0x20], xmm10
0000781a8ffd9a8d  vmovaps xmm9, [rsp+0x20]
0000781a8ffd9a93  por xmm10, xmm9
0000781a8ffd9a98  movaps xmm9, [r15+0x300]
0000781a8ffd9aa0  vmovaps [rsp+0x20], xmm9
0000781a8ffd9aa6  vmovaps xmm8, [rsp+0x20]
0000781a8ffd9aac  por xmm9, xmm8
0000781a8ffd9ab1  movaps xmm8, [r15+0x2B0]
0000781a8ffd9ab9  vmovaps [rsp+0x20], xmm8
0000781a8ffd9abf  vmovaps xmm7, [rsp+0x20]
0000781a8ffd9ac5  por xmm8, xmm7
0000781a8ffd9aca  movaps xmm7, [r15+0x180]
0000781a8ffd9ad2  vmovaps [rsp+0x20], xmm7
0000781a8ffd9ad8  vmovaps xmm6, [rsp+0x20]
0000781a8ffd9ade  por xmm7, xmm6
0000781a8ffd9ae2  lea r14, [rax+0x10]
0000781a8ffd9ae6  mov r12, [r13+r14*1]
0000781a8ffd9aeb  lea r14, [rax+0x18]
0000781a8ffd9aef  mov r11, [r13+r14*1]
0000781a8ffd9af4  movq xmm6, r12
0000781a8ffd9af9  movq xmm5, r11
0000781a8ffd9afe  movq xmm6, xmm6
0000781a8ffd9b02  movq xmm5, xmm5
0000781a8ffd9b06  movaps xmm4, [r15+0x200]
0000781a8ffd9b0e  vmovaps [rsp+0x20], xmm4
0000781a8ffd9b14  vmovaps xmm3, [rsp+0x20]
0000781a8ffd9b1a  por xmm4, xmm3
0000781a8ffd9b1e  movaps xmm3, [r15+0x1F0]
0000781a8ffd9b26  vmovaps [rsp+0x20], xmm3
0000781a8ffd9b2c  vmovaps xmm2, [rsp+0x20]
0000781a8ffd9b32  por xmm3, xmm2
0000781a8ffd9b36  movaps xmm2, [r15+0x2E0]
0000781a8ffd9b3e  vmovaps [rsp+0x20], xmm2
0000781a8ffd9b44  vmovaps [rsp+0x30], xmm1
0000781a8ffd9b4a  vmovaps xmm1, [rsp+0x20]
0000781a8ffd9b50  por xmm2, xmm1
0000781a8ffd9b54  movaps xmm1, [r15+0x2A0]
0000781a8ffd9b5c  vmovaps [rsp+0x20], xmm1
0000781a8ffd9b62  vmovaps [rsp+0x40], xmm15
0000781a8ffd9b68  vmovaps xmm15, [rsp+0x20]
0000781a8ffd9b6e  por xmm1, xmm15
0000781a8ffd9b73  movaps xmm15, [r15+0x280]
0000781a8ffd9b7b  vmovaps [rsp+0x20], xmm15
0000781a8ffd9b81  vmovaps [rsp+0x50], xmm1
0000781a8ffd9b87  vmovaps xmm1, [rsp+0x20]
0000781a8ffd9b8d  por xmm15, xmm1
0000781a8ffd9b92  movaps xmm1, [r15+0x1C0]
0000781a8ffd9b9a  vmovaps [rsp+0x20], xmm1
0000781a8ffd9ba0  vmovaps [rsp+0x60], xmm15
0000781a8ffd9ba6  vmovaps xmm15, [rsp+0x20]
0000781a8ffd9bac  por xmm1, xmm15
0000781a8ffd9bb1  movaps xmm15, [r15+0x210]
0000781a8ffd9bb9  vmovaps [rsp+0x20], xmm15
0000781a8ffd9bbf  vmovaps [rsp+0x70], xmm1
0000781a8ffd9bc5  vmovaps xmm1, [rsp+0x20]
0000781a8ffd9bcb  por xmm15, xmm1
0000781a8ffd9bd0  mov r14, [r13+rax*1]
0000781a8ffd9bd5  vmovq xmm1, r14
0000781a8ffd9bda  vpbroadcastq xmm1, xmm1
0000781a8ffd9bdf  vmovaps [rsp+0x20], xmm1
0000781a8ffd9be5  vxorps xmm1, xmm1, xmm1
0000781a8ffd9be9  vpbroadcastq xmm1, xmm1
0000781a8ffd9bee  mov r14, [r15+0xF8]
0000781a8ffd9bf5  vmovaps [rsp+0x80], xmm1
0000781a8ffd9bfe  movups xmm1, [r13+r14*1]
0000781a8ffd9c04  vmovaps [rsp+0x90], xmm1
0000781a8ffd9c0d  vxorps xmm1, xmm1, xmm1
0000781a8ffd9c11  vpbroadcastq xmm1, xmm1
0000781a8ffd9c16  lea r12, [rax+0x08]
0000781a8ffd9c1a  mov rax, [r13+r12*1]
0000781a8ffd9c1f  vmovaps [rsp+0xA0], xmm1
0000781a8ffd9c28  movq xmm1, rax
0000781a8ffd9c2d  movaps [r15+0x240], xmm1
0000781a8ffd9c35  mov rax, [r15+0x50]
0000781a8ffd9c39  mov [r15+0x60], rax
0000781a8ffd9c3d  mov qword ptr [r15+0x58], 0x40
0000781a8ffd9c45  vmovaps xmm1, [rsp+0x30]
0000781a8ffd9c4b  vmovaps [rsp+0x30], xmm15
0000781a8ffd9c51  vmovaps xmm15, [rsp+0x90]
0000781a8ffd9c5a  vmovaps [rsp+0x90], xmm14
0000781a8ffd9c63  vmovaps xmm14, [rsp+0x20]
0000781a8ffd9c69  vmovaps [rsp+0x20], xmm13
0000781a8ffd9c6f  vmovaps [rsp+0xB0], xmm12
0000781a8ffd9c78  movaps xmm13, xmm1
0000781a8ffd9c7c  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd9c87  vptest xmm12, xmm12
0000781a8ffd9c8c  jnz 0x0000781A8FFDA72F
0000781a8ffd9c92  movaps xmm1, [r15+0x250]
0000781a8ffd9c9a  vmovaps xmm15, [rsp+0x40]
0000781a8ffd9ca0  vmovaps [rsp+0x40], xmm13
0000781a8ffd9ca6  movaps xmm12, xmm15
0000781a8ffd9caa  vfmadd231pd xmm12, xmm1, xmm14
0000781a8ffd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
0000781a8ffd9cb5  vptest xmm13, xmm13
0000781a8ffd9cba  jnz 0x0000781A8FFDA888
0000781a8ffd9cc0  movaps xmm15, [r15+0x1E0]
0000781a8ffd9cc8  vmovaps [rsp+0xC0], xmm15
0000781a8ffd9cd1  vmovaps xmm13, [rsp+0xC0]
0000781a8ffd9cda  por xmm15, xmm13
0000781a8ffd9cdf  movaps xmm13, [r15+0x1D0]
0000781a8ffd9ce7  vmovaps [rsp+0xC0], xmm13
0000781a8ffd9cf0  vmovaps [rsp+0xD0], xmm1
0000781a8ffd9cf9  vmovaps xmm1, [rsp+0xC0]
0000781a8ffd9d02  por xmm13, xmm1
0000781a8ffd9d07  movaps xmm1, [r15+0x2C0]
0000781a8ffd9d0f  vmovaps [rsp+0xC0], xmm1
0000781a8ffd9d18  vmovaps [rsp+0xE0], xmm15
0000781a8ffd9d21  vmovaps xmm15, [rsp+0xC0]
0000781a8ffd9d2a  por xmm1, xmm15
0000781a8ffd9d2f  movaps xmm15, [r15+0x290]
0000781a8ffd9d37  vmovaps [rsp+0xC0], xmm15
0000781a8ffd9d40  vmovaps [rsp+0xF0], xmm1
0000781a8ffd9d49  vmovaps xmm1, [rsp+0xC0]
0000781a8ffd9d52  por xmm15, xmm1
0000781a8ffd9d57  movaps xmm1, [r15+0x260]
0000781a8ffd9d5f  vmovaps [rsp+0xC0], xmm1
0000781a8ffd9d68  vmovaps [rsp+0x100], xmm15
0000781a8ffd9d71  vmovaps xmm15, [rsp+0xC0]
0000781a8ffd9d7a  por xmm1, xmm15
0000781a8ffd9d7f  vmovaps xmm15, [rsp+0xD0]
0000781a8ffd9d88  vmovaps [rsp+0xC0], xmm1
0000781a8ffd9d91  vmovaps xmm1, [rsp+0xD0]
0000781a8ffd9d9a  por xmm15, xmm1
0000781a8ffd9d9f  lea r12, [r14+0xC0]
0000781a8ffd9da6  movups xmm1, [r13+r12*1]
0000781a8ffd9dac  mov [rsp+0xD0], rax
0000781a8ffd9db4  xor eax, eax
0000781a8ffd9db6  mov r12d, 0x40
0000781a8ffd9dbc  mov r11d, 0x200
0000781a8ffd9dc2  cmp r12, r11
0000781a8ffd9dc5  cmc
0000781a8ffd9dc6  lahf
0000781a8ffd9dc7  seto al
0000781a8ffd9dca  mov [r15+0x108], eax
0000781a8ffd9dd1  vmovaps [rsp+0x110], xmm1
0000781a8ffd9dda  vmovaps xmm1, [rsp+0x80]
0000781a8ffd9de3  vmovaps [rsp+0x80], xmm15
0000781a8ffd9dec  vmovaps xmm15, [rsp+0x110]
0000781a8ffd9df5  vmovaps [rsp+0x110], xmm13
0000781a8ffd9dfe  vmovaps [rsp+0x120], xmm12
0000781a8ffd9e07  movaps xmm13, xmm1
0000781a8ffd9e0b  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd9e16  vptest xmm12, xmm12
0000781a8ffd9e1b  jnz 0x0000781A8FFDA9EB
0000781a8ffd9e21  lea rax, [r14+0xB0]
0000781a8ffd9e28  movups xmm1, [r13+rax*1]
0000781a8ffd9e2e  vmovaps xmm15, [rsp+0xA0]
0000781a8ffd9e37  vmovaps [rsp+0xA0], xmm13
0000781a8ffd9e40  movaps xmm12, xmm15
0000781a8ffd9e44  vfmadd231pd xmm12, xmm1, xmm14
0000781a8ffd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
0000781a8ffd9e4f  vptest xmm13, xmm13
0000781a8ffd9e54  jnz 0x0000781A8FFDAB4E
0000781a8ffd9e5a  vmovaps xmm1, [rsp+0x30]
0000781a8ffd9e60  vmovaps xmm15, [rsp+0x30]
0000781a8ffd9e66  por xmm1, xmm15
0000781a8ffd9e6b  movaps [r15+0x210], xmm1
0000781a8ffd9e73  vmovaps xmm15, [rsp+0x70]
0000781a8ffd9e79  vmovaps xmm14, [rsp+0x70]
0000781a8ffd9e7f  por xmm15, xmm14
0000781a8ffd9e84  movaps [r15+0x1C0], xmm15
0000781a8ffd9e8c  vmovaps xmm14, [rsp+0x60]
0000781a8ffd9e92  vmovaps xmm13, [rsp+0x60]
0000781a8ffd9e98  por xmm14, xmm13
0000781a8ffd9e9d  movaps [r15+0x280], xmm14
0000781a8ffd9ea5  vmovaps xmm13, [rsp+0x50]
0000781a8ffd9eab  vmovaps [rsp+0x30], xmm1
0000781a8ffd9eb1  vmovaps xmm1, [rsp+0x50]
0000781a8ffd9eb7  por xmm13, xmm1
0000781a8ffd9ebc  movaps [r15+0x2A0], xmm13
0000781a8ffd9ec4  vmovaps [rsp+0x50], xmm2
0000781a8ffd9eca  vmovaps xmm1, [rsp+0x50]
0000781a8ffd9ed0  por xmm2, xmm1
0000781a8ffd9ed4  movaps [r15+0x2E0], xmm2
0000781a8ffd9edc  vmovaps [rsp+0x50], xmm3
0000781a8ffd9ee2  vmovaps xmm1, [rsp+0x50]
0000781a8ffd9ee8  por xmm3, xmm1
0000781a8ffd9eec  movaps [r15+0x1F0], xmm3
0000781a8ffd9ef4  vmovaps xmm1, [rsp+0x80]
0000781a8ffd9efd  vmovaps [rsp+0x50], xmm15
0000781a8ffd9f03  vmovaps xmm15, [rsp+0x80]
0000781a8ffd9f0c  por xmm1, xmm15
0000781a8ffd9f11  movaps [r15+0x250], xmm1
0000781a8ffd9f19  vmovaps xmm1, [rsp+0xC0]
0000781a8ffd9f22  vmovaps xmm15, [rsp+0xC0]
0000781a8ffd9f2b  por xmm1, xmm15
0000781a8ffd9f30  movaps [r15+0x260], xmm1
0000781a8ffd9f38  vmovaps xmm15, [rsp+0x100]
0000781a8ffd9f41  vmovaps [rsp+0x60], xmm1
0000781a8ffd9f47  vmovaps xmm1, [rsp+0x100]
0000781a8ffd9f50  por xmm15, xmm1
0000781a8ffd9f55  movaps [r15+0x290], xmm15
0000781a8ffd9f5d  vmovaps xmm1, [rsp+0xF0]
0000781a8ffd9f66  vmovaps [rsp+0x70], xmm15
0000781a8ffd9f6c  vmovaps xmm15, [rsp+0xF0]
0000781a8ffd9f75  por xmm1, xmm15
0000781a8ffd9f7a  movaps [r15+0x2C0], xmm1
0000781a8ffd9f82  movq xmm15, qword ptr [r15+0x240]
0000781a8ffd9f8b  vmovaps [rsp+0x80], xmm15
0000781a8ffd9f94  vpermilpd xmm15, xmm15, 0x00
0000781a8ffd9f9a  vmovaps [rsp+0xC0], xmm1
0000781a8ffd9fa3  vmovaps xmm1, [rsp+0x40]
0000781a8ffd9fa9  vmovaps [rsp+0x40], xmm15
0000781a8ffd9faf  vmovaps xmm15, [rsp+0x30]
0000781a8ffd9fb5  vmovaps [rsp+0x30], xmm14
0000781a8ffd9fbb  vmovaps xmm14, [rsp+0x40]
0000781a8ffd9fc1  vmovaps [rsp+0x40], xmm13
0000781a8ffd9fc7  vmovaps [rsp+0xF0], xmm12
0000781a8ffd9fd0  movaps xmm13, xmm1
0000781a8ffd9fd4  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000781a8ffd9fdf  vptest xmm12, xmm12
0000781a8ffd9fe4  jnz 0x0000781A8FFDACA7
0000781a8ffd9fea  vmovaps xmm1, [rsp+0x80]
0000781a8ffd9ff3  vpermilpd xmm1, xmm1, 0x00
0000781a8ffd9ff9  vmovaps xmm15, [rsp+0xA0]
0000781a8ffda002  movaps xmm14, xmm15
0000781a8ffda006  vfmadd231pd xmm14, xmm2, xmm1
0000781a8ffda00b  vcmppd xmm12, xmm14, xmm14, 0x03
0000781a8ffda011  vptest xmm12, xmm12
0000781a8ffda016  jnz 0x0000781A8FFDAE00
0000781a8ffda01c  vmovaps xmm1, [rsp+0x80]
0000781a8ffda025  vpermilpd xmm1, xmm1, 0x00
0000781a8ffda02b  vmovaps xmm15, [rsp+0x120]
0000781a8ffda034  vmovaps xmm12, [rsp+0x50]
0000781a8ffda03a  vmovaps [rsp+0x50], xmm14
0000781a8ffda040  movaps xmm2, xmm15
0000781a8ffda044  vfmadd231pd xmm2, xmm12, xmm1
0000781a8ffda049  vcmppd xmm14, xmm2, xmm2, 0x03
0000781a8ffda04e  vptest xmm14, xmm14
0000781a8ffda053  jnz 0x0000781A8FFDAF58
0000781a8ffda059  vmovaps xmm1, [rsp+0x110]
0000781a8ffda062  vmovaps xmm15, [rsp+0x110]
0000781a8ffda06b  por xmm1, xmm15
0000781a8ffda070  movaps [r15+0x1D0], xmm1
0000781a8ffda078  vmovaps xmm15, [rsp+0x80]
0000781a8ffda081  vpermilpd xmm15, xmm15, 0x00
0000781a8ffda087  vmovaps xmm14, [rsp+0xF0]
0000781a8ffda090  vmovaps [rsp+0x80], xmm1
0000781a8ffda099  movaps xmm12, xmm14
0000781a8ffda09d  vfmadd231pd xmm12, xmm3, xmm15
0000781a8ffda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
0000781a8ffda0a8  vptest xmm1, xmm1
0000781a8ffda0ad  jnz 0x0000781A8FFDB0AF
0000781a8ffda0b3  vmovaps [rsp+0xA0], xmm4
0000781a8ffda0bc  vmovaps xmm1, [rsp+0xA0]
0000781a8ffda0c5  por xmm4, xmm1
0000781a8ffda0c9  movaps [r15+0x200], xmm4
0000781a8ffda0d1  vmovaps xmm1, [rsp+0xE0]
0000781a8ffda0da  vmovaps xmm15, [rsp+0xE0]
0000781a8ffda0e3  por xmm1, xmm15
0000781a8ffda0e8  movaps [r15+0x1E0], xmm1
0000781a8ffda0f0  vmovaps [rsp+0xA0], xmm8
0000781a8ffda0f9  vmovaps xmm1, [rsp+0xA0]
0000781a8ffda102  por xmm8, xmm1
0000781a8ffda107  movaps [r15+0x2B0], xmm8
0000781a8ffda10f  vmovaps [rsp+0xA0], xmm9
0000781a8ffda118  vmovaps xmm1, [rsp+0xA0]
0000781a8ffda121  por xmm9, xmm1
0000781a8ffda126  movaps [r15+0x300], xmm9
0000781a8ffda12e  vmovaps [rsp+0xA0], xmm6
0000781a8ffda137  vpermilpd xmm6, xmm6, 0x00
0000781a8ffda13d  vmovaps xmm14, [rsp+0x60]
0000781a8ffda143  movaps xmm9, xmm13
0000781a8ffda147  vfmadd231pd xmm9, xmm14, xmm6
0000781a8ffda14c  vcmppd xmm3, xmm9, xmm9, 0x03
0000781a8ffda152  vptest xmm3, xmm3
0000781a8ffda157  jnz 0x0000781A8FFDB208
0000781a8ffda15d  vmovaps xmm14, [rsp+0xA0]
0000781a8ffda166  vpermilpd xmm14, xmm14, 0x00
0000781a8ffda16c  vmovaps xmm13, [rsp+0x50]
0000781a8ffda172  vmovaps xmm6, [rsp+0xC0]
0000781a8ffda17b  vmovaps [rsp+0x50], xmm1
0000781a8ffda181  movaps xmm3, xmm13
0000781a8ffda185  vfmadd231pd xmm3, xmm6, xmm14
0000781a8ffda18a  vcmppd xmm1, xmm3, xmm3, 0x03
0000781a8ffda18f  vptest xmm1, xmm1
0000781a8ffda194  jnz 0x0000781A8FFDB361
0000781a8ffda19a  vmovaps xmm1, [rsp+0xA0]
0000781a8ffda1a3  vpermilpd xmm1, xmm1, 0x00
0000781a8ffda1a9  vmovaps xmm14, [rsp+0x30]
0000781a8ffda1af  movaps xmm6, xmm2
0000781a8ffda1b2  vfmadd231pd xmm6, xmm14, xmm1
0000781a8ffda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
0000781a8ffda1bc  vptest xmm13, xmm13
0000781a8ffda1c1  jnz 0x0000781A8FFDB4B8
0000781a8ffda1c7  vmovaps xmm1, [rsp+0xA0]
0000781a8ffda1d0  vpermilpd xmm1, xmm1, 0x00
0000781a8ffda1d6  vmovaps xmm14, [rsp+0x80]
0000781a8ffda1df  movaps xmm13, xmm12
0000781a8ffda1e3  vfmadd231pd xmm13, xmm14, xmm1
0000781a8ffda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
0000781a8ffda1ee  vptest xmm2, xmm2
0000781a8ffda1f3  jnz 0x0000781A8FFDB60E
0000781a8ffda1f9  vmovaps [rsp+0x30], xmm7
0000781a8ffda1ff  vmovaps xmm1, [rsp+0x30]
0000781a8ffda205  por xmm7, xmm1
0000781a8ffda209  movaps [r15+0x180], xmm7
0000781a8ffda211  vmovaps [rsp+0x30], xmm10
0000781a8ffda217  vmovaps xmm1, [rsp+0x30]
0000781a8ffda21d  por xmm10, xmm1
0000781a8ffda222  movaps [r15+0x2D0], xmm10
0000781a8ffda22a  vmovaps [rsp+0x30], xmm5
0000781a8ffda230  vpermilpd xmm5, xmm5, 0x00
0000781a8ffda236  vmovaps xmm14, [rsp+0x50]
0000781a8ffda23c  movaps xmm12, xmm3
0000781a8ffda240  vfmadd231pd xmm12, xmm14, xmm5
0000781a8ffda245  vcmppd xmm10, xmm12, xmm12, 0x03
0000781a8ffda24b  vptest xmm10, xmm10
0000781a8ffda250  jnz 0x0000781A8FFDB767
0000781a8ffda256  vmovaps xmm14, [rsp+0x30]
0000781a8ffda25c  vpermilpd xmm14, xmm14, 0x00
0000781a8ffda262  movaps xmm10, xmm9
0000781a8ffda266  vfmadd231pd xmm10, xmm7, xmm14
0000781a8ffda26b  vcmppd xmm5, xmm10, xmm10, 0x03
0000781a8ffda271  vptest xmm5, xmm5
0000781a8ffda276  jnz 0x0000781A8FFDB8BF
0000781a8ffda27c  lea rax, [r14+0x80]
0000781a8ffda283  movups xmm14, [r13+rax*1]
0000781a8ffda289  movaps [r15+0x2F0], xmm14
0000781a8ffda291  vmovaps xmm9, [rsp+0x30]
0000781a8ffda297  vpermilpd xmm9, xmm9, 0x00
0000781a8ffda29d  vmovaps xmm7, [rsp+0x70]
0000781a8ffda2a3  movaps xmm5, xmm6
0000781a8ffda2a6  vfmadd231pd xmm5, xmm7, xmm9
0000781a8ffda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
0000781a8ffda2b0  vptest xmm3, xmm3
0000781a8ffda2b5  jnz 0x0000781A8FFDBA22
0000781a8ffda2bb  vmovaps xmm9, [rsp+0x30]
0000781a8ffda2c1  vpermilpd xmm9, xmm9, 0x00
0000781a8ffda2c7  movaps xmm7, xmm13
0000781a8ffda2cb  vfmadd231pd xmm7, xmm1, xmm9
0000781a8ffda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
0000781a8ffda2d5  vptest xmm6, xmm6
0000781a8ffda2da  jnz 0x0000781A8FFDBB78
0000781a8ffda2e0  vmovaps xmm1, [rsp+0x20]
0000781a8ffda2e6  vmovaps xmm13, [rsp+0x20]
0000781a8ffda2ec  por xmm1, xmm13
0000781a8ffda2f1  movaps [r15+0x160], xmm1
0000781a8ffda2f9  lea rax, [r14+0x40]
0000781a8ffda2fd  movups xmm13, [r13+rax*1]
0000781a8ffda303  lea rax, [r14+0x50]
0000781a8ffda307  movups xmm9, [r13+rax*1]
0000781a8ffda30d  movaps [r15+0x1B0], xmm13
0000781a8ffda315  movaps [r15+0x1A0], xmm9
0000781a8ffda31d  movaps xmm6, [r15+0x190]
0000781a8ffda325  vmovaps xmm3, [rsp+0xB0]
0000781a8ffda32e  vpermilpd xmm3, xmm3, 0x00
0000781a8ffda334  vmovaps [rsp+0x20], xmm1
0000781a8ffda33a  movaps xmm2, xmm12
0000781a8ffda33e  vfmadd231pd xmm2, xmm6, xmm3
0000781a8ffda343  vcmppd xmm1, xmm2, xmm2, 0x03
0000781a8ffda348  vptest xmm1, xmm1
0000781a8ffda34d  jnz 0x0000781A8FFDBCE3
0000781a8ffda353  vmovaps xmm1, [rsp+0xB0]
0000781a8ffda35c  vpermilpd xmm1, xmm1, 0x00
0000781a8ffda362  vmovaps xmm12, [rsp+0x20]
0000781a8ffda368  movaps xmm6, xmm10
0000781a8ffda36c  vfmadd231pd xmm6, xmm12, xmm1
0000781a8ffda371  vcmppd xmm3, xmm6, xmm6, 0x03
0000781a8ffda376  vptest xmm3, xmm3
0000781a8ffda37b  jnz 0x0000781A8FFDBE39
0000781a8ffda381  vmovaps xmm1, [rsp+0xB0]
0000781a8ffda38a  vpermilpd xmm1, xmm1, 0x00
0000781a8ffda390  vmovaps xmm12, [rsp+0x40]
0000781a8ffda396  movaps xmm10, xmm5
0000781a8ffda39a  vfmadd231pd xmm10, xmm12, xmm1
0000781a8ffda39f  vcmppd xmm3, xmm10, xmm10, 0x03
0000781a8ffda3a5  vptest xmm3, xmm3
0000781a8ffda3aa  jnz 0x0000781A8FFDBF90
0000781a8ffda3b0  vmovaps xmm1, [rsp+0xB0]
0000781a8ffda3b9  vpermilpd xmm1, xmm1, 0x00
0000781a8ffda3bf  movaps xmm12, xmm7
0000781a8ffda3c3  vfmadd231pd xmm12, xmm15, xmm1
0000781a8ffda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
0000781a8ffda3ce  vptest xmm5, xmm5
0000781a8ffda3d3  jnz 0x0000781A8FFDC0E8
0000781a8ffda3d9  lea rax, [r14+0x60]
0000781a8ffda3dd  movups xmm1, [r13+rax*1]
0000781a8ffda3e3  lea rax, [r14+0x70]
0000781a8ffda3e7  movups xmm15, [r13+rax*1]
0000781a8ffda3ed  movaps [r15+0x150], xmm1
0000781a8ffda3f5  movaps [r15+0x120], xmm15
0000781a8ffda3fd  vmovaps [rsp+0x20], xmm11
0000781a8ffda403  vpermilpd xmm11, xmm11, 0x00
0000781a8ffda409  movaps xmm7, xmm2
0000781a8ffda40c  vfmadd231pd xmm7, xmm9, xmm11
0000781a8ffda411  vcmppd xmm5, xmm7, xmm7, 0x03
0000781a8ffda416  vptest xmm5, xmm5
0000781a8ffda41b  jnz 0x0000781A8FFDC254
0000781a8ffda421  vmovaps xmm11, [rsp+0x20]
0000781a8ffda427  vpermilpd xmm11, xmm11, 0x00
0000781a8ffda42d  movaps xmm9, xmm6
0000781a8ffda431  vfmadd231pd xmm9, xmm1, xmm11
0000781a8ffda436  vcmppd xmm5, xmm9, xmm9, 0x03
0000781a8ffda43c  vptest xmm5, xmm5
0000781a8ffda441  jnz 0x0000781A8FFDC3AB
0000781a8ffda447  vmovaps xmm1, [rsp+0x20]
0000781a8ffda44d  vpermilpd xmm1, xmm1, 0x00
0000781a8ffda453  movaps xmm11, xmm10
0000781a8ffda457  vfmadd231pd xmm11, xmm8, xmm1
0000781a8ffda45c  vcmppd xmm6, xmm11, xmm11, 0x03
0000781a8ffda462  vptest xmm6, xmm6
0000781a8ffda467  jnz 0x0000781A8FFDC503
0000781a8ffda46d  vmovaps xmm1, [rsp+0x20]
0000781a8ffda473  vpermilpd xmm1, xmm1, 0x00
0000781a8ffda479  movaps xmm10, xmm12
0000781a8ffda47d  vfmadd231pd xmm10, xmm13, xmm1
0000781a8ffda482  vcmppd xmm8, xmm10, xmm10, 0x03
0000781a8ffda488  vptest xmm8, xmm8
0000781a8ffda48d  jnz 0x0000781A8FFDC65C
0000781a8ffda493  lea rax, [r14+0x20]
0000781a8ffda497  movups xmm1, [r13+rax*1]
0000781a8ffda49d  lea rax, [r14+0x30]
0000781a8ffda4a1  movups xmm13, [r13+rax*1]
0000781a8ffda4a7  vmovaps xmm12, [rsp+0x90]
0000781a8ffda4b0  vpermilpd xmm12, xmm12, 0x00
0000781a8ffda4b6  movaps xmm8, xmm7
0000781a8ffda4ba  vfmadd231pd xmm8, xmm4, xmm12
0000781a8ffda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
0000781a8ffda4c5  vptest xmm6, xmm6
0000781a8ffda4ca  jnz 0x0000781A8FFDC7C9
0000781a8ffda4d0  vmovaps xmm12, [rsp+0x90]
0000781a8ffda4d9  vpermilpd xmm12, xmm12, 0x00
0000781a8ffda4df  movaps xmm7, xmm9
0000781a8ffda4e3  vfmadd231pd xmm7, xmm14, xmm12
0000781a8ffda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
0000781a8ffda4ed  vptest xmm6, xmm6
0000781a8ffda4f2  jnz 0x0000781A8FFDC921
0000781a8ffda4f8  vmovaps xmm14, [rsp+0x90]
0000781a8ffda501  vpermilpd xmm14, xmm14, 0x00
0000781a8ffda507  movaps xmm12, xmm11
0000781a8ffda50b  vfmadd231pd xmm12, xmm15, xmm14
0000781a8ffda510  vcmppd xmm9, xmm12, xmm12, 0x03
0000781a8ffda516  vptest xmm9, xmm9
0000781a8ffda51b  jnz 0x0000781A8FFDCA79
0000781a8ffda521  vmovaps xmm15, [rsp+0x90]
0000781a8ffda52a  vpermilpd xmm15, xmm15, 0x00
0000781a8ffda530  movaps xmm11, xmm10
0000781a8ffda534  vfmadd231pd xmm11, xmm13, xmm15
0000781a8ffda539  vcmppd xmm14, xmm11, xmm11, 0x03
0000781a8ffda53f  vptest xmm14, xmm14
0000781a8ffda544  jnz 0x0000781A8FFDCBD3
0000781a8ffda54a  lea rax, [r14+0x90]
0000781a8ffda551  movups xmm15, [r13+rax*1]
0000781a8ffda557  lea rax, [r14+0xA0]
0000781a8ffda55e  movups xmm14, [r13+rax*1]
0000781a8ffda564  movaps [r15+0x140], xmm15
0000781a8ffda56c  movaps [r15+0x130], xmm14
0000781a8ffda574  vmovaps xmm13, [rsp+0x10]
0000781a8ffda57a  vpermilpd xmm13, xmm13, 0x00
0000781a8ffda580  movaps xmm10, xmm8
0000781a8ffda584  vfmadd231pd xmm10, xmm1, xmm13
0000781a8ffda589  vcmppd xmm9, xmm10, xmm10, 0x03
0000781a8ffda58f  vptest xmm9, xmm9
0000781a8ffda594  jnz 0x0000781A8FFDCD41
0000781a8ffda59a  movaps [r15+0x220], xmm10
0000781a8ffda5a2  lea rax, [r14+0x10]
0000781a8ffda5a6  movups xmm1, [r13+rax*1]
0000781a8ffda5ac  movaps [r15+0x240], xmm1
0000781a8ffda5b4  vmovaps xmm13, [rsp+0x10]
0000781a8ffda5ba  vpermilpd xmm13, xmm13, 0x00
0000781a8ffda5c0  movaps xmm9, xmm7
0000781a8ffda5c4  vfmadd231pd xmm9, xmm14, xmm13
0000781a8ffda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
0000781a8ffda5cf  vptest xmm8, xmm8
0000781a8ffda5d4  jnz 0x0000781A8FFDCEA4
0000781a8ffda5da  movaps [r15+0x110], xmm9
0000781a8ffda5e2  vmovaps xmm14, [rsp+0x10]
0000781a8ffda5e8  vpermilpd xmm14, xmm14, 0x00
0000781a8ffda5ee  movaps xmm13, xmm12
0000781a8ffda5f2  vfmadd231pd xmm13, xmm15, xmm14
0000781a8ffda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
0000781a8ffda5fd  vptest xmm8, xmm8
0000781a8ffda602  jnz 0x0000781A8FFDCFFD
0000781a8ffda608  movaps [r15+0x170], xmm13
0000781a8ffda610  vmovaps xmm15, [rsp+0x10]
0000781a8ffda616  vpermilpd xmm15, xmm15, 0x00
0000781a8ffda61c  movaps xmm14, xmm11
0000781a8ffda620  vfmadd231pd xmm14, xmm1, xmm15
0000781a8ffda625  vcmppd xmm12, xmm14, xmm14, 0x03
0000781a8ffda62b  vptest xmm12, xmm12
0000781a8ffda630  jnz 0x0000781A8FFDD157
0000781a8ffda636  movaps [r15+0x230], xmm14
0000781a8ffda63e  mov rax, [rsp+0xD0]
0000781a8ffda646  movups [r13+rax*1], xmm9
0000781a8ffda64c  lea r14, [rax+0x10]
0000781a8ffda650  movups [r13+r14*1], xmm13
0000781a8ffda656  lea r14, [rax+0x20]
0000781a8ffda65a  movups [r13+r14*1], xmm10
0000781a8ffda660  lea r14, [rax+0x30]
0000781a8ffda664  movups [r13+r14*1], xmm14
0000781a8ffda66a  mov eax, [r15+0x108]
0000781a8ffda671  sahf
0000781a8ffda672  jnz 0x0000781A8FFDA6A4
0000781a8ffda674  cmp dword ptr [r15+0x318], 0x00
0000781a8ffda67c  jz 0x0000781A8FFD9950
0000781a8ffda682  nop [rax+rax*1], ax
0000781a8ffda68b  nop [rax+rax*1], eax
0000781a8ffda693  mov eax, 0x410664
0000781a8ffda698  mov [r15+0x100], rax
0000781a8ffda69f  jmp 0x0000781A8FDFE110
0000781a8ffda6a4  cmp dword ptr [r15+0x318], 0x00
0000781a8ffda6ac  jz 0x0000781A8FFD6050
0000781a8ffda6b2  nop [rax+rax*1], ax
0000781a8ffda6bb  nop [rax+rax*1], eax
0000781a8ffda6c3  mov eax, 0x4104F0
0000781a8ffda6c8  mov [r15+0x100], rax
0000781a8ffda6cf  jmp 0x0000781A8FDFE110
0000781a8ffda6d4  int3
0000781a8ffda6d5  call 0x0000781A8FEE27E0
0000781a8ffda6da  jmp 0x0000781A8FFD9A10
0000781a8ffda6df  call 0x0000781A8FEE1570
0000781a8ffda6e4  jmp 0x0000781A8FFD9A19
0000781a8ffda6e9  call 0x0000781A8FEE27E0
0000781a8ffda6ee  jmp 0x0000781A8FFD9A62
0000781a8ffda6f3  call 0x0000781A8FEE1570
0000781a8ffda6f8  jmp 0x0000781A8FFD9A6B
0000781a8ffda6fd  call 0x0000781A8FEE27E0
0000781a8ffda702  jmp 0x0000781A8FFD9AEB
0000781a8ffda707  call 0x0000781A8FEE1570
0000781a8ffda70c  jmp 0x0000781A8FFD9AF4
0000781a8ffda711  call 0x0000781A8FE0DC20
0000781a8ffda716  jmp 0x0000781A8FFD9BD5
0000781a8ffda71b  call 0x0000781A8FED64F0
0000781a8ffda720  jmp 0x0000781A8FFD9C04
0000781a8ffda725  call 0x0000781A8FEB47C0
0000781a8ffda72a  jmp 0x0000781A8FFD9C1F
0000781a8ffda72f  sub rsp, 0x08
0000781a8ffda733  push rax
0000781a8ffda734  push rcx
0000781a8ffda735  push rdx
0000781a8ffda736  push rdi
0000781a8ffda737  push rsi
0000781a8ffda738  push r8
0000781a8ffda73a  push r9
0000781a8ffda73c  push r10
0000781a8ffda73e  push r11
0000781a8ffda740  sub rsp, 0xF0
0000781a8ffda747  vmovaps [rsp], xmm0
0000781a8ffda74c  vmovaps [rsp+0x10], xmm1
0000781a8ffda752  vmovaps [rsp+0x20], xmm2
0000781a8ffda758  vmovaps [rsp+0x30], xmm3
0000781a8ffda75e  vmovaps [rsp+0x40], xmm4
0000781a8ffda764  vmovaps [rsp+0x50], xmm5
0000781a8ffda76a  vmovaps [rsp+0x60], xmm6
0000781a8ffda770  vmovaps [rsp+0x70], xmm7
0000781a8ffda776  vmovaps [rsp+0x80], xmm8
0000781a8ffda77f  vmovaps [rsp+0x90], xmm9
0000781a8ffda788  vmovaps [rsp+0xA0], xmm10
0000781a8ffda791  vmovaps [rsp+0xB0], xmm11
0000781a8ffda79a  vmovaps [rsp+0xC0], xmm12
0000781a8ffda7a3  vmovaps [rsp+0xD0], xmm14
0000781a8ffda7ac  vmovaps [rsp+0xE0], xmm15
0000781a8ffda7b5  sub rsp, 0x40
0000781a8ffda7b9  lea rdi, [rsp]
0000781a8ffda7bd  lea rsi, [rsp+0x10]
0000781a8ffda7c2  lea rdx, [rsp+0x20]
0000781a8ffda7c7  lea rcx, [rsp+0x30]
0000781a8ffda7cc  mov r8d, 0x00
0000781a8ffda7d2  lea r9, [r15+0x3A8]
0000781a8ffda7d9  movaps [rdi], xmm13
0000781a8ffda7dd  movaps [rsi], xmm1
0000781a8ffda7e0  movaps [rdx], xmm15
0000781a8ffda7e4  movaps [rcx], xmm14
0000781a8ffda7e8  mov rax, 0x627DDC279A50
0000781a8ffda7f2  call rax
0000781a8ffda7f4  movaps xmm13, [rsp]
0000781a8ffda7f9  add rsp, 0x40
0000781a8ffda7fd  vmovaps xmm0, [rsp]
0000781a8ffda802  vmovaps xmm1, [rsp+0x10]
0000781a8ffda808  vmovaps xmm2, [rsp+0x20]
0000781a8ffda80e  vmovaps xmm3, [rsp+0x30]
0000781a8ffda814  vmovaps xmm4, [rsp+0x40]
0000781a8ffda81a  vmovaps xmm5, [rsp+0x50]
0000781a8ffda820  vmovaps xmm6, [rsp+0x60]
0000781a8ffda826  vmovaps xmm7, [rsp+0x70]
0000781a8ffda82c  vmovaps xmm8, [rsp+0x80]
0000781a8ffda835  vmovaps xmm9, [rsp+0x90]
0000781a8ffda83e  vmovaps xmm10, [rsp+0xA0]
0000781a8ffda847  vmovaps xmm11, [rsp+0xB0]
0000781a8ffda850  vmovaps xmm12, [rsp+0xC0]
0000781a8ffda859  vmovaps xmm14, [rsp+0xD0]
0000781a8ffda862  vmovaps xmm15, [rsp+0xE0]
0000781a8ffda86b  add rsp, 0xF0
0000781a8ffda872  pop r11
0000781a8ffda874  pop r10
0000781a8ffda876  pop r9
0000781a8ffda878  pop r8
0000781a8ffda87a  pop rsi
0000781a8ffda87b  pop rdi
0000781a8ffda87c  pop rdx
0000781a8ffda87d  pop rcx
0000781a8ffda87e  pop rax
0000781a8ffda87f  add rsp, 0x08
0000781a8ffda883  jmp 0x0000781A8FFD9C92
0000781a8ffda888  sub rsp, 0x08
0000781a8ffda88c  push rax
0000781a8ffda88d  push rcx
0000781a8ffda88e  push rdx
0000781a8ffda88f  push rdi
0000781a8ffda890  push rsi
0000781a8ffda891  push r8
0000781a8ffda893  push r9
0000781a8ffda895  push r10
0000781a8ffda897  push r11
0000781a8ffda899  sub rsp, 0xF0
0000781a8ffda8a0  vmovaps [rsp], xmm0
0000781a8ffda8a5  vmovaps [rsp+0x10], xmm1
0000781a8ffda8ab  vmovaps [rsp+0x20], xmm2
0000781a8ffda8b1  vmovaps [rsp+0x30], xmm3
0000781a8ffda8b7  vmovaps [rsp+0x40], xmm4
0000781a8ffda8bd  vmovaps [rsp+0x50], xmm5
0000781a8ffda8c3  vmovaps [rsp+0x60], xmm6
0000781a8ffda8c9  vmovaps [rsp+0x70], xmm7
0000781a8ffda8cf  vmovaps [rsp+0x80], xmm8
0000781a8ffda8d8  vmovaps [rsp+0x90], xmm9
0000781a8ffda8e1  vmovaps [rsp+0xA0], xmm10
0000781a8ffda8ea  vmovaps [rsp+0xB0], xmm11
0000781a8ffda8f3  vmovaps [rsp+0xC0], xmm13
0000781a8ffda8fc  vmovaps [rsp+0xD0], xmm14
0000781a8ffda905  vmovaps [rsp+0xE0], xmm15
0000781a8ffda90e  sub rsp, 0x40
0000781a8ffda912  lea rdi, [rsp]
0000781a8ffda916  lea rsi, [rsp+0x10]
0000781a8ffda91b  lea rdx, [rsp+0x20]
0000781a8ffda920  lea rcx, [rsp+0x30]
0000781a8ffda925  mov r8d, 0x00
0000781a8ffda92b  lea r9, [r15+0x3A8]
0000781a8ffda932  movaps [rdi], xmm12
0000781a8ffda936  movaps [rsi], xmm15
0000781a8ffda93a  movaps [rdx], xmm1
0000781a8ffda93d  movaps [rcx], xmm14
0000781a8ffda941  mov rax, 0x627DDC279A50
0000781a8ffda94b  call rax
0000781a8ffda94d  movaps xmm12, [rsp]
0000781a8ffda952  add rsp, 0x40
0000781a8ffda956  vmovaps xmm0, [rsp]
0000781a8ffda95b  vmovaps xmm1, [rsp+0x10]
0000781a8ffda961  vmovaps xmm2, [rsp+0x20]
0000781a8ffda967  vmovaps xmm3, [rsp+0x30]
0000781a8ffda96d  vmovaps xmm4, [rsp+0x40]
0000781a8ffda973  vmovaps xmm5, [rsp+0x50]
0000781a8ffda979  vmovaps xmm6, [rsp+0x60]
0000781a8ffda97f  vmovaps xmm7, [rsp+0x70]
0000781a8ffda985  vmovaps xmm8, [rsp+0x80]
0000781a8ffda98e  vmovaps xmm9, [rsp+0x90]
0000781a8ffda997  vmovaps xmm10, [rsp+0xA0]
0000781a8ffda9a0  vmovaps xmm11, [rsp+0xB0]
0000781a8ffda9a9  vmovaps xmm13, [rsp+0xC0]
0000781a8ffda9b2  vmovaps xmm14, [rsp+0xD0]
0000781a8ffda9bb  vmovaps xmm15, [rsp+0xE0]
0000781a8ffda9c4  add rsp, 0xF0
0000781a8ffda9cb  pop r11
0000781a8ffda9cd  pop r10
0000781a8ffda9cf  pop r9
0000781a8ffda9d1  pop r8
0000781a8ffda9d3  pop rsi
0000781a8ffda9d4  pop rdi
0000781a8ffda9d5  pop rdx
0000781a8ffda9d6  pop rcx
0000781a8ffda9d7  pop rax
0000781a8ffda9d8  add rsp, 0x08
0000781a8ffda9dc  jmp 0x0000781A8FFD9CC0
0000781a8ffda9e1  call 0x0000781A8FEB52F0
0000781a8ffda9e6  jmp 0x0000781A8FFD9DAC
0000781a8ffda9eb  sub rsp, 0x08
0000781a8ffda9ef  push rax
0000781a8ffda9f0  push rcx
0000781a8ffda9f1  push rdx
0000781a8ffda9f2  push rdi
0000781a8ffda9f3  push rsi
0000781a8ffda9f4  push r8
0000781a8ffda9f6  push r9
0000781a8ffda9f8  push r10
0000781a8ffda9fa  push r11
0000781a8ffda9fc  sub rsp, 0xF0
0000781a8ffdaa03  vmovaps [rsp], xmm0
0000781a8ffdaa08  vmovaps [rsp+0x10], xmm1
0000781a8ffdaa0e  vmovaps [rsp+0x20], xmm2
0000781a8ffdaa14  vmovaps [rsp+0x30], xmm3
0000781a8ffdaa1a  vmovaps [rsp+0x40], xmm4
0000781a8ffdaa20  vmovaps [rsp+0x50], xmm5
0000781a8ffdaa26  vmovaps [rsp+0x60], xmm6
0000781a8ffdaa2c  vmovaps [rsp+0x70], xmm7
0000781a8ffdaa32  vmovaps [rsp+0x80], xmm8
0000781a8ffdaa3b  vmovaps [rsp+0x90], xmm9
0000781a8ffdaa44  vmovaps [rsp+0xA0], xmm10
0000781a8ffdaa4d  vmovaps [rsp+0xB0], xmm11
0000781a8ffdaa56  vmovaps [rsp+0xC0], xmm12
0000781a8ffdaa5f  vmovaps [rsp+0xD0], xmm14
0000781a8ffdaa68  vmovaps [rsp+0xE0], xmm15
0000781a8ffdaa71  sub rsp, 0x40
0000781a8ffdaa75  lea rdi, [rsp]
0000781a8ffdaa79  lea rsi, [rsp+0x10]
0000781a8ffdaa7e  lea rdx, [rsp+0x20]
0000781a8ffdaa83  lea rcx, [rsp+0x30]
0000781a8ffdaa88  mov r8d, 0x00
0000781a8ffdaa8e  lea r9, [r15+0x3A8]
0000781a8ffdaa95  movaps [rdi], xmm13
0000781a8ffdaa99  movaps [rsi], xmm1
0000781a8ffdaa9c  movaps [rdx], xmm15
0000781a8ffdaaa0  movaps [rcx], xmm14
0000781a8ffdaaa4  mov rax, 0x627DDC279A50
0000781a8ffdaaae  call rax
0000781a8ffdaab0  movaps xmm13, [rsp]
0000781a8ffdaab5  add rsp, 0x40
0000781a8ffdaab9  vmovaps xmm0, [rsp]
0000781a8ffdaabe  vmovaps xmm1, [rsp+0x10]
0000781a8ffdaac4  vmovaps xmm2, [rsp+0x20]
0000781a8ffdaaca  vmovaps xmm3, [rsp+0x30]
0000781a8ffdaad0  vmovaps xmm4, [rsp+0x40]
0000781a8ffdaad6  vmovaps xmm5, [rsp+0x50]
0000781a8ffdaadc  vmovaps xmm6, [rsp+0x60]
0000781a8ffdaae2  vmovaps xmm7, [rsp+0x70]
0000781a8ffdaae8  vmovaps xmm8, [rsp+0x80]
0000781a8ffdaaf1  vmovaps xmm9, [rsp+0x90]
0000781a8ffdaafa  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdab03  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdab0c  vmovaps xmm12, [rsp+0xC0]
0000781a8ffdab15  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdab1e  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdab27  add rsp, 0xF0
0000781a8ffdab2e  pop r11
0000781a8ffdab30  pop r10
0000781a8ffdab32  pop r9
0000781a8ffdab34  pop r8
0000781a8ffdab36  pop rsi
0000781a8ffdab37  pop rdi
0000781a8ffdab38  pop rdx
0000781a8ffdab39  pop rcx
0000781a8ffdab3a  pop rax
0000781a8ffdab3b  add rsp, 0x08
0000781a8ffdab3f  jmp 0x0000781A8FFD9E21
0000781a8ffdab44  call 0x0000781A8FDFF430
0000781a8ffdab49  jmp 0x0000781A8FFD9E2E
0000781a8ffdab4e  sub rsp, 0x08
0000781a8ffdab52  push rax
0000781a8ffdab53  push rcx
0000781a8ffdab54  push rdx
0000781a8ffdab55  push rdi
0000781a8ffdab56  push rsi
0000781a8ffdab57  push r8
0000781a8ffdab59  push r9
0000781a8ffdab5b  push r10
0000781a8ffdab5d  push r11
0000781a8ffdab5f  sub rsp, 0xF0
0000781a8ffdab66  vmovaps [rsp], xmm0
0000781a8ffdab6b  vmovaps [rsp+0x10], xmm1
0000781a8ffdab71  vmovaps [rsp+0x20], xmm2
0000781a8ffdab77  vmovaps [rsp+0x30], xmm3
0000781a8ffdab7d  vmovaps [rsp+0x40], xmm4
0000781a8ffdab83  vmovaps [rsp+0x50], xmm5
0000781a8ffdab89  vmovaps [rsp+0x60], xmm6
0000781a8ffdab8f  vmovaps [rsp+0x70], xmm7
0000781a8ffdab95  vmovaps [rsp+0x80], xmm8
0000781a8ffdab9e  vmovaps [rsp+0x90], xmm9
0000781a8ffdaba7  vmovaps [rsp+0xA0], xmm10
0000781a8ffdabb0  vmovaps [rsp+0xB0], xmm11
0000781a8ffdabb9  vmovaps [rsp+0xC0], xmm13
0000781a8ffdabc2  vmovaps [rsp+0xD0], xmm14
0000781a8ffdabcb  vmovaps [rsp+0xE0], xmm15
0000781a8ffdabd4  sub rsp, 0x40
0000781a8ffdabd8  lea rdi, [rsp]
0000781a8ffdabdc  lea rsi, [rsp+0x10]
0000781a8ffdabe1  lea rdx, [rsp+0x20]
0000781a8ffdabe6  lea rcx, [rsp+0x30]
0000781a8ffdabeb  mov r8d, 0x00
0000781a8ffdabf1  lea r9, [r15+0x3A8]
0000781a8ffdabf8  movaps [rdi], xmm12
0000781a8ffdabfc  movaps [rsi], xmm15
0000781a8ffdac00  movaps [rdx], xmm1
0000781a8ffdac03  movaps [rcx], xmm14
0000781a8ffdac07  mov rax, 0x627DDC279A50
0000781a8ffdac11  call rax
0000781a8ffdac13  movaps xmm12, [rsp]
0000781a8ffdac18  add rsp, 0x40
0000781a8ffdac1c  vmovaps xmm0, [rsp]
0000781a8ffdac21  vmovaps xmm1, [rsp+0x10]
0000781a8ffdac27  vmovaps xmm2, [rsp+0x20]
0000781a8ffdac2d  vmovaps xmm3, [rsp+0x30]
0000781a8ffdac33  vmovaps xmm4, [rsp+0x40]
0000781a8ffdac39  vmovaps xmm5, [rsp+0x50]
0000781a8ffdac3f  vmovaps xmm6, [rsp+0x60]
0000781a8ffdac45  vmovaps xmm7, [rsp+0x70]
0000781a8ffdac4b  vmovaps xmm8, [rsp+0x80]
0000781a8ffdac54  vmovaps xmm9, [rsp+0x90]
0000781a8ffdac5d  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdac66  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdac6f  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdac78  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdac81  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdac8a  add rsp, 0xF0
0000781a8ffdac91  pop r11
0000781a8ffdac93  pop r10
0000781a8ffdac95  pop r9
0000781a8ffdac97  pop r8
0000781a8ffdac99  pop rsi
0000781a8ffdac9a  pop rdi
0000781a8ffdac9b  pop rdx
0000781a8ffdac9c  pop rcx
0000781a8ffdac9d  pop rax
0000781a8ffdac9e  add rsp, 0x08
0000781a8ffdaca2  jmp 0x0000781A8FFD9E5A
0000781a8ffdaca7  sub rsp, 0x08
0000781a8ffdacab  push rax
0000781a8ffdacac  push rcx
0000781a8ffdacad  push rdx
0000781a8ffdacae  push rdi
0000781a8ffdacaf  push rsi
0000781a8ffdacb0  push r8
0000781a8ffdacb2  push r9
0000781a8ffdacb4  push r10
0000781a8ffdacb6  push r11
0000781a8ffdacb8  sub rsp, 0xF0
0000781a8ffdacbf  vmovaps [rsp], xmm0
0000781a8ffdacc4  vmovaps [rsp+0x10], xmm1
0000781a8ffdacca  vmovaps [rsp+0x20], xmm2
0000781a8ffdacd0  vmovaps [rsp+0x30], xmm3
0000781a8ffdacd6  vmovaps [rsp+0x40], xmm4
0000781a8ffdacdc  vmovaps [rsp+0x50], xmm5
0000781a8ffdace2  vmovaps [rsp+0x60], xmm6
0000781a8ffdace8  vmovaps [rsp+0x70], xmm7
0000781a8ffdacee  vmovaps [rsp+0x80], xmm8
0000781a8ffdacf7  vmovaps [rsp+0x90], xmm9
0000781a8ffdad00  vmovaps [rsp+0xA0], xmm10
0000781a8ffdad09  vmovaps [rsp+0xB0], xmm11
0000781a8ffdad12  vmovaps [rsp+0xC0], xmm12
0000781a8ffdad1b  vmovaps [rsp+0xD0], xmm14
0000781a8ffdad24  vmovaps [rsp+0xE0], xmm15
0000781a8ffdad2d  sub rsp, 0x40
0000781a8ffdad31  lea rdi, [rsp]
0000781a8ffdad35  lea rsi, [rsp+0x10]
0000781a8ffdad3a  lea rdx, [rsp+0x20]
0000781a8ffdad3f  lea rcx, [rsp+0x30]
0000781a8ffdad44  mov r8d, 0x00
0000781a8ffdad4a  lea r9, [r15+0x3A8]
0000781a8ffdad51  movaps [rdi], xmm13
0000781a8ffdad55  movaps [rsi], xmm1
0000781a8ffdad58  movaps [rdx], xmm15
0000781a8ffdad5c  movaps [rcx], xmm14
0000781a8ffdad60  mov rax, 0x627DDC279A50
0000781a8ffdad6a  call rax
0000781a8ffdad6c  movaps xmm13, [rsp]
0000781a8ffdad71  add rsp, 0x40
0000781a8ffdad75  vmovaps xmm0, [rsp]
0000781a8ffdad7a  vmovaps xmm1, [rsp+0x10]
0000781a8ffdad80  vmovaps xmm2, [rsp+0x20]
0000781a8ffdad86  vmovaps xmm3, [rsp+0x30]
0000781a8ffdad8c  vmovaps xmm4, [rsp+0x40]
0000781a8ffdad92  vmovaps xmm5, [rsp+0x50]
0000781a8ffdad98  vmovaps xmm6, [rsp+0x60]
0000781a8ffdad9e  vmovaps xmm7, [rsp+0x70]
0000781a8ffdada4  vmovaps xmm8, [rsp+0x80]
0000781a8ffdadad  vmovaps xmm9, [rsp+0x90]
0000781a8ffdadb6  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdadbf  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdadc8  vmovaps xmm12, [rsp+0xC0]
0000781a8ffdadd1  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdadda  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdade3  add rsp, 0xF0
0000781a8ffdadea  pop r11
0000781a8ffdadec  pop r10
0000781a8ffdadee  pop r9
0000781a8ffdadf0  pop r8
0000781a8ffdadf2  pop rsi
0000781a8ffdadf3  pop rdi
0000781a8ffdadf4  pop rdx
0000781a8ffdadf5  pop rcx
0000781a8ffdadf6  pop rax
0000781a8ffdadf7  add rsp, 0x08
0000781a8ffdadfb  jmp 0x0000781A8FFD9FEA
0000781a8ffdae00  sub rsp, 0x08
0000781a8ffdae04  push rax
0000781a8ffdae05  push rcx
0000781a8ffdae06  push rdx
0000781a8ffdae07  push rdi
0000781a8ffdae08  push rsi
0000781a8ffdae09  push r8
0000781a8ffdae0b  push r9
0000781a8ffdae0d  push r10
0000781a8ffdae0f  push r11
0000781a8ffdae11  sub rsp, 0xF0
0000781a8ffdae18  vmovaps [rsp], xmm0
0000781a8ffdae1d  vmovaps [rsp+0x10], xmm1
0000781a8ffdae23  vmovaps [rsp+0x20], xmm2
0000781a8ffdae29  vmovaps [rsp+0x30], xmm3
0000781a8ffdae2f  vmovaps [rsp+0x40], xmm4
0000781a8ffdae35  vmovaps [rsp+0x50], xmm5
0000781a8ffdae3b  vmovaps [rsp+0x60], xmm6
0000781a8ffdae41  vmovaps [rsp+0x70], xmm7
0000781a8ffdae47  vmovaps [rsp+0x80], xmm8
0000781a8ffdae50  vmovaps [rsp+0x90], xmm9
0000781a8ffdae59  vmovaps [rsp+0xA0], xmm10
0000781a8ffdae62  vmovaps [rsp+0xB0], xmm11
0000781a8ffdae6b  vmovaps [rsp+0xC0], xmm12
0000781a8ffdae74  vmovaps [rsp+0xD0], xmm13
0000781a8ffdae7d  vmovaps [rsp+0xE0], xmm15
0000781a8ffdae86  sub rsp, 0x40
0000781a8ffdae8a  lea rdi, [rsp]
0000781a8ffdae8e  lea rsi, [rsp+0x10]
0000781a8ffdae93  lea rdx, [rsp+0x20]
0000781a8ffdae98  lea rcx, [rsp+0x30]
0000781a8ffdae9d  mov r8d, 0x00
0000781a8ffdaea3  lea r9, [r15+0x3A8]
0000781a8ffdaeaa  movaps [rdi], xmm14
0000781a8ffdaeae  movaps [rsi], xmm15
0000781a8ffdaeb2  movaps [rdx], xmm2
0000781a8ffdaeb5  movaps [rcx], xmm1
0000781a8ffdaeb8  mov rax, 0x627DDC279A50
0000781a8ffdaec2  call rax
0000781a8ffdaec4  movaps xmm14, [rsp]
0000781a8ffdaec9  add rsp, 0x40
0000781a8ffdaecd  vmovaps xmm0, [rsp]
0000781a8ffdaed2  vmovaps xmm1, [rsp+0x10]
0000781a8ffdaed8  vmovaps xmm2, [rsp+0x20]
0000781a8ffdaede  vmovaps xmm3, [rsp+0x30]
0000781a8ffdaee4  vmovaps xmm4, [rsp+0x40]
0000781a8ffdaeea  vmovaps xmm5, [rsp+0x50]
0000781a8ffdaef0  vmovaps xmm6, [rsp+0x60]
0000781a8ffdaef6  vmovaps xmm7, [rsp+0x70]
0000781a8ffdaefc  vmovaps xmm8, [rsp+0x80]
0000781a8ffdaf05  vmovaps xmm9, [rsp+0x90]
0000781a8ffdaf0e  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdaf17  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdaf20  vmovaps xmm12, [rsp+0xC0]
0000781a8ffdaf29  vmovaps xmm13, [rsp+0xD0]
0000781a8ffdaf32  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdaf3b  add rsp, 0xF0
0000781a8ffdaf42  pop r11
0000781a8ffdaf44  pop r10
0000781a8ffdaf46  pop r9
0000781a8ffdaf48  pop r8
0000781a8ffdaf4a  pop rsi
0000781a8ffdaf4b  pop rdi
0000781a8ffdaf4c  pop rdx
0000781a8ffdaf4d  pop rcx
0000781a8ffdaf4e  pop rax
0000781a8ffdaf4f  add rsp, 0x08
0000781a8ffdaf53  jmp 0x0000781A8FFDA01C
0000781a8ffdaf58  sub rsp, 0x08
0000781a8ffdaf5c  push rax
0000781a8ffdaf5d  push rcx
0000781a8ffdaf5e  push rdx
0000781a8ffdaf5f  push rdi
0000781a8ffdaf60  push rsi
0000781a8ffdaf61  push r8
0000781a8ffdaf63  push r9
0000781a8ffdaf65  push r10
0000781a8ffdaf67  push r11
0000781a8ffdaf69  sub rsp, 0xF0
0000781a8ffdaf70  vmovaps [rsp], xmm0
0000781a8ffdaf75  vmovaps [rsp+0x10], xmm1
0000781a8ffdaf7b  vmovaps [rsp+0x20], xmm3
0000781a8ffdaf81  vmovaps [rsp+0x30], xmm4
0000781a8ffdaf87  vmovaps [rsp+0x40], xmm5
0000781a8ffdaf8d  vmovaps [rsp+0x50], xmm6
0000781a8ffdaf93  vmovaps [rsp+0x60], xmm7
0000781a8ffdaf99  vmovaps [rsp+0x70], xmm8
0000781a8ffdaf9f  vmovaps [rsp+0x80], xmm9
0000781a8ffdafa8  vmovaps [rsp+0x90], xmm10
0000781a8ffdafb1  vmovaps [rsp+0xA0], xmm11
0000781a8ffdafba  vmovaps [rsp+0xB0], xmm12
0000781a8ffdafc3  vmovaps [rsp+0xC0], xmm13
0000781a8ffdafcc  vmovaps [rsp+0xD0], xmm14
0000781a8ffdafd5  vmovaps [rsp+0xE0], xmm15
0000781a8ffdafde  sub rsp, 0x40
0000781a8ffdafe2  lea rdi, [rsp]
0000781a8ffdafe6  lea rsi, [rsp+0x10]
0000781a8ffdafeb  lea rdx, [rsp+0x20]
0000781a8ffdaff0  lea rcx, [rsp+0x30]
0000781a8ffdaff5  mov r8d, 0x00
0000781a8ffdaffb  lea r9, [r15+0x3A8]
0000781a8ffdb002  movaps [rdi], xmm2
0000781a8ffdb005  movaps [rsi], xmm15
0000781a8ffdb009  movaps [rdx], xmm12
0000781a8ffdb00d  movaps [rcx], xmm1
0000781a8ffdb010  mov rax, 0x627DDC279A50
0000781a8ffdb01a  call rax
0000781a8ffdb01c  movaps xmm2, [rsp]
0000781a8ffdb020  add rsp, 0x40
0000781a8ffdb024  vmovaps xmm0, [rsp]
0000781a8ffdb029  vmovaps xmm1, [rsp+0x10]
0000781a8ffdb02f  vmovaps xmm3, [rsp+0x20]
0000781a8ffdb035  vmovaps xmm4, [rsp+0x30]
0000781a8ffdb03b  vmovaps xmm5, [rsp+0x40]
0000781a8ffdb041  vmovaps xmm6, [rsp+0x50]
0000781a8ffdb047  vmovaps xmm7, [rsp+0x60]
0000781a8ffdb04d  vmovaps xmm8, [rsp+0x70]
0000781a8ffdb053  vmovaps xmm9, [rsp+0x80]
0000781a8ffdb05c  vmovaps xmm10, [rsp+0x90]
0000781a8ffdb065  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdb06e  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdb077  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdb080  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdb089  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdb092  add rsp, 0xF0
0000781a8ffdb099  pop r11
0000781a8ffdb09b  pop r10
0000781a8ffdb09d  pop r9
0000781a8ffdb09f  pop r8
0000781a8ffdb0a1  pop rsi
0000781a8ffdb0a2  pop rdi
0000781a8ffdb0a3  pop rdx
0000781a8ffdb0a4  pop rcx
0000781a8ffdb0a5  pop rax
0000781a8ffdb0a6  add rsp, 0x08
0000781a8ffdb0aa  jmp 0x0000781A8FFDA059
0000781a8ffdb0af  sub rsp, 0x08
0000781a8ffdb0b3  push rax
0000781a8ffdb0b4  push rcx
0000781a8ffdb0b5  push rdx
0000781a8ffdb0b6  push rdi
0000781a8ffdb0b7  push rsi
0000781a8ffdb0b8  push r8
0000781a8ffdb0ba  push r9
0000781a8ffdb0bc  push r10
0000781a8ffdb0be  push r11
0000781a8ffdb0c0  sub rsp, 0xF0
0000781a8ffdb0c7  vmovaps [rsp], xmm0
0000781a8ffdb0cc  vmovaps [rsp+0x10], xmm1
0000781a8ffdb0d2  vmovaps [rsp+0x20], xmm2
0000781a8ffdb0d8  vmovaps [rsp+0x30], xmm3
0000781a8ffdb0de  vmovaps [rsp+0x40], xmm4
0000781a8ffdb0e4  vmovaps [rsp+0x50], xmm5
0000781a8ffdb0ea  vmovaps [rsp+0x60], xmm6
0000781a8ffdb0f0  vmovaps [rsp+0x70], xmm7
0000781a8ffdb0f6  vmovaps [rsp+0x80], xmm8
0000781a8ffdb0ff  vmovaps [rsp+0x90], xmm9
0000781a8ffdb108  vmovaps [rsp+0xA0], xmm10
0000781a8ffdb111  vmovaps [rsp+0xB0], xmm11
0000781a8ffdb11a  vmovaps [rsp+0xC0], xmm13
0000781a8ffdb123  vmovaps [rsp+0xD0], xmm14
0000781a8ffdb12c  vmovaps [rsp+0xE0], xmm15
0000781a8ffdb135  sub rsp, 0x40
0000781a8ffdb139  lea rdi, [rsp]
0000781a8ffdb13d  lea rsi, [rsp+0x10]
0000781a8ffdb142  lea rdx, [rsp+0x20]
0000781a8ffdb147  lea rcx, [rsp+0x30]
0000781a8ffdb14c  mov r8d, 0x00
0000781a8ffdb152  lea r9, [r15+0x3A8]
0000781a8ffdb159  movaps [rdi], xmm12
0000781a8ffdb15d  movaps [rsi], xmm14
0000781a8ffdb161  movaps [rdx], xmm3
0000781a8ffdb164  movaps [rcx], xmm15
0000781a8ffdb168  mov rax, 0x627DDC279A50
0000781a8ffdb172  call rax
0000781a8ffdb174  movaps xmm12, [rsp]
0000781a8ffdb179  add rsp, 0x40
0000781a8ffdb17d  vmovaps xmm0, [rsp]
0000781a8ffdb182  vmovaps xmm1, [rsp+0x10]
0000781a8ffdb188  vmovaps xmm2, [rsp+0x20]
0000781a8ffdb18e  vmovaps xmm3, [rsp+0x30]
0000781a8ffdb194  vmovaps xmm4, [rsp+0x40]
0000781a8ffdb19a  vmovaps xmm5, [rsp+0x50]
0000781a8ffdb1a0  vmovaps xmm6, [rsp+0x60]
0000781a8ffdb1a6  vmovaps xmm7, [rsp+0x70]
0000781a8ffdb1ac  vmovaps xmm8, [rsp+0x80]
0000781a8ffdb1b5  vmovaps xmm9, [rsp+0x90]
0000781a8ffdb1be  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdb1c7  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdb1d0  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdb1d9  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdb1e2  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdb1eb  add rsp, 0xF0
0000781a8ffdb1f2  pop r11
0000781a8ffdb1f4  pop r10
0000781a8ffdb1f6  pop r9
0000781a8ffdb1f8  pop r8
0000781a8ffdb1fa  pop rsi
0000781a8ffdb1fb  pop rdi
0000781a8ffdb1fc  pop rdx
0000781a8ffdb1fd  pop rcx
0000781a8ffdb1fe  pop rax
0000781a8ffdb1ff  add rsp, 0x08
0000781a8ffdb203  jmp 0x0000781A8FFDA0B3
0000781a8ffdb208  sub rsp, 0x08
0000781a8ffdb20c  push rax
0000781a8ffdb20d  push rcx
0000781a8ffdb20e  push rdx
0000781a8ffdb20f  push rdi
0000781a8ffdb210  push rsi
0000781a8ffdb211  push r8
0000781a8ffdb213  push r9
0000781a8ffdb215  push r10
0000781a8ffdb217  push r11
0000781a8ffdb219  sub rsp, 0xF0
0000781a8ffdb220  vmovaps [rsp], xmm0
0000781a8ffdb225  vmovaps [rsp+0x10], xmm1
0000781a8ffdb22b  vmovaps [rsp+0x20], xmm2
0000781a8ffdb231  vmovaps [rsp+0x30], xmm3
0000781a8ffdb237  vmovaps [rsp+0x40], xmm4
0000781a8ffdb23d  vmovaps [rsp+0x50], xmm5
0000781a8ffdb243  vmovaps [rsp+0x60], xmm6
0000781a8ffdb249  vmovaps [rsp+0x70], xmm7
0000781a8ffdb24f  vmovaps [rsp+0x80], xmm8
0000781a8ffdb258  vmovaps [rsp+0x90], xmm10
0000781a8ffdb261  vmovaps [rsp+0xA0], xmm11
0000781a8ffdb26a  vmovaps [rsp+0xB0], xmm12
0000781a8ffdb273  vmovaps [rsp+0xC0], xmm13
0000781a8ffdb27c  vmovaps [rsp+0xD0], xmm14
0000781a8ffdb285  vmovaps [rsp+0xE0], xmm15
0000781a8ffdb28e  sub rsp, 0x40
0000781a8ffdb292  lea rdi, [rsp]
0000781a8ffdb296  lea rsi, [rsp+0x10]
0000781a8ffdb29b  lea rdx, [rsp+0x20]
0000781a8ffdb2a0  lea rcx, [rsp+0x30]
0000781a8ffdb2a5  mov r8d, 0x00
0000781a8ffdb2ab  lea r9, [r15+0x3A8]
0000781a8ffdb2b2  movaps [rdi], xmm9
0000781a8ffdb2b6  movaps [rsi], xmm13
0000781a8ffdb2ba  movaps [rdx], xmm14
0000781a8ffdb2be  movaps [rcx], xmm6
0000781a8ffdb2c1  mov rax, 0x627DDC279A50
0000781a8ffdb2cb  call rax
0000781a8ffdb2cd  movaps xmm9, [rsp]
0000781a8ffdb2d2  add rsp, 0x40
0000781a8ffdb2d6  vmovaps xmm0, [rsp]
0000781a8ffdb2db  vmovaps xmm1, [rsp+0x10]
0000781a8ffdb2e1  vmovaps xmm2, [rsp+0x20]
0000781a8ffdb2e7  vmovaps xmm3, [rsp+0x30]
0000781a8ffdb2ed  vmovaps xmm4, [rsp+0x40]
0000781a8ffdb2f3  vmovaps xmm5, [rsp+0x50]
0000781a8ffdb2f9  vmovaps xmm6, [rsp+0x60]
0000781a8ffdb2ff  vmovaps xmm7, [rsp+0x70]
0000781a8ffdb305  vmovaps xmm8, [rsp+0x80]
0000781a8ffdb30e  vmovaps xmm10, [rsp+0x90]
0000781a8ffdb317  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdb320  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdb329  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdb332  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdb33b  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdb344  add rsp, 0xF0
0000781a8ffdb34b  pop r11
0000781a8ffdb34d  pop r10
0000781a8ffdb34f  pop r9
0000781a8ffdb351  pop r8
0000781a8ffdb353  pop rsi
0000781a8ffdb354  pop rdi
0000781a8ffdb355  pop rdx
0000781a8ffdb356  pop rcx
0000781a8ffdb357  pop rax
0000781a8ffdb358  add rsp, 0x08
0000781a8ffdb35c  jmp 0x0000781A8FFDA15D
0000781a8ffdb361  sub rsp, 0x08
0000781a8ffdb365  push rax
0000781a8ffdb366  push rcx
0000781a8ffdb367  push rdx
0000781a8ffdb368  push rdi
0000781a8ffdb369  push rsi
0000781a8ffdb36a  push r8
0000781a8ffdb36c  push r9
0000781a8ffdb36e  push r10
0000781a8ffdb370  push r11
0000781a8ffdb372  sub rsp, 0xF0
0000781a8ffdb379  vmovaps [rsp], xmm0
0000781a8ffdb37e  vmovaps [rsp+0x10], xmm1
0000781a8ffdb384  vmovaps [rsp+0x20], xmm2
0000781a8ffdb38a  vmovaps [rsp+0x30], xmm4
0000781a8ffdb390  vmovaps [rsp+0x40], xmm5
0000781a8ffdb396  vmovaps [rsp+0x50], xmm6
0000781a8ffdb39c  vmovaps [rsp+0x60], xmm7
0000781a8ffdb3a2  vmovaps [rsp+0x70], xmm8
0000781a8ffdb3a8  vmovaps [rsp+0x80], xmm9
0000781a8ffdb3b1  vmovaps [rsp+0x90], xmm10
0000781a8ffdb3ba  vmovaps [rsp+0xA0], xmm11
0000781a8ffdb3c3  vmovaps [rsp+0xB0], xmm12
0000781a8ffdb3cc  vmovaps [rsp+0xC0], xmm13
0000781a8ffdb3d5  vmovaps [rsp+0xD0], xmm14
0000781a8ffdb3de  vmovaps [rsp+0xE0], xmm15
0000781a8ffdb3e7  sub rsp, 0x40
0000781a8ffdb3eb  lea rdi, [rsp]
0000781a8ffdb3ef  lea rsi, [rsp+0x10]
0000781a8ffdb3f4  lea rdx, [rsp+0x20]
0000781a8ffdb3f9  lea rcx, [rsp+0x30]
0000781a8ffdb3fe  mov r8d, 0x00
0000781a8ffdb404  lea r9, [r15+0x3A8]
0000781a8ffdb40b  movaps [rdi], xmm3
0000781a8ffdb40e  movaps [rsi], xmm13
0000781a8ffdb412  movaps [rdx], xmm6
0000781a8ffdb415  movaps [rcx], xmm14
0000781a8ffdb419  mov rax, 0x627DDC279A50
0000781a8ffdb423  call rax
0000781a8ffdb425  movaps xmm3, [rsp]
0000781a8ffdb429  add rsp, 0x40
0000781a8ffdb42d  vmovaps xmm0, [rsp]
0000781a8ffdb432  vmovaps xmm1, [rsp+0x10]
0000781a8ffdb438  vmovaps xmm2, [rsp+0x20]
0000781a8ffdb43e  vmovaps xmm4, [rsp+0x30]
0000781a8ffdb444  vmovaps xmm5, [rsp+0x40]
0000781a8ffdb44a  vmovaps xmm6, [rsp+0x50]
0000781a8ffdb450  vmovaps xmm7, [rsp+0x60]
0000781a8ffdb456  vmovaps xmm8, [rsp+0x70]
0000781a8ffdb45c  vmovaps xmm9, [rsp+0x80]
0000781a8ffdb465  vmovaps xmm10, [rsp+0x90]
0000781a8ffdb46e  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdb477  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdb480  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdb489  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdb492  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdb49b  add rsp, 0xF0
0000781a8ffdb4a2  pop r11
0000781a8ffdb4a4  pop r10
0000781a8ffdb4a6  pop r9
0000781a8ffdb4a8  pop r8
0000781a8ffdb4aa  pop rsi
0000781a8ffdb4ab  pop rdi
0000781a8ffdb4ac  pop rdx
0000781a8ffdb4ad  pop rcx
0000781a8ffdb4ae  pop rax
0000781a8ffdb4af  add rsp, 0x08
0000781a8ffdb4b3  jmp 0x0000781A8FFDA19A
0000781a8ffdb4b8  sub rsp, 0x08
0000781a8ffdb4bc  push rax
0000781a8ffdb4bd  push rcx
0000781a8ffdb4be  push rdx
0000781a8ffdb4bf  push rdi
0000781a8ffdb4c0  push rsi
0000781a8ffdb4c1  push r8
0000781a8ffdb4c3  push r9
0000781a8ffdb4c5  push r10
0000781a8ffdb4c7  push r11
0000781a8ffdb4c9  sub rsp, 0xF0
0000781a8ffdb4d0  vmovaps [rsp], xmm0
0000781a8ffdb4d5  vmovaps [rsp+0x10], xmm1
0000781a8ffdb4db  vmovaps [rsp+0x20], xmm2
0000781a8ffdb4e1  vmovaps [rsp+0x30], xmm3
0000781a8ffdb4e7  vmovaps [rsp+0x40], xmm4
0000781a8ffdb4ed  vmovaps [rsp+0x50], xmm5
0000781a8ffdb4f3  vmovaps [rsp+0x60], xmm7
0000781a8ffdb4f9  vmovaps [rsp+0x70], xmm8
0000781a8ffdb4ff  vmovaps [rsp+0x80], xmm9
0000781a8ffdb508  vmovaps [rsp+0x90], xmm10
0000781a8ffdb511  vmovaps [rsp+0xA0], xmm11
0000781a8ffdb51a  vmovaps [rsp+0xB0], xmm12
0000781a8ffdb523  vmovaps [rsp+0xC0], xmm13
0000781a8ffdb52c  vmovaps [rsp+0xD0], xmm14
0000781a8ffdb535  vmovaps [rsp+0xE0], xmm15
0000781a8ffdb53e  sub rsp, 0x40
0000781a8ffdb542  lea rdi, [rsp]
0000781a8ffdb546  lea rsi, [rsp+0x10]
0000781a8ffdb54b  lea rdx, [rsp+0x20]
0000781a8ffdb550  lea rcx, [rsp+0x30]
0000781a8ffdb555  mov r8d, 0x00
0000781a8ffdb55b  lea r9, [r15+0x3A8]
0000781a8ffdb562  movaps [rdi], xmm6
0000781a8ffdb565  movaps [rsi], xmm2
0000781a8ffdb568  movaps [rdx], xmm14
0000781a8ffdb56c  movaps [rcx], xmm1
0000781a8ffdb56f  mov rax, 0x627DDC279A50
0000781a8ffdb579  call rax
0000781a8ffdb57b  movaps xmm6, [rsp]
0000781a8ffdb57f  add rsp, 0x40
0000781a8ffdb583  vmovaps xmm0, [rsp]
0000781a8ffdb588  vmovaps xmm1, [rsp+0x10]
0000781a8ffdb58e  vmovaps xmm2, [rsp+0x20]
0000781a8ffdb594  vmovaps xmm3, [rsp+0x30]
0000781a8ffdb59a  vmovaps xmm4, [rsp+0x40]
0000781a8ffdb5a0  vmovaps xmm5, [rsp+0x50]
0000781a8ffdb5a6  vmovaps xmm7, [rsp+0x60]
0000781a8ffdb5ac  vmovaps xmm8, [rsp+0x70]
0000781a8ffdb5b2  vmovaps xmm9, [rsp+0x80]
0000781a8ffdb5bb  vmovaps xmm10, [rsp+0x90]
0000781a8ffdb5c4  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdb5cd  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdb5d6  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdb5df  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdb5e8  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdb5f1  add rsp, 0xF0
0000781a8ffdb5f8  pop r11
0000781a8ffdb5fa  pop r10
0000781a8ffdb5fc  pop r9
0000781a8ffdb5fe  pop r8
0000781a8ffdb600  pop rsi
0000781a8ffdb601  pop rdi
0000781a8ffdb602  pop rdx
0000781a8ffdb603  pop rcx
0000781a8ffdb604  pop rax
0000781a8ffdb605  add rsp, 0x08
0000781a8ffdb609  jmp 0x0000781A8FFDA1C7
0000781a8ffdb60e  sub rsp, 0x08
0000781a8ffdb612  push rax
0000781a8ffdb613  push rcx
0000781a8ffdb614  push rdx
0000781a8ffdb615  push rdi
0000781a8ffdb616  push rsi
0000781a8ffdb617  push r8
0000781a8ffdb619  push r9
0000781a8ffdb61b  push r10
0000781a8ffdb61d  push r11
0000781a8ffdb61f  sub rsp, 0xF0
0000781a8ffdb626  vmovaps [rsp], xmm0
0000781a8ffdb62b  vmovaps [rsp+0x10], xmm1
0000781a8ffdb631  vmovaps [rsp+0x20], xmm2
0000781a8ffdb637  vmovaps [rsp+0x30], xmm3
0000781a8ffdb63d  vmovaps [rsp+0x40], xmm4
0000781a8ffdb643  vmovaps [rsp+0x50], xmm5
0000781a8ffdb649  vmovaps [rsp+0x60], xmm6
0000781a8ffdb64f  vmovaps [rsp+0x70], xmm7
0000781a8ffdb655  vmovaps [rsp+0x80], xmm8
0000781a8ffdb65e  vmovaps [rsp+0x90], xmm9
0000781a8ffdb667  vmovaps [rsp+0xA0], xmm10
0000781a8ffdb670  vmovaps [rsp+0xB0], xmm11
0000781a8ffdb679  vmovaps [rsp+0xC0], xmm12
0000781a8ffdb682  vmovaps [rsp+0xD0], xmm14
0000781a8ffdb68b  vmovaps [rsp+0xE0], xmm15
0000781a8ffdb694  sub rsp, 0x40
0000781a8ffdb698  lea rdi, [rsp]
0000781a8ffdb69c  lea rsi, [rsp+0x10]
0000781a8ffdb6a1  lea rdx, [rsp+0x20]
0000781a8ffdb6a6  lea rcx, [rsp+0x30]
0000781a8ffdb6ab  mov r8d, 0x00
0000781a8ffdb6b1  lea r9, [r15+0x3A8]
0000781a8ffdb6b8  movaps [rdi], xmm13
0000781a8ffdb6bc  movaps [rsi], xmm12
0000781a8ffdb6c0  movaps [rdx], xmm14
0000781a8ffdb6c4  movaps [rcx], xmm1
0000781a8ffdb6c7  mov rax, 0x627DDC279A50
0000781a8ffdb6d1  call rax
0000781a8ffdb6d3  movaps xmm13, [rsp]
0000781a8ffdb6d8  add rsp, 0x40
0000781a8ffdb6dc  vmovaps xmm0, [rsp]
0000781a8ffdb6e1  vmovaps xmm1, [rsp+0x10]
0000781a8ffdb6e7  vmovaps xmm2, [rsp+0x20]
0000781a8ffdb6ed  vmovaps xmm3, [rsp+0x30]
0000781a8ffdb6f3  vmovaps xmm4, [rsp+0x40]
0000781a8ffdb6f9  vmovaps xmm5, [rsp+0x50]
0000781a8ffdb6ff  vmovaps xmm6, [rsp+0x60]
0000781a8ffdb705  vmovaps xmm7, [rsp+0x70]
0000781a8ffdb70b  vmovaps xmm8, [rsp+0x80]
0000781a8ffdb714  vmovaps xmm9, [rsp+0x90]
0000781a8ffdb71d  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdb726  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdb72f  vmovaps xmm12, [rsp+0xC0]
0000781a8ffdb738  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdb741  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdb74a  add rsp, 0xF0
0000781a8ffdb751  pop r11
0000781a8ffdb753  pop r10
0000781a8ffdb755  pop r9
0000781a8ffdb757  pop r8
0000781a8ffdb759  pop rsi
0000781a8ffdb75a  pop rdi
0000781a8ffdb75b  pop rdx
0000781a8ffdb75c  pop rcx
0000781a8ffdb75d  pop rax
0000781a8ffdb75e  add rsp, 0x08
0000781a8ffdb762  jmp 0x0000781A8FFDA1F9
0000781a8ffdb767  sub rsp, 0x08
0000781a8ffdb76b  push rax
0000781a8ffdb76c  push rcx
0000781a8ffdb76d  push rdx
0000781a8ffdb76e  push rdi
0000781a8ffdb76f  push rsi
0000781a8ffdb770  push r8
0000781a8ffdb772  push r9
0000781a8ffdb774  push r10
0000781a8ffdb776  push r11
0000781a8ffdb778  sub rsp, 0xF0
0000781a8ffdb77f  vmovaps [rsp], xmm0
0000781a8ffdb784  vmovaps [rsp+0x10], xmm1
0000781a8ffdb78a  vmovaps [rsp+0x20], xmm2
0000781a8ffdb790  vmovaps [rsp+0x30], xmm3
0000781a8ffdb796  vmovaps [rsp+0x40], xmm4
0000781a8ffdb79c  vmovaps [rsp+0x50], xmm5
0000781a8ffdb7a2  vmovaps [rsp+0x60], xmm6
0000781a8ffdb7a8  vmovaps [rsp+0x70], xmm7
0000781a8ffdb7ae  vmovaps [rsp+0x80], xmm8
0000781a8ffdb7b7  vmovaps [rsp+0x90], xmm9
0000781a8ffdb7c0  vmovaps [rsp+0xA0], xmm10
0000781a8ffdb7c9  vmovaps [rsp+0xB0], xmm11
0000781a8ffdb7d2  vmovaps [rsp+0xC0], xmm13
0000781a8ffdb7db  vmovaps [rsp+0xD0], xmm14
0000781a8ffdb7e4  vmovaps [rsp+0xE0], xmm15
0000781a8ffdb7ed  sub rsp, 0x40
0000781a8ffdb7f1  lea rdi, [rsp]
0000781a8ffdb7f5  lea rsi, [rsp+0x10]
0000781a8ffdb7fa  lea rdx, [rsp+0x20]
0000781a8ffdb7ff  lea rcx, [rsp+0x30]
0000781a8ffdb804  mov r8d, 0x00
0000781a8ffdb80a  lea r9, [r15+0x3A8]
0000781a8ffdb811  movaps [rdi], xmm12
0000781a8ffdb815  movaps [rsi], xmm3
0000781a8ffdb818  movaps [rdx], xmm14
0000781a8ffdb81c  movaps [rcx], xmm5
0000781a8ffdb81f  mov rax, 0x627DDC279A50
0000781a8ffdb829  call rax
0000781a8ffdb82b  movaps xmm12, [rsp]
0000781a8ffdb830  add rsp, 0x40
0000781a8ffdb834  vmovaps xmm0, [rsp]
0000781a8ffdb839  vmovaps xmm1, [rsp+0x10]
0000781a8ffdb83f  vmovaps xmm2, [rsp+0x20]
0000781a8ffdb845  vmovaps xmm3, [rsp+0x30]
0000781a8ffdb84b  vmovaps xmm4, [rsp+0x40]
0000781a8ffdb851  vmovaps xmm5, [rsp+0x50]
0000781a8ffdb857  vmovaps xmm6, [rsp+0x60]
0000781a8ffdb85d  vmovaps xmm7, [rsp+0x70]
0000781a8ffdb863  vmovaps xmm8, [rsp+0x80]
0000781a8ffdb86c  vmovaps xmm9, [rsp+0x90]
0000781a8ffdb875  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdb87e  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdb887  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdb890  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdb899  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdb8a2  add rsp, 0xF0
0000781a8ffdb8a9  pop r11
0000781a8ffdb8ab  pop r10
0000781a8ffdb8ad  pop r9
0000781a8ffdb8af  pop r8
0000781a8ffdb8b1  pop rsi
0000781a8ffdb8b2  pop rdi
0000781a8ffdb8b3  pop rdx
0000781a8ffdb8b4  pop rcx
0000781a8ffdb8b5  pop rax
0000781a8ffdb8b6  add rsp, 0x08
0000781a8ffdb8ba  jmp 0x0000781A8FFDA256
0000781a8ffdb8bf  sub rsp, 0x08
0000781a8ffdb8c3  push rax
0000781a8ffdb8c4  push rcx
0000781a8ffdb8c5  push rdx
0000781a8ffdb8c6  push rdi
0000781a8ffdb8c7  push rsi
0000781a8ffdb8c8  push r8
0000781a8ffdb8ca  push r9
0000781a8ffdb8cc  push r10
0000781a8ffdb8ce  push r11
0000781a8ffdb8d0  sub rsp, 0xF0
0000781a8ffdb8d7  vmovaps [rsp], xmm0
0000781a8ffdb8dc  vmovaps [rsp+0x10], xmm1
0000781a8ffdb8e2  vmovaps [rsp+0x20], xmm2
0000781a8ffdb8e8  vmovaps [rsp+0x30], xmm3
0000781a8ffdb8ee  vmovaps [rsp+0x40], xmm4
0000781a8ffdb8f4  vmovaps [rsp+0x50], xmm5
0000781a8ffdb8fa  vmovaps [rsp+0x60], xmm6
0000781a8ffdb900  vmovaps [rsp+0x70], xmm7
0000781a8ffdb906  vmovaps [rsp+0x80], xmm8
0000781a8ffdb90f  vmovaps [rsp+0x90], xmm9
0000781a8ffdb918  vmovaps [rsp+0xA0], xmm11
0000781a8ffdb921  vmovaps [rsp+0xB0], xmm12
0000781a8ffdb92a  vmovaps [rsp+0xC0], xmm13
0000781a8ffdb933  vmovaps [rsp+0xD0], xmm14
0000781a8ffdb93c  vmovaps [rsp+0xE0], xmm15
0000781a8ffdb945  sub rsp, 0x40
0000781a8ffdb949  lea rdi, [rsp]
0000781a8ffdb94d  lea rsi, [rsp+0x10]
0000781a8ffdb952  lea rdx, [rsp+0x20]
0000781a8ffdb957  lea rcx, [rsp+0x30]
0000781a8ffdb95c  mov r8d, 0x00
0000781a8ffdb962  lea r9, [r15+0x3A8]
0000781a8ffdb969  movaps [rdi], xmm10
0000781a8ffdb96d  movaps [rsi], xmm9
0000781a8ffdb971  movaps [rdx], xmm7
0000781a8ffdb974  movaps [rcx], xmm14
0000781a8ffdb978  mov rax, 0x627DDC279A50
0000781a8ffdb982  call rax
0000781a8ffdb984  movaps xmm10, [rsp]
0000781a8ffdb989  add rsp, 0x40
0000781a8ffdb98d  vmovaps xmm0, [rsp]
0000781a8ffdb992  vmovaps xmm1, [rsp+0x10]
0000781a8ffdb998  vmovaps xmm2, [rsp+0x20]
0000781a8ffdb99e  vmovaps xmm3, [rsp+0x30]
0000781a8ffdb9a4  vmovaps xmm4, [rsp+0x40]
0000781a8ffdb9aa  vmovaps xmm5, [rsp+0x50]
0000781a8ffdb9b0  vmovaps xmm6, [rsp+0x60]
0000781a8ffdb9b6  vmovaps xmm7, [rsp+0x70]
0000781a8ffdb9bc  vmovaps xmm8, [rsp+0x80]
0000781a8ffdb9c5  vmovaps xmm9, [rsp+0x90]
0000781a8ffdb9ce  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdb9d7  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdb9e0  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdb9e9  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdb9f2  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdb9fb  add rsp, 0xF0
0000781a8ffdba02  pop r11
0000781a8ffdba04  pop r10
0000781a8ffdba06  pop r9
0000781a8ffdba08  pop r8
0000781a8ffdba0a  pop rsi
0000781a8ffdba0b  pop rdi
0000781a8ffdba0c  pop rdx
0000781a8ffdba0d  pop rcx
0000781a8ffdba0e  pop rax
0000781a8ffdba0f  add rsp, 0x08
0000781a8ffdba13  jmp 0x0000781A8FFDA27C
0000781a8ffdba18  call 0x0000781A8FE0D4E0
0000781a8ffdba1d  jmp 0x0000781A8FFDA289
0000781a8ffdba22  sub rsp, 0x08
0000781a8ffdba26  push rax
0000781a8ffdba27  push rcx
0000781a8ffdba28  push rdx
0000781a8ffdba29  push rdi
0000781a8ffdba2a  push rsi
0000781a8ffdba2b  push r8
0000781a8ffdba2d  push r9
0000781a8ffdba2f  push r10
0000781a8ffdba31  push r11
0000781a8ffdba33  sub rsp, 0xF0
0000781a8ffdba3a  vmovaps [rsp], xmm0
0000781a8ffdba3f  vmovaps [rsp+0x10], xmm1
0000781a8ffdba45  vmovaps [rsp+0x20], xmm2
0000781a8ffdba4b  vmovaps [rsp+0x30], xmm3
0000781a8ffdba51  vmovaps [rsp+0x40], xmm4
0000781a8ffdba57  vmovaps [rsp+0x50], xmm6
0000781a8ffdba5d  vmovaps [rsp+0x60], xmm7
0000781a8ffdba63  vmovaps [rsp+0x70], xmm8
0000781a8ffdba69  vmovaps [rsp+0x80], xmm9
0000781a8ffdba72  vmovaps [rsp+0x90], xmm10
0000781a8ffdba7b  vmovaps [rsp+0xA0], xmm11
0000781a8ffdba84  vmovaps [rsp+0xB0], xmm12
0000781a8ffdba8d  vmovaps [rsp+0xC0], xmm13
0000781a8ffdba96  vmovaps [rsp+0xD0], xmm14
0000781a8ffdba9f  vmovaps [rsp+0xE0], xmm15
0000781a8ffdbaa8  sub rsp, 0x40
0000781a8ffdbaac  lea rdi, [rsp]
0000781a8ffdbab0  lea rsi, [rsp+0x10]
0000781a8ffdbab5  lea rdx, [rsp+0x20]
0000781a8ffdbaba  lea rcx, [rsp+0x30]
0000781a8ffdbabf  mov r8d, 0x00
0000781a8ffdbac5  lea r9, [r15+0x3A8]
0000781a8ffdbacc  movaps [rdi], xmm5
0000781a8ffdbacf  movaps [rsi], xmm6
0000781a8ffdbad2  movaps [rdx], xmm7
0000781a8ffdbad5  movaps [rcx], xmm9
0000781a8ffdbad9  mov rax, 0x627DDC279A50
0000781a8ffdbae3  call rax
0000781a8ffdbae5  movaps xmm5, [rsp]
0000781a8ffdbae9  add rsp, 0x40
0000781a8ffdbaed  vmovaps xmm0, [rsp]
0000781a8ffdbaf2  vmovaps xmm1, [rsp+0x10]
0000781a8ffdbaf8  vmovaps xmm2, [rsp+0x20]
0000781a8ffdbafe  vmovaps xmm3, [rsp+0x30]
0000781a8ffdbb04  vmovaps xmm4, [rsp+0x40]
0000781a8ffdbb0a  vmovaps xmm6, [rsp+0x50]
0000781a8ffdbb10  vmovaps xmm7, [rsp+0x60]
0000781a8ffdbb16  vmovaps xmm8, [rsp+0x70]
0000781a8ffdbb1c  vmovaps xmm9, [rsp+0x80]
0000781a8ffdbb25  vmovaps xmm10, [rsp+0x90]
0000781a8ffdbb2e  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdbb37  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdbb40  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdbb49  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdbb52  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdbb5b  add rsp, 0xF0
0000781a8ffdbb62  pop r11
0000781a8ffdbb64  pop r10
0000781a8ffdbb66  pop r9
0000781a8ffdbb68  pop r8
0000781a8ffdbb6a  pop rsi
0000781a8ffdbb6b  pop rdi
0000781a8ffdbb6c  pop rdx
0000781a8ffdbb6d  pop rcx
0000781a8ffdbb6e  pop rax
0000781a8ffdbb6f  add rsp, 0x08
0000781a8ffdbb73  jmp 0x0000781A8FFDA2BB
0000781a8ffdbb78  sub rsp, 0x08
0000781a8ffdbb7c  push rax
0000781a8ffdbb7d  push rcx
0000781a8ffdbb7e  push rdx
0000781a8ffdbb7f  push rdi
0000781a8ffdbb80  push rsi
0000781a8ffdbb81  push r8
0000781a8ffdbb83  push r9
0000781a8ffdbb85  push r10
0000781a8ffdbb87  push r11
0000781a8ffdbb89  sub rsp, 0xF0
0000781a8ffdbb90  vmovaps [rsp], xmm0
0000781a8ffdbb95  vmovaps [rsp+0x10], xmm1
0000781a8ffdbb9b  vmovaps [rsp+0x20], xmm2
0000781a8ffdbba1  vmovaps [rsp+0x30], xmm3
0000781a8ffdbba7  vmovaps [rsp+0x40], xmm4
0000781a8ffdbbad  vmovaps [rsp+0x50], xmm5
0000781a8ffdbbb3  vmovaps [rsp+0x60], xmm6
0000781a8ffdbbb9  vmovaps [rsp+0x70], xmm8
0000781a8ffdbbbf  vmovaps [rsp+0x80], xmm9
0000781a8ffdbbc8  vmovaps [rsp+0x90], xmm10
0000781a8ffdbbd1  vmovaps [rsp+0xA0], xmm11
0000781a8ffdbbda  vmovaps [rsp+0xB0], xmm12
0000781a8ffdbbe3  vmovaps [rsp+0xC0], xmm13
0000781a8ffdbbec  vmovaps [rsp+0xD0], xmm14
0000781a8ffdbbf5  vmovaps [rsp+0xE0], xmm15
0000781a8ffdbbfe  sub rsp, 0x40
0000781a8ffdbc02  lea rdi, [rsp]
0000781a8ffdbc06  lea rsi, [rsp+0x10]
0000781a8ffdbc0b  lea rdx, [rsp+0x20]
0000781a8ffdbc10  lea rcx, [rsp+0x30]
0000781a8ffdbc15  mov r8d, 0x00
0000781a8ffdbc1b  lea r9, [r15+0x3A8]
0000781a8ffdbc22  movaps [rdi], xmm7
0000781a8ffdbc25  movaps [rsi], xmm13
0000781a8ffdbc29  movaps [rdx], xmm1
0000781a8ffdbc2c  movaps [rcx], xmm9
0000781a8ffdbc30  mov rax, 0x627DDC279A50
0000781a8ffdbc3a  call rax
0000781a8ffdbc3c  movaps xmm7, [rsp]
0000781a8ffdbc40  add rsp, 0x40
0000781a8ffdbc44  vmovaps xmm0, [rsp]
0000781a8ffdbc49  vmovaps xmm1, [rsp+0x10]
0000781a8ffdbc4f  vmovaps xmm2, [rsp+0x20]
0000781a8ffdbc55  vmovaps xmm3, [rsp+0x30]
0000781a8ffdbc5b  vmovaps xmm4, [rsp+0x40]
0000781a8ffdbc61  vmovaps xmm5, [rsp+0x50]
0000781a8ffdbc67  vmovaps xmm6, [rsp+0x60]
0000781a8ffdbc6d  vmovaps xmm8, [rsp+0x70]
0000781a8ffdbc73  vmovaps xmm9, [rsp+0x80]
0000781a8ffdbc7c  vmovaps xmm10, [rsp+0x90]
0000781a8ffdbc85  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdbc8e  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdbc97  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdbca0  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdbca9  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdbcb2  add rsp, 0xF0
0000781a8ffdbcb9  pop r11
0000781a8ffdbcbb  pop r10
0000781a8ffdbcbd  pop r9
0000781a8ffdbcbf  pop r8
0000781a8ffdbcc1  pop rsi
0000781a8ffdbcc2  pop rdi
0000781a8ffdbcc3  pop rdx
0000781a8ffdbcc4  pop rcx
0000781a8ffdbcc5  pop rax
0000781a8ffdbcc6  add rsp, 0x08
0000781a8ffdbcca  jmp 0x0000781A8FFDA2E0
0000781a8ffdbccf  call 0x0000781A8FE0C260
0000781a8ffdbcd4  jmp 0x0000781A8FFDA303
0000781a8ffdbcd9  call 0x0000781A8FE07890
0000781a8ffdbcde  jmp 0x0000781A8FFDA30D
0000781a8ffdbce3  sub rsp, 0x08
0000781a8ffdbce7  push rax
0000781a8ffdbce8  push rcx
0000781a8ffdbce9  push rdx
0000781a8ffdbcea  push rdi
0000781a8ffdbceb  push rsi
0000781a8ffdbcec  push r8
0000781a8ffdbcee  push r9
0000781a8ffdbcf0  push r10
0000781a8ffdbcf2  push r11
0000781a8ffdbcf4  sub rsp, 0xF0
0000781a8ffdbcfb  vmovaps [rsp], xmm0
0000781a8ffdbd00  vmovaps [rsp+0x10], xmm1
0000781a8ffdbd06  vmovaps [rsp+0x20], xmm3
0000781a8ffdbd0c  vmovaps [rsp+0x30], xmm4
0000781a8ffdbd12  vmovaps [rsp+0x40], xmm5
0000781a8ffdbd18  vmovaps [rsp+0x50], xmm6
0000781a8ffdbd1e  vmovaps [rsp+0x60], xmm7
0000781a8ffdbd24  vmovaps [rsp+0x70], xmm8
0000781a8ffdbd2a  vmovaps [rsp+0x80], xmm9
0000781a8ffdbd33  vmovaps [rsp+0x90], xmm10
0000781a8ffdbd3c  vmovaps [rsp+0xA0], xmm11
0000781a8ffdbd45  vmovaps [rsp+0xB0], xmm12
0000781a8ffdbd4e  vmovaps [rsp+0xC0], xmm13
0000781a8ffdbd57  vmovaps [rsp+0xD0], xmm14
0000781a8ffdbd60  vmovaps [rsp+0xE0], xmm15
0000781a8ffdbd69  sub rsp, 0x40
0000781a8ffdbd6d  lea rdi, [rsp]
0000781a8ffdbd71  lea rsi, [rsp+0x10]
0000781a8ffdbd76  lea rdx, [rsp+0x20]
0000781a8ffdbd7b  lea rcx, [rsp+0x30]
0000781a8ffdbd80  mov r8d, 0x00
0000781a8ffdbd86  lea r9, [r15+0x3A8]
0000781a8ffdbd8d  movaps [rdi], xmm2
0000781a8ffdbd90  movaps [rsi], xmm12
0000781a8ffdbd94  movaps [rdx], xmm6
0000781a8ffdbd97  movaps [rcx], xmm3
0000781a8ffdbd9a  mov rax, 0x627DDC279A50
0000781a8ffdbda4  call rax
0000781a8ffdbda6  movaps xmm2, [rsp]
0000781a8ffdbdaa  add rsp, 0x40
0000781a8ffdbdae  vmovaps xmm0, [rsp]
0000781a8ffdbdb3  vmovaps xmm1, [rsp+0x10]
0000781a8ffdbdb9  vmovaps xmm3, [rsp+0x20]
0000781a8ffdbdbf  vmovaps xmm4, [rsp+0x30]
0000781a8ffdbdc5  vmovaps xmm5, [rsp+0x40]
0000781a8ffdbdcb  vmovaps xmm6, [rsp+0x50]
0000781a8ffdbdd1  vmovaps xmm7, [rsp+0x60]
0000781a8ffdbdd7  vmovaps xmm8, [rsp+0x70]
0000781a8ffdbddd  vmovaps xmm9, [rsp+0x80]
0000781a8ffdbde6  vmovaps xmm10, [rsp+0x90]
0000781a8ffdbdef  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdbdf8  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdbe01  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdbe0a  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdbe13  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdbe1c  add rsp, 0xF0
0000781a8ffdbe23  pop r11
0000781a8ffdbe25  pop r10
0000781a8ffdbe27  pop r9
0000781a8ffdbe29  pop r8
0000781a8ffdbe2b  pop rsi
0000781a8ffdbe2c  pop rdi
0000781a8ffdbe2d  pop rdx
0000781a8ffdbe2e  pop rcx
0000781a8ffdbe2f  pop rax
0000781a8ffdbe30  add rsp, 0x08
0000781a8ffdbe34  jmp 0x0000781A8FFDA353
0000781a8ffdbe39  sub rsp, 0x08
0000781a8ffdbe3d  push rax
0000781a8ffdbe3e  push rcx
0000781a8ffdbe3f  push rdx
0000781a8ffdbe40  push rdi
0000781a8ffdbe41  push rsi
0000781a8ffdbe42  push r8
0000781a8ffdbe44  push r9
0000781a8ffdbe46  push r10
0000781a8ffdbe48  push r11
0000781a8ffdbe4a  sub rsp, 0xF0
0000781a8ffdbe51  vmovaps [rsp], xmm0
0000781a8ffdbe56  vmovaps [rsp+0x10], xmm1
0000781a8ffdbe5c  vmovaps [rsp+0x20], xmm2
0000781a8ffdbe62  vmovaps [rsp+0x30], xmm3
0000781a8ffdbe68  vmovaps [rsp+0x40], xmm4
0000781a8ffdbe6e  vmovaps [rsp+0x50], xmm5
0000781a8ffdbe74  vmovaps [rsp+0x60], xmm7
0000781a8ffdbe7a  vmovaps [rsp+0x70], xmm8
0000781a8ffdbe80  vmovaps [rsp+0x80], xmm9
0000781a8ffdbe89  vmovaps [rsp+0x90], xmm10
0000781a8ffdbe92  vmovaps [rsp+0xA0], xmm11
0000781a8ffdbe9b  vmovaps [rsp+0xB0], xmm12
0000781a8ffdbea4  vmovaps [rsp+0xC0], xmm13
0000781a8ffdbead  vmovaps [rsp+0xD0], xmm14
0000781a8ffdbeb6  vmovaps [rsp+0xE0], xmm15
0000781a8ffdbebf  sub rsp, 0x40
0000781a8ffdbec3  lea rdi, [rsp]
0000781a8ffdbec7  lea rsi, [rsp+0x10]
0000781a8ffdbecc  lea rdx, [rsp+0x20]
0000781a8ffdbed1  lea rcx, [rsp+0x30]
0000781a8ffdbed6  mov r8d, 0x00
0000781a8ffdbedc  lea r9, [r15+0x3A8]
0000781a8ffdbee3  movaps [rdi], xmm6
0000781a8ffdbee6  movaps [rsi], xmm10
0000781a8ffdbeea  movaps [rdx], xmm12
0000781a8ffdbeee  movaps [rcx], xmm1
0000781a8ffdbef1  mov rax, 0x627DDC279A50
0000781a8ffdbefb  call rax
0000781a8ffdbefd  movaps xmm6, [rsp]
0000781a8ffdbf01  add rsp, 0x40
0000781a8ffdbf05  vmovaps xmm0, [rsp]
0000781a8ffdbf0a  vmovaps xmm1, [rsp+0x10]
0000781a8ffdbf10  vmovaps xmm2, [rsp+0x20]
0000781a8ffdbf16  vmovaps xmm3, [rsp+0x30]
0000781a8ffdbf1c  vmovaps xmm4, [rsp+0x40]
0000781a8ffdbf22  vmovaps xmm5, [rsp+0x50]
0000781a8ffdbf28  vmovaps xmm7, [rsp+0x60]
0000781a8ffdbf2e  vmovaps xmm8, [rsp+0x70]
0000781a8ffdbf34  vmovaps xmm9, [rsp+0x80]
0000781a8ffdbf3d  vmovaps xmm10, [rsp+0x90]
0000781a8ffdbf46  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdbf4f  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdbf58  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdbf61  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdbf6a  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdbf73  add rsp, 0xF0
0000781a8ffdbf7a  pop r11
0000781a8ffdbf7c  pop r10
0000781a8ffdbf7e  pop r9
0000781a8ffdbf80  pop r8
0000781a8ffdbf82  pop rsi
0000781a8ffdbf83  pop rdi
0000781a8ffdbf84  pop rdx
0000781a8ffdbf85  pop rcx
0000781a8ffdbf86  pop rax
0000781a8ffdbf87  add rsp, 0x08
0000781a8ffdbf8b  jmp 0x0000781A8FFDA381
0000781a8ffdbf90  sub rsp, 0x08
0000781a8ffdbf94  push rax
0000781a8ffdbf95  push rcx
0000781a8ffdbf96  push rdx
0000781a8ffdbf97  push rdi
0000781a8ffdbf98  push rsi
0000781a8ffdbf99  push r8
0000781a8ffdbf9b  push r9
0000781a8ffdbf9d  push r10
0000781a8ffdbf9f  push r11
0000781a8ffdbfa1  sub rsp, 0xF0
0000781a8ffdbfa8  vmovaps [rsp], xmm0
0000781a8ffdbfad  vmovaps [rsp+0x10], xmm1
0000781a8ffdbfb3  vmovaps [rsp+0x20], xmm2
0000781a8ffdbfb9  vmovaps [rsp+0x30], xmm3
0000781a8ffdbfbf  vmovaps [rsp+0x40], xmm4
0000781a8ffdbfc5  vmovaps [rsp+0x50], xmm5
0000781a8ffdbfcb  vmovaps [rsp+0x60], xmm6
0000781a8ffdbfd1  vmovaps [rsp+0x70], xmm7
0000781a8ffdbfd7  vmovaps [rsp+0x80], xmm8
0000781a8ffdbfe0  vmovaps [rsp+0x90], xmm9
0000781a8ffdbfe9  vmovaps [rsp+0xA0], xmm11
0000781a8ffdbff2  vmovaps [rsp+0xB0], xmm12
0000781a8ffdbffb  vmovaps [rsp+0xC0], xmm13
0000781a8ffdc004  vmovaps [rsp+0xD0], xmm14
0000781a8ffdc00d  vmovaps [rsp+0xE0], xmm15
0000781a8ffdc016  sub rsp, 0x40
0000781a8ffdc01a  lea rdi, [rsp]
0000781a8ffdc01e  lea rsi, [rsp+0x10]
0000781a8ffdc023  lea rdx, [rsp+0x20]
0000781a8ffdc028  lea rcx, [rsp+0x30]
0000781a8ffdc02d  mov r8d, 0x00
0000781a8ffdc033  lea r9, [r15+0x3A8]
0000781a8ffdc03a  movaps [rdi], xmm10
0000781a8ffdc03e  movaps [rsi], xmm5
0000781a8ffdc041  movaps [rdx], xmm12
0000781a8ffdc045  movaps [rcx], xmm1
0000781a8ffdc048  mov rax, 0x627DDC279A50
0000781a8ffdc052  call rax
0000781a8ffdc054  movaps xmm10, [rsp]
0000781a8ffdc059  add rsp, 0x40
0000781a8ffdc05d  vmovaps xmm0, [rsp]
0000781a8ffdc062  vmovaps xmm1, [rsp+0x10]
0000781a8ffdc068  vmovaps xmm2, [rsp+0x20]
0000781a8ffdc06e  vmovaps xmm3, [rsp+0x30]
0000781a8ffdc074  vmovaps xmm4, [rsp+0x40]
0000781a8ffdc07a  vmovaps xmm5, [rsp+0x50]
0000781a8ffdc080  vmovaps xmm6, [rsp+0x60]
0000781a8ffdc086  vmovaps xmm7, [rsp+0x70]
0000781a8ffdc08c  vmovaps xmm8, [rsp+0x80]
0000781a8ffdc095  vmovaps xmm9, [rsp+0x90]
0000781a8ffdc09e  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdc0a7  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdc0b0  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdc0b9  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdc0c2  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdc0cb  add rsp, 0xF0
0000781a8ffdc0d2  pop r11
0000781a8ffdc0d4  pop r10
0000781a8ffdc0d6  pop r9
0000781a8ffdc0d8  pop r8
0000781a8ffdc0da  pop rsi
0000781a8ffdc0db  pop rdi
0000781a8ffdc0dc  pop rdx
0000781a8ffdc0dd  pop rcx
0000781a8ffdc0de  pop rax
0000781a8ffdc0df  add rsp, 0x08
0000781a8ffdc0e3  jmp 0x0000781A8FFDA3B0
0000781a8ffdc0e8  sub rsp, 0x08
0000781a8ffdc0ec  push rax
0000781a8ffdc0ed  push rcx
0000781a8ffdc0ee  push rdx
0000781a8ffdc0ef  push rdi
0000781a8ffdc0f0  push rsi
0000781a8ffdc0f1  push r8
0000781a8ffdc0f3  push r9
0000781a8ffdc0f5  push r10
0000781a8ffdc0f7  push r11
0000781a8ffdc0f9  sub rsp, 0xF0
0000781a8ffdc100  vmovaps [rsp], xmm0
0000781a8ffdc105  vmovaps [rsp+0x10], xmm1
0000781a8ffdc10b  vmovaps [rsp+0x20], xmm2
0000781a8ffdc111  vmovaps [rsp+0x30], xmm3
0000781a8ffdc117  vmovaps [rsp+0x40], xmm4
0000781a8ffdc11d  vmovaps [rsp+0x50], xmm5
0000781a8ffdc123  vmovaps [rsp+0x60], xmm6
0000781a8ffdc129  vmovaps [rsp+0x70], xmm7
0000781a8ffdc12f  vmovaps [rsp+0x80], xmm8
0000781a8ffdc138  vmovaps [rsp+0x90], xmm9
0000781a8ffdc141  vmovaps [rsp+0xA0], xmm10
0000781a8ffdc14a  vmovaps [rsp+0xB0], xmm11
0000781a8ffdc153  vmovaps [rsp+0xC0], xmm13
0000781a8ffdc15c  vmovaps [rsp+0xD0], xmm14
0000781a8ffdc165  vmovaps [rsp+0xE0], xmm15
0000781a8ffdc16e  sub rsp, 0x40
0000781a8ffdc172  lea rdi, [rsp]
0000781a8ffdc176  lea rsi, [rsp+0x10]
0000781a8ffdc17b  lea rdx, [rsp+0x20]
0000781a8ffdc180  lea rcx, [rsp+0x30]
0000781a8ffdc185  mov r8d, 0x00
0000781a8ffdc18b  lea r9, [r15+0x3A8]
0000781a8ffdc192  movaps [rdi], xmm12
0000781a8ffdc196  movaps [rsi], xmm7
0000781a8ffdc199  movaps [rdx], xmm15
0000781a8ffdc19d  movaps [rcx], xmm1
0000781a8ffdc1a0  mov rax, 0x627DDC279A50
0000781a8ffdc1aa  call rax
0000781a8ffdc1ac  movaps xmm12, [rsp]
0000781a8ffdc1b1  add rsp, 0x40
0000781a8ffdc1b5  vmovaps xmm0, [rsp]
0000781a8ffdc1ba  vmovaps xmm1, [rsp+0x10]
0000781a8ffdc1c0  vmovaps xmm2, [rsp+0x20]
0000781a8ffdc1c6  vmovaps xmm3, [rsp+0x30]
0000781a8ffdc1cc  vmovaps xmm4, [rsp+0x40]
0000781a8ffdc1d2  vmovaps xmm5, [rsp+0x50]
0000781a8ffdc1d8  vmovaps xmm6, [rsp+0x60]
0000781a8ffdc1de  vmovaps xmm7, [rsp+0x70]
0000781a8ffdc1e4  vmovaps xmm8, [rsp+0x80]
0000781a8ffdc1ed  vmovaps xmm9, [rsp+0x90]
0000781a8ffdc1f6  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdc1ff  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdc208  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdc211  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdc21a  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdc223  add rsp, 0xF0
0000781a8ffdc22a  pop r11
0000781a8ffdc22c  pop r10
0000781a8ffdc22e  pop r9
0000781a8ffdc230  pop r8
0000781a8ffdc232  pop rsi
0000781a8ffdc233  pop rdi
0000781a8ffdc234  pop rdx
0000781a8ffdc235  pop rcx
0000781a8ffdc236  pop rax
0000781a8ffdc237  add rsp, 0x08
0000781a8ffdc23b  jmp 0x0000781A8FFDA3D9
0000781a8ffdc240  call 0x0000781A8FDFF430
0000781a8ffdc245  jmp 0x0000781A8FFDA3E3
0000781a8ffdc24a  call 0x0000781A8FE0E760
0000781a8ffdc24f  jmp 0x0000781A8FFDA3ED
0000781a8ffdc254  sub rsp, 0x08
0000781a8ffdc258  push rax
0000781a8ffdc259  push rcx
0000781a8ffdc25a  push rdx
0000781a8ffdc25b  push rdi
0000781a8ffdc25c  push rsi
0000781a8ffdc25d  push r8
0000781a8ffdc25f  push r9
0000781a8ffdc261  push r10
0000781a8ffdc263  push r11
0000781a8ffdc265  sub rsp, 0xF0
0000781a8ffdc26c  vmovaps [rsp], xmm0
0000781a8ffdc271  vmovaps [rsp+0x10], xmm1
0000781a8ffdc277  vmovaps [rsp+0x20], xmm2
0000781a8ffdc27d  vmovaps [rsp+0x30], xmm3
0000781a8ffdc283  vmovaps [rsp+0x40], xmm4
0000781a8ffdc289  vmovaps [rsp+0x50], xmm5
0000781a8ffdc28f  vmovaps [rsp+0x60], xmm6
0000781a8ffdc295  vmovaps [rsp+0x70], xmm8
0000781a8ffdc29b  vmovaps [rsp+0x80], xmm9
0000781a8ffdc2a4  vmovaps [rsp+0x90], xmm10
0000781a8ffdc2ad  vmovaps [rsp+0xA0], xmm11
0000781a8ffdc2b6  vmovaps [rsp+0xB0], xmm12
0000781a8ffdc2bf  vmovaps [rsp+0xC0], xmm13
0000781a8ffdc2c8  vmovaps [rsp+0xD0], xmm14
0000781a8ffdc2d1  vmovaps [rsp+0xE0], xmm15
0000781a8ffdc2da  sub rsp, 0x40
0000781a8ffdc2de  lea rdi, [rsp]
0000781a8ffdc2e2  lea rsi, [rsp+0x10]
0000781a8ffdc2e7  lea rdx, [rsp+0x20]
0000781a8ffdc2ec  lea rcx, [rsp+0x30]
0000781a8ffdc2f1  mov r8d, 0x00
0000781a8ffdc2f7  lea r9, [r15+0x3A8]
0000781a8ffdc2fe  movaps [rdi], xmm7
0000781a8ffdc301  movaps [rsi], xmm2
0000781a8ffdc304  movaps [rdx], xmm9
0000781a8ffdc308  movaps [rcx], xmm11
0000781a8ffdc30c  mov rax, 0x627DDC279A50
0000781a8ffdc316  call rax
0000781a8ffdc318  movaps xmm7, [rsp]
0000781a8ffdc31c  add rsp, 0x40
0000781a8ffdc320  vmovaps xmm0, [rsp]
0000781a8ffdc325  vmovaps xmm1, [rsp+0x10]
0000781a8ffdc32b  vmovaps xmm2, [rsp+0x20]
0000781a8ffdc331  vmovaps xmm3, [rsp+0x30]
0000781a8ffdc337  vmovaps xmm4, [rsp+0x40]
0000781a8ffdc33d  vmovaps xmm5, [rsp+0x50]
0000781a8ffdc343  vmovaps xmm6, [rsp+0x60]
0000781a8ffdc349  vmovaps xmm8, [rsp+0x70]
0000781a8ffdc34f  vmovaps xmm9, [rsp+0x80]
0000781a8ffdc358  vmovaps xmm10, [rsp+0x90]
0000781a8ffdc361  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdc36a  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdc373  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdc37c  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdc385  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdc38e  add rsp, 0xF0
0000781a8ffdc395  pop r11
0000781a8ffdc397  pop r10
0000781a8ffdc399  pop r9
0000781a8ffdc39b  pop r8
0000781a8ffdc39d  pop rsi
0000781a8ffdc39e  pop rdi
0000781a8ffdc39f  pop rdx
0000781a8ffdc3a0  pop rcx
0000781a8ffdc3a1  pop rax
0000781a8ffdc3a2  add rsp, 0x08
0000781a8ffdc3a6  jmp 0x0000781A8FFDA421
0000781a8ffdc3ab  sub rsp, 0x08
0000781a8ffdc3af  push rax
0000781a8ffdc3b0  push rcx
0000781a8ffdc3b1  push rdx
0000781a8ffdc3b2  push rdi
0000781a8ffdc3b3  push rsi
0000781a8ffdc3b4  push r8
0000781a8ffdc3b6  push r9
0000781a8ffdc3b8  push r10
0000781a8ffdc3ba  push r11
0000781a8ffdc3bc  sub rsp, 0xF0
0000781a8ffdc3c3  vmovaps [rsp], xmm0
0000781a8ffdc3c8  vmovaps [rsp+0x10], xmm1
0000781a8ffdc3ce  vmovaps [rsp+0x20], xmm2
0000781a8ffdc3d4  vmovaps [rsp+0x30], xmm3
0000781a8ffdc3da  vmovaps [rsp+0x40], xmm4
0000781a8ffdc3e0  vmovaps [rsp+0x50], xmm5
0000781a8ffdc3e6  vmovaps [rsp+0x60], xmm6
0000781a8ffdc3ec  vmovaps [rsp+0x70], xmm7
0000781a8ffdc3f2  vmovaps [rsp+0x80], xmm8
0000781a8ffdc3fb  vmovaps [rsp+0x90], xmm10
0000781a8ffdc404  vmovaps [rsp+0xA0], xmm11
0000781a8ffdc40d  vmovaps [rsp+0xB0], xmm12
0000781a8ffdc416  vmovaps [rsp+0xC0], xmm13
0000781a8ffdc41f  vmovaps [rsp+0xD0], xmm14
0000781a8ffdc428  vmovaps [rsp+0xE0], xmm15
0000781a8ffdc431  sub rsp, 0x40
0000781a8ffdc435  lea rdi, [rsp]
0000781a8ffdc439  lea rsi, [rsp+0x10]
0000781a8ffdc43e  lea rdx, [rsp+0x20]
0000781a8ffdc443  lea rcx, [rsp+0x30]
0000781a8ffdc448  mov r8d, 0x00
0000781a8ffdc44e  lea r9, [r15+0x3A8]
0000781a8ffdc455  movaps [rdi], xmm9
0000781a8ffdc459  movaps [rsi], xmm6
0000781a8ffdc45c  movaps [rdx], xmm1
0000781a8ffdc45f  movaps [rcx], xmm11
0000781a8ffdc463  mov rax, 0x627DDC279A50
0000781a8ffdc46d  call rax
0000781a8ffdc46f  movaps xmm9, [rsp]
0000781a8ffdc474  add rsp, 0x40
0000781a8ffdc478  vmovaps xmm0, [rsp]
0000781a8ffdc47d  vmovaps xmm1, [rsp+0x10]
0000781a8ffdc483  vmovaps xmm2, [rsp+0x20]
0000781a8ffdc489  vmovaps xmm3, [rsp+0x30]
0000781a8ffdc48f  vmovaps xmm4, [rsp+0x40]
0000781a8ffdc495  vmovaps xmm5, [rsp+0x50]
0000781a8ffdc49b  vmovaps xmm6, [rsp+0x60]
0000781a8ffdc4a1  vmovaps xmm7, [rsp+0x70]
0000781a8ffdc4a7  vmovaps xmm8, [rsp+0x80]
0000781a8ffdc4b0  vmovaps xmm10, [rsp+0x90]
0000781a8ffdc4b9  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdc4c2  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdc4cb  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdc4d4  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdc4dd  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdc4e6  add rsp, 0xF0
0000781a8ffdc4ed  pop r11
0000781a8ffdc4ef  pop r10
0000781a8ffdc4f1  pop r9
0000781a8ffdc4f3  pop r8
0000781a8ffdc4f5  pop rsi
0000781a8ffdc4f6  pop rdi
0000781a8ffdc4f7  pop rdx
0000781a8ffdc4f8  pop rcx
0000781a8ffdc4f9  pop rax
0000781a8ffdc4fa  add rsp, 0x08
0000781a8ffdc4fe  jmp 0x0000781A8FFDA447
0000781a8ffdc503  sub rsp, 0x08
0000781a8ffdc507  push rax
0000781a8ffdc508  push rcx
0000781a8ffdc509  push rdx
0000781a8ffdc50a  push rdi
0000781a8ffdc50b  push rsi
0000781a8ffdc50c  push r8
0000781a8ffdc50e  push r9
0000781a8ffdc510  push r10
0000781a8ffdc512  push r11
0000781a8ffdc514  sub rsp, 0xF0
0000781a8ffdc51b  vmovaps [rsp], xmm0
0000781a8ffdc520  vmovaps [rsp+0x10], xmm1
0000781a8ffdc526  vmovaps [rsp+0x20], xmm2
0000781a8ffdc52c  vmovaps [rsp+0x30], xmm3
0000781a8ffdc532  vmovaps [rsp+0x40], xmm4
0000781a8ffdc538  vmovaps [rsp+0x50], xmm5
0000781a8ffdc53e  vmovaps [rsp+0x60], xmm6
0000781a8ffdc544  vmovaps [rsp+0x70], xmm7
0000781a8ffdc54a  vmovaps [rsp+0x80], xmm8
0000781a8ffdc553  vmovaps [rsp+0x90], xmm9
0000781a8ffdc55c  vmovaps [rsp+0xA0], xmm10
0000781a8ffdc565  vmovaps [rsp+0xB0], xmm12
0000781a8ffdc56e  vmovaps [rsp+0xC0], xmm13
0000781a8ffdc577  vmovaps [rsp+0xD0], xmm14
0000781a8ffdc580  vmovaps [rsp+0xE0], xmm15
0000781a8ffdc589  sub rsp, 0x40
0000781a8ffdc58d  lea rdi, [rsp]
0000781a8ffdc591  lea rsi, [rsp+0x10]
0000781a8ffdc596  lea rdx, [rsp+0x20]
0000781a8ffdc59b  lea rcx, [rsp+0x30]
0000781a8ffdc5a0  mov r8d, 0x00
0000781a8ffdc5a6  lea r9, [r15+0x3A8]
0000781a8ffdc5ad  movaps [rdi], xmm11
0000781a8ffdc5b1  movaps [rsi], xmm10
0000781a8ffdc5b5  movaps [rdx], xmm8
0000781a8ffdc5b9  movaps [rcx], xmm1
0000781a8ffdc5bc  mov rax, 0x627DDC279A50
0000781a8ffdc5c6  call rax
0000781a8ffdc5c8  movaps xmm11, [rsp]
0000781a8ffdc5cd  add rsp, 0x40
0000781a8ffdc5d1  vmovaps xmm0, [rsp]
0000781a8ffdc5d6  vmovaps xmm1, [rsp+0x10]
0000781a8ffdc5dc  vmovaps xmm2, [rsp+0x20]
0000781a8ffdc5e2  vmovaps xmm3, [rsp+0x30]
0000781a8ffdc5e8  vmovaps xmm4, [rsp+0x40]
0000781a8ffdc5ee  vmovaps xmm5, [rsp+0x50]
0000781a8ffdc5f4  vmovaps xmm6, [rsp+0x60]
0000781a8ffdc5fa  vmovaps xmm7, [rsp+0x70]
0000781a8ffdc600  vmovaps xmm8, [rsp+0x80]
0000781a8ffdc609  vmovaps xmm9, [rsp+0x90]
0000781a8ffdc612  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdc61b  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdc624  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdc62d  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdc636  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdc63f  add rsp, 0xF0
0000781a8ffdc646  pop r11
0000781a8ffdc648  pop r10
0000781a8ffdc64a  pop r9
0000781a8ffdc64c  pop r8
0000781a8ffdc64e  pop rsi
0000781a8ffdc64f  pop rdi
0000781a8ffdc650  pop rdx
0000781a8ffdc651  pop rcx
0000781a8ffdc652  pop rax
0000781a8ffdc653  add rsp, 0x08
0000781a8ffdc657  jmp 0x0000781A8FFDA46D
0000781a8ffdc65c  sub rsp, 0x08
0000781a8ffdc660  push rax
0000781a8ffdc661  push rcx
0000781a8ffdc662  push rdx
0000781a8ffdc663  push rdi
0000781a8ffdc664  push rsi
0000781a8ffdc665  push r8
0000781a8ffdc667  push r9
0000781a8ffdc669  push r10
0000781a8ffdc66b  push r11
0000781a8ffdc66d  sub rsp, 0xF0
0000781a8ffdc674  vmovaps [rsp], xmm0
0000781a8ffdc679  vmovaps [rsp+0x10], xmm1
0000781a8ffdc67f  vmovaps [rsp+0x20], xmm2
0000781a8ffdc685  vmovaps [rsp+0x30], xmm3
0000781a8ffdc68b  vmovaps [rsp+0x40], xmm4
0000781a8ffdc691  vmovaps [rsp+0x50], xmm5
0000781a8ffdc697  vmovaps [rsp+0x60], xmm6
0000781a8ffdc69d  vmovaps [rsp+0x70], xmm7
0000781a8ffdc6a3  vmovaps [rsp+0x80], xmm8
0000781a8ffdc6ac  vmovaps [rsp+0x90], xmm9
0000781a8ffdc6b5  vmovaps [rsp+0xA0], xmm11
0000781a8ffdc6be  vmovaps [rsp+0xB0], xmm12
0000781a8ffdc6c7  vmovaps [rsp+0xC0], xmm13
0000781a8ffdc6d0  vmovaps [rsp+0xD0], xmm14
0000781a8ffdc6d9  vmovaps [rsp+0xE0], xmm15
0000781a8ffdc6e2  sub rsp, 0x40
0000781a8ffdc6e6  lea rdi, [rsp]
0000781a8ffdc6ea  lea rsi, [rsp+0x10]
0000781a8ffdc6ef  lea rdx, [rsp+0x20]
0000781a8ffdc6f4  lea rcx, [rsp+0x30]
0000781a8ffdc6f9  mov r8d, 0x00
0000781a8ffdc6ff  lea r9, [r15+0x3A8]
0000781a8ffdc706  movaps [rdi], xmm10
0000781a8ffdc70a  movaps [rsi], xmm12
0000781a8ffdc70e  movaps [rdx], xmm13
0000781a8ffdc712  movaps [rcx], xmm1
0000781a8ffdc715  mov rax, 0x627DDC279A50
0000781a8ffdc71f  call rax
0000781a8ffdc721  movaps xmm10, [rsp]
0000781a8ffdc726  add rsp, 0x40
0000781a8ffdc72a  vmovaps xmm0, [rsp]
0000781a8ffdc72f  vmovaps xmm1, [rsp+0x10]
0000781a8ffdc735  vmovaps xmm2, [rsp+0x20]
0000781a8ffdc73b  vmovaps xmm3, [rsp+0x30]
0000781a8ffdc741  vmovaps xmm4, [rsp+0x40]
0000781a8ffdc747  vmovaps xmm5, [rsp+0x50]
0000781a8ffdc74d  vmovaps xmm6, [rsp+0x60]
0000781a8ffdc753  vmovaps xmm7, [rsp+0x70]
0000781a8ffdc759  vmovaps xmm8, [rsp+0x80]
0000781a8ffdc762  vmovaps xmm9, [rsp+0x90]
0000781a8ffdc76b  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdc774  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdc77d  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdc786  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdc78f  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdc798  add rsp, 0xF0
0000781a8ffdc79f  pop r11
0000781a8ffdc7a1  pop r10
0000781a8ffdc7a3  pop r9
0000781a8ffdc7a5  pop r8
0000781a8ffdc7a7  pop rsi
0000781a8ffdc7a8  pop rdi
0000781a8ffdc7a9  pop rdx
0000781a8ffdc7aa  pop rcx
0000781a8ffdc7ab  pop rax
0000781a8ffdc7ac  add rsp, 0x08
0000781a8ffdc7b0  jmp 0x0000781A8FFDA493
0000781a8ffdc7b5  call 0x0000781A8FDFF430
0000781a8ffdc7ba  jmp 0x0000781A8FFDA49D
0000781a8ffdc7bf  call 0x0000781A8FE0C260
0000781a8ffdc7c4  jmp 0x0000781A8FFDA4A7
0000781a8ffdc7c9  sub rsp, 0x08
0000781a8ffdc7cd  push rax
0000781a8ffdc7ce  push rcx
0000781a8ffdc7cf  push rdx
0000781a8ffdc7d0  push rdi
0000781a8ffdc7d1  push rsi
0000781a8ffdc7d2  push r8
0000781a8ffdc7d4  push r9
0000781a8ffdc7d6  push r10
0000781a8ffdc7d8  push r11
0000781a8ffdc7da  sub rsp, 0xF0
0000781a8ffdc7e1  vmovaps [rsp], xmm0
0000781a8ffdc7e6  vmovaps [rsp+0x10], xmm1
0000781a8ffdc7ec  vmovaps [rsp+0x20], xmm2
0000781a8ffdc7f2  vmovaps [rsp+0x30], xmm3
0000781a8ffdc7f8  vmovaps [rsp+0x40], xmm4
0000781a8ffdc7fe  vmovaps [rsp+0x50], xmm5
0000781a8ffdc804  vmovaps [rsp+0x60], xmm6
0000781a8ffdc80a  vmovaps [rsp+0x70], xmm7
0000781a8ffdc810  vmovaps [rsp+0x80], xmm9
0000781a8ffdc819  vmovaps [rsp+0x90], xmm10
0000781a8ffdc822  vmovaps [rsp+0xA0], xmm11
0000781a8ffdc82b  vmovaps [rsp+0xB0], xmm12
0000781a8ffdc834  vmovaps [rsp+0xC0], xmm13
0000781a8ffdc83d  vmovaps [rsp+0xD0], xmm14
0000781a8ffdc846  vmovaps [rsp+0xE0], xmm15
0000781a8ffdc84f  sub rsp, 0x40
0000781a8ffdc853  lea rdi, [rsp]
0000781a8ffdc857  lea rsi, [rsp+0x10]
0000781a8ffdc85c  lea rdx, [rsp+0x20]
0000781a8ffdc861  lea rcx, [rsp+0x30]
0000781a8ffdc866  mov r8d, 0x00
0000781a8ffdc86c  lea r9, [r15+0x3A8]
0000781a8ffdc873  movaps [rdi], xmm8
0000781a8ffdc877  movaps [rsi], xmm7
0000781a8ffdc87a  movaps [rdx], xmm4
0000781a8ffdc87d  movaps [rcx], xmm12
0000781a8ffdc881  mov rax, 0x627DDC279A50
0000781a8ffdc88b  call rax
0000781a8ffdc88d  movaps xmm8, [rsp]
0000781a8ffdc892  add rsp, 0x40
0000781a8ffdc896  vmovaps xmm0, [rsp]
0000781a8ffdc89b  vmovaps xmm1, [rsp+0x10]
0000781a8ffdc8a1  vmovaps xmm2, [rsp+0x20]
0000781a8ffdc8a7  vmovaps xmm3, [rsp+0x30]
0000781a8ffdc8ad  vmovaps xmm4, [rsp+0x40]
0000781a8ffdc8b3  vmovaps xmm5, [rsp+0x50]
0000781a8ffdc8b9  vmovaps xmm6, [rsp+0x60]
0000781a8ffdc8bf  vmovaps xmm7, [rsp+0x70]
0000781a8ffdc8c5  vmovaps xmm9, [rsp+0x80]
0000781a8ffdc8ce  vmovaps xmm10, [rsp+0x90]
0000781a8ffdc8d7  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdc8e0  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdc8e9  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdc8f2  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdc8fb  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdc904  add rsp, 0xF0
0000781a8ffdc90b  pop r11
0000781a8ffdc90d  pop r10
0000781a8ffdc90f  pop r9
0000781a8ffdc911  pop r8
0000781a8ffdc913  pop rsi
0000781a8ffdc914  pop rdi
0000781a8ffdc915  pop rdx
0000781a8ffdc916  pop rcx
0000781a8ffdc917  pop rax
0000781a8ffdc918  add rsp, 0x08
0000781a8ffdc91c  jmp 0x0000781A8FFDA4D0
0000781a8ffdc921  sub rsp, 0x08
0000781a8ffdc925  push rax
0000781a8ffdc926  push rcx
0000781a8ffdc927  push rdx
0000781a8ffdc928  push rdi
0000781a8ffdc929  push rsi
0000781a8ffdc92a  push r8
0000781a8ffdc92c  push r9
0000781a8ffdc92e  push r10
0000781a8ffdc930  push r11
0000781a8ffdc932  sub rsp, 0xF0
0000781a8ffdc939  vmovaps [rsp], xmm0
0000781a8ffdc93e  vmovaps [rsp+0x10], xmm1
0000781a8ffdc944  vmovaps [rsp+0x20], xmm2
0000781a8ffdc94a  vmovaps [rsp+0x30], xmm3
0000781a8ffdc950  vmovaps [rsp+0x40], xmm4
0000781a8ffdc956  vmovaps [rsp+0x50], xmm5
0000781a8ffdc95c  vmovaps [rsp+0x60], xmm6
0000781a8ffdc962  vmovaps [rsp+0x70], xmm8
0000781a8ffdc968  vmovaps [rsp+0x80], xmm9
0000781a8ffdc971  vmovaps [rsp+0x90], xmm10
0000781a8ffdc97a  vmovaps [rsp+0xA0], xmm11
0000781a8ffdc983  vmovaps [rsp+0xB0], xmm12
0000781a8ffdc98c  vmovaps [rsp+0xC0], xmm13
0000781a8ffdc995  vmovaps [rsp+0xD0], xmm14
0000781a8ffdc99e  vmovaps [rsp+0xE0], xmm15
0000781a8ffdc9a7  sub rsp, 0x40
0000781a8ffdc9ab  lea rdi, [rsp]
0000781a8ffdc9af  lea rsi, [rsp+0x10]
0000781a8ffdc9b4  lea rdx, [rsp+0x20]
0000781a8ffdc9b9  lea rcx, [rsp+0x30]
0000781a8ffdc9be  mov r8d, 0x00
0000781a8ffdc9c4  lea r9, [r15+0x3A8]
0000781a8ffdc9cb  movaps [rdi], xmm7
0000781a8ffdc9ce  movaps [rsi], xmm9
0000781a8ffdc9d2  movaps [rdx], xmm14
0000781a8ffdc9d6  movaps [rcx], xmm12
0000781a8ffdc9da  mov rax, 0x627DDC279A50
0000781a8ffdc9e4  call rax
0000781a8ffdc9e6  movaps xmm7, [rsp]
0000781a8ffdc9ea  add rsp, 0x40
0000781a8ffdc9ee  vmovaps xmm0, [rsp]
0000781a8ffdc9f3  vmovaps xmm1, [rsp+0x10]
0000781a8ffdc9f9  vmovaps xmm2, [rsp+0x20]
0000781a8ffdc9ff  vmovaps xmm3, [rsp+0x30]
0000781a8ffdca05  vmovaps xmm4, [rsp+0x40]
0000781a8ffdca0b  vmovaps xmm5, [rsp+0x50]
0000781a8ffdca11  vmovaps xmm6, [rsp+0x60]
0000781a8ffdca17  vmovaps xmm8, [rsp+0x70]
0000781a8ffdca1d  vmovaps xmm9, [rsp+0x80]
0000781a8ffdca26  vmovaps xmm10, [rsp+0x90]
0000781a8ffdca2f  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdca38  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdca41  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdca4a  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdca53  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdca5c  add rsp, 0xF0
0000781a8ffdca63  pop r11
0000781a8ffdca65  pop r10
0000781a8ffdca67  pop r9
0000781a8ffdca69  pop r8
0000781a8ffdca6b  pop rsi
0000781a8ffdca6c  pop rdi
0000781a8ffdca6d  pop rdx
0000781a8ffdca6e  pop rcx
0000781a8ffdca6f  pop rax
0000781a8ffdca70  add rsp, 0x08
0000781a8ffdca74  jmp 0x0000781A8FFDA4F8
0000781a8ffdca79  sub rsp, 0x08
0000781a8ffdca7d  push rax
0000781a8ffdca7e  push rcx
0000781a8ffdca7f  push rdx
0000781a8ffdca80  push rdi
0000781a8ffdca81  push rsi
0000781a8ffdca82  push r8
0000781a8ffdca84  push r9
0000781a8ffdca86  push r10
0000781a8ffdca88  push r11
0000781a8ffdca8a  sub rsp, 0xF0
0000781a8ffdca91  vmovaps [rsp], xmm0
0000781a8ffdca96  vmovaps [rsp+0x10], xmm1
0000781a8ffdca9c  vmovaps [rsp+0x20], xmm2
0000781a8ffdcaa2  vmovaps [rsp+0x30], xmm3
0000781a8ffdcaa8  vmovaps [rsp+0x40], xmm4
0000781a8ffdcaae  vmovaps [rsp+0x50], xmm5
0000781a8ffdcab4  vmovaps [rsp+0x60], xmm6
0000781a8ffdcaba  vmovaps [rsp+0x70], xmm7
0000781a8ffdcac0  vmovaps [rsp+0x80], xmm8
0000781a8ffdcac9  vmovaps [rsp+0x90], xmm9
0000781a8ffdcad2  vmovaps [rsp+0xA0], xmm10
0000781a8ffdcadb  vmovaps [rsp+0xB0], xmm11
0000781a8ffdcae4  vmovaps [rsp+0xC0], xmm13
0000781a8ffdcaed  vmovaps [rsp+0xD0], xmm14
0000781a8ffdcaf6  vmovaps [rsp+0xE0], xmm15
0000781a8ffdcaff  sub rsp, 0x40
0000781a8ffdcb03  lea rdi, [rsp]
0000781a8ffdcb07  lea rsi, [rsp+0x10]
0000781a8ffdcb0c  lea rdx, [rsp+0x20]
0000781a8ffdcb11  lea rcx, [rsp+0x30]
0000781a8ffdcb16  mov r8d, 0x00
0000781a8ffdcb1c  lea r9, [r15+0x3A8]
0000781a8ffdcb23  movaps [rdi], xmm12
0000781a8ffdcb27  movaps [rsi], xmm11
0000781a8ffdcb2b  movaps [rdx], xmm15
0000781a8ffdcb2f  movaps [rcx], xmm14
0000781a8ffdcb33  mov rax, 0x627DDC279A50
0000781a8ffdcb3d  call rax
0000781a8ffdcb3f  movaps xmm12, [rsp]
0000781a8ffdcb44  add rsp, 0x40
0000781a8ffdcb48  vmovaps xmm0, [rsp]
0000781a8ffdcb4d  vmovaps xmm1, [rsp+0x10]
0000781a8ffdcb53  vmovaps xmm2, [rsp+0x20]
0000781a8ffdcb59  vmovaps xmm3, [rsp+0x30]
0000781a8ffdcb5f  vmovaps xmm4, [rsp+0x40]
0000781a8ffdcb65  vmovaps xmm5, [rsp+0x50]
0000781a8ffdcb6b  vmovaps xmm6, [rsp+0x60]
0000781a8ffdcb71  vmovaps xmm7, [rsp+0x70]
0000781a8ffdcb77  vmovaps xmm8, [rsp+0x80]
0000781a8ffdcb80  vmovaps xmm9, [rsp+0x90]
0000781a8ffdcb89  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdcb92  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdcb9b  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdcba4  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdcbad  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdcbb6  add rsp, 0xF0
0000781a8ffdcbbd  pop r11
0000781a8ffdcbbf  pop r10
0000781a8ffdcbc1  pop r9
0000781a8ffdcbc3  pop r8
0000781a8ffdcbc5  pop rsi
0000781a8ffdcbc6  pop rdi
0000781a8ffdcbc7  pop rdx
0000781a8ffdcbc8  pop rcx
0000781a8ffdcbc9  pop rax
0000781a8ffdcbca  add rsp, 0x08
0000781a8ffdcbce  jmp 0x0000781A8FFDA521
0000781a8ffdcbd3  sub rsp, 0x08
0000781a8ffdcbd7  push rax
0000781a8ffdcbd8  push rcx
0000781a8ffdcbd9  push rdx
0000781a8ffdcbda  push rdi
0000781a8ffdcbdb  push rsi
0000781a8ffdcbdc  push r8
0000781a8ffdcbde  push r9
0000781a8ffdcbe0  push r10
0000781a8ffdcbe2  push r11
0000781a8ffdcbe4  sub rsp, 0xF0
0000781a8ffdcbeb  vmovaps [rsp], xmm0
0000781a8ffdcbf0  vmovaps [rsp+0x10], xmm1
0000781a8ffdcbf6  vmovaps [rsp+0x20], xmm2
0000781a8ffdcbfc  vmovaps [rsp+0x30], xmm3
0000781a8ffdcc02  vmovaps [rsp+0x40], xmm4
0000781a8ffdcc08  vmovaps [rsp+0x50], xmm5
0000781a8ffdcc0e  vmovaps [rsp+0x60], xmm6
0000781a8ffdcc14  vmovaps [rsp+0x70], xmm7
0000781a8ffdcc1a  vmovaps [rsp+0x80], xmm8
0000781a8ffdcc23  vmovaps [rsp+0x90], xmm9
0000781a8ffdcc2c  vmovaps [rsp+0xA0], xmm10
0000781a8ffdcc35  vmovaps [rsp+0xB0], xmm12
0000781a8ffdcc3e  vmovaps [rsp+0xC0], xmm13
0000781a8ffdcc47  vmovaps [rsp+0xD0], xmm14
0000781a8ffdcc50  vmovaps [rsp+0xE0], xmm15
0000781a8ffdcc59  sub rsp, 0x40
0000781a8ffdcc5d  lea rdi, [rsp]
0000781a8ffdcc61  lea rsi, [rsp+0x10]
0000781a8ffdcc66  lea rdx, [rsp+0x20]
0000781a8ffdcc6b  lea rcx, [rsp+0x30]
0000781a8ffdcc70  mov r8d, 0x00
0000781a8ffdcc76  lea r9, [r15+0x3A8]
0000781a8ffdcc7d  movaps [rdi], xmm11
0000781a8ffdcc81  movaps [rsi], xmm10
0000781a8ffdcc85  movaps [rdx], xmm13
0000781a8ffdcc89  movaps [rcx], xmm15
0000781a8ffdcc8d  mov rax, 0x627DDC279A50
0000781a8ffdcc97  call rax
0000781a8ffdcc99  movaps xmm11, [rsp]
0000781a8ffdcc9e  add rsp, 0x40
0000781a8ffdcca2  vmovaps xmm0, [rsp]
0000781a8ffdcca7  vmovaps xmm1, [rsp+0x10]
0000781a8ffdccad  vmovaps xmm2, [rsp+0x20]
0000781a8ffdccb3  vmovaps xmm3, [rsp+0x30]
0000781a8ffdccb9  vmovaps xmm4, [rsp+0x40]
0000781a8ffdccbf  vmovaps xmm5, [rsp+0x50]
0000781a8ffdccc5  vmovaps xmm6, [rsp+0x60]
0000781a8ffdcccb  vmovaps xmm7, [rsp+0x70]
0000781a8ffdccd1  vmovaps xmm8, [rsp+0x80]
0000781a8ffdccda  vmovaps xmm9, [rsp+0x90]
0000781a8ffdcce3  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdccec  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdccf5  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdccfe  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdcd07  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdcd10  add rsp, 0xF0
0000781a8ffdcd17  pop r11
0000781a8ffdcd19  pop r10
0000781a8ffdcd1b  pop r9
0000781a8ffdcd1d  pop r8
0000781a8ffdcd1f  pop rsi
0000781a8ffdcd20  pop rdi
0000781a8ffdcd21  pop rdx
0000781a8ffdcd22  pop rcx
0000781a8ffdcd23  pop rax
0000781a8ffdcd24  add rsp, 0x08
0000781a8ffdcd28  jmp 0x0000781A8FFDA54A
0000781a8ffdcd2d  call 0x0000781A8FE0E760
0000781a8ffdcd32  jmp 0x0000781A8FFDA557
0000781a8ffdcd37  call 0x0000781A8FE0D4E0
0000781a8ffdcd3c  jmp 0x0000781A8FFDA564
0000781a8ffdcd41  sub rsp, 0x08
0000781a8ffdcd45  push rax
0000781a8ffdcd46  push rcx
0000781a8ffdcd47  push rdx
0000781a8ffdcd48  push rdi
0000781a8ffdcd49  push rsi
0000781a8ffdcd4a  push r8
0000781a8ffdcd4c  push r9
0000781a8ffdcd4e  push r10
0000781a8ffdcd50  push r11
0000781a8ffdcd52  sub rsp, 0xF0
0000781a8ffdcd59  vmovaps [rsp], xmm0
0000781a8ffdcd5e  vmovaps [rsp+0x10], xmm1
0000781a8ffdcd64  vmovaps [rsp+0x20], xmm2
0000781a8ffdcd6a  vmovaps [rsp+0x30], xmm3
0000781a8ffdcd70  vmovaps [rsp+0x40], xmm4
0000781a8ffdcd76  vmovaps [rsp+0x50], xmm5
0000781a8ffdcd7c  vmovaps [rsp+0x60], xmm6
0000781a8ffdcd82  vmovaps [rsp+0x70], xmm7
0000781a8ffdcd88  vmovaps [rsp+0x80], xmm8
0000781a8ffdcd91  vmovaps [rsp+0x90], xmm9
0000781a8ffdcd9a  vmovaps [rsp+0xA0], xmm11
0000781a8ffdcda3  vmovaps [rsp+0xB0], xmm12
0000781a8ffdcdac  vmovaps [rsp+0xC0], xmm13
0000781a8ffdcdb5  vmovaps [rsp+0xD0], xmm14
0000781a8ffdcdbe  vmovaps [rsp+0xE0], xmm15
0000781a8ffdcdc7  sub rsp, 0x40
0000781a8ffdcdcb  lea rdi, [rsp]
0000781a8ffdcdcf  lea rsi, [rsp+0x10]
0000781a8ffdcdd4  lea rdx, [rsp+0x20]
0000781a8ffdcdd9  lea rcx, [rsp+0x30]
0000781a8ffdcdde  mov r8d, 0x00
0000781a8ffdcde4  lea r9, [r15+0x3A8]
0000781a8ffdcdeb  movaps [rdi], xmm10
0000781a8ffdcdef  movaps [rsi], xmm8
0000781a8ffdcdf3  movaps [rdx], xmm1
0000781a8ffdcdf6  movaps [rcx], xmm13
0000781a8ffdcdfa  mov rax, 0x627DDC279A50
0000781a8ffdce04  call rax
0000781a8ffdce06  movaps xmm10, [rsp]
0000781a8ffdce0b  add rsp, 0x40
0000781a8ffdce0f  vmovaps xmm0, [rsp]
0000781a8ffdce14  vmovaps xmm1, [rsp+0x10]
0000781a8ffdce1a  vmovaps xmm2, [rsp+0x20]
0000781a8ffdce20  vmovaps xmm3, [rsp+0x30]
0000781a8ffdce26  vmovaps xmm4, [rsp+0x40]
0000781a8ffdce2c  vmovaps xmm5, [rsp+0x50]
0000781a8ffdce32  vmovaps xmm6, [rsp+0x60]
0000781a8ffdce38  vmovaps xmm7, [rsp+0x70]
0000781a8ffdce3e  vmovaps xmm8, [rsp+0x80]
0000781a8ffdce47  vmovaps xmm9, [rsp+0x90]
0000781a8ffdce50  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdce59  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdce62  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdce6b  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdce74  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdce7d  add rsp, 0xF0
0000781a8ffdce84  pop r11
0000781a8ffdce86  pop r10
0000781a8ffdce88  pop r9
0000781a8ffdce8a  pop r8
0000781a8ffdce8c  pop rsi
0000781a8ffdce8d  pop rdi
0000781a8ffdce8e  pop rdx
0000781a8ffdce8f  pop rcx
0000781a8ffdce90  pop rax
0000781a8ffdce91  add rsp, 0x08
0000781a8ffdce95  jmp 0x0000781A8FFDA59A
0000781a8ffdce9a  call 0x0000781A8FDFF430
0000781a8ffdce9f  jmp 0x0000781A8FFDA5AC
0000781a8ffdcea4  sub rsp, 0x08
0000781a8ffdcea8  push rax
0000781a8ffdcea9  push rcx
0000781a8ffdceaa  push rdx
0000781a8ffdceab  push rdi
0000781a8ffdceac  push rsi
0000781a8ffdcead  push r8
0000781a8ffdceaf  push r9
0000781a8ffdceb1  push r10
0000781a8ffdceb3  push r11
0000781a8ffdceb5  sub rsp, 0xF0
0000781a8ffdcebc  vmovaps [rsp], xmm0
0000781a8ffdcec1  vmovaps [rsp+0x10], xmm1
0000781a8ffdcec7  vmovaps [rsp+0x20], xmm2
0000781a8ffdcecd  vmovaps [rsp+0x30], xmm3
0000781a8ffdced3  vmovaps [rsp+0x40], xmm4
0000781a8ffdced9  vmovaps [rsp+0x50], xmm5
0000781a8ffdcedf  vmovaps [rsp+0x60], xmm6
0000781a8ffdcee5  vmovaps [rsp+0x70], xmm7
0000781a8ffdceeb  vmovaps [rsp+0x80], xmm8
0000781a8ffdcef4  vmovaps [rsp+0x90], xmm10
0000781a8ffdcefd  vmovaps [rsp+0xA0], xmm11
0000781a8ffdcf06  vmovaps [rsp+0xB0], xmm12
0000781a8ffdcf0f  vmovaps [rsp+0xC0], xmm13
0000781a8ffdcf18  vmovaps [rsp+0xD0], xmm14
0000781a8ffdcf21  vmovaps [rsp+0xE0], xmm15
0000781a8ffdcf2a  sub rsp, 0x40
0000781a8ffdcf2e  lea rdi, [rsp]
0000781a8ffdcf32  lea rsi, [rsp+0x10]
0000781a8ffdcf37  lea rdx, [rsp+0x20]
0000781a8ffdcf3c  lea rcx, [rsp+0x30]
0000781a8ffdcf41  mov r8d, 0x00
0000781a8ffdcf47  lea r9, [r15+0x3A8]
0000781a8ffdcf4e  movaps [rdi], xmm9
0000781a8ffdcf52  movaps [rsi], xmm7
0000781a8ffdcf55  movaps [rdx], xmm14
0000781a8ffdcf59  movaps [rcx], xmm13
0000781a8ffdcf5d  mov rax, 0x627DDC279A50
0000781a8ffdcf67  call rax
0000781a8ffdcf69  movaps xmm9, [rsp]
0000781a8ffdcf6e  add rsp, 0x40
0000781a8ffdcf72  vmovaps xmm0, [rsp]
0000781a8ffdcf77  vmovaps xmm1, [rsp+0x10]
0000781a8ffdcf7d  vmovaps xmm2, [rsp+0x20]
0000781a8ffdcf83  vmovaps xmm3, [rsp+0x30]
0000781a8ffdcf89  vmovaps xmm4, [rsp+0x40]
0000781a8ffdcf8f  vmovaps xmm5, [rsp+0x50]
0000781a8ffdcf95  vmovaps xmm6, [rsp+0x60]
0000781a8ffdcf9b  vmovaps xmm7, [rsp+0x70]
0000781a8ffdcfa1  vmovaps xmm8, [rsp+0x80]
0000781a8ffdcfaa  vmovaps xmm10, [rsp+0x90]
0000781a8ffdcfb3  vmovaps xmm11, [rsp+0xA0]
0000781a8ffdcfbc  vmovaps xmm12, [rsp+0xB0]
0000781a8ffdcfc5  vmovaps xmm13, [rsp+0xC0]
0000781a8ffdcfce  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdcfd7  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdcfe0  add rsp, 0xF0
0000781a8ffdcfe7  pop r11
0000781a8ffdcfe9  pop r10
0000781a8ffdcfeb  pop r9
0000781a8ffdcfed  pop r8
0000781a8ffdcfef  pop rsi
0000781a8ffdcff0  pop rdi
0000781a8ffdcff1  pop rdx
0000781a8ffdcff2  pop rcx
0000781a8ffdcff3  pop rax
0000781a8ffdcff4  add rsp, 0x08
0000781a8ffdcff8  jmp 0x0000781A8FFDA5DA
0000781a8ffdcffd  sub rsp, 0x08
0000781a8ffdd001  push rax
0000781a8ffdd002  push rcx
0000781a8ffdd003  push rdx
0000781a8ffdd004  push rdi
0000781a8ffdd005  push rsi
0000781a8ffdd006  push r8
0000781a8ffdd008  push r9
0000781a8ffdd00a  push r10
0000781a8ffdd00c  push r11
0000781a8ffdd00e  sub rsp, 0xF0
0000781a8ffdd015  vmovaps [rsp], xmm0
0000781a8ffdd01a  vmovaps [rsp+0x10], xmm1
0000781a8ffdd020  vmovaps [rsp+0x20], xmm2
0000781a8ffdd026  vmovaps [rsp+0x30], xmm3
0000781a8ffdd02c  vmovaps [rsp+0x40], xmm4
0000781a8ffdd032  vmovaps [rsp+0x50], xmm5
0000781a8ffdd038  vmovaps [rsp+0x60], xmm6
0000781a8ffdd03e  vmovaps [rsp+0x70], xmm7
0000781a8ffdd044  vmovaps [rsp+0x80], xmm8
0000781a8ffdd04d  vmovaps [rsp+0x90], xmm9
0000781a8ffdd056  vmovaps [rsp+0xA0], xmm10
0000781a8ffdd05f  vmovaps [rsp+0xB0], xmm11
0000781a8ffdd068  vmovaps [rsp+0xC0], xmm12
0000781a8ffdd071  vmovaps [rsp+0xD0], xmm14
0000781a8ffdd07a  vmovaps [rsp+0xE0], xmm15
0000781a8ffdd083  sub rsp, 0x40
0000781a8ffdd087  lea rdi, [rsp]
0000781a8ffdd08b  lea rsi, [rsp+0x10]
0000781a8ffdd090  lea rdx, [rsp+0x20]
0000781a8ffdd095  lea rcx, [rsp+0x30]
0000781a8ffdd09a  mov r8d, 0x00
0000781a8ffdd0a0  lea r9, [r15+0x3A8]
0000781a8ffdd0a7  movaps [rdi], xmm13
0000781a8ffdd0ab  movaps [rsi], xmm12
0000781a8ffdd0af  movaps [rdx], xmm15
0000781a8ffdd0b3  movaps [rcx], xmm14
0000781a8ffdd0b7  mov rax, 0x627DDC279A50
0000781a8ffdd0c1  call rax
0000781a8ffdd0c3  movaps xmm13, [rsp]
0000781a8ffdd0c8  add rsp, 0x40
0000781a8ffdd0cc  vmovaps xmm0, [rsp]
0000781a8ffdd0d1  vmovaps xmm1, [rsp+0x10]
0000781a8ffdd0d7  vmovaps xmm2, [rsp+0x20]
0000781a8ffdd0dd  vmovaps xmm3, [rsp+0x30]
0000781a8ffdd0e3  vmovaps xmm4, [rsp+0x40]
0000781a8ffdd0e9  vmovaps xmm5, [rsp+0x50]
0000781a8ffdd0ef  vmovaps xmm6, [rsp+0x60]
0000781a8ffdd0f5  vmovaps xmm7, [rsp+0x70]
0000781a8ffdd0fb  vmovaps xmm8, [rsp+0x80]
0000781a8ffdd104  vmovaps xmm9, [rsp+0x90]
0000781a8ffdd10d  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdd116  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdd11f  vmovaps xmm12, [rsp+0xC0]
0000781a8ffdd128  vmovaps xmm14, [rsp+0xD0]
0000781a8ffdd131  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdd13a  add rsp, 0xF0
0000781a8ffdd141  pop r11
0000781a8ffdd143  pop r10
0000781a8ffdd145  pop r9
0000781a8ffdd147  pop r8
0000781a8ffdd149  pop rsi
0000781a8ffdd14a  pop rdi
0000781a8ffdd14b  pop rdx
0000781a8ffdd14c  pop rcx
0000781a8ffdd14d  pop rax
0000781a8ffdd14e  add rsp, 0x08
0000781a8ffdd152  jmp 0x0000781A8FFDA608
0000781a8ffdd157  sub rsp, 0x08
0000781a8ffdd15b  push rax
0000781a8ffdd15c  push rcx
0000781a8ffdd15d  push rdx
0000781a8ffdd15e  push rdi
0000781a8ffdd15f  push rsi
0000781a8ffdd160  push r8
0000781a8ffdd162  push r9
0000781a8ffdd164  push r10
0000781a8ffdd166  push r11
0000781a8ffdd168  sub rsp, 0xF0
0000781a8ffdd16f  vmovaps [rsp], xmm0
0000781a8ffdd174  vmovaps [rsp+0x10], xmm1
0000781a8ffdd17a  vmovaps [rsp+0x20], xmm2
0000781a8ffdd180  vmovaps [rsp+0x30], xmm3
0000781a8ffdd186  vmovaps [rsp+0x40], xmm4
0000781a8ffdd18c  vmovaps [rsp+0x50], xmm5
0000781a8ffdd192  vmovaps [rsp+0x60], xmm6
0000781a8ffdd198  vmovaps [rsp+0x70], xmm7
0000781a8ffdd19e  vmovaps [rsp+0x80], xmm8
0000781a8ffdd1a7  vmovaps [rsp+0x90], xmm9
0000781a8ffdd1b0  vmovaps [rsp+0xA0], xmm10
0000781a8ffdd1b9  vmovaps [rsp+0xB0], xmm11
0000781a8ffdd1c2  vmovaps [rsp+0xC0], xmm12
0000781a8ffdd1cb  vmovaps [rsp+0xD0], xmm13
0000781a8ffdd1d4  vmovaps [rsp+0xE0], xmm15
0000781a8ffdd1dd  sub rsp, 0x40
0000781a8ffdd1e1  lea rdi, [rsp]
0000781a8ffdd1e5  lea rsi, [rsp+0x10]
0000781a8ffdd1ea  lea rdx, [rsp+0x20]
0000781a8ffdd1ef  lea rcx, [rsp+0x30]
0000781a8ffdd1f4  mov r8d, 0x00
0000781a8ffdd1fa  lea r9, [r15+0x3A8]
0000781a8ffdd201  movaps [rdi], xmm14
0000781a8ffdd205  movaps [rsi], xmm11
0000781a8ffdd209  movaps [rdx], xmm1
0000781a8ffdd20c  movaps [rcx], xmm15
0000781a8ffdd210  mov rax, 0x627DDC279A50
0000781a8ffdd21a  call rax
0000781a8ffdd21c  movaps xmm14, [rsp]
0000781a8ffdd221  add rsp, 0x40
0000781a8ffdd225  vmovaps xmm0, [rsp]
0000781a8ffdd22a  vmovaps xmm1, [rsp+0x10]
0000781a8ffdd230  vmovaps xmm2, [rsp+0x20]
0000781a8ffdd236  vmovaps xmm3, [rsp+0x30]
0000781a8ffdd23c  vmovaps xmm4, [rsp+0x40]
0000781a8ffdd242  vmovaps xmm5, [rsp+0x50]
0000781a8ffdd248  vmovaps xmm6, [rsp+0x60]
0000781a8ffdd24e  vmovaps xmm7, [rsp+0x70]
0000781a8ffdd254  vmovaps xmm8, [rsp+0x80]
0000781a8ffdd25d  vmovaps xmm9, [rsp+0x90]
0000781a8ffdd266  vmovaps xmm10, [rsp+0xA0]
0000781a8ffdd26f  vmovaps xmm11, [rsp+0xB0]
0000781a8ffdd278  vmovaps xmm12, [rsp+0xC0]
0000781a8ffdd281  vmovaps xmm13, [rsp+0xD0]
0000781a8ffdd28a  vmovaps xmm15, [rsp+0xE0]
0000781a8ffdd293  add rsp, 0xF0
0000781a8ffdd29a  pop r11
0000781a8ffdd29c  pop r10
0000781a8ffdd29e  pop r9
0000781a8ffdd2a0  pop r8
0000781a8ffdd2a2  pop rsi
0000781a8ffdd2a3  pop rdi
0000781a8ffdd2a4  pop rdx
0000781a8ffdd2a5  pop rcx
0000781a8ffdd2a6  pop rax
0000781a8ffdd2a7  add rsp, 0x08
0000781a8ffdd2ab  jmp 0x0000781A8FFDA636
0000781a8ffdd2b0  call 0x0000781A8FE079B0
0000781a8ffdd2b5  jmp 0x0000781A8FFDA64C
0000781a8ffdd2ba  call 0x0000781A8FEE3440
0000781a8ffdd2bf  jmp 0x0000781A8FFDA656
0000781a8ffdd2c4  call 0x0000781A8FEDFCE0
0000781a8ffdd2c9  jmp 0x0000781A8FFDA660
0000781a8ffdd2ce  call 0x0000781A8FEE46C0
0000781a8ffdd2d3  jmp 0x0000781A8FFDA66A
0000781a8ffdd2d8  int3
0000781a8ffdd2d9  nop [rax], eax
0000781a8ffdd2e0  mov qword ptr [r15+0x40], 0x430000
0000781a8ffdd2e8  mov eax, 0x430C50
0000781a8ffdd2ed  mov r14, [r13+rax*1]
0000781a8ffdd2f2  movq xmm1, r14
0000781a8ffdd2f7  mov rax, [r15+0x50]
0000781a8ffdd2fb  movups xmm15, [r13+rax*1]
0000781a8ffdd301  movaps [r15+0x120], xmm15
0000781a8ffdd309  mov qword ptr [r15+0x48], 0x10
0000781a8ffdd311  xor eax, eax
0000781a8ffdd313  mov r14d, 0x10
0000781a8ffdd319  mov r12d, 0x200
0000781a8ffdd31f  cmp r14, r12
0000781a8ffdd322  cmc
0000781a8ffdd323  lahf
0000781a8ffdd324  seto al
0000781a8ffdd327  mov [r15+0x108], eax
0000781a8ffdd32e  pextrq rax, xmm15, 0x01
0000781a8ffdd335  movq xmm14, rax
0000781a8ffdd33a  movaps [r15+0x130], xmm14
0000781a8ffdd342  movq rax, xmm1
0000781a8ffdd347  movq r14, xmm15
0000781a8ffdd34c  vmovq xmm1, rax
0000781a8ffdd351  vmovq xmm15, r14
0000781a8ffdd356  movaps xmm13, xmm1
0000781a8ffdd35a  addsd xmm13, xmm15
0000781a8ffdd35f  ucomisd xmm13, xmm13
0000781a8ffdd364  jp 0x0000781A8FFDD423
0000781a8ffdd36a  movq xmm13, xmm13
0000781a8ffdd36f  movq rax, xmm13
0000781a8ffdd374  movq r14, xmm14
0000781a8ffdd379  vmovq xmm1, rax
0000781a8ffdd37e  vmovq xmm15, r14
0000781a8ffdd383  movaps xmm14, xmm1
0000781a8ffdd387  addsd xmm14, xmm15
0000781a8ffdd38c  ucomisd xmm14, xmm14
0000781a8ffdd391  jp 0x0000781A8FFDD46B
0000781a8ffdd397  movq xmm14, xmm14
0000781a8ffdd39c  movaps [r15+0x110], xmm14
0000781a8ffdd3a4  mov eax, [r15+0x108]
0000781a8ffdd3ab  sahf
0000781a8ffdd3ac  jnz 0x0000781A8FFDD3DE
0000781a8ffdd3ae  cmp dword ptr [r15+0x318], 0x00
0000781a8ffdd3b6  jz 0x0000781A8FFDD680
0000781a8ffdd3bc  nop [rax+rax*1], ax
0000781a8ffdd3c5  nop [rax+rax*1], eax
0000781a8ffdd3cd  mov eax, 0x410698
0000781a8ffdd3d2  mov [r15+0x100], rax
0000781a8ffdd3d9  jmp 0x0000781A8FDFE110
0000781a8ffdd3de  cmp dword ptr [r15+0x318], 0x00
0000781a8ffdd3e6  jz 0x0000781A8FFDD4C0
0000781a8ffdd3ec  nop [rax+rax*1], ax
0000781a8ffdd3f5  nop [rax+rax*1], eax
0000781a8ffdd3fd  mov eax, 0x41067C
0000781a8ffdd402  mov [r15+0x100], rax
0000781a8ffdd409  jmp 0x0000781A8FDFE110
0000781a8ffdd40e  int3
0000781a8ffdd40f  call 0x0000781A8FE0DC20
0000781a8ffdd414  jmp 0x0000781A8FFDD2F2
0000781a8ffdd419  call 0x0000781A8FE0E760
0000781a8ffdd41e  jmp 0x0000781A8FFDD301
0000781a8ffdd423  ucomisd xmm1, xmm15
0000781a8ffdd428  jp 0x0000781A8FFDD437
0000781a8ffdd42a  movaps xmm13, [0x0000781A8FBFE060]
0000781a8ffdd432  jmp 0x0000781A8FFDD36A
0000781a8ffdd437  vxorps xmm0, xmm1, xmm15
0000781a8ffdd43c  pextrw eax, xmm0, 0x03
0000781a8ffdd441  and eax, 0x7FF8
0000781a8ffdd446  cmp eax, 0x08
0000781a8ffdd449  jnz 0x0000781A8FFDD36A
0000781a8ffdd44f  movq rax, xmm15
0000781a8ffdd454  shl rax, 0x0D
0000781a8ffdd458  jbe 0x0000781A8FFDD36A
0000781a8ffdd45e  vorps xmm13, xmm15, [0x0000781A8FBFE070]
0000781a8ffdd466  jmp 0x0000781A8FFDD36A
0000781a8ffdd46b  ucomisd xmm1, xmm15
0000781a8ffdd470  jp 0x0000781A8FFDD47F
0000781a8ffdd472  movaps xmm14, [0x0000781A8FBFE060]
0000781a8ffdd47a  jmp 0x0000781A8FFDD397
0000781a8ffdd47f  vxorps xmm0, xmm1, xmm15
0000781a8ffdd484  pextrw eax, xmm0, 0x03
0000781a8ffdd489  and eax, 0x7FF8
0000781a8ffdd48e  cmp eax, 0x08
0000781a8ffdd491  jnz 0x0000781A8FFDD397
0000781a8ffdd497  movq rax, xmm15
0000781a8ffdd49c  shl rax, 0x0D
0000781a8ffdd4a0  jbe 0x0000781A8FFDD397
0000781a8ffdd4a6  vorps xmm14, xmm15, [0x0000781A8FBFE070]
0000781a8ffdd4ae  jmp 0x0000781A8FFDD397
0000781a8ffdd4b3  int3
0000781a8ffdd4b4  nop [rax+rax*1], ax
0000781a8ffdd4bd  nop [rax], eax
0000781a8ffdd4c0  mov rax, [r15+0x48]
0000781a8ffdd4c4  mov r14, [r15+0x50]
0000781a8ffdd4c8  lea r12, [r14+rax*1]
0000781a8ffdd4cc  movups xmm1, [r13+r12*1]
0000781a8ffdd4d2  movaps [r15+0x120], xmm1
0000781a8ffdd4da  lea r14, [rax+0x10]
0000781a8ffdd4de  mov [r15+0x48], r14
0000781a8ffdd4e2  xor eax, eax
0000781a8ffdd4e4  mov r12d, 0x200
0000781a8ffdd4ea  cmp r14, r12
0000781a8ffdd4ed  cmc
0000781a8ffdd4ee  lahf
0000781a8ffdd4ef  seto al
0000781a8ffdd4f2  mov [r15+0x108], eax
0000781a8ffdd4f9  pextrq rax, xmm1, 0x01
0000781a8ffdd500  movq xmm15, rax
0000781a8ffdd505  movaps [r15+0x130], xmm15
0000781a8ffdd50d  movaps xmm14, [r15+0x110]
0000781a8ffdd515  movq rax, xmm14
0000781a8ffdd51a  movq r14, xmm1
0000781a8ffdd51f  vmovq xmm1, rax
0000781a8ffdd524  vmovq xmm14, r14
0000781a8ffdd529  movaps xmm13, xmm1
0000781a8ffdd52d  addsd xmm13, xmm14
0000781a8ffdd532  ucomisd xmm13, xmm13
0000781a8ffdd537  jp 0x0000781A8FFDD5EC
0000781a8ffdd53d  movq xmm13, xmm13
0000781a8ffdd542  movq rax, xmm13
0000781a8ffdd547  movq r14, xmm15
0000781a8ffdd54c  vmovq xmm1, rax
0000781a8ffdd551  vmovq xmm15, r14
0000781a8ffdd556  movaps xmm14, xmm1
0000781a8ffdd55a  addsd xmm14, xmm15
0000781a8ffdd55f  ucomisd xmm14, xmm14
0000781a8ffdd564  jp 0x0000781A8FFDD634
0000781a8ffdd56a  movq xmm14, xmm14
0000781a8ffdd56f  movaps [r15+0x110], xmm14
0000781a8ffdd577  mov eax, [r15+0x108]
0000781a8ffdd57e  sahf
0000781a8ffdd57f  jnz 0x0000781A8FFDD5B1
0000781a8ffdd581  cmp dword ptr [r15+0x318], 0x00
0000781a8ffdd589  jz 0x0000781A8FFDD680
0000781a8ffdd58f  nop [rax+rax*1], ax
0000781a8ffdd598  nop [rax+rax*1], eax
0000781a8ffdd5a0  mov eax, 0x410698
0000781a8ffdd5a5  mov [r15+0x100], rax
0000781a8ffdd5ac  jmp 0x0000781A8FDFE110
0000781a8ffdd5b1  cmp dword ptr [r15+0x318], 0x00
0000781a8ffdd5b9  jz 0x0000781A8FFDD4C0
0000781a8ffdd5bf  nop [rax+rax*1], ax
0000781a8ffdd5c8  nop [rax+rax*1], eax
0000781a8ffdd5d0  mov eax, 0x41067C
0000781a8ffdd5d5  mov [r15+0x100], rax
0000781a8ffdd5dc  jmp 0x0000781A8FDFE110
0000781a8ffdd5e1  int3
0000781a8ffdd5e2  call 0x0000781A8FEB52F0
0000781a8ffdd5e7  jmp 0x0000781A8FFDD4D2
0000781a8ffdd5ec  ucomisd xmm1, xmm14
0000781a8ffdd5f1  jp 0x0000781A8FFDD600
0000781a8ffdd5f3  movaps xmm13, [0x0000781A8FBFE060]
0000781a8ffdd5fb  jmp 0x0000781A8FFDD53D
0000781a8ffdd600  vxorps xmm0, xmm1, xmm14
0000781a8ffdd605  pextrw eax, xmm0, 0x03
0000781a8ffdd60a  and eax, 0x7FF8
0000781a8ffdd60f  cmp eax, 0x08
0000781a8ffdd612  jnz 0x0000781A8FFDD53D
0000781a8ffdd618  movq rax, xmm14
0000781a8ffdd61d  shl rax, 0x0D
0000781a8ffdd621  jbe 0x0000781A8FFDD53D
0000781a8ffdd627  vorps xmm13, xmm14, [0x0000781A8FBFE070]
0000781a8ffdd62f  jmp 0x0000781A8FFDD53D
0000781a8ffdd634  ucomisd xmm1, xmm15
0000781a8ffdd639  jp 0x0000781A8FFDD648
0000781a8ffdd63b  movaps xmm14, [0x0000781A8FBFE060]
0000781a8ffdd643  jmp 0x0000781A8FFDD56A
0000781a8ffdd648  vxorps xmm0, xmm1, xmm15
0000781a8ffdd64d  pextrw eax, xmm0, 0x03
0000781a8ffdd652  and eax, 0x7FF8
0000781a8ffdd657  cmp eax, 0x08
0000781a8ffdd65a  jnz 0x0000781A8FFDD56A
0000781a8ffdd660  movq rax, xmm15
0000781a8ffdd665  shl rax, 0x0D
0000781a8ffdd669  jbe 0x0000781A8FFDD56A
0000781a8ffdd66f  vorps xmm14, xmm15, [0x0000781A8FBFE070]
0000781a8ffdd677  jmp 0x0000781A8FFDD56A
0000781a8ffdd67c  int3
0000781a8ffdd67d  nop [rax], eax
0000781a8ffdd680  mov rax, [r15+0xF8]
0000781a8ffdd687  lea r14, [rax+0x1A0]
0000781a8ffdd68e  mov r12, [r13+r14*1]
0000781a8ffdd693  lea r14, [rax+0x1A8]
0000781a8ffdd69a  mov r11, [r13+r14*1]
0000781a8ffdd69f  mov [r15+0xA0], r12
0000781a8ffdd6a6  mov [r15+0x98], r11
0000781a8ffdd6ad  mov r14, [r15+0x40]
0000781a8ffdd6b1  lea r12, [r14+0xC50]
0000781a8ffdd6b8  movaps xmm1, [r15+0x110]
0000781a8ffdd6c0  movq r14, xmm1
0000781a8ffdd6c5  mov [r13+r12*1], r14
0000781a8ffdd6ca  lea r14, [rax+0x190]
0000781a8ffdd6d1  mov r12, [r13+r14*1]
0000781a8ffdd6d6  lea r14, [rax+0x198]
0000781a8ffdd6dd  mov r11, [r13+r14*1]
0000781a8ffdd6e2  mov [r15+0xE8], r12
0000781a8ffdd6e9  mov [r15+0xF0], r11
0000781a8ffdd6f0  lea r14, [rax+0x180]
0000781a8ffdd6f7  mov r12, [r13+r14*1]
0000781a8ffdd6fc  lea r14, [rax+0x188]
0000781a8ffdd703  mov r10, [r13+r14*1]
0000781a8ffdd708  movq xmm1, r12
0000781a8ffdd70d  movq xmm15, r10
0000781a8ffdd712  movq xmm1, xmm1
0000781a8ffdd716  movq xmm1, xmm1
0000781a8ffdd71a  movaps [r15+0x1A0], xmm1
0000781a8ffdd722  movq xmm15, xmm15
0000781a8ffdd727  movq xmm15, xmm15
0000781a8ffdd72c  movaps [r15+0x190], xmm15
0000781a8ffdd734  lea r14, [rax+0x170]
0000781a8ffdd73b  mov r12, [r13+r14*1]
0000781a8ffdd740  lea r14, [rax+0x178]
0000781a8ffdd747  mov r10, [r13+r14*1]
0000781a8ffdd74c  movq xmm1, r12
0000781a8ffdd751  movq xmm15, r10
0000781a8ffdd756  movq xmm1, xmm1
0000781a8ffdd75a  movq xmm1, xmm1
0000781a8ffdd75e  movaps [r15+0x1C0], xmm1
0000781a8ffdd766  movq xmm15, xmm15
0000781a8ffdd76b  movq xmm15, xmm15
0000781a8ffdd770  movaps [r15+0x1B0], xmm15
0000781a8ffdd778  lea r14, [rax+0x160]
0000781a8ffdd77f  mov r12, [r13+r14*1]
0000781a8ffdd784  lea r14, [rax+0x168]
0000781a8ffdd78b  mov r10, [r13+r14*1]
0000781a8ffdd790  movq xmm1, r12
0000781a8ffdd795  movq xmm15, r10
0000781a8ffdd79a  movq xmm1, xmm1
0000781a8ffdd79e  movq xmm1, xmm1
0000781a8ffdd7a2  movaps [r15+0x1E0], xmm1
0000781a8ffdd7aa  movq xmm15, xmm15
0000781a8ffdd7af  movq xmm15, xmm15
0000781a8ffdd7b4  movaps [r15+0x1D0], xmm15
0000781a8ffdd7bc  lea r14, [rax+0x150]
0000781a8ffdd7c3  mov r12, [r13+r14*1]
0000781a8ffdd7c8  lea r14, [rax+0x158]
0000781a8ffdd7cf  mov r10, [r13+r14*1]
0000781a8ffdd7d4  movq xmm1, r12
0000781a8ffdd7d9  movq xmm15, r10
0000781a8ffdd7de  movq xmm1, xmm1
0000781a8ffdd7e2  movq xmm1, xmm1
0000781a8ffdd7e6  movaps [r15+0x200], xmm1
0000781a8ffdd7ee  movq xmm15, xmm15
0000781a8ffdd7f3  movq xmm15, xmm15
0000781a8ffdd7f8  movaps [r15+0x1F0], xmm15
0000781a8ffdd800  lea r14, [rax+0x1B0]
0000781a8ffdd807  mov [r15+0xF8], r14
0000781a8ffdd80e  mov [r15+0x100], r11
0000781a8ffdd815  jmp 0x0000781A8FFCE5C0
0000781a8ffdd81a  int3
0000781a8ffdd81b  call 0x0000781A8FEE27E0
0000781a8ffdd820  jmp 0x0000781A8FFDD693
0000781a8ffdd825  call 0x0000781A8FEE1570
0000781a8ffdd82a  jmp 0x0000781A8FFDD69F
0000781a8ffdd82f  call 0x0000781A8FEC3FE0
0000781a8ffdd834  jmp 0x0000781A8FFDD6CA
0000781a8ffdd839  call 0x0000781A8FEE27E0
0000781a8ffdd83e  jmp 0x0000781A8FFDD6D6
0000781a8ffdd843  call 0x0000781A8FEE1570
0000781a8ffdd848  jmp 0x0000781A8FFDD6E2
0000781a8ffdd84d  call 0x0000781A8FEE27E0
0000781a8ffdd852  jmp 0x0000781A8FFDD6FC
0000781a8ffdd857  call 0x0000781A8FEE0300
0000781a8ffdd85c  jmp 0x0000781A8FFDD708
0000781a8ffdd861  call 0x0000781A8FEE27E0
0000781a8ffdd866  jmp 0x0000781A8FFDD740
0000781a8ffdd86b  call 0x0000781A8FEE0300
0000781a8ffdd870  jmp 0x0000781A8FFDD74C
0000781a8ffdd875  call 0x0000781A8FEE27E0
0000781a8ffdd87a  jmp 0x0000781A8FFDD784
0000781a8ffdd87f  call 0x0000781A8FEE0300
0000781a8ffdd884  jmp 0x0000781A8FFDD790
0000781a8ffdd889  call 0x0000781A8FEE27E0
0000781a8ffdd88e  jmp 0x0000781A8FFDD7C8
0000781a8ffdd893  call 0x0000781A8FEE0300
0000781a8ffdd898  jmp 0x0000781A8FFDD7D4
0000781a8ffdd89d  int3
0000781a8ffdd89e  nop
0000781a8ffdd8a0  mov qword ptr [r15+0x100], 0x04
0000781a8ffdd8ab  mov esi, 0x00
0000781a8ffdd8b0  mov edx, 0x09
0000781a8ffdd8b5  mov rdi, 0x7FFCC42F5A60
0000781a8ffdd8bf  mov rax, 0x627DDC10C970
0000781a8ffdd8c9  call rax
0000781a8ffdd8cb  cmp dword ptr [r15+0x318], 0x00
0000781a8ffdd8d3  jnz 0x0000781A8FDFE110
0000781a8ffdd8d9  jmp 0x0000781A8FDFE0A0
0000781a8ffdd8de  int3
0000781a8ffdd8df  int3
