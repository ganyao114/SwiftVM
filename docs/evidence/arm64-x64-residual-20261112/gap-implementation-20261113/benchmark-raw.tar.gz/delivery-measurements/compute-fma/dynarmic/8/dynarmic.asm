00007cc2697ce69b  nop [rax+rax*1], eax
00007cc2697ce6a0  mov rax, [r15+0xF8]
00007cc2697ce6a7  lea r14, [rax-0x1B0]
00007cc2697ce6ae  mov [r15+0xF8], r14
00007cc2697ce6b5  lea rax, [r14+0x1A0]
00007cc2697ce6bc  mov r12, [r15+0xA0]
00007cc2697ce6c3  mov r11, [r15+0x98]
00007cc2697ce6ca  mov [r13+rax*1], r12
00007cc2697ce6cf  lea rax, [r14+0x1A8]
00007cc2697ce6d6  mov [r13+rax*1], r11
00007cc2697ce6db  mov eax, 0x420A30
00007cc2697ce6e0  movups xmm1, [r13+rax*1]
00007cc2697ce6e6  mov eax, 0x4209C0
00007cc2697ce6eb  movups xmm15, [r13+rax*1]
00007cc2697ce6f1  mov eax, 0x420A50
00007cc2697ce6f6  movups xmm14, [r13+rax*1]
00007cc2697ce6fc  mov eax, 0x4209F0
00007cc2697ce701  movups xmm13, [r13+rax*1]
00007cc2697ce707  mov qword ptr [r15+0x98], 0x430C60
00007cc2697ce712  mov eax, 0x420A60
00007cc2697ce717  movups xmm12, [r13+rax*1]
00007cc2697ce71d  mov eax, 0x430C60
00007cc2697ce722  movups [r13+rax*1], xmm1
00007cc2697ce728  mov eax, 0x430C70
00007cc2697ce72d  movups [r13+rax*1], xmm15
00007cc2697ce733  mov eax, 0x430C80
00007cc2697ce738  movups [r13+rax*1], xmm14
00007cc2697ce73e  mov eax, 0x430C90
00007cc2697ce743  movups [r13+rax*1], xmm13
00007cc2697ce749  mov eax, 0x4209B0
00007cc2697ce74e  movups xmm14, [r13+rax*1]
00007cc2697ce754  mov eax, 0x4209A0
00007cc2697ce759  movups xmm13, [r13+rax*1]
00007cc2697ce75f  mov eax, 0x430D60
00007cc2697ce764  movups [r13+rax*1], xmm1
00007cc2697ce76a  mov eax, 0x430D70
00007cc2697ce76f  movups [r13+rax*1], xmm15
00007cc2697ce775  mov eax, 0x430CA0
00007cc2697ce77a  movups [r13+rax*1], xmm12
00007cc2697ce780  mov eax, 0x430CB0
00007cc2697ce785  movups [r13+rax*1], xmm14
00007cc2697ce78b  mov eax, 0x420990
00007cc2697ce790  movups xmm1, [r13+rax*1]
00007cc2697ce796  mov eax, 0x420A00
00007cc2697ce79b  movups xmm15, [r13+rax*1]
00007cc2697ce7a1  mov eax, 0x430CC0
00007cc2697ce7a6  movups [r13+rax*1], xmm13
00007cc2697ce7ac  mov eax, 0x430CD0
00007cc2697ce7b1  movups [r13+rax*1], xmm1
00007cc2697ce7b7  mov eax, 0x420A10
00007cc2697ce7bc  movups xmm1, [r13+rax*1]
00007cc2697ce7c2  mov eax, 0x4209E0
00007cc2697ce7c7  movups xmm14, [r13+rax*1]
00007cc2697ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007cc2697ce7d5  mov eax, 0x430CE0
00007cc2697ce7da  movups [r13+rax*1], xmm15
00007cc2697ce7e0  mov eax, 0x430CF0
00007cc2697ce7e5  movups [r13+rax*1], xmm1
00007cc2697ce7eb  mov eax, 0x420A80
00007cc2697ce7f0  movups xmm1, [r13+rax*1]
00007cc2697ce7f6  mov eax, 0x420A90
00007cc2697ce7fb  movups xmm15, [r13+rax*1]
00007cc2697ce801  movaps [r15+0x150], xmm15
00007cc2697ce809  mov qword ptr [r15+0xA0], 0x3E8
00007cc2697ce814  mov eax, 0x430D00
00007cc2697ce819  movups [r13+rax*1], xmm14
00007cc2697ce81f  mov eax, 0x430D10
00007cc2697ce824  movups [r13+rax*1], xmm1
00007cc2697ce82a  mov eax, 0x420A70
00007cc2697ce82f  movups xmm1, [r13+rax*1]
00007cc2697ce835  mov eax, 0x420A20
00007cc2697ce83a  movups xmm14, [r13+rax*1]
00007cc2697ce840  movaps [r15+0x140], xmm14
00007cc2697ce848  lea rax, [r14+0x150]
00007cc2697ce84f  movq xmm13, qword ptr [r15+0x200]
00007cc2697ce858  movq xmm12, qword ptr [r15+0x1F0]
00007cc2697ce861  movq r12, xmm13
00007cc2697ce866  movq r11, xmm12
00007cc2697ce86b  mov [r13+rax*1], r12
00007cc2697ce870  lea rax, [r14+0x158]
00007cc2697ce877  mov [r13+rax*1], r11
00007cc2697ce87c  mov eax, 0x430D20
00007cc2697ce881  movups [r13+rax*1], xmm15
00007cc2697ce887  mov eax, 0x430D30
00007cc2697ce88c  movups [r13+rax*1], xmm1
00007cc2697ce892  mov eax, 0x420A40
00007cc2697ce897  movups xmm1, [r13+rax*1]
00007cc2697ce89d  mov eax, 0x420AA8
00007cc2697ce8a2  mov r12, [r13+rax*1]
00007cc2697ce8a7  movq xmm15, r12
00007cc2697ce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007cc2697ce8b4  mov eax, 0x430D40
00007cc2697ce8b9  movups [r13+rax*1], xmm14
00007cc2697ce8bf  mov eax, 0x430D50
00007cc2697ce8c4  movups [r13+rax*1], xmm1
00007cc2697ce8ca  mov eax, 0x420B10
00007cc2697ce8cf  movups xmm1, [r13+rax*1]
00007cc2697ce8d5  movq rax, xmm15
00007cc2697ce8da  mov r12d, 0x430D80
00007cc2697ce8e0  mov [r13+r12*1], rax
00007cc2697ce8e5  mov eax, 0x420AF0
00007cc2697ce8ea  movups xmm15, [r13+rax*1]
00007cc2697ce8f0  mov eax, 0x420B00
00007cc2697ce8f5  movups xmm14, [r13+rax*1]
00007cc2697ce8fb  lea rax, [r14+0x130]
00007cc2697ce902  movups [r13+rax*1], xmm1
00007cc2697ce908  lea rax, [r14+0x160]
00007cc2697ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007cc2697ce918  movq xmm13, qword ptr [r15+0x1D0]
00007cc2697ce921  movq r12, xmm1
00007cc2697ce926  movq r11, xmm13
00007cc2697ce92b  mov [r13+rax*1], r12
00007cc2697ce930  lea rax, [r14+0x168]
00007cc2697ce937  mov [r13+rax*1], r11
00007cc2697ce93c  lea rax, [r14+0x110]
00007cc2697ce943  movups [r13+rax*1], xmm15
00007cc2697ce949  lea rax, [r14+0x120]
00007cc2697ce950  movups [r13+rax*1], xmm14
00007cc2697ce956  mov eax, 0x420AB0
00007cc2697ce95b  movups xmm1, [r13+rax*1]
00007cc2697ce961  mov eax, 0x420AC0
00007cc2697ce966  movups xmm15, [r13+rax*1]
00007cc2697ce96c  movaps [r15+0x120], xmm15
00007cc2697ce974  lea rax, [r14+0x170]
00007cc2697ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007cc2697ce984  movq xmm13, qword ptr [r15+0x1B0]
00007cc2697ce98d  movq r12, xmm14
00007cc2697ce992  movq r11, xmm13
00007cc2697ce997  mov [r13+rax*1], r12
00007cc2697ce99c  lea rax, [r14+0x178]
00007cc2697ce9a3  mov [r13+rax*1], r11
00007cc2697ce9a8  lea rax, [r14+0x180]
00007cc2697ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007cc2697ce9b8  movq xmm13, qword ptr [r15+0x190]
00007cc2697ce9c1  movq r12, xmm14
00007cc2697ce9c6  movq r11, xmm13
00007cc2697ce9cb  mov [r13+rax*1], r12
00007cc2697ce9d0  lea rax, [r14+0x188]
00007cc2697ce9d7  mov [r13+rax*1], r11
00007cc2697ce9dc  lea rax, [r14+0xD0]
00007cc2697ce9e3  movups [r13+rax*1], xmm1
00007cc2697ce9e9  lea rax, [r14+0xE0]
00007cc2697ce9f0  movups [r13+rax*1], xmm15
00007cc2697ce9f6  mov eax, 0x420AD0
00007cc2697ce9fb  movups xmm1, [r13+rax*1]
00007cc2697cea01  mov eax, 0x420AE0
00007cc2697cea06  movups xmm15, [r13+rax*1]
00007cc2697cea0c  movaps [r15+0x110], xmm1
00007cc2697cea14  movaps [r15+0x130], xmm15
00007cc2697cea1c  lea rax, [r14+0x190]
00007cc2697cea23  mov r12, [r15+0xE8]
00007cc2697cea2a  mov r11, [r15+0xF0]
00007cc2697cea31  mov [r13+rax*1], r12
00007cc2697cea36  lea rax, [r14+0x198]
00007cc2697cea3d  mov [r13+rax*1], r11
00007cc2697cea42  mov eax, 0x430D88
00007cc2697cea47  mov r12d, 0x421DF8D3
00007cc2697cea4d  mov [r13+rax*1], r12d
00007cc2697cea52  lea rax, [r14+0xF0]
00007cc2697cea59  movups [r13+rax*1], xmm1
00007cc2697cea5f  lea rax, [r14+0x100]
00007cc2697cea66  movups [r13+rax*1], xmm15
00007cc2697cea6c  lea rax, [r14+0xD0]
00007cc2697cea73  mov [r15], rax
00007cc2697cea76  mov qword ptr [r15+0x08], 0x430C60
00007cc2697cea7e  mov qword ptr [r15+0x10], 0x12C
00007cc2697cea86  mov qword ptr [r15+0xF0], 0x410284
00007cc2697cea91  mov r14d, [r15+0x320]
00007cc2697cea98  mov eax, 0x410284
00007cc2697cea9d  mov rcx, 0x7CC2697D07C0
00007cc2697ceaa7  mov [r15+r14*8+0x328], rax
00007cc2697ceaaf  mov [r15+r14*8+0x368], rcx
00007cc2697ceab7  add r14d, 0x01
00007cc2697ceabb  and r14d, 0x07
00007cc2697ceabf  mov [r15+0x320], r14d
00007cc2697ceac6  cmp dword ptr [r15+0x318], 0x00
00007cc2697ceace  jz 0x00007CC2697CED70
00007cc2697cead4  nop [rax+rax*1], ax
00007cc2697ceadd  nop [rax+rax*1], eax
00007cc2697ceae5  mov eax, 0x4106BC
00007cc2697ceaea  mov [r15+0x100], rax
00007cc2697ceaf1  jmp 0x00007CC2695FE110
00007cc2697ceaf6  int3
00007cc2697ceaf7  call 0x00007CC26960BC20
00007cc2697ceafc  jmp 0x00007CC2697CE6CF
00007cc2697ceb01  call 0x00007CC26960A9A0
00007cc2697ceb06  jmp 0x00007CC2697CE6DB
00007cc2697ceb0b  call 0x00007CC2695FF430
00007cc2697ceb10  jmp 0x00007CC2697CE6E6
00007cc2697ceb15  call 0x00007CC26960E760
00007cc2697ceb1a  jmp 0x00007CC2697CE6F1
00007cc2697ceb1f  call 0x00007CC26960D4E0
00007cc2697ceb24  jmp 0x00007CC2697CE6FC
00007cc2697ceb29  call 0x00007CC26960C260
00007cc2697ceb2e  jmp 0x00007CC2697CE707
00007cc2697ceb33  call 0x00007CC26960AFE0
00007cc2697ceb38  jmp 0x00007CC2697CE71D
00007cc2697ceb3d  call 0x00007CC2695FF540
00007cc2697ceb42  jmp 0x00007CC2697CE728
00007cc2697ceb47  call 0x00007CC26960E880
00007cc2697ceb4c  jmp 0x00007CC2697CE733
00007cc2697ceb51  call 0x00007CC26960D600
00007cc2697ceb56  jmp 0x00007CC2697CE73E
00007cc2697ceb5b  call 0x00007CC26960C380
00007cc2697ceb60  jmp 0x00007CC2697CE749
00007cc2697ceb65  call 0x00007CC26960D4E0
00007cc2697ceb6a  jmp 0x00007CC2697CE754
00007cc2697ceb6f  call 0x00007CC26960C260
00007cc2697ceb74  jmp 0x00007CC2697CE75F
00007cc2697ceb79  call 0x00007CC2695FF540
00007cc2697ceb7e  jmp 0x00007CC2697CE76A
00007cc2697ceb83  call 0x00007CC26960E880
00007cc2697ceb88  jmp 0x00007CC2697CE775
00007cc2697ceb8d  call 0x00007CC26960B100
00007cc2697ceb92  jmp 0x00007CC2697CE780
00007cc2697ceb97  call 0x00007CC26960D600
00007cc2697ceb9c  jmp 0x00007CC2697CE78B
00007cc2697ceba1  call 0x00007CC2695FF430
00007cc2697ceba6  jmp 0x00007CC2697CE796
00007cc2697cebab  call 0x00007CC26960E760
00007cc2697cebb0  jmp 0x00007CC2697CE7A1
00007cc2697cebb5  call 0x00007CC26960C380
00007cc2697cebba  jmp 0x00007CC2697CE7AC
00007cc2697cebbf  call 0x00007CC2695FF540
00007cc2697cebc4  jmp 0x00007CC2697CE7B7
00007cc2697cebc9  call 0x00007CC2695FF430
00007cc2697cebce  jmp 0x00007CC2697CE7C2
00007cc2697cebd3  call 0x00007CC26960D4E0
00007cc2697cebd8  jmp 0x00007CC2697CE7CD
00007cc2697cebdd  call 0x00007CC26960E880
00007cc2697cebe2  jmp 0x00007CC2697CE7E0
00007cc2697cebe7  call 0x00007CC2695FF540
00007cc2697cebec  jmp 0x00007CC2697CE7EB
00007cc2697cebf1  call 0x00007CC2695FF430
00007cc2697cebf6  jmp 0x00007CC2697CE7F6
00007cc2697cebfb  call 0x00007CC26960E760
00007cc2697cec00  jmp 0x00007CC2697CE801
00007cc2697cec05  call 0x00007CC26960D600
00007cc2697cec0a  jmp 0x00007CC2697CE81F
00007cc2697cec0f  call 0x00007CC2695FF540
00007cc2697cec14  jmp 0x00007CC2697CE82A
00007cc2697cec19  call 0x00007CC2695FF430
00007cc2697cec1e  jmp 0x00007CC2697CE835
00007cc2697cec23  call 0x00007CC26960D4E0
00007cc2697cec28  jmp 0x00007CC2697CE840
00007cc2697cec2d  call 0x00007CC26960BC20
00007cc2697cec32  jmp 0x00007CC2697CE870
00007cc2697cec37  call 0x00007CC26960A9A0
00007cc2697cec3c  jmp 0x00007CC2697CE87C
00007cc2697cec41  call 0x00007CC26960E880
00007cc2697cec46  jmp 0x00007CC2697CE887
00007cc2697cec4b  call 0x00007CC2695FF540
00007cc2697cec50  jmp 0x00007CC2697CE892
00007cc2697cec55  call 0x00007CC2695FF430
00007cc2697cec5a  jmp 0x00007CC2697CE89D
00007cc2697cec5f  call 0x00007CC26960B720
00007cc2697cec64  jmp 0x00007CC2697CE8A7
00007cc2697cec69  call 0x00007CC26960D600
00007cc2697cec6e  jmp 0x00007CC2697CE8BF
00007cc2697cec73  call 0x00007CC2695FF540
00007cc2697cec78  jmp 0x00007CC2697CE8CA
00007cc2697cec7d  call 0x00007CC2695FF430
00007cc2697cec82  jmp 0x00007CC2697CE8D5
00007cc2697cec87  call 0x00007CC2696B4CB0
00007cc2697cec8c  jmp 0x00007CC2697CE8E5
00007cc2697cec91  call 0x00007CC26960E760
00007cc2697cec96  jmp 0x00007CC2697CE8F0
00007cc2697cec9b  call 0x00007CC26960D4E0
00007cc2697ceca0  jmp 0x00007CC2697CE8FB
00007cc2697ceca5  call 0x00007CC2695FF540
00007cc2697cecaa  jmp 0x00007CC2697CE908
00007cc2697cecaf  call 0x00007CC26960BC20
00007cc2697cecb4  jmp 0x00007CC2697CE930
00007cc2697cecb9  call 0x00007CC26960A9A0
00007cc2697cecbe  jmp 0x00007CC2697CE93C
00007cc2697cecc3  call 0x00007CC26960E880
00007cc2697cecc8  jmp 0x00007CC2697CE949
00007cc2697ceccd  call 0x00007CC26960D600
00007cc2697cecd2  jmp 0x00007CC2697CE956
00007cc2697cecd7  call 0x00007CC2695FF430
00007cc2697cecdc  jmp 0x00007CC2697CE961
00007cc2697cece1  call 0x00007CC26960E760
00007cc2697cece6  jmp 0x00007CC2697CE96C
00007cc2697ceceb  call 0x00007CC26960BC20
00007cc2697cecf0  jmp 0x00007CC2697CE99C
00007cc2697cecf5  call 0x00007CC26960A9A0
00007cc2697cecfa  jmp 0x00007CC2697CE9A8
00007cc2697cecff  call 0x00007CC26960BC20
00007cc2697ced04  jmp 0x00007CC2697CE9D0
00007cc2697ced09  call 0x00007CC26960A9A0
00007cc2697ced0e  jmp 0x00007CC2697CE9DC
00007cc2697ced13  call 0x00007CC2695FF540
00007cc2697ced18  jmp 0x00007CC2697CE9E9
00007cc2697ced1d  call 0x00007CC26960E880
00007cc2697ced22  jmp 0x00007CC2697CE9F6
00007cc2697ced27  call 0x00007CC2695FF430
00007cc2697ced2c  jmp 0x00007CC2697CEA01
00007cc2697ced31  call 0x00007CC26960E760
00007cc2697ced36  jmp 0x00007CC2697CEA0C
00007cc2697ced3b  call 0x00007CC26960BC20
00007cc2697ced40  jmp 0x00007CC2697CEA36
00007cc2697ced45  call 0x00007CC26960A9A0
00007cc2697ced4a  jmp 0x00007CC2697CEA42
00007cc2697ced4f  call 0x00007CC26960BAE0
00007cc2697ced54  jmp 0x00007CC2697CEA52
00007cc2697ced59  call 0x00007CC2695FF540
00007cc2697ced5e  jmp 0x00007CC2697CEA5F
00007cc2697ced63  call 0x00007CC26960E880
00007cc2697ced68  jmp 0x00007CC2697CEA6C
00007cc2697ced6d  int3
00007cc2697ced6e  nop
00007cc2697ced70  mov rax, [r15]
00007cc2697ced73  lea r14, [rax+0x20]
00007cc2697ced77  mov r12, [r13+r14*1]
00007cc2697ced7c  mov r14, [r15+0x10]
00007cc2697ced80  lea r11, [r12+r14*1]
00007cc2697ced84  mov [r15+0x40], r11
00007cc2697ced88  lea r12, [rax+0x20]
00007cc2697ced8c  mov [r13+r12*1], r11
00007cc2697ced91  test r14, r14
00007cc2697ced94  setz r14b
00007cc2697ced98  movzx r14, r14b
00007cc2697ced9c  mov [rsp+0x414], r14b
00007cc2697ceda4  cmp byte ptr [rsp+0x414], 0x00
00007cc2697cedac  jz 0x00007CC2697CEDDE
00007cc2697cedae  cmp dword ptr [r15+0x318], 0x00
00007cc2697cedb6  mov eax, 0x410934
00007cc2697cedbb  mov [r15+0x100], rax
00007cc2697cedc2  jz 0x00007CC2695FE0A0
00007cc2697cedc8  nop [rax+rax*1], eax
00007cc2697cedcd  mov eax, 0x410934
00007cc2697cedd2  mov [r15+0x100], rax
00007cc2697cedd9  jmp 0x00007CC2695FE110
00007cc2697cedde  cmp dword ptr [r15+0x318], 0x00
00007cc2697cede6  jz 0x00007CC2697CEE30
00007cc2697cedec  nop [rax+rax*1], ax
00007cc2697cedf5  nop [rax+rax*1], eax
00007cc2697cedfd  mov eax, 0x4106CC
00007cc2697cee02  mov [r15+0x100], rax
00007cc2697cee09  jmp 0x00007CC2695FE110
00007cc2697cee0e  int3
00007cc2697cee0f  call 0x00007CC2696E27E0
00007cc2697cee14  jmp 0x00007CC2697CED7C
00007cc2697cee19  call 0x00007CC2696C0860
00007cc2697cee1e  jmp 0x00007CC2697CED91
00007cc2697cee23  int3
00007cc2697cee24  nop [rax+rax*1], ax
00007cc2697cee2d  nop [rax], eax
00007cc2697cee30  mov rax, [r15+0xF8]
00007cc2697cee37  lea r14, [rax-0x150]
00007cc2697cee3e  mov [r15+0xF8], r14
00007cc2697cee45  mov rax, [r15]
00007cc2697cee48  lea r12, [rax+0x68]
00007cc2697cee4c  mov r11, [r13+r12*1]
00007cc2697cee51  mov [r15+0x88], r11
00007cc2697cee58  lea r12, [rax+0x28]
00007cc2697cee5c  mov [r15+0x40], r12
00007cc2697cee60  mov [r15+0x48], r14
00007cc2697cee64  mov qword ptr [r15+0x50], 0x420B20
00007cc2697cee6c  lea rax, [r14+0x100]
00007cc2697cee73  mov r12, [r15+0xE8]
00007cc2697cee7a  mov r11, [r15+0xD8]
00007cc2697cee81  mov [r13+rax*1], r12
00007cc2697cee86  lea rax, [r14+0x108]
00007cc2697cee8d  mov [r13+rax*1], r11
00007cc2697cee92  lea rax, [r14+0x110]
00007cc2697cee99  mov r12, [r15+0xD0]
00007cc2697ceea0  mov r11, [r15+0xC8]
00007cc2697ceea7  mov [r13+rax*1], r12
00007cc2697ceeac  lea rax, [r14+0x118]
00007cc2697ceeb3  mov [r13+rax*1], r11
00007cc2697ceeb8  lea rax, [r14+0x120]
00007cc2697ceebf  mov r12, [r15+0xC0]
00007cc2697ceec6  mov r11, [r15+0xB8]
00007cc2697ceecd  mov [r13+rax*1], r12
00007cc2697ceed2  lea rax, [r14+0x128]
00007cc2697ceed9  mov [r13+rax*1], r11
00007cc2697ceede  lea rax, [r14+0x130]
00007cc2697ceee5  mov r12, [r15+0xB0]
00007cc2697ceeec  mov r11, [r15+0xA8]
00007cc2697ceef3  mov [r13+rax*1], r12
00007cc2697ceef8  lea rax, [r14+0x138]
00007cc2697ceeff  mov [r13+rax*1], r11
00007cc2697cef04  lea rax, [r14+0x140]
00007cc2697cef0b  mov r12, [r15+0xA0]
00007cc2697cef12  mov r11, [r15+0x98]
00007cc2697cef19  mov [r13+rax*1], r12
00007cc2697cef1e  lea rax, [r14+0x148]
00007cc2697cef25  mov [r13+rax*1], r11
00007cc2697cef2a  cmp dword ptr [r15+0x318], 0x00
00007cc2697cef32  jz 0x00007CC2697CEFD0
00007cc2697cef38  nop [rax+rax*1], ax
00007cc2697cef41  nop [rax+rax*1], eax
00007cc2697cef49  mov eax, 0x410704
00007cc2697cef4e  mov [r15+0x100], rax
00007cc2697cef55  jmp 0x00007CC2695FE110
00007cc2697cef5a  int3
00007cc2697cef5b  call 0x00007CC2696C0370
00007cc2697cef60  jmp 0x00007CC2697CEE51
00007cc2697cef65  call 0x00007CC26960BC20
00007cc2697cef6a  jmp 0x00007CC2697CEE86
00007cc2697cef6f  call 0x00007CC26960A9A0
00007cc2697cef74  jmp 0x00007CC2697CEE92
00007cc2697cef79  call 0x00007CC26960BC20
00007cc2697cef7e  jmp 0x00007CC2697CEEAC
00007cc2697cef83  call 0x00007CC26960A9A0
00007cc2697cef88  jmp 0x00007CC2697CEEB8
00007cc2697cef8d  call 0x00007CC26960BC20
00007cc2697cef92  jmp 0x00007CC2697CEED2
00007cc2697cef97  call 0x00007CC26960A9A0
00007cc2697cef9c  jmp 0x00007CC2697CEEDE
00007cc2697cefa1  call 0x00007CC26960BC20
00007cc2697cefa6  jmp 0x00007CC2697CEEF8
00007cc2697cefab  call 0x00007CC26960A9A0
00007cc2697cefb0  jmp 0x00007CC2697CEF04
00007cc2697cefb5  call 0x00007CC26960BC20
00007cc2697cefba  jmp 0x00007CC2697CEF1E
00007cc2697cefbf  call 0x00007CC26960A9A0
00007cc2697cefc4  jmp 0x00007CC2697CEF2A
00007cc2697cefc9  int3
00007cc2697cefca  nop [rax+rax*1], ax
00007cc2697cefd0  mov rax, [r15+0x08]
00007cc2697cefd4  movzx r14d, byte ptr [r13+rax*1]
00007cc2697cefda  movzx r14d, r14b
00007cc2697cefde  mov [rsp+0x10], r14d
00007cc2697cefe3  mov r14d, r14d
00007cc2697cefe6  mov [r15+0x58], r14
00007cc2697cefea  lea r14, [rax+0x01]
00007cc2697cefee  mov [r15+0x08], r14
00007cc2697ceff2  mov rax, [r15+0x88]
00007cc2697ceff9  lea r14, [rax+0x01]
00007cc2697ceffd  mov r12, [r15]
00007cc2697cf000  lea r11, [r12+0x68]
00007cc2697cf005  mov [r13+r11*1], r14
00007cc2697cf00a  lea r14, [r12+rax*1]
00007cc2697cf00e  mov [r15+0x60], r14
00007cc2697cf012  lea rax, [r14+0x28]
00007cc2697cf016  mov r11d, [rsp+0x10]
00007cc2697cf01b  movzx r14d, r11b
00007cc2697cf01f  mov [r13+rax*1], r14b
00007cc2697cf024  lea rax, [r12+0x68]
00007cc2697cf029  mov r14, [r13+rax*1]
00007cc2697cf02e  mov [r15+0x88], r14
00007cc2697cf035  xor eax, eax
00007cc2697cf037  mov r12d, 0x40
00007cc2697cf03d  cmp r14, r12
00007cc2697cf040  cmc
00007cc2697cf041  lahf
00007cc2697cf042  seto al
00007cc2697cf045  mov [r15+0x108], eax
00007cc2697cf04c  mov eax, [r15+0x108]
00007cc2697cf053  sahf
00007cc2697cf054  jnz 0x00007CC2697CF086
00007cc2697cf056  cmp dword ptr [r15+0x318], 0x00
00007cc2697cf05e  jz 0x00007CC2697CF170
00007cc2697cf064  nop [rax+rax*1], ax
00007cc2697cf06d  nop [rax+rax*1], eax
00007cc2697cf075  mov eax, 0x410724
00007cc2697cf07a  mov [r15+0x100], rax
00007cc2697cf081  jmp 0x00007CC2695FE110
00007cc2697cf086  cmp dword ptr [r15+0x318], 0x00
00007cc2697cf08e  jz 0x00007CC2697CF0E0
00007cc2697cf094  nop [rax+rax*1], ax
00007cc2697cf09d  nop [rax+rax*1], eax
00007cc2697cf0a5  mov eax, 0x4106FC
00007cc2697cf0aa  mov [r15+0x100], rax
00007cc2697cf0b1  jmp 0x00007CC2695FE110
00007cc2697cf0b6  int3
00007cc2697cf0b7  call 0x00007CC26960D860
00007cc2697cf0bc  jmp 0x00007CC2697CEFDA
00007cc2697cf0c1  call 0x00007CC2696B36E0
00007cc2697cf0c6  jmp 0x00007CC2697CF00A
00007cc2697cf0cb  call 0x00007CC26960DD60
00007cc2697cf0d0  jmp 0x00007CC2697CF024
00007cc2697cf0d5  call 0x00007CC26960DC20
00007cc2697cf0da  jmp 0x00007CC2697CF02E
00007cc2697cf0df  int3
00007cc2697cf0e0  mov rax, [r15+0x10]
00007cc2697cf0e4  lea r14, [rax-0x01]
00007cc2697cf0e8  mov [r15+0x10], r14
00007cc2697cf0ec  test r14, r14
00007cc2697cf0ef  setz r14b
00007cc2697cf0f3  movzx r14, r14b
00007cc2697cf0f7  mov [rsp+0x414], r14b
00007cc2697cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007cc2697cf107  jz 0x00007CC2697CF139
00007cc2697cf109  cmp dword ptr [r15+0x318], 0x00
00007cc2697cf111  jz 0x00007CC2697D0670
00007cc2697cf117  nop [rax+rax*1], ax
00007cc2697cf120  nop [rax+rax*1], eax
00007cc2697cf128  mov eax, 0x41091C
00007cc2697cf12d  mov [r15+0x100], rax
00007cc2697cf134  jmp 0x00007CC2695FE110
00007cc2697cf139  cmp dword ptr [r15+0x318], 0x00
00007cc2697cf141  jz 0x00007CC2697CEFD0
00007cc2697cf147  nop [rax+rax*1], ax
00007cc2697cf150  nop [rax+rax*1], eax
00007cc2697cf158  mov eax, 0x410704
00007cc2697cf15d  mov [r15+0x100], rax
00007cc2697cf164  jmp 0x00007CC2695FE110
00007cc2697cf169  int3
00007cc2697cf16a  int3
00007cc2697cf16b  nop [rax+rax*1], eax
00007cc2697cf170  mov rax, [r15+0x40]
00007cc2697cf174  movzx r14d, byte ptr [r13+rax*1]
00007cc2697cf17a  movaps xmm1, [r15+0x110]
00007cc2697cf182  pinsrb xmm1, r14d, 0x00
00007cc2697cf189  lea r14, [rax+0x01]
00007cc2697cf18d  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf193  movaps xmm15, [r15+0x120]
00007cc2697cf19b  pinsrb xmm15, r12d, 0x00
00007cc2697cf1a2  lea r14, [rax+0x02]
00007cc2697cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf1ac  movaps xmm14, [r15+0x130]
00007cc2697cf1b4  pinsrb xmm14, r12d, 0x00
00007cc2697cf1bb  lea r14, [rax+0x03]
00007cc2697cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf1c5  movaps xmm13, [r15+0x140]
00007cc2697cf1cd  pinsrb xmm13, r12d, 0x00
00007cc2697cf1d4  lea r14, [rax+0x04]
00007cc2697cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf1de  pinsrb xmm1, r12d, 0x01
00007cc2697cf1e5  lea r14, [rax+0x05]
00007cc2697cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf1ef  pinsrb xmm15, r12d, 0x01
00007cc2697cf1f6  lea r14, [rax+0x06]
00007cc2697cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf200  pinsrb xmm14, r12d, 0x01
00007cc2697cf207  lea r14, [rax+0x07]
00007cc2697cf20b  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf211  pinsrb xmm13, r12d, 0x01
00007cc2697cf218  lea r14, [rax+0x08]
00007cc2697cf21c  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf222  pinsrb xmm1, r12d, 0x02
00007cc2697cf229  lea r14, [rax+0x09]
00007cc2697cf22d  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf233  pinsrb xmm15, r12d, 0x02
00007cc2697cf23a  lea r14, [rax+0x0A]
00007cc2697cf23e  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf244  pinsrb xmm14, r12d, 0x02
00007cc2697cf24b  lea r14, [rax+0x0B]
00007cc2697cf24f  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf255  pinsrb xmm13, r12d, 0x02
00007cc2697cf25c  lea r14, [rax+0x0C]
00007cc2697cf260  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf266  pinsrb xmm1, r12d, 0x03
00007cc2697cf26d  lea r14, [rax+0x0D]
00007cc2697cf271  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf277  pinsrb xmm15, r12d, 0x03
00007cc2697cf27e  lea r14, [rax+0x0E]
00007cc2697cf282  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf288  pinsrb xmm14, r12d, 0x03
00007cc2697cf28f  lea r14, [rax+0x0F]
00007cc2697cf293  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf299  pinsrb xmm13, r12d, 0x03
00007cc2697cf2a0  lea r14, [rax+0x10]
00007cc2697cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf2aa  pinsrb xmm1, r12d, 0x04
00007cc2697cf2b1  lea r14, [rax+0x11]
00007cc2697cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf2bb  pinsrb xmm15, r12d, 0x04
00007cc2697cf2c2  lea r14, [rax+0x12]
00007cc2697cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf2cc  pinsrb xmm14, r12d, 0x04
00007cc2697cf2d3  lea r14, [rax+0x13]
00007cc2697cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf2dd  pinsrb xmm13, r12d, 0x04
00007cc2697cf2e4  lea r14, [rax+0x14]
00007cc2697cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf2ee  pinsrb xmm1, r12d, 0x05
00007cc2697cf2f5  lea r14, [rax+0x15]
00007cc2697cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf2ff  pinsrb xmm15, r12d, 0x05
00007cc2697cf306  lea r14, [rax+0x16]
00007cc2697cf30a  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf310  pinsrb xmm14, r12d, 0x05
00007cc2697cf317  lea r14, [rax+0x17]
00007cc2697cf31b  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf321  pinsrb xmm13, r12d, 0x05
00007cc2697cf328  lea r14, [rax+0x18]
00007cc2697cf32c  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf332  pinsrb xmm1, r12d, 0x06
00007cc2697cf339  lea r14, [rax+0x19]
00007cc2697cf33d  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf343  pinsrb xmm15, r12d, 0x06
00007cc2697cf34a  lea r14, [rax+0x1A]
00007cc2697cf34e  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf354  pinsrb xmm14, r12d, 0x06
00007cc2697cf35b  lea r14, [rax+0x1B]
00007cc2697cf35f  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf365  pinsrb xmm13, r12d, 0x06
00007cc2697cf36c  lea r14, [rax+0x1C]
00007cc2697cf370  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf376  pinsrb xmm1, r12d, 0x07
00007cc2697cf37d  lea r14, [rax+0x1D]
00007cc2697cf381  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf387  pinsrb xmm15, r12d, 0x07
00007cc2697cf38e  lea r14, [rax+0x1E]
00007cc2697cf392  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf398  pinsrb xmm14, r12d, 0x07
00007cc2697cf39f  lea r14, [rax+0x1F]
00007cc2697cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf3a9  pinsrb xmm13, r12d, 0x07
00007cc2697cf3b0  lea r14, [rax+0x20]
00007cc2697cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf3ba  pinsrb xmm1, r12d, 0x08
00007cc2697cf3c1  lea r14, [rax+0x21]
00007cc2697cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf3cb  pinsrb xmm15, r12d, 0x08
00007cc2697cf3d2  lea r14, [rax+0x22]
00007cc2697cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf3dc  pinsrb xmm14, r12d, 0x08
00007cc2697cf3e3  lea r14, [rax+0x23]
00007cc2697cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf3ed  pinsrb xmm13, r12d, 0x08
00007cc2697cf3f4  lea r14, [rax+0x24]
00007cc2697cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf3fe  pinsrb xmm1, r12d, 0x09
00007cc2697cf405  lea r14, [rax+0x25]
00007cc2697cf409  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf40f  pinsrb xmm15, r12d, 0x09
00007cc2697cf416  lea r14, [rax+0x26]
00007cc2697cf41a  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf420  pinsrb xmm14, r12d, 0x09
00007cc2697cf427  lea r14, [rax+0x27]
00007cc2697cf42b  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf431  pinsrb xmm13, r12d, 0x09
00007cc2697cf438  lea r14, [rax+0x28]
00007cc2697cf43c  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf442  pinsrb xmm1, r12d, 0x0A
00007cc2697cf449  lea r14, [rax+0x29]
00007cc2697cf44d  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf453  pinsrb xmm15, r12d, 0x0A
00007cc2697cf45a  lea r14, [rax+0x2A]
00007cc2697cf45e  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf464  pinsrb xmm14, r12d, 0x0A
00007cc2697cf46b  lea r14, [rax+0x2B]
00007cc2697cf46f  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf475  pinsrb xmm13, r12d, 0x0A
00007cc2697cf47c  lea r14, [rax+0x2C]
00007cc2697cf480  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf486  pinsrb xmm1, r12d, 0x0B
00007cc2697cf48d  lea r14, [rax+0x2D]
00007cc2697cf491  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf497  pinsrb xmm15, r12d, 0x0B
00007cc2697cf49e  lea r14, [rax+0x2E]
00007cc2697cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf4a8  pinsrb xmm14, r12d, 0x0B
00007cc2697cf4af  lea r14, [rax+0x2F]
00007cc2697cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf4b9  pinsrb xmm13, r12d, 0x0B
00007cc2697cf4c0  lea r14, [rax+0x30]
00007cc2697cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf4ca  pinsrb xmm1, r12d, 0x0C
00007cc2697cf4d1  lea r14, [rax+0x31]
00007cc2697cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf4db  pinsrb xmm15, r12d, 0x0C
00007cc2697cf4e2  lea r14, [rax+0x32]
00007cc2697cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf4ec  pinsrb xmm14, r12d, 0x0C
00007cc2697cf4f3  lea r14, [rax+0x33]
00007cc2697cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf4fd  pinsrb xmm13, r12d, 0x0C
00007cc2697cf504  lea r14, [rax+0x34]
00007cc2697cf508  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf50e  pinsrb xmm1, r12d, 0x0D
00007cc2697cf515  lea r14, [rax+0x35]
00007cc2697cf519  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf51f  pinsrb xmm15, r12d, 0x0D
00007cc2697cf526  lea r14, [rax+0x36]
00007cc2697cf52a  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf530  pinsrb xmm14, r12d, 0x0D
00007cc2697cf537  lea r14, [rax+0x37]
00007cc2697cf53b  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf541  pinsrb xmm13, r12d, 0x0D
00007cc2697cf548  lea r14, [rax+0x38]
00007cc2697cf54c  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf552  pinsrb xmm1, r12d, 0x0E
00007cc2697cf559  lea r14, [rax+0x39]
00007cc2697cf55d  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf563  pinsrb xmm15, r12d, 0x0E
00007cc2697cf56a  lea r14, [rax+0x3A]
00007cc2697cf56e  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf574  pinsrb xmm14, r12d, 0x0E
00007cc2697cf57b  lea r14, [rax+0x3B]
00007cc2697cf57f  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf585  pinsrb xmm13, r12d, 0x0E
00007cc2697cf58c  lea r14, [rax+0x3C]
00007cc2697cf590  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf596  pinsrb xmm1, r12d, 0x0F
00007cc2697cf59d  movaps [r15+0x110], xmm1
00007cc2697cf5a5  lea r14, [rax+0x3D]
00007cc2697cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf5af  pinsrb xmm15, r12d, 0x0F
00007cc2697cf5b6  movaps [r15+0x120], xmm15
00007cc2697cf5be  lea r14, [rax+0x3E]
00007cc2697cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007cc2697cf5c8  pinsrb xmm14, r12d, 0x0F
00007cc2697cf5cf  movaps [r15+0x130], xmm14
00007cc2697cf5d7  lea r14, [rax+0x3F]
00007cc2697cf5db  movzx eax, byte ptr [r13+r14*1]
00007cc2697cf5e1  pinsrb xmm13, eax, 0x0F
00007cc2697cf5e8  movaps [r15+0x140], xmm13
00007cc2697cf5f0  movq xmm1, qword ptr [r15+0x120]
00007cc2697cf5f9  pmovzxbw xmm1, xmm1
00007cc2697cf5fe  psllw xmm1, 0x00
00007cc2697cf603  movaps [r15+0x150], xmm1
00007cc2697cf60b  movq xmm1, qword ptr [r15+0x130]
00007cc2697cf614  pmovzxbw xmm1, xmm1
00007cc2697cf619  psllw xmm1, 0x00
00007cc2697cf61e  movaps [r15+0x160], xmm1
00007cc2697cf626  movq xmm1, qword ptr [r15+0x110]
00007cc2697cf62f  pmovzxbw xmm1, xmm1
00007cc2697cf634  psllw xmm1, 0x00
00007cc2697cf639  movaps [r15+0x170], xmm1
00007cc2697cf641  movaps xmm15, [r15+0x110]
00007cc2697cf649  pextrq rax, xmm15, 0x01
00007cc2697cf650  movq xmm15, rax
00007cc2697cf655  pmovzxbw xmm15, xmm15
00007cc2697cf65b  psllw xmm15, 0x00
00007cc2697cf661  movaps [r15+0x180], xmm15
00007cc2697cf669  movaps xmm14, [r15+0x120]
00007cc2697cf671  pextrq rax, xmm14, 0x01
00007cc2697cf678  movq xmm14, rax
00007cc2697cf67d  pmovzxbw xmm14, xmm14
00007cc2697cf683  psllw xmm14, 0x00
00007cc2697cf689  movaps [r15+0x210], xmm14
00007cc2697cf691  movaps xmm13, [r15+0x130]
00007cc2697cf699  pextrq rax, xmm13, 0x01
00007cc2697cf6a0  movq xmm13, rax
00007cc2697cf6a5  pmovzxbw xmm13, xmm13
00007cc2697cf6ab  psllw xmm13, 0x00
00007cc2697cf6b1  movaps [r15+0x220], xmm13
00007cc2697cf6b9  movq xmm12, qword ptr [r15+0x140]
00007cc2697cf6c2  pmovzxbw xmm12, xmm12
00007cc2697cf6c8  psllw xmm12, 0x00
00007cc2697cf6ce  movaps [r15+0x250], xmm12
00007cc2697cf6d6  movaps xmm12, [r15+0x140]
00007cc2697cf6de  pextrq rax, xmm12, 0x01
00007cc2697cf6e5  movq xmm12, rax
00007cc2697cf6ea  pmovzxbw xmm12, xmm12
00007cc2697cf6f0  psllw xmm12, 0x00
00007cc2697cf6f6  movaps [r15+0x110], xmm12
00007cc2697cf6fe  movq xmm11, qword ptr [r15+0x150]
00007cc2697cf707  pmovzxwd xmm11, xmm11
00007cc2697cf70d  pslld xmm11, 0x10
00007cc2697cf713  movq xmm10, qword ptr [r15+0x160]
00007cc2697cf71c  pmovzxwd xmm10, xmm10
00007cc2697cf722  pslld xmm10, 0x08
00007cc2697cf728  pextrq rax, xmm1, 0x01
00007cc2697cf72f  movq xmm1, rax
00007cc2697cf734  pmovzxwd xmm1, xmm1
00007cc2697cf739  pslld xmm1, 0x00
00007cc2697cf73e  movaps [r15+0x260], xmm1
00007cc2697cf746  pextrq rax, xmm15, 0x01
00007cc2697cf74d  movq xmm15, rax
00007cc2697cf752  pmovzxwd xmm15, xmm15
00007cc2697cf758  pslld xmm15, 0x00
00007cc2697cf75e  movaps [r15+0x270], xmm15
00007cc2697cf766  movq xmm9, qword ptr [r15+0x170]
00007cc2697cf76f  pmovzxwd xmm9, xmm9
00007cc2697cf775  pslld xmm9, 0x00
00007cc2697cf77b  pextrq rax, xmm14, 0x01
00007cc2697cf782  movq xmm14, rax
00007cc2697cf787  pmovzxwd xmm14, xmm14
00007cc2697cf78d  pslld xmm14, 0x10
00007cc2697cf793  movaps [r15+0x280], xmm14
00007cc2697cf79b  movq xmm8, qword ptr [r15+0x180]
00007cc2697cf7a4  pmovzxwd xmm8, xmm8
00007cc2697cf7aa  pslld xmm8, 0x00
00007cc2697cf7b0  movq xmm7, qword ptr [r15+0x210]
00007cc2697cf7b9  pmovzxwd xmm7, xmm7
00007cc2697cf7be  pslld xmm7, 0x10
00007cc2697cf7c3  movaps xmm6, [r15+0x150]
00007cc2697cf7cb  pextrq rax, xmm6, 0x01
00007cc2697cf7d2  movq xmm6, rax
00007cc2697cf7d7  pmovzxwd xmm6, xmm6
00007cc2697cf7dc  pslld xmm6, 0x10
00007cc2697cf7e1  por xmm11, xmm10
00007cc2697cf7e6  movaps [r15+0x230], xmm11
00007cc2697cf7ee  pextrq rax, xmm13, 0x01
00007cc2697cf7f5  movq xmm13, rax
00007cc2697cf7fa  pmovzxwd xmm13, xmm13
00007cc2697cf800  pslld xmm13, 0x08
00007cc2697cf806  movaps [r15+0x240], xmm13
00007cc2697cf80e  movq xmm10, qword ptr [r15+0x220]
00007cc2697cf817  pmovzxwd xmm10, xmm10
00007cc2697cf81d  pslld xmm10, 0x08
00007cc2697cf823  movaps xmm5, [r15+0x160]
00007cc2697cf82b  pextrq rax, xmm5, 0x01
00007cc2697cf832  movq xmm5, rax
00007cc2697cf837  pmovzxwd xmm5, xmm5
00007cc2697cf83c  pslld xmm5, 0x08
00007cc2697cf841  pslld xmm9, 0x18
00007cc2697cf847  pslld xmm15, 0x18
00007cc2697cf84d  pslld xmm8, 0x18
00007cc2697cf853  movq xmm4, qword ptr [r15+0x250]
00007cc2697cf85c  pmovzxwd xmm4, xmm4
00007cc2697cf861  pslld xmm4, 0x00
00007cc2697cf866  por xmm14, xmm13
00007cc2697cf86b  por xmm7, xmm10
00007cc2697cf870  movaps [r15+0x210], xmm7
00007cc2697cf878  pslld xmm1, 0x18
00007cc2697cf87d  movaps [r15+0x220], xmm1
00007cc2697cf885  por xmm6, xmm5
00007cc2697cf889  por xmm11, xmm9
00007cc2697cf88e  movaps [r15+0x160], xmm11
00007cc2697cf896  pextrq rax, xmm12, 0x01
00007cc2697cf89d  movq xmm13, rax
00007cc2697cf8a2  pmovzxwd xmm13, xmm13
00007cc2697cf8a8  pslld xmm13, 0x00
00007cc2697cf8ae  movaps [r15+0x170], xmm13
00007cc2697cf8b6  movq xmm12, qword ptr [r15+0x110]
00007cc2697cf8bf  pmovzxwd xmm12, xmm12
00007cc2697cf8c5  pslld xmm12, 0x00
00007cc2697cf8cb  por xmm14, xmm15
00007cc2697cf8d0  por xmm7, xmm8
00007cc2697cf8d5  movaps xmm15, [r15+0x250]
00007cc2697cf8dd  pextrq rax, xmm15, 0x01
00007cc2697cf8e4  movq xmm15, rax
00007cc2697cf8e9  pmovzxwd xmm15, xmm15
00007cc2697cf8ef  pslld xmm15, 0x00
00007cc2697cf8f5  movaps [r15+0x180], xmm15
00007cc2697cf8fd  por xmm6, xmm1
00007cc2697cf901  movaps [r15+0x150], xmm6
00007cc2697cf909  por xmm11, xmm4
00007cc2697cf90e  movaps [r15+0x140], xmm11
00007cc2697cf916  por xmm7, xmm12
00007cc2697cf91b  movaps [r15+0x110], xmm7
00007cc2697cf923  por xmm14, xmm13
00007cc2697cf928  movaps [r15+0x120], xmm14
00007cc2697cf930  por xmm6, xmm15
00007cc2697cf935  movaps [r15+0x130], xmm6
00007cc2697cf93d  mov rax, [r15+0xF8]
00007cc2697cf944  lea r14, [rax+0x20]
00007cc2697cf948  movups [r13+r14*1], xmm7
00007cc2697cf94e  lea r14, [rax+0x30]
00007cc2697cf952  movups [r13+r14*1], xmm14
00007cc2697cf958  movups [r13+rax*1], xmm11
00007cc2697cf95e  lea r14, [rax+0x10]
00007cc2697cf962  movups [r13+r14*1], xmm6
00007cc2697cf968  mov r14d, [r13+rax*1]
00007cc2697cf96d  mov rax, [r15+0x48]
00007cc2697cf971  mov [r15+0x68], rax
00007cc2697cf975  mov qword ptr [r15+0x58], 0x04
00007cc2697cf97d  lea r12, [rax+0x04]
00007cc2697cf981  mov r11d, [r13+r12*1]
00007cc2697cf986  mov [rsp+0x10], r11d
00007cc2697cf98b  mov r11d, r11d
00007cc2697cf98e  mov [r15+0x70], r11
00007cc2697cf992  lea r12, [rax+0x38]
00007cc2697cf996  mov r11d, [r13+r12*1]
00007cc2697cf99b  lea r12, [rax+0x24]
00007cc2697cf99f  mov r10d, [r13+r12*1]
00007cc2697cf9a4  mov [rsp+0x20], r10d
00007cc2697cf9a9  mov r10d, r10d
00007cc2697cf9ac  mov [r15+0x90], r10
00007cc2697cf9b3  mov [rsp+0x30], rax
00007cc2697cf9b8  xor eax, eax
00007cc2697cf9ba  mov r12d, 0x04
00007cc2697cf9c0  mov r10d, 0xC0
00007cc2697cf9c6  cmp r12, r10
00007cc2697cf9c9  cmc
00007cc2697cf9ca  lahf
00007cc2697cf9cb  seto al
00007cc2697cf9ce  mov [r15+0x108], eax
00007cc2697cf9d5  mov eax, [rsp+0x10]
00007cc2697cf9d9  mov r12d, [rsp+0x10]
00007cc2697cf9de  shrd eax, r12d, 0x07
00007cc2697cf9e3  mov [rsp+0x10], r11d
00007cc2697cf9e8  mov r10d, [rsp+0x10]
00007cc2697cf9ed  shrd r11d, r10d, 0x11
00007cc2697cf9f2  mov r9d, [rsp+0x20]
00007cc2697cf9f7  lea r8d, [r9d+r14d*1]
00007cc2697cf9fc  rorx r14d, r12d, 0x12
00007cc2697cfa02  xor eax, r14d
00007cc2697cfa05  rorx r14d, r10d, 0x13
00007cc2697cfa0b  xor r11d, r14d
00007cc2697cfa0e  mov [rsp+0x10], r11d
00007cc2697cfa13  mov r11d, r11d
00007cc2697cfa16  mov [r15+0x88], r11
00007cc2697cfa1d  mov [rsp+0x20], r12d
00007cc2697cfa22  shr r12d, 0x03
00007cc2697cfa26  xor eax, r12d
00007cc2697cfa29  mov [rsp+0x40], eax
00007cc2697cfa2d  mov eax, eax
00007cc2697cfa2f  mov [r15+0x80], rax
00007cc2697cfa36  shr r10d, 0x0A
00007cc2697cfa3a  mov eax, [rsp+0x10]
00007cc2697cfa3e  xor eax, r10d
00007cc2697cfa41  mov [rsp+0x10], eax
00007cc2697cfa45  mov eax, eax
00007cc2697cfa47  mov [r15+0x78], rax
00007cc2697cfa4b  mov eax, [rsp+0x40]
00007cc2697cfa4f  lea r14d, [r8d+eax*1]
00007cc2697cfa54  mov eax, [rsp+0x10]
00007cc2697cfa58  lea r12d, [r14d+eax*1]
00007cc2697cfa5d  mov rax, [rsp+0x30]
00007cc2697cfa62  lea r14, [rax+0x40]
00007cc2697cfa66  mov [r13+r14*1], r12d
00007cc2697cfa6b  mov eax, [rsp+0x20]
00007cc2697cfa6f  mov eax, eax
00007cc2697cfa71  mov [r15+0x60], rax
00007cc2697cfa75  mov eax, [r15+0x108]
00007cc2697cfa7c  sahf
00007cc2697cfa7d  jnz 0x00007CC2697CFAAF
00007cc2697cfa7f  cmp dword ptr [r15+0x318], 0x00
00007cc2697cfa87  jz 0x00007CC2697CFF70
00007cc2697cfa8d  nop [rax+rax*1], ax
00007cc2697cfa96  nop [rax+rax*1], eax
00007cc2697cfa9e  mov eax, 0x410820
00007cc2697cfaa3  mov [r15+0x100], rax
00007cc2697cfaaa  jmp 0x00007CC2695FE110
00007cc2697cfaaf  cmp dword ptr [r15+0x318], 0x00
00007cc2697cfab7  jz 0x00007CC2697CFDC0
00007cc2697cfabd  nop [rax+rax*1], ax
00007cc2697cfac6  nop [rax+rax*1], eax
00007cc2697cface  mov eax, 0x4107D8
00007cc2697cfad3  mov [r15+0x100], rax
00007cc2697cfada  jmp 0x00007CC2695FE110
00007cc2697cfadf  int3
00007cc2697cfae0  call 0x00007CC26960D860
00007cc2697cfae5  jmp 0x00007CC2697CF17A
00007cc2697cfaea  call 0x00007CC2696E2420
00007cc2697cfaef  jmp 0x00007CC2697CF193
00007cc2697cfaf4  call 0x00007CC2696E2420
00007cc2697cfaf9  jmp 0x00007CC2697CF1AC
00007cc2697cfafe  call 0x00007CC2696E2420
00007cc2697cfb03  jmp 0x00007CC2697CF1C5
00007cc2697cfb08  call 0x00007CC2696E2420
00007cc2697cfb0d  jmp 0x00007CC2697CF1DE
00007cc2697cfb12  call 0x00007CC2696E2420
00007cc2697cfb17  jmp 0x00007CC2697CF1EF
00007cc2697cfb1c  call 0x00007CC2696E2420
00007cc2697cfb21  jmp 0x00007CC2697CF200
00007cc2697cfb26  call 0x00007CC2696E2420
00007cc2697cfb2b  jmp 0x00007CC2697CF211
00007cc2697cfb30  call 0x00007CC2696E2420
00007cc2697cfb35  jmp 0x00007CC2697CF222
00007cc2697cfb3a  call 0x00007CC2696E2420
00007cc2697cfb3f  jmp 0x00007CC2697CF233
00007cc2697cfb44  call 0x00007CC2696E2420
00007cc2697cfb49  jmp 0x00007CC2697CF244
00007cc2697cfb4e  call 0x00007CC2696E2420
00007cc2697cfb53  jmp 0x00007CC2697CF255
00007cc2697cfb58  call 0x00007CC2696E2420
00007cc2697cfb5d  jmp 0x00007CC2697CF266
00007cc2697cfb62  call 0x00007CC2696E2420
00007cc2697cfb67  jmp 0x00007CC2697CF277
00007cc2697cfb6c  call 0x00007CC2696E2420
00007cc2697cfb71  jmp 0x00007CC2697CF288
00007cc2697cfb76  call 0x00007CC2696E2420
00007cc2697cfb7b  jmp 0x00007CC2697CF299
00007cc2697cfb80  call 0x00007CC2696E2420
00007cc2697cfb85  jmp 0x00007CC2697CF2AA
00007cc2697cfb8a  call 0x00007CC2696E2420
00007cc2697cfb8f  jmp 0x00007CC2697CF2BB
00007cc2697cfb94  call 0x00007CC2696E2420
00007cc2697cfb99  jmp 0x00007CC2697CF2CC
00007cc2697cfb9e  call 0x00007CC2696E2420
00007cc2697cfba3  jmp 0x00007CC2697CF2DD
00007cc2697cfba8  call 0x00007CC2696E2420
00007cc2697cfbad  jmp 0x00007CC2697CF2EE
00007cc2697cfbb2  call 0x00007CC2696E2420
00007cc2697cfbb7  jmp 0x00007CC2697CF2FF
00007cc2697cfbbc  call 0x00007CC2696E2420
00007cc2697cfbc1  jmp 0x00007CC2697CF310
00007cc2697cfbc6  call 0x00007CC2696E2420
00007cc2697cfbcb  jmp 0x00007CC2697CF321
00007cc2697cfbd0  call 0x00007CC2696E2420
00007cc2697cfbd5  jmp 0x00007CC2697CF332
00007cc2697cfbda  call 0x00007CC2696E2420
00007cc2697cfbdf  jmp 0x00007CC2697CF343
00007cc2697cfbe4  call 0x00007CC2696E2420
00007cc2697cfbe9  jmp 0x00007CC2697CF354
00007cc2697cfbee  call 0x00007CC2696E2420
00007cc2697cfbf3  jmp 0x00007CC2697CF365
00007cc2697cfbf8  call 0x00007CC2696E2420
00007cc2697cfbfd  jmp 0x00007CC2697CF376
00007cc2697cfc02  call 0x00007CC2696E2420
00007cc2697cfc07  jmp 0x00007CC2697CF387
00007cc2697cfc0c  call 0x00007CC2696E2420
00007cc2697cfc11  jmp 0x00007CC2697CF398
00007cc2697cfc16  call 0x00007CC2696E2420
00007cc2697cfc1b  jmp 0x00007CC2697CF3A9
00007cc2697cfc20  call 0x00007CC2696E2420
00007cc2697cfc25  jmp 0x00007CC2697CF3BA
00007cc2697cfc2a  call 0x00007CC2696E2420
00007cc2697cfc2f  jmp 0x00007CC2697CF3CB
00007cc2697cfc34  call 0x00007CC2696E2420
00007cc2697cfc39  jmp 0x00007CC2697CF3DC
00007cc2697cfc3e  call 0x00007CC2696E2420
00007cc2697cfc43  jmp 0x00007CC2697CF3ED
00007cc2697cfc48  call 0x00007CC2696E2420
00007cc2697cfc4d  jmp 0x00007CC2697CF3FE
00007cc2697cfc52  call 0x00007CC2696E2420
00007cc2697cfc57  jmp 0x00007CC2697CF40F
00007cc2697cfc5c  call 0x00007CC2696E2420
00007cc2697cfc61  jmp 0x00007CC2697CF420
00007cc2697cfc66  call 0x00007CC2696E2420
00007cc2697cfc6b  jmp 0x00007CC2697CF431
00007cc2697cfc70  call 0x00007CC2696E2420
00007cc2697cfc75  jmp 0x00007CC2697CF442
00007cc2697cfc7a  call 0x00007CC2696E2420
00007cc2697cfc7f  jmp 0x00007CC2697CF453
00007cc2697cfc84  call 0x00007CC2696E2420
00007cc2697cfc89  jmp 0x00007CC2697CF464
00007cc2697cfc8e  call 0x00007CC2696E2420
00007cc2697cfc93  jmp 0x00007CC2697CF475
00007cc2697cfc98  call 0x00007CC2696E2420
00007cc2697cfc9d  jmp 0x00007CC2697CF486
00007cc2697cfca2  call 0x00007CC2696E2420
00007cc2697cfca7  jmp 0x00007CC2697CF497
00007cc2697cfcac  call 0x00007CC2696E2420
00007cc2697cfcb1  jmp 0x00007CC2697CF4A8
00007cc2697cfcb6  call 0x00007CC2696E2420
00007cc2697cfcbb  jmp 0x00007CC2697CF4B9
00007cc2697cfcc0  call 0x00007CC2696E2420
00007cc2697cfcc5  jmp 0x00007CC2697CF4CA
00007cc2697cfcca  call 0x00007CC2696E2420
00007cc2697cfccf  jmp 0x00007CC2697CF4DB
00007cc2697cfcd4  call 0x00007CC2696E2420
00007cc2697cfcd9  jmp 0x00007CC2697CF4EC
00007cc2697cfcde  call 0x00007CC2696E2420
00007cc2697cfce3  jmp 0x00007CC2697CF4FD
00007cc2697cfce8  call 0x00007CC2696E2420
00007cc2697cfced  jmp 0x00007CC2697CF50E
00007cc2697cfcf2  call 0x00007CC2696E2420
00007cc2697cfcf7  jmp 0x00007CC2697CF51F
00007cc2697cfcfc  call 0x00007CC2696E2420
00007cc2697cfd01  jmp 0x00007CC2697CF530
00007cc2697cfd06  call 0x00007CC2696E2420
00007cc2697cfd0b  jmp 0x00007CC2697CF541
00007cc2697cfd10  call 0x00007CC2696E2420
00007cc2697cfd15  jmp 0x00007CC2697CF552
00007cc2697cfd1a  call 0x00007CC2696E2420
00007cc2697cfd1f  jmp 0x00007CC2697CF563
00007cc2697cfd24  call 0x00007CC2696E2420
00007cc2697cfd29  jmp 0x00007CC2697CF574
00007cc2697cfd2e  call 0x00007CC2696E2420
00007cc2697cfd33  jmp 0x00007CC2697CF585
00007cc2697cfd38  call 0x00007CC2696E2420
00007cc2697cfd3d  jmp 0x00007CC2697CF596
00007cc2697cfd42  call 0x00007CC2696E2420
00007cc2697cfd47  jmp 0x00007CC2697CF5AF
00007cc2697cfd4c  call 0x00007CC2696E2420
00007cc2697cfd51  jmp 0x00007CC2697CF5C8
00007cc2697cfd56  call 0x00007CC2696D5610
00007cc2697cfd5b  jmp 0x00007CC2697CF5E1
00007cc2697cfd60  call 0x00007CC2696DC580
00007cc2697cfd65  jmp 0x00007CC2697CF94E
00007cc2697cfd6a  call 0x00007CC2696E46C0
00007cc2697cfd6f  jmp 0x00007CC2697CF958
00007cc2697cfd74  call 0x00007CC269609E90
00007cc2697cfd79  jmp 0x00007CC2697CF95E
00007cc2697cfd7e  call 0x00007CC2696DB310
00007cc2697cfd83  jmp 0x00007CC2697CF968
00007cc2697cfd88  call 0x00007CC26960DAE0
00007cc2697cfd8d  jmp 0x00007CC2697CF96D
00007cc2697cfd92  call 0x00007CC2696C0230
00007cc2697cfd97  jmp 0x00007CC2697CF986
00007cc2697cfd9c  call 0x00007CC2696C0230
00007cc2697cfda1  jmp 0x00007CC2697CF99B
00007cc2697cfda6  call 0x00007CC2696BEFC0
00007cc2697cfdab  jmp 0x00007CC2697CF9A4
00007cc2697cfdb0  call 0x00007CC2696E2BA0
00007cc2697cfdb5  jmp 0x00007CC2697CFA6B
00007cc2697cfdba  int3
00007cc2697cfdbb  nop [rax+rax*1], eax
00007cc2697cfdc0  mov rax, [r15+0x48]
00007cc2697cfdc4  mov r14, [r15+0x58]
00007cc2697cfdc8  lea r12, [rax+r14*1]
00007cc2697cfdcc  mov [r15+0x68], r12
00007cc2697cfdd0  lea rax, [r14+0x04]
00007cc2697cfdd4  mov [r15+0x58], rax
00007cc2697cfdd8  lea r14, [r12+0x04]
00007cc2697cfddd  mov r11d, [r13+r14*1]
00007cc2697cfde2  mov [rsp+0x10], r11d
00007cc2697cfde7  mov r11d, r11d
00007cc2697cfdea  mov [r15+0x70], r11
00007cc2697cfdee  lea r14, [r12+0x38]
00007cc2697cfdf3  mov r11d, [r13+r14*1]
00007cc2697cfdf8  lea r14, [r12+0x24]
00007cc2697cfdfd  mov r10d, [r13+r14*1]
00007cc2697cfe02  mov [rsp+0x20], r10d
00007cc2697cfe07  mov r10d, r10d
00007cc2697cfe0a  mov [r15+0x90], r10
00007cc2697cfe11  mov [rsp+0x30], rax
00007cc2697cfe16  xor eax, eax
00007cc2697cfe18  mov r14, [rsp+0x30]
00007cc2697cfe1d  mov r10d, 0xC0
00007cc2697cfe23  cmp r14, r10
00007cc2697cfe26  cmc
00007cc2697cfe27  lahf
00007cc2697cfe28  seto al
00007cc2697cfe2b  mov [r15+0x108], eax
00007cc2697cfe32  mov eax, [rsp+0x10]
00007cc2697cfe36  mov r14d, [rsp+0x10]
00007cc2697cfe3b  shrd eax, r14d, 0x07
00007cc2697cfe40  mov [rsp+0x10], r11d
00007cc2697cfe45  mov r10d, [rsp+0x10]
00007cc2697cfe4a  shrd r11d, r10d, 0x11
00007cc2697cfe4f  mov r9d, [r15+0x60]
00007cc2697cfe53  mov r8d, [rsp+0x20]
00007cc2697cfe58  lea ebp, [r8d+r9d*1]
00007cc2697cfe5d  rorx r9d, r14d, 0x12
00007cc2697cfe63  xor eax, r9d
00007cc2697cfe66  rorx r9d, r10d, 0x13
00007cc2697cfe6c  xor r11d, r9d
00007cc2697cfe6f  mov [rsp+0x10], r11d
00007cc2697cfe74  mov r11d, r11d
00007cc2697cfe77  mov [r15+0x88], r11
00007cc2697cfe7e  mov [rsp+0x20], r14d
00007cc2697cfe83  shr r14d, 0x03
00007cc2697cfe87  xor eax, r14d
00007cc2697cfe8a  mov [rsp+0x30], eax
00007cc2697cfe8e  mov eax, eax
00007cc2697cfe90  mov [r15+0x80], rax
00007cc2697cfe97  shr r10d, 0x0A
00007cc2697cfe9b  mov eax, [rsp+0x10]
00007cc2697cfe9f  xor eax, r10d
00007cc2697cfea2  mov [rsp+0x10], eax
00007cc2697cfea6  mov eax, eax
00007cc2697cfea8  mov [r15+0x78], rax
00007cc2697cfeac  mov eax, [rsp+0x30]
00007cc2697cfeb0  lea r14d, [ebp+eax*1]
00007cc2697cfeb6  mov eax, [rsp+0x10]
00007cc2697cfeba  lea r11d, [r14d+eax*1]
00007cc2697cfebf  lea rax, [r12+0x40]
00007cc2697cfec4  mov [r13+rax*1], r11d
00007cc2697cfec9  mov eax, [rsp+0x20]
00007cc2697cfecd  mov eax, eax
00007cc2697cfecf  mov [r15+0x60], rax
00007cc2697cfed3  mov eax, [r15+0x108]
00007cc2697cfeda  sahf
00007cc2697cfedb  jnz 0x00007CC2697CFF0D
00007cc2697cfedd  cmp dword ptr [r15+0x318], 0x00
00007cc2697cfee5  jz 0x00007CC2697CFF70
00007cc2697cfeeb  nop [rax+rax*1], ax
00007cc2697cfef4  nop [rax+rax*1], eax
00007cc2697cfefc  mov eax, 0x410820
00007cc2697cff01  mov [r15+0x100], rax
00007cc2697cff08  jmp 0x00007CC2695FE110
00007cc2697cff0d  cmp dword ptr [r15+0x318], 0x00
00007cc2697cff15  jz 0x00007CC2697CFDC0
00007cc2697cff1b  nop [rax+rax*1], ax
00007cc2697cff24  nop [rax+rax*1], eax
00007cc2697cff2c  mov eax, 0x4107D8
00007cc2697cff31  mov [r15+0x100], rax
00007cc2697cff38  jmp 0x00007CC2695FE110
00007cc2697cff3d  int3
00007cc2697cff3e  call 0x00007CC2696E1430
00007cc2697cff43  jmp 0x00007CC2697CFDE2
00007cc2697cff48  call 0x00007CC2696E1430
00007cc2697cff4d  jmp 0x00007CC2697CFDF8
00007cc2697cff52  call 0x00007CC2696E01C0
00007cc2697cff57  jmp 0x00007CC2697CFE02
00007cc2697cff5c  call 0x00007CC26960A860
00007cc2697cff61  jmp 0x00007CC2697CFEC9
00007cc2697cff66  int3
00007cc2697cff67  nop [rax+rax*1], ax
00007cc2697cff70  mov rax, [r15]
00007cc2697cff73  mov r14d, [r13+rax*1]
00007cc2697cff78  lea r12, [rax+0x04]
00007cc2697cff7c  mov r11d, [r13+r12*1]
00007cc2697cff81  mov [rsp+0x10], r14d
00007cc2697cff86  mov r14d, r14d
00007cc2697cff89  mov [r15+0x78], r14
00007cc2697cff8d  mov [rsp+0x20], r11d
00007cc2697cff92  mov r11d, r11d
00007cc2697cff95  mov [r15+0x80], r11
00007cc2697cff9c  lea r14, [rax+0x08]
00007cc2697cffa0  mov r12d, [r13+r14*1]
00007cc2697cffa5  lea r14, [rax+0x0C]
00007cc2697cffa9  mov r11d, [r13+r14*1]
00007cc2697cffae  mov [rsp+0x30], r12d
00007cc2697cffb3  mov r12d, r12d
00007cc2697cffb6  mov [r15+0x70], r12
00007cc2697cffba  mov [rsp+0x40], r11d
00007cc2697cffbf  mov r11d, r11d
00007cc2697cffc2  mov [r15+0x68], r11
00007cc2697cffc6  lea r14, [rax+0x18]
00007cc2697cffca  mov r12d, [r13+r14*1]
00007cc2697cffcf  lea r14, [rax+0x1C]
00007cc2697cffd3  mov r11d, [r13+r14*1]
00007cc2697cffd8  mov [rsp+0x50], r12d
00007cc2697cffdd  mov r12d, r12d
00007cc2697cffe0  mov [r15+0x58], r12
00007cc2697cffe4  mov [rsp+0x60], r11d
00007cc2697cffe9  mov r11d, r11d
00007cc2697cffec  mov [r15+0x60], r11
00007cc2697cfff0  lea r14, [rax+0x10]
00007cc2697cfff4  mov r12d, [r13+r14*1]
00007cc2697cfff9  lea r14, [rax+0x14]
00007cc2697cfffd  mov eax, [r13+r14*1]
00007cc2697d0002  mov [rsp+0x70], r12d
00007cc2697d0007  mov r12d, r12d
00007cc2697d000a  mov [r15+0x18], r12
00007cc2697d000e  mov [rsp+0x80], eax
00007cc2697d0015  mov eax, eax
00007cc2697d0017  mov [r15+0x90], rax
00007cc2697d001e  mov eax, [rsp+0x70]
00007cc2697d0022  mov eax, eax
00007cc2697d0024  mov [r15+0x30], rax
00007cc2697d0028  mov eax, [rsp+0x50]
00007cc2697d002c  mov eax, eax
00007cc2697d002e  mov [r15+0xA0], rax
00007cc2697d0035  mov eax, [rsp+0x30]
00007cc2697d0039  mov eax, eax
00007cc2697d003b  mov [r15+0x28], rax
00007cc2697d003f  mov eax, [rsp+0x20]
00007cc2697d0043  mov eax, eax
00007cc2697d0045  mov [r15+0x98], rax
00007cc2697d004c  mov eax, [rsp+0x10]
00007cc2697d0050  mov eax, eax
00007cc2697d0052  mov [r15+0x38], rax
00007cc2697d0056  mov eax, [rsp+0x70]
00007cc2697d005a  mov r14d, [rsp+0x70]
00007cc2697d005f  shrd eax, r14d, 0x06
00007cc2697d0064  mov [rsp+0x70], r14d
00007cc2697d0069  mov r12d, [rsp+0x80]
00007cc2697d0071  and r14d, r12d
00007cc2697d0074  mov r11d, [rsp+0x10]
00007cc2697d0079  mov r10d, [rsp+0x10]
00007cc2697d007e  shrd r11d, r10d, 0x02
00007cc2697d0083  mov [rsp+0x10], r12d
00007cc2697d0088  mov r12d, r12d
00007cc2697d008b  mov [r15+0x20], r12
00007cc2697d008f  mov r12, [r15+0x50]
00007cc2697d0093  mov r9d, [r13+r12*1]
00007cc2697d0098  mov r12d, [rsp+0x50]
00007cc2697d009d  mov r8d, [rsp+0x70]
00007cc2697d00a2  andn ebp, r8d, r12d
00007cc2697d00a7  mov edi, [rsp+0x60]
00007cc2697d00ab  lea esi, [r14d+edi*1]
00007cc2697d00b0  rorx r14d, r8d, 0x0B
00007cc2697d00b6  xor eax, r14d
00007cc2697d00b9  rorx r14d, r10d, 0x0D
00007cc2697d00bf  xor r11d, r14d
00007cc2697d00c2  lea edi, [esi+ebp*1]
00007cc2697d00c6  mov r14, [r15+0x48]
00007cc2697d00ca  mov ebp, [r13+r14*1]
00007cc2697d00cf  mov r14d, [rsp+0x30]
00007cc2697d00d4  mov esi, [rsp+0x20]
00007cc2697d00d8  and r14d, esi
00007cc2697d00db  mov [rsp+0x20], r14d
00007cc2697d00e0  mov r14d, r14d
00007cc2697d00e3  mov [r15+0xD8], r14
00007cc2697d00ea  lea r14d, [edi+r9d*1]
00007cc2697d00ef  mov r9d, [rsp+0x30]
00007cc2697d00f4  xor r9d, esi
00007cc2697d00f7  rorx edi, r8d, 0x19
00007cc2697d00fd  xor eax, edi
00007cc2697d00ff  and r9d, r10d
00007cc2697d0102  rorx edi, r10d, 0x16
00007cc2697d0108  xor r11d, edi
00007cc2697d010b  mov [rsp+0x30], r11d
00007cc2697d0110  mov r11d, r11d
00007cc2697d0113  mov [r15+0xD0], r11
00007cc2697d011a  lea r11d, [r14d+ebp*1]
00007cc2697d011f  mov r10d, [rsp+0x20]
00007cc2697d0124  xor r9d, r10d
00007cc2697d0127  lea r14d, [r11d+eax*1]
00007cc2697d012c  mov qword ptr [r15+0x88], 0x04
00007cc2697d0137  mov eax, [rsp+0x30]
00007cc2697d013b  lea r11d, [r9d+eax*1]
00007cc2697d0140  mov eax, [rsp+0x40]
00007cc2697d0144  lea r10d, [r14d+eax*1]
00007cc2697d0149  mov r10d, r10d
00007cc2697d014c  mov [r15+0xB8], r10
00007cc2697d0153  xor eax, eax
00007cc2697d0155  mov r10d, 0x04
00007cc2697d015b  mov r9d, 0x100
00007cc2697d0161  cmp r10, r9
00007cc2697d0164  cmc
00007cc2697d0165  lahf
00007cc2697d0166  seto al
00007cc2697d0169  mov [r15+0x108], eax
00007cc2697d0170  lea eax, [r11d+r14d*1]
00007cc2697d0175  mov eax, eax
00007cc2697d0177  mov [r15+0xA8], rax
00007cc2697d017e  mov r12d, r12d
00007cc2697d0181  mov [r15+0xB0], r12
00007cc2697d0188  mov eax, [rsp+0x10]
00007cc2697d018c  mov eax, eax
00007cc2697d018e  mov [r15+0xC0], rax
00007cc2697d0195  mov r8d, r8d
00007cc2697d0198  mov [r15+0xC8], r8
00007cc2697d019f  mov eax, [r15+0x108]
00007cc2697d01a6  sahf
00007cc2697d01a7  jnz 0x00007CC2697D01D9
00007cc2697d01a9  cmp dword ptr [r15+0x318], 0x00
00007cc2697d01b1  jz 0x00007CC2697D04A0
00007cc2697d01b7  nop [rax+rax*1], ax
00007cc2697d01c0  nop [rax+rax*1], eax
00007cc2697d01c8  mov eax, 0x4108E0
00007cc2697d01cd  mov [r15+0x100], rax
00007cc2697d01d4  jmp 0x00007CC2695FE110
00007cc2697d01d9  cmp dword ptr [r15+0x318], 0x00
00007cc2697d01e1  jz 0x00007CC2697D0270
00007cc2697d01e7  nop [rax+rax*1], ax
00007cc2697d01f0  nop [rax+rax*1], eax
00007cc2697d01f8  mov eax, 0x410854
00007cc2697d01fd  mov [r15+0x100], rax
00007cc2697d0204  jmp 0x00007CC2695FE110
00007cc2697d0209  int3
00007cc2697d020a  call 0x00007CC26960DAE0
00007cc2697d020f  jmp 0x00007CC2697CFF78
00007cc2697d0214  call 0x00007CC2696C0230
00007cc2697d0219  jmp 0x00007CC2697CFF81
00007cc2697d021e  call 0x00007CC2696E26A0
00007cc2697d0223  jmp 0x00007CC2697CFFA5
00007cc2697d0228  call 0x00007CC2696E1430
00007cc2697d022d  jmp 0x00007CC2697CFFAE
00007cc2697d0232  call 0x00007CC2696E26A0
00007cc2697d0237  jmp 0x00007CC2697CFFCF
00007cc2697d023c  call 0x00007CC2696E1430
00007cc2697d0241  jmp 0x00007CC2697CFFD8
00007cc2697d0246  call 0x00007CC2696E26A0
00007cc2697d024b  jmp 0x00007CC2697CFFF9
00007cc2697d0250  call 0x00007CC2696D5890
00007cc2697d0255  jmp 0x00007CC2697D0002
00007cc2697d025a  call 0x00007CC2696BDD50
00007cc2697d025f  jmp 0x00007CC2697D0098
00007cc2697d0264  call 0x00007CC2696DA580
00007cc2697d0269  jmp 0x00007CC2697D00CF
00007cc2697d026e  int3
00007cc2697d026f  nop
00007cc2697d0270  mov eax, [r15+0xB8]
00007cc2697d0277  mov [rsp+0x10], eax
00007cc2697d027b  mov eax, eax
00007cc2697d027d  mov [r15+0x30], rax
00007cc2697d0281  mov eax, [r15+0xC0]
00007cc2697d0288  mov [rsp+0x20], eax
00007cc2697d028c  mov eax, eax
00007cc2697d028e  mov [r15+0xA0], rax
00007cc2697d0295  mov eax, [r15+0x28]
00007cc2697d0299  mov r14d, [r15+0x98]
00007cc2697d02a0  mov [rsp+0x30], r14d
00007cc2697d02a5  mov r14d, r14d
00007cc2697d02a8  mov [r15+0x28], r14
00007cc2697d02ac  mov r14d, [r15+0x38]
00007cc2697d02b0  mov [rsp+0x40], r14d
00007cc2697d02b5  mov r14d, r14d
00007cc2697d02b8  mov [r15+0x98], r14
00007cc2697d02bf  mov r14d, [r15+0xA8]
00007cc2697d02c6  mov [rsp+0x50], r14d
00007cc2697d02cb  mov r14d, r14d
00007cc2697d02ce  mov [r15+0x38], r14
00007cc2697d02d2  mov r14d, [rsp+0x10]
00007cc2697d02d7  mov r12d, [rsp+0x10]
00007cc2697d02dc  shrd r14d, r12d, 0x06
00007cc2697d02e1  mov r11d, [r15+0xC8]
00007cc2697d02e8  mov [rsp+0x10], r12d
00007cc2697d02ed  and r12d, r11d
00007cc2697d02f0  mov r10d, [rsp+0x50]
00007cc2697d02f5  mov r9d, [rsp+0x50]
00007cc2697d02fa  shrd r10d, r9d, 0x02
00007cc2697d02ff  mov [rsp+0x50], r11d
00007cc2697d0304  mov r11d, r11d
00007cc2697d0307  mov [r15+0x20], r11
00007cc2697d030b  mov r11, [r15+0x88]
00007cc2697d0312  mov r8, [r15+0x50]
00007cc2697d0316  lea rbp, [r8+r11*1]
00007cc2697d031a  mov r8d, [r13+rbp*1]
00007cc2697d031f  mov ebp, [rsp+0x20]
00007cc2697d0323  mov edi, [rsp+0x10]
00007cc2697d0327  andn esi, edi, ebp
00007cc2697d032c  mov edx, [r15+0xB0]
00007cc2697d0333  lea ecx, [r12d+edx*1]
00007cc2697d0338  rorx r12d, edi, 0x0B
00007cc2697d033e  xor r14d, r12d
00007cc2697d0341  rorx r12d, r9d, 0x0D
00007cc2697d0347  xor r10d, r12d
00007cc2697d034a  lea r12d, [ecx+esi*1]
00007cc2697d034f  mov rsi, [r15+0x48]
00007cc2697d0353  lea rdx, [rsi+r11*1]
00007cc2697d0357  mov esi, [r13+rdx*1]
00007cc2697d035c  mov edx, [rsp+0x30]
00007cc2697d0360  mov ecx, [rsp+0x40]
00007cc2697d0364  and edx, ecx
00007cc2697d0366  mov [rsp+0x10], edx
00007cc2697d036a  mov edx, edx
00007cc2697d036c  mov [r15+0xD8], rdx
00007cc2697d0373  lea edx, [r12d+r8d*1]
00007cc2697d0378  mov r12d, [rsp+0x30]
00007cc2697d037d  xor r12d, ecx
00007cc2697d0380  rorx r8d, edi, 0x19
00007cc2697d0386  xor r14d, r8d
00007cc2697d0389  and r12d, r9d
00007cc2697d038c  rorx r8d, r9d, 0x16
00007cc2697d0392  xor r10d, r8d
00007cc2697d0395  mov [rsp+0x20], r10d
00007cc2697d039a  mov r10d, r10d
00007cc2697d039d  mov [r15+0xD0], r10
00007cc2697d03a4  lea r10d, [edx+esi*1]
00007cc2697d03a9  mov r9d, [rsp+0x10]
00007cc2697d03ae  xor r12d, r9d
00007cc2697d03b1  lea r9d, [r10d+r14d*1]
00007cc2697d03b6  lea r14, [r11+0x04]
00007cc2697d03ba  mov [r15+0x88], r14
00007cc2697d03c1  mov r11d, [rsp+0x20]
00007cc2697d03c6  lea r10d, [r12d+r11d*1]
00007cc2697d03cb  lea r11d, [r9d+eax*1]
00007cc2697d03d0  mov r11d, r11d
00007cc2697d03d3  mov [r15+0xB8], r11
00007cc2697d03da  xor eax, eax
00007cc2697d03dc  mov r12d, 0x100
00007cc2697d03e2  cmp r14, r12
00007cc2697d03e5  cmc
00007cc2697d03e6  lahf
00007cc2697d03e7  seto al
00007cc2697d03ea  mov [r15+0x108], eax
00007cc2697d03f1  lea eax, [r10d+r9d*1]
00007cc2697d03f6  mov eax, eax
00007cc2697d03f8  mov [r15+0xA8], rax
00007cc2697d03ff  mov ebp, ebp
00007cc2697d0401  mov [r15+0xB0], rbp
00007cc2697d0408  mov eax, [rsp+0x50]
00007cc2697d040c  mov eax, eax
00007cc2697d040e  mov [r15+0xC0], rax
00007cc2697d0415  mov edi, edi
00007cc2697d0417  mov [r15+0xC8], rdi
00007cc2697d041e  mov eax, [r15+0x108]
00007cc2697d0425  sahf
00007cc2697d0426  jnz 0x00007CC2697D0458
00007cc2697d0428  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0430  jz 0x00007CC2697D04A0
00007cc2697d0436  nop [rax+rax*1], ax
00007cc2697d043f  nop [rax+rax*1], eax
00007cc2697d0447  mov eax, 0x4108E0
00007cc2697d044c  mov [r15+0x100], rax
00007cc2697d0453  jmp 0x00007CC2695FE110
00007cc2697d0458  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0460  jz 0x00007CC2697D0270
00007cc2697d0466  nop [rax+rax*1], ax
00007cc2697d046f  nop [rax+rax*1], eax
00007cc2697d0477  mov eax, 0x410854
00007cc2697d047c  mov [r15+0x100], rax
00007cc2697d0483  jmp 0x00007CC2695FE110
00007cc2697d0488  int3
00007cc2697d0489  call 0x00007CC269649010
00007cc2697d048e  jmp 0x00007CC2697D031F
00007cc2697d0493  call 0x00007CC269625930
00007cc2697d0498  jmp 0x00007CC2697D035C
00007cc2697d049d  int3
00007cc2697d049e  nop
00007cc2697d04a0  mov eax, [r15+0x98]
00007cc2697d04a7  mov r14d, [r15+0x70]
00007cc2697d04ab  lea r12d, [eax+r14d*1]
00007cc2697d04b0  mov eax, [r15+0x28]
00007cc2697d04b4  mov r14d, [r15+0x68]
00007cc2697d04b8  lea r11d, [eax+r14d*1]
00007cc2697d04bd  mov qword ptr [r15+0x88], 0x00
00007cc2697d04c8  mov eax, [r15+0xA8]
00007cc2697d04cf  mov r14d, [r15+0x78]
00007cc2697d04d3  lea r10d, [eax+r14d*1]
00007cc2697d04d8  mov [rsp+0x10], r10d
00007cc2697d04dd  mov r10d, r10d
00007cc2697d04e0  mov [r15+0x78], r10
00007cc2697d04e4  mov eax, [r15+0x38]
00007cc2697d04e8  mov r14d, [r15+0x80]
00007cc2697d04ef  lea r10d, [eax+r14d*1]
00007cc2697d04f4  mov [rsp+0x20], r10d
00007cc2697d04f9  mov r10d, r10d
00007cc2697d04fc  mov [r15+0x80], r10
00007cc2697d0503  mov rax, [r15]
00007cc2697d0506  lea r14, [rax+0x08]
00007cc2697d050a  mov [r13+r14*1], r12d
00007cc2697d050f  lea r14, [rax+0x0C]
00007cc2697d0513  mov [r13+r14*1], r11d
00007cc2697d0518  mov r14d, [r15+0xB8]
00007cc2697d051f  mov r12d, [r15+0x18]
00007cc2697d0523  lea r11d, [r14d+r12d*1]
00007cc2697d0528  mov [rsp+0x30], r11d
00007cc2697d052d  mov r11d, r11d
00007cc2697d0530  mov [r15+0x68], r11
00007cc2697d0534  mov r14d, [r15+0x30]
00007cc2697d0538  mov r12d, [r15+0x90]
00007cc2697d053f  lea r11d, [r14d+r12d*1]
00007cc2697d0544  mov [rsp+0x40], r11d
00007cc2697d0549  mov r11d, r11d
00007cc2697d054c  mov [r15+0x70], r11
00007cc2697d0550  mov r14d, [r15+0x20]
00007cc2697d0554  mov r12d, [r15+0x58]
00007cc2697d0558  lea r11d, [r14d+r12d*1]
00007cc2697d055d  mov [rsp+0x50], r11d
00007cc2697d0562  mov r11d, r11d
00007cc2697d0565  mov [r15+0x58], r11
00007cc2697d0569  mov r14d, [r15+0xA0]
00007cc2697d0570  mov r12d, [r15+0x60]
00007cc2697d0574  lea r11d, [r14d+r12d*1]
00007cc2697d0579  mov [rsp+0x60], r11d
00007cc2697d057e  mov r11d, r11d
00007cc2697d0581  mov [r15+0x60], r11
00007cc2697d0585  mov r14d, [rsp+0x10]
00007cc2697d058a  mov [r13+rax*1], r14d
00007cc2697d058f  lea r14, [rax+0x04]
00007cc2697d0593  mov r12d, [rsp+0x20]
00007cc2697d0598  mov [r13+r14*1], r12d
00007cc2697d059d  lea r14, [rax+0x10]
00007cc2697d05a1  mov r12d, [rsp+0x30]
00007cc2697d05a6  mov [r13+r14*1], r12d
00007cc2697d05ab  lea r14, [rax+0x14]
00007cc2697d05af  mov r12d, [rsp+0x40]
00007cc2697d05b4  mov [r13+r14*1], r12d
00007cc2697d05b9  lea r14, [rax+0x18]
00007cc2697d05bd  mov r12d, [rsp+0x50]
00007cc2697d05c2  mov [r13+r14*1], r12d
00007cc2697d05c7  lea r14, [rax+0x1C]
00007cc2697d05cb  mov r12d, [rsp+0x60]
00007cc2697d05d0  mov [r13+r14*1], r12d
00007cc2697d05d5  lea r14, [rax+0x68]
00007cc2697d05d9  xor eax, eax
00007cc2697d05db  mov [r13+r14*1], rax
00007cc2697d05e0  cmp dword ptr [r15+0x318], 0x00
00007cc2697d05e8  jz 0x00007CC2697CF0E0
00007cc2697d05ee  nop [rax+rax*1], ax
00007cc2697d05f7  nop [rax+rax*1], eax
00007cc2697d05ff  mov eax, 0x4106FC
00007cc2697d0604  mov [r15+0x100], rax
00007cc2697d060b  jmp 0x00007CC2695FE110
00007cc2697d0610  int3
00007cc2697d0611  call 0x00007CC2696E2BA0
00007cc2697d0616  jmp 0x00007CC2697D050F
00007cc2697d061b  call 0x00007CC2696E1920
00007cc2697d0620  jmp 0x00007CC2697D0518
00007cc2697d0625  call 0x00007CC26960DFE0
00007cc2697d062a  jmp 0x00007CC2697D058F
00007cc2697d062f  call 0x00007CC2696E2BA0
00007cc2697d0634  jmp 0x00007CC2697D059D
00007cc2697d0639  call 0x00007CC2696E2BA0
00007cc2697d063e  jmp 0x00007CC2697D05AB
00007cc2697d0643  call 0x00007CC2696E2BA0
00007cc2697d0648  jmp 0x00007CC2697D05B9
00007cc2697d064d  call 0x00007CC2696E2BA0
00007cc2697d0652  jmp 0x00007CC2697D05C7
00007cc2697d0657  call 0x00007CC2696E2BA0
00007cc2697d065c  jmp 0x00007CC2697D05D5
00007cc2697d0661  call 0x00007CC2696D5EB0
00007cc2697d0666  jmp 0x00007CC2697D05E0
00007cc2697d066b  int3
00007cc2697d066c  nop [rax], eax
00007cc2697d0670  mov rax, [r15+0xF8]
00007cc2697d0677  lea r14, [rax+0x140]
00007cc2697d067e  mov r12, [r13+r14*1]
00007cc2697d0683  lea r14, [rax+0x148]
00007cc2697d068a  mov r11, [r13+r14*1]
00007cc2697d068f  mov [r15+0xA0], r12
00007cc2697d0696  mov [r15+0x98], r11
00007cc2697d069d  lea r14, [rax+0x130]
00007cc2697d06a4  mov r12, [r13+r14*1]
00007cc2697d06a9  lea r14, [rax+0x138]
00007cc2697d06b0  mov r11, [r13+r14*1]
00007cc2697d06b5  mov [r15+0xB0], r12
00007cc2697d06bc  mov [r15+0xA8], r11
00007cc2697d06c3  lea r14, [rax+0x120]
00007cc2697d06ca  mov r12, [r13+r14*1]
00007cc2697d06cf  lea r14, [rax+0x128]
00007cc2697d06d6  mov r11, [r13+r14*1]
00007cc2697d06db  mov [r15+0xC0], r12
00007cc2697d06e2  mov [r15+0xB8], r11
00007cc2697d06e9  lea r14, [rax+0x110]
00007cc2697d06f0  mov r12, [r13+r14*1]
00007cc2697d06f5  lea r14, [rax+0x118]
00007cc2697d06fc  mov r11, [r13+r14*1]
00007cc2697d0701  mov [r15+0xD0], r12
00007cc2697d0708  mov [r15+0xC8], r11
00007cc2697d070f  lea r14, [rax+0x100]
00007cc2697d0716  mov r12, [r13+r14*1]
00007cc2697d071b  lea r14, [rax+0x108]
00007cc2697d0722  mov r11, [r13+r14*1]
00007cc2697d0727  mov [r15+0xE8], r12
00007cc2697d072e  mov [r15+0xD8], r11
00007cc2697d0735  lea r14, [rax+0x150]
00007cc2697d073c  mov [r15+0xF8], r14
00007cc2697d0743  mov rax, [r15+0xF0]
00007cc2697d074a  mov [r15+0x100], rax
00007cc2697d0751  jmp 0x00007CC2697CE5C0
00007cc2697d0756  int3
00007cc2697d0757  call 0x00007CC2696E27E0
00007cc2697d075c  jmp 0x00007CC2697D0683
00007cc2697d0761  call 0x00007CC2696E1570
00007cc2697d0766  jmp 0x00007CC2697D068F
00007cc2697d076b  call 0x00007CC2696E27E0
00007cc2697d0770  jmp 0x00007CC2697D06A9
00007cc2697d0775  call 0x00007CC2696E1570
00007cc2697d077a  jmp 0x00007CC2697D06B5
00007cc2697d077f  call 0x00007CC2696E27E0
00007cc2697d0784  jmp 0x00007CC2697D06CF
00007cc2697d0789  call 0x00007CC2696E1570
00007cc2697d078e  jmp 0x00007CC2697D06DB
00007cc2697d0793  call 0x00007CC2696E27E0
00007cc2697d0798  jmp 0x00007CC2697D06F5
00007cc2697d079d  call 0x00007CC2696E1570
00007cc2697d07a2  jmp 0x00007CC2697D0701
00007cc2697d07a7  call 0x00007CC2696E27E0
00007cc2697d07ac  jmp 0x00007CC2697D071B
00007cc2697d07b1  call 0x00007CC2696E1570
00007cc2697d07b6  jmp 0x00007CC2697D0727
00007cc2697d07bb  int3
00007cc2697d07bc  nop [rax], eax
00007cc2697d07c0  mov eax, [r15+0xA0]
00007cc2697d07c7  mov [rsp+0x10], eax
00007cc2697d07cb  xor eax, eax
00007cc2697d07cd  mov r14d, [rsp+0x10]
00007cc2697d07d2  sub r14d, 0x01
00007cc2697d07d6  cmc
00007cc2697d07d7  lahf
00007cc2697d07d8  seto al
00007cc2697d07db  mov [r15+0x108], eax
00007cc2697d07e2  mov r14d, r14d
00007cc2697d07e5  mov [r15+0xA0], r14
00007cc2697d07ec  mov eax, [r15+0x108]
00007cc2697d07f3  sahf
00007cc2697d07f4  jnz 0x00007CC2697D0826
00007cc2697d07f6  cmp dword ptr [r15+0x318], 0x00
00007cc2697d07fe  jz 0x00007CC2697D0900
00007cc2697d0804  nop [rax+rax*1], ax
00007cc2697d080d  nop [rax+rax*1], eax
00007cc2697d0815  mov eax, 0x41028C
00007cc2697d081a  mov [r15+0x100], rax
00007cc2697d0821  jmp 0x00007CC2695FE110
00007cc2697d0826  cmp dword ptr [r15+0x318], 0x00
00007cc2697d082e  jz 0x00007CC2697D0860
00007cc2697d0834  nop [rax+rax*1], ax
00007cc2697d083d  nop [rax+rax*1], eax
00007cc2697d0845  mov eax, 0x410274
00007cc2697d084a  mov [r15+0x100], rax
00007cc2697d0851  jmp 0x00007CC2695FE110
00007cc2697d0856  int3
00007cc2697d0857  int3
00007cc2697d0858  nop [rax+rax*1], eax
00007cc2697d0860  mov rax, [r15+0xF8]
00007cc2697d0867  lea r14, [rax+0xD0]
00007cc2697d086e  mov [r15], r14
00007cc2697d0871  mov rax, [r15+0x98]
00007cc2697d0878  mov [r15+0x08], rax
00007cc2697d087c  mov qword ptr [r15+0x10], 0x12C
00007cc2697d0884  mov qword ptr [r15+0xF0], 0x410284
00007cc2697d088f  mov r14d, [r15+0x320]
00007cc2697d0896  mov eax, 0x410284
00007cc2697d089b  mov rcx, 0x7CC2697D07C0
00007cc2697d08a5  mov [r15+r14*8+0x328], rax
00007cc2697d08ad  mov [r15+r14*8+0x368], rcx
00007cc2697d08b5  add r14d, 0x01
00007cc2697d08b9  and r14d, 0x07
00007cc2697d08bd  mov [r15+0x320], r14d
00007cc2697d08c4  cmp dword ptr [r15+0x318], 0x00
00007cc2697d08cc  jz 0x00007CC2697CED70
00007cc2697d08d2  nop [rax+rax*1], ax
00007cc2697d08db  nop [rax+rax*1], eax
00007cc2697d08e3  mov eax, 0x4106BC
00007cc2697d08e8  mov [r15+0x100], rax
00007cc2697d08ef  jmp 0x00007CC2695FE110
00007cc2697d08f4  int3
00007cc2697d08f5  int3
00007cc2697d08f6  nop [rax+rax*1], ax
00007cc2697d08ff  nop
00007cc2697d0900  mov rax, [r15+0xF8]
00007cc2697d0907  lea r14, [rax+0xF0]
00007cc2697d090e  mov r12, [r13+r14*1]
00007cc2697d0913  mov [r15+0x98], r12
00007cc2697d091a  mov qword ptr [r15+0x40], 0x80
00007cc2697d0922  lea r14, [rax+0xD0]
00007cc2697d0929  mov [r15], r14
00007cc2697d092c  lea r14, [rax+0x14C]
00007cc2697d0933  mov [r15+0x08], r14
00007cc2697d0937  mov qword ptr [r15+0x10], 0x01
00007cc2697d093f  lea r14, [rax+0x14C]
00007cc2697d0946  mov eax, 0x80
00007cc2697d094b  mov [r13+r14*1], al
00007cc2697d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007cc2697d095b  mov r14d, [r15+0x320]
00007cc2697d0962  mov eax, 0x4102A8
00007cc2697d0967  mov rcx, 0x7CC2697D09E0
00007cc2697d0971  mov [r15+r14*8+0x328], rax
00007cc2697d0979  mov [r15+r14*8+0x368], rcx
00007cc2697d0981  add r14d, 0x01
00007cc2697d0985  and r14d, 0x07
00007cc2697d0989  mov [r15+0x320], r14d
00007cc2697d0990  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0998  jz 0x00007CC2697CED70
00007cc2697d099e  nop [rax+rax*1], ax
00007cc2697d09a7  nop [rax+rax*1], eax
00007cc2697d09af  mov eax, 0x4106BC
00007cc2697d09b4  mov [r15+0x100], rax
00007cc2697d09bb  jmp 0x00007CC2695FE110
00007cc2697d09c0  int3
00007cc2697d09c1  call 0x00007CC2696E27E0
00007cc2697d09c6  jmp 0x00007CC2697D0913
00007cc2697d09cb  call 0x00007CC2696D5AF0
00007cc2697d09d0  jmp 0x00007CC2697D0950
00007cc2697d09d5  int3
00007cc2697d09d6  nop [rax+rax*1], ax
00007cc2697d09df  nop
00007cc2697d09e0  mov rax, [r15+0xF8]
00007cc2697d09e7  lea r14, [rax+0x138]
00007cc2697d09ee  mov r12, [r13+r14*1]
00007cc2697d09f3  mov [r15+0x40], r12
00007cc2697d09f7  lea r14, [rax+0x148]
00007cc2697d09fe  xor eax, eax
00007cc2697d0a00  mov [r13+r14*1], al
00007cc2697d0a05  xor eax, eax
00007cc2697d0a07  mov r14d, 0x38
00007cc2697d0a0d  cmp r12, r14
00007cc2697d0a10  cmc
00007cc2697d0a11  lahf
00007cc2697d0a12  seto al
00007cc2697d0a15  mov [r15+0x108], eax
00007cc2697d0a1c  mov eax, [r15+0x108]
00007cc2697d0a23  sahf
00007cc2697d0a24  jz 0x00007CC2697D0A56
00007cc2697d0a26  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0a2e  jz 0x00007CC2697D0AA0
00007cc2697d0a34  nop [rax+rax*1], ax
00007cc2697d0a3d  nop [rax+rax*1], eax
00007cc2697d0a45  mov eax, 0x4102B8
00007cc2697d0a4a  mov [r15+0x100], rax
00007cc2697d0a51  jmp 0x00007CC2695FE110
00007cc2697d0a56  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0a5e  jz 0x00007CC2697D0BF0
00007cc2697d0a64  nop [rax+rax*1], ax
00007cc2697d0a6d  nop [rax+rax*1], eax
00007cc2697d0a75  mov eax, 0x4102D4
00007cc2697d0a7a  mov [r15+0x100], rax
00007cc2697d0a81  jmp 0x00007CC2695FE110
00007cc2697d0a86  int3
00007cc2697d0a87  call 0x00007CC2696E27E0
00007cc2697d0a8c  jmp 0x00007CC2697D09F3
00007cc2697d0a91  call 0x00007CC2696D5AF0
00007cc2697d0a96  jmp 0x00007CC2697D0A05
00007cc2697d0a9b  int3
00007cc2697d0a9c  nop [rax], eax
00007cc2697d0aa0  mov rax, [r15+0xF8]
00007cc2697d0aa7  lea r14, [rax+0xD0]
00007cc2697d0aae  mov [r15], r14
00007cc2697d0ab1  lea r14, [rax+0x148]
00007cc2697d0ab8  mov [r15+0x08], r14
00007cc2697d0abc  mov qword ptr [r15+0x10], 0x01
00007cc2697d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007cc2697d0acf  mov r14d, [r15+0x320]
00007cc2697d0ad6  mov eax, 0x4102C8
00007cc2697d0adb  mov rcx, 0x7CC2697D0B40
00007cc2697d0ae5  mov [r15+r14*8+0x328], rax
00007cc2697d0aed  mov [r15+r14*8+0x368], rcx
00007cc2697d0af5  add r14d, 0x01
00007cc2697d0af9  and r14d, 0x07
00007cc2697d0afd  mov [r15+0x320], r14d
00007cc2697d0b04  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0b0c  jz 0x00007CC2697CED70
00007cc2697d0b12  nop [rax+rax*1], ax
00007cc2697d0b1b  nop [rax+rax*1], eax
00007cc2697d0b23  mov eax, 0x4106BC
00007cc2697d0b28  mov [r15+0x100], rax
00007cc2697d0b2f  jmp 0x00007CC2695FE110
00007cc2697d0b34  int3
00007cc2697d0b35  int3
00007cc2697d0b36  nop [rax+rax*1], ax
00007cc2697d0b3f  nop
00007cc2697d0b40  mov rax, [r15+0xF8]
00007cc2697d0b47  lea r14, [rax+0x138]
00007cc2697d0b4e  mov rax, [r13+r14*1]
00007cc2697d0b53  mov [r15+0x40], rax
00007cc2697d0b57  mov [rsp+0x10], rax
00007cc2697d0b5c  xor eax, eax
00007cc2697d0b5e  mov r14, [rsp+0x10]
00007cc2697d0b63  mov r12d, 0x38
00007cc2697d0b69  cmp r14, r12
00007cc2697d0b6c  cmc
00007cc2697d0b6d  lahf
00007cc2697d0b6e  seto al
00007cc2697d0b71  mov [r15+0x108], eax
00007cc2697d0b78  mov eax, [r15+0x108]
00007cc2697d0b7f  sahf
00007cc2697d0b80  jnz 0x00007CC2697D0BB2
00007cc2697d0b82  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0b8a  jz 0x00007CC2697D0BF0
00007cc2697d0b90  nop [rax+rax*1], ax
00007cc2697d0b99  nop [rax+rax*1], eax
00007cc2697d0ba1  mov eax, 0x4102D4
00007cc2697d0ba6  mov [r15+0x100], rax
00007cc2697d0bad  jmp 0x00007CC2695FE110
00007cc2697d0bb2  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0bba  jz 0x00007CC2697D0AA0
00007cc2697d0bc0  nop [rax+rax*1], ax
00007cc2697d0bc9  nop [rax+rax*1], eax
00007cc2697d0bd1  mov eax, 0x4102B8
00007cc2697d0bd6  mov [r15+0x100], rax
00007cc2697d0bdd  jmp 0x00007CC2695FE110
00007cc2697d0be2  int3
00007cc2697d0be3  call 0x00007CC2696D59C0
00007cc2697d0be8  jmp 0x00007CC2697D0B53
00007cc2697d0bed  int3
00007cc2697d0bee  nop
00007cc2697d0bf0  mov rax, [r15+0x98]
00007cc2697d0bf7  rorx r14, rax, 0x3D
00007cc2697d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007cc2697d0c01  mov rax, [r15+0xF8]
00007cc2697d0c08  lea r12, [rax+0xD0]
00007cc2697d0c0f  mov [r15], r12
00007cc2697d0c12  lea r12, [rax+0x140]
00007cc2697d0c19  mov [r15+0x08], r12
00007cc2697d0c1d  mov qword ptr [r15+0x10], 0x08
00007cc2697d0c25  bswap r14
00007cc2697d0c28  mov [r15+0x40], r14
00007cc2697d0c2c  lea r12, [rax+0x140]
00007cc2697d0c33  mov [r13+r12*1], r14
00007cc2697d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007cc2697d0c43  mov r14d, [r15+0x320]
00007cc2697d0c4a  mov eax, 0x4102F0
00007cc2697d0c4f  mov rcx, 0x7CC2697D0CC0
00007cc2697d0c59  mov [r15+r14*8+0x328], rax
00007cc2697d0c61  mov [r15+r14*8+0x368], rcx
00007cc2697d0c69  add r14d, 0x01
00007cc2697d0c6d  and r14d, 0x07
00007cc2697d0c71  mov [r15+0x320], r14d
00007cc2697d0c78  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0c80  jz 0x00007CC2697CED70
00007cc2697d0c86  nop [rax+rax*1], ax
00007cc2697d0c8f  nop [rax+rax*1], eax
00007cc2697d0c97  mov eax, 0x4106BC
00007cc2697d0c9c  mov [r15+0x100], rax
00007cc2697d0ca3  jmp 0x00007CC2695FE110
00007cc2697d0ca8  int3
00007cc2697d0ca9  call 0x00007CC2696C3FE0
00007cc2697d0cae  jmp 0x00007CC2697D0C38
00007cc2697d0cb3  int3
00007cc2697d0cb4  nop [rax+rax*1], ax
00007cc2697d0cbd  nop [rax], eax
00007cc2697d0cc0  mov rax, [r15+0xF8]
00007cc2697d0cc7  lea r14, [rax+0xD0]
00007cc2697d0cce  mov r12d, [r13+r14*1]
00007cc2697d0cd3  lea r14, [rax+0xD4]
00007cc2697d0cda  mov r11d, [r13+r14*1]
00007cc2697d0cdf  lea r14, [rax+0xD8]
00007cc2697d0ce6  mov r10d, [r13+r14*1]
00007cc2697d0ceb  lea r14, [rax+0xDC]
00007cc2697d0cf2  mov r9d, [r13+r14*1]
00007cc2697d0cf7  mov qword ptr [r15+0x48], 0x430C20
00007cc2697d0cff  mov qword ptr [r15+0xA0], 0x00
00007cc2697d0d0a  bswap r12d
00007cc2697d0d0d  bswap r11d
00007cc2697d0d10  mov qword ptr [r15+0x98], 0x430D8C
00007cc2697d0d1b  mov r14d, 0x430C20
00007cc2697d0d21  mov [r13+r14*1], r12d
00007cc2697d0d26  mov r14d, 0x430C24
00007cc2697d0d2c  mov [r13+r14*1], r11d
00007cc2697d0d31  bswap r10d
00007cc2697d0d34  bswap r9d
00007cc2697d0d37  lea r14, [rax+0xE0]
00007cc2697d0d3e  mov r12d, [r13+r14*1]
00007cc2697d0d43  lea r14, [rax+0xE4]
00007cc2697d0d4a  mov r11d, [r13+r14*1]
00007cc2697d0d4f  mov r14d, 0x430C28
00007cc2697d0d55  mov [r13+r14*1], r10d
00007cc2697d0d5a  mov r14d, 0x430C2C
00007cc2697d0d60  mov [r13+r14*1], r9d
00007cc2697d0d65  bswap r12d
00007cc2697d0d68  bswap r11d
00007cc2697d0d6b  mov [rsp+0x10], r11d
00007cc2697d0d70  mov r11d, r11d
00007cc2697d0d73  mov [r15+0x58], r11
00007cc2697d0d77  lea r14, [rax+0xE8]
00007cc2697d0d7e  mov r11d, [r13+r14*1]
00007cc2697d0d83  lea r14, [rax+0xEC]
00007cc2697d0d8a  mov eax, [r13+r14*1]
00007cc2697d0d8f  mov [rsp+0x20], eax
00007cc2697d0d93  mov eax, eax
00007cc2697d0d95  mov [r15+0x60], rax
00007cc2697d0d99  mov eax, 0x430C30
00007cc2697d0d9e  mov [r13+rax*1], r12d
00007cc2697d0da3  mov eax, 0x430C34
00007cc2697d0da8  mov r14d, [rsp+0x10]
00007cc2697d0dad  mov [r13+rax*1], r14d
00007cc2697d0db2  bswap r11d
00007cc2697d0db5  mov [rsp+0x10], r11d
00007cc2697d0dba  mov r11d, r11d
00007cc2697d0dbd  mov [r15+0x40], r11
00007cc2697d0dc1  mov eax, [rsp+0x20]
00007cc2697d0dc5  bswap eax
00007cc2697d0dc7  mov [rsp+0x20], eax
00007cc2697d0dcb  mov eax, eax
00007cc2697d0dcd  mov [r15+0x50], rax
00007cc2697d0dd1  mov eax, 0x430C38
00007cc2697d0dd6  mov r14d, [rsp+0x10]
00007cc2697d0ddb  mov [r13+rax*1], r14d
00007cc2697d0de0  mov eax, 0x430C3C
00007cc2697d0de5  mov r14d, [rsp+0x20]
00007cc2697d0dea  mov [r13+rax*1], r14d
00007cc2697d0def  mov eax, [r15+0xA0]
00007cc2697d0df6  lea r14d, [eax+0x11]
00007cc2697d0dfb  mov r14d, r14d
00007cc2697d0dfe  mov [r15], r14
00007cc2697d0e01  mov qword ptr [r15+0xF0], 0x41034C
00007cc2697d0e0c  mov r14d, [r15+0x320]
00007cc2697d0e13  mov eax, 0x41034C
00007cc2697d0e18  mov rcx, 0x7CC2697D0F90
00007cc2697d0e22  mov [r15+r14*8+0x328], rax
00007cc2697d0e2a  mov [r15+r14*8+0x368], rcx
00007cc2697d0e32  add r14d, 0x01
00007cc2697d0e36  and r14d, 0x07
00007cc2697d0e3a  mov [r15+0x320], r14d
00007cc2697d0e41  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0e49  jz 0x00007CC2697D0F20
00007cc2697d0e4f  nop [rax+rax*1], ax
00007cc2697d0e58  nop [rax+rax*1], eax
00007cc2697d0e60  mov eax, 0x410938
00007cc2697d0e65  mov [r15+0x100], rax
00007cc2697d0e6c  jmp 0x00007CC2695FE110
00007cc2697d0e71  int3
00007cc2697d0e72  call 0x00007CC2696E26A0
00007cc2697d0e77  jmp 0x00007CC2697D0CD3
00007cc2697d0e7c  call 0x00007CC2696E1430
00007cc2697d0e81  jmp 0x00007CC2697D0CDF
00007cc2697d0e86  call 0x00007CC2696E01C0
00007cc2697d0e8b  jmp 0x00007CC2697D0CEB
00007cc2697d0e90  call 0x00007CC2696DEF50
00007cc2697d0e95  jmp 0x00007CC2697D0CF7
00007cc2697d0e9a  call 0x00007CC2696E2BA0
00007cc2697d0e9f  jmp 0x00007CC2697D0D26
00007cc2697d0ea4  call 0x00007CC2696E1920
00007cc2697d0ea9  jmp 0x00007CC2697D0D31
00007cc2697d0eae  call 0x00007CC2696E26A0
00007cc2697d0eb3  jmp 0x00007CC2697D0D43
00007cc2697d0eb8  call 0x00007CC2696E1430
00007cc2697d0ebd  jmp 0x00007CC2697D0D4F
00007cc2697d0ec2  call 0x00007CC2696E06B0
00007cc2697d0ec7  jmp 0x00007CC2697D0D5A
00007cc2697d0ecc  call 0x00007CC2696DF440
00007cc2697d0ed1  jmp 0x00007CC2697D0D65
00007cc2697d0ed6  call 0x00007CC2696E1430
00007cc2697d0edb  jmp 0x00007CC2697D0D83
00007cc2697d0ee0  call 0x00007CC2696D5890
00007cc2697d0ee5  jmp 0x00007CC2697D0D8F
00007cc2697d0eea  call 0x00007CC26960BAE0
00007cc2697d0eef  jmp 0x00007CC2697D0DA3
00007cc2697d0ef4  call 0x00007CC26960DFE0
00007cc2697d0ef9  jmp 0x00007CC2697D0DB2
00007cc2697d0efe  call 0x00007CC26960DFE0
00007cc2697d0f03  jmp 0x00007CC2697D0DE0
00007cc2697d0f08  call 0x00007CC26960DFE0
00007cc2697d0f0d  jmp 0x00007CC2697D0DEF
00007cc2697d0f12  int3
00007cc2697d0f13  nop [rax+rax*1], ax
00007cc2697d0f1c  nop [rax], eax
00007cc2697d0f20  mov eax, [r15]
00007cc2697d0f23  mov [rsp+0x10], eax
00007cc2697d0f27  shr eax, 0x10
00007cc2697d0f2a  mov r14d, [rsp+0x10]
00007cc2697d0f2f  xor r14d, eax
00007cc2697d0f32  imul r14d, r14d, 0x7FEB352D
00007cc2697d0f39  mov eax, 0x846CA68B
00007cc2697d0f3e  mov eax, eax
00007cc2697d0f40  mov [r15+0x48], rax
00007cc2697d0f44  mov [rsp+0x10], r14d
00007cc2697d0f49  shr r14d, 0x0F
00007cc2697d0f4d  mov eax, [rsp+0x10]
00007cc2697d0f51  xor eax, r14d
00007cc2697d0f54  imul eax, eax, 0x846CA68B
00007cc2697d0f5a  mov [rsp+0x10], eax
00007cc2697d0f5e  mov eax, eax
00007cc2697d0f60  mov [r15+0x40], rax
00007cc2697d0f64  mov eax, [rsp+0x10]
00007cc2697d0f68  shr eax, 0x10
00007cc2697d0f6b  mov r14d, [rsp+0x10]
00007cc2697d0f70  xor r14d, eax
00007cc2697d0f73  mov r14d, r14d
00007cc2697d0f76  mov [r15], r14
00007cc2697d0f79  mov rax, [r15+0xF0]
00007cc2697d0f80  mov [r15+0x100], rax
00007cc2697d0f87  jmp 0x00007CC2697CE5C0
00007cc2697d0f8c  int3
00007cc2697d0f8d  int3
00007cc2697d0f8e  nop
00007cc2697d0f90  mov rax, [r15+0xA0]
00007cc2697d0f97  mov [rsp+0x10], rax
00007cc2697d0f9c  shl rax, 0x02
00007cc2697d0fa0  mov r14, [r15+0x98]
00007cc2697d0fa7  lea r12, [r14+rax*1]
00007cc2697d0fab  mov eax, [r15]
00007cc2697d0fae  mov [r13+r12*1], eax
00007cc2697d0fb3  mov rax, [rsp+0x10]
00007cc2697d0fb8  lea r14, [rax+0x01]
00007cc2697d0fbc  mov [r15+0xA0], r14
00007cc2697d0fc3  xor eax, eax
00007cc2697d0fc5  mov r12d, 0x400
00007cc2697d0fcb  cmp r14, r12
00007cc2697d0fce  cmc
00007cc2697d0fcf  lahf
00007cc2697d0fd0  seto al
00007cc2697d0fd3  mov [r15+0x108], eax
00007cc2697d0fda  mov eax, [r15+0x108]
00007cc2697d0fe1  sahf
00007cc2697d0fe2  jnz 0x00007CC2697D1014
00007cc2697d0fe4  cmp dword ptr [r15+0x318], 0x00
00007cc2697d0fec  jz 0x00007CC2697D10E0
00007cc2697d0ff2  nop [rax+rax*1], ax
00007cc2697d0ffb  nop [rax+rax*1], eax
00007cc2697d1003  mov eax, 0x41035C
00007cc2697d1008  mov [r15+0x100], rax
00007cc2697d100f  jmp 0x00007CC2695FE110
00007cc2697d1014  cmp dword ptr [r15+0x318], 0x00
00007cc2697d101c  jz 0x00007CC2697D1050
00007cc2697d1022  nop [rax+rax*1], ax
00007cc2697d102b  nop [rax+rax*1], eax
00007cc2697d1033  mov eax, 0x410344
00007cc2697d1038  mov [r15+0x100], rax
00007cc2697d103f  jmp 0x00007CC2695FE110
00007cc2697d1044  int3
00007cc2697d1045  call 0x00007CC2696B4B70
00007cc2697d104a  jmp 0x00007CC2697D0FB3
00007cc2697d104f  int3
00007cc2697d1050  mov eax, [r15+0xA0]
00007cc2697d1057  lea r14d, [eax+0x11]
00007cc2697d105c  mov r14d, r14d
00007cc2697d105f  mov [r15], r14
00007cc2697d1062  mov qword ptr [r15+0xF0], 0x41034C
00007cc2697d106d  mov r14d, [r15+0x320]
00007cc2697d1074  mov eax, 0x41034C
00007cc2697d1079  mov rcx, 0x7CC2697D0F90
00007cc2697d1083  mov [r15+r14*8+0x328], rax
00007cc2697d108b  mov [r15+r14*8+0x368], rcx
00007cc2697d1093  add r14d, 0x01
00007cc2697d1097  and r14d, 0x07
00007cc2697d109b  mov [r15+0x320], r14d
00007cc2697d10a2  cmp dword ptr [r15+0x318], 0x00
00007cc2697d10aa  jz 0x00007CC2697D0F20
00007cc2697d10b0  nop [rax+rax*1], ax
00007cc2697d10b9  nop [rax+rax*1], eax
00007cc2697d10c1  mov eax, 0x410938
00007cc2697d10c6  mov [r15+0x100], rax
00007cc2697d10cd  jmp 0x00007CC2695FE110
00007cc2697d10d2  int3
00007cc2697d10d3  int3
00007cc2697d10d4  nop [rax+rax*1], ax
00007cc2697d10dd  nop [rax], eax
00007cc2697d10e0  mov qword ptr [r15+0x40], 0x01
00007cc2697d10e8  cmp dword ptr [r15+0x318], 0x00
00007cc2697d10f0  jz 0x00007CC2697D1120
00007cc2697d10f6  nop [rax+rax*1], ax
00007cc2697d10ff  nop [rax+rax*1], eax
00007cc2697d1107  mov eax, 0x410378
00007cc2697d110c  mov [r15+0x100], rax
00007cc2697d1113  jmp 0x00007CC2695FE110
00007cc2697d1118  int3
00007cc2697d1119  int3
00007cc2697d111a  nop [rax+rax*1], ax
00007cc2697d1120  mov rax, [r15+0x40]
00007cc2697d1124  mov [rsp+0x10], rax
00007cc2697d1129  shl rax, 0x02
00007cc2697d112d  mov r14, [r15+0x98]
00007cc2697d1134  lea r12, [r14+rax*1]
00007cc2697d1138  mov eax, [r13+r12*1]
00007cc2697d113d  mov [rsp+0x20], eax
00007cc2697d1141  mov eax, eax
00007cc2697d1143  mov [r15+0x48], rax
00007cc2697d1147  mov rax, [rsp+0x10]
00007cc2697d114c  mov [r15+0x50], rax
00007cc2697d1150  mov eax, [r15+0x50]
00007cc2697d1154  lea r12d, [eax-0x01]
00007cc2697d1159  mov r12d, r12d
00007cc2697d115c  mov [r15+0x58], r12
00007cc2697d1160  mov rax, [r15+0x58]
00007cc2697d1164  mov r12d, eax
00007cc2697d1167  mov r12d, r12d
00007cc2697d116a  shl r12, 0x02
00007cc2697d116e  lea rax, [r14+r12*1]
00007cc2697d1172  mov r14d, [r13+rax*1]
00007cc2697d1177  mov [rsp+0x10], r14d
00007cc2697d117c  mov r14d, r14d
00007cc2697d117f  mov [r15+0x60], r14
00007cc2697d1183  xor eax, eax
00007cc2697d1185  mov r14d, [rsp+0x10]
00007cc2697d118a  mov r12d, [rsp+0x20]
00007cc2697d118f  cmp r14d, r12d
00007cc2697d1192  cmc
00007cc2697d1193  lahf
00007cc2697d1194  seto al
00007cc2697d1197  mov [r15+0x108], eax
00007cc2697d119e  mov eax, [r15+0x108]
00007cc2697d11a5  sahf
00007cc2697d11a6  cmc
00007cc2697d11a7  jbe 0x00007CC2697D11D9
00007cc2697d11a9  cmp dword ptr [r15+0x318], 0x00
00007cc2697d11b1  jz 0x00007CC2697D1220
00007cc2697d11b7  nop [rax+rax*1], ax
00007cc2697d11c0  nop [rax+rax*1], eax
00007cc2697d11c8  mov eax, 0x410390
00007cc2697d11cd  mov [r15+0x100], rax
00007cc2697d11d4  jmp 0x00007CC2695FE110
00007cc2697d11d9  cmp dword ptr [r15+0x318], 0x00
00007cc2697d11e1  jz 0x00007CC2697D14C0
00007cc2697d11e7  nop [rax+rax*1], ax
00007cc2697d11f0  nop [rax+rax*1], eax
00007cc2697d11f8  mov eax, 0x410368
00007cc2697d11fd  mov [r15+0x100], rax
00007cc2697d1204  jmp 0x00007CC2695FE110
00007cc2697d1209  int3
00007cc2697d120a  call 0x00007CC2696B4690
00007cc2697d120f  jmp 0x00007CC2697D113D
00007cc2697d1214  call 0x00007CC26960DAE0
00007cc2697d1219  jmp 0x00007CC2697D1177
00007cc2697d121e  int3
00007cc2697d121f  nop
00007cc2697d1220  mov rax, [r15+0x50]
00007cc2697d1224  mov [rsp+0x10], rax
00007cc2697d1229  shl rax, 0x02
00007cc2697d122d  mov r14, [r15+0x98]
00007cc2697d1234  lea r12, [r14+rax*1]
00007cc2697d1238  mov eax, [r15+0x60]
00007cc2697d123c  mov [r13+r12*1], eax
00007cc2697d1241  mov rax, [rsp+0x10]
00007cc2697d1246  lea r14, [rax-0x01]
00007cc2697d124a  mov [r15+0x50], r14
00007cc2697d124e  mov rax, [r15+0x58]
00007cc2697d1252  test rax, rax
00007cc2697d1255  setz al
00007cc2697d1258  movzx rax, al
00007cc2697d125c  mov [rsp+0x414], al
00007cc2697d1263  cmp byte ptr [rsp+0x414], 0x00
00007cc2697d126b  jz 0x00007CC2697D129D
00007cc2697d126d  cmp dword ptr [r15+0x318], 0x00
00007cc2697d1275  jz 0x00007CC2697D12E0
00007cc2697d127b  nop [rax+rax*1], ax
00007cc2697d1284  nop [rax+rax*1], eax
00007cc2697d128c  mov eax, 0x41039C
00007cc2697d1291  mov [r15+0x100], rax
00007cc2697d1298  jmp 0x00007CC2695FE110
00007cc2697d129d  cmp dword ptr [r15+0x318], 0x00
00007cc2697d12a5  jz 0x00007CC2697D13E0
00007cc2697d12ab  nop [rax+rax*1], ax
00007cc2697d12b4  nop [rax+rax*1], eax
00007cc2697d12bc  mov eax, 0x410380
00007cc2697d12c1  mov [r15+0x100], rax
00007cc2697d12c8  jmp 0x00007CC2695FE110
00007cc2697d12cd  int3
00007cc2697d12ce  call 0x00007CC2696B4B70
00007cc2697d12d3  jmp 0x00007CC2697D1241
00007cc2697d12d8  int3
00007cc2697d12d9  nop [rax], eax
00007cc2697d12e0  cmp dword ptr [r15+0x318], 0x00
00007cc2697d12e8  jz 0x00007CC2697D1320
00007cc2697d12ee  nop [rax+rax*1], ax
00007cc2697d12f7  nop [rax+rax*1], eax
00007cc2697d12ff  mov eax, 0x410364
00007cc2697d1304  mov [r15+0x100], rax
00007cc2697d130b  jmp 0x00007CC2695FE110
00007cc2697d1310  int3
00007cc2697d1311  int3
00007cc2697d1312  nop [rax+rax*1], ax
00007cc2697d131b  nop [rax+rax*1], eax
00007cc2697d1320  mov qword ptr [r15+0x50], 0x00
00007cc2697d1328  mov rax, [r15+0x40]
00007cc2697d132c  lea r14, [rax+0x01]
00007cc2697d1330  mov [r15+0x40], r14
00007cc2697d1334  mov rax, [r15+0x98]
00007cc2697d133b  mov r12d, [r15+0x48]
00007cc2697d133f  mov [r13+rax*1], r12d
00007cc2697d1344  xor eax, eax
00007cc2697d1346  mov r12d, 0x400
00007cc2697d134c  cmp r14, r12
00007cc2697d134f  cmc
00007cc2697d1350  lahf
00007cc2697d1351  seto al
00007cc2697d1354  mov [r15+0x108], eax
00007cc2697d135b  mov eax, [r15+0x108]
00007cc2697d1362  sahf
00007cc2697d1363  jz 0x00007CC2697D1395
00007cc2697d1365  cmp dword ptr [r15+0x318], 0x00
00007cc2697d136d  jz 0x00007CC2697D1120
00007cc2697d1373  nop [rax+rax*1], ax
00007cc2697d137c  nop [rax+rax*1], eax
00007cc2697d1384  mov eax, 0x410378
00007cc2697d1389  mov [r15+0x100], rax
00007cc2697d1390  jmp 0x00007CC2695FE110
00007cc2697d1395  cmp dword ptr [r15+0x318], 0x00
00007cc2697d139d  jz 0x00007CC2697D1580
00007cc2697d13a3  nop [rax+rax*1], ax
00007cc2697d13ac  nop [rax+rax*1], eax
00007cc2697d13b4  mov eax, 0x4103A0
00007cc2697d13b9  mov [r15+0x100], rax
00007cc2697d13c0  jmp 0x00007CC2695FE110
00007cc2697d13c5  int3
00007cc2697d13c6  call 0x00007CC26960BAE0
00007cc2697d13cb  jmp 0x00007CC2697D1344
00007cc2697d13d0  int3
00007cc2697d13d1  nop [rax+rax*1], ax
00007cc2697d13da  nop [rax+rax*1], ax
00007cc2697d13e0  mov eax, [r15+0x50]
00007cc2697d13e4  lea r14d, [eax-0x01]
00007cc2697d13e9  mov r14d, r14d
00007cc2697d13ec  mov [r15+0x58], r14
00007cc2697d13f0  mov rax, [r15+0x58]
00007cc2697d13f4  mov r14d, eax
00007cc2697d13f7  mov r14d, r14d
00007cc2697d13fa  shl r14, 0x02
00007cc2697d13fe  mov rax, [r15+0x98]
00007cc2697d1405  lea r12, [rax+r14*1]
00007cc2697d1409  mov eax, [r13+r12*1]
00007cc2697d140e  mov [rsp+0x10], eax
00007cc2697d1412  mov eax, eax
00007cc2697d1414  mov [r15+0x60], rax
00007cc2697d1418  mov eax, [r15+0x48]
00007cc2697d141c  mov [rsp+0x20], eax
00007cc2697d1420  xor eax, eax
00007cc2697d1422  mov r14d, [rsp+0x10]
00007cc2697d1427  mov r12d, [rsp+0x20]
00007cc2697d142c  cmp r14d, r12d
00007cc2697d142f  cmc
00007cc2697d1430  lahf
00007cc2697d1431  seto al
00007cc2697d1434  mov [r15+0x108], eax
00007cc2697d143b  mov eax, [r15+0x108]
00007cc2697d1442  sahf
00007cc2697d1443  cmc
00007cc2697d1444  jbe 0x00007CC2697D1476
00007cc2697d1446  cmp dword ptr [r15+0x318], 0x00
00007cc2697d144e  jz 0x00007CC2697D1220
00007cc2697d1454  nop [rax+rax*1], ax
00007cc2697d145d  nop [rax+rax*1], eax
00007cc2697d1465  mov eax, 0x410390
00007cc2697d146a  mov [r15+0x100], rax
00007cc2697d1471  jmp 0x00007CC2695FE110
00007cc2697d1476  cmp dword ptr [r15+0x318], 0x00
00007cc2697d147e  jz 0x00007CC2697D14C0
00007cc2697d1484  nop [rax+rax*1], ax
00007cc2697d148d  nop [rax+rax*1], eax
00007cc2697d1495  mov eax, 0x410368
00007cc2697d149a  mov [r15+0x100], rax
00007cc2697d14a1  jmp 0x00007CC2695FE110
00007cc2697d14a6  int3
00007cc2697d14a7  call 0x00007CC2696B4690
00007cc2697d14ac  jmp 0x00007CC2697D140E
00007cc2697d14b1  int3
00007cc2697d14b2  nop [rax+rax*1], ax
00007cc2697d14bb  nop [rax+rax*1], eax
00007cc2697d14c0  mov rax, [r15+0x40]
00007cc2697d14c4  lea r14, [rax+0x01]
00007cc2697d14c8  mov [r15+0x40], r14
00007cc2697d14cc  mov rax, [r15+0x50]
00007cc2697d14d0  mov r12d, eax
00007cc2697d14d3  mov r12d, r12d
00007cc2697d14d6  shl r12, 0x02
00007cc2697d14da  mov rax, [r15+0x98]
00007cc2697d14e1  lea r11, [rax+r12*1]
00007cc2697d14e5  mov eax, [r15+0x48]
00007cc2697d14e9  mov [r13+r11*1], eax
00007cc2697d14ee  xor eax, eax
00007cc2697d14f0  mov r12d, 0x400
00007cc2697d14f6  cmp r14, r12
00007cc2697d14f9  cmc
00007cc2697d14fa  lahf
00007cc2697d14fb  seto al
00007cc2697d14fe  mov [r15+0x108], eax
00007cc2697d1505  mov eax, [r15+0x108]
00007cc2697d150c  sahf
00007cc2697d150d  jz 0x00007CC2697D153F
00007cc2697d150f  cmp dword ptr [r15+0x318], 0x00
00007cc2697d1517  jz 0x00007CC2697D1120
00007cc2697d151d  nop [rax+rax*1], ax
00007cc2697d1526  nop [rax+rax*1], eax
00007cc2697d152e  mov eax, 0x410378
00007cc2697d1533  mov [r15+0x100], rax
00007cc2697d153a  jmp 0x00007CC2695FE110
00007cc2697d153f  cmp dword ptr [r15+0x318], 0x00
00007cc2697d1547  jz 0x00007CC2697D1580
00007cc2697d154d  nop [rax+rax*1], ax
00007cc2697d1556  nop [rax+rax*1], eax
00007cc2697d155e  mov eax, 0x4103A0
00007cc2697d1563  mov [r15+0x100], rax
00007cc2697d156a  jmp 0x00007CC2695FE110
00007cc2697d156f  int3
00007cc2697d1570  call 0x00007CC2696A4270
00007cc2697d1575  jmp 0x00007CC2697D14EE
00007cc2697d157a  int3
00007cc2697d157b  nop [rax+rax*1], eax
00007cc2697d1580  mov qword ptr [r15+0x40], 0x430000
00007cc2697d1588  mov eax, 0x430C40
00007cc2697d158d  mov r14, [r13+rax*1]
00007cc2697d1592  mov rax, [r15+0x98]
00007cc2697d1599  mov r12d, [r13+rax*1]
00007cc2697d159e  lea r11, [rax+0x04]
00007cc2697d15a2  mov eax, [r13+r11*1]
00007cc2697d15a7  mov r12d, r12d
00007cc2697d15aa  mov [r15+0x68], r12
00007cc2697d15ae  mov eax, eax
00007cc2697d15b0  mov [r15+0x60], rax
00007cc2697d15b4  mov rax, [r15+0x68]
00007cc2697d15b8  mov [r15+0x68], rax
00007cc2697d15bc  mov qword ptr [r15+0x58], 0x02
00007cc2697d15c4  mov [rsp+0x10], rax
00007cc2697d15c9  xor eax, eax
00007cc2697d15cb  mov r12d, 0x02
00007cc2697d15d1  mov r11d, 0x400
00007cc2697d15d7  cmp r12, r11
00007cc2697d15da  cmc
00007cc2697d15db  lahf
00007cc2697d15dc  seto al
00007cc2697d15df  mov [r15+0x108], eax
00007cc2697d15e6  mov rax, [r15+0x60]
00007cc2697d15ea  mov r12d, 0x02
00007cc2697d15f0  imul rax, r12
00007cc2697d15f4  mov [r15+0x50], rax
00007cc2697d15f8  mov rax, [rsp+0x10]
00007cc2697d15fd  lea r12, [rax+r14*1]
00007cc2697d1601  mov [r15+0x48], r12
00007cc2697d1605  mov eax, [r15+0x108]
00007cc2697d160c  sahf
00007cc2697d160d  jnz 0x00007CC2697D163F
00007cc2697d160f  cmp dword ptr [r15+0x318], 0x00
00007cc2697d1617  jz 0x00007CC2697D17B0
00007cc2697d161d  nop [rax+rax*1], ax
00007cc2697d1626  nop [rax+rax*1], eax
00007cc2697d162e  mov eax, 0x4103D0
00007cc2697d1633  mov [r15+0x100], rax
00007cc2697d163a  jmp 0x00007CC2695FE110
00007cc2697d163f  cmp dword ptr [r15+0x318], 0x00
00007cc2697d1647  jz 0x00007CC2697D1690
00007cc2697d164d  nop [rax+rax*1], ax
00007cc2697d1656  nop [rax+rax*1], eax
00007cc2697d165e  mov eax, 0x4103B0
00007cc2697d1663  mov [r15+0x100], rax
00007cc2697d166a  jmp 0x00007CC2695FE110
00007cc2697d166f  int3
00007cc2697d1670  call 0x00007CC26960DC20
00007cc2697d1675  jmp 0x00007CC2697D1592
00007cc2697d167a  call 0x00007CC26960B5E0
00007cc2697d167f  jmp 0x00007CC2697D159E
00007cc2697d1684  call 0x00007CC2696A3D90
00007cc2697d1689  jmp 0x00007CC2697D15A7
00007cc2697d168e  int3
00007cc2697d168f  nop
00007cc2697d1690  mov rax, [r15+0x98]
00007cc2697d1697  mov r14, [r15+0x58]
00007cc2697d169b  mov [rsp+0x10], r14
00007cc2697d16a0  shl r14, 0x02
00007cc2697d16a4  lea r12, [rax+r14*1]
00007cc2697d16a8  mov eax, [r13+r12*1]
00007cc2697d16ad  lea r14, [r12+0x04]
00007cc2697d16b2  mov r12d, [r13+r14*1]
00007cc2697d16b7  mov eax, eax
00007cc2697d16b9  mov [r15+0x68], rax
00007cc2697d16bd  mov r12d, r12d
00007cc2697d16c0  mov [r15+0x60], r12
00007cc2697d16c4  mov rax, [r15+0x68]
00007cc2697d16c8  mov [rsp+0x20], rax
00007cc2697d16cd  mov r14, [rsp+0x10]
00007cc2697d16d2  imul rax, r14
00007cc2697d16d6  mov r12, [rsp+0x20]
00007cc2697d16db  lea r11, [r12+rax*1]
00007cc2697d16df  mov [r15+0x68], r11
00007cc2697d16e3  lea rax, [r14+0x02]
00007cc2697d16e7  mov [r15+0x58], rax
00007cc2697d16eb  mov [rsp+0x10], rax
00007cc2697d16f0  xor eax, eax
00007cc2697d16f2  mov r14, [rsp+0x10]
00007cc2697d16f7  mov r12d, 0x400
00007cc2697d16fd  cmp r14, r12
00007cc2697d1700  cmc
00007cc2697d1701  lahf
00007cc2697d1702  seto al
00007cc2697d1705  mov [r15+0x108], eax
00007cc2697d170c  mov rax, [r15+0x50]
00007cc2697d1710  mov r12, [r15+0x60]
00007cc2697d1714  imul r14, r12
00007cc2697d1718  lea r12, [rax+r14*1]
00007cc2697d171c  mov [r15+0x50], r12
00007cc2697d1720  mov rax, [r15+0x48]
00007cc2697d1724  lea r14, [r11+rax*1]
00007cc2697d1728  mov [r15+0x48], r14
00007cc2697d172c  mov eax, [r15+0x108]
00007cc2697d1733  sahf
00007cc2697d1734  jnz 0x00007CC2697D1766
00007cc2697d1736  cmp dword ptr [r15+0x318], 0x00
00007cc2697d173e  jz 0x00007CC2697D17B0
00007cc2697d1744  nop [rax+rax*1], ax
00007cc2697d174d  nop [rax+rax*1], eax
00007cc2697d1755  mov eax, 0x4103D0
00007cc2697d175a  mov [r15+0x100], rax
00007cc2697d1761  jmp 0x00007CC2695FE110
00007cc2697d1766  cmp dword ptr [r15+0x318], 0x00
00007cc2697d176e  jz 0x00007CC2697D1690
00007cc2697d1774  nop [rax+rax*1], ax
00007cc2697d177d  nop [rax+rax*1], eax
00007cc2697d1785  mov eax, 0x4103B0
00007cc2697d178a  mov [r15+0x100], rax
00007cc2697d1791  jmp 0x00007CC2695FE110
00007cc2697d1796  int3
00007cc2697d1797  call 0x00007CC2696B4690
00007cc2697d179c  jmp 0x00007CC2697D16AD
00007cc2697d17a1  call 0x00007CC2696E26A0
00007cc2697d17a6  jmp 0x00007CC2697D16B7
00007cc2697d17ab  int3
00007cc2697d17ac  nop [rax], eax
00007cc2697d17b0  mov qword ptr [r15+0x98], 0x00
00007cc2697d17bb  mov rax, [r15+0x50]
00007cc2697d17bf  mov r14, [r15+0x48]
00007cc2697d17c3  lea r12, [rax+r14*1]
00007cc2697d17c7  mov [r15+0x48], r12
00007cc2697d17cb  mov rax, [r15+0x40]
00007cc2697d17cf  lea r14, [rax+0xC40]
00007cc2697d17d6  mov [r13+r14*1], r12
00007cc2697d17db  mov qword ptr [r15], 0x01
00007cc2697d17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007cc2697d17ed  mov r14d, [r15+0x320]
00007cc2697d17f4  mov eax, 0x4103E8
00007cc2697d17f9  mov rcx, 0x7CC2697D1860
00007cc2697d1803  mov [r15+r14*8+0x328], rax
00007cc2697d180b  mov [r15+r14*8+0x368], rcx
00007cc2697d1813  add r14d, 0x01
00007cc2697d1817  and r14d, 0x07
00007cc2697d181b  mov [r15+0x320], r14d
00007cc2697d1822  cmp dword ptr [r15+0x318], 0x00
00007cc2697d182a  jz 0x00007CC2697D0F20
00007cc2697d1830  nop [rax+rax*1], ax
00007cc2697d1839  nop [rax+rax*1], eax
00007cc2697d1841  mov eax, 0x410938
00007cc2697d1846  mov [r15+0x100], rax
00007cc2697d184d  jmp 0x00007CC2695FE110
00007cc2697d1852  int3
00007cc2697d1853  call 0x00007CC2696E2CE0
00007cc2697d1858  jmp 0x00007CC2697D17DB
00007cc2697d185d  int3
00007cc2697d185e  nop
00007cc2697d1860  mov eax, [r15+0x98]
00007cc2697d1867  lea r14d, [eax+0x01]
00007cc2697d186c  mov [rsp+0x10], r14d
00007cc2697d1871  mov r14d, r14d
00007cc2697d1874  mov [r15+0x98], r14
00007cc2697d187b  xor eax, eax
00007cc2697d187d  mov r14d, [rsp+0x10]
00007cc2697d1882  cmp r14d, 0x10000
00007cc2697d1889  cmc
00007cc2697d188a  lahf
00007cc2697d188b  seto al
00007cc2697d188e  mov [r15+0x108], eax
00007cc2697d1895  mov eax, [r15+0x108]
00007cc2697d189c  sahf
00007cc2697d189d  jnz 0x00007CC2697D18CF
00007cc2697d189f  cmp dword ptr [r15+0x318], 0x00
00007cc2697d18a7  jz 0x00007CC2697D19A0
00007cc2697d18ad  nop [rax+rax*1], ax
00007cc2697d18b6  nop [rax+rax*1], eax
00007cc2697d18be  mov eax, 0x4103F4
00007cc2697d18c3  mov [r15+0x100], rax
00007cc2697d18ca  jmp 0x00007CC2695FE110
00007cc2697d18cf  cmp dword ptr [r15+0x318], 0x00
00007cc2697d18d7  jz 0x00007CC2697D1910
00007cc2697d18dd  nop [rax+rax*1], ax
00007cc2697d18e6  nop [rax+rax*1], eax
00007cc2697d18ee  mov eax, 0x4103E0
00007cc2697d18f3  mov [r15+0x100], rax
00007cc2697d18fa  jmp 0x00007CC2695FE110
00007cc2697d18ff  int3
00007cc2697d1900  int3
00007cc2697d1901  nop [rax+rax*1], ax
00007cc2697d190a  nop [rax+rax*1], ax
00007cc2697d1910  mov eax, [r15]
00007cc2697d1913  mov r14d, [r15+0x98]
00007cc2697d191a  lea r12d, [eax+r14d*1]
00007cc2697d191f  mov r12d, r12d
00007cc2697d1922  mov [r15], r12
00007cc2697d1925  mov qword ptr [r15+0xF0], 0x4103E8
00007cc2697d1930  mov r14d, [r15+0x320]
00007cc2697d1937  mov eax, 0x4103E8
00007cc2697d193c  mov rcx, 0x7CC2697D1860
00007cc2697d1946  mov [r15+r14*8+0x328], rax
00007cc2697d194e  mov [r15+r14*8+0x368], rcx
00007cc2697d1956  add r14d, 0x01
00007cc2697d195a  and r14d, 0x07
00007cc2697d195e  mov [r15+0x320], r14d
00007cc2697d1965  cmp dword ptr [r15+0x318], 0x00
00007cc2697d196d  jz 0x00007CC2697D0F20
00007cc2697d1973  nop [rax+rax*1], ax
00007cc2697d197c  nop [rax+rax*1], eax
00007cc2697d1984  mov eax, 0x410938
00007cc2697d1989  mov [r15+0x100], rax
00007cc2697d1990  jmp 0x00007CC2695FE110
00007cc2697d1995  int3
00007cc2697d1996  int3
00007cc2697d1997  nop [rax+rax*1], ax
00007cc2697d19a0  vmovaps xmm1, [0x00007CC2693FE010]
00007cc2697d19a8  movq xmm1, xmm1
00007cc2697d19ac  movaps [r15+0x110], xmm1
00007cc2697d19b4  mov eax, 0x420AA0
00007cc2697d19b9  mov r14, [r13+rax*1]
00007cc2697d19be  movq xmm1, r14
00007cc2697d19c3  movaps [r15+0x120], xmm1
00007cc2697d19cb  vmovaps xmm1, [0x00007CC2693FE020]
00007cc2697d19d3  movq xmm1, xmm1
00007cc2697d19d7  movaps [r15+0x140], xmm1
00007cc2697d19df  vmovaps xmm1, [0x00007CC2693FE030]
00007cc2697d19e7  vpbroadcastq xmm1, xmm1
00007cc2697d19ec  movaps [r15+0x150], xmm1
00007cc2697d19f4  mov qword ptr [r15+0x40], 0x02
00007cc2697d19fc  vmovaps xmm15, [0x00007CC2693FE040]
00007cc2697d1a04  movq xmm15, xmm15
00007cc2697d1a09  movaps [r15+0x160], xmm15
00007cc2697d1a11  vmovaps xmm15, [0x00007CC2693FE050]
00007cc2697d1a19  vpbroadcastq xmm15, xmm15
00007cc2697d1a1e  movaps [r15+0x130], xmm15
00007cc2697d1a26  mov rax, [r15+0x40]
00007cc2697d1a2a  vmovq xmm14, rax
00007cc2697d1a2f  vpbroadcastq xmm14, xmm14
00007cc2697d1a34  movaps [r15+0x170], xmm14
00007cc2697d1a3c  mov eax, 0x4209D0
00007cc2697d1a41  movups xmm13, [r13+rax*1]
00007cc2697d1a47  mov qword ptr [r15+0x40], 0x431D90
00007cc2697d1a4f  mov eax, [r15]
00007cc2697d1a52  mov r14d, 0x430C48
00007cc2697d1a58  mov [r13+r14*1], eax
00007cc2697d1a5d  mov qword ptr [r15+0x50], 0x431F90
00007cc2697d1a65  vpmovqd xmm12, xmm13
00007cc2697d1a6b  pxor xmm11, xmm11
00007cc2697d1a70  punpcklqdq xmm12, xmm11
00007cc2697d1a75  movaps [r15+0x210], xmm12
00007cc2697d1a7d  movq xmm12, qword ptr [r15+0x140]
00007cc2697d1a86  movq xmm11, qword ptr [r15+0x120]
00007cc2697d1a8f  psubd xmm12, xmm11
00007cc2697d1a94  movq xmm12, xmm12
00007cc2697d1a99  paddq xmm13, xmm14
00007cc2697d1a9e  movaps [r15+0x180], xmm13
00007cc2697d1aa6  movq xmm14, qword ptr [r15+0x160]
00007cc2697d1aaf  paddd xmm11, xmm14
00007cc2697d1ab4  movq xmm11, xmm11
00007cc2697d1ab9  movq xmm11, xmm11
00007cc2697d1abe  movaps [r15+0x120], xmm11
00007cc2697d1ac6  pmovzxdq xmm12, xmm12
00007cc2697d1acc  psllq xmm12, 0x00
00007cc2697d1ad2  movq xmm14, qword ptr [r15+0x210]
00007cc2697d1adb  movq xmm13, qword ptr [r15+0x110]
00007cc2697d1ae4  paddd xmm14, xmm13
00007cc2697d1ae9  movq xmm14, xmm14
00007cc2697d1aee  vcvtuqq2pd xmm12, xmm12
00007cc2697d1af4  pmovzxdq xmm14, xmm14
00007cc2697d1afa  psllq xmm14, 0x00
00007cc2697d1b00  vcvtuqq2pd xmm14, xmm14
00007cc2697d1b06  movaps xmm13, xmm12
00007cc2697d1b0a  mulpd xmm13, xmm1
00007cc2697d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007cc2697d1b15  ptest xmm11, xmm11
00007cc2697d1b1b  jnz 0x00007CC2697D1C0F
00007cc2697d1b21  movaps [r15+0x220], xmm13
00007cc2697d1b29  mov eax, 0x431F90
00007cc2697d1b2e  movups [r13+rax*1], xmm13
00007cc2697d1b34  movaps xmm1, xmm14
00007cc2697d1b38  mulpd xmm1, xmm15
00007cc2697d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007cc2697d1b42  ptest xmm13, xmm13
00007cc2697d1b48  jnz 0x00007CC2697D1D5C
00007cc2697d1b4e  movaps [r15+0x210], xmm1
00007cc2697d1b56  mov eax, 0x431D90
00007cc2697d1b5b  movups [r13+rax*1], xmm1
00007cc2697d1b61  mov qword ptr [r15+0x48], 0x10
00007cc2697d1b69  xor eax, eax
00007cc2697d1b6b  mov r14d, 0x10
00007cc2697d1b71  mov r12d, 0x200
00007cc2697d1b77  cmp r14, r12
00007cc2697d1b7a  cmc
00007cc2697d1b7b  lahf
00007cc2697d1b7c  seto al
00007cc2697d1b7f  mov [r15+0x108], eax
00007cc2697d1b86  mov eax, [r15+0x108]
00007cc2697d1b8d  sahf
00007cc2697d1b8e  jnz 0x00007CC2697D1BC0
00007cc2697d1b90  cmp dword ptr [r15+0x318], 0x00
00007cc2697d1b98  jz 0x00007CC2697D2300
00007cc2697d1b9e  nop [rax+rax*1], ax
00007cc2697d1ba7  nop [rax+rax*1], eax
00007cc2697d1baf  mov eax, 0x410480
00007cc2697d1bb4  mov [r15+0x100], rax
00007cc2697d1bbb  jmp 0x00007CC2695FE110
00007cc2697d1bc0  cmp dword ptr [r15+0x318], 0x00
00007cc2697d1bc8  jz 0x00007CC2697D1EB0
00007cc2697d1bce  nop [rax+rax*1], ax
00007cc2697d1bd7  nop [rax+rax*1], eax
00007cc2697d1bdf  mov eax, 0x410440
00007cc2697d1be4  mov [r15+0x100], rax
00007cc2697d1beb  jmp 0x00007CC2695FE110
00007cc2697d1bf0  int3
00007cc2697d1bf1  call 0x00007CC26960DC20
00007cc2697d1bf6  jmp 0x00007CC2697D19BE
00007cc2697d1bfb  call 0x00007CC26960C260
00007cc2697d1c00  jmp 0x00007CC2697D1A47
00007cc2697d1c05  call 0x00007CC2696D5D70
00007cc2697d1c0a  jmp 0x00007CC2697D1A5D
00007cc2697d1c0f  sub rsp, 0x08
00007cc2697d1c13  push rax
00007cc2697d1c14  push rcx
00007cc2697d1c15  push rdx
00007cc2697d1c16  push rdi
00007cc2697d1c17  push rsi
00007cc2697d1c18  push r8
00007cc2697d1c1a  push r9
00007cc2697d1c1c  push r10
00007cc2697d1c1e  push r11
00007cc2697d1c20  sub rsp, 0xF0
00007cc2697d1c27  vmovaps [rsp], xmm0
00007cc2697d1c2c  vmovaps [rsp+0x10], xmm1
00007cc2697d1c32  vmovaps [rsp+0x20], xmm2
00007cc2697d1c38  vmovaps [rsp+0x30], xmm3
00007cc2697d1c3e  vmovaps [rsp+0x40], xmm4
00007cc2697d1c44  vmovaps [rsp+0x50], xmm5
00007cc2697d1c4a  vmovaps [rsp+0x60], xmm6
00007cc2697d1c50  vmovaps [rsp+0x70], xmm7
00007cc2697d1c56  vmovaps [rsp+0x80], xmm8
00007cc2697d1c5f  vmovaps [rsp+0x90], xmm9
00007cc2697d1c68  vmovaps [rsp+0xA0], xmm10
00007cc2697d1c71  vmovaps [rsp+0xB0], xmm11
00007cc2697d1c7a  vmovaps [rsp+0xC0], xmm12
00007cc2697d1c83  vmovaps [rsp+0xD0], xmm14
00007cc2697d1c8c  vmovaps [rsp+0xE0], xmm15
00007cc2697d1c95  sub rsp, 0x30
00007cc2697d1c99  movaps [rsp], xmm13
00007cc2697d1c9e  movaps [rsp+0x10], xmm12
00007cc2697d1ca4  movaps [rsp+0x20], xmm1
00007cc2697d1ca9  lea rdi, [rsp]
00007cc2697d1cad  mov esi, 0x00
00007cc2697d1cb2  mov rax, 0x653E5FFFB530
00007cc2697d1cbc  call rax
00007cc2697d1cbe  movaps xmm13, [rsp]
00007cc2697d1cc3  add rsp, 0x30
00007cc2697d1cc7  vmovaps xmm0, [rsp]
00007cc2697d1ccc  vmovaps xmm1, [rsp+0x10]
00007cc2697d1cd2  vmovaps xmm2, [rsp+0x20]
00007cc2697d1cd8  vmovaps xmm3, [rsp+0x30]
00007cc2697d1cde  vmovaps xmm4, [rsp+0x40]
00007cc2697d1ce4  vmovaps xmm5, [rsp+0x50]
00007cc2697d1cea  vmovaps xmm6, [rsp+0x60]
00007cc2697d1cf0  vmovaps xmm7, [rsp+0x70]
00007cc2697d1cf6  vmovaps xmm8, [rsp+0x80]
00007cc2697d1cff  vmovaps xmm9, [rsp+0x90]
00007cc2697d1d08  vmovaps xmm10, [rsp+0xA0]
00007cc2697d1d11  vmovaps xmm11, [rsp+0xB0]
00007cc2697d1d1a  vmovaps xmm12, [rsp+0xC0]
00007cc2697d1d23  vmovaps xmm14, [rsp+0xD0]
00007cc2697d1d2c  vmovaps xmm15, [rsp+0xE0]
00007cc2697d1d35  add rsp, 0xF0
00007cc2697d1d3c  pop r11
00007cc2697d1d3e  pop r10
00007cc2697d1d40  pop r9
00007cc2697d1d42  pop r8
00007cc2697d1d44  pop rsi
00007cc2697d1d45  pop rdi
00007cc2697d1d46  pop rdx
00007cc2697d1d47  pop rcx
00007cc2697d1d48  pop rax
00007cc2697d1d49  add rsp, 0x08
00007cc2697d1d4d  jmp 0x00007CC2697D1B21
00007cc2697d1d52  call 0x00007CC26960C380
00007cc2697d1d57  jmp 0x00007CC2697D1B34
00007cc2697d1d5c  sub rsp, 0x08
00007cc2697d1d60  push rax
00007cc2697d1d61  push rcx
00007cc2697d1d62  push rdx
00007cc2697d1d63  push rdi
00007cc2697d1d64  push rsi
00007cc2697d1d65  push r8
00007cc2697d1d67  push r9
00007cc2697d1d69  push r10
00007cc2697d1d6b  push r11
00007cc2697d1d6d  sub rsp, 0xF0
00007cc2697d1d74  vmovaps [rsp], xmm0
00007cc2697d1d79  vmovaps [rsp+0x10], xmm2
00007cc2697d1d7f  vmovaps [rsp+0x20], xmm3
00007cc2697d1d85  vmovaps [rsp+0x30], xmm4
00007cc2697d1d8b  vmovaps [rsp+0x40], xmm5
00007cc2697d1d91  vmovaps [rsp+0x50], xmm6
00007cc2697d1d97  vmovaps [rsp+0x60], xmm7
00007cc2697d1d9d  vmovaps [rsp+0x70], xmm8
00007cc2697d1da3  vmovaps [rsp+0x80], xmm9
00007cc2697d1dac  vmovaps [rsp+0x90], xmm10
00007cc2697d1db5  vmovaps [rsp+0xA0], xmm11
00007cc2697d1dbe  vmovaps [rsp+0xB0], xmm12
00007cc2697d1dc7  vmovaps [rsp+0xC0], xmm13
00007cc2697d1dd0  vmovaps [rsp+0xD0], xmm14
00007cc2697d1dd9  vmovaps [rsp+0xE0], xmm15
00007cc2697d1de2  sub rsp, 0x30
00007cc2697d1de6  movaps [rsp], xmm1
00007cc2697d1dea  movaps [rsp+0x10], xmm14
00007cc2697d1df0  movaps [rsp+0x20], xmm15
00007cc2697d1df6  lea rdi, [rsp]
00007cc2697d1dfa  mov esi, 0x00
00007cc2697d1dff  mov rax, 0x653E5FFFB530
00007cc2697d1e09  call rax
00007cc2697d1e0b  movaps xmm1, [rsp]
00007cc2697d1e0f  add rsp, 0x30
00007cc2697d1e13  vmovaps xmm0, [rsp]
00007cc2697d1e18  vmovaps xmm2, [rsp+0x10]
00007cc2697d1e1e  vmovaps xmm3, [rsp+0x20]
00007cc2697d1e24  vmovaps xmm4, [rsp+0x30]
00007cc2697d1e2a  vmovaps xmm5, [rsp+0x40]
00007cc2697d1e30  vmovaps xmm6, [rsp+0x50]
00007cc2697d1e36  vmovaps xmm7, [rsp+0x60]
00007cc2697d1e3c  vmovaps xmm8, [rsp+0x70]
00007cc2697d1e42  vmovaps xmm9, [rsp+0x80]
00007cc2697d1e4b  vmovaps xmm10, [rsp+0x90]
00007cc2697d1e54  vmovaps xmm11, [rsp+0xA0]
00007cc2697d1e5d  vmovaps xmm12, [rsp+0xB0]
00007cc2697d1e66  vmovaps xmm13, [rsp+0xC0]
00007cc2697d1e6f  vmovaps xmm14, [rsp+0xD0]
00007cc2697d1e78  vmovaps xmm15, [rsp+0xE0]
00007cc2697d1e81  add rsp, 0xF0
00007cc2697d1e88  pop r11
00007cc2697d1e8a  pop r10
00007cc2697d1e8c  pop r9
00007cc2697d1e8e  pop r8
00007cc2697d1e90  pop rsi
00007cc2697d1e91  pop rdi
00007cc2697d1e92  pop rdx
00007cc2697d1e93  pop rcx
00007cc2697d1e94  pop rax
00007cc2697d1e95  add rsp, 0x08
00007cc2697d1e99  jmp 0x00007CC2697D1B4E
00007cc2697d1e9e  call 0x00007CC2695FF540
00007cc2697d1ea3  jmp 0x00007CC2697D1B61
00007cc2697d1ea8  int3
00007cc2697d1ea9  nop [rax], eax
00007cc2697d1eb0  movaps xmm1, [r15+0x180]
00007cc2697d1eb8  vpmovqd xmm15, xmm1
00007cc2697d1ebe  pxor xmm14, xmm14
00007cc2697d1ec3  punpcklqdq xmm15, xmm14
00007cc2697d1ec8  movaps [r15+0x210], xmm15
00007cc2697d1ed0  movq xmm15, qword ptr [r15+0x140]
00007cc2697d1ed9  movq xmm14, qword ptr [r15+0x120]
00007cc2697d1ee2  psubd xmm15, xmm14
00007cc2697d1ee7  movq xmm15, xmm15
00007cc2697d1eec  movaps xmm13, [r15+0x170]
00007cc2697d1ef4  paddq xmm1, xmm13
00007cc2697d1ef9  movaps [r15+0x180], xmm1
00007cc2697d1f01  movq xmm1, qword ptr [r15+0x160]
00007cc2697d1f0a  paddd xmm14, xmm1
00007cc2697d1f0f  movq xmm14, xmm14
00007cc2697d1f14  movq xmm14, xmm14
00007cc2697d1f19  movaps [r15+0x120], xmm14
00007cc2697d1f21  pmovzxdq xmm15, xmm15
00007cc2697d1f27  psllq xmm15, 0x00
00007cc2697d1f2d  movq xmm1, qword ptr [r15+0x210]
00007cc2697d1f36  movq xmm14, qword ptr [r15+0x110]
00007cc2697d1f3f  paddd xmm1, xmm14
00007cc2697d1f44  movq xmm1, xmm1
00007cc2697d1f48  vcvtuqq2pd xmm15, xmm15
00007cc2697d1f4e  pmovzxdq xmm1, xmm1
00007cc2697d1f53  psllq xmm1, 0x00
00007cc2697d1f58  vcvtuqq2pd xmm1, xmm1
00007cc2697d1f5e  movaps xmm14, [r15+0x150]
00007cc2697d1f66  movaps xmm13, xmm15
00007cc2697d1f6a  mulpd xmm13, xmm14
00007cc2697d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d1f75  ptest xmm12, xmm12
00007cc2697d1f7b  jnz 0x00007CC2697D205E
00007cc2697d1f81  movaps [r15+0x220], xmm13
00007cc2697d1f89  mov rax, [r15+0x48]
00007cc2697d1f8d  mov r14, [r15+0x50]
00007cc2697d1f91  lea r12, [r14+rax*1]
00007cc2697d1f95  movups [r13+r12*1], xmm13
00007cc2697d1f9b  movaps xmm15, [r15+0x130]
00007cc2697d1fa3  movaps xmm14, xmm1
00007cc2697d1fa7  mulpd xmm14, xmm15
00007cc2697d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007cc2697d1fb2  ptest xmm13, xmm13
00007cc2697d1fb8  jnz 0x00007CC2697D21AC
00007cc2697d1fbe  movaps [r15+0x210], xmm14
00007cc2697d1fc6  mov r14, [r15+0x40]
00007cc2697d1fca  lea r12, [r14+rax*1]
00007cc2697d1fce  movups [r13+r12*1], xmm14
00007cc2697d1fd4  lea r14, [rax+0x10]
00007cc2697d1fd8  mov [r15+0x48], r14
00007cc2697d1fdc  xor eax, eax
00007cc2697d1fde  mov r12d, 0x200
00007cc2697d1fe4  cmp r14, r12
00007cc2697d1fe7  cmc
00007cc2697d1fe8  lahf
00007cc2697d1fe9  seto al
00007cc2697d1fec  mov [r15+0x108], eax
00007cc2697d1ff3  mov eax, [r15+0x108]
00007cc2697d1ffa  sahf
00007cc2697d1ffb  jnz 0x00007CC2697D202D
00007cc2697d1ffd  cmp dword ptr [r15+0x318], 0x00
00007cc2697d2005  jz 0x00007CC2697D2300
00007cc2697d200b  nop [rax+rax*1], ax
00007cc2697d2014  nop [rax+rax*1], eax
00007cc2697d201c  mov eax, 0x410480
00007cc2697d2021  mov [r15+0x100], rax
00007cc2697d2028  jmp 0x00007CC2695FE110
00007cc2697d202d  cmp dword ptr [r15+0x318], 0x00
00007cc2697d2035  jz 0x00007CC2697D1EB0
00007cc2697d203b  nop [rax+rax*1], ax
00007cc2697d2044  nop [rax+rax*1], eax
00007cc2697d204c  mov eax, 0x410440
00007cc2697d2051  mov [r15+0x100], rax
00007cc2697d2058  jmp 0x00007CC2695FE110
00007cc2697d205d  int3
00007cc2697d205e  sub rsp, 0x08
00007cc2697d2062  push rax
00007cc2697d2063  push rcx
00007cc2697d2064  push rdx
00007cc2697d2065  push rdi
00007cc2697d2066  push rsi
00007cc2697d2067  push r8
00007cc2697d2069  push r9
00007cc2697d206b  push r10
00007cc2697d206d  push r11
00007cc2697d206f  sub rsp, 0xF0
00007cc2697d2076  vmovaps [rsp], xmm0
00007cc2697d207b  vmovaps [rsp+0x10], xmm1
00007cc2697d2081  vmovaps [rsp+0x20], xmm2
00007cc2697d2087  vmovaps [rsp+0x30], xmm3
00007cc2697d208d  vmovaps [rsp+0x40], xmm4
00007cc2697d2093  vmovaps [rsp+0x50], xmm5
00007cc2697d2099  vmovaps [rsp+0x60], xmm6
00007cc2697d209f  vmovaps [rsp+0x70], xmm7
00007cc2697d20a5  vmovaps [rsp+0x80], xmm8
00007cc2697d20ae  vmovaps [rsp+0x90], xmm9
00007cc2697d20b7  vmovaps [rsp+0xA0], xmm10
00007cc2697d20c0  vmovaps [rsp+0xB0], xmm11
00007cc2697d20c9  vmovaps [rsp+0xC0], xmm12
00007cc2697d20d2  vmovaps [rsp+0xD0], xmm14
00007cc2697d20db  vmovaps [rsp+0xE0], xmm15
00007cc2697d20e4  sub rsp, 0x30
00007cc2697d20e8  movaps [rsp], xmm13
00007cc2697d20ed  movaps [rsp+0x10], xmm15
00007cc2697d20f3  movaps [rsp+0x20], xmm14
00007cc2697d20f9  lea rdi, [rsp]
00007cc2697d20fd  mov esi, 0x00
00007cc2697d2102  mov rax, 0x653E5FFFB530
00007cc2697d210c  call rax
00007cc2697d210e  movaps xmm13, [rsp]
00007cc2697d2113  add rsp, 0x30
00007cc2697d2117  vmovaps xmm0, [rsp]
00007cc2697d211c  vmovaps xmm1, [rsp+0x10]
00007cc2697d2122  vmovaps xmm2, [rsp+0x20]
00007cc2697d2128  vmovaps xmm3, [rsp+0x30]
00007cc2697d212e  vmovaps xmm4, [rsp+0x40]
00007cc2697d2134  vmovaps xmm5, [rsp+0x50]
00007cc2697d213a  vmovaps xmm6, [rsp+0x60]
00007cc2697d2140  vmovaps xmm7, [rsp+0x70]
00007cc2697d2146  vmovaps xmm8, [rsp+0x80]
00007cc2697d214f  vmovaps xmm9, [rsp+0x90]
00007cc2697d2158  vmovaps xmm10, [rsp+0xA0]
00007cc2697d2161  vmovaps xmm11, [rsp+0xB0]
00007cc2697d216a  vmovaps xmm12, [rsp+0xC0]
00007cc2697d2173  vmovaps xmm14, [rsp+0xD0]
00007cc2697d217c  vmovaps xmm15, [rsp+0xE0]
00007cc2697d2185  add rsp, 0xF0
00007cc2697d218c  pop r11
00007cc2697d218e  pop r10
00007cc2697d2190  pop r9
00007cc2697d2192  pop r8
00007cc2697d2194  pop rsi
00007cc2697d2195  pop rdi
00007cc2697d2196  pop rdx
00007cc2697d2197  pop rcx
00007cc2697d2198  pop rax
00007cc2697d2199  add rsp, 0x08
00007cc2697d219d  jmp 0x00007CC2697D1F81
00007cc2697d21a2  call 0x00007CC2696C2240
00007cc2697d21a7  jmp 0x00007CC2697D1F9B
00007cc2697d21ac  sub rsp, 0x08
00007cc2697d21b0  push rax
00007cc2697d21b1  push rcx
00007cc2697d21b2  push rdx
00007cc2697d21b3  push rdi
00007cc2697d21b4  push rsi
00007cc2697d21b5  push r8
00007cc2697d21b7  push r9
00007cc2697d21b9  push r10
00007cc2697d21bb  push r11
00007cc2697d21bd  sub rsp, 0xF0
00007cc2697d21c4  vmovaps [rsp], xmm0
00007cc2697d21c9  vmovaps [rsp+0x10], xmm1
00007cc2697d21cf  vmovaps [rsp+0x20], xmm2
00007cc2697d21d5  vmovaps [rsp+0x30], xmm3
00007cc2697d21db  vmovaps [rsp+0x40], xmm4
00007cc2697d21e1  vmovaps [rsp+0x50], xmm5
00007cc2697d21e7  vmovaps [rsp+0x60], xmm6
00007cc2697d21ed  vmovaps [rsp+0x70], xmm7
00007cc2697d21f3  vmovaps [rsp+0x80], xmm8
00007cc2697d21fc  vmovaps [rsp+0x90], xmm9
00007cc2697d2205  vmovaps [rsp+0xA0], xmm10
00007cc2697d220e  vmovaps [rsp+0xB0], xmm11
00007cc2697d2217  vmovaps [rsp+0xC0], xmm12
00007cc2697d2220  vmovaps [rsp+0xD0], xmm13
00007cc2697d2229  vmovaps [rsp+0xE0], xmm15
00007cc2697d2232  sub rsp, 0x30
00007cc2697d2236  movaps [rsp], xmm14
00007cc2697d223b  movaps [rsp+0x10], xmm1
00007cc2697d2240  movaps [rsp+0x20], xmm15
00007cc2697d2246  lea rdi, [rsp]
00007cc2697d224a  mov esi, 0x00
00007cc2697d224f  mov rax, 0x653E5FFFB530
00007cc2697d2259  call rax
00007cc2697d225b  movaps xmm14, [rsp]
00007cc2697d2260  add rsp, 0x30
00007cc2697d2264  vmovaps xmm0, [rsp]
00007cc2697d2269  vmovaps xmm1, [rsp+0x10]
00007cc2697d226f  vmovaps xmm2, [rsp+0x20]
00007cc2697d2275  vmovaps xmm3, [rsp+0x30]
00007cc2697d227b  vmovaps xmm4, [rsp+0x40]
00007cc2697d2281  vmovaps xmm5, [rsp+0x50]
00007cc2697d2287  vmovaps xmm6, [rsp+0x60]
00007cc2697d228d  vmovaps xmm7, [rsp+0x70]
00007cc2697d2293  vmovaps xmm8, [rsp+0x80]
00007cc2697d229c  vmovaps xmm9, [rsp+0x90]
00007cc2697d22a5  vmovaps xmm10, [rsp+0xA0]
00007cc2697d22ae  vmovaps xmm11, [rsp+0xB0]
00007cc2697d22b7  vmovaps xmm12, [rsp+0xC0]
00007cc2697d22c0  vmovaps xmm13, [rsp+0xD0]
00007cc2697d22c9  vmovaps xmm15, [rsp+0xE0]
00007cc2697d22d2  add rsp, 0xF0
00007cc2697d22d9  pop r11
00007cc2697d22db  pop r10
00007cc2697d22dd  pop r9
00007cc2697d22df  pop r8
00007cc2697d22e1  pop rsi
00007cc2697d22e2  pop rdi
00007cc2697d22e3  pop rdx
00007cc2697d22e4  pop rcx
00007cc2697d22e5  pop rax
00007cc2697d22e6  add rsp, 0x08
00007cc2697d22ea  jmp 0x00007CC2697D1FBE
00007cc2697d22ef  call 0x00007CC2696C34C0
00007cc2697d22f4  jmp 0x00007CC2697D1FD4
00007cc2697d22f9  int3
00007cc2697d22fa  nop [rax+rax*1], ax
00007cc2697d2300  mov rax, [r15+0x50]
00007cc2697d2304  movups xmm1, [r13+rax*1]
00007cc2697d230a  lea r14, [rax+0x10]
00007cc2697d230e  movups xmm15, [r13+r14*1]
00007cc2697d2314  mov qword ptr [r15+0x48], 0x00
00007cc2697d231c  lea r14, [rax+0x40]
00007cc2697d2320  movups xmm14, [r13+r14*1]
00007cc2697d2326  lea r14, [rax+0x50]
00007cc2697d232a  movups xmm13, [r13+r14*1]
00007cc2697d2330  lea r14, [rax+0x80]
00007cc2697d2337  movups xmm12, [r13+r14*1]
00007cc2697d233d  lea r14, [rax+0x90]
00007cc2697d2344  movups xmm11, [r13+r14*1]
00007cc2697d234a  mov r14, [r15+0xF8]
00007cc2697d2351  movups [r13+r14*1], xmm1
00007cc2697d2357  lea r12, [rax+0x20]
00007cc2697d235b  movups xmm1, [r13+r12*1]
00007cc2697d2361  lea r12, [rax+0x30]
00007cc2697d2365  movups xmm10, [r13+r12*1]
00007cc2697d236b  lea r12, [rax+0xC0]
00007cc2697d2372  movups xmm9, [r13+r12*1]
00007cc2697d2378  lea r12, [rax+0xD0]
00007cc2697d237f  movups xmm8, [r13+r12*1]
00007cc2697d2385  lea r12, [rax+0x100]
00007cc2697d238c  movups xmm7, [r13+r12*1]
00007cc2697d2392  lea r12, [rax+0x110]
00007cc2697d2399  movups xmm6, [r13+r12*1]
00007cc2697d239f  lea r12, [rax+0x140]
00007cc2697d23a6  movups xmm5, [r13+r12*1]
00007cc2697d23ac  lea r12, [rax+0x150]
00007cc2697d23b3  movups xmm4, [r13+r12*1]
00007cc2697d23b9  lea r12, [r14+0xB0]
00007cc2697d23c0  movups [r13+r12*1], xmm10
00007cc2697d23c6  lea r12, [r14+0xC0]
00007cc2697d23cd  movups [r13+r12*1], xmm1
00007cc2697d23d3  lea r12, [rax+0x180]
00007cc2697d23da  movups xmm1, [r13+r12*1]
00007cc2697d23e0  lea r12, [rax+0x190]
00007cc2697d23e7  movups xmm10, [r13+r12*1]
00007cc2697d23ed  lea r12, [rax+0x1C0]
00007cc2697d23f4  movups xmm3, [r13+r12*1]
00007cc2697d23fa  lea r12, [rax+0x1D0]
00007cc2697d2401  movups xmm2, [r13+r12*1]
00007cc2697d2407  lea r12, [rax+0x60]
00007cc2697d240b  vmovaps [rsp+0x10], xmm1
00007cc2697d2411  movups xmm1, [r13+r12*1]
00007cc2697d2417  lea r12, [rax+0x70]
00007cc2697d241b  vmovaps [rsp+0x20], xmm1
00007cc2697d2421  movups xmm1, [r13+r12*1]
00007cc2697d2427  lea r12, [r14+0x70]
00007cc2697d242b  movups [r13+r12*1], xmm10
00007cc2697d2431  lea r12, [r14+0x80]
00007cc2697d2438  vmovaps xmm10, [rsp+0x10]
00007cc2697d243e  movups [r13+r12*1], xmm10
00007cc2697d2444  lea r12, [rax+0xA0]
00007cc2697d244b  movups xmm10, [r13+r12*1]
00007cc2697d2451  lea r12, [rax+0xB0]
00007cc2697d2458  vmovaps [rsp+0x10], xmm1
00007cc2697d245e  movups xmm1, [r13+r12*1]
00007cc2697d2464  lea r12, [r14+0x90]
00007cc2697d246b  movups [r13+r12*1], xmm2
00007cc2697d2471  lea r12, [r14+0xA0]
00007cc2697d2478  movups [r13+r12*1], xmm3
00007cc2697d247e  lea r12, [rax+0xE0]
00007cc2697d2485  movups xmm3, [r13+r12*1]
00007cc2697d248b  lea r12, [rax+0xF0]
00007cc2697d2492  movups xmm2, [r13+r12*1]
00007cc2697d2498  lea r12, [rax+0x120]
00007cc2697d249f  vmovaps [rsp+0x30], xmm1
00007cc2697d24a5  movups xmm1, [r13+r12*1]
00007cc2697d24ab  lea r12, [rax+0x130]
00007cc2697d24b2  vmovaps [rsp+0x40], xmm1
00007cc2697d24b8  movups xmm1, [r13+r12*1]
00007cc2697d24be  vmovaps [rsp+0x50], xmm1
00007cc2697d24c4  vmovaps xmm1, [rsp+0x40]
00007cc2697d24ca  movaps [r15+0x190], xmm1
00007cc2697d24d2  lea r12, [rax+0x160]
00007cc2697d24d9  vmovaps [rsp+0x40], xmm1
00007cc2697d24df  movups xmm1, [r13+r12*1]
00007cc2697d24e5  lea r12, [rax+0x170]
00007cc2697d24ec  vmovaps [rsp+0x60], xmm1
00007cc2697d24f2  movups xmm1, [r13+r12*1]
00007cc2697d24f8  lea r12, [rax+0x1A0]
00007cc2697d24ff  vmovaps [rsp+0x70], xmm1
00007cc2697d2505  movups xmm1, [r13+r12*1]
00007cc2697d250b  lea r12, [rax+0x1B0]
00007cc2697d2512  vmovaps [rsp+0x80], xmm1
00007cc2697d251b  movups xmm1, [r13+r12*1]
00007cc2697d2521  lea r12, [rax+0x1E0]
00007cc2697d2528  vmovaps [rsp+0x90], xmm1
00007cc2697d2531  movups xmm1, [r13+r12*1]
00007cc2697d2537  lea r12, [rax+0x1F0]
00007cc2697d253e  vmovaps [rsp+0xA0], xmm1
00007cc2697d2547  movups xmm1, [r13+r12*1]
00007cc2697d254d  mov qword ptr [r15+0x50], 0x432190
00007cc2697d2555  lea rax, [r14+0x50]
00007cc2697d2559  vmovaps [rsp+0xB0], xmm1
00007cc2697d2562  vmovaps xmm1, [rsp+0x60]
00007cc2697d2568  movups [r13+rax*1], xmm1
00007cc2697d256e  lea rax, [r14+0x60]
00007cc2697d2572  movups [r13+rax*1], xmm5
00007cc2697d2578  lea rax, [r14+0x40]
00007cc2697d257c  vmovaps xmm1, [rsp+0x70]
00007cc2697d2582  movups [r13+rax*1], xmm1
00007cc2697d2588  lea rax, [r14+0x20]
00007cc2697d258c  vmovaps xmm1, [rsp+0xA0]
00007cc2697d2595  movups [r13+rax*1], xmm1
00007cc2697d259b  lea rax, [r14+0x30]
00007cc2697d259f  vmovaps xmm1, [rsp+0x90]
00007cc2697d25a8  movups [r13+rax*1], xmm1
00007cc2697d25ae  lea rax, [r14+0x10]
00007cc2697d25b2  vmovaps xmm1, [rsp+0xB0]
00007cc2697d25bb  movups [r13+rax*1], xmm1
00007cc2697d25c1  mov rax, [r15+0x40]
00007cc2697d25c5  vxorps xmm1, xmm1, xmm1
00007cc2697d25c9  vpbroadcastq xmm1, xmm1
00007cc2697d25ce  vxorps xmm5, xmm5, xmm5
00007cc2697d25d2  vpbroadcastq xmm5, xmm5
00007cc2697d25d7  lea r12, [rax+0x30]
00007cc2697d25db  mov r11, [r13+r12*1]
00007cc2697d25e0  lea r12, [rax+0x38]
00007cc2697d25e4  mov r10, [r13+r12*1]
00007cc2697d25e9  vmovaps [rsp+0x60], xmm1
00007cc2697d25ef  movq xmm1, r11
00007cc2697d25f4  vmovaps [rsp+0x70], xmm1
00007cc2697d25fa  movq xmm1, r10
00007cc2697d25ff  vmovaps [rsp+0x90], xmm1
00007cc2697d2608  vmovaps xmm1, [rsp+0x70]
00007cc2697d260e  movq xmm1, xmm1
00007cc2697d2612  vmovaps [rsp+0x70], xmm1
00007cc2697d2618  vmovaps xmm1, [rsp+0x90]
00007cc2697d2621  movq xmm1, xmm1
00007cc2697d2625  vmovaps [rsp+0x90], xmm1
00007cc2697d262e  movq xmm1, xmm1
00007cc2697d2632  movaps [r15+0x270], xmm1
00007cc2697d263a  vmovaps [rsp+0xA0], xmm7
00007cc2697d2643  vmovaps xmm1, [rsp+0xA0]
00007cc2697d264c  por xmm7, xmm1
00007cc2697d2650  lea r12, [rax+0x20]
00007cc2697d2654  mov r11, [r13+r12*1]
00007cc2697d2659  lea r12, [rax+0x28]
00007cc2697d265d  mov r10, [r13+r12*1]
00007cc2697d2662  movq xmm1, r11
00007cc2697d2667  vmovaps [rsp+0xA0], xmm1
00007cc2697d2670  movq xmm1, r10
00007cc2697d2675  vmovaps [rsp+0xB0], xmm1
00007cc2697d267e  vmovaps xmm1, [rsp+0xA0]
00007cc2697d2687  movq xmm1, xmm1
00007cc2697d268b  vmovaps [rsp+0xA0], xmm1
00007cc2697d2694  vmovaps xmm1, [rsp+0xB0]
00007cc2697d269d  movq xmm1, xmm1
00007cc2697d26a1  vmovaps [rsp+0xB0], xmm2
00007cc2697d26aa  vmovaps [rsp+0xC0], xmm1
00007cc2697d26b3  vmovaps xmm1, [rsp+0xB0]
00007cc2697d26bc  por xmm2, xmm1
00007cc2697d26c0  vmovaps [rsp+0xB0], xmm3
00007cc2697d26c9  vmovaps xmm1, [rsp+0xB0]
00007cc2697d26d2  por xmm3, xmm1
00007cc2697d26d6  vmovaps [rsp+0xB0], xmm4
00007cc2697d26df  vmovaps xmm1, [rsp+0xB0]
00007cc2697d26e8  por xmm4, xmm1
00007cc2697d26ec  vmovaps [rsp+0xB0], xmm9
00007cc2697d26f5  vmovaps xmm1, [rsp+0xB0]
00007cc2697d26fe  por xmm9, xmm1
00007cc2697d2703  lea r12, [rax+0x10]
00007cc2697d2707  mov r11, [r13+r12*1]
00007cc2697d270c  lea r12, [rax+0x18]
00007cc2697d2710  mov r10, [r13+r12*1]
00007cc2697d2715  movq xmm1, r11
00007cc2697d271a  vmovaps [rsp+0xB0], xmm1
00007cc2697d2723  movq xmm1, r10
00007cc2697d2728  vmovaps [rsp+0xD0], xmm1
00007cc2697d2731  vmovaps xmm1, [rsp+0xB0]
00007cc2697d273a  movq xmm1, xmm1
00007cc2697d273e  vmovaps [rsp+0xB0], xmm1
00007cc2697d2747  vmovaps xmm1, [rsp+0xD0]
00007cc2697d2750  movq xmm1, xmm1
00007cc2697d2754  vmovaps [rsp+0xD0], xmm1
00007cc2697d275d  vmovaps xmm1, [rsp+0x80]
00007cc2697d2766  vmovaps [rsp+0xE0], xmm15
00007cc2697d276f  vmovaps xmm15, [rsp+0x80]
00007cc2697d2778  por xmm1, xmm15
00007cc2697d277d  vmovaps xmm15, [rsp+0x10]
00007cc2697d2783  vmovaps [rsp+0x80], xmm1
00007cc2697d278c  vmovaps xmm1, [rsp+0x10]
00007cc2697d2792  por xmm15, xmm1
00007cc2697d2797  vmovaps xmm1, [rsp+0x20]
00007cc2697d279d  vmovaps [rsp+0x10], xmm15
00007cc2697d27a3  vmovaps xmm15, [rsp+0x20]
00007cc2697d27a9  por xmm1, xmm15
00007cc2697d27ae  vmovaps [rsp+0x20], xmm6
00007cc2697d27b4  vmovaps xmm15, [rsp+0x20]
00007cc2697d27ba  por xmm6, xmm15
00007cc2697d27bf  vmovaps [rsp+0x20], xmm11
00007cc2697d27c5  vmovaps xmm15, [rsp+0x20]
00007cc2697d27cb  por xmm11, xmm15
00007cc2697d27d0  vmovaps [rsp+0x20], xmm13
00007cc2697d27d6  vmovaps xmm15, [rsp+0x20]
00007cc2697d27dc  por xmm13, xmm15
00007cc2697d27e1  vmovaps [rsp+0x20], xmm14
00007cc2697d27e7  vmovaps xmm15, [rsp+0x20]
00007cc2697d27ed  por xmm14, xmm15
00007cc2697d27f2  mov r12, [r13+rax*1]
00007cc2697d27f7  vmovq xmm15, r12
00007cc2697d27fc  vpbroadcastq xmm15, xmm15
00007cc2697d2801  vmovaps [rsp+0x20], xmm1
00007cc2697d2807  vxorps xmm1, xmm1, xmm1
00007cc2697d280b  vpbroadcastq xmm1, xmm1
00007cc2697d2810  vmovaps [rsp+0xF0], xmm1
00007cc2697d2819  movups xmm1, [r13+r14*1]
00007cc2697d281f  vmovaps [rsp+0x100], xmm1
00007cc2697d2828  vxorps xmm1, xmm1, xmm1
00007cc2697d282c  vpbroadcastq xmm1, xmm1
00007cc2697d2831  lea r12, [rax+0x08]
00007cc2697d2835  mov rax, [r13+r12*1]
00007cc2697d283a  vmovaps [rsp+0x110], xmm1
00007cc2697d2843  movq xmm1, rax
00007cc2697d2848  movaps [r15+0x240], xmm1
00007cc2697d2850  mov qword ptr [r15+0x60], 0x432190
00007cc2697d2858  mov qword ptr [r15+0x58], 0x40
00007cc2697d2860  vmovaps xmm1, [rsp+0x60]
00007cc2697d2866  vmovaps [rsp+0x60], xmm15
00007cc2697d286c  vmovaps xmm15, [rsp+0x100]
00007cc2697d2875  vmovaps [rsp+0x100], xmm14
00007cc2697d287e  vmovaps xmm14, [rsp+0x60]
00007cc2697d2884  vmovaps [rsp+0x60], xmm13
00007cc2697d288a  vmovaps [rsp+0x120], xmm12
00007cc2697d2893  movaps xmm13, xmm1
00007cc2697d2897  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d28a2  vptest xmm12, xmm12
00007cc2697d28a7  jnz 0x00007CC2697D3482
00007cc2697d28ad  vmovaps xmm1, [rsp+0xE0]
00007cc2697d28b6  movaps xmm15, xmm5
00007cc2697d28ba  vfmadd231pd xmm15, xmm1, xmm14
00007cc2697d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007cc2697d28c5  vptest xmm12, xmm12
00007cc2697d28ca  jnz 0x00007CC2697D35DB
00007cc2697d28d0  vmovaps xmm12, [rsp+0x50]
00007cc2697d28d6  vmovaps xmm5, [rsp+0x50]
00007cc2697d28dc  por xmm12, xmm5
00007cc2697d28e1  vmovaps xmm5, [rsp+0x30]
00007cc2697d28e7  vmovaps [rsp+0x50], xmm1
00007cc2697d28ed  vmovaps xmm1, [rsp+0x30]
00007cc2697d28f3  por xmm5, xmm1
00007cc2697d28f7  vmovaps [rsp+0x30], xmm10
00007cc2697d28fd  vmovaps xmm1, [rsp+0x30]
00007cc2697d2903  por xmm10, xmm1
00007cc2697d2908  vmovaps [rsp+0x30], xmm8
00007cc2697d290e  vmovaps xmm1, [rsp+0x30]
00007cc2697d2914  por xmm8, xmm1
00007cc2697d2919  vmovaps xmm1, [rsp+0x120]
00007cc2697d2922  vmovaps [rsp+0x30], xmm15
00007cc2697d2928  vmovaps xmm15, [rsp+0x120]
00007cc2697d2931  por xmm1, xmm15
00007cc2697d2936  vmovaps xmm15, [rsp+0x50]
00007cc2697d293c  vmovaps [rsp+0xE0], xmm1
00007cc2697d2945  vmovaps xmm1, [rsp+0x50]
00007cc2697d294b  por xmm15, xmm1
00007cc2697d2950  lea rax, [r14+0xC0]
00007cc2697d2957  movups xmm1, [r13+rax*1]
00007cc2697d295d  xor eax, eax
00007cc2697d295f  mov r12d, 0x40
00007cc2697d2965  mov r11d, 0x200
00007cc2697d296b  cmp r12, r11
00007cc2697d296e  cmc
00007cc2697d296f  lahf
00007cc2697d2970  seto al
00007cc2697d2973  mov [r15+0x108], eax
00007cc2697d297a  vmovaps [rsp+0x50], xmm1
00007cc2697d2980  vmovaps xmm1, [rsp+0xF0]
00007cc2697d2989  vmovaps [rsp+0xF0], xmm15
00007cc2697d2992  vmovaps xmm15, [rsp+0x50]
00007cc2697d2998  vmovaps [rsp+0x50], xmm13
00007cc2697d299e  vmovaps [rsp+0x120], xmm12
00007cc2697d29a7  movaps xmm13, xmm1
00007cc2697d29ab  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d29b6  vptest xmm12, xmm12
00007cc2697d29bb  jnz 0x00007CC2697D373D
00007cc2697d29c1  lea rax, [r14+0xB0]
00007cc2697d29c8  movups xmm1, [r13+rax*1]
00007cc2697d29ce  vmovaps xmm15, [rsp+0x110]
00007cc2697d29d7  vmovaps [rsp+0x110], xmm13
00007cc2697d29e0  movaps xmm12, xmm15
00007cc2697d29e4  vfmadd231pd xmm12, xmm1, xmm14
00007cc2697d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007cc2697d29ef  vptest xmm13, xmm13
00007cc2697d29f4  jnz 0x00007CC2697D38A0
00007cc2697d29fa  vmovaps xmm1, [rsp+0x100]
00007cc2697d2a03  vmovaps xmm15, [rsp+0x100]
00007cc2697d2a0c  por xmm1, xmm15
00007cc2697d2a11  movaps [r15+0x210], xmm1
00007cc2697d2a19  vmovaps xmm15, [rsp+0x60]
00007cc2697d2a1f  vmovaps xmm14, [rsp+0x60]
00007cc2697d2a25  por xmm15, xmm14
00007cc2697d2a2a  movaps [r15+0x1C0], xmm15
00007cc2697d2a32  vmovaps [rsp+0x60], xmm11
00007cc2697d2a38  vmovaps xmm14, [rsp+0x60]
00007cc2697d2a3e  por xmm11, xmm14
00007cc2697d2a43  movaps [r15+0x280], xmm11
00007cc2697d2a4b  vmovaps [rsp+0x60], xmm6
00007cc2697d2a51  vmovaps xmm14, [rsp+0x60]
00007cc2697d2a57  por xmm6, xmm14
00007cc2697d2a5c  movaps [r15+0x2A0], xmm6
00007cc2697d2a64  vmovaps xmm14, [rsp+0x20]
00007cc2697d2a6a  vmovaps xmm13, [rsp+0x20]
00007cc2697d2a70  por xmm14, xmm13
00007cc2697d2a75  movaps [r15+0x2E0], xmm14
00007cc2697d2a7d  vmovaps xmm13, [rsp+0x10]
00007cc2697d2a83  vmovaps [rsp+0x20], xmm1
00007cc2697d2a89  vmovaps xmm1, [rsp+0x10]
00007cc2697d2a8f  por xmm13, xmm1
00007cc2697d2a94  movaps [r15+0x1F0], xmm13
00007cc2697d2a9c  vmovaps xmm1, [rsp+0xF0]
00007cc2697d2aa5  vmovaps [rsp+0x10], xmm15
00007cc2697d2aab  vmovaps xmm15, [rsp+0xF0]
00007cc2697d2ab4  por xmm1, xmm15
00007cc2697d2ab9  movaps [r15+0x250], xmm1
00007cc2697d2ac1  vmovaps xmm1, [rsp+0xE0]
00007cc2697d2aca  vmovaps xmm15, [rsp+0xE0]
00007cc2697d2ad3  por xmm1, xmm15
00007cc2697d2ad8  movaps [r15+0x260], xmm1
00007cc2697d2ae0  vmovaps [rsp+0x60], xmm8
00007cc2697d2ae6  vmovaps xmm15, [rsp+0x60]
00007cc2697d2aec  por xmm8, xmm15
00007cc2697d2af1  movaps [r15+0x290], xmm8
00007cc2697d2af9  vmovaps [rsp+0x60], xmm10
00007cc2697d2aff  vmovaps xmm15, [rsp+0x60]
00007cc2697d2b05  por xmm10, xmm15
00007cc2697d2b0a  movaps [r15+0x2C0], xmm10
00007cc2697d2b12  movq xmm15, qword ptr [r15+0x240]
00007cc2697d2b1b  vmovaps [rsp+0x60], xmm15
00007cc2697d2b21  vpermilpd xmm15, xmm15, 0x00
00007cc2697d2b27  vmovaps [rsp+0xE0], xmm1
00007cc2697d2b30  vmovaps xmm1, [rsp+0x50]
00007cc2697d2b36  vmovaps [rsp+0x50], xmm15
00007cc2697d2b3c  vmovaps xmm15, [rsp+0x20]
00007cc2697d2b42  vmovaps [rsp+0x20], xmm14
00007cc2697d2b48  vmovaps xmm14, [rsp+0x50]
00007cc2697d2b4e  vmovaps [rsp+0x50], xmm13
00007cc2697d2b54  vmovaps [rsp+0xF0], xmm12
00007cc2697d2b5d  movaps xmm13, xmm1
00007cc2697d2b61  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d2b6c  vptest xmm12, xmm12
00007cc2697d2b71  jnz 0x00007CC2697D39F9
00007cc2697d2b77  vmovaps xmm1, [rsp+0x60]
00007cc2697d2b7d  vpermilpd xmm1, xmm1, 0x00
00007cc2697d2b83  vmovaps xmm15, [rsp+0x110]
00007cc2697d2b8c  vmovaps xmm14, [rsp+0x20]
00007cc2697d2b92  vmovaps [rsp+0x20], xmm13
00007cc2697d2b98  movaps xmm12, xmm15
00007cc2697d2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007cc2697d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007cc2697d2ba7  vptest xmm13, xmm13
00007cc2697d2bac  jnz 0x00007CC2697D3B52
00007cc2697d2bb2  vmovaps xmm1, [rsp+0x60]
00007cc2697d2bb8  vpermilpd xmm1, xmm1, 0x00
00007cc2697d2bbe  vmovaps xmm15, [rsp+0x30]
00007cc2697d2bc4  vmovaps xmm14, [rsp+0x10]
00007cc2697d2bca  vmovaps [rsp+0x10], xmm12
00007cc2697d2bd0  movaps xmm13, xmm15
00007cc2697d2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007cc2697d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d2bdf  vptest xmm12, xmm12
00007cc2697d2be4  jnz 0x00007CC2697D3CAB
00007cc2697d2bea  vmovaps [rsp+0x30], xmm5
00007cc2697d2bf0  vmovaps xmm1, [rsp+0x30]
00007cc2697d2bf6  por xmm5, xmm1
00007cc2697d2bfa  movaps [r15+0x1D0], xmm5
00007cc2697d2c02  vmovaps xmm1, [rsp+0x60]
00007cc2697d2c08  vpermilpd xmm1, xmm1, 0x00
00007cc2697d2c0e  vmovaps xmm15, [rsp+0xF0]
00007cc2697d2c17  vmovaps xmm14, [rsp+0x50]
00007cc2697d2c1d  vmovaps [rsp+0x30], xmm13
00007cc2697d2c23  movaps xmm12, xmm15
00007cc2697d2c27  vfmadd231pd xmm12, xmm14, xmm1
00007cc2697d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007cc2697d2c32  vptest xmm13, xmm13
00007cc2697d2c37  jnz 0x00007CC2697D3E04
00007cc2697d2c3d  vmovaps xmm1, [rsp+0x80]
00007cc2697d2c46  vmovaps xmm15, [rsp+0x80]
00007cc2697d2c4f  por xmm1, xmm15
00007cc2697d2c54  movaps [r15+0x200], xmm1
00007cc2697d2c5c  vmovaps xmm15, [rsp+0x120]
00007cc2697d2c65  vmovaps xmm14, [rsp+0x120]
00007cc2697d2c6e  por xmm15, xmm14
00007cc2697d2c73  movaps [r15+0x1E0], xmm15
00007cc2697d2c7b  vmovaps [rsp+0x50], xmm4
00007cc2697d2c81  vmovaps xmm13, [rsp+0x50]
00007cc2697d2c87  por xmm4, xmm13
00007cc2697d2c8c  movaps [r15+0x2B0], xmm4
00007cc2697d2c94  vmovaps [rsp+0x50], xmm3
00007cc2697d2c9a  vmovaps xmm13, [rsp+0x50]
00007cc2697d2ca0  por xmm3, xmm13
00007cc2697d2ca5  movaps [r15+0x300], xmm3
00007cc2697d2cad  vmovaps xmm15, [rsp+0xB0]
00007cc2697d2cb6  vpermilpd xmm15, xmm15, 0x00
00007cc2697d2cbc  vmovaps xmm3, [rsp+0x20]
00007cc2697d2cc2  vmovaps [rsp+0x20], xmm1
00007cc2697d2cc8  vmovaps xmm1, [rsp+0xE0]
00007cc2697d2cd1  vmovaps [rsp+0x50], xmm14
00007cc2697d2cd7  vmovaps [rsp+0x60], xmm13
00007cc2697d2cdd  movaps xmm14, xmm3
00007cc2697d2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007cc2697d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007cc2697d2cec  vptest xmm13, xmm13
00007cc2697d2cf1  jnz 0x00007CC2697D3F5D
00007cc2697d2cf7  vmovaps xmm1, [rsp+0xB0]
00007cc2697d2d00  vpermilpd xmm1, xmm1, 0x00
00007cc2697d2d06  vmovaps xmm15, [rsp+0x10]
00007cc2697d2d0c  movaps xmm13, xmm15
00007cc2697d2d10  vfmadd231pd xmm13, xmm10, xmm1
00007cc2697d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007cc2697d2d1b  vptest xmm3, xmm3
00007cc2697d2d20  jnz 0x00007CC2697D40B5
00007cc2697d2d26  vmovaps xmm1, [rsp+0xB0]
00007cc2697d2d2f  vpermilpd xmm1, xmm1, 0x00
00007cc2697d2d35  vmovaps xmm15, [rsp+0x30]
00007cc2697d2d3b  movaps xmm10, xmm15
00007cc2697d2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007cc2697d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007cc2697d2d4a  vptest xmm3, xmm3
00007cc2697d2d4f  jnz 0x00007CC2697D420E
00007cc2697d2d55  vmovaps xmm1, [rsp+0xB0]
00007cc2697d2d5e  vpermilpd xmm1, xmm1, 0x00
00007cc2697d2d64  movaps xmm15, xmm12
00007cc2697d2d68  vfmadd231pd xmm15, xmm5, xmm1
00007cc2697d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007cc2697d2d73  vptest xmm11, xmm11
00007cc2697d2d78  jnz 0x00007CC2697D4367
00007cc2697d2d7e  vmovaps [rsp+0x10], xmm9
00007cc2697d2d84  vmovaps xmm1, [rsp+0x10]
00007cc2697d2d8a  por xmm9, xmm1
00007cc2697d2d8f  movaps [r15+0x180], xmm9
00007cc2697d2d97  vmovaps [rsp+0x10], xmm2
00007cc2697d2d9d  vmovaps xmm1, [rsp+0x10]
00007cc2697d2da3  por xmm2, xmm1
00007cc2697d2da7  movaps [r15+0x2D0], xmm2
00007cc2697d2daf  vmovaps xmm12, [rsp+0xD0]
00007cc2697d2db8  vpermilpd xmm12, xmm12, 0x00
00007cc2697d2dbe  vmovaps xmm11, [rsp+0x60]
00007cc2697d2dc4  movaps xmm5, xmm13
00007cc2697d2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007cc2697d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007cc2697d2dd2  vptest xmm3, xmm3
00007cc2697d2dd7  jnz 0x00007CC2697D44BF
00007cc2697d2ddd  vmovaps xmm13, [rsp+0xD0]
00007cc2697d2de6  vpermilpd xmm13, xmm13, 0x00
00007cc2697d2dec  movaps xmm12, xmm14
00007cc2697d2df0  vfmadd231pd xmm12, xmm9, xmm13
00007cc2697d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007cc2697d2dfb  vptest xmm11, xmm11
00007cc2697d2e00  jnz 0x00007CC2697D4617
00007cc2697d2e06  lea rax, [r14+0x80]
00007cc2697d2e0d  movups xmm14, [r13+rax*1]
00007cc2697d2e13  movaps [r15+0x2F0], xmm14
00007cc2697d2e1b  vmovaps xmm13, [rsp+0xD0]
00007cc2697d2e24  vpermilpd xmm13, xmm13, 0x00
00007cc2697d2e2a  movaps xmm11, xmm10
00007cc2697d2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007cc2697d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007cc2697d2e39  vptest xmm9, xmm9
00007cc2697d2e3e  jnz 0x00007CC2697D477B
00007cc2697d2e44  vmovaps xmm13, [rsp+0xD0]
00007cc2697d2e4d  vpermilpd xmm13, xmm13, 0x00
00007cc2697d2e53  movaps xmm10, xmm15
00007cc2697d2e57  vfmadd231pd xmm10, xmm1, xmm13
00007cc2697d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007cc2697d2e62  vptest xmm9, xmm9
00007cc2697d2e67  jnz 0x00007CC2697D48D5
00007cc2697d2e6d  vmovaps [rsp+0x10], xmm7
00007cc2697d2e73  vmovaps xmm1, [rsp+0x10]
00007cc2697d2e79  por xmm7, xmm1
00007cc2697d2e7d  movaps [r15+0x160], xmm7
00007cc2697d2e85  lea rax, [r14+0x40]
00007cc2697d2e89  movups xmm1, [r13+rax*1]
00007cc2697d2e8f  lea rax, [r14+0x50]
00007cc2697d2e93  movups xmm15, [r13+rax*1]
00007cc2697d2e99  movaps [r15+0x1B0], xmm1
00007cc2697d2ea1  movaps [r15+0x1A0], xmm15
00007cc2697d2ea9  vmovaps xmm13, [rsp+0xA0]
00007cc2697d2eb2  vpermilpd xmm13, xmm13, 0x00
00007cc2697d2eb8  vmovaps xmm9, [rsp+0x40]
00007cc2697d2ebe  movaps xmm8, xmm5
00007cc2697d2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007cc2697d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007cc2697d2ecd  vptest xmm3, xmm3
00007cc2697d2ed2  jnz 0x00007CC2697D4A42
00007cc2697d2ed8  vmovaps xmm13, [rsp+0xA0]
00007cc2697d2ee1  vpermilpd xmm13, xmm13, 0x00
00007cc2697d2ee7  movaps xmm9, xmm12
00007cc2697d2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007cc2697d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007cc2697d2ef6  vptest xmm5, xmm5
00007cc2697d2efb  jnz 0x00007CC2697D4B9B
00007cc2697d2f01  vmovaps xmm13, [rsp+0xA0]
00007cc2697d2f0a  vpermilpd xmm13, xmm13, 0x00
00007cc2697d2f10  movaps xmm12, xmm11
00007cc2697d2f14  vfmadd231pd xmm12, xmm6, xmm13
00007cc2697d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007cc2697d2f1f  vptest xmm7, xmm7
00007cc2697d2f24  jnz 0x00007CC2697D4CF4
00007cc2697d2f2a  vmovaps xmm13, [rsp+0xA0]
00007cc2697d2f33  vpermilpd xmm13, xmm13, 0x00
00007cc2697d2f39  vmovaps xmm11, [rsp+0x50]
00007cc2697d2f3f  movaps xmm7, xmm10
00007cc2697d2f43  vfmadd231pd xmm7, xmm11, xmm13
00007cc2697d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2697d2f4d  vptest xmm6, xmm6
00007cc2697d2f52  jnz 0x00007CC2697D4E4D
00007cc2697d2f58  lea rax, [r14+0x60]
00007cc2697d2f5c  movups xmm13, [r13+rax*1]
00007cc2697d2f62  lea rax, [r14+0x70]
00007cc2697d2f66  movups xmm11, [r13+rax*1]
00007cc2697d2f6c  movaps [r15+0x150], xmm13
00007cc2697d2f74  movaps [r15+0x120], xmm11
00007cc2697d2f7c  vmovaps xmm10, [rsp+0xC0]
00007cc2697d2f85  vpermilpd xmm10, xmm10, 0x00
00007cc2697d2f8b  movaps xmm6, xmm8
00007cc2697d2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007cc2697d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007cc2697d2f99  vptest xmm5, xmm5
00007cc2697d2f9e  jnz 0x00007CC2697D4FB9
00007cc2697d2fa4  vmovaps xmm15, [rsp+0xC0]
00007cc2697d2fad  vpermilpd xmm15, xmm15, 0x00
00007cc2697d2fb3  movaps xmm10, xmm9
00007cc2697d2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007cc2697d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007cc2697d2fc2  vptest xmm8, xmm8
00007cc2697d2fc7  jnz 0x00007CC2697D5111
00007cc2697d2fcd  vmovaps xmm15, [rsp+0xC0]
00007cc2697d2fd6  vpermilpd xmm15, xmm15, 0x00
00007cc2697d2fdc  movaps xmm13, xmm12
00007cc2697d2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007cc2697d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007cc2697d2feb  vptest xmm9, xmm9
00007cc2697d2ff0  jnz 0x00007CC2697D526B
00007cc2697d2ff6  vmovaps xmm15, [rsp+0xC0]
00007cc2697d2fff  vpermilpd xmm15, xmm15, 0x00
00007cc2697d3005  movaps xmm12, xmm7
00007cc2697d3009  vfmadd231pd xmm12, xmm1, xmm15
00007cc2697d300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007cc2697d3014  vptest xmm9, xmm9
00007cc2697d3019  jnz 0x00007CC2697D53C4
00007cc2697d301f  lea rax, [r14+0x20]
00007cc2697d3023  movups xmm1, [r13+rax*1]
00007cc2697d3029  lea rax, [r14+0x30]
00007cc2697d302d  movups xmm15, [r13+rax*1]
00007cc2697d3033  vmovaps xmm9, [rsp+0x70]
00007cc2697d3039  vpermilpd xmm9, xmm9, 0x00
00007cc2697d303f  vmovaps xmm8, [rsp+0x20]
00007cc2697d3045  movaps xmm7, xmm6
00007cc2697d3048  vfmadd231pd xmm7, xmm8, xmm9
00007cc2697d304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007cc2697d3052  vptest xmm5, xmm5
00007cc2697d3057  jnz 0x00007CC2697D5530
00007cc2697d305d  vmovaps xmm9, [rsp+0x70]
00007cc2697d3063  vpermilpd xmm9, xmm9, 0x00
00007cc2697d3069  movaps xmm8, xmm10
00007cc2697d306d  vfmadd231pd xmm8, xmm14, xmm9
00007cc2697d3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007cc2697d3078  vptest xmm6, xmm6
00007cc2697d307d  jnz 0x00007CC2697D5687
00007cc2697d3083  vmovaps xmm14, [rsp+0x70]
00007cc2697d3089  vpermilpd xmm14, xmm14, 0x00
00007cc2697d308f  movaps xmm10, xmm13
00007cc2697d3093  vfmadd231pd xmm10, xmm11, xmm14
00007cc2697d3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007cc2697d309e  vptest xmm9, xmm9
00007cc2697d30a3  jnz 0x00007CC2697D57E1
00007cc2697d30a9  vmovaps xmm14, [rsp+0x70]
00007cc2697d30af  vpermilpd xmm14, xmm14, 0x00
00007cc2697d30b5  movaps xmm13, xmm12
00007cc2697d30b9  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007cc2697d30c4  vptest xmm11, xmm11
00007cc2697d30c9  jnz 0x00007CC2697D593B
00007cc2697d30cf  lea rax, [r14+0x90]
00007cc2697d30d6  movups xmm15, [r13+rax*1]
00007cc2697d30dc  lea rax, [r14+0xA0]
00007cc2697d30e3  movups xmm14, [r13+rax*1]
00007cc2697d30e9  movaps [r15+0x140], xmm15
00007cc2697d30f1  movaps [r15+0x130], xmm14
00007cc2697d30f9  vmovaps xmm12, [rsp+0x90]
00007cc2697d3102  vpermilpd xmm12, xmm12, 0x00
00007cc2697d3108  movaps xmm11, xmm7
00007cc2697d310c  vfmadd231pd xmm11, xmm1, xmm12
00007cc2697d3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007cc2697d3117  vptest xmm9, xmm9
00007cc2697d311c  jnz 0x00007CC2697D5AA9
00007cc2697d3122  movaps [r15+0x220], xmm11
00007cc2697d312a  lea rax, [r14+0x10]
00007cc2697d312e  movups xmm1, [r13+rax*1]
00007cc2697d3134  movaps [r15+0x240], xmm1
00007cc2697d313c  vmovaps xmm12, [rsp+0x90]
00007cc2697d3145  vpermilpd xmm12, xmm12, 0x00
00007cc2697d314b  movaps xmm9, xmm8
00007cc2697d314f  vfmadd231pd xmm9, xmm14, xmm12
00007cc2697d3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007cc2697d315a  vptest xmm7, xmm7
00007cc2697d315f  jnz 0x00007CC2697D5C0B
00007cc2697d3165  movaps [r15+0x110], xmm9
00007cc2697d316d  vmovaps xmm14, [rsp+0x90]
00007cc2697d3176  vpermilpd xmm14, xmm14, 0x00
00007cc2697d317c  movaps xmm12, xmm10
00007cc2697d3180  vfmadd231pd xmm12, xmm15, xmm14
00007cc2697d3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007cc2697d318b  vptest xmm8, xmm8
00007cc2697d3190  jnz 0x00007CC2697D5D65
00007cc2697d3196  movaps [r15+0x170], xmm12
00007cc2697d319e  vmovaps xmm15, [rsp+0x90]
00007cc2697d31a7  vpermilpd xmm15, xmm15, 0x00
00007cc2697d31ad  movaps xmm14, xmm13
00007cc2697d31b1  vfmadd231pd xmm14, xmm1, xmm15
00007cc2697d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007cc2697d31bc  vptest xmm10, xmm10
00007cc2697d31c1  jnz 0x00007CC2697D5EBF
00007cc2697d31c7  movaps [r15+0x230], xmm14
00007cc2697d31cf  mov eax, 0x432190
00007cc2697d31d4  movups [r13+rax*1], xmm9
00007cc2697d31da  mov eax, 0x4321A0
00007cc2697d31df  movups [r13+rax*1], xmm12
00007cc2697d31e5  mov eax, 0x4321B0
00007cc2697d31ea  movups [r13+rax*1], xmm11
00007cc2697d31f0  mov eax, 0x4321C0
00007cc2697d31f5  movups [r13+rax*1], xmm14
00007cc2697d31fb  mov eax, [r15+0x108]
00007cc2697d3202  sahf
00007cc2697d3203  jnz 0x00007CC2697D3235
00007cc2697d3205  cmp dword ptr [r15+0x318], 0x00
00007cc2697d320d  jz 0x00007CC2697D9950
00007cc2697d3213  nop [rax+rax*1], ax
00007cc2697d321c  nop [rax+rax*1], eax
00007cc2697d3224  mov eax, 0x410664
00007cc2697d3229  mov [r15+0x100], rax
00007cc2697d3230  jmp 0x00007CC2695FE110
00007cc2697d3235  cmp dword ptr [r15+0x318], 0x00
00007cc2697d323d  jz 0x00007CC2697D6050
00007cc2697d3243  nop [rax+rax*1], ax
00007cc2697d324c  nop [rax+rax*1], eax
00007cc2697d3254  mov eax, 0x4104F0
00007cc2697d3259  mov [r15+0x100], rax
00007cc2697d3260  jmp 0x00007CC2695FE110
00007cc2697d3265  int3
00007cc2697d3266  call 0x00007CC2695FF430
00007cc2697d326b  jmp 0x00007CC2697D230A
00007cc2697d3270  call 0x00007CC2696E5820
00007cc2697d3275  jmp 0x00007CC2697D2314
00007cc2697d327a  call 0x00007CC2696E45A0
00007cc2697d327f  jmp 0x00007CC2697D2326
00007cc2697d3284  call 0x00007CC2696E3320
00007cc2697d3289  jmp 0x00007CC2697D2330
00007cc2697d328e  call 0x00007CC2696E20A0
00007cc2697d3293  jmp 0x00007CC2697D233D
00007cc2697d3298  call 0x00007CC2696E0E30
00007cc2697d329d  jmp 0x00007CC2697D234A
00007cc2697d32a2  call 0x00007CC2696D6600
00007cc2697d32a7  jmp 0x00007CC2697D2357
00007cc2697d32ac  call 0x00007CC2696B52F0
00007cc2697d32b1  jmp 0x00007CC2697D2361
00007cc2697d32b6  call 0x00007CC2696BE9C0
00007cc2697d32bb  jmp 0x00007CC2697D236B
00007cc2697d32c0  call 0x00007CC2696BD750
00007cc2697d32c5  jmp 0x00007CC2697D2378
00007cc2697d32ca  call 0x00007CC2696BC4E0
00007cc2697d32cf  jmp 0x00007CC2697D2385
00007cc2697d32d4  call 0x00007CC2696BB270
00007cc2697d32d9  jmp 0x00007CC2697D2392
00007cc2697d32de  call 0x00007CC2696BA000
00007cc2697d32e3  jmp 0x00007CC2697D239F
00007cc2697d32e8  call 0x00007CC2696B8D90
00007cc2697d32ed  jmp 0x00007CC2697D23AC
00007cc2697d32f2  call 0x00007CC2696B8A20
00007cc2697d32f7  jmp 0x00007CC2697D23B9
00007cc2697d32fc  call 0x00007CC2696BEAE0
00007cc2697d3301  jmp 0x00007CC2697D23C6
00007cc2697d3306  call 0x00007CC2696B5400
00007cc2697d330b  jmp 0x00007CC2697D23D3
00007cc2697d3310  call 0x00007CC2696B52F0
00007cc2697d3315  jmp 0x00007CC2697D23E0
00007cc2697d331a  call 0x00007CC2696BE9C0
00007cc2697d331f  jmp 0x00007CC2697D23ED
00007cc2697d3324  call 0x00007CC2696B77B0
00007cc2697d3329  jmp 0x00007CC2697D23FA
00007cc2697d332e  call 0x00007CC2696B6550
00007cc2697d3333  jmp 0x00007CC2697D2407
00007cc2697d3338  call 0x00007CC2696B52F0
00007cc2697d333d  jmp 0x00007CC2697D2417
00007cc2697d3342  call 0x00007CC2696B52F0
00007cc2697d3347  jmp 0x00007CC2697D2427
00007cc2697d334c  call 0x00007CC2696BEAE0
00007cc2697d3351  jmp 0x00007CC2697D2431
00007cc2697d3356  call 0x00007CC2696BEAE0
00007cc2697d335b  jmp 0x00007CC2697D2444
00007cc2697d3360  call 0x00007CC2696BE9C0
00007cc2697d3365  jmp 0x00007CC2697D2451
00007cc2697d336a  call 0x00007CC2696B52F0
00007cc2697d336f  jmp 0x00007CC2697D2464
00007cc2697d3374  call 0x00007CC2696B6660
00007cc2697d3379  jmp 0x00007CC2697D2471
00007cc2697d337e  call 0x00007CC2696B78C0
00007cc2697d3383  jmp 0x00007CC2697D247E
00007cc2697d3388  call 0x00007CC2696B77B0
00007cc2697d338d  jmp 0x00007CC2697D248B
00007cc2697d3392  call 0x00007CC2696B6550
00007cc2697d3397  jmp 0x00007CC2697D2498
00007cc2697d339c  call 0x00007CC2696B52F0
00007cc2697d33a1  jmp 0x00007CC2697D24AB
00007cc2697d33a6  call 0x00007CC2696B52F0
00007cc2697d33ab  jmp 0x00007CC2697D24BE
00007cc2697d33b0  call 0x00007CC2696B52F0
00007cc2697d33b5  jmp 0x00007CC2697D24E5
00007cc2697d33ba  call 0x00007CC2696B52F0
00007cc2697d33bf  jmp 0x00007CC2697D24F8
00007cc2697d33c4  call 0x00007CC2696B52F0
00007cc2697d33c9  jmp 0x00007CC2697D250B
00007cc2697d33ce  call 0x00007CC2696B52F0
00007cc2697d33d3  jmp 0x00007CC2697D2521
00007cc2697d33d8  call 0x00007CC2696B52F0
00007cc2697d33dd  jmp 0x00007CC2697D2537
00007cc2697d33e2  call 0x00007CC2696B52F0
00007cc2697d33e7  jmp 0x00007CC2697D254D
00007cc2697d33ec  call 0x00007CC2695FF540
00007cc2697d33f1  jmp 0x00007CC2697D256E
00007cc2697d33f6  call 0x00007CC269602FE0
00007cc2697d33fb  jmp 0x00007CC2697D2578
00007cc2697d3400  call 0x00007CC2695FF540
00007cc2697d3405  jmp 0x00007CC2697D2588
00007cc2697d340a  call 0x00007CC2695FF540
00007cc2697d340f  jmp 0x00007CC2697D259B
00007cc2697d3414  call 0x00007CC2695FF540
00007cc2697d3419  jmp 0x00007CC2697D25AE
00007cc2697d341e  call 0x00007CC2695FF540
00007cc2697d3423  jmp 0x00007CC2697D25C1
00007cc2697d3428  call 0x00007CC2696C0370
00007cc2697d342d  jmp 0x00007CC2697D25E0
00007cc2697d3432  call 0x00007CC2696BF100
00007cc2697d3437  jmp 0x00007CC2697D25E9
00007cc2697d343c  call 0x00007CC2696C0370
00007cc2697d3441  jmp 0x00007CC2697D2659
00007cc2697d3446  call 0x00007CC2696BF100
00007cc2697d344b  jmp 0x00007CC2697D2662
00007cc2697d3450  call 0x00007CC2696C0370
00007cc2697d3455  jmp 0x00007CC2697D270C
00007cc2697d345a  call 0x00007CC2696BF100
00007cc2697d345f  jmp 0x00007CC2697D2715
00007cc2697d3464  call 0x00007CC26960B720
00007cc2697d3469  jmp 0x00007CC2697D27F7
00007cc2697d346e  call 0x00007CC2696D64F0
00007cc2697d3473  jmp 0x00007CC2697D281F
00007cc2697d3478  call 0x00007CC2696B47C0
00007cc2697d347d  jmp 0x00007CC2697D283A
00007cc2697d3482  sub rsp, 0x08
00007cc2697d3486  push rax
00007cc2697d3487  push rcx
00007cc2697d3488  push rdx
00007cc2697d3489  push rdi
00007cc2697d348a  push rsi
00007cc2697d348b  push r8
00007cc2697d348d  push r9
00007cc2697d348f  push r10
00007cc2697d3491  push r11
00007cc2697d3493  sub rsp, 0xF0
00007cc2697d349a  vmovaps [rsp], xmm0
00007cc2697d349f  vmovaps [rsp+0x10], xmm1
00007cc2697d34a5  vmovaps [rsp+0x20], xmm2
00007cc2697d34ab  vmovaps [rsp+0x30], xmm3
00007cc2697d34b1  vmovaps [rsp+0x40], xmm4
00007cc2697d34b7  vmovaps [rsp+0x50], xmm5
00007cc2697d34bd  vmovaps [rsp+0x60], xmm6
00007cc2697d34c3  vmovaps [rsp+0x70], xmm7
00007cc2697d34c9  vmovaps [rsp+0x80], xmm8
00007cc2697d34d2  vmovaps [rsp+0x90], xmm9
00007cc2697d34db  vmovaps [rsp+0xA0], xmm10
00007cc2697d34e4  vmovaps [rsp+0xB0], xmm11
00007cc2697d34ed  vmovaps [rsp+0xC0], xmm12
00007cc2697d34f6  vmovaps [rsp+0xD0], xmm14
00007cc2697d34ff  vmovaps [rsp+0xE0], xmm15
00007cc2697d3508  sub rsp, 0x40
00007cc2697d350c  lea rdi, [rsp]
00007cc2697d3510  lea rsi, [rsp+0x10]
00007cc2697d3515  lea rdx, [rsp+0x20]
00007cc2697d351a  lea rcx, [rsp+0x30]
00007cc2697d351f  mov r8d, 0x00
00007cc2697d3525  lea r9, [r15+0x3A8]
00007cc2697d352c  movaps [rdi], xmm13
00007cc2697d3530  movaps [rsi], xmm1
00007cc2697d3533  movaps [rdx], xmm15
00007cc2697d3537  movaps [rcx], xmm14
00007cc2697d353b  mov rax, 0x653E5FFFBA50
00007cc2697d3545  call rax
00007cc2697d3547  movaps xmm13, [rsp]
00007cc2697d354c  add rsp, 0x40
00007cc2697d3550  vmovaps xmm0, [rsp]
00007cc2697d3555  vmovaps xmm1, [rsp+0x10]
00007cc2697d355b  vmovaps xmm2, [rsp+0x20]
00007cc2697d3561  vmovaps xmm3, [rsp+0x30]
00007cc2697d3567  vmovaps xmm4, [rsp+0x40]
00007cc2697d356d  vmovaps xmm5, [rsp+0x50]
00007cc2697d3573  vmovaps xmm6, [rsp+0x60]
00007cc2697d3579  vmovaps xmm7, [rsp+0x70]
00007cc2697d357f  vmovaps xmm8, [rsp+0x80]
00007cc2697d3588  vmovaps xmm9, [rsp+0x90]
00007cc2697d3591  vmovaps xmm10, [rsp+0xA0]
00007cc2697d359a  vmovaps xmm11, [rsp+0xB0]
00007cc2697d35a3  vmovaps xmm12, [rsp+0xC0]
00007cc2697d35ac  vmovaps xmm14, [rsp+0xD0]
00007cc2697d35b5  vmovaps xmm15, [rsp+0xE0]
00007cc2697d35be  add rsp, 0xF0
00007cc2697d35c5  pop r11
00007cc2697d35c7  pop r10
00007cc2697d35c9  pop r9
00007cc2697d35cb  pop r8
00007cc2697d35cd  pop rsi
00007cc2697d35ce  pop rdi
00007cc2697d35cf  pop rdx
00007cc2697d35d0  pop rcx
00007cc2697d35d1  pop rax
00007cc2697d35d2  add rsp, 0x08
00007cc2697d35d6  jmp 0x00007CC2697D28AD
00007cc2697d35db  sub rsp, 0x08
00007cc2697d35df  push rax
00007cc2697d35e0  push rcx
00007cc2697d35e1  push rdx
00007cc2697d35e2  push rdi
00007cc2697d35e3  push rsi
00007cc2697d35e4  push r8
00007cc2697d35e6  push r9
00007cc2697d35e8  push r10
00007cc2697d35ea  push r11
00007cc2697d35ec  sub rsp, 0xF0
00007cc2697d35f3  vmovaps [rsp], xmm0
00007cc2697d35f8  vmovaps [rsp+0x10], xmm1
00007cc2697d35fe  vmovaps [rsp+0x20], xmm2
00007cc2697d3604  vmovaps [rsp+0x30], xmm3
00007cc2697d360a  vmovaps [rsp+0x40], xmm4
00007cc2697d3610  vmovaps [rsp+0x50], xmm5
00007cc2697d3616  vmovaps [rsp+0x60], xmm6
00007cc2697d361c  vmovaps [rsp+0x70], xmm7
00007cc2697d3622  vmovaps [rsp+0x80], xmm8
00007cc2697d362b  vmovaps [rsp+0x90], xmm9
00007cc2697d3634  vmovaps [rsp+0xA0], xmm10
00007cc2697d363d  vmovaps [rsp+0xB0], xmm11
00007cc2697d3646  vmovaps [rsp+0xC0], xmm12
00007cc2697d364f  vmovaps [rsp+0xD0], xmm13
00007cc2697d3658  vmovaps [rsp+0xE0], xmm14
00007cc2697d3661  sub rsp, 0x40
00007cc2697d3665  lea rdi, [rsp]
00007cc2697d3669  lea rsi, [rsp+0x10]
00007cc2697d366e  lea rdx, [rsp+0x20]
00007cc2697d3673  lea rcx, [rsp+0x30]
00007cc2697d3678  mov r8d, 0x00
00007cc2697d367e  lea r9, [r15+0x3A8]
00007cc2697d3685  movaps [rdi], xmm15
00007cc2697d3689  movaps [rsi], xmm5
00007cc2697d368c  movaps [rdx], xmm1
00007cc2697d368f  movaps [rcx], xmm14
00007cc2697d3693  mov rax, 0x653E5FFFBA50
00007cc2697d369d  call rax
00007cc2697d369f  movaps xmm15, [rsp]
00007cc2697d36a4  add rsp, 0x40
00007cc2697d36a8  vmovaps xmm0, [rsp]
00007cc2697d36ad  vmovaps xmm1, [rsp+0x10]
00007cc2697d36b3  vmovaps xmm2, [rsp+0x20]
00007cc2697d36b9  vmovaps xmm3, [rsp+0x30]
00007cc2697d36bf  vmovaps xmm4, [rsp+0x40]
00007cc2697d36c5  vmovaps xmm5, [rsp+0x50]
00007cc2697d36cb  vmovaps xmm6, [rsp+0x60]
00007cc2697d36d1  vmovaps xmm7, [rsp+0x70]
00007cc2697d36d7  vmovaps xmm8, [rsp+0x80]
00007cc2697d36e0  vmovaps xmm9, [rsp+0x90]
00007cc2697d36e9  vmovaps xmm10, [rsp+0xA0]
00007cc2697d36f2  vmovaps xmm11, [rsp+0xB0]
00007cc2697d36fb  vmovaps xmm12, [rsp+0xC0]
00007cc2697d3704  vmovaps xmm13, [rsp+0xD0]
00007cc2697d370d  vmovaps xmm14, [rsp+0xE0]
00007cc2697d3716  add rsp, 0xF0
00007cc2697d371d  pop r11
00007cc2697d371f  pop r10
00007cc2697d3721  pop r9
00007cc2697d3723  pop r8
00007cc2697d3725  pop rsi
00007cc2697d3726  pop rdi
00007cc2697d3727  pop rdx
00007cc2697d3728  pop rcx
00007cc2697d3729  pop rax
00007cc2697d372a  add rsp, 0x08
00007cc2697d372e  jmp 0x00007CC2697D28D0
00007cc2697d3733  call 0x00007CC2695FF430
00007cc2697d3738  jmp 0x00007CC2697D295D
00007cc2697d373d  sub rsp, 0x08
00007cc2697d3741  push rax
00007cc2697d3742  push rcx
00007cc2697d3743  push rdx
00007cc2697d3744  push rdi
00007cc2697d3745  push rsi
00007cc2697d3746  push r8
00007cc2697d3748  push r9
00007cc2697d374a  push r10
00007cc2697d374c  push r11
00007cc2697d374e  sub rsp, 0xF0
00007cc2697d3755  vmovaps [rsp], xmm0
00007cc2697d375a  vmovaps [rsp+0x10], xmm1
00007cc2697d3760  vmovaps [rsp+0x20], xmm2
00007cc2697d3766  vmovaps [rsp+0x30], xmm3
00007cc2697d376c  vmovaps [rsp+0x40], xmm4
00007cc2697d3772  vmovaps [rsp+0x50], xmm5
00007cc2697d3778  vmovaps [rsp+0x60], xmm6
00007cc2697d377e  vmovaps [rsp+0x70], xmm7
00007cc2697d3784  vmovaps [rsp+0x80], xmm8
00007cc2697d378d  vmovaps [rsp+0x90], xmm9
00007cc2697d3796  vmovaps [rsp+0xA0], xmm10
00007cc2697d379f  vmovaps [rsp+0xB0], xmm11
00007cc2697d37a8  vmovaps [rsp+0xC0], xmm12
00007cc2697d37b1  vmovaps [rsp+0xD0], xmm14
00007cc2697d37ba  vmovaps [rsp+0xE0], xmm15
00007cc2697d37c3  sub rsp, 0x40
00007cc2697d37c7  lea rdi, [rsp]
00007cc2697d37cb  lea rsi, [rsp+0x10]
00007cc2697d37d0  lea rdx, [rsp+0x20]
00007cc2697d37d5  lea rcx, [rsp+0x30]
00007cc2697d37da  mov r8d, 0x00
00007cc2697d37e0  lea r9, [r15+0x3A8]
00007cc2697d37e7  movaps [rdi], xmm13
00007cc2697d37eb  movaps [rsi], xmm1
00007cc2697d37ee  movaps [rdx], xmm15
00007cc2697d37f2  movaps [rcx], xmm14
00007cc2697d37f6  mov rax, 0x653E5FFFBA50
00007cc2697d3800  call rax
00007cc2697d3802  movaps xmm13, [rsp]
00007cc2697d3807  add rsp, 0x40
00007cc2697d380b  vmovaps xmm0, [rsp]
00007cc2697d3810  vmovaps xmm1, [rsp+0x10]
00007cc2697d3816  vmovaps xmm2, [rsp+0x20]
00007cc2697d381c  vmovaps xmm3, [rsp+0x30]
00007cc2697d3822  vmovaps xmm4, [rsp+0x40]
00007cc2697d3828  vmovaps xmm5, [rsp+0x50]
00007cc2697d382e  vmovaps xmm6, [rsp+0x60]
00007cc2697d3834  vmovaps xmm7, [rsp+0x70]
00007cc2697d383a  vmovaps xmm8, [rsp+0x80]
00007cc2697d3843  vmovaps xmm9, [rsp+0x90]
00007cc2697d384c  vmovaps xmm10, [rsp+0xA0]
00007cc2697d3855  vmovaps xmm11, [rsp+0xB0]
00007cc2697d385e  vmovaps xmm12, [rsp+0xC0]
00007cc2697d3867  vmovaps xmm14, [rsp+0xD0]
00007cc2697d3870  vmovaps xmm15, [rsp+0xE0]
00007cc2697d3879  add rsp, 0xF0
00007cc2697d3880  pop r11
00007cc2697d3882  pop r10
00007cc2697d3884  pop r9
00007cc2697d3886  pop r8
00007cc2697d3888  pop rsi
00007cc2697d3889  pop rdi
00007cc2697d388a  pop rdx
00007cc2697d388b  pop rcx
00007cc2697d388c  pop rax
00007cc2697d388d  add rsp, 0x08
00007cc2697d3891  jmp 0x00007CC2697D29C1
00007cc2697d3896  call 0x00007CC2695FF430
00007cc2697d389b  jmp 0x00007CC2697D29CE
00007cc2697d38a0  sub rsp, 0x08
00007cc2697d38a4  push rax
00007cc2697d38a5  push rcx
00007cc2697d38a6  push rdx
00007cc2697d38a7  push rdi
00007cc2697d38a8  push rsi
00007cc2697d38a9  push r8
00007cc2697d38ab  push r9
00007cc2697d38ad  push r10
00007cc2697d38af  push r11
00007cc2697d38b1  sub rsp, 0xF0
00007cc2697d38b8  vmovaps [rsp], xmm0
00007cc2697d38bd  vmovaps [rsp+0x10], xmm1
00007cc2697d38c3  vmovaps [rsp+0x20], xmm2
00007cc2697d38c9  vmovaps [rsp+0x30], xmm3
00007cc2697d38cf  vmovaps [rsp+0x40], xmm4
00007cc2697d38d5  vmovaps [rsp+0x50], xmm5
00007cc2697d38db  vmovaps [rsp+0x60], xmm6
00007cc2697d38e1  vmovaps [rsp+0x70], xmm7
00007cc2697d38e7  vmovaps [rsp+0x80], xmm8
00007cc2697d38f0  vmovaps [rsp+0x90], xmm9
00007cc2697d38f9  vmovaps [rsp+0xA0], xmm10
00007cc2697d3902  vmovaps [rsp+0xB0], xmm11
00007cc2697d390b  vmovaps [rsp+0xC0], xmm13
00007cc2697d3914  vmovaps [rsp+0xD0], xmm14
00007cc2697d391d  vmovaps [rsp+0xE0], xmm15
00007cc2697d3926  sub rsp, 0x40
00007cc2697d392a  lea rdi, [rsp]
00007cc2697d392e  lea rsi, [rsp+0x10]
00007cc2697d3933  lea rdx, [rsp+0x20]
00007cc2697d3938  lea rcx, [rsp+0x30]
00007cc2697d393d  mov r8d, 0x00
00007cc2697d3943  lea r9, [r15+0x3A8]
00007cc2697d394a  movaps [rdi], xmm12
00007cc2697d394e  movaps [rsi], xmm15
00007cc2697d3952  movaps [rdx], xmm1
00007cc2697d3955  movaps [rcx], xmm14
00007cc2697d3959  mov rax, 0x653E5FFFBA50
00007cc2697d3963  call rax
00007cc2697d3965  movaps xmm12, [rsp]
00007cc2697d396a  add rsp, 0x40
00007cc2697d396e  vmovaps xmm0, [rsp]
00007cc2697d3973  vmovaps xmm1, [rsp+0x10]
00007cc2697d3979  vmovaps xmm2, [rsp+0x20]
00007cc2697d397f  vmovaps xmm3, [rsp+0x30]
00007cc2697d3985  vmovaps xmm4, [rsp+0x40]
00007cc2697d398b  vmovaps xmm5, [rsp+0x50]
00007cc2697d3991  vmovaps xmm6, [rsp+0x60]
00007cc2697d3997  vmovaps xmm7, [rsp+0x70]
00007cc2697d399d  vmovaps xmm8, [rsp+0x80]
00007cc2697d39a6  vmovaps xmm9, [rsp+0x90]
00007cc2697d39af  vmovaps xmm10, [rsp+0xA0]
00007cc2697d39b8  vmovaps xmm11, [rsp+0xB0]
00007cc2697d39c1  vmovaps xmm13, [rsp+0xC0]
00007cc2697d39ca  vmovaps xmm14, [rsp+0xD0]
00007cc2697d39d3  vmovaps xmm15, [rsp+0xE0]
00007cc2697d39dc  add rsp, 0xF0
00007cc2697d39e3  pop r11
00007cc2697d39e5  pop r10
00007cc2697d39e7  pop r9
00007cc2697d39e9  pop r8
00007cc2697d39eb  pop rsi
00007cc2697d39ec  pop rdi
00007cc2697d39ed  pop rdx
00007cc2697d39ee  pop rcx
00007cc2697d39ef  pop rax
00007cc2697d39f0  add rsp, 0x08
00007cc2697d39f4  jmp 0x00007CC2697D29FA
00007cc2697d39f9  sub rsp, 0x08
00007cc2697d39fd  push rax
00007cc2697d39fe  push rcx
00007cc2697d39ff  push rdx
00007cc2697d3a00  push rdi
00007cc2697d3a01  push rsi
00007cc2697d3a02  push r8
00007cc2697d3a04  push r9
00007cc2697d3a06  push r10
00007cc2697d3a08  push r11
00007cc2697d3a0a  sub rsp, 0xF0
00007cc2697d3a11  vmovaps [rsp], xmm0
00007cc2697d3a16  vmovaps [rsp+0x10], xmm1
00007cc2697d3a1c  vmovaps [rsp+0x20], xmm2
00007cc2697d3a22  vmovaps [rsp+0x30], xmm3
00007cc2697d3a28  vmovaps [rsp+0x40], xmm4
00007cc2697d3a2e  vmovaps [rsp+0x50], xmm5
00007cc2697d3a34  vmovaps [rsp+0x60], xmm6
00007cc2697d3a3a  vmovaps [rsp+0x70], xmm7
00007cc2697d3a40  vmovaps [rsp+0x80], xmm8
00007cc2697d3a49  vmovaps [rsp+0x90], xmm9
00007cc2697d3a52  vmovaps [rsp+0xA0], xmm10
00007cc2697d3a5b  vmovaps [rsp+0xB0], xmm11
00007cc2697d3a64  vmovaps [rsp+0xC0], xmm12
00007cc2697d3a6d  vmovaps [rsp+0xD0], xmm14
00007cc2697d3a76  vmovaps [rsp+0xE0], xmm15
00007cc2697d3a7f  sub rsp, 0x40
00007cc2697d3a83  lea rdi, [rsp]
00007cc2697d3a87  lea rsi, [rsp+0x10]
00007cc2697d3a8c  lea rdx, [rsp+0x20]
00007cc2697d3a91  lea rcx, [rsp+0x30]
00007cc2697d3a96  mov r8d, 0x00
00007cc2697d3a9c  lea r9, [r15+0x3A8]
00007cc2697d3aa3  movaps [rdi], xmm13
00007cc2697d3aa7  movaps [rsi], xmm1
00007cc2697d3aaa  movaps [rdx], xmm15
00007cc2697d3aae  movaps [rcx], xmm14
00007cc2697d3ab2  mov rax, 0x653E5FFFBA50
00007cc2697d3abc  call rax
00007cc2697d3abe  movaps xmm13, [rsp]
00007cc2697d3ac3  add rsp, 0x40
00007cc2697d3ac7  vmovaps xmm0, [rsp]
00007cc2697d3acc  vmovaps xmm1, [rsp+0x10]
00007cc2697d3ad2  vmovaps xmm2, [rsp+0x20]
00007cc2697d3ad8  vmovaps xmm3, [rsp+0x30]
00007cc2697d3ade  vmovaps xmm4, [rsp+0x40]
00007cc2697d3ae4  vmovaps xmm5, [rsp+0x50]
00007cc2697d3aea  vmovaps xmm6, [rsp+0x60]
00007cc2697d3af0  vmovaps xmm7, [rsp+0x70]
00007cc2697d3af6  vmovaps xmm8, [rsp+0x80]
00007cc2697d3aff  vmovaps xmm9, [rsp+0x90]
00007cc2697d3b08  vmovaps xmm10, [rsp+0xA0]
00007cc2697d3b11  vmovaps xmm11, [rsp+0xB0]
00007cc2697d3b1a  vmovaps xmm12, [rsp+0xC0]
00007cc2697d3b23  vmovaps xmm14, [rsp+0xD0]
00007cc2697d3b2c  vmovaps xmm15, [rsp+0xE0]
00007cc2697d3b35  add rsp, 0xF0
00007cc2697d3b3c  pop r11
00007cc2697d3b3e  pop r10
00007cc2697d3b40  pop r9
00007cc2697d3b42  pop r8
00007cc2697d3b44  pop rsi
00007cc2697d3b45  pop rdi
00007cc2697d3b46  pop rdx
00007cc2697d3b47  pop rcx
00007cc2697d3b48  pop rax
00007cc2697d3b49  add rsp, 0x08
00007cc2697d3b4d  jmp 0x00007CC2697D2B77
00007cc2697d3b52  sub rsp, 0x08
00007cc2697d3b56  push rax
00007cc2697d3b57  push rcx
00007cc2697d3b58  push rdx
00007cc2697d3b59  push rdi
00007cc2697d3b5a  push rsi
00007cc2697d3b5b  push r8
00007cc2697d3b5d  push r9
00007cc2697d3b5f  push r10
00007cc2697d3b61  push r11
00007cc2697d3b63  sub rsp, 0xF0
00007cc2697d3b6a  vmovaps [rsp], xmm0
00007cc2697d3b6f  vmovaps [rsp+0x10], xmm1
00007cc2697d3b75  vmovaps [rsp+0x20], xmm2
00007cc2697d3b7b  vmovaps [rsp+0x30], xmm3
00007cc2697d3b81  vmovaps [rsp+0x40], xmm4
00007cc2697d3b87  vmovaps [rsp+0x50], xmm5
00007cc2697d3b8d  vmovaps [rsp+0x60], xmm6
00007cc2697d3b93  vmovaps [rsp+0x70], xmm7
00007cc2697d3b99  vmovaps [rsp+0x80], xmm8
00007cc2697d3ba2  vmovaps [rsp+0x90], xmm9
00007cc2697d3bab  vmovaps [rsp+0xA0], xmm10
00007cc2697d3bb4  vmovaps [rsp+0xB0], xmm11
00007cc2697d3bbd  vmovaps [rsp+0xC0], xmm13
00007cc2697d3bc6  vmovaps [rsp+0xD0], xmm14
00007cc2697d3bcf  vmovaps [rsp+0xE0], xmm15
00007cc2697d3bd8  sub rsp, 0x40
00007cc2697d3bdc  lea rdi, [rsp]
00007cc2697d3be0  lea rsi, [rsp+0x10]
00007cc2697d3be5  lea rdx, [rsp+0x20]
00007cc2697d3bea  lea rcx, [rsp+0x30]
00007cc2697d3bef  mov r8d, 0x00
00007cc2697d3bf5  lea r9, [r15+0x3A8]
00007cc2697d3bfc  movaps [rdi], xmm12
00007cc2697d3c00  movaps [rsi], xmm15
00007cc2697d3c04  movaps [rdx], xmm14
00007cc2697d3c08  movaps [rcx], xmm1
00007cc2697d3c0b  mov rax, 0x653E5FFFBA50
00007cc2697d3c15  call rax
00007cc2697d3c17  movaps xmm12, [rsp]
00007cc2697d3c1c  add rsp, 0x40
00007cc2697d3c20  vmovaps xmm0, [rsp]
00007cc2697d3c25  vmovaps xmm1, [rsp+0x10]
00007cc2697d3c2b  vmovaps xmm2, [rsp+0x20]
00007cc2697d3c31  vmovaps xmm3, [rsp+0x30]
00007cc2697d3c37  vmovaps xmm4, [rsp+0x40]
00007cc2697d3c3d  vmovaps xmm5, [rsp+0x50]
00007cc2697d3c43  vmovaps xmm6, [rsp+0x60]
00007cc2697d3c49  vmovaps xmm7, [rsp+0x70]
00007cc2697d3c4f  vmovaps xmm8, [rsp+0x80]
00007cc2697d3c58  vmovaps xmm9, [rsp+0x90]
00007cc2697d3c61  vmovaps xmm10, [rsp+0xA0]
00007cc2697d3c6a  vmovaps xmm11, [rsp+0xB0]
00007cc2697d3c73  vmovaps xmm13, [rsp+0xC0]
00007cc2697d3c7c  vmovaps xmm14, [rsp+0xD0]
00007cc2697d3c85  vmovaps xmm15, [rsp+0xE0]
00007cc2697d3c8e  add rsp, 0xF0
00007cc2697d3c95  pop r11
00007cc2697d3c97  pop r10
00007cc2697d3c99  pop r9
00007cc2697d3c9b  pop r8
00007cc2697d3c9d  pop rsi
00007cc2697d3c9e  pop rdi
00007cc2697d3c9f  pop rdx
00007cc2697d3ca0  pop rcx
00007cc2697d3ca1  pop rax
00007cc2697d3ca2  add rsp, 0x08
00007cc2697d3ca6  jmp 0x00007CC2697D2BB2
00007cc2697d3cab  sub rsp, 0x08
00007cc2697d3caf  push rax
00007cc2697d3cb0  push rcx
00007cc2697d3cb1  push rdx
00007cc2697d3cb2  push rdi
00007cc2697d3cb3  push rsi
00007cc2697d3cb4  push r8
00007cc2697d3cb6  push r9
00007cc2697d3cb8  push r10
00007cc2697d3cba  push r11
00007cc2697d3cbc  sub rsp, 0xF0
00007cc2697d3cc3  vmovaps [rsp], xmm0
00007cc2697d3cc8  vmovaps [rsp+0x10], xmm1
00007cc2697d3cce  vmovaps [rsp+0x20], xmm2
00007cc2697d3cd4  vmovaps [rsp+0x30], xmm3
00007cc2697d3cda  vmovaps [rsp+0x40], xmm4
00007cc2697d3ce0  vmovaps [rsp+0x50], xmm5
00007cc2697d3ce6  vmovaps [rsp+0x60], xmm6
00007cc2697d3cec  vmovaps [rsp+0x70], xmm7
00007cc2697d3cf2  vmovaps [rsp+0x80], xmm8
00007cc2697d3cfb  vmovaps [rsp+0x90], xmm9
00007cc2697d3d04  vmovaps [rsp+0xA0], xmm10
00007cc2697d3d0d  vmovaps [rsp+0xB0], xmm11
00007cc2697d3d16  vmovaps [rsp+0xC0], xmm12
00007cc2697d3d1f  vmovaps [rsp+0xD0], xmm14
00007cc2697d3d28  vmovaps [rsp+0xE0], xmm15
00007cc2697d3d31  sub rsp, 0x40
00007cc2697d3d35  lea rdi, [rsp]
00007cc2697d3d39  lea rsi, [rsp+0x10]
00007cc2697d3d3e  lea rdx, [rsp+0x20]
00007cc2697d3d43  lea rcx, [rsp+0x30]
00007cc2697d3d48  mov r8d, 0x00
00007cc2697d3d4e  lea r9, [r15+0x3A8]
00007cc2697d3d55  movaps [rdi], xmm13
00007cc2697d3d59  movaps [rsi], xmm15
00007cc2697d3d5d  movaps [rdx], xmm14
00007cc2697d3d61  movaps [rcx], xmm1
00007cc2697d3d64  mov rax, 0x653E5FFFBA50
00007cc2697d3d6e  call rax
00007cc2697d3d70  movaps xmm13, [rsp]
00007cc2697d3d75  add rsp, 0x40
00007cc2697d3d79  vmovaps xmm0, [rsp]
00007cc2697d3d7e  vmovaps xmm1, [rsp+0x10]
00007cc2697d3d84  vmovaps xmm2, [rsp+0x20]
00007cc2697d3d8a  vmovaps xmm3, [rsp+0x30]
00007cc2697d3d90  vmovaps xmm4, [rsp+0x40]
00007cc2697d3d96  vmovaps xmm5, [rsp+0x50]
00007cc2697d3d9c  vmovaps xmm6, [rsp+0x60]
00007cc2697d3da2  vmovaps xmm7, [rsp+0x70]
00007cc2697d3da8  vmovaps xmm8, [rsp+0x80]
00007cc2697d3db1  vmovaps xmm9, [rsp+0x90]
00007cc2697d3dba  vmovaps xmm10, [rsp+0xA0]
00007cc2697d3dc3  vmovaps xmm11, [rsp+0xB0]
00007cc2697d3dcc  vmovaps xmm12, [rsp+0xC0]
00007cc2697d3dd5  vmovaps xmm14, [rsp+0xD0]
00007cc2697d3dde  vmovaps xmm15, [rsp+0xE0]
00007cc2697d3de7  add rsp, 0xF0
00007cc2697d3dee  pop r11
00007cc2697d3df0  pop r10
00007cc2697d3df2  pop r9
00007cc2697d3df4  pop r8
00007cc2697d3df6  pop rsi
00007cc2697d3df7  pop rdi
00007cc2697d3df8  pop rdx
00007cc2697d3df9  pop rcx
00007cc2697d3dfa  pop rax
00007cc2697d3dfb  add rsp, 0x08
00007cc2697d3dff  jmp 0x00007CC2697D2BEA
00007cc2697d3e04  sub rsp, 0x08
00007cc2697d3e08  push rax
00007cc2697d3e09  push rcx
00007cc2697d3e0a  push rdx
00007cc2697d3e0b  push rdi
00007cc2697d3e0c  push rsi
00007cc2697d3e0d  push r8
00007cc2697d3e0f  push r9
00007cc2697d3e11  push r10
00007cc2697d3e13  push r11
00007cc2697d3e15  sub rsp, 0xF0
00007cc2697d3e1c  vmovaps [rsp], xmm0
00007cc2697d3e21  vmovaps [rsp+0x10], xmm1
00007cc2697d3e27  vmovaps [rsp+0x20], xmm2
00007cc2697d3e2d  vmovaps [rsp+0x30], xmm3
00007cc2697d3e33  vmovaps [rsp+0x40], xmm4
00007cc2697d3e39  vmovaps [rsp+0x50], xmm5
00007cc2697d3e3f  vmovaps [rsp+0x60], xmm6
00007cc2697d3e45  vmovaps [rsp+0x70], xmm7
00007cc2697d3e4b  vmovaps [rsp+0x80], xmm8
00007cc2697d3e54  vmovaps [rsp+0x90], xmm9
00007cc2697d3e5d  vmovaps [rsp+0xA0], xmm10
00007cc2697d3e66  vmovaps [rsp+0xB0], xmm11
00007cc2697d3e6f  vmovaps [rsp+0xC0], xmm13
00007cc2697d3e78  vmovaps [rsp+0xD0], xmm14
00007cc2697d3e81  vmovaps [rsp+0xE0], xmm15
00007cc2697d3e8a  sub rsp, 0x40
00007cc2697d3e8e  lea rdi, [rsp]
00007cc2697d3e92  lea rsi, [rsp+0x10]
00007cc2697d3e97  lea rdx, [rsp+0x20]
00007cc2697d3e9c  lea rcx, [rsp+0x30]
00007cc2697d3ea1  mov r8d, 0x00
00007cc2697d3ea7  lea r9, [r15+0x3A8]
00007cc2697d3eae  movaps [rdi], xmm12
00007cc2697d3eb2  movaps [rsi], xmm15
00007cc2697d3eb6  movaps [rdx], xmm14
00007cc2697d3eba  movaps [rcx], xmm1
00007cc2697d3ebd  mov rax, 0x653E5FFFBA50
00007cc2697d3ec7  call rax
00007cc2697d3ec9  movaps xmm12, [rsp]
00007cc2697d3ece  add rsp, 0x40
00007cc2697d3ed2  vmovaps xmm0, [rsp]
00007cc2697d3ed7  vmovaps xmm1, [rsp+0x10]
00007cc2697d3edd  vmovaps xmm2, [rsp+0x20]
00007cc2697d3ee3  vmovaps xmm3, [rsp+0x30]
00007cc2697d3ee9  vmovaps xmm4, [rsp+0x40]
00007cc2697d3eef  vmovaps xmm5, [rsp+0x50]
00007cc2697d3ef5  vmovaps xmm6, [rsp+0x60]
00007cc2697d3efb  vmovaps xmm7, [rsp+0x70]
00007cc2697d3f01  vmovaps xmm8, [rsp+0x80]
00007cc2697d3f0a  vmovaps xmm9, [rsp+0x90]
00007cc2697d3f13  vmovaps xmm10, [rsp+0xA0]
00007cc2697d3f1c  vmovaps xmm11, [rsp+0xB0]
00007cc2697d3f25  vmovaps xmm13, [rsp+0xC0]
00007cc2697d3f2e  vmovaps xmm14, [rsp+0xD0]
00007cc2697d3f37  vmovaps xmm15, [rsp+0xE0]
00007cc2697d3f40  add rsp, 0xF0
00007cc2697d3f47  pop r11
00007cc2697d3f49  pop r10
00007cc2697d3f4b  pop r9
00007cc2697d3f4d  pop r8
00007cc2697d3f4f  pop rsi
00007cc2697d3f50  pop rdi
00007cc2697d3f51  pop rdx
00007cc2697d3f52  pop rcx
00007cc2697d3f53  pop rax
00007cc2697d3f54  add rsp, 0x08
00007cc2697d3f58  jmp 0x00007CC2697D2C3D
00007cc2697d3f5d  sub rsp, 0x08
00007cc2697d3f61  push rax
00007cc2697d3f62  push rcx
00007cc2697d3f63  push rdx
00007cc2697d3f64  push rdi
00007cc2697d3f65  push rsi
00007cc2697d3f66  push r8
00007cc2697d3f68  push r9
00007cc2697d3f6a  push r10
00007cc2697d3f6c  push r11
00007cc2697d3f6e  sub rsp, 0xF0
00007cc2697d3f75  vmovaps [rsp], xmm0
00007cc2697d3f7a  vmovaps [rsp+0x10], xmm1
00007cc2697d3f80  vmovaps [rsp+0x20], xmm2
00007cc2697d3f86  vmovaps [rsp+0x30], xmm3
00007cc2697d3f8c  vmovaps [rsp+0x40], xmm4
00007cc2697d3f92  vmovaps [rsp+0x50], xmm5
00007cc2697d3f98  vmovaps [rsp+0x60], xmm6
00007cc2697d3f9e  vmovaps [rsp+0x70], xmm7
00007cc2697d3fa4  vmovaps [rsp+0x80], xmm8
00007cc2697d3fad  vmovaps [rsp+0x90], xmm9
00007cc2697d3fb6  vmovaps [rsp+0xA0], xmm10
00007cc2697d3fbf  vmovaps [rsp+0xB0], xmm11
00007cc2697d3fc8  vmovaps [rsp+0xC0], xmm12
00007cc2697d3fd1  vmovaps [rsp+0xD0], xmm13
00007cc2697d3fda  vmovaps [rsp+0xE0], xmm15
00007cc2697d3fe3  sub rsp, 0x40
00007cc2697d3fe7  lea rdi, [rsp]
00007cc2697d3feb  lea rsi, [rsp+0x10]
00007cc2697d3ff0  lea rdx, [rsp+0x20]
00007cc2697d3ff5  lea rcx, [rsp+0x30]
00007cc2697d3ffa  mov r8d, 0x00
00007cc2697d4000  lea r9, [r15+0x3A8]
00007cc2697d4007  movaps [rdi], xmm14
00007cc2697d400b  movaps [rsi], xmm3
00007cc2697d400e  movaps [rdx], xmm1
00007cc2697d4011  movaps [rcx], xmm15
00007cc2697d4015  mov rax, 0x653E5FFFBA50
00007cc2697d401f  call rax
00007cc2697d4021  movaps xmm14, [rsp]
00007cc2697d4026  add rsp, 0x40
00007cc2697d402a  vmovaps xmm0, [rsp]
00007cc2697d402f  vmovaps xmm1, [rsp+0x10]
00007cc2697d4035  vmovaps xmm2, [rsp+0x20]
00007cc2697d403b  vmovaps xmm3, [rsp+0x30]
00007cc2697d4041  vmovaps xmm4, [rsp+0x40]
00007cc2697d4047  vmovaps xmm5, [rsp+0x50]
00007cc2697d404d  vmovaps xmm6, [rsp+0x60]
00007cc2697d4053  vmovaps xmm7, [rsp+0x70]
00007cc2697d4059  vmovaps xmm8, [rsp+0x80]
00007cc2697d4062  vmovaps xmm9, [rsp+0x90]
00007cc2697d406b  vmovaps xmm10, [rsp+0xA0]
00007cc2697d4074  vmovaps xmm11, [rsp+0xB0]
00007cc2697d407d  vmovaps xmm12, [rsp+0xC0]
00007cc2697d4086  vmovaps xmm13, [rsp+0xD0]
00007cc2697d408f  vmovaps xmm15, [rsp+0xE0]
00007cc2697d4098  add rsp, 0xF0
00007cc2697d409f  pop r11
00007cc2697d40a1  pop r10
00007cc2697d40a3  pop r9
00007cc2697d40a5  pop r8
00007cc2697d40a7  pop rsi
00007cc2697d40a8  pop rdi
00007cc2697d40a9  pop rdx
00007cc2697d40aa  pop rcx
00007cc2697d40ab  pop rax
00007cc2697d40ac  add rsp, 0x08
00007cc2697d40b0  jmp 0x00007CC2697D2CF7
00007cc2697d40b5  sub rsp, 0x08
00007cc2697d40b9  push rax
00007cc2697d40ba  push rcx
00007cc2697d40bb  push rdx
00007cc2697d40bc  push rdi
00007cc2697d40bd  push rsi
00007cc2697d40be  push r8
00007cc2697d40c0  push r9
00007cc2697d40c2  push r10
00007cc2697d40c4  push r11
00007cc2697d40c6  sub rsp, 0xF0
00007cc2697d40cd  vmovaps [rsp], xmm0
00007cc2697d40d2  vmovaps [rsp+0x10], xmm1
00007cc2697d40d8  vmovaps [rsp+0x20], xmm2
00007cc2697d40de  vmovaps [rsp+0x30], xmm3
00007cc2697d40e4  vmovaps [rsp+0x40], xmm4
00007cc2697d40ea  vmovaps [rsp+0x50], xmm5
00007cc2697d40f0  vmovaps [rsp+0x60], xmm6
00007cc2697d40f6  vmovaps [rsp+0x70], xmm7
00007cc2697d40fc  vmovaps [rsp+0x80], xmm8
00007cc2697d4105  vmovaps [rsp+0x90], xmm9
00007cc2697d410e  vmovaps [rsp+0xA0], xmm10
00007cc2697d4117  vmovaps [rsp+0xB0], xmm11
00007cc2697d4120  vmovaps [rsp+0xC0], xmm12
00007cc2697d4129  vmovaps [rsp+0xD0], xmm14
00007cc2697d4132  vmovaps [rsp+0xE0], xmm15
00007cc2697d413b  sub rsp, 0x40
00007cc2697d413f  lea rdi, [rsp]
00007cc2697d4143  lea rsi, [rsp+0x10]
00007cc2697d4148  lea rdx, [rsp+0x20]
00007cc2697d414d  lea rcx, [rsp+0x30]
00007cc2697d4152  mov r8d, 0x00
00007cc2697d4158  lea r9, [r15+0x3A8]
00007cc2697d415f  movaps [rdi], xmm13
00007cc2697d4163  movaps [rsi], xmm15
00007cc2697d4167  movaps [rdx], xmm10
00007cc2697d416b  movaps [rcx], xmm1
00007cc2697d416e  mov rax, 0x653E5FFFBA50
00007cc2697d4178  call rax
00007cc2697d417a  movaps xmm13, [rsp]
00007cc2697d417f  add rsp, 0x40
00007cc2697d4183  vmovaps xmm0, [rsp]
00007cc2697d4188  vmovaps xmm1, [rsp+0x10]
00007cc2697d418e  vmovaps xmm2, [rsp+0x20]
00007cc2697d4194  vmovaps xmm3, [rsp+0x30]
00007cc2697d419a  vmovaps xmm4, [rsp+0x40]
00007cc2697d41a0  vmovaps xmm5, [rsp+0x50]
00007cc2697d41a6  vmovaps xmm6, [rsp+0x60]
00007cc2697d41ac  vmovaps xmm7, [rsp+0x70]
00007cc2697d41b2  vmovaps xmm8, [rsp+0x80]
00007cc2697d41bb  vmovaps xmm9, [rsp+0x90]
00007cc2697d41c4  vmovaps xmm10, [rsp+0xA0]
00007cc2697d41cd  vmovaps xmm11, [rsp+0xB0]
00007cc2697d41d6  vmovaps xmm12, [rsp+0xC0]
00007cc2697d41df  vmovaps xmm14, [rsp+0xD0]
00007cc2697d41e8  vmovaps xmm15, [rsp+0xE0]
00007cc2697d41f1  add rsp, 0xF0
00007cc2697d41f8  pop r11
00007cc2697d41fa  pop r10
00007cc2697d41fc  pop r9
00007cc2697d41fe  pop r8
00007cc2697d4200  pop rsi
00007cc2697d4201  pop rdi
00007cc2697d4202  pop rdx
00007cc2697d4203  pop rcx
00007cc2697d4204  pop rax
00007cc2697d4205  add rsp, 0x08
00007cc2697d4209  jmp 0x00007CC2697D2D26
00007cc2697d420e  sub rsp, 0x08
00007cc2697d4212  push rax
00007cc2697d4213  push rcx
00007cc2697d4214  push rdx
00007cc2697d4215  push rdi
00007cc2697d4216  push rsi
00007cc2697d4217  push r8
00007cc2697d4219  push r9
00007cc2697d421b  push r10
00007cc2697d421d  push r11
00007cc2697d421f  sub rsp, 0xF0
00007cc2697d4226  vmovaps [rsp], xmm0
00007cc2697d422b  vmovaps [rsp+0x10], xmm1
00007cc2697d4231  vmovaps [rsp+0x20], xmm2
00007cc2697d4237  vmovaps [rsp+0x30], xmm3
00007cc2697d423d  vmovaps [rsp+0x40], xmm4
00007cc2697d4243  vmovaps [rsp+0x50], xmm5
00007cc2697d4249  vmovaps [rsp+0x60], xmm6
00007cc2697d424f  vmovaps [rsp+0x70], xmm7
00007cc2697d4255  vmovaps [rsp+0x80], xmm8
00007cc2697d425e  vmovaps [rsp+0x90], xmm9
00007cc2697d4267  vmovaps [rsp+0xA0], xmm11
00007cc2697d4270  vmovaps [rsp+0xB0], xmm12
00007cc2697d4279  vmovaps [rsp+0xC0], xmm13
00007cc2697d4282  vmovaps [rsp+0xD0], xmm14
00007cc2697d428b  vmovaps [rsp+0xE0], xmm15
00007cc2697d4294  sub rsp, 0x40
00007cc2697d4298  lea rdi, [rsp]
00007cc2697d429c  lea rsi, [rsp+0x10]
00007cc2697d42a1  lea rdx, [rsp+0x20]
00007cc2697d42a6  lea rcx, [rsp+0x30]
00007cc2697d42ab  mov r8d, 0x00
00007cc2697d42b1  lea r9, [r15+0x3A8]
00007cc2697d42b8  movaps [rdi], xmm10
00007cc2697d42bc  movaps [rsi], xmm15
00007cc2697d42c0  movaps [rdx], xmm11
00007cc2697d42c4  movaps [rcx], xmm1
00007cc2697d42c7  mov rax, 0x653E5FFFBA50
00007cc2697d42d1  call rax
00007cc2697d42d3  movaps xmm10, [rsp]
00007cc2697d42d8  add rsp, 0x40
00007cc2697d42dc  vmovaps xmm0, [rsp]
00007cc2697d42e1  vmovaps xmm1, [rsp+0x10]
00007cc2697d42e7  vmovaps xmm2, [rsp+0x20]
00007cc2697d42ed  vmovaps xmm3, [rsp+0x30]
00007cc2697d42f3  vmovaps xmm4, [rsp+0x40]
00007cc2697d42f9  vmovaps xmm5, [rsp+0x50]
00007cc2697d42ff  vmovaps xmm6, [rsp+0x60]
00007cc2697d4305  vmovaps xmm7, [rsp+0x70]
00007cc2697d430b  vmovaps xmm8, [rsp+0x80]
00007cc2697d4314  vmovaps xmm9, [rsp+0x90]
00007cc2697d431d  vmovaps xmm11, [rsp+0xA0]
00007cc2697d4326  vmovaps xmm12, [rsp+0xB0]
00007cc2697d432f  vmovaps xmm13, [rsp+0xC0]
00007cc2697d4338  vmovaps xmm14, [rsp+0xD0]
00007cc2697d4341  vmovaps xmm15, [rsp+0xE0]
00007cc2697d434a  add rsp, 0xF0
00007cc2697d4351  pop r11
00007cc2697d4353  pop r10
00007cc2697d4355  pop r9
00007cc2697d4357  pop r8
00007cc2697d4359  pop rsi
00007cc2697d435a  pop rdi
00007cc2697d435b  pop rdx
00007cc2697d435c  pop rcx
00007cc2697d435d  pop rax
00007cc2697d435e  add rsp, 0x08
00007cc2697d4362  jmp 0x00007CC2697D2D55
00007cc2697d4367  sub rsp, 0x08
00007cc2697d436b  push rax
00007cc2697d436c  push rcx
00007cc2697d436d  push rdx
00007cc2697d436e  push rdi
00007cc2697d436f  push rsi
00007cc2697d4370  push r8
00007cc2697d4372  push r9
00007cc2697d4374  push r10
00007cc2697d4376  push r11
00007cc2697d4378  sub rsp, 0xF0
00007cc2697d437f  vmovaps [rsp], xmm0
00007cc2697d4384  vmovaps [rsp+0x10], xmm1
00007cc2697d438a  vmovaps [rsp+0x20], xmm2
00007cc2697d4390  vmovaps [rsp+0x30], xmm3
00007cc2697d4396  vmovaps [rsp+0x40], xmm4
00007cc2697d439c  vmovaps [rsp+0x50], xmm5
00007cc2697d43a2  vmovaps [rsp+0x60], xmm6
00007cc2697d43a8  vmovaps [rsp+0x70], xmm7
00007cc2697d43ae  vmovaps [rsp+0x80], xmm8
00007cc2697d43b7  vmovaps [rsp+0x90], xmm9
00007cc2697d43c0  vmovaps [rsp+0xA0], xmm10
00007cc2697d43c9  vmovaps [rsp+0xB0], xmm11
00007cc2697d43d2  vmovaps [rsp+0xC0], xmm12
00007cc2697d43db  vmovaps [rsp+0xD0], xmm13
00007cc2697d43e4  vmovaps [rsp+0xE0], xmm14
00007cc2697d43ed  sub rsp, 0x40
00007cc2697d43f1  lea rdi, [rsp]
00007cc2697d43f5  lea rsi, [rsp+0x10]
00007cc2697d43fa  lea rdx, [rsp+0x20]
00007cc2697d43ff  lea rcx, [rsp+0x30]
00007cc2697d4404  mov r8d, 0x00
00007cc2697d440a  lea r9, [r15+0x3A8]
00007cc2697d4411  movaps [rdi], xmm15
00007cc2697d4415  movaps [rsi], xmm12
00007cc2697d4419  movaps [rdx], xmm5
00007cc2697d441c  movaps [rcx], xmm1
00007cc2697d441f  mov rax, 0x653E5FFFBA50
00007cc2697d4429  call rax
00007cc2697d442b  movaps xmm15, [rsp]
00007cc2697d4430  add rsp, 0x40
00007cc2697d4434  vmovaps xmm0, [rsp]
00007cc2697d4439  vmovaps xmm1, [rsp+0x10]
00007cc2697d443f  vmovaps xmm2, [rsp+0x20]
00007cc2697d4445  vmovaps xmm3, [rsp+0x30]
00007cc2697d444b  vmovaps xmm4, [rsp+0x40]
00007cc2697d4451  vmovaps xmm5, [rsp+0x50]
00007cc2697d4457  vmovaps xmm6, [rsp+0x60]
00007cc2697d445d  vmovaps xmm7, [rsp+0x70]
00007cc2697d4463  vmovaps xmm8, [rsp+0x80]
00007cc2697d446c  vmovaps xmm9, [rsp+0x90]
00007cc2697d4475  vmovaps xmm10, [rsp+0xA0]
00007cc2697d447e  vmovaps xmm11, [rsp+0xB0]
00007cc2697d4487  vmovaps xmm12, [rsp+0xC0]
00007cc2697d4490  vmovaps xmm13, [rsp+0xD0]
00007cc2697d4499  vmovaps xmm14, [rsp+0xE0]
00007cc2697d44a2  add rsp, 0xF0
00007cc2697d44a9  pop r11
00007cc2697d44ab  pop r10
00007cc2697d44ad  pop r9
00007cc2697d44af  pop r8
00007cc2697d44b1  pop rsi
00007cc2697d44b2  pop rdi
00007cc2697d44b3  pop rdx
00007cc2697d44b4  pop rcx
00007cc2697d44b5  pop rax
00007cc2697d44b6  add rsp, 0x08
00007cc2697d44ba  jmp 0x00007CC2697D2D7E
00007cc2697d44bf  sub rsp, 0x08
00007cc2697d44c3  push rax
00007cc2697d44c4  push rcx
00007cc2697d44c5  push rdx
00007cc2697d44c6  push rdi
00007cc2697d44c7  push rsi
00007cc2697d44c8  push r8
00007cc2697d44ca  push r9
00007cc2697d44cc  push r10
00007cc2697d44ce  push r11
00007cc2697d44d0  sub rsp, 0xF0
00007cc2697d44d7  vmovaps [rsp], xmm0
00007cc2697d44dc  vmovaps [rsp+0x10], xmm1
00007cc2697d44e2  vmovaps [rsp+0x20], xmm2
00007cc2697d44e8  vmovaps [rsp+0x30], xmm3
00007cc2697d44ee  vmovaps [rsp+0x40], xmm4
00007cc2697d44f4  vmovaps [rsp+0x50], xmm6
00007cc2697d44fa  vmovaps [rsp+0x60], xmm7
00007cc2697d4500  vmovaps [rsp+0x70], xmm8
00007cc2697d4506  vmovaps [rsp+0x80], xmm9
00007cc2697d450f  vmovaps [rsp+0x90], xmm10
00007cc2697d4518  vmovaps [rsp+0xA0], xmm11
00007cc2697d4521  vmovaps [rsp+0xB0], xmm12
00007cc2697d452a  vmovaps [rsp+0xC0], xmm13
00007cc2697d4533  vmovaps [rsp+0xD0], xmm14
00007cc2697d453c  vmovaps [rsp+0xE0], xmm15
00007cc2697d4545  sub rsp, 0x40
00007cc2697d4549  lea rdi, [rsp]
00007cc2697d454d  lea rsi, [rsp+0x10]
00007cc2697d4552  lea rdx, [rsp+0x20]
00007cc2697d4557  lea rcx, [rsp+0x30]
00007cc2697d455c  mov r8d, 0x00
00007cc2697d4562  lea r9, [r15+0x3A8]
00007cc2697d4569  movaps [rdi], xmm5
00007cc2697d456c  movaps [rsi], xmm13
00007cc2697d4570  movaps [rdx], xmm11
00007cc2697d4574  movaps [rcx], xmm12
00007cc2697d4578  mov rax, 0x653E5FFFBA50
00007cc2697d4582  call rax
00007cc2697d4584  movaps xmm5, [rsp]
00007cc2697d4588  add rsp, 0x40
00007cc2697d458c  vmovaps xmm0, [rsp]
00007cc2697d4591  vmovaps xmm1, [rsp+0x10]
00007cc2697d4597  vmovaps xmm2, [rsp+0x20]
00007cc2697d459d  vmovaps xmm3, [rsp+0x30]
00007cc2697d45a3  vmovaps xmm4, [rsp+0x40]
00007cc2697d45a9  vmovaps xmm6, [rsp+0x50]
00007cc2697d45af  vmovaps xmm7, [rsp+0x60]
00007cc2697d45b5  vmovaps xmm8, [rsp+0x70]
00007cc2697d45bb  vmovaps xmm9, [rsp+0x80]
00007cc2697d45c4  vmovaps xmm10, [rsp+0x90]
00007cc2697d45cd  vmovaps xmm11, [rsp+0xA0]
00007cc2697d45d6  vmovaps xmm12, [rsp+0xB0]
00007cc2697d45df  vmovaps xmm13, [rsp+0xC0]
00007cc2697d45e8  vmovaps xmm14, [rsp+0xD0]
00007cc2697d45f1  vmovaps xmm15, [rsp+0xE0]
00007cc2697d45fa  add rsp, 0xF0
00007cc2697d4601  pop r11
00007cc2697d4603  pop r10
00007cc2697d4605  pop r9
00007cc2697d4607  pop r8
00007cc2697d4609  pop rsi
00007cc2697d460a  pop rdi
00007cc2697d460b  pop rdx
00007cc2697d460c  pop rcx
00007cc2697d460d  pop rax
00007cc2697d460e  add rsp, 0x08
00007cc2697d4612  jmp 0x00007CC2697D2DDD
00007cc2697d4617  sub rsp, 0x08
00007cc2697d461b  push rax
00007cc2697d461c  push rcx
00007cc2697d461d  push rdx
00007cc2697d461e  push rdi
00007cc2697d461f  push rsi
00007cc2697d4620  push r8
00007cc2697d4622  push r9
00007cc2697d4624  push r10
00007cc2697d4626  push r11
00007cc2697d4628  sub rsp, 0xF0
00007cc2697d462f  vmovaps [rsp], xmm0
00007cc2697d4634  vmovaps [rsp+0x10], xmm1
00007cc2697d463a  vmovaps [rsp+0x20], xmm2
00007cc2697d4640  vmovaps [rsp+0x30], xmm3
00007cc2697d4646  vmovaps [rsp+0x40], xmm4
00007cc2697d464c  vmovaps [rsp+0x50], xmm5
00007cc2697d4652  vmovaps [rsp+0x60], xmm6
00007cc2697d4658  vmovaps [rsp+0x70], xmm7
00007cc2697d465e  vmovaps [rsp+0x80], xmm8
00007cc2697d4667  vmovaps [rsp+0x90], xmm9
00007cc2697d4670  vmovaps [rsp+0xA0], xmm10
00007cc2697d4679  vmovaps [rsp+0xB0], xmm11
00007cc2697d4682  vmovaps [rsp+0xC0], xmm13
00007cc2697d468b  vmovaps [rsp+0xD0], xmm14
00007cc2697d4694  vmovaps [rsp+0xE0], xmm15
00007cc2697d469d  sub rsp, 0x40
00007cc2697d46a1  lea rdi, [rsp]
00007cc2697d46a5  lea rsi, [rsp+0x10]
00007cc2697d46aa  lea rdx, [rsp+0x20]
00007cc2697d46af  lea rcx, [rsp+0x30]
00007cc2697d46b4  mov r8d, 0x00
00007cc2697d46ba  lea r9, [r15+0x3A8]
00007cc2697d46c1  movaps [rdi], xmm12
00007cc2697d46c5  movaps [rsi], xmm14
00007cc2697d46c9  movaps [rdx], xmm9
00007cc2697d46cd  movaps [rcx], xmm13
00007cc2697d46d1  mov rax, 0x653E5FFFBA50
00007cc2697d46db  call rax
00007cc2697d46dd  movaps xmm12, [rsp]
00007cc2697d46e2  add rsp, 0x40
00007cc2697d46e6  vmovaps xmm0, [rsp]
00007cc2697d46eb  vmovaps xmm1, [rsp+0x10]
00007cc2697d46f1  vmovaps xmm2, [rsp+0x20]
00007cc2697d46f7  vmovaps xmm3, [rsp+0x30]
00007cc2697d46fd  vmovaps xmm4, [rsp+0x40]
00007cc2697d4703  vmovaps xmm5, [rsp+0x50]
00007cc2697d4709  vmovaps xmm6, [rsp+0x60]
00007cc2697d470f  vmovaps xmm7, [rsp+0x70]
00007cc2697d4715  vmovaps xmm8, [rsp+0x80]
00007cc2697d471e  vmovaps xmm9, [rsp+0x90]
00007cc2697d4727  vmovaps xmm10, [rsp+0xA0]
00007cc2697d4730  vmovaps xmm11, [rsp+0xB0]
00007cc2697d4739  vmovaps xmm13, [rsp+0xC0]
00007cc2697d4742  vmovaps xmm14, [rsp+0xD0]
00007cc2697d474b  vmovaps xmm15, [rsp+0xE0]
00007cc2697d4754  add rsp, 0xF0
00007cc2697d475b  pop r11
00007cc2697d475d  pop r10
00007cc2697d475f  pop r9
00007cc2697d4761  pop r8
00007cc2697d4763  pop rsi
00007cc2697d4764  pop rdi
00007cc2697d4765  pop rdx
00007cc2697d4766  pop rcx
00007cc2697d4767  pop rax
00007cc2697d4768  add rsp, 0x08
00007cc2697d476c  jmp 0x00007CC2697D2E06
00007cc2697d4771  call 0x00007CC26960D4E0
00007cc2697d4776  jmp 0x00007CC2697D2E13
00007cc2697d477b  sub rsp, 0x08
00007cc2697d477f  push rax
00007cc2697d4780  push rcx
00007cc2697d4781  push rdx
00007cc2697d4782  push rdi
00007cc2697d4783  push rsi
00007cc2697d4784  push r8
00007cc2697d4786  push r9
00007cc2697d4788  push r10
00007cc2697d478a  push r11
00007cc2697d478c  sub rsp, 0xF0
00007cc2697d4793  vmovaps [rsp], xmm0
00007cc2697d4798  vmovaps [rsp+0x10], xmm1
00007cc2697d479e  vmovaps [rsp+0x20], xmm2
00007cc2697d47a4  vmovaps [rsp+0x30], xmm3
00007cc2697d47aa  vmovaps [rsp+0x40], xmm4
00007cc2697d47b0  vmovaps [rsp+0x50], xmm5
00007cc2697d47b6  vmovaps [rsp+0x60], xmm6
00007cc2697d47bc  vmovaps [rsp+0x70], xmm7
00007cc2697d47c2  vmovaps [rsp+0x80], xmm8
00007cc2697d47cb  vmovaps [rsp+0x90], xmm9
00007cc2697d47d4  vmovaps [rsp+0xA0], xmm10
00007cc2697d47dd  vmovaps [rsp+0xB0], xmm12
00007cc2697d47e6  vmovaps [rsp+0xC0], xmm13
00007cc2697d47ef  vmovaps [rsp+0xD0], xmm14
00007cc2697d47f8  vmovaps [rsp+0xE0], xmm15
00007cc2697d4801  sub rsp, 0x40
00007cc2697d4805  lea rdi, [rsp]
00007cc2697d4809  lea rsi, [rsp+0x10]
00007cc2697d480e  lea rdx, [rsp+0x20]
00007cc2697d4813  lea rcx, [rsp+0x30]
00007cc2697d4818  mov r8d, 0x00
00007cc2697d481e  lea r9, [r15+0x3A8]
00007cc2697d4825  movaps [rdi], xmm11
00007cc2697d4829  movaps [rsi], xmm10
00007cc2697d482d  movaps [rdx], xmm8
00007cc2697d4831  movaps [rcx], xmm13
00007cc2697d4835  mov rax, 0x653E5FFFBA50
00007cc2697d483f  call rax
00007cc2697d4841  movaps xmm11, [rsp]
00007cc2697d4846  add rsp, 0x40
00007cc2697d484a  vmovaps xmm0, [rsp]
00007cc2697d484f  vmovaps xmm1, [rsp+0x10]
00007cc2697d4855  vmovaps xmm2, [rsp+0x20]
00007cc2697d485b  vmovaps xmm3, [rsp+0x30]
00007cc2697d4861  vmovaps xmm4, [rsp+0x40]
00007cc2697d4867  vmovaps xmm5, [rsp+0x50]
00007cc2697d486d  vmovaps xmm6, [rsp+0x60]
00007cc2697d4873  vmovaps xmm7, [rsp+0x70]
00007cc2697d4879  vmovaps xmm8, [rsp+0x80]
00007cc2697d4882  vmovaps xmm9, [rsp+0x90]
00007cc2697d488b  vmovaps xmm10, [rsp+0xA0]
00007cc2697d4894  vmovaps xmm12, [rsp+0xB0]
00007cc2697d489d  vmovaps xmm13, [rsp+0xC0]
00007cc2697d48a6  vmovaps xmm14, [rsp+0xD0]
00007cc2697d48af  vmovaps xmm15, [rsp+0xE0]
00007cc2697d48b8  add rsp, 0xF0
00007cc2697d48bf  pop r11
00007cc2697d48c1  pop r10
00007cc2697d48c3  pop r9
00007cc2697d48c5  pop r8
00007cc2697d48c7  pop rsi
00007cc2697d48c8  pop rdi
00007cc2697d48c9  pop rdx
00007cc2697d48ca  pop rcx
00007cc2697d48cb  pop rax
00007cc2697d48cc  add rsp, 0x08
00007cc2697d48d0  jmp 0x00007CC2697D2E44
00007cc2697d48d5  sub rsp, 0x08
00007cc2697d48d9  push rax
00007cc2697d48da  push rcx
00007cc2697d48db  push rdx
00007cc2697d48dc  push rdi
00007cc2697d48dd  push rsi
00007cc2697d48de  push r8
00007cc2697d48e0  push r9
00007cc2697d48e2  push r10
00007cc2697d48e4  push r11
00007cc2697d48e6  sub rsp, 0xF0
00007cc2697d48ed  vmovaps [rsp], xmm0
00007cc2697d48f2  vmovaps [rsp+0x10], xmm1
00007cc2697d48f8  vmovaps [rsp+0x20], xmm2
00007cc2697d48fe  vmovaps [rsp+0x30], xmm3
00007cc2697d4904  vmovaps [rsp+0x40], xmm4
00007cc2697d490a  vmovaps [rsp+0x50], xmm5
00007cc2697d4910  vmovaps [rsp+0x60], xmm6
00007cc2697d4916  vmovaps [rsp+0x70], xmm7
00007cc2697d491c  vmovaps [rsp+0x80], xmm8
00007cc2697d4925  vmovaps [rsp+0x90], xmm9
00007cc2697d492e  vmovaps [rsp+0xA0], xmm11
00007cc2697d4937  vmovaps [rsp+0xB0], xmm12
00007cc2697d4940  vmovaps [rsp+0xC0], xmm13
00007cc2697d4949  vmovaps [rsp+0xD0], xmm14
00007cc2697d4952  vmovaps [rsp+0xE0], xmm15
00007cc2697d495b  sub rsp, 0x40
00007cc2697d495f  lea rdi, [rsp]
00007cc2697d4963  lea rsi, [rsp+0x10]
00007cc2697d4968  lea rdx, [rsp+0x20]
00007cc2697d496d  lea rcx, [rsp+0x30]
00007cc2697d4972  mov r8d, 0x00
00007cc2697d4978  lea r9, [r15+0x3A8]
00007cc2697d497f  movaps [rdi], xmm10
00007cc2697d4983  movaps [rsi], xmm15
00007cc2697d4987  movaps [rdx], xmm1
00007cc2697d498a  movaps [rcx], xmm13
00007cc2697d498e  mov rax, 0x653E5FFFBA50
00007cc2697d4998  call rax
00007cc2697d499a  movaps xmm10, [rsp]
00007cc2697d499f  add rsp, 0x40
00007cc2697d49a3  vmovaps xmm0, [rsp]
00007cc2697d49a8  vmovaps xmm1, [rsp+0x10]
00007cc2697d49ae  vmovaps xmm2, [rsp+0x20]
00007cc2697d49b4  vmovaps xmm3, [rsp+0x30]
00007cc2697d49ba  vmovaps xmm4, [rsp+0x40]
00007cc2697d49c0  vmovaps xmm5, [rsp+0x50]
00007cc2697d49c6  vmovaps xmm6, [rsp+0x60]
00007cc2697d49cc  vmovaps xmm7, [rsp+0x70]
00007cc2697d49d2  vmovaps xmm8, [rsp+0x80]
00007cc2697d49db  vmovaps xmm9, [rsp+0x90]
00007cc2697d49e4  vmovaps xmm11, [rsp+0xA0]
00007cc2697d49ed  vmovaps xmm12, [rsp+0xB0]
00007cc2697d49f6  vmovaps xmm13, [rsp+0xC0]
00007cc2697d49ff  vmovaps xmm14, [rsp+0xD0]
00007cc2697d4a08  vmovaps xmm15, [rsp+0xE0]
00007cc2697d4a11  add rsp, 0xF0
00007cc2697d4a18  pop r11
00007cc2697d4a1a  pop r10
00007cc2697d4a1c  pop r9
00007cc2697d4a1e  pop r8
00007cc2697d4a20  pop rsi
00007cc2697d4a21  pop rdi
00007cc2697d4a22  pop rdx
00007cc2697d4a23  pop rcx
00007cc2697d4a24  pop rax
00007cc2697d4a25  add rsp, 0x08
00007cc2697d4a29  jmp 0x00007CC2697D2E6D
00007cc2697d4a2e  call 0x00007CC2695FF430
00007cc2697d4a33  jmp 0x00007CC2697D2E8F
00007cc2697d4a38  call 0x00007CC26960E760
00007cc2697d4a3d  jmp 0x00007CC2697D2E99
00007cc2697d4a42  sub rsp, 0x08
00007cc2697d4a46  push rax
00007cc2697d4a47  push rcx
00007cc2697d4a48  push rdx
00007cc2697d4a49  push rdi
00007cc2697d4a4a  push rsi
00007cc2697d4a4b  push r8
00007cc2697d4a4d  push r9
00007cc2697d4a4f  push r10
00007cc2697d4a51  push r11
00007cc2697d4a53  sub rsp, 0xF0
00007cc2697d4a5a  vmovaps [rsp], xmm0
00007cc2697d4a5f  vmovaps [rsp+0x10], xmm1
00007cc2697d4a65  vmovaps [rsp+0x20], xmm2
00007cc2697d4a6b  vmovaps [rsp+0x30], xmm3
00007cc2697d4a71  vmovaps [rsp+0x40], xmm4
00007cc2697d4a77  vmovaps [rsp+0x50], xmm5
00007cc2697d4a7d  vmovaps [rsp+0x60], xmm6
00007cc2697d4a83  vmovaps [rsp+0x70], xmm7
00007cc2697d4a89  vmovaps [rsp+0x80], xmm9
00007cc2697d4a92  vmovaps [rsp+0x90], xmm10
00007cc2697d4a9b  vmovaps [rsp+0xA0], xmm11
00007cc2697d4aa4  vmovaps [rsp+0xB0], xmm12
00007cc2697d4aad  vmovaps [rsp+0xC0], xmm13
00007cc2697d4ab6  vmovaps [rsp+0xD0], xmm14
00007cc2697d4abf  vmovaps [rsp+0xE0], xmm15
00007cc2697d4ac8  sub rsp, 0x40
00007cc2697d4acc  lea rdi, [rsp]
00007cc2697d4ad0  lea rsi, [rsp+0x10]
00007cc2697d4ad5  lea rdx, [rsp+0x20]
00007cc2697d4ada  lea rcx, [rsp+0x30]
00007cc2697d4adf  mov r8d, 0x00
00007cc2697d4ae5  lea r9, [r15+0x3A8]
00007cc2697d4aec  movaps [rdi], xmm8
00007cc2697d4af0  movaps [rsi], xmm5
00007cc2697d4af3  movaps [rdx], xmm9
00007cc2697d4af7  movaps [rcx], xmm13
00007cc2697d4afb  mov rax, 0x653E5FFFBA50
00007cc2697d4b05  call rax
00007cc2697d4b07  movaps xmm8, [rsp]
00007cc2697d4b0c  add rsp, 0x40
00007cc2697d4b10  vmovaps xmm0, [rsp]
00007cc2697d4b15  vmovaps xmm1, [rsp+0x10]
00007cc2697d4b1b  vmovaps xmm2, [rsp+0x20]
00007cc2697d4b21  vmovaps xmm3, [rsp+0x30]
00007cc2697d4b27  vmovaps xmm4, [rsp+0x40]
00007cc2697d4b2d  vmovaps xmm5, [rsp+0x50]
00007cc2697d4b33  vmovaps xmm6, [rsp+0x60]
00007cc2697d4b39  vmovaps xmm7, [rsp+0x70]
00007cc2697d4b3f  vmovaps xmm9, [rsp+0x80]
00007cc2697d4b48  vmovaps xmm10, [rsp+0x90]
00007cc2697d4b51  vmovaps xmm11, [rsp+0xA0]
00007cc2697d4b5a  vmovaps xmm12, [rsp+0xB0]
00007cc2697d4b63  vmovaps xmm13, [rsp+0xC0]
00007cc2697d4b6c  vmovaps xmm14, [rsp+0xD0]
00007cc2697d4b75  vmovaps xmm15, [rsp+0xE0]
00007cc2697d4b7e  add rsp, 0xF0
00007cc2697d4b85  pop r11
00007cc2697d4b87  pop r10
00007cc2697d4b89  pop r9
00007cc2697d4b8b  pop r8
00007cc2697d4b8d  pop rsi
00007cc2697d4b8e  pop rdi
00007cc2697d4b8f  pop rdx
00007cc2697d4b90  pop rcx
00007cc2697d4b91  pop rax
00007cc2697d4b92  add rsp, 0x08
00007cc2697d4b96  jmp 0x00007CC2697D2ED8
00007cc2697d4b9b  sub rsp, 0x08
00007cc2697d4b9f  push rax
00007cc2697d4ba0  push rcx
00007cc2697d4ba1  push rdx
00007cc2697d4ba2  push rdi
00007cc2697d4ba3  push rsi
00007cc2697d4ba4  push r8
00007cc2697d4ba6  push r9
00007cc2697d4ba8  push r10
00007cc2697d4baa  push r11
00007cc2697d4bac  sub rsp, 0xF0
00007cc2697d4bb3  vmovaps [rsp], xmm0
00007cc2697d4bb8  vmovaps [rsp+0x10], xmm1
00007cc2697d4bbe  vmovaps [rsp+0x20], xmm2
00007cc2697d4bc4  vmovaps [rsp+0x30], xmm3
00007cc2697d4bca  vmovaps [rsp+0x40], xmm4
00007cc2697d4bd0  vmovaps [rsp+0x50], xmm5
00007cc2697d4bd6  vmovaps [rsp+0x60], xmm6
00007cc2697d4bdc  vmovaps [rsp+0x70], xmm7
00007cc2697d4be2  vmovaps [rsp+0x80], xmm8
00007cc2697d4beb  vmovaps [rsp+0x90], xmm10
00007cc2697d4bf4  vmovaps [rsp+0xA0], xmm11
00007cc2697d4bfd  vmovaps [rsp+0xB0], xmm12
00007cc2697d4c06  vmovaps [rsp+0xC0], xmm13
00007cc2697d4c0f  vmovaps [rsp+0xD0], xmm14
00007cc2697d4c18  vmovaps [rsp+0xE0], xmm15
00007cc2697d4c21  sub rsp, 0x40
00007cc2697d4c25  lea rdi, [rsp]
00007cc2697d4c29  lea rsi, [rsp+0x10]
00007cc2697d4c2e  lea rdx, [rsp+0x20]
00007cc2697d4c33  lea rcx, [rsp+0x30]
00007cc2697d4c38  mov r8d, 0x00
00007cc2697d4c3e  lea r9, [r15+0x3A8]
00007cc2697d4c45  movaps [rdi], xmm9
00007cc2697d4c49  movaps [rsi], xmm12
00007cc2697d4c4d  movaps [rdx], xmm7
00007cc2697d4c50  movaps [rcx], xmm13
00007cc2697d4c54  mov rax, 0x653E5FFFBA50
00007cc2697d4c5e  call rax
00007cc2697d4c60  movaps xmm9, [rsp]
00007cc2697d4c65  add rsp, 0x40
00007cc2697d4c69  vmovaps xmm0, [rsp]
00007cc2697d4c6e  vmovaps xmm1, [rsp+0x10]
00007cc2697d4c74  vmovaps xmm2, [rsp+0x20]
00007cc2697d4c7a  vmovaps xmm3, [rsp+0x30]
00007cc2697d4c80  vmovaps xmm4, [rsp+0x40]
00007cc2697d4c86  vmovaps xmm5, [rsp+0x50]
00007cc2697d4c8c  vmovaps xmm6, [rsp+0x60]
00007cc2697d4c92  vmovaps xmm7, [rsp+0x70]
00007cc2697d4c98  vmovaps xmm8, [rsp+0x80]
00007cc2697d4ca1  vmovaps xmm10, [rsp+0x90]
00007cc2697d4caa  vmovaps xmm11, [rsp+0xA0]
00007cc2697d4cb3  vmovaps xmm12, [rsp+0xB0]
00007cc2697d4cbc  vmovaps xmm13, [rsp+0xC0]
00007cc2697d4cc5  vmovaps xmm14, [rsp+0xD0]
00007cc2697d4cce  vmovaps xmm15, [rsp+0xE0]
00007cc2697d4cd7  add rsp, 0xF0
00007cc2697d4cde  pop r11
00007cc2697d4ce0  pop r10
00007cc2697d4ce2  pop r9
00007cc2697d4ce4  pop r8
00007cc2697d4ce6  pop rsi
00007cc2697d4ce7  pop rdi
00007cc2697d4ce8  pop rdx
00007cc2697d4ce9  pop rcx
00007cc2697d4cea  pop rax
00007cc2697d4ceb  add rsp, 0x08
00007cc2697d4cef  jmp 0x00007CC2697D2F01
00007cc2697d4cf4  sub rsp, 0x08
00007cc2697d4cf8  push rax
00007cc2697d4cf9  push rcx
00007cc2697d4cfa  push rdx
00007cc2697d4cfb  push rdi
00007cc2697d4cfc  push rsi
00007cc2697d4cfd  push r8
00007cc2697d4cff  push r9
00007cc2697d4d01  push r10
00007cc2697d4d03  push r11
00007cc2697d4d05  sub rsp, 0xF0
00007cc2697d4d0c  vmovaps [rsp], xmm0
00007cc2697d4d11  vmovaps [rsp+0x10], xmm1
00007cc2697d4d17  vmovaps [rsp+0x20], xmm2
00007cc2697d4d1d  vmovaps [rsp+0x30], xmm3
00007cc2697d4d23  vmovaps [rsp+0x40], xmm4
00007cc2697d4d29  vmovaps [rsp+0x50], xmm5
00007cc2697d4d2f  vmovaps [rsp+0x60], xmm6
00007cc2697d4d35  vmovaps [rsp+0x70], xmm7
00007cc2697d4d3b  vmovaps [rsp+0x80], xmm8
00007cc2697d4d44  vmovaps [rsp+0x90], xmm9
00007cc2697d4d4d  vmovaps [rsp+0xA0], xmm10
00007cc2697d4d56  vmovaps [rsp+0xB0], xmm11
00007cc2697d4d5f  vmovaps [rsp+0xC0], xmm13
00007cc2697d4d68  vmovaps [rsp+0xD0], xmm14
00007cc2697d4d71  vmovaps [rsp+0xE0], xmm15
00007cc2697d4d7a  sub rsp, 0x40
00007cc2697d4d7e  lea rdi, [rsp]
00007cc2697d4d82  lea rsi, [rsp+0x10]
00007cc2697d4d87  lea rdx, [rsp+0x20]
00007cc2697d4d8c  lea rcx, [rsp+0x30]
00007cc2697d4d91  mov r8d, 0x00
00007cc2697d4d97  lea r9, [r15+0x3A8]
00007cc2697d4d9e  movaps [rdi], xmm12
00007cc2697d4da2  movaps [rsi], xmm11
00007cc2697d4da6  movaps [rdx], xmm6
00007cc2697d4da9  movaps [rcx], xmm13
00007cc2697d4dad  mov rax, 0x653E5FFFBA50
00007cc2697d4db7  call rax
00007cc2697d4db9  movaps xmm12, [rsp]
00007cc2697d4dbe  add rsp, 0x40
00007cc2697d4dc2  vmovaps xmm0, [rsp]
00007cc2697d4dc7  vmovaps xmm1, [rsp+0x10]
00007cc2697d4dcd  vmovaps xmm2, [rsp+0x20]
00007cc2697d4dd3  vmovaps xmm3, [rsp+0x30]
00007cc2697d4dd9  vmovaps xmm4, [rsp+0x40]
00007cc2697d4ddf  vmovaps xmm5, [rsp+0x50]
00007cc2697d4de5  vmovaps xmm6, [rsp+0x60]
00007cc2697d4deb  vmovaps xmm7, [rsp+0x70]
00007cc2697d4df1  vmovaps xmm8, [rsp+0x80]
00007cc2697d4dfa  vmovaps xmm9, [rsp+0x90]
00007cc2697d4e03  vmovaps xmm10, [rsp+0xA0]
00007cc2697d4e0c  vmovaps xmm11, [rsp+0xB0]
00007cc2697d4e15  vmovaps xmm13, [rsp+0xC0]
00007cc2697d4e1e  vmovaps xmm14, [rsp+0xD0]
00007cc2697d4e27  vmovaps xmm15, [rsp+0xE0]
00007cc2697d4e30  add rsp, 0xF0
00007cc2697d4e37  pop r11
00007cc2697d4e39  pop r10
00007cc2697d4e3b  pop r9
00007cc2697d4e3d  pop r8
00007cc2697d4e3f  pop rsi
00007cc2697d4e40  pop rdi
00007cc2697d4e41  pop rdx
00007cc2697d4e42  pop rcx
00007cc2697d4e43  pop rax
00007cc2697d4e44  add rsp, 0x08
00007cc2697d4e48  jmp 0x00007CC2697D2F2A
00007cc2697d4e4d  sub rsp, 0x08
00007cc2697d4e51  push rax
00007cc2697d4e52  push rcx
00007cc2697d4e53  push rdx
00007cc2697d4e54  push rdi
00007cc2697d4e55  push rsi
00007cc2697d4e56  push r8
00007cc2697d4e58  push r9
00007cc2697d4e5a  push r10
00007cc2697d4e5c  push r11
00007cc2697d4e5e  sub rsp, 0xF0
00007cc2697d4e65  vmovaps [rsp], xmm0
00007cc2697d4e6a  vmovaps [rsp+0x10], xmm1
00007cc2697d4e70  vmovaps [rsp+0x20], xmm2
00007cc2697d4e76  vmovaps [rsp+0x30], xmm3
00007cc2697d4e7c  vmovaps [rsp+0x40], xmm4
00007cc2697d4e82  vmovaps [rsp+0x50], xmm5
00007cc2697d4e88  vmovaps [rsp+0x60], xmm6
00007cc2697d4e8e  vmovaps [rsp+0x70], xmm8
00007cc2697d4e94  vmovaps [rsp+0x80], xmm9
00007cc2697d4e9d  vmovaps [rsp+0x90], xmm10
00007cc2697d4ea6  vmovaps [rsp+0xA0], xmm11
00007cc2697d4eaf  vmovaps [rsp+0xB0], xmm12
00007cc2697d4eb8  vmovaps [rsp+0xC0], xmm13
00007cc2697d4ec1  vmovaps [rsp+0xD0], xmm14
00007cc2697d4eca  vmovaps [rsp+0xE0], xmm15
00007cc2697d4ed3  sub rsp, 0x40
00007cc2697d4ed7  lea rdi, [rsp]
00007cc2697d4edb  lea rsi, [rsp+0x10]
00007cc2697d4ee0  lea rdx, [rsp+0x20]
00007cc2697d4ee5  lea rcx, [rsp+0x30]
00007cc2697d4eea  mov r8d, 0x00
00007cc2697d4ef0  lea r9, [r15+0x3A8]
00007cc2697d4ef7  movaps [rdi], xmm7
00007cc2697d4efa  movaps [rsi], xmm10
00007cc2697d4efe  movaps [rdx], xmm11
00007cc2697d4f02  movaps [rcx], xmm13
00007cc2697d4f06  mov rax, 0x653E5FFFBA50
00007cc2697d4f10  call rax
00007cc2697d4f12  movaps xmm7, [rsp]
00007cc2697d4f16  add rsp, 0x40
00007cc2697d4f1a  vmovaps xmm0, [rsp]
00007cc2697d4f1f  vmovaps xmm1, [rsp+0x10]
00007cc2697d4f25  vmovaps xmm2, [rsp+0x20]
00007cc2697d4f2b  vmovaps xmm3, [rsp+0x30]
00007cc2697d4f31  vmovaps xmm4, [rsp+0x40]
00007cc2697d4f37  vmovaps xmm5, [rsp+0x50]
00007cc2697d4f3d  vmovaps xmm6, [rsp+0x60]
00007cc2697d4f43  vmovaps xmm8, [rsp+0x70]
00007cc2697d4f49  vmovaps xmm9, [rsp+0x80]
00007cc2697d4f52  vmovaps xmm10, [rsp+0x90]
00007cc2697d4f5b  vmovaps xmm11, [rsp+0xA0]
00007cc2697d4f64  vmovaps xmm12, [rsp+0xB0]
00007cc2697d4f6d  vmovaps xmm13, [rsp+0xC0]
00007cc2697d4f76  vmovaps xmm14, [rsp+0xD0]
00007cc2697d4f7f  vmovaps xmm15, [rsp+0xE0]
00007cc2697d4f88  add rsp, 0xF0
00007cc2697d4f8f  pop r11
00007cc2697d4f91  pop r10
00007cc2697d4f93  pop r9
00007cc2697d4f95  pop r8
00007cc2697d4f97  pop rsi
00007cc2697d4f98  pop rdi
00007cc2697d4f99  pop rdx
00007cc2697d4f9a  pop rcx
00007cc2697d4f9b  pop rax
00007cc2697d4f9c  add rsp, 0x08
00007cc2697d4fa0  jmp 0x00007CC2697D2F58
00007cc2697d4fa5  call 0x00007CC26960C260
00007cc2697d4faa  jmp 0x00007CC2697D2F62
00007cc2697d4faf  call 0x00007CC269609D70
00007cc2697d4fb4  jmp 0x00007CC2697D2F6C
00007cc2697d4fb9  sub rsp, 0x08
00007cc2697d4fbd  push rax
00007cc2697d4fbe  push rcx
00007cc2697d4fbf  push rdx
00007cc2697d4fc0  push rdi
00007cc2697d4fc1  push rsi
00007cc2697d4fc2  push r8
00007cc2697d4fc4  push r9
00007cc2697d4fc6  push r10
00007cc2697d4fc8  push r11
00007cc2697d4fca  sub rsp, 0xF0
00007cc2697d4fd1  vmovaps [rsp], xmm0
00007cc2697d4fd6  vmovaps [rsp+0x10], xmm1
00007cc2697d4fdc  vmovaps [rsp+0x20], xmm2
00007cc2697d4fe2  vmovaps [rsp+0x30], xmm3
00007cc2697d4fe8  vmovaps [rsp+0x40], xmm4
00007cc2697d4fee  vmovaps [rsp+0x50], xmm5
00007cc2697d4ff4  vmovaps [rsp+0x60], xmm7
00007cc2697d4ffa  vmovaps [rsp+0x70], xmm8
00007cc2697d5000  vmovaps [rsp+0x80], xmm9
00007cc2697d5009  vmovaps [rsp+0x90], xmm10
00007cc2697d5012  vmovaps [rsp+0xA0], xmm11
00007cc2697d501b  vmovaps [rsp+0xB0], xmm12
00007cc2697d5024  vmovaps [rsp+0xC0], xmm13
00007cc2697d502d  vmovaps [rsp+0xD0], xmm14
00007cc2697d5036  vmovaps [rsp+0xE0], xmm15
00007cc2697d503f  sub rsp, 0x40
00007cc2697d5043  lea rdi, [rsp]
00007cc2697d5047  lea rsi, [rsp+0x10]
00007cc2697d504c  lea rdx, [rsp+0x20]
00007cc2697d5051  lea rcx, [rsp+0x30]
00007cc2697d5056  mov r8d, 0x00
00007cc2697d505c  lea r9, [r15+0x3A8]
00007cc2697d5063  movaps [rdi], xmm6
00007cc2697d5066  movaps [rsi], xmm8
00007cc2697d506a  movaps [rdx], xmm15
00007cc2697d506e  movaps [rcx], xmm10
00007cc2697d5072  mov rax, 0x653E5FFFBA50
00007cc2697d507c  call rax
00007cc2697d507e  movaps xmm6, [rsp]
00007cc2697d5082  add rsp, 0x40
00007cc2697d5086  vmovaps xmm0, [rsp]
00007cc2697d508b  vmovaps xmm1, [rsp+0x10]
00007cc2697d5091  vmovaps xmm2, [rsp+0x20]
00007cc2697d5097  vmovaps xmm3, [rsp+0x30]
00007cc2697d509d  vmovaps xmm4, [rsp+0x40]
00007cc2697d50a3  vmovaps xmm5, [rsp+0x50]
00007cc2697d50a9  vmovaps xmm7, [rsp+0x60]
00007cc2697d50af  vmovaps xmm8, [rsp+0x70]
00007cc2697d50b5  vmovaps xmm9, [rsp+0x80]
00007cc2697d50be  vmovaps xmm10, [rsp+0x90]
00007cc2697d50c7  vmovaps xmm11, [rsp+0xA0]
00007cc2697d50d0  vmovaps xmm12, [rsp+0xB0]
00007cc2697d50d9  vmovaps xmm13, [rsp+0xC0]
00007cc2697d50e2  vmovaps xmm14, [rsp+0xD0]
00007cc2697d50eb  vmovaps xmm15, [rsp+0xE0]
00007cc2697d50f4  add rsp, 0xF0
00007cc2697d50fb  pop r11
00007cc2697d50fd  pop r10
00007cc2697d50ff  pop r9
00007cc2697d5101  pop r8
00007cc2697d5103  pop rsi
00007cc2697d5104  pop rdi
00007cc2697d5105  pop rdx
00007cc2697d5106  pop rcx
00007cc2697d5107  pop rax
00007cc2697d5108  add rsp, 0x08
00007cc2697d510c  jmp 0x00007CC2697D2FA4
00007cc2697d5111  sub rsp, 0x08
00007cc2697d5115  push rax
00007cc2697d5116  push rcx
00007cc2697d5117  push rdx
00007cc2697d5118  push rdi
00007cc2697d5119  push rsi
00007cc2697d511a  push r8
00007cc2697d511c  push r9
00007cc2697d511e  push r10
00007cc2697d5120  push r11
00007cc2697d5122  sub rsp, 0xF0
00007cc2697d5129  vmovaps [rsp], xmm0
00007cc2697d512e  vmovaps [rsp+0x10], xmm1
00007cc2697d5134  vmovaps [rsp+0x20], xmm2
00007cc2697d513a  vmovaps [rsp+0x30], xmm3
00007cc2697d5140  vmovaps [rsp+0x40], xmm4
00007cc2697d5146  vmovaps [rsp+0x50], xmm5
00007cc2697d514c  vmovaps [rsp+0x60], xmm6
00007cc2697d5152  vmovaps [rsp+0x70], xmm7
00007cc2697d5158  vmovaps [rsp+0x80], xmm8
00007cc2697d5161  vmovaps [rsp+0x90], xmm9
00007cc2697d516a  vmovaps [rsp+0xA0], xmm11
00007cc2697d5173  vmovaps [rsp+0xB0], xmm12
00007cc2697d517c  vmovaps [rsp+0xC0], xmm13
00007cc2697d5185  vmovaps [rsp+0xD0], xmm14
00007cc2697d518e  vmovaps [rsp+0xE0], xmm15
00007cc2697d5197  sub rsp, 0x40
00007cc2697d519b  lea rdi, [rsp]
00007cc2697d519f  lea rsi, [rsp+0x10]
00007cc2697d51a4  lea rdx, [rsp+0x20]
00007cc2697d51a9  lea rcx, [rsp+0x30]
00007cc2697d51ae  mov r8d, 0x00
00007cc2697d51b4  lea r9, [r15+0x3A8]
00007cc2697d51bb  movaps [rdi], xmm10
00007cc2697d51bf  movaps [rsi], xmm9
00007cc2697d51c3  movaps [rdx], xmm13
00007cc2697d51c7  movaps [rcx], xmm15
00007cc2697d51cb  mov rax, 0x653E5FFFBA50
00007cc2697d51d5  call rax
00007cc2697d51d7  movaps xmm10, [rsp]
00007cc2697d51dc  add rsp, 0x40
00007cc2697d51e0  vmovaps xmm0, [rsp]
00007cc2697d51e5  vmovaps xmm1, [rsp+0x10]
00007cc2697d51eb  vmovaps xmm2, [rsp+0x20]
00007cc2697d51f1  vmovaps xmm3, [rsp+0x30]
00007cc2697d51f7  vmovaps xmm4, [rsp+0x40]
00007cc2697d51fd  vmovaps xmm5, [rsp+0x50]
00007cc2697d5203  vmovaps xmm6, [rsp+0x60]
00007cc2697d5209  vmovaps xmm7, [rsp+0x70]
00007cc2697d520f  vmovaps xmm8, [rsp+0x80]
00007cc2697d5218  vmovaps xmm9, [rsp+0x90]
00007cc2697d5221  vmovaps xmm11, [rsp+0xA0]
00007cc2697d522a  vmovaps xmm12, [rsp+0xB0]
00007cc2697d5233  vmovaps xmm13, [rsp+0xC0]
00007cc2697d523c  vmovaps xmm14, [rsp+0xD0]
00007cc2697d5245  vmovaps xmm15, [rsp+0xE0]
00007cc2697d524e  add rsp, 0xF0
00007cc2697d5255  pop r11
00007cc2697d5257  pop r10
00007cc2697d5259  pop r9
00007cc2697d525b  pop r8
00007cc2697d525d  pop rsi
00007cc2697d525e  pop rdi
00007cc2697d525f  pop rdx
00007cc2697d5260  pop rcx
00007cc2697d5261  pop rax
00007cc2697d5262  add rsp, 0x08
00007cc2697d5266  jmp 0x00007CC2697D2FCD
00007cc2697d526b  sub rsp, 0x08
00007cc2697d526f  push rax
00007cc2697d5270  push rcx
00007cc2697d5271  push rdx
00007cc2697d5272  push rdi
00007cc2697d5273  push rsi
00007cc2697d5274  push r8
00007cc2697d5276  push r9
00007cc2697d5278  push r10
00007cc2697d527a  push r11
00007cc2697d527c  sub rsp, 0xF0
00007cc2697d5283  vmovaps [rsp], xmm0
00007cc2697d5288  vmovaps [rsp+0x10], xmm1
00007cc2697d528e  vmovaps [rsp+0x20], xmm2
00007cc2697d5294  vmovaps [rsp+0x30], xmm3
00007cc2697d529a  vmovaps [rsp+0x40], xmm4
00007cc2697d52a0  vmovaps [rsp+0x50], xmm5
00007cc2697d52a6  vmovaps [rsp+0x60], xmm6
00007cc2697d52ac  vmovaps [rsp+0x70], xmm7
00007cc2697d52b2  vmovaps [rsp+0x80], xmm8
00007cc2697d52bb  vmovaps [rsp+0x90], xmm9
00007cc2697d52c4  vmovaps [rsp+0xA0], xmm10
00007cc2697d52cd  vmovaps [rsp+0xB0], xmm11
00007cc2697d52d6  vmovaps [rsp+0xC0], xmm12
00007cc2697d52df  vmovaps [rsp+0xD0], xmm14
00007cc2697d52e8  vmovaps [rsp+0xE0], xmm15
00007cc2697d52f1  sub rsp, 0x40
00007cc2697d52f5  lea rdi, [rsp]
00007cc2697d52f9  lea rsi, [rsp+0x10]
00007cc2697d52fe  lea rdx, [rsp+0x20]
00007cc2697d5303  lea rcx, [rsp+0x30]
00007cc2697d5308  mov r8d, 0x00
00007cc2697d530e  lea r9, [r15+0x3A8]
00007cc2697d5315  movaps [rdi], xmm13
00007cc2697d5319  movaps [rsi], xmm12
00007cc2697d531d  movaps [rdx], xmm4
00007cc2697d5320  movaps [rcx], xmm15
00007cc2697d5324  mov rax, 0x653E5FFFBA50
00007cc2697d532e  call rax
00007cc2697d5330  movaps xmm13, [rsp]
00007cc2697d5335  add rsp, 0x40
00007cc2697d5339  vmovaps xmm0, [rsp]
00007cc2697d533e  vmovaps xmm1, [rsp+0x10]
00007cc2697d5344  vmovaps xmm2, [rsp+0x20]
00007cc2697d534a  vmovaps xmm3, [rsp+0x30]
00007cc2697d5350  vmovaps xmm4, [rsp+0x40]
00007cc2697d5356  vmovaps xmm5, [rsp+0x50]
00007cc2697d535c  vmovaps xmm6, [rsp+0x60]
00007cc2697d5362  vmovaps xmm7, [rsp+0x70]
00007cc2697d5368  vmovaps xmm8, [rsp+0x80]
00007cc2697d5371  vmovaps xmm9, [rsp+0x90]
00007cc2697d537a  vmovaps xmm10, [rsp+0xA0]
00007cc2697d5383  vmovaps xmm11, [rsp+0xB0]
00007cc2697d538c  vmovaps xmm12, [rsp+0xC0]
00007cc2697d5395  vmovaps xmm14, [rsp+0xD0]
00007cc2697d539e  vmovaps xmm15, [rsp+0xE0]
00007cc2697d53a7  add rsp, 0xF0
00007cc2697d53ae  pop r11
00007cc2697d53b0  pop r10
00007cc2697d53b2  pop r9
00007cc2697d53b4  pop r8
00007cc2697d53b6  pop rsi
00007cc2697d53b7  pop rdi
00007cc2697d53b8  pop rdx
00007cc2697d53b9  pop rcx
00007cc2697d53ba  pop rax
00007cc2697d53bb  add rsp, 0x08
00007cc2697d53bf  jmp 0x00007CC2697D2FF6
00007cc2697d53c4  sub rsp, 0x08
00007cc2697d53c8  push rax
00007cc2697d53c9  push rcx
00007cc2697d53ca  push rdx
00007cc2697d53cb  push rdi
00007cc2697d53cc  push rsi
00007cc2697d53cd  push r8
00007cc2697d53cf  push r9
00007cc2697d53d1  push r10
00007cc2697d53d3  push r11
00007cc2697d53d5  sub rsp, 0xF0
00007cc2697d53dc  vmovaps [rsp], xmm0
00007cc2697d53e1  vmovaps [rsp+0x10], xmm1
00007cc2697d53e7  vmovaps [rsp+0x20], xmm2
00007cc2697d53ed  vmovaps [rsp+0x30], xmm3
00007cc2697d53f3  vmovaps [rsp+0x40], xmm4
00007cc2697d53f9  vmovaps [rsp+0x50], xmm5
00007cc2697d53ff  vmovaps [rsp+0x60], xmm6
00007cc2697d5405  vmovaps [rsp+0x70], xmm7
00007cc2697d540b  vmovaps [rsp+0x80], xmm8
00007cc2697d5414  vmovaps [rsp+0x90], xmm9
00007cc2697d541d  vmovaps [rsp+0xA0], xmm10
00007cc2697d5426  vmovaps [rsp+0xB0], xmm11
00007cc2697d542f  vmovaps [rsp+0xC0], xmm13
00007cc2697d5438  vmovaps [rsp+0xD0], xmm14
00007cc2697d5441  vmovaps [rsp+0xE0], xmm15
00007cc2697d544a  sub rsp, 0x40
00007cc2697d544e  lea rdi, [rsp]
00007cc2697d5452  lea rsi, [rsp+0x10]
00007cc2697d5457  lea rdx, [rsp+0x20]
00007cc2697d545c  lea rcx, [rsp+0x30]
00007cc2697d5461  mov r8d, 0x00
00007cc2697d5467  lea r9, [r15+0x3A8]
00007cc2697d546e  movaps [rdi], xmm12
00007cc2697d5472  movaps [rsi], xmm7
00007cc2697d5475  movaps [rdx], xmm1
00007cc2697d5478  movaps [rcx], xmm15
00007cc2697d547c  mov rax, 0x653E5FFFBA50
00007cc2697d5486  call rax
00007cc2697d5488  movaps xmm12, [rsp]
00007cc2697d548d  add rsp, 0x40
00007cc2697d5491  vmovaps xmm0, [rsp]
00007cc2697d5496  vmovaps xmm1, [rsp+0x10]
00007cc2697d549c  vmovaps xmm2, [rsp+0x20]
00007cc2697d54a2  vmovaps xmm3, [rsp+0x30]
00007cc2697d54a8  vmovaps xmm4, [rsp+0x40]
00007cc2697d54ae  vmovaps xmm5, [rsp+0x50]
00007cc2697d54b4  vmovaps xmm6, [rsp+0x60]
00007cc2697d54ba  vmovaps xmm7, [rsp+0x70]
00007cc2697d54c0  vmovaps xmm8, [rsp+0x80]
00007cc2697d54c9  vmovaps xmm9, [rsp+0x90]
00007cc2697d54d2  vmovaps xmm10, [rsp+0xA0]
00007cc2697d54db  vmovaps xmm11, [rsp+0xB0]
00007cc2697d54e4  vmovaps xmm13, [rsp+0xC0]
00007cc2697d54ed  vmovaps xmm14, [rsp+0xD0]
00007cc2697d54f6  vmovaps xmm15, [rsp+0xE0]
00007cc2697d54ff  add rsp, 0xF0
00007cc2697d5506  pop r11
00007cc2697d5508  pop r10
00007cc2697d550a  pop r9
00007cc2697d550c  pop r8
00007cc2697d550e  pop rsi
00007cc2697d550f  pop rdi
00007cc2697d5510  pop rdx
00007cc2697d5511  pop rcx
00007cc2697d5512  pop rax
00007cc2697d5513  add rsp, 0x08
00007cc2697d5517  jmp 0x00007CC2697D301F
00007cc2697d551c  call 0x00007CC2695FF430
00007cc2697d5521  jmp 0x00007CC2697D3029
00007cc2697d5526  call 0x00007CC26960E760
00007cc2697d552b  jmp 0x00007CC2697D3033
00007cc2697d5530  sub rsp, 0x08
00007cc2697d5534  push rax
00007cc2697d5535  push rcx
00007cc2697d5536  push rdx
00007cc2697d5537  push rdi
00007cc2697d5538  push rsi
00007cc2697d5539  push r8
00007cc2697d553b  push r9
00007cc2697d553d  push r10
00007cc2697d553f  push r11
00007cc2697d5541  sub rsp, 0xF0
00007cc2697d5548  vmovaps [rsp], xmm0
00007cc2697d554d  vmovaps [rsp+0x10], xmm1
00007cc2697d5553  vmovaps [rsp+0x20], xmm2
00007cc2697d5559  vmovaps [rsp+0x30], xmm3
00007cc2697d555f  vmovaps [rsp+0x40], xmm4
00007cc2697d5565  vmovaps [rsp+0x50], xmm5
00007cc2697d556b  vmovaps [rsp+0x60], xmm6
00007cc2697d5571  vmovaps [rsp+0x70], xmm8
00007cc2697d5577  vmovaps [rsp+0x80], xmm9
00007cc2697d5580  vmovaps [rsp+0x90], xmm10
00007cc2697d5589  vmovaps [rsp+0xA0], xmm11
00007cc2697d5592  vmovaps [rsp+0xB0], xmm12
00007cc2697d559b  vmovaps [rsp+0xC0], xmm13
00007cc2697d55a4  vmovaps [rsp+0xD0], xmm14
00007cc2697d55ad  vmovaps [rsp+0xE0], xmm15
00007cc2697d55b6  sub rsp, 0x40
00007cc2697d55ba  lea rdi, [rsp]
00007cc2697d55be  lea rsi, [rsp+0x10]
00007cc2697d55c3  lea rdx, [rsp+0x20]
00007cc2697d55c8  lea rcx, [rsp+0x30]
00007cc2697d55cd  mov r8d, 0x00
00007cc2697d55d3  lea r9, [r15+0x3A8]
00007cc2697d55da  movaps [rdi], xmm7
00007cc2697d55dd  movaps [rsi], xmm6
00007cc2697d55e0  movaps [rdx], xmm8
00007cc2697d55e4  movaps [rcx], xmm9
00007cc2697d55e8  mov rax, 0x653E5FFFBA50
00007cc2697d55f2  call rax
00007cc2697d55f4  movaps xmm7, [rsp]
00007cc2697d55f8  add rsp, 0x40
00007cc2697d55fc  vmovaps xmm0, [rsp]
00007cc2697d5601  vmovaps xmm1, [rsp+0x10]
00007cc2697d5607  vmovaps xmm2, [rsp+0x20]
00007cc2697d560d  vmovaps xmm3, [rsp+0x30]
00007cc2697d5613  vmovaps xmm4, [rsp+0x40]
00007cc2697d5619  vmovaps xmm5, [rsp+0x50]
00007cc2697d561f  vmovaps xmm6, [rsp+0x60]
00007cc2697d5625  vmovaps xmm8, [rsp+0x70]
00007cc2697d562b  vmovaps xmm9, [rsp+0x80]
00007cc2697d5634  vmovaps xmm10, [rsp+0x90]
00007cc2697d563d  vmovaps xmm11, [rsp+0xA0]
00007cc2697d5646  vmovaps xmm12, [rsp+0xB0]
00007cc2697d564f  vmovaps xmm13, [rsp+0xC0]
00007cc2697d5658  vmovaps xmm14, [rsp+0xD0]
00007cc2697d5661  vmovaps xmm15, [rsp+0xE0]
00007cc2697d566a  add rsp, 0xF0
00007cc2697d5671  pop r11
00007cc2697d5673  pop r10
00007cc2697d5675  pop r9
00007cc2697d5677  pop r8
00007cc2697d5679  pop rsi
00007cc2697d567a  pop rdi
00007cc2697d567b  pop rdx
00007cc2697d567c  pop rcx
00007cc2697d567d  pop rax
00007cc2697d567e  add rsp, 0x08
00007cc2697d5682  jmp 0x00007CC2697D305D
00007cc2697d5687  sub rsp, 0x08
00007cc2697d568b  push rax
00007cc2697d568c  push rcx
00007cc2697d568d  push rdx
00007cc2697d568e  push rdi
00007cc2697d568f  push rsi
00007cc2697d5690  push r8
00007cc2697d5692  push r9
00007cc2697d5694  push r10
00007cc2697d5696  push r11
00007cc2697d5698  sub rsp, 0xF0
00007cc2697d569f  vmovaps [rsp], xmm0
00007cc2697d56a4  vmovaps [rsp+0x10], xmm1
00007cc2697d56aa  vmovaps [rsp+0x20], xmm2
00007cc2697d56b0  vmovaps [rsp+0x30], xmm3
00007cc2697d56b6  vmovaps [rsp+0x40], xmm4
00007cc2697d56bc  vmovaps [rsp+0x50], xmm5
00007cc2697d56c2  vmovaps [rsp+0x60], xmm6
00007cc2697d56c8  vmovaps [rsp+0x70], xmm7
00007cc2697d56ce  vmovaps [rsp+0x80], xmm9
00007cc2697d56d7  vmovaps [rsp+0x90], xmm10
00007cc2697d56e0  vmovaps [rsp+0xA0], xmm11
00007cc2697d56e9  vmovaps [rsp+0xB0], xmm12
00007cc2697d56f2  vmovaps [rsp+0xC0], xmm13
00007cc2697d56fb  vmovaps [rsp+0xD0], xmm14
00007cc2697d5704  vmovaps [rsp+0xE0], xmm15
00007cc2697d570d  sub rsp, 0x40
00007cc2697d5711  lea rdi, [rsp]
00007cc2697d5715  lea rsi, [rsp+0x10]
00007cc2697d571a  lea rdx, [rsp+0x20]
00007cc2697d571f  lea rcx, [rsp+0x30]
00007cc2697d5724  mov r8d, 0x00
00007cc2697d572a  lea r9, [r15+0x3A8]
00007cc2697d5731  movaps [rdi], xmm8
00007cc2697d5735  movaps [rsi], xmm10
00007cc2697d5739  movaps [rdx], xmm14
00007cc2697d573d  movaps [rcx], xmm9
00007cc2697d5741  mov rax, 0x653E5FFFBA50
00007cc2697d574b  call rax
00007cc2697d574d  movaps xmm8, [rsp]
00007cc2697d5752  add rsp, 0x40
00007cc2697d5756  vmovaps xmm0, [rsp]
00007cc2697d575b  vmovaps xmm1, [rsp+0x10]
00007cc2697d5761  vmovaps xmm2, [rsp+0x20]
00007cc2697d5767  vmovaps xmm3, [rsp+0x30]
00007cc2697d576d  vmovaps xmm4, [rsp+0x40]
00007cc2697d5773  vmovaps xmm5, [rsp+0x50]
00007cc2697d5779  vmovaps xmm6, [rsp+0x60]
00007cc2697d577f  vmovaps xmm7, [rsp+0x70]
00007cc2697d5785  vmovaps xmm9, [rsp+0x80]
00007cc2697d578e  vmovaps xmm10, [rsp+0x90]
00007cc2697d5797  vmovaps xmm11, [rsp+0xA0]
00007cc2697d57a0  vmovaps xmm12, [rsp+0xB0]
00007cc2697d57a9  vmovaps xmm13, [rsp+0xC0]
00007cc2697d57b2  vmovaps xmm14, [rsp+0xD0]
00007cc2697d57bb  vmovaps xmm15, [rsp+0xE0]
00007cc2697d57c4  add rsp, 0xF0
00007cc2697d57cb  pop r11
00007cc2697d57cd  pop r10
00007cc2697d57cf  pop r9
00007cc2697d57d1  pop r8
00007cc2697d57d3  pop rsi
00007cc2697d57d4  pop rdi
00007cc2697d57d5  pop rdx
00007cc2697d57d6  pop rcx
00007cc2697d57d7  pop rax
00007cc2697d57d8  add rsp, 0x08
00007cc2697d57dc  jmp 0x00007CC2697D3083
00007cc2697d57e1  sub rsp, 0x08
00007cc2697d57e5  push rax
00007cc2697d57e6  push rcx
00007cc2697d57e7  push rdx
00007cc2697d57e8  push rdi
00007cc2697d57e9  push rsi
00007cc2697d57ea  push r8
00007cc2697d57ec  push r9
00007cc2697d57ee  push r10
00007cc2697d57f0  push r11
00007cc2697d57f2  sub rsp, 0xF0
00007cc2697d57f9  vmovaps [rsp], xmm0
00007cc2697d57fe  vmovaps [rsp+0x10], xmm1
00007cc2697d5804  vmovaps [rsp+0x20], xmm2
00007cc2697d580a  vmovaps [rsp+0x30], xmm3
00007cc2697d5810  vmovaps [rsp+0x40], xmm4
00007cc2697d5816  vmovaps [rsp+0x50], xmm5
00007cc2697d581c  vmovaps [rsp+0x60], xmm6
00007cc2697d5822  vmovaps [rsp+0x70], xmm7
00007cc2697d5828  vmovaps [rsp+0x80], xmm8
00007cc2697d5831  vmovaps [rsp+0x90], xmm9
00007cc2697d583a  vmovaps [rsp+0xA0], xmm11
00007cc2697d5843  vmovaps [rsp+0xB0], xmm12
00007cc2697d584c  vmovaps [rsp+0xC0], xmm13
00007cc2697d5855  vmovaps [rsp+0xD0], xmm14
00007cc2697d585e  vmovaps [rsp+0xE0], xmm15
00007cc2697d5867  sub rsp, 0x40
00007cc2697d586b  lea rdi, [rsp]
00007cc2697d586f  lea rsi, [rsp+0x10]
00007cc2697d5874  lea rdx, [rsp+0x20]
00007cc2697d5879  lea rcx, [rsp+0x30]
00007cc2697d587e  mov r8d, 0x00
00007cc2697d5884  lea r9, [r15+0x3A8]
00007cc2697d588b  movaps [rdi], xmm10
00007cc2697d588f  movaps [rsi], xmm13
00007cc2697d5893  movaps [rdx], xmm11
00007cc2697d5897  movaps [rcx], xmm14
00007cc2697d589b  mov rax, 0x653E5FFFBA50
00007cc2697d58a5  call rax
00007cc2697d58a7  movaps xmm10, [rsp]
00007cc2697d58ac  add rsp, 0x40
00007cc2697d58b0  vmovaps xmm0, [rsp]
00007cc2697d58b5  vmovaps xmm1, [rsp+0x10]
00007cc2697d58bb  vmovaps xmm2, [rsp+0x20]
00007cc2697d58c1  vmovaps xmm3, [rsp+0x30]
00007cc2697d58c7  vmovaps xmm4, [rsp+0x40]
00007cc2697d58cd  vmovaps xmm5, [rsp+0x50]
00007cc2697d58d3  vmovaps xmm6, [rsp+0x60]
00007cc2697d58d9  vmovaps xmm7, [rsp+0x70]
00007cc2697d58df  vmovaps xmm8, [rsp+0x80]
00007cc2697d58e8  vmovaps xmm9, [rsp+0x90]
00007cc2697d58f1  vmovaps xmm11, [rsp+0xA0]
00007cc2697d58fa  vmovaps xmm12, [rsp+0xB0]
00007cc2697d5903  vmovaps xmm13, [rsp+0xC0]
00007cc2697d590c  vmovaps xmm14, [rsp+0xD0]
00007cc2697d5915  vmovaps xmm15, [rsp+0xE0]
00007cc2697d591e  add rsp, 0xF0
00007cc2697d5925  pop r11
00007cc2697d5927  pop r10
00007cc2697d5929  pop r9
00007cc2697d592b  pop r8
00007cc2697d592d  pop rsi
00007cc2697d592e  pop rdi
00007cc2697d592f  pop rdx
00007cc2697d5930  pop rcx
00007cc2697d5931  pop rax
00007cc2697d5932  add rsp, 0x08
00007cc2697d5936  jmp 0x00007CC2697D30A9
00007cc2697d593b  sub rsp, 0x08
00007cc2697d593f  push rax
00007cc2697d5940  push rcx
00007cc2697d5941  push rdx
00007cc2697d5942  push rdi
00007cc2697d5943  push rsi
00007cc2697d5944  push r8
00007cc2697d5946  push r9
00007cc2697d5948  push r10
00007cc2697d594a  push r11
00007cc2697d594c  sub rsp, 0xF0
00007cc2697d5953  vmovaps [rsp], xmm0
00007cc2697d5958  vmovaps [rsp+0x10], xmm1
00007cc2697d595e  vmovaps [rsp+0x20], xmm2
00007cc2697d5964  vmovaps [rsp+0x30], xmm3
00007cc2697d596a  vmovaps [rsp+0x40], xmm4
00007cc2697d5970  vmovaps [rsp+0x50], xmm5
00007cc2697d5976  vmovaps [rsp+0x60], xmm6
00007cc2697d597c  vmovaps [rsp+0x70], xmm7
00007cc2697d5982  vmovaps [rsp+0x80], xmm8
00007cc2697d598b  vmovaps [rsp+0x90], xmm9
00007cc2697d5994  vmovaps [rsp+0xA0], xmm10
00007cc2697d599d  vmovaps [rsp+0xB0], xmm11
00007cc2697d59a6  vmovaps [rsp+0xC0], xmm12
00007cc2697d59af  vmovaps [rsp+0xD0], xmm14
00007cc2697d59b8  vmovaps [rsp+0xE0], xmm15
00007cc2697d59c1  sub rsp, 0x40
00007cc2697d59c5  lea rdi, [rsp]
00007cc2697d59c9  lea rsi, [rsp+0x10]
00007cc2697d59ce  lea rdx, [rsp+0x20]
00007cc2697d59d3  lea rcx, [rsp+0x30]
00007cc2697d59d8  mov r8d, 0x00
00007cc2697d59de  lea r9, [r15+0x3A8]
00007cc2697d59e5  movaps [rdi], xmm13
00007cc2697d59e9  movaps [rsi], xmm12
00007cc2697d59ed  movaps [rdx], xmm15
00007cc2697d59f1  movaps [rcx], xmm14
00007cc2697d59f5  mov rax, 0x653E5FFFBA50
00007cc2697d59ff  call rax
00007cc2697d5a01  movaps xmm13, [rsp]
00007cc2697d5a06  add rsp, 0x40
00007cc2697d5a0a  vmovaps xmm0, [rsp]
00007cc2697d5a0f  vmovaps xmm1, [rsp+0x10]
00007cc2697d5a15  vmovaps xmm2, [rsp+0x20]
00007cc2697d5a1b  vmovaps xmm3, [rsp+0x30]
00007cc2697d5a21  vmovaps xmm4, [rsp+0x40]
00007cc2697d5a27  vmovaps xmm5, [rsp+0x50]
00007cc2697d5a2d  vmovaps xmm6, [rsp+0x60]
00007cc2697d5a33  vmovaps xmm7, [rsp+0x70]
00007cc2697d5a39  vmovaps xmm8, [rsp+0x80]
00007cc2697d5a42  vmovaps xmm9, [rsp+0x90]
00007cc2697d5a4b  vmovaps xmm10, [rsp+0xA0]
00007cc2697d5a54  vmovaps xmm11, [rsp+0xB0]
00007cc2697d5a5d  vmovaps xmm12, [rsp+0xC0]
00007cc2697d5a66  vmovaps xmm14, [rsp+0xD0]
00007cc2697d5a6f  vmovaps xmm15, [rsp+0xE0]
00007cc2697d5a78  add rsp, 0xF0
00007cc2697d5a7f  pop r11
00007cc2697d5a81  pop r10
00007cc2697d5a83  pop r9
00007cc2697d5a85  pop r8
00007cc2697d5a87  pop rsi
00007cc2697d5a88  pop rdi
00007cc2697d5a89  pop rdx
00007cc2697d5a8a  pop rcx
00007cc2697d5a8b  pop rax
00007cc2697d5a8c  add rsp, 0x08
00007cc2697d5a90  jmp 0x00007CC2697D30CF
00007cc2697d5a95  call 0x00007CC26960E760
00007cc2697d5a9a  jmp 0x00007CC2697D30DC
00007cc2697d5a9f  call 0x00007CC26960D4E0
00007cc2697d5aa4  jmp 0x00007CC2697D30E9
00007cc2697d5aa9  sub rsp, 0x08
00007cc2697d5aad  push rax
00007cc2697d5aae  push rcx
00007cc2697d5aaf  push rdx
00007cc2697d5ab0  push rdi
00007cc2697d5ab1  push rsi
00007cc2697d5ab2  push r8
00007cc2697d5ab4  push r9
00007cc2697d5ab6  push r10
00007cc2697d5ab8  push r11
00007cc2697d5aba  sub rsp, 0xF0
00007cc2697d5ac1  vmovaps [rsp], xmm0
00007cc2697d5ac6  vmovaps [rsp+0x10], xmm1
00007cc2697d5acc  vmovaps [rsp+0x20], xmm2
00007cc2697d5ad2  vmovaps [rsp+0x30], xmm3
00007cc2697d5ad8  vmovaps [rsp+0x40], xmm4
00007cc2697d5ade  vmovaps [rsp+0x50], xmm5
00007cc2697d5ae4  vmovaps [rsp+0x60], xmm6
00007cc2697d5aea  vmovaps [rsp+0x70], xmm7
00007cc2697d5af0  vmovaps [rsp+0x80], xmm8
00007cc2697d5af9  vmovaps [rsp+0x90], xmm9
00007cc2697d5b02  vmovaps [rsp+0xA0], xmm10
00007cc2697d5b0b  vmovaps [rsp+0xB0], xmm12
00007cc2697d5b14  vmovaps [rsp+0xC0], xmm13
00007cc2697d5b1d  vmovaps [rsp+0xD0], xmm14
00007cc2697d5b26  vmovaps [rsp+0xE0], xmm15
00007cc2697d5b2f  sub rsp, 0x40
00007cc2697d5b33  lea rdi, [rsp]
00007cc2697d5b37  lea rsi, [rsp+0x10]
00007cc2697d5b3c  lea rdx, [rsp+0x20]
00007cc2697d5b41  lea rcx, [rsp+0x30]
00007cc2697d5b46  mov r8d, 0x00
00007cc2697d5b4c  lea r9, [r15+0x3A8]
00007cc2697d5b53  movaps [rdi], xmm11
00007cc2697d5b57  movaps [rsi], xmm7
00007cc2697d5b5a  movaps [rdx], xmm1
00007cc2697d5b5d  movaps [rcx], xmm12
00007cc2697d5b61  mov rax, 0x653E5FFFBA50
00007cc2697d5b6b  call rax
00007cc2697d5b6d  movaps xmm11, [rsp]
00007cc2697d5b72  add rsp, 0x40
00007cc2697d5b76  vmovaps xmm0, [rsp]
00007cc2697d5b7b  vmovaps xmm1, [rsp+0x10]
00007cc2697d5b81  vmovaps xmm2, [rsp+0x20]
00007cc2697d5b87  vmovaps xmm3, [rsp+0x30]
00007cc2697d5b8d  vmovaps xmm4, [rsp+0x40]
00007cc2697d5b93  vmovaps xmm5, [rsp+0x50]
00007cc2697d5b99  vmovaps xmm6, [rsp+0x60]
00007cc2697d5b9f  vmovaps xmm7, [rsp+0x70]
00007cc2697d5ba5  vmovaps xmm8, [rsp+0x80]
00007cc2697d5bae  vmovaps xmm9, [rsp+0x90]
00007cc2697d5bb7  vmovaps xmm10, [rsp+0xA0]
00007cc2697d5bc0  vmovaps xmm12, [rsp+0xB0]
00007cc2697d5bc9  vmovaps xmm13, [rsp+0xC0]
00007cc2697d5bd2  vmovaps xmm14, [rsp+0xD0]
00007cc2697d5bdb  vmovaps xmm15, [rsp+0xE0]
00007cc2697d5be4  add rsp, 0xF0
00007cc2697d5beb  pop r11
00007cc2697d5bed  pop r10
00007cc2697d5bef  pop r9
00007cc2697d5bf1  pop r8
00007cc2697d5bf3  pop rsi
00007cc2697d5bf4  pop rdi
00007cc2697d5bf5  pop rdx
00007cc2697d5bf6  pop rcx
00007cc2697d5bf7  pop rax
00007cc2697d5bf8  add rsp, 0x08
00007cc2697d5bfc  jmp 0x00007CC2697D3122
00007cc2697d5c01  call 0x00007CC2695FF430
00007cc2697d5c06  jmp 0x00007CC2697D3134
00007cc2697d5c0b  sub rsp, 0x08
00007cc2697d5c0f  push rax
00007cc2697d5c10  push rcx
00007cc2697d5c11  push rdx
00007cc2697d5c12  push rdi
00007cc2697d5c13  push rsi
00007cc2697d5c14  push r8
00007cc2697d5c16  push r9
00007cc2697d5c18  push r10
00007cc2697d5c1a  push r11
00007cc2697d5c1c  sub rsp, 0xF0
00007cc2697d5c23  vmovaps [rsp], xmm0
00007cc2697d5c28  vmovaps [rsp+0x10], xmm1
00007cc2697d5c2e  vmovaps [rsp+0x20], xmm2
00007cc2697d5c34  vmovaps [rsp+0x30], xmm3
00007cc2697d5c3a  vmovaps [rsp+0x40], xmm4
00007cc2697d5c40  vmovaps [rsp+0x50], xmm5
00007cc2697d5c46  vmovaps [rsp+0x60], xmm6
00007cc2697d5c4c  vmovaps [rsp+0x70], xmm7
00007cc2697d5c52  vmovaps [rsp+0x80], xmm8
00007cc2697d5c5b  vmovaps [rsp+0x90], xmm10
00007cc2697d5c64  vmovaps [rsp+0xA0], xmm11
00007cc2697d5c6d  vmovaps [rsp+0xB0], xmm12
00007cc2697d5c76  vmovaps [rsp+0xC0], xmm13
00007cc2697d5c7f  vmovaps [rsp+0xD0], xmm14
00007cc2697d5c88  vmovaps [rsp+0xE0], xmm15
00007cc2697d5c91  sub rsp, 0x40
00007cc2697d5c95  lea rdi, [rsp]
00007cc2697d5c99  lea rsi, [rsp+0x10]
00007cc2697d5c9e  lea rdx, [rsp+0x20]
00007cc2697d5ca3  lea rcx, [rsp+0x30]
00007cc2697d5ca8  mov r8d, 0x00
00007cc2697d5cae  lea r9, [r15+0x3A8]
00007cc2697d5cb5  movaps [rdi], xmm9
00007cc2697d5cb9  movaps [rsi], xmm8
00007cc2697d5cbd  movaps [rdx], xmm14
00007cc2697d5cc1  movaps [rcx], xmm12
00007cc2697d5cc5  mov rax, 0x653E5FFFBA50
00007cc2697d5ccf  call rax
00007cc2697d5cd1  movaps xmm9, [rsp]
00007cc2697d5cd6  add rsp, 0x40
00007cc2697d5cda  vmovaps xmm0, [rsp]
00007cc2697d5cdf  vmovaps xmm1, [rsp+0x10]
00007cc2697d5ce5  vmovaps xmm2, [rsp+0x20]
00007cc2697d5ceb  vmovaps xmm3, [rsp+0x30]
00007cc2697d5cf1  vmovaps xmm4, [rsp+0x40]
00007cc2697d5cf7  vmovaps xmm5, [rsp+0x50]
00007cc2697d5cfd  vmovaps xmm6, [rsp+0x60]
00007cc2697d5d03  vmovaps xmm7, [rsp+0x70]
00007cc2697d5d09  vmovaps xmm8, [rsp+0x80]
00007cc2697d5d12  vmovaps xmm10, [rsp+0x90]
00007cc2697d5d1b  vmovaps xmm11, [rsp+0xA0]
00007cc2697d5d24  vmovaps xmm12, [rsp+0xB0]
00007cc2697d5d2d  vmovaps xmm13, [rsp+0xC0]
00007cc2697d5d36  vmovaps xmm14, [rsp+0xD0]
00007cc2697d5d3f  vmovaps xmm15, [rsp+0xE0]
00007cc2697d5d48  add rsp, 0xF0
00007cc2697d5d4f  pop r11
00007cc2697d5d51  pop r10
00007cc2697d5d53  pop r9
00007cc2697d5d55  pop r8
00007cc2697d5d57  pop rsi
00007cc2697d5d58  pop rdi
00007cc2697d5d59  pop rdx
00007cc2697d5d5a  pop rcx
00007cc2697d5d5b  pop rax
00007cc2697d5d5c  add rsp, 0x08
00007cc2697d5d60  jmp 0x00007CC2697D3165
00007cc2697d5d65  sub rsp, 0x08
00007cc2697d5d69  push rax
00007cc2697d5d6a  push rcx
00007cc2697d5d6b  push rdx
00007cc2697d5d6c  push rdi
00007cc2697d5d6d  push rsi
00007cc2697d5d6e  push r8
00007cc2697d5d70  push r9
00007cc2697d5d72  push r10
00007cc2697d5d74  push r11
00007cc2697d5d76  sub rsp, 0xF0
00007cc2697d5d7d  vmovaps [rsp], xmm0
00007cc2697d5d82  vmovaps [rsp+0x10], xmm1
00007cc2697d5d88  vmovaps [rsp+0x20], xmm2
00007cc2697d5d8e  vmovaps [rsp+0x30], xmm3
00007cc2697d5d94  vmovaps [rsp+0x40], xmm4
00007cc2697d5d9a  vmovaps [rsp+0x50], xmm5
00007cc2697d5da0  vmovaps [rsp+0x60], xmm6
00007cc2697d5da6  vmovaps [rsp+0x70], xmm7
00007cc2697d5dac  vmovaps [rsp+0x80], xmm8
00007cc2697d5db5  vmovaps [rsp+0x90], xmm9
00007cc2697d5dbe  vmovaps [rsp+0xA0], xmm10
00007cc2697d5dc7  vmovaps [rsp+0xB0], xmm11
00007cc2697d5dd0  vmovaps [rsp+0xC0], xmm13
00007cc2697d5dd9  vmovaps [rsp+0xD0], xmm14
00007cc2697d5de2  vmovaps [rsp+0xE0], xmm15
00007cc2697d5deb  sub rsp, 0x40
00007cc2697d5def  lea rdi, [rsp]
00007cc2697d5df3  lea rsi, [rsp+0x10]
00007cc2697d5df8  lea rdx, [rsp+0x20]
00007cc2697d5dfd  lea rcx, [rsp+0x30]
00007cc2697d5e02  mov r8d, 0x00
00007cc2697d5e08  lea r9, [r15+0x3A8]
00007cc2697d5e0f  movaps [rdi], xmm12
00007cc2697d5e13  movaps [rsi], xmm10
00007cc2697d5e17  movaps [rdx], xmm15
00007cc2697d5e1b  movaps [rcx], xmm14
00007cc2697d5e1f  mov rax, 0x653E5FFFBA50
00007cc2697d5e29  call rax
00007cc2697d5e2b  movaps xmm12, [rsp]
00007cc2697d5e30  add rsp, 0x40
00007cc2697d5e34  vmovaps xmm0, [rsp]
00007cc2697d5e39  vmovaps xmm1, [rsp+0x10]
00007cc2697d5e3f  vmovaps xmm2, [rsp+0x20]
00007cc2697d5e45  vmovaps xmm3, [rsp+0x30]
00007cc2697d5e4b  vmovaps xmm4, [rsp+0x40]
00007cc2697d5e51  vmovaps xmm5, [rsp+0x50]
00007cc2697d5e57  vmovaps xmm6, [rsp+0x60]
00007cc2697d5e5d  vmovaps xmm7, [rsp+0x70]
00007cc2697d5e63  vmovaps xmm8, [rsp+0x80]
00007cc2697d5e6c  vmovaps xmm9, [rsp+0x90]
00007cc2697d5e75  vmovaps xmm10, [rsp+0xA0]
00007cc2697d5e7e  vmovaps xmm11, [rsp+0xB0]
00007cc2697d5e87  vmovaps xmm13, [rsp+0xC0]
00007cc2697d5e90  vmovaps xmm14, [rsp+0xD0]
00007cc2697d5e99  vmovaps xmm15, [rsp+0xE0]
00007cc2697d5ea2  add rsp, 0xF0
00007cc2697d5ea9  pop r11
00007cc2697d5eab  pop r10
00007cc2697d5ead  pop r9
00007cc2697d5eaf  pop r8
00007cc2697d5eb1  pop rsi
00007cc2697d5eb2  pop rdi
00007cc2697d5eb3  pop rdx
00007cc2697d5eb4  pop rcx
00007cc2697d5eb5  pop rax
00007cc2697d5eb6  add rsp, 0x08
00007cc2697d5eba  jmp 0x00007CC2697D3196
00007cc2697d5ebf  sub rsp, 0x08
00007cc2697d5ec3  push rax
00007cc2697d5ec4  push rcx
00007cc2697d5ec5  push rdx
00007cc2697d5ec6  push rdi
00007cc2697d5ec7  push rsi
00007cc2697d5ec8  push r8
00007cc2697d5eca  push r9
00007cc2697d5ecc  push r10
00007cc2697d5ece  push r11
00007cc2697d5ed0  sub rsp, 0xF0
00007cc2697d5ed7  vmovaps [rsp], xmm0
00007cc2697d5edc  vmovaps [rsp+0x10], xmm1
00007cc2697d5ee2  vmovaps [rsp+0x20], xmm2
00007cc2697d5ee8  vmovaps [rsp+0x30], xmm3
00007cc2697d5eee  vmovaps [rsp+0x40], xmm4
00007cc2697d5ef4  vmovaps [rsp+0x50], xmm5
00007cc2697d5efa  vmovaps [rsp+0x60], xmm6
00007cc2697d5f00  vmovaps [rsp+0x70], xmm7
00007cc2697d5f06  vmovaps [rsp+0x80], xmm8
00007cc2697d5f0f  vmovaps [rsp+0x90], xmm9
00007cc2697d5f18  vmovaps [rsp+0xA0], xmm10
00007cc2697d5f21  vmovaps [rsp+0xB0], xmm11
00007cc2697d5f2a  vmovaps [rsp+0xC0], xmm12
00007cc2697d5f33  vmovaps [rsp+0xD0], xmm13
00007cc2697d5f3c  vmovaps [rsp+0xE0], xmm15
00007cc2697d5f45  sub rsp, 0x40
00007cc2697d5f49  lea rdi, [rsp]
00007cc2697d5f4d  lea rsi, [rsp+0x10]
00007cc2697d5f52  lea rdx, [rsp+0x20]
00007cc2697d5f57  lea rcx, [rsp+0x30]
00007cc2697d5f5c  mov r8d, 0x00
00007cc2697d5f62  lea r9, [r15+0x3A8]
00007cc2697d5f69  movaps [rdi], xmm14
00007cc2697d5f6d  movaps [rsi], xmm13
00007cc2697d5f71  movaps [rdx], xmm1
00007cc2697d5f74  movaps [rcx], xmm15
00007cc2697d5f78  mov rax, 0x653E5FFFBA50
00007cc2697d5f82  call rax
00007cc2697d5f84  movaps xmm14, [rsp]
00007cc2697d5f89  add rsp, 0x40
00007cc2697d5f8d  vmovaps xmm0, [rsp]
00007cc2697d5f92  vmovaps xmm1, [rsp+0x10]
00007cc2697d5f98  vmovaps xmm2, [rsp+0x20]
00007cc2697d5f9e  vmovaps xmm3, [rsp+0x30]
00007cc2697d5fa4  vmovaps xmm4, [rsp+0x40]
00007cc2697d5faa  vmovaps xmm5, [rsp+0x50]
00007cc2697d5fb0  vmovaps xmm6, [rsp+0x60]
00007cc2697d5fb6  vmovaps xmm7, [rsp+0x70]
00007cc2697d5fbc  vmovaps xmm8, [rsp+0x80]
00007cc2697d5fc5  vmovaps xmm9, [rsp+0x90]
00007cc2697d5fce  vmovaps xmm10, [rsp+0xA0]
00007cc2697d5fd7  vmovaps xmm11, [rsp+0xB0]
00007cc2697d5fe0  vmovaps xmm12, [rsp+0xC0]
00007cc2697d5fe9  vmovaps xmm13, [rsp+0xD0]
00007cc2697d5ff2  vmovaps xmm15, [rsp+0xE0]
00007cc2697d5ffb  add rsp, 0xF0
00007cc2697d6002  pop r11
00007cc2697d6004  pop r10
00007cc2697d6006  pop r9
00007cc2697d6008  pop r8
00007cc2697d600a  pop rsi
00007cc2697d600b  pop rdi
00007cc2697d600c  pop rdx
00007cc2697d600d  pop rcx
00007cc2697d600e  pop rax
00007cc2697d600f  add rsp, 0x08
00007cc2697d6013  jmp 0x00007CC2697D31C7
00007cc2697d6018  call 0x00007CC2696079B0
00007cc2697d601d  jmp 0x00007CC2697D31DA
00007cc2697d6022  call 0x00007CC26960B100
00007cc2697d6027  jmp 0x00007CC2697D31E5
00007cc2697d602c  call 0x00007CC269609E90
00007cc2697d6031  jmp 0x00007CC2697D31F0
00007cc2697d6036  call 0x00007CC26960D600
00007cc2697d603b  jmp 0x00007CC2697D31FB
00007cc2697d6040  int3
00007cc2697d6041  nop [rax+rax*1], ax
00007cc2697d604a  nop [rax+rax*1], ax
00007cc2697d6050  mov rax, [r15+0x40]
00007cc2697d6054  mov r14, [r15+0x58]
00007cc2697d6058  lea r12, [rax+r14*1]
00007cc2697d605c  vxorps xmm1, xmm1, xmm1
00007cc2697d6060  vpbroadcastq xmm1, xmm1
00007cc2697d6065  vxorps xmm15, xmm15, xmm15
00007cc2697d606a  vpbroadcastq xmm15, xmm15
00007cc2697d606f  lea rax, [r12+0x30]
00007cc2697d6074  mov r11, [r13+rax*1]
00007cc2697d6079  lea rax, [r12+0x38]
00007cc2697d607e  mov r10, [r13+rax*1]
00007cc2697d6083  movq xmm14, r11
00007cc2697d6088  movq xmm13, r10
00007cc2697d608d  movq xmm14, xmm14
00007cc2697d6092  movq xmm13, xmm13
00007cc2697d6097  vmovaps [rsp+0x10], xmm13
00007cc2697d609d  movq xmm13, xmm13
00007cc2697d60a2  movaps [r15+0x270], xmm13
00007cc2697d60aa  movaps xmm13, [r15+0x160]
00007cc2697d60b2  vmovaps [rsp+0x20], xmm13
00007cc2697d60b8  vmovaps xmm12, [rsp+0x20]
00007cc2697d60be  por xmm13, xmm12
00007cc2697d60c3  lea rax, [r12+0x20]
00007cc2697d60c8  mov r11, [r13+rax*1]
00007cc2697d60cd  lea rax, [r12+0x28]
00007cc2697d60d2  mov r10, [r13+rax*1]
00007cc2697d60d7  movq xmm12, r11
00007cc2697d60dc  movq xmm11, r10
00007cc2697d60e1  movq xmm12, xmm12
00007cc2697d60e6  movq xmm11, xmm11
00007cc2697d60eb  movaps xmm10, [r15+0x2D0]
00007cc2697d60f3  vmovaps [rsp+0x20], xmm10
00007cc2697d60f9  vmovaps xmm9, [rsp+0x20]
00007cc2697d60ff  por xmm10, xmm9
00007cc2697d6104  movaps xmm9, [r15+0x300]
00007cc2697d610c  vmovaps [rsp+0x20], xmm9
00007cc2697d6112  vmovaps xmm8, [rsp+0x20]
00007cc2697d6118  por xmm9, xmm8
00007cc2697d611d  movaps xmm8, [r15+0x2B0]
00007cc2697d6125  vmovaps [rsp+0x20], xmm8
00007cc2697d612b  vmovaps xmm7, [rsp+0x20]
00007cc2697d6131  por xmm8, xmm7
00007cc2697d6136  movaps xmm7, [r15+0x180]
00007cc2697d613e  vmovaps [rsp+0x20], xmm7
00007cc2697d6144  vmovaps xmm6, [rsp+0x20]
00007cc2697d614a  por xmm7, xmm6
00007cc2697d614e  lea rax, [r12+0x10]
00007cc2697d6153  mov r11, [r13+rax*1]
00007cc2697d6158  lea rax, [r12+0x18]
00007cc2697d615d  mov r10, [r13+rax*1]
00007cc2697d6162  movq xmm6, r11
00007cc2697d6167  movq xmm5, r10
00007cc2697d616c  movq xmm6, xmm6
00007cc2697d6170  movq xmm5, xmm5
00007cc2697d6174  movaps xmm4, [r15+0x200]
00007cc2697d617c  vmovaps [rsp+0x20], xmm4
00007cc2697d6182  vmovaps xmm3, [rsp+0x20]
00007cc2697d6188  por xmm4, xmm3
00007cc2697d618c  movaps xmm3, [r15+0x1F0]
00007cc2697d6194  vmovaps [rsp+0x20], xmm3
00007cc2697d619a  vmovaps xmm2, [rsp+0x20]
00007cc2697d61a0  por xmm3, xmm2
00007cc2697d61a4  movaps xmm2, [r15+0x2E0]
00007cc2697d61ac  vmovaps [rsp+0x20], xmm2
00007cc2697d61b2  vmovaps [rsp+0x30], xmm1
00007cc2697d61b8  vmovaps xmm1, [rsp+0x20]
00007cc2697d61be  por xmm2, xmm1
00007cc2697d61c2  movaps xmm1, [r15+0x2A0]
00007cc2697d61ca  vmovaps [rsp+0x20], xmm1
00007cc2697d61d0  vmovaps [rsp+0x40], xmm15
00007cc2697d61d6  vmovaps xmm15, [rsp+0x20]
00007cc2697d61dc  por xmm1, xmm15
00007cc2697d61e1  movaps xmm15, [r15+0x280]
00007cc2697d61e9  vmovaps [rsp+0x20], xmm15
00007cc2697d61ef  vmovaps [rsp+0x50], xmm1
00007cc2697d61f5  vmovaps xmm1, [rsp+0x20]
00007cc2697d61fb  por xmm15, xmm1
00007cc2697d6200  movaps xmm1, [r15+0x1C0]
00007cc2697d6208  vmovaps [rsp+0x20], xmm1
00007cc2697d620e  vmovaps [rsp+0x60], xmm15
00007cc2697d6214  vmovaps xmm15, [rsp+0x20]
00007cc2697d621a  por xmm1, xmm15
00007cc2697d621f  movaps xmm15, [r15+0x210]
00007cc2697d6227  vmovaps [rsp+0x20], xmm15
00007cc2697d622d  vmovaps [rsp+0x70], xmm1
00007cc2697d6233  vmovaps xmm1, [rsp+0x20]
00007cc2697d6239  por xmm15, xmm1
00007cc2697d623e  mov rax, [r13+r12*1]
00007cc2697d6243  vmovq xmm1, rax
00007cc2697d6248  vpbroadcastq xmm1, xmm1
00007cc2697d624d  vmovaps [rsp+0x20], xmm1
00007cc2697d6253  vxorps xmm1, xmm1, xmm1
00007cc2697d6257  vpbroadcastq xmm1, xmm1
00007cc2697d625c  mov rax, [r15+0xF8]
00007cc2697d6263  vmovaps [rsp+0x80], xmm1
00007cc2697d626c  movups xmm1, [r13+rax*1]
00007cc2697d6272  vmovaps [rsp+0x90], xmm1
00007cc2697d627b  vxorps xmm1, xmm1, xmm1
00007cc2697d627f  vpbroadcastq xmm1, xmm1
00007cc2697d6284  lea r11, [r12+0x08]
00007cc2697d6289  mov r12, [r13+r11*1]
00007cc2697d628e  vmovaps [rsp+0xA0], xmm1
00007cc2697d6297  movq xmm1, r12
00007cc2697d629c  movaps [r15+0x240], xmm1
00007cc2697d62a4  mov r12, [r15+0x50]
00007cc2697d62a8  lea r11, [r12+r14*1]
00007cc2697d62ac  mov [r15+0x60], r11
00007cc2697d62b0  lea r12, [r14+0x40]
00007cc2697d62b4  mov [r15+0x58], r12
00007cc2697d62b8  vmovaps xmm1, [rsp+0x30]
00007cc2697d62be  vmovaps [rsp+0x30], xmm15
00007cc2697d62c4  vmovaps xmm15, [rsp+0x90]
00007cc2697d62cd  vmovaps [rsp+0x90], xmm14
00007cc2697d62d6  vmovaps xmm14, [rsp+0x20]
00007cc2697d62dc  vmovaps [rsp+0x20], xmm13
00007cc2697d62e2  vmovaps [rsp+0xB0], xmm12
00007cc2697d62eb  movaps xmm13, xmm1
00007cc2697d62ef  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d62fa  vptest xmm12, xmm12
00007cc2697d62ff  jnz 0x00007CC2697D6D9C
00007cc2697d6305  movaps xmm1, [r15+0x250]
00007cc2697d630d  vmovaps xmm15, [rsp+0x40]
00007cc2697d6313  vmovaps [rsp+0x40], xmm13
00007cc2697d6319  movaps xmm12, xmm15
00007cc2697d631d  vfmadd231pd xmm12, xmm1, xmm14
00007cc2697d6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007cc2697d6328  vptest xmm13, xmm13
00007cc2697d632d  jnz 0x00007CC2697D6EF5
00007cc2697d6333  movaps xmm15, [r15+0x1E0]
00007cc2697d633b  vmovaps [rsp+0xC0], xmm15
00007cc2697d6344  vmovaps xmm13, [rsp+0xC0]
00007cc2697d634d  por xmm15, xmm13
00007cc2697d6352  movaps xmm13, [r15+0x1D0]
00007cc2697d635a  vmovaps [rsp+0xC0], xmm13
00007cc2697d6363  vmovaps [rsp+0xD0], xmm1
00007cc2697d636c  vmovaps xmm1, [rsp+0xC0]
00007cc2697d6375  por xmm13, xmm1
00007cc2697d637a  movaps xmm1, [r15+0x2C0]
00007cc2697d6382  vmovaps [rsp+0xC0], xmm1
00007cc2697d638b  vmovaps [rsp+0xE0], xmm15
00007cc2697d6394  vmovaps xmm15, [rsp+0xC0]
00007cc2697d639d  por xmm1, xmm15
00007cc2697d63a2  movaps xmm15, [r15+0x290]
00007cc2697d63aa  vmovaps [rsp+0xC0], xmm15
00007cc2697d63b3  vmovaps [rsp+0xF0], xmm1
00007cc2697d63bc  vmovaps xmm1, [rsp+0xC0]
00007cc2697d63c5  por xmm15, xmm1
00007cc2697d63ca  movaps xmm1, [r15+0x260]
00007cc2697d63d2  vmovaps [rsp+0xC0], xmm1
00007cc2697d63db  vmovaps [rsp+0x100], xmm15
00007cc2697d63e4  vmovaps xmm15, [rsp+0xC0]
00007cc2697d63ed  por xmm1, xmm15
00007cc2697d63f2  vmovaps xmm15, [rsp+0xD0]
00007cc2697d63fb  vmovaps [rsp+0xC0], xmm1
00007cc2697d6404  vmovaps xmm1, [rsp+0xD0]
00007cc2697d640d  por xmm15, xmm1
00007cc2697d6412  lea r14, [rax+0xC0]
00007cc2697d6419  movups xmm1, [r13+r14*1]
00007cc2697d641f  mov [rsp+0xD0], rax
00007cc2697d6427  xor eax, eax
00007cc2697d6429  mov r14d, 0x200
00007cc2697d642f  cmp r12, r14
00007cc2697d6432  cmc
00007cc2697d6433  lahf
00007cc2697d6434  seto al
00007cc2697d6437  mov [r15+0x108], eax
00007cc2697d643e  vmovaps [rsp+0x110], xmm1
00007cc2697d6447  vmovaps xmm1, [rsp+0x80]
00007cc2697d6450  vmovaps [rsp+0x80], xmm15
00007cc2697d6459  vmovaps xmm15, [rsp+0x110]
00007cc2697d6462  vmovaps [rsp+0x110], xmm13
00007cc2697d646b  vmovaps [rsp+0x120], xmm12
00007cc2697d6474  movaps xmm13, xmm1
00007cc2697d6478  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d6483  vptest xmm12, xmm12
00007cc2697d6488  jnz 0x00007CC2697D7058
00007cc2697d648e  mov rax, [rsp+0xD0]
00007cc2697d6496  lea r14, [rax+0xB0]
00007cc2697d649d  movups xmm1, [r13+r14*1]
00007cc2697d64a3  vmovaps xmm15, [rsp+0xA0]
00007cc2697d64ac  vmovaps [rsp+0xA0], xmm13
00007cc2697d64b5  movaps xmm12, xmm15
00007cc2697d64b9  vfmadd231pd xmm12, xmm1, xmm14
00007cc2697d64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007cc2697d64c4  vptest xmm13, xmm13
00007cc2697d64c9  jnz 0x00007CC2697D71BB
00007cc2697d64cf  vmovaps xmm1, [rsp+0x30]
00007cc2697d64d5  vmovaps xmm15, [rsp+0x30]
00007cc2697d64db  por xmm1, xmm15
00007cc2697d64e0  movaps [r15+0x210], xmm1
00007cc2697d64e8  vmovaps xmm15, [rsp+0x70]
00007cc2697d64ee  vmovaps xmm14, [rsp+0x70]
00007cc2697d64f4  por xmm15, xmm14
00007cc2697d64f9  movaps [r15+0x1C0], xmm15
00007cc2697d6501  vmovaps xmm14, [rsp+0x60]
00007cc2697d6507  vmovaps xmm13, [rsp+0x60]
00007cc2697d650d  por xmm14, xmm13
00007cc2697d6512  movaps [r15+0x280], xmm14
00007cc2697d651a  vmovaps xmm13, [rsp+0x50]
00007cc2697d6520  vmovaps [rsp+0x30], xmm1
00007cc2697d6526  vmovaps xmm1, [rsp+0x50]
00007cc2697d652c  por xmm13, xmm1
00007cc2697d6531  movaps [r15+0x2A0], xmm13
00007cc2697d6539  vmovaps [rsp+0x50], xmm2
00007cc2697d653f  vmovaps xmm1, [rsp+0x50]
00007cc2697d6545  por xmm2, xmm1
00007cc2697d6549  movaps [r15+0x2E0], xmm2
00007cc2697d6551  vmovaps [rsp+0x50], xmm3
00007cc2697d6557  vmovaps xmm1, [rsp+0x50]
00007cc2697d655d  por xmm3, xmm1
00007cc2697d6561  movaps [r15+0x1F0], xmm3
00007cc2697d6569  vmovaps xmm1, [rsp+0x80]
00007cc2697d6572  vmovaps [rsp+0x50], xmm15
00007cc2697d6578  vmovaps xmm15, [rsp+0x80]
00007cc2697d6581  por xmm1, xmm15
00007cc2697d6586  movaps [r15+0x250], xmm1
00007cc2697d658e  vmovaps xmm1, [rsp+0xC0]
00007cc2697d6597  vmovaps xmm15, [rsp+0xC0]
00007cc2697d65a0  por xmm1, xmm15
00007cc2697d65a5  movaps [r15+0x260], xmm1
00007cc2697d65ad  vmovaps xmm15, [rsp+0x100]
00007cc2697d65b6  vmovaps [rsp+0x60], xmm1
00007cc2697d65bc  vmovaps xmm1, [rsp+0x100]
00007cc2697d65c5  por xmm15, xmm1
00007cc2697d65ca  movaps [r15+0x290], xmm15
00007cc2697d65d2  vmovaps xmm1, [rsp+0xF0]
00007cc2697d65db  vmovaps [rsp+0x70], xmm15
00007cc2697d65e1  vmovaps xmm15, [rsp+0xF0]
00007cc2697d65ea  por xmm1, xmm15
00007cc2697d65ef  movaps [r15+0x2C0], xmm1
00007cc2697d65f7  movq xmm15, qword ptr [r15+0x240]
00007cc2697d6600  vmovaps [rsp+0x80], xmm15
00007cc2697d6609  vpermilpd xmm15, xmm15, 0x00
00007cc2697d660f  vmovaps [rsp+0xC0], xmm1
00007cc2697d6618  vmovaps xmm1, [rsp+0x40]
00007cc2697d661e  vmovaps [rsp+0x40], xmm15
00007cc2697d6624  vmovaps xmm15, [rsp+0x30]
00007cc2697d662a  vmovaps [rsp+0x30], xmm14
00007cc2697d6630  vmovaps xmm14, [rsp+0x40]
00007cc2697d6636  vmovaps [rsp+0x40], xmm13
00007cc2697d663c  vmovaps [rsp+0xD0], xmm12
00007cc2697d6645  movaps xmm13, xmm1
00007cc2697d6649  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d6654  vptest xmm12, xmm12
00007cc2697d6659  jnz 0x00007CC2697D7314
00007cc2697d665f  vmovaps xmm1, [rsp+0x80]
00007cc2697d6668  vpermilpd xmm1, xmm1, 0x00
00007cc2697d666e  vmovaps xmm15, [rsp+0xA0]
00007cc2697d6677  movaps xmm14, xmm15
00007cc2697d667b  vfmadd231pd xmm14, xmm2, xmm1
00007cc2697d6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007cc2697d6686  vptest xmm12, xmm12
00007cc2697d668b  jnz 0x00007CC2697D746D
00007cc2697d6691  vmovaps xmm1, [rsp+0x80]
00007cc2697d669a  vpermilpd xmm1, xmm1, 0x00
00007cc2697d66a0  vmovaps xmm15, [rsp+0x120]
00007cc2697d66a9  vmovaps xmm12, [rsp+0x50]
00007cc2697d66af  vmovaps [rsp+0x50], xmm14
00007cc2697d66b5  movaps xmm2, xmm15
00007cc2697d66b9  vfmadd231pd xmm2, xmm12, xmm1
00007cc2697d66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007cc2697d66c3  vptest xmm14, xmm14
00007cc2697d66c8  jnz 0x00007CC2697D75C5
00007cc2697d66ce  vmovaps xmm1, [rsp+0x110]
00007cc2697d66d7  vmovaps xmm15, [rsp+0x110]
00007cc2697d66e0  por xmm1, xmm15
00007cc2697d66e5  movaps [r15+0x1D0], xmm1
00007cc2697d66ed  vmovaps xmm15, [rsp+0x80]
00007cc2697d66f6  vpermilpd xmm15, xmm15, 0x00
00007cc2697d66fc  vmovaps xmm14, [rsp+0xD0]
00007cc2697d6705  vmovaps [rsp+0x80], xmm1
00007cc2697d670e  movaps xmm12, xmm14
00007cc2697d6712  vfmadd231pd xmm12, xmm3, xmm15
00007cc2697d6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007cc2697d671d  vptest xmm1, xmm1
00007cc2697d6722  jnz 0x00007CC2697D771C
00007cc2697d6728  vmovaps [rsp+0xA0], xmm4
00007cc2697d6731  vmovaps xmm1, [rsp+0xA0]
00007cc2697d673a  por xmm4, xmm1
00007cc2697d673e  movaps [r15+0x200], xmm4
00007cc2697d6746  vmovaps xmm1, [rsp+0xE0]
00007cc2697d674f  vmovaps xmm15, [rsp+0xE0]
00007cc2697d6758  por xmm1, xmm15
00007cc2697d675d  movaps [r15+0x1E0], xmm1
00007cc2697d6765  vmovaps [rsp+0xA0], xmm8
00007cc2697d676e  vmovaps xmm1, [rsp+0xA0]
00007cc2697d6777  por xmm8, xmm1
00007cc2697d677c  movaps [r15+0x2B0], xmm8
00007cc2697d6784  vmovaps [rsp+0xA0], xmm9
00007cc2697d678d  vmovaps xmm1, [rsp+0xA0]
00007cc2697d6796  por xmm9, xmm1
00007cc2697d679b  movaps [r15+0x300], xmm9
00007cc2697d67a3  vmovaps [rsp+0xA0], xmm6
00007cc2697d67ac  vpermilpd xmm6, xmm6, 0x00
00007cc2697d67b2  vmovaps xmm14, [rsp+0x60]
00007cc2697d67b8  movaps xmm9, xmm13
00007cc2697d67bc  vfmadd231pd xmm9, xmm14, xmm6
00007cc2697d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007cc2697d67c7  vptest xmm3, xmm3
00007cc2697d67cc  jnz 0x00007CC2697D7875
00007cc2697d67d2  vmovaps xmm14, [rsp+0xA0]
00007cc2697d67db  vpermilpd xmm14, xmm14, 0x00
00007cc2697d67e1  vmovaps xmm13, [rsp+0x50]
00007cc2697d67e7  vmovaps xmm6, [rsp+0xC0]
00007cc2697d67f0  vmovaps [rsp+0x50], xmm1
00007cc2697d67f6  movaps xmm3, xmm13
00007cc2697d67fa  vfmadd231pd xmm3, xmm6, xmm14
00007cc2697d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007cc2697d6804  vptest xmm1, xmm1
00007cc2697d6809  jnz 0x00007CC2697D79CE
00007cc2697d680f  vmovaps xmm1, [rsp+0xA0]
00007cc2697d6818  vpermilpd xmm1, xmm1, 0x00
00007cc2697d681e  vmovaps xmm14, [rsp+0x30]
00007cc2697d6824  movaps xmm6, xmm2
00007cc2697d6827  vfmadd231pd xmm6, xmm14, xmm1
00007cc2697d682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007cc2697d6831  vptest xmm13, xmm13
00007cc2697d6836  jnz 0x00007CC2697D7B25
00007cc2697d683c  vmovaps xmm1, [rsp+0xA0]
00007cc2697d6845  vpermilpd xmm1, xmm1, 0x00
00007cc2697d684b  vmovaps xmm14, [rsp+0x80]
00007cc2697d6854  movaps xmm13, xmm12
00007cc2697d6858  vfmadd231pd xmm13, xmm14, xmm1
00007cc2697d685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007cc2697d6863  vptest xmm2, xmm2
00007cc2697d6868  jnz 0x00007CC2697D7C7B
00007cc2697d686e  vmovaps [rsp+0x30], xmm7
00007cc2697d6874  vmovaps xmm1, [rsp+0x30]
00007cc2697d687a  por xmm7, xmm1
00007cc2697d687e  movaps [r15+0x180], xmm7
00007cc2697d6886  vmovaps [rsp+0x30], xmm10
00007cc2697d688c  vmovaps xmm1, [rsp+0x30]
00007cc2697d6892  por xmm10, xmm1
00007cc2697d6897  movaps [r15+0x2D0], xmm10
00007cc2697d689f  vmovaps [rsp+0x30], xmm5
00007cc2697d68a5  vpermilpd xmm5, xmm5, 0x00
00007cc2697d68ab  vmovaps xmm14, [rsp+0x50]
00007cc2697d68b1  movaps xmm12, xmm3
00007cc2697d68b5  vfmadd231pd xmm12, xmm14, xmm5
00007cc2697d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007cc2697d68c0  vptest xmm10, xmm10
00007cc2697d68c5  jnz 0x00007CC2697D7DD4
00007cc2697d68cb  vmovaps xmm14, [rsp+0x30]
00007cc2697d68d1  vpermilpd xmm14, xmm14, 0x00
00007cc2697d68d7  movaps xmm10, xmm9
00007cc2697d68db  vfmadd231pd xmm10, xmm7, xmm14
00007cc2697d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007cc2697d68e6  vptest xmm5, xmm5
00007cc2697d68eb  jnz 0x00007CC2697D7F2C
00007cc2697d68f1  lea r14, [rax+0x80]
00007cc2697d68f8  movups xmm14, [r13+r14*1]
00007cc2697d68fe  movaps [r15+0x2F0], xmm14
00007cc2697d6906  vmovaps xmm9, [rsp+0x30]
00007cc2697d690c  vpermilpd xmm9, xmm9, 0x00
00007cc2697d6912  vmovaps xmm7, [rsp+0x70]
00007cc2697d6918  movaps xmm5, xmm6
00007cc2697d691b  vfmadd231pd xmm5, xmm7, xmm9
00007cc2697d6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007cc2697d6925  vptest xmm3, xmm3
00007cc2697d692a  jnz 0x00007CC2697D808F
00007cc2697d6930  vmovaps xmm9, [rsp+0x30]
00007cc2697d6936  vpermilpd xmm9, xmm9, 0x00
00007cc2697d693c  movaps xmm7, xmm13
00007cc2697d6940  vfmadd231pd xmm7, xmm1, xmm9
00007cc2697d6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2697d694a  vptest xmm6, xmm6
00007cc2697d694f  jnz 0x00007CC2697D81E5
00007cc2697d6955  vmovaps xmm1, [rsp+0x20]
00007cc2697d695b  vmovaps xmm13, [rsp+0x20]
00007cc2697d6961  por xmm1, xmm13
00007cc2697d6966  movaps [r15+0x160], xmm1
00007cc2697d696e  lea r14, [rax+0x40]
00007cc2697d6972  movups xmm13, [r13+r14*1]
00007cc2697d6978  lea r14, [rax+0x50]
00007cc2697d697c  movups xmm9, [r13+r14*1]
00007cc2697d6982  movaps [r15+0x1B0], xmm13
00007cc2697d698a  movaps [r15+0x1A0], xmm9
00007cc2697d6992  movaps xmm6, [r15+0x190]
00007cc2697d699a  vmovaps xmm3, [rsp+0xB0]
00007cc2697d69a3  vpermilpd xmm3, xmm3, 0x00
00007cc2697d69a9  vmovaps [rsp+0x20], xmm1
00007cc2697d69af  movaps xmm2, xmm12
00007cc2697d69b3  vfmadd231pd xmm2, xmm6, xmm3
00007cc2697d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007cc2697d69bd  vptest xmm1, xmm1
00007cc2697d69c2  jnz 0x00007CC2697D8350
00007cc2697d69c8  vmovaps xmm1, [rsp+0xB0]
00007cc2697d69d1  vpermilpd xmm1, xmm1, 0x00
00007cc2697d69d7  vmovaps xmm12, [rsp+0x20]
00007cc2697d69dd  movaps xmm6, xmm10
00007cc2697d69e1  vfmadd231pd xmm6, xmm12, xmm1
00007cc2697d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007cc2697d69eb  vptest xmm3, xmm3
00007cc2697d69f0  jnz 0x00007CC2697D84A6
00007cc2697d69f6  vmovaps xmm1, [rsp+0xB0]
00007cc2697d69ff  vpermilpd xmm1, xmm1, 0x00
00007cc2697d6a05  vmovaps xmm12, [rsp+0x40]
00007cc2697d6a0b  movaps xmm10, xmm5
00007cc2697d6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007cc2697d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007cc2697d6a1a  vptest xmm3, xmm3
00007cc2697d6a1f  jnz 0x00007CC2697D85FD
00007cc2697d6a25  vmovaps xmm1, [rsp+0xB0]
00007cc2697d6a2e  vpermilpd xmm1, xmm1, 0x00
00007cc2697d6a34  movaps xmm12, xmm7
00007cc2697d6a38  vfmadd231pd xmm12, xmm15, xmm1
00007cc2697d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007cc2697d6a43  vptest xmm5, xmm5
00007cc2697d6a48  jnz 0x00007CC2697D8755
00007cc2697d6a4e  lea r14, [rax+0x60]
00007cc2697d6a52  movups xmm1, [r13+r14*1]
00007cc2697d6a58  lea r14, [rax+0x70]
00007cc2697d6a5c  movups xmm15, [r13+r14*1]
00007cc2697d6a62  movaps [r15+0x150], xmm1
00007cc2697d6a6a  movaps [r15+0x120], xmm15
00007cc2697d6a72  vmovaps [rsp+0x20], xmm11
00007cc2697d6a78  vpermilpd xmm11, xmm11, 0x00
00007cc2697d6a7e  movaps xmm7, xmm2
00007cc2697d6a81  vfmadd231pd xmm7, xmm9, xmm11
00007cc2697d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007cc2697d6a8b  vptest xmm5, xmm5
00007cc2697d6a90  jnz 0x00007CC2697D88C1
00007cc2697d6a96  vmovaps xmm11, [rsp+0x20]
00007cc2697d6a9c  vpermilpd xmm11, xmm11, 0x00
00007cc2697d6aa2  movaps xmm9, xmm6
00007cc2697d6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007cc2697d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007cc2697d6ab1  vptest xmm5, xmm5
00007cc2697d6ab6  jnz 0x00007CC2697D8A18
00007cc2697d6abc  vmovaps xmm1, [rsp+0x20]
00007cc2697d6ac2  vpermilpd xmm1, xmm1, 0x00
00007cc2697d6ac8  movaps xmm11, xmm10
00007cc2697d6acc  vfmadd231pd xmm11, xmm8, xmm1
00007cc2697d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007cc2697d6ad7  vptest xmm6, xmm6
00007cc2697d6adc  jnz 0x00007CC2697D8B70
00007cc2697d6ae2  vmovaps xmm1, [rsp+0x20]
00007cc2697d6ae8  vpermilpd xmm1, xmm1, 0x00
00007cc2697d6aee  movaps xmm10, xmm12
00007cc2697d6af2  vfmadd231pd xmm10, xmm13, xmm1
00007cc2697d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007cc2697d6afd  vptest xmm8, xmm8
00007cc2697d6b02  jnz 0x00007CC2697D8CC9
00007cc2697d6b08  lea r14, [rax+0x20]
00007cc2697d6b0c  movups xmm1, [r13+r14*1]
00007cc2697d6b12  lea r14, [rax+0x30]
00007cc2697d6b16  movups xmm13, [r13+r14*1]
00007cc2697d6b1c  vmovaps xmm12, [rsp+0x90]
00007cc2697d6b25  vpermilpd xmm12, xmm12, 0x00
00007cc2697d6b2b  movaps xmm8, xmm7
00007cc2697d6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007cc2697d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007cc2697d6b3a  vptest xmm6, xmm6
00007cc2697d6b3f  jnz 0x00007CC2697D8E36
00007cc2697d6b45  vmovaps xmm12, [rsp+0x90]
00007cc2697d6b4e  vpermilpd xmm12, xmm12, 0x00
00007cc2697d6b54  movaps xmm7, xmm9
00007cc2697d6b58  vfmadd231pd xmm7, xmm14, xmm12
00007cc2697d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2697d6b62  vptest xmm6, xmm6
00007cc2697d6b67  jnz 0x00007CC2697D8F8E
00007cc2697d6b6d  vmovaps xmm14, [rsp+0x90]
00007cc2697d6b76  vpermilpd xmm14, xmm14, 0x00
00007cc2697d6b7c  movaps xmm12, xmm11
00007cc2697d6b80  vfmadd231pd xmm12, xmm15, xmm14
00007cc2697d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007cc2697d6b8b  vptest xmm9, xmm9
00007cc2697d6b90  jnz 0x00007CC2697D90E6
00007cc2697d6b96  vmovaps xmm15, [rsp+0x90]
00007cc2697d6b9f  vpermilpd xmm15, xmm15, 0x00
00007cc2697d6ba5  movaps xmm11, xmm10
00007cc2697d6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007cc2697d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007cc2697d6bb4  vptest xmm14, xmm14
00007cc2697d6bb9  jnz 0x00007CC2697D9240
00007cc2697d6bbf  lea r14, [rax+0x90]
00007cc2697d6bc6  movups xmm15, [r13+r14*1]
00007cc2697d6bcc  lea r14, [rax+0xA0]
00007cc2697d6bd3  movups xmm14, [r13+r14*1]
00007cc2697d6bd9  movaps [r15+0x140], xmm15
00007cc2697d6be1  movaps [r15+0x130], xmm14
00007cc2697d6be9  vmovaps xmm13, [rsp+0x10]
00007cc2697d6bef  vpermilpd xmm13, xmm13, 0x00
00007cc2697d6bf5  movaps xmm10, xmm8
00007cc2697d6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007cc2697d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007cc2697d6c04  vptest xmm9, xmm9
00007cc2697d6c09  jnz 0x00007CC2697D93AE
00007cc2697d6c0f  movaps [r15+0x220], xmm10
00007cc2697d6c17  lea r14, [rax+0x10]
00007cc2697d6c1b  movups xmm1, [r13+r14*1]
00007cc2697d6c21  movaps [r15+0x240], xmm1
00007cc2697d6c29  vmovaps xmm13, [rsp+0x10]
00007cc2697d6c2f  vpermilpd xmm13, xmm13, 0x00
00007cc2697d6c35  movaps xmm9, xmm7
00007cc2697d6c39  vfmadd231pd xmm9, xmm14, xmm13
00007cc2697d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007cc2697d6c44  vptest xmm8, xmm8
00007cc2697d6c49  jnz 0x00007CC2697D9511
00007cc2697d6c4f  movaps [r15+0x110], xmm9
00007cc2697d6c57  vmovaps xmm14, [rsp+0x10]
00007cc2697d6c5d  vpermilpd xmm14, xmm14, 0x00
00007cc2697d6c63  movaps xmm13, xmm12
00007cc2697d6c67  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007cc2697d6c72  vptest xmm8, xmm8
00007cc2697d6c77  jnz 0x00007CC2697D966A
00007cc2697d6c7d  movaps [r15+0x170], xmm13
00007cc2697d6c85  vmovaps xmm15, [rsp+0x10]
00007cc2697d6c8b  vpermilpd xmm15, xmm15, 0x00
00007cc2697d6c91  movaps xmm14, xmm11
00007cc2697d6c95  vfmadd231pd xmm14, xmm1, xmm15
00007cc2697d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007cc2697d6ca0  vptest xmm12, xmm12
00007cc2697d6ca5  jnz 0x00007CC2697D97C4
00007cc2697d6cab  movaps [r15+0x230], xmm14
00007cc2697d6cb3  movups [r13+r11*1], xmm9
00007cc2697d6cb9  lea rax, [r11+0x10]
00007cc2697d6cbd  movups [r13+rax*1], xmm13
00007cc2697d6cc3  lea rax, [r11+0x20]
00007cc2697d6cc7  movups [r13+rax*1], xmm10
00007cc2697d6ccd  lea rax, [r11+0x30]
00007cc2697d6cd1  movups [r13+rax*1], xmm14
00007cc2697d6cd7  mov eax, [r15+0x108]
00007cc2697d6cde  sahf
00007cc2697d6cdf  jnz 0x00007CC2697D6D11
00007cc2697d6ce1  cmp dword ptr [r15+0x318], 0x00
00007cc2697d6ce9  jz 0x00007CC2697D9950
00007cc2697d6cef  nop [rax+rax*1], ax
00007cc2697d6cf8  nop [rax+rax*1], eax
00007cc2697d6d00  mov eax, 0x410664
00007cc2697d6d05  mov [r15+0x100], rax
00007cc2697d6d0c  jmp 0x00007CC2695FE110
00007cc2697d6d11  cmp dword ptr [r15+0x318], 0x00
00007cc2697d6d19  jz 0x00007CC2697D6050
00007cc2697d6d1f  nop [rax+rax*1], ax
00007cc2697d6d28  nop [rax+rax*1], eax
00007cc2697d6d30  mov eax, 0x4104F0
00007cc2697d6d35  mov [r15+0x100], rax
00007cc2697d6d3c  jmp 0x00007CC2695FE110
00007cc2697d6d41  int3
00007cc2697d6d42  call 0x00007CC26960A4B0
00007cc2697d6d47  jmp 0x00007CC2697D6079
00007cc2697d6d4c  call 0x00007CC269609240
00007cc2697d6d51  jmp 0x00007CC2697D6083
00007cc2697d6d56  call 0x00007CC26960A4B0
00007cc2697d6d5b  jmp 0x00007CC2697D60CD
00007cc2697d6d60  call 0x00007CC269609240
00007cc2697d6d65  jmp 0x00007CC2697D60D7
00007cc2697d6d6a  call 0x00007CC26960A4B0
00007cc2697d6d6f  jmp 0x00007CC2697D6158
00007cc2697d6d74  call 0x00007CC269609240
00007cc2697d6d79  jmp 0x00007CC2697D6162
00007cc2697d6d7e  call 0x00007CC2696B47C0
00007cc2697d6d83  jmp 0x00007CC2697D6243
00007cc2697d6d88  call 0x00007CC2695FF430
00007cc2697d6d8d  jmp 0x00007CC2697D6272
00007cc2697d6d92  call 0x00007CC2696B0CE0
00007cc2697d6d97  jmp 0x00007CC2697D628E
00007cc2697d6d9c  sub rsp, 0x08
00007cc2697d6da0  push rax
00007cc2697d6da1  push rcx
00007cc2697d6da2  push rdx
00007cc2697d6da3  push rdi
00007cc2697d6da4  push rsi
00007cc2697d6da5  push r8
00007cc2697d6da7  push r9
00007cc2697d6da9  push r10
00007cc2697d6dab  push r11
00007cc2697d6dad  sub rsp, 0xF0
00007cc2697d6db4  vmovaps [rsp], xmm0
00007cc2697d6db9  vmovaps [rsp+0x10], xmm1
00007cc2697d6dbf  vmovaps [rsp+0x20], xmm2
00007cc2697d6dc5  vmovaps [rsp+0x30], xmm3
00007cc2697d6dcb  vmovaps [rsp+0x40], xmm4
00007cc2697d6dd1  vmovaps [rsp+0x50], xmm5
00007cc2697d6dd7  vmovaps [rsp+0x60], xmm6
00007cc2697d6ddd  vmovaps [rsp+0x70], xmm7
00007cc2697d6de3  vmovaps [rsp+0x80], xmm8
00007cc2697d6dec  vmovaps [rsp+0x90], xmm9
00007cc2697d6df5  vmovaps [rsp+0xA0], xmm10
00007cc2697d6dfe  vmovaps [rsp+0xB0], xmm11
00007cc2697d6e07  vmovaps [rsp+0xC0], xmm12
00007cc2697d6e10  vmovaps [rsp+0xD0], xmm14
00007cc2697d6e19  vmovaps [rsp+0xE0], xmm15
00007cc2697d6e22  sub rsp, 0x40
00007cc2697d6e26  lea rdi, [rsp]
00007cc2697d6e2a  lea rsi, [rsp+0x10]
00007cc2697d6e2f  lea rdx, [rsp+0x20]
00007cc2697d6e34  lea rcx, [rsp+0x30]
00007cc2697d6e39  mov r8d, 0x00
00007cc2697d6e3f  lea r9, [r15+0x3A8]
00007cc2697d6e46  movaps [rdi], xmm13
00007cc2697d6e4a  movaps [rsi], xmm1
00007cc2697d6e4d  movaps [rdx], xmm15
00007cc2697d6e51  movaps [rcx], xmm14
00007cc2697d6e55  mov rax, 0x653E5FFFBA50
00007cc2697d6e5f  call rax
00007cc2697d6e61  movaps xmm13, [rsp]
00007cc2697d6e66  add rsp, 0x40
00007cc2697d6e6a  vmovaps xmm0, [rsp]
00007cc2697d6e6f  vmovaps xmm1, [rsp+0x10]
00007cc2697d6e75  vmovaps xmm2, [rsp+0x20]
00007cc2697d6e7b  vmovaps xmm3, [rsp+0x30]
00007cc2697d6e81  vmovaps xmm4, [rsp+0x40]
00007cc2697d6e87  vmovaps xmm5, [rsp+0x50]
00007cc2697d6e8d  vmovaps xmm6, [rsp+0x60]
00007cc2697d6e93  vmovaps xmm7, [rsp+0x70]
00007cc2697d6e99  vmovaps xmm8, [rsp+0x80]
00007cc2697d6ea2  vmovaps xmm9, [rsp+0x90]
00007cc2697d6eab  vmovaps xmm10, [rsp+0xA0]
00007cc2697d6eb4  vmovaps xmm11, [rsp+0xB0]
00007cc2697d6ebd  vmovaps xmm12, [rsp+0xC0]
00007cc2697d6ec6  vmovaps xmm14, [rsp+0xD0]
00007cc2697d6ecf  vmovaps xmm15, [rsp+0xE0]
00007cc2697d6ed8  add rsp, 0xF0
00007cc2697d6edf  pop r11
00007cc2697d6ee1  pop r10
00007cc2697d6ee3  pop r9
00007cc2697d6ee5  pop r8
00007cc2697d6ee7  pop rsi
00007cc2697d6ee8  pop rdi
00007cc2697d6ee9  pop rdx
00007cc2697d6eea  pop rcx
00007cc2697d6eeb  pop rax
00007cc2697d6eec  add rsp, 0x08
00007cc2697d6ef0  jmp 0x00007CC2697D6305
00007cc2697d6ef5  sub rsp, 0x08
00007cc2697d6ef9  push rax
00007cc2697d6efa  push rcx
00007cc2697d6efb  push rdx
00007cc2697d6efc  push rdi
00007cc2697d6efd  push rsi
00007cc2697d6efe  push r8
00007cc2697d6f00  push r9
00007cc2697d6f02  push r10
00007cc2697d6f04  push r11
00007cc2697d6f06  sub rsp, 0xF0
00007cc2697d6f0d  vmovaps [rsp], xmm0
00007cc2697d6f12  vmovaps [rsp+0x10], xmm1
00007cc2697d6f18  vmovaps [rsp+0x20], xmm2
00007cc2697d6f1e  vmovaps [rsp+0x30], xmm3
00007cc2697d6f24  vmovaps [rsp+0x40], xmm4
00007cc2697d6f2a  vmovaps [rsp+0x50], xmm5
00007cc2697d6f30  vmovaps [rsp+0x60], xmm6
00007cc2697d6f36  vmovaps [rsp+0x70], xmm7
00007cc2697d6f3c  vmovaps [rsp+0x80], xmm8
00007cc2697d6f45  vmovaps [rsp+0x90], xmm9
00007cc2697d6f4e  vmovaps [rsp+0xA0], xmm10
00007cc2697d6f57  vmovaps [rsp+0xB0], xmm11
00007cc2697d6f60  vmovaps [rsp+0xC0], xmm13
00007cc2697d6f69  vmovaps [rsp+0xD0], xmm14
00007cc2697d6f72  vmovaps [rsp+0xE0], xmm15
00007cc2697d6f7b  sub rsp, 0x40
00007cc2697d6f7f  lea rdi, [rsp]
00007cc2697d6f83  lea rsi, [rsp+0x10]
00007cc2697d6f88  lea rdx, [rsp+0x20]
00007cc2697d6f8d  lea rcx, [rsp+0x30]
00007cc2697d6f92  mov r8d, 0x00
00007cc2697d6f98  lea r9, [r15+0x3A8]
00007cc2697d6f9f  movaps [rdi], xmm12
00007cc2697d6fa3  movaps [rsi], xmm15
00007cc2697d6fa7  movaps [rdx], xmm1
00007cc2697d6faa  movaps [rcx], xmm14
00007cc2697d6fae  mov rax, 0x653E5FFFBA50
00007cc2697d6fb8  call rax
00007cc2697d6fba  movaps xmm12, [rsp]
00007cc2697d6fbf  add rsp, 0x40
00007cc2697d6fc3  vmovaps xmm0, [rsp]
00007cc2697d6fc8  vmovaps xmm1, [rsp+0x10]
00007cc2697d6fce  vmovaps xmm2, [rsp+0x20]
00007cc2697d6fd4  vmovaps xmm3, [rsp+0x30]
00007cc2697d6fda  vmovaps xmm4, [rsp+0x40]
00007cc2697d6fe0  vmovaps xmm5, [rsp+0x50]
00007cc2697d6fe6  vmovaps xmm6, [rsp+0x60]
00007cc2697d6fec  vmovaps xmm7, [rsp+0x70]
00007cc2697d6ff2  vmovaps xmm8, [rsp+0x80]
00007cc2697d6ffb  vmovaps xmm9, [rsp+0x90]
00007cc2697d7004  vmovaps xmm10, [rsp+0xA0]
00007cc2697d700d  vmovaps xmm11, [rsp+0xB0]
00007cc2697d7016  vmovaps xmm13, [rsp+0xC0]
00007cc2697d701f  vmovaps xmm14, [rsp+0xD0]
00007cc2697d7028  vmovaps xmm15, [rsp+0xE0]
00007cc2697d7031  add rsp, 0xF0
00007cc2697d7038  pop r11
00007cc2697d703a  pop r10
00007cc2697d703c  pop r9
00007cc2697d703e  pop r8
00007cc2697d7040  pop rsi
00007cc2697d7041  pop rdi
00007cc2697d7042  pop rdx
00007cc2697d7043  pop rcx
00007cc2697d7044  pop rax
00007cc2697d7045  add rsp, 0x08
00007cc2697d7049  jmp 0x00007CC2697D6333
00007cc2697d704e  call 0x00007CC2696D64F0
00007cc2697d7053  jmp 0x00007CC2697D641F
00007cc2697d7058  sub rsp, 0x08
00007cc2697d705c  push rax
00007cc2697d705d  push rcx
00007cc2697d705e  push rdx
00007cc2697d705f  push rdi
00007cc2697d7060  push rsi
00007cc2697d7061  push r8
00007cc2697d7063  push r9
00007cc2697d7065  push r10
00007cc2697d7067  push r11
00007cc2697d7069  sub rsp, 0xF0
00007cc2697d7070  vmovaps [rsp], xmm0
00007cc2697d7075  vmovaps [rsp+0x10], xmm1
00007cc2697d707b  vmovaps [rsp+0x20], xmm2
00007cc2697d7081  vmovaps [rsp+0x30], xmm3
00007cc2697d7087  vmovaps [rsp+0x40], xmm4
00007cc2697d708d  vmovaps [rsp+0x50], xmm5
00007cc2697d7093  vmovaps [rsp+0x60], xmm6
00007cc2697d7099  vmovaps [rsp+0x70], xmm7
00007cc2697d709f  vmovaps [rsp+0x80], xmm8
00007cc2697d70a8  vmovaps [rsp+0x90], xmm9
00007cc2697d70b1  vmovaps [rsp+0xA0], xmm10
00007cc2697d70ba  vmovaps [rsp+0xB0], xmm11
00007cc2697d70c3  vmovaps [rsp+0xC0], xmm12
00007cc2697d70cc  vmovaps [rsp+0xD0], xmm14
00007cc2697d70d5  vmovaps [rsp+0xE0], xmm15
00007cc2697d70de  sub rsp, 0x40
00007cc2697d70e2  lea rdi, [rsp]
00007cc2697d70e6  lea rsi, [rsp+0x10]
00007cc2697d70eb  lea rdx, [rsp+0x20]
00007cc2697d70f0  lea rcx, [rsp+0x30]
00007cc2697d70f5  mov r8d, 0x00
00007cc2697d70fb  lea r9, [r15+0x3A8]
00007cc2697d7102  movaps [rdi], xmm13
00007cc2697d7106  movaps [rsi], xmm1
00007cc2697d7109  movaps [rdx], xmm15
00007cc2697d710d  movaps [rcx], xmm14
00007cc2697d7111  mov rax, 0x653E5FFFBA50
00007cc2697d711b  call rax
00007cc2697d711d  movaps xmm13, [rsp]
00007cc2697d7122  add rsp, 0x40
00007cc2697d7126  vmovaps xmm0, [rsp]
00007cc2697d712b  vmovaps xmm1, [rsp+0x10]
00007cc2697d7131  vmovaps xmm2, [rsp+0x20]
00007cc2697d7137  vmovaps xmm3, [rsp+0x30]
00007cc2697d713d  vmovaps xmm4, [rsp+0x40]
00007cc2697d7143  vmovaps xmm5, [rsp+0x50]
00007cc2697d7149  vmovaps xmm6, [rsp+0x60]
00007cc2697d714f  vmovaps xmm7, [rsp+0x70]
00007cc2697d7155  vmovaps xmm8, [rsp+0x80]
00007cc2697d715e  vmovaps xmm9, [rsp+0x90]
00007cc2697d7167  vmovaps xmm10, [rsp+0xA0]
00007cc2697d7170  vmovaps xmm11, [rsp+0xB0]
00007cc2697d7179  vmovaps xmm12, [rsp+0xC0]
00007cc2697d7182  vmovaps xmm14, [rsp+0xD0]
00007cc2697d718b  vmovaps xmm15, [rsp+0xE0]
00007cc2697d7194  add rsp, 0xF0
00007cc2697d719b  pop r11
00007cc2697d719d  pop r10
00007cc2697d719f  pop r9
00007cc2697d71a1  pop r8
00007cc2697d71a3  pop rsi
00007cc2697d71a4  pop rdi
00007cc2697d71a5  pop rdx
00007cc2697d71a6  pop rcx
00007cc2697d71a7  pop rax
00007cc2697d71a8  add rsp, 0x08
00007cc2697d71ac  jmp 0x00007CC2697D648E
00007cc2697d71b1  call 0x00007CC2696D64F0
00007cc2697d71b6  jmp 0x00007CC2697D64A3
00007cc2697d71bb  sub rsp, 0x08
00007cc2697d71bf  push rax
00007cc2697d71c0  push rcx
00007cc2697d71c1  push rdx
00007cc2697d71c2  push rdi
00007cc2697d71c3  push rsi
00007cc2697d71c4  push r8
00007cc2697d71c6  push r9
00007cc2697d71c8  push r10
00007cc2697d71ca  push r11
00007cc2697d71cc  sub rsp, 0xF0
00007cc2697d71d3  vmovaps [rsp], xmm0
00007cc2697d71d8  vmovaps [rsp+0x10], xmm1
00007cc2697d71de  vmovaps [rsp+0x20], xmm2
00007cc2697d71e4  vmovaps [rsp+0x30], xmm3
00007cc2697d71ea  vmovaps [rsp+0x40], xmm4
00007cc2697d71f0  vmovaps [rsp+0x50], xmm5
00007cc2697d71f6  vmovaps [rsp+0x60], xmm6
00007cc2697d71fc  vmovaps [rsp+0x70], xmm7
00007cc2697d7202  vmovaps [rsp+0x80], xmm8
00007cc2697d720b  vmovaps [rsp+0x90], xmm9
00007cc2697d7214  vmovaps [rsp+0xA0], xmm10
00007cc2697d721d  vmovaps [rsp+0xB0], xmm11
00007cc2697d7226  vmovaps [rsp+0xC0], xmm13
00007cc2697d722f  vmovaps [rsp+0xD0], xmm14
00007cc2697d7238  vmovaps [rsp+0xE0], xmm15
00007cc2697d7241  sub rsp, 0x40
00007cc2697d7245  lea rdi, [rsp]
00007cc2697d7249  lea rsi, [rsp+0x10]
00007cc2697d724e  lea rdx, [rsp+0x20]
00007cc2697d7253  lea rcx, [rsp+0x30]
00007cc2697d7258  mov r8d, 0x00
00007cc2697d725e  lea r9, [r15+0x3A8]
00007cc2697d7265  movaps [rdi], xmm12
00007cc2697d7269  movaps [rsi], xmm15
00007cc2697d726d  movaps [rdx], xmm1
00007cc2697d7270  movaps [rcx], xmm14
00007cc2697d7274  mov rax, 0x653E5FFFBA50
00007cc2697d727e  call rax
00007cc2697d7280  movaps xmm12, [rsp]
00007cc2697d7285  add rsp, 0x40
00007cc2697d7289  vmovaps xmm0, [rsp]
00007cc2697d728e  vmovaps xmm1, [rsp+0x10]
00007cc2697d7294  vmovaps xmm2, [rsp+0x20]
00007cc2697d729a  vmovaps xmm3, [rsp+0x30]
00007cc2697d72a0  vmovaps xmm4, [rsp+0x40]
00007cc2697d72a6  vmovaps xmm5, [rsp+0x50]
00007cc2697d72ac  vmovaps xmm6, [rsp+0x60]
00007cc2697d72b2  vmovaps xmm7, [rsp+0x70]
00007cc2697d72b8  vmovaps xmm8, [rsp+0x80]
00007cc2697d72c1  vmovaps xmm9, [rsp+0x90]
00007cc2697d72ca  vmovaps xmm10, [rsp+0xA0]
00007cc2697d72d3  vmovaps xmm11, [rsp+0xB0]
00007cc2697d72dc  vmovaps xmm13, [rsp+0xC0]
00007cc2697d72e5  vmovaps xmm14, [rsp+0xD0]
00007cc2697d72ee  vmovaps xmm15, [rsp+0xE0]
00007cc2697d72f7  add rsp, 0xF0
00007cc2697d72fe  pop r11
00007cc2697d7300  pop r10
00007cc2697d7302  pop r9
00007cc2697d7304  pop r8
00007cc2697d7306  pop rsi
00007cc2697d7307  pop rdi
00007cc2697d7308  pop rdx
00007cc2697d7309  pop rcx
00007cc2697d730a  pop rax
00007cc2697d730b  add rsp, 0x08
00007cc2697d730f  jmp 0x00007CC2697D64CF
00007cc2697d7314  sub rsp, 0x08
00007cc2697d7318  push rax
00007cc2697d7319  push rcx
00007cc2697d731a  push rdx
00007cc2697d731b  push rdi
00007cc2697d731c  push rsi
00007cc2697d731d  push r8
00007cc2697d731f  push r9
00007cc2697d7321  push r10
00007cc2697d7323  push r11
00007cc2697d7325  sub rsp, 0xF0
00007cc2697d732c  vmovaps [rsp], xmm0
00007cc2697d7331  vmovaps [rsp+0x10], xmm1
00007cc2697d7337  vmovaps [rsp+0x20], xmm2
00007cc2697d733d  vmovaps [rsp+0x30], xmm3
00007cc2697d7343  vmovaps [rsp+0x40], xmm4
00007cc2697d7349  vmovaps [rsp+0x50], xmm5
00007cc2697d734f  vmovaps [rsp+0x60], xmm6
00007cc2697d7355  vmovaps [rsp+0x70], xmm7
00007cc2697d735b  vmovaps [rsp+0x80], xmm8
00007cc2697d7364  vmovaps [rsp+0x90], xmm9
00007cc2697d736d  vmovaps [rsp+0xA0], xmm10
00007cc2697d7376  vmovaps [rsp+0xB0], xmm11
00007cc2697d737f  vmovaps [rsp+0xC0], xmm12
00007cc2697d7388  vmovaps [rsp+0xD0], xmm14
00007cc2697d7391  vmovaps [rsp+0xE0], xmm15
00007cc2697d739a  sub rsp, 0x40
00007cc2697d739e  lea rdi, [rsp]
00007cc2697d73a2  lea rsi, [rsp+0x10]
00007cc2697d73a7  lea rdx, [rsp+0x20]
00007cc2697d73ac  lea rcx, [rsp+0x30]
00007cc2697d73b1  mov r8d, 0x00
00007cc2697d73b7  lea r9, [r15+0x3A8]
00007cc2697d73be  movaps [rdi], xmm13
00007cc2697d73c2  movaps [rsi], xmm1
00007cc2697d73c5  movaps [rdx], xmm15
00007cc2697d73c9  movaps [rcx], xmm14
00007cc2697d73cd  mov rax, 0x653E5FFFBA50
00007cc2697d73d7  call rax
00007cc2697d73d9  movaps xmm13, [rsp]
00007cc2697d73de  add rsp, 0x40
00007cc2697d73e2  vmovaps xmm0, [rsp]
00007cc2697d73e7  vmovaps xmm1, [rsp+0x10]
00007cc2697d73ed  vmovaps xmm2, [rsp+0x20]
00007cc2697d73f3  vmovaps xmm3, [rsp+0x30]
00007cc2697d73f9  vmovaps xmm4, [rsp+0x40]
00007cc2697d73ff  vmovaps xmm5, [rsp+0x50]
00007cc2697d7405  vmovaps xmm6, [rsp+0x60]
00007cc2697d740b  vmovaps xmm7, [rsp+0x70]
00007cc2697d7411  vmovaps xmm8, [rsp+0x80]
00007cc2697d741a  vmovaps xmm9, [rsp+0x90]
00007cc2697d7423  vmovaps xmm10, [rsp+0xA0]
00007cc2697d742c  vmovaps xmm11, [rsp+0xB0]
00007cc2697d7435  vmovaps xmm12, [rsp+0xC0]
00007cc2697d743e  vmovaps xmm14, [rsp+0xD0]
00007cc2697d7447  vmovaps xmm15, [rsp+0xE0]
00007cc2697d7450  add rsp, 0xF0
00007cc2697d7457  pop r11
00007cc2697d7459  pop r10
00007cc2697d745b  pop r9
00007cc2697d745d  pop r8
00007cc2697d745f  pop rsi
00007cc2697d7460  pop rdi
00007cc2697d7461  pop rdx
00007cc2697d7462  pop rcx
00007cc2697d7463  pop rax
00007cc2697d7464  add rsp, 0x08
00007cc2697d7468  jmp 0x00007CC2697D665F
00007cc2697d746d  sub rsp, 0x08
00007cc2697d7471  push rax
00007cc2697d7472  push rcx
00007cc2697d7473  push rdx
00007cc2697d7474  push rdi
00007cc2697d7475  push rsi
00007cc2697d7476  push r8
00007cc2697d7478  push r9
00007cc2697d747a  push r10
00007cc2697d747c  push r11
00007cc2697d747e  sub rsp, 0xF0
00007cc2697d7485  vmovaps [rsp], xmm0
00007cc2697d748a  vmovaps [rsp+0x10], xmm1
00007cc2697d7490  vmovaps [rsp+0x20], xmm2
00007cc2697d7496  vmovaps [rsp+0x30], xmm3
00007cc2697d749c  vmovaps [rsp+0x40], xmm4
00007cc2697d74a2  vmovaps [rsp+0x50], xmm5
00007cc2697d74a8  vmovaps [rsp+0x60], xmm6
00007cc2697d74ae  vmovaps [rsp+0x70], xmm7
00007cc2697d74b4  vmovaps [rsp+0x80], xmm8
00007cc2697d74bd  vmovaps [rsp+0x90], xmm9
00007cc2697d74c6  vmovaps [rsp+0xA0], xmm10
00007cc2697d74cf  vmovaps [rsp+0xB0], xmm11
00007cc2697d74d8  vmovaps [rsp+0xC0], xmm12
00007cc2697d74e1  vmovaps [rsp+0xD0], xmm13
00007cc2697d74ea  vmovaps [rsp+0xE0], xmm15
00007cc2697d74f3  sub rsp, 0x40
00007cc2697d74f7  lea rdi, [rsp]
00007cc2697d74fb  lea rsi, [rsp+0x10]
00007cc2697d7500  lea rdx, [rsp+0x20]
00007cc2697d7505  lea rcx, [rsp+0x30]
00007cc2697d750a  mov r8d, 0x00
00007cc2697d7510  lea r9, [r15+0x3A8]
00007cc2697d7517  movaps [rdi], xmm14
00007cc2697d751b  movaps [rsi], xmm15
00007cc2697d751f  movaps [rdx], xmm2
00007cc2697d7522  movaps [rcx], xmm1
00007cc2697d7525  mov rax, 0x653E5FFFBA50
00007cc2697d752f  call rax
00007cc2697d7531  movaps xmm14, [rsp]
00007cc2697d7536  add rsp, 0x40
00007cc2697d753a  vmovaps xmm0, [rsp]
00007cc2697d753f  vmovaps xmm1, [rsp+0x10]
00007cc2697d7545  vmovaps xmm2, [rsp+0x20]
00007cc2697d754b  vmovaps xmm3, [rsp+0x30]
00007cc2697d7551  vmovaps xmm4, [rsp+0x40]
00007cc2697d7557  vmovaps xmm5, [rsp+0x50]
00007cc2697d755d  vmovaps xmm6, [rsp+0x60]
00007cc2697d7563  vmovaps xmm7, [rsp+0x70]
00007cc2697d7569  vmovaps xmm8, [rsp+0x80]
00007cc2697d7572  vmovaps xmm9, [rsp+0x90]
00007cc2697d757b  vmovaps xmm10, [rsp+0xA0]
00007cc2697d7584  vmovaps xmm11, [rsp+0xB0]
00007cc2697d758d  vmovaps xmm12, [rsp+0xC0]
00007cc2697d7596  vmovaps xmm13, [rsp+0xD0]
00007cc2697d759f  vmovaps xmm15, [rsp+0xE0]
00007cc2697d75a8  add rsp, 0xF0
00007cc2697d75af  pop r11
00007cc2697d75b1  pop r10
00007cc2697d75b3  pop r9
00007cc2697d75b5  pop r8
00007cc2697d75b7  pop rsi
00007cc2697d75b8  pop rdi
00007cc2697d75b9  pop rdx
00007cc2697d75ba  pop rcx
00007cc2697d75bb  pop rax
00007cc2697d75bc  add rsp, 0x08
00007cc2697d75c0  jmp 0x00007CC2697D6691
00007cc2697d75c5  sub rsp, 0x08
00007cc2697d75c9  push rax
00007cc2697d75ca  push rcx
00007cc2697d75cb  push rdx
00007cc2697d75cc  push rdi
00007cc2697d75cd  push rsi
00007cc2697d75ce  push r8
00007cc2697d75d0  push r9
00007cc2697d75d2  push r10
00007cc2697d75d4  push r11
00007cc2697d75d6  sub rsp, 0xF0
00007cc2697d75dd  vmovaps [rsp], xmm0
00007cc2697d75e2  vmovaps [rsp+0x10], xmm1
00007cc2697d75e8  vmovaps [rsp+0x20], xmm3
00007cc2697d75ee  vmovaps [rsp+0x30], xmm4
00007cc2697d75f4  vmovaps [rsp+0x40], xmm5
00007cc2697d75fa  vmovaps [rsp+0x50], xmm6
00007cc2697d7600  vmovaps [rsp+0x60], xmm7
00007cc2697d7606  vmovaps [rsp+0x70], xmm8
00007cc2697d760c  vmovaps [rsp+0x80], xmm9
00007cc2697d7615  vmovaps [rsp+0x90], xmm10
00007cc2697d761e  vmovaps [rsp+0xA0], xmm11
00007cc2697d7627  vmovaps [rsp+0xB0], xmm12
00007cc2697d7630  vmovaps [rsp+0xC0], xmm13
00007cc2697d7639  vmovaps [rsp+0xD0], xmm14
00007cc2697d7642  vmovaps [rsp+0xE0], xmm15
00007cc2697d764b  sub rsp, 0x40
00007cc2697d764f  lea rdi, [rsp]
00007cc2697d7653  lea rsi, [rsp+0x10]
00007cc2697d7658  lea rdx, [rsp+0x20]
00007cc2697d765d  lea rcx, [rsp+0x30]
00007cc2697d7662  mov r8d, 0x00
00007cc2697d7668  lea r9, [r15+0x3A8]
00007cc2697d766f  movaps [rdi], xmm2
00007cc2697d7672  movaps [rsi], xmm15
00007cc2697d7676  movaps [rdx], xmm12
00007cc2697d767a  movaps [rcx], xmm1
00007cc2697d767d  mov rax, 0x653E5FFFBA50
00007cc2697d7687  call rax
00007cc2697d7689  movaps xmm2, [rsp]
00007cc2697d768d  add rsp, 0x40
00007cc2697d7691  vmovaps xmm0, [rsp]
00007cc2697d7696  vmovaps xmm1, [rsp+0x10]
00007cc2697d769c  vmovaps xmm3, [rsp+0x20]
00007cc2697d76a2  vmovaps xmm4, [rsp+0x30]
00007cc2697d76a8  vmovaps xmm5, [rsp+0x40]
00007cc2697d76ae  vmovaps xmm6, [rsp+0x50]
00007cc2697d76b4  vmovaps xmm7, [rsp+0x60]
00007cc2697d76ba  vmovaps xmm8, [rsp+0x70]
00007cc2697d76c0  vmovaps xmm9, [rsp+0x80]
00007cc2697d76c9  vmovaps xmm10, [rsp+0x90]
00007cc2697d76d2  vmovaps xmm11, [rsp+0xA0]
00007cc2697d76db  vmovaps xmm12, [rsp+0xB0]
00007cc2697d76e4  vmovaps xmm13, [rsp+0xC0]
00007cc2697d76ed  vmovaps xmm14, [rsp+0xD0]
00007cc2697d76f6  vmovaps xmm15, [rsp+0xE0]
00007cc2697d76ff  add rsp, 0xF0
00007cc2697d7706  pop r11
00007cc2697d7708  pop r10
00007cc2697d770a  pop r9
00007cc2697d770c  pop r8
00007cc2697d770e  pop rsi
00007cc2697d770f  pop rdi
00007cc2697d7710  pop rdx
00007cc2697d7711  pop rcx
00007cc2697d7712  pop rax
00007cc2697d7713  add rsp, 0x08
00007cc2697d7717  jmp 0x00007CC2697D66CE
00007cc2697d771c  sub rsp, 0x08
00007cc2697d7720  push rax
00007cc2697d7721  push rcx
00007cc2697d7722  push rdx
00007cc2697d7723  push rdi
00007cc2697d7724  push rsi
00007cc2697d7725  push r8
00007cc2697d7727  push r9
00007cc2697d7729  push r10
00007cc2697d772b  push r11
00007cc2697d772d  sub rsp, 0xF0
00007cc2697d7734  vmovaps [rsp], xmm0
00007cc2697d7739  vmovaps [rsp+0x10], xmm1
00007cc2697d773f  vmovaps [rsp+0x20], xmm2
00007cc2697d7745  vmovaps [rsp+0x30], xmm3
00007cc2697d774b  vmovaps [rsp+0x40], xmm4
00007cc2697d7751  vmovaps [rsp+0x50], xmm5
00007cc2697d7757  vmovaps [rsp+0x60], xmm6
00007cc2697d775d  vmovaps [rsp+0x70], xmm7
00007cc2697d7763  vmovaps [rsp+0x80], xmm8
00007cc2697d776c  vmovaps [rsp+0x90], xmm9
00007cc2697d7775  vmovaps [rsp+0xA0], xmm10
00007cc2697d777e  vmovaps [rsp+0xB0], xmm11
00007cc2697d7787  vmovaps [rsp+0xC0], xmm13
00007cc2697d7790  vmovaps [rsp+0xD0], xmm14
00007cc2697d7799  vmovaps [rsp+0xE0], xmm15
00007cc2697d77a2  sub rsp, 0x40
00007cc2697d77a6  lea rdi, [rsp]
00007cc2697d77aa  lea rsi, [rsp+0x10]
00007cc2697d77af  lea rdx, [rsp+0x20]
00007cc2697d77b4  lea rcx, [rsp+0x30]
00007cc2697d77b9  mov r8d, 0x00
00007cc2697d77bf  lea r9, [r15+0x3A8]
00007cc2697d77c6  movaps [rdi], xmm12
00007cc2697d77ca  movaps [rsi], xmm14
00007cc2697d77ce  movaps [rdx], xmm3
00007cc2697d77d1  movaps [rcx], xmm15
00007cc2697d77d5  mov rax, 0x653E5FFFBA50
00007cc2697d77df  call rax
00007cc2697d77e1  movaps xmm12, [rsp]
00007cc2697d77e6  add rsp, 0x40
00007cc2697d77ea  vmovaps xmm0, [rsp]
00007cc2697d77ef  vmovaps xmm1, [rsp+0x10]
00007cc2697d77f5  vmovaps xmm2, [rsp+0x20]
00007cc2697d77fb  vmovaps xmm3, [rsp+0x30]
00007cc2697d7801  vmovaps xmm4, [rsp+0x40]
00007cc2697d7807  vmovaps xmm5, [rsp+0x50]
00007cc2697d780d  vmovaps xmm6, [rsp+0x60]
00007cc2697d7813  vmovaps xmm7, [rsp+0x70]
00007cc2697d7819  vmovaps xmm8, [rsp+0x80]
00007cc2697d7822  vmovaps xmm9, [rsp+0x90]
00007cc2697d782b  vmovaps xmm10, [rsp+0xA0]
00007cc2697d7834  vmovaps xmm11, [rsp+0xB0]
00007cc2697d783d  vmovaps xmm13, [rsp+0xC0]
00007cc2697d7846  vmovaps xmm14, [rsp+0xD0]
00007cc2697d784f  vmovaps xmm15, [rsp+0xE0]
00007cc2697d7858  add rsp, 0xF0
00007cc2697d785f  pop r11
00007cc2697d7861  pop r10
00007cc2697d7863  pop r9
00007cc2697d7865  pop r8
00007cc2697d7867  pop rsi
00007cc2697d7868  pop rdi
00007cc2697d7869  pop rdx
00007cc2697d786a  pop rcx
00007cc2697d786b  pop rax
00007cc2697d786c  add rsp, 0x08
00007cc2697d7870  jmp 0x00007CC2697D6728
00007cc2697d7875  sub rsp, 0x08
00007cc2697d7879  push rax
00007cc2697d787a  push rcx
00007cc2697d787b  push rdx
00007cc2697d787c  push rdi
00007cc2697d787d  push rsi
00007cc2697d787e  push r8
00007cc2697d7880  push r9
00007cc2697d7882  push r10
00007cc2697d7884  push r11
00007cc2697d7886  sub rsp, 0xF0
00007cc2697d788d  vmovaps [rsp], xmm0
00007cc2697d7892  vmovaps [rsp+0x10], xmm1
00007cc2697d7898  vmovaps [rsp+0x20], xmm2
00007cc2697d789e  vmovaps [rsp+0x30], xmm3
00007cc2697d78a4  vmovaps [rsp+0x40], xmm4
00007cc2697d78aa  vmovaps [rsp+0x50], xmm5
00007cc2697d78b0  vmovaps [rsp+0x60], xmm6
00007cc2697d78b6  vmovaps [rsp+0x70], xmm7
00007cc2697d78bc  vmovaps [rsp+0x80], xmm8
00007cc2697d78c5  vmovaps [rsp+0x90], xmm10
00007cc2697d78ce  vmovaps [rsp+0xA0], xmm11
00007cc2697d78d7  vmovaps [rsp+0xB0], xmm12
00007cc2697d78e0  vmovaps [rsp+0xC0], xmm13
00007cc2697d78e9  vmovaps [rsp+0xD0], xmm14
00007cc2697d78f2  vmovaps [rsp+0xE0], xmm15
00007cc2697d78fb  sub rsp, 0x40
00007cc2697d78ff  lea rdi, [rsp]
00007cc2697d7903  lea rsi, [rsp+0x10]
00007cc2697d7908  lea rdx, [rsp+0x20]
00007cc2697d790d  lea rcx, [rsp+0x30]
00007cc2697d7912  mov r8d, 0x00
00007cc2697d7918  lea r9, [r15+0x3A8]
00007cc2697d791f  movaps [rdi], xmm9
00007cc2697d7923  movaps [rsi], xmm13
00007cc2697d7927  movaps [rdx], xmm14
00007cc2697d792b  movaps [rcx], xmm6
00007cc2697d792e  mov rax, 0x653E5FFFBA50
00007cc2697d7938  call rax
00007cc2697d793a  movaps xmm9, [rsp]
00007cc2697d793f  add rsp, 0x40
00007cc2697d7943  vmovaps xmm0, [rsp]
00007cc2697d7948  vmovaps xmm1, [rsp+0x10]
00007cc2697d794e  vmovaps xmm2, [rsp+0x20]
00007cc2697d7954  vmovaps xmm3, [rsp+0x30]
00007cc2697d795a  vmovaps xmm4, [rsp+0x40]
00007cc2697d7960  vmovaps xmm5, [rsp+0x50]
00007cc2697d7966  vmovaps xmm6, [rsp+0x60]
00007cc2697d796c  vmovaps xmm7, [rsp+0x70]
00007cc2697d7972  vmovaps xmm8, [rsp+0x80]
00007cc2697d797b  vmovaps xmm10, [rsp+0x90]
00007cc2697d7984  vmovaps xmm11, [rsp+0xA0]
00007cc2697d798d  vmovaps xmm12, [rsp+0xB0]
00007cc2697d7996  vmovaps xmm13, [rsp+0xC0]
00007cc2697d799f  vmovaps xmm14, [rsp+0xD0]
00007cc2697d79a8  vmovaps xmm15, [rsp+0xE0]
00007cc2697d79b1  add rsp, 0xF0
00007cc2697d79b8  pop r11
00007cc2697d79ba  pop r10
00007cc2697d79bc  pop r9
00007cc2697d79be  pop r8
00007cc2697d79c0  pop rsi
00007cc2697d79c1  pop rdi
00007cc2697d79c2  pop rdx
00007cc2697d79c3  pop rcx
00007cc2697d79c4  pop rax
00007cc2697d79c5  add rsp, 0x08
00007cc2697d79c9  jmp 0x00007CC2697D67D2
00007cc2697d79ce  sub rsp, 0x08
00007cc2697d79d2  push rax
00007cc2697d79d3  push rcx
00007cc2697d79d4  push rdx
00007cc2697d79d5  push rdi
00007cc2697d79d6  push rsi
00007cc2697d79d7  push r8
00007cc2697d79d9  push r9
00007cc2697d79db  push r10
00007cc2697d79dd  push r11
00007cc2697d79df  sub rsp, 0xF0
00007cc2697d79e6  vmovaps [rsp], xmm0
00007cc2697d79eb  vmovaps [rsp+0x10], xmm1
00007cc2697d79f1  vmovaps [rsp+0x20], xmm2
00007cc2697d79f7  vmovaps [rsp+0x30], xmm4
00007cc2697d79fd  vmovaps [rsp+0x40], xmm5
00007cc2697d7a03  vmovaps [rsp+0x50], xmm6
00007cc2697d7a09  vmovaps [rsp+0x60], xmm7
00007cc2697d7a0f  vmovaps [rsp+0x70], xmm8
00007cc2697d7a15  vmovaps [rsp+0x80], xmm9
00007cc2697d7a1e  vmovaps [rsp+0x90], xmm10
00007cc2697d7a27  vmovaps [rsp+0xA0], xmm11
00007cc2697d7a30  vmovaps [rsp+0xB0], xmm12
00007cc2697d7a39  vmovaps [rsp+0xC0], xmm13
00007cc2697d7a42  vmovaps [rsp+0xD0], xmm14
00007cc2697d7a4b  vmovaps [rsp+0xE0], xmm15
00007cc2697d7a54  sub rsp, 0x40
00007cc2697d7a58  lea rdi, [rsp]
00007cc2697d7a5c  lea rsi, [rsp+0x10]
00007cc2697d7a61  lea rdx, [rsp+0x20]
00007cc2697d7a66  lea rcx, [rsp+0x30]
00007cc2697d7a6b  mov r8d, 0x00
00007cc2697d7a71  lea r9, [r15+0x3A8]
00007cc2697d7a78  movaps [rdi], xmm3
00007cc2697d7a7b  movaps [rsi], xmm13
00007cc2697d7a7f  movaps [rdx], xmm6
00007cc2697d7a82  movaps [rcx], xmm14
00007cc2697d7a86  mov rax, 0x653E5FFFBA50
00007cc2697d7a90  call rax
00007cc2697d7a92  movaps xmm3, [rsp]
00007cc2697d7a96  add rsp, 0x40
00007cc2697d7a9a  vmovaps xmm0, [rsp]
00007cc2697d7a9f  vmovaps xmm1, [rsp+0x10]
00007cc2697d7aa5  vmovaps xmm2, [rsp+0x20]
00007cc2697d7aab  vmovaps xmm4, [rsp+0x30]
00007cc2697d7ab1  vmovaps xmm5, [rsp+0x40]
00007cc2697d7ab7  vmovaps xmm6, [rsp+0x50]
00007cc2697d7abd  vmovaps xmm7, [rsp+0x60]
00007cc2697d7ac3  vmovaps xmm8, [rsp+0x70]
00007cc2697d7ac9  vmovaps xmm9, [rsp+0x80]
00007cc2697d7ad2  vmovaps xmm10, [rsp+0x90]
00007cc2697d7adb  vmovaps xmm11, [rsp+0xA0]
00007cc2697d7ae4  vmovaps xmm12, [rsp+0xB0]
00007cc2697d7aed  vmovaps xmm13, [rsp+0xC0]
00007cc2697d7af6  vmovaps xmm14, [rsp+0xD0]
00007cc2697d7aff  vmovaps xmm15, [rsp+0xE0]
00007cc2697d7b08  add rsp, 0xF0
00007cc2697d7b0f  pop r11
00007cc2697d7b11  pop r10
00007cc2697d7b13  pop r9
00007cc2697d7b15  pop r8
00007cc2697d7b17  pop rsi
00007cc2697d7b18  pop rdi
00007cc2697d7b19  pop rdx
00007cc2697d7b1a  pop rcx
00007cc2697d7b1b  pop rax
00007cc2697d7b1c  add rsp, 0x08
00007cc2697d7b20  jmp 0x00007CC2697D680F
00007cc2697d7b25  sub rsp, 0x08
00007cc2697d7b29  push rax
00007cc2697d7b2a  push rcx
00007cc2697d7b2b  push rdx
00007cc2697d7b2c  push rdi
00007cc2697d7b2d  push rsi
00007cc2697d7b2e  push r8
00007cc2697d7b30  push r9
00007cc2697d7b32  push r10
00007cc2697d7b34  push r11
00007cc2697d7b36  sub rsp, 0xF0
00007cc2697d7b3d  vmovaps [rsp], xmm0
00007cc2697d7b42  vmovaps [rsp+0x10], xmm1
00007cc2697d7b48  vmovaps [rsp+0x20], xmm2
00007cc2697d7b4e  vmovaps [rsp+0x30], xmm3
00007cc2697d7b54  vmovaps [rsp+0x40], xmm4
00007cc2697d7b5a  vmovaps [rsp+0x50], xmm5
00007cc2697d7b60  vmovaps [rsp+0x60], xmm7
00007cc2697d7b66  vmovaps [rsp+0x70], xmm8
00007cc2697d7b6c  vmovaps [rsp+0x80], xmm9
00007cc2697d7b75  vmovaps [rsp+0x90], xmm10
00007cc2697d7b7e  vmovaps [rsp+0xA0], xmm11
00007cc2697d7b87  vmovaps [rsp+0xB0], xmm12
00007cc2697d7b90  vmovaps [rsp+0xC0], xmm13
00007cc2697d7b99  vmovaps [rsp+0xD0], xmm14
00007cc2697d7ba2  vmovaps [rsp+0xE0], xmm15
00007cc2697d7bab  sub rsp, 0x40
00007cc2697d7baf  lea rdi, [rsp]
00007cc2697d7bb3  lea rsi, [rsp+0x10]
00007cc2697d7bb8  lea rdx, [rsp+0x20]
00007cc2697d7bbd  lea rcx, [rsp+0x30]
00007cc2697d7bc2  mov r8d, 0x00
00007cc2697d7bc8  lea r9, [r15+0x3A8]
00007cc2697d7bcf  movaps [rdi], xmm6
00007cc2697d7bd2  movaps [rsi], xmm2
00007cc2697d7bd5  movaps [rdx], xmm14
00007cc2697d7bd9  movaps [rcx], xmm1
00007cc2697d7bdc  mov rax, 0x653E5FFFBA50
00007cc2697d7be6  call rax
00007cc2697d7be8  movaps xmm6, [rsp]
00007cc2697d7bec  add rsp, 0x40
00007cc2697d7bf0  vmovaps xmm0, [rsp]
00007cc2697d7bf5  vmovaps xmm1, [rsp+0x10]
00007cc2697d7bfb  vmovaps xmm2, [rsp+0x20]
00007cc2697d7c01  vmovaps xmm3, [rsp+0x30]
00007cc2697d7c07  vmovaps xmm4, [rsp+0x40]
00007cc2697d7c0d  vmovaps xmm5, [rsp+0x50]
00007cc2697d7c13  vmovaps xmm7, [rsp+0x60]
00007cc2697d7c19  vmovaps xmm8, [rsp+0x70]
00007cc2697d7c1f  vmovaps xmm9, [rsp+0x80]
00007cc2697d7c28  vmovaps xmm10, [rsp+0x90]
00007cc2697d7c31  vmovaps xmm11, [rsp+0xA0]
00007cc2697d7c3a  vmovaps xmm12, [rsp+0xB0]
00007cc2697d7c43  vmovaps xmm13, [rsp+0xC0]
00007cc2697d7c4c  vmovaps xmm14, [rsp+0xD0]
00007cc2697d7c55  vmovaps xmm15, [rsp+0xE0]
00007cc2697d7c5e  add rsp, 0xF0
00007cc2697d7c65  pop r11
00007cc2697d7c67  pop r10
00007cc2697d7c69  pop r9
00007cc2697d7c6b  pop r8
00007cc2697d7c6d  pop rsi
00007cc2697d7c6e  pop rdi
00007cc2697d7c6f  pop rdx
00007cc2697d7c70  pop rcx
00007cc2697d7c71  pop rax
00007cc2697d7c72  add rsp, 0x08
00007cc2697d7c76  jmp 0x00007CC2697D683C
00007cc2697d7c7b  sub rsp, 0x08
00007cc2697d7c7f  push rax
00007cc2697d7c80  push rcx
00007cc2697d7c81  push rdx
00007cc2697d7c82  push rdi
00007cc2697d7c83  push rsi
00007cc2697d7c84  push r8
00007cc2697d7c86  push r9
00007cc2697d7c88  push r10
00007cc2697d7c8a  push r11
00007cc2697d7c8c  sub rsp, 0xF0
00007cc2697d7c93  vmovaps [rsp], xmm0
00007cc2697d7c98  vmovaps [rsp+0x10], xmm1
00007cc2697d7c9e  vmovaps [rsp+0x20], xmm2
00007cc2697d7ca4  vmovaps [rsp+0x30], xmm3
00007cc2697d7caa  vmovaps [rsp+0x40], xmm4
00007cc2697d7cb0  vmovaps [rsp+0x50], xmm5
00007cc2697d7cb6  vmovaps [rsp+0x60], xmm6
00007cc2697d7cbc  vmovaps [rsp+0x70], xmm7
00007cc2697d7cc2  vmovaps [rsp+0x80], xmm8
00007cc2697d7ccb  vmovaps [rsp+0x90], xmm9
00007cc2697d7cd4  vmovaps [rsp+0xA0], xmm10
00007cc2697d7cdd  vmovaps [rsp+0xB0], xmm11
00007cc2697d7ce6  vmovaps [rsp+0xC0], xmm12
00007cc2697d7cef  vmovaps [rsp+0xD0], xmm14
00007cc2697d7cf8  vmovaps [rsp+0xE0], xmm15
00007cc2697d7d01  sub rsp, 0x40
00007cc2697d7d05  lea rdi, [rsp]
00007cc2697d7d09  lea rsi, [rsp+0x10]
00007cc2697d7d0e  lea rdx, [rsp+0x20]
00007cc2697d7d13  lea rcx, [rsp+0x30]
00007cc2697d7d18  mov r8d, 0x00
00007cc2697d7d1e  lea r9, [r15+0x3A8]
00007cc2697d7d25  movaps [rdi], xmm13
00007cc2697d7d29  movaps [rsi], xmm12
00007cc2697d7d2d  movaps [rdx], xmm14
00007cc2697d7d31  movaps [rcx], xmm1
00007cc2697d7d34  mov rax, 0x653E5FFFBA50
00007cc2697d7d3e  call rax
00007cc2697d7d40  movaps xmm13, [rsp]
00007cc2697d7d45  add rsp, 0x40
00007cc2697d7d49  vmovaps xmm0, [rsp]
00007cc2697d7d4e  vmovaps xmm1, [rsp+0x10]
00007cc2697d7d54  vmovaps xmm2, [rsp+0x20]
00007cc2697d7d5a  vmovaps xmm3, [rsp+0x30]
00007cc2697d7d60  vmovaps xmm4, [rsp+0x40]
00007cc2697d7d66  vmovaps xmm5, [rsp+0x50]
00007cc2697d7d6c  vmovaps xmm6, [rsp+0x60]
00007cc2697d7d72  vmovaps xmm7, [rsp+0x70]
00007cc2697d7d78  vmovaps xmm8, [rsp+0x80]
00007cc2697d7d81  vmovaps xmm9, [rsp+0x90]
00007cc2697d7d8a  vmovaps xmm10, [rsp+0xA0]
00007cc2697d7d93  vmovaps xmm11, [rsp+0xB0]
00007cc2697d7d9c  vmovaps xmm12, [rsp+0xC0]
00007cc2697d7da5  vmovaps xmm14, [rsp+0xD0]
00007cc2697d7dae  vmovaps xmm15, [rsp+0xE0]
00007cc2697d7db7  add rsp, 0xF0
00007cc2697d7dbe  pop r11
00007cc2697d7dc0  pop r10
00007cc2697d7dc2  pop r9
00007cc2697d7dc4  pop r8
00007cc2697d7dc6  pop rsi
00007cc2697d7dc7  pop rdi
00007cc2697d7dc8  pop rdx
00007cc2697d7dc9  pop rcx
00007cc2697d7dca  pop rax
00007cc2697d7dcb  add rsp, 0x08
00007cc2697d7dcf  jmp 0x00007CC2697D686E
00007cc2697d7dd4  sub rsp, 0x08
00007cc2697d7dd8  push rax
00007cc2697d7dd9  push rcx
00007cc2697d7dda  push rdx
00007cc2697d7ddb  push rdi
00007cc2697d7ddc  push rsi
00007cc2697d7ddd  push r8
00007cc2697d7ddf  push r9
00007cc2697d7de1  push r10
00007cc2697d7de3  push r11
00007cc2697d7de5  sub rsp, 0xF0
00007cc2697d7dec  vmovaps [rsp], xmm0
00007cc2697d7df1  vmovaps [rsp+0x10], xmm1
00007cc2697d7df7  vmovaps [rsp+0x20], xmm2
00007cc2697d7dfd  vmovaps [rsp+0x30], xmm3
00007cc2697d7e03  vmovaps [rsp+0x40], xmm4
00007cc2697d7e09  vmovaps [rsp+0x50], xmm5
00007cc2697d7e0f  vmovaps [rsp+0x60], xmm6
00007cc2697d7e15  vmovaps [rsp+0x70], xmm7
00007cc2697d7e1b  vmovaps [rsp+0x80], xmm8
00007cc2697d7e24  vmovaps [rsp+0x90], xmm9
00007cc2697d7e2d  vmovaps [rsp+0xA0], xmm10
00007cc2697d7e36  vmovaps [rsp+0xB0], xmm11
00007cc2697d7e3f  vmovaps [rsp+0xC0], xmm13
00007cc2697d7e48  vmovaps [rsp+0xD0], xmm14
00007cc2697d7e51  vmovaps [rsp+0xE0], xmm15
00007cc2697d7e5a  sub rsp, 0x40
00007cc2697d7e5e  lea rdi, [rsp]
00007cc2697d7e62  lea rsi, [rsp+0x10]
00007cc2697d7e67  lea rdx, [rsp+0x20]
00007cc2697d7e6c  lea rcx, [rsp+0x30]
00007cc2697d7e71  mov r8d, 0x00
00007cc2697d7e77  lea r9, [r15+0x3A8]
00007cc2697d7e7e  movaps [rdi], xmm12
00007cc2697d7e82  movaps [rsi], xmm3
00007cc2697d7e85  movaps [rdx], xmm14
00007cc2697d7e89  movaps [rcx], xmm5
00007cc2697d7e8c  mov rax, 0x653E5FFFBA50
00007cc2697d7e96  call rax
00007cc2697d7e98  movaps xmm12, [rsp]
00007cc2697d7e9d  add rsp, 0x40
00007cc2697d7ea1  vmovaps xmm0, [rsp]
00007cc2697d7ea6  vmovaps xmm1, [rsp+0x10]
00007cc2697d7eac  vmovaps xmm2, [rsp+0x20]
00007cc2697d7eb2  vmovaps xmm3, [rsp+0x30]
00007cc2697d7eb8  vmovaps xmm4, [rsp+0x40]
00007cc2697d7ebe  vmovaps xmm5, [rsp+0x50]
00007cc2697d7ec4  vmovaps xmm6, [rsp+0x60]
00007cc2697d7eca  vmovaps xmm7, [rsp+0x70]
00007cc2697d7ed0  vmovaps xmm8, [rsp+0x80]
00007cc2697d7ed9  vmovaps xmm9, [rsp+0x90]
00007cc2697d7ee2  vmovaps xmm10, [rsp+0xA0]
00007cc2697d7eeb  vmovaps xmm11, [rsp+0xB0]
00007cc2697d7ef4  vmovaps xmm13, [rsp+0xC0]
00007cc2697d7efd  vmovaps xmm14, [rsp+0xD0]
00007cc2697d7f06  vmovaps xmm15, [rsp+0xE0]
00007cc2697d7f0f  add rsp, 0xF0
00007cc2697d7f16  pop r11
00007cc2697d7f18  pop r10
00007cc2697d7f1a  pop r9
00007cc2697d7f1c  pop r8
00007cc2697d7f1e  pop rsi
00007cc2697d7f1f  pop rdi
00007cc2697d7f20  pop rdx
00007cc2697d7f21  pop rcx
00007cc2697d7f22  pop rax
00007cc2697d7f23  add rsp, 0x08
00007cc2697d7f27  jmp 0x00007CC2697D68CB
00007cc2697d7f2c  sub rsp, 0x08
00007cc2697d7f30  push rax
00007cc2697d7f31  push rcx
00007cc2697d7f32  push rdx
00007cc2697d7f33  push rdi
00007cc2697d7f34  push rsi
00007cc2697d7f35  push r8
00007cc2697d7f37  push r9
00007cc2697d7f39  push r10
00007cc2697d7f3b  push r11
00007cc2697d7f3d  sub rsp, 0xF0
00007cc2697d7f44  vmovaps [rsp], xmm0
00007cc2697d7f49  vmovaps [rsp+0x10], xmm1
00007cc2697d7f4f  vmovaps [rsp+0x20], xmm2
00007cc2697d7f55  vmovaps [rsp+0x30], xmm3
00007cc2697d7f5b  vmovaps [rsp+0x40], xmm4
00007cc2697d7f61  vmovaps [rsp+0x50], xmm5
00007cc2697d7f67  vmovaps [rsp+0x60], xmm6
00007cc2697d7f6d  vmovaps [rsp+0x70], xmm7
00007cc2697d7f73  vmovaps [rsp+0x80], xmm8
00007cc2697d7f7c  vmovaps [rsp+0x90], xmm9
00007cc2697d7f85  vmovaps [rsp+0xA0], xmm11
00007cc2697d7f8e  vmovaps [rsp+0xB0], xmm12
00007cc2697d7f97  vmovaps [rsp+0xC0], xmm13
00007cc2697d7fa0  vmovaps [rsp+0xD0], xmm14
00007cc2697d7fa9  vmovaps [rsp+0xE0], xmm15
00007cc2697d7fb2  sub rsp, 0x40
00007cc2697d7fb6  lea rdi, [rsp]
00007cc2697d7fba  lea rsi, [rsp+0x10]
00007cc2697d7fbf  lea rdx, [rsp+0x20]
00007cc2697d7fc4  lea rcx, [rsp+0x30]
00007cc2697d7fc9  mov r8d, 0x00
00007cc2697d7fcf  lea r9, [r15+0x3A8]
00007cc2697d7fd6  movaps [rdi], xmm10
00007cc2697d7fda  movaps [rsi], xmm9
00007cc2697d7fde  movaps [rdx], xmm7
00007cc2697d7fe1  movaps [rcx], xmm14
00007cc2697d7fe5  mov rax, 0x653E5FFFBA50
00007cc2697d7fef  call rax
00007cc2697d7ff1  movaps xmm10, [rsp]
00007cc2697d7ff6  add rsp, 0x40
00007cc2697d7ffa  vmovaps xmm0, [rsp]
00007cc2697d7fff  vmovaps xmm1, [rsp+0x10]
00007cc2697d8005  vmovaps xmm2, [rsp+0x20]
00007cc2697d800b  vmovaps xmm3, [rsp+0x30]
00007cc2697d8011  vmovaps xmm4, [rsp+0x40]
00007cc2697d8017  vmovaps xmm5, [rsp+0x50]
00007cc2697d801d  vmovaps xmm6, [rsp+0x60]
00007cc2697d8023  vmovaps xmm7, [rsp+0x70]
00007cc2697d8029  vmovaps xmm8, [rsp+0x80]
00007cc2697d8032  vmovaps xmm9, [rsp+0x90]
00007cc2697d803b  vmovaps xmm11, [rsp+0xA0]
00007cc2697d8044  vmovaps xmm12, [rsp+0xB0]
00007cc2697d804d  vmovaps xmm13, [rsp+0xC0]
00007cc2697d8056  vmovaps xmm14, [rsp+0xD0]
00007cc2697d805f  vmovaps xmm15, [rsp+0xE0]
00007cc2697d8068  add rsp, 0xF0
00007cc2697d806f  pop r11
00007cc2697d8071  pop r10
00007cc2697d8073  pop r9
00007cc2697d8075  pop r8
00007cc2697d8077  pop rsi
00007cc2697d8078  pop rdi
00007cc2697d8079  pop rdx
00007cc2697d807a  pop rcx
00007cc2697d807b  pop rax
00007cc2697d807c  add rsp, 0x08
00007cc2697d8080  jmp 0x00007CC2697D68F1
00007cc2697d8085  call 0x00007CC2696E45A0
00007cc2697d808a  jmp 0x00007CC2697D68FE
00007cc2697d808f  sub rsp, 0x08
00007cc2697d8093  push rax
00007cc2697d8094  push rcx
00007cc2697d8095  push rdx
00007cc2697d8096  push rdi
00007cc2697d8097  push rsi
00007cc2697d8098  push r8
00007cc2697d809a  push r9
00007cc2697d809c  push r10
00007cc2697d809e  push r11
00007cc2697d80a0  sub rsp, 0xF0
00007cc2697d80a7  vmovaps [rsp], xmm0
00007cc2697d80ac  vmovaps [rsp+0x10], xmm1
00007cc2697d80b2  vmovaps [rsp+0x20], xmm2
00007cc2697d80b8  vmovaps [rsp+0x30], xmm3
00007cc2697d80be  vmovaps [rsp+0x40], xmm4
00007cc2697d80c4  vmovaps [rsp+0x50], xmm6
00007cc2697d80ca  vmovaps [rsp+0x60], xmm7
00007cc2697d80d0  vmovaps [rsp+0x70], xmm8
00007cc2697d80d6  vmovaps [rsp+0x80], xmm9
00007cc2697d80df  vmovaps [rsp+0x90], xmm10
00007cc2697d80e8  vmovaps [rsp+0xA0], xmm11
00007cc2697d80f1  vmovaps [rsp+0xB0], xmm12
00007cc2697d80fa  vmovaps [rsp+0xC0], xmm13
00007cc2697d8103  vmovaps [rsp+0xD0], xmm14
00007cc2697d810c  vmovaps [rsp+0xE0], xmm15
00007cc2697d8115  sub rsp, 0x40
00007cc2697d8119  lea rdi, [rsp]
00007cc2697d811d  lea rsi, [rsp+0x10]
00007cc2697d8122  lea rdx, [rsp+0x20]
00007cc2697d8127  lea rcx, [rsp+0x30]
00007cc2697d812c  mov r8d, 0x00
00007cc2697d8132  lea r9, [r15+0x3A8]
00007cc2697d8139  movaps [rdi], xmm5
00007cc2697d813c  movaps [rsi], xmm6
00007cc2697d813f  movaps [rdx], xmm7
00007cc2697d8142  movaps [rcx], xmm9
00007cc2697d8146  mov rax, 0x653E5FFFBA50
00007cc2697d8150  call rax
00007cc2697d8152  movaps xmm5, [rsp]
00007cc2697d8156  add rsp, 0x40
00007cc2697d815a  vmovaps xmm0, [rsp]
00007cc2697d815f  vmovaps xmm1, [rsp+0x10]
00007cc2697d8165  vmovaps xmm2, [rsp+0x20]
00007cc2697d816b  vmovaps xmm3, [rsp+0x30]
00007cc2697d8171  vmovaps xmm4, [rsp+0x40]
00007cc2697d8177  vmovaps xmm6, [rsp+0x50]
00007cc2697d817d  vmovaps xmm7, [rsp+0x60]
00007cc2697d8183  vmovaps xmm8, [rsp+0x70]
00007cc2697d8189  vmovaps xmm9, [rsp+0x80]
00007cc2697d8192  vmovaps xmm10, [rsp+0x90]
00007cc2697d819b  vmovaps xmm11, [rsp+0xA0]
00007cc2697d81a4  vmovaps xmm12, [rsp+0xB0]
00007cc2697d81ad  vmovaps xmm13, [rsp+0xC0]
00007cc2697d81b6  vmovaps xmm14, [rsp+0xD0]
00007cc2697d81bf  vmovaps xmm15, [rsp+0xE0]
00007cc2697d81c8  add rsp, 0xF0
00007cc2697d81cf  pop r11
00007cc2697d81d1  pop r10
00007cc2697d81d3  pop r9
00007cc2697d81d5  pop r8
00007cc2697d81d7  pop rsi
00007cc2697d81d8  pop rdi
00007cc2697d81d9  pop rdx
00007cc2697d81da  pop rcx
00007cc2697d81db  pop rax
00007cc2697d81dc  add rsp, 0x08
00007cc2697d81e0  jmp 0x00007CC2697D6930
00007cc2697d81e5  sub rsp, 0x08
00007cc2697d81e9  push rax
00007cc2697d81ea  push rcx
00007cc2697d81eb  push rdx
00007cc2697d81ec  push rdi
00007cc2697d81ed  push rsi
00007cc2697d81ee  push r8
00007cc2697d81f0  push r9
00007cc2697d81f2  push r10
00007cc2697d81f4  push r11
00007cc2697d81f6  sub rsp, 0xF0
00007cc2697d81fd  vmovaps [rsp], xmm0
00007cc2697d8202  vmovaps [rsp+0x10], xmm1
00007cc2697d8208  vmovaps [rsp+0x20], xmm2
00007cc2697d820e  vmovaps [rsp+0x30], xmm3
00007cc2697d8214  vmovaps [rsp+0x40], xmm4
00007cc2697d821a  vmovaps [rsp+0x50], xmm5
00007cc2697d8220  vmovaps [rsp+0x60], xmm6
00007cc2697d8226  vmovaps [rsp+0x70], xmm8
00007cc2697d822c  vmovaps [rsp+0x80], xmm9
00007cc2697d8235  vmovaps [rsp+0x90], xmm10
00007cc2697d823e  vmovaps [rsp+0xA0], xmm11
00007cc2697d8247  vmovaps [rsp+0xB0], xmm12
00007cc2697d8250  vmovaps [rsp+0xC0], xmm13
00007cc2697d8259  vmovaps [rsp+0xD0], xmm14
00007cc2697d8262  vmovaps [rsp+0xE0], xmm15
00007cc2697d826b  sub rsp, 0x40
00007cc2697d826f  lea rdi, [rsp]
00007cc2697d8273  lea rsi, [rsp+0x10]
00007cc2697d8278  lea rdx, [rsp+0x20]
00007cc2697d827d  lea rcx, [rsp+0x30]
00007cc2697d8282  mov r8d, 0x00
00007cc2697d8288  lea r9, [r15+0x3A8]
00007cc2697d828f  movaps [rdi], xmm7
00007cc2697d8292  movaps [rsi], xmm13
00007cc2697d8296  movaps [rdx], xmm1
00007cc2697d8299  movaps [rcx], xmm9
00007cc2697d829d  mov rax, 0x653E5FFFBA50
00007cc2697d82a7  call rax
00007cc2697d82a9  movaps xmm7, [rsp]
00007cc2697d82ad  add rsp, 0x40
00007cc2697d82b1  vmovaps xmm0, [rsp]
00007cc2697d82b6  vmovaps xmm1, [rsp+0x10]
00007cc2697d82bc  vmovaps xmm2, [rsp+0x20]
00007cc2697d82c2  vmovaps xmm3, [rsp+0x30]
00007cc2697d82c8  vmovaps xmm4, [rsp+0x40]
00007cc2697d82ce  vmovaps xmm5, [rsp+0x50]
00007cc2697d82d4  vmovaps xmm6, [rsp+0x60]
00007cc2697d82da  vmovaps xmm8, [rsp+0x70]
00007cc2697d82e0  vmovaps xmm9, [rsp+0x80]
00007cc2697d82e9  vmovaps xmm10, [rsp+0x90]
00007cc2697d82f2  vmovaps xmm11, [rsp+0xA0]
00007cc2697d82fb  vmovaps xmm12, [rsp+0xB0]
00007cc2697d8304  vmovaps xmm13, [rsp+0xC0]
00007cc2697d830d  vmovaps xmm14, [rsp+0xD0]
00007cc2697d8316  vmovaps xmm15, [rsp+0xE0]
00007cc2697d831f  add rsp, 0xF0
00007cc2697d8326  pop r11
00007cc2697d8328  pop r10
00007cc2697d832a  pop r9
00007cc2697d832c  pop r8
00007cc2697d832e  pop rsi
00007cc2697d832f  pop rdi
00007cc2697d8330  pop rdx
00007cc2697d8331  pop rcx
00007cc2697d8332  pop rax
00007cc2697d8333  add rsp, 0x08
00007cc2697d8337  jmp 0x00007CC2697D6955
00007cc2697d833c  call 0x00007CC2696E3320
00007cc2697d8341  jmp 0x00007CC2697D6978
00007cc2697d8346  call 0x00007CC2696DE950
00007cc2697d834b  jmp 0x00007CC2697D6982
00007cc2697d8350  sub rsp, 0x08
00007cc2697d8354  push rax
00007cc2697d8355  push rcx
00007cc2697d8356  push rdx
00007cc2697d8357  push rdi
00007cc2697d8358  push rsi
00007cc2697d8359  push r8
00007cc2697d835b  push r9
00007cc2697d835d  push r10
00007cc2697d835f  push r11
00007cc2697d8361  sub rsp, 0xF0
00007cc2697d8368  vmovaps [rsp], xmm0
00007cc2697d836d  vmovaps [rsp+0x10], xmm1
00007cc2697d8373  vmovaps [rsp+0x20], xmm3
00007cc2697d8379  vmovaps [rsp+0x30], xmm4
00007cc2697d837f  vmovaps [rsp+0x40], xmm5
00007cc2697d8385  vmovaps [rsp+0x50], xmm6
00007cc2697d838b  vmovaps [rsp+0x60], xmm7
00007cc2697d8391  vmovaps [rsp+0x70], xmm8
00007cc2697d8397  vmovaps [rsp+0x80], xmm9
00007cc2697d83a0  vmovaps [rsp+0x90], xmm10
00007cc2697d83a9  vmovaps [rsp+0xA0], xmm11
00007cc2697d83b2  vmovaps [rsp+0xB0], xmm12
00007cc2697d83bb  vmovaps [rsp+0xC0], xmm13
00007cc2697d83c4  vmovaps [rsp+0xD0], xmm14
00007cc2697d83cd  vmovaps [rsp+0xE0], xmm15
00007cc2697d83d6  sub rsp, 0x40
00007cc2697d83da  lea rdi, [rsp]
00007cc2697d83de  lea rsi, [rsp+0x10]
00007cc2697d83e3  lea rdx, [rsp+0x20]
00007cc2697d83e8  lea rcx, [rsp+0x30]
00007cc2697d83ed  mov r8d, 0x00
00007cc2697d83f3  lea r9, [r15+0x3A8]
00007cc2697d83fa  movaps [rdi], xmm2
00007cc2697d83fd  movaps [rsi], xmm12
00007cc2697d8401  movaps [rdx], xmm6
00007cc2697d8404  movaps [rcx], xmm3
00007cc2697d8407  mov rax, 0x653E5FFFBA50
00007cc2697d8411  call rax
00007cc2697d8413  movaps xmm2, [rsp]
00007cc2697d8417  add rsp, 0x40
00007cc2697d841b  vmovaps xmm0, [rsp]
00007cc2697d8420  vmovaps xmm1, [rsp+0x10]
00007cc2697d8426  vmovaps xmm3, [rsp+0x20]
00007cc2697d842c  vmovaps xmm4, [rsp+0x30]
00007cc2697d8432  vmovaps xmm5, [rsp+0x40]
00007cc2697d8438  vmovaps xmm6, [rsp+0x50]
00007cc2697d843e  vmovaps xmm7, [rsp+0x60]
00007cc2697d8444  vmovaps xmm8, [rsp+0x70]
00007cc2697d844a  vmovaps xmm9, [rsp+0x80]
00007cc2697d8453  vmovaps xmm10, [rsp+0x90]
00007cc2697d845c  vmovaps xmm11, [rsp+0xA0]
00007cc2697d8465  vmovaps xmm12, [rsp+0xB0]
00007cc2697d846e  vmovaps xmm13, [rsp+0xC0]
00007cc2697d8477  vmovaps xmm14, [rsp+0xD0]
00007cc2697d8480  vmovaps xmm15, [rsp+0xE0]
00007cc2697d8489  add rsp, 0xF0
00007cc2697d8490  pop r11
00007cc2697d8492  pop r10
00007cc2697d8494  pop r9
00007cc2697d8496  pop r8
00007cc2697d8498  pop rsi
00007cc2697d8499  pop rdi
00007cc2697d849a  pop rdx
00007cc2697d849b  pop rcx
00007cc2697d849c  pop rax
00007cc2697d849d  add rsp, 0x08
00007cc2697d84a1  jmp 0x00007CC2697D69C8
00007cc2697d84a6  sub rsp, 0x08
00007cc2697d84aa  push rax
00007cc2697d84ab  push rcx
00007cc2697d84ac  push rdx
00007cc2697d84ad  push rdi
00007cc2697d84ae  push rsi
00007cc2697d84af  push r8
00007cc2697d84b1  push r9
00007cc2697d84b3  push r10
00007cc2697d84b5  push r11
00007cc2697d84b7  sub rsp, 0xF0
00007cc2697d84be  vmovaps [rsp], xmm0
00007cc2697d84c3  vmovaps [rsp+0x10], xmm1
00007cc2697d84c9  vmovaps [rsp+0x20], xmm2
00007cc2697d84cf  vmovaps [rsp+0x30], xmm3
00007cc2697d84d5  vmovaps [rsp+0x40], xmm4
00007cc2697d84db  vmovaps [rsp+0x50], xmm5
00007cc2697d84e1  vmovaps [rsp+0x60], xmm7
00007cc2697d84e7  vmovaps [rsp+0x70], xmm8
00007cc2697d84ed  vmovaps [rsp+0x80], xmm9
00007cc2697d84f6  vmovaps [rsp+0x90], xmm10
00007cc2697d84ff  vmovaps [rsp+0xA0], xmm11
00007cc2697d8508  vmovaps [rsp+0xB0], xmm12
00007cc2697d8511  vmovaps [rsp+0xC0], xmm13
00007cc2697d851a  vmovaps [rsp+0xD0], xmm14
00007cc2697d8523  vmovaps [rsp+0xE0], xmm15
00007cc2697d852c  sub rsp, 0x40
00007cc2697d8530  lea rdi, [rsp]
00007cc2697d8534  lea rsi, [rsp+0x10]
00007cc2697d8539  lea rdx, [rsp+0x20]
00007cc2697d853e  lea rcx, [rsp+0x30]
00007cc2697d8543  mov r8d, 0x00
00007cc2697d8549  lea r9, [r15+0x3A8]
00007cc2697d8550  movaps [rdi], xmm6
00007cc2697d8553  movaps [rsi], xmm10
00007cc2697d8557  movaps [rdx], xmm12
00007cc2697d855b  movaps [rcx], xmm1
00007cc2697d855e  mov rax, 0x653E5FFFBA50
00007cc2697d8568  call rax
00007cc2697d856a  movaps xmm6, [rsp]
00007cc2697d856e  add rsp, 0x40
00007cc2697d8572  vmovaps xmm0, [rsp]
00007cc2697d8577  vmovaps xmm1, [rsp+0x10]
00007cc2697d857d  vmovaps xmm2, [rsp+0x20]
00007cc2697d8583  vmovaps xmm3, [rsp+0x30]
00007cc2697d8589  vmovaps xmm4, [rsp+0x40]
00007cc2697d858f  vmovaps xmm5, [rsp+0x50]
00007cc2697d8595  vmovaps xmm7, [rsp+0x60]
00007cc2697d859b  vmovaps xmm8, [rsp+0x70]
00007cc2697d85a1  vmovaps xmm9, [rsp+0x80]
00007cc2697d85aa  vmovaps xmm10, [rsp+0x90]
00007cc2697d85b3  vmovaps xmm11, [rsp+0xA0]
00007cc2697d85bc  vmovaps xmm12, [rsp+0xB0]
00007cc2697d85c5  vmovaps xmm13, [rsp+0xC0]
00007cc2697d85ce  vmovaps xmm14, [rsp+0xD0]
00007cc2697d85d7  vmovaps xmm15, [rsp+0xE0]
00007cc2697d85e0  add rsp, 0xF0
00007cc2697d85e7  pop r11
00007cc2697d85e9  pop r10
00007cc2697d85eb  pop r9
00007cc2697d85ed  pop r8
00007cc2697d85ef  pop rsi
00007cc2697d85f0  pop rdi
00007cc2697d85f1  pop rdx
00007cc2697d85f2  pop rcx
00007cc2697d85f3  pop rax
00007cc2697d85f4  add rsp, 0x08
00007cc2697d85f8  jmp 0x00007CC2697D69F6
00007cc2697d85fd  sub rsp, 0x08
00007cc2697d8601  push rax
00007cc2697d8602  push rcx
00007cc2697d8603  push rdx
00007cc2697d8604  push rdi
00007cc2697d8605  push rsi
00007cc2697d8606  push r8
00007cc2697d8608  push r9
00007cc2697d860a  push r10
00007cc2697d860c  push r11
00007cc2697d860e  sub rsp, 0xF0
00007cc2697d8615  vmovaps [rsp], xmm0
00007cc2697d861a  vmovaps [rsp+0x10], xmm1
00007cc2697d8620  vmovaps [rsp+0x20], xmm2
00007cc2697d8626  vmovaps [rsp+0x30], xmm3
00007cc2697d862c  vmovaps [rsp+0x40], xmm4
00007cc2697d8632  vmovaps [rsp+0x50], xmm5
00007cc2697d8638  vmovaps [rsp+0x60], xmm6
00007cc2697d863e  vmovaps [rsp+0x70], xmm7
00007cc2697d8644  vmovaps [rsp+0x80], xmm8
00007cc2697d864d  vmovaps [rsp+0x90], xmm9
00007cc2697d8656  vmovaps [rsp+0xA0], xmm11
00007cc2697d865f  vmovaps [rsp+0xB0], xmm12
00007cc2697d8668  vmovaps [rsp+0xC0], xmm13
00007cc2697d8671  vmovaps [rsp+0xD0], xmm14
00007cc2697d867a  vmovaps [rsp+0xE0], xmm15
00007cc2697d8683  sub rsp, 0x40
00007cc2697d8687  lea rdi, [rsp]
00007cc2697d868b  lea rsi, [rsp+0x10]
00007cc2697d8690  lea rdx, [rsp+0x20]
00007cc2697d8695  lea rcx, [rsp+0x30]
00007cc2697d869a  mov r8d, 0x00
00007cc2697d86a0  lea r9, [r15+0x3A8]
00007cc2697d86a7  movaps [rdi], xmm10
00007cc2697d86ab  movaps [rsi], xmm5
00007cc2697d86ae  movaps [rdx], xmm12
00007cc2697d86b2  movaps [rcx], xmm1
00007cc2697d86b5  mov rax, 0x653E5FFFBA50
00007cc2697d86bf  call rax
00007cc2697d86c1  movaps xmm10, [rsp]
00007cc2697d86c6  add rsp, 0x40
00007cc2697d86ca  vmovaps xmm0, [rsp]
00007cc2697d86cf  vmovaps xmm1, [rsp+0x10]
00007cc2697d86d5  vmovaps xmm2, [rsp+0x20]
00007cc2697d86db  vmovaps xmm3, [rsp+0x30]
00007cc2697d86e1  vmovaps xmm4, [rsp+0x40]
00007cc2697d86e7  vmovaps xmm5, [rsp+0x50]
00007cc2697d86ed  vmovaps xmm6, [rsp+0x60]
00007cc2697d86f3  vmovaps xmm7, [rsp+0x70]
00007cc2697d86f9  vmovaps xmm8, [rsp+0x80]
00007cc2697d8702  vmovaps xmm9, [rsp+0x90]
00007cc2697d870b  vmovaps xmm11, [rsp+0xA0]
00007cc2697d8714  vmovaps xmm12, [rsp+0xB0]
00007cc2697d871d  vmovaps xmm13, [rsp+0xC0]
00007cc2697d8726  vmovaps xmm14, [rsp+0xD0]
00007cc2697d872f  vmovaps xmm15, [rsp+0xE0]
00007cc2697d8738  add rsp, 0xF0
00007cc2697d873f  pop r11
00007cc2697d8741  pop r10
00007cc2697d8743  pop r9
00007cc2697d8745  pop r8
00007cc2697d8747  pop rsi
00007cc2697d8748  pop rdi
00007cc2697d8749  pop rdx
00007cc2697d874a  pop rcx
00007cc2697d874b  pop rax
00007cc2697d874c  add rsp, 0x08
00007cc2697d8750  jmp 0x00007CC2697D6A25
00007cc2697d8755  sub rsp, 0x08
00007cc2697d8759  push rax
00007cc2697d875a  push rcx
00007cc2697d875b  push rdx
00007cc2697d875c  push rdi
00007cc2697d875d  push rsi
00007cc2697d875e  push r8
00007cc2697d8760  push r9
00007cc2697d8762  push r10
00007cc2697d8764  push r11
00007cc2697d8766  sub rsp, 0xF0
00007cc2697d876d  vmovaps [rsp], xmm0
00007cc2697d8772  vmovaps [rsp+0x10], xmm1
00007cc2697d8778  vmovaps [rsp+0x20], xmm2
00007cc2697d877e  vmovaps [rsp+0x30], xmm3
00007cc2697d8784  vmovaps [rsp+0x40], xmm4
00007cc2697d878a  vmovaps [rsp+0x50], xmm5
00007cc2697d8790  vmovaps [rsp+0x60], xmm6
00007cc2697d8796  vmovaps [rsp+0x70], xmm7
00007cc2697d879c  vmovaps [rsp+0x80], xmm8
00007cc2697d87a5  vmovaps [rsp+0x90], xmm9
00007cc2697d87ae  vmovaps [rsp+0xA0], xmm10
00007cc2697d87b7  vmovaps [rsp+0xB0], xmm11
00007cc2697d87c0  vmovaps [rsp+0xC0], xmm13
00007cc2697d87c9  vmovaps [rsp+0xD0], xmm14
00007cc2697d87d2  vmovaps [rsp+0xE0], xmm15
00007cc2697d87db  sub rsp, 0x40
00007cc2697d87df  lea rdi, [rsp]
00007cc2697d87e3  lea rsi, [rsp+0x10]
00007cc2697d87e8  lea rdx, [rsp+0x20]
00007cc2697d87ed  lea rcx, [rsp+0x30]
00007cc2697d87f2  mov r8d, 0x00
00007cc2697d87f8  lea r9, [r15+0x3A8]
00007cc2697d87ff  movaps [rdi], xmm12
00007cc2697d8803  movaps [rsi], xmm7
00007cc2697d8806  movaps [rdx], xmm15
00007cc2697d880a  movaps [rcx], xmm1
00007cc2697d880d  mov rax, 0x653E5FFFBA50
00007cc2697d8817  call rax
00007cc2697d8819  movaps xmm12, [rsp]
00007cc2697d881e  add rsp, 0x40
00007cc2697d8822  vmovaps xmm0, [rsp]
00007cc2697d8827  vmovaps xmm1, [rsp+0x10]
00007cc2697d882d  vmovaps xmm2, [rsp+0x20]
00007cc2697d8833  vmovaps xmm3, [rsp+0x30]
00007cc2697d8839  vmovaps xmm4, [rsp+0x40]
00007cc2697d883f  vmovaps xmm5, [rsp+0x50]
00007cc2697d8845  vmovaps xmm6, [rsp+0x60]
00007cc2697d884b  vmovaps xmm7, [rsp+0x70]
00007cc2697d8851  vmovaps xmm8, [rsp+0x80]
00007cc2697d885a  vmovaps xmm9, [rsp+0x90]
00007cc2697d8863  vmovaps xmm10, [rsp+0xA0]
00007cc2697d886c  vmovaps xmm11, [rsp+0xB0]
00007cc2697d8875  vmovaps xmm13, [rsp+0xC0]
00007cc2697d887e  vmovaps xmm14, [rsp+0xD0]
00007cc2697d8887  vmovaps xmm15, [rsp+0xE0]
00007cc2697d8890  add rsp, 0xF0
00007cc2697d8897  pop r11
00007cc2697d8899  pop r10
00007cc2697d889b  pop r9
00007cc2697d889d  pop r8
00007cc2697d889f  pop rsi
00007cc2697d88a0  pop rdi
00007cc2697d88a1  pop rdx
00007cc2697d88a2  pop rcx
00007cc2697d88a3  pop rax
00007cc2697d88a4  add rsp, 0x08
00007cc2697d88a8  jmp 0x00007CC2697D6A4E
00007cc2697d88ad  call 0x00007CC2696D64F0
00007cc2697d88b2  jmp 0x00007CC2697D6A58
00007cc2697d88b7  call 0x00007CC2696E5820
00007cc2697d88bc  jmp 0x00007CC2697D6A62
00007cc2697d88c1  sub rsp, 0x08
00007cc2697d88c5  push rax
00007cc2697d88c6  push rcx
00007cc2697d88c7  push rdx
00007cc2697d88c8  push rdi
00007cc2697d88c9  push rsi
00007cc2697d88ca  push r8
00007cc2697d88cc  push r9
00007cc2697d88ce  push r10
00007cc2697d88d0  push r11
00007cc2697d88d2  sub rsp, 0xF0
00007cc2697d88d9  vmovaps [rsp], xmm0
00007cc2697d88de  vmovaps [rsp+0x10], xmm1
00007cc2697d88e4  vmovaps [rsp+0x20], xmm2
00007cc2697d88ea  vmovaps [rsp+0x30], xmm3
00007cc2697d88f0  vmovaps [rsp+0x40], xmm4
00007cc2697d88f6  vmovaps [rsp+0x50], xmm5
00007cc2697d88fc  vmovaps [rsp+0x60], xmm6
00007cc2697d8902  vmovaps [rsp+0x70], xmm8
00007cc2697d8908  vmovaps [rsp+0x80], xmm9
00007cc2697d8911  vmovaps [rsp+0x90], xmm10
00007cc2697d891a  vmovaps [rsp+0xA0], xmm11
00007cc2697d8923  vmovaps [rsp+0xB0], xmm12
00007cc2697d892c  vmovaps [rsp+0xC0], xmm13
00007cc2697d8935  vmovaps [rsp+0xD0], xmm14
00007cc2697d893e  vmovaps [rsp+0xE0], xmm15
00007cc2697d8947  sub rsp, 0x40
00007cc2697d894b  lea rdi, [rsp]
00007cc2697d894f  lea rsi, [rsp+0x10]
00007cc2697d8954  lea rdx, [rsp+0x20]
00007cc2697d8959  lea rcx, [rsp+0x30]
00007cc2697d895e  mov r8d, 0x00
00007cc2697d8964  lea r9, [r15+0x3A8]
00007cc2697d896b  movaps [rdi], xmm7
00007cc2697d896e  movaps [rsi], xmm2
00007cc2697d8971  movaps [rdx], xmm9
00007cc2697d8975  movaps [rcx], xmm11
00007cc2697d8979  mov rax, 0x653E5FFFBA50
00007cc2697d8983  call rax
00007cc2697d8985  movaps xmm7, [rsp]
00007cc2697d8989  add rsp, 0x40
00007cc2697d898d  vmovaps xmm0, [rsp]
00007cc2697d8992  vmovaps xmm1, [rsp+0x10]
00007cc2697d8998  vmovaps xmm2, [rsp+0x20]
00007cc2697d899e  vmovaps xmm3, [rsp+0x30]
00007cc2697d89a4  vmovaps xmm4, [rsp+0x40]
00007cc2697d89aa  vmovaps xmm5, [rsp+0x50]
00007cc2697d89b0  vmovaps xmm6, [rsp+0x60]
00007cc2697d89b6  vmovaps xmm8, [rsp+0x70]
00007cc2697d89bc  vmovaps xmm9, [rsp+0x80]
00007cc2697d89c5  vmovaps xmm10, [rsp+0x90]
00007cc2697d89ce  vmovaps xmm11, [rsp+0xA0]
00007cc2697d89d7  vmovaps xmm12, [rsp+0xB0]
00007cc2697d89e0  vmovaps xmm13, [rsp+0xC0]
00007cc2697d89e9  vmovaps xmm14, [rsp+0xD0]
00007cc2697d89f2  vmovaps xmm15, [rsp+0xE0]
00007cc2697d89fb  add rsp, 0xF0
00007cc2697d8a02  pop r11
00007cc2697d8a04  pop r10
00007cc2697d8a06  pop r9
00007cc2697d8a08  pop r8
00007cc2697d8a0a  pop rsi
00007cc2697d8a0b  pop rdi
00007cc2697d8a0c  pop rdx
00007cc2697d8a0d  pop rcx
00007cc2697d8a0e  pop rax
00007cc2697d8a0f  add rsp, 0x08
00007cc2697d8a13  jmp 0x00007CC2697D6A96
00007cc2697d8a18  sub rsp, 0x08
00007cc2697d8a1c  push rax
00007cc2697d8a1d  push rcx
00007cc2697d8a1e  push rdx
00007cc2697d8a1f  push rdi
00007cc2697d8a20  push rsi
00007cc2697d8a21  push r8
00007cc2697d8a23  push r9
00007cc2697d8a25  push r10
00007cc2697d8a27  push r11
00007cc2697d8a29  sub rsp, 0xF0
00007cc2697d8a30  vmovaps [rsp], xmm0
00007cc2697d8a35  vmovaps [rsp+0x10], xmm1
00007cc2697d8a3b  vmovaps [rsp+0x20], xmm2
00007cc2697d8a41  vmovaps [rsp+0x30], xmm3
00007cc2697d8a47  vmovaps [rsp+0x40], xmm4
00007cc2697d8a4d  vmovaps [rsp+0x50], xmm5
00007cc2697d8a53  vmovaps [rsp+0x60], xmm6
00007cc2697d8a59  vmovaps [rsp+0x70], xmm7
00007cc2697d8a5f  vmovaps [rsp+0x80], xmm8
00007cc2697d8a68  vmovaps [rsp+0x90], xmm10
00007cc2697d8a71  vmovaps [rsp+0xA0], xmm11
00007cc2697d8a7a  vmovaps [rsp+0xB0], xmm12
00007cc2697d8a83  vmovaps [rsp+0xC0], xmm13
00007cc2697d8a8c  vmovaps [rsp+0xD0], xmm14
00007cc2697d8a95  vmovaps [rsp+0xE0], xmm15
00007cc2697d8a9e  sub rsp, 0x40
00007cc2697d8aa2  lea rdi, [rsp]
00007cc2697d8aa6  lea rsi, [rsp+0x10]
00007cc2697d8aab  lea rdx, [rsp+0x20]
00007cc2697d8ab0  lea rcx, [rsp+0x30]
00007cc2697d8ab5  mov r8d, 0x00
00007cc2697d8abb  lea r9, [r15+0x3A8]
00007cc2697d8ac2  movaps [rdi], xmm9
00007cc2697d8ac6  movaps [rsi], xmm6
00007cc2697d8ac9  movaps [rdx], xmm1
00007cc2697d8acc  movaps [rcx], xmm11
00007cc2697d8ad0  mov rax, 0x653E5FFFBA50
00007cc2697d8ada  call rax
00007cc2697d8adc  movaps xmm9, [rsp]
00007cc2697d8ae1  add rsp, 0x40
00007cc2697d8ae5  vmovaps xmm0, [rsp]
00007cc2697d8aea  vmovaps xmm1, [rsp+0x10]
00007cc2697d8af0  vmovaps xmm2, [rsp+0x20]
00007cc2697d8af6  vmovaps xmm3, [rsp+0x30]
00007cc2697d8afc  vmovaps xmm4, [rsp+0x40]
00007cc2697d8b02  vmovaps xmm5, [rsp+0x50]
00007cc2697d8b08  vmovaps xmm6, [rsp+0x60]
00007cc2697d8b0e  vmovaps xmm7, [rsp+0x70]
00007cc2697d8b14  vmovaps xmm8, [rsp+0x80]
00007cc2697d8b1d  vmovaps xmm10, [rsp+0x90]
00007cc2697d8b26  vmovaps xmm11, [rsp+0xA0]
00007cc2697d8b2f  vmovaps xmm12, [rsp+0xB0]
00007cc2697d8b38  vmovaps xmm13, [rsp+0xC0]
00007cc2697d8b41  vmovaps xmm14, [rsp+0xD0]
00007cc2697d8b4a  vmovaps xmm15, [rsp+0xE0]
00007cc2697d8b53  add rsp, 0xF0
00007cc2697d8b5a  pop r11
00007cc2697d8b5c  pop r10
00007cc2697d8b5e  pop r9
00007cc2697d8b60  pop r8
00007cc2697d8b62  pop rsi
00007cc2697d8b63  pop rdi
00007cc2697d8b64  pop rdx
00007cc2697d8b65  pop rcx
00007cc2697d8b66  pop rax
00007cc2697d8b67  add rsp, 0x08
00007cc2697d8b6b  jmp 0x00007CC2697D6ABC
00007cc2697d8b70  sub rsp, 0x08
00007cc2697d8b74  push rax
00007cc2697d8b75  push rcx
00007cc2697d8b76  push rdx
00007cc2697d8b77  push rdi
00007cc2697d8b78  push rsi
00007cc2697d8b79  push r8
00007cc2697d8b7b  push r9
00007cc2697d8b7d  push r10
00007cc2697d8b7f  push r11
00007cc2697d8b81  sub rsp, 0xF0
00007cc2697d8b88  vmovaps [rsp], xmm0
00007cc2697d8b8d  vmovaps [rsp+0x10], xmm1
00007cc2697d8b93  vmovaps [rsp+0x20], xmm2
00007cc2697d8b99  vmovaps [rsp+0x30], xmm3
00007cc2697d8b9f  vmovaps [rsp+0x40], xmm4
00007cc2697d8ba5  vmovaps [rsp+0x50], xmm5
00007cc2697d8bab  vmovaps [rsp+0x60], xmm6
00007cc2697d8bb1  vmovaps [rsp+0x70], xmm7
00007cc2697d8bb7  vmovaps [rsp+0x80], xmm8
00007cc2697d8bc0  vmovaps [rsp+0x90], xmm9
00007cc2697d8bc9  vmovaps [rsp+0xA0], xmm10
00007cc2697d8bd2  vmovaps [rsp+0xB0], xmm12
00007cc2697d8bdb  vmovaps [rsp+0xC0], xmm13
00007cc2697d8be4  vmovaps [rsp+0xD0], xmm14
00007cc2697d8bed  vmovaps [rsp+0xE0], xmm15
00007cc2697d8bf6  sub rsp, 0x40
00007cc2697d8bfa  lea rdi, [rsp]
00007cc2697d8bfe  lea rsi, [rsp+0x10]
00007cc2697d8c03  lea rdx, [rsp+0x20]
00007cc2697d8c08  lea rcx, [rsp+0x30]
00007cc2697d8c0d  mov r8d, 0x00
00007cc2697d8c13  lea r9, [r15+0x3A8]
00007cc2697d8c1a  movaps [rdi], xmm11
00007cc2697d8c1e  movaps [rsi], xmm10
00007cc2697d8c22  movaps [rdx], xmm8
00007cc2697d8c26  movaps [rcx], xmm1
00007cc2697d8c29  mov rax, 0x653E5FFFBA50
00007cc2697d8c33  call rax
00007cc2697d8c35  movaps xmm11, [rsp]
00007cc2697d8c3a  add rsp, 0x40
00007cc2697d8c3e  vmovaps xmm0, [rsp]
00007cc2697d8c43  vmovaps xmm1, [rsp+0x10]
00007cc2697d8c49  vmovaps xmm2, [rsp+0x20]
00007cc2697d8c4f  vmovaps xmm3, [rsp+0x30]
00007cc2697d8c55  vmovaps xmm4, [rsp+0x40]
00007cc2697d8c5b  vmovaps xmm5, [rsp+0x50]
00007cc2697d8c61  vmovaps xmm6, [rsp+0x60]
00007cc2697d8c67  vmovaps xmm7, [rsp+0x70]
00007cc2697d8c6d  vmovaps xmm8, [rsp+0x80]
00007cc2697d8c76  vmovaps xmm9, [rsp+0x90]
00007cc2697d8c7f  vmovaps xmm10, [rsp+0xA0]
00007cc2697d8c88  vmovaps xmm12, [rsp+0xB0]
00007cc2697d8c91  vmovaps xmm13, [rsp+0xC0]
00007cc2697d8c9a  vmovaps xmm14, [rsp+0xD0]
00007cc2697d8ca3  vmovaps xmm15, [rsp+0xE0]
00007cc2697d8cac  add rsp, 0xF0
00007cc2697d8cb3  pop r11
00007cc2697d8cb5  pop r10
00007cc2697d8cb7  pop r9
00007cc2697d8cb9  pop r8
00007cc2697d8cbb  pop rsi
00007cc2697d8cbc  pop rdi
00007cc2697d8cbd  pop rdx
00007cc2697d8cbe  pop rcx
00007cc2697d8cbf  pop rax
00007cc2697d8cc0  add rsp, 0x08
00007cc2697d8cc4  jmp 0x00007CC2697D6AE2
00007cc2697d8cc9  sub rsp, 0x08
00007cc2697d8ccd  push rax
00007cc2697d8cce  push rcx
00007cc2697d8ccf  push rdx
00007cc2697d8cd0  push rdi
00007cc2697d8cd1  push rsi
00007cc2697d8cd2  push r8
00007cc2697d8cd4  push r9
00007cc2697d8cd6  push r10
00007cc2697d8cd8  push r11
00007cc2697d8cda  sub rsp, 0xF0
00007cc2697d8ce1  vmovaps [rsp], xmm0
00007cc2697d8ce6  vmovaps [rsp+0x10], xmm1
00007cc2697d8cec  vmovaps [rsp+0x20], xmm2
00007cc2697d8cf2  vmovaps [rsp+0x30], xmm3
00007cc2697d8cf8  vmovaps [rsp+0x40], xmm4
00007cc2697d8cfe  vmovaps [rsp+0x50], xmm5
00007cc2697d8d04  vmovaps [rsp+0x60], xmm6
00007cc2697d8d0a  vmovaps [rsp+0x70], xmm7
00007cc2697d8d10  vmovaps [rsp+0x80], xmm8
00007cc2697d8d19  vmovaps [rsp+0x90], xmm9
00007cc2697d8d22  vmovaps [rsp+0xA0], xmm11
00007cc2697d8d2b  vmovaps [rsp+0xB0], xmm12
00007cc2697d8d34  vmovaps [rsp+0xC0], xmm13
00007cc2697d8d3d  vmovaps [rsp+0xD0], xmm14
00007cc2697d8d46  vmovaps [rsp+0xE0], xmm15
00007cc2697d8d4f  sub rsp, 0x40
00007cc2697d8d53  lea rdi, [rsp]
00007cc2697d8d57  lea rsi, [rsp+0x10]
00007cc2697d8d5c  lea rdx, [rsp+0x20]
00007cc2697d8d61  lea rcx, [rsp+0x30]
00007cc2697d8d66  mov r8d, 0x00
00007cc2697d8d6c  lea r9, [r15+0x3A8]
00007cc2697d8d73  movaps [rdi], xmm10
00007cc2697d8d77  movaps [rsi], xmm12
00007cc2697d8d7b  movaps [rdx], xmm13
00007cc2697d8d7f  movaps [rcx], xmm1
00007cc2697d8d82  mov rax, 0x653E5FFFBA50
00007cc2697d8d8c  call rax
00007cc2697d8d8e  movaps xmm10, [rsp]
00007cc2697d8d93  add rsp, 0x40
00007cc2697d8d97  vmovaps xmm0, [rsp]
00007cc2697d8d9c  vmovaps xmm1, [rsp+0x10]
00007cc2697d8da2  vmovaps xmm2, [rsp+0x20]
00007cc2697d8da8  vmovaps xmm3, [rsp+0x30]
00007cc2697d8dae  vmovaps xmm4, [rsp+0x40]
00007cc2697d8db4  vmovaps xmm5, [rsp+0x50]
00007cc2697d8dba  vmovaps xmm6, [rsp+0x60]
00007cc2697d8dc0  vmovaps xmm7, [rsp+0x70]
00007cc2697d8dc6  vmovaps xmm8, [rsp+0x80]
00007cc2697d8dcf  vmovaps xmm9, [rsp+0x90]
00007cc2697d8dd8  vmovaps xmm11, [rsp+0xA0]
00007cc2697d8de1  vmovaps xmm12, [rsp+0xB0]
00007cc2697d8dea  vmovaps xmm13, [rsp+0xC0]
00007cc2697d8df3  vmovaps xmm14, [rsp+0xD0]
00007cc2697d8dfc  vmovaps xmm15, [rsp+0xE0]
00007cc2697d8e05  add rsp, 0xF0
00007cc2697d8e0c  pop r11
00007cc2697d8e0e  pop r10
00007cc2697d8e10  pop r9
00007cc2697d8e12  pop r8
00007cc2697d8e14  pop rsi
00007cc2697d8e15  pop rdi
00007cc2697d8e16  pop rdx
00007cc2697d8e17  pop rcx
00007cc2697d8e18  pop rax
00007cc2697d8e19  add rsp, 0x08
00007cc2697d8e1d  jmp 0x00007CC2697D6B08
00007cc2697d8e22  call 0x00007CC2696D64F0
00007cc2697d8e27  jmp 0x00007CC2697D6B12
00007cc2697d8e2c  call 0x00007CC2696E3320
00007cc2697d8e31  jmp 0x00007CC2697D6B1C
00007cc2697d8e36  sub rsp, 0x08
00007cc2697d8e3a  push rax
00007cc2697d8e3b  push rcx
00007cc2697d8e3c  push rdx
00007cc2697d8e3d  push rdi
00007cc2697d8e3e  push rsi
00007cc2697d8e3f  push r8
00007cc2697d8e41  push r9
00007cc2697d8e43  push r10
00007cc2697d8e45  push r11
00007cc2697d8e47  sub rsp, 0xF0
00007cc2697d8e4e  vmovaps [rsp], xmm0
00007cc2697d8e53  vmovaps [rsp+0x10], xmm1
00007cc2697d8e59  vmovaps [rsp+0x20], xmm2
00007cc2697d8e5f  vmovaps [rsp+0x30], xmm3
00007cc2697d8e65  vmovaps [rsp+0x40], xmm4
00007cc2697d8e6b  vmovaps [rsp+0x50], xmm5
00007cc2697d8e71  vmovaps [rsp+0x60], xmm6
00007cc2697d8e77  vmovaps [rsp+0x70], xmm7
00007cc2697d8e7d  vmovaps [rsp+0x80], xmm9
00007cc2697d8e86  vmovaps [rsp+0x90], xmm10
00007cc2697d8e8f  vmovaps [rsp+0xA0], xmm11
00007cc2697d8e98  vmovaps [rsp+0xB0], xmm12
00007cc2697d8ea1  vmovaps [rsp+0xC0], xmm13
00007cc2697d8eaa  vmovaps [rsp+0xD0], xmm14
00007cc2697d8eb3  vmovaps [rsp+0xE0], xmm15
00007cc2697d8ebc  sub rsp, 0x40
00007cc2697d8ec0  lea rdi, [rsp]
00007cc2697d8ec4  lea rsi, [rsp+0x10]
00007cc2697d8ec9  lea rdx, [rsp+0x20]
00007cc2697d8ece  lea rcx, [rsp+0x30]
00007cc2697d8ed3  mov r8d, 0x00
00007cc2697d8ed9  lea r9, [r15+0x3A8]
00007cc2697d8ee0  movaps [rdi], xmm8
00007cc2697d8ee4  movaps [rsi], xmm7
00007cc2697d8ee7  movaps [rdx], xmm4
00007cc2697d8eea  movaps [rcx], xmm12
00007cc2697d8eee  mov rax, 0x653E5FFFBA50
00007cc2697d8ef8  call rax
00007cc2697d8efa  movaps xmm8, [rsp]
00007cc2697d8eff  add rsp, 0x40
00007cc2697d8f03  vmovaps xmm0, [rsp]
00007cc2697d8f08  vmovaps xmm1, [rsp+0x10]
00007cc2697d8f0e  vmovaps xmm2, [rsp+0x20]
00007cc2697d8f14  vmovaps xmm3, [rsp+0x30]
00007cc2697d8f1a  vmovaps xmm4, [rsp+0x40]
00007cc2697d8f20  vmovaps xmm5, [rsp+0x50]
00007cc2697d8f26  vmovaps xmm6, [rsp+0x60]
00007cc2697d8f2c  vmovaps xmm7, [rsp+0x70]
00007cc2697d8f32  vmovaps xmm9, [rsp+0x80]
00007cc2697d8f3b  vmovaps xmm10, [rsp+0x90]
00007cc2697d8f44  vmovaps xmm11, [rsp+0xA0]
00007cc2697d8f4d  vmovaps xmm12, [rsp+0xB0]
00007cc2697d8f56  vmovaps xmm13, [rsp+0xC0]
00007cc2697d8f5f  vmovaps xmm14, [rsp+0xD0]
00007cc2697d8f68  vmovaps xmm15, [rsp+0xE0]
00007cc2697d8f71  add rsp, 0xF0
00007cc2697d8f78  pop r11
00007cc2697d8f7a  pop r10
00007cc2697d8f7c  pop r9
00007cc2697d8f7e  pop r8
00007cc2697d8f80  pop rsi
00007cc2697d8f81  pop rdi
00007cc2697d8f82  pop rdx
00007cc2697d8f83  pop rcx
00007cc2697d8f84  pop rax
00007cc2697d8f85  add rsp, 0x08
00007cc2697d8f89  jmp 0x00007CC2697D6B45
00007cc2697d8f8e  sub rsp, 0x08
00007cc2697d8f92  push rax
00007cc2697d8f93  push rcx
00007cc2697d8f94  push rdx
00007cc2697d8f95  push rdi
00007cc2697d8f96  push rsi
00007cc2697d8f97  push r8
00007cc2697d8f99  push r9
00007cc2697d8f9b  push r10
00007cc2697d8f9d  push r11
00007cc2697d8f9f  sub rsp, 0xF0
00007cc2697d8fa6  vmovaps [rsp], xmm0
00007cc2697d8fab  vmovaps [rsp+0x10], xmm1
00007cc2697d8fb1  vmovaps [rsp+0x20], xmm2
00007cc2697d8fb7  vmovaps [rsp+0x30], xmm3
00007cc2697d8fbd  vmovaps [rsp+0x40], xmm4
00007cc2697d8fc3  vmovaps [rsp+0x50], xmm5
00007cc2697d8fc9  vmovaps [rsp+0x60], xmm6
00007cc2697d8fcf  vmovaps [rsp+0x70], xmm8
00007cc2697d8fd5  vmovaps [rsp+0x80], xmm9
00007cc2697d8fde  vmovaps [rsp+0x90], xmm10
00007cc2697d8fe7  vmovaps [rsp+0xA0], xmm11
00007cc2697d8ff0  vmovaps [rsp+0xB0], xmm12
00007cc2697d8ff9  vmovaps [rsp+0xC0], xmm13
00007cc2697d9002  vmovaps [rsp+0xD0], xmm14
00007cc2697d900b  vmovaps [rsp+0xE0], xmm15
00007cc2697d9014  sub rsp, 0x40
00007cc2697d9018  lea rdi, [rsp]
00007cc2697d901c  lea rsi, [rsp+0x10]
00007cc2697d9021  lea rdx, [rsp+0x20]
00007cc2697d9026  lea rcx, [rsp+0x30]
00007cc2697d902b  mov r8d, 0x00
00007cc2697d9031  lea r9, [r15+0x3A8]
00007cc2697d9038  movaps [rdi], xmm7
00007cc2697d903b  movaps [rsi], xmm9
00007cc2697d903f  movaps [rdx], xmm14
00007cc2697d9043  movaps [rcx], xmm12
00007cc2697d9047  mov rax, 0x653E5FFFBA50
00007cc2697d9051  call rax
00007cc2697d9053  movaps xmm7, [rsp]
00007cc2697d9057  add rsp, 0x40
00007cc2697d905b  vmovaps xmm0, [rsp]
00007cc2697d9060  vmovaps xmm1, [rsp+0x10]
00007cc2697d9066  vmovaps xmm2, [rsp+0x20]
00007cc2697d906c  vmovaps xmm3, [rsp+0x30]
00007cc2697d9072  vmovaps xmm4, [rsp+0x40]
00007cc2697d9078  vmovaps xmm5, [rsp+0x50]
00007cc2697d907e  vmovaps xmm6, [rsp+0x60]
00007cc2697d9084  vmovaps xmm8, [rsp+0x70]
00007cc2697d908a  vmovaps xmm9, [rsp+0x80]
00007cc2697d9093  vmovaps xmm10, [rsp+0x90]
00007cc2697d909c  vmovaps xmm11, [rsp+0xA0]
00007cc2697d90a5  vmovaps xmm12, [rsp+0xB0]
00007cc2697d90ae  vmovaps xmm13, [rsp+0xC0]
00007cc2697d90b7  vmovaps xmm14, [rsp+0xD0]
00007cc2697d90c0  vmovaps xmm15, [rsp+0xE0]
00007cc2697d90c9  add rsp, 0xF0
00007cc2697d90d0  pop r11
00007cc2697d90d2  pop r10
00007cc2697d90d4  pop r9
00007cc2697d90d6  pop r8
00007cc2697d90d8  pop rsi
00007cc2697d90d9  pop rdi
00007cc2697d90da  pop rdx
00007cc2697d90db  pop rcx
00007cc2697d90dc  pop rax
00007cc2697d90dd  add rsp, 0x08
00007cc2697d90e1  jmp 0x00007CC2697D6B6D
00007cc2697d90e6  sub rsp, 0x08
00007cc2697d90ea  push rax
00007cc2697d90eb  push rcx
00007cc2697d90ec  push rdx
00007cc2697d90ed  push rdi
00007cc2697d90ee  push rsi
00007cc2697d90ef  push r8
00007cc2697d90f1  push r9
00007cc2697d90f3  push r10
00007cc2697d90f5  push r11
00007cc2697d90f7  sub rsp, 0xF0
00007cc2697d90fe  vmovaps [rsp], xmm0
00007cc2697d9103  vmovaps [rsp+0x10], xmm1
00007cc2697d9109  vmovaps [rsp+0x20], xmm2
00007cc2697d910f  vmovaps [rsp+0x30], xmm3
00007cc2697d9115  vmovaps [rsp+0x40], xmm4
00007cc2697d911b  vmovaps [rsp+0x50], xmm5
00007cc2697d9121  vmovaps [rsp+0x60], xmm6
00007cc2697d9127  vmovaps [rsp+0x70], xmm7
00007cc2697d912d  vmovaps [rsp+0x80], xmm8
00007cc2697d9136  vmovaps [rsp+0x90], xmm9
00007cc2697d913f  vmovaps [rsp+0xA0], xmm10
00007cc2697d9148  vmovaps [rsp+0xB0], xmm11
00007cc2697d9151  vmovaps [rsp+0xC0], xmm13
00007cc2697d915a  vmovaps [rsp+0xD0], xmm14
00007cc2697d9163  vmovaps [rsp+0xE0], xmm15
00007cc2697d916c  sub rsp, 0x40
00007cc2697d9170  lea rdi, [rsp]
00007cc2697d9174  lea rsi, [rsp+0x10]
00007cc2697d9179  lea rdx, [rsp+0x20]
00007cc2697d917e  lea rcx, [rsp+0x30]
00007cc2697d9183  mov r8d, 0x00
00007cc2697d9189  lea r9, [r15+0x3A8]
00007cc2697d9190  movaps [rdi], xmm12
00007cc2697d9194  movaps [rsi], xmm11
00007cc2697d9198  movaps [rdx], xmm15
00007cc2697d919c  movaps [rcx], xmm14
00007cc2697d91a0  mov rax, 0x653E5FFFBA50
00007cc2697d91aa  call rax
00007cc2697d91ac  movaps xmm12, [rsp]
00007cc2697d91b1  add rsp, 0x40
00007cc2697d91b5  vmovaps xmm0, [rsp]
00007cc2697d91ba  vmovaps xmm1, [rsp+0x10]
00007cc2697d91c0  vmovaps xmm2, [rsp+0x20]
00007cc2697d91c6  vmovaps xmm3, [rsp+0x30]
00007cc2697d91cc  vmovaps xmm4, [rsp+0x40]
00007cc2697d91d2  vmovaps xmm5, [rsp+0x50]
00007cc2697d91d8  vmovaps xmm6, [rsp+0x60]
00007cc2697d91de  vmovaps xmm7, [rsp+0x70]
00007cc2697d91e4  vmovaps xmm8, [rsp+0x80]
00007cc2697d91ed  vmovaps xmm9, [rsp+0x90]
00007cc2697d91f6  vmovaps xmm10, [rsp+0xA0]
00007cc2697d91ff  vmovaps xmm11, [rsp+0xB0]
00007cc2697d9208  vmovaps xmm13, [rsp+0xC0]
00007cc2697d9211  vmovaps xmm14, [rsp+0xD0]
00007cc2697d921a  vmovaps xmm15, [rsp+0xE0]
00007cc2697d9223  add rsp, 0xF0
00007cc2697d922a  pop r11
00007cc2697d922c  pop r10
00007cc2697d922e  pop r9
00007cc2697d9230  pop r8
00007cc2697d9232  pop rsi
00007cc2697d9233  pop rdi
00007cc2697d9234  pop rdx
00007cc2697d9235  pop rcx
00007cc2697d9236  pop rax
00007cc2697d9237  add rsp, 0x08
00007cc2697d923b  jmp 0x00007CC2697D6B96
00007cc2697d9240  sub rsp, 0x08
00007cc2697d9244  push rax
00007cc2697d9245  push rcx
00007cc2697d9246  push rdx
00007cc2697d9247  push rdi
00007cc2697d9248  push rsi
00007cc2697d9249  push r8
00007cc2697d924b  push r9
00007cc2697d924d  push r10
00007cc2697d924f  push r11
00007cc2697d9251  sub rsp, 0xF0
00007cc2697d9258  vmovaps [rsp], xmm0
00007cc2697d925d  vmovaps [rsp+0x10], xmm1
00007cc2697d9263  vmovaps [rsp+0x20], xmm2
00007cc2697d9269  vmovaps [rsp+0x30], xmm3
00007cc2697d926f  vmovaps [rsp+0x40], xmm4
00007cc2697d9275  vmovaps [rsp+0x50], xmm5
00007cc2697d927b  vmovaps [rsp+0x60], xmm6
00007cc2697d9281  vmovaps [rsp+0x70], xmm7
00007cc2697d9287  vmovaps [rsp+0x80], xmm8
00007cc2697d9290  vmovaps [rsp+0x90], xmm9
00007cc2697d9299  vmovaps [rsp+0xA0], xmm10
00007cc2697d92a2  vmovaps [rsp+0xB0], xmm12
00007cc2697d92ab  vmovaps [rsp+0xC0], xmm13
00007cc2697d92b4  vmovaps [rsp+0xD0], xmm14
00007cc2697d92bd  vmovaps [rsp+0xE0], xmm15
00007cc2697d92c6  sub rsp, 0x40
00007cc2697d92ca  lea rdi, [rsp]
00007cc2697d92ce  lea rsi, [rsp+0x10]
00007cc2697d92d3  lea rdx, [rsp+0x20]
00007cc2697d92d8  lea rcx, [rsp+0x30]
00007cc2697d92dd  mov r8d, 0x00
00007cc2697d92e3  lea r9, [r15+0x3A8]
00007cc2697d92ea  movaps [rdi], xmm11
00007cc2697d92ee  movaps [rsi], xmm10
00007cc2697d92f2  movaps [rdx], xmm13
00007cc2697d92f6  movaps [rcx], xmm15
00007cc2697d92fa  mov rax, 0x653E5FFFBA50
00007cc2697d9304  call rax
00007cc2697d9306  movaps xmm11, [rsp]
00007cc2697d930b  add rsp, 0x40
00007cc2697d930f  vmovaps xmm0, [rsp]
00007cc2697d9314  vmovaps xmm1, [rsp+0x10]
00007cc2697d931a  vmovaps xmm2, [rsp+0x20]
00007cc2697d9320  vmovaps xmm3, [rsp+0x30]
00007cc2697d9326  vmovaps xmm4, [rsp+0x40]
00007cc2697d932c  vmovaps xmm5, [rsp+0x50]
00007cc2697d9332  vmovaps xmm6, [rsp+0x60]
00007cc2697d9338  vmovaps xmm7, [rsp+0x70]
00007cc2697d933e  vmovaps xmm8, [rsp+0x80]
00007cc2697d9347  vmovaps xmm9, [rsp+0x90]
00007cc2697d9350  vmovaps xmm10, [rsp+0xA0]
00007cc2697d9359  vmovaps xmm12, [rsp+0xB0]
00007cc2697d9362  vmovaps xmm13, [rsp+0xC0]
00007cc2697d936b  vmovaps xmm14, [rsp+0xD0]
00007cc2697d9374  vmovaps xmm15, [rsp+0xE0]
00007cc2697d937d  add rsp, 0xF0
00007cc2697d9384  pop r11
00007cc2697d9386  pop r10
00007cc2697d9388  pop r9
00007cc2697d938a  pop r8
00007cc2697d938c  pop rsi
00007cc2697d938d  pop rdi
00007cc2697d938e  pop rdx
00007cc2697d938f  pop rcx
00007cc2697d9390  pop rax
00007cc2697d9391  add rsp, 0x08
00007cc2697d9395  jmp 0x00007CC2697D6BBF
00007cc2697d939a  call 0x00007CC2696E5820
00007cc2697d939f  jmp 0x00007CC2697D6BCC
00007cc2697d93a4  call 0x00007CC2696E45A0
00007cc2697d93a9  jmp 0x00007CC2697D6BD9
00007cc2697d93ae  sub rsp, 0x08
00007cc2697d93b2  push rax
00007cc2697d93b3  push rcx
00007cc2697d93b4  push rdx
00007cc2697d93b5  push rdi
00007cc2697d93b6  push rsi
00007cc2697d93b7  push r8
00007cc2697d93b9  push r9
00007cc2697d93bb  push r10
00007cc2697d93bd  push r11
00007cc2697d93bf  sub rsp, 0xF0
00007cc2697d93c6  vmovaps [rsp], xmm0
00007cc2697d93cb  vmovaps [rsp+0x10], xmm1
00007cc2697d93d1  vmovaps [rsp+0x20], xmm2
00007cc2697d93d7  vmovaps [rsp+0x30], xmm3
00007cc2697d93dd  vmovaps [rsp+0x40], xmm4
00007cc2697d93e3  vmovaps [rsp+0x50], xmm5
00007cc2697d93e9  vmovaps [rsp+0x60], xmm6
00007cc2697d93ef  vmovaps [rsp+0x70], xmm7
00007cc2697d93f5  vmovaps [rsp+0x80], xmm8
00007cc2697d93fe  vmovaps [rsp+0x90], xmm9
00007cc2697d9407  vmovaps [rsp+0xA0], xmm11
00007cc2697d9410  vmovaps [rsp+0xB0], xmm12
00007cc2697d9419  vmovaps [rsp+0xC0], xmm13
00007cc2697d9422  vmovaps [rsp+0xD0], xmm14
00007cc2697d942b  vmovaps [rsp+0xE0], xmm15
00007cc2697d9434  sub rsp, 0x40
00007cc2697d9438  lea rdi, [rsp]
00007cc2697d943c  lea rsi, [rsp+0x10]
00007cc2697d9441  lea rdx, [rsp+0x20]
00007cc2697d9446  lea rcx, [rsp+0x30]
00007cc2697d944b  mov r8d, 0x00
00007cc2697d9451  lea r9, [r15+0x3A8]
00007cc2697d9458  movaps [rdi], xmm10
00007cc2697d945c  movaps [rsi], xmm8
00007cc2697d9460  movaps [rdx], xmm1
00007cc2697d9463  movaps [rcx], xmm13
00007cc2697d9467  mov rax, 0x653E5FFFBA50
00007cc2697d9471  call rax
00007cc2697d9473  movaps xmm10, [rsp]
00007cc2697d9478  add rsp, 0x40
00007cc2697d947c  vmovaps xmm0, [rsp]
00007cc2697d9481  vmovaps xmm1, [rsp+0x10]
00007cc2697d9487  vmovaps xmm2, [rsp+0x20]
00007cc2697d948d  vmovaps xmm3, [rsp+0x30]
00007cc2697d9493  vmovaps xmm4, [rsp+0x40]
00007cc2697d9499  vmovaps xmm5, [rsp+0x50]
00007cc2697d949f  vmovaps xmm6, [rsp+0x60]
00007cc2697d94a5  vmovaps xmm7, [rsp+0x70]
00007cc2697d94ab  vmovaps xmm8, [rsp+0x80]
00007cc2697d94b4  vmovaps xmm9, [rsp+0x90]
00007cc2697d94bd  vmovaps xmm11, [rsp+0xA0]
00007cc2697d94c6  vmovaps xmm12, [rsp+0xB0]
00007cc2697d94cf  vmovaps xmm13, [rsp+0xC0]
00007cc2697d94d8  vmovaps xmm14, [rsp+0xD0]
00007cc2697d94e1  vmovaps xmm15, [rsp+0xE0]
00007cc2697d94ea  add rsp, 0xF0
00007cc2697d94f1  pop r11
00007cc2697d94f3  pop r10
00007cc2697d94f5  pop r9
00007cc2697d94f7  pop r8
00007cc2697d94f9  pop rsi
00007cc2697d94fa  pop rdi
00007cc2697d94fb  pop rdx
00007cc2697d94fc  pop rcx
00007cc2697d94fd  pop rax
00007cc2697d94fe  add rsp, 0x08
00007cc2697d9502  jmp 0x00007CC2697D6C0F
00007cc2697d9507  call 0x00007CC2696D64F0
00007cc2697d950c  jmp 0x00007CC2697D6C21
00007cc2697d9511  sub rsp, 0x08
00007cc2697d9515  push rax
00007cc2697d9516  push rcx
00007cc2697d9517  push rdx
00007cc2697d9518  push rdi
00007cc2697d9519  push rsi
00007cc2697d951a  push r8
00007cc2697d951c  push r9
00007cc2697d951e  push r10
00007cc2697d9520  push r11
00007cc2697d9522  sub rsp, 0xF0
00007cc2697d9529  vmovaps [rsp], xmm0
00007cc2697d952e  vmovaps [rsp+0x10], xmm1
00007cc2697d9534  vmovaps [rsp+0x20], xmm2
00007cc2697d953a  vmovaps [rsp+0x30], xmm3
00007cc2697d9540  vmovaps [rsp+0x40], xmm4
00007cc2697d9546  vmovaps [rsp+0x50], xmm5
00007cc2697d954c  vmovaps [rsp+0x60], xmm6
00007cc2697d9552  vmovaps [rsp+0x70], xmm7
00007cc2697d9558  vmovaps [rsp+0x80], xmm8
00007cc2697d9561  vmovaps [rsp+0x90], xmm10
00007cc2697d956a  vmovaps [rsp+0xA0], xmm11
00007cc2697d9573  vmovaps [rsp+0xB0], xmm12
00007cc2697d957c  vmovaps [rsp+0xC0], xmm13
00007cc2697d9585  vmovaps [rsp+0xD0], xmm14
00007cc2697d958e  vmovaps [rsp+0xE0], xmm15
00007cc2697d9597  sub rsp, 0x40
00007cc2697d959b  lea rdi, [rsp]
00007cc2697d959f  lea rsi, [rsp+0x10]
00007cc2697d95a4  lea rdx, [rsp+0x20]
00007cc2697d95a9  lea rcx, [rsp+0x30]
00007cc2697d95ae  mov r8d, 0x00
00007cc2697d95b4  lea r9, [r15+0x3A8]
00007cc2697d95bb  movaps [rdi], xmm9
00007cc2697d95bf  movaps [rsi], xmm7
00007cc2697d95c2  movaps [rdx], xmm14
00007cc2697d95c6  movaps [rcx], xmm13
00007cc2697d95ca  mov rax, 0x653E5FFFBA50
00007cc2697d95d4  call rax
00007cc2697d95d6  movaps xmm9, [rsp]
00007cc2697d95db  add rsp, 0x40
00007cc2697d95df  vmovaps xmm0, [rsp]
00007cc2697d95e4  vmovaps xmm1, [rsp+0x10]
00007cc2697d95ea  vmovaps xmm2, [rsp+0x20]
00007cc2697d95f0  vmovaps xmm3, [rsp+0x30]
00007cc2697d95f6  vmovaps xmm4, [rsp+0x40]
00007cc2697d95fc  vmovaps xmm5, [rsp+0x50]
00007cc2697d9602  vmovaps xmm6, [rsp+0x60]
00007cc2697d9608  vmovaps xmm7, [rsp+0x70]
00007cc2697d960e  vmovaps xmm8, [rsp+0x80]
00007cc2697d9617  vmovaps xmm10, [rsp+0x90]
00007cc2697d9620  vmovaps xmm11, [rsp+0xA0]
00007cc2697d9629  vmovaps xmm12, [rsp+0xB0]
00007cc2697d9632  vmovaps xmm13, [rsp+0xC0]
00007cc2697d963b  vmovaps xmm14, [rsp+0xD0]
00007cc2697d9644  vmovaps xmm15, [rsp+0xE0]
00007cc2697d964d  add rsp, 0xF0
00007cc2697d9654  pop r11
00007cc2697d9656  pop r10
00007cc2697d9658  pop r9
00007cc2697d965a  pop r8
00007cc2697d965c  pop rsi
00007cc2697d965d  pop rdi
00007cc2697d965e  pop rdx
00007cc2697d965f  pop rcx
00007cc2697d9660  pop rax
00007cc2697d9661  add rsp, 0x08
00007cc2697d9665  jmp 0x00007CC2697D6C4F
00007cc2697d966a  sub rsp, 0x08
00007cc2697d966e  push rax
00007cc2697d966f  push rcx
00007cc2697d9670  push rdx
00007cc2697d9671  push rdi
00007cc2697d9672  push rsi
00007cc2697d9673  push r8
00007cc2697d9675  push r9
00007cc2697d9677  push r10
00007cc2697d9679  push r11
00007cc2697d967b  sub rsp, 0xF0
00007cc2697d9682  vmovaps [rsp], xmm0
00007cc2697d9687  vmovaps [rsp+0x10], xmm1
00007cc2697d968d  vmovaps [rsp+0x20], xmm2
00007cc2697d9693  vmovaps [rsp+0x30], xmm3
00007cc2697d9699  vmovaps [rsp+0x40], xmm4
00007cc2697d969f  vmovaps [rsp+0x50], xmm5
00007cc2697d96a5  vmovaps [rsp+0x60], xmm6
00007cc2697d96ab  vmovaps [rsp+0x70], xmm7
00007cc2697d96b1  vmovaps [rsp+0x80], xmm8
00007cc2697d96ba  vmovaps [rsp+0x90], xmm9
00007cc2697d96c3  vmovaps [rsp+0xA0], xmm10
00007cc2697d96cc  vmovaps [rsp+0xB0], xmm11
00007cc2697d96d5  vmovaps [rsp+0xC0], xmm12
00007cc2697d96de  vmovaps [rsp+0xD0], xmm14
00007cc2697d96e7  vmovaps [rsp+0xE0], xmm15
00007cc2697d96f0  sub rsp, 0x40
00007cc2697d96f4  lea rdi, [rsp]
00007cc2697d96f8  lea rsi, [rsp+0x10]
00007cc2697d96fd  lea rdx, [rsp+0x20]
00007cc2697d9702  lea rcx, [rsp+0x30]
00007cc2697d9707  mov r8d, 0x00
00007cc2697d970d  lea r9, [r15+0x3A8]
00007cc2697d9714  movaps [rdi], xmm13
00007cc2697d9718  movaps [rsi], xmm12
00007cc2697d971c  movaps [rdx], xmm15
00007cc2697d9720  movaps [rcx], xmm14
00007cc2697d9724  mov rax, 0x653E5FFFBA50
00007cc2697d972e  call rax
00007cc2697d9730  movaps xmm13, [rsp]
00007cc2697d9735  add rsp, 0x40
00007cc2697d9739  vmovaps xmm0, [rsp]
00007cc2697d973e  vmovaps xmm1, [rsp+0x10]
00007cc2697d9744  vmovaps xmm2, [rsp+0x20]
00007cc2697d974a  vmovaps xmm3, [rsp+0x30]
00007cc2697d9750  vmovaps xmm4, [rsp+0x40]
00007cc2697d9756  vmovaps xmm5, [rsp+0x50]
00007cc2697d975c  vmovaps xmm6, [rsp+0x60]
00007cc2697d9762  vmovaps xmm7, [rsp+0x70]
00007cc2697d9768  vmovaps xmm8, [rsp+0x80]
00007cc2697d9771  vmovaps xmm9, [rsp+0x90]
00007cc2697d977a  vmovaps xmm10, [rsp+0xA0]
00007cc2697d9783  vmovaps xmm11, [rsp+0xB0]
00007cc2697d978c  vmovaps xmm12, [rsp+0xC0]
00007cc2697d9795  vmovaps xmm14, [rsp+0xD0]
00007cc2697d979e  vmovaps xmm15, [rsp+0xE0]
00007cc2697d97a7  add rsp, 0xF0
00007cc2697d97ae  pop r11
00007cc2697d97b0  pop r10
00007cc2697d97b2  pop r9
00007cc2697d97b4  pop r8
00007cc2697d97b6  pop rsi
00007cc2697d97b7  pop rdi
00007cc2697d97b8  pop rdx
00007cc2697d97b9  pop rcx
00007cc2697d97ba  pop rax
00007cc2697d97bb  add rsp, 0x08
00007cc2697d97bf  jmp 0x00007CC2697D6C7D
00007cc2697d97c4  sub rsp, 0x08
00007cc2697d97c8  push rax
00007cc2697d97c9  push rcx
00007cc2697d97ca  push rdx
00007cc2697d97cb  push rdi
00007cc2697d97cc  push rsi
00007cc2697d97cd  push r8
00007cc2697d97cf  push r9
00007cc2697d97d1  push r10
00007cc2697d97d3  push r11
00007cc2697d97d5  sub rsp, 0xF0
00007cc2697d97dc  vmovaps [rsp], xmm0
00007cc2697d97e1  vmovaps [rsp+0x10], xmm1
00007cc2697d97e7  vmovaps [rsp+0x20], xmm2
00007cc2697d97ed  vmovaps [rsp+0x30], xmm3
00007cc2697d97f3  vmovaps [rsp+0x40], xmm4
00007cc2697d97f9  vmovaps [rsp+0x50], xmm5
00007cc2697d97ff  vmovaps [rsp+0x60], xmm6
00007cc2697d9805  vmovaps [rsp+0x70], xmm7
00007cc2697d980b  vmovaps [rsp+0x80], xmm8
00007cc2697d9814  vmovaps [rsp+0x90], xmm9
00007cc2697d981d  vmovaps [rsp+0xA0], xmm10
00007cc2697d9826  vmovaps [rsp+0xB0], xmm11
00007cc2697d982f  vmovaps [rsp+0xC0], xmm12
00007cc2697d9838  vmovaps [rsp+0xD0], xmm13
00007cc2697d9841  vmovaps [rsp+0xE0], xmm15
00007cc2697d984a  sub rsp, 0x40
00007cc2697d984e  lea rdi, [rsp]
00007cc2697d9852  lea rsi, [rsp+0x10]
00007cc2697d9857  lea rdx, [rsp+0x20]
00007cc2697d985c  lea rcx, [rsp+0x30]
00007cc2697d9861  mov r8d, 0x00
00007cc2697d9867  lea r9, [r15+0x3A8]
00007cc2697d986e  movaps [rdi], xmm14
00007cc2697d9872  movaps [rsi], xmm11
00007cc2697d9876  movaps [rdx], xmm1
00007cc2697d9879  movaps [rcx], xmm15
00007cc2697d987d  mov rax, 0x653E5FFFBA50
00007cc2697d9887  call rax
00007cc2697d9889  movaps xmm14, [rsp]
00007cc2697d988e  add rsp, 0x40
00007cc2697d9892  vmovaps xmm0, [rsp]
00007cc2697d9897  vmovaps xmm1, [rsp+0x10]
00007cc2697d989d  vmovaps xmm2, [rsp+0x20]
00007cc2697d98a3  vmovaps xmm3, [rsp+0x30]
00007cc2697d98a9  vmovaps xmm4, [rsp+0x40]
00007cc2697d98af  vmovaps xmm5, [rsp+0x50]
00007cc2697d98b5  vmovaps xmm6, [rsp+0x60]
00007cc2697d98bb  vmovaps xmm7, [rsp+0x70]
00007cc2697d98c1  vmovaps xmm8, [rsp+0x80]
00007cc2697d98ca  vmovaps xmm9, [rsp+0x90]
00007cc2697d98d3  vmovaps xmm10, [rsp+0xA0]
00007cc2697d98dc  vmovaps xmm11, [rsp+0xB0]
00007cc2697d98e5  vmovaps xmm12, [rsp+0xC0]
00007cc2697d98ee  vmovaps xmm13, [rsp+0xD0]
00007cc2697d98f7  vmovaps xmm15, [rsp+0xE0]
00007cc2697d9900  add rsp, 0xF0
00007cc2697d9907  pop r11
00007cc2697d9909  pop r10
00007cc2697d990b  pop r9
00007cc2697d990d  pop r8
00007cc2697d990f  pop rsi
00007cc2697d9910  pop rdi
00007cc2697d9911  pop rdx
00007cc2697d9912  pop rcx
00007cc2697d9913  pop rax
00007cc2697d9914  add rsp, 0x08
00007cc2697d9918  jmp 0x00007CC2697D6CAB
00007cc2697d991d  call 0x00007CC2696ACF70
00007cc2697d9922  jmp 0x00007CC2697D6CB9
00007cc2697d9927  call 0x00007CC26960C380
00007cc2697d992c  jmp 0x00007CC2697D6CC3
00007cc2697d9931  call 0x00007CC269608C20
00007cc2697d9936  jmp 0x00007CC2697D6CCD
00007cc2697d993b  call 0x00007CC26960D600
00007cc2697d9940  jmp 0x00007CC2697D6CD7
00007cc2697d9945  int3
00007cc2697d9946  nop [rax+rax*1], ax
00007cc2697d994f  nop
00007cc2697d9950  mov eax, [r15+0x48]
00007cc2697d9954  lea r14d, [eax+0x01]
00007cc2697d9959  mov [rsp+0x10], r14d
00007cc2697d995e  mov r14d, r14d
00007cc2697d9961  mov [r15+0x48], r14
00007cc2697d9965  xor eax, eax
00007cc2697d9967  mov r14d, [rsp+0x10]
00007cc2697d996c  cmp r14d, 0x1F4
00007cc2697d9973  cmc
00007cc2697d9974  lahf
00007cc2697d9975  seto al
00007cc2697d9978  mov [r15+0x108], eax
00007cc2697d997f  mov eax, [r15+0x108]
00007cc2697d9986  sahf
00007cc2697d9987  jnz 0x00007CC2697D99B9
00007cc2697d9989  cmp dword ptr [r15+0x318], 0x00
00007cc2697d9991  jz 0x00007CC2697DD2E0
00007cc2697d9997  nop [rax+rax*1], ax
00007cc2697d99a0  nop [rax+rax*1], eax
00007cc2697d99a8  mov eax, 0x410670
00007cc2697d99ad  mov [r15+0x100], rax
00007cc2697d99b4  jmp 0x00007CC2695FE110
00007cc2697d99b9  cmp dword ptr [r15+0x318], 0x00
00007cc2697d99c1  jz 0x00007CC2697D99F0
00007cc2697d99c7  nop [rax+rax*1], ax
00007cc2697d99d0  nop [rax+rax*1], eax
00007cc2697d99d8  mov eax, 0x4104EC
00007cc2697d99dd  mov [r15+0x100], rax
00007cc2697d99e4  jmp 0x00007CC2695FE110
00007cc2697d99e9  int3
00007cc2697d99ea  int3
00007cc2697d99eb  nop [rax+rax*1], eax
00007cc2697d99f0  mov rax, [r15+0x40]
00007cc2697d99f4  vxorps xmm1, xmm1, xmm1
00007cc2697d99f8  vpbroadcastq xmm1, xmm1
00007cc2697d99fd  vxorps xmm15, xmm15, xmm15
00007cc2697d9a02  vpbroadcastq xmm15, xmm15
00007cc2697d9a07  lea r14, [rax+0x30]
00007cc2697d9a0b  mov r12, [r13+r14*1]
00007cc2697d9a10  lea r14, [rax+0x38]
00007cc2697d9a14  mov r11, [r13+r14*1]
00007cc2697d9a19  movq xmm14, r12
00007cc2697d9a1e  movq xmm13, r11
00007cc2697d9a23  movq xmm14, xmm14
00007cc2697d9a28  movq xmm13, xmm13
00007cc2697d9a2d  vmovaps [rsp+0x10], xmm13
00007cc2697d9a33  movq xmm13, xmm13
00007cc2697d9a38  movaps [r15+0x270], xmm13
00007cc2697d9a40  movaps xmm13, [r15+0x160]
00007cc2697d9a48  vmovaps [rsp+0x20], xmm13
00007cc2697d9a4e  vmovaps xmm12, [rsp+0x20]
00007cc2697d9a54  por xmm13, xmm12
00007cc2697d9a59  lea r14, [rax+0x20]
00007cc2697d9a5d  mov r12, [r13+r14*1]
00007cc2697d9a62  lea r14, [rax+0x28]
00007cc2697d9a66  mov r11, [r13+r14*1]
00007cc2697d9a6b  movq xmm12, r12
00007cc2697d9a70  movq xmm11, r11
00007cc2697d9a75  movq xmm12, xmm12
00007cc2697d9a7a  movq xmm11, xmm11
00007cc2697d9a7f  movaps xmm10, [r15+0x2D0]
00007cc2697d9a87  vmovaps [rsp+0x20], xmm10
00007cc2697d9a8d  vmovaps xmm9, [rsp+0x20]
00007cc2697d9a93  por xmm10, xmm9
00007cc2697d9a98  movaps xmm9, [r15+0x300]
00007cc2697d9aa0  vmovaps [rsp+0x20], xmm9
00007cc2697d9aa6  vmovaps xmm8, [rsp+0x20]
00007cc2697d9aac  por xmm9, xmm8
00007cc2697d9ab1  movaps xmm8, [r15+0x2B0]
00007cc2697d9ab9  vmovaps [rsp+0x20], xmm8
00007cc2697d9abf  vmovaps xmm7, [rsp+0x20]
00007cc2697d9ac5  por xmm8, xmm7
00007cc2697d9aca  movaps xmm7, [r15+0x180]
00007cc2697d9ad2  vmovaps [rsp+0x20], xmm7
00007cc2697d9ad8  vmovaps xmm6, [rsp+0x20]
00007cc2697d9ade  por xmm7, xmm6
00007cc2697d9ae2  lea r14, [rax+0x10]
00007cc2697d9ae6  mov r12, [r13+r14*1]
00007cc2697d9aeb  lea r14, [rax+0x18]
00007cc2697d9aef  mov r11, [r13+r14*1]
00007cc2697d9af4  movq xmm6, r12
00007cc2697d9af9  movq xmm5, r11
00007cc2697d9afe  movq xmm6, xmm6
00007cc2697d9b02  movq xmm5, xmm5
00007cc2697d9b06  movaps xmm4, [r15+0x200]
00007cc2697d9b0e  vmovaps [rsp+0x20], xmm4
00007cc2697d9b14  vmovaps xmm3, [rsp+0x20]
00007cc2697d9b1a  por xmm4, xmm3
00007cc2697d9b1e  movaps xmm3, [r15+0x1F0]
00007cc2697d9b26  vmovaps [rsp+0x20], xmm3
00007cc2697d9b2c  vmovaps xmm2, [rsp+0x20]
00007cc2697d9b32  por xmm3, xmm2
00007cc2697d9b36  movaps xmm2, [r15+0x2E0]
00007cc2697d9b3e  vmovaps [rsp+0x20], xmm2
00007cc2697d9b44  vmovaps [rsp+0x30], xmm1
00007cc2697d9b4a  vmovaps xmm1, [rsp+0x20]
00007cc2697d9b50  por xmm2, xmm1
00007cc2697d9b54  movaps xmm1, [r15+0x2A0]
00007cc2697d9b5c  vmovaps [rsp+0x20], xmm1
00007cc2697d9b62  vmovaps [rsp+0x40], xmm15
00007cc2697d9b68  vmovaps xmm15, [rsp+0x20]
00007cc2697d9b6e  por xmm1, xmm15
00007cc2697d9b73  movaps xmm15, [r15+0x280]
00007cc2697d9b7b  vmovaps [rsp+0x20], xmm15
00007cc2697d9b81  vmovaps [rsp+0x50], xmm1
00007cc2697d9b87  vmovaps xmm1, [rsp+0x20]
00007cc2697d9b8d  por xmm15, xmm1
00007cc2697d9b92  movaps xmm1, [r15+0x1C0]
00007cc2697d9b9a  vmovaps [rsp+0x20], xmm1
00007cc2697d9ba0  vmovaps [rsp+0x60], xmm15
00007cc2697d9ba6  vmovaps xmm15, [rsp+0x20]
00007cc2697d9bac  por xmm1, xmm15
00007cc2697d9bb1  movaps xmm15, [r15+0x210]
00007cc2697d9bb9  vmovaps [rsp+0x20], xmm15
00007cc2697d9bbf  vmovaps [rsp+0x70], xmm1
00007cc2697d9bc5  vmovaps xmm1, [rsp+0x20]
00007cc2697d9bcb  por xmm15, xmm1
00007cc2697d9bd0  mov r14, [r13+rax*1]
00007cc2697d9bd5  vmovq xmm1, r14
00007cc2697d9bda  vpbroadcastq xmm1, xmm1
00007cc2697d9bdf  vmovaps [rsp+0x20], xmm1
00007cc2697d9be5  vxorps xmm1, xmm1, xmm1
00007cc2697d9be9  vpbroadcastq xmm1, xmm1
00007cc2697d9bee  mov r14, [r15+0xF8]
00007cc2697d9bf5  vmovaps [rsp+0x80], xmm1
00007cc2697d9bfe  movups xmm1, [r13+r14*1]
00007cc2697d9c04  vmovaps [rsp+0x90], xmm1
00007cc2697d9c0d  vxorps xmm1, xmm1, xmm1
00007cc2697d9c11  vpbroadcastq xmm1, xmm1
00007cc2697d9c16  lea r12, [rax+0x08]
00007cc2697d9c1a  mov rax, [r13+r12*1]
00007cc2697d9c1f  vmovaps [rsp+0xA0], xmm1
00007cc2697d9c28  movq xmm1, rax
00007cc2697d9c2d  movaps [r15+0x240], xmm1
00007cc2697d9c35  mov rax, [r15+0x50]
00007cc2697d9c39  mov [r15+0x60], rax
00007cc2697d9c3d  mov qword ptr [r15+0x58], 0x40
00007cc2697d9c45  vmovaps xmm1, [rsp+0x30]
00007cc2697d9c4b  vmovaps [rsp+0x30], xmm15
00007cc2697d9c51  vmovaps xmm15, [rsp+0x90]
00007cc2697d9c5a  vmovaps [rsp+0x90], xmm14
00007cc2697d9c63  vmovaps xmm14, [rsp+0x20]
00007cc2697d9c69  vmovaps [rsp+0x20], xmm13
00007cc2697d9c6f  vmovaps [rsp+0xB0], xmm12
00007cc2697d9c78  movaps xmm13, xmm1
00007cc2697d9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d9c87  vptest xmm12, xmm12
00007cc2697d9c8c  jnz 0x00007CC2697DA72F
00007cc2697d9c92  movaps xmm1, [r15+0x250]
00007cc2697d9c9a  vmovaps xmm15, [rsp+0x40]
00007cc2697d9ca0  vmovaps [rsp+0x40], xmm13
00007cc2697d9ca6  movaps xmm12, xmm15
00007cc2697d9caa  vfmadd231pd xmm12, xmm1, xmm14
00007cc2697d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007cc2697d9cb5  vptest xmm13, xmm13
00007cc2697d9cba  jnz 0x00007CC2697DA888
00007cc2697d9cc0  movaps xmm15, [r15+0x1E0]
00007cc2697d9cc8  vmovaps [rsp+0xC0], xmm15
00007cc2697d9cd1  vmovaps xmm13, [rsp+0xC0]
00007cc2697d9cda  por xmm15, xmm13
00007cc2697d9cdf  movaps xmm13, [r15+0x1D0]
00007cc2697d9ce7  vmovaps [rsp+0xC0], xmm13
00007cc2697d9cf0  vmovaps [rsp+0xD0], xmm1
00007cc2697d9cf9  vmovaps xmm1, [rsp+0xC0]
00007cc2697d9d02  por xmm13, xmm1
00007cc2697d9d07  movaps xmm1, [r15+0x2C0]
00007cc2697d9d0f  vmovaps [rsp+0xC0], xmm1
00007cc2697d9d18  vmovaps [rsp+0xE0], xmm15
00007cc2697d9d21  vmovaps xmm15, [rsp+0xC0]
00007cc2697d9d2a  por xmm1, xmm15
00007cc2697d9d2f  movaps xmm15, [r15+0x290]
00007cc2697d9d37  vmovaps [rsp+0xC0], xmm15
00007cc2697d9d40  vmovaps [rsp+0xF0], xmm1
00007cc2697d9d49  vmovaps xmm1, [rsp+0xC0]
00007cc2697d9d52  por xmm15, xmm1
00007cc2697d9d57  movaps xmm1, [r15+0x260]
00007cc2697d9d5f  vmovaps [rsp+0xC0], xmm1
00007cc2697d9d68  vmovaps [rsp+0x100], xmm15
00007cc2697d9d71  vmovaps xmm15, [rsp+0xC0]
00007cc2697d9d7a  por xmm1, xmm15
00007cc2697d9d7f  vmovaps xmm15, [rsp+0xD0]
00007cc2697d9d88  vmovaps [rsp+0xC0], xmm1
00007cc2697d9d91  vmovaps xmm1, [rsp+0xD0]
00007cc2697d9d9a  por xmm15, xmm1
00007cc2697d9d9f  lea r12, [r14+0xC0]
00007cc2697d9da6  movups xmm1, [r13+r12*1]
00007cc2697d9dac  mov [rsp+0xD0], rax
00007cc2697d9db4  xor eax, eax
00007cc2697d9db6  mov r12d, 0x40
00007cc2697d9dbc  mov r11d, 0x200
00007cc2697d9dc2  cmp r12, r11
00007cc2697d9dc5  cmc
00007cc2697d9dc6  lahf
00007cc2697d9dc7  seto al
00007cc2697d9dca  mov [r15+0x108], eax
00007cc2697d9dd1  vmovaps [rsp+0x110], xmm1
00007cc2697d9dda  vmovaps xmm1, [rsp+0x80]
00007cc2697d9de3  vmovaps [rsp+0x80], xmm15
00007cc2697d9dec  vmovaps xmm15, [rsp+0x110]
00007cc2697d9df5  vmovaps [rsp+0x110], xmm13
00007cc2697d9dfe  vmovaps [rsp+0x120], xmm12
00007cc2697d9e07  movaps xmm13, xmm1
00007cc2697d9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d9e16  vptest xmm12, xmm12
00007cc2697d9e1b  jnz 0x00007CC2697DA9EB
00007cc2697d9e21  lea rax, [r14+0xB0]
00007cc2697d9e28  movups xmm1, [r13+rax*1]
00007cc2697d9e2e  vmovaps xmm15, [rsp+0xA0]
00007cc2697d9e37  vmovaps [rsp+0xA0], xmm13
00007cc2697d9e40  movaps xmm12, xmm15
00007cc2697d9e44  vfmadd231pd xmm12, xmm1, xmm14
00007cc2697d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007cc2697d9e4f  vptest xmm13, xmm13
00007cc2697d9e54  jnz 0x00007CC2697DAB4E
00007cc2697d9e5a  vmovaps xmm1, [rsp+0x30]
00007cc2697d9e60  vmovaps xmm15, [rsp+0x30]
00007cc2697d9e66  por xmm1, xmm15
00007cc2697d9e6b  movaps [r15+0x210], xmm1
00007cc2697d9e73  vmovaps xmm15, [rsp+0x70]
00007cc2697d9e79  vmovaps xmm14, [rsp+0x70]
00007cc2697d9e7f  por xmm15, xmm14
00007cc2697d9e84  movaps [r15+0x1C0], xmm15
00007cc2697d9e8c  vmovaps xmm14, [rsp+0x60]
00007cc2697d9e92  vmovaps xmm13, [rsp+0x60]
00007cc2697d9e98  por xmm14, xmm13
00007cc2697d9e9d  movaps [r15+0x280], xmm14
00007cc2697d9ea5  vmovaps xmm13, [rsp+0x50]
00007cc2697d9eab  vmovaps [rsp+0x30], xmm1
00007cc2697d9eb1  vmovaps xmm1, [rsp+0x50]
00007cc2697d9eb7  por xmm13, xmm1
00007cc2697d9ebc  movaps [r15+0x2A0], xmm13
00007cc2697d9ec4  vmovaps [rsp+0x50], xmm2
00007cc2697d9eca  vmovaps xmm1, [rsp+0x50]
00007cc2697d9ed0  por xmm2, xmm1
00007cc2697d9ed4  movaps [r15+0x2E0], xmm2
00007cc2697d9edc  vmovaps [rsp+0x50], xmm3
00007cc2697d9ee2  vmovaps xmm1, [rsp+0x50]
00007cc2697d9ee8  por xmm3, xmm1
00007cc2697d9eec  movaps [r15+0x1F0], xmm3
00007cc2697d9ef4  vmovaps xmm1, [rsp+0x80]
00007cc2697d9efd  vmovaps [rsp+0x50], xmm15
00007cc2697d9f03  vmovaps xmm15, [rsp+0x80]
00007cc2697d9f0c  por xmm1, xmm15
00007cc2697d9f11  movaps [r15+0x250], xmm1
00007cc2697d9f19  vmovaps xmm1, [rsp+0xC0]
00007cc2697d9f22  vmovaps xmm15, [rsp+0xC0]
00007cc2697d9f2b  por xmm1, xmm15
00007cc2697d9f30  movaps [r15+0x260], xmm1
00007cc2697d9f38  vmovaps xmm15, [rsp+0x100]
00007cc2697d9f41  vmovaps [rsp+0x60], xmm1
00007cc2697d9f47  vmovaps xmm1, [rsp+0x100]
00007cc2697d9f50  por xmm15, xmm1
00007cc2697d9f55  movaps [r15+0x290], xmm15
00007cc2697d9f5d  vmovaps xmm1, [rsp+0xF0]
00007cc2697d9f66  vmovaps [rsp+0x70], xmm15
00007cc2697d9f6c  vmovaps xmm15, [rsp+0xF0]
00007cc2697d9f75  por xmm1, xmm15
00007cc2697d9f7a  movaps [r15+0x2C0], xmm1
00007cc2697d9f82  movq xmm15, qword ptr [r15+0x240]
00007cc2697d9f8b  vmovaps [rsp+0x80], xmm15
00007cc2697d9f94  vpermilpd xmm15, xmm15, 0x00
00007cc2697d9f9a  vmovaps [rsp+0xC0], xmm1
00007cc2697d9fa3  vmovaps xmm1, [rsp+0x40]
00007cc2697d9fa9  vmovaps [rsp+0x40], xmm15
00007cc2697d9faf  vmovaps xmm15, [rsp+0x30]
00007cc2697d9fb5  vmovaps [rsp+0x30], xmm14
00007cc2697d9fbb  vmovaps xmm14, [rsp+0x40]
00007cc2697d9fc1  vmovaps [rsp+0x40], xmm13
00007cc2697d9fc7  vmovaps [rsp+0xF0], xmm12
00007cc2697d9fd0  movaps xmm13, xmm1
00007cc2697d9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2697d9fdf  vptest xmm12, xmm12
00007cc2697d9fe4  jnz 0x00007CC2697DACA7
00007cc2697d9fea  vmovaps xmm1, [rsp+0x80]
00007cc2697d9ff3  vpermilpd xmm1, xmm1, 0x00
00007cc2697d9ff9  vmovaps xmm15, [rsp+0xA0]
00007cc2697da002  movaps xmm14, xmm15
00007cc2697da006  vfmadd231pd xmm14, xmm2, xmm1
00007cc2697da00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007cc2697da011  vptest xmm12, xmm12
00007cc2697da016  jnz 0x00007CC2697DAE00
00007cc2697da01c  vmovaps xmm1, [rsp+0x80]
00007cc2697da025  vpermilpd xmm1, xmm1, 0x00
00007cc2697da02b  vmovaps xmm15, [rsp+0x120]
00007cc2697da034  vmovaps xmm12, [rsp+0x50]
00007cc2697da03a  vmovaps [rsp+0x50], xmm14
00007cc2697da040  movaps xmm2, xmm15
00007cc2697da044  vfmadd231pd xmm2, xmm12, xmm1
00007cc2697da049  vcmppd xmm14, xmm2, xmm2, 0x03
00007cc2697da04e  vptest xmm14, xmm14
00007cc2697da053  jnz 0x00007CC2697DAF58
00007cc2697da059  vmovaps xmm1, [rsp+0x110]
00007cc2697da062  vmovaps xmm15, [rsp+0x110]
00007cc2697da06b  por xmm1, xmm15
00007cc2697da070  movaps [r15+0x1D0], xmm1
00007cc2697da078  vmovaps xmm15, [rsp+0x80]
00007cc2697da081  vpermilpd xmm15, xmm15, 0x00
00007cc2697da087  vmovaps xmm14, [rsp+0xF0]
00007cc2697da090  vmovaps [rsp+0x80], xmm1
00007cc2697da099  movaps xmm12, xmm14
00007cc2697da09d  vfmadd231pd xmm12, xmm3, xmm15
00007cc2697da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007cc2697da0a8  vptest xmm1, xmm1
00007cc2697da0ad  jnz 0x00007CC2697DB0AF
00007cc2697da0b3  vmovaps [rsp+0xA0], xmm4
00007cc2697da0bc  vmovaps xmm1, [rsp+0xA0]
00007cc2697da0c5  por xmm4, xmm1
00007cc2697da0c9  movaps [r15+0x200], xmm4
00007cc2697da0d1  vmovaps xmm1, [rsp+0xE0]
00007cc2697da0da  vmovaps xmm15, [rsp+0xE0]
00007cc2697da0e3  por xmm1, xmm15
00007cc2697da0e8  movaps [r15+0x1E0], xmm1
00007cc2697da0f0  vmovaps [rsp+0xA0], xmm8
00007cc2697da0f9  vmovaps xmm1, [rsp+0xA0]
00007cc2697da102  por xmm8, xmm1
00007cc2697da107  movaps [r15+0x2B0], xmm8
00007cc2697da10f  vmovaps [rsp+0xA0], xmm9
00007cc2697da118  vmovaps xmm1, [rsp+0xA0]
00007cc2697da121  por xmm9, xmm1
00007cc2697da126  movaps [r15+0x300], xmm9
00007cc2697da12e  vmovaps [rsp+0xA0], xmm6
00007cc2697da137  vpermilpd xmm6, xmm6, 0x00
00007cc2697da13d  vmovaps xmm14, [rsp+0x60]
00007cc2697da143  movaps xmm9, xmm13
00007cc2697da147  vfmadd231pd xmm9, xmm14, xmm6
00007cc2697da14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007cc2697da152  vptest xmm3, xmm3
00007cc2697da157  jnz 0x00007CC2697DB208
00007cc2697da15d  vmovaps xmm14, [rsp+0xA0]
00007cc2697da166  vpermilpd xmm14, xmm14, 0x00
00007cc2697da16c  vmovaps xmm13, [rsp+0x50]
00007cc2697da172  vmovaps xmm6, [rsp+0xC0]
00007cc2697da17b  vmovaps [rsp+0x50], xmm1
00007cc2697da181  movaps xmm3, xmm13
00007cc2697da185  vfmadd231pd xmm3, xmm6, xmm14
00007cc2697da18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007cc2697da18f  vptest xmm1, xmm1
00007cc2697da194  jnz 0x00007CC2697DB361
00007cc2697da19a  vmovaps xmm1, [rsp+0xA0]
00007cc2697da1a3  vpermilpd xmm1, xmm1, 0x00
00007cc2697da1a9  vmovaps xmm14, [rsp+0x30]
00007cc2697da1af  movaps xmm6, xmm2
00007cc2697da1b2  vfmadd231pd xmm6, xmm14, xmm1
00007cc2697da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007cc2697da1bc  vptest xmm13, xmm13
00007cc2697da1c1  jnz 0x00007CC2697DB4B8
00007cc2697da1c7  vmovaps xmm1, [rsp+0xA0]
00007cc2697da1d0  vpermilpd xmm1, xmm1, 0x00
00007cc2697da1d6  vmovaps xmm14, [rsp+0x80]
00007cc2697da1df  movaps xmm13, xmm12
00007cc2697da1e3  vfmadd231pd xmm13, xmm14, xmm1
00007cc2697da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007cc2697da1ee  vptest xmm2, xmm2
00007cc2697da1f3  jnz 0x00007CC2697DB60E
00007cc2697da1f9  vmovaps [rsp+0x30], xmm7
00007cc2697da1ff  vmovaps xmm1, [rsp+0x30]
00007cc2697da205  por xmm7, xmm1
00007cc2697da209  movaps [r15+0x180], xmm7
00007cc2697da211  vmovaps [rsp+0x30], xmm10
00007cc2697da217  vmovaps xmm1, [rsp+0x30]
00007cc2697da21d  por xmm10, xmm1
00007cc2697da222  movaps [r15+0x2D0], xmm10
00007cc2697da22a  vmovaps [rsp+0x30], xmm5
00007cc2697da230  vpermilpd xmm5, xmm5, 0x00
00007cc2697da236  vmovaps xmm14, [rsp+0x50]
00007cc2697da23c  movaps xmm12, xmm3
00007cc2697da240  vfmadd231pd xmm12, xmm14, xmm5
00007cc2697da245  vcmppd xmm10, xmm12, xmm12, 0x03
00007cc2697da24b  vptest xmm10, xmm10
00007cc2697da250  jnz 0x00007CC2697DB767
00007cc2697da256  vmovaps xmm14, [rsp+0x30]
00007cc2697da25c  vpermilpd xmm14, xmm14, 0x00
00007cc2697da262  movaps xmm10, xmm9
00007cc2697da266  vfmadd231pd xmm10, xmm7, xmm14
00007cc2697da26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007cc2697da271  vptest xmm5, xmm5
00007cc2697da276  jnz 0x00007CC2697DB8BF
00007cc2697da27c  lea rax, [r14+0x80]
00007cc2697da283  movups xmm14, [r13+rax*1]
00007cc2697da289  movaps [r15+0x2F0], xmm14
00007cc2697da291  vmovaps xmm9, [rsp+0x30]
00007cc2697da297  vpermilpd xmm9, xmm9, 0x00
00007cc2697da29d  vmovaps xmm7, [rsp+0x70]
00007cc2697da2a3  movaps xmm5, xmm6
00007cc2697da2a6  vfmadd231pd xmm5, xmm7, xmm9
00007cc2697da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007cc2697da2b0  vptest xmm3, xmm3
00007cc2697da2b5  jnz 0x00007CC2697DBA22
00007cc2697da2bb  vmovaps xmm9, [rsp+0x30]
00007cc2697da2c1  vpermilpd xmm9, xmm9, 0x00
00007cc2697da2c7  movaps xmm7, xmm13
00007cc2697da2cb  vfmadd231pd xmm7, xmm1, xmm9
00007cc2697da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2697da2d5  vptest xmm6, xmm6
00007cc2697da2da  jnz 0x00007CC2697DBB78
00007cc2697da2e0  vmovaps xmm1, [rsp+0x20]
00007cc2697da2e6  vmovaps xmm13, [rsp+0x20]
00007cc2697da2ec  por xmm1, xmm13
00007cc2697da2f1  movaps [r15+0x160], xmm1
00007cc2697da2f9  lea rax, [r14+0x40]
00007cc2697da2fd  movups xmm13, [r13+rax*1]
00007cc2697da303  lea rax, [r14+0x50]
00007cc2697da307  movups xmm9, [r13+rax*1]
00007cc2697da30d  movaps [r15+0x1B0], xmm13
00007cc2697da315  movaps [r15+0x1A0], xmm9
00007cc2697da31d  movaps xmm6, [r15+0x190]
00007cc2697da325  vmovaps xmm3, [rsp+0xB0]
00007cc2697da32e  vpermilpd xmm3, xmm3, 0x00
00007cc2697da334  vmovaps [rsp+0x20], xmm1
00007cc2697da33a  movaps xmm2, xmm12
00007cc2697da33e  vfmadd231pd xmm2, xmm6, xmm3
00007cc2697da343  vcmppd xmm1, xmm2, xmm2, 0x03
00007cc2697da348  vptest xmm1, xmm1
00007cc2697da34d  jnz 0x00007CC2697DBCE3
00007cc2697da353  vmovaps xmm1, [rsp+0xB0]
00007cc2697da35c  vpermilpd xmm1, xmm1, 0x00
00007cc2697da362  vmovaps xmm12, [rsp+0x20]
00007cc2697da368  movaps xmm6, xmm10
00007cc2697da36c  vfmadd231pd xmm6, xmm12, xmm1
00007cc2697da371  vcmppd xmm3, xmm6, xmm6, 0x03
00007cc2697da376  vptest xmm3, xmm3
00007cc2697da37b  jnz 0x00007CC2697DBE39
00007cc2697da381  vmovaps xmm1, [rsp+0xB0]
00007cc2697da38a  vpermilpd xmm1, xmm1, 0x00
00007cc2697da390  vmovaps xmm12, [rsp+0x40]
00007cc2697da396  movaps xmm10, xmm5
00007cc2697da39a  vfmadd231pd xmm10, xmm12, xmm1
00007cc2697da39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007cc2697da3a5  vptest xmm3, xmm3
00007cc2697da3aa  jnz 0x00007CC2697DBF90
00007cc2697da3b0  vmovaps xmm1, [rsp+0xB0]
00007cc2697da3b9  vpermilpd xmm1, xmm1, 0x00
00007cc2697da3bf  movaps xmm12, xmm7
00007cc2697da3c3  vfmadd231pd xmm12, xmm15, xmm1
00007cc2697da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007cc2697da3ce  vptest xmm5, xmm5
00007cc2697da3d3  jnz 0x00007CC2697DC0E8
00007cc2697da3d9  lea rax, [r14+0x60]
00007cc2697da3dd  movups xmm1, [r13+rax*1]
00007cc2697da3e3  lea rax, [r14+0x70]
00007cc2697da3e7  movups xmm15, [r13+rax*1]
00007cc2697da3ed  movaps [r15+0x150], xmm1
00007cc2697da3f5  movaps [r15+0x120], xmm15
00007cc2697da3fd  vmovaps [rsp+0x20], xmm11
00007cc2697da403  vpermilpd xmm11, xmm11, 0x00
00007cc2697da409  movaps xmm7, xmm2
00007cc2697da40c  vfmadd231pd xmm7, xmm9, xmm11
00007cc2697da411  vcmppd xmm5, xmm7, xmm7, 0x03
00007cc2697da416  vptest xmm5, xmm5
00007cc2697da41b  jnz 0x00007CC2697DC254
00007cc2697da421  vmovaps xmm11, [rsp+0x20]
00007cc2697da427  vpermilpd xmm11, xmm11, 0x00
00007cc2697da42d  movaps xmm9, xmm6
00007cc2697da431  vfmadd231pd xmm9, xmm1, xmm11
00007cc2697da436  vcmppd xmm5, xmm9, xmm9, 0x03
00007cc2697da43c  vptest xmm5, xmm5
00007cc2697da441  jnz 0x00007CC2697DC3AB
00007cc2697da447  vmovaps xmm1, [rsp+0x20]
00007cc2697da44d  vpermilpd xmm1, xmm1, 0x00
00007cc2697da453  movaps xmm11, xmm10
00007cc2697da457  vfmadd231pd xmm11, xmm8, xmm1
00007cc2697da45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007cc2697da462  vptest xmm6, xmm6
00007cc2697da467  jnz 0x00007CC2697DC503
00007cc2697da46d  vmovaps xmm1, [rsp+0x20]
00007cc2697da473  vpermilpd xmm1, xmm1, 0x00
00007cc2697da479  movaps xmm10, xmm12
00007cc2697da47d  vfmadd231pd xmm10, xmm13, xmm1
00007cc2697da482  vcmppd xmm8, xmm10, xmm10, 0x03
00007cc2697da488  vptest xmm8, xmm8
00007cc2697da48d  jnz 0x00007CC2697DC65C
00007cc2697da493  lea rax, [r14+0x20]
00007cc2697da497  movups xmm1, [r13+rax*1]
00007cc2697da49d  lea rax, [r14+0x30]
00007cc2697da4a1  movups xmm13, [r13+rax*1]
00007cc2697da4a7  vmovaps xmm12, [rsp+0x90]
00007cc2697da4b0  vpermilpd xmm12, xmm12, 0x00
00007cc2697da4b6  movaps xmm8, xmm7
00007cc2697da4ba  vfmadd231pd xmm8, xmm4, xmm12
00007cc2697da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007cc2697da4c5  vptest xmm6, xmm6
00007cc2697da4ca  jnz 0x00007CC2697DC7C9
00007cc2697da4d0  vmovaps xmm12, [rsp+0x90]
00007cc2697da4d9  vpermilpd xmm12, xmm12, 0x00
00007cc2697da4df  movaps xmm7, xmm9
00007cc2697da4e3  vfmadd231pd xmm7, xmm14, xmm12
00007cc2697da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2697da4ed  vptest xmm6, xmm6
00007cc2697da4f2  jnz 0x00007CC2697DC921
00007cc2697da4f8  vmovaps xmm14, [rsp+0x90]
00007cc2697da501  vpermilpd xmm14, xmm14, 0x00
00007cc2697da507  movaps xmm12, xmm11
00007cc2697da50b  vfmadd231pd xmm12, xmm15, xmm14
00007cc2697da510  vcmppd xmm9, xmm12, xmm12, 0x03
00007cc2697da516  vptest xmm9, xmm9
00007cc2697da51b  jnz 0x00007CC2697DCA79
00007cc2697da521  vmovaps xmm15, [rsp+0x90]
00007cc2697da52a  vpermilpd xmm15, xmm15, 0x00
00007cc2697da530  movaps xmm11, xmm10
00007cc2697da534  vfmadd231pd xmm11, xmm13, xmm15
00007cc2697da539  vcmppd xmm14, xmm11, xmm11, 0x03
00007cc2697da53f  vptest xmm14, xmm14
00007cc2697da544  jnz 0x00007CC2697DCBD3
00007cc2697da54a  lea rax, [r14+0x90]
00007cc2697da551  movups xmm15, [r13+rax*1]
00007cc2697da557  lea rax, [r14+0xA0]
00007cc2697da55e  movups xmm14, [r13+rax*1]
00007cc2697da564  movaps [r15+0x140], xmm15
00007cc2697da56c  movaps [r15+0x130], xmm14
00007cc2697da574  vmovaps xmm13, [rsp+0x10]
00007cc2697da57a  vpermilpd xmm13, xmm13, 0x00
00007cc2697da580  movaps xmm10, xmm8
00007cc2697da584  vfmadd231pd xmm10, xmm1, xmm13
00007cc2697da589  vcmppd xmm9, xmm10, xmm10, 0x03
00007cc2697da58f  vptest xmm9, xmm9
00007cc2697da594  jnz 0x00007CC2697DCD41
00007cc2697da59a  movaps [r15+0x220], xmm10
00007cc2697da5a2  lea rax, [r14+0x10]
00007cc2697da5a6  movups xmm1, [r13+rax*1]
00007cc2697da5ac  movaps [r15+0x240], xmm1
00007cc2697da5b4  vmovaps xmm13, [rsp+0x10]
00007cc2697da5ba  vpermilpd xmm13, xmm13, 0x00
00007cc2697da5c0  movaps xmm9, xmm7
00007cc2697da5c4  vfmadd231pd xmm9, xmm14, xmm13
00007cc2697da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007cc2697da5cf  vptest xmm8, xmm8
00007cc2697da5d4  jnz 0x00007CC2697DCEA4
00007cc2697da5da  movaps [r15+0x110], xmm9
00007cc2697da5e2  vmovaps xmm14, [rsp+0x10]
00007cc2697da5e8  vpermilpd xmm14, xmm14, 0x00
00007cc2697da5ee  movaps xmm13, xmm12
00007cc2697da5f2  vfmadd231pd xmm13, xmm15, xmm14
00007cc2697da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007cc2697da5fd  vptest xmm8, xmm8
00007cc2697da602  jnz 0x00007CC2697DCFFD
00007cc2697da608  movaps [r15+0x170], xmm13
00007cc2697da610  vmovaps xmm15, [rsp+0x10]
00007cc2697da616  vpermilpd xmm15, xmm15, 0x00
00007cc2697da61c  movaps xmm14, xmm11
00007cc2697da620  vfmadd231pd xmm14, xmm1, xmm15
00007cc2697da625  vcmppd xmm12, xmm14, xmm14, 0x03
00007cc2697da62b  vptest xmm12, xmm12
00007cc2697da630  jnz 0x00007CC2697DD157
00007cc2697da636  movaps [r15+0x230], xmm14
00007cc2697da63e  mov rax, [rsp+0xD0]
00007cc2697da646  movups [r13+rax*1], xmm9
00007cc2697da64c  lea r14, [rax+0x10]
00007cc2697da650  movups [r13+r14*1], xmm13
00007cc2697da656  lea r14, [rax+0x20]
00007cc2697da65a  movups [r13+r14*1], xmm10
00007cc2697da660  lea r14, [rax+0x30]
00007cc2697da664  movups [r13+r14*1], xmm14
00007cc2697da66a  mov eax, [r15+0x108]
00007cc2697da671  sahf
00007cc2697da672  jnz 0x00007CC2697DA6A4
00007cc2697da674  cmp dword ptr [r15+0x318], 0x00
00007cc2697da67c  jz 0x00007CC2697D9950
00007cc2697da682  nop [rax+rax*1], ax
00007cc2697da68b  nop [rax+rax*1], eax
00007cc2697da693  mov eax, 0x410664
00007cc2697da698  mov [r15+0x100], rax
00007cc2697da69f  jmp 0x00007CC2695FE110
00007cc2697da6a4  cmp dword ptr [r15+0x318], 0x00
00007cc2697da6ac  jz 0x00007CC2697D6050
00007cc2697da6b2  nop [rax+rax*1], ax
00007cc2697da6bb  nop [rax+rax*1], eax
00007cc2697da6c3  mov eax, 0x4104F0
00007cc2697da6c8  mov [r15+0x100], rax
00007cc2697da6cf  jmp 0x00007CC2695FE110
00007cc2697da6d4  int3
00007cc2697da6d5  call 0x00007CC2696E27E0
00007cc2697da6da  jmp 0x00007CC2697D9A10
00007cc2697da6df  call 0x00007CC2696E1570
00007cc2697da6e4  jmp 0x00007CC2697D9A19
00007cc2697da6e9  call 0x00007CC2696E27E0
00007cc2697da6ee  jmp 0x00007CC2697D9A62
00007cc2697da6f3  call 0x00007CC2696E1570
00007cc2697da6f8  jmp 0x00007CC2697D9A6B
00007cc2697da6fd  call 0x00007CC2696E27E0
00007cc2697da702  jmp 0x00007CC2697D9AEB
00007cc2697da707  call 0x00007CC2696E1570
00007cc2697da70c  jmp 0x00007CC2697D9AF4
00007cc2697da711  call 0x00007CC26960DC20
00007cc2697da716  jmp 0x00007CC2697D9BD5
00007cc2697da71b  call 0x00007CC2696D64F0
00007cc2697da720  jmp 0x00007CC2697D9C04
00007cc2697da725  call 0x00007CC2696B47C0
00007cc2697da72a  jmp 0x00007CC2697D9C1F
00007cc2697da72f  sub rsp, 0x08
00007cc2697da733  push rax
00007cc2697da734  push rcx
00007cc2697da735  push rdx
00007cc2697da736  push rdi
00007cc2697da737  push rsi
00007cc2697da738  push r8
00007cc2697da73a  push r9
00007cc2697da73c  push r10
00007cc2697da73e  push r11
00007cc2697da740  sub rsp, 0xF0
00007cc2697da747  vmovaps [rsp], xmm0
00007cc2697da74c  vmovaps [rsp+0x10], xmm1
00007cc2697da752  vmovaps [rsp+0x20], xmm2
00007cc2697da758  vmovaps [rsp+0x30], xmm3
00007cc2697da75e  vmovaps [rsp+0x40], xmm4
00007cc2697da764  vmovaps [rsp+0x50], xmm5
00007cc2697da76a  vmovaps [rsp+0x60], xmm6
00007cc2697da770  vmovaps [rsp+0x70], xmm7
00007cc2697da776  vmovaps [rsp+0x80], xmm8
00007cc2697da77f  vmovaps [rsp+0x90], xmm9
00007cc2697da788  vmovaps [rsp+0xA0], xmm10
00007cc2697da791  vmovaps [rsp+0xB0], xmm11
00007cc2697da79a  vmovaps [rsp+0xC0], xmm12
00007cc2697da7a3  vmovaps [rsp+0xD0], xmm14
00007cc2697da7ac  vmovaps [rsp+0xE0], xmm15
00007cc2697da7b5  sub rsp, 0x40
00007cc2697da7b9  lea rdi, [rsp]
00007cc2697da7bd  lea rsi, [rsp+0x10]
00007cc2697da7c2  lea rdx, [rsp+0x20]
00007cc2697da7c7  lea rcx, [rsp+0x30]
00007cc2697da7cc  mov r8d, 0x00
00007cc2697da7d2  lea r9, [r15+0x3A8]
00007cc2697da7d9  movaps [rdi], xmm13
00007cc2697da7dd  movaps [rsi], xmm1
00007cc2697da7e0  movaps [rdx], xmm15
00007cc2697da7e4  movaps [rcx], xmm14
00007cc2697da7e8  mov rax, 0x653E5FFFBA50
00007cc2697da7f2  call rax
00007cc2697da7f4  movaps xmm13, [rsp]
00007cc2697da7f9  add rsp, 0x40
00007cc2697da7fd  vmovaps xmm0, [rsp]
00007cc2697da802  vmovaps xmm1, [rsp+0x10]
00007cc2697da808  vmovaps xmm2, [rsp+0x20]
00007cc2697da80e  vmovaps xmm3, [rsp+0x30]
00007cc2697da814  vmovaps xmm4, [rsp+0x40]
00007cc2697da81a  vmovaps xmm5, [rsp+0x50]
00007cc2697da820  vmovaps xmm6, [rsp+0x60]
00007cc2697da826  vmovaps xmm7, [rsp+0x70]
00007cc2697da82c  vmovaps xmm8, [rsp+0x80]
00007cc2697da835  vmovaps xmm9, [rsp+0x90]
00007cc2697da83e  vmovaps xmm10, [rsp+0xA0]
00007cc2697da847  vmovaps xmm11, [rsp+0xB0]
00007cc2697da850  vmovaps xmm12, [rsp+0xC0]
00007cc2697da859  vmovaps xmm14, [rsp+0xD0]
00007cc2697da862  vmovaps xmm15, [rsp+0xE0]
00007cc2697da86b  add rsp, 0xF0
00007cc2697da872  pop r11
00007cc2697da874  pop r10
00007cc2697da876  pop r9
00007cc2697da878  pop r8
00007cc2697da87a  pop rsi
00007cc2697da87b  pop rdi
00007cc2697da87c  pop rdx
00007cc2697da87d  pop rcx
00007cc2697da87e  pop rax
00007cc2697da87f  add rsp, 0x08
00007cc2697da883  jmp 0x00007CC2697D9C92
00007cc2697da888  sub rsp, 0x08
00007cc2697da88c  push rax
00007cc2697da88d  push rcx
00007cc2697da88e  push rdx
00007cc2697da88f  push rdi
00007cc2697da890  push rsi
00007cc2697da891  push r8
00007cc2697da893  push r9
00007cc2697da895  push r10
00007cc2697da897  push r11
00007cc2697da899  sub rsp, 0xF0
00007cc2697da8a0  vmovaps [rsp], xmm0
00007cc2697da8a5  vmovaps [rsp+0x10], xmm1
00007cc2697da8ab  vmovaps [rsp+0x20], xmm2
00007cc2697da8b1  vmovaps [rsp+0x30], xmm3
00007cc2697da8b7  vmovaps [rsp+0x40], xmm4
00007cc2697da8bd  vmovaps [rsp+0x50], xmm5
00007cc2697da8c3  vmovaps [rsp+0x60], xmm6
00007cc2697da8c9  vmovaps [rsp+0x70], xmm7
00007cc2697da8cf  vmovaps [rsp+0x80], xmm8
00007cc2697da8d8  vmovaps [rsp+0x90], xmm9
00007cc2697da8e1  vmovaps [rsp+0xA0], xmm10
00007cc2697da8ea  vmovaps [rsp+0xB0], xmm11
00007cc2697da8f3  vmovaps [rsp+0xC0], xmm13
00007cc2697da8fc  vmovaps [rsp+0xD0], xmm14
00007cc2697da905  vmovaps [rsp+0xE0], xmm15
00007cc2697da90e  sub rsp, 0x40
00007cc2697da912  lea rdi, [rsp]
00007cc2697da916  lea rsi, [rsp+0x10]
00007cc2697da91b  lea rdx, [rsp+0x20]
00007cc2697da920  lea rcx, [rsp+0x30]
00007cc2697da925  mov r8d, 0x00
00007cc2697da92b  lea r9, [r15+0x3A8]
00007cc2697da932  movaps [rdi], xmm12
00007cc2697da936  movaps [rsi], xmm15
00007cc2697da93a  movaps [rdx], xmm1
00007cc2697da93d  movaps [rcx], xmm14
00007cc2697da941  mov rax, 0x653E5FFFBA50
00007cc2697da94b  call rax
00007cc2697da94d  movaps xmm12, [rsp]
00007cc2697da952  add rsp, 0x40
00007cc2697da956  vmovaps xmm0, [rsp]
00007cc2697da95b  vmovaps xmm1, [rsp+0x10]
00007cc2697da961  vmovaps xmm2, [rsp+0x20]
00007cc2697da967  vmovaps xmm3, [rsp+0x30]
00007cc2697da96d  vmovaps xmm4, [rsp+0x40]
00007cc2697da973  vmovaps xmm5, [rsp+0x50]
00007cc2697da979  vmovaps xmm6, [rsp+0x60]
00007cc2697da97f  vmovaps xmm7, [rsp+0x70]
00007cc2697da985  vmovaps xmm8, [rsp+0x80]
00007cc2697da98e  vmovaps xmm9, [rsp+0x90]
00007cc2697da997  vmovaps xmm10, [rsp+0xA0]
00007cc2697da9a0  vmovaps xmm11, [rsp+0xB0]
00007cc2697da9a9  vmovaps xmm13, [rsp+0xC0]
00007cc2697da9b2  vmovaps xmm14, [rsp+0xD0]
00007cc2697da9bb  vmovaps xmm15, [rsp+0xE0]
00007cc2697da9c4  add rsp, 0xF0
00007cc2697da9cb  pop r11
00007cc2697da9cd  pop r10
00007cc2697da9cf  pop r9
00007cc2697da9d1  pop r8
00007cc2697da9d3  pop rsi
00007cc2697da9d4  pop rdi
00007cc2697da9d5  pop rdx
00007cc2697da9d6  pop rcx
00007cc2697da9d7  pop rax
00007cc2697da9d8  add rsp, 0x08
00007cc2697da9dc  jmp 0x00007CC2697D9CC0
00007cc2697da9e1  call 0x00007CC2696B52F0
00007cc2697da9e6  jmp 0x00007CC2697D9DAC
00007cc2697da9eb  sub rsp, 0x08
00007cc2697da9ef  push rax
00007cc2697da9f0  push rcx
00007cc2697da9f1  push rdx
00007cc2697da9f2  push rdi
00007cc2697da9f3  push rsi
00007cc2697da9f4  push r8
00007cc2697da9f6  push r9
00007cc2697da9f8  push r10
00007cc2697da9fa  push r11
00007cc2697da9fc  sub rsp, 0xF0
00007cc2697daa03  vmovaps [rsp], xmm0
00007cc2697daa08  vmovaps [rsp+0x10], xmm1
00007cc2697daa0e  vmovaps [rsp+0x20], xmm2
00007cc2697daa14  vmovaps [rsp+0x30], xmm3
00007cc2697daa1a  vmovaps [rsp+0x40], xmm4
00007cc2697daa20  vmovaps [rsp+0x50], xmm5
00007cc2697daa26  vmovaps [rsp+0x60], xmm6
00007cc2697daa2c  vmovaps [rsp+0x70], xmm7
00007cc2697daa32  vmovaps [rsp+0x80], xmm8
00007cc2697daa3b  vmovaps [rsp+0x90], xmm9
00007cc2697daa44  vmovaps [rsp+0xA0], xmm10
00007cc2697daa4d  vmovaps [rsp+0xB0], xmm11
00007cc2697daa56  vmovaps [rsp+0xC0], xmm12
00007cc2697daa5f  vmovaps [rsp+0xD0], xmm14
00007cc2697daa68  vmovaps [rsp+0xE0], xmm15
00007cc2697daa71  sub rsp, 0x40
00007cc2697daa75  lea rdi, [rsp]
00007cc2697daa79  lea rsi, [rsp+0x10]
00007cc2697daa7e  lea rdx, [rsp+0x20]
00007cc2697daa83  lea rcx, [rsp+0x30]
00007cc2697daa88  mov r8d, 0x00
00007cc2697daa8e  lea r9, [r15+0x3A8]
00007cc2697daa95  movaps [rdi], xmm13
00007cc2697daa99  movaps [rsi], xmm1
00007cc2697daa9c  movaps [rdx], xmm15
00007cc2697daaa0  movaps [rcx], xmm14
00007cc2697daaa4  mov rax, 0x653E5FFFBA50
00007cc2697daaae  call rax
00007cc2697daab0  movaps xmm13, [rsp]
00007cc2697daab5  add rsp, 0x40
00007cc2697daab9  vmovaps xmm0, [rsp]
00007cc2697daabe  vmovaps xmm1, [rsp+0x10]
00007cc2697daac4  vmovaps xmm2, [rsp+0x20]
00007cc2697daaca  vmovaps xmm3, [rsp+0x30]
00007cc2697daad0  vmovaps xmm4, [rsp+0x40]
00007cc2697daad6  vmovaps xmm5, [rsp+0x50]
00007cc2697daadc  vmovaps xmm6, [rsp+0x60]
00007cc2697daae2  vmovaps xmm7, [rsp+0x70]
00007cc2697daae8  vmovaps xmm8, [rsp+0x80]
00007cc2697daaf1  vmovaps xmm9, [rsp+0x90]
00007cc2697daafa  vmovaps xmm10, [rsp+0xA0]
00007cc2697dab03  vmovaps xmm11, [rsp+0xB0]
00007cc2697dab0c  vmovaps xmm12, [rsp+0xC0]
00007cc2697dab15  vmovaps xmm14, [rsp+0xD0]
00007cc2697dab1e  vmovaps xmm15, [rsp+0xE0]
00007cc2697dab27  add rsp, 0xF0
00007cc2697dab2e  pop r11
00007cc2697dab30  pop r10
00007cc2697dab32  pop r9
00007cc2697dab34  pop r8
00007cc2697dab36  pop rsi
00007cc2697dab37  pop rdi
00007cc2697dab38  pop rdx
00007cc2697dab39  pop rcx
00007cc2697dab3a  pop rax
00007cc2697dab3b  add rsp, 0x08
00007cc2697dab3f  jmp 0x00007CC2697D9E21
00007cc2697dab44  call 0x00007CC2695FF430
00007cc2697dab49  jmp 0x00007CC2697D9E2E
00007cc2697dab4e  sub rsp, 0x08
00007cc2697dab52  push rax
00007cc2697dab53  push rcx
00007cc2697dab54  push rdx
00007cc2697dab55  push rdi
00007cc2697dab56  push rsi
00007cc2697dab57  push r8
00007cc2697dab59  push r9
00007cc2697dab5b  push r10
00007cc2697dab5d  push r11
00007cc2697dab5f  sub rsp, 0xF0
00007cc2697dab66  vmovaps [rsp], xmm0
00007cc2697dab6b  vmovaps [rsp+0x10], xmm1
00007cc2697dab71  vmovaps [rsp+0x20], xmm2
00007cc2697dab77  vmovaps [rsp+0x30], xmm3
00007cc2697dab7d  vmovaps [rsp+0x40], xmm4
00007cc2697dab83  vmovaps [rsp+0x50], xmm5
00007cc2697dab89  vmovaps [rsp+0x60], xmm6
00007cc2697dab8f  vmovaps [rsp+0x70], xmm7
00007cc2697dab95  vmovaps [rsp+0x80], xmm8
00007cc2697dab9e  vmovaps [rsp+0x90], xmm9
00007cc2697daba7  vmovaps [rsp+0xA0], xmm10
00007cc2697dabb0  vmovaps [rsp+0xB0], xmm11
00007cc2697dabb9  vmovaps [rsp+0xC0], xmm13
00007cc2697dabc2  vmovaps [rsp+0xD0], xmm14
00007cc2697dabcb  vmovaps [rsp+0xE0], xmm15
00007cc2697dabd4  sub rsp, 0x40
00007cc2697dabd8  lea rdi, [rsp]
00007cc2697dabdc  lea rsi, [rsp+0x10]
00007cc2697dabe1  lea rdx, [rsp+0x20]
00007cc2697dabe6  lea rcx, [rsp+0x30]
00007cc2697dabeb  mov r8d, 0x00
00007cc2697dabf1  lea r9, [r15+0x3A8]
00007cc2697dabf8  movaps [rdi], xmm12
00007cc2697dabfc  movaps [rsi], xmm15
00007cc2697dac00  movaps [rdx], xmm1
00007cc2697dac03  movaps [rcx], xmm14
00007cc2697dac07  mov rax, 0x653E5FFFBA50
00007cc2697dac11  call rax
00007cc2697dac13  movaps xmm12, [rsp]
00007cc2697dac18  add rsp, 0x40
00007cc2697dac1c  vmovaps xmm0, [rsp]
00007cc2697dac21  vmovaps xmm1, [rsp+0x10]
00007cc2697dac27  vmovaps xmm2, [rsp+0x20]
00007cc2697dac2d  vmovaps xmm3, [rsp+0x30]
00007cc2697dac33  vmovaps xmm4, [rsp+0x40]
00007cc2697dac39  vmovaps xmm5, [rsp+0x50]
00007cc2697dac3f  vmovaps xmm6, [rsp+0x60]
00007cc2697dac45  vmovaps xmm7, [rsp+0x70]
00007cc2697dac4b  vmovaps xmm8, [rsp+0x80]
00007cc2697dac54  vmovaps xmm9, [rsp+0x90]
00007cc2697dac5d  vmovaps xmm10, [rsp+0xA0]
00007cc2697dac66  vmovaps xmm11, [rsp+0xB0]
00007cc2697dac6f  vmovaps xmm13, [rsp+0xC0]
00007cc2697dac78  vmovaps xmm14, [rsp+0xD0]
00007cc2697dac81  vmovaps xmm15, [rsp+0xE0]
00007cc2697dac8a  add rsp, 0xF0
00007cc2697dac91  pop r11
00007cc2697dac93  pop r10
00007cc2697dac95  pop r9
00007cc2697dac97  pop r8
00007cc2697dac99  pop rsi
00007cc2697dac9a  pop rdi
00007cc2697dac9b  pop rdx
00007cc2697dac9c  pop rcx
00007cc2697dac9d  pop rax
00007cc2697dac9e  add rsp, 0x08
00007cc2697daca2  jmp 0x00007CC2697D9E5A
00007cc2697daca7  sub rsp, 0x08
00007cc2697dacab  push rax
00007cc2697dacac  push rcx
00007cc2697dacad  push rdx
00007cc2697dacae  push rdi
00007cc2697dacaf  push rsi
00007cc2697dacb0  push r8
00007cc2697dacb2  push r9
00007cc2697dacb4  push r10
00007cc2697dacb6  push r11
00007cc2697dacb8  sub rsp, 0xF0
00007cc2697dacbf  vmovaps [rsp], xmm0
00007cc2697dacc4  vmovaps [rsp+0x10], xmm1
00007cc2697dacca  vmovaps [rsp+0x20], xmm2
00007cc2697dacd0  vmovaps [rsp+0x30], xmm3
00007cc2697dacd6  vmovaps [rsp+0x40], xmm4
00007cc2697dacdc  vmovaps [rsp+0x50], xmm5
00007cc2697dace2  vmovaps [rsp+0x60], xmm6
00007cc2697dace8  vmovaps [rsp+0x70], xmm7
00007cc2697dacee  vmovaps [rsp+0x80], xmm8
00007cc2697dacf7  vmovaps [rsp+0x90], xmm9
00007cc2697dad00  vmovaps [rsp+0xA0], xmm10
00007cc2697dad09  vmovaps [rsp+0xB0], xmm11
00007cc2697dad12  vmovaps [rsp+0xC0], xmm12
00007cc2697dad1b  vmovaps [rsp+0xD0], xmm14
00007cc2697dad24  vmovaps [rsp+0xE0], xmm15
00007cc2697dad2d  sub rsp, 0x40
00007cc2697dad31  lea rdi, [rsp]
00007cc2697dad35  lea rsi, [rsp+0x10]
00007cc2697dad3a  lea rdx, [rsp+0x20]
00007cc2697dad3f  lea rcx, [rsp+0x30]
00007cc2697dad44  mov r8d, 0x00
00007cc2697dad4a  lea r9, [r15+0x3A8]
00007cc2697dad51  movaps [rdi], xmm13
00007cc2697dad55  movaps [rsi], xmm1
00007cc2697dad58  movaps [rdx], xmm15
00007cc2697dad5c  movaps [rcx], xmm14
00007cc2697dad60  mov rax, 0x653E5FFFBA50
00007cc2697dad6a  call rax
00007cc2697dad6c  movaps xmm13, [rsp]
00007cc2697dad71  add rsp, 0x40
00007cc2697dad75  vmovaps xmm0, [rsp]
00007cc2697dad7a  vmovaps xmm1, [rsp+0x10]
00007cc2697dad80  vmovaps xmm2, [rsp+0x20]
00007cc2697dad86  vmovaps xmm3, [rsp+0x30]
00007cc2697dad8c  vmovaps xmm4, [rsp+0x40]
00007cc2697dad92  vmovaps xmm5, [rsp+0x50]
00007cc2697dad98  vmovaps xmm6, [rsp+0x60]
00007cc2697dad9e  vmovaps xmm7, [rsp+0x70]
00007cc2697dada4  vmovaps xmm8, [rsp+0x80]
00007cc2697dadad  vmovaps xmm9, [rsp+0x90]
00007cc2697dadb6  vmovaps xmm10, [rsp+0xA0]
00007cc2697dadbf  vmovaps xmm11, [rsp+0xB0]
00007cc2697dadc8  vmovaps xmm12, [rsp+0xC0]
00007cc2697dadd1  vmovaps xmm14, [rsp+0xD0]
00007cc2697dadda  vmovaps xmm15, [rsp+0xE0]
00007cc2697dade3  add rsp, 0xF0
00007cc2697dadea  pop r11
00007cc2697dadec  pop r10
00007cc2697dadee  pop r9
00007cc2697dadf0  pop r8
00007cc2697dadf2  pop rsi
00007cc2697dadf3  pop rdi
00007cc2697dadf4  pop rdx
00007cc2697dadf5  pop rcx
00007cc2697dadf6  pop rax
00007cc2697dadf7  add rsp, 0x08
00007cc2697dadfb  jmp 0x00007CC2697D9FEA
00007cc2697dae00  sub rsp, 0x08
00007cc2697dae04  push rax
00007cc2697dae05  push rcx
00007cc2697dae06  push rdx
00007cc2697dae07  push rdi
00007cc2697dae08  push rsi
00007cc2697dae09  push r8
00007cc2697dae0b  push r9
00007cc2697dae0d  push r10
00007cc2697dae0f  push r11
00007cc2697dae11  sub rsp, 0xF0
00007cc2697dae18  vmovaps [rsp], xmm0
00007cc2697dae1d  vmovaps [rsp+0x10], xmm1
00007cc2697dae23  vmovaps [rsp+0x20], xmm2
00007cc2697dae29  vmovaps [rsp+0x30], xmm3
00007cc2697dae2f  vmovaps [rsp+0x40], xmm4
00007cc2697dae35  vmovaps [rsp+0x50], xmm5
00007cc2697dae3b  vmovaps [rsp+0x60], xmm6
00007cc2697dae41  vmovaps [rsp+0x70], xmm7
00007cc2697dae47  vmovaps [rsp+0x80], xmm8
00007cc2697dae50  vmovaps [rsp+0x90], xmm9
00007cc2697dae59  vmovaps [rsp+0xA0], xmm10
00007cc2697dae62  vmovaps [rsp+0xB0], xmm11
00007cc2697dae6b  vmovaps [rsp+0xC0], xmm12
00007cc2697dae74  vmovaps [rsp+0xD0], xmm13
00007cc2697dae7d  vmovaps [rsp+0xE0], xmm15
00007cc2697dae86  sub rsp, 0x40
00007cc2697dae8a  lea rdi, [rsp]
00007cc2697dae8e  lea rsi, [rsp+0x10]
00007cc2697dae93  lea rdx, [rsp+0x20]
00007cc2697dae98  lea rcx, [rsp+0x30]
00007cc2697dae9d  mov r8d, 0x00
00007cc2697daea3  lea r9, [r15+0x3A8]
00007cc2697daeaa  movaps [rdi], xmm14
00007cc2697daeae  movaps [rsi], xmm15
00007cc2697daeb2  movaps [rdx], xmm2
00007cc2697daeb5  movaps [rcx], xmm1
00007cc2697daeb8  mov rax, 0x653E5FFFBA50
00007cc2697daec2  call rax
00007cc2697daec4  movaps xmm14, [rsp]
00007cc2697daec9  add rsp, 0x40
00007cc2697daecd  vmovaps xmm0, [rsp]
00007cc2697daed2  vmovaps xmm1, [rsp+0x10]
00007cc2697daed8  vmovaps xmm2, [rsp+0x20]
00007cc2697daede  vmovaps xmm3, [rsp+0x30]
00007cc2697daee4  vmovaps xmm4, [rsp+0x40]
00007cc2697daeea  vmovaps xmm5, [rsp+0x50]
00007cc2697daef0  vmovaps xmm6, [rsp+0x60]
00007cc2697daef6  vmovaps xmm7, [rsp+0x70]
00007cc2697daefc  vmovaps xmm8, [rsp+0x80]
00007cc2697daf05  vmovaps xmm9, [rsp+0x90]
00007cc2697daf0e  vmovaps xmm10, [rsp+0xA0]
00007cc2697daf17  vmovaps xmm11, [rsp+0xB0]
00007cc2697daf20  vmovaps xmm12, [rsp+0xC0]
00007cc2697daf29  vmovaps xmm13, [rsp+0xD0]
00007cc2697daf32  vmovaps xmm15, [rsp+0xE0]
00007cc2697daf3b  add rsp, 0xF0
00007cc2697daf42  pop r11
00007cc2697daf44  pop r10
00007cc2697daf46  pop r9
00007cc2697daf48  pop r8
00007cc2697daf4a  pop rsi
00007cc2697daf4b  pop rdi
00007cc2697daf4c  pop rdx
00007cc2697daf4d  pop rcx
00007cc2697daf4e  pop rax
00007cc2697daf4f  add rsp, 0x08
00007cc2697daf53  jmp 0x00007CC2697DA01C
00007cc2697daf58  sub rsp, 0x08
00007cc2697daf5c  push rax
00007cc2697daf5d  push rcx
00007cc2697daf5e  push rdx
00007cc2697daf5f  push rdi
00007cc2697daf60  push rsi
00007cc2697daf61  push r8
00007cc2697daf63  push r9
00007cc2697daf65  push r10
00007cc2697daf67  push r11
00007cc2697daf69  sub rsp, 0xF0
00007cc2697daf70  vmovaps [rsp], xmm0
00007cc2697daf75  vmovaps [rsp+0x10], xmm1
00007cc2697daf7b  vmovaps [rsp+0x20], xmm3
00007cc2697daf81  vmovaps [rsp+0x30], xmm4
00007cc2697daf87  vmovaps [rsp+0x40], xmm5
00007cc2697daf8d  vmovaps [rsp+0x50], xmm6
00007cc2697daf93  vmovaps [rsp+0x60], xmm7
00007cc2697daf99  vmovaps [rsp+0x70], xmm8
00007cc2697daf9f  vmovaps [rsp+0x80], xmm9
00007cc2697dafa8  vmovaps [rsp+0x90], xmm10
00007cc2697dafb1  vmovaps [rsp+0xA0], xmm11
00007cc2697dafba  vmovaps [rsp+0xB0], xmm12
00007cc2697dafc3  vmovaps [rsp+0xC0], xmm13
00007cc2697dafcc  vmovaps [rsp+0xD0], xmm14
00007cc2697dafd5  vmovaps [rsp+0xE0], xmm15
00007cc2697dafde  sub rsp, 0x40
00007cc2697dafe2  lea rdi, [rsp]
00007cc2697dafe6  lea rsi, [rsp+0x10]
00007cc2697dafeb  lea rdx, [rsp+0x20]
00007cc2697daff0  lea rcx, [rsp+0x30]
00007cc2697daff5  mov r8d, 0x00
00007cc2697daffb  lea r9, [r15+0x3A8]
00007cc2697db002  movaps [rdi], xmm2
00007cc2697db005  movaps [rsi], xmm15
00007cc2697db009  movaps [rdx], xmm12
00007cc2697db00d  movaps [rcx], xmm1
00007cc2697db010  mov rax, 0x653E5FFFBA50
00007cc2697db01a  call rax
00007cc2697db01c  movaps xmm2, [rsp]
00007cc2697db020  add rsp, 0x40
00007cc2697db024  vmovaps xmm0, [rsp]
00007cc2697db029  vmovaps xmm1, [rsp+0x10]
00007cc2697db02f  vmovaps xmm3, [rsp+0x20]
00007cc2697db035  vmovaps xmm4, [rsp+0x30]
00007cc2697db03b  vmovaps xmm5, [rsp+0x40]
00007cc2697db041  vmovaps xmm6, [rsp+0x50]
00007cc2697db047  vmovaps xmm7, [rsp+0x60]
00007cc2697db04d  vmovaps xmm8, [rsp+0x70]
00007cc2697db053  vmovaps xmm9, [rsp+0x80]
00007cc2697db05c  vmovaps xmm10, [rsp+0x90]
00007cc2697db065  vmovaps xmm11, [rsp+0xA0]
00007cc2697db06e  vmovaps xmm12, [rsp+0xB0]
00007cc2697db077  vmovaps xmm13, [rsp+0xC0]
00007cc2697db080  vmovaps xmm14, [rsp+0xD0]
00007cc2697db089  vmovaps xmm15, [rsp+0xE0]
00007cc2697db092  add rsp, 0xF0
00007cc2697db099  pop r11
00007cc2697db09b  pop r10
00007cc2697db09d  pop r9
00007cc2697db09f  pop r8
00007cc2697db0a1  pop rsi
00007cc2697db0a2  pop rdi
00007cc2697db0a3  pop rdx
00007cc2697db0a4  pop rcx
00007cc2697db0a5  pop rax
00007cc2697db0a6  add rsp, 0x08
00007cc2697db0aa  jmp 0x00007CC2697DA059
00007cc2697db0af  sub rsp, 0x08
00007cc2697db0b3  push rax
00007cc2697db0b4  push rcx
00007cc2697db0b5  push rdx
00007cc2697db0b6  push rdi
00007cc2697db0b7  push rsi
00007cc2697db0b8  push r8
00007cc2697db0ba  push r9
00007cc2697db0bc  push r10
00007cc2697db0be  push r11
00007cc2697db0c0  sub rsp, 0xF0
00007cc2697db0c7  vmovaps [rsp], xmm0
00007cc2697db0cc  vmovaps [rsp+0x10], xmm1
00007cc2697db0d2  vmovaps [rsp+0x20], xmm2
00007cc2697db0d8  vmovaps [rsp+0x30], xmm3
00007cc2697db0de  vmovaps [rsp+0x40], xmm4
00007cc2697db0e4  vmovaps [rsp+0x50], xmm5
00007cc2697db0ea  vmovaps [rsp+0x60], xmm6
00007cc2697db0f0  vmovaps [rsp+0x70], xmm7
00007cc2697db0f6  vmovaps [rsp+0x80], xmm8
00007cc2697db0ff  vmovaps [rsp+0x90], xmm9
00007cc2697db108  vmovaps [rsp+0xA0], xmm10
00007cc2697db111  vmovaps [rsp+0xB0], xmm11
00007cc2697db11a  vmovaps [rsp+0xC0], xmm13
00007cc2697db123  vmovaps [rsp+0xD0], xmm14
00007cc2697db12c  vmovaps [rsp+0xE0], xmm15
00007cc2697db135  sub rsp, 0x40
00007cc2697db139  lea rdi, [rsp]
00007cc2697db13d  lea rsi, [rsp+0x10]
00007cc2697db142  lea rdx, [rsp+0x20]
00007cc2697db147  lea rcx, [rsp+0x30]
00007cc2697db14c  mov r8d, 0x00
00007cc2697db152  lea r9, [r15+0x3A8]
00007cc2697db159  movaps [rdi], xmm12
00007cc2697db15d  movaps [rsi], xmm14
00007cc2697db161  movaps [rdx], xmm3
00007cc2697db164  movaps [rcx], xmm15
00007cc2697db168  mov rax, 0x653E5FFFBA50
00007cc2697db172  call rax
00007cc2697db174  movaps xmm12, [rsp]
00007cc2697db179  add rsp, 0x40
00007cc2697db17d  vmovaps xmm0, [rsp]
00007cc2697db182  vmovaps xmm1, [rsp+0x10]
00007cc2697db188  vmovaps xmm2, [rsp+0x20]
00007cc2697db18e  vmovaps xmm3, [rsp+0x30]
00007cc2697db194  vmovaps xmm4, [rsp+0x40]
00007cc2697db19a  vmovaps xmm5, [rsp+0x50]
00007cc2697db1a0  vmovaps xmm6, [rsp+0x60]
00007cc2697db1a6  vmovaps xmm7, [rsp+0x70]
00007cc2697db1ac  vmovaps xmm8, [rsp+0x80]
00007cc2697db1b5  vmovaps xmm9, [rsp+0x90]
00007cc2697db1be  vmovaps xmm10, [rsp+0xA0]
00007cc2697db1c7  vmovaps xmm11, [rsp+0xB0]
00007cc2697db1d0  vmovaps xmm13, [rsp+0xC0]
00007cc2697db1d9  vmovaps xmm14, [rsp+0xD0]
00007cc2697db1e2  vmovaps xmm15, [rsp+0xE0]
00007cc2697db1eb  add rsp, 0xF0
00007cc2697db1f2  pop r11
00007cc2697db1f4  pop r10
00007cc2697db1f6  pop r9
00007cc2697db1f8  pop r8
00007cc2697db1fa  pop rsi
00007cc2697db1fb  pop rdi
00007cc2697db1fc  pop rdx
00007cc2697db1fd  pop rcx
00007cc2697db1fe  pop rax
00007cc2697db1ff  add rsp, 0x08
00007cc2697db203  jmp 0x00007CC2697DA0B3
00007cc2697db208  sub rsp, 0x08
00007cc2697db20c  push rax
00007cc2697db20d  push rcx
00007cc2697db20e  push rdx
00007cc2697db20f  push rdi
00007cc2697db210  push rsi
00007cc2697db211  push r8
00007cc2697db213  push r9
00007cc2697db215  push r10
00007cc2697db217  push r11
00007cc2697db219  sub rsp, 0xF0
00007cc2697db220  vmovaps [rsp], xmm0
00007cc2697db225  vmovaps [rsp+0x10], xmm1
00007cc2697db22b  vmovaps [rsp+0x20], xmm2
00007cc2697db231  vmovaps [rsp+0x30], xmm3
00007cc2697db237  vmovaps [rsp+0x40], xmm4
00007cc2697db23d  vmovaps [rsp+0x50], xmm5
00007cc2697db243  vmovaps [rsp+0x60], xmm6
00007cc2697db249  vmovaps [rsp+0x70], xmm7
00007cc2697db24f  vmovaps [rsp+0x80], xmm8
00007cc2697db258  vmovaps [rsp+0x90], xmm10
00007cc2697db261  vmovaps [rsp+0xA0], xmm11
00007cc2697db26a  vmovaps [rsp+0xB0], xmm12
00007cc2697db273  vmovaps [rsp+0xC0], xmm13
00007cc2697db27c  vmovaps [rsp+0xD0], xmm14
00007cc2697db285  vmovaps [rsp+0xE0], xmm15
00007cc2697db28e  sub rsp, 0x40
00007cc2697db292  lea rdi, [rsp]
00007cc2697db296  lea rsi, [rsp+0x10]
00007cc2697db29b  lea rdx, [rsp+0x20]
00007cc2697db2a0  lea rcx, [rsp+0x30]
00007cc2697db2a5  mov r8d, 0x00
00007cc2697db2ab  lea r9, [r15+0x3A8]
00007cc2697db2b2  movaps [rdi], xmm9
00007cc2697db2b6  movaps [rsi], xmm13
00007cc2697db2ba  movaps [rdx], xmm14
00007cc2697db2be  movaps [rcx], xmm6
00007cc2697db2c1  mov rax, 0x653E5FFFBA50
00007cc2697db2cb  call rax
00007cc2697db2cd  movaps xmm9, [rsp]
00007cc2697db2d2  add rsp, 0x40
00007cc2697db2d6  vmovaps xmm0, [rsp]
00007cc2697db2db  vmovaps xmm1, [rsp+0x10]
00007cc2697db2e1  vmovaps xmm2, [rsp+0x20]
00007cc2697db2e7  vmovaps xmm3, [rsp+0x30]
00007cc2697db2ed  vmovaps xmm4, [rsp+0x40]
00007cc2697db2f3  vmovaps xmm5, [rsp+0x50]
00007cc2697db2f9  vmovaps xmm6, [rsp+0x60]
00007cc2697db2ff  vmovaps xmm7, [rsp+0x70]
00007cc2697db305  vmovaps xmm8, [rsp+0x80]
00007cc2697db30e  vmovaps xmm10, [rsp+0x90]
00007cc2697db317  vmovaps xmm11, [rsp+0xA0]
00007cc2697db320  vmovaps xmm12, [rsp+0xB0]
00007cc2697db329  vmovaps xmm13, [rsp+0xC0]
00007cc2697db332  vmovaps xmm14, [rsp+0xD0]
00007cc2697db33b  vmovaps xmm15, [rsp+0xE0]
00007cc2697db344  add rsp, 0xF0
00007cc2697db34b  pop r11
00007cc2697db34d  pop r10
00007cc2697db34f  pop r9
00007cc2697db351  pop r8
00007cc2697db353  pop rsi
00007cc2697db354  pop rdi
00007cc2697db355  pop rdx
00007cc2697db356  pop rcx
00007cc2697db357  pop rax
00007cc2697db358  add rsp, 0x08
00007cc2697db35c  jmp 0x00007CC2697DA15D
00007cc2697db361  sub rsp, 0x08
00007cc2697db365  push rax
00007cc2697db366  push rcx
00007cc2697db367  push rdx
00007cc2697db368  push rdi
00007cc2697db369  push rsi
00007cc2697db36a  push r8
00007cc2697db36c  push r9
00007cc2697db36e  push r10
00007cc2697db370  push r11
00007cc2697db372  sub rsp, 0xF0
00007cc2697db379  vmovaps [rsp], xmm0
00007cc2697db37e  vmovaps [rsp+0x10], xmm1
00007cc2697db384  vmovaps [rsp+0x20], xmm2
00007cc2697db38a  vmovaps [rsp+0x30], xmm4
00007cc2697db390  vmovaps [rsp+0x40], xmm5
00007cc2697db396  vmovaps [rsp+0x50], xmm6
00007cc2697db39c  vmovaps [rsp+0x60], xmm7
00007cc2697db3a2  vmovaps [rsp+0x70], xmm8
00007cc2697db3a8  vmovaps [rsp+0x80], xmm9
00007cc2697db3b1  vmovaps [rsp+0x90], xmm10
00007cc2697db3ba  vmovaps [rsp+0xA0], xmm11
00007cc2697db3c3  vmovaps [rsp+0xB0], xmm12
00007cc2697db3cc  vmovaps [rsp+0xC0], xmm13
00007cc2697db3d5  vmovaps [rsp+0xD0], xmm14
00007cc2697db3de  vmovaps [rsp+0xE0], xmm15
00007cc2697db3e7  sub rsp, 0x40
00007cc2697db3eb  lea rdi, [rsp]
00007cc2697db3ef  lea rsi, [rsp+0x10]
00007cc2697db3f4  lea rdx, [rsp+0x20]
00007cc2697db3f9  lea rcx, [rsp+0x30]
00007cc2697db3fe  mov r8d, 0x00
00007cc2697db404  lea r9, [r15+0x3A8]
00007cc2697db40b  movaps [rdi], xmm3
00007cc2697db40e  movaps [rsi], xmm13
00007cc2697db412  movaps [rdx], xmm6
00007cc2697db415  movaps [rcx], xmm14
00007cc2697db419  mov rax, 0x653E5FFFBA50
00007cc2697db423  call rax
00007cc2697db425  movaps xmm3, [rsp]
00007cc2697db429  add rsp, 0x40
00007cc2697db42d  vmovaps xmm0, [rsp]
00007cc2697db432  vmovaps xmm1, [rsp+0x10]
00007cc2697db438  vmovaps xmm2, [rsp+0x20]
00007cc2697db43e  vmovaps xmm4, [rsp+0x30]
00007cc2697db444  vmovaps xmm5, [rsp+0x40]
00007cc2697db44a  vmovaps xmm6, [rsp+0x50]
00007cc2697db450  vmovaps xmm7, [rsp+0x60]
00007cc2697db456  vmovaps xmm8, [rsp+0x70]
00007cc2697db45c  vmovaps xmm9, [rsp+0x80]
00007cc2697db465  vmovaps xmm10, [rsp+0x90]
00007cc2697db46e  vmovaps xmm11, [rsp+0xA0]
00007cc2697db477  vmovaps xmm12, [rsp+0xB0]
00007cc2697db480  vmovaps xmm13, [rsp+0xC0]
00007cc2697db489  vmovaps xmm14, [rsp+0xD0]
00007cc2697db492  vmovaps xmm15, [rsp+0xE0]
00007cc2697db49b  add rsp, 0xF0
00007cc2697db4a2  pop r11
00007cc2697db4a4  pop r10
00007cc2697db4a6  pop r9
00007cc2697db4a8  pop r8
00007cc2697db4aa  pop rsi
00007cc2697db4ab  pop rdi
00007cc2697db4ac  pop rdx
00007cc2697db4ad  pop rcx
00007cc2697db4ae  pop rax
00007cc2697db4af  add rsp, 0x08
00007cc2697db4b3  jmp 0x00007CC2697DA19A
00007cc2697db4b8  sub rsp, 0x08
00007cc2697db4bc  push rax
00007cc2697db4bd  push rcx
00007cc2697db4be  push rdx
00007cc2697db4bf  push rdi
00007cc2697db4c0  push rsi
00007cc2697db4c1  push r8
00007cc2697db4c3  push r9
00007cc2697db4c5  push r10
00007cc2697db4c7  push r11
00007cc2697db4c9  sub rsp, 0xF0
00007cc2697db4d0  vmovaps [rsp], xmm0
00007cc2697db4d5  vmovaps [rsp+0x10], xmm1
00007cc2697db4db  vmovaps [rsp+0x20], xmm2
00007cc2697db4e1  vmovaps [rsp+0x30], xmm3
00007cc2697db4e7  vmovaps [rsp+0x40], xmm4
00007cc2697db4ed  vmovaps [rsp+0x50], xmm5
00007cc2697db4f3  vmovaps [rsp+0x60], xmm7
00007cc2697db4f9  vmovaps [rsp+0x70], xmm8
00007cc2697db4ff  vmovaps [rsp+0x80], xmm9
00007cc2697db508  vmovaps [rsp+0x90], xmm10
00007cc2697db511  vmovaps [rsp+0xA0], xmm11
00007cc2697db51a  vmovaps [rsp+0xB0], xmm12
00007cc2697db523  vmovaps [rsp+0xC0], xmm13
00007cc2697db52c  vmovaps [rsp+0xD0], xmm14
00007cc2697db535  vmovaps [rsp+0xE0], xmm15
00007cc2697db53e  sub rsp, 0x40
00007cc2697db542  lea rdi, [rsp]
00007cc2697db546  lea rsi, [rsp+0x10]
00007cc2697db54b  lea rdx, [rsp+0x20]
00007cc2697db550  lea rcx, [rsp+0x30]
00007cc2697db555  mov r8d, 0x00
00007cc2697db55b  lea r9, [r15+0x3A8]
00007cc2697db562  movaps [rdi], xmm6
00007cc2697db565  movaps [rsi], xmm2
00007cc2697db568  movaps [rdx], xmm14
00007cc2697db56c  movaps [rcx], xmm1
00007cc2697db56f  mov rax, 0x653E5FFFBA50
00007cc2697db579  call rax
00007cc2697db57b  movaps xmm6, [rsp]
00007cc2697db57f  add rsp, 0x40
00007cc2697db583  vmovaps xmm0, [rsp]
00007cc2697db588  vmovaps xmm1, [rsp+0x10]
00007cc2697db58e  vmovaps xmm2, [rsp+0x20]
00007cc2697db594  vmovaps xmm3, [rsp+0x30]
00007cc2697db59a  vmovaps xmm4, [rsp+0x40]
00007cc2697db5a0  vmovaps xmm5, [rsp+0x50]
00007cc2697db5a6  vmovaps xmm7, [rsp+0x60]
00007cc2697db5ac  vmovaps xmm8, [rsp+0x70]
00007cc2697db5b2  vmovaps xmm9, [rsp+0x80]
00007cc2697db5bb  vmovaps xmm10, [rsp+0x90]
00007cc2697db5c4  vmovaps xmm11, [rsp+0xA0]
00007cc2697db5cd  vmovaps xmm12, [rsp+0xB0]
00007cc2697db5d6  vmovaps xmm13, [rsp+0xC0]
00007cc2697db5df  vmovaps xmm14, [rsp+0xD0]
00007cc2697db5e8  vmovaps xmm15, [rsp+0xE0]
00007cc2697db5f1  add rsp, 0xF0
00007cc2697db5f8  pop r11
00007cc2697db5fa  pop r10
00007cc2697db5fc  pop r9
00007cc2697db5fe  pop r8
00007cc2697db600  pop rsi
00007cc2697db601  pop rdi
00007cc2697db602  pop rdx
00007cc2697db603  pop rcx
00007cc2697db604  pop rax
00007cc2697db605  add rsp, 0x08
00007cc2697db609  jmp 0x00007CC2697DA1C7
00007cc2697db60e  sub rsp, 0x08
00007cc2697db612  push rax
00007cc2697db613  push rcx
00007cc2697db614  push rdx
00007cc2697db615  push rdi
00007cc2697db616  push rsi
00007cc2697db617  push r8
00007cc2697db619  push r9
00007cc2697db61b  push r10
00007cc2697db61d  push r11
00007cc2697db61f  sub rsp, 0xF0
00007cc2697db626  vmovaps [rsp], xmm0
00007cc2697db62b  vmovaps [rsp+0x10], xmm1
00007cc2697db631  vmovaps [rsp+0x20], xmm2
00007cc2697db637  vmovaps [rsp+0x30], xmm3
00007cc2697db63d  vmovaps [rsp+0x40], xmm4
00007cc2697db643  vmovaps [rsp+0x50], xmm5
00007cc2697db649  vmovaps [rsp+0x60], xmm6
00007cc2697db64f  vmovaps [rsp+0x70], xmm7
00007cc2697db655  vmovaps [rsp+0x80], xmm8
00007cc2697db65e  vmovaps [rsp+0x90], xmm9
00007cc2697db667  vmovaps [rsp+0xA0], xmm10
00007cc2697db670  vmovaps [rsp+0xB0], xmm11
00007cc2697db679  vmovaps [rsp+0xC0], xmm12
00007cc2697db682  vmovaps [rsp+0xD0], xmm14
00007cc2697db68b  vmovaps [rsp+0xE0], xmm15
00007cc2697db694  sub rsp, 0x40
00007cc2697db698  lea rdi, [rsp]
00007cc2697db69c  lea rsi, [rsp+0x10]
00007cc2697db6a1  lea rdx, [rsp+0x20]
00007cc2697db6a6  lea rcx, [rsp+0x30]
00007cc2697db6ab  mov r8d, 0x00
00007cc2697db6b1  lea r9, [r15+0x3A8]
00007cc2697db6b8  movaps [rdi], xmm13
00007cc2697db6bc  movaps [rsi], xmm12
00007cc2697db6c0  movaps [rdx], xmm14
00007cc2697db6c4  movaps [rcx], xmm1
00007cc2697db6c7  mov rax, 0x653E5FFFBA50
00007cc2697db6d1  call rax
00007cc2697db6d3  movaps xmm13, [rsp]
00007cc2697db6d8  add rsp, 0x40
00007cc2697db6dc  vmovaps xmm0, [rsp]
00007cc2697db6e1  vmovaps xmm1, [rsp+0x10]
00007cc2697db6e7  vmovaps xmm2, [rsp+0x20]
00007cc2697db6ed  vmovaps xmm3, [rsp+0x30]
00007cc2697db6f3  vmovaps xmm4, [rsp+0x40]
00007cc2697db6f9  vmovaps xmm5, [rsp+0x50]
00007cc2697db6ff  vmovaps xmm6, [rsp+0x60]
00007cc2697db705  vmovaps xmm7, [rsp+0x70]
00007cc2697db70b  vmovaps xmm8, [rsp+0x80]
00007cc2697db714  vmovaps xmm9, [rsp+0x90]
00007cc2697db71d  vmovaps xmm10, [rsp+0xA0]
00007cc2697db726  vmovaps xmm11, [rsp+0xB0]
00007cc2697db72f  vmovaps xmm12, [rsp+0xC0]
00007cc2697db738  vmovaps xmm14, [rsp+0xD0]
00007cc2697db741  vmovaps xmm15, [rsp+0xE0]
00007cc2697db74a  add rsp, 0xF0
00007cc2697db751  pop r11
00007cc2697db753  pop r10
00007cc2697db755  pop r9
00007cc2697db757  pop r8
00007cc2697db759  pop rsi
00007cc2697db75a  pop rdi
00007cc2697db75b  pop rdx
00007cc2697db75c  pop rcx
00007cc2697db75d  pop rax
00007cc2697db75e  add rsp, 0x08
00007cc2697db762  jmp 0x00007CC2697DA1F9
00007cc2697db767  sub rsp, 0x08
00007cc2697db76b  push rax
00007cc2697db76c  push rcx
00007cc2697db76d  push rdx
00007cc2697db76e  push rdi
00007cc2697db76f  push rsi
00007cc2697db770  push r8
00007cc2697db772  push r9
00007cc2697db774  push r10
00007cc2697db776  push r11
00007cc2697db778  sub rsp, 0xF0
00007cc2697db77f  vmovaps [rsp], xmm0
00007cc2697db784  vmovaps [rsp+0x10], xmm1
00007cc2697db78a  vmovaps [rsp+0x20], xmm2
00007cc2697db790  vmovaps [rsp+0x30], xmm3
00007cc2697db796  vmovaps [rsp+0x40], xmm4
00007cc2697db79c  vmovaps [rsp+0x50], xmm5
00007cc2697db7a2  vmovaps [rsp+0x60], xmm6
00007cc2697db7a8  vmovaps [rsp+0x70], xmm7
00007cc2697db7ae  vmovaps [rsp+0x80], xmm8
00007cc2697db7b7  vmovaps [rsp+0x90], xmm9
00007cc2697db7c0  vmovaps [rsp+0xA0], xmm10
00007cc2697db7c9  vmovaps [rsp+0xB0], xmm11
00007cc2697db7d2  vmovaps [rsp+0xC0], xmm13
00007cc2697db7db  vmovaps [rsp+0xD0], xmm14
00007cc2697db7e4  vmovaps [rsp+0xE0], xmm15
00007cc2697db7ed  sub rsp, 0x40
00007cc2697db7f1  lea rdi, [rsp]
00007cc2697db7f5  lea rsi, [rsp+0x10]
00007cc2697db7fa  lea rdx, [rsp+0x20]
00007cc2697db7ff  lea rcx, [rsp+0x30]
00007cc2697db804  mov r8d, 0x00
00007cc2697db80a  lea r9, [r15+0x3A8]
00007cc2697db811  movaps [rdi], xmm12
00007cc2697db815  movaps [rsi], xmm3
00007cc2697db818  movaps [rdx], xmm14
00007cc2697db81c  movaps [rcx], xmm5
00007cc2697db81f  mov rax, 0x653E5FFFBA50
00007cc2697db829  call rax
00007cc2697db82b  movaps xmm12, [rsp]
00007cc2697db830  add rsp, 0x40
00007cc2697db834  vmovaps xmm0, [rsp]
00007cc2697db839  vmovaps xmm1, [rsp+0x10]
00007cc2697db83f  vmovaps xmm2, [rsp+0x20]
00007cc2697db845  vmovaps xmm3, [rsp+0x30]
00007cc2697db84b  vmovaps xmm4, [rsp+0x40]
00007cc2697db851  vmovaps xmm5, [rsp+0x50]
00007cc2697db857  vmovaps xmm6, [rsp+0x60]
00007cc2697db85d  vmovaps xmm7, [rsp+0x70]
00007cc2697db863  vmovaps xmm8, [rsp+0x80]
00007cc2697db86c  vmovaps xmm9, [rsp+0x90]
00007cc2697db875  vmovaps xmm10, [rsp+0xA0]
00007cc2697db87e  vmovaps xmm11, [rsp+0xB0]
00007cc2697db887  vmovaps xmm13, [rsp+0xC0]
00007cc2697db890  vmovaps xmm14, [rsp+0xD0]
00007cc2697db899  vmovaps xmm15, [rsp+0xE0]
00007cc2697db8a2  add rsp, 0xF0
00007cc2697db8a9  pop r11
00007cc2697db8ab  pop r10
00007cc2697db8ad  pop r9
00007cc2697db8af  pop r8
00007cc2697db8b1  pop rsi
00007cc2697db8b2  pop rdi
00007cc2697db8b3  pop rdx
00007cc2697db8b4  pop rcx
00007cc2697db8b5  pop rax
00007cc2697db8b6  add rsp, 0x08
00007cc2697db8ba  jmp 0x00007CC2697DA256
00007cc2697db8bf  sub rsp, 0x08
00007cc2697db8c3  push rax
00007cc2697db8c4  push rcx
00007cc2697db8c5  push rdx
00007cc2697db8c6  push rdi
00007cc2697db8c7  push rsi
00007cc2697db8c8  push r8
00007cc2697db8ca  push r9
00007cc2697db8cc  push r10
00007cc2697db8ce  push r11
00007cc2697db8d0  sub rsp, 0xF0
00007cc2697db8d7  vmovaps [rsp], xmm0
00007cc2697db8dc  vmovaps [rsp+0x10], xmm1
00007cc2697db8e2  vmovaps [rsp+0x20], xmm2
00007cc2697db8e8  vmovaps [rsp+0x30], xmm3
00007cc2697db8ee  vmovaps [rsp+0x40], xmm4
00007cc2697db8f4  vmovaps [rsp+0x50], xmm5
00007cc2697db8fa  vmovaps [rsp+0x60], xmm6
00007cc2697db900  vmovaps [rsp+0x70], xmm7
00007cc2697db906  vmovaps [rsp+0x80], xmm8
00007cc2697db90f  vmovaps [rsp+0x90], xmm9
00007cc2697db918  vmovaps [rsp+0xA0], xmm11
00007cc2697db921  vmovaps [rsp+0xB0], xmm12
00007cc2697db92a  vmovaps [rsp+0xC0], xmm13
00007cc2697db933  vmovaps [rsp+0xD0], xmm14
00007cc2697db93c  vmovaps [rsp+0xE0], xmm15
00007cc2697db945  sub rsp, 0x40
00007cc2697db949  lea rdi, [rsp]
00007cc2697db94d  lea rsi, [rsp+0x10]
00007cc2697db952  lea rdx, [rsp+0x20]
00007cc2697db957  lea rcx, [rsp+0x30]
00007cc2697db95c  mov r8d, 0x00
00007cc2697db962  lea r9, [r15+0x3A8]
00007cc2697db969  movaps [rdi], xmm10
00007cc2697db96d  movaps [rsi], xmm9
00007cc2697db971  movaps [rdx], xmm7
00007cc2697db974  movaps [rcx], xmm14
00007cc2697db978  mov rax, 0x653E5FFFBA50
00007cc2697db982  call rax
00007cc2697db984  movaps xmm10, [rsp]
00007cc2697db989  add rsp, 0x40
00007cc2697db98d  vmovaps xmm0, [rsp]
00007cc2697db992  vmovaps xmm1, [rsp+0x10]
00007cc2697db998  vmovaps xmm2, [rsp+0x20]
00007cc2697db99e  vmovaps xmm3, [rsp+0x30]
00007cc2697db9a4  vmovaps xmm4, [rsp+0x40]
00007cc2697db9aa  vmovaps xmm5, [rsp+0x50]
00007cc2697db9b0  vmovaps xmm6, [rsp+0x60]
00007cc2697db9b6  vmovaps xmm7, [rsp+0x70]
00007cc2697db9bc  vmovaps xmm8, [rsp+0x80]
00007cc2697db9c5  vmovaps xmm9, [rsp+0x90]
00007cc2697db9ce  vmovaps xmm11, [rsp+0xA0]
00007cc2697db9d7  vmovaps xmm12, [rsp+0xB0]
00007cc2697db9e0  vmovaps xmm13, [rsp+0xC0]
00007cc2697db9e9  vmovaps xmm14, [rsp+0xD0]
00007cc2697db9f2  vmovaps xmm15, [rsp+0xE0]
00007cc2697db9fb  add rsp, 0xF0
00007cc2697dba02  pop r11
00007cc2697dba04  pop r10
00007cc2697dba06  pop r9
00007cc2697dba08  pop r8
00007cc2697dba0a  pop rsi
00007cc2697dba0b  pop rdi
00007cc2697dba0c  pop rdx
00007cc2697dba0d  pop rcx
00007cc2697dba0e  pop rax
00007cc2697dba0f  add rsp, 0x08
00007cc2697dba13  jmp 0x00007CC2697DA27C
00007cc2697dba18  call 0x00007CC26960D4E0
00007cc2697dba1d  jmp 0x00007CC2697DA289
00007cc2697dba22  sub rsp, 0x08
00007cc2697dba26  push rax
00007cc2697dba27  push rcx
00007cc2697dba28  push rdx
00007cc2697dba29  push rdi
00007cc2697dba2a  push rsi
00007cc2697dba2b  push r8
00007cc2697dba2d  push r9
00007cc2697dba2f  push r10
00007cc2697dba31  push r11
00007cc2697dba33  sub rsp, 0xF0
00007cc2697dba3a  vmovaps [rsp], xmm0
00007cc2697dba3f  vmovaps [rsp+0x10], xmm1
00007cc2697dba45  vmovaps [rsp+0x20], xmm2
00007cc2697dba4b  vmovaps [rsp+0x30], xmm3
00007cc2697dba51  vmovaps [rsp+0x40], xmm4
00007cc2697dba57  vmovaps [rsp+0x50], xmm6
00007cc2697dba5d  vmovaps [rsp+0x60], xmm7
00007cc2697dba63  vmovaps [rsp+0x70], xmm8
00007cc2697dba69  vmovaps [rsp+0x80], xmm9
00007cc2697dba72  vmovaps [rsp+0x90], xmm10
00007cc2697dba7b  vmovaps [rsp+0xA0], xmm11
00007cc2697dba84  vmovaps [rsp+0xB0], xmm12
00007cc2697dba8d  vmovaps [rsp+0xC0], xmm13
00007cc2697dba96  vmovaps [rsp+0xD0], xmm14
00007cc2697dba9f  vmovaps [rsp+0xE0], xmm15
00007cc2697dbaa8  sub rsp, 0x40
00007cc2697dbaac  lea rdi, [rsp]
00007cc2697dbab0  lea rsi, [rsp+0x10]
00007cc2697dbab5  lea rdx, [rsp+0x20]
00007cc2697dbaba  lea rcx, [rsp+0x30]
00007cc2697dbabf  mov r8d, 0x00
00007cc2697dbac5  lea r9, [r15+0x3A8]
00007cc2697dbacc  movaps [rdi], xmm5
00007cc2697dbacf  movaps [rsi], xmm6
00007cc2697dbad2  movaps [rdx], xmm7
00007cc2697dbad5  movaps [rcx], xmm9
00007cc2697dbad9  mov rax, 0x653E5FFFBA50
00007cc2697dbae3  call rax
00007cc2697dbae5  movaps xmm5, [rsp]
00007cc2697dbae9  add rsp, 0x40
00007cc2697dbaed  vmovaps xmm0, [rsp]
00007cc2697dbaf2  vmovaps xmm1, [rsp+0x10]
00007cc2697dbaf8  vmovaps xmm2, [rsp+0x20]
00007cc2697dbafe  vmovaps xmm3, [rsp+0x30]
00007cc2697dbb04  vmovaps xmm4, [rsp+0x40]
00007cc2697dbb0a  vmovaps xmm6, [rsp+0x50]
00007cc2697dbb10  vmovaps xmm7, [rsp+0x60]
00007cc2697dbb16  vmovaps xmm8, [rsp+0x70]
00007cc2697dbb1c  vmovaps xmm9, [rsp+0x80]
00007cc2697dbb25  vmovaps xmm10, [rsp+0x90]
00007cc2697dbb2e  vmovaps xmm11, [rsp+0xA0]
00007cc2697dbb37  vmovaps xmm12, [rsp+0xB0]
00007cc2697dbb40  vmovaps xmm13, [rsp+0xC0]
00007cc2697dbb49  vmovaps xmm14, [rsp+0xD0]
00007cc2697dbb52  vmovaps xmm15, [rsp+0xE0]
00007cc2697dbb5b  add rsp, 0xF0
00007cc2697dbb62  pop r11
00007cc2697dbb64  pop r10
00007cc2697dbb66  pop r9
00007cc2697dbb68  pop r8
00007cc2697dbb6a  pop rsi
00007cc2697dbb6b  pop rdi
00007cc2697dbb6c  pop rdx
00007cc2697dbb6d  pop rcx
00007cc2697dbb6e  pop rax
00007cc2697dbb6f  add rsp, 0x08
00007cc2697dbb73  jmp 0x00007CC2697DA2BB
00007cc2697dbb78  sub rsp, 0x08
00007cc2697dbb7c  push rax
00007cc2697dbb7d  push rcx
00007cc2697dbb7e  push rdx
00007cc2697dbb7f  push rdi
00007cc2697dbb80  push rsi
00007cc2697dbb81  push r8
00007cc2697dbb83  push r9
00007cc2697dbb85  push r10
00007cc2697dbb87  push r11
00007cc2697dbb89  sub rsp, 0xF0
00007cc2697dbb90  vmovaps [rsp], xmm0
00007cc2697dbb95  vmovaps [rsp+0x10], xmm1
00007cc2697dbb9b  vmovaps [rsp+0x20], xmm2
00007cc2697dbba1  vmovaps [rsp+0x30], xmm3
00007cc2697dbba7  vmovaps [rsp+0x40], xmm4
00007cc2697dbbad  vmovaps [rsp+0x50], xmm5
00007cc2697dbbb3  vmovaps [rsp+0x60], xmm6
00007cc2697dbbb9  vmovaps [rsp+0x70], xmm8
00007cc2697dbbbf  vmovaps [rsp+0x80], xmm9
00007cc2697dbbc8  vmovaps [rsp+0x90], xmm10
00007cc2697dbbd1  vmovaps [rsp+0xA0], xmm11
00007cc2697dbbda  vmovaps [rsp+0xB0], xmm12
00007cc2697dbbe3  vmovaps [rsp+0xC0], xmm13
00007cc2697dbbec  vmovaps [rsp+0xD0], xmm14
00007cc2697dbbf5  vmovaps [rsp+0xE0], xmm15
00007cc2697dbbfe  sub rsp, 0x40
00007cc2697dbc02  lea rdi, [rsp]
00007cc2697dbc06  lea rsi, [rsp+0x10]
00007cc2697dbc0b  lea rdx, [rsp+0x20]
00007cc2697dbc10  lea rcx, [rsp+0x30]
00007cc2697dbc15  mov r8d, 0x00
00007cc2697dbc1b  lea r9, [r15+0x3A8]
00007cc2697dbc22  movaps [rdi], xmm7
00007cc2697dbc25  movaps [rsi], xmm13
00007cc2697dbc29  movaps [rdx], xmm1
00007cc2697dbc2c  movaps [rcx], xmm9
00007cc2697dbc30  mov rax, 0x653E5FFFBA50
00007cc2697dbc3a  call rax
00007cc2697dbc3c  movaps xmm7, [rsp]
00007cc2697dbc40  add rsp, 0x40
00007cc2697dbc44  vmovaps xmm0, [rsp]
00007cc2697dbc49  vmovaps xmm1, [rsp+0x10]
00007cc2697dbc4f  vmovaps xmm2, [rsp+0x20]
00007cc2697dbc55  vmovaps xmm3, [rsp+0x30]
00007cc2697dbc5b  vmovaps xmm4, [rsp+0x40]
00007cc2697dbc61  vmovaps xmm5, [rsp+0x50]
00007cc2697dbc67  vmovaps xmm6, [rsp+0x60]
00007cc2697dbc6d  vmovaps xmm8, [rsp+0x70]
00007cc2697dbc73  vmovaps xmm9, [rsp+0x80]
00007cc2697dbc7c  vmovaps xmm10, [rsp+0x90]
00007cc2697dbc85  vmovaps xmm11, [rsp+0xA0]
00007cc2697dbc8e  vmovaps xmm12, [rsp+0xB0]
00007cc2697dbc97  vmovaps xmm13, [rsp+0xC0]
00007cc2697dbca0  vmovaps xmm14, [rsp+0xD0]
00007cc2697dbca9  vmovaps xmm15, [rsp+0xE0]
00007cc2697dbcb2  add rsp, 0xF0
00007cc2697dbcb9  pop r11
00007cc2697dbcbb  pop r10
00007cc2697dbcbd  pop r9
00007cc2697dbcbf  pop r8
00007cc2697dbcc1  pop rsi
00007cc2697dbcc2  pop rdi
00007cc2697dbcc3  pop rdx
00007cc2697dbcc4  pop rcx
00007cc2697dbcc5  pop rax
00007cc2697dbcc6  add rsp, 0x08
00007cc2697dbcca  jmp 0x00007CC2697DA2E0
00007cc2697dbccf  call 0x00007CC26960C260
00007cc2697dbcd4  jmp 0x00007CC2697DA303
00007cc2697dbcd9  call 0x00007CC269607890
00007cc2697dbcde  jmp 0x00007CC2697DA30D
00007cc2697dbce3  sub rsp, 0x08
00007cc2697dbce7  push rax
00007cc2697dbce8  push rcx
00007cc2697dbce9  push rdx
00007cc2697dbcea  push rdi
00007cc2697dbceb  push rsi
00007cc2697dbcec  push r8
00007cc2697dbcee  push r9
00007cc2697dbcf0  push r10
00007cc2697dbcf2  push r11
00007cc2697dbcf4  sub rsp, 0xF0
00007cc2697dbcfb  vmovaps [rsp], xmm0
00007cc2697dbd00  vmovaps [rsp+0x10], xmm1
00007cc2697dbd06  vmovaps [rsp+0x20], xmm3
00007cc2697dbd0c  vmovaps [rsp+0x30], xmm4
00007cc2697dbd12  vmovaps [rsp+0x40], xmm5
00007cc2697dbd18  vmovaps [rsp+0x50], xmm6
00007cc2697dbd1e  vmovaps [rsp+0x60], xmm7
00007cc2697dbd24  vmovaps [rsp+0x70], xmm8
00007cc2697dbd2a  vmovaps [rsp+0x80], xmm9
00007cc2697dbd33  vmovaps [rsp+0x90], xmm10
00007cc2697dbd3c  vmovaps [rsp+0xA0], xmm11
00007cc2697dbd45  vmovaps [rsp+0xB0], xmm12
00007cc2697dbd4e  vmovaps [rsp+0xC0], xmm13
00007cc2697dbd57  vmovaps [rsp+0xD0], xmm14
00007cc2697dbd60  vmovaps [rsp+0xE0], xmm15
00007cc2697dbd69  sub rsp, 0x40
00007cc2697dbd6d  lea rdi, [rsp]
00007cc2697dbd71  lea rsi, [rsp+0x10]
00007cc2697dbd76  lea rdx, [rsp+0x20]
00007cc2697dbd7b  lea rcx, [rsp+0x30]
00007cc2697dbd80  mov r8d, 0x00
00007cc2697dbd86  lea r9, [r15+0x3A8]
00007cc2697dbd8d  movaps [rdi], xmm2
00007cc2697dbd90  movaps [rsi], xmm12
00007cc2697dbd94  movaps [rdx], xmm6
00007cc2697dbd97  movaps [rcx], xmm3
00007cc2697dbd9a  mov rax, 0x653E5FFFBA50
00007cc2697dbda4  call rax
00007cc2697dbda6  movaps xmm2, [rsp]
00007cc2697dbdaa  add rsp, 0x40
00007cc2697dbdae  vmovaps xmm0, [rsp]
00007cc2697dbdb3  vmovaps xmm1, [rsp+0x10]
00007cc2697dbdb9  vmovaps xmm3, [rsp+0x20]
00007cc2697dbdbf  vmovaps xmm4, [rsp+0x30]
00007cc2697dbdc5  vmovaps xmm5, [rsp+0x40]
00007cc2697dbdcb  vmovaps xmm6, [rsp+0x50]
00007cc2697dbdd1  vmovaps xmm7, [rsp+0x60]
00007cc2697dbdd7  vmovaps xmm8, [rsp+0x70]
00007cc2697dbddd  vmovaps xmm9, [rsp+0x80]
00007cc2697dbde6  vmovaps xmm10, [rsp+0x90]
00007cc2697dbdef  vmovaps xmm11, [rsp+0xA0]
00007cc2697dbdf8  vmovaps xmm12, [rsp+0xB0]
00007cc2697dbe01  vmovaps xmm13, [rsp+0xC0]
00007cc2697dbe0a  vmovaps xmm14, [rsp+0xD0]
00007cc2697dbe13  vmovaps xmm15, [rsp+0xE0]
00007cc2697dbe1c  add rsp, 0xF0
00007cc2697dbe23  pop r11
00007cc2697dbe25  pop r10
00007cc2697dbe27  pop r9
00007cc2697dbe29  pop r8
00007cc2697dbe2b  pop rsi
00007cc2697dbe2c  pop rdi
00007cc2697dbe2d  pop rdx
00007cc2697dbe2e  pop rcx
00007cc2697dbe2f  pop rax
00007cc2697dbe30  add rsp, 0x08
00007cc2697dbe34  jmp 0x00007CC2697DA353
00007cc2697dbe39  sub rsp, 0x08
00007cc2697dbe3d  push rax
00007cc2697dbe3e  push rcx
00007cc2697dbe3f  push rdx
00007cc2697dbe40  push rdi
00007cc2697dbe41  push rsi
00007cc2697dbe42  push r8
00007cc2697dbe44  push r9
00007cc2697dbe46  push r10
00007cc2697dbe48  push r11
00007cc2697dbe4a  sub rsp, 0xF0
00007cc2697dbe51  vmovaps [rsp], xmm0
00007cc2697dbe56  vmovaps [rsp+0x10], xmm1
00007cc2697dbe5c  vmovaps [rsp+0x20], xmm2
00007cc2697dbe62  vmovaps [rsp+0x30], xmm3
00007cc2697dbe68  vmovaps [rsp+0x40], xmm4
00007cc2697dbe6e  vmovaps [rsp+0x50], xmm5
00007cc2697dbe74  vmovaps [rsp+0x60], xmm7
00007cc2697dbe7a  vmovaps [rsp+0x70], xmm8
00007cc2697dbe80  vmovaps [rsp+0x80], xmm9
00007cc2697dbe89  vmovaps [rsp+0x90], xmm10
00007cc2697dbe92  vmovaps [rsp+0xA0], xmm11
00007cc2697dbe9b  vmovaps [rsp+0xB0], xmm12
00007cc2697dbea4  vmovaps [rsp+0xC0], xmm13
00007cc2697dbead  vmovaps [rsp+0xD0], xmm14
00007cc2697dbeb6  vmovaps [rsp+0xE0], xmm15
00007cc2697dbebf  sub rsp, 0x40
00007cc2697dbec3  lea rdi, [rsp]
00007cc2697dbec7  lea rsi, [rsp+0x10]
00007cc2697dbecc  lea rdx, [rsp+0x20]
00007cc2697dbed1  lea rcx, [rsp+0x30]
00007cc2697dbed6  mov r8d, 0x00
00007cc2697dbedc  lea r9, [r15+0x3A8]
00007cc2697dbee3  movaps [rdi], xmm6
00007cc2697dbee6  movaps [rsi], xmm10
00007cc2697dbeea  movaps [rdx], xmm12
00007cc2697dbeee  movaps [rcx], xmm1
00007cc2697dbef1  mov rax, 0x653E5FFFBA50
00007cc2697dbefb  call rax
00007cc2697dbefd  movaps xmm6, [rsp]
00007cc2697dbf01  add rsp, 0x40
00007cc2697dbf05  vmovaps xmm0, [rsp]
00007cc2697dbf0a  vmovaps xmm1, [rsp+0x10]
00007cc2697dbf10  vmovaps xmm2, [rsp+0x20]
00007cc2697dbf16  vmovaps xmm3, [rsp+0x30]
00007cc2697dbf1c  vmovaps xmm4, [rsp+0x40]
00007cc2697dbf22  vmovaps xmm5, [rsp+0x50]
00007cc2697dbf28  vmovaps xmm7, [rsp+0x60]
00007cc2697dbf2e  vmovaps xmm8, [rsp+0x70]
00007cc2697dbf34  vmovaps xmm9, [rsp+0x80]
00007cc2697dbf3d  vmovaps xmm10, [rsp+0x90]
00007cc2697dbf46  vmovaps xmm11, [rsp+0xA0]
00007cc2697dbf4f  vmovaps xmm12, [rsp+0xB0]
00007cc2697dbf58  vmovaps xmm13, [rsp+0xC0]
00007cc2697dbf61  vmovaps xmm14, [rsp+0xD0]
00007cc2697dbf6a  vmovaps xmm15, [rsp+0xE0]
00007cc2697dbf73  add rsp, 0xF0
00007cc2697dbf7a  pop r11
00007cc2697dbf7c  pop r10
00007cc2697dbf7e  pop r9
00007cc2697dbf80  pop r8
00007cc2697dbf82  pop rsi
00007cc2697dbf83  pop rdi
00007cc2697dbf84  pop rdx
00007cc2697dbf85  pop rcx
00007cc2697dbf86  pop rax
00007cc2697dbf87  add rsp, 0x08
00007cc2697dbf8b  jmp 0x00007CC2697DA381
00007cc2697dbf90  sub rsp, 0x08
00007cc2697dbf94  push rax
00007cc2697dbf95  push rcx
00007cc2697dbf96  push rdx
00007cc2697dbf97  push rdi
00007cc2697dbf98  push rsi
00007cc2697dbf99  push r8
00007cc2697dbf9b  push r9
00007cc2697dbf9d  push r10
00007cc2697dbf9f  push r11
00007cc2697dbfa1  sub rsp, 0xF0
00007cc2697dbfa8  vmovaps [rsp], xmm0
00007cc2697dbfad  vmovaps [rsp+0x10], xmm1
00007cc2697dbfb3  vmovaps [rsp+0x20], xmm2
00007cc2697dbfb9  vmovaps [rsp+0x30], xmm3
00007cc2697dbfbf  vmovaps [rsp+0x40], xmm4
00007cc2697dbfc5  vmovaps [rsp+0x50], xmm5
00007cc2697dbfcb  vmovaps [rsp+0x60], xmm6
00007cc2697dbfd1  vmovaps [rsp+0x70], xmm7
00007cc2697dbfd7  vmovaps [rsp+0x80], xmm8
00007cc2697dbfe0  vmovaps [rsp+0x90], xmm9
00007cc2697dbfe9  vmovaps [rsp+0xA0], xmm11
00007cc2697dbff2  vmovaps [rsp+0xB0], xmm12
00007cc2697dbffb  vmovaps [rsp+0xC0], xmm13
00007cc2697dc004  vmovaps [rsp+0xD0], xmm14
00007cc2697dc00d  vmovaps [rsp+0xE0], xmm15
00007cc2697dc016  sub rsp, 0x40
00007cc2697dc01a  lea rdi, [rsp]
00007cc2697dc01e  lea rsi, [rsp+0x10]
00007cc2697dc023  lea rdx, [rsp+0x20]
00007cc2697dc028  lea rcx, [rsp+0x30]
00007cc2697dc02d  mov r8d, 0x00
00007cc2697dc033  lea r9, [r15+0x3A8]
00007cc2697dc03a  movaps [rdi], xmm10
00007cc2697dc03e  movaps [rsi], xmm5
00007cc2697dc041  movaps [rdx], xmm12
00007cc2697dc045  movaps [rcx], xmm1
00007cc2697dc048  mov rax, 0x653E5FFFBA50
00007cc2697dc052  call rax
00007cc2697dc054  movaps xmm10, [rsp]
00007cc2697dc059  add rsp, 0x40
00007cc2697dc05d  vmovaps xmm0, [rsp]
00007cc2697dc062  vmovaps xmm1, [rsp+0x10]
00007cc2697dc068  vmovaps xmm2, [rsp+0x20]
00007cc2697dc06e  vmovaps xmm3, [rsp+0x30]
00007cc2697dc074  vmovaps xmm4, [rsp+0x40]
00007cc2697dc07a  vmovaps xmm5, [rsp+0x50]
00007cc2697dc080  vmovaps xmm6, [rsp+0x60]
00007cc2697dc086  vmovaps xmm7, [rsp+0x70]
00007cc2697dc08c  vmovaps xmm8, [rsp+0x80]
00007cc2697dc095  vmovaps xmm9, [rsp+0x90]
00007cc2697dc09e  vmovaps xmm11, [rsp+0xA0]
00007cc2697dc0a7  vmovaps xmm12, [rsp+0xB0]
00007cc2697dc0b0  vmovaps xmm13, [rsp+0xC0]
00007cc2697dc0b9  vmovaps xmm14, [rsp+0xD0]
00007cc2697dc0c2  vmovaps xmm15, [rsp+0xE0]
00007cc2697dc0cb  add rsp, 0xF0
00007cc2697dc0d2  pop r11
00007cc2697dc0d4  pop r10
00007cc2697dc0d6  pop r9
00007cc2697dc0d8  pop r8
00007cc2697dc0da  pop rsi
00007cc2697dc0db  pop rdi
00007cc2697dc0dc  pop rdx
00007cc2697dc0dd  pop rcx
00007cc2697dc0de  pop rax
00007cc2697dc0df  add rsp, 0x08
00007cc2697dc0e3  jmp 0x00007CC2697DA3B0
00007cc2697dc0e8  sub rsp, 0x08
00007cc2697dc0ec  push rax
00007cc2697dc0ed  push rcx
00007cc2697dc0ee  push rdx
00007cc2697dc0ef  push rdi
00007cc2697dc0f0  push rsi
00007cc2697dc0f1  push r8
00007cc2697dc0f3  push r9
00007cc2697dc0f5  push r10
00007cc2697dc0f7  push r11
00007cc2697dc0f9  sub rsp, 0xF0
00007cc2697dc100  vmovaps [rsp], xmm0
00007cc2697dc105  vmovaps [rsp+0x10], xmm1
00007cc2697dc10b  vmovaps [rsp+0x20], xmm2
00007cc2697dc111  vmovaps [rsp+0x30], xmm3
00007cc2697dc117  vmovaps [rsp+0x40], xmm4
00007cc2697dc11d  vmovaps [rsp+0x50], xmm5
00007cc2697dc123  vmovaps [rsp+0x60], xmm6
00007cc2697dc129  vmovaps [rsp+0x70], xmm7
00007cc2697dc12f  vmovaps [rsp+0x80], xmm8
00007cc2697dc138  vmovaps [rsp+0x90], xmm9
00007cc2697dc141  vmovaps [rsp+0xA0], xmm10
00007cc2697dc14a  vmovaps [rsp+0xB0], xmm11
00007cc2697dc153  vmovaps [rsp+0xC0], xmm13
00007cc2697dc15c  vmovaps [rsp+0xD0], xmm14
00007cc2697dc165  vmovaps [rsp+0xE0], xmm15
00007cc2697dc16e  sub rsp, 0x40
00007cc2697dc172  lea rdi, [rsp]
00007cc2697dc176  lea rsi, [rsp+0x10]
00007cc2697dc17b  lea rdx, [rsp+0x20]
00007cc2697dc180  lea rcx, [rsp+0x30]
00007cc2697dc185  mov r8d, 0x00
00007cc2697dc18b  lea r9, [r15+0x3A8]
00007cc2697dc192  movaps [rdi], xmm12
00007cc2697dc196  movaps [rsi], xmm7
00007cc2697dc199  movaps [rdx], xmm15
00007cc2697dc19d  movaps [rcx], xmm1
00007cc2697dc1a0  mov rax, 0x653E5FFFBA50
00007cc2697dc1aa  call rax
00007cc2697dc1ac  movaps xmm12, [rsp]
00007cc2697dc1b1  add rsp, 0x40
00007cc2697dc1b5  vmovaps xmm0, [rsp]
00007cc2697dc1ba  vmovaps xmm1, [rsp+0x10]
00007cc2697dc1c0  vmovaps xmm2, [rsp+0x20]
00007cc2697dc1c6  vmovaps xmm3, [rsp+0x30]
00007cc2697dc1cc  vmovaps xmm4, [rsp+0x40]
00007cc2697dc1d2  vmovaps xmm5, [rsp+0x50]
00007cc2697dc1d8  vmovaps xmm6, [rsp+0x60]
00007cc2697dc1de  vmovaps xmm7, [rsp+0x70]
00007cc2697dc1e4  vmovaps xmm8, [rsp+0x80]
00007cc2697dc1ed  vmovaps xmm9, [rsp+0x90]
00007cc2697dc1f6  vmovaps xmm10, [rsp+0xA0]
00007cc2697dc1ff  vmovaps xmm11, [rsp+0xB0]
00007cc2697dc208  vmovaps xmm13, [rsp+0xC0]
00007cc2697dc211  vmovaps xmm14, [rsp+0xD0]
00007cc2697dc21a  vmovaps xmm15, [rsp+0xE0]
00007cc2697dc223  add rsp, 0xF0
00007cc2697dc22a  pop r11
00007cc2697dc22c  pop r10
00007cc2697dc22e  pop r9
00007cc2697dc230  pop r8
00007cc2697dc232  pop rsi
00007cc2697dc233  pop rdi
00007cc2697dc234  pop rdx
00007cc2697dc235  pop rcx
00007cc2697dc236  pop rax
00007cc2697dc237  add rsp, 0x08
00007cc2697dc23b  jmp 0x00007CC2697DA3D9
00007cc2697dc240  call 0x00007CC2695FF430
00007cc2697dc245  jmp 0x00007CC2697DA3E3
00007cc2697dc24a  call 0x00007CC26960E760
00007cc2697dc24f  jmp 0x00007CC2697DA3ED
00007cc2697dc254  sub rsp, 0x08
00007cc2697dc258  push rax
00007cc2697dc259  push rcx
00007cc2697dc25a  push rdx
00007cc2697dc25b  push rdi
00007cc2697dc25c  push rsi
00007cc2697dc25d  push r8
00007cc2697dc25f  push r9
00007cc2697dc261  push r10
00007cc2697dc263  push r11
00007cc2697dc265  sub rsp, 0xF0
00007cc2697dc26c  vmovaps [rsp], xmm0
00007cc2697dc271  vmovaps [rsp+0x10], xmm1
00007cc2697dc277  vmovaps [rsp+0x20], xmm2
00007cc2697dc27d  vmovaps [rsp+0x30], xmm3
00007cc2697dc283  vmovaps [rsp+0x40], xmm4
00007cc2697dc289  vmovaps [rsp+0x50], xmm5
00007cc2697dc28f  vmovaps [rsp+0x60], xmm6
00007cc2697dc295  vmovaps [rsp+0x70], xmm8
00007cc2697dc29b  vmovaps [rsp+0x80], xmm9
00007cc2697dc2a4  vmovaps [rsp+0x90], xmm10
00007cc2697dc2ad  vmovaps [rsp+0xA0], xmm11
00007cc2697dc2b6  vmovaps [rsp+0xB0], xmm12
00007cc2697dc2bf  vmovaps [rsp+0xC0], xmm13
00007cc2697dc2c8  vmovaps [rsp+0xD0], xmm14
00007cc2697dc2d1  vmovaps [rsp+0xE0], xmm15
00007cc2697dc2da  sub rsp, 0x40
00007cc2697dc2de  lea rdi, [rsp]
00007cc2697dc2e2  lea rsi, [rsp+0x10]
00007cc2697dc2e7  lea rdx, [rsp+0x20]
00007cc2697dc2ec  lea rcx, [rsp+0x30]
00007cc2697dc2f1  mov r8d, 0x00
00007cc2697dc2f7  lea r9, [r15+0x3A8]
00007cc2697dc2fe  movaps [rdi], xmm7
00007cc2697dc301  movaps [rsi], xmm2
00007cc2697dc304  movaps [rdx], xmm9
00007cc2697dc308  movaps [rcx], xmm11
00007cc2697dc30c  mov rax, 0x653E5FFFBA50
00007cc2697dc316  call rax
00007cc2697dc318  movaps xmm7, [rsp]
00007cc2697dc31c  add rsp, 0x40
00007cc2697dc320  vmovaps xmm0, [rsp]
00007cc2697dc325  vmovaps xmm1, [rsp+0x10]
00007cc2697dc32b  vmovaps xmm2, [rsp+0x20]
00007cc2697dc331  vmovaps xmm3, [rsp+0x30]
00007cc2697dc337  vmovaps xmm4, [rsp+0x40]
00007cc2697dc33d  vmovaps xmm5, [rsp+0x50]
00007cc2697dc343  vmovaps xmm6, [rsp+0x60]
00007cc2697dc349  vmovaps xmm8, [rsp+0x70]
00007cc2697dc34f  vmovaps xmm9, [rsp+0x80]
00007cc2697dc358  vmovaps xmm10, [rsp+0x90]
00007cc2697dc361  vmovaps xmm11, [rsp+0xA0]
00007cc2697dc36a  vmovaps xmm12, [rsp+0xB0]
00007cc2697dc373  vmovaps xmm13, [rsp+0xC0]
00007cc2697dc37c  vmovaps xmm14, [rsp+0xD0]
00007cc2697dc385  vmovaps xmm15, [rsp+0xE0]
00007cc2697dc38e  add rsp, 0xF0
00007cc2697dc395  pop r11
00007cc2697dc397  pop r10
00007cc2697dc399  pop r9
00007cc2697dc39b  pop r8
00007cc2697dc39d  pop rsi
00007cc2697dc39e  pop rdi
00007cc2697dc39f  pop rdx
00007cc2697dc3a0  pop rcx
00007cc2697dc3a1  pop rax
00007cc2697dc3a2  add rsp, 0x08
00007cc2697dc3a6  jmp 0x00007CC2697DA421
00007cc2697dc3ab  sub rsp, 0x08
00007cc2697dc3af  push rax
00007cc2697dc3b0  push rcx
00007cc2697dc3b1  push rdx
00007cc2697dc3b2  push rdi
00007cc2697dc3b3  push rsi
00007cc2697dc3b4  push r8
00007cc2697dc3b6  push r9
00007cc2697dc3b8  push r10
00007cc2697dc3ba  push r11
00007cc2697dc3bc  sub rsp, 0xF0
00007cc2697dc3c3  vmovaps [rsp], xmm0
00007cc2697dc3c8  vmovaps [rsp+0x10], xmm1
00007cc2697dc3ce  vmovaps [rsp+0x20], xmm2
00007cc2697dc3d4  vmovaps [rsp+0x30], xmm3
00007cc2697dc3da  vmovaps [rsp+0x40], xmm4
00007cc2697dc3e0  vmovaps [rsp+0x50], xmm5
00007cc2697dc3e6  vmovaps [rsp+0x60], xmm6
00007cc2697dc3ec  vmovaps [rsp+0x70], xmm7
00007cc2697dc3f2  vmovaps [rsp+0x80], xmm8
00007cc2697dc3fb  vmovaps [rsp+0x90], xmm10
00007cc2697dc404  vmovaps [rsp+0xA0], xmm11
00007cc2697dc40d  vmovaps [rsp+0xB0], xmm12
00007cc2697dc416  vmovaps [rsp+0xC0], xmm13
00007cc2697dc41f  vmovaps [rsp+0xD0], xmm14
00007cc2697dc428  vmovaps [rsp+0xE0], xmm15
00007cc2697dc431  sub rsp, 0x40
00007cc2697dc435  lea rdi, [rsp]
00007cc2697dc439  lea rsi, [rsp+0x10]
00007cc2697dc43e  lea rdx, [rsp+0x20]
00007cc2697dc443  lea rcx, [rsp+0x30]
00007cc2697dc448  mov r8d, 0x00
00007cc2697dc44e  lea r9, [r15+0x3A8]
00007cc2697dc455  movaps [rdi], xmm9
00007cc2697dc459  movaps [rsi], xmm6
00007cc2697dc45c  movaps [rdx], xmm1
00007cc2697dc45f  movaps [rcx], xmm11
00007cc2697dc463  mov rax, 0x653E5FFFBA50
00007cc2697dc46d  call rax
00007cc2697dc46f  movaps xmm9, [rsp]
00007cc2697dc474  add rsp, 0x40
00007cc2697dc478  vmovaps xmm0, [rsp]
00007cc2697dc47d  vmovaps xmm1, [rsp+0x10]
00007cc2697dc483  vmovaps xmm2, [rsp+0x20]
00007cc2697dc489  vmovaps xmm3, [rsp+0x30]
00007cc2697dc48f  vmovaps xmm4, [rsp+0x40]
00007cc2697dc495  vmovaps xmm5, [rsp+0x50]
00007cc2697dc49b  vmovaps xmm6, [rsp+0x60]
00007cc2697dc4a1  vmovaps xmm7, [rsp+0x70]
00007cc2697dc4a7  vmovaps xmm8, [rsp+0x80]
00007cc2697dc4b0  vmovaps xmm10, [rsp+0x90]
00007cc2697dc4b9  vmovaps xmm11, [rsp+0xA0]
00007cc2697dc4c2  vmovaps xmm12, [rsp+0xB0]
00007cc2697dc4cb  vmovaps xmm13, [rsp+0xC0]
00007cc2697dc4d4  vmovaps xmm14, [rsp+0xD0]
00007cc2697dc4dd  vmovaps xmm15, [rsp+0xE0]
00007cc2697dc4e6  add rsp, 0xF0
00007cc2697dc4ed  pop r11
00007cc2697dc4ef  pop r10
00007cc2697dc4f1  pop r9
00007cc2697dc4f3  pop r8
00007cc2697dc4f5  pop rsi
00007cc2697dc4f6  pop rdi
00007cc2697dc4f7  pop rdx
00007cc2697dc4f8  pop rcx
00007cc2697dc4f9  pop rax
00007cc2697dc4fa  add rsp, 0x08
00007cc2697dc4fe  jmp 0x00007CC2697DA447
00007cc2697dc503  sub rsp, 0x08
00007cc2697dc507  push rax
00007cc2697dc508  push rcx
00007cc2697dc509  push rdx
00007cc2697dc50a  push rdi
00007cc2697dc50b  push rsi
00007cc2697dc50c  push r8
00007cc2697dc50e  push r9
00007cc2697dc510  push r10
00007cc2697dc512  push r11
00007cc2697dc514  sub rsp, 0xF0
00007cc2697dc51b  vmovaps [rsp], xmm0
00007cc2697dc520  vmovaps [rsp+0x10], xmm1
00007cc2697dc526  vmovaps [rsp+0x20], xmm2
00007cc2697dc52c  vmovaps [rsp+0x30], xmm3
00007cc2697dc532  vmovaps [rsp+0x40], xmm4
00007cc2697dc538  vmovaps [rsp+0x50], xmm5
00007cc2697dc53e  vmovaps [rsp+0x60], xmm6
00007cc2697dc544  vmovaps [rsp+0x70], xmm7
00007cc2697dc54a  vmovaps [rsp+0x80], xmm8
00007cc2697dc553  vmovaps [rsp+0x90], xmm9
00007cc2697dc55c  vmovaps [rsp+0xA0], xmm10
00007cc2697dc565  vmovaps [rsp+0xB0], xmm12
00007cc2697dc56e  vmovaps [rsp+0xC0], xmm13
00007cc2697dc577  vmovaps [rsp+0xD0], xmm14
00007cc2697dc580  vmovaps [rsp+0xE0], xmm15
00007cc2697dc589  sub rsp, 0x40
00007cc2697dc58d  lea rdi, [rsp]
00007cc2697dc591  lea rsi, [rsp+0x10]
00007cc2697dc596  lea rdx, [rsp+0x20]
00007cc2697dc59b  lea rcx, [rsp+0x30]
00007cc2697dc5a0  mov r8d, 0x00
00007cc2697dc5a6  lea r9, [r15+0x3A8]
00007cc2697dc5ad  movaps [rdi], xmm11
00007cc2697dc5b1  movaps [rsi], xmm10
00007cc2697dc5b5  movaps [rdx], xmm8
00007cc2697dc5b9  movaps [rcx], xmm1
00007cc2697dc5bc  mov rax, 0x653E5FFFBA50
00007cc2697dc5c6  call rax
00007cc2697dc5c8  movaps xmm11, [rsp]
00007cc2697dc5cd  add rsp, 0x40
00007cc2697dc5d1  vmovaps xmm0, [rsp]
00007cc2697dc5d6  vmovaps xmm1, [rsp+0x10]
00007cc2697dc5dc  vmovaps xmm2, [rsp+0x20]
00007cc2697dc5e2  vmovaps xmm3, [rsp+0x30]
00007cc2697dc5e8  vmovaps xmm4, [rsp+0x40]
00007cc2697dc5ee  vmovaps xmm5, [rsp+0x50]
00007cc2697dc5f4  vmovaps xmm6, [rsp+0x60]
00007cc2697dc5fa  vmovaps xmm7, [rsp+0x70]
00007cc2697dc600  vmovaps xmm8, [rsp+0x80]
00007cc2697dc609  vmovaps xmm9, [rsp+0x90]
00007cc2697dc612  vmovaps xmm10, [rsp+0xA0]
00007cc2697dc61b  vmovaps xmm12, [rsp+0xB0]
00007cc2697dc624  vmovaps xmm13, [rsp+0xC0]
00007cc2697dc62d  vmovaps xmm14, [rsp+0xD0]
00007cc2697dc636  vmovaps xmm15, [rsp+0xE0]
00007cc2697dc63f  add rsp, 0xF0
00007cc2697dc646  pop r11
00007cc2697dc648  pop r10
00007cc2697dc64a  pop r9
00007cc2697dc64c  pop r8
00007cc2697dc64e  pop rsi
00007cc2697dc64f  pop rdi
00007cc2697dc650  pop rdx
00007cc2697dc651  pop rcx
00007cc2697dc652  pop rax
00007cc2697dc653  add rsp, 0x08
00007cc2697dc657  jmp 0x00007CC2697DA46D
00007cc2697dc65c  sub rsp, 0x08
00007cc2697dc660  push rax
00007cc2697dc661  push rcx
00007cc2697dc662  push rdx
00007cc2697dc663  push rdi
00007cc2697dc664  push rsi
00007cc2697dc665  push r8
00007cc2697dc667  push r9
00007cc2697dc669  push r10
00007cc2697dc66b  push r11
00007cc2697dc66d  sub rsp, 0xF0
00007cc2697dc674  vmovaps [rsp], xmm0
00007cc2697dc679  vmovaps [rsp+0x10], xmm1
00007cc2697dc67f  vmovaps [rsp+0x20], xmm2
00007cc2697dc685  vmovaps [rsp+0x30], xmm3
00007cc2697dc68b  vmovaps [rsp+0x40], xmm4
00007cc2697dc691  vmovaps [rsp+0x50], xmm5
00007cc2697dc697  vmovaps [rsp+0x60], xmm6
00007cc2697dc69d  vmovaps [rsp+0x70], xmm7
00007cc2697dc6a3  vmovaps [rsp+0x80], xmm8
00007cc2697dc6ac  vmovaps [rsp+0x90], xmm9
00007cc2697dc6b5  vmovaps [rsp+0xA0], xmm11
00007cc2697dc6be  vmovaps [rsp+0xB0], xmm12
00007cc2697dc6c7  vmovaps [rsp+0xC0], xmm13
00007cc2697dc6d0  vmovaps [rsp+0xD0], xmm14
00007cc2697dc6d9  vmovaps [rsp+0xE0], xmm15
00007cc2697dc6e2  sub rsp, 0x40
00007cc2697dc6e6  lea rdi, [rsp]
00007cc2697dc6ea  lea rsi, [rsp+0x10]
00007cc2697dc6ef  lea rdx, [rsp+0x20]
00007cc2697dc6f4  lea rcx, [rsp+0x30]
00007cc2697dc6f9  mov r8d, 0x00
00007cc2697dc6ff  lea r9, [r15+0x3A8]
00007cc2697dc706  movaps [rdi], xmm10
00007cc2697dc70a  movaps [rsi], xmm12
00007cc2697dc70e  movaps [rdx], xmm13
00007cc2697dc712  movaps [rcx], xmm1
00007cc2697dc715  mov rax, 0x653E5FFFBA50
00007cc2697dc71f  call rax
00007cc2697dc721  movaps xmm10, [rsp]
00007cc2697dc726  add rsp, 0x40
00007cc2697dc72a  vmovaps xmm0, [rsp]
00007cc2697dc72f  vmovaps xmm1, [rsp+0x10]
00007cc2697dc735  vmovaps xmm2, [rsp+0x20]
00007cc2697dc73b  vmovaps xmm3, [rsp+0x30]
00007cc2697dc741  vmovaps xmm4, [rsp+0x40]
00007cc2697dc747  vmovaps xmm5, [rsp+0x50]
00007cc2697dc74d  vmovaps xmm6, [rsp+0x60]
00007cc2697dc753  vmovaps xmm7, [rsp+0x70]
00007cc2697dc759  vmovaps xmm8, [rsp+0x80]
00007cc2697dc762  vmovaps xmm9, [rsp+0x90]
00007cc2697dc76b  vmovaps xmm11, [rsp+0xA0]
00007cc2697dc774  vmovaps xmm12, [rsp+0xB0]
00007cc2697dc77d  vmovaps xmm13, [rsp+0xC0]
00007cc2697dc786  vmovaps xmm14, [rsp+0xD0]
00007cc2697dc78f  vmovaps xmm15, [rsp+0xE0]
00007cc2697dc798  add rsp, 0xF0
00007cc2697dc79f  pop r11
00007cc2697dc7a1  pop r10
00007cc2697dc7a3  pop r9
00007cc2697dc7a5  pop r8
00007cc2697dc7a7  pop rsi
00007cc2697dc7a8  pop rdi
00007cc2697dc7a9  pop rdx
00007cc2697dc7aa  pop rcx
00007cc2697dc7ab  pop rax
00007cc2697dc7ac  add rsp, 0x08
00007cc2697dc7b0  jmp 0x00007CC2697DA493
00007cc2697dc7b5  call 0x00007CC2695FF430
00007cc2697dc7ba  jmp 0x00007CC2697DA49D
00007cc2697dc7bf  call 0x00007CC26960C260
00007cc2697dc7c4  jmp 0x00007CC2697DA4A7
00007cc2697dc7c9  sub rsp, 0x08
00007cc2697dc7cd  push rax
00007cc2697dc7ce  push rcx
00007cc2697dc7cf  push rdx
00007cc2697dc7d0  push rdi
00007cc2697dc7d1  push rsi
00007cc2697dc7d2  push r8
00007cc2697dc7d4  push r9
00007cc2697dc7d6  push r10
00007cc2697dc7d8  push r11
00007cc2697dc7da  sub rsp, 0xF0
00007cc2697dc7e1  vmovaps [rsp], xmm0
00007cc2697dc7e6  vmovaps [rsp+0x10], xmm1
00007cc2697dc7ec  vmovaps [rsp+0x20], xmm2
00007cc2697dc7f2  vmovaps [rsp+0x30], xmm3
00007cc2697dc7f8  vmovaps [rsp+0x40], xmm4
00007cc2697dc7fe  vmovaps [rsp+0x50], xmm5
00007cc2697dc804  vmovaps [rsp+0x60], xmm6
00007cc2697dc80a  vmovaps [rsp+0x70], xmm7
00007cc2697dc810  vmovaps [rsp+0x80], xmm9
00007cc2697dc819  vmovaps [rsp+0x90], xmm10
00007cc2697dc822  vmovaps [rsp+0xA0], xmm11
00007cc2697dc82b  vmovaps [rsp+0xB0], xmm12
00007cc2697dc834  vmovaps [rsp+0xC0], xmm13
00007cc2697dc83d  vmovaps [rsp+0xD0], xmm14
00007cc2697dc846  vmovaps [rsp+0xE0], xmm15
00007cc2697dc84f  sub rsp, 0x40
00007cc2697dc853  lea rdi, [rsp]
00007cc2697dc857  lea rsi, [rsp+0x10]
00007cc2697dc85c  lea rdx, [rsp+0x20]
00007cc2697dc861  lea rcx, [rsp+0x30]
00007cc2697dc866  mov r8d, 0x00
00007cc2697dc86c  lea r9, [r15+0x3A8]
00007cc2697dc873  movaps [rdi], xmm8
00007cc2697dc877  movaps [rsi], xmm7
00007cc2697dc87a  movaps [rdx], xmm4
00007cc2697dc87d  movaps [rcx], xmm12
00007cc2697dc881  mov rax, 0x653E5FFFBA50
00007cc2697dc88b  call rax
00007cc2697dc88d  movaps xmm8, [rsp]
00007cc2697dc892  add rsp, 0x40
00007cc2697dc896  vmovaps xmm0, [rsp]
00007cc2697dc89b  vmovaps xmm1, [rsp+0x10]
00007cc2697dc8a1  vmovaps xmm2, [rsp+0x20]
00007cc2697dc8a7  vmovaps xmm3, [rsp+0x30]
00007cc2697dc8ad  vmovaps xmm4, [rsp+0x40]
00007cc2697dc8b3  vmovaps xmm5, [rsp+0x50]
00007cc2697dc8b9  vmovaps xmm6, [rsp+0x60]
00007cc2697dc8bf  vmovaps xmm7, [rsp+0x70]
00007cc2697dc8c5  vmovaps xmm9, [rsp+0x80]
00007cc2697dc8ce  vmovaps xmm10, [rsp+0x90]
00007cc2697dc8d7  vmovaps xmm11, [rsp+0xA0]
00007cc2697dc8e0  vmovaps xmm12, [rsp+0xB0]
00007cc2697dc8e9  vmovaps xmm13, [rsp+0xC0]
00007cc2697dc8f2  vmovaps xmm14, [rsp+0xD0]
00007cc2697dc8fb  vmovaps xmm15, [rsp+0xE0]
00007cc2697dc904  add rsp, 0xF0
00007cc2697dc90b  pop r11
00007cc2697dc90d  pop r10
00007cc2697dc90f  pop r9
00007cc2697dc911  pop r8
00007cc2697dc913  pop rsi
00007cc2697dc914  pop rdi
00007cc2697dc915  pop rdx
00007cc2697dc916  pop rcx
00007cc2697dc917  pop rax
00007cc2697dc918  add rsp, 0x08
00007cc2697dc91c  jmp 0x00007CC2697DA4D0
00007cc2697dc921  sub rsp, 0x08
00007cc2697dc925  push rax
00007cc2697dc926  push rcx
00007cc2697dc927  push rdx
00007cc2697dc928  push rdi
00007cc2697dc929  push rsi
00007cc2697dc92a  push r8
00007cc2697dc92c  push r9
00007cc2697dc92e  push r10
00007cc2697dc930  push r11
00007cc2697dc932  sub rsp, 0xF0
00007cc2697dc939  vmovaps [rsp], xmm0
00007cc2697dc93e  vmovaps [rsp+0x10], xmm1
00007cc2697dc944  vmovaps [rsp+0x20], xmm2
00007cc2697dc94a  vmovaps [rsp+0x30], xmm3
00007cc2697dc950  vmovaps [rsp+0x40], xmm4
00007cc2697dc956  vmovaps [rsp+0x50], xmm5
00007cc2697dc95c  vmovaps [rsp+0x60], xmm6
00007cc2697dc962  vmovaps [rsp+0x70], xmm8
00007cc2697dc968  vmovaps [rsp+0x80], xmm9
00007cc2697dc971  vmovaps [rsp+0x90], xmm10
00007cc2697dc97a  vmovaps [rsp+0xA0], xmm11
00007cc2697dc983  vmovaps [rsp+0xB0], xmm12
00007cc2697dc98c  vmovaps [rsp+0xC0], xmm13
00007cc2697dc995  vmovaps [rsp+0xD0], xmm14
00007cc2697dc99e  vmovaps [rsp+0xE0], xmm15
00007cc2697dc9a7  sub rsp, 0x40
00007cc2697dc9ab  lea rdi, [rsp]
00007cc2697dc9af  lea rsi, [rsp+0x10]
00007cc2697dc9b4  lea rdx, [rsp+0x20]
00007cc2697dc9b9  lea rcx, [rsp+0x30]
00007cc2697dc9be  mov r8d, 0x00
00007cc2697dc9c4  lea r9, [r15+0x3A8]
00007cc2697dc9cb  movaps [rdi], xmm7
00007cc2697dc9ce  movaps [rsi], xmm9
00007cc2697dc9d2  movaps [rdx], xmm14
00007cc2697dc9d6  movaps [rcx], xmm12
00007cc2697dc9da  mov rax, 0x653E5FFFBA50
00007cc2697dc9e4  call rax
00007cc2697dc9e6  movaps xmm7, [rsp]
00007cc2697dc9ea  add rsp, 0x40
00007cc2697dc9ee  vmovaps xmm0, [rsp]
00007cc2697dc9f3  vmovaps xmm1, [rsp+0x10]
00007cc2697dc9f9  vmovaps xmm2, [rsp+0x20]
00007cc2697dc9ff  vmovaps xmm3, [rsp+0x30]
00007cc2697dca05  vmovaps xmm4, [rsp+0x40]
00007cc2697dca0b  vmovaps xmm5, [rsp+0x50]
00007cc2697dca11  vmovaps xmm6, [rsp+0x60]
00007cc2697dca17  vmovaps xmm8, [rsp+0x70]
00007cc2697dca1d  vmovaps xmm9, [rsp+0x80]
00007cc2697dca26  vmovaps xmm10, [rsp+0x90]
00007cc2697dca2f  vmovaps xmm11, [rsp+0xA0]
00007cc2697dca38  vmovaps xmm12, [rsp+0xB0]
00007cc2697dca41  vmovaps xmm13, [rsp+0xC0]
00007cc2697dca4a  vmovaps xmm14, [rsp+0xD0]
00007cc2697dca53  vmovaps xmm15, [rsp+0xE0]
00007cc2697dca5c  add rsp, 0xF0
00007cc2697dca63  pop r11
00007cc2697dca65  pop r10
00007cc2697dca67  pop r9
00007cc2697dca69  pop r8
00007cc2697dca6b  pop rsi
00007cc2697dca6c  pop rdi
00007cc2697dca6d  pop rdx
00007cc2697dca6e  pop rcx
00007cc2697dca6f  pop rax
00007cc2697dca70  add rsp, 0x08
00007cc2697dca74  jmp 0x00007CC2697DA4F8
00007cc2697dca79  sub rsp, 0x08
00007cc2697dca7d  push rax
00007cc2697dca7e  push rcx
00007cc2697dca7f  push rdx
00007cc2697dca80  push rdi
00007cc2697dca81  push rsi
00007cc2697dca82  push r8
00007cc2697dca84  push r9
00007cc2697dca86  push r10
00007cc2697dca88  push r11
00007cc2697dca8a  sub rsp, 0xF0
00007cc2697dca91  vmovaps [rsp], xmm0
00007cc2697dca96  vmovaps [rsp+0x10], xmm1
00007cc2697dca9c  vmovaps [rsp+0x20], xmm2
00007cc2697dcaa2  vmovaps [rsp+0x30], xmm3
00007cc2697dcaa8  vmovaps [rsp+0x40], xmm4
00007cc2697dcaae  vmovaps [rsp+0x50], xmm5
00007cc2697dcab4  vmovaps [rsp+0x60], xmm6
00007cc2697dcaba  vmovaps [rsp+0x70], xmm7
00007cc2697dcac0  vmovaps [rsp+0x80], xmm8
00007cc2697dcac9  vmovaps [rsp+0x90], xmm9
00007cc2697dcad2  vmovaps [rsp+0xA0], xmm10
00007cc2697dcadb  vmovaps [rsp+0xB0], xmm11
00007cc2697dcae4  vmovaps [rsp+0xC0], xmm13
00007cc2697dcaed  vmovaps [rsp+0xD0], xmm14
00007cc2697dcaf6  vmovaps [rsp+0xE0], xmm15
00007cc2697dcaff  sub rsp, 0x40
00007cc2697dcb03  lea rdi, [rsp]
00007cc2697dcb07  lea rsi, [rsp+0x10]
00007cc2697dcb0c  lea rdx, [rsp+0x20]
00007cc2697dcb11  lea rcx, [rsp+0x30]
00007cc2697dcb16  mov r8d, 0x00
00007cc2697dcb1c  lea r9, [r15+0x3A8]
00007cc2697dcb23  movaps [rdi], xmm12
00007cc2697dcb27  movaps [rsi], xmm11
00007cc2697dcb2b  movaps [rdx], xmm15
00007cc2697dcb2f  movaps [rcx], xmm14
00007cc2697dcb33  mov rax, 0x653E5FFFBA50
00007cc2697dcb3d  call rax
00007cc2697dcb3f  movaps xmm12, [rsp]
00007cc2697dcb44  add rsp, 0x40
00007cc2697dcb48  vmovaps xmm0, [rsp]
00007cc2697dcb4d  vmovaps xmm1, [rsp+0x10]
00007cc2697dcb53  vmovaps xmm2, [rsp+0x20]
00007cc2697dcb59  vmovaps xmm3, [rsp+0x30]
00007cc2697dcb5f  vmovaps xmm4, [rsp+0x40]
00007cc2697dcb65  vmovaps xmm5, [rsp+0x50]
00007cc2697dcb6b  vmovaps xmm6, [rsp+0x60]
00007cc2697dcb71  vmovaps xmm7, [rsp+0x70]
00007cc2697dcb77  vmovaps xmm8, [rsp+0x80]
00007cc2697dcb80  vmovaps xmm9, [rsp+0x90]
00007cc2697dcb89  vmovaps xmm10, [rsp+0xA0]
00007cc2697dcb92  vmovaps xmm11, [rsp+0xB0]
00007cc2697dcb9b  vmovaps xmm13, [rsp+0xC0]
00007cc2697dcba4  vmovaps xmm14, [rsp+0xD0]
00007cc2697dcbad  vmovaps xmm15, [rsp+0xE0]
00007cc2697dcbb6  add rsp, 0xF0
00007cc2697dcbbd  pop r11
00007cc2697dcbbf  pop r10
00007cc2697dcbc1  pop r9
00007cc2697dcbc3  pop r8
00007cc2697dcbc5  pop rsi
00007cc2697dcbc6  pop rdi
00007cc2697dcbc7  pop rdx
00007cc2697dcbc8  pop rcx
00007cc2697dcbc9  pop rax
00007cc2697dcbca  add rsp, 0x08
00007cc2697dcbce  jmp 0x00007CC2697DA521
00007cc2697dcbd3  sub rsp, 0x08
00007cc2697dcbd7  push rax
00007cc2697dcbd8  push rcx
00007cc2697dcbd9  push rdx
00007cc2697dcbda  push rdi
00007cc2697dcbdb  push rsi
00007cc2697dcbdc  push r8
00007cc2697dcbde  push r9
00007cc2697dcbe0  push r10
00007cc2697dcbe2  push r11
00007cc2697dcbe4  sub rsp, 0xF0
00007cc2697dcbeb  vmovaps [rsp], xmm0
00007cc2697dcbf0  vmovaps [rsp+0x10], xmm1
00007cc2697dcbf6  vmovaps [rsp+0x20], xmm2
00007cc2697dcbfc  vmovaps [rsp+0x30], xmm3
00007cc2697dcc02  vmovaps [rsp+0x40], xmm4
00007cc2697dcc08  vmovaps [rsp+0x50], xmm5
00007cc2697dcc0e  vmovaps [rsp+0x60], xmm6
00007cc2697dcc14  vmovaps [rsp+0x70], xmm7
00007cc2697dcc1a  vmovaps [rsp+0x80], xmm8
00007cc2697dcc23  vmovaps [rsp+0x90], xmm9
00007cc2697dcc2c  vmovaps [rsp+0xA0], xmm10
00007cc2697dcc35  vmovaps [rsp+0xB0], xmm12
00007cc2697dcc3e  vmovaps [rsp+0xC0], xmm13
00007cc2697dcc47  vmovaps [rsp+0xD0], xmm14
00007cc2697dcc50  vmovaps [rsp+0xE0], xmm15
00007cc2697dcc59  sub rsp, 0x40
00007cc2697dcc5d  lea rdi, [rsp]
00007cc2697dcc61  lea rsi, [rsp+0x10]
00007cc2697dcc66  lea rdx, [rsp+0x20]
00007cc2697dcc6b  lea rcx, [rsp+0x30]
00007cc2697dcc70  mov r8d, 0x00
00007cc2697dcc76  lea r9, [r15+0x3A8]
00007cc2697dcc7d  movaps [rdi], xmm11
00007cc2697dcc81  movaps [rsi], xmm10
00007cc2697dcc85  movaps [rdx], xmm13
00007cc2697dcc89  movaps [rcx], xmm15
00007cc2697dcc8d  mov rax, 0x653E5FFFBA50
00007cc2697dcc97  call rax
00007cc2697dcc99  movaps xmm11, [rsp]
00007cc2697dcc9e  add rsp, 0x40
00007cc2697dcca2  vmovaps xmm0, [rsp]
00007cc2697dcca7  vmovaps xmm1, [rsp+0x10]
00007cc2697dccad  vmovaps xmm2, [rsp+0x20]
00007cc2697dccb3  vmovaps xmm3, [rsp+0x30]
00007cc2697dccb9  vmovaps xmm4, [rsp+0x40]
00007cc2697dccbf  vmovaps xmm5, [rsp+0x50]
00007cc2697dccc5  vmovaps xmm6, [rsp+0x60]
00007cc2697dcccb  vmovaps xmm7, [rsp+0x70]
00007cc2697dccd1  vmovaps xmm8, [rsp+0x80]
00007cc2697dccda  vmovaps xmm9, [rsp+0x90]
00007cc2697dcce3  vmovaps xmm10, [rsp+0xA0]
00007cc2697dccec  vmovaps xmm12, [rsp+0xB0]
00007cc2697dccf5  vmovaps xmm13, [rsp+0xC0]
00007cc2697dccfe  vmovaps xmm14, [rsp+0xD0]
00007cc2697dcd07  vmovaps xmm15, [rsp+0xE0]
00007cc2697dcd10  add rsp, 0xF0
00007cc2697dcd17  pop r11
00007cc2697dcd19  pop r10
00007cc2697dcd1b  pop r9
00007cc2697dcd1d  pop r8
00007cc2697dcd1f  pop rsi
00007cc2697dcd20  pop rdi
00007cc2697dcd21  pop rdx
00007cc2697dcd22  pop rcx
00007cc2697dcd23  pop rax
00007cc2697dcd24  add rsp, 0x08
00007cc2697dcd28  jmp 0x00007CC2697DA54A
00007cc2697dcd2d  call 0x00007CC26960E760
00007cc2697dcd32  jmp 0x00007CC2697DA557
00007cc2697dcd37  call 0x00007CC26960D4E0
00007cc2697dcd3c  jmp 0x00007CC2697DA564
00007cc2697dcd41  sub rsp, 0x08
00007cc2697dcd45  push rax
00007cc2697dcd46  push rcx
00007cc2697dcd47  push rdx
00007cc2697dcd48  push rdi
00007cc2697dcd49  push rsi
00007cc2697dcd4a  push r8
00007cc2697dcd4c  push r9
00007cc2697dcd4e  push r10
00007cc2697dcd50  push r11
00007cc2697dcd52  sub rsp, 0xF0
00007cc2697dcd59  vmovaps [rsp], xmm0
00007cc2697dcd5e  vmovaps [rsp+0x10], xmm1
00007cc2697dcd64  vmovaps [rsp+0x20], xmm2
00007cc2697dcd6a  vmovaps [rsp+0x30], xmm3
00007cc2697dcd70  vmovaps [rsp+0x40], xmm4
00007cc2697dcd76  vmovaps [rsp+0x50], xmm5
00007cc2697dcd7c  vmovaps [rsp+0x60], xmm6
00007cc2697dcd82  vmovaps [rsp+0x70], xmm7
00007cc2697dcd88  vmovaps [rsp+0x80], xmm8
00007cc2697dcd91  vmovaps [rsp+0x90], xmm9
00007cc2697dcd9a  vmovaps [rsp+0xA0], xmm11
00007cc2697dcda3  vmovaps [rsp+0xB0], xmm12
00007cc2697dcdac  vmovaps [rsp+0xC0], xmm13
00007cc2697dcdb5  vmovaps [rsp+0xD0], xmm14
00007cc2697dcdbe  vmovaps [rsp+0xE0], xmm15
00007cc2697dcdc7  sub rsp, 0x40
00007cc2697dcdcb  lea rdi, [rsp]
00007cc2697dcdcf  lea rsi, [rsp+0x10]
00007cc2697dcdd4  lea rdx, [rsp+0x20]
00007cc2697dcdd9  lea rcx, [rsp+0x30]
00007cc2697dcdde  mov r8d, 0x00
00007cc2697dcde4  lea r9, [r15+0x3A8]
00007cc2697dcdeb  movaps [rdi], xmm10
00007cc2697dcdef  movaps [rsi], xmm8
00007cc2697dcdf3  movaps [rdx], xmm1
00007cc2697dcdf6  movaps [rcx], xmm13
00007cc2697dcdfa  mov rax, 0x653E5FFFBA50
00007cc2697dce04  call rax
00007cc2697dce06  movaps xmm10, [rsp]
00007cc2697dce0b  add rsp, 0x40
00007cc2697dce0f  vmovaps xmm0, [rsp]
00007cc2697dce14  vmovaps xmm1, [rsp+0x10]
00007cc2697dce1a  vmovaps xmm2, [rsp+0x20]
00007cc2697dce20  vmovaps xmm3, [rsp+0x30]
00007cc2697dce26  vmovaps xmm4, [rsp+0x40]
00007cc2697dce2c  vmovaps xmm5, [rsp+0x50]
00007cc2697dce32  vmovaps xmm6, [rsp+0x60]
00007cc2697dce38  vmovaps xmm7, [rsp+0x70]
00007cc2697dce3e  vmovaps xmm8, [rsp+0x80]
00007cc2697dce47  vmovaps xmm9, [rsp+0x90]
00007cc2697dce50  vmovaps xmm11, [rsp+0xA0]
00007cc2697dce59  vmovaps xmm12, [rsp+0xB0]
00007cc2697dce62  vmovaps xmm13, [rsp+0xC0]
00007cc2697dce6b  vmovaps xmm14, [rsp+0xD0]
00007cc2697dce74  vmovaps xmm15, [rsp+0xE0]
00007cc2697dce7d  add rsp, 0xF0
00007cc2697dce84  pop r11
00007cc2697dce86  pop r10
00007cc2697dce88  pop r9
00007cc2697dce8a  pop r8
00007cc2697dce8c  pop rsi
00007cc2697dce8d  pop rdi
00007cc2697dce8e  pop rdx
00007cc2697dce8f  pop rcx
00007cc2697dce90  pop rax
00007cc2697dce91  add rsp, 0x08
00007cc2697dce95  jmp 0x00007CC2697DA59A
00007cc2697dce9a  call 0x00007CC2695FF430
00007cc2697dce9f  jmp 0x00007CC2697DA5AC
00007cc2697dcea4  sub rsp, 0x08
00007cc2697dcea8  push rax
00007cc2697dcea9  push rcx
00007cc2697dceaa  push rdx
00007cc2697dceab  push rdi
00007cc2697dceac  push rsi
00007cc2697dcead  push r8
00007cc2697dceaf  push r9
00007cc2697dceb1  push r10
00007cc2697dceb3  push r11
00007cc2697dceb5  sub rsp, 0xF0
00007cc2697dcebc  vmovaps [rsp], xmm0
00007cc2697dcec1  vmovaps [rsp+0x10], xmm1
00007cc2697dcec7  vmovaps [rsp+0x20], xmm2
00007cc2697dcecd  vmovaps [rsp+0x30], xmm3
00007cc2697dced3  vmovaps [rsp+0x40], xmm4
00007cc2697dced9  vmovaps [rsp+0x50], xmm5
00007cc2697dcedf  vmovaps [rsp+0x60], xmm6
00007cc2697dcee5  vmovaps [rsp+0x70], xmm7
00007cc2697dceeb  vmovaps [rsp+0x80], xmm8
00007cc2697dcef4  vmovaps [rsp+0x90], xmm10
00007cc2697dcefd  vmovaps [rsp+0xA0], xmm11
00007cc2697dcf06  vmovaps [rsp+0xB0], xmm12
00007cc2697dcf0f  vmovaps [rsp+0xC0], xmm13
00007cc2697dcf18  vmovaps [rsp+0xD0], xmm14
00007cc2697dcf21  vmovaps [rsp+0xE0], xmm15
00007cc2697dcf2a  sub rsp, 0x40
00007cc2697dcf2e  lea rdi, [rsp]
00007cc2697dcf32  lea rsi, [rsp+0x10]
00007cc2697dcf37  lea rdx, [rsp+0x20]
00007cc2697dcf3c  lea rcx, [rsp+0x30]
00007cc2697dcf41  mov r8d, 0x00
00007cc2697dcf47  lea r9, [r15+0x3A8]
00007cc2697dcf4e  movaps [rdi], xmm9
00007cc2697dcf52  movaps [rsi], xmm7
00007cc2697dcf55  movaps [rdx], xmm14
00007cc2697dcf59  movaps [rcx], xmm13
00007cc2697dcf5d  mov rax, 0x653E5FFFBA50
00007cc2697dcf67  call rax
00007cc2697dcf69  movaps xmm9, [rsp]
00007cc2697dcf6e  add rsp, 0x40
00007cc2697dcf72  vmovaps xmm0, [rsp]
00007cc2697dcf77  vmovaps xmm1, [rsp+0x10]
00007cc2697dcf7d  vmovaps xmm2, [rsp+0x20]
00007cc2697dcf83  vmovaps xmm3, [rsp+0x30]
00007cc2697dcf89  vmovaps xmm4, [rsp+0x40]
00007cc2697dcf8f  vmovaps xmm5, [rsp+0x50]
00007cc2697dcf95  vmovaps xmm6, [rsp+0x60]
00007cc2697dcf9b  vmovaps xmm7, [rsp+0x70]
00007cc2697dcfa1  vmovaps xmm8, [rsp+0x80]
00007cc2697dcfaa  vmovaps xmm10, [rsp+0x90]
00007cc2697dcfb3  vmovaps xmm11, [rsp+0xA0]
00007cc2697dcfbc  vmovaps xmm12, [rsp+0xB0]
00007cc2697dcfc5  vmovaps xmm13, [rsp+0xC0]
00007cc2697dcfce  vmovaps xmm14, [rsp+0xD0]
00007cc2697dcfd7  vmovaps xmm15, [rsp+0xE0]
00007cc2697dcfe0  add rsp, 0xF0
00007cc2697dcfe7  pop r11
00007cc2697dcfe9  pop r10
00007cc2697dcfeb  pop r9
00007cc2697dcfed  pop r8
00007cc2697dcfef  pop rsi
00007cc2697dcff0  pop rdi
00007cc2697dcff1  pop rdx
00007cc2697dcff2  pop rcx
00007cc2697dcff3  pop rax
00007cc2697dcff4  add rsp, 0x08
00007cc2697dcff8  jmp 0x00007CC2697DA5DA
00007cc2697dcffd  sub rsp, 0x08
00007cc2697dd001  push rax
00007cc2697dd002  push rcx
00007cc2697dd003  push rdx
00007cc2697dd004  push rdi
00007cc2697dd005  push rsi
00007cc2697dd006  push r8
00007cc2697dd008  push r9
00007cc2697dd00a  push r10
00007cc2697dd00c  push r11
00007cc2697dd00e  sub rsp, 0xF0
00007cc2697dd015  vmovaps [rsp], xmm0
00007cc2697dd01a  vmovaps [rsp+0x10], xmm1
00007cc2697dd020  vmovaps [rsp+0x20], xmm2
00007cc2697dd026  vmovaps [rsp+0x30], xmm3
00007cc2697dd02c  vmovaps [rsp+0x40], xmm4
00007cc2697dd032  vmovaps [rsp+0x50], xmm5
00007cc2697dd038  vmovaps [rsp+0x60], xmm6
00007cc2697dd03e  vmovaps [rsp+0x70], xmm7
00007cc2697dd044  vmovaps [rsp+0x80], xmm8
00007cc2697dd04d  vmovaps [rsp+0x90], xmm9
00007cc2697dd056  vmovaps [rsp+0xA0], xmm10
00007cc2697dd05f  vmovaps [rsp+0xB0], xmm11
00007cc2697dd068  vmovaps [rsp+0xC0], xmm12
00007cc2697dd071  vmovaps [rsp+0xD0], xmm14
00007cc2697dd07a  vmovaps [rsp+0xE0], xmm15
00007cc2697dd083  sub rsp, 0x40
00007cc2697dd087  lea rdi, [rsp]
00007cc2697dd08b  lea rsi, [rsp+0x10]
00007cc2697dd090  lea rdx, [rsp+0x20]
00007cc2697dd095  lea rcx, [rsp+0x30]
00007cc2697dd09a  mov r8d, 0x00
00007cc2697dd0a0  lea r9, [r15+0x3A8]
00007cc2697dd0a7  movaps [rdi], xmm13
00007cc2697dd0ab  movaps [rsi], xmm12
00007cc2697dd0af  movaps [rdx], xmm15
00007cc2697dd0b3  movaps [rcx], xmm14
00007cc2697dd0b7  mov rax, 0x653E5FFFBA50
00007cc2697dd0c1  call rax
00007cc2697dd0c3  movaps xmm13, [rsp]
00007cc2697dd0c8  add rsp, 0x40
00007cc2697dd0cc  vmovaps xmm0, [rsp]
00007cc2697dd0d1  vmovaps xmm1, [rsp+0x10]
00007cc2697dd0d7  vmovaps xmm2, [rsp+0x20]
00007cc2697dd0dd  vmovaps xmm3, [rsp+0x30]
00007cc2697dd0e3  vmovaps xmm4, [rsp+0x40]
00007cc2697dd0e9  vmovaps xmm5, [rsp+0x50]
00007cc2697dd0ef  vmovaps xmm6, [rsp+0x60]
00007cc2697dd0f5  vmovaps xmm7, [rsp+0x70]
00007cc2697dd0fb  vmovaps xmm8, [rsp+0x80]
00007cc2697dd104  vmovaps xmm9, [rsp+0x90]
00007cc2697dd10d  vmovaps xmm10, [rsp+0xA0]
00007cc2697dd116  vmovaps xmm11, [rsp+0xB0]
00007cc2697dd11f  vmovaps xmm12, [rsp+0xC0]
00007cc2697dd128  vmovaps xmm14, [rsp+0xD0]
00007cc2697dd131  vmovaps xmm15, [rsp+0xE0]
00007cc2697dd13a  add rsp, 0xF0
00007cc2697dd141  pop r11
00007cc2697dd143  pop r10
00007cc2697dd145  pop r9
00007cc2697dd147  pop r8
00007cc2697dd149  pop rsi
00007cc2697dd14a  pop rdi
00007cc2697dd14b  pop rdx
00007cc2697dd14c  pop rcx
00007cc2697dd14d  pop rax
00007cc2697dd14e  add rsp, 0x08
00007cc2697dd152  jmp 0x00007CC2697DA608
00007cc2697dd157  sub rsp, 0x08
00007cc2697dd15b  push rax
00007cc2697dd15c  push rcx
00007cc2697dd15d  push rdx
00007cc2697dd15e  push rdi
00007cc2697dd15f  push rsi
00007cc2697dd160  push r8
00007cc2697dd162  push r9
00007cc2697dd164  push r10
00007cc2697dd166  push r11
00007cc2697dd168  sub rsp, 0xF0
00007cc2697dd16f  vmovaps [rsp], xmm0
00007cc2697dd174  vmovaps [rsp+0x10], xmm1
00007cc2697dd17a  vmovaps [rsp+0x20], xmm2
00007cc2697dd180  vmovaps [rsp+0x30], xmm3
00007cc2697dd186  vmovaps [rsp+0x40], xmm4
00007cc2697dd18c  vmovaps [rsp+0x50], xmm5
00007cc2697dd192  vmovaps [rsp+0x60], xmm6
00007cc2697dd198  vmovaps [rsp+0x70], xmm7
00007cc2697dd19e  vmovaps [rsp+0x80], xmm8
00007cc2697dd1a7  vmovaps [rsp+0x90], xmm9
00007cc2697dd1b0  vmovaps [rsp+0xA0], xmm10
00007cc2697dd1b9  vmovaps [rsp+0xB0], xmm11
00007cc2697dd1c2  vmovaps [rsp+0xC0], xmm12
00007cc2697dd1cb  vmovaps [rsp+0xD0], xmm13
00007cc2697dd1d4  vmovaps [rsp+0xE0], xmm15
00007cc2697dd1dd  sub rsp, 0x40
00007cc2697dd1e1  lea rdi, [rsp]
00007cc2697dd1e5  lea rsi, [rsp+0x10]
00007cc2697dd1ea  lea rdx, [rsp+0x20]
00007cc2697dd1ef  lea rcx, [rsp+0x30]
00007cc2697dd1f4  mov r8d, 0x00
00007cc2697dd1fa  lea r9, [r15+0x3A8]
00007cc2697dd201  movaps [rdi], xmm14
00007cc2697dd205  movaps [rsi], xmm11
00007cc2697dd209  movaps [rdx], xmm1
00007cc2697dd20c  movaps [rcx], xmm15
00007cc2697dd210  mov rax, 0x653E5FFFBA50
00007cc2697dd21a  call rax
00007cc2697dd21c  movaps xmm14, [rsp]
00007cc2697dd221  add rsp, 0x40
00007cc2697dd225  vmovaps xmm0, [rsp]
00007cc2697dd22a  vmovaps xmm1, [rsp+0x10]
00007cc2697dd230  vmovaps xmm2, [rsp+0x20]
00007cc2697dd236  vmovaps xmm3, [rsp+0x30]
00007cc2697dd23c  vmovaps xmm4, [rsp+0x40]
00007cc2697dd242  vmovaps xmm5, [rsp+0x50]
00007cc2697dd248  vmovaps xmm6, [rsp+0x60]
00007cc2697dd24e  vmovaps xmm7, [rsp+0x70]
00007cc2697dd254  vmovaps xmm8, [rsp+0x80]
00007cc2697dd25d  vmovaps xmm9, [rsp+0x90]
00007cc2697dd266  vmovaps xmm10, [rsp+0xA0]
00007cc2697dd26f  vmovaps xmm11, [rsp+0xB0]
00007cc2697dd278  vmovaps xmm12, [rsp+0xC0]
00007cc2697dd281  vmovaps xmm13, [rsp+0xD0]
00007cc2697dd28a  vmovaps xmm15, [rsp+0xE0]
00007cc2697dd293  add rsp, 0xF0
00007cc2697dd29a  pop r11
00007cc2697dd29c  pop r10
00007cc2697dd29e  pop r9
00007cc2697dd2a0  pop r8
00007cc2697dd2a2  pop rsi
00007cc2697dd2a3  pop rdi
00007cc2697dd2a4  pop rdx
00007cc2697dd2a5  pop rcx
00007cc2697dd2a6  pop rax
00007cc2697dd2a7  add rsp, 0x08
00007cc2697dd2ab  jmp 0x00007CC2697DA636
00007cc2697dd2b0  call 0x00007CC2696079B0
00007cc2697dd2b5  jmp 0x00007CC2697DA64C
00007cc2697dd2ba  call 0x00007CC2696E3440
00007cc2697dd2bf  jmp 0x00007CC2697DA656
00007cc2697dd2c4  call 0x00007CC2696DFCE0
00007cc2697dd2c9  jmp 0x00007CC2697DA660
00007cc2697dd2ce  call 0x00007CC2696E46C0
00007cc2697dd2d3  jmp 0x00007CC2697DA66A
00007cc2697dd2d8  int3
00007cc2697dd2d9  nop [rax], eax
00007cc2697dd2e0  mov qword ptr [r15+0x40], 0x430000
00007cc2697dd2e8  mov eax, 0x430C50
00007cc2697dd2ed  mov r14, [r13+rax*1]
00007cc2697dd2f2  movq xmm1, r14
00007cc2697dd2f7  mov rax, [r15+0x50]
00007cc2697dd2fb  movups xmm15, [r13+rax*1]
00007cc2697dd301  movaps [r15+0x120], xmm15
00007cc2697dd309  mov qword ptr [r15+0x48], 0x10
00007cc2697dd311  xor eax, eax
00007cc2697dd313  mov r14d, 0x10
00007cc2697dd319  mov r12d, 0x200
00007cc2697dd31f  cmp r14, r12
00007cc2697dd322  cmc
00007cc2697dd323  lahf
00007cc2697dd324  seto al
00007cc2697dd327  mov [r15+0x108], eax
00007cc2697dd32e  pextrq rax, xmm15, 0x01
00007cc2697dd335  movq xmm14, rax
00007cc2697dd33a  movaps [r15+0x130], xmm14
00007cc2697dd342  movq rax, xmm1
00007cc2697dd347  movq r14, xmm15
00007cc2697dd34c  vmovq xmm1, rax
00007cc2697dd351  vmovq xmm15, r14
00007cc2697dd356  movaps xmm13, xmm1
00007cc2697dd35a  addsd xmm13, xmm15
00007cc2697dd35f  ucomisd xmm13, xmm13
00007cc2697dd364  jp 0x00007CC2697DD423
00007cc2697dd36a  movq xmm13, xmm13
00007cc2697dd36f  movq rax, xmm13
00007cc2697dd374  movq r14, xmm14
00007cc2697dd379  vmovq xmm1, rax
00007cc2697dd37e  vmovq xmm15, r14
00007cc2697dd383  movaps xmm14, xmm1
00007cc2697dd387  addsd xmm14, xmm15
00007cc2697dd38c  ucomisd xmm14, xmm14
00007cc2697dd391  jp 0x00007CC2697DD46B
00007cc2697dd397  movq xmm14, xmm14
00007cc2697dd39c  movaps [r15+0x110], xmm14
00007cc2697dd3a4  mov eax, [r15+0x108]
00007cc2697dd3ab  sahf
00007cc2697dd3ac  jnz 0x00007CC2697DD3DE
00007cc2697dd3ae  cmp dword ptr [r15+0x318], 0x00
00007cc2697dd3b6  jz 0x00007CC2697DD680
00007cc2697dd3bc  nop [rax+rax*1], ax
00007cc2697dd3c5  nop [rax+rax*1], eax
00007cc2697dd3cd  mov eax, 0x410698
00007cc2697dd3d2  mov [r15+0x100], rax
00007cc2697dd3d9  jmp 0x00007CC2695FE110
00007cc2697dd3de  cmp dword ptr [r15+0x318], 0x00
00007cc2697dd3e6  jz 0x00007CC2697DD4C0
00007cc2697dd3ec  nop [rax+rax*1], ax
00007cc2697dd3f5  nop [rax+rax*1], eax
00007cc2697dd3fd  mov eax, 0x41067C
00007cc2697dd402  mov [r15+0x100], rax
00007cc2697dd409  jmp 0x00007CC2695FE110
00007cc2697dd40e  int3
00007cc2697dd40f  call 0x00007CC26960DC20
00007cc2697dd414  jmp 0x00007CC2697DD2F2
00007cc2697dd419  call 0x00007CC26960E760
00007cc2697dd41e  jmp 0x00007CC2697DD301
00007cc2697dd423  ucomisd xmm1, xmm15
00007cc2697dd428  jp 0x00007CC2697DD437
00007cc2697dd42a  movaps xmm13, [0x00007CC2693FE060]
00007cc2697dd432  jmp 0x00007CC2697DD36A
00007cc2697dd437  vxorps xmm0, xmm1, xmm15
00007cc2697dd43c  pextrw eax, xmm0, 0x03
00007cc2697dd441  and eax, 0x7FF8
00007cc2697dd446  cmp eax, 0x08
00007cc2697dd449  jnz 0x00007CC2697DD36A
00007cc2697dd44f  movq rax, xmm15
00007cc2697dd454  shl rax, 0x0D
00007cc2697dd458  jbe 0x00007CC2697DD36A
00007cc2697dd45e  vorps xmm13, xmm15, [0x00007CC2693FE070]
00007cc2697dd466  jmp 0x00007CC2697DD36A
00007cc2697dd46b  ucomisd xmm1, xmm15
00007cc2697dd470  jp 0x00007CC2697DD47F
00007cc2697dd472  movaps xmm14, [0x00007CC2693FE060]
00007cc2697dd47a  jmp 0x00007CC2697DD397
00007cc2697dd47f  vxorps xmm0, xmm1, xmm15
00007cc2697dd484  pextrw eax, xmm0, 0x03
00007cc2697dd489  and eax, 0x7FF8
00007cc2697dd48e  cmp eax, 0x08
00007cc2697dd491  jnz 0x00007CC2697DD397
00007cc2697dd497  movq rax, xmm15
00007cc2697dd49c  shl rax, 0x0D
00007cc2697dd4a0  jbe 0x00007CC2697DD397
00007cc2697dd4a6  vorps xmm14, xmm15, [0x00007CC2693FE070]
00007cc2697dd4ae  jmp 0x00007CC2697DD397
00007cc2697dd4b3  int3
00007cc2697dd4b4  nop [rax+rax*1], ax
00007cc2697dd4bd  nop [rax], eax
00007cc2697dd4c0  mov rax, [r15+0x48]
00007cc2697dd4c4  mov r14, [r15+0x50]
00007cc2697dd4c8  lea r12, [r14+rax*1]
00007cc2697dd4cc  movups xmm1, [r13+r12*1]
00007cc2697dd4d2  movaps [r15+0x120], xmm1
00007cc2697dd4da  lea r14, [rax+0x10]
00007cc2697dd4de  mov [r15+0x48], r14
00007cc2697dd4e2  xor eax, eax
00007cc2697dd4e4  mov r12d, 0x200
00007cc2697dd4ea  cmp r14, r12
00007cc2697dd4ed  cmc
00007cc2697dd4ee  lahf
00007cc2697dd4ef  seto al
00007cc2697dd4f2  mov [r15+0x108], eax
00007cc2697dd4f9  pextrq rax, xmm1, 0x01
00007cc2697dd500  movq xmm15, rax
00007cc2697dd505  movaps [r15+0x130], xmm15
00007cc2697dd50d  movaps xmm14, [r15+0x110]
00007cc2697dd515  movq rax, xmm14
00007cc2697dd51a  movq r14, xmm1
00007cc2697dd51f  vmovq xmm1, rax
00007cc2697dd524  vmovq xmm14, r14
00007cc2697dd529  movaps xmm13, xmm1
00007cc2697dd52d  addsd xmm13, xmm14
00007cc2697dd532  ucomisd xmm13, xmm13
00007cc2697dd537  jp 0x00007CC2697DD5EC
00007cc2697dd53d  movq xmm13, xmm13
00007cc2697dd542  movq rax, xmm13
00007cc2697dd547  movq r14, xmm15
00007cc2697dd54c  vmovq xmm1, rax
00007cc2697dd551  vmovq xmm15, r14
00007cc2697dd556  movaps xmm14, xmm1
00007cc2697dd55a  addsd xmm14, xmm15
00007cc2697dd55f  ucomisd xmm14, xmm14
00007cc2697dd564  jp 0x00007CC2697DD634
00007cc2697dd56a  movq xmm14, xmm14
00007cc2697dd56f  movaps [r15+0x110], xmm14
00007cc2697dd577  mov eax, [r15+0x108]
00007cc2697dd57e  sahf
00007cc2697dd57f  jnz 0x00007CC2697DD5B1
00007cc2697dd581  cmp dword ptr [r15+0x318], 0x00
00007cc2697dd589  jz 0x00007CC2697DD680
00007cc2697dd58f  nop [rax+rax*1], ax
00007cc2697dd598  nop [rax+rax*1], eax
00007cc2697dd5a0  mov eax, 0x410698
00007cc2697dd5a5  mov [r15+0x100], rax
00007cc2697dd5ac  jmp 0x00007CC2695FE110
00007cc2697dd5b1  cmp dword ptr [r15+0x318], 0x00
00007cc2697dd5b9  jz 0x00007CC2697DD4C0
00007cc2697dd5bf  nop [rax+rax*1], ax
00007cc2697dd5c8  nop [rax+rax*1], eax
00007cc2697dd5d0  mov eax, 0x41067C
00007cc2697dd5d5  mov [r15+0x100], rax
00007cc2697dd5dc  jmp 0x00007CC2695FE110
00007cc2697dd5e1  int3
00007cc2697dd5e2  call 0x00007CC2696B52F0
00007cc2697dd5e7  jmp 0x00007CC2697DD4D2
00007cc2697dd5ec  ucomisd xmm1, xmm14
00007cc2697dd5f1  jp 0x00007CC2697DD600
00007cc2697dd5f3  movaps xmm13, [0x00007CC2693FE060]
00007cc2697dd5fb  jmp 0x00007CC2697DD53D
00007cc2697dd600  vxorps xmm0, xmm1, xmm14
00007cc2697dd605  pextrw eax, xmm0, 0x03
00007cc2697dd60a  and eax, 0x7FF8
00007cc2697dd60f  cmp eax, 0x08
00007cc2697dd612  jnz 0x00007CC2697DD53D
00007cc2697dd618  movq rax, xmm14
00007cc2697dd61d  shl rax, 0x0D
00007cc2697dd621  jbe 0x00007CC2697DD53D
00007cc2697dd627  vorps xmm13, xmm14, [0x00007CC2693FE070]
00007cc2697dd62f  jmp 0x00007CC2697DD53D
00007cc2697dd634  ucomisd xmm1, xmm15
00007cc2697dd639  jp 0x00007CC2697DD648
00007cc2697dd63b  movaps xmm14, [0x00007CC2693FE060]
00007cc2697dd643  jmp 0x00007CC2697DD56A
00007cc2697dd648  vxorps xmm0, xmm1, xmm15
00007cc2697dd64d  pextrw eax, xmm0, 0x03
00007cc2697dd652  and eax, 0x7FF8
00007cc2697dd657  cmp eax, 0x08
00007cc2697dd65a  jnz 0x00007CC2697DD56A
00007cc2697dd660  movq rax, xmm15
00007cc2697dd665  shl rax, 0x0D
00007cc2697dd669  jbe 0x00007CC2697DD56A
00007cc2697dd66f  vorps xmm14, xmm15, [0x00007CC2693FE070]
00007cc2697dd677  jmp 0x00007CC2697DD56A
00007cc2697dd67c  int3
00007cc2697dd67d  nop [rax], eax
00007cc2697dd680  mov rax, [r15+0xF8]
00007cc2697dd687  lea r14, [rax+0x1A0]
00007cc2697dd68e  mov r12, [r13+r14*1]
00007cc2697dd693  lea r14, [rax+0x1A8]
00007cc2697dd69a  mov r11, [r13+r14*1]
00007cc2697dd69f  mov [r15+0xA0], r12
00007cc2697dd6a6  mov [r15+0x98], r11
00007cc2697dd6ad  mov r14, [r15+0x40]
00007cc2697dd6b1  lea r12, [r14+0xC50]
00007cc2697dd6b8  movaps xmm1, [r15+0x110]
00007cc2697dd6c0  movq r14, xmm1
00007cc2697dd6c5  mov [r13+r12*1], r14
00007cc2697dd6ca  lea r14, [rax+0x190]
00007cc2697dd6d1  mov r12, [r13+r14*1]
00007cc2697dd6d6  lea r14, [rax+0x198]
00007cc2697dd6dd  mov r11, [r13+r14*1]
00007cc2697dd6e2  mov [r15+0xE8], r12
00007cc2697dd6e9  mov [r15+0xF0], r11
00007cc2697dd6f0  lea r14, [rax+0x180]
00007cc2697dd6f7  mov r12, [r13+r14*1]
00007cc2697dd6fc  lea r14, [rax+0x188]
00007cc2697dd703  mov r10, [r13+r14*1]
00007cc2697dd708  movq xmm1, r12
00007cc2697dd70d  movq xmm15, r10
00007cc2697dd712  movq xmm1, xmm1
00007cc2697dd716  movq xmm1, xmm1
00007cc2697dd71a  movaps [r15+0x1A0], xmm1
00007cc2697dd722  movq xmm15, xmm15
00007cc2697dd727  movq xmm15, xmm15
00007cc2697dd72c  movaps [r15+0x190], xmm15
00007cc2697dd734  lea r14, [rax+0x170]
00007cc2697dd73b  mov r12, [r13+r14*1]
00007cc2697dd740  lea r14, [rax+0x178]
00007cc2697dd747  mov r10, [r13+r14*1]
00007cc2697dd74c  movq xmm1, r12
00007cc2697dd751  movq xmm15, r10
00007cc2697dd756  movq xmm1, xmm1
00007cc2697dd75a  movq xmm1, xmm1
00007cc2697dd75e  movaps [r15+0x1C0], xmm1
00007cc2697dd766  movq xmm15, xmm15
00007cc2697dd76b  movq xmm15, xmm15
00007cc2697dd770  movaps [r15+0x1B0], xmm15
00007cc2697dd778  lea r14, [rax+0x160]
00007cc2697dd77f  mov r12, [r13+r14*1]
00007cc2697dd784  lea r14, [rax+0x168]
00007cc2697dd78b  mov r10, [r13+r14*1]
00007cc2697dd790  movq xmm1, r12
00007cc2697dd795  movq xmm15, r10
00007cc2697dd79a  movq xmm1, xmm1
00007cc2697dd79e  movq xmm1, xmm1
00007cc2697dd7a2  movaps [r15+0x1E0], xmm1
00007cc2697dd7aa  movq xmm15, xmm15
00007cc2697dd7af  movq xmm15, xmm15
00007cc2697dd7b4  movaps [r15+0x1D0], xmm15
00007cc2697dd7bc  lea r14, [rax+0x150]
00007cc2697dd7c3  mov r12, [r13+r14*1]
00007cc2697dd7c8  lea r14, [rax+0x158]
00007cc2697dd7cf  mov r10, [r13+r14*1]
00007cc2697dd7d4  movq xmm1, r12
00007cc2697dd7d9  movq xmm15, r10
00007cc2697dd7de  movq xmm1, xmm1
00007cc2697dd7e2  movq xmm1, xmm1
00007cc2697dd7e6  movaps [r15+0x200], xmm1
00007cc2697dd7ee  movq xmm15, xmm15
00007cc2697dd7f3  movq xmm15, xmm15
00007cc2697dd7f8  movaps [r15+0x1F0], xmm15
00007cc2697dd800  lea r14, [rax+0x1B0]
00007cc2697dd807  mov [r15+0xF8], r14
00007cc2697dd80e  mov [r15+0x100], r11
00007cc2697dd815  jmp 0x00007CC2697CE5C0
00007cc2697dd81a  int3
00007cc2697dd81b  call 0x00007CC2696E27E0
00007cc2697dd820  jmp 0x00007CC2697DD693
00007cc2697dd825  call 0x00007CC2696E1570
00007cc2697dd82a  jmp 0x00007CC2697DD69F
00007cc2697dd82f  call 0x00007CC2696C3FE0
00007cc2697dd834  jmp 0x00007CC2697DD6CA
00007cc2697dd839  call 0x00007CC2696E27E0
00007cc2697dd83e  jmp 0x00007CC2697DD6D6
00007cc2697dd843  call 0x00007CC2696E1570
00007cc2697dd848  jmp 0x00007CC2697DD6E2
00007cc2697dd84d  call 0x00007CC2696E27E0
00007cc2697dd852  jmp 0x00007CC2697DD6FC
00007cc2697dd857  call 0x00007CC2696E0300
00007cc2697dd85c  jmp 0x00007CC2697DD708
00007cc2697dd861  call 0x00007CC2696E27E0
00007cc2697dd866  jmp 0x00007CC2697DD740
00007cc2697dd86b  call 0x00007CC2696E0300
00007cc2697dd870  jmp 0x00007CC2697DD74C
00007cc2697dd875  call 0x00007CC2696E27E0
00007cc2697dd87a  jmp 0x00007CC2697DD784
00007cc2697dd87f  call 0x00007CC2696E0300
00007cc2697dd884  jmp 0x00007CC2697DD790
00007cc2697dd889  call 0x00007CC2696E27E0
00007cc2697dd88e  jmp 0x00007CC2697DD7C8
00007cc2697dd893  call 0x00007CC2696E0300
00007cc2697dd898  jmp 0x00007CC2697DD7D4
00007cc2697dd89d  int3
00007cc2697dd89e  nop
00007cc2697dd8a0  mov qword ptr [r15+0x100], 0x04
00007cc2697dd8ab  mov esi, 0x00
00007cc2697dd8b0  mov edx, 0x09
00007cc2697dd8b5  mov rdi, 0x7FFC4DC902F0
00007cc2697dd8bf  mov rax, 0x653E5FE8E970
00007cc2697dd8c9  call rax
00007cc2697dd8cb  cmp dword ptr [r15+0x318], 0x00
00007cc2697dd8d3  jnz 0x00007CC2695FE110
00007cc2697dd8d9  jmp 0x00007CC2695FE0A0
00007cc2697dd8de  int3
00007cc2697dd8df  int3
