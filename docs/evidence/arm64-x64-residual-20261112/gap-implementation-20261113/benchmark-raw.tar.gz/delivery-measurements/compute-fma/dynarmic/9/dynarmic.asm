000074da185ce69b  nop [rax+rax*1], eax
000074da185ce6a0  mov rax, [r15+0xF8]
000074da185ce6a7  lea r14, [rax-0x1B0]
000074da185ce6ae  mov [r15+0xF8], r14
000074da185ce6b5  lea rax, [r14+0x1A0]
000074da185ce6bc  mov r12, [r15+0xA0]
000074da185ce6c3  mov r11, [r15+0x98]
000074da185ce6ca  mov [r13+rax*1], r12
000074da185ce6cf  lea rax, [r14+0x1A8]
000074da185ce6d6  mov [r13+rax*1], r11
000074da185ce6db  mov eax, 0x420A30
000074da185ce6e0  movups xmm1, [r13+rax*1]
000074da185ce6e6  mov eax, 0x4209C0
000074da185ce6eb  movups xmm15, [r13+rax*1]
000074da185ce6f1  mov eax, 0x420A50
000074da185ce6f6  movups xmm14, [r13+rax*1]
000074da185ce6fc  mov eax, 0x4209F0
000074da185ce701  movups xmm13, [r13+rax*1]
000074da185ce707  mov qword ptr [r15+0x98], 0x430C60
000074da185ce712  mov eax, 0x420A60
000074da185ce717  movups xmm12, [r13+rax*1]
000074da185ce71d  mov eax, 0x430C60
000074da185ce722  movups [r13+rax*1], xmm1
000074da185ce728  mov eax, 0x430C70
000074da185ce72d  movups [r13+rax*1], xmm15
000074da185ce733  mov eax, 0x430C80
000074da185ce738  movups [r13+rax*1], xmm14
000074da185ce73e  mov eax, 0x430C90
000074da185ce743  movups [r13+rax*1], xmm13
000074da185ce749  mov eax, 0x4209B0
000074da185ce74e  movups xmm14, [r13+rax*1]
000074da185ce754  mov eax, 0x4209A0
000074da185ce759  movups xmm13, [r13+rax*1]
000074da185ce75f  mov eax, 0x430D60
000074da185ce764  movups [r13+rax*1], xmm1
000074da185ce76a  mov eax, 0x430D70
000074da185ce76f  movups [r13+rax*1], xmm15
000074da185ce775  mov eax, 0x430CA0
000074da185ce77a  movups [r13+rax*1], xmm12
000074da185ce780  mov eax, 0x430CB0
000074da185ce785  movups [r13+rax*1], xmm14
000074da185ce78b  mov eax, 0x420990
000074da185ce790  movups xmm1, [r13+rax*1]
000074da185ce796  mov eax, 0x420A00
000074da185ce79b  movups xmm15, [r13+rax*1]
000074da185ce7a1  mov eax, 0x430CC0
000074da185ce7a6  movups [r13+rax*1], xmm13
000074da185ce7ac  mov eax, 0x430CD0
000074da185ce7b1  movups [r13+rax*1], xmm1
000074da185ce7b7  mov eax, 0x420A10
000074da185ce7bc  movups xmm1, [r13+rax*1]
000074da185ce7c2  mov eax, 0x4209E0
000074da185ce7c7  movups xmm14, [r13+rax*1]
000074da185ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000074da185ce7d5  mov eax, 0x430CE0
000074da185ce7da  movups [r13+rax*1], xmm15
000074da185ce7e0  mov eax, 0x430CF0
000074da185ce7e5  movups [r13+rax*1], xmm1
000074da185ce7eb  mov eax, 0x420A80
000074da185ce7f0  movups xmm1, [r13+rax*1]
000074da185ce7f6  mov eax, 0x420A90
000074da185ce7fb  movups xmm15, [r13+rax*1]
000074da185ce801  movaps [r15+0x150], xmm15
000074da185ce809  mov qword ptr [r15+0xA0], 0x3E8
000074da185ce814  mov eax, 0x430D00
000074da185ce819  movups [r13+rax*1], xmm14
000074da185ce81f  mov eax, 0x430D10
000074da185ce824  movups [r13+rax*1], xmm1
000074da185ce82a  mov eax, 0x420A70
000074da185ce82f  movups xmm1, [r13+rax*1]
000074da185ce835  mov eax, 0x420A20
000074da185ce83a  movups xmm14, [r13+rax*1]
000074da185ce840  movaps [r15+0x140], xmm14
000074da185ce848  lea rax, [r14+0x150]
000074da185ce84f  movq xmm13, qword ptr [r15+0x200]
000074da185ce858  movq xmm12, qword ptr [r15+0x1F0]
000074da185ce861  movq r12, xmm13
000074da185ce866  movq r11, xmm12
000074da185ce86b  mov [r13+rax*1], r12
000074da185ce870  lea rax, [r14+0x158]
000074da185ce877  mov [r13+rax*1], r11
000074da185ce87c  mov eax, 0x430D20
000074da185ce881  movups [r13+rax*1], xmm15
000074da185ce887  mov eax, 0x430D30
000074da185ce88c  movups [r13+rax*1], xmm1
000074da185ce892  mov eax, 0x420A40
000074da185ce897  movups xmm1, [r13+rax*1]
000074da185ce89d  mov eax, 0x420AA8
000074da185ce8a2  mov r12, [r13+rax*1]
000074da185ce8a7  movq xmm15, r12
000074da185ce8ac  mov qword ptr [r15+0x40], 0x420AB0
000074da185ce8b4  mov eax, 0x430D40
000074da185ce8b9  movups [r13+rax*1], xmm14
000074da185ce8bf  mov eax, 0x430D50
000074da185ce8c4  movups [r13+rax*1], xmm1
000074da185ce8ca  mov eax, 0x420B10
000074da185ce8cf  movups xmm1, [r13+rax*1]
000074da185ce8d5  movq rax, xmm15
000074da185ce8da  mov r12d, 0x430D80
000074da185ce8e0  mov [r13+r12*1], rax
000074da185ce8e5  mov eax, 0x420AF0
000074da185ce8ea  movups xmm15, [r13+rax*1]
000074da185ce8f0  mov eax, 0x420B00
000074da185ce8f5  movups xmm14, [r13+rax*1]
000074da185ce8fb  lea rax, [r14+0x130]
000074da185ce902  movups [r13+rax*1], xmm1
000074da185ce908  lea rax, [r14+0x160]
000074da185ce90f  movq xmm1, qword ptr [r15+0x1E0]
000074da185ce918  movq xmm13, qword ptr [r15+0x1D0]
000074da185ce921  movq r12, xmm1
000074da185ce926  movq r11, xmm13
000074da185ce92b  mov [r13+rax*1], r12
000074da185ce930  lea rax, [r14+0x168]
000074da185ce937  mov [r13+rax*1], r11
000074da185ce93c  lea rax, [r14+0x110]
000074da185ce943  movups [r13+rax*1], xmm15
000074da185ce949  lea rax, [r14+0x120]
000074da185ce950  movups [r13+rax*1], xmm14
000074da185ce956  mov eax, 0x420AB0
000074da185ce95b  movups xmm1, [r13+rax*1]
000074da185ce961  mov eax, 0x420AC0
000074da185ce966  movups xmm15, [r13+rax*1]
000074da185ce96c  movaps [r15+0x120], xmm15
000074da185ce974  lea rax, [r14+0x170]
000074da185ce97b  movq xmm14, qword ptr [r15+0x1C0]
000074da185ce984  movq xmm13, qword ptr [r15+0x1B0]
000074da185ce98d  movq r12, xmm14
000074da185ce992  movq r11, xmm13
000074da185ce997  mov [r13+rax*1], r12
000074da185ce99c  lea rax, [r14+0x178]
000074da185ce9a3  mov [r13+rax*1], r11
000074da185ce9a8  lea rax, [r14+0x180]
000074da185ce9af  movq xmm14, qword ptr [r15+0x1A0]
000074da185ce9b8  movq xmm13, qword ptr [r15+0x190]
000074da185ce9c1  movq r12, xmm14
000074da185ce9c6  movq r11, xmm13
000074da185ce9cb  mov [r13+rax*1], r12
000074da185ce9d0  lea rax, [r14+0x188]
000074da185ce9d7  mov [r13+rax*1], r11
000074da185ce9dc  lea rax, [r14+0xD0]
000074da185ce9e3  movups [r13+rax*1], xmm1
000074da185ce9e9  lea rax, [r14+0xE0]
000074da185ce9f0  movups [r13+rax*1], xmm15
000074da185ce9f6  mov eax, 0x420AD0
000074da185ce9fb  movups xmm1, [r13+rax*1]
000074da185cea01  mov eax, 0x420AE0
000074da185cea06  movups xmm15, [r13+rax*1]
000074da185cea0c  movaps [r15+0x110], xmm1
000074da185cea14  movaps [r15+0x130], xmm15
000074da185cea1c  lea rax, [r14+0x190]
000074da185cea23  mov r12, [r15+0xE8]
000074da185cea2a  mov r11, [r15+0xF0]
000074da185cea31  mov [r13+rax*1], r12
000074da185cea36  lea rax, [r14+0x198]
000074da185cea3d  mov [r13+rax*1], r11
000074da185cea42  mov eax, 0x430D88
000074da185cea47  mov r12d, 0x421DF8D3
000074da185cea4d  mov [r13+rax*1], r12d
000074da185cea52  lea rax, [r14+0xF0]
000074da185cea59  movups [r13+rax*1], xmm1
000074da185cea5f  lea rax, [r14+0x100]
000074da185cea66  movups [r13+rax*1], xmm15
000074da185cea6c  lea rax, [r14+0xD0]
000074da185cea73  mov [r15], rax
000074da185cea76  mov qword ptr [r15+0x08], 0x430C60
000074da185cea7e  mov qword ptr [r15+0x10], 0x12C
000074da185cea86  mov qword ptr [r15+0xF0], 0x410284
000074da185cea91  mov r14d, [r15+0x320]
000074da185cea98  mov eax, 0x410284
000074da185cea9d  mov rcx, 0x74DA185D07C0
000074da185ceaa7  mov [r15+r14*8+0x328], rax
000074da185ceaaf  mov [r15+r14*8+0x368], rcx
000074da185ceab7  add r14d, 0x01
000074da185ceabb  and r14d, 0x07
000074da185ceabf  mov [r15+0x320], r14d
000074da185ceac6  cmp dword ptr [r15+0x318], 0x00
000074da185ceace  jz 0x000074DA185CED70
000074da185cead4  nop [rax+rax*1], ax
000074da185ceadd  nop [rax+rax*1], eax
000074da185ceae5  mov eax, 0x4106BC
000074da185ceaea  mov [r15+0x100], rax
000074da185ceaf1  jmp 0x000074DA183FE110
000074da185ceaf6  int3
000074da185ceaf7  call 0x000074DA1840BC20
000074da185ceafc  jmp 0x000074DA185CE6CF
000074da185ceb01  call 0x000074DA1840A9A0
000074da185ceb06  jmp 0x000074DA185CE6DB
000074da185ceb0b  call 0x000074DA183FF430
000074da185ceb10  jmp 0x000074DA185CE6E6
000074da185ceb15  call 0x000074DA1840E760
000074da185ceb1a  jmp 0x000074DA185CE6F1
000074da185ceb1f  call 0x000074DA1840D4E0
000074da185ceb24  jmp 0x000074DA185CE6FC
000074da185ceb29  call 0x000074DA1840C260
000074da185ceb2e  jmp 0x000074DA185CE707
000074da185ceb33  call 0x000074DA1840AFE0
000074da185ceb38  jmp 0x000074DA185CE71D
000074da185ceb3d  call 0x000074DA183FF540
000074da185ceb42  jmp 0x000074DA185CE728
000074da185ceb47  call 0x000074DA1840E880
000074da185ceb4c  jmp 0x000074DA185CE733
000074da185ceb51  call 0x000074DA1840D600
000074da185ceb56  jmp 0x000074DA185CE73E
000074da185ceb5b  call 0x000074DA1840C380
000074da185ceb60  jmp 0x000074DA185CE749
000074da185ceb65  call 0x000074DA1840D4E0
000074da185ceb6a  jmp 0x000074DA185CE754
000074da185ceb6f  call 0x000074DA1840C260
000074da185ceb74  jmp 0x000074DA185CE75F
000074da185ceb79  call 0x000074DA183FF540
000074da185ceb7e  jmp 0x000074DA185CE76A
000074da185ceb83  call 0x000074DA1840E880
000074da185ceb88  jmp 0x000074DA185CE775
000074da185ceb8d  call 0x000074DA1840B100
000074da185ceb92  jmp 0x000074DA185CE780
000074da185ceb97  call 0x000074DA1840D600
000074da185ceb9c  jmp 0x000074DA185CE78B
000074da185ceba1  call 0x000074DA183FF430
000074da185ceba6  jmp 0x000074DA185CE796
000074da185cebab  call 0x000074DA1840E760
000074da185cebb0  jmp 0x000074DA185CE7A1
000074da185cebb5  call 0x000074DA1840C380
000074da185cebba  jmp 0x000074DA185CE7AC
000074da185cebbf  call 0x000074DA183FF540
000074da185cebc4  jmp 0x000074DA185CE7B7
000074da185cebc9  call 0x000074DA183FF430
000074da185cebce  jmp 0x000074DA185CE7C2
000074da185cebd3  call 0x000074DA1840D4E0
000074da185cebd8  jmp 0x000074DA185CE7CD
000074da185cebdd  call 0x000074DA1840E880
000074da185cebe2  jmp 0x000074DA185CE7E0
000074da185cebe7  call 0x000074DA183FF540
000074da185cebec  jmp 0x000074DA185CE7EB
000074da185cebf1  call 0x000074DA183FF430
000074da185cebf6  jmp 0x000074DA185CE7F6
000074da185cebfb  call 0x000074DA1840E760
000074da185cec00  jmp 0x000074DA185CE801
000074da185cec05  call 0x000074DA1840D600
000074da185cec0a  jmp 0x000074DA185CE81F
000074da185cec0f  call 0x000074DA183FF540
000074da185cec14  jmp 0x000074DA185CE82A
000074da185cec19  call 0x000074DA183FF430
000074da185cec1e  jmp 0x000074DA185CE835
000074da185cec23  call 0x000074DA1840D4E0
000074da185cec28  jmp 0x000074DA185CE840
000074da185cec2d  call 0x000074DA1840BC20
000074da185cec32  jmp 0x000074DA185CE870
000074da185cec37  call 0x000074DA1840A9A0
000074da185cec3c  jmp 0x000074DA185CE87C
000074da185cec41  call 0x000074DA1840E880
000074da185cec46  jmp 0x000074DA185CE887
000074da185cec4b  call 0x000074DA183FF540
000074da185cec50  jmp 0x000074DA185CE892
000074da185cec55  call 0x000074DA183FF430
000074da185cec5a  jmp 0x000074DA185CE89D
000074da185cec5f  call 0x000074DA1840B720
000074da185cec64  jmp 0x000074DA185CE8A7
000074da185cec69  call 0x000074DA1840D600
000074da185cec6e  jmp 0x000074DA185CE8BF
000074da185cec73  call 0x000074DA183FF540
000074da185cec78  jmp 0x000074DA185CE8CA
000074da185cec7d  call 0x000074DA183FF430
000074da185cec82  jmp 0x000074DA185CE8D5
000074da185cec87  call 0x000074DA184B4CB0
000074da185cec8c  jmp 0x000074DA185CE8E5
000074da185cec91  call 0x000074DA1840E760
000074da185cec96  jmp 0x000074DA185CE8F0
000074da185cec9b  call 0x000074DA1840D4E0
000074da185ceca0  jmp 0x000074DA185CE8FB
000074da185ceca5  call 0x000074DA183FF540
000074da185cecaa  jmp 0x000074DA185CE908
000074da185cecaf  call 0x000074DA1840BC20
000074da185cecb4  jmp 0x000074DA185CE930
000074da185cecb9  call 0x000074DA1840A9A0
000074da185cecbe  jmp 0x000074DA185CE93C
000074da185cecc3  call 0x000074DA1840E880
000074da185cecc8  jmp 0x000074DA185CE949
000074da185ceccd  call 0x000074DA1840D600
000074da185cecd2  jmp 0x000074DA185CE956
000074da185cecd7  call 0x000074DA183FF430
000074da185cecdc  jmp 0x000074DA185CE961
000074da185cece1  call 0x000074DA1840E760
000074da185cece6  jmp 0x000074DA185CE96C
000074da185ceceb  call 0x000074DA1840BC20
000074da185cecf0  jmp 0x000074DA185CE99C
000074da185cecf5  call 0x000074DA1840A9A0
000074da185cecfa  jmp 0x000074DA185CE9A8
000074da185cecff  call 0x000074DA1840BC20
000074da185ced04  jmp 0x000074DA185CE9D0
000074da185ced09  call 0x000074DA1840A9A0
000074da185ced0e  jmp 0x000074DA185CE9DC
000074da185ced13  call 0x000074DA183FF540
000074da185ced18  jmp 0x000074DA185CE9E9
000074da185ced1d  call 0x000074DA1840E880
000074da185ced22  jmp 0x000074DA185CE9F6
000074da185ced27  call 0x000074DA183FF430
000074da185ced2c  jmp 0x000074DA185CEA01
000074da185ced31  call 0x000074DA1840E760
000074da185ced36  jmp 0x000074DA185CEA0C
000074da185ced3b  call 0x000074DA1840BC20
000074da185ced40  jmp 0x000074DA185CEA36
000074da185ced45  call 0x000074DA1840A9A0
000074da185ced4a  jmp 0x000074DA185CEA42
000074da185ced4f  call 0x000074DA1840BAE0
000074da185ced54  jmp 0x000074DA185CEA52
000074da185ced59  call 0x000074DA183FF540
000074da185ced5e  jmp 0x000074DA185CEA5F
000074da185ced63  call 0x000074DA1840E880
000074da185ced68  jmp 0x000074DA185CEA6C
000074da185ced6d  int3
000074da185ced6e  nop
000074da185ced70  mov rax, [r15]
000074da185ced73  lea r14, [rax+0x20]
000074da185ced77  mov r12, [r13+r14*1]
000074da185ced7c  mov r14, [r15+0x10]
000074da185ced80  lea r11, [r12+r14*1]
000074da185ced84  mov [r15+0x40], r11
000074da185ced88  lea r12, [rax+0x20]
000074da185ced8c  mov [r13+r12*1], r11
000074da185ced91  test r14, r14
000074da185ced94  setz r14b
000074da185ced98  movzx r14, r14b
000074da185ced9c  mov [rsp+0x414], r14b
000074da185ceda4  cmp byte ptr [rsp+0x414], 0x00
000074da185cedac  jz 0x000074DA185CEDDE
000074da185cedae  cmp dword ptr [r15+0x318], 0x00
000074da185cedb6  mov eax, 0x410934
000074da185cedbb  mov [r15+0x100], rax
000074da185cedc2  jz 0x000074DA183FE0A0
000074da185cedc8  nop [rax+rax*1], eax
000074da185cedcd  mov eax, 0x410934
000074da185cedd2  mov [r15+0x100], rax
000074da185cedd9  jmp 0x000074DA183FE110
000074da185cedde  cmp dword ptr [r15+0x318], 0x00
000074da185cede6  jz 0x000074DA185CEE30
000074da185cedec  nop [rax+rax*1], ax
000074da185cedf5  nop [rax+rax*1], eax
000074da185cedfd  mov eax, 0x4106CC
000074da185cee02  mov [r15+0x100], rax
000074da185cee09  jmp 0x000074DA183FE110
000074da185cee0e  int3
000074da185cee0f  call 0x000074DA184E27E0
000074da185cee14  jmp 0x000074DA185CED7C
000074da185cee19  call 0x000074DA184C0860
000074da185cee1e  jmp 0x000074DA185CED91
000074da185cee23  int3
000074da185cee24  nop [rax+rax*1], ax
000074da185cee2d  nop [rax], eax
000074da185cee30  mov rax, [r15+0xF8]
000074da185cee37  lea r14, [rax-0x150]
000074da185cee3e  mov [r15+0xF8], r14
000074da185cee45  mov rax, [r15]
000074da185cee48  lea r12, [rax+0x68]
000074da185cee4c  mov r11, [r13+r12*1]
000074da185cee51  mov [r15+0x88], r11
000074da185cee58  lea r12, [rax+0x28]
000074da185cee5c  mov [r15+0x40], r12
000074da185cee60  mov [r15+0x48], r14
000074da185cee64  mov qword ptr [r15+0x50], 0x420B20
000074da185cee6c  lea rax, [r14+0x100]
000074da185cee73  mov r12, [r15+0xE8]
000074da185cee7a  mov r11, [r15+0xD8]
000074da185cee81  mov [r13+rax*1], r12
000074da185cee86  lea rax, [r14+0x108]
000074da185cee8d  mov [r13+rax*1], r11
000074da185cee92  lea rax, [r14+0x110]
000074da185cee99  mov r12, [r15+0xD0]
000074da185ceea0  mov r11, [r15+0xC8]
000074da185ceea7  mov [r13+rax*1], r12
000074da185ceeac  lea rax, [r14+0x118]
000074da185ceeb3  mov [r13+rax*1], r11
000074da185ceeb8  lea rax, [r14+0x120]
000074da185ceebf  mov r12, [r15+0xC0]
000074da185ceec6  mov r11, [r15+0xB8]
000074da185ceecd  mov [r13+rax*1], r12
000074da185ceed2  lea rax, [r14+0x128]
000074da185ceed9  mov [r13+rax*1], r11
000074da185ceede  lea rax, [r14+0x130]
000074da185ceee5  mov r12, [r15+0xB0]
000074da185ceeec  mov r11, [r15+0xA8]
000074da185ceef3  mov [r13+rax*1], r12
000074da185ceef8  lea rax, [r14+0x138]
000074da185ceeff  mov [r13+rax*1], r11
000074da185cef04  lea rax, [r14+0x140]
000074da185cef0b  mov r12, [r15+0xA0]
000074da185cef12  mov r11, [r15+0x98]
000074da185cef19  mov [r13+rax*1], r12
000074da185cef1e  lea rax, [r14+0x148]
000074da185cef25  mov [r13+rax*1], r11
000074da185cef2a  cmp dword ptr [r15+0x318], 0x00
000074da185cef32  jz 0x000074DA185CEFD0
000074da185cef38  nop [rax+rax*1], ax
000074da185cef41  nop [rax+rax*1], eax
000074da185cef49  mov eax, 0x410704
000074da185cef4e  mov [r15+0x100], rax
000074da185cef55  jmp 0x000074DA183FE110
000074da185cef5a  int3
000074da185cef5b  call 0x000074DA184C0370
000074da185cef60  jmp 0x000074DA185CEE51
000074da185cef65  call 0x000074DA1840BC20
000074da185cef6a  jmp 0x000074DA185CEE86
000074da185cef6f  call 0x000074DA1840A9A0
000074da185cef74  jmp 0x000074DA185CEE92
000074da185cef79  call 0x000074DA1840BC20
000074da185cef7e  jmp 0x000074DA185CEEAC
000074da185cef83  call 0x000074DA1840A9A0
000074da185cef88  jmp 0x000074DA185CEEB8
000074da185cef8d  call 0x000074DA1840BC20
000074da185cef92  jmp 0x000074DA185CEED2
000074da185cef97  call 0x000074DA1840A9A0
000074da185cef9c  jmp 0x000074DA185CEEDE
000074da185cefa1  call 0x000074DA1840BC20
000074da185cefa6  jmp 0x000074DA185CEEF8
000074da185cefab  call 0x000074DA1840A9A0
000074da185cefb0  jmp 0x000074DA185CEF04
000074da185cefb5  call 0x000074DA1840BC20
000074da185cefba  jmp 0x000074DA185CEF1E
000074da185cefbf  call 0x000074DA1840A9A0
000074da185cefc4  jmp 0x000074DA185CEF2A
000074da185cefc9  int3
000074da185cefca  nop [rax+rax*1], ax
000074da185cefd0  mov rax, [r15+0x08]
000074da185cefd4  movzx r14d, byte ptr [r13+rax*1]
000074da185cefda  movzx r14d, r14b
000074da185cefde  mov [rsp+0x10], r14d
000074da185cefe3  mov r14d, r14d
000074da185cefe6  mov [r15+0x58], r14
000074da185cefea  lea r14, [rax+0x01]
000074da185cefee  mov [r15+0x08], r14
000074da185ceff2  mov rax, [r15+0x88]
000074da185ceff9  lea r14, [rax+0x01]
000074da185ceffd  mov r12, [r15]
000074da185cf000  lea r11, [r12+0x68]
000074da185cf005  mov [r13+r11*1], r14
000074da185cf00a  lea r14, [r12+rax*1]
000074da185cf00e  mov [r15+0x60], r14
000074da185cf012  lea rax, [r14+0x28]
000074da185cf016  mov r11d, [rsp+0x10]
000074da185cf01b  movzx r14d, r11b
000074da185cf01f  mov [r13+rax*1], r14b
000074da185cf024  lea rax, [r12+0x68]
000074da185cf029  mov r14, [r13+rax*1]
000074da185cf02e  mov [r15+0x88], r14
000074da185cf035  xor eax, eax
000074da185cf037  mov r12d, 0x40
000074da185cf03d  cmp r14, r12
000074da185cf040  cmc
000074da185cf041  lahf
000074da185cf042  seto al
000074da185cf045  mov [r15+0x108], eax
000074da185cf04c  mov eax, [r15+0x108]
000074da185cf053  sahf
000074da185cf054  jnz 0x000074DA185CF086
000074da185cf056  cmp dword ptr [r15+0x318], 0x00
000074da185cf05e  jz 0x000074DA185CF170
000074da185cf064  nop [rax+rax*1], ax
000074da185cf06d  nop [rax+rax*1], eax
000074da185cf075  mov eax, 0x410724
000074da185cf07a  mov [r15+0x100], rax
000074da185cf081  jmp 0x000074DA183FE110
000074da185cf086  cmp dword ptr [r15+0x318], 0x00
000074da185cf08e  jz 0x000074DA185CF0E0
000074da185cf094  nop [rax+rax*1], ax
000074da185cf09d  nop [rax+rax*1], eax
000074da185cf0a5  mov eax, 0x4106FC
000074da185cf0aa  mov [r15+0x100], rax
000074da185cf0b1  jmp 0x000074DA183FE110
000074da185cf0b6  int3
000074da185cf0b7  call 0x000074DA1840D860
000074da185cf0bc  jmp 0x000074DA185CEFDA
000074da185cf0c1  call 0x000074DA184B36E0
000074da185cf0c6  jmp 0x000074DA185CF00A
000074da185cf0cb  call 0x000074DA1840DD60
000074da185cf0d0  jmp 0x000074DA185CF024
000074da185cf0d5  call 0x000074DA1840DC20
000074da185cf0da  jmp 0x000074DA185CF02E
000074da185cf0df  int3
000074da185cf0e0  mov rax, [r15+0x10]
000074da185cf0e4  lea r14, [rax-0x01]
000074da185cf0e8  mov [r15+0x10], r14
000074da185cf0ec  test r14, r14
000074da185cf0ef  setz r14b
000074da185cf0f3  movzx r14, r14b
000074da185cf0f7  mov [rsp+0x414], r14b
000074da185cf0ff  cmp byte ptr [rsp+0x414], 0x00
000074da185cf107  jz 0x000074DA185CF139
000074da185cf109  cmp dword ptr [r15+0x318], 0x00
000074da185cf111  jz 0x000074DA185D0670
000074da185cf117  nop [rax+rax*1], ax
000074da185cf120  nop [rax+rax*1], eax
000074da185cf128  mov eax, 0x41091C
000074da185cf12d  mov [r15+0x100], rax
000074da185cf134  jmp 0x000074DA183FE110
000074da185cf139  cmp dword ptr [r15+0x318], 0x00
000074da185cf141  jz 0x000074DA185CEFD0
000074da185cf147  nop [rax+rax*1], ax
000074da185cf150  nop [rax+rax*1], eax
000074da185cf158  mov eax, 0x410704
000074da185cf15d  mov [r15+0x100], rax
000074da185cf164  jmp 0x000074DA183FE110
000074da185cf169  int3
000074da185cf16a  int3
000074da185cf16b  nop [rax+rax*1], eax
000074da185cf170  mov rax, [r15+0x40]
000074da185cf174  movzx r14d, byte ptr [r13+rax*1]
000074da185cf17a  movaps xmm1, [r15+0x110]
000074da185cf182  pinsrb xmm1, r14d, 0x00
000074da185cf189  lea r14, [rax+0x01]
000074da185cf18d  movzx r12d, byte ptr [r13+r14*1]
000074da185cf193  movaps xmm15, [r15+0x120]
000074da185cf19b  pinsrb xmm15, r12d, 0x00
000074da185cf1a2  lea r14, [rax+0x02]
000074da185cf1a6  movzx r12d, byte ptr [r13+r14*1]
000074da185cf1ac  movaps xmm14, [r15+0x130]
000074da185cf1b4  pinsrb xmm14, r12d, 0x00
000074da185cf1bb  lea r14, [rax+0x03]
000074da185cf1bf  movzx r12d, byte ptr [r13+r14*1]
000074da185cf1c5  movaps xmm13, [r15+0x140]
000074da185cf1cd  pinsrb xmm13, r12d, 0x00
000074da185cf1d4  lea r14, [rax+0x04]
000074da185cf1d8  movzx r12d, byte ptr [r13+r14*1]
000074da185cf1de  pinsrb xmm1, r12d, 0x01
000074da185cf1e5  lea r14, [rax+0x05]
000074da185cf1e9  movzx r12d, byte ptr [r13+r14*1]
000074da185cf1ef  pinsrb xmm15, r12d, 0x01
000074da185cf1f6  lea r14, [rax+0x06]
000074da185cf1fa  movzx r12d, byte ptr [r13+r14*1]
000074da185cf200  pinsrb xmm14, r12d, 0x01
000074da185cf207  lea r14, [rax+0x07]
000074da185cf20b  movzx r12d, byte ptr [r13+r14*1]
000074da185cf211  pinsrb xmm13, r12d, 0x01
000074da185cf218  lea r14, [rax+0x08]
000074da185cf21c  movzx r12d, byte ptr [r13+r14*1]
000074da185cf222  pinsrb xmm1, r12d, 0x02
000074da185cf229  lea r14, [rax+0x09]
000074da185cf22d  movzx r12d, byte ptr [r13+r14*1]
000074da185cf233  pinsrb xmm15, r12d, 0x02
000074da185cf23a  lea r14, [rax+0x0A]
000074da185cf23e  movzx r12d, byte ptr [r13+r14*1]
000074da185cf244  pinsrb xmm14, r12d, 0x02
000074da185cf24b  lea r14, [rax+0x0B]
000074da185cf24f  movzx r12d, byte ptr [r13+r14*1]
000074da185cf255  pinsrb xmm13, r12d, 0x02
000074da185cf25c  lea r14, [rax+0x0C]
000074da185cf260  movzx r12d, byte ptr [r13+r14*1]
000074da185cf266  pinsrb xmm1, r12d, 0x03
000074da185cf26d  lea r14, [rax+0x0D]
000074da185cf271  movzx r12d, byte ptr [r13+r14*1]
000074da185cf277  pinsrb xmm15, r12d, 0x03
000074da185cf27e  lea r14, [rax+0x0E]
000074da185cf282  movzx r12d, byte ptr [r13+r14*1]
000074da185cf288  pinsrb xmm14, r12d, 0x03
000074da185cf28f  lea r14, [rax+0x0F]
000074da185cf293  movzx r12d, byte ptr [r13+r14*1]
000074da185cf299  pinsrb xmm13, r12d, 0x03
000074da185cf2a0  lea r14, [rax+0x10]
000074da185cf2a4  movzx r12d, byte ptr [r13+r14*1]
000074da185cf2aa  pinsrb xmm1, r12d, 0x04
000074da185cf2b1  lea r14, [rax+0x11]
000074da185cf2b5  movzx r12d, byte ptr [r13+r14*1]
000074da185cf2bb  pinsrb xmm15, r12d, 0x04
000074da185cf2c2  lea r14, [rax+0x12]
000074da185cf2c6  movzx r12d, byte ptr [r13+r14*1]
000074da185cf2cc  pinsrb xmm14, r12d, 0x04
000074da185cf2d3  lea r14, [rax+0x13]
000074da185cf2d7  movzx r12d, byte ptr [r13+r14*1]
000074da185cf2dd  pinsrb xmm13, r12d, 0x04
000074da185cf2e4  lea r14, [rax+0x14]
000074da185cf2e8  movzx r12d, byte ptr [r13+r14*1]
000074da185cf2ee  pinsrb xmm1, r12d, 0x05
000074da185cf2f5  lea r14, [rax+0x15]
000074da185cf2f9  movzx r12d, byte ptr [r13+r14*1]
000074da185cf2ff  pinsrb xmm15, r12d, 0x05
000074da185cf306  lea r14, [rax+0x16]
000074da185cf30a  movzx r12d, byte ptr [r13+r14*1]
000074da185cf310  pinsrb xmm14, r12d, 0x05
000074da185cf317  lea r14, [rax+0x17]
000074da185cf31b  movzx r12d, byte ptr [r13+r14*1]
000074da185cf321  pinsrb xmm13, r12d, 0x05
000074da185cf328  lea r14, [rax+0x18]
000074da185cf32c  movzx r12d, byte ptr [r13+r14*1]
000074da185cf332  pinsrb xmm1, r12d, 0x06
000074da185cf339  lea r14, [rax+0x19]
000074da185cf33d  movzx r12d, byte ptr [r13+r14*1]
000074da185cf343  pinsrb xmm15, r12d, 0x06
000074da185cf34a  lea r14, [rax+0x1A]
000074da185cf34e  movzx r12d, byte ptr [r13+r14*1]
000074da185cf354  pinsrb xmm14, r12d, 0x06
000074da185cf35b  lea r14, [rax+0x1B]
000074da185cf35f  movzx r12d, byte ptr [r13+r14*1]
000074da185cf365  pinsrb xmm13, r12d, 0x06
000074da185cf36c  lea r14, [rax+0x1C]
000074da185cf370  movzx r12d, byte ptr [r13+r14*1]
000074da185cf376  pinsrb xmm1, r12d, 0x07
000074da185cf37d  lea r14, [rax+0x1D]
000074da185cf381  movzx r12d, byte ptr [r13+r14*1]
000074da185cf387  pinsrb xmm15, r12d, 0x07
000074da185cf38e  lea r14, [rax+0x1E]
000074da185cf392  movzx r12d, byte ptr [r13+r14*1]
000074da185cf398  pinsrb xmm14, r12d, 0x07
000074da185cf39f  lea r14, [rax+0x1F]
000074da185cf3a3  movzx r12d, byte ptr [r13+r14*1]
000074da185cf3a9  pinsrb xmm13, r12d, 0x07
000074da185cf3b0  lea r14, [rax+0x20]
000074da185cf3b4  movzx r12d, byte ptr [r13+r14*1]
000074da185cf3ba  pinsrb xmm1, r12d, 0x08
000074da185cf3c1  lea r14, [rax+0x21]
000074da185cf3c5  movzx r12d, byte ptr [r13+r14*1]
000074da185cf3cb  pinsrb xmm15, r12d, 0x08
000074da185cf3d2  lea r14, [rax+0x22]
000074da185cf3d6  movzx r12d, byte ptr [r13+r14*1]
000074da185cf3dc  pinsrb xmm14, r12d, 0x08
000074da185cf3e3  lea r14, [rax+0x23]
000074da185cf3e7  movzx r12d, byte ptr [r13+r14*1]
000074da185cf3ed  pinsrb xmm13, r12d, 0x08
000074da185cf3f4  lea r14, [rax+0x24]
000074da185cf3f8  movzx r12d, byte ptr [r13+r14*1]
000074da185cf3fe  pinsrb xmm1, r12d, 0x09
000074da185cf405  lea r14, [rax+0x25]
000074da185cf409  movzx r12d, byte ptr [r13+r14*1]
000074da185cf40f  pinsrb xmm15, r12d, 0x09
000074da185cf416  lea r14, [rax+0x26]
000074da185cf41a  movzx r12d, byte ptr [r13+r14*1]
000074da185cf420  pinsrb xmm14, r12d, 0x09
000074da185cf427  lea r14, [rax+0x27]
000074da185cf42b  movzx r12d, byte ptr [r13+r14*1]
000074da185cf431  pinsrb xmm13, r12d, 0x09
000074da185cf438  lea r14, [rax+0x28]
000074da185cf43c  movzx r12d, byte ptr [r13+r14*1]
000074da185cf442  pinsrb xmm1, r12d, 0x0A
000074da185cf449  lea r14, [rax+0x29]
000074da185cf44d  movzx r12d, byte ptr [r13+r14*1]
000074da185cf453  pinsrb xmm15, r12d, 0x0A
000074da185cf45a  lea r14, [rax+0x2A]
000074da185cf45e  movzx r12d, byte ptr [r13+r14*1]
000074da185cf464  pinsrb xmm14, r12d, 0x0A
000074da185cf46b  lea r14, [rax+0x2B]
000074da185cf46f  movzx r12d, byte ptr [r13+r14*1]
000074da185cf475  pinsrb xmm13, r12d, 0x0A
000074da185cf47c  lea r14, [rax+0x2C]
000074da185cf480  movzx r12d, byte ptr [r13+r14*1]
000074da185cf486  pinsrb xmm1, r12d, 0x0B
000074da185cf48d  lea r14, [rax+0x2D]
000074da185cf491  movzx r12d, byte ptr [r13+r14*1]
000074da185cf497  pinsrb xmm15, r12d, 0x0B
000074da185cf49e  lea r14, [rax+0x2E]
000074da185cf4a2  movzx r12d, byte ptr [r13+r14*1]
000074da185cf4a8  pinsrb xmm14, r12d, 0x0B
000074da185cf4af  lea r14, [rax+0x2F]
000074da185cf4b3  movzx r12d, byte ptr [r13+r14*1]
000074da185cf4b9  pinsrb xmm13, r12d, 0x0B
000074da185cf4c0  lea r14, [rax+0x30]
000074da185cf4c4  movzx r12d, byte ptr [r13+r14*1]
000074da185cf4ca  pinsrb xmm1, r12d, 0x0C
000074da185cf4d1  lea r14, [rax+0x31]
000074da185cf4d5  movzx r12d, byte ptr [r13+r14*1]
000074da185cf4db  pinsrb xmm15, r12d, 0x0C
000074da185cf4e2  lea r14, [rax+0x32]
000074da185cf4e6  movzx r12d, byte ptr [r13+r14*1]
000074da185cf4ec  pinsrb xmm14, r12d, 0x0C
000074da185cf4f3  lea r14, [rax+0x33]
000074da185cf4f7  movzx r12d, byte ptr [r13+r14*1]
000074da185cf4fd  pinsrb xmm13, r12d, 0x0C
000074da185cf504  lea r14, [rax+0x34]
000074da185cf508  movzx r12d, byte ptr [r13+r14*1]
000074da185cf50e  pinsrb xmm1, r12d, 0x0D
000074da185cf515  lea r14, [rax+0x35]
000074da185cf519  movzx r12d, byte ptr [r13+r14*1]
000074da185cf51f  pinsrb xmm15, r12d, 0x0D
000074da185cf526  lea r14, [rax+0x36]
000074da185cf52a  movzx r12d, byte ptr [r13+r14*1]
000074da185cf530  pinsrb xmm14, r12d, 0x0D
000074da185cf537  lea r14, [rax+0x37]
000074da185cf53b  movzx r12d, byte ptr [r13+r14*1]
000074da185cf541  pinsrb xmm13, r12d, 0x0D
000074da185cf548  lea r14, [rax+0x38]
000074da185cf54c  movzx r12d, byte ptr [r13+r14*1]
000074da185cf552  pinsrb xmm1, r12d, 0x0E
000074da185cf559  lea r14, [rax+0x39]
000074da185cf55d  movzx r12d, byte ptr [r13+r14*1]
000074da185cf563  pinsrb xmm15, r12d, 0x0E
000074da185cf56a  lea r14, [rax+0x3A]
000074da185cf56e  movzx r12d, byte ptr [r13+r14*1]
000074da185cf574  pinsrb xmm14, r12d, 0x0E
000074da185cf57b  lea r14, [rax+0x3B]
000074da185cf57f  movzx r12d, byte ptr [r13+r14*1]
000074da185cf585  pinsrb xmm13, r12d, 0x0E
000074da185cf58c  lea r14, [rax+0x3C]
000074da185cf590  movzx r12d, byte ptr [r13+r14*1]
000074da185cf596  pinsrb xmm1, r12d, 0x0F
000074da185cf59d  movaps [r15+0x110], xmm1
000074da185cf5a5  lea r14, [rax+0x3D]
000074da185cf5a9  movzx r12d, byte ptr [r13+r14*1]
000074da185cf5af  pinsrb xmm15, r12d, 0x0F
000074da185cf5b6  movaps [r15+0x120], xmm15
000074da185cf5be  lea r14, [rax+0x3E]
000074da185cf5c2  movzx r12d, byte ptr [r13+r14*1]
000074da185cf5c8  pinsrb xmm14, r12d, 0x0F
000074da185cf5cf  movaps [r15+0x130], xmm14
000074da185cf5d7  lea r14, [rax+0x3F]
000074da185cf5db  movzx eax, byte ptr [r13+r14*1]
000074da185cf5e1  pinsrb xmm13, eax, 0x0F
000074da185cf5e8  movaps [r15+0x140], xmm13
000074da185cf5f0  movq xmm1, qword ptr [r15+0x120]
000074da185cf5f9  pmovzxbw xmm1, xmm1
000074da185cf5fe  psllw xmm1, 0x00
000074da185cf603  movaps [r15+0x150], xmm1
000074da185cf60b  movq xmm1, qword ptr [r15+0x130]
000074da185cf614  pmovzxbw xmm1, xmm1
000074da185cf619  psllw xmm1, 0x00
000074da185cf61e  movaps [r15+0x160], xmm1
000074da185cf626  movq xmm1, qword ptr [r15+0x110]
000074da185cf62f  pmovzxbw xmm1, xmm1
000074da185cf634  psllw xmm1, 0x00
000074da185cf639  movaps [r15+0x170], xmm1
000074da185cf641  movaps xmm15, [r15+0x110]
000074da185cf649  pextrq rax, xmm15, 0x01
000074da185cf650  movq xmm15, rax
000074da185cf655  pmovzxbw xmm15, xmm15
000074da185cf65b  psllw xmm15, 0x00
000074da185cf661  movaps [r15+0x180], xmm15
000074da185cf669  movaps xmm14, [r15+0x120]
000074da185cf671  pextrq rax, xmm14, 0x01
000074da185cf678  movq xmm14, rax
000074da185cf67d  pmovzxbw xmm14, xmm14
000074da185cf683  psllw xmm14, 0x00
000074da185cf689  movaps [r15+0x210], xmm14
000074da185cf691  movaps xmm13, [r15+0x130]
000074da185cf699  pextrq rax, xmm13, 0x01
000074da185cf6a0  movq xmm13, rax
000074da185cf6a5  pmovzxbw xmm13, xmm13
000074da185cf6ab  psllw xmm13, 0x00
000074da185cf6b1  movaps [r15+0x220], xmm13
000074da185cf6b9  movq xmm12, qword ptr [r15+0x140]
000074da185cf6c2  pmovzxbw xmm12, xmm12
000074da185cf6c8  psllw xmm12, 0x00
000074da185cf6ce  movaps [r15+0x250], xmm12
000074da185cf6d6  movaps xmm12, [r15+0x140]
000074da185cf6de  pextrq rax, xmm12, 0x01
000074da185cf6e5  movq xmm12, rax
000074da185cf6ea  pmovzxbw xmm12, xmm12
000074da185cf6f0  psllw xmm12, 0x00
000074da185cf6f6  movaps [r15+0x110], xmm12
000074da185cf6fe  movq xmm11, qword ptr [r15+0x150]
000074da185cf707  pmovzxwd xmm11, xmm11
000074da185cf70d  pslld xmm11, 0x10
000074da185cf713  movq xmm10, qword ptr [r15+0x160]
000074da185cf71c  pmovzxwd xmm10, xmm10
000074da185cf722  pslld xmm10, 0x08
000074da185cf728  pextrq rax, xmm1, 0x01
000074da185cf72f  movq xmm1, rax
000074da185cf734  pmovzxwd xmm1, xmm1
000074da185cf739  pslld xmm1, 0x00
000074da185cf73e  movaps [r15+0x260], xmm1
000074da185cf746  pextrq rax, xmm15, 0x01
000074da185cf74d  movq xmm15, rax
000074da185cf752  pmovzxwd xmm15, xmm15
000074da185cf758  pslld xmm15, 0x00
000074da185cf75e  movaps [r15+0x270], xmm15
000074da185cf766  movq xmm9, qword ptr [r15+0x170]
000074da185cf76f  pmovzxwd xmm9, xmm9
000074da185cf775  pslld xmm9, 0x00
000074da185cf77b  pextrq rax, xmm14, 0x01
000074da185cf782  movq xmm14, rax
000074da185cf787  pmovzxwd xmm14, xmm14
000074da185cf78d  pslld xmm14, 0x10
000074da185cf793  movaps [r15+0x280], xmm14
000074da185cf79b  movq xmm8, qword ptr [r15+0x180]
000074da185cf7a4  pmovzxwd xmm8, xmm8
000074da185cf7aa  pslld xmm8, 0x00
000074da185cf7b0  movq xmm7, qword ptr [r15+0x210]
000074da185cf7b9  pmovzxwd xmm7, xmm7
000074da185cf7be  pslld xmm7, 0x10
000074da185cf7c3  movaps xmm6, [r15+0x150]
000074da185cf7cb  pextrq rax, xmm6, 0x01
000074da185cf7d2  movq xmm6, rax
000074da185cf7d7  pmovzxwd xmm6, xmm6
000074da185cf7dc  pslld xmm6, 0x10
000074da185cf7e1  por xmm11, xmm10
000074da185cf7e6  movaps [r15+0x230], xmm11
000074da185cf7ee  pextrq rax, xmm13, 0x01
000074da185cf7f5  movq xmm13, rax
000074da185cf7fa  pmovzxwd xmm13, xmm13
000074da185cf800  pslld xmm13, 0x08
000074da185cf806  movaps [r15+0x240], xmm13
000074da185cf80e  movq xmm10, qword ptr [r15+0x220]
000074da185cf817  pmovzxwd xmm10, xmm10
000074da185cf81d  pslld xmm10, 0x08
000074da185cf823  movaps xmm5, [r15+0x160]
000074da185cf82b  pextrq rax, xmm5, 0x01
000074da185cf832  movq xmm5, rax
000074da185cf837  pmovzxwd xmm5, xmm5
000074da185cf83c  pslld xmm5, 0x08
000074da185cf841  pslld xmm9, 0x18
000074da185cf847  pslld xmm15, 0x18
000074da185cf84d  pslld xmm8, 0x18
000074da185cf853  movq xmm4, qword ptr [r15+0x250]
000074da185cf85c  pmovzxwd xmm4, xmm4
000074da185cf861  pslld xmm4, 0x00
000074da185cf866  por xmm14, xmm13
000074da185cf86b  por xmm7, xmm10
000074da185cf870  movaps [r15+0x210], xmm7
000074da185cf878  pslld xmm1, 0x18
000074da185cf87d  movaps [r15+0x220], xmm1
000074da185cf885  por xmm6, xmm5
000074da185cf889  por xmm11, xmm9
000074da185cf88e  movaps [r15+0x160], xmm11
000074da185cf896  pextrq rax, xmm12, 0x01
000074da185cf89d  movq xmm13, rax
000074da185cf8a2  pmovzxwd xmm13, xmm13
000074da185cf8a8  pslld xmm13, 0x00
000074da185cf8ae  movaps [r15+0x170], xmm13
000074da185cf8b6  movq xmm12, qword ptr [r15+0x110]
000074da185cf8bf  pmovzxwd xmm12, xmm12
000074da185cf8c5  pslld xmm12, 0x00
000074da185cf8cb  por xmm14, xmm15
000074da185cf8d0  por xmm7, xmm8
000074da185cf8d5  movaps xmm15, [r15+0x250]
000074da185cf8dd  pextrq rax, xmm15, 0x01
000074da185cf8e4  movq xmm15, rax
000074da185cf8e9  pmovzxwd xmm15, xmm15
000074da185cf8ef  pslld xmm15, 0x00
000074da185cf8f5  movaps [r15+0x180], xmm15
000074da185cf8fd  por xmm6, xmm1
000074da185cf901  movaps [r15+0x150], xmm6
000074da185cf909  por xmm11, xmm4
000074da185cf90e  movaps [r15+0x140], xmm11
000074da185cf916  por xmm7, xmm12
000074da185cf91b  movaps [r15+0x110], xmm7
000074da185cf923  por xmm14, xmm13
000074da185cf928  movaps [r15+0x120], xmm14
000074da185cf930  por xmm6, xmm15
000074da185cf935  movaps [r15+0x130], xmm6
000074da185cf93d  mov rax, [r15+0xF8]
000074da185cf944  lea r14, [rax+0x20]
000074da185cf948  movups [r13+r14*1], xmm7
000074da185cf94e  lea r14, [rax+0x30]
000074da185cf952  movups [r13+r14*1], xmm14
000074da185cf958  movups [r13+rax*1], xmm11
000074da185cf95e  lea r14, [rax+0x10]
000074da185cf962  movups [r13+r14*1], xmm6
000074da185cf968  mov r14d, [r13+rax*1]
000074da185cf96d  mov rax, [r15+0x48]
000074da185cf971  mov [r15+0x68], rax
000074da185cf975  mov qword ptr [r15+0x58], 0x04
000074da185cf97d  lea r12, [rax+0x04]
000074da185cf981  mov r11d, [r13+r12*1]
000074da185cf986  mov [rsp+0x10], r11d
000074da185cf98b  mov r11d, r11d
000074da185cf98e  mov [r15+0x70], r11
000074da185cf992  lea r12, [rax+0x38]
000074da185cf996  mov r11d, [r13+r12*1]
000074da185cf99b  lea r12, [rax+0x24]
000074da185cf99f  mov r10d, [r13+r12*1]
000074da185cf9a4  mov [rsp+0x20], r10d
000074da185cf9a9  mov r10d, r10d
000074da185cf9ac  mov [r15+0x90], r10
000074da185cf9b3  mov [rsp+0x30], rax
000074da185cf9b8  xor eax, eax
000074da185cf9ba  mov r12d, 0x04
000074da185cf9c0  mov r10d, 0xC0
000074da185cf9c6  cmp r12, r10
000074da185cf9c9  cmc
000074da185cf9ca  lahf
000074da185cf9cb  seto al
000074da185cf9ce  mov [r15+0x108], eax
000074da185cf9d5  mov eax, [rsp+0x10]
000074da185cf9d9  mov r12d, [rsp+0x10]
000074da185cf9de  shrd eax, r12d, 0x07
000074da185cf9e3  mov [rsp+0x10], r11d
000074da185cf9e8  mov r10d, [rsp+0x10]
000074da185cf9ed  shrd r11d, r10d, 0x11
000074da185cf9f2  mov r9d, [rsp+0x20]
000074da185cf9f7  lea r8d, [r9d+r14d*1]
000074da185cf9fc  rorx r14d, r12d, 0x12
000074da185cfa02  xor eax, r14d
000074da185cfa05  rorx r14d, r10d, 0x13
000074da185cfa0b  xor r11d, r14d
000074da185cfa0e  mov [rsp+0x10], r11d
000074da185cfa13  mov r11d, r11d
000074da185cfa16  mov [r15+0x88], r11
000074da185cfa1d  mov [rsp+0x20], r12d
000074da185cfa22  shr r12d, 0x03
000074da185cfa26  xor eax, r12d
000074da185cfa29  mov [rsp+0x40], eax
000074da185cfa2d  mov eax, eax
000074da185cfa2f  mov [r15+0x80], rax
000074da185cfa36  shr r10d, 0x0A
000074da185cfa3a  mov eax, [rsp+0x10]
000074da185cfa3e  xor eax, r10d
000074da185cfa41  mov [rsp+0x10], eax
000074da185cfa45  mov eax, eax
000074da185cfa47  mov [r15+0x78], rax
000074da185cfa4b  mov eax, [rsp+0x40]
000074da185cfa4f  lea r14d, [r8d+eax*1]
000074da185cfa54  mov eax, [rsp+0x10]
000074da185cfa58  lea r12d, [r14d+eax*1]
000074da185cfa5d  mov rax, [rsp+0x30]
000074da185cfa62  lea r14, [rax+0x40]
000074da185cfa66  mov [r13+r14*1], r12d
000074da185cfa6b  mov eax, [rsp+0x20]
000074da185cfa6f  mov eax, eax
000074da185cfa71  mov [r15+0x60], rax
000074da185cfa75  mov eax, [r15+0x108]
000074da185cfa7c  sahf
000074da185cfa7d  jnz 0x000074DA185CFAAF
000074da185cfa7f  cmp dword ptr [r15+0x318], 0x00
000074da185cfa87  jz 0x000074DA185CFF70
000074da185cfa8d  nop [rax+rax*1], ax
000074da185cfa96  nop [rax+rax*1], eax
000074da185cfa9e  mov eax, 0x410820
000074da185cfaa3  mov [r15+0x100], rax
000074da185cfaaa  jmp 0x000074DA183FE110
000074da185cfaaf  cmp dword ptr [r15+0x318], 0x00
000074da185cfab7  jz 0x000074DA185CFDC0
000074da185cfabd  nop [rax+rax*1], ax
000074da185cfac6  nop [rax+rax*1], eax
000074da185cface  mov eax, 0x4107D8
000074da185cfad3  mov [r15+0x100], rax
000074da185cfada  jmp 0x000074DA183FE110
000074da185cfadf  int3
000074da185cfae0  call 0x000074DA1840D860
000074da185cfae5  jmp 0x000074DA185CF17A
000074da185cfaea  call 0x000074DA184E2420
000074da185cfaef  jmp 0x000074DA185CF193
000074da185cfaf4  call 0x000074DA184E2420
000074da185cfaf9  jmp 0x000074DA185CF1AC
000074da185cfafe  call 0x000074DA184E2420
000074da185cfb03  jmp 0x000074DA185CF1C5
000074da185cfb08  call 0x000074DA184E2420
000074da185cfb0d  jmp 0x000074DA185CF1DE
000074da185cfb12  call 0x000074DA184E2420
000074da185cfb17  jmp 0x000074DA185CF1EF
000074da185cfb1c  call 0x000074DA184E2420
000074da185cfb21  jmp 0x000074DA185CF200
000074da185cfb26  call 0x000074DA184E2420
000074da185cfb2b  jmp 0x000074DA185CF211
000074da185cfb30  call 0x000074DA184E2420
000074da185cfb35  jmp 0x000074DA185CF222
000074da185cfb3a  call 0x000074DA184E2420
000074da185cfb3f  jmp 0x000074DA185CF233
000074da185cfb44  call 0x000074DA184E2420
000074da185cfb49  jmp 0x000074DA185CF244
000074da185cfb4e  call 0x000074DA184E2420
000074da185cfb53  jmp 0x000074DA185CF255
000074da185cfb58  call 0x000074DA184E2420
000074da185cfb5d  jmp 0x000074DA185CF266
000074da185cfb62  call 0x000074DA184E2420
000074da185cfb67  jmp 0x000074DA185CF277
000074da185cfb6c  call 0x000074DA184E2420
000074da185cfb71  jmp 0x000074DA185CF288
000074da185cfb76  call 0x000074DA184E2420
000074da185cfb7b  jmp 0x000074DA185CF299
000074da185cfb80  call 0x000074DA184E2420
000074da185cfb85  jmp 0x000074DA185CF2AA
000074da185cfb8a  call 0x000074DA184E2420
000074da185cfb8f  jmp 0x000074DA185CF2BB
000074da185cfb94  call 0x000074DA184E2420
000074da185cfb99  jmp 0x000074DA185CF2CC
000074da185cfb9e  call 0x000074DA184E2420
000074da185cfba3  jmp 0x000074DA185CF2DD
000074da185cfba8  call 0x000074DA184E2420
000074da185cfbad  jmp 0x000074DA185CF2EE
000074da185cfbb2  call 0x000074DA184E2420
000074da185cfbb7  jmp 0x000074DA185CF2FF
000074da185cfbbc  call 0x000074DA184E2420
000074da185cfbc1  jmp 0x000074DA185CF310
000074da185cfbc6  call 0x000074DA184E2420
000074da185cfbcb  jmp 0x000074DA185CF321
000074da185cfbd0  call 0x000074DA184E2420
000074da185cfbd5  jmp 0x000074DA185CF332
000074da185cfbda  call 0x000074DA184E2420
000074da185cfbdf  jmp 0x000074DA185CF343
000074da185cfbe4  call 0x000074DA184E2420
000074da185cfbe9  jmp 0x000074DA185CF354
000074da185cfbee  call 0x000074DA184E2420
000074da185cfbf3  jmp 0x000074DA185CF365
000074da185cfbf8  call 0x000074DA184E2420
000074da185cfbfd  jmp 0x000074DA185CF376
000074da185cfc02  call 0x000074DA184E2420
000074da185cfc07  jmp 0x000074DA185CF387
000074da185cfc0c  call 0x000074DA184E2420
000074da185cfc11  jmp 0x000074DA185CF398
000074da185cfc16  call 0x000074DA184E2420
000074da185cfc1b  jmp 0x000074DA185CF3A9
000074da185cfc20  call 0x000074DA184E2420
000074da185cfc25  jmp 0x000074DA185CF3BA
000074da185cfc2a  call 0x000074DA184E2420
000074da185cfc2f  jmp 0x000074DA185CF3CB
000074da185cfc34  call 0x000074DA184E2420
000074da185cfc39  jmp 0x000074DA185CF3DC
000074da185cfc3e  call 0x000074DA184E2420
000074da185cfc43  jmp 0x000074DA185CF3ED
000074da185cfc48  call 0x000074DA184E2420
000074da185cfc4d  jmp 0x000074DA185CF3FE
000074da185cfc52  call 0x000074DA184E2420
000074da185cfc57  jmp 0x000074DA185CF40F
000074da185cfc5c  call 0x000074DA184E2420
000074da185cfc61  jmp 0x000074DA185CF420
000074da185cfc66  call 0x000074DA184E2420
000074da185cfc6b  jmp 0x000074DA185CF431
000074da185cfc70  call 0x000074DA184E2420
000074da185cfc75  jmp 0x000074DA185CF442
000074da185cfc7a  call 0x000074DA184E2420
000074da185cfc7f  jmp 0x000074DA185CF453
000074da185cfc84  call 0x000074DA184E2420
000074da185cfc89  jmp 0x000074DA185CF464
000074da185cfc8e  call 0x000074DA184E2420
000074da185cfc93  jmp 0x000074DA185CF475
000074da185cfc98  call 0x000074DA184E2420
000074da185cfc9d  jmp 0x000074DA185CF486
000074da185cfca2  call 0x000074DA184E2420
000074da185cfca7  jmp 0x000074DA185CF497
000074da185cfcac  call 0x000074DA184E2420
000074da185cfcb1  jmp 0x000074DA185CF4A8
000074da185cfcb6  call 0x000074DA184E2420
000074da185cfcbb  jmp 0x000074DA185CF4B9
000074da185cfcc0  call 0x000074DA184E2420
000074da185cfcc5  jmp 0x000074DA185CF4CA
000074da185cfcca  call 0x000074DA184E2420
000074da185cfccf  jmp 0x000074DA185CF4DB
000074da185cfcd4  call 0x000074DA184E2420
000074da185cfcd9  jmp 0x000074DA185CF4EC
000074da185cfcde  call 0x000074DA184E2420
000074da185cfce3  jmp 0x000074DA185CF4FD
000074da185cfce8  call 0x000074DA184E2420
000074da185cfced  jmp 0x000074DA185CF50E
000074da185cfcf2  call 0x000074DA184E2420
000074da185cfcf7  jmp 0x000074DA185CF51F
000074da185cfcfc  call 0x000074DA184E2420
000074da185cfd01  jmp 0x000074DA185CF530
000074da185cfd06  call 0x000074DA184E2420
000074da185cfd0b  jmp 0x000074DA185CF541
000074da185cfd10  call 0x000074DA184E2420
000074da185cfd15  jmp 0x000074DA185CF552
000074da185cfd1a  call 0x000074DA184E2420
000074da185cfd1f  jmp 0x000074DA185CF563
000074da185cfd24  call 0x000074DA184E2420
000074da185cfd29  jmp 0x000074DA185CF574
000074da185cfd2e  call 0x000074DA184E2420
000074da185cfd33  jmp 0x000074DA185CF585
000074da185cfd38  call 0x000074DA184E2420
000074da185cfd3d  jmp 0x000074DA185CF596
000074da185cfd42  call 0x000074DA184E2420
000074da185cfd47  jmp 0x000074DA185CF5AF
000074da185cfd4c  call 0x000074DA184E2420
000074da185cfd51  jmp 0x000074DA185CF5C8
000074da185cfd56  call 0x000074DA184D5610
000074da185cfd5b  jmp 0x000074DA185CF5E1
000074da185cfd60  call 0x000074DA184DC580
000074da185cfd65  jmp 0x000074DA185CF94E
000074da185cfd6a  call 0x000074DA184E46C0
000074da185cfd6f  jmp 0x000074DA185CF958
000074da185cfd74  call 0x000074DA18409E90
000074da185cfd79  jmp 0x000074DA185CF95E
000074da185cfd7e  call 0x000074DA184DB310
000074da185cfd83  jmp 0x000074DA185CF968
000074da185cfd88  call 0x000074DA1840DAE0
000074da185cfd8d  jmp 0x000074DA185CF96D
000074da185cfd92  call 0x000074DA184C0230
000074da185cfd97  jmp 0x000074DA185CF986
000074da185cfd9c  call 0x000074DA184C0230
000074da185cfda1  jmp 0x000074DA185CF99B
000074da185cfda6  call 0x000074DA184BEFC0
000074da185cfdab  jmp 0x000074DA185CF9A4
000074da185cfdb0  call 0x000074DA184E2BA0
000074da185cfdb5  jmp 0x000074DA185CFA6B
000074da185cfdba  int3
000074da185cfdbb  nop [rax+rax*1], eax
000074da185cfdc0  mov rax, [r15+0x48]
000074da185cfdc4  mov r14, [r15+0x58]
000074da185cfdc8  lea r12, [rax+r14*1]
000074da185cfdcc  mov [r15+0x68], r12
000074da185cfdd0  lea rax, [r14+0x04]
000074da185cfdd4  mov [r15+0x58], rax
000074da185cfdd8  lea r14, [r12+0x04]
000074da185cfddd  mov r11d, [r13+r14*1]
000074da185cfde2  mov [rsp+0x10], r11d
000074da185cfde7  mov r11d, r11d
000074da185cfdea  mov [r15+0x70], r11
000074da185cfdee  lea r14, [r12+0x38]
000074da185cfdf3  mov r11d, [r13+r14*1]
000074da185cfdf8  lea r14, [r12+0x24]
000074da185cfdfd  mov r10d, [r13+r14*1]
000074da185cfe02  mov [rsp+0x20], r10d
000074da185cfe07  mov r10d, r10d
000074da185cfe0a  mov [r15+0x90], r10
000074da185cfe11  mov [rsp+0x30], rax
000074da185cfe16  xor eax, eax
000074da185cfe18  mov r14, [rsp+0x30]
000074da185cfe1d  mov r10d, 0xC0
000074da185cfe23  cmp r14, r10
000074da185cfe26  cmc
000074da185cfe27  lahf
000074da185cfe28  seto al
000074da185cfe2b  mov [r15+0x108], eax
000074da185cfe32  mov eax, [rsp+0x10]
000074da185cfe36  mov r14d, [rsp+0x10]
000074da185cfe3b  shrd eax, r14d, 0x07
000074da185cfe40  mov [rsp+0x10], r11d
000074da185cfe45  mov r10d, [rsp+0x10]
000074da185cfe4a  shrd r11d, r10d, 0x11
000074da185cfe4f  mov r9d, [r15+0x60]
000074da185cfe53  mov r8d, [rsp+0x20]
000074da185cfe58  lea ebp, [r8d+r9d*1]
000074da185cfe5d  rorx r9d, r14d, 0x12
000074da185cfe63  xor eax, r9d
000074da185cfe66  rorx r9d, r10d, 0x13
000074da185cfe6c  xor r11d, r9d
000074da185cfe6f  mov [rsp+0x10], r11d
000074da185cfe74  mov r11d, r11d
000074da185cfe77  mov [r15+0x88], r11
000074da185cfe7e  mov [rsp+0x20], r14d
000074da185cfe83  shr r14d, 0x03
000074da185cfe87  xor eax, r14d
000074da185cfe8a  mov [rsp+0x30], eax
000074da185cfe8e  mov eax, eax
000074da185cfe90  mov [r15+0x80], rax
000074da185cfe97  shr r10d, 0x0A
000074da185cfe9b  mov eax, [rsp+0x10]
000074da185cfe9f  xor eax, r10d
000074da185cfea2  mov [rsp+0x10], eax
000074da185cfea6  mov eax, eax
000074da185cfea8  mov [r15+0x78], rax
000074da185cfeac  mov eax, [rsp+0x30]
000074da185cfeb0  lea r14d, [ebp+eax*1]
000074da185cfeb6  mov eax, [rsp+0x10]
000074da185cfeba  lea r11d, [r14d+eax*1]
000074da185cfebf  lea rax, [r12+0x40]
000074da185cfec4  mov [r13+rax*1], r11d
000074da185cfec9  mov eax, [rsp+0x20]
000074da185cfecd  mov eax, eax
000074da185cfecf  mov [r15+0x60], rax
000074da185cfed3  mov eax, [r15+0x108]
000074da185cfeda  sahf
000074da185cfedb  jnz 0x000074DA185CFF0D
000074da185cfedd  cmp dword ptr [r15+0x318], 0x00
000074da185cfee5  jz 0x000074DA185CFF70
000074da185cfeeb  nop [rax+rax*1], ax
000074da185cfef4  nop [rax+rax*1], eax
000074da185cfefc  mov eax, 0x410820
000074da185cff01  mov [r15+0x100], rax
000074da185cff08  jmp 0x000074DA183FE110
000074da185cff0d  cmp dword ptr [r15+0x318], 0x00
000074da185cff15  jz 0x000074DA185CFDC0
000074da185cff1b  nop [rax+rax*1], ax
000074da185cff24  nop [rax+rax*1], eax
000074da185cff2c  mov eax, 0x4107D8
000074da185cff31  mov [r15+0x100], rax
000074da185cff38  jmp 0x000074DA183FE110
000074da185cff3d  int3
000074da185cff3e  call 0x000074DA184E1430
000074da185cff43  jmp 0x000074DA185CFDE2
000074da185cff48  call 0x000074DA184E1430
000074da185cff4d  jmp 0x000074DA185CFDF8
000074da185cff52  call 0x000074DA184E01C0
000074da185cff57  jmp 0x000074DA185CFE02
000074da185cff5c  call 0x000074DA1840A860
000074da185cff61  jmp 0x000074DA185CFEC9
000074da185cff66  int3
000074da185cff67  nop [rax+rax*1], ax
000074da185cff70  mov rax, [r15]
000074da185cff73  mov r14d, [r13+rax*1]
000074da185cff78  lea r12, [rax+0x04]
000074da185cff7c  mov r11d, [r13+r12*1]
000074da185cff81  mov [rsp+0x10], r14d
000074da185cff86  mov r14d, r14d
000074da185cff89  mov [r15+0x78], r14
000074da185cff8d  mov [rsp+0x20], r11d
000074da185cff92  mov r11d, r11d
000074da185cff95  mov [r15+0x80], r11
000074da185cff9c  lea r14, [rax+0x08]
000074da185cffa0  mov r12d, [r13+r14*1]
000074da185cffa5  lea r14, [rax+0x0C]
000074da185cffa9  mov r11d, [r13+r14*1]
000074da185cffae  mov [rsp+0x30], r12d
000074da185cffb3  mov r12d, r12d
000074da185cffb6  mov [r15+0x70], r12
000074da185cffba  mov [rsp+0x40], r11d
000074da185cffbf  mov r11d, r11d
000074da185cffc2  mov [r15+0x68], r11
000074da185cffc6  lea r14, [rax+0x18]
000074da185cffca  mov r12d, [r13+r14*1]
000074da185cffcf  lea r14, [rax+0x1C]
000074da185cffd3  mov r11d, [r13+r14*1]
000074da185cffd8  mov [rsp+0x50], r12d
000074da185cffdd  mov r12d, r12d
000074da185cffe0  mov [r15+0x58], r12
000074da185cffe4  mov [rsp+0x60], r11d
000074da185cffe9  mov r11d, r11d
000074da185cffec  mov [r15+0x60], r11
000074da185cfff0  lea r14, [rax+0x10]
000074da185cfff4  mov r12d, [r13+r14*1]
000074da185cfff9  lea r14, [rax+0x14]
000074da185cfffd  mov eax, [r13+r14*1]
000074da185d0002  mov [rsp+0x70], r12d
000074da185d0007  mov r12d, r12d
000074da185d000a  mov [r15+0x18], r12
000074da185d000e  mov [rsp+0x80], eax
000074da185d0015  mov eax, eax
000074da185d0017  mov [r15+0x90], rax
000074da185d001e  mov eax, [rsp+0x70]
000074da185d0022  mov eax, eax
000074da185d0024  mov [r15+0x30], rax
000074da185d0028  mov eax, [rsp+0x50]
000074da185d002c  mov eax, eax
000074da185d002e  mov [r15+0xA0], rax
000074da185d0035  mov eax, [rsp+0x30]
000074da185d0039  mov eax, eax
000074da185d003b  mov [r15+0x28], rax
000074da185d003f  mov eax, [rsp+0x20]
000074da185d0043  mov eax, eax
000074da185d0045  mov [r15+0x98], rax
000074da185d004c  mov eax, [rsp+0x10]
000074da185d0050  mov eax, eax
000074da185d0052  mov [r15+0x38], rax
000074da185d0056  mov eax, [rsp+0x70]
000074da185d005a  mov r14d, [rsp+0x70]
000074da185d005f  shrd eax, r14d, 0x06
000074da185d0064  mov [rsp+0x70], r14d
000074da185d0069  mov r12d, [rsp+0x80]
000074da185d0071  and r14d, r12d
000074da185d0074  mov r11d, [rsp+0x10]
000074da185d0079  mov r10d, [rsp+0x10]
000074da185d007e  shrd r11d, r10d, 0x02
000074da185d0083  mov [rsp+0x10], r12d
000074da185d0088  mov r12d, r12d
000074da185d008b  mov [r15+0x20], r12
000074da185d008f  mov r12, [r15+0x50]
000074da185d0093  mov r9d, [r13+r12*1]
000074da185d0098  mov r12d, [rsp+0x50]
000074da185d009d  mov r8d, [rsp+0x70]
000074da185d00a2  andn ebp, r8d, r12d
000074da185d00a7  mov edi, [rsp+0x60]
000074da185d00ab  lea esi, [r14d+edi*1]
000074da185d00b0  rorx r14d, r8d, 0x0B
000074da185d00b6  xor eax, r14d
000074da185d00b9  rorx r14d, r10d, 0x0D
000074da185d00bf  xor r11d, r14d
000074da185d00c2  lea edi, [esi+ebp*1]
000074da185d00c6  mov r14, [r15+0x48]
000074da185d00ca  mov ebp, [r13+r14*1]
000074da185d00cf  mov r14d, [rsp+0x30]
000074da185d00d4  mov esi, [rsp+0x20]
000074da185d00d8  and r14d, esi
000074da185d00db  mov [rsp+0x20], r14d
000074da185d00e0  mov r14d, r14d
000074da185d00e3  mov [r15+0xD8], r14
000074da185d00ea  lea r14d, [edi+r9d*1]
000074da185d00ef  mov r9d, [rsp+0x30]
000074da185d00f4  xor r9d, esi
000074da185d00f7  rorx edi, r8d, 0x19
000074da185d00fd  xor eax, edi
000074da185d00ff  and r9d, r10d
000074da185d0102  rorx edi, r10d, 0x16
000074da185d0108  xor r11d, edi
000074da185d010b  mov [rsp+0x30], r11d
000074da185d0110  mov r11d, r11d
000074da185d0113  mov [r15+0xD0], r11
000074da185d011a  lea r11d, [r14d+ebp*1]
000074da185d011f  mov r10d, [rsp+0x20]
000074da185d0124  xor r9d, r10d
000074da185d0127  lea r14d, [r11d+eax*1]
000074da185d012c  mov qword ptr [r15+0x88], 0x04
000074da185d0137  mov eax, [rsp+0x30]
000074da185d013b  lea r11d, [r9d+eax*1]
000074da185d0140  mov eax, [rsp+0x40]
000074da185d0144  lea r10d, [r14d+eax*1]
000074da185d0149  mov r10d, r10d
000074da185d014c  mov [r15+0xB8], r10
000074da185d0153  xor eax, eax
000074da185d0155  mov r10d, 0x04
000074da185d015b  mov r9d, 0x100
000074da185d0161  cmp r10, r9
000074da185d0164  cmc
000074da185d0165  lahf
000074da185d0166  seto al
000074da185d0169  mov [r15+0x108], eax
000074da185d0170  lea eax, [r11d+r14d*1]
000074da185d0175  mov eax, eax
000074da185d0177  mov [r15+0xA8], rax
000074da185d017e  mov r12d, r12d
000074da185d0181  mov [r15+0xB0], r12
000074da185d0188  mov eax, [rsp+0x10]
000074da185d018c  mov eax, eax
000074da185d018e  mov [r15+0xC0], rax
000074da185d0195  mov r8d, r8d
000074da185d0198  mov [r15+0xC8], r8
000074da185d019f  mov eax, [r15+0x108]
000074da185d01a6  sahf
000074da185d01a7  jnz 0x000074DA185D01D9
000074da185d01a9  cmp dword ptr [r15+0x318], 0x00
000074da185d01b1  jz 0x000074DA185D04A0
000074da185d01b7  nop [rax+rax*1], ax
000074da185d01c0  nop [rax+rax*1], eax
000074da185d01c8  mov eax, 0x4108E0
000074da185d01cd  mov [r15+0x100], rax
000074da185d01d4  jmp 0x000074DA183FE110
000074da185d01d9  cmp dword ptr [r15+0x318], 0x00
000074da185d01e1  jz 0x000074DA185D0270
000074da185d01e7  nop [rax+rax*1], ax
000074da185d01f0  nop [rax+rax*1], eax
000074da185d01f8  mov eax, 0x410854
000074da185d01fd  mov [r15+0x100], rax
000074da185d0204  jmp 0x000074DA183FE110
000074da185d0209  int3
000074da185d020a  call 0x000074DA1840DAE0
000074da185d020f  jmp 0x000074DA185CFF78
000074da185d0214  call 0x000074DA184C0230
000074da185d0219  jmp 0x000074DA185CFF81
000074da185d021e  call 0x000074DA184E26A0
000074da185d0223  jmp 0x000074DA185CFFA5
000074da185d0228  call 0x000074DA184E1430
000074da185d022d  jmp 0x000074DA185CFFAE
000074da185d0232  call 0x000074DA184E26A0
000074da185d0237  jmp 0x000074DA185CFFCF
000074da185d023c  call 0x000074DA184E1430
000074da185d0241  jmp 0x000074DA185CFFD8
000074da185d0246  call 0x000074DA184E26A0
000074da185d024b  jmp 0x000074DA185CFFF9
000074da185d0250  call 0x000074DA184D5890
000074da185d0255  jmp 0x000074DA185D0002
000074da185d025a  call 0x000074DA184BDD50
000074da185d025f  jmp 0x000074DA185D0098
000074da185d0264  call 0x000074DA184DA580
000074da185d0269  jmp 0x000074DA185D00CF
000074da185d026e  int3
000074da185d026f  nop
000074da185d0270  mov eax, [r15+0xB8]
000074da185d0277  mov [rsp+0x10], eax
000074da185d027b  mov eax, eax
000074da185d027d  mov [r15+0x30], rax
000074da185d0281  mov eax, [r15+0xC0]
000074da185d0288  mov [rsp+0x20], eax
000074da185d028c  mov eax, eax
000074da185d028e  mov [r15+0xA0], rax
000074da185d0295  mov eax, [r15+0x28]
000074da185d0299  mov r14d, [r15+0x98]
000074da185d02a0  mov [rsp+0x30], r14d
000074da185d02a5  mov r14d, r14d
000074da185d02a8  mov [r15+0x28], r14
000074da185d02ac  mov r14d, [r15+0x38]
000074da185d02b0  mov [rsp+0x40], r14d
000074da185d02b5  mov r14d, r14d
000074da185d02b8  mov [r15+0x98], r14
000074da185d02bf  mov r14d, [r15+0xA8]
000074da185d02c6  mov [rsp+0x50], r14d
000074da185d02cb  mov r14d, r14d
000074da185d02ce  mov [r15+0x38], r14
000074da185d02d2  mov r14d, [rsp+0x10]
000074da185d02d7  mov r12d, [rsp+0x10]
000074da185d02dc  shrd r14d, r12d, 0x06
000074da185d02e1  mov r11d, [r15+0xC8]
000074da185d02e8  mov [rsp+0x10], r12d
000074da185d02ed  and r12d, r11d
000074da185d02f0  mov r10d, [rsp+0x50]
000074da185d02f5  mov r9d, [rsp+0x50]
000074da185d02fa  shrd r10d, r9d, 0x02
000074da185d02ff  mov [rsp+0x50], r11d
000074da185d0304  mov r11d, r11d
000074da185d0307  mov [r15+0x20], r11
000074da185d030b  mov r11, [r15+0x88]
000074da185d0312  mov r8, [r15+0x50]
000074da185d0316  lea rbp, [r8+r11*1]
000074da185d031a  mov r8d, [r13+rbp*1]
000074da185d031f  mov ebp, [rsp+0x20]
000074da185d0323  mov edi, [rsp+0x10]
000074da185d0327  andn esi, edi, ebp
000074da185d032c  mov edx, [r15+0xB0]
000074da185d0333  lea ecx, [r12d+edx*1]
000074da185d0338  rorx r12d, edi, 0x0B
000074da185d033e  xor r14d, r12d
000074da185d0341  rorx r12d, r9d, 0x0D
000074da185d0347  xor r10d, r12d
000074da185d034a  lea r12d, [ecx+esi*1]
000074da185d034f  mov rsi, [r15+0x48]
000074da185d0353  lea rdx, [rsi+r11*1]
000074da185d0357  mov esi, [r13+rdx*1]
000074da185d035c  mov edx, [rsp+0x30]
000074da185d0360  mov ecx, [rsp+0x40]
000074da185d0364  and edx, ecx
000074da185d0366  mov [rsp+0x10], edx
000074da185d036a  mov edx, edx
000074da185d036c  mov [r15+0xD8], rdx
000074da185d0373  lea edx, [r12d+r8d*1]
000074da185d0378  mov r12d, [rsp+0x30]
000074da185d037d  xor r12d, ecx
000074da185d0380  rorx r8d, edi, 0x19
000074da185d0386  xor r14d, r8d
000074da185d0389  and r12d, r9d
000074da185d038c  rorx r8d, r9d, 0x16
000074da185d0392  xor r10d, r8d
000074da185d0395  mov [rsp+0x20], r10d
000074da185d039a  mov r10d, r10d
000074da185d039d  mov [r15+0xD0], r10
000074da185d03a4  lea r10d, [edx+esi*1]
000074da185d03a9  mov r9d, [rsp+0x10]
000074da185d03ae  xor r12d, r9d
000074da185d03b1  lea r9d, [r10d+r14d*1]
000074da185d03b6  lea r14, [r11+0x04]
000074da185d03ba  mov [r15+0x88], r14
000074da185d03c1  mov r11d, [rsp+0x20]
000074da185d03c6  lea r10d, [r12d+r11d*1]
000074da185d03cb  lea r11d, [r9d+eax*1]
000074da185d03d0  mov r11d, r11d
000074da185d03d3  mov [r15+0xB8], r11
000074da185d03da  xor eax, eax
000074da185d03dc  mov r12d, 0x100
000074da185d03e2  cmp r14, r12
000074da185d03e5  cmc
000074da185d03e6  lahf
000074da185d03e7  seto al
000074da185d03ea  mov [r15+0x108], eax
000074da185d03f1  lea eax, [r10d+r9d*1]
000074da185d03f6  mov eax, eax
000074da185d03f8  mov [r15+0xA8], rax
000074da185d03ff  mov ebp, ebp
000074da185d0401  mov [r15+0xB0], rbp
000074da185d0408  mov eax, [rsp+0x50]
000074da185d040c  mov eax, eax
000074da185d040e  mov [r15+0xC0], rax
000074da185d0415  mov edi, edi
000074da185d0417  mov [r15+0xC8], rdi
000074da185d041e  mov eax, [r15+0x108]
000074da185d0425  sahf
000074da185d0426  jnz 0x000074DA185D0458
000074da185d0428  cmp dword ptr [r15+0x318], 0x00
000074da185d0430  jz 0x000074DA185D04A0
000074da185d0436  nop [rax+rax*1], ax
000074da185d043f  nop [rax+rax*1], eax
000074da185d0447  mov eax, 0x4108E0
000074da185d044c  mov [r15+0x100], rax
000074da185d0453  jmp 0x000074DA183FE110
000074da185d0458  cmp dword ptr [r15+0x318], 0x00
000074da185d0460  jz 0x000074DA185D0270
000074da185d0466  nop [rax+rax*1], ax
000074da185d046f  nop [rax+rax*1], eax
000074da185d0477  mov eax, 0x410854
000074da185d047c  mov [r15+0x100], rax
000074da185d0483  jmp 0x000074DA183FE110
000074da185d0488  int3
000074da185d0489  call 0x000074DA18449010
000074da185d048e  jmp 0x000074DA185D031F
000074da185d0493  call 0x000074DA18425930
000074da185d0498  jmp 0x000074DA185D035C
000074da185d049d  int3
000074da185d049e  nop
000074da185d04a0  mov eax, [r15+0x98]
000074da185d04a7  mov r14d, [r15+0x70]
000074da185d04ab  lea r12d, [eax+r14d*1]
000074da185d04b0  mov eax, [r15+0x28]
000074da185d04b4  mov r14d, [r15+0x68]
000074da185d04b8  lea r11d, [eax+r14d*1]
000074da185d04bd  mov qword ptr [r15+0x88], 0x00
000074da185d04c8  mov eax, [r15+0xA8]
000074da185d04cf  mov r14d, [r15+0x78]
000074da185d04d3  lea r10d, [eax+r14d*1]
000074da185d04d8  mov [rsp+0x10], r10d
000074da185d04dd  mov r10d, r10d
000074da185d04e0  mov [r15+0x78], r10
000074da185d04e4  mov eax, [r15+0x38]
000074da185d04e8  mov r14d, [r15+0x80]
000074da185d04ef  lea r10d, [eax+r14d*1]
000074da185d04f4  mov [rsp+0x20], r10d
000074da185d04f9  mov r10d, r10d
000074da185d04fc  mov [r15+0x80], r10
000074da185d0503  mov rax, [r15]
000074da185d0506  lea r14, [rax+0x08]
000074da185d050a  mov [r13+r14*1], r12d
000074da185d050f  lea r14, [rax+0x0C]
000074da185d0513  mov [r13+r14*1], r11d
000074da185d0518  mov r14d, [r15+0xB8]
000074da185d051f  mov r12d, [r15+0x18]
000074da185d0523  lea r11d, [r14d+r12d*1]
000074da185d0528  mov [rsp+0x30], r11d
000074da185d052d  mov r11d, r11d
000074da185d0530  mov [r15+0x68], r11
000074da185d0534  mov r14d, [r15+0x30]
000074da185d0538  mov r12d, [r15+0x90]
000074da185d053f  lea r11d, [r14d+r12d*1]
000074da185d0544  mov [rsp+0x40], r11d
000074da185d0549  mov r11d, r11d
000074da185d054c  mov [r15+0x70], r11
000074da185d0550  mov r14d, [r15+0x20]
000074da185d0554  mov r12d, [r15+0x58]
000074da185d0558  lea r11d, [r14d+r12d*1]
000074da185d055d  mov [rsp+0x50], r11d
000074da185d0562  mov r11d, r11d
000074da185d0565  mov [r15+0x58], r11
000074da185d0569  mov r14d, [r15+0xA0]
000074da185d0570  mov r12d, [r15+0x60]
000074da185d0574  lea r11d, [r14d+r12d*1]
000074da185d0579  mov [rsp+0x60], r11d
000074da185d057e  mov r11d, r11d
000074da185d0581  mov [r15+0x60], r11
000074da185d0585  mov r14d, [rsp+0x10]
000074da185d058a  mov [r13+rax*1], r14d
000074da185d058f  lea r14, [rax+0x04]
000074da185d0593  mov r12d, [rsp+0x20]
000074da185d0598  mov [r13+r14*1], r12d
000074da185d059d  lea r14, [rax+0x10]
000074da185d05a1  mov r12d, [rsp+0x30]
000074da185d05a6  mov [r13+r14*1], r12d
000074da185d05ab  lea r14, [rax+0x14]
000074da185d05af  mov r12d, [rsp+0x40]
000074da185d05b4  mov [r13+r14*1], r12d
000074da185d05b9  lea r14, [rax+0x18]
000074da185d05bd  mov r12d, [rsp+0x50]
000074da185d05c2  mov [r13+r14*1], r12d
000074da185d05c7  lea r14, [rax+0x1C]
000074da185d05cb  mov r12d, [rsp+0x60]
000074da185d05d0  mov [r13+r14*1], r12d
000074da185d05d5  lea r14, [rax+0x68]
000074da185d05d9  xor eax, eax
000074da185d05db  mov [r13+r14*1], rax
000074da185d05e0  cmp dword ptr [r15+0x318], 0x00
000074da185d05e8  jz 0x000074DA185CF0E0
000074da185d05ee  nop [rax+rax*1], ax
000074da185d05f7  nop [rax+rax*1], eax
000074da185d05ff  mov eax, 0x4106FC
000074da185d0604  mov [r15+0x100], rax
000074da185d060b  jmp 0x000074DA183FE110
000074da185d0610  int3
000074da185d0611  call 0x000074DA184E2BA0
000074da185d0616  jmp 0x000074DA185D050F
000074da185d061b  call 0x000074DA184E1920
000074da185d0620  jmp 0x000074DA185D0518
000074da185d0625  call 0x000074DA1840DFE0
000074da185d062a  jmp 0x000074DA185D058F
000074da185d062f  call 0x000074DA184E2BA0
000074da185d0634  jmp 0x000074DA185D059D
000074da185d0639  call 0x000074DA184E2BA0
000074da185d063e  jmp 0x000074DA185D05AB
000074da185d0643  call 0x000074DA184E2BA0
000074da185d0648  jmp 0x000074DA185D05B9
000074da185d064d  call 0x000074DA184E2BA0
000074da185d0652  jmp 0x000074DA185D05C7
000074da185d0657  call 0x000074DA184E2BA0
000074da185d065c  jmp 0x000074DA185D05D5
000074da185d0661  call 0x000074DA184D5EB0
000074da185d0666  jmp 0x000074DA185D05E0
000074da185d066b  int3
000074da185d066c  nop [rax], eax
000074da185d0670  mov rax, [r15+0xF8]
000074da185d0677  lea r14, [rax+0x140]
000074da185d067e  mov r12, [r13+r14*1]
000074da185d0683  lea r14, [rax+0x148]
000074da185d068a  mov r11, [r13+r14*1]
000074da185d068f  mov [r15+0xA0], r12
000074da185d0696  mov [r15+0x98], r11
000074da185d069d  lea r14, [rax+0x130]
000074da185d06a4  mov r12, [r13+r14*1]
000074da185d06a9  lea r14, [rax+0x138]
000074da185d06b0  mov r11, [r13+r14*1]
000074da185d06b5  mov [r15+0xB0], r12
000074da185d06bc  mov [r15+0xA8], r11
000074da185d06c3  lea r14, [rax+0x120]
000074da185d06ca  mov r12, [r13+r14*1]
000074da185d06cf  lea r14, [rax+0x128]
000074da185d06d6  mov r11, [r13+r14*1]
000074da185d06db  mov [r15+0xC0], r12
000074da185d06e2  mov [r15+0xB8], r11
000074da185d06e9  lea r14, [rax+0x110]
000074da185d06f0  mov r12, [r13+r14*1]
000074da185d06f5  lea r14, [rax+0x118]
000074da185d06fc  mov r11, [r13+r14*1]
000074da185d0701  mov [r15+0xD0], r12
000074da185d0708  mov [r15+0xC8], r11
000074da185d070f  lea r14, [rax+0x100]
000074da185d0716  mov r12, [r13+r14*1]
000074da185d071b  lea r14, [rax+0x108]
000074da185d0722  mov r11, [r13+r14*1]
000074da185d0727  mov [r15+0xE8], r12
000074da185d072e  mov [r15+0xD8], r11
000074da185d0735  lea r14, [rax+0x150]
000074da185d073c  mov [r15+0xF8], r14
000074da185d0743  mov rax, [r15+0xF0]
000074da185d074a  mov [r15+0x100], rax
000074da185d0751  jmp 0x000074DA185CE5C0
000074da185d0756  int3
000074da185d0757  call 0x000074DA184E27E0
000074da185d075c  jmp 0x000074DA185D0683
000074da185d0761  call 0x000074DA184E1570
000074da185d0766  jmp 0x000074DA185D068F
000074da185d076b  call 0x000074DA184E27E0
000074da185d0770  jmp 0x000074DA185D06A9
000074da185d0775  call 0x000074DA184E1570
000074da185d077a  jmp 0x000074DA185D06B5
000074da185d077f  call 0x000074DA184E27E0
000074da185d0784  jmp 0x000074DA185D06CF
000074da185d0789  call 0x000074DA184E1570
000074da185d078e  jmp 0x000074DA185D06DB
000074da185d0793  call 0x000074DA184E27E0
000074da185d0798  jmp 0x000074DA185D06F5
000074da185d079d  call 0x000074DA184E1570
000074da185d07a2  jmp 0x000074DA185D0701
000074da185d07a7  call 0x000074DA184E27E0
000074da185d07ac  jmp 0x000074DA185D071B
000074da185d07b1  call 0x000074DA184E1570
000074da185d07b6  jmp 0x000074DA185D0727
000074da185d07bb  int3
000074da185d07bc  nop [rax], eax
000074da185d07c0  mov eax, [r15+0xA0]
000074da185d07c7  mov [rsp+0x10], eax
000074da185d07cb  xor eax, eax
000074da185d07cd  mov r14d, [rsp+0x10]
000074da185d07d2  sub r14d, 0x01
000074da185d07d6  cmc
000074da185d07d7  lahf
000074da185d07d8  seto al
000074da185d07db  mov [r15+0x108], eax
000074da185d07e2  mov r14d, r14d
000074da185d07e5  mov [r15+0xA0], r14
000074da185d07ec  mov eax, [r15+0x108]
000074da185d07f3  sahf
000074da185d07f4  jnz 0x000074DA185D0826
000074da185d07f6  cmp dword ptr [r15+0x318], 0x00
000074da185d07fe  jz 0x000074DA185D0900
000074da185d0804  nop [rax+rax*1], ax
000074da185d080d  nop [rax+rax*1], eax
000074da185d0815  mov eax, 0x41028C
000074da185d081a  mov [r15+0x100], rax
000074da185d0821  jmp 0x000074DA183FE110
000074da185d0826  cmp dword ptr [r15+0x318], 0x00
000074da185d082e  jz 0x000074DA185D0860
000074da185d0834  nop [rax+rax*1], ax
000074da185d083d  nop [rax+rax*1], eax
000074da185d0845  mov eax, 0x410274
000074da185d084a  mov [r15+0x100], rax
000074da185d0851  jmp 0x000074DA183FE110
000074da185d0856  int3
000074da185d0857  int3
000074da185d0858  nop [rax+rax*1], eax
000074da185d0860  mov rax, [r15+0xF8]
000074da185d0867  lea r14, [rax+0xD0]
000074da185d086e  mov [r15], r14
000074da185d0871  mov rax, [r15+0x98]
000074da185d0878  mov [r15+0x08], rax
000074da185d087c  mov qword ptr [r15+0x10], 0x12C
000074da185d0884  mov qword ptr [r15+0xF0], 0x410284
000074da185d088f  mov r14d, [r15+0x320]
000074da185d0896  mov eax, 0x410284
000074da185d089b  mov rcx, 0x74DA185D07C0
000074da185d08a5  mov [r15+r14*8+0x328], rax
000074da185d08ad  mov [r15+r14*8+0x368], rcx
000074da185d08b5  add r14d, 0x01
000074da185d08b9  and r14d, 0x07
000074da185d08bd  mov [r15+0x320], r14d
000074da185d08c4  cmp dword ptr [r15+0x318], 0x00
000074da185d08cc  jz 0x000074DA185CED70
000074da185d08d2  nop [rax+rax*1], ax
000074da185d08db  nop [rax+rax*1], eax
000074da185d08e3  mov eax, 0x4106BC
000074da185d08e8  mov [r15+0x100], rax
000074da185d08ef  jmp 0x000074DA183FE110
000074da185d08f4  int3
000074da185d08f5  int3
000074da185d08f6  nop [rax+rax*1], ax
000074da185d08ff  nop
000074da185d0900  mov rax, [r15+0xF8]
000074da185d0907  lea r14, [rax+0xF0]
000074da185d090e  mov r12, [r13+r14*1]
000074da185d0913  mov [r15+0x98], r12
000074da185d091a  mov qword ptr [r15+0x40], 0x80
000074da185d0922  lea r14, [rax+0xD0]
000074da185d0929  mov [r15], r14
000074da185d092c  lea r14, [rax+0x14C]
000074da185d0933  mov [r15+0x08], r14
000074da185d0937  mov qword ptr [r15+0x10], 0x01
000074da185d093f  lea r14, [rax+0x14C]
000074da185d0946  mov eax, 0x80
000074da185d094b  mov [r13+r14*1], al
000074da185d0950  mov qword ptr [r15+0xF0], 0x4102A8
000074da185d095b  mov r14d, [r15+0x320]
000074da185d0962  mov eax, 0x4102A8
000074da185d0967  mov rcx, 0x74DA185D09E0
000074da185d0971  mov [r15+r14*8+0x328], rax
000074da185d0979  mov [r15+r14*8+0x368], rcx
000074da185d0981  add r14d, 0x01
000074da185d0985  and r14d, 0x07
000074da185d0989  mov [r15+0x320], r14d
000074da185d0990  cmp dword ptr [r15+0x318], 0x00
000074da185d0998  jz 0x000074DA185CED70
000074da185d099e  nop [rax+rax*1], ax
000074da185d09a7  nop [rax+rax*1], eax
000074da185d09af  mov eax, 0x4106BC
000074da185d09b4  mov [r15+0x100], rax
000074da185d09bb  jmp 0x000074DA183FE110
000074da185d09c0  int3
000074da185d09c1  call 0x000074DA184E27E0
000074da185d09c6  jmp 0x000074DA185D0913
000074da185d09cb  call 0x000074DA184D5AF0
000074da185d09d0  jmp 0x000074DA185D0950
000074da185d09d5  int3
000074da185d09d6  nop [rax+rax*1], ax
000074da185d09df  nop
000074da185d09e0  mov rax, [r15+0xF8]
000074da185d09e7  lea r14, [rax+0x138]
000074da185d09ee  mov r12, [r13+r14*1]
000074da185d09f3  mov [r15+0x40], r12
000074da185d09f7  lea r14, [rax+0x148]
000074da185d09fe  xor eax, eax
000074da185d0a00  mov [r13+r14*1], al
000074da185d0a05  xor eax, eax
000074da185d0a07  mov r14d, 0x38
000074da185d0a0d  cmp r12, r14
000074da185d0a10  cmc
000074da185d0a11  lahf
000074da185d0a12  seto al
000074da185d0a15  mov [r15+0x108], eax
000074da185d0a1c  mov eax, [r15+0x108]
000074da185d0a23  sahf
000074da185d0a24  jz 0x000074DA185D0A56
000074da185d0a26  cmp dword ptr [r15+0x318], 0x00
000074da185d0a2e  jz 0x000074DA185D0AA0
000074da185d0a34  nop [rax+rax*1], ax
000074da185d0a3d  nop [rax+rax*1], eax
000074da185d0a45  mov eax, 0x4102B8
000074da185d0a4a  mov [r15+0x100], rax
000074da185d0a51  jmp 0x000074DA183FE110
000074da185d0a56  cmp dword ptr [r15+0x318], 0x00
000074da185d0a5e  jz 0x000074DA185D0BF0
000074da185d0a64  nop [rax+rax*1], ax
000074da185d0a6d  nop [rax+rax*1], eax
000074da185d0a75  mov eax, 0x4102D4
000074da185d0a7a  mov [r15+0x100], rax
000074da185d0a81  jmp 0x000074DA183FE110
000074da185d0a86  int3
000074da185d0a87  call 0x000074DA184E27E0
000074da185d0a8c  jmp 0x000074DA185D09F3
000074da185d0a91  call 0x000074DA184D5AF0
000074da185d0a96  jmp 0x000074DA185D0A05
000074da185d0a9b  int3
000074da185d0a9c  nop [rax], eax
000074da185d0aa0  mov rax, [r15+0xF8]
000074da185d0aa7  lea r14, [rax+0xD0]
000074da185d0aae  mov [r15], r14
000074da185d0ab1  lea r14, [rax+0x148]
000074da185d0ab8  mov [r15+0x08], r14
000074da185d0abc  mov qword ptr [r15+0x10], 0x01
000074da185d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000074da185d0acf  mov r14d, [r15+0x320]
000074da185d0ad6  mov eax, 0x4102C8
000074da185d0adb  mov rcx, 0x74DA185D0B40
000074da185d0ae5  mov [r15+r14*8+0x328], rax
000074da185d0aed  mov [r15+r14*8+0x368], rcx
000074da185d0af5  add r14d, 0x01
000074da185d0af9  and r14d, 0x07
000074da185d0afd  mov [r15+0x320], r14d
000074da185d0b04  cmp dword ptr [r15+0x318], 0x00
000074da185d0b0c  jz 0x000074DA185CED70
000074da185d0b12  nop [rax+rax*1], ax
000074da185d0b1b  nop [rax+rax*1], eax
000074da185d0b23  mov eax, 0x4106BC
000074da185d0b28  mov [r15+0x100], rax
000074da185d0b2f  jmp 0x000074DA183FE110
000074da185d0b34  int3
000074da185d0b35  int3
000074da185d0b36  nop [rax+rax*1], ax
000074da185d0b3f  nop
000074da185d0b40  mov rax, [r15+0xF8]
000074da185d0b47  lea r14, [rax+0x138]
000074da185d0b4e  mov rax, [r13+r14*1]
000074da185d0b53  mov [r15+0x40], rax
000074da185d0b57  mov [rsp+0x10], rax
000074da185d0b5c  xor eax, eax
000074da185d0b5e  mov r14, [rsp+0x10]
000074da185d0b63  mov r12d, 0x38
000074da185d0b69  cmp r14, r12
000074da185d0b6c  cmc
000074da185d0b6d  lahf
000074da185d0b6e  seto al
000074da185d0b71  mov [r15+0x108], eax
000074da185d0b78  mov eax, [r15+0x108]
000074da185d0b7f  sahf
000074da185d0b80  jnz 0x000074DA185D0BB2
000074da185d0b82  cmp dword ptr [r15+0x318], 0x00
000074da185d0b8a  jz 0x000074DA185D0BF0
000074da185d0b90  nop [rax+rax*1], ax
000074da185d0b99  nop [rax+rax*1], eax
000074da185d0ba1  mov eax, 0x4102D4
000074da185d0ba6  mov [r15+0x100], rax
000074da185d0bad  jmp 0x000074DA183FE110
000074da185d0bb2  cmp dword ptr [r15+0x318], 0x00
000074da185d0bba  jz 0x000074DA185D0AA0
000074da185d0bc0  nop [rax+rax*1], ax
000074da185d0bc9  nop [rax+rax*1], eax
000074da185d0bd1  mov eax, 0x4102B8
000074da185d0bd6  mov [r15+0x100], rax
000074da185d0bdd  jmp 0x000074DA183FE110
000074da185d0be2  int3
000074da185d0be3  call 0x000074DA184D59C0
000074da185d0be8  jmp 0x000074DA185D0B53
000074da185d0bed  int3
000074da185d0bee  nop
000074da185d0bf0  mov rax, [r15+0x98]
000074da185d0bf7  rorx r14, rax, 0x3D
000074da185d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000074da185d0c01  mov rax, [r15+0xF8]
000074da185d0c08  lea r12, [rax+0xD0]
000074da185d0c0f  mov [r15], r12
000074da185d0c12  lea r12, [rax+0x140]
000074da185d0c19  mov [r15+0x08], r12
000074da185d0c1d  mov qword ptr [r15+0x10], 0x08
000074da185d0c25  bswap r14
000074da185d0c28  mov [r15+0x40], r14
000074da185d0c2c  lea r12, [rax+0x140]
000074da185d0c33  mov [r13+r12*1], r14
000074da185d0c38  mov qword ptr [r15+0xF0], 0x4102F0
000074da185d0c43  mov r14d, [r15+0x320]
000074da185d0c4a  mov eax, 0x4102F0
000074da185d0c4f  mov rcx, 0x74DA185D0CC0
000074da185d0c59  mov [r15+r14*8+0x328], rax
000074da185d0c61  mov [r15+r14*8+0x368], rcx
000074da185d0c69  add r14d, 0x01
000074da185d0c6d  and r14d, 0x07
000074da185d0c71  mov [r15+0x320], r14d
000074da185d0c78  cmp dword ptr [r15+0x318], 0x00
000074da185d0c80  jz 0x000074DA185CED70
000074da185d0c86  nop [rax+rax*1], ax
000074da185d0c8f  nop [rax+rax*1], eax
000074da185d0c97  mov eax, 0x4106BC
000074da185d0c9c  mov [r15+0x100], rax
000074da185d0ca3  jmp 0x000074DA183FE110
000074da185d0ca8  int3
000074da185d0ca9  call 0x000074DA184C3FE0
000074da185d0cae  jmp 0x000074DA185D0C38
000074da185d0cb3  int3
000074da185d0cb4  nop [rax+rax*1], ax
000074da185d0cbd  nop [rax], eax
000074da185d0cc0  mov rax, [r15+0xF8]
000074da185d0cc7  lea r14, [rax+0xD0]
000074da185d0cce  mov r12d, [r13+r14*1]
000074da185d0cd3  lea r14, [rax+0xD4]
000074da185d0cda  mov r11d, [r13+r14*1]
000074da185d0cdf  lea r14, [rax+0xD8]
000074da185d0ce6  mov r10d, [r13+r14*1]
000074da185d0ceb  lea r14, [rax+0xDC]
000074da185d0cf2  mov r9d, [r13+r14*1]
000074da185d0cf7  mov qword ptr [r15+0x48], 0x430C20
000074da185d0cff  mov qword ptr [r15+0xA0], 0x00
000074da185d0d0a  bswap r12d
000074da185d0d0d  bswap r11d
000074da185d0d10  mov qword ptr [r15+0x98], 0x430D8C
000074da185d0d1b  mov r14d, 0x430C20
000074da185d0d21  mov [r13+r14*1], r12d
000074da185d0d26  mov r14d, 0x430C24
000074da185d0d2c  mov [r13+r14*1], r11d
000074da185d0d31  bswap r10d
000074da185d0d34  bswap r9d
000074da185d0d37  lea r14, [rax+0xE0]
000074da185d0d3e  mov r12d, [r13+r14*1]
000074da185d0d43  lea r14, [rax+0xE4]
000074da185d0d4a  mov r11d, [r13+r14*1]
000074da185d0d4f  mov r14d, 0x430C28
000074da185d0d55  mov [r13+r14*1], r10d
000074da185d0d5a  mov r14d, 0x430C2C
000074da185d0d60  mov [r13+r14*1], r9d
000074da185d0d65  bswap r12d
000074da185d0d68  bswap r11d
000074da185d0d6b  mov [rsp+0x10], r11d
000074da185d0d70  mov r11d, r11d
000074da185d0d73  mov [r15+0x58], r11
000074da185d0d77  lea r14, [rax+0xE8]
000074da185d0d7e  mov r11d, [r13+r14*1]
000074da185d0d83  lea r14, [rax+0xEC]
000074da185d0d8a  mov eax, [r13+r14*1]
000074da185d0d8f  mov [rsp+0x20], eax
000074da185d0d93  mov eax, eax
000074da185d0d95  mov [r15+0x60], rax
000074da185d0d99  mov eax, 0x430C30
000074da185d0d9e  mov [r13+rax*1], r12d
000074da185d0da3  mov eax, 0x430C34
000074da185d0da8  mov r14d, [rsp+0x10]
000074da185d0dad  mov [r13+rax*1], r14d
000074da185d0db2  bswap r11d
000074da185d0db5  mov [rsp+0x10], r11d
000074da185d0dba  mov r11d, r11d
000074da185d0dbd  mov [r15+0x40], r11
000074da185d0dc1  mov eax, [rsp+0x20]
000074da185d0dc5  bswap eax
000074da185d0dc7  mov [rsp+0x20], eax
000074da185d0dcb  mov eax, eax
000074da185d0dcd  mov [r15+0x50], rax
000074da185d0dd1  mov eax, 0x430C38
000074da185d0dd6  mov r14d, [rsp+0x10]
000074da185d0ddb  mov [r13+rax*1], r14d
000074da185d0de0  mov eax, 0x430C3C
000074da185d0de5  mov r14d, [rsp+0x20]
000074da185d0dea  mov [r13+rax*1], r14d
000074da185d0def  mov eax, [r15+0xA0]
000074da185d0df6  lea r14d, [eax+0x11]
000074da185d0dfb  mov r14d, r14d
000074da185d0dfe  mov [r15], r14
000074da185d0e01  mov qword ptr [r15+0xF0], 0x41034C
000074da185d0e0c  mov r14d, [r15+0x320]
000074da185d0e13  mov eax, 0x41034C
000074da185d0e18  mov rcx, 0x74DA185D0F90
000074da185d0e22  mov [r15+r14*8+0x328], rax
000074da185d0e2a  mov [r15+r14*8+0x368], rcx
000074da185d0e32  add r14d, 0x01
000074da185d0e36  and r14d, 0x07
000074da185d0e3a  mov [r15+0x320], r14d
000074da185d0e41  cmp dword ptr [r15+0x318], 0x00
000074da185d0e49  jz 0x000074DA185D0F20
000074da185d0e4f  nop [rax+rax*1], ax
000074da185d0e58  nop [rax+rax*1], eax
000074da185d0e60  mov eax, 0x410938
000074da185d0e65  mov [r15+0x100], rax
000074da185d0e6c  jmp 0x000074DA183FE110
000074da185d0e71  int3
000074da185d0e72  call 0x000074DA184E26A0
000074da185d0e77  jmp 0x000074DA185D0CD3
000074da185d0e7c  call 0x000074DA184E1430
000074da185d0e81  jmp 0x000074DA185D0CDF
000074da185d0e86  call 0x000074DA184E01C0
000074da185d0e8b  jmp 0x000074DA185D0CEB
000074da185d0e90  call 0x000074DA184DEF50
000074da185d0e95  jmp 0x000074DA185D0CF7
000074da185d0e9a  call 0x000074DA184E2BA0
000074da185d0e9f  jmp 0x000074DA185D0D26
000074da185d0ea4  call 0x000074DA184E1920
000074da185d0ea9  jmp 0x000074DA185D0D31
000074da185d0eae  call 0x000074DA184E26A0
000074da185d0eb3  jmp 0x000074DA185D0D43
000074da185d0eb8  call 0x000074DA184E1430
000074da185d0ebd  jmp 0x000074DA185D0D4F
000074da185d0ec2  call 0x000074DA184E06B0
000074da185d0ec7  jmp 0x000074DA185D0D5A
000074da185d0ecc  call 0x000074DA184DF440
000074da185d0ed1  jmp 0x000074DA185D0D65
000074da185d0ed6  call 0x000074DA184E1430
000074da185d0edb  jmp 0x000074DA185D0D83
000074da185d0ee0  call 0x000074DA184D5890
000074da185d0ee5  jmp 0x000074DA185D0D8F
000074da185d0eea  call 0x000074DA1840BAE0
000074da185d0eef  jmp 0x000074DA185D0DA3
000074da185d0ef4  call 0x000074DA1840DFE0
000074da185d0ef9  jmp 0x000074DA185D0DB2
000074da185d0efe  call 0x000074DA1840DFE0
000074da185d0f03  jmp 0x000074DA185D0DE0
000074da185d0f08  call 0x000074DA1840DFE0
000074da185d0f0d  jmp 0x000074DA185D0DEF
000074da185d0f12  int3
000074da185d0f13  nop [rax+rax*1], ax
000074da185d0f1c  nop [rax], eax
000074da185d0f20  mov eax, [r15]
000074da185d0f23  mov [rsp+0x10], eax
000074da185d0f27  shr eax, 0x10
000074da185d0f2a  mov r14d, [rsp+0x10]
000074da185d0f2f  xor r14d, eax
000074da185d0f32  imul r14d, r14d, 0x7FEB352D
000074da185d0f39  mov eax, 0x846CA68B
000074da185d0f3e  mov eax, eax
000074da185d0f40  mov [r15+0x48], rax
000074da185d0f44  mov [rsp+0x10], r14d
000074da185d0f49  shr r14d, 0x0F
000074da185d0f4d  mov eax, [rsp+0x10]
000074da185d0f51  xor eax, r14d
000074da185d0f54  imul eax, eax, 0x846CA68B
000074da185d0f5a  mov [rsp+0x10], eax
000074da185d0f5e  mov eax, eax
000074da185d0f60  mov [r15+0x40], rax
000074da185d0f64  mov eax, [rsp+0x10]
000074da185d0f68  shr eax, 0x10
000074da185d0f6b  mov r14d, [rsp+0x10]
000074da185d0f70  xor r14d, eax
000074da185d0f73  mov r14d, r14d
000074da185d0f76  mov [r15], r14
000074da185d0f79  mov rax, [r15+0xF0]
000074da185d0f80  mov [r15+0x100], rax
000074da185d0f87  jmp 0x000074DA185CE5C0
000074da185d0f8c  int3
000074da185d0f8d  int3
000074da185d0f8e  nop
000074da185d0f90  mov rax, [r15+0xA0]
000074da185d0f97  mov [rsp+0x10], rax
000074da185d0f9c  shl rax, 0x02
000074da185d0fa0  mov r14, [r15+0x98]
000074da185d0fa7  lea r12, [r14+rax*1]
000074da185d0fab  mov eax, [r15]
000074da185d0fae  mov [r13+r12*1], eax
000074da185d0fb3  mov rax, [rsp+0x10]
000074da185d0fb8  lea r14, [rax+0x01]
000074da185d0fbc  mov [r15+0xA0], r14
000074da185d0fc3  xor eax, eax
000074da185d0fc5  mov r12d, 0x400
000074da185d0fcb  cmp r14, r12
000074da185d0fce  cmc
000074da185d0fcf  lahf
000074da185d0fd0  seto al
000074da185d0fd3  mov [r15+0x108], eax
000074da185d0fda  mov eax, [r15+0x108]
000074da185d0fe1  sahf
000074da185d0fe2  jnz 0x000074DA185D1014
000074da185d0fe4  cmp dword ptr [r15+0x318], 0x00
000074da185d0fec  jz 0x000074DA185D10E0
000074da185d0ff2  nop [rax+rax*1], ax
000074da185d0ffb  nop [rax+rax*1], eax
000074da185d1003  mov eax, 0x41035C
000074da185d1008  mov [r15+0x100], rax
000074da185d100f  jmp 0x000074DA183FE110
000074da185d1014  cmp dword ptr [r15+0x318], 0x00
000074da185d101c  jz 0x000074DA185D1050
000074da185d1022  nop [rax+rax*1], ax
000074da185d102b  nop [rax+rax*1], eax
000074da185d1033  mov eax, 0x410344
000074da185d1038  mov [r15+0x100], rax
000074da185d103f  jmp 0x000074DA183FE110
000074da185d1044  int3
000074da185d1045  call 0x000074DA184B4B70
000074da185d104a  jmp 0x000074DA185D0FB3
000074da185d104f  int3
000074da185d1050  mov eax, [r15+0xA0]
000074da185d1057  lea r14d, [eax+0x11]
000074da185d105c  mov r14d, r14d
000074da185d105f  mov [r15], r14
000074da185d1062  mov qword ptr [r15+0xF0], 0x41034C
000074da185d106d  mov r14d, [r15+0x320]
000074da185d1074  mov eax, 0x41034C
000074da185d1079  mov rcx, 0x74DA185D0F90
000074da185d1083  mov [r15+r14*8+0x328], rax
000074da185d108b  mov [r15+r14*8+0x368], rcx
000074da185d1093  add r14d, 0x01
000074da185d1097  and r14d, 0x07
000074da185d109b  mov [r15+0x320], r14d
000074da185d10a2  cmp dword ptr [r15+0x318], 0x00
000074da185d10aa  jz 0x000074DA185D0F20
000074da185d10b0  nop [rax+rax*1], ax
000074da185d10b9  nop [rax+rax*1], eax
000074da185d10c1  mov eax, 0x410938
000074da185d10c6  mov [r15+0x100], rax
000074da185d10cd  jmp 0x000074DA183FE110
000074da185d10d2  int3
000074da185d10d3  int3
000074da185d10d4  nop [rax+rax*1], ax
000074da185d10dd  nop [rax], eax
000074da185d10e0  mov qword ptr [r15+0x40], 0x01
000074da185d10e8  cmp dword ptr [r15+0x318], 0x00
000074da185d10f0  jz 0x000074DA185D1120
000074da185d10f6  nop [rax+rax*1], ax
000074da185d10ff  nop [rax+rax*1], eax
000074da185d1107  mov eax, 0x410378
000074da185d110c  mov [r15+0x100], rax
000074da185d1113  jmp 0x000074DA183FE110
000074da185d1118  int3
000074da185d1119  int3
000074da185d111a  nop [rax+rax*1], ax
000074da185d1120  mov rax, [r15+0x40]
000074da185d1124  mov [rsp+0x10], rax
000074da185d1129  shl rax, 0x02
000074da185d112d  mov r14, [r15+0x98]
000074da185d1134  lea r12, [r14+rax*1]
000074da185d1138  mov eax, [r13+r12*1]
000074da185d113d  mov [rsp+0x20], eax
000074da185d1141  mov eax, eax
000074da185d1143  mov [r15+0x48], rax
000074da185d1147  mov rax, [rsp+0x10]
000074da185d114c  mov [r15+0x50], rax
000074da185d1150  mov eax, [r15+0x50]
000074da185d1154  lea r12d, [eax-0x01]
000074da185d1159  mov r12d, r12d
000074da185d115c  mov [r15+0x58], r12
000074da185d1160  mov rax, [r15+0x58]
000074da185d1164  mov r12d, eax
000074da185d1167  mov r12d, r12d
000074da185d116a  shl r12, 0x02
000074da185d116e  lea rax, [r14+r12*1]
000074da185d1172  mov r14d, [r13+rax*1]
000074da185d1177  mov [rsp+0x10], r14d
000074da185d117c  mov r14d, r14d
000074da185d117f  mov [r15+0x60], r14
000074da185d1183  xor eax, eax
000074da185d1185  mov r14d, [rsp+0x10]
000074da185d118a  mov r12d, [rsp+0x20]
000074da185d118f  cmp r14d, r12d
000074da185d1192  cmc
000074da185d1193  lahf
000074da185d1194  seto al
000074da185d1197  mov [r15+0x108], eax
000074da185d119e  mov eax, [r15+0x108]
000074da185d11a5  sahf
000074da185d11a6  cmc
000074da185d11a7  jbe 0x000074DA185D11D9
000074da185d11a9  cmp dword ptr [r15+0x318], 0x00
000074da185d11b1  jz 0x000074DA185D1220
000074da185d11b7  nop [rax+rax*1], ax
000074da185d11c0  nop [rax+rax*1], eax
000074da185d11c8  mov eax, 0x410390
000074da185d11cd  mov [r15+0x100], rax
000074da185d11d4  jmp 0x000074DA183FE110
000074da185d11d9  cmp dword ptr [r15+0x318], 0x00
000074da185d11e1  jz 0x000074DA185D14C0
000074da185d11e7  nop [rax+rax*1], ax
000074da185d11f0  nop [rax+rax*1], eax
000074da185d11f8  mov eax, 0x410368
000074da185d11fd  mov [r15+0x100], rax
000074da185d1204  jmp 0x000074DA183FE110
000074da185d1209  int3
000074da185d120a  call 0x000074DA184B4690
000074da185d120f  jmp 0x000074DA185D113D
000074da185d1214  call 0x000074DA1840DAE0
000074da185d1219  jmp 0x000074DA185D1177
000074da185d121e  int3
000074da185d121f  nop
000074da185d1220  mov rax, [r15+0x50]
000074da185d1224  mov [rsp+0x10], rax
000074da185d1229  shl rax, 0x02
000074da185d122d  mov r14, [r15+0x98]
000074da185d1234  lea r12, [r14+rax*1]
000074da185d1238  mov eax, [r15+0x60]
000074da185d123c  mov [r13+r12*1], eax
000074da185d1241  mov rax, [rsp+0x10]
000074da185d1246  lea r14, [rax-0x01]
000074da185d124a  mov [r15+0x50], r14
000074da185d124e  mov rax, [r15+0x58]
000074da185d1252  test rax, rax
000074da185d1255  setz al
000074da185d1258  movzx rax, al
000074da185d125c  mov [rsp+0x414], al
000074da185d1263  cmp byte ptr [rsp+0x414], 0x00
000074da185d126b  jz 0x000074DA185D129D
000074da185d126d  cmp dword ptr [r15+0x318], 0x00
000074da185d1275  jz 0x000074DA185D12E0
000074da185d127b  nop [rax+rax*1], ax
000074da185d1284  nop [rax+rax*1], eax
000074da185d128c  mov eax, 0x41039C
000074da185d1291  mov [r15+0x100], rax
000074da185d1298  jmp 0x000074DA183FE110
000074da185d129d  cmp dword ptr [r15+0x318], 0x00
000074da185d12a5  jz 0x000074DA185D13E0
000074da185d12ab  nop [rax+rax*1], ax
000074da185d12b4  nop [rax+rax*1], eax
000074da185d12bc  mov eax, 0x410380
000074da185d12c1  mov [r15+0x100], rax
000074da185d12c8  jmp 0x000074DA183FE110
000074da185d12cd  int3
000074da185d12ce  call 0x000074DA184B4B70
000074da185d12d3  jmp 0x000074DA185D1241
000074da185d12d8  int3
000074da185d12d9  nop [rax], eax
000074da185d12e0  cmp dword ptr [r15+0x318], 0x00
000074da185d12e8  jz 0x000074DA185D1320
000074da185d12ee  nop [rax+rax*1], ax
000074da185d12f7  nop [rax+rax*1], eax
000074da185d12ff  mov eax, 0x410364
000074da185d1304  mov [r15+0x100], rax
000074da185d130b  jmp 0x000074DA183FE110
000074da185d1310  int3
000074da185d1311  int3
000074da185d1312  nop [rax+rax*1], ax
000074da185d131b  nop [rax+rax*1], eax
000074da185d1320  mov qword ptr [r15+0x50], 0x00
000074da185d1328  mov rax, [r15+0x40]
000074da185d132c  lea r14, [rax+0x01]
000074da185d1330  mov [r15+0x40], r14
000074da185d1334  mov rax, [r15+0x98]
000074da185d133b  mov r12d, [r15+0x48]
000074da185d133f  mov [r13+rax*1], r12d
000074da185d1344  xor eax, eax
000074da185d1346  mov r12d, 0x400
000074da185d134c  cmp r14, r12
000074da185d134f  cmc
000074da185d1350  lahf
000074da185d1351  seto al
000074da185d1354  mov [r15+0x108], eax
000074da185d135b  mov eax, [r15+0x108]
000074da185d1362  sahf
000074da185d1363  jz 0x000074DA185D1395
000074da185d1365  cmp dword ptr [r15+0x318], 0x00
000074da185d136d  jz 0x000074DA185D1120
000074da185d1373  nop [rax+rax*1], ax
000074da185d137c  nop [rax+rax*1], eax
000074da185d1384  mov eax, 0x410378
000074da185d1389  mov [r15+0x100], rax
000074da185d1390  jmp 0x000074DA183FE110
000074da185d1395  cmp dword ptr [r15+0x318], 0x00
000074da185d139d  jz 0x000074DA185D1580
000074da185d13a3  nop [rax+rax*1], ax
000074da185d13ac  nop [rax+rax*1], eax
000074da185d13b4  mov eax, 0x4103A0
000074da185d13b9  mov [r15+0x100], rax
000074da185d13c0  jmp 0x000074DA183FE110
000074da185d13c5  int3
000074da185d13c6  call 0x000074DA1840BAE0
000074da185d13cb  jmp 0x000074DA185D1344
000074da185d13d0  int3
000074da185d13d1  nop [rax+rax*1], ax
000074da185d13da  nop [rax+rax*1], ax
000074da185d13e0  mov eax, [r15+0x50]
000074da185d13e4  lea r14d, [eax-0x01]
000074da185d13e9  mov r14d, r14d
000074da185d13ec  mov [r15+0x58], r14
000074da185d13f0  mov rax, [r15+0x58]
000074da185d13f4  mov r14d, eax
000074da185d13f7  mov r14d, r14d
000074da185d13fa  shl r14, 0x02
000074da185d13fe  mov rax, [r15+0x98]
000074da185d1405  lea r12, [rax+r14*1]
000074da185d1409  mov eax, [r13+r12*1]
000074da185d140e  mov [rsp+0x10], eax
000074da185d1412  mov eax, eax
000074da185d1414  mov [r15+0x60], rax
000074da185d1418  mov eax, [r15+0x48]
000074da185d141c  mov [rsp+0x20], eax
000074da185d1420  xor eax, eax
000074da185d1422  mov r14d, [rsp+0x10]
000074da185d1427  mov r12d, [rsp+0x20]
000074da185d142c  cmp r14d, r12d
000074da185d142f  cmc
000074da185d1430  lahf
000074da185d1431  seto al
000074da185d1434  mov [r15+0x108], eax
000074da185d143b  mov eax, [r15+0x108]
000074da185d1442  sahf
000074da185d1443  cmc
000074da185d1444  jbe 0x000074DA185D1476
000074da185d1446  cmp dword ptr [r15+0x318], 0x00
000074da185d144e  jz 0x000074DA185D1220
000074da185d1454  nop [rax+rax*1], ax
000074da185d145d  nop [rax+rax*1], eax
000074da185d1465  mov eax, 0x410390
000074da185d146a  mov [r15+0x100], rax
000074da185d1471  jmp 0x000074DA183FE110
000074da185d1476  cmp dword ptr [r15+0x318], 0x00
000074da185d147e  jz 0x000074DA185D14C0
000074da185d1484  nop [rax+rax*1], ax
000074da185d148d  nop [rax+rax*1], eax
000074da185d1495  mov eax, 0x410368
000074da185d149a  mov [r15+0x100], rax
000074da185d14a1  jmp 0x000074DA183FE110
000074da185d14a6  int3
000074da185d14a7  call 0x000074DA184B4690
000074da185d14ac  jmp 0x000074DA185D140E
000074da185d14b1  int3
000074da185d14b2  nop [rax+rax*1], ax
000074da185d14bb  nop [rax+rax*1], eax
000074da185d14c0  mov rax, [r15+0x40]
000074da185d14c4  lea r14, [rax+0x01]
000074da185d14c8  mov [r15+0x40], r14
000074da185d14cc  mov rax, [r15+0x50]
000074da185d14d0  mov r12d, eax
000074da185d14d3  mov r12d, r12d
000074da185d14d6  shl r12, 0x02
000074da185d14da  mov rax, [r15+0x98]
000074da185d14e1  lea r11, [rax+r12*1]
000074da185d14e5  mov eax, [r15+0x48]
000074da185d14e9  mov [r13+r11*1], eax
000074da185d14ee  xor eax, eax
000074da185d14f0  mov r12d, 0x400
000074da185d14f6  cmp r14, r12
000074da185d14f9  cmc
000074da185d14fa  lahf
000074da185d14fb  seto al
000074da185d14fe  mov [r15+0x108], eax
000074da185d1505  mov eax, [r15+0x108]
000074da185d150c  sahf
000074da185d150d  jz 0x000074DA185D153F
000074da185d150f  cmp dword ptr [r15+0x318], 0x00
000074da185d1517  jz 0x000074DA185D1120
000074da185d151d  nop [rax+rax*1], ax
000074da185d1526  nop [rax+rax*1], eax
000074da185d152e  mov eax, 0x410378
000074da185d1533  mov [r15+0x100], rax
000074da185d153a  jmp 0x000074DA183FE110
000074da185d153f  cmp dword ptr [r15+0x318], 0x00
000074da185d1547  jz 0x000074DA185D1580
000074da185d154d  nop [rax+rax*1], ax
000074da185d1556  nop [rax+rax*1], eax
000074da185d155e  mov eax, 0x4103A0
000074da185d1563  mov [r15+0x100], rax
000074da185d156a  jmp 0x000074DA183FE110
000074da185d156f  int3
000074da185d1570  call 0x000074DA184A4270
000074da185d1575  jmp 0x000074DA185D14EE
000074da185d157a  int3
000074da185d157b  nop [rax+rax*1], eax
000074da185d1580  mov qword ptr [r15+0x40], 0x430000
000074da185d1588  mov eax, 0x430C40
000074da185d158d  mov r14, [r13+rax*1]
000074da185d1592  mov rax, [r15+0x98]
000074da185d1599  mov r12d, [r13+rax*1]
000074da185d159e  lea r11, [rax+0x04]
000074da185d15a2  mov eax, [r13+r11*1]
000074da185d15a7  mov r12d, r12d
000074da185d15aa  mov [r15+0x68], r12
000074da185d15ae  mov eax, eax
000074da185d15b0  mov [r15+0x60], rax
000074da185d15b4  mov rax, [r15+0x68]
000074da185d15b8  mov [r15+0x68], rax
000074da185d15bc  mov qword ptr [r15+0x58], 0x02
000074da185d15c4  mov [rsp+0x10], rax
000074da185d15c9  xor eax, eax
000074da185d15cb  mov r12d, 0x02
000074da185d15d1  mov r11d, 0x400
000074da185d15d7  cmp r12, r11
000074da185d15da  cmc
000074da185d15db  lahf
000074da185d15dc  seto al
000074da185d15df  mov [r15+0x108], eax
000074da185d15e6  mov rax, [r15+0x60]
000074da185d15ea  mov r12d, 0x02
000074da185d15f0  imul rax, r12
000074da185d15f4  mov [r15+0x50], rax
000074da185d15f8  mov rax, [rsp+0x10]
000074da185d15fd  lea r12, [rax+r14*1]
000074da185d1601  mov [r15+0x48], r12
000074da185d1605  mov eax, [r15+0x108]
000074da185d160c  sahf
000074da185d160d  jnz 0x000074DA185D163F
000074da185d160f  cmp dword ptr [r15+0x318], 0x00
000074da185d1617  jz 0x000074DA185D17B0
000074da185d161d  nop [rax+rax*1], ax
000074da185d1626  nop [rax+rax*1], eax
000074da185d162e  mov eax, 0x4103D0
000074da185d1633  mov [r15+0x100], rax
000074da185d163a  jmp 0x000074DA183FE110
000074da185d163f  cmp dword ptr [r15+0x318], 0x00
000074da185d1647  jz 0x000074DA185D1690
000074da185d164d  nop [rax+rax*1], ax
000074da185d1656  nop [rax+rax*1], eax
000074da185d165e  mov eax, 0x4103B0
000074da185d1663  mov [r15+0x100], rax
000074da185d166a  jmp 0x000074DA183FE110
000074da185d166f  int3
000074da185d1670  call 0x000074DA1840DC20
000074da185d1675  jmp 0x000074DA185D1592
000074da185d167a  call 0x000074DA1840B5E0
000074da185d167f  jmp 0x000074DA185D159E
000074da185d1684  call 0x000074DA184A3D90
000074da185d1689  jmp 0x000074DA185D15A7
000074da185d168e  int3
000074da185d168f  nop
000074da185d1690  mov rax, [r15+0x98]
000074da185d1697  mov r14, [r15+0x58]
000074da185d169b  mov [rsp+0x10], r14
000074da185d16a0  shl r14, 0x02
000074da185d16a4  lea r12, [rax+r14*1]
000074da185d16a8  mov eax, [r13+r12*1]
000074da185d16ad  lea r14, [r12+0x04]
000074da185d16b2  mov r12d, [r13+r14*1]
000074da185d16b7  mov eax, eax
000074da185d16b9  mov [r15+0x68], rax
000074da185d16bd  mov r12d, r12d
000074da185d16c0  mov [r15+0x60], r12
000074da185d16c4  mov rax, [r15+0x68]
000074da185d16c8  mov [rsp+0x20], rax
000074da185d16cd  mov r14, [rsp+0x10]
000074da185d16d2  imul rax, r14
000074da185d16d6  mov r12, [rsp+0x20]
000074da185d16db  lea r11, [r12+rax*1]
000074da185d16df  mov [r15+0x68], r11
000074da185d16e3  lea rax, [r14+0x02]
000074da185d16e7  mov [r15+0x58], rax
000074da185d16eb  mov [rsp+0x10], rax
000074da185d16f0  xor eax, eax
000074da185d16f2  mov r14, [rsp+0x10]
000074da185d16f7  mov r12d, 0x400
000074da185d16fd  cmp r14, r12
000074da185d1700  cmc
000074da185d1701  lahf
000074da185d1702  seto al
000074da185d1705  mov [r15+0x108], eax
000074da185d170c  mov rax, [r15+0x50]
000074da185d1710  mov r12, [r15+0x60]
000074da185d1714  imul r14, r12
000074da185d1718  lea r12, [rax+r14*1]
000074da185d171c  mov [r15+0x50], r12
000074da185d1720  mov rax, [r15+0x48]
000074da185d1724  lea r14, [r11+rax*1]
000074da185d1728  mov [r15+0x48], r14
000074da185d172c  mov eax, [r15+0x108]
000074da185d1733  sahf
000074da185d1734  jnz 0x000074DA185D1766
000074da185d1736  cmp dword ptr [r15+0x318], 0x00
000074da185d173e  jz 0x000074DA185D17B0
000074da185d1744  nop [rax+rax*1], ax
000074da185d174d  nop [rax+rax*1], eax
000074da185d1755  mov eax, 0x4103D0
000074da185d175a  mov [r15+0x100], rax
000074da185d1761  jmp 0x000074DA183FE110
000074da185d1766  cmp dword ptr [r15+0x318], 0x00
000074da185d176e  jz 0x000074DA185D1690
000074da185d1774  nop [rax+rax*1], ax
000074da185d177d  nop [rax+rax*1], eax
000074da185d1785  mov eax, 0x4103B0
000074da185d178a  mov [r15+0x100], rax
000074da185d1791  jmp 0x000074DA183FE110
000074da185d1796  int3
000074da185d1797  call 0x000074DA184B4690
000074da185d179c  jmp 0x000074DA185D16AD
000074da185d17a1  call 0x000074DA184E26A0
000074da185d17a6  jmp 0x000074DA185D16B7
000074da185d17ab  int3
000074da185d17ac  nop [rax], eax
000074da185d17b0  mov qword ptr [r15+0x98], 0x00
000074da185d17bb  mov rax, [r15+0x50]
000074da185d17bf  mov r14, [r15+0x48]
000074da185d17c3  lea r12, [rax+r14*1]
000074da185d17c7  mov [r15+0x48], r12
000074da185d17cb  mov rax, [r15+0x40]
000074da185d17cf  lea r14, [rax+0xC40]
000074da185d17d6  mov [r13+r14*1], r12
000074da185d17db  mov qword ptr [r15], 0x01
000074da185d17e2  mov qword ptr [r15+0xF0], 0x4103E8
000074da185d17ed  mov r14d, [r15+0x320]
000074da185d17f4  mov eax, 0x4103E8
000074da185d17f9  mov rcx, 0x74DA185D1860
000074da185d1803  mov [r15+r14*8+0x328], rax
000074da185d180b  mov [r15+r14*8+0x368], rcx
000074da185d1813  add r14d, 0x01
000074da185d1817  and r14d, 0x07
000074da185d181b  mov [r15+0x320], r14d
000074da185d1822  cmp dword ptr [r15+0x318], 0x00
000074da185d182a  jz 0x000074DA185D0F20
000074da185d1830  nop [rax+rax*1], ax
000074da185d1839  nop [rax+rax*1], eax
000074da185d1841  mov eax, 0x410938
000074da185d1846  mov [r15+0x100], rax
000074da185d184d  jmp 0x000074DA183FE110
000074da185d1852  int3
000074da185d1853  call 0x000074DA184E2CE0
000074da185d1858  jmp 0x000074DA185D17DB
000074da185d185d  int3
000074da185d185e  nop
000074da185d1860  mov eax, [r15+0x98]
000074da185d1867  lea r14d, [eax+0x01]
000074da185d186c  mov [rsp+0x10], r14d
000074da185d1871  mov r14d, r14d
000074da185d1874  mov [r15+0x98], r14
000074da185d187b  xor eax, eax
000074da185d187d  mov r14d, [rsp+0x10]
000074da185d1882  cmp r14d, 0x10000
000074da185d1889  cmc
000074da185d188a  lahf
000074da185d188b  seto al
000074da185d188e  mov [r15+0x108], eax
000074da185d1895  mov eax, [r15+0x108]
000074da185d189c  sahf
000074da185d189d  jnz 0x000074DA185D18CF
000074da185d189f  cmp dword ptr [r15+0x318], 0x00
000074da185d18a7  jz 0x000074DA185D19A0
000074da185d18ad  nop [rax+rax*1], ax
000074da185d18b6  nop [rax+rax*1], eax
000074da185d18be  mov eax, 0x4103F4
000074da185d18c3  mov [r15+0x100], rax
000074da185d18ca  jmp 0x000074DA183FE110
000074da185d18cf  cmp dword ptr [r15+0x318], 0x00
000074da185d18d7  jz 0x000074DA185D1910
000074da185d18dd  nop [rax+rax*1], ax
000074da185d18e6  nop [rax+rax*1], eax
000074da185d18ee  mov eax, 0x4103E0
000074da185d18f3  mov [r15+0x100], rax
000074da185d18fa  jmp 0x000074DA183FE110
000074da185d18ff  int3
000074da185d1900  int3
000074da185d1901  nop [rax+rax*1], ax
000074da185d190a  nop [rax+rax*1], ax
000074da185d1910  mov eax, [r15]
000074da185d1913  mov r14d, [r15+0x98]
000074da185d191a  lea r12d, [eax+r14d*1]
000074da185d191f  mov r12d, r12d
000074da185d1922  mov [r15], r12
000074da185d1925  mov qword ptr [r15+0xF0], 0x4103E8
000074da185d1930  mov r14d, [r15+0x320]
000074da185d1937  mov eax, 0x4103E8
000074da185d193c  mov rcx, 0x74DA185D1860
000074da185d1946  mov [r15+r14*8+0x328], rax
000074da185d194e  mov [r15+r14*8+0x368], rcx
000074da185d1956  add r14d, 0x01
000074da185d195a  and r14d, 0x07
000074da185d195e  mov [r15+0x320], r14d
000074da185d1965  cmp dword ptr [r15+0x318], 0x00
000074da185d196d  jz 0x000074DA185D0F20
000074da185d1973  nop [rax+rax*1], ax
000074da185d197c  nop [rax+rax*1], eax
000074da185d1984  mov eax, 0x410938
000074da185d1989  mov [r15+0x100], rax
000074da185d1990  jmp 0x000074DA183FE110
000074da185d1995  int3
000074da185d1996  int3
000074da185d1997  nop [rax+rax*1], ax
000074da185d19a0  vmovaps xmm1, [0x000074DA181FE010]
000074da185d19a8  movq xmm1, xmm1
000074da185d19ac  movaps [r15+0x110], xmm1
000074da185d19b4  mov eax, 0x420AA0
000074da185d19b9  mov r14, [r13+rax*1]
000074da185d19be  movq xmm1, r14
000074da185d19c3  movaps [r15+0x120], xmm1
000074da185d19cb  vmovaps xmm1, [0x000074DA181FE020]
000074da185d19d3  movq xmm1, xmm1
000074da185d19d7  movaps [r15+0x140], xmm1
000074da185d19df  vmovaps xmm1, [0x000074DA181FE030]
000074da185d19e7  vpbroadcastq xmm1, xmm1
000074da185d19ec  movaps [r15+0x150], xmm1
000074da185d19f4  mov qword ptr [r15+0x40], 0x02
000074da185d19fc  vmovaps xmm15, [0x000074DA181FE040]
000074da185d1a04  movq xmm15, xmm15
000074da185d1a09  movaps [r15+0x160], xmm15
000074da185d1a11  vmovaps xmm15, [0x000074DA181FE050]
000074da185d1a19  vpbroadcastq xmm15, xmm15
000074da185d1a1e  movaps [r15+0x130], xmm15
000074da185d1a26  mov rax, [r15+0x40]
000074da185d1a2a  vmovq xmm14, rax
000074da185d1a2f  vpbroadcastq xmm14, xmm14
000074da185d1a34  movaps [r15+0x170], xmm14
000074da185d1a3c  mov eax, 0x4209D0
000074da185d1a41  movups xmm13, [r13+rax*1]
000074da185d1a47  mov qword ptr [r15+0x40], 0x431D90
000074da185d1a4f  mov eax, [r15]
000074da185d1a52  mov r14d, 0x430C48
000074da185d1a58  mov [r13+r14*1], eax
000074da185d1a5d  mov qword ptr [r15+0x50], 0x431F90
000074da185d1a65  vpmovqd xmm12, xmm13
000074da185d1a6b  pxor xmm11, xmm11
000074da185d1a70  punpcklqdq xmm12, xmm11
000074da185d1a75  movaps [r15+0x210], xmm12
000074da185d1a7d  movq xmm12, qword ptr [r15+0x140]
000074da185d1a86  movq xmm11, qword ptr [r15+0x120]
000074da185d1a8f  psubd xmm12, xmm11
000074da185d1a94  movq xmm12, xmm12
000074da185d1a99  paddq xmm13, xmm14
000074da185d1a9e  movaps [r15+0x180], xmm13
000074da185d1aa6  movq xmm14, qword ptr [r15+0x160]
000074da185d1aaf  paddd xmm11, xmm14
000074da185d1ab4  movq xmm11, xmm11
000074da185d1ab9  movq xmm11, xmm11
000074da185d1abe  movaps [r15+0x120], xmm11
000074da185d1ac6  pmovzxdq xmm12, xmm12
000074da185d1acc  psllq xmm12, 0x00
000074da185d1ad2  movq xmm14, qword ptr [r15+0x210]
000074da185d1adb  movq xmm13, qword ptr [r15+0x110]
000074da185d1ae4  paddd xmm14, xmm13
000074da185d1ae9  movq xmm14, xmm14
000074da185d1aee  vcvtuqq2pd xmm12, xmm12
000074da185d1af4  pmovzxdq xmm14, xmm14
000074da185d1afa  psllq xmm14, 0x00
000074da185d1b00  vcvtuqq2pd xmm14, xmm14
000074da185d1b06  movaps xmm13, xmm12
000074da185d1b0a  mulpd xmm13, xmm1
000074da185d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000074da185d1b15  ptest xmm11, xmm11
000074da185d1b1b  jnz 0x000074DA185D1C0F
000074da185d1b21  movaps [r15+0x220], xmm13
000074da185d1b29  mov eax, 0x431F90
000074da185d1b2e  movups [r13+rax*1], xmm13
000074da185d1b34  movaps xmm1, xmm14
000074da185d1b38  mulpd xmm1, xmm15
000074da185d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000074da185d1b42  ptest xmm13, xmm13
000074da185d1b48  jnz 0x000074DA185D1D5C
000074da185d1b4e  movaps [r15+0x210], xmm1
000074da185d1b56  mov eax, 0x431D90
000074da185d1b5b  movups [r13+rax*1], xmm1
000074da185d1b61  mov qword ptr [r15+0x48], 0x10
000074da185d1b69  xor eax, eax
000074da185d1b6b  mov r14d, 0x10
000074da185d1b71  mov r12d, 0x200
000074da185d1b77  cmp r14, r12
000074da185d1b7a  cmc
000074da185d1b7b  lahf
000074da185d1b7c  seto al
000074da185d1b7f  mov [r15+0x108], eax
000074da185d1b86  mov eax, [r15+0x108]
000074da185d1b8d  sahf
000074da185d1b8e  jnz 0x000074DA185D1BC0
000074da185d1b90  cmp dword ptr [r15+0x318], 0x00
000074da185d1b98  jz 0x000074DA185D2300
000074da185d1b9e  nop [rax+rax*1], ax
000074da185d1ba7  nop [rax+rax*1], eax
000074da185d1baf  mov eax, 0x410480
000074da185d1bb4  mov [r15+0x100], rax
000074da185d1bbb  jmp 0x000074DA183FE110
000074da185d1bc0  cmp dword ptr [r15+0x318], 0x00
000074da185d1bc8  jz 0x000074DA185D1EB0
000074da185d1bce  nop [rax+rax*1], ax
000074da185d1bd7  nop [rax+rax*1], eax
000074da185d1bdf  mov eax, 0x410440
000074da185d1be4  mov [r15+0x100], rax
000074da185d1beb  jmp 0x000074DA183FE110
000074da185d1bf0  int3
000074da185d1bf1  call 0x000074DA1840DC20
000074da185d1bf6  jmp 0x000074DA185D19BE
000074da185d1bfb  call 0x000074DA1840C260
000074da185d1c00  jmp 0x000074DA185D1A47
000074da185d1c05  call 0x000074DA184D5D70
000074da185d1c0a  jmp 0x000074DA185D1A5D
000074da185d1c0f  sub rsp, 0x08
000074da185d1c13  push rax
000074da185d1c14  push rcx
000074da185d1c15  push rdx
000074da185d1c16  push rdi
000074da185d1c17  push rsi
000074da185d1c18  push r8
000074da185d1c1a  push r9
000074da185d1c1c  push r10
000074da185d1c1e  push r11
000074da185d1c20  sub rsp, 0xF0
000074da185d1c27  vmovaps [rsp], xmm0
000074da185d1c2c  vmovaps [rsp+0x10], xmm1
000074da185d1c32  vmovaps [rsp+0x20], xmm2
000074da185d1c38  vmovaps [rsp+0x30], xmm3
000074da185d1c3e  vmovaps [rsp+0x40], xmm4
000074da185d1c44  vmovaps [rsp+0x50], xmm5
000074da185d1c4a  vmovaps [rsp+0x60], xmm6
000074da185d1c50  vmovaps [rsp+0x70], xmm7
000074da185d1c56  vmovaps [rsp+0x80], xmm8
000074da185d1c5f  vmovaps [rsp+0x90], xmm9
000074da185d1c68  vmovaps [rsp+0xA0], xmm10
000074da185d1c71  vmovaps [rsp+0xB0], xmm11
000074da185d1c7a  vmovaps [rsp+0xC0], xmm12
000074da185d1c83  vmovaps [rsp+0xD0], xmm14
000074da185d1c8c  vmovaps [rsp+0xE0], xmm15
000074da185d1c95  sub rsp, 0x30
000074da185d1c99  movaps [rsp], xmm13
000074da185d1c9e  movaps [rsp+0x10], xmm12
000074da185d1ca4  movaps [rsp+0x20], xmm1
000074da185d1ca9  lea rdi, [rsp]
000074da185d1cad  mov esi, 0x00
000074da185d1cb2  mov rax, 0x5946061DF530
000074da185d1cbc  call rax
000074da185d1cbe  movaps xmm13, [rsp]
000074da185d1cc3  add rsp, 0x30
000074da185d1cc7  vmovaps xmm0, [rsp]
000074da185d1ccc  vmovaps xmm1, [rsp+0x10]
000074da185d1cd2  vmovaps xmm2, [rsp+0x20]
000074da185d1cd8  vmovaps xmm3, [rsp+0x30]
000074da185d1cde  vmovaps xmm4, [rsp+0x40]
000074da185d1ce4  vmovaps xmm5, [rsp+0x50]
000074da185d1cea  vmovaps xmm6, [rsp+0x60]
000074da185d1cf0  vmovaps xmm7, [rsp+0x70]
000074da185d1cf6  vmovaps xmm8, [rsp+0x80]
000074da185d1cff  vmovaps xmm9, [rsp+0x90]
000074da185d1d08  vmovaps xmm10, [rsp+0xA0]
000074da185d1d11  vmovaps xmm11, [rsp+0xB0]
000074da185d1d1a  vmovaps xmm12, [rsp+0xC0]
000074da185d1d23  vmovaps xmm14, [rsp+0xD0]
000074da185d1d2c  vmovaps xmm15, [rsp+0xE0]
000074da185d1d35  add rsp, 0xF0
000074da185d1d3c  pop r11
000074da185d1d3e  pop r10
000074da185d1d40  pop r9
000074da185d1d42  pop r8
000074da185d1d44  pop rsi
000074da185d1d45  pop rdi
000074da185d1d46  pop rdx
000074da185d1d47  pop rcx
000074da185d1d48  pop rax
000074da185d1d49  add rsp, 0x08
000074da185d1d4d  jmp 0x000074DA185D1B21
000074da185d1d52  call 0x000074DA1840C380
000074da185d1d57  jmp 0x000074DA185D1B34
000074da185d1d5c  sub rsp, 0x08
000074da185d1d60  push rax
000074da185d1d61  push rcx
000074da185d1d62  push rdx
000074da185d1d63  push rdi
000074da185d1d64  push rsi
000074da185d1d65  push r8
000074da185d1d67  push r9
000074da185d1d69  push r10
000074da185d1d6b  push r11
000074da185d1d6d  sub rsp, 0xF0
000074da185d1d74  vmovaps [rsp], xmm0
000074da185d1d79  vmovaps [rsp+0x10], xmm2
000074da185d1d7f  vmovaps [rsp+0x20], xmm3
000074da185d1d85  vmovaps [rsp+0x30], xmm4
000074da185d1d8b  vmovaps [rsp+0x40], xmm5
000074da185d1d91  vmovaps [rsp+0x50], xmm6
000074da185d1d97  vmovaps [rsp+0x60], xmm7
000074da185d1d9d  vmovaps [rsp+0x70], xmm8
000074da185d1da3  vmovaps [rsp+0x80], xmm9
000074da185d1dac  vmovaps [rsp+0x90], xmm10
000074da185d1db5  vmovaps [rsp+0xA0], xmm11
000074da185d1dbe  vmovaps [rsp+0xB0], xmm12
000074da185d1dc7  vmovaps [rsp+0xC0], xmm13
000074da185d1dd0  vmovaps [rsp+0xD0], xmm14
000074da185d1dd9  vmovaps [rsp+0xE0], xmm15
000074da185d1de2  sub rsp, 0x30
000074da185d1de6  movaps [rsp], xmm1
000074da185d1dea  movaps [rsp+0x10], xmm14
000074da185d1df0  movaps [rsp+0x20], xmm15
000074da185d1df6  lea rdi, [rsp]
000074da185d1dfa  mov esi, 0x00
000074da185d1dff  mov rax, 0x5946061DF530
000074da185d1e09  call rax
000074da185d1e0b  movaps xmm1, [rsp]
000074da185d1e0f  add rsp, 0x30
000074da185d1e13  vmovaps xmm0, [rsp]
000074da185d1e18  vmovaps xmm2, [rsp+0x10]
000074da185d1e1e  vmovaps xmm3, [rsp+0x20]
000074da185d1e24  vmovaps xmm4, [rsp+0x30]
000074da185d1e2a  vmovaps xmm5, [rsp+0x40]
000074da185d1e30  vmovaps xmm6, [rsp+0x50]
000074da185d1e36  vmovaps xmm7, [rsp+0x60]
000074da185d1e3c  vmovaps xmm8, [rsp+0x70]
000074da185d1e42  vmovaps xmm9, [rsp+0x80]
000074da185d1e4b  vmovaps xmm10, [rsp+0x90]
000074da185d1e54  vmovaps xmm11, [rsp+0xA0]
000074da185d1e5d  vmovaps xmm12, [rsp+0xB0]
000074da185d1e66  vmovaps xmm13, [rsp+0xC0]
000074da185d1e6f  vmovaps xmm14, [rsp+0xD0]
000074da185d1e78  vmovaps xmm15, [rsp+0xE0]
000074da185d1e81  add rsp, 0xF0
000074da185d1e88  pop r11
000074da185d1e8a  pop r10
000074da185d1e8c  pop r9
000074da185d1e8e  pop r8
000074da185d1e90  pop rsi
000074da185d1e91  pop rdi
000074da185d1e92  pop rdx
000074da185d1e93  pop rcx
000074da185d1e94  pop rax
000074da185d1e95  add rsp, 0x08
000074da185d1e99  jmp 0x000074DA185D1B4E
000074da185d1e9e  call 0x000074DA183FF540
000074da185d1ea3  jmp 0x000074DA185D1B61
000074da185d1ea8  int3
000074da185d1ea9  nop [rax], eax
000074da185d1eb0  movaps xmm1, [r15+0x180]
000074da185d1eb8  vpmovqd xmm15, xmm1
000074da185d1ebe  pxor xmm14, xmm14
000074da185d1ec3  punpcklqdq xmm15, xmm14
000074da185d1ec8  movaps [r15+0x210], xmm15
000074da185d1ed0  movq xmm15, qword ptr [r15+0x140]
000074da185d1ed9  movq xmm14, qword ptr [r15+0x120]
000074da185d1ee2  psubd xmm15, xmm14
000074da185d1ee7  movq xmm15, xmm15
000074da185d1eec  movaps xmm13, [r15+0x170]
000074da185d1ef4  paddq xmm1, xmm13
000074da185d1ef9  movaps [r15+0x180], xmm1
000074da185d1f01  movq xmm1, qword ptr [r15+0x160]
000074da185d1f0a  paddd xmm14, xmm1
000074da185d1f0f  movq xmm14, xmm14
000074da185d1f14  movq xmm14, xmm14
000074da185d1f19  movaps [r15+0x120], xmm14
000074da185d1f21  pmovzxdq xmm15, xmm15
000074da185d1f27  psllq xmm15, 0x00
000074da185d1f2d  movq xmm1, qword ptr [r15+0x210]
000074da185d1f36  movq xmm14, qword ptr [r15+0x110]
000074da185d1f3f  paddd xmm1, xmm14
000074da185d1f44  movq xmm1, xmm1
000074da185d1f48  vcvtuqq2pd xmm15, xmm15
000074da185d1f4e  pmovzxdq xmm1, xmm1
000074da185d1f53  psllq xmm1, 0x00
000074da185d1f58  vcvtuqq2pd xmm1, xmm1
000074da185d1f5e  movaps xmm14, [r15+0x150]
000074da185d1f66  movaps xmm13, xmm15
000074da185d1f6a  mulpd xmm13, xmm14
000074da185d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d1f75  ptest xmm12, xmm12
000074da185d1f7b  jnz 0x000074DA185D205E
000074da185d1f81  movaps [r15+0x220], xmm13
000074da185d1f89  mov rax, [r15+0x48]
000074da185d1f8d  mov r14, [r15+0x50]
000074da185d1f91  lea r12, [r14+rax*1]
000074da185d1f95  movups [r13+r12*1], xmm13
000074da185d1f9b  movaps xmm15, [r15+0x130]
000074da185d1fa3  movaps xmm14, xmm1
000074da185d1fa7  mulpd xmm14, xmm15
000074da185d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000074da185d1fb2  ptest xmm13, xmm13
000074da185d1fb8  jnz 0x000074DA185D21AC
000074da185d1fbe  movaps [r15+0x210], xmm14
000074da185d1fc6  mov r14, [r15+0x40]
000074da185d1fca  lea r12, [r14+rax*1]
000074da185d1fce  movups [r13+r12*1], xmm14
000074da185d1fd4  lea r14, [rax+0x10]
000074da185d1fd8  mov [r15+0x48], r14
000074da185d1fdc  xor eax, eax
000074da185d1fde  mov r12d, 0x200
000074da185d1fe4  cmp r14, r12
000074da185d1fe7  cmc
000074da185d1fe8  lahf
000074da185d1fe9  seto al
000074da185d1fec  mov [r15+0x108], eax
000074da185d1ff3  mov eax, [r15+0x108]
000074da185d1ffa  sahf
000074da185d1ffb  jnz 0x000074DA185D202D
000074da185d1ffd  cmp dword ptr [r15+0x318], 0x00
000074da185d2005  jz 0x000074DA185D2300
000074da185d200b  nop [rax+rax*1], ax
000074da185d2014  nop [rax+rax*1], eax
000074da185d201c  mov eax, 0x410480
000074da185d2021  mov [r15+0x100], rax
000074da185d2028  jmp 0x000074DA183FE110
000074da185d202d  cmp dword ptr [r15+0x318], 0x00
000074da185d2035  jz 0x000074DA185D1EB0
000074da185d203b  nop [rax+rax*1], ax
000074da185d2044  nop [rax+rax*1], eax
000074da185d204c  mov eax, 0x410440
000074da185d2051  mov [r15+0x100], rax
000074da185d2058  jmp 0x000074DA183FE110
000074da185d205d  int3
000074da185d205e  sub rsp, 0x08
000074da185d2062  push rax
000074da185d2063  push rcx
000074da185d2064  push rdx
000074da185d2065  push rdi
000074da185d2066  push rsi
000074da185d2067  push r8
000074da185d2069  push r9
000074da185d206b  push r10
000074da185d206d  push r11
000074da185d206f  sub rsp, 0xF0
000074da185d2076  vmovaps [rsp], xmm0
000074da185d207b  vmovaps [rsp+0x10], xmm1
000074da185d2081  vmovaps [rsp+0x20], xmm2
000074da185d2087  vmovaps [rsp+0x30], xmm3
000074da185d208d  vmovaps [rsp+0x40], xmm4
000074da185d2093  vmovaps [rsp+0x50], xmm5
000074da185d2099  vmovaps [rsp+0x60], xmm6
000074da185d209f  vmovaps [rsp+0x70], xmm7
000074da185d20a5  vmovaps [rsp+0x80], xmm8
000074da185d20ae  vmovaps [rsp+0x90], xmm9
000074da185d20b7  vmovaps [rsp+0xA0], xmm10
000074da185d20c0  vmovaps [rsp+0xB0], xmm11
000074da185d20c9  vmovaps [rsp+0xC0], xmm12
000074da185d20d2  vmovaps [rsp+0xD0], xmm14
000074da185d20db  vmovaps [rsp+0xE0], xmm15
000074da185d20e4  sub rsp, 0x30
000074da185d20e8  movaps [rsp], xmm13
000074da185d20ed  movaps [rsp+0x10], xmm15
000074da185d20f3  movaps [rsp+0x20], xmm14
000074da185d20f9  lea rdi, [rsp]
000074da185d20fd  mov esi, 0x00
000074da185d2102  mov rax, 0x5946061DF530
000074da185d210c  call rax
000074da185d210e  movaps xmm13, [rsp]
000074da185d2113  add rsp, 0x30
000074da185d2117  vmovaps xmm0, [rsp]
000074da185d211c  vmovaps xmm1, [rsp+0x10]
000074da185d2122  vmovaps xmm2, [rsp+0x20]
000074da185d2128  vmovaps xmm3, [rsp+0x30]
000074da185d212e  vmovaps xmm4, [rsp+0x40]
000074da185d2134  vmovaps xmm5, [rsp+0x50]
000074da185d213a  vmovaps xmm6, [rsp+0x60]
000074da185d2140  vmovaps xmm7, [rsp+0x70]
000074da185d2146  vmovaps xmm8, [rsp+0x80]
000074da185d214f  vmovaps xmm9, [rsp+0x90]
000074da185d2158  vmovaps xmm10, [rsp+0xA0]
000074da185d2161  vmovaps xmm11, [rsp+0xB0]
000074da185d216a  vmovaps xmm12, [rsp+0xC0]
000074da185d2173  vmovaps xmm14, [rsp+0xD0]
000074da185d217c  vmovaps xmm15, [rsp+0xE0]
000074da185d2185  add rsp, 0xF0
000074da185d218c  pop r11
000074da185d218e  pop r10
000074da185d2190  pop r9
000074da185d2192  pop r8
000074da185d2194  pop rsi
000074da185d2195  pop rdi
000074da185d2196  pop rdx
000074da185d2197  pop rcx
000074da185d2198  pop rax
000074da185d2199  add rsp, 0x08
000074da185d219d  jmp 0x000074DA185D1F81
000074da185d21a2  call 0x000074DA184C2240
000074da185d21a7  jmp 0x000074DA185D1F9B
000074da185d21ac  sub rsp, 0x08
000074da185d21b0  push rax
000074da185d21b1  push rcx
000074da185d21b2  push rdx
000074da185d21b3  push rdi
000074da185d21b4  push rsi
000074da185d21b5  push r8
000074da185d21b7  push r9
000074da185d21b9  push r10
000074da185d21bb  push r11
000074da185d21bd  sub rsp, 0xF0
000074da185d21c4  vmovaps [rsp], xmm0
000074da185d21c9  vmovaps [rsp+0x10], xmm1
000074da185d21cf  vmovaps [rsp+0x20], xmm2
000074da185d21d5  vmovaps [rsp+0x30], xmm3
000074da185d21db  vmovaps [rsp+0x40], xmm4
000074da185d21e1  vmovaps [rsp+0x50], xmm5
000074da185d21e7  vmovaps [rsp+0x60], xmm6
000074da185d21ed  vmovaps [rsp+0x70], xmm7
000074da185d21f3  vmovaps [rsp+0x80], xmm8
000074da185d21fc  vmovaps [rsp+0x90], xmm9
000074da185d2205  vmovaps [rsp+0xA0], xmm10
000074da185d220e  vmovaps [rsp+0xB0], xmm11
000074da185d2217  vmovaps [rsp+0xC0], xmm12
000074da185d2220  vmovaps [rsp+0xD0], xmm13
000074da185d2229  vmovaps [rsp+0xE0], xmm15
000074da185d2232  sub rsp, 0x30
000074da185d2236  movaps [rsp], xmm14
000074da185d223b  movaps [rsp+0x10], xmm1
000074da185d2240  movaps [rsp+0x20], xmm15
000074da185d2246  lea rdi, [rsp]
000074da185d224a  mov esi, 0x00
000074da185d224f  mov rax, 0x5946061DF530
000074da185d2259  call rax
000074da185d225b  movaps xmm14, [rsp]
000074da185d2260  add rsp, 0x30
000074da185d2264  vmovaps xmm0, [rsp]
000074da185d2269  vmovaps xmm1, [rsp+0x10]
000074da185d226f  vmovaps xmm2, [rsp+0x20]
000074da185d2275  vmovaps xmm3, [rsp+0x30]
000074da185d227b  vmovaps xmm4, [rsp+0x40]
000074da185d2281  vmovaps xmm5, [rsp+0x50]
000074da185d2287  vmovaps xmm6, [rsp+0x60]
000074da185d228d  vmovaps xmm7, [rsp+0x70]
000074da185d2293  vmovaps xmm8, [rsp+0x80]
000074da185d229c  vmovaps xmm9, [rsp+0x90]
000074da185d22a5  vmovaps xmm10, [rsp+0xA0]
000074da185d22ae  vmovaps xmm11, [rsp+0xB0]
000074da185d22b7  vmovaps xmm12, [rsp+0xC0]
000074da185d22c0  vmovaps xmm13, [rsp+0xD0]
000074da185d22c9  vmovaps xmm15, [rsp+0xE0]
000074da185d22d2  add rsp, 0xF0
000074da185d22d9  pop r11
000074da185d22db  pop r10
000074da185d22dd  pop r9
000074da185d22df  pop r8
000074da185d22e1  pop rsi
000074da185d22e2  pop rdi
000074da185d22e3  pop rdx
000074da185d22e4  pop rcx
000074da185d22e5  pop rax
000074da185d22e6  add rsp, 0x08
000074da185d22ea  jmp 0x000074DA185D1FBE
000074da185d22ef  call 0x000074DA184C34C0
000074da185d22f4  jmp 0x000074DA185D1FD4
000074da185d22f9  int3
000074da185d22fa  nop [rax+rax*1], ax
000074da185d2300  mov rax, [r15+0x50]
000074da185d2304  movups xmm1, [r13+rax*1]
000074da185d230a  lea r14, [rax+0x10]
000074da185d230e  movups xmm15, [r13+r14*1]
000074da185d2314  mov qword ptr [r15+0x48], 0x00
000074da185d231c  lea r14, [rax+0x40]
000074da185d2320  movups xmm14, [r13+r14*1]
000074da185d2326  lea r14, [rax+0x50]
000074da185d232a  movups xmm13, [r13+r14*1]
000074da185d2330  lea r14, [rax+0x80]
000074da185d2337  movups xmm12, [r13+r14*1]
000074da185d233d  lea r14, [rax+0x90]
000074da185d2344  movups xmm11, [r13+r14*1]
000074da185d234a  mov r14, [r15+0xF8]
000074da185d2351  movups [r13+r14*1], xmm1
000074da185d2357  lea r12, [rax+0x20]
000074da185d235b  movups xmm1, [r13+r12*1]
000074da185d2361  lea r12, [rax+0x30]
000074da185d2365  movups xmm10, [r13+r12*1]
000074da185d236b  lea r12, [rax+0xC0]
000074da185d2372  movups xmm9, [r13+r12*1]
000074da185d2378  lea r12, [rax+0xD0]
000074da185d237f  movups xmm8, [r13+r12*1]
000074da185d2385  lea r12, [rax+0x100]
000074da185d238c  movups xmm7, [r13+r12*1]
000074da185d2392  lea r12, [rax+0x110]
000074da185d2399  movups xmm6, [r13+r12*1]
000074da185d239f  lea r12, [rax+0x140]
000074da185d23a6  movups xmm5, [r13+r12*1]
000074da185d23ac  lea r12, [rax+0x150]
000074da185d23b3  movups xmm4, [r13+r12*1]
000074da185d23b9  lea r12, [r14+0xB0]
000074da185d23c0  movups [r13+r12*1], xmm10
000074da185d23c6  lea r12, [r14+0xC0]
000074da185d23cd  movups [r13+r12*1], xmm1
000074da185d23d3  lea r12, [rax+0x180]
000074da185d23da  movups xmm1, [r13+r12*1]
000074da185d23e0  lea r12, [rax+0x190]
000074da185d23e7  movups xmm10, [r13+r12*1]
000074da185d23ed  lea r12, [rax+0x1C0]
000074da185d23f4  movups xmm3, [r13+r12*1]
000074da185d23fa  lea r12, [rax+0x1D0]
000074da185d2401  movups xmm2, [r13+r12*1]
000074da185d2407  lea r12, [rax+0x60]
000074da185d240b  vmovaps [rsp+0x10], xmm1
000074da185d2411  movups xmm1, [r13+r12*1]
000074da185d2417  lea r12, [rax+0x70]
000074da185d241b  vmovaps [rsp+0x20], xmm1
000074da185d2421  movups xmm1, [r13+r12*1]
000074da185d2427  lea r12, [r14+0x70]
000074da185d242b  movups [r13+r12*1], xmm10
000074da185d2431  lea r12, [r14+0x80]
000074da185d2438  vmovaps xmm10, [rsp+0x10]
000074da185d243e  movups [r13+r12*1], xmm10
000074da185d2444  lea r12, [rax+0xA0]
000074da185d244b  movups xmm10, [r13+r12*1]
000074da185d2451  lea r12, [rax+0xB0]
000074da185d2458  vmovaps [rsp+0x10], xmm1
000074da185d245e  movups xmm1, [r13+r12*1]
000074da185d2464  lea r12, [r14+0x90]
000074da185d246b  movups [r13+r12*1], xmm2
000074da185d2471  lea r12, [r14+0xA0]
000074da185d2478  movups [r13+r12*1], xmm3
000074da185d247e  lea r12, [rax+0xE0]
000074da185d2485  movups xmm3, [r13+r12*1]
000074da185d248b  lea r12, [rax+0xF0]
000074da185d2492  movups xmm2, [r13+r12*1]
000074da185d2498  lea r12, [rax+0x120]
000074da185d249f  vmovaps [rsp+0x30], xmm1
000074da185d24a5  movups xmm1, [r13+r12*1]
000074da185d24ab  lea r12, [rax+0x130]
000074da185d24b2  vmovaps [rsp+0x40], xmm1
000074da185d24b8  movups xmm1, [r13+r12*1]
000074da185d24be  vmovaps [rsp+0x50], xmm1
000074da185d24c4  vmovaps xmm1, [rsp+0x40]
000074da185d24ca  movaps [r15+0x190], xmm1
000074da185d24d2  lea r12, [rax+0x160]
000074da185d24d9  vmovaps [rsp+0x40], xmm1
000074da185d24df  movups xmm1, [r13+r12*1]
000074da185d24e5  lea r12, [rax+0x170]
000074da185d24ec  vmovaps [rsp+0x60], xmm1
000074da185d24f2  movups xmm1, [r13+r12*1]
000074da185d24f8  lea r12, [rax+0x1A0]
000074da185d24ff  vmovaps [rsp+0x70], xmm1
000074da185d2505  movups xmm1, [r13+r12*1]
000074da185d250b  lea r12, [rax+0x1B0]
000074da185d2512  vmovaps [rsp+0x80], xmm1
000074da185d251b  movups xmm1, [r13+r12*1]
000074da185d2521  lea r12, [rax+0x1E0]
000074da185d2528  vmovaps [rsp+0x90], xmm1
000074da185d2531  movups xmm1, [r13+r12*1]
000074da185d2537  lea r12, [rax+0x1F0]
000074da185d253e  vmovaps [rsp+0xA0], xmm1
000074da185d2547  movups xmm1, [r13+r12*1]
000074da185d254d  mov qword ptr [r15+0x50], 0x432190
000074da185d2555  lea rax, [r14+0x50]
000074da185d2559  vmovaps [rsp+0xB0], xmm1
000074da185d2562  vmovaps xmm1, [rsp+0x60]
000074da185d2568  movups [r13+rax*1], xmm1
000074da185d256e  lea rax, [r14+0x60]
000074da185d2572  movups [r13+rax*1], xmm5
000074da185d2578  lea rax, [r14+0x40]
000074da185d257c  vmovaps xmm1, [rsp+0x70]
000074da185d2582  movups [r13+rax*1], xmm1
000074da185d2588  lea rax, [r14+0x20]
000074da185d258c  vmovaps xmm1, [rsp+0xA0]
000074da185d2595  movups [r13+rax*1], xmm1
000074da185d259b  lea rax, [r14+0x30]
000074da185d259f  vmovaps xmm1, [rsp+0x90]
000074da185d25a8  movups [r13+rax*1], xmm1
000074da185d25ae  lea rax, [r14+0x10]
000074da185d25b2  vmovaps xmm1, [rsp+0xB0]
000074da185d25bb  movups [r13+rax*1], xmm1
000074da185d25c1  mov rax, [r15+0x40]
000074da185d25c5  vxorps xmm1, xmm1, xmm1
000074da185d25c9  vpbroadcastq xmm1, xmm1
000074da185d25ce  vxorps xmm5, xmm5, xmm5
000074da185d25d2  vpbroadcastq xmm5, xmm5
000074da185d25d7  lea r12, [rax+0x30]
000074da185d25db  mov r11, [r13+r12*1]
000074da185d25e0  lea r12, [rax+0x38]
000074da185d25e4  mov r10, [r13+r12*1]
000074da185d25e9  vmovaps [rsp+0x60], xmm1
000074da185d25ef  movq xmm1, r11
000074da185d25f4  vmovaps [rsp+0x70], xmm1
000074da185d25fa  movq xmm1, r10
000074da185d25ff  vmovaps [rsp+0x90], xmm1
000074da185d2608  vmovaps xmm1, [rsp+0x70]
000074da185d260e  movq xmm1, xmm1
000074da185d2612  vmovaps [rsp+0x70], xmm1
000074da185d2618  vmovaps xmm1, [rsp+0x90]
000074da185d2621  movq xmm1, xmm1
000074da185d2625  vmovaps [rsp+0x90], xmm1
000074da185d262e  movq xmm1, xmm1
000074da185d2632  movaps [r15+0x270], xmm1
000074da185d263a  vmovaps [rsp+0xA0], xmm7
000074da185d2643  vmovaps xmm1, [rsp+0xA0]
000074da185d264c  por xmm7, xmm1
000074da185d2650  lea r12, [rax+0x20]
000074da185d2654  mov r11, [r13+r12*1]
000074da185d2659  lea r12, [rax+0x28]
000074da185d265d  mov r10, [r13+r12*1]
000074da185d2662  movq xmm1, r11
000074da185d2667  vmovaps [rsp+0xA0], xmm1
000074da185d2670  movq xmm1, r10
000074da185d2675  vmovaps [rsp+0xB0], xmm1
000074da185d267e  vmovaps xmm1, [rsp+0xA0]
000074da185d2687  movq xmm1, xmm1
000074da185d268b  vmovaps [rsp+0xA0], xmm1
000074da185d2694  vmovaps xmm1, [rsp+0xB0]
000074da185d269d  movq xmm1, xmm1
000074da185d26a1  vmovaps [rsp+0xB0], xmm2
000074da185d26aa  vmovaps [rsp+0xC0], xmm1
000074da185d26b3  vmovaps xmm1, [rsp+0xB0]
000074da185d26bc  por xmm2, xmm1
000074da185d26c0  vmovaps [rsp+0xB0], xmm3
000074da185d26c9  vmovaps xmm1, [rsp+0xB0]
000074da185d26d2  por xmm3, xmm1
000074da185d26d6  vmovaps [rsp+0xB0], xmm4
000074da185d26df  vmovaps xmm1, [rsp+0xB0]
000074da185d26e8  por xmm4, xmm1
000074da185d26ec  vmovaps [rsp+0xB0], xmm9
000074da185d26f5  vmovaps xmm1, [rsp+0xB0]
000074da185d26fe  por xmm9, xmm1
000074da185d2703  lea r12, [rax+0x10]
000074da185d2707  mov r11, [r13+r12*1]
000074da185d270c  lea r12, [rax+0x18]
000074da185d2710  mov r10, [r13+r12*1]
000074da185d2715  movq xmm1, r11
000074da185d271a  vmovaps [rsp+0xB0], xmm1
000074da185d2723  movq xmm1, r10
000074da185d2728  vmovaps [rsp+0xD0], xmm1
000074da185d2731  vmovaps xmm1, [rsp+0xB0]
000074da185d273a  movq xmm1, xmm1
000074da185d273e  vmovaps [rsp+0xB0], xmm1
000074da185d2747  vmovaps xmm1, [rsp+0xD0]
000074da185d2750  movq xmm1, xmm1
000074da185d2754  vmovaps [rsp+0xD0], xmm1
000074da185d275d  vmovaps xmm1, [rsp+0x80]
000074da185d2766  vmovaps [rsp+0xE0], xmm15
000074da185d276f  vmovaps xmm15, [rsp+0x80]
000074da185d2778  por xmm1, xmm15
000074da185d277d  vmovaps xmm15, [rsp+0x10]
000074da185d2783  vmovaps [rsp+0x80], xmm1
000074da185d278c  vmovaps xmm1, [rsp+0x10]
000074da185d2792  por xmm15, xmm1
000074da185d2797  vmovaps xmm1, [rsp+0x20]
000074da185d279d  vmovaps [rsp+0x10], xmm15
000074da185d27a3  vmovaps xmm15, [rsp+0x20]
000074da185d27a9  por xmm1, xmm15
000074da185d27ae  vmovaps [rsp+0x20], xmm6
000074da185d27b4  vmovaps xmm15, [rsp+0x20]
000074da185d27ba  por xmm6, xmm15
000074da185d27bf  vmovaps [rsp+0x20], xmm11
000074da185d27c5  vmovaps xmm15, [rsp+0x20]
000074da185d27cb  por xmm11, xmm15
000074da185d27d0  vmovaps [rsp+0x20], xmm13
000074da185d27d6  vmovaps xmm15, [rsp+0x20]
000074da185d27dc  por xmm13, xmm15
000074da185d27e1  vmovaps [rsp+0x20], xmm14
000074da185d27e7  vmovaps xmm15, [rsp+0x20]
000074da185d27ed  por xmm14, xmm15
000074da185d27f2  mov r12, [r13+rax*1]
000074da185d27f7  vmovq xmm15, r12
000074da185d27fc  vpbroadcastq xmm15, xmm15
000074da185d2801  vmovaps [rsp+0x20], xmm1
000074da185d2807  vxorps xmm1, xmm1, xmm1
000074da185d280b  vpbroadcastq xmm1, xmm1
000074da185d2810  vmovaps [rsp+0xF0], xmm1
000074da185d2819  movups xmm1, [r13+r14*1]
000074da185d281f  vmovaps [rsp+0x100], xmm1
000074da185d2828  vxorps xmm1, xmm1, xmm1
000074da185d282c  vpbroadcastq xmm1, xmm1
000074da185d2831  lea r12, [rax+0x08]
000074da185d2835  mov rax, [r13+r12*1]
000074da185d283a  vmovaps [rsp+0x110], xmm1
000074da185d2843  movq xmm1, rax
000074da185d2848  movaps [r15+0x240], xmm1
000074da185d2850  mov qword ptr [r15+0x60], 0x432190
000074da185d2858  mov qword ptr [r15+0x58], 0x40
000074da185d2860  vmovaps xmm1, [rsp+0x60]
000074da185d2866  vmovaps [rsp+0x60], xmm15
000074da185d286c  vmovaps xmm15, [rsp+0x100]
000074da185d2875  vmovaps [rsp+0x100], xmm14
000074da185d287e  vmovaps xmm14, [rsp+0x60]
000074da185d2884  vmovaps [rsp+0x60], xmm13
000074da185d288a  vmovaps [rsp+0x120], xmm12
000074da185d2893  movaps xmm13, xmm1
000074da185d2897  vfmadd231pd xmm13, xmm15, xmm14
000074da185d289c  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d28a2  vptest xmm12, xmm12
000074da185d28a7  jnz 0x000074DA185D3482
000074da185d28ad  vmovaps xmm1, [rsp+0xE0]
000074da185d28b6  movaps xmm15, xmm5
000074da185d28ba  vfmadd231pd xmm15, xmm1, xmm14
000074da185d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
000074da185d28c5  vptest xmm12, xmm12
000074da185d28ca  jnz 0x000074DA185D35DB
000074da185d28d0  vmovaps xmm12, [rsp+0x50]
000074da185d28d6  vmovaps xmm5, [rsp+0x50]
000074da185d28dc  por xmm12, xmm5
000074da185d28e1  vmovaps xmm5, [rsp+0x30]
000074da185d28e7  vmovaps [rsp+0x50], xmm1
000074da185d28ed  vmovaps xmm1, [rsp+0x30]
000074da185d28f3  por xmm5, xmm1
000074da185d28f7  vmovaps [rsp+0x30], xmm10
000074da185d28fd  vmovaps xmm1, [rsp+0x30]
000074da185d2903  por xmm10, xmm1
000074da185d2908  vmovaps [rsp+0x30], xmm8
000074da185d290e  vmovaps xmm1, [rsp+0x30]
000074da185d2914  por xmm8, xmm1
000074da185d2919  vmovaps xmm1, [rsp+0x120]
000074da185d2922  vmovaps [rsp+0x30], xmm15
000074da185d2928  vmovaps xmm15, [rsp+0x120]
000074da185d2931  por xmm1, xmm15
000074da185d2936  vmovaps xmm15, [rsp+0x50]
000074da185d293c  vmovaps [rsp+0xE0], xmm1
000074da185d2945  vmovaps xmm1, [rsp+0x50]
000074da185d294b  por xmm15, xmm1
000074da185d2950  lea rax, [r14+0xC0]
000074da185d2957  movups xmm1, [r13+rax*1]
000074da185d295d  xor eax, eax
000074da185d295f  mov r12d, 0x40
000074da185d2965  mov r11d, 0x200
000074da185d296b  cmp r12, r11
000074da185d296e  cmc
000074da185d296f  lahf
000074da185d2970  seto al
000074da185d2973  mov [r15+0x108], eax
000074da185d297a  vmovaps [rsp+0x50], xmm1
000074da185d2980  vmovaps xmm1, [rsp+0xF0]
000074da185d2989  vmovaps [rsp+0xF0], xmm15
000074da185d2992  vmovaps xmm15, [rsp+0x50]
000074da185d2998  vmovaps [rsp+0x50], xmm13
000074da185d299e  vmovaps [rsp+0x120], xmm12
000074da185d29a7  movaps xmm13, xmm1
000074da185d29ab  vfmadd231pd xmm13, xmm15, xmm14
000074da185d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d29b6  vptest xmm12, xmm12
000074da185d29bb  jnz 0x000074DA185D373D
000074da185d29c1  lea rax, [r14+0xB0]
000074da185d29c8  movups xmm1, [r13+rax*1]
000074da185d29ce  vmovaps xmm15, [rsp+0x110]
000074da185d29d7  vmovaps [rsp+0x110], xmm13
000074da185d29e0  movaps xmm12, xmm15
000074da185d29e4  vfmadd231pd xmm12, xmm1, xmm14
000074da185d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
000074da185d29ef  vptest xmm13, xmm13
000074da185d29f4  jnz 0x000074DA185D38A0
000074da185d29fa  vmovaps xmm1, [rsp+0x100]
000074da185d2a03  vmovaps xmm15, [rsp+0x100]
000074da185d2a0c  por xmm1, xmm15
000074da185d2a11  movaps [r15+0x210], xmm1
000074da185d2a19  vmovaps xmm15, [rsp+0x60]
000074da185d2a1f  vmovaps xmm14, [rsp+0x60]
000074da185d2a25  por xmm15, xmm14
000074da185d2a2a  movaps [r15+0x1C0], xmm15
000074da185d2a32  vmovaps [rsp+0x60], xmm11
000074da185d2a38  vmovaps xmm14, [rsp+0x60]
000074da185d2a3e  por xmm11, xmm14
000074da185d2a43  movaps [r15+0x280], xmm11
000074da185d2a4b  vmovaps [rsp+0x60], xmm6
000074da185d2a51  vmovaps xmm14, [rsp+0x60]
000074da185d2a57  por xmm6, xmm14
000074da185d2a5c  movaps [r15+0x2A0], xmm6
000074da185d2a64  vmovaps xmm14, [rsp+0x20]
000074da185d2a6a  vmovaps xmm13, [rsp+0x20]
000074da185d2a70  por xmm14, xmm13
000074da185d2a75  movaps [r15+0x2E0], xmm14
000074da185d2a7d  vmovaps xmm13, [rsp+0x10]
000074da185d2a83  vmovaps [rsp+0x20], xmm1
000074da185d2a89  vmovaps xmm1, [rsp+0x10]
000074da185d2a8f  por xmm13, xmm1
000074da185d2a94  movaps [r15+0x1F0], xmm13
000074da185d2a9c  vmovaps xmm1, [rsp+0xF0]
000074da185d2aa5  vmovaps [rsp+0x10], xmm15
000074da185d2aab  vmovaps xmm15, [rsp+0xF0]
000074da185d2ab4  por xmm1, xmm15
000074da185d2ab9  movaps [r15+0x250], xmm1
000074da185d2ac1  vmovaps xmm1, [rsp+0xE0]
000074da185d2aca  vmovaps xmm15, [rsp+0xE0]
000074da185d2ad3  por xmm1, xmm15
000074da185d2ad8  movaps [r15+0x260], xmm1
000074da185d2ae0  vmovaps [rsp+0x60], xmm8
000074da185d2ae6  vmovaps xmm15, [rsp+0x60]
000074da185d2aec  por xmm8, xmm15
000074da185d2af1  movaps [r15+0x290], xmm8
000074da185d2af9  vmovaps [rsp+0x60], xmm10
000074da185d2aff  vmovaps xmm15, [rsp+0x60]
000074da185d2b05  por xmm10, xmm15
000074da185d2b0a  movaps [r15+0x2C0], xmm10
000074da185d2b12  movq xmm15, qword ptr [r15+0x240]
000074da185d2b1b  vmovaps [rsp+0x60], xmm15
000074da185d2b21  vpermilpd xmm15, xmm15, 0x00
000074da185d2b27  vmovaps [rsp+0xE0], xmm1
000074da185d2b30  vmovaps xmm1, [rsp+0x50]
000074da185d2b36  vmovaps [rsp+0x50], xmm15
000074da185d2b3c  vmovaps xmm15, [rsp+0x20]
000074da185d2b42  vmovaps [rsp+0x20], xmm14
000074da185d2b48  vmovaps xmm14, [rsp+0x50]
000074da185d2b4e  vmovaps [rsp+0x50], xmm13
000074da185d2b54  vmovaps [rsp+0xF0], xmm12
000074da185d2b5d  movaps xmm13, xmm1
000074da185d2b61  vfmadd231pd xmm13, xmm15, xmm14
000074da185d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d2b6c  vptest xmm12, xmm12
000074da185d2b71  jnz 0x000074DA185D39F9
000074da185d2b77  vmovaps xmm1, [rsp+0x60]
000074da185d2b7d  vpermilpd xmm1, xmm1, 0x00
000074da185d2b83  vmovaps xmm15, [rsp+0x110]
000074da185d2b8c  vmovaps xmm14, [rsp+0x20]
000074da185d2b92  vmovaps [rsp+0x20], xmm13
000074da185d2b98  movaps xmm12, xmm15
000074da185d2b9c  vfmadd231pd xmm12, xmm14, xmm1
000074da185d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
000074da185d2ba7  vptest xmm13, xmm13
000074da185d2bac  jnz 0x000074DA185D3B52
000074da185d2bb2  vmovaps xmm1, [rsp+0x60]
000074da185d2bb8  vpermilpd xmm1, xmm1, 0x00
000074da185d2bbe  vmovaps xmm15, [rsp+0x30]
000074da185d2bc4  vmovaps xmm14, [rsp+0x10]
000074da185d2bca  vmovaps [rsp+0x10], xmm12
000074da185d2bd0  movaps xmm13, xmm15
000074da185d2bd4  vfmadd231pd xmm13, xmm14, xmm1
000074da185d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d2bdf  vptest xmm12, xmm12
000074da185d2be4  jnz 0x000074DA185D3CAB
000074da185d2bea  vmovaps [rsp+0x30], xmm5
000074da185d2bf0  vmovaps xmm1, [rsp+0x30]
000074da185d2bf6  por xmm5, xmm1
000074da185d2bfa  movaps [r15+0x1D0], xmm5
000074da185d2c02  vmovaps xmm1, [rsp+0x60]
000074da185d2c08  vpermilpd xmm1, xmm1, 0x00
000074da185d2c0e  vmovaps xmm15, [rsp+0xF0]
000074da185d2c17  vmovaps xmm14, [rsp+0x50]
000074da185d2c1d  vmovaps [rsp+0x30], xmm13
000074da185d2c23  movaps xmm12, xmm15
000074da185d2c27  vfmadd231pd xmm12, xmm14, xmm1
000074da185d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
000074da185d2c32  vptest xmm13, xmm13
000074da185d2c37  jnz 0x000074DA185D3E04
000074da185d2c3d  vmovaps xmm1, [rsp+0x80]
000074da185d2c46  vmovaps xmm15, [rsp+0x80]
000074da185d2c4f  por xmm1, xmm15
000074da185d2c54  movaps [r15+0x200], xmm1
000074da185d2c5c  vmovaps xmm15, [rsp+0x120]
000074da185d2c65  vmovaps xmm14, [rsp+0x120]
000074da185d2c6e  por xmm15, xmm14
000074da185d2c73  movaps [r15+0x1E0], xmm15
000074da185d2c7b  vmovaps [rsp+0x50], xmm4
000074da185d2c81  vmovaps xmm13, [rsp+0x50]
000074da185d2c87  por xmm4, xmm13
000074da185d2c8c  movaps [r15+0x2B0], xmm4
000074da185d2c94  vmovaps [rsp+0x50], xmm3
000074da185d2c9a  vmovaps xmm13, [rsp+0x50]
000074da185d2ca0  por xmm3, xmm13
000074da185d2ca5  movaps [r15+0x300], xmm3
000074da185d2cad  vmovaps xmm15, [rsp+0xB0]
000074da185d2cb6  vpermilpd xmm15, xmm15, 0x00
000074da185d2cbc  vmovaps xmm3, [rsp+0x20]
000074da185d2cc2  vmovaps [rsp+0x20], xmm1
000074da185d2cc8  vmovaps xmm1, [rsp+0xE0]
000074da185d2cd1  vmovaps [rsp+0x50], xmm14
000074da185d2cd7  vmovaps [rsp+0x60], xmm13
000074da185d2cdd  movaps xmm14, xmm3
000074da185d2ce1  vfmadd231pd xmm14, xmm1, xmm15
000074da185d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
000074da185d2cec  vptest xmm13, xmm13
000074da185d2cf1  jnz 0x000074DA185D3F5D
000074da185d2cf7  vmovaps xmm1, [rsp+0xB0]
000074da185d2d00  vpermilpd xmm1, xmm1, 0x00
000074da185d2d06  vmovaps xmm15, [rsp+0x10]
000074da185d2d0c  movaps xmm13, xmm15
000074da185d2d10  vfmadd231pd xmm13, xmm10, xmm1
000074da185d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
000074da185d2d1b  vptest xmm3, xmm3
000074da185d2d20  jnz 0x000074DA185D40B5
000074da185d2d26  vmovaps xmm1, [rsp+0xB0]
000074da185d2d2f  vpermilpd xmm1, xmm1, 0x00
000074da185d2d35  vmovaps xmm15, [rsp+0x30]
000074da185d2d3b  movaps xmm10, xmm15
000074da185d2d3f  vfmadd231pd xmm10, xmm11, xmm1
000074da185d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
000074da185d2d4a  vptest xmm3, xmm3
000074da185d2d4f  jnz 0x000074DA185D420E
000074da185d2d55  vmovaps xmm1, [rsp+0xB0]
000074da185d2d5e  vpermilpd xmm1, xmm1, 0x00
000074da185d2d64  movaps xmm15, xmm12
000074da185d2d68  vfmadd231pd xmm15, xmm5, xmm1
000074da185d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
000074da185d2d73  vptest xmm11, xmm11
000074da185d2d78  jnz 0x000074DA185D4367
000074da185d2d7e  vmovaps [rsp+0x10], xmm9
000074da185d2d84  vmovaps xmm1, [rsp+0x10]
000074da185d2d8a  por xmm9, xmm1
000074da185d2d8f  movaps [r15+0x180], xmm9
000074da185d2d97  vmovaps [rsp+0x10], xmm2
000074da185d2d9d  vmovaps xmm1, [rsp+0x10]
000074da185d2da3  por xmm2, xmm1
000074da185d2da7  movaps [r15+0x2D0], xmm2
000074da185d2daf  vmovaps xmm12, [rsp+0xD0]
000074da185d2db8  vpermilpd xmm12, xmm12, 0x00
000074da185d2dbe  vmovaps xmm11, [rsp+0x60]
000074da185d2dc4  movaps xmm5, xmm13
000074da185d2dc8  vfmadd231pd xmm5, xmm11, xmm12
000074da185d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
000074da185d2dd2  vptest xmm3, xmm3
000074da185d2dd7  jnz 0x000074DA185D44BF
000074da185d2ddd  vmovaps xmm13, [rsp+0xD0]
000074da185d2de6  vpermilpd xmm13, xmm13, 0x00
000074da185d2dec  movaps xmm12, xmm14
000074da185d2df0  vfmadd231pd xmm12, xmm9, xmm13
000074da185d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
000074da185d2dfb  vptest xmm11, xmm11
000074da185d2e00  jnz 0x000074DA185D4617
000074da185d2e06  lea rax, [r14+0x80]
000074da185d2e0d  movups xmm14, [r13+rax*1]
000074da185d2e13  movaps [r15+0x2F0], xmm14
000074da185d2e1b  vmovaps xmm13, [rsp+0xD0]
000074da185d2e24  vpermilpd xmm13, xmm13, 0x00
000074da185d2e2a  movaps xmm11, xmm10
000074da185d2e2e  vfmadd231pd xmm11, xmm8, xmm13
000074da185d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
000074da185d2e39  vptest xmm9, xmm9
000074da185d2e3e  jnz 0x000074DA185D477B
000074da185d2e44  vmovaps xmm13, [rsp+0xD0]
000074da185d2e4d  vpermilpd xmm13, xmm13, 0x00
000074da185d2e53  movaps xmm10, xmm15
000074da185d2e57  vfmadd231pd xmm10, xmm1, xmm13
000074da185d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
000074da185d2e62  vptest xmm9, xmm9
000074da185d2e67  jnz 0x000074DA185D48D5
000074da185d2e6d  vmovaps [rsp+0x10], xmm7
000074da185d2e73  vmovaps xmm1, [rsp+0x10]
000074da185d2e79  por xmm7, xmm1
000074da185d2e7d  movaps [r15+0x160], xmm7
000074da185d2e85  lea rax, [r14+0x40]
000074da185d2e89  movups xmm1, [r13+rax*1]
000074da185d2e8f  lea rax, [r14+0x50]
000074da185d2e93  movups xmm15, [r13+rax*1]
000074da185d2e99  movaps [r15+0x1B0], xmm1
000074da185d2ea1  movaps [r15+0x1A0], xmm15
000074da185d2ea9  vmovaps xmm13, [rsp+0xA0]
000074da185d2eb2  vpermilpd xmm13, xmm13, 0x00
000074da185d2eb8  vmovaps xmm9, [rsp+0x40]
000074da185d2ebe  movaps xmm8, xmm5
000074da185d2ec2  vfmadd231pd xmm8, xmm9, xmm13
000074da185d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
000074da185d2ecd  vptest xmm3, xmm3
000074da185d2ed2  jnz 0x000074DA185D4A42
000074da185d2ed8  vmovaps xmm13, [rsp+0xA0]
000074da185d2ee1  vpermilpd xmm13, xmm13, 0x00
000074da185d2ee7  movaps xmm9, xmm12
000074da185d2eeb  vfmadd231pd xmm9, xmm7, xmm13
000074da185d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
000074da185d2ef6  vptest xmm5, xmm5
000074da185d2efb  jnz 0x000074DA185D4B9B
000074da185d2f01  vmovaps xmm13, [rsp+0xA0]
000074da185d2f0a  vpermilpd xmm13, xmm13, 0x00
000074da185d2f10  movaps xmm12, xmm11
000074da185d2f14  vfmadd231pd xmm12, xmm6, xmm13
000074da185d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
000074da185d2f1f  vptest xmm7, xmm7
000074da185d2f24  jnz 0x000074DA185D4CF4
000074da185d2f2a  vmovaps xmm13, [rsp+0xA0]
000074da185d2f33  vpermilpd xmm13, xmm13, 0x00
000074da185d2f39  vmovaps xmm11, [rsp+0x50]
000074da185d2f3f  movaps xmm7, xmm10
000074da185d2f43  vfmadd231pd xmm7, xmm11, xmm13
000074da185d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
000074da185d2f4d  vptest xmm6, xmm6
000074da185d2f52  jnz 0x000074DA185D4E4D
000074da185d2f58  lea rax, [r14+0x60]
000074da185d2f5c  movups xmm13, [r13+rax*1]
000074da185d2f62  lea rax, [r14+0x70]
000074da185d2f66  movups xmm11, [r13+rax*1]
000074da185d2f6c  movaps [r15+0x150], xmm13
000074da185d2f74  movaps [r15+0x120], xmm11
000074da185d2f7c  vmovaps xmm10, [rsp+0xC0]
000074da185d2f85  vpermilpd xmm10, xmm10, 0x00
000074da185d2f8b  movaps xmm6, xmm8
000074da185d2f8f  vfmadd231pd xmm6, xmm15, xmm10
000074da185d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
000074da185d2f99  vptest xmm5, xmm5
000074da185d2f9e  jnz 0x000074DA185D4FB9
000074da185d2fa4  vmovaps xmm15, [rsp+0xC0]
000074da185d2fad  vpermilpd xmm15, xmm15, 0x00
000074da185d2fb3  movaps xmm10, xmm9
000074da185d2fb7  vfmadd231pd xmm10, xmm13, xmm15
000074da185d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
000074da185d2fc2  vptest xmm8, xmm8
000074da185d2fc7  jnz 0x000074DA185D5111
000074da185d2fcd  vmovaps xmm15, [rsp+0xC0]
000074da185d2fd6  vpermilpd xmm15, xmm15, 0x00
000074da185d2fdc  movaps xmm13, xmm12
000074da185d2fe0  vfmadd231pd xmm13, xmm4, xmm15
000074da185d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
000074da185d2feb  vptest xmm9, xmm9
000074da185d2ff0  jnz 0x000074DA185D526B
000074da185d2ff6  vmovaps xmm15, [rsp+0xC0]
000074da185d2fff  vpermilpd xmm15, xmm15, 0x00
000074da185d3005  movaps xmm12, xmm7
000074da185d3009  vfmadd231pd xmm12, xmm1, xmm15
000074da185d300e  vcmppd xmm9, xmm12, xmm12, 0x03
000074da185d3014  vptest xmm9, xmm9
000074da185d3019  jnz 0x000074DA185D53C4
000074da185d301f  lea rax, [r14+0x20]
000074da185d3023  movups xmm1, [r13+rax*1]
000074da185d3029  lea rax, [r14+0x30]
000074da185d302d  movups xmm15, [r13+rax*1]
000074da185d3033  vmovaps xmm9, [rsp+0x70]
000074da185d3039  vpermilpd xmm9, xmm9, 0x00
000074da185d303f  vmovaps xmm8, [rsp+0x20]
000074da185d3045  movaps xmm7, xmm6
000074da185d3048  vfmadd231pd xmm7, xmm8, xmm9
000074da185d304d  vcmppd xmm5, xmm7, xmm7, 0x03
000074da185d3052  vptest xmm5, xmm5
000074da185d3057  jnz 0x000074DA185D5530
000074da185d305d  vmovaps xmm9, [rsp+0x70]
000074da185d3063  vpermilpd xmm9, xmm9, 0x00
000074da185d3069  movaps xmm8, xmm10
000074da185d306d  vfmadd231pd xmm8, xmm14, xmm9
000074da185d3072  vcmppd xmm6, xmm8, xmm8, 0x03
000074da185d3078  vptest xmm6, xmm6
000074da185d307d  jnz 0x000074DA185D5687
000074da185d3083  vmovaps xmm14, [rsp+0x70]
000074da185d3089  vpermilpd xmm14, xmm14, 0x00
000074da185d308f  movaps xmm10, xmm13
000074da185d3093  vfmadd231pd xmm10, xmm11, xmm14
000074da185d3098  vcmppd xmm9, xmm10, xmm10, 0x03
000074da185d309e  vptest xmm9, xmm9
000074da185d30a3  jnz 0x000074DA185D57E1
000074da185d30a9  vmovaps xmm14, [rsp+0x70]
000074da185d30af  vpermilpd xmm14, xmm14, 0x00
000074da185d30b5  movaps xmm13, xmm12
000074da185d30b9  vfmadd231pd xmm13, xmm15, xmm14
000074da185d30be  vcmppd xmm11, xmm13, xmm13, 0x03
000074da185d30c4  vptest xmm11, xmm11
000074da185d30c9  jnz 0x000074DA185D593B
000074da185d30cf  lea rax, [r14+0x90]
000074da185d30d6  movups xmm15, [r13+rax*1]
000074da185d30dc  lea rax, [r14+0xA0]
000074da185d30e3  movups xmm14, [r13+rax*1]
000074da185d30e9  movaps [r15+0x140], xmm15
000074da185d30f1  movaps [r15+0x130], xmm14
000074da185d30f9  vmovaps xmm12, [rsp+0x90]
000074da185d3102  vpermilpd xmm12, xmm12, 0x00
000074da185d3108  movaps xmm11, xmm7
000074da185d310c  vfmadd231pd xmm11, xmm1, xmm12
000074da185d3111  vcmppd xmm9, xmm11, xmm11, 0x03
000074da185d3117  vptest xmm9, xmm9
000074da185d311c  jnz 0x000074DA185D5AA9
000074da185d3122  movaps [r15+0x220], xmm11
000074da185d312a  lea rax, [r14+0x10]
000074da185d312e  movups xmm1, [r13+rax*1]
000074da185d3134  movaps [r15+0x240], xmm1
000074da185d313c  vmovaps xmm12, [rsp+0x90]
000074da185d3145  vpermilpd xmm12, xmm12, 0x00
000074da185d314b  movaps xmm9, xmm8
000074da185d314f  vfmadd231pd xmm9, xmm14, xmm12
000074da185d3154  vcmppd xmm7, xmm9, xmm9, 0x03
000074da185d315a  vptest xmm7, xmm7
000074da185d315f  jnz 0x000074DA185D5C0B
000074da185d3165  movaps [r15+0x110], xmm9
000074da185d316d  vmovaps xmm14, [rsp+0x90]
000074da185d3176  vpermilpd xmm14, xmm14, 0x00
000074da185d317c  movaps xmm12, xmm10
000074da185d3180  vfmadd231pd xmm12, xmm15, xmm14
000074da185d3185  vcmppd xmm8, xmm12, xmm12, 0x03
000074da185d318b  vptest xmm8, xmm8
000074da185d3190  jnz 0x000074DA185D5D65
000074da185d3196  movaps [r15+0x170], xmm12
000074da185d319e  vmovaps xmm15, [rsp+0x90]
000074da185d31a7  vpermilpd xmm15, xmm15, 0x00
000074da185d31ad  movaps xmm14, xmm13
000074da185d31b1  vfmadd231pd xmm14, xmm1, xmm15
000074da185d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
000074da185d31bc  vptest xmm10, xmm10
000074da185d31c1  jnz 0x000074DA185D5EBF
000074da185d31c7  movaps [r15+0x230], xmm14
000074da185d31cf  mov eax, 0x432190
000074da185d31d4  movups [r13+rax*1], xmm9
000074da185d31da  mov eax, 0x4321A0
000074da185d31df  movups [r13+rax*1], xmm12
000074da185d31e5  mov eax, 0x4321B0
000074da185d31ea  movups [r13+rax*1], xmm11
000074da185d31f0  mov eax, 0x4321C0
000074da185d31f5  movups [r13+rax*1], xmm14
000074da185d31fb  mov eax, [r15+0x108]
000074da185d3202  sahf
000074da185d3203  jnz 0x000074DA185D3235
000074da185d3205  cmp dword ptr [r15+0x318], 0x00
000074da185d320d  jz 0x000074DA185D9950
000074da185d3213  nop [rax+rax*1], ax
000074da185d321c  nop [rax+rax*1], eax
000074da185d3224  mov eax, 0x410664
000074da185d3229  mov [r15+0x100], rax
000074da185d3230  jmp 0x000074DA183FE110
000074da185d3235  cmp dword ptr [r15+0x318], 0x00
000074da185d323d  jz 0x000074DA185D6050
000074da185d3243  nop [rax+rax*1], ax
000074da185d324c  nop [rax+rax*1], eax
000074da185d3254  mov eax, 0x4104F0
000074da185d3259  mov [r15+0x100], rax
000074da185d3260  jmp 0x000074DA183FE110
000074da185d3265  int3
000074da185d3266  call 0x000074DA183FF430
000074da185d326b  jmp 0x000074DA185D230A
000074da185d3270  call 0x000074DA184E5820
000074da185d3275  jmp 0x000074DA185D2314
000074da185d327a  call 0x000074DA184E45A0
000074da185d327f  jmp 0x000074DA185D2326
000074da185d3284  call 0x000074DA184E3320
000074da185d3289  jmp 0x000074DA185D2330
000074da185d328e  call 0x000074DA184E20A0
000074da185d3293  jmp 0x000074DA185D233D
000074da185d3298  call 0x000074DA184E0E30
000074da185d329d  jmp 0x000074DA185D234A
000074da185d32a2  call 0x000074DA184D6600
000074da185d32a7  jmp 0x000074DA185D2357
000074da185d32ac  call 0x000074DA184B52F0
000074da185d32b1  jmp 0x000074DA185D2361
000074da185d32b6  call 0x000074DA184BE9C0
000074da185d32bb  jmp 0x000074DA185D236B
000074da185d32c0  call 0x000074DA184BD750
000074da185d32c5  jmp 0x000074DA185D2378
000074da185d32ca  call 0x000074DA184BC4E0
000074da185d32cf  jmp 0x000074DA185D2385
000074da185d32d4  call 0x000074DA184BB270
000074da185d32d9  jmp 0x000074DA185D2392
000074da185d32de  call 0x000074DA184BA000
000074da185d32e3  jmp 0x000074DA185D239F
000074da185d32e8  call 0x000074DA184B8D90
000074da185d32ed  jmp 0x000074DA185D23AC
000074da185d32f2  call 0x000074DA184B8A20
000074da185d32f7  jmp 0x000074DA185D23B9
000074da185d32fc  call 0x000074DA184BEAE0
000074da185d3301  jmp 0x000074DA185D23C6
000074da185d3306  call 0x000074DA184B5400
000074da185d330b  jmp 0x000074DA185D23D3
000074da185d3310  call 0x000074DA184B52F0
000074da185d3315  jmp 0x000074DA185D23E0
000074da185d331a  call 0x000074DA184BE9C0
000074da185d331f  jmp 0x000074DA185D23ED
000074da185d3324  call 0x000074DA184B77B0
000074da185d3329  jmp 0x000074DA185D23FA
000074da185d332e  call 0x000074DA184B6550
000074da185d3333  jmp 0x000074DA185D2407
000074da185d3338  call 0x000074DA184B52F0
000074da185d333d  jmp 0x000074DA185D2417
000074da185d3342  call 0x000074DA184B52F0
000074da185d3347  jmp 0x000074DA185D2427
000074da185d334c  call 0x000074DA184BEAE0
000074da185d3351  jmp 0x000074DA185D2431
000074da185d3356  call 0x000074DA184BEAE0
000074da185d335b  jmp 0x000074DA185D2444
000074da185d3360  call 0x000074DA184BE9C0
000074da185d3365  jmp 0x000074DA185D2451
000074da185d336a  call 0x000074DA184B52F0
000074da185d336f  jmp 0x000074DA185D2464
000074da185d3374  call 0x000074DA184B6660
000074da185d3379  jmp 0x000074DA185D2471
000074da185d337e  call 0x000074DA184B78C0
000074da185d3383  jmp 0x000074DA185D247E
000074da185d3388  call 0x000074DA184B77B0
000074da185d338d  jmp 0x000074DA185D248B
000074da185d3392  call 0x000074DA184B6550
000074da185d3397  jmp 0x000074DA185D2498
000074da185d339c  call 0x000074DA184B52F0
000074da185d33a1  jmp 0x000074DA185D24AB
000074da185d33a6  call 0x000074DA184B52F0
000074da185d33ab  jmp 0x000074DA185D24BE
000074da185d33b0  call 0x000074DA184B52F0
000074da185d33b5  jmp 0x000074DA185D24E5
000074da185d33ba  call 0x000074DA184B52F0
000074da185d33bf  jmp 0x000074DA185D24F8
000074da185d33c4  call 0x000074DA184B52F0
000074da185d33c9  jmp 0x000074DA185D250B
000074da185d33ce  call 0x000074DA184B52F0
000074da185d33d3  jmp 0x000074DA185D2521
000074da185d33d8  call 0x000074DA184B52F0
000074da185d33dd  jmp 0x000074DA185D2537
000074da185d33e2  call 0x000074DA184B52F0
000074da185d33e7  jmp 0x000074DA185D254D
000074da185d33ec  call 0x000074DA183FF540
000074da185d33f1  jmp 0x000074DA185D256E
000074da185d33f6  call 0x000074DA18402FE0
000074da185d33fb  jmp 0x000074DA185D2578
000074da185d3400  call 0x000074DA183FF540
000074da185d3405  jmp 0x000074DA185D2588
000074da185d340a  call 0x000074DA183FF540
000074da185d340f  jmp 0x000074DA185D259B
000074da185d3414  call 0x000074DA183FF540
000074da185d3419  jmp 0x000074DA185D25AE
000074da185d341e  call 0x000074DA183FF540
000074da185d3423  jmp 0x000074DA185D25C1
000074da185d3428  call 0x000074DA184C0370
000074da185d342d  jmp 0x000074DA185D25E0
000074da185d3432  call 0x000074DA184BF100
000074da185d3437  jmp 0x000074DA185D25E9
000074da185d343c  call 0x000074DA184C0370
000074da185d3441  jmp 0x000074DA185D2659
000074da185d3446  call 0x000074DA184BF100
000074da185d344b  jmp 0x000074DA185D2662
000074da185d3450  call 0x000074DA184C0370
000074da185d3455  jmp 0x000074DA185D270C
000074da185d345a  call 0x000074DA184BF100
000074da185d345f  jmp 0x000074DA185D2715
000074da185d3464  call 0x000074DA1840B720
000074da185d3469  jmp 0x000074DA185D27F7
000074da185d346e  call 0x000074DA184D64F0
000074da185d3473  jmp 0x000074DA185D281F
000074da185d3478  call 0x000074DA184B47C0
000074da185d347d  jmp 0x000074DA185D283A
000074da185d3482  sub rsp, 0x08
000074da185d3486  push rax
000074da185d3487  push rcx
000074da185d3488  push rdx
000074da185d3489  push rdi
000074da185d348a  push rsi
000074da185d348b  push r8
000074da185d348d  push r9
000074da185d348f  push r10
000074da185d3491  push r11
000074da185d3493  sub rsp, 0xF0
000074da185d349a  vmovaps [rsp], xmm0
000074da185d349f  vmovaps [rsp+0x10], xmm1
000074da185d34a5  vmovaps [rsp+0x20], xmm2
000074da185d34ab  vmovaps [rsp+0x30], xmm3
000074da185d34b1  vmovaps [rsp+0x40], xmm4
000074da185d34b7  vmovaps [rsp+0x50], xmm5
000074da185d34bd  vmovaps [rsp+0x60], xmm6
000074da185d34c3  vmovaps [rsp+0x70], xmm7
000074da185d34c9  vmovaps [rsp+0x80], xmm8
000074da185d34d2  vmovaps [rsp+0x90], xmm9
000074da185d34db  vmovaps [rsp+0xA0], xmm10
000074da185d34e4  vmovaps [rsp+0xB0], xmm11
000074da185d34ed  vmovaps [rsp+0xC0], xmm12
000074da185d34f6  vmovaps [rsp+0xD0], xmm14
000074da185d34ff  vmovaps [rsp+0xE0], xmm15
000074da185d3508  sub rsp, 0x40
000074da185d350c  lea rdi, [rsp]
000074da185d3510  lea rsi, [rsp+0x10]
000074da185d3515  lea rdx, [rsp+0x20]
000074da185d351a  lea rcx, [rsp+0x30]
000074da185d351f  mov r8d, 0x00
000074da185d3525  lea r9, [r15+0x3A8]
000074da185d352c  movaps [rdi], xmm13
000074da185d3530  movaps [rsi], xmm1
000074da185d3533  movaps [rdx], xmm15
000074da185d3537  movaps [rcx], xmm14
000074da185d353b  mov rax, 0x5946061DFA50
000074da185d3545  call rax
000074da185d3547  movaps xmm13, [rsp]
000074da185d354c  add rsp, 0x40
000074da185d3550  vmovaps xmm0, [rsp]
000074da185d3555  vmovaps xmm1, [rsp+0x10]
000074da185d355b  vmovaps xmm2, [rsp+0x20]
000074da185d3561  vmovaps xmm3, [rsp+0x30]
000074da185d3567  vmovaps xmm4, [rsp+0x40]
000074da185d356d  vmovaps xmm5, [rsp+0x50]
000074da185d3573  vmovaps xmm6, [rsp+0x60]
000074da185d3579  vmovaps xmm7, [rsp+0x70]
000074da185d357f  vmovaps xmm8, [rsp+0x80]
000074da185d3588  vmovaps xmm9, [rsp+0x90]
000074da185d3591  vmovaps xmm10, [rsp+0xA0]
000074da185d359a  vmovaps xmm11, [rsp+0xB0]
000074da185d35a3  vmovaps xmm12, [rsp+0xC0]
000074da185d35ac  vmovaps xmm14, [rsp+0xD0]
000074da185d35b5  vmovaps xmm15, [rsp+0xE0]
000074da185d35be  add rsp, 0xF0
000074da185d35c5  pop r11
000074da185d35c7  pop r10
000074da185d35c9  pop r9
000074da185d35cb  pop r8
000074da185d35cd  pop rsi
000074da185d35ce  pop rdi
000074da185d35cf  pop rdx
000074da185d35d0  pop rcx
000074da185d35d1  pop rax
000074da185d35d2  add rsp, 0x08
000074da185d35d6  jmp 0x000074DA185D28AD
000074da185d35db  sub rsp, 0x08
000074da185d35df  push rax
000074da185d35e0  push rcx
000074da185d35e1  push rdx
000074da185d35e2  push rdi
000074da185d35e3  push rsi
000074da185d35e4  push r8
000074da185d35e6  push r9
000074da185d35e8  push r10
000074da185d35ea  push r11
000074da185d35ec  sub rsp, 0xF0
000074da185d35f3  vmovaps [rsp], xmm0
000074da185d35f8  vmovaps [rsp+0x10], xmm1
000074da185d35fe  vmovaps [rsp+0x20], xmm2
000074da185d3604  vmovaps [rsp+0x30], xmm3
000074da185d360a  vmovaps [rsp+0x40], xmm4
000074da185d3610  vmovaps [rsp+0x50], xmm5
000074da185d3616  vmovaps [rsp+0x60], xmm6
000074da185d361c  vmovaps [rsp+0x70], xmm7
000074da185d3622  vmovaps [rsp+0x80], xmm8
000074da185d362b  vmovaps [rsp+0x90], xmm9
000074da185d3634  vmovaps [rsp+0xA0], xmm10
000074da185d363d  vmovaps [rsp+0xB0], xmm11
000074da185d3646  vmovaps [rsp+0xC0], xmm12
000074da185d364f  vmovaps [rsp+0xD0], xmm13
000074da185d3658  vmovaps [rsp+0xE0], xmm14
000074da185d3661  sub rsp, 0x40
000074da185d3665  lea rdi, [rsp]
000074da185d3669  lea rsi, [rsp+0x10]
000074da185d366e  lea rdx, [rsp+0x20]
000074da185d3673  lea rcx, [rsp+0x30]
000074da185d3678  mov r8d, 0x00
000074da185d367e  lea r9, [r15+0x3A8]
000074da185d3685  movaps [rdi], xmm15
000074da185d3689  movaps [rsi], xmm5
000074da185d368c  movaps [rdx], xmm1
000074da185d368f  movaps [rcx], xmm14
000074da185d3693  mov rax, 0x5946061DFA50
000074da185d369d  call rax
000074da185d369f  movaps xmm15, [rsp]
000074da185d36a4  add rsp, 0x40
000074da185d36a8  vmovaps xmm0, [rsp]
000074da185d36ad  vmovaps xmm1, [rsp+0x10]
000074da185d36b3  vmovaps xmm2, [rsp+0x20]
000074da185d36b9  vmovaps xmm3, [rsp+0x30]
000074da185d36bf  vmovaps xmm4, [rsp+0x40]
000074da185d36c5  vmovaps xmm5, [rsp+0x50]
000074da185d36cb  vmovaps xmm6, [rsp+0x60]
000074da185d36d1  vmovaps xmm7, [rsp+0x70]
000074da185d36d7  vmovaps xmm8, [rsp+0x80]
000074da185d36e0  vmovaps xmm9, [rsp+0x90]
000074da185d36e9  vmovaps xmm10, [rsp+0xA0]
000074da185d36f2  vmovaps xmm11, [rsp+0xB0]
000074da185d36fb  vmovaps xmm12, [rsp+0xC0]
000074da185d3704  vmovaps xmm13, [rsp+0xD0]
000074da185d370d  vmovaps xmm14, [rsp+0xE0]
000074da185d3716  add rsp, 0xF0
000074da185d371d  pop r11
000074da185d371f  pop r10
000074da185d3721  pop r9
000074da185d3723  pop r8
000074da185d3725  pop rsi
000074da185d3726  pop rdi
000074da185d3727  pop rdx
000074da185d3728  pop rcx
000074da185d3729  pop rax
000074da185d372a  add rsp, 0x08
000074da185d372e  jmp 0x000074DA185D28D0
000074da185d3733  call 0x000074DA183FF430
000074da185d3738  jmp 0x000074DA185D295D
000074da185d373d  sub rsp, 0x08
000074da185d3741  push rax
000074da185d3742  push rcx
000074da185d3743  push rdx
000074da185d3744  push rdi
000074da185d3745  push rsi
000074da185d3746  push r8
000074da185d3748  push r9
000074da185d374a  push r10
000074da185d374c  push r11
000074da185d374e  sub rsp, 0xF0
000074da185d3755  vmovaps [rsp], xmm0
000074da185d375a  vmovaps [rsp+0x10], xmm1
000074da185d3760  vmovaps [rsp+0x20], xmm2
000074da185d3766  vmovaps [rsp+0x30], xmm3
000074da185d376c  vmovaps [rsp+0x40], xmm4
000074da185d3772  vmovaps [rsp+0x50], xmm5
000074da185d3778  vmovaps [rsp+0x60], xmm6
000074da185d377e  vmovaps [rsp+0x70], xmm7
000074da185d3784  vmovaps [rsp+0x80], xmm8
000074da185d378d  vmovaps [rsp+0x90], xmm9
000074da185d3796  vmovaps [rsp+0xA0], xmm10
000074da185d379f  vmovaps [rsp+0xB0], xmm11
000074da185d37a8  vmovaps [rsp+0xC0], xmm12
000074da185d37b1  vmovaps [rsp+0xD0], xmm14
000074da185d37ba  vmovaps [rsp+0xE0], xmm15
000074da185d37c3  sub rsp, 0x40
000074da185d37c7  lea rdi, [rsp]
000074da185d37cb  lea rsi, [rsp+0x10]
000074da185d37d0  lea rdx, [rsp+0x20]
000074da185d37d5  lea rcx, [rsp+0x30]
000074da185d37da  mov r8d, 0x00
000074da185d37e0  lea r9, [r15+0x3A8]
000074da185d37e7  movaps [rdi], xmm13
000074da185d37eb  movaps [rsi], xmm1
000074da185d37ee  movaps [rdx], xmm15
000074da185d37f2  movaps [rcx], xmm14
000074da185d37f6  mov rax, 0x5946061DFA50
000074da185d3800  call rax
000074da185d3802  movaps xmm13, [rsp]
000074da185d3807  add rsp, 0x40
000074da185d380b  vmovaps xmm0, [rsp]
000074da185d3810  vmovaps xmm1, [rsp+0x10]
000074da185d3816  vmovaps xmm2, [rsp+0x20]
000074da185d381c  vmovaps xmm3, [rsp+0x30]
000074da185d3822  vmovaps xmm4, [rsp+0x40]
000074da185d3828  vmovaps xmm5, [rsp+0x50]
000074da185d382e  vmovaps xmm6, [rsp+0x60]
000074da185d3834  vmovaps xmm7, [rsp+0x70]
000074da185d383a  vmovaps xmm8, [rsp+0x80]
000074da185d3843  vmovaps xmm9, [rsp+0x90]
000074da185d384c  vmovaps xmm10, [rsp+0xA0]
000074da185d3855  vmovaps xmm11, [rsp+0xB0]
000074da185d385e  vmovaps xmm12, [rsp+0xC0]
000074da185d3867  vmovaps xmm14, [rsp+0xD0]
000074da185d3870  vmovaps xmm15, [rsp+0xE0]
000074da185d3879  add rsp, 0xF0
000074da185d3880  pop r11
000074da185d3882  pop r10
000074da185d3884  pop r9
000074da185d3886  pop r8
000074da185d3888  pop rsi
000074da185d3889  pop rdi
000074da185d388a  pop rdx
000074da185d388b  pop rcx
000074da185d388c  pop rax
000074da185d388d  add rsp, 0x08
000074da185d3891  jmp 0x000074DA185D29C1
000074da185d3896  call 0x000074DA183FF430
000074da185d389b  jmp 0x000074DA185D29CE
000074da185d38a0  sub rsp, 0x08
000074da185d38a4  push rax
000074da185d38a5  push rcx
000074da185d38a6  push rdx
000074da185d38a7  push rdi
000074da185d38a8  push rsi
000074da185d38a9  push r8
000074da185d38ab  push r9
000074da185d38ad  push r10
000074da185d38af  push r11
000074da185d38b1  sub rsp, 0xF0
000074da185d38b8  vmovaps [rsp], xmm0
000074da185d38bd  vmovaps [rsp+0x10], xmm1
000074da185d38c3  vmovaps [rsp+0x20], xmm2
000074da185d38c9  vmovaps [rsp+0x30], xmm3
000074da185d38cf  vmovaps [rsp+0x40], xmm4
000074da185d38d5  vmovaps [rsp+0x50], xmm5
000074da185d38db  vmovaps [rsp+0x60], xmm6
000074da185d38e1  vmovaps [rsp+0x70], xmm7
000074da185d38e7  vmovaps [rsp+0x80], xmm8
000074da185d38f0  vmovaps [rsp+0x90], xmm9
000074da185d38f9  vmovaps [rsp+0xA0], xmm10
000074da185d3902  vmovaps [rsp+0xB0], xmm11
000074da185d390b  vmovaps [rsp+0xC0], xmm13
000074da185d3914  vmovaps [rsp+0xD0], xmm14
000074da185d391d  vmovaps [rsp+0xE0], xmm15
000074da185d3926  sub rsp, 0x40
000074da185d392a  lea rdi, [rsp]
000074da185d392e  lea rsi, [rsp+0x10]
000074da185d3933  lea rdx, [rsp+0x20]
000074da185d3938  lea rcx, [rsp+0x30]
000074da185d393d  mov r8d, 0x00
000074da185d3943  lea r9, [r15+0x3A8]
000074da185d394a  movaps [rdi], xmm12
000074da185d394e  movaps [rsi], xmm15
000074da185d3952  movaps [rdx], xmm1
000074da185d3955  movaps [rcx], xmm14
000074da185d3959  mov rax, 0x5946061DFA50
000074da185d3963  call rax
000074da185d3965  movaps xmm12, [rsp]
000074da185d396a  add rsp, 0x40
000074da185d396e  vmovaps xmm0, [rsp]
000074da185d3973  vmovaps xmm1, [rsp+0x10]
000074da185d3979  vmovaps xmm2, [rsp+0x20]
000074da185d397f  vmovaps xmm3, [rsp+0x30]
000074da185d3985  vmovaps xmm4, [rsp+0x40]
000074da185d398b  vmovaps xmm5, [rsp+0x50]
000074da185d3991  vmovaps xmm6, [rsp+0x60]
000074da185d3997  vmovaps xmm7, [rsp+0x70]
000074da185d399d  vmovaps xmm8, [rsp+0x80]
000074da185d39a6  vmovaps xmm9, [rsp+0x90]
000074da185d39af  vmovaps xmm10, [rsp+0xA0]
000074da185d39b8  vmovaps xmm11, [rsp+0xB0]
000074da185d39c1  vmovaps xmm13, [rsp+0xC0]
000074da185d39ca  vmovaps xmm14, [rsp+0xD0]
000074da185d39d3  vmovaps xmm15, [rsp+0xE0]
000074da185d39dc  add rsp, 0xF0
000074da185d39e3  pop r11
000074da185d39e5  pop r10
000074da185d39e7  pop r9
000074da185d39e9  pop r8
000074da185d39eb  pop rsi
000074da185d39ec  pop rdi
000074da185d39ed  pop rdx
000074da185d39ee  pop rcx
000074da185d39ef  pop rax
000074da185d39f0  add rsp, 0x08
000074da185d39f4  jmp 0x000074DA185D29FA
000074da185d39f9  sub rsp, 0x08
000074da185d39fd  push rax
000074da185d39fe  push rcx
000074da185d39ff  push rdx
000074da185d3a00  push rdi
000074da185d3a01  push rsi
000074da185d3a02  push r8
000074da185d3a04  push r9
000074da185d3a06  push r10
000074da185d3a08  push r11
000074da185d3a0a  sub rsp, 0xF0
000074da185d3a11  vmovaps [rsp], xmm0
000074da185d3a16  vmovaps [rsp+0x10], xmm1
000074da185d3a1c  vmovaps [rsp+0x20], xmm2
000074da185d3a22  vmovaps [rsp+0x30], xmm3
000074da185d3a28  vmovaps [rsp+0x40], xmm4
000074da185d3a2e  vmovaps [rsp+0x50], xmm5
000074da185d3a34  vmovaps [rsp+0x60], xmm6
000074da185d3a3a  vmovaps [rsp+0x70], xmm7
000074da185d3a40  vmovaps [rsp+0x80], xmm8
000074da185d3a49  vmovaps [rsp+0x90], xmm9
000074da185d3a52  vmovaps [rsp+0xA0], xmm10
000074da185d3a5b  vmovaps [rsp+0xB0], xmm11
000074da185d3a64  vmovaps [rsp+0xC0], xmm12
000074da185d3a6d  vmovaps [rsp+0xD0], xmm14
000074da185d3a76  vmovaps [rsp+0xE0], xmm15
000074da185d3a7f  sub rsp, 0x40
000074da185d3a83  lea rdi, [rsp]
000074da185d3a87  lea rsi, [rsp+0x10]
000074da185d3a8c  lea rdx, [rsp+0x20]
000074da185d3a91  lea rcx, [rsp+0x30]
000074da185d3a96  mov r8d, 0x00
000074da185d3a9c  lea r9, [r15+0x3A8]
000074da185d3aa3  movaps [rdi], xmm13
000074da185d3aa7  movaps [rsi], xmm1
000074da185d3aaa  movaps [rdx], xmm15
000074da185d3aae  movaps [rcx], xmm14
000074da185d3ab2  mov rax, 0x5946061DFA50
000074da185d3abc  call rax
000074da185d3abe  movaps xmm13, [rsp]
000074da185d3ac3  add rsp, 0x40
000074da185d3ac7  vmovaps xmm0, [rsp]
000074da185d3acc  vmovaps xmm1, [rsp+0x10]
000074da185d3ad2  vmovaps xmm2, [rsp+0x20]
000074da185d3ad8  vmovaps xmm3, [rsp+0x30]
000074da185d3ade  vmovaps xmm4, [rsp+0x40]
000074da185d3ae4  vmovaps xmm5, [rsp+0x50]
000074da185d3aea  vmovaps xmm6, [rsp+0x60]
000074da185d3af0  vmovaps xmm7, [rsp+0x70]
000074da185d3af6  vmovaps xmm8, [rsp+0x80]
000074da185d3aff  vmovaps xmm9, [rsp+0x90]
000074da185d3b08  vmovaps xmm10, [rsp+0xA0]
000074da185d3b11  vmovaps xmm11, [rsp+0xB0]
000074da185d3b1a  vmovaps xmm12, [rsp+0xC0]
000074da185d3b23  vmovaps xmm14, [rsp+0xD0]
000074da185d3b2c  vmovaps xmm15, [rsp+0xE0]
000074da185d3b35  add rsp, 0xF0
000074da185d3b3c  pop r11
000074da185d3b3e  pop r10
000074da185d3b40  pop r9
000074da185d3b42  pop r8
000074da185d3b44  pop rsi
000074da185d3b45  pop rdi
000074da185d3b46  pop rdx
000074da185d3b47  pop rcx
000074da185d3b48  pop rax
000074da185d3b49  add rsp, 0x08
000074da185d3b4d  jmp 0x000074DA185D2B77
000074da185d3b52  sub rsp, 0x08
000074da185d3b56  push rax
000074da185d3b57  push rcx
000074da185d3b58  push rdx
000074da185d3b59  push rdi
000074da185d3b5a  push rsi
000074da185d3b5b  push r8
000074da185d3b5d  push r9
000074da185d3b5f  push r10
000074da185d3b61  push r11
000074da185d3b63  sub rsp, 0xF0
000074da185d3b6a  vmovaps [rsp], xmm0
000074da185d3b6f  vmovaps [rsp+0x10], xmm1
000074da185d3b75  vmovaps [rsp+0x20], xmm2
000074da185d3b7b  vmovaps [rsp+0x30], xmm3
000074da185d3b81  vmovaps [rsp+0x40], xmm4
000074da185d3b87  vmovaps [rsp+0x50], xmm5
000074da185d3b8d  vmovaps [rsp+0x60], xmm6
000074da185d3b93  vmovaps [rsp+0x70], xmm7
000074da185d3b99  vmovaps [rsp+0x80], xmm8
000074da185d3ba2  vmovaps [rsp+0x90], xmm9
000074da185d3bab  vmovaps [rsp+0xA0], xmm10
000074da185d3bb4  vmovaps [rsp+0xB0], xmm11
000074da185d3bbd  vmovaps [rsp+0xC0], xmm13
000074da185d3bc6  vmovaps [rsp+0xD0], xmm14
000074da185d3bcf  vmovaps [rsp+0xE0], xmm15
000074da185d3bd8  sub rsp, 0x40
000074da185d3bdc  lea rdi, [rsp]
000074da185d3be0  lea rsi, [rsp+0x10]
000074da185d3be5  lea rdx, [rsp+0x20]
000074da185d3bea  lea rcx, [rsp+0x30]
000074da185d3bef  mov r8d, 0x00
000074da185d3bf5  lea r9, [r15+0x3A8]
000074da185d3bfc  movaps [rdi], xmm12
000074da185d3c00  movaps [rsi], xmm15
000074da185d3c04  movaps [rdx], xmm14
000074da185d3c08  movaps [rcx], xmm1
000074da185d3c0b  mov rax, 0x5946061DFA50
000074da185d3c15  call rax
000074da185d3c17  movaps xmm12, [rsp]
000074da185d3c1c  add rsp, 0x40
000074da185d3c20  vmovaps xmm0, [rsp]
000074da185d3c25  vmovaps xmm1, [rsp+0x10]
000074da185d3c2b  vmovaps xmm2, [rsp+0x20]
000074da185d3c31  vmovaps xmm3, [rsp+0x30]
000074da185d3c37  vmovaps xmm4, [rsp+0x40]
000074da185d3c3d  vmovaps xmm5, [rsp+0x50]
000074da185d3c43  vmovaps xmm6, [rsp+0x60]
000074da185d3c49  vmovaps xmm7, [rsp+0x70]
000074da185d3c4f  vmovaps xmm8, [rsp+0x80]
000074da185d3c58  vmovaps xmm9, [rsp+0x90]
000074da185d3c61  vmovaps xmm10, [rsp+0xA0]
000074da185d3c6a  vmovaps xmm11, [rsp+0xB0]
000074da185d3c73  vmovaps xmm13, [rsp+0xC0]
000074da185d3c7c  vmovaps xmm14, [rsp+0xD0]
000074da185d3c85  vmovaps xmm15, [rsp+0xE0]
000074da185d3c8e  add rsp, 0xF0
000074da185d3c95  pop r11
000074da185d3c97  pop r10
000074da185d3c99  pop r9
000074da185d3c9b  pop r8
000074da185d3c9d  pop rsi
000074da185d3c9e  pop rdi
000074da185d3c9f  pop rdx
000074da185d3ca0  pop rcx
000074da185d3ca1  pop rax
000074da185d3ca2  add rsp, 0x08
000074da185d3ca6  jmp 0x000074DA185D2BB2
000074da185d3cab  sub rsp, 0x08
000074da185d3caf  push rax
000074da185d3cb0  push rcx
000074da185d3cb1  push rdx
000074da185d3cb2  push rdi
000074da185d3cb3  push rsi
000074da185d3cb4  push r8
000074da185d3cb6  push r9
000074da185d3cb8  push r10
000074da185d3cba  push r11
000074da185d3cbc  sub rsp, 0xF0
000074da185d3cc3  vmovaps [rsp], xmm0
000074da185d3cc8  vmovaps [rsp+0x10], xmm1
000074da185d3cce  vmovaps [rsp+0x20], xmm2
000074da185d3cd4  vmovaps [rsp+0x30], xmm3
000074da185d3cda  vmovaps [rsp+0x40], xmm4
000074da185d3ce0  vmovaps [rsp+0x50], xmm5
000074da185d3ce6  vmovaps [rsp+0x60], xmm6
000074da185d3cec  vmovaps [rsp+0x70], xmm7
000074da185d3cf2  vmovaps [rsp+0x80], xmm8
000074da185d3cfb  vmovaps [rsp+0x90], xmm9
000074da185d3d04  vmovaps [rsp+0xA0], xmm10
000074da185d3d0d  vmovaps [rsp+0xB0], xmm11
000074da185d3d16  vmovaps [rsp+0xC0], xmm12
000074da185d3d1f  vmovaps [rsp+0xD0], xmm14
000074da185d3d28  vmovaps [rsp+0xE0], xmm15
000074da185d3d31  sub rsp, 0x40
000074da185d3d35  lea rdi, [rsp]
000074da185d3d39  lea rsi, [rsp+0x10]
000074da185d3d3e  lea rdx, [rsp+0x20]
000074da185d3d43  lea rcx, [rsp+0x30]
000074da185d3d48  mov r8d, 0x00
000074da185d3d4e  lea r9, [r15+0x3A8]
000074da185d3d55  movaps [rdi], xmm13
000074da185d3d59  movaps [rsi], xmm15
000074da185d3d5d  movaps [rdx], xmm14
000074da185d3d61  movaps [rcx], xmm1
000074da185d3d64  mov rax, 0x5946061DFA50
000074da185d3d6e  call rax
000074da185d3d70  movaps xmm13, [rsp]
000074da185d3d75  add rsp, 0x40
000074da185d3d79  vmovaps xmm0, [rsp]
000074da185d3d7e  vmovaps xmm1, [rsp+0x10]
000074da185d3d84  vmovaps xmm2, [rsp+0x20]
000074da185d3d8a  vmovaps xmm3, [rsp+0x30]
000074da185d3d90  vmovaps xmm4, [rsp+0x40]
000074da185d3d96  vmovaps xmm5, [rsp+0x50]
000074da185d3d9c  vmovaps xmm6, [rsp+0x60]
000074da185d3da2  vmovaps xmm7, [rsp+0x70]
000074da185d3da8  vmovaps xmm8, [rsp+0x80]
000074da185d3db1  vmovaps xmm9, [rsp+0x90]
000074da185d3dba  vmovaps xmm10, [rsp+0xA0]
000074da185d3dc3  vmovaps xmm11, [rsp+0xB0]
000074da185d3dcc  vmovaps xmm12, [rsp+0xC0]
000074da185d3dd5  vmovaps xmm14, [rsp+0xD0]
000074da185d3dde  vmovaps xmm15, [rsp+0xE0]
000074da185d3de7  add rsp, 0xF0
000074da185d3dee  pop r11
000074da185d3df0  pop r10
000074da185d3df2  pop r9
000074da185d3df4  pop r8
000074da185d3df6  pop rsi
000074da185d3df7  pop rdi
000074da185d3df8  pop rdx
000074da185d3df9  pop rcx
000074da185d3dfa  pop rax
000074da185d3dfb  add rsp, 0x08
000074da185d3dff  jmp 0x000074DA185D2BEA
000074da185d3e04  sub rsp, 0x08
000074da185d3e08  push rax
000074da185d3e09  push rcx
000074da185d3e0a  push rdx
000074da185d3e0b  push rdi
000074da185d3e0c  push rsi
000074da185d3e0d  push r8
000074da185d3e0f  push r9
000074da185d3e11  push r10
000074da185d3e13  push r11
000074da185d3e15  sub rsp, 0xF0
000074da185d3e1c  vmovaps [rsp], xmm0
000074da185d3e21  vmovaps [rsp+0x10], xmm1
000074da185d3e27  vmovaps [rsp+0x20], xmm2
000074da185d3e2d  vmovaps [rsp+0x30], xmm3
000074da185d3e33  vmovaps [rsp+0x40], xmm4
000074da185d3e39  vmovaps [rsp+0x50], xmm5
000074da185d3e3f  vmovaps [rsp+0x60], xmm6
000074da185d3e45  vmovaps [rsp+0x70], xmm7
000074da185d3e4b  vmovaps [rsp+0x80], xmm8
000074da185d3e54  vmovaps [rsp+0x90], xmm9
000074da185d3e5d  vmovaps [rsp+0xA0], xmm10
000074da185d3e66  vmovaps [rsp+0xB0], xmm11
000074da185d3e6f  vmovaps [rsp+0xC0], xmm13
000074da185d3e78  vmovaps [rsp+0xD0], xmm14
000074da185d3e81  vmovaps [rsp+0xE0], xmm15
000074da185d3e8a  sub rsp, 0x40
000074da185d3e8e  lea rdi, [rsp]
000074da185d3e92  lea rsi, [rsp+0x10]
000074da185d3e97  lea rdx, [rsp+0x20]
000074da185d3e9c  lea rcx, [rsp+0x30]
000074da185d3ea1  mov r8d, 0x00
000074da185d3ea7  lea r9, [r15+0x3A8]
000074da185d3eae  movaps [rdi], xmm12
000074da185d3eb2  movaps [rsi], xmm15
000074da185d3eb6  movaps [rdx], xmm14
000074da185d3eba  movaps [rcx], xmm1
000074da185d3ebd  mov rax, 0x5946061DFA50
000074da185d3ec7  call rax
000074da185d3ec9  movaps xmm12, [rsp]
000074da185d3ece  add rsp, 0x40
000074da185d3ed2  vmovaps xmm0, [rsp]
000074da185d3ed7  vmovaps xmm1, [rsp+0x10]
000074da185d3edd  vmovaps xmm2, [rsp+0x20]
000074da185d3ee3  vmovaps xmm3, [rsp+0x30]
000074da185d3ee9  vmovaps xmm4, [rsp+0x40]
000074da185d3eef  vmovaps xmm5, [rsp+0x50]
000074da185d3ef5  vmovaps xmm6, [rsp+0x60]
000074da185d3efb  vmovaps xmm7, [rsp+0x70]
000074da185d3f01  vmovaps xmm8, [rsp+0x80]
000074da185d3f0a  vmovaps xmm9, [rsp+0x90]
000074da185d3f13  vmovaps xmm10, [rsp+0xA0]
000074da185d3f1c  vmovaps xmm11, [rsp+0xB0]
000074da185d3f25  vmovaps xmm13, [rsp+0xC0]
000074da185d3f2e  vmovaps xmm14, [rsp+0xD0]
000074da185d3f37  vmovaps xmm15, [rsp+0xE0]
000074da185d3f40  add rsp, 0xF0
000074da185d3f47  pop r11
000074da185d3f49  pop r10
000074da185d3f4b  pop r9
000074da185d3f4d  pop r8
000074da185d3f4f  pop rsi
000074da185d3f50  pop rdi
000074da185d3f51  pop rdx
000074da185d3f52  pop rcx
000074da185d3f53  pop rax
000074da185d3f54  add rsp, 0x08
000074da185d3f58  jmp 0x000074DA185D2C3D
000074da185d3f5d  sub rsp, 0x08
000074da185d3f61  push rax
000074da185d3f62  push rcx
000074da185d3f63  push rdx
000074da185d3f64  push rdi
000074da185d3f65  push rsi
000074da185d3f66  push r8
000074da185d3f68  push r9
000074da185d3f6a  push r10
000074da185d3f6c  push r11
000074da185d3f6e  sub rsp, 0xF0
000074da185d3f75  vmovaps [rsp], xmm0
000074da185d3f7a  vmovaps [rsp+0x10], xmm1
000074da185d3f80  vmovaps [rsp+0x20], xmm2
000074da185d3f86  vmovaps [rsp+0x30], xmm3
000074da185d3f8c  vmovaps [rsp+0x40], xmm4
000074da185d3f92  vmovaps [rsp+0x50], xmm5
000074da185d3f98  vmovaps [rsp+0x60], xmm6
000074da185d3f9e  vmovaps [rsp+0x70], xmm7
000074da185d3fa4  vmovaps [rsp+0x80], xmm8
000074da185d3fad  vmovaps [rsp+0x90], xmm9
000074da185d3fb6  vmovaps [rsp+0xA0], xmm10
000074da185d3fbf  vmovaps [rsp+0xB0], xmm11
000074da185d3fc8  vmovaps [rsp+0xC0], xmm12
000074da185d3fd1  vmovaps [rsp+0xD0], xmm13
000074da185d3fda  vmovaps [rsp+0xE0], xmm15
000074da185d3fe3  sub rsp, 0x40
000074da185d3fe7  lea rdi, [rsp]
000074da185d3feb  lea rsi, [rsp+0x10]
000074da185d3ff0  lea rdx, [rsp+0x20]
000074da185d3ff5  lea rcx, [rsp+0x30]
000074da185d3ffa  mov r8d, 0x00
000074da185d4000  lea r9, [r15+0x3A8]
000074da185d4007  movaps [rdi], xmm14
000074da185d400b  movaps [rsi], xmm3
000074da185d400e  movaps [rdx], xmm1
000074da185d4011  movaps [rcx], xmm15
000074da185d4015  mov rax, 0x5946061DFA50
000074da185d401f  call rax
000074da185d4021  movaps xmm14, [rsp]
000074da185d4026  add rsp, 0x40
000074da185d402a  vmovaps xmm0, [rsp]
000074da185d402f  vmovaps xmm1, [rsp+0x10]
000074da185d4035  vmovaps xmm2, [rsp+0x20]
000074da185d403b  vmovaps xmm3, [rsp+0x30]
000074da185d4041  vmovaps xmm4, [rsp+0x40]
000074da185d4047  vmovaps xmm5, [rsp+0x50]
000074da185d404d  vmovaps xmm6, [rsp+0x60]
000074da185d4053  vmovaps xmm7, [rsp+0x70]
000074da185d4059  vmovaps xmm8, [rsp+0x80]
000074da185d4062  vmovaps xmm9, [rsp+0x90]
000074da185d406b  vmovaps xmm10, [rsp+0xA0]
000074da185d4074  vmovaps xmm11, [rsp+0xB0]
000074da185d407d  vmovaps xmm12, [rsp+0xC0]
000074da185d4086  vmovaps xmm13, [rsp+0xD0]
000074da185d408f  vmovaps xmm15, [rsp+0xE0]
000074da185d4098  add rsp, 0xF0
000074da185d409f  pop r11
000074da185d40a1  pop r10
000074da185d40a3  pop r9
000074da185d40a5  pop r8
000074da185d40a7  pop rsi
000074da185d40a8  pop rdi
000074da185d40a9  pop rdx
000074da185d40aa  pop rcx
000074da185d40ab  pop rax
000074da185d40ac  add rsp, 0x08
000074da185d40b0  jmp 0x000074DA185D2CF7
000074da185d40b5  sub rsp, 0x08
000074da185d40b9  push rax
000074da185d40ba  push rcx
000074da185d40bb  push rdx
000074da185d40bc  push rdi
000074da185d40bd  push rsi
000074da185d40be  push r8
000074da185d40c0  push r9
000074da185d40c2  push r10
000074da185d40c4  push r11
000074da185d40c6  sub rsp, 0xF0
000074da185d40cd  vmovaps [rsp], xmm0
000074da185d40d2  vmovaps [rsp+0x10], xmm1
000074da185d40d8  vmovaps [rsp+0x20], xmm2
000074da185d40de  vmovaps [rsp+0x30], xmm3
000074da185d40e4  vmovaps [rsp+0x40], xmm4
000074da185d40ea  vmovaps [rsp+0x50], xmm5
000074da185d40f0  vmovaps [rsp+0x60], xmm6
000074da185d40f6  vmovaps [rsp+0x70], xmm7
000074da185d40fc  vmovaps [rsp+0x80], xmm8
000074da185d4105  vmovaps [rsp+0x90], xmm9
000074da185d410e  vmovaps [rsp+0xA0], xmm10
000074da185d4117  vmovaps [rsp+0xB0], xmm11
000074da185d4120  vmovaps [rsp+0xC0], xmm12
000074da185d4129  vmovaps [rsp+0xD0], xmm14
000074da185d4132  vmovaps [rsp+0xE0], xmm15
000074da185d413b  sub rsp, 0x40
000074da185d413f  lea rdi, [rsp]
000074da185d4143  lea rsi, [rsp+0x10]
000074da185d4148  lea rdx, [rsp+0x20]
000074da185d414d  lea rcx, [rsp+0x30]
000074da185d4152  mov r8d, 0x00
000074da185d4158  lea r9, [r15+0x3A8]
000074da185d415f  movaps [rdi], xmm13
000074da185d4163  movaps [rsi], xmm15
000074da185d4167  movaps [rdx], xmm10
000074da185d416b  movaps [rcx], xmm1
000074da185d416e  mov rax, 0x5946061DFA50
000074da185d4178  call rax
000074da185d417a  movaps xmm13, [rsp]
000074da185d417f  add rsp, 0x40
000074da185d4183  vmovaps xmm0, [rsp]
000074da185d4188  vmovaps xmm1, [rsp+0x10]
000074da185d418e  vmovaps xmm2, [rsp+0x20]
000074da185d4194  vmovaps xmm3, [rsp+0x30]
000074da185d419a  vmovaps xmm4, [rsp+0x40]
000074da185d41a0  vmovaps xmm5, [rsp+0x50]
000074da185d41a6  vmovaps xmm6, [rsp+0x60]
000074da185d41ac  vmovaps xmm7, [rsp+0x70]
000074da185d41b2  vmovaps xmm8, [rsp+0x80]
000074da185d41bb  vmovaps xmm9, [rsp+0x90]
000074da185d41c4  vmovaps xmm10, [rsp+0xA0]
000074da185d41cd  vmovaps xmm11, [rsp+0xB0]
000074da185d41d6  vmovaps xmm12, [rsp+0xC0]
000074da185d41df  vmovaps xmm14, [rsp+0xD0]
000074da185d41e8  vmovaps xmm15, [rsp+0xE0]
000074da185d41f1  add rsp, 0xF0
000074da185d41f8  pop r11
000074da185d41fa  pop r10
000074da185d41fc  pop r9
000074da185d41fe  pop r8
000074da185d4200  pop rsi
000074da185d4201  pop rdi
000074da185d4202  pop rdx
000074da185d4203  pop rcx
000074da185d4204  pop rax
000074da185d4205  add rsp, 0x08
000074da185d4209  jmp 0x000074DA185D2D26
000074da185d420e  sub rsp, 0x08
000074da185d4212  push rax
000074da185d4213  push rcx
000074da185d4214  push rdx
000074da185d4215  push rdi
000074da185d4216  push rsi
000074da185d4217  push r8
000074da185d4219  push r9
000074da185d421b  push r10
000074da185d421d  push r11
000074da185d421f  sub rsp, 0xF0
000074da185d4226  vmovaps [rsp], xmm0
000074da185d422b  vmovaps [rsp+0x10], xmm1
000074da185d4231  vmovaps [rsp+0x20], xmm2
000074da185d4237  vmovaps [rsp+0x30], xmm3
000074da185d423d  vmovaps [rsp+0x40], xmm4
000074da185d4243  vmovaps [rsp+0x50], xmm5
000074da185d4249  vmovaps [rsp+0x60], xmm6
000074da185d424f  vmovaps [rsp+0x70], xmm7
000074da185d4255  vmovaps [rsp+0x80], xmm8
000074da185d425e  vmovaps [rsp+0x90], xmm9
000074da185d4267  vmovaps [rsp+0xA0], xmm11
000074da185d4270  vmovaps [rsp+0xB0], xmm12
000074da185d4279  vmovaps [rsp+0xC0], xmm13
000074da185d4282  vmovaps [rsp+0xD0], xmm14
000074da185d428b  vmovaps [rsp+0xE0], xmm15
000074da185d4294  sub rsp, 0x40
000074da185d4298  lea rdi, [rsp]
000074da185d429c  lea rsi, [rsp+0x10]
000074da185d42a1  lea rdx, [rsp+0x20]
000074da185d42a6  lea rcx, [rsp+0x30]
000074da185d42ab  mov r8d, 0x00
000074da185d42b1  lea r9, [r15+0x3A8]
000074da185d42b8  movaps [rdi], xmm10
000074da185d42bc  movaps [rsi], xmm15
000074da185d42c0  movaps [rdx], xmm11
000074da185d42c4  movaps [rcx], xmm1
000074da185d42c7  mov rax, 0x5946061DFA50
000074da185d42d1  call rax
000074da185d42d3  movaps xmm10, [rsp]
000074da185d42d8  add rsp, 0x40
000074da185d42dc  vmovaps xmm0, [rsp]
000074da185d42e1  vmovaps xmm1, [rsp+0x10]
000074da185d42e7  vmovaps xmm2, [rsp+0x20]
000074da185d42ed  vmovaps xmm3, [rsp+0x30]
000074da185d42f3  vmovaps xmm4, [rsp+0x40]
000074da185d42f9  vmovaps xmm5, [rsp+0x50]
000074da185d42ff  vmovaps xmm6, [rsp+0x60]
000074da185d4305  vmovaps xmm7, [rsp+0x70]
000074da185d430b  vmovaps xmm8, [rsp+0x80]
000074da185d4314  vmovaps xmm9, [rsp+0x90]
000074da185d431d  vmovaps xmm11, [rsp+0xA0]
000074da185d4326  vmovaps xmm12, [rsp+0xB0]
000074da185d432f  vmovaps xmm13, [rsp+0xC0]
000074da185d4338  vmovaps xmm14, [rsp+0xD0]
000074da185d4341  vmovaps xmm15, [rsp+0xE0]
000074da185d434a  add rsp, 0xF0
000074da185d4351  pop r11
000074da185d4353  pop r10
000074da185d4355  pop r9
000074da185d4357  pop r8
000074da185d4359  pop rsi
000074da185d435a  pop rdi
000074da185d435b  pop rdx
000074da185d435c  pop rcx
000074da185d435d  pop rax
000074da185d435e  add rsp, 0x08
000074da185d4362  jmp 0x000074DA185D2D55
000074da185d4367  sub rsp, 0x08
000074da185d436b  push rax
000074da185d436c  push rcx
000074da185d436d  push rdx
000074da185d436e  push rdi
000074da185d436f  push rsi
000074da185d4370  push r8
000074da185d4372  push r9
000074da185d4374  push r10
000074da185d4376  push r11
000074da185d4378  sub rsp, 0xF0
000074da185d437f  vmovaps [rsp], xmm0
000074da185d4384  vmovaps [rsp+0x10], xmm1
000074da185d438a  vmovaps [rsp+0x20], xmm2
000074da185d4390  vmovaps [rsp+0x30], xmm3
000074da185d4396  vmovaps [rsp+0x40], xmm4
000074da185d439c  vmovaps [rsp+0x50], xmm5
000074da185d43a2  vmovaps [rsp+0x60], xmm6
000074da185d43a8  vmovaps [rsp+0x70], xmm7
000074da185d43ae  vmovaps [rsp+0x80], xmm8
000074da185d43b7  vmovaps [rsp+0x90], xmm9
000074da185d43c0  vmovaps [rsp+0xA0], xmm10
000074da185d43c9  vmovaps [rsp+0xB0], xmm11
000074da185d43d2  vmovaps [rsp+0xC0], xmm12
000074da185d43db  vmovaps [rsp+0xD0], xmm13
000074da185d43e4  vmovaps [rsp+0xE0], xmm14
000074da185d43ed  sub rsp, 0x40
000074da185d43f1  lea rdi, [rsp]
000074da185d43f5  lea rsi, [rsp+0x10]
000074da185d43fa  lea rdx, [rsp+0x20]
000074da185d43ff  lea rcx, [rsp+0x30]
000074da185d4404  mov r8d, 0x00
000074da185d440a  lea r9, [r15+0x3A8]
000074da185d4411  movaps [rdi], xmm15
000074da185d4415  movaps [rsi], xmm12
000074da185d4419  movaps [rdx], xmm5
000074da185d441c  movaps [rcx], xmm1
000074da185d441f  mov rax, 0x5946061DFA50
000074da185d4429  call rax
000074da185d442b  movaps xmm15, [rsp]
000074da185d4430  add rsp, 0x40
000074da185d4434  vmovaps xmm0, [rsp]
000074da185d4439  vmovaps xmm1, [rsp+0x10]
000074da185d443f  vmovaps xmm2, [rsp+0x20]
000074da185d4445  vmovaps xmm3, [rsp+0x30]
000074da185d444b  vmovaps xmm4, [rsp+0x40]
000074da185d4451  vmovaps xmm5, [rsp+0x50]
000074da185d4457  vmovaps xmm6, [rsp+0x60]
000074da185d445d  vmovaps xmm7, [rsp+0x70]
000074da185d4463  vmovaps xmm8, [rsp+0x80]
000074da185d446c  vmovaps xmm9, [rsp+0x90]
000074da185d4475  vmovaps xmm10, [rsp+0xA0]
000074da185d447e  vmovaps xmm11, [rsp+0xB0]
000074da185d4487  vmovaps xmm12, [rsp+0xC0]
000074da185d4490  vmovaps xmm13, [rsp+0xD0]
000074da185d4499  vmovaps xmm14, [rsp+0xE0]
000074da185d44a2  add rsp, 0xF0
000074da185d44a9  pop r11
000074da185d44ab  pop r10
000074da185d44ad  pop r9
000074da185d44af  pop r8
000074da185d44b1  pop rsi
000074da185d44b2  pop rdi
000074da185d44b3  pop rdx
000074da185d44b4  pop rcx
000074da185d44b5  pop rax
000074da185d44b6  add rsp, 0x08
000074da185d44ba  jmp 0x000074DA185D2D7E
000074da185d44bf  sub rsp, 0x08
000074da185d44c3  push rax
000074da185d44c4  push rcx
000074da185d44c5  push rdx
000074da185d44c6  push rdi
000074da185d44c7  push rsi
000074da185d44c8  push r8
000074da185d44ca  push r9
000074da185d44cc  push r10
000074da185d44ce  push r11
000074da185d44d0  sub rsp, 0xF0
000074da185d44d7  vmovaps [rsp], xmm0
000074da185d44dc  vmovaps [rsp+0x10], xmm1
000074da185d44e2  vmovaps [rsp+0x20], xmm2
000074da185d44e8  vmovaps [rsp+0x30], xmm3
000074da185d44ee  vmovaps [rsp+0x40], xmm4
000074da185d44f4  vmovaps [rsp+0x50], xmm6
000074da185d44fa  vmovaps [rsp+0x60], xmm7
000074da185d4500  vmovaps [rsp+0x70], xmm8
000074da185d4506  vmovaps [rsp+0x80], xmm9
000074da185d450f  vmovaps [rsp+0x90], xmm10
000074da185d4518  vmovaps [rsp+0xA0], xmm11
000074da185d4521  vmovaps [rsp+0xB0], xmm12
000074da185d452a  vmovaps [rsp+0xC0], xmm13
000074da185d4533  vmovaps [rsp+0xD0], xmm14
000074da185d453c  vmovaps [rsp+0xE0], xmm15
000074da185d4545  sub rsp, 0x40
000074da185d4549  lea rdi, [rsp]
000074da185d454d  lea rsi, [rsp+0x10]
000074da185d4552  lea rdx, [rsp+0x20]
000074da185d4557  lea rcx, [rsp+0x30]
000074da185d455c  mov r8d, 0x00
000074da185d4562  lea r9, [r15+0x3A8]
000074da185d4569  movaps [rdi], xmm5
000074da185d456c  movaps [rsi], xmm13
000074da185d4570  movaps [rdx], xmm11
000074da185d4574  movaps [rcx], xmm12
000074da185d4578  mov rax, 0x5946061DFA50
000074da185d4582  call rax
000074da185d4584  movaps xmm5, [rsp]
000074da185d4588  add rsp, 0x40
000074da185d458c  vmovaps xmm0, [rsp]
000074da185d4591  vmovaps xmm1, [rsp+0x10]
000074da185d4597  vmovaps xmm2, [rsp+0x20]
000074da185d459d  vmovaps xmm3, [rsp+0x30]
000074da185d45a3  vmovaps xmm4, [rsp+0x40]
000074da185d45a9  vmovaps xmm6, [rsp+0x50]
000074da185d45af  vmovaps xmm7, [rsp+0x60]
000074da185d45b5  vmovaps xmm8, [rsp+0x70]
000074da185d45bb  vmovaps xmm9, [rsp+0x80]
000074da185d45c4  vmovaps xmm10, [rsp+0x90]
000074da185d45cd  vmovaps xmm11, [rsp+0xA0]
000074da185d45d6  vmovaps xmm12, [rsp+0xB0]
000074da185d45df  vmovaps xmm13, [rsp+0xC0]
000074da185d45e8  vmovaps xmm14, [rsp+0xD0]
000074da185d45f1  vmovaps xmm15, [rsp+0xE0]
000074da185d45fa  add rsp, 0xF0
000074da185d4601  pop r11
000074da185d4603  pop r10
000074da185d4605  pop r9
000074da185d4607  pop r8
000074da185d4609  pop rsi
000074da185d460a  pop rdi
000074da185d460b  pop rdx
000074da185d460c  pop rcx
000074da185d460d  pop rax
000074da185d460e  add rsp, 0x08
000074da185d4612  jmp 0x000074DA185D2DDD
000074da185d4617  sub rsp, 0x08
000074da185d461b  push rax
000074da185d461c  push rcx
000074da185d461d  push rdx
000074da185d461e  push rdi
000074da185d461f  push rsi
000074da185d4620  push r8
000074da185d4622  push r9
000074da185d4624  push r10
000074da185d4626  push r11
000074da185d4628  sub rsp, 0xF0
000074da185d462f  vmovaps [rsp], xmm0
000074da185d4634  vmovaps [rsp+0x10], xmm1
000074da185d463a  vmovaps [rsp+0x20], xmm2
000074da185d4640  vmovaps [rsp+0x30], xmm3
000074da185d4646  vmovaps [rsp+0x40], xmm4
000074da185d464c  vmovaps [rsp+0x50], xmm5
000074da185d4652  vmovaps [rsp+0x60], xmm6
000074da185d4658  vmovaps [rsp+0x70], xmm7
000074da185d465e  vmovaps [rsp+0x80], xmm8
000074da185d4667  vmovaps [rsp+0x90], xmm9
000074da185d4670  vmovaps [rsp+0xA0], xmm10
000074da185d4679  vmovaps [rsp+0xB0], xmm11
000074da185d4682  vmovaps [rsp+0xC0], xmm13
000074da185d468b  vmovaps [rsp+0xD0], xmm14
000074da185d4694  vmovaps [rsp+0xE0], xmm15
000074da185d469d  sub rsp, 0x40
000074da185d46a1  lea rdi, [rsp]
000074da185d46a5  lea rsi, [rsp+0x10]
000074da185d46aa  lea rdx, [rsp+0x20]
000074da185d46af  lea rcx, [rsp+0x30]
000074da185d46b4  mov r8d, 0x00
000074da185d46ba  lea r9, [r15+0x3A8]
000074da185d46c1  movaps [rdi], xmm12
000074da185d46c5  movaps [rsi], xmm14
000074da185d46c9  movaps [rdx], xmm9
000074da185d46cd  movaps [rcx], xmm13
000074da185d46d1  mov rax, 0x5946061DFA50
000074da185d46db  call rax
000074da185d46dd  movaps xmm12, [rsp]
000074da185d46e2  add rsp, 0x40
000074da185d46e6  vmovaps xmm0, [rsp]
000074da185d46eb  vmovaps xmm1, [rsp+0x10]
000074da185d46f1  vmovaps xmm2, [rsp+0x20]
000074da185d46f7  vmovaps xmm3, [rsp+0x30]
000074da185d46fd  vmovaps xmm4, [rsp+0x40]
000074da185d4703  vmovaps xmm5, [rsp+0x50]
000074da185d4709  vmovaps xmm6, [rsp+0x60]
000074da185d470f  vmovaps xmm7, [rsp+0x70]
000074da185d4715  vmovaps xmm8, [rsp+0x80]
000074da185d471e  vmovaps xmm9, [rsp+0x90]
000074da185d4727  vmovaps xmm10, [rsp+0xA0]
000074da185d4730  vmovaps xmm11, [rsp+0xB0]
000074da185d4739  vmovaps xmm13, [rsp+0xC0]
000074da185d4742  vmovaps xmm14, [rsp+0xD0]
000074da185d474b  vmovaps xmm15, [rsp+0xE0]
000074da185d4754  add rsp, 0xF0
000074da185d475b  pop r11
000074da185d475d  pop r10
000074da185d475f  pop r9
000074da185d4761  pop r8
000074da185d4763  pop rsi
000074da185d4764  pop rdi
000074da185d4765  pop rdx
000074da185d4766  pop rcx
000074da185d4767  pop rax
000074da185d4768  add rsp, 0x08
000074da185d476c  jmp 0x000074DA185D2E06
000074da185d4771  call 0x000074DA1840D4E0
000074da185d4776  jmp 0x000074DA185D2E13
000074da185d477b  sub rsp, 0x08
000074da185d477f  push rax
000074da185d4780  push rcx
000074da185d4781  push rdx
000074da185d4782  push rdi
000074da185d4783  push rsi
000074da185d4784  push r8
000074da185d4786  push r9
000074da185d4788  push r10
000074da185d478a  push r11
000074da185d478c  sub rsp, 0xF0
000074da185d4793  vmovaps [rsp], xmm0
000074da185d4798  vmovaps [rsp+0x10], xmm1
000074da185d479e  vmovaps [rsp+0x20], xmm2
000074da185d47a4  vmovaps [rsp+0x30], xmm3
000074da185d47aa  vmovaps [rsp+0x40], xmm4
000074da185d47b0  vmovaps [rsp+0x50], xmm5
000074da185d47b6  vmovaps [rsp+0x60], xmm6
000074da185d47bc  vmovaps [rsp+0x70], xmm7
000074da185d47c2  vmovaps [rsp+0x80], xmm8
000074da185d47cb  vmovaps [rsp+0x90], xmm9
000074da185d47d4  vmovaps [rsp+0xA0], xmm10
000074da185d47dd  vmovaps [rsp+0xB0], xmm12
000074da185d47e6  vmovaps [rsp+0xC0], xmm13
000074da185d47ef  vmovaps [rsp+0xD0], xmm14
000074da185d47f8  vmovaps [rsp+0xE0], xmm15
000074da185d4801  sub rsp, 0x40
000074da185d4805  lea rdi, [rsp]
000074da185d4809  lea rsi, [rsp+0x10]
000074da185d480e  lea rdx, [rsp+0x20]
000074da185d4813  lea rcx, [rsp+0x30]
000074da185d4818  mov r8d, 0x00
000074da185d481e  lea r9, [r15+0x3A8]
000074da185d4825  movaps [rdi], xmm11
000074da185d4829  movaps [rsi], xmm10
000074da185d482d  movaps [rdx], xmm8
000074da185d4831  movaps [rcx], xmm13
000074da185d4835  mov rax, 0x5946061DFA50
000074da185d483f  call rax
000074da185d4841  movaps xmm11, [rsp]
000074da185d4846  add rsp, 0x40
000074da185d484a  vmovaps xmm0, [rsp]
000074da185d484f  vmovaps xmm1, [rsp+0x10]
000074da185d4855  vmovaps xmm2, [rsp+0x20]
000074da185d485b  vmovaps xmm3, [rsp+0x30]
000074da185d4861  vmovaps xmm4, [rsp+0x40]
000074da185d4867  vmovaps xmm5, [rsp+0x50]
000074da185d486d  vmovaps xmm6, [rsp+0x60]
000074da185d4873  vmovaps xmm7, [rsp+0x70]
000074da185d4879  vmovaps xmm8, [rsp+0x80]
000074da185d4882  vmovaps xmm9, [rsp+0x90]
000074da185d488b  vmovaps xmm10, [rsp+0xA0]
000074da185d4894  vmovaps xmm12, [rsp+0xB0]
000074da185d489d  vmovaps xmm13, [rsp+0xC0]
000074da185d48a6  vmovaps xmm14, [rsp+0xD0]
000074da185d48af  vmovaps xmm15, [rsp+0xE0]
000074da185d48b8  add rsp, 0xF0
000074da185d48bf  pop r11
000074da185d48c1  pop r10
000074da185d48c3  pop r9
000074da185d48c5  pop r8
000074da185d48c7  pop rsi
000074da185d48c8  pop rdi
000074da185d48c9  pop rdx
000074da185d48ca  pop rcx
000074da185d48cb  pop rax
000074da185d48cc  add rsp, 0x08
000074da185d48d0  jmp 0x000074DA185D2E44
000074da185d48d5  sub rsp, 0x08
000074da185d48d9  push rax
000074da185d48da  push rcx
000074da185d48db  push rdx
000074da185d48dc  push rdi
000074da185d48dd  push rsi
000074da185d48de  push r8
000074da185d48e0  push r9
000074da185d48e2  push r10
000074da185d48e4  push r11
000074da185d48e6  sub rsp, 0xF0
000074da185d48ed  vmovaps [rsp], xmm0
000074da185d48f2  vmovaps [rsp+0x10], xmm1
000074da185d48f8  vmovaps [rsp+0x20], xmm2
000074da185d48fe  vmovaps [rsp+0x30], xmm3
000074da185d4904  vmovaps [rsp+0x40], xmm4
000074da185d490a  vmovaps [rsp+0x50], xmm5
000074da185d4910  vmovaps [rsp+0x60], xmm6
000074da185d4916  vmovaps [rsp+0x70], xmm7
000074da185d491c  vmovaps [rsp+0x80], xmm8
000074da185d4925  vmovaps [rsp+0x90], xmm9
000074da185d492e  vmovaps [rsp+0xA0], xmm11
000074da185d4937  vmovaps [rsp+0xB0], xmm12
000074da185d4940  vmovaps [rsp+0xC0], xmm13
000074da185d4949  vmovaps [rsp+0xD0], xmm14
000074da185d4952  vmovaps [rsp+0xE0], xmm15
000074da185d495b  sub rsp, 0x40
000074da185d495f  lea rdi, [rsp]
000074da185d4963  lea rsi, [rsp+0x10]
000074da185d4968  lea rdx, [rsp+0x20]
000074da185d496d  lea rcx, [rsp+0x30]
000074da185d4972  mov r8d, 0x00
000074da185d4978  lea r9, [r15+0x3A8]
000074da185d497f  movaps [rdi], xmm10
000074da185d4983  movaps [rsi], xmm15
000074da185d4987  movaps [rdx], xmm1
000074da185d498a  movaps [rcx], xmm13
000074da185d498e  mov rax, 0x5946061DFA50
000074da185d4998  call rax
000074da185d499a  movaps xmm10, [rsp]
000074da185d499f  add rsp, 0x40
000074da185d49a3  vmovaps xmm0, [rsp]
000074da185d49a8  vmovaps xmm1, [rsp+0x10]
000074da185d49ae  vmovaps xmm2, [rsp+0x20]
000074da185d49b4  vmovaps xmm3, [rsp+0x30]
000074da185d49ba  vmovaps xmm4, [rsp+0x40]
000074da185d49c0  vmovaps xmm5, [rsp+0x50]
000074da185d49c6  vmovaps xmm6, [rsp+0x60]
000074da185d49cc  vmovaps xmm7, [rsp+0x70]
000074da185d49d2  vmovaps xmm8, [rsp+0x80]
000074da185d49db  vmovaps xmm9, [rsp+0x90]
000074da185d49e4  vmovaps xmm11, [rsp+0xA0]
000074da185d49ed  vmovaps xmm12, [rsp+0xB0]
000074da185d49f6  vmovaps xmm13, [rsp+0xC0]
000074da185d49ff  vmovaps xmm14, [rsp+0xD0]
000074da185d4a08  vmovaps xmm15, [rsp+0xE0]
000074da185d4a11  add rsp, 0xF0
000074da185d4a18  pop r11
000074da185d4a1a  pop r10
000074da185d4a1c  pop r9
000074da185d4a1e  pop r8
000074da185d4a20  pop rsi
000074da185d4a21  pop rdi
000074da185d4a22  pop rdx
000074da185d4a23  pop rcx
000074da185d4a24  pop rax
000074da185d4a25  add rsp, 0x08
000074da185d4a29  jmp 0x000074DA185D2E6D
000074da185d4a2e  call 0x000074DA183FF430
000074da185d4a33  jmp 0x000074DA185D2E8F
000074da185d4a38  call 0x000074DA1840E760
000074da185d4a3d  jmp 0x000074DA185D2E99
000074da185d4a42  sub rsp, 0x08
000074da185d4a46  push rax
000074da185d4a47  push rcx
000074da185d4a48  push rdx
000074da185d4a49  push rdi
000074da185d4a4a  push rsi
000074da185d4a4b  push r8
000074da185d4a4d  push r9
000074da185d4a4f  push r10
000074da185d4a51  push r11
000074da185d4a53  sub rsp, 0xF0
000074da185d4a5a  vmovaps [rsp], xmm0
000074da185d4a5f  vmovaps [rsp+0x10], xmm1
000074da185d4a65  vmovaps [rsp+0x20], xmm2
000074da185d4a6b  vmovaps [rsp+0x30], xmm3
000074da185d4a71  vmovaps [rsp+0x40], xmm4
000074da185d4a77  vmovaps [rsp+0x50], xmm5
000074da185d4a7d  vmovaps [rsp+0x60], xmm6
000074da185d4a83  vmovaps [rsp+0x70], xmm7
000074da185d4a89  vmovaps [rsp+0x80], xmm9
000074da185d4a92  vmovaps [rsp+0x90], xmm10
000074da185d4a9b  vmovaps [rsp+0xA0], xmm11
000074da185d4aa4  vmovaps [rsp+0xB0], xmm12
000074da185d4aad  vmovaps [rsp+0xC0], xmm13
000074da185d4ab6  vmovaps [rsp+0xD0], xmm14
000074da185d4abf  vmovaps [rsp+0xE0], xmm15
000074da185d4ac8  sub rsp, 0x40
000074da185d4acc  lea rdi, [rsp]
000074da185d4ad0  lea rsi, [rsp+0x10]
000074da185d4ad5  lea rdx, [rsp+0x20]
000074da185d4ada  lea rcx, [rsp+0x30]
000074da185d4adf  mov r8d, 0x00
000074da185d4ae5  lea r9, [r15+0x3A8]
000074da185d4aec  movaps [rdi], xmm8
000074da185d4af0  movaps [rsi], xmm5
000074da185d4af3  movaps [rdx], xmm9
000074da185d4af7  movaps [rcx], xmm13
000074da185d4afb  mov rax, 0x5946061DFA50
000074da185d4b05  call rax
000074da185d4b07  movaps xmm8, [rsp]
000074da185d4b0c  add rsp, 0x40
000074da185d4b10  vmovaps xmm0, [rsp]
000074da185d4b15  vmovaps xmm1, [rsp+0x10]
000074da185d4b1b  vmovaps xmm2, [rsp+0x20]
000074da185d4b21  vmovaps xmm3, [rsp+0x30]
000074da185d4b27  vmovaps xmm4, [rsp+0x40]
000074da185d4b2d  vmovaps xmm5, [rsp+0x50]
000074da185d4b33  vmovaps xmm6, [rsp+0x60]
000074da185d4b39  vmovaps xmm7, [rsp+0x70]
000074da185d4b3f  vmovaps xmm9, [rsp+0x80]
000074da185d4b48  vmovaps xmm10, [rsp+0x90]
000074da185d4b51  vmovaps xmm11, [rsp+0xA0]
000074da185d4b5a  vmovaps xmm12, [rsp+0xB0]
000074da185d4b63  vmovaps xmm13, [rsp+0xC0]
000074da185d4b6c  vmovaps xmm14, [rsp+0xD0]
000074da185d4b75  vmovaps xmm15, [rsp+0xE0]
000074da185d4b7e  add rsp, 0xF0
000074da185d4b85  pop r11
000074da185d4b87  pop r10
000074da185d4b89  pop r9
000074da185d4b8b  pop r8
000074da185d4b8d  pop rsi
000074da185d4b8e  pop rdi
000074da185d4b8f  pop rdx
000074da185d4b90  pop rcx
000074da185d4b91  pop rax
000074da185d4b92  add rsp, 0x08
000074da185d4b96  jmp 0x000074DA185D2ED8
000074da185d4b9b  sub rsp, 0x08
000074da185d4b9f  push rax
000074da185d4ba0  push rcx
000074da185d4ba1  push rdx
000074da185d4ba2  push rdi
000074da185d4ba3  push rsi
000074da185d4ba4  push r8
000074da185d4ba6  push r9
000074da185d4ba8  push r10
000074da185d4baa  push r11
000074da185d4bac  sub rsp, 0xF0
000074da185d4bb3  vmovaps [rsp], xmm0
000074da185d4bb8  vmovaps [rsp+0x10], xmm1
000074da185d4bbe  vmovaps [rsp+0x20], xmm2
000074da185d4bc4  vmovaps [rsp+0x30], xmm3
000074da185d4bca  vmovaps [rsp+0x40], xmm4
000074da185d4bd0  vmovaps [rsp+0x50], xmm5
000074da185d4bd6  vmovaps [rsp+0x60], xmm6
000074da185d4bdc  vmovaps [rsp+0x70], xmm7
000074da185d4be2  vmovaps [rsp+0x80], xmm8
000074da185d4beb  vmovaps [rsp+0x90], xmm10
000074da185d4bf4  vmovaps [rsp+0xA0], xmm11
000074da185d4bfd  vmovaps [rsp+0xB0], xmm12
000074da185d4c06  vmovaps [rsp+0xC0], xmm13
000074da185d4c0f  vmovaps [rsp+0xD0], xmm14
000074da185d4c18  vmovaps [rsp+0xE0], xmm15
000074da185d4c21  sub rsp, 0x40
000074da185d4c25  lea rdi, [rsp]
000074da185d4c29  lea rsi, [rsp+0x10]
000074da185d4c2e  lea rdx, [rsp+0x20]
000074da185d4c33  lea rcx, [rsp+0x30]
000074da185d4c38  mov r8d, 0x00
000074da185d4c3e  lea r9, [r15+0x3A8]
000074da185d4c45  movaps [rdi], xmm9
000074da185d4c49  movaps [rsi], xmm12
000074da185d4c4d  movaps [rdx], xmm7
000074da185d4c50  movaps [rcx], xmm13
000074da185d4c54  mov rax, 0x5946061DFA50
000074da185d4c5e  call rax
000074da185d4c60  movaps xmm9, [rsp]
000074da185d4c65  add rsp, 0x40
000074da185d4c69  vmovaps xmm0, [rsp]
000074da185d4c6e  vmovaps xmm1, [rsp+0x10]
000074da185d4c74  vmovaps xmm2, [rsp+0x20]
000074da185d4c7a  vmovaps xmm3, [rsp+0x30]
000074da185d4c80  vmovaps xmm4, [rsp+0x40]
000074da185d4c86  vmovaps xmm5, [rsp+0x50]
000074da185d4c8c  vmovaps xmm6, [rsp+0x60]
000074da185d4c92  vmovaps xmm7, [rsp+0x70]
000074da185d4c98  vmovaps xmm8, [rsp+0x80]
000074da185d4ca1  vmovaps xmm10, [rsp+0x90]
000074da185d4caa  vmovaps xmm11, [rsp+0xA0]
000074da185d4cb3  vmovaps xmm12, [rsp+0xB0]
000074da185d4cbc  vmovaps xmm13, [rsp+0xC0]
000074da185d4cc5  vmovaps xmm14, [rsp+0xD0]
000074da185d4cce  vmovaps xmm15, [rsp+0xE0]
000074da185d4cd7  add rsp, 0xF0
000074da185d4cde  pop r11
000074da185d4ce0  pop r10
000074da185d4ce2  pop r9
000074da185d4ce4  pop r8
000074da185d4ce6  pop rsi
000074da185d4ce7  pop rdi
000074da185d4ce8  pop rdx
000074da185d4ce9  pop rcx
000074da185d4cea  pop rax
000074da185d4ceb  add rsp, 0x08
000074da185d4cef  jmp 0x000074DA185D2F01
000074da185d4cf4  sub rsp, 0x08
000074da185d4cf8  push rax
000074da185d4cf9  push rcx
000074da185d4cfa  push rdx
000074da185d4cfb  push rdi
000074da185d4cfc  push rsi
000074da185d4cfd  push r8
000074da185d4cff  push r9
000074da185d4d01  push r10
000074da185d4d03  push r11
000074da185d4d05  sub rsp, 0xF0
000074da185d4d0c  vmovaps [rsp], xmm0
000074da185d4d11  vmovaps [rsp+0x10], xmm1
000074da185d4d17  vmovaps [rsp+0x20], xmm2
000074da185d4d1d  vmovaps [rsp+0x30], xmm3
000074da185d4d23  vmovaps [rsp+0x40], xmm4
000074da185d4d29  vmovaps [rsp+0x50], xmm5
000074da185d4d2f  vmovaps [rsp+0x60], xmm6
000074da185d4d35  vmovaps [rsp+0x70], xmm7
000074da185d4d3b  vmovaps [rsp+0x80], xmm8
000074da185d4d44  vmovaps [rsp+0x90], xmm9
000074da185d4d4d  vmovaps [rsp+0xA0], xmm10
000074da185d4d56  vmovaps [rsp+0xB0], xmm11
000074da185d4d5f  vmovaps [rsp+0xC0], xmm13
000074da185d4d68  vmovaps [rsp+0xD0], xmm14
000074da185d4d71  vmovaps [rsp+0xE0], xmm15
000074da185d4d7a  sub rsp, 0x40
000074da185d4d7e  lea rdi, [rsp]
000074da185d4d82  lea rsi, [rsp+0x10]
000074da185d4d87  lea rdx, [rsp+0x20]
000074da185d4d8c  lea rcx, [rsp+0x30]
000074da185d4d91  mov r8d, 0x00
000074da185d4d97  lea r9, [r15+0x3A8]
000074da185d4d9e  movaps [rdi], xmm12
000074da185d4da2  movaps [rsi], xmm11
000074da185d4da6  movaps [rdx], xmm6
000074da185d4da9  movaps [rcx], xmm13
000074da185d4dad  mov rax, 0x5946061DFA50
000074da185d4db7  call rax
000074da185d4db9  movaps xmm12, [rsp]
000074da185d4dbe  add rsp, 0x40
000074da185d4dc2  vmovaps xmm0, [rsp]
000074da185d4dc7  vmovaps xmm1, [rsp+0x10]
000074da185d4dcd  vmovaps xmm2, [rsp+0x20]
000074da185d4dd3  vmovaps xmm3, [rsp+0x30]
000074da185d4dd9  vmovaps xmm4, [rsp+0x40]
000074da185d4ddf  vmovaps xmm5, [rsp+0x50]
000074da185d4de5  vmovaps xmm6, [rsp+0x60]
000074da185d4deb  vmovaps xmm7, [rsp+0x70]
000074da185d4df1  vmovaps xmm8, [rsp+0x80]
000074da185d4dfa  vmovaps xmm9, [rsp+0x90]
000074da185d4e03  vmovaps xmm10, [rsp+0xA0]
000074da185d4e0c  vmovaps xmm11, [rsp+0xB0]
000074da185d4e15  vmovaps xmm13, [rsp+0xC0]
000074da185d4e1e  vmovaps xmm14, [rsp+0xD0]
000074da185d4e27  vmovaps xmm15, [rsp+0xE0]
000074da185d4e30  add rsp, 0xF0
000074da185d4e37  pop r11
000074da185d4e39  pop r10
000074da185d4e3b  pop r9
000074da185d4e3d  pop r8
000074da185d4e3f  pop rsi
000074da185d4e40  pop rdi
000074da185d4e41  pop rdx
000074da185d4e42  pop rcx
000074da185d4e43  pop rax
000074da185d4e44  add rsp, 0x08
000074da185d4e48  jmp 0x000074DA185D2F2A
000074da185d4e4d  sub rsp, 0x08
000074da185d4e51  push rax
000074da185d4e52  push rcx
000074da185d4e53  push rdx
000074da185d4e54  push rdi
000074da185d4e55  push rsi
000074da185d4e56  push r8
000074da185d4e58  push r9
000074da185d4e5a  push r10
000074da185d4e5c  push r11
000074da185d4e5e  sub rsp, 0xF0
000074da185d4e65  vmovaps [rsp], xmm0
000074da185d4e6a  vmovaps [rsp+0x10], xmm1
000074da185d4e70  vmovaps [rsp+0x20], xmm2
000074da185d4e76  vmovaps [rsp+0x30], xmm3
000074da185d4e7c  vmovaps [rsp+0x40], xmm4
000074da185d4e82  vmovaps [rsp+0x50], xmm5
000074da185d4e88  vmovaps [rsp+0x60], xmm6
000074da185d4e8e  vmovaps [rsp+0x70], xmm8
000074da185d4e94  vmovaps [rsp+0x80], xmm9
000074da185d4e9d  vmovaps [rsp+0x90], xmm10
000074da185d4ea6  vmovaps [rsp+0xA0], xmm11
000074da185d4eaf  vmovaps [rsp+0xB0], xmm12
000074da185d4eb8  vmovaps [rsp+0xC0], xmm13
000074da185d4ec1  vmovaps [rsp+0xD0], xmm14
000074da185d4eca  vmovaps [rsp+0xE0], xmm15
000074da185d4ed3  sub rsp, 0x40
000074da185d4ed7  lea rdi, [rsp]
000074da185d4edb  lea rsi, [rsp+0x10]
000074da185d4ee0  lea rdx, [rsp+0x20]
000074da185d4ee5  lea rcx, [rsp+0x30]
000074da185d4eea  mov r8d, 0x00
000074da185d4ef0  lea r9, [r15+0x3A8]
000074da185d4ef7  movaps [rdi], xmm7
000074da185d4efa  movaps [rsi], xmm10
000074da185d4efe  movaps [rdx], xmm11
000074da185d4f02  movaps [rcx], xmm13
000074da185d4f06  mov rax, 0x5946061DFA50
000074da185d4f10  call rax
000074da185d4f12  movaps xmm7, [rsp]
000074da185d4f16  add rsp, 0x40
000074da185d4f1a  vmovaps xmm0, [rsp]
000074da185d4f1f  vmovaps xmm1, [rsp+0x10]
000074da185d4f25  vmovaps xmm2, [rsp+0x20]
000074da185d4f2b  vmovaps xmm3, [rsp+0x30]
000074da185d4f31  vmovaps xmm4, [rsp+0x40]
000074da185d4f37  vmovaps xmm5, [rsp+0x50]
000074da185d4f3d  vmovaps xmm6, [rsp+0x60]
000074da185d4f43  vmovaps xmm8, [rsp+0x70]
000074da185d4f49  vmovaps xmm9, [rsp+0x80]
000074da185d4f52  vmovaps xmm10, [rsp+0x90]
000074da185d4f5b  vmovaps xmm11, [rsp+0xA0]
000074da185d4f64  vmovaps xmm12, [rsp+0xB0]
000074da185d4f6d  vmovaps xmm13, [rsp+0xC0]
000074da185d4f76  vmovaps xmm14, [rsp+0xD0]
000074da185d4f7f  vmovaps xmm15, [rsp+0xE0]
000074da185d4f88  add rsp, 0xF0
000074da185d4f8f  pop r11
000074da185d4f91  pop r10
000074da185d4f93  pop r9
000074da185d4f95  pop r8
000074da185d4f97  pop rsi
000074da185d4f98  pop rdi
000074da185d4f99  pop rdx
000074da185d4f9a  pop rcx
000074da185d4f9b  pop rax
000074da185d4f9c  add rsp, 0x08
000074da185d4fa0  jmp 0x000074DA185D2F58
000074da185d4fa5  call 0x000074DA1840C260
000074da185d4faa  jmp 0x000074DA185D2F62
000074da185d4faf  call 0x000074DA18409D70
000074da185d4fb4  jmp 0x000074DA185D2F6C
000074da185d4fb9  sub rsp, 0x08
000074da185d4fbd  push rax
000074da185d4fbe  push rcx
000074da185d4fbf  push rdx
000074da185d4fc0  push rdi
000074da185d4fc1  push rsi
000074da185d4fc2  push r8
000074da185d4fc4  push r9
000074da185d4fc6  push r10
000074da185d4fc8  push r11
000074da185d4fca  sub rsp, 0xF0
000074da185d4fd1  vmovaps [rsp], xmm0
000074da185d4fd6  vmovaps [rsp+0x10], xmm1
000074da185d4fdc  vmovaps [rsp+0x20], xmm2
000074da185d4fe2  vmovaps [rsp+0x30], xmm3
000074da185d4fe8  vmovaps [rsp+0x40], xmm4
000074da185d4fee  vmovaps [rsp+0x50], xmm5
000074da185d4ff4  vmovaps [rsp+0x60], xmm7
000074da185d4ffa  vmovaps [rsp+0x70], xmm8
000074da185d5000  vmovaps [rsp+0x80], xmm9
000074da185d5009  vmovaps [rsp+0x90], xmm10
000074da185d5012  vmovaps [rsp+0xA0], xmm11
000074da185d501b  vmovaps [rsp+0xB0], xmm12
000074da185d5024  vmovaps [rsp+0xC0], xmm13
000074da185d502d  vmovaps [rsp+0xD0], xmm14
000074da185d5036  vmovaps [rsp+0xE0], xmm15
000074da185d503f  sub rsp, 0x40
000074da185d5043  lea rdi, [rsp]
000074da185d5047  lea rsi, [rsp+0x10]
000074da185d504c  lea rdx, [rsp+0x20]
000074da185d5051  lea rcx, [rsp+0x30]
000074da185d5056  mov r8d, 0x00
000074da185d505c  lea r9, [r15+0x3A8]
000074da185d5063  movaps [rdi], xmm6
000074da185d5066  movaps [rsi], xmm8
000074da185d506a  movaps [rdx], xmm15
000074da185d506e  movaps [rcx], xmm10
000074da185d5072  mov rax, 0x5946061DFA50
000074da185d507c  call rax
000074da185d507e  movaps xmm6, [rsp]
000074da185d5082  add rsp, 0x40
000074da185d5086  vmovaps xmm0, [rsp]
000074da185d508b  vmovaps xmm1, [rsp+0x10]
000074da185d5091  vmovaps xmm2, [rsp+0x20]
000074da185d5097  vmovaps xmm3, [rsp+0x30]
000074da185d509d  vmovaps xmm4, [rsp+0x40]
000074da185d50a3  vmovaps xmm5, [rsp+0x50]
000074da185d50a9  vmovaps xmm7, [rsp+0x60]
000074da185d50af  vmovaps xmm8, [rsp+0x70]
000074da185d50b5  vmovaps xmm9, [rsp+0x80]
000074da185d50be  vmovaps xmm10, [rsp+0x90]
000074da185d50c7  vmovaps xmm11, [rsp+0xA0]
000074da185d50d0  vmovaps xmm12, [rsp+0xB0]
000074da185d50d9  vmovaps xmm13, [rsp+0xC0]
000074da185d50e2  vmovaps xmm14, [rsp+0xD0]
000074da185d50eb  vmovaps xmm15, [rsp+0xE0]
000074da185d50f4  add rsp, 0xF0
000074da185d50fb  pop r11
000074da185d50fd  pop r10
000074da185d50ff  pop r9
000074da185d5101  pop r8
000074da185d5103  pop rsi
000074da185d5104  pop rdi
000074da185d5105  pop rdx
000074da185d5106  pop rcx
000074da185d5107  pop rax
000074da185d5108  add rsp, 0x08
000074da185d510c  jmp 0x000074DA185D2FA4
000074da185d5111  sub rsp, 0x08
000074da185d5115  push rax
000074da185d5116  push rcx
000074da185d5117  push rdx
000074da185d5118  push rdi
000074da185d5119  push rsi
000074da185d511a  push r8
000074da185d511c  push r9
000074da185d511e  push r10
000074da185d5120  push r11
000074da185d5122  sub rsp, 0xF0
000074da185d5129  vmovaps [rsp], xmm0
000074da185d512e  vmovaps [rsp+0x10], xmm1
000074da185d5134  vmovaps [rsp+0x20], xmm2
000074da185d513a  vmovaps [rsp+0x30], xmm3
000074da185d5140  vmovaps [rsp+0x40], xmm4
000074da185d5146  vmovaps [rsp+0x50], xmm5
000074da185d514c  vmovaps [rsp+0x60], xmm6
000074da185d5152  vmovaps [rsp+0x70], xmm7
000074da185d5158  vmovaps [rsp+0x80], xmm8
000074da185d5161  vmovaps [rsp+0x90], xmm9
000074da185d516a  vmovaps [rsp+0xA0], xmm11
000074da185d5173  vmovaps [rsp+0xB0], xmm12
000074da185d517c  vmovaps [rsp+0xC0], xmm13
000074da185d5185  vmovaps [rsp+0xD0], xmm14
000074da185d518e  vmovaps [rsp+0xE0], xmm15
000074da185d5197  sub rsp, 0x40
000074da185d519b  lea rdi, [rsp]
000074da185d519f  lea rsi, [rsp+0x10]
000074da185d51a4  lea rdx, [rsp+0x20]
000074da185d51a9  lea rcx, [rsp+0x30]
000074da185d51ae  mov r8d, 0x00
000074da185d51b4  lea r9, [r15+0x3A8]
000074da185d51bb  movaps [rdi], xmm10
000074da185d51bf  movaps [rsi], xmm9
000074da185d51c3  movaps [rdx], xmm13
000074da185d51c7  movaps [rcx], xmm15
000074da185d51cb  mov rax, 0x5946061DFA50
000074da185d51d5  call rax
000074da185d51d7  movaps xmm10, [rsp]
000074da185d51dc  add rsp, 0x40
000074da185d51e0  vmovaps xmm0, [rsp]
000074da185d51e5  vmovaps xmm1, [rsp+0x10]
000074da185d51eb  vmovaps xmm2, [rsp+0x20]
000074da185d51f1  vmovaps xmm3, [rsp+0x30]
000074da185d51f7  vmovaps xmm4, [rsp+0x40]
000074da185d51fd  vmovaps xmm5, [rsp+0x50]
000074da185d5203  vmovaps xmm6, [rsp+0x60]
000074da185d5209  vmovaps xmm7, [rsp+0x70]
000074da185d520f  vmovaps xmm8, [rsp+0x80]
000074da185d5218  vmovaps xmm9, [rsp+0x90]
000074da185d5221  vmovaps xmm11, [rsp+0xA0]
000074da185d522a  vmovaps xmm12, [rsp+0xB0]
000074da185d5233  vmovaps xmm13, [rsp+0xC0]
000074da185d523c  vmovaps xmm14, [rsp+0xD0]
000074da185d5245  vmovaps xmm15, [rsp+0xE0]
000074da185d524e  add rsp, 0xF0
000074da185d5255  pop r11
000074da185d5257  pop r10
000074da185d5259  pop r9
000074da185d525b  pop r8
000074da185d525d  pop rsi
000074da185d525e  pop rdi
000074da185d525f  pop rdx
000074da185d5260  pop rcx
000074da185d5261  pop rax
000074da185d5262  add rsp, 0x08
000074da185d5266  jmp 0x000074DA185D2FCD
000074da185d526b  sub rsp, 0x08
000074da185d526f  push rax
000074da185d5270  push rcx
000074da185d5271  push rdx
000074da185d5272  push rdi
000074da185d5273  push rsi
000074da185d5274  push r8
000074da185d5276  push r9
000074da185d5278  push r10
000074da185d527a  push r11
000074da185d527c  sub rsp, 0xF0
000074da185d5283  vmovaps [rsp], xmm0
000074da185d5288  vmovaps [rsp+0x10], xmm1
000074da185d528e  vmovaps [rsp+0x20], xmm2
000074da185d5294  vmovaps [rsp+0x30], xmm3
000074da185d529a  vmovaps [rsp+0x40], xmm4
000074da185d52a0  vmovaps [rsp+0x50], xmm5
000074da185d52a6  vmovaps [rsp+0x60], xmm6
000074da185d52ac  vmovaps [rsp+0x70], xmm7
000074da185d52b2  vmovaps [rsp+0x80], xmm8
000074da185d52bb  vmovaps [rsp+0x90], xmm9
000074da185d52c4  vmovaps [rsp+0xA0], xmm10
000074da185d52cd  vmovaps [rsp+0xB0], xmm11
000074da185d52d6  vmovaps [rsp+0xC0], xmm12
000074da185d52df  vmovaps [rsp+0xD0], xmm14
000074da185d52e8  vmovaps [rsp+0xE0], xmm15
000074da185d52f1  sub rsp, 0x40
000074da185d52f5  lea rdi, [rsp]
000074da185d52f9  lea rsi, [rsp+0x10]
000074da185d52fe  lea rdx, [rsp+0x20]
000074da185d5303  lea rcx, [rsp+0x30]
000074da185d5308  mov r8d, 0x00
000074da185d530e  lea r9, [r15+0x3A8]
000074da185d5315  movaps [rdi], xmm13
000074da185d5319  movaps [rsi], xmm12
000074da185d531d  movaps [rdx], xmm4
000074da185d5320  movaps [rcx], xmm15
000074da185d5324  mov rax, 0x5946061DFA50
000074da185d532e  call rax
000074da185d5330  movaps xmm13, [rsp]
000074da185d5335  add rsp, 0x40
000074da185d5339  vmovaps xmm0, [rsp]
000074da185d533e  vmovaps xmm1, [rsp+0x10]
000074da185d5344  vmovaps xmm2, [rsp+0x20]
000074da185d534a  vmovaps xmm3, [rsp+0x30]
000074da185d5350  vmovaps xmm4, [rsp+0x40]
000074da185d5356  vmovaps xmm5, [rsp+0x50]
000074da185d535c  vmovaps xmm6, [rsp+0x60]
000074da185d5362  vmovaps xmm7, [rsp+0x70]
000074da185d5368  vmovaps xmm8, [rsp+0x80]
000074da185d5371  vmovaps xmm9, [rsp+0x90]
000074da185d537a  vmovaps xmm10, [rsp+0xA0]
000074da185d5383  vmovaps xmm11, [rsp+0xB0]
000074da185d538c  vmovaps xmm12, [rsp+0xC0]
000074da185d5395  vmovaps xmm14, [rsp+0xD0]
000074da185d539e  vmovaps xmm15, [rsp+0xE0]
000074da185d53a7  add rsp, 0xF0
000074da185d53ae  pop r11
000074da185d53b0  pop r10
000074da185d53b2  pop r9
000074da185d53b4  pop r8
000074da185d53b6  pop rsi
000074da185d53b7  pop rdi
000074da185d53b8  pop rdx
000074da185d53b9  pop rcx
000074da185d53ba  pop rax
000074da185d53bb  add rsp, 0x08
000074da185d53bf  jmp 0x000074DA185D2FF6
000074da185d53c4  sub rsp, 0x08
000074da185d53c8  push rax
000074da185d53c9  push rcx
000074da185d53ca  push rdx
000074da185d53cb  push rdi
000074da185d53cc  push rsi
000074da185d53cd  push r8
000074da185d53cf  push r9
000074da185d53d1  push r10
000074da185d53d3  push r11
000074da185d53d5  sub rsp, 0xF0
000074da185d53dc  vmovaps [rsp], xmm0
000074da185d53e1  vmovaps [rsp+0x10], xmm1
000074da185d53e7  vmovaps [rsp+0x20], xmm2
000074da185d53ed  vmovaps [rsp+0x30], xmm3
000074da185d53f3  vmovaps [rsp+0x40], xmm4
000074da185d53f9  vmovaps [rsp+0x50], xmm5
000074da185d53ff  vmovaps [rsp+0x60], xmm6
000074da185d5405  vmovaps [rsp+0x70], xmm7
000074da185d540b  vmovaps [rsp+0x80], xmm8
000074da185d5414  vmovaps [rsp+0x90], xmm9
000074da185d541d  vmovaps [rsp+0xA0], xmm10
000074da185d5426  vmovaps [rsp+0xB0], xmm11
000074da185d542f  vmovaps [rsp+0xC0], xmm13
000074da185d5438  vmovaps [rsp+0xD0], xmm14
000074da185d5441  vmovaps [rsp+0xE0], xmm15
000074da185d544a  sub rsp, 0x40
000074da185d544e  lea rdi, [rsp]
000074da185d5452  lea rsi, [rsp+0x10]
000074da185d5457  lea rdx, [rsp+0x20]
000074da185d545c  lea rcx, [rsp+0x30]
000074da185d5461  mov r8d, 0x00
000074da185d5467  lea r9, [r15+0x3A8]
000074da185d546e  movaps [rdi], xmm12
000074da185d5472  movaps [rsi], xmm7
000074da185d5475  movaps [rdx], xmm1
000074da185d5478  movaps [rcx], xmm15
000074da185d547c  mov rax, 0x5946061DFA50
000074da185d5486  call rax
000074da185d5488  movaps xmm12, [rsp]
000074da185d548d  add rsp, 0x40
000074da185d5491  vmovaps xmm0, [rsp]
000074da185d5496  vmovaps xmm1, [rsp+0x10]
000074da185d549c  vmovaps xmm2, [rsp+0x20]
000074da185d54a2  vmovaps xmm3, [rsp+0x30]
000074da185d54a8  vmovaps xmm4, [rsp+0x40]
000074da185d54ae  vmovaps xmm5, [rsp+0x50]
000074da185d54b4  vmovaps xmm6, [rsp+0x60]
000074da185d54ba  vmovaps xmm7, [rsp+0x70]
000074da185d54c0  vmovaps xmm8, [rsp+0x80]
000074da185d54c9  vmovaps xmm9, [rsp+0x90]
000074da185d54d2  vmovaps xmm10, [rsp+0xA0]
000074da185d54db  vmovaps xmm11, [rsp+0xB0]
000074da185d54e4  vmovaps xmm13, [rsp+0xC0]
000074da185d54ed  vmovaps xmm14, [rsp+0xD0]
000074da185d54f6  vmovaps xmm15, [rsp+0xE0]
000074da185d54ff  add rsp, 0xF0
000074da185d5506  pop r11
000074da185d5508  pop r10
000074da185d550a  pop r9
000074da185d550c  pop r8
000074da185d550e  pop rsi
000074da185d550f  pop rdi
000074da185d5510  pop rdx
000074da185d5511  pop rcx
000074da185d5512  pop rax
000074da185d5513  add rsp, 0x08
000074da185d5517  jmp 0x000074DA185D301F
000074da185d551c  call 0x000074DA183FF430
000074da185d5521  jmp 0x000074DA185D3029
000074da185d5526  call 0x000074DA1840E760
000074da185d552b  jmp 0x000074DA185D3033
000074da185d5530  sub rsp, 0x08
000074da185d5534  push rax
000074da185d5535  push rcx
000074da185d5536  push rdx
000074da185d5537  push rdi
000074da185d5538  push rsi
000074da185d5539  push r8
000074da185d553b  push r9
000074da185d553d  push r10
000074da185d553f  push r11
000074da185d5541  sub rsp, 0xF0
000074da185d5548  vmovaps [rsp], xmm0
000074da185d554d  vmovaps [rsp+0x10], xmm1
000074da185d5553  vmovaps [rsp+0x20], xmm2
000074da185d5559  vmovaps [rsp+0x30], xmm3
000074da185d555f  vmovaps [rsp+0x40], xmm4
000074da185d5565  vmovaps [rsp+0x50], xmm5
000074da185d556b  vmovaps [rsp+0x60], xmm6
000074da185d5571  vmovaps [rsp+0x70], xmm8
000074da185d5577  vmovaps [rsp+0x80], xmm9
000074da185d5580  vmovaps [rsp+0x90], xmm10
000074da185d5589  vmovaps [rsp+0xA0], xmm11
000074da185d5592  vmovaps [rsp+0xB0], xmm12
000074da185d559b  vmovaps [rsp+0xC0], xmm13
000074da185d55a4  vmovaps [rsp+0xD0], xmm14
000074da185d55ad  vmovaps [rsp+0xE0], xmm15
000074da185d55b6  sub rsp, 0x40
000074da185d55ba  lea rdi, [rsp]
000074da185d55be  lea rsi, [rsp+0x10]
000074da185d55c3  lea rdx, [rsp+0x20]
000074da185d55c8  lea rcx, [rsp+0x30]
000074da185d55cd  mov r8d, 0x00
000074da185d55d3  lea r9, [r15+0x3A8]
000074da185d55da  movaps [rdi], xmm7
000074da185d55dd  movaps [rsi], xmm6
000074da185d55e0  movaps [rdx], xmm8
000074da185d55e4  movaps [rcx], xmm9
000074da185d55e8  mov rax, 0x5946061DFA50
000074da185d55f2  call rax
000074da185d55f4  movaps xmm7, [rsp]
000074da185d55f8  add rsp, 0x40
000074da185d55fc  vmovaps xmm0, [rsp]
000074da185d5601  vmovaps xmm1, [rsp+0x10]
000074da185d5607  vmovaps xmm2, [rsp+0x20]
000074da185d560d  vmovaps xmm3, [rsp+0x30]
000074da185d5613  vmovaps xmm4, [rsp+0x40]
000074da185d5619  vmovaps xmm5, [rsp+0x50]
000074da185d561f  vmovaps xmm6, [rsp+0x60]
000074da185d5625  vmovaps xmm8, [rsp+0x70]
000074da185d562b  vmovaps xmm9, [rsp+0x80]
000074da185d5634  vmovaps xmm10, [rsp+0x90]
000074da185d563d  vmovaps xmm11, [rsp+0xA0]
000074da185d5646  vmovaps xmm12, [rsp+0xB0]
000074da185d564f  vmovaps xmm13, [rsp+0xC0]
000074da185d5658  vmovaps xmm14, [rsp+0xD0]
000074da185d5661  vmovaps xmm15, [rsp+0xE0]
000074da185d566a  add rsp, 0xF0
000074da185d5671  pop r11
000074da185d5673  pop r10
000074da185d5675  pop r9
000074da185d5677  pop r8
000074da185d5679  pop rsi
000074da185d567a  pop rdi
000074da185d567b  pop rdx
000074da185d567c  pop rcx
000074da185d567d  pop rax
000074da185d567e  add rsp, 0x08
000074da185d5682  jmp 0x000074DA185D305D
000074da185d5687  sub rsp, 0x08
000074da185d568b  push rax
000074da185d568c  push rcx
000074da185d568d  push rdx
000074da185d568e  push rdi
000074da185d568f  push rsi
000074da185d5690  push r8
000074da185d5692  push r9
000074da185d5694  push r10
000074da185d5696  push r11
000074da185d5698  sub rsp, 0xF0
000074da185d569f  vmovaps [rsp], xmm0
000074da185d56a4  vmovaps [rsp+0x10], xmm1
000074da185d56aa  vmovaps [rsp+0x20], xmm2
000074da185d56b0  vmovaps [rsp+0x30], xmm3
000074da185d56b6  vmovaps [rsp+0x40], xmm4
000074da185d56bc  vmovaps [rsp+0x50], xmm5
000074da185d56c2  vmovaps [rsp+0x60], xmm6
000074da185d56c8  vmovaps [rsp+0x70], xmm7
000074da185d56ce  vmovaps [rsp+0x80], xmm9
000074da185d56d7  vmovaps [rsp+0x90], xmm10
000074da185d56e0  vmovaps [rsp+0xA0], xmm11
000074da185d56e9  vmovaps [rsp+0xB0], xmm12
000074da185d56f2  vmovaps [rsp+0xC0], xmm13
000074da185d56fb  vmovaps [rsp+0xD0], xmm14
000074da185d5704  vmovaps [rsp+0xE0], xmm15
000074da185d570d  sub rsp, 0x40
000074da185d5711  lea rdi, [rsp]
000074da185d5715  lea rsi, [rsp+0x10]
000074da185d571a  lea rdx, [rsp+0x20]
000074da185d571f  lea rcx, [rsp+0x30]
000074da185d5724  mov r8d, 0x00
000074da185d572a  lea r9, [r15+0x3A8]
000074da185d5731  movaps [rdi], xmm8
000074da185d5735  movaps [rsi], xmm10
000074da185d5739  movaps [rdx], xmm14
000074da185d573d  movaps [rcx], xmm9
000074da185d5741  mov rax, 0x5946061DFA50
000074da185d574b  call rax
000074da185d574d  movaps xmm8, [rsp]
000074da185d5752  add rsp, 0x40
000074da185d5756  vmovaps xmm0, [rsp]
000074da185d575b  vmovaps xmm1, [rsp+0x10]
000074da185d5761  vmovaps xmm2, [rsp+0x20]
000074da185d5767  vmovaps xmm3, [rsp+0x30]
000074da185d576d  vmovaps xmm4, [rsp+0x40]
000074da185d5773  vmovaps xmm5, [rsp+0x50]
000074da185d5779  vmovaps xmm6, [rsp+0x60]
000074da185d577f  vmovaps xmm7, [rsp+0x70]
000074da185d5785  vmovaps xmm9, [rsp+0x80]
000074da185d578e  vmovaps xmm10, [rsp+0x90]
000074da185d5797  vmovaps xmm11, [rsp+0xA0]
000074da185d57a0  vmovaps xmm12, [rsp+0xB0]
000074da185d57a9  vmovaps xmm13, [rsp+0xC0]
000074da185d57b2  vmovaps xmm14, [rsp+0xD0]
000074da185d57bb  vmovaps xmm15, [rsp+0xE0]
000074da185d57c4  add rsp, 0xF0
000074da185d57cb  pop r11
000074da185d57cd  pop r10
000074da185d57cf  pop r9
000074da185d57d1  pop r8
000074da185d57d3  pop rsi
000074da185d57d4  pop rdi
000074da185d57d5  pop rdx
000074da185d57d6  pop rcx
000074da185d57d7  pop rax
000074da185d57d8  add rsp, 0x08
000074da185d57dc  jmp 0x000074DA185D3083
000074da185d57e1  sub rsp, 0x08
000074da185d57e5  push rax
000074da185d57e6  push rcx
000074da185d57e7  push rdx
000074da185d57e8  push rdi
000074da185d57e9  push rsi
000074da185d57ea  push r8
000074da185d57ec  push r9
000074da185d57ee  push r10
000074da185d57f0  push r11
000074da185d57f2  sub rsp, 0xF0
000074da185d57f9  vmovaps [rsp], xmm0
000074da185d57fe  vmovaps [rsp+0x10], xmm1
000074da185d5804  vmovaps [rsp+0x20], xmm2
000074da185d580a  vmovaps [rsp+0x30], xmm3
000074da185d5810  vmovaps [rsp+0x40], xmm4
000074da185d5816  vmovaps [rsp+0x50], xmm5
000074da185d581c  vmovaps [rsp+0x60], xmm6
000074da185d5822  vmovaps [rsp+0x70], xmm7
000074da185d5828  vmovaps [rsp+0x80], xmm8
000074da185d5831  vmovaps [rsp+0x90], xmm9
000074da185d583a  vmovaps [rsp+0xA0], xmm11
000074da185d5843  vmovaps [rsp+0xB0], xmm12
000074da185d584c  vmovaps [rsp+0xC0], xmm13
000074da185d5855  vmovaps [rsp+0xD0], xmm14
000074da185d585e  vmovaps [rsp+0xE0], xmm15
000074da185d5867  sub rsp, 0x40
000074da185d586b  lea rdi, [rsp]
000074da185d586f  lea rsi, [rsp+0x10]
000074da185d5874  lea rdx, [rsp+0x20]
000074da185d5879  lea rcx, [rsp+0x30]
000074da185d587e  mov r8d, 0x00
000074da185d5884  lea r9, [r15+0x3A8]
000074da185d588b  movaps [rdi], xmm10
000074da185d588f  movaps [rsi], xmm13
000074da185d5893  movaps [rdx], xmm11
000074da185d5897  movaps [rcx], xmm14
000074da185d589b  mov rax, 0x5946061DFA50
000074da185d58a5  call rax
000074da185d58a7  movaps xmm10, [rsp]
000074da185d58ac  add rsp, 0x40
000074da185d58b0  vmovaps xmm0, [rsp]
000074da185d58b5  vmovaps xmm1, [rsp+0x10]
000074da185d58bb  vmovaps xmm2, [rsp+0x20]
000074da185d58c1  vmovaps xmm3, [rsp+0x30]
000074da185d58c7  vmovaps xmm4, [rsp+0x40]
000074da185d58cd  vmovaps xmm5, [rsp+0x50]
000074da185d58d3  vmovaps xmm6, [rsp+0x60]
000074da185d58d9  vmovaps xmm7, [rsp+0x70]
000074da185d58df  vmovaps xmm8, [rsp+0x80]
000074da185d58e8  vmovaps xmm9, [rsp+0x90]
000074da185d58f1  vmovaps xmm11, [rsp+0xA0]
000074da185d58fa  vmovaps xmm12, [rsp+0xB0]
000074da185d5903  vmovaps xmm13, [rsp+0xC0]
000074da185d590c  vmovaps xmm14, [rsp+0xD0]
000074da185d5915  vmovaps xmm15, [rsp+0xE0]
000074da185d591e  add rsp, 0xF0
000074da185d5925  pop r11
000074da185d5927  pop r10
000074da185d5929  pop r9
000074da185d592b  pop r8
000074da185d592d  pop rsi
000074da185d592e  pop rdi
000074da185d592f  pop rdx
000074da185d5930  pop rcx
000074da185d5931  pop rax
000074da185d5932  add rsp, 0x08
000074da185d5936  jmp 0x000074DA185D30A9
000074da185d593b  sub rsp, 0x08
000074da185d593f  push rax
000074da185d5940  push rcx
000074da185d5941  push rdx
000074da185d5942  push rdi
000074da185d5943  push rsi
000074da185d5944  push r8
000074da185d5946  push r9
000074da185d5948  push r10
000074da185d594a  push r11
000074da185d594c  sub rsp, 0xF0
000074da185d5953  vmovaps [rsp], xmm0
000074da185d5958  vmovaps [rsp+0x10], xmm1
000074da185d595e  vmovaps [rsp+0x20], xmm2
000074da185d5964  vmovaps [rsp+0x30], xmm3
000074da185d596a  vmovaps [rsp+0x40], xmm4
000074da185d5970  vmovaps [rsp+0x50], xmm5
000074da185d5976  vmovaps [rsp+0x60], xmm6
000074da185d597c  vmovaps [rsp+0x70], xmm7
000074da185d5982  vmovaps [rsp+0x80], xmm8
000074da185d598b  vmovaps [rsp+0x90], xmm9
000074da185d5994  vmovaps [rsp+0xA0], xmm10
000074da185d599d  vmovaps [rsp+0xB0], xmm11
000074da185d59a6  vmovaps [rsp+0xC0], xmm12
000074da185d59af  vmovaps [rsp+0xD0], xmm14
000074da185d59b8  vmovaps [rsp+0xE0], xmm15
000074da185d59c1  sub rsp, 0x40
000074da185d59c5  lea rdi, [rsp]
000074da185d59c9  lea rsi, [rsp+0x10]
000074da185d59ce  lea rdx, [rsp+0x20]
000074da185d59d3  lea rcx, [rsp+0x30]
000074da185d59d8  mov r8d, 0x00
000074da185d59de  lea r9, [r15+0x3A8]
000074da185d59e5  movaps [rdi], xmm13
000074da185d59e9  movaps [rsi], xmm12
000074da185d59ed  movaps [rdx], xmm15
000074da185d59f1  movaps [rcx], xmm14
000074da185d59f5  mov rax, 0x5946061DFA50
000074da185d59ff  call rax
000074da185d5a01  movaps xmm13, [rsp]
000074da185d5a06  add rsp, 0x40
000074da185d5a0a  vmovaps xmm0, [rsp]
000074da185d5a0f  vmovaps xmm1, [rsp+0x10]
000074da185d5a15  vmovaps xmm2, [rsp+0x20]
000074da185d5a1b  vmovaps xmm3, [rsp+0x30]
000074da185d5a21  vmovaps xmm4, [rsp+0x40]
000074da185d5a27  vmovaps xmm5, [rsp+0x50]
000074da185d5a2d  vmovaps xmm6, [rsp+0x60]
000074da185d5a33  vmovaps xmm7, [rsp+0x70]
000074da185d5a39  vmovaps xmm8, [rsp+0x80]
000074da185d5a42  vmovaps xmm9, [rsp+0x90]
000074da185d5a4b  vmovaps xmm10, [rsp+0xA0]
000074da185d5a54  vmovaps xmm11, [rsp+0xB0]
000074da185d5a5d  vmovaps xmm12, [rsp+0xC0]
000074da185d5a66  vmovaps xmm14, [rsp+0xD0]
000074da185d5a6f  vmovaps xmm15, [rsp+0xE0]
000074da185d5a78  add rsp, 0xF0
000074da185d5a7f  pop r11
000074da185d5a81  pop r10
000074da185d5a83  pop r9
000074da185d5a85  pop r8
000074da185d5a87  pop rsi
000074da185d5a88  pop rdi
000074da185d5a89  pop rdx
000074da185d5a8a  pop rcx
000074da185d5a8b  pop rax
000074da185d5a8c  add rsp, 0x08
000074da185d5a90  jmp 0x000074DA185D30CF
000074da185d5a95  call 0x000074DA1840E760
000074da185d5a9a  jmp 0x000074DA185D30DC
000074da185d5a9f  call 0x000074DA1840D4E0
000074da185d5aa4  jmp 0x000074DA185D30E9
000074da185d5aa9  sub rsp, 0x08
000074da185d5aad  push rax
000074da185d5aae  push rcx
000074da185d5aaf  push rdx
000074da185d5ab0  push rdi
000074da185d5ab1  push rsi
000074da185d5ab2  push r8
000074da185d5ab4  push r9
000074da185d5ab6  push r10
000074da185d5ab8  push r11
000074da185d5aba  sub rsp, 0xF0
000074da185d5ac1  vmovaps [rsp], xmm0
000074da185d5ac6  vmovaps [rsp+0x10], xmm1
000074da185d5acc  vmovaps [rsp+0x20], xmm2
000074da185d5ad2  vmovaps [rsp+0x30], xmm3
000074da185d5ad8  vmovaps [rsp+0x40], xmm4
000074da185d5ade  vmovaps [rsp+0x50], xmm5
000074da185d5ae4  vmovaps [rsp+0x60], xmm6
000074da185d5aea  vmovaps [rsp+0x70], xmm7
000074da185d5af0  vmovaps [rsp+0x80], xmm8
000074da185d5af9  vmovaps [rsp+0x90], xmm9
000074da185d5b02  vmovaps [rsp+0xA0], xmm10
000074da185d5b0b  vmovaps [rsp+0xB0], xmm12
000074da185d5b14  vmovaps [rsp+0xC0], xmm13
000074da185d5b1d  vmovaps [rsp+0xD0], xmm14
000074da185d5b26  vmovaps [rsp+0xE0], xmm15
000074da185d5b2f  sub rsp, 0x40
000074da185d5b33  lea rdi, [rsp]
000074da185d5b37  lea rsi, [rsp+0x10]
000074da185d5b3c  lea rdx, [rsp+0x20]
000074da185d5b41  lea rcx, [rsp+0x30]
000074da185d5b46  mov r8d, 0x00
000074da185d5b4c  lea r9, [r15+0x3A8]
000074da185d5b53  movaps [rdi], xmm11
000074da185d5b57  movaps [rsi], xmm7
000074da185d5b5a  movaps [rdx], xmm1
000074da185d5b5d  movaps [rcx], xmm12
000074da185d5b61  mov rax, 0x5946061DFA50
000074da185d5b6b  call rax
000074da185d5b6d  movaps xmm11, [rsp]
000074da185d5b72  add rsp, 0x40
000074da185d5b76  vmovaps xmm0, [rsp]
000074da185d5b7b  vmovaps xmm1, [rsp+0x10]
000074da185d5b81  vmovaps xmm2, [rsp+0x20]
000074da185d5b87  vmovaps xmm3, [rsp+0x30]
000074da185d5b8d  vmovaps xmm4, [rsp+0x40]
000074da185d5b93  vmovaps xmm5, [rsp+0x50]
000074da185d5b99  vmovaps xmm6, [rsp+0x60]
000074da185d5b9f  vmovaps xmm7, [rsp+0x70]
000074da185d5ba5  vmovaps xmm8, [rsp+0x80]
000074da185d5bae  vmovaps xmm9, [rsp+0x90]
000074da185d5bb7  vmovaps xmm10, [rsp+0xA0]
000074da185d5bc0  vmovaps xmm12, [rsp+0xB0]
000074da185d5bc9  vmovaps xmm13, [rsp+0xC0]
000074da185d5bd2  vmovaps xmm14, [rsp+0xD0]
000074da185d5bdb  vmovaps xmm15, [rsp+0xE0]
000074da185d5be4  add rsp, 0xF0
000074da185d5beb  pop r11
000074da185d5bed  pop r10
000074da185d5bef  pop r9
000074da185d5bf1  pop r8
000074da185d5bf3  pop rsi
000074da185d5bf4  pop rdi
000074da185d5bf5  pop rdx
000074da185d5bf6  pop rcx
000074da185d5bf7  pop rax
000074da185d5bf8  add rsp, 0x08
000074da185d5bfc  jmp 0x000074DA185D3122
000074da185d5c01  call 0x000074DA183FF430
000074da185d5c06  jmp 0x000074DA185D3134
000074da185d5c0b  sub rsp, 0x08
000074da185d5c0f  push rax
000074da185d5c10  push rcx
000074da185d5c11  push rdx
000074da185d5c12  push rdi
000074da185d5c13  push rsi
000074da185d5c14  push r8
000074da185d5c16  push r9
000074da185d5c18  push r10
000074da185d5c1a  push r11
000074da185d5c1c  sub rsp, 0xF0
000074da185d5c23  vmovaps [rsp], xmm0
000074da185d5c28  vmovaps [rsp+0x10], xmm1
000074da185d5c2e  vmovaps [rsp+0x20], xmm2
000074da185d5c34  vmovaps [rsp+0x30], xmm3
000074da185d5c3a  vmovaps [rsp+0x40], xmm4
000074da185d5c40  vmovaps [rsp+0x50], xmm5
000074da185d5c46  vmovaps [rsp+0x60], xmm6
000074da185d5c4c  vmovaps [rsp+0x70], xmm7
000074da185d5c52  vmovaps [rsp+0x80], xmm8
000074da185d5c5b  vmovaps [rsp+0x90], xmm10
000074da185d5c64  vmovaps [rsp+0xA0], xmm11
000074da185d5c6d  vmovaps [rsp+0xB0], xmm12
000074da185d5c76  vmovaps [rsp+0xC0], xmm13
000074da185d5c7f  vmovaps [rsp+0xD0], xmm14
000074da185d5c88  vmovaps [rsp+0xE0], xmm15
000074da185d5c91  sub rsp, 0x40
000074da185d5c95  lea rdi, [rsp]
000074da185d5c99  lea rsi, [rsp+0x10]
000074da185d5c9e  lea rdx, [rsp+0x20]
000074da185d5ca3  lea rcx, [rsp+0x30]
000074da185d5ca8  mov r8d, 0x00
000074da185d5cae  lea r9, [r15+0x3A8]
000074da185d5cb5  movaps [rdi], xmm9
000074da185d5cb9  movaps [rsi], xmm8
000074da185d5cbd  movaps [rdx], xmm14
000074da185d5cc1  movaps [rcx], xmm12
000074da185d5cc5  mov rax, 0x5946061DFA50
000074da185d5ccf  call rax
000074da185d5cd1  movaps xmm9, [rsp]
000074da185d5cd6  add rsp, 0x40
000074da185d5cda  vmovaps xmm0, [rsp]
000074da185d5cdf  vmovaps xmm1, [rsp+0x10]
000074da185d5ce5  vmovaps xmm2, [rsp+0x20]
000074da185d5ceb  vmovaps xmm3, [rsp+0x30]
000074da185d5cf1  vmovaps xmm4, [rsp+0x40]
000074da185d5cf7  vmovaps xmm5, [rsp+0x50]
000074da185d5cfd  vmovaps xmm6, [rsp+0x60]
000074da185d5d03  vmovaps xmm7, [rsp+0x70]
000074da185d5d09  vmovaps xmm8, [rsp+0x80]
000074da185d5d12  vmovaps xmm10, [rsp+0x90]
000074da185d5d1b  vmovaps xmm11, [rsp+0xA0]
000074da185d5d24  vmovaps xmm12, [rsp+0xB0]
000074da185d5d2d  vmovaps xmm13, [rsp+0xC0]
000074da185d5d36  vmovaps xmm14, [rsp+0xD0]
000074da185d5d3f  vmovaps xmm15, [rsp+0xE0]
000074da185d5d48  add rsp, 0xF0
000074da185d5d4f  pop r11
000074da185d5d51  pop r10
000074da185d5d53  pop r9
000074da185d5d55  pop r8
000074da185d5d57  pop rsi
000074da185d5d58  pop rdi
000074da185d5d59  pop rdx
000074da185d5d5a  pop rcx
000074da185d5d5b  pop rax
000074da185d5d5c  add rsp, 0x08
000074da185d5d60  jmp 0x000074DA185D3165
000074da185d5d65  sub rsp, 0x08
000074da185d5d69  push rax
000074da185d5d6a  push rcx
000074da185d5d6b  push rdx
000074da185d5d6c  push rdi
000074da185d5d6d  push rsi
000074da185d5d6e  push r8
000074da185d5d70  push r9
000074da185d5d72  push r10
000074da185d5d74  push r11
000074da185d5d76  sub rsp, 0xF0
000074da185d5d7d  vmovaps [rsp], xmm0
000074da185d5d82  vmovaps [rsp+0x10], xmm1
000074da185d5d88  vmovaps [rsp+0x20], xmm2
000074da185d5d8e  vmovaps [rsp+0x30], xmm3
000074da185d5d94  vmovaps [rsp+0x40], xmm4
000074da185d5d9a  vmovaps [rsp+0x50], xmm5
000074da185d5da0  vmovaps [rsp+0x60], xmm6
000074da185d5da6  vmovaps [rsp+0x70], xmm7
000074da185d5dac  vmovaps [rsp+0x80], xmm8
000074da185d5db5  vmovaps [rsp+0x90], xmm9
000074da185d5dbe  vmovaps [rsp+0xA0], xmm10
000074da185d5dc7  vmovaps [rsp+0xB0], xmm11
000074da185d5dd0  vmovaps [rsp+0xC0], xmm13
000074da185d5dd9  vmovaps [rsp+0xD0], xmm14
000074da185d5de2  vmovaps [rsp+0xE0], xmm15
000074da185d5deb  sub rsp, 0x40
000074da185d5def  lea rdi, [rsp]
000074da185d5df3  lea rsi, [rsp+0x10]
000074da185d5df8  lea rdx, [rsp+0x20]
000074da185d5dfd  lea rcx, [rsp+0x30]
000074da185d5e02  mov r8d, 0x00
000074da185d5e08  lea r9, [r15+0x3A8]
000074da185d5e0f  movaps [rdi], xmm12
000074da185d5e13  movaps [rsi], xmm10
000074da185d5e17  movaps [rdx], xmm15
000074da185d5e1b  movaps [rcx], xmm14
000074da185d5e1f  mov rax, 0x5946061DFA50
000074da185d5e29  call rax
000074da185d5e2b  movaps xmm12, [rsp]
000074da185d5e30  add rsp, 0x40
000074da185d5e34  vmovaps xmm0, [rsp]
000074da185d5e39  vmovaps xmm1, [rsp+0x10]
000074da185d5e3f  vmovaps xmm2, [rsp+0x20]
000074da185d5e45  vmovaps xmm3, [rsp+0x30]
000074da185d5e4b  vmovaps xmm4, [rsp+0x40]
000074da185d5e51  vmovaps xmm5, [rsp+0x50]
000074da185d5e57  vmovaps xmm6, [rsp+0x60]
000074da185d5e5d  vmovaps xmm7, [rsp+0x70]
000074da185d5e63  vmovaps xmm8, [rsp+0x80]
000074da185d5e6c  vmovaps xmm9, [rsp+0x90]
000074da185d5e75  vmovaps xmm10, [rsp+0xA0]
000074da185d5e7e  vmovaps xmm11, [rsp+0xB0]
000074da185d5e87  vmovaps xmm13, [rsp+0xC0]
000074da185d5e90  vmovaps xmm14, [rsp+0xD0]
000074da185d5e99  vmovaps xmm15, [rsp+0xE0]
000074da185d5ea2  add rsp, 0xF0
000074da185d5ea9  pop r11
000074da185d5eab  pop r10
000074da185d5ead  pop r9
000074da185d5eaf  pop r8
000074da185d5eb1  pop rsi
000074da185d5eb2  pop rdi
000074da185d5eb3  pop rdx
000074da185d5eb4  pop rcx
000074da185d5eb5  pop rax
000074da185d5eb6  add rsp, 0x08
000074da185d5eba  jmp 0x000074DA185D3196
000074da185d5ebf  sub rsp, 0x08
000074da185d5ec3  push rax
000074da185d5ec4  push rcx
000074da185d5ec5  push rdx
000074da185d5ec6  push rdi
000074da185d5ec7  push rsi
000074da185d5ec8  push r8
000074da185d5eca  push r9
000074da185d5ecc  push r10
000074da185d5ece  push r11
000074da185d5ed0  sub rsp, 0xF0
000074da185d5ed7  vmovaps [rsp], xmm0
000074da185d5edc  vmovaps [rsp+0x10], xmm1
000074da185d5ee2  vmovaps [rsp+0x20], xmm2
000074da185d5ee8  vmovaps [rsp+0x30], xmm3
000074da185d5eee  vmovaps [rsp+0x40], xmm4
000074da185d5ef4  vmovaps [rsp+0x50], xmm5
000074da185d5efa  vmovaps [rsp+0x60], xmm6
000074da185d5f00  vmovaps [rsp+0x70], xmm7
000074da185d5f06  vmovaps [rsp+0x80], xmm8
000074da185d5f0f  vmovaps [rsp+0x90], xmm9
000074da185d5f18  vmovaps [rsp+0xA0], xmm10
000074da185d5f21  vmovaps [rsp+0xB0], xmm11
000074da185d5f2a  vmovaps [rsp+0xC0], xmm12
000074da185d5f33  vmovaps [rsp+0xD0], xmm13
000074da185d5f3c  vmovaps [rsp+0xE0], xmm15
000074da185d5f45  sub rsp, 0x40
000074da185d5f49  lea rdi, [rsp]
000074da185d5f4d  lea rsi, [rsp+0x10]
000074da185d5f52  lea rdx, [rsp+0x20]
000074da185d5f57  lea rcx, [rsp+0x30]
000074da185d5f5c  mov r8d, 0x00
000074da185d5f62  lea r9, [r15+0x3A8]
000074da185d5f69  movaps [rdi], xmm14
000074da185d5f6d  movaps [rsi], xmm13
000074da185d5f71  movaps [rdx], xmm1
000074da185d5f74  movaps [rcx], xmm15
000074da185d5f78  mov rax, 0x5946061DFA50
000074da185d5f82  call rax
000074da185d5f84  movaps xmm14, [rsp]
000074da185d5f89  add rsp, 0x40
000074da185d5f8d  vmovaps xmm0, [rsp]
000074da185d5f92  vmovaps xmm1, [rsp+0x10]
000074da185d5f98  vmovaps xmm2, [rsp+0x20]
000074da185d5f9e  vmovaps xmm3, [rsp+0x30]
000074da185d5fa4  vmovaps xmm4, [rsp+0x40]
000074da185d5faa  vmovaps xmm5, [rsp+0x50]
000074da185d5fb0  vmovaps xmm6, [rsp+0x60]
000074da185d5fb6  vmovaps xmm7, [rsp+0x70]
000074da185d5fbc  vmovaps xmm8, [rsp+0x80]
000074da185d5fc5  vmovaps xmm9, [rsp+0x90]
000074da185d5fce  vmovaps xmm10, [rsp+0xA0]
000074da185d5fd7  vmovaps xmm11, [rsp+0xB0]
000074da185d5fe0  vmovaps xmm12, [rsp+0xC0]
000074da185d5fe9  vmovaps xmm13, [rsp+0xD0]
000074da185d5ff2  vmovaps xmm15, [rsp+0xE0]
000074da185d5ffb  add rsp, 0xF0
000074da185d6002  pop r11
000074da185d6004  pop r10
000074da185d6006  pop r9
000074da185d6008  pop r8
000074da185d600a  pop rsi
000074da185d600b  pop rdi
000074da185d600c  pop rdx
000074da185d600d  pop rcx
000074da185d600e  pop rax
000074da185d600f  add rsp, 0x08
000074da185d6013  jmp 0x000074DA185D31C7
000074da185d6018  call 0x000074DA184079B0
000074da185d601d  jmp 0x000074DA185D31DA
000074da185d6022  call 0x000074DA1840B100
000074da185d6027  jmp 0x000074DA185D31E5
000074da185d602c  call 0x000074DA18409E90
000074da185d6031  jmp 0x000074DA185D31F0
000074da185d6036  call 0x000074DA1840D600
000074da185d603b  jmp 0x000074DA185D31FB
000074da185d6040  int3
000074da185d6041  nop [rax+rax*1], ax
000074da185d604a  nop [rax+rax*1], ax
000074da185d6050  mov rax, [r15+0x40]
000074da185d6054  mov r14, [r15+0x58]
000074da185d6058  lea r12, [rax+r14*1]
000074da185d605c  vxorps xmm1, xmm1, xmm1
000074da185d6060  vpbroadcastq xmm1, xmm1
000074da185d6065  vxorps xmm15, xmm15, xmm15
000074da185d606a  vpbroadcastq xmm15, xmm15
000074da185d606f  lea rax, [r12+0x30]
000074da185d6074  mov r11, [r13+rax*1]
000074da185d6079  lea rax, [r12+0x38]
000074da185d607e  mov r10, [r13+rax*1]
000074da185d6083  movq xmm14, r11
000074da185d6088  movq xmm13, r10
000074da185d608d  movq xmm14, xmm14
000074da185d6092  movq xmm13, xmm13
000074da185d6097  vmovaps [rsp+0x10], xmm13
000074da185d609d  movq xmm13, xmm13
000074da185d60a2  movaps [r15+0x270], xmm13
000074da185d60aa  movaps xmm13, [r15+0x160]
000074da185d60b2  vmovaps [rsp+0x20], xmm13
000074da185d60b8  vmovaps xmm12, [rsp+0x20]
000074da185d60be  por xmm13, xmm12
000074da185d60c3  lea rax, [r12+0x20]
000074da185d60c8  mov r11, [r13+rax*1]
000074da185d60cd  lea rax, [r12+0x28]
000074da185d60d2  mov r10, [r13+rax*1]
000074da185d60d7  movq xmm12, r11
000074da185d60dc  movq xmm11, r10
000074da185d60e1  movq xmm12, xmm12
000074da185d60e6  movq xmm11, xmm11
000074da185d60eb  movaps xmm10, [r15+0x2D0]
000074da185d60f3  vmovaps [rsp+0x20], xmm10
000074da185d60f9  vmovaps xmm9, [rsp+0x20]
000074da185d60ff  por xmm10, xmm9
000074da185d6104  movaps xmm9, [r15+0x300]
000074da185d610c  vmovaps [rsp+0x20], xmm9
000074da185d6112  vmovaps xmm8, [rsp+0x20]
000074da185d6118  por xmm9, xmm8
000074da185d611d  movaps xmm8, [r15+0x2B0]
000074da185d6125  vmovaps [rsp+0x20], xmm8
000074da185d612b  vmovaps xmm7, [rsp+0x20]
000074da185d6131  por xmm8, xmm7
000074da185d6136  movaps xmm7, [r15+0x180]
000074da185d613e  vmovaps [rsp+0x20], xmm7
000074da185d6144  vmovaps xmm6, [rsp+0x20]
000074da185d614a  por xmm7, xmm6
000074da185d614e  lea rax, [r12+0x10]
000074da185d6153  mov r11, [r13+rax*1]
000074da185d6158  lea rax, [r12+0x18]
000074da185d615d  mov r10, [r13+rax*1]
000074da185d6162  movq xmm6, r11
000074da185d6167  movq xmm5, r10
000074da185d616c  movq xmm6, xmm6
000074da185d6170  movq xmm5, xmm5
000074da185d6174  movaps xmm4, [r15+0x200]
000074da185d617c  vmovaps [rsp+0x20], xmm4
000074da185d6182  vmovaps xmm3, [rsp+0x20]
000074da185d6188  por xmm4, xmm3
000074da185d618c  movaps xmm3, [r15+0x1F0]
000074da185d6194  vmovaps [rsp+0x20], xmm3
000074da185d619a  vmovaps xmm2, [rsp+0x20]
000074da185d61a0  por xmm3, xmm2
000074da185d61a4  movaps xmm2, [r15+0x2E0]
000074da185d61ac  vmovaps [rsp+0x20], xmm2
000074da185d61b2  vmovaps [rsp+0x30], xmm1
000074da185d61b8  vmovaps xmm1, [rsp+0x20]
000074da185d61be  por xmm2, xmm1
000074da185d61c2  movaps xmm1, [r15+0x2A0]
000074da185d61ca  vmovaps [rsp+0x20], xmm1
000074da185d61d0  vmovaps [rsp+0x40], xmm15
000074da185d61d6  vmovaps xmm15, [rsp+0x20]
000074da185d61dc  por xmm1, xmm15
000074da185d61e1  movaps xmm15, [r15+0x280]
000074da185d61e9  vmovaps [rsp+0x20], xmm15
000074da185d61ef  vmovaps [rsp+0x50], xmm1
000074da185d61f5  vmovaps xmm1, [rsp+0x20]
000074da185d61fb  por xmm15, xmm1
000074da185d6200  movaps xmm1, [r15+0x1C0]
000074da185d6208  vmovaps [rsp+0x20], xmm1
000074da185d620e  vmovaps [rsp+0x60], xmm15
000074da185d6214  vmovaps xmm15, [rsp+0x20]
000074da185d621a  por xmm1, xmm15
000074da185d621f  movaps xmm15, [r15+0x210]
000074da185d6227  vmovaps [rsp+0x20], xmm15
000074da185d622d  vmovaps [rsp+0x70], xmm1
000074da185d6233  vmovaps xmm1, [rsp+0x20]
000074da185d6239  por xmm15, xmm1
000074da185d623e  mov rax, [r13+r12*1]
000074da185d6243  vmovq xmm1, rax
000074da185d6248  vpbroadcastq xmm1, xmm1
000074da185d624d  vmovaps [rsp+0x20], xmm1
000074da185d6253  vxorps xmm1, xmm1, xmm1
000074da185d6257  vpbroadcastq xmm1, xmm1
000074da185d625c  mov rax, [r15+0xF8]
000074da185d6263  vmovaps [rsp+0x80], xmm1
000074da185d626c  movups xmm1, [r13+rax*1]
000074da185d6272  vmovaps [rsp+0x90], xmm1
000074da185d627b  vxorps xmm1, xmm1, xmm1
000074da185d627f  vpbroadcastq xmm1, xmm1
000074da185d6284  lea r11, [r12+0x08]
000074da185d6289  mov r12, [r13+r11*1]
000074da185d628e  vmovaps [rsp+0xA0], xmm1
000074da185d6297  movq xmm1, r12
000074da185d629c  movaps [r15+0x240], xmm1
000074da185d62a4  mov r12, [r15+0x50]
000074da185d62a8  lea r11, [r12+r14*1]
000074da185d62ac  mov [r15+0x60], r11
000074da185d62b0  lea r12, [r14+0x40]
000074da185d62b4  mov [r15+0x58], r12
000074da185d62b8  vmovaps xmm1, [rsp+0x30]
000074da185d62be  vmovaps [rsp+0x30], xmm15
000074da185d62c4  vmovaps xmm15, [rsp+0x90]
000074da185d62cd  vmovaps [rsp+0x90], xmm14
000074da185d62d6  vmovaps xmm14, [rsp+0x20]
000074da185d62dc  vmovaps [rsp+0x20], xmm13
000074da185d62e2  vmovaps [rsp+0xB0], xmm12
000074da185d62eb  movaps xmm13, xmm1
000074da185d62ef  vfmadd231pd xmm13, xmm15, xmm14
000074da185d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d62fa  vptest xmm12, xmm12
000074da185d62ff  jnz 0x000074DA185D6D9C
000074da185d6305  movaps xmm1, [r15+0x250]
000074da185d630d  vmovaps xmm15, [rsp+0x40]
000074da185d6313  vmovaps [rsp+0x40], xmm13
000074da185d6319  movaps xmm12, xmm15
000074da185d631d  vfmadd231pd xmm12, xmm1, xmm14
000074da185d6322  vcmppd xmm13, xmm12, xmm12, 0x03
000074da185d6328  vptest xmm13, xmm13
000074da185d632d  jnz 0x000074DA185D6EF5
000074da185d6333  movaps xmm15, [r15+0x1E0]
000074da185d633b  vmovaps [rsp+0xC0], xmm15
000074da185d6344  vmovaps xmm13, [rsp+0xC0]
000074da185d634d  por xmm15, xmm13
000074da185d6352  movaps xmm13, [r15+0x1D0]
000074da185d635a  vmovaps [rsp+0xC0], xmm13
000074da185d6363  vmovaps [rsp+0xD0], xmm1
000074da185d636c  vmovaps xmm1, [rsp+0xC0]
000074da185d6375  por xmm13, xmm1
000074da185d637a  movaps xmm1, [r15+0x2C0]
000074da185d6382  vmovaps [rsp+0xC0], xmm1
000074da185d638b  vmovaps [rsp+0xE0], xmm15
000074da185d6394  vmovaps xmm15, [rsp+0xC0]
000074da185d639d  por xmm1, xmm15
000074da185d63a2  movaps xmm15, [r15+0x290]
000074da185d63aa  vmovaps [rsp+0xC0], xmm15
000074da185d63b3  vmovaps [rsp+0xF0], xmm1
000074da185d63bc  vmovaps xmm1, [rsp+0xC0]
000074da185d63c5  por xmm15, xmm1
000074da185d63ca  movaps xmm1, [r15+0x260]
000074da185d63d2  vmovaps [rsp+0xC0], xmm1
000074da185d63db  vmovaps [rsp+0x100], xmm15
000074da185d63e4  vmovaps xmm15, [rsp+0xC0]
000074da185d63ed  por xmm1, xmm15
000074da185d63f2  vmovaps xmm15, [rsp+0xD0]
000074da185d63fb  vmovaps [rsp+0xC0], xmm1
000074da185d6404  vmovaps xmm1, [rsp+0xD0]
000074da185d640d  por xmm15, xmm1
000074da185d6412  lea r14, [rax+0xC0]
000074da185d6419  movups xmm1, [r13+r14*1]
000074da185d641f  mov [rsp+0xD0], rax
000074da185d6427  xor eax, eax
000074da185d6429  mov r14d, 0x200
000074da185d642f  cmp r12, r14
000074da185d6432  cmc
000074da185d6433  lahf
000074da185d6434  seto al
000074da185d6437  mov [r15+0x108], eax
000074da185d643e  vmovaps [rsp+0x110], xmm1
000074da185d6447  vmovaps xmm1, [rsp+0x80]
000074da185d6450  vmovaps [rsp+0x80], xmm15
000074da185d6459  vmovaps xmm15, [rsp+0x110]
000074da185d6462  vmovaps [rsp+0x110], xmm13
000074da185d646b  vmovaps [rsp+0x120], xmm12
000074da185d6474  movaps xmm13, xmm1
000074da185d6478  vfmadd231pd xmm13, xmm15, xmm14
000074da185d647d  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d6483  vptest xmm12, xmm12
000074da185d6488  jnz 0x000074DA185D7058
000074da185d648e  mov rax, [rsp+0xD0]
000074da185d6496  lea r14, [rax+0xB0]
000074da185d649d  movups xmm1, [r13+r14*1]
000074da185d64a3  vmovaps xmm15, [rsp+0xA0]
000074da185d64ac  vmovaps [rsp+0xA0], xmm13
000074da185d64b5  movaps xmm12, xmm15
000074da185d64b9  vfmadd231pd xmm12, xmm1, xmm14
000074da185d64be  vcmppd xmm13, xmm12, xmm12, 0x03
000074da185d64c4  vptest xmm13, xmm13
000074da185d64c9  jnz 0x000074DA185D71BB
000074da185d64cf  vmovaps xmm1, [rsp+0x30]
000074da185d64d5  vmovaps xmm15, [rsp+0x30]
000074da185d64db  por xmm1, xmm15
000074da185d64e0  movaps [r15+0x210], xmm1
000074da185d64e8  vmovaps xmm15, [rsp+0x70]
000074da185d64ee  vmovaps xmm14, [rsp+0x70]
000074da185d64f4  por xmm15, xmm14
000074da185d64f9  movaps [r15+0x1C0], xmm15
000074da185d6501  vmovaps xmm14, [rsp+0x60]
000074da185d6507  vmovaps xmm13, [rsp+0x60]
000074da185d650d  por xmm14, xmm13
000074da185d6512  movaps [r15+0x280], xmm14
000074da185d651a  vmovaps xmm13, [rsp+0x50]
000074da185d6520  vmovaps [rsp+0x30], xmm1
000074da185d6526  vmovaps xmm1, [rsp+0x50]
000074da185d652c  por xmm13, xmm1
000074da185d6531  movaps [r15+0x2A0], xmm13
000074da185d6539  vmovaps [rsp+0x50], xmm2
000074da185d653f  vmovaps xmm1, [rsp+0x50]
000074da185d6545  por xmm2, xmm1
000074da185d6549  movaps [r15+0x2E0], xmm2
000074da185d6551  vmovaps [rsp+0x50], xmm3
000074da185d6557  vmovaps xmm1, [rsp+0x50]
000074da185d655d  por xmm3, xmm1
000074da185d6561  movaps [r15+0x1F0], xmm3
000074da185d6569  vmovaps xmm1, [rsp+0x80]
000074da185d6572  vmovaps [rsp+0x50], xmm15
000074da185d6578  vmovaps xmm15, [rsp+0x80]
000074da185d6581  por xmm1, xmm15
000074da185d6586  movaps [r15+0x250], xmm1
000074da185d658e  vmovaps xmm1, [rsp+0xC0]
000074da185d6597  vmovaps xmm15, [rsp+0xC0]
000074da185d65a0  por xmm1, xmm15
000074da185d65a5  movaps [r15+0x260], xmm1
000074da185d65ad  vmovaps xmm15, [rsp+0x100]
000074da185d65b6  vmovaps [rsp+0x60], xmm1
000074da185d65bc  vmovaps xmm1, [rsp+0x100]
000074da185d65c5  por xmm15, xmm1
000074da185d65ca  movaps [r15+0x290], xmm15
000074da185d65d2  vmovaps xmm1, [rsp+0xF0]
000074da185d65db  vmovaps [rsp+0x70], xmm15
000074da185d65e1  vmovaps xmm15, [rsp+0xF0]
000074da185d65ea  por xmm1, xmm15
000074da185d65ef  movaps [r15+0x2C0], xmm1
000074da185d65f7  movq xmm15, qword ptr [r15+0x240]
000074da185d6600  vmovaps [rsp+0x80], xmm15
000074da185d6609  vpermilpd xmm15, xmm15, 0x00
000074da185d660f  vmovaps [rsp+0xC0], xmm1
000074da185d6618  vmovaps xmm1, [rsp+0x40]
000074da185d661e  vmovaps [rsp+0x40], xmm15
000074da185d6624  vmovaps xmm15, [rsp+0x30]
000074da185d662a  vmovaps [rsp+0x30], xmm14
000074da185d6630  vmovaps xmm14, [rsp+0x40]
000074da185d6636  vmovaps [rsp+0x40], xmm13
000074da185d663c  vmovaps [rsp+0xD0], xmm12
000074da185d6645  movaps xmm13, xmm1
000074da185d6649  vfmadd231pd xmm13, xmm15, xmm14
000074da185d664e  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d6654  vptest xmm12, xmm12
000074da185d6659  jnz 0x000074DA185D7314
000074da185d665f  vmovaps xmm1, [rsp+0x80]
000074da185d6668  vpermilpd xmm1, xmm1, 0x00
000074da185d666e  vmovaps xmm15, [rsp+0xA0]
000074da185d6677  movaps xmm14, xmm15
000074da185d667b  vfmadd231pd xmm14, xmm2, xmm1
000074da185d6680  vcmppd xmm12, xmm14, xmm14, 0x03
000074da185d6686  vptest xmm12, xmm12
000074da185d668b  jnz 0x000074DA185D746D
000074da185d6691  vmovaps xmm1, [rsp+0x80]
000074da185d669a  vpermilpd xmm1, xmm1, 0x00
000074da185d66a0  vmovaps xmm15, [rsp+0x120]
000074da185d66a9  vmovaps xmm12, [rsp+0x50]
000074da185d66af  vmovaps [rsp+0x50], xmm14
000074da185d66b5  movaps xmm2, xmm15
000074da185d66b9  vfmadd231pd xmm2, xmm12, xmm1
000074da185d66be  vcmppd xmm14, xmm2, xmm2, 0x03
000074da185d66c3  vptest xmm14, xmm14
000074da185d66c8  jnz 0x000074DA185D75C5
000074da185d66ce  vmovaps xmm1, [rsp+0x110]
000074da185d66d7  vmovaps xmm15, [rsp+0x110]
000074da185d66e0  por xmm1, xmm15
000074da185d66e5  movaps [r15+0x1D0], xmm1
000074da185d66ed  vmovaps xmm15, [rsp+0x80]
000074da185d66f6  vpermilpd xmm15, xmm15, 0x00
000074da185d66fc  vmovaps xmm14, [rsp+0xD0]
000074da185d6705  vmovaps [rsp+0x80], xmm1
000074da185d670e  movaps xmm12, xmm14
000074da185d6712  vfmadd231pd xmm12, xmm3, xmm15
000074da185d6717  vcmppd xmm1, xmm12, xmm12, 0x03
000074da185d671d  vptest xmm1, xmm1
000074da185d6722  jnz 0x000074DA185D771C
000074da185d6728  vmovaps [rsp+0xA0], xmm4
000074da185d6731  vmovaps xmm1, [rsp+0xA0]
000074da185d673a  por xmm4, xmm1
000074da185d673e  movaps [r15+0x200], xmm4
000074da185d6746  vmovaps xmm1, [rsp+0xE0]
000074da185d674f  vmovaps xmm15, [rsp+0xE0]
000074da185d6758  por xmm1, xmm15
000074da185d675d  movaps [r15+0x1E0], xmm1
000074da185d6765  vmovaps [rsp+0xA0], xmm8
000074da185d676e  vmovaps xmm1, [rsp+0xA0]
000074da185d6777  por xmm8, xmm1
000074da185d677c  movaps [r15+0x2B0], xmm8
000074da185d6784  vmovaps [rsp+0xA0], xmm9
000074da185d678d  vmovaps xmm1, [rsp+0xA0]
000074da185d6796  por xmm9, xmm1
000074da185d679b  movaps [r15+0x300], xmm9
000074da185d67a3  vmovaps [rsp+0xA0], xmm6
000074da185d67ac  vpermilpd xmm6, xmm6, 0x00
000074da185d67b2  vmovaps xmm14, [rsp+0x60]
000074da185d67b8  movaps xmm9, xmm13
000074da185d67bc  vfmadd231pd xmm9, xmm14, xmm6
000074da185d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
000074da185d67c7  vptest xmm3, xmm3
000074da185d67cc  jnz 0x000074DA185D7875
000074da185d67d2  vmovaps xmm14, [rsp+0xA0]
000074da185d67db  vpermilpd xmm14, xmm14, 0x00
000074da185d67e1  vmovaps xmm13, [rsp+0x50]
000074da185d67e7  vmovaps xmm6, [rsp+0xC0]
000074da185d67f0  vmovaps [rsp+0x50], xmm1
000074da185d67f6  movaps xmm3, xmm13
000074da185d67fa  vfmadd231pd xmm3, xmm6, xmm14
000074da185d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
000074da185d6804  vptest xmm1, xmm1
000074da185d6809  jnz 0x000074DA185D79CE
000074da185d680f  vmovaps xmm1, [rsp+0xA0]
000074da185d6818  vpermilpd xmm1, xmm1, 0x00
000074da185d681e  vmovaps xmm14, [rsp+0x30]
000074da185d6824  movaps xmm6, xmm2
000074da185d6827  vfmadd231pd xmm6, xmm14, xmm1
000074da185d682c  vcmppd xmm13, xmm6, xmm6, 0x03
000074da185d6831  vptest xmm13, xmm13
000074da185d6836  jnz 0x000074DA185D7B25
000074da185d683c  vmovaps xmm1, [rsp+0xA0]
000074da185d6845  vpermilpd xmm1, xmm1, 0x00
000074da185d684b  vmovaps xmm14, [rsp+0x80]
000074da185d6854  movaps xmm13, xmm12
000074da185d6858  vfmadd231pd xmm13, xmm14, xmm1
000074da185d685d  vcmppd xmm2, xmm13, xmm13, 0x03
000074da185d6863  vptest xmm2, xmm2
000074da185d6868  jnz 0x000074DA185D7C7B
000074da185d686e  vmovaps [rsp+0x30], xmm7
000074da185d6874  vmovaps xmm1, [rsp+0x30]
000074da185d687a  por xmm7, xmm1
000074da185d687e  movaps [r15+0x180], xmm7
000074da185d6886  vmovaps [rsp+0x30], xmm10
000074da185d688c  vmovaps xmm1, [rsp+0x30]
000074da185d6892  por xmm10, xmm1
000074da185d6897  movaps [r15+0x2D0], xmm10
000074da185d689f  vmovaps [rsp+0x30], xmm5
000074da185d68a5  vpermilpd xmm5, xmm5, 0x00
000074da185d68ab  vmovaps xmm14, [rsp+0x50]
000074da185d68b1  movaps xmm12, xmm3
000074da185d68b5  vfmadd231pd xmm12, xmm14, xmm5
000074da185d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
000074da185d68c0  vptest xmm10, xmm10
000074da185d68c5  jnz 0x000074DA185D7DD4
000074da185d68cb  vmovaps xmm14, [rsp+0x30]
000074da185d68d1  vpermilpd xmm14, xmm14, 0x00
000074da185d68d7  movaps xmm10, xmm9
000074da185d68db  vfmadd231pd xmm10, xmm7, xmm14
000074da185d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
000074da185d68e6  vptest xmm5, xmm5
000074da185d68eb  jnz 0x000074DA185D7F2C
000074da185d68f1  lea r14, [rax+0x80]
000074da185d68f8  movups xmm14, [r13+r14*1]
000074da185d68fe  movaps [r15+0x2F0], xmm14
000074da185d6906  vmovaps xmm9, [rsp+0x30]
000074da185d690c  vpermilpd xmm9, xmm9, 0x00
000074da185d6912  vmovaps xmm7, [rsp+0x70]
000074da185d6918  movaps xmm5, xmm6
000074da185d691b  vfmadd231pd xmm5, xmm7, xmm9
000074da185d6920  vcmppd xmm3, xmm5, xmm5, 0x03
000074da185d6925  vptest xmm3, xmm3
000074da185d692a  jnz 0x000074DA185D808F
000074da185d6930  vmovaps xmm9, [rsp+0x30]
000074da185d6936  vpermilpd xmm9, xmm9, 0x00
000074da185d693c  movaps xmm7, xmm13
000074da185d6940  vfmadd231pd xmm7, xmm1, xmm9
000074da185d6945  vcmppd xmm6, xmm7, xmm7, 0x03
000074da185d694a  vptest xmm6, xmm6
000074da185d694f  jnz 0x000074DA185D81E5
000074da185d6955  vmovaps xmm1, [rsp+0x20]
000074da185d695b  vmovaps xmm13, [rsp+0x20]
000074da185d6961  por xmm1, xmm13
000074da185d6966  movaps [r15+0x160], xmm1
000074da185d696e  lea r14, [rax+0x40]
000074da185d6972  movups xmm13, [r13+r14*1]
000074da185d6978  lea r14, [rax+0x50]
000074da185d697c  movups xmm9, [r13+r14*1]
000074da185d6982  movaps [r15+0x1B0], xmm13
000074da185d698a  movaps [r15+0x1A0], xmm9
000074da185d6992  movaps xmm6, [r15+0x190]
000074da185d699a  vmovaps xmm3, [rsp+0xB0]
000074da185d69a3  vpermilpd xmm3, xmm3, 0x00
000074da185d69a9  vmovaps [rsp+0x20], xmm1
000074da185d69af  movaps xmm2, xmm12
000074da185d69b3  vfmadd231pd xmm2, xmm6, xmm3
000074da185d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
000074da185d69bd  vptest xmm1, xmm1
000074da185d69c2  jnz 0x000074DA185D8350
000074da185d69c8  vmovaps xmm1, [rsp+0xB0]
000074da185d69d1  vpermilpd xmm1, xmm1, 0x00
000074da185d69d7  vmovaps xmm12, [rsp+0x20]
000074da185d69dd  movaps xmm6, xmm10
000074da185d69e1  vfmadd231pd xmm6, xmm12, xmm1
000074da185d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
000074da185d69eb  vptest xmm3, xmm3
000074da185d69f0  jnz 0x000074DA185D84A6
000074da185d69f6  vmovaps xmm1, [rsp+0xB0]
000074da185d69ff  vpermilpd xmm1, xmm1, 0x00
000074da185d6a05  vmovaps xmm12, [rsp+0x40]
000074da185d6a0b  movaps xmm10, xmm5
000074da185d6a0f  vfmadd231pd xmm10, xmm12, xmm1
000074da185d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
000074da185d6a1a  vptest xmm3, xmm3
000074da185d6a1f  jnz 0x000074DA185D85FD
000074da185d6a25  vmovaps xmm1, [rsp+0xB0]
000074da185d6a2e  vpermilpd xmm1, xmm1, 0x00
000074da185d6a34  movaps xmm12, xmm7
000074da185d6a38  vfmadd231pd xmm12, xmm15, xmm1
000074da185d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
000074da185d6a43  vptest xmm5, xmm5
000074da185d6a48  jnz 0x000074DA185D8755
000074da185d6a4e  lea r14, [rax+0x60]
000074da185d6a52  movups xmm1, [r13+r14*1]
000074da185d6a58  lea r14, [rax+0x70]
000074da185d6a5c  movups xmm15, [r13+r14*1]
000074da185d6a62  movaps [r15+0x150], xmm1
000074da185d6a6a  movaps [r15+0x120], xmm15
000074da185d6a72  vmovaps [rsp+0x20], xmm11
000074da185d6a78  vpermilpd xmm11, xmm11, 0x00
000074da185d6a7e  movaps xmm7, xmm2
000074da185d6a81  vfmadd231pd xmm7, xmm9, xmm11
000074da185d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
000074da185d6a8b  vptest xmm5, xmm5
000074da185d6a90  jnz 0x000074DA185D88C1
000074da185d6a96  vmovaps xmm11, [rsp+0x20]
000074da185d6a9c  vpermilpd xmm11, xmm11, 0x00
000074da185d6aa2  movaps xmm9, xmm6
000074da185d6aa6  vfmadd231pd xmm9, xmm1, xmm11
000074da185d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
000074da185d6ab1  vptest xmm5, xmm5
000074da185d6ab6  jnz 0x000074DA185D8A18
000074da185d6abc  vmovaps xmm1, [rsp+0x20]
000074da185d6ac2  vpermilpd xmm1, xmm1, 0x00
000074da185d6ac8  movaps xmm11, xmm10
000074da185d6acc  vfmadd231pd xmm11, xmm8, xmm1
000074da185d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
000074da185d6ad7  vptest xmm6, xmm6
000074da185d6adc  jnz 0x000074DA185D8B70
000074da185d6ae2  vmovaps xmm1, [rsp+0x20]
000074da185d6ae8  vpermilpd xmm1, xmm1, 0x00
000074da185d6aee  movaps xmm10, xmm12
000074da185d6af2  vfmadd231pd xmm10, xmm13, xmm1
000074da185d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
000074da185d6afd  vptest xmm8, xmm8
000074da185d6b02  jnz 0x000074DA185D8CC9
000074da185d6b08  lea r14, [rax+0x20]
000074da185d6b0c  movups xmm1, [r13+r14*1]
000074da185d6b12  lea r14, [rax+0x30]
000074da185d6b16  movups xmm13, [r13+r14*1]
000074da185d6b1c  vmovaps xmm12, [rsp+0x90]
000074da185d6b25  vpermilpd xmm12, xmm12, 0x00
000074da185d6b2b  movaps xmm8, xmm7
000074da185d6b2f  vfmadd231pd xmm8, xmm4, xmm12
000074da185d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
000074da185d6b3a  vptest xmm6, xmm6
000074da185d6b3f  jnz 0x000074DA185D8E36
000074da185d6b45  vmovaps xmm12, [rsp+0x90]
000074da185d6b4e  vpermilpd xmm12, xmm12, 0x00
000074da185d6b54  movaps xmm7, xmm9
000074da185d6b58  vfmadd231pd xmm7, xmm14, xmm12
000074da185d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
000074da185d6b62  vptest xmm6, xmm6
000074da185d6b67  jnz 0x000074DA185D8F8E
000074da185d6b6d  vmovaps xmm14, [rsp+0x90]
000074da185d6b76  vpermilpd xmm14, xmm14, 0x00
000074da185d6b7c  movaps xmm12, xmm11
000074da185d6b80  vfmadd231pd xmm12, xmm15, xmm14
000074da185d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
000074da185d6b8b  vptest xmm9, xmm9
000074da185d6b90  jnz 0x000074DA185D90E6
000074da185d6b96  vmovaps xmm15, [rsp+0x90]
000074da185d6b9f  vpermilpd xmm15, xmm15, 0x00
000074da185d6ba5  movaps xmm11, xmm10
000074da185d6ba9  vfmadd231pd xmm11, xmm13, xmm15
000074da185d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
000074da185d6bb4  vptest xmm14, xmm14
000074da185d6bb9  jnz 0x000074DA185D9240
000074da185d6bbf  lea r14, [rax+0x90]
000074da185d6bc6  movups xmm15, [r13+r14*1]
000074da185d6bcc  lea r14, [rax+0xA0]
000074da185d6bd3  movups xmm14, [r13+r14*1]
000074da185d6bd9  movaps [r15+0x140], xmm15
000074da185d6be1  movaps [r15+0x130], xmm14
000074da185d6be9  vmovaps xmm13, [rsp+0x10]
000074da185d6bef  vpermilpd xmm13, xmm13, 0x00
000074da185d6bf5  movaps xmm10, xmm8
000074da185d6bf9  vfmadd231pd xmm10, xmm1, xmm13
000074da185d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
000074da185d6c04  vptest xmm9, xmm9
000074da185d6c09  jnz 0x000074DA185D93AE
000074da185d6c0f  movaps [r15+0x220], xmm10
000074da185d6c17  lea r14, [rax+0x10]
000074da185d6c1b  movups xmm1, [r13+r14*1]
000074da185d6c21  movaps [r15+0x240], xmm1
000074da185d6c29  vmovaps xmm13, [rsp+0x10]
000074da185d6c2f  vpermilpd xmm13, xmm13, 0x00
000074da185d6c35  movaps xmm9, xmm7
000074da185d6c39  vfmadd231pd xmm9, xmm14, xmm13
000074da185d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
000074da185d6c44  vptest xmm8, xmm8
000074da185d6c49  jnz 0x000074DA185D9511
000074da185d6c4f  movaps [r15+0x110], xmm9
000074da185d6c57  vmovaps xmm14, [rsp+0x10]
000074da185d6c5d  vpermilpd xmm14, xmm14, 0x00
000074da185d6c63  movaps xmm13, xmm12
000074da185d6c67  vfmadd231pd xmm13, xmm15, xmm14
000074da185d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
000074da185d6c72  vptest xmm8, xmm8
000074da185d6c77  jnz 0x000074DA185D966A
000074da185d6c7d  movaps [r15+0x170], xmm13
000074da185d6c85  vmovaps xmm15, [rsp+0x10]
000074da185d6c8b  vpermilpd xmm15, xmm15, 0x00
000074da185d6c91  movaps xmm14, xmm11
000074da185d6c95  vfmadd231pd xmm14, xmm1, xmm15
000074da185d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
000074da185d6ca0  vptest xmm12, xmm12
000074da185d6ca5  jnz 0x000074DA185D97C4
000074da185d6cab  movaps [r15+0x230], xmm14
000074da185d6cb3  movups [r13+r11*1], xmm9
000074da185d6cb9  lea rax, [r11+0x10]
000074da185d6cbd  movups [r13+rax*1], xmm13
000074da185d6cc3  lea rax, [r11+0x20]
000074da185d6cc7  movups [r13+rax*1], xmm10
000074da185d6ccd  lea rax, [r11+0x30]
000074da185d6cd1  movups [r13+rax*1], xmm14
000074da185d6cd7  mov eax, [r15+0x108]
000074da185d6cde  sahf
000074da185d6cdf  jnz 0x000074DA185D6D11
000074da185d6ce1  cmp dword ptr [r15+0x318], 0x00
000074da185d6ce9  jz 0x000074DA185D9950
000074da185d6cef  nop [rax+rax*1], ax
000074da185d6cf8  nop [rax+rax*1], eax
000074da185d6d00  mov eax, 0x410664
000074da185d6d05  mov [r15+0x100], rax
000074da185d6d0c  jmp 0x000074DA183FE110
000074da185d6d11  cmp dword ptr [r15+0x318], 0x00
000074da185d6d19  jz 0x000074DA185D6050
000074da185d6d1f  nop [rax+rax*1], ax
000074da185d6d28  nop [rax+rax*1], eax
000074da185d6d30  mov eax, 0x4104F0
000074da185d6d35  mov [r15+0x100], rax
000074da185d6d3c  jmp 0x000074DA183FE110
000074da185d6d41  int3
000074da185d6d42  call 0x000074DA1840A4B0
000074da185d6d47  jmp 0x000074DA185D6079
000074da185d6d4c  call 0x000074DA18409240
000074da185d6d51  jmp 0x000074DA185D6083
000074da185d6d56  call 0x000074DA1840A4B0
000074da185d6d5b  jmp 0x000074DA185D60CD
000074da185d6d60  call 0x000074DA18409240
000074da185d6d65  jmp 0x000074DA185D60D7
000074da185d6d6a  call 0x000074DA1840A4B0
000074da185d6d6f  jmp 0x000074DA185D6158
000074da185d6d74  call 0x000074DA18409240
000074da185d6d79  jmp 0x000074DA185D6162
000074da185d6d7e  call 0x000074DA184B47C0
000074da185d6d83  jmp 0x000074DA185D6243
000074da185d6d88  call 0x000074DA183FF430
000074da185d6d8d  jmp 0x000074DA185D6272
000074da185d6d92  call 0x000074DA184B0CE0
000074da185d6d97  jmp 0x000074DA185D628E
000074da185d6d9c  sub rsp, 0x08
000074da185d6da0  push rax
000074da185d6da1  push rcx
000074da185d6da2  push rdx
000074da185d6da3  push rdi
000074da185d6da4  push rsi
000074da185d6da5  push r8
000074da185d6da7  push r9
000074da185d6da9  push r10
000074da185d6dab  push r11
000074da185d6dad  sub rsp, 0xF0
000074da185d6db4  vmovaps [rsp], xmm0
000074da185d6db9  vmovaps [rsp+0x10], xmm1
000074da185d6dbf  vmovaps [rsp+0x20], xmm2
000074da185d6dc5  vmovaps [rsp+0x30], xmm3
000074da185d6dcb  vmovaps [rsp+0x40], xmm4
000074da185d6dd1  vmovaps [rsp+0x50], xmm5
000074da185d6dd7  vmovaps [rsp+0x60], xmm6
000074da185d6ddd  vmovaps [rsp+0x70], xmm7
000074da185d6de3  vmovaps [rsp+0x80], xmm8
000074da185d6dec  vmovaps [rsp+0x90], xmm9
000074da185d6df5  vmovaps [rsp+0xA0], xmm10
000074da185d6dfe  vmovaps [rsp+0xB0], xmm11
000074da185d6e07  vmovaps [rsp+0xC0], xmm12
000074da185d6e10  vmovaps [rsp+0xD0], xmm14
000074da185d6e19  vmovaps [rsp+0xE0], xmm15
000074da185d6e22  sub rsp, 0x40
000074da185d6e26  lea rdi, [rsp]
000074da185d6e2a  lea rsi, [rsp+0x10]
000074da185d6e2f  lea rdx, [rsp+0x20]
000074da185d6e34  lea rcx, [rsp+0x30]
000074da185d6e39  mov r8d, 0x00
000074da185d6e3f  lea r9, [r15+0x3A8]
000074da185d6e46  movaps [rdi], xmm13
000074da185d6e4a  movaps [rsi], xmm1
000074da185d6e4d  movaps [rdx], xmm15
000074da185d6e51  movaps [rcx], xmm14
000074da185d6e55  mov rax, 0x5946061DFA50
000074da185d6e5f  call rax
000074da185d6e61  movaps xmm13, [rsp]
000074da185d6e66  add rsp, 0x40
000074da185d6e6a  vmovaps xmm0, [rsp]
000074da185d6e6f  vmovaps xmm1, [rsp+0x10]
000074da185d6e75  vmovaps xmm2, [rsp+0x20]
000074da185d6e7b  vmovaps xmm3, [rsp+0x30]
000074da185d6e81  vmovaps xmm4, [rsp+0x40]
000074da185d6e87  vmovaps xmm5, [rsp+0x50]
000074da185d6e8d  vmovaps xmm6, [rsp+0x60]
000074da185d6e93  vmovaps xmm7, [rsp+0x70]
000074da185d6e99  vmovaps xmm8, [rsp+0x80]
000074da185d6ea2  vmovaps xmm9, [rsp+0x90]
000074da185d6eab  vmovaps xmm10, [rsp+0xA0]
000074da185d6eb4  vmovaps xmm11, [rsp+0xB0]
000074da185d6ebd  vmovaps xmm12, [rsp+0xC0]
000074da185d6ec6  vmovaps xmm14, [rsp+0xD0]
000074da185d6ecf  vmovaps xmm15, [rsp+0xE0]
000074da185d6ed8  add rsp, 0xF0
000074da185d6edf  pop r11
000074da185d6ee1  pop r10
000074da185d6ee3  pop r9
000074da185d6ee5  pop r8
000074da185d6ee7  pop rsi
000074da185d6ee8  pop rdi
000074da185d6ee9  pop rdx
000074da185d6eea  pop rcx
000074da185d6eeb  pop rax
000074da185d6eec  add rsp, 0x08
000074da185d6ef0  jmp 0x000074DA185D6305
000074da185d6ef5  sub rsp, 0x08
000074da185d6ef9  push rax
000074da185d6efa  push rcx
000074da185d6efb  push rdx
000074da185d6efc  push rdi
000074da185d6efd  push rsi
000074da185d6efe  push r8
000074da185d6f00  push r9
000074da185d6f02  push r10
000074da185d6f04  push r11
000074da185d6f06  sub rsp, 0xF0
000074da185d6f0d  vmovaps [rsp], xmm0
000074da185d6f12  vmovaps [rsp+0x10], xmm1
000074da185d6f18  vmovaps [rsp+0x20], xmm2
000074da185d6f1e  vmovaps [rsp+0x30], xmm3
000074da185d6f24  vmovaps [rsp+0x40], xmm4
000074da185d6f2a  vmovaps [rsp+0x50], xmm5
000074da185d6f30  vmovaps [rsp+0x60], xmm6
000074da185d6f36  vmovaps [rsp+0x70], xmm7
000074da185d6f3c  vmovaps [rsp+0x80], xmm8
000074da185d6f45  vmovaps [rsp+0x90], xmm9
000074da185d6f4e  vmovaps [rsp+0xA0], xmm10
000074da185d6f57  vmovaps [rsp+0xB0], xmm11
000074da185d6f60  vmovaps [rsp+0xC0], xmm13
000074da185d6f69  vmovaps [rsp+0xD0], xmm14
000074da185d6f72  vmovaps [rsp+0xE0], xmm15
000074da185d6f7b  sub rsp, 0x40
000074da185d6f7f  lea rdi, [rsp]
000074da185d6f83  lea rsi, [rsp+0x10]
000074da185d6f88  lea rdx, [rsp+0x20]
000074da185d6f8d  lea rcx, [rsp+0x30]
000074da185d6f92  mov r8d, 0x00
000074da185d6f98  lea r9, [r15+0x3A8]
000074da185d6f9f  movaps [rdi], xmm12
000074da185d6fa3  movaps [rsi], xmm15
000074da185d6fa7  movaps [rdx], xmm1
000074da185d6faa  movaps [rcx], xmm14
000074da185d6fae  mov rax, 0x5946061DFA50
000074da185d6fb8  call rax
000074da185d6fba  movaps xmm12, [rsp]
000074da185d6fbf  add rsp, 0x40
000074da185d6fc3  vmovaps xmm0, [rsp]
000074da185d6fc8  vmovaps xmm1, [rsp+0x10]
000074da185d6fce  vmovaps xmm2, [rsp+0x20]
000074da185d6fd4  vmovaps xmm3, [rsp+0x30]
000074da185d6fda  vmovaps xmm4, [rsp+0x40]
000074da185d6fe0  vmovaps xmm5, [rsp+0x50]
000074da185d6fe6  vmovaps xmm6, [rsp+0x60]
000074da185d6fec  vmovaps xmm7, [rsp+0x70]
000074da185d6ff2  vmovaps xmm8, [rsp+0x80]
000074da185d6ffb  vmovaps xmm9, [rsp+0x90]
000074da185d7004  vmovaps xmm10, [rsp+0xA0]
000074da185d700d  vmovaps xmm11, [rsp+0xB0]
000074da185d7016  vmovaps xmm13, [rsp+0xC0]
000074da185d701f  vmovaps xmm14, [rsp+0xD0]
000074da185d7028  vmovaps xmm15, [rsp+0xE0]
000074da185d7031  add rsp, 0xF0
000074da185d7038  pop r11
000074da185d703a  pop r10
000074da185d703c  pop r9
000074da185d703e  pop r8
000074da185d7040  pop rsi
000074da185d7041  pop rdi
000074da185d7042  pop rdx
000074da185d7043  pop rcx
000074da185d7044  pop rax
000074da185d7045  add rsp, 0x08
000074da185d7049  jmp 0x000074DA185D6333
000074da185d704e  call 0x000074DA184D64F0
000074da185d7053  jmp 0x000074DA185D641F
000074da185d7058  sub rsp, 0x08
000074da185d705c  push rax
000074da185d705d  push rcx
000074da185d705e  push rdx
000074da185d705f  push rdi
000074da185d7060  push rsi
000074da185d7061  push r8
000074da185d7063  push r9
000074da185d7065  push r10
000074da185d7067  push r11
000074da185d7069  sub rsp, 0xF0
000074da185d7070  vmovaps [rsp], xmm0
000074da185d7075  vmovaps [rsp+0x10], xmm1
000074da185d707b  vmovaps [rsp+0x20], xmm2
000074da185d7081  vmovaps [rsp+0x30], xmm3
000074da185d7087  vmovaps [rsp+0x40], xmm4
000074da185d708d  vmovaps [rsp+0x50], xmm5
000074da185d7093  vmovaps [rsp+0x60], xmm6
000074da185d7099  vmovaps [rsp+0x70], xmm7
000074da185d709f  vmovaps [rsp+0x80], xmm8
000074da185d70a8  vmovaps [rsp+0x90], xmm9
000074da185d70b1  vmovaps [rsp+0xA0], xmm10
000074da185d70ba  vmovaps [rsp+0xB0], xmm11
000074da185d70c3  vmovaps [rsp+0xC0], xmm12
000074da185d70cc  vmovaps [rsp+0xD0], xmm14
000074da185d70d5  vmovaps [rsp+0xE0], xmm15
000074da185d70de  sub rsp, 0x40
000074da185d70e2  lea rdi, [rsp]
000074da185d70e6  lea rsi, [rsp+0x10]
000074da185d70eb  lea rdx, [rsp+0x20]
000074da185d70f0  lea rcx, [rsp+0x30]
000074da185d70f5  mov r8d, 0x00
000074da185d70fb  lea r9, [r15+0x3A8]
000074da185d7102  movaps [rdi], xmm13
000074da185d7106  movaps [rsi], xmm1
000074da185d7109  movaps [rdx], xmm15
000074da185d710d  movaps [rcx], xmm14
000074da185d7111  mov rax, 0x5946061DFA50
000074da185d711b  call rax
000074da185d711d  movaps xmm13, [rsp]
000074da185d7122  add rsp, 0x40
000074da185d7126  vmovaps xmm0, [rsp]
000074da185d712b  vmovaps xmm1, [rsp+0x10]
000074da185d7131  vmovaps xmm2, [rsp+0x20]
000074da185d7137  vmovaps xmm3, [rsp+0x30]
000074da185d713d  vmovaps xmm4, [rsp+0x40]
000074da185d7143  vmovaps xmm5, [rsp+0x50]
000074da185d7149  vmovaps xmm6, [rsp+0x60]
000074da185d714f  vmovaps xmm7, [rsp+0x70]
000074da185d7155  vmovaps xmm8, [rsp+0x80]
000074da185d715e  vmovaps xmm9, [rsp+0x90]
000074da185d7167  vmovaps xmm10, [rsp+0xA0]
000074da185d7170  vmovaps xmm11, [rsp+0xB0]
000074da185d7179  vmovaps xmm12, [rsp+0xC0]
000074da185d7182  vmovaps xmm14, [rsp+0xD0]
000074da185d718b  vmovaps xmm15, [rsp+0xE0]
000074da185d7194  add rsp, 0xF0
000074da185d719b  pop r11
000074da185d719d  pop r10
000074da185d719f  pop r9
000074da185d71a1  pop r8
000074da185d71a3  pop rsi
000074da185d71a4  pop rdi
000074da185d71a5  pop rdx
000074da185d71a6  pop rcx
000074da185d71a7  pop rax
000074da185d71a8  add rsp, 0x08
000074da185d71ac  jmp 0x000074DA185D648E
000074da185d71b1  call 0x000074DA184D64F0
000074da185d71b6  jmp 0x000074DA185D64A3
000074da185d71bb  sub rsp, 0x08
000074da185d71bf  push rax
000074da185d71c0  push rcx
000074da185d71c1  push rdx
000074da185d71c2  push rdi
000074da185d71c3  push rsi
000074da185d71c4  push r8
000074da185d71c6  push r9
000074da185d71c8  push r10
000074da185d71ca  push r11
000074da185d71cc  sub rsp, 0xF0
000074da185d71d3  vmovaps [rsp], xmm0
000074da185d71d8  vmovaps [rsp+0x10], xmm1
000074da185d71de  vmovaps [rsp+0x20], xmm2
000074da185d71e4  vmovaps [rsp+0x30], xmm3
000074da185d71ea  vmovaps [rsp+0x40], xmm4
000074da185d71f0  vmovaps [rsp+0x50], xmm5
000074da185d71f6  vmovaps [rsp+0x60], xmm6
000074da185d71fc  vmovaps [rsp+0x70], xmm7
000074da185d7202  vmovaps [rsp+0x80], xmm8
000074da185d720b  vmovaps [rsp+0x90], xmm9
000074da185d7214  vmovaps [rsp+0xA0], xmm10
000074da185d721d  vmovaps [rsp+0xB0], xmm11
000074da185d7226  vmovaps [rsp+0xC0], xmm13
000074da185d722f  vmovaps [rsp+0xD0], xmm14
000074da185d7238  vmovaps [rsp+0xE0], xmm15
000074da185d7241  sub rsp, 0x40
000074da185d7245  lea rdi, [rsp]
000074da185d7249  lea rsi, [rsp+0x10]
000074da185d724e  lea rdx, [rsp+0x20]
000074da185d7253  lea rcx, [rsp+0x30]
000074da185d7258  mov r8d, 0x00
000074da185d725e  lea r9, [r15+0x3A8]
000074da185d7265  movaps [rdi], xmm12
000074da185d7269  movaps [rsi], xmm15
000074da185d726d  movaps [rdx], xmm1
000074da185d7270  movaps [rcx], xmm14
000074da185d7274  mov rax, 0x5946061DFA50
000074da185d727e  call rax
000074da185d7280  movaps xmm12, [rsp]
000074da185d7285  add rsp, 0x40
000074da185d7289  vmovaps xmm0, [rsp]
000074da185d728e  vmovaps xmm1, [rsp+0x10]
000074da185d7294  vmovaps xmm2, [rsp+0x20]
000074da185d729a  vmovaps xmm3, [rsp+0x30]
000074da185d72a0  vmovaps xmm4, [rsp+0x40]
000074da185d72a6  vmovaps xmm5, [rsp+0x50]
000074da185d72ac  vmovaps xmm6, [rsp+0x60]
000074da185d72b2  vmovaps xmm7, [rsp+0x70]
000074da185d72b8  vmovaps xmm8, [rsp+0x80]
000074da185d72c1  vmovaps xmm9, [rsp+0x90]
000074da185d72ca  vmovaps xmm10, [rsp+0xA0]
000074da185d72d3  vmovaps xmm11, [rsp+0xB0]
000074da185d72dc  vmovaps xmm13, [rsp+0xC0]
000074da185d72e5  vmovaps xmm14, [rsp+0xD0]
000074da185d72ee  vmovaps xmm15, [rsp+0xE0]
000074da185d72f7  add rsp, 0xF0
000074da185d72fe  pop r11
000074da185d7300  pop r10
000074da185d7302  pop r9
000074da185d7304  pop r8
000074da185d7306  pop rsi
000074da185d7307  pop rdi
000074da185d7308  pop rdx
000074da185d7309  pop rcx
000074da185d730a  pop rax
000074da185d730b  add rsp, 0x08
000074da185d730f  jmp 0x000074DA185D64CF
000074da185d7314  sub rsp, 0x08
000074da185d7318  push rax
000074da185d7319  push rcx
000074da185d731a  push rdx
000074da185d731b  push rdi
000074da185d731c  push rsi
000074da185d731d  push r8
000074da185d731f  push r9
000074da185d7321  push r10
000074da185d7323  push r11
000074da185d7325  sub rsp, 0xF0
000074da185d732c  vmovaps [rsp], xmm0
000074da185d7331  vmovaps [rsp+0x10], xmm1
000074da185d7337  vmovaps [rsp+0x20], xmm2
000074da185d733d  vmovaps [rsp+0x30], xmm3
000074da185d7343  vmovaps [rsp+0x40], xmm4
000074da185d7349  vmovaps [rsp+0x50], xmm5
000074da185d734f  vmovaps [rsp+0x60], xmm6
000074da185d7355  vmovaps [rsp+0x70], xmm7
000074da185d735b  vmovaps [rsp+0x80], xmm8
000074da185d7364  vmovaps [rsp+0x90], xmm9
000074da185d736d  vmovaps [rsp+0xA0], xmm10
000074da185d7376  vmovaps [rsp+0xB0], xmm11
000074da185d737f  vmovaps [rsp+0xC0], xmm12
000074da185d7388  vmovaps [rsp+0xD0], xmm14
000074da185d7391  vmovaps [rsp+0xE0], xmm15
000074da185d739a  sub rsp, 0x40
000074da185d739e  lea rdi, [rsp]
000074da185d73a2  lea rsi, [rsp+0x10]
000074da185d73a7  lea rdx, [rsp+0x20]
000074da185d73ac  lea rcx, [rsp+0x30]
000074da185d73b1  mov r8d, 0x00
000074da185d73b7  lea r9, [r15+0x3A8]
000074da185d73be  movaps [rdi], xmm13
000074da185d73c2  movaps [rsi], xmm1
000074da185d73c5  movaps [rdx], xmm15
000074da185d73c9  movaps [rcx], xmm14
000074da185d73cd  mov rax, 0x5946061DFA50
000074da185d73d7  call rax
000074da185d73d9  movaps xmm13, [rsp]
000074da185d73de  add rsp, 0x40
000074da185d73e2  vmovaps xmm0, [rsp]
000074da185d73e7  vmovaps xmm1, [rsp+0x10]
000074da185d73ed  vmovaps xmm2, [rsp+0x20]
000074da185d73f3  vmovaps xmm3, [rsp+0x30]
000074da185d73f9  vmovaps xmm4, [rsp+0x40]
000074da185d73ff  vmovaps xmm5, [rsp+0x50]
000074da185d7405  vmovaps xmm6, [rsp+0x60]
000074da185d740b  vmovaps xmm7, [rsp+0x70]
000074da185d7411  vmovaps xmm8, [rsp+0x80]
000074da185d741a  vmovaps xmm9, [rsp+0x90]
000074da185d7423  vmovaps xmm10, [rsp+0xA0]
000074da185d742c  vmovaps xmm11, [rsp+0xB0]
000074da185d7435  vmovaps xmm12, [rsp+0xC0]
000074da185d743e  vmovaps xmm14, [rsp+0xD0]
000074da185d7447  vmovaps xmm15, [rsp+0xE0]
000074da185d7450  add rsp, 0xF0
000074da185d7457  pop r11
000074da185d7459  pop r10
000074da185d745b  pop r9
000074da185d745d  pop r8
000074da185d745f  pop rsi
000074da185d7460  pop rdi
000074da185d7461  pop rdx
000074da185d7462  pop rcx
000074da185d7463  pop rax
000074da185d7464  add rsp, 0x08
000074da185d7468  jmp 0x000074DA185D665F
000074da185d746d  sub rsp, 0x08
000074da185d7471  push rax
000074da185d7472  push rcx
000074da185d7473  push rdx
000074da185d7474  push rdi
000074da185d7475  push rsi
000074da185d7476  push r8
000074da185d7478  push r9
000074da185d747a  push r10
000074da185d747c  push r11
000074da185d747e  sub rsp, 0xF0
000074da185d7485  vmovaps [rsp], xmm0
000074da185d748a  vmovaps [rsp+0x10], xmm1
000074da185d7490  vmovaps [rsp+0x20], xmm2
000074da185d7496  vmovaps [rsp+0x30], xmm3
000074da185d749c  vmovaps [rsp+0x40], xmm4
000074da185d74a2  vmovaps [rsp+0x50], xmm5
000074da185d74a8  vmovaps [rsp+0x60], xmm6
000074da185d74ae  vmovaps [rsp+0x70], xmm7
000074da185d74b4  vmovaps [rsp+0x80], xmm8
000074da185d74bd  vmovaps [rsp+0x90], xmm9
000074da185d74c6  vmovaps [rsp+0xA0], xmm10
000074da185d74cf  vmovaps [rsp+0xB0], xmm11
000074da185d74d8  vmovaps [rsp+0xC0], xmm12
000074da185d74e1  vmovaps [rsp+0xD0], xmm13
000074da185d74ea  vmovaps [rsp+0xE0], xmm15
000074da185d74f3  sub rsp, 0x40
000074da185d74f7  lea rdi, [rsp]
000074da185d74fb  lea rsi, [rsp+0x10]
000074da185d7500  lea rdx, [rsp+0x20]
000074da185d7505  lea rcx, [rsp+0x30]
000074da185d750a  mov r8d, 0x00
000074da185d7510  lea r9, [r15+0x3A8]
000074da185d7517  movaps [rdi], xmm14
000074da185d751b  movaps [rsi], xmm15
000074da185d751f  movaps [rdx], xmm2
000074da185d7522  movaps [rcx], xmm1
000074da185d7525  mov rax, 0x5946061DFA50
000074da185d752f  call rax
000074da185d7531  movaps xmm14, [rsp]
000074da185d7536  add rsp, 0x40
000074da185d753a  vmovaps xmm0, [rsp]
000074da185d753f  vmovaps xmm1, [rsp+0x10]
000074da185d7545  vmovaps xmm2, [rsp+0x20]
000074da185d754b  vmovaps xmm3, [rsp+0x30]
000074da185d7551  vmovaps xmm4, [rsp+0x40]
000074da185d7557  vmovaps xmm5, [rsp+0x50]
000074da185d755d  vmovaps xmm6, [rsp+0x60]
000074da185d7563  vmovaps xmm7, [rsp+0x70]
000074da185d7569  vmovaps xmm8, [rsp+0x80]
000074da185d7572  vmovaps xmm9, [rsp+0x90]
000074da185d757b  vmovaps xmm10, [rsp+0xA0]
000074da185d7584  vmovaps xmm11, [rsp+0xB0]
000074da185d758d  vmovaps xmm12, [rsp+0xC0]
000074da185d7596  vmovaps xmm13, [rsp+0xD0]
000074da185d759f  vmovaps xmm15, [rsp+0xE0]
000074da185d75a8  add rsp, 0xF0
000074da185d75af  pop r11
000074da185d75b1  pop r10
000074da185d75b3  pop r9
000074da185d75b5  pop r8
000074da185d75b7  pop rsi
000074da185d75b8  pop rdi
000074da185d75b9  pop rdx
000074da185d75ba  pop rcx
000074da185d75bb  pop rax
000074da185d75bc  add rsp, 0x08
000074da185d75c0  jmp 0x000074DA185D6691
000074da185d75c5  sub rsp, 0x08
000074da185d75c9  push rax
000074da185d75ca  push rcx
000074da185d75cb  push rdx
000074da185d75cc  push rdi
000074da185d75cd  push rsi
000074da185d75ce  push r8
000074da185d75d0  push r9
000074da185d75d2  push r10
000074da185d75d4  push r11
000074da185d75d6  sub rsp, 0xF0
000074da185d75dd  vmovaps [rsp], xmm0
000074da185d75e2  vmovaps [rsp+0x10], xmm1
000074da185d75e8  vmovaps [rsp+0x20], xmm3
000074da185d75ee  vmovaps [rsp+0x30], xmm4
000074da185d75f4  vmovaps [rsp+0x40], xmm5
000074da185d75fa  vmovaps [rsp+0x50], xmm6
000074da185d7600  vmovaps [rsp+0x60], xmm7
000074da185d7606  vmovaps [rsp+0x70], xmm8
000074da185d760c  vmovaps [rsp+0x80], xmm9
000074da185d7615  vmovaps [rsp+0x90], xmm10
000074da185d761e  vmovaps [rsp+0xA0], xmm11
000074da185d7627  vmovaps [rsp+0xB0], xmm12
000074da185d7630  vmovaps [rsp+0xC0], xmm13
000074da185d7639  vmovaps [rsp+0xD0], xmm14
000074da185d7642  vmovaps [rsp+0xE0], xmm15
000074da185d764b  sub rsp, 0x40
000074da185d764f  lea rdi, [rsp]
000074da185d7653  lea rsi, [rsp+0x10]
000074da185d7658  lea rdx, [rsp+0x20]
000074da185d765d  lea rcx, [rsp+0x30]
000074da185d7662  mov r8d, 0x00
000074da185d7668  lea r9, [r15+0x3A8]
000074da185d766f  movaps [rdi], xmm2
000074da185d7672  movaps [rsi], xmm15
000074da185d7676  movaps [rdx], xmm12
000074da185d767a  movaps [rcx], xmm1
000074da185d767d  mov rax, 0x5946061DFA50
000074da185d7687  call rax
000074da185d7689  movaps xmm2, [rsp]
000074da185d768d  add rsp, 0x40
000074da185d7691  vmovaps xmm0, [rsp]
000074da185d7696  vmovaps xmm1, [rsp+0x10]
000074da185d769c  vmovaps xmm3, [rsp+0x20]
000074da185d76a2  vmovaps xmm4, [rsp+0x30]
000074da185d76a8  vmovaps xmm5, [rsp+0x40]
000074da185d76ae  vmovaps xmm6, [rsp+0x50]
000074da185d76b4  vmovaps xmm7, [rsp+0x60]
000074da185d76ba  vmovaps xmm8, [rsp+0x70]
000074da185d76c0  vmovaps xmm9, [rsp+0x80]
000074da185d76c9  vmovaps xmm10, [rsp+0x90]
000074da185d76d2  vmovaps xmm11, [rsp+0xA0]
000074da185d76db  vmovaps xmm12, [rsp+0xB0]
000074da185d76e4  vmovaps xmm13, [rsp+0xC0]
000074da185d76ed  vmovaps xmm14, [rsp+0xD0]
000074da185d76f6  vmovaps xmm15, [rsp+0xE0]
000074da185d76ff  add rsp, 0xF0
000074da185d7706  pop r11
000074da185d7708  pop r10
000074da185d770a  pop r9
000074da185d770c  pop r8
000074da185d770e  pop rsi
000074da185d770f  pop rdi
000074da185d7710  pop rdx
000074da185d7711  pop rcx
000074da185d7712  pop rax
000074da185d7713  add rsp, 0x08
000074da185d7717  jmp 0x000074DA185D66CE
000074da185d771c  sub rsp, 0x08
000074da185d7720  push rax
000074da185d7721  push rcx
000074da185d7722  push rdx
000074da185d7723  push rdi
000074da185d7724  push rsi
000074da185d7725  push r8
000074da185d7727  push r9
000074da185d7729  push r10
000074da185d772b  push r11
000074da185d772d  sub rsp, 0xF0
000074da185d7734  vmovaps [rsp], xmm0
000074da185d7739  vmovaps [rsp+0x10], xmm1
000074da185d773f  vmovaps [rsp+0x20], xmm2
000074da185d7745  vmovaps [rsp+0x30], xmm3
000074da185d774b  vmovaps [rsp+0x40], xmm4
000074da185d7751  vmovaps [rsp+0x50], xmm5
000074da185d7757  vmovaps [rsp+0x60], xmm6
000074da185d775d  vmovaps [rsp+0x70], xmm7
000074da185d7763  vmovaps [rsp+0x80], xmm8
000074da185d776c  vmovaps [rsp+0x90], xmm9
000074da185d7775  vmovaps [rsp+0xA0], xmm10
000074da185d777e  vmovaps [rsp+0xB0], xmm11
000074da185d7787  vmovaps [rsp+0xC0], xmm13
000074da185d7790  vmovaps [rsp+0xD0], xmm14
000074da185d7799  vmovaps [rsp+0xE0], xmm15
000074da185d77a2  sub rsp, 0x40
000074da185d77a6  lea rdi, [rsp]
000074da185d77aa  lea rsi, [rsp+0x10]
000074da185d77af  lea rdx, [rsp+0x20]
000074da185d77b4  lea rcx, [rsp+0x30]
000074da185d77b9  mov r8d, 0x00
000074da185d77bf  lea r9, [r15+0x3A8]
000074da185d77c6  movaps [rdi], xmm12
000074da185d77ca  movaps [rsi], xmm14
000074da185d77ce  movaps [rdx], xmm3
000074da185d77d1  movaps [rcx], xmm15
000074da185d77d5  mov rax, 0x5946061DFA50
000074da185d77df  call rax
000074da185d77e1  movaps xmm12, [rsp]
000074da185d77e6  add rsp, 0x40
000074da185d77ea  vmovaps xmm0, [rsp]
000074da185d77ef  vmovaps xmm1, [rsp+0x10]
000074da185d77f5  vmovaps xmm2, [rsp+0x20]
000074da185d77fb  vmovaps xmm3, [rsp+0x30]
000074da185d7801  vmovaps xmm4, [rsp+0x40]
000074da185d7807  vmovaps xmm5, [rsp+0x50]
000074da185d780d  vmovaps xmm6, [rsp+0x60]
000074da185d7813  vmovaps xmm7, [rsp+0x70]
000074da185d7819  vmovaps xmm8, [rsp+0x80]
000074da185d7822  vmovaps xmm9, [rsp+0x90]
000074da185d782b  vmovaps xmm10, [rsp+0xA0]
000074da185d7834  vmovaps xmm11, [rsp+0xB0]
000074da185d783d  vmovaps xmm13, [rsp+0xC0]
000074da185d7846  vmovaps xmm14, [rsp+0xD0]
000074da185d784f  vmovaps xmm15, [rsp+0xE0]
000074da185d7858  add rsp, 0xF0
000074da185d785f  pop r11
000074da185d7861  pop r10
000074da185d7863  pop r9
000074da185d7865  pop r8
000074da185d7867  pop rsi
000074da185d7868  pop rdi
000074da185d7869  pop rdx
000074da185d786a  pop rcx
000074da185d786b  pop rax
000074da185d786c  add rsp, 0x08
000074da185d7870  jmp 0x000074DA185D6728
000074da185d7875  sub rsp, 0x08
000074da185d7879  push rax
000074da185d787a  push rcx
000074da185d787b  push rdx
000074da185d787c  push rdi
000074da185d787d  push rsi
000074da185d787e  push r8
000074da185d7880  push r9
000074da185d7882  push r10
000074da185d7884  push r11
000074da185d7886  sub rsp, 0xF0
000074da185d788d  vmovaps [rsp], xmm0
000074da185d7892  vmovaps [rsp+0x10], xmm1
000074da185d7898  vmovaps [rsp+0x20], xmm2
000074da185d789e  vmovaps [rsp+0x30], xmm3
000074da185d78a4  vmovaps [rsp+0x40], xmm4
000074da185d78aa  vmovaps [rsp+0x50], xmm5
000074da185d78b0  vmovaps [rsp+0x60], xmm6
000074da185d78b6  vmovaps [rsp+0x70], xmm7
000074da185d78bc  vmovaps [rsp+0x80], xmm8
000074da185d78c5  vmovaps [rsp+0x90], xmm10
000074da185d78ce  vmovaps [rsp+0xA0], xmm11
000074da185d78d7  vmovaps [rsp+0xB0], xmm12
000074da185d78e0  vmovaps [rsp+0xC0], xmm13
000074da185d78e9  vmovaps [rsp+0xD0], xmm14
000074da185d78f2  vmovaps [rsp+0xE0], xmm15
000074da185d78fb  sub rsp, 0x40
000074da185d78ff  lea rdi, [rsp]
000074da185d7903  lea rsi, [rsp+0x10]
000074da185d7908  lea rdx, [rsp+0x20]
000074da185d790d  lea rcx, [rsp+0x30]
000074da185d7912  mov r8d, 0x00
000074da185d7918  lea r9, [r15+0x3A8]
000074da185d791f  movaps [rdi], xmm9
000074da185d7923  movaps [rsi], xmm13
000074da185d7927  movaps [rdx], xmm14
000074da185d792b  movaps [rcx], xmm6
000074da185d792e  mov rax, 0x5946061DFA50
000074da185d7938  call rax
000074da185d793a  movaps xmm9, [rsp]
000074da185d793f  add rsp, 0x40
000074da185d7943  vmovaps xmm0, [rsp]
000074da185d7948  vmovaps xmm1, [rsp+0x10]
000074da185d794e  vmovaps xmm2, [rsp+0x20]
000074da185d7954  vmovaps xmm3, [rsp+0x30]
000074da185d795a  vmovaps xmm4, [rsp+0x40]
000074da185d7960  vmovaps xmm5, [rsp+0x50]
000074da185d7966  vmovaps xmm6, [rsp+0x60]
000074da185d796c  vmovaps xmm7, [rsp+0x70]
000074da185d7972  vmovaps xmm8, [rsp+0x80]
000074da185d797b  vmovaps xmm10, [rsp+0x90]
000074da185d7984  vmovaps xmm11, [rsp+0xA0]
000074da185d798d  vmovaps xmm12, [rsp+0xB0]
000074da185d7996  vmovaps xmm13, [rsp+0xC0]
000074da185d799f  vmovaps xmm14, [rsp+0xD0]
000074da185d79a8  vmovaps xmm15, [rsp+0xE0]
000074da185d79b1  add rsp, 0xF0
000074da185d79b8  pop r11
000074da185d79ba  pop r10
000074da185d79bc  pop r9
000074da185d79be  pop r8
000074da185d79c0  pop rsi
000074da185d79c1  pop rdi
000074da185d79c2  pop rdx
000074da185d79c3  pop rcx
000074da185d79c4  pop rax
000074da185d79c5  add rsp, 0x08
000074da185d79c9  jmp 0x000074DA185D67D2
000074da185d79ce  sub rsp, 0x08
000074da185d79d2  push rax
000074da185d79d3  push rcx
000074da185d79d4  push rdx
000074da185d79d5  push rdi
000074da185d79d6  push rsi
000074da185d79d7  push r8
000074da185d79d9  push r9
000074da185d79db  push r10
000074da185d79dd  push r11
000074da185d79df  sub rsp, 0xF0
000074da185d79e6  vmovaps [rsp], xmm0
000074da185d79eb  vmovaps [rsp+0x10], xmm1
000074da185d79f1  vmovaps [rsp+0x20], xmm2
000074da185d79f7  vmovaps [rsp+0x30], xmm4
000074da185d79fd  vmovaps [rsp+0x40], xmm5
000074da185d7a03  vmovaps [rsp+0x50], xmm6
000074da185d7a09  vmovaps [rsp+0x60], xmm7
000074da185d7a0f  vmovaps [rsp+0x70], xmm8
000074da185d7a15  vmovaps [rsp+0x80], xmm9
000074da185d7a1e  vmovaps [rsp+0x90], xmm10
000074da185d7a27  vmovaps [rsp+0xA0], xmm11
000074da185d7a30  vmovaps [rsp+0xB0], xmm12
000074da185d7a39  vmovaps [rsp+0xC0], xmm13
000074da185d7a42  vmovaps [rsp+0xD0], xmm14
000074da185d7a4b  vmovaps [rsp+0xE0], xmm15
000074da185d7a54  sub rsp, 0x40
000074da185d7a58  lea rdi, [rsp]
000074da185d7a5c  lea rsi, [rsp+0x10]
000074da185d7a61  lea rdx, [rsp+0x20]
000074da185d7a66  lea rcx, [rsp+0x30]
000074da185d7a6b  mov r8d, 0x00
000074da185d7a71  lea r9, [r15+0x3A8]
000074da185d7a78  movaps [rdi], xmm3
000074da185d7a7b  movaps [rsi], xmm13
000074da185d7a7f  movaps [rdx], xmm6
000074da185d7a82  movaps [rcx], xmm14
000074da185d7a86  mov rax, 0x5946061DFA50
000074da185d7a90  call rax
000074da185d7a92  movaps xmm3, [rsp]
000074da185d7a96  add rsp, 0x40
000074da185d7a9a  vmovaps xmm0, [rsp]
000074da185d7a9f  vmovaps xmm1, [rsp+0x10]
000074da185d7aa5  vmovaps xmm2, [rsp+0x20]
000074da185d7aab  vmovaps xmm4, [rsp+0x30]
000074da185d7ab1  vmovaps xmm5, [rsp+0x40]
000074da185d7ab7  vmovaps xmm6, [rsp+0x50]
000074da185d7abd  vmovaps xmm7, [rsp+0x60]
000074da185d7ac3  vmovaps xmm8, [rsp+0x70]
000074da185d7ac9  vmovaps xmm9, [rsp+0x80]
000074da185d7ad2  vmovaps xmm10, [rsp+0x90]
000074da185d7adb  vmovaps xmm11, [rsp+0xA0]
000074da185d7ae4  vmovaps xmm12, [rsp+0xB0]
000074da185d7aed  vmovaps xmm13, [rsp+0xC0]
000074da185d7af6  vmovaps xmm14, [rsp+0xD0]
000074da185d7aff  vmovaps xmm15, [rsp+0xE0]
000074da185d7b08  add rsp, 0xF0
000074da185d7b0f  pop r11
000074da185d7b11  pop r10
000074da185d7b13  pop r9
000074da185d7b15  pop r8
000074da185d7b17  pop rsi
000074da185d7b18  pop rdi
000074da185d7b19  pop rdx
000074da185d7b1a  pop rcx
000074da185d7b1b  pop rax
000074da185d7b1c  add rsp, 0x08
000074da185d7b20  jmp 0x000074DA185D680F
000074da185d7b25  sub rsp, 0x08
000074da185d7b29  push rax
000074da185d7b2a  push rcx
000074da185d7b2b  push rdx
000074da185d7b2c  push rdi
000074da185d7b2d  push rsi
000074da185d7b2e  push r8
000074da185d7b30  push r9
000074da185d7b32  push r10
000074da185d7b34  push r11
000074da185d7b36  sub rsp, 0xF0
000074da185d7b3d  vmovaps [rsp], xmm0
000074da185d7b42  vmovaps [rsp+0x10], xmm1
000074da185d7b48  vmovaps [rsp+0x20], xmm2
000074da185d7b4e  vmovaps [rsp+0x30], xmm3
000074da185d7b54  vmovaps [rsp+0x40], xmm4
000074da185d7b5a  vmovaps [rsp+0x50], xmm5
000074da185d7b60  vmovaps [rsp+0x60], xmm7
000074da185d7b66  vmovaps [rsp+0x70], xmm8
000074da185d7b6c  vmovaps [rsp+0x80], xmm9
000074da185d7b75  vmovaps [rsp+0x90], xmm10
000074da185d7b7e  vmovaps [rsp+0xA0], xmm11
000074da185d7b87  vmovaps [rsp+0xB0], xmm12
000074da185d7b90  vmovaps [rsp+0xC0], xmm13
000074da185d7b99  vmovaps [rsp+0xD0], xmm14
000074da185d7ba2  vmovaps [rsp+0xE0], xmm15
000074da185d7bab  sub rsp, 0x40
000074da185d7baf  lea rdi, [rsp]
000074da185d7bb3  lea rsi, [rsp+0x10]
000074da185d7bb8  lea rdx, [rsp+0x20]
000074da185d7bbd  lea rcx, [rsp+0x30]
000074da185d7bc2  mov r8d, 0x00
000074da185d7bc8  lea r9, [r15+0x3A8]
000074da185d7bcf  movaps [rdi], xmm6
000074da185d7bd2  movaps [rsi], xmm2
000074da185d7bd5  movaps [rdx], xmm14
000074da185d7bd9  movaps [rcx], xmm1
000074da185d7bdc  mov rax, 0x5946061DFA50
000074da185d7be6  call rax
000074da185d7be8  movaps xmm6, [rsp]
000074da185d7bec  add rsp, 0x40
000074da185d7bf0  vmovaps xmm0, [rsp]
000074da185d7bf5  vmovaps xmm1, [rsp+0x10]
000074da185d7bfb  vmovaps xmm2, [rsp+0x20]
000074da185d7c01  vmovaps xmm3, [rsp+0x30]
000074da185d7c07  vmovaps xmm4, [rsp+0x40]
000074da185d7c0d  vmovaps xmm5, [rsp+0x50]
000074da185d7c13  vmovaps xmm7, [rsp+0x60]
000074da185d7c19  vmovaps xmm8, [rsp+0x70]
000074da185d7c1f  vmovaps xmm9, [rsp+0x80]
000074da185d7c28  vmovaps xmm10, [rsp+0x90]
000074da185d7c31  vmovaps xmm11, [rsp+0xA0]
000074da185d7c3a  vmovaps xmm12, [rsp+0xB0]
000074da185d7c43  vmovaps xmm13, [rsp+0xC0]
000074da185d7c4c  vmovaps xmm14, [rsp+0xD0]
000074da185d7c55  vmovaps xmm15, [rsp+0xE0]
000074da185d7c5e  add rsp, 0xF0
000074da185d7c65  pop r11
000074da185d7c67  pop r10
000074da185d7c69  pop r9
000074da185d7c6b  pop r8
000074da185d7c6d  pop rsi
000074da185d7c6e  pop rdi
000074da185d7c6f  pop rdx
000074da185d7c70  pop rcx
000074da185d7c71  pop rax
000074da185d7c72  add rsp, 0x08
000074da185d7c76  jmp 0x000074DA185D683C
000074da185d7c7b  sub rsp, 0x08
000074da185d7c7f  push rax
000074da185d7c80  push rcx
000074da185d7c81  push rdx
000074da185d7c82  push rdi
000074da185d7c83  push rsi
000074da185d7c84  push r8
000074da185d7c86  push r9
000074da185d7c88  push r10
000074da185d7c8a  push r11
000074da185d7c8c  sub rsp, 0xF0
000074da185d7c93  vmovaps [rsp], xmm0
000074da185d7c98  vmovaps [rsp+0x10], xmm1
000074da185d7c9e  vmovaps [rsp+0x20], xmm2
000074da185d7ca4  vmovaps [rsp+0x30], xmm3
000074da185d7caa  vmovaps [rsp+0x40], xmm4
000074da185d7cb0  vmovaps [rsp+0x50], xmm5
000074da185d7cb6  vmovaps [rsp+0x60], xmm6
000074da185d7cbc  vmovaps [rsp+0x70], xmm7
000074da185d7cc2  vmovaps [rsp+0x80], xmm8
000074da185d7ccb  vmovaps [rsp+0x90], xmm9
000074da185d7cd4  vmovaps [rsp+0xA0], xmm10
000074da185d7cdd  vmovaps [rsp+0xB0], xmm11
000074da185d7ce6  vmovaps [rsp+0xC0], xmm12
000074da185d7cef  vmovaps [rsp+0xD0], xmm14
000074da185d7cf8  vmovaps [rsp+0xE0], xmm15
000074da185d7d01  sub rsp, 0x40
000074da185d7d05  lea rdi, [rsp]
000074da185d7d09  lea rsi, [rsp+0x10]
000074da185d7d0e  lea rdx, [rsp+0x20]
000074da185d7d13  lea rcx, [rsp+0x30]
000074da185d7d18  mov r8d, 0x00
000074da185d7d1e  lea r9, [r15+0x3A8]
000074da185d7d25  movaps [rdi], xmm13
000074da185d7d29  movaps [rsi], xmm12
000074da185d7d2d  movaps [rdx], xmm14
000074da185d7d31  movaps [rcx], xmm1
000074da185d7d34  mov rax, 0x5946061DFA50
000074da185d7d3e  call rax
000074da185d7d40  movaps xmm13, [rsp]
000074da185d7d45  add rsp, 0x40
000074da185d7d49  vmovaps xmm0, [rsp]
000074da185d7d4e  vmovaps xmm1, [rsp+0x10]
000074da185d7d54  vmovaps xmm2, [rsp+0x20]
000074da185d7d5a  vmovaps xmm3, [rsp+0x30]
000074da185d7d60  vmovaps xmm4, [rsp+0x40]
000074da185d7d66  vmovaps xmm5, [rsp+0x50]
000074da185d7d6c  vmovaps xmm6, [rsp+0x60]
000074da185d7d72  vmovaps xmm7, [rsp+0x70]
000074da185d7d78  vmovaps xmm8, [rsp+0x80]
000074da185d7d81  vmovaps xmm9, [rsp+0x90]
000074da185d7d8a  vmovaps xmm10, [rsp+0xA0]
000074da185d7d93  vmovaps xmm11, [rsp+0xB0]
000074da185d7d9c  vmovaps xmm12, [rsp+0xC0]
000074da185d7da5  vmovaps xmm14, [rsp+0xD0]
000074da185d7dae  vmovaps xmm15, [rsp+0xE0]
000074da185d7db7  add rsp, 0xF0
000074da185d7dbe  pop r11
000074da185d7dc0  pop r10
000074da185d7dc2  pop r9
000074da185d7dc4  pop r8
000074da185d7dc6  pop rsi
000074da185d7dc7  pop rdi
000074da185d7dc8  pop rdx
000074da185d7dc9  pop rcx
000074da185d7dca  pop rax
000074da185d7dcb  add rsp, 0x08
000074da185d7dcf  jmp 0x000074DA185D686E
000074da185d7dd4  sub rsp, 0x08
000074da185d7dd8  push rax
000074da185d7dd9  push rcx
000074da185d7dda  push rdx
000074da185d7ddb  push rdi
000074da185d7ddc  push rsi
000074da185d7ddd  push r8
000074da185d7ddf  push r9
000074da185d7de1  push r10
000074da185d7de3  push r11
000074da185d7de5  sub rsp, 0xF0
000074da185d7dec  vmovaps [rsp], xmm0
000074da185d7df1  vmovaps [rsp+0x10], xmm1
000074da185d7df7  vmovaps [rsp+0x20], xmm2
000074da185d7dfd  vmovaps [rsp+0x30], xmm3
000074da185d7e03  vmovaps [rsp+0x40], xmm4
000074da185d7e09  vmovaps [rsp+0x50], xmm5
000074da185d7e0f  vmovaps [rsp+0x60], xmm6
000074da185d7e15  vmovaps [rsp+0x70], xmm7
000074da185d7e1b  vmovaps [rsp+0x80], xmm8
000074da185d7e24  vmovaps [rsp+0x90], xmm9
000074da185d7e2d  vmovaps [rsp+0xA0], xmm10
000074da185d7e36  vmovaps [rsp+0xB0], xmm11
000074da185d7e3f  vmovaps [rsp+0xC0], xmm13
000074da185d7e48  vmovaps [rsp+0xD0], xmm14
000074da185d7e51  vmovaps [rsp+0xE0], xmm15
000074da185d7e5a  sub rsp, 0x40
000074da185d7e5e  lea rdi, [rsp]
000074da185d7e62  lea rsi, [rsp+0x10]
000074da185d7e67  lea rdx, [rsp+0x20]
000074da185d7e6c  lea rcx, [rsp+0x30]
000074da185d7e71  mov r8d, 0x00
000074da185d7e77  lea r9, [r15+0x3A8]
000074da185d7e7e  movaps [rdi], xmm12
000074da185d7e82  movaps [rsi], xmm3
000074da185d7e85  movaps [rdx], xmm14
000074da185d7e89  movaps [rcx], xmm5
000074da185d7e8c  mov rax, 0x5946061DFA50
000074da185d7e96  call rax
000074da185d7e98  movaps xmm12, [rsp]
000074da185d7e9d  add rsp, 0x40
000074da185d7ea1  vmovaps xmm0, [rsp]
000074da185d7ea6  vmovaps xmm1, [rsp+0x10]
000074da185d7eac  vmovaps xmm2, [rsp+0x20]
000074da185d7eb2  vmovaps xmm3, [rsp+0x30]
000074da185d7eb8  vmovaps xmm4, [rsp+0x40]
000074da185d7ebe  vmovaps xmm5, [rsp+0x50]
000074da185d7ec4  vmovaps xmm6, [rsp+0x60]
000074da185d7eca  vmovaps xmm7, [rsp+0x70]
000074da185d7ed0  vmovaps xmm8, [rsp+0x80]
000074da185d7ed9  vmovaps xmm9, [rsp+0x90]
000074da185d7ee2  vmovaps xmm10, [rsp+0xA0]
000074da185d7eeb  vmovaps xmm11, [rsp+0xB0]
000074da185d7ef4  vmovaps xmm13, [rsp+0xC0]
000074da185d7efd  vmovaps xmm14, [rsp+0xD0]
000074da185d7f06  vmovaps xmm15, [rsp+0xE0]
000074da185d7f0f  add rsp, 0xF0
000074da185d7f16  pop r11
000074da185d7f18  pop r10
000074da185d7f1a  pop r9
000074da185d7f1c  pop r8
000074da185d7f1e  pop rsi
000074da185d7f1f  pop rdi
000074da185d7f20  pop rdx
000074da185d7f21  pop rcx
000074da185d7f22  pop rax
000074da185d7f23  add rsp, 0x08
000074da185d7f27  jmp 0x000074DA185D68CB
000074da185d7f2c  sub rsp, 0x08
000074da185d7f30  push rax
000074da185d7f31  push rcx
000074da185d7f32  push rdx
000074da185d7f33  push rdi
000074da185d7f34  push rsi
000074da185d7f35  push r8
000074da185d7f37  push r9
000074da185d7f39  push r10
000074da185d7f3b  push r11
000074da185d7f3d  sub rsp, 0xF0
000074da185d7f44  vmovaps [rsp], xmm0
000074da185d7f49  vmovaps [rsp+0x10], xmm1
000074da185d7f4f  vmovaps [rsp+0x20], xmm2
000074da185d7f55  vmovaps [rsp+0x30], xmm3
000074da185d7f5b  vmovaps [rsp+0x40], xmm4
000074da185d7f61  vmovaps [rsp+0x50], xmm5
000074da185d7f67  vmovaps [rsp+0x60], xmm6
000074da185d7f6d  vmovaps [rsp+0x70], xmm7
000074da185d7f73  vmovaps [rsp+0x80], xmm8
000074da185d7f7c  vmovaps [rsp+0x90], xmm9
000074da185d7f85  vmovaps [rsp+0xA0], xmm11
000074da185d7f8e  vmovaps [rsp+0xB0], xmm12
000074da185d7f97  vmovaps [rsp+0xC0], xmm13
000074da185d7fa0  vmovaps [rsp+0xD0], xmm14
000074da185d7fa9  vmovaps [rsp+0xE0], xmm15
000074da185d7fb2  sub rsp, 0x40
000074da185d7fb6  lea rdi, [rsp]
000074da185d7fba  lea rsi, [rsp+0x10]
000074da185d7fbf  lea rdx, [rsp+0x20]
000074da185d7fc4  lea rcx, [rsp+0x30]
000074da185d7fc9  mov r8d, 0x00
000074da185d7fcf  lea r9, [r15+0x3A8]
000074da185d7fd6  movaps [rdi], xmm10
000074da185d7fda  movaps [rsi], xmm9
000074da185d7fde  movaps [rdx], xmm7
000074da185d7fe1  movaps [rcx], xmm14
000074da185d7fe5  mov rax, 0x5946061DFA50
000074da185d7fef  call rax
000074da185d7ff1  movaps xmm10, [rsp]
000074da185d7ff6  add rsp, 0x40
000074da185d7ffa  vmovaps xmm0, [rsp]
000074da185d7fff  vmovaps xmm1, [rsp+0x10]
000074da185d8005  vmovaps xmm2, [rsp+0x20]
000074da185d800b  vmovaps xmm3, [rsp+0x30]
000074da185d8011  vmovaps xmm4, [rsp+0x40]
000074da185d8017  vmovaps xmm5, [rsp+0x50]
000074da185d801d  vmovaps xmm6, [rsp+0x60]
000074da185d8023  vmovaps xmm7, [rsp+0x70]
000074da185d8029  vmovaps xmm8, [rsp+0x80]
000074da185d8032  vmovaps xmm9, [rsp+0x90]
000074da185d803b  vmovaps xmm11, [rsp+0xA0]
000074da185d8044  vmovaps xmm12, [rsp+0xB0]
000074da185d804d  vmovaps xmm13, [rsp+0xC0]
000074da185d8056  vmovaps xmm14, [rsp+0xD0]
000074da185d805f  vmovaps xmm15, [rsp+0xE0]
000074da185d8068  add rsp, 0xF0
000074da185d806f  pop r11
000074da185d8071  pop r10
000074da185d8073  pop r9
000074da185d8075  pop r8
000074da185d8077  pop rsi
000074da185d8078  pop rdi
000074da185d8079  pop rdx
000074da185d807a  pop rcx
000074da185d807b  pop rax
000074da185d807c  add rsp, 0x08
000074da185d8080  jmp 0x000074DA185D68F1
000074da185d8085  call 0x000074DA184E45A0
000074da185d808a  jmp 0x000074DA185D68FE
000074da185d808f  sub rsp, 0x08
000074da185d8093  push rax
000074da185d8094  push rcx
000074da185d8095  push rdx
000074da185d8096  push rdi
000074da185d8097  push rsi
000074da185d8098  push r8
000074da185d809a  push r9
000074da185d809c  push r10
000074da185d809e  push r11
000074da185d80a0  sub rsp, 0xF0
000074da185d80a7  vmovaps [rsp], xmm0
000074da185d80ac  vmovaps [rsp+0x10], xmm1
000074da185d80b2  vmovaps [rsp+0x20], xmm2
000074da185d80b8  vmovaps [rsp+0x30], xmm3
000074da185d80be  vmovaps [rsp+0x40], xmm4
000074da185d80c4  vmovaps [rsp+0x50], xmm6
000074da185d80ca  vmovaps [rsp+0x60], xmm7
000074da185d80d0  vmovaps [rsp+0x70], xmm8
000074da185d80d6  vmovaps [rsp+0x80], xmm9
000074da185d80df  vmovaps [rsp+0x90], xmm10
000074da185d80e8  vmovaps [rsp+0xA0], xmm11
000074da185d80f1  vmovaps [rsp+0xB0], xmm12
000074da185d80fa  vmovaps [rsp+0xC0], xmm13
000074da185d8103  vmovaps [rsp+0xD0], xmm14
000074da185d810c  vmovaps [rsp+0xE0], xmm15
000074da185d8115  sub rsp, 0x40
000074da185d8119  lea rdi, [rsp]
000074da185d811d  lea rsi, [rsp+0x10]
000074da185d8122  lea rdx, [rsp+0x20]
000074da185d8127  lea rcx, [rsp+0x30]
000074da185d812c  mov r8d, 0x00
000074da185d8132  lea r9, [r15+0x3A8]
000074da185d8139  movaps [rdi], xmm5
000074da185d813c  movaps [rsi], xmm6
000074da185d813f  movaps [rdx], xmm7
000074da185d8142  movaps [rcx], xmm9
000074da185d8146  mov rax, 0x5946061DFA50
000074da185d8150  call rax
000074da185d8152  movaps xmm5, [rsp]
000074da185d8156  add rsp, 0x40
000074da185d815a  vmovaps xmm0, [rsp]
000074da185d815f  vmovaps xmm1, [rsp+0x10]
000074da185d8165  vmovaps xmm2, [rsp+0x20]
000074da185d816b  vmovaps xmm3, [rsp+0x30]
000074da185d8171  vmovaps xmm4, [rsp+0x40]
000074da185d8177  vmovaps xmm6, [rsp+0x50]
000074da185d817d  vmovaps xmm7, [rsp+0x60]
000074da185d8183  vmovaps xmm8, [rsp+0x70]
000074da185d8189  vmovaps xmm9, [rsp+0x80]
000074da185d8192  vmovaps xmm10, [rsp+0x90]
000074da185d819b  vmovaps xmm11, [rsp+0xA0]
000074da185d81a4  vmovaps xmm12, [rsp+0xB0]
000074da185d81ad  vmovaps xmm13, [rsp+0xC0]
000074da185d81b6  vmovaps xmm14, [rsp+0xD0]
000074da185d81bf  vmovaps xmm15, [rsp+0xE0]
000074da185d81c8  add rsp, 0xF0
000074da185d81cf  pop r11
000074da185d81d1  pop r10
000074da185d81d3  pop r9
000074da185d81d5  pop r8
000074da185d81d7  pop rsi
000074da185d81d8  pop rdi
000074da185d81d9  pop rdx
000074da185d81da  pop rcx
000074da185d81db  pop rax
000074da185d81dc  add rsp, 0x08
000074da185d81e0  jmp 0x000074DA185D6930
000074da185d81e5  sub rsp, 0x08
000074da185d81e9  push rax
000074da185d81ea  push rcx
000074da185d81eb  push rdx
000074da185d81ec  push rdi
000074da185d81ed  push rsi
000074da185d81ee  push r8
000074da185d81f0  push r9
000074da185d81f2  push r10
000074da185d81f4  push r11
000074da185d81f6  sub rsp, 0xF0
000074da185d81fd  vmovaps [rsp], xmm0
000074da185d8202  vmovaps [rsp+0x10], xmm1
000074da185d8208  vmovaps [rsp+0x20], xmm2
000074da185d820e  vmovaps [rsp+0x30], xmm3
000074da185d8214  vmovaps [rsp+0x40], xmm4
000074da185d821a  vmovaps [rsp+0x50], xmm5
000074da185d8220  vmovaps [rsp+0x60], xmm6
000074da185d8226  vmovaps [rsp+0x70], xmm8
000074da185d822c  vmovaps [rsp+0x80], xmm9
000074da185d8235  vmovaps [rsp+0x90], xmm10
000074da185d823e  vmovaps [rsp+0xA0], xmm11
000074da185d8247  vmovaps [rsp+0xB0], xmm12
000074da185d8250  vmovaps [rsp+0xC0], xmm13
000074da185d8259  vmovaps [rsp+0xD0], xmm14
000074da185d8262  vmovaps [rsp+0xE0], xmm15
000074da185d826b  sub rsp, 0x40
000074da185d826f  lea rdi, [rsp]
000074da185d8273  lea rsi, [rsp+0x10]
000074da185d8278  lea rdx, [rsp+0x20]
000074da185d827d  lea rcx, [rsp+0x30]
000074da185d8282  mov r8d, 0x00
000074da185d8288  lea r9, [r15+0x3A8]
000074da185d828f  movaps [rdi], xmm7
000074da185d8292  movaps [rsi], xmm13
000074da185d8296  movaps [rdx], xmm1
000074da185d8299  movaps [rcx], xmm9
000074da185d829d  mov rax, 0x5946061DFA50
000074da185d82a7  call rax
000074da185d82a9  movaps xmm7, [rsp]
000074da185d82ad  add rsp, 0x40
000074da185d82b1  vmovaps xmm0, [rsp]
000074da185d82b6  vmovaps xmm1, [rsp+0x10]
000074da185d82bc  vmovaps xmm2, [rsp+0x20]
000074da185d82c2  vmovaps xmm3, [rsp+0x30]
000074da185d82c8  vmovaps xmm4, [rsp+0x40]
000074da185d82ce  vmovaps xmm5, [rsp+0x50]
000074da185d82d4  vmovaps xmm6, [rsp+0x60]
000074da185d82da  vmovaps xmm8, [rsp+0x70]
000074da185d82e0  vmovaps xmm9, [rsp+0x80]
000074da185d82e9  vmovaps xmm10, [rsp+0x90]
000074da185d82f2  vmovaps xmm11, [rsp+0xA0]
000074da185d82fb  vmovaps xmm12, [rsp+0xB0]
000074da185d8304  vmovaps xmm13, [rsp+0xC0]
000074da185d830d  vmovaps xmm14, [rsp+0xD0]
000074da185d8316  vmovaps xmm15, [rsp+0xE0]
000074da185d831f  add rsp, 0xF0
000074da185d8326  pop r11
000074da185d8328  pop r10
000074da185d832a  pop r9
000074da185d832c  pop r8
000074da185d832e  pop rsi
000074da185d832f  pop rdi
000074da185d8330  pop rdx
000074da185d8331  pop rcx
000074da185d8332  pop rax
000074da185d8333  add rsp, 0x08
000074da185d8337  jmp 0x000074DA185D6955
000074da185d833c  call 0x000074DA184E3320
000074da185d8341  jmp 0x000074DA185D6978
000074da185d8346  call 0x000074DA184DE950
000074da185d834b  jmp 0x000074DA185D6982
000074da185d8350  sub rsp, 0x08
000074da185d8354  push rax
000074da185d8355  push rcx
000074da185d8356  push rdx
000074da185d8357  push rdi
000074da185d8358  push rsi
000074da185d8359  push r8
000074da185d835b  push r9
000074da185d835d  push r10
000074da185d835f  push r11
000074da185d8361  sub rsp, 0xF0
000074da185d8368  vmovaps [rsp], xmm0
000074da185d836d  vmovaps [rsp+0x10], xmm1
000074da185d8373  vmovaps [rsp+0x20], xmm3
000074da185d8379  vmovaps [rsp+0x30], xmm4
000074da185d837f  vmovaps [rsp+0x40], xmm5
000074da185d8385  vmovaps [rsp+0x50], xmm6
000074da185d838b  vmovaps [rsp+0x60], xmm7
000074da185d8391  vmovaps [rsp+0x70], xmm8
000074da185d8397  vmovaps [rsp+0x80], xmm9
000074da185d83a0  vmovaps [rsp+0x90], xmm10
000074da185d83a9  vmovaps [rsp+0xA0], xmm11
000074da185d83b2  vmovaps [rsp+0xB0], xmm12
000074da185d83bb  vmovaps [rsp+0xC0], xmm13
000074da185d83c4  vmovaps [rsp+0xD0], xmm14
000074da185d83cd  vmovaps [rsp+0xE0], xmm15
000074da185d83d6  sub rsp, 0x40
000074da185d83da  lea rdi, [rsp]
000074da185d83de  lea rsi, [rsp+0x10]
000074da185d83e3  lea rdx, [rsp+0x20]
000074da185d83e8  lea rcx, [rsp+0x30]
000074da185d83ed  mov r8d, 0x00
000074da185d83f3  lea r9, [r15+0x3A8]
000074da185d83fa  movaps [rdi], xmm2
000074da185d83fd  movaps [rsi], xmm12
000074da185d8401  movaps [rdx], xmm6
000074da185d8404  movaps [rcx], xmm3
000074da185d8407  mov rax, 0x5946061DFA50
000074da185d8411  call rax
000074da185d8413  movaps xmm2, [rsp]
000074da185d8417  add rsp, 0x40
000074da185d841b  vmovaps xmm0, [rsp]
000074da185d8420  vmovaps xmm1, [rsp+0x10]
000074da185d8426  vmovaps xmm3, [rsp+0x20]
000074da185d842c  vmovaps xmm4, [rsp+0x30]
000074da185d8432  vmovaps xmm5, [rsp+0x40]
000074da185d8438  vmovaps xmm6, [rsp+0x50]
000074da185d843e  vmovaps xmm7, [rsp+0x60]
000074da185d8444  vmovaps xmm8, [rsp+0x70]
000074da185d844a  vmovaps xmm9, [rsp+0x80]
000074da185d8453  vmovaps xmm10, [rsp+0x90]
000074da185d845c  vmovaps xmm11, [rsp+0xA0]
000074da185d8465  vmovaps xmm12, [rsp+0xB0]
000074da185d846e  vmovaps xmm13, [rsp+0xC0]
000074da185d8477  vmovaps xmm14, [rsp+0xD0]
000074da185d8480  vmovaps xmm15, [rsp+0xE0]
000074da185d8489  add rsp, 0xF0
000074da185d8490  pop r11
000074da185d8492  pop r10
000074da185d8494  pop r9
000074da185d8496  pop r8
000074da185d8498  pop rsi
000074da185d8499  pop rdi
000074da185d849a  pop rdx
000074da185d849b  pop rcx
000074da185d849c  pop rax
000074da185d849d  add rsp, 0x08
000074da185d84a1  jmp 0x000074DA185D69C8
000074da185d84a6  sub rsp, 0x08
000074da185d84aa  push rax
000074da185d84ab  push rcx
000074da185d84ac  push rdx
000074da185d84ad  push rdi
000074da185d84ae  push rsi
000074da185d84af  push r8
000074da185d84b1  push r9
000074da185d84b3  push r10
000074da185d84b5  push r11
000074da185d84b7  sub rsp, 0xF0
000074da185d84be  vmovaps [rsp], xmm0
000074da185d84c3  vmovaps [rsp+0x10], xmm1
000074da185d84c9  vmovaps [rsp+0x20], xmm2
000074da185d84cf  vmovaps [rsp+0x30], xmm3
000074da185d84d5  vmovaps [rsp+0x40], xmm4
000074da185d84db  vmovaps [rsp+0x50], xmm5
000074da185d84e1  vmovaps [rsp+0x60], xmm7
000074da185d84e7  vmovaps [rsp+0x70], xmm8
000074da185d84ed  vmovaps [rsp+0x80], xmm9
000074da185d84f6  vmovaps [rsp+0x90], xmm10
000074da185d84ff  vmovaps [rsp+0xA0], xmm11
000074da185d8508  vmovaps [rsp+0xB0], xmm12
000074da185d8511  vmovaps [rsp+0xC0], xmm13
000074da185d851a  vmovaps [rsp+0xD0], xmm14
000074da185d8523  vmovaps [rsp+0xE0], xmm15
000074da185d852c  sub rsp, 0x40
000074da185d8530  lea rdi, [rsp]
000074da185d8534  lea rsi, [rsp+0x10]
000074da185d8539  lea rdx, [rsp+0x20]
000074da185d853e  lea rcx, [rsp+0x30]
000074da185d8543  mov r8d, 0x00
000074da185d8549  lea r9, [r15+0x3A8]
000074da185d8550  movaps [rdi], xmm6
000074da185d8553  movaps [rsi], xmm10
000074da185d8557  movaps [rdx], xmm12
000074da185d855b  movaps [rcx], xmm1
000074da185d855e  mov rax, 0x5946061DFA50
000074da185d8568  call rax
000074da185d856a  movaps xmm6, [rsp]
000074da185d856e  add rsp, 0x40
000074da185d8572  vmovaps xmm0, [rsp]
000074da185d8577  vmovaps xmm1, [rsp+0x10]
000074da185d857d  vmovaps xmm2, [rsp+0x20]
000074da185d8583  vmovaps xmm3, [rsp+0x30]
000074da185d8589  vmovaps xmm4, [rsp+0x40]
000074da185d858f  vmovaps xmm5, [rsp+0x50]
000074da185d8595  vmovaps xmm7, [rsp+0x60]
000074da185d859b  vmovaps xmm8, [rsp+0x70]
000074da185d85a1  vmovaps xmm9, [rsp+0x80]
000074da185d85aa  vmovaps xmm10, [rsp+0x90]
000074da185d85b3  vmovaps xmm11, [rsp+0xA0]
000074da185d85bc  vmovaps xmm12, [rsp+0xB0]
000074da185d85c5  vmovaps xmm13, [rsp+0xC0]
000074da185d85ce  vmovaps xmm14, [rsp+0xD0]
000074da185d85d7  vmovaps xmm15, [rsp+0xE0]
000074da185d85e0  add rsp, 0xF0
000074da185d85e7  pop r11
000074da185d85e9  pop r10
000074da185d85eb  pop r9
000074da185d85ed  pop r8
000074da185d85ef  pop rsi
000074da185d85f0  pop rdi
000074da185d85f1  pop rdx
000074da185d85f2  pop rcx
000074da185d85f3  pop rax
000074da185d85f4  add rsp, 0x08
000074da185d85f8  jmp 0x000074DA185D69F6
000074da185d85fd  sub rsp, 0x08
000074da185d8601  push rax
000074da185d8602  push rcx
000074da185d8603  push rdx
000074da185d8604  push rdi
000074da185d8605  push rsi
000074da185d8606  push r8
000074da185d8608  push r9
000074da185d860a  push r10
000074da185d860c  push r11
000074da185d860e  sub rsp, 0xF0
000074da185d8615  vmovaps [rsp], xmm0
000074da185d861a  vmovaps [rsp+0x10], xmm1
000074da185d8620  vmovaps [rsp+0x20], xmm2
000074da185d8626  vmovaps [rsp+0x30], xmm3
000074da185d862c  vmovaps [rsp+0x40], xmm4
000074da185d8632  vmovaps [rsp+0x50], xmm5
000074da185d8638  vmovaps [rsp+0x60], xmm6
000074da185d863e  vmovaps [rsp+0x70], xmm7
000074da185d8644  vmovaps [rsp+0x80], xmm8
000074da185d864d  vmovaps [rsp+0x90], xmm9
000074da185d8656  vmovaps [rsp+0xA0], xmm11
000074da185d865f  vmovaps [rsp+0xB0], xmm12
000074da185d8668  vmovaps [rsp+0xC0], xmm13
000074da185d8671  vmovaps [rsp+0xD0], xmm14
000074da185d867a  vmovaps [rsp+0xE0], xmm15
000074da185d8683  sub rsp, 0x40
000074da185d8687  lea rdi, [rsp]
000074da185d868b  lea rsi, [rsp+0x10]
000074da185d8690  lea rdx, [rsp+0x20]
000074da185d8695  lea rcx, [rsp+0x30]
000074da185d869a  mov r8d, 0x00
000074da185d86a0  lea r9, [r15+0x3A8]
000074da185d86a7  movaps [rdi], xmm10
000074da185d86ab  movaps [rsi], xmm5
000074da185d86ae  movaps [rdx], xmm12
000074da185d86b2  movaps [rcx], xmm1
000074da185d86b5  mov rax, 0x5946061DFA50
000074da185d86bf  call rax
000074da185d86c1  movaps xmm10, [rsp]
000074da185d86c6  add rsp, 0x40
000074da185d86ca  vmovaps xmm0, [rsp]
000074da185d86cf  vmovaps xmm1, [rsp+0x10]
000074da185d86d5  vmovaps xmm2, [rsp+0x20]
000074da185d86db  vmovaps xmm3, [rsp+0x30]
000074da185d86e1  vmovaps xmm4, [rsp+0x40]
000074da185d86e7  vmovaps xmm5, [rsp+0x50]
000074da185d86ed  vmovaps xmm6, [rsp+0x60]
000074da185d86f3  vmovaps xmm7, [rsp+0x70]
000074da185d86f9  vmovaps xmm8, [rsp+0x80]
000074da185d8702  vmovaps xmm9, [rsp+0x90]
000074da185d870b  vmovaps xmm11, [rsp+0xA0]
000074da185d8714  vmovaps xmm12, [rsp+0xB0]
000074da185d871d  vmovaps xmm13, [rsp+0xC0]
000074da185d8726  vmovaps xmm14, [rsp+0xD0]
000074da185d872f  vmovaps xmm15, [rsp+0xE0]
000074da185d8738  add rsp, 0xF0
000074da185d873f  pop r11
000074da185d8741  pop r10
000074da185d8743  pop r9
000074da185d8745  pop r8
000074da185d8747  pop rsi
000074da185d8748  pop rdi
000074da185d8749  pop rdx
000074da185d874a  pop rcx
000074da185d874b  pop rax
000074da185d874c  add rsp, 0x08
000074da185d8750  jmp 0x000074DA185D6A25
000074da185d8755  sub rsp, 0x08
000074da185d8759  push rax
000074da185d875a  push rcx
000074da185d875b  push rdx
000074da185d875c  push rdi
000074da185d875d  push rsi
000074da185d875e  push r8
000074da185d8760  push r9
000074da185d8762  push r10
000074da185d8764  push r11
000074da185d8766  sub rsp, 0xF0
000074da185d876d  vmovaps [rsp], xmm0
000074da185d8772  vmovaps [rsp+0x10], xmm1
000074da185d8778  vmovaps [rsp+0x20], xmm2
000074da185d877e  vmovaps [rsp+0x30], xmm3
000074da185d8784  vmovaps [rsp+0x40], xmm4
000074da185d878a  vmovaps [rsp+0x50], xmm5
000074da185d8790  vmovaps [rsp+0x60], xmm6
000074da185d8796  vmovaps [rsp+0x70], xmm7
000074da185d879c  vmovaps [rsp+0x80], xmm8
000074da185d87a5  vmovaps [rsp+0x90], xmm9
000074da185d87ae  vmovaps [rsp+0xA0], xmm10
000074da185d87b7  vmovaps [rsp+0xB0], xmm11
000074da185d87c0  vmovaps [rsp+0xC0], xmm13
000074da185d87c9  vmovaps [rsp+0xD0], xmm14
000074da185d87d2  vmovaps [rsp+0xE0], xmm15
000074da185d87db  sub rsp, 0x40
000074da185d87df  lea rdi, [rsp]
000074da185d87e3  lea rsi, [rsp+0x10]
000074da185d87e8  lea rdx, [rsp+0x20]
000074da185d87ed  lea rcx, [rsp+0x30]
000074da185d87f2  mov r8d, 0x00
000074da185d87f8  lea r9, [r15+0x3A8]
000074da185d87ff  movaps [rdi], xmm12
000074da185d8803  movaps [rsi], xmm7
000074da185d8806  movaps [rdx], xmm15
000074da185d880a  movaps [rcx], xmm1
000074da185d880d  mov rax, 0x5946061DFA50
000074da185d8817  call rax
000074da185d8819  movaps xmm12, [rsp]
000074da185d881e  add rsp, 0x40
000074da185d8822  vmovaps xmm0, [rsp]
000074da185d8827  vmovaps xmm1, [rsp+0x10]
000074da185d882d  vmovaps xmm2, [rsp+0x20]
000074da185d8833  vmovaps xmm3, [rsp+0x30]
000074da185d8839  vmovaps xmm4, [rsp+0x40]
000074da185d883f  vmovaps xmm5, [rsp+0x50]
000074da185d8845  vmovaps xmm6, [rsp+0x60]
000074da185d884b  vmovaps xmm7, [rsp+0x70]
000074da185d8851  vmovaps xmm8, [rsp+0x80]
000074da185d885a  vmovaps xmm9, [rsp+0x90]
000074da185d8863  vmovaps xmm10, [rsp+0xA0]
000074da185d886c  vmovaps xmm11, [rsp+0xB0]
000074da185d8875  vmovaps xmm13, [rsp+0xC0]
000074da185d887e  vmovaps xmm14, [rsp+0xD0]
000074da185d8887  vmovaps xmm15, [rsp+0xE0]
000074da185d8890  add rsp, 0xF0
000074da185d8897  pop r11
000074da185d8899  pop r10
000074da185d889b  pop r9
000074da185d889d  pop r8
000074da185d889f  pop rsi
000074da185d88a0  pop rdi
000074da185d88a1  pop rdx
000074da185d88a2  pop rcx
000074da185d88a3  pop rax
000074da185d88a4  add rsp, 0x08
000074da185d88a8  jmp 0x000074DA185D6A4E
000074da185d88ad  call 0x000074DA184D64F0
000074da185d88b2  jmp 0x000074DA185D6A58
000074da185d88b7  call 0x000074DA184E5820
000074da185d88bc  jmp 0x000074DA185D6A62
000074da185d88c1  sub rsp, 0x08
000074da185d88c5  push rax
000074da185d88c6  push rcx
000074da185d88c7  push rdx
000074da185d88c8  push rdi
000074da185d88c9  push rsi
000074da185d88ca  push r8
000074da185d88cc  push r9
000074da185d88ce  push r10
000074da185d88d0  push r11
000074da185d88d2  sub rsp, 0xF0
000074da185d88d9  vmovaps [rsp], xmm0
000074da185d88de  vmovaps [rsp+0x10], xmm1
000074da185d88e4  vmovaps [rsp+0x20], xmm2
000074da185d88ea  vmovaps [rsp+0x30], xmm3
000074da185d88f0  vmovaps [rsp+0x40], xmm4
000074da185d88f6  vmovaps [rsp+0x50], xmm5
000074da185d88fc  vmovaps [rsp+0x60], xmm6
000074da185d8902  vmovaps [rsp+0x70], xmm8
000074da185d8908  vmovaps [rsp+0x80], xmm9
000074da185d8911  vmovaps [rsp+0x90], xmm10
000074da185d891a  vmovaps [rsp+0xA0], xmm11
000074da185d8923  vmovaps [rsp+0xB0], xmm12
000074da185d892c  vmovaps [rsp+0xC0], xmm13
000074da185d8935  vmovaps [rsp+0xD0], xmm14
000074da185d893e  vmovaps [rsp+0xE0], xmm15
000074da185d8947  sub rsp, 0x40
000074da185d894b  lea rdi, [rsp]
000074da185d894f  lea rsi, [rsp+0x10]
000074da185d8954  lea rdx, [rsp+0x20]
000074da185d8959  lea rcx, [rsp+0x30]
000074da185d895e  mov r8d, 0x00
000074da185d8964  lea r9, [r15+0x3A8]
000074da185d896b  movaps [rdi], xmm7
000074da185d896e  movaps [rsi], xmm2
000074da185d8971  movaps [rdx], xmm9
000074da185d8975  movaps [rcx], xmm11
000074da185d8979  mov rax, 0x5946061DFA50
000074da185d8983  call rax
000074da185d8985  movaps xmm7, [rsp]
000074da185d8989  add rsp, 0x40
000074da185d898d  vmovaps xmm0, [rsp]
000074da185d8992  vmovaps xmm1, [rsp+0x10]
000074da185d8998  vmovaps xmm2, [rsp+0x20]
000074da185d899e  vmovaps xmm3, [rsp+0x30]
000074da185d89a4  vmovaps xmm4, [rsp+0x40]
000074da185d89aa  vmovaps xmm5, [rsp+0x50]
000074da185d89b0  vmovaps xmm6, [rsp+0x60]
000074da185d89b6  vmovaps xmm8, [rsp+0x70]
000074da185d89bc  vmovaps xmm9, [rsp+0x80]
000074da185d89c5  vmovaps xmm10, [rsp+0x90]
000074da185d89ce  vmovaps xmm11, [rsp+0xA0]
000074da185d89d7  vmovaps xmm12, [rsp+0xB0]
000074da185d89e0  vmovaps xmm13, [rsp+0xC0]
000074da185d89e9  vmovaps xmm14, [rsp+0xD0]
000074da185d89f2  vmovaps xmm15, [rsp+0xE0]
000074da185d89fb  add rsp, 0xF0
000074da185d8a02  pop r11
000074da185d8a04  pop r10
000074da185d8a06  pop r9
000074da185d8a08  pop r8
000074da185d8a0a  pop rsi
000074da185d8a0b  pop rdi
000074da185d8a0c  pop rdx
000074da185d8a0d  pop rcx
000074da185d8a0e  pop rax
000074da185d8a0f  add rsp, 0x08
000074da185d8a13  jmp 0x000074DA185D6A96
000074da185d8a18  sub rsp, 0x08
000074da185d8a1c  push rax
000074da185d8a1d  push rcx
000074da185d8a1e  push rdx
000074da185d8a1f  push rdi
000074da185d8a20  push rsi
000074da185d8a21  push r8
000074da185d8a23  push r9
000074da185d8a25  push r10
000074da185d8a27  push r11
000074da185d8a29  sub rsp, 0xF0
000074da185d8a30  vmovaps [rsp], xmm0
000074da185d8a35  vmovaps [rsp+0x10], xmm1
000074da185d8a3b  vmovaps [rsp+0x20], xmm2
000074da185d8a41  vmovaps [rsp+0x30], xmm3
000074da185d8a47  vmovaps [rsp+0x40], xmm4
000074da185d8a4d  vmovaps [rsp+0x50], xmm5
000074da185d8a53  vmovaps [rsp+0x60], xmm6
000074da185d8a59  vmovaps [rsp+0x70], xmm7
000074da185d8a5f  vmovaps [rsp+0x80], xmm8
000074da185d8a68  vmovaps [rsp+0x90], xmm10
000074da185d8a71  vmovaps [rsp+0xA0], xmm11
000074da185d8a7a  vmovaps [rsp+0xB0], xmm12
000074da185d8a83  vmovaps [rsp+0xC0], xmm13
000074da185d8a8c  vmovaps [rsp+0xD0], xmm14
000074da185d8a95  vmovaps [rsp+0xE0], xmm15
000074da185d8a9e  sub rsp, 0x40
000074da185d8aa2  lea rdi, [rsp]
000074da185d8aa6  lea rsi, [rsp+0x10]
000074da185d8aab  lea rdx, [rsp+0x20]
000074da185d8ab0  lea rcx, [rsp+0x30]
000074da185d8ab5  mov r8d, 0x00
000074da185d8abb  lea r9, [r15+0x3A8]
000074da185d8ac2  movaps [rdi], xmm9
000074da185d8ac6  movaps [rsi], xmm6
000074da185d8ac9  movaps [rdx], xmm1
000074da185d8acc  movaps [rcx], xmm11
000074da185d8ad0  mov rax, 0x5946061DFA50
000074da185d8ada  call rax
000074da185d8adc  movaps xmm9, [rsp]
000074da185d8ae1  add rsp, 0x40
000074da185d8ae5  vmovaps xmm0, [rsp]
000074da185d8aea  vmovaps xmm1, [rsp+0x10]
000074da185d8af0  vmovaps xmm2, [rsp+0x20]
000074da185d8af6  vmovaps xmm3, [rsp+0x30]
000074da185d8afc  vmovaps xmm4, [rsp+0x40]
000074da185d8b02  vmovaps xmm5, [rsp+0x50]
000074da185d8b08  vmovaps xmm6, [rsp+0x60]
000074da185d8b0e  vmovaps xmm7, [rsp+0x70]
000074da185d8b14  vmovaps xmm8, [rsp+0x80]
000074da185d8b1d  vmovaps xmm10, [rsp+0x90]
000074da185d8b26  vmovaps xmm11, [rsp+0xA0]
000074da185d8b2f  vmovaps xmm12, [rsp+0xB0]
000074da185d8b38  vmovaps xmm13, [rsp+0xC0]
000074da185d8b41  vmovaps xmm14, [rsp+0xD0]
000074da185d8b4a  vmovaps xmm15, [rsp+0xE0]
000074da185d8b53  add rsp, 0xF0
000074da185d8b5a  pop r11
000074da185d8b5c  pop r10
000074da185d8b5e  pop r9
000074da185d8b60  pop r8
000074da185d8b62  pop rsi
000074da185d8b63  pop rdi
000074da185d8b64  pop rdx
000074da185d8b65  pop rcx
000074da185d8b66  pop rax
000074da185d8b67  add rsp, 0x08
000074da185d8b6b  jmp 0x000074DA185D6ABC
000074da185d8b70  sub rsp, 0x08
000074da185d8b74  push rax
000074da185d8b75  push rcx
000074da185d8b76  push rdx
000074da185d8b77  push rdi
000074da185d8b78  push rsi
000074da185d8b79  push r8
000074da185d8b7b  push r9
000074da185d8b7d  push r10
000074da185d8b7f  push r11
000074da185d8b81  sub rsp, 0xF0
000074da185d8b88  vmovaps [rsp], xmm0
000074da185d8b8d  vmovaps [rsp+0x10], xmm1
000074da185d8b93  vmovaps [rsp+0x20], xmm2
000074da185d8b99  vmovaps [rsp+0x30], xmm3
000074da185d8b9f  vmovaps [rsp+0x40], xmm4
000074da185d8ba5  vmovaps [rsp+0x50], xmm5
000074da185d8bab  vmovaps [rsp+0x60], xmm6
000074da185d8bb1  vmovaps [rsp+0x70], xmm7
000074da185d8bb7  vmovaps [rsp+0x80], xmm8
000074da185d8bc0  vmovaps [rsp+0x90], xmm9
000074da185d8bc9  vmovaps [rsp+0xA0], xmm10
000074da185d8bd2  vmovaps [rsp+0xB0], xmm12
000074da185d8bdb  vmovaps [rsp+0xC0], xmm13
000074da185d8be4  vmovaps [rsp+0xD0], xmm14
000074da185d8bed  vmovaps [rsp+0xE0], xmm15
000074da185d8bf6  sub rsp, 0x40
000074da185d8bfa  lea rdi, [rsp]
000074da185d8bfe  lea rsi, [rsp+0x10]
000074da185d8c03  lea rdx, [rsp+0x20]
000074da185d8c08  lea rcx, [rsp+0x30]
000074da185d8c0d  mov r8d, 0x00
000074da185d8c13  lea r9, [r15+0x3A8]
000074da185d8c1a  movaps [rdi], xmm11
000074da185d8c1e  movaps [rsi], xmm10
000074da185d8c22  movaps [rdx], xmm8
000074da185d8c26  movaps [rcx], xmm1
000074da185d8c29  mov rax, 0x5946061DFA50
000074da185d8c33  call rax
000074da185d8c35  movaps xmm11, [rsp]
000074da185d8c3a  add rsp, 0x40
000074da185d8c3e  vmovaps xmm0, [rsp]
000074da185d8c43  vmovaps xmm1, [rsp+0x10]
000074da185d8c49  vmovaps xmm2, [rsp+0x20]
000074da185d8c4f  vmovaps xmm3, [rsp+0x30]
000074da185d8c55  vmovaps xmm4, [rsp+0x40]
000074da185d8c5b  vmovaps xmm5, [rsp+0x50]
000074da185d8c61  vmovaps xmm6, [rsp+0x60]
000074da185d8c67  vmovaps xmm7, [rsp+0x70]
000074da185d8c6d  vmovaps xmm8, [rsp+0x80]
000074da185d8c76  vmovaps xmm9, [rsp+0x90]
000074da185d8c7f  vmovaps xmm10, [rsp+0xA0]
000074da185d8c88  vmovaps xmm12, [rsp+0xB0]
000074da185d8c91  vmovaps xmm13, [rsp+0xC0]
000074da185d8c9a  vmovaps xmm14, [rsp+0xD0]
000074da185d8ca3  vmovaps xmm15, [rsp+0xE0]
000074da185d8cac  add rsp, 0xF0
000074da185d8cb3  pop r11
000074da185d8cb5  pop r10
000074da185d8cb7  pop r9
000074da185d8cb9  pop r8
000074da185d8cbb  pop rsi
000074da185d8cbc  pop rdi
000074da185d8cbd  pop rdx
000074da185d8cbe  pop rcx
000074da185d8cbf  pop rax
000074da185d8cc0  add rsp, 0x08
000074da185d8cc4  jmp 0x000074DA185D6AE2
000074da185d8cc9  sub rsp, 0x08
000074da185d8ccd  push rax
000074da185d8cce  push rcx
000074da185d8ccf  push rdx
000074da185d8cd0  push rdi
000074da185d8cd1  push rsi
000074da185d8cd2  push r8
000074da185d8cd4  push r9
000074da185d8cd6  push r10
000074da185d8cd8  push r11
000074da185d8cda  sub rsp, 0xF0
000074da185d8ce1  vmovaps [rsp], xmm0
000074da185d8ce6  vmovaps [rsp+0x10], xmm1
000074da185d8cec  vmovaps [rsp+0x20], xmm2
000074da185d8cf2  vmovaps [rsp+0x30], xmm3
000074da185d8cf8  vmovaps [rsp+0x40], xmm4
000074da185d8cfe  vmovaps [rsp+0x50], xmm5
000074da185d8d04  vmovaps [rsp+0x60], xmm6
000074da185d8d0a  vmovaps [rsp+0x70], xmm7
000074da185d8d10  vmovaps [rsp+0x80], xmm8
000074da185d8d19  vmovaps [rsp+0x90], xmm9
000074da185d8d22  vmovaps [rsp+0xA0], xmm11
000074da185d8d2b  vmovaps [rsp+0xB0], xmm12
000074da185d8d34  vmovaps [rsp+0xC0], xmm13
000074da185d8d3d  vmovaps [rsp+0xD0], xmm14
000074da185d8d46  vmovaps [rsp+0xE0], xmm15
000074da185d8d4f  sub rsp, 0x40
000074da185d8d53  lea rdi, [rsp]
000074da185d8d57  lea rsi, [rsp+0x10]
000074da185d8d5c  lea rdx, [rsp+0x20]
000074da185d8d61  lea rcx, [rsp+0x30]
000074da185d8d66  mov r8d, 0x00
000074da185d8d6c  lea r9, [r15+0x3A8]
000074da185d8d73  movaps [rdi], xmm10
000074da185d8d77  movaps [rsi], xmm12
000074da185d8d7b  movaps [rdx], xmm13
000074da185d8d7f  movaps [rcx], xmm1
000074da185d8d82  mov rax, 0x5946061DFA50
000074da185d8d8c  call rax
000074da185d8d8e  movaps xmm10, [rsp]
000074da185d8d93  add rsp, 0x40
000074da185d8d97  vmovaps xmm0, [rsp]
000074da185d8d9c  vmovaps xmm1, [rsp+0x10]
000074da185d8da2  vmovaps xmm2, [rsp+0x20]
000074da185d8da8  vmovaps xmm3, [rsp+0x30]
000074da185d8dae  vmovaps xmm4, [rsp+0x40]
000074da185d8db4  vmovaps xmm5, [rsp+0x50]
000074da185d8dba  vmovaps xmm6, [rsp+0x60]
000074da185d8dc0  vmovaps xmm7, [rsp+0x70]
000074da185d8dc6  vmovaps xmm8, [rsp+0x80]
000074da185d8dcf  vmovaps xmm9, [rsp+0x90]
000074da185d8dd8  vmovaps xmm11, [rsp+0xA0]
000074da185d8de1  vmovaps xmm12, [rsp+0xB0]
000074da185d8dea  vmovaps xmm13, [rsp+0xC0]
000074da185d8df3  vmovaps xmm14, [rsp+0xD0]
000074da185d8dfc  vmovaps xmm15, [rsp+0xE0]
000074da185d8e05  add rsp, 0xF0
000074da185d8e0c  pop r11
000074da185d8e0e  pop r10
000074da185d8e10  pop r9
000074da185d8e12  pop r8
000074da185d8e14  pop rsi
000074da185d8e15  pop rdi
000074da185d8e16  pop rdx
000074da185d8e17  pop rcx
000074da185d8e18  pop rax
000074da185d8e19  add rsp, 0x08
000074da185d8e1d  jmp 0x000074DA185D6B08
000074da185d8e22  call 0x000074DA184D64F0
000074da185d8e27  jmp 0x000074DA185D6B12
000074da185d8e2c  call 0x000074DA184E3320
000074da185d8e31  jmp 0x000074DA185D6B1C
000074da185d8e36  sub rsp, 0x08
000074da185d8e3a  push rax
000074da185d8e3b  push rcx
000074da185d8e3c  push rdx
000074da185d8e3d  push rdi
000074da185d8e3e  push rsi
000074da185d8e3f  push r8
000074da185d8e41  push r9
000074da185d8e43  push r10
000074da185d8e45  push r11
000074da185d8e47  sub rsp, 0xF0
000074da185d8e4e  vmovaps [rsp], xmm0
000074da185d8e53  vmovaps [rsp+0x10], xmm1
000074da185d8e59  vmovaps [rsp+0x20], xmm2
000074da185d8e5f  vmovaps [rsp+0x30], xmm3
000074da185d8e65  vmovaps [rsp+0x40], xmm4
000074da185d8e6b  vmovaps [rsp+0x50], xmm5
000074da185d8e71  vmovaps [rsp+0x60], xmm6
000074da185d8e77  vmovaps [rsp+0x70], xmm7
000074da185d8e7d  vmovaps [rsp+0x80], xmm9
000074da185d8e86  vmovaps [rsp+0x90], xmm10
000074da185d8e8f  vmovaps [rsp+0xA0], xmm11
000074da185d8e98  vmovaps [rsp+0xB0], xmm12
000074da185d8ea1  vmovaps [rsp+0xC0], xmm13
000074da185d8eaa  vmovaps [rsp+0xD0], xmm14
000074da185d8eb3  vmovaps [rsp+0xE0], xmm15
000074da185d8ebc  sub rsp, 0x40
000074da185d8ec0  lea rdi, [rsp]
000074da185d8ec4  lea rsi, [rsp+0x10]
000074da185d8ec9  lea rdx, [rsp+0x20]
000074da185d8ece  lea rcx, [rsp+0x30]
000074da185d8ed3  mov r8d, 0x00
000074da185d8ed9  lea r9, [r15+0x3A8]
000074da185d8ee0  movaps [rdi], xmm8
000074da185d8ee4  movaps [rsi], xmm7
000074da185d8ee7  movaps [rdx], xmm4
000074da185d8eea  movaps [rcx], xmm12
000074da185d8eee  mov rax, 0x5946061DFA50
000074da185d8ef8  call rax
000074da185d8efa  movaps xmm8, [rsp]
000074da185d8eff  add rsp, 0x40
000074da185d8f03  vmovaps xmm0, [rsp]
000074da185d8f08  vmovaps xmm1, [rsp+0x10]
000074da185d8f0e  vmovaps xmm2, [rsp+0x20]
000074da185d8f14  vmovaps xmm3, [rsp+0x30]
000074da185d8f1a  vmovaps xmm4, [rsp+0x40]
000074da185d8f20  vmovaps xmm5, [rsp+0x50]
000074da185d8f26  vmovaps xmm6, [rsp+0x60]
000074da185d8f2c  vmovaps xmm7, [rsp+0x70]
000074da185d8f32  vmovaps xmm9, [rsp+0x80]
000074da185d8f3b  vmovaps xmm10, [rsp+0x90]
000074da185d8f44  vmovaps xmm11, [rsp+0xA0]
000074da185d8f4d  vmovaps xmm12, [rsp+0xB0]
000074da185d8f56  vmovaps xmm13, [rsp+0xC0]
000074da185d8f5f  vmovaps xmm14, [rsp+0xD0]
000074da185d8f68  vmovaps xmm15, [rsp+0xE0]
000074da185d8f71  add rsp, 0xF0
000074da185d8f78  pop r11
000074da185d8f7a  pop r10
000074da185d8f7c  pop r9
000074da185d8f7e  pop r8
000074da185d8f80  pop rsi
000074da185d8f81  pop rdi
000074da185d8f82  pop rdx
000074da185d8f83  pop rcx
000074da185d8f84  pop rax
000074da185d8f85  add rsp, 0x08
000074da185d8f89  jmp 0x000074DA185D6B45
000074da185d8f8e  sub rsp, 0x08
000074da185d8f92  push rax
000074da185d8f93  push rcx
000074da185d8f94  push rdx
000074da185d8f95  push rdi
000074da185d8f96  push rsi
000074da185d8f97  push r8
000074da185d8f99  push r9
000074da185d8f9b  push r10
000074da185d8f9d  push r11
000074da185d8f9f  sub rsp, 0xF0
000074da185d8fa6  vmovaps [rsp], xmm0
000074da185d8fab  vmovaps [rsp+0x10], xmm1
000074da185d8fb1  vmovaps [rsp+0x20], xmm2
000074da185d8fb7  vmovaps [rsp+0x30], xmm3
000074da185d8fbd  vmovaps [rsp+0x40], xmm4
000074da185d8fc3  vmovaps [rsp+0x50], xmm5
000074da185d8fc9  vmovaps [rsp+0x60], xmm6
000074da185d8fcf  vmovaps [rsp+0x70], xmm8
000074da185d8fd5  vmovaps [rsp+0x80], xmm9
000074da185d8fde  vmovaps [rsp+0x90], xmm10
000074da185d8fe7  vmovaps [rsp+0xA0], xmm11
000074da185d8ff0  vmovaps [rsp+0xB0], xmm12
000074da185d8ff9  vmovaps [rsp+0xC0], xmm13
000074da185d9002  vmovaps [rsp+0xD0], xmm14
000074da185d900b  vmovaps [rsp+0xE0], xmm15
000074da185d9014  sub rsp, 0x40
000074da185d9018  lea rdi, [rsp]
000074da185d901c  lea rsi, [rsp+0x10]
000074da185d9021  lea rdx, [rsp+0x20]
000074da185d9026  lea rcx, [rsp+0x30]
000074da185d902b  mov r8d, 0x00
000074da185d9031  lea r9, [r15+0x3A8]
000074da185d9038  movaps [rdi], xmm7
000074da185d903b  movaps [rsi], xmm9
000074da185d903f  movaps [rdx], xmm14
000074da185d9043  movaps [rcx], xmm12
000074da185d9047  mov rax, 0x5946061DFA50
000074da185d9051  call rax
000074da185d9053  movaps xmm7, [rsp]
000074da185d9057  add rsp, 0x40
000074da185d905b  vmovaps xmm0, [rsp]
000074da185d9060  vmovaps xmm1, [rsp+0x10]
000074da185d9066  vmovaps xmm2, [rsp+0x20]
000074da185d906c  vmovaps xmm3, [rsp+0x30]
000074da185d9072  vmovaps xmm4, [rsp+0x40]
000074da185d9078  vmovaps xmm5, [rsp+0x50]
000074da185d907e  vmovaps xmm6, [rsp+0x60]
000074da185d9084  vmovaps xmm8, [rsp+0x70]
000074da185d908a  vmovaps xmm9, [rsp+0x80]
000074da185d9093  vmovaps xmm10, [rsp+0x90]
000074da185d909c  vmovaps xmm11, [rsp+0xA0]
000074da185d90a5  vmovaps xmm12, [rsp+0xB0]
000074da185d90ae  vmovaps xmm13, [rsp+0xC0]
000074da185d90b7  vmovaps xmm14, [rsp+0xD0]
000074da185d90c0  vmovaps xmm15, [rsp+0xE0]
000074da185d90c9  add rsp, 0xF0
000074da185d90d0  pop r11
000074da185d90d2  pop r10
000074da185d90d4  pop r9
000074da185d90d6  pop r8
000074da185d90d8  pop rsi
000074da185d90d9  pop rdi
000074da185d90da  pop rdx
000074da185d90db  pop rcx
000074da185d90dc  pop rax
000074da185d90dd  add rsp, 0x08
000074da185d90e1  jmp 0x000074DA185D6B6D
000074da185d90e6  sub rsp, 0x08
000074da185d90ea  push rax
000074da185d90eb  push rcx
000074da185d90ec  push rdx
000074da185d90ed  push rdi
000074da185d90ee  push rsi
000074da185d90ef  push r8
000074da185d90f1  push r9
000074da185d90f3  push r10
000074da185d90f5  push r11
000074da185d90f7  sub rsp, 0xF0
000074da185d90fe  vmovaps [rsp], xmm0
000074da185d9103  vmovaps [rsp+0x10], xmm1
000074da185d9109  vmovaps [rsp+0x20], xmm2
000074da185d910f  vmovaps [rsp+0x30], xmm3
000074da185d9115  vmovaps [rsp+0x40], xmm4
000074da185d911b  vmovaps [rsp+0x50], xmm5
000074da185d9121  vmovaps [rsp+0x60], xmm6
000074da185d9127  vmovaps [rsp+0x70], xmm7
000074da185d912d  vmovaps [rsp+0x80], xmm8
000074da185d9136  vmovaps [rsp+0x90], xmm9
000074da185d913f  vmovaps [rsp+0xA0], xmm10
000074da185d9148  vmovaps [rsp+0xB0], xmm11
000074da185d9151  vmovaps [rsp+0xC0], xmm13
000074da185d915a  vmovaps [rsp+0xD0], xmm14
000074da185d9163  vmovaps [rsp+0xE0], xmm15
000074da185d916c  sub rsp, 0x40
000074da185d9170  lea rdi, [rsp]
000074da185d9174  lea rsi, [rsp+0x10]
000074da185d9179  lea rdx, [rsp+0x20]
000074da185d917e  lea rcx, [rsp+0x30]
000074da185d9183  mov r8d, 0x00
000074da185d9189  lea r9, [r15+0x3A8]
000074da185d9190  movaps [rdi], xmm12
000074da185d9194  movaps [rsi], xmm11
000074da185d9198  movaps [rdx], xmm15
000074da185d919c  movaps [rcx], xmm14
000074da185d91a0  mov rax, 0x5946061DFA50
000074da185d91aa  call rax
000074da185d91ac  movaps xmm12, [rsp]
000074da185d91b1  add rsp, 0x40
000074da185d91b5  vmovaps xmm0, [rsp]
000074da185d91ba  vmovaps xmm1, [rsp+0x10]
000074da185d91c0  vmovaps xmm2, [rsp+0x20]
000074da185d91c6  vmovaps xmm3, [rsp+0x30]
000074da185d91cc  vmovaps xmm4, [rsp+0x40]
000074da185d91d2  vmovaps xmm5, [rsp+0x50]
000074da185d91d8  vmovaps xmm6, [rsp+0x60]
000074da185d91de  vmovaps xmm7, [rsp+0x70]
000074da185d91e4  vmovaps xmm8, [rsp+0x80]
000074da185d91ed  vmovaps xmm9, [rsp+0x90]
000074da185d91f6  vmovaps xmm10, [rsp+0xA0]
000074da185d91ff  vmovaps xmm11, [rsp+0xB0]
000074da185d9208  vmovaps xmm13, [rsp+0xC0]
000074da185d9211  vmovaps xmm14, [rsp+0xD0]
000074da185d921a  vmovaps xmm15, [rsp+0xE0]
000074da185d9223  add rsp, 0xF0
000074da185d922a  pop r11
000074da185d922c  pop r10
000074da185d922e  pop r9
000074da185d9230  pop r8
000074da185d9232  pop rsi
000074da185d9233  pop rdi
000074da185d9234  pop rdx
000074da185d9235  pop rcx
000074da185d9236  pop rax
000074da185d9237  add rsp, 0x08
000074da185d923b  jmp 0x000074DA185D6B96
000074da185d9240  sub rsp, 0x08
000074da185d9244  push rax
000074da185d9245  push rcx
000074da185d9246  push rdx
000074da185d9247  push rdi
000074da185d9248  push rsi
000074da185d9249  push r8
000074da185d924b  push r9
000074da185d924d  push r10
000074da185d924f  push r11
000074da185d9251  sub rsp, 0xF0
000074da185d9258  vmovaps [rsp], xmm0
000074da185d925d  vmovaps [rsp+0x10], xmm1
000074da185d9263  vmovaps [rsp+0x20], xmm2
000074da185d9269  vmovaps [rsp+0x30], xmm3
000074da185d926f  vmovaps [rsp+0x40], xmm4
000074da185d9275  vmovaps [rsp+0x50], xmm5
000074da185d927b  vmovaps [rsp+0x60], xmm6
000074da185d9281  vmovaps [rsp+0x70], xmm7
000074da185d9287  vmovaps [rsp+0x80], xmm8
000074da185d9290  vmovaps [rsp+0x90], xmm9
000074da185d9299  vmovaps [rsp+0xA0], xmm10
000074da185d92a2  vmovaps [rsp+0xB0], xmm12
000074da185d92ab  vmovaps [rsp+0xC0], xmm13
000074da185d92b4  vmovaps [rsp+0xD0], xmm14
000074da185d92bd  vmovaps [rsp+0xE0], xmm15
000074da185d92c6  sub rsp, 0x40
000074da185d92ca  lea rdi, [rsp]
000074da185d92ce  lea rsi, [rsp+0x10]
000074da185d92d3  lea rdx, [rsp+0x20]
000074da185d92d8  lea rcx, [rsp+0x30]
000074da185d92dd  mov r8d, 0x00
000074da185d92e3  lea r9, [r15+0x3A8]
000074da185d92ea  movaps [rdi], xmm11
000074da185d92ee  movaps [rsi], xmm10
000074da185d92f2  movaps [rdx], xmm13
000074da185d92f6  movaps [rcx], xmm15
000074da185d92fa  mov rax, 0x5946061DFA50
000074da185d9304  call rax
000074da185d9306  movaps xmm11, [rsp]
000074da185d930b  add rsp, 0x40
000074da185d930f  vmovaps xmm0, [rsp]
000074da185d9314  vmovaps xmm1, [rsp+0x10]
000074da185d931a  vmovaps xmm2, [rsp+0x20]
000074da185d9320  vmovaps xmm3, [rsp+0x30]
000074da185d9326  vmovaps xmm4, [rsp+0x40]
000074da185d932c  vmovaps xmm5, [rsp+0x50]
000074da185d9332  vmovaps xmm6, [rsp+0x60]
000074da185d9338  vmovaps xmm7, [rsp+0x70]
000074da185d933e  vmovaps xmm8, [rsp+0x80]
000074da185d9347  vmovaps xmm9, [rsp+0x90]
000074da185d9350  vmovaps xmm10, [rsp+0xA0]
000074da185d9359  vmovaps xmm12, [rsp+0xB0]
000074da185d9362  vmovaps xmm13, [rsp+0xC0]
000074da185d936b  vmovaps xmm14, [rsp+0xD0]
000074da185d9374  vmovaps xmm15, [rsp+0xE0]
000074da185d937d  add rsp, 0xF0
000074da185d9384  pop r11
000074da185d9386  pop r10
000074da185d9388  pop r9
000074da185d938a  pop r8
000074da185d938c  pop rsi
000074da185d938d  pop rdi
000074da185d938e  pop rdx
000074da185d938f  pop rcx
000074da185d9390  pop rax
000074da185d9391  add rsp, 0x08
000074da185d9395  jmp 0x000074DA185D6BBF
000074da185d939a  call 0x000074DA184E5820
000074da185d939f  jmp 0x000074DA185D6BCC
000074da185d93a4  call 0x000074DA184E45A0
000074da185d93a9  jmp 0x000074DA185D6BD9
000074da185d93ae  sub rsp, 0x08
000074da185d93b2  push rax
000074da185d93b3  push rcx
000074da185d93b4  push rdx
000074da185d93b5  push rdi
000074da185d93b6  push rsi
000074da185d93b7  push r8
000074da185d93b9  push r9
000074da185d93bb  push r10
000074da185d93bd  push r11
000074da185d93bf  sub rsp, 0xF0
000074da185d93c6  vmovaps [rsp], xmm0
000074da185d93cb  vmovaps [rsp+0x10], xmm1
000074da185d93d1  vmovaps [rsp+0x20], xmm2
000074da185d93d7  vmovaps [rsp+0x30], xmm3
000074da185d93dd  vmovaps [rsp+0x40], xmm4
000074da185d93e3  vmovaps [rsp+0x50], xmm5
000074da185d93e9  vmovaps [rsp+0x60], xmm6
000074da185d93ef  vmovaps [rsp+0x70], xmm7
000074da185d93f5  vmovaps [rsp+0x80], xmm8
000074da185d93fe  vmovaps [rsp+0x90], xmm9
000074da185d9407  vmovaps [rsp+0xA0], xmm11
000074da185d9410  vmovaps [rsp+0xB0], xmm12
000074da185d9419  vmovaps [rsp+0xC0], xmm13
000074da185d9422  vmovaps [rsp+0xD0], xmm14
000074da185d942b  vmovaps [rsp+0xE0], xmm15
000074da185d9434  sub rsp, 0x40
000074da185d9438  lea rdi, [rsp]
000074da185d943c  lea rsi, [rsp+0x10]
000074da185d9441  lea rdx, [rsp+0x20]
000074da185d9446  lea rcx, [rsp+0x30]
000074da185d944b  mov r8d, 0x00
000074da185d9451  lea r9, [r15+0x3A8]
000074da185d9458  movaps [rdi], xmm10
000074da185d945c  movaps [rsi], xmm8
000074da185d9460  movaps [rdx], xmm1
000074da185d9463  movaps [rcx], xmm13
000074da185d9467  mov rax, 0x5946061DFA50
000074da185d9471  call rax
000074da185d9473  movaps xmm10, [rsp]
000074da185d9478  add rsp, 0x40
000074da185d947c  vmovaps xmm0, [rsp]
000074da185d9481  vmovaps xmm1, [rsp+0x10]
000074da185d9487  vmovaps xmm2, [rsp+0x20]
000074da185d948d  vmovaps xmm3, [rsp+0x30]
000074da185d9493  vmovaps xmm4, [rsp+0x40]
000074da185d9499  vmovaps xmm5, [rsp+0x50]
000074da185d949f  vmovaps xmm6, [rsp+0x60]
000074da185d94a5  vmovaps xmm7, [rsp+0x70]
000074da185d94ab  vmovaps xmm8, [rsp+0x80]
000074da185d94b4  vmovaps xmm9, [rsp+0x90]
000074da185d94bd  vmovaps xmm11, [rsp+0xA0]
000074da185d94c6  vmovaps xmm12, [rsp+0xB0]
000074da185d94cf  vmovaps xmm13, [rsp+0xC0]
000074da185d94d8  vmovaps xmm14, [rsp+0xD0]
000074da185d94e1  vmovaps xmm15, [rsp+0xE0]
000074da185d94ea  add rsp, 0xF0
000074da185d94f1  pop r11
000074da185d94f3  pop r10
000074da185d94f5  pop r9
000074da185d94f7  pop r8
000074da185d94f9  pop rsi
000074da185d94fa  pop rdi
000074da185d94fb  pop rdx
000074da185d94fc  pop rcx
000074da185d94fd  pop rax
000074da185d94fe  add rsp, 0x08
000074da185d9502  jmp 0x000074DA185D6C0F
000074da185d9507  call 0x000074DA184D64F0
000074da185d950c  jmp 0x000074DA185D6C21
000074da185d9511  sub rsp, 0x08
000074da185d9515  push rax
000074da185d9516  push rcx
000074da185d9517  push rdx
000074da185d9518  push rdi
000074da185d9519  push rsi
000074da185d951a  push r8
000074da185d951c  push r9
000074da185d951e  push r10
000074da185d9520  push r11
000074da185d9522  sub rsp, 0xF0
000074da185d9529  vmovaps [rsp], xmm0
000074da185d952e  vmovaps [rsp+0x10], xmm1
000074da185d9534  vmovaps [rsp+0x20], xmm2
000074da185d953a  vmovaps [rsp+0x30], xmm3
000074da185d9540  vmovaps [rsp+0x40], xmm4
000074da185d9546  vmovaps [rsp+0x50], xmm5
000074da185d954c  vmovaps [rsp+0x60], xmm6
000074da185d9552  vmovaps [rsp+0x70], xmm7
000074da185d9558  vmovaps [rsp+0x80], xmm8
000074da185d9561  vmovaps [rsp+0x90], xmm10
000074da185d956a  vmovaps [rsp+0xA0], xmm11
000074da185d9573  vmovaps [rsp+0xB0], xmm12
000074da185d957c  vmovaps [rsp+0xC0], xmm13
000074da185d9585  vmovaps [rsp+0xD0], xmm14
000074da185d958e  vmovaps [rsp+0xE0], xmm15
000074da185d9597  sub rsp, 0x40
000074da185d959b  lea rdi, [rsp]
000074da185d959f  lea rsi, [rsp+0x10]
000074da185d95a4  lea rdx, [rsp+0x20]
000074da185d95a9  lea rcx, [rsp+0x30]
000074da185d95ae  mov r8d, 0x00
000074da185d95b4  lea r9, [r15+0x3A8]
000074da185d95bb  movaps [rdi], xmm9
000074da185d95bf  movaps [rsi], xmm7
000074da185d95c2  movaps [rdx], xmm14
000074da185d95c6  movaps [rcx], xmm13
000074da185d95ca  mov rax, 0x5946061DFA50
000074da185d95d4  call rax
000074da185d95d6  movaps xmm9, [rsp]
000074da185d95db  add rsp, 0x40
000074da185d95df  vmovaps xmm0, [rsp]
000074da185d95e4  vmovaps xmm1, [rsp+0x10]
000074da185d95ea  vmovaps xmm2, [rsp+0x20]
000074da185d95f0  vmovaps xmm3, [rsp+0x30]
000074da185d95f6  vmovaps xmm4, [rsp+0x40]
000074da185d95fc  vmovaps xmm5, [rsp+0x50]
000074da185d9602  vmovaps xmm6, [rsp+0x60]
000074da185d9608  vmovaps xmm7, [rsp+0x70]
000074da185d960e  vmovaps xmm8, [rsp+0x80]
000074da185d9617  vmovaps xmm10, [rsp+0x90]
000074da185d9620  vmovaps xmm11, [rsp+0xA0]
000074da185d9629  vmovaps xmm12, [rsp+0xB0]
000074da185d9632  vmovaps xmm13, [rsp+0xC0]
000074da185d963b  vmovaps xmm14, [rsp+0xD0]
000074da185d9644  vmovaps xmm15, [rsp+0xE0]
000074da185d964d  add rsp, 0xF0
000074da185d9654  pop r11
000074da185d9656  pop r10
000074da185d9658  pop r9
000074da185d965a  pop r8
000074da185d965c  pop rsi
000074da185d965d  pop rdi
000074da185d965e  pop rdx
000074da185d965f  pop rcx
000074da185d9660  pop rax
000074da185d9661  add rsp, 0x08
000074da185d9665  jmp 0x000074DA185D6C4F
000074da185d966a  sub rsp, 0x08
000074da185d966e  push rax
000074da185d966f  push rcx
000074da185d9670  push rdx
000074da185d9671  push rdi
000074da185d9672  push rsi
000074da185d9673  push r8
000074da185d9675  push r9
000074da185d9677  push r10
000074da185d9679  push r11
000074da185d967b  sub rsp, 0xF0
000074da185d9682  vmovaps [rsp], xmm0
000074da185d9687  vmovaps [rsp+0x10], xmm1
000074da185d968d  vmovaps [rsp+0x20], xmm2
000074da185d9693  vmovaps [rsp+0x30], xmm3
000074da185d9699  vmovaps [rsp+0x40], xmm4
000074da185d969f  vmovaps [rsp+0x50], xmm5
000074da185d96a5  vmovaps [rsp+0x60], xmm6
000074da185d96ab  vmovaps [rsp+0x70], xmm7
000074da185d96b1  vmovaps [rsp+0x80], xmm8
000074da185d96ba  vmovaps [rsp+0x90], xmm9
000074da185d96c3  vmovaps [rsp+0xA0], xmm10
000074da185d96cc  vmovaps [rsp+0xB0], xmm11
000074da185d96d5  vmovaps [rsp+0xC0], xmm12
000074da185d96de  vmovaps [rsp+0xD0], xmm14
000074da185d96e7  vmovaps [rsp+0xE0], xmm15
000074da185d96f0  sub rsp, 0x40
000074da185d96f4  lea rdi, [rsp]
000074da185d96f8  lea rsi, [rsp+0x10]
000074da185d96fd  lea rdx, [rsp+0x20]
000074da185d9702  lea rcx, [rsp+0x30]
000074da185d9707  mov r8d, 0x00
000074da185d970d  lea r9, [r15+0x3A8]
000074da185d9714  movaps [rdi], xmm13
000074da185d9718  movaps [rsi], xmm12
000074da185d971c  movaps [rdx], xmm15
000074da185d9720  movaps [rcx], xmm14
000074da185d9724  mov rax, 0x5946061DFA50
000074da185d972e  call rax
000074da185d9730  movaps xmm13, [rsp]
000074da185d9735  add rsp, 0x40
000074da185d9739  vmovaps xmm0, [rsp]
000074da185d973e  vmovaps xmm1, [rsp+0x10]
000074da185d9744  vmovaps xmm2, [rsp+0x20]
000074da185d974a  vmovaps xmm3, [rsp+0x30]
000074da185d9750  vmovaps xmm4, [rsp+0x40]
000074da185d9756  vmovaps xmm5, [rsp+0x50]
000074da185d975c  vmovaps xmm6, [rsp+0x60]
000074da185d9762  vmovaps xmm7, [rsp+0x70]
000074da185d9768  vmovaps xmm8, [rsp+0x80]
000074da185d9771  vmovaps xmm9, [rsp+0x90]
000074da185d977a  vmovaps xmm10, [rsp+0xA0]
000074da185d9783  vmovaps xmm11, [rsp+0xB0]
000074da185d978c  vmovaps xmm12, [rsp+0xC0]
000074da185d9795  vmovaps xmm14, [rsp+0xD0]
000074da185d979e  vmovaps xmm15, [rsp+0xE0]
000074da185d97a7  add rsp, 0xF0
000074da185d97ae  pop r11
000074da185d97b0  pop r10
000074da185d97b2  pop r9
000074da185d97b4  pop r8
000074da185d97b6  pop rsi
000074da185d97b7  pop rdi
000074da185d97b8  pop rdx
000074da185d97b9  pop rcx
000074da185d97ba  pop rax
000074da185d97bb  add rsp, 0x08
000074da185d97bf  jmp 0x000074DA185D6C7D
000074da185d97c4  sub rsp, 0x08
000074da185d97c8  push rax
000074da185d97c9  push rcx
000074da185d97ca  push rdx
000074da185d97cb  push rdi
000074da185d97cc  push rsi
000074da185d97cd  push r8
000074da185d97cf  push r9
000074da185d97d1  push r10
000074da185d97d3  push r11
000074da185d97d5  sub rsp, 0xF0
000074da185d97dc  vmovaps [rsp], xmm0
000074da185d97e1  vmovaps [rsp+0x10], xmm1
000074da185d97e7  vmovaps [rsp+0x20], xmm2
000074da185d97ed  vmovaps [rsp+0x30], xmm3
000074da185d97f3  vmovaps [rsp+0x40], xmm4
000074da185d97f9  vmovaps [rsp+0x50], xmm5
000074da185d97ff  vmovaps [rsp+0x60], xmm6
000074da185d9805  vmovaps [rsp+0x70], xmm7
000074da185d980b  vmovaps [rsp+0x80], xmm8
000074da185d9814  vmovaps [rsp+0x90], xmm9
000074da185d981d  vmovaps [rsp+0xA0], xmm10
000074da185d9826  vmovaps [rsp+0xB0], xmm11
000074da185d982f  vmovaps [rsp+0xC0], xmm12
000074da185d9838  vmovaps [rsp+0xD0], xmm13
000074da185d9841  vmovaps [rsp+0xE0], xmm15
000074da185d984a  sub rsp, 0x40
000074da185d984e  lea rdi, [rsp]
000074da185d9852  lea rsi, [rsp+0x10]
000074da185d9857  lea rdx, [rsp+0x20]
000074da185d985c  lea rcx, [rsp+0x30]
000074da185d9861  mov r8d, 0x00
000074da185d9867  lea r9, [r15+0x3A8]
000074da185d986e  movaps [rdi], xmm14
000074da185d9872  movaps [rsi], xmm11
000074da185d9876  movaps [rdx], xmm1
000074da185d9879  movaps [rcx], xmm15
000074da185d987d  mov rax, 0x5946061DFA50
000074da185d9887  call rax
000074da185d9889  movaps xmm14, [rsp]
000074da185d988e  add rsp, 0x40
000074da185d9892  vmovaps xmm0, [rsp]
000074da185d9897  vmovaps xmm1, [rsp+0x10]
000074da185d989d  vmovaps xmm2, [rsp+0x20]
000074da185d98a3  vmovaps xmm3, [rsp+0x30]
000074da185d98a9  vmovaps xmm4, [rsp+0x40]
000074da185d98af  vmovaps xmm5, [rsp+0x50]
000074da185d98b5  vmovaps xmm6, [rsp+0x60]
000074da185d98bb  vmovaps xmm7, [rsp+0x70]
000074da185d98c1  vmovaps xmm8, [rsp+0x80]
000074da185d98ca  vmovaps xmm9, [rsp+0x90]
000074da185d98d3  vmovaps xmm10, [rsp+0xA0]
000074da185d98dc  vmovaps xmm11, [rsp+0xB0]
000074da185d98e5  vmovaps xmm12, [rsp+0xC0]
000074da185d98ee  vmovaps xmm13, [rsp+0xD0]
000074da185d98f7  vmovaps xmm15, [rsp+0xE0]
000074da185d9900  add rsp, 0xF0
000074da185d9907  pop r11
000074da185d9909  pop r10
000074da185d990b  pop r9
000074da185d990d  pop r8
000074da185d990f  pop rsi
000074da185d9910  pop rdi
000074da185d9911  pop rdx
000074da185d9912  pop rcx
000074da185d9913  pop rax
000074da185d9914  add rsp, 0x08
000074da185d9918  jmp 0x000074DA185D6CAB
000074da185d991d  call 0x000074DA184ACF70
000074da185d9922  jmp 0x000074DA185D6CB9
000074da185d9927  call 0x000074DA1840C380
000074da185d992c  jmp 0x000074DA185D6CC3
000074da185d9931  call 0x000074DA18408C20
000074da185d9936  jmp 0x000074DA185D6CCD
000074da185d993b  call 0x000074DA1840D600
000074da185d9940  jmp 0x000074DA185D6CD7
000074da185d9945  int3
000074da185d9946  nop [rax+rax*1], ax
000074da185d994f  nop
000074da185d9950  mov eax, [r15+0x48]
000074da185d9954  lea r14d, [eax+0x01]
000074da185d9959  mov [rsp+0x10], r14d
000074da185d995e  mov r14d, r14d
000074da185d9961  mov [r15+0x48], r14
000074da185d9965  xor eax, eax
000074da185d9967  mov r14d, [rsp+0x10]
000074da185d996c  cmp r14d, 0x1F4
000074da185d9973  cmc
000074da185d9974  lahf
000074da185d9975  seto al
000074da185d9978  mov [r15+0x108], eax
000074da185d997f  mov eax, [r15+0x108]
000074da185d9986  sahf
000074da185d9987  jnz 0x000074DA185D99B9
000074da185d9989  cmp dword ptr [r15+0x318], 0x00
000074da185d9991  jz 0x000074DA185DD2E0
000074da185d9997  nop [rax+rax*1], ax
000074da185d99a0  nop [rax+rax*1], eax
000074da185d99a8  mov eax, 0x410670
000074da185d99ad  mov [r15+0x100], rax
000074da185d99b4  jmp 0x000074DA183FE110
000074da185d99b9  cmp dword ptr [r15+0x318], 0x00
000074da185d99c1  jz 0x000074DA185D99F0
000074da185d99c7  nop [rax+rax*1], ax
000074da185d99d0  nop [rax+rax*1], eax
000074da185d99d8  mov eax, 0x4104EC
000074da185d99dd  mov [r15+0x100], rax
000074da185d99e4  jmp 0x000074DA183FE110
000074da185d99e9  int3
000074da185d99ea  int3
000074da185d99eb  nop [rax+rax*1], eax
000074da185d99f0  mov rax, [r15+0x40]
000074da185d99f4  vxorps xmm1, xmm1, xmm1
000074da185d99f8  vpbroadcastq xmm1, xmm1
000074da185d99fd  vxorps xmm15, xmm15, xmm15
000074da185d9a02  vpbroadcastq xmm15, xmm15
000074da185d9a07  lea r14, [rax+0x30]
000074da185d9a0b  mov r12, [r13+r14*1]
000074da185d9a10  lea r14, [rax+0x38]
000074da185d9a14  mov r11, [r13+r14*1]
000074da185d9a19  movq xmm14, r12
000074da185d9a1e  movq xmm13, r11
000074da185d9a23  movq xmm14, xmm14
000074da185d9a28  movq xmm13, xmm13
000074da185d9a2d  vmovaps [rsp+0x10], xmm13
000074da185d9a33  movq xmm13, xmm13
000074da185d9a38  movaps [r15+0x270], xmm13
000074da185d9a40  movaps xmm13, [r15+0x160]
000074da185d9a48  vmovaps [rsp+0x20], xmm13
000074da185d9a4e  vmovaps xmm12, [rsp+0x20]
000074da185d9a54  por xmm13, xmm12
000074da185d9a59  lea r14, [rax+0x20]
000074da185d9a5d  mov r12, [r13+r14*1]
000074da185d9a62  lea r14, [rax+0x28]
000074da185d9a66  mov r11, [r13+r14*1]
000074da185d9a6b  movq xmm12, r12
000074da185d9a70  movq xmm11, r11
000074da185d9a75  movq xmm12, xmm12
000074da185d9a7a  movq xmm11, xmm11
000074da185d9a7f  movaps xmm10, [r15+0x2D0]
000074da185d9a87  vmovaps [rsp+0x20], xmm10
000074da185d9a8d  vmovaps xmm9, [rsp+0x20]
000074da185d9a93  por xmm10, xmm9
000074da185d9a98  movaps xmm9, [r15+0x300]
000074da185d9aa0  vmovaps [rsp+0x20], xmm9
000074da185d9aa6  vmovaps xmm8, [rsp+0x20]
000074da185d9aac  por xmm9, xmm8
000074da185d9ab1  movaps xmm8, [r15+0x2B0]
000074da185d9ab9  vmovaps [rsp+0x20], xmm8
000074da185d9abf  vmovaps xmm7, [rsp+0x20]
000074da185d9ac5  por xmm8, xmm7
000074da185d9aca  movaps xmm7, [r15+0x180]
000074da185d9ad2  vmovaps [rsp+0x20], xmm7
000074da185d9ad8  vmovaps xmm6, [rsp+0x20]
000074da185d9ade  por xmm7, xmm6
000074da185d9ae2  lea r14, [rax+0x10]
000074da185d9ae6  mov r12, [r13+r14*1]
000074da185d9aeb  lea r14, [rax+0x18]
000074da185d9aef  mov r11, [r13+r14*1]
000074da185d9af4  movq xmm6, r12
000074da185d9af9  movq xmm5, r11
000074da185d9afe  movq xmm6, xmm6
000074da185d9b02  movq xmm5, xmm5
000074da185d9b06  movaps xmm4, [r15+0x200]
000074da185d9b0e  vmovaps [rsp+0x20], xmm4
000074da185d9b14  vmovaps xmm3, [rsp+0x20]
000074da185d9b1a  por xmm4, xmm3
000074da185d9b1e  movaps xmm3, [r15+0x1F0]
000074da185d9b26  vmovaps [rsp+0x20], xmm3
000074da185d9b2c  vmovaps xmm2, [rsp+0x20]
000074da185d9b32  por xmm3, xmm2
000074da185d9b36  movaps xmm2, [r15+0x2E0]
000074da185d9b3e  vmovaps [rsp+0x20], xmm2
000074da185d9b44  vmovaps [rsp+0x30], xmm1
000074da185d9b4a  vmovaps xmm1, [rsp+0x20]
000074da185d9b50  por xmm2, xmm1
000074da185d9b54  movaps xmm1, [r15+0x2A0]
000074da185d9b5c  vmovaps [rsp+0x20], xmm1
000074da185d9b62  vmovaps [rsp+0x40], xmm15
000074da185d9b68  vmovaps xmm15, [rsp+0x20]
000074da185d9b6e  por xmm1, xmm15
000074da185d9b73  movaps xmm15, [r15+0x280]
000074da185d9b7b  vmovaps [rsp+0x20], xmm15
000074da185d9b81  vmovaps [rsp+0x50], xmm1
000074da185d9b87  vmovaps xmm1, [rsp+0x20]
000074da185d9b8d  por xmm15, xmm1
000074da185d9b92  movaps xmm1, [r15+0x1C0]
000074da185d9b9a  vmovaps [rsp+0x20], xmm1
000074da185d9ba0  vmovaps [rsp+0x60], xmm15
000074da185d9ba6  vmovaps xmm15, [rsp+0x20]
000074da185d9bac  por xmm1, xmm15
000074da185d9bb1  movaps xmm15, [r15+0x210]
000074da185d9bb9  vmovaps [rsp+0x20], xmm15
000074da185d9bbf  vmovaps [rsp+0x70], xmm1
000074da185d9bc5  vmovaps xmm1, [rsp+0x20]
000074da185d9bcb  por xmm15, xmm1
000074da185d9bd0  mov r14, [r13+rax*1]
000074da185d9bd5  vmovq xmm1, r14
000074da185d9bda  vpbroadcastq xmm1, xmm1
000074da185d9bdf  vmovaps [rsp+0x20], xmm1
000074da185d9be5  vxorps xmm1, xmm1, xmm1
000074da185d9be9  vpbroadcastq xmm1, xmm1
000074da185d9bee  mov r14, [r15+0xF8]
000074da185d9bf5  vmovaps [rsp+0x80], xmm1
000074da185d9bfe  movups xmm1, [r13+r14*1]
000074da185d9c04  vmovaps [rsp+0x90], xmm1
000074da185d9c0d  vxorps xmm1, xmm1, xmm1
000074da185d9c11  vpbroadcastq xmm1, xmm1
000074da185d9c16  lea r12, [rax+0x08]
000074da185d9c1a  mov rax, [r13+r12*1]
000074da185d9c1f  vmovaps [rsp+0xA0], xmm1
000074da185d9c28  movq xmm1, rax
000074da185d9c2d  movaps [r15+0x240], xmm1
000074da185d9c35  mov rax, [r15+0x50]
000074da185d9c39  mov [r15+0x60], rax
000074da185d9c3d  mov qword ptr [r15+0x58], 0x40
000074da185d9c45  vmovaps xmm1, [rsp+0x30]
000074da185d9c4b  vmovaps [rsp+0x30], xmm15
000074da185d9c51  vmovaps xmm15, [rsp+0x90]
000074da185d9c5a  vmovaps [rsp+0x90], xmm14
000074da185d9c63  vmovaps xmm14, [rsp+0x20]
000074da185d9c69  vmovaps [rsp+0x20], xmm13
000074da185d9c6f  vmovaps [rsp+0xB0], xmm12
000074da185d9c78  movaps xmm13, xmm1
000074da185d9c7c  vfmadd231pd xmm13, xmm15, xmm14
000074da185d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d9c87  vptest xmm12, xmm12
000074da185d9c8c  jnz 0x000074DA185DA72F
000074da185d9c92  movaps xmm1, [r15+0x250]
000074da185d9c9a  vmovaps xmm15, [rsp+0x40]
000074da185d9ca0  vmovaps [rsp+0x40], xmm13
000074da185d9ca6  movaps xmm12, xmm15
000074da185d9caa  vfmadd231pd xmm12, xmm1, xmm14
000074da185d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
000074da185d9cb5  vptest xmm13, xmm13
000074da185d9cba  jnz 0x000074DA185DA888
000074da185d9cc0  movaps xmm15, [r15+0x1E0]
000074da185d9cc8  vmovaps [rsp+0xC0], xmm15
000074da185d9cd1  vmovaps xmm13, [rsp+0xC0]
000074da185d9cda  por xmm15, xmm13
000074da185d9cdf  movaps xmm13, [r15+0x1D0]
000074da185d9ce7  vmovaps [rsp+0xC0], xmm13
000074da185d9cf0  vmovaps [rsp+0xD0], xmm1
000074da185d9cf9  vmovaps xmm1, [rsp+0xC0]
000074da185d9d02  por xmm13, xmm1
000074da185d9d07  movaps xmm1, [r15+0x2C0]
000074da185d9d0f  vmovaps [rsp+0xC0], xmm1
000074da185d9d18  vmovaps [rsp+0xE0], xmm15
000074da185d9d21  vmovaps xmm15, [rsp+0xC0]
000074da185d9d2a  por xmm1, xmm15
000074da185d9d2f  movaps xmm15, [r15+0x290]
000074da185d9d37  vmovaps [rsp+0xC0], xmm15
000074da185d9d40  vmovaps [rsp+0xF0], xmm1
000074da185d9d49  vmovaps xmm1, [rsp+0xC0]
000074da185d9d52  por xmm15, xmm1
000074da185d9d57  movaps xmm1, [r15+0x260]
000074da185d9d5f  vmovaps [rsp+0xC0], xmm1
000074da185d9d68  vmovaps [rsp+0x100], xmm15
000074da185d9d71  vmovaps xmm15, [rsp+0xC0]
000074da185d9d7a  por xmm1, xmm15
000074da185d9d7f  vmovaps xmm15, [rsp+0xD0]
000074da185d9d88  vmovaps [rsp+0xC0], xmm1
000074da185d9d91  vmovaps xmm1, [rsp+0xD0]
000074da185d9d9a  por xmm15, xmm1
000074da185d9d9f  lea r12, [r14+0xC0]
000074da185d9da6  movups xmm1, [r13+r12*1]
000074da185d9dac  mov [rsp+0xD0], rax
000074da185d9db4  xor eax, eax
000074da185d9db6  mov r12d, 0x40
000074da185d9dbc  mov r11d, 0x200
000074da185d9dc2  cmp r12, r11
000074da185d9dc5  cmc
000074da185d9dc6  lahf
000074da185d9dc7  seto al
000074da185d9dca  mov [r15+0x108], eax
000074da185d9dd1  vmovaps [rsp+0x110], xmm1
000074da185d9dda  vmovaps xmm1, [rsp+0x80]
000074da185d9de3  vmovaps [rsp+0x80], xmm15
000074da185d9dec  vmovaps xmm15, [rsp+0x110]
000074da185d9df5  vmovaps [rsp+0x110], xmm13
000074da185d9dfe  vmovaps [rsp+0x120], xmm12
000074da185d9e07  movaps xmm13, xmm1
000074da185d9e0b  vfmadd231pd xmm13, xmm15, xmm14
000074da185d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d9e16  vptest xmm12, xmm12
000074da185d9e1b  jnz 0x000074DA185DA9EB
000074da185d9e21  lea rax, [r14+0xB0]
000074da185d9e28  movups xmm1, [r13+rax*1]
000074da185d9e2e  vmovaps xmm15, [rsp+0xA0]
000074da185d9e37  vmovaps [rsp+0xA0], xmm13
000074da185d9e40  movaps xmm12, xmm15
000074da185d9e44  vfmadd231pd xmm12, xmm1, xmm14
000074da185d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
000074da185d9e4f  vptest xmm13, xmm13
000074da185d9e54  jnz 0x000074DA185DAB4E
000074da185d9e5a  vmovaps xmm1, [rsp+0x30]
000074da185d9e60  vmovaps xmm15, [rsp+0x30]
000074da185d9e66  por xmm1, xmm15
000074da185d9e6b  movaps [r15+0x210], xmm1
000074da185d9e73  vmovaps xmm15, [rsp+0x70]
000074da185d9e79  vmovaps xmm14, [rsp+0x70]
000074da185d9e7f  por xmm15, xmm14
000074da185d9e84  movaps [r15+0x1C0], xmm15
000074da185d9e8c  vmovaps xmm14, [rsp+0x60]
000074da185d9e92  vmovaps xmm13, [rsp+0x60]
000074da185d9e98  por xmm14, xmm13
000074da185d9e9d  movaps [r15+0x280], xmm14
000074da185d9ea5  vmovaps xmm13, [rsp+0x50]
000074da185d9eab  vmovaps [rsp+0x30], xmm1
000074da185d9eb1  vmovaps xmm1, [rsp+0x50]
000074da185d9eb7  por xmm13, xmm1
000074da185d9ebc  movaps [r15+0x2A0], xmm13
000074da185d9ec4  vmovaps [rsp+0x50], xmm2
000074da185d9eca  vmovaps xmm1, [rsp+0x50]
000074da185d9ed0  por xmm2, xmm1
000074da185d9ed4  movaps [r15+0x2E0], xmm2
000074da185d9edc  vmovaps [rsp+0x50], xmm3
000074da185d9ee2  vmovaps xmm1, [rsp+0x50]
000074da185d9ee8  por xmm3, xmm1
000074da185d9eec  movaps [r15+0x1F0], xmm3
000074da185d9ef4  vmovaps xmm1, [rsp+0x80]
000074da185d9efd  vmovaps [rsp+0x50], xmm15
000074da185d9f03  vmovaps xmm15, [rsp+0x80]
000074da185d9f0c  por xmm1, xmm15
000074da185d9f11  movaps [r15+0x250], xmm1
000074da185d9f19  vmovaps xmm1, [rsp+0xC0]
000074da185d9f22  vmovaps xmm15, [rsp+0xC0]
000074da185d9f2b  por xmm1, xmm15
000074da185d9f30  movaps [r15+0x260], xmm1
000074da185d9f38  vmovaps xmm15, [rsp+0x100]
000074da185d9f41  vmovaps [rsp+0x60], xmm1
000074da185d9f47  vmovaps xmm1, [rsp+0x100]
000074da185d9f50  por xmm15, xmm1
000074da185d9f55  movaps [r15+0x290], xmm15
000074da185d9f5d  vmovaps xmm1, [rsp+0xF0]
000074da185d9f66  vmovaps [rsp+0x70], xmm15
000074da185d9f6c  vmovaps xmm15, [rsp+0xF0]
000074da185d9f75  por xmm1, xmm15
000074da185d9f7a  movaps [r15+0x2C0], xmm1
000074da185d9f82  movq xmm15, qword ptr [r15+0x240]
000074da185d9f8b  vmovaps [rsp+0x80], xmm15
000074da185d9f94  vpermilpd xmm15, xmm15, 0x00
000074da185d9f9a  vmovaps [rsp+0xC0], xmm1
000074da185d9fa3  vmovaps xmm1, [rsp+0x40]
000074da185d9fa9  vmovaps [rsp+0x40], xmm15
000074da185d9faf  vmovaps xmm15, [rsp+0x30]
000074da185d9fb5  vmovaps [rsp+0x30], xmm14
000074da185d9fbb  vmovaps xmm14, [rsp+0x40]
000074da185d9fc1  vmovaps [rsp+0x40], xmm13
000074da185d9fc7  vmovaps [rsp+0xF0], xmm12
000074da185d9fd0  movaps xmm13, xmm1
000074da185d9fd4  vfmadd231pd xmm13, xmm15, xmm14
000074da185d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
000074da185d9fdf  vptest xmm12, xmm12
000074da185d9fe4  jnz 0x000074DA185DACA7
000074da185d9fea  vmovaps xmm1, [rsp+0x80]
000074da185d9ff3  vpermilpd xmm1, xmm1, 0x00
000074da185d9ff9  vmovaps xmm15, [rsp+0xA0]
000074da185da002  movaps xmm14, xmm15
000074da185da006  vfmadd231pd xmm14, xmm2, xmm1
000074da185da00b  vcmppd xmm12, xmm14, xmm14, 0x03
000074da185da011  vptest xmm12, xmm12
000074da185da016  jnz 0x000074DA185DAE00
000074da185da01c  vmovaps xmm1, [rsp+0x80]
000074da185da025  vpermilpd xmm1, xmm1, 0x00
000074da185da02b  vmovaps xmm15, [rsp+0x120]
000074da185da034  vmovaps xmm12, [rsp+0x50]
000074da185da03a  vmovaps [rsp+0x50], xmm14
000074da185da040  movaps xmm2, xmm15
000074da185da044  vfmadd231pd xmm2, xmm12, xmm1
000074da185da049  vcmppd xmm14, xmm2, xmm2, 0x03
000074da185da04e  vptest xmm14, xmm14
000074da185da053  jnz 0x000074DA185DAF58
000074da185da059  vmovaps xmm1, [rsp+0x110]
000074da185da062  vmovaps xmm15, [rsp+0x110]
000074da185da06b  por xmm1, xmm15
000074da185da070  movaps [r15+0x1D0], xmm1
000074da185da078  vmovaps xmm15, [rsp+0x80]
000074da185da081  vpermilpd xmm15, xmm15, 0x00
000074da185da087  vmovaps xmm14, [rsp+0xF0]
000074da185da090  vmovaps [rsp+0x80], xmm1
000074da185da099  movaps xmm12, xmm14
000074da185da09d  vfmadd231pd xmm12, xmm3, xmm15
000074da185da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
000074da185da0a8  vptest xmm1, xmm1
000074da185da0ad  jnz 0x000074DA185DB0AF
000074da185da0b3  vmovaps [rsp+0xA0], xmm4
000074da185da0bc  vmovaps xmm1, [rsp+0xA0]
000074da185da0c5  por xmm4, xmm1
000074da185da0c9  movaps [r15+0x200], xmm4
000074da185da0d1  vmovaps xmm1, [rsp+0xE0]
000074da185da0da  vmovaps xmm15, [rsp+0xE0]
000074da185da0e3  por xmm1, xmm15
000074da185da0e8  movaps [r15+0x1E0], xmm1
000074da185da0f0  vmovaps [rsp+0xA0], xmm8
000074da185da0f9  vmovaps xmm1, [rsp+0xA0]
000074da185da102  por xmm8, xmm1
000074da185da107  movaps [r15+0x2B0], xmm8
000074da185da10f  vmovaps [rsp+0xA0], xmm9
000074da185da118  vmovaps xmm1, [rsp+0xA0]
000074da185da121  por xmm9, xmm1
000074da185da126  movaps [r15+0x300], xmm9
000074da185da12e  vmovaps [rsp+0xA0], xmm6
000074da185da137  vpermilpd xmm6, xmm6, 0x00
000074da185da13d  vmovaps xmm14, [rsp+0x60]
000074da185da143  movaps xmm9, xmm13
000074da185da147  vfmadd231pd xmm9, xmm14, xmm6
000074da185da14c  vcmppd xmm3, xmm9, xmm9, 0x03
000074da185da152  vptest xmm3, xmm3
000074da185da157  jnz 0x000074DA185DB208
000074da185da15d  vmovaps xmm14, [rsp+0xA0]
000074da185da166  vpermilpd xmm14, xmm14, 0x00
000074da185da16c  vmovaps xmm13, [rsp+0x50]
000074da185da172  vmovaps xmm6, [rsp+0xC0]
000074da185da17b  vmovaps [rsp+0x50], xmm1
000074da185da181  movaps xmm3, xmm13
000074da185da185  vfmadd231pd xmm3, xmm6, xmm14
000074da185da18a  vcmppd xmm1, xmm3, xmm3, 0x03
000074da185da18f  vptest xmm1, xmm1
000074da185da194  jnz 0x000074DA185DB361
000074da185da19a  vmovaps xmm1, [rsp+0xA0]
000074da185da1a3  vpermilpd xmm1, xmm1, 0x00
000074da185da1a9  vmovaps xmm14, [rsp+0x30]
000074da185da1af  movaps xmm6, xmm2
000074da185da1b2  vfmadd231pd xmm6, xmm14, xmm1
000074da185da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
000074da185da1bc  vptest xmm13, xmm13
000074da185da1c1  jnz 0x000074DA185DB4B8
000074da185da1c7  vmovaps xmm1, [rsp+0xA0]
000074da185da1d0  vpermilpd xmm1, xmm1, 0x00
000074da185da1d6  vmovaps xmm14, [rsp+0x80]
000074da185da1df  movaps xmm13, xmm12
000074da185da1e3  vfmadd231pd xmm13, xmm14, xmm1
000074da185da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
000074da185da1ee  vptest xmm2, xmm2
000074da185da1f3  jnz 0x000074DA185DB60E
000074da185da1f9  vmovaps [rsp+0x30], xmm7
000074da185da1ff  vmovaps xmm1, [rsp+0x30]
000074da185da205  por xmm7, xmm1
000074da185da209  movaps [r15+0x180], xmm7
000074da185da211  vmovaps [rsp+0x30], xmm10
000074da185da217  vmovaps xmm1, [rsp+0x30]
000074da185da21d  por xmm10, xmm1
000074da185da222  movaps [r15+0x2D0], xmm10
000074da185da22a  vmovaps [rsp+0x30], xmm5
000074da185da230  vpermilpd xmm5, xmm5, 0x00
000074da185da236  vmovaps xmm14, [rsp+0x50]
000074da185da23c  movaps xmm12, xmm3
000074da185da240  vfmadd231pd xmm12, xmm14, xmm5
000074da185da245  vcmppd xmm10, xmm12, xmm12, 0x03
000074da185da24b  vptest xmm10, xmm10
000074da185da250  jnz 0x000074DA185DB767
000074da185da256  vmovaps xmm14, [rsp+0x30]
000074da185da25c  vpermilpd xmm14, xmm14, 0x00
000074da185da262  movaps xmm10, xmm9
000074da185da266  vfmadd231pd xmm10, xmm7, xmm14
000074da185da26b  vcmppd xmm5, xmm10, xmm10, 0x03
000074da185da271  vptest xmm5, xmm5
000074da185da276  jnz 0x000074DA185DB8BF
000074da185da27c  lea rax, [r14+0x80]
000074da185da283  movups xmm14, [r13+rax*1]
000074da185da289  movaps [r15+0x2F0], xmm14
000074da185da291  vmovaps xmm9, [rsp+0x30]
000074da185da297  vpermilpd xmm9, xmm9, 0x00
000074da185da29d  vmovaps xmm7, [rsp+0x70]
000074da185da2a3  movaps xmm5, xmm6
000074da185da2a6  vfmadd231pd xmm5, xmm7, xmm9
000074da185da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
000074da185da2b0  vptest xmm3, xmm3
000074da185da2b5  jnz 0x000074DA185DBA22
000074da185da2bb  vmovaps xmm9, [rsp+0x30]
000074da185da2c1  vpermilpd xmm9, xmm9, 0x00
000074da185da2c7  movaps xmm7, xmm13
000074da185da2cb  vfmadd231pd xmm7, xmm1, xmm9
000074da185da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
000074da185da2d5  vptest xmm6, xmm6
000074da185da2da  jnz 0x000074DA185DBB78
000074da185da2e0  vmovaps xmm1, [rsp+0x20]
000074da185da2e6  vmovaps xmm13, [rsp+0x20]
000074da185da2ec  por xmm1, xmm13
000074da185da2f1  movaps [r15+0x160], xmm1
000074da185da2f9  lea rax, [r14+0x40]
000074da185da2fd  movups xmm13, [r13+rax*1]
000074da185da303  lea rax, [r14+0x50]
000074da185da307  movups xmm9, [r13+rax*1]
000074da185da30d  movaps [r15+0x1B0], xmm13
000074da185da315  movaps [r15+0x1A0], xmm9
000074da185da31d  movaps xmm6, [r15+0x190]
000074da185da325  vmovaps xmm3, [rsp+0xB0]
000074da185da32e  vpermilpd xmm3, xmm3, 0x00
000074da185da334  vmovaps [rsp+0x20], xmm1
000074da185da33a  movaps xmm2, xmm12
000074da185da33e  vfmadd231pd xmm2, xmm6, xmm3
000074da185da343  vcmppd xmm1, xmm2, xmm2, 0x03
000074da185da348  vptest xmm1, xmm1
000074da185da34d  jnz 0x000074DA185DBCE3
000074da185da353  vmovaps xmm1, [rsp+0xB0]
000074da185da35c  vpermilpd xmm1, xmm1, 0x00
000074da185da362  vmovaps xmm12, [rsp+0x20]
000074da185da368  movaps xmm6, xmm10
000074da185da36c  vfmadd231pd xmm6, xmm12, xmm1
000074da185da371  vcmppd xmm3, xmm6, xmm6, 0x03
000074da185da376  vptest xmm3, xmm3
000074da185da37b  jnz 0x000074DA185DBE39
000074da185da381  vmovaps xmm1, [rsp+0xB0]
000074da185da38a  vpermilpd xmm1, xmm1, 0x00
000074da185da390  vmovaps xmm12, [rsp+0x40]
000074da185da396  movaps xmm10, xmm5
000074da185da39a  vfmadd231pd xmm10, xmm12, xmm1
000074da185da39f  vcmppd xmm3, xmm10, xmm10, 0x03
000074da185da3a5  vptest xmm3, xmm3
000074da185da3aa  jnz 0x000074DA185DBF90
000074da185da3b0  vmovaps xmm1, [rsp+0xB0]
000074da185da3b9  vpermilpd xmm1, xmm1, 0x00
000074da185da3bf  movaps xmm12, xmm7
000074da185da3c3  vfmadd231pd xmm12, xmm15, xmm1
000074da185da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
000074da185da3ce  vptest xmm5, xmm5
000074da185da3d3  jnz 0x000074DA185DC0E8
000074da185da3d9  lea rax, [r14+0x60]
000074da185da3dd  movups xmm1, [r13+rax*1]
000074da185da3e3  lea rax, [r14+0x70]
000074da185da3e7  movups xmm15, [r13+rax*1]
000074da185da3ed  movaps [r15+0x150], xmm1
000074da185da3f5  movaps [r15+0x120], xmm15
000074da185da3fd  vmovaps [rsp+0x20], xmm11
000074da185da403  vpermilpd xmm11, xmm11, 0x00
000074da185da409  movaps xmm7, xmm2
000074da185da40c  vfmadd231pd xmm7, xmm9, xmm11
000074da185da411  vcmppd xmm5, xmm7, xmm7, 0x03
000074da185da416  vptest xmm5, xmm5
000074da185da41b  jnz 0x000074DA185DC254
000074da185da421  vmovaps xmm11, [rsp+0x20]
000074da185da427  vpermilpd xmm11, xmm11, 0x00
000074da185da42d  movaps xmm9, xmm6
000074da185da431  vfmadd231pd xmm9, xmm1, xmm11
000074da185da436  vcmppd xmm5, xmm9, xmm9, 0x03
000074da185da43c  vptest xmm5, xmm5
000074da185da441  jnz 0x000074DA185DC3AB
000074da185da447  vmovaps xmm1, [rsp+0x20]
000074da185da44d  vpermilpd xmm1, xmm1, 0x00
000074da185da453  movaps xmm11, xmm10
000074da185da457  vfmadd231pd xmm11, xmm8, xmm1
000074da185da45c  vcmppd xmm6, xmm11, xmm11, 0x03
000074da185da462  vptest xmm6, xmm6
000074da185da467  jnz 0x000074DA185DC503
000074da185da46d  vmovaps xmm1, [rsp+0x20]
000074da185da473  vpermilpd xmm1, xmm1, 0x00
000074da185da479  movaps xmm10, xmm12
000074da185da47d  vfmadd231pd xmm10, xmm13, xmm1
000074da185da482  vcmppd xmm8, xmm10, xmm10, 0x03
000074da185da488  vptest xmm8, xmm8
000074da185da48d  jnz 0x000074DA185DC65C
000074da185da493  lea rax, [r14+0x20]
000074da185da497  movups xmm1, [r13+rax*1]
000074da185da49d  lea rax, [r14+0x30]
000074da185da4a1  movups xmm13, [r13+rax*1]
000074da185da4a7  vmovaps xmm12, [rsp+0x90]
000074da185da4b0  vpermilpd xmm12, xmm12, 0x00
000074da185da4b6  movaps xmm8, xmm7
000074da185da4ba  vfmadd231pd xmm8, xmm4, xmm12
000074da185da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
000074da185da4c5  vptest xmm6, xmm6
000074da185da4ca  jnz 0x000074DA185DC7C9
000074da185da4d0  vmovaps xmm12, [rsp+0x90]
000074da185da4d9  vpermilpd xmm12, xmm12, 0x00
000074da185da4df  movaps xmm7, xmm9
000074da185da4e3  vfmadd231pd xmm7, xmm14, xmm12
000074da185da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
000074da185da4ed  vptest xmm6, xmm6
000074da185da4f2  jnz 0x000074DA185DC921
000074da185da4f8  vmovaps xmm14, [rsp+0x90]
000074da185da501  vpermilpd xmm14, xmm14, 0x00
000074da185da507  movaps xmm12, xmm11
000074da185da50b  vfmadd231pd xmm12, xmm15, xmm14
000074da185da510  vcmppd xmm9, xmm12, xmm12, 0x03
000074da185da516  vptest xmm9, xmm9
000074da185da51b  jnz 0x000074DA185DCA79
000074da185da521  vmovaps xmm15, [rsp+0x90]
000074da185da52a  vpermilpd xmm15, xmm15, 0x00
000074da185da530  movaps xmm11, xmm10
000074da185da534  vfmadd231pd xmm11, xmm13, xmm15
000074da185da539  vcmppd xmm14, xmm11, xmm11, 0x03
000074da185da53f  vptest xmm14, xmm14
000074da185da544  jnz 0x000074DA185DCBD3
000074da185da54a  lea rax, [r14+0x90]
000074da185da551  movups xmm15, [r13+rax*1]
000074da185da557  lea rax, [r14+0xA0]
000074da185da55e  movups xmm14, [r13+rax*1]
000074da185da564  movaps [r15+0x140], xmm15
000074da185da56c  movaps [r15+0x130], xmm14
000074da185da574  vmovaps xmm13, [rsp+0x10]
000074da185da57a  vpermilpd xmm13, xmm13, 0x00
000074da185da580  movaps xmm10, xmm8
000074da185da584  vfmadd231pd xmm10, xmm1, xmm13
000074da185da589  vcmppd xmm9, xmm10, xmm10, 0x03
000074da185da58f  vptest xmm9, xmm9
000074da185da594  jnz 0x000074DA185DCD41
000074da185da59a  movaps [r15+0x220], xmm10
000074da185da5a2  lea rax, [r14+0x10]
000074da185da5a6  movups xmm1, [r13+rax*1]
000074da185da5ac  movaps [r15+0x240], xmm1
000074da185da5b4  vmovaps xmm13, [rsp+0x10]
000074da185da5ba  vpermilpd xmm13, xmm13, 0x00
000074da185da5c0  movaps xmm9, xmm7
000074da185da5c4  vfmadd231pd xmm9, xmm14, xmm13
000074da185da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
000074da185da5cf  vptest xmm8, xmm8
000074da185da5d4  jnz 0x000074DA185DCEA4
000074da185da5da  movaps [r15+0x110], xmm9
000074da185da5e2  vmovaps xmm14, [rsp+0x10]
000074da185da5e8  vpermilpd xmm14, xmm14, 0x00
000074da185da5ee  movaps xmm13, xmm12
000074da185da5f2  vfmadd231pd xmm13, xmm15, xmm14
000074da185da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
000074da185da5fd  vptest xmm8, xmm8
000074da185da602  jnz 0x000074DA185DCFFD
000074da185da608  movaps [r15+0x170], xmm13
000074da185da610  vmovaps xmm15, [rsp+0x10]
000074da185da616  vpermilpd xmm15, xmm15, 0x00
000074da185da61c  movaps xmm14, xmm11
000074da185da620  vfmadd231pd xmm14, xmm1, xmm15
000074da185da625  vcmppd xmm12, xmm14, xmm14, 0x03
000074da185da62b  vptest xmm12, xmm12
000074da185da630  jnz 0x000074DA185DD157
000074da185da636  movaps [r15+0x230], xmm14
000074da185da63e  mov rax, [rsp+0xD0]
000074da185da646  movups [r13+rax*1], xmm9
000074da185da64c  lea r14, [rax+0x10]
000074da185da650  movups [r13+r14*1], xmm13
000074da185da656  lea r14, [rax+0x20]
000074da185da65a  movups [r13+r14*1], xmm10
000074da185da660  lea r14, [rax+0x30]
000074da185da664  movups [r13+r14*1], xmm14
000074da185da66a  mov eax, [r15+0x108]
000074da185da671  sahf
000074da185da672  jnz 0x000074DA185DA6A4
000074da185da674  cmp dword ptr [r15+0x318], 0x00
000074da185da67c  jz 0x000074DA185D9950
000074da185da682  nop [rax+rax*1], ax
000074da185da68b  nop [rax+rax*1], eax
000074da185da693  mov eax, 0x410664
000074da185da698  mov [r15+0x100], rax
000074da185da69f  jmp 0x000074DA183FE110
000074da185da6a4  cmp dword ptr [r15+0x318], 0x00
000074da185da6ac  jz 0x000074DA185D6050
000074da185da6b2  nop [rax+rax*1], ax
000074da185da6bb  nop [rax+rax*1], eax
000074da185da6c3  mov eax, 0x4104F0
000074da185da6c8  mov [r15+0x100], rax
000074da185da6cf  jmp 0x000074DA183FE110
000074da185da6d4  int3
000074da185da6d5  call 0x000074DA184E27E0
000074da185da6da  jmp 0x000074DA185D9A10
000074da185da6df  call 0x000074DA184E1570
000074da185da6e4  jmp 0x000074DA185D9A19
000074da185da6e9  call 0x000074DA184E27E0
000074da185da6ee  jmp 0x000074DA185D9A62
000074da185da6f3  call 0x000074DA184E1570
000074da185da6f8  jmp 0x000074DA185D9A6B
000074da185da6fd  call 0x000074DA184E27E0
000074da185da702  jmp 0x000074DA185D9AEB
000074da185da707  call 0x000074DA184E1570
000074da185da70c  jmp 0x000074DA185D9AF4
000074da185da711  call 0x000074DA1840DC20
000074da185da716  jmp 0x000074DA185D9BD5
000074da185da71b  call 0x000074DA184D64F0
000074da185da720  jmp 0x000074DA185D9C04
000074da185da725  call 0x000074DA184B47C0
000074da185da72a  jmp 0x000074DA185D9C1F
000074da185da72f  sub rsp, 0x08
000074da185da733  push rax
000074da185da734  push rcx
000074da185da735  push rdx
000074da185da736  push rdi
000074da185da737  push rsi
000074da185da738  push r8
000074da185da73a  push r9
000074da185da73c  push r10
000074da185da73e  push r11
000074da185da740  sub rsp, 0xF0
000074da185da747  vmovaps [rsp], xmm0
000074da185da74c  vmovaps [rsp+0x10], xmm1
000074da185da752  vmovaps [rsp+0x20], xmm2
000074da185da758  vmovaps [rsp+0x30], xmm3
000074da185da75e  vmovaps [rsp+0x40], xmm4
000074da185da764  vmovaps [rsp+0x50], xmm5
000074da185da76a  vmovaps [rsp+0x60], xmm6
000074da185da770  vmovaps [rsp+0x70], xmm7
000074da185da776  vmovaps [rsp+0x80], xmm8
000074da185da77f  vmovaps [rsp+0x90], xmm9
000074da185da788  vmovaps [rsp+0xA0], xmm10
000074da185da791  vmovaps [rsp+0xB0], xmm11
000074da185da79a  vmovaps [rsp+0xC0], xmm12
000074da185da7a3  vmovaps [rsp+0xD0], xmm14
000074da185da7ac  vmovaps [rsp+0xE0], xmm15
000074da185da7b5  sub rsp, 0x40
000074da185da7b9  lea rdi, [rsp]
000074da185da7bd  lea rsi, [rsp+0x10]
000074da185da7c2  lea rdx, [rsp+0x20]
000074da185da7c7  lea rcx, [rsp+0x30]
000074da185da7cc  mov r8d, 0x00
000074da185da7d2  lea r9, [r15+0x3A8]
000074da185da7d9  movaps [rdi], xmm13
000074da185da7dd  movaps [rsi], xmm1
000074da185da7e0  movaps [rdx], xmm15
000074da185da7e4  movaps [rcx], xmm14
000074da185da7e8  mov rax, 0x5946061DFA50
000074da185da7f2  call rax
000074da185da7f4  movaps xmm13, [rsp]
000074da185da7f9  add rsp, 0x40
000074da185da7fd  vmovaps xmm0, [rsp]
000074da185da802  vmovaps xmm1, [rsp+0x10]
000074da185da808  vmovaps xmm2, [rsp+0x20]
000074da185da80e  vmovaps xmm3, [rsp+0x30]
000074da185da814  vmovaps xmm4, [rsp+0x40]
000074da185da81a  vmovaps xmm5, [rsp+0x50]
000074da185da820  vmovaps xmm6, [rsp+0x60]
000074da185da826  vmovaps xmm7, [rsp+0x70]
000074da185da82c  vmovaps xmm8, [rsp+0x80]
000074da185da835  vmovaps xmm9, [rsp+0x90]
000074da185da83e  vmovaps xmm10, [rsp+0xA0]
000074da185da847  vmovaps xmm11, [rsp+0xB0]
000074da185da850  vmovaps xmm12, [rsp+0xC0]
000074da185da859  vmovaps xmm14, [rsp+0xD0]
000074da185da862  vmovaps xmm15, [rsp+0xE0]
000074da185da86b  add rsp, 0xF0
000074da185da872  pop r11
000074da185da874  pop r10
000074da185da876  pop r9
000074da185da878  pop r8
000074da185da87a  pop rsi
000074da185da87b  pop rdi
000074da185da87c  pop rdx
000074da185da87d  pop rcx
000074da185da87e  pop rax
000074da185da87f  add rsp, 0x08
000074da185da883  jmp 0x000074DA185D9C92
000074da185da888  sub rsp, 0x08
000074da185da88c  push rax
000074da185da88d  push rcx
000074da185da88e  push rdx
000074da185da88f  push rdi
000074da185da890  push rsi
000074da185da891  push r8
000074da185da893  push r9
000074da185da895  push r10
000074da185da897  push r11
000074da185da899  sub rsp, 0xF0
000074da185da8a0  vmovaps [rsp], xmm0
000074da185da8a5  vmovaps [rsp+0x10], xmm1
000074da185da8ab  vmovaps [rsp+0x20], xmm2
000074da185da8b1  vmovaps [rsp+0x30], xmm3
000074da185da8b7  vmovaps [rsp+0x40], xmm4
000074da185da8bd  vmovaps [rsp+0x50], xmm5
000074da185da8c3  vmovaps [rsp+0x60], xmm6
000074da185da8c9  vmovaps [rsp+0x70], xmm7
000074da185da8cf  vmovaps [rsp+0x80], xmm8
000074da185da8d8  vmovaps [rsp+0x90], xmm9
000074da185da8e1  vmovaps [rsp+0xA0], xmm10
000074da185da8ea  vmovaps [rsp+0xB0], xmm11
000074da185da8f3  vmovaps [rsp+0xC0], xmm13
000074da185da8fc  vmovaps [rsp+0xD0], xmm14
000074da185da905  vmovaps [rsp+0xE0], xmm15
000074da185da90e  sub rsp, 0x40
000074da185da912  lea rdi, [rsp]
000074da185da916  lea rsi, [rsp+0x10]
000074da185da91b  lea rdx, [rsp+0x20]
000074da185da920  lea rcx, [rsp+0x30]
000074da185da925  mov r8d, 0x00
000074da185da92b  lea r9, [r15+0x3A8]
000074da185da932  movaps [rdi], xmm12
000074da185da936  movaps [rsi], xmm15
000074da185da93a  movaps [rdx], xmm1
000074da185da93d  movaps [rcx], xmm14
000074da185da941  mov rax, 0x5946061DFA50
000074da185da94b  call rax
000074da185da94d  movaps xmm12, [rsp]
000074da185da952  add rsp, 0x40
000074da185da956  vmovaps xmm0, [rsp]
000074da185da95b  vmovaps xmm1, [rsp+0x10]
000074da185da961  vmovaps xmm2, [rsp+0x20]
000074da185da967  vmovaps xmm3, [rsp+0x30]
000074da185da96d  vmovaps xmm4, [rsp+0x40]
000074da185da973  vmovaps xmm5, [rsp+0x50]
000074da185da979  vmovaps xmm6, [rsp+0x60]
000074da185da97f  vmovaps xmm7, [rsp+0x70]
000074da185da985  vmovaps xmm8, [rsp+0x80]
000074da185da98e  vmovaps xmm9, [rsp+0x90]
000074da185da997  vmovaps xmm10, [rsp+0xA0]
000074da185da9a0  vmovaps xmm11, [rsp+0xB0]
000074da185da9a9  vmovaps xmm13, [rsp+0xC0]
000074da185da9b2  vmovaps xmm14, [rsp+0xD0]
000074da185da9bb  vmovaps xmm15, [rsp+0xE0]
000074da185da9c4  add rsp, 0xF0
000074da185da9cb  pop r11
000074da185da9cd  pop r10
000074da185da9cf  pop r9
000074da185da9d1  pop r8
000074da185da9d3  pop rsi
000074da185da9d4  pop rdi
000074da185da9d5  pop rdx
000074da185da9d6  pop rcx
000074da185da9d7  pop rax
000074da185da9d8  add rsp, 0x08
000074da185da9dc  jmp 0x000074DA185D9CC0
000074da185da9e1  call 0x000074DA184B52F0
000074da185da9e6  jmp 0x000074DA185D9DAC
000074da185da9eb  sub rsp, 0x08
000074da185da9ef  push rax
000074da185da9f0  push rcx
000074da185da9f1  push rdx
000074da185da9f2  push rdi
000074da185da9f3  push rsi
000074da185da9f4  push r8
000074da185da9f6  push r9
000074da185da9f8  push r10
000074da185da9fa  push r11
000074da185da9fc  sub rsp, 0xF0
000074da185daa03  vmovaps [rsp], xmm0
000074da185daa08  vmovaps [rsp+0x10], xmm1
000074da185daa0e  vmovaps [rsp+0x20], xmm2
000074da185daa14  vmovaps [rsp+0x30], xmm3
000074da185daa1a  vmovaps [rsp+0x40], xmm4
000074da185daa20  vmovaps [rsp+0x50], xmm5
000074da185daa26  vmovaps [rsp+0x60], xmm6
000074da185daa2c  vmovaps [rsp+0x70], xmm7
000074da185daa32  vmovaps [rsp+0x80], xmm8
000074da185daa3b  vmovaps [rsp+0x90], xmm9
000074da185daa44  vmovaps [rsp+0xA0], xmm10
000074da185daa4d  vmovaps [rsp+0xB0], xmm11
000074da185daa56  vmovaps [rsp+0xC0], xmm12
000074da185daa5f  vmovaps [rsp+0xD0], xmm14
000074da185daa68  vmovaps [rsp+0xE0], xmm15
000074da185daa71  sub rsp, 0x40
000074da185daa75  lea rdi, [rsp]
000074da185daa79  lea rsi, [rsp+0x10]
000074da185daa7e  lea rdx, [rsp+0x20]
000074da185daa83  lea rcx, [rsp+0x30]
000074da185daa88  mov r8d, 0x00
000074da185daa8e  lea r9, [r15+0x3A8]
000074da185daa95  movaps [rdi], xmm13
000074da185daa99  movaps [rsi], xmm1
000074da185daa9c  movaps [rdx], xmm15
000074da185daaa0  movaps [rcx], xmm14
000074da185daaa4  mov rax, 0x5946061DFA50
000074da185daaae  call rax
000074da185daab0  movaps xmm13, [rsp]
000074da185daab5  add rsp, 0x40
000074da185daab9  vmovaps xmm0, [rsp]
000074da185daabe  vmovaps xmm1, [rsp+0x10]
000074da185daac4  vmovaps xmm2, [rsp+0x20]
000074da185daaca  vmovaps xmm3, [rsp+0x30]
000074da185daad0  vmovaps xmm4, [rsp+0x40]
000074da185daad6  vmovaps xmm5, [rsp+0x50]
000074da185daadc  vmovaps xmm6, [rsp+0x60]
000074da185daae2  vmovaps xmm7, [rsp+0x70]
000074da185daae8  vmovaps xmm8, [rsp+0x80]
000074da185daaf1  vmovaps xmm9, [rsp+0x90]
000074da185daafa  vmovaps xmm10, [rsp+0xA0]
000074da185dab03  vmovaps xmm11, [rsp+0xB0]
000074da185dab0c  vmovaps xmm12, [rsp+0xC0]
000074da185dab15  vmovaps xmm14, [rsp+0xD0]
000074da185dab1e  vmovaps xmm15, [rsp+0xE0]
000074da185dab27  add rsp, 0xF0
000074da185dab2e  pop r11
000074da185dab30  pop r10
000074da185dab32  pop r9
000074da185dab34  pop r8
000074da185dab36  pop rsi
000074da185dab37  pop rdi
000074da185dab38  pop rdx
000074da185dab39  pop rcx
000074da185dab3a  pop rax
000074da185dab3b  add rsp, 0x08
000074da185dab3f  jmp 0x000074DA185D9E21
000074da185dab44  call 0x000074DA183FF430
000074da185dab49  jmp 0x000074DA185D9E2E
000074da185dab4e  sub rsp, 0x08
000074da185dab52  push rax
000074da185dab53  push rcx
000074da185dab54  push rdx
000074da185dab55  push rdi
000074da185dab56  push rsi
000074da185dab57  push r8
000074da185dab59  push r9
000074da185dab5b  push r10
000074da185dab5d  push r11
000074da185dab5f  sub rsp, 0xF0
000074da185dab66  vmovaps [rsp], xmm0
000074da185dab6b  vmovaps [rsp+0x10], xmm1
000074da185dab71  vmovaps [rsp+0x20], xmm2
000074da185dab77  vmovaps [rsp+0x30], xmm3
000074da185dab7d  vmovaps [rsp+0x40], xmm4
000074da185dab83  vmovaps [rsp+0x50], xmm5
000074da185dab89  vmovaps [rsp+0x60], xmm6
000074da185dab8f  vmovaps [rsp+0x70], xmm7
000074da185dab95  vmovaps [rsp+0x80], xmm8
000074da185dab9e  vmovaps [rsp+0x90], xmm9
000074da185daba7  vmovaps [rsp+0xA0], xmm10
000074da185dabb0  vmovaps [rsp+0xB0], xmm11
000074da185dabb9  vmovaps [rsp+0xC0], xmm13
000074da185dabc2  vmovaps [rsp+0xD0], xmm14
000074da185dabcb  vmovaps [rsp+0xE0], xmm15
000074da185dabd4  sub rsp, 0x40
000074da185dabd8  lea rdi, [rsp]
000074da185dabdc  lea rsi, [rsp+0x10]
000074da185dabe1  lea rdx, [rsp+0x20]
000074da185dabe6  lea rcx, [rsp+0x30]
000074da185dabeb  mov r8d, 0x00
000074da185dabf1  lea r9, [r15+0x3A8]
000074da185dabf8  movaps [rdi], xmm12
000074da185dabfc  movaps [rsi], xmm15
000074da185dac00  movaps [rdx], xmm1
000074da185dac03  movaps [rcx], xmm14
000074da185dac07  mov rax, 0x5946061DFA50
000074da185dac11  call rax
000074da185dac13  movaps xmm12, [rsp]
000074da185dac18  add rsp, 0x40
000074da185dac1c  vmovaps xmm0, [rsp]
000074da185dac21  vmovaps xmm1, [rsp+0x10]
000074da185dac27  vmovaps xmm2, [rsp+0x20]
000074da185dac2d  vmovaps xmm3, [rsp+0x30]
000074da185dac33  vmovaps xmm4, [rsp+0x40]
000074da185dac39  vmovaps xmm5, [rsp+0x50]
000074da185dac3f  vmovaps xmm6, [rsp+0x60]
000074da185dac45  vmovaps xmm7, [rsp+0x70]
000074da185dac4b  vmovaps xmm8, [rsp+0x80]
000074da185dac54  vmovaps xmm9, [rsp+0x90]
000074da185dac5d  vmovaps xmm10, [rsp+0xA0]
000074da185dac66  vmovaps xmm11, [rsp+0xB0]
000074da185dac6f  vmovaps xmm13, [rsp+0xC0]
000074da185dac78  vmovaps xmm14, [rsp+0xD0]
000074da185dac81  vmovaps xmm15, [rsp+0xE0]
000074da185dac8a  add rsp, 0xF0
000074da185dac91  pop r11
000074da185dac93  pop r10
000074da185dac95  pop r9
000074da185dac97  pop r8
000074da185dac99  pop rsi
000074da185dac9a  pop rdi
000074da185dac9b  pop rdx
000074da185dac9c  pop rcx
000074da185dac9d  pop rax
000074da185dac9e  add rsp, 0x08
000074da185daca2  jmp 0x000074DA185D9E5A
000074da185daca7  sub rsp, 0x08
000074da185dacab  push rax
000074da185dacac  push rcx
000074da185dacad  push rdx
000074da185dacae  push rdi
000074da185dacaf  push rsi
000074da185dacb0  push r8
000074da185dacb2  push r9
000074da185dacb4  push r10
000074da185dacb6  push r11
000074da185dacb8  sub rsp, 0xF0
000074da185dacbf  vmovaps [rsp], xmm0
000074da185dacc4  vmovaps [rsp+0x10], xmm1
000074da185dacca  vmovaps [rsp+0x20], xmm2
000074da185dacd0  vmovaps [rsp+0x30], xmm3
000074da185dacd6  vmovaps [rsp+0x40], xmm4
000074da185dacdc  vmovaps [rsp+0x50], xmm5
000074da185dace2  vmovaps [rsp+0x60], xmm6
000074da185dace8  vmovaps [rsp+0x70], xmm7
000074da185dacee  vmovaps [rsp+0x80], xmm8
000074da185dacf7  vmovaps [rsp+0x90], xmm9
000074da185dad00  vmovaps [rsp+0xA0], xmm10
000074da185dad09  vmovaps [rsp+0xB0], xmm11
000074da185dad12  vmovaps [rsp+0xC0], xmm12
000074da185dad1b  vmovaps [rsp+0xD0], xmm14
000074da185dad24  vmovaps [rsp+0xE0], xmm15
000074da185dad2d  sub rsp, 0x40
000074da185dad31  lea rdi, [rsp]
000074da185dad35  lea rsi, [rsp+0x10]
000074da185dad3a  lea rdx, [rsp+0x20]
000074da185dad3f  lea rcx, [rsp+0x30]
000074da185dad44  mov r8d, 0x00
000074da185dad4a  lea r9, [r15+0x3A8]
000074da185dad51  movaps [rdi], xmm13
000074da185dad55  movaps [rsi], xmm1
000074da185dad58  movaps [rdx], xmm15
000074da185dad5c  movaps [rcx], xmm14
000074da185dad60  mov rax, 0x5946061DFA50
000074da185dad6a  call rax
000074da185dad6c  movaps xmm13, [rsp]
000074da185dad71  add rsp, 0x40
000074da185dad75  vmovaps xmm0, [rsp]
000074da185dad7a  vmovaps xmm1, [rsp+0x10]
000074da185dad80  vmovaps xmm2, [rsp+0x20]
000074da185dad86  vmovaps xmm3, [rsp+0x30]
000074da185dad8c  vmovaps xmm4, [rsp+0x40]
000074da185dad92  vmovaps xmm5, [rsp+0x50]
000074da185dad98  vmovaps xmm6, [rsp+0x60]
000074da185dad9e  vmovaps xmm7, [rsp+0x70]
000074da185dada4  vmovaps xmm8, [rsp+0x80]
000074da185dadad  vmovaps xmm9, [rsp+0x90]
000074da185dadb6  vmovaps xmm10, [rsp+0xA0]
000074da185dadbf  vmovaps xmm11, [rsp+0xB0]
000074da185dadc8  vmovaps xmm12, [rsp+0xC0]
000074da185dadd1  vmovaps xmm14, [rsp+0xD0]
000074da185dadda  vmovaps xmm15, [rsp+0xE0]
000074da185dade3  add rsp, 0xF0
000074da185dadea  pop r11
000074da185dadec  pop r10
000074da185dadee  pop r9
000074da185dadf0  pop r8
000074da185dadf2  pop rsi
000074da185dadf3  pop rdi
000074da185dadf4  pop rdx
000074da185dadf5  pop rcx
000074da185dadf6  pop rax
000074da185dadf7  add rsp, 0x08
000074da185dadfb  jmp 0x000074DA185D9FEA
000074da185dae00  sub rsp, 0x08
000074da185dae04  push rax
000074da185dae05  push rcx
000074da185dae06  push rdx
000074da185dae07  push rdi
000074da185dae08  push rsi
000074da185dae09  push r8
000074da185dae0b  push r9
000074da185dae0d  push r10
000074da185dae0f  push r11
000074da185dae11  sub rsp, 0xF0
000074da185dae18  vmovaps [rsp], xmm0
000074da185dae1d  vmovaps [rsp+0x10], xmm1
000074da185dae23  vmovaps [rsp+0x20], xmm2
000074da185dae29  vmovaps [rsp+0x30], xmm3
000074da185dae2f  vmovaps [rsp+0x40], xmm4
000074da185dae35  vmovaps [rsp+0x50], xmm5
000074da185dae3b  vmovaps [rsp+0x60], xmm6
000074da185dae41  vmovaps [rsp+0x70], xmm7
000074da185dae47  vmovaps [rsp+0x80], xmm8
000074da185dae50  vmovaps [rsp+0x90], xmm9
000074da185dae59  vmovaps [rsp+0xA0], xmm10
000074da185dae62  vmovaps [rsp+0xB0], xmm11
000074da185dae6b  vmovaps [rsp+0xC0], xmm12
000074da185dae74  vmovaps [rsp+0xD0], xmm13
000074da185dae7d  vmovaps [rsp+0xE0], xmm15
000074da185dae86  sub rsp, 0x40
000074da185dae8a  lea rdi, [rsp]
000074da185dae8e  lea rsi, [rsp+0x10]
000074da185dae93  lea rdx, [rsp+0x20]
000074da185dae98  lea rcx, [rsp+0x30]
000074da185dae9d  mov r8d, 0x00
000074da185daea3  lea r9, [r15+0x3A8]
000074da185daeaa  movaps [rdi], xmm14
000074da185daeae  movaps [rsi], xmm15
000074da185daeb2  movaps [rdx], xmm2
000074da185daeb5  movaps [rcx], xmm1
000074da185daeb8  mov rax, 0x5946061DFA50
000074da185daec2  call rax
000074da185daec4  movaps xmm14, [rsp]
000074da185daec9  add rsp, 0x40
000074da185daecd  vmovaps xmm0, [rsp]
000074da185daed2  vmovaps xmm1, [rsp+0x10]
000074da185daed8  vmovaps xmm2, [rsp+0x20]
000074da185daede  vmovaps xmm3, [rsp+0x30]
000074da185daee4  vmovaps xmm4, [rsp+0x40]
000074da185daeea  vmovaps xmm5, [rsp+0x50]
000074da185daef0  vmovaps xmm6, [rsp+0x60]
000074da185daef6  vmovaps xmm7, [rsp+0x70]
000074da185daefc  vmovaps xmm8, [rsp+0x80]
000074da185daf05  vmovaps xmm9, [rsp+0x90]
000074da185daf0e  vmovaps xmm10, [rsp+0xA0]
000074da185daf17  vmovaps xmm11, [rsp+0xB0]
000074da185daf20  vmovaps xmm12, [rsp+0xC0]
000074da185daf29  vmovaps xmm13, [rsp+0xD0]
000074da185daf32  vmovaps xmm15, [rsp+0xE0]
000074da185daf3b  add rsp, 0xF0
000074da185daf42  pop r11
000074da185daf44  pop r10
000074da185daf46  pop r9
000074da185daf48  pop r8
000074da185daf4a  pop rsi
000074da185daf4b  pop rdi
000074da185daf4c  pop rdx
000074da185daf4d  pop rcx
000074da185daf4e  pop rax
000074da185daf4f  add rsp, 0x08
000074da185daf53  jmp 0x000074DA185DA01C
000074da185daf58  sub rsp, 0x08
000074da185daf5c  push rax
000074da185daf5d  push rcx
000074da185daf5e  push rdx
000074da185daf5f  push rdi
000074da185daf60  push rsi
000074da185daf61  push r8
000074da185daf63  push r9
000074da185daf65  push r10
000074da185daf67  push r11
000074da185daf69  sub rsp, 0xF0
000074da185daf70  vmovaps [rsp], xmm0
000074da185daf75  vmovaps [rsp+0x10], xmm1
000074da185daf7b  vmovaps [rsp+0x20], xmm3
000074da185daf81  vmovaps [rsp+0x30], xmm4
000074da185daf87  vmovaps [rsp+0x40], xmm5
000074da185daf8d  vmovaps [rsp+0x50], xmm6
000074da185daf93  vmovaps [rsp+0x60], xmm7
000074da185daf99  vmovaps [rsp+0x70], xmm8
000074da185daf9f  vmovaps [rsp+0x80], xmm9
000074da185dafa8  vmovaps [rsp+0x90], xmm10
000074da185dafb1  vmovaps [rsp+0xA0], xmm11
000074da185dafba  vmovaps [rsp+0xB0], xmm12
000074da185dafc3  vmovaps [rsp+0xC0], xmm13
000074da185dafcc  vmovaps [rsp+0xD0], xmm14
000074da185dafd5  vmovaps [rsp+0xE0], xmm15
000074da185dafde  sub rsp, 0x40
000074da185dafe2  lea rdi, [rsp]
000074da185dafe6  lea rsi, [rsp+0x10]
000074da185dafeb  lea rdx, [rsp+0x20]
000074da185daff0  lea rcx, [rsp+0x30]
000074da185daff5  mov r8d, 0x00
000074da185daffb  lea r9, [r15+0x3A8]
000074da185db002  movaps [rdi], xmm2
000074da185db005  movaps [rsi], xmm15
000074da185db009  movaps [rdx], xmm12
000074da185db00d  movaps [rcx], xmm1
000074da185db010  mov rax, 0x5946061DFA50
000074da185db01a  call rax
000074da185db01c  movaps xmm2, [rsp]
000074da185db020  add rsp, 0x40
000074da185db024  vmovaps xmm0, [rsp]
000074da185db029  vmovaps xmm1, [rsp+0x10]
000074da185db02f  vmovaps xmm3, [rsp+0x20]
000074da185db035  vmovaps xmm4, [rsp+0x30]
000074da185db03b  vmovaps xmm5, [rsp+0x40]
000074da185db041  vmovaps xmm6, [rsp+0x50]
000074da185db047  vmovaps xmm7, [rsp+0x60]
000074da185db04d  vmovaps xmm8, [rsp+0x70]
000074da185db053  vmovaps xmm9, [rsp+0x80]
000074da185db05c  vmovaps xmm10, [rsp+0x90]
000074da185db065  vmovaps xmm11, [rsp+0xA0]
000074da185db06e  vmovaps xmm12, [rsp+0xB0]
000074da185db077  vmovaps xmm13, [rsp+0xC0]
000074da185db080  vmovaps xmm14, [rsp+0xD0]
000074da185db089  vmovaps xmm15, [rsp+0xE0]
000074da185db092  add rsp, 0xF0
000074da185db099  pop r11
000074da185db09b  pop r10
000074da185db09d  pop r9
000074da185db09f  pop r8
000074da185db0a1  pop rsi
000074da185db0a2  pop rdi
000074da185db0a3  pop rdx
000074da185db0a4  pop rcx
000074da185db0a5  pop rax
000074da185db0a6  add rsp, 0x08
000074da185db0aa  jmp 0x000074DA185DA059
000074da185db0af  sub rsp, 0x08
000074da185db0b3  push rax
000074da185db0b4  push rcx
000074da185db0b5  push rdx
000074da185db0b6  push rdi
000074da185db0b7  push rsi
000074da185db0b8  push r8
000074da185db0ba  push r9
000074da185db0bc  push r10
000074da185db0be  push r11
000074da185db0c0  sub rsp, 0xF0
000074da185db0c7  vmovaps [rsp], xmm0
000074da185db0cc  vmovaps [rsp+0x10], xmm1
000074da185db0d2  vmovaps [rsp+0x20], xmm2
000074da185db0d8  vmovaps [rsp+0x30], xmm3
000074da185db0de  vmovaps [rsp+0x40], xmm4
000074da185db0e4  vmovaps [rsp+0x50], xmm5
000074da185db0ea  vmovaps [rsp+0x60], xmm6
000074da185db0f0  vmovaps [rsp+0x70], xmm7
000074da185db0f6  vmovaps [rsp+0x80], xmm8
000074da185db0ff  vmovaps [rsp+0x90], xmm9
000074da185db108  vmovaps [rsp+0xA0], xmm10
000074da185db111  vmovaps [rsp+0xB0], xmm11
000074da185db11a  vmovaps [rsp+0xC0], xmm13
000074da185db123  vmovaps [rsp+0xD0], xmm14
000074da185db12c  vmovaps [rsp+0xE0], xmm15
000074da185db135  sub rsp, 0x40
000074da185db139  lea rdi, [rsp]
000074da185db13d  lea rsi, [rsp+0x10]
000074da185db142  lea rdx, [rsp+0x20]
000074da185db147  lea rcx, [rsp+0x30]
000074da185db14c  mov r8d, 0x00
000074da185db152  lea r9, [r15+0x3A8]
000074da185db159  movaps [rdi], xmm12
000074da185db15d  movaps [rsi], xmm14
000074da185db161  movaps [rdx], xmm3
000074da185db164  movaps [rcx], xmm15
000074da185db168  mov rax, 0x5946061DFA50
000074da185db172  call rax
000074da185db174  movaps xmm12, [rsp]
000074da185db179  add rsp, 0x40
000074da185db17d  vmovaps xmm0, [rsp]
000074da185db182  vmovaps xmm1, [rsp+0x10]
000074da185db188  vmovaps xmm2, [rsp+0x20]
000074da185db18e  vmovaps xmm3, [rsp+0x30]
000074da185db194  vmovaps xmm4, [rsp+0x40]
000074da185db19a  vmovaps xmm5, [rsp+0x50]
000074da185db1a0  vmovaps xmm6, [rsp+0x60]
000074da185db1a6  vmovaps xmm7, [rsp+0x70]
000074da185db1ac  vmovaps xmm8, [rsp+0x80]
000074da185db1b5  vmovaps xmm9, [rsp+0x90]
000074da185db1be  vmovaps xmm10, [rsp+0xA0]
000074da185db1c7  vmovaps xmm11, [rsp+0xB0]
000074da185db1d0  vmovaps xmm13, [rsp+0xC0]
000074da185db1d9  vmovaps xmm14, [rsp+0xD0]
000074da185db1e2  vmovaps xmm15, [rsp+0xE0]
000074da185db1eb  add rsp, 0xF0
000074da185db1f2  pop r11
000074da185db1f4  pop r10
000074da185db1f6  pop r9
000074da185db1f8  pop r8
000074da185db1fa  pop rsi
000074da185db1fb  pop rdi
000074da185db1fc  pop rdx
000074da185db1fd  pop rcx
000074da185db1fe  pop rax
000074da185db1ff  add rsp, 0x08
000074da185db203  jmp 0x000074DA185DA0B3
000074da185db208  sub rsp, 0x08
000074da185db20c  push rax
000074da185db20d  push rcx
000074da185db20e  push rdx
000074da185db20f  push rdi
000074da185db210  push rsi
000074da185db211  push r8
000074da185db213  push r9
000074da185db215  push r10
000074da185db217  push r11
000074da185db219  sub rsp, 0xF0
000074da185db220  vmovaps [rsp], xmm0
000074da185db225  vmovaps [rsp+0x10], xmm1
000074da185db22b  vmovaps [rsp+0x20], xmm2
000074da185db231  vmovaps [rsp+0x30], xmm3
000074da185db237  vmovaps [rsp+0x40], xmm4
000074da185db23d  vmovaps [rsp+0x50], xmm5
000074da185db243  vmovaps [rsp+0x60], xmm6
000074da185db249  vmovaps [rsp+0x70], xmm7
000074da185db24f  vmovaps [rsp+0x80], xmm8
000074da185db258  vmovaps [rsp+0x90], xmm10
000074da185db261  vmovaps [rsp+0xA0], xmm11
000074da185db26a  vmovaps [rsp+0xB0], xmm12
000074da185db273  vmovaps [rsp+0xC0], xmm13
000074da185db27c  vmovaps [rsp+0xD0], xmm14
000074da185db285  vmovaps [rsp+0xE0], xmm15
000074da185db28e  sub rsp, 0x40
000074da185db292  lea rdi, [rsp]
000074da185db296  lea rsi, [rsp+0x10]
000074da185db29b  lea rdx, [rsp+0x20]
000074da185db2a0  lea rcx, [rsp+0x30]
000074da185db2a5  mov r8d, 0x00
000074da185db2ab  lea r9, [r15+0x3A8]
000074da185db2b2  movaps [rdi], xmm9
000074da185db2b6  movaps [rsi], xmm13
000074da185db2ba  movaps [rdx], xmm14
000074da185db2be  movaps [rcx], xmm6
000074da185db2c1  mov rax, 0x5946061DFA50
000074da185db2cb  call rax
000074da185db2cd  movaps xmm9, [rsp]
000074da185db2d2  add rsp, 0x40
000074da185db2d6  vmovaps xmm0, [rsp]
000074da185db2db  vmovaps xmm1, [rsp+0x10]
000074da185db2e1  vmovaps xmm2, [rsp+0x20]
000074da185db2e7  vmovaps xmm3, [rsp+0x30]
000074da185db2ed  vmovaps xmm4, [rsp+0x40]
000074da185db2f3  vmovaps xmm5, [rsp+0x50]
000074da185db2f9  vmovaps xmm6, [rsp+0x60]
000074da185db2ff  vmovaps xmm7, [rsp+0x70]
000074da185db305  vmovaps xmm8, [rsp+0x80]
000074da185db30e  vmovaps xmm10, [rsp+0x90]
000074da185db317  vmovaps xmm11, [rsp+0xA0]
000074da185db320  vmovaps xmm12, [rsp+0xB0]
000074da185db329  vmovaps xmm13, [rsp+0xC0]
000074da185db332  vmovaps xmm14, [rsp+0xD0]
000074da185db33b  vmovaps xmm15, [rsp+0xE0]
000074da185db344  add rsp, 0xF0
000074da185db34b  pop r11
000074da185db34d  pop r10
000074da185db34f  pop r9
000074da185db351  pop r8
000074da185db353  pop rsi
000074da185db354  pop rdi
000074da185db355  pop rdx
000074da185db356  pop rcx
000074da185db357  pop rax
000074da185db358  add rsp, 0x08
000074da185db35c  jmp 0x000074DA185DA15D
000074da185db361  sub rsp, 0x08
000074da185db365  push rax
000074da185db366  push rcx
000074da185db367  push rdx
000074da185db368  push rdi
000074da185db369  push rsi
000074da185db36a  push r8
000074da185db36c  push r9
000074da185db36e  push r10
000074da185db370  push r11
000074da185db372  sub rsp, 0xF0
000074da185db379  vmovaps [rsp], xmm0
000074da185db37e  vmovaps [rsp+0x10], xmm1
000074da185db384  vmovaps [rsp+0x20], xmm2
000074da185db38a  vmovaps [rsp+0x30], xmm4
000074da185db390  vmovaps [rsp+0x40], xmm5
000074da185db396  vmovaps [rsp+0x50], xmm6
000074da185db39c  vmovaps [rsp+0x60], xmm7
000074da185db3a2  vmovaps [rsp+0x70], xmm8
000074da185db3a8  vmovaps [rsp+0x80], xmm9
000074da185db3b1  vmovaps [rsp+0x90], xmm10
000074da185db3ba  vmovaps [rsp+0xA0], xmm11
000074da185db3c3  vmovaps [rsp+0xB0], xmm12
000074da185db3cc  vmovaps [rsp+0xC0], xmm13
000074da185db3d5  vmovaps [rsp+0xD0], xmm14
000074da185db3de  vmovaps [rsp+0xE0], xmm15
000074da185db3e7  sub rsp, 0x40
000074da185db3eb  lea rdi, [rsp]
000074da185db3ef  lea rsi, [rsp+0x10]
000074da185db3f4  lea rdx, [rsp+0x20]
000074da185db3f9  lea rcx, [rsp+0x30]
000074da185db3fe  mov r8d, 0x00
000074da185db404  lea r9, [r15+0x3A8]
000074da185db40b  movaps [rdi], xmm3
000074da185db40e  movaps [rsi], xmm13
000074da185db412  movaps [rdx], xmm6
000074da185db415  movaps [rcx], xmm14
000074da185db419  mov rax, 0x5946061DFA50
000074da185db423  call rax
000074da185db425  movaps xmm3, [rsp]
000074da185db429  add rsp, 0x40
000074da185db42d  vmovaps xmm0, [rsp]
000074da185db432  vmovaps xmm1, [rsp+0x10]
000074da185db438  vmovaps xmm2, [rsp+0x20]
000074da185db43e  vmovaps xmm4, [rsp+0x30]
000074da185db444  vmovaps xmm5, [rsp+0x40]
000074da185db44a  vmovaps xmm6, [rsp+0x50]
000074da185db450  vmovaps xmm7, [rsp+0x60]
000074da185db456  vmovaps xmm8, [rsp+0x70]
000074da185db45c  vmovaps xmm9, [rsp+0x80]
000074da185db465  vmovaps xmm10, [rsp+0x90]
000074da185db46e  vmovaps xmm11, [rsp+0xA0]
000074da185db477  vmovaps xmm12, [rsp+0xB0]
000074da185db480  vmovaps xmm13, [rsp+0xC0]
000074da185db489  vmovaps xmm14, [rsp+0xD0]
000074da185db492  vmovaps xmm15, [rsp+0xE0]
000074da185db49b  add rsp, 0xF0
000074da185db4a2  pop r11
000074da185db4a4  pop r10
000074da185db4a6  pop r9
000074da185db4a8  pop r8
000074da185db4aa  pop rsi
000074da185db4ab  pop rdi
000074da185db4ac  pop rdx
000074da185db4ad  pop rcx
000074da185db4ae  pop rax
000074da185db4af  add rsp, 0x08
000074da185db4b3  jmp 0x000074DA185DA19A
000074da185db4b8  sub rsp, 0x08
000074da185db4bc  push rax
000074da185db4bd  push rcx
000074da185db4be  push rdx
000074da185db4bf  push rdi
000074da185db4c0  push rsi
000074da185db4c1  push r8
000074da185db4c3  push r9
000074da185db4c5  push r10
000074da185db4c7  push r11
000074da185db4c9  sub rsp, 0xF0
000074da185db4d0  vmovaps [rsp], xmm0
000074da185db4d5  vmovaps [rsp+0x10], xmm1
000074da185db4db  vmovaps [rsp+0x20], xmm2
000074da185db4e1  vmovaps [rsp+0x30], xmm3
000074da185db4e7  vmovaps [rsp+0x40], xmm4
000074da185db4ed  vmovaps [rsp+0x50], xmm5
000074da185db4f3  vmovaps [rsp+0x60], xmm7
000074da185db4f9  vmovaps [rsp+0x70], xmm8
000074da185db4ff  vmovaps [rsp+0x80], xmm9
000074da185db508  vmovaps [rsp+0x90], xmm10
000074da185db511  vmovaps [rsp+0xA0], xmm11
000074da185db51a  vmovaps [rsp+0xB0], xmm12
000074da185db523  vmovaps [rsp+0xC0], xmm13
000074da185db52c  vmovaps [rsp+0xD0], xmm14
000074da185db535  vmovaps [rsp+0xE0], xmm15
000074da185db53e  sub rsp, 0x40
000074da185db542  lea rdi, [rsp]
000074da185db546  lea rsi, [rsp+0x10]
000074da185db54b  lea rdx, [rsp+0x20]
000074da185db550  lea rcx, [rsp+0x30]
000074da185db555  mov r8d, 0x00
000074da185db55b  lea r9, [r15+0x3A8]
000074da185db562  movaps [rdi], xmm6
000074da185db565  movaps [rsi], xmm2
000074da185db568  movaps [rdx], xmm14
000074da185db56c  movaps [rcx], xmm1
000074da185db56f  mov rax, 0x5946061DFA50
000074da185db579  call rax
000074da185db57b  movaps xmm6, [rsp]
000074da185db57f  add rsp, 0x40
000074da185db583  vmovaps xmm0, [rsp]
000074da185db588  vmovaps xmm1, [rsp+0x10]
000074da185db58e  vmovaps xmm2, [rsp+0x20]
000074da185db594  vmovaps xmm3, [rsp+0x30]
000074da185db59a  vmovaps xmm4, [rsp+0x40]
000074da185db5a0  vmovaps xmm5, [rsp+0x50]
000074da185db5a6  vmovaps xmm7, [rsp+0x60]
000074da185db5ac  vmovaps xmm8, [rsp+0x70]
000074da185db5b2  vmovaps xmm9, [rsp+0x80]
000074da185db5bb  vmovaps xmm10, [rsp+0x90]
000074da185db5c4  vmovaps xmm11, [rsp+0xA0]
000074da185db5cd  vmovaps xmm12, [rsp+0xB0]
000074da185db5d6  vmovaps xmm13, [rsp+0xC0]
000074da185db5df  vmovaps xmm14, [rsp+0xD0]
000074da185db5e8  vmovaps xmm15, [rsp+0xE0]
000074da185db5f1  add rsp, 0xF0
000074da185db5f8  pop r11
000074da185db5fa  pop r10
000074da185db5fc  pop r9
000074da185db5fe  pop r8
000074da185db600  pop rsi
000074da185db601  pop rdi
000074da185db602  pop rdx
000074da185db603  pop rcx
000074da185db604  pop rax
000074da185db605  add rsp, 0x08
000074da185db609  jmp 0x000074DA185DA1C7
000074da185db60e  sub rsp, 0x08
000074da185db612  push rax
000074da185db613  push rcx
000074da185db614  push rdx
000074da185db615  push rdi
000074da185db616  push rsi
000074da185db617  push r8
000074da185db619  push r9
000074da185db61b  push r10
000074da185db61d  push r11
000074da185db61f  sub rsp, 0xF0
000074da185db626  vmovaps [rsp], xmm0
000074da185db62b  vmovaps [rsp+0x10], xmm1
000074da185db631  vmovaps [rsp+0x20], xmm2
000074da185db637  vmovaps [rsp+0x30], xmm3
000074da185db63d  vmovaps [rsp+0x40], xmm4
000074da185db643  vmovaps [rsp+0x50], xmm5
000074da185db649  vmovaps [rsp+0x60], xmm6
000074da185db64f  vmovaps [rsp+0x70], xmm7
000074da185db655  vmovaps [rsp+0x80], xmm8
000074da185db65e  vmovaps [rsp+0x90], xmm9
000074da185db667  vmovaps [rsp+0xA0], xmm10
000074da185db670  vmovaps [rsp+0xB0], xmm11
000074da185db679  vmovaps [rsp+0xC0], xmm12
000074da185db682  vmovaps [rsp+0xD0], xmm14
000074da185db68b  vmovaps [rsp+0xE0], xmm15
000074da185db694  sub rsp, 0x40
000074da185db698  lea rdi, [rsp]
000074da185db69c  lea rsi, [rsp+0x10]
000074da185db6a1  lea rdx, [rsp+0x20]
000074da185db6a6  lea rcx, [rsp+0x30]
000074da185db6ab  mov r8d, 0x00
000074da185db6b1  lea r9, [r15+0x3A8]
000074da185db6b8  movaps [rdi], xmm13
000074da185db6bc  movaps [rsi], xmm12
000074da185db6c0  movaps [rdx], xmm14
000074da185db6c4  movaps [rcx], xmm1
000074da185db6c7  mov rax, 0x5946061DFA50
000074da185db6d1  call rax
000074da185db6d3  movaps xmm13, [rsp]
000074da185db6d8  add rsp, 0x40
000074da185db6dc  vmovaps xmm0, [rsp]
000074da185db6e1  vmovaps xmm1, [rsp+0x10]
000074da185db6e7  vmovaps xmm2, [rsp+0x20]
000074da185db6ed  vmovaps xmm3, [rsp+0x30]
000074da185db6f3  vmovaps xmm4, [rsp+0x40]
000074da185db6f9  vmovaps xmm5, [rsp+0x50]
000074da185db6ff  vmovaps xmm6, [rsp+0x60]
000074da185db705  vmovaps xmm7, [rsp+0x70]
000074da185db70b  vmovaps xmm8, [rsp+0x80]
000074da185db714  vmovaps xmm9, [rsp+0x90]
000074da185db71d  vmovaps xmm10, [rsp+0xA0]
000074da185db726  vmovaps xmm11, [rsp+0xB0]
000074da185db72f  vmovaps xmm12, [rsp+0xC0]
000074da185db738  vmovaps xmm14, [rsp+0xD0]
000074da185db741  vmovaps xmm15, [rsp+0xE0]
000074da185db74a  add rsp, 0xF0
000074da185db751  pop r11
000074da185db753  pop r10
000074da185db755  pop r9
000074da185db757  pop r8
000074da185db759  pop rsi
000074da185db75a  pop rdi
000074da185db75b  pop rdx
000074da185db75c  pop rcx
000074da185db75d  pop rax
000074da185db75e  add rsp, 0x08
000074da185db762  jmp 0x000074DA185DA1F9
000074da185db767  sub rsp, 0x08
000074da185db76b  push rax
000074da185db76c  push rcx
000074da185db76d  push rdx
000074da185db76e  push rdi
000074da185db76f  push rsi
000074da185db770  push r8
000074da185db772  push r9
000074da185db774  push r10
000074da185db776  push r11
000074da185db778  sub rsp, 0xF0
000074da185db77f  vmovaps [rsp], xmm0
000074da185db784  vmovaps [rsp+0x10], xmm1
000074da185db78a  vmovaps [rsp+0x20], xmm2
000074da185db790  vmovaps [rsp+0x30], xmm3
000074da185db796  vmovaps [rsp+0x40], xmm4
000074da185db79c  vmovaps [rsp+0x50], xmm5
000074da185db7a2  vmovaps [rsp+0x60], xmm6
000074da185db7a8  vmovaps [rsp+0x70], xmm7
000074da185db7ae  vmovaps [rsp+0x80], xmm8
000074da185db7b7  vmovaps [rsp+0x90], xmm9
000074da185db7c0  vmovaps [rsp+0xA0], xmm10
000074da185db7c9  vmovaps [rsp+0xB0], xmm11
000074da185db7d2  vmovaps [rsp+0xC0], xmm13
000074da185db7db  vmovaps [rsp+0xD0], xmm14
000074da185db7e4  vmovaps [rsp+0xE0], xmm15
000074da185db7ed  sub rsp, 0x40
000074da185db7f1  lea rdi, [rsp]
000074da185db7f5  lea rsi, [rsp+0x10]
000074da185db7fa  lea rdx, [rsp+0x20]
000074da185db7ff  lea rcx, [rsp+0x30]
000074da185db804  mov r8d, 0x00
000074da185db80a  lea r9, [r15+0x3A8]
000074da185db811  movaps [rdi], xmm12
000074da185db815  movaps [rsi], xmm3
000074da185db818  movaps [rdx], xmm14
000074da185db81c  movaps [rcx], xmm5
000074da185db81f  mov rax, 0x5946061DFA50
000074da185db829  call rax
000074da185db82b  movaps xmm12, [rsp]
000074da185db830  add rsp, 0x40
000074da185db834  vmovaps xmm0, [rsp]
000074da185db839  vmovaps xmm1, [rsp+0x10]
000074da185db83f  vmovaps xmm2, [rsp+0x20]
000074da185db845  vmovaps xmm3, [rsp+0x30]
000074da185db84b  vmovaps xmm4, [rsp+0x40]
000074da185db851  vmovaps xmm5, [rsp+0x50]
000074da185db857  vmovaps xmm6, [rsp+0x60]
000074da185db85d  vmovaps xmm7, [rsp+0x70]
000074da185db863  vmovaps xmm8, [rsp+0x80]
000074da185db86c  vmovaps xmm9, [rsp+0x90]
000074da185db875  vmovaps xmm10, [rsp+0xA0]
000074da185db87e  vmovaps xmm11, [rsp+0xB0]
000074da185db887  vmovaps xmm13, [rsp+0xC0]
000074da185db890  vmovaps xmm14, [rsp+0xD0]
000074da185db899  vmovaps xmm15, [rsp+0xE0]
000074da185db8a2  add rsp, 0xF0
000074da185db8a9  pop r11
000074da185db8ab  pop r10
000074da185db8ad  pop r9
000074da185db8af  pop r8
000074da185db8b1  pop rsi
000074da185db8b2  pop rdi
000074da185db8b3  pop rdx
000074da185db8b4  pop rcx
000074da185db8b5  pop rax
000074da185db8b6  add rsp, 0x08
000074da185db8ba  jmp 0x000074DA185DA256
000074da185db8bf  sub rsp, 0x08
000074da185db8c3  push rax
000074da185db8c4  push rcx
000074da185db8c5  push rdx
000074da185db8c6  push rdi
000074da185db8c7  push rsi
000074da185db8c8  push r8
000074da185db8ca  push r9
000074da185db8cc  push r10
000074da185db8ce  push r11
000074da185db8d0  sub rsp, 0xF0
000074da185db8d7  vmovaps [rsp], xmm0
000074da185db8dc  vmovaps [rsp+0x10], xmm1
000074da185db8e2  vmovaps [rsp+0x20], xmm2
000074da185db8e8  vmovaps [rsp+0x30], xmm3
000074da185db8ee  vmovaps [rsp+0x40], xmm4
000074da185db8f4  vmovaps [rsp+0x50], xmm5
000074da185db8fa  vmovaps [rsp+0x60], xmm6
000074da185db900  vmovaps [rsp+0x70], xmm7
000074da185db906  vmovaps [rsp+0x80], xmm8
000074da185db90f  vmovaps [rsp+0x90], xmm9
000074da185db918  vmovaps [rsp+0xA0], xmm11
000074da185db921  vmovaps [rsp+0xB0], xmm12
000074da185db92a  vmovaps [rsp+0xC0], xmm13
000074da185db933  vmovaps [rsp+0xD0], xmm14
000074da185db93c  vmovaps [rsp+0xE0], xmm15
000074da185db945  sub rsp, 0x40
000074da185db949  lea rdi, [rsp]
000074da185db94d  lea rsi, [rsp+0x10]
000074da185db952  lea rdx, [rsp+0x20]
000074da185db957  lea rcx, [rsp+0x30]
000074da185db95c  mov r8d, 0x00
000074da185db962  lea r9, [r15+0x3A8]
000074da185db969  movaps [rdi], xmm10
000074da185db96d  movaps [rsi], xmm9
000074da185db971  movaps [rdx], xmm7
000074da185db974  movaps [rcx], xmm14
000074da185db978  mov rax, 0x5946061DFA50
000074da185db982  call rax
000074da185db984  movaps xmm10, [rsp]
000074da185db989  add rsp, 0x40
000074da185db98d  vmovaps xmm0, [rsp]
000074da185db992  vmovaps xmm1, [rsp+0x10]
000074da185db998  vmovaps xmm2, [rsp+0x20]
000074da185db99e  vmovaps xmm3, [rsp+0x30]
000074da185db9a4  vmovaps xmm4, [rsp+0x40]
000074da185db9aa  vmovaps xmm5, [rsp+0x50]
000074da185db9b0  vmovaps xmm6, [rsp+0x60]
000074da185db9b6  vmovaps xmm7, [rsp+0x70]
000074da185db9bc  vmovaps xmm8, [rsp+0x80]
000074da185db9c5  vmovaps xmm9, [rsp+0x90]
000074da185db9ce  vmovaps xmm11, [rsp+0xA0]
000074da185db9d7  vmovaps xmm12, [rsp+0xB0]
000074da185db9e0  vmovaps xmm13, [rsp+0xC0]
000074da185db9e9  vmovaps xmm14, [rsp+0xD0]
000074da185db9f2  vmovaps xmm15, [rsp+0xE0]
000074da185db9fb  add rsp, 0xF0
000074da185dba02  pop r11
000074da185dba04  pop r10
000074da185dba06  pop r9
000074da185dba08  pop r8
000074da185dba0a  pop rsi
000074da185dba0b  pop rdi
000074da185dba0c  pop rdx
000074da185dba0d  pop rcx
000074da185dba0e  pop rax
000074da185dba0f  add rsp, 0x08
000074da185dba13  jmp 0x000074DA185DA27C
000074da185dba18  call 0x000074DA1840D4E0
000074da185dba1d  jmp 0x000074DA185DA289
000074da185dba22  sub rsp, 0x08
000074da185dba26  push rax
000074da185dba27  push rcx
000074da185dba28  push rdx
000074da185dba29  push rdi
000074da185dba2a  push rsi
000074da185dba2b  push r8
000074da185dba2d  push r9
000074da185dba2f  push r10
000074da185dba31  push r11
000074da185dba33  sub rsp, 0xF0
000074da185dba3a  vmovaps [rsp], xmm0
000074da185dba3f  vmovaps [rsp+0x10], xmm1
000074da185dba45  vmovaps [rsp+0x20], xmm2
000074da185dba4b  vmovaps [rsp+0x30], xmm3
000074da185dba51  vmovaps [rsp+0x40], xmm4
000074da185dba57  vmovaps [rsp+0x50], xmm6
000074da185dba5d  vmovaps [rsp+0x60], xmm7
000074da185dba63  vmovaps [rsp+0x70], xmm8
000074da185dba69  vmovaps [rsp+0x80], xmm9
000074da185dba72  vmovaps [rsp+0x90], xmm10
000074da185dba7b  vmovaps [rsp+0xA0], xmm11
000074da185dba84  vmovaps [rsp+0xB0], xmm12
000074da185dba8d  vmovaps [rsp+0xC0], xmm13
000074da185dba96  vmovaps [rsp+0xD0], xmm14
000074da185dba9f  vmovaps [rsp+0xE0], xmm15
000074da185dbaa8  sub rsp, 0x40
000074da185dbaac  lea rdi, [rsp]
000074da185dbab0  lea rsi, [rsp+0x10]
000074da185dbab5  lea rdx, [rsp+0x20]
000074da185dbaba  lea rcx, [rsp+0x30]
000074da185dbabf  mov r8d, 0x00
000074da185dbac5  lea r9, [r15+0x3A8]
000074da185dbacc  movaps [rdi], xmm5
000074da185dbacf  movaps [rsi], xmm6
000074da185dbad2  movaps [rdx], xmm7
000074da185dbad5  movaps [rcx], xmm9
000074da185dbad9  mov rax, 0x5946061DFA50
000074da185dbae3  call rax
000074da185dbae5  movaps xmm5, [rsp]
000074da185dbae9  add rsp, 0x40
000074da185dbaed  vmovaps xmm0, [rsp]
000074da185dbaf2  vmovaps xmm1, [rsp+0x10]
000074da185dbaf8  vmovaps xmm2, [rsp+0x20]
000074da185dbafe  vmovaps xmm3, [rsp+0x30]
000074da185dbb04  vmovaps xmm4, [rsp+0x40]
000074da185dbb0a  vmovaps xmm6, [rsp+0x50]
000074da185dbb10  vmovaps xmm7, [rsp+0x60]
000074da185dbb16  vmovaps xmm8, [rsp+0x70]
000074da185dbb1c  vmovaps xmm9, [rsp+0x80]
000074da185dbb25  vmovaps xmm10, [rsp+0x90]
000074da185dbb2e  vmovaps xmm11, [rsp+0xA0]
000074da185dbb37  vmovaps xmm12, [rsp+0xB0]
000074da185dbb40  vmovaps xmm13, [rsp+0xC0]
000074da185dbb49  vmovaps xmm14, [rsp+0xD0]
000074da185dbb52  vmovaps xmm15, [rsp+0xE0]
000074da185dbb5b  add rsp, 0xF0
000074da185dbb62  pop r11
000074da185dbb64  pop r10
000074da185dbb66  pop r9
000074da185dbb68  pop r8
000074da185dbb6a  pop rsi
000074da185dbb6b  pop rdi
000074da185dbb6c  pop rdx
000074da185dbb6d  pop rcx
000074da185dbb6e  pop rax
000074da185dbb6f  add rsp, 0x08
000074da185dbb73  jmp 0x000074DA185DA2BB
000074da185dbb78  sub rsp, 0x08
000074da185dbb7c  push rax
000074da185dbb7d  push rcx
000074da185dbb7e  push rdx
000074da185dbb7f  push rdi
000074da185dbb80  push rsi
000074da185dbb81  push r8
000074da185dbb83  push r9
000074da185dbb85  push r10
000074da185dbb87  push r11
000074da185dbb89  sub rsp, 0xF0
000074da185dbb90  vmovaps [rsp], xmm0
000074da185dbb95  vmovaps [rsp+0x10], xmm1
000074da185dbb9b  vmovaps [rsp+0x20], xmm2
000074da185dbba1  vmovaps [rsp+0x30], xmm3
000074da185dbba7  vmovaps [rsp+0x40], xmm4
000074da185dbbad  vmovaps [rsp+0x50], xmm5
000074da185dbbb3  vmovaps [rsp+0x60], xmm6
000074da185dbbb9  vmovaps [rsp+0x70], xmm8
000074da185dbbbf  vmovaps [rsp+0x80], xmm9
000074da185dbbc8  vmovaps [rsp+0x90], xmm10
000074da185dbbd1  vmovaps [rsp+0xA0], xmm11
000074da185dbbda  vmovaps [rsp+0xB0], xmm12
000074da185dbbe3  vmovaps [rsp+0xC0], xmm13
000074da185dbbec  vmovaps [rsp+0xD0], xmm14
000074da185dbbf5  vmovaps [rsp+0xE0], xmm15
000074da185dbbfe  sub rsp, 0x40
000074da185dbc02  lea rdi, [rsp]
000074da185dbc06  lea rsi, [rsp+0x10]
000074da185dbc0b  lea rdx, [rsp+0x20]
000074da185dbc10  lea rcx, [rsp+0x30]
000074da185dbc15  mov r8d, 0x00
000074da185dbc1b  lea r9, [r15+0x3A8]
000074da185dbc22  movaps [rdi], xmm7
000074da185dbc25  movaps [rsi], xmm13
000074da185dbc29  movaps [rdx], xmm1
000074da185dbc2c  movaps [rcx], xmm9
000074da185dbc30  mov rax, 0x5946061DFA50
000074da185dbc3a  call rax
000074da185dbc3c  movaps xmm7, [rsp]
000074da185dbc40  add rsp, 0x40
000074da185dbc44  vmovaps xmm0, [rsp]
000074da185dbc49  vmovaps xmm1, [rsp+0x10]
000074da185dbc4f  vmovaps xmm2, [rsp+0x20]
000074da185dbc55  vmovaps xmm3, [rsp+0x30]
000074da185dbc5b  vmovaps xmm4, [rsp+0x40]
000074da185dbc61  vmovaps xmm5, [rsp+0x50]
000074da185dbc67  vmovaps xmm6, [rsp+0x60]
000074da185dbc6d  vmovaps xmm8, [rsp+0x70]
000074da185dbc73  vmovaps xmm9, [rsp+0x80]
000074da185dbc7c  vmovaps xmm10, [rsp+0x90]
000074da185dbc85  vmovaps xmm11, [rsp+0xA0]
000074da185dbc8e  vmovaps xmm12, [rsp+0xB0]
000074da185dbc97  vmovaps xmm13, [rsp+0xC0]
000074da185dbca0  vmovaps xmm14, [rsp+0xD0]
000074da185dbca9  vmovaps xmm15, [rsp+0xE0]
000074da185dbcb2  add rsp, 0xF0
000074da185dbcb9  pop r11
000074da185dbcbb  pop r10
000074da185dbcbd  pop r9
000074da185dbcbf  pop r8
000074da185dbcc1  pop rsi
000074da185dbcc2  pop rdi
000074da185dbcc3  pop rdx
000074da185dbcc4  pop rcx
000074da185dbcc5  pop rax
000074da185dbcc6  add rsp, 0x08
000074da185dbcca  jmp 0x000074DA185DA2E0
000074da185dbccf  call 0x000074DA1840C260
000074da185dbcd4  jmp 0x000074DA185DA303
000074da185dbcd9  call 0x000074DA18407890
000074da185dbcde  jmp 0x000074DA185DA30D
000074da185dbce3  sub rsp, 0x08
000074da185dbce7  push rax
000074da185dbce8  push rcx
000074da185dbce9  push rdx
000074da185dbcea  push rdi
000074da185dbceb  push rsi
000074da185dbcec  push r8
000074da185dbcee  push r9
000074da185dbcf0  push r10
000074da185dbcf2  push r11
000074da185dbcf4  sub rsp, 0xF0
000074da185dbcfb  vmovaps [rsp], xmm0
000074da185dbd00  vmovaps [rsp+0x10], xmm1
000074da185dbd06  vmovaps [rsp+0x20], xmm3
000074da185dbd0c  vmovaps [rsp+0x30], xmm4
000074da185dbd12  vmovaps [rsp+0x40], xmm5
000074da185dbd18  vmovaps [rsp+0x50], xmm6
000074da185dbd1e  vmovaps [rsp+0x60], xmm7
000074da185dbd24  vmovaps [rsp+0x70], xmm8
000074da185dbd2a  vmovaps [rsp+0x80], xmm9
000074da185dbd33  vmovaps [rsp+0x90], xmm10
000074da185dbd3c  vmovaps [rsp+0xA0], xmm11
000074da185dbd45  vmovaps [rsp+0xB0], xmm12
000074da185dbd4e  vmovaps [rsp+0xC0], xmm13
000074da185dbd57  vmovaps [rsp+0xD0], xmm14
000074da185dbd60  vmovaps [rsp+0xE0], xmm15
000074da185dbd69  sub rsp, 0x40
000074da185dbd6d  lea rdi, [rsp]
000074da185dbd71  lea rsi, [rsp+0x10]
000074da185dbd76  lea rdx, [rsp+0x20]
000074da185dbd7b  lea rcx, [rsp+0x30]
000074da185dbd80  mov r8d, 0x00
000074da185dbd86  lea r9, [r15+0x3A8]
000074da185dbd8d  movaps [rdi], xmm2
000074da185dbd90  movaps [rsi], xmm12
000074da185dbd94  movaps [rdx], xmm6
000074da185dbd97  movaps [rcx], xmm3
000074da185dbd9a  mov rax, 0x5946061DFA50
000074da185dbda4  call rax
000074da185dbda6  movaps xmm2, [rsp]
000074da185dbdaa  add rsp, 0x40
000074da185dbdae  vmovaps xmm0, [rsp]
000074da185dbdb3  vmovaps xmm1, [rsp+0x10]
000074da185dbdb9  vmovaps xmm3, [rsp+0x20]
000074da185dbdbf  vmovaps xmm4, [rsp+0x30]
000074da185dbdc5  vmovaps xmm5, [rsp+0x40]
000074da185dbdcb  vmovaps xmm6, [rsp+0x50]
000074da185dbdd1  vmovaps xmm7, [rsp+0x60]
000074da185dbdd7  vmovaps xmm8, [rsp+0x70]
000074da185dbddd  vmovaps xmm9, [rsp+0x80]
000074da185dbde6  vmovaps xmm10, [rsp+0x90]
000074da185dbdef  vmovaps xmm11, [rsp+0xA0]
000074da185dbdf8  vmovaps xmm12, [rsp+0xB0]
000074da185dbe01  vmovaps xmm13, [rsp+0xC0]
000074da185dbe0a  vmovaps xmm14, [rsp+0xD0]
000074da185dbe13  vmovaps xmm15, [rsp+0xE0]
000074da185dbe1c  add rsp, 0xF0
000074da185dbe23  pop r11
000074da185dbe25  pop r10
000074da185dbe27  pop r9
000074da185dbe29  pop r8
000074da185dbe2b  pop rsi
000074da185dbe2c  pop rdi
000074da185dbe2d  pop rdx
000074da185dbe2e  pop rcx
000074da185dbe2f  pop rax
000074da185dbe30  add rsp, 0x08
000074da185dbe34  jmp 0x000074DA185DA353
000074da185dbe39  sub rsp, 0x08
000074da185dbe3d  push rax
000074da185dbe3e  push rcx
000074da185dbe3f  push rdx
000074da185dbe40  push rdi
000074da185dbe41  push rsi
000074da185dbe42  push r8
000074da185dbe44  push r9
000074da185dbe46  push r10
000074da185dbe48  push r11
000074da185dbe4a  sub rsp, 0xF0
000074da185dbe51  vmovaps [rsp], xmm0
000074da185dbe56  vmovaps [rsp+0x10], xmm1
000074da185dbe5c  vmovaps [rsp+0x20], xmm2
000074da185dbe62  vmovaps [rsp+0x30], xmm3
000074da185dbe68  vmovaps [rsp+0x40], xmm4
000074da185dbe6e  vmovaps [rsp+0x50], xmm5
000074da185dbe74  vmovaps [rsp+0x60], xmm7
000074da185dbe7a  vmovaps [rsp+0x70], xmm8
000074da185dbe80  vmovaps [rsp+0x80], xmm9
000074da185dbe89  vmovaps [rsp+0x90], xmm10
000074da185dbe92  vmovaps [rsp+0xA0], xmm11
000074da185dbe9b  vmovaps [rsp+0xB0], xmm12
000074da185dbea4  vmovaps [rsp+0xC0], xmm13
000074da185dbead  vmovaps [rsp+0xD0], xmm14
000074da185dbeb6  vmovaps [rsp+0xE0], xmm15
000074da185dbebf  sub rsp, 0x40
000074da185dbec3  lea rdi, [rsp]
000074da185dbec7  lea rsi, [rsp+0x10]
000074da185dbecc  lea rdx, [rsp+0x20]
000074da185dbed1  lea rcx, [rsp+0x30]
000074da185dbed6  mov r8d, 0x00
000074da185dbedc  lea r9, [r15+0x3A8]
000074da185dbee3  movaps [rdi], xmm6
000074da185dbee6  movaps [rsi], xmm10
000074da185dbeea  movaps [rdx], xmm12
000074da185dbeee  movaps [rcx], xmm1
000074da185dbef1  mov rax, 0x5946061DFA50
000074da185dbefb  call rax
000074da185dbefd  movaps xmm6, [rsp]
000074da185dbf01  add rsp, 0x40
000074da185dbf05  vmovaps xmm0, [rsp]
000074da185dbf0a  vmovaps xmm1, [rsp+0x10]
000074da185dbf10  vmovaps xmm2, [rsp+0x20]
000074da185dbf16  vmovaps xmm3, [rsp+0x30]
000074da185dbf1c  vmovaps xmm4, [rsp+0x40]
000074da185dbf22  vmovaps xmm5, [rsp+0x50]
000074da185dbf28  vmovaps xmm7, [rsp+0x60]
000074da185dbf2e  vmovaps xmm8, [rsp+0x70]
000074da185dbf34  vmovaps xmm9, [rsp+0x80]
000074da185dbf3d  vmovaps xmm10, [rsp+0x90]
000074da185dbf46  vmovaps xmm11, [rsp+0xA0]
000074da185dbf4f  vmovaps xmm12, [rsp+0xB0]
000074da185dbf58  vmovaps xmm13, [rsp+0xC0]
000074da185dbf61  vmovaps xmm14, [rsp+0xD0]
000074da185dbf6a  vmovaps xmm15, [rsp+0xE0]
000074da185dbf73  add rsp, 0xF0
000074da185dbf7a  pop r11
000074da185dbf7c  pop r10
000074da185dbf7e  pop r9
000074da185dbf80  pop r8
000074da185dbf82  pop rsi
000074da185dbf83  pop rdi
000074da185dbf84  pop rdx
000074da185dbf85  pop rcx
000074da185dbf86  pop rax
000074da185dbf87  add rsp, 0x08
000074da185dbf8b  jmp 0x000074DA185DA381
000074da185dbf90  sub rsp, 0x08
000074da185dbf94  push rax
000074da185dbf95  push rcx
000074da185dbf96  push rdx
000074da185dbf97  push rdi
000074da185dbf98  push rsi
000074da185dbf99  push r8
000074da185dbf9b  push r9
000074da185dbf9d  push r10
000074da185dbf9f  push r11
000074da185dbfa1  sub rsp, 0xF0
000074da185dbfa8  vmovaps [rsp], xmm0
000074da185dbfad  vmovaps [rsp+0x10], xmm1
000074da185dbfb3  vmovaps [rsp+0x20], xmm2
000074da185dbfb9  vmovaps [rsp+0x30], xmm3
000074da185dbfbf  vmovaps [rsp+0x40], xmm4
000074da185dbfc5  vmovaps [rsp+0x50], xmm5
000074da185dbfcb  vmovaps [rsp+0x60], xmm6
000074da185dbfd1  vmovaps [rsp+0x70], xmm7
000074da185dbfd7  vmovaps [rsp+0x80], xmm8
000074da185dbfe0  vmovaps [rsp+0x90], xmm9
000074da185dbfe9  vmovaps [rsp+0xA0], xmm11
000074da185dbff2  vmovaps [rsp+0xB0], xmm12
000074da185dbffb  vmovaps [rsp+0xC0], xmm13
000074da185dc004  vmovaps [rsp+0xD0], xmm14
000074da185dc00d  vmovaps [rsp+0xE0], xmm15
000074da185dc016  sub rsp, 0x40
000074da185dc01a  lea rdi, [rsp]
000074da185dc01e  lea rsi, [rsp+0x10]
000074da185dc023  lea rdx, [rsp+0x20]
000074da185dc028  lea rcx, [rsp+0x30]
000074da185dc02d  mov r8d, 0x00
000074da185dc033  lea r9, [r15+0x3A8]
000074da185dc03a  movaps [rdi], xmm10
000074da185dc03e  movaps [rsi], xmm5
000074da185dc041  movaps [rdx], xmm12
000074da185dc045  movaps [rcx], xmm1
000074da185dc048  mov rax, 0x5946061DFA50
000074da185dc052  call rax
000074da185dc054  movaps xmm10, [rsp]
000074da185dc059  add rsp, 0x40
000074da185dc05d  vmovaps xmm0, [rsp]
000074da185dc062  vmovaps xmm1, [rsp+0x10]
000074da185dc068  vmovaps xmm2, [rsp+0x20]
000074da185dc06e  vmovaps xmm3, [rsp+0x30]
000074da185dc074  vmovaps xmm4, [rsp+0x40]
000074da185dc07a  vmovaps xmm5, [rsp+0x50]
000074da185dc080  vmovaps xmm6, [rsp+0x60]
000074da185dc086  vmovaps xmm7, [rsp+0x70]
000074da185dc08c  vmovaps xmm8, [rsp+0x80]
000074da185dc095  vmovaps xmm9, [rsp+0x90]
000074da185dc09e  vmovaps xmm11, [rsp+0xA0]
000074da185dc0a7  vmovaps xmm12, [rsp+0xB0]
000074da185dc0b0  vmovaps xmm13, [rsp+0xC0]
000074da185dc0b9  vmovaps xmm14, [rsp+0xD0]
000074da185dc0c2  vmovaps xmm15, [rsp+0xE0]
000074da185dc0cb  add rsp, 0xF0
000074da185dc0d2  pop r11
000074da185dc0d4  pop r10
000074da185dc0d6  pop r9
000074da185dc0d8  pop r8
000074da185dc0da  pop rsi
000074da185dc0db  pop rdi
000074da185dc0dc  pop rdx
000074da185dc0dd  pop rcx
000074da185dc0de  pop rax
000074da185dc0df  add rsp, 0x08
000074da185dc0e3  jmp 0x000074DA185DA3B0
000074da185dc0e8  sub rsp, 0x08
000074da185dc0ec  push rax
000074da185dc0ed  push rcx
000074da185dc0ee  push rdx
000074da185dc0ef  push rdi
000074da185dc0f0  push rsi
000074da185dc0f1  push r8
000074da185dc0f3  push r9
000074da185dc0f5  push r10
000074da185dc0f7  push r11
000074da185dc0f9  sub rsp, 0xF0
000074da185dc100  vmovaps [rsp], xmm0
000074da185dc105  vmovaps [rsp+0x10], xmm1
000074da185dc10b  vmovaps [rsp+0x20], xmm2
000074da185dc111  vmovaps [rsp+0x30], xmm3
000074da185dc117  vmovaps [rsp+0x40], xmm4
000074da185dc11d  vmovaps [rsp+0x50], xmm5
000074da185dc123  vmovaps [rsp+0x60], xmm6
000074da185dc129  vmovaps [rsp+0x70], xmm7
000074da185dc12f  vmovaps [rsp+0x80], xmm8
000074da185dc138  vmovaps [rsp+0x90], xmm9
000074da185dc141  vmovaps [rsp+0xA0], xmm10
000074da185dc14a  vmovaps [rsp+0xB0], xmm11
000074da185dc153  vmovaps [rsp+0xC0], xmm13
000074da185dc15c  vmovaps [rsp+0xD0], xmm14
000074da185dc165  vmovaps [rsp+0xE0], xmm15
000074da185dc16e  sub rsp, 0x40
000074da185dc172  lea rdi, [rsp]
000074da185dc176  lea rsi, [rsp+0x10]
000074da185dc17b  lea rdx, [rsp+0x20]
000074da185dc180  lea rcx, [rsp+0x30]
000074da185dc185  mov r8d, 0x00
000074da185dc18b  lea r9, [r15+0x3A8]
000074da185dc192  movaps [rdi], xmm12
000074da185dc196  movaps [rsi], xmm7
000074da185dc199  movaps [rdx], xmm15
000074da185dc19d  movaps [rcx], xmm1
000074da185dc1a0  mov rax, 0x5946061DFA50
000074da185dc1aa  call rax
000074da185dc1ac  movaps xmm12, [rsp]
000074da185dc1b1  add rsp, 0x40
000074da185dc1b5  vmovaps xmm0, [rsp]
000074da185dc1ba  vmovaps xmm1, [rsp+0x10]
000074da185dc1c0  vmovaps xmm2, [rsp+0x20]
000074da185dc1c6  vmovaps xmm3, [rsp+0x30]
000074da185dc1cc  vmovaps xmm4, [rsp+0x40]
000074da185dc1d2  vmovaps xmm5, [rsp+0x50]
000074da185dc1d8  vmovaps xmm6, [rsp+0x60]
000074da185dc1de  vmovaps xmm7, [rsp+0x70]
000074da185dc1e4  vmovaps xmm8, [rsp+0x80]
000074da185dc1ed  vmovaps xmm9, [rsp+0x90]
000074da185dc1f6  vmovaps xmm10, [rsp+0xA0]
000074da185dc1ff  vmovaps xmm11, [rsp+0xB0]
000074da185dc208  vmovaps xmm13, [rsp+0xC0]
000074da185dc211  vmovaps xmm14, [rsp+0xD0]
000074da185dc21a  vmovaps xmm15, [rsp+0xE0]
000074da185dc223  add rsp, 0xF0
000074da185dc22a  pop r11
000074da185dc22c  pop r10
000074da185dc22e  pop r9
000074da185dc230  pop r8
000074da185dc232  pop rsi
000074da185dc233  pop rdi
000074da185dc234  pop rdx
000074da185dc235  pop rcx
000074da185dc236  pop rax
000074da185dc237  add rsp, 0x08
000074da185dc23b  jmp 0x000074DA185DA3D9
000074da185dc240  call 0x000074DA183FF430
000074da185dc245  jmp 0x000074DA185DA3E3
000074da185dc24a  call 0x000074DA1840E760
000074da185dc24f  jmp 0x000074DA185DA3ED
000074da185dc254  sub rsp, 0x08
000074da185dc258  push rax
000074da185dc259  push rcx
000074da185dc25a  push rdx
000074da185dc25b  push rdi
000074da185dc25c  push rsi
000074da185dc25d  push r8
000074da185dc25f  push r9
000074da185dc261  push r10
000074da185dc263  push r11
000074da185dc265  sub rsp, 0xF0
000074da185dc26c  vmovaps [rsp], xmm0
000074da185dc271  vmovaps [rsp+0x10], xmm1
000074da185dc277  vmovaps [rsp+0x20], xmm2
000074da185dc27d  vmovaps [rsp+0x30], xmm3
000074da185dc283  vmovaps [rsp+0x40], xmm4
000074da185dc289  vmovaps [rsp+0x50], xmm5
000074da185dc28f  vmovaps [rsp+0x60], xmm6
000074da185dc295  vmovaps [rsp+0x70], xmm8
000074da185dc29b  vmovaps [rsp+0x80], xmm9
000074da185dc2a4  vmovaps [rsp+0x90], xmm10
000074da185dc2ad  vmovaps [rsp+0xA0], xmm11
000074da185dc2b6  vmovaps [rsp+0xB0], xmm12
000074da185dc2bf  vmovaps [rsp+0xC0], xmm13
000074da185dc2c8  vmovaps [rsp+0xD0], xmm14
000074da185dc2d1  vmovaps [rsp+0xE0], xmm15
000074da185dc2da  sub rsp, 0x40
000074da185dc2de  lea rdi, [rsp]
000074da185dc2e2  lea rsi, [rsp+0x10]
000074da185dc2e7  lea rdx, [rsp+0x20]
000074da185dc2ec  lea rcx, [rsp+0x30]
000074da185dc2f1  mov r8d, 0x00
000074da185dc2f7  lea r9, [r15+0x3A8]
000074da185dc2fe  movaps [rdi], xmm7
000074da185dc301  movaps [rsi], xmm2
000074da185dc304  movaps [rdx], xmm9
000074da185dc308  movaps [rcx], xmm11
000074da185dc30c  mov rax, 0x5946061DFA50
000074da185dc316  call rax
000074da185dc318  movaps xmm7, [rsp]
000074da185dc31c  add rsp, 0x40
000074da185dc320  vmovaps xmm0, [rsp]
000074da185dc325  vmovaps xmm1, [rsp+0x10]
000074da185dc32b  vmovaps xmm2, [rsp+0x20]
000074da185dc331  vmovaps xmm3, [rsp+0x30]
000074da185dc337  vmovaps xmm4, [rsp+0x40]
000074da185dc33d  vmovaps xmm5, [rsp+0x50]
000074da185dc343  vmovaps xmm6, [rsp+0x60]
000074da185dc349  vmovaps xmm8, [rsp+0x70]
000074da185dc34f  vmovaps xmm9, [rsp+0x80]
000074da185dc358  vmovaps xmm10, [rsp+0x90]
000074da185dc361  vmovaps xmm11, [rsp+0xA0]
000074da185dc36a  vmovaps xmm12, [rsp+0xB0]
000074da185dc373  vmovaps xmm13, [rsp+0xC0]
000074da185dc37c  vmovaps xmm14, [rsp+0xD0]
000074da185dc385  vmovaps xmm15, [rsp+0xE0]
000074da185dc38e  add rsp, 0xF0
000074da185dc395  pop r11
000074da185dc397  pop r10
000074da185dc399  pop r9
000074da185dc39b  pop r8
000074da185dc39d  pop rsi
000074da185dc39e  pop rdi
000074da185dc39f  pop rdx
000074da185dc3a0  pop rcx
000074da185dc3a1  pop rax
000074da185dc3a2  add rsp, 0x08
000074da185dc3a6  jmp 0x000074DA185DA421
000074da185dc3ab  sub rsp, 0x08
000074da185dc3af  push rax
000074da185dc3b0  push rcx
000074da185dc3b1  push rdx
000074da185dc3b2  push rdi
000074da185dc3b3  push rsi
000074da185dc3b4  push r8
000074da185dc3b6  push r9
000074da185dc3b8  push r10
000074da185dc3ba  push r11
000074da185dc3bc  sub rsp, 0xF0
000074da185dc3c3  vmovaps [rsp], xmm0
000074da185dc3c8  vmovaps [rsp+0x10], xmm1
000074da185dc3ce  vmovaps [rsp+0x20], xmm2
000074da185dc3d4  vmovaps [rsp+0x30], xmm3
000074da185dc3da  vmovaps [rsp+0x40], xmm4
000074da185dc3e0  vmovaps [rsp+0x50], xmm5
000074da185dc3e6  vmovaps [rsp+0x60], xmm6
000074da185dc3ec  vmovaps [rsp+0x70], xmm7
000074da185dc3f2  vmovaps [rsp+0x80], xmm8
000074da185dc3fb  vmovaps [rsp+0x90], xmm10
000074da185dc404  vmovaps [rsp+0xA0], xmm11
000074da185dc40d  vmovaps [rsp+0xB0], xmm12
000074da185dc416  vmovaps [rsp+0xC0], xmm13
000074da185dc41f  vmovaps [rsp+0xD0], xmm14
000074da185dc428  vmovaps [rsp+0xE0], xmm15
000074da185dc431  sub rsp, 0x40
000074da185dc435  lea rdi, [rsp]
000074da185dc439  lea rsi, [rsp+0x10]
000074da185dc43e  lea rdx, [rsp+0x20]
000074da185dc443  lea rcx, [rsp+0x30]
000074da185dc448  mov r8d, 0x00
000074da185dc44e  lea r9, [r15+0x3A8]
000074da185dc455  movaps [rdi], xmm9
000074da185dc459  movaps [rsi], xmm6
000074da185dc45c  movaps [rdx], xmm1
000074da185dc45f  movaps [rcx], xmm11
000074da185dc463  mov rax, 0x5946061DFA50
000074da185dc46d  call rax
000074da185dc46f  movaps xmm9, [rsp]
000074da185dc474  add rsp, 0x40
000074da185dc478  vmovaps xmm0, [rsp]
000074da185dc47d  vmovaps xmm1, [rsp+0x10]
000074da185dc483  vmovaps xmm2, [rsp+0x20]
000074da185dc489  vmovaps xmm3, [rsp+0x30]
000074da185dc48f  vmovaps xmm4, [rsp+0x40]
000074da185dc495  vmovaps xmm5, [rsp+0x50]
000074da185dc49b  vmovaps xmm6, [rsp+0x60]
000074da185dc4a1  vmovaps xmm7, [rsp+0x70]
000074da185dc4a7  vmovaps xmm8, [rsp+0x80]
000074da185dc4b0  vmovaps xmm10, [rsp+0x90]
000074da185dc4b9  vmovaps xmm11, [rsp+0xA0]
000074da185dc4c2  vmovaps xmm12, [rsp+0xB0]
000074da185dc4cb  vmovaps xmm13, [rsp+0xC0]
000074da185dc4d4  vmovaps xmm14, [rsp+0xD0]
000074da185dc4dd  vmovaps xmm15, [rsp+0xE0]
000074da185dc4e6  add rsp, 0xF0
000074da185dc4ed  pop r11
000074da185dc4ef  pop r10
000074da185dc4f1  pop r9
000074da185dc4f3  pop r8
000074da185dc4f5  pop rsi
000074da185dc4f6  pop rdi
000074da185dc4f7  pop rdx
000074da185dc4f8  pop rcx
000074da185dc4f9  pop rax
000074da185dc4fa  add rsp, 0x08
000074da185dc4fe  jmp 0x000074DA185DA447
000074da185dc503  sub rsp, 0x08
000074da185dc507  push rax
000074da185dc508  push rcx
000074da185dc509  push rdx
000074da185dc50a  push rdi
000074da185dc50b  push rsi
000074da185dc50c  push r8
000074da185dc50e  push r9
000074da185dc510  push r10
000074da185dc512  push r11
000074da185dc514  sub rsp, 0xF0
000074da185dc51b  vmovaps [rsp], xmm0
000074da185dc520  vmovaps [rsp+0x10], xmm1
000074da185dc526  vmovaps [rsp+0x20], xmm2
000074da185dc52c  vmovaps [rsp+0x30], xmm3
000074da185dc532  vmovaps [rsp+0x40], xmm4
000074da185dc538  vmovaps [rsp+0x50], xmm5
000074da185dc53e  vmovaps [rsp+0x60], xmm6
000074da185dc544  vmovaps [rsp+0x70], xmm7
000074da185dc54a  vmovaps [rsp+0x80], xmm8
000074da185dc553  vmovaps [rsp+0x90], xmm9
000074da185dc55c  vmovaps [rsp+0xA0], xmm10
000074da185dc565  vmovaps [rsp+0xB0], xmm12
000074da185dc56e  vmovaps [rsp+0xC0], xmm13
000074da185dc577  vmovaps [rsp+0xD0], xmm14
000074da185dc580  vmovaps [rsp+0xE0], xmm15
000074da185dc589  sub rsp, 0x40
000074da185dc58d  lea rdi, [rsp]
000074da185dc591  lea rsi, [rsp+0x10]
000074da185dc596  lea rdx, [rsp+0x20]
000074da185dc59b  lea rcx, [rsp+0x30]
000074da185dc5a0  mov r8d, 0x00
000074da185dc5a6  lea r9, [r15+0x3A8]
000074da185dc5ad  movaps [rdi], xmm11
000074da185dc5b1  movaps [rsi], xmm10
000074da185dc5b5  movaps [rdx], xmm8
000074da185dc5b9  movaps [rcx], xmm1
000074da185dc5bc  mov rax, 0x5946061DFA50
000074da185dc5c6  call rax
000074da185dc5c8  movaps xmm11, [rsp]
000074da185dc5cd  add rsp, 0x40
000074da185dc5d1  vmovaps xmm0, [rsp]
000074da185dc5d6  vmovaps xmm1, [rsp+0x10]
000074da185dc5dc  vmovaps xmm2, [rsp+0x20]
000074da185dc5e2  vmovaps xmm3, [rsp+0x30]
000074da185dc5e8  vmovaps xmm4, [rsp+0x40]
000074da185dc5ee  vmovaps xmm5, [rsp+0x50]
000074da185dc5f4  vmovaps xmm6, [rsp+0x60]
000074da185dc5fa  vmovaps xmm7, [rsp+0x70]
000074da185dc600  vmovaps xmm8, [rsp+0x80]
000074da185dc609  vmovaps xmm9, [rsp+0x90]
000074da185dc612  vmovaps xmm10, [rsp+0xA0]
000074da185dc61b  vmovaps xmm12, [rsp+0xB0]
000074da185dc624  vmovaps xmm13, [rsp+0xC0]
000074da185dc62d  vmovaps xmm14, [rsp+0xD0]
000074da185dc636  vmovaps xmm15, [rsp+0xE0]
000074da185dc63f  add rsp, 0xF0
000074da185dc646  pop r11
000074da185dc648  pop r10
000074da185dc64a  pop r9
000074da185dc64c  pop r8
000074da185dc64e  pop rsi
000074da185dc64f  pop rdi
000074da185dc650  pop rdx
000074da185dc651  pop rcx
000074da185dc652  pop rax
000074da185dc653  add rsp, 0x08
000074da185dc657  jmp 0x000074DA185DA46D
000074da185dc65c  sub rsp, 0x08
000074da185dc660  push rax
000074da185dc661  push rcx
000074da185dc662  push rdx
000074da185dc663  push rdi
000074da185dc664  push rsi
000074da185dc665  push r8
000074da185dc667  push r9
000074da185dc669  push r10
000074da185dc66b  push r11
000074da185dc66d  sub rsp, 0xF0
000074da185dc674  vmovaps [rsp], xmm0
000074da185dc679  vmovaps [rsp+0x10], xmm1
000074da185dc67f  vmovaps [rsp+0x20], xmm2
000074da185dc685  vmovaps [rsp+0x30], xmm3
000074da185dc68b  vmovaps [rsp+0x40], xmm4
000074da185dc691  vmovaps [rsp+0x50], xmm5
000074da185dc697  vmovaps [rsp+0x60], xmm6
000074da185dc69d  vmovaps [rsp+0x70], xmm7
000074da185dc6a3  vmovaps [rsp+0x80], xmm8
000074da185dc6ac  vmovaps [rsp+0x90], xmm9
000074da185dc6b5  vmovaps [rsp+0xA0], xmm11
000074da185dc6be  vmovaps [rsp+0xB0], xmm12
000074da185dc6c7  vmovaps [rsp+0xC0], xmm13
000074da185dc6d0  vmovaps [rsp+0xD0], xmm14
000074da185dc6d9  vmovaps [rsp+0xE0], xmm15
000074da185dc6e2  sub rsp, 0x40
000074da185dc6e6  lea rdi, [rsp]
000074da185dc6ea  lea rsi, [rsp+0x10]
000074da185dc6ef  lea rdx, [rsp+0x20]
000074da185dc6f4  lea rcx, [rsp+0x30]
000074da185dc6f9  mov r8d, 0x00
000074da185dc6ff  lea r9, [r15+0x3A8]
000074da185dc706  movaps [rdi], xmm10
000074da185dc70a  movaps [rsi], xmm12
000074da185dc70e  movaps [rdx], xmm13
000074da185dc712  movaps [rcx], xmm1
000074da185dc715  mov rax, 0x5946061DFA50
000074da185dc71f  call rax
000074da185dc721  movaps xmm10, [rsp]
000074da185dc726  add rsp, 0x40
000074da185dc72a  vmovaps xmm0, [rsp]
000074da185dc72f  vmovaps xmm1, [rsp+0x10]
000074da185dc735  vmovaps xmm2, [rsp+0x20]
000074da185dc73b  vmovaps xmm3, [rsp+0x30]
000074da185dc741  vmovaps xmm4, [rsp+0x40]
000074da185dc747  vmovaps xmm5, [rsp+0x50]
000074da185dc74d  vmovaps xmm6, [rsp+0x60]
000074da185dc753  vmovaps xmm7, [rsp+0x70]
000074da185dc759  vmovaps xmm8, [rsp+0x80]
000074da185dc762  vmovaps xmm9, [rsp+0x90]
000074da185dc76b  vmovaps xmm11, [rsp+0xA0]
000074da185dc774  vmovaps xmm12, [rsp+0xB0]
000074da185dc77d  vmovaps xmm13, [rsp+0xC0]
000074da185dc786  vmovaps xmm14, [rsp+0xD0]
000074da185dc78f  vmovaps xmm15, [rsp+0xE0]
000074da185dc798  add rsp, 0xF0
000074da185dc79f  pop r11
000074da185dc7a1  pop r10
000074da185dc7a3  pop r9
000074da185dc7a5  pop r8
000074da185dc7a7  pop rsi
000074da185dc7a8  pop rdi
000074da185dc7a9  pop rdx
000074da185dc7aa  pop rcx
000074da185dc7ab  pop rax
000074da185dc7ac  add rsp, 0x08
000074da185dc7b0  jmp 0x000074DA185DA493
000074da185dc7b5  call 0x000074DA183FF430
000074da185dc7ba  jmp 0x000074DA185DA49D
000074da185dc7bf  call 0x000074DA1840C260
000074da185dc7c4  jmp 0x000074DA185DA4A7
000074da185dc7c9  sub rsp, 0x08
000074da185dc7cd  push rax
000074da185dc7ce  push rcx
000074da185dc7cf  push rdx
000074da185dc7d0  push rdi
000074da185dc7d1  push rsi
000074da185dc7d2  push r8
000074da185dc7d4  push r9
000074da185dc7d6  push r10
000074da185dc7d8  push r11
000074da185dc7da  sub rsp, 0xF0
000074da185dc7e1  vmovaps [rsp], xmm0
000074da185dc7e6  vmovaps [rsp+0x10], xmm1
000074da185dc7ec  vmovaps [rsp+0x20], xmm2
000074da185dc7f2  vmovaps [rsp+0x30], xmm3
000074da185dc7f8  vmovaps [rsp+0x40], xmm4
000074da185dc7fe  vmovaps [rsp+0x50], xmm5
000074da185dc804  vmovaps [rsp+0x60], xmm6
000074da185dc80a  vmovaps [rsp+0x70], xmm7
000074da185dc810  vmovaps [rsp+0x80], xmm9
000074da185dc819  vmovaps [rsp+0x90], xmm10
000074da185dc822  vmovaps [rsp+0xA0], xmm11
000074da185dc82b  vmovaps [rsp+0xB0], xmm12
000074da185dc834  vmovaps [rsp+0xC0], xmm13
000074da185dc83d  vmovaps [rsp+0xD0], xmm14
000074da185dc846  vmovaps [rsp+0xE0], xmm15
000074da185dc84f  sub rsp, 0x40
000074da185dc853  lea rdi, [rsp]
000074da185dc857  lea rsi, [rsp+0x10]
000074da185dc85c  lea rdx, [rsp+0x20]
000074da185dc861  lea rcx, [rsp+0x30]
000074da185dc866  mov r8d, 0x00
000074da185dc86c  lea r9, [r15+0x3A8]
000074da185dc873  movaps [rdi], xmm8
000074da185dc877  movaps [rsi], xmm7
000074da185dc87a  movaps [rdx], xmm4
000074da185dc87d  movaps [rcx], xmm12
000074da185dc881  mov rax, 0x5946061DFA50
000074da185dc88b  call rax
000074da185dc88d  movaps xmm8, [rsp]
000074da185dc892  add rsp, 0x40
000074da185dc896  vmovaps xmm0, [rsp]
000074da185dc89b  vmovaps xmm1, [rsp+0x10]
000074da185dc8a1  vmovaps xmm2, [rsp+0x20]
000074da185dc8a7  vmovaps xmm3, [rsp+0x30]
000074da185dc8ad  vmovaps xmm4, [rsp+0x40]
000074da185dc8b3  vmovaps xmm5, [rsp+0x50]
000074da185dc8b9  vmovaps xmm6, [rsp+0x60]
000074da185dc8bf  vmovaps xmm7, [rsp+0x70]
000074da185dc8c5  vmovaps xmm9, [rsp+0x80]
000074da185dc8ce  vmovaps xmm10, [rsp+0x90]
000074da185dc8d7  vmovaps xmm11, [rsp+0xA0]
000074da185dc8e0  vmovaps xmm12, [rsp+0xB0]
000074da185dc8e9  vmovaps xmm13, [rsp+0xC0]
000074da185dc8f2  vmovaps xmm14, [rsp+0xD0]
000074da185dc8fb  vmovaps xmm15, [rsp+0xE0]
000074da185dc904  add rsp, 0xF0
000074da185dc90b  pop r11
000074da185dc90d  pop r10
000074da185dc90f  pop r9
000074da185dc911  pop r8
000074da185dc913  pop rsi
000074da185dc914  pop rdi
000074da185dc915  pop rdx
000074da185dc916  pop rcx
000074da185dc917  pop rax
000074da185dc918  add rsp, 0x08
000074da185dc91c  jmp 0x000074DA185DA4D0
000074da185dc921  sub rsp, 0x08
000074da185dc925  push rax
000074da185dc926  push rcx
000074da185dc927  push rdx
000074da185dc928  push rdi
000074da185dc929  push rsi
000074da185dc92a  push r8
000074da185dc92c  push r9
000074da185dc92e  push r10
000074da185dc930  push r11
000074da185dc932  sub rsp, 0xF0
000074da185dc939  vmovaps [rsp], xmm0
000074da185dc93e  vmovaps [rsp+0x10], xmm1
000074da185dc944  vmovaps [rsp+0x20], xmm2
000074da185dc94a  vmovaps [rsp+0x30], xmm3
000074da185dc950  vmovaps [rsp+0x40], xmm4
000074da185dc956  vmovaps [rsp+0x50], xmm5
000074da185dc95c  vmovaps [rsp+0x60], xmm6
000074da185dc962  vmovaps [rsp+0x70], xmm8
000074da185dc968  vmovaps [rsp+0x80], xmm9
000074da185dc971  vmovaps [rsp+0x90], xmm10
000074da185dc97a  vmovaps [rsp+0xA0], xmm11
000074da185dc983  vmovaps [rsp+0xB0], xmm12
000074da185dc98c  vmovaps [rsp+0xC0], xmm13
000074da185dc995  vmovaps [rsp+0xD0], xmm14
000074da185dc99e  vmovaps [rsp+0xE0], xmm15
000074da185dc9a7  sub rsp, 0x40
000074da185dc9ab  lea rdi, [rsp]
000074da185dc9af  lea rsi, [rsp+0x10]
000074da185dc9b4  lea rdx, [rsp+0x20]
000074da185dc9b9  lea rcx, [rsp+0x30]
000074da185dc9be  mov r8d, 0x00
000074da185dc9c4  lea r9, [r15+0x3A8]
000074da185dc9cb  movaps [rdi], xmm7
000074da185dc9ce  movaps [rsi], xmm9
000074da185dc9d2  movaps [rdx], xmm14
000074da185dc9d6  movaps [rcx], xmm12
000074da185dc9da  mov rax, 0x5946061DFA50
000074da185dc9e4  call rax
000074da185dc9e6  movaps xmm7, [rsp]
000074da185dc9ea  add rsp, 0x40
000074da185dc9ee  vmovaps xmm0, [rsp]
000074da185dc9f3  vmovaps xmm1, [rsp+0x10]
000074da185dc9f9  vmovaps xmm2, [rsp+0x20]
000074da185dc9ff  vmovaps xmm3, [rsp+0x30]
000074da185dca05  vmovaps xmm4, [rsp+0x40]
000074da185dca0b  vmovaps xmm5, [rsp+0x50]
000074da185dca11  vmovaps xmm6, [rsp+0x60]
000074da185dca17  vmovaps xmm8, [rsp+0x70]
000074da185dca1d  vmovaps xmm9, [rsp+0x80]
000074da185dca26  vmovaps xmm10, [rsp+0x90]
000074da185dca2f  vmovaps xmm11, [rsp+0xA0]
000074da185dca38  vmovaps xmm12, [rsp+0xB0]
000074da185dca41  vmovaps xmm13, [rsp+0xC0]
000074da185dca4a  vmovaps xmm14, [rsp+0xD0]
000074da185dca53  vmovaps xmm15, [rsp+0xE0]
000074da185dca5c  add rsp, 0xF0
000074da185dca63  pop r11
000074da185dca65  pop r10
000074da185dca67  pop r9
000074da185dca69  pop r8
000074da185dca6b  pop rsi
000074da185dca6c  pop rdi
000074da185dca6d  pop rdx
000074da185dca6e  pop rcx
000074da185dca6f  pop rax
000074da185dca70  add rsp, 0x08
000074da185dca74  jmp 0x000074DA185DA4F8
000074da185dca79  sub rsp, 0x08
000074da185dca7d  push rax
000074da185dca7e  push rcx
000074da185dca7f  push rdx
000074da185dca80  push rdi
000074da185dca81  push rsi
000074da185dca82  push r8
000074da185dca84  push r9
000074da185dca86  push r10
000074da185dca88  push r11
000074da185dca8a  sub rsp, 0xF0
000074da185dca91  vmovaps [rsp], xmm0
000074da185dca96  vmovaps [rsp+0x10], xmm1
000074da185dca9c  vmovaps [rsp+0x20], xmm2
000074da185dcaa2  vmovaps [rsp+0x30], xmm3
000074da185dcaa8  vmovaps [rsp+0x40], xmm4
000074da185dcaae  vmovaps [rsp+0x50], xmm5
000074da185dcab4  vmovaps [rsp+0x60], xmm6
000074da185dcaba  vmovaps [rsp+0x70], xmm7
000074da185dcac0  vmovaps [rsp+0x80], xmm8
000074da185dcac9  vmovaps [rsp+0x90], xmm9
000074da185dcad2  vmovaps [rsp+0xA0], xmm10
000074da185dcadb  vmovaps [rsp+0xB0], xmm11
000074da185dcae4  vmovaps [rsp+0xC0], xmm13
000074da185dcaed  vmovaps [rsp+0xD0], xmm14
000074da185dcaf6  vmovaps [rsp+0xE0], xmm15
000074da185dcaff  sub rsp, 0x40
000074da185dcb03  lea rdi, [rsp]
000074da185dcb07  lea rsi, [rsp+0x10]
000074da185dcb0c  lea rdx, [rsp+0x20]
000074da185dcb11  lea rcx, [rsp+0x30]
000074da185dcb16  mov r8d, 0x00
000074da185dcb1c  lea r9, [r15+0x3A8]
000074da185dcb23  movaps [rdi], xmm12
000074da185dcb27  movaps [rsi], xmm11
000074da185dcb2b  movaps [rdx], xmm15
000074da185dcb2f  movaps [rcx], xmm14
000074da185dcb33  mov rax, 0x5946061DFA50
000074da185dcb3d  call rax
000074da185dcb3f  movaps xmm12, [rsp]
000074da185dcb44  add rsp, 0x40
000074da185dcb48  vmovaps xmm0, [rsp]
000074da185dcb4d  vmovaps xmm1, [rsp+0x10]
000074da185dcb53  vmovaps xmm2, [rsp+0x20]
000074da185dcb59  vmovaps xmm3, [rsp+0x30]
000074da185dcb5f  vmovaps xmm4, [rsp+0x40]
000074da185dcb65  vmovaps xmm5, [rsp+0x50]
000074da185dcb6b  vmovaps xmm6, [rsp+0x60]
000074da185dcb71  vmovaps xmm7, [rsp+0x70]
000074da185dcb77  vmovaps xmm8, [rsp+0x80]
000074da185dcb80  vmovaps xmm9, [rsp+0x90]
000074da185dcb89  vmovaps xmm10, [rsp+0xA0]
000074da185dcb92  vmovaps xmm11, [rsp+0xB0]
000074da185dcb9b  vmovaps xmm13, [rsp+0xC0]
000074da185dcba4  vmovaps xmm14, [rsp+0xD0]
000074da185dcbad  vmovaps xmm15, [rsp+0xE0]
000074da185dcbb6  add rsp, 0xF0
000074da185dcbbd  pop r11
000074da185dcbbf  pop r10
000074da185dcbc1  pop r9
000074da185dcbc3  pop r8
000074da185dcbc5  pop rsi
000074da185dcbc6  pop rdi
000074da185dcbc7  pop rdx
000074da185dcbc8  pop rcx
000074da185dcbc9  pop rax
000074da185dcbca  add rsp, 0x08
000074da185dcbce  jmp 0x000074DA185DA521
000074da185dcbd3  sub rsp, 0x08
000074da185dcbd7  push rax
000074da185dcbd8  push rcx
000074da185dcbd9  push rdx
000074da185dcbda  push rdi
000074da185dcbdb  push rsi
000074da185dcbdc  push r8
000074da185dcbde  push r9
000074da185dcbe0  push r10
000074da185dcbe2  push r11
000074da185dcbe4  sub rsp, 0xF0
000074da185dcbeb  vmovaps [rsp], xmm0
000074da185dcbf0  vmovaps [rsp+0x10], xmm1
000074da185dcbf6  vmovaps [rsp+0x20], xmm2
000074da185dcbfc  vmovaps [rsp+0x30], xmm3
000074da185dcc02  vmovaps [rsp+0x40], xmm4
000074da185dcc08  vmovaps [rsp+0x50], xmm5
000074da185dcc0e  vmovaps [rsp+0x60], xmm6
000074da185dcc14  vmovaps [rsp+0x70], xmm7
000074da185dcc1a  vmovaps [rsp+0x80], xmm8
000074da185dcc23  vmovaps [rsp+0x90], xmm9
000074da185dcc2c  vmovaps [rsp+0xA0], xmm10
000074da185dcc35  vmovaps [rsp+0xB0], xmm12
000074da185dcc3e  vmovaps [rsp+0xC0], xmm13
000074da185dcc47  vmovaps [rsp+0xD0], xmm14
000074da185dcc50  vmovaps [rsp+0xE0], xmm15
000074da185dcc59  sub rsp, 0x40
000074da185dcc5d  lea rdi, [rsp]
000074da185dcc61  lea rsi, [rsp+0x10]
000074da185dcc66  lea rdx, [rsp+0x20]
000074da185dcc6b  lea rcx, [rsp+0x30]
000074da185dcc70  mov r8d, 0x00
000074da185dcc76  lea r9, [r15+0x3A8]
000074da185dcc7d  movaps [rdi], xmm11
000074da185dcc81  movaps [rsi], xmm10
000074da185dcc85  movaps [rdx], xmm13
000074da185dcc89  movaps [rcx], xmm15
000074da185dcc8d  mov rax, 0x5946061DFA50
000074da185dcc97  call rax
000074da185dcc99  movaps xmm11, [rsp]
000074da185dcc9e  add rsp, 0x40
000074da185dcca2  vmovaps xmm0, [rsp]
000074da185dcca7  vmovaps xmm1, [rsp+0x10]
000074da185dccad  vmovaps xmm2, [rsp+0x20]
000074da185dccb3  vmovaps xmm3, [rsp+0x30]
000074da185dccb9  vmovaps xmm4, [rsp+0x40]
000074da185dccbf  vmovaps xmm5, [rsp+0x50]
000074da185dccc5  vmovaps xmm6, [rsp+0x60]
000074da185dcccb  vmovaps xmm7, [rsp+0x70]
000074da185dccd1  vmovaps xmm8, [rsp+0x80]
000074da185dccda  vmovaps xmm9, [rsp+0x90]
000074da185dcce3  vmovaps xmm10, [rsp+0xA0]
000074da185dccec  vmovaps xmm12, [rsp+0xB0]
000074da185dccf5  vmovaps xmm13, [rsp+0xC0]
000074da185dccfe  vmovaps xmm14, [rsp+0xD0]
000074da185dcd07  vmovaps xmm15, [rsp+0xE0]
000074da185dcd10  add rsp, 0xF0
000074da185dcd17  pop r11
000074da185dcd19  pop r10
000074da185dcd1b  pop r9
000074da185dcd1d  pop r8
000074da185dcd1f  pop rsi
000074da185dcd20  pop rdi
000074da185dcd21  pop rdx
000074da185dcd22  pop rcx
000074da185dcd23  pop rax
000074da185dcd24  add rsp, 0x08
000074da185dcd28  jmp 0x000074DA185DA54A
000074da185dcd2d  call 0x000074DA1840E760
000074da185dcd32  jmp 0x000074DA185DA557
000074da185dcd37  call 0x000074DA1840D4E0
000074da185dcd3c  jmp 0x000074DA185DA564
000074da185dcd41  sub rsp, 0x08
000074da185dcd45  push rax
000074da185dcd46  push rcx
000074da185dcd47  push rdx
000074da185dcd48  push rdi
000074da185dcd49  push rsi
000074da185dcd4a  push r8
000074da185dcd4c  push r9
000074da185dcd4e  push r10
000074da185dcd50  push r11
000074da185dcd52  sub rsp, 0xF0
000074da185dcd59  vmovaps [rsp], xmm0
000074da185dcd5e  vmovaps [rsp+0x10], xmm1
000074da185dcd64  vmovaps [rsp+0x20], xmm2
000074da185dcd6a  vmovaps [rsp+0x30], xmm3
000074da185dcd70  vmovaps [rsp+0x40], xmm4
000074da185dcd76  vmovaps [rsp+0x50], xmm5
000074da185dcd7c  vmovaps [rsp+0x60], xmm6
000074da185dcd82  vmovaps [rsp+0x70], xmm7
000074da185dcd88  vmovaps [rsp+0x80], xmm8
000074da185dcd91  vmovaps [rsp+0x90], xmm9
000074da185dcd9a  vmovaps [rsp+0xA0], xmm11
000074da185dcda3  vmovaps [rsp+0xB0], xmm12
000074da185dcdac  vmovaps [rsp+0xC0], xmm13
000074da185dcdb5  vmovaps [rsp+0xD0], xmm14
000074da185dcdbe  vmovaps [rsp+0xE0], xmm15
000074da185dcdc7  sub rsp, 0x40
000074da185dcdcb  lea rdi, [rsp]
000074da185dcdcf  lea rsi, [rsp+0x10]
000074da185dcdd4  lea rdx, [rsp+0x20]
000074da185dcdd9  lea rcx, [rsp+0x30]
000074da185dcdde  mov r8d, 0x00
000074da185dcde4  lea r9, [r15+0x3A8]
000074da185dcdeb  movaps [rdi], xmm10
000074da185dcdef  movaps [rsi], xmm8
000074da185dcdf3  movaps [rdx], xmm1
000074da185dcdf6  movaps [rcx], xmm13
000074da185dcdfa  mov rax, 0x5946061DFA50
000074da185dce04  call rax
000074da185dce06  movaps xmm10, [rsp]
000074da185dce0b  add rsp, 0x40
000074da185dce0f  vmovaps xmm0, [rsp]
000074da185dce14  vmovaps xmm1, [rsp+0x10]
000074da185dce1a  vmovaps xmm2, [rsp+0x20]
000074da185dce20  vmovaps xmm3, [rsp+0x30]
000074da185dce26  vmovaps xmm4, [rsp+0x40]
000074da185dce2c  vmovaps xmm5, [rsp+0x50]
000074da185dce32  vmovaps xmm6, [rsp+0x60]
000074da185dce38  vmovaps xmm7, [rsp+0x70]
000074da185dce3e  vmovaps xmm8, [rsp+0x80]
000074da185dce47  vmovaps xmm9, [rsp+0x90]
000074da185dce50  vmovaps xmm11, [rsp+0xA0]
000074da185dce59  vmovaps xmm12, [rsp+0xB0]
000074da185dce62  vmovaps xmm13, [rsp+0xC0]
000074da185dce6b  vmovaps xmm14, [rsp+0xD0]
000074da185dce74  vmovaps xmm15, [rsp+0xE0]
000074da185dce7d  add rsp, 0xF0
000074da185dce84  pop r11
000074da185dce86  pop r10
000074da185dce88  pop r9
000074da185dce8a  pop r8
000074da185dce8c  pop rsi
000074da185dce8d  pop rdi
000074da185dce8e  pop rdx
000074da185dce8f  pop rcx
000074da185dce90  pop rax
000074da185dce91  add rsp, 0x08
000074da185dce95  jmp 0x000074DA185DA59A
000074da185dce9a  call 0x000074DA183FF430
000074da185dce9f  jmp 0x000074DA185DA5AC
000074da185dcea4  sub rsp, 0x08
000074da185dcea8  push rax
000074da185dcea9  push rcx
000074da185dceaa  push rdx
000074da185dceab  push rdi
000074da185dceac  push rsi
000074da185dcead  push r8
000074da185dceaf  push r9
000074da185dceb1  push r10
000074da185dceb3  push r11
000074da185dceb5  sub rsp, 0xF0
000074da185dcebc  vmovaps [rsp], xmm0
000074da185dcec1  vmovaps [rsp+0x10], xmm1
000074da185dcec7  vmovaps [rsp+0x20], xmm2
000074da185dcecd  vmovaps [rsp+0x30], xmm3
000074da185dced3  vmovaps [rsp+0x40], xmm4
000074da185dced9  vmovaps [rsp+0x50], xmm5
000074da185dcedf  vmovaps [rsp+0x60], xmm6
000074da185dcee5  vmovaps [rsp+0x70], xmm7
000074da185dceeb  vmovaps [rsp+0x80], xmm8
000074da185dcef4  vmovaps [rsp+0x90], xmm10
000074da185dcefd  vmovaps [rsp+0xA0], xmm11
000074da185dcf06  vmovaps [rsp+0xB0], xmm12
000074da185dcf0f  vmovaps [rsp+0xC0], xmm13
000074da185dcf18  vmovaps [rsp+0xD0], xmm14
000074da185dcf21  vmovaps [rsp+0xE0], xmm15
000074da185dcf2a  sub rsp, 0x40
000074da185dcf2e  lea rdi, [rsp]
000074da185dcf32  lea rsi, [rsp+0x10]
000074da185dcf37  lea rdx, [rsp+0x20]
000074da185dcf3c  lea rcx, [rsp+0x30]
000074da185dcf41  mov r8d, 0x00
000074da185dcf47  lea r9, [r15+0x3A8]
000074da185dcf4e  movaps [rdi], xmm9
000074da185dcf52  movaps [rsi], xmm7
000074da185dcf55  movaps [rdx], xmm14
000074da185dcf59  movaps [rcx], xmm13
000074da185dcf5d  mov rax, 0x5946061DFA50
000074da185dcf67  call rax
000074da185dcf69  movaps xmm9, [rsp]
000074da185dcf6e  add rsp, 0x40
000074da185dcf72  vmovaps xmm0, [rsp]
000074da185dcf77  vmovaps xmm1, [rsp+0x10]
000074da185dcf7d  vmovaps xmm2, [rsp+0x20]
000074da185dcf83  vmovaps xmm3, [rsp+0x30]
000074da185dcf89  vmovaps xmm4, [rsp+0x40]
000074da185dcf8f  vmovaps xmm5, [rsp+0x50]
000074da185dcf95  vmovaps xmm6, [rsp+0x60]
000074da185dcf9b  vmovaps xmm7, [rsp+0x70]
000074da185dcfa1  vmovaps xmm8, [rsp+0x80]
000074da185dcfaa  vmovaps xmm10, [rsp+0x90]
000074da185dcfb3  vmovaps xmm11, [rsp+0xA0]
000074da185dcfbc  vmovaps xmm12, [rsp+0xB0]
000074da185dcfc5  vmovaps xmm13, [rsp+0xC0]
000074da185dcfce  vmovaps xmm14, [rsp+0xD0]
000074da185dcfd7  vmovaps xmm15, [rsp+0xE0]
000074da185dcfe0  add rsp, 0xF0
000074da185dcfe7  pop r11
000074da185dcfe9  pop r10
000074da185dcfeb  pop r9
000074da185dcfed  pop r8
000074da185dcfef  pop rsi
000074da185dcff0  pop rdi
000074da185dcff1  pop rdx
000074da185dcff2  pop rcx
000074da185dcff3  pop rax
000074da185dcff4  add rsp, 0x08
000074da185dcff8  jmp 0x000074DA185DA5DA
000074da185dcffd  sub rsp, 0x08
000074da185dd001  push rax
000074da185dd002  push rcx
000074da185dd003  push rdx
000074da185dd004  push rdi
000074da185dd005  push rsi
000074da185dd006  push r8
000074da185dd008  push r9
000074da185dd00a  push r10
000074da185dd00c  push r11
000074da185dd00e  sub rsp, 0xF0
000074da185dd015  vmovaps [rsp], xmm0
000074da185dd01a  vmovaps [rsp+0x10], xmm1
000074da185dd020  vmovaps [rsp+0x20], xmm2
000074da185dd026  vmovaps [rsp+0x30], xmm3
000074da185dd02c  vmovaps [rsp+0x40], xmm4
000074da185dd032  vmovaps [rsp+0x50], xmm5
000074da185dd038  vmovaps [rsp+0x60], xmm6
000074da185dd03e  vmovaps [rsp+0x70], xmm7
000074da185dd044  vmovaps [rsp+0x80], xmm8
000074da185dd04d  vmovaps [rsp+0x90], xmm9
000074da185dd056  vmovaps [rsp+0xA0], xmm10
000074da185dd05f  vmovaps [rsp+0xB0], xmm11
000074da185dd068  vmovaps [rsp+0xC0], xmm12
000074da185dd071  vmovaps [rsp+0xD0], xmm14
000074da185dd07a  vmovaps [rsp+0xE0], xmm15
000074da185dd083  sub rsp, 0x40
000074da185dd087  lea rdi, [rsp]
000074da185dd08b  lea rsi, [rsp+0x10]
000074da185dd090  lea rdx, [rsp+0x20]
000074da185dd095  lea rcx, [rsp+0x30]
000074da185dd09a  mov r8d, 0x00
000074da185dd0a0  lea r9, [r15+0x3A8]
000074da185dd0a7  movaps [rdi], xmm13
000074da185dd0ab  movaps [rsi], xmm12
000074da185dd0af  movaps [rdx], xmm15
000074da185dd0b3  movaps [rcx], xmm14
000074da185dd0b7  mov rax, 0x5946061DFA50
000074da185dd0c1  call rax
000074da185dd0c3  movaps xmm13, [rsp]
000074da185dd0c8  add rsp, 0x40
000074da185dd0cc  vmovaps xmm0, [rsp]
000074da185dd0d1  vmovaps xmm1, [rsp+0x10]
000074da185dd0d7  vmovaps xmm2, [rsp+0x20]
000074da185dd0dd  vmovaps xmm3, [rsp+0x30]
000074da185dd0e3  vmovaps xmm4, [rsp+0x40]
000074da185dd0e9  vmovaps xmm5, [rsp+0x50]
000074da185dd0ef  vmovaps xmm6, [rsp+0x60]
000074da185dd0f5  vmovaps xmm7, [rsp+0x70]
000074da185dd0fb  vmovaps xmm8, [rsp+0x80]
000074da185dd104  vmovaps xmm9, [rsp+0x90]
000074da185dd10d  vmovaps xmm10, [rsp+0xA0]
000074da185dd116  vmovaps xmm11, [rsp+0xB0]
000074da185dd11f  vmovaps xmm12, [rsp+0xC0]
000074da185dd128  vmovaps xmm14, [rsp+0xD0]
000074da185dd131  vmovaps xmm15, [rsp+0xE0]
000074da185dd13a  add rsp, 0xF0
000074da185dd141  pop r11
000074da185dd143  pop r10
000074da185dd145  pop r9
000074da185dd147  pop r8
000074da185dd149  pop rsi
000074da185dd14a  pop rdi
000074da185dd14b  pop rdx
000074da185dd14c  pop rcx
000074da185dd14d  pop rax
000074da185dd14e  add rsp, 0x08
000074da185dd152  jmp 0x000074DA185DA608
000074da185dd157  sub rsp, 0x08
000074da185dd15b  push rax
000074da185dd15c  push rcx
000074da185dd15d  push rdx
000074da185dd15e  push rdi
000074da185dd15f  push rsi
000074da185dd160  push r8
000074da185dd162  push r9
000074da185dd164  push r10
000074da185dd166  push r11
000074da185dd168  sub rsp, 0xF0
000074da185dd16f  vmovaps [rsp], xmm0
000074da185dd174  vmovaps [rsp+0x10], xmm1
000074da185dd17a  vmovaps [rsp+0x20], xmm2
000074da185dd180  vmovaps [rsp+0x30], xmm3
000074da185dd186  vmovaps [rsp+0x40], xmm4
000074da185dd18c  vmovaps [rsp+0x50], xmm5
000074da185dd192  vmovaps [rsp+0x60], xmm6
000074da185dd198  vmovaps [rsp+0x70], xmm7
000074da185dd19e  vmovaps [rsp+0x80], xmm8
000074da185dd1a7  vmovaps [rsp+0x90], xmm9
000074da185dd1b0  vmovaps [rsp+0xA0], xmm10
000074da185dd1b9  vmovaps [rsp+0xB0], xmm11
000074da185dd1c2  vmovaps [rsp+0xC0], xmm12
000074da185dd1cb  vmovaps [rsp+0xD0], xmm13
000074da185dd1d4  vmovaps [rsp+0xE0], xmm15
000074da185dd1dd  sub rsp, 0x40
000074da185dd1e1  lea rdi, [rsp]
000074da185dd1e5  lea rsi, [rsp+0x10]
000074da185dd1ea  lea rdx, [rsp+0x20]
000074da185dd1ef  lea rcx, [rsp+0x30]
000074da185dd1f4  mov r8d, 0x00
000074da185dd1fa  lea r9, [r15+0x3A8]
000074da185dd201  movaps [rdi], xmm14
000074da185dd205  movaps [rsi], xmm11
000074da185dd209  movaps [rdx], xmm1
000074da185dd20c  movaps [rcx], xmm15
000074da185dd210  mov rax, 0x5946061DFA50
000074da185dd21a  call rax
000074da185dd21c  movaps xmm14, [rsp]
000074da185dd221  add rsp, 0x40
000074da185dd225  vmovaps xmm0, [rsp]
000074da185dd22a  vmovaps xmm1, [rsp+0x10]
000074da185dd230  vmovaps xmm2, [rsp+0x20]
000074da185dd236  vmovaps xmm3, [rsp+0x30]
000074da185dd23c  vmovaps xmm4, [rsp+0x40]
000074da185dd242  vmovaps xmm5, [rsp+0x50]
000074da185dd248  vmovaps xmm6, [rsp+0x60]
000074da185dd24e  vmovaps xmm7, [rsp+0x70]
000074da185dd254  vmovaps xmm8, [rsp+0x80]
000074da185dd25d  vmovaps xmm9, [rsp+0x90]
000074da185dd266  vmovaps xmm10, [rsp+0xA0]
000074da185dd26f  vmovaps xmm11, [rsp+0xB0]
000074da185dd278  vmovaps xmm12, [rsp+0xC0]
000074da185dd281  vmovaps xmm13, [rsp+0xD0]
000074da185dd28a  vmovaps xmm15, [rsp+0xE0]
000074da185dd293  add rsp, 0xF0
000074da185dd29a  pop r11
000074da185dd29c  pop r10
000074da185dd29e  pop r9
000074da185dd2a0  pop r8
000074da185dd2a2  pop rsi
000074da185dd2a3  pop rdi
000074da185dd2a4  pop rdx
000074da185dd2a5  pop rcx
000074da185dd2a6  pop rax
000074da185dd2a7  add rsp, 0x08
000074da185dd2ab  jmp 0x000074DA185DA636
000074da185dd2b0  call 0x000074DA184079B0
000074da185dd2b5  jmp 0x000074DA185DA64C
000074da185dd2ba  call 0x000074DA184E3440
000074da185dd2bf  jmp 0x000074DA185DA656
000074da185dd2c4  call 0x000074DA184DFCE0
000074da185dd2c9  jmp 0x000074DA185DA660
000074da185dd2ce  call 0x000074DA184E46C0
000074da185dd2d3  jmp 0x000074DA185DA66A
000074da185dd2d8  int3
000074da185dd2d9  nop [rax], eax
000074da185dd2e0  mov qword ptr [r15+0x40], 0x430000
000074da185dd2e8  mov eax, 0x430C50
000074da185dd2ed  mov r14, [r13+rax*1]
000074da185dd2f2  movq xmm1, r14
000074da185dd2f7  mov rax, [r15+0x50]
000074da185dd2fb  movups xmm15, [r13+rax*1]
000074da185dd301  movaps [r15+0x120], xmm15
000074da185dd309  mov qword ptr [r15+0x48], 0x10
000074da185dd311  xor eax, eax
000074da185dd313  mov r14d, 0x10
000074da185dd319  mov r12d, 0x200
000074da185dd31f  cmp r14, r12
000074da185dd322  cmc
000074da185dd323  lahf
000074da185dd324  seto al
000074da185dd327  mov [r15+0x108], eax
000074da185dd32e  pextrq rax, xmm15, 0x01
000074da185dd335  movq xmm14, rax
000074da185dd33a  movaps [r15+0x130], xmm14
000074da185dd342  movq rax, xmm1
000074da185dd347  movq r14, xmm15
000074da185dd34c  vmovq xmm1, rax
000074da185dd351  vmovq xmm15, r14
000074da185dd356  movaps xmm13, xmm1
000074da185dd35a  addsd xmm13, xmm15
000074da185dd35f  ucomisd xmm13, xmm13
000074da185dd364  jp 0x000074DA185DD423
000074da185dd36a  movq xmm13, xmm13
000074da185dd36f  movq rax, xmm13
000074da185dd374  movq r14, xmm14
000074da185dd379  vmovq xmm1, rax
000074da185dd37e  vmovq xmm15, r14
000074da185dd383  movaps xmm14, xmm1
000074da185dd387  addsd xmm14, xmm15
000074da185dd38c  ucomisd xmm14, xmm14
000074da185dd391  jp 0x000074DA185DD46B
000074da185dd397  movq xmm14, xmm14
000074da185dd39c  movaps [r15+0x110], xmm14
000074da185dd3a4  mov eax, [r15+0x108]
000074da185dd3ab  sahf
000074da185dd3ac  jnz 0x000074DA185DD3DE
000074da185dd3ae  cmp dword ptr [r15+0x318], 0x00
000074da185dd3b6  jz 0x000074DA185DD680
000074da185dd3bc  nop [rax+rax*1], ax
000074da185dd3c5  nop [rax+rax*1], eax
000074da185dd3cd  mov eax, 0x410698
000074da185dd3d2  mov [r15+0x100], rax
000074da185dd3d9  jmp 0x000074DA183FE110
000074da185dd3de  cmp dword ptr [r15+0x318], 0x00
000074da185dd3e6  jz 0x000074DA185DD4C0
000074da185dd3ec  nop [rax+rax*1], ax
000074da185dd3f5  nop [rax+rax*1], eax
000074da185dd3fd  mov eax, 0x41067C
000074da185dd402  mov [r15+0x100], rax
000074da185dd409  jmp 0x000074DA183FE110
000074da185dd40e  int3
000074da185dd40f  call 0x000074DA1840DC20
000074da185dd414  jmp 0x000074DA185DD2F2
000074da185dd419  call 0x000074DA1840E760
000074da185dd41e  jmp 0x000074DA185DD301
000074da185dd423  ucomisd xmm1, xmm15
000074da185dd428  jp 0x000074DA185DD437
000074da185dd42a  movaps xmm13, [0x000074DA181FE060]
000074da185dd432  jmp 0x000074DA185DD36A
000074da185dd437  vxorps xmm0, xmm1, xmm15
000074da185dd43c  pextrw eax, xmm0, 0x03
000074da185dd441  and eax, 0x7FF8
000074da185dd446  cmp eax, 0x08
000074da185dd449  jnz 0x000074DA185DD36A
000074da185dd44f  movq rax, xmm15
000074da185dd454  shl rax, 0x0D
000074da185dd458  jbe 0x000074DA185DD36A
000074da185dd45e  vorps xmm13, xmm15, [0x000074DA181FE070]
000074da185dd466  jmp 0x000074DA185DD36A
000074da185dd46b  ucomisd xmm1, xmm15
000074da185dd470  jp 0x000074DA185DD47F
000074da185dd472  movaps xmm14, [0x000074DA181FE060]
000074da185dd47a  jmp 0x000074DA185DD397
000074da185dd47f  vxorps xmm0, xmm1, xmm15
000074da185dd484  pextrw eax, xmm0, 0x03
000074da185dd489  and eax, 0x7FF8
000074da185dd48e  cmp eax, 0x08
000074da185dd491  jnz 0x000074DA185DD397
000074da185dd497  movq rax, xmm15
000074da185dd49c  shl rax, 0x0D
000074da185dd4a0  jbe 0x000074DA185DD397
000074da185dd4a6  vorps xmm14, xmm15, [0x000074DA181FE070]
000074da185dd4ae  jmp 0x000074DA185DD397
000074da185dd4b3  int3
000074da185dd4b4  nop [rax+rax*1], ax
000074da185dd4bd  nop [rax], eax
000074da185dd4c0  mov rax, [r15+0x48]
000074da185dd4c4  mov r14, [r15+0x50]
000074da185dd4c8  lea r12, [r14+rax*1]
000074da185dd4cc  movups xmm1, [r13+r12*1]
000074da185dd4d2  movaps [r15+0x120], xmm1
000074da185dd4da  lea r14, [rax+0x10]
000074da185dd4de  mov [r15+0x48], r14
000074da185dd4e2  xor eax, eax
000074da185dd4e4  mov r12d, 0x200
000074da185dd4ea  cmp r14, r12
000074da185dd4ed  cmc
000074da185dd4ee  lahf
000074da185dd4ef  seto al
000074da185dd4f2  mov [r15+0x108], eax
000074da185dd4f9  pextrq rax, xmm1, 0x01
000074da185dd500  movq xmm15, rax
000074da185dd505  movaps [r15+0x130], xmm15
000074da185dd50d  movaps xmm14, [r15+0x110]
000074da185dd515  movq rax, xmm14
000074da185dd51a  movq r14, xmm1
000074da185dd51f  vmovq xmm1, rax
000074da185dd524  vmovq xmm14, r14
000074da185dd529  movaps xmm13, xmm1
000074da185dd52d  addsd xmm13, xmm14
000074da185dd532  ucomisd xmm13, xmm13
000074da185dd537  jp 0x000074DA185DD5EC
000074da185dd53d  movq xmm13, xmm13
000074da185dd542  movq rax, xmm13
000074da185dd547  movq r14, xmm15
000074da185dd54c  vmovq xmm1, rax
000074da185dd551  vmovq xmm15, r14
000074da185dd556  movaps xmm14, xmm1
000074da185dd55a  addsd xmm14, xmm15
000074da185dd55f  ucomisd xmm14, xmm14
000074da185dd564  jp 0x000074DA185DD634
000074da185dd56a  movq xmm14, xmm14
000074da185dd56f  movaps [r15+0x110], xmm14
000074da185dd577  mov eax, [r15+0x108]
000074da185dd57e  sahf
000074da185dd57f  jnz 0x000074DA185DD5B1
000074da185dd581  cmp dword ptr [r15+0x318], 0x00
000074da185dd589  jz 0x000074DA185DD680
000074da185dd58f  nop [rax+rax*1], ax
000074da185dd598  nop [rax+rax*1], eax
000074da185dd5a0  mov eax, 0x410698
000074da185dd5a5  mov [r15+0x100], rax
000074da185dd5ac  jmp 0x000074DA183FE110
000074da185dd5b1  cmp dword ptr [r15+0x318], 0x00
000074da185dd5b9  jz 0x000074DA185DD4C0
000074da185dd5bf  nop [rax+rax*1], ax
000074da185dd5c8  nop [rax+rax*1], eax
000074da185dd5d0  mov eax, 0x41067C
000074da185dd5d5  mov [r15+0x100], rax
000074da185dd5dc  jmp 0x000074DA183FE110
000074da185dd5e1  int3
000074da185dd5e2  call 0x000074DA184B52F0
000074da185dd5e7  jmp 0x000074DA185DD4D2
000074da185dd5ec  ucomisd xmm1, xmm14
000074da185dd5f1  jp 0x000074DA185DD600
000074da185dd5f3  movaps xmm13, [0x000074DA181FE060]
000074da185dd5fb  jmp 0x000074DA185DD53D
000074da185dd600  vxorps xmm0, xmm1, xmm14
000074da185dd605  pextrw eax, xmm0, 0x03
000074da185dd60a  and eax, 0x7FF8
000074da185dd60f  cmp eax, 0x08
000074da185dd612  jnz 0x000074DA185DD53D
000074da185dd618  movq rax, xmm14
000074da185dd61d  shl rax, 0x0D
000074da185dd621  jbe 0x000074DA185DD53D
000074da185dd627  vorps xmm13, xmm14, [0x000074DA181FE070]
000074da185dd62f  jmp 0x000074DA185DD53D
000074da185dd634  ucomisd xmm1, xmm15
000074da185dd639  jp 0x000074DA185DD648
000074da185dd63b  movaps xmm14, [0x000074DA181FE060]
000074da185dd643  jmp 0x000074DA185DD56A
000074da185dd648  vxorps xmm0, xmm1, xmm15
000074da185dd64d  pextrw eax, xmm0, 0x03
000074da185dd652  and eax, 0x7FF8
000074da185dd657  cmp eax, 0x08
000074da185dd65a  jnz 0x000074DA185DD56A
000074da185dd660  movq rax, xmm15
000074da185dd665  shl rax, 0x0D
000074da185dd669  jbe 0x000074DA185DD56A
000074da185dd66f  vorps xmm14, xmm15, [0x000074DA181FE070]
000074da185dd677  jmp 0x000074DA185DD56A
000074da185dd67c  int3
000074da185dd67d  nop [rax], eax
000074da185dd680  mov rax, [r15+0xF8]
000074da185dd687  lea r14, [rax+0x1A0]
000074da185dd68e  mov r12, [r13+r14*1]
000074da185dd693  lea r14, [rax+0x1A8]
000074da185dd69a  mov r11, [r13+r14*1]
000074da185dd69f  mov [r15+0xA0], r12
000074da185dd6a6  mov [r15+0x98], r11
000074da185dd6ad  mov r14, [r15+0x40]
000074da185dd6b1  lea r12, [r14+0xC50]
000074da185dd6b8  movaps xmm1, [r15+0x110]
000074da185dd6c0  movq r14, xmm1
000074da185dd6c5  mov [r13+r12*1], r14
000074da185dd6ca  lea r14, [rax+0x190]
000074da185dd6d1  mov r12, [r13+r14*1]
000074da185dd6d6  lea r14, [rax+0x198]
000074da185dd6dd  mov r11, [r13+r14*1]
000074da185dd6e2  mov [r15+0xE8], r12
000074da185dd6e9  mov [r15+0xF0], r11
000074da185dd6f0  lea r14, [rax+0x180]
000074da185dd6f7  mov r12, [r13+r14*1]
000074da185dd6fc  lea r14, [rax+0x188]
000074da185dd703  mov r10, [r13+r14*1]
000074da185dd708  movq xmm1, r12
000074da185dd70d  movq xmm15, r10
000074da185dd712  movq xmm1, xmm1
000074da185dd716  movq xmm1, xmm1
000074da185dd71a  movaps [r15+0x1A0], xmm1
000074da185dd722  movq xmm15, xmm15
000074da185dd727  movq xmm15, xmm15
000074da185dd72c  movaps [r15+0x190], xmm15
000074da185dd734  lea r14, [rax+0x170]
000074da185dd73b  mov r12, [r13+r14*1]
000074da185dd740  lea r14, [rax+0x178]
000074da185dd747  mov r10, [r13+r14*1]
000074da185dd74c  movq xmm1, r12
000074da185dd751  movq xmm15, r10
000074da185dd756  movq xmm1, xmm1
000074da185dd75a  movq xmm1, xmm1
000074da185dd75e  movaps [r15+0x1C0], xmm1
000074da185dd766  movq xmm15, xmm15
000074da185dd76b  movq xmm15, xmm15
000074da185dd770  movaps [r15+0x1B0], xmm15
000074da185dd778  lea r14, [rax+0x160]
000074da185dd77f  mov r12, [r13+r14*1]
000074da185dd784  lea r14, [rax+0x168]
000074da185dd78b  mov r10, [r13+r14*1]
000074da185dd790  movq xmm1, r12
000074da185dd795  movq xmm15, r10
000074da185dd79a  movq xmm1, xmm1
000074da185dd79e  movq xmm1, xmm1
000074da185dd7a2  movaps [r15+0x1E0], xmm1
000074da185dd7aa  movq xmm15, xmm15
000074da185dd7af  movq xmm15, xmm15
000074da185dd7b4  movaps [r15+0x1D0], xmm15
000074da185dd7bc  lea r14, [rax+0x150]
000074da185dd7c3  mov r12, [r13+r14*1]
000074da185dd7c8  lea r14, [rax+0x158]
000074da185dd7cf  mov r10, [r13+r14*1]
000074da185dd7d4  movq xmm1, r12
000074da185dd7d9  movq xmm15, r10
000074da185dd7de  movq xmm1, xmm1
000074da185dd7e2  movq xmm1, xmm1
000074da185dd7e6  movaps [r15+0x200], xmm1
000074da185dd7ee  movq xmm15, xmm15
000074da185dd7f3  movq xmm15, xmm15
000074da185dd7f8  movaps [r15+0x1F0], xmm15
000074da185dd800  lea r14, [rax+0x1B0]
000074da185dd807  mov [r15+0xF8], r14
000074da185dd80e  mov [r15+0x100], r11
000074da185dd815  jmp 0x000074DA185CE5C0
000074da185dd81a  int3
000074da185dd81b  call 0x000074DA184E27E0
000074da185dd820  jmp 0x000074DA185DD693
000074da185dd825  call 0x000074DA184E1570
000074da185dd82a  jmp 0x000074DA185DD69F
000074da185dd82f  call 0x000074DA184C3FE0
000074da185dd834  jmp 0x000074DA185DD6CA
000074da185dd839  call 0x000074DA184E27E0
000074da185dd83e  jmp 0x000074DA185DD6D6
000074da185dd843  call 0x000074DA184E1570
000074da185dd848  jmp 0x000074DA185DD6E2
000074da185dd84d  call 0x000074DA184E27E0
000074da185dd852  jmp 0x000074DA185DD6FC
000074da185dd857  call 0x000074DA184E0300
000074da185dd85c  jmp 0x000074DA185DD708
000074da185dd861  call 0x000074DA184E27E0
000074da185dd866  jmp 0x000074DA185DD740
000074da185dd86b  call 0x000074DA184E0300
000074da185dd870  jmp 0x000074DA185DD74C
000074da185dd875  call 0x000074DA184E27E0
000074da185dd87a  jmp 0x000074DA185DD784
000074da185dd87f  call 0x000074DA184E0300
000074da185dd884  jmp 0x000074DA185DD790
000074da185dd889  call 0x000074DA184E27E0
000074da185dd88e  jmp 0x000074DA185DD7C8
000074da185dd893  call 0x000074DA184E0300
000074da185dd898  jmp 0x000074DA185DD7D4
000074da185dd89d  int3
000074da185dd89e  nop
000074da185dd8a0  mov qword ptr [r15+0x100], 0x04
000074da185dd8ab  mov esi, 0x00
000074da185dd8b0  mov edx, 0x09
000074da185dd8b5  mov rdi, 0x7FFDC01A9F00
000074da185dd8bf  mov rax, 0x594606072970
000074da185dd8c9  call rax
000074da185dd8cb  cmp dword ptr [r15+0x318], 0x00
000074da185dd8d3  jnz 0x000074DA183FE110
000074da185dd8d9  jmp 0x000074DA183FE0A0
000074da185dd8de  int3
000074da185dd8df  int3
