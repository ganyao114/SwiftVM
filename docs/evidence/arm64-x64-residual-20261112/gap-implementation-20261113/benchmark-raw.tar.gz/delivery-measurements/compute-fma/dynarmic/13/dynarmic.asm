0000773e7dfce69b  nop [rax+rax*1], eax
0000773e7dfce6a0  mov rax, [r15+0xF8]
0000773e7dfce6a7  lea r14, [rax-0x1B0]
0000773e7dfce6ae  mov [r15+0xF8], r14
0000773e7dfce6b5  lea rax, [r14+0x1A0]
0000773e7dfce6bc  mov r12, [r15+0xA0]
0000773e7dfce6c3  mov r11, [r15+0x98]
0000773e7dfce6ca  mov [r13+rax*1], r12
0000773e7dfce6cf  lea rax, [r14+0x1A8]
0000773e7dfce6d6  mov [r13+rax*1], r11
0000773e7dfce6db  mov eax, 0x420A30
0000773e7dfce6e0  movups xmm1, [r13+rax*1]
0000773e7dfce6e6  mov eax, 0x4209C0
0000773e7dfce6eb  movups xmm15, [r13+rax*1]
0000773e7dfce6f1  mov eax, 0x420A50
0000773e7dfce6f6  movups xmm14, [r13+rax*1]
0000773e7dfce6fc  mov eax, 0x4209F0
0000773e7dfce701  movups xmm13, [r13+rax*1]
0000773e7dfce707  mov qword ptr [r15+0x98], 0x430C60
0000773e7dfce712  mov eax, 0x420A60
0000773e7dfce717  movups xmm12, [r13+rax*1]
0000773e7dfce71d  mov eax, 0x430C60
0000773e7dfce722  movups [r13+rax*1], xmm1
0000773e7dfce728  mov eax, 0x430C70
0000773e7dfce72d  movups [r13+rax*1], xmm15
0000773e7dfce733  mov eax, 0x430C80
0000773e7dfce738  movups [r13+rax*1], xmm14
0000773e7dfce73e  mov eax, 0x430C90
0000773e7dfce743  movups [r13+rax*1], xmm13
0000773e7dfce749  mov eax, 0x4209B0
0000773e7dfce74e  movups xmm14, [r13+rax*1]
0000773e7dfce754  mov eax, 0x4209A0
0000773e7dfce759  movups xmm13, [r13+rax*1]
0000773e7dfce75f  mov eax, 0x430D60
0000773e7dfce764  movups [r13+rax*1], xmm1
0000773e7dfce76a  mov eax, 0x430D70
0000773e7dfce76f  movups [r13+rax*1], xmm15
0000773e7dfce775  mov eax, 0x430CA0
0000773e7dfce77a  movups [r13+rax*1], xmm12
0000773e7dfce780  mov eax, 0x430CB0
0000773e7dfce785  movups [r13+rax*1], xmm14
0000773e7dfce78b  mov eax, 0x420990
0000773e7dfce790  movups xmm1, [r13+rax*1]
0000773e7dfce796  mov eax, 0x420A00
0000773e7dfce79b  movups xmm15, [r13+rax*1]
0000773e7dfce7a1  mov eax, 0x430CC0
0000773e7dfce7a6  movups [r13+rax*1], xmm13
0000773e7dfce7ac  mov eax, 0x430CD0
0000773e7dfce7b1  movups [r13+rax*1], xmm1
0000773e7dfce7b7  mov eax, 0x420A10
0000773e7dfce7bc  movups xmm1, [r13+rax*1]
0000773e7dfce7c2  mov eax, 0x4209E0
0000773e7dfce7c7  movups xmm14, [r13+rax*1]
0000773e7dfce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000773e7dfce7d5  mov eax, 0x430CE0
0000773e7dfce7da  movups [r13+rax*1], xmm15
0000773e7dfce7e0  mov eax, 0x430CF0
0000773e7dfce7e5  movups [r13+rax*1], xmm1
0000773e7dfce7eb  mov eax, 0x420A80
0000773e7dfce7f0  movups xmm1, [r13+rax*1]
0000773e7dfce7f6  mov eax, 0x420A90
0000773e7dfce7fb  movups xmm15, [r13+rax*1]
0000773e7dfce801  movaps [r15+0x150], xmm15
0000773e7dfce809  mov qword ptr [r15+0xA0], 0x3E8
0000773e7dfce814  mov eax, 0x430D00
0000773e7dfce819  movups [r13+rax*1], xmm14
0000773e7dfce81f  mov eax, 0x430D10
0000773e7dfce824  movups [r13+rax*1], xmm1
0000773e7dfce82a  mov eax, 0x420A70
0000773e7dfce82f  movups xmm1, [r13+rax*1]
0000773e7dfce835  mov eax, 0x420A20
0000773e7dfce83a  movups xmm14, [r13+rax*1]
0000773e7dfce840  movaps [r15+0x140], xmm14
0000773e7dfce848  lea rax, [r14+0x150]
0000773e7dfce84f  movq xmm13, qword ptr [r15+0x200]
0000773e7dfce858  movq xmm12, qword ptr [r15+0x1F0]
0000773e7dfce861  movq r12, xmm13
0000773e7dfce866  movq r11, xmm12
0000773e7dfce86b  mov [r13+rax*1], r12
0000773e7dfce870  lea rax, [r14+0x158]
0000773e7dfce877  mov [r13+rax*1], r11
0000773e7dfce87c  mov eax, 0x430D20
0000773e7dfce881  movups [r13+rax*1], xmm15
0000773e7dfce887  mov eax, 0x430D30
0000773e7dfce88c  movups [r13+rax*1], xmm1
0000773e7dfce892  mov eax, 0x420A40
0000773e7dfce897  movups xmm1, [r13+rax*1]
0000773e7dfce89d  mov eax, 0x420AA8
0000773e7dfce8a2  mov r12, [r13+rax*1]
0000773e7dfce8a7  movq xmm15, r12
0000773e7dfce8ac  mov qword ptr [r15+0x40], 0x420AB0
0000773e7dfce8b4  mov eax, 0x430D40
0000773e7dfce8b9  movups [r13+rax*1], xmm14
0000773e7dfce8bf  mov eax, 0x430D50
0000773e7dfce8c4  movups [r13+rax*1], xmm1
0000773e7dfce8ca  mov eax, 0x420B10
0000773e7dfce8cf  movups xmm1, [r13+rax*1]
0000773e7dfce8d5  movq rax, xmm15
0000773e7dfce8da  mov r12d, 0x430D80
0000773e7dfce8e0  mov [r13+r12*1], rax
0000773e7dfce8e5  mov eax, 0x420AF0
0000773e7dfce8ea  movups xmm15, [r13+rax*1]
0000773e7dfce8f0  mov eax, 0x420B00
0000773e7dfce8f5  movups xmm14, [r13+rax*1]
0000773e7dfce8fb  lea rax, [r14+0x130]
0000773e7dfce902  movups [r13+rax*1], xmm1
0000773e7dfce908  lea rax, [r14+0x160]
0000773e7dfce90f  movq xmm1, qword ptr [r15+0x1E0]
0000773e7dfce918  movq xmm13, qword ptr [r15+0x1D0]
0000773e7dfce921  movq r12, xmm1
0000773e7dfce926  movq r11, xmm13
0000773e7dfce92b  mov [r13+rax*1], r12
0000773e7dfce930  lea rax, [r14+0x168]
0000773e7dfce937  mov [r13+rax*1], r11
0000773e7dfce93c  lea rax, [r14+0x110]
0000773e7dfce943  movups [r13+rax*1], xmm15
0000773e7dfce949  lea rax, [r14+0x120]
0000773e7dfce950  movups [r13+rax*1], xmm14
0000773e7dfce956  mov eax, 0x420AB0
0000773e7dfce95b  movups xmm1, [r13+rax*1]
0000773e7dfce961  mov eax, 0x420AC0
0000773e7dfce966  movups xmm15, [r13+rax*1]
0000773e7dfce96c  movaps [r15+0x120], xmm15
0000773e7dfce974  lea rax, [r14+0x170]
0000773e7dfce97b  movq xmm14, qword ptr [r15+0x1C0]
0000773e7dfce984  movq xmm13, qword ptr [r15+0x1B0]
0000773e7dfce98d  movq r12, xmm14
0000773e7dfce992  movq r11, xmm13
0000773e7dfce997  mov [r13+rax*1], r12
0000773e7dfce99c  lea rax, [r14+0x178]
0000773e7dfce9a3  mov [r13+rax*1], r11
0000773e7dfce9a8  lea rax, [r14+0x180]
0000773e7dfce9af  movq xmm14, qword ptr [r15+0x1A0]
0000773e7dfce9b8  movq xmm13, qword ptr [r15+0x190]
0000773e7dfce9c1  movq r12, xmm14
0000773e7dfce9c6  movq r11, xmm13
0000773e7dfce9cb  mov [r13+rax*1], r12
0000773e7dfce9d0  lea rax, [r14+0x188]
0000773e7dfce9d7  mov [r13+rax*1], r11
0000773e7dfce9dc  lea rax, [r14+0xD0]
0000773e7dfce9e3  movups [r13+rax*1], xmm1
0000773e7dfce9e9  lea rax, [r14+0xE0]
0000773e7dfce9f0  movups [r13+rax*1], xmm15
0000773e7dfce9f6  mov eax, 0x420AD0
0000773e7dfce9fb  movups xmm1, [r13+rax*1]
0000773e7dfcea01  mov eax, 0x420AE0
0000773e7dfcea06  movups xmm15, [r13+rax*1]
0000773e7dfcea0c  movaps [r15+0x110], xmm1
0000773e7dfcea14  movaps [r15+0x130], xmm15
0000773e7dfcea1c  lea rax, [r14+0x190]
0000773e7dfcea23  mov r12, [r15+0xE8]
0000773e7dfcea2a  mov r11, [r15+0xF0]
0000773e7dfcea31  mov [r13+rax*1], r12
0000773e7dfcea36  lea rax, [r14+0x198]
0000773e7dfcea3d  mov [r13+rax*1], r11
0000773e7dfcea42  mov eax, 0x430D88
0000773e7dfcea47  mov r12d, 0x421DF8D3
0000773e7dfcea4d  mov [r13+rax*1], r12d
0000773e7dfcea52  lea rax, [r14+0xF0]
0000773e7dfcea59  movups [r13+rax*1], xmm1
0000773e7dfcea5f  lea rax, [r14+0x100]
0000773e7dfcea66  movups [r13+rax*1], xmm15
0000773e7dfcea6c  lea rax, [r14+0xD0]
0000773e7dfcea73  mov [r15], rax
0000773e7dfcea76  mov qword ptr [r15+0x08], 0x430C60
0000773e7dfcea7e  mov qword ptr [r15+0x10], 0x12C
0000773e7dfcea86  mov qword ptr [r15+0xF0], 0x410284
0000773e7dfcea91  mov r14d, [r15+0x320]
0000773e7dfcea98  mov eax, 0x410284
0000773e7dfcea9d  mov rcx, 0x773E7DFD07C0
0000773e7dfceaa7  mov [r15+r14*8+0x328], rax
0000773e7dfceaaf  mov [r15+r14*8+0x368], rcx
0000773e7dfceab7  add r14d, 0x01
0000773e7dfceabb  and r14d, 0x07
0000773e7dfceabf  mov [r15+0x320], r14d
0000773e7dfceac6  cmp dword ptr [r15+0x318], 0x00
0000773e7dfceace  jz 0x0000773E7DFCED70
0000773e7dfcead4  nop [rax+rax*1], ax
0000773e7dfceadd  nop [rax+rax*1], eax
0000773e7dfceae5  mov eax, 0x4106BC
0000773e7dfceaea  mov [r15+0x100], rax
0000773e7dfceaf1  jmp 0x0000773E7DDFE110
0000773e7dfceaf6  int3
0000773e7dfceaf7  call 0x0000773E7DE0BC20
0000773e7dfceafc  jmp 0x0000773E7DFCE6CF
0000773e7dfceb01  call 0x0000773E7DE0A9A0
0000773e7dfceb06  jmp 0x0000773E7DFCE6DB
0000773e7dfceb0b  call 0x0000773E7DDFF430
0000773e7dfceb10  jmp 0x0000773E7DFCE6E6
0000773e7dfceb15  call 0x0000773E7DE0E760
0000773e7dfceb1a  jmp 0x0000773E7DFCE6F1
0000773e7dfceb1f  call 0x0000773E7DE0D4E0
0000773e7dfceb24  jmp 0x0000773E7DFCE6FC
0000773e7dfceb29  call 0x0000773E7DE0C260
0000773e7dfceb2e  jmp 0x0000773E7DFCE707
0000773e7dfceb33  call 0x0000773E7DE0AFE0
0000773e7dfceb38  jmp 0x0000773E7DFCE71D
0000773e7dfceb3d  call 0x0000773E7DDFF540
0000773e7dfceb42  jmp 0x0000773E7DFCE728
0000773e7dfceb47  call 0x0000773E7DE0E880
0000773e7dfceb4c  jmp 0x0000773E7DFCE733
0000773e7dfceb51  call 0x0000773E7DE0D600
0000773e7dfceb56  jmp 0x0000773E7DFCE73E
0000773e7dfceb5b  call 0x0000773E7DE0C380
0000773e7dfceb60  jmp 0x0000773E7DFCE749
0000773e7dfceb65  call 0x0000773E7DE0D4E0
0000773e7dfceb6a  jmp 0x0000773E7DFCE754
0000773e7dfceb6f  call 0x0000773E7DE0C260
0000773e7dfceb74  jmp 0x0000773E7DFCE75F
0000773e7dfceb79  call 0x0000773E7DDFF540
0000773e7dfceb7e  jmp 0x0000773E7DFCE76A
0000773e7dfceb83  call 0x0000773E7DE0E880
0000773e7dfceb88  jmp 0x0000773E7DFCE775
0000773e7dfceb8d  call 0x0000773E7DE0B100
0000773e7dfceb92  jmp 0x0000773E7DFCE780
0000773e7dfceb97  call 0x0000773E7DE0D600
0000773e7dfceb9c  jmp 0x0000773E7DFCE78B
0000773e7dfceba1  call 0x0000773E7DDFF430
0000773e7dfceba6  jmp 0x0000773E7DFCE796
0000773e7dfcebab  call 0x0000773E7DE0E760
0000773e7dfcebb0  jmp 0x0000773E7DFCE7A1
0000773e7dfcebb5  call 0x0000773E7DE0C380
0000773e7dfcebba  jmp 0x0000773E7DFCE7AC
0000773e7dfcebbf  call 0x0000773E7DDFF540
0000773e7dfcebc4  jmp 0x0000773E7DFCE7B7
0000773e7dfcebc9  call 0x0000773E7DDFF430
0000773e7dfcebce  jmp 0x0000773E7DFCE7C2
0000773e7dfcebd3  call 0x0000773E7DE0D4E0
0000773e7dfcebd8  jmp 0x0000773E7DFCE7CD
0000773e7dfcebdd  call 0x0000773E7DE0E880
0000773e7dfcebe2  jmp 0x0000773E7DFCE7E0
0000773e7dfcebe7  call 0x0000773E7DDFF540
0000773e7dfcebec  jmp 0x0000773E7DFCE7EB
0000773e7dfcebf1  call 0x0000773E7DDFF430
0000773e7dfcebf6  jmp 0x0000773E7DFCE7F6
0000773e7dfcebfb  call 0x0000773E7DE0E760
0000773e7dfcec00  jmp 0x0000773E7DFCE801
0000773e7dfcec05  call 0x0000773E7DE0D600
0000773e7dfcec0a  jmp 0x0000773E7DFCE81F
0000773e7dfcec0f  call 0x0000773E7DDFF540
0000773e7dfcec14  jmp 0x0000773E7DFCE82A
0000773e7dfcec19  call 0x0000773E7DDFF430
0000773e7dfcec1e  jmp 0x0000773E7DFCE835
0000773e7dfcec23  call 0x0000773E7DE0D4E0
0000773e7dfcec28  jmp 0x0000773E7DFCE840
0000773e7dfcec2d  call 0x0000773E7DE0BC20
0000773e7dfcec32  jmp 0x0000773E7DFCE870
0000773e7dfcec37  call 0x0000773E7DE0A9A0
0000773e7dfcec3c  jmp 0x0000773E7DFCE87C
0000773e7dfcec41  call 0x0000773E7DE0E880
0000773e7dfcec46  jmp 0x0000773E7DFCE887
0000773e7dfcec4b  call 0x0000773E7DDFF540
0000773e7dfcec50  jmp 0x0000773E7DFCE892
0000773e7dfcec55  call 0x0000773E7DDFF430
0000773e7dfcec5a  jmp 0x0000773E7DFCE89D
0000773e7dfcec5f  call 0x0000773E7DE0B720
0000773e7dfcec64  jmp 0x0000773E7DFCE8A7
0000773e7dfcec69  call 0x0000773E7DE0D600
0000773e7dfcec6e  jmp 0x0000773E7DFCE8BF
0000773e7dfcec73  call 0x0000773E7DDFF540
0000773e7dfcec78  jmp 0x0000773E7DFCE8CA
0000773e7dfcec7d  call 0x0000773E7DDFF430
0000773e7dfcec82  jmp 0x0000773E7DFCE8D5
0000773e7dfcec87  call 0x0000773E7DEB4CB0
0000773e7dfcec8c  jmp 0x0000773E7DFCE8E5
0000773e7dfcec91  call 0x0000773E7DE0E760
0000773e7dfcec96  jmp 0x0000773E7DFCE8F0
0000773e7dfcec9b  call 0x0000773E7DE0D4E0
0000773e7dfceca0  jmp 0x0000773E7DFCE8FB
0000773e7dfceca5  call 0x0000773E7DDFF540
0000773e7dfcecaa  jmp 0x0000773E7DFCE908
0000773e7dfcecaf  call 0x0000773E7DE0BC20
0000773e7dfcecb4  jmp 0x0000773E7DFCE930
0000773e7dfcecb9  call 0x0000773E7DE0A9A0
0000773e7dfcecbe  jmp 0x0000773E7DFCE93C
0000773e7dfcecc3  call 0x0000773E7DE0E880
0000773e7dfcecc8  jmp 0x0000773E7DFCE949
0000773e7dfceccd  call 0x0000773E7DE0D600
0000773e7dfcecd2  jmp 0x0000773E7DFCE956
0000773e7dfcecd7  call 0x0000773E7DDFF430
0000773e7dfcecdc  jmp 0x0000773E7DFCE961
0000773e7dfcece1  call 0x0000773E7DE0E760
0000773e7dfcece6  jmp 0x0000773E7DFCE96C
0000773e7dfceceb  call 0x0000773E7DE0BC20
0000773e7dfcecf0  jmp 0x0000773E7DFCE99C
0000773e7dfcecf5  call 0x0000773E7DE0A9A0
0000773e7dfcecfa  jmp 0x0000773E7DFCE9A8
0000773e7dfcecff  call 0x0000773E7DE0BC20
0000773e7dfced04  jmp 0x0000773E7DFCE9D0
0000773e7dfced09  call 0x0000773E7DE0A9A0
0000773e7dfced0e  jmp 0x0000773E7DFCE9DC
0000773e7dfced13  call 0x0000773E7DDFF540
0000773e7dfced18  jmp 0x0000773E7DFCE9E9
0000773e7dfced1d  call 0x0000773E7DE0E880
0000773e7dfced22  jmp 0x0000773E7DFCE9F6
0000773e7dfced27  call 0x0000773E7DDFF430
0000773e7dfced2c  jmp 0x0000773E7DFCEA01
0000773e7dfced31  call 0x0000773E7DE0E760
0000773e7dfced36  jmp 0x0000773E7DFCEA0C
0000773e7dfced3b  call 0x0000773E7DE0BC20
0000773e7dfced40  jmp 0x0000773E7DFCEA36
0000773e7dfced45  call 0x0000773E7DE0A9A0
0000773e7dfced4a  jmp 0x0000773E7DFCEA42
0000773e7dfced4f  call 0x0000773E7DE0BAE0
0000773e7dfced54  jmp 0x0000773E7DFCEA52
0000773e7dfced59  call 0x0000773E7DDFF540
0000773e7dfced5e  jmp 0x0000773E7DFCEA5F
0000773e7dfced63  call 0x0000773E7DE0E880
0000773e7dfced68  jmp 0x0000773E7DFCEA6C
0000773e7dfced6d  int3
0000773e7dfced6e  nop
0000773e7dfced70  mov rax, [r15]
0000773e7dfced73  lea r14, [rax+0x20]
0000773e7dfced77  mov r12, [r13+r14*1]
0000773e7dfced7c  mov r14, [r15+0x10]
0000773e7dfced80  lea r11, [r12+r14*1]
0000773e7dfced84  mov [r15+0x40], r11
0000773e7dfced88  lea r12, [rax+0x20]
0000773e7dfced8c  mov [r13+r12*1], r11
0000773e7dfced91  test r14, r14
0000773e7dfced94  setz r14b
0000773e7dfced98  movzx r14, r14b
0000773e7dfced9c  mov [rsp+0x414], r14b
0000773e7dfceda4  cmp byte ptr [rsp+0x414], 0x00
0000773e7dfcedac  jz 0x0000773E7DFCEDDE
0000773e7dfcedae  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcedb6  mov eax, 0x410934
0000773e7dfcedbb  mov [r15+0x100], rax
0000773e7dfcedc2  jz 0x0000773E7DDFE0A0
0000773e7dfcedc8  nop [rax+rax*1], eax
0000773e7dfcedcd  mov eax, 0x410934
0000773e7dfcedd2  mov [r15+0x100], rax
0000773e7dfcedd9  jmp 0x0000773E7DDFE110
0000773e7dfcedde  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcede6  jz 0x0000773E7DFCEE30
0000773e7dfcedec  nop [rax+rax*1], ax
0000773e7dfcedf5  nop [rax+rax*1], eax
0000773e7dfcedfd  mov eax, 0x4106CC
0000773e7dfcee02  mov [r15+0x100], rax
0000773e7dfcee09  jmp 0x0000773E7DDFE110
0000773e7dfcee0e  int3
0000773e7dfcee0f  call 0x0000773E7DEE27E0
0000773e7dfcee14  jmp 0x0000773E7DFCED7C
0000773e7dfcee19  call 0x0000773E7DEC0860
0000773e7dfcee1e  jmp 0x0000773E7DFCED91
0000773e7dfcee23  int3
0000773e7dfcee24  nop [rax+rax*1], ax
0000773e7dfcee2d  nop [rax], eax
0000773e7dfcee30  mov rax, [r15+0xF8]
0000773e7dfcee37  lea r14, [rax-0x150]
0000773e7dfcee3e  mov [r15+0xF8], r14
0000773e7dfcee45  mov rax, [r15]
0000773e7dfcee48  lea r12, [rax+0x68]
0000773e7dfcee4c  mov r11, [r13+r12*1]
0000773e7dfcee51  mov [r15+0x88], r11
0000773e7dfcee58  lea r12, [rax+0x28]
0000773e7dfcee5c  mov [r15+0x40], r12
0000773e7dfcee60  mov [r15+0x48], r14
0000773e7dfcee64  mov qword ptr [r15+0x50], 0x420B20
0000773e7dfcee6c  lea rax, [r14+0x100]
0000773e7dfcee73  mov r12, [r15+0xE8]
0000773e7dfcee7a  mov r11, [r15+0xD8]
0000773e7dfcee81  mov [r13+rax*1], r12
0000773e7dfcee86  lea rax, [r14+0x108]
0000773e7dfcee8d  mov [r13+rax*1], r11
0000773e7dfcee92  lea rax, [r14+0x110]
0000773e7dfcee99  mov r12, [r15+0xD0]
0000773e7dfceea0  mov r11, [r15+0xC8]
0000773e7dfceea7  mov [r13+rax*1], r12
0000773e7dfceeac  lea rax, [r14+0x118]
0000773e7dfceeb3  mov [r13+rax*1], r11
0000773e7dfceeb8  lea rax, [r14+0x120]
0000773e7dfceebf  mov r12, [r15+0xC0]
0000773e7dfceec6  mov r11, [r15+0xB8]
0000773e7dfceecd  mov [r13+rax*1], r12
0000773e7dfceed2  lea rax, [r14+0x128]
0000773e7dfceed9  mov [r13+rax*1], r11
0000773e7dfceede  lea rax, [r14+0x130]
0000773e7dfceee5  mov r12, [r15+0xB0]
0000773e7dfceeec  mov r11, [r15+0xA8]
0000773e7dfceef3  mov [r13+rax*1], r12
0000773e7dfceef8  lea rax, [r14+0x138]
0000773e7dfceeff  mov [r13+rax*1], r11
0000773e7dfcef04  lea rax, [r14+0x140]
0000773e7dfcef0b  mov r12, [r15+0xA0]
0000773e7dfcef12  mov r11, [r15+0x98]
0000773e7dfcef19  mov [r13+rax*1], r12
0000773e7dfcef1e  lea rax, [r14+0x148]
0000773e7dfcef25  mov [r13+rax*1], r11
0000773e7dfcef2a  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcef32  jz 0x0000773E7DFCEFD0
0000773e7dfcef38  nop [rax+rax*1], ax
0000773e7dfcef41  nop [rax+rax*1], eax
0000773e7dfcef49  mov eax, 0x410704
0000773e7dfcef4e  mov [r15+0x100], rax
0000773e7dfcef55  jmp 0x0000773E7DDFE110
0000773e7dfcef5a  int3
0000773e7dfcef5b  call 0x0000773E7DEC0370
0000773e7dfcef60  jmp 0x0000773E7DFCEE51
0000773e7dfcef65  call 0x0000773E7DE0BC20
0000773e7dfcef6a  jmp 0x0000773E7DFCEE86
0000773e7dfcef6f  call 0x0000773E7DE0A9A0
0000773e7dfcef74  jmp 0x0000773E7DFCEE92
0000773e7dfcef79  call 0x0000773E7DE0BC20
0000773e7dfcef7e  jmp 0x0000773E7DFCEEAC
0000773e7dfcef83  call 0x0000773E7DE0A9A0
0000773e7dfcef88  jmp 0x0000773E7DFCEEB8
0000773e7dfcef8d  call 0x0000773E7DE0BC20
0000773e7dfcef92  jmp 0x0000773E7DFCEED2
0000773e7dfcef97  call 0x0000773E7DE0A9A0
0000773e7dfcef9c  jmp 0x0000773E7DFCEEDE
0000773e7dfcefa1  call 0x0000773E7DE0BC20
0000773e7dfcefa6  jmp 0x0000773E7DFCEEF8
0000773e7dfcefab  call 0x0000773E7DE0A9A0
0000773e7dfcefb0  jmp 0x0000773E7DFCEF04
0000773e7dfcefb5  call 0x0000773E7DE0BC20
0000773e7dfcefba  jmp 0x0000773E7DFCEF1E
0000773e7dfcefbf  call 0x0000773E7DE0A9A0
0000773e7dfcefc4  jmp 0x0000773E7DFCEF2A
0000773e7dfcefc9  int3
0000773e7dfcefca  nop [rax+rax*1], ax
0000773e7dfcefd0  mov rax, [r15+0x08]
0000773e7dfcefd4  movzx r14d, byte ptr [r13+rax*1]
0000773e7dfcefda  movzx r14d, r14b
0000773e7dfcefde  mov [rsp+0x10], r14d
0000773e7dfcefe3  mov r14d, r14d
0000773e7dfcefe6  mov [r15+0x58], r14
0000773e7dfcefea  lea r14, [rax+0x01]
0000773e7dfcefee  mov [r15+0x08], r14
0000773e7dfceff2  mov rax, [r15+0x88]
0000773e7dfceff9  lea r14, [rax+0x01]
0000773e7dfceffd  mov r12, [r15]
0000773e7dfcf000  lea r11, [r12+0x68]
0000773e7dfcf005  mov [r13+r11*1], r14
0000773e7dfcf00a  lea r14, [r12+rax*1]
0000773e7dfcf00e  mov [r15+0x60], r14
0000773e7dfcf012  lea rax, [r14+0x28]
0000773e7dfcf016  mov r11d, [rsp+0x10]
0000773e7dfcf01b  movzx r14d, r11b
0000773e7dfcf01f  mov [r13+rax*1], r14b
0000773e7dfcf024  lea rax, [r12+0x68]
0000773e7dfcf029  mov r14, [r13+rax*1]
0000773e7dfcf02e  mov [r15+0x88], r14
0000773e7dfcf035  xor eax, eax
0000773e7dfcf037  mov r12d, 0x40
0000773e7dfcf03d  cmp r14, r12
0000773e7dfcf040  cmc
0000773e7dfcf041  lahf
0000773e7dfcf042  seto al
0000773e7dfcf045  mov [r15+0x108], eax
0000773e7dfcf04c  mov eax, [r15+0x108]
0000773e7dfcf053  sahf
0000773e7dfcf054  jnz 0x0000773E7DFCF086
0000773e7dfcf056  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcf05e  jz 0x0000773E7DFCF170
0000773e7dfcf064  nop [rax+rax*1], ax
0000773e7dfcf06d  nop [rax+rax*1], eax
0000773e7dfcf075  mov eax, 0x410724
0000773e7dfcf07a  mov [r15+0x100], rax
0000773e7dfcf081  jmp 0x0000773E7DDFE110
0000773e7dfcf086  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcf08e  jz 0x0000773E7DFCF0E0
0000773e7dfcf094  nop [rax+rax*1], ax
0000773e7dfcf09d  nop [rax+rax*1], eax
0000773e7dfcf0a5  mov eax, 0x4106FC
0000773e7dfcf0aa  mov [r15+0x100], rax
0000773e7dfcf0b1  jmp 0x0000773E7DDFE110
0000773e7dfcf0b6  int3
0000773e7dfcf0b7  call 0x0000773E7DE0D860
0000773e7dfcf0bc  jmp 0x0000773E7DFCEFDA
0000773e7dfcf0c1  call 0x0000773E7DEB36E0
0000773e7dfcf0c6  jmp 0x0000773E7DFCF00A
0000773e7dfcf0cb  call 0x0000773E7DE0DD60
0000773e7dfcf0d0  jmp 0x0000773E7DFCF024
0000773e7dfcf0d5  call 0x0000773E7DE0DC20
0000773e7dfcf0da  jmp 0x0000773E7DFCF02E
0000773e7dfcf0df  int3
0000773e7dfcf0e0  mov rax, [r15+0x10]
0000773e7dfcf0e4  lea r14, [rax-0x01]
0000773e7dfcf0e8  mov [r15+0x10], r14
0000773e7dfcf0ec  test r14, r14
0000773e7dfcf0ef  setz r14b
0000773e7dfcf0f3  movzx r14, r14b
0000773e7dfcf0f7  mov [rsp+0x414], r14b
0000773e7dfcf0ff  cmp byte ptr [rsp+0x414], 0x00
0000773e7dfcf107  jz 0x0000773E7DFCF139
0000773e7dfcf109  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcf111  jz 0x0000773E7DFD0670
0000773e7dfcf117  nop [rax+rax*1], ax
0000773e7dfcf120  nop [rax+rax*1], eax
0000773e7dfcf128  mov eax, 0x41091C
0000773e7dfcf12d  mov [r15+0x100], rax
0000773e7dfcf134  jmp 0x0000773E7DDFE110
0000773e7dfcf139  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcf141  jz 0x0000773E7DFCEFD0
0000773e7dfcf147  nop [rax+rax*1], ax
0000773e7dfcf150  nop [rax+rax*1], eax
0000773e7dfcf158  mov eax, 0x410704
0000773e7dfcf15d  mov [r15+0x100], rax
0000773e7dfcf164  jmp 0x0000773E7DDFE110
0000773e7dfcf169  int3
0000773e7dfcf16a  int3
0000773e7dfcf16b  nop [rax+rax*1], eax
0000773e7dfcf170  mov rax, [r15+0x40]
0000773e7dfcf174  movzx r14d, byte ptr [r13+rax*1]
0000773e7dfcf17a  movaps xmm1, [r15+0x110]
0000773e7dfcf182  pinsrb xmm1, r14d, 0x00
0000773e7dfcf189  lea r14, [rax+0x01]
0000773e7dfcf18d  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf193  movaps xmm15, [r15+0x120]
0000773e7dfcf19b  pinsrb xmm15, r12d, 0x00
0000773e7dfcf1a2  lea r14, [rax+0x02]
0000773e7dfcf1a6  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf1ac  movaps xmm14, [r15+0x130]
0000773e7dfcf1b4  pinsrb xmm14, r12d, 0x00
0000773e7dfcf1bb  lea r14, [rax+0x03]
0000773e7dfcf1bf  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf1c5  movaps xmm13, [r15+0x140]
0000773e7dfcf1cd  pinsrb xmm13, r12d, 0x00
0000773e7dfcf1d4  lea r14, [rax+0x04]
0000773e7dfcf1d8  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf1de  pinsrb xmm1, r12d, 0x01
0000773e7dfcf1e5  lea r14, [rax+0x05]
0000773e7dfcf1e9  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf1ef  pinsrb xmm15, r12d, 0x01
0000773e7dfcf1f6  lea r14, [rax+0x06]
0000773e7dfcf1fa  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf200  pinsrb xmm14, r12d, 0x01
0000773e7dfcf207  lea r14, [rax+0x07]
0000773e7dfcf20b  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf211  pinsrb xmm13, r12d, 0x01
0000773e7dfcf218  lea r14, [rax+0x08]
0000773e7dfcf21c  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf222  pinsrb xmm1, r12d, 0x02
0000773e7dfcf229  lea r14, [rax+0x09]
0000773e7dfcf22d  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf233  pinsrb xmm15, r12d, 0x02
0000773e7dfcf23a  lea r14, [rax+0x0A]
0000773e7dfcf23e  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf244  pinsrb xmm14, r12d, 0x02
0000773e7dfcf24b  lea r14, [rax+0x0B]
0000773e7dfcf24f  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf255  pinsrb xmm13, r12d, 0x02
0000773e7dfcf25c  lea r14, [rax+0x0C]
0000773e7dfcf260  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf266  pinsrb xmm1, r12d, 0x03
0000773e7dfcf26d  lea r14, [rax+0x0D]
0000773e7dfcf271  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf277  pinsrb xmm15, r12d, 0x03
0000773e7dfcf27e  lea r14, [rax+0x0E]
0000773e7dfcf282  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf288  pinsrb xmm14, r12d, 0x03
0000773e7dfcf28f  lea r14, [rax+0x0F]
0000773e7dfcf293  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf299  pinsrb xmm13, r12d, 0x03
0000773e7dfcf2a0  lea r14, [rax+0x10]
0000773e7dfcf2a4  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf2aa  pinsrb xmm1, r12d, 0x04
0000773e7dfcf2b1  lea r14, [rax+0x11]
0000773e7dfcf2b5  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf2bb  pinsrb xmm15, r12d, 0x04
0000773e7dfcf2c2  lea r14, [rax+0x12]
0000773e7dfcf2c6  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf2cc  pinsrb xmm14, r12d, 0x04
0000773e7dfcf2d3  lea r14, [rax+0x13]
0000773e7dfcf2d7  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf2dd  pinsrb xmm13, r12d, 0x04
0000773e7dfcf2e4  lea r14, [rax+0x14]
0000773e7dfcf2e8  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf2ee  pinsrb xmm1, r12d, 0x05
0000773e7dfcf2f5  lea r14, [rax+0x15]
0000773e7dfcf2f9  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf2ff  pinsrb xmm15, r12d, 0x05
0000773e7dfcf306  lea r14, [rax+0x16]
0000773e7dfcf30a  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf310  pinsrb xmm14, r12d, 0x05
0000773e7dfcf317  lea r14, [rax+0x17]
0000773e7dfcf31b  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf321  pinsrb xmm13, r12d, 0x05
0000773e7dfcf328  lea r14, [rax+0x18]
0000773e7dfcf32c  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf332  pinsrb xmm1, r12d, 0x06
0000773e7dfcf339  lea r14, [rax+0x19]
0000773e7dfcf33d  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf343  pinsrb xmm15, r12d, 0x06
0000773e7dfcf34a  lea r14, [rax+0x1A]
0000773e7dfcf34e  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf354  pinsrb xmm14, r12d, 0x06
0000773e7dfcf35b  lea r14, [rax+0x1B]
0000773e7dfcf35f  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf365  pinsrb xmm13, r12d, 0x06
0000773e7dfcf36c  lea r14, [rax+0x1C]
0000773e7dfcf370  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf376  pinsrb xmm1, r12d, 0x07
0000773e7dfcf37d  lea r14, [rax+0x1D]
0000773e7dfcf381  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf387  pinsrb xmm15, r12d, 0x07
0000773e7dfcf38e  lea r14, [rax+0x1E]
0000773e7dfcf392  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf398  pinsrb xmm14, r12d, 0x07
0000773e7dfcf39f  lea r14, [rax+0x1F]
0000773e7dfcf3a3  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf3a9  pinsrb xmm13, r12d, 0x07
0000773e7dfcf3b0  lea r14, [rax+0x20]
0000773e7dfcf3b4  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf3ba  pinsrb xmm1, r12d, 0x08
0000773e7dfcf3c1  lea r14, [rax+0x21]
0000773e7dfcf3c5  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf3cb  pinsrb xmm15, r12d, 0x08
0000773e7dfcf3d2  lea r14, [rax+0x22]
0000773e7dfcf3d6  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf3dc  pinsrb xmm14, r12d, 0x08
0000773e7dfcf3e3  lea r14, [rax+0x23]
0000773e7dfcf3e7  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf3ed  pinsrb xmm13, r12d, 0x08
0000773e7dfcf3f4  lea r14, [rax+0x24]
0000773e7dfcf3f8  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf3fe  pinsrb xmm1, r12d, 0x09
0000773e7dfcf405  lea r14, [rax+0x25]
0000773e7dfcf409  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf40f  pinsrb xmm15, r12d, 0x09
0000773e7dfcf416  lea r14, [rax+0x26]
0000773e7dfcf41a  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf420  pinsrb xmm14, r12d, 0x09
0000773e7dfcf427  lea r14, [rax+0x27]
0000773e7dfcf42b  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf431  pinsrb xmm13, r12d, 0x09
0000773e7dfcf438  lea r14, [rax+0x28]
0000773e7dfcf43c  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf442  pinsrb xmm1, r12d, 0x0A
0000773e7dfcf449  lea r14, [rax+0x29]
0000773e7dfcf44d  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf453  pinsrb xmm15, r12d, 0x0A
0000773e7dfcf45a  lea r14, [rax+0x2A]
0000773e7dfcf45e  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf464  pinsrb xmm14, r12d, 0x0A
0000773e7dfcf46b  lea r14, [rax+0x2B]
0000773e7dfcf46f  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf475  pinsrb xmm13, r12d, 0x0A
0000773e7dfcf47c  lea r14, [rax+0x2C]
0000773e7dfcf480  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf486  pinsrb xmm1, r12d, 0x0B
0000773e7dfcf48d  lea r14, [rax+0x2D]
0000773e7dfcf491  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf497  pinsrb xmm15, r12d, 0x0B
0000773e7dfcf49e  lea r14, [rax+0x2E]
0000773e7dfcf4a2  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf4a8  pinsrb xmm14, r12d, 0x0B
0000773e7dfcf4af  lea r14, [rax+0x2F]
0000773e7dfcf4b3  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf4b9  pinsrb xmm13, r12d, 0x0B
0000773e7dfcf4c0  lea r14, [rax+0x30]
0000773e7dfcf4c4  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf4ca  pinsrb xmm1, r12d, 0x0C
0000773e7dfcf4d1  lea r14, [rax+0x31]
0000773e7dfcf4d5  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf4db  pinsrb xmm15, r12d, 0x0C
0000773e7dfcf4e2  lea r14, [rax+0x32]
0000773e7dfcf4e6  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf4ec  pinsrb xmm14, r12d, 0x0C
0000773e7dfcf4f3  lea r14, [rax+0x33]
0000773e7dfcf4f7  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf4fd  pinsrb xmm13, r12d, 0x0C
0000773e7dfcf504  lea r14, [rax+0x34]
0000773e7dfcf508  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf50e  pinsrb xmm1, r12d, 0x0D
0000773e7dfcf515  lea r14, [rax+0x35]
0000773e7dfcf519  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf51f  pinsrb xmm15, r12d, 0x0D
0000773e7dfcf526  lea r14, [rax+0x36]
0000773e7dfcf52a  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf530  pinsrb xmm14, r12d, 0x0D
0000773e7dfcf537  lea r14, [rax+0x37]
0000773e7dfcf53b  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf541  pinsrb xmm13, r12d, 0x0D
0000773e7dfcf548  lea r14, [rax+0x38]
0000773e7dfcf54c  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf552  pinsrb xmm1, r12d, 0x0E
0000773e7dfcf559  lea r14, [rax+0x39]
0000773e7dfcf55d  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf563  pinsrb xmm15, r12d, 0x0E
0000773e7dfcf56a  lea r14, [rax+0x3A]
0000773e7dfcf56e  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf574  pinsrb xmm14, r12d, 0x0E
0000773e7dfcf57b  lea r14, [rax+0x3B]
0000773e7dfcf57f  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf585  pinsrb xmm13, r12d, 0x0E
0000773e7dfcf58c  lea r14, [rax+0x3C]
0000773e7dfcf590  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf596  pinsrb xmm1, r12d, 0x0F
0000773e7dfcf59d  movaps [r15+0x110], xmm1
0000773e7dfcf5a5  lea r14, [rax+0x3D]
0000773e7dfcf5a9  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf5af  pinsrb xmm15, r12d, 0x0F
0000773e7dfcf5b6  movaps [r15+0x120], xmm15
0000773e7dfcf5be  lea r14, [rax+0x3E]
0000773e7dfcf5c2  movzx r12d, byte ptr [r13+r14*1]
0000773e7dfcf5c8  pinsrb xmm14, r12d, 0x0F
0000773e7dfcf5cf  movaps [r15+0x130], xmm14
0000773e7dfcf5d7  lea r14, [rax+0x3F]
0000773e7dfcf5db  movzx eax, byte ptr [r13+r14*1]
0000773e7dfcf5e1  pinsrb xmm13, eax, 0x0F
0000773e7dfcf5e8  movaps [r15+0x140], xmm13
0000773e7dfcf5f0  movq xmm1, qword ptr [r15+0x120]
0000773e7dfcf5f9  pmovzxbw xmm1, xmm1
0000773e7dfcf5fe  psllw xmm1, 0x00
0000773e7dfcf603  movaps [r15+0x150], xmm1
0000773e7dfcf60b  movq xmm1, qword ptr [r15+0x130]
0000773e7dfcf614  pmovzxbw xmm1, xmm1
0000773e7dfcf619  psllw xmm1, 0x00
0000773e7dfcf61e  movaps [r15+0x160], xmm1
0000773e7dfcf626  movq xmm1, qword ptr [r15+0x110]
0000773e7dfcf62f  pmovzxbw xmm1, xmm1
0000773e7dfcf634  psllw xmm1, 0x00
0000773e7dfcf639  movaps [r15+0x170], xmm1
0000773e7dfcf641  movaps xmm15, [r15+0x110]
0000773e7dfcf649  pextrq rax, xmm15, 0x01
0000773e7dfcf650  movq xmm15, rax
0000773e7dfcf655  pmovzxbw xmm15, xmm15
0000773e7dfcf65b  psllw xmm15, 0x00
0000773e7dfcf661  movaps [r15+0x180], xmm15
0000773e7dfcf669  movaps xmm14, [r15+0x120]
0000773e7dfcf671  pextrq rax, xmm14, 0x01
0000773e7dfcf678  movq xmm14, rax
0000773e7dfcf67d  pmovzxbw xmm14, xmm14
0000773e7dfcf683  psllw xmm14, 0x00
0000773e7dfcf689  movaps [r15+0x210], xmm14
0000773e7dfcf691  movaps xmm13, [r15+0x130]
0000773e7dfcf699  pextrq rax, xmm13, 0x01
0000773e7dfcf6a0  movq xmm13, rax
0000773e7dfcf6a5  pmovzxbw xmm13, xmm13
0000773e7dfcf6ab  psllw xmm13, 0x00
0000773e7dfcf6b1  movaps [r15+0x220], xmm13
0000773e7dfcf6b9  movq xmm12, qword ptr [r15+0x140]
0000773e7dfcf6c2  pmovzxbw xmm12, xmm12
0000773e7dfcf6c8  psllw xmm12, 0x00
0000773e7dfcf6ce  movaps [r15+0x250], xmm12
0000773e7dfcf6d6  movaps xmm12, [r15+0x140]
0000773e7dfcf6de  pextrq rax, xmm12, 0x01
0000773e7dfcf6e5  movq xmm12, rax
0000773e7dfcf6ea  pmovzxbw xmm12, xmm12
0000773e7dfcf6f0  psllw xmm12, 0x00
0000773e7dfcf6f6  movaps [r15+0x110], xmm12
0000773e7dfcf6fe  movq xmm11, qword ptr [r15+0x150]
0000773e7dfcf707  pmovzxwd xmm11, xmm11
0000773e7dfcf70d  pslld xmm11, 0x10
0000773e7dfcf713  movq xmm10, qword ptr [r15+0x160]
0000773e7dfcf71c  pmovzxwd xmm10, xmm10
0000773e7dfcf722  pslld xmm10, 0x08
0000773e7dfcf728  pextrq rax, xmm1, 0x01
0000773e7dfcf72f  movq xmm1, rax
0000773e7dfcf734  pmovzxwd xmm1, xmm1
0000773e7dfcf739  pslld xmm1, 0x00
0000773e7dfcf73e  movaps [r15+0x260], xmm1
0000773e7dfcf746  pextrq rax, xmm15, 0x01
0000773e7dfcf74d  movq xmm15, rax
0000773e7dfcf752  pmovzxwd xmm15, xmm15
0000773e7dfcf758  pslld xmm15, 0x00
0000773e7dfcf75e  movaps [r15+0x270], xmm15
0000773e7dfcf766  movq xmm9, qword ptr [r15+0x170]
0000773e7dfcf76f  pmovzxwd xmm9, xmm9
0000773e7dfcf775  pslld xmm9, 0x00
0000773e7dfcf77b  pextrq rax, xmm14, 0x01
0000773e7dfcf782  movq xmm14, rax
0000773e7dfcf787  pmovzxwd xmm14, xmm14
0000773e7dfcf78d  pslld xmm14, 0x10
0000773e7dfcf793  movaps [r15+0x280], xmm14
0000773e7dfcf79b  movq xmm8, qword ptr [r15+0x180]
0000773e7dfcf7a4  pmovzxwd xmm8, xmm8
0000773e7dfcf7aa  pslld xmm8, 0x00
0000773e7dfcf7b0  movq xmm7, qword ptr [r15+0x210]
0000773e7dfcf7b9  pmovzxwd xmm7, xmm7
0000773e7dfcf7be  pslld xmm7, 0x10
0000773e7dfcf7c3  movaps xmm6, [r15+0x150]
0000773e7dfcf7cb  pextrq rax, xmm6, 0x01
0000773e7dfcf7d2  movq xmm6, rax
0000773e7dfcf7d7  pmovzxwd xmm6, xmm6
0000773e7dfcf7dc  pslld xmm6, 0x10
0000773e7dfcf7e1  por xmm11, xmm10
0000773e7dfcf7e6  movaps [r15+0x230], xmm11
0000773e7dfcf7ee  pextrq rax, xmm13, 0x01
0000773e7dfcf7f5  movq xmm13, rax
0000773e7dfcf7fa  pmovzxwd xmm13, xmm13
0000773e7dfcf800  pslld xmm13, 0x08
0000773e7dfcf806  movaps [r15+0x240], xmm13
0000773e7dfcf80e  movq xmm10, qword ptr [r15+0x220]
0000773e7dfcf817  pmovzxwd xmm10, xmm10
0000773e7dfcf81d  pslld xmm10, 0x08
0000773e7dfcf823  movaps xmm5, [r15+0x160]
0000773e7dfcf82b  pextrq rax, xmm5, 0x01
0000773e7dfcf832  movq xmm5, rax
0000773e7dfcf837  pmovzxwd xmm5, xmm5
0000773e7dfcf83c  pslld xmm5, 0x08
0000773e7dfcf841  pslld xmm9, 0x18
0000773e7dfcf847  pslld xmm15, 0x18
0000773e7dfcf84d  pslld xmm8, 0x18
0000773e7dfcf853  movq xmm4, qword ptr [r15+0x250]
0000773e7dfcf85c  pmovzxwd xmm4, xmm4
0000773e7dfcf861  pslld xmm4, 0x00
0000773e7dfcf866  por xmm14, xmm13
0000773e7dfcf86b  por xmm7, xmm10
0000773e7dfcf870  movaps [r15+0x210], xmm7
0000773e7dfcf878  pslld xmm1, 0x18
0000773e7dfcf87d  movaps [r15+0x220], xmm1
0000773e7dfcf885  por xmm6, xmm5
0000773e7dfcf889  por xmm11, xmm9
0000773e7dfcf88e  movaps [r15+0x160], xmm11
0000773e7dfcf896  pextrq rax, xmm12, 0x01
0000773e7dfcf89d  movq xmm13, rax
0000773e7dfcf8a2  pmovzxwd xmm13, xmm13
0000773e7dfcf8a8  pslld xmm13, 0x00
0000773e7dfcf8ae  movaps [r15+0x170], xmm13
0000773e7dfcf8b6  movq xmm12, qword ptr [r15+0x110]
0000773e7dfcf8bf  pmovzxwd xmm12, xmm12
0000773e7dfcf8c5  pslld xmm12, 0x00
0000773e7dfcf8cb  por xmm14, xmm15
0000773e7dfcf8d0  por xmm7, xmm8
0000773e7dfcf8d5  movaps xmm15, [r15+0x250]
0000773e7dfcf8dd  pextrq rax, xmm15, 0x01
0000773e7dfcf8e4  movq xmm15, rax
0000773e7dfcf8e9  pmovzxwd xmm15, xmm15
0000773e7dfcf8ef  pslld xmm15, 0x00
0000773e7dfcf8f5  movaps [r15+0x180], xmm15
0000773e7dfcf8fd  por xmm6, xmm1
0000773e7dfcf901  movaps [r15+0x150], xmm6
0000773e7dfcf909  por xmm11, xmm4
0000773e7dfcf90e  movaps [r15+0x140], xmm11
0000773e7dfcf916  por xmm7, xmm12
0000773e7dfcf91b  movaps [r15+0x110], xmm7
0000773e7dfcf923  por xmm14, xmm13
0000773e7dfcf928  movaps [r15+0x120], xmm14
0000773e7dfcf930  por xmm6, xmm15
0000773e7dfcf935  movaps [r15+0x130], xmm6
0000773e7dfcf93d  mov rax, [r15+0xF8]
0000773e7dfcf944  lea r14, [rax+0x20]
0000773e7dfcf948  movups [r13+r14*1], xmm7
0000773e7dfcf94e  lea r14, [rax+0x30]
0000773e7dfcf952  movups [r13+r14*1], xmm14
0000773e7dfcf958  movups [r13+rax*1], xmm11
0000773e7dfcf95e  lea r14, [rax+0x10]
0000773e7dfcf962  movups [r13+r14*1], xmm6
0000773e7dfcf968  mov r14d, [r13+rax*1]
0000773e7dfcf96d  mov rax, [r15+0x48]
0000773e7dfcf971  mov [r15+0x68], rax
0000773e7dfcf975  mov qword ptr [r15+0x58], 0x04
0000773e7dfcf97d  lea r12, [rax+0x04]
0000773e7dfcf981  mov r11d, [r13+r12*1]
0000773e7dfcf986  mov [rsp+0x10], r11d
0000773e7dfcf98b  mov r11d, r11d
0000773e7dfcf98e  mov [r15+0x70], r11
0000773e7dfcf992  lea r12, [rax+0x38]
0000773e7dfcf996  mov r11d, [r13+r12*1]
0000773e7dfcf99b  lea r12, [rax+0x24]
0000773e7dfcf99f  mov r10d, [r13+r12*1]
0000773e7dfcf9a4  mov [rsp+0x20], r10d
0000773e7dfcf9a9  mov r10d, r10d
0000773e7dfcf9ac  mov [r15+0x90], r10
0000773e7dfcf9b3  mov [rsp+0x30], rax
0000773e7dfcf9b8  xor eax, eax
0000773e7dfcf9ba  mov r12d, 0x04
0000773e7dfcf9c0  mov r10d, 0xC0
0000773e7dfcf9c6  cmp r12, r10
0000773e7dfcf9c9  cmc
0000773e7dfcf9ca  lahf
0000773e7dfcf9cb  seto al
0000773e7dfcf9ce  mov [r15+0x108], eax
0000773e7dfcf9d5  mov eax, [rsp+0x10]
0000773e7dfcf9d9  mov r12d, [rsp+0x10]
0000773e7dfcf9de  shrd eax, r12d, 0x07
0000773e7dfcf9e3  mov [rsp+0x10], r11d
0000773e7dfcf9e8  mov r10d, [rsp+0x10]
0000773e7dfcf9ed  shrd r11d, r10d, 0x11
0000773e7dfcf9f2  mov r9d, [rsp+0x20]
0000773e7dfcf9f7  lea r8d, [r9d+r14d*1]
0000773e7dfcf9fc  rorx r14d, r12d, 0x12
0000773e7dfcfa02  xor eax, r14d
0000773e7dfcfa05  rorx r14d, r10d, 0x13
0000773e7dfcfa0b  xor r11d, r14d
0000773e7dfcfa0e  mov [rsp+0x10], r11d
0000773e7dfcfa13  mov r11d, r11d
0000773e7dfcfa16  mov [r15+0x88], r11
0000773e7dfcfa1d  mov [rsp+0x20], r12d
0000773e7dfcfa22  shr r12d, 0x03
0000773e7dfcfa26  xor eax, r12d
0000773e7dfcfa29  mov [rsp+0x40], eax
0000773e7dfcfa2d  mov eax, eax
0000773e7dfcfa2f  mov [r15+0x80], rax
0000773e7dfcfa36  shr r10d, 0x0A
0000773e7dfcfa3a  mov eax, [rsp+0x10]
0000773e7dfcfa3e  xor eax, r10d
0000773e7dfcfa41  mov [rsp+0x10], eax
0000773e7dfcfa45  mov eax, eax
0000773e7dfcfa47  mov [r15+0x78], rax
0000773e7dfcfa4b  mov eax, [rsp+0x40]
0000773e7dfcfa4f  lea r14d, [r8d+eax*1]
0000773e7dfcfa54  mov eax, [rsp+0x10]
0000773e7dfcfa58  lea r12d, [r14d+eax*1]
0000773e7dfcfa5d  mov rax, [rsp+0x30]
0000773e7dfcfa62  lea r14, [rax+0x40]
0000773e7dfcfa66  mov [r13+r14*1], r12d
0000773e7dfcfa6b  mov eax, [rsp+0x20]
0000773e7dfcfa6f  mov eax, eax
0000773e7dfcfa71  mov [r15+0x60], rax
0000773e7dfcfa75  mov eax, [r15+0x108]
0000773e7dfcfa7c  sahf
0000773e7dfcfa7d  jnz 0x0000773E7DFCFAAF
0000773e7dfcfa7f  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcfa87  jz 0x0000773E7DFCFF70
0000773e7dfcfa8d  nop [rax+rax*1], ax
0000773e7dfcfa96  nop [rax+rax*1], eax
0000773e7dfcfa9e  mov eax, 0x410820
0000773e7dfcfaa3  mov [r15+0x100], rax
0000773e7dfcfaaa  jmp 0x0000773E7DDFE110
0000773e7dfcfaaf  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcfab7  jz 0x0000773E7DFCFDC0
0000773e7dfcfabd  nop [rax+rax*1], ax
0000773e7dfcfac6  nop [rax+rax*1], eax
0000773e7dfcface  mov eax, 0x4107D8
0000773e7dfcfad3  mov [r15+0x100], rax
0000773e7dfcfada  jmp 0x0000773E7DDFE110
0000773e7dfcfadf  int3
0000773e7dfcfae0  call 0x0000773E7DE0D860
0000773e7dfcfae5  jmp 0x0000773E7DFCF17A
0000773e7dfcfaea  call 0x0000773E7DEE2420
0000773e7dfcfaef  jmp 0x0000773E7DFCF193
0000773e7dfcfaf4  call 0x0000773E7DEE2420
0000773e7dfcfaf9  jmp 0x0000773E7DFCF1AC
0000773e7dfcfafe  call 0x0000773E7DEE2420
0000773e7dfcfb03  jmp 0x0000773E7DFCF1C5
0000773e7dfcfb08  call 0x0000773E7DEE2420
0000773e7dfcfb0d  jmp 0x0000773E7DFCF1DE
0000773e7dfcfb12  call 0x0000773E7DEE2420
0000773e7dfcfb17  jmp 0x0000773E7DFCF1EF
0000773e7dfcfb1c  call 0x0000773E7DEE2420
0000773e7dfcfb21  jmp 0x0000773E7DFCF200
0000773e7dfcfb26  call 0x0000773E7DEE2420
0000773e7dfcfb2b  jmp 0x0000773E7DFCF211
0000773e7dfcfb30  call 0x0000773E7DEE2420
0000773e7dfcfb35  jmp 0x0000773E7DFCF222
0000773e7dfcfb3a  call 0x0000773E7DEE2420
0000773e7dfcfb3f  jmp 0x0000773E7DFCF233
0000773e7dfcfb44  call 0x0000773E7DEE2420
0000773e7dfcfb49  jmp 0x0000773E7DFCF244
0000773e7dfcfb4e  call 0x0000773E7DEE2420
0000773e7dfcfb53  jmp 0x0000773E7DFCF255
0000773e7dfcfb58  call 0x0000773E7DEE2420
0000773e7dfcfb5d  jmp 0x0000773E7DFCF266
0000773e7dfcfb62  call 0x0000773E7DEE2420
0000773e7dfcfb67  jmp 0x0000773E7DFCF277
0000773e7dfcfb6c  call 0x0000773E7DEE2420
0000773e7dfcfb71  jmp 0x0000773E7DFCF288
0000773e7dfcfb76  call 0x0000773E7DEE2420
0000773e7dfcfb7b  jmp 0x0000773E7DFCF299
0000773e7dfcfb80  call 0x0000773E7DEE2420
0000773e7dfcfb85  jmp 0x0000773E7DFCF2AA
0000773e7dfcfb8a  call 0x0000773E7DEE2420
0000773e7dfcfb8f  jmp 0x0000773E7DFCF2BB
0000773e7dfcfb94  call 0x0000773E7DEE2420
0000773e7dfcfb99  jmp 0x0000773E7DFCF2CC
0000773e7dfcfb9e  call 0x0000773E7DEE2420
0000773e7dfcfba3  jmp 0x0000773E7DFCF2DD
0000773e7dfcfba8  call 0x0000773E7DEE2420
0000773e7dfcfbad  jmp 0x0000773E7DFCF2EE
0000773e7dfcfbb2  call 0x0000773E7DEE2420
0000773e7dfcfbb7  jmp 0x0000773E7DFCF2FF
0000773e7dfcfbbc  call 0x0000773E7DEE2420
0000773e7dfcfbc1  jmp 0x0000773E7DFCF310
0000773e7dfcfbc6  call 0x0000773E7DEE2420
0000773e7dfcfbcb  jmp 0x0000773E7DFCF321
0000773e7dfcfbd0  call 0x0000773E7DEE2420
0000773e7dfcfbd5  jmp 0x0000773E7DFCF332
0000773e7dfcfbda  call 0x0000773E7DEE2420
0000773e7dfcfbdf  jmp 0x0000773E7DFCF343
0000773e7dfcfbe4  call 0x0000773E7DEE2420
0000773e7dfcfbe9  jmp 0x0000773E7DFCF354
0000773e7dfcfbee  call 0x0000773E7DEE2420
0000773e7dfcfbf3  jmp 0x0000773E7DFCF365
0000773e7dfcfbf8  call 0x0000773E7DEE2420
0000773e7dfcfbfd  jmp 0x0000773E7DFCF376
0000773e7dfcfc02  call 0x0000773E7DEE2420
0000773e7dfcfc07  jmp 0x0000773E7DFCF387
0000773e7dfcfc0c  call 0x0000773E7DEE2420
0000773e7dfcfc11  jmp 0x0000773E7DFCF398
0000773e7dfcfc16  call 0x0000773E7DEE2420
0000773e7dfcfc1b  jmp 0x0000773E7DFCF3A9
0000773e7dfcfc20  call 0x0000773E7DEE2420
0000773e7dfcfc25  jmp 0x0000773E7DFCF3BA
0000773e7dfcfc2a  call 0x0000773E7DEE2420
0000773e7dfcfc2f  jmp 0x0000773E7DFCF3CB
0000773e7dfcfc34  call 0x0000773E7DEE2420
0000773e7dfcfc39  jmp 0x0000773E7DFCF3DC
0000773e7dfcfc3e  call 0x0000773E7DEE2420
0000773e7dfcfc43  jmp 0x0000773E7DFCF3ED
0000773e7dfcfc48  call 0x0000773E7DEE2420
0000773e7dfcfc4d  jmp 0x0000773E7DFCF3FE
0000773e7dfcfc52  call 0x0000773E7DEE2420
0000773e7dfcfc57  jmp 0x0000773E7DFCF40F
0000773e7dfcfc5c  call 0x0000773E7DEE2420
0000773e7dfcfc61  jmp 0x0000773E7DFCF420
0000773e7dfcfc66  call 0x0000773E7DEE2420
0000773e7dfcfc6b  jmp 0x0000773E7DFCF431
0000773e7dfcfc70  call 0x0000773E7DEE2420
0000773e7dfcfc75  jmp 0x0000773E7DFCF442
0000773e7dfcfc7a  call 0x0000773E7DEE2420
0000773e7dfcfc7f  jmp 0x0000773E7DFCF453
0000773e7dfcfc84  call 0x0000773E7DEE2420
0000773e7dfcfc89  jmp 0x0000773E7DFCF464
0000773e7dfcfc8e  call 0x0000773E7DEE2420
0000773e7dfcfc93  jmp 0x0000773E7DFCF475
0000773e7dfcfc98  call 0x0000773E7DEE2420
0000773e7dfcfc9d  jmp 0x0000773E7DFCF486
0000773e7dfcfca2  call 0x0000773E7DEE2420
0000773e7dfcfca7  jmp 0x0000773E7DFCF497
0000773e7dfcfcac  call 0x0000773E7DEE2420
0000773e7dfcfcb1  jmp 0x0000773E7DFCF4A8
0000773e7dfcfcb6  call 0x0000773E7DEE2420
0000773e7dfcfcbb  jmp 0x0000773E7DFCF4B9
0000773e7dfcfcc0  call 0x0000773E7DEE2420
0000773e7dfcfcc5  jmp 0x0000773E7DFCF4CA
0000773e7dfcfcca  call 0x0000773E7DEE2420
0000773e7dfcfccf  jmp 0x0000773E7DFCF4DB
0000773e7dfcfcd4  call 0x0000773E7DEE2420
0000773e7dfcfcd9  jmp 0x0000773E7DFCF4EC
0000773e7dfcfcde  call 0x0000773E7DEE2420
0000773e7dfcfce3  jmp 0x0000773E7DFCF4FD
0000773e7dfcfce8  call 0x0000773E7DEE2420
0000773e7dfcfced  jmp 0x0000773E7DFCF50E
0000773e7dfcfcf2  call 0x0000773E7DEE2420
0000773e7dfcfcf7  jmp 0x0000773E7DFCF51F
0000773e7dfcfcfc  call 0x0000773E7DEE2420
0000773e7dfcfd01  jmp 0x0000773E7DFCF530
0000773e7dfcfd06  call 0x0000773E7DEE2420
0000773e7dfcfd0b  jmp 0x0000773E7DFCF541
0000773e7dfcfd10  call 0x0000773E7DEE2420
0000773e7dfcfd15  jmp 0x0000773E7DFCF552
0000773e7dfcfd1a  call 0x0000773E7DEE2420
0000773e7dfcfd1f  jmp 0x0000773E7DFCF563
0000773e7dfcfd24  call 0x0000773E7DEE2420
0000773e7dfcfd29  jmp 0x0000773E7DFCF574
0000773e7dfcfd2e  call 0x0000773E7DEE2420
0000773e7dfcfd33  jmp 0x0000773E7DFCF585
0000773e7dfcfd38  call 0x0000773E7DEE2420
0000773e7dfcfd3d  jmp 0x0000773E7DFCF596
0000773e7dfcfd42  call 0x0000773E7DEE2420
0000773e7dfcfd47  jmp 0x0000773E7DFCF5AF
0000773e7dfcfd4c  call 0x0000773E7DEE2420
0000773e7dfcfd51  jmp 0x0000773E7DFCF5C8
0000773e7dfcfd56  call 0x0000773E7DED5610
0000773e7dfcfd5b  jmp 0x0000773E7DFCF5E1
0000773e7dfcfd60  call 0x0000773E7DEDC580
0000773e7dfcfd65  jmp 0x0000773E7DFCF94E
0000773e7dfcfd6a  call 0x0000773E7DEE46C0
0000773e7dfcfd6f  jmp 0x0000773E7DFCF958
0000773e7dfcfd74  call 0x0000773E7DE09E90
0000773e7dfcfd79  jmp 0x0000773E7DFCF95E
0000773e7dfcfd7e  call 0x0000773E7DEDB310
0000773e7dfcfd83  jmp 0x0000773E7DFCF968
0000773e7dfcfd88  call 0x0000773E7DE0DAE0
0000773e7dfcfd8d  jmp 0x0000773E7DFCF96D
0000773e7dfcfd92  call 0x0000773E7DEC0230
0000773e7dfcfd97  jmp 0x0000773E7DFCF986
0000773e7dfcfd9c  call 0x0000773E7DEC0230
0000773e7dfcfda1  jmp 0x0000773E7DFCF99B
0000773e7dfcfda6  call 0x0000773E7DEBEFC0
0000773e7dfcfdab  jmp 0x0000773E7DFCF9A4
0000773e7dfcfdb0  call 0x0000773E7DEE2BA0
0000773e7dfcfdb5  jmp 0x0000773E7DFCFA6B
0000773e7dfcfdba  int3
0000773e7dfcfdbb  nop [rax+rax*1], eax
0000773e7dfcfdc0  mov rax, [r15+0x48]
0000773e7dfcfdc4  mov r14, [r15+0x58]
0000773e7dfcfdc8  lea r12, [rax+r14*1]
0000773e7dfcfdcc  mov [r15+0x68], r12
0000773e7dfcfdd0  lea rax, [r14+0x04]
0000773e7dfcfdd4  mov [r15+0x58], rax
0000773e7dfcfdd8  lea r14, [r12+0x04]
0000773e7dfcfddd  mov r11d, [r13+r14*1]
0000773e7dfcfde2  mov [rsp+0x10], r11d
0000773e7dfcfde7  mov r11d, r11d
0000773e7dfcfdea  mov [r15+0x70], r11
0000773e7dfcfdee  lea r14, [r12+0x38]
0000773e7dfcfdf3  mov r11d, [r13+r14*1]
0000773e7dfcfdf8  lea r14, [r12+0x24]
0000773e7dfcfdfd  mov r10d, [r13+r14*1]
0000773e7dfcfe02  mov [rsp+0x20], r10d
0000773e7dfcfe07  mov r10d, r10d
0000773e7dfcfe0a  mov [r15+0x90], r10
0000773e7dfcfe11  mov [rsp+0x30], rax
0000773e7dfcfe16  xor eax, eax
0000773e7dfcfe18  mov r14, [rsp+0x30]
0000773e7dfcfe1d  mov r10d, 0xC0
0000773e7dfcfe23  cmp r14, r10
0000773e7dfcfe26  cmc
0000773e7dfcfe27  lahf
0000773e7dfcfe28  seto al
0000773e7dfcfe2b  mov [r15+0x108], eax
0000773e7dfcfe32  mov eax, [rsp+0x10]
0000773e7dfcfe36  mov r14d, [rsp+0x10]
0000773e7dfcfe3b  shrd eax, r14d, 0x07
0000773e7dfcfe40  mov [rsp+0x10], r11d
0000773e7dfcfe45  mov r10d, [rsp+0x10]
0000773e7dfcfe4a  shrd r11d, r10d, 0x11
0000773e7dfcfe4f  mov r9d, [r15+0x60]
0000773e7dfcfe53  mov r8d, [rsp+0x20]
0000773e7dfcfe58  lea ebp, [r8d+r9d*1]
0000773e7dfcfe5d  rorx r9d, r14d, 0x12
0000773e7dfcfe63  xor eax, r9d
0000773e7dfcfe66  rorx r9d, r10d, 0x13
0000773e7dfcfe6c  xor r11d, r9d
0000773e7dfcfe6f  mov [rsp+0x10], r11d
0000773e7dfcfe74  mov r11d, r11d
0000773e7dfcfe77  mov [r15+0x88], r11
0000773e7dfcfe7e  mov [rsp+0x20], r14d
0000773e7dfcfe83  shr r14d, 0x03
0000773e7dfcfe87  xor eax, r14d
0000773e7dfcfe8a  mov [rsp+0x30], eax
0000773e7dfcfe8e  mov eax, eax
0000773e7dfcfe90  mov [r15+0x80], rax
0000773e7dfcfe97  shr r10d, 0x0A
0000773e7dfcfe9b  mov eax, [rsp+0x10]
0000773e7dfcfe9f  xor eax, r10d
0000773e7dfcfea2  mov [rsp+0x10], eax
0000773e7dfcfea6  mov eax, eax
0000773e7dfcfea8  mov [r15+0x78], rax
0000773e7dfcfeac  mov eax, [rsp+0x30]
0000773e7dfcfeb0  lea r14d, [ebp+eax*1]
0000773e7dfcfeb6  mov eax, [rsp+0x10]
0000773e7dfcfeba  lea r11d, [r14d+eax*1]
0000773e7dfcfebf  lea rax, [r12+0x40]
0000773e7dfcfec4  mov [r13+rax*1], r11d
0000773e7dfcfec9  mov eax, [rsp+0x20]
0000773e7dfcfecd  mov eax, eax
0000773e7dfcfecf  mov [r15+0x60], rax
0000773e7dfcfed3  mov eax, [r15+0x108]
0000773e7dfcfeda  sahf
0000773e7dfcfedb  jnz 0x0000773E7DFCFF0D
0000773e7dfcfedd  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcfee5  jz 0x0000773E7DFCFF70
0000773e7dfcfeeb  nop [rax+rax*1], ax
0000773e7dfcfef4  nop [rax+rax*1], eax
0000773e7dfcfefc  mov eax, 0x410820
0000773e7dfcff01  mov [r15+0x100], rax
0000773e7dfcff08  jmp 0x0000773E7DDFE110
0000773e7dfcff0d  cmp dword ptr [r15+0x318], 0x00
0000773e7dfcff15  jz 0x0000773E7DFCFDC0
0000773e7dfcff1b  nop [rax+rax*1], ax
0000773e7dfcff24  nop [rax+rax*1], eax
0000773e7dfcff2c  mov eax, 0x4107D8
0000773e7dfcff31  mov [r15+0x100], rax
0000773e7dfcff38  jmp 0x0000773E7DDFE110
0000773e7dfcff3d  int3
0000773e7dfcff3e  call 0x0000773E7DEE1430
0000773e7dfcff43  jmp 0x0000773E7DFCFDE2
0000773e7dfcff48  call 0x0000773E7DEE1430
0000773e7dfcff4d  jmp 0x0000773E7DFCFDF8
0000773e7dfcff52  call 0x0000773E7DEE01C0
0000773e7dfcff57  jmp 0x0000773E7DFCFE02
0000773e7dfcff5c  call 0x0000773E7DE0A860
0000773e7dfcff61  jmp 0x0000773E7DFCFEC9
0000773e7dfcff66  int3
0000773e7dfcff67  nop [rax+rax*1], ax
0000773e7dfcff70  mov rax, [r15]
0000773e7dfcff73  mov r14d, [r13+rax*1]
0000773e7dfcff78  lea r12, [rax+0x04]
0000773e7dfcff7c  mov r11d, [r13+r12*1]
0000773e7dfcff81  mov [rsp+0x10], r14d
0000773e7dfcff86  mov r14d, r14d
0000773e7dfcff89  mov [r15+0x78], r14
0000773e7dfcff8d  mov [rsp+0x20], r11d
0000773e7dfcff92  mov r11d, r11d
0000773e7dfcff95  mov [r15+0x80], r11
0000773e7dfcff9c  lea r14, [rax+0x08]
0000773e7dfcffa0  mov r12d, [r13+r14*1]
0000773e7dfcffa5  lea r14, [rax+0x0C]
0000773e7dfcffa9  mov r11d, [r13+r14*1]
0000773e7dfcffae  mov [rsp+0x30], r12d
0000773e7dfcffb3  mov r12d, r12d
0000773e7dfcffb6  mov [r15+0x70], r12
0000773e7dfcffba  mov [rsp+0x40], r11d
0000773e7dfcffbf  mov r11d, r11d
0000773e7dfcffc2  mov [r15+0x68], r11
0000773e7dfcffc6  lea r14, [rax+0x18]
0000773e7dfcffca  mov r12d, [r13+r14*1]
0000773e7dfcffcf  lea r14, [rax+0x1C]
0000773e7dfcffd3  mov r11d, [r13+r14*1]
0000773e7dfcffd8  mov [rsp+0x50], r12d
0000773e7dfcffdd  mov r12d, r12d
0000773e7dfcffe0  mov [r15+0x58], r12
0000773e7dfcffe4  mov [rsp+0x60], r11d
0000773e7dfcffe9  mov r11d, r11d
0000773e7dfcffec  mov [r15+0x60], r11
0000773e7dfcfff0  lea r14, [rax+0x10]
0000773e7dfcfff4  mov r12d, [r13+r14*1]
0000773e7dfcfff9  lea r14, [rax+0x14]
0000773e7dfcfffd  mov eax, [r13+r14*1]
0000773e7dfd0002  mov [rsp+0x70], r12d
0000773e7dfd0007  mov r12d, r12d
0000773e7dfd000a  mov [r15+0x18], r12
0000773e7dfd000e  mov [rsp+0x80], eax
0000773e7dfd0015  mov eax, eax
0000773e7dfd0017  mov [r15+0x90], rax
0000773e7dfd001e  mov eax, [rsp+0x70]
0000773e7dfd0022  mov eax, eax
0000773e7dfd0024  mov [r15+0x30], rax
0000773e7dfd0028  mov eax, [rsp+0x50]
0000773e7dfd002c  mov eax, eax
0000773e7dfd002e  mov [r15+0xA0], rax
0000773e7dfd0035  mov eax, [rsp+0x30]
0000773e7dfd0039  mov eax, eax
0000773e7dfd003b  mov [r15+0x28], rax
0000773e7dfd003f  mov eax, [rsp+0x20]
0000773e7dfd0043  mov eax, eax
0000773e7dfd0045  mov [r15+0x98], rax
0000773e7dfd004c  mov eax, [rsp+0x10]
0000773e7dfd0050  mov eax, eax
0000773e7dfd0052  mov [r15+0x38], rax
0000773e7dfd0056  mov eax, [rsp+0x70]
0000773e7dfd005a  mov r14d, [rsp+0x70]
0000773e7dfd005f  shrd eax, r14d, 0x06
0000773e7dfd0064  mov [rsp+0x70], r14d
0000773e7dfd0069  mov r12d, [rsp+0x80]
0000773e7dfd0071  and r14d, r12d
0000773e7dfd0074  mov r11d, [rsp+0x10]
0000773e7dfd0079  mov r10d, [rsp+0x10]
0000773e7dfd007e  shrd r11d, r10d, 0x02
0000773e7dfd0083  mov [rsp+0x10], r12d
0000773e7dfd0088  mov r12d, r12d
0000773e7dfd008b  mov [r15+0x20], r12
0000773e7dfd008f  mov r12, [r15+0x50]
0000773e7dfd0093  mov r9d, [r13+r12*1]
0000773e7dfd0098  mov r12d, [rsp+0x50]
0000773e7dfd009d  mov r8d, [rsp+0x70]
0000773e7dfd00a2  andn ebp, r8d, r12d
0000773e7dfd00a7  mov edi, [rsp+0x60]
0000773e7dfd00ab  lea esi, [r14d+edi*1]
0000773e7dfd00b0  rorx r14d, r8d, 0x0B
0000773e7dfd00b6  xor eax, r14d
0000773e7dfd00b9  rorx r14d, r10d, 0x0D
0000773e7dfd00bf  xor r11d, r14d
0000773e7dfd00c2  lea edi, [esi+ebp*1]
0000773e7dfd00c6  mov r14, [r15+0x48]
0000773e7dfd00ca  mov ebp, [r13+r14*1]
0000773e7dfd00cf  mov r14d, [rsp+0x30]
0000773e7dfd00d4  mov esi, [rsp+0x20]
0000773e7dfd00d8  and r14d, esi
0000773e7dfd00db  mov [rsp+0x20], r14d
0000773e7dfd00e0  mov r14d, r14d
0000773e7dfd00e3  mov [r15+0xD8], r14
0000773e7dfd00ea  lea r14d, [edi+r9d*1]
0000773e7dfd00ef  mov r9d, [rsp+0x30]
0000773e7dfd00f4  xor r9d, esi
0000773e7dfd00f7  rorx edi, r8d, 0x19
0000773e7dfd00fd  xor eax, edi
0000773e7dfd00ff  and r9d, r10d
0000773e7dfd0102  rorx edi, r10d, 0x16
0000773e7dfd0108  xor r11d, edi
0000773e7dfd010b  mov [rsp+0x30], r11d
0000773e7dfd0110  mov r11d, r11d
0000773e7dfd0113  mov [r15+0xD0], r11
0000773e7dfd011a  lea r11d, [r14d+ebp*1]
0000773e7dfd011f  mov r10d, [rsp+0x20]
0000773e7dfd0124  xor r9d, r10d
0000773e7dfd0127  lea r14d, [r11d+eax*1]
0000773e7dfd012c  mov qword ptr [r15+0x88], 0x04
0000773e7dfd0137  mov eax, [rsp+0x30]
0000773e7dfd013b  lea r11d, [r9d+eax*1]
0000773e7dfd0140  mov eax, [rsp+0x40]
0000773e7dfd0144  lea r10d, [r14d+eax*1]
0000773e7dfd0149  mov r10d, r10d
0000773e7dfd014c  mov [r15+0xB8], r10
0000773e7dfd0153  xor eax, eax
0000773e7dfd0155  mov r10d, 0x04
0000773e7dfd015b  mov r9d, 0x100
0000773e7dfd0161  cmp r10, r9
0000773e7dfd0164  cmc
0000773e7dfd0165  lahf
0000773e7dfd0166  seto al
0000773e7dfd0169  mov [r15+0x108], eax
0000773e7dfd0170  lea eax, [r11d+r14d*1]
0000773e7dfd0175  mov eax, eax
0000773e7dfd0177  mov [r15+0xA8], rax
0000773e7dfd017e  mov r12d, r12d
0000773e7dfd0181  mov [r15+0xB0], r12
0000773e7dfd0188  mov eax, [rsp+0x10]
0000773e7dfd018c  mov eax, eax
0000773e7dfd018e  mov [r15+0xC0], rax
0000773e7dfd0195  mov r8d, r8d
0000773e7dfd0198  mov [r15+0xC8], r8
0000773e7dfd019f  mov eax, [r15+0x108]
0000773e7dfd01a6  sahf
0000773e7dfd01a7  jnz 0x0000773E7DFD01D9
0000773e7dfd01a9  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd01b1  jz 0x0000773E7DFD04A0
0000773e7dfd01b7  nop [rax+rax*1], ax
0000773e7dfd01c0  nop [rax+rax*1], eax
0000773e7dfd01c8  mov eax, 0x4108E0
0000773e7dfd01cd  mov [r15+0x100], rax
0000773e7dfd01d4  jmp 0x0000773E7DDFE110
0000773e7dfd01d9  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd01e1  jz 0x0000773E7DFD0270
0000773e7dfd01e7  nop [rax+rax*1], ax
0000773e7dfd01f0  nop [rax+rax*1], eax
0000773e7dfd01f8  mov eax, 0x410854
0000773e7dfd01fd  mov [r15+0x100], rax
0000773e7dfd0204  jmp 0x0000773E7DDFE110
0000773e7dfd0209  int3
0000773e7dfd020a  call 0x0000773E7DE0DAE0
0000773e7dfd020f  jmp 0x0000773E7DFCFF78
0000773e7dfd0214  call 0x0000773E7DEC0230
0000773e7dfd0219  jmp 0x0000773E7DFCFF81
0000773e7dfd021e  call 0x0000773E7DEE26A0
0000773e7dfd0223  jmp 0x0000773E7DFCFFA5
0000773e7dfd0228  call 0x0000773E7DEE1430
0000773e7dfd022d  jmp 0x0000773E7DFCFFAE
0000773e7dfd0232  call 0x0000773E7DEE26A0
0000773e7dfd0237  jmp 0x0000773E7DFCFFCF
0000773e7dfd023c  call 0x0000773E7DEE1430
0000773e7dfd0241  jmp 0x0000773E7DFCFFD8
0000773e7dfd0246  call 0x0000773E7DEE26A0
0000773e7dfd024b  jmp 0x0000773E7DFCFFF9
0000773e7dfd0250  call 0x0000773E7DED5890
0000773e7dfd0255  jmp 0x0000773E7DFD0002
0000773e7dfd025a  call 0x0000773E7DEBDD50
0000773e7dfd025f  jmp 0x0000773E7DFD0098
0000773e7dfd0264  call 0x0000773E7DEDA580
0000773e7dfd0269  jmp 0x0000773E7DFD00CF
0000773e7dfd026e  int3
0000773e7dfd026f  nop
0000773e7dfd0270  mov eax, [r15+0xB8]
0000773e7dfd0277  mov [rsp+0x10], eax
0000773e7dfd027b  mov eax, eax
0000773e7dfd027d  mov [r15+0x30], rax
0000773e7dfd0281  mov eax, [r15+0xC0]
0000773e7dfd0288  mov [rsp+0x20], eax
0000773e7dfd028c  mov eax, eax
0000773e7dfd028e  mov [r15+0xA0], rax
0000773e7dfd0295  mov eax, [r15+0x28]
0000773e7dfd0299  mov r14d, [r15+0x98]
0000773e7dfd02a0  mov [rsp+0x30], r14d
0000773e7dfd02a5  mov r14d, r14d
0000773e7dfd02a8  mov [r15+0x28], r14
0000773e7dfd02ac  mov r14d, [r15+0x38]
0000773e7dfd02b0  mov [rsp+0x40], r14d
0000773e7dfd02b5  mov r14d, r14d
0000773e7dfd02b8  mov [r15+0x98], r14
0000773e7dfd02bf  mov r14d, [r15+0xA8]
0000773e7dfd02c6  mov [rsp+0x50], r14d
0000773e7dfd02cb  mov r14d, r14d
0000773e7dfd02ce  mov [r15+0x38], r14
0000773e7dfd02d2  mov r14d, [rsp+0x10]
0000773e7dfd02d7  mov r12d, [rsp+0x10]
0000773e7dfd02dc  shrd r14d, r12d, 0x06
0000773e7dfd02e1  mov r11d, [r15+0xC8]
0000773e7dfd02e8  mov [rsp+0x10], r12d
0000773e7dfd02ed  and r12d, r11d
0000773e7dfd02f0  mov r10d, [rsp+0x50]
0000773e7dfd02f5  mov r9d, [rsp+0x50]
0000773e7dfd02fa  shrd r10d, r9d, 0x02
0000773e7dfd02ff  mov [rsp+0x50], r11d
0000773e7dfd0304  mov r11d, r11d
0000773e7dfd0307  mov [r15+0x20], r11
0000773e7dfd030b  mov r11, [r15+0x88]
0000773e7dfd0312  mov r8, [r15+0x50]
0000773e7dfd0316  lea rbp, [r8+r11*1]
0000773e7dfd031a  mov r8d, [r13+rbp*1]
0000773e7dfd031f  mov ebp, [rsp+0x20]
0000773e7dfd0323  mov edi, [rsp+0x10]
0000773e7dfd0327  andn esi, edi, ebp
0000773e7dfd032c  mov edx, [r15+0xB0]
0000773e7dfd0333  lea ecx, [r12d+edx*1]
0000773e7dfd0338  rorx r12d, edi, 0x0B
0000773e7dfd033e  xor r14d, r12d
0000773e7dfd0341  rorx r12d, r9d, 0x0D
0000773e7dfd0347  xor r10d, r12d
0000773e7dfd034a  lea r12d, [ecx+esi*1]
0000773e7dfd034f  mov rsi, [r15+0x48]
0000773e7dfd0353  lea rdx, [rsi+r11*1]
0000773e7dfd0357  mov esi, [r13+rdx*1]
0000773e7dfd035c  mov edx, [rsp+0x30]
0000773e7dfd0360  mov ecx, [rsp+0x40]
0000773e7dfd0364  and edx, ecx
0000773e7dfd0366  mov [rsp+0x10], edx
0000773e7dfd036a  mov edx, edx
0000773e7dfd036c  mov [r15+0xD8], rdx
0000773e7dfd0373  lea edx, [r12d+r8d*1]
0000773e7dfd0378  mov r12d, [rsp+0x30]
0000773e7dfd037d  xor r12d, ecx
0000773e7dfd0380  rorx r8d, edi, 0x19
0000773e7dfd0386  xor r14d, r8d
0000773e7dfd0389  and r12d, r9d
0000773e7dfd038c  rorx r8d, r9d, 0x16
0000773e7dfd0392  xor r10d, r8d
0000773e7dfd0395  mov [rsp+0x20], r10d
0000773e7dfd039a  mov r10d, r10d
0000773e7dfd039d  mov [r15+0xD0], r10
0000773e7dfd03a4  lea r10d, [edx+esi*1]
0000773e7dfd03a9  mov r9d, [rsp+0x10]
0000773e7dfd03ae  xor r12d, r9d
0000773e7dfd03b1  lea r9d, [r10d+r14d*1]
0000773e7dfd03b6  lea r14, [r11+0x04]
0000773e7dfd03ba  mov [r15+0x88], r14
0000773e7dfd03c1  mov r11d, [rsp+0x20]
0000773e7dfd03c6  lea r10d, [r12d+r11d*1]
0000773e7dfd03cb  lea r11d, [r9d+eax*1]
0000773e7dfd03d0  mov r11d, r11d
0000773e7dfd03d3  mov [r15+0xB8], r11
0000773e7dfd03da  xor eax, eax
0000773e7dfd03dc  mov r12d, 0x100
0000773e7dfd03e2  cmp r14, r12
0000773e7dfd03e5  cmc
0000773e7dfd03e6  lahf
0000773e7dfd03e7  seto al
0000773e7dfd03ea  mov [r15+0x108], eax
0000773e7dfd03f1  lea eax, [r10d+r9d*1]
0000773e7dfd03f6  mov eax, eax
0000773e7dfd03f8  mov [r15+0xA8], rax
0000773e7dfd03ff  mov ebp, ebp
0000773e7dfd0401  mov [r15+0xB0], rbp
0000773e7dfd0408  mov eax, [rsp+0x50]
0000773e7dfd040c  mov eax, eax
0000773e7dfd040e  mov [r15+0xC0], rax
0000773e7dfd0415  mov edi, edi
0000773e7dfd0417  mov [r15+0xC8], rdi
0000773e7dfd041e  mov eax, [r15+0x108]
0000773e7dfd0425  sahf
0000773e7dfd0426  jnz 0x0000773E7DFD0458
0000773e7dfd0428  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0430  jz 0x0000773E7DFD04A0
0000773e7dfd0436  nop [rax+rax*1], ax
0000773e7dfd043f  nop [rax+rax*1], eax
0000773e7dfd0447  mov eax, 0x4108E0
0000773e7dfd044c  mov [r15+0x100], rax
0000773e7dfd0453  jmp 0x0000773E7DDFE110
0000773e7dfd0458  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0460  jz 0x0000773E7DFD0270
0000773e7dfd0466  nop [rax+rax*1], ax
0000773e7dfd046f  nop [rax+rax*1], eax
0000773e7dfd0477  mov eax, 0x410854
0000773e7dfd047c  mov [r15+0x100], rax
0000773e7dfd0483  jmp 0x0000773E7DDFE110
0000773e7dfd0488  int3
0000773e7dfd0489  call 0x0000773E7DE49010
0000773e7dfd048e  jmp 0x0000773E7DFD031F
0000773e7dfd0493  call 0x0000773E7DE25930
0000773e7dfd0498  jmp 0x0000773E7DFD035C
0000773e7dfd049d  int3
0000773e7dfd049e  nop
0000773e7dfd04a0  mov eax, [r15+0x98]
0000773e7dfd04a7  mov r14d, [r15+0x70]
0000773e7dfd04ab  lea r12d, [eax+r14d*1]
0000773e7dfd04b0  mov eax, [r15+0x28]
0000773e7dfd04b4  mov r14d, [r15+0x68]
0000773e7dfd04b8  lea r11d, [eax+r14d*1]
0000773e7dfd04bd  mov qword ptr [r15+0x88], 0x00
0000773e7dfd04c8  mov eax, [r15+0xA8]
0000773e7dfd04cf  mov r14d, [r15+0x78]
0000773e7dfd04d3  lea r10d, [eax+r14d*1]
0000773e7dfd04d8  mov [rsp+0x10], r10d
0000773e7dfd04dd  mov r10d, r10d
0000773e7dfd04e0  mov [r15+0x78], r10
0000773e7dfd04e4  mov eax, [r15+0x38]
0000773e7dfd04e8  mov r14d, [r15+0x80]
0000773e7dfd04ef  lea r10d, [eax+r14d*1]
0000773e7dfd04f4  mov [rsp+0x20], r10d
0000773e7dfd04f9  mov r10d, r10d
0000773e7dfd04fc  mov [r15+0x80], r10
0000773e7dfd0503  mov rax, [r15]
0000773e7dfd0506  lea r14, [rax+0x08]
0000773e7dfd050a  mov [r13+r14*1], r12d
0000773e7dfd050f  lea r14, [rax+0x0C]
0000773e7dfd0513  mov [r13+r14*1], r11d
0000773e7dfd0518  mov r14d, [r15+0xB8]
0000773e7dfd051f  mov r12d, [r15+0x18]
0000773e7dfd0523  lea r11d, [r14d+r12d*1]
0000773e7dfd0528  mov [rsp+0x30], r11d
0000773e7dfd052d  mov r11d, r11d
0000773e7dfd0530  mov [r15+0x68], r11
0000773e7dfd0534  mov r14d, [r15+0x30]
0000773e7dfd0538  mov r12d, [r15+0x90]
0000773e7dfd053f  lea r11d, [r14d+r12d*1]
0000773e7dfd0544  mov [rsp+0x40], r11d
0000773e7dfd0549  mov r11d, r11d
0000773e7dfd054c  mov [r15+0x70], r11
0000773e7dfd0550  mov r14d, [r15+0x20]
0000773e7dfd0554  mov r12d, [r15+0x58]
0000773e7dfd0558  lea r11d, [r14d+r12d*1]
0000773e7dfd055d  mov [rsp+0x50], r11d
0000773e7dfd0562  mov r11d, r11d
0000773e7dfd0565  mov [r15+0x58], r11
0000773e7dfd0569  mov r14d, [r15+0xA0]
0000773e7dfd0570  mov r12d, [r15+0x60]
0000773e7dfd0574  lea r11d, [r14d+r12d*1]
0000773e7dfd0579  mov [rsp+0x60], r11d
0000773e7dfd057e  mov r11d, r11d
0000773e7dfd0581  mov [r15+0x60], r11
0000773e7dfd0585  mov r14d, [rsp+0x10]
0000773e7dfd058a  mov [r13+rax*1], r14d
0000773e7dfd058f  lea r14, [rax+0x04]
0000773e7dfd0593  mov r12d, [rsp+0x20]
0000773e7dfd0598  mov [r13+r14*1], r12d
0000773e7dfd059d  lea r14, [rax+0x10]
0000773e7dfd05a1  mov r12d, [rsp+0x30]
0000773e7dfd05a6  mov [r13+r14*1], r12d
0000773e7dfd05ab  lea r14, [rax+0x14]
0000773e7dfd05af  mov r12d, [rsp+0x40]
0000773e7dfd05b4  mov [r13+r14*1], r12d
0000773e7dfd05b9  lea r14, [rax+0x18]
0000773e7dfd05bd  mov r12d, [rsp+0x50]
0000773e7dfd05c2  mov [r13+r14*1], r12d
0000773e7dfd05c7  lea r14, [rax+0x1C]
0000773e7dfd05cb  mov r12d, [rsp+0x60]
0000773e7dfd05d0  mov [r13+r14*1], r12d
0000773e7dfd05d5  lea r14, [rax+0x68]
0000773e7dfd05d9  xor eax, eax
0000773e7dfd05db  mov [r13+r14*1], rax
0000773e7dfd05e0  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd05e8  jz 0x0000773E7DFCF0E0
0000773e7dfd05ee  nop [rax+rax*1], ax
0000773e7dfd05f7  nop [rax+rax*1], eax
0000773e7dfd05ff  mov eax, 0x4106FC
0000773e7dfd0604  mov [r15+0x100], rax
0000773e7dfd060b  jmp 0x0000773E7DDFE110
0000773e7dfd0610  int3
0000773e7dfd0611  call 0x0000773E7DEE2BA0
0000773e7dfd0616  jmp 0x0000773E7DFD050F
0000773e7dfd061b  call 0x0000773E7DEE1920
0000773e7dfd0620  jmp 0x0000773E7DFD0518
0000773e7dfd0625  call 0x0000773E7DE0DFE0
0000773e7dfd062a  jmp 0x0000773E7DFD058F
0000773e7dfd062f  call 0x0000773E7DEE2BA0
0000773e7dfd0634  jmp 0x0000773E7DFD059D
0000773e7dfd0639  call 0x0000773E7DEE2BA0
0000773e7dfd063e  jmp 0x0000773E7DFD05AB
0000773e7dfd0643  call 0x0000773E7DEE2BA0
0000773e7dfd0648  jmp 0x0000773E7DFD05B9
0000773e7dfd064d  call 0x0000773E7DEE2BA0
0000773e7dfd0652  jmp 0x0000773E7DFD05C7
0000773e7dfd0657  call 0x0000773E7DEE2BA0
0000773e7dfd065c  jmp 0x0000773E7DFD05D5
0000773e7dfd0661  call 0x0000773E7DED5EB0
0000773e7dfd0666  jmp 0x0000773E7DFD05E0
0000773e7dfd066b  int3
0000773e7dfd066c  nop [rax], eax
0000773e7dfd0670  mov rax, [r15+0xF8]
0000773e7dfd0677  lea r14, [rax+0x140]
0000773e7dfd067e  mov r12, [r13+r14*1]
0000773e7dfd0683  lea r14, [rax+0x148]
0000773e7dfd068a  mov r11, [r13+r14*1]
0000773e7dfd068f  mov [r15+0xA0], r12
0000773e7dfd0696  mov [r15+0x98], r11
0000773e7dfd069d  lea r14, [rax+0x130]
0000773e7dfd06a4  mov r12, [r13+r14*1]
0000773e7dfd06a9  lea r14, [rax+0x138]
0000773e7dfd06b0  mov r11, [r13+r14*1]
0000773e7dfd06b5  mov [r15+0xB0], r12
0000773e7dfd06bc  mov [r15+0xA8], r11
0000773e7dfd06c3  lea r14, [rax+0x120]
0000773e7dfd06ca  mov r12, [r13+r14*1]
0000773e7dfd06cf  lea r14, [rax+0x128]
0000773e7dfd06d6  mov r11, [r13+r14*1]
0000773e7dfd06db  mov [r15+0xC0], r12
0000773e7dfd06e2  mov [r15+0xB8], r11
0000773e7dfd06e9  lea r14, [rax+0x110]
0000773e7dfd06f0  mov r12, [r13+r14*1]
0000773e7dfd06f5  lea r14, [rax+0x118]
0000773e7dfd06fc  mov r11, [r13+r14*1]
0000773e7dfd0701  mov [r15+0xD0], r12
0000773e7dfd0708  mov [r15+0xC8], r11
0000773e7dfd070f  lea r14, [rax+0x100]
0000773e7dfd0716  mov r12, [r13+r14*1]
0000773e7dfd071b  lea r14, [rax+0x108]
0000773e7dfd0722  mov r11, [r13+r14*1]
0000773e7dfd0727  mov [r15+0xE8], r12
0000773e7dfd072e  mov [r15+0xD8], r11
0000773e7dfd0735  lea r14, [rax+0x150]
0000773e7dfd073c  mov [r15+0xF8], r14
0000773e7dfd0743  mov rax, [r15+0xF0]
0000773e7dfd074a  mov [r15+0x100], rax
0000773e7dfd0751  jmp 0x0000773E7DFCE5C0
0000773e7dfd0756  int3
0000773e7dfd0757  call 0x0000773E7DEE27E0
0000773e7dfd075c  jmp 0x0000773E7DFD0683
0000773e7dfd0761  call 0x0000773E7DEE1570
0000773e7dfd0766  jmp 0x0000773E7DFD068F
0000773e7dfd076b  call 0x0000773E7DEE27E0
0000773e7dfd0770  jmp 0x0000773E7DFD06A9
0000773e7dfd0775  call 0x0000773E7DEE1570
0000773e7dfd077a  jmp 0x0000773E7DFD06B5
0000773e7dfd077f  call 0x0000773E7DEE27E0
0000773e7dfd0784  jmp 0x0000773E7DFD06CF
0000773e7dfd0789  call 0x0000773E7DEE1570
0000773e7dfd078e  jmp 0x0000773E7DFD06DB
0000773e7dfd0793  call 0x0000773E7DEE27E0
0000773e7dfd0798  jmp 0x0000773E7DFD06F5
0000773e7dfd079d  call 0x0000773E7DEE1570
0000773e7dfd07a2  jmp 0x0000773E7DFD0701
0000773e7dfd07a7  call 0x0000773E7DEE27E0
0000773e7dfd07ac  jmp 0x0000773E7DFD071B
0000773e7dfd07b1  call 0x0000773E7DEE1570
0000773e7dfd07b6  jmp 0x0000773E7DFD0727
0000773e7dfd07bb  int3
0000773e7dfd07bc  nop [rax], eax
0000773e7dfd07c0  mov eax, [r15+0xA0]
0000773e7dfd07c7  mov [rsp+0x10], eax
0000773e7dfd07cb  xor eax, eax
0000773e7dfd07cd  mov r14d, [rsp+0x10]
0000773e7dfd07d2  sub r14d, 0x01
0000773e7dfd07d6  cmc
0000773e7dfd07d7  lahf
0000773e7dfd07d8  seto al
0000773e7dfd07db  mov [r15+0x108], eax
0000773e7dfd07e2  mov r14d, r14d
0000773e7dfd07e5  mov [r15+0xA0], r14
0000773e7dfd07ec  mov eax, [r15+0x108]
0000773e7dfd07f3  sahf
0000773e7dfd07f4  jnz 0x0000773E7DFD0826
0000773e7dfd07f6  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd07fe  jz 0x0000773E7DFD0900
0000773e7dfd0804  nop [rax+rax*1], ax
0000773e7dfd080d  nop [rax+rax*1], eax
0000773e7dfd0815  mov eax, 0x41028C
0000773e7dfd081a  mov [r15+0x100], rax
0000773e7dfd0821  jmp 0x0000773E7DDFE110
0000773e7dfd0826  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd082e  jz 0x0000773E7DFD0860
0000773e7dfd0834  nop [rax+rax*1], ax
0000773e7dfd083d  nop [rax+rax*1], eax
0000773e7dfd0845  mov eax, 0x410274
0000773e7dfd084a  mov [r15+0x100], rax
0000773e7dfd0851  jmp 0x0000773E7DDFE110
0000773e7dfd0856  int3
0000773e7dfd0857  int3
0000773e7dfd0858  nop [rax+rax*1], eax
0000773e7dfd0860  mov rax, [r15+0xF8]
0000773e7dfd0867  lea r14, [rax+0xD0]
0000773e7dfd086e  mov [r15], r14
0000773e7dfd0871  mov rax, [r15+0x98]
0000773e7dfd0878  mov [r15+0x08], rax
0000773e7dfd087c  mov qword ptr [r15+0x10], 0x12C
0000773e7dfd0884  mov qword ptr [r15+0xF0], 0x410284
0000773e7dfd088f  mov r14d, [r15+0x320]
0000773e7dfd0896  mov eax, 0x410284
0000773e7dfd089b  mov rcx, 0x773E7DFD07C0
0000773e7dfd08a5  mov [r15+r14*8+0x328], rax
0000773e7dfd08ad  mov [r15+r14*8+0x368], rcx
0000773e7dfd08b5  add r14d, 0x01
0000773e7dfd08b9  and r14d, 0x07
0000773e7dfd08bd  mov [r15+0x320], r14d
0000773e7dfd08c4  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd08cc  jz 0x0000773E7DFCED70
0000773e7dfd08d2  nop [rax+rax*1], ax
0000773e7dfd08db  nop [rax+rax*1], eax
0000773e7dfd08e3  mov eax, 0x4106BC
0000773e7dfd08e8  mov [r15+0x100], rax
0000773e7dfd08ef  jmp 0x0000773E7DDFE110
0000773e7dfd08f4  int3
0000773e7dfd08f5  int3
0000773e7dfd08f6  nop [rax+rax*1], ax
0000773e7dfd08ff  nop
0000773e7dfd0900  mov rax, [r15+0xF8]
0000773e7dfd0907  lea r14, [rax+0xF0]
0000773e7dfd090e  mov r12, [r13+r14*1]
0000773e7dfd0913  mov [r15+0x98], r12
0000773e7dfd091a  mov qword ptr [r15+0x40], 0x80
0000773e7dfd0922  lea r14, [rax+0xD0]
0000773e7dfd0929  mov [r15], r14
0000773e7dfd092c  lea r14, [rax+0x14C]
0000773e7dfd0933  mov [r15+0x08], r14
0000773e7dfd0937  mov qword ptr [r15+0x10], 0x01
0000773e7dfd093f  lea r14, [rax+0x14C]
0000773e7dfd0946  mov eax, 0x80
0000773e7dfd094b  mov [r13+r14*1], al
0000773e7dfd0950  mov qword ptr [r15+0xF0], 0x4102A8
0000773e7dfd095b  mov r14d, [r15+0x320]
0000773e7dfd0962  mov eax, 0x4102A8
0000773e7dfd0967  mov rcx, 0x773E7DFD09E0
0000773e7dfd0971  mov [r15+r14*8+0x328], rax
0000773e7dfd0979  mov [r15+r14*8+0x368], rcx
0000773e7dfd0981  add r14d, 0x01
0000773e7dfd0985  and r14d, 0x07
0000773e7dfd0989  mov [r15+0x320], r14d
0000773e7dfd0990  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0998  jz 0x0000773E7DFCED70
0000773e7dfd099e  nop [rax+rax*1], ax
0000773e7dfd09a7  nop [rax+rax*1], eax
0000773e7dfd09af  mov eax, 0x4106BC
0000773e7dfd09b4  mov [r15+0x100], rax
0000773e7dfd09bb  jmp 0x0000773E7DDFE110
0000773e7dfd09c0  int3
0000773e7dfd09c1  call 0x0000773E7DEE27E0
0000773e7dfd09c6  jmp 0x0000773E7DFD0913
0000773e7dfd09cb  call 0x0000773E7DED5AF0
0000773e7dfd09d0  jmp 0x0000773E7DFD0950
0000773e7dfd09d5  int3
0000773e7dfd09d6  nop [rax+rax*1], ax
0000773e7dfd09df  nop
0000773e7dfd09e0  mov rax, [r15+0xF8]
0000773e7dfd09e7  lea r14, [rax+0x138]
0000773e7dfd09ee  mov r12, [r13+r14*1]
0000773e7dfd09f3  mov [r15+0x40], r12
0000773e7dfd09f7  lea r14, [rax+0x148]
0000773e7dfd09fe  xor eax, eax
0000773e7dfd0a00  mov [r13+r14*1], al
0000773e7dfd0a05  xor eax, eax
0000773e7dfd0a07  mov r14d, 0x38
0000773e7dfd0a0d  cmp r12, r14
0000773e7dfd0a10  cmc
0000773e7dfd0a11  lahf
0000773e7dfd0a12  seto al
0000773e7dfd0a15  mov [r15+0x108], eax
0000773e7dfd0a1c  mov eax, [r15+0x108]
0000773e7dfd0a23  sahf
0000773e7dfd0a24  jz 0x0000773E7DFD0A56
0000773e7dfd0a26  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0a2e  jz 0x0000773E7DFD0AA0
0000773e7dfd0a34  nop [rax+rax*1], ax
0000773e7dfd0a3d  nop [rax+rax*1], eax
0000773e7dfd0a45  mov eax, 0x4102B8
0000773e7dfd0a4a  mov [r15+0x100], rax
0000773e7dfd0a51  jmp 0x0000773E7DDFE110
0000773e7dfd0a56  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0a5e  jz 0x0000773E7DFD0BF0
0000773e7dfd0a64  nop [rax+rax*1], ax
0000773e7dfd0a6d  nop [rax+rax*1], eax
0000773e7dfd0a75  mov eax, 0x4102D4
0000773e7dfd0a7a  mov [r15+0x100], rax
0000773e7dfd0a81  jmp 0x0000773E7DDFE110
0000773e7dfd0a86  int3
0000773e7dfd0a87  call 0x0000773E7DEE27E0
0000773e7dfd0a8c  jmp 0x0000773E7DFD09F3
0000773e7dfd0a91  call 0x0000773E7DED5AF0
0000773e7dfd0a96  jmp 0x0000773E7DFD0A05
0000773e7dfd0a9b  int3
0000773e7dfd0a9c  nop [rax], eax
0000773e7dfd0aa0  mov rax, [r15+0xF8]
0000773e7dfd0aa7  lea r14, [rax+0xD0]
0000773e7dfd0aae  mov [r15], r14
0000773e7dfd0ab1  lea r14, [rax+0x148]
0000773e7dfd0ab8  mov [r15+0x08], r14
0000773e7dfd0abc  mov qword ptr [r15+0x10], 0x01
0000773e7dfd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
0000773e7dfd0acf  mov r14d, [r15+0x320]
0000773e7dfd0ad6  mov eax, 0x4102C8
0000773e7dfd0adb  mov rcx, 0x773E7DFD0B40
0000773e7dfd0ae5  mov [r15+r14*8+0x328], rax
0000773e7dfd0aed  mov [r15+r14*8+0x368], rcx
0000773e7dfd0af5  add r14d, 0x01
0000773e7dfd0af9  and r14d, 0x07
0000773e7dfd0afd  mov [r15+0x320], r14d
0000773e7dfd0b04  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0b0c  jz 0x0000773E7DFCED70
0000773e7dfd0b12  nop [rax+rax*1], ax
0000773e7dfd0b1b  nop [rax+rax*1], eax
0000773e7dfd0b23  mov eax, 0x4106BC
0000773e7dfd0b28  mov [r15+0x100], rax
0000773e7dfd0b2f  jmp 0x0000773E7DDFE110
0000773e7dfd0b34  int3
0000773e7dfd0b35  int3
0000773e7dfd0b36  nop [rax+rax*1], ax
0000773e7dfd0b3f  nop
0000773e7dfd0b40  mov rax, [r15+0xF8]
0000773e7dfd0b47  lea r14, [rax+0x138]
0000773e7dfd0b4e  mov rax, [r13+r14*1]
0000773e7dfd0b53  mov [r15+0x40], rax
0000773e7dfd0b57  mov [rsp+0x10], rax
0000773e7dfd0b5c  xor eax, eax
0000773e7dfd0b5e  mov r14, [rsp+0x10]
0000773e7dfd0b63  mov r12d, 0x38
0000773e7dfd0b69  cmp r14, r12
0000773e7dfd0b6c  cmc
0000773e7dfd0b6d  lahf
0000773e7dfd0b6e  seto al
0000773e7dfd0b71  mov [r15+0x108], eax
0000773e7dfd0b78  mov eax, [r15+0x108]
0000773e7dfd0b7f  sahf
0000773e7dfd0b80  jnz 0x0000773E7DFD0BB2
0000773e7dfd0b82  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0b8a  jz 0x0000773E7DFD0BF0
0000773e7dfd0b90  nop [rax+rax*1], ax
0000773e7dfd0b99  nop [rax+rax*1], eax
0000773e7dfd0ba1  mov eax, 0x4102D4
0000773e7dfd0ba6  mov [r15+0x100], rax
0000773e7dfd0bad  jmp 0x0000773E7DDFE110
0000773e7dfd0bb2  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0bba  jz 0x0000773E7DFD0AA0
0000773e7dfd0bc0  nop [rax+rax*1], ax
0000773e7dfd0bc9  nop [rax+rax*1], eax
0000773e7dfd0bd1  mov eax, 0x4102B8
0000773e7dfd0bd6  mov [r15+0x100], rax
0000773e7dfd0bdd  jmp 0x0000773E7DDFE110
0000773e7dfd0be2  int3
0000773e7dfd0be3  call 0x0000773E7DED59C0
0000773e7dfd0be8  jmp 0x0000773E7DFD0B53
0000773e7dfd0bed  int3
0000773e7dfd0bee  nop
0000773e7dfd0bf0  mov rax, [r15+0x98]
0000773e7dfd0bf7  rorx r14, rax, 0x3D
0000773e7dfd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
0000773e7dfd0c01  mov rax, [r15+0xF8]
0000773e7dfd0c08  lea r12, [rax+0xD0]
0000773e7dfd0c0f  mov [r15], r12
0000773e7dfd0c12  lea r12, [rax+0x140]
0000773e7dfd0c19  mov [r15+0x08], r12
0000773e7dfd0c1d  mov qword ptr [r15+0x10], 0x08
0000773e7dfd0c25  bswap r14
0000773e7dfd0c28  mov [r15+0x40], r14
0000773e7dfd0c2c  lea r12, [rax+0x140]
0000773e7dfd0c33  mov [r13+r12*1], r14
0000773e7dfd0c38  mov qword ptr [r15+0xF0], 0x4102F0
0000773e7dfd0c43  mov r14d, [r15+0x320]
0000773e7dfd0c4a  mov eax, 0x4102F0
0000773e7dfd0c4f  mov rcx, 0x773E7DFD0CC0
0000773e7dfd0c59  mov [r15+r14*8+0x328], rax
0000773e7dfd0c61  mov [r15+r14*8+0x368], rcx
0000773e7dfd0c69  add r14d, 0x01
0000773e7dfd0c6d  and r14d, 0x07
0000773e7dfd0c71  mov [r15+0x320], r14d
0000773e7dfd0c78  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0c80  jz 0x0000773E7DFCED70
0000773e7dfd0c86  nop [rax+rax*1], ax
0000773e7dfd0c8f  nop [rax+rax*1], eax
0000773e7dfd0c97  mov eax, 0x4106BC
0000773e7dfd0c9c  mov [r15+0x100], rax
0000773e7dfd0ca3  jmp 0x0000773E7DDFE110
0000773e7dfd0ca8  int3
0000773e7dfd0ca9  call 0x0000773E7DEC3FE0
0000773e7dfd0cae  jmp 0x0000773E7DFD0C38
0000773e7dfd0cb3  int3
0000773e7dfd0cb4  nop [rax+rax*1], ax
0000773e7dfd0cbd  nop [rax], eax
0000773e7dfd0cc0  mov rax, [r15+0xF8]
0000773e7dfd0cc7  lea r14, [rax+0xD0]
0000773e7dfd0cce  mov r12d, [r13+r14*1]
0000773e7dfd0cd3  lea r14, [rax+0xD4]
0000773e7dfd0cda  mov r11d, [r13+r14*1]
0000773e7dfd0cdf  lea r14, [rax+0xD8]
0000773e7dfd0ce6  mov r10d, [r13+r14*1]
0000773e7dfd0ceb  lea r14, [rax+0xDC]
0000773e7dfd0cf2  mov r9d, [r13+r14*1]
0000773e7dfd0cf7  mov qword ptr [r15+0x48], 0x430C20
0000773e7dfd0cff  mov qword ptr [r15+0xA0], 0x00
0000773e7dfd0d0a  bswap r12d
0000773e7dfd0d0d  bswap r11d
0000773e7dfd0d10  mov qword ptr [r15+0x98], 0x430D8C
0000773e7dfd0d1b  mov r14d, 0x430C20
0000773e7dfd0d21  mov [r13+r14*1], r12d
0000773e7dfd0d26  mov r14d, 0x430C24
0000773e7dfd0d2c  mov [r13+r14*1], r11d
0000773e7dfd0d31  bswap r10d
0000773e7dfd0d34  bswap r9d
0000773e7dfd0d37  lea r14, [rax+0xE0]
0000773e7dfd0d3e  mov r12d, [r13+r14*1]
0000773e7dfd0d43  lea r14, [rax+0xE4]
0000773e7dfd0d4a  mov r11d, [r13+r14*1]
0000773e7dfd0d4f  mov r14d, 0x430C28
0000773e7dfd0d55  mov [r13+r14*1], r10d
0000773e7dfd0d5a  mov r14d, 0x430C2C
0000773e7dfd0d60  mov [r13+r14*1], r9d
0000773e7dfd0d65  bswap r12d
0000773e7dfd0d68  bswap r11d
0000773e7dfd0d6b  mov [rsp+0x10], r11d
0000773e7dfd0d70  mov r11d, r11d
0000773e7dfd0d73  mov [r15+0x58], r11
0000773e7dfd0d77  lea r14, [rax+0xE8]
0000773e7dfd0d7e  mov r11d, [r13+r14*1]
0000773e7dfd0d83  lea r14, [rax+0xEC]
0000773e7dfd0d8a  mov eax, [r13+r14*1]
0000773e7dfd0d8f  mov [rsp+0x20], eax
0000773e7dfd0d93  mov eax, eax
0000773e7dfd0d95  mov [r15+0x60], rax
0000773e7dfd0d99  mov eax, 0x430C30
0000773e7dfd0d9e  mov [r13+rax*1], r12d
0000773e7dfd0da3  mov eax, 0x430C34
0000773e7dfd0da8  mov r14d, [rsp+0x10]
0000773e7dfd0dad  mov [r13+rax*1], r14d
0000773e7dfd0db2  bswap r11d
0000773e7dfd0db5  mov [rsp+0x10], r11d
0000773e7dfd0dba  mov r11d, r11d
0000773e7dfd0dbd  mov [r15+0x40], r11
0000773e7dfd0dc1  mov eax, [rsp+0x20]
0000773e7dfd0dc5  bswap eax
0000773e7dfd0dc7  mov [rsp+0x20], eax
0000773e7dfd0dcb  mov eax, eax
0000773e7dfd0dcd  mov [r15+0x50], rax
0000773e7dfd0dd1  mov eax, 0x430C38
0000773e7dfd0dd6  mov r14d, [rsp+0x10]
0000773e7dfd0ddb  mov [r13+rax*1], r14d
0000773e7dfd0de0  mov eax, 0x430C3C
0000773e7dfd0de5  mov r14d, [rsp+0x20]
0000773e7dfd0dea  mov [r13+rax*1], r14d
0000773e7dfd0def  mov eax, [r15+0xA0]
0000773e7dfd0df6  lea r14d, [eax+0x11]
0000773e7dfd0dfb  mov r14d, r14d
0000773e7dfd0dfe  mov [r15], r14
0000773e7dfd0e01  mov qword ptr [r15+0xF0], 0x41034C
0000773e7dfd0e0c  mov r14d, [r15+0x320]
0000773e7dfd0e13  mov eax, 0x41034C
0000773e7dfd0e18  mov rcx, 0x773E7DFD0F90
0000773e7dfd0e22  mov [r15+r14*8+0x328], rax
0000773e7dfd0e2a  mov [r15+r14*8+0x368], rcx
0000773e7dfd0e32  add r14d, 0x01
0000773e7dfd0e36  and r14d, 0x07
0000773e7dfd0e3a  mov [r15+0x320], r14d
0000773e7dfd0e41  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0e49  jz 0x0000773E7DFD0F20
0000773e7dfd0e4f  nop [rax+rax*1], ax
0000773e7dfd0e58  nop [rax+rax*1], eax
0000773e7dfd0e60  mov eax, 0x410938
0000773e7dfd0e65  mov [r15+0x100], rax
0000773e7dfd0e6c  jmp 0x0000773E7DDFE110
0000773e7dfd0e71  int3
0000773e7dfd0e72  call 0x0000773E7DEE26A0
0000773e7dfd0e77  jmp 0x0000773E7DFD0CD3
0000773e7dfd0e7c  call 0x0000773E7DEE1430
0000773e7dfd0e81  jmp 0x0000773E7DFD0CDF
0000773e7dfd0e86  call 0x0000773E7DEE01C0
0000773e7dfd0e8b  jmp 0x0000773E7DFD0CEB
0000773e7dfd0e90  call 0x0000773E7DEDEF50
0000773e7dfd0e95  jmp 0x0000773E7DFD0CF7
0000773e7dfd0e9a  call 0x0000773E7DEE2BA0
0000773e7dfd0e9f  jmp 0x0000773E7DFD0D26
0000773e7dfd0ea4  call 0x0000773E7DEE1920
0000773e7dfd0ea9  jmp 0x0000773E7DFD0D31
0000773e7dfd0eae  call 0x0000773E7DEE26A0
0000773e7dfd0eb3  jmp 0x0000773E7DFD0D43
0000773e7dfd0eb8  call 0x0000773E7DEE1430
0000773e7dfd0ebd  jmp 0x0000773E7DFD0D4F
0000773e7dfd0ec2  call 0x0000773E7DEE06B0
0000773e7dfd0ec7  jmp 0x0000773E7DFD0D5A
0000773e7dfd0ecc  call 0x0000773E7DEDF440
0000773e7dfd0ed1  jmp 0x0000773E7DFD0D65
0000773e7dfd0ed6  call 0x0000773E7DEE1430
0000773e7dfd0edb  jmp 0x0000773E7DFD0D83
0000773e7dfd0ee0  call 0x0000773E7DED5890
0000773e7dfd0ee5  jmp 0x0000773E7DFD0D8F
0000773e7dfd0eea  call 0x0000773E7DE0BAE0
0000773e7dfd0eef  jmp 0x0000773E7DFD0DA3
0000773e7dfd0ef4  call 0x0000773E7DE0DFE0
0000773e7dfd0ef9  jmp 0x0000773E7DFD0DB2
0000773e7dfd0efe  call 0x0000773E7DE0DFE0
0000773e7dfd0f03  jmp 0x0000773E7DFD0DE0
0000773e7dfd0f08  call 0x0000773E7DE0DFE0
0000773e7dfd0f0d  jmp 0x0000773E7DFD0DEF
0000773e7dfd0f12  int3
0000773e7dfd0f13  nop [rax+rax*1], ax
0000773e7dfd0f1c  nop [rax], eax
0000773e7dfd0f20  mov eax, [r15]
0000773e7dfd0f23  mov [rsp+0x10], eax
0000773e7dfd0f27  shr eax, 0x10
0000773e7dfd0f2a  mov r14d, [rsp+0x10]
0000773e7dfd0f2f  xor r14d, eax
0000773e7dfd0f32  imul r14d, r14d, 0x7FEB352D
0000773e7dfd0f39  mov eax, 0x846CA68B
0000773e7dfd0f3e  mov eax, eax
0000773e7dfd0f40  mov [r15+0x48], rax
0000773e7dfd0f44  mov [rsp+0x10], r14d
0000773e7dfd0f49  shr r14d, 0x0F
0000773e7dfd0f4d  mov eax, [rsp+0x10]
0000773e7dfd0f51  xor eax, r14d
0000773e7dfd0f54  imul eax, eax, 0x846CA68B
0000773e7dfd0f5a  mov [rsp+0x10], eax
0000773e7dfd0f5e  mov eax, eax
0000773e7dfd0f60  mov [r15+0x40], rax
0000773e7dfd0f64  mov eax, [rsp+0x10]
0000773e7dfd0f68  shr eax, 0x10
0000773e7dfd0f6b  mov r14d, [rsp+0x10]
0000773e7dfd0f70  xor r14d, eax
0000773e7dfd0f73  mov r14d, r14d
0000773e7dfd0f76  mov [r15], r14
0000773e7dfd0f79  mov rax, [r15+0xF0]
0000773e7dfd0f80  mov [r15+0x100], rax
0000773e7dfd0f87  jmp 0x0000773E7DFCE5C0
0000773e7dfd0f8c  int3
0000773e7dfd0f8d  int3
0000773e7dfd0f8e  nop
0000773e7dfd0f90  mov rax, [r15+0xA0]
0000773e7dfd0f97  mov [rsp+0x10], rax
0000773e7dfd0f9c  shl rax, 0x02
0000773e7dfd0fa0  mov r14, [r15+0x98]
0000773e7dfd0fa7  lea r12, [r14+rax*1]
0000773e7dfd0fab  mov eax, [r15]
0000773e7dfd0fae  mov [r13+r12*1], eax
0000773e7dfd0fb3  mov rax, [rsp+0x10]
0000773e7dfd0fb8  lea r14, [rax+0x01]
0000773e7dfd0fbc  mov [r15+0xA0], r14
0000773e7dfd0fc3  xor eax, eax
0000773e7dfd0fc5  mov r12d, 0x400
0000773e7dfd0fcb  cmp r14, r12
0000773e7dfd0fce  cmc
0000773e7dfd0fcf  lahf
0000773e7dfd0fd0  seto al
0000773e7dfd0fd3  mov [r15+0x108], eax
0000773e7dfd0fda  mov eax, [r15+0x108]
0000773e7dfd0fe1  sahf
0000773e7dfd0fe2  jnz 0x0000773E7DFD1014
0000773e7dfd0fe4  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd0fec  jz 0x0000773E7DFD10E0
0000773e7dfd0ff2  nop [rax+rax*1], ax
0000773e7dfd0ffb  nop [rax+rax*1], eax
0000773e7dfd1003  mov eax, 0x41035C
0000773e7dfd1008  mov [r15+0x100], rax
0000773e7dfd100f  jmp 0x0000773E7DDFE110
0000773e7dfd1014  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd101c  jz 0x0000773E7DFD1050
0000773e7dfd1022  nop [rax+rax*1], ax
0000773e7dfd102b  nop [rax+rax*1], eax
0000773e7dfd1033  mov eax, 0x410344
0000773e7dfd1038  mov [r15+0x100], rax
0000773e7dfd103f  jmp 0x0000773E7DDFE110
0000773e7dfd1044  int3
0000773e7dfd1045  call 0x0000773E7DEB4B70
0000773e7dfd104a  jmp 0x0000773E7DFD0FB3
0000773e7dfd104f  int3
0000773e7dfd1050  mov eax, [r15+0xA0]
0000773e7dfd1057  lea r14d, [eax+0x11]
0000773e7dfd105c  mov r14d, r14d
0000773e7dfd105f  mov [r15], r14
0000773e7dfd1062  mov qword ptr [r15+0xF0], 0x41034C
0000773e7dfd106d  mov r14d, [r15+0x320]
0000773e7dfd1074  mov eax, 0x41034C
0000773e7dfd1079  mov rcx, 0x773E7DFD0F90
0000773e7dfd1083  mov [r15+r14*8+0x328], rax
0000773e7dfd108b  mov [r15+r14*8+0x368], rcx
0000773e7dfd1093  add r14d, 0x01
0000773e7dfd1097  and r14d, 0x07
0000773e7dfd109b  mov [r15+0x320], r14d
0000773e7dfd10a2  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd10aa  jz 0x0000773E7DFD0F20
0000773e7dfd10b0  nop [rax+rax*1], ax
0000773e7dfd10b9  nop [rax+rax*1], eax
0000773e7dfd10c1  mov eax, 0x410938
0000773e7dfd10c6  mov [r15+0x100], rax
0000773e7dfd10cd  jmp 0x0000773E7DDFE110
0000773e7dfd10d2  int3
0000773e7dfd10d3  int3
0000773e7dfd10d4  nop [rax+rax*1], ax
0000773e7dfd10dd  nop [rax], eax
0000773e7dfd10e0  mov qword ptr [r15+0x40], 0x01
0000773e7dfd10e8  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd10f0  jz 0x0000773E7DFD1120
0000773e7dfd10f6  nop [rax+rax*1], ax
0000773e7dfd10ff  nop [rax+rax*1], eax
0000773e7dfd1107  mov eax, 0x410378
0000773e7dfd110c  mov [r15+0x100], rax
0000773e7dfd1113  jmp 0x0000773E7DDFE110
0000773e7dfd1118  int3
0000773e7dfd1119  int3
0000773e7dfd111a  nop [rax+rax*1], ax
0000773e7dfd1120  mov rax, [r15+0x40]
0000773e7dfd1124  mov [rsp+0x10], rax
0000773e7dfd1129  shl rax, 0x02
0000773e7dfd112d  mov r14, [r15+0x98]
0000773e7dfd1134  lea r12, [r14+rax*1]
0000773e7dfd1138  mov eax, [r13+r12*1]
0000773e7dfd113d  mov [rsp+0x20], eax
0000773e7dfd1141  mov eax, eax
0000773e7dfd1143  mov [r15+0x48], rax
0000773e7dfd1147  mov rax, [rsp+0x10]
0000773e7dfd114c  mov [r15+0x50], rax
0000773e7dfd1150  mov eax, [r15+0x50]
0000773e7dfd1154  lea r12d, [eax-0x01]
0000773e7dfd1159  mov r12d, r12d
0000773e7dfd115c  mov [r15+0x58], r12
0000773e7dfd1160  mov rax, [r15+0x58]
0000773e7dfd1164  mov r12d, eax
0000773e7dfd1167  mov r12d, r12d
0000773e7dfd116a  shl r12, 0x02
0000773e7dfd116e  lea rax, [r14+r12*1]
0000773e7dfd1172  mov r14d, [r13+rax*1]
0000773e7dfd1177  mov [rsp+0x10], r14d
0000773e7dfd117c  mov r14d, r14d
0000773e7dfd117f  mov [r15+0x60], r14
0000773e7dfd1183  xor eax, eax
0000773e7dfd1185  mov r14d, [rsp+0x10]
0000773e7dfd118a  mov r12d, [rsp+0x20]
0000773e7dfd118f  cmp r14d, r12d
0000773e7dfd1192  cmc
0000773e7dfd1193  lahf
0000773e7dfd1194  seto al
0000773e7dfd1197  mov [r15+0x108], eax
0000773e7dfd119e  mov eax, [r15+0x108]
0000773e7dfd11a5  sahf
0000773e7dfd11a6  cmc
0000773e7dfd11a7  jbe 0x0000773E7DFD11D9
0000773e7dfd11a9  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd11b1  jz 0x0000773E7DFD1220
0000773e7dfd11b7  nop [rax+rax*1], ax
0000773e7dfd11c0  nop [rax+rax*1], eax
0000773e7dfd11c8  mov eax, 0x410390
0000773e7dfd11cd  mov [r15+0x100], rax
0000773e7dfd11d4  jmp 0x0000773E7DDFE110
0000773e7dfd11d9  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd11e1  jz 0x0000773E7DFD14C0
0000773e7dfd11e7  nop [rax+rax*1], ax
0000773e7dfd11f0  nop [rax+rax*1], eax
0000773e7dfd11f8  mov eax, 0x410368
0000773e7dfd11fd  mov [r15+0x100], rax
0000773e7dfd1204  jmp 0x0000773E7DDFE110
0000773e7dfd1209  int3
0000773e7dfd120a  call 0x0000773E7DEB4690
0000773e7dfd120f  jmp 0x0000773E7DFD113D
0000773e7dfd1214  call 0x0000773E7DE0DAE0
0000773e7dfd1219  jmp 0x0000773E7DFD1177
0000773e7dfd121e  int3
0000773e7dfd121f  nop
0000773e7dfd1220  mov rax, [r15+0x50]
0000773e7dfd1224  mov [rsp+0x10], rax
0000773e7dfd1229  shl rax, 0x02
0000773e7dfd122d  mov r14, [r15+0x98]
0000773e7dfd1234  lea r12, [r14+rax*1]
0000773e7dfd1238  mov eax, [r15+0x60]
0000773e7dfd123c  mov [r13+r12*1], eax
0000773e7dfd1241  mov rax, [rsp+0x10]
0000773e7dfd1246  lea r14, [rax-0x01]
0000773e7dfd124a  mov [r15+0x50], r14
0000773e7dfd124e  mov rax, [r15+0x58]
0000773e7dfd1252  test rax, rax
0000773e7dfd1255  setz al
0000773e7dfd1258  movzx rax, al
0000773e7dfd125c  mov [rsp+0x414], al
0000773e7dfd1263  cmp byte ptr [rsp+0x414], 0x00
0000773e7dfd126b  jz 0x0000773E7DFD129D
0000773e7dfd126d  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd1275  jz 0x0000773E7DFD12E0
0000773e7dfd127b  nop [rax+rax*1], ax
0000773e7dfd1284  nop [rax+rax*1], eax
0000773e7dfd128c  mov eax, 0x41039C
0000773e7dfd1291  mov [r15+0x100], rax
0000773e7dfd1298  jmp 0x0000773E7DDFE110
0000773e7dfd129d  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd12a5  jz 0x0000773E7DFD13E0
0000773e7dfd12ab  nop [rax+rax*1], ax
0000773e7dfd12b4  nop [rax+rax*1], eax
0000773e7dfd12bc  mov eax, 0x410380
0000773e7dfd12c1  mov [r15+0x100], rax
0000773e7dfd12c8  jmp 0x0000773E7DDFE110
0000773e7dfd12cd  int3
0000773e7dfd12ce  call 0x0000773E7DEB4B70
0000773e7dfd12d3  jmp 0x0000773E7DFD1241
0000773e7dfd12d8  int3
0000773e7dfd12d9  nop [rax], eax
0000773e7dfd12e0  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd12e8  jz 0x0000773E7DFD1320
0000773e7dfd12ee  nop [rax+rax*1], ax
0000773e7dfd12f7  nop [rax+rax*1], eax
0000773e7dfd12ff  mov eax, 0x410364
0000773e7dfd1304  mov [r15+0x100], rax
0000773e7dfd130b  jmp 0x0000773E7DDFE110
0000773e7dfd1310  int3
0000773e7dfd1311  int3
0000773e7dfd1312  nop [rax+rax*1], ax
0000773e7dfd131b  nop [rax+rax*1], eax
0000773e7dfd1320  mov qword ptr [r15+0x50], 0x00
0000773e7dfd1328  mov rax, [r15+0x40]
0000773e7dfd132c  lea r14, [rax+0x01]
0000773e7dfd1330  mov [r15+0x40], r14
0000773e7dfd1334  mov rax, [r15+0x98]
0000773e7dfd133b  mov r12d, [r15+0x48]
0000773e7dfd133f  mov [r13+rax*1], r12d
0000773e7dfd1344  xor eax, eax
0000773e7dfd1346  mov r12d, 0x400
0000773e7dfd134c  cmp r14, r12
0000773e7dfd134f  cmc
0000773e7dfd1350  lahf
0000773e7dfd1351  seto al
0000773e7dfd1354  mov [r15+0x108], eax
0000773e7dfd135b  mov eax, [r15+0x108]
0000773e7dfd1362  sahf
0000773e7dfd1363  jz 0x0000773E7DFD1395
0000773e7dfd1365  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd136d  jz 0x0000773E7DFD1120
0000773e7dfd1373  nop [rax+rax*1], ax
0000773e7dfd137c  nop [rax+rax*1], eax
0000773e7dfd1384  mov eax, 0x410378
0000773e7dfd1389  mov [r15+0x100], rax
0000773e7dfd1390  jmp 0x0000773E7DDFE110
0000773e7dfd1395  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd139d  jz 0x0000773E7DFD1580
0000773e7dfd13a3  nop [rax+rax*1], ax
0000773e7dfd13ac  nop [rax+rax*1], eax
0000773e7dfd13b4  mov eax, 0x4103A0
0000773e7dfd13b9  mov [r15+0x100], rax
0000773e7dfd13c0  jmp 0x0000773E7DDFE110
0000773e7dfd13c5  int3
0000773e7dfd13c6  call 0x0000773E7DE0BAE0
0000773e7dfd13cb  jmp 0x0000773E7DFD1344
0000773e7dfd13d0  int3
0000773e7dfd13d1  nop [rax+rax*1], ax
0000773e7dfd13da  nop [rax+rax*1], ax
0000773e7dfd13e0  mov eax, [r15+0x50]
0000773e7dfd13e4  lea r14d, [eax-0x01]
0000773e7dfd13e9  mov r14d, r14d
0000773e7dfd13ec  mov [r15+0x58], r14
0000773e7dfd13f0  mov rax, [r15+0x58]
0000773e7dfd13f4  mov r14d, eax
0000773e7dfd13f7  mov r14d, r14d
0000773e7dfd13fa  shl r14, 0x02
0000773e7dfd13fe  mov rax, [r15+0x98]
0000773e7dfd1405  lea r12, [rax+r14*1]
0000773e7dfd1409  mov eax, [r13+r12*1]
0000773e7dfd140e  mov [rsp+0x10], eax
0000773e7dfd1412  mov eax, eax
0000773e7dfd1414  mov [r15+0x60], rax
0000773e7dfd1418  mov eax, [r15+0x48]
0000773e7dfd141c  mov [rsp+0x20], eax
0000773e7dfd1420  xor eax, eax
0000773e7dfd1422  mov r14d, [rsp+0x10]
0000773e7dfd1427  mov r12d, [rsp+0x20]
0000773e7dfd142c  cmp r14d, r12d
0000773e7dfd142f  cmc
0000773e7dfd1430  lahf
0000773e7dfd1431  seto al
0000773e7dfd1434  mov [r15+0x108], eax
0000773e7dfd143b  mov eax, [r15+0x108]
0000773e7dfd1442  sahf
0000773e7dfd1443  cmc
0000773e7dfd1444  jbe 0x0000773E7DFD1476
0000773e7dfd1446  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd144e  jz 0x0000773E7DFD1220
0000773e7dfd1454  nop [rax+rax*1], ax
0000773e7dfd145d  nop [rax+rax*1], eax
0000773e7dfd1465  mov eax, 0x410390
0000773e7dfd146a  mov [r15+0x100], rax
0000773e7dfd1471  jmp 0x0000773E7DDFE110
0000773e7dfd1476  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd147e  jz 0x0000773E7DFD14C0
0000773e7dfd1484  nop [rax+rax*1], ax
0000773e7dfd148d  nop [rax+rax*1], eax
0000773e7dfd1495  mov eax, 0x410368
0000773e7dfd149a  mov [r15+0x100], rax
0000773e7dfd14a1  jmp 0x0000773E7DDFE110
0000773e7dfd14a6  int3
0000773e7dfd14a7  call 0x0000773E7DEB4690
0000773e7dfd14ac  jmp 0x0000773E7DFD140E
0000773e7dfd14b1  int3
0000773e7dfd14b2  nop [rax+rax*1], ax
0000773e7dfd14bb  nop [rax+rax*1], eax
0000773e7dfd14c0  mov rax, [r15+0x40]
0000773e7dfd14c4  lea r14, [rax+0x01]
0000773e7dfd14c8  mov [r15+0x40], r14
0000773e7dfd14cc  mov rax, [r15+0x50]
0000773e7dfd14d0  mov r12d, eax
0000773e7dfd14d3  mov r12d, r12d
0000773e7dfd14d6  shl r12, 0x02
0000773e7dfd14da  mov rax, [r15+0x98]
0000773e7dfd14e1  lea r11, [rax+r12*1]
0000773e7dfd14e5  mov eax, [r15+0x48]
0000773e7dfd14e9  mov [r13+r11*1], eax
0000773e7dfd14ee  xor eax, eax
0000773e7dfd14f0  mov r12d, 0x400
0000773e7dfd14f6  cmp r14, r12
0000773e7dfd14f9  cmc
0000773e7dfd14fa  lahf
0000773e7dfd14fb  seto al
0000773e7dfd14fe  mov [r15+0x108], eax
0000773e7dfd1505  mov eax, [r15+0x108]
0000773e7dfd150c  sahf
0000773e7dfd150d  jz 0x0000773E7DFD153F
0000773e7dfd150f  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd1517  jz 0x0000773E7DFD1120
0000773e7dfd151d  nop [rax+rax*1], ax
0000773e7dfd1526  nop [rax+rax*1], eax
0000773e7dfd152e  mov eax, 0x410378
0000773e7dfd1533  mov [r15+0x100], rax
0000773e7dfd153a  jmp 0x0000773E7DDFE110
0000773e7dfd153f  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd1547  jz 0x0000773E7DFD1580
0000773e7dfd154d  nop [rax+rax*1], ax
0000773e7dfd1556  nop [rax+rax*1], eax
0000773e7dfd155e  mov eax, 0x4103A0
0000773e7dfd1563  mov [r15+0x100], rax
0000773e7dfd156a  jmp 0x0000773E7DDFE110
0000773e7dfd156f  int3
0000773e7dfd1570  call 0x0000773E7DEA4270
0000773e7dfd1575  jmp 0x0000773E7DFD14EE
0000773e7dfd157a  int3
0000773e7dfd157b  nop [rax+rax*1], eax
0000773e7dfd1580  mov qword ptr [r15+0x40], 0x430000
0000773e7dfd1588  mov eax, 0x430C40
0000773e7dfd158d  mov r14, [r13+rax*1]
0000773e7dfd1592  mov rax, [r15+0x98]
0000773e7dfd1599  mov r12d, [r13+rax*1]
0000773e7dfd159e  lea r11, [rax+0x04]
0000773e7dfd15a2  mov eax, [r13+r11*1]
0000773e7dfd15a7  mov r12d, r12d
0000773e7dfd15aa  mov [r15+0x68], r12
0000773e7dfd15ae  mov eax, eax
0000773e7dfd15b0  mov [r15+0x60], rax
0000773e7dfd15b4  mov rax, [r15+0x68]
0000773e7dfd15b8  mov [r15+0x68], rax
0000773e7dfd15bc  mov qword ptr [r15+0x58], 0x02
0000773e7dfd15c4  mov [rsp+0x10], rax
0000773e7dfd15c9  xor eax, eax
0000773e7dfd15cb  mov r12d, 0x02
0000773e7dfd15d1  mov r11d, 0x400
0000773e7dfd15d7  cmp r12, r11
0000773e7dfd15da  cmc
0000773e7dfd15db  lahf
0000773e7dfd15dc  seto al
0000773e7dfd15df  mov [r15+0x108], eax
0000773e7dfd15e6  mov rax, [r15+0x60]
0000773e7dfd15ea  mov r12d, 0x02
0000773e7dfd15f0  imul rax, r12
0000773e7dfd15f4  mov [r15+0x50], rax
0000773e7dfd15f8  mov rax, [rsp+0x10]
0000773e7dfd15fd  lea r12, [rax+r14*1]
0000773e7dfd1601  mov [r15+0x48], r12
0000773e7dfd1605  mov eax, [r15+0x108]
0000773e7dfd160c  sahf
0000773e7dfd160d  jnz 0x0000773E7DFD163F
0000773e7dfd160f  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd1617  jz 0x0000773E7DFD17B0
0000773e7dfd161d  nop [rax+rax*1], ax
0000773e7dfd1626  nop [rax+rax*1], eax
0000773e7dfd162e  mov eax, 0x4103D0
0000773e7dfd1633  mov [r15+0x100], rax
0000773e7dfd163a  jmp 0x0000773E7DDFE110
0000773e7dfd163f  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd1647  jz 0x0000773E7DFD1690
0000773e7dfd164d  nop [rax+rax*1], ax
0000773e7dfd1656  nop [rax+rax*1], eax
0000773e7dfd165e  mov eax, 0x4103B0
0000773e7dfd1663  mov [r15+0x100], rax
0000773e7dfd166a  jmp 0x0000773E7DDFE110
0000773e7dfd166f  int3
0000773e7dfd1670  call 0x0000773E7DE0DC20
0000773e7dfd1675  jmp 0x0000773E7DFD1592
0000773e7dfd167a  call 0x0000773E7DE0B5E0
0000773e7dfd167f  jmp 0x0000773E7DFD159E
0000773e7dfd1684  call 0x0000773E7DEA3D90
0000773e7dfd1689  jmp 0x0000773E7DFD15A7
0000773e7dfd168e  int3
0000773e7dfd168f  nop
0000773e7dfd1690  mov rax, [r15+0x98]
0000773e7dfd1697  mov r14, [r15+0x58]
0000773e7dfd169b  mov [rsp+0x10], r14
0000773e7dfd16a0  shl r14, 0x02
0000773e7dfd16a4  lea r12, [rax+r14*1]
0000773e7dfd16a8  mov eax, [r13+r12*1]
0000773e7dfd16ad  lea r14, [r12+0x04]
0000773e7dfd16b2  mov r12d, [r13+r14*1]
0000773e7dfd16b7  mov eax, eax
0000773e7dfd16b9  mov [r15+0x68], rax
0000773e7dfd16bd  mov r12d, r12d
0000773e7dfd16c0  mov [r15+0x60], r12
0000773e7dfd16c4  mov rax, [r15+0x68]
0000773e7dfd16c8  mov [rsp+0x20], rax
0000773e7dfd16cd  mov r14, [rsp+0x10]
0000773e7dfd16d2  imul rax, r14
0000773e7dfd16d6  mov r12, [rsp+0x20]
0000773e7dfd16db  lea r11, [r12+rax*1]
0000773e7dfd16df  mov [r15+0x68], r11
0000773e7dfd16e3  lea rax, [r14+0x02]
0000773e7dfd16e7  mov [r15+0x58], rax
0000773e7dfd16eb  mov [rsp+0x10], rax
0000773e7dfd16f0  xor eax, eax
0000773e7dfd16f2  mov r14, [rsp+0x10]
0000773e7dfd16f7  mov r12d, 0x400
0000773e7dfd16fd  cmp r14, r12
0000773e7dfd1700  cmc
0000773e7dfd1701  lahf
0000773e7dfd1702  seto al
0000773e7dfd1705  mov [r15+0x108], eax
0000773e7dfd170c  mov rax, [r15+0x50]
0000773e7dfd1710  mov r12, [r15+0x60]
0000773e7dfd1714  imul r14, r12
0000773e7dfd1718  lea r12, [rax+r14*1]
0000773e7dfd171c  mov [r15+0x50], r12
0000773e7dfd1720  mov rax, [r15+0x48]
0000773e7dfd1724  lea r14, [r11+rax*1]
0000773e7dfd1728  mov [r15+0x48], r14
0000773e7dfd172c  mov eax, [r15+0x108]
0000773e7dfd1733  sahf
0000773e7dfd1734  jnz 0x0000773E7DFD1766
0000773e7dfd1736  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd173e  jz 0x0000773E7DFD17B0
0000773e7dfd1744  nop [rax+rax*1], ax
0000773e7dfd174d  nop [rax+rax*1], eax
0000773e7dfd1755  mov eax, 0x4103D0
0000773e7dfd175a  mov [r15+0x100], rax
0000773e7dfd1761  jmp 0x0000773E7DDFE110
0000773e7dfd1766  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd176e  jz 0x0000773E7DFD1690
0000773e7dfd1774  nop [rax+rax*1], ax
0000773e7dfd177d  nop [rax+rax*1], eax
0000773e7dfd1785  mov eax, 0x4103B0
0000773e7dfd178a  mov [r15+0x100], rax
0000773e7dfd1791  jmp 0x0000773E7DDFE110
0000773e7dfd1796  int3
0000773e7dfd1797  call 0x0000773E7DEB4690
0000773e7dfd179c  jmp 0x0000773E7DFD16AD
0000773e7dfd17a1  call 0x0000773E7DEE26A0
0000773e7dfd17a6  jmp 0x0000773E7DFD16B7
0000773e7dfd17ab  int3
0000773e7dfd17ac  nop [rax], eax
0000773e7dfd17b0  mov qword ptr [r15+0x98], 0x00
0000773e7dfd17bb  mov rax, [r15+0x50]
0000773e7dfd17bf  mov r14, [r15+0x48]
0000773e7dfd17c3  lea r12, [rax+r14*1]
0000773e7dfd17c7  mov [r15+0x48], r12
0000773e7dfd17cb  mov rax, [r15+0x40]
0000773e7dfd17cf  lea r14, [rax+0xC40]
0000773e7dfd17d6  mov [r13+r14*1], r12
0000773e7dfd17db  mov qword ptr [r15], 0x01
0000773e7dfd17e2  mov qword ptr [r15+0xF0], 0x4103E8
0000773e7dfd17ed  mov r14d, [r15+0x320]
0000773e7dfd17f4  mov eax, 0x4103E8
0000773e7dfd17f9  mov rcx, 0x773E7DFD1860
0000773e7dfd1803  mov [r15+r14*8+0x328], rax
0000773e7dfd180b  mov [r15+r14*8+0x368], rcx
0000773e7dfd1813  add r14d, 0x01
0000773e7dfd1817  and r14d, 0x07
0000773e7dfd181b  mov [r15+0x320], r14d
0000773e7dfd1822  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd182a  jz 0x0000773E7DFD0F20
0000773e7dfd1830  nop [rax+rax*1], ax
0000773e7dfd1839  nop [rax+rax*1], eax
0000773e7dfd1841  mov eax, 0x410938
0000773e7dfd1846  mov [r15+0x100], rax
0000773e7dfd184d  jmp 0x0000773E7DDFE110
0000773e7dfd1852  int3
0000773e7dfd1853  call 0x0000773E7DEE2CE0
0000773e7dfd1858  jmp 0x0000773E7DFD17DB
0000773e7dfd185d  int3
0000773e7dfd185e  nop
0000773e7dfd1860  mov eax, [r15+0x98]
0000773e7dfd1867  lea r14d, [eax+0x01]
0000773e7dfd186c  mov [rsp+0x10], r14d
0000773e7dfd1871  mov r14d, r14d
0000773e7dfd1874  mov [r15+0x98], r14
0000773e7dfd187b  xor eax, eax
0000773e7dfd187d  mov r14d, [rsp+0x10]
0000773e7dfd1882  cmp r14d, 0x10000
0000773e7dfd1889  cmc
0000773e7dfd188a  lahf
0000773e7dfd188b  seto al
0000773e7dfd188e  mov [r15+0x108], eax
0000773e7dfd1895  mov eax, [r15+0x108]
0000773e7dfd189c  sahf
0000773e7dfd189d  jnz 0x0000773E7DFD18CF
0000773e7dfd189f  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd18a7  jz 0x0000773E7DFD19A0
0000773e7dfd18ad  nop [rax+rax*1], ax
0000773e7dfd18b6  nop [rax+rax*1], eax
0000773e7dfd18be  mov eax, 0x4103F4
0000773e7dfd18c3  mov [r15+0x100], rax
0000773e7dfd18ca  jmp 0x0000773E7DDFE110
0000773e7dfd18cf  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd18d7  jz 0x0000773E7DFD1910
0000773e7dfd18dd  nop [rax+rax*1], ax
0000773e7dfd18e6  nop [rax+rax*1], eax
0000773e7dfd18ee  mov eax, 0x4103E0
0000773e7dfd18f3  mov [r15+0x100], rax
0000773e7dfd18fa  jmp 0x0000773E7DDFE110
0000773e7dfd18ff  int3
0000773e7dfd1900  int3
0000773e7dfd1901  nop [rax+rax*1], ax
0000773e7dfd190a  nop [rax+rax*1], ax
0000773e7dfd1910  mov eax, [r15]
0000773e7dfd1913  mov r14d, [r15+0x98]
0000773e7dfd191a  lea r12d, [eax+r14d*1]
0000773e7dfd191f  mov r12d, r12d
0000773e7dfd1922  mov [r15], r12
0000773e7dfd1925  mov qword ptr [r15+0xF0], 0x4103E8
0000773e7dfd1930  mov r14d, [r15+0x320]
0000773e7dfd1937  mov eax, 0x4103E8
0000773e7dfd193c  mov rcx, 0x773E7DFD1860
0000773e7dfd1946  mov [r15+r14*8+0x328], rax
0000773e7dfd194e  mov [r15+r14*8+0x368], rcx
0000773e7dfd1956  add r14d, 0x01
0000773e7dfd195a  and r14d, 0x07
0000773e7dfd195e  mov [r15+0x320], r14d
0000773e7dfd1965  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd196d  jz 0x0000773E7DFD0F20
0000773e7dfd1973  nop [rax+rax*1], ax
0000773e7dfd197c  nop [rax+rax*1], eax
0000773e7dfd1984  mov eax, 0x410938
0000773e7dfd1989  mov [r15+0x100], rax
0000773e7dfd1990  jmp 0x0000773E7DDFE110
0000773e7dfd1995  int3
0000773e7dfd1996  int3
0000773e7dfd1997  nop [rax+rax*1], ax
0000773e7dfd19a0  vmovaps xmm1, [0x0000773E7DBFE010]
0000773e7dfd19a8  movq xmm1, xmm1
0000773e7dfd19ac  movaps [r15+0x110], xmm1
0000773e7dfd19b4  mov eax, 0x420AA0
0000773e7dfd19b9  mov r14, [r13+rax*1]
0000773e7dfd19be  movq xmm1, r14
0000773e7dfd19c3  movaps [r15+0x120], xmm1
0000773e7dfd19cb  vmovaps xmm1, [0x0000773E7DBFE020]
0000773e7dfd19d3  movq xmm1, xmm1
0000773e7dfd19d7  movaps [r15+0x140], xmm1
0000773e7dfd19df  vmovaps xmm1, [0x0000773E7DBFE030]
0000773e7dfd19e7  vpbroadcastq xmm1, xmm1
0000773e7dfd19ec  movaps [r15+0x150], xmm1
0000773e7dfd19f4  mov qword ptr [r15+0x40], 0x02
0000773e7dfd19fc  vmovaps xmm15, [0x0000773E7DBFE040]
0000773e7dfd1a04  movq xmm15, xmm15
0000773e7dfd1a09  movaps [r15+0x160], xmm15
0000773e7dfd1a11  vmovaps xmm15, [0x0000773E7DBFE050]
0000773e7dfd1a19  vpbroadcastq xmm15, xmm15
0000773e7dfd1a1e  movaps [r15+0x130], xmm15
0000773e7dfd1a26  mov rax, [r15+0x40]
0000773e7dfd1a2a  vmovq xmm14, rax
0000773e7dfd1a2f  vpbroadcastq xmm14, xmm14
0000773e7dfd1a34  movaps [r15+0x170], xmm14
0000773e7dfd1a3c  mov eax, 0x4209D0
0000773e7dfd1a41  movups xmm13, [r13+rax*1]
0000773e7dfd1a47  mov qword ptr [r15+0x40], 0x431D90
0000773e7dfd1a4f  mov eax, [r15]
0000773e7dfd1a52  mov r14d, 0x430C48
0000773e7dfd1a58  mov [r13+r14*1], eax
0000773e7dfd1a5d  mov qword ptr [r15+0x50], 0x431F90
0000773e7dfd1a65  vpmovqd xmm12, xmm13
0000773e7dfd1a6b  pxor xmm11, xmm11
0000773e7dfd1a70  punpcklqdq xmm12, xmm11
0000773e7dfd1a75  movaps [r15+0x210], xmm12
0000773e7dfd1a7d  movq xmm12, qword ptr [r15+0x140]
0000773e7dfd1a86  movq xmm11, qword ptr [r15+0x120]
0000773e7dfd1a8f  psubd xmm12, xmm11
0000773e7dfd1a94  movq xmm12, xmm12
0000773e7dfd1a99  paddq xmm13, xmm14
0000773e7dfd1a9e  movaps [r15+0x180], xmm13
0000773e7dfd1aa6  movq xmm14, qword ptr [r15+0x160]
0000773e7dfd1aaf  paddd xmm11, xmm14
0000773e7dfd1ab4  movq xmm11, xmm11
0000773e7dfd1ab9  movq xmm11, xmm11
0000773e7dfd1abe  movaps [r15+0x120], xmm11
0000773e7dfd1ac6  pmovzxdq xmm12, xmm12
0000773e7dfd1acc  psllq xmm12, 0x00
0000773e7dfd1ad2  movq xmm14, qword ptr [r15+0x210]
0000773e7dfd1adb  movq xmm13, qword ptr [r15+0x110]
0000773e7dfd1ae4  paddd xmm14, xmm13
0000773e7dfd1ae9  movq xmm14, xmm14
0000773e7dfd1aee  vcvtuqq2pd xmm12, xmm12
0000773e7dfd1af4  pmovzxdq xmm14, xmm14
0000773e7dfd1afa  psllq xmm14, 0x00
0000773e7dfd1b00  vcvtuqq2pd xmm14, xmm14
0000773e7dfd1b06  movaps xmm13, xmm12
0000773e7dfd1b0a  mulpd xmm13, xmm1
0000773e7dfd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
0000773e7dfd1b15  ptest xmm11, xmm11
0000773e7dfd1b1b  jnz 0x0000773E7DFD1C0F
0000773e7dfd1b21  movaps [r15+0x220], xmm13
0000773e7dfd1b29  mov eax, 0x431F90
0000773e7dfd1b2e  movups [r13+rax*1], xmm13
0000773e7dfd1b34  movaps xmm1, xmm14
0000773e7dfd1b38  mulpd xmm1, xmm15
0000773e7dfd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
0000773e7dfd1b42  ptest xmm13, xmm13
0000773e7dfd1b48  jnz 0x0000773E7DFD1D5C
0000773e7dfd1b4e  movaps [r15+0x210], xmm1
0000773e7dfd1b56  mov eax, 0x431D90
0000773e7dfd1b5b  movups [r13+rax*1], xmm1
0000773e7dfd1b61  mov qword ptr [r15+0x48], 0x10
0000773e7dfd1b69  xor eax, eax
0000773e7dfd1b6b  mov r14d, 0x10
0000773e7dfd1b71  mov r12d, 0x200
0000773e7dfd1b77  cmp r14, r12
0000773e7dfd1b7a  cmc
0000773e7dfd1b7b  lahf
0000773e7dfd1b7c  seto al
0000773e7dfd1b7f  mov [r15+0x108], eax
0000773e7dfd1b86  mov eax, [r15+0x108]
0000773e7dfd1b8d  sahf
0000773e7dfd1b8e  jnz 0x0000773E7DFD1BC0
0000773e7dfd1b90  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd1b98  jz 0x0000773E7DFD2300
0000773e7dfd1b9e  nop [rax+rax*1], ax
0000773e7dfd1ba7  nop [rax+rax*1], eax
0000773e7dfd1baf  mov eax, 0x410480
0000773e7dfd1bb4  mov [r15+0x100], rax
0000773e7dfd1bbb  jmp 0x0000773E7DDFE110
0000773e7dfd1bc0  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd1bc8  jz 0x0000773E7DFD1EB0
0000773e7dfd1bce  nop [rax+rax*1], ax
0000773e7dfd1bd7  nop [rax+rax*1], eax
0000773e7dfd1bdf  mov eax, 0x410440
0000773e7dfd1be4  mov [r15+0x100], rax
0000773e7dfd1beb  jmp 0x0000773E7DDFE110
0000773e7dfd1bf0  int3
0000773e7dfd1bf1  call 0x0000773E7DE0DC20
0000773e7dfd1bf6  jmp 0x0000773E7DFD19BE
0000773e7dfd1bfb  call 0x0000773E7DE0C260
0000773e7dfd1c00  jmp 0x0000773E7DFD1A47
0000773e7dfd1c05  call 0x0000773E7DED5D70
0000773e7dfd1c0a  jmp 0x0000773E7DFD1A5D
0000773e7dfd1c0f  sub rsp, 0x08
0000773e7dfd1c13  push rax
0000773e7dfd1c14  push rcx
0000773e7dfd1c15  push rdx
0000773e7dfd1c16  push rdi
0000773e7dfd1c17  push rsi
0000773e7dfd1c18  push r8
0000773e7dfd1c1a  push r9
0000773e7dfd1c1c  push r10
0000773e7dfd1c1e  push r11
0000773e7dfd1c20  sub rsp, 0xF0
0000773e7dfd1c27  vmovaps [rsp], xmm0
0000773e7dfd1c2c  vmovaps [rsp+0x10], xmm1
0000773e7dfd1c32  vmovaps [rsp+0x20], xmm2
0000773e7dfd1c38  vmovaps [rsp+0x30], xmm3
0000773e7dfd1c3e  vmovaps [rsp+0x40], xmm4
0000773e7dfd1c44  vmovaps [rsp+0x50], xmm5
0000773e7dfd1c4a  vmovaps [rsp+0x60], xmm6
0000773e7dfd1c50  vmovaps [rsp+0x70], xmm7
0000773e7dfd1c56  vmovaps [rsp+0x80], xmm8
0000773e7dfd1c5f  vmovaps [rsp+0x90], xmm9
0000773e7dfd1c68  vmovaps [rsp+0xA0], xmm10
0000773e7dfd1c71  vmovaps [rsp+0xB0], xmm11
0000773e7dfd1c7a  vmovaps [rsp+0xC0], xmm12
0000773e7dfd1c83  vmovaps [rsp+0xD0], xmm14
0000773e7dfd1c8c  vmovaps [rsp+0xE0], xmm15
0000773e7dfd1c95  sub rsp, 0x30
0000773e7dfd1c99  movaps [rsp], xmm13
0000773e7dfd1c9e  movaps [rsp+0x10], xmm12
0000773e7dfd1ca4  movaps [rsp+0x20], xmm1
0000773e7dfd1ca9  lea rdi, [rsp]
0000773e7dfd1cad  mov esi, 0x00
0000773e7dfd1cb2  mov rax, 0x567852F34530
0000773e7dfd1cbc  call rax
0000773e7dfd1cbe  movaps xmm13, [rsp]
0000773e7dfd1cc3  add rsp, 0x30
0000773e7dfd1cc7  vmovaps xmm0, [rsp]
0000773e7dfd1ccc  vmovaps xmm1, [rsp+0x10]
0000773e7dfd1cd2  vmovaps xmm2, [rsp+0x20]
0000773e7dfd1cd8  vmovaps xmm3, [rsp+0x30]
0000773e7dfd1cde  vmovaps xmm4, [rsp+0x40]
0000773e7dfd1ce4  vmovaps xmm5, [rsp+0x50]
0000773e7dfd1cea  vmovaps xmm6, [rsp+0x60]
0000773e7dfd1cf0  vmovaps xmm7, [rsp+0x70]
0000773e7dfd1cf6  vmovaps xmm8, [rsp+0x80]
0000773e7dfd1cff  vmovaps xmm9, [rsp+0x90]
0000773e7dfd1d08  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd1d11  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd1d1a  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd1d23  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd1d2c  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd1d35  add rsp, 0xF0
0000773e7dfd1d3c  pop r11
0000773e7dfd1d3e  pop r10
0000773e7dfd1d40  pop r9
0000773e7dfd1d42  pop r8
0000773e7dfd1d44  pop rsi
0000773e7dfd1d45  pop rdi
0000773e7dfd1d46  pop rdx
0000773e7dfd1d47  pop rcx
0000773e7dfd1d48  pop rax
0000773e7dfd1d49  add rsp, 0x08
0000773e7dfd1d4d  jmp 0x0000773E7DFD1B21
0000773e7dfd1d52  call 0x0000773E7DE0C380
0000773e7dfd1d57  jmp 0x0000773E7DFD1B34
0000773e7dfd1d5c  sub rsp, 0x08
0000773e7dfd1d60  push rax
0000773e7dfd1d61  push rcx
0000773e7dfd1d62  push rdx
0000773e7dfd1d63  push rdi
0000773e7dfd1d64  push rsi
0000773e7dfd1d65  push r8
0000773e7dfd1d67  push r9
0000773e7dfd1d69  push r10
0000773e7dfd1d6b  push r11
0000773e7dfd1d6d  sub rsp, 0xF0
0000773e7dfd1d74  vmovaps [rsp], xmm0
0000773e7dfd1d79  vmovaps [rsp+0x10], xmm2
0000773e7dfd1d7f  vmovaps [rsp+0x20], xmm3
0000773e7dfd1d85  vmovaps [rsp+0x30], xmm4
0000773e7dfd1d8b  vmovaps [rsp+0x40], xmm5
0000773e7dfd1d91  vmovaps [rsp+0x50], xmm6
0000773e7dfd1d97  vmovaps [rsp+0x60], xmm7
0000773e7dfd1d9d  vmovaps [rsp+0x70], xmm8
0000773e7dfd1da3  vmovaps [rsp+0x80], xmm9
0000773e7dfd1dac  vmovaps [rsp+0x90], xmm10
0000773e7dfd1db5  vmovaps [rsp+0xA0], xmm11
0000773e7dfd1dbe  vmovaps [rsp+0xB0], xmm12
0000773e7dfd1dc7  vmovaps [rsp+0xC0], xmm13
0000773e7dfd1dd0  vmovaps [rsp+0xD0], xmm14
0000773e7dfd1dd9  vmovaps [rsp+0xE0], xmm15
0000773e7dfd1de2  sub rsp, 0x30
0000773e7dfd1de6  movaps [rsp], xmm1
0000773e7dfd1dea  movaps [rsp+0x10], xmm14
0000773e7dfd1df0  movaps [rsp+0x20], xmm15
0000773e7dfd1df6  lea rdi, [rsp]
0000773e7dfd1dfa  mov esi, 0x00
0000773e7dfd1dff  mov rax, 0x567852F34530
0000773e7dfd1e09  call rax
0000773e7dfd1e0b  movaps xmm1, [rsp]
0000773e7dfd1e0f  add rsp, 0x30
0000773e7dfd1e13  vmovaps xmm0, [rsp]
0000773e7dfd1e18  vmovaps xmm2, [rsp+0x10]
0000773e7dfd1e1e  vmovaps xmm3, [rsp+0x20]
0000773e7dfd1e24  vmovaps xmm4, [rsp+0x30]
0000773e7dfd1e2a  vmovaps xmm5, [rsp+0x40]
0000773e7dfd1e30  vmovaps xmm6, [rsp+0x50]
0000773e7dfd1e36  vmovaps xmm7, [rsp+0x60]
0000773e7dfd1e3c  vmovaps xmm8, [rsp+0x70]
0000773e7dfd1e42  vmovaps xmm9, [rsp+0x80]
0000773e7dfd1e4b  vmovaps xmm10, [rsp+0x90]
0000773e7dfd1e54  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd1e5d  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd1e66  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd1e6f  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd1e78  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd1e81  add rsp, 0xF0
0000773e7dfd1e88  pop r11
0000773e7dfd1e8a  pop r10
0000773e7dfd1e8c  pop r9
0000773e7dfd1e8e  pop r8
0000773e7dfd1e90  pop rsi
0000773e7dfd1e91  pop rdi
0000773e7dfd1e92  pop rdx
0000773e7dfd1e93  pop rcx
0000773e7dfd1e94  pop rax
0000773e7dfd1e95  add rsp, 0x08
0000773e7dfd1e99  jmp 0x0000773E7DFD1B4E
0000773e7dfd1e9e  call 0x0000773E7DDFF540
0000773e7dfd1ea3  jmp 0x0000773E7DFD1B61
0000773e7dfd1ea8  int3
0000773e7dfd1ea9  nop [rax], eax
0000773e7dfd1eb0  movaps xmm1, [r15+0x180]
0000773e7dfd1eb8  vpmovqd xmm15, xmm1
0000773e7dfd1ebe  pxor xmm14, xmm14
0000773e7dfd1ec3  punpcklqdq xmm15, xmm14
0000773e7dfd1ec8  movaps [r15+0x210], xmm15
0000773e7dfd1ed0  movq xmm15, qword ptr [r15+0x140]
0000773e7dfd1ed9  movq xmm14, qword ptr [r15+0x120]
0000773e7dfd1ee2  psubd xmm15, xmm14
0000773e7dfd1ee7  movq xmm15, xmm15
0000773e7dfd1eec  movaps xmm13, [r15+0x170]
0000773e7dfd1ef4  paddq xmm1, xmm13
0000773e7dfd1ef9  movaps [r15+0x180], xmm1
0000773e7dfd1f01  movq xmm1, qword ptr [r15+0x160]
0000773e7dfd1f0a  paddd xmm14, xmm1
0000773e7dfd1f0f  movq xmm14, xmm14
0000773e7dfd1f14  movq xmm14, xmm14
0000773e7dfd1f19  movaps [r15+0x120], xmm14
0000773e7dfd1f21  pmovzxdq xmm15, xmm15
0000773e7dfd1f27  psllq xmm15, 0x00
0000773e7dfd1f2d  movq xmm1, qword ptr [r15+0x210]
0000773e7dfd1f36  movq xmm14, qword ptr [r15+0x110]
0000773e7dfd1f3f  paddd xmm1, xmm14
0000773e7dfd1f44  movq xmm1, xmm1
0000773e7dfd1f48  vcvtuqq2pd xmm15, xmm15
0000773e7dfd1f4e  pmovzxdq xmm1, xmm1
0000773e7dfd1f53  psllq xmm1, 0x00
0000773e7dfd1f58  vcvtuqq2pd xmm1, xmm1
0000773e7dfd1f5e  movaps xmm14, [r15+0x150]
0000773e7dfd1f66  movaps xmm13, xmm15
0000773e7dfd1f6a  mulpd xmm13, xmm14
0000773e7dfd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd1f75  ptest xmm12, xmm12
0000773e7dfd1f7b  jnz 0x0000773E7DFD205E
0000773e7dfd1f81  movaps [r15+0x220], xmm13
0000773e7dfd1f89  mov rax, [r15+0x48]
0000773e7dfd1f8d  mov r14, [r15+0x50]
0000773e7dfd1f91  lea r12, [r14+rax*1]
0000773e7dfd1f95  movups [r13+r12*1], xmm13
0000773e7dfd1f9b  movaps xmm15, [r15+0x130]
0000773e7dfd1fa3  movaps xmm14, xmm1
0000773e7dfd1fa7  mulpd xmm14, xmm15
0000773e7dfd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
0000773e7dfd1fb2  ptest xmm13, xmm13
0000773e7dfd1fb8  jnz 0x0000773E7DFD21AC
0000773e7dfd1fbe  movaps [r15+0x210], xmm14
0000773e7dfd1fc6  mov r14, [r15+0x40]
0000773e7dfd1fca  lea r12, [r14+rax*1]
0000773e7dfd1fce  movups [r13+r12*1], xmm14
0000773e7dfd1fd4  lea r14, [rax+0x10]
0000773e7dfd1fd8  mov [r15+0x48], r14
0000773e7dfd1fdc  xor eax, eax
0000773e7dfd1fde  mov r12d, 0x200
0000773e7dfd1fe4  cmp r14, r12
0000773e7dfd1fe7  cmc
0000773e7dfd1fe8  lahf
0000773e7dfd1fe9  seto al
0000773e7dfd1fec  mov [r15+0x108], eax
0000773e7dfd1ff3  mov eax, [r15+0x108]
0000773e7dfd1ffa  sahf
0000773e7dfd1ffb  jnz 0x0000773E7DFD202D
0000773e7dfd1ffd  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd2005  jz 0x0000773E7DFD2300
0000773e7dfd200b  nop [rax+rax*1], ax
0000773e7dfd2014  nop [rax+rax*1], eax
0000773e7dfd201c  mov eax, 0x410480
0000773e7dfd2021  mov [r15+0x100], rax
0000773e7dfd2028  jmp 0x0000773E7DDFE110
0000773e7dfd202d  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd2035  jz 0x0000773E7DFD1EB0
0000773e7dfd203b  nop [rax+rax*1], ax
0000773e7dfd2044  nop [rax+rax*1], eax
0000773e7dfd204c  mov eax, 0x410440
0000773e7dfd2051  mov [r15+0x100], rax
0000773e7dfd2058  jmp 0x0000773E7DDFE110
0000773e7dfd205d  int3
0000773e7dfd205e  sub rsp, 0x08
0000773e7dfd2062  push rax
0000773e7dfd2063  push rcx
0000773e7dfd2064  push rdx
0000773e7dfd2065  push rdi
0000773e7dfd2066  push rsi
0000773e7dfd2067  push r8
0000773e7dfd2069  push r9
0000773e7dfd206b  push r10
0000773e7dfd206d  push r11
0000773e7dfd206f  sub rsp, 0xF0
0000773e7dfd2076  vmovaps [rsp], xmm0
0000773e7dfd207b  vmovaps [rsp+0x10], xmm1
0000773e7dfd2081  vmovaps [rsp+0x20], xmm2
0000773e7dfd2087  vmovaps [rsp+0x30], xmm3
0000773e7dfd208d  vmovaps [rsp+0x40], xmm4
0000773e7dfd2093  vmovaps [rsp+0x50], xmm5
0000773e7dfd2099  vmovaps [rsp+0x60], xmm6
0000773e7dfd209f  vmovaps [rsp+0x70], xmm7
0000773e7dfd20a5  vmovaps [rsp+0x80], xmm8
0000773e7dfd20ae  vmovaps [rsp+0x90], xmm9
0000773e7dfd20b7  vmovaps [rsp+0xA0], xmm10
0000773e7dfd20c0  vmovaps [rsp+0xB0], xmm11
0000773e7dfd20c9  vmovaps [rsp+0xC0], xmm12
0000773e7dfd20d2  vmovaps [rsp+0xD0], xmm14
0000773e7dfd20db  vmovaps [rsp+0xE0], xmm15
0000773e7dfd20e4  sub rsp, 0x30
0000773e7dfd20e8  movaps [rsp], xmm13
0000773e7dfd20ed  movaps [rsp+0x10], xmm15
0000773e7dfd20f3  movaps [rsp+0x20], xmm14
0000773e7dfd20f9  lea rdi, [rsp]
0000773e7dfd20fd  mov esi, 0x00
0000773e7dfd2102  mov rax, 0x567852F34530
0000773e7dfd210c  call rax
0000773e7dfd210e  movaps xmm13, [rsp]
0000773e7dfd2113  add rsp, 0x30
0000773e7dfd2117  vmovaps xmm0, [rsp]
0000773e7dfd211c  vmovaps xmm1, [rsp+0x10]
0000773e7dfd2122  vmovaps xmm2, [rsp+0x20]
0000773e7dfd2128  vmovaps xmm3, [rsp+0x30]
0000773e7dfd212e  vmovaps xmm4, [rsp+0x40]
0000773e7dfd2134  vmovaps xmm5, [rsp+0x50]
0000773e7dfd213a  vmovaps xmm6, [rsp+0x60]
0000773e7dfd2140  vmovaps xmm7, [rsp+0x70]
0000773e7dfd2146  vmovaps xmm8, [rsp+0x80]
0000773e7dfd214f  vmovaps xmm9, [rsp+0x90]
0000773e7dfd2158  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd2161  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd216a  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd2173  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd217c  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd2185  add rsp, 0xF0
0000773e7dfd218c  pop r11
0000773e7dfd218e  pop r10
0000773e7dfd2190  pop r9
0000773e7dfd2192  pop r8
0000773e7dfd2194  pop rsi
0000773e7dfd2195  pop rdi
0000773e7dfd2196  pop rdx
0000773e7dfd2197  pop rcx
0000773e7dfd2198  pop rax
0000773e7dfd2199  add rsp, 0x08
0000773e7dfd219d  jmp 0x0000773E7DFD1F81
0000773e7dfd21a2  call 0x0000773E7DEC2240
0000773e7dfd21a7  jmp 0x0000773E7DFD1F9B
0000773e7dfd21ac  sub rsp, 0x08
0000773e7dfd21b0  push rax
0000773e7dfd21b1  push rcx
0000773e7dfd21b2  push rdx
0000773e7dfd21b3  push rdi
0000773e7dfd21b4  push rsi
0000773e7dfd21b5  push r8
0000773e7dfd21b7  push r9
0000773e7dfd21b9  push r10
0000773e7dfd21bb  push r11
0000773e7dfd21bd  sub rsp, 0xF0
0000773e7dfd21c4  vmovaps [rsp], xmm0
0000773e7dfd21c9  vmovaps [rsp+0x10], xmm1
0000773e7dfd21cf  vmovaps [rsp+0x20], xmm2
0000773e7dfd21d5  vmovaps [rsp+0x30], xmm3
0000773e7dfd21db  vmovaps [rsp+0x40], xmm4
0000773e7dfd21e1  vmovaps [rsp+0x50], xmm5
0000773e7dfd21e7  vmovaps [rsp+0x60], xmm6
0000773e7dfd21ed  vmovaps [rsp+0x70], xmm7
0000773e7dfd21f3  vmovaps [rsp+0x80], xmm8
0000773e7dfd21fc  vmovaps [rsp+0x90], xmm9
0000773e7dfd2205  vmovaps [rsp+0xA0], xmm10
0000773e7dfd220e  vmovaps [rsp+0xB0], xmm11
0000773e7dfd2217  vmovaps [rsp+0xC0], xmm12
0000773e7dfd2220  vmovaps [rsp+0xD0], xmm13
0000773e7dfd2229  vmovaps [rsp+0xE0], xmm15
0000773e7dfd2232  sub rsp, 0x30
0000773e7dfd2236  movaps [rsp], xmm14
0000773e7dfd223b  movaps [rsp+0x10], xmm1
0000773e7dfd2240  movaps [rsp+0x20], xmm15
0000773e7dfd2246  lea rdi, [rsp]
0000773e7dfd224a  mov esi, 0x00
0000773e7dfd224f  mov rax, 0x567852F34530
0000773e7dfd2259  call rax
0000773e7dfd225b  movaps xmm14, [rsp]
0000773e7dfd2260  add rsp, 0x30
0000773e7dfd2264  vmovaps xmm0, [rsp]
0000773e7dfd2269  vmovaps xmm1, [rsp+0x10]
0000773e7dfd226f  vmovaps xmm2, [rsp+0x20]
0000773e7dfd2275  vmovaps xmm3, [rsp+0x30]
0000773e7dfd227b  vmovaps xmm4, [rsp+0x40]
0000773e7dfd2281  vmovaps xmm5, [rsp+0x50]
0000773e7dfd2287  vmovaps xmm6, [rsp+0x60]
0000773e7dfd228d  vmovaps xmm7, [rsp+0x70]
0000773e7dfd2293  vmovaps xmm8, [rsp+0x80]
0000773e7dfd229c  vmovaps xmm9, [rsp+0x90]
0000773e7dfd22a5  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd22ae  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd22b7  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd22c0  vmovaps xmm13, [rsp+0xD0]
0000773e7dfd22c9  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd22d2  add rsp, 0xF0
0000773e7dfd22d9  pop r11
0000773e7dfd22db  pop r10
0000773e7dfd22dd  pop r9
0000773e7dfd22df  pop r8
0000773e7dfd22e1  pop rsi
0000773e7dfd22e2  pop rdi
0000773e7dfd22e3  pop rdx
0000773e7dfd22e4  pop rcx
0000773e7dfd22e5  pop rax
0000773e7dfd22e6  add rsp, 0x08
0000773e7dfd22ea  jmp 0x0000773E7DFD1FBE
0000773e7dfd22ef  call 0x0000773E7DEC34C0
0000773e7dfd22f4  jmp 0x0000773E7DFD1FD4
0000773e7dfd22f9  int3
0000773e7dfd22fa  nop [rax+rax*1], ax
0000773e7dfd2300  mov rax, [r15+0x50]
0000773e7dfd2304  movups xmm1, [r13+rax*1]
0000773e7dfd230a  lea r14, [rax+0x10]
0000773e7dfd230e  movups xmm15, [r13+r14*1]
0000773e7dfd2314  mov qword ptr [r15+0x48], 0x00
0000773e7dfd231c  lea r14, [rax+0x40]
0000773e7dfd2320  movups xmm14, [r13+r14*1]
0000773e7dfd2326  lea r14, [rax+0x50]
0000773e7dfd232a  movups xmm13, [r13+r14*1]
0000773e7dfd2330  lea r14, [rax+0x80]
0000773e7dfd2337  movups xmm12, [r13+r14*1]
0000773e7dfd233d  lea r14, [rax+0x90]
0000773e7dfd2344  movups xmm11, [r13+r14*1]
0000773e7dfd234a  mov r14, [r15+0xF8]
0000773e7dfd2351  movups [r13+r14*1], xmm1
0000773e7dfd2357  lea r12, [rax+0x20]
0000773e7dfd235b  movups xmm1, [r13+r12*1]
0000773e7dfd2361  lea r12, [rax+0x30]
0000773e7dfd2365  movups xmm10, [r13+r12*1]
0000773e7dfd236b  lea r12, [rax+0xC0]
0000773e7dfd2372  movups xmm9, [r13+r12*1]
0000773e7dfd2378  lea r12, [rax+0xD0]
0000773e7dfd237f  movups xmm8, [r13+r12*1]
0000773e7dfd2385  lea r12, [rax+0x100]
0000773e7dfd238c  movups xmm7, [r13+r12*1]
0000773e7dfd2392  lea r12, [rax+0x110]
0000773e7dfd2399  movups xmm6, [r13+r12*1]
0000773e7dfd239f  lea r12, [rax+0x140]
0000773e7dfd23a6  movups xmm5, [r13+r12*1]
0000773e7dfd23ac  lea r12, [rax+0x150]
0000773e7dfd23b3  movups xmm4, [r13+r12*1]
0000773e7dfd23b9  lea r12, [r14+0xB0]
0000773e7dfd23c0  movups [r13+r12*1], xmm10
0000773e7dfd23c6  lea r12, [r14+0xC0]
0000773e7dfd23cd  movups [r13+r12*1], xmm1
0000773e7dfd23d3  lea r12, [rax+0x180]
0000773e7dfd23da  movups xmm1, [r13+r12*1]
0000773e7dfd23e0  lea r12, [rax+0x190]
0000773e7dfd23e7  movups xmm10, [r13+r12*1]
0000773e7dfd23ed  lea r12, [rax+0x1C0]
0000773e7dfd23f4  movups xmm3, [r13+r12*1]
0000773e7dfd23fa  lea r12, [rax+0x1D0]
0000773e7dfd2401  movups xmm2, [r13+r12*1]
0000773e7dfd2407  lea r12, [rax+0x60]
0000773e7dfd240b  vmovaps [rsp+0x10], xmm1
0000773e7dfd2411  movups xmm1, [r13+r12*1]
0000773e7dfd2417  lea r12, [rax+0x70]
0000773e7dfd241b  vmovaps [rsp+0x20], xmm1
0000773e7dfd2421  movups xmm1, [r13+r12*1]
0000773e7dfd2427  lea r12, [r14+0x70]
0000773e7dfd242b  movups [r13+r12*1], xmm10
0000773e7dfd2431  lea r12, [r14+0x80]
0000773e7dfd2438  vmovaps xmm10, [rsp+0x10]
0000773e7dfd243e  movups [r13+r12*1], xmm10
0000773e7dfd2444  lea r12, [rax+0xA0]
0000773e7dfd244b  movups xmm10, [r13+r12*1]
0000773e7dfd2451  lea r12, [rax+0xB0]
0000773e7dfd2458  vmovaps [rsp+0x10], xmm1
0000773e7dfd245e  movups xmm1, [r13+r12*1]
0000773e7dfd2464  lea r12, [r14+0x90]
0000773e7dfd246b  movups [r13+r12*1], xmm2
0000773e7dfd2471  lea r12, [r14+0xA0]
0000773e7dfd2478  movups [r13+r12*1], xmm3
0000773e7dfd247e  lea r12, [rax+0xE0]
0000773e7dfd2485  movups xmm3, [r13+r12*1]
0000773e7dfd248b  lea r12, [rax+0xF0]
0000773e7dfd2492  movups xmm2, [r13+r12*1]
0000773e7dfd2498  lea r12, [rax+0x120]
0000773e7dfd249f  vmovaps [rsp+0x30], xmm1
0000773e7dfd24a5  movups xmm1, [r13+r12*1]
0000773e7dfd24ab  lea r12, [rax+0x130]
0000773e7dfd24b2  vmovaps [rsp+0x40], xmm1
0000773e7dfd24b8  movups xmm1, [r13+r12*1]
0000773e7dfd24be  vmovaps [rsp+0x50], xmm1
0000773e7dfd24c4  vmovaps xmm1, [rsp+0x40]
0000773e7dfd24ca  movaps [r15+0x190], xmm1
0000773e7dfd24d2  lea r12, [rax+0x160]
0000773e7dfd24d9  vmovaps [rsp+0x40], xmm1
0000773e7dfd24df  movups xmm1, [r13+r12*1]
0000773e7dfd24e5  lea r12, [rax+0x170]
0000773e7dfd24ec  vmovaps [rsp+0x60], xmm1
0000773e7dfd24f2  movups xmm1, [r13+r12*1]
0000773e7dfd24f8  lea r12, [rax+0x1A0]
0000773e7dfd24ff  vmovaps [rsp+0x70], xmm1
0000773e7dfd2505  movups xmm1, [r13+r12*1]
0000773e7dfd250b  lea r12, [rax+0x1B0]
0000773e7dfd2512  vmovaps [rsp+0x80], xmm1
0000773e7dfd251b  movups xmm1, [r13+r12*1]
0000773e7dfd2521  lea r12, [rax+0x1E0]
0000773e7dfd2528  vmovaps [rsp+0x90], xmm1
0000773e7dfd2531  movups xmm1, [r13+r12*1]
0000773e7dfd2537  lea r12, [rax+0x1F0]
0000773e7dfd253e  vmovaps [rsp+0xA0], xmm1
0000773e7dfd2547  movups xmm1, [r13+r12*1]
0000773e7dfd254d  mov qword ptr [r15+0x50], 0x432190
0000773e7dfd2555  lea rax, [r14+0x50]
0000773e7dfd2559  vmovaps [rsp+0xB0], xmm1
0000773e7dfd2562  vmovaps xmm1, [rsp+0x60]
0000773e7dfd2568  movups [r13+rax*1], xmm1
0000773e7dfd256e  lea rax, [r14+0x60]
0000773e7dfd2572  movups [r13+rax*1], xmm5
0000773e7dfd2578  lea rax, [r14+0x40]
0000773e7dfd257c  vmovaps xmm1, [rsp+0x70]
0000773e7dfd2582  movups [r13+rax*1], xmm1
0000773e7dfd2588  lea rax, [r14+0x20]
0000773e7dfd258c  vmovaps xmm1, [rsp+0xA0]
0000773e7dfd2595  movups [r13+rax*1], xmm1
0000773e7dfd259b  lea rax, [r14+0x30]
0000773e7dfd259f  vmovaps xmm1, [rsp+0x90]
0000773e7dfd25a8  movups [r13+rax*1], xmm1
0000773e7dfd25ae  lea rax, [r14+0x10]
0000773e7dfd25b2  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd25bb  movups [r13+rax*1], xmm1
0000773e7dfd25c1  mov rax, [r15+0x40]
0000773e7dfd25c5  vxorps xmm1, xmm1, xmm1
0000773e7dfd25c9  vpbroadcastq xmm1, xmm1
0000773e7dfd25ce  vxorps xmm5, xmm5, xmm5
0000773e7dfd25d2  vpbroadcastq xmm5, xmm5
0000773e7dfd25d7  lea r12, [rax+0x30]
0000773e7dfd25db  mov r11, [r13+r12*1]
0000773e7dfd25e0  lea r12, [rax+0x38]
0000773e7dfd25e4  mov r10, [r13+r12*1]
0000773e7dfd25e9  vmovaps [rsp+0x60], xmm1
0000773e7dfd25ef  movq xmm1, r11
0000773e7dfd25f4  vmovaps [rsp+0x70], xmm1
0000773e7dfd25fa  movq xmm1, r10
0000773e7dfd25ff  vmovaps [rsp+0x90], xmm1
0000773e7dfd2608  vmovaps xmm1, [rsp+0x70]
0000773e7dfd260e  movq xmm1, xmm1
0000773e7dfd2612  vmovaps [rsp+0x70], xmm1
0000773e7dfd2618  vmovaps xmm1, [rsp+0x90]
0000773e7dfd2621  movq xmm1, xmm1
0000773e7dfd2625  vmovaps [rsp+0x90], xmm1
0000773e7dfd262e  movq xmm1, xmm1
0000773e7dfd2632  movaps [r15+0x270], xmm1
0000773e7dfd263a  vmovaps [rsp+0xA0], xmm7
0000773e7dfd2643  vmovaps xmm1, [rsp+0xA0]
0000773e7dfd264c  por xmm7, xmm1
0000773e7dfd2650  lea r12, [rax+0x20]
0000773e7dfd2654  mov r11, [r13+r12*1]
0000773e7dfd2659  lea r12, [rax+0x28]
0000773e7dfd265d  mov r10, [r13+r12*1]
0000773e7dfd2662  movq xmm1, r11
0000773e7dfd2667  vmovaps [rsp+0xA0], xmm1
0000773e7dfd2670  movq xmm1, r10
0000773e7dfd2675  vmovaps [rsp+0xB0], xmm1
0000773e7dfd267e  vmovaps xmm1, [rsp+0xA0]
0000773e7dfd2687  movq xmm1, xmm1
0000773e7dfd268b  vmovaps [rsp+0xA0], xmm1
0000773e7dfd2694  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd269d  movq xmm1, xmm1
0000773e7dfd26a1  vmovaps [rsp+0xB0], xmm2
0000773e7dfd26aa  vmovaps [rsp+0xC0], xmm1
0000773e7dfd26b3  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd26bc  por xmm2, xmm1
0000773e7dfd26c0  vmovaps [rsp+0xB0], xmm3
0000773e7dfd26c9  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd26d2  por xmm3, xmm1
0000773e7dfd26d6  vmovaps [rsp+0xB0], xmm4
0000773e7dfd26df  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd26e8  por xmm4, xmm1
0000773e7dfd26ec  vmovaps [rsp+0xB0], xmm9
0000773e7dfd26f5  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd26fe  por xmm9, xmm1
0000773e7dfd2703  lea r12, [rax+0x10]
0000773e7dfd2707  mov r11, [r13+r12*1]
0000773e7dfd270c  lea r12, [rax+0x18]
0000773e7dfd2710  mov r10, [r13+r12*1]
0000773e7dfd2715  movq xmm1, r11
0000773e7dfd271a  vmovaps [rsp+0xB0], xmm1
0000773e7dfd2723  movq xmm1, r10
0000773e7dfd2728  vmovaps [rsp+0xD0], xmm1
0000773e7dfd2731  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd273a  movq xmm1, xmm1
0000773e7dfd273e  vmovaps [rsp+0xB0], xmm1
0000773e7dfd2747  vmovaps xmm1, [rsp+0xD0]
0000773e7dfd2750  movq xmm1, xmm1
0000773e7dfd2754  vmovaps [rsp+0xD0], xmm1
0000773e7dfd275d  vmovaps xmm1, [rsp+0x80]
0000773e7dfd2766  vmovaps [rsp+0xE0], xmm15
0000773e7dfd276f  vmovaps xmm15, [rsp+0x80]
0000773e7dfd2778  por xmm1, xmm15
0000773e7dfd277d  vmovaps xmm15, [rsp+0x10]
0000773e7dfd2783  vmovaps [rsp+0x80], xmm1
0000773e7dfd278c  vmovaps xmm1, [rsp+0x10]
0000773e7dfd2792  por xmm15, xmm1
0000773e7dfd2797  vmovaps xmm1, [rsp+0x20]
0000773e7dfd279d  vmovaps [rsp+0x10], xmm15
0000773e7dfd27a3  vmovaps xmm15, [rsp+0x20]
0000773e7dfd27a9  por xmm1, xmm15
0000773e7dfd27ae  vmovaps [rsp+0x20], xmm6
0000773e7dfd27b4  vmovaps xmm15, [rsp+0x20]
0000773e7dfd27ba  por xmm6, xmm15
0000773e7dfd27bf  vmovaps [rsp+0x20], xmm11
0000773e7dfd27c5  vmovaps xmm15, [rsp+0x20]
0000773e7dfd27cb  por xmm11, xmm15
0000773e7dfd27d0  vmovaps [rsp+0x20], xmm13
0000773e7dfd27d6  vmovaps xmm15, [rsp+0x20]
0000773e7dfd27dc  por xmm13, xmm15
0000773e7dfd27e1  vmovaps [rsp+0x20], xmm14
0000773e7dfd27e7  vmovaps xmm15, [rsp+0x20]
0000773e7dfd27ed  por xmm14, xmm15
0000773e7dfd27f2  mov r12, [r13+rax*1]
0000773e7dfd27f7  vmovq xmm15, r12
0000773e7dfd27fc  vpbroadcastq xmm15, xmm15
0000773e7dfd2801  vmovaps [rsp+0x20], xmm1
0000773e7dfd2807  vxorps xmm1, xmm1, xmm1
0000773e7dfd280b  vpbroadcastq xmm1, xmm1
0000773e7dfd2810  vmovaps [rsp+0xF0], xmm1
0000773e7dfd2819  movups xmm1, [r13+r14*1]
0000773e7dfd281f  vmovaps [rsp+0x100], xmm1
0000773e7dfd2828  vxorps xmm1, xmm1, xmm1
0000773e7dfd282c  vpbroadcastq xmm1, xmm1
0000773e7dfd2831  lea r12, [rax+0x08]
0000773e7dfd2835  mov rax, [r13+r12*1]
0000773e7dfd283a  vmovaps [rsp+0x110], xmm1
0000773e7dfd2843  movq xmm1, rax
0000773e7dfd2848  movaps [r15+0x240], xmm1
0000773e7dfd2850  mov qword ptr [r15+0x60], 0x432190
0000773e7dfd2858  mov qword ptr [r15+0x58], 0x40
0000773e7dfd2860  vmovaps xmm1, [rsp+0x60]
0000773e7dfd2866  vmovaps [rsp+0x60], xmm15
0000773e7dfd286c  vmovaps xmm15, [rsp+0x100]
0000773e7dfd2875  vmovaps [rsp+0x100], xmm14
0000773e7dfd287e  vmovaps xmm14, [rsp+0x60]
0000773e7dfd2884  vmovaps [rsp+0x60], xmm13
0000773e7dfd288a  vmovaps [rsp+0x120], xmm12
0000773e7dfd2893  movaps xmm13, xmm1
0000773e7dfd2897  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd289c  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd28a2  vptest xmm12, xmm12
0000773e7dfd28a7  jnz 0x0000773E7DFD3482
0000773e7dfd28ad  vmovaps xmm1, [rsp+0xE0]
0000773e7dfd28b6  movaps xmm15, xmm5
0000773e7dfd28ba  vfmadd231pd xmm15, xmm1, xmm14
0000773e7dfd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
0000773e7dfd28c5  vptest xmm12, xmm12
0000773e7dfd28ca  jnz 0x0000773E7DFD35DB
0000773e7dfd28d0  vmovaps xmm12, [rsp+0x50]
0000773e7dfd28d6  vmovaps xmm5, [rsp+0x50]
0000773e7dfd28dc  por xmm12, xmm5
0000773e7dfd28e1  vmovaps xmm5, [rsp+0x30]
0000773e7dfd28e7  vmovaps [rsp+0x50], xmm1
0000773e7dfd28ed  vmovaps xmm1, [rsp+0x30]
0000773e7dfd28f3  por xmm5, xmm1
0000773e7dfd28f7  vmovaps [rsp+0x30], xmm10
0000773e7dfd28fd  vmovaps xmm1, [rsp+0x30]
0000773e7dfd2903  por xmm10, xmm1
0000773e7dfd2908  vmovaps [rsp+0x30], xmm8
0000773e7dfd290e  vmovaps xmm1, [rsp+0x30]
0000773e7dfd2914  por xmm8, xmm1
0000773e7dfd2919  vmovaps xmm1, [rsp+0x120]
0000773e7dfd2922  vmovaps [rsp+0x30], xmm15
0000773e7dfd2928  vmovaps xmm15, [rsp+0x120]
0000773e7dfd2931  por xmm1, xmm15
0000773e7dfd2936  vmovaps xmm15, [rsp+0x50]
0000773e7dfd293c  vmovaps [rsp+0xE0], xmm1
0000773e7dfd2945  vmovaps xmm1, [rsp+0x50]
0000773e7dfd294b  por xmm15, xmm1
0000773e7dfd2950  lea rax, [r14+0xC0]
0000773e7dfd2957  movups xmm1, [r13+rax*1]
0000773e7dfd295d  xor eax, eax
0000773e7dfd295f  mov r12d, 0x40
0000773e7dfd2965  mov r11d, 0x200
0000773e7dfd296b  cmp r12, r11
0000773e7dfd296e  cmc
0000773e7dfd296f  lahf
0000773e7dfd2970  seto al
0000773e7dfd2973  mov [r15+0x108], eax
0000773e7dfd297a  vmovaps [rsp+0x50], xmm1
0000773e7dfd2980  vmovaps xmm1, [rsp+0xF0]
0000773e7dfd2989  vmovaps [rsp+0xF0], xmm15
0000773e7dfd2992  vmovaps xmm15, [rsp+0x50]
0000773e7dfd2998  vmovaps [rsp+0x50], xmm13
0000773e7dfd299e  vmovaps [rsp+0x120], xmm12
0000773e7dfd29a7  movaps xmm13, xmm1
0000773e7dfd29ab  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd29b6  vptest xmm12, xmm12
0000773e7dfd29bb  jnz 0x0000773E7DFD373D
0000773e7dfd29c1  lea rax, [r14+0xB0]
0000773e7dfd29c8  movups xmm1, [r13+rax*1]
0000773e7dfd29ce  vmovaps xmm15, [rsp+0x110]
0000773e7dfd29d7  vmovaps [rsp+0x110], xmm13
0000773e7dfd29e0  movaps xmm12, xmm15
0000773e7dfd29e4  vfmadd231pd xmm12, xmm1, xmm14
0000773e7dfd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
0000773e7dfd29ef  vptest xmm13, xmm13
0000773e7dfd29f4  jnz 0x0000773E7DFD38A0
0000773e7dfd29fa  vmovaps xmm1, [rsp+0x100]
0000773e7dfd2a03  vmovaps xmm15, [rsp+0x100]
0000773e7dfd2a0c  por xmm1, xmm15
0000773e7dfd2a11  movaps [r15+0x210], xmm1
0000773e7dfd2a19  vmovaps xmm15, [rsp+0x60]
0000773e7dfd2a1f  vmovaps xmm14, [rsp+0x60]
0000773e7dfd2a25  por xmm15, xmm14
0000773e7dfd2a2a  movaps [r15+0x1C0], xmm15
0000773e7dfd2a32  vmovaps [rsp+0x60], xmm11
0000773e7dfd2a38  vmovaps xmm14, [rsp+0x60]
0000773e7dfd2a3e  por xmm11, xmm14
0000773e7dfd2a43  movaps [r15+0x280], xmm11
0000773e7dfd2a4b  vmovaps [rsp+0x60], xmm6
0000773e7dfd2a51  vmovaps xmm14, [rsp+0x60]
0000773e7dfd2a57  por xmm6, xmm14
0000773e7dfd2a5c  movaps [r15+0x2A0], xmm6
0000773e7dfd2a64  vmovaps xmm14, [rsp+0x20]
0000773e7dfd2a6a  vmovaps xmm13, [rsp+0x20]
0000773e7dfd2a70  por xmm14, xmm13
0000773e7dfd2a75  movaps [r15+0x2E0], xmm14
0000773e7dfd2a7d  vmovaps xmm13, [rsp+0x10]
0000773e7dfd2a83  vmovaps [rsp+0x20], xmm1
0000773e7dfd2a89  vmovaps xmm1, [rsp+0x10]
0000773e7dfd2a8f  por xmm13, xmm1
0000773e7dfd2a94  movaps [r15+0x1F0], xmm13
0000773e7dfd2a9c  vmovaps xmm1, [rsp+0xF0]
0000773e7dfd2aa5  vmovaps [rsp+0x10], xmm15
0000773e7dfd2aab  vmovaps xmm15, [rsp+0xF0]
0000773e7dfd2ab4  por xmm1, xmm15
0000773e7dfd2ab9  movaps [r15+0x250], xmm1
0000773e7dfd2ac1  vmovaps xmm1, [rsp+0xE0]
0000773e7dfd2aca  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd2ad3  por xmm1, xmm15
0000773e7dfd2ad8  movaps [r15+0x260], xmm1
0000773e7dfd2ae0  vmovaps [rsp+0x60], xmm8
0000773e7dfd2ae6  vmovaps xmm15, [rsp+0x60]
0000773e7dfd2aec  por xmm8, xmm15
0000773e7dfd2af1  movaps [r15+0x290], xmm8
0000773e7dfd2af9  vmovaps [rsp+0x60], xmm10
0000773e7dfd2aff  vmovaps xmm15, [rsp+0x60]
0000773e7dfd2b05  por xmm10, xmm15
0000773e7dfd2b0a  movaps [r15+0x2C0], xmm10
0000773e7dfd2b12  movq xmm15, qword ptr [r15+0x240]
0000773e7dfd2b1b  vmovaps [rsp+0x60], xmm15
0000773e7dfd2b21  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd2b27  vmovaps [rsp+0xE0], xmm1
0000773e7dfd2b30  vmovaps xmm1, [rsp+0x50]
0000773e7dfd2b36  vmovaps [rsp+0x50], xmm15
0000773e7dfd2b3c  vmovaps xmm15, [rsp+0x20]
0000773e7dfd2b42  vmovaps [rsp+0x20], xmm14
0000773e7dfd2b48  vmovaps xmm14, [rsp+0x50]
0000773e7dfd2b4e  vmovaps [rsp+0x50], xmm13
0000773e7dfd2b54  vmovaps [rsp+0xF0], xmm12
0000773e7dfd2b5d  movaps xmm13, xmm1
0000773e7dfd2b61  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd2b6c  vptest xmm12, xmm12
0000773e7dfd2b71  jnz 0x0000773E7DFD39F9
0000773e7dfd2b77  vmovaps xmm1, [rsp+0x60]
0000773e7dfd2b7d  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd2b83  vmovaps xmm15, [rsp+0x110]
0000773e7dfd2b8c  vmovaps xmm14, [rsp+0x20]
0000773e7dfd2b92  vmovaps [rsp+0x20], xmm13
0000773e7dfd2b98  movaps xmm12, xmm15
0000773e7dfd2b9c  vfmadd231pd xmm12, xmm14, xmm1
0000773e7dfd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
0000773e7dfd2ba7  vptest xmm13, xmm13
0000773e7dfd2bac  jnz 0x0000773E7DFD3B52
0000773e7dfd2bb2  vmovaps xmm1, [rsp+0x60]
0000773e7dfd2bb8  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd2bbe  vmovaps xmm15, [rsp+0x30]
0000773e7dfd2bc4  vmovaps xmm14, [rsp+0x10]
0000773e7dfd2bca  vmovaps [rsp+0x10], xmm12
0000773e7dfd2bd0  movaps xmm13, xmm15
0000773e7dfd2bd4  vfmadd231pd xmm13, xmm14, xmm1
0000773e7dfd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd2bdf  vptest xmm12, xmm12
0000773e7dfd2be4  jnz 0x0000773E7DFD3CAB
0000773e7dfd2bea  vmovaps [rsp+0x30], xmm5
0000773e7dfd2bf0  vmovaps xmm1, [rsp+0x30]
0000773e7dfd2bf6  por xmm5, xmm1
0000773e7dfd2bfa  movaps [r15+0x1D0], xmm5
0000773e7dfd2c02  vmovaps xmm1, [rsp+0x60]
0000773e7dfd2c08  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd2c0e  vmovaps xmm15, [rsp+0xF0]
0000773e7dfd2c17  vmovaps xmm14, [rsp+0x50]
0000773e7dfd2c1d  vmovaps [rsp+0x30], xmm13
0000773e7dfd2c23  movaps xmm12, xmm15
0000773e7dfd2c27  vfmadd231pd xmm12, xmm14, xmm1
0000773e7dfd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
0000773e7dfd2c32  vptest xmm13, xmm13
0000773e7dfd2c37  jnz 0x0000773E7DFD3E04
0000773e7dfd2c3d  vmovaps xmm1, [rsp+0x80]
0000773e7dfd2c46  vmovaps xmm15, [rsp+0x80]
0000773e7dfd2c4f  por xmm1, xmm15
0000773e7dfd2c54  movaps [r15+0x200], xmm1
0000773e7dfd2c5c  vmovaps xmm15, [rsp+0x120]
0000773e7dfd2c65  vmovaps xmm14, [rsp+0x120]
0000773e7dfd2c6e  por xmm15, xmm14
0000773e7dfd2c73  movaps [r15+0x1E0], xmm15
0000773e7dfd2c7b  vmovaps [rsp+0x50], xmm4
0000773e7dfd2c81  vmovaps xmm13, [rsp+0x50]
0000773e7dfd2c87  por xmm4, xmm13
0000773e7dfd2c8c  movaps [r15+0x2B0], xmm4
0000773e7dfd2c94  vmovaps [rsp+0x50], xmm3
0000773e7dfd2c9a  vmovaps xmm13, [rsp+0x50]
0000773e7dfd2ca0  por xmm3, xmm13
0000773e7dfd2ca5  movaps [r15+0x300], xmm3
0000773e7dfd2cad  vmovaps xmm15, [rsp+0xB0]
0000773e7dfd2cb6  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd2cbc  vmovaps xmm3, [rsp+0x20]
0000773e7dfd2cc2  vmovaps [rsp+0x20], xmm1
0000773e7dfd2cc8  vmovaps xmm1, [rsp+0xE0]
0000773e7dfd2cd1  vmovaps [rsp+0x50], xmm14
0000773e7dfd2cd7  vmovaps [rsp+0x60], xmm13
0000773e7dfd2cdd  movaps xmm14, xmm3
0000773e7dfd2ce1  vfmadd231pd xmm14, xmm1, xmm15
0000773e7dfd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
0000773e7dfd2cec  vptest xmm13, xmm13
0000773e7dfd2cf1  jnz 0x0000773E7DFD3F5D
0000773e7dfd2cf7  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd2d00  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd2d06  vmovaps xmm15, [rsp+0x10]
0000773e7dfd2d0c  movaps xmm13, xmm15
0000773e7dfd2d10  vfmadd231pd xmm13, xmm10, xmm1
0000773e7dfd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
0000773e7dfd2d1b  vptest xmm3, xmm3
0000773e7dfd2d20  jnz 0x0000773E7DFD40B5
0000773e7dfd2d26  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd2d2f  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd2d35  vmovaps xmm15, [rsp+0x30]
0000773e7dfd2d3b  movaps xmm10, xmm15
0000773e7dfd2d3f  vfmadd231pd xmm10, xmm11, xmm1
0000773e7dfd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
0000773e7dfd2d4a  vptest xmm3, xmm3
0000773e7dfd2d4f  jnz 0x0000773E7DFD420E
0000773e7dfd2d55  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd2d5e  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd2d64  movaps xmm15, xmm12
0000773e7dfd2d68  vfmadd231pd xmm15, xmm5, xmm1
0000773e7dfd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
0000773e7dfd2d73  vptest xmm11, xmm11
0000773e7dfd2d78  jnz 0x0000773E7DFD4367
0000773e7dfd2d7e  vmovaps [rsp+0x10], xmm9
0000773e7dfd2d84  vmovaps xmm1, [rsp+0x10]
0000773e7dfd2d8a  por xmm9, xmm1
0000773e7dfd2d8f  movaps [r15+0x180], xmm9
0000773e7dfd2d97  vmovaps [rsp+0x10], xmm2
0000773e7dfd2d9d  vmovaps xmm1, [rsp+0x10]
0000773e7dfd2da3  por xmm2, xmm1
0000773e7dfd2da7  movaps [r15+0x2D0], xmm2
0000773e7dfd2daf  vmovaps xmm12, [rsp+0xD0]
0000773e7dfd2db8  vpermilpd xmm12, xmm12, 0x00
0000773e7dfd2dbe  vmovaps xmm11, [rsp+0x60]
0000773e7dfd2dc4  movaps xmm5, xmm13
0000773e7dfd2dc8  vfmadd231pd xmm5, xmm11, xmm12
0000773e7dfd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
0000773e7dfd2dd2  vptest xmm3, xmm3
0000773e7dfd2dd7  jnz 0x0000773E7DFD44BF
0000773e7dfd2ddd  vmovaps xmm13, [rsp+0xD0]
0000773e7dfd2de6  vpermilpd xmm13, xmm13, 0x00
0000773e7dfd2dec  movaps xmm12, xmm14
0000773e7dfd2df0  vfmadd231pd xmm12, xmm9, xmm13
0000773e7dfd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
0000773e7dfd2dfb  vptest xmm11, xmm11
0000773e7dfd2e00  jnz 0x0000773E7DFD4617
0000773e7dfd2e06  lea rax, [r14+0x80]
0000773e7dfd2e0d  movups xmm14, [r13+rax*1]
0000773e7dfd2e13  movaps [r15+0x2F0], xmm14
0000773e7dfd2e1b  vmovaps xmm13, [rsp+0xD0]
0000773e7dfd2e24  vpermilpd xmm13, xmm13, 0x00
0000773e7dfd2e2a  movaps xmm11, xmm10
0000773e7dfd2e2e  vfmadd231pd xmm11, xmm8, xmm13
0000773e7dfd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
0000773e7dfd2e39  vptest xmm9, xmm9
0000773e7dfd2e3e  jnz 0x0000773E7DFD477B
0000773e7dfd2e44  vmovaps xmm13, [rsp+0xD0]
0000773e7dfd2e4d  vpermilpd xmm13, xmm13, 0x00
0000773e7dfd2e53  movaps xmm10, xmm15
0000773e7dfd2e57  vfmadd231pd xmm10, xmm1, xmm13
0000773e7dfd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
0000773e7dfd2e62  vptest xmm9, xmm9
0000773e7dfd2e67  jnz 0x0000773E7DFD48D5
0000773e7dfd2e6d  vmovaps [rsp+0x10], xmm7
0000773e7dfd2e73  vmovaps xmm1, [rsp+0x10]
0000773e7dfd2e79  por xmm7, xmm1
0000773e7dfd2e7d  movaps [r15+0x160], xmm7
0000773e7dfd2e85  lea rax, [r14+0x40]
0000773e7dfd2e89  movups xmm1, [r13+rax*1]
0000773e7dfd2e8f  lea rax, [r14+0x50]
0000773e7dfd2e93  movups xmm15, [r13+rax*1]
0000773e7dfd2e99  movaps [r15+0x1B0], xmm1
0000773e7dfd2ea1  movaps [r15+0x1A0], xmm15
0000773e7dfd2ea9  vmovaps xmm13, [rsp+0xA0]
0000773e7dfd2eb2  vpermilpd xmm13, xmm13, 0x00
0000773e7dfd2eb8  vmovaps xmm9, [rsp+0x40]
0000773e7dfd2ebe  movaps xmm8, xmm5
0000773e7dfd2ec2  vfmadd231pd xmm8, xmm9, xmm13
0000773e7dfd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
0000773e7dfd2ecd  vptest xmm3, xmm3
0000773e7dfd2ed2  jnz 0x0000773E7DFD4A42
0000773e7dfd2ed8  vmovaps xmm13, [rsp+0xA0]
0000773e7dfd2ee1  vpermilpd xmm13, xmm13, 0x00
0000773e7dfd2ee7  movaps xmm9, xmm12
0000773e7dfd2eeb  vfmadd231pd xmm9, xmm7, xmm13
0000773e7dfd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
0000773e7dfd2ef6  vptest xmm5, xmm5
0000773e7dfd2efb  jnz 0x0000773E7DFD4B9B
0000773e7dfd2f01  vmovaps xmm13, [rsp+0xA0]
0000773e7dfd2f0a  vpermilpd xmm13, xmm13, 0x00
0000773e7dfd2f10  movaps xmm12, xmm11
0000773e7dfd2f14  vfmadd231pd xmm12, xmm6, xmm13
0000773e7dfd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
0000773e7dfd2f1f  vptest xmm7, xmm7
0000773e7dfd2f24  jnz 0x0000773E7DFD4CF4
0000773e7dfd2f2a  vmovaps xmm13, [rsp+0xA0]
0000773e7dfd2f33  vpermilpd xmm13, xmm13, 0x00
0000773e7dfd2f39  vmovaps xmm11, [rsp+0x50]
0000773e7dfd2f3f  movaps xmm7, xmm10
0000773e7dfd2f43  vfmadd231pd xmm7, xmm11, xmm13
0000773e7dfd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
0000773e7dfd2f4d  vptest xmm6, xmm6
0000773e7dfd2f52  jnz 0x0000773E7DFD4E4D
0000773e7dfd2f58  lea rax, [r14+0x60]
0000773e7dfd2f5c  movups xmm13, [r13+rax*1]
0000773e7dfd2f62  lea rax, [r14+0x70]
0000773e7dfd2f66  movups xmm11, [r13+rax*1]
0000773e7dfd2f6c  movaps [r15+0x150], xmm13
0000773e7dfd2f74  movaps [r15+0x120], xmm11
0000773e7dfd2f7c  vmovaps xmm10, [rsp+0xC0]
0000773e7dfd2f85  vpermilpd xmm10, xmm10, 0x00
0000773e7dfd2f8b  movaps xmm6, xmm8
0000773e7dfd2f8f  vfmadd231pd xmm6, xmm15, xmm10
0000773e7dfd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
0000773e7dfd2f99  vptest xmm5, xmm5
0000773e7dfd2f9e  jnz 0x0000773E7DFD4FB9
0000773e7dfd2fa4  vmovaps xmm15, [rsp+0xC0]
0000773e7dfd2fad  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd2fb3  movaps xmm10, xmm9
0000773e7dfd2fb7  vfmadd231pd xmm10, xmm13, xmm15
0000773e7dfd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
0000773e7dfd2fc2  vptest xmm8, xmm8
0000773e7dfd2fc7  jnz 0x0000773E7DFD5111
0000773e7dfd2fcd  vmovaps xmm15, [rsp+0xC0]
0000773e7dfd2fd6  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd2fdc  movaps xmm13, xmm12
0000773e7dfd2fe0  vfmadd231pd xmm13, xmm4, xmm15
0000773e7dfd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
0000773e7dfd2feb  vptest xmm9, xmm9
0000773e7dfd2ff0  jnz 0x0000773E7DFD526B
0000773e7dfd2ff6  vmovaps xmm15, [rsp+0xC0]
0000773e7dfd2fff  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd3005  movaps xmm12, xmm7
0000773e7dfd3009  vfmadd231pd xmm12, xmm1, xmm15
0000773e7dfd300e  vcmppd xmm9, xmm12, xmm12, 0x03
0000773e7dfd3014  vptest xmm9, xmm9
0000773e7dfd3019  jnz 0x0000773E7DFD53C4
0000773e7dfd301f  lea rax, [r14+0x20]
0000773e7dfd3023  movups xmm1, [r13+rax*1]
0000773e7dfd3029  lea rax, [r14+0x30]
0000773e7dfd302d  movups xmm15, [r13+rax*1]
0000773e7dfd3033  vmovaps xmm9, [rsp+0x70]
0000773e7dfd3039  vpermilpd xmm9, xmm9, 0x00
0000773e7dfd303f  vmovaps xmm8, [rsp+0x20]
0000773e7dfd3045  movaps xmm7, xmm6
0000773e7dfd3048  vfmadd231pd xmm7, xmm8, xmm9
0000773e7dfd304d  vcmppd xmm5, xmm7, xmm7, 0x03
0000773e7dfd3052  vptest xmm5, xmm5
0000773e7dfd3057  jnz 0x0000773E7DFD5530
0000773e7dfd305d  vmovaps xmm9, [rsp+0x70]
0000773e7dfd3063  vpermilpd xmm9, xmm9, 0x00
0000773e7dfd3069  movaps xmm8, xmm10
0000773e7dfd306d  vfmadd231pd xmm8, xmm14, xmm9
0000773e7dfd3072  vcmppd xmm6, xmm8, xmm8, 0x03
0000773e7dfd3078  vptest xmm6, xmm6
0000773e7dfd307d  jnz 0x0000773E7DFD5687
0000773e7dfd3083  vmovaps xmm14, [rsp+0x70]
0000773e7dfd3089  vpermilpd xmm14, xmm14, 0x00
0000773e7dfd308f  movaps xmm10, xmm13
0000773e7dfd3093  vfmadd231pd xmm10, xmm11, xmm14
0000773e7dfd3098  vcmppd xmm9, xmm10, xmm10, 0x03
0000773e7dfd309e  vptest xmm9, xmm9
0000773e7dfd30a3  jnz 0x0000773E7DFD57E1
0000773e7dfd30a9  vmovaps xmm14, [rsp+0x70]
0000773e7dfd30af  vpermilpd xmm14, xmm14, 0x00
0000773e7dfd30b5  movaps xmm13, xmm12
0000773e7dfd30b9  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd30be  vcmppd xmm11, xmm13, xmm13, 0x03
0000773e7dfd30c4  vptest xmm11, xmm11
0000773e7dfd30c9  jnz 0x0000773E7DFD593B
0000773e7dfd30cf  lea rax, [r14+0x90]
0000773e7dfd30d6  movups xmm15, [r13+rax*1]
0000773e7dfd30dc  lea rax, [r14+0xA0]
0000773e7dfd30e3  movups xmm14, [r13+rax*1]
0000773e7dfd30e9  movaps [r15+0x140], xmm15
0000773e7dfd30f1  movaps [r15+0x130], xmm14
0000773e7dfd30f9  vmovaps xmm12, [rsp+0x90]
0000773e7dfd3102  vpermilpd xmm12, xmm12, 0x00
0000773e7dfd3108  movaps xmm11, xmm7
0000773e7dfd310c  vfmadd231pd xmm11, xmm1, xmm12
0000773e7dfd3111  vcmppd xmm9, xmm11, xmm11, 0x03
0000773e7dfd3117  vptest xmm9, xmm9
0000773e7dfd311c  jnz 0x0000773E7DFD5AA9
0000773e7dfd3122  movaps [r15+0x220], xmm11
0000773e7dfd312a  lea rax, [r14+0x10]
0000773e7dfd312e  movups xmm1, [r13+rax*1]
0000773e7dfd3134  movaps [r15+0x240], xmm1
0000773e7dfd313c  vmovaps xmm12, [rsp+0x90]
0000773e7dfd3145  vpermilpd xmm12, xmm12, 0x00
0000773e7dfd314b  movaps xmm9, xmm8
0000773e7dfd314f  vfmadd231pd xmm9, xmm14, xmm12
0000773e7dfd3154  vcmppd xmm7, xmm9, xmm9, 0x03
0000773e7dfd315a  vptest xmm7, xmm7
0000773e7dfd315f  jnz 0x0000773E7DFD5C0B
0000773e7dfd3165  movaps [r15+0x110], xmm9
0000773e7dfd316d  vmovaps xmm14, [rsp+0x90]
0000773e7dfd3176  vpermilpd xmm14, xmm14, 0x00
0000773e7dfd317c  movaps xmm12, xmm10
0000773e7dfd3180  vfmadd231pd xmm12, xmm15, xmm14
0000773e7dfd3185  vcmppd xmm8, xmm12, xmm12, 0x03
0000773e7dfd318b  vptest xmm8, xmm8
0000773e7dfd3190  jnz 0x0000773E7DFD5D65
0000773e7dfd3196  movaps [r15+0x170], xmm12
0000773e7dfd319e  vmovaps xmm15, [rsp+0x90]
0000773e7dfd31a7  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd31ad  movaps xmm14, xmm13
0000773e7dfd31b1  vfmadd231pd xmm14, xmm1, xmm15
0000773e7dfd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
0000773e7dfd31bc  vptest xmm10, xmm10
0000773e7dfd31c1  jnz 0x0000773E7DFD5EBF
0000773e7dfd31c7  movaps [r15+0x230], xmm14
0000773e7dfd31cf  mov eax, 0x432190
0000773e7dfd31d4  movups [r13+rax*1], xmm9
0000773e7dfd31da  mov eax, 0x4321A0
0000773e7dfd31df  movups [r13+rax*1], xmm12
0000773e7dfd31e5  mov eax, 0x4321B0
0000773e7dfd31ea  movups [r13+rax*1], xmm11
0000773e7dfd31f0  mov eax, 0x4321C0
0000773e7dfd31f5  movups [r13+rax*1], xmm14
0000773e7dfd31fb  mov eax, [r15+0x108]
0000773e7dfd3202  sahf
0000773e7dfd3203  jnz 0x0000773E7DFD3235
0000773e7dfd3205  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd320d  jz 0x0000773E7DFD9950
0000773e7dfd3213  nop [rax+rax*1], ax
0000773e7dfd321c  nop [rax+rax*1], eax
0000773e7dfd3224  mov eax, 0x410664
0000773e7dfd3229  mov [r15+0x100], rax
0000773e7dfd3230  jmp 0x0000773E7DDFE110
0000773e7dfd3235  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd323d  jz 0x0000773E7DFD6050
0000773e7dfd3243  nop [rax+rax*1], ax
0000773e7dfd324c  nop [rax+rax*1], eax
0000773e7dfd3254  mov eax, 0x4104F0
0000773e7dfd3259  mov [r15+0x100], rax
0000773e7dfd3260  jmp 0x0000773E7DDFE110
0000773e7dfd3265  int3
0000773e7dfd3266  call 0x0000773E7DDFF430
0000773e7dfd326b  jmp 0x0000773E7DFD230A
0000773e7dfd3270  call 0x0000773E7DEE5820
0000773e7dfd3275  jmp 0x0000773E7DFD2314
0000773e7dfd327a  call 0x0000773E7DEE45A0
0000773e7dfd327f  jmp 0x0000773E7DFD2326
0000773e7dfd3284  call 0x0000773E7DEE3320
0000773e7dfd3289  jmp 0x0000773E7DFD2330
0000773e7dfd328e  call 0x0000773E7DEE20A0
0000773e7dfd3293  jmp 0x0000773E7DFD233D
0000773e7dfd3298  call 0x0000773E7DEE0E30
0000773e7dfd329d  jmp 0x0000773E7DFD234A
0000773e7dfd32a2  call 0x0000773E7DED6600
0000773e7dfd32a7  jmp 0x0000773E7DFD2357
0000773e7dfd32ac  call 0x0000773E7DEB52F0
0000773e7dfd32b1  jmp 0x0000773E7DFD2361
0000773e7dfd32b6  call 0x0000773E7DEBE9C0
0000773e7dfd32bb  jmp 0x0000773E7DFD236B
0000773e7dfd32c0  call 0x0000773E7DEBD750
0000773e7dfd32c5  jmp 0x0000773E7DFD2378
0000773e7dfd32ca  call 0x0000773E7DEBC4E0
0000773e7dfd32cf  jmp 0x0000773E7DFD2385
0000773e7dfd32d4  call 0x0000773E7DEBB270
0000773e7dfd32d9  jmp 0x0000773E7DFD2392
0000773e7dfd32de  call 0x0000773E7DEBA000
0000773e7dfd32e3  jmp 0x0000773E7DFD239F
0000773e7dfd32e8  call 0x0000773E7DEB8D90
0000773e7dfd32ed  jmp 0x0000773E7DFD23AC
0000773e7dfd32f2  call 0x0000773E7DEB8A20
0000773e7dfd32f7  jmp 0x0000773E7DFD23B9
0000773e7dfd32fc  call 0x0000773E7DEBEAE0
0000773e7dfd3301  jmp 0x0000773E7DFD23C6
0000773e7dfd3306  call 0x0000773E7DEB5400
0000773e7dfd330b  jmp 0x0000773E7DFD23D3
0000773e7dfd3310  call 0x0000773E7DEB52F0
0000773e7dfd3315  jmp 0x0000773E7DFD23E0
0000773e7dfd331a  call 0x0000773E7DEBE9C0
0000773e7dfd331f  jmp 0x0000773E7DFD23ED
0000773e7dfd3324  call 0x0000773E7DEB77B0
0000773e7dfd3329  jmp 0x0000773E7DFD23FA
0000773e7dfd332e  call 0x0000773E7DEB6550
0000773e7dfd3333  jmp 0x0000773E7DFD2407
0000773e7dfd3338  call 0x0000773E7DEB52F0
0000773e7dfd333d  jmp 0x0000773E7DFD2417
0000773e7dfd3342  call 0x0000773E7DEB52F0
0000773e7dfd3347  jmp 0x0000773E7DFD2427
0000773e7dfd334c  call 0x0000773E7DEBEAE0
0000773e7dfd3351  jmp 0x0000773E7DFD2431
0000773e7dfd3356  call 0x0000773E7DEBEAE0
0000773e7dfd335b  jmp 0x0000773E7DFD2444
0000773e7dfd3360  call 0x0000773E7DEBE9C0
0000773e7dfd3365  jmp 0x0000773E7DFD2451
0000773e7dfd336a  call 0x0000773E7DEB52F0
0000773e7dfd336f  jmp 0x0000773E7DFD2464
0000773e7dfd3374  call 0x0000773E7DEB6660
0000773e7dfd3379  jmp 0x0000773E7DFD2471
0000773e7dfd337e  call 0x0000773E7DEB78C0
0000773e7dfd3383  jmp 0x0000773E7DFD247E
0000773e7dfd3388  call 0x0000773E7DEB77B0
0000773e7dfd338d  jmp 0x0000773E7DFD248B
0000773e7dfd3392  call 0x0000773E7DEB6550
0000773e7dfd3397  jmp 0x0000773E7DFD2498
0000773e7dfd339c  call 0x0000773E7DEB52F0
0000773e7dfd33a1  jmp 0x0000773E7DFD24AB
0000773e7dfd33a6  call 0x0000773E7DEB52F0
0000773e7dfd33ab  jmp 0x0000773E7DFD24BE
0000773e7dfd33b0  call 0x0000773E7DEB52F0
0000773e7dfd33b5  jmp 0x0000773E7DFD24E5
0000773e7dfd33ba  call 0x0000773E7DEB52F0
0000773e7dfd33bf  jmp 0x0000773E7DFD24F8
0000773e7dfd33c4  call 0x0000773E7DEB52F0
0000773e7dfd33c9  jmp 0x0000773E7DFD250B
0000773e7dfd33ce  call 0x0000773E7DEB52F0
0000773e7dfd33d3  jmp 0x0000773E7DFD2521
0000773e7dfd33d8  call 0x0000773E7DEB52F0
0000773e7dfd33dd  jmp 0x0000773E7DFD2537
0000773e7dfd33e2  call 0x0000773E7DEB52F0
0000773e7dfd33e7  jmp 0x0000773E7DFD254D
0000773e7dfd33ec  call 0x0000773E7DDFF540
0000773e7dfd33f1  jmp 0x0000773E7DFD256E
0000773e7dfd33f6  call 0x0000773E7DE02FE0
0000773e7dfd33fb  jmp 0x0000773E7DFD2578
0000773e7dfd3400  call 0x0000773E7DDFF540
0000773e7dfd3405  jmp 0x0000773E7DFD2588
0000773e7dfd340a  call 0x0000773E7DDFF540
0000773e7dfd340f  jmp 0x0000773E7DFD259B
0000773e7dfd3414  call 0x0000773E7DDFF540
0000773e7dfd3419  jmp 0x0000773E7DFD25AE
0000773e7dfd341e  call 0x0000773E7DDFF540
0000773e7dfd3423  jmp 0x0000773E7DFD25C1
0000773e7dfd3428  call 0x0000773E7DEC0370
0000773e7dfd342d  jmp 0x0000773E7DFD25E0
0000773e7dfd3432  call 0x0000773E7DEBF100
0000773e7dfd3437  jmp 0x0000773E7DFD25E9
0000773e7dfd343c  call 0x0000773E7DEC0370
0000773e7dfd3441  jmp 0x0000773E7DFD2659
0000773e7dfd3446  call 0x0000773E7DEBF100
0000773e7dfd344b  jmp 0x0000773E7DFD2662
0000773e7dfd3450  call 0x0000773E7DEC0370
0000773e7dfd3455  jmp 0x0000773E7DFD270C
0000773e7dfd345a  call 0x0000773E7DEBF100
0000773e7dfd345f  jmp 0x0000773E7DFD2715
0000773e7dfd3464  call 0x0000773E7DE0B720
0000773e7dfd3469  jmp 0x0000773E7DFD27F7
0000773e7dfd346e  call 0x0000773E7DED64F0
0000773e7dfd3473  jmp 0x0000773E7DFD281F
0000773e7dfd3478  call 0x0000773E7DEB47C0
0000773e7dfd347d  jmp 0x0000773E7DFD283A
0000773e7dfd3482  sub rsp, 0x08
0000773e7dfd3486  push rax
0000773e7dfd3487  push rcx
0000773e7dfd3488  push rdx
0000773e7dfd3489  push rdi
0000773e7dfd348a  push rsi
0000773e7dfd348b  push r8
0000773e7dfd348d  push r9
0000773e7dfd348f  push r10
0000773e7dfd3491  push r11
0000773e7dfd3493  sub rsp, 0xF0
0000773e7dfd349a  vmovaps [rsp], xmm0
0000773e7dfd349f  vmovaps [rsp+0x10], xmm1
0000773e7dfd34a5  vmovaps [rsp+0x20], xmm2
0000773e7dfd34ab  vmovaps [rsp+0x30], xmm3
0000773e7dfd34b1  vmovaps [rsp+0x40], xmm4
0000773e7dfd34b7  vmovaps [rsp+0x50], xmm5
0000773e7dfd34bd  vmovaps [rsp+0x60], xmm6
0000773e7dfd34c3  vmovaps [rsp+0x70], xmm7
0000773e7dfd34c9  vmovaps [rsp+0x80], xmm8
0000773e7dfd34d2  vmovaps [rsp+0x90], xmm9
0000773e7dfd34db  vmovaps [rsp+0xA0], xmm10
0000773e7dfd34e4  vmovaps [rsp+0xB0], xmm11
0000773e7dfd34ed  vmovaps [rsp+0xC0], xmm12
0000773e7dfd34f6  vmovaps [rsp+0xD0], xmm14
0000773e7dfd34ff  vmovaps [rsp+0xE0], xmm15
0000773e7dfd3508  sub rsp, 0x40
0000773e7dfd350c  lea rdi, [rsp]
0000773e7dfd3510  lea rsi, [rsp+0x10]
0000773e7dfd3515  lea rdx, [rsp+0x20]
0000773e7dfd351a  lea rcx, [rsp+0x30]
0000773e7dfd351f  mov r8d, 0x00
0000773e7dfd3525  lea r9, [r15+0x3A8]
0000773e7dfd352c  movaps [rdi], xmm13
0000773e7dfd3530  movaps [rsi], xmm1
0000773e7dfd3533  movaps [rdx], xmm15
0000773e7dfd3537  movaps [rcx], xmm14
0000773e7dfd353b  mov rax, 0x567852F34A50
0000773e7dfd3545  call rax
0000773e7dfd3547  movaps xmm13, [rsp]
0000773e7dfd354c  add rsp, 0x40
0000773e7dfd3550  vmovaps xmm0, [rsp]
0000773e7dfd3555  vmovaps xmm1, [rsp+0x10]
0000773e7dfd355b  vmovaps xmm2, [rsp+0x20]
0000773e7dfd3561  vmovaps xmm3, [rsp+0x30]
0000773e7dfd3567  vmovaps xmm4, [rsp+0x40]
0000773e7dfd356d  vmovaps xmm5, [rsp+0x50]
0000773e7dfd3573  vmovaps xmm6, [rsp+0x60]
0000773e7dfd3579  vmovaps xmm7, [rsp+0x70]
0000773e7dfd357f  vmovaps xmm8, [rsp+0x80]
0000773e7dfd3588  vmovaps xmm9, [rsp+0x90]
0000773e7dfd3591  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd359a  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd35a3  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd35ac  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd35b5  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd35be  add rsp, 0xF0
0000773e7dfd35c5  pop r11
0000773e7dfd35c7  pop r10
0000773e7dfd35c9  pop r9
0000773e7dfd35cb  pop r8
0000773e7dfd35cd  pop rsi
0000773e7dfd35ce  pop rdi
0000773e7dfd35cf  pop rdx
0000773e7dfd35d0  pop rcx
0000773e7dfd35d1  pop rax
0000773e7dfd35d2  add rsp, 0x08
0000773e7dfd35d6  jmp 0x0000773E7DFD28AD
0000773e7dfd35db  sub rsp, 0x08
0000773e7dfd35df  push rax
0000773e7dfd35e0  push rcx
0000773e7dfd35e1  push rdx
0000773e7dfd35e2  push rdi
0000773e7dfd35e3  push rsi
0000773e7dfd35e4  push r8
0000773e7dfd35e6  push r9
0000773e7dfd35e8  push r10
0000773e7dfd35ea  push r11
0000773e7dfd35ec  sub rsp, 0xF0
0000773e7dfd35f3  vmovaps [rsp], xmm0
0000773e7dfd35f8  vmovaps [rsp+0x10], xmm1
0000773e7dfd35fe  vmovaps [rsp+0x20], xmm2
0000773e7dfd3604  vmovaps [rsp+0x30], xmm3
0000773e7dfd360a  vmovaps [rsp+0x40], xmm4
0000773e7dfd3610  vmovaps [rsp+0x50], xmm5
0000773e7dfd3616  vmovaps [rsp+0x60], xmm6
0000773e7dfd361c  vmovaps [rsp+0x70], xmm7
0000773e7dfd3622  vmovaps [rsp+0x80], xmm8
0000773e7dfd362b  vmovaps [rsp+0x90], xmm9
0000773e7dfd3634  vmovaps [rsp+0xA0], xmm10
0000773e7dfd363d  vmovaps [rsp+0xB0], xmm11
0000773e7dfd3646  vmovaps [rsp+0xC0], xmm12
0000773e7dfd364f  vmovaps [rsp+0xD0], xmm13
0000773e7dfd3658  vmovaps [rsp+0xE0], xmm14
0000773e7dfd3661  sub rsp, 0x40
0000773e7dfd3665  lea rdi, [rsp]
0000773e7dfd3669  lea rsi, [rsp+0x10]
0000773e7dfd366e  lea rdx, [rsp+0x20]
0000773e7dfd3673  lea rcx, [rsp+0x30]
0000773e7dfd3678  mov r8d, 0x00
0000773e7dfd367e  lea r9, [r15+0x3A8]
0000773e7dfd3685  movaps [rdi], xmm15
0000773e7dfd3689  movaps [rsi], xmm5
0000773e7dfd368c  movaps [rdx], xmm1
0000773e7dfd368f  movaps [rcx], xmm14
0000773e7dfd3693  mov rax, 0x567852F34A50
0000773e7dfd369d  call rax
0000773e7dfd369f  movaps xmm15, [rsp]
0000773e7dfd36a4  add rsp, 0x40
0000773e7dfd36a8  vmovaps xmm0, [rsp]
0000773e7dfd36ad  vmovaps xmm1, [rsp+0x10]
0000773e7dfd36b3  vmovaps xmm2, [rsp+0x20]
0000773e7dfd36b9  vmovaps xmm3, [rsp+0x30]
0000773e7dfd36bf  vmovaps xmm4, [rsp+0x40]
0000773e7dfd36c5  vmovaps xmm5, [rsp+0x50]
0000773e7dfd36cb  vmovaps xmm6, [rsp+0x60]
0000773e7dfd36d1  vmovaps xmm7, [rsp+0x70]
0000773e7dfd36d7  vmovaps xmm8, [rsp+0x80]
0000773e7dfd36e0  vmovaps xmm9, [rsp+0x90]
0000773e7dfd36e9  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd36f2  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd36fb  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd3704  vmovaps xmm13, [rsp+0xD0]
0000773e7dfd370d  vmovaps xmm14, [rsp+0xE0]
0000773e7dfd3716  add rsp, 0xF0
0000773e7dfd371d  pop r11
0000773e7dfd371f  pop r10
0000773e7dfd3721  pop r9
0000773e7dfd3723  pop r8
0000773e7dfd3725  pop rsi
0000773e7dfd3726  pop rdi
0000773e7dfd3727  pop rdx
0000773e7dfd3728  pop rcx
0000773e7dfd3729  pop rax
0000773e7dfd372a  add rsp, 0x08
0000773e7dfd372e  jmp 0x0000773E7DFD28D0
0000773e7dfd3733  call 0x0000773E7DDFF430
0000773e7dfd3738  jmp 0x0000773E7DFD295D
0000773e7dfd373d  sub rsp, 0x08
0000773e7dfd3741  push rax
0000773e7dfd3742  push rcx
0000773e7dfd3743  push rdx
0000773e7dfd3744  push rdi
0000773e7dfd3745  push rsi
0000773e7dfd3746  push r8
0000773e7dfd3748  push r9
0000773e7dfd374a  push r10
0000773e7dfd374c  push r11
0000773e7dfd374e  sub rsp, 0xF0
0000773e7dfd3755  vmovaps [rsp], xmm0
0000773e7dfd375a  vmovaps [rsp+0x10], xmm1
0000773e7dfd3760  vmovaps [rsp+0x20], xmm2
0000773e7dfd3766  vmovaps [rsp+0x30], xmm3
0000773e7dfd376c  vmovaps [rsp+0x40], xmm4
0000773e7dfd3772  vmovaps [rsp+0x50], xmm5
0000773e7dfd3778  vmovaps [rsp+0x60], xmm6
0000773e7dfd377e  vmovaps [rsp+0x70], xmm7
0000773e7dfd3784  vmovaps [rsp+0x80], xmm8
0000773e7dfd378d  vmovaps [rsp+0x90], xmm9
0000773e7dfd3796  vmovaps [rsp+0xA0], xmm10
0000773e7dfd379f  vmovaps [rsp+0xB0], xmm11
0000773e7dfd37a8  vmovaps [rsp+0xC0], xmm12
0000773e7dfd37b1  vmovaps [rsp+0xD0], xmm14
0000773e7dfd37ba  vmovaps [rsp+0xE0], xmm15
0000773e7dfd37c3  sub rsp, 0x40
0000773e7dfd37c7  lea rdi, [rsp]
0000773e7dfd37cb  lea rsi, [rsp+0x10]
0000773e7dfd37d0  lea rdx, [rsp+0x20]
0000773e7dfd37d5  lea rcx, [rsp+0x30]
0000773e7dfd37da  mov r8d, 0x00
0000773e7dfd37e0  lea r9, [r15+0x3A8]
0000773e7dfd37e7  movaps [rdi], xmm13
0000773e7dfd37eb  movaps [rsi], xmm1
0000773e7dfd37ee  movaps [rdx], xmm15
0000773e7dfd37f2  movaps [rcx], xmm14
0000773e7dfd37f6  mov rax, 0x567852F34A50
0000773e7dfd3800  call rax
0000773e7dfd3802  movaps xmm13, [rsp]
0000773e7dfd3807  add rsp, 0x40
0000773e7dfd380b  vmovaps xmm0, [rsp]
0000773e7dfd3810  vmovaps xmm1, [rsp+0x10]
0000773e7dfd3816  vmovaps xmm2, [rsp+0x20]
0000773e7dfd381c  vmovaps xmm3, [rsp+0x30]
0000773e7dfd3822  vmovaps xmm4, [rsp+0x40]
0000773e7dfd3828  vmovaps xmm5, [rsp+0x50]
0000773e7dfd382e  vmovaps xmm6, [rsp+0x60]
0000773e7dfd3834  vmovaps xmm7, [rsp+0x70]
0000773e7dfd383a  vmovaps xmm8, [rsp+0x80]
0000773e7dfd3843  vmovaps xmm9, [rsp+0x90]
0000773e7dfd384c  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd3855  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd385e  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd3867  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd3870  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd3879  add rsp, 0xF0
0000773e7dfd3880  pop r11
0000773e7dfd3882  pop r10
0000773e7dfd3884  pop r9
0000773e7dfd3886  pop r8
0000773e7dfd3888  pop rsi
0000773e7dfd3889  pop rdi
0000773e7dfd388a  pop rdx
0000773e7dfd388b  pop rcx
0000773e7dfd388c  pop rax
0000773e7dfd388d  add rsp, 0x08
0000773e7dfd3891  jmp 0x0000773E7DFD29C1
0000773e7dfd3896  call 0x0000773E7DDFF430
0000773e7dfd389b  jmp 0x0000773E7DFD29CE
0000773e7dfd38a0  sub rsp, 0x08
0000773e7dfd38a4  push rax
0000773e7dfd38a5  push rcx
0000773e7dfd38a6  push rdx
0000773e7dfd38a7  push rdi
0000773e7dfd38a8  push rsi
0000773e7dfd38a9  push r8
0000773e7dfd38ab  push r9
0000773e7dfd38ad  push r10
0000773e7dfd38af  push r11
0000773e7dfd38b1  sub rsp, 0xF0
0000773e7dfd38b8  vmovaps [rsp], xmm0
0000773e7dfd38bd  vmovaps [rsp+0x10], xmm1
0000773e7dfd38c3  vmovaps [rsp+0x20], xmm2
0000773e7dfd38c9  vmovaps [rsp+0x30], xmm3
0000773e7dfd38cf  vmovaps [rsp+0x40], xmm4
0000773e7dfd38d5  vmovaps [rsp+0x50], xmm5
0000773e7dfd38db  vmovaps [rsp+0x60], xmm6
0000773e7dfd38e1  vmovaps [rsp+0x70], xmm7
0000773e7dfd38e7  vmovaps [rsp+0x80], xmm8
0000773e7dfd38f0  vmovaps [rsp+0x90], xmm9
0000773e7dfd38f9  vmovaps [rsp+0xA0], xmm10
0000773e7dfd3902  vmovaps [rsp+0xB0], xmm11
0000773e7dfd390b  vmovaps [rsp+0xC0], xmm13
0000773e7dfd3914  vmovaps [rsp+0xD0], xmm14
0000773e7dfd391d  vmovaps [rsp+0xE0], xmm15
0000773e7dfd3926  sub rsp, 0x40
0000773e7dfd392a  lea rdi, [rsp]
0000773e7dfd392e  lea rsi, [rsp+0x10]
0000773e7dfd3933  lea rdx, [rsp+0x20]
0000773e7dfd3938  lea rcx, [rsp+0x30]
0000773e7dfd393d  mov r8d, 0x00
0000773e7dfd3943  lea r9, [r15+0x3A8]
0000773e7dfd394a  movaps [rdi], xmm12
0000773e7dfd394e  movaps [rsi], xmm15
0000773e7dfd3952  movaps [rdx], xmm1
0000773e7dfd3955  movaps [rcx], xmm14
0000773e7dfd3959  mov rax, 0x567852F34A50
0000773e7dfd3963  call rax
0000773e7dfd3965  movaps xmm12, [rsp]
0000773e7dfd396a  add rsp, 0x40
0000773e7dfd396e  vmovaps xmm0, [rsp]
0000773e7dfd3973  vmovaps xmm1, [rsp+0x10]
0000773e7dfd3979  vmovaps xmm2, [rsp+0x20]
0000773e7dfd397f  vmovaps xmm3, [rsp+0x30]
0000773e7dfd3985  vmovaps xmm4, [rsp+0x40]
0000773e7dfd398b  vmovaps xmm5, [rsp+0x50]
0000773e7dfd3991  vmovaps xmm6, [rsp+0x60]
0000773e7dfd3997  vmovaps xmm7, [rsp+0x70]
0000773e7dfd399d  vmovaps xmm8, [rsp+0x80]
0000773e7dfd39a6  vmovaps xmm9, [rsp+0x90]
0000773e7dfd39af  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd39b8  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd39c1  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd39ca  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd39d3  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd39dc  add rsp, 0xF0
0000773e7dfd39e3  pop r11
0000773e7dfd39e5  pop r10
0000773e7dfd39e7  pop r9
0000773e7dfd39e9  pop r8
0000773e7dfd39eb  pop rsi
0000773e7dfd39ec  pop rdi
0000773e7dfd39ed  pop rdx
0000773e7dfd39ee  pop rcx
0000773e7dfd39ef  pop rax
0000773e7dfd39f0  add rsp, 0x08
0000773e7dfd39f4  jmp 0x0000773E7DFD29FA
0000773e7dfd39f9  sub rsp, 0x08
0000773e7dfd39fd  push rax
0000773e7dfd39fe  push rcx
0000773e7dfd39ff  push rdx
0000773e7dfd3a00  push rdi
0000773e7dfd3a01  push rsi
0000773e7dfd3a02  push r8
0000773e7dfd3a04  push r9
0000773e7dfd3a06  push r10
0000773e7dfd3a08  push r11
0000773e7dfd3a0a  sub rsp, 0xF0
0000773e7dfd3a11  vmovaps [rsp], xmm0
0000773e7dfd3a16  vmovaps [rsp+0x10], xmm1
0000773e7dfd3a1c  vmovaps [rsp+0x20], xmm2
0000773e7dfd3a22  vmovaps [rsp+0x30], xmm3
0000773e7dfd3a28  vmovaps [rsp+0x40], xmm4
0000773e7dfd3a2e  vmovaps [rsp+0x50], xmm5
0000773e7dfd3a34  vmovaps [rsp+0x60], xmm6
0000773e7dfd3a3a  vmovaps [rsp+0x70], xmm7
0000773e7dfd3a40  vmovaps [rsp+0x80], xmm8
0000773e7dfd3a49  vmovaps [rsp+0x90], xmm9
0000773e7dfd3a52  vmovaps [rsp+0xA0], xmm10
0000773e7dfd3a5b  vmovaps [rsp+0xB0], xmm11
0000773e7dfd3a64  vmovaps [rsp+0xC0], xmm12
0000773e7dfd3a6d  vmovaps [rsp+0xD0], xmm14
0000773e7dfd3a76  vmovaps [rsp+0xE0], xmm15
0000773e7dfd3a7f  sub rsp, 0x40
0000773e7dfd3a83  lea rdi, [rsp]
0000773e7dfd3a87  lea rsi, [rsp+0x10]
0000773e7dfd3a8c  lea rdx, [rsp+0x20]
0000773e7dfd3a91  lea rcx, [rsp+0x30]
0000773e7dfd3a96  mov r8d, 0x00
0000773e7dfd3a9c  lea r9, [r15+0x3A8]
0000773e7dfd3aa3  movaps [rdi], xmm13
0000773e7dfd3aa7  movaps [rsi], xmm1
0000773e7dfd3aaa  movaps [rdx], xmm15
0000773e7dfd3aae  movaps [rcx], xmm14
0000773e7dfd3ab2  mov rax, 0x567852F34A50
0000773e7dfd3abc  call rax
0000773e7dfd3abe  movaps xmm13, [rsp]
0000773e7dfd3ac3  add rsp, 0x40
0000773e7dfd3ac7  vmovaps xmm0, [rsp]
0000773e7dfd3acc  vmovaps xmm1, [rsp+0x10]
0000773e7dfd3ad2  vmovaps xmm2, [rsp+0x20]
0000773e7dfd3ad8  vmovaps xmm3, [rsp+0x30]
0000773e7dfd3ade  vmovaps xmm4, [rsp+0x40]
0000773e7dfd3ae4  vmovaps xmm5, [rsp+0x50]
0000773e7dfd3aea  vmovaps xmm6, [rsp+0x60]
0000773e7dfd3af0  vmovaps xmm7, [rsp+0x70]
0000773e7dfd3af6  vmovaps xmm8, [rsp+0x80]
0000773e7dfd3aff  vmovaps xmm9, [rsp+0x90]
0000773e7dfd3b08  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd3b11  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd3b1a  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd3b23  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd3b2c  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd3b35  add rsp, 0xF0
0000773e7dfd3b3c  pop r11
0000773e7dfd3b3e  pop r10
0000773e7dfd3b40  pop r9
0000773e7dfd3b42  pop r8
0000773e7dfd3b44  pop rsi
0000773e7dfd3b45  pop rdi
0000773e7dfd3b46  pop rdx
0000773e7dfd3b47  pop rcx
0000773e7dfd3b48  pop rax
0000773e7dfd3b49  add rsp, 0x08
0000773e7dfd3b4d  jmp 0x0000773E7DFD2B77
0000773e7dfd3b52  sub rsp, 0x08
0000773e7dfd3b56  push rax
0000773e7dfd3b57  push rcx
0000773e7dfd3b58  push rdx
0000773e7dfd3b59  push rdi
0000773e7dfd3b5a  push rsi
0000773e7dfd3b5b  push r8
0000773e7dfd3b5d  push r9
0000773e7dfd3b5f  push r10
0000773e7dfd3b61  push r11
0000773e7dfd3b63  sub rsp, 0xF0
0000773e7dfd3b6a  vmovaps [rsp], xmm0
0000773e7dfd3b6f  vmovaps [rsp+0x10], xmm1
0000773e7dfd3b75  vmovaps [rsp+0x20], xmm2
0000773e7dfd3b7b  vmovaps [rsp+0x30], xmm3
0000773e7dfd3b81  vmovaps [rsp+0x40], xmm4
0000773e7dfd3b87  vmovaps [rsp+0x50], xmm5
0000773e7dfd3b8d  vmovaps [rsp+0x60], xmm6
0000773e7dfd3b93  vmovaps [rsp+0x70], xmm7
0000773e7dfd3b99  vmovaps [rsp+0x80], xmm8
0000773e7dfd3ba2  vmovaps [rsp+0x90], xmm9
0000773e7dfd3bab  vmovaps [rsp+0xA0], xmm10
0000773e7dfd3bb4  vmovaps [rsp+0xB0], xmm11
0000773e7dfd3bbd  vmovaps [rsp+0xC0], xmm13
0000773e7dfd3bc6  vmovaps [rsp+0xD0], xmm14
0000773e7dfd3bcf  vmovaps [rsp+0xE0], xmm15
0000773e7dfd3bd8  sub rsp, 0x40
0000773e7dfd3bdc  lea rdi, [rsp]
0000773e7dfd3be0  lea rsi, [rsp+0x10]
0000773e7dfd3be5  lea rdx, [rsp+0x20]
0000773e7dfd3bea  lea rcx, [rsp+0x30]
0000773e7dfd3bef  mov r8d, 0x00
0000773e7dfd3bf5  lea r9, [r15+0x3A8]
0000773e7dfd3bfc  movaps [rdi], xmm12
0000773e7dfd3c00  movaps [rsi], xmm15
0000773e7dfd3c04  movaps [rdx], xmm14
0000773e7dfd3c08  movaps [rcx], xmm1
0000773e7dfd3c0b  mov rax, 0x567852F34A50
0000773e7dfd3c15  call rax
0000773e7dfd3c17  movaps xmm12, [rsp]
0000773e7dfd3c1c  add rsp, 0x40
0000773e7dfd3c20  vmovaps xmm0, [rsp]
0000773e7dfd3c25  vmovaps xmm1, [rsp+0x10]
0000773e7dfd3c2b  vmovaps xmm2, [rsp+0x20]
0000773e7dfd3c31  vmovaps xmm3, [rsp+0x30]
0000773e7dfd3c37  vmovaps xmm4, [rsp+0x40]
0000773e7dfd3c3d  vmovaps xmm5, [rsp+0x50]
0000773e7dfd3c43  vmovaps xmm6, [rsp+0x60]
0000773e7dfd3c49  vmovaps xmm7, [rsp+0x70]
0000773e7dfd3c4f  vmovaps xmm8, [rsp+0x80]
0000773e7dfd3c58  vmovaps xmm9, [rsp+0x90]
0000773e7dfd3c61  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd3c6a  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd3c73  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd3c7c  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd3c85  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd3c8e  add rsp, 0xF0
0000773e7dfd3c95  pop r11
0000773e7dfd3c97  pop r10
0000773e7dfd3c99  pop r9
0000773e7dfd3c9b  pop r8
0000773e7dfd3c9d  pop rsi
0000773e7dfd3c9e  pop rdi
0000773e7dfd3c9f  pop rdx
0000773e7dfd3ca0  pop rcx
0000773e7dfd3ca1  pop rax
0000773e7dfd3ca2  add rsp, 0x08
0000773e7dfd3ca6  jmp 0x0000773E7DFD2BB2
0000773e7dfd3cab  sub rsp, 0x08
0000773e7dfd3caf  push rax
0000773e7dfd3cb0  push rcx
0000773e7dfd3cb1  push rdx
0000773e7dfd3cb2  push rdi
0000773e7dfd3cb3  push rsi
0000773e7dfd3cb4  push r8
0000773e7dfd3cb6  push r9
0000773e7dfd3cb8  push r10
0000773e7dfd3cba  push r11
0000773e7dfd3cbc  sub rsp, 0xF0
0000773e7dfd3cc3  vmovaps [rsp], xmm0
0000773e7dfd3cc8  vmovaps [rsp+0x10], xmm1
0000773e7dfd3cce  vmovaps [rsp+0x20], xmm2
0000773e7dfd3cd4  vmovaps [rsp+0x30], xmm3
0000773e7dfd3cda  vmovaps [rsp+0x40], xmm4
0000773e7dfd3ce0  vmovaps [rsp+0x50], xmm5
0000773e7dfd3ce6  vmovaps [rsp+0x60], xmm6
0000773e7dfd3cec  vmovaps [rsp+0x70], xmm7
0000773e7dfd3cf2  vmovaps [rsp+0x80], xmm8
0000773e7dfd3cfb  vmovaps [rsp+0x90], xmm9
0000773e7dfd3d04  vmovaps [rsp+0xA0], xmm10
0000773e7dfd3d0d  vmovaps [rsp+0xB0], xmm11
0000773e7dfd3d16  vmovaps [rsp+0xC0], xmm12
0000773e7dfd3d1f  vmovaps [rsp+0xD0], xmm14
0000773e7dfd3d28  vmovaps [rsp+0xE0], xmm15
0000773e7dfd3d31  sub rsp, 0x40
0000773e7dfd3d35  lea rdi, [rsp]
0000773e7dfd3d39  lea rsi, [rsp+0x10]
0000773e7dfd3d3e  lea rdx, [rsp+0x20]
0000773e7dfd3d43  lea rcx, [rsp+0x30]
0000773e7dfd3d48  mov r8d, 0x00
0000773e7dfd3d4e  lea r9, [r15+0x3A8]
0000773e7dfd3d55  movaps [rdi], xmm13
0000773e7dfd3d59  movaps [rsi], xmm15
0000773e7dfd3d5d  movaps [rdx], xmm14
0000773e7dfd3d61  movaps [rcx], xmm1
0000773e7dfd3d64  mov rax, 0x567852F34A50
0000773e7dfd3d6e  call rax
0000773e7dfd3d70  movaps xmm13, [rsp]
0000773e7dfd3d75  add rsp, 0x40
0000773e7dfd3d79  vmovaps xmm0, [rsp]
0000773e7dfd3d7e  vmovaps xmm1, [rsp+0x10]
0000773e7dfd3d84  vmovaps xmm2, [rsp+0x20]
0000773e7dfd3d8a  vmovaps xmm3, [rsp+0x30]
0000773e7dfd3d90  vmovaps xmm4, [rsp+0x40]
0000773e7dfd3d96  vmovaps xmm5, [rsp+0x50]
0000773e7dfd3d9c  vmovaps xmm6, [rsp+0x60]
0000773e7dfd3da2  vmovaps xmm7, [rsp+0x70]
0000773e7dfd3da8  vmovaps xmm8, [rsp+0x80]
0000773e7dfd3db1  vmovaps xmm9, [rsp+0x90]
0000773e7dfd3dba  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd3dc3  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd3dcc  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd3dd5  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd3dde  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd3de7  add rsp, 0xF0
0000773e7dfd3dee  pop r11
0000773e7dfd3df0  pop r10
0000773e7dfd3df2  pop r9
0000773e7dfd3df4  pop r8
0000773e7dfd3df6  pop rsi
0000773e7dfd3df7  pop rdi
0000773e7dfd3df8  pop rdx
0000773e7dfd3df9  pop rcx
0000773e7dfd3dfa  pop rax
0000773e7dfd3dfb  add rsp, 0x08
0000773e7dfd3dff  jmp 0x0000773E7DFD2BEA
0000773e7dfd3e04  sub rsp, 0x08
0000773e7dfd3e08  push rax
0000773e7dfd3e09  push rcx
0000773e7dfd3e0a  push rdx
0000773e7dfd3e0b  push rdi
0000773e7dfd3e0c  push rsi
0000773e7dfd3e0d  push r8
0000773e7dfd3e0f  push r9
0000773e7dfd3e11  push r10
0000773e7dfd3e13  push r11
0000773e7dfd3e15  sub rsp, 0xF0
0000773e7dfd3e1c  vmovaps [rsp], xmm0
0000773e7dfd3e21  vmovaps [rsp+0x10], xmm1
0000773e7dfd3e27  vmovaps [rsp+0x20], xmm2
0000773e7dfd3e2d  vmovaps [rsp+0x30], xmm3
0000773e7dfd3e33  vmovaps [rsp+0x40], xmm4
0000773e7dfd3e39  vmovaps [rsp+0x50], xmm5
0000773e7dfd3e3f  vmovaps [rsp+0x60], xmm6
0000773e7dfd3e45  vmovaps [rsp+0x70], xmm7
0000773e7dfd3e4b  vmovaps [rsp+0x80], xmm8
0000773e7dfd3e54  vmovaps [rsp+0x90], xmm9
0000773e7dfd3e5d  vmovaps [rsp+0xA0], xmm10
0000773e7dfd3e66  vmovaps [rsp+0xB0], xmm11
0000773e7dfd3e6f  vmovaps [rsp+0xC0], xmm13
0000773e7dfd3e78  vmovaps [rsp+0xD0], xmm14
0000773e7dfd3e81  vmovaps [rsp+0xE0], xmm15
0000773e7dfd3e8a  sub rsp, 0x40
0000773e7dfd3e8e  lea rdi, [rsp]
0000773e7dfd3e92  lea rsi, [rsp+0x10]
0000773e7dfd3e97  lea rdx, [rsp+0x20]
0000773e7dfd3e9c  lea rcx, [rsp+0x30]
0000773e7dfd3ea1  mov r8d, 0x00
0000773e7dfd3ea7  lea r9, [r15+0x3A8]
0000773e7dfd3eae  movaps [rdi], xmm12
0000773e7dfd3eb2  movaps [rsi], xmm15
0000773e7dfd3eb6  movaps [rdx], xmm14
0000773e7dfd3eba  movaps [rcx], xmm1
0000773e7dfd3ebd  mov rax, 0x567852F34A50
0000773e7dfd3ec7  call rax
0000773e7dfd3ec9  movaps xmm12, [rsp]
0000773e7dfd3ece  add rsp, 0x40
0000773e7dfd3ed2  vmovaps xmm0, [rsp]
0000773e7dfd3ed7  vmovaps xmm1, [rsp+0x10]
0000773e7dfd3edd  vmovaps xmm2, [rsp+0x20]
0000773e7dfd3ee3  vmovaps xmm3, [rsp+0x30]
0000773e7dfd3ee9  vmovaps xmm4, [rsp+0x40]
0000773e7dfd3eef  vmovaps xmm5, [rsp+0x50]
0000773e7dfd3ef5  vmovaps xmm6, [rsp+0x60]
0000773e7dfd3efb  vmovaps xmm7, [rsp+0x70]
0000773e7dfd3f01  vmovaps xmm8, [rsp+0x80]
0000773e7dfd3f0a  vmovaps xmm9, [rsp+0x90]
0000773e7dfd3f13  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd3f1c  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd3f25  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd3f2e  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd3f37  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd3f40  add rsp, 0xF0
0000773e7dfd3f47  pop r11
0000773e7dfd3f49  pop r10
0000773e7dfd3f4b  pop r9
0000773e7dfd3f4d  pop r8
0000773e7dfd3f4f  pop rsi
0000773e7dfd3f50  pop rdi
0000773e7dfd3f51  pop rdx
0000773e7dfd3f52  pop rcx
0000773e7dfd3f53  pop rax
0000773e7dfd3f54  add rsp, 0x08
0000773e7dfd3f58  jmp 0x0000773E7DFD2C3D
0000773e7dfd3f5d  sub rsp, 0x08
0000773e7dfd3f61  push rax
0000773e7dfd3f62  push rcx
0000773e7dfd3f63  push rdx
0000773e7dfd3f64  push rdi
0000773e7dfd3f65  push rsi
0000773e7dfd3f66  push r8
0000773e7dfd3f68  push r9
0000773e7dfd3f6a  push r10
0000773e7dfd3f6c  push r11
0000773e7dfd3f6e  sub rsp, 0xF0
0000773e7dfd3f75  vmovaps [rsp], xmm0
0000773e7dfd3f7a  vmovaps [rsp+0x10], xmm1
0000773e7dfd3f80  vmovaps [rsp+0x20], xmm2
0000773e7dfd3f86  vmovaps [rsp+0x30], xmm3
0000773e7dfd3f8c  vmovaps [rsp+0x40], xmm4
0000773e7dfd3f92  vmovaps [rsp+0x50], xmm5
0000773e7dfd3f98  vmovaps [rsp+0x60], xmm6
0000773e7dfd3f9e  vmovaps [rsp+0x70], xmm7
0000773e7dfd3fa4  vmovaps [rsp+0x80], xmm8
0000773e7dfd3fad  vmovaps [rsp+0x90], xmm9
0000773e7dfd3fb6  vmovaps [rsp+0xA0], xmm10
0000773e7dfd3fbf  vmovaps [rsp+0xB0], xmm11
0000773e7dfd3fc8  vmovaps [rsp+0xC0], xmm12
0000773e7dfd3fd1  vmovaps [rsp+0xD0], xmm13
0000773e7dfd3fda  vmovaps [rsp+0xE0], xmm15
0000773e7dfd3fe3  sub rsp, 0x40
0000773e7dfd3fe7  lea rdi, [rsp]
0000773e7dfd3feb  lea rsi, [rsp+0x10]
0000773e7dfd3ff0  lea rdx, [rsp+0x20]
0000773e7dfd3ff5  lea rcx, [rsp+0x30]
0000773e7dfd3ffa  mov r8d, 0x00
0000773e7dfd4000  lea r9, [r15+0x3A8]
0000773e7dfd4007  movaps [rdi], xmm14
0000773e7dfd400b  movaps [rsi], xmm3
0000773e7dfd400e  movaps [rdx], xmm1
0000773e7dfd4011  movaps [rcx], xmm15
0000773e7dfd4015  mov rax, 0x567852F34A50
0000773e7dfd401f  call rax
0000773e7dfd4021  movaps xmm14, [rsp]
0000773e7dfd4026  add rsp, 0x40
0000773e7dfd402a  vmovaps xmm0, [rsp]
0000773e7dfd402f  vmovaps xmm1, [rsp+0x10]
0000773e7dfd4035  vmovaps xmm2, [rsp+0x20]
0000773e7dfd403b  vmovaps xmm3, [rsp+0x30]
0000773e7dfd4041  vmovaps xmm4, [rsp+0x40]
0000773e7dfd4047  vmovaps xmm5, [rsp+0x50]
0000773e7dfd404d  vmovaps xmm6, [rsp+0x60]
0000773e7dfd4053  vmovaps xmm7, [rsp+0x70]
0000773e7dfd4059  vmovaps xmm8, [rsp+0x80]
0000773e7dfd4062  vmovaps xmm9, [rsp+0x90]
0000773e7dfd406b  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd4074  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd407d  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd4086  vmovaps xmm13, [rsp+0xD0]
0000773e7dfd408f  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd4098  add rsp, 0xF0
0000773e7dfd409f  pop r11
0000773e7dfd40a1  pop r10
0000773e7dfd40a3  pop r9
0000773e7dfd40a5  pop r8
0000773e7dfd40a7  pop rsi
0000773e7dfd40a8  pop rdi
0000773e7dfd40a9  pop rdx
0000773e7dfd40aa  pop rcx
0000773e7dfd40ab  pop rax
0000773e7dfd40ac  add rsp, 0x08
0000773e7dfd40b0  jmp 0x0000773E7DFD2CF7
0000773e7dfd40b5  sub rsp, 0x08
0000773e7dfd40b9  push rax
0000773e7dfd40ba  push rcx
0000773e7dfd40bb  push rdx
0000773e7dfd40bc  push rdi
0000773e7dfd40bd  push rsi
0000773e7dfd40be  push r8
0000773e7dfd40c0  push r9
0000773e7dfd40c2  push r10
0000773e7dfd40c4  push r11
0000773e7dfd40c6  sub rsp, 0xF0
0000773e7dfd40cd  vmovaps [rsp], xmm0
0000773e7dfd40d2  vmovaps [rsp+0x10], xmm1
0000773e7dfd40d8  vmovaps [rsp+0x20], xmm2
0000773e7dfd40de  vmovaps [rsp+0x30], xmm3
0000773e7dfd40e4  vmovaps [rsp+0x40], xmm4
0000773e7dfd40ea  vmovaps [rsp+0x50], xmm5
0000773e7dfd40f0  vmovaps [rsp+0x60], xmm6
0000773e7dfd40f6  vmovaps [rsp+0x70], xmm7
0000773e7dfd40fc  vmovaps [rsp+0x80], xmm8
0000773e7dfd4105  vmovaps [rsp+0x90], xmm9
0000773e7dfd410e  vmovaps [rsp+0xA0], xmm10
0000773e7dfd4117  vmovaps [rsp+0xB0], xmm11
0000773e7dfd4120  vmovaps [rsp+0xC0], xmm12
0000773e7dfd4129  vmovaps [rsp+0xD0], xmm14
0000773e7dfd4132  vmovaps [rsp+0xE0], xmm15
0000773e7dfd413b  sub rsp, 0x40
0000773e7dfd413f  lea rdi, [rsp]
0000773e7dfd4143  lea rsi, [rsp+0x10]
0000773e7dfd4148  lea rdx, [rsp+0x20]
0000773e7dfd414d  lea rcx, [rsp+0x30]
0000773e7dfd4152  mov r8d, 0x00
0000773e7dfd4158  lea r9, [r15+0x3A8]
0000773e7dfd415f  movaps [rdi], xmm13
0000773e7dfd4163  movaps [rsi], xmm15
0000773e7dfd4167  movaps [rdx], xmm10
0000773e7dfd416b  movaps [rcx], xmm1
0000773e7dfd416e  mov rax, 0x567852F34A50
0000773e7dfd4178  call rax
0000773e7dfd417a  movaps xmm13, [rsp]
0000773e7dfd417f  add rsp, 0x40
0000773e7dfd4183  vmovaps xmm0, [rsp]
0000773e7dfd4188  vmovaps xmm1, [rsp+0x10]
0000773e7dfd418e  vmovaps xmm2, [rsp+0x20]
0000773e7dfd4194  vmovaps xmm3, [rsp+0x30]
0000773e7dfd419a  vmovaps xmm4, [rsp+0x40]
0000773e7dfd41a0  vmovaps xmm5, [rsp+0x50]
0000773e7dfd41a6  vmovaps xmm6, [rsp+0x60]
0000773e7dfd41ac  vmovaps xmm7, [rsp+0x70]
0000773e7dfd41b2  vmovaps xmm8, [rsp+0x80]
0000773e7dfd41bb  vmovaps xmm9, [rsp+0x90]
0000773e7dfd41c4  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd41cd  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd41d6  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd41df  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd41e8  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd41f1  add rsp, 0xF0
0000773e7dfd41f8  pop r11
0000773e7dfd41fa  pop r10
0000773e7dfd41fc  pop r9
0000773e7dfd41fe  pop r8
0000773e7dfd4200  pop rsi
0000773e7dfd4201  pop rdi
0000773e7dfd4202  pop rdx
0000773e7dfd4203  pop rcx
0000773e7dfd4204  pop rax
0000773e7dfd4205  add rsp, 0x08
0000773e7dfd4209  jmp 0x0000773E7DFD2D26
0000773e7dfd420e  sub rsp, 0x08
0000773e7dfd4212  push rax
0000773e7dfd4213  push rcx
0000773e7dfd4214  push rdx
0000773e7dfd4215  push rdi
0000773e7dfd4216  push rsi
0000773e7dfd4217  push r8
0000773e7dfd4219  push r9
0000773e7dfd421b  push r10
0000773e7dfd421d  push r11
0000773e7dfd421f  sub rsp, 0xF0
0000773e7dfd4226  vmovaps [rsp], xmm0
0000773e7dfd422b  vmovaps [rsp+0x10], xmm1
0000773e7dfd4231  vmovaps [rsp+0x20], xmm2
0000773e7dfd4237  vmovaps [rsp+0x30], xmm3
0000773e7dfd423d  vmovaps [rsp+0x40], xmm4
0000773e7dfd4243  vmovaps [rsp+0x50], xmm5
0000773e7dfd4249  vmovaps [rsp+0x60], xmm6
0000773e7dfd424f  vmovaps [rsp+0x70], xmm7
0000773e7dfd4255  vmovaps [rsp+0x80], xmm8
0000773e7dfd425e  vmovaps [rsp+0x90], xmm9
0000773e7dfd4267  vmovaps [rsp+0xA0], xmm11
0000773e7dfd4270  vmovaps [rsp+0xB0], xmm12
0000773e7dfd4279  vmovaps [rsp+0xC0], xmm13
0000773e7dfd4282  vmovaps [rsp+0xD0], xmm14
0000773e7dfd428b  vmovaps [rsp+0xE0], xmm15
0000773e7dfd4294  sub rsp, 0x40
0000773e7dfd4298  lea rdi, [rsp]
0000773e7dfd429c  lea rsi, [rsp+0x10]
0000773e7dfd42a1  lea rdx, [rsp+0x20]
0000773e7dfd42a6  lea rcx, [rsp+0x30]
0000773e7dfd42ab  mov r8d, 0x00
0000773e7dfd42b1  lea r9, [r15+0x3A8]
0000773e7dfd42b8  movaps [rdi], xmm10
0000773e7dfd42bc  movaps [rsi], xmm15
0000773e7dfd42c0  movaps [rdx], xmm11
0000773e7dfd42c4  movaps [rcx], xmm1
0000773e7dfd42c7  mov rax, 0x567852F34A50
0000773e7dfd42d1  call rax
0000773e7dfd42d3  movaps xmm10, [rsp]
0000773e7dfd42d8  add rsp, 0x40
0000773e7dfd42dc  vmovaps xmm0, [rsp]
0000773e7dfd42e1  vmovaps xmm1, [rsp+0x10]
0000773e7dfd42e7  vmovaps xmm2, [rsp+0x20]
0000773e7dfd42ed  vmovaps xmm3, [rsp+0x30]
0000773e7dfd42f3  vmovaps xmm4, [rsp+0x40]
0000773e7dfd42f9  vmovaps xmm5, [rsp+0x50]
0000773e7dfd42ff  vmovaps xmm6, [rsp+0x60]
0000773e7dfd4305  vmovaps xmm7, [rsp+0x70]
0000773e7dfd430b  vmovaps xmm8, [rsp+0x80]
0000773e7dfd4314  vmovaps xmm9, [rsp+0x90]
0000773e7dfd431d  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd4326  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd432f  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd4338  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd4341  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd434a  add rsp, 0xF0
0000773e7dfd4351  pop r11
0000773e7dfd4353  pop r10
0000773e7dfd4355  pop r9
0000773e7dfd4357  pop r8
0000773e7dfd4359  pop rsi
0000773e7dfd435a  pop rdi
0000773e7dfd435b  pop rdx
0000773e7dfd435c  pop rcx
0000773e7dfd435d  pop rax
0000773e7dfd435e  add rsp, 0x08
0000773e7dfd4362  jmp 0x0000773E7DFD2D55
0000773e7dfd4367  sub rsp, 0x08
0000773e7dfd436b  push rax
0000773e7dfd436c  push rcx
0000773e7dfd436d  push rdx
0000773e7dfd436e  push rdi
0000773e7dfd436f  push rsi
0000773e7dfd4370  push r8
0000773e7dfd4372  push r9
0000773e7dfd4374  push r10
0000773e7dfd4376  push r11
0000773e7dfd4378  sub rsp, 0xF0
0000773e7dfd437f  vmovaps [rsp], xmm0
0000773e7dfd4384  vmovaps [rsp+0x10], xmm1
0000773e7dfd438a  vmovaps [rsp+0x20], xmm2
0000773e7dfd4390  vmovaps [rsp+0x30], xmm3
0000773e7dfd4396  vmovaps [rsp+0x40], xmm4
0000773e7dfd439c  vmovaps [rsp+0x50], xmm5
0000773e7dfd43a2  vmovaps [rsp+0x60], xmm6
0000773e7dfd43a8  vmovaps [rsp+0x70], xmm7
0000773e7dfd43ae  vmovaps [rsp+0x80], xmm8
0000773e7dfd43b7  vmovaps [rsp+0x90], xmm9
0000773e7dfd43c0  vmovaps [rsp+0xA0], xmm10
0000773e7dfd43c9  vmovaps [rsp+0xB0], xmm11
0000773e7dfd43d2  vmovaps [rsp+0xC0], xmm12
0000773e7dfd43db  vmovaps [rsp+0xD0], xmm13
0000773e7dfd43e4  vmovaps [rsp+0xE0], xmm14
0000773e7dfd43ed  sub rsp, 0x40
0000773e7dfd43f1  lea rdi, [rsp]
0000773e7dfd43f5  lea rsi, [rsp+0x10]
0000773e7dfd43fa  lea rdx, [rsp+0x20]
0000773e7dfd43ff  lea rcx, [rsp+0x30]
0000773e7dfd4404  mov r8d, 0x00
0000773e7dfd440a  lea r9, [r15+0x3A8]
0000773e7dfd4411  movaps [rdi], xmm15
0000773e7dfd4415  movaps [rsi], xmm12
0000773e7dfd4419  movaps [rdx], xmm5
0000773e7dfd441c  movaps [rcx], xmm1
0000773e7dfd441f  mov rax, 0x567852F34A50
0000773e7dfd4429  call rax
0000773e7dfd442b  movaps xmm15, [rsp]
0000773e7dfd4430  add rsp, 0x40
0000773e7dfd4434  vmovaps xmm0, [rsp]
0000773e7dfd4439  vmovaps xmm1, [rsp+0x10]
0000773e7dfd443f  vmovaps xmm2, [rsp+0x20]
0000773e7dfd4445  vmovaps xmm3, [rsp+0x30]
0000773e7dfd444b  vmovaps xmm4, [rsp+0x40]
0000773e7dfd4451  vmovaps xmm5, [rsp+0x50]
0000773e7dfd4457  vmovaps xmm6, [rsp+0x60]
0000773e7dfd445d  vmovaps xmm7, [rsp+0x70]
0000773e7dfd4463  vmovaps xmm8, [rsp+0x80]
0000773e7dfd446c  vmovaps xmm9, [rsp+0x90]
0000773e7dfd4475  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd447e  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd4487  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd4490  vmovaps xmm13, [rsp+0xD0]
0000773e7dfd4499  vmovaps xmm14, [rsp+0xE0]
0000773e7dfd44a2  add rsp, 0xF0
0000773e7dfd44a9  pop r11
0000773e7dfd44ab  pop r10
0000773e7dfd44ad  pop r9
0000773e7dfd44af  pop r8
0000773e7dfd44b1  pop rsi
0000773e7dfd44b2  pop rdi
0000773e7dfd44b3  pop rdx
0000773e7dfd44b4  pop rcx
0000773e7dfd44b5  pop rax
0000773e7dfd44b6  add rsp, 0x08
0000773e7dfd44ba  jmp 0x0000773E7DFD2D7E
0000773e7dfd44bf  sub rsp, 0x08
0000773e7dfd44c3  push rax
0000773e7dfd44c4  push rcx
0000773e7dfd44c5  push rdx
0000773e7dfd44c6  push rdi
0000773e7dfd44c7  push rsi
0000773e7dfd44c8  push r8
0000773e7dfd44ca  push r9
0000773e7dfd44cc  push r10
0000773e7dfd44ce  push r11
0000773e7dfd44d0  sub rsp, 0xF0
0000773e7dfd44d7  vmovaps [rsp], xmm0
0000773e7dfd44dc  vmovaps [rsp+0x10], xmm1
0000773e7dfd44e2  vmovaps [rsp+0x20], xmm2
0000773e7dfd44e8  vmovaps [rsp+0x30], xmm3
0000773e7dfd44ee  vmovaps [rsp+0x40], xmm4
0000773e7dfd44f4  vmovaps [rsp+0x50], xmm6
0000773e7dfd44fa  vmovaps [rsp+0x60], xmm7
0000773e7dfd4500  vmovaps [rsp+0x70], xmm8
0000773e7dfd4506  vmovaps [rsp+0x80], xmm9
0000773e7dfd450f  vmovaps [rsp+0x90], xmm10
0000773e7dfd4518  vmovaps [rsp+0xA0], xmm11
0000773e7dfd4521  vmovaps [rsp+0xB0], xmm12
0000773e7dfd452a  vmovaps [rsp+0xC0], xmm13
0000773e7dfd4533  vmovaps [rsp+0xD0], xmm14
0000773e7dfd453c  vmovaps [rsp+0xE0], xmm15
0000773e7dfd4545  sub rsp, 0x40
0000773e7dfd4549  lea rdi, [rsp]
0000773e7dfd454d  lea rsi, [rsp+0x10]
0000773e7dfd4552  lea rdx, [rsp+0x20]
0000773e7dfd4557  lea rcx, [rsp+0x30]
0000773e7dfd455c  mov r8d, 0x00
0000773e7dfd4562  lea r9, [r15+0x3A8]
0000773e7dfd4569  movaps [rdi], xmm5
0000773e7dfd456c  movaps [rsi], xmm13
0000773e7dfd4570  movaps [rdx], xmm11
0000773e7dfd4574  movaps [rcx], xmm12
0000773e7dfd4578  mov rax, 0x567852F34A50
0000773e7dfd4582  call rax
0000773e7dfd4584  movaps xmm5, [rsp]
0000773e7dfd4588  add rsp, 0x40
0000773e7dfd458c  vmovaps xmm0, [rsp]
0000773e7dfd4591  vmovaps xmm1, [rsp+0x10]
0000773e7dfd4597  vmovaps xmm2, [rsp+0x20]
0000773e7dfd459d  vmovaps xmm3, [rsp+0x30]
0000773e7dfd45a3  vmovaps xmm4, [rsp+0x40]
0000773e7dfd45a9  vmovaps xmm6, [rsp+0x50]
0000773e7dfd45af  vmovaps xmm7, [rsp+0x60]
0000773e7dfd45b5  vmovaps xmm8, [rsp+0x70]
0000773e7dfd45bb  vmovaps xmm9, [rsp+0x80]
0000773e7dfd45c4  vmovaps xmm10, [rsp+0x90]
0000773e7dfd45cd  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd45d6  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd45df  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd45e8  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd45f1  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd45fa  add rsp, 0xF0
0000773e7dfd4601  pop r11
0000773e7dfd4603  pop r10
0000773e7dfd4605  pop r9
0000773e7dfd4607  pop r8
0000773e7dfd4609  pop rsi
0000773e7dfd460a  pop rdi
0000773e7dfd460b  pop rdx
0000773e7dfd460c  pop rcx
0000773e7dfd460d  pop rax
0000773e7dfd460e  add rsp, 0x08
0000773e7dfd4612  jmp 0x0000773E7DFD2DDD
0000773e7dfd4617  sub rsp, 0x08
0000773e7dfd461b  push rax
0000773e7dfd461c  push rcx
0000773e7dfd461d  push rdx
0000773e7dfd461e  push rdi
0000773e7dfd461f  push rsi
0000773e7dfd4620  push r8
0000773e7dfd4622  push r9
0000773e7dfd4624  push r10
0000773e7dfd4626  push r11
0000773e7dfd4628  sub rsp, 0xF0
0000773e7dfd462f  vmovaps [rsp], xmm0
0000773e7dfd4634  vmovaps [rsp+0x10], xmm1
0000773e7dfd463a  vmovaps [rsp+0x20], xmm2
0000773e7dfd4640  vmovaps [rsp+0x30], xmm3
0000773e7dfd4646  vmovaps [rsp+0x40], xmm4
0000773e7dfd464c  vmovaps [rsp+0x50], xmm5
0000773e7dfd4652  vmovaps [rsp+0x60], xmm6
0000773e7dfd4658  vmovaps [rsp+0x70], xmm7
0000773e7dfd465e  vmovaps [rsp+0x80], xmm8
0000773e7dfd4667  vmovaps [rsp+0x90], xmm9
0000773e7dfd4670  vmovaps [rsp+0xA0], xmm10
0000773e7dfd4679  vmovaps [rsp+0xB0], xmm11
0000773e7dfd4682  vmovaps [rsp+0xC0], xmm13
0000773e7dfd468b  vmovaps [rsp+0xD0], xmm14
0000773e7dfd4694  vmovaps [rsp+0xE0], xmm15
0000773e7dfd469d  sub rsp, 0x40
0000773e7dfd46a1  lea rdi, [rsp]
0000773e7dfd46a5  lea rsi, [rsp+0x10]
0000773e7dfd46aa  lea rdx, [rsp+0x20]
0000773e7dfd46af  lea rcx, [rsp+0x30]
0000773e7dfd46b4  mov r8d, 0x00
0000773e7dfd46ba  lea r9, [r15+0x3A8]
0000773e7dfd46c1  movaps [rdi], xmm12
0000773e7dfd46c5  movaps [rsi], xmm14
0000773e7dfd46c9  movaps [rdx], xmm9
0000773e7dfd46cd  movaps [rcx], xmm13
0000773e7dfd46d1  mov rax, 0x567852F34A50
0000773e7dfd46db  call rax
0000773e7dfd46dd  movaps xmm12, [rsp]
0000773e7dfd46e2  add rsp, 0x40
0000773e7dfd46e6  vmovaps xmm0, [rsp]
0000773e7dfd46eb  vmovaps xmm1, [rsp+0x10]
0000773e7dfd46f1  vmovaps xmm2, [rsp+0x20]
0000773e7dfd46f7  vmovaps xmm3, [rsp+0x30]
0000773e7dfd46fd  vmovaps xmm4, [rsp+0x40]
0000773e7dfd4703  vmovaps xmm5, [rsp+0x50]
0000773e7dfd4709  vmovaps xmm6, [rsp+0x60]
0000773e7dfd470f  vmovaps xmm7, [rsp+0x70]
0000773e7dfd4715  vmovaps xmm8, [rsp+0x80]
0000773e7dfd471e  vmovaps xmm9, [rsp+0x90]
0000773e7dfd4727  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd4730  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd4739  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd4742  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd474b  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd4754  add rsp, 0xF0
0000773e7dfd475b  pop r11
0000773e7dfd475d  pop r10
0000773e7dfd475f  pop r9
0000773e7dfd4761  pop r8
0000773e7dfd4763  pop rsi
0000773e7dfd4764  pop rdi
0000773e7dfd4765  pop rdx
0000773e7dfd4766  pop rcx
0000773e7dfd4767  pop rax
0000773e7dfd4768  add rsp, 0x08
0000773e7dfd476c  jmp 0x0000773E7DFD2E06
0000773e7dfd4771  call 0x0000773E7DE0D4E0
0000773e7dfd4776  jmp 0x0000773E7DFD2E13
0000773e7dfd477b  sub rsp, 0x08
0000773e7dfd477f  push rax
0000773e7dfd4780  push rcx
0000773e7dfd4781  push rdx
0000773e7dfd4782  push rdi
0000773e7dfd4783  push rsi
0000773e7dfd4784  push r8
0000773e7dfd4786  push r9
0000773e7dfd4788  push r10
0000773e7dfd478a  push r11
0000773e7dfd478c  sub rsp, 0xF0
0000773e7dfd4793  vmovaps [rsp], xmm0
0000773e7dfd4798  vmovaps [rsp+0x10], xmm1
0000773e7dfd479e  vmovaps [rsp+0x20], xmm2
0000773e7dfd47a4  vmovaps [rsp+0x30], xmm3
0000773e7dfd47aa  vmovaps [rsp+0x40], xmm4
0000773e7dfd47b0  vmovaps [rsp+0x50], xmm5
0000773e7dfd47b6  vmovaps [rsp+0x60], xmm6
0000773e7dfd47bc  vmovaps [rsp+0x70], xmm7
0000773e7dfd47c2  vmovaps [rsp+0x80], xmm8
0000773e7dfd47cb  vmovaps [rsp+0x90], xmm9
0000773e7dfd47d4  vmovaps [rsp+0xA0], xmm10
0000773e7dfd47dd  vmovaps [rsp+0xB0], xmm12
0000773e7dfd47e6  vmovaps [rsp+0xC0], xmm13
0000773e7dfd47ef  vmovaps [rsp+0xD0], xmm14
0000773e7dfd47f8  vmovaps [rsp+0xE0], xmm15
0000773e7dfd4801  sub rsp, 0x40
0000773e7dfd4805  lea rdi, [rsp]
0000773e7dfd4809  lea rsi, [rsp+0x10]
0000773e7dfd480e  lea rdx, [rsp+0x20]
0000773e7dfd4813  lea rcx, [rsp+0x30]
0000773e7dfd4818  mov r8d, 0x00
0000773e7dfd481e  lea r9, [r15+0x3A8]
0000773e7dfd4825  movaps [rdi], xmm11
0000773e7dfd4829  movaps [rsi], xmm10
0000773e7dfd482d  movaps [rdx], xmm8
0000773e7dfd4831  movaps [rcx], xmm13
0000773e7dfd4835  mov rax, 0x567852F34A50
0000773e7dfd483f  call rax
0000773e7dfd4841  movaps xmm11, [rsp]
0000773e7dfd4846  add rsp, 0x40
0000773e7dfd484a  vmovaps xmm0, [rsp]
0000773e7dfd484f  vmovaps xmm1, [rsp+0x10]
0000773e7dfd4855  vmovaps xmm2, [rsp+0x20]
0000773e7dfd485b  vmovaps xmm3, [rsp+0x30]
0000773e7dfd4861  vmovaps xmm4, [rsp+0x40]
0000773e7dfd4867  vmovaps xmm5, [rsp+0x50]
0000773e7dfd486d  vmovaps xmm6, [rsp+0x60]
0000773e7dfd4873  vmovaps xmm7, [rsp+0x70]
0000773e7dfd4879  vmovaps xmm8, [rsp+0x80]
0000773e7dfd4882  vmovaps xmm9, [rsp+0x90]
0000773e7dfd488b  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd4894  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd489d  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd48a6  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd48af  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd48b8  add rsp, 0xF0
0000773e7dfd48bf  pop r11
0000773e7dfd48c1  pop r10
0000773e7dfd48c3  pop r9
0000773e7dfd48c5  pop r8
0000773e7dfd48c7  pop rsi
0000773e7dfd48c8  pop rdi
0000773e7dfd48c9  pop rdx
0000773e7dfd48ca  pop rcx
0000773e7dfd48cb  pop rax
0000773e7dfd48cc  add rsp, 0x08
0000773e7dfd48d0  jmp 0x0000773E7DFD2E44
0000773e7dfd48d5  sub rsp, 0x08
0000773e7dfd48d9  push rax
0000773e7dfd48da  push rcx
0000773e7dfd48db  push rdx
0000773e7dfd48dc  push rdi
0000773e7dfd48dd  push rsi
0000773e7dfd48de  push r8
0000773e7dfd48e0  push r9
0000773e7dfd48e2  push r10
0000773e7dfd48e4  push r11
0000773e7dfd48e6  sub rsp, 0xF0
0000773e7dfd48ed  vmovaps [rsp], xmm0
0000773e7dfd48f2  vmovaps [rsp+0x10], xmm1
0000773e7dfd48f8  vmovaps [rsp+0x20], xmm2
0000773e7dfd48fe  vmovaps [rsp+0x30], xmm3
0000773e7dfd4904  vmovaps [rsp+0x40], xmm4
0000773e7dfd490a  vmovaps [rsp+0x50], xmm5
0000773e7dfd4910  vmovaps [rsp+0x60], xmm6
0000773e7dfd4916  vmovaps [rsp+0x70], xmm7
0000773e7dfd491c  vmovaps [rsp+0x80], xmm8
0000773e7dfd4925  vmovaps [rsp+0x90], xmm9
0000773e7dfd492e  vmovaps [rsp+0xA0], xmm11
0000773e7dfd4937  vmovaps [rsp+0xB0], xmm12
0000773e7dfd4940  vmovaps [rsp+0xC0], xmm13
0000773e7dfd4949  vmovaps [rsp+0xD0], xmm14
0000773e7dfd4952  vmovaps [rsp+0xE0], xmm15
0000773e7dfd495b  sub rsp, 0x40
0000773e7dfd495f  lea rdi, [rsp]
0000773e7dfd4963  lea rsi, [rsp+0x10]
0000773e7dfd4968  lea rdx, [rsp+0x20]
0000773e7dfd496d  lea rcx, [rsp+0x30]
0000773e7dfd4972  mov r8d, 0x00
0000773e7dfd4978  lea r9, [r15+0x3A8]
0000773e7dfd497f  movaps [rdi], xmm10
0000773e7dfd4983  movaps [rsi], xmm15
0000773e7dfd4987  movaps [rdx], xmm1
0000773e7dfd498a  movaps [rcx], xmm13
0000773e7dfd498e  mov rax, 0x567852F34A50
0000773e7dfd4998  call rax
0000773e7dfd499a  movaps xmm10, [rsp]
0000773e7dfd499f  add rsp, 0x40
0000773e7dfd49a3  vmovaps xmm0, [rsp]
0000773e7dfd49a8  vmovaps xmm1, [rsp+0x10]
0000773e7dfd49ae  vmovaps xmm2, [rsp+0x20]
0000773e7dfd49b4  vmovaps xmm3, [rsp+0x30]
0000773e7dfd49ba  vmovaps xmm4, [rsp+0x40]
0000773e7dfd49c0  vmovaps xmm5, [rsp+0x50]
0000773e7dfd49c6  vmovaps xmm6, [rsp+0x60]
0000773e7dfd49cc  vmovaps xmm7, [rsp+0x70]
0000773e7dfd49d2  vmovaps xmm8, [rsp+0x80]
0000773e7dfd49db  vmovaps xmm9, [rsp+0x90]
0000773e7dfd49e4  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd49ed  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd49f6  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd49ff  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd4a08  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd4a11  add rsp, 0xF0
0000773e7dfd4a18  pop r11
0000773e7dfd4a1a  pop r10
0000773e7dfd4a1c  pop r9
0000773e7dfd4a1e  pop r8
0000773e7dfd4a20  pop rsi
0000773e7dfd4a21  pop rdi
0000773e7dfd4a22  pop rdx
0000773e7dfd4a23  pop rcx
0000773e7dfd4a24  pop rax
0000773e7dfd4a25  add rsp, 0x08
0000773e7dfd4a29  jmp 0x0000773E7DFD2E6D
0000773e7dfd4a2e  call 0x0000773E7DDFF430
0000773e7dfd4a33  jmp 0x0000773E7DFD2E8F
0000773e7dfd4a38  call 0x0000773E7DE0E760
0000773e7dfd4a3d  jmp 0x0000773E7DFD2E99
0000773e7dfd4a42  sub rsp, 0x08
0000773e7dfd4a46  push rax
0000773e7dfd4a47  push rcx
0000773e7dfd4a48  push rdx
0000773e7dfd4a49  push rdi
0000773e7dfd4a4a  push rsi
0000773e7dfd4a4b  push r8
0000773e7dfd4a4d  push r9
0000773e7dfd4a4f  push r10
0000773e7dfd4a51  push r11
0000773e7dfd4a53  sub rsp, 0xF0
0000773e7dfd4a5a  vmovaps [rsp], xmm0
0000773e7dfd4a5f  vmovaps [rsp+0x10], xmm1
0000773e7dfd4a65  vmovaps [rsp+0x20], xmm2
0000773e7dfd4a6b  vmovaps [rsp+0x30], xmm3
0000773e7dfd4a71  vmovaps [rsp+0x40], xmm4
0000773e7dfd4a77  vmovaps [rsp+0x50], xmm5
0000773e7dfd4a7d  vmovaps [rsp+0x60], xmm6
0000773e7dfd4a83  vmovaps [rsp+0x70], xmm7
0000773e7dfd4a89  vmovaps [rsp+0x80], xmm9
0000773e7dfd4a92  vmovaps [rsp+0x90], xmm10
0000773e7dfd4a9b  vmovaps [rsp+0xA0], xmm11
0000773e7dfd4aa4  vmovaps [rsp+0xB0], xmm12
0000773e7dfd4aad  vmovaps [rsp+0xC0], xmm13
0000773e7dfd4ab6  vmovaps [rsp+0xD0], xmm14
0000773e7dfd4abf  vmovaps [rsp+0xE0], xmm15
0000773e7dfd4ac8  sub rsp, 0x40
0000773e7dfd4acc  lea rdi, [rsp]
0000773e7dfd4ad0  lea rsi, [rsp+0x10]
0000773e7dfd4ad5  lea rdx, [rsp+0x20]
0000773e7dfd4ada  lea rcx, [rsp+0x30]
0000773e7dfd4adf  mov r8d, 0x00
0000773e7dfd4ae5  lea r9, [r15+0x3A8]
0000773e7dfd4aec  movaps [rdi], xmm8
0000773e7dfd4af0  movaps [rsi], xmm5
0000773e7dfd4af3  movaps [rdx], xmm9
0000773e7dfd4af7  movaps [rcx], xmm13
0000773e7dfd4afb  mov rax, 0x567852F34A50
0000773e7dfd4b05  call rax
0000773e7dfd4b07  movaps xmm8, [rsp]
0000773e7dfd4b0c  add rsp, 0x40
0000773e7dfd4b10  vmovaps xmm0, [rsp]
0000773e7dfd4b15  vmovaps xmm1, [rsp+0x10]
0000773e7dfd4b1b  vmovaps xmm2, [rsp+0x20]
0000773e7dfd4b21  vmovaps xmm3, [rsp+0x30]
0000773e7dfd4b27  vmovaps xmm4, [rsp+0x40]
0000773e7dfd4b2d  vmovaps xmm5, [rsp+0x50]
0000773e7dfd4b33  vmovaps xmm6, [rsp+0x60]
0000773e7dfd4b39  vmovaps xmm7, [rsp+0x70]
0000773e7dfd4b3f  vmovaps xmm9, [rsp+0x80]
0000773e7dfd4b48  vmovaps xmm10, [rsp+0x90]
0000773e7dfd4b51  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd4b5a  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd4b63  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd4b6c  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd4b75  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd4b7e  add rsp, 0xF0
0000773e7dfd4b85  pop r11
0000773e7dfd4b87  pop r10
0000773e7dfd4b89  pop r9
0000773e7dfd4b8b  pop r8
0000773e7dfd4b8d  pop rsi
0000773e7dfd4b8e  pop rdi
0000773e7dfd4b8f  pop rdx
0000773e7dfd4b90  pop rcx
0000773e7dfd4b91  pop rax
0000773e7dfd4b92  add rsp, 0x08
0000773e7dfd4b96  jmp 0x0000773E7DFD2ED8
0000773e7dfd4b9b  sub rsp, 0x08
0000773e7dfd4b9f  push rax
0000773e7dfd4ba0  push rcx
0000773e7dfd4ba1  push rdx
0000773e7dfd4ba2  push rdi
0000773e7dfd4ba3  push rsi
0000773e7dfd4ba4  push r8
0000773e7dfd4ba6  push r9
0000773e7dfd4ba8  push r10
0000773e7dfd4baa  push r11
0000773e7dfd4bac  sub rsp, 0xF0
0000773e7dfd4bb3  vmovaps [rsp], xmm0
0000773e7dfd4bb8  vmovaps [rsp+0x10], xmm1
0000773e7dfd4bbe  vmovaps [rsp+0x20], xmm2
0000773e7dfd4bc4  vmovaps [rsp+0x30], xmm3
0000773e7dfd4bca  vmovaps [rsp+0x40], xmm4
0000773e7dfd4bd0  vmovaps [rsp+0x50], xmm5
0000773e7dfd4bd6  vmovaps [rsp+0x60], xmm6
0000773e7dfd4bdc  vmovaps [rsp+0x70], xmm7
0000773e7dfd4be2  vmovaps [rsp+0x80], xmm8
0000773e7dfd4beb  vmovaps [rsp+0x90], xmm10
0000773e7dfd4bf4  vmovaps [rsp+0xA0], xmm11
0000773e7dfd4bfd  vmovaps [rsp+0xB0], xmm12
0000773e7dfd4c06  vmovaps [rsp+0xC0], xmm13
0000773e7dfd4c0f  vmovaps [rsp+0xD0], xmm14
0000773e7dfd4c18  vmovaps [rsp+0xE0], xmm15
0000773e7dfd4c21  sub rsp, 0x40
0000773e7dfd4c25  lea rdi, [rsp]
0000773e7dfd4c29  lea rsi, [rsp+0x10]
0000773e7dfd4c2e  lea rdx, [rsp+0x20]
0000773e7dfd4c33  lea rcx, [rsp+0x30]
0000773e7dfd4c38  mov r8d, 0x00
0000773e7dfd4c3e  lea r9, [r15+0x3A8]
0000773e7dfd4c45  movaps [rdi], xmm9
0000773e7dfd4c49  movaps [rsi], xmm12
0000773e7dfd4c4d  movaps [rdx], xmm7
0000773e7dfd4c50  movaps [rcx], xmm13
0000773e7dfd4c54  mov rax, 0x567852F34A50
0000773e7dfd4c5e  call rax
0000773e7dfd4c60  movaps xmm9, [rsp]
0000773e7dfd4c65  add rsp, 0x40
0000773e7dfd4c69  vmovaps xmm0, [rsp]
0000773e7dfd4c6e  vmovaps xmm1, [rsp+0x10]
0000773e7dfd4c74  vmovaps xmm2, [rsp+0x20]
0000773e7dfd4c7a  vmovaps xmm3, [rsp+0x30]
0000773e7dfd4c80  vmovaps xmm4, [rsp+0x40]
0000773e7dfd4c86  vmovaps xmm5, [rsp+0x50]
0000773e7dfd4c8c  vmovaps xmm6, [rsp+0x60]
0000773e7dfd4c92  vmovaps xmm7, [rsp+0x70]
0000773e7dfd4c98  vmovaps xmm8, [rsp+0x80]
0000773e7dfd4ca1  vmovaps xmm10, [rsp+0x90]
0000773e7dfd4caa  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd4cb3  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd4cbc  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd4cc5  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd4cce  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd4cd7  add rsp, 0xF0
0000773e7dfd4cde  pop r11
0000773e7dfd4ce0  pop r10
0000773e7dfd4ce2  pop r9
0000773e7dfd4ce4  pop r8
0000773e7dfd4ce6  pop rsi
0000773e7dfd4ce7  pop rdi
0000773e7dfd4ce8  pop rdx
0000773e7dfd4ce9  pop rcx
0000773e7dfd4cea  pop rax
0000773e7dfd4ceb  add rsp, 0x08
0000773e7dfd4cef  jmp 0x0000773E7DFD2F01
0000773e7dfd4cf4  sub rsp, 0x08
0000773e7dfd4cf8  push rax
0000773e7dfd4cf9  push rcx
0000773e7dfd4cfa  push rdx
0000773e7dfd4cfb  push rdi
0000773e7dfd4cfc  push rsi
0000773e7dfd4cfd  push r8
0000773e7dfd4cff  push r9
0000773e7dfd4d01  push r10
0000773e7dfd4d03  push r11
0000773e7dfd4d05  sub rsp, 0xF0
0000773e7dfd4d0c  vmovaps [rsp], xmm0
0000773e7dfd4d11  vmovaps [rsp+0x10], xmm1
0000773e7dfd4d17  vmovaps [rsp+0x20], xmm2
0000773e7dfd4d1d  vmovaps [rsp+0x30], xmm3
0000773e7dfd4d23  vmovaps [rsp+0x40], xmm4
0000773e7dfd4d29  vmovaps [rsp+0x50], xmm5
0000773e7dfd4d2f  vmovaps [rsp+0x60], xmm6
0000773e7dfd4d35  vmovaps [rsp+0x70], xmm7
0000773e7dfd4d3b  vmovaps [rsp+0x80], xmm8
0000773e7dfd4d44  vmovaps [rsp+0x90], xmm9
0000773e7dfd4d4d  vmovaps [rsp+0xA0], xmm10
0000773e7dfd4d56  vmovaps [rsp+0xB0], xmm11
0000773e7dfd4d5f  vmovaps [rsp+0xC0], xmm13
0000773e7dfd4d68  vmovaps [rsp+0xD0], xmm14
0000773e7dfd4d71  vmovaps [rsp+0xE0], xmm15
0000773e7dfd4d7a  sub rsp, 0x40
0000773e7dfd4d7e  lea rdi, [rsp]
0000773e7dfd4d82  lea rsi, [rsp+0x10]
0000773e7dfd4d87  lea rdx, [rsp+0x20]
0000773e7dfd4d8c  lea rcx, [rsp+0x30]
0000773e7dfd4d91  mov r8d, 0x00
0000773e7dfd4d97  lea r9, [r15+0x3A8]
0000773e7dfd4d9e  movaps [rdi], xmm12
0000773e7dfd4da2  movaps [rsi], xmm11
0000773e7dfd4da6  movaps [rdx], xmm6
0000773e7dfd4da9  movaps [rcx], xmm13
0000773e7dfd4dad  mov rax, 0x567852F34A50
0000773e7dfd4db7  call rax
0000773e7dfd4db9  movaps xmm12, [rsp]
0000773e7dfd4dbe  add rsp, 0x40
0000773e7dfd4dc2  vmovaps xmm0, [rsp]
0000773e7dfd4dc7  vmovaps xmm1, [rsp+0x10]
0000773e7dfd4dcd  vmovaps xmm2, [rsp+0x20]
0000773e7dfd4dd3  vmovaps xmm3, [rsp+0x30]
0000773e7dfd4dd9  vmovaps xmm4, [rsp+0x40]
0000773e7dfd4ddf  vmovaps xmm5, [rsp+0x50]
0000773e7dfd4de5  vmovaps xmm6, [rsp+0x60]
0000773e7dfd4deb  vmovaps xmm7, [rsp+0x70]
0000773e7dfd4df1  vmovaps xmm8, [rsp+0x80]
0000773e7dfd4dfa  vmovaps xmm9, [rsp+0x90]
0000773e7dfd4e03  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd4e0c  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd4e15  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd4e1e  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd4e27  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd4e30  add rsp, 0xF0
0000773e7dfd4e37  pop r11
0000773e7dfd4e39  pop r10
0000773e7dfd4e3b  pop r9
0000773e7dfd4e3d  pop r8
0000773e7dfd4e3f  pop rsi
0000773e7dfd4e40  pop rdi
0000773e7dfd4e41  pop rdx
0000773e7dfd4e42  pop rcx
0000773e7dfd4e43  pop rax
0000773e7dfd4e44  add rsp, 0x08
0000773e7dfd4e48  jmp 0x0000773E7DFD2F2A
0000773e7dfd4e4d  sub rsp, 0x08
0000773e7dfd4e51  push rax
0000773e7dfd4e52  push rcx
0000773e7dfd4e53  push rdx
0000773e7dfd4e54  push rdi
0000773e7dfd4e55  push rsi
0000773e7dfd4e56  push r8
0000773e7dfd4e58  push r9
0000773e7dfd4e5a  push r10
0000773e7dfd4e5c  push r11
0000773e7dfd4e5e  sub rsp, 0xF0
0000773e7dfd4e65  vmovaps [rsp], xmm0
0000773e7dfd4e6a  vmovaps [rsp+0x10], xmm1
0000773e7dfd4e70  vmovaps [rsp+0x20], xmm2
0000773e7dfd4e76  vmovaps [rsp+0x30], xmm3
0000773e7dfd4e7c  vmovaps [rsp+0x40], xmm4
0000773e7dfd4e82  vmovaps [rsp+0x50], xmm5
0000773e7dfd4e88  vmovaps [rsp+0x60], xmm6
0000773e7dfd4e8e  vmovaps [rsp+0x70], xmm8
0000773e7dfd4e94  vmovaps [rsp+0x80], xmm9
0000773e7dfd4e9d  vmovaps [rsp+0x90], xmm10
0000773e7dfd4ea6  vmovaps [rsp+0xA0], xmm11
0000773e7dfd4eaf  vmovaps [rsp+0xB0], xmm12
0000773e7dfd4eb8  vmovaps [rsp+0xC0], xmm13
0000773e7dfd4ec1  vmovaps [rsp+0xD0], xmm14
0000773e7dfd4eca  vmovaps [rsp+0xE0], xmm15
0000773e7dfd4ed3  sub rsp, 0x40
0000773e7dfd4ed7  lea rdi, [rsp]
0000773e7dfd4edb  lea rsi, [rsp+0x10]
0000773e7dfd4ee0  lea rdx, [rsp+0x20]
0000773e7dfd4ee5  lea rcx, [rsp+0x30]
0000773e7dfd4eea  mov r8d, 0x00
0000773e7dfd4ef0  lea r9, [r15+0x3A8]
0000773e7dfd4ef7  movaps [rdi], xmm7
0000773e7dfd4efa  movaps [rsi], xmm10
0000773e7dfd4efe  movaps [rdx], xmm11
0000773e7dfd4f02  movaps [rcx], xmm13
0000773e7dfd4f06  mov rax, 0x567852F34A50
0000773e7dfd4f10  call rax
0000773e7dfd4f12  movaps xmm7, [rsp]
0000773e7dfd4f16  add rsp, 0x40
0000773e7dfd4f1a  vmovaps xmm0, [rsp]
0000773e7dfd4f1f  vmovaps xmm1, [rsp+0x10]
0000773e7dfd4f25  vmovaps xmm2, [rsp+0x20]
0000773e7dfd4f2b  vmovaps xmm3, [rsp+0x30]
0000773e7dfd4f31  vmovaps xmm4, [rsp+0x40]
0000773e7dfd4f37  vmovaps xmm5, [rsp+0x50]
0000773e7dfd4f3d  vmovaps xmm6, [rsp+0x60]
0000773e7dfd4f43  vmovaps xmm8, [rsp+0x70]
0000773e7dfd4f49  vmovaps xmm9, [rsp+0x80]
0000773e7dfd4f52  vmovaps xmm10, [rsp+0x90]
0000773e7dfd4f5b  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd4f64  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd4f6d  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd4f76  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd4f7f  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd4f88  add rsp, 0xF0
0000773e7dfd4f8f  pop r11
0000773e7dfd4f91  pop r10
0000773e7dfd4f93  pop r9
0000773e7dfd4f95  pop r8
0000773e7dfd4f97  pop rsi
0000773e7dfd4f98  pop rdi
0000773e7dfd4f99  pop rdx
0000773e7dfd4f9a  pop rcx
0000773e7dfd4f9b  pop rax
0000773e7dfd4f9c  add rsp, 0x08
0000773e7dfd4fa0  jmp 0x0000773E7DFD2F58
0000773e7dfd4fa5  call 0x0000773E7DE0C260
0000773e7dfd4faa  jmp 0x0000773E7DFD2F62
0000773e7dfd4faf  call 0x0000773E7DE09D70
0000773e7dfd4fb4  jmp 0x0000773E7DFD2F6C
0000773e7dfd4fb9  sub rsp, 0x08
0000773e7dfd4fbd  push rax
0000773e7dfd4fbe  push rcx
0000773e7dfd4fbf  push rdx
0000773e7dfd4fc0  push rdi
0000773e7dfd4fc1  push rsi
0000773e7dfd4fc2  push r8
0000773e7dfd4fc4  push r9
0000773e7dfd4fc6  push r10
0000773e7dfd4fc8  push r11
0000773e7dfd4fca  sub rsp, 0xF0
0000773e7dfd4fd1  vmovaps [rsp], xmm0
0000773e7dfd4fd6  vmovaps [rsp+0x10], xmm1
0000773e7dfd4fdc  vmovaps [rsp+0x20], xmm2
0000773e7dfd4fe2  vmovaps [rsp+0x30], xmm3
0000773e7dfd4fe8  vmovaps [rsp+0x40], xmm4
0000773e7dfd4fee  vmovaps [rsp+0x50], xmm5
0000773e7dfd4ff4  vmovaps [rsp+0x60], xmm7
0000773e7dfd4ffa  vmovaps [rsp+0x70], xmm8
0000773e7dfd5000  vmovaps [rsp+0x80], xmm9
0000773e7dfd5009  vmovaps [rsp+0x90], xmm10
0000773e7dfd5012  vmovaps [rsp+0xA0], xmm11
0000773e7dfd501b  vmovaps [rsp+0xB0], xmm12
0000773e7dfd5024  vmovaps [rsp+0xC0], xmm13
0000773e7dfd502d  vmovaps [rsp+0xD0], xmm14
0000773e7dfd5036  vmovaps [rsp+0xE0], xmm15
0000773e7dfd503f  sub rsp, 0x40
0000773e7dfd5043  lea rdi, [rsp]
0000773e7dfd5047  lea rsi, [rsp+0x10]
0000773e7dfd504c  lea rdx, [rsp+0x20]
0000773e7dfd5051  lea rcx, [rsp+0x30]
0000773e7dfd5056  mov r8d, 0x00
0000773e7dfd505c  lea r9, [r15+0x3A8]
0000773e7dfd5063  movaps [rdi], xmm6
0000773e7dfd5066  movaps [rsi], xmm8
0000773e7dfd506a  movaps [rdx], xmm15
0000773e7dfd506e  movaps [rcx], xmm10
0000773e7dfd5072  mov rax, 0x567852F34A50
0000773e7dfd507c  call rax
0000773e7dfd507e  movaps xmm6, [rsp]
0000773e7dfd5082  add rsp, 0x40
0000773e7dfd5086  vmovaps xmm0, [rsp]
0000773e7dfd508b  vmovaps xmm1, [rsp+0x10]
0000773e7dfd5091  vmovaps xmm2, [rsp+0x20]
0000773e7dfd5097  vmovaps xmm3, [rsp+0x30]
0000773e7dfd509d  vmovaps xmm4, [rsp+0x40]
0000773e7dfd50a3  vmovaps xmm5, [rsp+0x50]
0000773e7dfd50a9  vmovaps xmm7, [rsp+0x60]
0000773e7dfd50af  vmovaps xmm8, [rsp+0x70]
0000773e7dfd50b5  vmovaps xmm9, [rsp+0x80]
0000773e7dfd50be  vmovaps xmm10, [rsp+0x90]
0000773e7dfd50c7  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd50d0  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd50d9  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd50e2  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd50eb  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd50f4  add rsp, 0xF0
0000773e7dfd50fb  pop r11
0000773e7dfd50fd  pop r10
0000773e7dfd50ff  pop r9
0000773e7dfd5101  pop r8
0000773e7dfd5103  pop rsi
0000773e7dfd5104  pop rdi
0000773e7dfd5105  pop rdx
0000773e7dfd5106  pop rcx
0000773e7dfd5107  pop rax
0000773e7dfd5108  add rsp, 0x08
0000773e7dfd510c  jmp 0x0000773E7DFD2FA4
0000773e7dfd5111  sub rsp, 0x08
0000773e7dfd5115  push rax
0000773e7dfd5116  push rcx
0000773e7dfd5117  push rdx
0000773e7dfd5118  push rdi
0000773e7dfd5119  push rsi
0000773e7dfd511a  push r8
0000773e7dfd511c  push r9
0000773e7dfd511e  push r10
0000773e7dfd5120  push r11
0000773e7dfd5122  sub rsp, 0xF0
0000773e7dfd5129  vmovaps [rsp], xmm0
0000773e7dfd512e  vmovaps [rsp+0x10], xmm1
0000773e7dfd5134  vmovaps [rsp+0x20], xmm2
0000773e7dfd513a  vmovaps [rsp+0x30], xmm3
0000773e7dfd5140  vmovaps [rsp+0x40], xmm4
0000773e7dfd5146  vmovaps [rsp+0x50], xmm5
0000773e7dfd514c  vmovaps [rsp+0x60], xmm6
0000773e7dfd5152  vmovaps [rsp+0x70], xmm7
0000773e7dfd5158  vmovaps [rsp+0x80], xmm8
0000773e7dfd5161  vmovaps [rsp+0x90], xmm9
0000773e7dfd516a  vmovaps [rsp+0xA0], xmm11
0000773e7dfd5173  vmovaps [rsp+0xB0], xmm12
0000773e7dfd517c  vmovaps [rsp+0xC0], xmm13
0000773e7dfd5185  vmovaps [rsp+0xD0], xmm14
0000773e7dfd518e  vmovaps [rsp+0xE0], xmm15
0000773e7dfd5197  sub rsp, 0x40
0000773e7dfd519b  lea rdi, [rsp]
0000773e7dfd519f  lea rsi, [rsp+0x10]
0000773e7dfd51a4  lea rdx, [rsp+0x20]
0000773e7dfd51a9  lea rcx, [rsp+0x30]
0000773e7dfd51ae  mov r8d, 0x00
0000773e7dfd51b4  lea r9, [r15+0x3A8]
0000773e7dfd51bb  movaps [rdi], xmm10
0000773e7dfd51bf  movaps [rsi], xmm9
0000773e7dfd51c3  movaps [rdx], xmm13
0000773e7dfd51c7  movaps [rcx], xmm15
0000773e7dfd51cb  mov rax, 0x567852F34A50
0000773e7dfd51d5  call rax
0000773e7dfd51d7  movaps xmm10, [rsp]
0000773e7dfd51dc  add rsp, 0x40
0000773e7dfd51e0  vmovaps xmm0, [rsp]
0000773e7dfd51e5  vmovaps xmm1, [rsp+0x10]
0000773e7dfd51eb  vmovaps xmm2, [rsp+0x20]
0000773e7dfd51f1  vmovaps xmm3, [rsp+0x30]
0000773e7dfd51f7  vmovaps xmm4, [rsp+0x40]
0000773e7dfd51fd  vmovaps xmm5, [rsp+0x50]
0000773e7dfd5203  vmovaps xmm6, [rsp+0x60]
0000773e7dfd5209  vmovaps xmm7, [rsp+0x70]
0000773e7dfd520f  vmovaps xmm8, [rsp+0x80]
0000773e7dfd5218  vmovaps xmm9, [rsp+0x90]
0000773e7dfd5221  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd522a  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd5233  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd523c  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd5245  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd524e  add rsp, 0xF0
0000773e7dfd5255  pop r11
0000773e7dfd5257  pop r10
0000773e7dfd5259  pop r9
0000773e7dfd525b  pop r8
0000773e7dfd525d  pop rsi
0000773e7dfd525e  pop rdi
0000773e7dfd525f  pop rdx
0000773e7dfd5260  pop rcx
0000773e7dfd5261  pop rax
0000773e7dfd5262  add rsp, 0x08
0000773e7dfd5266  jmp 0x0000773E7DFD2FCD
0000773e7dfd526b  sub rsp, 0x08
0000773e7dfd526f  push rax
0000773e7dfd5270  push rcx
0000773e7dfd5271  push rdx
0000773e7dfd5272  push rdi
0000773e7dfd5273  push rsi
0000773e7dfd5274  push r8
0000773e7dfd5276  push r9
0000773e7dfd5278  push r10
0000773e7dfd527a  push r11
0000773e7dfd527c  sub rsp, 0xF0
0000773e7dfd5283  vmovaps [rsp], xmm0
0000773e7dfd5288  vmovaps [rsp+0x10], xmm1
0000773e7dfd528e  vmovaps [rsp+0x20], xmm2
0000773e7dfd5294  vmovaps [rsp+0x30], xmm3
0000773e7dfd529a  vmovaps [rsp+0x40], xmm4
0000773e7dfd52a0  vmovaps [rsp+0x50], xmm5
0000773e7dfd52a6  vmovaps [rsp+0x60], xmm6
0000773e7dfd52ac  vmovaps [rsp+0x70], xmm7
0000773e7dfd52b2  vmovaps [rsp+0x80], xmm8
0000773e7dfd52bb  vmovaps [rsp+0x90], xmm9
0000773e7dfd52c4  vmovaps [rsp+0xA0], xmm10
0000773e7dfd52cd  vmovaps [rsp+0xB0], xmm11
0000773e7dfd52d6  vmovaps [rsp+0xC0], xmm12
0000773e7dfd52df  vmovaps [rsp+0xD0], xmm14
0000773e7dfd52e8  vmovaps [rsp+0xE0], xmm15
0000773e7dfd52f1  sub rsp, 0x40
0000773e7dfd52f5  lea rdi, [rsp]
0000773e7dfd52f9  lea rsi, [rsp+0x10]
0000773e7dfd52fe  lea rdx, [rsp+0x20]
0000773e7dfd5303  lea rcx, [rsp+0x30]
0000773e7dfd5308  mov r8d, 0x00
0000773e7dfd530e  lea r9, [r15+0x3A8]
0000773e7dfd5315  movaps [rdi], xmm13
0000773e7dfd5319  movaps [rsi], xmm12
0000773e7dfd531d  movaps [rdx], xmm4
0000773e7dfd5320  movaps [rcx], xmm15
0000773e7dfd5324  mov rax, 0x567852F34A50
0000773e7dfd532e  call rax
0000773e7dfd5330  movaps xmm13, [rsp]
0000773e7dfd5335  add rsp, 0x40
0000773e7dfd5339  vmovaps xmm0, [rsp]
0000773e7dfd533e  vmovaps xmm1, [rsp+0x10]
0000773e7dfd5344  vmovaps xmm2, [rsp+0x20]
0000773e7dfd534a  vmovaps xmm3, [rsp+0x30]
0000773e7dfd5350  vmovaps xmm4, [rsp+0x40]
0000773e7dfd5356  vmovaps xmm5, [rsp+0x50]
0000773e7dfd535c  vmovaps xmm6, [rsp+0x60]
0000773e7dfd5362  vmovaps xmm7, [rsp+0x70]
0000773e7dfd5368  vmovaps xmm8, [rsp+0x80]
0000773e7dfd5371  vmovaps xmm9, [rsp+0x90]
0000773e7dfd537a  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd5383  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd538c  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd5395  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd539e  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd53a7  add rsp, 0xF0
0000773e7dfd53ae  pop r11
0000773e7dfd53b0  pop r10
0000773e7dfd53b2  pop r9
0000773e7dfd53b4  pop r8
0000773e7dfd53b6  pop rsi
0000773e7dfd53b7  pop rdi
0000773e7dfd53b8  pop rdx
0000773e7dfd53b9  pop rcx
0000773e7dfd53ba  pop rax
0000773e7dfd53bb  add rsp, 0x08
0000773e7dfd53bf  jmp 0x0000773E7DFD2FF6
0000773e7dfd53c4  sub rsp, 0x08
0000773e7dfd53c8  push rax
0000773e7dfd53c9  push rcx
0000773e7dfd53ca  push rdx
0000773e7dfd53cb  push rdi
0000773e7dfd53cc  push rsi
0000773e7dfd53cd  push r8
0000773e7dfd53cf  push r9
0000773e7dfd53d1  push r10
0000773e7dfd53d3  push r11
0000773e7dfd53d5  sub rsp, 0xF0
0000773e7dfd53dc  vmovaps [rsp], xmm0
0000773e7dfd53e1  vmovaps [rsp+0x10], xmm1
0000773e7dfd53e7  vmovaps [rsp+0x20], xmm2
0000773e7dfd53ed  vmovaps [rsp+0x30], xmm3
0000773e7dfd53f3  vmovaps [rsp+0x40], xmm4
0000773e7dfd53f9  vmovaps [rsp+0x50], xmm5
0000773e7dfd53ff  vmovaps [rsp+0x60], xmm6
0000773e7dfd5405  vmovaps [rsp+0x70], xmm7
0000773e7dfd540b  vmovaps [rsp+0x80], xmm8
0000773e7dfd5414  vmovaps [rsp+0x90], xmm9
0000773e7dfd541d  vmovaps [rsp+0xA0], xmm10
0000773e7dfd5426  vmovaps [rsp+0xB0], xmm11
0000773e7dfd542f  vmovaps [rsp+0xC0], xmm13
0000773e7dfd5438  vmovaps [rsp+0xD0], xmm14
0000773e7dfd5441  vmovaps [rsp+0xE0], xmm15
0000773e7dfd544a  sub rsp, 0x40
0000773e7dfd544e  lea rdi, [rsp]
0000773e7dfd5452  lea rsi, [rsp+0x10]
0000773e7dfd5457  lea rdx, [rsp+0x20]
0000773e7dfd545c  lea rcx, [rsp+0x30]
0000773e7dfd5461  mov r8d, 0x00
0000773e7dfd5467  lea r9, [r15+0x3A8]
0000773e7dfd546e  movaps [rdi], xmm12
0000773e7dfd5472  movaps [rsi], xmm7
0000773e7dfd5475  movaps [rdx], xmm1
0000773e7dfd5478  movaps [rcx], xmm15
0000773e7dfd547c  mov rax, 0x567852F34A50
0000773e7dfd5486  call rax
0000773e7dfd5488  movaps xmm12, [rsp]
0000773e7dfd548d  add rsp, 0x40
0000773e7dfd5491  vmovaps xmm0, [rsp]
0000773e7dfd5496  vmovaps xmm1, [rsp+0x10]
0000773e7dfd549c  vmovaps xmm2, [rsp+0x20]
0000773e7dfd54a2  vmovaps xmm3, [rsp+0x30]
0000773e7dfd54a8  vmovaps xmm4, [rsp+0x40]
0000773e7dfd54ae  vmovaps xmm5, [rsp+0x50]
0000773e7dfd54b4  vmovaps xmm6, [rsp+0x60]
0000773e7dfd54ba  vmovaps xmm7, [rsp+0x70]
0000773e7dfd54c0  vmovaps xmm8, [rsp+0x80]
0000773e7dfd54c9  vmovaps xmm9, [rsp+0x90]
0000773e7dfd54d2  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd54db  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd54e4  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd54ed  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd54f6  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd54ff  add rsp, 0xF0
0000773e7dfd5506  pop r11
0000773e7dfd5508  pop r10
0000773e7dfd550a  pop r9
0000773e7dfd550c  pop r8
0000773e7dfd550e  pop rsi
0000773e7dfd550f  pop rdi
0000773e7dfd5510  pop rdx
0000773e7dfd5511  pop rcx
0000773e7dfd5512  pop rax
0000773e7dfd5513  add rsp, 0x08
0000773e7dfd5517  jmp 0x0000773E7DFD301F
0000773e7dfd551c  call 0x0000773E7DDFF430
0000773e7dfd5521  jmp 0x0000773E7DFD3029
0000773e7dfd5526  call 0x0000773E7DE0E760
0000773e7dfd552b  jmp 0x0000773E7DFD3033
0000773e7dfd5530  sub rsp, 0x08
0000773e7dfd5534  push rax
0000773e7dfd5535  push rcx
0000773e7dfd5536  push rdx
0000773e7dfd5537  push rdi
0000773e7dfd5538  push rsi
0000773e7dfd5539  push r8
0000773e7dfd553b  push r9
0000773e7dfd553d  push r10
0000773e7dfd553f  push r11
0000773e7dfd5541  sub rsp, 0xF0
0000773e7dfd5548  vmovaps [rsp], xmm0
0000773e7dfd554d  vmovaps [rsp+0x10], xmm1
0000773e7dfd5553  vmovaps [rsp+0x20], xmm2
0000773e7dfd5559  vmovaps [rsp+0x30], xmm3
0000773e7dfd555f  vmovaps [rsp+0x40], xmm4
0000773e7dfd5565  vmovaps [rsp+0x50], xmm5
0000773e7dfd556b  vmovaps [rsp+0x60], xmm6
0000773e7dfd5571  vmovaps [rsp+0x70], xmm8
0000773e7dfd5577  vmovaps [rsp+0x80], xmm9
0000773e7dfd5580  vmovaps [rsp+0x90], xmm10
0000773e7dfd5589  vmovaps [rsp+0xA0], xmm11
0000773e7dfd5592  vmovaps [rsp+0xB0], xmm12
0000773e7dfd559b  vmovaps [rsp+0xC0], xmm13
0000773e7dfd55a4  vmovaps [rsp+0xD0], xmm14
0000773e7dfd55ad  vmovaps [rsp+0xE0], xmm15
0000773e7dfd55b6  sub rsp, 0x40
0000773e7dfd55ba  lea rdi, [rsp]
0000773e7dfd55be  lea rsi, [rsp+0x10]
0000773e7dfd55c3  lea rdx, [rsp+0x20]
0000773e7dfd55c8  lea rcx, [rsp+0x30]
0000773e7dfd55cd  mov r8d, 0x00
0000773e7dfd55d3  lea r9, [r15+0x3A8]
0000773e7dfd55da  movaps [rdi], xmm7
0000773e7dfd55dd  movaps [rsi], xmm6
0000773e7dfd55e0  movaps [rdx], xmm8
0000773e7dfd55e4  movaps [rcx], xmm9
0000773e7dfd55e8  mov rax, 0x567852F34A50
0000773e7dfd55f2  call rax
0000773e7dfd55f4  movaps xmm7, [rsp]
0000773e7dfd55f8  add rsp, 0x40
0000773e7dfd55fc  vmovaps xmm0, [rsp]
0000773e7dfd5601  vmovaps xmm1, [rsp+0x10]
0000773e7dfd5607  vmovaps xmm2, [rsp+0x20]
0000773e7dfd560d  vmovaps xmm3, [rsp+0x30]
0000773e7dfd5613  vmovaps xmm4, [rsp+0x40]
0000773e7dfd5619  vmovaps xmm5, [rsp+0x50]
0000773e7dfd561f  vmovaps xmm6, [rsp+0x60]
0000773e7dfd5625  vmovaps xmm8, [rsp+0x70]
0000773e7dfd562b  vmovaps xmm9, [rsp+0x80]
0000773e7dfd5634  vmovaps xmm10, [rsp+0x90]
0000773e7dfd563d  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd5646  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd564f  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd5658  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd5661  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd566a  add rsp, 0xF0
0000773e7dfd5671  pop r11
0000773e7dfd5673  pop r10
0000773e7dfd5675  pop r9
0000773e7dfd5677  pop r8
0000773e7dfd5679  pop rsi
0000773e7dfd567a  pop rdi
0000773e7dfd567b  pop rdx
0000773e7dfd567c  pop rcx
0000773e7dfd567d  pop rax
0000773e7dfd567e  add rsp, 0x08
0000773e7dfd5682  jmp 0x0000773E7DFD305D
0000773e7dfd5687  sub rsp, 0x08
0000773e7dfd568b  push rax
0000773e7dfd568c  push rcx
0000773e7dfd568d  push rdx
0000773e7dfd568e  push rdi
0000773e7dfd568f  push rsi
0000773e7dfd5690  push r8
0000773e7dfd5692  push r9
0000773e7dfd5694  push r10
0000773e7dfd5696  push r11
0000773e7dfd5698  sub rsp, 0xF0
0000773e7dfd569f  vmovaps [rsp], xmm0
0000773e7dfd56a4  vmovaps [rsp+0x10], xmm1
0000773e7dfd56aa  vmovaps [rsp+0x20], xmm2
0000773e7dfd56b0  vmovaps [rsp+0x30], xmm3
0000773e7dfd56b6  vmovaps [rsp+0x40], xmm4
0000773e7dfd56bc  vmovaps [rsp+0x50], xmm5
0000773e7dfd56c2  vmovaps [rsp+0x60], xmm6
0000773e7dfd56c8  vmovaps [rsp+0x70], xmm7
0000773e7dfd56ce  vmovaps [rsp+0x80], xmm9
0000773e7dfd56d7  vmovaps [rsp+0x90], xmm10
0000773e7dfd56e0  vmovaps [rsp+0xA0], xmm11
0000773e7dfd56e9  vmovaps [rsp+0xB0], xmm12
0000773e7dfd56f2  vmovaps [rsp+0xC0], xmm13
0000773e7dfd56fb  vmovaps [rsp+0xD0], xmm14
0000773e7dfd5704  vmovaps [rsp+0xE0], xmm15
0000773e7dfd570d  sub rsp, 0x40
0000773e7dfd5711  lea rdi, [rsp]
0000773e7dfd5715  lea rsi, [rsp+0x10]
0000773e7dfd571a  lea rdx, [rsp+0x20]
0000773e7dfd571f  lea rcx, [rsp+0x30]
0000773e7dfd5724  mov r8d, 0x00
0000773e7dfd572a  lea r9, [r15+0x3A8]
0000773e7dfd5731  movaps [rdi], xmm8
0000773e7dfd5735  movaps [rsi], xmm10
0000773e7dfd5739  movaps [rdx], xmm14
0000773e7dfd573d  movaps [rcx], xmm9
0000773e7dfd5741  mov rax, 0x567852F34A50
0000773e7dfd574b  call rax
0000773e7dfd574d  movaps xmm8, [rsp]
0000773e7dfd5752  add rsp, 0x40
0000773e7dfd5756  vmovaps xmm0, [rsp]
0000773e7dfd575b  vmovaps xmm1, [rsp+0x10]
0000773e7dfd5761  vmovaps xmm2, [rsp+0x20]
0000773e7dfd5767  vmovaps xmm3, [rsp+0x30]
0000773e7dfd576d  vmovaps xmm4, [rsp+0x40]
0000773e7dfd5773  vmovaps xmm5, [rsp+0x50]
0000773e7dfd5779  vmovaps xmm6, [rsp+0x60]
0000773e7dfd577f  vmovaps xmm7, [rsp+0x70]
0000773e7dfd5785  vmovaps xmm9, [rsp+0x80]
0000773e7dfd578e  vmovaps xmm10, [rsp+0x90]
0000773e7dfd5797  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd57a0  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd57a9  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd57b2  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd57bb  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd57c4  add rsp, 0xF0
0000773e7dfd57cb  pop r11
0000773e7dfd57cd  pop r10
0000773e7dfd57cf  pop r9
0000773e7dfd57d1  pop r8
0000773e7dfd57d3  pop rsi
0000773e7dfd57d4  pop rdi
0000773e7dfd57d5  pop rdx
0000773e7dfd57d6  pop rcx
0000773e7dfd57d7  pop rax
0000773e7dfd57d8  add rsp, 0x08
0000773e7dfd57dc  jmp 0x0000773E7DFD3083
0000773e7dfd57e1  sub rsp, 0x08
0000773e7dfd57e5  push rax
0000773e7dfd57e6  push rcx
0000773e7dfd57e7  push rdx
0000773e7dfd57e8  push rdi
0000773e7dfd57e9  push rsi
0000773e7dfd57ea  push r8
0000773e7dfd57ec  push r9
0000773e7dfd57ee  push r10
0000773e7dfd57f0  push r11
0000773e7dfd57f2  sub rsp, 0xF0
0000773e7dfd57f9  vmovaps [rsp], xmm0
0000773e7dfd57fe  vmovaps [rsp+0x10], xmm1
0000773e7dfd5804  vmovaps [rsp+0x20], xmm2
0000773e7dfd580a  vmovaps [rsp+0x30], xmm3
0000773e7dfd5810  vmovaps [rsp+0x40], xmm4
0000773e7dfd5816  vmovaps [rsp+0x50], xmm5
0000773e7dfd581c  vmovaps [rsp+0x60], xmm6
0000773e7dfd5822  vmovaps [rsp+0x70], xmm7
0000773e7dfd5828  vmovaps [rsp+0x80], xmm8
0000773e7dfd5831  vmovaps [rsp+0x90], xmm9
0000773e7dfd583a  vmovaps [rsp+0xA0], xmm11
0000773e7dfd5843  vmovaps [rsp+0xB0], xmm12
0000773e7dfd584c  vmovaps [rsp+0xC0], xmm13
0000773e7dfd5855  vmovaps [rsp+0xD0], xmm14
0000773e7dfd585e  vmovaps [rsp+0xE0], xmm15
0000773e7dfd5867  sub rsp, 0x40
0000773e7dfd586b  lea rdi, [rsp]
0000773e7dfd586f  lea rsi, [rsp+0x10]
0000773e7dfd5874  lea rdx, [rsp+0x20]
0000773e7dfd5879  lea rcx, [rsp+0x30]
0000773e7dfd587e  mov r8d, 0x00
0000773e7dfd5884  lea r9, [r15+0x3A8]
0000773e7dfd588b  movaps [rdi], xmm10
0000773e7dfd588f  movaps [rsi], xmm13
0000773e7dfd5893  movaps [rdx], xmm11
0000773e7dfd5897  movaps [rcx], xmm14
0000773e7dfd589b  mov rax, 0x567852F34A50
0000773e7dfd58a5  call rax
0000773e7dfd58a7  movaps xmm10, [rsp]
0000773e7dfd58ac  add rsp, 0x40
0000773e7dfd58b0  vmovaps xmm0, [rsp]
0000773e7dfd58b5  vmovaps xmm1, [rsp+0x10]
0000773e7dfd58bb  vmovaps xmm2, [rsp+0x20]
0000773e7dfd58c1  vmovaps xmm3, [rsp+0x30]
0000773e7dfd58c7  vmovaps xmm4, [rsp+0x40]
0000773e7dfd58cd  vmovaps xmm5, [rsp+0x50]
0000773e7dfd58d3  vmovaps xmm6, [rsp+0x60]
0000773e7dfd58d9  vmovaps xmm7, [rsp+0x70]
0000773e7dfd58df  vmovaps xmm8, [rsp+0x80]
0000773e7dfd58e8  vmovaps xmm9, [rsp+0x90]
0000773e7dfd58f1  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd58fa  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd5903  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd590c  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd5915  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd591e  add rsp, 0xF0
0000773e7dfd5925  pop r11
0000773e7dfd5927  pop r10
0000773e7dfd5929  pop r9
0000773e7dfd592b  pop r8
0000773e7dfd592d  pop rsi
0000773e7dfd592e  pop rdi
0000773e7dfd592f  pop rdx
0000773e7dfd5930  pop rcx
0000773e7dfd5931  pop rax
0000773e7dfd5932  add rsp, 0x08
0000773e7dfd5936  jmp 0x0000773E7DFD30A9
0000773e7dfd593b  sub rsp, 0x08
0000773e7dfd593f  push rax
0000773e7dfd5940  push rcx
0000773e7dfd5941  push rdx
0000773e7dfd5942  push rdi
0000773e7dfd5943  push rsi
0000773e7dfd5944  push r8
0000773e7dfd5946  push r9
0000773e7dfd5948  push r10
0000773e7dfd594a  push r11
0000773e7dfd594c  sub rsp, 0xF0
0000773e7dfd5953  vmovaps [rsp], xmm0
0000773e7dfd5958  vmovaps [rsp+0x10], xmm1
0000773e7dfd595e  vmovaps [rsp+0x20], xmm2
0000773e7dfd5964  vmovaps [rsp+0x30], xmm3
0000773e7dfd596a  vmovaps [rsp+0x40], xmm4
0000773e7dfd5970  vmovaps [rsp+0x50], xmm5
0000773e7dfd5976  vmovaps [rsp+0x60], xmm6
0000773e7dfd597c  vmovaps [rsp+0x70], xmm7
0000773e7dfd5982  vmovaps [rsp+0x80], xmm8
0000773e7dfd598b  vmovaps [rsp+0x90], xmm9
0000773e7dfd5994  vmovaps [rsp+0xA0], xmm10
0000773e7dfd599d  vmovaps [rsp+0xB0], xmm11
0000773e7dfd59a6  vmovaps [rsp+0xC0], xmm12
0000773e7dfd59af  vmovaps [rsp+0xD0], xmm14
0000773e7dfd59b8  vmovaps [rsp+0xE0], xmm15
0000773e7dfd59c1  sub rsp, 0x40
0000773e7dfd59c5  lea rdi, [rsp]
0000773e7dfd59c9  lea rsi, [rsp+0x10]
0000773e7dfd59ce  lea rdx, [rsp+0x20]
0000773e7dfd59d3  lea rcx, [rsp+0x30]
0000773e7dfd59d8  mov r8d, 0x00
0000773e7dfd59de  lea r9, [r15+0x3A8]
0000773e7dfd59e5  movaps [rdi], xmm13
0000773e7dfd59e9  movaps [rsi], xmm12
0000773e7dfd59ed  movaps [rdx], xmm15
0000773e7dfd59f1  movaps [rcx], xmm14
0000773e7dfd59f5  mov rax, 0x567852F34A50
0000773e7dfd59ff  call rax
0000773e7dfd5a01  movaps xmm13, [rsp]
0000773e7dfd5a06  add rsp, 0x40
0000773e7dfd5a0a  vmovaps xmm0, [rsp]
0000773e7dfd5a0f  vmovaps xmm1, [rsp+0x10]
0000773e7dfd5a15  vmovaps xmm2, [rsp+0x20]
0000773e7dfd5a1b  vmovaps xmm3, [rsp+0x30]
0000773e7dfd5a21  vmovaps xmm4, [rsp+0x40]
0000773e7dfd5a27  vmovaps xmm5, [rsp+0x50]
0000773e7dfd5a2d  vmovaps xmm6, [rsp+0x60]
0000773e7dfd5a33  vmovaps xmm7, [rsp+0x70]
0000773e7dfd5a39  vmovaps xmm8, [rsp+0x80]
0000773e7dfd5a42  vmovaps xmm9, [rsp+0x90]
0000773e7dfd5a4b  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd5a54  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd5a5d  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd5a66  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd5a6f  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd5a78  add rsp, 0xF0
0000773e7dfd5a7f  pop r11
0000773e7dfd5a81  pop r10
0000773e7dfd5a83  pop r9
0000773e7dfd5a85  pop r8
0000773e7dfd5a87  pop rsi
0000773e7dfd5a88  pop rdi
0000773e7dfd5a89  pop rdx
0000773e7dfd5a8a  pop rcx
0000773e7dfd5a8b  pop rax
0000773e7dfd5a8c  add rsp, 0x08
0000773e7dfd5a90  jmp 0x0000773E7DFD30CF
0000773e7dfd5a95  call 0x0000773E7DE0E760
0000773e7dfd5a9a  jmp 0x0000773E7DFD30DC
0000773e7dfd5a9f  call 0x0000773E7DE0D4E0
0000773e7dfd5aa4  jmp 0x0000773E7DFD30E9
0000773e7dfd5aa9  sub rsp, 0x08
0000773e7dfd5aad  push rax
0000773e7dfd5aae  push rcx
0000773e7dfd5aaf  push rdx
0000773e7dfd5ab0  push rdi
0000773e7dfd5ab1  push rsi
0000773e7dfd5ab2  push r8
0000773e7dfd5ab4  push r9
0000773e7dfd5ab6  push r10
0000773e7dfd5ab8  push r11
0000773e7dfd5aba  sub rsp, 0xF0
0000773e7dfd5ac1  vmovaps [rsp], xmm0
0000773e7dfd5ac6  vmovaps [rsp+0x10], xmm1
0000773e7dfd5acc  vmovaps [rsp+0x20], xmm2
0000773e7dfd5ad2  vmovaps [rsp+0x30], xmm3
0000773e7dfd5ad8  vmovaps [rsp+0x40], xmm4
0000773e7dfd5ade  vmovaps [rsp+0x50], xmm5
0000773e7dfd5ae4  vmovaps [rsp+0x60], xmm6
0000773e7dfd5aea  vmovaps [rsp+0x70], xmm7
0000773e7dfd5af0  vmovaps [rsp+0x80], xmm8
0000773e7dfd5af9  vmovaps [rsp+0x90], xmm9
0000773e7dfd5b02  vmovaps [rsp+0xA0], xmm10
0000773e7dfd5b0b  vmovaps [rsp+0xB0], xmm12
0000773e7dfd5b14  vmovaps [rsp+0xC0], xmm13
0000773e7dfd5b1d  vmovaps [rsp+0xD0], xmm14
0000773e7dfd5b26  vmovaps [rsp+0xE0], xmm15
0000773e7dfd5b2f  sub rsp, 0x40
0000773e7dfd5b33  lea rdi, [rsp]
0000773e7dfd5b37  lea rsi, [rsp+0x10]
0000773e7dfd5b3c  lea rdx, [rsp+0x20]
0000773e7dfd5b41  lea rcx, [rsp+0x30]
0000773e7dfd5b46  mov r8d, 0x00
0000773e7dfd5b4c  lea r9, [r15+0x3A8]
0000773e7dfd5b53  movaps [rdi], xmm11
0000773e7dfd5b57  movaps [rsi], xmm7
0000773e7dfd5b5a  movaps [rdx], xmm1
0000773e7dfd5b5d  movaps [rcx], xmm12
0000773e7dfd5b61  mov rax, 0x567852F34A50
0000773e7dfd5b6b  call rax
0000773e7dfd5b6d  movaps xmm11, [rsp]
0000773e7dfd5b72  add rsp, 0x40
0000773e7dfd5b76  vmovaps xmm0, [rsp]
0000773e7dfd5b7b  vmovaps xmm1, [rsp+0x10]
0000773e7dfd5b81  vmovaps xmm2, [rsp+0x20]
0000773e7dfd5b87  vmovaps xmm3, [rsp+0x30]
0000773e7dfd5b8d  vmovaps xmm4, [rsp+0x40]
0000773e7dfd5b93  vmovaps xmm5, [rsp+0x50]
0000773e7dfd5b99  vmovaps xmm6, [rsp+0x60]
0000773e7dfd5b9f  vmovaps xmm7, [rsp+0x70]
0000773e7dfd5ba5  vmovaps xmm8, [rsp+0x80]
0000773e7dfd5bae  vmovaps xmm9, [rsp+0x90]
0000773e7dfd5bb7  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd5bc0  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd5bc9  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd5bd2  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd5bdb  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd5be4  add rsp, 0xF0
0000773e7dfd5beb  pop r11
0000773e7dfd5bed  pop r10
0000773e7dfd5bef  pop r9
0000773e7dfd5bf1  pop r8
0000773e7dfd5bf3  pop rsi
0000773e7dfd5bf4  pop rdi
0000773e7dfd5bf5  pop rdx
0000773e7dfd5bf6  pop rcx
0000773e7dfd5bf7  pop rax
0000773e7dfd5bf8  add rsp, 0x08
0000773e7dfd5bfc  jmp 0x0000773E7DFD3122
0000773e7dfd5c01  call 0x0000773E7DDFF430
0000773e7dfd5c06  jmp 0x0000773E7DFD3134
0000773e7dfd5c0b  sub rsp, 0x08
0000773e7dfd5c0f  push rax
0000773e7dfd5c10  push rcx
0000773e7dfd5c11  push rdx
0000773e7dfd5c12  push rdi
0000773e7dfd5c13  push rsi
0000773e7dfd5c14  push r8
0000773e7dfd5c16  push r9
0000773e7dfd5c18  push r10
0000773e7dfd5c1a  push r11
0000773e7dfd5c1c  sub rsp, 0xF0
0000773e7dfd5c23  vmovaps [rsp], xmm0
0000773e7dfd5c28  vmovaps [rsp+0x10], xmm1
0000773e7dfd5c2e  vmovaps [rsp+0x20], xmm2
0000773e7dfd5c34  vmovaps [rsp+0x30], xmm3
0000773e7dfd5c3a  vmovaps [rsp+0x40], xmm4
0000773e7dfd5c40  vmovaps [rsp+0x50], xmm5
0000773e7dfd5c46  vmovaps [rsp+0x60], xmm6
0000773e7dfd5c4c  vmovaps [rsp+0x70], xmm7
0000773e7dfd5c52  vmovaps [rsp+0x80], xmm8
0000773e7dfd5c5b  vmovaps [rsp+0x90], xmm10
0000773e7dfd5c64  vmovaps [rsp+0xA0], xmm11
0000773e7dfd5c6d  vmovaps [rsp+0xB0], xmm12
0000773e7dfd5c76  vmovaps [rsp+0xC0], xmm13
0000773e7dfd5c7f  vmovaps [rsp+0xD0], xmm14
0000773e7dfd5c88  vmovaps [rsp+0xE0], xmm15
0000773e7dfd5c91  sub rsp, 0x40
0000773e7dfd5c95  lea rdi, [rsp]
0000773e7dfd5c99  lea rsi, [rsp+0x10]
0000773e7dfd5c9e  lea rdx, [rsp+0x20]
0000773e7dfd5ca3  lea rcx, [rsp+0x30]
0000773e7dfd5ca8  mov r8d, 0x00
0000773e7dfd5cae  lea r9, [r15+0x3A8]
0000773e7dfd5cb5  movaps [rdi], xmm9
0000773e7dfd5cb9  movaps [rsi], xmm8
0000773e7dfd5cbd  movaps [rdx], xmm14
0000773e7dfd5cc1  movaps [rcx], xmm12
0000773e7dfd5cc5  mov rax, 0x567852F34A50
0000773e7dfd5ccf  call rax
0000773e7dfd5cd1  movaps xmm9, [rsp]
0000773e7dfd5cd6  add rsp, 0x40
0000773e7dfd5cda  vmovaps xmm0, [rsp]
0000773e7dfd5cdf  vmovaps xmm1, [rsp+0x10]
0000773e7dfd5ce5  vmovaps xmm2, [rsp+0x20]
0000773e7dfd5ceb  vmovaps xmm3, [rsp+0x30]
0000773e7dfd5cf1  vmovaps xmm4, [rsp+0x40]
0000773e7dfd5cf7  vmovaps xmm5, [rsp+0x50]
0000773e7dfd5cfd  vmovaps xmm6, [rsp+0x60]
0000773e7dfd5d03  vmovaps xmm7, [rsp+0x70]
0000773e7dfd5d09  vmovaps xmm8, [rsp+0x80]
0000773e7dfd5d12  vmovaps xmm10, [rsp+0x90]
0000773e7dfd5d1b  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd5d24  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd5d2d  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd5d36  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd5d3f  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd5d48  add rsp, 0xF0
0000773e7dfd5d4f  pop r11
0000773e7dfd5d51  pop r10
0000773e7dfd5d53  pop r9
0000773e7dfd5d55  pop r8
0000773e7dfd5d57  pop rsi
0000773e7dfd5d58  pop rdi
0000773e7dfd5d59  pop rdx
0000773e7dfd5d5a  pop rcx
0000773e7dfd5d5b  pop rax
0000773e7dfd5d5c  add rsp, 0x08
0000773e7dfd5d60  jmp 0x0000773E7DFD3165
0000773e7dfd5d65  sub rsp, 0x08
0000773e7dfd5d69  push rax
0000773e7dfd5d6a  push rcx
0000773e7dfd5d6b  push rdx
0000773e7dfd5d6c  push rdi
0000773e7dfd5d6d  push rsi
0000773e7dfd5d6e  push r8
0000773e7dfd5d70  push r9
0000773e7dfd5d72  push r10
0000773e7dfd5d74  push r11
0000773e7dfd5d76  sub rsp, 0xF0
0000773e7dfd5d7d  vmovaps [rsp], xmm0
0000773e7dfd5d82  vmovaps [rsp+0x10], xmm1
0000773e7dfd5d88  vmovaps [rsp+0x20], xmm2
0000773e7dfd5d8e  vmovaps [rsp+0x30], xmm3
0000773e7dfd5d94  vmovaps [rsp+0x40], xmm4
0000773e7dfd5d9a  vmovaps [rsp+0x50], xmm5
0000773e7dfd5da0  vmovaps [rsp+0x60], xmm6
0000773e7dfd5da6  vmovaps [rsp+0x70], xmm7
0000773e7dfd5dac  vmovaps [rsp+0x80], xmm8
0000773e7dfd5db5  vmovaps [rsp+0x90], xmm9
0000773e7dfd5dbe  vmovaps [rsp+0xA0], xmm10
0000773e7dfd5dc7  vmovaps [rsp+0xB0], xmm11
0000773e7dfd5dd0  vmovaps [rsp+0xC0], xmm13
0000773e7dfd5dd9  vmovaps [rsp+0xD0], xmm14
0000773e7dfd5de2  vmovaps [rsp+0xE0], xmm15
0000773e7dfd5deb  sub rsp, 0x40
0000773e7dfd5def  lea rdi, [rsp]
0000773e7dfd5df3  lea rsi, [rsp+0x10]
0000773e7dfd5df8  lea rdx, [rsp+0x20]
0000773e7dfd5dfd  lea rcx, [rsp+0x30]
0000773e7dfd5e02  mov r8d, 0x00
0000773e7dfd5e08  lea r9, [r15+0x3A8]
0000773e7dfd5e0f  movaps [rdi], xmm12
0000773e7dfd5e13  movaps [rsi], xmm10
0000773e7dfd5e17  movaps [rdx], xmm15
0000773e7dfd5e1b  movaps [rcx], xmm14
0000773e7dfd5e1f  mov rax, 0x567852F34A50
0000773e7dfd5e29  call rax
0000773e7dfd5e2b  movaps xmm12, [rsp]
0000773e7dfd5e30  add rsp, 0x40
0000773e7dfd5e34  vmovaps xmm0, [rsp]
0000773e7dfd5e39  vmovaps xmm1, [rsp+0x10]
0000773e7dfd5e3f  vmovaps xmm2, [rsp+0x20]
0000773e7dfd5e45  vmovaps xmm3, [rsp+0x30]
0000773e7dfd5e4b  vmovaps xmm4, [rsp+0x40]
0000773e7dfd5e51  vmovaps xmm5, [rsp+0x50]
0000773e7dfd5e57  vmovaps xmm6, [rsp+0x60]
0000773e7dfd5e5d  vmovaps xmm7, [rsp+0x70]
0000773e7dfd5e63  vmovaps xmm8, [rsp+0x80]
0000773e7dfd5e6c  vmovaps xmm9, [rsp+0x90]
0000773e7dfd5e75  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd5e7e  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd5e87  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd5e90  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd5e99  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd5ea2  add rsp, 0xF0
0000773e7dfd5ea9  pop r11
0000773e7dfd5eab  pop r10
0000773e7dfd5ead  pop r9
0000773e7dfd5eaf  pop r8
0000773e7dfd5eb1  pop rsi
0000773e7dfd5eb2  pop rdi
0000773e7dfd5eb3  pop rdx
0000773e7dfd5eb4  pop rcx
0000773e7dfd5eb5  pop rax
0000773e7dfd5eb6  add rsp, 0x08
0000773e7dfd5eba  jmp 0x0000773E7DFD3196
0000773e7dfd5ebf  sub rsp, 0x08
0000773e7dfd5ec3  push rax
0000773e7dfd5ec4  push rcx
0000773e7dfd5ec5  push rdx
0000773e7dfd5ec6  push rdi
0000773e7dfd5ec7  push rsi
0000773e7dfd5ec8  push r8
0000773e7dfd5eca  push r9
0000773e7dfd5ecc  push r10
0000773e7dfd5ece  push r11
0000773e7dfd5ed0  sub rsp, 0xF0
0000773e7dfd5ed7  vmovaps [rsp], xmm0
0000773e7dfd5edc  vmovaps [rsp+0x10], xmm1
0000773e7dfd5ee2  vmovaps [rsp+0x20], xmm2
0000773e7dfd5ee8  vmovaps [rsp+0x30], xmm3
0000773e7dfd5eee  vmovaps [rsp+0x40], xmm4
0000773e7dfd5ef4  vmovaps [rsp+0x50], xmm5
0000773e7dfd5efa  vmovaps [rsp+0x60], xmm6
0000773e7dfd5f00  vmovaps [rsp+0x70], xmm7
0000773e7dfd5f06  vmovaps [rsp+0x80], xmm8
0000773e7dfd5f0f  vmovaps [rsp+0x90], xmm9
0000773e7dfd5f18  vmovaps [rsp+0xA0], xmm10
0000773e7dfd5f21  vmovaps [rsp+0xB0], xmm11
0000773e7dfd5f2a  vmovaps [rsp+0xC0], xmm12
0000773e7dfd5f33  vmovaps [rsp+0xD0], xmm13
0000773e7dfd5f3c  vmovaps [rsp+0xE0], xmm15
0000773e7dfd5f45  sub rsp, 0x40
0000773e7dfd5f49  lea rdi, [rsp]
0000773e7dfd5f4d  lea rsi, [rsp+0x10]
0000773e7dfd5f52  lea rdx, [rsp+0x20]
0000773e7dfd5f57  lea rcx, [rsp+0x30]
0000773e7dfd5f5c  mov r8d, 0x00
0000773e7dfd5f62  lea r9, [r15+0x3A8]
0000773e7dfd5f69  movaps [rdi], xmm14
0000773e7dfd5f6d  movaps [rsi], xmm13
0000773e7dfd5f71  movaps [rdx], xmm1
0000773e7dfd5f74  movaps [rcx], xmm15
0000773e7dfd5f78  mov rax, 0x567852F34A50
0000773e7dfd5f82  call rax
0000773e7dfd5f84  movaps xmm14, [rsp]
0000773e7dfd5f89  add rsp, 0x40
0000773e7dfd5f8d  vmovaps xmm0, [rsp]
0000773e7dfd5f92  vmovaps xmm1, [rsp+0x10]
0000773e7dfd5f98  vmovaps xmm2, [rsp+0x20]
0000773e7dfd5f9e  vmovaps xmm3, [rsp+0x30]
0000773e7dfd5fa4  vmovaps xmm4, [rsp+0x40]
0000773e7dfd5faa  vmovaps xmm5, [rsp+0x50]
0000773e7dfd5fb0  vmovaps xmm6, [rsp+0x60]
0000773e7dfd5fb6  vmovaps xmm7, [rsp+0x70]
0000773e7dfd5fbc  vmovaps xmm8, [rsp+0x80]
0000773e7dfd5fc5  vmovaps xmm9, [rsp+0x90]
0000773e7dfd5fce  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd5fd7  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd5fe0  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd5fe9  vmovaps xmm13, [rsp+0xD0]
0000773e7dfd5ff2  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd5ffb  add rsp, 0xF0
0000773e7dfd6002  pop r11
0000773e7dfd6004  pop r10
0000773e7dfd6006  pop r9
0000773e7dfd6008  pop r8
0000773e7dfd600a  pop rsi
0000773e7dfd600b  pop rdi
0000773e7dfd600c  pop rdx
0000773e7dfd600d  pop rcx
0000773e7dfd600e  pop rax
0000773e7dfd600f  add rsp, 0x08
0000773e7dfd6013  jmp 0x0000773E7DFD31C7
0000773e7dfd6018  call 0x0000773E7DE079B0
0000773e7dfd601d  jmp 0x0000773E7DFD31DA
0000773e7dfd6022  call 0x0000773E7DE0B100
0000773e7dfd6027  jmp 0x0000773E7DFD31E5
0000773e7dfd602c  call 0x0000773E7DE09E90
0000773e7dfd6031  jmp 0x0000773E7DFD31F0
0000773e7dfd6036  call 0x0000773E7DE0D600
0000773e7dfd603b  jmp 0x0000773E7DFD31FB
0000773e7dfd6040  int3
0000773e7dfd6041  nop [rax+rax*1], ax
0000773e7dfd604a  nop [rax+rax*1], ax
0000773e7dfd6050  mov rax, [r15+0x40]
0000773e7dfd6054  mov r14, [r15+0x58]
0000773e7dfd6058  lea r12, [rax+r14*1]
0000773e7dfd605c  vxorps xmm1, xmm1, xmm1
0000773e7dfd6060  vpbroadcastq xmm1, xmm1
0000773e7dfd6065  vxorps xmm15, xmm15, xmm15
0000773e7dfd606a  vpbroadcastq xmm15, xmm15
0000773e7dfd606f  lea rax, [r12+0x30]
0000773e7dfd6074  mov r11, [r13+rax*1]
0000773e7dfd6079  lea rax, [r12+0x38]
0000773e7dfd607e  mov r10, [r13+rax*1]
0000773e7dfd6083  movq xmm14, r11
0000773e7dfd6088  movq xmm13, r10
0000773e7dfd608d  movq xmm14, xmm14
0000773e7dfd6092  movq xmm13, xmm13
0000773e7dfd6097  vmovaps [rsp+0x10], xmm13
0000773e7dfd609d  movq xmm13, xmm13
0000773e7dfd60a2  movaps [r15+0x270], xmm13
0000773e7dfd60aa  movaps xmm13, [r15+0x160]
0000773e7dfd60b2  vmovaps [rsp+0x20], xmm13
0000773e7dfd60b8  vmovaps xmm12, [rsp+0x20]
0000773e7dfd60be  por xmm13, xmm12
0000773e7dfd60c3  lea rax, [r12+0x20]
0000773e7dfd60c8  mov r11, [r13+rax*1]
0000773e7dfd60cd  lea rax, [r12+0x28]
0000773e7dfd60d2  mov r10, [r13+rax*1]
0000773e7dfd60d7  movq xmm12, r11
0000773e7dfd60dc  movq xmm11, r10
0000773e7dfd60e1  movq xmm12, xmm12
0000773e7dfd60e6  movq xmm11, xmm11
0000773e7dfd60eb  movaps xmm10, [r15+0x2D0]
0000773e7dfd60f3  vmovaps [rsp+0x20], xmm10
0000773e7dfd60f9  vmovaps xmm9, [rsp+0x20]
0000773e7dfd60ff  por xmm10, xmm9
0000773e7dfd6104  movaps xmm9, [r15+0x300]
0000773e7dfd610c  vmovaps [rsp+0x20], xmm9
0000773e7dfd6112  vmovaps xmm8, [rsp+0x20]
0000773e7dfd6118  por xmm9, xmm8
0000773e7dfd611d  movaps xmm8, [r15+0x2B0]
0000773e7dfd6125  vmovaps [rsp+0x20], xmm8
0000773e7dfd612b  vmovaps xmm7, [rsp+0x20]
0000773e7dfd6131  por xmm8, xmm7
0000773e7dfd6136  movaps xmm7, [r15+0x180]
0000773e7dfd613e  vmovaps [rsp+0x20], xmm7
0000773e7dfd6144  vmovaps xmm6, [rsp+0x20]
0000773e7dfd614a  por xmm7, xmm6
0000773e7dfd614e  lea rax, [r12+0x10]
0000773e7dfd6153  mov r11, [r13+rax*1]
0000773e7dfd6158  lea rax, [r12+0x18]
0000773e7dfd615d  mov r10, [r13+rax*1]
0000773e7dfd6162  movq xmm6, r11
0000773e7dfd6167  movq xmm5, r10
0000773e7dfd616c  movq xmm6, xmm6
0000773e7dfd6170  movq xmm5, xmm5
0000773e7dfd6174  movaps xmm4, [r15+0x200]
0000773e7dfd617c  vmovaps [rsp+0x20], xmm4
0000773e7dfd6182  vmovaps xmm3, [rsp+0x20]
0000773e7dfd6188  por xmm4, xmm3
0000773e7dfd618c  movaps xmm3, [r15+0x1F0]
0000773e7dfd6194  vmovaps [rsp+0x20], xmm3
0000773e7dfd619a  vmovaps xmm2, [rsp+0x20]
0000773e7dfd61a0  por xmm3, xmm2
0000773e7dfd61a4  movaps xmm2, [r15+0x2E0]
0000773e7dfd61ac  vmovaps [rsp+0x20], xmm2
0000773e7dfd61b2  vmovaps [rsp+0x30], xmm1
0000773e7dfd61b8  vmovaps xmm1, [rsp+0x20]
0000773e7dfd61be  por xmm2, xmm1
0000773e7dfd61c2  movaps xmm1, [r15+0x2A0]
0000773e7dfd61ca  vmovaps [rsp+0x20], xmm1
0000773e7dfd61d0  vmovaps [rsp+0x40], xmm15
0000773e7dfd61d6  vmovaps xmm15, [rsp+0x20]
0000773e7dfd61dc  por xmm1, xmm15
0000773e7dfd61e1  movaps xmm15, [r15+0x280]
0000773e7dfd61e9  vmovaps [rsp+0x20], xmm15
0000773e7dfd61ef  vmovaps [rsp+0x50], xmm1
0000773e7dfd61f5  vmovaps xmm1, [rsp+0x20]
0000773e7dfd61fb  por xmm15, xmm1
0000773e7dfd6200  movaps xmm1, [r15+0x1C0]
0000773e7dfd6208  vmovaps [rsp+0x20], xmm1
0000773e7dfd620e  vmovaps [rsp+0x60], xmm15
0000773e7dfd6214  vmovaps xmm15, [rsp+0x20]
0000773e7dfd621a  por xmm1, xmm15
0000773e7dfd621f  movaps xmm15, [r15+0x210]
0000773e7dfd6227  vmovaps [rsp+0x20], xmm15
0000773e7dfd622d  vmovaps [rsp+0x70], xmm1
0000773e7dfd6233  vmovaps xmm1, [rsp+0x20]
0000773e7dfd6239  por xmm15, xmm1
0000773e7dfd623e  mov rax, [r13+r12*1]
0000773e7dfd6243  vmovq xmm1, rax
0000773e7dfd6248  vpbroadcastq xmm1, xmm1
0000773e7dfd624d  vmovaps [rsp+0x20], xmm1
0000773e7dfd6253  vxorps xmm1, xmm1, xmm1
0000773e7dfd6257  vpbroadcastq xmm1, xmm1
0000773e7dfd625c  mov rax, [r15+0xF8]
0000773e7dfd6263  vmovaps [rsp+0x80], xmm1
0000773e7dfd626c  movups xmm1, [r13+rax*1]
0000773e7dfd6272  vmovaps [rsp+0x90], xmm1
0000773e7dfd627b  vxorps xmm1, xmm1, xmm1
0000773e7dfd627f  vpbroadcastq xmm1, xmm1
0000773e7dfd6284  lea r11, [r12+0x08]
0000773e7dfd6289  mov r12, [r13+r11*1]
0000773e7dfd628e  vmovaps [rsp+0xA0], xmm1
0000773e7dfd6297  movq xmm1, r12
0000773e7dfd629c  movaps [r15+0x240], xmm1
0000773e7dfd62a4  mov r12, [r15+0x50]
0000773e7dfd62a8  lea r11, [r12+r14*1]
0000773e7dfd62ac  mov [r15+0x60], r11
0000773e7dfd62b0  lea r12, [r14+0x40]
0000773e7dfd62b4  mov [r15+0x58], r12
0000773e7dfd62b8  vmovaps xmm1, [rsp+0x30]
0000773e7dfd62be  vmovaps [rsp+0x30], xmm15
0000773e7dfd62c4  vmovaps xmm15, [rsp+0x90]
0000773e7dfd62cd  vmovaps [rsp+0x90], xmm14
0000773e7dfd62d6  vmovaps xmm14, [rsp+0x20]
0000773e7dfd62dc  vmovaps [rsp+0x20], xmm13
0000773e7dfd62e2  vmovaps [rsp+0xB0], xmm12
0000773e7dfd62eb  movaps xmm13, xmm1
0000773e7dfd62ef  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd62fa  vptest xmm12, xmm12
0000773e7dfd62ff  jnz 0x0000773E7DFD6D9C
0000773e7dfd6305  movaps xmm1, [r15+0x250]
0000773e7dfd630d  vmovaps xmm15, [rsp+0x40]
0000773e7dfd6313  vmovaps [rsp+0x40], xmm13
0000773e7dfd6319  movaps xmm12, xmm15
0000773e7dfd631d  vfmadd231pd xmm12, xmm1, xmm14
0000773e7dfd6322  vcmppd xmm13, xmm12, xmm12, 0x03
0000773e7dfd6328  vptest xmm13, xmm13
0000773e7dfd632d  jnz 0x0000773E7DFD6EF5
0000773e7dfd6333  movaps xmm15, [r15+0x1E0]
0000773e7dfd633b  vmovaps [rsp+0xC0], xmm15
0000773e7dfd6344  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd634d  por xmm15, xmm13
0000773e7dfd6352  movaps xmm13, [r15+0x1D0]
0000773e7dfd635a  vmovaps [rsp+0xC0], xmm13
0000773e7dfd6363  vmovaps [rsp+0xD0], xmm1
0000773e7dfd636c  vmovaps xmm1, [rsp+0xC0]
0000773e7dfd6375  por xmm13, xmm1
0000773e7dfd637a  movaps xmm1, [r15+0x2C0]
0000773e7dfd6382  vmovaps [rsp+0xC0], xmm1
0000773e7dfd638b  vmovaps [rsp+0xE0], xmm15
0000773e7dfd6394  vmovaps xmm15, [rsp+0xC0]
0000773e7dfd639d  por xmm1, xmm15
0000773e7dfd63a2  movaps xmm15, [r15+0x290]
0000773e7dfd63aa  vmovaps [rsp+0xC0], xmm15
0000773e7dfd63b3  vmovaps [rsp+0xF0], xmm1
0000773e7dfd63bc  vmovaps xmm1, [rsp+0xC0]
0000773e7dfd63c5  por xmm15, xmm1
0000773e7dfd63ca  movaps xmm1, [r15+0x260]
0000773e7dfd63d2  vmovaps [rsp+0xC0], xmm1
0000773e7dfd63db  vmovaps [rsp+0x100], xmm15
0000773e7dfd63e4  vmovaps xmm15, [rsp+0xC0]
0000773e7dfd63ed  por xmm1, xmm15
0000773e7dfd63f2  vmovaps xmm15, [rsp+0xD0]
0000773e7dfd63fb  vmovaps [rsp+0xC0], xmm1
0000773e7dfd6404  vmovaps xmm1, [rsp+0xD0]
0000773e7dfd640d  por xmm15, xmm1
0000773e7dfd6412  lea r14, [rax+0xC0]
0000773e7dfd6419  movups xmm1, [r13+r14*1]
0000773e7dfd641f  mov [rsp+0xD0], rax
0000773e7dfd6427  xor eax, eax
0000773e7dfd6429  mov r14d, 0x200
0000773e7dfd642f  cmp r12, r14
0000773e7dfd6432  cmc
0000773e7dfd6433  lahf
0000773e7dfd6434  seto al
0000773e7dfd6437  mov [r15+0x108], eax
0000773e7dfd643e  vmovaps [rsp+0x110], xmm1
0000773e7dfd6447  vmovaps xmm1, [rsp+0x80]
0000773e7dfd6450  vmovaps [rsp+0x80], xmm15
0000773e7dfd6459  vmovaps xmm15, [rsp+0x110]
0000773e7dfd6462  vmovaps [rsp+0x110], xmm13
0000773e7dfd646b  vmovaps [rsp+0x120], xmm12
0000773e7dfd6474  movaps xmm13, xmm1
0000773e7dfd6478  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd647d  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd6483  vptest xmm12, xmm12
0000773e7dfd6488  jnz 0x0000773E7DFD7058
0000773e7dfd648e  mov rax, [rsp+0xD0]
0000773e7dfd6496  lea r14, [rax+0xB0]
0000773e7dfd649d  movups xmm1, [r13+r14*1]
0000773e7dfd64a3  vmovaps xmm15, [rsp+0xA0]
0000773e7dfd64ac  vmovaps [rsp+0xA0], xmm13
0000773e7dfd64b5  movaps xmm12, xmm15
0000773e7dfd64b9  vfmadd231pd xmm12, xmm1, xmm14
0000773e7dfd64be  vcmppd xmm13, xmm12, xmm12, 0x03
0000773e7dfd64c4  vptest xmm13, xmm13
0000773e7dfd64c9  jnz 0x0000773E7DFD71BB
0000773e7dfd64cf  vmovaps xmm1, [rsp+0x30]
0000773e7dfd64d5  vmovaps xmm15, [rsp+0x30]
0000773e7dfd64db  por xmm1, xmm15
0000773e7dfd64e0  movaps [r15+0x210], xmm1
0000773e7dfd64e8  vmovaps xmm15, [rsp+0x70]
0000773e7dfd64ee  vmovaps xmm14, [rsp+0x70]
0000773e7dfd64f4  por xmm15, xmm14
0000773e7dfd64f9  movaps [r15+0x1C0], xmm15
0000773e7dfd6501  vmovaps xmm14, [rsp+0x60]
0000773e7dfd6507  vmovaps xmm13, [rsp+0x60]
0000773e7dfd650d  por xmm14, xmm13
0000773e7dfd6512  movaps [r15+0x280], xmm14
0000773e7dfd651a  vmovaps xmm13, [rsp+0x50]
0000773e7dfd6520  vmovaps [rsp+0x30], xmm1
0000773e7dfd6526  vmovaps xmm1, [rsp+0x50]
0000773e7dfd652c  por xmm13, xmm1
0000773e7dfd6531  movaps [r15+0x2A0], xmm13
0000773e7dfd6539  vmovaps [rsp+0x50], xmm2
0000773e7dfd653f  vmovaps xmm1, [rsp+0x50]
0000773e7dfd6545  por xmm2, xmm1
0000773e7dfd6549  movaps [r15+0x2E0], xmm2
0000773e7dfd6551  vmovaps [rsp+0x50], xmm3
0000773e7dfd6557  vmovaps xmm1, [rsp+0x50]
0000773e7dfd655d  por xmm3, xmm1
0000773e7dfd6561  movaps [r15+0x1F0], xmm3
0000773e7dfd6569  vmovaps xmm1, [rsp+0x80]
0000773e7dfd6572  vmovaps [rsp+0x50], xmm15
0000773e7dfd6578  vmovaps xmm15, [rsp+0x80]
0000773e7dfd6581  por xmm1, xmm15
0000773e7dfd6586  movaps [r15+0x250], xmm1
0000773e7dfd658e  vmovaps xmm1, [rsp+0xC0]
0000773e7dfd6597  vmovaps xmm15, [rsp+0xC0]
0000773e7dfd65a0  por xmm1, xmm15
0000773e7dfd65a5  movaps [r15+0x260], xmm1
0000773e7dfd65ad  vmovaps xmm15, [rsp+0x100]
0000773e7dfd65b6  vmovaps [rsp+0x60], xmm1
0000773e7dfd65bc  vmovaps xmm1, [rsp+0x100]
0000773e7dfd65c5  por xmm15, xmm1
0000773e7dfd65ca  movaps [r15+0x290], xmm15
0000773e7dfd65d2  vmovaps xmm1, [rsp+0xF0]
0000773e7dfd65db  vmovaps [rsp+0x70], xmm15
0000773e7dfd65e1  vmovaps xmm15, [rsp+0xF0]
0000773e7dfd65ea  por xmm1, xmm15
0000773e7dfd65ef  movaps [r15+0x2C0], xmm1
0000773e7dfd65f7  movq xmm15, qword ptr [r15+0x240]
0000773e7dfd6600  vmovaps [rsp+0x80], xmm15
0000773e7dfd6609  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd660f  vmovaps [rsp+0xC0], xmm1
0000773e7dfd6618  vmovaps xmm1, [rsp+0x40]
0000773e7dfd661e  vmovaps [rsp+0x40], xmm15
0000773e7dfd6624  vmovaps xmm15, [rsp+0x30]
0000773e7dfd662a  vmovaps [rsp+0x30], xmm14
0000773e7dfd6630  vmovaps xmm14, [rsp+0x40]
0000773e7dfd6636  vmovaps [rsp+0x40], xmm13
0000773e7dfd663c  vmovaps [rsp+0xD0], xmm12
0000773e7dfd6645  movaps xmm13, xmm1
0000773e7dfd6649  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd664e  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd6654  vptest xmm12, xmm12
0000773e7dfd6659  jnz 0x0000773E7DFD7314
0000773e7dfd665f  vmovaps xmm1, [rsp+0x80]
0000773e7dfd6668  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd666e  vmovaps xmm15, [rsp+0xA0]
0000773e7dfd6677  movaps xmm14, xmm15
0000773e7dfd667b  vfmadd231pd xmm14, xmm2, xmm1
0000773e7dfd6680  vcmppd xmm12, xmm14, xmm14, 0x03
0000773e7dfd6686  vptest xmm12, xmm12
0000773e7dfd668b  jnz 0x0000773E7DFD746D
0000773e7dfd6691  vmovaps xmm1, [rsp+0x80]
0000773e7dfd669a  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd66a0  vmovaps xmm15, [rsp+0x120]
0000773e7dfd66a9  vmovaps xmm12, [rsp+0x50]
0000773e7dfd66af  vmovaps [rsp+0x50], xmm14
0000773e7dfd66b5  movaps xmm2, xmm15
0000773e7dfd66b9  vfmadd231pd xmm2, xmm12, xmm1
0000773e7dfd66be  vcmppd xmm14, xmm2, xmm2, 0x03
0000773e7dfd66c3  vptest xmm14, xmm14
0000773e7dfd66c8  jnz 0x0000773E7DFD75C5
0000773e7dfd66ce  vmovaps xmm1, [rsp+0x110]
0000773e7dfd66d7  vmovaps xmm15, [rsp+0x110]
0000773e7dfd66e0  por xmm1, xmm15
0000773e7dfd66e5  movaps [r15+0x1D0], xmm1
0000773e7dfd66ed  vmovaps xmm15, [rsp+0x80]
0000773e7dfd66f6  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd66fc  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd6705  vmovaps [rsp+0x80], xmm1
0000773e7dfd670e  movaps xmm12, xmm14
0000773e7dfd6712  vfmadd231pd xmm12, xmm3, xmm15
0000773e7dfd6717  vcmppd xmm1, xmm12, xmm12, 0x03
0000773e7dfd671d  vptest xmm1, xmm1
0000773e7dfd6722  jnz 0x0000773E7DFD771C
0000773e7dfd6728  vmovaps [rsp+0xA0], xmm4
0000773e7dfd6731  vmovaps xmm1, [rsp+0xA0]
0000773e7dfd673a  por xmm4, xmm1
0000773e7dfd673e  movaps [r15+0x200], xmm4
0000773e7dfd6746  vmovaps xmm1, [rsp+0xE0]
0000773e7dfd674f  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd6758  por xmm1, xmm15
0000773e7dfd675d  movaps [r15+0x1E0], xmm1
0000773e7dfd6765  vmovaps [rsp+0xA0], xmm8
0000773e7dfd676e  vmovaps xmm1, [rsp+0xA0]
0000773e7dfd6777  por xmm8, xmm1
0000773e7dfd677c  movaps [r15+0x2B0], xmm8
0000773e7dfd6784  vmovaps [rsp+0xA0], xmm9
0000773e7dfd678d  vmovaps xmm1, [rsp+0xA0]
0000773e7dfd6796  por xmm9, xmm1
0000773e7dfd679b  movaps [r15+0x300], xmm9
0000773e7dfd67a3  vmovaps [rsp+0xA0], xmm6
0000773e7dfd67ac  vpermilpd xmm6, xmm6, 0x00
0000773e7dfd67b2  vmovaps xmm14, [rsp+0x60]
0000773e7dfd67b8  movaps xmm9, xmm13
0000773e7dfd67bc  vfmadd231pd xmm9, xmm14, xmm6
0000773e7dfd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
0000773e7dfd67c7  vptest xmm3, xmm3
0000773e7dfd67cc  jnz 0x0000773E7DFD7875
0000773e7dfd67d2  vmovaps xmm14, [rsp+0xA0]
0000773e7dfd67db  vpermilpd xmm14, xmm14, 0x00
0000773e7dfd67e1  vmovaps xmm13, [rsp+0x50]
0000773e7dfd67e7  vmovaps xmm6, [rsp+0xC0]
0000773e7dfd67f0  vmovaps [rsp+0x50], xmm1
0000773e7dfd67f6  movaps xmm3, xmm13
0000773e7dfd67fa  vfmadd231pd xmm3, xmm6, xmm14
0000773e7dfd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
0000773e7dfd6804  vptest xmm1, xmm1
0000773e7dfd6809  jnz 0x0000773E7DFD79CE
0000773e7dfd680f  vmovaps xmm1, [rsp+0xA0]
0000773e7dfd6818  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd681e  vmovaps xmm14, [rsp+0x30]
0000773e7dfd6824  movaps xmm6, xmm2
0000773e7dfd6827  vfmadd231pd xmm6, xmm14, xmm1
0000773e7dfd682c  vcmppd xmm13, xmm6, xmm6, 0x03
0000773e7dfd6831  vptest xmm13, xmm13
0000773e7dfd6836  jnz 0x0000773E7DFD7B25
0000773e7dfd683c  vmovaps xmm1, [rsp+0xA0]
0000773e7dfd6845  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd684b  vmovaps xmm14, [rsp+0x80]
0000773e7dfd6854  movaps xmm13, xmm12
0000773e7dfd6858  vfmadd231pd xmm13, xmm14, xmm1
0000773e7dfd685d  vcmppd xmm2, xmm13, xmm13, 0x03
0000773e7dfd6863  vptest xmm2, xmm2
0000773e7dfd6868  jnz 0x0000773E7DFD7C7B
0000773e7dfd686e  vmovaps [rsp+0x30], xmm7
0000773e7dfd6874  vmovaps xmm1, [rsp+0x30]
0000773e7dfd687a  por xmm7, xmm1
0000773e7dfd687e  movaps [r15+0x180], xmm7
0000773e7dfd6886  vmovaps [rsp+0x30], xmm10
0000773e7dfd688c  vmovaps xmm1, [rsp+0x30]
0000773e7dfd6892  por xmm10, xmm1
0000773e7dfd6897  movaps [r15+0x2D0], xmm10
0000773e7dfd689f  vmovaps [rsp+0x30], xmm5
0000773e7dfd68a5  vpermilpd xmm5, xmm5, 0x00
0000773e7dfd68ab  vmovaps xmm14, [rsp+0x50]
0000773e7dfd68b1  movaps xmm12, xmm3
0000773e7dfd68b5  vfmadd231pd xmm12, xmm14, xmm5
0000773e7dfd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
0000773e7dfd68c0  vptest xmm10, xmm10
0000773e7dfd68c5  jnz 0x0000773E7DFD7DD4
0000773e7dfd68cb  vmovaps xmm14, [rsp+0x30]
0000773e7dfd68d1  vpermilpd xmm14, xmm14, 0x00
0000773e7dfd68d7  movaps xmm10, xmm9
0000773e7dfd68db  vfmadd231pd xmm10, xmm7, xmm14
0000773e7dfd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
0000773e7dfd68e6  vptest xmm5, xmm5
0000773e7dfd68eb  jnz 0x0000773E7DFD7F2C
0000773e7dfd68f1  lea r14, [rax+0x80]
0000773e7dfd68f8  movups xmm14, [r13+r14*1]
0000773e7dfd68fe  movaps [r15+0x2F0], xmm14
0000773e7dfd6906  vmovaps xmm9, [rsp+0x30]
0000773e7dfd690c  vpermilpd xmm9, xmm9, 0x00
0000773e7dfd6912  vmovaps xmm7, [rsp+0x70]
0000773e7dfd6918  movaps xmm5, xmm6
0000773e7dfd691b  vfmadd231pd xmm5, xmm7, xmm9
0000773e7dfd6920  vcmppd xmm3, xmm5, xmm5, 0x03
0000773e7dfd6925  vptest xmm3, xmm3
0000773e7dfd692a  jnz 0x0000773E7DFD808F
0000773e7dfd6930  vmovaps xmm9, [rsp+0x30]
0000773e7dfd6936  vpermilpd xmm9, xmm9, 0x00
0000773e7dfd693c  movaps xmm7, xmm13
0000773e7dfd6940  vfmadd231pd xmm7, xmm1, xmm9
0000773e7dfd6945  vcmppd xmm6, xmm7, xmm7, 0x03
0000773e7dfd694a  vptest xmm6, xmm6
0000773e7dfd694f  jnz 0x0000773E7DFD81E5
0000773e7dfd6955  vmovaps xmm1, [rsp+0x20]
0000773e7dfd695b  vmovaps xmm13, [rsp+0x20]
0000773e7dfd6961  por xmm1, xmm13
0000773e7dfd6966  movaps [r15+0x160], xmm1
0000773e7dfd696e  lea r14, [rax+0x40]
0000773e7dfd6972  movups xmm13, [r13+r14*1]
0000773e7dfd6978  lea r14, [rax+0x50]
0000773e7dfd697c  movups xmm9, [r13+r14*1]
0000773e7dfd6982  movaps [r15+0x1B0], xmm13
0000773e7dfd698a  movaps [r15+0x1A0], xmm9
0000773e7dfd6992  movaps xmm6, [r15+0x190]
0000773e7dfd699a  vmovaps xmm3, [rsp+0xB0]
0000773e7dfd69a3  vpermilpd xmm3, xmm3, 0x00
0000773e7dfd69a9  vmovaps [rsp+0x20], xmm1
0000773e7dfd69af  movaps xmm2, xmm12
0000773e7dfd69b3  vfmadd231pd xmm2, xmm6, xmm3
0000773e7dfd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
0000773e7dfd69bd  vptest xmm1, xmm1
0000773e7dfd69c2  jnz 0x0000773E7DFD8350
0000773e7dfd69c8  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd69d1  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd69d7  vmovaps xmm12, [rsp+0x20]
0000773e7dfd69dd  movaps xmm6, xmm10
0000773e7dfd69e1  vfmadd231pd xmm6, xmm12, xmm1
0000773e7dfd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
0000773e7dfd69eb  vptest xmm3, xmm3
0000773e7dfd69f0  jnz 0x0000773E7DFD84A6
0000773e7dfd69f6  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd69ff  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd6a05  vmovaps xmm12, [rsp+0x40]
0000773e7dfd6a0b  movaps xmm10, xmm5
0000773e7dfd6a0f  vfmadd231pd xmm10, xmm12, xmm1
0000773e7dfd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
0000773e7dfd6a1a  vptest xmm3, xmm3
0000773e7dfd6a1f  jnz 0x0000773E7DFD85FD
0000773e7dfd6a25  vmovaps xmm1, [rsp+0xB0]
0000773e7dfd6a2e  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd6a34  movaps xmm12, xmm7
0000773e7dfd6a38  vfmadd231pd xmm12, xmm15, xmm1
0000773e7dfd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
0000773e7dfd6a43  vptest xmm5, xmm5
0000773e7dfd6a48  jnz 0x0000773E7DFD8755
0000773e7dfd6a4e  lea r14, [rax+0x60]
0000773e7dfd6a52  movups xmm1, [r13+r14*1]
0000773e7dfd6a58  lea r14, [rax+0x70]
0000773e7dfd6a5c  movups xmm15, [r13+r14*1]
0000773e7dfd6a62  movaps [r15+0x150], xmm1
0000773e7dfd6a6a  movaps [r15+0x120], xmm15
0000773e7dfd6a72  vmovaps [rsp+0x20], xmm11
0000773e7dfd6a78  vpermilpd xmm11, xmm11, 0x00
0000773e7dfd6a7e  movaps xmm7, xmm2
0000773e7dfd6a81  vfmadd231pd xmm7, xmm9, xmm11
0000773e7dfd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
0000773e7dfd6a8b  vptest xmm5, xmm5
0000773e7dfd6a90  jnz 0x0000773E7DFD88C1
0000773e7dfd6a96  vmovaps xmm11, [rsp+0x20]
0000773e7dfd6a9c  vpermilpd xmm11, xmm11, 0x00
0000773e7dfd6aa2  movaps xmm9, xmm6
0000773e7dfd6aa6  vfmadd231pd xmm9, xmm1, xmm11
0000773e7dfd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
0000773e7dfd6ab1  vptest xmm5, xmm5
0000773e7dfd6ab6  jnz 0x0000773E7DFD8A18
0000773e7dfd6abc  vmovaps xmm1, [rsp+0x20]
0000773e7dfd6ac2  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd6ac8  movaps xmm11, xmm10
0000773e7dfd6acc  vfmadd231pd xmm11, xmm8, xmm1
0000773e7dfd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
0000773e7dfd6ad7  vptest xmm6, xmm6
0000773e7dfd6adc  jnz 0x0000773E7DFD8B70
0000773e7dfd6ae2  vmovaps xmm1, [rsp+0x20]
0000773e7dfd6ae8  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd6aee  movaps xmm10, xmm12
0000773e7dfd6af2  vfmadd231pd xmm10, xmm13, xmm1
0000773e7dfd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
0000773e7dfd6afd  vptest xmm8, xmm8
0000773e7dfd6b02  jnz 0x0000773E7DFD8CC9
0000773e7dfd6b08  lea r14, [rax+0x20]
0000773e7dfd6b0c  movups xmm1, [r13+r14*1]
0000773e7dfd6b12  lea r14, [rax+0x30]
0000773e7dfd6b16  movups xmm13, [r13+r14*1]
0000773e7dfd6b1c  vmovaps xmm12, [rsp+0x90]
0000773e7dfd6b25  vpermilpd xmm12, xmm12, 0x00
0000773e7dfd6b2b  movaps xmm8, xmm7
0000773e7dfd6b2f  vfmadd231pd xmm8, xmm4, xmm12
0000773e7dfd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
0000773e7dfd6b3a  vptest xmm6, xmm6
0000773e7dfd6b3f  jnz 0x0000773E7DFD8E36
0000773e7dfd6b45  vmovaps xmm12, [rsp+0x90]
0000773e7dfd6b4e  vpermilpd xmm12, xmm12, 0x00
0000773e7dfd6b54  movaps xmm7, xmm9
0000773e7dfd6b58  vfmadd231pd xmm7, xmm14, xmm12
0000773e7dfd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
0000773e7dfd6b62  vptest xmm6, xmm6
0000773e7dfd6b67  jnz 0x0000773E7DFD8F8E
0000773e7dfd6b6d  vmovaps xmm14, [rsp+0x90]
0000773e7dfd6b76  vpermilpd xmm14, xmm14, 0x00
0000773e7dfd6b7c  movaps xmm12, xmm11
0000773e7dfd6b80  vfmadd231pd xmm12, xmm15, xmm14
0000773e7dfd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
0000773e7dfd6b8b  vptest xmm9, xmm9
0000773e7dfd6b90  jnz 0x0000773E7DFD90E6
0000773e7dfd6b96  vmovaps xmm15, [rsp+0x90]
0000773e7dfd6b9f  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd6ba5  movaps xmm11, xmm10
0000773e7dfd6ba9  vfmadd231pd xmm11, xmm13, xmm15
0000773e7dfd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
0000773e7dfd6bb4  vptest xmm14, xmm14
0000773e7dfd6bb9  jnz 0x0000773E7DFD9240
0000773e7dfd6bbf  lea r14, [rax+0x90]
0000773e7dfd6bc6  movups xmm15, [r13+r14*1]
0000773e7dfd6bcc  lea r14, [rax+0xA0]
0000773e7dfd6bd3  movups xmm14, [r13+r14*1]
0000773e7dfd6bd9  movaps [r15+0x140], xmm15
0000773e7dfd6be1  movaps [r15+0x130], xmm14
0000773e7dfd6be9  vmovaps xmm13, [rsp+0x10]
0000773e7dfd6bef  vpermilpd xmm13, xmm13, 0x00
0000773e7dfd6bf5  movaps xmm10, xmm8
0000773e7dfd6bf9  vfmadd231pd xmm10, xmm1, xmm13
0000773e7dfd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
0000773e7dfd6c04  vptest xmm9, xmm9
0000773e7dfd6c09  jnz 0x0000773E7DFD93AE
0000773e7dfd6c0f  movaps [r15+0x220], xmm10
0000773e7dfd6c17  lea r14, [rax+0x10]
0000773e7dfd6c1b  movups xmm1, [r13+r14*1]
0000773e7dfd6c21  movaps [r15+0x240], xmm1
0000773e7dfd6c29  vmovaps xmm13, [rsp+0x10]
0000773e7dfd6c2f  vpermilpd xmm13, xmm13, 0x00
0000773e7dfd6c35  movaps xmm9, xmm7
0000773e7dfd6c39  vfmadd231pd xmm9, xmm14, xmm13
0000773e7dfd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
0000773e7dfd6c44  vptest xmm8, xmm8
0000773e7dfd6c49  jnz 0x0000773E7DFD9511
0000773e7dfd6c4f  movaps [r15+0x110], xmm9
0000773e7dfd6c57  vmovaps xmm14, [rsp+0x10]
0000773e7dfd6c5d  vpermilpd xmm14, xmm14, 0x00
0000773e7dfd6c63  movaps xmm13, xmm12
0000773e7dfd6c67  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
0000773e7dfd6c72  vptest xmm8, xmm8
0000773e7dfd6c77  jnz 0x0000773E7DFD966A
0000773e7dfd6c7d  movaps [r15+0x170], xmm13
0000773e7dfd6c85  vmovaps xmm15, [rsp+0x10]
0000773e7dfd6c8b  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd6c91  movaps xmm14, xmm11
0000773e7dfd6c95  vfmadd231pd xmm14, xmm1, xmm15
0000773e7dfd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
0000773e7dfd6ca0  vptest xmm12, xmm12
0000773e7dfd6ca5  jnz 0x0000773E7DFD97C4
0000773e7dfd6cab  movaps [r15+0x230], xmm14
0000773e7dfd6cb3  movups [r13+r11*1], xmm9
0000773e7dfd6cb9  lea rax, [r11+0x10]
0000773e7dfd6cbd  movups [r13+rax*1], xmm13
0000773e7dfd6cc3  lea rax, [r11+0x20]
0000773e7dfd6cc7  movups [r13+rax*1], xmm10
0000773e7dfd6ccd  lea rax, [r11+0x30]
0000773e7dfd6cd1  movups [r13+rax*1], xmm14
0000773e7dfd6cd7  mov eax, [r15+0x108]
0000773e7dfd6cde  sahf
0000773e7dfd6cdf  jnz 0x0000773E7DFD6D11
0000773e7dfd6ce1  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd6ce9  jz 0x0000773E7DFD9950
0000773e7dfd6cef  nop [rax+rax*1], ax
0000773e7dfd6cf8  nop [rax+rax*1], eax
0000773e7dfd6d00  mov eax, 0x410664
0000773e7dfd6d05  mov [r15+0x100], rax
0000773e7dfd6d0c  jmp 0x0000773E7DDFE110
0000773e7dfd6d11  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd6d19  jz 0x0000773E7DFD6050
0000773e7dfd6d1f  nop [rax+rax*1], ax
0000773e7dfd6d28  nop [rax+rax*1], eax
0000773e7dfd6d30  mov eax, 0x4104F0
0000773e7dfd6d35  mov [r15+0x100], rax
0000773e7dfd6d3c  jmp 0x0000773E7DDFE110
0000773e7dfd6d41  int3
0000773e7dfd6d42  call 0x0000773E7DE0A4B0
0000773e7dfd6d47  jmp 0x0000773E7DFD6079
0000773e7dfd6d4c  call 0x0000773E7DE09240
0000773e7dfd6d51  jmp 0x0000773E7DFD6083
0000773e7dfd6d56  call 0x0000773E7DE0A4B0
0000773e7dfd6d5b  jmp 0x0000773E7DFD60CD
0000773e7dfd6d60  call 0x0000773E7DE09240
0000773e7dfd6d65  jmp 0x0000773E7DFD60D7
0000773e7dfd6d6a  call 0x0000773E7DE0A4B0
0000773e7dfd6d6f  jmp 0x0000773E7DFD6158
0000773e7dfd6d74  call 0x0000773E7DE09240
0000773e7dfd6d79  jmp 0x0000773E7DFD6162
0000773e7dfd6d7e  call 0x0000773E7DEB47C0
0000773e7dfd6d83  jmp 0x0000773E7DFD6243
0000773e7dfd6d88  call 0x0000773E7DDFF430
0000773e7dfd6d8d  jmp 0x0000773E7DFD6272
0000773e7dfd6d92  call 0x0000773E7DEB0CE0
0000773e7dfd6d97  jmp 0x0000773E7DFD628E
0000773e7dfd6d9c  sub rsp, 0x08
0000773e7dfd6da0  push rax
0000773e7dfd6da1  push rcx
0000773e7dfd6da2  push rdx
0000773e7dfd6da3  push rdi
0000773e7dfd6da4  push rsi
0000773e7dfd6da5  push r8
0000773e7dfd6da7  push r9
0000773e7dfd6da9  push r10
0000773e7dfd6dab  push r11
0000773e7dfd6dad  sub rsp, 0xF0
0000773e7dfd6db4  vmovaps [rsp], xmm0
0000773e7dfd6db9  vmovaps [rsp+0x10], xmm1
0000773e7dfd6dbf  vmovaps [rsp+0x20], xmm2
0000773e7dfd6dc5  vmovaps [rsp+0x30], xmm3
0000773e7dfd6dcb  vmovaps [rsp+0x40], xmm4
0000773e7dfd6dd1  vmovaps [rsp+0x50], xmm5
0000773e7dfd6dd7  vmovaps [rsp+0x60], xmm6
0000773e7dfd6ddd  vmovaps [rsp+0x70], xmm7
0000773e7dfd6de3  vmovaps [rsp+0x80], xmm8
0000773e7dfd6dec  vmovaps [rsp+0x90], xmm9
0000773e7dfd6df5  vmovaps [rsp+0xA0], xmm10
0000773e7dfd6dfe  vmovaps [rsp+0xB0], xmm11
0000773e7dfd6e07  vmovaps [rsp+0xC0], xmm12
0000773e7dfd6e10  vmovaps [rsp+0xD0], xmm14
0000773e7dfd6e19  vmovaps [rsp+0xE0], xmm15
0000773e7dfd6e22  sub rsp, 0x40
0000773e7dfd6e26  lea rdi, [rsp]
0000773e7dfd6e2a  lea rsi, [rsp+0x10]
0000773e7dfd6e2f  lea rdx, [rsp+0x20]
0000773e7dfd6e34  lea rcx, [rsp+0x30]
0000773e7dfd6e39  mov r8d, 0x00
0000773e7dfd6e3f  lea r9, [r15+0x3A8]
0000773e7dfd6e46  movaps [rdi], xmm13
0000773e7dfd6e4a  movaps [rsi], xmm1
0000773e7dfd6e4d  movaps [rdx], xmm15
0000773e7dfd6e51  movaps [rcx], xmm14
0000773e7dfd6e55  mov rax, 0x567852F34A50
0000773e7dfd6e5f  call rax
0000773e7dfd6e61  movaps xmm13, [rsp]
0000773e7dfd6e66  add rsp, 0x40
0000773e7dfd6e6a  vmovaps xmm0, [rsp]
0000773e7dfd6e6f  vmovaps xmm1, [rsp+0x10]
0000773e7dfd6e75  vmovaps xmm2, [rsp+0x20]
0000773e7dfd6e7b  vmovaps xmm3, [rsp+0x30]
0000773e7dfd6e81  vmovaps xmm4, [rsp+0x40]
0000773e7dfd6e87  vmovaps xmm5, [rsp+0x50]
0000773e7dfd6e8d  vmovaps xmm6, [rsp+0x60]
0000773e7dfd6e93  vmovaps xmm7, [rsp+0x70]
0000773e7dfd6e99  vmovaps xmm8, [rsp+0x80]
0000773e7dfd6ea2  vmovaps xmm9, [rsp+0x90]
0000773e7dfd6eab  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd6eb4  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd6ebd  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd6ec6  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd6ecf  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd6ed8  add rsp, 0xF0
0000773e7dfd6edf  pop r11
0000773e7dfd6ee1  pop r10
0000773e7dfd6ee3  pop r9
0000773e7dfd6ee5  pop r8
0000773e7dfd6ee7  pop rsi
0000773e7dfd6ee8  pop rdi
0000773e7dfd6ee9  pop rdx
0000773e7dfd6eea  pop rcx
0000773e7dfd6eeb  pop rax
0000773e7dfd6eec  add rsp, 0x08
0000773e7dfd6ef0  jmp 0x0000773E7DFD6305
0000773e7dfd6ef5  sub rsp, 0x08
0000773e7dfd6ef9  push rax
0000773e7dfd6efa  push rcx
0000773e7dfd6efb  push rdx
0000773e7dfd6efc  push rdi
0000773e7dfd6efd  push rsi
0000773e7dfd6efe  push r8
0000773e7dfd6f00  push r9
0000773e7dfd6f02  push r10
0000773e7dfd6f04  push r11
0000773e7dfd6f06  sub rsp, 0xF0
0000773e7dfd6f0d  vmovaps [rsp], xmm0
0000773e7dfd6f12  vmovaps [rsp+0x10], xmm1
0000773e7dfd6f18  vmovaps [rsp+0x20], xmm2
0000773e7dfd6f1e  vmovaps [rsp+0x30], xmm3
0000773e7dfd6f24  vmovaps [rsp+0x40], xmm4
0000773e7dfd6f2a  vmovaps [rsp+0x50], xmm5
0000773e7dfd6f30  vmovaps [rsp+0x60], xmm6
0000773e7dfd6f36  vmovaps [rsp+0x70], xmm7
0000773e7dfd6f3c  vmovaps [rsp+0x80], xmm8
0000773e7dfd6f45  vmovaps [rsp+0x90], xmm9
0000773e7dfd6f4e  vmovaps [rsp+0xA0], xmm10
0000773e7dfd6f57  vmovaps [rsp+0xB0], xmm11
0000773e7dfd6f60  vmovaps [rsp+0xC0], xmm13
0000773e7dfd6f69  vmovaps [rsp+0xD0], xmm14
0000773e7dfd6f72  vmovaps [rsp+0xE0], xmm15
0000773e7dfd6f7b  sub rsp, 0x40
0000773e7dfd6f7f  lea rdi, [rsp]
0000773e7dfd6f83  lea rsi, [rsp+0x10]
0000773e7dfd6f88  lea rdx, [rsp+0x20]
0000773e7dfd6f8d  lea rcx, [rsp+0x30]
0000773e7dfd6f92  mov r8d, 0x00
0000773e7dfd6f98  lea r9, [r15+0x3A8]
0000773e7dfd6f9f  movaps [rdi], xmm12
0000773e7dfd6fa3  movaps [rsi], xmm15
0000773e7dfd6fa7  movaps [rdx], xmm1
0000773e7dfd6faa  movaps [rcx], xmm14
0000773e7dfd6fae  mov rax, 0x567852F34A50
0000773e7dfd6fb8  call rax
0000773e7dfd6fba  movaps xmm12, [rsp]
0000773e7dfd6fbf  add rsp, 0x40
0000773e7dfd6fc3  vmovaps xmm0, [rsp]
0000773e7dfd6fc8  vmovaps xmm1, [rsp+0x10]
0000773e7dfd6fce  vmovaps xmm2, [rsp+0x20]
0000773e7dfd6fd4  vmovaps xmm3, [rsp+0x30]
0000773e7dfd6fda  vmovaps xmm4, [rsp+0x40]
0000773e7dfd6fe0  vmovaps xmm5, [rsp+0x50]
0000773e7dfd6fe6  vmovaps xmm6, [rsp+0x60]
0000773e7dfd6fec  vmovaps xmm7, [rsp+0x70]
0000773e7dfd6ff2  vmovaps xmm8, [rsp+0x80]
0000773e7dfd6ffb  vmovaps xmm9, [rsp+0x90]
0000773e7dfd7004  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd700d  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd7016  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd701f  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd7028  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd7031  add rsp, 0xF0
0000773e7dfd7038  pop r11
0000773e7dfd703a  pop r10
0000773e7dfd703c  pop r9
0000773e7dfd703e  pop r8
0000773e7dfd7040  pop rsi
0000773e7dfd7041  pop rdi
0000773e7dfd7042  pop rdx
0000773e7dfd7043  pop rcx
0000773e7dfd7044  pop rax
0000773e7dfd7045  add rsp, 0x08
0000773e7dfd7049  jmp 0x0000773E7DFD6333
0000773e7dfd704e  call 0x0000773E7DED64F0
0000773e7dfd7053  jmp 0x0000773E7DFD641F
0000773e7dfd7058  sub rsp, 0x08
0000773e7dfd705c  push rax
0000773e7dfd705d  push rcx
0000773e7dfd705e  push rdx
0000773e7dfd705f  push rdi
0000773e7dfd7060  push rsi
0000773e7dfd7061  push r8
0000773e7dfd7063  push r9
0000773e7dfd7065  push r10
0000773e7dfd7067  push r11
0000773e7dfd7069  sub rsp, 0xF0
0000773e7dfd7070  vmovaps [rsp], xmm0
0000773e7dfd7075  vmovaps [rsp+0x10], xmm1
0000773e7dfd707b  vmovaps [rsp+0x20], xmm2
0000773e7dfd7081  vmovaps [rsp+0x30], xmm3
0000773e7dfd7087  vmovaps [rsp+0x40], xmm4
0000773e7dfd708d  vmovaps [rsp+0x50], xmm5
0000773e7dfd7093  vmovaps [rsp+0x60], xmm6
0000773e7dfd7099  vmovaps [rsp+0x70], xmm7
0000773e7dfd709f  vmovaps [rsp+0x80], xmm8
0000773e7dfd70a8  vmovaps [rsp+0x90], xmm9
0000773e7dfd70b1  vmovaps [rsp+0xA0], xmm10
0000773e7dfd70ba  vmovaps [rsp+0xB0], xmm11
0000773e7dfd70c3  vmovaps [rsp+0xC0], xmm12
0000773e7dfd70cc  vmovaps [rsp+0xD0], xmm14
0000773e7dfd70d5  vmovaps [rsp+0xE0], xmm15
0000773e7dfd70de  sub rsp, 0x40
0000773e7dfd70e2  lea rdi, [rsp]
0000773e7dfd70e6  lea rsi, [rsp+0x10]
0000773e7dfd70eb  lea rdx, [rsp+0x20]
0000773e7dfd70f0  lea rcx, [rsp+0x30]
0000773e7dfd70f5  mov r8d, 0x00
0000773e7dfd70fb  lea r9, [r15+0x3A8]
0000773e7dfd7102  movaps [rdi], xmm13
0000773e7dfd7106  movaps [rsi], xmm1
0000773e7dfd7109  movaps [rdx], xmm15
0000773e7dfd710d  movaps [rcx], xmm14
0000773e7dfd7111  mov rax, 0x567852F34A50
0000773e7dfd711b  call rax
0000773e7dfd711d  movaps xmm13, [rsp]
0000773e7dfd7122  add rsp, 0x40
0000773e7dfd7126  vmovaps xmm0, [rsp]
0000773e7dfd712b  vmovaps xmm1, [rsp+0x10]
0000773e7dfd7131  vmovaps xmm2, [rsp+0x20]
0000773e7dfd7137  vmovaps xmm3, [rsp+0x30]
0000773e7dfd713d  vmovaps xmm4, [rsp+0x40]
0000773e7dfd7143  vmovaps xmm5, [rsp+0x50]
0000773e7dfd7149  vmovaps xmm6, [rsp+0x60]
0000773e7dfd714f  vmovaps xmm7, [rsp+0x70]
0000773e7dfd7155  vmovaps xmm8, [rsp+0x80]
0000773e7dfd715e  vmovaps xmm9, [rsp+0x90]
0000773e7dfd7167  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd7170  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd7179  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd7182  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd718b  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd7194  add rsp, 0xF0
0000773e7dfd719b  pop r11
0000773e7dfd719d  pop r10
0000773e7dfd719f  pop r9
0000773e7dfd71a1  pop r8
0000773e7dfd71a3  pop rsi
0000773e7dfd71a4  pop rdi
0000773e7dfd71a5  pop rdx
0000773e7dfd71a6  pop rcx
0000773e7dfd71a7  pop rax
0000773e7dfd71a8  add rsp, 0x08
0000773e7dfd71ac  jmp 0x0000773E7DFD648E
0000773e7dfd71b1  call 0x0000773E7DED64F0
0000773e7dfd71b6  jmp 0x0000773E7DFD64A3
0000773e7dfd71bb  sub rsp, 0x08
0000773e7dfd71bf  push rax
0000773e7dfd71c0  push rcx
0000773e7dfd71c1  push rdx
0000773e7dfd71c2  push rdi
0000773e7dfd71c3  push rsi
0000773e7dfd71c4  push r8
0000773e7dfd71c6  push r9
0000773e7dfd71c8  push r10
0000773e7dfd71ca  push r11
0000773e7dfd71cc  sub rsp, 0xF0
0000773e7dfd71d3  vmovaps [rsp], xmm0
0000773e7dfd71d8  vmovaps [rsp+0x10], xmm1
0000773e7dfd71de  vmovaps [rsp+0x20], xmm2
0000773e7dfd71e4  vmovaps [rsp+0x30], xmm3
0000773e7dfd71ea  vmovaps [rsp+0x40], xmm4
0000773e7dfd71f0  vmovaps [rsp+0x50], xmm5
0000773e7dfd71f6  vmovaps [rsp+0x60], xmm6
0000773e7dfd71fc  vmovaps [rsp+0x70], xmm7
0000773e7dfd7202  vmovaps [rsp+0x80], xmm8
0000773e7dfd720b  vmovaps [rsp+0x90], xmm9
0000773e7dfd7214  vmovaps [rsp+0xA0], xmm10
0000773e7dfd721d  vmovaps [rsp+0xB0], xmm11
0000773e7dfd7226  vmovaps [rsp+0xC0], xmm13
0000773e7dfd722f  vmovaps [rsp+0xD0], xmm14
0000773e7dfd7238  vmovaps [rsp+0xE0], xmm15
0000773e7dfd7241  sub rsp, 0x40
0000773e7dfd7245  lea rdi, [rsp]
0000773e7dfd7249  lea rsi, [rsp+0x10]
0000773e7dfd724e  lea rdx, [rsp+0x20]
0000773e7dfd7253  lea rcx, [rsp+0x30]
0000773e7dfd7258  mov r8d, 0x00
0000773e7dfd725e  lea r9, [r15+0x3A8]
0000773e7dfd7265  movaps [rdi], xmm12
0000773e7dfd7269  movaps [rsi], xmm15
0000773e7dfd726d  movaps [rdx], xmm1
0000773e7dfd7270  movaps [rcx], xmm14
0000773e7dfd7274  mov rax, 0x567852F34A50
0000773e7dfd727e  call rax
0000773e7dfd7280  movaps xmm12, [rsp]
0000773e7dfd7285  add rsp, 0x40
0000773e7dfd7289  vmovaps xmm0, [rsp]
0000773e7dfd728e  vmovaps xmm1, [rsp+0x10]
0000773e7dfd7294  vmovaps xmm2, [rsp+0x20]
0000773e7dfd729a  vmovaps xmm3, [rsp+0x30]
0000773e7dfd72a0  vmovaps xmm4, [rsp+0x40]
0000773e7dfd72a6  vmovaps xmm5, [rsp+0x50]
0000773e7dfd72ac  vmovaps xmm6, [rsp+0x60]
0000773e7dfd72b2  vmovaps xmm7, [rsp+0x70]
0000773e7dfd72b8  vmovaps xmm8, [rsp+0x80]
0000773e7dfd72c1  vmovaps xmm9, [rsp+0x90]
0000773e7dfd72ca  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd72d3  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd72dc  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd72e5  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd72ee  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd72f7  add rsp, 0xF0
0000773e7dfd72fe  pop r11
0000773e7dfd7300  pop r10
0000773e7dfd7302  pop r9
0000773e7dfd7304  pop r8
0000773e7dfd7306  pop rsi
0000773e7dfd7307  pop rdi
0000773e7dfd7308  pop rdx
0000773e7dfd7309  pop rcx
0000773e7dfd730a  pop rax
0000773e7dfd730b  add rsp, 0x08
0000773e7dfd730f  jmp 0x0000773E7DFD64CF
0000773e7dfd7314  sub rsp, 0x08
0000773e7dfd7318  push rax
0000773e7dfd7319  push rcx
0000773e7dfd731a  push rdx
0000773e7dfd731b  push rdi
0000773e7dfd731c  push rsi
0000773e7dfd731d  push r8
0000773e7dfd731f  push r9
0000773e7dfd7321  push r10
0000773e7dfd7323  push r11
0000773e7dfd7325  sub rsp, 0xF0
0000773e7dfd732c  vmovaps [rsp], xmm0
0000773e7dfd7331  vmovaps [rsp+0x10], xmm1
0000773e7dfd7337  vmovaps [rsp+0x20], xmm2
0000773e7dfd733d  vmovaps [rsp+0x30], xmm3
0000773e7dfd7343  vmovaps [rsp+0x40], xmm4
0000773e7dfd7349  vmovaps [rsp+0x50], xmm5
0000773e7dfd734f  vmovaps [rsp+0x60], xmm6
0000773e7dfd7355  vmovaps [rsp+0x70], xmm7
0000773e7dfd735b  vmovaps [rsp+0x80], xmm8
0000773e7dfd7364  vmovaps [rsp+0x90], xmm9
0000773e7dfd736d  vmovaps [rsp+0xA0], xmm10
0000773e7dfd7376  vmovaps [rsp+0xB0], xmm11
0000773e7dfd737f  vmovaps [rsp+0xC0], xmm12
0000773e7dfd7388  vmovaps [rsp+0xD0], xmm14
0000773e7dfd7391  vmovaps [rsp+0xE0], xmm15
0000773e7dfd739a  sub rsp, 0x40
0000773e7dfd739e  lea rdi, [rsp]
0000773e7dfd73a2  lea rsi, [rsp+0x10]
0000773e7dfd73a7  lea rdx, [rsp+0x20]
0000773e7dfd73ac  lea rcx, [rsp+0x30]
0000773e7dfd73b1  mov r8d, 0x00
0000773e7dfd73b7  lea r9, [r15+0x3A8]
0000773e7dfd73be  movaps [rdi], xmm13
0000773e7dfd73c2  movaps [rsi], xmm1
0000773e7dfd73c5  movaps [rdx], xmm15
0000773e7dfd73c9  movaps [rcx], xmm14
0000773e7dfd73cd  mov rax, 0x567852F34A50
0000773e7dfd73d7  call rax
0000773e7dfd73d9  movaps xmm13, [rsp]
0000773e7dfd73de  add rsp, 0x40
0000773e7dfd73e2  vmovaps xmm0, [rsp]
0000773e7dfd73e7  vmovaps xmm1, [rsp+0x10]
0000773e7dfd73ed  vmovaps xmm2, [rsp+0x20]
0000773e7dfd73f3  vmovaps xmm3, [rsp+0x30]
0000773e7dfd73f9  vmovaps xmm4, [rsp+0x40]
0000773e7dfd73ff  vmovaps xmm5, [rsp+0x50]
0000773e7dfd7405  vmovaps xmm6, [rsp+0x60]
0000773e7dfd740b  vmovaps xmm7, [rsp+0x70]
0000773e7dfd7411  vmovaps xmm8, [rsp+0x80]
0000773e7dfd741a  vmovaps xmm9, [rsp+0x90]
0000773e7dfd7423  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd742c  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd7435  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd743e  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd7447  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd7450  add rsp, 0xF0
0000773e7dfd7457  pop r11
0000773e7dfd7459  pop r10
0000773e7dfd745b  pop r9
0000773e7dfd745d  pop r8
0000773e7dfd745f  pop rsi
0000773e7dfd7460  pop rdi
0000773e7dfd7461  pop rdx
0000773e7dfd7462  pop rcx
0000773e7dfd7463  pop rax
0000773e7dfd7464  add rsp, 0x08
0000773e7dfd7468  jmp 0x0000773E7DFD665F
0000773e7dfd746d  sub rsp, 0x08
0000773e7dfd7471  push rax
0000773e7dfd7472  push rcx
0000773e7dfd7473  push rdx
0000773e7dfd7474  push rdi
0000773e7dfd7475  push rsi
0000773e7dfd7476  push r8
0000773e7dfd7478  push r9
0000773e7dfd747a  push r10
0000773e7dfd747c  push r11
0000773e7dfd747e  sub rsp, 0xF0
0000773e7dfd7485  vmovaps [rsp], xmm0
0000773e7dfd748a  vmovaps [rsp+0x10], xmm1
0000773e7dfd7490  vmovaps [rsp+0x20], xmm2
0000773e7dfd7496  vmovaps [rsp+0x30], xmm3
0000773e7dfd749c  vmovaps [rsp+0x40], xmm4
0000773e7dfd74a2  vmovaps [rsp+0x50], xmm5
0000773e7dfd74a8  vmovaps [rsp+0x60], xmm6
0000773e7dfd74ae  vmovaps [rsp+0x70], xmm7
0000773e7dfd74b4  vmovaps [rsp+0x80], xmm8
0000773e7dfd74bd  vmovaps [rsp+0x90], xmm9
0000773e7dfd74c6  vmovaps [rsp+0xA0], xmm10
0000773e7dfd74cf  vmovaps [rsp+0xB0], xmm11
0000773e7dfd74d8  vmovaps [rsp+0xC0], xmm12
0000773e7dfd74e1  vmovaps [rsp+0xD0], xmm13
0000773e7dfd74ea  vmovaps [rsp+0xE0], xmm15
0000773e7dfd74f3  sub rsp, 0x40
0000773e7dfd74f7  lea rdi, [rsp]
0000773e7dfd74fb  lea rsi, [rsp+0x10]
0000773e7dfd7500  lea rdx, [rsp+0x20]
0000773e7dfd7505  lea rcx, [rsp+0x30]
0000773e7dfd750a  mov r8d, 0x00
0000773e7dfd7510  lea r9, [r15+0x3A8]
0000773e7dfd7517  movaps [rdi], xmm14
0000773e7dfd751b  movaps [rsi], xmm15
0000773e7dfd751f  movaps [rdx], xmm2
0000773e7dfd7522  movaps [rcx], xmm1
0000773e7dfd7525  mov rax, 0x567852F34A50
0000773e7dfd752f  call rax
0000773e7dfd7531  movaps xmm14, [rsp]
0000773e7dfd7536  add rsp, 0x40
0000773e7dfd753a  vmovaps xmm0, [rsp]
0000773e7dfd753f  vmovaps xmm1, [rsp+0x10]
0000773e7dfd7545  vmovaps xmm2, [rsp+0x20]
0000773e7dfd754b  vmovaps xmm3, [rsp+0x30]
0000773e7dfd7551  vmovaps xmm4, [rsp+0x40]
0000773e7dfd7557  vmovaps xmm5, [rsp+0x50]
0000773e7dfd755d  vmovaps xmm6, [rsp+0x60]
0000773e7dfd7563  vmovaps xmm7, [rsp+0x70]
0000773e7dfd7569  vmovaps xmm8, [rsp+0x80]
0000773e7dfd7572  vmovaps xmm9, [rsp+0x90]
0000773e7dfd757b  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd7584  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd758d  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd7596  vmovaps xmm13, [rsp+0xD0]
0000773e7dfd759f  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd75a8  add rsp, 0xF0
0000773e7dfd75af  pop r11
0000773e7dfd75b1  pop r10
0000773e7dfd75b3  pop r9
0000773e7dfd75b5  pop r8
0000773e7dfd75b7  pop rsi
0000773e7dfd75b8  pop rdi
0000773e7dfd75b9  pop rdx
0000773e7dfd75ba  pop rcx
0000773e7dfd75bb  pop rax
0000773e7dfd75bc  add rsp, 0x08
0000773e7dfd75c0  jmp 0x0000773E7DFD6691
0000773e7dfd75c5  sub rsp, 0x08
0000773e7dfd75c9  push rax
0000773e7dfd75ca  push rcx
0000773e7dfd75cb  push rdx
0000773e7dfd75cc  push rdi
0000773e7dfd75cd  push rsi
0000773e7dfd75ce  push r8
0000773e7dfd75d0  push r9
0000773e7dfd75d2  push r10
0000773e7dfd75d4  push r11
0000773e7dfd75d6  sub rsp, 0xF0
0000773e7dfd75dd  vmovaps [rsp], xmm0
0000773e7dfd75e2  vmovaps [rsp+0x10], xmm1
0000773e7dfd75e8  vmovaps [rsp+0x20], xmm3
0000773e7dfd75ee  vmovaps [rsp+0x30], xmm4
0000773e7dfd75f4  vmovaps [rsp+0x40], xmm5
0000773e7dfd75fa  vmovaps [rsp+0x50], xmm6
0000773e7dfd7600  vmovaps [rsp+0x60], xmm7
0000773e7dfd7606  vmovaps [rsp+0x70], xmm8
0000773e7dfd760c  vmovaps [rsp+0x80], xmm9
0000773e7dfd7615  vmovaps [rsp+0x90], xmm10
0000773e7dfd761e  vmovaps [rsp+0xA0], xmm11
0000773e7dfd7627  vmovaps [rsp+0xB0], xmm12
0000773e7dfd7630  vmovaps [rsp+0xC0], xmm13
0000773e7dfd7639  vmovaps [rsp+0xD0], xmm14
0000773e7dfd7642  vmovaps [rsp+0xE0], xmm15
0000773e7dfd764b  sub rsp, 0x40
0000773e7dfd764f  lea rdi, [rsp]
0000773e7dfd7653  lea rsi, [rsp+0x10]
0000773e7dfd7658  lea rdx, [rsp+0x20]
0000773e7dfd765d  lea rcx, [rsp+0x30]
0000773e7dfd7662  mov r8d, 0x00
0000773e7dfd7668  lea r9, [r15+0x3A8]
0000773e7dfd766f  movaps [rdi], xmm2
0000773e7dfd7672  movaps [rsi], xmm15
0000773e7dfd7676  movaps [rdx], xmm12
0000773e7dfd767a  movaps [rcx], xmm1
0000773e7dfd767d  mov rax, 0x567852F34A50
0000773e7dfd7687  call rax
0000773e7dfd7689  movaps xmm2, [rsp]
0000773e7dfd768d  add rsp, 0x40
0000773e7dfd7691  vmovaps xmm0, [rsp]
0000773e7dfd7696  vmovaps xmm1, [rsp+0x10]
0000773e7dfd769c  vmovaps xmm3, [rsp+0x20]
0000773e7dfd76a2  vmovaps xmm4, [rsp+0x30]
0000773e7dfd76a8  vmovaps xmm5, [rsp+0x40]
0000773e7dfd76ae  vmovaps xmm6, [rsp+0x50]
0000773e7dfd76b4  vmovaps xmm7, [rsp+0x60]
0000773e7dfd76ba  vmovaps xmm8, [rsp+0x70]
0000773e7dfd76c0  vmovaps xmm9, [rsp+0x80]
0000773e7dfd76c9  vmovaps xmm10, [rsp+0x90]
0000773e7dfd76d2  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd76db  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd76e4  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd76ed  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd76f6  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd76ff  add rsp, 0xF0
0000773e7dfd7706  pop r11
0000773e7dfd7708  pop r10
0000773e7dfd770a  pop r9
0000773e7dfd770c  pop r8
0000773e7dfd770e  pop rsi
0000773e7dfd770f  pop rdi
0000773e7dfd7710  pop rdx
0000773e7dfd7711  pop rcx
0000773e7dfd7712  pop rax
0000773e7dfd7713  add rsp, 0x08
0000773e7dfd7717  jmp 0x0000773E7DFD66CE
0000773e7dfd771c  sub rsp, 0x08
0000773e7dfd7720  push rax
0000773e7dfd7721  push rcx
0000773e7dfd7722  push rdx
0000773e7dfd7723  push rdi
0000773e7dfd7724  push rsi
0000773e7dfd7725  push r8
0000773e7dfd7727  push r9
0000773e7dfd7729  push r10
0000773e7dfd772b  push r11
0000773e7dfd772d  sub rsp, 0xF0
0000773e7dfd7734  vmovaps [rsp], xmm0
0000773e7dfd7739  vmovaps [rsp+0x10], xmm1
0000773e7dfd773f  vmovaps [rsp+0x20], xmm2
0000773e7dfd7745  vmovaps [rsp+0x30], xmm3
0000773e7dfd774b  vmovaps [rsp+0x40], xmm4
0000773e7dfd7751  vmovaps [rsp+0x50], xmm5
0000773e7dfd7757  vmovaps [rsp+0x60], xmm6
0000773e7dfd775d  vmovaps [rsp+0x70], xmm7
0000773e7dfd7763  vmovaps [rsp+0x80], xmm8
0000773e7dfd776c  vmovaps [rsp+0x90], xmm9
0000773e7dfd7775  vmovaps [rsp+0xA0], xmm10
0000773e7dfd777e  vmovaps [rsp+0xB0], xmm11
0000773e7dfd7787  vmovaps [rsp+0xC0], xmm13
0000773e7dfd7790  vmovaps [rsp+0xD0], xmm14
0000773e7dfd7799  vmovaps [rsp+0xE0], xmm15
0000773e7dfd77a2  sub rsp, 0x40
0000773e7dfd77a6  lea rdi, [rsp]
0000773e7dfd77aa  lea rsi, [rsp+0x10]
0000773e7dfd77af  lea rdx, [rsp+0x20]
0000773e7dfd77b4  lea rcx, [rsp+0x30]
0000773e7dfd77b9  mov r8d, 0x00
0000773e7dfd77bf  lea r9, [r15+0x3A8]
0000773e7dfd77c6  movaps [rdi], xmm12
0000773e7dfd77ca  movaps [rsi], xmm14
0000773e7dfd77ce  movaps [rdx], xmm3
0000773e7dfd77d1  movaps [rcx], xmm15
0000773e7dfd77d5  mov rax, 0x567852F34A50
0000773e7dfd77df  call rax
0000773e7dfd77e1  movaps xmm12, [rsp]
0000773e7dfd77e6  add rsp, 0x40
0000773e7dfd77ea  vmovaps xmm0, [rsp]
0000773e7dfd77ef  vmovaps xmm1, [rsp+0x10]
0000773e7dfd77f5  vmovaps xmm2, [rsp+0x20]
0000773e7dfd77fb  vmovaps xmm3, [rsp+0x30]
0000773e7dfd7801  vmovaps xmm4, [rsp+0x40]
0000773e7dfd7807  vmovaps xmm5, [rsp+0x50]
0000773e7dfd780d  vmovaps xmm6, [rsp+0x60]
0000773e7dfd7813  vmovaps xmm7, [rsp+0x70]
0000773e7dfd7819  vmovaps xmm8, [rsp+0x80]
0000773e7dfd7822  vmovaps xmm9, [rsp+0x90]
0000773e7dfd782b  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd7834  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd783d  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd7846  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd784f  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd7858  add rsp, 0xF0
0000773e7dfd785f  pop r11
0000773e7dfd7861  pop r10
0000773e7dfd7863  pop r9
0000773e7dfd7865  pop r8
0000773e7dfd7867  pop rsi
0000773e7dfd7868  pop rdi
0000773e7dfd7869  pop rdx
0000773e7dfd786a  pop rcx
0000773e7dfd786b  pop rax
0000773e7dfd786c  add rsp, 0x08
0000773e7dfd7870  jmp 0x0000773E7DFD6728
0000773e7dfd7875  sub rsp, 0x08
0000773e7dfd7879  push rax
0000773e7dfd787a  push rcx
0000773e7dfd787b  push rdx
0000773e7dfd787c  push rdi
0000773e7dfd787d  push rsi
0000773e7dfd787e  push r8
0000773e7dfd7880  push r9
0000773e7dfd7882  push r10
0000773e7dfd7884  push r11
0000773e7dfd7886  sub rsp, 0xF0
0000773e7dfd788d  vmovaps [rsp], xmm0
0000773e7dfd7892  vmovaps [rsp+0x10], xmm1
0000773e7dfd7898  vmovaps [rsp+0x20], xmm2
0000773e7dfd789e  vmovaps [rsp+0x30], xmm3
0000773e7dfd78a4  vmovaps [rsp+0x40], xmm4
0000773e7dfd78aa  vmovaps [rsp+0x50], xmm5
0000773e7dfd78b0  vmovaps [rsp+0x60], xmm6
0000773e7dfd78b6  vmovaps [rsp+0x70], xmm7
0000773e7dfd78bc  vmovaps [rsp+0x80], xmm8
0000773e7dfd78c5  vmovaps [rsp+0x90], xmm10
0000773e7dfd78ce  vmovaps [rsp+0xA0], xmm11
0000773e7dfd78d7  vmovaps [rsp+0xB0], xmm12
0000773e7dfd78e0  vmovaps [rsp+0xC0], xmm13
0000773e7dfd78e9  vmovaps [rsp+0xD0], xmm14
0000773e7dfd78f2  vmovaps [rsp+0xE0], xmm15
0000773e7dfd78fb  sub rsp, 0x40
0000773e7dfd78ff  lea rdi, [rsp]
0000773e7dfd7903  lea rsi, [rsp+0x10]
0000773e7dfd7908  lea rdx, [rsp+0x20]
0000773e7dfd790d  lea rcx, [rsp+0x30]
0000773e7dfd7912  mov r8d, 0x00
0000773e7dfd7918  lea r9, [r15+0x3A8]
0000773e7dfd791f  movaps [rdi], xmm9
0000773e7dfd7923  movaps [rsi], xmm13
0000773e7dfd7927  movaps [rdx], xmm14
0000773e7dfd792b  movaps [rcx], xmm6
0000773e7dfd792e  mov rax, 0x567852F34A50
0000773e7dfd7938  call rax
0000773e7dfd793a  movaps xmm9, [rsp]
0000773e7dfd793f  add rsp, 0x40
0000773e7dfd7943  vmovaps xmm0, [rsp]
0000773e7dfd7948  vmovaps xmm1, [rsp+0x10]
0000773e7dfd794e  vmovaps xmm2, [rsp+0x20]
0000773e7dfd7954  vmovaps xmm3, [rsp+0x30]
0000773e7dfd795a  vmovaps xmm4, [rsp+0x40]
0000773e7dfd7960  vmovaps xmm5, [rsp+0x50]
0000773e7dfd7966  vmovaps xmm6, [rsp+0x60]
0000773e7dfd796c  vmovaps xmm7, [rsp+0x70]
0000773e7dfd7972  vmovaps xmm8, [rsp+0x80]
0000773e7dfd797b  vmovaps xmm10, [rsp+0x90]
0000773e7dfd7984  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd798d  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd7996  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd799f  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd79a8  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd79b1  add rsp, 0xF0
0000773e7dfd79b8  pop r11
0000773e7dfd79ba  pop r10
0000773e7dfd79bc  pop r9
0000773e7dfd79be  pop r8
0000773e7dfd79c0  pop rsi
0000773e7dfd79c1  pop rdi
0000773e7dfd79c2  pop rdx
0000773e7dfd79c3  pop rcx
0000773e7dfd79c4  pop rax
0000773e7dfd79c5  add rsp, 0x08
0000773e7dfd79c9  jmp 0x0000773E7DFD67D2
0000773e7dfd79ce  sub rsp, 0x08
0000773e7dfd79d2  push rax
0000773e7dfd79d3  push rcx
0000773e7dfd79d4  push rdx
0000773e7dfd79d5  push rdi
0000773e7dfd79d6  push rsi
0000773e7dfd79d7  push r8
0000773e7dfd79d9  push r9
0000773e7dfd79db  push r10
0000773e7dfd79dd  push r11
0000773e7dfd79df  sub rsp, 0xF0
0000773e7dfd79e6  vmovaps [rsp], xmm0
0000773e7dfd79eb  vmovaps [rsp+0x10], xmm1
0000773e7dfd79f1  vmovaps [rsp+0x20], xmm2
0000773e7dfd79f7  vmovaps [rsp+0x30], xmm4
0000773e7dfd79fd  vmovaps [rsp+0x40], xmm5
0000773e7dfd7a03  vmovaps [rsp+0x50], xmm6
0000773e7dfd7a09  vmovaps [rsp+0x60], xmm7
0000773e7dfd7a0f  vmovaps [rsp+0x70], xmm8
0000773e7dfd7a15  vmovaps [rsp+0x80], xmm9
0000773e7dfd7a1e  vmovaps [rsp+0x90], xmm10
0000773e7dfd7a27  vmovaps [rsp+0xA0], xmm11
0000773e7dfd7a30  vmovaps [rsp+0xB0], xmm12
0000773e7dfd7a39  vmovaps [rsp+0xC0], xmm13
0000773e7dfd7a42  vmovaps [rsp+0xD0], xmm14
0000773e7dfd7a4b  vmovaps [rsp+0xE0], xmm15
0000773e7dfd7a54  sub rsp, 0x40
0000773e7dfd7a58  lea rdi, [rsp]
0000773e7dfd7a5c  lea rsi, [rsp+0x10]
0000773e7dfd7a61  lea rdx, [rsp+0x20]
0000773e7dfd7a66  lea rcx, [rsp+0x30]
0000773e7dfd7a6b  mov r8d, 0x00
0000773e7dfd7a71  lea r9, [r15+0x3A8]
0000773e7dfd7a78  movaps [rdi], xmm3
0000773e7dfd7a7b  movaps [rsi], xmm13
0000773e7dfd7a7f  movaps [rdx], xmm6
0000773e7dfd7a82  movaps [rcx], xmm14
0000773e7dfd7a86  mov rax, 0x567852F34A50
0000773e7dfd7a90  call rax
0000773e7dfd7a92  movaps xmm3, [rsp]
0000773e7dfd7a96  add rsp, 0x40
0000773e7dfd7a9a  vmovaps xmm0, [rsp]
0000773e7dfd7a9f  vmovaps xmm1, [rsp+0x10]
0000773e7dfd7aa5  vmovaps xmm2, [rsp+0x20]
0000773e7dfd7aab  vmovaps xmm4, [rsp+0x30]
0000773e7dfd7ab1  vmovaps xmm5, [rsp+0x40]
0000773e7dfd7ab7  vmovaps xmm6, [rsp+0x50]
0000773e7dfd7abd  vmovaps xmm7, [rsp+0x60]
0000773e7dfd7ac3  vmovaps xmm8, [rsp+0x70]
0000773e7dfd7ac9  vmovaps xmm9, [rsp+0x80]
0000773e7dfd7ad2  vmovaps xmm10, [rsp+0x90]
0000773e7dfd7adb  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd7ae4  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd7aed  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd7af6  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd7aff  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd7b08  add rsp, 0xF0
0000773e7dfd7b0f  pop r11
0000773e7dfd7b11  pop r10
0000773e7dfd7b13  pop r9
0000773e7dfd7b15  pop r8
0000773e7dfd7b17  pop rsi
0000773e7dfd7b18  pop rdi
0000773e7dfd7b19  pop rdx
0000773e7dfd7b1a  pop rcx
0000773e7dfd7b1b  pop rax
0000773e7dfd7b1c  add rsp, 0x08
0000773e7dfd7b20  jmp 0x0000773E7DFD680F
0000773e7dfd7b25  sub rsp, 0x08
0000773e7dfd7b29  push rax
0000773e7dfd7b2a  push rcx
0000773e7dfd7b2b  push rdx
0000773e7dfd7b2c  push rdi
0000773e7dfd7b2d  push rsi
0000773e7dfd7b2e  push r8
0000773e7dfd7b30  push r9
0000773e7dfd7b32  push r10
0000773e7dfd7b34  push r11
0000773e7dfd7b36  sub rsp, 0xF0
0000773e7dfd7b3d  vmovaps [rsp], xmm0
0000773e7dfd7b42  vmovaps [rsp+0x10], xmm1
0000773e7dfd7b48  vmovaps [rsp+0x20], xmm2
0000773e7dfd7b4e  vmovaps [rsp+0x30], xmm3
0000773e7dfd7b54  vmovaps [rsp+0x40], xmm4
0000773e7dfd7b5a  vmovaps [rsp+0x50], xmm5
0000773e7dfd7b60  vmovaps [rsp+0x60], xmm7
0000773e7dfd7b66  vmovaps [rsp+0x70], xmm8
0000773e7dfd7b6c  vmovaps [rsp+0x80], xmm9
0000773e7dfd7b75  vmovaps [rsp+0x90], xmm10
0000773e7dfd7b7e  vmovaps [rsp+0xA0], xmm11
0000773e7dfd7b87  vmovaps [rsp+0xB0], xmm12
0000773e7dfd7b90  vmovaps [rsp+0xC0], xmm13
0000773e7dfd7b99  vmovaps [rsp+0xD0], xmm14
0000773e7dfd7ba2  vmovaps [rsp+0xE0], xmm15
0000773e7dfd7bab  sub rsp, 0x40
0000773e7dfd7baf  lea rdi, [rsp]
0000773e7dfd7bb3  lea rsi, [rsp+0x10]
0000773e7dfd7bb8  lea rdx, [rsp+0x20]
0000773e7dfd7bbd  lea rcx, [rsp+0x30]
0000773e7dfd7bc2  mov r8d, 0x00
0000773e7dfd7bc8  lea r9, [r15+0x3A8]
0000773e7dfd7bcf  movaps [rdi], xmm6
0000773e7dfd7bd2  movaps [rsi], xmm2
0000773e7dfd7bd5  movaps [rdx], xmm14
0000773e7dfd7bd9  movaps [rcx], xmm1
0000773e7dfd7bdc  mov rax, 0x567852F34A50
0000773e7dfd7be6  call rax
0000773e7dfd7be8  movaps xmm6, [rsp]
0000773e7dfd7bec  add rsp, 0x40
0000773e7dfd7bf0  vmovaps xmm0, [rsp]
0000773e7dfd7bf5  vmovaps xmm1, [rsp+0x10]
0000773e7dfd7bfb  vmovaps xmm2, [rsp+0x20]
0000773e7dfd7c01  vmovaps xmm3, [rsp+0x30]
0000773e7dfd7c07  vmovaps xmm4, [rsp+0x40]
0000773e7dfd7c0d  vmovaps xmm5, [rsp+0x50]
0000773e7dfd7c13  vmovaps xmm7, [rsp+0x60]
0000773e7dfd7c19  vmovaps xmm8, [rsp+0x70]
0000773e7dfd7c1f  vmovaps xmm9, [rsp+0x80]
0000773e7dfd7c28  vmovaps xmm10, [rsp+0x90]
0000773e7dfd7c31  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd7c3a  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd7c43  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd7c4c  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd7c55  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd7c5e  add rsp, 0xF0
0000773e7dfd7c65  pop r11
0000773e7dfd7c67  pop r10
0000773e7dfd7c69  pop r9
0000773e7dfd7c6b  pop r8
0000773e7dfd7c6d  pop rsi
0000773e7dfd7c6e  pop rdi
0000773e7dfd7c6f  pop rdx
0000773e7dfd7c70  pop rcx
0000773e7dfd7c71  pop rax
0000773e7dfd7c72  add rsp, 0x08
0000773e7dfd7c76  jmp 0x0000773E7DFD683C
0000773e7dfd7c7b  sub rsp, 0x08
0000773e7dfd7c7f  push rax
0000773e7dfd7c80  push rcx
0000773e7dfd7c81  push rdx
0000773e7dfd7c82  push rdi
0000773e7dfd7c83  push rsi
0000773e7dfd7c84  push r8
0000773e7dfd7c86  push r9
0000773e7dfd7c88  push r10
0000773e7dfd7c8a  push r11
0000773e7dfd7c8c  sub rsp, 0xF0
0000773e7dfd7c93  vmovaps [rsp], xmm0
0000773e7dfd7c98  vmovaps [rsp+0x10], xmm1
0000773e7dfd7c9e  vmovaps [rsp+0x20], xmm2
0000773e7dfd7ca4  vmovaps [rsp+0x30], xmm3
0000773e7dfd7caa  vmovaps [rsp+0x40], xmm4
0000773e7dfd7cb0  vmovaps [rsp+0x50], xmm5
0000773e7dfd7cb6  vmovaps [rsp+0x60], xmm6
0000773e7dfd7cbc  vmovaps [rsp+0x70], xmm7
0000773e7dfd7cc2  vmovaps [rsp+0x80], xmm8
0000773e7dfd7ccb  vmovaps [rsp+0x90], xmm9
0000773e7dfd7cd4  vmovaps [rsp+0xA0], xmm10
0000773e7dfd7cdd  vmovaps [rsp+0xB0], xmm11
0000773e7dfd7ce6  vmovaps [rsp+0xC0], xmm12
0000773e7dfd7cef  vmovaps [rsp+0xD0], xmm14
0000773e7dfd7cf8  vmovaps [rsp+0xE0], xmm15
0000773e7dfd7d01  sub rsp, 0x40
0000773e7dfd7d05  lea rdi, [rsp]
0000773e7dfd7d09  lea rsi, [rsp+0x10]
0000773e7dfd7d0e  lea rdx, [rsp+0x20]
0000773e7dfd7d13  lea rcx, [rsp+0x30]
0000773e7dfd7d18  mov r8d, 0x00
0000773e7dfd7d1e  lea r9, [r15+0x3A8]
0000773e7dfd7d25  movaps [rdi], xmm13
0000773e7dfd7d29  movaps [rsi], xmm12
0000773e7dfd7d2d  movaps [rdx], xmm14
0000773e7dfd7d31  movaps [rcx], xmm1
0000773e7dfd7d34  mov rax, 0x567852F34A50
0000773e7dfd7d3e  call rax
0000773e7dfd7d40  movaps xmm13, [rsp]
0000773e7dfd7d45  add rsp, 0x40
0000773e7dfd7d49  vmovaps xmm0, [rsp]
0000773e7dfd7d4e  vmovaps xmm1, [rsp+0x10]
0000773e7dfd7d54  vmovaps xmm2, [rsp+0x20]
0000773e7dfd7d5a  vmovaps xmm3, [rsp+0x30]
0000773e7dfd7d60  vmovaps xmm4, [rsp+0x40]
0000773e7dfd7d66  vmovaps xmm5, [rsp+0x50]
0000773e7dfd7d6c  vmovaps xmm6, [rsp+0x60]
0000773e7dfd7d72  vmovaps xmm7, [rsp+0x70]
0000773e7dfd7d78  vmovaps xmm8, [rsp+0x80]
0000773e7dfd7d81  vmovaps xmm9, [rsp+0x90]
0000773e7dfd7d8a  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd7d93  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd7d9c  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd7da5  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd7dae  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd7db7  add rsp, 0xF0
0000773e7dfd7dbe  pop r11
0000773e7dfd7dc0  pop r10
0000773e7dfd7dc2  pop r9
0000773e7dfd7dc4  pop r8
0000773e7dfd7dc6  pop rsi
0000773e7dfd7dc7  pop rdi
0000773e7dfd7dc8  pop rdx
0000773e7dfd7dc9  pop rcx
0000773e7dfd7dca  pop rax
0000773e7dfd7dcb  add rsp, 0x08
0000773e7dfd7dcf  jmp 0x0000773E7DFD686E
0000773e7dfd7dd4  sub rsp, 0x08
0000773e7dfd7dd8  push rax
0000773e7dfd7dd9  push rcx
0000773e7dfd7dda  push rdx
0000773e7dfd7ddb  push rdi
0000773e7dfd7ddc  push rsi
0000773e7dfd7ddd  push r8
0000773e7dfd7ddf  push r9
0000773e7dfd7de1  push r10
0000773e7dfd7de3  push r11
0000773e7dfd7de5  sub rsp, 0xF0
0000773e7dfd7dec  vmovaps [rsp], xmm0
0000773e7dfd7df1  vmovaps [rsp+0x10], xmm1
0000773e7dfd7df7  vmovaps [rsp+0x20], xmm2
0000773e7dfd7dfd  vmovaps [rsp+0x30], xmm3
0000773e7dfd7e03  vmovaps [rsp+0x40], xmm4
0000773e7dfd7e09  vmovaps [rsp+0x50], xmm5
0000773e7dfd7e0f  vmovaps [rsp+0x60], xmm6
0000773e7dfd7e15  vmovaps [rsp+0x70], xmm7
0000773e7dfd7e1b  vmovaps [rsp+0x80], xmm8
0000773e7dfd7e24  vmovaps [rsp+0x90], xmm9
0000773e7dfd7e2d  vmovaps [rsp+0xA0], xmm10
0000773e7dfd7e36  vmovaps [rsp+0xB0], xmm11
0000773e7dfd7e3f  vmovaps [rsp+0xC0], xmm13
0000773e7dfd7e48  vmovaps [rsp+0xD0], xmm14
0000773e7dfd7e51  vmovaps [rsp+0xE0], xmm15
0000773e7dfd7e5a  sub rsp, 0x40
0000773e7dfd7e5e  lea rdi, [rsp]
0000773e7dfd7e62  lea rsi, [rsp+0x10]
0000773e7dfd7e67  lea rdx, [rsp+0x20]
0000773e7dfd7e6c  lea rcx, [rsp+0x30]
0000773e7dfd7e71  mov r8d, 0x00
0000773e7dfd7e77  lea r9, [r15+0x3A8]
0000773e7dfd7e7e  movaps [rdi], xmm12
0000773e7dfd7e82  movaps [rsi], xmm3
0000773e7dfd7e85  movaps [rdx], xmm14
0000773e7dfd7e89  movaps [rcx], xmm5
0000773e7dfd7e8c  mov rax, 0x567852F34A50
0000773e7dfd7e96  call rax
0000773e7dfd7e98  movaps xmm12, [rsp]
0000773e7dfd7e9d  add rsp, 0x40
0000773e7dfd7ea1  vmovaps xmm0, [rsp]
0000773e7dfd7ea6  vmovaps xmm1, [rsp+0x10]
0000773e7dfd7eac  vmovaps xmm2, [rsp+0x20]
0000773e7dfd7eb2  vmovaps xmm3, [rsp+0x30]
0000773e7dfd7eb8  vmovaps xmm4, [rsp+0x40]
0000773e7dfd7ebe  vmovaps xmm5, [rsp+0x50]
0000773e7dfd7ec4  vmovaps xmm6, [rsp+0x60]
0000773e7dfd7eca  vmovaps xmm7, [rsp+0x70]
0000773e7dfd7ed0  vmovaps xmm8, [rsp+0x80]
0000773e7dfd7ed9  vmovaps xmm9, [rsp+0x90]
0000773e7dfd7ee2  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd7eeb  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd7ef4  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd7efd  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd7f06  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd7f0f  add rsp, 0xF0
0000773e7dfd7f16  pop r11
0000773e7dfd7f18  pop r10
0000773e7dfd7f1a  pop r9
0000773e7dfd7f1c  pop r8
0000773e7dfd7f1e  pop rsi
0000773e7dfd7f1f  pop rdi
0000773e7dfd7f20  pop rdx
0000773e7dfd7f21  pop rcx
0000773e7dfd7f22  pop rax
0000773e7dfd7f23  add rsp, 0x08
0000773e7dfd7f27  jmp 0x0000773E7DFD68CB
0000773e7dfd7f2c  sub rsp, 0x08
0000773e7dfd7f30  push rax
0000773e7dfd7f31  push rcx
0000773e7dfd7f32  push rdx
0000773e7dfd7f33  push rdi
0000773e7dfd7f34  push rsi
0000773e7dfd7f35  push r8
0000773e7dfd7f37  push r9
0000773e7dfd7f39  push r10
0000773e7dfd7f3b  push r11
0000773e7dfd7f3d  sub rsp, 0xF0
0000773e7dfd7f44  vmovaps [rsp], xmm0
0000773e7dfd7f49  vmovaps [rsp+0x10], xmm1
0000773e7dfd7f4f  vmovaps [rsp+0x20], xmm2
0000773e7dfd7f55  vmovaps [rsp+0x30], xmm3
0000773e7dfd7f5b  vmovaps [rsp+0x40], xmm4
0000773e7dfd7f61  vmovaps [rsp+0x50], xmm5
0000773e7dfd7f67  vmovaps [rsp+0x60], xmm6
0000773e7dfd7f6d  vmovaps [rsp+0x70], xmm7
0000773e7dfd7f73  vmovaps [rsp+0x80], xmm8
0000773e7dfd7f7c  vmovaps [rsp+0x90], xmm9
0000773e7dfd7f85  vmovaps [rsp+0xA0], xmm11
0000773e7dfd7f8e  vmovaps [rsp+0xB0], xmm12
0000773e7dfd7f97  vmovaps [rsp+0xC0], xmm13
0000773e7dfd7fa0  vmovaps [rsp+0xD0], xmm14
0000773e7dfd7fa9  vmovaps [rsp+0xE0], xmm15
0000773e7dfd7fb2  sub rsp, 0x40
0000773e7dfd7fb6  lea rdi, [rsp]
0000773e7dfd7fba  lea rsi, [rsp+0x10]
0000773e7dfd7fbf  lea rdx, [rsp+0x20]
0000773e7dfd7fc4  lea rcx, [rsp+0x30]
0000773e7dfd7fc9  mov r8d, 0x00
0000773e7dfd7fcf  lea r9, [r15+0x3A8]
0000773e7dfd7fd6  movaps [rdi], xmm10
0000773e7dfd7fda  movaps [rsi], xmm9
0000773e7dfd7fde  movaps [rdx], xmm7
0000773e7dfd7fe1  movaps [rcx], xmm14
0000773e7dfd7fe5  mov rax, 0x567852F34A50
0000773e7dfd7fef  call rax
0000773e7dfd7ff1  movaps xmm10, [rsp]
0000773e7dfd7ff6  add rsp, 0x40
0000773e7dfd7ffa  vmovaps xmm0, [rsp]
0000773e7dfd7fff  vmovaps xmm1, [rsp+0x10]
0000773e7dfd8005  vmovaps xmm2, [rsp+0x20]
0000773e7dfd800b  vmovaps xmm3, [rsp+0x30]
0000773e7dfd8011  vmovaps xmm4, [rsp+0x40]
0000773e7dfd8017  vmovaps xmm5, [rsp+0x50]
0000773e7dfd801d  vmovaps xmm6, [rsp+0x60]
0000773e7dfd8023  vmovaps xmm7, [rsp+0x70]
0000773e7dfd8029  vmovaps xmm8, [rsp+0x80]
0000773e7dfd8032  vmovaps xmm9, [rsp+0x90]
0000773e7dfd803b  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd8044  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd804d  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd8056  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd805f  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd8068  add rsp, 0xF0
0000773e7dfd806f  pop r11
0000773e7dfd8071  pop r10
0000773e7dfd8073  pop r9
0000773e7dfd8075  pop r8
0000773e7dfd8077  pop rsi
0000773e7dfd8078  pop rdi
0000773e7dfd8079  pop rdx
0000773e7dfd807a  pop rcx
0000773e7dfd807b  pop rax
0000773e7dfd807c  add rsp, 0x08
0000773e7dfd8080  jmp 0x0000773E7DFD68F1
0000773e7dfd8085  call 0x0000773E7DEE45A0
0000773e7dfd808a  jmp 0x0000773E7DFD68FE
0000773e7dfd808f  sub rsp, 0x08
0000773e7dfd8093  push rax
0000773e7dfd8094  push rcx
0000773e7dfd8095  push rdx
0000773e7dfd8096  push rdi
0000773e7dfd8097  push rsi
0000773e7dfd8098  push r8
0000773e7dfd809a  push r9
0000773e7dfd809c  push r10
0000773e7dfd809e  push r11
0000773e7dfd80a0  sub rsp, 0xF0
0000773e7dfd80a7  vmovaps [rsp], xmm0
0000773e7dfd80ac  vmovaps [rsp+0x10], xmm1
0000773e7dfd80b2  vmovaps [rsp+0x20], xmm2
0000773e7dfd80b8  vmovaps [rsp+0x30], xmm3
0000773e7dfd80be  vmovaps [rsp+0x40], xmm4
0000773e7dfd80c4  vmovaps [rsp+0x50], xmm6
0000773e7dfd80ca  vmovaps [rsp+0x60], xmm7
0000773e7dfd80d0  vmovaps [rsp+0x70], xmm8
0000773e7dfd80d6  vmovaps [rsp+0x80], xmm9
0000773e7dfd80df  vmovaps [rsp+0x90], xmm10
0000773e7dfd80e8  vmovaps [rsp+0xA0], xmm11
0000773e7dfd80f1  vmovaps [rsp+0xB0], xmm12
0000773e7dfd80fa  vmovaps [rsp+0xC0], xmm13
0000773e7dfd8103  vmovaps [rsp+0xD0], xmm14
0000773e7dfd810c  vmovaps [rsp+0xE0], xmm15
0000773e7dfd8115  sub rsp, 0x40
0000773e7dfd8119  lea rdi, [rsp]
0000773e7dfd811d  lea rsi, [rsp+0x10]
0000773e7dfd8122  lea rdx, [rsp+0x20]
0000773e7dfd8127  lea rcx, [rsp+0x30]
0000773e7dfd812c  mov r8d, 0x00
0000773e7dfd8132  lea r9, [r15+0x3A8]
0000773e7dfd8139  movaps [rdi], xmm5
0000773e7dfd813c  movaps [rsi], xmm6
0000773e7dfd813f  movaps [rdx], xmm7
0000773e7dfd8142  movaps [rcx], xmm9
0000773e7dfd8146  mov rax, 0x567852F34A50
0000773e7dfd8150  call rax
0000773e7dfd8152  movaps xmm5, [rsp]
0000773e7dfd8156  add rsp, 0x40
0000773e7dfd815a  vmovaps xmm0, [rsp]
0000773e7dfd815f  vmovaps xmm1, [rsp+0x10]
0000773e7dfd8165  vmovaps xmm2, [rsp+0x20]
0000773e7dfd816b  vmovaps xmm3, [rsp+0x30]
0000773e7dfd8171  vmovaps xmm4, [rsp+0x40]
0000773e7dfd8177  vmovaps xmm6, [rsp+0x50]
0000773e7dfd817d  vmovaps xmm7, [rsp+0x60]
0000773e7dfd8183  vmovaps xmm8, [rsp+0x70]
0000773e7dfd8189  vmovaps xmm9, [rsp+0x80]
0000773e7dfd8192  vmovaps xmm10, [rsp+0x90]
0000773e7dfd819b  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd81a4  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd81ad  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd81b6  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd81bf  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd81c8  add rsp, 0xF0
0000773e7dfd81cf  pop r11
0000773e7dfd81d1  pop r10
0000773e7dfd81d3  pop r9
0000773e7dfd81d5  pop r8
0000773e7dfd81d7  pop rsi
0000773e7dfd81d8  pop rdi
0000773e7dfd81d9  pop rdx
0000773e7dfd81da  pop rcx
0000773e7dfd81db  pop rax
0000773e7dfd81dc  add rsp, 0x08
0000773e7dfd81e0  jmp 0x0000773E7DFD6930
0000773e7dfd81e5  sub rsp, 0x08
0000773e7dfd81e9  push rax
0000773e7dfd81ea  push rcx
0000773e7dfd81eb  push rdx
0000773e7dfd81ec  push rdi
0000773e7dfd81ed  push rsi
0000773e7dfd81ee  push r8
0000773e7dfd81f0  push r9
0000773e7dfd81f2  push r10
0000773e7dfd81f4  push r11
0000773e7dfd81f6  sub rsp, 0xF0
0000773e7dfd81fd  vmovaps [rsp], xmm0
0000773e7dfd8202  vmovaps [rsp+0x10], xmm1
0000773e7dfd8208  vmovaps [rsp+0x20], xmm2
0000773e7dfd820e  vmovaps [rsp+0x30], xmm3
0000773e7dfd8214  vmovaps [rsp+0x40], xmm4
0000773e7dfd821a  vmovaps [rsp+0x50], xmm5
0000773e7dfd8220  vmovaps [rsp+0x60], xmm6
0000773e7dfd8226  vmovaps [rsp+0x70], xmm8
0000773e7dfd822c  vmovaps [rsp+0x80], xmm9
0000773e7dfd8235  vmovaps [rsp+0x90], xmm10
0000773e7dfd823e  vmovaps [rsp+0xA0], xmm11
0000773e7dfd8247  vmovaps [rsp+0xB0], xmm12
0000773e7dfd8250  vmovaps [rsp+0xC0], xmm13
0000773e7dfd8259  vmovaps [rsp+0xD0], xmm14
0000773e7dfd8262  vmovaps [rsp+0xE0], xmm15
0000773e7dfd826b  sub rsp, 0x40
0000773e7dfd826f  lea rdi, [rsp]
0000773e7dfd8273  lea rsi, [rsp+0x10]
0000773e7dfd8278  lea rdx, [rsp+0x20]
0000773e7dfd827d  lea rcx, [rsp+0x30]
0000773e7dfd8282  mov r8d, 0x00
0000773e7dfd8288  lea r9, [r15+0x3A8]
0000773e7dfd828f  movaps [rdi], xmm7
0000773e7dfd8292  movaps [rsi], xmm13
0000773e7dfd8296  movaps [rdx], xmm1
0000773e7dfd8299  movaps [rcx], xmm9
0000773e7dfd829d  mov rax, 0x567852F34A50
0000773e7dfd82a7  call rax
0000773e7dfd82a9  movaps xmm7, [rsp]
0000773e7dfd82ad  add rsp, 0x40
0000773e7dfd82b1  vmovaps xmm0, [rsp]
0000773e7dfd82b6  vmovaps xmm1, [rsp+0x10]
0000773e7dfd82bc  vmovaps xmm2, [rsp+0x20]
0000773e7dfd82c2  vmovaps xmm3, [rsp+0x30]
0000773e7dfd82c8  vmovaps xmm4, [rsp+0x40]
0000773e7dfd82ce  vmovaps xmm5, [rsp+0x50]
0000773e7dfd82d4  vmovaps xmm6, [rsp+0x60]
0000773e7dfd82da  vmovaps xmm8, [rsp+0x70]
0000773e7dfd82e0  vmovaps xmm9, [rsp+0x80]
0000773e7dfd82e9  vmovaps xmm10, [rsp+0x90]
0000773e7dfd82f2  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd82fb  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd8304  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd830d  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd8316  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd831f  add rsp, 0xF0
0000773e7dfd8326  pop r11
0000773e7dfd8328  pop r10
0000773e7dfd832a  pop r9
0000773e7dfd832c  pop r8
0000773e7dfd832e  pop rsi
0000773e7dfd832f  pop rdi
0000773e7dfd8330  pop rdx
0000773e7dfd8331  pop rcx
0000773e7dfd8332  pop rax
0000773e7dfd8333  add rsp, 0x08
0000773e7dfd8337  jmp 0x0000773E7DFD6955
0000773e7dfd833c  call 0x0000773E7DEE3320
0000773e7dfd8341  jmp 0x0000773E7DFD6978
0000773e7dfd8346  call 0x0000773E7DEDE950
0000773e7dfd834b  jmp 0x0000773E7DFD6982
0000773e7dfd8350  sub rsp, 0x08
0000773e7dfd8354  push rax
0000773e7dfd8355  push rcx
0000773e7dfd8356  push rdx
0000773e7dfd8357  push rdi
0000773e7dfd8358  push rsi
0000773e7dfd8359  push r8
0000773e7dfd835b  push r9
0000773e7dfd835d  push r10
0000773e7dfd835f  push r11
0000773e7dfd8361  sub rsp, 0xF0
0000773e7dfd8368  vmovaps [rsp], xmm0
0000773e7dfd836d  vmovaps [rsp+0x10], xmm1
0000773e7dfd8373  vmovaps [rsp+0x20], xmm3
0000773e7dfd8379  vmovaps [rsp+0x30], xmm4
0000773e7dfd837f  vmovaps [rsp+0x40], xmm5
0000773e7dfd8385  vmovaps [rsp+0x50], xmm6
0000773e7dfd838b  vmovaps [rsp+0x60], xmm7
0000773e7dfd8391  vmovaps [rsp+0x70], xmm8
0000773e7dfd8397  vmovaps [rsp+0x80], xmm9
0000773e7dfd83a0  vmovaps [rsp+0x90], xmm10
0000773e7dfd83a9  vmovaps [rsp+0xA0], xmm11
0000773e7dfd83b2  vmovaps [rsp+0xB0], xmm12
0000773e7dfd83bb  vmovaps [rsp+0xC0], xmm13
0000773e7dfd83c4  vmovaps [rsp+0xD0], xmm14
0000773e7dfd83cd  vmovaps [rsp+0xE0], xmm15
0000773e7dfd83d6  sub rsp, 0x40
0000773e7dfd83da  lea rdi, [rsp]
0000773e7dfd83de  lea rsi, [rsp+0x10]
0000773e7dfd83e3  lea rdx, [rsp+0x20]
0000773e7dfd83e8  lea rcx, [rsp+0x30]
0000773e7dfd83ed  mov r8d, 0x00
0000773e7dfd83f3  lea r9, [r15+0x3A8]
0000773e7dfd83fa  movaps [rdi], xmm2
0000773e7dfd83fd  movaps [rsi], xmm12
0000773e7dfd8401  movaps [rdx], xmm6
0000773e7dfd8404  movaps [rcx], xmm3
0000773e7dfd8407  mov rax, 0x567852F34A50
0000773e7dfd8411  call rax
0000773e7dfd8413  movaps xmm2, [rsp]
0000773e7dfd8417  add rsp, 0x40
0000773e7dfd841b  vmovaps xmm0, [rsp]
0000773e7dfd8420  vmovaps xmm1, [rsp+0x10]
0000773e7dfd8426  vmovaps xmm3, [rsp+0x20]
0000773e7dfd842c  vmovaps xmm4, [rsp+0x30]
0000773e7dfd8432  vmovaps xmm5, [rsp+0x40]
0000773e7dfd8438  vmovaps xmm6, [rsp+0x50]
0000773e7dfd843e  vmovaps xmm7, [rsp+0x60]
0000773e7dfd8444  vmovaps xmm8, [rsp+0x70]
0000773e7dfd844a  vmovaps xmm9, [rsp+0x80]
0000773e7dfd8453  vmovaps xmm10, [rsp+0x90]
0000773e7dfd845c  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd8465  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd846e  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd8477  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd8480  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd8489  add rsp, 0xF0
0000773e7dfd8490  pop r11
0000773e7dfd8492  pop r10
0000773e7dfd8494  pop r9
0000773e7dfd8496  pop r8
0000773e7dfd8498  pop rsi
0000773e7dfd8499  pop rdi
0000773e7dfd849a  pop rdx
0000773e7dfd849b  pop rcx
0000773e7dfd849c  pop rax
0000773e7dfd849d  add rsp, 0x08
0000773e7dfd84a1  jmp 0x0000773E7DFD69C8
0000773e7dfd84a6  sub rsp, 0x08
0000773e7dfd84aa  push rax
0000773e7dfd84ab  push rcx
0000773e7dfd84ac  push rdx
0000773e7dfd84ad  push rdi
0000773e7dfd84ae  push rsi
0000773e7dfd84af  push r8
0000773e7dfd84b1  push r9
0000773e7dfd84b3  push r10
0000773e7dfd84b5  push r11
0000773e7dfd84b7  sub rsp, 0xF0
0000773e7dfd84be  vmovaps [rsp], xmm0
0000773e7dfd84c3  vmovaps [rsp+0x10], xmm1
0000773e7dfd84c9  vmovaps [rsp+0x20], xmm2
0000773e7dfd84cf  vmovaps [rsp+0x30], xmm3
0000773e7dfd84d5  vmovaps [rsp+0x40], xmm4
0000773e7dfd84db  vmovaps [rsp+0x50], xmm5
0000773e7dfd84e1  vmovaps [rsp+0x60], xmm7
0000773e7dfd84e7  vmovaps [rsp+0x70], xmm8
0000773e7dfd84ed  vmovaps [rsp+0x80], xmm9
0000773e7dfd84f6  vmovaps [rsp+0x90], xmm10
0000773e7dfd84ff  vmovaps [rsp+0xA0], xmm11
0000773e7dfd8508  vmovaps [rsp+0xB0], xmm12
0000773e7dfd8511  vmovaps [rsp+0xC0], xmm13
0000773e7dfd851a  vmovaps [rsp+0xD0], xmm14
0000773e7dfd8523  vmovaps [rsp+0xE0], xmm15
0000773e7dfd852c  sub rsp, 0x40
0000773e7dfd8530  lea rdi, [rsp]
0000773e7dfd8534  lea rsi, [rsp+0x10]
0000773e7dfd8539  lea rdx, [rsp+0x20]
0000773e7dfd853e  lea rcx, [rsp+0x30]
0000773e7dfd8543  mov r8d, 0x00
0000773e7dfd8549  lea r9, [r15+0x3A8]
0000773e7dfd8550  movaps [rdi], xmm6
0000773e7dfd8553  movaps [rsi], xmm10
0000773e7dfd8557  movaps [rdx], xmm12
0000773e7dfd855b  movaps [rcx], xmm1
0000773e7dfd855e  mov rax, 0x567852F34A50
0000773e7dfd8568  call rax
0000773e7dfd856a  movaps xmm6, [rsp]
0000773e7dfd856e  add rsp, 0x40
0000773e7dfd8572  vmovaps xmm0, [rsp]
0000773e7dfd8577  vmovaps xmm1, [rsp+0x10]
0000773e7dfd857d  vmovaps xmm2, [rsp+0x20]
0000773e7dfd8583  vmovaps xmm3, [rsp+0x30]
0000773e7dfd8589  vmovaps xmm4, [rsp+0x40]
0000773e7dfd858f  vmovaps xmm5, [rsp+0x50]
0000773e7dfd8595  vmovaps xmm7, [rsp+0x60]
0000773e7dfd859b  vmovaps xmm8, [rsp+0x70]
0000773e7dfd85a1  vmovaps xmm9, [rsp+0x80]
0000773e7dfd85aa  vmovaps xmm10, [rsp+0x90]
0000773e7dfd85b3  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd85bc  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd85c5  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd85ce  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd85d7  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd85e0  add rsp, 0xF0
0000773e7dfd85e7  pop r11
0000773e7dfd85e9  pop r10
0000773e7dfd85eb  pop r9
0000773e7dfd85ed  pop r8
0000773e7dfd85ef  pop rsi
0000773e7dfd85f0  pop rdi
0000773e7dfd85f1  pop rdx
0000773e7dfd85f2  pop rcx
0000773e7dfd85f3  pop rax
0000773e7dfd85f4  add rsp, 0x08
0000773e7dfd85f8  jmp 0x0000773E7DFD69F6
0000773e7dfd85fd  sub rsp, 0x08
0000773e7dfd8601  push rax
0000773e7dfd8602  push rcx
0000773e7dfd8603  push rdx
0000773e7dfd8604  push rdi
0000773e7dfd8605  push rsi
0000773e7dfd8606  push r8
0000773e7dfd8608  push r9
0000773e7dfd860a  push r10
0000773e7dfd860c  push r11
0000773e7dfd860e  sub rsp, 0xF0
0000773e7dfd8615  vmovaps [rsp], xmm0
0000773e7dfd861a  vmovaps [rsp+0x10], xmm1
0000773e7dfd8620  vmovaps [rsp+0x20], xmm2
0000773e7dfd8626  vmovaps [rsp+0x30], xmm3
0000773e7dfd862c  vmovaps [rsp+0x40], xmm4
0000773e7dfd8632  vmovaps [rsp+0x50], xmm5
0000773e7dfd8638  vmovaps [rsp+0x60], xmm6
0000773e7dfd863e  vmovaps [rsp+0x70], xmm7
0000773e7dfd8644  vmovaps [rsp+0x80], xmm8
0000773e7dfd864d  vmovaps [rsp+0x90], xmm9
0000773e7dfd8656  vmovaps [rsp+0xA0], xmm11
0000773e7dfd865f  vmovaps [rsp+0xB0], xmm12
0000773e7dfd8668  vmovaps [rsp+0xC0], xmm13
0000773e7dfd8671  vmovaps [rsp+0xD0], xmm14
0000773e7dfd867a  vmovaps [rsp+0xE0], xmm15
0000773e7dfd8683  sub rsp, 0x40
0000773e7dfd8687  lea rdi, [rsp]
0000773e7dfd868b  lea rsi, [rsp+0x10]
0000773e7dfd8690  lea rdx, [rsp+0x20]
0000773e7dfd8695  lea rcx, [rsp+0x30]
0000773e7dfd869a  mov r8d, 0x00
0000773e7dfd86a0  lea r9, [r15+0x3A8]
0000773e7dfd86a7  movaps [rdi], xmm10
0000773e7dfd86ab  movaps [rsi], xmm5
0000773e7dfd86ae  movaps [rdx], xmm12
0000773e7dfd86b2  movaps [rcx], xmm1
0000773e7dfd86b5  mov rax, 0x567852F34A50
0000773e7dfd86bf  call rax
0000773e7dfd86c1  movaps xmm10, [rsp]
0000773e7dfd86c6  add rsp, 0x40
0000773e7dfd86ca  vmovaps xmm0, [rsp]
0000773e7dfd86cf  vmovaps xmm1, [rsp+0x10]
0000773e7dfd86d5  vmovaps xmm2, [rsp+0x20]
0000773e7dfd86db  vmovaps xmm3, [rsp+0x30]
0000773e7dfd86e1  vmovaps xmm4, [rsp+0x40]
0000773e7dfd86e7  vmovaps xmm5, [rsp+0x50]
0000773e7dfd86ed  vmovaps xmm6, [rsp+0x60]
0000773e7dfd86f3  vmovaps xmm7, [rsp+0x70]
0000773e7dfd86f9  vmovaps xmm8, [rsp+0x80]
0000773e7dfd8702  vmovaps xmm9, [rsp+0x90]
0000773e7dfd870b  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd8714  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd871d  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd8726  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd872f  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd8738  add rsp, 0xF0
0000773e7dfd873f  pop r11
0000773e7dfd8741  pop r10
0000773e7dfd8743  pop r9
0000773e7dfd8745  pop r8
0000773e7dfd8747  pop rsi
0000773e7dfd8748  pop rdi
0000773e7dfd8749  pop rdx
0000773e7dfd874a  pop rcx
0000773e7dfd874b  pop rax
0000773e7dfd874c  add rsp, 0x08
0000773e7dfd8750  jmp 0x0000773E7DFD6A25
0000773e7dfd8755  sub rsp, 0x08
0000773e7dfd8759  push rax
0000773e7dfd875a  push rcx
0000773e7dfd875b  push rdx
0000773e7dfd875c  push rdi
0000773e7dfd875d  push rsi
0000773e7dfd875e  push r8
0000773e7dfd8760  push r9
0000773e7dfd8762  push r10
0000773e7dfd8764  push r11
0000773e7dfd8766  sub rsp, 0xF0
0000773e7dfd876d  vmovaps [rsp], xmm0
0000773e7dfd8772  vmovaps [rsp+0x10], xmm1
0000773e7dfd8778  vmovaps [rsp+0x20], xmm2
0000773e7dfd877e  vmovaps [rsp+0x30], xmm3
0000773e7dfd8784  vmovaps [rsp+0x40], xmm4
0000773e7dfd878a  vmovaps [rsp+0x50], xmm5
0000773e7dfd8790  vmovaps [rsp+0x60], xmm6
0000773e7dfd8796  vmovaps [rsp+0x70], xmm7
0000773e7dfd879c  vmovaps [rsp+0x80], xmm8
0000773e7dfd87a5  vmovaps [rsp+0x90], xmm9
0000773e7dfd87ae  vmovaps [rsp+0xA0], xmm10
0000773e7dfd87b7  vmovaps [rsp+0xB0], xmm11
0000773e7dfd87c0  vmovaps [rsp+0xC0], xmm13
0000773e7dfd87c9  vmovaps [rsp+0xD0], xmm14
0000773e7dfd87d2  vmovaps [rsp+0xE0], xmm15
0000773e7dfd87db  sub rsp, 0x40
0000773e7dfd87df  lea rdi, [rsp]
0000773e7dfd87e3  lea rsi, [rsp+0x10]
0000773e7dfd87e8  lea rdx, [rsp+0x20]
0000773e7dfd87ed  lea rcx, [rsp+0x30]
0000773e7dfd87f2  mov r8d, 0x00
0000773e7dfd87f8  lea r9, [r15+0x3A8]
0000773e7dfd87ff  movaps [rdi], xmm12
0000773e7dfd8803  movaps [rsi], xmm7
0000773e7dfd8806  movaps [rdx], xmm15
0000773e7dfd880a  movaps [rcx], xmm1
0000773e7dfd880d  mov rax, 0x567852F34A50
0000773e7dfd8817  call rax
0000773e7dfd8819  movaps xmm12, [rsp]
0000773e7dfd881e  add rsp, 0x40
0000773e7dfd8822  vmovaps xmm0, [rsp]
0000773e7dfd8827  vmovaps xmm1, [rsp+0x10]
0000773e7dfd882d  vmovaps xmm2, [rsp+0x20]
0000773e7dfd8833  vmovaps xmm3, [rsp+0x30]
0000773e7dfd8839  vmovaps xmm4, [rsp+0x40]
0000773e7dfd883f  vmovaps xmm5, [rsp+0x50]
0000773e7dfd8845  vmovaps xmm6, [rsp+0x60]
0000773e7dfd884b  vmovaps xmm7, [rsp+0x70]
0000773e7dfd8851  vmovaps xmm8, [rsp+0x80]
0000773e7dfd885a  vmovaps xmm9, [rsp+0x90]
0000773e7dfd8863  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd886c  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd8875  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd887e  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd8887  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd8890  add rsp, 0xF0
0000773e7dfd8897  pop r11
0000773e7dfd8899  pop r10
0000773e7dfd889b  pop r9
0000773e7dfd889d  pop r8
0000773e7dfd889f  pop rsi
0000773e7dfd88a0  pop rdi
0000773e7dfd88a1  pop rdx
0000773e7dfd88a2  pop rcx
0000773e7dfd88a3  pop rax
0000773e7dfd88a4  add rsp, 0x08
0000773e7dfd88a8  jmp 0x0000773E7DFD6A4E
0000773e7dfd88ad  call 0x0000773E7DED64F0
0000773e7dfd88b2  jmp 0x0000773E7DFD6A58
0000773e7dfd88b7  call 0x0000773E7DEE5820
0000773e7dfd88bc  jmp 0x0000773E7DFD6A62
0000773e7dfd88c1  sub rsp, 0x08
0000773e7dfd88c5  push rax
0000773e7dfd88c6  push rcx
0000773e7dfd88c7  push rdx
0000773e7dfd88c8  push rdi
0000773e7dfd88c9  push rsi
0000773e7dfd88ca  push r8
0000773e7dfd88cc  push r9
0000773e7dfd88ce  push r10
0000773e7dfd88d0  push r11
0000773e7dfd88d2  sub rsp, 0xF0
0000773e7dfd88d9  vmovaps [rsp], xmm0
0000773e7dfd88de  vmovaps [rsp+0x10], xmm1
0000773e7dfd88e4  vmovaps [rsp+0x20], xmm2
0000773e7dfd88ea  vmovaps [rsp+0x30], xmm3
0000773e7dfd88f0  vmovaps [rsp+0x40], xmm4
0000773e7dfd88f6  vmovaps [rsp+0x50], xmm5
0000773e7dfd88fc  vmovaps [rsp+0x60], xmm6
0000773e7dfd8902  vmovaps [rsp+0x70], xmm8
0000773e7dfd8908  vmovaps [rsp+0x80], xmm9
0000773e7dfd8911  vmovaps [rsp+0x90], xmm10
0000773e7dfd891a  vmovaps [rsp+0xA0], xmm11
0000773e7dfd8923  vmovaps [rsp+0xB0], xmm12
0000773e7dfd892c  vmovaps [rsp+0xC0], xmm13
0000773e7dfd8935  vmovaps [rsp+0xD0], xmm14
0000773e7dfd893e  vmovaps [rsp+0xE0], xmm15
0000773e7dfd8947  sub rsp, 0x40
0000773e7dfd894b  lea rdi, [rsp]
0000773e7dfd894f  lea rsi, [rsp+0x10]
0000773e7dfd8954  lea rdx, [rsp+0x20]
0000773e7dfd8959  lea rcx, [rsp+0x30]
0000773e7dfd895e  mov r8d, 0x00
0000773e7dfd8964  lea r9, [r15+0x3A8]
0000773e7dfd896b  movaps [rdi], xmm7
0000773e7dfd896e  movaps [rsi], xmm2
0000773e7dfd8971  movaps [rdx], xmm9
0000773e7dfd8975  movaps [rcx], xmm11
0000773e7dfd8979  mov rax, 0x567852F34A50
0000773e7dfd8983  call rax
0000773e7dfd8985  movaps xmm7, [rsp]
0000773e7dfd8989  add rsp, 0x40
0000773e7dfd898d  vmovaps xmm0, [rsp]
0000773e7dfd8992  vmovaps xmm1, [rsp+0x10]
0000773e7dfd8998  vmovaps xmm2, [rsp+0x20]
0000773e7dfd899e  vmovaps xmm3, [rsp+0x30]
0000773e7dfd89a4  vmovaps xmm4, [rsp+0x40]
0000773e7dfd89aa  vmovaps xmm5, [rsp+0x50]
0000773e7dfd89b0  vmovaps xmm6, [rsp+0x60]
0000773e7dfd89b6  vmovaps xmm8, [rsp+0x70]
0000773e7dfd89bc  vmovaps xmm9, [rsp+0x80]
0000773e7dfd89c5  vmovaps xmm10, [rsp+0x90]
0000773e7dfd89ce  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd89d7  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd89e0  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd89e9  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd89f2  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd89fb  add rsp, 0xF0
0000773e7dfd8a02  pop r11
0000773e7dfd8a04  pop r10
0000773e7dfd8a06  pop r9
0000773e7dfd8a08  pop r8
0000773e7dfd8a0a  pop rsi
0000773e7dfd8a0b  pop rdi
0000773e7dfd8a0c  pop rdx
0000773e7dfd8a0d  pop rcx
0000773e7dfd8a0e  pop rax
0000773e7dfd8a0f  add rsp, 0x08
0000773e7dfd8a13  jmp 0x0000773E7DFD6A96
0000773e7dfd8a18  sub rsp, 0x08
0000773e7dfd8a1c  push rax
0000773e7dfd8a1d  push rcx
0000773e7dfd8a1e  push rdx
0000773e7dfd8a1f  push rdi
0000773e7dfd8a20  push rsi
0000773e7dfd8a21  push r8
0000773e7dfd8a23  push r9
0000773e7dfd8a25  push r10
0000773e7dfd8a27  push r11
0000773e7dfd8a29  sub rsp, 0xF0
0000773e7dfd8a30  vmovaps [rsp], xmm0
0000773e7dfd8a35  vmovaps [rsp+0x10], xmm1
0000773e7dfd8a3b  vmovaps [rsp+0x20], xmm2
0000773e7dfd8a41  vmovaps [rsp+0x30], xmm3
0000773e7dfd8a47  vmovaps [rsp+0x40], xmm4
0000773e7dfd8a4d  vmovaps [rsp+0x50], xmm5
0000773e7dfd8a53  vmovaps [rsp+0x60], xmm6
0000773e7dfd8a59  vmovaps [rsp+0x70], xmm7
0000773e7dfd8a5f  vmovaps [rsp+0x80], xmm8
0000773e7dfd8a68  vmovaps [rsp+0x90], xmm10
0000773e7dfd8a71  vmovaps [rsp+0xA0], xmm11
0000773e7dfd8a7a  vmovaps [rsp+0xB0], xmm12
0000773e7dfd8a83  vmovaps [rsp+0xC0], xmm13
0000773e7dfd8a8c  vmovaps [rsp+0xD0], xmm14
0000773e7dfd8a95  vmovaps [rsp+0xE0], xmm15
0000773e7dfd8a9e  sub rsp, 0x40
0000773e7dfd8aa2  lea rdi, [rsp]
0000773e7dfd8aa6  lea rsi, [rsp+0x10]
0000773e7dfd8aab  lea rdx, [rsp+0x20]
0000773e7dfd8ab0  lea rcx, [rsp+0x30]
0000773e7dfd8ab5  mov r8d, 0x00
0000773e7dfd8abb  lea r9, [r15+0x3A8]
0000773e7dfd8ac2  movaps [rdi], xmm9
0000773e7dfd8ac6  movaps [rsi], xmm6
0000773e7dfd8ac9  movaps [rdx], xmm1
0000773e7dfd8acc  movaps [rcx], xmm11
0000773e7dfd8ad0  mov rax, 0x567852F34A50
0000773e7dfd8ada  call rax
0000773e7dfd8adc  movaps xmm9, [rsp]
0000773e7dfd8ae1  add rsp, 0x40
0000773e7dfd8ae5  vmovaps xmm0, [rsp]
0000773e7dfd8aea  vmovaps xmm1, [rsp+0x10]
0000773e7dfd8af0  vmovaps xmm2, [rsp+0x20]
0000773e7dfd8af6  vmovaps xmm3, [rsp+0x30]
0000773e7dfd8afc  vmovaps xmm4, [rsp+0x40]
0000773e7dfd8b02  vmovaps xmm5, [rsp+0x50]
0000773e7dfd8b08  vmovaps xmm6, [rsp+0x60]
0000773e7dfd8b0e  vmovaps xmm7, [rsp+0x70]
0000773e7dfd8b14  vmovaps xmm8, [rsp+0x80]
0000773e7dfd8b1d  vmovaps xmm10, [rsp+0x90]
0000773e7dfd8b26  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd8b2f  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd8b38  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd8b41  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd8b4a  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd8b53  add rsp, 0xF0
0000773e7dfd8b5a  pop r11
0000773e7dfd8b5c  pop r10
0000773e7dfd8b5e  pop r9
0000773e7dfd8b60  pop r8
0000773e7dfd8b62  pop rsi
0000773e7dfd8b63  pop rdi
0000773e7dfd8b64  pop rdx
0000773e7dfd8b65  pop rcx
0000773e7dfd8b66  pop rax
0000773e7dfd8b67  add rsp, 0x08
0000773e7dfd8b6b  jmp 0x0000773E7DFD6ABC
0000773e7dfd8b70  sub rsp, 0x08
0000773e7dfd8b74  push rax
0000773e7dfd8b75  push rcx
0000773e7dfd8b76  push rdx
0000773e7dfd8b77  push rdi
0000773e7dfd8b78  push rsi
0000773e7dfd8b79  push r8
0000773e7dfd8b7b  push r9
0000773e7dfd8b7d  push r10
0000773e7dfd8b7f  push r11
0000773e7dfd8b81  sub rsp, 0xF0
0000773e7dfd8b88  vmovaps [rsp], xmm0
0000773e7dfd8b8d  vmovaps [rsp+0x10], xmm1
0000773e7dfd8b93  vmovaps [rsp+0x20], xmm2
0000773e7dfd8b99  vmovaps [rsp+0x30], xmm3
0000773e7dfd8b9f  vmovaps [rsp+0x40], xmm4
0000773e7dfd8ba5  vmovaps [rsp+0x50], xmm5
0000773e7dfd8bab  vmovaps [rsp+0x60], xmm6
0000773e7dfd8bb1  vmovaps [rsp+0x70], xmm7
0000773e7dfd8bb7  vmovaps [rsp+0x80], xmm8
0000773e7dfd8bc0  vmovaps [rsp+0x90], xmm9
0000773e7dfd8bc9  vmovaps [rsp+0xA0], xmm10
0000773e7dfd8bd2  vmovaps [rsp+0xB0], xmm12
0000773e7dfd8bdb  vmovaps [rsp+0xC0], xmm13
0000773e7dfd8be4  vmovaps [rsp+0xD0], xmm14
0000773e7dfd8bed  vmovaps [rsp+0xE0], xmm15
0000773e7dfd8bf6  sub rsp, 0x40
0000773e7dfd8bfa  lea rdi, [rsp]
0000773e7dfd8bfe  lea rsi, [rsp+0x10]
0000773e7dfd8c03  lea rdx, [rsp+0x20]
0000773e7dfd8c08  lea rcx, [rsp+0x30]
0000773e7dfd8c0d  mov r8d, 0x00
0000773e7dfd8c13  lea r9, [r15+0x3A8]
0000773e7dfd8c1a  movaps [rdi], xmm11
0000773e7dfd8c1e  movaps [rsi], xmm10
0000773e7dfd8c22  movaps [rdx], xmm8
0000773e7dfd8c26  movaps [rcx], xmm1
0000773e7dfd8c29  mov rax, 0x567852F34A50
0000773e7dfd8c33  call rax
0000773e7dfd8c35  movaps xmm11, [rsp]
0000773e7dfd8c3a  add rsp, 0x40
0000773e7dfd8c3e  vmovaps xmm0, [rsp]
0000773e7dfd8c43  vmovaps xmm1, [rsp+0x10]
0000773e7dfd8c49  vmovaps xmm2, [rsp+0x20]
0000773e7dfd8c4f  vmovaps xmm3, [rsp+0x30]
0000773e7dfd8c55  vmovaps xmm4, [rsp+0x40]
0000773e7dfd8c5b  vmovaps xmm5, [rsp+0x50]
0000773e7dfd8c61  vmovaps xmm6, [rsp+0x60]
0000773e7dfd8c67  vmovaps xmm7, [rsp+0x70]
0000773e7dfd8c6d  vmovaps xmm8, [rsp+0x80]
0000773e7dfd8c76  vmovaps xmm9, [rsp+0x90]
0000773e7dfd8c7f  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd8c88  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd8c91  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd8c9a  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd8ca3  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd8cac  add rsp, 0xF0
0000773e7dfd8cb3  pop r11
0000773e7dfd8cb5  pop r10
0000773e7dfd8cb7  pop r9
0000773e7dfd8cb9  pop r8
0000773e7dfd8cbb  pop rsi
0000773e7dfd8cbc  pop rdi
0000773e7dfd8cbd  pop rdx
0000773e7dfd8cbe  pop rcx
0000773e7dfd8cbf  pop rax
0000773e7dfd8cc0  add rsp, 0x08
0000773e7dfd8cc4  jmp 0x0000773E7DFD6AE2
0000773e7dfd8cc9  sub rsp, 0x08
0000773e7dfd8ccd  push rax
0000773e7dfd8cce  push rcx
0000773e7dfd8ccf  push rdx
0000773e7dfd8cd0  push rdi
0000773e7dfd8cd1  push rsi
0000773e7dfd8cd2  push r8
0000773e7dfd8cd4  push r9
0000773e7dfd8cd6  push r10
0000773e7dfd8cd8  push r11
0000773e7dfd8cda  sub rsp, 0xF0
0000773e7dfd8ce1  vmovaps [rsp], xmm0
0000773e7dfd8ce6  vmovaps [rsp+0x10], xmm1
0000773e7dfd8cec  vmovaps [rsp+0x20], xmm2
0000773e7dfd8cf2  vmovaps [rsp+0x30], xmm3
0000773e7dfd8cf8  vmovaps [rsp+0x40], xmm4
0000773e7dfd8cfe  vmovaps [rsp+0x50], xmm5
0000773e7dfd8d04  vmovaps [rsp+0x60], xmm6
0000773e7dfd8d0a  vmovaps [rsp+0x70], xmm7
0000773e7dfd8d10  vmovaps [rsp+0x80], xmm8
0000773e7dfd8d19  vmovaps [rsp+0x90], xmm9
0000773e7dfd8d22  vmovaps [rsp+0xA0], xmm11
0000773e7dfd8d2b  vmovaps [rsp+0xB0], xmm12
0000773e7dfd8d34  vmovaps [rsp+0xC0], xmm13
0000773e7dfd8d3d  vmovaps [rsp+0xD0], xmm14
0000773e7dfd8d46  vmovaps [rsp+0xE0], xmm15
0000773e7dfd8d4f  sub rsp, 0x40
0000773e7dfd8d53  lea rdi, [rsp]
0000773e7dfd8d57  lea rsi, [rsp+0x10]
0000773e7dfd8d5c  lea rdx, [rsp+0x20]
0000773e7dfd8d61  lea rcx, [rsp+0x30]
0000773e7dfd8d66  mov r8d, 0x00
0000773e7dfd8d6c  lea r9, [r15+0x3A8]
0000773e7dfd8d73  movaps [rdi], xmm10
0000773e7dfd8d77  movaps [rsi], xmm12
0000773e7dfd8d7b  movaps [rdx], xmm13
0000773e7dfd8d7f  movaps [rcx], xmm1
0000773e7dfd8d82  mov rax, 0x567852F34A50
0000773e7dfd8d8c  call rax
0000773e7dfd8d8e  movaps xmm10, [rsp]
0000773e7dfd8d93  add rsp, 0x40
0000773e7dfd8d97  vmovaps xmm0, [rsp]
0000773e7dfd8d9c  vmovaps xmm1, [rsp+0x10]
0000773e7dfd8da2  vmovaps xmm2, [rsp+0x20]
0000773e7dfd8da8  vmovaps xmm3, [rsp+0x30]
0000773e7dfd8dae  vmovaps xmm4, [rsp+0x40]
0000773e7dfd8db4  vmovaps xmm5, [rsp+0x50]
0000773e7dfd8dba  vmovaps xmm6, [rsp+0x60]
0000773e7dfd8dc0  vmovaps xmm7, [rsp+0x70]
0000773e7dfd8dc6  vmovaps xmm8, [rsp+0x80]
0000773e7dfd8dcf  vmovaps xmm9, [rsp+0x90]
0000773e7dfd8dd8  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd8de1  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd8dea  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd8df3  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd8dfc  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd8e05  add rsp, 0xF0
0000773e7dfd8e0c  pop r11
0000773e7dfd8e0e  pop r10
0000773e7dfd8e10  pop r9
0000773e7dfd8e12  pop r8
0000773e7dfd8e14  pop rsi
0000773e7dfd8e15  pop rdi
0000773e7dfd8e16  pop rdx
0000773e7dfd8e17  pop rcx
0000773e7dfd8e18  pop rax
0000773e7dfd8e19  add rsp, 0x08
0000773e7dfd8e1d  jmp 0x0000773E7DFD6B08
0000773e7dfd8e22  call 0x0000773E7DED64F0
0000773e7dfd8e27  jmp 0x0000773E7DFD6B12
0000773e7dfd8e2c  call 0x0000773E7DEE3320
0000773e7dfd8e31  jmp 0x0000773E7DFD6B1C
0000773e7dfd8e36  sub rsp, 0x08
0000773e7dfd8e3a  push rax
0000773e7dfd8e3b  push rcx
0000773e7dfd8e3c  push rdx
0000773e7dfd8e3d  push rdi
0000773e7dfd8e3e  push rsi
0000773e7dfd8e3f  push r8
0000773e7dfd8e41  push r9
0000773e7dfd8e43  push r10
0000773e7dfd8e45  push r11
0000773e7dfd8e47  sub rsp, 0xF0
0000773e7dfd8e4e  vmovaps [rsp], xmm0
0000773e7dfd8e53  vmovaps [rsp+0x10], xmm1
0000773e7dfd8e59  vmovaps [rsp+0x20], xmm2
0000773e7dfd8e5f  vmovaps [rsp+0x30], xmm3
0000773e7dfd8e65  vmovaps [rsp+0x40], xmm4
0000773e7dfd8e6b  vmovaps [rsp+0x50], xmm5
0000773e7dfd8e71  vmovaps [rsp+0x60], xmm6
0000773e7dfd8e77  vmovaps [rsp+0x70], xmm7
0000773e7dfd8e7d  vmovaps [rsp+0x80], xmm9
0000773e7dfd8e86  vmovaps [rsp+0x90], xmm10
0000773e7dfd8e8f  vmovaps [rsp+0xA0], xmm11
0000773e7dfd8e98  vmovaps [rsp+0xB0], xmm12
0000773e7dfd8ea1  vmovaps [rsp+0xC0], xmm13
0000773e7dfd8eaa  vmovaps [rsp+0xD0], xmm14
0000773e7dfd8eb3  vmovaps [rsp+0xE0], xmm15
0000773e7dfd8ebc  sub rsp, 0x40
0000773e7dfd8ec0  lea rdi, [rsp]
0000773e7dfd8ec4  lea rsi, [rsp+0x10]
0000773e7dfd8ec9  lea rdx, [rsp+0x20]
0000773e7dfd8ece  lea rcx, [rsp+0x30]
0000773e7dfd8ed3  mov r8d, 0x00
0000773e7dfd8ed9  lea r9, [r15+0x3A8]
0000773e7dfd8ee0  movaps [rdi], xmm8
0000773e7dfd8ee4  movaps [rsi], xmm7
0000773e7dfd8ee7  movaps [rdx], xmm4
0000773e7dfd8eea  movaps [rcx], xmm12
0000773e7dfd8eee  mov rax, 0x567852F34A50
0000773e7dfd8ef8  call rax
0000773e7dfd8efa  movaps xmm8, [rsp]
0000773e7dfd8eff  add rsp, 0x40
0000773e7dfd8f03  vmovaps xmm0, [rsp]
0000773e7dfd8f08  vmovaps xmm1, [rsp+0x10]
0000773e7dfd8f0e  vmovaps xmm2, [rsp+0x20]
0000773e7dfd8f14  vmovaps xmm3, [rsp+0x30]
0000773e7dfd8f1a  vmovaps xmm4, [rsp+0x40]
0000773e7dfd8f20  vmovaps xmm5, [rsp+0x50]
0000773e7dfd8f26  vmovaps xmm6, [rsp+0x60]
0000773e7dfd8f2c  vmovaps xmm7, [rsp+0x70]
0000773e7dfd8f32  vmovaps xmm9, [rsp+0x80]
0000773e7dfd8f3b  vmovaps xmm10, [rsp+0x90]
0000773e7dfd8f44  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd8f4d  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd8f56  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd8f5f  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd8f68  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd8f71  add rsp, 0xF0
0000773e7dfd8f78  pop r11
0000773e7dfd8f7a  pop r10
0000773e7dfd8f7c  pop r9
0000773e7dfd8f7e  pop r8
0000773e7dfd8f80  pop rsi
0000773e7dfd8f81  pop rdi
0000773e7dfd8f82  pop rdx
0000773e7dfd8f83  pop rcx
0000773e7dfd8f84  pop rax
0000773e7dfd8f85  add rsp, 0x08
0000773e7dfd8f89  jmp 0x0000773E7DFD6B45
0000773e7dfd8f8e  sub rsp, 0x08
0000773e7dfd8f92  push rax
0000773e7dfd8f93  push rcx
0000773e7dfd8f94  push rdx
0000773e7dfd8f95  push rdi
0000773e7dfd8f96  push rsi
0000773e7dfd8f97  push r8
0000773e7dfd8f99  push r9
0000773e7dfd8f9b  push r10
0000773e7dfd8f9d  push r11
0000773e7dfd8f9f  sub rsp, 0xF0
0000773e7dfd8fa6  vmovaps [rsp], xmm0
0000773e7dfd8fab  vmovaps [rsp+0x10], xmm1
0000773e7dfd8fb1  vmovaps [rsp+0x20], xmm2
0000773e7dfd8fb7  vmovaps [rsp+0x30], xmm3
0000773e7dfd8fbd  vmovaps [rsp+0x40], xmm4
0000773e7dfd8fc3  vmovaps [rsp+0x50], xmm5
0000773e7dfd8fc9  vmovaps [rsp+0x60], xmm6
0000773e7dfd8fcf  vmovaps [rsp+0x70], xmm8
0000773e7dfd8fd5  vmovaps [rsp+0x80], xmm9
0000773e7dfd8fde  vmovaps [rsp+0x90], xmm10
0000773e7dfd8fe7  vmovaps [rsp+0xA0], xmm11
0000773e7dfd8ff0  vmovaps [rsp+0xB0], xmm12
0000773e7dfd8ff9  vmovaps [rsp+0xC0], xmm13
0000773e7dfd9002  vmovaps [rsp+0xD0], xmm14
0000773e7dfd900b  vmovaps [rsp+0xE0], xmm15
0000773e7dfd9014  sub rsp, 0x40
0000773e7dfd9018  lea rdi, [rsp]
0000773e7dfd901c  lea rsi, [rsp+0x10]
0000773e7dfd9021  lea rdx, [rsp+0x20]
0000773e7dfd9026  lea rcx, [rsp+0x30]
0000773e7dfd902b  mov r8d, 0x00
0000773e7dfd9031  lea r9, [r15+0x3A8]
0000773e7dfd9038  movaps [rdi], xmm7
0000773e7dfd903b  movaps [rsi], xmm9
0000773e7dfd903f  movaps [rdx], xmm14
0000773e7dfd9043  movaps [rcx], xmm12
0000773e7dfd9047  mov rax, 0x567852F34A50
0000773e7dfd9051  call rax
0000773e7dfd9053  movaps xmm7, [rsp]
0000773e7dfd9057  add rsp, 0x40
0000773e7dfd905b  vmovaps xmm0, [rsp]
0000773e7dfd9060  vmovaps xmm1, [rsp+0x10]
0000773e7dfd9066  vmovaps xmm2, [rsp+0x20]
0000773e7dfd906c  vmovaps xmm3, [rsp+0x30]
0000773e7dfd9072  vmovaps xmm4, [rsp+0x40]
0000773e7dfd9078  vmovaps xmm5, [rsp+0x50]
0000773e7dfd907e  vmovaps xmm6, [rsp+0x60]
0000773e7dfd9084  vmovaps xmm8, [rsp+0x70]
0000773e7dfd908a  vmovaps xmm9, [rsp+0x80]
0000773e7dfd9093  vmovaps xmm10, [rsp+0x90]
0000773e7dfd909c  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd90a5  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd90ae  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd90b7  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd90c0  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd90c9  add rsp, 0xF0
0000773e7dfd90d0  pop r11
0000773e7dfd90d2  pop r10
0000773e7dfd90d4  pop r9
0000773e7dfd90d6  pop r8
0000773e7dfd90d8  pop rsi
0000773e7dfd90d9  pop rdi
0000773e7dfd90da  pop rdx
0000773e7dfd90db  pop rcx
0000773e7dfd90dc  pop rax
0000773e7dfd90dd  add rsp, 0x08
0000773e7dfd90e1  jmp 0x0000773E7DFD6B6D
0000773e7dfd90e6  sub rsp, 0x08
0000773e7dfd90ea  push rax
0000773e7dfd90eb  push rcx
0000773e7dfd90ec  push rdx
0000773e7dfd90ed  push rdi
0000773e7dfd90ee  push rsi
0000773e7dfd90ef  push r8
0000773e7dfd90f1  push r9
0000773e7dfd90f3  push r10
0000773e7dfd90f5  push r11
0000773e7dfd90f7  sub rsp, 0xF0
0000773e7dfd90fe  vmovaps [rsp], xmm0
0000773e7dfd9103  vmovaps [rsp+0x10], xmm1
0000773e7dfd9109  vmovaps [rsp+0x20], xmm2
0000773e7dfd910f  vmovaps [rsp+0x30], xmm3
0000773e7dfd9115  vmovaps [rsp+0x40], xmm4
0000773e7dfd911b  vmovaps [rsp+0x50], xmm5
0000773e7dfd9121  vmovaps [rsp+0x60], xmm6
0000773e7dfd9127  vmovaps [rsp+0x70], xmm7
0000773e7dfd912d  vmovaps [rsp+0x80], xmm8
0000773e7dfd9136  vmovaps [rsp+0x90], xmm9
0000773e7dfd913f  vmovaps [rsp+0xA0], xmm10
0000773e7dfd9148  vmovaps [rsp+0xB0], xmm11
0000773e7dfd9151  vmovaps [rsp+0xC0], xmm13
0000773e7dfd915a  vmovaps [rsp+0xD0], xmm14
0000773e7dfd9163  vmovaps [rsp+0xE0], xmm15
0000773e7dfd916c  sub rsp, 0x40
0000773e7dfd9170  lea rdi, [rsp]
0000773e7dfd9174  lea rsi, [rsp+0x10]
0000773e7dfd9179  lea rdx, [rsp+0x20]
0000773e7dfd917e  lea rcx, [rsp+0x30]
0000773e7dfd9183  mov r8d, 0x00
0000773e7dfd9189  lea r9, [r15+0x3A8]
0000773e7dfd9190  movaps [rdi], xmm12
0000773e7dfd9194  movaps [rsi], xmm11
0000773e7dfd9198  movaps [rdx], xmm15
0000773e7dfd919c  movaps [rcx], xmm14
0000773e7dfd91a0  mov rax, 0x567852F34A50
0000773e7dfd91aa  call rax
0000773e7dfd91ac  movaps xmm12, [rsp]
0000773e7dfd91b1  add rsp, 0x40
0000773e7dfd91b5  vmovaps xmm0, [rsp]
0000773e7dfd91ba  vmovaps xmm1, [rsp+0x10]
0000773e7dfd91c0  vmovaps xmm2, [rsp+0x20]
0000773e7dfd91c6  vmovaps xmm3, [rsp+0x30]
0000773e7dfd91cc  vmovaps xmm4, [rsp+0x40]
0000773e7dfd91d2  vmovaps xmm5, [rsp+0x50]
0000773e7dfd91d8  vmovaps xmm6, [rsp+0x60]
0000773e7dfd91de  vmovaps xmm7, [rsp+0x70]
0000773e7dfd91e4  vmovaps xmm8, [rsp+0x80]
0000773e7dfd91ed  vmovaps xmm9, [rsp+0x90]
0000773e7dfd91f6  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd91ff  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd9208  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd9211  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd921a  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd9223  add rsp, 0xF0
0000773e7dfd922a  pop r11
0000773e7dfd922c  pop r10
0000773e7dfd922e  pop r9
0000773e7dfd9230  pop r8
0000773e7dfd9232  pop rsi
0000773e7dfd9233  pop rdi
0000773e7dfd9234  pop rdx
0000773e7dfd9235  pop rcx
0000773e7dfd9236  pop rax
0000773e7dfd9237  add rsp, 0x08
0000773e7dfd923b  jmp 0x0000773E7DFD6B96
0000773e7dfd9240  sub rsp, 0x08
0000773e7dfd9244  push rax
0000773e7dfd9245  push rcx
0000773e7dfd9246  push rdx
0000773e7dfd9247  push rdi
0000773e7dfd9248  push rsi
0000773e7dfd9249  push r8
0000773e7dfd924b  push r9
0000773e7dfd924d  push r10
0000773e7dfd924f  push r11
0000773e7dfd9251  sub rsp, 0xF0
0000773e7dfd9258  vmovaps [rsp], xmm0
0000773e7dfd925d  vmovaps [rsp+0x10], xmm1
0000773e7dfd9263  vmovaps [rsp+0x20], xmm2
0000773e7dfd9269  vmovaps [rsp+0x30], xmm3
0000773e7dfd926f  vmovaps [rsp+0x40], xmm4
0000773e7dfd9275  vmovaps [rsp+0x50], xmm5
0000773e7dfd927b  vmovaps [rsp+0x60], xmm6
0000773e7dfd9281  vmovaps [rsp+0x70], xmm7
0000773e7dfd9287  vmovaps [rsp+0x80], xmm8
0000773e7dfd9290  vmovaps [rsp+0x90], xmm9
0000773e7dfd9299  vmovaps [rsp+0xA0], xmm10
0000773e7dfd92a2  vmovaps [rsp+0xB0], xmm12
0000773e7dfd92ab  vmovaps [rsp+0xC0], xmm13
0000773e7dfd92b4  vmovaps [rsp+0xD0], xmm14
0000773e7dfd92bd  vmovaps [rsp+0xE0], xmm15
0000773e7dfd92c6  sub rsp, 0x40
0000773e7dfd92ca  lea rdi, [rsp]
0000773e7dfd92ce  lea rsi, [rsp+0x10]
0000773e7dfd92d3  lea rdx, [rsp+0x20]
0000773e7dfd92d8  lea rcx, [rsp+0x30]
0000773e7dfd92dd  mov r8d, 0x00
0000773e7dfd92e3  lea r9, [r15+0x3A8]
0000773e7dfd92ea  movaps [rdi], xmm11
0000773e7dfd92ee  movaps [rsi], xmm10
0000773e7dfd92f2  movaps [rdx], xmm13
0000773e7dfd92f6  movaps [rcx], xmm15
0000773e7dfd92fa  mov rax, 0x567852F34A50
0000773e7dfd9304  call rax
0000773e7dfd9306  movaps xmm11, [rsp]
0000773e7dfd930b  add rsp, 0x40
0000773e7dfd930f  vmovaps xmm0, [rsp]
0000773e7dfd9314  vmovaps xmm1, [rsp+0x10]
0000773e7dfd931a  vmovaps xmm2, [rsp+0x20]
0000773e7dfd9320  vmovaps xmm3, [rsp+0x30]
0000773e7dfd9326  vmovaps xmm4, [rsp+0x40]
0000773e7dfd932c  vmovaps xmm5, [rsp+0x50]
0000773e7dfd9332  vmovaps xmm6, [rsp+0x60]
0000773e7dfd9338  vmovaps xmm7, [rsp+0x70]
0000773e7dfd933e  vmovaps xmm8, [rsp+0x80]
0000773e7dfd9347  vmovaps xmm9, [rsp+0x90]
0000773e7dfd9350  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd9359  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd9362  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd936b  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd9374  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd937d  add rsp, 0xF0
0000773e7dfd9384  pop r11
0000773e7dfd9386  pop r10
0000773e7dfd9388  pop r9
0000773e7dfd938a  pop r8
0000773e7dfd938c  pop rsi
0000773e7dfd938d  pop rdi
0000773e7dfd938e  pop rdx
0000773e7dfd938f  pop rcx
0000773e7dfd9390  pop rax
0000773e7dfd9391  add rsp, 0x08
0000773e7dfd9395  jmp 0x0000773E7DFD6BBF
0000773e7dfd939a  call 0x0000773E7DEE5820
0000773e7dfd939f  jmp 0x0000773E7DFD6BCC
0000773e7dfd93a4  call 0x0000773E7DEE45A0
0000773e7dfd93a9  jmp 0x0000773E7DFD6BD9
0000773e7dfd93ae  sub rsp, 0x08
0000773e7dfd93b2  push rax
0000773e7dfd93b3  push rcx
0000773e7dfd93b4  push rdx
0000773e7dfd93b5  push rdi
0000773e7dfd93b6  push rsi
0000773e7dfd93b7  push r8
0000773e7dfd93b9  push r9
0000773e7dfd93bb  push r10
0000773e7dfd93bd  push r11
0000773e7dfd93bf  sub rsp, 0xF0
0000773e7dfd93c6  vmovaps [rsp], xmm0
0000773e7dfd93cb  vmovaps [rsp+0x10], xmm1
0000773e7dfd93d1  vmovaps [rsp+0x20], xmm2
0000773e7dfd93d7  vmovaps [rsp+0x30], xmm3
0000773e7dfd93dd  vmovaps [rsp+0x40], xmm4
0000773e7dfd93e3  vmovaps [rsp+0x50], xmm5
0000773e7dfd93e9  vmovaps [rsp+0x60], xmm6
0000773e7dfd93ef  vmovaps [rsp+0x70], xmm7
0000773e7dfd93f5  vmovaps [rsp+0x80], xmm8
0000773e7dfd93fe  vmovaps [rsp+0x90], xmm9
0000773e7dfd9407  vmovaps [rsp+0xA0], xmm11
0000773e7dfd9410  vmovaps [rsp+0xB0], xmm12
0000773e7dfd9419  vmovaps [rsp+0xC0], xmm13
0000773e7dfd9422  vmovaps [rsp+0xD0], xmm14
0000773e7dfd942b  vmovaps [rsp+0xE0], xmm15
0000773e7dfd9434  sub rsp, 0x40
0000773e7dfd9438  lea rdi, [rsp]
0000773e7dfd943c  lea rsi, [rsp+0x10]
0000773e7dfd9441  lea rdx, [rsp+0x20]
0000773e7dfd9446  lea rcx, [rsp+0x30]
0000773e7dfd944b  mov r8d, 0x00
0000773e7dfd9451  lea r9, [r15+0x3A8]
0000773e7dfd9458  movaps [rdi], xmm10
0000773e7dfd945c  movaps [rsi], xmm8
0000773e7dfd9460  movaps [rdx], xmm1
0000773e7dfd9463  movaps [rcx], xmm13
0000773e7dfd9467  mov rax, 0x567852F34A50
0000773e7dfd9471  call rax
0000773e7dfd9473  movaps xmm10, [rsp]
0000773e7dfd9478  add rsp, 0x40
0000773e7dfd947c  vmovaps xmm0, [rsp]
0000773e7dfd9481  vmovaps xmm1, [rsp+0x10]
0000773e7dfd9487  vmovaps xmm2, [rsp+0x20]
0000773e7dfd948d  vmovaps xmm3, [rsp+0x30]
0000773e7dfd9493  vmovaps xmm4, [rsp+0x40]
0000773e7dfd9499  vmovaps xmm5, [rsp+0x50]
0000773e7dfd949f  vmovaps xmm6, [rsp+0x60]
0000773e7dfd94a5  vmovaps xmm7, [rsp+0x70]
0000773e7dfd94ab  vmovaps xmm8, [rsp+0x80]
0000773e7dfd94b4  vmovaps xmm9, [rsp+0x90]
0000773e7dfd94bd  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd94c6  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd94cf  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd94d8  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd94e1  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd94ea  add rsp, 0xF0
0000773e7dfd94f1  pop r11
0000773e7dfd94f3  pop r10
0000773e7dfd94f5  pop r9
0000773e7dfd94f7  pop r8
0000773e7dfd94f9  pop rsi
0000773e7dfd94fa  pop rdi
0000773e7dfd94fb  pop rdx
0000773e7dfd94fc  pop rcx
0000773e7dfd94fd  pop rax
0000773e7dfd94fe  add rsp, 0x08
0000773e7dfd9502  jmp 0x0000773E7DFD6C0F
0000773e7dfd9507  call 0x0000773E7DED64F0
0000773e7dfd950c  jmp 0x0000773E7DFD6C21
0000773e7dfd9511  sub rsp, 0x08
0000773e7dfd9515  push rax
0000773e7dfd9516  push rcx
0000773e7dfd9517  push rdx
0000773e7dfd9518  push rdi
0000773e7dfd9519  push rsi
0000773e7dfd951a  push r8
0000773e7dfd951c  push r9
0000773e7dfd951e  push r10
0000773e7dfd9520  push r11
0000773e7dfd9522  sub rsp, 0xF0
0000773e7dfd9529  vmovaps [rsp], xmm0
0000773e7dfd952e  vmovaps [rsp+0x10], xmm1
0000773e7dfd9534  vmovaps [rsp+0x20], xmm2
0000773e7dfd953a  vmovaps [rsp+0x30], xmm3
0000773e7dfd9540  vmovaps [rsp+0x40], xmm4
0000773e7dfd9546  vmovaps [rsp+0x50], xmm5
0000773e7dfd954c  vmovaps [rsp+0x60], xmm6
0000773e7dfd9552  vmovaps [rsp+0x70], xmm7
0000773e7dfd9558  vmovaps [rsp+0x80], xmm8
0000773e7dfd9561  vmovaps [rsp+0x90], xmm10
0000773e7dfd956a  vmovaps [rsp+0xA0], xmm11
0000773e7dfd9573  vmovaps [rsp+0xB0], xmm12
0000773e7dfd957c  vmovaps [rsp+0xC0], xmm13
0000773e7dfd9585  vmovaps [rsp+0xD0], xmm14
0000773e7dfd958e  vmovaps [rsp+0xE0], xmm15
0000773e7dfd9597  sub rsp, 0x40
0000773e7dfd959b  lea rdi, [rsp]
0000773e7dfd959f  lea rsi, [rsp+0x10]
0000773e7dfd95a4  lea rdx, [rsp+0x20]
0000773e7dfd95a9  lea rcx, [rsp+0x30]
0000773e7dfd95ae  mov r8d, 0x00
0000773e7dfd95b4  lea r9, [r15+0x3A8]
0000773e7dfd95bb  movaps [rdi], xmm9
0000773e7dfd95bf  movaps [rsi], xmm7
0000773e7dfd95c2  movaps [rdx], xmm14
0000773e7dfd95c6  movaps [rcx], xmm13
0000773e7dfd95ca  mov rax, 0x567852F34A50
0000773e7dfd95d4  call rax
0000773e7dfd95d6  movaps xmm9, [rsp]
0000773e7dfd95db  add rsp, 0x40
0000773e7dfd95df  vmovaps xmm0, [rsp]
0000773e7dfd95e4  vmovaps xmm1, [rsp+0x10]
0000773e7dfd95ea  vmovaps xmm2, [rsp+0x20]
0000773e7dfd95f0  vmovaps xmm3, [rsp+0x30]
0000773e7dfd95f6  vmovaps xmm4, [rsp+0x40]
0000773e7dfd95fc  vmovaps xmm5, [rsp+0x50]
0000773e7dfd9602  vmovaps xmm6, [rsp+0x60]
0000773e7dfd9608  vmovaps xmm7, [rsp+0x70]
0000773e7dfd960e  vmovaps xmm8, [rsp+0x80]
0000773e7dfd9617  vmovaps xmm10, [rsp+0x90]
0000773e7dfd9620  vmovaps xmm11, [rsp+0xA0]
0000773e7dfd9629  vmovaps xmm12, [rsp+0xB0]
0000773e7dfd9632  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd963b  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd9644  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd964d  add rsp, 0xF0
0000773e7dfd9654  pop r11
0000773e7dfd9656  pop r10
0000773e7dfd9658  pop r9
0000773e7dfd965a  pop r8
0000773e7dfd965c  pop rsi
0000773e7dfd965d  pop rdi
0000773e7dfd965e  pop rdx
0000773e7dfd965f  pop rcx
0000773e7dfd9660  pop rax
0000773e7dfd9661  add rsp, 0x08
0000773e7dfd9665  jmp 0x0000773E7DFD6C4F
0000773e7dfd966a  sub rsp, 0x08
0000773e7dfd966e  push rax
0000773e7dfd966f  push rcx
0000773e7dfd9670  push rdx
0000773e7dfd9671  push rdi
0000773e7dfd9672  push rsi
0000773e7dfd9673  push r8
0000773e7dfd9675  push r9
0000773e7dfd9677  push r10
0000773e7dfd9679  push r11
0000773e7dfd967b  sub rsp, 0xF0
0000773e7dfd9682  vmovaps [rsp], xmm0
0000773e7dfd9687  vmovaps [rsp+0x10], xmm1
0000773e7dfd968d  vmovaps [rsp+0x20], xmm2
0000773e7dfd9693  vmovaps [rsp+0x30], xmm3
0000773e7dfd9699  vmovaps [rsp+0x40], xmm4
0000773e7dfd969f  vmovaps [rsp+0x50], xmm5
0000773e7dfd96a5  vmovaps [rsp+0x60], xmm6
0000773e7dfd96ab  vmovaps [rsp+0x70], xmm7
0000773e7dfd96b1  vmovaps [rsp+0x80], xmm8
0000773e7dfd96ba  vmovaps [rsp+0x90], xmm9
0000773e7dfd96c3  vmovaps [rsp+0xA0], xmm10
0000773e7dfd96cc  vmovaps [rsp+0xB0], xmm11
0000773e7dfd96d5  vmovaps [rsp+0xC0], xmm12
0000773e7dfd96de  vmovaps [rsp+0xD0], xmm14
0000773e7dfd96e7  vmovaps [rsp+0xE0], xmm15
0000773e7dfd96f0  sub rsp, 0x40
0000773e7dfd96f4  lea rdi, [rsp]
0000773e7dfd96f8  lea rsi, [rsp+0x10]
0000773e7dfd96fd  lea rdx, [rsp+0x20]
0000773e7dfd9702  lea rcx, [rsp+0x30]
0000773e7dfd9707  mov r8d, 0x00
0000773e7dfd970d  lea r9, [r15+0x3A8]
0000773e7dfd9714  movaps [rdi], xmm13
0000773e7dfd9718  movaps [rsi], xmm12
0000773e7dfd971c  movaps [rdx], xmm15
0000773e7dfd9720  movaps [rcx], xmm14
0000773e7dfd9724  mov rax, 0x567852F34A50
0000773e7dfd972e  call rax
0000773e7dfd9730  movaps xmm13, [rsp]
0000773e7dfd9735  add rsp, 0x40
0000773e7dfd9739  vmovaps xmm0, [rsp]
0000773e7dfd973e  vmovaps xmm1, [rsp+0x10]
0000773e7dfd9744  vmovaps xmm2, [rsp+0x20]
0000773e7dfd974a  vmovaps xmm3, [rsp+0x30]
0000773e7dfd9750  vmovaps xmm4, [rsp+0x40]
0000773e7dfd9756  vmovaps xmm5, [rsp+0x50]
0000773e7dfd975c  vmovaps xmm6, [rsp+0x60]
0000773e7dfd9762  vmovaps xmm7, [rsp+0x70]
0000773e7dfd9768  vmovaps xmm8, [rsp+0x80]
0000773e7dfd9771  vmovaps xmm9, [rsp+0x90]
0000773e7dfd977a  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd9783  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd978c  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd9795  vmovaps xmm14, [rsp+0xD0]
0000773e7dfd979e  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd97a7  add rsp, 0xF0
0000773e7dfd97ae  pop r11
0000773e7dfd97b0  pop r10
0000773e7dfd97b2  pop r9
0000773e7dfd97b4  pop r8
0000773e7dfd97b6  pop rsi
0000773e7dfd97b7  pop rdi
0000773e7dfd97b8  pop rdx
0000773e7dfd97b9  pop rcx
0000773e7dfd97ba  pop rax
0000773e7dfd97bb  add rsp, 0x08
0000773e7dfd97bf  jmp 0x0000773E7DFD6C7D
0000773e7dfd97c4  sub rsp, 0x08
0000773e7dfd97c8  push rax
0000773e7dfd97c9  push rcx
0000773e7dfd97ca  push rdx
0000773e7dfd97cb  push rdi
0000773e7dfd97cc  push rsi
0000773e7dfd97cd  push r8
0000773e7dfd97cf  push r9
0000773e7dfd97d1  push r10
0000773e7dfd97d3  push r11
0000773e7dfd97d5  sub rsp, 0xF0
0000773e7dfd97dc  vmovaps [rsp], xmm0
0000773e7dfd97e1  vmovaps [rsp+0x10], xmm1
0000773e7dfd97e7  vmovaps [rsp+0x20], xmm2
0000773e7dfd97ed  vmovaps [rsp+0x30], xmm3
0000773e7dfd97f3  vmovaps [rsp+0x40], xmm4
0000773e7dfd97f9  vmovaps [rsp+0x50], xmm5
0000773e7dfd97ff  vmovaps [rsp+0x60], xmm6
0000773e7dfd9805  vmovaps [rsp+0x70], xmm7
0000773e7dfd980b  vmovaps [rsp+0x80], xmm8
0000773e7dfd9814  vmovaps [rsp+0x90], xmm9
0000773e7dfd981d  vmovaps [rsp+0xA0], xmm10
0000773e7dfd9826  vmovaps [rsp+0xB0], xmm11
0000773e7dfd982f  vmovaps [rsp+0xC0], xmm12
0000773e7dfd9838  vmovaps [rsp+0xD0], xmm13
0000773e7dfd9841  vmovaps [rsp+0xE0], xmm15
0000773e7dfd984a  sub rsp, 0x40
0000773e7dfd984e  lea rdi, [rsp]
0000773e7dfd9852  lea rsi, [rsp+0x10]
0000773e7dfd9857  lea rdx, [rsp+0x20]
0000773e7dfd985c  lea rcx, [rsp+0x30]
0000773e7dfd9861  mov r8d, 0x00
0000773e7dfd9867  lea r9, [r15+0x3A8]
0000773e7dfd986e  movaps [rdi], xmm14
0000773e7dfd9872  movaps [rsi], xmm11
0000773e7dfd9876  movaps [rdx], xmm1
0000773e7dfd9879  movaps [rcx], xmm15
0000773e7dfd987d  mov rax, 0x567852F34A50
0000773e7dfd9887  call rax
0000773e7dfd9889  movaps xmm14, [rsp]
0000773e7dfd988e  add rsp, 0x40
0000773e7dfd9892  vmovaps xmm0, [rsp]
0000773e7dfd9897  vmovaps xmm1, [rsp+0x10]
0000773e7dfd989d  vmovaps xmm2, [rsp+0x20]
0000773e7dfd98a3  vmovaps xmm3, [rsp+0x30]
0000773e7dfd98a9  vmovaps xmm4, [rsp+0x40]
0000773e7dfd98af  vmovaps xmm5, [rsp+0x50]
0000773e7dfd98b5  vmovaps xmm6, [rsp+0x60]
0000773e7dfd98bb  vmovaps xmm7, [rsp+0x70]
0000773e7dfd98c1  vmovaps xmm8, [rsp+0x80]
0000773e7dfd98ca  vmovaps xmm9, [rsp+0x90]
0000773e7dfd98d3  vmovaps xmm10, [rsp+0xA0]
0000773e7dfd98dc  vmovaps xmm11, [rsp+0xB0]
0000773e7dfd98e5  vmovaps xmm12, [rsp+0xC0]
0000773e7dfd98ee  vmovaps xmm13, [rsp+0xD0]
0000773e7dfd98f7  vmovaps xmm15, [rsp+0xE0]
0000773e7dfd9900  add rsp, 0xF0
0000773e7dfd9907  pop r11
0000773e7dfd9909  pop r10
0000773e7dfd990b  pop r9
0000773e7dfd990d  pop r8
0000773e7dfd990f  pop rsi
0000773e7dfd9910  pop rdi
0000773e7dfd9911  pop rdx
0000773e7dfd9912  pop rcx
0000773e7dfd9913  pop rax
0000773e7dfd9914  add rsp, 0x08
0000773e7dfd9918  jmp 0x0000773E7DFD6CAB
0000773e7dfd991d  call 0x0000773E7DEACF70
0000773e7dfd9922  jmp 0x0000773E7DFD6CB9
0000773e7dfd9927  call 0x0000773E7DE0C380
0000773e7dfd992c  jmp 0x0000773E7DFD6CC3
0000773e7dfd9931  call 0x0000773E7DE08C20
0000773e7dfd9936  jmp 0x0000773E7DFD6CCD
0000773e7dfd993b  call 0x0000773E7DE0D600
0000773e7dfd9940  jmp 0x0000773E7DFD6CD7
0000773e7dfd9945  int3
0000773e7dfd9946  nop [rax+rax*1], ax
0000773e7dfd994f  nop
0000773e7dfd9950  mov eax, [r15+0x48]
0000773e7dfd9954  lea r14d, [eax+0x01]
0000773e7dfd9959  mov [rsp+0x10], r14d
0000773e7dfd995e  mov r14d, r14d
0000773e7dfd9961  mov [r15+0x48], r14
0000773e7dfd9965  xor eax, eax
0000773e7dfd9967  mov r14d, [rsp+0x10]
0000773e7dfd996c  cmp r14d, 0x1F4
0000773e7dfd9973  cmc
0000773e7dfd9974  lahf
0000773e7dfd9975  seto al
0000773e7dfd9978  mov [r15+0x108], eax
0000773e7dfd997f  mov eax, [r15+0x108]
0000773e7dfd9986  sahf
0000773e7dfd9987  jnz 0x0000773E7DFD99B9
0000773e7dfd9989  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd9991  jz 0x0000773E7DFDD2E0
0000773e7dfd9997  nop [rax+rax*1], ax
0000773e7dfd99a0  nop [rax+rax*1], eax
0000773e7dfd99a8  mov eax, 0x410670
0000773e7dfd99ad  mov [r15+0x100], rax
0000773e7dfd99b4  jmp 0x0000773E7DDFE110
0000773e7dfd99b9  cmp dword ptr [r15+0x318], 0x00
0000773e7dfd99c1  jz 0x0000773E7DFD99F0
0000773e7dfd99c7  nop [rax+rax*1], ax
0000773e7dfd99d0  nop [rax+rax*1], eax
0000773e7dfd99d8  mov eax, 0x4104EC
0000773e7dfd99dd  mov [r15+0x100], rax
0000773e7dfd99e4  jmp 0x0000773E7DDFE110
0000773e7dfd99e9  int3
0000773e7dfd99ea  int3
0000773e7dfd99eb  nop [rax+rax*1], eax
0000773e7dfd99f0  mov rax, [r15+0x40]
0000773e7dfd99f4  vxorps xmm1, xmm1, xmm1
0000773e7dfd99f8  vpbroadcastq xmm1, xmm1
0000773e7dfd99fd  vxorps xmm15, xmm15, xmm15
0000773e7dfd9a02  vpbroadcastq xmm15, xmm15
0000773e7dfd9a07  lea r14, [rax+0x30]
0000773e7dfd9a0b  mov r12, [r13+r14*1]
0000773e7dfd9a10  lea r14, [rax+0x38]
0000773e7dfd9a14  mov r11, [r13+r14*1]
0000773e7dfd9a19  movq xmm14, r12
0000773e7dfd9a1e  movq xmm13, r11
0000773e7dfd9a23  movq xmm14, xmm14
0000773e7dfd9a28  movq xmm13, xmm13
0000773e7dfd9a2d  vmovaps [rsp+0x10], xmm13
0000773e7dfd9a33  movq xmm13, xmm13
0000773e7dfd9a38  movaps [r15+0x270], xmm13
0000773e7dfd9a40  movaps xmm13, [r15+0x160]
0000773e7dfd9a48  vmovaps [rsp+0x20], xmm13
0000773e7dfd9a4e  vmovaps xmm12, [rsp+0x20]
0000773e7dfd9a54  por xmm13, xmm12
0000773e7dfd9a59  lea r14, [rax+0x20]
0000773e7dfd9a5d  mov r12, [r13+r14*1]
0000773e7dfd9a62  lea r14, [rax+0x28]
0000773e7dfd9a66  mov r11, [r13+r14*1]
0000773e7dfd9a6b  movq xmm12, r12
0000773e7dfd9a70  movq xmm11, r11
0000773e7dfd9a75  movq xmm12, xmm12
0000773e7dfd9a7a  movq xmm11, xmm11
0000773e7dfd9a7f  movaps xmm10, [r15+0x2D0]
0000773e7dfd9a87  vmovaps [rsp+0x20], xmm10
0000773e7dfd9a8d  vmovaps xmm9, [rsp+0x20]
0000773e7dfd9a93  por xmm10, xmm9
0000773e7dfd9a98  movaps xmm9, [r15+0x300]
0000773e7dfd9aa0  vmovaps [rsp+0x20], xmm9
0000773e7dfd9aa6  vmovaps xmm8, [rsp+0x20]
0000773e7dfd9aac  por xmm9, xmm8
0000773e7dfd9ab1  movaps xmm8, [r15+0x2B0]
0000773e7dfd9ab9  vmovaps [rsp+0x20], xmm8
0000773e7dfd9abf  vmovaps xmm7, [rsp+0x20]
0000773e7dfd9ac5  por xmm8, xmm7
0000773e7dfd9aca  movaps xmm7, [r15+0x180]
0000773e7dfd9ad2  vmovaps [rsp+0x20], xmm7
0000773e7dfd9ad8  vmovaps xmm6, [rsp+0x20]
0000773e7dfd9ade  por xmm7, xmm6
0000773e7dfd9ae2  lea r14, [rax+0x10]
0000773e7dfd9ae6  mov r12, [r13+r14*1]
0000773e7dfd9aeb  lea r14, [rax+0x18]
0000773e7dfd9aef  mov r11, [r13+r14*1]
0000773e7dfd9af4  movq xmm6, r12
0000773e7dfd9af9  movq xmm5, r11
0000773e7dfd9afe  movq xmm6, xmm6
0000773e7dfd9b02  movq xmm5, xmm5
0000773e7dfd9b06  movaps xmm4, [r15+0x200]
0000773e7dfd9b0e  vmovaps [rsp+0x20], xmm4
0000773e7dfd9b14  vmovaps xmm3, [rsp+0x20]
0000773e7dfd9b1a  por xmm4, xmm3
0000773e7dfd9b1e  movaps xmm3, [r15+0x1F0]
0000773e7dfd9b26  vmovaps [rsp+0x20], xmm3
0000773e7dfd9b2c  vmovaps xmm2, [rsp+0x20]
0000773e7dfd9b32  por xmm3, xmm2
0000773e7dfd9b36  movaps xmm2, [r15+0x2E0]
0000773e7dfd9b3e  vmovaps [rsp+0x20], xmm2
0000773e7dfd9b44  vmovaps [rsp+0x30], xmm1
0000773e7dfd9b4a  vmovaps xmm1, [rsp+0x20]
0000773e7dfd9b50  por xmm2, xmm1
0000773e7dfd9b54  movaps xmm1, [r15+0x2A0]
0000773e7dfd9b5c  vmovaps [rsp+0x20], xmm1
0000773e7dfd9b62  vmovaps [rsp+0x40], xmm15
0000773e7dfd9b68  vmovaps xmm15, [rsp+0x20]
0000773e7dfd9b6e  por xmm1, xmm15
0000773e7dfd9b73  movaps xmm15, [r15+0x280]
0000773e7dfd9b7b  vmovaps [rsp+0x20], xmm15
0000773e7dfd9b81  vmovaps [rsp+0x50], xmm1
0000773e7dfd9b87  vmovaps xmm1, [rsp+0x20]
0000773e7dfd9b8d  por xmm15, xmm1
0000773e7dfd9b92  movaps xmm1, [r15+0x1C0]
0000773e7dfd9b9a  vmovaps [rsp+0x20], xmm1
0000773e7dfd9ba0  vmovaps [rsp+0x60], xmm15
0000773e7dfd9ba6  vmovaps xmm15, [rsp+0x20]
0000773e7dfd9bac  por xmm1, xmm15
0000773e7dfd9bb1  movaps xmm15, [r15+0x210]
0000773e7dfd9bb9  vmovaps [rsp+0x20], xmm15
0000773e7dfd9bbf  vmovaps [rsp+0x70], xmm1
0000773e7dfd9bc5  vmovaps xmm1, [rsp+0x20]
0000773e7dfd9bcb  por xmm15, xmm1
0000773e7dfd9bd0  mov r14, [r13+rax*1]
0000773e7dfd9bd5  vmovq xmm1, r14
0000773e7dfd9bda  vpbroadcastq xmm1, xmm1
0000773e7dfd9bdf  vmovaps [rsp+0x20], xmm1
0000773e7dfd9be5  vxorps xmm1, xmm1, xmm1
0000773e7dfd9be9  vpbroadcastq xmm1, xmm1
0000773e7dfd9bee  mov r14, [r15+0xF8]
0000773e7dfd9bf5  vmovaps [rsp+0x80], xmm1
0000773e7dfd9bfe  movups xmm1, [r13+r14*1]
0000773e7dfd9c04  vmovaps [rsp+0x90], xmm1
0000773e7dfd9c0d  vxorps xmm1, xmm1, xmm1
0000773e7dfd9c11  vpbroadcastq xmm1, xmm1
0000773e7dfd9c16  lea r12, [rax+0x08]
0000773e7dfd9c1a  mov rax, [r13+r12*1]
0000773e7dfd9c1f  vmovaps [rsp+0xA0], xmm1
0000773e7dfd9c28  movq xmm1, rax
0000773e7dfd9c2d  movaps [r15+0x240], xmm1
0000773e7dfd9c35  mov rax, [r15+0x50]
0000773e7dfd9c39  mov [r15+0x60], rax
0000773e7dfd9c3d  mov qword ptr [r15+0x58], 0x40
0000773e7dfd9c45  vmovaps xmm1, [rsp+0x30]
0000773e7dfd9c4b  vmovaps [rsp+0x30], xmm15
0000773e7dfd9c51  vmovaps xmm15, [rsp+0x90]
0000773e7dfd9c5a  vmovaps [rsp+0x90], xmm14
0000773e7dfd9c63  vmovaps xmm14, [rsp+0x20]
0000773e7dfd9c69  vmovaps [rsp+0x20], xmm13
0000773e7dfd9c6f  vmovaps [rsp+0xB0], xmm12
0000773e7dfd9c78  movaps xmm13, xmm1
0000773e7dfd9c7c  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd9c87  vptest xmm12, xmm12
0000773e7dfd9c8c  jnz 0x0000773E7DFDA72F
0000773e7dfd9c92  movaps xmm1, [r15+0x250]
0000773e7dfd9c9a  vmovaps xmm15, [rsp+0x40]
0000773e7dfd9ca0  vmovaps [rsp+0x40], xmm13
0000773e7dfd9ca6  movaps xmm12, xmm15
0000773e7dfd9caa  vfmadd231pd xmm12, xmm1, xmm14
0000773e7dfd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
0000773e7dfd9cb5  vptest xmm13, xmm13
0000773e7dfd9cba  jnz 0x0000773E7DFDA888
0000773e7dfd9cc0  movaps xmm15, [r15+0x1E0]
0000773e7dfd9cc8  vmovaps [rsp+0xC0], xmm15
0000773e7dfd9cd1  vmovaps xmm13, [rsp+0xC0]
0000773e7dfd9cda  por xmm15, xmm13
0000773e7dfd9cdf  movaps xmm13, [r15+0x1D0]
0000773e7dfd9ce7  vmovaps [rsp+0xC0], xmm13
0000773e7dfd9cf0  vmovaps [rsp+0xD0], xmm1
0000773e7dfd9cf9  vmovaps xmm1, [rsp+0xC0]
0000773e7dfd9d02  por xmm13, xmm1
0000773e7dfd9d07  movaps xmm1, [r15+0x2C0]
0000773e7dfd9d0f  vmovaps [rsp+0xC0], xmm1
0000773e7dfd9d18  vmovaps [rsp+0xE0], xmm15
0000773e7dfd9d21  vmovaps xmm15, [rsp+0xC0]
0000773e7dfd9d2a  por xmm1, xmm15
0000773e7dfd9d2f  movaps xmm15, [r15+0x290]
0000773e7dfd9d37  vmovaps [rsp+0xC0], xmm15
0000773e7dfd9d40  vmovaps [rsp+0xF0], xmm1
0000773e7dfd9d49  vmovaps xmm1, [rsp+0xC0]
0000773e7dfd9d52  por xmm15, xmm1
0000773e7dfd9d57  movaps xmm1, [r15+0x260]
0000773e7dfd9d5f  vmovaps [rsp+0xC0], xmm1
0000773e7dfd9d68  vmovaps [rsp+0x100], xmm15
0000773e7dfd9d71  vmovaps xmm15, [rsp+0xC0]
0000773e7dfd9d7a  por xmm1, xmm15
0000773e7dfd9d7f  vmovaps xmm15, [rsp+0xD0]
0000773e7dfd9d88  vmovaps [rsp+0xC0], xmm1
0000773e7dfd9d91  vmovaps xmm1, [rsp+0xD0]
0000773e7dfd9d9a  por xmm15, xmm1
0000773e7dfd9d9f  lea r12, [r14+0xC0]
0000773e7dfd9da6  movups xmm1, [r13+r12*1]
0000773e7dfd9dac  mov [rsp+0xD0], rax
0000773e7dfd9db4  xor eax, eax
0000773e7dfd9db6  mov r12d, 0x40
0000773e7dfd9dbc  mov r11d, 0x200
0000773e7dfd9dc2  cmp r12, r11
0000773e7dfd9dc5  cmc
0000773e7dfd9dc6  lahf
0000773e7dfd9dc7  seto al
0000773e7dfd9dca  mov [r15+0x108], eax
0000773e7dfd9dd1  vmovaps [rsp+0x110], xmm1
0000773e7dfd9dda  vmovaps xmm1, [rsp+0x80]
0000773e7dfd9de3  vmovaps [rsp+0x80], xmm15
0000773e7dfd9dec  vmovaps xmm15, [rsp+0x110]
0000773e7dfd9df5  vmovaps [rsp+0x110], xmm13
0000773e7dfd9dfe  vmovaps [rsp+0x120], xmm12
0000773e7dfd9e07  movaps xmm13, xmm1
0000773e7dfd9e0b  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd9e16  vptest xmm12, xmm12
0000773e7dfd9e1b  jnz 0x0000773E7DFDA9EB
0000773e7dfd9e21  lea rax, [r14+0xB0]
0000773e7dfd9e28  movups xmm1, [r13+rax*1]
0000773e7dfd9e2e  vmovaps xmm15, [rsp+0xA0]
0000773e7dfd9e37  vmovaps [rsp+0xA0], xmm13
0000773e7dfd9e40  movaps xmm12, xmm15
0000773e7dfd9e44  vfmadd231pd xmm12, xmm1, xmm14
0000773e7dfd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
0000773e7dfd9e4f  vptest xmm13, xmm13
0000773e7dfd9e54  jnz 0x0000773E7DFDAB4E
0000773e7dfd9e5a  vmovaps xmm1, [rsp+0x30]
0000773e7dfd9e60  vmovaps xmm15, [rsp+0x30]
0000773e7dfd9e66  por xmm1, xmm15
0000773e7dfd9e6b  movaps [r15+0x210], xmm1
0000773e7dfd9e73  vmovaps xmm15, [rsp+0x70]
0000773e7dfd9e79  vmovaps xmm14, [rsp+0x70]
0000773e7dfd9e7f  por xmm15, xmm14
0000773e7dfd9e84  movaps [r15+0x1C0], xmm15
0000773e7dfd9e8c  vmovaps xmm14, [rsp+0x60]
0000773e7dfd9e92  vmovaps xmm13, [rsp+0x60]
0000773e7dfd9e98  por xmm14, xmm13
0000773e7dfd9e9d  movaps [r15+0x280], xmm14
0000773e7dfd9ea5  vmovaps xmm13, [rsp+0x50]
0000773e7dfd9eab  vmovaps [rsp+0x30], xmm1
0000773e7dfd9eb1  vmovaps xmm1, [rsp+0x50]
0000773e7dfd9eb7  por xmm13, xmm1
0000773e7dfd9ebc  movaps [r15+0x2A0], xmm13
0000773e7dfd9ec4  vmovaps [rsp+0x50], xmm2
0000773e7dfd9eca  vmovaps xmm1, [rsp+0x50]
0000773e7dfd9ed0  por xmm2, xmm1
0000773e7dfd9ed4  movaps [r15+0x2E0], xmm2
0000773e7dfd9edc  vmovaps [rsp+0x50], xmm3
0000773e7dfd9ee2  vmovaps xmm1, [rsp+0x50]
0000773e7dfd9ee8  por xmm3, xmm1
0000773e7dfd9eec  movaps [r15+0x1F0], xmm3
0000773e7dfd9ef4  vmovaps xmm1, [rsp+0x80]
0000773e7dfd9efd  vmovaps [rsp+0x50], xmm15
0000773e7dfd9f03  vmovaps xmm15, [rsp+0x80]
0000773e7dfd9f0c  por xmm1, xmm15
0000773e7dfd9f11  movaps [r15+0x250], xmm1
0000773e7dfd9f19  vmovaps xmm1, [rsp+0xC0]
0000773e7dfd9f22  vmovaps xmm15, [rsp+0xC0]
0000773e7dfd9f2b  por xmm1, xmm15
0000773e7dfd9f30  movaps [r15+0x260], xmm1
0000773e7dfd9f38  vmovaps xmm15, [rsp+0x100]
0000773e7dfd9f41  vmovaps [rsp+0x60], xmm1
0000773e7dfd9f47  vmovaps xmm1, [rsp+0x100]
0000773e7dfd9f50  por xmm15, xmm1
0000773e7dfd9f55  movaps [r15+0x290], xmm15
0000773e7dfd9f5d  vmovaps xmm1, [rsp+0xF0]
0000773e7dfd9f66  vmovaps [rsp+0x70], xmm15
0000773e7dfd9f6c  vmovaps xmm15, [rsp+0xF0]
0000773e7dfd9f75  por xmm1, xmm15
0000773e7dfd9f7a  movaps [r15+0x2C0], xmm1
0000773e7dfd9f82  movq xmm15, qword ptr [r15+0x240]
0000773e7dfd9f8b  vmovaps [rsp+0x80], xmm15
0000773e7dfd9f94  vpermilpd xmm15, xmm15, 0x00
0000773e7dfd9f9a  vmovaps [rsp+0xC0], xmm1
0000773e7dfd9fa3  vmovaps xmm1, [rsp+0x40]
0000773e7dfd9fa9  vmovaps [rsp+0x40], xmm15
0000773e7dfd9faf  vmovaps xmm15, [rsp+0x30]
0000773e7dfd9fb5  vmovaps [rsp+0x30], xmm14
0000773e7dfd9fbb  vmovaps xmm14, [rsp+0x40]
0000773e7dfd9fc1  vmovaps [rsp+0x40], xmm13
0000773e7dfd9fc7  vmovaps [rsp+0xF0], xmm12
0000773e7dfd9fd0  movaps xmm13, xmm1
0000773e7dfd9fd4  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000773e7dfd9fdf  vptest xmm12, xmm12
0000773e7dfd9fe4  jnz 0x0000773E7DFDACA7
0000773e7dfd9fea  vmovaps xmm1, [rsp+0x80]
0000773e7dfd9ff3  vpermilpd xmm1, xmm1, 0x00
0000773e7dfd9ff9  vmovaps xmm15, [rsp+0xA0]
0000773e7dfda002  movaps xmm14, xmm15
0000773e7dfda006  vfmadd231pd xmm14, xmm2, xmm1
0000773e7dfda00b  vcmppd xmm12, xmm14, xmm14, 0x03
0000773e7dfda011  vptest xmm12, xmm12
0000773e7dfda016  jnz 0x0000773E7DFDAE00
0000773e7dfda01c  vmovaps xmm1, [rsp+0x80]
0000773e7dfda025  vpermilpd xmm1, xmm1, 0x00
0000773e7dfda02b  vmovaps xmm15, [rsp+0x120]
0000773e7dfda034  vmovaps xmm12, [rsp+0x50]
0000773e7dfda03a  vmovaps [rsp+0x50], xmm14
0000773e7dfda040  movaps xmm2, xmm15
0000773e7dfda044  vfmadd231pd xmm2, xmm12, xmm1
0000773e7dfda049  vcmppd xmm14, xmm2, xmm2, 0x03
0000773e7dfda04e  vptest xmm14, xmm14
0000773e7dfda053  jnz 0x0000773E7DFDAF58
0000773e7dfda059  vmovaps xmm1, [rsp+0x110]
0000773e7dfda062  vmovaps xmm15, [rsp+0x110]
0000773e7dfda06b  por xmm1, xmm15
0000773e7dfda070  movaps [r15+0x1D0], xmm1
0000773e7dfda078  vmovaps xmm15, [rsp+0x80]
0000773e7dfda081  vpermilpd xmm15, xmm15, 0x00
0000773e7dfda087  vmovaps xmm14, [rsp+0xF0]
0000773e7dfda090  vmovaps [rsp+0x80], xmm1
0000773e7dfda099  movaps xmm12, xmm14
0000773e7dfda09d  vfmadd231pd xmm12, xmm3, xmm15
0000773e7dfda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
0000773e7dfda0a8  vptest xmm1, xmm1
0000773e7dfda0ad  jnz 0x0000773E7DFDB0AF
0000773e7dfda0b3  vmovaps [rsp+0xA0], xmm4
0000773e7dfda0bc  vmovaps xmm1, [rsp+0xA0]
0000773e7dfda0c5  por xmm4, xmm1
0000773e7dfda0c9  movaps [r15+0x200], xmm4
0000773e7dfda0d1  vmovaps xmm1, [rsp+0xE0]
0000773e7dfda0da  vmovaps xmm15, [rsp+0xE0]
0000773e7dfda0e3  por xmm1, xmm15
0000773e7dfda0e8  movaps [r15+0x1E0], xmm1
0000773e7dfda0f0  vmovaps [rsp+0xA0], xmm8
0000773e7dfda0f9  vmovaps xmm1, [rsp+0xA0]
0000773e7dfda102  por xmm8, xmm1
0000773e7dfda107  movaps [r15+0x2B0], xmm8
0000773e7dfda10f  vmovaps [rsp+0xA0], xmm9
0000773e7dfda118  vmovaps xmm1, [rsp+0xA0]
0000773e7dfda121  por xmm9, xmm1
0000773e7dfda126  movaps [r15+0x300], xmm9
0000773e7dfda12e  vmovaps [rsp+0xA0], xmm6
0000773e7dfda137  vpermilpd xmm6, xmm6, 0x00
0000773e7dfda13d  vmovaps xmm14, [rsp+0x60]
0000773e7dfda143  movaps xmm9, xmm13
0000773e7dfda147  vfmadd231pd xmm9, xmm14, xmm6
0000773e7dfda14c  vcmppd xmm3, xmm9, xmm9, 0x03
0000773e7dfda152  vptest xmm3, xmm3
0000773e7dfda157  jnz 0x0000773E7DFDB208
0000773e7dfda15d  vmovaps xmm14, [rsp+0xA0]
0000773e7dfda166  vpermilpd xmm14, xmm14, 0x00
0000773e7dfda16c  vmovaps xmm13, [rsp+0x50]
0000773e7dfda172  vmovaps xmm6, [rsp+0xC0]
0000773e7dfda17b  vmovaps [rsp+0x50], xmm1
0000773e7dfda181  movaps xmm3, xmm13
0000773e7dfda185  vfmadd231pd xmm3, xmm6, xmm14
0000773e7dfda18a  vcmppd xmm1, xmm3, xmm3, 0x03
0000773e7dfda18f  vptest xmm1, xmm1
0000773e7dfda194  jnz 0x0000773E7DFDB361
0000773e7dfda19a  vmovaps xmm1, [rsp+0xA0]
0000773e7dfda1a3  vpermilpd xmm1, xmm1, 0x00
0000773e7dfda1a9  vmovaps xmm14, [rsp+0x30]
0000773e7dfda1af  movaps xmm6, xmm2
0000773e7dfda1b2  vfmadd231pd xmm6, xmm14, xmm1
0000773e7dfda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
0000773e7dfda1bc  vptest xmm13, xmm13
0000773e7dfda1c1  jnz 0x0000773E7DFDB4B8
0000773e7dfda1c7  vmovaps xmm1, [rsp+0xA0]
0000773e7dfda1d0  vpermilpd xmm1, xmm1, 0x00
0000773e7dfda1d6  vmovaps xmm14, [rsp+0x80]
0000773e7dfda1df  movaps xmm13, xmm12
0000773e7dfda1e3  vfmadd231pd xmm13, xmm14, xmm1
0000773e7dfda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
0000773e7dfda1ee  vptest xmm2, xmm2
0000773e7dfda1f3  jnz 0x0000773E7DFDB60E
0000773e7dfda1f9  vmovaps [rsp+0x30], xmm7
0000773e7dfda1ff  vmovaps xmm1, [rsp+0x30]
0000773e7dfda205  por xmm7, xmm1
0000773e7dfda209  movaps [r15+0x180], xmm7
0000773e7dfda211  vmovaps [rsp+0x30], xmm10
0000773e7dfda217  vmovaps xmm1, [rsp+0x30]
0000773e7dfda21d  por xmm10, xmm1
0000773e7dfda222  movaps [r15+0x2D0], xmm10
0000773e7dfda22a  vmovaps [rsp+0x30], xmm5
0000773e7dfda230  vpermilpd xmm5, xmm5, 0x00
0000773e7dfda236  vmovaps xmm14, [rsp+0x50]
0000773e7dfda23c  movaps xmm12, xmm3
0000773e7dfda240  vfmadd231pd xmm12, xmm14, xmm5
0000773e7dfda245  vcmppd xmm10, xmm12, xmm12, 0x03
0000773e7dfda24b  vptest xmm10, xmm10
0000773e7dfda250  jnz 0x0000773E7DFDB767
0000773e7dfda256  vmovaps xmm14, [rsp+0x30]
0000773e7dfda25c  vpermilpd xmm14, xmm14, 0x00
0000773e7dfda262  movaps xmm10, xmm9
0000773e7dfda266  vfmadd231pd xmm10, xmm7, xmm14
0000773e7dfda26b  vcmppd xmm5, xmm10, xmm10, 0x03
0000773e7dfda271  vptest xmm5, xmm5
0000773e7dfda276  jnz 0x0000773E7DFDB8BF
0000773e7dfda27c  lea rax, [r14+0x80]
0000773e7dfda283  movups xmm14, [r13+rax*1]
0000773e7dfda289  movaps [r15+0x2F0], xmm14
0000773e7dfda291  vmovaps xmm9, [rsp+0x30]
0000773e7dfda297  vpermilpd xmm9, xmm9, 0x00
0000773e7dfda29d  vmovaps xmm7, [rsp+0x70]
0000773e7dfda2a3  movaps xmm5, xmm6
0000773e7dfda2a6  vfmadd231pd xmm5, xmm7, xmm9
0000773e7dfda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
0000773e7dfda2b0  vptest xmm3, xmm3
0000773e7dfda2b5  jnz 0x0000773E7DFDBA22
0000773e7dfda2bb  vmovaps xmm9, [rsp+0x30]
0000773e7dfda2c1  vpermilpd xmm9, xmm9, 0x00
0000773e7dfda2c7  movaps xmm7, xmm13
0000773e7dfda2cb  vfmadd231pd xmm7, xmm1, xmm9
0000773e7dfda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
0000773e7dfda2d5  vptest xmm6, xmm6
0000773e7dfda2da  jnz 0x0000773E7DFDBB78
0000773e7dfda2e0  vmovaps xmm1, [rsp+0x20]
0000773e7dfda2e6  vmovaps xmm13, [rsp+0x20]
0000773e7dfda2ec  por xmm1, xmm13
0000773e7dfda2f1  movaps [r15+0x160], xmm1
0000773e7dfda2f9  lea rax, [r14+0x40]
0000773e7dfda2fd  movups xmm13, [r13+rax*1]
0000773e7dfda303  lea rax, [r14+0x50]
0000773e7dfda307  movups xmm9, [r13+rax*1]
0000773e7dfda30d  movaps [r15+0x1B0], xmm13
0000773e7dfda315  movaps [r15+0x1A0], xmm9
0000773e7dfda31d  movaps xmm6, [r15+0x190]
0000773e7dfda325  vmovaps xmm3, [rsp+0xB0]
0000773e7dfda32e  vpermilpd xmm3, xmm3, 0x00
0000773e7dfda334  vmovaps [rsp+0x20], xmm1
0000773e7dfda33a  movaps xmm2, xmm12
0000773e7dfda33e  vfmadd231pd xmm2, xmm6, xmm3
0000773e7dfda343  vcmppd xmm1, xmm2, xmm2, 0x03
0000773e7dfda348  vptest xmm1, xmm1
0000773e7dfda34d  jnz 0x0000773E7DFDBCE3
0000773e7dfda353  vmovaps xmm1, [rsp+0xB0]
0000773e7dfda35c  vpermilpd xmm1, xmm1, 0x00
0000773e7dfda362  vmovaps xmm12, [rsp+0x20]
0000773e7dfda368  movaps xmm6, xmm10
0000773e7dfda36c  vfmadd231pd xmm6, xmm12, xmm1
0000773e7dfda371  vcmppd xmm3, xmm6, xmm6, 0x03
0000773e7dfda376  vptest xmm3, xmm3
0000773e7dfda37b  jnz 0x0000773E7DFDBE39
0000773e7dfda381  vmovaps xmm1, [rsp+0xB0]
0000773e7dfda38a  vpermilpd xmm1, xmm1, 0x00
0000773e7dfda390  vmovaps xmm12, [rsp+0x40]
0000773e7dfda396  movaps xmm10, xmm5
0000773e7dfda39a  vfmadd231pd xmm10, xmm12, xmm1
0000773e7dfda39f  vcmppd xmm3, xmm10, xmm10, 0x03
0000773e7dfda3a5  vptest xmm3, xmm3
0000773e7dfda3aa  jnz 0x0000773E7DFDBF90
0000773e7dfda3b0  vmovaps xmm1, [rsp+0xB0]
0000773e7dfda3b9  vpermilpd xmm1, xmm1, 0x00
0000773e7dfda3bf  movaps xmm12, xmm7
0000773e7dfda3c3  vfmadd231pd xmm12, xmm15, xmm1
0000773e7dfda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
0000773e7dfda3ce  vptest xmm5, xmm5
0000773e7dfda3d3  jnz 0x0000773E7DFDC0E8
0000773e7dfda3d9  lea rax, [r14+0x60]
0000773e7dfda3dd  movups xmm1, [r13+rax*1]
0000773e7dfda3e3  lea rax, [r14+0x70]
0000773e7dfda3e7  movups xmm15, [r13+rax*1]
0000773e7dfda3ed  movaps [r15+0x150], xmm1
0000773e7dfda3f5  movaps [r15+0x120], xmm15
0000773e7dfda3fd  vmovaps [rsp+0x20], xmm11
0000773e7dfda403  vpermilpd xmm11, xmm11, 0x00
0000773e7dfda409  movaps xmm7, xmm2
0000773e7dfda40c  vfmadd231pd xmm7, xmm9, xmm11
0000773e7dfda411  vcmppd xmm5, xmm7, xmm7, 0x03
0000773e7dfda416  vptest xmm5, xmm5
0000773e7dfda41b  jnz 0x0000773E7DFDC254
0000773e7dfda421  vmovaps xmm11, [rsp+0x20]
0000773e7dfda427  vpermilpd xmm11, xmm11, 0x00
0000773e7dfda42d  movaps xmm9, xmm6
0000773e7dfda431  vfmadd231pd xmm9, xmm1, xmm11
0000773e7dfda436  vcmppd xmm5, xmm9, xmm9, 0x03
0000773e7dfda43c  vptest xmm5, xmm5
0000773e7dfda441  jnz 0x0000773E7DFDC3AB
0000773e7dfda447  vmovaps xmm1, [rsp+0x20]
0000773e7dfda44d  vpermilpd xmm1, xmm1, 0x00
0000773e7dfda453  movaps xmm11, xmm10
0000773e7dfda457  vfmadd231pd xmm11, xmm8, xmm1
0000773e7dfda45c  vcmppd xmm6, xmm11, xmm11, 0x03
0000773e7dfda462  vptest xmm6, xmm6
0000773e7dfda467  jnz 0x0000773E7DFDC503
0000773e7dfda46d  vmovaps xmm1, [rsp+0x20]
0000773e7dfda473  vpermilpd xmm1, xmm1, 0x00
0000773e7dfda479  movaps xmm10, xmm12
0000773e7dfda47d  vfmadd231pd xmm10, xmm13, xmm1
0000773e7dfda482  vcmppd xmm8, xmm10, xmm10, 0x03
0000773e7dfda488  vptest xmm8, xmm8
0000773e7dfda48d  jnz 0x0000773E7DFDC65C
0000773e7dfda493  lea rax, [r14+0x20]
0000773e7dfda497  movups xmm1, [r13+rax*1]
0000773e7dfda49d  lea rax, [r14+0x30]
0000773e7dfda4a1  movups xmm13, [r13+rax*1]
0000773e7dfda4a7  vmovaps xmm12, [rsp+0x90]
0000773e7dfda4b0  vpermilpd xmm12, xmm12, 0x00
0000773e7dfda4b6  movaps xmm8, xmm7
0000773e7dfda4ba  vfmadd231pd xmm8, xmm4, xmm12
0000773e7dfda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
0000773e7dfda4c5  vptest xmm6, xmm6
0000773e7dfda4ca  jnz 0x0000773E7DFDC7C9
0000773e7dfda4d0  vmovaps xmm12, [rsp+0x90]
0000773e7dfda4d9  vpermilpd xmm12, xmm12, 0x00
0000773e7dfda4df  movaps xmm7, xmm9
0000773e7dfda4e3  vfmadd231pd xmm7, xmm14, xmm12
0000773e7dfda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
0000773e7dfda4ed  vptest xmm6, xmm6
0000773e7dfda4f2  jnz 0x0000773E7DFDC921
0000773e7dfda4f8  vmovaps xmm14, [rsp+0x90]
0000773e7dfda501  vpermilpd xmm14, xmm14, 0x00
0000773e7dfda507  movaps xmm12, xmm11
0000773e7dfda50b  vfmadd231pd xmm12, xmm15, xmm14
0000773e7dfda510  vcmppd xmm9, xmm12, xmm12, 0x03
0000773e7dfda516  vptest xmm9, xmm9
0000773e7dfda51b  jnz 0x0000773E7DFDCA79
0000773e7dfda521  vmovaps xmm15, [rsp+0x90]
0000773e7dfda52a  vpermilpd xmm15, xmm15, 0x00
0000773e7dfda530  movaps xmm11, xmm10
0000773e7dfda534  vfmadd231pd xmm11, xmm13, xmm15
0000773e7dfda539  vcmppd xmm14, xmm11, xmm11, 0x03
0000773e7dfda53f  vptest xmm14, xmm14
0000773e7dfda544  jnz 0x0000773E7DFDCBD3
0000773e7dfda54a  lea rax, [r14+0x90]
0000773e7dfda551  movups xmm15, [r13+rax*1]
0000773e7dfda557  lea rax, [r14+0xA0]
0000773e7dfda55e  movups xmm14, [r13+rax*1]
0000773e7dfda564  movaps [r15+0x140], xmm15
0000773e7dfda56c  movaps [r15+0x130], xmm14
0000773e7dfda574  vmovaps xmm13, [rsp+0x10]
0000773e7dfda57a  vpermilpd xmm13, xmm13, 0x00
0000773e7dfda580  movaps xmm10, xmm8
0000773e7dfda584  vfmadd231pd xmm10, xmm1, xmm13
0000773e7dfda589  vcmppd xmm9, xmm10, xmm10, 0x03
0000773e7dfda58f  vptest xmm9, xmm9
0000773e7dfda594  jnz 0x0000773E7DFDCD41
0000773e7dfda59a  movaps [r15+0x220], xmm10
0000773e7dfda5a2  lea rax, [r14+0x10]
0000773e7dfda5a6  movups xmm1, [r13+rax*1]
0000773e7dfda5ac  movaps [r15+0x240], xmm1
0000773e7dfda5b4  vmovaps xmm13, [rsp+0x10]
0000773e7dfda5ba  vpermilpd xmm13, xmm13, 0x00
0000773e7dfda5c0  movaps xmm9, xmm7
0000773e7dfda5c4  vfmadd231pd xmm9, xmm14, xmm13
0000773e7dfda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
0000773e7dfda5cf  vptest xmm8, xmm8
0000773e7dfda5d4  jnz 0x0000773E7DFDCEA4
0000773e7dfda5da  movaps [r15+0x110], xmm9
0000773e7dfda5e2  vmovaps xmm14, [rsp+0x10]
0000773e7dfda5e8  vpermilpd xmm14, xmm14, 0x00
0000773e7dfda5ee  movaps xmm13, xmm12
0000773e7dfda5f2  vfmadd231pd xmm13, xmm15, xmm14
0000773e7dfda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
0000773e7dfda5fd  vptest xmm8, xmm8
0000773e7dfda602  jnz 0x0000773E7DFDCFFD
0000773e7dfda608  movaps [r15+0x170], xmm13
0000773e7dfda610  vmovaps xmm15, [rsp+0x10]
0000773e7dfda616  vpermilpd xmm15, xmm15, 0x00
0000773e7dfda61c  movaps xmm14, xmm11
0000773e7dfda620  vfmadd231pd xmm14, xmm1, xmm15
0000773e7dfda625  vcmppd xmm12, xmm14, xmm14, 0x03
0000773e7dfda62b  vptest xmm12, xmm12
0000773e7dfda630  jnz 0x0000773E7DFDD157
0000773e7dfda636  movaps [r15+0x230], xmm14
0000773e7dfda63e  mov rax, [rsp+0xD0]
0000773e7dfda646  movups [r13+rax*1], xmm9
0000773e7dfda64c  lea r14, [rax+0x10]
0000773e7dfda650  movups [r13+r14*1], xmm13
0000773e7dfda656  lea r14, [rax+0x20]
0000773e7dfda65a  movups [r13+r14*1], xmm10
0000773e7dfda660  lea r14, [rax+0x30]
0000773e7dfda664  movups [r13+r14*1], xmm14
0000773e7dfda66a  mov eax, [r15+0x108]
0000773e7dfda671  sahf
0000773e7dfda672  jnz 0x0000773E7DFDA6A4
0000773e7dfda674  cmp dword ptr [r15+0x318], 0x00
0000773e7dfda67c  jz 0x0000773E7DFD9950
0000773e7dfda682  nop [rax+rax*1], ax
0000773e7dfda68b  nop [rax+rax*1], eax
0000773e7dfda693  mov eax, 0x410664
0000773e7dfda698  mov [r15+0x100], rax
0000773e7dfda69f  jmp 0x0000773E7DDFE110
0000773e7dfda6a4  cmp dword ptr [r15+0x318], 0x00
0000773e7dfda6ac  jz 0x0000773E7DFD6050
0000773e7dfda6b2  nop [rax+rax*1], ax
0000773e7dfda6bb  nop [rax+rax*1], eax
0000773e7dfda6c3  mov eax, 0x4104F0
0000773e7dfda6c8  mov [r15+0x100], rax
0000773e7dfda6cf  jmp 0x0000773E7DDFE110
0000773e7dfda6d4  int3
0000773e7dfda6d5  call 0x0000773E7DEE27E0
0000773e7dfda6da  jmp 0x0000773E7DFD9A10
0000773e7dfda6df  call 0x0000773E7DEE1570
0000773e7dfda6e4  jmp 0x0000773E7DFD9A19
0000773e7dfda6e9  call 0x0000773E7DEE27E0
0000773e7dfda6ee  jmp 0x0000773E7DFD9A62
0000773e7dfda6f3  call 0x0000773E7DEE1570
0000773e7dfda6f8  jmp 0x0000773E7DFD9A6B
0000773e7dfda6fd  call 0x0000773E7DEE27E0
0000773e7dfda702  jmp 0x0000773E7DFD9AEB
0000773e7dfda707  call 0x0000773E7DEE1570
0000773e7dfda70c  jmp 0x0000773E7DFD9AF4
0000773e7dfda711  call 0x0000773E7DE0DC20
0000773e7dfda716  jmp 0x0000773E7DFD9BD5
0000773e7dfda71b  call 0x0000773E7DED64F0
0000773e7dfda720  jmp 0x0000773E7DFD9C04
0000773e7dfda725  call 0x0000773E7DEB47C0
0000773e7dfda72a  jmp 0x0000773E7DFD9C1F
0000773e7dfda72f  sub rsp, 0x08
0000773e7dfda733  push rax
0000773e7dfda734  push rcx
0000773e7dfda735  push rdx
0000773e7dfda736  push rdi
0000773e7dfda737  push rsi
0000773e7dfda738  push r8
0000773e7dfda73a  push r9
0000773e7dfda73c  push r10
0000773e7dfda73e  push r11
0000773e7dfda740  sub rsp, 0xF0
0000773e7dfda747  vmovaps [rsp], xmm0
0000773e7dfda74c  vmovaps [rsp+0x10], xmm1
0000773e7dfda752  vmovaps [rsp+0x20], xmm2
0000773e7dfda758  vmovaps [rsp+0x30], xmm3
0000773e7dfda75e  vmovaps [rsp+0x40], xmm4
0000773e7dfda764  vmovaps [rsp+0x50], xmm5
0000773e7dfda76a  vmovaps [rsp+0x60], xmm6
0000773e7dfda770  vmovaps [rsp+0x70], xmm7
0000773e7dfda776  vmovaps [rsp+0x80], xmm8
0000773e7dfda77f  vmovaps [rsp+0x90], xmm9
0000773e7dfda788  vmovaps [rsp+0xA0], xmm10
0000773e7dfda791  vmovaps [rsp+0xB0], xmm11
0000773e7dfda79a  vmovaps [rsp+0xC0], xmm12
0000773e7dfda7a3  vmovaps [rsp+0xD0], xmm14
0000773e7dfda7ac  vmovaps [rsp+0xE0], xmm15
0000773e7dfda7b5  sub rsp, 0x40
0000773e7dfda7b9  lea rdi, [rsp]
0000773e7dfda7bd  lea rsi, [rsp+0x10]
0000773e7dfda7c2  lea rdx, [rsp+0x20]
0000773e7dfda7c7  lea rcx, [rsp+0x30]
0000773e7dfda7cc  mov r8d, 0x00
0000773e7dfda7d2  lea r9, [r15+0x3A8]
0000773e7dfda7d9  movaps [rdi], xmm13
0000773e7dfda7dd  movaps [rsi], xmm1
0000773e7dfda7e0  movaps [rdx], xmm15
0000773e7dfda7e4  movaps [rcx], xmm14
0000773e7dfda7e8  mov rax, 0x567852F34A50
0000773e7dfda7f2  call rax
0000773e7dfda7f4  movaps xmm13, [rsp]
0000773e7dfda7f9  add rsp, 0x40
0000773e7dfda7fd  vmovaps xmm0, [rsp]
0000773e7dfda802  vmovaps xmm1, [rsp+0x10]
0000773e7dfda808  vmovaps xmm2, [rsp+0x20]
0000773e7dfda80e  vmovaps xmm3, [rsp+0x30]
0000773e7dfda814  vmovaps xmm4, [rsp+0x40]
0000773e7dfda81a  vmovaps xmm5, [rsp+0x50]
0000773e7dfda820  vmovaps xmm6, [rsp+0x60]
0000773e7dfda826  vmovaps xmm7, [rsp+0x70]
0000773e7dfda82c  vmovaps xmm8, [rsp+0x80]
0000773e7dfda835  vmovaps xmm9, [rsp+0x90]
0000773e7dfda83e  vmovaps xmm10, [rsp+0xA0]
0000773e7dfda847  vmovaps xmm11, [rsp+0xB0]
0000773e7dfda850  vmovaps xmm12, [rsp+0xC0]
0000773e7dfda859  vmovaps xmm14, [rsp+0xD0]
0000773e7dfda862  vmovaps xmm15, [rsp+0xE0]
0000773e7dfda86b  add rsp, 0xF0
0000773e7dfda872  pop r11
0000773e7dfda874  pop r10
0000773e7dfda876  pop r9
0000773e7dfda878  pop r8
0000773e7dfda87a  pop rsi
0000773e7dfda87b  pop rdi
0000773e7dfda87c  pop rdx
0000773e7dfda87d  pop rcx
0000773e7dfda87e  pop rax
0000773e7dfda87f  add rsp, 0x08
0000773e7dfda883  jmp 0x0000773E7DFD9C92
0000773e7dfda888  sub rsp, 0x08
0000773e7dfda88c  push rax
0000773e7dfda88d  push rcx
0000773e7dfda88e  push rdx
0000773e7dfda88f  push rdi
0000773e7dfda890  push rsi
0000773e7dfda891  push r8
0000773e7dfda893  push r9
0000773e7dfda895  push r10
0000773e7dfda897  push r11
0000773e7dfda899  sub rsp, 0xF0
0000773e7dfda8a0  vmovaps [rsp], xmm0
0000773e7dfda8a5  vmovaps [rsp+0x10], xmm1
0000773e7dfda8ab  vmovaps [rsp+0x20], xmm2
0000773e7dfda8b1  vmovaps [rsp+0x30], xmm3
0000773e7dfda8b7  vmovaps [rsp+0x40], xmm4
0000773e7dfda8bd  vmovaps [rsp+0x50], xmm5
0000773e7dfda8c3  vmovaps [rsp+0x60], xmm6
0000773e7dfda8c9  vmovaps [rsp+0x70], xmm7
0000773e7dfda8cf  vmovaps [rsp+0x80], xmm8
0000773e7dfda8d8  vmovaps [rsp+0x90], xmm9
0000773e7dfda8e1  vmovaps [rsp+0xA0], xmm10
0000773e7dfda8ea  vmovaps [rsp+0xB0], xmm11
0000773e7dfda8f3  vmovaps [rsp+0xC0], xmm13
0000773e7dfda8fc  vmovaps [rsp+0xD0], xmm14
0000773e7dfda905  vmovaps [rsp+0xE0], xmm15
0000773e7dfda90e  sub rsp, 0x40
0000773e7dfda912  lea rdi, [rsp]
0000773e7dfda916  lea rsi, [rsp+0x10]
0000773e7dfda91b  lea rdx, [rsp+0x20]
0000773e7dfda920  lea rcx, [rsp+0x30]
0000773e7dfda925  mov r8d, 0x00
0000773e7dfda92b  lea r9, [r15+0x3A8]
0000773e7dfda932  movaps [rdi], xmm12
0000773e7dfda936  movaps [rsi], xmm15
0000773e7dfda93a  movaps [rdx], xmm1
0000773e7dfda93d  movaps [rcx], xmm14
0000773e7dfda941  mov rax, 0x567852F34A50
0000773e7dfda94b  call rax
0000773e7dfda94d  movaps xmm12, [rsp]
0000773e7dfda952  add rsp, 0x40
0000773e7dfda956  vmovaps xmm0, [rsp]
0000773e7dfda95b  vmovaps xmm1, [rsp+0x10]
0000773e7dfda961  vmovaps xmm2, [rsp+0x20]
0000773e7dfda967  vmovaps xmm3, [rsp+0x30]
0000773e7dfda96d  vmovaps xmm4, [rsp+0x40]
0000773e7dfda973  vmovaps xmm5, [rsp+0x50]
0000773e7dfda979  vmovaps xmm6, [rsp+0x60]
0000773e7dfda97f  vmovaps xmm7, [rsp+0x70]
0000773e7dfda985  vmovaps xmm8, [rsp+0x80]
0000773e7dfda98e  vmovaps xmm9, [rsp+0x90]
0000773e7dfda997  vmovaps xmm10, [rsp+0xA0]
0000773e7dfda9a0  vmovaps xmm11, [rsp+0xB0]
0000773e7dfda9a9  vmovaps xmm13, [rsp+0xC0]
0000773e7dfda9b2  vmovaps xmm14, [rsp+0xD0]
0000773e7dfda9bb  vmovaps xmm15, [rsp+0xE0]
0000773e7dfda9c4  add rsp, 0xF0
0000773e7dfda9cb  pop r11
0000773e7dfda9cd  pop r10
0000773e7dfda9cf  pop r9
0000773e7dfda9d1  pop r8
0000773e7dfda9d3  pop rsi
0000773e7dfda9d4  pop rdi
0000773e7dfda9d5  pop rdx
0000773e7dfda9d6  pop rcx
0000773e7dfda9d7  pop rax
0000773e7dfda9d8  add rsp, 0x08
0000773e7dfda9dc  jmp 0x0000773E7DFD9CC0
0000773e7dfda9e1  call 0x0000773E7DEB52F0
0000773e7dfda9e6  jmp 0x0000773E7DFD9DAC
0000773e7dfda9eb  sub rsp, 0x08
0000773e7dfda9ef  push rax
0000773e7dfda9f0  push rcx
0000773e7dfda9f1  push rdx
0000773e7dfda9f2  push rdi
0000773e7dfda9f3  push rsi
0000773e7dfda9f4  push r8
0000773e7dfda9f6  push r9
0000773e7dfda9f8  push r10
0000773e7dfda9fa  push r11
0000773e7dfda9fc  sub rsp, 0xF0
0000773e7dfdaa03  vmovaps [rsp], xmm0
0000773e7dfdaa08  vmovaps [rsp+0x10], xmm1
0000773e7dfdaa0e  vmovaps [rsp+0x20], xmm2
0000773e7dfdaa14  vmovaps [rsp+0x30], xmm3
0000773e7dfdaa1a  vmovaps [rsp+0x40], xmm4
0000773e7dfdaa20  vmovaps [rsp+0x50], xmm5
0000773e7dfdaa26  vmovaps [rsp+0x60], xmm6
0000773e7dfdaa2c  vmovaps [rsp+0x70], xmm7
0000773e7dfdaa32  vmovaps [rsp+0x80], xmm8
0000773e7dfdaa3b  vmovaps [rsp+0x90], xmm9
0000773e7dfdaa44  vmovaps [rsp+0xA0], xmm10
0000773e7dfdaa4d  vmovaps [rsp+0xB0], xmm11
0000773e7dfdaa56  vmovaps [rsp+0xC0], xmm12
0000773e7dfdaa5f  vmovaps [rsp+0xD0], xmm14
0000773e7dfdaa68  vmovaps [rsp+0xE0], xmm15
0000773e7dfdaa71  sub rsp, 0x40
0000773e7dfdaa75  lea rdi, [rsp]
0000773e7dfdaa79  lea rsi, [rsp+0x10]
0000773e7dfdaa7e  lea rdx, [rsp+0x20]
0000773e7dfdaa83  lea rcx, [rsp+0x30]
0000773e7dfdaa88  mov r8d, 0x00
0000773e7dfdaa8e  lea r9, [r15+0x3A8]
0000773e7dfdaa95  movaps [rdi], xmm13
0000773e7dfdaa99  movaps [rsi], xmm1
0000773e7dfdaa9c  movaps [rdx], xmm15
0000773e7dfdaaa0  movaps [rcx], xmm14
0000773e7dfdaaa4  mov rax, 0x567852F34A50
0000773e7dfdaaae  call rax
0000773e7dfdaab0  movaps xmm13, [rsp]
0000773e7dfdaab5  add rsp, 0x40
0000773e7dfdaab9  vmovaps xmm0, [rsp]
0000773e7dfdaabe  vmovaps xmm1, [rsp+0x10]
0000773e7dfdaac4  vmovaps xmm2, [rsp+0x20]
0000773e7dfdaaca  vmovaps xmm3, [rsp+0x30]
0000773e7dfdaad0  vmovaps xmm4, [rsp+0x40]
0000773e7dfdaad6  vmovaps xmm5, [rsp+0x50]
0000773e7dfdaadc  vmovaps xmm6, [rsp+0x60]
0000773e7dfdaae2  vmovaps xmm7, [rsp+0x70]
0000773e7dfdaae8  vmovaps xmm8, [rsp+0x80]
0000773e7dfdaaf1  vmovaps xmm9, [rsp+0x90]
0000773e7dfdaafa  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdab03  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdab0c  vmovaps xmm12, [rsp+0xC0]
0000773e7dfdab15  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdab1e  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdab27  add rsp, 0xF0
0000773e7dfdab2e  pop r11
0000773e7dfdab30  pop r10
0000773e7dfdab32  pop r9
0000773e7dfdab34  pop r8
0000773e7dfdab36  pop rsi
0000773e7dfdab37  pop rdi
0000773e7dfdab38  pop rdx
0000773e7dfdab39  pop rcx
0000773e7dfdab3a  pop rax
0000773e7dfdab3b  add rsp, 0x08
0000773e7dfdab3f  jmp 0x0000773E7DFD9E21
0000773e7dfdab44  call 0x0000773E7DDFF430
0000773e7dfdab49  jmp 0x0000773E7DFD9E2E
0000773e7dfdab4e  sub rsp, 0x08
0000773e7dfdab52  push rax
0000773e7dfdab53  push rcx
0000773e7dfdab54  push rdx
0000773e7dfdab55  push rdi
0000773e7dfdab56  push rsi
0000773e7dfdab57  push r8
0000773e7dfdab59  push r9
0000773e7dfdab5b  push r10
0000773e7dfdab5d  push r11
0000773e7dfdab5f  sub rsp, 0xF0
0000773e7dfdab66  vmovaps [rsp], xmm0
0000773e7dfdab6b  vmovaps [rsp+0x10], xmm1
0000773e7dfdab71  vmovaps [rsp+0x20], xmm2
0000773e7dfdab77  vmovaps [rsp+0x30], xmm3
0000773e7dfdab7d  vmovaps [rsp+0x40], xmm4
0000773e7dfdab83  vmovaps [rsp+0x50], xmm5
0000773e7dfdab89  vmovaps [rsp+0x60], xmm6
0000773e7dfdab8f  vmovaps [rsp+0x70], xmm7
0000773e7dfdab95  vmovaps [rsp+0x80], xmm8
0000773e7dfdab9e  vmovaps [rsp+0x90], xmm9
0000773e7dfdaba7  vmovaps [rsp+0xA0], xmm10
0000773e7dfdabb0  vmovaps [rsp+0xB0], xmm11
0000773e7dfdabb9  vmovaps [rsp+0xC0], xmm13
0000773e7dfdabc2  vmovaps [rsp+0xD0], xmm14
0000773e7dfdabcb  vmovaps [rsp+0xE0], xmm15
0000773e7dfdabd4  sub rsp, 0x40
0000773e7dfdabd8  lea rdi, [rsp]
0000773e7dfdabdc  lea rsi, [rsp+0x10]
0000773e7dfdabe1  lea rdx, [rsp+0x20]
0000773e7dfdabe6  lea rcx, [rsp+0x30]
0000773e7dfdabeb  mov r8d, 0x00
0000773e7dfdabf1  lea r9, [r15+0x3A8]
0000773e7dfdabf8  movaps [rdi], xmm12
0000773e7dfdabfc  movaps [rsi], xmm15
0000773e7dfdac00  movaps [rdx], xmm1
0000773e7dfdac03  movaps [rcx], xmm14
0000773e7dfdac07  mov rax, 0x567852F34A50
0000773e7dfdac11  call rax
0000773e7dfdac13  movaps xmm12, [rsp]
0000773e7dfdac18  add rsp, 0x40
0000773e7dfdac1c  vmovaps xmm0, [rsp]
0000773e7dfdac21  vmovaps xmm1, [rsp+0x10]
0000773e7dfdac27  vmovaps xmm2, [rsp+0x20]
0000773e7dfdac2d  vmovaps xmm3, [rsp+0x30]
0000773e7dfdac33  vmovaps xmm4, [rsp+0x40]
0000773e7dfdac39  vmovaps xmm5, [rsp+0x50]
0000773e7dfdac3f  vmovaps xmm6, [rsp+0x60]
0000773e7dfdac45  vmovaps xmm7, [rsp+0x70]
0000773e7dfdac4b  vmovaps xmm8, [rsp+0x80]
0000773e7dfdac54  vmovaps xmm9, [rsp+0x90]
0000773e7dfdac5d  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdac66  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdac6f  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdac78  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdac81  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdac8a  add rsp, 0xF0
0000773e7dfdac91  pop r11
0000773e7dfdac93  pop r10
0000773e7dfdac95  pop r9
0000773e7dfdac97  pop r8
0000773e7dfdac99  pop rsi
0000773e7dfdac9a  pop rdi
0000773e7dfdac9b  pop rdx
0000773e7dfdac9c  pop rcx
0000773e7dfdac9d  pop rax
0000773e7dfdac9e  add rsp, 0x08
0000773e7dfdaca2  jmp 0x0000773E7DFD9E5A
0000773e7dfdaca7  sub rsp, 0x08
0000773e7dfdacab  push rax
0000773e7dfdacac  push rcx
0000773e7dfdacad  push rdx
0000773e7dfdacae  push rdi
0000773e7dfdacaf  push rsi
0000773e7dfdacb0  push r8
0000773e7dfdacb2  push r9
0000773e7dfdacb4  push r10
0000773e7dfdacb6  push r11
0000773e7dfdacb8  sub rsp, 0xF0
0000773e7dfdacbf  vmovaps [rsp], xmm0
0000773e7dfdacc4  vmovaps [rsp+0x10], xmm1
0000773e7dfdacca  vmovaps [rsp+0x20], xmm2
0000773e7dfdacd0  vmovaps [rsp+0x30], xmm3
0000773e7dfdacd6  vmovaps [rsp+0x40], xmm4
0000773e7dfdacdc  vmovaps [rsp+0x50], xmm5
0000773e7dfdace2  vmovaps [rsp+0x60], xmm6
0000773e7dfdace8  vmovaps [rsp+0x70], xmm7
0000773e7dfdacee  vmovaps [rsp+0x80], xmm8
0000773e7dfdacf7  vmovaps [rsp+0x90], xmm9
0000773e7dfdad00  vmovaps [rsp+0xA0], xmm10
0000773e7dfdad09  vmovaps [rsp+0xB0], xmm11
0000773e7dfdad12  vmovaps [rsp+0xC0], xmm12
0000773e7dfdad1b  vmovaps [rsp+0xD0], xmm14
0000773e7dfdad24  vmovaps [rsp+0xE0], xmm15
0000773e7dfdad2d  sub rsp, 0x40
0000773e7dfdad31  lea rdi, [rsp]
0000773e7dfdad35  lea rsi, [rsp+0x10]
0000773e7dfdad3a  lea rdx, [rsp+0x20]
0000773e7dfdad3f  lea rcx, [rsp+0x30]
0000773e7dfdad44  mov r8d, 0x00
0000773e7dfdad4a  lea r9, [r15+0x3A8]
0000773e7dfdad51  movaps [rdi], xmm13
0000773e7dfdad55  movaps [rsi], xmm1
0000773e7dfdad58  movaps [rdx], xmm15
0000773e7dfdad5c  movaps [rcx], xmm14
0000773e7dfdad60  mov rax, 0x567852F34A50
0000773e7dfdad6a  call rax
0000773e7dfdad6c  movaps xmm13, [rsp]
0000773e7dfdad71  add rsp, 0x40
0000773e7dfdad75  vmovaps xmm0, [rsp]
0000773e7dfdad7a  vmovaps xmm1, [rsp+0x10]
0000773e7dfdad80  vmovaps xmm2, [rsp+0x20]
0000773e7dfdad86  vmovaps xmm3, [rsp+0x30]
0000773e7dfdad8c  vmovaps xmm4, [rsp+0x40]
0000773e7dfdad92  vmovaps xmm5, [rsp+0x50]
0000773e7dfdad98  vmovaps xmm6, [rsp+0x60]
0000773e7dfdad9e  vmovaps xmm7, [rsp+0x70]
0000773e7dfdada4  vmovaps xmm8, [rsp+0x80]
0000773e7dfdadad  vmovaps xmm9, [rsp+0x90]
0000773e7dfdadb6  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdadbf  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdadc8  vmovaps xmm12, [rsp+0xC0]
0000773e7dfdadd1  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdadda  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdade3  add rsp, 0xF0
0000773e7dfdadea  pop r11
0000773e7dfdadec  pop r10
0000773e7dfdadee  pop r9
0000773e7dfdadf0  pop r8
0000773e7dfdadf2  pop rsi
0000773e7dfdadf3  pop rdi
0000773e7dfdadf4  pop rdx
0000773e7dfdadf5  pop rcx
0000773e7dfdadf6  pop rax
0000773e7dfdadf7  add rsp, 0x08
0000773e7dfdadfb  jmp 0x0000773E7DFD9FEA
0000773e7dfdae00  sub rsp, 0x08
0000773e7dfdae04  push rax
0000773e7dfdae05  push rcx
0000773e7dfdae06  push rdx
0000773e7dfdae07  push rdi
0000773e7dfdae08  push rsi
0000773e7dfdae09  push r8
0000773e7dfdae0b  push r9
0000773e7dfdae0d  push r10
0000773e7dfdae0f  push r11
0000773e7dfdae11  sub rsp, 0xF0
0000773e7dfdae18  vmovaps [rsp], xmm0
0000773e7dfdae1d  vmovaps [rsp+0x10], xmm1
0000773e7dfdae23  vmovaps [rsp+0x20], xmm2
0000773e7dfdae29  vmovaps [rsp+0x30], xmm3
0000773e7dfdae2f  vmovaps [rsp+0x40], xmm4
0000773e7dfdae35  vmovaps [rsp+0x50], xmm5
0000773e7dfdae3b  vmovaps [rsp+0x60], xmm6
0000773e7dfdae41  vmovaps [rsp+0x70], xmm7
0000773e7dfdae47  vmovaps [rsp+0x80], xmm8
0000773e7dfdae50  vmovaps [rsp+0x90], xmm9
0000773e7dfdae59  vmovaps [rsp+0xA0], xmm10
0000773e7dfdae62  vmovaps [rsp+0xB0], xmm11
0000773e7dfdae6b  vmovaps [rsp+0xC0], xmm12
0000773e7dfdae74  vmovaps [rsp+0xD0], xmm13
0000773e7dfdae7d  vmovaps [rsp+0xE0], xmm15
0000773e7dfdae86  sub rsp, 0x40
0000773e7dfdae8a  lea rdi, [rsp]
0000773e7dfdae8e  lea rsi, [rsp+0x10]
0000773e7dfdae93  lea rdx, [rsp+0x20]
0000773e7dfdae98  lea rcx, [rsp+0x30]
0000773e7dfdae9d  mov r8d, 0x00
0000773e7dfdaea3  lea r9, [r15+0x3A8]
0000773e7dfdaeaa  movaps [rdi], xmm14
0000773e7dfdaeae  movaps [rsi], xmm15
0000773e7dfdaeb2  movaps [rdx], xmm2
0000773e7dfdaeb5  movaps [rcx], xmm1
0000773e7dfdaeb8  mov rax, 0x567852F34A50
0000773e7dfdaec2  call rax
0000773e7dfdaec4  movaps xmm14, [rsp]
0000773e7dfdaec9  add rsp, 0x40
0000773e7dfdaecd  vmovaps xmm0, [rsp]
0000773e7dfdaed2  vmovaps xmm1, [rsp+0x10]
0000773e7dfdaed8  vmovaps xmm2, [rsp+0x20]
0000773e7dfdaede  vmovaps xmm3, [rsp+0x30]
0000773e7dfdaee4  vmovaps xmm4, [rsp+0x40]
0000773e7dfdaeea  vmovaps xmm5, [rsp+0x50]
0000773e7dfdaef0  vmovaps xmm6, [rsp+0x60]
0000773e7dfdaef6  vmovaps xmm7, [rsp+0x70]
0000773e7dfdaefc  vmovaps xmm8, [rsp+0x80]
0000773e7dfdaf05  vmovaps xmm9, [rsp+0x90]
0000773e7dfdaf0e  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdaf17  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdaf20  vmovaps xmm12, [rsp+0xC0]
0000773e7dfdaf29  vmovaps xmm13, [rsp+0xD0]
0000773e7dfdaf32  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdaf3b  add rsp, 0xF0
0000773e7dfdaf42  pop r11
0000773e7dfdaf44  pop r10
0000773e7dfdaf46  pop r9
0000773e7dfdaf48  pop r8
0000773e7dfdaf4a  pop rsi
0000773e7dfdaf4b  pop rdi
0000773e7dfdaf4c  pop rdx
0000773e7dfdaf4d  pop rcx
0000773e7dfdaf4e  pop rax
0000773e7dfdaf4f  add rsp, 0x08
0000773e7dfdaf53  jmp 0x0000773E7DFDA01C
0000773e7dfdaf58  sub rsp, 0x08
0000773e7dfdaf5c  push rax
0000773e7dfdaf5d  push rcx
0000773e7dfdaf5e  push rdx
0000773e7dfdaf5f  push rdi
0000773e7dfdaf60  push rsi
0000773e7dfdaf61  push r8
0000773e7dfdaf63  push r9
0000773e7dfdaf65  push r10
0000773e7dfdaf67  push r11
0000773e7dfdaf69  sub rsp, 0xF0
0000773e7dfdaf70  vmovaps [rsp], xmm0
0000773e7dfdaf75  vmovaps [rsp+0x10], xmm1
0000773e7dfdaf7b  vmovaps [rsp+0x20], xmm3
0000773e7dfdaf81  vmovaps [rsp+0x30], xmm4
0000773e7dfdaf87  vmovaps [rsp+0x40], xmm5
0000773e7dfdaf8d  vmovaps [rsp+0x50], xmm6
0000773e7dfdaf93  vmovaps [rsp+0x60], xmm7
0000773e7dfdaf99  vmovaps [rsp+0x70], xmm8
0000773e7dfdaf9f  vmovaps [rsp+0x80], xmm9
0000773e7dfdafa8  vmovaps [rsp+0x90], xmm10
0000773e7dfdafb1  vmovaps [rsp+0xA0], xmm11
0000773e7dfdafba  vmovaps [rsp+0xB0], xmm12
0000773e7dfdafc3  vmovaps [rsp+0xC0], xmm13
0000773e7dfdafcc  vmovaps [rsp+0xD0], xmm14
0000773e7dfdafd5  vmovaps [rsp+0xE0], xmm15
0000773e7dfdafde  sub rsp, 0x40
0000773e7dfdafe2  lea rdi, [rsp]
0000773e7dfdafe6  lea rsi, [rsp+0x10]
0000773e7dfdafeb  lea rdx, [rsp+0x20]
0000773e7dfdaff0  lea rcx, [rsp+0x30]
0000773e7dfdaff5  mov r8d, 0x00
0000773e7dfdaffb  lea r9, [r15+0x3A8]
0000773e7dfdb002  movaps [rdi], xmm2
0000773e7dfdb005  movaps [rsi], xmm15
0000773e7dfdb009  movaps [rdx], xmm12
0000773e7dfdb00d  movaps [rcx], xmm1
0000773e7dfdb010  mov rax, 0x567852F34A50
0000773e7dfdb01a  call rax
0000773e7dfdb01c  movaps xmm2, [rsp]
0000773e7dfdb020  add rsp, 0x40
0000773e7dfdb024  vmovaps xmm0, [rsp]
0000773e7dfdb029  vmovaps xmm1, [rsp+0x10]
0000773e7dfdb02f  vmovaps xmm3, [rsp+0x20]
0000773e7dfdb035  vmovaps xmm4, [rsp+0x30]
0000773e7dfdb03b  vmovaps xmm5, [rsp+0x40]
0000773e7dfdb041  vmovaps xmm6, [rsp+0x50]
0000773e7dfdb047  vmovaps xmm7, [rsp+0x60]
0000773e7dfdb04d  vmovaps xmm8, [rsp+0x70]
0000773e7dfdb053  vmovaps xmm9, [rsp+0x80]
0000773e7dfdb05c  vmovaps xmm10, [rsp+0x90]
0000773e7dfdb065  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdb06e  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdb077  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdb080  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdb089  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdb092  add rsp, 0xF0
0000773e7dfdb099  pop r11
0000773e7dfdb09b  pop r10
0000773e7dfdb09d  pop r9
0000773e7dfdb09f  pop r8
0000773e7dfdb0a1  pop rsi
0000773e7dfdb0a2  pop rdi
0000773e7dfdb0a3  pop rdx
0000773e7dfdb0a4  pop rcx
0000773e7dfdb0a5  pop rax
0000773e7dfdb0a6  add rsp, 0x08
0000773e7dfdb0aa  jmp 0x0000773E7DFDA059
0000773e7dfdb0af  sub rsp, 0x08
0000773e7dfdb0b3  push rax
0000773e7dfdb0b4  push rcx
0000773e7dfdb0b5  push rdx
0000773e7dfdb0b6  push rdi
0000773e7dfdb0b7  push rsi
0000773e7dfdb0b8  push r8
0000773e7dfdb0ba  push r9
0000773e7dfdb0bc  push r10
0000773e7dfdb0be  push r11
0000773e7dfdb0c0  sub rsp, 0xF0
0000773e7dfdb0c7  vmovaps [rsp], xmm0
0000773e7dfdb0cc  vmovaps [rsp+0x10], xmm1
0000773e7dfdb0d2  vmovaps [rsp+0x20], xmm2
0000773e7dfdb0d8  vmovaps [rsp+0x30], xmm3
0000773e7dfdb0de  vmovaps [rsp+0x40], xmm4
0000773e7dfdb0e4  vmovaps [rsp+0x50], xmm5
0000773e7dfdb0ea  vmovaps [rsp+0x60], xmm6
0000773e7dfdb0f0  vmovaps [rsp+0x70], xmm7
0000773e7dfdb0f6  vmovaps [rsp+0x80], xmm8
0000773e7dfdb0ff  vmovaps [rsp+0x90], xmm9
0000773e7dfdb108  vmovaps [rsp+0xA0], xmm10
0000773e7dfdb111  vmovaps [rsp+0xB0], xmm11
0000773e7dfdb11a  vmovaps [rsp+0xC0], xmm13
0000773e7dfdb123  vmovaps [rsp+0xD0], xmm14
0000773e7dfdb12c  vmovaps [rsp+0xE0], xmm15
0000773e7dfdb135  sub rsp, 0x40
0000773e7dfdb139  lea rdi, [rsp]
0000773e7dfdb13d  lea rsi, [rsp+0x10]
0000773e7dfdb142  lea rdx, [rsp+0x20]
0000773e7dfdb147  lea rcx, [rsp+0x30]
0000773e7dfdb14c  mov r8d, 0x00
0000773e7dfdb152  lea r9, [r15+0x3A8]
0000773e7dfdb159  movaps [rdi], xmm12
0000773e7dfdb15d  movaps [rsi], xmm14
0000773e7dfdb161  movaps [rdx], xmm3
0000773e7dfdb164  movaps [rcx], xmm15
0000773e7dfdb168  mov rax, 0x567852F34A50
0000773e7dfdb172  call rax
0000773e7dfdb174  movaps xmm12, [rsp]
0000773e7dfdb179  add rsp, 0x40
0000773e7dfdb17d  vmovaps xmm0, [rsp]
0000773e7dfdb182  vmovaps xmm1, [rsp+0x10]
0000773e7dfdb188  vmovaps xmm2, [rsp+0x20]
0000773e7dfdb18e  vmovaps xmm3, [rsp+0x30]
0000773e7dfdb194  vmovaps xmm4, [rsp+0x40]
0000773e7dfdb19a  vmovaps xmm5, [rsp+0x50]
0000773e7dfdb1a0  vmovaps xmm6, [rsp+0x60]
0000773e7dfdb1a6  vmovaps xmm7, [rsp+0x70]
0000773e7dfdb1ac  vmovaps xmm8, [rsp+0x80]
0000773e7dfdb1b5  vmovaps xmm9, [rsp+0x90]
0000773e7dfdb1be  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdb1c7  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdb1d0  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdb1d9  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdb1e2  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdb1eb  add rsp, 0xF0
0000773e7dfdb1f2  pop r11
0000773e7dfdb1f4  pop r10
0000773e7dfdb1f6  pop r9
0000773e7dfdb1f8  pop r8
0000773e7dfdb1fa  pop rsi
0000773e7dfdb1fb  pop rdi
0000773e7dfdb1fc  pop rdx
0000773e7dfdb1fd  pop rcx
0000773e7dfdb1fe  pop rax
0000773e7dfdb1ff  add rsp, 0x08
0000773e7dfdb203  jmp 0x0000773E7DFDA0B3
0000773e7dfdb208  sub rsp, 0x08
0000773e7dfdb20c  push rax
0000773e7dfdb20d  push rcx
0000773e7dfdb20e  push rdx
0000773e7dfdb20f  push rdi
0000773e7dfdb210  push rsi
0000773e7dfdb211  push r8
0000773e7dfdb213  push r9
0000773e7dfdb215  push r10
0000773e7dfdb217  push r11
0000773e7dfdb219  sub rsp, 0xF0
0000773e7dfdb220  vmovaps [rsp], xmm0
0000773e7dfdb225  vmovaps [rsp+0x10], xmm1
0000773e7dfdb22b  vmovaps [rsp+0x20], xmm2
0000773e7dfdb231  vmovaps [rsp+0x30], xmm3
0000773e7dfdb237  vmovaps [rsp+0x40], xmm4
0000773e7dfdb23d  vmovaps [rsp+0x50], xmm5
0000773e7dfdb243  vmovaps [rsp+0x60], xmm6
0000773e7dfdb249  vmovaps [rsp+0x70], xmm7
0000773e7dfdb24f  vmovaps [rsp+0x80], xmm8
0000773e7dfdb258  vmovaps [rsp+0x90], xmm10
0000773e7dfdb261  vmovaps [rsp+0xA0], xmm11
0000773e7dfdb26a  vmovaps [rsp+0xB0], xmm12
0000773e7dfdb273  vmovaps [rsp+0xC0], xmm13
0000773e7dfdb27c  vmovaps [rsp+0xD0], xmm14
0000773e7dfdb285  vmovaps [rsp+0xE0], xmm15
0000773e7dfdb28e  sub rsp, 0x40
0000773e7dfdb292  lea rdi, [rsp]
0000773e7dfdb296  lea rsi, [rsp+0x10]
0000773e7dfdb29b  lea rdx, [rsp+0x20]
0000773e7dfdb2a0  lea rcx, [rsp+0x30]
0000773e7dfdb2a5  mov r8d, 0x00
0000773e7dfdb2ab  lea r9, [r15+0x3A8]
0000773e7dfdb2b2  movaps [rdi], xmm9
0000773e7dfdb2b6  movaps [rsi], xmm13
0000773e7dfdb2ba  movaps [rdx], xmm14
0000773e7dfdb2be  movaps [rcx], xmm6
0000773e7dfdb2c1  mov rax, 0x567852F34A50
0000773e7dfdb2cb  call rax
0000773e7dfdb2cd  movaps xmm9, [rsp]
0000773e7dfdb2d2  add rsp, 0x40
0000773e7dfdb2d6  vmovaps xmm0, [rsp]
0000773e7dfdb2db  vmovaps xmm1, [rsp+0x10]
0000773e7dfdb2e1  vmovaps xmm2, [rsp+0x20]
0000773e7dfdb2e7  vmovaps xmm3, [rsp+0x30]
0000773e7dfdb2ed  vmovaps xmm4, [rsp+0x40]
0000773e7dfdb2f3  vmovaps xmm5, [rsp+0x50]
0000773e7dfdb2f9  vmovaps xmm6, [rsp+0x60]
0000773e7dfdb2ff  vmovaps xmm7, [rsp+0x70]
0000773e7dfdb305  vmovaps xmm8, [rsp+0x80]
0000773e7dfdb30e  vmovaps xmm10, [rsp+0x90]
0000773e7dfdb317  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdb320  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdb329  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdb332  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdb33b  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdb344  add rsp, 0xF0
0000773e7dfdb34b  pop r11
0000773e7dfdb34d  pop r10
0000773e7dfdb34f  pop r9
0000773e7dfdb351  pop r8
0000773e7dfdb353  pop rsi
0000773e7dfdb354  pop rdi
0000773e7dfdb355  pop rdx
0000773e7dfdb356  pop rcx
0000773e7dfdb357  pop rax
0000773e7dfdb358  add rsp, 0x08
0000773e7dfdb35c  jmp 0x0000773E7DFDA15D
0000773e7dfdb361  sub rsp, 0x08
0000773e7dfdb365  push rax
0000773e7dfdb366  push rcx
0000773e7dfdb367  push rdx
0000773e7dfdb368  push rdi
0000773e7dfdb369  push rsi
0000773e7dfdb36a  push r8
0000773e7dfdb36c  push r9
0000773e7dfdb36e  push r10
0000773e7dfdb370  push r11
0000773e7dfdb372  sub rsp, 0xF0
0000773e7dfdb379  vmovaps [rsp], xmm0
0000773e7dfdb37e  vmovaps [rsp+0x10], xmm1
0000773e7dfdb384  vmovaps [rsp+0x20], xmm2
0000773e7dfdb38a  vmovaps [rsp+0x30], xmm4
0000773e7dfdb390  vmovaps [rsp+0x40], xmm5
0000773e7dfdb396  vmovaps [rsp+0x50], xmm6
0000773e7dfdb39c  vmovaps [rsp+0x60], xmm7
0000773e7dfdb3a2  vmovaps [rsp+0x70], xmm8
0000773e7dfdb3a8  vmovaps [rsp+0x80], xmm9
0000773e7dfdb3b1  vmovaps [rsp+0x90], xmm10
0000773e7dfdb3ba  vmovaps [rsp+0xA0], xmm11
0000773e7dfdb3c3  vmovaps [rsp+0xB0], xmm12
0000773e7dfdb3cc  vmovaps [rsp+0xC0], xmm13
0000773e7dfdb3d5  vmovaps [rsp+0xD0], xmm14
0000773e7dfdb3de  vmovaps [rsp+0xE0], xmm15
0000773e7dfdb3e7  sub rsp, 0x40
0000773e7dfdb3eb  lea rdi, [rsp]
0000773e7dfdb3ef  lea rsi, [rsp+0x10]
0000773e7dfdb3f4  lea rdx, [rsp+0x20]
0000773e7dfdb3f9  lea rcx, [rsp+0x30]
0000773e7dfdb3fe  mov r8d, 0x00
0000773e7dfdb404  lea r9, [r15+0x3A8]
0000773e7dfdb40b  movaps [rdi], xmm3
0000773e7dfdb40e  movaps [rsi], xmm13
0000773e7dfdb412  movaps [rdx], xmm6
0000773e7dfdb415  movaps [rcx], xmm14
0000773e7dfdb419  mov rax, 0x567852F34A50
0000773e7dfdb423  call rax
0000773e7dfdb425  movaps xmm3, [rsp]
0000773e7dfdb429  add rsp, 0x40
0000773e7dfdb42d  vmovaps xmm0, [rsp]
0000773e7dfdb432  vmovaps xmm1, [rsp+0x10]
0000773e7dfdb438  vmovaps xmm2, [rsp+0x20]
0000773e7dfdb43e  vmovaps xmm4, [rsp+0x30]
0000773e7dfdb444  vmovaps xmm5, [rsp+0x40]
0000773e7dfdb44a  vmovaps xmm6, [rsp+0x50]
0000773e7dfdb450  vmovaps xmm7, [rsp+0x60]
0000773e7dfdb456  vmovaps xmm8, [rsp+0x70]
0000773e7dfdb45c  vmovaps xmm9, [rsp+0x80]
0000773e7dfdb465  vmovaps xmm10, [rsp+0x90]
0000773e7dfdb46e  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdb477  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdb480  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdb489  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdb492  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdb49b  add rsp, 0xF0
0000773e7dfdb4a2  pop r11
0000773e7dfdb4a4  pop r10
0000773e7dfdb4a6  pop r9
0000773e7dfdb4a8  pop r8
0000773e7dfdb4aa  pop rsi
0000773e7dfdb4ab  pop rdi
0000773e7dfdb4ac  pop rdx
0000773e7dfdb4ad  pop rcx
0000773e7dfdb4ae  pop rax
0000773e7dfdb4af  add rsp, 0x08
0000773e7dfdb4b3  jmp 0x0000773E7DFDA19A
0000773e7dfdb4b8  sub rsp, 0x08
0000773e7dfdb4bc  push rax
0000773e7dfdb4bd  push rcx
0000773e7dfdb4be  push rdx
0000773e7dfdb4bf  push rdi
0000773e7dfdb4c0  push rsi
0000773e7dfdb4c1  push r8
0000773e7dfdb4c3  push r9
0000773e7dfdb4c5  push r10
0000773e7dfdb4c7  push r11
0000773e7dfdb4c9  sub rsp, 0xF0
0000773e7dfdb4d0  vmovaps [rsp], xmm0
0000773e7dfdb4d5  vmovaps [rsp+0x10], xmm1
0000773e7dfdb4db  vmovaps [rsp+0x20], xmm2
0000773e7dfdb4e1  vmovaps [rsp+0x30], xmm3
0000773e7dfdb4e7  vmovaps [rsp+0x40], xmm4
0000773e7dfdb4ed  vmovaps [rsp+0x50], xmm5
0000773e7dfdb4f3  vmovaps [rsp+0x60], xmm7
0000773e7dfdb4f9  vmovaps [rsp+0x70], xmm8
0000773e7dfdb4ff  vmovaps [rsp+0x80], xmm9
0000773e7dfdb508  vmovaps [rsp+0x90], xmm10
0000773e7dfdb511  vmovaps [rsp+0xA0], xmm11
0000773e7dfdb51a  vmovaps [rsp+0xB0], xmm12
0000773e7dfdb523  vmovaps [rsp+0xC0], xmm13
0000773e7dfdb52c  vmovaps [rsp+0xD0], xmm14
0000773e7dfdb535  vmovaps [rsp+0xE0], xmm15
0000773e7dfdb53e  sub rsp, 0x40
0000773e7dfdb542  lea rdi, [rsp]
0000773e7dfdb546  lea rsi, [rsp+0x10]
0000773e7dfdb54b  lea rdx, [rsp+0x20]
0000773e7dfdb550  lea rcx, [rsp+0x30]
0000773e7dfdb555  mov r8d, 0x00
0000773e7dfdb55b  lea r9, [r15+0x3A8]
0000773e7dfdb562  movaps [rdi], xmm6
0000773e7dfdb565  movaps [rsi], xmm2
0000773e7dfdb568  movaps [rdx], xmm14
0000773e7dfdb56c  movaps [rcx], xmm1
0000773e7dfdb56f  mov rax, 0x567852F34A50
0000773e7dfdb579  call rax
0000773e7dfdb57b  movaps xmm6, [rsp]
0000773e7dfdb57f  add rsp, 0x40
0000773e7dfdb583  vmovaps xmm0, [rsp]
0000773e7dfdb588  vmovaps xmm1, [rsp+0x10]
0000773e7dfdb58e  vmovaps xmm2, [rsp+0x20]
0000773e7dfdb594  vmovaps xmm3, [rsp+0x30]
0000773e7dfdb59a  vmovaps xmm4, [rsp+0x40]
0000773e7dfdb5a0  vmovaps xmm5, [rsp+0x50]
0000773e7dfdb5a6  vmovaps xmm7, [rsp+0x60]
0000773e7dfdb5ac  vmovaps xmm8, [rsp+0x70]
0000773e7dfdb5b2  vmovaps xmm9, [rsp+0x80]
0000773e7dfdb5bb  vmovaps xmm10, [rsp+0x90]
0000773e7dfdb5c4  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdb5cd  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdb5d6  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdb5df  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdb5e8  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdb5f1  add rsp, 0xF0
0000773e7dfdb5f8  pop r11
0000773e7dfdb5fa  pop r10
0000773e7dfdb5fc  pop r9
0000773e7dfdb5fe  pop r8
0000773e7dfdb600  pop rsi
0000773e7dfdb601  pop rdi
0000773e7dfdb602  pop rdx
0000773e7dfdb603  pop rcx
0000773e7dfdb604  pop rax
0000773e7dfdb605  add rsp, 0x08
0000773e7dfdb609  jmp 0x0000773E7DFDA1C7
0000773e7dfdb60e  sub rsp, 0x08
0000773e7dfdb612  push rax
0000773e7dfdb613  push rcx
0000773e7dfdb614  push rdx
0000773e7dfdb615  push rdi
0000773e7dfdb616  push rsi
0000773e7dfdb617  push r8
0000773e7dfdb619  push r9
0000773e7dfdb61b  push r10
0000773e7dfdb61d  push r11
0000773e7dfdb61f  sub rsp, 0xF0
0000773e7dfdb626  vmovaps [rsp], xmm0
0000773e7dfdb62b  vmovaps [rsp+0x10], xmm1
0000773e7dfdb631  vmovaps [rsp+0x20], xmm2
0000773e7dfdb637  vmovaps [rsp+0x30], xmm3
0000773e7dfdb63d  vmovaps [rsp+0x40], xmm4
0000773e7dfdb643  vmovaps [rsp+0x50], xmm5
0000773e7dfdb649  vmovaps [rsp+0x60], xmm6
0000773e7dfdb64f  vmovaps [rsp+0x70], xmm7
0000773e7dfdb655  vmovaps [rsp+0x80], xmm8
0000773e7dfdb65e  vmovaps [rsp+0x90], xmm9
0000773e7dfdb667  vmovaps [rsp+0xA0], xmm10
0000773e7dfdb670  vmovaps [rsp+0xB0], xmm11
0000773e7dfdb679  vmovaps [rsp+0xC0], xmm12
0000773e7dfdb682  vmovaps [rsp+0xD0], xmm14
0000773e7dfdb68b  vmovaps [rsp+0xE0], xmm15
0000773e7dfdb694  sub rsp, 0x40
0000773e7dfdb698  lea rdi, [rsp]
0000773e7dfdb69c  lea rsi, [rsp+0x10]
0000773e7dfdb6a1  lea rdx, [rsp+0x20]
0000773e7dfdb6a6  lea rcx, [rsp+0x30]
0000773e7dfdb6ab  mov r8d, 0x00
0000773e7dfdb6b1  lea r9, [r15+0x3A8]
0000773e7dfdb6b8  movaps [rdi], xmm13
0000773e7dfdb6bc  movaps [rsi], xmm12
0000773e7dfdb6c0  movaps [rdx], xmm14
0000773e7dfdb6c4  movaps [rcx], xmm1
0000773e7dfdb6c7  mov rax, 0x567852F34A50
0000773e7dfdb6d1  call rax
0000773e7dfdb6d3  movaps xmm13, [rsp]
0000773e7dfdb6d8  add rsp, 0x40
0000773e7dfdb6dc  vmovaps xmm0, [rsp]
0000773e7dfdb6e1  vmovaps xmm1, [rsp+0x10]
0000773e7dfdb6e7  vmovaps xmm2, [rsp+0x20]
0000773e7dfdb6ed  vmovaps xmm3, [rsp+0x30]
0000773e7dfdb6f3  vmovaps xmm4, [rsp+0x40]
0000773e7dfdb6f9  vmovaps xmm5, [rsp+0x50]
0000773e7dfdb6ff  vmovaps xmm6, [rsp+0x60]
0000773e7dfdb705  vmovaps xmm7, [rsp+0x70]
0000773e7dfdb70b  vmovaps xmm8, [rsp+0x80]
0000773e7dfdb714  vmovaps xmm9, [rsp+0x90]
0000773e7dfdb71d  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdb726  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdb72f  vmovaps xmm12, [rsp+0xC0]
0000773e7dfdb738  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdb741  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdb74a  add rsp, 0xF0
0000773e7dfdb751  pop r11
0000773e7dfdb753  pop r10
0000773e7dfdb755  pop r9
0000773e7dfdb757  pop r8
0000773e7dfdb759  pop rsi
0000773e7dfdb75a  pop rdi
0000773e7dfdb75b  pop rdx
0000773e7dfdb75c  pop rcx
0000773e7dfdb75d  pop rax
0000773e7dfdb75e  add rsp, 0x08
0000773e7dfdb762  jmp 0x0000773E7DFDA1F9
0000773e7dfdb767  sub rsp, 0x08
0000773e7dfdb76b  push rax
0000773e7dfdb76c  push rcx
0000773e7dfdb76d  push rdx
0000773e7dfdb76e  push rdi
0000773e7dfdb76f  push rsi
0000773e7dfdb770  push r8
0000773e7dfdb772  push r9
0000773e7dfdb774  push r10
0000773e7dfdb776  push r11
0000773e7dfdb778  sub rsp, 0xF0
0000773e7dfdb77f  vmovaps [rsp], xmm0
0000773e7dfdb784  vmovaps [rsp+0x10], xmm1
0000773e7dfdb78a  vmovaps [rsp+0x20], xmm2
0000773e7dfdb790  vmovaps [rsp+0x30], xmm3
0000773e7dfdb796  vmovaps [rsp+0x40], xmm4
0000773e7dfdb79c  vmovaps [rsp+0x50], xmm5
0000773e7dfdb7a2  vmovaps [rsp+0x60], xmm6
0000773e7dfdb7a8  vmovaps [rsp+0x70], xmm7
0000773e7dfdb7ae  vmovaps [rsp+0x80], xmm8
0000773e7dfdb7b7  vmovaps [rsp+0x90], xmm9
0000773e7dfdb7c0  vmovaps [rsp+0xA0], xmm10
0000773e7dfdb7c9  vmovaps [rsp+0xB0], xmm11
0000773e7dfdb7d2  vmovaps [rsp+0xC0], xmm13
0000773e7dfdb7db  vmovaps [rsp+0xD0], xmm14
0000773e7dfdb7e4  vmovaps [rsp+0xE0], xmm15
0000773e7dfdb7ed  sub rsp, 0x40
0000773e7dfdb7f1  lea rdi, [rsp]
0000773e7dfdb7f5  lea rsi, [rsp+0x10]
0000773e7dfdb7fa  lea rdx, [rsp+0x20]
0000773e7dfdb7ff  lea rcx, [rsp+0x30]
0000773e7dfdb804  mov r8d, 0x00
0000773e7dfdb80a  lea r9, [r15+0x3A8]
0000773e7dfdb811  movaps [rdi], xmm12
0000773e7dfdb815  movaps [rsi], xmm3
0000773e7dfdb818  movaps [rdx], xmm14
0000773e7dfdb81c  movaps [rcx], xmm5
0000773e7dfdb81f  mov rax, 0x567852F34A50
0000773e7dfdb829  call rax
0000773e7dfdb82b  movaps xmm12, [rsp]
0000773e7dfdb830  add rsp, 0x40
0000773e7dfdb834  vmovaps xmm0, [rsp]
0000773e7dfdb839  vmovaps xmm1, [rsp+0x10]
0000773e7dfdb83f  vmovaps xmm2, [rsp+0x20]
0000773e7dfdb845  vmovaps xmm3, [rsp+0x30]
0000773e7dfdb84b  vmovaps xmm4, [rsp+0x40]
0000773e7dfdb851  vmovaps xmm5, [rsp+0x50]
0000773e7dfdb857  vmovaps xmm6, [rsp+0x60]
0000773e7dfdb85d  vmovaps xmm7, [rsp+0x70]
0000773e7dfdb863  vmovaps xmm8, [rsp+0x80]
0000773e7dfdb86c  vmovaps xmm9, [rsp+0x90]
0000773e7dfdb875  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdb87e  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdb887  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdb890  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdb899  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdb8a2  add rsp, 0xF0
0000773e7dfdb8a9  pop r11
0000773e7dfdb8ab  pop r10
0000773e7dfdb8ad  pop r9
0000773e7dfdb8af  pop r8
0000773e7dfdb8b1  pop rsi
0000773e7dfdb8b2  pop rdi
0000773e7dfdb8b3  pop rdx
0000773e7dfdb8b4  pop rcx
0000773e7dfdb8b5  pop rax
0000773e7dfdb8b6  add rsp, 0x08
0000773e7dfdb8ba  jmp 0x0000773E7DFDA256
0000773e7dfdb8bf  sub rsp, 0x08
0000773e7dfdb8c3  push rax
0000773e7dfdb8c4  push rcx
0000773e7dfdb8c5  push rdx
0000773e7dfdb8c6  push rdi
0000773e7dfdb8c7  push rsi
0000773e7dfdb8c8  push r8
0000773e7dfdb8ca  push r9
0000773e7dfdb8cc  push r10
0000773e7dfdb8ce  push r11
0000773e7dfdb8d0  sub rsp, 0xF0
0000773e7dfdb8d7  vmovaps [rsp], xmm0
0000773e7dfdb8dc  vmovaps [rsp+0x10], xmm1
0000773e7dfdb8e2  vmovaps [rsp+0x20], xmm2
0000773e7dfdb8e8  vmovaps [rsp+0x30], xmm3
0000773e7dfdb8ee  vmovaps [rsp+0x40], xmm4
0000773e7dfdb8f4  vmovaps [rsp+0x50], xmm5
0000773e7dfdb8fa  vmovaps [rsp+0x60], xmm6
0000773e7dfdb900  vmovaps [rsp+0x70], xmm7
0000773e7dfdb906  vmovaps [rsp+0x80], xmm8
0000773e7dfdb90f  vmovaps [rsp+0x90], xmm9
0000773e7dfdb918  vmovaps [rsp+0xA0], xmm11
0000773e7dfdb921  vmovaps [rsp+0xB0], xmm12
0000773e7dfdb92a  vmovaps [rsp+0xC0], xmm13
0000773e7dfdb933  vmovaps [rsp+0xD0], xmm14
0000773e7dfdb93c  vmovaps [rsp+0xE0], xmm15
0000773e7dfdb945  sub rsp, 0x40
0000773e7dfdb949  lea rdi, [rsp]
0000773e7dfdb94d  lea rsi, [rsp+0x10]
0000773e7dfdb952  lea rdx, [rsp+0x20]
0000773e7dfdb957  lea rcx, [rsp+0x30]
0000773e7dfdb95c  mov r8d, 0x00
0000773e7dfdb962  lea r9, [r15+0x3A8]
0000773e7dfdb969  movaps [rdi], xmm10
0000773e7dfdb96d  movaps [rsi], xmm9
0000773e7dfdb971  movaps [rdx], xmm7
0000773e7dfdb974  movaps [rcx], xmm14
0000773e7dfdb978  mov rax, 0x567852F34A50
0000773e7dfdb982  call rax
0000773e7dfdb984  movaps xmm10, [rsp]
0000773e7dfdb989  add rsp, 0x40
0000773e7dfdb98d  vmovaps xmm0, [rsp]
0000773e7dfdb992  vmovaps xmm1, [rsp+0x10]
0000773e7dfdb998  vmovaps xmm2, [rsp+0x20]
0000773e7dfdb99e  vmovaps xmm3, [rsp+0x30]
0000773e7dfdb9a4  vmovaps xmm4, [rsp+0x40]
0000773e7dfdb9aa  vmovaps xmm5, [rsp+0x50]
0000773e7dfdb9b0  vmovaps xmm6, [rsp+0x60]
0000773e7dfdb9b6  vmovaps xmm7, [rsp+0x70]
0000773e7dfdb9bc  vmovaps xmm8, [rsp+0x80]
0000773e7dfdb9c5  vmovaps xmm9, [rsp+0x90]
0000773e7dfdb9ce  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdb9d7  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdb9e0  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdb9e9  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdb9f2  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdb9fb  add rsp, 0xF0
0000773e7dfdba02  pop r11
0000773e7dfdba04  pop r10
0000773e7dfdba06  pop r9
0000773e7dfdba08  pop r8
0000773e7dfdba0a  pop rsi
0000773e7dfdba0b  pop rdi
0000773e7dfdba0c  pop rdx
0000773e7dfdba0d  pop rcx
0000773e7dfdba0e  pop rax
0000773e7dfdba0f  add rsp, 0x08
0000773e7dfdba13  jmp 0x0000773E7DFDA27C
0000773e7dfdba18  call 0x0000773E7DE0D4E0
0000773e7dfdba1d  jmp 0x0000773E7DFDA289
0000773e7dfdba22  sub rsp, 0x08
0000773e7dfdba26  push rax
0000773e7dfdba27  push rcx
0000773e7dfdba28  push rdx
0000773e7dfdba29  push rdi
0000773e7dfdba2a  push rsi
0000773e7dfdba2b  push r8
0000773e7dfdba2d  push r9
0000773e7dfdba2f  push r10
0000773e7dfdba31  push r11
0000773e7dfdba33  sub rsp, 0xF0
0000773e7dfdba3a  vmovaps [rsp], xmm0
0000773e7dfdba3f  vmovaps [rsp+0x10], xmm1
0000773e7dfdba45  vmovaps [rsp+0x20], xmm2
0000773e7dfdba4b  vmovaps [rsp+0x30], xmm3
0000773e7dfdba51  vmovaps [rsp+0x40], xmm4
0000773e7dfdba57  vmovaps [rsp+0x50], xmm6
0000773e7dfdba5d  vmovaps [rsp+0x60], xmm7
0000773e7dfdba63  vmovaps [rsp+0x70], xmm8
0000773e7dfdba69  vmovaps [rsp+0x80], xmm9
0000773e7dfdba72  vmovaps [rsp+0x90], xmm10
0000773e7dfdba7b  vmovaps [rsp+0xA0], xmm11
0000773e7dfdba84  vmovaps [rsp+0xB0], xmm12
0000773e7dfdba8d  vmovaps [rsp+0xC0], xmm13
0000773e7dfdba96  vmovaps [rsp+0xD0], xmm14
0000773e7dfdba9f  vmovaps [rsp+0xE0], xmm15
0000773e7dfdbaa8  sub rsp, 0x40
0000773e7dfdbaac  lea rdi, [rsp]
0000773e7dfdbab0  lea rsi, [rsp+0x10]
0000773e7dfdbab5  lea rdx, [rsp+0x20]
0000773e7dfdbaba  lea rcx, [rsp+0x30]
0000773e7dfdbabf  mov r8d, 0x00
0000773e7dfdbac5  lea r9, [r15+0x3A8]
0000773e7dfdbacc  movaps [rdi], xmm5
0000773e7dfdbacf  movaps [rsi], xmm6
0000773e7dfdbad2  movaps [rdx], xmm7
0000773e7dfdbad5  movaps [rcx], xmm9
0000773e7dfdbad9  mov rax, 0x567852F34A50
0000773e7dfdbae3  call rax
0000773e7dfdbae5  movaps xmm5, [rsp]
0000773e7dfdbae9  add rsp, 0x40
0000773e7dfdbaed  vmovaps xmm0, [rsp]
0000773e7dfdbaf2  vmovaps xmm1, [rsp+0x10]
0000773e7dfdbaf8  vmovaps xmm2, [rsp+0x20]
0000773e7dfdbafe  vmovaps xmm3, [rsp+0x30]
0000773e7dfdbb04  vmovaps xmm4, [rsp+0x40]
0000773e7dfdbb0a  vmovaps xmm6, [rsp+0x50]
0000773e7dfdbb10  vmovaps xmm7, [rsp+0x60]
0000773e7dfdbb16  vmovaps xmm8, [rsp+0x70]
0000773e7dfdbb1c  vmovaps xmm9, [rsp+0x80]
0000773e7dfdbb25  vmovaps xmm10, [rsp+0x90]
0000773e7dfdbb2e  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdbb37  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdbb40  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdbb49  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdbb52  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdbb5b  add rsp, 0xF0
0000773e7dfdbb62  pop r11
0000773e7dfdbb64  pop r10
0000773e7dfdbb66  pop r9
0000773e7dfdbb68  pop r8
0000773e7dfdbb6a  pop rsi
0000773e7dfdbb6b  pop rdi
0000773e7dfdbb6c  pop rdx
0000773e7dfdbb6d  pop rcx
0000773e7dfdbb6e  pop rax
0000773e7dfdbb6f  add rsp, 0x08
0000773e7dfdbb73  jmp 0x0000773E7DFDA2BB
0000773e7dfdbb78  sub rsp, 0x08
0000773e7dfdbb7c  push rax
0000773e7dfdbb7d  push rcx
0000773e7dfdbb7e  push rdx
0000773e7dfdbb7f  push rdi
0000773e7dfdbb80  push rsi
0000773e7dfdbb81  push r8
0000773e7dfdbb83  push r9
0000773e7dfdbb85  push r10
0000773e7dfdbb87  push r11
0000773e7dfdbb89  sub rsp, 0xF0
0000773e7dfdbb90  vmovaps [rsp], xmm0
0000773e7dfdbb95  vmovaps [rsp+0x10], xmm1
0000773e7dfdbb9b  vmovaps [rsp+0x20], xmm2
0000773e7dfdbba1  vmovaps [rsp+0x30], xmm3
0000773e7dfdbba7  vmovaps [rsp+0x40], xmm4
0000773e7dfdbbad  vmovaps [rsp+0x50], xmm5
0000773e7dfdbbb3  vmovaps [rsp+0x60], xmm6
0000773e7dfdbbb9  vmovaps [rsp+0x70], xmm8
0000773e7dfdbbbf  vmovaps [rsp+0x80], xmm9
0000773e7dfdbbc8  vmovaps [rsp+0x90], xmm10
0000773e7dfdbbd1  vmovaps [rsp+0xA0], xmm11
0000773e7dfdbbda  vmovaps [rsp+0xB0], xmm12
0000773e7dfdbbe3  vmovaps [rsp+0xC0], xmm13
0000773e7dfdbbec  vmovaps [rsp+0xD0], xmm14
0000773e7dfdbbf5  vmovaps [rsp+0xE0], xmm15
0000773e7dfdbbfe  sub rsp, 0x40
0000773e7dfdbc02  lea rdi, [rsp]
0000773e7dfdbc06  lea rsi, [rsp+0x10]
0000773e7dfdbc0b  lea rdx, [rsp+0x20]
0000773e7dfdbc10  lea rcx, [rsp+0x30]
0000773e7dfdbc15  mov r8d, 0x00
0000773e7dfdbc1b  lea r9, [r15+0x3A8]
0000773e7dfdbc22  movaps [rdi], xmm7
0000773e7dfdbc25  movaps [rsi], xmm13
0000773e7dfdbc29  movaps [rdx], xmm1
0000773e7dfdbc2c  movaps [rcx], xmm9
0000773e7dfdbc30  mov rax, 0x567852F34A50
0000773e7dfdbc3a  call rax
0000773e7dfdbc3c  movaps xmm7, [rsp]
0000773e7dfdbc40  add rsp, 0x40
0000773e7dfdbc44  vmovaps xmm0, [rsp]
0000773e7dfdbc49  vmovaps xmm1, [rsp+0x10]
0000773e7dfdbc4f  vmovaps xmm2, [rsp+0x20]
0000773e7dfdbc55  vmovaps xmm3, [rsp+0x30]
0000773e7dfdbc5b  vmovaps xmm4, [rsp+0x40]
0000773e7dfdbc61  vmovaps xmm5, [rsp+0x50]
0000773e7dfdbc67  vmovaps xmm6, [rsp+0x60]
0000773e7dfdbc6d  vmovaps xmm8, [rsp+0x70]
0000773e7dfdbc73  vmovaps xmm9, [rsp+0x80]
0000773e7dfdbc7c  vmovaps xmm10, [rsp+0x90]
0000773e7dfdbc85  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdbc8e  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdbc97  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdbca0  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdbca9  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdbcb2  add rsp, 0xF0
0000773e7dfdbcb9  pop r11
0000773e7dfdbcbb  pop r10
0000773e7dfdbcbd  pop r9
0000773e7dfdbcbf  pop r8
0000773e7dfdbcc1  pop rsi
0000773e7dfdbcc2  pop rdi
0000773e7dfdbcc3  pop rdx
0000773e7dfdbcc4  pop rcx
0000773e7dfdbcc5  pop rax
0000773e7dfdbcc6  add rsp, 0x08
0000773e7dfdbcca  jmp 0x0000773E7DFDA2E0
0000773e7dfdbccf  call 0x0000773E7DE0C260
0000773e7dfdbcd4  jmp 0x0000773E7DFDA303
0000773e7dfdbcd9  call 0x0000773E7DE07890
0000773e7dfdbcde  jmp 0x0000773E7DFDA30D
0000773e7dfdbce3  sub rsp, 0x08
0000773e7dfdbce7  push rax
0000773e7dfdbce8  push rcx
0000773e7dfdbce9  push rdx
0000773e7dfdbcea  push rdi
0000773e7dfdbceb  push rsi
0000773e7dfdbcec  push r8
0000773e7dfdbcee  push r9
0000773e7dfdbcf0  push r10
0000773e7dfdbcf2  push r11
0000773e7dfdbcf4  sub rsp, 0xF0
0000773e7dfdbcfb  vmovaps [rsp], xmm0
0000773e7dfdbd00  vmovaps [rsp+0x10], xmm1
0000773e7dfdbd06  vmovaps [rsp+0x20], xmm3
0000773e7dfdbd0c  vmovaps [rsp+0x30], xmm4
0000773e7dfdbd12  vmovaps [rsp+0x40], xmm5
0000773e7dfdbd18  vmovaps [rsp+0x50], xmm6
0000773e7dfdbd1e  vmovaps [rsp+0x60], xmm7
0000773e7dfdbd24  vmovaps [rsp+0x70], xmm8
0000773e7dfdbd2a  vmovaps [rsp+0x80], xmm9
0000773e7dfdbd33  vmovaps [rsp+0x90], xmm10
0000773e7dfdbd3c  vmovaps [rsp+0xA0], xmm11
0000773e7dfdbd45  vmovaps [rsp+0xB0], xmm12
0000773e7dfdbd4e  vmovaps [rsp+0xC0], xmm13
0000773e7dfdbd57  vmovaps [rsp+0xD0], xmm14
0000773e7dfdbd60  vmovaps [rsp+0xE0], xmm15
0000773e7dfdbd69  sub rsp, 0x40
0000773e7dfdbd6d  lea rdi, [rsp]
0000773e7dfdbd71  lea rsi, [rsp+0x10]
0000773e7dfdbd76  lea rdx, [rsp+0x20]
0000773e7dfdbd7b  lea rcx, [rsp+0x30]
0000773e7dfdbd80  mov r8d, 0x00
0000773e7dfdbd86  lea r9, [r15+0x3A8]
0000773e7dfdbd8d  movaps [rdi], xmm2
0000773e7dfdbd90  movaps [rsi], xmm12
0000773e7dfdbd94  movaps [rdx], xmm6
0000773e7dfdbd97  movaps [rcx], xmm3
0000773e7dfdbd9a  mov rax, 0x567852F34A50
0000773e7dfdbda4  call rax
0000773e7dfdbda6  movaps xmm2, [rsp]
0000773e7dfdbdaa  add rsp, 0x40
0000773e7dfdbdae  vmovaps xmm0, [rsp]
0000773e7dfdbdb3  vmovaps xmm1, [rsp+0x10]
0000773e7dfdbdb9  vmovaps xmm3, [rsp+0x20]
0000773e7dfdbdbf  vmovaps xmm4, [rsp+0x30]
0000773e7dfdbdc5  vmovaps xmm5, [rsp+0x40]
0000773e7dfdbdcb  vmovaps xmm6, [rsp+0x50]
0000773e7dfdbdd1  vmovaps xmm7, [rsp+0x60]
0000773e7dfdbdd7  vmovaps xmm8, [rsp+0x70]
0000773e7dfdbddd  vmovaps xmm9, [rsp+0x80]
0000773e7dfdbde6  vmovaps xmm10, [rsp+0x90]
0000773e7dfdbdef  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdbdf8  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdbe01  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdbe0a  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdbe13  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdbe1c  add rsp, 0xF0
0000773e7dfdbe23  pop r11
0000773e7dfdbe25  pop r10
0000773e7dfdbe27  pop r9
0000773e7dfdbe29  pop r8
0000773e7dfdbe2b  pop rsi
0000773e7dfdbe2c  pop rdi
0000773e7dfdbe2d  pop rdx
0000773e7dfdbe2e  pop rcx
0000773e7dfdbe2f  pop rax
0000773e7dfdbe30  add rsp, 0x08
0000773e7dfdbe34  jmp 0x0000773E7DFDA353
0000773e7dfdbe39  sub rsp, 0x08
0000773e7dfdbe3d  push rax
0000773e7dfdbe3e  push rcx
0000773e7dfdbe3f  push rdx
0000773e7dfdbe40  push rdi
0000773e7dfdbe41  push rsi
0000773e7dfdbe42  push r8
0000773e7dfdbe44  push r9
0000773e7dfdbe46  push r10
0000773e7dfdbe48  push r11
0000773e7dfdbe4a  sub rsp, 0xF0
0000773e7dfdbe51  vmovaps [rsp], xmm0
0000773e7dfdbe56  vmovaps [rsp+0x10], xmm1
0000773e7dfdbe5c  vmovaps [rsp+0x20], xmm2
0000773e7dfdbe62  vmovaps [rsp+0x30], xmm3
0000773e7dfdbe68  vmovaps [rsp+0x40], xmm4
0000773e7dfdbe6e  vmovaps [rsp+0x50], xmm5
0000773e7dfdbe74  vmovaps [rsp+0x60], xmm7
0000773e7dfdbe7a  vmovaps [rsp+0x70], xmm8
0000773e7dfdbe80  vmovaps [rsp+0x80], xmm9
0000773e7dfdbe89  vmovaps [rsp+0x90], xmm10
0000773e7dfdbe92  vmovaps [rsp+0xA0], xmm11
0000773e7dfdbe9b  vmovaps [rsp+0xB0], xmm12
0000773e7dfdbea4  vmovaps [rsp+0xC0], xmm13
0000773e7dfdbead  vmovaps [rsp+0xD0], xmm14
0000773e7dfdbeb6  vmovaps [rsp+0xE0], xmm15
0000773e7dfdbebf  sub rsp, 0x40
0000773e7dfdbec3  lea rdi, [rsp]
0000773e7dfdbec7  lea rsi, [rsp+0x10]
0000773e7dfdbecc  lea rdx, [rsp+0x20]
0000773e7dfdbed1  lea rcx, [rsp+0x30]
0000773e7dfdbed6  mov r8d, 0x00
0000773e7dfdbedc  lea r9, [r15+0x3A8]
0000773e7dfdbee3  movaps [rdi], xmm6
0000773e7dfdbee6  movaps [rsi], xmm10
0000773e7dfdbeea  movaps [rdx], xmm12
0000773e7dfdbeee  movaps [rcx], xmm1
0000773e7dfdbef1  mov rax, 0x567852F34A50
0000773e7dfdbefb  call rax
0000773e7dfdbefd  movaps xmm6, [rsp]
0000773e7dfdbf01  add rsp, 0x40
0000773e7dfdbf05  vmovaps xmm0, [rsp]
0000773e7dfdbf0a  vmovaps xmm1, [rsp+0x10]
0000773e7dfdbf10  vmovaps xmm2, [rsp+0x20]
0000773e7dfdbf16  vmovaps xmm3, [rsp+0x30]
0000773e7dfdbf1c  vmovaps xmm4, [rsp+0x40]
0000773e7dfdbf22  vmovaps xmm5, [rsp+0x50]
0000773e7dfdbf28  vmovaps xmm7, [rsp+0x60]
0000773e7dfdbf2e  vmovaps xmm8, [rsp+0x70]
0000773e7dfdbf34  vmovaps xmm9, [rsp+0x80]
0000773e7dfdbf3d  vmovaps xmm10, [rsp+0x90]
0000773e7dfdbf46  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdbf4f  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdbf58  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdbf61  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdbf6a  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdbf73  add rsp, 0xF0
0000773e7dfdbf7a  pop r11
0000773e7dfdbf7c  pop r10
0000773e7dfdbf7e  pop r9
0000773e7dfdbf80  pop r8
0000773e7dfdbf82  pop rsi
0000773e7dfdbf83  pop rdi
0000773e7dfdbf84  pop rdx
0000773e7dfdbf85  pop rcx
0000773e7dfdbf86  pop rax
0000773e7dfdbf87  add rsp, 0x08
0000773e7dfdbf8b  jmp 0x0000773E7DFDA381
0000773e7dfdbf90  sub rsp, 0x08
0000773e7dfdbf94  push rax
0000773e7dfdbf95  push rcx
0000773e7dfdbf96  push rdx
0000773e7dfdbf97  push rdi
0000773e7dfdbf98  push rsi
0000773e7dfdbf99  push r8
0000773e7dfdbf9b  push r9
0000773e7dfdbf9d  push r10
0000773e7dfdbf9f  push r11
0000773e7dfdbfa1  sub rsp, 0xF0
0000773e7dfdbfa8  vmovaps [rsp], xmm0
0000773e7dfdbfad  vmovaps [rsp+0x10], xmm1
0000773e7dfdbfb3  vmovaps [rsp+0x20], xmm2
0000773e7dfdbfb9  vmovaps [rsp+0x30], xmm3
0000773e7dfdbfbf  vmovaps [rsp+0x40], xmm4
0000773e7dfdbfc5  vmovaps [rsp+0x50], xmm5
0000773e7dfdbfcb  vmovaps [rsp+0x60], xmm6
0000773e7dfdbfd1  vmovaps [rsp+0x70], xmm7
0000773e7dfdbfd7  vmovaps [rsp+0x80], xmm8
0000773e7dfdbfe0  vmovaps [rsp+0x90], xmm9
0000773e7dfdbfe9  vmovaps [rsp+0xA0], xmm11
0000773e7dfdbff2  vmovaps [rsp+0xB0], xmm12
0000773e7dfdbffb  vmovaps [rsp+0xC0], xmm13
0000773e7dfdc004  vmovaps [rsp+0xD0], xmm14
0000773e7dfdc00d  vmovaps [rsp+0xE0], xmm15
0000773e7dfdc016  sub rsp, 0x40
0000773e7dfdc01a  lea rdi, [rsp]
0000773e7dfdc01e  lea rsi, [rsp+0x10]
0000773e7dfdc023  lea rdx, [rsp+0x20]
0000773e7dfdc028  lea rcx, [rsp+0x30]
0000773e7dfdc02d  mov r8d, 0x00
0000773e7dfdc033  lea r9, [r15+0x3A8]
0000773e7dfdc03a  movaps [rdi], xmm10
0000773e7dfdc03e  movaps [rsi], xmm5
0000773e7dfdc041  movaps [rdx], xmm12
0000773e7dfdc045  movaps [rcx], xmm1
0000773e7dfdc048  mov rax, 0x567852F34A50
0000773e7dfdc052  call rax
0000773e7dfdc054  movaps xmm10, [rsp]
0000773e7dfdc059  add rsp, 0x40
0000773e7dfdc05d  vmovaps xmm0, [rsp]
0000773e7dfdc062  vmovaps xmm1, [rsp+0x10]
0000773e7dfdc068  vmovaps xmm2, [rsp+0x20]
0000773e7dfdc06e  vmovaps xmm3, [rsp+0x30]
0000773e7dfdc074  vmovaps xmm4, [rsp+0x40]
0000773e7dfdc07a  vmovaps xmm5, [rsp+0x50]
0000773e7dfdc080  vmovaps xmm6, [rsp+0x60]
0000773e7dfdc086  vmovaps xmm7, [rsp+0x70]
0000773e7dfdc08c  vmovaps xmm8, [rsp+0x80]
0000773e7dfdc095  vmovaps xmm9, [rsp+0x90]
0000773e7dfdc09e  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdc0a7  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdc0b0  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdc0b9  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdc0c2  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdc0cb  add rsp, 0xF0
0000773e7dfdc0d2  pop r11
0000773e7dfdc0d4  pop r10
0000773e7dfdc0d6  pop r9
0000773e7dfdc0d8  pop r8
0000773e7dfdc0da  pop rsi
0000773e7dfdc0db  pop rdi
0000773e7dfdc0dc  pop rdx
0000773e7dfdc0dd  pop rcx
0000773e7dfdc0de  pop rax
0000773e7dfdc0df  add rsp, 0x08
0000773e7dfdc0e3  jmp 0x0000773E7DFDA3B0
0000773e7dfdc0e8  sub rsp, 0x08
0000773e7dfdc0ec  push rax
0000773e7dfdc0ed  push rcx
0000773e7dfdc0ee  push rdx
0000773e7dfdc0ef  push rdi
0000773e7dfdc0f0  push rsi
0000773e7dfdc0f1  push r8
0000773e7dfdc0f3  push r9
0000773e7dfdc0f5  push r10
0000773e7dfdc0f7  push r11
0000773e7dfdc0f9  sub rsp, 0xF0
0000773e7dfdc100  vmovaps [rsp], xmm0
0000773e7dfdc105  vmovaps [rsp+0x10], xmm1
0000773e7dfdc10b  vmovaps [rsp+0x20], xmm2
0000773e7dfdc111  vmovaps [rsp+0x30], xmm3
0000773e7dfdc117  vmovaps [rsp+0x40], xmm4
0000773e7dfdc11d  vmovaps [rsp+0x50], xmm5
0000773e7dfdc123  vmovaps [rsp+0x60], xmm6
0000773e7dfdc129  vmovaps [rsp+0x70], xmm7
0000773e7dfdc12f  vmovaps [rsp+0x80], xmm8
0000773e7dfdc138  vmovaps [rsp+0x90], xmm9
0000773e7dfdc141  vmovaps [rsp+0xA0], xmm10
0000773e7dfdc14a  vmovaps [rsp+0xB0], xmm11
0000773e7dfdc153  vmovaps [rsp+0xC0], xmm13
0000773e7dfdc15c  vmovaps [rsp+0xD0], xmm14
0000773e7dfdc165  vmovaps [rsp+0xE0], xmm15
0000773e7dfdc16e  sub rsp, 0x40
0000773e7dfdc172  lea rdi, [rsp]
0000773e7dfdc176  lea rsi, [rsp+0x10]
0000773e7dfdc17b  lea rdx, [rsp+0x20]
0000773e7dfdc180  lea rcx, [rsp+0x30]
0000773e7dfdc185  mov r8d, 0x00
0000773e7dfdc18b  lea r9, [r15+0x3A8]
0000773e7dfdc192  movaps [rdi], xmm12
0000773e7dfdc196  movaps [rsi], xmm7
0000773e7dfdc199  movaps [rdx], xmm15
0000773e7dfdc19d  movaps [rcx], xmm1
0000773e7dfdc1a0  mov rax, 0x567852F34A50
0000773e7dfdc1aa  call rax
0000773e7dfdc1ac  movaps xmm12, [rsp]
0000773e7dfdc1b1  add rsp, 0x40
0000773e7dfdc1b5  vmovaps xmm0, [rsp]
0000773e7dfdc1ba  vmovaps xmm1, [rsp+0x10]
0000773e7dfdc1c0  vmovaps xmm2, [rsp+0x20]
0000773e7dfdc1c6  vmovaps xmm3, [rsp+0x30]
0000773e7dfdc1cc  vmovaps xmm4, [rsp+0x40]
0000773e7dfdc1d2  vmovaps xmm5, [rsp+0x50]
0000773e7dfdc1d8  vmovaps xmm6, [rsp+0x60]
0000773e7dfdc1de  vmovaps xmm7, [rsp+0x70]
0000773e7dfdc1e4  vmovaps xmm8, [rsp+0x80]
0000773e7dfdc1ed  vmovaps xmm9, [rsp+0x90]
0000773e7dfdc1f6  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdc1ff  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdc208  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdc211  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdc21a  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdc223  add rsp, 0xF0
0000773e7dfdc22a  pop r11
0000773e7dfdc22c  pop r10
0000773e7dfdc22e  pop r9
0000773e7dfdc230  pop r8
0000773e7dfdc232  pop rsi
0000773e7dfdc233  pop rdi
0000773e7dfdc234  pop rdx
0000773e7dfdc235  pop rcx
0000773e7dfdc236  pop rax
0000773e7dfdc237  add rsp, 0x08
0000773e7dfdc23b  jmp 0x0000773E7DFDA3D9
0000773e7dfdc240  call 0x0000773E7DDFF430
0000773e7dfdc245  jmp 0x0000773E7DFDA3E3
0000773e7dfdc24a  call 0x0000773E7DE0E760
0000773e7dfdc24f  jmp 0x0000773E7DFDA3ED
0000773e7dfdc254  sub rsp, 0x08
0000773e7dfdc258  push rax
0000773e7dfdc259  push rcx
0000773e7dfdc25a  push rdx
0000773e7dfdc25b  push rdi
0000773e7dfdc25c  push rsi
0000773e7dfdc25d  push r8
0000773e7dfdc25f  push r9
0000773e7dfdc261  push r10
0000773e7dfdc263  push r11
0000773e7dfdc265  sub rsp, 0xF0
0000773e7dfdc26c  vmovaps [rsp], xmm0
0000773e7dfdc271  vmovaps [rsp+0x10], xmm1
0000773e7dfdc277  vmovaps [rsp+0x20], xmm2
0000773e7dfdc27d  vmovaps [rsp+0x30], xmm3
0000773e7dfdc283  vmovaps [rsp+0x40], xmm4
0000773e7dfdc289  vmovaps [rsp+0x50], xmm5
0000773e7dfdc28f  vmovaps [rsp+0x60], xmm6
0000773e7dfdc295  vmovaps [rsp+0x70], xmm8
0000773e7dfdc29b  vmovaps [rsp+0x80], xmm9
0000773e7dfdc2a4  vmovaps [rsp+0x90], xmm10
0000773e7dfdc2ad  vmovaps [rsp+0xA0], xmm11
0000773e7dfdc2b6  vmovaps [rsp+0xB0], xmm12
0000773e7dfdc2bf  vmovaps [rsp+0xC0], xmm13
0000773e7dfdc2c8  vmovaps [rsp+0xD0], xmm14
0000773e7dfdc2d1  vmovaps [rsp+0xE0], xmm15
0000773e7dfdc2da  sub rsp, 0x40
0000773e7dfdc2de  lea rdi, [rsp]
0000773e7dfdc2e2  lea rsi, [rsp+0x10]
0000773e7dfdc2e7  lea rdx, [rsp+0x20]
0000773e7dfdc2ec  lea rcx, [rsp+0x30]
0000773e7dfdc2f1  mov r8d, 0x00
0000773e7dfdc2f7  lea r9, [r15+0x3A8]
0000773e7dfdc2fe  movaps [rdi], xmm7
0000773e7dfdc301  movaps [rsi], xmm2
0000773e7dfdc304  movaps [rdx], xmm9
0000773e7dfdc308  movaps [rcx], xmm11
0000773e7dfdc30c  mov rax, 0x567852F34A50
0000773e7dfdc316  call rax
0000773e7dfdc318  movaps xmm7, [rsp]
0000773e7dfdc31c  add rsp, 0x40
0000773e7dfdc320  vmovaps xmm0, [rsp]
0000773e7dfdc325  vmovaps xmm1, [rsp+0x10]
0000773e7dfdc32b  vmovaps xmm2, [rsp+0x20]
0000773e7dfdc331  vmovaps xmm3, [rsp+0x30]
0000773e7dfdc337  vmovaps xmm4, [rsp+0x40]
0000773e7dfdc33d  vmovaps xmm5, [rsp+0x50]
0000773e7dfdc343  vmovaps xmm6, [rsp+0x60]
0000773e7dfdc349  vmovaps xmm8, [rsp+0x70]
0000773e7dfdc34f  vmovaps xmm9, [rsp+0x80]
0000773e7dfdc358  vmovaps xmm10, [rsp+0x90]
0000773e7dfdc361  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdc36a  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdc373  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdc37c  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdc385  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdc38e  add rsp, 0xF0
0000773e7dfdc395  pop r11
0000773e7dfdc397  pop r10
0000773e7dfdc399  pop r9
0000773e7dfdc39b  pop r8
0000773e7dfdc39d  pop rsi
0000773e7dfdc39e  pop rdi
0000773e7dfdc39f  pop rdx
0000773e7dfdc3a0  pop rcx
0000773e7dfdc3a1  pop rax
0000773e7dfdc3a2  add rsp, 0x08
0000773e7dfdc3a6  jmp 0x0000773E7DFDA421
0000773e7dfdc3ab  sub rsp, 0x08
0000773e7dfdc3af  push rax
0000773e7dfdc3b0  push rcx
0000773e7dfdc3b1  push rdx
0000773e7dfdc3b2  push rdi
0000773e7dfdc3b3  push rsi
0000773e7dfdc3b4  push r8
0000773e7dfdc3b6  push r9
0000773e7dfdc3b8  push r10
0000773e7dfdc3ba  push r11
0000773e7dfdc3bc  sub rsp, 0xF0
0000773e7dfdc3c3  vmovaps [rsp], xmm0
0000773e7dfdc3c8  vmovaps [rsp+0x10], xmm1
0000773e7dfdc3ce  vmovaps [rsp+0x20], xmm2
0000773e7dfdc3d4  vmovaps [rsp+0x30], xmm3
0000773e7dfdc3da  vmovaps [rsp+0x40], xmm4
0000773e7dfdc3e0  vmovaps [rsp+0x50], xmm5
0000773e7dfdc3e6  vmovaps [rsp+0x60], xmm6
0000773e7dfdc3ec  vmovaps [rsp+0x70], xmm7
0000773e7dfdc3f2  vmovaps [rsp+0x80], xmm8
0000773e7dfdc3fb  vmovaps [rsp+0x90], xmm10
0000773e7dfdc404  vmovaps [rsp+0xA0], xmm11
0000773e7dfdc40d  vmovaps [rsp+0xB0], xmm12
0000773e7dfdc416  vmovaps [rsp+0xC0], xmm13
0000773e7dfdc41f  vmovaps [rsp+0xD0], xmm14
0000773e7dfdc428  vmovaps [rsp+0xE0], xmm15
0000773e7dfdc431  sub rsp, 0x40
0000773e7dfdc435  lea rdi, [rsp]
0000773e7dfdc439  lea rsi, [rsp+0x10]
0000773e7dfdc43e  lea rdx, [rsp+0x20]
0000773e7dfdc443  lea rcx, [rsp+0x30]
0000773e7dfdc448  mov r8d, 0x00
0000773e7dfdc44e  lea r9, [r15+0x3A8]
0000773e7dfdc455  movaps [rdi], xmm9
0000773e7dfdc459  movaps [rsi], xmm6
0000773e7dfdc45c  movaps [rdx], xmm1
0000773e7dfdc45f  movaps [rcx], xmm11
0000773e7dfdc463  mov rax, 0x567852F34A50
0000773e7dfdc46d  call rax
0000773e7dfdc46f  movaps xmm9, [rsp]
0000773e7dfdc474  add rsp, 0x40
0000773e7dfdc478  vmovaps xmm0, [rsp]
0000773e7dfdc47d  vmovaps xmm1, [rsp+0x10]
0000773e7dfdc483  vmovaps xmm2, [rsp+0x20]
0000773e7dfdc489  vmovaps xmm3, [rsp+0x30]
0000773e7dfdc48f  vmovaps xmm4, [rsp+0x40]
0000773e7dfdc495  vmovaps xmm5, [rsp+0x50]
0000773e7dfdc49b  vmovaps xmm6, [rsp+0x60]
0000773e7dfdc4a1  vmovaps xmm7, [rsp+0x70]
0000773e7dfdc4a7  vmovaps xmm8, [rsp+0x80]
0000773e7dfdc4b0  vmovaps xmm10, [rsp+0x90]
0000773e7dfdc4b9  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdc4c2  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdc4cb  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdc4d4  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdc4dd  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdc4e6  add rsp, 0xF0
0000773e7dfdc4ed  pop r11
0000773e7dfdc4ef  pop r10
0000773e7dfdc4f1  pop r9
0000773e7dfdc4f3  pop r8
0000773e7dfdc4f5  pop rsi
0000773e7dfdc4f6  pop rdi
0000773e7dfdc4f7  pop rdx
0000773e7dfdc4f8  pop rcx
0000773e7dfdc4f9  pop rax
0000773e7dfdc4fa  add rsp, 0x08
0000773e7dfdc4fe  jmp 0x0000773E7DFDA447
0000773e7dfdc503  sub rsp, 0x08
0000773e7dfdc507  push rax
0000773e7dfdc508  push rcx
0000773e7dfdc509  push rdx
0000773e7dfdc50a  push rdi
0000773e7dfdc50b  push rsi
0000773e7dfdc50c  push r8
0000773e7dfdc50e  push r9
0000773e7dfdc510  push r10
0000773e7dfdc512  push r11
0000773e7dfdc514  sub rsp, 0xF0
0000773e7dfdc51b  vmovaps [rsp], xmm0
0000773e7dfdc520  vmovaps [rsp+0x10], xmm1
0000773e7dfdc526  vmovaps [rsp+0x20], xmm2
0000773e7dfdc52c  vmovaps [rsp+0x30], xmm3
0000773e7dfdc532  vmovaps [rsp+0x40], xmm4
0000773e7dfdc538  vmovaps [rsp+0x50], xmm5
0000773e7dfdc53e  vmovaps [rsp+0x60], xmm6
0000773e7dfdc544  vmovaps [rsp+0x70], xmm7
0000773e7dfdc54a  vmovaps [rsp+0x80], xmm8
0000773e7dfdc553  vmovaps [rsp+0x90], xmm9
0000773e7dfdc55c  vmovaps [rsp+0xA0], xmm10
0000773e7dfdc565  vmovaps [rsp+0xB0], xmm12
0000773e7dfdc56e  vmovaps [rsp+0xC0], xmm13
0000773e7dfdc577  vmovaps [rsp+0xD0], xmm14
0000773e7dfdc580  vmovaps [rsp+0xE0], xmm15
0000773e7dfdc589  sub rsp, 0x40
0000773e7dfdc58d  lea rdi, [rsp]
0000773e7dfdc591  lea rsi, [rsp+0x10]
0000773e7dfdc596  lea rdx, [rsp+0x20]
0000773e7dfdc59b  lea rcx, [rsp+0x30]
0000773e7dfdc5a0  mov r8d, 0x00
0000773e7dfdc5a6  lea r9, [r15+0x3A8]
0000773e7dfdc5ad  movaps [rdi], xmm11
0000773e7dfdc5b1  movaps [rsi], xmm10
0000773e7dfdc5b5  movaps [rdx], xmm8
0000773e7dfdc5b9  movaps [rcx], xmm1
0000773e7dfdc5bc  mov rax, 0x567852F34A50
0000773e7dfdc5c6  call rax
0000773e7dfdc5c8  movaps xmm11, [rsp]
0000773e7dfdc5cd  add rsp, 0x40
0000773e7dfdc5d1  vmovaps xmm0, [rsp]
0000773e7dfdc5d6  vmovaps xmm1, [rsp+0x10]
0000773e7dfdc5dc  vmovaps xmm2, [rsp+0x20]
0000773e7dfdc5e2  vmovaps xmm3, [rsp+0x30]
0000773e7dfdc5e8  vmovaps xmm4, [rsp+0x40]
0000773e7dfdc5ee  vmovaps xmm5, [rsp+0x50]
0000773e7dfdc5f4  vmovaps xmm6, [rsp+0x60]
0000773e7dfdc5fa  vmovaps xmm7, [rsp+0x70]
0000773e7dfdc600  vmovaps xmm8, [rsp+0x80]
0000773e7dfdc609  vmovaps xmm9, [rsp+0x90]
0000773e7dfdc612  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdc61b  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdc624  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdc62d  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdc636  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdc63f  add rsp, 0xF0
0000773e7dfdc646  pop r11
0000773e7dfdc648  pop r10
0000773e7dfdc64a  pop r9
0000773e7dfdc64c  pop r8
0000773e7dfdc64e  pop rsi
0000773e7dfdc64f  pop rdi
0000773e7dfdc650  pop rdx
0000773e7dfdc651  pop rcx
0000773e7dfdc652  pop rax
0000773e7dfdc653  add rsp, 0x08
0000773e7dfdc657  jmp 0x0000773E7DFDA46D
0000773e7dfdc65c  sub rsp, 0x08
0000773e7dfdc660  push rax
0000773e7dfdc661  push rcx
0000773e7dfdc662  push rdx
0000773e7dfdc663  push rdi
0000773e7dfdc664  push rsi
0000773e7dfdc665  push r8
0000773e7dfdc667  push r9
0000773e7dfdc669  push r10
0000773e7dfdc66b  push r11
0000773e7dfdc66d  sub rsp, 0xF0
0000773e7dfdc674  vmovaps [rsp], xmm0
0000773e7dfdc679  vmovaps [rsp+0x10], xmm1
0000773e7dfdc67f  vmovaps [rsp+0x20], xmm2
0000773e7dfdc685  vmovaps [rsp+0x30], xmm3
0000773e7dfdc68b  vmovaps [rsp+0x40], xmm4
0000773e7dfdc691  vmovaps [rsp+0x50], xmm5
0000773e7dfdc697  vmovaps [rsp+0x60], xmm6
0000773e7dfdc69d  vmovaps [rsp+0x70], xmm7
0000773e7dfdc6a3  vmovaps [rsp+0x80], xmm8
0000773e7dfdc6ac  vmovaps [rsp+0x90], xmm9
0000773e7dfdc6b5  vmovaps [rsp+0xA0], xmm11
0000773e7dfdc6be  vmovaps [rsp+0xB0], xmm12
0000773e7dfdc6c7  vmovaps [rsp+0xC0], xmm13
0000773e7dfdc6d0  vmovaps [rsp+0xD0], xmm14
0000773e7dfdc6d9  vmovaps [rsp+0xE0], xmm15
0000773e7dfdc6e2  sub rsp, 0x40
0000773e7dfdc6e6  lea rdi, [rsp]
0000773e7dfdc6ea  lea rsi, [rsp+0x10]
0000773e7dfdc6ef  lea rdx, [rsp+0x20]
0000773e7dfdc6f4  lea rcx, [rsp+0x30]
0000773e7dfdc6f9  mov r8d, 0x00
0000773e7dfdc6ff  lea r9, [r15+0x3A8]
0000773e7dfdc706  movaps [rdi], xmm10
0000773e7dfdc70a  movaps [rsi], xmm12
0000773e7dfdc70e  movaps [rdx], xmm13
0000773e7dfdc712  movaps [rcx], xmm1
0000773e7dfdc715  mov rax, 0x567852F34A50
0000773e7dfdc71f  call rax
0000773e7dfdc721  movaps xmm10, [rsp]
0000773e7dfdc726  add rsp, 0x40
0000773e7dfdc72a  vmovaps xmm0, [rsp]
0000773e7dfdc72f  vmovaps xmm1, [rsp+0x10]
0000773e7dfdc735  vmovaps xmm2, [rsp+0x20]
0000773e7dfdc73b  vmovaps xmm3, [rsp+0x30]
0000773e7dfdc741  vmovaps xmm4, [rsp+0x40]
0000773e7dfdc747  vmovaps xmm5, [rsp+0x50]
0000773e7dfdc74d  vmovaps xmm6, [rsp+0x60]
0000773e7dfdc753  vmovaps xmm7, [rsp+0x70]
0000773e7dfdc759  vmovaps xmm8, [rsp+0x80]
0000773e7dfdc762  vmovaps xmm9, [rsp+0x90]
0000773e7dfdc76b  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdc774  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdc77d  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdc786  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdc78f  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdc798  add rsp, 0xF0
0000773e7dfdc79f  pop r11
0000773e7dfdc7a1  pop r10
0000773e7dfdc7a3  pop r9
0000773e7dfdc7a5  pop r8
0000773e7dfdc7a7  pop rsi
0000773e7dfdc7a8  pop rdi
0000773e7dfdc7a9  pop rdx
0000773e7dfdc7aa  pop rcx
0000773e7dfdc7ab  pop rax
0000773e7dfdc7ac  add rsp, 0x08
0000773e7dfdc7b0  jmp 0x0000773E7DFDA493
0000773e7dfdc7b5  call 0x0000773E7DDFF430
0000773e7dfdc7ba  jmp 0x0000773E7DFDA49D
0000773e7dfdc7bf  call 0x0000773E7DE0C260
0000773e7dfdc7c4  jmp 0x0000773E7DFDA4A7
0000773e7dfdc7c9  sub rsp, 0x08
0000773e7dfdc7cd  push rax
0000773e7dfdc7ce  push rcx
0000773e7dfdc7cf  push rdx
0000773e7dfdc7d0  push rdi
0000773e7dfdc7d1  push rsi
0000773e7dfdc7d2  push r8
0000773e7dfdc7d4  push r9
0000773e7dfdc7d6  push r10
0000773e7dfdc7d8  push r11
0000773e7dfdc7da  sub rsp, 0xF0
0000773e7dfdc7e1  vmovaps [rsp], xmm0
0000773e7dfdc7e6  vmovaps [rsp+0x10], xmm1
0000773e7dfdc7ec  vmovaps [rsp+0x20], xmm2
0000773e7dfdc7f2  vmovaps [rsp+0x30], xmm3
0000773e7dfdc7f8  vmovaps [rsp+0x40], xmm4
0000773e7dfdc7fe  vmovaps [rsp+0x50], xmm5
0000773e7dfdc804  vmovaps [rsp+0x60], xmm6
0000773e7dfdc80a  vmovaps [rsp+0x70], xmm7
0000773e7dfdc810  vmovaps [rsp+0x80], xmm9
0000773e7dfdc819  vmovaps [rsp+0x90], xmm10
0000773e7dfdc822  vmovaps [rsp+0xA0], xmm11
0000773e7dfdc82b  vmovaps [rsp+0xB0], xmm12
0000773e7dfdc834  vmovaps [rsp+0xC0], xmm13
0000773e7dfdc83d  vmovaps [rsp+0xD0], xmm14
0000773e7dfdc846  vmovaps [rsp+0xE0], xmm15
0000773e7dfdc84f  sub rsp, 0x40
0000773e7dfdc853  lea rdi, [rsp]
0000773e7dfdc857  lea rsi, [rsp+0x10]
0000773e7dfdc85c  lea rdx, [rsp+0x20]
0000773e7dfdc861  lea rcx, [rsp+0x30]
0000773e7dfdc866  mov r8d, 0x00
0000773e7dfdc86c  lea r9, [r15+0x3A8]
0000773e7dfdc873  movaps [rdi], xmm8
0000773e7dfdc877  movaps [rsi], xmm7
0000773e7dfdc87a  movaps [rdx], xmm4
0000773e7dfdc87d  movaps [rcx], xmm12
0000773e7dfdc881  mov rax, 0x567852F34A50
0000773e7dfdc88b  call rax
0000773e7dfdc88d  movaps xmm8, [rsp]
0000773e7dfdc892  add rsp, 0x40
0000773e7dfdc896  vmovaps xmm0, [rsp]
0000773e7dfdc89b  vmovaps xmm1, [rsp+0x10]
0000773e7dfdc8a1  vmovaps xmm2, [rsp+0x20]
0000773e7dfdc8a7  vmovaps xmm3, [rsp+0x30]
0000773e7dfdc8ad  vmovaps xmm4, [rsp+0x40]
0000773e7dfdc8b3  vmovaps xmm5, [rsp+0x50]
0000773e7dfdc8b9  vmovaps xmm6, [rsp+0x60]
0000773e7dfdc8bf  vmovaps xmm7, [rsp+0x70]
0000773e7dfdc8c5  vmovaps xmm9, [rsp+0x80]
0000773e7dfdc8ce  vmovaps xmm10, [rsp+0x90]
0000773e7dfdc8d7  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdc8e0  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdc8e9  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdc8f2  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdc8fb  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdc904  add rsp, 0xF0
0000773e7dfdc90b  pop r11
0000773e7dfdc90d  pop r10
0000773e7dfdc90f  pop r9
0000773e7dfdc911  pop r8
0000773e7dfdc913  pop rsi
0000773e7dfdc914  pop rdi
0000773e7dfdc915  pop rdx
0000773e7dfdc916  pop rcx
0000773e7dfdc917  pop rax
0000773e7dfdc918  add rsp, 0x08
0000773e7dfdc91c  jmp 0x0000773E7DFDA4D0
0000773e7dfdc921  sub rsp, 0x08
0000773e7dfdc925  push rax
0000773e7dfdc926  push rcx
0000773e7dfdc927  push rdx
0000773e7dfdc928  push rdi
0000773e7dfdc929  push rsi
0000773e7dfdc92a  push r8
0000773e7dfdc92c  push r9
0000773e7dfdc92e  push r10
0000773e7dfdc930  push r11
0000773e7dfdc932  sub rsp, 0xF0
0000773e7dfdc939  vmovaps [rsp], xmm0
0000773e7dfdc93e  vmovaps [rsp+0x10], xmm1
0000773e7dfdc944  vmovaps [rsp+0x20], xmm2
0000773e7dfdc94a  vmovaps [rsp+0x30], xmm3
0000773e7dfdc950  vmovaps [rsp+0x40], xmm4
0000773e7dfdc956  vmovaps [rsp+0x50], xmm5
0000773e7dfdc95c  vmovaps [rsp+0x60], xmm6
0000773e7dfdc962  vmovaps [rsp+0x70], xmm8
0000773e7dfdc968  vmovaps [rsp+0x80], xmm9
0000773e7dfdc971  vmovaps [rsp+0x90], xmm10
0000773e7dfdc97a  vmovaps [rsp+0xA0], xmm11
0000773e7dfdc983  vmovaps [rsp+0xB0], xmm12
0000773e7dfdc98c  vmovaps [rsp+0xC0], xmm13
0000773e7dfdc995  vmovaps [rsp+0xD0], xmm14
0000773e7dfdc99e  vmovaps [rsp+0xE0], xmm15
0000773e7dfdc9a7  sub rsp, 0x40
0000773e7dfdc9ab  lea rdi, [rsp]
0000773e7dfdc9af  lea rsi, [rsp+0x10]
0000773e7dfdc9b4  lea rdx, [rsp+0x20]
0000773e7dfdc9b9  lea rcx, [rsp+0x30]
0000773e7dfdc9be  mov r8d, 0x00
0000773e7dfdc9c4  lea r9, [r15+0x3A8]
0000773e7dfdc9cb  movaps [rdi], xmm7
0000773e7dfdc9ce  movaps [rsi], xmm9
0000773e7dfdc9d2  movaps [rdx], xmm14
0000773e7dfdc9d6  movaps [rcx], xmm12
0000773e7dfdc9da  mov rax, 0x567852F34A50
0000773e7dfdc9e4  call rax
0000773e7dfdc9e6  movaps xmm7, [rsp]
0000773e7dfdc9ea  add rsp, 0x40
0000773e7dfdc9ee  vmovaps xmm0, [rsp]
0000773e7dfdc9f3  vmovaps xmm1, [rsp+0x10]
0000773e7dfdc9f9  vmovaps xmm2, [rsp+0x20]
0000773e7dfdc9ff  vmovaps xmm3, [rsp+0x30]
0000773e7dfdca05  vmovaps xmm4, [rsp+0x40]
0000773e7dfdca0b  vmovaps xmm5, [rsp+0x50]
0000773e7dfdca11  vmovaps xmm6, [rsp+0x60]
0000773e7dfdca17  vmovaps xmm8, [rsp+0x70]
0000773e7dfdca1d  vmovaps xmm9, [rsp+0x80]
0000773e7dfdca26  vmovaps xmm10, [rsp+0x90]
0000773e7dfdca2f  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdca38  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdca41  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdca4a  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdca53  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdca5c  add rsp, 0xF0
0000773e7dfdca63  pop r11
0000773e7dfdca65  pop r10
0000773e7dfdca67  pop r9
0000773e7dfdca69  pop r8
0000773e7dfdca6b  pop rsi
0000773e7dfdca6c  pop rdi
0000773e7dfdca6d  pop rdx
0000773e7dfdca6e  pop rcx
0000773e7dfdca6f  pop rax
0000773e7dfdca70  add rsp, 0x08
0000773e7dfdca74  jmp 0x0000773E7DFDA4F8
0000773e7dfdca79  sub rsp, 0x08
0000773e7dfdca7d  push rax
0000773e7dfdca7e  push rcx
0000773e7dfdca7f  push rdx
0000773e7dfdca80  push rdi
0000773e7dfdca81  push rsi
0000773e7dfdca82  push r8
0000773e7dfdca84  push r9
0000773e7dfdca86  push r10
0000773e7dfdca88  push r11
0000773e7dfdca8a  sub rsp, 0xF0
0000773e7dfdca91  vmovaps [rsp], xmm0
0000773e7dfdca96  vmovaps [rsp+0x10], xmm1
0000773e7dfdca9c  vmovaps [rsp+0x20], xmm2
0000773e7dfdcaa2  vmovaps [rsp+0x30], xmm3
0000773e7dfdcaa8  vmovaps [rsp+0x40], xmm4
0000773e7dfdcaae  vmovaps [rsp+0x50], xmm5
0000773e7dfdcab4  vmovaps [rsp+0x60], xmm6
0000773e7dfdcaba  vmovaps [rsp+0x70], xmm7
0000773e7dfdcac0  vmovaps [rsp+0x80], xmm8
0000773e7dfdcac9  vmovaps [rsp+0x90], xmm9
0000773e7dfdcad2  vmovaps [rsp+0xA0], xmm10
0000773e7dfdcadb  vmovaps [rsp+0xB0], xmm11
0000773e7dfdcae4  vmovaps [rsp+0xC0], xmm13
0000773e7dfdcaed  vmovaps [rsp+0xD0], xmm14
0000773e7dfdcaf6  vmovaps [rsp+0xE0], xmm15
0000773e7dfdcaff  sub rsp, 0x40
0000773e7dfdcb03  lea rdi, [rsp]
0000773e7dfdcb07  lea rsi, [rsp+0x10]
0000773e7dfdcb0c  lea rdx, [rsp+0x20]
0000773e7dfdcb11  lea rcx, [rsp+0x30]
0000773e7dfdcb16  mov r8d, 0x00
0000773e7dfdcb1c  lea r9, [r15+0x3A8]
0000773e7dfdcb23  movaps [rdi], xmm12
0000773e7dfdcb27  movaps [rsi], xmm11
0000773e7dfdcb2b  movaps [rdx], xmm15
0000773e7dfdcb2f  movaps [rcx], xmm14
0000773e7dfdcb33  mov rax, 0x567852F34A50
0000773e7dfdcb3d  call rax
0000773e7dfdcb3f  movaps xmm12, [rsp]
0000773e7dfdcb44  add rsp, 0x40
0000773e7dfdcb48  vmovaps xmm0, [rsp]
0000773e7dfdcb4d  vmovaps xmm1, [rsp+0x10]
0000773e7dfdcb53  vmovaps xmm2, [rsp+0x20]
0000773e7dfdcb59  vmovaps xmm3, [rsp+0x30]
0000773e7dfdcb5f  vmovaps xmm4, [rsp+0x40]
0000773e7dfdcb65  vmovaps xmm5, [rsp+0x50]
0000773e7dfdcb6b  vmovaps xmm6, [rsp+0x60]
0000773e7dfdcb71  vmovaps xmm7, [rsp+0x70]
0000773e7dfdcb77  vmovaps xmm8, [rsp+0x80]
0000773e7dfdcb80  vmovaps xmm9, [rsp+0x90]
0000773e7dfdcb89  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdcb92  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdcb9b  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdcba4  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdcbad  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdcbb6  add rsp, 0xF0
0000773e7dfdcbbd  pop r11
0000773e7dfdcbbf  pop r10
0000773e7dfdcbc1  pop r9
0000773e7dfdcbc3  pop r8
0000773e7dfdcbc5  pop rsi
0000773e7dfdcbc6  pop rdi
0000773e7dfdcbc7  pop rdx
0000773e7dfdcbc8  pop rcx
0000773e7dfdcbc9  pop rax
0000773e7dfdcbca  add rsp, 0x08
0000773e7dfdcbce  jmp 0x0000773E7DFDA521
0000773e7dfdcbd3  sub rsp, 0x08
0000773e7dfdcbd7  push rax
0000773e7dfdcbd8  push rcx
0000773e7dfdcbd9  push rdx
0000773e7dfdcbda  push rdi
0000773e7dfdcbdb  push rsi
0000773e7dfdcbdc  push r8
0000773e7dfdcbde  push r9
0000773e7dfdcbe0  push r10
0000773e7dfdcbe2  push r11
0000773e7dfdcbe4  sub rsp, 0xF0
0000773e7dfdcbeb  vmovaps [rsp], xmm0
0000773e7dfdcbf0  vmovaps [rsp+0x10], xmm1
0000773e7dfdcbf6  vmovaps [rsp+0x20], xmm2
0000773e7dfdcbfc  vmovaps [rsp+0x30], xmm3
0000773e7dfdcc02  vmovaps [rsp+0x40], xmm4
0000773e7dfdcc08  vmovaps [rsp+0x50], xmm5
0000773e7dfdcc0e  vmovaps [rsp+0x60], xmm6
0000773e7dfdcc14  vmovaps [rsp+0x70], xmm7
0000773e7dfdcc1a  vmovaps [rsp+0x80], xmm8
0000773e7dfdcc23  vmovaps [rsp+0x90], xmm9
0000773e7dfdcc2c  vmovaps [rsp+0xA0], xmm10
0000773e7dfdcc35  vmovaps [rsp+0xB0], xmm12
0000773e7dfdcc3e  vmovaps [rsp+0xC0], xmm13
0000773e7dfdcc47  vmovaps [rsp+0xD0], xmm14
0000773e7dfdcc50  vmovaps [rsp+0xE0], xmm15
0000773e7dfdcc59  sub rsp, 0x40
0000773e7dfdcc5d  lea rdi, [rsp]
0000773e7dfdcc61  lea rsi, [rsp+0x10]
0000773e7dfdcc66  lea rdx, [rsp+0x20]
0000773e7dfdcc6b  lea rcx, [rsp+0x30]
0000773e7dfdcc70  mov r8d, 0x00
0000773e7dfdcc76  lea r9, [r15+0x3A8]
0000773e7dfdcc7d  movaps [rdi], xmm11
0000773e7dfdcc81  movaps [rsi], xmm10
0000773e7dfdcc85  movaps [rdx], xmm13
0000773e7dfdcc89  movaps [rcx], xmm15
0000773e7dfdcc8d  mov rax, 0x567852F34A50
0000773e7dfdcc97  call rax
0000773e7dfdcc99  movaps xmm11, [rsp]
0000773e7dfdcc9e  add rsp, 0x40
0000773e7dfdcca2  vmovaps xmm0, [rsp]
0000773e7dfdcca7  vmovaps xmm1, [rsp+0x10]
0000773e7dfdccad  vmovaps xmm2, [rsp+0x20]
0000773e7dfdccb3  vmovaps xmm3, [rsp+0x30]
0000773e7dfdccb9  vmovaps xmm4, [rsp+0x40]
0000773e7dfdccbf  vmovaps xmm5, [rsp+0x50]
0000773e7dfdccc5  vmovaps xmm6, [rsp+0x60]
0000773e7dfdcccb  vmovaps xmm7, [rsp+0x70]
0000773e7dfdccd1  vmovaps xmm8, [rsp+0x80]
0000773e7dfdccda  vmovaps xmm9, [rsp+0x90]
0000773e7dfdcce3  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdccec  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdccf5  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdccfe  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdcd07  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdcd10  add rsp, 0xF0
0000773e7dfdcd17  pop r11
0000773e7dfdcd19  pop r10
0000773e7dfdcd1b  pop r9
0000773e7dfdcd1d  pop r8
0000773e7dfdcd1f  pop rsi
0000773e7dfdcd20  pop rdi
0000773e7dfdcd21  pop rdx
0000773e7dfdcd22  pop rcx
0000773e7dfdcd23  pop rax
0000773e7dfdcd24  add rsp, 0x08
0000773e7dfdcd28  jmp 0x0000773E7DFDA54A
0000773e7dfdcd2d  call 0x0000773E7DE0E760
0000773e7dfdcd32  jmp 0x0000773E7DFDA557
0000773e7dfdcd37  call 0x0000773E7DE0D4E0
0000773e7dfdcd3c  jmp 0x0000773E7DFDA564
0000773e7dfdcd41  sub rsp, 0x08
0000773e7dfdcd45  push rax
0000773e7dfdcd46  push rcx
0000773e7dfdcd47  push rdx
0000773e7dfdcd48  push rdi
0000773e7dfdcd49  push rsi
0000773e7dfdcd4a  push r8
0000773e7dfdcd4c  push r9
0000773e7dfdcd4e  push r10
0000773e7dfdcd50  push r11
0000773e7dfdcd52  sub rsp, 0xF0
0000773e7dfdcd59  vmovaps [rsp], xmm0
0000773e7dfdcd5e  vmovaps [rsp+0x10], xmm1
0000773e7dfdcd64  vmovaps [rsp+0x20], xmm2
0000773e7dfdcd6a  vmovaps [rsp+0x30], xmm3
0000773e7dfdcd70  vmovaps [rsp+0x40], xmm4
0000773e7dfdcd76  vmovaps [rsp+0x50], xmm5
0000773e7dfdcd7c  vmovaps [rsp+0x60], xmm6
0000773e7dfdcd82  vmovaps [rsp+0x70], xmm7
0000773e7dfdcd88  vmovaps [rsp+0x80], xmm8
0000773e7dfdcd91  vmovaps [rsp+0x90], xmm9
0000773e7dfdcd9a  vmovaps [rsp+0xA0], xmm11
0000773e7dfdcda3  vmovaps [rsp+0xB0], xmm12
0000773e7dfdcdac  vmovaps [rsp+0xC0], xmm13
0000773e7dfdcdb5  vmovaps [rsp+0xD0], xmm14
0000773e7dfdcdbe  vmovaps [rsp+0xE0], xmm15
0000773e7dfdcdc7  sub rsp, 0x40
0000773e7dfdcdcb  lea rdi, [rsp]
0000773e7dfdcdcf  lea rsi, [rsp+0x10]
0000773e7dfdcdd4  lea rdx, [rsp+0x20]
0000773e7dfdcdd9  lea rcx, [rsp+0x30]
0000773e7dfdcdde  mov r8d, 0x00
0000773e7dfdcde4  lea r9, [r15+0x3A8]
0000773e7dfdcdeb  movaps [rdi], xmm10
0000773e7dfdcdef  movaps [rsi], xmm8
0000773e7dfdcdf3  movaps [rdx], xmm1
0000773e7dfdcdf6  movaps [rcx], xmm13
0000773e7dfdcdfa  mov rax, 0x567852F34A50
0000773e7dfdce04  call rax
0000773e7dfdce06  movaps xmm10, [rsp]
0000773e7dfdce0b  add rsp, 0x40
0000773e7dfdce0f  vmovaps xmm0, [rsp]
0000773e7dfdce14  vmovaps xmm1, [rsp+0x10]
0000773e7dfdce1a  vmovaps xmm2, [rsp+0x20]
0000773e7dfdce20  vmovaps xmm3, [rsp+0x30]
0000773e7dfdce26  vmovaps xmm4, [rsp+0x40]
0000773e7dfdce2c  vmovaps xmm5, [rsp+0x50]
0000773e7dfdce32  vmovaps xmm6, [rsp+0x60]
0000773e7dfdce38  vmovaps xmm7, [rsp+0x70]
0000773e7dfdce3e  vmovaps xmm8, [rsp+0x80]
0000773e7dfdce47  vmovaps xmm9, [rsp+0x90]
0000773e7dfdce50  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdce59  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdce62  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdce6b  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdce74  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdce7d  add rsp, 0xF0
0000773e7dfdce84  pop r11
0000773e7dfdce86  pop r10
0000773e7dfdce88  pop r9
0000773e7dfdce8a  pop r8
0000773e7dfdce8c  pop rsi
0000773e7dfdce8d  pop rdi
0000773e7dfdce8e  pop rdx
0000773e7dfdce8f  pop rcx
0000773e7dfdce90  pop rax
0000773e7dfdce91  add rsp, 0x08
0000773e7dfdce95  jmp 0x0000773E7DFDA59A
0000773e7dfdce9a  call 0x0000773E7DDFF430
0000773e7dfdce9f  jmp 0x0000773E7DFDA5AC
0000773e7dfdcea4  sub rsp, 0x08
0000773e7dfdcea8  push rax
0000773e7dfdcea9  push rcx
0000773e7dfdceaa  push rdx
0000773e7dfdceab  push rdi
0000773e7dfdceac  push rsi
0000773e7dfdcead  push r8
0000773e7dfdceaf  push r9
0000773e7dfdceb1  push r10
0000773e7dfdceb3  push r11
0000773e7dfdceb5  sub rsp, 0xF0
0000773e7dfdcebc  vmovaps [rsp], xmm0
0000773e7dfdcec1  vmovaps [rsp+0x10], xmm1
0000773e7dfdcec7  vmovaps [rsp+0x20], xmm2
0000773e7dfdcecd  vmovaps [rsp+0x30], xmm3
0000773e7dfdced3  vmovaps [rsp+0x40], xmm4
0000773e7dfdced9  vmovaps [rsp+0x50], xmm5
0000773e7dfdcedf  vmovaps [rsp+0x60], xmm6
0000773e7dfdcee5  vmovaps [rsp+0x70], xmm7
0000773e7dfdceeb  vmovaps [rsp+0x80], xmm8
0000773e7dfdcef4  vmovaps [rsp+0x90], xmm10
0000773e7dfdcefd  vmovaps [rsp+0xA0], xmm11
0000773e7dfdcf06  vmovaps [rsp+0xB0], xmm12
0000773e7dfdcf0f  vmovaps [rsp+0xC0], xmm13
0000773e7dfdcf18  vmovaps [rsp+0xD0], xmm14
0000773e7dfdcf21  vmovaps [rsp+0xE0], xmm15
0000773e7dfdcf2a  sub rsp, 0x40
0000773e7dfdcf2e  lea rdi, [rsp]
0000773e7dfdcf32  lea rsi, [rsp+0x10]
0000773e7dfdcf37  lea rdx, [rsp+0x20]
0000773e7dfdcf3c  lea rcx, [rsp+0x30]
0000773e7dfdcf41  mov r8d, 0x00
0000773e7dfdcf47  lea r9, [r15+0x3A8]
0000773e7dfdcf4e  movaps [rdi], xmm9
0000773e7dfdcf52  movaps [rsi], xmm7
0000773e7dfdcf55  movaps [rdx], xmm14
0000773e7dfdcf59  movaps [rcx], xmm13
0000773e7dfdcf5d  mov rax, 0x567852F34A50
0000773e7dfdcf67  call rax
0000773e7dfdcf69  movaps xmm9, [rsp]
0000773e7dfdcf6e  add rsp, 0x40
0000773e7dfdcf72  vmovaps xmm0, [rsp]
0000773e7dfdcf77  vmovaps xmm1, [rsp+0x10]
0000773e7dfdcf7d  vmovaps xmm2, [rsp+0x20]
0000773e7dfdcf83  vmovaps xmm3, [rsp+0x30]
0000773e7dfdcf89  vmovaps xmm4, [rsp+0x40]
0000773e7dfdcf8f  vmovaps xmm5, [rsp+0x50]
0000773e7dfdcf95  vmovaps xmm6, [rsp+0x60]
0000773e7dfdcf9b  vmovaps xmm7, [rsp+0x70]
0000773e7dfdcfa1  vmovaps xmm8, [rsp+0x80]
0000773e7dfdcfaa  vmovaps xmm10, [rsp+0x90]
0000773e7dfdcfb3  vmovaps xmm11, [rsp+0xA0]
0000773e7dfdcfbc  vmovaps xmm12, [rsp+0xB0]
0000773e7dfdcfc5  vmovaps xmm13, [rsp+0xC0]
0000773e7dfdcfce  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdcfd7  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdcfe0  add rsp, 0xF0
0000773e7dfdcfe7  pop r11
0000773e7dfdcfe9  pop r10
0000773e7dfdcfeb  pop r9
0000773e7dfdcfed  pop r8
0000773e7dfdcfef  pop rsi
0000773e7dfdcff0  pop rdi
0000773e7dfdcff1  pop rdx
0000773e7dfdcff2  pop rcx
0000773e7dfdcff3  pop rax
0000773e7dfdcff4  add rsp, 0x08
0000773e7dfdcff8  jmp 0x0000773E7DFDA5DA
0000773e7dfdcffd  sub rsp, 0x08
0000773e7dfdd001  push rax
0000773e7dfdd002  push rcx
0000773e7dfdd003  push rdx
0000773e7dfdd004  push rdi
0000773e7dfdd005  push rsi
0000773e7dfdd006  push r8
0000773e7dfdd008  push r9
0000773e7dfdd00a  push r10
0000773e7dfdd00c  push r11
0000773e7dfdd00e  sub rsp, 0xF0
0000773e7dfdd015  vmovaps [rsp], xmm0
0000773e7dfdd01a  vmovaps [rsp+0x10], xmm1
0000773e7dfdd020  vmovaps [rsp+0x20], xmm2
0000773e7dfdd026  vmovaps [rsp+0x30], xmm3
0000773e7dfdd02c  vmovaps [rsp+0x40], xmm4
0000773e7dfdd032  vmovaps [rsp+0x50], xmm5
0000773e7dfdd038  vmovaps [rsp+0x60], xmm6
0000773e7dfdd03e  vmovaps [rsp+0x70], xmm7
0000773e7dfdd044  vmovaps [rsp+0x80], xmm8
0000773e7dfdd04d  vmovaps [rsp+0x90], xmm9
0000773e7dfdd056  vmovaps [rsp+0xA0], xmm10
0000773e7dfdd05f  vmovaps [rsp+0xB0], xmm11
0000773e7dfdd068  vmovaps [rsp+0xC0], xmm12
0000773e7dfdd071  vmovaps [rsp+0xD0], xmm14
0000773e7dfdd07a  vmovaps [rsp+0xE0], xmm15
0000773e7dfdd083  sub rsp, 0x40
0000773e7dfdd087  lea rdi, [rsp]
0000773e7dfdd08b  lea rsi, [rsp+0x10]
0000773e7dfdd090  lea rdx, [rsp+0x20]
0000773e7dfdd095  lea rcx, [rsp+0x30]
0000773e7dfdd09a  mov r8d, 0x00
0000773e7dfdd0a0  lea r9, [r15+0x3A8]
0000773e7dfdd0a7  movaps [rdi], xmm13
0000773e7dfdd0ab  movaps [rsi], xmm12
0000773e7dfdd0af  movaps [rdx], xmm15
0000773e7dfdd0b3  movaps [rcx], xmm14
0000773e7dfdd0b7  mov rax, 0x567852F34A50
0000773e7dfdd0c1  call rax
0000773e7dfdd0c3  movaps xmm13, [rsp]
0000773e7dfdd0c8  add rsp, 0x40
0000773e7dfdd0cc  vmovaps xmm0, [rsp]
0000773e7dfdd0d1  vmovaps xmm1, [rsp+0x10]
0000773e7dfdd0d7  vmovaps xmm2, [rsp+0x20]
0000773e7dfdd0dd  vmovaps xmm3, [rsp+0x30]
0000773e7dfdd0e3  vmovaps xmm4, [rsp+0x40]
0000773e7dfdd0e9  vmovaps xmm5, [rsp+0x50]
0000773e7dfdd0ef  vmovaps xmm6, [rsp+0x60]
0000773e7dfdd0f5  vmovaps xmm7, [rsp+0x70]
0000773e7dfdd0fb  vmovaps xmm8, [rsp+0x80]
0000773e7dfdd104  vmovaps xmm9, [rsp+0x90]
0000773e7dfdd10d  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdd116  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdd11f  vmovaps xmm12, [rsp+0xC0]
0000773e7dfdd128  vmovaps xmm14, [rsp+0xD0]
0000773e7dfdd131  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdd13a  add rsp, 0xF0
0000773e7dfdd141  pop r11
0000773e7dfdd143  pop r10
0000773e7dfdd145  pop r9
0000773e7dfdd147  pop r8
0000773e7dfdd149  pop rsi
0000773e7dfdd14a  pop rdi
0000773e7dfdd14b  pop rdx
0000773e7dfdd14c  pop rcx
0000773e7dfdd14d  pop rax
0000773e7dfdd14e  add rsp, 0x08
0000773e7dfdd152  jmp 0x0000773E7DFDA608
0000773e7dfdd157  sub rsp, 0x08
0000773e7dfdd15b  push rax
0000773e7dfdd15c  push rcx
0000773e7dfdd15d  push rdx
0000773e7dfdd15e  push rdi
0000773e7dfdd15f  push rsi
0000773e7dfdd160  push r8
0000773e7dfdd162  push r9
0000773e7dfdd164  push r10
0000773e7dfdd166  push r11
0000773e7dfdd168  sub rsp, 0xF0
0000773e7dfdd16f  vmovaps [rsp], xmm0
0000773e7dfdd174  vmovaps [rsp+0x10], xmm1
0000773e7dfdd17a  vmovaps [rsp+0x20], xmm2
0000773e7dfdd180  vmovaps [rsp+0x30], xmm3
0000773e7dfdd186  vmovaps [rsp+0x40], xmm4
0000773e7dfdd18c  vmovaps [rsp+0x50], xmm5
0000773e7dfdd192  vmovaps [rsp+0x60], xmm6
0000773e7dfdd198  vmovaps [rsp+0x70], xmm7
0000773e7dfdd19e  vmovaps [rsp+0x80], xmm8
0000773e7dfdd1a7  vmovaps [rsp+0x90], xmm9
0000773e7dfdd1b0  vmovaps [rsp+0xA0], xmm10
0000773e7dfdd1b9  vmovaps [rsp+0xB0], xmm11
0000773e7dfdd1c2  vmovaps [rsp+0xC0], xmm12
0000773e7dfdd1cb  vmovaps [rsp+0xD0], xmm13
0000773e7dfdd1d4  vmovaps [rsp+0xE0], xmm15
0000773e7dfdd1dd  sub rsp, 0x40
0000773e7dfdd1e1  lea rdi, [rsp]
0000773e7dfdd1e5  lea rsi, [rsp+0x10]
0000773e7dfdd1ea  lea rdx, [rsp+0x20]
0000773e7dfdd1ef  lea rcx, [rsp+0x30]
0000773e7dfdd1f4  mov r8d, 0x00
0000773e7dfdd1fa  lea r9, [r15+0x3A8]
0000773e7dfdd201  movaps [rdi], xmm14
0000773e7dfdd205  movaps [rsi], xmm11
0000773e7dfdd209  movaps [rdx], xmm1
0000773e7dfdd20c  movaps [rcx], xmm15
0000773e7dfdd210  mov rax, 0x567852F34A50
0000773e7dfdd21a  call rax
0000773e7dfdd21c  movaps xmm14, [rsp]
0000773e7dfdd221  add rsp, 0x40
0000773e7dfdd225  vmovaps xmm0, [rsp]
0000773e7dfdd22a  vmovaps xmm1, [rsp+0x10]
0000773e7dfdd230  vmovaps xmm2, [rsp+0x20]
0000773e7dfdd236  vmovaps xmm3, [rsp+0x30]
0000773e7dfdd23c  vmovaps xmm4, [rsp+0x40]
0000773e7dfdd242  vmovaps xmm5, [rsp+0x50]
0000773e7dfdd248  vmovaps xmm6, [rsp+0x60]
0000773e7dfdd24e  vmovaps xmm7, [rsp+0x70]
0000773e7dfdd254  vmovaps xmm8, [rsp+0x80]
0000773e7dfdd25d  vmovaps xmm9, [rsp+0x90]
0000773e7dfdd266  vmovaps xmm10, [rsp+0xA0]
0000773e7dfdd26f  vmovaps xmm11, [rsp+0xB0]
0000773e7dfdd278  vmovaps xmm12, [rsp+0xC0]
0000773e7dfdd281  vmovaps xmm13, [rsp+0xD0]
0000773e7dfdd28a  vmovaps xmm15, [rsp+0xE0]
0000773e7dfdd293  add rsp, 0xF0
0000773e7dfdd29a  pop r11
0000773e7dfdd29c  pop r10
0000773e7dfdd29e  pop r9
0000773e7dfdd2a0  pop r8
0000773e7dfdd2a2  pop rsi
0000773e7dfdd2a3  pop rdi
0000773e7dfdd2a4  pop rdx
0000773e7dfdd2a5  pop rcx
0000773e7dfdd2a6  pop rax
0000773e7dfdd2a7  add rsp, 0x08
0000773e7dfdd2ab  jmp 0x0000773E7DFDA636
0000773e7dfdd2b0  call 0x0000773E7DE079B0
0000773e7dfdd2b5  jmp 0x0000773E7DFDA64C
0000773e7dfdd2ba  call 0x0000773E7DEE3440
0000773e7dfdd2bf  jmp 0x0000773E7DFDA656
0000773e7dfdd2c4  call 0x0000773E7DEDFCE0
0000773e7dfdd2c9  jmp 0x0000773E7DFDA660
0000773e7dfdd2ce  call 0x0000773E7DEE46C0
0000773e7dfdd2d3  jmp 0x0000773E7DFDA66A
0000773e7dfdd2d8  int3
0000773e7dfdd2d9  nop [rax], eax
0000773e7dfdd2e0  mov qword ptr [r15+0x40], 0x430000
0000773e7dfdd2e8  mov eax, 0x430C50
0000773e7dfdd2ed  mov r14, [r13+rax*1]
0000773e7dfdd2f2  movq xmm1, r14
0000773e7dfdd2f7  mov rax, [r15+0x50]
0000773e7dfdd2fb  movups xmm15, [r13+rax*1]
0000773e7dfdd301  movaps [r15+0x120], xmm15
0000773e7dfdd309  mov qword ptr [r15+0x48], 0x10
0000773e7dfdd311  xor eax, eax
0000773e7dfdd313  mov r14d, 0x10
0000773e7dfdd319  mov r12d, 0x200
0000773e7dfdd31f  cmp r14, r12
0000773e7dfdd322  cmc
0000773e7dfdd323  lahf
0000773e7dfdd324  seto al
0000773e7dfdd327  mov [r15+0x108], eax
0000773e7dfdd32e  pextrq rax, xmm15, 0x01
0000773e7dfdd335  movq xmm14, rax
0000773e7dfdd33a  movaps [r15+0x130], xmm14
0000773e7dfdd342  movq rax, xmm1
0000773e7dfdd347  movq r14, xmm15
0000773e7dfdd34c  vmovq xmm1, rax
0000773e7dfdd351  vmovq xmm15, r14
0000773e7dfdd356  movaps xmm13, xmm1
0000773e7dfdd35a  addsd xmm13, xmm15
0000773e7dfdd35f  ucomisd xmm13, xmm13
0000773e7dfdd364  jp 0x0000773E7DFDD423
0000773e7dfdd36a  movq xmm13, xmm13
0000773e7dfdd36f  movq rax, xmm13
0000773e7dfdd374  movq r14, xmm14
0000773e7dfdd379  vmovq xmm1, rax
0000773e7dfdd37e  vmovq xmm15, r14
0000773e7dfdd383  movaps xmm14, xmm1
0000773e7dfdd387  addsd xmm14, xmm15
0000773e7dfdd38c  ucomisd xmm14, xmm14
0000773e7dfdd391  jp 0x0000773E7DFDD46B
0000773e7dfdd397  movq xmm14, xmm14
0000773e7dfdd39c  movaps [r15+0x110], xmm14
0000773e7dfdd3a4  mov eax, [r15+0x108]
0000773e7dfdd3ab  sahf
0000773e7dfdd3ac  jnz 0x0000773E7DFDD3DE
0000773e7dfdd3ae  cmp dword ptr [r15+0x318], 0x00
0000773e7dfdd3b6  jz 0x0000773E7DFDD680
0000773e7dfdd3bc  nop [rax+rax*1], ax
0000773e7dfdd3c5  nop [rax+rax*1], eax
0000773e7dfdd3cd  mov eax, 0x410698
0000773e7dfdd3d2  mov [r15+0x100], rax
0000773e7dfdd3d9  jmp 0x0000773E7DDFE110
0000773e7dfdd3de  cmp dword ptr [r15+0x318], 0x00
0000773e7dfdd3e6  jz 0x0000773E7DFDD4C0
0000773e7dfdd3ec  nop [rax+rax*1], ax
0000773e7dfdd3f5  nop [rax+rax*1], eax
0000773e7dfdd3fd  mov eax, 0x41067C
0000773e7dfdd402  mov [r15+0x100], rax
0000773e7dfdd409  jmp 0x0000773E7DDFE110
0000773e7dfdd40e  int3
0000773e7dfdd40f  call 0x0000773E7DE0DC20
0000773e7dfdd414  jmp 0x0000773E7DFDD2F2
0000773e7dfdd419  call 0x0000773E7DE0E760
0000773e7dfdd41e  jmp 0x0000773E7DFDD301
0000773e7dfdd423  ucomisd xmm1, xmm15
0000773e7dfdd428  jp 0x0000773E7DFDD437
0000773e7dfdd42a  movaps xmm13, [0x0000773E7DBFE060]
0000773e7dfdd432  jmp 0x0000773E7DFDD36A
0000773e7dfdd437  vxorps xmm0, xmm1, xmm15
0000773e7dfdd43c  pextrw eax, xmm0, 0x03
0000773e7dfdd441  and eax, 0x7FF8
0000773e7dfdd446  cmp eax, 0x08
0000773e7dfdd449  jnz 0x0000773E7DFDD36A
0000773e7dfdd44f  movq rax, xmm15
0000773e7dfdd454  shl rax, 0x0D
0000773e7dfdd458  jbe 0x0000773E7DFDD36A
0000773e7dfdd45e  vorps xmm13, xmm15, [0x0000773E7DBFE070]
0000773e7dfdd466  jmp 0x0000773E7DFDD36A
0000773e7dfdd46b  ucomisd xmm1, xmm15
0000773e7dfdd470  jp 0x0000773E7DFDD47F
0000773e7dfdd472  movaps xmm14, [0x0000773E7DBFE060]
0000773e7dfdd47a  jmp 0x0000773E7DFDD397
0000773e7dfdd47f  vxorps xmm0, xmm1, xmm15
0000773e7dfdd484  pextrw eax, xmm0, 0x03
0000773e7dfdd489  and eax, 0x7FF8
0000773e7dfdd48e  cmp eax, 0x08
0000773e7dfdd491  jnz 0x0000773E7DFDD397
0000773e7dfdd497  movq rax, xmm15
0000773e7dfdd49c  shl rax, 0x0D
0000773e7dfdd4a0  jbe 0x0000773E7DFDD397
0000773e7dfdd4a6  vorps xmm14, xmm15, [0x0000773E7DBFE070]
0000773e7dfdd4ae  jmp 0x0000773E7DFDD397
0000773e7dfdd4b3  int3
0000773e7dfdd4b4  nop [rax+rax*1], ax
0000773e7dfdd4bd  nop [rax], eax
0000773e7dfdd4c0  mov rax, [r15+0x48]
0000773e7dfdd4c4  mov r14, [r15+0x50]
0000773e7dfdd4c8  lea r12, [r14+rax*1]
0000773e7dfdd4cc  movups xmm1, [r13+r12*1]
0000773e7dfdd4d2  movaps [r15+0x120], xmm1
0000773e7dfdd4da  lea r14, [rax+0x10]
0000773e7dfdd4de  mov [r15+0x48], r14
0000773e7dfdd4e2  xor eax, eax
0000773e7dfdd4e4  mov r12d, 0x200
0000773e7dfdd4ea  cmp r14, r12
0000773e7dfdd4ed  cmc
0000773e7dfdd4ee  lahf
0000773e7dfdd4ef  seto al
0000773e7dfdd4f2  mov [r15+0x108], eax
0000773e7dfdd4f9  pextrq rax, xmm1, 0x01
0000773e7dfdd500  movq xmm15, rax
0000773e7dfdd505  movaps [r15+0x130], xmm15
0000773e7dfdd50d  movaps xmm14, [r15+0x110]
0000773e7dfdd515  movq rax, xmm14
0000773e7dfdd51a  movq r14, xmm1
0000773e7dfdd51f  vmovq xmm1, rax
0000773e7dfdd524  vmovq xmm14, r14
0000773e7dfdd529  movaps xmm13, xmm1
0000773e7dfdd52d  addsd xmm13, xmm14
0000773e7dfdd532  ucomisd xmm13, xmm13
0000773e7dfdd537  jp 0x0000773E7DFDD5EC
0000773e7dfdd53d  movq xmm13, xmm13
0000773e7dfdd542  movq rax, xmm13
0000773e7dfdd547  movq r14, xmm15
0000773e7dfdd54c  vmovq xmm1, rax
0000773e7dfdd551  vmovq xmm15, r14
0000773e7dfdd556  movaps xmm14, xmm1
0000773e7dfdd55a  addsd xmm14, xmm15
0000773e7dfdd55f  ucomisd xmm14, xmm14
0000773e7dfdd564  jp 0x0000773E7DFDD634
0000773e7dfdd56a  movq xmm14, xmm14
0000773e7dfdd56f  movaps [r15+0x110], xmm14
0000773e7dfdd577  mov eax, [r15+0x108]
0000773e7dfdd57e  sahf
0000773e7dfdd57f  jnz 0x0000773E7DFDD5B1
0000773e7dfdd581  cmp dword ptr [r15+0x318], 0x00
0000773e7dfdd589  jz 0x0000773E7DFDD680
0000773e7dfdd58f  nop [rax+rax*1], ax
0000773e7dfdd598  nop [rax+rax*1], eax
0000773e7dfdd5a0  mov eax, 0x410698
0000773e7dfdd5a5  mov [r15+0x100], rax
0000773e7dfdd5ac  jmp 0x0000773E7DDFE110
0000773e7dfdd5b1  cmp dword ptr [r15+0x318], 0x00
0000773e7dfdd5b9  jz 0x0000773E7DFDD4C0
0000773e7dfdd5bf  nop [rax+rax*1], ax
0000773e7dfdd5c8  nop [rax+rax*1], eax
0000773e7dfdd5d0  mov eax, 0x41067C
0000773e7dfdd5d5  mov [r15+0x100], rax
0000773e7dfdd5dc  jmp 0x0000773E7DDFE110
0000773e7dfdd5e1  int3
0000773e7dfdd5e2  call 0x0000773E7DEB52F0
0000773e7dfdd5e7  jmp 0x0000773E7DFDD4D2
0000773e7dfdd5ec  ucomisd xmm1, xmm14
0000773e7dfdd5f1  jp 0x0000773E7DFDD600
0000773e7dfdd5f3  movaps xmm13, [0x0000773E7DBFE060]
0000773e7dfdd5fb  jmp 0x0000773E7DFDD53D
0000773e7dfdd600  vxorps xmm0, xmm1, xmm14
0000773e7dfdd605  pextrw eax, xmm0, 0x03
0000773e7dfdd60a  and eax, 0x7FF8
0000773e7dfdd60f  cmp eax, 0x08
0000773e7dfdd612  jnz 0x0000773E7DFDD53D
0000773e7dfdd618  movq rax, xmm14
0000773e7dfdd61d  shl rax, 0x0D
0000773e7dfdd621  jbe 0x0000773E7DFDD53D
0000773e7dfdd627  vorps xmm13, xmm14, [0x0000773E7DBFE070]
0000773e7dfdd62f  jmp 0x0000773E7DFDD53D
0000773e7dfdd634  ucomisd xmm1, xmm15
0000773e7dfdd639  jp 0x0000773E7DFDD648
0000773e7dfdd63b  movaps xmm14, [0x0000773E7DBFE060]
0000773e7dfdd643  jmp 0x0000773E7DFDD56A
0000773e7dfdd648  vxorps xmm0, xmm1, xmm15
0000773e7dfdd64d  pextrw eax, xmm0, 0x03
0000773e7dfdd652  and eax, 0x7FF8
0000773e7dfdd657  cmp eax, 0x08
0000773e7dfdd65a  jnz 0x0000773E7DFDD56A
0000773e7dfdd660  movq rax, xmm15
0000773e7dfdd665  shl rax, 0x0D
0000773e7dfdd669  jbe 0x0000773E7DFDD56A
0000773e7dfdd66f  vorps xmm14, xmm15, [0x0000773E7DBFE070]
0000773e7dfdd677  jmp 0x0000773E7DFDD56A
0000773e7dfdd67c  int3
0000773e7dfdd67d  nop [rax], eax
0000773e7dfdd680  mov rax, [r15+0xF8]
0000773e7dfdd687  lea r14, [rax+0x1A0]
0000773e7dfdd68e  mov r12, [r13+r14*1]
0000773e7dfdd693  lea r14, [rax+0x1A8]
0000773e7dfdd69a  mov r11, [r13+r14*1]
0000773e7dfdd69f  mov [r15+0xA0], r12
0000773e7dfdd6a6  mov [r15+0x98], r11
0000773e7dfdd6ad  mov r14, [r15+0x40]
0000773e7dfdd6b1  lea r12, [r14+0xC50]
0000773e7dfdd6b8  movaps xmm1, [r15+0x110]
0000773e7dfdd6c0  movq r14, xmm1
0000773e7dfdd6c5  mov [r13+r12*1], r14
0000773e7dfdd6ca  lea r14, [rax+0x190]
0000773e7dfdd6d1  mov r12, [r13+r14*1]
0000773e7dfdd6d6  lea r14, [rax+0x198]
0000773e7dfdd6dd  mov r11, [r13+r14*1]
0000773e7dfdd6e2  mov [r15+0xE8], r12
0000773e7dfdd6e9  mov [r15+0xF0], r11
0000773e7dfdd6f0  lea r14, [rax+0x180]
0000773e7dfdd6f7  mov r12, [r13+r14*1]
0000773e7dfdd6fc  lea r14, [rax+0x188]
0000773e7dfdd703  mov r10, [r13+r14*1]
0000773e7dfdd708  movq xmm1, r12
0000773e7dfdd70d  movq xmm15, r10
0000773e7dfdd712  movq xmm1, xmm1
0000773e7dfdd716  movq xmm1, xmm1
0000773e7dfdd71a  movaps [r15+0x1A0], xmm1
0000773e7dfdd722  movq xmm15, xmm15
0000773e7dfdd727  movq xmm15, xmm15
0000773e7dfdd72c  movaps [r15+0x190], xmm15
0000773e7dfdd734  lea r14, [rax+0x170]
0000773e7dfdd73b  mov r12, [r13+r14*1]
0000773e7dfdd740  lea r14, [rax+0x178]
0000773e7dfdd747  mov r10, [r13+r14*1]
0000773e7dfdd74c  movq xmm1, r12
0000773e7dfdd751  movq xmm15, r10
0000773e7dfdd756  movq xmm1, xmm1
0000773e7dfdd75a  movq xmm1, xmm1
0000773e7dfdd75e  movaps [r15+0x1C0], xmm1
0000773e7dfdd766  movq xmm15, xmm15
0000773e7dfdd76b  movq xmm15, xmm15
0000773e7dfdd770  movaps [r15+0x1B0], xmm15
0000773e7dfdd778  lea r14, [rax+0x160]
0000773e7dfdd77f  mov r12, [r13+r14*1]
0000773e7dfdd784  lea r14, [rax+0x168]
0000773e7dfdd78b  mov r10, [r13+r14*1]
0000773e7dfdd790  movq xmm1, r12
0000773e7dfdd795  movq xmm15, r10
0000773e7dfdd79a  movq xmm1, xmm1
0000773e7dfdd79e  movq xmm1, xmm1
0000773e7dfdd7a2  movaps [r15+0x1E0], xmm1
0000773e7dfdd7aa  movq xmm15, xmm15
0000773e7dfdd7af  movq xmm15, xmm15
0000773e7dfdd7b4  movaps [r15+0x1D0], xmm15
0000773e7dfdd7bc  lea r14, [rax+0x150]
0000773e7dfdd7c3  mov r12, [r13+r14*1]
0000773e7dfdd7c8  lea r14, [rax+0x158]
0000773e7dfdd7cf  mov r10, [r13+r14*1]
0000773e7dfdd7d4  movq xmm1, r12
0000773e7dfdd7d9  movq xmm15, r10
0000773e7dfdd7de  movq xmm1, xmm1
0000773e7dfdd7e2  movq xmm1, xmm1
0000773e7dfdd7e6  movaps [r15+0x200], xmm1
0000773e7dfdd7ee  movq xmm15, xmm15
0000773e7dfdd7f3  movq xmm15, xmm15
0000773e7dfdd7f8  movaps [r15+0x1F0], xmm15
0000773e7dfdd800  lea r14, [rax+0x1B0]
0000773e7dfdd807  mov [r15+0xF8], r14
0000773e7dfdd80e  mov [r15+0x100], r11
0000773e7dfdd815  jmp 0x0000773E7DFCE5C0
0000773e7dfdd81a  int3
0000773e7dfdd81b  call 0x0000773E7DEE27E0
0000773e7dfdd820  jmp 0x0000773E7DFDD693
0000773e7dfdd825  call 0x0000773E7DEE1570
0000773e7dfdd82a  jmp 0x0000773E7DFDD69F
0000773e7dfdd82f  call 0x0000773E7DEC3FE0
0000773e7dfdd834  jmp 0x0000773E7DFDD6CA
0000773e7dfdd839  call 0x0000773E7DEE27E0
0000773e7dfdd83e  jmp 0x0000773E7DFDD6D6
0000773e7dfdd843  call 0x0000773E7DEE1570
0000773e7dfdd848  jmp 0x0000773E7DFDD6E2
0000773e7dfdd84d  call 0x0000773E7DEE27E0
0000773e7dfdd852  jmp 0x0000773E7DFDD6FC
0000773e7dfdd857  call 0x0000773E7DEE0300
0000773e7dfdd85c  jmp 0x0000773E7DFDD708
0000773e7dfdd861  call 0x0000773E7DEE27E0
0000773e7dfdd866  jmp 0x0000773E7DFDD740
0000773e7dfdd86b  call 0x0000773E7DEE0300
0000773e7dfdd870  jmp 0x0000773E7DFDD74C
0000773e7dfdd875  call 0x0000773E7DEE27E0
0000773e7dfdd87a  jmp 0x0000773E7DFDD784
0000773e7dfdd87f  call 0x0000773E7DEE0300
0000773e7dfdd884  jmp 0x0000773E7DFDD790
0000773e7dfdd889  call 0x0000773E7DEE27E0
0000773e7dfdd88e  jmp 0x0000773E7DFDD7C8
0000773e7dfdd893  call 0x0000773E7DEE0300
0000773e7dfdd898  jmp 0x0000773E7DFDD7D4
0000773e7dfdd89d  int3
0000773e7dfdd89e  nop
0000773e7dfdd8a0  mov qword ptr [r15+0x100], 0x04
0000773e7dfdd8ab  mov esi, 0x00
0000773e7dfdd8b0  mov edx, 0x09
0000773e7dfdd8b5  mov rdi, 0x7FFDE8975AF0
0000773e7dfdd8bf  mov rax, 0x567852DC7970
0000773e7dfdd8c9  call rax
0000773e7dfdd8cb  cmp dword ptr [r15+0x318], 0x00
0000773e7dfdd8d3  jnz 0x0000773E7DDFE110
0000773e7dfdd8d9  jmp 0x0000773E7DDFE0A0
0000773e7dfdd8de  int3
0000773e7dfdd8df  int3
