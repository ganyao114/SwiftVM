00007dc7c45ce69b  nop [rax+rax*1], eax
00007dc7c45ce6a0  mov qword ptr [r15+0x20], 0x420070
00007dc7c45ce6a8  xor eax, eax
00007dc7c45ce6aa  mov r14d, 0xB71B00
00007dc7c45ce6b0  mov r12d, 0x01
00007dc7c45ce6b6  sub r14, r12
00007dc7c45ce6b9  cmc
00007dc7c45ce6ba  lahf
00007dc7c45ce6bb  seto al
00007dc7c45ce6be  mov [r15+0x108], eax
00007dc7c45ce6c5  mov [r15+0x08], r14
00007dc7c45ce6c9  mov qword ptr [r15+0x10], 0x03
00007dc7c45ce6d1  mov eax, 0x03
00007dc7c45ce6d6  mov r14d, 0x03
00007dc7c45ce6dc  shrd rax, r14, 0x0D
00007dc7c45ce6e1  mov [rsp+0x10], rax
00007dc7c45ce6e6  mov r14, [rsp+0x10]
00007dc7c45ce6eb  shrd rax, r14, 0x33
00007dc7c45ce6f0  mov [r15+0x18], rax
00007dc7c45ce6f4  mov [r15], rax
00007dc7c45ce6f7  mov eax, [r15+0x108]
00007dc7c45ce6fe  sahf
00007dc7c45ce6ff  jnz 0x00007DC7C45CE731
00007dc7c45ce701  cmp dword ptr [r15+0x318], 0x00
00007dc7c45ce709  jz 0x00007DC7C45CE860
00007dc7c45ce70f  nop [rax+rax*1], ax
00007dc7c45ce718  nop [rax+rax*1], eax
00007dc7c45ce720  mov eax, 0x410064
00007dc7c45ce725  mov [r15+0x100], rax
00007dc7c45ce72c  jmp 0x00007DC7C43FE110
00007dc7c45ce731  cmp dword ptr [r15+0x318], 0x00
00007dc7c45ce739  jz 0x00007DC7C45CE770
00007dc7c45ce73f  nop [rax+rax*1], ax
00007dc7c45ce748  nop [rax+rax*1], eax
00007dc7c45ce750  mov eax, 0x41003C
00007dc7c45ce755  mov [r15+0x100], rax
00007dc7c45ce75c  jmp 0x00007DC7C43FE110
00007dc7c45ce761  int3
00007dc7c45ce762  int3
00007dc7c45ce763  nop [rax+rax*1], ax
00007dc7c45ce76c  nop [rax], eax
00007dc7c45ce770  mov rax, [r15+0x08]
00007dc7c45ce774  mov [rsp+0x10], rax
00007dc7c45ce779  xor eax, eax
00007dc7c45ce77b  mov r14, [rsp+0x10]
00007dc7c45ce780  mov r12d, 0x01
00007dc7c45ce786  sub r14, r12
00007dc7c45ce789  cmc
00007dc7c45ce78a  lahf
00007dc7c45ce78b  seto al
00007dc7c45ce78e  mov [r15+0x108], eax
00007dc7c45ce795  mov [r15+0x08], r14
00007dc7c45ce799  mov rax, [r15]
00007dc7c45ce79c  lea r14, [rax+0x08]
00007dc7c45ce7a0  lea rax, [r14-0x05]
00007dc7c45ce7a4  mov [r15+0x10], rax
00007dc7c45ce7a8  mov [rsp+0x10], rax
00007dc7c45ce7ad  shr rax, 0x07
00007dc7c45ce7b1  mov r14, [rsp+0x10]
00007dc7c45ce7b6  xor r14, rax
00007dc7c45ce7b9  mov rax, [rsp+0x10]
00007dc7c45ce7be  shr rax, 0x07
00007dc7c45ce7c2  xor r14, rax
00007dc7c45ce7c5  mov [rsp+0x10], r14
00007dc7c45ce7ca  mov rax, [rsp+0x10]
00007dc7c45ce7cf  shrd r14, rax, 0x0D
00007dc7c45ce7d4  mov [rsp+0x10], r14
00007dc7c45ce7d9  mov rax, [rsp+0x10]
00007dc7c45ce7de  shrd r14, rax, 0x33
00007dc7c45ce7e3  mov [r15+0x18], r14
00007dc7c45ce7e7  mov [r15], r14
00007dc7c45ce7ea  mov eax, [r15+0x108]
00007dc7c45ce7f1  sahf
00007dc7c45ce7f2  jnz 0x00007DC7C45CE824
00007dc7c45ce7f4  cmp dword ptr [r15+0x318], 0x00
00007dc7c45ce7fc  jz 0x00007DC7C45CE860
00007dc7c45ce802  nop [rax+rax*1], ax
00007dc7c45ce80b  nop [rax+rax*1], eax
00007dc7c45ce813  mov eax, 0x410064
00007dc7c45ce818  mov [r15+0x100], rax
00007dc7c45ce81f  jmp 0x00007DC7C43FE110
00007dc7c45ce824  cmp dword ptr [r15+0x318], 0x00
00007dc7c45ce82c  jz 0x00007DC7C45CE770
00007dc7c45ce832  nop [rax+rax*1], ax
00007dc7c45ce83b  nop [rax+rax*1], eax
00007dc7c45ce843  mov eax, 0x41003C
00007dc7c45ce848  mov [r15+0x100], rax
00007dc7c45ce84f  jmp 0x00007DC7C43FE110
00007dc7c45ce854  int3
00007dc7c45ce855  int3
00007dc7c45ce856  nop [rax+rax*1], ax
00007dc7c45ce85f  nop
00007dc7c45ce860  mov rax, [r15+0x20]
00007dc7c45ce864  mov r14, [r15]
00007dc7c45ce867  mov [r13+rax*1], r14
00007dc7c45ce86c  mov rax, [r15+0xF0]
00007dc7c45ce873  mov [r15+0x100], rax
00007dc7c45ce87a  jmp 0x00007DC7C45CE5C0
00007dc7c45ce87f  int3
00007dc7c45ce880  call 0x00007DC7C440E120
00007dc7c45ce885  jmp 0x00007DC7C45CE86C
00007dc7c45ce88a  int3
00007dc7c45ce88b  nop [rax+rax*1], eax
00007dc7c45ce890  mov qword ptr [r15+0x100], 0x04
00007dc7c45ce89b  mov esi, 0x00
00007dc7c45ce8a0  mov edx, 0x09
00007dc7c45ce8a5  mov rdi, 0x7FFFD3BB8840
00007dc7c45ce8af  mov rax, 0x5825E929E970
00007dc7c45ce8b9  call rax
00007dc7c45ce8bb  cmp dword ptr [r15+0x318], 0x00
00007dc7c45ce8c3  jnz 0x00007DC7C43FE110
00007dc7c45ce8c9  jmp 0x00007DC7C43FE0A0
00007dc7c45ce8ce  int3
00007dc7c45ce8cf  int3
