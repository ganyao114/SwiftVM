00007117d8dce69b  nop [rax+rax*1], eax
00007117d8dce6a0  mov qword ptr [r15+0x20], 0x420070
00007117d8dce6a8  xor eax, eax
00007117d8dce6aa  mov r14d, 0xB71B00
00007117d8dce6b0  mov r12d, 0x01
00007117d8dce6b6  sub r14, r12
00007117d8dce6b9  cmc
00007117d8dce6ba  lahf
00007117d8dce6bb  seto al
00007117d8dce6be  mov [r15+0x108], eax
00007117d8dce6c5  mov [r15+0x08], r14
00007117d8dce6c9  mov qword ptr [r15+0x10], 0x03
00007117d8dce6d1  mov eax, 0x03
00007117d8dce6d6  mov r14d, 0x03
00007117d8dce6dc  shrd rax, r14, 0x0D
00007117d8dce6e1  mov [rsp+0x10], rax
00007117d8dce6e6  mov r14, [rsp+0x10]
00007117d8dce6eb  shrd rax, r14, 0x33
00007117d8dce6f0  mov [r15+0x18], rax
00007117d8dce6f4  mov [r15], rax
00007117d8dce6f7  mov eax, [r15+0x108]
00007117d8dce6fe  sahf
00007117d8dce6ff  jnz 0x00007117D8DCE731
00007117d8dce701  cmp dword ptr [r15+0x318], 0x00
00007117d8dce709  jz 0x00007117D8DCE860
00007117d8dce70f  nop [rax+rax*1], ax
00007117d8dce718  nop [rax+rax*1], eax
00007117d8dce720  mov eax, 0x410064
00007117d8dce725  mov [r15+0x100], rax
00007117d8dce72c  jmp 0x00007117D8BFE110
00007117d8dce731  cmp dword ptr [r15+0x318], 0x00
00007117d8dce739  jz 0x00007117D8DCE770
00007117d8dce73f  nop [rax+rax*1], ax
00007117d8dce748  nop [rax+rax*1], eax
00007117d8dce750  mov eax, 0x41003C
00007117d8dce755  mov [r15+0x100], rax
00007117d8dce75c  jmp 0x00007117D8BFE110
00007117d8dce761  int3
00007117d8dce762  int3
00007117d8dce763  nop [rax+rax*1], ax
00007117d8dce76c  nop [rax], eax
00007117d8dce770  mov rax, [r15+0x08]
00007117d8dce774  mov [rsp+0x10], rax
00007117d8dce779  xor eax, eax
00007117d8dce77b  mov r14, [rsp+0x10]
00007117d8dce780  mov r12d, 0x01
00007117d8dce786  sub r14, r12
00007117d8dce789  cmc
00007117d8dce78a  lahf
00007117d8dce78b  seto al
00007117d8dce78e  mov [r15+0x108], eax
00007117d8dce795  mov [r15+0x08], r14
00007117d8dce799  mov rax, [r15]
00007117d8dce79c  lea r14, [rax+0x08]
00007117d8dce7a0  lea rax, [r14-0x05]
00007117d8dce7a4  mov [r15+0x10], rax
00007117d8dce7a8  mov [rsp+0x10], rax
00007117d8dce7ad  shr rax, 0x07
00007117d8dce7b1  mov r14, [rsp+0x10]
00007117d8dce7b6  xor r14, rax
00007117d8dce7b9  mov rax, [rsp+0x10]
00007117d8dce7be  shr rax, 0x07
00007117d8dce7c2  xor r14, rax
00007117d8dce7c5  mov [rsp+0x10], r14
00007117d8dce7ca  mov rax, [rsp+0x10]
00007117d8dce7cf  shrd r14, rax, 0x0D
00007117d8dce7d4  mov [rsp+0x10], r14
00007117d8dce7d9  mov rax, [rsp+0x10]
00007117d8dce7de  shrd r14, rax, 0x33
00007117d8dce7e3  mov [r15+0x18], r14
00007117d8dce7e7  mov [r15], r14
00007117d8dce7ea  mov eax, [r15+0x108]
00007117d8dce7f1  sahf
00007117d8dce7f2  jnz 0x00007117D8DCE824
00007117d8dce7f4  cmp dword ptr [r15+0x318], 0x00
00007117d8dce7fc  jz 0x00007117D8DCE860
00007117d8dce802  nop [rax+rax*1], ax
00007117d8dce80b  nop [rax+rax*1], eax
00007117d8dce813  mov eax, 0x410064
00007117d8dce818  mov [r15+0x100], rax
00007117d8dce81f  jmp 0x00007117D8BFE110
00007117d8dce824  cmp dword ptr [r15+0x318], 0x00
00007117d8dce82c  jz 0x00007117D8DCE770
00007117d8dce832  nop [rax+rax*1], ax
00007117d8dce83b  nop [rax+rax*1], eax
00007117d8dce843  mov eax, 0x41003C
00007117d8dce848  mov [r15+0x100], rax
00007117d8dce84f  jmp 0x00007117D8BFE110
00007117d8dce854  int3
00007117d8dce855  int3
00007117d8dce856  nop [rax+rax*1], ax
00007117d8dce85f  nop
00007117d8dce860  mov rax, [r15+0x20]
00007117d8dce864  mov r14, [r15]
00007117d8dce867  mov [r13+rax*1], r14
00007117d8dce86c  mov rax, [r15+0xF0]
00007117d8dce873  mov [r15+0x100], rax
00007117d8dce87a  jmp 0x00007117D8DCE5C0
00007117d8dce87f  int3
00007117d8dce880  call 0x00007117D8C0E120
00007117d8dce885  jmp 0x00007117D8DCE86C
00007117d8dce88a  int3
00007117d8dce88b  nop [rax+rax*1], eax
00007117d8dce890  mov qword ptr [r15+0x100], 0x04
00007117d8dce89b  mov esi, 0x00
00007117d8dce8a0  mov edx, 0x09
00007117d8dce8a5  mov rdi, 0x7FFEC8EF49D0
00007117d8dce8af  mov rax, 0x5818A3F7C970
00007117d8dce8b9  call rax
00007117d8dce8bb  cmp dword ptr [r15+0x318], 0x00
00007117d8dce8c3  jnz 0x00007117D8BFE110
00007117d8dce8c9  jmp 0x00007117D8BFE0A0
00007117d8dce8ce  int3
00007117d8dce8cf  int3
