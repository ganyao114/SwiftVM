0000775dd5fce69b  nop [rax+rax*1], eax
0000775dd5fce6a0  mov qword ptr [r15+0x20], 0x420070
0000775dd5fce6a8  xor eax, eax
0000775dd5fce6aa  mov r14d, 0xB71B00
0000775dd5fce6b0  mov r12d, 0x01
0000775dd5fce6b6  sub r14, r12
0000775dd5fce6b9  cmc
0000775dd5fce6ba  lahf
0000775dd5fce6bb  seto al
0000775dd5fce6be  mov [r15+0x108], eax
0000775dd5fce6c5  mov [r15+0x08], r14
0000775dd5fce6c9  mov qword ptr [r15+0x10], 0x03
0000775dd5fce6d1  mov eax, 0x03
0000775dd5fce6d6  mov r14d, 0x03
0000775dd5fce6dc  shrd rax, r14, 0x0D
0000775dd5fce6e1  mov [rsp+0x10], rax
0000775dd5fce6e6  mov r14, [rsp+0x10]
0000775dd5fce6eb  shrd rax, r14, 0x33
0000775dd5fce6f0  mov [r15+0x18], rax
0000775dd5fce6f4  mov [r15], rax
0000775dd5fce6f7  mov eax, [r15+0x108]
0000775dd5fce6fe  sahf
0000775dd5fce6ff  jnz 0x0000775DD5FCE731
0000775dd5fce701  cmp dword ptr [r15+0x318], 0x00
0000775dd5fce709  jz 0x0000775DD5FCE860
0000775dd5fce70f  nop [rax+rax*1], ax
0000775dd5fce718  nop [rax+rax*1], eax
0000775dd5fce720  mov eax, 0x410064
0000775dd5fce725  mov [r15+0x100], rax
0000775dd5fce72c  jmp 0x0000775DD5DFE110
0000775dd5fce731  cmp dword ptr [r15+0x318], 0x00
0000775dd5fce739  jz 0x0000775DD5FCE770
0000775dd5fce73f  nop [rax+rax*1], ax
0000775dd5fce748  nop [rax+rax*1], eax
0000775dd5fce750  mov eax, 0x41003C
0000775dd5fce755  mov [r15+0x100], rax
0000775dd5fce75c  jmp 0x0000775DD5DFE110
0000775dd5fce761  int3
0000775dd5fce762  int3
0000775dd5fce763  nop [rax+rax*1], ax
0000775dd5fce76c  nop [rax], eax
0000775dd5fce770  mov rax, [r15+0x08]
0000775dd5fce774  mov [rsp+0x10], rax
0000775dd5fce779  xor eax, eax
0000775dd5fce77b  mov r14, [rsp+0x10]
0000775dd5fce780  mov r12d, 0x01
0000775dd5fce786  sub r14, r12
0000775dd5fce789  cmc
0000775dd5fce78a  lahf
0000775dd5fce78b  seto al
0000775dd5fce78e  mov [r15+0x108], eax
0000775dd5fce795  mov [r15+0x08], r14
0000775dd5fce799  mov rax, [r15]
0000775dd5fce79c  lea r14, [rax+0x08]
0000775dd5fce7a0  lea rax, [r14-0x05]
0000775dd5fce7a4  mov [r15+0x10], rax
0000775dd5fce7a8  mov [rsp+0x10], rax
0000775dd5fce7ad  shr rax, 0x07
0000775dd5fce7b1  mov r14, [rsp+0x10]
0000775dd5fce7b6  xor r14, rax
0000775dd5fce7b9  mov rax, [rsp+0x10]
0000775dd5fce7be  shr rax, 0x07
0000775dd5fce7c2  xor r14, rax
0000775dd5fce7c5  mov [rsp+0x10], r14
0000775dd5fce7ca  mov rax, [rsp+0x10]
0000775dd5fce7cf  shrd r14, rax, 0x0D
0000775dd5fce7d4  mov [rsp+0x10], r14
0000775dd5fce7d9  mov rax, [rsp+0x10]
0000775dd5fce7de  shrd r14, rax, 0x33
0000775dd5fce7e3  mov [r15+0x18], r14
0000775dd5fce7e7  mov [r15], r14
0000775dd5fce7ea  mov eax, [r15+0x108]
0000775dd5fce7f1  sahf
0000775dd5fce7f2  jnz 0x0000775DD5FCE824
0000775dd5fce7f4  cmp dword ptr [r15+0x318], 0x00
0000775dd5fce7fc  jz 0x0000775DD5FCE860
0000775dd5fce802  nop [rax+rax*1], ax
0000775dd5fce80b  nop [rax+rax*1], eax
0000775dd5fce813  mov eax, 0x410064
0000775dd5fce818  mov [r15+0x100], rax
0000775dd5fce81f  jmp 0x0000775DD5DFE110
0000775dd5fce824  cmp dword ptr [r15+0x318], 0x00
0000775dd5fce82c  jz 0x0000775DD5FCE770
0000775dd5fce832  nop [rax+rax*1], ax
0000775dd5fce83b  nop [rax+rax*1], eax
0000775dd5fce843  mov eax, 0x41003C
0000775dd5fce848  mov [r15+0x100], rax
0000775dd5fce84f  jmp 0x0000775DD5DFE110
0000775dd5fce854  int3
0000775dd5fce855  int3
0000775dd5fce856  nop [rax+rax*1], ax
0000775dd5fce85f  nop
0000775dd5fce860  mov rax, [r15+0x20]
0000775dd5fce864  mov r14, [r15]
0000775dd5fce867  mov [r13+rax*1], r14
0000775dd5fce86c  mov rax, [r15+0xF0]
0000775dd5fce873  mov [r15+0x100], rax
0000775dd5fce87a  jmp 0x0000775DD5FCE5C0
0000775dd5fce87f  int3
0000775dd5fce880  call 0x0000775DD5E0E120
0000775dd5fce885  jmp 0x0000775DD5FCE86C
0000775dd5fce88a  int3
0000775dd5fce88b  nop [rax+rax*1], eax
0000775dd5fce890  mov qword ptr [r15+0x100], 0x04
0000775dd5fce89b  mov esi, 0x00
0000775dd5fce8a0  mov edx, 0x09
0000775dd5fce8a5  mov rdi, 0x7FFEB0C65930
0000775dd5fce8af  mov rax, 0x5E7566DC5970
0000775dd5fce8b9  call rax
0000775dd5fce8bb  cmp dword ptr [r15+0x318], 0x00
0000775dd5fce8c3  jnz 0x0000775DD5DFE110
0000775dd5fce8c9  jmp 0x0000775DD5DFE0A0
0000775dd5fce8ce  int3
0000775dd5fce8cf  int3
