00007b29efbce69b  nop [rax+rax*1], eax
00007b29efbce6a0  mov qword ptr [r15+0x20], 0x420070
00007b29efbce6a8  xor eax, eax
00007b29efbce6aa  mov r14d, 0xB71B00
00007b29efbce6b0  mov r12d, 0x01
00007b29efbce6b6  sub r14, r12
00007b29efbce6b9  cmc
00007b29efbce6ba  lahf
00007b29efbce6bb  seto al
00007b29efbce6be  mov [r15+0x108], eax
00007b29efbce6c5  mov [r15+0x08], r14
00007b29efbce6c9  mov qword ptr [r15+0x10], 0x03
00007b29efbce6d1  mov eax, 0x03
00007b29efbce6d6  mov r14d, 0x03
00007b29efbce6dc  shrd rax, r14, 0x0D
00007b29efbce6e1  mov [rsp+0x10], rax
00007b29efbce6e6  mov r14, [rsp+0x10]
00007b29efbce6eb  shrd rax, r14, 0x33
00007b29efbce6f0  mov [r15+0x18], rax
00007b29efbce6f4  mov [r15], rax
00007b29efbce6f7  mov eax, [r15+0x108]
00007b29efbce6fe  sahf
00007b29efbce6ff  jnz 0x00007B29EFBCE731
00007b29efbce701  cmp dword ptr [r15+0x318], 0x00
00007b29efbce709  jz 0x00007B29EFBCE860
00007b29efbce70f  nop [rax+rax*1], ax
00007b29efbce718  nop [rax+rax*1], eax
00007b29efbce720  mov eax, 0x410064
00007b29efbce725  mov [r15+0x100], rax
00007b29efbce72c  jmp 0x00007B29EF9FE110
00007b29efbce731  cmp dword ptr [r15+0x318], 0x00
00007b29efbce739  jz 0x00007B29EFBCE770
00007b29efbce73f  nop [rax+rax*1], ax
00007b29efbce748  nop [rax+rax*1], eax
00007b29efbce750  mov eax, 0x41003C
00007b29efbce755  mov [r15+0x100], rax
00007b29efbce75c  jmp 0x00007B29EF9FE110
00007b29efbce761  int3
00007b29efbce762  int3
00007b29efbce763  nop [rax+rax*1], ax
00007b29efbce76c  nop [rax], eax
00007b29efbce770  mov rax, [r15+0x08]
00007b29efbce774  mov [rsp+0x10], rax
00007b29efbce779  xor eax, eax
00007b29efbce77b  mov r14, [rsp+0x10]
00007b29efbce780  mov r12d, 0x01
00007b29efbce786  sub r14, r12
00007b29efbce789  cmc
00007b29efbce78a  lahf
00007b29efbce78b  seto al
00007b29efbce78e  mov [r15+0x108], eax
00007b29efbce795  mov [r15+0x08], r14
00007b29efbce799  mov rax, [r15]
00007b29efbce79c  lea r14, [rax+0x08]
00007b29efbce7a0  lea rax, [r14-0x05]
00007b29efbce7a4  mov [r15+0x10], rax
00007b29efbce7a8  mov [rsp+0x10], rax
00007b29efbce7ad  shr rax, 0x07
00007b29efbce7b1  mov r14, [rsp+0x10]
00007b29efbce7b6  xor r14, rax
00007b29efbce7b9  mov rax, [rsp+0x10]
00007b29efbce7be  shr rax, 0x07
00007b29efbce7c2  xor r14, rax
00007b29efbce7c5  mov [rsp+0x10], r14
00007b29efbce7ca  mov rax, [rsp+0x10]
00007b29efbce7cf  shrd r14, rax, 0x0D
00007b29efbce7d4  mov [rsp+0x10], r14
00007b29efbce7d9  mov rax, [rsp+0x10]
00007b29efbce7de  shrd r14, rax, 0x33
00007b29efbce7e3  mov [r15+0x18], r14
00007b29efbce7e7  mov [r15], r14
00007b29efbce7ea  mov eax, [r15+0x108]
00007b29efbce7f1  sahf
00007b29efbce7f2  jnz 0x00007B29EFBCE824
00007b29efbce7f4  cmp dword ptr [r15+0x318], 0x00
00007b29efbce7fc  jz 0x00007B29EFBCE860
00007b29efbce802  nop [rax+rax*1], ax
00007b29efbce80b  nop [rax+rax*1], eax
00007b29efbce813  mov eax, 0x410064
00007b29efbce818  mov [r15+0x100], rax
00007b29efbce81f  jmp 0x00007B29EF9FE110
00007b29efbce824  cmp dword ptr [r15+0x318], 0x00
00007b29efbce82c  jz 0x00007B29EFBCE770
00007b29efbce832  nop [rax+rax*1], ax
00007b29efbce83b  nop [rax+rax*1], eax
00007b29efbce843  mov eax, 0x41003C
00007b29efbce848  mov [r15+0x100], rax
00007b29efbce84f  jmp 0x00007B29EF9FE110
00007b29efbce854  int3
00007b29efbce855  int3
00007b29efbce856  nop [rax+rax*1], ax
00007b29efbce85f  nop
00007b29efbce860  mov rax, [r15+0x20]
00007b29efbce864  mov r14, [r15]
00007b29efbce867  mov [r13+rax*1], r14
00007b29efbce86c  mov rax, [r15+0xF0]
00007b29efbce873  mov [r15+0x100], rax
00007b29efbce87a  jmp 0x00007B29EFBCE5C0
00007b29efbce87f  int3
00007b29efbce880  call 0x00007B29EFA0E120
00007b29efbce885  jmp 0x00007B29EFBCE86C
00007b29efbce88a  int3
00007b29efbce88b  nop [rax+rax*1], eax
00007b29efbce890  mov qword ptr [r15+0x100], 0x04
00007b29efbce89b  mov esi, 0x00
00007b29efbce8a0  mov edx, 0x09
00007b29efbce8a5  mov rdi, 0x7FFE88899F10
00007b29efbce8af  mov rax, 0x63E4DBF18970
00007b29efbce8b9  call rax
00007b29efbce8bb  cmp dword ptr [r15+0x318], 0x00
00007b29efbce8c3  jnz 0x00007B29EF9FE110
00007b29efbce8c9  jmp 0x00007B29EF9FE0A0
00007b29efbce8ce  int3
00007b29efbce8cf  int3
