00007f8c5d1ce69b  nop [rax+rax*1], eax
00007f8c5d1ce6a0  mov qword ptr [r15+0x20], 0x420070
00007f8c5d1ce6a8  xor eax, eax
00007f8c5d1ce6aa  mov r14d, 0xB71B00
00007f8c5d1ce6b0  mov r12d, 0x01
00007f8c5d1ce6b6  sub r14, r12
00007f8c5d1ce6b9  cmc
00007f8c5d1ce6ba  lahf
00007f8c5d1ce6bb  seto al
00007f8c5d1ce6be  mov [r15+0x108], eax
00007f8c5d1ce6c5  mov [r15+0x08], r14
00007f8c5d1ce6c9  mov qword ptr [r15+0x10], 0x03
00007f8c5d1ce6d1  mov eax, 0x03
00007f8c5d1ce6d6  mov r14d, 0x03
00007f8c5d1ce6dc  shrd rax, r14, 0x0D
00007f8c5d1ce6e1  mov [rsp+0x10], rax
00007f8c5d1ce6e6  mov r14, [rsp+0x10]
00007f8c5d1ce6eb  shrd rax, r14, 0x33
00007f8c5d1ce6f0  mov [r15+0x18], rax
00007f8c5d1ce6f4  mov [r15], rax
00007f8c5d1ce6f7  mov eax, [r15+0x108]
00007f8c5d1ce6fe  sahf
00007f8c5d1ce6ff  jnz 0x00007F8C5D1CE731
00007f8c5d1ce701  cmp dword ptr [r15+0x318], 0x00
00007f8c5d1ce709  jz 0x00007F8C5D1CE860
00007f8c5d1ce70f  nop [rax+rax*1], ax
00007f8c5d1ce718  nop [rax+rax*1], eax
00007f8c5d1ce720  mov eax, 0x410064
00007f8c5d1ce725  mov [r15+0x100], rax
00007f8c5d1ce72c  jmp 0x00007F8C5CFFE110
00007f8c5d1ce731  cmp dword ptr [r15+0x318], 0x00
00007f8c5d1ce739  jz 0x00007F8C5D1CE770
00007f8c5d1ce73f  nop [rax+rax*1], ax
00007f8c5d1ce748  nop [rax+rax*1], eax
00007f8c5d1ce750  mov eax, 0x41003C
00007f8c5d1ce755  mov [r15+0x100], rax
00007f8c5d1ce75c  jmp 0x00007F8C5CFFE110
00007f8c5d1ce761  int3
00007f8c5d1ce762  int3
00007f8c5d1ce763  nop [rax+rax*1], ax
00007f8c5d1ce76c  nop [rax], eax
00007f8c5d1ce770  mov rax, [r15+0x08]
00007f8c5d1ce774  mov [rsp+0x10], rax
00007f8c5d1ce779  xor eax, eax
00007f8c5d1ce77b  mov r14, [rsp+0x10]
00007f8c5d1ce780  mov r12d, 0x01
00007f8c5d1ce786  sub r14, r12
00007f8c5d1ce789  cmc
00007f8c5d1ce78a  lahf
00007f8c5d1ce78b  seto al
00007f8c5d1ce78e  mov [r15+0x108], eax
00007f8c5d1ce795  mov [r15+0x08], r14
00007f8c5d1ce799  mov rax, [r15]
00007f8c5d1ce79c  lea r14, [rax+0x08]
00007f8c5d1ce7a0  lea rax, [r14-0x05]
00007f8c5d1ce7a4  mov [r15+0x10], rax
00007f8c5d1ce7a8  mov [rsp+0x10], rax
00007f8c5d1ce7ad  shr rax, 0x07
00007f8c5d1ce7b1  mov r14, [rsp+0x10]
00007f8c5d1ce7b6  xor r14, rax
00007f8c5d1ce7b9  mov rax, [rsp+0x10]
00007f8c5d1ce7be  shr rax, 0x07
00007f8c5d1ce7c2  xor r14, rax
00007f8c5d1ce7c5  mov [rsp+0x10], r14
00007f8c5d1ce7ca  mov rax, [rsp+0x10]
00007f8c5d1ce7cf  shrd r14, rax, 0x0D
00007f8c5d1ce7d4  mov [rsp+0x10], r14
00007f8c5d1ce7d9  mov rax, [rsp+0x10]
00007f8c5d1ce7de  shrd r14, rax, 0x33
00007f8c5d1ce7e3  mov [r15+0x18], r14
00007f8c5d1ce7e7  mov [r15], r14
00007f8c5d1ce7ea  mov eax, [r15+0x108]
00007f8c5d1ce7f1  sahf
00007f8c5d1ce7f2  jnz 0x00007F8C5D1CE824
00007f8c5d1ce7f4  cmp dword ptr [r15+0x318], 0x00
00007f8c5d1ce7fc  jz 0x00007F8C5D1CE860
00007f8c5d1ce802  nop [rax+rax*1], ax
00007f8c5d1ce80b  nop [rax+rax*1], eax
00007f8c5d1ce813  mov eax, 0x410064
00007f8c5d1ce818  mov [r15+0x100], rax
00007f8c5d1ce81f  jmp 0x00007F8C5CFFE110
00007f8c5d1ce824  cmp dword ptr [r15+0x318], 0x00
00007f8c5d1ce82c  jz 0x00007F8C5D1CE770
00007f8c5d1ce832  nop [rax+rax*1], ax
00007f8c5d1ce83b  nop [rax+rax*1], eax
00007f8c5d1ce843  mov eax, 0x41003C
00007f8c5d1ce848  mov [r15+0x100], rax
00007f8c5d1ce84f  jmp 0x00007F8C5CFFE110
00007f8c5d1ce854  int3
00007f8c5d1ce855  int3
00007f8c5d1ce856  nop [rax+rax*1], ax
00007f8c5d1ce85f  nop
00007f8c5d1ce860  mov rax, [r15+0x20]
00007f8c5d1ce864  mov r14, [r15]
00007f8c5d1ce867  mov [r13+rax*1], r14
00007f8c5d1ce86c  mov rax, [r15+0xF0]
00007f8c5d1ce873  mov [r15+0x100], rax
00007f8c5d1ce87a  jmp 0x00007F8C5D1CE5C0
00007f8c5d1ce87f  int3
00007f8c5d1ce880  call 0x00007F8C5D00E120
00007f8c5d1ce885  jmp 0x00007F8C5D1CE86C
00007f8c5d1ce88a  int3
00007f8c5d1ce88b  nop [rax+rax*1], eax
00007f8c5d1ce890  mov qword ptr [r15+0x100], 0x04
00007f8c5d1ce89b  mov esi, 0x00
00007f8c5d1ce8a0  mov edx, 0x09
00007f8c5d1ce8a5  mov rdi, 0x7FFFA675FB70
00007f8c5d1ce8af  mov rax, 0x61FA64AA9970
00007f8c5d1ce8b9  call rax
00007f8c5d1ce8bb  cmp dword ptr [r15+0x318], 0x00
00007f8c5d1ce8c3  jnz 0x00007F8C5CFFE110
00007f8c5d1ce8c9  jmp 0x00007F8C5CFFE0A0
00007f8c5d1ce8ce  int3
00007f8c5d1ce8cf  int3
