00007e926d7ce69b  nop [rax+rax*1], eax
00007e926d7ce6a0  mov qword ptr [r15+0x20], 0x420070
00007e926d7ce6a8  xor eax, eax
00007e926d7ce6aa  mov r14d, 0xB71B00
00007e926d7ce6b0  mov r12d, 0x01
00007e926d7ce6b6  sub r14, r12
00007e926d7ce6b9  cmc
00007e926d7ce6ba  lahf
00007e926d7ce6bb  seto al
00007e926d7ce6be  mov [r15+0x108], eax
00007e926d7ce6c5  mov [r15+0x08], r14
00007e926d7ce6c9  mov qword ptr [r15+0x10], 0x03
00007e926d7ce6d1  mov eax, 0x03
00007e926d7ce6d6  mov r14d, 0x03
00007e926d7ce6dc  shrd rax, r14, 0x0D
00007e926d7ce6e1  mov [rsp+0x10], rax
00007e926d7ce6e6  mov r14, [rsp+0x10]
00007e926d7ce6eb  shrd rax, r14, 0x33
00007e926d7ce6f0  mov [r15+0x18], rax
00007e926d7ce6f4  mov [r15], rax
00007e926d7ce6f7  mov eax, [r15+0x108]
00007e926d7ce6fe  sahf
00007e926d7ce6ff  jnz 0x00007E926D7CE731
00007e926d7ce701  cmp dword ptr [r15+0x318], 0x00
00007e926d7ce709  jz 0x00007E926D7CE860
00007e926d7ce70f  nop [rax+rax*1], ax
00007e926d7ce718  nop [rax+rax*1], eax
00007e926d7ce720  mov eax, 0x410064
00007e926d7ce725  mov [r15+0x100], rax
00007e926d7ce72c  jmp 0x00007E926D5FE110
00007e926d7ce731  cmp dword ptr [r15+0x318], 0x00
00007e926d7ce739  jz 0x00007E926D7CE770
00007e926d7ce73f  nop [rax+rax*1], ax
00007e926d7ce748  nop [rax+rax*1], eax
00007e926d7ce750  mov eax, 0x41003C
00007e926d7ce755  mov [r15+0x100], rax
00007e926d7ce75c  jmp 0x00007E926D5FE110
00007e926d7ce761  int3
00007e926d7ce762  int3
00007e926d7ce763  nop [rax+rax*1], ax
00007e926d7ce76c  nop [rax], eax
00007e926d7ce770  mov rax, [r15+0x08]
00007e926d7ce774  mov [rsp+0x10], rax
00007e926d7ce779  xor eax, eax
00007e926d7ce77b  mov r14, [rsp+0x10]
00007e926d7ce780  mov r12d, 0x01
00007e926d7ce786  sub r14, r12
00007e926d7ce789  cmc
00007e926d7ce78a  lahf
00007e926d7ce78b  seto al
00007e926d7ce78e  mov [r15+0x108], eax
00007e926d7ce795  mov [r15+0x08], r14
00007e926d7ce799  mov rax, [r15]
00007e926d7ce79c  lea r14, [rax+0x08]
00007e926d7ce7a0  lea rax, [r14-0x05]
00007e926d7ce7a4  mov [r15+0x10], rax
00007e926d7ce7a8  mov [rsp+0x10], rax
00007e926d7ce7ad  shr rax, 0x07
00007e926d7ce7b1  mov r14, [rsp+0x10]
00007e926d7ce7b6  xor r14, rax
00007e926d7ce7b9  mov rax, [rsp+0x10]
00007e926d7ce7be  shr rax, 0x07
00007e926d7ce7c2  xor r14, rax
00007e926d7ce7c5  mov [rsp+0x10], r14
00007e926d7ce7ca  mov rax, [rsp+0x10]
00007e926d7ce7cf  shrd r14, rax, 0x0D
00007e926d7ce7d4  mov [rsp+0x10], r14
00007e926d7ce7d9  mov rax, [rsp+0x10]
00007e926d7ce7de  shrd r14, rax, 0x33
00007e926d7ce7e3  mov [r15+0x18], r14
00007e926d7ce7e7  mov [r15], r14
00007e926d7ce7ea  mov eax, [r15+0x108]
00007e926d7ce7f1  sahf
00007e926d7ce7f2  jnz 0x00007E926D7CE824
00007e926d7ce7f4  cmp dword ptr [r15+0x318], 0x00
00007e926d7ce7fc  jz 0x00007E926D7CE860
00007e926d7ce802  nop [rax+rax*1], ax
00007e926d7ce80b  nop [rax+rax*1], eax
00007e926d7ce813  mov eax, 0x410064
00007e926d7ce818  mov [r15+0x100], rax
00007e926d7ce81f  jmp 0x00007E926D5FE110
00007e926d7ce824  cmp dword ptr [r15+0x318], 0x00
00007e926d7ce82c  jz 0x00007E926D7CE770
00007e926d7ce832  nop [rax+rax*1], ax
00007e926d7ce83b  nop [rax+rax*1], eax
00007e926d7ce843  mov eax, 0x41003C
00007e926d7ce848  mov [r15+0x100], rax
00007e926d7ce84f  jmp 0x00007E926D5FE110
00007e926d7ce854  int3
00007e926d7ce855  int3
00007e926d7ce856  nop [rax+rax*1], ax
00007e926d7ce85f  nop
00007e926d7ce860  mov rax, [r15+0x20]
00007e926d7ce864  mov r14, [r15]
00007e926d7ce867  mov [r13+rax*1], r14
00007e926d7ce86c  mov rax, [r15+0xF0]
00007e926d7ce873  mov [r15+0x100], rax
00007e926d7ce87a  jmp 0x00007E926D7CE5C0
00007e926d7ce87f  int3
00007e926d7ce880  call 0x00007E926D60E120
00007e926d7ce885  jmp 0x00007E926D7CE86C
00007e926d7ce88a  int3
00007e926d7ce88b  nop [rax+rax*1], eax
00007e926d7ce890  mov qword ptr [r15+0x100], 0x04
00007e926d7ce89b  mov esi, 0x00
00007e926d7ce8a0  mov edx, 0x09
00007e926d7ce8a5  mov rdi, 0x7FFD864F8A00
00007e926d7ce8af  mov rax, 0x602DD1282970
00007e926d7ce8b9  call rax
00007e926d7ce8bb  cmp dword ptr [r15+0x318], 0x00
00007e926d7ce8c3  jnz 0x00007E926D5FE110
00007e926d7ce8c9  jmp 0x00007E926D5FE0A0
00007e926d7ce8ce  int3
00007e926d7ce8cf  int3
