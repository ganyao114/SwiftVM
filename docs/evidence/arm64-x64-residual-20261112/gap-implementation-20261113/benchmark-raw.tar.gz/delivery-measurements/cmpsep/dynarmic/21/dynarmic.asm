00007327a4dce69b  nop [rax+rax*1], eax
00007327a4dce6a0  mov qword ptr [r15+0x20], 0x420070
00007327a4dce6a8  xor eax, eax
00007327a4dce6aa  mov r14d, 0xB71B00
00007327a4dce6b0  mov r12d, 0x01
00007327a4dce6b6  sub r14, r12
00007327a4dce6b9  cmc
00007327a4dce6ba  lahf
00007327a4dce6bb  seto al
00007327a4dce6be  mov [r15+0x108], eax
00007327a4dce6c5  mov [r15+0x08], r14
00007327a4dce6c9  mov qword ptr [r15+0x10], 0x03
00007327a4dce6d1  mov eax, 0x03
00007327a4dce6d6  mov r14d, 0x03
00007327a4dce6dc  shrd rax, r14, 0x0D
00007327a4dce6e1  mov [rsp+0x10], rax
00007327a4dce6e6  mov r14, [rsp+0x10]
00007327a4dce6eb  shrd rax, r14, 0x33
00007327a4dce6f0  mov [r15+0x18], rax
00007327a4dce6f4  mov [r15], rax
00007327a4dce6f7  mov eax, [r15+0x108]
00007327a4dce6fe  sahf
00007327a4dce6ff  jnz 0x00007327A4DCE731
00007327a4dce701  cmp dword ptr [r15+0x318], 0x00
00007327a4dce709  jz 0x00007327A4DCE860
00007327a4dce70f  nop [rax+rax*1], ax
00007327a4dce718  nop [rax+rax*1], eax
00007327a4dce720  mov eax, 0x410064
00007327a4dce725  mov [r15+0x100], rax
00007327a4dce72c  jmp 0x00007327A4BFE110
00007327a4dce731  cmp dword ptr [r15+0x318], 0x00
00007327a4dce739  jz 0x00007327A4DCE770
00007327a4dce73f  nop [rax+rax*1], ax
00007327a4dce748  nop [rax+rax*1], eax
00007327a4dce750  mov eax, 0x41003C
00007327a4dce755  mov [r15+0x100], rax
00007327a4dce75c  jmp 0x00007327A4BFE110
00007327a4dce761  int3
00007327a4dce762  int3
00007327a4dce763  nop [rax+rax*1], ax
00007327a4dce76c  nop [rax], eax
00007327a4dce770  mov rax, [r15+0x08]
00007327a4dce774  mov [rsp+0x10], rax
00007327a4dce779  xor eax, eax
00007327a4dce77b  mov r14, [rsp+0x10]
00007327a4dce780  mov r12d, 0x01
00007327a4dce786  sub r14, r12
00007327a4dce789  cmc
00007327a4dce78a  lahf
00007327a4dce78b  seto al
00007327a4dce78e  mov [r15+0x108], eax
00007327a4dce795  mov [r15+0x08], r14
00007327a4dce799  mov rax, [r15]
00007327a4dce79c  lea r14, [rax+0x08]
00007327a4dce7a0  lea rax, [r14-0x05]
00007327a4dce7a4  mov [r15+0x10], rax
00007327a4dce7a8  mov [rsp+0x10], rax
00007327a4dce7ad  shr rax, 0x07
00007327a4dce7b1  mov r14, [rsp+0x10]
00007327a4dce7b6  xor r14, rax
00007327a4dce7b9  mov rax, [rsp+0x10]
00007327a4dce7be  shr rax, 0x07
00007327a4dce7c2  xor r14, rax
00007327a4dce7c5  mov [rsp+0x10], r14
00007327a4dce7ca  mov rax, [rsp+0x10]
00007327a4dce7cf  shrd r14, rax, 0x0D
00007327a4dce7d4  mov [rsp+0x10], r14
00007327a4dce7d9  mov rax, [rsp+0x10]
00007327a4dce7de  shrd r14, rax, 0x33
00007327a4dce7e3  mov [r15+0x18], r14
00007327a4dce7e7  mov [r15], r14
00007327a4dce7ea  mov eax, [r15+0x108]
00007327a4dce7f1  sahf
00007327a4dce7f2  jnz 0x00007327A4DCE824
00007327a4dce7f4  cmp dword ptr [r15+0x318], 0x00
00007327a4dce7fc  jz 0x00007327A4DCE860
00007327a4dce802  nop [rax+rax*1], ax
00007327a4dce80b  nop [rax+rax*1], eax
00007327a4dce813  mov eax, 0x410064
00007327a4dce818  mov [r15+0x100], rax
00007327a4dce81f  jmp 0x00007327A4BFE110
00007327a4dce824  cmp dword ptr [r15+0x318], 0x00
00007327a4dce82c  jz 0x00007327A4DCE770
00007327a4dce832  nop [rax+rax*1], ax
00007327a4dce83b  nop [rax+rax*1], eax
00007327a4dce843  mov eax, 0x41003C
00007327a4dce848  mov [r15+0x100], rax
00007327a4dce84f  jmp 0x00007327A4BFE110
00007327a4dce854  int3
00007327a4dce855  int3
00007327a4dce856  nop [rax+rax*1], ax
00007327a4dce85f  nop
00007327a4dce860  mov rax, [r15+0x20]
00007327a4dce864  mov r14, [r15]
00007327a4dce867  mov [r13+rax*1], r14
00007327a4dce86c  mov rax, [r15+0xF0]
00007327a4dce873  mov [r15+0x100], rax
00007327a4dce87a  jmp 0x00007327A4DCE5C0
00007327a4dce87f  int3
00007327a4dce880  call 0x00007327A4C0E120
00007327a4dce885  jmp 0x00007327A4DCE86C
00007327a4dce88a  int3
00007327a4dce88b  nop [rax+rax*1], eax
00007327a4dce890  mov qword ptr [r15+0x100], 0x04
00007327a4dce89b  mov esi, 0x00
00007327a4dce8a0  mov edx, 0x09
00007327a4dce8a5  mov rdi, 0x7FFC75231190
00007327a4dce8af  mov rax, 0x6396C0D93970
00007327a4dce8b9  call rax
00007327a4dce8bb  cmp dword ptr [r15+0x318], 0x00
00007327a4dce8c3  jnz 0x00007327A4BFE110
00007327a4dce8c9  jmp 0x00007327A4BFE0A0
00007327a4dce8ce  int3
00007327a4dce8cf  int3
