00007374c2bce69b  nop [rax+rax*1], eax
00007374c2bce6a0  mov qword ptr [r15+0x20], 0x420070
00007374c2bce6a8  xor eax, eax
00007374c2bce6aa  mov r14d, 0xB71B00
00007374c2bce6b0  mov r12d, 0x01
00007374c2bce6b6  sub r14, r12
00007374c2bce6b9  cmc
00007374c2bce6ba  lahf
00007374c2bce6bb  seto al
00007374c2bce6be  mov [r15+0x108], eax
00007374c2bce6c5  mov [r15+0x08], r14
00007374c2bce6c9  mov qword ptr [r15+0x10], 0x03
00007374c2bce6d1  mov eax, 0x03
00007374c2bce6d6  mov r14d, 0x03
00007374c2bce6dc  shrd rax, r14, 0x0D
00007374c2bce6e1  mov [rsp+0x10], rax
00007374c2bce6e6  mov r14, [rsp+0x10]
00007374c2bce6eb  shrd rax, r14, 0x33
00007374c2bce6f0  mov [r15+0x18], rax
00007374c2bce6f4  mov [r15], rax
00007374c2bce6f7  mov eax, [r15+0x108]
00007374c2bce6fe  sahf
00007374c2bce6ff  jnz 0x00007374C2BCE731
00007374c2bce701  cmp dword ptr [r15+0x318], 0x00
00007374c2bce709  jz 0x00007374C2BCE860
00007374c2bce70f  nop [rax+rax*1], ax
00007374c2bce718  nop [rax+rax*1], eax
00007374c2bce720  mov eax, 0x410064
00007374c2bce725  mov [r15+0x100], rax
00007374c2bce72c  jmp 0x00007374C29FE110
00007374c2bce731  cmp dword ptr [r15+0x318], 0x00
00007374c2bce739  jz 0x00007374C2BCE770
00007374c2bce73f  nop [rax+rax*1], ax
00007374c2bce748  nop [rax+rax*1], eax
00007374c2bce750  mov eax, 0x41003C
00007374c2bce755  mov [r15+0x100], rax
00007374c2bce75c  jmp 0x00007374C29FE110
00007374c2bce761  int3
00007374c2bce762  int3
00007374c2bce763  nop [rax+rax*1], ax
00007374c2bce76c  nop [rax], eax
00007374c2bce770  mov rax, [r15+0x08]
00007374c2bce774  mov [rsp+0x10], rax
00007374c2bce779  xor eax, eax
00007374c2bce77b  mov r14, [rsp+0x10]
00007374c2bce780  mov r12d, 0x01
00007374c2bce786  sub r14, r12
00007374c2bce789  cmc
00007374c2bce78a  lahf
00007374c2bce78b  seto al
00007374c2bce78e  mov [r15+0x108], eax
00007374c2bce795  mov [r15+0x08], r14
00007374c2bce799  mov rax, [r15]
00007374c2bce79c  lea r14, [rax+0x08]
00007374c2bce7a0  lea rax, [r14-0x05]
00007374c2bce7a4  mov [r15+0x10], rax
00007374c2bce7a8  mov [rsp+0x10], rax
00007374c2bce7ad  shr rax, 0x07
00007374c2bce7b1  mov r14, [rsp+0x10]
00007374c2bce7b6  xor r14, rax
00007374c2bce7b9  mov rax, [rsp+0x10]
00007374c2bce7be  shr rax, 0x07
00007374c2bce7c2  xor r14, rax
00007374c2bce7c5  mov [rsp+0x10], r14
00007374c2bce7ca  mov rax, [rsp+0x10]
00007374c2bce7cf  shrd r14, rax, 0x0D
00007374c2bce7d4  mov [rsp+0x10], r14
00007374c2bce7d9  mov rax, [rsp+0x10]
00007374c2bce7de  shrd r14, rax, 0x33
00007374c2bce7e3  mov [r15+0x18], r14
00007374c2bce7e7  mov [r15], r14
00007374c2bce7ea  mov eax, [r15+0x108]
00007374c2bce7f1  sahf
00007374c2bce7f2  jnz 0x00007374C2BCE824
00007374c2bce7f4  cmp dword ptr [r15+0x318], 0x00
00007374c2bce7fc  jz 0x00007374C2BCE860
00007374c2bce802  nop [rax+rax*1], ax
00007374c2bce80b  nop [rax+rax*1], eax
00007374c2bce813  mov eax, 0x410064
00007374c2bce818  mov [r15+0x100], rax
00007374c2bce81f  jmp 0x00007374C29FE110
00007374c2bce824  cmp dword ptr [r15+0x318], 0x00
00007374c2bce82c  jz 0x00007374C2BCE770
00007374c2bce832  nop [rax+rax*1], ax
00007374c2bce83b  nop [rax+rax*1], eax
00007374c2bce843  mov eax, 0x41003C
00007374c2bce848  mov [r15+0x100], rax
00007374c2bce84f  jmp 0x00007374C29FE110
00007374c2bce854  int3
00007374c2bce855  int3
00007374c2bce856  nop [rax+rax*1], ax
00007374c2bce85f  nop
00007374c2bce860  mov rax, [r15+0x20]
00007374c2bce864  mov r14, [r15]
00007374c2bce867  mov [r13+rax*1], r14
00007374c2bce86c  mov rax, [r15+0xF0]
00007374c2bce873  mov [r15+0x100], rax
00007374c2bce87a  jmp 0x00007374C2BCE5C0
00007374c2bce87f  int3
00007374c2bce880  call 0x00007374C2A0E120
00007374c2bce885  jmp 0x00007374C2BCE86C
00007374c2bce88a  int3
00007374c2bce88b  nop [rax+rax*1], eax
00007374c2bce890  mov qword ptr [r15+0x100], 0x04
00007374c2bce89b  mov esi, 0x00
00007374c2bce8a0  mov edx, 0x09
00007374c2bce8a5  mov rdi, 0x7FFC8D43EC30
00007374c2bce8af  mov rax, 0x5F8C4F936970
00007374c2bce8b9  call rax
00007374c2bce8bb  cmp dword ptr [r15+0x318], 0x00
00007374c2bce8c3  jnz 0x00007374C29FE110
00007374c2bce8c9  jmp 0x00007374C29FE0A0
00007374c2bce8ce  int3
00007374c2bce8cf  int3
