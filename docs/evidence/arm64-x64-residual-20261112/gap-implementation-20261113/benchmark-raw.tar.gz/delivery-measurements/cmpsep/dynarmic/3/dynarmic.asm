000073f9fa9ce69b  nop [rax+rax*1], eax
000073f9fa9ce6a0  mov qword ptr [r15+0x20], 0x420070
000073f9fa9ce6a8  xor eax, eax
000073f9fa9ce6aa  mov r14d, 0xB71B00
000073f9fa9ce6b0  mov r12d, 0x01
000073f9fa9ce6b6  sub r14, r12
000073f9fa9ce6b9  cmc
000073f9fa9ce6ba  lahf
000073f9fa9ce6bb  seto al
000073f9fa9ce6be  mov [r15+0x108], eax
000073f9fa9ce6c5  mov [r15+0x08], r14
000073f9fa9ce6c9  mov qword ptr [r15+0x10], 0x03
000073f9fa9ce6d1  mov eax, 0x03
000073f9fa9ce6d6  mov r14d, 0x03
000073f9fa9ce6dc  shrd rax, r14, 0x0D
000073f9fa9ce6e1  mov [rsp+0x10], rax
000073f9fa9ce6e6  mov r14, [rsp+0x10]
000073f9fa9ce6eb  shrd rax, r14, 0x33
000073f9fa9ce6f0  mov [r15+0x18], rax
000073f9fa9ce6f4  mov [r15], rax
000073f9fa9ce6f7  mov eax, [r15+0x108]
000073f9fa9ce6fe  sahf
000073f9fa9ce6ff  jnz 0x000073F9FA9CE731
000073f9fa9ce701  cmp dword ptr [r15+0x318], 0x00
000073f9fa9ce709  jz 0x000073F9FA9CE860
000073f9fa9ce70f  nop [rax+rax*1], ax
000073f9fa9ce718  nop [rax+rax*1], eax
000073f9fa9ce720  mov eax, 0x410064
000073f9fa9ce725  mov [r15+0x100], rax
000073f9fa9ce72c  jmp 0x000073F9FA7FE110
000073f9fa9ce731  cmp dword ptr [r15+0x318], 0x00
000073f9fa9ce739  jz 0x000073F9FA9CE770
000073f9fa9ce73f  nop [rax+rax*1], ax
000073f9fa9ce748  nop [rax+rax*1], eax
000073f9fa9ce750  mov eax, 0x41003C
000073f9fa9ce755  mov [r15+0x100], rax
000073f9fa9ce75c  jmp 0x000073F9FA7FE110
000073f9fa9ce761  int3
000073f9fa9ce762  int3
000073f9fa9ce763  nop [rax+rax*1], ax
000073f9fa9ce76c  nop [rax], eax
000073f9fa9ce770  mov rax, [r15+0x08]
000073f9fa9ce774  mov [rsp+0x10], rax
000073f9fa9ce779  xor eax, eax
000073f9fa9ce77b  mov r14, [rsp+0x10]
000073f9fa9ce780  mov r12d, 0x01
000073f9fa9ce786  sub r14, r12
000073f9fa9ce789  cmc
000073f9fa9ce78a  lahf
000073f9fa9ce78b  seto al
000073f9fa9ce78e  mov [r15+0x108], eax
000073f9fa9ce795  mov [r15+0x08], r14
000073f9fa9ce799  mov rax, [r15]
000073f9fa9ce79c  lea r14, [rax+0x08]
000073f9fa9ce7a0  lea rax, [r14-0x05]
000073f9fa9ce7a4  mov [r15+0x10], rax
000073f9fa9ce7a8  mov [rsp+0x10], rax
000073f9fa9ce7ad  shr rax, 0x07
000073f9fa9ce7b1  mov r14, [rsp+0x10]
000073f9fa9ce7b6  xor r14, rax
000073f9fa9ce7b9  mov rax, [rsp+0x10]
000073f9fa9ce7be  shr rax, 0x07
000073f9fa9ce7c2  xor r14, rax
000073f9fa9ce7c5  mov [rsp+0x10], r14
000073f9fa9ce7ca  mov rax, [rsp+0x10]
000073f9fa9ce7cf  shrd r14, rax, 0x0D
000073f9fa9ce7d4  mov [rsp+0x10], r14
000073f9fa9ce7d9  mov rax, [rsp+0x10]
000073f9fa9ce7de  shrd r14, rax, 0x33
000073f9fa9ce7e3  mov [r15+0x18], r14
000073f9fa9ce7e7  mov [r15], r14
000073f9fa9ce7ea  mov eax, [r15+0x108]
000073f9fa9ce7f1  sahf
000073f9fa9ce7f2  jnz 0x000073F9FA9CE824
000073f9fa9ce7f4  cmp dword ptr [r15+0x318], 0x00
000073f9fa9ce7fc  jz 0x000073F9FA9CE860
000073f9fa9ce802  nop [rax+rax*1], ax
000073f9fa9ce80b  nop [rax+rax*1], eax
000073f9fa9ce813  mov eax, 0x410064
000073f9fa9ce818  mov [r15+0x100], rax
000073f9fa9ce81f  jmp 0x000073F9FA7FE110
000073f9fa9ce824  cmp dword ptr [r15+0x318], 0x00
000073f9fa9ce82c  jz 0x000073F9FA9CE770
000073f9fa9ce832  nop [rax+rax*1], ax
000073f9fa9ce83b  nop [rax+rax*1], eax
000073f9fa9ce843  mov eax, 0x41003C
000073f9fa9ce848  mov [r15+0x100], rax
000073f9fa9ce84f  jmp 0x000073F9FA7FE110
000073f9fa9ce854  int3
000073f9fa9ce855  int3
000073f9fa9ce856  nop [rax+rax*1], ax
000073f9fa9ce85f  nop
000073f9fa9ce860  mov rax, [r15+0x20]
000073f9fa9ce864  mov r14, [r15]
000073f9fa9ce867  mov [r13+rax*1], r14
000073f9fa9ce86c  mov rax, [r15+0xF0]
000073f9fa9ce873  mov [r15+0x100], rax
000073f9fa9ce87a  jmp 0x000073F9FA9CE5C0
000073f9fa9ce87f  int3
000073f9fa9ce880  call 0x000073F9FA80E120
000073f9fa9ce885  jmp 0x000073F9FA9CE86C
000073f9fa9ce88a  int3
000073f9fa9ce88b  nop [rax+rax*1], eax
000073f9fa9ce890  mov qword ptr [r15+0x100], 0x04
000073f9fa9ce89b  mov esi, 0x00
000073f9fa9ce8a0  mov edx, 0x09
000073f9fa9ce8a5  mov rdi, 0x7FFFB787AC20
000073f9fa9ce8af  mov rax, 0x5B31B8B81970
000073f9fa9ce8b9  call rax
000073f9fa9ce8bb  cmp dword ptr [r15+0x318], 0x00
000073f9fa9ce8c3  jnz 0x000073F9FA7FE110
000073f9fa9ce8c9  jmp 0x000073F9FA7FE0A0
000073f9fa9ce8ce  int3
000073f9fa9ce8cf  int3
