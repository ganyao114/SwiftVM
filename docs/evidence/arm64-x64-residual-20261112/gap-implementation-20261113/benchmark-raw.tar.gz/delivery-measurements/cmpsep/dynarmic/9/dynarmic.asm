000079db33dce69b  nop [rax+rax*1], eax
000079db33dce6a0  mov qword ptr [r15+0x20], 0x420070
000079db33dce6a8  xor eax, eax
000079db33dce6aa  mov r14d, 0xB71B00
000079db33dce6b0  mov r12d, 0x01
000079db33dce6b6  sub r14, r12
000079db33dce6b9  cmc
000079db33dce6ba  lahf
000079db33dce6bb  seto al
000079db33dce6be  mov [r15+0x108], eax
000079db33dce6c5  mov [r15+0x08], r14
000079db33dce6c9  mov qword ptr [r15+0x10], 0x03
000079db33dce6d1  mov eax, 0x03
000079db33dce6d6  mov r14d, 0x03
000079db33dce6dc  shrd rax, r14, 0x0D
000079db33dce6e1  mov [rsp+0x10], rax
000079db33dce6e6  mov r14, [rsp+0x10]
000079db33dce6eb  shrd rax, r14, 0x33
000079db33dce6f0  mov [r15+0x18], rax
000079db33dce6f4  mov [r15], rax
000079db33dce6f7  mov eax, [r15+0x108]
000079db33dce6fe  sahf
000079db33dce6ff  jnz 0x000079DB33DCE731
000079db33dce701  cmp dword ptr [r15+0x318], 0x00
000079db33dce709  jz 0x000079DB33DCE860
000079db33dce70f  nop [rax+rax*1], ax
000079db33dce718  nop [rax+rax*1], eax
000079db33dce720  mov eax, 0x410064
000079db33dce725  mov [r15+0x100], rax
000079db33dce72c  jmp 0x000079DB33BFE110
000079db33dce731  cmp dword ptr [r15+0x318], 0x00
000079db33dce739  jz 0x000079DB33DCE770
000079db33dce73f  nop [rax+rax*1], ax
000079db33dce748  nop [rax+rax*1], eax
000079db33dce750  mov eax, 0x41003C
000079db33dce755  mov [r15+0x100], rax
000079db33dce75c  jmp 0x000079DB33BFE110
000079db33dce761  int3
000079db33dce762  int3
000079db33dce763  nop [rax+rax*1], ax
000079db33dce76c  nop [rax], eax
000079db33dce770  mov rax, [r15+0x08]
000079db33dce774  mov [rsp+0x10], rax
000079db33dce779  xor eax, eax
000079db33dce77b  mov r14, [rsp+0x10]
000079db33dce780  mov r12d, 0x01
000079db33dce786  sub r14, r12
000079db33dce789  cmc
000079db33dce78a  lahf
000079db33dce78b  seto al
000079db33dce78e  mov [r15+0x108], eax
000079db33dce795  mov [r15+0x08], r14
000079db33dce799  mov rax, [r15]
000079db33dce79c  lea r14, [rax+0x08]
000079db33dce7a0  lea rax, [r14-0x05]
000079db33dce7a4  mov [r15+0x10], rax
000079db33dce7a8  mov [rsp+0x10], rax
000079db33dce7ad  shr rax, 0x07
000079db33dce7b1  mov r14, [rsp+0x10]
000079db33dce7b6  xor r14, rax
000079db33dce7b9  mov rax, [rsp+0x10]
000079db33dce7be  shr rax, 0x07
000079db33dce7c2  xor r14, rax
000079db33dce7c5  mov [rsp+0x10], r14
000079db33dce7ca  mov rax, [rsp+0x10]
000079db33dce7cf  shrd r14, rax, 0x0D
000079db33dce7d4  mov [rsp+0x10], r14
000079db33dce7d9  mov rax, [rsp+0x10]
000079db33dce7de  shrd r14, rax, 0x33
000079db33dce7e3  mov [r15+0x18], r14
000079db33dce7e7  mov [r15], r14
000079db33dce7ea  mov eax, [r15+0x108]
000079db33dce7f1  sahf
000079db33dce7f2  jnz 0x000079DB33DCE824
000079db33dce7f4  cmp dword ptr [r15+0x318], 0x00
000079db33dce7fc  jz 0x000079DB33DCE860
000079db33dce802  nop [rax+rax*1], ax
000079db33dce80b  nop [rax+rax*1], eax
000079db33dce813  mov eax, 0x410064
000079db33dce818  mov [r15+0x100], rax
000079db33dce81f  jmp 0x000079DB33BFE110
000079db33dce824  cmp dword ptr [r15+0x318], 0x00
000079db33dce82c  jz 0x000079DB33DCE770
000079db33dce832  nop [rax+rax*1], ax
000079db33dce83b  nop [rax+rax*1], eax
000079db33dce843  mov eax, 0x41003C
000079db33dce848  mov [r15+0x100], rax
000079db33dce84f  jmp 0x000079DB33BFE110
000079db33dce854  int3
000079db33dce855  int3
000079db33dce856  nop [rax+rax*1], ax
000079db33dce85f  nop
000079db33dce860  mov rax, [r15+0x20]
000079db33dce864  mov r14, [r15]
000079db33dce867  mov [r13+rax*1], r14
000079db33dce86c  mov rax, [r15+0xF0]
000079db33dce873  mov [r15+0x100], rax
000079db33dce87a  jmp 0x000079DB33DCE5C0
000079db33dce87f  int3
000079db33dce880  call 0x000079DB33C0E120
000079db33dce885  jmp 0x000079DB33DCE86C
000079db33dce88a  int3
000079db33dce88b  nop [rax+rax*1], eax
000079db33dce890  mov qword ptr [r15+0x100], 0x04
000079db33dce89b  mov esi, 0x00
000079db33dce8a0  mov edx, 0x09
000079db33dce8a5  mov rdi, 0x7FFFEAB9F4F0
000079db33dce8af  mov rax, 0x597F7FC91970
000079db33dce8b9  call rax
000079db33dce8bb  cmp dword ptr [r15+0x318], 0x00
000079db33dce8c3  jnz 0x000079DB33BFE110
000079db33dce8c9  jmp 0x000079DB33BFE0A0
000079db33dce8ce  int3
000079db33dce8cf  int3
