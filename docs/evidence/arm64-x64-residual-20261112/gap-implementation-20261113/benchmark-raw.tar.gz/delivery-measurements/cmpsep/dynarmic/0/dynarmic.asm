00007be70f1ce69b  nop [rax+rax*1], eax
00007be70f1ce6a0  mov qword ptr [r15+0x20], 0x420070
00007be70f1ce6a8  xor eax, eax
00007be70f1ce6aa  mov r14d, 0xB71B00
00007be70f1ce6b0  mov r12d, 0x01
00007be70f1ce6b6  sub r14, r12
00007be70f1ce6b9  cmc
00007be70f1ce6ba  lahf
00007be70f1ce6bb  seto al
00007be70f1ce6be  mov [r15+0x108], eax
00007be70f1ce6c5  mov [r15+0x08], r14
00007be70f1ce6c9  mov qword ptr [r15+0x10], 0x03
00007be70f1ce6d1  mov eax, 0x03
00007be70f1ce6d6  mov r14d, 0x03
00007be70f1ce6dc  shrd rax, r14, 0x0D
00007be70f1ce6e1  mov [rsp+0x10], rax
00007be70f1ce6e6  mov r14, [rsp+0x10]
00007be70f1ce6eb  shrd rax, r14, 0x33
00007be70f1ce6f0  mov [r15+0x18], rax
00007be70f1ce6f4  mov [r15], rax
00007be70f1ce6f7  mov eax, [r15+0x108]
00007be70f1ce6fe  sahf
00007be70f1ce6ff  jnz 0x00007BE70F1CE731
00007be70f1ce701  cmp dword ptr [r15+0x318], 0x00
00007be70f1ce709  jz 0x00007BE70F1CE860
00007be70f1ce70f  nop [rax+rax*1], ax
00007be70f1ce718  nop [rax+rax*1], eax
00007be70f1ce720  mov eax, 0x410064
00007be70f1ce725  mov [r15+0x100], rax
00007be70f1ce72c  jmp 0x00007BE70EFFE110
00007be70f1ce731  cmp dword ptr [r15+0x318], 0x00
00007be70f1ce739  jz 0x00007BE70F1CE770
00007be70f1ce73f  nop [rax+rax*1], ax
00007be70f1ce748  nop [rax+rax*1], eax
00007be70f1ce750  mov eax, 0x41003C
00007be70f1ce755  mov [r15+0x100], rax
00007be70f1ce75c  jmp 0x00007BE70EFFE110
00007be70f1ce761  int3
00007be70f1ce762  int3
00007be70f1ce763  nop [rax+rax*1], ax
00007be70f1ce76c  nop [rax], eax
00007be70f1ce770  mov rax, [r15+0x08]
00007be70f1ce774  mov [rsp+0x10], rax
00007be70f1ce779  xor eax, eax
00007be70f1ce77b  mov r14, [rsp+0x10]
00007be70f1ce780  mov r12d, 0x01
00007be70f1ce786  sub r14, r12
00007be70f1ce789  cmc
00007be70f1ce78a  lahf
00007be70f1ce78b  seto al
00007be70f1ce78e  mov [r15+0x108], eax
00007be70f1ce795  mov [r15+0x08], r14
00007be70f1ce799  mov rax, [r15]
00007be70f1ce79c  lea r14, [rax+0x08]
00007be70f1ce7a0  lea rax, [r14-0x05]
00007be70f1ce7a4  mov [r15+0x10], rax
00007be70f1ce7a8  mov [rsp+0x10], rax
00007be70f1ce7ad  shr rax, 0x07
00007be70f1ce7b1  mov r14, [rsp+0x10]
00007be70f1ce7b6  xor r14, rax
00007be70f1ce7b9  mov rax, [rsp+0x10]
00007be70f1ce7be  shr rax, 0x07
00007be70f1ce7c2  xor r14, rax
00007be70f1ce7c5  mov [rsp+0x10], r14
00007be70f1ce7ca  mov rax, [rsp+0x10]
00007be70f1ce7cf  shrd r14, rax, 0x0D
00007be70f1ce7d4  mov [rsp+0x10], r14
00007be70f1ce7d9  mov rax, [rsp+0x10]
00007be70f1ce7de  shrd r14, rax, 0x33
00007be70f1ce7e3  mov [r15+0x18], r14
00007be70f1ce7e7  mov [r15], r14
00007be70f1ce7ea  mov eax, [r15+0x108]
00007be70f1ce7f1  sahf
00007be70f1ce7f2  jnz 0x00007BE70F1CE824
00007be70f1ce7f4  cmp dword ptr [r15+0x318], 0x00
00007be70f1ce7fc  jz 0x00007BE70F1CE860
00007be70f1ce802  nop [rax+rax*1], ax
00007be70f1ce80b  nop [rax+rax*1], eax
00007be70f1ce813  mov eax, 0x410064
00007be70f1ce818  mov [r15+0x100], rax
00007be70f1ce81f  jmp 0x00007BE70EFFE110
00007be70f1ce824  cmp dword ptr [r15+0x318], 0x00
00007be70f1ce82c  jz 0x00007BE70F1CE770
00007be70f1ce832  nop [rax+rax*1], ax
00007be70f1ce83b  nop [rax+rax*1], eax
00007be70f1ce843  mov eax, 0x41003C
00007be70f1ce848  mov [r15+0x100], rax
00007be70f1ce84f  jmp 0x00007BE70EFFE110
00007be70f1ce854  int3
00007be70f1ce855  int3
00007be70f1ce856  nop [rax+rax*1], ax
00007be70f1ce85f  nop
00007be70f1ce860  mov rax, [r15+0x20]
00007be70f1ce864  mov r14, [r15]
00007be70f1ce867  mov [r13+rax*1], r14
00007be70f1ce86c  mov rax, [r15+0xF0]
00007be70f1ce873  mov [r15+0x100], rax
00007be70f1ce87a  jmp 0x00007BE70F1CE5C0
00007be70f1ce87f  int3
00007be70f1ce880  call 0x00007BE70F00E120
00007be70f1ce885  jmp 0x00007BE70F1CE86C
00007be70f1ce88a  int3
00007be70f1ce88b  nop [rax+rax*1], eax
00007be70f1ce890  mov qword ptr [r15+0x100], 0x04
00007be70f1ce89b  mov esi, 0x00
00007be70f1ce8a0  mov edx, 0x09
00007be70f1ce8a5  mov rdi, 0x7FFC4F2684C0
00007be70f1ce8af  mov rax, 0x63716DCD1970
00007be70f1ce8b9  call rax
00007be70f1ce8bb  cmp dword ptr [r15+0x318], 0x00
00007be70f1ce8c3  jnz 0x00007BE70EFFE110
00007be70f1ce8c9  jmp 0x00007BE70EFFE0A0
00007be70f1ce8ce  int3
00007be70f1ce8cf  int3
