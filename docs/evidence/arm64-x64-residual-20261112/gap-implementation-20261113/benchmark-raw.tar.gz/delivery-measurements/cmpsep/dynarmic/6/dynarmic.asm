00007c7b3efce69b  nop [rax+rax*1], eax
00007c7b3efce6a0  mov qword ptr [r15+0x20], 0x420070
00007c7b3efce6a8  xor eax, eax
00007c7b3efce6aa  mov r14d, 0xB71B00
00007c7b3efce6b0  mov r12d, 0x01
00007c7b3efce6b6  sub r14, r12
00007c7b3efce6b9  cmc
00007c7b3efce6ba  lahf
00007c7b3efce6bb  seto al
00007c7b3efce6be  mov [r15+0x108], eax
00007c7b3efce6c5  mov [r15+0x08], r14
00007c7b3efce6c9  mov qword ptr [r15+0x10], 0x03
00007c7b3efce6d1  mov eax, 0x03
00007c7b3efce6d6  mov r14d, 0x03
00007c7b3efce6dc  shrd rax, r14, 0x0D
00007c7b3efce6e1  mov [rsp+0x10], rax
00007c7b3efce6e6  mov r14, [rsp+0x10]
00007c7b3efce6eb  shrd rax, r14, 0x33
00007c7b3efce6f0  mov [r15+0x18], rax
00007c7b3efce6f4  mov [r15], rax
00007c7b3efce6f7  mov eax, [r15+0x108]
00007c7b3efce6fe  sahf
00007c7b3efce6ff  jnz 0x00007C7B3EFCE731
00007c7b3efce701  cmp dword ptr [r15+0x318], 0x00
00007c7b3efce709  jz 0x00007C7B3EFCE860
00007c7b3efce70f  nop [rax+rax*1], ax
00007c7b3efce718  nop [rax+rax*1], eax
00007c7b3efce720  mov eax, 0x410064
00007c7b3efce725  mov [r15+0x100], rax
00007c7b3efce72c  jmp 0x00007C7B3EDFE110
00007c7b3efce731  cmp dword ptr [r15+0x318], 0x00
00007c7b3efce739  jz 0x00007C7B3EFCE770
00007c7b3efce73f  nop [rax+rax*1], ax
00007c7b3efce748  nop [rax+rax*1], eax
00007c7b3efce750  mov eax, 0x41003C
00007c7b3efce755  mov [r15+0x100], rax
00007c7b3efce75c  jmp 0x00007C7B3EDFE110
00007c7b3efce761  int3
00007c7b3efce762  int3
00007c7b3efce763  nop [rax+rax*1], ax
00007c7b3efce76c  nop [rax], eax
00007c7b3efce770  mov rax, [r15+0x08]
00007c7b3efce774  mov [rsp+0x10], rax
00007c7b3efce779  xor eax, eax
00007c7b3efce77b  mov r14, [rsp+0x10]
00007c7b3efce780  mov r12d, 0x01
00007c7b3efce786  sub r14, r12
00007c7b3efce789  cmc
00007c7b3efce78a  lahf
00007c7b3efce78b  seto al
00007c7b3efce78e  mov [r15+0x108], eax
00007c7b3efce795  mov [r15+0x08], r14
00007c7b3efce799  mov rax, [r15]
00007c7b3efce79c  lea r14, [rax+0x08]
00007c7b3efce7a0  lea rax, [r14-0x05]
00007c7b3efce7a4  mov [r15+0x10], rax
00007c7b3efce7a8  mov [rsp+0x10], rax
00007c7b3efce7ad  shr rax, 0x07
00007c7b3efce7b1  mov r14, [rsp+0x10]
00007c7b3efce7b6  xor r14, rax
00007c7b3efce7b9  mov rax, [rsp+0x10]
00007c7b3efce7be  shr rax, 0x07
00007c7b3efce7c2  xor r14, rax
00007c7b3efce7c5  mov [rsp+0x10], r14
00007c7b3efce7ca  mov rax, [rsp+0x10]
00007c7b3efce7cf  shrd r14, rax, 0x0D
00007c7b3efce7d4  mov [rsp+0x10], r14
00007c7b3efce7d9  mov rax, [rsp+0x10]
00007c7b3efce7de  shrd r14, rax, 0x33
00007c7b3efce7e3  mov [r15+0x18], r14
00007c7b3efce7e7  mov [r15], r14
00007c7b3efce7ea  mov eax, [r15+0x108]
00007c7b3efce7f1  sahf
00007c7b3efce7f2  jnz 0x00007C7B3EFCE824
00007c7b3efce7f4  cmp dword ptr [r15+0x318], 0x00
00007c7b3efce7fc  jz 0x00007C7B3EFCE860
00007c7b3efce802  nop [rax+rax*1], ax
00007c7b3efce80b  nop [rax+rax*1], eax
00007c7b3efce813  mov eax, 0x410064
00007c7b3efce818  mov [r15+0x100], rax
00007c7b3efce81f  jmp 0x00007C7B3EDFE110
00007c7b3efce824  cmp dword ptr [r15+0x318], 0x00
00007c7b3efce82c  jz 0x00007C7B3EFCE770
00007c7b3efce832  nop [rax+rax*1], ax
00007c7b3efce83b  nop [rax+rax*1], eax
00007c7b3efce843  mov eax, 0x41003C
00007c7b3efce848  mov [r15+0x100], rax
00007c7b3efce84f  jmp 0x00007C7B3EDFE110
00007c7b3efce854  int3
00007c7b3efce855  int3
00007c7b3efce856  nop [rax+rax*1], ax
00007c7b3efce85f  nop
00007c7b3efce860  mov rax, [r15+0x20]
00007c7b3efce864  mov r14, [r15]
00007c7b3efce867  mov [r13+rax*1], r14
00007c7b3efce86c  mov rax, [r15+0xF0]
00007c7b3efce873  mov [r15+0x100], rax
00007c7b3efce87a  jmp 0x00007C7B3EFCE5C0
00007c7b3efce87f  int3
00007c7b3efce880  call 0x00007C7B3EE0E120
00007c7b3efce885  jmp 0x00007C7B3EFCE86C
00007c7b3efce88a  int3
00007c7b3efce88b  nop [rax+rax*1], eax
00007c7b3efce890  mov qword ptr [r15+0x100], 0x04
00007c7b3efce89b  mov esi, 0x00
00007c7b3efce8a0  mov edx, 0x09
00007c7b3efce8a5  mov rdi, 0x7FFE33EC6A60
00007c7b3efce8af  mov rax, 0x62A9F3550970
00007c7b3efce8b9  call rax
00007c7b3efce8bb  cmp dword ptr [r15+0x318], 0x00
00007c7b3efce8c3  jnz 0x00007C7B3EDFE110
00007c7b3efce8c9  jmp 0x00007C7B3EDFE0A0
00007c7b3efce8ce  int3
00007c7b3efce8cf  int3
