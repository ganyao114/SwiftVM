00007c6a661ce69b  nop [rax+rax*1], eax
00007c6a661ce6a0  mov qword ptr [r15+0x20], 0x420070
00007c6a661ce6a8  xor eax, eax
00007c6a661ce6aa  mov r14d, 0xB71B00
00007c6a661ce6b0  mov r12d, 0x01
00007c6a661ce6b6  sub r14, r12
00007c6a661ce6b9  cmc
00007c6a661ce6ba  lahf
00007c6a661ce6bb  seto al
00007c6a661ce6be  mov [r15+0x108], eax
00007c6a661ce6c5  mov [r15+0x08], r14
00007c6a661ce6c9  mov qword ptr [r15+0x10], 0x03
00007c6a661ce6d1  mov eax, 0x03
00007c6a661ce6d6  mov r14d, 0x03
00007c6a661ce6dc  shrd rax, r14, 0x0D
00007c6a661ce6e1  mov [rsp+0x10], rax
00007c6a661ce6e6  mov r14, [rsp+0x10]
00007c6a661ce6eb  shrd rax, r14, 0x33
00007c6a661ce6f0  mov [r15+0x18], rax
00007c6a661ce6f4  mov [r15], rax
00007c6a661ce6f7  mov eax, [r15+0x108]
00007c6a661ce6fe  sahf
00007c6a661ce6ff  jnz 0x00007C6A661CE731
00007c6a661ce701  cmp dword ptr [r15+0x318], 0x00
00007c6a661ce709  jz 0x00007C6A661CE860
00007c6a661ce70f  nop [rax+rax*1], ax
00007c6a661ce718  nop [rax+rax*1], eax
00007c6a661ce720  mov eax, 0x410064
00007c6a661ce725  mov [r15+0x100], rax
00007c6a661ce72c  jmp 0x00007C6A65FFE110
00007c6a661ce731  cmp dword ptr [r15+0x318], 0x00
00007c6a661ce739  jz 0x00007C6A661CE770
00007c6a661ce73f  nop [rax+rax*1], ax
00007c6a661ce748  nop [rax+rax*1], eax
00007c6a661ce750  mov eax, 0x41003C
00007c6a661ce755  mov [r15+0x100], rax
00007c6a661ce75c  jmp 0x00007C6A65FFE110
00007c6a661ce761  int3
00007c6a661ce762  int3
00007c6a661ce763  nop [rax+rax*1], ax
00007c6a661ce76c  nop [rax], eax
00007c6a661ce770  mov rax, [r15+0x08]
00007c6a661ce774  mov [rsp+0x10], rax
00007c6a661ce779  xor eax, eax
00007c6a661ce77b  mov r14, [rsp+0x10]
00007c6a661ce780  mov r12d, 0x01
00007c6a661ce786  sub r14, r12
00007c6a661ce789  cmc
00007c6a661ce78a  lahf
00007c6a661ce78b  seto al
00007c6a661ce78e  mov [r15+0x108], eax
00007c6a661ce795  mov [r15+0x08], r14
00007c6a661ce799  mov rax, [r15]
00007c6a661ce79c  lea r14, [rax+0x08]
00007c6a661ce7a0  lea rax, [r14-0x05]
00007c6a661ce7a4  mov [r15+0x10], rax
00007c6a661ce7a8  mov [rsp+0x10], rax
00007c6a661ce7ad  shr rax, 0x07
00007c6a661ce7b1  mov r14, [rsp+0x10]
00007c6a661ce7b6  xor r14, rax
00007c6a661ce7b9  mov rax, [rsp+0x10]
00007c6a661ce7be  shr rax, 0x07
00007c6a661ce7c2  xor r14, rax
00007c6a661ce7c5  mov [rsp+0x10], r14
00007c6a661ce7ca  mov rax, [rsp+0x10]
00007c6a661ce7cf  shrd r14, rax, 0x0D
00007c6a661ce7d4  mov [rsp+0x10], r14
00007c6a661ce7d9  mov rax, [rsp+0x10]
00007c6a661ce7de  shrd r14, rax, 0x33
00007c6a661ce7e3  mov [r15+0x18], r14
00007c6a661ce7e7  mov [r15], r14
00007c6a661ce7ea  mov eax, [r15+0x108]
00007c6a661ce7f1  sahf
00007c6a661ce7f2  jnz 0x00007C6A661CE824
00007c6a661ce7f4  cmp dword ptr [r15+0x318], 0x00
00007c6a661ce7fc  jz 0x00007C6A661CE860
00007c6a661ce802  nop [rax+rax*1], ax
00007c6a661ce80b  nop [rax+rax*1], eax
00007c6a661ce813  mov eax, 0x410064
00007c6a661ce818  mov [r15+0x100], rax
00007c6a661ce81f  jmp 0x00007C6A65FFE110
00007c6a661ce824  cmp dword ptr [r15+0x318], 0x00
00007c6a661ce82c  jz 0x00007C6A661CE770
00007c6a661ce832  nop [rax+rax*1], ax
00007c6a661ce83b  nop [rax+rax*1], eax
00007c6a661ce843  mov eax, 0x41003C
00007c6a661ce848  mov [r15+0x100], rax
00007c6a661ce84f  jmp 0x00007C6A65FFE110
00007c6a661ce854  int3
00007c6a661ce855  int3
00007c6a661ce856  nop [rax+rax*1], ax
00007c6a661ce85f  nop
00007c6a661ce860  mov rax, [r15+0x20]
00007c6a661ce864  mov r14, [r15]
00007c6a661ce867  mov [r13+rax*1], r14
00007c6a661ce86c  mov rax, [r15+0xF0]
00007c6a661ce873  mov [r15+0x100], rax
00007c6a661ce87a  jmp 0x00007C6A661CE5C0
00007c6a661ce87f  int3
00007c6a661ce880  call 0x00007C6A6600E120
00007c6a661ce885  jmp 0x00007C6A661CE86C
00007c6a661ce88a  int3
00007c6a661ce88b  nop [rax+rax*1], eax
00007c6a661ce890  mov qword ptr [r15+0x100], 0x04
00007c6a661ce89b  mov esi, 0x00
00007c6a661ce8a0  mov edx, 0x09
00007c6a661ce8a5  mov rdi, 0x7FFFFA8BC5B0
00007c6a661ce8af  mov rax, 0x58C4E2B3A970
00007c6a661ce8b9  call rax
00007c6a661ce8bb  cmp dword ptr [r15+0x318], 0x00
00007c6a661ce8c3  jnz 0x00007C6A65FFE110
00007c6a661ce8c9  jmp 0x00007C6A65FFE0A0
00007c6a661ce8ce  int3
00007c6a661ce8cf  int3
