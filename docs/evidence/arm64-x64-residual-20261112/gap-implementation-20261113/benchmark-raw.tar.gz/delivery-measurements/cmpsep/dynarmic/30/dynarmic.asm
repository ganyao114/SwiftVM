0000701ec1fce69b  nop [rax+rax*1], eax
0000701ec1fce6a0  mov qword ptr [r15+0x20], 0x420070
0000701ec1fce6a8  xor eax, eax
0000701ec1fce6aa  mov r14d, 0xB71B00
0000701ec1fce6b0  mov r12d, 0x01
0000701ec1fce6b6  sub r14, r12
0000701ec1fce6b9  cmc
0000701ec1fce6ba  lahf
0000701ec1fce6bb  seto al
0000701ec1fce6be  mov [r15+0x108], eax
0000701ec1fce6c5  mov [r15+0x08], r14
0000701ec1fce6c9  mov qword ptr [r15+0x10], 0x03
0000701ec1fce6d1  mov eax, 0x03
0000701ec1fce6d6  mov r14d, 0x03
0000701ec1fce6dc  shrd rax, r14, 0x0D
0000701ec1fce6e1  mov [rsp+0x10], rax
0000701ec1fce6e6  mov r14, [rsp+0x10]
0000701ec1fce6eb  shrd rax, r14, 0x33
0000701ec1fce6f0  mov [r15+0x18], rax
0000701ec1fce6f4  mov [r15], rax
0000701ec1fce6f7  mov eax, [r15+0x108]
0000701ec1fce6fe  sahf
0000701ec1fce6ff  jnz 0x0000701EC1FCE731
0000701ec1fce701  cmp dword ptr [r15+0x318], 0x00
0000701ec1fce709  jz 0x0000701EC1FCE860
0000701ec1fce70f  nop [rax+rax*1], ax
0000701ec1fce718  nop [rax+rax*1], eax
0000701ec1fce720  mov eax, 0x410064
0000701ec1fce725  mov [r15+0x100], rax
0000701ec1fce72c  jmp 0x0000701EC1DFE110
0000701ec1fce731  cmp dword ptr [r15+0x318], 0x00
0000701ec1fce739  jz 0x0000701EC1FCE770
0000701ec1fce73f  nop [rax+rax*1], ax
0000701ec1fce748  nop [rax+rax*1], eax
0000701ec1fce750  mov eax, 0x41003C
0000701ec1fce755  mov [r15+0x100], rax
0000701ec1fce75c  jmp 0x0000701EC1DFE110
0000701ec1fce761  int3
0000701ec1fce762  int3
0000701ec1fce763  nop [rax+rax*1], ax
0000701ec1fce76c  nop [rax], eax
0000701ec1fce770  mov rax, [r15+0x08]
0000701ec1fce774  mov [rsp+0x10], rax
0000701ec1fce779  xor eax, eax
0000701ec1fce77b  mov r14, [rsp+0x10]
0000701ec1fce780  mov r12d, 0x01
0000701ec1fce786  sub r14, r12
0000701ec1fce789  cmc
0000701ec1fce78a  lahf
0000701ec1fce78b  seto al
0000701ec1fce78e  mov [r15+0x108], eax
0000701ec1fce795  mov [r15+0x08], r14
0000701ec1fce799  mov rax, [r15]
0000701ec1fce79c  lea r14, [rax+0x08]
0000701ec1fce7a0  lea rax, [r14-0x05]
0000701ec1fce7a4  mov [r15+0x10], rax
0000701ec1fce7a8  mov [rsp+0x10], rax
0000701ec1fce7ad  shr rax, 0x07
0000701ec1fce7b1  mov r14, [rsp+0x10]
0000701ec1fce7b6  xor r14, rax
0000701ec1fce7b9  mov rax, [rsp+0x10]
0000701ec1fce7be  shr rax, 0x07
0000701ec1fce7c2  xor r14, rax
0000701ec1fce7c5  mov [rsp+0x10], r14
0000701ec1fce7ca  mov rax, [rsp+0x10]
0000701ec1fce7cf  shrd r14, rax, 0x0D
0000701ec1fce7d4  mov [rsp+0x10], r14
0000701ec1fce7d9  mov rax, [rsp+0x10]
0000701ec1fce7de  shrd r14, rax, 0x33
0000701ec1fce7e3  mov [r15+0x18], r14
0000701ec1fce7e7  mov [r15], r14
0000701ec1fce7ea  mov eax, [r15+0x108]
0000701ec1fce7f1  sahf
0000701ec1fce7f2  jnz 0x0000701EC1FCE824
0000701ec1fce7f4  cmp dword ptr [r15+0x318], 0x00
0000701ec1fce7fc  jz 0x0000701EC1FCE860
0000701ec1fce802  nop [rax+rax*1], ax
0000701ec1fce80b  nop [rax+rax*1], eax
0000701ec1fce813  mov eax, 0x410064
0000701ec1fce818  mov [r15+0x100], rax
0000701ec1fce81f  jmp 0x0000701EC1DFE110
0000701ec1fce824  cmp dword ptr [r15+0x318], 0x00
0000701ec1fce82c  jz 0x0000701EC1FCE770
0000701ec1fce832  nop [rax+rax*1], ax
0000701ec1fce83b  nop [rax+rax*1], eax
0000701ec1fce843  mov eax, 0x41003C
0000701ec1fce848  mov [r15+0x100], rax
0000701ec1fce84f  jmp 0x0000701EC1DFE110
0000701ec1fce854  int3
0000701ec1fce855  int3
0000701ec1fce856  nop [rax+rax*1], ax
0000701ec1fce85f  nop
0000701ec1fce860  mov rax, [r15+0x20]
0000701ec1fce864  mov r14, [r15]
0000701ec1fce867  mov [r13+rax*1], r14
0000701ec1fce86c  mov rax, [r15+0xF0]
0000701ec1fce873  mov [r15+0x100], rax
0000701ec1fce87a  jmp 0x0000701EC1FCE5C0
0000701ec1fce87f  int3
0000701ec1fce880  call 0x0000701EC1E0E120
0000701ec1fce885  jmp 0x0000701EC1FCE86C
0000701ec1fce88a  int3
0000701ec1fce88b  nop [rax+rax*1], eax
0000701ec1fce890  mov qword ptr [r15+0x100], 0x04
0000701ec1fce89b  mov esi, 0x00
0000701ec1fce8a0  mov edx, 0x09
0000701ec1fce8a5  mov rdi, 0x7FFC08BC1F40
0000701ec1fce8af  mov rax, 0x569D2878B970
0000701ec1fce8b9  call rax
0000701ec1fce8bb  cmp dword ptr [r15+0x318], 0x00
0000701ec1fce8c3  jnz 0x0000701EC1DFE110
0000701ec1fce8c9  jmp 0x0000701EC1DFE0A0
0000701ec1fce8ce  int3
0000701ec1fce8cf  int3
