00007c77e05ce69b  nop [rax+rax*1], eax
00007c77e05ce6a0  mov qword ptr [r15+0x20], 0x420070
00007c77e05ce6a8  xor eax, eax
00007c77e05ce6aa  mov r14d, 0xB71B00
00007c77e05ce6b0  mov r12d, 0x01
00007c77e05ce6b6  sub r14, r12
00007c77e05ce6b9  cmc
00007c77e05ce6ba  lahf
00007c77e05ce6bb  seto al
00007c77e05ce6be  mov [r15+0x108], eax
00007c77e05ce6c5  mov [r15+0x08], r14
00007c77e05ce6c9  mov qword ptr [r15+0x10], 0x03
00007c77e05ce6d1  mov eax, 0x03
00007c77e05ce6d6  mov r14d, 0x03
00007c77e05ce6dc  shrd rax, r14, 0x0D
00007c77e05ce6e1  mov [rsp+0x10], rax
00007c77e05ce6e6  mov r14, [rsp+0x10]
00007c77e05ce6eb  shrd rax, r14, 0x33
00007c77e05ce6f0  mov [r15+0x18], rax
00007c77e05ce6f4  mov [r15], rax
00007c77e05ce6f7  mov eax, [r15+0x108]
00007c77e05ce6fe  sahf
00007c77e05ce6ff  jnz 0x00007C77E05CE731
00007c77e05ce701  cmp dword ptr [r15+0x318], 0x00
00007c77e05ce709  jz 0x00007C77E05CE860
00007c77e05ce70f  nop [rax+rax*1], ax
00007c77e05ce718  nop [rax+rax*1], eax
00007c77e05ce720  mov eax, 0x410064
00007c77e05ce725  mov [r15+0x100], rax
00007c77e05ce72c  jmp 0x00007C77E03FE110
00007c77e05ce731  cmp dword ptr [r15+0x318], 0x00
00007c77e05ce739  jz 0x00007C77E05CE770
00007c77e05ce73f  nop [rax+rax*1], ax
00007c77e05ce748  nop [rax+rax*1], eax
00007c77e05ce750  mov eax, 0x41003C
00007c77e05ce755  mov [r15+0x100], rax
00007c77e05ce75c  jmp 0x00007C77E03FE110
00007c77e05ce761  int3
00007c77e05ce762  int3
00007c77e05ce763  nop [rax+rax*1], ax
00007c77e05ce76c  nop [rax], eax
00007c77e05ce770  mov rax, [r15+0x08]
00007c77e05ce774  mov [rsp+0x10], rax
00007c77e05ce779  xor eax, eax
00007c77e05ce77b  mov r14, [rsp+0x10]
00007c77e05ce780  mov r12d, 0x01
00007c77e05ce786  sub r14, r12
00007c77e05ce789  cmc
00007c77e05ce78a  lahf
00007c77e05ce78b  seto al
00007c77e05ce78e  mov [r15+0x108], eax
00007c77e05ce795  mov [r15+0x08], r14
00007c77e05ce799  mov rax, [r15]
00007c77e05ce79c  lea r14, [rax+0x08]
00007c77e05ce7a0  lea rax, [r14-0x05]
00007c77e05ce7a4  mov [r15+0x10], rax
00007c77e05ce7a8  mov [rsp+0x10], rax
00007c77e05ce7ad  shr rax, 0x07
00007c77e05ce7b1  mov r14, [rsp+0x10]
00007c77e05ce7b6  xor r14, rax
00007c77e05ce7b9  mov rax, [rsp+0x10]
00007c77e05ce7be  shr rax, 0x07
00007c77e05ce7c2  xor r14, rax
00007c77e05ce7c5  mov [rsp+0x10], r14
00007c77e05ce7ca  mov rax, [rsp+0x10]
00007c77e05ce7cf  shrd r14, rax, 0x0D
00007c77e05ce7d4  mov [rsp+0x10], r14
00007c77e05ce7d9  mov rax, [rsp+0x10]
00007c77e05ce7de  shrd r14, rax, 0x33
00007c77e05ce7e3  mov [r15+0x18], r14
00007c77e05ce7e7  mov [r15], r14
00007c77e05ce7ea  mov eax, [r15+0x108]
00007c77e05ce7f1  sahf
00007c77e05ce7f2  jnz 0x00007C77E05CE824
00007c77e05ce7f4  cmp dword ptr [r15+0x318], 0x00
00007c77e05ce7fc  jz 0x00007C77E05CE860
00007c77e05ce802  nop [rax+rax*1], ax
00007c77e05ce80b  nop [rax+rax*1], eax
00007c77e05ce813  mov eax, 0x410064
00007c77e05ce818  mov [r15+0x100], rax
00007c77e05ce81f  jmp 0x00007C77E03FE110
00007c77e05ce824  cmp dword ptr [r15+0x318], 0x00
00007c77e05ce82c  jz 0x00007C77E05CE770
00007c77e05ce832  nop [rax+rax*1], ax
00007c77e05ce83b  nop [rax+rax*1], eax
00007c77e05ce843  mov eax, 0x41003C
00007c77e05ce848  mov [r15+0x100], rax
00007c77e05ce84f  jmp 0x00007C77E03FE110
00007c77e05ce854  int3
00007c77e05ce855  int3
00007c77e05ce856  nop [rax+rax*1], ax
00007c77e05ce85f  nop
00007c77e05ce860  mov rax, [r15+0x20]
00007c77e05ce864  mov r14, [r15]
00007c77e05ce867  mov [r13+rax*1], r14
00007c77e05ce86c  mov rax, [r15+0xF0]
00007c77e05ce873  mov [r15+0x100], rax
00007c77e05ce87a  jmp 0x00007C77E05CE5C0
00007c77e05ce87f  int3
00007c77e05ce880  call 0x00007C77E040E120
00007c77e05ce885  jmp 0x00007C77E05CE86C
00007c77e05ce88a  int3
00007c77e05ce88b  nop [rax+rax*1], eax
00007c77e05ce890  mov qword ptr [r15+0x100], 0x04
00007c77e05ce89b  mov esi, 0x00
00007c77e05ce8a0  mov edx, 0x09
00007c77e05ce8a5  mov rdi, 0x7FFD20A36AB0
00007c77e05ce8af  mov rax, 0x55C773500970
00007c77e05ce8b9  call rax
00007c77e05ce8bb  cmp dword ptr [r15+0x318], 0x00
00007c77e05ce8c3  jnz 0x00007C77E03FE110
00007c77e05ce8c9  jmp 0x00007C77E03FE0A0
00007c77e05ce8ce  int3
00007c77e05ce8cf  int3
