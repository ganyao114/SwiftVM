0000720fc3fce69b  nop [rax+rax*1], eax
0000720fc3fce6a0  mov qword ptr [r15+0x20], 0x420070
0000720fc3fce6a8  xor eax, eax
0000720fc3fce6aa  mov r14d, 0xB71B00
0000720fc3fce6b0  mov r12d, 0x01
0000720fc3fce6b6  sub r14, r12
0000720fc3fce6b9  cmc
0000720fc3fce6ba  lahf
0000720fc3fce6bb  seto al
0000720fc3fce6be  mov [r15+0x108], eax
0000720fc3fce6c5  mov [r15+0x08], r14
0000720fc3fce6c9  mov qword ptr [r15+0x10], 0x03
0000720fc3fce6d1  mov eax, 0x03
0000720fc3fce6d6  mov r14d, 0x03
0000720fc3fce6dc  shrd rax, r14, 0x0D
0000720fc3fce6e1  mov [rsp+0x10], rax
0000720fc3fce6e6  mov r14, [rsp+0x10]
0000720fc3fce6eb  shrd rax, r14, 0x33
0000720fc3fce6f0  mov [r15+0x18], rax
0000720fc3fce6f4  mov [r15], rax
0000720fc3fce6f7  mov eax, [r15+0x108]
0000720fc3fce6fe  sahf
0000720fc3fce6ff  jnz 0x0000720FC3FCE731
0000720fc3fce701  cmp dword ptr [r15+0x318], 0x00
0000720fc3fce709  jz 0x0000720FC3FCE860
0000720fc3fce70f  nop [rax+rax*1], ax
0000720fc3fce718  nop [rax+rax*1], eax
0000720fc3fce720  mov eax, 0x410064
0000720fc3fce725  mov [r15+0x100], rax
0000720fc3fce72c  jmp 0x0000720FC3DFE110
0000720fc3fce731  cmp dword ptr [r15+0x318], 0x00
0000720fc3fce739  jz 0x0000720FC3FCE770
0000720fc3fce73f  nop [rax+rax*1], ax
0000720fc3fce748  nop [rax+rax*1], eax
0000720fc3fce750  mov eax, 0x41003C
0000720fc3fce755  mov [r15+0x100], rax
0000720fc3fce75c  jmp 0x0000720FC3DFE110
0000720fc3fce761  int3
0000720fc3fce762  int3
0000720fc3fce763  nop [rax+rax*1], ax
0000720fc3fce76c  nop [rax], eax
0000720fc3fce770  mov rax, [r15+0x08]
0000720fc3fce774  mov [rsp+0x10], rax
0000720fc3fce779  xor eax, eax
0000720fc3fce77b  mov r14, [rsp+0x10]
0000720fc3fce780  mov r12d, 0x01
0000720fc3fce786  sub r14, r12
0000720fc3fce789  cmc
0000720fc3fce78a  lahf
0000720fc3fce78b  seto al
0000720fc3fce78e  mov [r15+0x108], eax
0000720fc3fce795  mov [r15+0x08], r14
0000720fc3fce799  mov rax, [r15]
0000720fc3fce79c  lea r14, [rax+0x08]
0000720fc3fce7a0  lea rax, [r14-0x05]
0000720fc3fce7a4  mov [r15+0x10], rax
0000720fc3fce7a8  mov [rsp+0x10], rax
0000720fc3fce7ad  shr rax, 0x07
0000720fc3fce7b1  mov r14, [rsp+0x10]
0000720fc3fce7b6  xor r14, rax
0000720fc3fce7b9  mov rax, [rsp+0x10]
0000720fc3fce7be  shr rax, 0x07
0000720fc3fce7c2  xor r14, rax
0000720fc3fce7c5  mov [rsp+0x10], r14
0000720fc3fce7ca  mov rax, [rsp+0x10]
0000720fc3fce7cf  shrd r14, rax, 0x0D
0000720fc3fce7d4  mov [rsp+0x10], r14
0000720fc3fce7d9  mov rax, [rsp+0x10]
0000720fc3fce7de  shrd r14, rax, 0x33
0000720fc3fce7e3  mov [r15+0x18], r14
0000720fc3fce7e7  mov [r15], r14
0000720fc3fce7ea  mov eax, [r15+0x108]
0000720fc3fce7f1  sahf
0000720fc3fce7f2  jnz 0x0000720FC3FCE824
0000720fc3fce7f4  cmp dword ptr [r15+0x318], 0x00
0000720fc3fce7fc  jz 0x0000720FC3FCE860
0000720fc3fce802  nop [rax+rax*1], ax
0000720fc3fce80b  nop [rax+rax*1], eax
0000720fc3fce813  mov eax, 0x410064
0000720fc3fce818  mov [r15+0x100], rax
0000720fc3fce81f  jmp 0x0000720FC3DFE110
0000720fc3fce824  cmp dword ptr [r15+0x318], 0x00
0000720fc3fce82c  jz 0x0000720FC3FCE770
0000720fc3fce832  nop [rax+rax*1], ax
0000720fc3fce83b  nop [rax+rax*1], eax
0000720fc3fce843  mov eax, 0x41003C
0000720fc3fce848  mov [r15+0x100], rax
0000720fc3fce84f  jmp 0x0000720FC3DFE110
0000720fc3fce854  int3
0000720fc3fce855  int3
0000720fc3fce856  nop [rax+rax*1], ax
0000720fc3fce85f  nop
0000720fc3fce860  mov rax, [r15+0x20]
0000720fc3fce864  mov r14, [r15]
0000720fc3fce867  mov [r13+rax*1], r14
0000720fc3fce86c  mov rax, [r15+0xF0]
0000720fc3fce873  mov [r15+0x100], rax
0000720fc3fce87a  jmp 0x0000720FC3FCE5C0
0000720fc3fce87f  int3
0000720fc3fce880  call 0x0000720FC3E0E120
0000720fc3fce885  jmp 0x0000720FC3FCE86C
0000720fc3fce88a  int3
0000720fc3fce88b  nop [rax+rax*1], eax
0000720fc3fce890  mov qword ptr [r15+0x100], 0x04
0000720fc3fce89b  mov esi, 0x00
0000720fc3fce8a0  mov edx, 0x09
0000720fc3fce8a5  mov rdi, 0x7FFF0CA187E0
0000720fc3fce8af  mov rax, 0x6149580AE970
0000720fc3fce8b9  call rax
0000720fc3fce8bb  cmp dword ptr [r15+0x318], 0x00
0000720fc3fce8c3  jnz 0x0000720FC3DFE110
0000720fc3fce8c9  jmp 0x0000720FC3DFE0A0
0000720fc3fce8ce  int3
0000720fc3fce8cf  int3
