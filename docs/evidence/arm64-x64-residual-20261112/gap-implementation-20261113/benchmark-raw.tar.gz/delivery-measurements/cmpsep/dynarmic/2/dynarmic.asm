00007f48c55ce69b  nop [rax+rax*1], eax
00007f48c55ce6a0  mov qword ptr [r15+0x20], 0x420070
00007f48c55ce6a8  xor eax, eax
00007f48c55ce6aa  mov r14d, 0xB71B00
00007f48c55ce6b0  mov r12d, 0x01
00007f48c55ce6b6  sub r14, r12
00007f48c55ce6b9  cmc
00007f48c55ce6ba  lahf
00007f48c55ce6bb  seto al
00007f48c55ce6be  mov [r15+0x108], eax
00007f48c55ce6c5  mov [r15+0x08], r14
00007f48c55ce6c9  mov qword ptr [r15+0x10], 0x03
00007f48c55ce6d1  mov eax, 0x03
00007f48c55ce6d6  mov r14d, 0x03
00007f48c55ce6dc  shrd rax, r14, 0x0D
00007f48c55ce6e1  mov [rsp+0x10], rax
00007f48c55ce6e6  mov r14, [rsp+0x10]
00007f48c55ce6eb  shrd rax, r14, 0x33
00007f48c55ce6f0  mov [r15+0x18], rax
00007f48c55ce6f4  mov [r15], rax
00007f48c55ce6f7  mov eax, [r15+0x108]
00007f48c55ce6fe  sahf
00007f48c55ce6ff  jnz 0x00007F48C55CE731
00007f48c55ce701  cmp dword ptr [r15+0x318], 0x00
00007f48c55ce709  jz 0x00007F48C55CE860
00007f48c55ce70f  nop [rax+rax*1], ax
00007f48c55ce718  nop [rax+rax*1], eax
00007f48c55ce720  mov eax, 0x410064
00007f48c55ce725  mov [r15+0x100], rax
00007f48c55ce72c  jmp 0x00007F48C53FE110
00007f48c55ce731  cmp dword ptr [r15+0x318], 0x00
00007f48c55ce739  jz 0x00007F48C55CE770
00007f48c55ce73f  nop [rax+rax*1], ax
00007f48c55ce748  nop [rax+rax*1], eax
00007f48c55ce750  mov eax, 0x41003C
00007f48c55ce755  mov [r15+0x100], rax
00007f48c55ce75c  jmp 0x00007F48C53FE110
00007f48c55ce761  int3
00007f48c55ce762  int3
00007f48c55ce763  nop [rax+rax*1], ax
00007f48c55ce76c  nop [rax], eax
00007f48c55ce770  mov rax, [r15+0x08]
00007f48c55ce774  mov [rsp+0x10], rax
00007f48c55ce779  xor eax, eax
00007f48c55ce77b  mov r14, [rsp+0x10]
00007f48c55ce780  mov r12d, 0x01
00007f48c55ce786  sub r14, r12
00007f48c55ce789  cmc
00007f48c55ce78a  lahf
00007f48c55ce78b  seto al
00007f48c55ce78e  mov [r15+0x108], eax
00007f48c55ce795  mov [r15+0x08], r14
00007f48c55ce799  mov rax, [r15]
00007f48c55ce79c  lea r14, [rax+0x08]
00007f48c55ce7a0  lea rax, [r14-0x05]
00007f48c55ce7a4  mov [r15+0x10], rax
00007f48c55ce7a8  mov [rsp+0x10], rax
00007f48c55ce7ad  shr rax, 0x07
00007f48c55ce7b1  mov r14, [rsp+0x10]
00007f48c55ce7b6  xor r14, rax
00007f48c55ce7b9  mov rax, [rsp+0x10]
00007f48c55ce7be  shr rax, 0x07
00007f48c55ce7c2  xor r14, rax
00007f48c55ce7c5  mov [rsp+0x10], r14
00007f48c55ce7ca  mov rax, [rsp+0x10]
00007f48c55ce7cf  shrd r14, rax, 0x0D
00007f48c55ce7d4  mov [rsp+0x10], r14
00007f48c55ce7d9  mov rax, [rsp+0x10]
00007f48c55ce7de  shrd r14, rax, 0x33
00007f48c55ce7e3  mov [r15+0x18], r14
00007f48c55ce7e7  mov [r15], r14
00007f48c55ce7ea  mov eax, [r15+0x108]
00007f48c55ce7f1  sahf
00007f48c55ce7f2  jnz 0x00007F48C55CE824
00007f48c55ce7f4  cmp dword ptr [r15+0x318], 0x00
00007f48c55ce7fc  jz 0x00007F48C55CE860
00007f48c55ce802  nop [rax+rax*1], ax
00007f48c55ce80b  nop [rax+rax*1], eax
00007f48c55ce813  mov eax, 0x410064
00007f48c55ce818  mov [r15+0x100], rax
00007f48c55ce81f  jmp 0x00007F48C53FE110
00007f48c55ce824  cmp dword ptr [r15+0x318], 0x00
00007f48c55ce82c  jz 0x00007F48C55CE770
00007f48c55ce832  nop [rax+rax*1], ax
00007f48c55ce83b  nop [rax+rax*1], eax
00007f48c55ce843  mov eax, 0x41003C
00007f48c55ce848  mov [r15+0x100], rax
00007f48c55ce84f  jmp 0x00007F48C53FE110
00007f48c55ce854  int3
00007f48c55ce855  int3
00007f48c55ce856  nop [rax+rax*1], ax
00007f48c55ce85f  nop
00007f48c55ce860  mov rax, [r15+0x20]
00007f48c55ce864  mov r14, [r15]
00007f48c55ce867  mov [r13+rax*1], r14
00007f48c55ce86c  mov rax, [r15+0xF0]
00007f48c55ce873  mov [r15+0x100], rax
00007f48c55ce87a  jmp 0x00007F48C55CE5C0
00007f48c55ce87f  int3
00007f48c55ce880  call 0x00007F48C540E120
00007f48c55ce885  jmp 0x00007F48C55CE86C
00007f48c55ce88a  int3
00007f48c55ce88b  nop [rax+rax*1], eax
00007f48c55ce890  mov qword ptr [r15+0x100], 0x04
00007f48c55ce89b  mov esi, 0x00
00007f48c55ce8a0  mov edx, 0x09
00007f48c55ce8a5  mov rdi, 0x7FFEEA51ED50
00007f48c55ce8af  mov rax, 0x5CA57BD15970
00007f48c55ce8b9  call rax
00007f48c55ce8bb  cmp dword ptr [r15+0x318], 0x00
00007f48c55ce8c3  jnz 0x00007F48C53FE110
00007f48c55ce8c9  jmp 0x00007F48C53FE0A0
00007f48c55ce8ce  int3
00007f48c55ce8cf  int3
