00007a8aa13ce69b  nop [rax+rax*1], eax
00007a8aa13ce6a0  mov qword ptr [r15+0x20], 0x420070
00007a8aa13ce6a8  xor eax, eax
00007a8aa13ce6aa  mov r14d, 0xB71B00
00007a8aa13ce6b0  mov r12d, 0x01
00007a8aa13ce6b6  sub r14, r12
00007a8aa13ce6b9  cmc
00007a8aa13ce6ba  lahf
00007a8aa13ce6bb  seto al
00007a8aa13ce6be  mov [r15+0x108], eax
00007a8aa13ce6c5  mov [r15+0x08], r14
00007a8aa13ce6c9  mov qword ptr [r15+0x10], 0x03
00007a8aa13ce6d1  mov eax, 0x03
00007a8aa13ce6d6  mov r14d, 0x03
00007a8aa13ce6dc  shrd rax, r14, 0x0D
00007a8aa13ce6e1  mov [rsp+0x10], rax
00007a8aa13ce6e6  mov r14, [rsp+0x10]
00007a8aa13ce6eb  shrd rax, r14, 0x33
00007a8aa13ce6f0  mov [r15+0x18], rax
00007a8aa13ce6f4  mov [r15], rax
00007a8aa13ce6f7  mov eax, [r15+0x108]
00007a8aa13ce6fe  sahf
00007a8aa13ce6ff  jnz 0x00007A8AA13CE731
00007a8aa13ce701  cmp dword ptr [r15+0x318], 0x00
00007a8aa13ce709  jz 0x00007A8AA13CE860
00007a8aa13ce70f  nop [rax+rax*1], ax
00007a8aa13ce718  nop [rax+rax*1], eax
00007a8aa13ce720  mov eax, 0x410064
00007a8aa13ce725  mov [r15+0x100], rax
00007a8aa13ce72c  jmp 0x00007A8AA11FE110
00007a8aa13ce731  cmp dword ptr [r15+0x318], 0x00
00007a8aa13ce739  jz 0x00007A8AA13CE770
00007a8aa13ce73f  nop [rax+rax*1], ax
00007a8aa13ce748  nop [rax+rax*1], eax
00007a8aa13ce750  mov eax, 0x41003C
00007a8aa13ce755  mov [r15+0x100], rax
00007a8aa13ce75c  jmp 0x00007A8AA11FE110
00007a8aa13ce761  int3
00007a8aa13ce762  int3
00007a8aa13ce763  nop [rax+rax*1], ax
00007a8aa13ce76c  nop [rax], eax
00007a8aa13ce770  mov rax, [r15+0x08]
00007a8aa13ce774  mov [rsp+0x10], rax
00007a8aa13ce779  xor eax, eax
00007a8aa13ce77b  mov r14, [rsp+0x10]
00007a8aa13ce780  mov r12d, 0x01
00007a8aa13ce786  sub r14, r12
00007a8aa13ce789  cmc
00007a8aa13ce78a  lahf
00007a8aa13ce78b  seto al
00007a8aa13ce78e  mov [r15+0x108], eax
00007a8aa13ce795  mov [r15+0x08], r14
00007a8aa13ce799  mov rax, [r15]
00007a8aa13ce79c  lea r14, [rax+0x08]
00007a8aa13ce7a0  lea rax, [r14-0x05]
00007a8aa13ce7a4  mov [r15+0x10], rax
00007a8aa13ce7a8  mov [rsp+0x10], rax
00007a8aa13ce7ad  shr rax, 0x07
00007a8aa13ce7b1  mov r14, [rsp+0x10]
00007a8aa13ce7b6  xor r14, rax
00007a8aa13ce7b9  mov rax, [rsp+0x10]
00007a8aa13ce7be  shr rax, 0x07
00007a8aa13ce7c2  xor r14, rax
00007a8aa13ce7c5  mov [rsp+0x10], r14
00007a8aa13ce7ca  mov rax, [rsp+0x10]
00007a8aa13ce7cf  shrd r14, rax, 0x0D
00007a8aa13ce7d4  mov [rsp+0x10], r14
00007a8aa13ce7d9  mov rax, [rsp+0x10]
00007a8aa13ce7de  shrd r14, rax, 0x33
00007a8aa13ce7e3  mov [r15+0x18], r14
00007a8aa13ce7e7  mov [r15], r14
00007a8aa13ce7ea  mov eax, [r15+0x108]
00007a8aa13ce7f1  sahf
00007a8aa13ce7f2  jnz 0x00007A8AA13CE824
00007a8aa13ce7f4  cmp dword ptr [r15+0x318], 0x00
00007a8aa13ce7fc  jz 0x00007A8AA13CE860
00007a8aa13ce802  nop [rax+rax*1], ax
00007a8aa13ce80b  nop [rax+rax*1], eax
00007a8aa13ce813  mov eax, 0x410064
00007a8aa13ce818  mov [r15+0x100], rax
00007a8aa13ce81f  jmp 0x00007A8AA11FE110
00007a8aa13ce824  cmp dword ptr [r15+0x318], 0x00
00007a8aa13ce82c  jz 0x00007A8AA13CE770
00007a8aa13ce832  nop [rax+rax*1], ax
00007a8aa13ce83b  nop [rax+rax*1], eax
00007a8aa13ce843  mov eax, 0x41003C
00007a8aa13ce848  mov [r15+0x100], rax
00007a8aa13ce84f  jmp 0x00007A8AA11FE110
00007a8aa13ce854  int3
00007a8aa13ce855  int3
00007a8aa13ce856  nop [rax+rax*1], ax
00007a8aa13ce85f  nop
00007a8aa13ce860  mov rax, [r15+0x20]
00007a8aa13ce864  mov r14, [r15]
00007a8aa13ce867  mov [r13+rax*1], r14
00007a8aa13ce86c  mov rax, [r15+0xF0]
00007a8aa13ce873  mov [r15+0x100], rax
00007a8aa13ce87a  jmp 0x00007A8AA13CE5C0
00007a8aa13ce87f  int3
00007a8aa13ce880  call 0x00007A8AA120E120
00007a8aa13ce885  jmp 0x00007A8AA13CE86C
00007a8aa13ce88a  int3
00007a8aa13ce88b  nop [rax+rax*1], eax
00007a8aa13ce890  mov qword ptr [r15+0x100], 0x04
00007a8aa13ce89b  mov esi, 0x00
00007a8aa13ce8a0  mov edx, 0x09
00007a8aa13ce8a5  mov rdi, 0x7FFF47FE05A0
00007a8aa13ce8af  mov rax, 0x55DD4DA66970
00007a8aa13ce8b9  call rax
00007a8aa13ce8bb  cmp dword ptr [r15+0x318], 0x00
00007a8aa13ce8c3  jnz 0x00007A8AA11FE110
00007a8aa13ce8c9  jmp 0x00007A8AA11FE0A0
00007a8aa13ce8ce  int3
00007a8aa13ce8cf  int3
