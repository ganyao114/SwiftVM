000075df5e9ce69b  nop [rax+rax*1], eax
000075df5e9ce6a0  mov qword ptr [r15+0x20], 0x420070
000075df5e9ce6a8  xor eax, eax
000075df5e9ce6aa  mov r14d, 0xB71B00
000075df5e9ce6b0  mov r12d, 0x01
000075df5e9ce6b6  sub r14, r12
000075df5e9ce6b9  cmc
000075df5e9ce6ba  lahf
000075df5e9ce6bb  seto al
000075df5e9ce6be  mov [r15+0x108], eax
000075df5e9ce6c5  mov [r15+0x08], r14
000075df5e9ce6c9  mov qword ptr [r15+0x10], 0x03
000075df5e9ce6d1  mov eax, 0x03
000075df5e9ce6d6  mov r14d, 0x03
000075df5e9ce6dc  shrd rax, r14, 0x0D
000075df5e9ce6e1  mov [rsp+0x10], rax
000075df5e9ce6e6  mov r14, [rsp+0x10]
000075df5e9ce6eb  shrd rax, r14, 0x33
000075df5e9ce6f0  mov [r15+0x18], rax
000075df5e9ce6f4  mov [r15], rax
000075df5e9ce6f7  mov eax, [r15+0x108]
000075df5e9ce6fe  sahf
000075df5e9ce6ff  jnz 0x000075DF5E9CE731
000075df5e9ce701  cmp dword ptr [r15+0x318], 0x00
000075df5e9ce709  jz 0x000075DF5E9CE860
000075df5e9ce70f  nop [rax+rax*1], ax
000075df5e9ce718  nop [rax+rax*1], eax
000075df5e9ce720  mov eax, 0x410064
000075df5e9ce725  mov [r15+0x100], rax
000075df5e9ce72c  jmp 0x000075DF5E7FE110
000075df5e9ce731  cmp dword ptr [r15+0x318], 0x00
000075df5e9ce739  jz 0x000075DF5E9CE770
000075df5e9ce73f  nop [rax+rax*1], ax
000075df5e9ce748  nop [rax+rax*1], eax
000075df5e9ce750  mov eax, 0x41003C
000075df5e9ce755  mov [r15+0x100], rax
000075df5e9ce75c  jmp 0x000075DF5E7FE110
000075df5e9ce761  int3
000075df5e9ce762  int3
000075df5e9ce763  nop [rax+rax*1], ax
000075df5e9ce76c  nop [rax], eax
000075df5e9ce770  mov rax, [r15+0x08]
000075df5e9ce774  mov [rsp+0x10], rax
000075df5e9ce779  xor eax, eax
000075df5e9ce77b  mov r14, [rsp+0x10]
000075df5e9ce780  mov r12d, 0x01
000075df5e9ce786  sub r14, r12
000075df5e9ce789  cmc
000075df5e9ce78a  lahf
000075df5e9ce78b  seto al
000075df5e9ce78e  mov [r15+0x108], eax
000075df5e9ce795  mov [r15+0x08], r14
000075df5e9ce799  mov rax, [r15]
000075df5e9ce79c  lea r14, [rax+0x08]
000075df5e9ce7a0  lea rax, [r14-0x05]
000075df5e9ce7a4  mov [r15+0x10], rax
000075df5e9ce7a8  mov [rsp+0x10], rax
000075df5e9ce7ad  shr rax, 0x07
000075df5e9ce7b1  mov r14, [rsp+0x10]
000075df5e9ce7b6  xor r14, rax
000075df5e9ce7b9  mov rax, [rsp+0x10]
000075df5e9ce7be  shr rax, 0x07
000075df5e9ce7c2  xor r14, rax
000075df5e9ce7c5  mov [rsp+0x10], r14
000075df5e9ce7ca  mov rax, [rsp+0x10]
000075df5e9ce7cf  shrd r14, rax, 0x0D
000075df5e9ce7d4  mov [rsp+0x10], r14
000075df5e9ce7d9  mov rax, [rsp+0x10]
000075df5e9ce7de  shrd r14, rax, 0x33
000075df5e9ce7e3  mov [r15+0x18], r14
000075df5e9ce7e7  mov [r15], r14
000075df5e9ce7ea  mov eax, [r15+0x108]
000075df5e9ce7f1  sahf
000075df5e9ce7f2  jnz 0x000075DF5E9CE824
000075df5e9ce7f4  cmp dword ptr [r15+0x318], 0x00
000075df5e9ce7fc  jz 0x000075DF5E9CE860
000075df5e9ce802  nop [rax+rax*1], ax
000075df5e9ce80b  nop [rax+rax*1], eax
000075df5e9ce813  mov eax, 0x410064
000075df5e9ce818  mov [r15+0x100], rax
000075df5e9ce81f  jmp 0x000075DF5E7FE110
000075df5e9ce824  cmp dword ptr [r15+0x318], 0x00
000075df5e9ce82c  jz 0x000075DF5E9CE770
000075df5e9ce832  nop [rax+rax*1], ax
000075df5e9ce83b  nop [rax+rax*1], eax
000075df5e9ce843  mov eax, 0x41003C
000075df5e9ce848  mov [r15+0x100], rax
000075df5e9ce84f  jmp 0x000075DF5E7FE110
000075df5e9ce854  int3
000075df5e9ce855  int3
000075df5e9ce856  nop [rax+rax*1], ax
000075df5e9ce85f  nop
000075df5e9ce860  mov rax, [r15+0x20]
000075df5e9ce864  mov r14, [r15]
000075df5e9ce867  mov [r13+rax*1], r14
000075df5e9ce86c  mov rax, [r15+0xF0]
000075df5e9ce873  mov [r15+0x100], rax
000075df5e9ce87a  jmp 0x000075DF5E9CE5C0
000075df5e9ce87f  int3
000075df5e9ce880  call 0x000075DF5E80E120
000075df5e9ce885  jmp 0x000075DF5E9CE86C
000075df5e9ce88a  int3
000075df5e9ce88b  nop [rax+rax*1], eax
000075df5e9ce890  mov qword ptr [r15+0x100], 0x04
000075df5e9ce89b  mov esi, 0x00
000075df5e9ce8a0  mov edx, 0x09
000075df5e9ce8a5  mov rdi, 0x7FFE3F177130
000075df5e9ce8af  mov rax, 0x5C699E1EF970
000075df5e9ce8b9  call rax
000075df5e9ce8bb  cmp dword ptr [r15+0x318], 0x00
000075df5e9ce8c3  jnz 0x000075DF5E7FE110
000075df5e9ce8c9  jmp 0x000075DF5E7FE0A0
000075df5e9ce8ce  int3
000075df5e9ce8cf  int3
