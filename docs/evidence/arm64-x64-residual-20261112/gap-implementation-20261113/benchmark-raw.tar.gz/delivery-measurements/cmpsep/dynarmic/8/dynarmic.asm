00007a0be0bce69b  nop [rax+rax*1], eax
00007a0be0bce6a0  mov qword ptr [r15+0x20], 0x420070
00007a0be0bce6a8  xor eax, eax
00007a0be0bce6aa  mov r14d, 0xB71B00
00007a0be0bce6b0  mov r12d, 0x01
00007a0be0bce6b6  sub r14, r12
00007a0be0bce6b9  cmc
00007a0be0bce6ba  lahf
00007a0be0bce6bb  seto al
00007a0be0bce6be  mov [r15+0x108], eax
00007a0be0bce6c5  mov [r15+0x08], r14
00007a0be0bce6c9  mov qword ptr [r15+0x10], 0x03
00007a0be0bce6d1  mov eax, 0x03
00007a0be0bce6d6  mov r14d, 0x03
00007a0be0bce6dc  shrd rax, r14, 0x0D
00007a0be0bce6e1  mov [rsp+0x10], rax
00007a0be0bce6e6  mov r14, [rsp+0x10]
00007a0be0bce6eb  shrd rax, r14, 0x33
00007a0be0bce6f0  mov [r15+0x18], rax
00007a0be0bce6f4  mov [r15], rax
00007a0be0bce6f7  mov eax, [r15+0x108]
00007a0be0bce6fe  sahf
00007a0be0bce6ff  jnz 0x00007A0BE0BCE731
00007a0be0bce701  cmp dword ptr [r15+0x318], 0x00
00007a0be0bce709  jz 0x00007A0BE0BCE860
00007a0be0bce70f  nop [rax+rax*1], ax
00007a0be0bce718  nop [rax+rax*1], eax
00007a0be0bce720  mov eax, 0x410064
00007a0be0bce725  mov [r15+0x100], rax
00007a0be0bce72c  jmp 0x00007A0BE09FE110
00007a0be0bce731  cmp dword ptr [r15+0x318], 0x00
00007a0be0bce739  jz 0x00007A0BE0BCE770
00007a0be0bce73f  nop [rax+rax*1], ax
00007a0be0bce748  nop [rax+rax*1], eax
00007a0be0bce750  mov eax, 0x41003C
00007a0be0bce755  mov [r15+0x100], rax
00007a0be0bce75c  jmp 0x00007A0BE09FE110
00007a0be0bce761  int3
00007a0be0bce762  int3
00007a0be0bce763  nop [rax+rax*1], ax
00007a0be0bce76c  nop [rax], eax
00007a0be0bce770  mov rax, [r15+0x08]
00007a0be0bce774  mov [rsp+0x10], rax
00007a0be0bce779  xor eax, eax
00007a0be0bce77b  mov r14, [rsp+0x10]
00007a0be0bce780  mov r12d, 0x01
00007a0be0bce786  sub r14, r12
00007a0be0bce789  cmc
00007a0be0bce78a  lahf
00007a0be0bce78b  seto al
00007a0be0bce78e  mov [r15+0x108], eax
00007a0be0bce795  mov [r15+0x08], r14
00007a0be0bce799  mov rax, [r15]
00007a0be0bce79c  lea r14, [rax+0x08]
00007a0be0bce7a0  lea rax, [r14-0x05]
00007a0be0bce7a4  mov [r15+0x10], rax
00007a0be0bce7a8  mov [rsp+0x10], rax
00007a0be0bce7ad  shr rax, 0x07
00007a0be0bce7b1  mov r14, [rsp+0x10]
00007a0be0bce7b6  xor r14, rax
00007a0be0bce7b9  mov rax, [rsp+0x10]
00007a0be0bce7be  shr rax, 0x07
00007a0be0bce7c2  xor r14, rax
00007a0be0bce7c5  mov [rsp+0x10], r14
00007a0be0bce7ca  mov rax, [rsp+0x10]
00007a0be0bce7cf  shrd r14, rax, 0x0D
00007a0be0bce7d4  mov [rsp+0x10], r14
00007a0be0bce7d9  mov rax, [rsp+0x10]
00007a0be0bce7de  shrd r14, rax, 0x33
00007a0be0bce7e3  mov [r15+0x18], r14
00007a0be0bce7e7  mov [r15], r14
00007a0be0bce7ea  mov eax, [r15+0x108]
00007a0be0bce7f1  sahf
00007a0be0bce7f2  jnz 0x00007A0BE0BCE824
00007a0be0bce7f4  cmp dword ptr [r15+0x318], 0x00
00007a0be0bce7fc  jz 0x00007A0BE0BCE860
00007a0be0bce802  nop [rax+rax*1], ax
00007a0be0bce80b  nop [rax+rax*1], eax
00007a0be0bce813  mov eax, 0x410064
00007a0be0bce818  mov [r15+0x100], rax
00007a0be0bce81f  jmp 0x00007A0BE09FE110
00007a0be0bce824  cmp dword ptr [r15+0x318], 0x00
00007a0be0bce82c  jz 0x00007A0BE0BCE770
00007a0be0bce832  nop [rax+rax*1], ax
00007a0be0bce83b  nop [rax+rax*1], eax
00007a0be0bce843  mov eax, 0x41003C
00007a0be0bce848  mov [r15+0x100], rax
00007a0be0bce84f  jmp 0x00007A0BE09FE110
00007a0be0bce854  int3
00007a0be0bce855  int3
00007a0be0bce856  nop [rax+rax*1], ax
00007a0be0bce85f  nop
00007a0be0bce860  mov rax, [r15+0x20]
00007a0be0bce864  mov r14, [r15]
00007a0be0bce867  mov [r13+rax*1], r14
00007a0be0bce86c  mov rax, [r15+0xF0]
00007a0be0bce873  mov [r15+0x100], rax
00007a0be0bce87a  jmp 0x00007A0BE0BCE5C0
00007a0be0bce87f  int3
00007a0be0bce880  call 0x00007A0BE0A0E120
00007a0be0bce885  jmp 0x00007A0BE0BCE86C
00007a0be0bce88a  int3
00007a0be0bce88b  nop [rax+rax*1], eax
00007a0be0bce890  mov qword ptr [r15+0x100], 0x04
00007a0be0bce89b  mov esi, 0x00
00007a0be0bce8a0  mov edx, 0x09
00007a0be0bce8a5  mov rdi, 0x7FFF3A0BA8C0
00007a0be0bce8af  mov rax, 0x5EFB1CDE4970
00007a0be0bce8b9  call rax
00007a0be0bce8bb  cmp dword ptr [r15+0x318], 0x00
00007a0be0bce8c3  jnz 0x00007A0BE09FE110
00007a0be0bce8c9  jmp 0x00007A0BE09FE0A0
00007a0be0bce8ce  int3
00007a0be0bce8cf  int3
