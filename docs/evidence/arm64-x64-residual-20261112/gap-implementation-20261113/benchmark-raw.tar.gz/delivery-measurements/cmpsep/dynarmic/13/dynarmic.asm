00007e2f82fce69b  nop [rax+rax*1], eax
00007e2f82fce6a0  mov qword ptr [r15+0x20], 0x420070
00007e2f82fce6a8  xor eax, eax
00007e2f82fce6aa  mov r14d, 0xB71B00
00007e2f82fce6b0  mov r12d, 0x01
00007e2f82fce6b6  sub r14, r12
00007e2f82fce6b9  cmc
00007e2f82fce6ba  lahf
00007e2f82fce6bb  seto al
00007e2f82fce6be  mov [r15+0x108], eax
00007e2f82fce6c5  mov [r15+0x08], r14
00007e2f82fce6c9  mov qword ptr [r15+0x10], 0x03
00007e2f82fce6d1  mov eax, 0x03
00007e2f82fce6d6  mov r14d, 0x03
00007e2f82fce6dc  shrd rax, r14, 0x0D
00007e2f82fce6e1  mov [rsp+0x10], rax
00007e2f82fce6e6  mov r14, [rsp+0x10]
00007e2f82fce6eb  shrd rax, r14, 0x33
00007e2f82fce6f0  mov [r15+0x18], rax
00007e2f82fce6f4  mov [r15], rax
00007e2f82fce6f7  mov eax, [r15+0x108]
00007e2f82fce6fe  sahf
00007e2f82fce6ff  jnz 0x00007E2F82FCE731
00007e2f82fce701  cmp dword ptr [r15+0x318], 0x00
00007e2f82fce709  jz 0x00007E2F82FCE860
00007e2f82fce70f  nop [rax+rax*1], ax
00007e2f82fce718  nop [rax+rax*1], eax
00007e2f82fce720  mov eax, 0x410064
00007e2f82fce725  mov [r15+0x100], rax
00007e2f82fce72c  jmp 0x00007E2F82DFE110
00007e2f82fce731  cmp dword ptr [r15+0x318], 0x00
00007e2f82fce739  jz 0x00007E2F82FCE770
00007e2f82fce73f  nop [rax+rax*1], ax
00007e2f82fce748  nop [rax+rax*1], eax
00007e2f82fce750  mov eax, 0x41003C
00007e2f82fce755  mov [r15+0x100], rax
00007e2f82fce75c  jmp 0x00007E2F82DFE110
00007e2f82fce761  int3
00007e2f82fce762  int3
00007e2f82fce763  nop [rax+rax*1], ax
00007e2f82fce76c  nop [rax], eax
00007e2f82fce770  mov rax, [r15+0x08]
00007e2f82fce774  mov [rsp+0x10], rax
00007e2f82fce779  xor eax, eax
00007e2f82fce77b  mov r14, [rsp+0x10]
00007e2f82fce780  mov r12d, 0x01
00007e2f82fce786  sub r14, r12
00007e2f82fce789  cmc
00007e2f82fce78a  lahf
00007e2f82fce78b  seto al
00007e2f82fce78e  mov [r15+0x108], eax
00007e2f82fce795  mov [r15+0x08], r14
00007e2f82fce799  mov rax, [r15]
00007e2f82fce79c  lea r14, [rax+0x08]
00007e2f82fce7a0  lea rax, [r14-0x05]
00007e2f82fce7a4  mov [r15+0x10], rax
00007e2f82fce7a8  mov [rsp+0x10], rax
00007e2f82fce7ad  shr rax, 0x07
00007e2f82fce7b1  mov r14, [rsp+0x10]
00007e2f82fce7b6  xor r14, rax
00007e2f82fce7b9  mov rax, [rsp+0x10]
00007e2f82fce7be  shr rax, 0x07
00007e2f82fce7c2  xor r14, rax
00007e2f82fce7c5  mov [rsp+0x10], r14
00007e2f82fce7ca  mov rax, [rsp+0x10]
00007e2f82fce7cf  shrd r14, rax, 0x0D
00007e2f82fce7d4  mov [rsp+0x10], r14
00007e2f82fce7d9  mov rax, [rsp+0x10]
00007e2f82fce7de  shrd r14, rax, 0x33
00007e2f82fce7e3  mov [r15+0x18], r14
00007e2f82fce7e7  mov [r15], r14
00007e2f82fce7ea  mov eax, [r15+0x108]
00007e2f82fce7f1  sahf
00007e2f82fce7f2  jnz 0x00007E2F82FCE824
00007e2f82fce7f4  cmp dword ptr [r15+0x318], 0x00
00007e2f82fce7fc  jz 0x00007E2F82FCE860
00007e2f82fce802  nop [rax+rax*1], ax
00007e2f82fce80b  nop [rax+rax*1], eax
00007e2f82fce813  mov eax, 0x410064
00007e2f82fce818  mov [r15+0x100], rax
00007e2f82fce81f  jmp 0x00007E2F82DFE110
00007e2f82fce824  cmp dword ptr [r15+0x318], 0x00
00007e2f82fce82c  jz 0x00007E2F82FCE770
00007e2f82fce832  nop [rax+rax*1], ax
00007e2f82fce83b  nop [rax+rax*1], eax
00007e2f82fce843  mov eax, 0x41003C
00007e2f82fce848  mov [r15+0x100], rax
00007e2f82fce84f  jmp 0x00007E2F82DFE110
00007e2f82fce854  int3
00007e2f82fce855  int3
00007e2f82fce856  nop [rax+rax*1], ax
00007e2f82fce85f  nop
00007e2f82fce860  mov rax, [r15+0x20]
00007e2f82fce864  mov r14, [r15]
00007e2f82fce867  mov [r13+rax*1], r14
00007e2f82fce86c  mov rax, [r15+0xF0]
00007e2f82fce873  mov [r15+0x100], rax
00007e2f82fce87a  jmp 0x00007E2F82FCE5C0
00007e2f82fce87f  int3
00007e2f82fce880  call 0x00007E2F82E0E120
00007e2f82fce885  jmp 0x00007E2F82FCE86C
00007e2f82fce88a  int3
00007e2f82fce88b  nop [rax+rax*1], eax
00007e2f82fce890  mov qword ptr [r15+0x100], 0x04
00007e2f82fce89b  mov esi, 0x00
00007e2f82fce8a0  mov edx, 0x09
00007e2f82fce8a5  mov rdi, 0x7FFF216FE810
00007e2f82fce8af  mov rax, 0x5CD80C8C2970
00007e2f82fce8b9  call rax
00007e2f82fce8bb  cmp dword ptr [r15+0x318], 0x00
00007e2f82fce8c3  jnz 0x00007E2F82DFE110
00007e2f82fce8c9  jmp 0x00007E2F82DFE0A0
00007e2f82fce8ce  int3
00007e2f82fce8cf  int3
