#include <array>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <sys/mman.h>
#include "runtime/arch/arm64/numeric.h"
#include "runtime/backend/x64/allocate.h"
#include "runtime/backend/x64/compile.h"
#include "runtime/ir/builder.h"
#include "runtime/ir/optimize.h"
using namespace swift::runtime;
using namespace ir;
namespace x64 = backend::x64;
using u64 = std::uint64_t;

void need(bool ok) {
    if (!ok) throw std::runtime_error("numerical scaling validation failed");
}

Value emit(Builder& b, OpCode op, Type type, std::initializer_list<Operand> operands) {
    const auto result = b.Append(op, type, operands);
    need(bool(result));
    return result.GetValue();
}

Operand imm(u64 value) { return Operand::Immediate(value, Type::U64); }

struct Metrics {
    std::size_t before{}, after{}, words{}, ir_reserved{}, home_capacity{}, code{}, stubs{};
};

Metrics run(unsigned count, bool cold, bool verify) {
    constexpr unsigned q = offsetof(arm64::GuestState, q);
    constexpr std::uint32_t word = 0x1f010800;  // FMADD S0, S0, S1, S2.
    need(arm64::SupportsNumeric(arm64::Numeric::Scalar, word));
    const auto mode = arm64::NumericCall(arm64::Numeric::Scalar, word);
    Builder b{Scope::Block, x64::KnownTargetInfo()};
    const auto block = b.CreateBlock();
    need(bool(block));
    need(b.BeginBlock(block.block) == Error::None);
#ifdef SVM_EXACT_VALUES
    const auto load = [&](unsigned reg) {
        return emit(
                b, OpCode::LoadUniform, Type::V128, {Operand::Uniform(q + reg * 16, Type::V128)});
    };
    auto value = load(0);
    const auto right = load(1), addend = load(2);
#else
    const auto pointer = emit(b, OpCode::GetUniformAddress, Type::U64, {imm(0)});
#endif
    for (unsigned i = 0; i < count; ++i) {
#ifdef SVM_EXACT_VALUES
        value = emit(b,
                     OpCode::ArmFPTernary,
                     Type::V128,
                     {Operand::ValueOf(value),
                      Operand::ValueOf(right),
                      Operand::ValueOf(addend),
                      imm(arm64::FPStateOffsets(offsetof(arm64::GuestState, fpcr),
                                                offsetof(arm64::GuestState, fpsr))),
                      imm(mode)});
        emit(b,
             OpCode::StoreUniform,
             Type::Void,
             {Operand::Uniform(q, Type::V128), Operand::ValueOf(value)});
#else
        const auto encoded = emit(b, OpCode::LoadImm, Type::U64, {imm(mode)});
        const auto pc = emit(b, OpCode::LoadImm, Type::U64, {imm(0x1000 + i * 4)});
        emit(b,
             OpCode::CallLambda,
             Type::U64,
             {Operand::Lambda(),
              imm(reinterpret_cast<std::uintptr_t>(&arm64::ExecuteNumeric)),
              Operand::ValueOf(pointer),
              Operand::ValueOf(encoded),
              Operand::ValueOf(pc)});
#endif
    }
    const auto zero = emit(b, OpCode::LoadImm, Type::U64, {imm(0)});
    need(b.EndBlock(Terminal::Return(zero)) == Error::None);
    auto submitted = b.Submit();
    need(bool(submitted));
    const auto before = submitted.program.Operations().size();
    auto optimized = Optimize(
            std::move(submitted.program),
            SIZE_MAX,
            {.flags = UniformRange{offsetof(arm64::GuestState, packed_flags), 8},
             .guest_memory_disjoint = true,
             .numeric_control = UniformRange{offsetof(arm64::GuestState, numeric_control), 4},
             .pc = UniformRange{offsetof(arm64::GuestState, pc), 8}});
    need(bool(optimized));
    x64::CompileOptions options;
    options.flags_offset = offsetof(arm64::GuestState, packed_flags);
    options.pc_offset = offsetof(arm64::GuestState, pc);
    options.mxcsr_offset = offsetof(arm64::GuestState, numeric_control);
    options.arm_fpcr_offset = offsetof(arm64::GuestState, fpcr);
    options.arm_fpsr_offset = offsetof(arm64::GuestState, fpsr);
    options.arm_fpcr = 0;
    options.native_fp_environment = true;
    options.local_flags = true;
    options.relocatable = true;
    options.fma = true;
    options.sse41 = true;
    options.lahf = true;
#ifdef SVM_EXACT_VALUES
    options.avx = true;
#endif
    x64::Allocation allocation;
    backend::CompileResult code;
    x64::Compile(optimized.program, options, code, allocation);
    need(bool(code));
    Metrics result{before,
                   optimized.program.Operations().size(),
                   optimized.program.OperandArena().size(),
                   optimized.program.ReservedBytes(),
                   allocation.homes.capacity() * sizeof(x64::Home),
                   code.words.size() * 4};
    for (const auto& relocation : code.relocations) {
#ifdef SVM_EXACT_VALUES
        result.stubs += relocation.symbol == backend::HostSymbol::ArmFPValues;
#else
        result.stubs += relocation.symbol == backend::HostSymbol::ArmGuestFP;
#endif
    }
    if (verify) {
        const auto bytes = (result.code + 4095) & ~std::size_t{4095};
        auto* memory =
                mmap(nullptr, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        need(memory != MAP_FAILED);
        std::memcpy(memory, code.words.data(), result.code);
        need(mprotect(memory, bytes, PROT_READ | PROT_EXEC) == 0);
        arm64::GuestState state;
        state.fpcr = 0;
        state.numeric_control = 0x1f80;
        state.packed_flags = 0x51234567;
        const std::array<std::uint32_t, 3> inputs{
                cold ? 0x7f800001u : 0x3f800000u, 0x3f800000u, 0x3e000000u};
        for (unsigned i = 0; i < inputs.size(); ++i) std::memcpy(state.q[i], &inputs[i], 4);
        const auto answer = reinterpret_cast<u64 (*)(std::uint8_t*)>(memory)(
                reinterpret_cast<std::uint8_t*>(&state));
        float expected_float = 1.0f + float(count) / 8;
        std::uint32_t expected;
        std::memcpy(&expected, &expected_float, 4);
        std::array<std::uint32_t, 4> actual{};
        std::memcpy(actual.data(), state.q[0], 16);
        need(answer == 0 && actual[0] == (cold ? 0x7fc00001u : expected) && actual[1] == 0 &&
             actual[2] == 0 && actual[3] == 0);
        need(state.fpsr == (cold ? 1u : 0u) && state.packed_flags == 0x51234567);
        need(munmap(memory, bytes) == 0);
    }
    return result;
}

int main() {
    for (const bool cold : {false, true})
        for (const unsigned count : {256u, 512u, 1024u}) {
            const auto m = run(count, cold, true);
            std::printf(
                    "{\"kind\":\"%s\",\"count\":%u,\"nodes_before\":%zu,\"nodes_after\":%zu,"
                    "\"operand_words\":%zu,\"ir_reserved_bytes\":%zu,\"home_capacity_bytes\":%zu,"
                    "\"native_bytes\":%zu,\"recorded_math_stubs\":%zu,\"output_verified\":true,"
                    "\"requests\":4,\"sequence_ns\":[",
                    cold ? "numeric-cold" : "numeric-fp",
                    count,
                    m.before,
                    m.after,
                    m.words,
                    m.ir_reserved,
                    m.home_capacity,
                    m.code,
                    m.stubs);
            for (unsigned sample = 0; sample < 7; ++sample) {
                const auto begin = std::chrono::steady_clock::now();
                for (unsigned request = 0; request < 4; ++request) run(count, cold, false);
                const auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(
                                             std::chrono::steady_clock::now() - begin)
                                             .count();
                std::printf("%s%lld", sample ? "," : "", static_cast<long long>(elapsed));
            }
            std::puts("]}");
            std::fflush(stdout);
        }
}
