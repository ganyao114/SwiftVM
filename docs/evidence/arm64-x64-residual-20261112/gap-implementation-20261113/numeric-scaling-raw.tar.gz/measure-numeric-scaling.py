from pathlib import Path
import hashlib,json,os,statistics,subprocess,sys
root=Path(__file__).parent
old=root.parent/'arm64-x64-residual-impl-20261112'
work=root/'numeric-scaling';work.mkdir(exist_ok=False)
source=root/'numeric-scaling.cpp'
subprocess.run([str(root/'format-tool/clang_format/data/bin/clang-format'),'-i','--style=file:/mnt/d/Dev/SwiftVM/.clang-format',str(source)],check=True)
cmd=json.loads((old/'final-tools-build.json').read_text())['scaling']['argv']
builds={}
for engine in ['baseline','candidate']:
    include=root/'memory-metadata/baseline-headers/source' if engine=='baseline' else root/'source/source'
    cwd=Path('/mnt/d/Dev/SwiftVM/build/host') if engine=='baseline' else root/'build'
    args=[x.replace('/mnt/d/Dev/SwiftVM/source',str(include)).replace(str(old/'scaling.cpp'),str(source)) for x in cmd]
    args[args.index('-o')+1]=str(work/engine)
    if engine=='candidate':args.insert(1,'-DSVM_EXACT_VALUES=1')
    with (work/(engine+'-build.log')).open('w') as log:p=subprocess.run(args,cwd=cwd,stdout=log,stderr=log)
    assert p.returncode==0,(work/(engine+'-build.log')).read_text()[-4000:]
    builds[engine]={'cwd':str(cwd),'argv':args,'sha256':hashlib.sha256((work/engine).read_bytes()).hexdigest()}
(work/'builds.json').write_text(json.dumps(builds,indent=2)+'\n')
os.sched_setaffinity(0,{2})
rows={'baseline':[],'candidate':[]}
for sample in range(11):
    for engine in (['baseline','candidate'] if sample%2==0 else ['candidate','baseline']):
        p=subprocess.run([str(work/engine)],capture_output=True,text=True,timeout=120)
        assert p.returncode==0,(engine,p.returncode,p.stderr[-2000:],p.stdout[-1000:])
        records=[json.loads(line) for line in p.stdout.splitlines()]
        assert len(records)==6 and all(x['output_verified'] for x in records)
        (work/f'{engine}-{sample}.jsonl').write_text(p.stdout)
        rows[engine].append(records)
sys.path.insert(0,'/mnt/d/Dev/SwiftVM/tools');import bench_dynarmic as b
summary={}
for index,first in enumerate(rows['baseline'][0]):
    key=f"{first['kind']}/{first['count']}"
    values={engine:[statistics.median(run[index]['sequence_ns'])/run[index]['requests'] for run in records] for engine,records in rows.items()}
    summary[key]={'paired':b.distribution([x/y for x,y in zip(values['candidate'],values['baseline'])]),'medians_ns':{e:statistics.median(v) for e,v in values.items()},'baseline':first,'candidate':rows['candidate'][0][index]}
result={'samples':11,'sequence_samples':7,'requests_per_sequence':4,'cpu':2,'baseline_code_build_id':'045cbc5e2551348c2c212350f19a834302969b0afbf7c7cbb58613e281d50d42','scope':'legacy CallLambda numerical IR versus exact SSA numerical IR; bare Compile with stable FPCR=0 and scalar FMA','input_verification':'normal finite exact results and forced sNaN cold results, FPSR, zero upper lanes and preserved NZCV','builds':builds,'rows':summary}
(root/'numeric-scaling.json').write_text(json.dumps(result,indent=2)+'\n')
for k,v in summary.items():print(k,round(v['paired']['median'],3),'nodes',v['baseline']['nodes_after'],v['candidate']['nodes_after'],'bytes',v['baseline']['native_bytes'],v['candidate']['native_bytes'],'stubs',v['baseline']['recorded_math_stubs'],v['candidate']['recorded_math_stubs'],flush=True)
