
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sha/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	sub    r13,0xa0
  1f:	mov    QWORD PTR [r12+0xf8],r13
  27:	mov    r14d,0x420000
  2d:	mov    QWORD PTR [r12+0x40],r14
  32:	mov    r14d,0x420000
  38:	mov    QWORD PTR [r12+0x48],r14
  3d:	mov    r14,r13
  40:	add    r14,0x90
  47:	mov    r15,r14
  4a:	add    r15,0x8
  4e:	mov    rbp,QWORD PTR [r12+0xa0]
  56:	mov    r8,QWORD PTR [r12+0x98]
  5e:	mov    QWORD PTR [r14],rbp
  61:	mov    r14d,0x0
  67:	mov    DWORD PTR [r12+0x32c],r14d
  6f:	mov    QWORD PTR [r15],r8
  72:	mov    r14d,0x420670
  78:	movdqu xmm2,XMMWORD PTR [r14]
  7d:	movdqu XMMWORD PTR [r12+0x110],xmm2
  87:	mov    r14d,0x420610
  8d:	movdqu xmm3,XMMWORD PTR [r14]
  92:	movdqu XMMWORD PTR [r12+0x120],xmm3
  9c:	mov    r14d,0x420690
  a2:	movdqu xmm4,XMMWORD PTR [r14]
  a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
  b1:	mov    r14d,0x420630
  b7:	movdqu xmm5,XMMWORD PTR [r14]
  bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
  c6:	mov    r14d,0x430000
  cc:	add    r14,0x8a0
  d3:	mov    QWORD PTR [r12+0x98],r14
  db:	mov    r15d,0x4206a0
  e1:	movdqu xmm6,XMMWORD PTR [r15]
  e6:	movdqu XMMWORD PTR [r12+0x150],xmm6
  f0:	mov    r15,r14
  f3:	add    r15,0x10
  f7:	movdqu XMMWORD PTR [r14],xmm2
  fc:	movdqu XMMWORD PTR [r15],xmm3
 101:	mov    r15,r14
 104:	add    r15,0x20
 108:	mov    rbp,r15
 10b:	add    rbp,0x10
 10f:	movdqu XMMWORD PTR [r15],xmm4
 114:	movdqu XMMWORD PTR [rbp+0x0],xmm5
 119:	mov    r15d,0x420600
 11f:	movdqu xmm4,XMMWORD PTR [r15]
 124:	movdqu XMMWORD PTR [r12+0x130],xmm4
 12e:	mov    r15d,0x4205f0
 134:	movdqu xmm5,XMMWORD PTR [r15]
 139:	movdqu XMMWORD PTR [r12+0x140],xmm5
 143:	mov    r15,r14
 146:	add    r15,0x100
 14d:	mov    rbp,r15
 150:	add    rbp,0x10
 154:	movdqu XMMWORD PTR [r15],xmm2
 159:	movdqu XMMWORD PTR [rbp+0x0],xmm3
 15e:	mov    r15,r14
 161:	add    r15,0x40
 165:	mov    rbp,r15
 168:	add    rbp,0x10
 16c:	movdqu XMMWORD PTR [r15],xmm6
 171:	movdqu XMMWORD PTR [rbp+0x0],xmm4
 176:	mov    r15d,0x4205e0
 17c:	movdqu xmm2,XMMWORD PTR [r15]
 181:	movdqu XMMWORD PTR [r12+0x130],xmm2
 18b:	mov    r15d,0x420640
 191:	movdqu xmm3,XMMWORD PTR [r15]
 196:	movdqu XMMWORD PTR [r12+0x150],xmm3
 1a0:	mov    r15d,0xf8d3
 1a6:	mov    QWORD PTR [r12+0x48],r15
 1ab:	mov    r15,r14
 1ae:	add    r15,0x60
 1b2:	mov    rbp,r15
 1b5:	add    rbp,0x10
 1b9:	movdqu XMMWORD PTR [r15],xmm5
 1be:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 1c3:	mov    r15d,0x420650
 1c9:	movdqu xmm2,XMMWORD PTR [r15]
 1ce:	movdqu XMMWORD PTR [r12+0x130],xmm2
 1d8:	mov    r15d,0x420620
 1de:	movdqu xmm4,XMMWORD PTR [r15]
 1e3:	movdqu XMMWORD PTR [r12+0x140],xmm4
 1ed:	mov    r15d,0xf8d3
 1f3:	mov    ebp,0x421d
 1f8:	and    ebp,0xffff
 1fe:	mov    rax,r15
 201:	movabs rcx,0xffffffff0000ffff
 20b:	and    rax,rcx
 20e:	mov    rdx,rbp
 211:	shl    rdx,0x10
 215:	mov    ecx,0xffff0000
 21a:	and    rdx,rcx
 21d:	or     rax,rdx
 220:	mov    r8d,eax
 223:	mov    QWORD PTR [r12+0x48],r8
 228:	mov    r15,r14
 22b:	add    r15,0x80
 232:	mov    rbp,r15
 235:	add    rbp,0x10
 239:	movdqu XMMWORD PTR [r15],xmm3
 23e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 243:	mov    r15d,0x4206c0
 249:	movdqu xmm2,XMMWORD PTR [r15]
 24e:	movdqu XMMWORD PTR [r12+0x130],xmm2
 258:	mov    r15d,0x4206d0
 25e:	movdqu xmm3,XMMWORD PTR [r15]
 263:	movdqu XMMWORD PTR [r12+0x150],xmm3
 26d:	mov    r15d,0x3e8
 273:	mov    QWORD PTR [r12+0xa0],r15
 27b:	mov    r15,r14
 27e:	add    r15,0xa0
 285:	mov    rbp,r15
 288:	add    rbp,0x10
 28c:	movdqu XMMWORD PTR [r15],xmm4
 291:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 296:	mov    r15d,0x4206b0
 29c:	movdqu xmm2,XMMWORD PTR [r15]
 2a1:	movdqu XMMWORD PTR [r12+0x130],xmm2
 2ab:	mov    r15d,0x420660
 2b1:	movdqu xmm4,XMMWORD PTR [r15]
 2b6:	movdqu XMMWORD PTR [r12+0x140],xmm4
 2c0:	mov    r15,r13
 2c3:	add    r15,0x80
 2ca:	mov    rbp,QWORD PTR [r12+0xf0]
 2d2:	mov    QWORD PTR [r15],rbp
 2d5:	mov    r15,r14
 2d8:	add    r15,0xc0
 2df:	mov    rbp,r15
 2e2:	add    rbp,0x10
 2e6:	movdqu XMMWORD PTR [r15],xmm3
 2eb:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 2f0:	mov    r15d,0x420680
 2f6:	movdqu xmm2,XMMWORD PTR [r15]
 2fb:	movdqu XMMWORD PTR [r12+0x130],xmm2
 305:	mov    r15d,0x4206e0
 30b:	mov    rbp,QWORD PTR [r15]
 30e:	mov    r15d,0x0
 314:	mov    QWORD PTR [r12+0x110],rbp
 31c:	mov    QWORD PTR [r12+0x118],r15
 324:	mov    r15d,0x4206e8
 32a:	mov    QWORD PTR [r12+0x40],r15
 32f:	mov    r15,r14
 332:	add    r15,0xe0
 339:	mov    r9,r15
 33c:	add    r9,0x10
 340:	movdqu XMMWORD PTR [r15],xmm4
 345:	movdqu XMMWORD PTR [r9],xmm2
 34a:	mov    r15d,0x420748
 350:	movdqu xmm2,XMMWORD PTR [r15]
 355:	movdqu XMMWORD PTR [r12+0x130],xmm2
 35f:	mov    r15,r14
 362:	add    r15,0x120
 369:	mov    QWORD PTR [r15],rbp
 36c:	mov    r15d,0x420728
 372:	mov    ebp,0x420738
 377:	movdqu xmm3,XMMWORD PTR [r15]
 37c:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
 381:	movdqu XMMWORD PTR [r12+0x120],xmm3
 38b:	movdqu XMMWORD PTR [r12+0x110],xmm4
 395:	mov    r15,r13
 398:	add    r15,0x60
 39c:	movdqu XMMWORD PTR [r15],xmm2
 3a1:	mov    r15,r14
 3a4:	add    r15,0x128
 3ab:	mov    DWORD PTR [r15],r8d
 3ae:	mov    r15,r13
 3b1:	add    r15,0x40
 3b5:	mov    rbp,r15
 3b8:	add    rbp,0x10
 3bc:	movdqu XMMWORD PTR [r15],xmm3
 3c1:	movdqu XMMWORD PTR [rbp+0x0],xmm4
 3c6:	mov    r15d,0x4206e8
 3cc:	mov    ebp,0x4206f8
 3d1:	movdqu xmm2,XMMWORD PTR [r15]
 3d6:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
 3db:	movdqu XMMWORD PTR [r12+0x110],xmm2
 3e5:	movdqu XMMWORD PTR [r12+0x120],xmm3
 3ef:	mov    r15,r13
 3f2:	add    r15,0x10
 3f6:	movdqu XMMWORD PTR [r13+0x0],xmm2
 3fc:	movdqu XMMWORD PTR [r15],xmm3
 401:	mov    r15d,0x420708
 407:	mov    ebp,0x420718
 40c:	movdqu xmm2,XMMWORD PTR [r15]
 411:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
 416:	movdqu XMMWORD PTR [r12+0x110],xmm2
 420:	movdqu XMMWORD PTR [r12+0x130],xmm3
 42a:	mov    r15,r13
 42d:	add    r15,0x20
 431:	mov    rbp,r15
 434:	add    rbp,0x10
 438:	movdqu XMMWORD PTR [r15],xmm2
 43d:	movdqu XMMWORD PTR [rbp+0x0],xmm3
 442:	mov    QWORD PTR [r12],r13
 446:	mov    r13d,0x0
 44c:	or     r13,r14
 44f:	mov    QWORD PTR [r12+0x8],r13
 454:	mov    r13d,0x12c
 45a:	mov    QWORD PTR [r12+0x10],r13
 45f:	mov    r13d,0x410274
 465:	mov    QWORD PTR [r12+0xf0],r13
 46d:	mov    r13d,0x410338
 473:	mov    QWORD PTR [r12+0x100],r13
 47b:	mov    r11,QWORD PTR [rsp]
 47f:	mov    QWORD PTR [r12+0x398],r11
 487:	mov    edi,0x410338
 48c:	mov    QWORD PTR [r12+0x100],rdi
 494:	add    rsp,0x10
 498:	jmp    QWORD PTR [rip+0x2]        # 0x4a0
 49e:	xchg   ax,ax
 4a0:	shl    ah,0xef
 4a3:	sbb    eax,0x7da1
 4a8:	mov    al,0xe4
 4aa:	out    dx,eax
 4ab:	sbb    eax,0x7da1
 4b0:	movabs r11,0x580415130940
 4ba:	jmp    r11
 4bd:	nop
 4be:	nop
 4bf:	nop
