
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sha/candidate/0/5.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x30
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp+0x18],r11
  11:	mov    rax,QWORD PTR [r12+0xf8]
  19:	mov    r14,QWORD PTR [r12+0xf8]
  21:	add    r14,0x4
  25:	mov    rdi,QWORD PTR [r12+0xf8]
  2d:	mov    r15d,DWORD PTR [rdi]
  30:	mov    ebp,DWORD PTR [r14]
  33:	mov    QWORD PTR [r12+0x40],r15
  38:	mov    QWORD PTR [r12+0x50],rbp
  3d:	mov    r14,QWORD PTR [r12+0xf8]
  45:	add    r14,0x8
  49:	mov    r8,r14
  4c:	add    r8,0x4
  50:	mov    r9d,DWORD PTR [r14]
  53:	mov    eax,DWORD PTR [r8]
  56:	mov    QWORD PTR [rsp],rax
  5a:	mov    QWORD PTR [r12+0x58],r9
  5f:	mov    rax,QWORD PTR [rsp]
  63:	mov    QWORD PTR [r12+0x60],rax
  68:	mov    r8d,0x430860
  6e:	mov    QWORD PTR [r12+0x48],r8
  73:	mov    r8,QWORD PTR [r12+0xf8]
  7b:	add    r8,0x80
  82:	mov    r13,QWORD PTR [r8]
  85:	mov    QWORD PTR [r12+0xf0],r13
  8d:	movabs rcx,0xff00ff00ff00ff
  97:	mov    r13,r15
  9a:	and    r13,rcx
  9d:	shl    r13,0x8
  a1:	movabs rcx,0xff00ff00ff00ff00
  ab:	mov    r8,r15
  ae:	and    r8,rcx
  b1:	shr    r8,0x8
  b5:	or     r8,r13
  b8:	movabs rcx,0xffff0000ffff
  c2:	mov    r13,r8
  c5:	and    r13,rcx
  c8:	shl    r13,0x10
  cc:	movabs rcx,0xffff0000ffff0000
  d6:	and    r8,rcx
  d9:	shr    r8,0x10
  dd:	or     r8,r13
  e0:	mov    ecx,0xffffffff
  e5:	and    r8,rcx
  e8:	mov    QWORD PTR [r12+0x40],r8
  ed:	movabs rcx,0xff00ff00ff00ff
  f7:	mov    r13,rbp
  fa:	and    r13,rcx
  fd:	shl    r13,0x8
 101:	movabs rcx,0xff00ff00ff00ff00
 10b:	mov    r15,rbp
 10e:	and    r15,rcx
 111:	shr    r15,0x8
 115:	or     r15,r13
 118:	movabs rcx,0xffff0000ffff
 122:	mov    r13,r15
 125:	and    r13,rcx
 128:	shl    r13,0x10
 12c:	movabs rcx,0xffff0000ffff0000
 136:	and    r15,rcx
 139:	shr    r15,0x10
 13d:	or     r15,r13
 140:	mov    ecx,0xffffffff
 145:	and    r15,rcx
 148:	mov    QWORD PTR [r12+0x50],r15
 14d:	mov    r13d,0x430860
 153:	mov    ebp,0x430864
 158:	mov    rax,r8
 15b:	mov    eax,eax
 15d:	mov    r14d,eax
 160:	mov    rax,r15
 163:	mov    eax,eax
 165:	mov    r8d,eax
 168:	mov    DWORD PTR [r13+0x0],r14d
 16c:	mov    r13d,0x0
 172:	mov    DWORD PTR [r12+0x32c],r13d
 17a:	mov    DWORD PTR [rbp+0x0],r8d
 17e:	movabs rcx,0xff00ff00ff00ff
 188:	mov    r13,r9
 18b:	and    r13,rcx
 18e:	shl    r13,0x8
 192:	movabs rcx,0xff00ff00ff00ff00
 19c:	mov    r14,r9
 19f:	and    r14,rcx
 1a2:	shr    r14,0x8
 1a6:	or     r14,r13
 1a9:	movabs rcx,0xffff0000ffff
 1b3:	mov    r13,r14
 1b6:	and    r13,rcx
 1b9:	shl    r13,0x10
 1bd:	movabs rcx,0xffff0000ffff0000
 1c7:	and    r14,rcx
 1ca:	shr    r14,0x10
 1ce:	or     r14,r13
 1d1:	mov    ecx,0xffffffff
 1d6:	and    r14,rcx
 1d9:	mov    QWORD PTR [r12+0x40],r14
 1de:	movabs rcx,0xff00ff00ff00ff
 1e8:	mov    r13,QWORD PTR [rsp]
 1ec:	and    r13,rcx
 1ef:	shl    r13,0x8
 1f3:	movabs rcx,0xff00ff00ff00ff00
 1fd:	mov    r15,QWORD PTR [rsp]
 201:	and    r15,rcx
 204:	shr    r15,0x8
 208:	or     r15,r13
 20b:	movabs rcx,0xffff0000ffff
 215:	mov    r13,r15
 218:	and    r13,rcx
 21b:	shl    r13,0x10
 21f:	movabs rcx,0xffff0000ffff0000
 229:	and    r15,rcx
 22c:	shr    r15,0x10
 230:	or     r15,r13
 233:	mov    ecx,0xffffffff
 238:	and    r15,rcx
 23b:	mov    QWORD PTR [r12+0x58],r15
 240:	mov    r13,QWORD PTR [r12+0xf8]
 248:	add    r13,0x10
 24c:	mov    rbp,r13
 24f:	add    rbp,0x4
 253:	mov    r8d,DWORD PTR [r13+0x0]
 257:	mov    eax,DWORD PTR [rbp+0x0]
 25a:	mov    QWORD PTR [rsp+0x8],rax
 25f:	mov    QWORD PTR [r12+0x50],r8
 264:	mov    rax,QWORD PTR [rsp+0x8]
 269:	mov    QWORD PTR [r12+0x60],rax
 26e:	mov    ebp,0x430868
 273:	mov    r9d,0x43086c
 279:	mov    rax,r14
 27c:	mov    eax,eax
 27e:	mov    r13d,eax
 281:	mov    rax,r15
 284:	mov    eax,eax
 286:	mov    r14d,eax
 289:	mov    DWORD PTR [rbp+0x0],r13d
 28d:	mov    DWORD PTR [r9],r14d
 290:	mov    r13,QWORD PTR [r12+0xf8]
 298:	add    r13,0x90
 29f:	mov    r14,r13
 2a2:	add    r14,0x8
 2a6:	mov    r15,QWORD PTR [r13+0x0]
 2aa:	mov    r13,QWORD PTR [r14]
 2ad:	mov    QWORD PTR [r12+0xa0],r15
 2b5:	mov    QWORD PTR [r12+0x98],r13
 2bd:	movabs rcx,0xff00ff00ff00ff
 2c7:	mov    r13,r8
 2ca:	and    r13,rcx
 2cd:	shl    r13,0x8
 2d1:	movabs rcx,0xff00ff00ff00ff00
 2db:	mov    r14,r8
 2de:	and    r14,rcx
 2e1:	shr    r14,0x8
 2e5:	or     r14,r13
 2e8:	movabs rcx,0xffff0000ffff
 2f2:	mov    r13,r14
 2f5:	and    r13,rcx
 2f8:	shl    r13,0x10
 2fc:	movabs rcx,0xffff0000ffff0000
 306:	and    r14,rcx
 309:	shr    r14,0x10
 30d:	or     r14,r13
 310:	mov    ecx,0xffffffff
 315:	and    r14,rcx
 318:	mov    QWORD PTR [r12+0x40],r14
 31d:	movabs rcx,0xff00ff00ff00ff
 327:	mov    r13,QWORD PTR [rsp+0x8]
 32c:	and    r13,rcx
 32f:	shl    r13,0x8
 333:	movabs rcx,0xff00ff00ff00ff00
 33d:	mov    r15,QWORD PTR [rsp+0x8]
 342:	and    r15,rcx
 345:	shr    r15,0x8
 349:	or     r15,r13
 34c:	movabs rcx,0xffff0000ffff
 356:	mov    r13,r15
 359:	and    r13,rcx
 35c:	shl    r13,0x10
 360:	movabs rcx,0xffff0000ffff0000
 36a:	and    r15,rcx
 36d:	shr    r15,0x10
 371:	or     r15,r13
 374:	mov    ecx,0xffffffff
 379:	and    r15,rcx
 37c:	mov    QWORD PTR [r12+0x58],r15
 381:	mov    r13,QWORD PTR [r12+0xf8]
 389:	add    r13,0x18
 38d:	mov    rbp,r13
 390:	add    rbp,0x4
 394:	mov    r8d,DWORD PTR [r13+0x0]
 398:	mov    eax,DWORD PTR [rbp+0x0]
 39b:	mov    QWORD PTR [rsp+0x10],rax
 3a0:	mov    QWORD PTR [r12+0x50],r8
 3a5:	mov    rax,QWORD PTR [rsp+0x10]
 3aa:	mov    QWORD PTR [r12+0x60],rax
 3af:	mov    ebp,0x430870
 3b4:	mov    r9d,0x430874
 3ba:	mov    rax,r14
 3bd:	mov    eax,eax
 3bf:	mov    r13d,eax
 3c2:	mov    rax,r15
 3c5:	mov    eax,eax
 3c7:	mov    r14d,eax
 3ca:	mov    DWORD PTR [rbp+0x0],r13d
 3ce:	mov    DWORD PTR [r9],r14d
 3d1:	movabs rcx,0xff00ff00ff00ff
 3db:	mov    r13,r8
 3de:	and    r13,rcx
 3e1:	shl    r13,0x8
 3e5:	movabs rcx,0xff00ff00ff00ff00
 3ef:	mov    r14,r8
 3f2:	and    r14,rcx
 3f5:	shr    r14,0x8
 3f9:	or     r14,r13
 3fc:	movabs rcx,0xffff0000ffff
 406:	mov    r13,r14
 409:	and    r13,rcx
 40c:	shl    r13,0x10
 410:	movabs rcx,0xffff0000ffff0000
 41a:	and    r14,rcx
 41d:	shr    r14,0x10
 421:	or     r14,r13
 424:	mov    ecx,0xffffffff
 429:	and    r14,rcx
 42c:	mov    QWORD PTR [r12+0x40],r14
 431:	movabs rcx,0xff00ff00ff00ff
 43b:	mov    r13,QWORD PTR [rsp+0x10]
 440:	and    r13,rcx
 443:	shl    r13,0x8
 447:	movabs rcx,0xff00ff00ff00ff00
 451:	mov    r15,QWORD PTR [rsp+0x10]
 456:	and    r15,rcx
 459:	shr    r15,0x8
 45d:	or     r15,r13
 460:	movabs rcx,0xffff0000ffff
 46a:	mov    r13,r15
 46d:	and    r13,rcx
 470:	shl    r13,0x10
 474:	movabs rcx,0xffff0000ffff0000
 47e:	and    r15,rcx
 481:	shr    r15,0x10
 485:	or     r15,r13
 488:	mov    ecx,0xffffffff
 48d:	and    r15,rcx
 490:	mov    QWORD PTR [r12+0x50],r15
 495:	mov    r13d,0x430878
 49b:	mov    ebp,0x43087c
 4a0:	mov    rax,r14
 4a3:	mov    eax,eax
 4a5:	mov    r8d,eax
 4a8:	mov    rax,r15
 4ab:	mov    eax,eax
 4ad:	mov    r14d,eax
 4b0:	mov    DWORD PTR [r13+0x0],r8d
 4b4:	mov    DWORD PTR [rbp+0x0],r14d
 4b8:	mov    r13,QWORD PTR [r12+0xf8]
 4c0:	add    r13,0xa0
 4c7:	mov    QWORD PTR [r12+0xf8],r13
 4cf:	mov    rcx,QWORD PTR [r12+0x380]
 4d7:	jrcxz  0x4de
 4d9:	jmp    0x514
 4de:	mov    r13,QWORD PTR [r12+0xf0]
 4e6:	mov    QWORD PTR [r12+0x100],r13
 4ee:	mov    r11,QWORD PTR [rsp+0x18]
 4f3:	mov    QWORD PTR [r12+0x398],r11
 4fb:	mov    rdi,QWORD PTR [r12+0x100]
 503:	add    rsp,0x30
 507:	movabs r11,0x580415130940
 511:	jmp    r11
 514:	mov    eax,0x410334
 519:	mov    QWORD PTR [r12+0x100],rax
 521:	push   rdx
 522:	push   rsi
 523:	push   r10
 525:	push   r11
 527:	mov    rdx,QWORD PTR [rsp+0x38]
 52c:	mov    r10d,edx
 52f:	and    r10d,0xc000
 536:	shl    r10d,0x10
 53a:	mov    r11d,edx
 53d:	and    r11d,0x100
 544:	shl    r11d,0x15
 548:	or     r10d,r11d
 54b:	and    edx,0x1
 54e:	shl    edx,0x1c
 551:	or     r10d,edx
 554:	btc    r10,0x1d
 559:	mov    r11d,0xf0000000
 55f:	and    r11,r10
 562:	movabs rsi,0xffffffff0fffffff
 56c:	and    rbx,rsi
 56f:	or     rbx,r11
 572:	pop    r11
 574:	pop    r10
 576:	pop    rsi
 577:	pop    rdx
 578:	mov    QWORD PTR [r12+0x108],rbx
 580:	add    rsp,0x30
 584:	mov    eax,0xc
 589:	movabs r11,0x580415130ca0
 593:	jmp    r11
 596:	nop
 597:	nop
