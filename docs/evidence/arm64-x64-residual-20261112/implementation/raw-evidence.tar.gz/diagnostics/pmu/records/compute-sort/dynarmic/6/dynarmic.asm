0000797dbbbce69b  nop [rax+rax*1], eax
0000797dbbbce6a0  mov rax, [r15+0xF8]
0000797dbbbce6a7  lea r14, [rax-0x20]
0000797dbbbce6ab  mov r12, [r15+0xF0]
0000797dbbbce6b2  mov [r13+r14*1], r12
0000797dbbbce6b7  mov [r15+0xF8], r14
0000797dbbbce6be  lea r14, [rax-0x10]
0000797dbbbce6c2  mov r12, [r15+0xA0]
0000797dbbbce6c9  mov r11, [r15+0x98]
0000797dbbbce6d0  mov [r13+r14*1], r12
0000797dbbbce6d5  lea r14, [rax-0x08]
0000797dbbbce6d9  mov [r13+r14*1], r11
0000797dbbbce6de  mov qword ptr [r15+0xA0], 0x00
0000797dbbbce6e9  mov qword ptr [r15+0x98], 0x4202A0
0000797dbbbce6f4  mov eax, [r15+0xA0]
0000797dbbbce6fb  lea r14d, [eax+0x11]
0000797dbbbce700  mov r14d, r14d
0000797dbbbce703  mov [r15], r14
0000797dbbbce706  mov qword ptr [r15+0xF0], 0x410184
0000797dbbbce711  mov r14d, [r15+0x320]
0000797dbbbce718  mov eax, 0x410184
0000797dbbbce71d  mov rcx, 0x797DBBBCE800
0000797dbbbce727  mov [r15+r14*8+0x328], rax
0000797dbbbce72f  mov [r15+r14*8+0x368], rcx
0000797dbbbce737  add r14d, 0x01
0000797dbbbce73b  and r14d, 0x07
0000797dbbbce73f  mov [r15+0x320], r14d
0000797dbbbce746  cmp dword ptr [r15+0x318], 0x00
0000797dbbbce74e  jz 0x0000797DBBBCE7A0
0000797dbbbce754  nop [rax+rax*1], ax
0000797dbbbce75d  nop [rax+rax*1], eax
0000797dbbbce765  mov eax, 0x41021C
0000797dbbbce76a  mov [r15+0x100], rax
0000797dbbbce771  jmp 0x0000797DBB9FE110
0000797dbbbce776  int3
0000797dbbbce777  call 0x0000797DBBAE2CE0
0000797dbbbce77c  jmp 0x0000797DBBBCE6B7
0000797dbbbce781  call 0x0000797DBBAE2CE0
0000797dbbbce786  jmp 0x0000797DBBBCE6D5
0000797dbbbce78b  call 0x0000797DBBAE1A60
0000797dbbbce790  jmp 0x0000797DBBBCE6DE
0000797dbbbce795  int3
0000797dbbbce796  nop [rax+rax*1], ax
0000797dbbbce79f  nop
0000797dbbbce7a0  mov eax, 0x846CA68B
0000797dbbbce7a5  mov eax, eax
0000797dbbbce7a7  mov [r15+0x48], rax
0000797dbbbce7ab  mov eax, [r15]
0000797dbbbce7ae  imul eax, eax, 0x7FEB352D
0000797dbbbce7b4  mov [rsp+0x10], eax
0000797dbbbce7b8  shr eax, 0x0F
0000797dbbbce7bb  mov r14d, [rsp+0x10]
0000797dbbbce7c0  xor r14d, eax
0000797dbbbce7c3  imul r14d, r14d, 0x846CA68B
0000797dbbbce7ca  mov [rsp+0x10], r14d
0000797dbbbce7cf  mov r14d, r14d
0000797dbbbce7d2  mov [r15+0x40], r14
0000797dbbbce7d6  mov eax, [rsp+0x10]
0000797dbbbce7da  shr eax, 0x10
0000797dbbbce7dd  mov r14d, [rsp+0x10]
0000797dbbbce7e2  xor r14d, eax
0000797dbbbce7e5  mov r14d, r14d
0000797dbbbce7e8  mov [r15], r14
0000797dbbbce7eb  mov rax, [r15+0xF0]
0000797dbbbce7f2  mov [r15+0x100], rax
0000797dbbbce7f9  jmp 0x0000797DBBBCE5C0
0000797dbbbce7fe  int3
0000797dbbbce7ff  int3
0000797dbbbce800  mov rax, [r15+0xA0]
0000797dbbbce807  mov [rsp+0x10], rax
0000797dbbbce80c  shl rax, 0x02
0000797dbbbce810  mov r14, [r15+0x98]
0000797dbbbce817  lea r12, [r14+rax*1]
0000797dbbbce81b  mov eax, [r15]
0000797dbbbce81e  mov [r13+r12*1], eax
0000797dbbbce823  mov rax, [rsp+0x10]
0000797dbbbce828  lea r14, [rax+0x01]
0000797dbbbce82c  mov [r15+0xA0], r14
0000797dbbbce833  xor eax, eax
0000797dbbbce835  mov r12d, 0x400
0000797dbbbce83b  cmp r14, r12
0000797dbbbce83e  cmc
0000797dbbbce83f  lahf
0000797dbbbce840  seto al
0000797dbbbce843  mov [r15+0x108], eax
0000797dbbbce84a  mov eax, [r15+0x108]
0000797dbbbce851  sahf
0000797dbbbce852  jnz 0x0000797DBBBCE884
0000797dbbbce854  cmp dword ptr [r15+0x318], 0x00
0000797dbbbce85c  jz 0x0000797DBBBCE950
0000797dbbbce862  nop [rax+rax*1], ax
0000797dbbbce86b  nop [rax+rax*1], eax
0000797dbbbce873  mov eax, 0x410194
0000797dbbbce878  mov [r15+0x100], rax
0000797dbbbce87f  jmp 0x0000797DBB9FE110
0000797dbbbce884  cmp dword ptr [r15+0x318], 0x00
0000797dbbbce88c  jz 0x0000797DBBBCE8C0
0000797dbbbce892  nop [rax+rax*1], ax
0000797dbbbce89b  nop [rax+rax*1], eax
0000797dbbbce8a3  mov eax, 0x41017C
0000797dbbbce8a8  mov [r15+0x100], rax
0000797dbbbce8af  jmp 0x0000797DBB9FE110
0000797dbbbce8b4  int3
0000797dbbbce8b5  call 0x0000797DBBAB4B70
0000797dbbbce8ba  jmp 0x0000797DBBBCE823
0000797dbbbce8bf  int3
0000797dbbbce8c0  mov eax, [r15+0xA0]
0000797dbbbce8c7  lea r14d, [eax+0x11]
0000797dbbbce8cc  mov r14d, r14d
0000797dbbbce8cf  mov [r15], r14
0000797dbbbce8d2  mov qword ptr [r15+0xF0], 0x410184
0000797dbbbce8dd  mov r14d, [r15+0x320]
0000797dbbbce8e4  mov eax, 0x410184
0000797dbbbce8e9  mov rcx, 0x797DBBBCE800
0000797dbbbce8f3  mov [r15+r14*8+0x328], rax
0000797dbbbce8fb  mov [r15+r14*8+0x368], rcx
0000797dbbbce903  add r14d, 0x01
0000797dbbbce907  and r14d, 0x07
0000797dbbbce90b  mov [r15+0x320], r14d
0000797dbbbce912  cmp dword ptr [r15+0x318], 0x00
0000797dbbbce91a  jz 0x0000797DBBBCE7A0
0000797dbbbce920  nop [rax+rax*1], ax
0000797dbbbce929  nop [rax+rax*1], eax
0000797dbbbce931  mov eax, 0x41021C
0000797dbbbce936  mov [r15+0x100], rax
0000797dbbbce93d  jmp 0x0000797DBB9FE110
0000797dbbbce942  int3
0000797dbbbce943  int3
0000797dbbbce944  nop [rax+rax*1], ax
0000797dbbbce94d  nop [rax], eax
0000797dbbbce950  mov qword ptr [r15+0x40], 0x01
0000797dbbbce958  cmp dword ptr [r15+0x318], 0x00
0000797dbbbce960  jz 0x0000797DBBBCE990
0000797dbbbce966  nop [rax+rax*1], ax
0000797dbbbce96f  nop [rax+rax*1], eax
0000797dbbbce977  mov eax, 0x4101B0
0000797dbbbce97c  mov [r15+0x100], rax
0000797dbbbce983  jmp 0x0000797DBB9FE110
0000797dbbbce988  int3
0000797dbbbce989  int3
0000797dbbbce98a  nop [rax+rax*1], ax
0000797dbbbce990  mov rax, [r15+0x40]
0000797dbbbce994  mov [rsp+0x10], rax
0000797dbbbce999  shl rax, 0x02
0000797dbbbce99d  mov r14, [r15+0x98]
0000797dbbbce9a4  lea r12, [r14+rax*1]
0000797dbbbce9a8  mov eax, [r13+r12*1]
0000797dbbbce9ad  mov [rsp+0x20], eax
0000797dbbbce9b1  mov eax, eax
0000797dbbbce9b3  mov [r15+0x48], rax
0000797dbbbce9b7  mov rax, [rsp+0x10]
0000797dbbbce9bc  mov [r15+0x50], rax
0000797dbbbce9c0  mov eax, [r15+0x50]
0000797dbbbce9c4  lea r12d, [eax-0x01]
0000797dbbbce9c9  mov r12d, r12d
0000797dbbbce9cc  mov [r15+0x58], r12
0000797dbbbce9d0  mov rax, [r15+0x58]
0000797dbbbce9d4  mov r12d, eax
0000797dbbbce9d7  mov r12d, r12d
0000797dbbbce9da  shl r12, 0x02
0000797dbbbce9de  lea rax, [r14+r12*1]
0000797dbbbce9e2  mov r14d, [r13+rax*1]
0000797dbbbce9e7  mov [rsp+0x10], r14d
0000797dbbbce9ec  mov r14d, r14d
0000797dbbbce9ef  mov [r15+0x60], r14
0000797dbbbce9f3  xor eax, eax
0000797dbbbce9f5  mov r14d, [rsp+0x10]
0000797dbbbce9fa  mov r12d, [rsp+0x20]
0000797dbbbce9ff  cmp r14d, r12d
0000797dbbbcea02  cmc
0000797dbbbcea03  lahf
0000797dbbbcea04  seto al
0000797dbbbcea07  mov [r15+0x108], eax
0000797dbbbcea0e  mov eax, [r15+0x108]
0000797dbbbcea15  sahf
0000797dbbbcea16  cmc
0000797dbbbcea17  jbe 0x0000797DBBBCEA49
0000797dbbbcea19  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcea21  jz 0x0000797DBBBCEA90
0000797dbbbcea27  nop [rax+rax*1], ax
0000797dbbbcea30  nop [rax+rax*1], eax
0000797dbbbcea38  mov eax, 0x4101C8
0000797dbbbcea3d  mov [r15+0x100], rax
0000797dbbbcea44  jmp 0x0000797DBB9FE110
0000797dbbbcea49  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcea51  jz 0x0000797DBBBCED30
0000797dbbbcea57  nop [rax+rax*1], ax
0000797dbbbcea60  nop [rax+rax*1], eax
0000797dbbbcea68  mov eax, 0x4101A0
0000797dbbbcea6d  mov [r15+0x100], rax
0000797dbbbcea74  jmp 0x0000797DBB9FE110
0000797dbbbcea79  int3
0000797dbbbcea7a  call 0x0000797DBBAB4690
0000797dbbbcea7f  jmp 0x0000797DBBBCE9AD
0000797dbbbcea84  call 0x0000797DBBA0DAE0
0000797dbbbcea89  jmp 0x0000797DBBBCE9E7
0000797dbbbcea8e  int3
0000797dbbbcea8f  nop
0000797dbbbcea90  mov rax, [r15+0x50]
0000797dbbbcea94  mov [rsp+0x10], rax
0000797dbbbcea99  shl rax, 0x02
0000797dbbbcea9d  mov r14, [r15+0x98]
0000797dbbbceaa4  lea r12, [r14+rax*1]
0000797dbbbceaa8  mov eax, [r15+0x60]
0000797dbbbceaac  mov [r13+r12*1], eax
0000797dbbbceab1  mov rax, [rsp+0x10]
0000797dbbbceab6  lea r14, [rax-0x01]
0000797dbbbceaba  mov [r15+0x50], r14
0000797dbbbceabe  mov rax, [r15+0x58]
0000797dbbbceac2  test rax, rax
0000797dbbbceac5  setz al
0000797dbbbceac8  movzx rax, al
0000797dbbbceacc  mov [rsp+0x414], al
0000797dbbbcead3  cmp byte ptr [rsp+0x414], 0x00
0000797dbbbceadb  jz 0x0000797DBBBCEB0D
0000797dbbbceadd  cmp dword ptr [r15+0x318], 0x00
0000797dbbbceae5  jz 0x0000797DBBBCEB50
0000797dbbbceaeb  nop [rax+rax*1], ax
0000797dbbbceaf4  nop [rax+rax*1], eax
0000797dbbbceafc  mov eax, 0x4101D4
0000797dbbbceb01  mov [r15+0x100], rax
0000797dbbbceb08  jmp 0x0000797DBB9FE110
0000797dbbbceb0d  cmp dword ptr [r15+0x318], 0x00
0000797dbbbceb15  jz 0x0000797DBBBCEC50
0000797dbbbceb1b  nop [rax+rax*1], ax
0000797dbbbceb24  nop [rax+rax*1], eax
0000797dbbbceb2c  mov eax, 0x4101B8
0000797dbbbceb31  mov [r15+0x100], rax
0000797dbbbceb38  jmp 0x0000797DBB9FE110
0000797dbbbceb3d  int3
0000797dbbbceb3e  call 0x0000797DBBAB4B70
0000797dbbbceb43  jmp 0x0000797DBBBCEAB1
0000797dbbbceb48  int3
0000797dbbbceb49  nop [rax], eax
0000797dbbbceb50  cmp dword ptr [r15+0x318], 0x00
0000797dbbbceb58  jz 0x0000797DBBBCEB90
0000797dbbbceb5e  nop [rax+rax*1], ax
0000797dbbbceb67  nop [rax+rax*1], eax
0000797dbbbceb6f  mov eax, 0x41019C
0000797dbbbceb74  mov [r15+0x100], rax
0000797dbbbceb7b  jmp 0x0000797DBB9FE110
0000797dbbbceb80  int3
0000797dbbbceb81  int3
0000797dbbbceb82  nop [rax+rax*1], ax
0000797dbbbceb8b  nop [rax+rax*1], eax
0000797dbbbceb90  mov qword ptr [r15+0x50], 0x00
0000797dbbbceb98  mov rax, [r15+0x40]
0000797dbbbceb9c  lea r14, [rax+0x01]
0000797dbbbceba0  mov [r15+0x40], r14
0000797dbbbceba4  mov rax, [r15+0x98]
0000797dbbbcebab  mov r12d, [r15+0x48]
0000797dbbbcebaf  mov [r13+rax*1], r12d
0000797dbbbcebb4  xor eax, eax
0000797dbbbcebb6  mov r12d, 0x400
0000797dbbbcebbc  cmp r14, r12
0000797dbbbcebbf  cmc
0000797dbbbcebc0  lahf
0000797dbbbcebc1  seto al
0000797dbbbcebc4  mov [r15+0x108], eax
0000797dbbbcebcb  mov eax, [r15+0x108]
0000797dbbbcebd2  sahf
0000797dbbbcebd3  jz 0x0000797DBBBCEC05
0000797dbbbcebd5  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcebdd  jz 0x0000797DBBBCE990
0000797dbbbcebe3  nop [rax+rax*1], ax
0000797dbbbcebec  nop [rax+rax*1], eax
0000797dbbbcebf4  mov eax, 0x4101B0
0000797dbbbcebf9  mov [r15+0x100], rax
0000797dbbbcec00  jmp 0x0000797DBB9FE110
0000797dbbbcec05  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcec0d  jz 0x0000797DBBBCEDF0
0000797dbbbcec13  nop [rax+rax*1], ax
0000797dbbbcec1c  nop [rax+rax*1], eax
0000797dbbbcec24  mov eax, 0x4101D8
0000797dbbbcec29  mov [r15+0x100], rax
0000797dbbbcec30  jmp 0x0000797DBB9FE110
0000797dbbbcec35  int3
0000797dbbbcec36  call 0x0000797DBBA0BAE0
0000797dbbbcec3b  jmp 0x0000797DBBBCEBB4
0000797dbbbcec40  int3
0000797dbbbcec41  nop [rax+rax*1], ax
0000797dbbbcec4a  nop [rax+rax*1], ax
0000797dbbbcec50  mov eax, [r15+0x50]
0000797dbbbcec54  lea r14d, [eax-0x01]
0000797dbbbcec59  mov r14d, r14d
0000797dbbbcec5c  mov [r15+0x58], r14
0000797dbbbcec60  mov rax, [r15+0x58]
0000797dbbbcec64  mov r14d, eax
0000797dbbbcec67  mov r14d, r14d
0000797dbbbcec6a  shl r14, 0x02
0000797dbbbcec6e  mov rax, [r15+0x98]
0000797dbbbcec75  lea r12, [rax+r14*1]
0000797dbbbcec79  mov eax, [r13+r12*1]
0000797dbbbcec7e  mov [rsp+0x10], eax
0000797dbbbcec82  mov eax, eax
0000797dbbbcec84  mov [r15+0x60], rax
0000797dbbbcec88  mov eax, [r15+0x48]
0000797dbbbcec8c  mov [rsp+0x20], eax
0000797dbbbcec90  xor eax, eax
0000797dbbbcec92  mov r14d, [rsp+0x10]
0000797dbbbcec97  mov r12d, [rsp+0x20]
0000797dbbbcec9c  cmp r14d, r12d
0000797dbbbcec9f  cmc
0000797dbbbceca0  lahf
0000797dbbbceca1  seto al
0000797dbbbceca4  mov [r15+0x108], eax
0000797dbbbcecab  mov eax, [r15+0x108]
0000797dbbbcecb2  sahf
0000797dbbbcecb3  cmc
0000797dbbbcecb4  jbe 0x0000797DBBBCECE6
0000797dbbbcecb6  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcecbe  jz 0x0000797DBBBCEA90
0000797dbbbcecc4  nop [rax+rax*1], ax
0000797dbbbceccd  nop [rax+rax*1], eax
0000797dbbbcecd5  mov eax, 0x4101C8
0000797dbbbcecda  mov [r15+0x100], rax
0000797dbbbcece1  jmp 0x0000797DBB9FE110
0000797dbbbcece6  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcecee  jz 0x0000797DBBBCED30
0000797dbbbcecf4  nop [rax+rax*1], ax
0000797dbbbcecfd  nop [rax+rax*1], eax
0000797dbbbced05  mov eax, 0x4101A0
0000797dbbbced0a  mov [r15+0x100], rax
0000797dbbbced11  jmp 0x0000797DBB9FE110
0000797dbbbced16  int3
0000797dbbbced17  call 0x0000797DBBAB4690
0000797dbbbced1c  jmp 0x0000797DBBBCEC7E
0000797dbbbced21  int3
0000797dbbbced22  nop [rax+rax*1], ax
0000797dbbbced2b  nop [rax+rax*1], eax
0000797dbbbced30  mov rax, [r15+0x40]
0000797dbbbced34  lea r14, [rax+0x01]
0000797dbbbced38  mov [r15+0x40], r14
0000797dbbbced3c  mov rax, [r15+0x50]
0000797dbbbced40  mov r12d, eax
0000797dbbbced43  mov r12d, r12d
0000797dbbbced46  shl r12, 0x02
0000797dbbbced4a  mov rax, [r15+0x98]
0000797dbbbced51  lea r11, [rax+r12*1]
0000797dbbbced55  mov eax, [r15+0x48]
0000797dbbbced59  mov [r13+r11*1], eax
0000797dbbbced5e  xor eax, eax
0000797dbbbced60  mov r12d, 0x400
0000797dbbbced66  cmp r14, r12
0000797dbbbced69  cmc
0000797dbbbced6a  lahf
0000797dbbbced6b  seto al
0000797dbbbced6e  mov [r15+0x108], eax
0000797dbbbced75  mov eax, [r15+0x108]
0000797dbbbced7c  sahf
0000797dbbbced7d  jz 0x0000797DBBBCEDAF
0000797dbbbced7f  cmp dword ptr [r15+0x318], 0x00
0000797dbbbced87  jz 0x0000797DBBBCE990
0000797dbbbced8d  nop [rax+rax*1], ax
0000797dbbbced96  nop [rax+rax*1], eax
0000797dbbbced9e  mov eax, 0x4101B0
0000797dbbbceda3  mov [r15+0x100], rax
0000797dbbbcedaa  jmp 0x0000797DBB9FE110
0000797dbbbcedaf  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcedb7  jz 0x0000797DBBBCEDF0
0000797dbbbcedbd  nop [rax+rax*1], ax
0000797dbbbcedc6  nop [rax+rax*1], eax
0000797dbbbcedce  mov eax, 0x4101D8
0000797dbbbcedd3  mov [r15+0x100], rax
0000797dbbbcedda  jmp 0x0000797DBB9FE110
0000797dbbbceddf  int3
0000797dbbbcede0  call 0x0000797DBBAA4270
0000797dbbbcede5  jmp 0x0000797DBBBCED5E
0000797dbbbcedea  int3
0000797dbbbcedeb  nop [rax+rax*1], eax
0000797dbbbcedf0  mov qword ptr [r15+0x40], 0x420000
0000797dbbbcedf8  mov eax, 0x420288
0000797dbbbcedfd  mov r14, [r13+rax*1]
0000797dbbbcee02  mov rax, [r15+0x98]
0000797dbbbcee09  mov r12d, [r13+rax*1]
0000797dbbbcee0e  lea r11, [rax+0x04]
0000797dbbbcee12  mov eax, [r13+r11*1]
0000797dbbbcee17  mov r12d, r12d
0000797dbbbcee1a  mov [r15+0x68], r12
0000797dbbbcee1e  mov eax, eax
0000797dbbbcee20  mov [r15+0x60], rax
0000797dbbbcee24  mov rax, [r15+0x68]
0000797dbbbcee28  mov [r15+0x68], rax
0000797dbbbcee2c  mov qword ptr [r15+0x58], 0x02
0000797dbbbcee34  mov [rsp+0x10], rax
0000797dbbbcee39  xor eax, eax
0000797dbbbcee3b  mov r12d, 0x02
0000797dbbbcee41  mov r11d, 0x400
0000797dbbbcee47  cmp r12, r11
0000797dbbbcee4a  cmc
0000797dbbbcee4b  lahf
0000797dbbbcee4c  seto al
0000797dbbbcee4f  mov [r15+0x108], eax
0000797dbbbcee56  mov rax, [r15+0x60]
0000797dbbbcee5a  mov r12d, 0x02
0000797dbbbcee60  imul rax, r12
0000797dbbbcee64  mov [r15+0x50], rax
0000797dbbbcee68  mov rax, [rsp+0x10]
0000797dbbbcee6d  lea r12, [rax+r14*1]
0000797dbbbcee71  mov [r15+0x48], r12
0000797dbbbcee75  mov eax, [r15+0x108]
0000797dbbbcee7c  sahf
0000797dbbbcee7d  jnz 0x0000797DBBBCEEAF
0000797dbbbcee7f  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcee87  jz 0x0000797DBBBCF020
0000797dbbbcee8d  nop [rax+rax*1], ax
0000797dbbbcee96  nop [rax+rax*1], eax
0000797dbbbcee9e  mov eax, 0x410208
0000797dbbbceea3  mov [r15+0x100], rax
0000797dbbbceeaa  jmp 0x0000797DBB9FE110
0000797dbbbceeaf  cmp dword ptr [r15+0x318], 0x00
0000797dbbbceeb7  jz 0x0000797DBBBCEF00
0000797dbbbceebd  nop [rax+rax*1], ax
0000797dbbbceec6  nop [rax+rax*1], eax
0000797dbbbceece  mov eax, 0x4101E8
0000797dbbbceed3  mov [r15+0x100], rax
0000797dbbbceeda  jmp 0x0000797DBB9FE110
0000797dbbbceedf  int3
0000797dbbbceee0  call 0x0000797DBBA0DC20
0000797dbbbceee5  jmp 0x0000797DBBBCEE02
0000797dbbbceeea  call 0x0000797DBBA0B5E0
0000797dbbbceeef  jmp 0x0000797DBBBCEE0E
0000797dbbbceef4  call 0x0000797DBBAA3D90
0000797dbbbceef9  jmp 0x0000797DBBBCEE17
0000797dbbbceefe  int3
0000797dbbbceeff  nop
0000797dbbbcef00  mov rax, [r15+0x98]
0000797dbbbcef07  mov r14, [r15+0x58]
0000797dbbbcef0b  mov [rsp+0x10], r14
0000797dbbbcef10  shl r14, 0x02
0000797dbbbcef14  lea r12, [rax+r14*1]
0000797dbbbcef18  mov eax, [r13+r12*1]
0000797dbbbcef1d  lea r14, [r12+0x04]
0000797dbbbcef22  mov r12d, [r13+r14*1]
0000797dbbbcef27  mov eax, eax
0000797dbbbcef29  mov [r15+0x68], rax
0000797dbbbcef2d  mov r12d, r12d
0000797dbbbcef30  mov [r15+0x60], r12
0000797dbbbcef34  mov rax, [r15+0x68]
0000797dbbbcef38  mov [rsp+0x20], rax
0000797dbbbcef3d  mov r14, [rsp+0x10]
0000797dbbbcef42  imul rax, r14
0000797dbbbcef46  mov r12, [rsp+0x20]
0000797dbbbcef4b  lea r11, [r12+rax*1]
0000797dbbbcef4f  mov [r15+0x68], r11
0000797dbbbcef53  lea rax, [r14+0x02]
0000797dbbbcef57  mov [r15+0x58], rax
0000797dbbbcef5b  mov [rsp+0x10], rax
0000797dbbbcef60  xor eax, eax
0000797dbbbcef62  mov r14, [rsp+0x10]
0000797dbbbcef67  mov r12d, 0x400
0000797dbbbcef6d  cmp r14, r12
0000797dbbbcef70  cmc
0000797dbbbcef71  lahf
0000797dbbbcef72  seto al
0000797dbbbcef75  mov [r15+0x108], eax
0000797dbbbcef7c  mov rax, [r15+0x50]
0000797dbbbcef80  mov r12, [r15+0x60]
0000797dbbbcef84  imul r14, r12
0000797dbbbcef88  lea r12, [rax+r14*1]
0000797dbbbcef8c  mov [r15+0x50], r12
0000797dbbbcef90  mov rax, [r15+0x48]
0000797dbbbcef94  lea r14, [r11+rax*1]
0000797dbbbcef98  mov [r15+0x48], r14
0000797dbbbcef9c  mov eax, [r15+0x108]
0000797dbbbcefa3  sahf
0000797dbbbcefa4  jnz 0x0000797DBBBCEFD6
0000797dbbbcefa6  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcefae  jz 0x0000797DBBBCF020
0000797dbbbcefb4  nop [rax+rax*1], ax
0000797dbbbcefbd  nop [rax+rax*1], eax
0000797dbbbcefc5  mov eax, 0x410208
0000797dbbbcefca  mov [r15+0x100], rax
0000797dbbbcefd1  jmp 0x0000797DBB9FE110
0000797dbbbcefd6  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcefde  jz 0x0000797DBBBCEF00
0000797dbbbcefe4  nop [rax+rax*1], ax
0000797dbbbcefed  nop [rax+rax*1], eax
0000797dbbbceff5  mov eax, 0x4101E8
0000797dbbbceffa  mov [r15+0x100], rax
0000797dbbbcf001  jmp 0x0000797DBB9FE110
0000797dbbbcf006  int3
0000797dbbbcf007  call 0x0000797DBBAB4690
0000797dbbbcf00c  jmp 0x0000797DBBBCEF1D
0000797dbbbcf011  call 0x0000797DBBAE26A0
0000797dbbbcf016  jmp 0x0000797DBBBCEF27
0000797dbbbcf01b  int3
0000797dbbbcf01c  nop [rax], eax
0000797dbbbcf020  mov rax, [r15+0xF8]
0000797dbbbcf027  lea r14, [rax+0x10]
0000797dbbbcf02b  mov r12, [r13+r14*1]
0000797dbbbcf030  lea r14, [rax+0x18]
0000797dbbbcf034  mov r11, [r13+r14*1]
0000797dbbbcf039  mov [r15+0xA0], r12
0000797dbbbcf040  mov [r15+0x98], r11
0000797dbbbcf047  mov r14, [r15+0x50]
0000797dbbbcf04b  mov r12, [r15+0x48]
0000797dbbbcf04f  lea r11, [r14+r12*1]
0000797dbbbcf053  mov [r15+0x48], r11
0000797dbbbcf057  mov r14, [r15+0x40]
0000797dbbbcf05b  lea r12, [r14+0x288]
0000797dbbbcf062  mov [r13+r12*1], r11
0000797dbbbcf067  mov r14, [r13+rax*1]
0000797dbbbcf06c  mov [r15+0xF0], r14
0000797dbbbcf073  lea r12, [rax+0x20]
0000797dbbbcf077  mov [r15+0xF8], r12
0000797dbbbcf07e  mov [r15+0x100], r14
0000797dbbbcf085  jmp 0x0000797DBBBCE5C0
0000797dbbbcf08a  int3
0000797dbbbcf08b  call 0x0000797DBBAE27E0
0000797dbbbcf090  jmp 0x0000797DBBBCF030
0000797dbbbcf095  call 0x0000797DBBAE1570
0000797dbbbcf09a  jmp 0x0000797DBBBCF039
0000797dbbbcf09f  call 0x0000797DBBAC0860
0000797dbbbcf0a4  jmp 0x0000797DBBBCF067
0000797dbbbcf0a9  call 0x0000797DBBA0DC20
0000797dbbbcf0ae  jmp 0x0000797DBBBCF06C
0000797dbbbcf0b3  int3
0000797dbbbcf0b4  nop [rax+rax*1], ax
0000797dbbbcf0bd  nop [rax], eax
0000797dbbbcf0c0  mov qword ptr [r15+0x100], 0x04
0000797dbbbcf0cb  mov esi, 0x00
0000797dbbbcf0d0  mov edx, 0x09
0000797dbbbcf0d5  mov rdi, 0x7FFF2A9DE730
0000797dbbbcf0df  mov rax, 0x575D84C9F970
0000797dbbbcf0e9  call rax
0000797dbbbcf0eb  cmp dword ptr [r15+0x318], 0x00
0000797dbbbcf0f3  jnz 0x0000797DBB9FE110
0000797dbbbcf0f9  jmp 0x0000797DBB9FE0A0
0000797dbbbcf0fe  int3
0000797dbbbcf0ff  int3
