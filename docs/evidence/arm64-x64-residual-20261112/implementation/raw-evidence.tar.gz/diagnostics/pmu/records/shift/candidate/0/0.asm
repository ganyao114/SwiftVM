
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/shift/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r13d,0x1b00
   a:	mov    r14d,0xb7
  10:	and    r14d,0xffff
  17:	mov    rax,r13
  1a:	movabs rcx,0xffffffff0000ffff
  24:	and    rax,rcx
  27:	mov    rdx,r14
  2a:	shl    rdx,0x10
  2e:	mov    ecx,0xffff0000
  33:	and    rdx,rcx
  36:	or     rax,rdx
  39:	mov    r15,rax
  3c:	mov    QWORD PTR [r12+0x8],r15
  41:	mov    r13d,0x420060
  47:	mov    QWORD PTR [r12+0x20],r13
  4c:	mov    r13d,0x0
  52:	mov    QWORD PTR [r12],r13
  56:	jmp    0x5b
  5b:	mov    r13,QWORD PTR [r12]
  5f:	ror    r13,0xd
  63:	mov    r14,r13
  66:	shr    r14,0x7
  6a:	xor    r13,r14
  6d:	add    r13,0x3
  71:	mov    QWORD PTR [r12],r13
  75:	mov    r13,QWORD PTR [r12+0x8]
  7a:	sub    r13,0x1
  7e:	mov    QWORD PTR [r12+0x8],r13
  83:	mov    rcx,QWORD PTR [r12+0x380]
  8b:	jrcxz  0x92
  8d:	jmp    0x10a
  92:	jne    0x5b
  98:	mov    r11,rax
  9b:	lahf
  9c:	seto   al
  9f:	mov    WORD PTR [rsp],ax
  a3:	mov    rax,r11
  a6:	jmp    0xab
  ab:	mov    r13,QWORD PTR [r12+0x20]
  b0:	mov    r14,QWORD PTR [r12]
  b4:	mov    QWORD PTR [r13+0x0],r14
  b8:	mov    r13d,0x0
  be:	mov    DWORD PTR [r12+0x32c],r13d
  c6:	mov    rcx,QWORD PTR [r12+0x380]
  ce:	jrcxz  0xd5
  d0:	jmp    0x19b
  d5:	mov    r13,QWORD PTR [r12+0xf0]
  dd:	mov    QWORD PTR [r12+0x100],r13
  e5:	mov    r11,QWORD PTR [rsp]
  e9:	mov    QWORD PTR [r12+0x398],r11
  f1:	mov    rdi,QWORD PTR [r12+0x100]
  f9:	add    rsp,0x10
  fd:	movabs r11,0x6546e2411940
 107:	jmp    r11
 10a:	mov    eax,0x41004c
 10f:	mov    QWORD PTR [r12+0x100],rax
 117:	push   rdx
 118:	push   rsi
 119:	push   r10
 11b:	push   r11
 11d:	mov    r11,rax
 120:	lahf
 121:	seto   al
 124:	mov    WORD PTR [rsp+0x20],ax
 129:	mov    rax,r11
 12c:	mov    rdx,QWORD PTR [rsp+0x20]
 131:	mov    r10d,edx
 134:	and    r10d,0xc000
 13b:	shl    r10d,0x10
 13f:	mov    r11d,edx
 142:	and    r11d,0x100
 149:	shl    r11d,0x15
 14d:	or     r10d,r11d
 150:	and    edx,0x1
 153:	shl    edx,0x1c
 156:	or     r10d,edx
 159:	btc    r10,0x1d
 15e:	mov    r11d,0xf0000000
 164:	and    r11,r10
 167:	movabs rsi,0xffffffff0fffffff
 171:	and    rbx,rsi
 174:	or     rbx,r11
 177:	pop    r11
 179:	pop    r10
 17b:	pop    rsi
 17c:	pop    rdx
 17d:	mov    QWORD PTR [r12+0x108],rbx
 185:	add    rsp,0x10
 189:	mov    eax,0xc
 18e:	movabs r11,0x6546e2411ca0
 198:	jmp    r11
 19b:	mov    eax,0x410054
 1a0:	mov    QWORD PTR [r12+0x100],rax
 1a8:	push   rdx
 1a9:	push   rsi
 1aa:	push   r10
 1ac:	push   r11
 1ae:	mov    rdx,QWORD PTR [rsp+0x20]
 1b3:	mov    r10d,edx
 1b6:	and    r10d,0xc000
 1bd:	shl    r10d,0x10
 1c1:	mov    r11d,edx
 1c4:	and    r11d,0x100
 1cb:	shl    r11d,0x15
 1cf:	or     r10d,r11d
 1d2:	and    edx,0x1
 1d5:	shl    edx,0x1c
 1d8:	or     r10d,edx
 1db:	btc    r10,0x1d
 1e0:	mov    r11d,0xf0000000
 1e6:	and    r11,r10
 1e9:	movabs rsi,0xffffffff0fffffff
 1f3:	and    rbx,rsi
 1f6:	or     rbx,r11
 1f9:	pop    r11
 1fb:	pop    r10
 1fd:	pop    rsi
 1fe:	pop    rdx
 1ff:	mov    QWORD PTR [r12+0x108],rbx
 207:	add    rsp,0x10
 20b:	mov    eax,0xc
 210:	movabs r11,0x6546e2411ca0
 21a:	jmp    r11
 21d:	nop    DWORD PTR [rax]
 220:	sub    rsp,0x10
 224:	jmp    0x5b
 229:	nop    DWORD PTR [rax+0x0]
 230:	sub    rsp,0x10
 234:	mov    r11,QWORD PTR [r12+0x398]
 23c:	mov    QWORD PTR [rsp],r11
 240:	jmp    0xab
 245:	nop
 246:	nop
 247:	nop
