0000701cb81ce69b  nop [rax+rax*1], eax
0000701cb81ce6a0  mov qword ptr [r15+0x20], 0x420060
0000701cb81ce6a8  xor eax, eax
0000701cb81ce6aa  xor r14d, r14d
0000701cb81ce6ad  shrd rax, r14, 0x0D
0000701cb81ce6b2  mov [rsp+0x10], rax
0000701cb81ce6b7  shr rax, 0x07
0000701cb81ce6bb  mov r14, [rsp+0x10]
0000701cb81ce6c0  xor r14, rax
0000701cb81ce6c3  lea rax, [r14+0x03]
0000701cb81ce6c7  mov [r15], rax
0000701cb81ce6ca  xor eax, eax
0000701cb81ce6cc  mov r14d, 0xB71B00
0000701cb81ce6d2  mov r12d, 0x01
0000701cb81ce6d8  sub r14, r12
0000701cb81ce6db  cmc
0000701cb81ce6dc  lahf
0000701cb81ce6dd  seto al
0000701cb81ce6e0  mov [r15+0x108], eax
0000701cb81ce6e7  mov [r15+0x08], r14
0000701cb81ce6eb  mov eax, [r15+0x108]
0000701cb81ce6f2  sahf
0000701cb81ce6f3  jnz 0x0000701CB81CE725
0000701cb81ce6f5  cmp dword ptr [r15+0x318], 0x00
0000701cb81ce6fd  jz 0x0000701CB81CE820
0000701cb81ce703  nop [rax+rax*1], ax
0000701cb81ce70c  nop [rax+rax*1], eax
0000701cb81ce714  mov eax, 0x410050
0000701cb81ce719  mov [r15+0x100], rax
0000701cb81ce720  jmp 0x0000701CB7FFE110
0000701cb81ce725  cmp dword ptr [r15+0x318], 0x00
0000701cb81ce72d  jz 0x0000701CB81CE760
0000701cb81ce733  nop [rax+rax*1], ax
0000701cb81ce73c  nop [rax+rax*1], eax
0000701cb81ce744  mov eax, 0x41003C
0000701cb81ce749  mov [r15+0x100], rax
0000701cb81ce750  jmp 0x0000701CB7FFE110
0000701cb81ce755  int3
0000701cb81ce756  int3
0000701cb81ce757  nop [rax+rax*1], ax
0000701cb81ce760  mov rax, [r15]
0000701cb81ce763  mov [rsp+0x10], rax
0000701cb81ce768  mov r14, [rsp+0x10]
0000701cb81ce76d  shrd rax, r14, 0x0D
0000701cb81ce772  mov [rsp+0x10], rax
0000701cb81ce777  shr rax, 0x07
0000701cb81ce77b  mov r14, [rsp+0x10]
0000701cb81ce780  xor r14, rax
0000701cb81ce783  lea rax, [r14+0x03]
0000701cb81ce787  mov [r15], rax
0000701cb81ce78a  mov rax, [r15+0x08]
0000701cb81ce78e  mov [rsp+0x10], rax
0000701cb81ce793  xor eax, eax
0000701cb81ce795  mov r14, [rsp+0x10]
0000701cb81ce79a  mov r12d, 0x01
0000701cb81ce7a0  sub r14, r12
0000701cb81ce7a3  cmc
0000701cb81ce7a4  lahf
0000701cb81ce7a5  seto al
0000701cb81ce7a8  mov [r15+0x108], eax
0000701cb81ce7af  mov [r15+0x08], r14
0000701cb81ce7b3  mov eax, [r15+0x108]
0000701cb81ce7ba  sahf
0000701cb81ce7bb  jnz 0x0000701CB81CE7ED
0000701cb81ce7bd  cmp dword ptr [r15+0x318], 0x00
0000701cb81ce7c5  jz 0x0000701CB81CE820
0000701cb81ce7cb  nop [rax+rax*1], ax
0000701cb81ce7d4  nop [rax+rax*1], eax
0000701cb81ce7dc  mov eax, 0x410050
0000701cb81ce7e1  mov [r15+0x100], rax
0000701cb81ce7e8  jmp 0x0000701CB7FFE110
0000701cb81ce7ed  cmp dword ptr [r15+0x318], 0x00
0000701cb81ce7f5  jz 0x0000701CB81CE760
0000701cb81ce7fb  nop [rax+rax*1], ax
0000701cb81ce804  nop [rax+rax*1], eax
0000701cb81ce80c  mov eax, 0x41003C
0000701cb81ce811  mov [r15+0x100], rax
0000701cb81ce818  jmp 0x0000701CB7FFE110
0000701cb81ce81d  int3
0000701cb81ce81e  int3
0000701cb81ce81f  nop
0000701cb81ce820  mov rax, [r15+0x20]
0000701cb81ce824  mov r14, [r15]
0000701cb81ce827  mov [r13+rax*1], r14
0000701cb81ce82c  mov rax, [r15+0xF0]
0000701cb81ce833  mov [r15+0x100], rax
0000701cb81ce83a  jmp 0x0000701CB81CE5C0
0000701cb81ce83f  int3
0000701cb81ce840  call 0x0000701CB800E120
0000701cb81ce845  jmp 0x0000701CB81CE82C
0000701cb81ce84a  int3
0000701cb81ce84b  nop [rax+rax*1], eax
0000701cb81ce850  mov qword ptr [r15+0x100], 0x04
0000701cb81ce85b  mov esi, 0x00
0000701cb81ce860  mov edx, 0x09
0000701cb81ce865  mov rdi, 0x7FFE8A063C20
0000701cb81ce86f  mov rax, 0x5FE72DE64970
0000701cb81ce879  call rax
0000701cb81ce87b  cmp dword ptr [r15+0x318], 0x00
0000701cb81ce883  jnz 0x0000701CB7FFE110
0000701cb81ce889  jmp 0x0000701CB7FFE0A0
0000701cb81ce88e  int3
0000701cb81ce88f  int3
