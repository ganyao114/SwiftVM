
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sort/candidate/0/1.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13d,0x352d
  16:	mov    QWORD PTR [r12+0x40],r13
  1b:	mov    r13d,0xa68b
  21:	mov    QWORD PTR [r12+0x48],r13
  26:	mov    r13d,0x352d
  2c:	mov    r14d,0x7feb
  32:	and    r14d,0xffff
  39:	mov    rax,r13
  3c:	movabs rcx,0xffffffff0000ffff
  46:	and    rax,rcx
  49:	mov    rdx,r14
  4c:	shl    rdx,0x10
  50:	mov    ecx,0xffff0000
  55:	and    rdx,rcx
  58:	or     rax,rdx
  5b:	mov    r15d,eax
  5e:	mov    QWORD PTR [r12+0x40],r15
  63:	mov    r13d,0xa68b
  69:	mov    r14d,0x846c
  6f:	and    r14d,0xffff
  76:	mov    rax,r13
  79:	movabs rcx,0xffffffff0000ffff
  83:	and    rax,rcx
  86:	mov    rdx,r14
  89:	shl    rdx,0x10
  8d:	mov    ecx,0xffff0000
  92:	and    rdx,rcx
  95:	or     rax,rdx
  98:	mov    ebp,eax
  9a:	mov    QWORD PTR [r12+0x48],rbp
  9f:	mov    r13d,DWORD PTR [r12]
  a3:	mov    r14d,0x0
  a9:	imul   r13d,r15d
  ad:	mov    r15d,r14d
  b0:	add    r15d,r13d
  b3:	mov    QWORD PTR [r12+0x40],r15
  b8:	mov    r13d,r15d
  bb:	mov    r13d,r13d
  be:	shr    r13d,0xf
  c2:	xor    r15d,r13d
  c5:	mov    QWORD PTR [r12+0x40],r15
  ca:	mov    r13d,0x0
  d0:	imul   r15d,ebp
  d4:	mov    r14d,r13d
  d7:	add    r14d,r15d
  da:	mov    QWORD PTR [r12+0x40],r14
  df:	mov    r13d,r14d
  e2:	mov    r13d,r13d
  e5:	shr    r13d,0x10
  e9:	xor    r14d,r13d
  ec:	mov    QWORD PTR [r12],r14
  f0:	mov    rcx,QWORD PTR [r12+0x380]
  f8:	jrcxz  0xff
  fa:	jmp    0x134
  ff:	mov    r13,QWORD PTR [r12+0xf0]
 107:	mov    QWORD PTR [r12+0x100],r13
 10f:	mov    r11,QWORD PTR [rsp]
 113:	mov    QWORD PTR [r12+0x398],r11
 11b:	mov    rdi,QWORD PTR [r12+0x100]
 123:	add    rsp,0x10
 127:	movabs r11,0x5c931c45a940
 131:	jmp    r11
 134:	mov    eax,0x41023c
 139:	mov    QWORD PTR [r12+0x100],rax
 141:	push   rdx
 142:	push   rsi
 143:	push   r10
 145:	push   r11
 147:	mov    rdx,QWORD PTR [rsp+0x20]
 14c:	mov    r10d,edx
 14f:	and    r10d,0xc000
 156:	shl    r10d,0x10
 15a:	mov    r11d,edx
 15d:	and    r11d,0x100
 164:	shl    r11d,0x15
 168:	or     r10d,r11d
 16b:	and    edx,0x1
 16e:	shl    edx,0x1c
 171:	or     r10d,edx
 174:	btc    r10,0x1d
 179:	mov    r11d,0xf0000000
 17f:	and    r11,r10
 182:	movabs rsi,0xffffffff0fffffff
 18c:	and    rbx,rsi
 18f:	or     rbx,r11
 192:	pop    r11
 194:	pop    r10
 196:	pop    rsi
 197:	pop    rdx
 198:	mov    QWORD PTR [r12+0x108],rbx
 1a0:	add    rsp,0x10
 1a4:	mov    eax,0xc
 1a9:	movabs r11,0x5c931c45aca0
 1b3:	jmp    r11
 1b6:	nop
 1b7:	nop
