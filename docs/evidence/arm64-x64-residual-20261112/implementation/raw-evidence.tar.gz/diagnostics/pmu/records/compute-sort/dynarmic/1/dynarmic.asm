0000771d8f7ce69b  nop [rax+rax*1], eax
0000771d8f7ce6a0  mov rax, [r15+0xF8]
0000771d8f7ce6a7  lea r14, [rax-0x20]
0000771d8f7ce6ab  mov r12, [r15+0xF0]
0000771d8f7ce6b2  mov [r13+r14*1], r12
0000771d8f7ce6b7  mov [r15+0xF8], r14
0000771d8f7ce6be  lea r14, [rax-0x10]
0000771d8f7ce6c2  mov r12, [r15+0xA0]
0000771d8f7ce6c9  mov r11, [r15+0x98]
0000771d8f7ce6d0  mov [r13+r14*1], r12
0000771d8f7ce6d5  lea r14, [rax-0x08]
0000771d8f7ce6d9  mov [r13+r14*1], r11
0000771d8f7ce6de  mov qword ptr [r15+0xA0], 0x00
0000771d8f7ce6e9  mov qword ptr [r15+0x98], 0x4202A0
0000771d8f7ce6f4  mov eax, [r15+0xA0]
0000771d8f7ce6fb  lea r14d, [eax+0x11]
0000771d8f7ce700  mov r14d, r14d
0000771d8f7ce703  mov [r15], r14
0000771d8f7ce706  mov qword ptr [r15+0xF0], 0x410184
0000771d8f7ce711  mov r14d, [r15+0x320]
0000771d8f7ce718  mov eax, 0x410184
0000771d8f7ce71d  mov rcx, 0x771D8F7CE800
0000771d8f7ce727  mov [r15+r14*8+0x328], rax
0000771d8f7ce72f  mov [r15+r14*8+0x368], rcx
0000771d8f7ce737  add r14d, 0x01
0000771d8f7ce73b  and r14d, 0x07
0000771d8f7ce73f  mov [r15+0x320], r14d
0000771d8f7ce746  cmp dword ptr [r15+0x318], 0x00
0000771d8f7ce74e  jz 0x0000771D8F7CE7A0
0000771d8f7ce754  nop [rax+rax*1], ax
0000771d8f7ce75d  nop [rax+rax*1], eax
0000771d8f7ce765  mov eax, 0x41021C
0000771d8f7ce76a  mov [r15+0x100], rax
0000771d8f7ce771  jmp 0x0000771D8F5FE110
0000771d8f7ce776  int3
0000771d8f7ce777  call 0x0000771D8F6E2CE0
0000771d8f7ce77c  jmp 0x0000771D8F7CE6B7
0000771d8f7ce781  call 0x0000771D8F6E2CE0
0000771d8f7ce786  jmp 0x0000771D8F7CE6D5
0000771d8f7ce78b  call 0x0000771D8F6E1A60
0000771d8f7ce790  jmp 0x0000771D8F7CE6DE
0000771d8f7ce795  int3
0000771d8f7ce796  nop [rax+rax*1], ax
0000771d8f7ce79f  nop
0000771d8f7ce7a0  mov eax, 0x846CA68B
0000771d8f7ce7a5  mov eax, eax
0000771d8f7ce7a7  mov [r15+0x48], rax
0000771d8f7ce7ab  mov eax, [r15]
0000771d8f7ce7ae  imul eax, eax, 0x7FEB352D
0000771d8f7ce7b4  mov [rsp+0x10], eax
0000771d8f7ce7b8  shr eax, 0x0F
0000771d8f7ce7bb  mov r14d, [rsp+0x10]
0000771d8f7ce7c0  xor r14d, eax
0000771d8f7ce7c3  imul r14d, r14d, 0x846CA68B
0000771d8f7ce7ca  mov [rsp+0x10], r14d
0000771d8f7ce7cf  mov r14d, r14d
0000771d8f7ce7d2  mov [r15+0x40], r14
0000771d8f7ce7d6  mov eax, [rsp+0x10]
0000771d8f7ce7da  shr eax, 0x10
0000771d8f7ce7dd  mov r14d, [rsp+0x10]
0000771d8f7ce7e2  xor r14d, eax
0000771d8f7ce7e5  mov r14d, r14d
0000771d8f7ce7e8  mov [r15], r14
0000771d8f7ce7eb  mov rax, [r15+0xF0]
0000771d8f7ce7f2  mov [r15+0x100], rax
0000771d8f7ce7f9  jmp 0x0000771D8F7CE5C0
0000771d8f7ce7fe  int3
0000771d8f7ce7ff  int3
0000771d8f7ce800  mov rax, [r15+0xA0]
0000771d8f7ce807  mov [rsp+0x10], rax
0000771d8f7ce80c  shl rax, 0x02
0000771d8f7ce810  mov r14, [r15+0x98]
0000771d8f7ce817  lea r12, [r14+rax*1]
0000771d8f7ce81b  mov eax, [r15]
0000771d8f7ce81e  mov [r13+r12*1], eax
0000771d8f7ce823  mov rax, [rsp+0x10]
0000771d8f7ce828  lea r14, [rax+0x01]
0000771d8f7ce82c  mov [r15+0xA0], r14
0000771d8f7ce833  xor eax, eax
0000771d8f7ce835  mov r12d, 0x400
0000771d8f7ce83b  cmp r14, r12
0000771d8f7ce83e  cmc
0000771d8f7ce83f  lahf
0000771d8f7ce840  seto al
0000771d8f7ce843  mov [r15+0x108], eax
0000771d8f7ce84a  mov eax, [r15+0x108]
0000771d8f7ce851  sahf
0000771d8f7ce852  jnz 0x0000771D8F7CE884
0000771d8f7ce854  cmp dword ptr [r15+0x318], 0x00
0000771d8f7ce85c  jz 0x0000771D8F7CE950
0000771d8f7ce862  nop [rax+rax*1], ax
0000771d8f7ce86b  nop [rax+rax*1], eax
0000771d8f7ce873  mov eax, 0x410194
0000771d8f7ce878  mov [r15+0x100], rax
0000771d8f7ce87f  jmp 0x0000771D8F5FE110
0000771d8f7ce884  cmp dword ptr [r15+0x318], 0x00
0000771d8f7ce88c  jz 0x0000771D8F7CE8C0
0000771d8f7ce892  nop [rax+rax*1], ax
0000771d8f7ce89b  nop [rax+rax*1], eax
0000771d8f7ce8a3  mov eax, 0x41017C
0000771d8f7ce8a8  mov [r15+0x100], rax
0000771d8f7ce8af  jmp 0x0000771D8F5FE110
0000771d8f7ce8b4  int3
0000771d8f7ce8b5  call 0x0000771D8F6B4B70
0000771d8f7ce8ba  jmp 0x0000771D8F7CE823
0000771d8f7ce8bf  int3
0000771d8f7ce8c0  mov eax, [r15+0xA0]
0000771d8f7ce8c7  lea r14d, [eax+0x11]
0000771d8f7ce8cc  mov r14d, r14d
0000771d8f7ce8cf  mov [r15], r14
0000771d8f7ce8d2  mov qword ptr [r15+0xF0], 0x410184
0000771d8f7ce8dd  mov r14d, [r15+0x320]
0000771d8f7ce8e4  mov eax, 0x410184
0000771d8f7ce8e9  mov rcx, 0x771D8F7CE800
0000771d8f7ce8f3  mov [r15+r14*8+0x328], rax
0000771d8f7ce8fb  mov [r15+r14*8+0x368], rcx
0000771d8f7ce903  add r14d, 0x01
0000771d8f7ce907  and r14d, 0x07
0000771d8f7ce90b  mov [r15+0x320], r14d
0000771d8f7ce912  cmp dword ptr [r15+0x318], 0x00
0000771d8f7ce91a  jz 0x0000771D8F7CE7A0
0000771d8f7ce920  nop [rax+rax*1], ax
0000771d8f7ce929  nop [rax+rax*1], eax
0000771d8f7ce931  mov eax, 0x41021C
0000771d8f7ce936  mov [r15+0x100], rax
0000771d8f7ce93d  jmp 0x0000771D8F5FE110
0000771d8f7ce942  int3
0000771d8f7ce943  int3
0000771d8f7ce944  nop [rax+rax*1], ax
0000771d8f7ce94d  nop [rax], eax
0000771d8f7ce950  mov qword ptr [r15+0x40], 0x01
0000771d8f7ce958  cmp dword ptr [r15+0x318], 0x00
0000771d8f7ce960  jz 0x0000771D8F7CE990
0000771d8f7ce966  nop [rax+rax*1], ax
0000771d8f7ce96f  nop [rax+rax*1], eax
0000771d8f7ce977  mov eax, 0x4101B0
0000771d8f7ce97c  mov [r15+0x100], rax
0000771d8f7ce983  jmp 0x0000771D8F5FE110
0000771d8f7ce988  int3
0000771d8f7ce989  int3
0000771d8f7ce98a  nop [rax+rax*1], ax
0000771d8f7ce990  mov rax, [r15+0x40]
0000771d8f7ce994  mov [rsp+0x10], rax
0000771d8f7ce999  shl rax, 0x02
0000771d8f7ce99d  mov r14, [r15+0x98]
0000771d8f7ce9a4  lea r12, [r14+rax*1]
0000771d8f7ce9a8  mov eax, [r13+r12*1]
0000771d8f7ce9ad  mov [rsp+0x20], eax
0000771d8f7ce9b1  mov eax, eax
0000771d8f7ce9b3  mov [r15+0x48], rax
0000771d8f7ce9b7  mov rax, [rsp+0x10]
0000771d8f7ce9bc  mov [r15+0x50], rax
0000771d8f7ce9c0  mov eax, [r15+0x50]
0000771d8f7ce9c4  lea r12d, [eax-0x01]
0000771d8f7ce9c9  mov r12d, r12d
0000771d8f7ce9cc  mov [r15+0x58], r12
0000771d8f7ce9d0  mov rax, [r15+0x58]
0000771d8f7ce9d4  mov r12d, eax
0000771d8f7ce9d7  mov r12d, r12d
0000771d8f7ce9da  shl r12, 0x02
0000771d8f7ce9de  lea rax, [r14+r12*1]
0000771d8f7ce9e2  mov r14d, [r13+rax*1]
0000771d8f7ce9e7  mov [rsp+0x10], r14d
0000771d8f7ce9ec  mov r14d, r14d
0000771d8f7ce9ef  mov [r15+0x60], r14
0000771d8f7ce9f3  xor eax, eax
0000771d8f7ce9f5  mov r14d, [rsp+0x10]
0000771d8f7ce9fa  mov r12d, [rsp+0x20]
0000771d8f7ce9ff  cmp r14d, r12d
0000771d8f7cea02  cmc
0000771d8f7cea03  lahf
0000771d8f7cea04  seto al
0000771d8f7cea07  mov [r15+0x108], eax
0000771d8f7cea0e  mov eax, [r15+0x108]
0000771d8f7cea15  sahf
0000771d8f7cea16  cmc
0000771d8f7cea17  jbe 0x0000771D8F7CEA49
0000771d8f7cea19  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cea21  jz 0x0000771D8F7CEA90
0000771d8f7cea27  nop [rax+rax*1], ax
0000771d8f7cea30  nop [rax+rax*1], eax
0000771d8f7cea38  mov eax, 0x4101C8
0000771d8f7cea3d  mov [r15+0x100], rax
0000771d8f7cea44  jmp 0x0000771D8F5FE110
0000771d8f7cea49  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cea51  jz 0x0000771D8F7CED30
0000771d8f7cea57  nop [rax+rax*1], ax
0000771d8f7cea60  nop [rax+rax*1], eax
0000771d8f7cea68  mov eax, 0x4101A0
0000771d8f7cea6d  mov [r15+0x100], rax
0000771d8f7cea74  jmp 0x0000771D8F5FE110
0000771d8f7cea79  int3
0000771d8f7cea7a  call 0x0000771D8F6B4690
0000771d8f7cea7f  jmp 0x0000771D8F7CE9AD
0000771d8f7cea84  call 0x0000771D8F60DAE0
0000771d8f7cea89  jmp 0x0000771D8F7CE9E7
0000771d8f7cea8e  int3
0000771d8f7cea8f  nop
0000771d8f7cea90  mov rax, [r15+0x50]
0000771d8f7cea94  mov [rsp+0x10], rax
0000771d8f7cea99  shl rax, 0x02
0000771d8f7cea9d  mov r14, [r15+0x98]
0000771d8f7ceaa4  lea r12, [r14+rax*1]
0000771d8f7ceaa8  mov eax, [r15+0x60]
0000771d8f7ceaac  mov [r13+r12*1], eax
0000771d8f7ceab1  mov rax, [rsp+0x10]
0000771d8f7ceab6  lea r14, [rax-0x01]
0000771d8f7ceaba  mov [r15+0x50], r14
0000771d8f7ceabe  mov rax, [r15+0x58]
0000771d8f7ceac2  test rax, rax
0000771d8f7ceac5  setz al
0000771d8f7ceac8  movzx rax, al
0000771d8f7ceacc  mov [rsp+0x414], al
0000771d8f7cead3  cmp byte ptr [rsp+0x414], 0x00
0000771d8f7ceadb  jz 0x0000771D8F7CEB0D
0000771d8f7ceadd  cmp dword ptr [r15+0x318], 0x00
0000771d8f7ceae5  jz 0x0000771D8F7CEB50
0000771d8f7ceaeb  nop [rax+rax*1], ax
0000771d8f7ceaf4  nop [rax+rax*1], eax
0000771d8f7ceafc  mov eax, 0x4101D4
0000771d8f7ceb01  mov [r15+0x100], rax
0000771d8f7ceb08  jmp 0x0000771D8F5FE110
0000771d8f7ceb0d  cmp dword ptr [r15+0x318], 0x00
0000771d8f7ceb15  jz 0x0000771D8F7CEC50
0000771d8f7ceb1b  nop [rax+rax*1], ax
0000771d8f7ceb24  nop [rax+rax*1], eax
0000771d8f7ceb2c  mov eax, 0x4101B8
0000771d8f7ceb31  mov [r15+0x100], rax
0000771d8f7ceb38  jmp 0x0000771D8F5FE110
0000771d8f7ceb3d  int3
0000771d8f7ceb3e  call 0x0000771D8F6B4B70
0000771d8f7ceb43  jmp 0x0000771D8F7CEAB1
0000771d8f7ceb48  int3
0000771d8f7ceb49  nop [rax], eax
0000771d8f7ceb50  cmp dword ptr [r15+0x318], 0x00
0000771d8f7ceb58  jz 0x0000771D8F7CEB90
0000771d8f7ceb5e  nop [rax+rax*1], ax
0000771d8f7ceb67  nop [rax+rax*1], eax
0000771d8f7ceb6f  mov eax, 0x41019C
0000771d8f7ceb74  mov [r15+0x100], rax
0000771d8f7ceb7b  jmp 0x0000771D8F5FE110
0000771d8f7ceb80  int3
0000771d8f7ceb81  int3
0000771d8f7ceb82  nop [rax+rax*1], ax
0000771d8f7ceb8b  nop [rax+rax*1], eax
0000771d8f7ceb90  mov qword ptr [r15+0x50], 0x00
0000771d8f7ceb98  mov rax, [r15+0x40]
0000771d8f7ceb9c  lea r14, [rax+0x01]
0000771d8f7ceba0  mov [r15+0x40], r14
0000771d8f7ceba4  mov rax, [r15+0x98]
0000771d8f7cebab  mov r12d, [r15+0x48]
0000771d8f7cebaf  mov [r13+rax*1], r12d
0000771d8f7cebb4  xor eax, eax
0000771d8f7cebb6  mov r12d, 0x400
0000771d8f7cebbc  cmp r14, r12
0000771d8f7cebbf  cmc
0000771d8f7cebc0  lahf
0000771d8f7cebc1  seto al
0000771d8f7cebc4  mov [r15+0x108], eax
0000771d8f7cebcb  mov eax, [r15+0x108]
0000771d8f7cebd2  sahf
0000771d8f7cebd3  jz 0x0000771D8F7CEC05
0000771d8f7cebd5  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cebdd  jz 0x0000771D8F7CE990
0000771d8f7cebe3  nop [rax+rax*1], ax
0000771d8f7cebec  nop [rax+rax*1], eax
0000771d8f7cebf4  mov eax, 0x4101B0
0000771d8f7cebf9  mov [r15+0x100], rax
0000771d8f7cec00  jmp 0x0000771D8F5FE110
0000771d8f7cec05  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cec0d  jz 0x0000771D8F7CEDF0
0000771d8f7cec13  nop [rax+rax*1], ax
0000771d8f7cec1c  nop [rax+rax*1], eax
0000771d8f7cec24  mov eax, 0x4101D8
0000771d8f7cec29  mov [r15+0x100], rax
0000771d8f7cec30  jmp 0x0000771D8F5FE110
0000771d8f7cec35  int3
0000771d8f7cec36  call 0x0000771D8F60BAE0
0000771d8f7cec3b  jmp 0x0000771D8F7CEBB4
0000771d8f7cec40  int3
0000771d8f7cec41  nop [rax+rax*1], ax
0000771d8f7cec4a  nop [rax+rax*1], ax
0000771d8f7cec50  mov eax, [r15+0x50]
0000771d8f7cec54  lea r14d, [eax-0x01]
0000771d8f7cec59  mov r14d, r14d
0000771d8f7cec5c  mov [r15+0x58], r14
0000771d8f7cec60  mov rax, [r15+0x58]
0000771d8f7cec64  mov r14d, eax
0000771d8f7cec67  mov r14d, r14d
0000771d8f7cec6a  shl r14, 0x02
0000771d8f7cec6e  mov rax, [r15+0x98]
0000771d8f7cec75  lea r12, [rax+r14*1]
0000771d8f7cec79  mov eax, [r13+r12*1]
0000771d8f7cec7e  mov [rsp+0x10], eax
0000771d8f7cec82  mov eax, eax
0000771d8f7cec84  mov [r15+0x60], rax
0000771d8f7cec88  mov eax, [r15+0x48]
0000771d8f7cec8c  mov [rsp+0x20], eax
0000771d8f7cec90  xor eax, eax
0000771d8f7cec92  mov r14d, [rsp+0x10]
0000771d8f7cec97  mov r12d, [rsp+0x20]
0000771d8f7cec9c  cmp r14d, r12d
0000771d8f7cec9f  cmc
0000771d8f7ceca0  lahf
0000771d8f7ceca1  seto al
0000771d8f7ceca4  mov [r15+0x108], eax
0000771d8f7cecab  mov eax, [r15+0x108]
0000771d8f7cecb2  sahf
0000771d8f7cecb3  cmc
0000771d8f7cecb4  jbe 0x0000771D8F7CECE6
0000771d8f7cecb6  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cecbe  jz 0x0000771D8F7CEA90
0000771d8f7cecc4  nop [rax+rax*1], ax
0000771d8f7ceccd  nop [rax+rax*1], eax
0000771d8f7cecd5  mov eax, 0x4101C8
0000771d8f7cecda  mov [r15+0x100], rax
0000771d8f7cece1  jmp 0x0000771D8F5FE110
0000771d8f7cece6  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cecee  jz 0x0000771D8F7CED30
0000771d8f7cecf4  nop [rax+rax*1], ax
0000771d8f7cecfd  nop [rax+rax*1], eax
0000771d8f7ced05  mov eax, 0x4101A0
0000771d8f7ced0a  mov [r15+0x100], rax
0000771d8f7ced11  jmp 0x0000771D8F5FE110
0000771d8f7ced16  int3
0000771d8f7ced17  call 0x0000771D8F6B4690
0000771d8f7ced1c  jmp 0x0000771D8F7CEC7E
0000771d8f7ced21  int3
0000771d8f7ced22  nop [rax+rax*1], ax
0000771d8f7ced2b  nop [rax+rax*1], eax
0000771d8f7ced30  mov rax, [r15+0x40]
0000771d8f7ced34  lea r14, [rax+0x01]
0000771d8f7ced38  mov [r15+0x40], r14
0000771d8f7ced3c  mov rax, [r15+0x50]
0000771d8f7ced40  mov r12d, eax
0000771d8f7ced43  mov r12d, r12d
0000771d8f7ced46  shl r12, 0x02
0000771d8f7ced4a  mov rax, [r15+0x98]
0000771d8f7ced51  lea r11, [rax+r12*1]
0000771d8f7ced55  mov eax, [r15+0x48]
0000771d8f7ced59  mov [r13+r11*1], eax
0000771d8f7ced5e  xor eax, eax
0000771d8f7ced60  mov r12d, 0x400
0000771d8f7ced66  cmp r14, r12
0000771d8f7ced69  cmc
0000771d8f7ced6a  lahf
0000771d8f7ced6b  seto al
0000771d8f7ced6e  mov [r15+0x108], eax
0000771d8f7ced75  mov eax, [r15+0x108]
0000771d8f7ced7c  sahf
0000771d8f7ced7d  jz 0x0000771D8F7CEDAF
0000771d8f7ced7f  cmp dword ptr [r15+0x318], 0x00
0000771d8f7ced87  jz 0x0000771D8F7CE990
0000771d8f7ced8d  nop [rax+rax*1], ax
0000771d8f7ced96  nop [rax+rax*1], eax
0000771d8f7ced9e  mov eax, 0x4101B0
0000771d8f7ceda3  mov [r15+0x100], rax
0000771d8f7cedaa  jmp 0x0000771D8F5FE110
0000771d8f7cedaf  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cedb7  jz 0x0000771D8F7CEDF0
0000771d8f7cedbd  nop [rax+rax*1], ax
0000771d8f7cedc6  nop [rax+rax*1], eax
0000771d8f7cedce  mov eax, 0x4101D8
0000771d8f7cedd3  mov [r15+0x100], rax
0000771d8f7cedda  jmp 0x0000771D8F5FE110
0000771d8f7ceddf  int3
0000771d8f7cede0  call 0x0000771D8F6A4270
0000771d8f7cede5  jmp 0x0000771D8F7CED5E
0000771d8f7cedea  int3
0000771d8f7cedeb  nop [rax+rax*1], eax
0000771d8f7cedf0  mov qword ptr [r15+0x40], 0x420000
0000771d8f7cedf8  mov eax, 0x420288
0000771d8f7cedfd  mov r14, [r13+rax*1]
0000771d8f7cee02  mov rax, [r15+0x98]
0000771d8f7cee09  mov r12d, [r13+rax*1]
0000771d8f7cee0e  lea r11, [rax+0x04]
0000771d8f7cee12  mov eax, [r13+r11*1]
0000771d8f7cee17  mov r12d, r12d
0000771d8f7cee1a  mov [r15+0x68], r12
0000771d8f7cee1e  mov eax, eax
0000771d8f7cee20  mov [r15+0x60], rax
0000771d8f7cee24  mov rax, [r15+0x68]
0000771d8f7cee28  mov [r15+0x68], rax
0000771d8f7cee2c  mov qword ptr [r15+0x58], 0x02
0000771d8f7cee34  mov [rsp+0x10], rax
0000771d8f7cee39  xor eax, eax
0000771d8f7cee3b  mov r12d, 0x02
0000771d8f7cee41  mov r11d, 0x400
0000771d8f7cee47  cmp r12, r11
0000771d8f7cee4a  cmc
0000771d8f7cee4b  lahf
0000771d8f7cee4c  seto al
0000771d8f7cee4f  mov [r15+0x108], eax
0000771d8f7cee56  mov rax, [r15+0x60]
0000771d8f7cee5a  mov r12d, 0x02
0000771d8f7cee60  imul rax, r12
0000771d8f7cee64  mov [r15+0x50], rax
0000771d8f7cee68  mov rax, [rsp+0x10]
0000771d8f7cee6d  lea r12, [rax+r14*1]
0000771d8f7cee71  mov [r15+0x48], r12
0000771d8f7cee75  mov eax, [r15+0x108]
0000771d8f7cee7c  sahf
0000771d8f7cee7d  jnz 0x0000771D8F7CEEAF
0000771d8f7cee7f  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cee87  jz 0x0000771D8F7CF020
0000771d8f7cee8d  nop [rax+rax*1], ax
0000771d8f7cee96  nop [rax+rax*1], eax
0000771d8f7cee9e  mov eax, 0x410208
0000771d8f7ceea3  mov [r15+0x100], rax
0000771d8f7ceeaa  jmp 0x0000771D8F5FE110
0000771d8f7ceeaf  cmp dword ptr [r15+0x318], 0x00
0000771d8f7ceeb7  jz 0x0000771D8F7CEF00
0000771d8f7ceebd  nop [rax+rax*1], ax
0000771d8f7ceec6  nop [rax+rax*1], eax
0000771d8f7ceece  mov eax, 0x4101E8
0000771d8f7ceed3  mov [r15+0x100], rax
0000771d8f7ceeda  jmp 0x0000771D8F5FE110
0000771d8f7ceedf  int3
0000771d8f7ceee0  call 0x0000771D8F60DC20
0000771d8f7ceee5  jmp 0x0000771D8F7CEE02
0000771d8f7ceeea  call 0x0000771D8F60B5E0
0000771d8f7ceeef  jmp 0x0000771D8F7CEE0E
0000771d8f7ceef4  call 0x0000771D8F6A3D90
0000771d8f7ceef9  jmp 0x0000771D8F7CEE17
0000771d8f7ceefe  int3
0000771d8f7ceeff  nop
0000771d8f7cef00  mov rax, [r15+0x98]
0000771d8f7cef07  mov r14, [r15+0x58]
0000771d8f7cef0b  mov [rsp+0x10], r14
0000771d8f7cef10  shl r14, 0x02
0000771d8f7cef14  lea r12, [rax+r14*1]
0000771d8f7cef18  mov eax, [r13+r12*1]
0000771d8f7cef1d  lea r14, [r12+0x04]
0000771d8f7cef22  mov r12d, [r13+r14*1]
0000771d8f7cef27  mov eax, eax
0000771d8f7cef29  mov [r15+0x68], rax
0000771d8f7cef2d  mov r12d, r12d
0000771d8f7cef30  mov [r15+0x60], r12
0000771d8f7cef34  mov rax, [r15+0x68]
0000771d8f7cef38  mov [rsp+0x20], rax
0000771d8f7cef3d  mov r14, [rsp+0x10]
0000771d8f7cef42  imul rax, r14
0000771d8f7cef46  mov r12, [rsp+0x20]
0000771d8f7cef4b  lea r11, [r12+rax*1]
0000771d8f7cef4f  mov [r15+0x68], r11
0000771d8f7cef53  lea rax, [r14+0x02]
0000771d8f7cef57  mov [r15+0x58], rax
0000771d8f7cef5b  mov [rsp+0x10], rax
0000771d8f7cef60  xor eax, eax
0000771d8f7cef62  mov r14, [rsp+0x10]
0000771d8f7cef67  mov r12d, 0x400
0000771d8f7cef6d  cmp r14, r12
0000771d8f7cef70  cmc
0000771d8f7cef71  lahf
0000771d8f7cef72  seto al
0000771d8f7cef75  mov [r15+0x108], eax
0000771d8f7cef7c  mov rax, [r15+0x50]
0000771d8f7cef80  mov r12, [r15+0x60]
0000771d8f7cef84  imul r14, r12
0000771d8f7cef88  lea r12, [rax+r14*1]
0000771d8f7cef8c  mov [r15+0x50], r12
0000771d8f7cef90  mov rax, [r15+0x48]
0000771d8f7cef94  lea r14, [r11+rax*1]
0000771d8f7cef98  mov [r15+0x48], r14
0000771d8f7cef9c  mov eax, [r15+0x108]
0000771d8f7cefa3  sahf
0000771d8f7cefa4  jnz 0x0000771D8F7CEFD6
0000771d8f7cefa6  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cefae  jz 0x0000771D8F7CF020
0000771d8f7cefb4  nop [rax+rax*1], ax
0000771d8f7cefbd  nop [rax+rax*1], eax
0000771d8f7cefc5  mov eax, 0x410208
0000771d8f7cefca  mov [r15+0x100], rax
0000771d8f7cefd1  jmp 0x0000771D8F5FE110
0000771d8f7cefd6  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cefde  jz 0x0000771D8F7CEF00
0000771d8f7cefe4  nop [rax+rax*1], ax
0000771d8f7cefed  nop [rax+rax*1], eax
0000771d8f7ceff5  mov eax, 0x4101E8
0000771d8f7ceffa  mov [r15+0x100], rax
0000771d8f7cf001  jmp 0x0000771D8F5FE110
0000771d8f7cf006  int3
0000771d8f7cf007  call 0x0000771D8F6B4690
0000771d8f7cf00c  jmp 0x0000771D8F7CEF1D
0000771d8f7cf011  call 0x0000771D8F6E26A0
0000771d8f7cf016  jmp 0x0000771D8F7CEF27
0000771d8f7cf01b  int3
0000771d8f7cf01c  nop [rax], eax
0000771d8f7cf020  mov rax, [r15+0xF8]
0000771d8f7cf027  lea r14, [rax+0x10]
0000771d8f7cf02b  mov r12, [r13+r14*1]
0000771d8f7cf030  lea r14, [rax+0x18]
0000771d8f7cf034  mov r11, [r13+r14*1]
0000771d8f7cf039  mov [r15+0xA0], r12
0000771d8f7cf040  mov [r15+0x98], r11
0000771d8f7cf047  mov r14, [r15+0x50]
0000771d8f7cf04b  mov r12, [r15+0x48]
0000771d8f7cf04f  lea r11, [r14+r12*1]
0000771d8f7cf053  mov [r15+0x48], r11
0000771d8f7cf057  mov r14, [r15+0x40]
0000771d8f7cf05b  lea r12, [r14+0x288]
0000771d8f7cf062  mov [r13+r12*1], r11
0000771d8f7cf067  mov r14, [r13+rax*1]
0000771d8f7cf06c  mov [r15+0xF0], r14
0000771d8f7cf073  lea r12, [rax+0x20]
0000771d8f7cf077  mov [r15+0xF8], r12
0000771d8f7cf07e  mov [r15+0x100], r14
0000771d8f7cf085  jmp 0x0000771D8F7CE5C0
0000771d8f7cf08a  int3
0000771d8f7cf08b  call 0x0000771D8F6E27E0
0000771d8f7cf090  jmp 0x0000771D8F7CF030
0000771d8f7cf095  call 0x0000771D8F6E1570
0000771d8f7cf09a  jmp 0x0000771D8F7CF039
0000771d8f7cf09f  call 0x0000771D8F6C0860
0000771d8f7cf0a4  jmp 0x0000771D8F7CF067
0000771d8f7cf0a9  call 0x0000771D8F60DC20
0000771d8f7cf0ae  jmp 0x0000771D8F7CF06C
0000771d8f7cf0b3  int3
0000771d8f7cf0b4  nop [rax+rax*1], ax
0000771d8f7cf0bd  nop [rax], eax
0000771d8f7cf0c0  mov qword ptr [r15+0x100], 0x04
0000771d8f7cf0cb  mov esi, 0x00
0000771d8f7cf0d0  mov edx, 0x09
0000771d8f7cf0d5  mov rdi, 0x7FFCE3EA7E90
0000771d8f7cf0df  mov rax, 0x64CC09499970
0000771d8f7cf0e9  call rax
0000771d8f7cf0eb  cmp dword ptr [r15+0x318], 0x00
0000771d8f7cf0f3  jnz 0x0000771D8F5FE110
0000771d8f7cf0f9  jmp 0x0000771D8F5FE0A0
0000771d8f7cf0fe  int3
0000771d8f7cf0ff  int3
