
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sha/candidate/0/3.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	mov    r14,r13
  1b:	add    r14,0x68
  1f:	mov    r15,QWORD PTR [r14]
  22:	mov    QWORD PTR [r12+0x40],r15
  27:	add    r13,0x88
  2e:	mov    r14d,0x0
  34:	mov    BYTE PTR [r13+0x0],r14b
  38:	mov    r13d,0x0
  3e:	mov    DWORD PTR [r12+0x32c],r13d
  46:	sub    r15,0x38
  4a:	je     0x63
  50:	mov    r11,rax
  53:	lahf
  54:	seto   al
  57:	mov    WORD PTR [rsp],ax
  5b:	mov    rax,r11
  5e:	jmp    0x76
  63:	mov    r11,rax
  66:	lahf
  67:	seto   al
  6a:	mov    WORD PTR [rsp],ax
  6e:	mov    rax,r11
  71:	jmp    0xfd
  76:	mov    r13,QWORD PTR [r12+0xf8]
  7e:	mov    QWORD PTR [r12],r13
  82:	add    r13,0x88
  89:	mov    QWORD PTR [r12+0x8],r13
  8e:	mov    r13d,0x1
  94:	mov    QWORD PTR [r12+0x10],r13
  99:	mov    r13d,0x4102b8
  9f:	mov    QWORD PTR [r12+0xf0],r13
  a7:	mov    r13d,0x410338
  ad:	mov    QWORD PTR [r12+0x100],r13
  b5:	mov    r11,QWORD PTR [rsp]
  b9:	mov    QWORD PTR [r12+0x398],r11
  c1:	mov    edi,0x410338
  c6:	mov    QWORD PTR [r12+0x100],rdi
  ce:	add    rsp,0x10
  d2:	nop    WORD PTR [rax+rax*1+0x0]
  d8:	jmp    QWORD PTR [rip+0x2]        # 0xe0
  de:	xchg   ax,ax
  e0:	shl    ah,0xef
  e3:	sbb    eax,0x7da1
  e8:	ror    BYTE PTR [rip+0x7da11df0],1        # 0x7da11ede
  ee:	add    BYTE PTR [rax],al
  f0:	movabs r11,0x580415130940
  fa:	jmp    r11
  fd:	mov    r13,QWORD PTR [r12+0x98]
 105:	ror    r13,0x3d
 109:	and    r13,0xfffffffffffffff8
 10d:	mov    r14,QWORD PTR [r12+0xf8]
 115:	mov    QWORD PTR [r12],r14
 119:	mov    r15,r14
 11c:	add    r15,0x78
 120:	mov    QWORD PTR [r12+0x8],r15
 125:	mov    r15d,0x8
 12b:	mov    QWORD PTR [r12+0x10],r15
 130:	movabs rcx,0xff00ff00ff00ff
 13a:	mov    r15,r13
 13d:	and    r15,rcx
 140:	shl    r15,0x8
 144:	movabs rcx,0xff00ff00ff00ff00
 14e:	and    r13,rcx
 151:	shr    r13,0x8
 155:	or     r13,r15
 158:	movabs rcx,0xffff0000ffff
 162:	mov    r15,r13
 165:	and    r15,rcx
 168:	shl    r15,0x10
 16c:	movabs rcx,0xffff0000ffff0000
 176:	and    r13,rcx
 179:	shr    r13,0x10
 17d:	or     r13,r15
 180:	mov    r15,r13
 183:	shl    r15,0x20
 187:	shr    r13,0x20
 18b:	or     r13,r15
 18e:	mov    QWORD PTR [r12+0x40],r13
 193:	add    r14,0x78
 197:	mov    QWORD PTR [r14],r13
 19a:	mov    r13d,0x0
 1a0:	mov    DWORD PTR [r12+0x32c],r13d
 1a8:	mov    r13d,0x4102e0
 1ae:	mov    QWORD PTR [r12+0xf0],r13
 1b6:	mov    r13d,0x410338
 1bc:	mov    QWORD PTR [r12+0x100],r13
 1c4:	mov    r11,QWORD PTR [rsp]
 1c8:	mov    QWORD PTR [r12+0x398],r11
 1d0:	mov    edi,0x410338
 1d5:	mov    QWORD PTR [r12+0x100],rdi
 1dd:	add    rsp,0x10
 1e1:	nop    DWORD PTR [rax+0x0]
 1e8:	jmp    QWORD PTR [rip+0x2]        # 0x1f0
 1ee:	xchg   ax,ax
 1f0:	shl    ah,0xef
 1f3:	sbb    eax,0x7da1
 1f8:	loopne 0x208
 1fa:	lock sbb eax,0x7da1
 200:	movabs r11,0x580415130940
 20a:	jmp    r11
 20d:	nop    DWORD PTR [rax]
 210:	sub    rsp,0x10
 214:	mov    r11,QWORD PTR [r12+0x398]
 21c:	mov    QWORD PTR [rsp],r11
 220:	jmp    0x76
 225:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 230:	sub    rsp,0x10
 234:	mov    r11,QWORD PTR [r12+0x398]
 23c:	mov    QWORD PTR [rsp],r11
 240:	jmp    0xfd
 245:	nop
 246:	nop
 247:	nop
