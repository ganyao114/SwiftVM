
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/candidate/0/8.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x150
       7:	mov    r11,QWORD PTR [r12+0x398]
       f:	mov    QWORD PTR [rsp],r11
      13:	cmp    DWORD PTR [r12+0x310],0x0
      1c:	je     0xa7
      22:	push   rdx
      23:	push   rsi
      24:	push   r10
      26:	push   r11
      28:	mov    rdx,QWORD PTR [rsp+0x20]
      2d:	mov    r10d,edx
      30:	and    r10d,0xc000
      37:	shl    r10d,0x10
      3b:	mov    r11d,edx
      3e:	and    r11d,0x100
      45:	shl    r11d,0x15
      49:	or     r10d,r11d
      4c:	and    edx,0x1
      4f:	shl    edx,0x1c
      52:	or     r10d,edx
      55:	btc    r10,0x1d
      5a:	mov    r11d,0xf0000000
      60:	and    r11,r10
      63:	movabs rsi,0xffffffff0fffffff
      6d:	and    rbx,rsi
      70:	or     rbx,r11
      73:	pop    r11
      75:	pop    r10
      77:	pop    rsi
      78:	pop    rdx
      79:	mov    QWORD PTR [r12+0x108],rbx
      81:	mov    eax,0x4103f8
      86:	mov    QWORD PTR [r12+0x100],rax
      8e:	add    rsp,0x150
      95:	mov    eax,0x3
      9a:	movabs r11,0x590d8528fca0
      a4:	jmp    r11
      a7:	mov    r13d,DWORD PTR [r12+0x98]
      af:	add    r13d,0x1
      b3:	mov    QWORD PTR [r12+0x98],r13
      bb:	sub    r13d,0x10000
      c2:	mov    rcx,QWORD PTR [r12+0x380]
      ca:	jrcxz  0xd1
      cc:	jmp    0x9a85
      d1:	jne    0xea
      d7:	mov    r11,rax
      da:	lahf
      db:	seto   al
      de:	mov    WORD PTR [rsp],ax
      e2:	mov    rax,r11
      e5:	jmp    0xfd
      ea:	mov    r11,rax
      ed:	lahf
      ee:	seto   al
      f1:	mov    WORD PTR [rsp],ax
      f5:	mov    rax,r11
      f8:	jmp    0x2bd3
      fd:	mov    r13d,0x420000
     103:	mov    QWORD PTR [r12+0x40],r13
     108:	movabs r13,0x100000001
     112:	mov    r14d,0x0
     118:	mov    QWORD PTR [r12+0x110],r13
     120:	mov    QWORD PTR [r12+0x118],r14
     128:	movabs r13,0x3fa0000000000000
     132:	mov    QWORD PTR [r12+0x50],r13
     137:	mov    r13d,0x420b10
     13d:	mov    r14,QWORD PTR [r13+0x0]
     141:	mov    r13d,0x0
     147:	mov    QWORD PTR [r12+0x120],r14
     14f:	mov    QWORD PTR [r12+0x128],r13
     157:	movabs r13,0x4100000041
     161:	mov    r14d,0x0
     167:	mov    QWORD PTR [r12+0x140],r13
     16f:	mov    QWORD PTR [r12+0x148],r14
     177:	movabs r13,0x3fc0000000000000
     181:	movabs r14,0x3fc0000000000000
     18b:	mov    QWORD PTR [r12+0x150],r13
     193:	mov    QWORD PTR [r12+0x158],r14
     19b:	movabs r13,0x200000002
     1a5:	mov    r14d,0x0
     1ab:	mov    QWORD PTR [r12+0x160],r13
     1b3:	mov    QWORD PTR [r12+0x168],r14
     1bb:	movabs r13,0x3fa0000000000000
     1c5:	mov    QWORD PTR [r12+0x130],r13
     1cd:	mov    QWORD PTR [r12+0x138],r13
     1d5:	mov    r13d,0x2
     1db:	mov    QWORD PTR [r12+0x170],r13
     1e3:	mov    QWORD PTR [r12+0x178],r13
     1eb:	mov    r13d,0x420000
     1f1:	mov    QWORD PTR [r12+0x40],r13
     1f6:	mov    r13d,0x430000
     1fc:	mov    QWORD PTR [r12+0x50],r13
     201:	mov    r13d,0x420a40
     207:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     20d:	movdqu XMMWORD PTR [r12+0x180],xmm2
     217:	mov    r13d,0x0
     21d:	mov    QWORD PTR [r12+0x48],r13
     222:	mov    r13d,0x431000
     228:	add    r13,0xe00
     22f:	mov    QWORD PTR [r12+0x40],r13
     234:	mov    r13d,0x430cb8
     23a:	mov    r14d,DWORD PTR [r12]
     23e:	mov    DWORD PTR [r13+0x0],r14d
     242:	mov    r13d,0x0
     248:	mov    DWORD PTR [r12+0x32c],r13d
     250:	mov    r13d,0x432000
     256:	mov    QWORD PTR [r12+0x50],r13
     25b:	mov    r11,rax
     25e:	movzx  eax,WORD PTR [rsp]
     262:	add    al,0x7f
     264:	sahf
     265:	mov    rax,r11
     268:	jmp    0x26d
     26d:	mov    r13,QWORD PTR [r12+0x180]
     275:	mov    r14,QWORD PTR [r12+0x188]
     27d:	mov    r15d,0x0
     283:	mov    r11,rax
     286:	lahf
     287:	seto   al
     28a:	mov    WORD PTR [rsp],ax
     28e:	mov    rax,r11
     291:	mov    ecx,0xffffffff
     296:	and    r13,rcx
     299:	mov    rbp,r15
     29c:	or     rbp,r13
     29f:	mov    ecx,0xffffffff
     2a4:	and    r14,rcx
     2a7:	shl    r14,0x20
     2ab:	or     rbp,r14
     2ae:	mov    QWORD PTR [r12+0x210],rbp
     2b6:	mov    QWORD PTR [r12+0x218],r15
     2be:	movdqu xmm2,XMMWORD PTR [r12+0x140]
     2c8:	movdqu xmm3,XMMWORD PTR [r12+0x120]
     2d2:	movdqa xmm1,xmm3
     2d6:	psubd  xmm2,xmm1
     2da:	movdqa xmm14,xmm2
     2df:	movdqa xmm1,xmm14
     2e4:	movq   rax,xmm1
     2e9:	mov    r13,rax
     2ec:	movdqu xmm2,XMMWORD PTR [r12+0x180]
     2f6:	movdqu xmm4,XMMWORD PTR [r12+0x170]
     300:	movdqa xmm1,xmm4
     304:	paddq  xmm2,xmm1
     308:	movdqu XMMWORD PTR [r12+0x180],xmm2
     312:	movdqu xmm2,XMMWORD PTR [r12+0x160]
     31c:	movdqa xmm1,xmm2
     320:	paddd  xmm3,xmm1
     324:	movdqa xmm14,xmm3
     329:	movdqa xmm1,xmm14
     32e:	movq   rax,xmm1
     333:	mov    r14,rax
     336:	mov    r15d,0x0
     33c:	mov    QWORD PTR [r12+0x120],r14
     344:	mov    QWORD PTR [r12+0x128],r15
     34c:	mov    r14d,0x0
     352:	mov    ecx,0xffffffff
     357:	mov    r15,r13
     35a:	and    r15,rcx
     35d:	mov    rbp,r14
     360:	or     rbp,r15
     363:	shr    r13,0x20
     367:	mov    ecx,0xffffffff
     36c:	and    r13,rcx
     36f:	or     r14,r13
     372:	mov    QWORD PTR [r12+0x220],rbp
     37a:	mov    QWORD PTR [r12+0x228],r14
     382:	movdqu xmm2,XMMWORD PTR [r12+0x210]
     38c:	movdqu xmm3,XMMWORD PTR [r12+0x110]
     396:	movdqa xmm1,xmm3
     39a:	paddd  xmm2,xmm1
     39e:	movdqa xmm14,xmm2
     3a3:	movdqa xmm1,xmm14
     3a8:	movq   rax,xmm1
     3ad:	mov    r13,rax
     3b0:	mov    r14d,0x0
     3b6:	mov    QWORD PTR [r12+0x210],r13
     3be:	mov    QWORD PTR [r12+0x218],r14
     3c6:	lea    r13,[r12]
     3ca:	movabs r14,0xb6e61da31
     3d4:	mov    r15d,0x410468
     3da:	mov    rdx,QWORD PTR [rsp]
     3de:	mov    r10d,edx
     3e1:	and    r10d,0xc000
     3e8:	shl    r10d,0x10
     3ec:	mov    r11d,edx
     3ef:	and    r11d,0x100
     3f6:	shl    r11d,0x15
     3fa:	or     r10d,r11d
     3fd:	and    edx,0x1
     400:	shl    edx,0x1c
     403:	or     r10d,edx
     406:	btc    r10,0x1d
     40b:	mov    r11d,0xf0000000
     411:	and    r11,r10
     414:	movabs rsi,0xffffffff0fffffff
     41e:	and    rbx,rsi
     421:	or     rbx,r11
     424:	mov    QWORD PTR [r12+0x378],0x3
     430:	mov    QWORD PTR [r12+0x108],rbx
     438:	stmxcsr DWORD PTR [r12-0x28]
     43e:	mov    r10d,DWORD PTR [r12-0x28]
     443:	test   r10d,0x3f
     44a:	je     0x46f
     450:	mov    r11d,r10d
     453:	shr    r10d,1
     456:	and    r10d,0x1e
     45a:	and    r11d,0x1
     45e:	or     r10d,r11d
     461:	or     DWORD PTR [r12+0x314],r10d
     469:	and    DWORD PTR [r12-0x28],0xffffffc0
     46f:	ldmxcsr DWORD PTR [r12-0x38]
     475:	movabs r11,0x590d850f15e0
     47f:	mov    rdi,r13
     482:	mov    rsi,r14
     485:	mov    rdx,r15
     488:	call   r11
     48b:	ldmxcsr DWORD PTR [r12-0x28]
     491:	mov    rbx,QWORD PTR [r12+0x108]
     499:	mov    QWORD PTR [r12+0x378],0x2
     4a5:	mov    rbp,rax
     4a8:	mov    r13,QWORD PTR [r12+0x210]
     4b0:	mov    r14d,0x0
     4b6:	mov    ecx,0xffffffff
     4bb:	mov    r15,r13
     4be:	and    r15,rcx
     4c1:	mov    rbp,r14
     4c4:	or     rbp,r15
     4c7:	shr    r13,0x20
     4cb:	mov    ecx,0xffffffff
     4d0:	and    r13,rcx
     4d3:	or     r14,r13
     4d6:	mov    QWORD PTR [r12+0x210],rbp
     4de:	mov    QWORD PTR [r12+0x218],r14
     4e6:	lea    r13,[r12]
     4ea:	movabs r14,0xb6e61da10
     4f4:	mov    r15d,0x410470
     4fa:	mov    QWORD PTR [r12+0x378],0x3
     506:	mov    QWORD PTR [r12+0x108],rbx
     50e:	stmxcsr DWORD PTR [r12-0x28]
     514:	mov    r10d,DWORD PTR [r12-0x28]
     519:	test   r10d,0x3f
     520:	je     0x545
     526:	mov    r11d,r10d
     529:	shr    r10d,1
     52c:	and    r10d,0x1e
     530:	and    r11d,0x1
     534:	or     r10d,r11d
     537:	or     DWORD PTR [r12+0x314],r10d
     53f:	and    DWORD PTR [r12-0x28],0xffffffc0
     545:	ldmxcsr DWORD PTR [r12-0x38]
     54b:	movabs r11,0x590d850f15e0
     555:	mov    rdi,r13
     558:	mov    rsi,r14
     55b:	mov    rdx,r15
     55e:	call   r11
     561:	ldmxcsr DWORD PTR [r12-0x28]
     567:	mov    rbx,QWORD PTR [r12+0x108]
     56f:	mov    QWORD PTR [r12+0x378],0x2
     57b:	mov    rbp,rax
     57e:	movdqu xmm2,XMMWORD PTR [r12+0x220]
     588:	movdqu xmm3,XMMWORD PTR [r12+0x150]
     592:	movdqa xmm0,xmm2
     596:	movdqa xmm1,xmm3
     59a:	mulpd  xmm0,xmm1
     59e:	movdqa xmm14,xmm0
     5a3:	movdqu xmm15,XMMWORD PTR [rip+0x9f34]        # 0xa4e0
     5ac:	pand   xmm14,xmm15
     5b1:	movdqu xmm15,XMMWORD PTR [rip+0x9f36]        # 0xa4f0
     5ba:	pcmpeqq xmm14,xmm15
     5c0:	movdqa xmm15,xmm0
     5c5:	cmpunordpd xmm15,xmm0
     5cb:	por    xmm14,xmm15
     5d0:	pmovmskb ecx,xmm14
     5d5:	jrcxz  0x5dc
     5d7:	jmp    0x2c4d
     5dc:	movdqa xmm4,xmm0
     5e0:	movdqu XMMWORD PTR [r12+0x220],xmm4
     5ea:	mov    r13,QWORD PTR [r12+0x48]
     5ef:	mov    r14,QWORD PTR [r12+0x50]
     5f4:	add    r14,r13
     5f7:	movdqu XMMWORD PTR [r14],xmm4
     5fc:	mov    r14d,0x0
     602:	mov    DWORD PTR [r12+0x32c],r14d
     60a:	movdqu xmm2,XMMWORD PTR [r12+0x210]
     614:	movdqu xmm3,XMMWORD PTR [r12+0x130]
     61e:	movdqa xmm0,xmm2
     622:	movdqa xmm1,xmm3
     626:	mulpd  xmm0,xmm1
     62a:	movdqa xmm14,xmm0
     62f:	movdqu xmm15,XMMWORD PTR [rip+0x9ea8]        # 0xa4e0
     638:	pand   xmm14,xmm15
     63d:	movdqu xmm15,XMMWORD PTR [rip+0x9eaa]        # 0xa4f0
     646:	pcmpeqq xmm14,xmm15
     64c:	movdqa xmm15,xmm0
     651:	cmpunordpd xmm15,xmm0
     657:	por    xmm14,xmm15
     65c:	pmovmskb ecx,xmm14
     661:	jrcxz  0x668
     663:	jmp    0x2c71
     668:	movdqa xmm4,xmm0
     66c:	movdqu XMMWORD PTR [r12+0x210],xmm4
     676:	mov    r14,QWORD PTR [r12+0x40]
     67b:	add    r14,r13
     67e:	movdqu XMMWORD PTR [r14],xmm4
     683:	add    r13,0x10
     687:	mov    QWORD PTR [r12+0x48],r13
     68c:	sub    r13,0x200
     693:	mov    rcx,QWORD PTR [r12+0x380]
     69b:	jrcxz  0x6a2
     69d:	jmp    0x9b19
     6a2:	jne    0x26d
     6a8:	mov    r11,rax
     6ab:	lahf
     6ac:	seto   al
     6af:	mov    WORD PTR [rsp],ax
     6b3:	mov    rax,r11
     6b6:	jmp    0x6bb
     6bb:	mov    r13,QWORD PTR [r12+0x50]
     6c0:	mov    r14,r13
     6c3:	add    r14,0x80
     6ca:	mov    r15,r14
     6cd:	add    r15,0x10
     6d1:	movdqu xmm2,XMMWORD PTR [r14]
     6d6:	movdqu xmm3,XMMWORD PTR [r15]
     6db:	movdqu XMMWORD PTR [r12+0x130],xmm2
     6e5:	movdqu XMMWORD PTR [r12+0x110],xmm3
     6ef:	mov    r14d,0x0
     6f5:	mov    r15d,0x0
     6fb:	mov    QWORD PTR [r12+0x1b0],r14
     703:	mov    QWORD PTR [r12+0x1b8],r15
     70b:	mov    r14,r13
     70e:	add    r14,0x40
     712:	mov    r15,r14
     715:	add    r15,0x10
     719:	movdqu xmm4,XMMWORD PTR [r14]
     71e:	movdqu xmm5,XMMWORD PTR [r15]
     723:	movdqu XMMWORD PTR [r12+0x250],xmm4
     72d:	movdqu XMMWORD PTR [r12+0x120],xmm5
     737:	mov    r14d,0x0
     73d:	mov    QWORD PTR [r12+0x48],r14
     742:	mov    r14,r13
     745:	add    r14,0x10
     749:	movdqu xmm4,XMMWORD PTR [r13+0x0]
     74f:	movdqu xmm6,XMMWORD PTR [r14]
     754:	movdqu XMMWORD PTR [r12+0x170],xmm4
     75e:	movdqu XMMWORD PTR [r12+0x180],xmm6
     768:	mov    r14,QWORD PTR [r12+0xf8]
     770:	mov    r15,r14
     773:	add    r15,0xe0
     77a:	mov    rbp,r15
     77d:	add    rbp,0x10
     781:	movdqu XMMWORD PTR [r15],xmm3
     786:	mov    r15d,0x0
     78c:	mov    DWORD PTR [r12+0x32c],r15d
     794:	movdqu XMMWORD PTR [rbp+0x0],xmm2
     799:	mov    r15,r13
     79c:	add    r15,0xc0
     7a3:	mov    rbp,r15
     7a6:	add    rbp,0x10
     7aa:	movdqu xmm2,XMMWORD PTR [r15]
     7af:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     7b4:	movdqu XMMWORD PTR [r12+0x130],xmm2
     7be:	movdqu XMMWORD PTR [r12+0x110],xmm3
     7c8:	mov    r15,r13
     7cb:	add    r15,0x140
     7d2:	mov    rbp,r15
     7d5:	add    rbp,0x10
     7d9:	movdqu xmm7,XMMWORD PTR [r15]
     7de:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
     7e4:	movdqu XMMWORD PTR [r12+0x270],xmm7
     7ee:	movdqu XMMWORD PTR [r12+0x190],xmm8
     7f8:	mov    r15,r13
     7fb:	add    r15,0x180
     802:	mov    rbp,r15
     805:	add    rbp,0x10
     809:	movdqu xmm7,XMMWORD PTR [r15]
     80e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
     814:	movdqu XMMWORD PTR [r12+0x2a0],xmm7
     81e:	movdqu XMMWORD PTR [r12+0x1a0],xmm8
     828:	mov    r15,r14
     82b:	add    r15,0xc0
     832:	mov    rbp,r15
     835:	add    rbp,0x10
     839:	movdqu XMMWORD PTR [r15],xmm3
     83e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
     843:	mov    r15,r13
     846:	add    r15,0x100
     84d:	mov    rbp,r15
     850:	add    rbp,0x10
     854:	movdqu xmm2,XMMWORD PTR [r15]
     859:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     85e:	movdqu XMMWORD PTR [r12+0x110],xmm2
     868:	movdqu XMMWORD PTR [r12+0x300],xmm3
     872:	mov    r15,r13
     875:	add    r15,0x1c0
     87c:	mov    rbp,r15
     87f:	add    rbp,0x10
     883:	movdqu xmm3,XMMWORD PTR [r15]
     888:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
     88d:	movdqu XMMWORD PTR [r12+0x240],xmm3
     897:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
     8a1:	mov    r15,r13
     8a4:	add    r15,0x20
     8a8:	mov    rbp,r15
     8ab:	add    rbp,0x10
     8af:	movdqu xmm7,XMMWORD PTR [r15]
     8b4:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
     8ba:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
     8c4:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
     8ce:	mov    r15,r14
     8d1:	add    r15,0x20
     8d5:	mov    rbp,r15
     8d8:	add    rbp,0x10
     8dc:	movdqu XMMWORD PTR [r15],xmm2
     8e1:	movdqu XMMWORD PTR [rbp+0x0],xmm5
     8e6:	mov    r15,r13
     8e9:	add    r15,0x60
     8ed:	mov    rbp,r15
     8f0:	add    rbp,0x10
     8f4:	movdqu xmm2,XMMWORD PTR [r15]
     8f9:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
     8fe:	movdqu XMMWORD PTR [r12+0x110],xmm2
     908:	movdqu XMMWORD PTR [r12+0x120],xmm5
     912:	mov    r15,r14
     915:	add    r15,0x60
     919:	mov    rbp,r15
     91c:	add    rbp,0x10
     920:	movdqu XMMWORD PTR [r15],xmm4
     925:	movdqu XMMWORD PTR [rbp+0x0],xmm3
     92a:	mov    r15,r13
     92d:	add    r15,0xe0
     934:	mov    rbp,r15
     937:	add    rbp,0x10
     93b:	movdqu xmm3,XMMWORD PTR [r15]
     940:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
     945:	movdqu XMMWORD PTR [r12+0x200],xmm3
     94f:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
     959:	mov    r15,r13
     95c:	add    r15,0x120
     963:	mov    rbp,r15
     966:	add    rbp,0x10
     96a:	movdqu xmm3,XMMWORD PTR [r15]
     96f:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
     974:	movdqu XMMWORD PTR [r12+0x2e0],xmm3
     97e:	movdqu XMMWORD PTR [r12+0x2f0],xmm4
     988:	mov    r15,r14
     98b:	add    r15,0xa0
     992:	mov    rbp,r15
     995:	add    rbp,0x10
     999:	movdqu XMMWORD PTR [r15],xmm5
     99e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
     9a3:	mov    r15,r13
     9a6:	add    r15,0xa0
     9ad:	mov    rbp,r15
     9b0:	add    rbp,0x10
     9b4:	movdqu xmm2,XMMWORD PTR [r15]
     9b9:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     9be:	movdqu XMMWORD PTR [r12+0x110],xmm2
     9c8:	movdqu XMMWORD PTR [r12+0x120],xmm3
     9d2:	mov    r15,r13
     9d5:	add    r15,0x160
     9dc:	mov    rbp,r15
     9df:	add    rbp,0x10
     9e3:	movdqu xmm4,XMMWORD PTR [r15]
     9e8:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
     9ed:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
     9f7:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
     a01:	mov    r15,r13
     a04:	add    r15,0x1a0
     a0b:	mov    rbp,r15
     a0e:	add    rbp,0x10
     a12:	movdqu xmm5,XMMWORD PTR [r15]
     a17:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
     a1c:	movdqu XMMWORD PTR [r12+0x290],xmm5
     a26:	movdqu XMMWORD PTR [r12+0x1e0],xmm7
     a30:	mov    r15,r14
     a33:	add    r15,0x80
     a3a:	mov    rbp,r15
     a3d:	add    rbp,0x10
     a41:	movdqu XMMWORD PTR [r15],xmm3
     a46:	movdqu XMMWORD PTR [rbp+0x0],xmm2
     a4b:	add    r13,0x1e0
     a52:	mov    r15,r13
     a55:	add    r15,0x10
     a59:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     a5f:	movdqu xmm3,XMMWORD PTR [r15]
     a64:	movdqu XMMWORD PTR [r12+0x230],xmm2
     a6e:	movdqu XMMWORD PTR [r12+0x280],xmm3
     a78:	mov    r13d,0x432000
     a7e:	add    r13,0x200
     a85:	mov    QWORD PTR [r12+0x50],r13
     a8a:	mov    r13,r14
     a8d:	add    r13,0x40
     a91:	mov    r15,r13
     a94:	add    r15,0x10
     a98:	movdqu XMMWORD PTR [r13+0x0],xmm4
     a9e:	movdqu XMMWORD PTR [r15],xmm6
     aa3:	mov    r13,r14
     aa6:	add    r13,0x10
     aaa:	movdqu XMMWORD PTR [r14],xmm3
     aaf:	movdqu XMMWORD PTR [r13+0x0],xmm2
     ab5:	mov    r11,rax
     ab8:	movzx  eax,WORD PTR [rsp]
     abc:	add    al,0x7f
     abe:	sahf
     abf:	mov    rax,r11
     ac2:	jmp    0xac7
     ac7:	mov    r13d,0x0
     acd:	mov    QWORD PTR [r12+0x58],r13
     ad2:	mov    r11,rax
     ad5:	lahf
     ad6:	seto   al
     ad9:	mov    WORD PTR [rsp],ax
     add:	mov    rax,r11
     ae0:	jmp    0xae5
     ae5:	mov    r13,QWORD PTR [r12+0x58]
     aea:	mov    r14,QWORD PTR [r12+0x40]
     aef:	add    r14,r13
     af2:	mov    QWORD PTR [r12+0x60],r14
     af7:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
     b01:	movdqa xmm0,xmm2
     b05:	movdqa xmm1,xmm2
     b09:	por    xmm0,xmm1
     b0d:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
     b17:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
     b21:	movdqa xmm0,xmm4
     b25:	movdqa xmm1,xmm4
     b29:	por    xmm0,xmm1
     b2d:	movdqu XMMWORD PTR [r12+0x120],xmm0
     b37:	mov    r15,r14
     b3a:	add    r15,0x30
     b3e:	mov    rbp,r15
     b41:	add    rbp,0x8
     b45:	mov    r8,QWORD PTR [r15]
     b48:	mov    r15,QWORD PTR [rbp+0x0]
     b4c:	mov    ebp,0x0
     b51:	mov    QWORD PTR [r12+0x130],r8
     b59:	mov    QWORD PTR [r12+0x138],rbp
     b61:	mov    ebp,0x0
     b66:	mov    QWORD PTR [r12+0x280],r15
     b6e:	mov    QWORD PTR [r12+0x288],rbp
     b76:	movdqu xmm5,XMMWORD PTR [r12+0x270]
     b80:	movdqa xmm0,xmm5
     b84:	movdqa xmm1,xmm5
     b88:	por    xmm0,xmm1
     b8c:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
     b96:	mov    r15,r14
     b99:	add    r15,0x20
     b9d:	mov    rbp,r15
     ba0:	add    rbp,0x8
     ba4:	mov    r8,QWORD PTR [r15]
     ba7:	mov    r15,QWORD PTR [rbp+0x0]
     bab:	mov    ebp,0x0
     bb0:	mov    QWORD PTR [r12+0x150],r8
     bb8:	mov    QWORD PTR [r12+0x158],rbp
     bc0:	mov    ebp,0x0
     bc5:	mov    QWORD PTR [r12+0x140],r15
     bcd:	mov    QWORD PTR [r12+0x148],rbp
     bd5:	mov    r15,r14
     bd8:	add    r15,0x10
     bdc:	mov    rbp,r15
     bdf:	add    rbp,0x8
     be3:	mov    r8,QWORD PTR [r15]
     be6:	mov    r15,QWORD PTR [rbp+0x0]
     bea:	mov    ebp,0x0
     bef:	mov    QWORD PTR [r12+0x170],r8
     bf7:	mov    QWORD PTR [r12+0x178],rbp
     bff:	mov    ebp,0x0
     c04:	mov    QWORD PTR [r12+0x160],r15
     c0c:	mov    QWORD PTR [r12+0x168],rbp
     c14:	mov    r15d,0x8
     c1a:	mov    rbp,QWORD PTR [r14]
     c1d:	mov    QWORD PTR [r12+0x180],rbp
     c25:	mov    QWORD PTR [r12+0x188],rbp
     c2d:	add    r14,r15
     c30:	mov    QWORD PTR [r12+0x60],r14
     c35:	mov    r15,QWORD PTR [r14]
     c38:	mov    r14d,0x0
     c3e:	mov    QWORD PTR [r12+0x230],r15
     c46:	mov    QWORD PTR [r12+0x238],r14
     c4e:	mov    r14,QWORD PTR [r12+0xf8]
     c56:	mov    r15,r14
     c59:	add    r15,0x50
     c5d:	mov    rbp,r15
     c60:	add    rbp,0x10
     c64:	movdqu xmm6,XMMWORD PTR [r15]
     c69:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
     c6e:	movdqu XMMWORD PTR [r12+0x220],xmm6
     c78:	movdqu XMMWORD PTR [r12+0x210],xmm7
     c82:	mov    r15,r14
     c85:	add    r15,0x30
     c89:	movdqu xmm8,XMMWORD PTR [r15]
     c8e:	movdqu XMMWORD PTR [r12+0x110],xmm8
     c98:	mov    r15,QWORD PTR [r12+0x50]
     c9d:	add    r15,r13
     ca0:	mov    QWORD PTR [r12+0x60],r15
     ca5:	add    r13,0x40
     ca9:	mov    QWORD PTR [r12+0x58],r13
     cae:	movdqu xmm9,XMMWORD PTR [r12+0x180]
     cb8:	movdqa xmm0,xmm9
     cbd:	movdqa xmm1,xmm2
     cc1:	mulpd  xmm0,xmm1
     cc5:	movdqa xmm14,xmm0
     cca:	movdqu xmm15,XMMWORD PTR [rip+0x980d]        # 0xa4e0
     cd3:	pand   xmm14,xmm15
     cd8:	movdqu xmm15,XMMWORD PTR [rip+0x980f]        # 0xa4f0
     ce1:	pcmpeqq xmm14,xmm15
     ce7:	movdqa xmm15,xmm0
     cec:	cmpunordpd xmm15,xmm0
     cf2:	por    xmm14,xmm15
     cf7:	pmovmskb ecx,xmm14
     cfc:	jrcxz  0xd03
     cfe:	jmp    0x2c95
     d03:	movdqa xmm10,xmm0
     d08:	movdqu xmm2,XMMWORD PTR [r12+0x230]
     d12:	movdqa xmm0,xmm8
     d17:	movdqa xmm1,xmm2
     d1b:	pshufd xmm1,xmm1,0x44
     d20:	mulpd  xmm0,xmm1
     d24:	movdqa xmm14,xmm0
     d29:	movdqu xmm15,XMMWORD PTR [rip+0x97ae]        # 0xa4e0
     d32:	pand   xmm14,xmm15
     d37:	movdqu xmm15,XMMWORD PTR [rip+0x97b0]        # 0xa4f0
     d40:	pcmpeqq xmm14,xmm15
     d46:	movdqa xmm15,xmm0
     d4b:	cmpunordpd xmm15,xmm0
     d51:	por    xmm14,xmm15
     d56:	pmovmskb ecx,xmm14
     d5b:	jrcxz  0xd62
     d5d:	jmp    0x2cba
     d62:	movdqa xmm11,xmm0
     d67:	movdqu XMMWORD PTR [r12+0x260],xmm11
     d71:	mov    ebp,0x0
     d76:	mov    r8d,0x0
     d7c:	mov    QWORD PTR [r12+0x110],rbp
     d84:	mov    QWORD PTR [r12+0x118],r8
     d8c:	movdqa xmm0,xmm9
     d91:	movdqa xmm1,xmm7
     d95:	mulpd  xmm0,xmm1
     d99:	movdqa xmm14,xmm0
     d9e:	movdqu xmm15,XMMWORD PTR [rip+0x9739]        # 0xa4e0
     da7:	pand   xmm14,xmm15
     dac:	movdqu xmm15,XMMWORD PTR [rip+0x973b]        # 0xa4f0
     db5:	pcmpeqq xmm14,xmm15
     dbb:	movdqa xmm15,xmm0
     dc0:	cmpunordpd xmm15,xmm0
     dc6:	por    xmm14,xmm15
     dcb:	pmovmskb ecx,xmm14
     dd0:	jrcxz  0xdd7
     dd2:	jmp    0x2cdf
     dd7:	movdqa xmm8,xmm0
     ddc:	movdqa xmm0,xmm9
     de1:	movdqa xmm1,xmm6
     de5:	mulpd  xmm0,xmm1
     de9:	movdqa xmm14,xmm0
     dee:	movdqu xmm15,XMMWORD PTR [rip+0x96e9]        # 0xa4e0
     df7:	pand   xmm14,xmm15
     dfc:	movdqu xmm15,XMMWORD PTR [rip+0x96eb]        # 0xa4f0
     e05:	pcmpeqq xmm14,xmm15
     e0b:	movdqa xmm15,xmm0
     e10:	cmpunordpd xmm15,xmm0
     e16:	por    xmm14,xmm15
     e1b:	pmovmskb ecx,xmm14
     e20:	jrcxz  0xe27
     e22:	jmp    0x2d04
     e27:	movdqa xmm7,xmm0
     e2b:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
     e35:	movdqa xmm0,xmm9
     e3a:	movdqa xmm1,xmm6
     e3e:	mulpd  xmm0,xmm1
     e42:	movdqa xmm14,xmm0
     e47:	movdqu xmm15,XMMWORD PTR [rip+0x9690]        # 0xa4e0
     e50:	pand   xmm14,xmm15
     e55:	movdqu xmm15,XMMWORD PTR [rip+0x9692]        # 0xa4f0
     e5e:	pcmpeqq xmm14,xmm15
     e64:	movdqa xmm15,xmm0
     e69:	cmpunordpd xmm15,xmm0
     e6f:	por    xmm14,xmm15
     e74:	pmovmskb ecx,xmm14
     e79:	jrcxz  0xe80
     e7b:	jmp    0x2d29
     e80:	movdqa xmm12,xmm0
     e85:	movdqu XMMWORD PTR [r12+0x180],xmm12
     e8f:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
     e99:	movdqa xmm0,xmm6
     e9d:	movdqa xmm1,xmm6
     ea1:	por    xmm0,xmm1
     ea5:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
     eaf:	movdqu xmm9,XMMWORD PTR [r12+0x250]
     eb9:	movdqa xmm0,xmm9
     ebe:	movdqa xmm1,xmm9
     ec3:	por    xmm0,xmm1
     ec7:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
     ed1:	movdqa xmm0,xmm9
     ed6:	movdqa xmm1,xmm2
     eda:	pshufd xmm1,xmm1,0x44
     edf:	mulpd  xmm0,xmm1
     ee3:	movdqa xmm14,xmm0
     ee8:	movdqu xmm15,XMMWORD PTR [rip+0x95ef]        # 0xa4e0
     ef1:	pand   xmm14,xmm15
     ef6:	movdqu xmm15,XMMWORD PTR [rip+0x95f1]        # 0xa4f0
     eff:	pcmpeqq xmm14,xmm15
     f05:	movdqa xmm15,xmm0
     f0a:	cmpunordpd xmm15,xmm0
     f10:	por    xmm14,xmm15
     f15:	pmovmskb ecx,xmm14
     f1a:	jrcxz  0xf21
     f1c:	jmp    0x2d4e
     f21:	movdqa xmm4,xmm0
     f25:	movdqu XMMWORD PTR [r12+0x250],xmm4
     f2f:	sub    r13,0x200
     f36:	movdqu xmm9,XMMWORD PTR [r12+0x110]
     f40:	movdqa xmm0,xmm10
     f45:	movdqa xmm1,xmm9
     f4a:	addpd  xmm0,xmm1
     f4e:	movdqa xmm14,xmm0
     f53:	movdqu xmm15,XMMWORD PTR [rip+0x9584]        # 0xa4e0
     f5c:	pand   xmm14,xmm15
     f61:	movdqu xmm15,XMMWORD PTR [rip+0x9586]        # 0xa4f0
     f6a:	pcmpeqq xmm14,xmm15
     f70:	movdqa xmm15,xmm0
     f75:	cmpunordpd xmm15,xmm0
     f7b:	por    xmm14,xmm15
     f80:	pmovmskb ecx,xmm14
     f85:	jrcxz  0xf8c
     f87:	jmp    0x2d73
     f8c:	movdqu XMMWORD PTR [r12+0x240],xmm0
     f96:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
     fa0:	movdqa xmm0,xmm8
     fa5:	movdqa xmm1,xmm10
     faa:	addpd  xmm0,xmm1
     fae:	movdqa xmm14,xmm0
     fb3:	movdqu xmm15,XMMWORD PTR [rip+0x9524]        # 0xa4e0
     fbc:	pand   xmm14,xmm15
     fc1:	movdqu xmm15,XMMWORD PTR [rip+0x9526]        # 0xa4f0
     fca:	pcmpeqq xmm14,xmm15
     fd0:	movdqa xmm15,xmm0
     fd5:	cmpunordpd xmm15,xmm0
     fdb:	por    xmm14,xmm15
     fe0:	pmovmskb ecx,xmm14
     fe5:	jrcxz  0xfec
     fe7:	jmp    0x2db4
     fec:	movdqa xmm6,xmm0
     ff0:	movdqu XMMWORD PTR [r12+0x210],xmm6
     ffa:	movdqa xmm0,xmm7
     ffe:	movdqa xmm1,xmm10
    1003:	addpd  xmm0,xmm1
    1007:	movdqa xmm14,xmm0
    100c:	movdqu xmm15,XMMWORD PTR [rip+0x94cb]        # 0xa4e0
    1015:	pand   xmm14,xmm15
    101a:	movdqu xmm15,XMMWORD PTR [rip+0x94cd]        # 0xa4f0
    1023:	pcmpeqq xmm14,xmm15
    1029:	movdqa xmm15,xmm0
    102e:	cmpunordpd xmm15,xmm0
    1034:	por    xmm14,xmm15
    1039:	pmovmskb ecx,xmm14
    103e:	jrcxz  0x1045
    1040:	jmp    0x2df5
    1045:	movdqa xmm8,xmm0
    104a:	movdqu XMMWORD PTR [r12+0x220],xmm8
    1054:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    105e:	setne  BYTE PTR [rsp+0x8]
    1063:	mov    r11,rax
    1066:	lahf
    1067:	seto   al
    106a:	mov    WORD PTR [rsp],ax
    106e:	mov    rax,r11
    1071:	movdqa xmm0,xmm7
    1075:	movdqa xmm1,xmm7
    1079:	por    xmm0,xmm1
    107d:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    1087:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    1091:	movdqa xmm0,xmm10
    1096:	movdqa xmm1,xmm10
    109b:	por    xmm0,xmm1
    109f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    10a9:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    10b3:	movdqa xmm0,xmm13
    10b8:	movdqa xmm1,xmm13
    10bd:	por    xmm0,xmm1
    10c1:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    10cb:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    10d5:	movdqa xmm0,xmm5
    10d9:	movdqa xmm1,xmm5
    10dd:	por    xmm0,xmm1
    10e1:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    10eb:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    10f5:	movdqa xmm1,xmm7
    10f9:	por    xmm7,xmm1
    10fd:	movdqu XMMWORD PTR [r12+0x200],xmm7
    1107:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    1111:	movdqa xmm1,xmm3
    1115:	por    xmm3,xmm1
    1119:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    1123:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    112d:	movdqa xmm1,xmm10
    1132:	por    xmm10,xmm1
    1137:	movdqu XMMWORD PTR [r12+0x190],xmm10
    1141:	mov    r13,r14
    1144:	add    r13,0xa0
    114b:	mov    rbp,r13
    114e:	add    rbp,0x10
    1152:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    1158:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    115d:	movdqu XMMWORD PTR [r12+0x300],xmm13
    1167:	movdqu XMMWORD PTR [r12+0x270],xmm5
    1171:	movdqa xmm0,xmm12
    1176:	movdqa xmm1,xmm9
    117b:	addpd  xmm0,xmm1
    117f:	movdqa xmm14,xmm0
    1184:	movdqu xmm15,XMMWORD PTR [rip+0x9353]        # 0xa4e0
    118d:	pand   xmm14,xmm15
    1192:	movdqu xmm15,XMMWORD PTR [rip+0x9355]        # 0xa4f0
    119b:	pcmpeqq xmm14,xmm15
    11a1:	movdqa xmm15,xmm0
    11a6:	cmpunordpd xmm15,xmm0
    11ac:	por    xmm14,xmm15
    11b1:	pmovmskb ecx,xmm14
    11b6:	jrcxz  0x11bd
    11b8:	jmp    0x2e35
    11bd:	movdqu XMMWORD PTR [r12+0x180],xmm0
    11c7:	mov    r13,r14
    11ca:	add    r13,0xf0
    11d1:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    11d7:	movdqu XMMWORD PTR [r12+0x110],xmm9
    11e1:	movdqa xmm0,xmm6
    11e5:	movdqa xmm1,xmm4
    11e9:	addpd  xmm0,xmm1
    11ed:	movdqa xmm14,xmm0
    11f2:	movdqu xmm15,XMMWORD PTR [rip+0x92e5]        # 0xa4e0
    11fb:	pand   xmm14,xmm15
    1200:	movdqu xmm15,XMMWORD PTR [rip+0x92e7]        # 0xa4f0
    1209:	pcmpeqq xmm14,xmm15
    120f:	movdqa xmm15,xmm0
    1214:	cmpunordpd xmm15,xmm0
    121a:	por    xmm14,xmm15
    121f:	pmovmskb ecx,xmm14
    1224:	jrcxz  0x122b
    1226:	jmp    0x2e5b
    122b:	movdqa xmm12,xmm0
    1230:	movdqu XMMWORD PTR [r12+0x210],xmm12
    123a:	movdqa xmm0,xmm8
    123f:	movdqa xmm1,xmm11
    1244:	addpd  xmm0,xmm1
    1248:	movdqa xmm14,xmm0
    124d:	movdqu xmm15,XMMWORD PTR [rip+0x928a]        # 0xa4e0
    1256:	pand   xmm14,xmm15
    125b:	movdqu xmm15,XMMWORD PTR [rip+0x928c]        # 0xa4f0
    1264:	pcmpeqq xmm14,xmm15
    126a:	movdqa xmm15,xmm0
    126f:	cmpunordpd xmm15,xmm0
    1275:	por    xmm14,xmm15
    127a:	pmovmskb ecx,xmm14
    127f:	jrcxz  0x1286
    1281:	jmp    0x2e7f
    1286:	movdqa xmm4,xmm0
    128a:	movdqu XMMWORD PTR [r12+0x220],xmm4
    1294:	movdqa xmm0,xmm5
    1298:	movdqa xmm1,xmm2
    129c:	pshufd xmm1,xmm1,0x44
    12a1:	mulpd  xmm0,xmm1
    12a5:	movdqa xmm14,xmm0
    12aa:	movdqu xmm15,XMMWORD PTR [rip+0x922d]        # 0xa4e0
    12b3:	pand   xmm14,xmm15
    12b8:	movdqu xmm15,XMMWORD PTR [rip+0x922f]        # 0xa4f0
    12c1:	pcmpeqq xmm14,xmm15
    12c7:	movdqa xmm15,xmm0
    12cc:	cmpunordpd xmm15,xmm0
    12d2:	por    xmm14,xmm15
    12d7:	pmovmskb ecx,xmm14
    12dc:	jrcxz  0x12e3
    12de:	jmp    0x2ea5
    12e3:	movdqa xmm6,xmm0
    12e7:	movdqu XMMWORD PTR [r12+0x270],xmm6
    12f1:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    12fb:	movdqa xmm0,xmm9
    1300:	movdqa xmm1,xmm5
    1304:	pshufd xmm1,xmm1,0x44
    1309:	mulpd  xmm0,xmm1
    130d:	movdqa xmm14,xmm0
    1312:	movdqu xmm15,XMMWORD PTR [rip+0x91c5]        # 0xa4e0
    131b:	pand   xmm14,xmm15
    1320:	movdqu xmm15,XMMWORD PTR [rip+0x91c7]        # 0xa4f0
    1329:	pcmpeqq xmm14,xmm15
    132f:	movdqa xmm15,xmm0
    1334:	cmpunordpd xmm15,xmm0
    133a:	por    xmm14,xmm15
    133f:	pmovmskb ecx,xmm14
    1344:	jrcxz  0x134b
    1346:	jmp    0x2ec9
    134b:	movdqa xmm8,xmm0
    1350:	movdqu XMMWORD PTR [r12+0x250],xmm8
    135a:	mov    r13,r14
    135d:	add    r13,0xe0
    1364:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    136a:	movdqu XMMWORD PTR [r12+0x110],xmm9
    1374:	movdqa xmm0,xmm13
    1379:	movdqa xmm1,xmm2
    137d:	pshufd xmm1,xmm1,0x44
    1382:	mulpd  xmm0,xmm1
    1386:	movdqa xmm14,xmm0
    138b:	movdqu xmm15,XMMWORD PTR [rip+0x914c]        # 0xa4e0
    1394:	pand   xmm14,xmm15
    1399:	movdqu xmm15,XMMWORD PTR [rip+0x914e]        # 0xa4f0
    13a2:	pcmpeqq xmm14,xmm15
    13a8:	movdqa xmm15,xmm0
    13ad:	cmpunordpd xmm15,xmm0
    13b3:	por    xmm14,xmm15
    13b8:	pmovmskb ecx,xmm14
    13bd:	jrcxz  0x13c4
    13bf:	jmp    0x2eee
    13c4:	movdqa xmm11,xmm0
    13c9:	movdqu XMMWORD PTR [r12+0x230],xmm11
    13d3:	movdqa xmm0,xmm10
    13d8:	movdqa xmm1,xmm10
    13dd:	por    xmm0,xmm1
    13e1:	movdqu XMMWORD PTR [r12+0x300],xmm0
    13eb:	movdqa xmm0,xmm3
    13ef:	movdqa xmm1,xmm3
    13f3:	por    xmm0,xmm1
    13f7:	movdqu XMMWORD PTR [r12+0x190],xmm0
    1401:	movdqa xmm0,xmm9
    1406:	movdqa xmm1,xmm5
    140a:	pshufd xmm1,xmm1,0x44
    140f:	mulpd  xmm0,xmm1
    1413:	movdqa xmm14,xmm0
    1418:	movdqu xmm15,XMMWORD PTR [rip+0x90bf]        # 0xa4e0
    1421:	pand   xmm14,xmm15
    1426:	movdqu xmm15,XMMWORD PTR [rip+0x90c1]        # 0xa4f0
    142f:	pcmpeqq xmm14,xmm15
    1435:	movdqa xmm15,xmm0
    143a:	cmpunordpd xmm15,xmm0
    1440:	por    xmm14,xmm15
    1445:	pmovmskb ecx,xmm14
    144a:	jrcxz  0x1451
    144c:	jmp    0x2f13
    1451:	movdqa xmm2,xmm0
    1455:	movdqu XMMWORD PTR [r12+0x260],xmm2
    145f:	mov    r13,r14
    1462:	add    r13,0x90
    1469:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    146f:	movdqu XMMWORD PTR [r12+0x110],xmm9
    1479:	movdqa xmm0,xmm7
    147d:	movdqa xmm1,xmm7
    1481:	por    xmm0,xmm1
    1485:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    148f:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    1499:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    14a3:	por    xmm13,xmm1
    14a8:	movdqu XMMWORD PTR [r12+0x200],xmm13
    14b2:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    14bc:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    14c6:	por    xmm7,xmm1
    14ca:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    14d4:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    14de:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    14e8:	por    xmm0,xmm1
    14ec:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    14f6:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    1500:	movdqa xmm1,xmm6
    1504:	addpd  xmm0,xmm1
    1508:	movdqa xmm14,xmm0
    150d:	movdqu xmm15,XMMWORD PTR [rip+0x8fca]        # 0xa4e0
    1516:	pand   xmm14,xmm15
    151b:	movdqu xmm15,XMMWORD PTR [rip+0x8fcc]        # 0xa4f0
    1524:	pcmpeqq xmm14,xmm15
    152a:	movdqa xmm15,xmm0
    152f:	cmpunordpd xmm15,xmm0
    1535:	por    xmm14,xmm15
    153a:	pmovmskb ecx,xmm14
    153f:	jrcxz  0x1546
    1541:	jmp    0x2f38
    1546:	movdqa xmm3,xmm0
    154a:	movdqu XMMWORD PTR [r12+0x240],xmm3
    1554:	movdqa xmm0,xmm9
    1559:	movdqa xmm1,xmm5
    155d:	pshufd xmm1,xmm1,0x44
    1562:	mulpd  xmm0,xmm1
    1566:	movdqa xmm14,xmm0
    156b:	movdqu xmm15,XMMWORD PTR [rip+0x8f6c]        # 0xa4e0
    1574:	pand   xmm14,xmm15
    1579:	movdqu xmm15,XMMWORD PTR [rip+0x8f6e]        # 0xa4f0
    1582:	pcmpeqq xmm14,xmm15
    1588:	movdqa xmm15,xmm0
    158d:	cmpunordpd xmm15,xmm0
    1593:	por    xmm14,xmm15
    1598:	pmovmskb ecx,xmm14
    159d:	jrcxz  0x15a4
    159f:	jmp    0x2f62
    15a4:	movdqa xmm6,xmm0
    15a8:	movdqu XMMWORD PTR [r12+0x270],xmm6
    15b2:	mov    r13,r14
    15b5:	add    r13,0x80
    15bc:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    15c2:	movdqu XMMWORD PTR [r12+0x110],xmm9
    15cc:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    15d6:	movdqa xmm1,xmm11
    15db:	addpd  xmm0,xmm1
    15df:	movdqa xmm14,xmm0
    15e4:	movdqu xmm15,XMMWORD PTR [rip+0x8ef3]        # 0xa4e0
    15ed:	pand   xmm14,xmm15
    15f2:	movdqu xmm15,XMMWORD PTR [rip+0x8ef5]        # 0xa4f0
    15fb:	pcmpeqq xmm14,xmm15
    1601:	movdqa xmm15,xmm0
    1606:	cmpunordpd xmm15,xmm0
    160c:	por    xmm14,xmm15
    1611:	pmovmskb ecx,xmm14
    1616:	jrcxz  0x161d
    1618:	jmp    0x2f87
    161d:	movdqa xmm10,xmm0
    1622:	movdqu XMMWORD PTR [r12+0x180],xmm10
    162c:	movdqa xmm0,xmm12
    1631:	movdqa xmm1,xmm8
    1636:	addpd  xmm0,xmm1
    163a:	movdqa xmm14,xmm0
    163f:	movdqu xmm15,XMMWORD PTR [rip+0x8e98]        # 0xa4e0
    1648:	pand   xmm14,xmm15
    164d:	movdqu xmm15,XMMWORD PTR [rip+0x8e9a]        # 0xa4f0
    1656:	pcmpeqq xmm14,xmm15
    165c:	movdqa xmm15,xmm0
    1661:	cmpunordpd xmm15,xmm0
    1667:	por    xmm14,xmm15
    166c:	pmovmskb ecx,xmm14
    1671:	jrcxz  0x1678
    1673:	jmp    0x2fb2
    1678:	movdqa xmm11,xmm0
    167d:	movdqu XMMWORD PTR [r12+0x210],xmm11
    1687:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    1691:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    169b:	por    xmm0,xmm1
    169f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    16a9:	movdqa xmm0,xmm9
    16ae:	movdqa xmm1,xmm5
    16b2:	pshufd xmm1,xmm1,0x44
    16b7:	mulpd  xmm0,xmm1
    16bb:	movdqa xmm14,xmm0
    16c0:	movdqu xmm15,XMMWORD PTR [rip+0x8e17]        # 0xa4e0
    16c9:	pand   xmm14,xmm15
    16ce:	movdqu xmm15,XMMWORD PTR [rip+0x8e19]        # 0xa4f0
    16d7:	pcmpeqq xmm14,xmm15
    16dd:	movdqa xmm15,xmm0
    16e2:	cmpunordpd xmm15,xmm0
    16e8:	por    xmm14,xmm15
    16ed:	pmovmskb ecx,xmm14
    16f2:	jrcxz  0x16f9
    16f4:	jmp    0x2fd8
    16f9:	movdqa xmm12,xmm0
    16fe:	movdqu XMMWORD PTR [r12+0x170],xmm12
    1708:	mov    r13,r14
    170b:	add    r13,0xd0
    1712:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    1718:	movdqu XMMWORD PTR [r12+0x110],xmm5
    1722:	movdqa xmm0,xmm4
    1726:	movdqa xmm1,xmm2
    172a:	addpd  xmm0,xmm1
    172e:	movdqa xmm14,xmm0
    1733:	movdqu xmm15,XMMWORD PTR [rip+0x8da4]        # 0xa4e0
    173c:	pand   xmm14,xmm15
    1741:	movdqu xmm15,XMMWORD PTR [rip+0x8da6]        # 0xa4f0
    174a:	pcmpeqq xmm14,xmm15
    1750:	movdqa xmm15,xmm0
    1755:	cmpunordpd xmm15,xmm0
    175b:	por    xmm14,xmm15
    1760:	pmovmskb ecx,xmm14
    1765:	jrcxz  0x176c
    1767:	jmp    0x2ffd
    176c:	movdqa xmm9,xmm0
    1771:	movdqu XMMWORD PTR [r12+0x220],xmm9
    177b:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    1785:	movdqa xmm0,xmm13
    178a:	movdqa xmm1,xmm2
    178e:	pshufd xmm1,xmm1,0x44
    1793:	mulpd  xmm0,xmm1
    1797:	movdqa xmm14,xmm0
    179c:	movdqu xmm15,XMMWORD PTR [rip+0x8d3b]        # 0xa4e0
    17a5:	pand   xmm14,xmm15
    17aa:	movdqu xmm15,XMMWORD PTR [rip+0x8d3d]        # 0xa4f0
    17b3:	pcmpeqq xmm14,xmm15
    17b9:	movdqa xmm15,xmm0
    17be:	cmpunordpd xmm15,xmm0
    17c4:	por    xmm14,xmm15
    17c9:	pmovmskb ecx,xmm14
    17ce:	jrcxz  0x17d5
    17d0:	jmp    0x3021
    17d5:	movdqa xmm4,xmm0
    17d9:	movdqu XMMWORD PTR [r12+0x260],xmm4
    17e3:	mov    r13d,0x0
    17e9:	mov    ebp,0x0
    17ee:	mov    QWORD PTR [r12+0x1b0],r13
    17f6:	mov    QWORD PTR [r12+0x1b8],rbp
    17fe:	movdqa xmm0,xmm5
    1802:	movdqa xmm1,xmm2
    1806:	pshufd xmm1,xmm1,0x44
    180b:	mulpd  xmm0,xmm1
    180f:	movdqa xmm14,xmm0
    1814:	movdqu xmm15,XMMWORD PTR [rip+0x8cc3]        # 0xa4e0
    181d:	pand   xmm14,xmm15
    1822:	movdqu xmm15,XMMWORD PTR [rip+0x8cc5]        # 0xa4f0
    182b:	pcmpeqq xmm14,xmm15
    1831:	movdqa xmm15,xmm0
    1836:	cmpunordpd xmm15,xmm0
    183c:	por    xmm14,xmm15
    1841:	pmovmskb ecx,xmm14
    1846:	jrcxz  0x184d
    1848:	jmp    0x3046
    184d:	movdqa xmm13,xmm0
    1852:	movdqu XMMWORD PTR [r12+0x230],xmm13
    185c:	mov    r13,r14
    185f:	add    r13,0xc0
    1866:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    186c:	movdqu XMMWORD PTR [r12+0x110],xmm5
    1876:	movdqa xmm0,xmm3
    187a:	movdqa xmm1,xmm6
    187e:	addpd  xmm0,xmm1
    1882:	movdqa xmm14,xmm0
    1887:	movdqu xmm15,XMMWORD PTR [rip+0x8c50]        # 0xa4e0
    1890:	pand   xmm14,xmm15
    1895:	movdqu xmm15,XMMWORD PTR [rip+0x8c52]        # 0xa4f0
    189e:	pcmpeqq xmm14,xmm15
    18a4:	movdqa xmm15,xmm0
    18a9:	cmpunordpd xmm15,xmm0
    18af:	por    xmm14,xmm15
    18b4:	pmovmskb ecx,xmm14
    18b9:	jrcxz  0x18c0
    18bb:	jmp    0x306a
    18c0:	movdqa xmm8,xmm0
    18c5:	movdqu XMMWORD PTR [r12+0x240],xmm8
    18cf:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    18d9:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    18e3:	por    xmm0,xmm1
    18e7:	movdqu XMMWORD PTR [r12+0x270],xmm0
    18f1:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    18fb:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    1905:	por    xmm6,xmm1
    1909:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    1913:	movdqa xmm0,xmm5
    1917:	movdqa xmm1,xmm2
    191b:	pshufd xmm1,xmm1,0x44
    1920:	mulpd  xmm0,xmm1
    1924:	movdqa xmm14,xmm0
    1929:	movdqu xmm15,XMMWORD PTR [rip+0x8bae]        # 0xa4e0
    1932:	pand   xmm14,xmm15
    1937:	movdqu xmm15,XMMWORD PTR [rip+0x8bb0]        # 0xa4f0
    1940:	pcmpeqq xmm14,xmm15
    1946:	movdqa xmm15,xmm0
    194b:	cmpunordpd xmm15,xmm0
    1951:	por    xmm14,xmm15
    1956:	pmovmskb ecx,xmm14
    195b:	jrcxz  0x1962
    195d:	jmp    0x308e
    1962:	movdqa xmm6,xmm0
    1966:	movdqu XMMWORD PTR [r12+0x250],xmm6
    1970:	mov    r13,r14
    1973:	add    r13,0x20
    1977:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    197d:	movdqu XMMWORD PTR [r12+0x110],xmm5
    1987:	movdqa xmm0,xmm10
    198c:	movdqa xmm1,xmm12
    1991:	addpd  xmm0,xmm1
    1995:	movdqa xmm14,xmm0
    199a:	movdqu xmm15,XMMWORD PTR [rip+0x8b3d]        # 0xa4e0
    19a3:	pand   xmm14,xmm15
    19a8:	movdqu xmm15,XMMWORD PTR [rip+0x8b3f]        # 0xa4f0
    19b1:	pcmpeqq xmm14,xmm15
    19b7:	movdqa xmm15,xmm0
    19bc:	cmpunordpd xmm15,xmm0
    19c2:	por    xmm14,xmm15
    19c7:	pmovmskb ecx,xmm14
    19cc:	jrcxz  0x19d3
    19ce:	jmp    0x30b2
    19d3:	movdqa xmm3,xmm0
    19d7:	movdqa xmm0,xmm7
    19db:	movdqa xmm1,xmm2
    19df:	pshufd xmm1,xmm1,0x44
    19e4:	mulpd  xmm0,xmm1
    19e8:	movdqa xmm14,xmm0
    19ed:	movdqu xmm15,XMMWORD PTR [rip+0x8aea]        # 0xa4e0
    19f6:	pand   xmm14,xmm15
    19fb:	movdqu xmm15,XMMWORD PTR [rip+0x8aec]        # 0xa4f0
    1a04:	pcmpeqq xmm14,xmm15
    1a0a:	movdqa xmm15,xmm0
    1a0f:	cmpunordpd xmm15,xmm0
    1a15:	por    xmm14,xmm15
    1a1a:	pmovmskb ecx,xmm14
    1a1f:	jrcxz  0x1a26
    1a21:	jmp    0x30d8
    1a26:	movdqa xmm10,xmm0
    1a2b:	movdqa xmm0,xmm11
    1a30:	movdqa xmm1,xmm13
    1a35:	addpd  xmm0,xmm1
    1a39:	movdqa xmm14,xmm0
    1a3e:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0xa4e0
    1a47:	pand   xmm14,xmm15
    1a4c:	movdqu xmm15,XMMWORD PTR [rip+0x8a9b]        # 0xa4f0
    1a55:	pcmpeqq xmm14,xmm15
    1a5b:	movdqa xmm15,xmm0
    1a60:	cmpunordpd xmm15,xmm0
    1a66:	por    xmm14,xmm15
    1a6b:	pmovmskb ecx,xmm14
    1a70:	jrcxz  0x1a77
    1a72:	jmp    0x30fc
    1a77:	movdqa xmm2,xmm0
    1a7b:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    1a85:	movdqa xmm0,xmm5
    1a89:	movdqa xmm1,xmm7
    1a8d:	pshufd xmm1,xmm1,0x44
    1a92:	mulpd  xmm0,xmm1
    1a96:	movdqa xmm14,xmm0
    1a9b:	movdqu xmm15,XMMWORD PTR [rip+0x8a3c]        # 0xa4e0
    1aa4:	pand   xmm14,xmm15
    1aa9:	movdqu xmm15,XMMWORD PTR [rip+0x8a3e]        # 0xa4f0
    1ab2:	pcmpeqq xmm14,xmm15
    1ab8:	movdqa xmm15,xmm0
    1abd:	cmpunordpd xmm15,xmm0
    1ac3:	por    xmm14,xmm15
    1ac8:	pmovmskb ecx,xmm14
    1acd:	jrcxz  0x1ad4
    1acf:	jmp    0x3122
    1ad4:	movdqa xmm11,xmm0
    1ad9:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    1ae3:	movdqa xmm1,xmm7
    1ae7:	pshufd xmm1,xmm1,0x44
    1aec:	mulpd  xmm0,xmm1
    1af0:	movdqa xmm14,xmm0
    1af5:	movdqu xmm15,XMMWORD PTR [rip+0x89e2]        # 0xa4e0
    1afe:	pand   xmm14,xmm15
    1b03:	movdqu xmm15,XMMWORD PTR [rip+0x89e4]        # 0xa4f0
    1b0c:	pcmpeqq xmm14,xmm15
    1b12:	movdqa xmm15,xmm0
    1b17:	cmpunordpd xmm15,xmm0
    1b1d:	por    xmm14,xmm15
    1b22:	pmovmskb ecx,xmm14
    1b27:	jrcxz  0x1b2e
    1b29:	jmp    0x3146
    1b2e:	movdqa xmm5,xmm0
    1b32:	movdqa xmm0,xmm8
    1b37:	movdqa xmm1,xmm4
    1b3b:	addpd  xmm0,xmm1
    1b3f:	movdqa xmm14,xmm0
    1b44:	movdqu xmm15,XMMWORD PTR [rip+0x8993]        # 0xa4e0
    1b4d:	pand   xmm14,xmm15
    1b52:	movdqu xmm15,XMMWORD PTR [rip+0x8995]        # 0xa4f0
    1b5b:	pcmpeqq xmm14,xmm15
    1b61:	movdqa xmm15,xmm0
    1b66:	cmpunordpd xmm15,xmm0
    1b6c:	por    xmm14,xmm15
    1b71:	pmovmskb ecx,xmm14
    1b76:	jrcxz  0x1b7d
    1b78:	jmp    0x3170
    1b7d:	movdqa xmm12,xmm0
    1b82:	movdqu XMMWORD PTR [r12+0x240],xmm12
    1b8c:	movdqa xmm0,xmm9
    1b91:	movdqa xmm1,xmm6
    1b95:	addpd  xmm0,xmm1
    1b99:	movdqa xmm14,xmm0
    1b9e:	movdqu xmm15,XMMWORD PTR [rip+0x8939]        # 0xa4e0
    1ba7:	pand   xmm14,xmm15
    1bac:	movdqu xmm15,XMMWORD PTR [rip+0x893b]        # 0xa4f0
    1bb5:	pcmpeqq xmm14,xmm15
    1bbb:	movdqa xmm15,xmm0
    1bc0:	cmpunordpd xmm15,xmm0
    1bc6:	por    xmm14,xmm15
    1bcb:	pmovmskb ecx,xmm14
    1bd0:	jrcxz  0x1bd7
    1bd2:	jmp    0x3195
    1bd7:	movdqa xmm4,xmm0
    1bdb:	movdqu XMMWORD PTR [r12+0x220],xmm4
    1be5:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    1bef:	movdqa xmm1,xmm7
    1bf3:	pshufd xmm1,xmm1,0x44
    1bf8:	mulpd  xmm0,xmm1
    1bfc:	movdqa xmm14,xmm0
    1c01:	movdqu xmm15,XMMWORD PTR [rip+0x88d6]        # 0xa4e0
    1c0a:	pand   xmm14,xmm15
    1c0f:	movdqu xmm15,XMMWORD PTR [rip+0x88d8]        # 0xa4f0
    1c18:	pcmpeqq xmm14,xmm15
    1c1e:	movdqa xmm15,xmm0
    1c23:	cmpunordpd xmm15,xmm0
    1c29:	por    xmm14,xmm15
    1c2e:	pmovmskb ecx,xmm14
    1c33:	jrcxz  0x1c3a
    1c35:	jmp    0x31ba
    1c3a:	movdqa xmm6,xmm0
    1c3e:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    1c48:	movdqa xmm1,xmm7
    1c4c:	pshufd xmm1,xmm1,0x44
    1c51:	mulpd  xmm0,xmm1
    1c55:	movdqa xmm14,xmm0
    1c5a:	movdqu xmm15,XMMWORD PTR [rip+0x887d]        # 0xa4e0
    1c63:	pand   xmm14,xmm15
    1c68:	movdqu xmm15,XMMWORD PTR [rip+0x887f]        # 0xa4f0
    1c71:	pcmpeqq xmm14,xmm15
    1c77:	movdqa xmm15,xmm0
    1c7c:	cmpunordpd xmm15,xmm0
    1c82:	por    xmm14,xmm15
    1c87:	pmovmskb ecx,xmm14
    1c8c:	jrcxz  0x1c93
    1c8e:	jmp    0x31e4
    1c93:	movdqa xmm8,xmm0
    1c98:	movdqu XMMWORD PTR [r12+0x150],xmm8
    1ca2:	movdqa xmm0,xmm3
    1ca6:	movdqa xmm1,xmm10
    1cab:	addpd  xmm0,xmm1
    1caf:	movdqa xmm14,xmm0
    1cb4:	movdqu xmm15,XMMWORD PTR [rip+0x8823]        # 0xa4e0
    1cbd:	pand   xmm14,xmm15
    1cc2:	movdqu xmm15,XMMWORD PTR [rip+0x8825]        # 0xa4f0
    1ccb:	pcmpeqq xmm14,xmm15
    1cd1:	movdqa xmm15,xmm0
    1cd6:	cmpunordpd xmm15,xmm0
    1cdc:	por    xmm14,xmm15
    1ce1:	pmovmskb ecx,xmm14
    1ce6:	jrcxz  0x1ced
    1ce8:	jmp    0x320e
    1ced:	movdqa xmm7,xmm0
    1cf1:	movdqu XMMWORD PTR [r12+0x160],xmm7
    1cfb:	movdqa xmm0,xmm2
    1cff:	movdqa xmm1,xmm11
    1d04:	addpd  xmm0,xmm1
    1d08:	movdqa xmm14,xmm0
    1d0d:	movdqu xmm15,XMMWORD PTR [rip+0x87ca]        # 0xa4e0
    1d16:	pand   xmm14,xmm15
    1d1b:	movdqu xmm15,XMMWORD PTR [rip+0x87cc]        # 0xa4f0
    1d24:	pcmpeqq xmm14,xmm15
    1d2a:	movdqa xmm15,xmm0
    1d2f:	cmpunordpd xmm15,xmm0
    1d35:	por    xmm14,xmm15
    1d3a:	pmovmskb ecx,xmm14
    1d3f:	jrcxz  0x1d46
    1d41:	jmp    0x3233
    1d46:	movdqa xmm3,xmm0
    1d4a:	movdqu XMMWORD PTR [r12+0x170],xmm3
    1d54:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    1d5e:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    1d68:	movdqa xmm1,xmm2
    1d6c:	pshufd xmm1,xmm1,0x44
    1d71:	mulpd  xmm0,xmm1
    1d75:	movdqa xmm14,xmm0
    1d7a:	movdqu xmm15,XMMWORD PTR [rip+0x875d]        # 0xa4e0
    1d83:	pand   xmm14,xmm15
    1d88:	movdqu xmm15,XMMWORD PTR [rip+0x875f]        # 0xa4f0
    1d91:	pcmpeqq xmm14,xmm15
    1d97:	movdqa xmm15,xmm0
    1d9c:	cmpunordpd xmm15,xmm0
    1da2:	por    xmm14,xmm15
    1da7:	pmovmskb ecx,xmm14
    1dac:	jrcxz  0x1db3
    1dae:	jmp    0x3258
    1db3:	movdqa xmm9,xmm0
    1db8:	movdqu XMMWORD PTR [r12+0x180],xmm9
    1dc2:	movdqa xmm0,xmm4
    1dc6:	movdqa xmm1,xmm5
    1dca:	addpd  xmm0,xmm1
    1dce:	movdqa xmm14,xmm0
    1dd3:	movdqu xmm15,XMMWORD PTR [rip+0x8704]        # 0xa4e0
    1ddc:	pand   xmm14,xmm15
    1de1:	movdqu xmm15,XMMWORD PTR [rip+0x8706]        # 0xa4f0
    1dea:	pcmpeqq xmm14,xmm15
    1df0:	movdqa xmm15,xmm0
    1df5:	cmpunordpd xmm15,xmm0
    1dfb:	por    xmm14,xmm15
    1e00:	pmovmskb ecx,xmm14
    1e05:	jrcxz  0x1e0c
    1e07:	jmp    0x3282
    1e0c:	movdqa xmm10,xmm0
    1e11:	movdqu XMMWORD PTR [r12+0x210],xmm10
    1e1b:	movdqa xmm0,xmm12
    1e20:	movdqa xmm1,xmm6
    1e24:	addpd  xmm0,xmm1
    1e28:	movdqa xmm14,xmm0
    1e2d:	movdqu xmm15,XMMWORD PTR [rip+0x86aa]        # 0xa4e0
    1e36:	pand   xmm14,xmm15
    1e3b:	movdqu xmm15,XMMWORD PTR [rip+0x86ac]        # 0xa4f0
    1e44:	pcmpeqq xmm14,xmm15
    1e4a:	movdqa xmm15,xmm0
    1e4f:	cmpunordpd xmm15,xmm0
    1e55:	por    xmm14,xmm15
    1e5a:	pmovmskb ecx,xmm14
    1e5f:	jrcxz  0x1e66
    1e61:	jmp    0x32a6
    1e66:	movdqa xmm4,xmm0
    1e6a:	movdqu XMMWORD PTR [r12+0x230],xmm4
    1e74:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    1e7e:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    1e88:	por    xmm5,xmm1
    1e8c:	movdqu XMMWORD PTR [r12+0x250],xmm5
    1e96:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    1ea0:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    1eaa:	por    xmm5,xmm1
    1eae:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    1eb8:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    1ec2:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    1ecc:	por    xmm6,xmm1
    1ed0:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    1eda:	mov    r13,r14
    1edd:	add    r13,0x40
    1ee1:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    1ee7:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    1ef1:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    1efb:	movdqa xmm1,xmm2
    1eff:	pshufd xmm1,xmm1,0x44
    1f04:	mulpd  xmm0,xmm1
    1f08:	movdqa xmm14,xmm0
    1f0d:	movdqu xmm15,XMMWORD PTR [rip+0x85ca]        # 0xa4e0
    1f16:	pand   xmm14,xmm15
    1f1b:	movdqu xmm15,XMMWORD PTR [rip+0x85cc]        # 0xa4f0
    1f24:	pcmpeqq xmm14,xmm15
    1f2a:	movdqa xmm15,xmm0
    1f2f:	cmpunordpd xmm15,xmm0
    1f35:	por    xmm14,xmm15
    1f3a:	pmovmskb ecx,xmm14
    1f3f:	jrcxz  0x1f46
    1f41:	jmp    0x32cb
    1f46:	movdqa xmm11,xmm0
    1f4b:	movdqa xmm0,xmm7
    1f4f:	movdqa xmm1,xmm8
    1f54:	addpd  xmm0,xmm1
    1f58:	movdqa xmm14,xmm0
    1f5d:	movdqu xmm15,XMMWORD PTR [rip+0x857a]        # 0xa4e0
    1f66:	pand   xmm14,xmm15
    1f6b:	movdqu xmm15,XMMWORD PTR [rip+0x857c]        # 0xa4f0
    1f74:	pcmpeqq xmm14,xmm15
    1f7a:	movdqa xmm15,xmm0
    1f7f:	cmpunordpd xmm15,xmm0
    1f85:	por    xmm14,xmm15
    1f8a:	pmovmskb ecx,xmm14
    1f8f:	jrcxz  0x1f96
    1f91:	jmp    0x32f5
    1f96:	movdqa xmm12,xmm0
    1f9b:	movdqa xmm0,xmm3
    1f9f:	movdqa xmm1,xmm9
    1fa4:	addpd  xmm0,xmm1
    1fa8:	movdqa xmm14,xmm0
    1fad:	movdqu xmm15,XMMWORD PTR [rip+0x852a]        # 0xa4e0
    1fb6:	pand   xmm14,xmm15
    1fbb:	movdqu xmm15,XMMWORD PTR [rip+0x852c]        # 0xa4f0
    1fc4:	pcmpeqq xmm14,xmm15
    1fca:	movdqa xmm15,xmm0
    1fcf:	cmpunordpd xmm15,xmm0
    1fd5:	por    xmm14,xmm15
    1fda:	pmovmskb ecx,xmm14
    1fdf:	jrcxz  0x1fe6
    1fe1:	jmp    0x331a
    1fe6:	movdqa xmm7,xmm0
    1fea:	movdqu XMMWORD PTR [r12+0x160],xmm7
    1ff4:	movdqa xmm0,xmm6
    1ff8:	movdqa xmm1,xmm2
    1ffc:	pshufd xmm1,xmm1,0x44
    2001:	mulpd  xmm0,xmm1
    2005:	movdqa xmm14,xmm0
    200a:	movdqu xmm15,XMMWORD PTR [rip+0x84cd]        # 0xa4e0
    2013:	pand   xmm14,xmm15
    2018:	movdqu xmm15,XMMWORD PTR [rip+0x84cf]        # 0xa4f0
    2021:	pcmpeqq xmm14,xmm15
    2027:	movdqa xmm15,xmm0
    202c:	cmpunordpd xmm15,xmm0
    2032:	por    xmm14,xmm15
    2037:	pmovmskb ecx,xmm14
    203c:	jrcxz  0x2043
    203e:	jmp    0x333f
    2043:	movdqa xmm3,xmm0
    2047:	movdqu XMMWORD PTR [r12+0x240],xmm3
    2051:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    205b:	movdqa xmm0,xmm6
    205f:	movdqa xmm1,xmm2
    2063:	pshufd xmm1,xmm1,0x44
    2068:	mulpd  xmm0,xmm1
    206c:	movdqa xmm14,xmm0
    2071:	movdqu xmm15,XMMWORD PTR [rip+0x8466]        # 0xa4e0
    207a:	pand   xmm14,xmm15
    207f:	movdqu xmm15,XMMWORD PTR [rip+0x8468]        # 0xa4f0
    2088:	pcmpeqq xmm14,xmm15
    208e:	movdqa xmm15,xmm0
    2093:	cmpunordpd xmm15,xmm0
    2099:	por    xmm14,xmm15
    209e:	pmovmskb ecx,xmm14
    20a3:	jrcxz  0x20aa
    20a5:	jmp    0x3363
    20aa:	movdqa xmm8,xmm0
    20af:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    20b9:	movdqa xmm0,xmm5
    20bd:	movdqa xmm1,xmm2
    20c1:	pshufd xmm1,xmm1,0x44
    20c6:	mulpd  xmm0,xmm1
    20ca:	movdqa xmm14,xmm0
    20cf:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0xa4e0
    20d8:	pand   xmm14,xmm15
    20dd:	movdqu xmm15,XMMWORD PTR [rip+0x840a]        # 0xa4f0
    20e6:	pcmpeqq xmm14,xmm15
    20ec:	movdqa xmm15,xmm0
    20f1:	cmpunordpd xmm15,xmm0
    20f7:	por    xmm14,xmm15
    20fc:	pmovmskb ecx,xmm14
    2101:	jrcxz  0x2108
    2103:	jmp    0x3387
    2108:	movdqa xmm6,xmm0
    210c:	movdqu XMMWORD PTR [r12+0x170],xmm6
    2116:	movdqa xmm0,xmm10
    211b:	movdqa xmm1,xmm11
    2120:	addpd  xmm0,xmm1
    2124:	movdqa xmm14,xmm0
    2129:	movdqu xmm15,XMMWORD PTR [rip+0x83ae]        # 0xa4e0
    2132:	pand   xmm14,xmm15
    2137:	movdqu xmm15,XMMWORD PTR [rip+0x83b0]        # 0xa4f0
    2140:	pcmpeqq xmm14,xmm15
    2146:	movdqa xmm15,xmm0
    214b:	cmpunordpd xmm15,xmm0
    2151:	por    xmm14,xmm15
    2156:	pmovmskb ecx,xmm14
    215b:	jrcxz  0x2162
    215d:	jmp    0x33ab
    2162:	movdqa xmm5,xmm0
    2166:	movdqu XMMWORD PTR [r12+0x180],xmm5
    2170:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    217a:	movdqa xmm1,xmm2
    217e:	pshufd xmm1,xmm1,0x44
    2183:	mulpd  xmm0,xmm1
    2187:	movdqa xmm14,xmm0
    218c:	movdqu xmm15,XMMWORD PTR [rip+0x834b]        # 0xa4e0
    2195:	pand   xmm14,xmm15
    219a:	movdqu xmm15,XMMWORD PTR [rip+0x834d]        # 0xa4f0
    21a3:	pcmpeqq xmm14,xmm15
    21a9:	movdqa xmm15,xmm0
    21ae:	cmpunordpd xmm15,xmm0
    21b4:	por    xmm14,xmm15
    21b9:	pmovmskb ecx,xmm14
    21be:	jrcxz  0x21c5
    21c0:	jmp    0x33d1
    21c5:	movdqa xmm9,xmm0
    21ca:	movdqu XMMWORD PTR [r12+0x210],xmm9
    21d4:	movdqa xmm0,xmm4
    21d8:	movdqa xmm1,xmm3
    21dc:	addpd  xmm0,xmm1
    21e0:	movdqa xmm14,xmm0
    21e5:	movdqu xmm15,XMMWORD PTR [rip+0x82f2]        # 0xa4e0
    21ee:	pand   xmm14,xmm15
    21f3:	movdqu xmm15,XMMWORD PTR [rip+0x82f4]        # 0xa4f0
    21fc:	pcmpeqq xmm14,xmm15
    2202:	movdqa xmm15,xmm0
    2207:	cmpunordpd xmm15,xmm0
    220d:	por    xmm14,xmm15
    2212:	pmovmskb ecx,xmm14
    2217:	jrcxz  0x221e
    2219:	jmp    0x33fb
    221e:	movdqa xmm10,xmm0
    2223:	movdqu XMMWORD PTR [r12+0x220],xmm10
    222d:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    2237:	movdqa xmm0,xmm3
    223b:	movdqa xmm1,xmm2
    223f:	pshufd xmm1,xmm1,0x44
    2244:	mulpd  xmm0,xmm1
    2248:	movdqa xmm14,xmm0
    224d:	movdqu xmm15,XMMWORD PTR [rip+0x828a]        # 0xa4e0
    2256:	pand   xmm14,xmm15
    225b:	movdqu xmm15,XMMWORD PTR [rip+0x828c]        # 0xa4f0
    2264:	pcmpeqq xmm14,xmm15
    226a:	movdqa xmm15,xmm0
    226f:	cmpunordpd xmm15,xmm0
    2275:	por    xmm14,xmm15
    227a:	pmovmskb ecx,xmm14
    227f:	jrcxz  0x2286
    2281:	jmp    0x341f
    2286:	movdqa xmm4,xmm0
    228a:	movdqu XMMWORD PTR [r12+0x230],xmm4
    2294:	movdqa xmm0,xmm12
    2299:	movdqa xmm1,xmm8
    229e:	addpd  xmm0,xmm1
    22a2:	movdqa xmm14,xmm0
    22a7:	movdqu xmm15,XMMWORD PTR [rip+0x8230]        # 0xa4e0
    22b0:	pand   xmm14,xmm15
    22b5:	movdqu xmm15,XMMWORD PTR [rip+0x8232]        # 0xa4f0
    22be:	pcmpeqq xmm14,xmm15
    22c4:	movdqa xmm15,xmm0
    22c9:	cmpunordpd xmm15,xmm0
    22cf:	por    xmm14,xmm15
    22d4:	pmovmskb ecx,xmm14
    22d9:	jrcxz  0x22e0
    22db:	jmp    0x3443
    22e0:	movdqa xmm3,xmm0
    22e4:	movdqu XMMWORD PTR [r12+0x140],xmm3
    22ee:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    22f8:	movdqa xmm0,xmm8
    22fd:	movdqa xmm1,xmm2
    2301:	pshufd xmm1,xmm1,0x44
    2306:	mulpd  xmm0,xmm1
    230a:	movdqa xmm14,xmm0
    230f:	movdqu xmm15,XMMWORD PTR [rip+0x81c8]        # 0xa4e0
    2318:	pand   xmm14,xmm15
    231d:	movdqu xmm15,XMMWORD PTR [rip+0x81ca]        # 0xa4f0
    2326:	pcmpeqq xmm14,xmm15
    232c:	movdqa xmm15,xmm0
    2331:	cmpunordpd xmm15,xmm0
    2337:	por    xmm14,xmm15
    233c:	pmovmskb ecx,xmm14
    2341:	jrcxz  0x2348
    2343:	jmp    0x3469
    2348:	movdqa xmm11,xmm0
    234d:	movdqu XMMWORD PTR [r12+0x130],xmm11
    2357:	movdqa xmm0,xmm7
    235b:	movdqa xmm1,xmm6
    235f:	addpd  xmm0,xmm1
    2363:	movdqa xmm14,xmm0
    2368:	movdqu xmm15,XMMWORD PTR [rip+0x816f]        # 0xa4e0
    2371:	pand   xmm14,xmm15
    2376:	movdqu xmm15,XMMWORD PTR [rip+0x8171]        # 0xa4f0
    237f:	pcmpeqq xmm14,xmm15
    2385:	movdqa xmm15,xmm0
    238a:	cmpunordpd xmm15,xmm0
    2390:	por    xmm14,xmm15
    2395:	pmovmskb ecx,xmm14
    239a:	jrcxz  0x23a1
    239c:	jmp    0x348e
    23a1:	movdqa xmm2,xmm0
    23a5:	movdqu XMMWORD PTR [r12+0x150],xmm2
    23af:	mov    r13,r14
    23b2:	add    r13,0x70
    23b6:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    23bc:	movdqu XMMWORD PTR [r12+0x240],xmm6
    23c6:	movdqa xmm0,xmm5
    23ca:	movdqa xmm1,xmm9
    23cf:	addpd  xmm0,xmm1
    23d3:	movdqa xmm14,xmm0
    23d8:	movdqu xmm15,XMMWORD PTR [rip+0x80ff]        # 0xa4e0
    23e1:	pand   xmm14,xmm15
    23e6:	movdqu xmm15,XMMWORD PTR [rip+0x8101]        # 0xa4f0
    23ef:	pcmpeqq xmm14,xmm15
    23f5:	movdqa xmm15,xmm0
    23fa:	cmpunordpd xmm15,xmm0
    2400:	por    xmm14,xmm15
    2405:	pmovmskb ecx,xmm14
    240a:	jrcxz  0x2411
    240c:	jmp    0x34b2
    2411:	movdqa xmm7,xmm0
    2415:	movdqu XMMWORD PTR [r12+0x170],xmm7
    241f:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    2429:	movdqa xmm0,xmm6
    242d:	movdqa xmm1,xmm5
    2431:	pshufd xmm1,xmm1,0x44
    2436:	mulpd  xmm0,xmm1
    243a:	movdqa xmm14,xmm0
    243f:	movdqu xmm15,XMMWORD PTR [rip+0x8098]        # 0xa4e0
    2448:	pand   xmm14,xmm15
    244d:	movdqu xmm15,XMMWORD PTR [rip+0x809a]        # 0xa4f0
    2456:	pcmpeqq xmm14,xmm15
    245c:	movdqa xmm15,xmm0
    2461:	cmpunordpd xmm15,xmm0
    2467:	por    xmm14,xmm15
    246c:	pmovmskb ecx,xmm14
    2471:	jrcxz  0x2478
    2473:	jmp    0x34d7
    2478:	movdqa xmm8,xmm0
    247d:	movdqu XMMWORD PTR [r12+0x160],xmm8
    2487:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    2491:	movdqa xmm1,xmm5
    2495:	pshufd xmm1,xmm1,0x44
    249a:	mulpd  xmm0,xmm1
    249e:	movdqa xmm14,xmm0
    24a3:	movdqu xmm15,XMMWORD PTR [rip+0x8034]        # 0xa4e0
    24ac:	pand   xmm14,xmm15
    24b1:	movdqu xmm15,XMMWORD PTR [rip+0x8036]        # 0xa4f0
    24ba:	pcmpeqq xmm14,xmm15
    24c0:	movdqa xmm15,xmm0
    24c5:	cmpunordpd xmm15,xmm0
    24cb:	por    xmm14,xmm15
    24d0:	pmovmskb ecx,xmm14
    24d5:	jrcxz  0x24dc
    24d7:	jmp    0x34fb
    24dc:	movdqa xmm6,xmm0
    24e0:	movdqu XMMWORD PTR [r12+0x180],xmm6
    24ea:	movdqa xmm0,xmm10
    24ef:	movdqa xmm1,xmm4
    24f3:	addpd  xmm0,xmm1
    24f7:	movdqa xmm14,xmm0
    24fc:	movdqu xmm15,XMMWORD PTR [rip+0x7fdb]        # 0xa4e0
    2505:	pand   xmm14,xmm15
    250a:	movdqu xmm15,XMMWORD PTR [rip+0x7fdd]        # 0xa4f0
    2513:	pcmpeqq xmm14,xmm15
    2519:	movdqa xmm15,xmm0
    251e:	cmpunordpd xmm15,xmm0
    2524:	por    xmm14,xmm15
    2529:	pmovmskb ecx,xmm14
    252e:	jrcxz  0x2535
    2530:	jmp    0x3525
    2535:	movdqa xmm9,xmm0
    253a:	movdqu XMMWORD PTR [r12+0x210],xmm9
    2544:	mov    r13,r14
    2547:	add    r13,0x10
    254b:	movdqu xmm4,XMMWORD PTR [r14]
    2550:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    2556:	movdqu XMMWORD PTR [r12+0x230],xmm10
    2560:	movdqa xmm0,xmm3
    2564:	movdqa xmm1,xmm11
    2569:	addpd  xmm0,xmm1
    256d:	movdqa xmm14,xmm0
    2572:	movdqu xmm15,XMMWORD PTR [rip+0x7f65]        # 0xa4e0
    257b:	pand   xmm14,xmm15
    2580:	movdqu xmm15,XMMWORD PTR [rip+0x7f67]        # 0xa4f0
    2589:	pcmpeqq xmm14,xmm15
    258f:	movdqa xmm15,xmm0
    2594:	cmpunordpd xmm15,xmm0
    259a:	por    xmm14,xmm15
    259f:	pmovmskb ecx,xmm14
    25a4:	jrcxz  0x25ab
    25a6:	jmp    0x354a
    25ab:	movdqa xmm12,xmm0
    25b0:	movdqu XMMWORD PTR [r12+0x130],xmm12
    25ba:	movdqa xmm0,xmm10
    25bf:	movdqa xmm1,xmm5
    25c3:	pshufd xmm1,xmm1,0x44
    25c8:	mulpd  xmm0,xmm1
    25cc:	movdqa xmm14,xmm0
    25d1:	movdqu xmm15,XMMWORD PTR [rip+0x7f06]        # 0xa4e0
    25da:	pand   xmm14,xmm15
    25df:	movdqu xmm15,XMMWORD PTR [rip+0x7f08]        # 0xa4f0
    25e8:	pcmpeqq xmm14,xmm15
    25ee:	movdqa xmm15,xmm0
    25f3:	cmpunordpd xmm15,xmm0
    25f9:	por    xmm14,xmm15
    25fe:	pmovmskb ecx,xmm14
    2603:	jrcxz  0x260a
    2605:	jmp    0x356f
    260a:	movdqa xmm3,xmm0
    260e:	movdqu XMMWORD PTR [r12+0x220],xmm3
    2618:	movdqa xmm0,xmm4
    261c:	movdqa xmm1,xmm5
    2620:	pshufd xmm1,xmm1,0x44
    2625:	mulpd  xmm0,xmm1
    2629:	movdqa xmm14,xmm0
    262e:	movdqu xmm15,XMMWORD PTR [rip+0x7ea9]        # 0xa4e0
    2637:	pand   xmm14,xmm15
    263c:	movdqu xmm15,XMMWORD PTR [rip+0x7eab]        # 0xa4f0
    2645:	pcmpeqq xmm14,xmm15
    264b:	movdqa xmm15,xmm0
    2650:	cmpunordpd xmm15,xmm0
    2656:	por    xmm14,xmm15
    265b:	pmovmskb ecx,xmm14
    2660:	jrcxz  0x2667
    2662:	jmp    0x3594
    2667:	movdqa xmm10,xmm0
    266c:	movdqa xmm0,xmm2
    2670:	movdqa xmm1,xmm8
    2675:	addpd  xmm0,xmm1
    2679:	movdqa xmm14,xmm0
    267e:	movdqu xmm15,XMMWORD PTR [rip+0x7e59]        # 0xa4e0
    2687:	pand   xmm14,xmm15
    268c:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0xa4f0
    2695:	pcmpeqq xmm14,xmm15
    269b:	movdqa xmm15,xmm0
    26a0:	cmpunordpd xmm15,xmm0
    26a6:	por    xmm14,xmm15
    26ab:	pmovmskb ecx,xmm14
    26b0:	jrcxz  0x26b7
    26b2:	jmp    0x35b8
    26b7:	movdqa xmm4,xmm0
    26bb:	movdqu XMMWORD PTR [r12+0x140],xmm4
    26c5:	movdqa xmm0,xmm7
    26c9:	movdqa xmm1,xmm6
    26cd:	addpd  xmm0,xmm1
    26d1:	movdqa xmm14,xmm0
    26d6:	movdqu xmm15,XMMWORD PTR [rip+0x7e01]        # 0xa4e0
    26df:	pand   xmm14,xmm15
    26e4:	movdqu xmm15,XMMWORD PTR [rip+0x7e03]        # 0xa4f0
    26ed:	pcmpeqq xmm14,xmm15
    26f3:	movdqa xmm15,xmm0
    26f8:	cmpunordpd xmm15,xmm0
    26fe:	por    xmm14,xmm15
    2703:	pmovmskb ecx,xmm14
    2708:	jrcxz  0x270f
    270a:	jmp    0x35dd
    270f:	movdqa xmm2,xmm0
    2713:	movdqu XMMWORD PTR [r12+0x150],xmm2
    271d:	movdqa xmm0,xmm9
    2722:	movdqa xmm1,xmm3
    2726:	addpd  xmm0,xmm1
    272a:	movdqa xmm14,xmm0
    272f:	movdqu xmm15,XMMWORD PTR [rip+0x7da8]        # 0xa4e0
    2738:	pand   xmm14,xmm15
    273d:	movdqu xmm15,XMMWORD PTR [rip+0x7daa]        # 0xa4f0
    2746:	pcmpeqq xmm14,xmm15
    274c:	movdqa xmm15,xmm0
    2751:	cmpunordpd xmm15,xmm0
    2757:	por    xmm14,xmm15
    275c:	pmovmskb ecx,xmm14
    2761:	jrcxz  0x2768
    2763:	jmp    0x3601
    2768:	movdqa xmm5,xmm0
    276c:	movdqu XMMWORD PTR [r12+0x160],xmm5
    2776:	movdqa xmm0,xmm12
    277b:	movdqa xmm1,xmm10
    2780:	addpd  xmm0,xmm1
    2784:	movdqa xmm14,xmm0
    2789:	movdqu xmm15,XMMWORD PTR [rip+0x7d4e]        # 0xa4e0
    2792:	pand   xmm14,xmm15
    2797:	movdqu xmm15,XMMWORD PTR [rip+0x7d50]        # 0xa4f0
    27a0:	pcmpeqq xmm14,xmm15
    27a6:	movdqa xmm15,xmm0
    27ab:	cmpunordpd xmm15,xmm0
    27b1:	por    xmm14,xmm15
    27b6:	pmovmskb ecx,xmm14
    27bb:	jrcxz  0x27c2
    27bd:	jmp    0x3626
    27c2:	movdqa xmm3,xmm0
    27c6:	movdqu XMMWORD PTR [r12+0x120],xmm3
    27d0:	mov    r13,r15
    27d3:	add    r13,0x10
    27d7:	movdqu XMMWORD PTR [r15],xmm4
    27dc:	mov    r14d,0x0
    27e2:	mov    DWORD PTR [r12+0x32c],r14d
    27ea:	movdqu XMMWORD PTR [r13+0x0],xmm2
    27f0:	add    r15,0x20
    27f4:	mov    r13,r15
    27f7:	add    r13,0x10
    27fb:	movdqu XMMWORD PTR [r15],xmm5
    2800:	movdqu XMMWORD PTR [r13+0x0],xmm3
    2806:	mov    rcx,QWORD PTR [r12+0x380]
    280e:	jrcxz  0x2815
    2810:	jmp    0x9bad
    2815:	cmp    BYTE PTR [rsp+0x8],0x0
    281a:	jne    0xae5
    2820:	jmp    0x2825
    2825:	mov    r13d,DWORD PTR [r12+0x48]
    282a:	add    r13d,0x1
    282e:	mov    QWORD PTR [r12+0x48],r13
    2833:	sub    r13d,0x1f4
    283a:	mov    rcx,QWORD PTR [r12+0x380]
    2842:	jrcxz  0x2849
    2844:	jmp    0x9c32
    2849:	jne    0xac7
    284f:	mov    r11,rax
    2852:	lahf
    2853:	seto   al
    2856:	mov    WORD PTR [rsp],ax
    285a:	mov    rax,r11
    285d:	jmp    0x2862
    2862:	mov    r13d,0x430000
    2868:	mov    QWORD PTR [r12+0x40],r13
    286d:	mov    r13d,0x0
    2873:	mov    QWORD PTR [r12+0x48],r13
    2878:	mov    r13d,0x430cc0
    287e:	mov    r14,QWORD PTR [r13+0x0]
    2882:	mov    r13d,0x0
    2888:	mov    QWORD PTR [r12+0x110],r14
    2890:	mov    QWORD PTR [r12+0x118],r13
    2898:	jmp    0x289d
    289d:	mov    r13,QWORD PTR [r12+0x48]
    28a2:	mov    r14,QWORD PTR [r12+0x50]
    28a7:	add    r14,r13
    28aa:	movdqu xmm2,XMMWORD PTR [r14]
    28af:	movdqu XMMWORD PTR [r12+0x120],xmm2
    28b9:	add    r13,0x10
    28bd:	mov    QWORD PTR [r12+0x48],r13
    28c2:	sub    r13,0x200
    28c9:	mov    r13,QWORD PTR [r12+0x128]
    28d1:	mov    r14d,0x0
    28d7:	mov    QWORD PTR [r12+0x130],r13
    28df:	mov    QWORD PTR [r12+0x138],r14
    28e7:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    28f1:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    28fb:	movdqa xmm0,xmm2
    28ff:	movdqa xmm1,xmm3
    2903:	movq   xmm0,xmm0
    2907:	movq   xmm1,xmm1
    290b:	addsd  xmm0,xmm1
    290f:	movdqa xmm14,xmm0
    2914:	movdqu xmm15,XMMWORD PTR [rip+0x7bc3]        # 0xa4e0
    291d:	pand   xmm14,xmm15
    2922:	movdqu xmm15,XMMWORD PTR [rip+0x7bc5]        # 0xa4f0
    292b:	pcmpeqq xmm14,xmm15
    2931:	movdqa xmm15,xmm0
    2936:	cmpunordpd xmm15,xmm0
    293c:	por    xmm14,xmm15
    2941:	pmovmskb ecx,xmm14
    2946:	jrcxz  0x294d
    2948:	jmp    0x364c
    294d:	movdqa xmm4,xmm0
    2951:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    295b:	movdqa xmm0,xmm4
    295f:	movdqa xmm1,xmm2
    2963:	movq   xmm0,xmm0
    2967:	movq   xmm1,xmm1
    296b:	addsd  xmm0,xmm1
    296f:	movdqa xmm14,xmm0
    2974:	movdqu xmm15,XMMWORD PTR [rip+0x7b63]        # 0xa4e0
    297d:	pand   xmm14,xmm15
    2982:	movdqu xmm15,XMMWORD PTR [rip+0x7b65]        # 0xa4f0
    298b:	pcmpeqq xmm14,xmm15
    2991:	movdqa xmm15,xmm0
    2996:	cmpunordpd xmm15,xmm0
    299c:	por    xmm14,xmm15
    29a1:	pmovmskb ecx,xmm14
    29a6:	jrcxz  0x29ad
    29a8:	jmp    0x368b
    29ad:	movdqa xmm3,xmm0
    29b1:	movdqu XMMWORD PTR [r12+0x110],xmm3
    29bb:	mov    rcx,QWORD PTR [r12+0x380]
    29c3:	jrcxz  0x29ca
    29c5:	jmp    0x9cc6
    29ca:	jne    0x29e3
    29d0:	mov    r11,rax
    29d3:	lahf
    29d4:	seto   al
    29d7:	mov    WORD PTR [rsp],ax
    29db:	mov    rax,r11
    29de:	jmp    0x29f6
    29e3:	mov    r11,rax
    29e6:	lahf
    29e7:	seto   al
    29ea:	mov    WORD PTR [rsp],ax
    29ee:	mov    rax,r11
    29f1:	jmp    0x289d
    29f6:	mov    r13,QWORD PTR [r12+0xf8]
    29fe:	mov    r14,r13
    2a01:	add    r14,0x1d0
    2a08:	mov    r15,r14
    2a0b:	add    r15,0x8
    2a0f:	mov    rbp,QWORD PTR [r14]
    2a12:	mov    r14,QWORD PTR [r15]
    2a15:	mov    QWORD PTR [r12+0xa0],rbp
    2a1d:	mov    QWORD PTR [r12+0x98],r14
    2a25:	mov    r14,QWORD PTR [r12+0x40]
    2a2a:	add    r14,0xcc0
    2a31:	mov    r15,QWORD PTR [r12+0x110]
    2a39:	mov    QWORD PTR [r14],r15
    2a3c:	mov    r14d,0x0
    2a42:	mov    DWORD PTR [r12+0x32c],r14d
    2a4a:	mov    r14,r13
    2a4d:	add    r14,0x1c0
    2a54:	mov    r15,r14
    2a57:	add    r15,0x8
    2a5b:	mov    rbp,QWORD PTR [r14]
    2a5e:	mov    r14,QWORD PTR [r15]
    2a61:	mov    QWORD PTR [r12+0xe8],rbp
    2a69:	mov    QWORD PTR [r12+0xf0],r14
    2a71:	mov    r14,r13
    2a74:	add    r14,0x1b0
    2a7b:	mov    r15,r14
    2a7e:	add    r15,0x8
    2a82:	mov    rbp,QWORD PTR [r14]
    2a85:	mov    r14,QWORD PTR [r15]
    2a88:	mov    r15d,0x0
    2a8e:	mov    QWORD PTR [r12+0x1a0],rbp
    2a96:	mov    QWORD PTR [r12+0x1a8],r15
    2a9e:	mov    r15d,0x0
    2aa4:	mov    QWORD PTR [r12+0x190],r14
    2aac:	mov    QWORD PTR [r12+0x198],r15
    2ab4:	mov    r14,r13
    2ab7:	add    r14,0x1a0
    2abe:	mov    r15,r14
    2ac1:	add    r15,0x8
    2ac5:	mov    rbp,QWORD PTR [r14]
    2ac8:	mov    r14,QWORD PTR [r15]
    2acb:	mov    r15d,0x0
    2ad1:	mov    QWORD PTR [r12+0x1c0],rbp
    2ad9:	mov    QWORD PTR [r12+0x1c8],r15
    2ae1:	mov    r15d,0x0
    2ae7:	mov    QWORD PTR [r12+0x1b0],r14
    2aef:	mov    QWORD PTR [r12+0x1b8],r15
    2af7:	mov    r14,r13
    2afa:	add    r14,0x190
    2b01:	mov    r15,r14
    2b04:	add    r15,0x8
    2b08:	mov    rbp,QWORD PTR [r14]
    2b0b:	mov    r14,QWORD PTR [r15]
    2b0e:	mov    r15d,0x0
    2b14:	mov    QWORD PTR [r12+0x1e0],rbp
    2b1c:	mov    QWORD PTR [r12+0x1e8],r15
    2b24:	mov    r15d,0x0
    2b2a:	mov    QWORD PTR [r12+0x1d0],r14
    2b32:	mov    QWORD PTR [r12+0x1d8],r15
    2b3a:	mov    r14,r13
    2b3d:	add    r14,0x180
    2b44:	mov    r15,r14
    2b47:	add    r15,0x8
    2b4b:	mov    rbp,QWORD PTR [r14]
    2b4e:	mov    r14,QWORD PTR [r15]
    2b51:	mov    r15d,0x0
    2b57:	mov    QWORD PTR [r12+0x200],rbp
    2b5f:	mov    QWORD PTR [r12+0x208],r15
    2b67:	mov    r15d,0x0
    2b6d:	mov    QWORD PTR [r12+0x1f0],r14
    2b75:	mov    QWORD PTR [r12+0x1f8],r15
    2b7d:	add    r13,0x1e0
    2b84:	mov    QWORD PTR [r12+0xf8],r13
    2b8c:	mov    rcx,QWORD PTR [r12+0x380]
    2b94:	jrcxz  0x2b9b
    2b96:	jmp    0x9d5a
    2b9b:	mov    r13,QWORD PTR [r12+0xf0]
    2ba3:	mov    QWORD PTR [r12+0x100],r13
    2bab:	mov    r11,QWORD PTR [rsp]
    2baf:	mov    QWORD PTR [r12+0x398],r11
    2bb7:	mov    rdi,QWORD PTR [r12+0x100]
    2bbf:	add    rsp,0x150
    2bc6:	movabs r11,0x590d8528f940
    2bd0:	jmp    r11
    2bd3:	mov    r13d,DWORD PTR [r12+0x98]
    2bdb:	mov    r14d,DWORD PTR [r12]
    2bdf:	add    r14d,r13d
    2be2:	mov    QWORD PTR [r12],r14
    2be6:	mov    r13d,0x4103f8
    2bec:	mov    QWORD PTR [r12+0xf0],r13
    2bf4:	mov    r13d,0x4109a4
    2bfa:	mov    QWORD PTR [r12+0x100],r13
    2c02:	mov    r11,QWORD PTR [rsp]
    2c06:	mov    QWORD PTR [r12+0x398],r11
    2c0e:	mov    edi,0x4109a4
    2c13:	mov    QWORD PTR [r12+0x100],rdi
    2c1b:	add    rsp,0x150
    2c22:	nop    WORD PTR [rax+rax*1+0x0]
    2c28:	jmp    QWORD PTR [rip+0x2]        # 0x2c30
    2c2e:	xchg   ax,ax
    2c30:	rex (bad)
    2c32:	xor    BYTE PTR [rax+rcx*1+0x7b],ch
    2c36:	add    BYTE PTR [rax],al
    2c38:	mov    al,0x4d
    2c3a:	xor    BYTE PTR [rax+rcx*1+0x7b],ch
    2c3e:	add    BYTE PTR [rax],al
    2c40:	movabs r11,0x590d8528f940
    2c4a:	jmp    r11
    2c4d:	movdqa xmm0,xmm2
    2c51:	movdqa xmm1,xmm3
    2c55:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2c5e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2c67:	call   0x36d0
    2c6c:	jmp    0x5dc
    2c71:	movdqa xmm0,xmm2
    2c75:	movdqa xmm1,xmm3
    2c79:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2c82:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2c8b:	call   0x36d0
    2c90:	jmp    0x668
    2c95:	movdqa xmm0,xmm9
    2c9a:	movdqa xmm1,xmm2
    2c9e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2ca7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2cb0:	call   0x37a0
    2cb5:	jmp    0xd03
    2cba:	movdqa xmm0,xmm8
    2cbf:	movdqa xmm1,xmm2
    2cc3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2ccc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2cd5:	call   0x38b0
    2cda:	jmp    0xd62
    2cdf:	movdqa xmm0,xmm9
    2ce4:	movdqa xmm1,xmm7
    2ce8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2cf1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2cfa:	call   0x39d0
    2cff:	jmp    0xdd7
    2d04:	movdqa xmm0,xmm9
    2d09:	movdqa xmm1,xmm6
    2d0d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2d16:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2d1f:	call   0x3af0
    2d24:	jmp    0xe27
    2d29:	movdqa xmm0,xmm9
    2d2e:	movdqa xmm1,xmm6
    2d32:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2d3b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2d44:	call   0x3c10
    2d49:	jmp    0xe80
    2d4e:	movdqa xmm0,xmm9
    2d53:	movdqa xmm1,xmm2
    2d57:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2d60:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2d69:	call   0x3d40
    2d6e:	jmp    0xf21
    2d73:	mov    r11,rax
    2d76:	lahf
    2d77:	seto   al
    2d7a:	mov    WORD PTR [rsp],ax
    2d7e:	mov    rax,r11
    2d81:	movdqa xmm0,xmm10
    2d86:	movdqa xmm1,xmm9
    2d8b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2d94:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2d9d:	call   0x3e80
    2da2:	mov    r11,rax
    2da5:	movzx  eax,WORD PTR [rsp]
    2da9:	add    al,0x7f
    2dab:	sahf
    2dac:	mov    rax,r11
    2daf:	jmp    0xf8c
    2db4:	mov    r11,rax
    2db7:	lahf
    2db8:	seto   al
    2dbb:	mov    WORD PTR [rsp],ax
    2dbf:	mov    rax,r11
    2dc2:	movdqa xmm0,xmm8
    2dc7:	movdqa xmm1,xmm10
    2dcc:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2dd5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2dde:	call   0x3e80
    2de3:	mov    r11,rax
    2de6:	movzx  eax,WORD PTR [rsp]
    2dea:	add    al,0x7f
    2dec:	sahf
    2ded:	mov    rax,r11
    2df0:	jmp    0xfec
    2df5:	mov    r11,rax
    2df8:	lahf
    2df9:	seto   al
    2dfc:	mov    WORD PTR [rsp],ax
    2e00:	mov    rax,r11
    2e03:	movdqa xmm0,xmm7
    2e07:	movdqa xmm1,xmm10
    2e0c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2e15:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2e1e:	call   0x4050
    2e23:	mov    r11,rax
    2e26:	movzx  eax,WORD PTR [rsp]
    2e2a:	add    al,0x7f
    2e2c:	sahf
    2e2d:	mov    rax,r11
    2e30:	jmp    0x1045
    2e35:	movdqa xmm0,xmm12
    2e3a:	movdqa xmm1,xmm9
    2e3f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2e48:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2e51:	call   0x4210
    2e56:	jmp    0x11bd
    2e5b:	movdqa xmm0,xmm6
    2e5f:	movdqa xmm1,xmm4
    2e63:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2e6c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2e75:	call   0x4410
    2e7a:	jmp    0x122b
    2e7f:	movdqa xmm0,xmm8
    2e84:	movdqa xmm1,xmm11
    2e89:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2e92:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2e9b:	call   0x4600
    2ea0:	jmp    0x1286
    2ea5:	movdqa xmm0,xmm5
    2ea9:	movdqa xmm1,xmm2
    2ead:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2eb6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2ebf:	call   0x47f0
    2ec4:	jmp    0x12e3
    2ec9:	movdqa xmm0,xmm9
    2ece:	movdqa xmm1,xmm5
    2ed2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2edb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2ee4:	call   0x49c0
    2ee9:	jmp    0x134b
    2eee:	movdqa xmm0,xmm13
    2ef3:	movdqa xmm1,xmm2
    2ef7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2f00:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2f09:	call   0x4ba0
    2f0e:	jmp    0x13c4
    2f13:	movdqa xmm0,xmm9
    2f18:	movdqa xmm1,xmm5
    2f1c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2f25:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2f2e:	call   0x4d90
    2f33:	jmp    0x1451
    2f38:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    2f42:	movdqa xmm1,xmm6
    2f46:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2f4f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2f58:	call   0x4f50
    2f5d:	jmp    0x1546
    2f62:	movdqa xmm0,xmm9
    2f67:	movdqa xmm1,xmm5
    2f6b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2f74:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2f7d:	call   0x5130
    2f82:	jmp    0x15a4
    2f87:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    2f91:	movdqa xmm1,xmm11
    2f96:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2f9f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2fa8:	call   0x5310
    2fad:	jmp    0x161d
    2fb2:	movdqa xmm0,xmm12
    2fb7:	movdqa xmm1,xmm8
    2fbc:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2fc5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2fce:	call   0x5500
    2fd3:	jmp    0x1678
    2fd8:	movdqa xmm0,xmm9
    2fdd:	movdqa xmm1,xmm5
    2fe1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2fea:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2ff3:	call   0x56f0
    2ff8:	jmp    0x16f9
    2ffd:	movdqa xmm0,xmm4
    3001:	movdqa xmm1,xmm2
    3005:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    300e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3017:	call   0x58d0
    301c:	jmp    0x176c
    3021:	movdqa xmm0,xmm13
    3026:	movdqa xmm1,xmm2
    302a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3033:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    303c:	call   0x5ab0
    3041:	jmp    0x17d5
    3046:	movdqa xmm0,xmm5
    304a:	movdqa xmm1,xmm2
    304e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3057:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3060:	call   0x5c90
    3065:	jmp    0x184d
    306a:	movdqa xmm0,xmm3
    306e:	movdqa xmm1,xmm6
    3072:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    307b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3084:	call   0x5e70
    3089:	jmp    0x18c0
    308e:	movdqa xmm0,xmm5
    3092:	movdqa xmm1,xmm2
    3096:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    309f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    30a8:	call   0x6060
    30ad:	jmp    0x1962
    30b2:	movdqa xmm0,xmm10
    30b7:	movdqa xmm1,xmm12
    30bc:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    30c5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    30ce:	call   0x6250
    30d3:	jmp    0x19d3
    30d8:	movdqa xmm0,xmm7
    30dc:	movdqa xmm1,xmm2
    30e0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    30e9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    30f2:	call   0x6450
    30f7:	jmp    0x1a26
    30fc:	movdqa xmm0,xmm11
    3101:	movdqa xmm1,xmm13
    3106:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    310f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3118:	call   0x6630
    311d:	jmp    0x1a77
    3122:	movdqa xmm0,xmm5
    3126:	movdqa xmm1,xmm7
    312a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3133:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    313c:	call   0x6810
    3141:	jmp    0x1ad4
    3146:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    3150:	movdqa xmm1,xmm7
    3154:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    315d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3166:	call   0x69e0
    316b:	jmp    0x1b2e
    3170:	movdqa xmm0,xmm8
    3175:	movdqa xmm1,xmm4
    3179:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3182:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    318b:	call   0x6bb0
    3190:	jmp    0x1b7d
    3195:	movdqa xmm0,xmm9
    319a:	movdqa xmm1,xmm6
    319e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    31a7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    31b0:	call   0x6d90
    31b5:	jmp    0x1bd7
    31ba:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    31c4:	movdqa xmm1,xmm7
    31c8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    31d1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    31da:	call   0x6f60
    31df:	jmp    0x1c3a
    31e4:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    31ee:	movdqa xmm1,xmm7
    31f2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    31fb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3204:	call   0x7120
    3209:	jmp    0x1c93
    320e:	movdqa xmm0,xmm3
    3212:	movdqa xmm1,xmm10
    3217:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3220:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3229:	call   0x72f0
    322e:	jmp    0x1ced
    3233:	movdqa xmm0,xmm2
    3237:	movdqa xmm1,xmm11
    323c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3245:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    324e:	call   0x74c0
    3253:	jmp    0x1d46
    3258:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    3262:	movdqa xmm1,xmm2
    3266:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    326f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3278:	call   0x7680
    327d:	jmp    0x1db3
    3282:	movdqa xmm0,xmm4
    3286:	movdqa xmm1,xmm5
    328a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3293:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    329c:	call   0x7830
    32a1:	jmp    0x1e0c
    32a6:	movdqa xmm0,xmm12
    32ab:	movdqa xmm1,xmm6
    32af:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    32b8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    32c1:	call   0x7a00
    32c6:	jmp    0x1e66
    32cb:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    32d5:	movdqa xmm1,xmm2
    32d9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    32e2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    32eb:	call   0x6810
    32f0:	jmp    0x1f46
    32f5:	movdqa xmm0,xmm7
    32f9:	movdqa xmm1,xmm8
    32fe:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3307:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3310:	call   0x6bb0
    3315:	jmp    0x1f96
    331a:	movdqa xmm0,xmm3
    331e:	movdqa xmm1,xmm9
    3323:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    332c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3335:	call   0x7bc0
    333a:	jmp    0x1fe6
    333f:	movdqa xmm0,xmm6
    3343:	movdqa xmm1,xmm2
    3347:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3350:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3359:	call   0x7d90
    335e:	jmp    0x2043
    3363:	movdqa xmm0,xmm6
    3367:	movdqa xmm1,xmm2
    336b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3374:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    337d:	call   0x7120
    3382:	jmp    0x20aa
    3387:	movdqa xmm0,xmm5
    338b:	movdqa xmm1,xmm2
    338f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3398:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    33a1:	call   0x7f50
    33a6:	jmp    0x2108
    33ab:	movdqa xmm0,xmm10
    33b0:	movdqa xmm1,xmm11
    33b5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    33be:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    33c7:	call   0x8120
    33cc:	jmp    0x2162
    33d1:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    33db:	movdqa xmm1,xmm2
    33df:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    33e8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    33f1:	call   0x7680
    33f6:	jmp    0x21c5
    33fb:	movdqa xmm0,xmm4
    33ff:	movdqa xmm1,xmm3
    3403:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    340c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3415:	call   0x7830
    341a:	jmp    0x221e
    341f:	movdqa xmm0,xmm3
    3423:	movdqa xmm1,xmm2
    3427:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3430:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3439:	call   0x82f0
    343e:	jmp    0x2286
    3443:	movdqa xmm0,xmm12
    3448:	movdqa xmm1,xmm8
    344d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3456:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    345f:	call   0x84c0
    3464:	jmp    0x22e0
    3469:	movdqa xmm0,xmm8
    346e:	movdqa xmm1,xmm2
    3472:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    347b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3484:	call   0x6810
    3489:	jmp    0x2348
    348e:	movdqa xmm0,xmm7
    3492:	movdqa xmm1,xmm6
    3496:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    349f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    34a8:	call   0x8690
    34ad:	jmp    0x23a1
    34b2:	movdqa xmm0,xmm5
    34b6:	movdqa xmm1,xmm9
    34bb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    34c4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    34cd:	call   0x8850
    34d2:	jmp    0x2411
    34d7:	movdqa xmm0,xmm6
    34db:	movdqa xmm1,xmm5
    34df:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    34e8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    34f1:	call   0x8a10
    34f6:	jmp    0x2478
    34fb:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    3505:	movdqa xmm1,xmm5
    3509:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3512:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    351b:	call   0x8bc0
    3520:	jmp    0x24dc
    3525:	movdqa xmm0,xmm10
    352a:	movdqa xmm1,xmm4
    352e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3537:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3540:	call   0x8d80
    3545:	jmp    0x2535
    354a:	movdqa xmm0,xmm3
    354e:	movdqa xmm1,xmm11
    3553:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    355c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3565:	call   0x6bb0
    356a:	jmp    0x25ab
    356f:	movdqa xmm0,xmm10
    3574:	movdqa xmm1,xmm5
    3578:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3581:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    358a:	call   0x8f50
    358f:	jmp    0x260a
    3594:	movdqa xmm0,xmm4
    3598:	movdqa xmm1,xmm5
    359c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    35a5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    35ae:	call   0x9120
    35b3:	jmp    0x2667
    35b8:	movdqa xmm0,xmm2
    35bc:	movdqa xmm1,xmm8
    35c1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    35ca:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    35d3:	call   0x7a00
    35d8:	jmp    0x26b7
    35dd:	movdqa xmm0,xmm7
    35e1:	movdqa xmm1,xmm6
    35e5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    35ee:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    35f7:	call   0x92f0
    35fc:	jmp    0x270f
    3601:	movdqa xmm0,xmm9
    3606:	movdqa xmm1,xmm3
    360a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3613:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    361c:	call   0x94a0
    3621:	jmp    0x2768
    3626:	movdqa xmm0,xmm12
    362b:	movdqa xmm1,xmm10
    3630:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3639:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3642:	call   0x9640
    3647:	jmp    0x27c2
    364c:	mov    r11,rax
    364f:	lahf
    3650:	seto   al
    3653:	mov    WORD PTR [rsp],ax
    3657:	mov    rax,r11
    365a:	movdqa xmm0,xmm2
    365e:	movdqa xmm1,xmm3
    3662:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    366b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3674:	call   0x97d0
    3679:	mov    r11,rax
    367c:	movzx  eax,WORD PTR [rsp]
    3680:	add    al,0x7f
    3682:	sahf
    3683:	mov    rax,r11
    3686:	jmp    0x294d
    368b:	mov    r11,rax
    368e:	lahf
    368f:	seto   al
    3692:	mov    WORD PTR [rsp],ax
    3696:	mov    rax,r11
    3699:	movdqa xmm0,xmm4
    369d:	movdqa xmm1,xmm2
    36a1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    36aa:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    36b3:	call   0x9930
    36b8:	mov    r11,rax
    36bb:	movzx  eax,WORD PTR [rsp]
    36bf:	add    al,0x7f
    36c1:	sahf
    36c2:	mov    rax,r11
    36c5:	jmp    0x29ad
    36ca:	nop    WORD PTR [rax+rax*1+0x0]
    36d0:	sub    rsp,0x8
    36d4:	mov    QWORD PTR [r12+0x378],0x3
    36e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    36e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    36ec:	mov    QWORD PTR [r12+0x108],rbx
    36f4:	stmxcsr DWORD PTR [r12-0x28]
    36fa:	mov    r10d,DWORD PTR [r12-0x28]
    36ff:	test   r10d,0x3f
    3706:	je     0x372b
    370c:	mov    r11d,r10d
    370f:	shr    r10d,1
    3712:	and    r10d,0x1e
    3716:	and    r11d,0x1
    371a:	or     r10d,r11d
    371d:	or     DWORD PTR [r12+0x314],r10d
    3725:	and    DWORD PTR [r12-0x28],0xffffffc0
    372b:	ldmxcsr DWORD PTR [r12-0x38]
    3731:	lea    rdi,[rsp+0x110]
    3739:	lea    rsi,[rsp+0xf0]
    3741:	lea    rdx,[rsp+0x100]
    3749:	mov    ecx,0x16
    374e:	mov    r8d,0x0
    3754:	lea    r9,[r12+0x314]
    375c:	movabs r11,0x590d850f6650
    3766:	call   r11
    3769:	ldmxcsr DWORD PTR [r12-0x28]
    376f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3775:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    377b:	mov    rbx,QWORD PTR [r12+0x108]
    3783:	mov    QWORD PTR [r12+0x378],0x2
    378f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3798:	add    rsp,0x8
    379c:	ret
    379d:	nop    DWORD PTR [rax]
    37a0:	sub    rsp,0x8
    37a4:	mov    QWORD PTR [r12+0x378],0x3
    37b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    37b6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    37bc:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    37c2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    37cc:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    37d6:	mov    QWORD PTR [r12+0x108],rbx
    37de:	stmxcsr DWORD PTR [r12-0x28]
    37e4:	mov    r10d,DWORD PTR [r12-0x28]
    37e9:	test   r10d,0x3f
    37f0:	je     0x3815
    37f6:	mov    r11d,r10d
    37f9:	shr    r10d,1
    37fc:	and    r10d,0x1e
    3800:	and    r11d,0x1
    3804:	or     r10d,r11d
    3807:	or     DWORD PTR [r12+0x314],r10d
    380f:	and    DWORD PTR [r12-0x28],0xffffffc0
    3815:	ldmxcsr DWORD PTR [r12-0x38]
    381b:	lea    rdi,[rsp+0x110]
    3823:	lea    rsi,[rsp+0xf0]
    382b:	lea    rdx,[rsp+0x100]
    3833:	mov    ecx,0x16
    3838:	mov    r8d,0x0
    383e:	lea    r9,[r12+0x314]
    3846:	movabs r11,0x590d850f6650
    3850:	call   r11
    3853:	ldmxcsr DWORD PTR [r12-0x28]
    3859:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    385f:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    3865:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    386b:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    3875:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    387f:	mov    rbx,QWORD PTR [r12+0x108]
    3887:	mov    QWORD PTR [r12+0x378],0x2
    3893:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    389c:	add    rsp,0x8
    38a0:	ret
    38a1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    38b0:	sub    rsp,0x8
    38b4:	mov    QWORD PTR [r12+0x378],0x3
    38c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    38c6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    38cc:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    38d2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    38dc:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    38e6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    38f0:	mov    QWORD PTR [r12+0x108],rbx
    38f8:	stmxcsr DWORD PTR [r12-0x28]
    38fe:	mov    r10d,DWORD PTR [r12-0x28]
    3903:	test   r10d,0x3f
    390a:	je     0x392f
    3910:	mov    r11d,r10d
    3913:	shr    r10d,1
    3916:	and    r10d,0x1e
    391a:	and    r11d,0x1
    391e:	or     r10d,r11d
    3921:	or     DWORD PTR [r12+0x314],r10d
    3929:	and    DWORD PTR [r12-0x28],0xffffffc0
    392f:	ldmxcsr DWORD PTR [r12-0x38]
    3935:	lea    rdi,[rsp+0x110]
    393d:	lea    rsi,[rsp+0xf0]
    3945:	lea    rdx,[rsp+0x100]
    394d:	mov    ecx,0x56
    3952:	mov    r8d,0x0
    3958:	lea    r9,[r12+0x314]
    3960:	movabs r11,0x590d850f6650
    396a:	call   r11
    396d:	ldmxcsr DWORD PTR [r12-0x28]
    3973:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3979:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    397f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    3985:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    398f:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3999:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    39a3:	mov    rbx,QWORD PTR [r12+0x108]
    39ab:	mov    QWORD PTR [r12+0x378],0x2
    39b7:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    39c0:	add    rsp,0x8
    39c4:	ret
    39c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    39d0:	sub    rsp,0x8
    39d4:	mov    QWORD PTR [r12+0x378],0x3
    39e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    39e6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    39ec:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    39f2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    39fc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    3a06:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    3a10:	mov    QWORD PTR [r12+0x108],rbx
    3a18:	stmxcsr DWORD PTR [r12-0x28]
    3a1e:	mov    r10d,DWORD PTR [r12-0x28]
    3a23:	test   r10d,0x3f
    3a2a:	je     0x3a4f
    3a30:	mov    r11d,r10d
    3a33:	shr    r10d,1
    3a36:	and    r10d,0x1e
    3a3a:	and    r11d,0x1
    3a3e:	or     r10d,r11d
    3a41:	or     DWORD PTR [r12+0x314],r10d
    3a49:	and    DWORD PTR [r12-0x28],0xffffffc0
    3a4f:	ldmxcsr DWORD PTR [r12-0x38]
    3a55:	lea    rdi,[rsp+0x110]
    3a5d:	lea    rsi,[rsp+0xf0]
    3a65:	lea    rdx,[rsp+0x100]
    3a6d:	mov    ecx,0x16
    3a72:	mov    r8d,0x0
    3a78:	lea    r9,[r12+0x314]
    3a80:	movabs r11,0x590d850f6650
    3a8a:	call   r11
    3a8d:	ldmxcsr DWORD PTR [r12-0x28]
    3a93:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3a99:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    3a9f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    3aa5:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3aaf:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3ab9:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    3ac3:	mov    rbx,QWORD PTR [r12+0x108]
    3acb:	mov    QWORD PTR [r12+0x378],0x2
    3ad7:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3ae0:	add    rsp,0x8
    3ae4:	ret
    3ae5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    3af0:	sub    rsp,0x8
    3af4:	mov    QWORD PTR [r12+0x378],0x3
    3b00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3b06:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    3b0c:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    3b16:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    3b20:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    3b2a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    3b34:	mov    QWORD PTR [r12+0x108],rbx
    3b3c:	stmxcsr DWORD PTR [r12-0x28]
    3b42:	mov    r10d,DWORD PTR [r12-0x28]
    3b47:	test   r10d,0x3f
    3b4e:	je     0x3b73
    3b54:	mov    r11d,r10d
    3b57:	shr    r10d,1
    3b5a:	and    r10d,0x1e
    3b5e:	and    r11d,0x1
    3b62:	or     r10d,r11d
    3b65:	or     DWORD PTR [r12+0x314],r10d
    3b6d:	and    DWORD PTR [r12-0x28],0xffffffc0
    3b73:	ldmxcsr DWORD PTR [r12-0x38]
    3b79:	lea    rdi,[rsp+0x110]
    3b81:	lea    rsi,[rsp+0xf0]
    3b89:	lea    rdx,[rsp+0x100]
    3b91:	mov    ecx,0x16
    3b96:	mov    r8d,0x0
    3b9c:	lea    r9,[r12+0x314]
    3ba4:	movabs r11,0x590d850f6650
    3bae:	call   r11
    3bb1:	ldmxcsr DWORD PTR [r12-0x28]
    3bb7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3bbd:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    3bc3:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    3bcd:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3bd7:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3be1:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    3beb:	mov    rbx,QWORD PTR [r12+0x108]
    3bf3:	mov    QWORD PTR [r12+0x378],0x2
    3bff:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3c08:	add    rsp,0x8
    3c0c:	ret
    3c0d:	nop    DWORD PTR [rax]
    3c10:	sub    rsp,0x8
    3c14:	mov    QWORD PTR [r12+0x378],0x3
    3c20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3c26:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    3c2c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    3c32:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    3c3c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    3c46:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    3c50:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    3c5a:	mov    QWORD PTR [r12+0x108],rbx
    3c62:	stmxcsr DWORD PTR [r12-0x28]
    3c68:	mov    r10d,DWORD PTR [r12-0x28]
    3c6d:	test   r10d,0x3f
    3c74:	je     0x3c99
    3c7a:	mov    r11d,r10d
    3c7d:	shr    r10d,1
    3c80:	and    r10d,0x1e
    3c84:	and    r11d,0x1
    3c88:	or     r10d,r11d
    3c8b:	or     DWORD PTR [r12+0x314],r10d
    3c93:	and    DWORD PTR [r12-0x28],0xffffffc0
    3c99:	ldmxcsr DWORD PTR [r12-0x38]
    3c9f:	lea    rdi,[rsp+0x110]
    3ca7:	lea    rsi,[rsp+0xf0]
    3caf:	lea    rdx,[rsp+0x100]
    3cb7:	mov    ecx,0x16
    3cbc:	mov    r8d,0x0
    3cc2:	lea    r9,[r12+0x314]
    3cca:	movabs r11,0x590d850f6650
    3cd4:	call   r11
    3cd7:	ldmxcsr DWORD PTR [r12-0x28]
    3cdd:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3ce3:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    3ce9:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    3cef:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    3cf9:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3d03:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3d0d:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    3d17:	mov    rbx,QWORD PTR [r12+0x108]
    3d1f:	mov    QWORD PTR [r12+0x378],0x2
    3d2b:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3d34:	add    rsp,0x8
    3d38:	ret
    3d39:	nop    DWORD PTR [rax+0x0]
    3d40:	sub    rsp,0x8
    3d44:	mov    QWORD PTR [r12+0x378],0x3
    3d50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3d56:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    3d5c:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    3d66:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    3d70:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    3d7a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    3d84:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    3d8e:	mov    QWORD PTR [r12+0x108],rbx
    3d96:	stmxcsr DWORD PTR [r12-0x28]
    3d9c:	mov    r10d,DWORD PTR [r12-0x28]
    3da1:	test   r10d,0x3f
    3da8:	je     0x3dcd
    3dae:	mov    r11d,r10d
    3db1:	shr    r10d,1
    3db4:	and    r10d,0x1e
    3db8:	and    r11d,0x1
    3dbc:	or     r10d,r11d
    3dbf:	or     DWORD PTR [r12+0x314],r10d
    3dc7:	and    DWORD PTR [r12-0x28],0xffffffc0
    3dcd:	ldmxcsr DWORD PTR [r12-0x38]
    3dd3:	lea    rdi,[rsp+0x110]
    3ddb:	lea    rsi,[rsp+0xf0]
    3de3:	lea    rdx,[rsp+0x100]
    3deb:	mov    ecx,0x56
    3df0:	mov    r8d,0x0
    3df6:	lea    r9,[r12+0x314]
    3dfe:	movabs r11,0x590d850f6650
    3e08:	call   r11
    3e0b:	ldmxcsr DWORD PTR [r12-0x28]
    3e11:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3e17:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    3e1d:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    3e27:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3e31:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3e3b:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    3e45:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    3e4f:	mov    rbx,QWORD PTR [r12+0x108]
    3e57:	mov    QWORD PTR [r12+0x378],0x2
    3e63:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3e6c:	add    rsp,0x8
    3e70:	ret
    3e71:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    3e80:	sub    rsp,0x8
    3e84:	mov    QWORD PTR [r12+0x378],0x3
    3e90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3e96:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    3e9c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    3ea2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    3eac:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    3eb6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    3ec0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    3eca:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    3ed4:	push   rdx
    3ed5:	push   rsi
    3ed6:	push   r10
    3ed8:	push   r11
    3eda:	mov    rdx,QWORD PTR [rsp+0x30]
    3edf:	mov    r10d,edx
    3ee2:	and    r10d,0xc000
    3ee9:	shl    r10d,0x10
    3eed:	mov    r11d,edx
    3ef0:	and    r11d,0x100
    3ef7:	shl    r11d,0x15
    3efb:	or     r10d,r11d
    3efe:	and    edx,0x1
    3f01:	shl    edx,0x1c
    3f04:	or     r10d,edx
    3f07:	btc    r10,0x1d
    3f0c:	mov    r11d,0xf0000000
    3f12:	and    r11,r10
    3f15:	movabs rsi,0xffffffff0fffffff
    3f1f:	and    rbx,rsi
    3f22:	or     rbx,r11
    3f25:	pop    r11
    3f27:	pop    r10
    3f29:	pop    rsi
    3f2a:	pop    rdx
    3f2b:	mov    QWORD PTR [r12+0x108],rbx
    3f33:	stmxcsr DWORD PTR [r12-0x28]
    3f39:	mov    r10d,DWORD PTR [r12-0x28]
    3f3e:	test   r10d,0x3f
    3f45:	je     0x3f6a
    3f4b:	mov    r11d,r10d
    3f4e:	shr    r10d,1
    3f51:	and    r10d,0x1e
    3f55:	and    r11d,0x1
    3f59:	or     r10d,r11d
    3f5c:	or     DWORD PTR [r12+0x314],r10d
    3f64:	and    DWORD PTR [r12-0x28],0xffffffc0
    3f6a:	ldmxcsr DWORD PTR [r12-0x38]
    3f70:	lea    rdi,[rsp+0x110]
    3f78:	lea    rsi,[rsp+0xf0]
    3f80:	lea    rdx,[rsp+0x100]
    3f88:	mov    ecx,0x14
    3f8d:	mov    r8d,0x0
    3f93:	lea    r9,[r12+0x314]
    3f9b:	movabs r11,0x590d850f6650
    3fa5:	call   r11
    3fa8:	ldmxcsr DWORD PTR [r12-0x28]
    3fae:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3fb4:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    3fba:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    3fc0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    3fca:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3fd4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3fde:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    3fe8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    3ff2:	mov    rbx,QWORD PTR [r12+0x108]
    3ffa:	mov    QWORD PTR [r12+0x378],0x2
    4006:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    400f:	mov    rdx,rbx
    4012:	shr    rdx,0x10
    4016:	and    edx,0xc000
    401c:	mov    rax,rbx
    401f:	shr    rax,0x15
    4023:	and    eax,0x100
    4028:	xor    eax,0x100
    402d:	or     edx,eax
    402f:	mov    rax,rbx
    4032:	shr    rax,0x1c
    4036:	and    eax,0x1
    4039:	or     edx,eax
    403b:	mov    QWORD PTR [rsp+0x10],rdx
    4040:	add    rsp,0x8
    4044:	ret
    4045:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    4050:	sub    rsp,0x8
    4054:	mov    QWORD PTR [r12+0x378],0x3
    4060:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4066:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    406c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    4072:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4078:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4082:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    408c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    4096:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    40a0:	push   rdx
    40a1:	push   rsi
    40a2:	push   r10
    40a4:	push   r11
    40a6:	mov    rdx,QWORD PTR [rsp+0x30]
    40ab:	mov    r10d,edx
    40ae:	and    r10d,0xc000
    40b5:	shl    r10d,0x10
    40b9:	mov    r11d,edx
    40bc:	and    r11d,0x100
    40c3:	shl    r11d,0x15
    40c7:	or     r10d,r11d
    40ca:	and    edx,0x1
    40cd:	shl    edx,0x1c
    40d0:	or     r10d,edx
    40d3:	btc    r10,0x1d
    40d8:	mov    r11d,0xf0000000
    40de:	and    r11,r10
    40e1:	movabs rsi,0xffffffff0fffffff
    40eb:	and    rbx,rsi
    40ee:	or     rbx,r11
    40f1:	pop    r11
    40f3:	pop    r10
    40f5:	pop    rsi
    40f6:	pop    rdx
    40f7:	mov    QWORD PTR [r12+0x108],rbx
    40ff:	stmxcsr DWORD PTR [r12-0x28]
    4105:	mov    r10d,DWORD PTR [r12-0x28]
    410a:	test   r10d,0x3f
    4111:	je     0x4136
    4117:	mov    r11d,r10d
    411a:	shr    r10d,1
    411d:	and    r10d,0x1e
    4121:	and    r11d,0x1
    4125:	or     r10d,r11d
    4128:	or     DWORD PTR [r12+0x314],r10d
    4130:	and    DWORD PTR [r12-0x28],0xffffffc0
    4136:	ldmxcsr DWORD PTR [r12-0x38]
    413c:	lea    rdi,[rsp+0x110]
    4144:	lea    rsi,[rsp+0xf0]
    414c:	lea    rdx,[rsp+0x100]
    4154:	mov    ecx,0x14
    4159:	mov    r8d,0x0
    415f:	lea    r9,[r12+0x314]
    4167:	movabs r11,0x590d850f6650
    4171:	call   r11
    4174:	ldmxcsr DWORD PTR [r12-0x28]
    417a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4180:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4186:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    418c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4192:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    419c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    41a6:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    41b0:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    41ba:	mov    rbx,QWORD PTR [r12+0x108]
    41c2:	mov    QWORD PTR [r12+0x378],0x2
    41ce:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    41d7:	mov    rdx,rbx
    41da:	shr    rdx,0x10
    41de:	and    edx,0xc000
    41e4:	mov    rax,rbx
    41e7:	shr    rax,0x15
    41eb:	and    eax,0x100
    41f0:	xor    eax,0x100
    41f5:	or     edx,eax
    41f7:	mov    rax,rbx
    41fa:	shr    rax,0x1c
    41fe:	and    eax,0x1
    4201:	or     edx,eax
    4203:	mov    QWORD PTR [rsp+0x10],rdx
    4208:	add    rsp,0x8
    420c:	ret
    420d:	nop    DWORD PTR [rax]
    4210:	sub    rsp,0x8
    4214:	mov    QWORD PTR [r12+0x378],0x3
    4220:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4226:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    422c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    4232:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4238:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    423e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4244:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    424e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4258:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    4262:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    426c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    4276:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4280:	push   rdx
    4281:	push   rsi
    4282:	push   r10
    4284:	push   r11
    4286:	mov    rdx,QWORD PTR [rsp+0x30]
    428b:	mov    r10d,edx
    428e:	and    r10d,0xc000
    4295:	shl    r10d,0x10
    4299:	mov    r11d,edx
    429c:	and    r11d,0x100
    42a3:	shl    r11d,0x15
    42a7:	or     r10d,r11d
    42aa:	and    edx,0x1
    42ad:	shl    edx,0x1c
    42b0:	or     r10d,edx
    42b3:	btc    r10,0x1d
    42b8:	mov    r11d,0xf0000000
    42be:	and    r11,r10
    42c1:	movabs rsi,0xffffffff0fffffff
    42cb:	and    rbx,rsi
    42ce:	or     rbx,r11
    42d1:	pop    r11
    42d3:	pop    r10
    42d5:	pop    rsi
    42d6:	pop    rdx
    42d7:	mov    QWORD PTR [r12+0x108],rbx
    42df:	stmxcsr DWORD PTR [r12-0x28]
    42e5:	mov    r10d,DWORD PTR [r12-0x28]
    42ea:	test   r10d,0x3f
    42f1:	je     0x4316
    42f7:	mov    r11d,r10d
    42fa:	shr    r10d,1
    42fd:	and    r10d,0x1e
    4301:	and    r11d,0x1
    4305:	or     r10d,r11d
    4308:	or     DWORD PTR [r12+0x314],r10d
    4310:	and    DWORD PTR [r12-0x28],0xffffffc0
    4316:	ldmxcsr DWORD PTR [r12-0x38]
    431c:	lea    rdi,[rsp+0x110]
    4324:	lea    rsi,[rsp+0xf0]
    432c:	lea    rdx,[rsp+0x100]
    4334:	mov    ecx,0x14
    4339:	mov    r8d,0x0
    433f:	lea    r9,[r12+0x314]
    4347:	movabs r11,0x590d850f6650
    4351:	call   r11
    4354:	ldmxcsr DWORD PTR [r12-0x28]
    435a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4360:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    4366:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    436c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4372:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    4378:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    437e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    4388:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4392:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    439c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    43a6:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    43b0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    43ba:	mov    rbx,QWORD PTR [r12+0x108]
    43c2:	mov    QWORD PTR [r12+0x378],0x2
    43ce:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    43d7:	mov    rdx,rbx
    43da:	shr    rdx,0x10
    43de:	and    edx,0xc000
    43e4:	mov    rax,rbx
    43e7:	shr    rax,0x15
    43eb:	and    eax,0x100
    43f0:	xor    eax,0x100
    43f5:	or     edx,eax
    43f7:	mov    rax,rbx
    43fa:	shr    rax,0x1c
    43fe:	and    eax,0x1
    4401:	or     edx,eax
    4403:	mov    QWORD PTR [rsp+0x10],rdx
    4408:	add    rsp,0x8
    440c:	ret
    440d:	nop    DWORD PTR [rax]
    4410:	sub    rsp,0x8
    4414:	mov    QWORD PTR [r12+0x378],0x3
    4420:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4426:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    442c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    4432:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4438:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    443e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4444:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    444e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4458:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    4462:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    446c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4476:	push   rdx
    4477:	push   rsi
    4478:	push   r10
    447a:	push   r11
    447c:	mov    rdx,QWORD PTR [rsp+0x30]
    4481:	mov    r10d,edx
    4484:	and    r10d,0xc000
    448b:	shl    r10d,0x10
    448f:	mov    r11d,edx
    4492:	and    r11d,0x100
    4499:	shl    r11d,0x15
    449d:	or     r10d,r11d
    44a0:	and    edx,0x1
    44a3:	shl    edx,0x1c
    44a6:	or     r10d,edx
    44a9:	btc    r10,0x1d
    44ae:	mov    r11d,0xf0000000
    44b4:	and    r11,r10
    44b7:	movabs rsi,0xffffffff0fffffff
    44c1:	and    rbx,rsi
    44c4:	or     rbx,r11
    44c7:	pop    r11
    44c9:	pop    r10
    44cb:	pop    rsi
    44cc:	pop    rdx
    44cd:	mov    QWORD PTR [r12+0x108],rbx
    44d5:	stmxcsr DWORD PTR [r12-0x28]
    44db:	mov    r10d,DWORD PTR [r12-0x28]
    44e0:	test   r10d,0x3f
    44e7:	je     0x450c
    44ed:	mov    r11d,r10d
    44f0:	shr    r10d,1
    44f3:	and    r10d,0x1e
    44f7:	and    r11d,0x1
    44fb:	or     r10d,r11d
    44fe:	or     DWORD PTR [r12+0x314],r10d
    4506:	and    DWORD PTR [r12-0x28],0xffffffc0
    450c:	ldmxcsr DWORD PTR [r12-0x38]
    4512:	lea    rdi,[rsp+0x110]
    451a:	lea    rsi,[rsp+0xf0]
    4522:	lea    rdx,[rsp+0x100]
    452a:	mov    ecx,0x14
    452f:	mov    r8d,0x0
    4535:	lea    r9,[r12+0x314]
    453d:	movabs r11,0x590d850f6650
    4547:	call   r11
    454a:	ldmxcsr DWORD PTR [r12-0x28]
    4550:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4556:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    455c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4562:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4568:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    456e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4574:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    457e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4588:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    4592:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    459c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    45a6:	mov    rbx,QWORD PTR [r12+0x108]
    45ae:	mov    QWORD PTR [r12+0x378],0x2
    45ba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    45c3:	mov    rdx,rbx
    45c6:	shr    rdx,0x10
    45ca:	and    edx,0xc000
    45d0:	mov    rax,rbx
    45d3:	shr    rax,0x15
    45d7:	and    eax,0x100
    45dc:	xor    eax,0x100
    45e1:	or     edx,eax
    45e3:	mov    rax,rbx
    45e6:	shr    rax,0x1c
    45ea:	and    eax,0x1
    45ed:	or     edx,eax
    45ef:	mov    QWORD PTR [rsp+0x10],rdx
    45f4:	add    rsp,0x8
    45f8:	ret
    45f9:	nop    DWORD PTR [rax+0x0]
    4600:	sub    rsp,0x8
    4604:	mov    QWORD PTR [r12+0x378],0x3
    4610:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4616:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    461c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4622:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4628:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    4632:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    463c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    4646:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    4650:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    465a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4664:	push   rdx
    4665:	push   rsi
    4666:	push   r10
    4668:	push   r11
    466a:	mov    rdx,QWORD PTR [rsp+0x30]
    466f:	mov    r10d,edx
    4672:	and    r10d,0xc000
    4679:	shl    r10d,0x10
    467d:	mov    r11d,edx
    4680:	and    r11d,0x100
    4687:	shl    r11d,0x15
    468b:	or     r10d,r11d
    468e:	and    edx,0x1
    4691:	shl    edx,0x1c
    4694:	or     r10d,edx
    4697:	btc    r10,0x1d
    469c:	mov    r11d,0xf0000000
    46a2:	and    r11,r10
    46a5:	movabs rsi,0xffffffff0fffffff
    46af:	and    rbx,rsi
    46b2:	or     rbx,r11
    46b5:	pop    r11
    46b7:	pop    r10
    46b9:	pop    rsi
    46ba:	pop    rdx
    46bb:	mov    QWORD PTR [r12+0x108],rbx
    46c3:	stmxcsr DWORD PTR [r12-0x28]
    46c9:	mov    r10d,DWORD PTR [r12-0x28]
    46ce:	test   r10d,0x3f
    46d5:	je     0x46fa
    46db:	mov    r11d,r10d
    46de:	shr    r10d,1
    46e1:	and    r10d,0x1e
    46e5:	and    r11d,0x1
    46e9:	or     r10d,r11d
    46ec:	or     DWORD PTR [r12+0x314],r10d
    46f4:	and    DWORD PTR [r12-0x28],0xffffffc0
    46fa:	ldmxcsr DWORD PTR [r12-0x38]
    4700:	lea    rdi,[rsp+0x110]
    4708:	lea    rsi,[rsp+0xf0]
    4710:	lea    rdx,[rsp+0x100]
    4718:	mov    ecx,0x14
    471d:	mov    r8d,0x0
    4723:	lea    r9,[r12+0x314]
    472b:	movabs r11,0x590d850f6650
    4735:	call   r11
    4738:	ldmxcsr DWORD PTR [r12-0x28]
    473e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4744:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    474a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4750:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4756:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    4760:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    476a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    4774:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    477e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    4788:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    4792:	mov    rbx,QWORD PTR [r12+0x108]
    479a:	mov    QWORD PTR [r12+0x378],0x2
    47a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    47af:	mov    rdx,rbx
    47b2:	shr    rdx,0x10
    47b6:	and    edx,0xc000
    47bc:	mov    rax,rbx
    47bf:	shr    rax,0x15
    47c3:	and    eax,0x100
    47c8:	xor    eax,0x100
    47cd:	or     edx,eax
    47cf:	mov    rax,rbx
    47d2:	shr    rax,0x1c
    47d6:	and    eax,0x1
    47d9:	or     edx,eax
    47db:	mov    QWORD PTR [rsp+0x10],rdx
    47e0:	add    rsp,0x8
    47e4:	ret
    47e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    47f0:	sub    rsp,0x8
    47f4:	mov    QWORD PTR [r12+0x378],0x3
    4800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    480c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    4812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4818:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    481e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4828:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    4832:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    483c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4846:	push   rdx
    4847:	push   rsi
    4848:	push   r10
    484a:	push   r11
    484c:	mov    rdx,QWORD PTR [rsp+0x30]
    4851:	mov    r10d,edx
    4854:	and    r10d,0xc000
    485b:	shl    r10d,0x10
    485f:	mov    r11d,edx
    4862:	and    r11d,0x100
    4869:	shl    r11d,0x15
    486d:	or     r10d,r11d
    4870:	and    edx,0x1
    4873:	shl    edx,0x1c
    4876:	or     r10d,edx
    4879:	btc    r10,0x1d
    487e:	mov    r11d,0xf0000000
    4884:	and    r11,r10
    4887:	movabs rsi,0xffffffff0fffffff
    4891:	and    rbx,rsi
    4894:	or     rbx,r11
    4897:	pop    r11
    4899:	pop    r10
    489b:	pop    rsi
    489c:	pop    rdx
    489d:	mov    QWORD PTR [r12+0x108],rbx
    48a5:	stmxcsr DWORD PTR [r12-0x28]
    48ab:	mov    r10d,DWORD PTR [r12-0x28]
    48b0:	test   r10d,0x3f
    48b7:	je     0x48dc
    48bd:	mov    r11d,r10d
    48c0:	shr    r10d,1
    48c3:	and    r10d,0x1e
    48c7:	and    r11d,0x1
    48cb:	or     r10d,r11d
    48ce:	or     DWORD PTR [r12+0x314],r10d
    48d6:	and    DWORD PTR [r12-0x28],0xffffffc0
    48dc:	ldmxcsr DWORD PTR [r12-0x38]
    48e2:	lea    rdi,[rsp+0x110]
    48ea:	lea    rsi,[rsp+0xf0]
    48f2:	lea    rdx,[rsp+0x100]
    48fa:	mov    ecx,0x56
    48ff:	mov    r8d,0x0
    4905:	lea    r9,[r12+0x314]
    490d:	movabs r11,0x590d850f6650
    4917:	call   r11
    491a:	ldmxcsr DWORD PTR [r12-0x28]
    4920:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4926:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    492c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4932:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4938:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    493e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4948:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    4952:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    495c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    4966:	mov    rbx,QWORD PTR [r12+0x108]
    496e:	mov    QWORD PTR [r12+0x378],0x2
    497a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4983:	mov    rdx,rbx
    4986:	shr    rdx,0x10
    498a:	and    edx,0xc000
    4990:	mov    rax,rbx
    4993:	shr    rax,0x15
    4997:	and    eax,0x100
    499c:	xor    eax,0x100
    49a1:	or     edx,eax
    49a3:	mov    rax,rbx
    49a6:	shr    rax,0x1c
    49aa:	and    eax,0x1
    49ad:	or     edx,eax
    49af:	mov    QWORD PTR [rsp+0x10],rdx
    49b4:	add    rsp,0x8
    49b8:	ret
    49b9:	nop    DWORD PTR [rax+0x0]
    49c0:	sub    rsp,0x8
    49c4:	mov    QWORD PTR [r12+0x378],0x3
    49d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    49d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    49dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    49e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    49e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    49ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    49f4:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    49fe:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    4a08:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    4a12:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4a1c:	push   rdx
    4a1d:	push   rsi
    4a1e:	push   r10
    4a20:	push   r11
    4a22:	mov    rdx,QWORD PTR [rsp+0x30]
    4a27:	mov    r10d,edx
    4a2a:	and    r10d,0xc000
    4a31:	shl    r10d,0x10
    4a35:	mov    r11d,edx
    4a38:	and    r11d,0x100
    4a3f:	shl    r11d,0x15
    4a43:	or     r10d,r11d
    4a46:	and    edx,0x1
    4a49:	shl    edx,0x1c
    4a4c:	or     r10d,edx
    4a4f:	btc    r10,0x1d
    4a54:	mov    r11d,0xf0000000
    4a5a:	and    r11,r10
    4a5d:	movabs rsi,0xffffffff0fffffff
    4a67:	and    rbx,rsi
    4a6a:	or     rbx,r11
    4a6d:	pop    r11
    4a6f:	pop    r10
    4a71:	pop    rsi
    4a72:	pop    rdx
    4a73:	mov    QWORD PTR [r12+0x108],rbx
    4a7b:	stmxcsr DWORD PTR [r12-0x28]
    4a81:	mov    r10d,DWORD PTR [r12-0x28]
    4a86:	test   r10d,0x3f
    4a8d:	je     0x4ab2
    4a93:	mov    r11d,r10d
    4a96:	shr    r10d,1
    4a99:	and    r10d,0x1e
    4a9d:	and    r11d,0x1
    4aa1:	or     r10d,r11d
    4aa4:	or     DWORD PTR [r12+0x314],r10d
    4aac:	and    DWORD PTR [r12-0x28],0xffffffc0
    4ab2:	ldmxcsr DWORD PTR [r12-0x38]
    4ab8:	lea    rdi,[rsp+0x110]
    4ac0:	lea    rsi,[rsp+0xf0]
    4ac8:	lea    rdx,[rsp+0x100]
    4ad0:	mov    ecx,0x56
    4ad5:	mov    r8d,0x0
    4adb:	lea    r9,[r12+0x314]
    4ae3:	movabs r11,0x590d850f6650
    4aed:	call   r11
    4af0:	ldmxcsr DWORD PTR [r12-0x28]
    4af6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4afc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    4b02:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4b08:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4b0e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    4b14:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4b1a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4b24:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    4b2e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    4b38:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    4b42:	mov    rbx,QWORD PTR [r12+0x108]
    4b4a:	mov    QWORD PTR [r12+0x378],0x2
    4b56:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4b5f:	mov    rdx,rbx
    4b62:	shr    rdx,0x10
    4b66:	and    edx,0xc000
    4b6c:	mov    rax,rbx
    4b6f:	shr    rax,0x15
    4b73:	and    eax,0x100
    4b78:	xor    eax,0x100
    4b7d:	or     edx,eax
    4b7f:	mov    rax,rbx
    4b82:	shr    rax,0x1c
    4b86:	and    eax,0x1
    4b89:	or     edx,eax
    4b8b:	mov    QWORD PTR [rsp+0x10],rdx
    4b90:	add    rsp,0x8
    4b94:	ret
    4b95:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    4ba0:	sub    rsp,0x8
    4ba4:	mov    QWORD PTR [r12+0x378],0x3
    4bb0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4bb6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    4bbc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    4bc2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4bc8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    4bce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4bd4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    4bde:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4be8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    4bf2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    4bfc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4c06:	push   rdx
    4c07:	push   rsi
    4c08:	push   r10
    4c0a:	push   r11
    4c0c:	mov    rdx,QWORD PTR [rsp+0x30]
    4c11:	mov    r10d,edx
    4c14:	and    r10d,0xc000
    4c1b:	shl    r10d,0x10
    4c1f:	mov    r11d,edx
    4c22:	and    r11d,0x100
    4c29:	shl    r11d,0x15
    4c2d:	or     r10d,r11d
    4c30:	and    edx,0x1
    4c33:	shl    edx,0x1c
    4c36:	or     r10d,edx
    4c39:	btc    r10,0x1d
    4c3e:	mov    r11d,0xf0000000
    4c44:	and    r11,r10
    4c47:	movabs rsi,0xffffffff0fffffff
    4c51:	and    rbx,rsi
    4c54:	or     rbx,r11
    4c57:	pop    r11
    4c59:	pop    r10
    4c5b:	pop    rsi
    4c5c:	pop    rdx
    4c5d:	mov    QWORD PTR [r12+0x108],rbx
    4c65:	stmxcsr DWORD PTR [r12-0x28]
    4c6b:	mov    r10d,DWORD PTR [r12-0x28]
    4c70:	test   r10d,0x3f
    4c77:	je     0x4c9c
    4c7d:	mov    r11d,r10d
    4c80:	shr    r10d,1
    4c83:	and    r10d,0x1e
    4c87:	and    r11d,0x1
    4c8b:	or     r10d,r11d
    4c8e:	or     DWORD PTR [r12+0x314],r10d
    4c96:	and    DWORD PTR [r12-0x28],0xffffffc0
    4c9c:	ldmxcsr DWORD PTR [r12-0x38]
    4ca2:	lea    rdi,[rsp+0x110]
    4caa:	lea    rsi,[rsp+0xf0]
    4cb2:	lea    rdx,[rsp+0x100]
    4cba:	mov    ecx,0x56
    4cbf:	mov    r8d,0x0
    4cc5:	lea    r9,[r12+0x314]
    4ccd:	movabs r11,0x590d850f6650
    4cd7:	call   r11
    4cda:	ldmxcsr DWORD PTR [r12-0x28]
    4ce0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4ce6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    4cec:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4cf2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4cf8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    4cfe:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4d04:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    4d0e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4d18:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    4d22:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    4d2c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    4d36:	mov    rbx,QWORD PTR [r12+0x108]
    4d3e:	mov    QWORD PTR [r12+0x378],0x2
    4d4a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4d53:	mov    rdx,rbx
    4d56:	shr    rdx,0x10
    4d5a:	and    edx,0xc000
    4d60:	mov    rax,rbx
    4d63:	shr    rax,0x15
    4d67:	and    eax,0x100
    4d6c:	xor    eax,0x100
    4d71:	or     edx,eax
    4d73:	mov    rax,rbx
    4d76:	shr    rax,0x1c
    4d7a:	and    eax,0x1
    4d7d:	or     edx,eax
    4d7f:	mov    QWORD PTR [rsp+0x10],rdx
    4d84:	add    rsp,0x8
    4d88:	ret
    4d89:	nop    DWORD PTR [rax+0x0]
    4d90:	sub    rsp,0x8
    4d94:	mov    QWORD PTR [r12+0x378],0x3
    4da0:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    4da6:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4dac:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    4db2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4db8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    4dc2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4dcc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    4dd6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    4de0:	push   rdx
    4de1:	push   rsi
    4de2:	push   r10
    4de4:	push   r11
    4de6:	mov    rdx,QWORD PTR [rsp+0x30]
    4deb:	mov    r10d,edx
    4dee:	and    r10d,0xc000
    4df5:	shl    r10d,0x10
    4df9:	mov    r11d,edx
    4dfc:	and    r11d,0x100
    4e03:	shl    r11d,0x15
    4e07:	or     r10d,r11d
    4e0a:	and    edx,0x1
    4e0d:	shl    edx,0x1c
    4e10:	or     r10d,edx
    4e13:	btc    r10,0x1d
    4e18:	mov    r11d,0xf0000000
    4e1e:	and    r11,r10
    4e21:	movabs rsi,0xffffffff0fffffff
    4e2b:	and    rbx,rsi
    4e2e:	or     rbx,r11
    4e31:	pop    r11
    4e33:	pop    r10
    4e35:	pop    rsi
    4e36:	pop    rdx
    4e37:	mov    QWORD PTR [r12+0x108],rbx
    4e3f:	stmxcsr DWORD PTR [r12-0x28]
    4e45:	mov    r10d,DWORD PTR [r12-0x28]
    4e4a:	test   r10d,0x3f
    4e51:	je     0x4e76
    4e57:	mov    r11d,r10d
    4e5a:	shr    r10d,1
    4e5d:	and    r10d,0x1e
    4e61:	and    r11d,0x1
    4e65:	or     r10d,r11d
    4e68:	or     DWORD PTR [r12+0x314],r10d
    4e70:	and    DWORD PTR [r12-0x28],0xffffffc0
    4e76:	ldmxcsr DWORD PTR [r12-0x38]
    4e7c:	lea    rdi,[rsp+0x110]
    4e84:	lea    rsi,[rsp+0xf0]
    4e8c:	lea    rdx,[rsp+0x100]
    4e94:	mov    ecx,0x56
    4e99:	mov    r8d,0x0
    4e9f:	lea    r9,[r12+0x314]
    4ea7:	movabs r11,0x590d850f6650
    4eb1:	call   r11
    4eb4:	ldmxcsr DWORD PTR [r12-0x28]
    4eba:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4ec0:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4ec6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    4ecc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4ed2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    4edc:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4ee6:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    4ef0:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    4efa:	mov    rbx,QWORD PTR [r12+0x108]
    4f02:	mov    QWORD PTR [r12+0x378],0x2
    4f0e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4f17:	mov    rdx,rbx
    4f1a:	shr    rdx,0x10
    4f1e:	and    edx,0xc000
    4f24:	mov    rax,rbx
    4f27:	shr    rax,0x15
    4f2b:	and    eax,0x100
    4f30:	xor    eax,0x100
    4f35:	or     edx,eax
    4f37:	mov    rax,rbx
    4f3a:	shr    rax,0x1c
    4f3e:	and    eax,0x1
    4f41:	or     edx,eax
    4f43:	mov    QWORD PTR [rsp+0x10],rdx
    4f48:	add    rsp,0x8
    4f4c:	ret
    4f4d:	nop    DWORD PTR [rax]
    4f50:	sub    rsp,0x8
    4f54:	mov    QWORD PTR [r12+0x378],0x3
    4f60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4f66:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    4f6c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4f72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    4f78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4f7e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    4f88:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4f92:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    4f9c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    4fa6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4fb0:	push   rdx
    4fb1:	push   rsi
    4fb2:	push   r10
    4fb4:	push   r11
    4fb6:	mov    rdx,QWORD PTR [rsp+0x30]
    4fbb:	mov    r10d,edx
    4fbe:	and    r10d,0xc000
    4fc5:	shl    r10d,0x10
    4fc9:	mov    r11d,edx
    4fcc:	and    r11d,0x100
    4fd3:	shl    r11d,0x15
    4fd7:	or     r10d,r11d
    4fda:	and    edx,0x1
    4fdd:	shl    edx,0x1c
    4fe0:	or     r10d,edx
    4fe3:	btc    r10,0x1d
    4fe8:	mov    r11d,0xf0000000
    4fee:	and    r11,r10
    4ff1:	movabs rsi,0xffffffff0fffffff
    4ffb:	and    rbx,rsi
    4ffe:	or     rbx,r11
    5001:	pop    r11
    5003:	pop    r10
    5005:	pop    rsi
    5006:	pop    rdx
    5007:	mov    QWORD PTR [r12+0x108],rbx
    500f:	stmxcsr DWORD PTR [r12-0x28]
    5015:	mov    r10d,DWORD PTR [r12-0x28]
    501a:	test   r10d,0x3f
    5021:	je     0x5046
    5027:	mov    r11d,r10d
    502a:	shr    r10d,1
    502d:	and    r10d,0x1e
    5031:	and    r11d,0x1
    5035:	or     r10d,r11d
    5038:	or     DWORD PTR [r12+0x314],r10d
    5040:	and    DWORD PTR [r12-0x28],0xffffffc0
    5046:	ldmxcsr DWORD PTR [r12-0x38]
    504c:	lea    rdi,[rsp+0x110]
    5054:	lea    rsi,[rsp+0xf0]
    505c:	lea    rdx,[rsp+0x100]
    5064:	mov    ecx,0x14
    5069:	mov    r8d,0x0
    506f:	lea    r9,[r12+0x314]
    5077:	movabs r11,0x590d850f6650
    5081:	call   r11
    5084:	ldmxcsr DWORD PTR [r12-0x28]
    508a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5090:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5096:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    509c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    50a2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    50a8:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    50b2:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    50bc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    50c6:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    50d0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    50da:	mov    rbx,QWORD PTR [r12+0x108]
    50e2:	mov    QWORD PTR [r12+0x378],0x2
    50ee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    50f7:	mov    rdx,rbx
    50fa:	shr    rdx,0x10
    50fe:	and    edx,0xc000
    5104:	mov    rax,rbx
    5107:	shr    rax,0x15
    510b:	and    eax,0x100
    5110:	xor    eax,0x100
    5115:	or     edx,eax
    5117:	mov    rax,rbx
    511a:	shr    rax,0x1c
    511e:	and    eax,0x1
    5121:	or     edx,eax
    5123:	mov    QWORD PTR [rsp+0x10],rdx
    5128:	add    rsp,0x8
    512c:	ret
    512d:	nop    DWORD PTR [rax]
    5130:	sub    rsp,0x8
    5134:	mov    QWORD PTR [r12+0x378],0x3
    5140:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5146:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    514c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5152:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5158:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    515e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    5168:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    5172:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    517c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    5186:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    5190:	push   rdx
    5191:	push   rsi
    5192:	push   r10
    5194:	push   r11
    5196:	mov    rdx,QWORD PTR [rsp+0x30]
    519b:	mov    r10d,edx
    519e:	and    r10d,0xc000
    51a5:	shl    r10d,0x10
    51a9:	mov    r11d,edx
    51ac:	and    r11d,0x100
    51b3:	shl    r11d,0x15
    51b7:	or     r10d,r11d
    51ba:	and    edx,0x1
    51bd:	shl    edx,0x1c
    51c0:	or     r10d,edx
    51c3:	btc    r10,0x1d
    51c8:	mov    r11d,0xf0000000
    51ce:	and    r11,r10
    51d1:	movabs rsi,0xffffffff0fffffff
    51db:	and    rbx,rsi
    51de:	or     rbx,r11
    51e1:	pop    r11
    51e3:	pop    r10
    51e5:	pop    rsi
    51e6:	pop    rdx
    51e7:	mov    QWORD PTR [r12+0x108],rbx
    51ef:	stmxcsr DWORD PTR [r12-0x28]
    51f5:	mov    r10d,DWORD PTR [r12-0x28]
    51fa:	test   r10d,0x3f
    5201:	je     0x5226
    5207:	mov    r11d,r10d
    520a:	shr    r10d,1
    520d:	and    r10d,0x1e
    5211:	and    r11d,0x1
    5215:	or     r10d,r11d
    5218:	or     DWORD PTR [r12+0x314],r10d
    5220:	and    DWORD PTR [r12-0x28],0xffffffc0
    5226:	ldmxcsr DWORD PTR [r12-0x38]
    522c:	lea    rdi,[rsp+0x110]
    5234:	lea    rsi,[rsp+0xf0]
    523c:	lea    rdx,[rsp+0x100]
    5244:	mov    ecx,0x56
    5249:	mov    r8d,0x0
    524f:	lea    r9,[r12+0x314]
    5257:	movabs r11,0x590d850f6650
    5261:	call   r11
    5264:	ldmxcsr DWORD PTR [r12-0x28]
    526a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5270:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5276:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    527c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5282:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5288:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    5292:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    529c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    52a6:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    52b0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    52ba:	mov    rbx,QWORD PTR [r12+0x108]
    52c2:	mov    QWORD PTR [r12+0x378],0x2
    52ce:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    52d7:	mov    rdx,rbx
    52da:	shr    rdx,0x10
    52de:	and    edx,0xc000
    52e4:	mov    rax,rbx
    52e7:	shr    rax,0x15
    52eb:	and    eax,0x100
    52f0:	xor    eax,0x100
    52f5:	or     edx,eax
    52f7:	mov    rax,rbx
    52fa:	shr    rax,0x1c
    52fe:	and    eax,0x1
    5301:	or     edx,eax
    5303:	mov    QWORD PTR [rsp+0x10],rdx
    5308:	add    rsp,0x8
    530c:	ret
    530d:	nop    DWORD PTR [rax]
    5310:	sub    rsp,0x8
    5314:	mov    QWORD PTR [r12+0x378],0x3
    5320:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5326:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    532c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5332:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5338:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    533e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    5344:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    534e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    5358:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    5362:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    536c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    5376:	push   rdx
    5377:	push   rsi
    5378:	push   r10
    537a:	push   r11
    537c:	mov    rdx,QWORD PTR [rsp+0x30]
    5381:	mov    r10d,edx
    5384:	and    r10d,0xc000
    538b:	shl    r10d,0x10
    538f:	mov    r11d,edx
    5392:	and    r11d,0x100
    5399:	shl    r11d,0x15
    539d:	or     r10d,r11d
    53a0:	and    edx,0x1
    53a3:	shl    edx,0x1c
    53a6:	or     r10d,edx
    53a9:	btc    r10,0x1d
    53ae:	mov    r11d,0xf0000000
    53b4:	and    r11,r10
    53b7:	movabs rsi,0xffffffff0fffffff
    53c1:	and    rbx,rsi
    53c4:	or     rbx,r11
    53c7:	pop    r11
    53c9:	pop    r10
    53cb:	pop    rsi
    53cc:	pop    rdx
    53cd:	mov    QWORD PTR [r12+0x108],rbx
    53d5:	stmxcsr DWORD PTR [r12-0x28]
    53db:	mov    r10d,DWORD PTR [r12-0x28]
    53e0:	test   r10d,0x3f
    53e7:	je     0x540c
    53ed:	mov    r11d,r10d
    53f0:	shr    r10d,1
    53f3:	and    r10d,0x1e
    53f7:	and    r11d,0x1
    53fb:	or     r10d,r11d
    53fe:	or     DWORD PTR [r12+0x314],r10d
    5406:	and    DWORD PTR [r12-0x28],0xffffffc0
    540c:	ldmxcsr DWORD PTR [r12-0x38]
    5412:	lea    rdi,[rsp+0x110]
    541a:	lea    rsi,[rsp+0xf0]
    5422:	lea    rdx,[rsp+0x100]
    542a:	mov    ecx,0x14
    542f:	mov    r8d,0x0
    5435:	lea    r9,[r12+0x314]
    543d:	movabs r11,0x590d850f6650
    5447:	call   r11
    544a:	ldmxcsr DWORD PTR [r12-0x28]
    5450:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5456:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    545c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5462:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5468:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    546e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5474:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    547e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5488:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5492:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    549c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    54a6:	mov    rbx,QWORD PTR [r12+0x108]
    54ae:	mov    QWORD PTR [r12+0x378],0x2
    54ba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    54c3:	mov    rdx,rbx
    54c6:	shr    rdx,0x10
    54ca:	and    edx,0xc000
    54d0:	mov    rax,rbx
    54d3:	shr    rax,0x15
    54d7:	and    eax,0x100
    54dc:	xor    eax,0x100
    54e1:	or     edx,eax
    54e3:	mov    rax,rbx
    54e6:	shr    rax,0x1c
    54ea:	and    eax,0x1
    54ed:	or     edx,eax
    54ef:	mov    QWORD PTR [rsp+0x10],rdx
    54f4:	add    rsp,0x8
    54f8:	ret
    54f9:	nop    DWORD PTR [rax+0x0]
    5500:	sub    rsp,0x8
    5504:	mov    QWORD PTR [r12+0x378],0x3
    5510:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5516:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    551c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5522:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5528:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    552e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    5534:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    553e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    5548:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    5552:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    555c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    5566:	push   rdx
    5567:	push   rsi
    5568:	push   r10
    556a:	push   r11
    556c:	mov    rdx,QWORD PTR [rsp+0x30]
    5571:	mov    r10d,edx
    5574:	and    r10d,0xc000
    557b:	shl    r10d,0x10
    557f:	mov    r11d,edx
    5582:	and    r11d,0x100
    5589:	shl    r11d,0x15
    558d:	or     r10d,r11d
    5590:	and    edx,0x1
    5593:	shl    edx,0x1c
    5596:	or     r10d,edx
    5599:	btc    r10,0x1d
    559e:	mov    r11d,0xf0000000
    55a4:	and    r11,r10
    55a7:	movabs rsi,0xffffffff0fffffff
    55b1:	and    rbx,rsi
    55b4:	or     rbx,r11
    55b7:	pop    r11
    55b9:	pop    r10
    55bb:	pop    rsi
    55bc:	pop    rdx
    55bd:	mov    QWORD PTR [r12+0x108],rbx
    55c5:	stmxcsr DWORD PTR [r12-0x28]
    55cb:	mov    r10d,DWORD PTR [r12-0x28]
    55d0:	test   r10d,0x3f
    55d7:	je     0x55fc
    55dd:	mov    r11d,r10d
    55e0:	shr    r10d,1
    55e3:	and    r10d,0x1e
    55e7:	and    r11d,0x1
    55eb:	or     r10d,r11d
    55ee:	or     DWORD PTR [r12+0x314],r10d
    55f6:	and    DWORD PTR [r12-0x28],0xffffffc0
    55fc:	ldmxcsr DWORD PTR [r12-0x38]
    5602:	lea    rdi,[rsp+0x110]
    560a:	lea    rsi,[rsp+0xf0]
    5612:	lea    rdx,[rsp+0x100]
    561a:	mov    ecx,0x14
    561f:	mov    r8d,0x0
    5625:	lea    r9,[r12+0x314]
    562d:	movabs r11,0x590d850f6650
    5637:	call   r11
    563a:	ldmxcsr DWORD PTR [r12-0x28]
    5640:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5646:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    564c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5652:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5658:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    565e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5664:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    566e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5678:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    5682:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    568c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    5696:	mov    rbx,QWORD PTR [r12+0x108]
    569e:	mov    QWORD PTR [r12+0x378],0x2
    56aa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    56b3:	mov    rdx,rbx
    56b6:	shr    rdx,0x10
    56ba:	and    edx,0xc000
    56c0:	mov    rax,rbx
    56c3:	shr    rax,0x15
    56c7:	and    eax,0x100
    56cc:	xor    eax,0x100
    56d1:	or     edx,eax
    56d3:	mov    rax,rbx
    56d6:	shr    rax,0x1c
    56da:	and    eax,0x1
    56dd:	or     edx,eax
    56df:	mov    QWORD PTR [rsp+0x10],rdx
    56e4:	add    rsp,0x8
    56e8:	ret
    56e9:	nop    DWORD PTR [rax+0x0]
    56f0:	sub    rsp,0x8
    56f4:	mov    QWORD PTR [r12+0x378],0x3
    5700:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5706:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    570c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5712:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5718:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    571e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    5724:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    572e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    5738:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    5742:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    574c:	push   rdx
    574d:	push   rsi
    574e:	push   r10
    5750:	push   r11
    5752:	mov    rdx,QWORD PTR [rsp+0x30]
    5757:	mov    r10d,edx
    575a:	and    r10d,0xc000
    5761:	shl    r10d,0x10
    5765:	mov    r11d,edx
    5768:	and    r11d,0x100
    576f:	shl    r11d,0x15
    5773:	or     r10d,r11d
    5776:	and    edx,0x1
    5779:	shl    edx,0x1c
    577c:	or     r10d,edx
    577f:	btc    r10,0x1d
    5784:	mov    r11d,0xf0000000
    578a:	and    r11,r10
    578d:	movabs rsi,0xffffffff0fffffff
    5797:	and    rbx,rsi
    579a:	or     rbx,r11
    579d:	pop    r11
    579f:	pop    r10
    57a1:	pop    rsi
    57a2:	pop    rdx
    57a3:	mov    QWORD PTR [r12+0x108],rbx
    57ab:	stmxcsr DWORD PTR [r12-0x28]
    57b1:	mov    r10d,DWORD PTR [r12-0x28]
    57b6:	test   r10d,0x3f
    57bd:	je     0x57e2
    57c3:	mov    r11d,r10d
    57c6:	shr    r10d,1
    57c9:	and    r10d,0x1e
    57cd:	and    r11d,0x1
    57d1:	or     r10d,r11d
    57d4:	or     DWORD PTR [r12+0x314],r10d
    57dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    57e2:	ldmxcsr DWORD PTR [r12-0x38]
    57e8:	lea    rdi,[rsp+0x110]
    57f0:	lea    rsi,[rsp+0xf0]
    57f8:	lea    rdx,[rsp+0x100]
    5800:	mov    ecx,0x56
    5805:	mov    r8d,0x0
    580b:	lea    r9,[r12+0x314]
    5813:	movabs r11,0x590d850f6650
    581d:	call   r11
    5820:	ldmxcsr DWORD PTR [r12-0x28]
    5826:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    582c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5832:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5838:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    583e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    5844:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    584a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5854:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    585e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5868:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    5872:	mov    rbx,QWORD PTR [r12+0x108]
    587a:	mov    QWORD PTR [r12+0x378],0x2
    5886:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    588f:	mov    rdx,rbx
    5892:	shr    rdx,0x10
    5896:	and    edx,0xc000
    589c:	mov    rax,rbx
    589f:	shr    rax,0x15
    58a3:	and    eax,0x100
    58a8:	xor    eax,0x100
    58ad:	or     edx,eax
    58af:	mov    rax,rbx
    58b2:	shr    rax,0x1c
    58b6:	and    eax,0x1
    58b9:	or     edx,eax
    58bb:	mov    QWORD PTR [rsp+0x10],rdx
    58c0:	add    rsp,0x8
    58c4:	ret
    58c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    58d0:	sub    rsp,0x8
    58d4:	mov    QWORD PTR [r12+0x378],0x3
    58e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    58e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    58ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    58f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    58f8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    58fe:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    5904:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    590e:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    5918:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    5922:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    592c:	push   rdx
    592d:	push   rsi
    592e:	push   r10
    5930:	push   r11
    5932:	mov    rdx,QWORD PTR [rsp+0x30]
    5937:	mov    r10d,edx
    593a:	and    r10d,0xc000
    5941:	shl    r10d,0x10
    5945:	mov    r11d,edx
    5948:	and    r11d,0x100
    594f:	shl    r11d,0x15
    5953:	or     r10d,r11d
    5956:	and    edx,0x1
    5959:	shl    edx,0x1c
    595c:	or     r10d,edx
    595f:	btc    r10,0x1d
    5964:	mov    r11d,0xf0000000
    596a:	and    r11,r10
    596d:	movabs rsi,0xffffffff0fffffff
    5977:	and    rbx,rsi
    597a:	or     rbx,r11
    597d:	pop    r11
    597f:	pop    r10
    5981:	pop    rsi
    5982:	pop    rdx
    5983:	mov    QWORD PTR [r12+0x108],rbx
    598b:	stmxcsr DWORD PTR [r12-0x28]
    5991:	mov    r10d,DWORD PTR [r12-0x28]
    5996:	test   r10d,0x3f
    599d:	je     0x59c2
    59a3:	mov    r11d,r10d
    59a6:	shr    r10d,1
    59a9:	and    r10d,0x1e
    59ad:	and    r11d,0x1
    59b1:	or     r10d,r11d
    59b4:	or     DWORD PTR [r12+0x314],r10d
    59bc:	and    DWORD PTR [r12-0x28],0xffffffc0
    59c2:	ldmxcsr DWORD PTR [r12-0x38]
    59c8:	lea    rdi,[rsp+0x110]
    59d0:	lea    rsi,[rsp+0xf0]
    59d8:	lea    rdx,[rsp+0x100]
    59e0:	mov    ecx,0x14
    59e5:	mov    r8d,0x0
    59eb:	lea    r9,[r12+0x314]
    59f3:	movabs r11,0x590d850f6650
    59fd:	call   r11
    5a00:	ldmxcsr DWORD PTR [r12-0x28]
    5a06:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5a0c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5a12:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5a18:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5a1e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    5a24:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5a2a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    5a34:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5a3e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    5a48:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    5a52:	mov    rbx,QWORD PTR [r12+0x108]
    5a5a:	mov    QWORD PTR [r12+0x378],0x2
    5a66:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5a6f:	mov    rdx,rbx
    5a72:	shr    rdx,0x10
    5a76:	and    edx,0xc000
    5a7c:	mov    rax,rbx
    5a7f:	shr    rax,0x15
    5a83:	and    eax,0x100
    5a88:	xor    eax,0x100
    5a8d:	or     edx,eax
    5a8f:	mov    rax,rbx
    5a92:	shr    rax,0x1c
    5a96:	and    eax,0x1
    5a99:	or     edx,eax
    5a9b:	mov    QWORD PTR [rsp+0x10],rdx
    5aa0:	add    rsp,0x8
    5aa4:	ret
    5aa5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    5ab0:	sub    rsp,0x8
    5ab4:	mov    QWORD PTR [r12+0x378],0x3
    5ac0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5ac6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5acc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5ad2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    5ad8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    5ade:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    5ae8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    5af2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    5afc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    5b06:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    5b10:	push   rdx
    5b11:	push   rsi
    5b12:	push   r10
    5b14:	push   r11
    5b16:	mov    rdx,QWORD PTR [rsp+0x30]
    5b1b:	mov    r10d,edx
    5b1e:	and    r10d,0xc000
    5b25:	shl    r10d,0x10
    5b29:	mov    r11d,edx
    5b2c:	and    r11d,0x100
    5b33:	shl    r11d,0x15
    5b37:	or     r10d,r11d
    5b3a:	and    edx,0x1
    5b3d:	shl    edx,0x1c
    5b40:	or     r10d,edx
    5b43:	btc    r10,0x1d
    5b48:	mov    r11d,0xf0000000
    5b4e:	and    r11,r10
    5b51:	movabs rsi,0xffffffff0fffffff
    5b5b:	and    rbx,rsi
    5b5e:	or     rbx,r11
    5b61:	pop    r11
    5b63:	pop    r10
    5b65:	pop    rsi
    5b66:	pop    rdx
    5b67:	mov    QWORD PTR [r12+0x108],rbx
    5b6f:	stmxcsr DWORD PTR [r12-0x28]
    5b75:	mov    r10d,DWORD PTR [r12-0x28]
    5b7a:	test   r10d,0x3f
    5b81:	je     0x5ba6
    5b87:	mov    r11d,r10d
    5b8a:	shr    r10d,1
    5b8d:	and    r10d,0x1e
    5b91:	and    r11d,0x1
    5b95:	or     r10d,r11d
    5b98:	or     DWORD PTR [r12+0x314],r10d
    5ba0:	and    DWORD PTR [r12-0x28],0xffffffc0
    5ba6:	ldmxcsr DWORD PTR [r12-0x38]
    5bac:	lea    rdi,[rsp+0x110]
    5bb4:	lea    rsi,[rsp+0xf0]
    5bbc:	lea    rdx,[rsp+0x100]
    5bc4:	mov    ecx,0x56
    5bc9:	mov    r8d,0x0
    5bcf:	lea    r9,[r12+0x314]
    5bd7:	movabs r11,0x590d850f6650
    5be1:	call   r11
    5be4:	ldmxcsr DWORD PTR [r12-0x28]
    5bea:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5bf0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5bf6:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5bfc:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    5c02:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5c08:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5c12:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    5c1c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5c26:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    5c30:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    5c3a:	mov    rbx,QWORD PTR [r12+0x108]
    5c42:	mov    QWORD PTR [r12+0x378],0x2
    5c4e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5c57:	mov    rdx,rbx
    5c5a:	shr    rdx,0x10
    5c5e:	and    edx,0xc000
    5c64:	mov    rax,rbx
    5c67:	shr    rax,0x15
    5c6b:	and    eax,0x100
    5c70:	xor    eax,0x100
    5c75:	or     edx,eax
    5c77:	mov    rax,rbx
    5c7a:	shr    rax,0x1c
    5c7e:	and    eax,0x1
    5c81:	or     edx,eax
    5c83:	mov    QWORD PTR [rsp+0x10],rdx
    5c88:	add    rsp,0x8
    5c8c:	ret
    5c8d:	nop    DWORD PTR [rax]
    5c90:	sub    rsp,0x8
    5c94:	mov    QWORD PTR [r12+0x378],0x3
    5ca0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5ca6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5cac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5cb2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5cb8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    5cbe:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    5cc4:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    5cce:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    5cd8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    5ce2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    5cec:	push   rdx
    5ced:	push   rsi
    5cee:	push   r10
    5cf0:	push   r11
    5cf2:	mov    rdx,QWORD PTR [rsp+0x30]
    5cf7:	mov    r10d,edx
    5cfa:	and    r10d,0xc000
    5d01:	shl    r10d,0x10
    5d05:	mov    r11d,edx
    5d08:	and    r11d,0x100
    5d0f:	shl    r11d,0x15
    5d13:	or     r10d,r11d
    5d16:	and    edx,0x1
    5d19:	shl    edx,0x1c
    5d1c:	or     r10d,edx
    5d1f:	btc    r10,0x1d
    5d24:	mov    r11d,0xf0000000
    5d2a:	and    r11,r10
    5d2d:	movabs rsi,0xffffffff0fffffff
    5d37:	and    rbx,rsi
    5d3a:	or     rbx,r11
    5d3d:	pop    r11
    5d3f:	pop    r10
    5d41:	pop    rsi
    5d42:	pop    rdx
    5d43:	mov    QWORD PTR [r12+0x108],rbx
    5d4b:	stmxcsr DWORD PTR [r12-0x28]
    5d51:	mov    r10d,DWORD PTR [r12-0x28]
    5d56:	test   r10d,0x3f
    5d5d:	je     0x5d82
    5d63:	mov    r11d,r10d
    5d66:	shr    r10d,1
    5d69:	and    r10d,0x1e
    5d6d:	and    r11d,0x1
    5d71:	or     r10d,r11d
    5d74:	or     DWORD PTR [r12+0x314],r10d
    5d7c:	and    DWORD PTR [r12-0x28],0xffffffc0
    5d82:	ldmxcsr DWORD PTR [r12-0x38]
    5d88:	lea    rdi,[rsp+0x110]
    5d90:	lea    rsi,[rsp+0xf0]
    5d98:	lea    rdx,[rsp+0x100]
    5da0:	mov    ecx,0x56
    5da5:	mov    r8d,0x0
    5dab:	lea    r9,[r12+0x314]
    5db3:	movabs r11,0x590d850f6650
    5dbd:	call   r11
    5dc0:	ldmxcsr DWORD PTR [r12-0x28]
    5dc6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5dcc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5dd2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5dd8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5dde:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    5de4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5dea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5df4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    5dfe:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5e08:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    5e12:	mov    rbx,QWORD PTR [r12+0x108]
    5e1a:	mov    QWORD PTR [r12+0x378],0x2
    5e26:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5e2f:	mov    rdx,rbx
    5e32:	shr    rdx,0x10
    5e36:	and    edx,0xc000
    5e3c:	mov    rax,rbx
    5e3f:	shr    rax,0x15
    5e43:	and    eax,0x100
    5e48:	xor    eax,0x100
    5e4d:	or     edx,eax
    5e4f:	mov    rax,rbx
    5e52:	shr    rax,0x1c
    5e56:	and    eax,0x1
    5e59:	or     edx,eax
    5e5b:	mov    QWORD PTR [rsp+0x10],rdx
    5e60:	add    rsp,0x8
    5e64:	ret
    5e65:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    5e70:	sub    rsp,0x8
    5e74:	mov    QWORD PTR [r12+0x378],0x3
    5e80:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5e86:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5e8c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5e92:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5e98:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    5e9e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    5ea4:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    5eae:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    5eb8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    5ec2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    5ecc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    5ed6:	push   rdx
    5ed7:	push   rsi
    5ed8:	push   r10
    5eda:	push   r11
    5edc:	mov    rdx,QWORD PTR [rsp+0x30]
    5ee1:	mov    r10d,edx
    5ee4:	and    r10d,0xc000
    5eeb:	shl    r10d,0x10
    5eef:	mov    r11d,edx
    5ef2:	and    r11d,0x100
    5ef9:	shl    r11d,0x15
    5efd:	or     r10d,r11d
    5f00:	and    edx,0x1
    5f03:	shl    edx,0x1c
    5f06:	or     r10d,edx
    5f09:	btc    r10,0x1d
    5f0e:	mov    r11d,0xf0000000
    5f14:	and    r11,r10
    5f17:	movabs rsi,0xffffffff0fffffff
    5f21:	and    rbx,rsi
    5f24:	or     rbx,r11
    5f27:	pop    r11
    5f29:	pop    r10
    5f2b:	pop    rsi
    5f2c:	pop    rdx
    5f2d:	mov    QWORD PTR [r12+0x108],rbx
    5f35:	stmxcsr DWORD PTR [r12-0x28]
    5f3b:	mov    r10d,DWORD PTR [r12-0x28]
    5f40:	test   r10d,0x3f
    5f47:	je     0x5f6c
    5f4d:	mov    r11d,r10d
    5f50:	shr    r10d,1
    5f53:	and    r10d,0x1e
    5f57:	and    r11d,0x1
    5f5b:	or     r10d,r11d
    5f5e:	or     DWORD PTR [r12+0x314],r10d
    5f66:	and    DWORD PTR [r12-0x28],0xffffffc0
    5f6c:	ldmxcsr DWORD PTR [r12-0x38]
    5f72:	lea    rdi,[rsp+0x110]
    5f7a:	lea    rsi,[rsp+0xf0]
    5f82:	lea    rdx,[rsp+0x100]
    5f8a:	mov    ecx,0x14
    5f8f:	mov    r8d,0x0
    5f95:	lea    r9,[r12+0x314]
    5f9d:	movabs r11,0x590d850f6650
    5fa7:	call   r11
    5faa:	ldmxcsr DWORD PTR [r12-0x28]
    5fb0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5fb6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5fbc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5fc2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5fc8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    5fce:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5fd4:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5fde:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    5fe8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5ff2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    5ffc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    6006:	mov    rbx,QWORD PTR [r12+0x108]
    600e:	mov    QWORD PTR [r12+0x378],0x2
    601a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6023:	mov    rdx,rbx
    6026:	shr    rdx,0x10
    602a:	and    edx,0xc000
    6030:	mov    rax,rbx
    6033:	shr    rax,0x15
    6037:	and    eax,0x100
    603c:	xor    eax,0x100
    6041:	or     edx,eax
    6043:	mov    rax,rbx
    6046:	shr    rax,0x1c
    604a:	and    eax,0x1
    604d:	or     edx,eax
    604f:	mov    QWORD PTR [rsp+0x10],rdx
    6054:	add    rsp,0x8
    6058:	ret
    6059:	nop    DWORD PTR [rax+0x0]
    6060:	sub    rsp,0x8
    6064:	mov    QWORD PTR [r12+0x378],0x3
    6070:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6076:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    607c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6082:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6088:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    6092:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    609c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    60a6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    60b0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    60ba:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    60c4:	push   rdx
    60c5:	push   rsi
    60c6:	push   r10
    60c8:	push   r11
    60ca:	mov    rdx,QWORD PTR [rsp+0x30]
    60cf:	mov    r10d,edx
    60d2:	and    r10d,0xc000
    60d9:	shl    r10d,0x10
    60dd:	mov    r11d,edx
    60e0:	and    r11d,0x100
    60e7:	shl    r11d,0x15
    60eb:	or     r10d,r11d
    60ee:	and    edx,0x1
    60f1:	shl    edx,0x1c
    60f4:	or     r10d,edx
    60f7:	btc    r10,0x1d
    60fc:	mov    r11d,0xf0000000
    6102:	and    r11,r10
    6105:	movabs rsi,0xffffffff0fffffff
    610f:	and    rbx,rsi
    6112:	or     rbx,r11
    6115:	pop    r11
    6117:	pop    r10
    6119:	pop    rsi
    611a:	pop    rdx
    611b:	mov    QWORD PTR [r12+0x108],rbx
    6123:	stmxcsr DWORD PTR [r12-0x28]
    6129:	mov    r10d,DWORD PTR [r12-0x28]
    612e:	test   r10d,0x3f
    6135:	je     0x615a
    613b:	mov    r11d,r10d
    613e:	shr    r10d,1
    6141:	and    r10d,0x1e
    6145:	and    r11d,0x1
    6149:	or     r10d,r11d
    614c:	or     DWORD PTR [r12+0x314],r10d
    6154:	and    DWORD PTR [r12-0x28],0xffffffc0
    615a:	ldmxcsr DWORD PTR [r12-0x38]
    6160:	lea    rdi,[rsp+0x110]
    6168:	lea    rsi,[rsp+0xf0]
    6170:	lea    rdx,[rsp+0x100]
    6178:	mov    ecx,0x56
    617d:	mov    r8d,0x0
    6183:	lea    r9,[r12+0x314]
    618b:	movabs r11,0x590d850f6650
    6195:	call   r11
    6198:	ldmxcsr DWORD PTR [r12-0x28]
    619e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    61a4:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    61aa:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    61b0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    61b6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    61c0:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    61ca:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    61d4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    61de:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    61e8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    61f2:	mov    rbx,QWORD PTR [r12+0x108]
    61fa:	mov    QWORD PTR [r12+0x378],0x2
    6206:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    620f:	mov    rdx,rbx
    6212:	shr    rdx,0x10
    6216:	and    edx,0xc000
    621c:	mov    rax,rbx
    621f:	shr    rax,0x15
    6223:	and    eax,0x100
    6228:	xor    eax,0x100
    622d:	or     edx,eax
    622f:	mov    rax,rbx
    6232:	shr    rax,0x1c
    6236:	and    eax,0x1
    6239:	or     edx,eax
    623b:	mov    QWORD PTR [rsp+0x10],rdx
    6240:	add    rsp,0x8
    6244:	ret
    6245:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    6250:	sub    rsp,0x8
    6254:	mov    QWORD PTR [r12+0x378],0x3
    6260:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6266:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    626c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6272:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    6278:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    627e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    6288:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    6292:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    629c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    62a6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    62b0:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    62ba:	push   rdx
    62bb:	push   rsi
    62bc:	push   r10
    62be:	push   r11
    62c0:	mov    rdx,QWORD PTR [rsp+0x30]
    62c5:	mov    r10d,edx
    62c8:	and    r10d,0xc000
    62cf:	shl    r10d,0x10
    62d3:	mov    r11d,edx
    62d6:	and    r11d,0x100
    62dd:	shl    r11d,0x15
    62e1:	or     r10d,r11d
    62e4:	and    edx,0x1
    62e7:	shl    edx,0x1c
    62ea:	or     r10d,edx
    62ed:	btc    r10,0x1d
    62f2:	mov    r11d,0xf0000000
    62f8:	and    r11,r10
    62fb:	movabs rsi,0xffffffff0fffffff
    6305:	and    rbx,rsi
    6308:	or     rbx,r11
    630b:	pop    r11
    630d:	pop    r10
    630f:	pop    rsi
    6310:	pop    rdx
    6311:	mov    QWORD PTR [r12+0x108],rbx
    6319:	stmxcsr DWORD PTR [r12-0x28]
    631f:	mov    r10d,DWORD PTR [r12-0x28]
    6324:	test   r10d,0x3f
    632b:	je     0x6350
    6331:	mov    r11d,r10d
    6334:	shr    r10d,1
    6337:	and    r10d,0x1e
    633b:	and    r11d,0x1
    633f:	or     r10d,r11d
    6342:	or     DWORD PTR [r12+0x314],r10d
    634a:	and    DWORD PTR [r12-0x28],0xffffffc0
    6350:	ldmxcsr DWORD PTR [r12-0x38]
    6356:	lea    rdi,[rsp+0x110]
    635e:	lea    rsi,[rsp+0xf0]
    6366:	lea    rdx,[rsp+0x100]
    636e:	mov    ecx,0x14
    6373:	mov    r8d,0x0
    6379:	lea    r9,[r12+0x314]
    6381:	movabs r11,0x590d850f6650
    638b:	call   r11
    638e:	ldmxcsr DWORD PTR [r12-0x28]
    6394:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    639a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    63a0:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    63a6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    63ac:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    63b2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    63bc:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    63c6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    63d0:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    63da:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    63e4:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    63ee:	mov    rbx,QWORD PTR [r12+0x108]
    63f6:	mov    QWORD PTR [r12+0x378],0x2
    6402:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    640b:	mov    rdx,rbx
    640e:	shr    rdx,0x10
    6412:	and    edx,0xc000
    6418:	mov    rax,rbx
    641b:	shr    rax,0x15
    641f:	and    eax,0x100
    6424:	xor    eax,0x100
    6429:	or     edx,eax
    642b:	mov    rax,rbx
    642e:	shr    rax,0x1c
    6432:	and    eax,0x1
    6435:	or     edx,eax
    6437:	mov    QWORD PTR [rsp+0x10],rdx
    643c:	add    rsp,0x8
    6440:	ret
    6441:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    6450:	sub    rsp,0x8
    6454:	mov    QWORD PTR [r12+0x378],0x3
    6460:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6466:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    646c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6472:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6478:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    647e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6484:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    648e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    6498:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    64a2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    64ac:	push   rdx
    64ad:	push   rsi
    64ae:	push   r10
    64b0:	push   r11
    64b2:	mov    rdx,QWORD PTR [rsp+0x30]
    64b7:	mov    r10d,edx
    64ba:	and    r10d,0xc000
    64c1:	shl    r10d,0x10
    64c5:	mov    r11d,edx
    64c8:	and    r11d,0x100
    64cf:	shl    r11d,0x15
    64d3:	or     r10d,r11d
    64d6:	and    edx,0x1
    64d9:	shl    edx,0x1c
    64dc:	or     r10d,edx
    64df:	btc    r10,0x1d
    64e4:	mov    r11d,0xf0000000
    64ea:	and    r11,r10
    64ed:	movabs rsi,0xffffffff0fffffff
    64f7:	and    rbx,rsi
    64fa:	or     rbx,r11
    64fd:	pop    r11
    64ff:	pop    r10
    6501:	pop    rsi
    6502:	pop    rdx
    6503:	mov    QWORD PTR [r12+0x108],rbx
    650b:	stmxcsr DWORD PTR [r12-0x28]
    6511:	mov    r10d,DWORD PTR [r12-0x28]
    6516:	test   r10d,0x3f
    651d:	je     0x6542
    6523:	mov    r11d,r10d
    6526:	shr    r10d,1
    6529:	and    r10d,0x1e
    652d:	and    r11d,0x1
    6531:	or     r10d,r11d
    6534:	or     DWORD PTR [r12+0x314],r10d
    653c:	and    DWORD PTR [r12-0x28],0xffffffc0
    6542:	ldmxcsr DWORD PTR [r12-0x38]
    6548:	lea    rdi,[rsp+0x110]
    6550:	lea    rsi,[rsp+0xf0]
    6558:	lea    rdx,[rsp+0x100]
    6560:	mov    ecx,0x56
    6565:	mov    r8d,0x0
    656b:	lea    r9,[r12+0x314]
    6573:	movabs r11,0x590d850f6650
    657d:	call   r11
    6580:	ldmxcsr DWORD PTR [r12-0x28]
    6586:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    658c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6592:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6598:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    659e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    65a4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    65aa:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    65b4:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    65be:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    65c8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    65d2:	mov    rbx,QWORD PTR [r12+0x108]
    65da:	mov    QWORD PTR [r12+0x378],0x2
    65e6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    65ef:	mov    rdx,rbx
    65f2:	shr    rdx,0x10
    65f6:	and    edx,0xc000
    65fc:	mov    rax,rbx
    65ff:	shr    rax,0x15
    6603:	and    eax,0x100
    6608:	xor    eax,0x100
    660d:	or     edx,eax
    660f:	mov    rax,rbx
    6612:	shr    rax,0x1c
    6616:	and    eax,0x1
    6619:	or     edx,eax
    661b:	mov    QWORD PTR [rsp+0x10],rdx
    6620:	add    rsp,0x8
    6624:	ret
    6625:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    6630:	sub    rsp,0x8
    6634:	mov    QWORD PTR [r12+0x378],0x3
    6640:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    664c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    6658:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    6662:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    666c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6676:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6680:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    668a:	push   rdx
    668b:	push   rsi
    668c:	push   r10
    668e:	push   r11
    6690:	mov    rdx,QWORD PTR [rsp+0x30]
    6695:	mov    r10d,edx
    6698:	and    r10d,0xc000
    669f:	shl    r10d,0x10
    66a3:	mov    r11d,edx
    66a6:	and    r11d,0x100
    66ad:	shl    r11d,0x15
    66b1:	or     r10d,r11d
    66b4:	and    edx,0x1
    66b7:	shl    edx,0x1c
    66ba:	or     r10d,edx
    66bd:	btc    r10,0x1d
    66c2:	mov    r11d,0xf0000000
    66c8:	and    r11,r10
    66cb:	movabs rsi,0xffffffff0fffffff
    66d5:	and    rbx,rsi
    66d8:	or     rbx,r11
    66db:	pop    r11
    66dd:	pop    r10
    66df:	pop    rsi
    66e0:	pop    rdx
    66e1:	mov    QWORD PTR [r12+0x108],rbx
    66e9:	stmxcsr DWORD PTR [r12-0x28]
    66ef:	mov    r10d,DWORD PTR [r12-0x28]
    66f4:	test   r10d,0x3f
    66fb:	je     0x6720
    6701:	mov    r11d,r10d
    6704:	shr    r10d,1
    6707:	and    r10d,0x1e
    670b:	and    r11d,0x1
    670f:	or     r10d,r11d
    6712:	or     DWORD PTR [r12+0x314],r10d
    671a:	and    DWORD PTR [r12-0x28],0xffffffc0
    6720:	ldmxcsr DWORD PTR [r12-0x38]
    6726:	lea    rdi,[rsp+0x110]
    672e:	lea    rsi,[rsp+0xf0]
    6736:	lea    rdx,[rsp+0x100]
    673e:	mov    ecx,0x14
    6743:	mov    r8d,0x0
    6749:	lea    r9,[r12+0x314]
    6751:	movabs r11,0x590d850f6650
    675b:	call   r11
    675e:	ldmxcsr DWORD PTR [r12-0x28]
    6764:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    676a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6770:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6776:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    677c:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    6786:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6790:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    679a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    67a4:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    67ae:	mov    rbx,QWORD PTR [r12+0x108]
    67b6:	mov    QWORD PTR [r12+0x378],0x2
    67c2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    67cb:	mov    rdx,rbx
    67ce:	shr    rdx,0x10
    67d2:	and    edx,0xc000
    67d8:	mov    rax,rbx
    67db:	shr    rax,0x15
    67df:	and    eax,0x100
    67e4:	xor    eax,0x100
    67e9:	or     edx,eax
    67eb:	mov    rax,rbx
    67ee:	shr    rax,0x1c
    67f2:	and    eax,0x1
    67f5:	or     edx,eax
    67f7:	mov    QWORD PTR [rsp+0x10],rdx
    67fc:	add    rsp,0x8
    6800:	ret
    6801:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    6810:	sub    rsp,0x8
    6814:	mov    QWORD PTR [r12+0x378],0x3
    6820:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6826:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    682c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6832:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6838:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    683e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6844:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    684e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    6858:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6862:	push   rdx
    6863:	push   rsi
    6864:	push   r10
    6866:	push   r11
    6868:	mov    rdx,QWORD PTR [rsp+0x30]
    686d:	mov    r10d,edx
    6870:	and    r10d,0xc000
    6877:	shl    r10d,0x10
    687b:	mov    r11d,edx
    687e:	and    r11d,0x100
    6885:	shl    r11d,0x15
    6889:	or     r10d,r11d
    688c:	and    edx,0x1
    688f:	shl    edx,0x1c
    6892:	or     r10d,edx
    6895:	btc    r10,0x1d
    689a:	mov    r11d,0xf0000000
    68a0:	and    r11,r10
    68a3:	movabs rsi,0xffffffff0fffffff
    68ad:	and    rbx,rsi
    68b0:	or     rbx,r11
    68b3:	pop    r11
    68b5:	pop    r10
    68b7:	pop    rsi
    68b8:	pop    rdx
    68b9:	mov    QWORD PTR [r12+0x108],rbx
    68c1:	stmxcsr DWORD PTR [r12-0x28]
    68c7:	mov    r10d,DWORD PTR [r12-0x28]
    68cc:	test   r10d,0x3f
    68d3:	je     0x68f8
    68d9:	mov    r11d,r10d
    68dc:	shr    r10d,1
    68df:	and    r10d,0x1e
    68e3:	and    r11d,0x1
    68e7:	or     r10d,r11d
    68ea:	or     DWORD PTR [r12+0x314],r10d
    68f2:	and    DWORD PTR [r12-0x28],0xffffffc0
    68f8:	ldmxcsr DWORD PTR [r12-0x38]
    68fe:	lea    rdi,[rsp+0x110]
    6906:	lea    rsi,[rsp+0xf0]
    690e:	lea    rdx,[rsp+0x100]
    6916:	mov    ecx,0x56
    691b:	mov    r8d,0x0
    6921:	lea    r9,[r12+0x314]
    6929:	movabs r11,0x590d850f6650
    6933:	call   r11
    6936:	ldmxcsr DWORD PTR [r12-0x28]
    693c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6942:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6948:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    694e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6954:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    695a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6960:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    696a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6974:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    697e:	mov    rbx,QWORD PTR [r12+0x108]
    6986:	mov    QWORD PTR [r12+0x378],0x2
    6992:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    699b:	mov    rdx,rbx
    699e:	shr    rdx,0x10
    69a2:	and    edx,0xc000
    69a8:	mov    rax,rbx
    69ab:	shr    rax,0x15
    69af:	and    eax,0x100
    69b4:	xor    eax,0x100
    69b9:	or     edx,eax
    69bb:	mov    rax,rbx
    69be:	shr    rax,0x1c
    69c2:	and    eax,0x1
    69c5:	or     edx,eax
    69c7:	mov    QWORD PTR [rsp+0x10],rdx
    69cc:	add    rsp,0x8
    69d0:	ret
    69d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    69e0:	sub    rsp,0x8
    69e4:	mov    QWORD PTR [r12+0x378],0x3
    69f0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    69f6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    69fc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6a02:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    6a08:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6a0e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    6a18:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    6a22:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6a2c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6a36:	push   rdx
    6a37:	push   rsi
    6a38:	push   r10
    6a3a:	push   r11
    6a3c:	mov    rdx,QWORD PTR [rsp+0x30]
    6a41:	mov    r10d,edx
    6a44:	and    r10d,0xc000
    6a4b:	shl    r10d,0x10
    6a4f:	mov    r11d,edx
    6a52:	and    r11d,0x100
    6a59:	shl    r11d,0x15
    6a5d:	or     r10d,r11d
    6a60:	and    edx,0x1
    6a63:	shl    edx,0x1c
    6a66:	or     r10d,edx
    6a69:	btc    r10,0x1d
    6a6e:	mov    r11d,0xf0000000
    6a74:	and    r11,r10
    6a77:	movabs rsi,0xffffffff0fffffff
    6a81:	and    rbx,rsi
    6a84:	or     rbx,r11
    6a87:	pop    r11
    6a89:	pop    r10
    6a8b:	pop    rsi
    6a8c:	pop    rdx
    6a8d:	mov    QWORD PTR [r12+0x108],rbx
    6a95:	stmxcsr DWORD PTR [r12-0x28]
    6a9b:	mov    r10d,DWORD PTR [r12-0x28]
    6aa0:	test   r10d,0x3f
    6aa7:	je     0x6acc
    6aad:	mov    r11d,r10d
    6ab0:	shr    r10d,1
    6ab3:	and    r10d,0x1e
    6ab7:	and    r11d,0x1
    6abb:	or     r10d,r11d
    6abe:	or     DWORD PTR [r12+0x314],r10d
    6ac6:	and    DWORD PTR [r12-0x28],0xffffffc0
    6acc:	ldmxcsr DWORD PTR [r12-0x38]
    6ad2:	lea    rdi,[rsp+0x110]
    6ada:	lea    rsi,[rsp+0xf0]
    6ae2:	lea    rdx,[rsp+0x100]
    6aea:	mov    ecx,0x56
    6aef:	mov    r8d,0x0
    6af5:	lea    r9,[r12+0x314]
    6afd:	movabs r11,0x590d850f6650
    6b07:	call   r11
    6b0a:	ldmxcsr DWORD PTR [r12-0x28]
    6b10:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6b16:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6b1c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6b22:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    6b28:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6b2e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    6b38:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6b42:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    6b4c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    6b56:	mov    rbx,QWORD PTR [r12+0x108]
    6b5e:	mov    QWORD PTR [r12+0x378],0x2
    6b6a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6b73:	mov    rdx,rbx
    6b76:	shr    rdx,0x10
    6b7a:	and    edx,0xc000
    6b80:	mov    rax,rbx
    6b83:	shr    rax,0x15
    6b87:	and    eax,0x100
    6b8c:	xor    eax,0x100
    6b91:	or     edx,eax
    6b93:	mov    rax,rbx
    6b96:	shr    rax,0x1c
    6b9a:	and    eax,0x1
    6b9d:	or     edx,eax
    6b9f:	mov    QWORD PTR [rsp+0x10],rdx
    6ba4:	add    rsp,0x8
    6ba8:	ret
    6ba9:	nop    DWORD PTR [rax+0x0]
    6bb0:	sub    rsp,0x8
    6bb4:	mov    QWORD PTR [r12+0x378],0x3
    6bc0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6bc6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6bcc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6bd2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6bd8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    6bde:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6be4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    6bee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    6bf8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6c02:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6c0c:	push   rdx
    6c0d:	push   rsi
    6c0e:	push   r10
    6c10:	push   r11
    6c12:	mov    rdx,QWORD PTR [rsp+0x30]
    6c17:	mov    r10d,edx
    6c1a:	and    r10d,0xc000
    6c21:	shl    r10d,0x10
    6c25:	mov    r11d,edx
    6c28:	and    r11d,0x100
    6c2f:	shl    r11d,0x15
    6c33:	or     r10d,r11d
    6c36:	and    edx,0x1
    6c39:	shl    edx,0x1c
    6c3c:	or     r10d,edx
    6c3f:	btc    r10,0x1d
    6c44:	mov    r11d,0xf0000000
    6c4a:	and    r11,r10
    6c4d:	movabs rsi,0xffffffff0fffffff
    6c57:	and    rbx,rsi
    6c5a:	or     rbx,r11
    6c5d:	pop    r11
    6c5f:	pop    r10
    6c61:	pop    rsi
    6c62:	pop    rdx
    6c63:	mov    QWORD PTR [r12+0x108],rbx
    6c6b:	stmxcsr DWORD PTR [r12-0x28]
    6c71:	mov    r10d,DWORD PTR [r12-0x28]
    6c76:	test   r10d,0x3f
    6c7d:	je     0x6ca2
    6c83:	mov    r11d,r10d
    6c86:	shr    r10d,1
    6c89:	and    r10d,0x1e
    6c8d:	and    r11d,0x1
    6c91:	or     r10d,r11d
    6c94:	or     DWORD PTR [r12+0x314],r10d
    6c9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    6ca2:	ldmxcsr DWORD PTR [r12-0x38]
    6ca8:	lea    rdi,[rsp+0x110]
    6cb0:	lea    rsi,[rsp+0xf0]
    6cb8:	lea    rdx,[rsp+0x100]
    6cc0:	mov    ecx,0x14
    6cc5:	mov    r8d,0x0
    6ccb:	lea    r9,[r12+0x314]
    6cd3:	movabs r11,0x590d850f6650
    6cdd:	call   r11
    6ce0:	ldmxcsr DWORD PTR [r12-0x28]
    6ce6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6cec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6cf2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6cf8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6cfe:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    6d04:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6d0a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    6d14:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6d1e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    6d28:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    6d32:	mov    rbx,QWORD PTR [r12+0x108]
    6d3a:	mov    QWORD PTR [r12+0x378],0x2
    6d46:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6d4f:	mov    rdx,rbx
    6d52:	shr    rdx,0x10
    6d56:	and    edx,0xc000
    6d5c:	mov    rax,rbx
    6d5f:	shr    rax,0x15
    6d63:	and    eax,0x100
    6d68:	xor    eax,0x100
    6d6d:	or     edx,eax
    6d6f:	mov    rax,rbx
    6d72:	shr    rax,0x1c
    6d76:	and    eax,0x1
    6d79:	or     edx,eax
    6d7b:	mov    QWORD PTR [rsp+0x10],rdx
    6d80:	add    rsp,0x8
    6d84:	ret
    6d85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    6d90:	sub    rsp,0x8
    6d94:	mov    QWORD PTR [r12+0x378],0x3
    6da0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6da6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6dac:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6db2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    6db8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6dbe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    6dc8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6dd2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6ddc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    6de6:	push   rdx
    6de7:	push   rsi
    6de8:	push   r10
    6dea:	push   r11
    6dec:	mov    rdx,QWORD PTR [rsp+0x30]
    6df1:	mov    r10d,edx
    6df4:	and    r10d,0xc000
    6dfb:	shl    r10d,0x10
    6dff:	mov    r11d,edx
    6e02:	and    r11d,0x100
    6e09:	shl    r11d,0x15
    6e0d:	or     r10d,r11d
    6e10:	and    edx,0x1
    6e13:	shl    edx,0x1c
    6e16:	or     r10d,edx
    6e19:	btc    r10,0x1d
    6e1e:	mov    r11d,0xf0000000
    6e24:	and    r11,r10
    6e27:	movabs rsi,0xffffffff0fffffff
    6e31:	and    rbx,rsi
    6e34:	or     rbx,r11
    6e37:	pop    r11
    6e39:	pop    r10
    6e3b:	pop    rsi
    6e3c:	pop    rdx
    6e3d:	mov    QWORD PTR [r12+0x108],rbx
    6e45:	stmxcsr DWORD PTR [r12-0x28]
    6e4b:	mov    r10d,DWORD PTR [r12-0x28]
    6e50:	test   r10d,0x3f
    6e57:	je     0x6e7c
    6e5d:	mov    r11d,r10d
    6e60:	shr    r10d,1
    6e63:	and    r10d,0x1e
    6e67:	and    r11d,0x1
    6e6b:	or     r10d,r11d
    6e6e:	or     DWORD PTR [r12+0x314],r10d
    6e76:	and    DWORD PTR [r12-0x28],0xffffffc0
    6e7c:	ldmxcsr DWORD PTR [r12-0x38]
    6e82:	lea    rdi,[rsp+0x110]
    6e8a:	lea    rsi,[rsp+0xf0]
    6e92:	lea    rdx,[rsp+0x100]
    6e9a:	mov    ecx,0x14
    6e9f:	mov    r8d,0x0
    6ea5:	lea    r9,[r12+0x314]
    6ead:	movabs r11,0x590d850f6650
    6eb7:	call   r11
    6eba:	ldmxcsr DWORD PTR [r12-0x28]
    6ec0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6ec6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6ecc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6ed2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    6ed8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6ede:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6ee8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    6ef2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    6efc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    6f06:	mov    rbx,QWORD PTR [r12+0x108]
    6f0e:	mov    QWORD PTR [r12+0x378],0x2
    6f1a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6f23:	mov    rdx,rbx
    6f26:	shr    rdx,0x10
    6f2a:	and    edx,0xc000
    6f30:	mov    rax,rbx
    6f33:	shr    rax,0x15
    6f37:	and    eax,0x100
    6f3c:	xor    eax,0x100
    6f41:	or     edx,eax
    6f43:	mov    rax,rbx
    6f46:	shr    rax,0x1c
    6f4a:	and    eax,0x1
    6f4d:	or     edx,eax
    6f4f:	mov    QWORD PTR [rsp+0x10],rdx
    6f54:	add    rsp,0x8
    6f58:	ret
    6f59:	nop    DWORD PTR [rax+0x0]
    6f60:	sub    rsp,0x8
    6f64:	mov    QWORD PTR [r12+0x378],0x3
    6f70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6f76:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6f7c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6f82:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6f88:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6f8e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6f98:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6fa2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    6fac:	push   rdx
    6fad:	push   rsi
    6fae:	push   r10
    6fb0:	push   r11
    6fb2:	mov    rdx,QWORD PTR [rsp+0x30]
    6fb7:	mov    r10d,edx
    6fba:	and    r10d,0xc000
    6fc1:	shl    r10d,0x10
    6fc5:	mov    r11d,edx
    6fc8:	and    r11d,0x100
    6fcf:	shl    r11d,0x15
    6fd3:	or     r10d,r11d
    6fd6:	and    edx,0x1
    6fd9:	shl    edx,0x1c
    6fdc:	or     r10d,edx
    6fdf:	btc    r10,0x1d
    6fe4:	mov    r11d,0xf0000000
    6fea:	and    r11,r10
    6fed:	movabs rsi,0xffffffff0fffffff
    6ff7:	and    rbx,rsi
    6ffa:	or     rbx,r11
    6ffd:	pop    r11
    6fff:	pop    r10
    7001:	pop    rsi
    7002:	pop    rdx
    7003:	mov    QWORD PTR [r12+0x108],rbx
    700b:	stmxcsr DWORD PTR [r12-0x28]
    7011:	mov    r10d,DWORD PTR [r12-0x28]
    7016:	test   r10d,0x3f
    701d:	je     0x7042
    7023:	mov    r11d,r10d
    7026:	shr    r10d,1
    7029:	and    r10d,0x1e
    702d:	and    r11d,0x1
    7031:	or     r10d,r11d
    7034:	or     DWORD PTR [r12+0x314],r10d
    703c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7042:	ldmxcsr DWORD PTR [r12-0x38]
    7048:	lea    rdi,[rsp+0x110]
    7050:	lea    rsi,[rsp+0xf0]
    7058:	lea    rdx,[rsp+0x100]
    7060:	mov    ecx,0x56
    7065:	mov    r8d,0x0
    706b:	lea    r9,[r12+0x314]
    7073:	movabs r11,0x590d850f6650
    707d:	call   r11
    7080:	ldmxcsr DWORD PTR [r12-0x28]
    7086:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    708c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7092:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7098:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    709e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    70a4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    70ae:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    70b8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    70c2:	mov    rbx,QWORD PTR [r12+0x108]
    70ca:	mov    QWORD PTR [r12+0x378],0x2
    70d6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70df:	mov    rdx,rbx
    70e2:	shr    rdx,0x10
    70e6:	and    edx,0xc000
    70ec:	mov    rax,rbx
    70ef:	shr    rax,0x15
    70f3:	and    eax,0x100
    70f8:	xor    eax,0x100
    70fd:	or     edx,eax
    70ff:	mov    rax,rbx
    7102:	shr    rax,0x1c
    7106:	and    eax,0x1
    7109:	or     edx,eax
    710b:	mov    QWORD PTR [rsp+0x10],rdx
    7110:	add    rsp,0x8
    7114:	ret
    7115:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7120:	sub    rsp,0x8
    7124:	mov    QWORD PTR [r12+0x378],0x3
    7130:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7136:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    713c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7142:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7148:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    714e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7154:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    715e:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7168:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7172:	push   rdx
    7173:	push   rsi
    7174:	push   r10
    7176:	push   r11
    7178:	mov    rdx,QWORD PTR [rsp+0x30]
    717d:	mov    r10d,edx
    7180:	and    r10d,0xc000
    7187:	shl    r10d,0x10
    718b:	mov    r11d,edx
    718e:	and    r11d,0x100
    7195:	shl    r11d,0x15
    7199:	or     r10d,r11d
    719c:	and    edx,0x1
    719f:	shl    edx,0x1c
    71a2:	or     r10d,edx
    71a5:	btc    r10,0x1d
    71aa:	mov    r11d,0xf0000000
    71b0:	and    r11,r10
    71b3:	movabs rsi,0xffffffff0fffffff
    71bd:	and    rbx,rsi
    71c0:	or     rbx,r11
    71c3:	pop    r11
    71c5:	pop    r10
    71c7:	pop    rsi
    71c8:	pop    rdx
    71c9:	mov    QWORD PTR [r12+0x108],rbx
    71d1:	stmxcsr DWORD PTR [r12-0x28]
    71d7:	mov    r10d,DWORD PTR [r12-0x28]
    71dc:	test   r10d,0x3f
    71e3:	je     0x7208
    71e9:	mov    r11d,r10d
    71ec:	shr    r10d,1
    71ef:	and    r10d,0x1e
    71f3:	and    r11d,0x1
    71f7:	or     r10d,r11d
    71fa:	or     DWORD PTR [r12+0x314],r10d
    7202:	and    DWORD PTR [r12-0x28],0xffffffc0
    7208:	ldmxcsr DWORD PTR [r12-0x38]
    720e:	lea    rdi,[rsp+0x110]
    7216:	lea    rsi,[rsp+0xf0]
    721e:	lea    rdx,[rsp+0x100]
    7226:	mov    ecx,0x56
    722b:	mov    r8d,0x0
    7231:	lea    r9,[r12+0x314]
    7239:	movabs r11,0x590d850f6650
    7243:	call   r11
    7246:	ldmxcsr DWORD PTR [r12-0x28]
    724c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7252:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7258:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    725e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7264:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    726a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7270:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    727a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7284:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    728e:	mov    rbx,QWORD PTR [r12+0x108]
    7296:	mov    QWORD PTR [r12+0x378],0x2
    72a2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72ab:	mov    rdx,rbx
    72ae:	shr    rdx,0x10
    72b2:	and    edx,0xc000
    72b8:	mov    rax,rbx
    72bb:	shr    rax,0x15
    72bf:	and    eax,0x100
    72c4:	xor    eax,0x100
    72c9:	or     edx,eax
    72cb:	mov    rax,rbx
    72ce:	shr    rax,0x1c
    72d2:	and    eax,0x1
    72d5:	or     edx,eax
    72d7:	mov    QWORD PTR [rsp+0x10],rdx
    72dc:	add    rsp,0x8
    72e0:	ret
    72e1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72f0:	sub    rsp,0x8
    72f4:	mov    QWORD PTR [r12+0x378],0x3
    7300:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7306:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7312:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7318:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    731e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7328:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7332:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    733c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7346:	push   rdx
    7347:	push   rsi
    7348:	push   r10
    734a:	push   r11
    734c:	mov    rdx,QWORD PTR [rsp+0x30]
    7351:	mov    r10d,edx
    7354:	and    r10d,0xc000
    735b:	shl    r10d,0x10
    735f:	mov    r11d,edx
    7362:	and    r11d,0x100
    7369:	shl    r11d,0x15
    736d:	or     r10d,r11d
    7370:	and    edx,0x1
    7373:	shl    edx,0x1c
    7376:	or     r10d,edx
    7379:	btc    r10,0x1d
    737e:	mov    r11d,0xf0000000
    7384:	and    r11,r10
    7387:	movabs rsi,0xffffffff0fffffff
    7391:	and    rbx,rsi
    7394:	or     rbx,r11
    7397:	pop    r11
    7399:	pop    r10
    739b:	pop    rsi
    739c:	pop    rdx
    739d:	mov    QWORD PTR [r12+0x108],rbx
    73a5:	stmxcsr DWORD PTR [r12-0x28]
    73ab:	mov    r10d,DWORD PTR [r12-0x28]
    73b0:	test   r10d,0x3f
    73b7:	je     0x73dc
    73bd:	mov    r11d,r10d
    73c0:	shr    r10d,1
    73c3:	and    r10d,0x1e
    73c7:	and    r11d,0x1
    73cb:	or     r10d,r11d
    73ce:	or     DWORD PTR [r12+0x314],r10d
    73d6:	and    DWORD PTR [r12-0x28],0xffffffc0
    73dc:	ldmxcsr DWORD PTR [r12-0x38]
    73e2:	lea    rdi,[rsp+0x110]
    73ea:	lea    rsi,[rsp+0xf0]
    73f2:	lea    rdx,[rsp+0x100]
    73fa:	mov    ecx,0x14
    73ff:	mov    r8d,0x0
    7405:	lea    r9,[r12+0x314]
    740d:	movabs r11,0x590d850f6650
    7417:	call   r11
    741a:	ldmxcsr DWORD PTR [r12-0x28]
    7420:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7426:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    742c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7432:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7438:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    743e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7448:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7452:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    745c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7466:	mov    rbx,QWORD PTR [r12+0x108]
    746e:	mov    QWORD PTR [r12+0x378],0x2
    747a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7483:	mov    rdx,rbx
    7486:	shr    rdx,0x10
    748a:	and    edx,0xc000
    7490:	mov    rax,rbx
    7493:	shr    rax,0x15
    7497:	and    eax,0x100
    749c:	xor    eax,0x100
    74a1:	or     edx,eax
    74a3:	mov    rax,rbx
    74a6:	shr    rax,0x1c
    74aa:	and    eax,0x1
    74ad:	or     edx,eax
    74af:	mov    QWORD PTR [rsp+0x10],rdx
    74b4:	add    rsp,0x8
    74b8:	ret
    74b9:	nop    DWORD PTR [rax+0x0]
    74c0:	sub    rsp,0x8
    74c4:	mov    QWORD PTR [r12+0x378],0x3
    74d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74f8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7502:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    750c:	push   rdx
    750d:	push   rsi
    750e:	push   r10
    7510:	push   r11
    7512:	mov    rdx,QWORD PTR [rsp+0x30]
    7517:	mov    r10d,edx
    751a:	and    r10d,0xc000
    7521:	shl    r10d,0x10
    7525:	mov    r11d,edx
    7528:	and    r11d,0x100
    752f:	shl    r11d,0x15
    7533:	or     r10d,r11d
    7536:	and    edx,0x1
    7539:	shl    edx,0x1c
    753c:	or     r10d,edx
    753f:	btc    r10,0x1d
    7544:	mov    r11d,0xf0000000
    754a:	and    r11,r10
    754d:	movabs rsi,0xffffffff0fffffff
    7557:	and    rbx,rsi
    755a:	or     rbx,r11
    755d:	pop    r11
    755f:	pop    r10
    7561:	pop    rsi
    7562:	pop    rdx
    7563:	mov    QWORD PTR [r12+0x108],rbx
    756b:	stmxcsr DWORD PTR [r12-0x28]
    7571:	mov    r10d,DWORD PTR [r12-0x28]
    7576:	test   r10d,0x3f
    757d:	je     0x75a2
    7583:	mov    r11d,r10d
    7586:	shr    r10d,1
    7589:	and    r10d,0x1e
    758d:	and    r11d,0x1
    7591:	or     r10d,r11d
    7594:	or     DWORD PTR [r12+0x314],r10d
    759c:	and    DWORD PTR [r12-0x28],0xffffffc0
    75a2:	ldmxcsr DWORD PTR [r12-0x38]
    75a8:	lea    rdi,[rsp+0x110]
    75b0:	lea    rsi,[rsp+0xf0]
    75b8:	lea    rdx,[rsp+0x100]
    75c0:	mov    ecx,0x14
    75c5:	mov    r8d,0x0
    75cb:	lea    r9,[r12+0x314]
    75d3:	movabs r11,0x590d850f6650
    75dd:	call   r11
    75e0:	ldmxcsr DWORD PTR [r12-0x28]
    75e6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75ec:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75f2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75f8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75fe:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7604:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    760e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7618:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7622:	mov    rbx,QWORD PTR [r12+0x108]
    762a:	mov    QWORD PTR [r12+0x378],0x2
    7636:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    763f:	mov    rdx,rbx
    7642:	shr    rdx,0x10
    7646:	and    edx,0xc000
    764c:	mov    rax,rbx
    764f:	shr    rax,0x15
    7653:	and    eax,0x100
    7658:	xor    eax,0x100
    765d:	or     edx,eax
    765f:	mov    rax,rbx
    7662:	shr    rax,0x1c
    7666:	and    eax,0x1
    7669:	or     edx,eax
    766b:	mov    QWORD PTR [rsp+0x10],rdx
    7670:	add    rsp,0x8
    7674:	ret
    7675:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7680:	sub    rsp,0x8
    7684:	mov    QWORD PTR [r12+0x378],0x3
    7690:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7696:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    769c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    76a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    76a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    76ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    76b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    76be:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    76c8:	push   rdx
    76c9:	push   rsi
    76ca:	push   r10
    76cc:	push   r11
    76ce:	mov    rdx,QWORD PTR [rsp+0x30]
    76d3:	mov    r10d,edx
    76d6:	and    r10d,0xc000
    76dd:	shl    r10d,0x10
    76e1:	mov    r11d,edx
    76e4:	and    r11d,0x100
    76eb:	shl    r11d,0x15
    76ef:	or     r10d,r11d
    76f2:	and    edx,0x1
    76f5:	shl    edx,0x1c
    76f8:	or     r10d,edx
    76fb:	btc    r10,0x1d
    7700:	mov    r11d,0xf0000000
    7706:	and    r11,r10
    7709:	movabs rsi,0xffffffff0fffffff
    7713:	and    rbx,rsi
    7716:	or     rbx,r11
    7719:	pop    r11
    771b:	pop    r10
    771d:	pop    rsi
    771e:	pop    rdx
    771f:	mov    QWORD PTR [r12+0x108],rbx
    7727:	stmxcsr DWORD PTR [r12-0x28]
    772d:	mov    r10d,DWORD PTR [r12-0x28]
    7732:	test   r10d,0x3f
    7739:	je     0x775e
    773f:	mov    r11d,r10d
    7742:	shr    r10d,1
    7745:	and    r10d,0x1e
    7749:	and    r11d,0x1
    774d:	or     r10d,r11d
    7750:	or     DWORD PTR [r12+0x314],r10d
    7758:	and    DWORD PTR [r12-0x28],0xffffffc0
    775e:	ldmxcsr DWORD PTR [r12-0x38]
    7764:	lea    rdi,[rsp+0x110]
    776c:	lea    rsi,[rsp+0xf0]
    7774:	lea    rdx,[rsp+0x100]
    777c:	mov    ecx,0x56
    7781:	mov    r8d,0x0
    7787:	lea    r9,[r12+0x314]
    778f:	movabs r11,0x590d850f6650
    7799:	call   r11
    779c:	ldmxcsr DWORD PTR [r12-0x28]
    77a2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77a8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77ae:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77b4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77ba:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77c0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77c6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77d0:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77da:	mov    rbx,QWORD PTR [r12+0x108]
    77e2:	mov    QWORD PTR [r12+0x378],0x2
    77ee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77f7:	mov    rdx,rbx
    77fa:	shr    rdx,0x10
    77fe:	and    edx,0xc000
    7804:	mov    rax,rbx
    7807:	shr    rax,0x15
    780b:	and    eax,0x100
    7810:	xor    eax,0x100
    7815:	or     edx,eax
    7817:	mov    rax,rbx
    781a:	shr    rax,0x1c
    781e:	and    eax,0x1
    7821:	or     edx,eax
    7823:	mov    QWORD PTR [rsp+0x10],rdx
    7828:	add    rsp,0x8
    782c:	ret
    782d:	nop    DWORD PTR [rax]
    7830:	sub    rsp,0x8
    7834:	mov    QWORD PTR [r12+0x378],0x3
    7840:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7846:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    784c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7852:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7858:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    785e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7864:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    786e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7878:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7882:	push   rdx
    7883:	push   rsi
    7884:	push   r10
    7886:	push   r11
    7888:	mov    rdx,QWORD PTR [rsp+0x30]
    788d:	mov    r10d,edx
    7890:	and    r10d,0xc000
    7897:	shl    r10d,0x10
    789b:	mov    r11d,edx
    789e:	and    r11d,0x100
    78a5:	shl    r11d,0x15
    78a9:	or     r10d,r11d
    78ac:	and    edx,0x1
    78af:	shl    edx,0x1c
    78b2:	or     r10d,edx
    78b5:	btc    r10,0x1d
    78ba:	mov    r11d,0xf0000000
    78c0:	and    r11,r10
    78c3:	movabs rsi,0xffffffff0fffffff
    78cd:	and    rbx,rsi
    78d0:	or     rbx,r11
    78d3:	pop    r11
    78d5:	pop    r10
    78d7:	pop    rsi
    78d8:	pop    rdx
    78d9:	mov    QWORD PTR [r12+0x108],rbx
    78e1:	stmxcsr DWORD PTR [r12-0x28]
    78e7:	mov    r10d,DWORD PTR [r12-0x28]
    78ec:	test   r10d,0x3f
    78f3:	je     0x7918
    78f9:	mov    r11d,r10d
    78fc:	shr    r10d,1
    78ff:	and    r10d,0x1e
    7903:	and    r11d,0x1
    7907:	or     r10d,r11d
    790a:	or     DWORD PTR [r12+0x314],r10d
    7912:	and    DWORD PTR [r12-0x28],0xffffffc0
    7918:	ldmxcsr DWORD PTR [r12-0x38]
    791e:	lea    rdi,[rsp+0x110]
    7926:	lea    rsi,[rsp+0xf0]
    792e:	lea    rdx,[rsp+0x100]
    7936:	mov    ecx,0x14
    793b:	mov    r8d,0x0
    7941:	lea    r9,[r12+0x314]
    7949:	movabs r11,0x590d850f6650
    7953:	call   r11
    7956:	ldmxcsr DWORD PTR [r12-0x28]
    795c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7962:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7968:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    796e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7974:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    797a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7980:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    798a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7994:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    799e:	mov    rbx,QWORD PTR [r12+0x108]
    79a6:	mov    QWORD PTR [r12+0x378],0x2
    79b2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    79bb:	mov    rdx,rbx
    79be:	shr    rdx,0x10
    79c2:	and    edx,0xc000
    79c8:	mov    rax,rbx
    79cb:	shr    rax,0x15
    79cf:	and    eax,0x100
    79d4:	xor    eax,0x100
    79d9:	or     edx,eax
    79db:	mov    rax,rbx
    79de:	shr    rax,0x1c
    79e2:	and    eax,0x1
    79e5:	or     edx,eax
    79e7:	mov    QWORD PTR [rsp+0x10],rdx
    79ec:	add    rsp,0x8
    79f0:	ret
    79f1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7a00:	sub    rsp,0x8
    7a04:	mov    QWORD PTR [r12+0x378],0x3
    7a10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7a16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7a1c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7a22:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7a28:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7a32:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7a3c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7a46:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7a50:	push   rdx
    7a51:	push   rsi
    7a52:	push   r10
    7a54:	push   r11
    7a56:	mov    rdx,QWORD PTR [rsp+0x30]
    7a5b:	mov    r10d,edx
    7a5e:	and    r10d,0xc000
    7a65:	shl    r10d,0x10
    7a69:	mov    r11d,edx
    7a6c:	and    r11d,0x100
    7a73:	shl    r11d,0x15
    7a77:	or     r10d,r11d
    7a7a:	and    edx,0x1
    7a7d:	shl    edx,0x1c
    7a80:	or     r10d,edx
    7a83:	btc    r10,0x1d
    7a88:	mov    r11d,0xf0000000
    7a8e:	and    r11,r10
    7a91:	movabs rsi,0xffffffff0fffffff
    7a9b:	and    rbx,rsi
    7a9e:	or     rbx,r11
    7aa1:	pop    r11
    7aa3:	pop    r10
    7aa5:	pop    rsi
    7aa6:	pop    rdx
    7aa7:	mov    QWORD PTR [r12+0x108],rbx
    7aaf:	stmxcsr DWORD PTR [r12-0x28]
    7ab5:	mov    r10d,DWORD PTR [r12-0x28]
    7aba:	test   r10d,0x3f
    7ac1:	je     0x7ae6
    7ac7:	mov    r11d,r10d
    7aca:	shr    r10d,1
    7acd:	and    r10d,0x1e
    7ad1:	and    r11d,0x1
    7ad5:	or     r10d,r11d
    7ad8:	or     DWORD PTR [r12+0x314],r10d
    7ae0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7ae6:	ldmxcsr DWORD PTR [r12-0x38]
    7aec:	lea    rdi,[rsp+0x110]
    7af4:	lea    rsi,[rsp+0xf0]
    7afc:	lea    rdx,[rsp+0x100]
    7b04:	mov    ecx,0x14
    7b09:	mov    r8d,0x0
    7b0f:	lea    r9,[r12+0x314]
    7b17:	movabs r11,0x590d850f6650
    7b21:	call   r11
    7b24:	ldmxcsr DWORD PTR [r12-0x28]
    7b2a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7b30:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7b36:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7b3c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7b42:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7b4c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7b56:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7b60:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7b6a:	mov    rbx,QWORD PTR [r12+0x108]
    7b72:	mov    QWORD PTR [r12+0x378],0x2
    7b7e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7b87:	mov    rdx,rbx
    7b8a:	shr    rdx,0x10
    7b8e:	and    edx,0xc000
    7b94:	mov    rax,rbx
    7b97:	shr    rax,0x15
    7b9b:	and    eax,0x100
    7ba0:	xor    eax,0x100
    7ba5:	or     edx,eax
    7ba7:	mov    rax,rbx
    7baa:	shr    rax,0x1c
    7bae:	and    eax,0x1
    7bb1:	or     edx,eax
    7bb3:	mov    QWORD PTR [rsp+0x10],rdx
    7bb8:	add    rsp,0x8
    7bbc:	ret
    7bbd:	nop    DWORD PTR [rax]
    7bc0:	sub    rsp,0x8
    7bc4:	mov    QWORD PTR [r12+0x378],0x3
    7bd0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7bd6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7bdc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7be2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7be8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7bee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7bf8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c02:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c0c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c16:	push   rdx
    7c17:	push   rsi
    7c18:	push   r10
    7c1a:	push   r11
    7c1c:	mov    rdx,QWORD PTR [rsp+0x30]
    7c21:	mov    r10d,edx
    7c24:	and    r10d,0xc000
    7c2b:	shl    r10d,0x10
    7c2f:	mov    r11d,edx
    7c32:	and    r11d,0x100
    7c39:	shl    r11d,0x15
    7c3d:	or     r10d,r11d
    7c40:	and    edx,0x1
    7c43:	shl    edx,0x1c
    7c46:	or     r10d,edx
    7c49:	btc    r10,0x1d
    7c4e:	mov    r11d,0xf0000000
    7c54:	and    r11,r10
    7c57:	movabs rsi,0xffffffff0fffffff
    7c61:	and    rbx,rsi
    7c64:	or     rbx,r11
    7c67:	pop    r11
    7c69:	pop    r10
    7c6b:	pop    rsi
    7c6c:	pop    rdx
    7c6d:	mov    QWORD PTR [r12+0x108],rbx
    7c75:	stmxcsr DWORD PTR [r12-0x28]
    7c7b:	mov    r10d,DWORD PTR [r12-0x28]
    7c80:	test   r10d,0x3f
    7c87:	je     0x7cac
    7c8d:	mov    r11d,r10d
    7c90:	shr    r10d,1
    7c93:	and    r10d,0x1e
    7c97:	and    r11d,0x1
    7c9b:	or     r10d,r11d
    7c9e:	or     DWORD PTR [r12+0x314],r10d
    7ca6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7cac:	ldmxcsr DWORD PTR [r12-0x38]
    7cb2:	lea    rdi,[rsp+0x110]
    7cba:	lea    rsi,[rsp+0xf0]
    7cc2:	lea    rdx,[rsp+0x100]
    7cca:	mov    ecx,0x14
    7ccf:	mov    r8d,0x0
    7cd5:	lea    r9,[r12+0x314]
    7cdd:	movabs r11,0x590d850f6650
    7ce7:	call   r11
    7cea:	ldmxcsr DWORD PTR [r12-0x28]
    7cf0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7cf6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7cfc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7d02:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7d08:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7d0e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7d18:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7d22:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7d2c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7d36:	mov    rbx,QWORD PTR [r12+0x108]
    7d3e:	mov    QWORD PTR [r12+0x378],0x2
    7d4a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7d53:	mov    rdx,rbx
    7d56:	shr    rdx,0x10
    7d5a:	and    edx,0xc000
    7d60:	mov    rax,rbx
    7d63:	shr    rax,0x15
    7d67:	and    eax,0x100
    7d6c:	xor    eax,0x100
    7d71:	or     edx,eax
    7d73:	mov    rax,rbx
    7d76:	shr    rax,0x1c
    7d7a:	and    eax,0x1
    7d7d:	or     edx,eax
    7d7f:	mov    QWORD PTR [rsp+0x10],rdx
    7d84:	add    rsp,0x8
    7d88:	ret
    7d89:	nop    DWORD PTR [rax+0x0]
    7d90:	sub    rsp,0x8
    7d94:	mov    QWORD PTR [r12+0x378],0x3
    7da0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7da6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7dac:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7db2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7db8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7dbe:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7dc8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7dd2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7ddc:	push   rdx
    7ddd:	push   rsi
    7dde:	push   r10
    7de0:	push   r11
    7de2:	mov    rdx,QWORD PTR [rsp+0x30]
    7de7:	mov    r10d,edx
    7dea:	and    r10d,0xc000
    7df1:	shl    r10d,0x10
    7df5:	mov    r11d,edx
    7df8:	and    r11d,0x100
    7dff:	shl    r11d,0x15
    7e03:	or     r10d,r11d
    7e06:	and    edx,0x1
    7e09:	shl    edx,0x1c
    7e0c:	or     r10d,edx
    7e0f:	btc    r10,0x1d
    7e14:	mov    r11d,0xf0000000
    7e1a:	and    r11,r10
    7e1d:	movabs rsi,0xffffffff0fffffff
    7e27:	and    rbx,rsi
    7e2a:	or     rbx,r11
    7e2d:	pop    r11
    7e2f:	pop    r10
    7e31:	pop    rsi
    7e32:	pop    rdx
    7e33:	mov    QWORD PTR [r12+0x108],rbx
    7e3b:	stmxcsr DWORD PTR [r12-0x28]
    7e41:	mov    r10d,DWORD PTR [r12-0x28]
    7e46:	test   r10d,0x3f
    7e4d:	je     0x7e72
    7e53:	mov    r11d,r10d
    7e56:	shr    r10d,1
    7e59:	and    r10d,0x1e
    7e5d:	and    r11d,0x1
    7e61:	or     r10d,r11d
    7e64:	or     DWORD PTR [r12+0x314],r10d
    7e6c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7e72:	ldmxcsr DWORD PTR [r12-0x38]
    7e78:	lea    rdi,[rsp+0x110]
    7e80:	lea    rsi,[rsp+0xf0]
    7e88:	lea    rdx,[rsp+0x100]
    7e90:	mov    ecx,0x56
    7e95:	mov    r8d,0x0
    7e9b:	lea    r9,[r12+0x314]
    7ea3:	movabs r11,0x590d850f6650
    7ead:	call   r11
    7eb0:	ldmxcsr DWORD PTR [r12-0x28]
    7eb6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7ebc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7ec2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7ec8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7ece:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7ed4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7ede:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7ee8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7ef2:	mov    rbx,QWORD PTR [r12+0x108]
    7efa:	mov    QWORD PTR [r12+0x378],0x2
    7f06:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f0f:	mov    rdx,rbx
    7f12:	shr    rdx,0x10
    7f16:	and    edx,0xc000
    7f1c:	mov    rax,rbx
    7f1f:	shr    rax,0x15
    7f23:	and    eax,0x100
    7f28:	xor    eax,0x100
    7f2d:	or     edx,eax
    7f2f:	mov    rax,rbx
    7f32:	shr    rax,0x1c
    7f36:	and    eax,0x1
    7f39:	or     edx,eax
    7f3b:	mov    QWORD PTR [rsp+0x10],rdx
    7f40:	add    rsp,0x8
    7f44:	ret
    7f45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f50:	sub    rsp,0x8
    7f54:	mov    QWORD PTR [r12+0x378],0x3
    7f60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f72:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f7e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f88:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f92:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f9c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7fa6:	push   rdx
    7fa7:	push   rsi
    7fa8:	push   r10
    7faa:	push   r11
    7fac:	mov    rdx,QWORD PTR [rsp+0x30]
    7fb1:	mov    r10d,edx
    7fb4:	and    r10d,0xc000
    7fbb:	shl    r10d,0x10
    7fbf:	mov    r11d,edx
    7fc2:	and    r11d,0x100
    7fc9:	shl    r11d,0x15
    7fcd:	or     r10d,r11d
    7fd0:	and    edx,0x1
    7fd3:	shl    edx,0x1c
    7fd6:	or     r10d,edx
    7fd9:	btc    r10,0x1d
    7fde:	mov    r11d,0xf0000000
    7fe4:	and    r11,r10
    7fe7:	movabs rsi,0xffffffff0fffffff
    7ff1:	and    rbx,rsi
    7ff4:	or     rbx,r11
    7ff7:	pop    r11
    7ff9:	pop    r10
    7ffb:	pop    rsi
    7ffc:	pop    rdx
    7ffd:	mov    QWORD PTR [r12+0x108],rbx
    8005:	stmxcsr DWORD PTR [r12-0x28]
    800b:	mov    r10d,DWORD PTR [r12-0x28]
    8010:	test   r10d,0x3f
    8017:	je     0x803c
    801d:	mov    r11d,r10d
    8020:	shr    r10d,1
    8023:	and    r10d,0x1e
    8027:	and    r11d,0x1
    802b:	or     r10d,r11d
    802e:	or     DWORD PTR [r12+0x314],r10d
    8036:	and    DWORD PTR [r12-0x28],0xffffffc0
    803c:	ldmxcsr DWORD PTR [r12-0x38]
    8042:	lea    rdi,[rsp+0x110]
    804a:	lea    rsi,[rsp+0xf0]
    8052:	lea    rdx,[rsp+0x100]
    805a:	mov    ecx,0x56
    805f:	mov    r8d,0x0
    8065:	lea    r9,[r12+0x314]
    806d:	movabs r11,0x590d850f6650
    8077:	call   r11
    807a:	ldmxcsr DWORD PTR [r12-0x28]
    8080:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8086:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    808c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8092:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8098:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    809e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    80a8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    80b2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    80bc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    80c6:	mov    rbx,QWORD PTR [r12+0x108]
    80ce:	mov    QWORD PTR [r12+0x378],0x2
    80da:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    80e3:	mov    rdx,rbx
    80e6:	shr    rdx,0x10
    80ea:	and    edx,0xc000
    80f0:	mov    rax,rbx
    80f3:	shr    rax,0x15
    80f7:	and    eax,0x100
    80fc:	xor    eax,0x100
    8101:	or     edx,eax
    8103:	mov    rax,rbx
    8106:	shr    rax,0x1c
    810a:	and    eax,0x1
    810d:	or     edx,eax
    810f:	mov    QWORD PTR [rsp+0x10],rdx
    8114:	add    rsp,0x8
    8118:	ret
    8119:	nop    DWORD PTR [rax+0x0]
    8120:	sub    rsp,0x8
    8124:	mov    QWORD PTR [r12+0x378],0x3
    8130:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8136:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    813c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    8142:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    8148:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    814e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    8158:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8162:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    816c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    8176:	push   rdx
    8177:	push   rsi
    8178:	push   r10
    817a:	push   r11
    817c:	mov    rdx,QWORD PTR [rsp+0x30]
    8181:	mov    r10d,edx
    8184:	and    r10d,0xc000
    818b:	shl    r10d,0x10
    818f:	mov    r11d,edx
    8192:	and    r11d,0x100
    8199:	shl    r11d,0x15
    819d:	or     r10d,r11d
    81a0:	and    edx,0x1
    81a3:	shl    edx,0x1c
    81a6:	or     r10d,edx
    81a9:	btc    r10,0x1d
    81ae:	mov    r11d,0xf0000000
    81b4:	and    r11,r10
    81b7:	movabs rsi,0xffffffff0fffffff
    81c1:	and    rbx,rsi
    81c4:	or     rbx,r11
    81c7:	pop    r11
    81c9:	pop    r10
    81cb:	pop    rsi
    81cc:	pop    rdx
    81cd:	mov    QWORD PTR [r12+0x108],rbx
    81d5:	stmxcsr DWORD PTR [r12-0x28]
    81db:	mov    r10d,DWORD PTR [r12-0x28]
    81e0:	test   r10d,0x3f
    81e7:	je     0x820c
    81ed:	mov    r11d,r10d
    81f0:	shr    r10d,1
    81f3:	and    r10d,0x1e
    81f7:	and    r11d,0x1
    81fb:	or     r10d,r11d
    81fe:	or     DWORD PTR [r12+0x314],r10d
    8206:	and    DWORD PTR [r12-0x28],0xffffffc0
    820c:	ldmxcsr DWORD PTR [r12-0x38]
    8212:	lea    rdi,[rsp+0x110]
    821a:	lea    rsi,[rsp+0xf0]
    8222:	lea    rdx,[rsp+0x100]
    822a:	mov    ecx,0x14
    822f:	mov    r8d,0x0
    8235:	lea    r9,[r12+0x314]
    823d:	movabs r11,0x590d850f6650
    8247:	call   r11
    824a:	ldmxcsr DWORD PTR [r12-0x28]
    8250:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8256:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    825c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8262:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    8268:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    826e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    8278:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8282:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    828c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    8296:	mov    rbx,QWORD PTR [r12+0x108]
    829e:	mov    QWORD PTR [r12+0x378],0x2
    82aa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    82b3:	mov    rdx,rbx
    82b6:	shr    rdx,0x10
    82ba:	and    edx,0xc000
    82c0:	mov    rax,rbx
    82c3:	shr    rax,0x15
    82c7:	and    eax,0x100
    82cc:	xor    eax,0x100
    82d1:	or     edx,eax
    82d3:	mov    rax,rbx
    82d6:	shr    rax,0x1c
    82da:	and    eax,0x1
    82dd:	or     edx,eax
    82df:	mov    QWORD PTR [rsp+0x10],rdx
    82e4:	add    rsp,0x8
    82e8:	ret
    82e9:	nop    DWORD PTR [rax+0x0]
    82f0:	sub    rsp,0x8
    82f4:	mov    QWORD PTR [r12+0x378],0x3
    8300:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8306:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    830c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8312:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    8318:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    831e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    8328:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    8332:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    833c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    8346:	push   rdx
    8347:	push   rsi
    8348:	push   r10
    834a:	push   r11
    834c:	mov    rdx,QWORD PTR [rsp+0x30]
    8351:	mov    r10d,edx
    8354:	and    r10d,0xc000
    835b:	shl    r10d,0x10
    835f:	mov    r11d,edx
    8362:	and    r11d,0x100
    8369:	shl    r11d,0x15
    836d:	or     r10d,r11d
    8370:	and    edx,0x1
    8373:	shl    edx,0x1c
    8376:	or     r10d,edx
    8379:	btc    r10,0x1d
    837e:	mov    r11d,0xf0000000
    8384:	and    r11,r10
    8387:	movabs rsi,0xffffffff0fffffff
    8391:	and    rbx,rsi
    8394:	or     rbx,r11
    8397:	pop    r11
    8399:	pop    r10
    839b:	pop    rsi
    839c:	pop    rdx
    839d:	mov    QWORD PTR [r12+0x108],rbx
    83a5:	stmxcsr DWORD PTR [r12-0x28]
    83ab:	mov    r10d,DWORD PTR [r12-0x28]
    83b0:	test   r10d,0x3f
    83b7:	je     0x83dc
    83bd:	mov    r11d,r10d
    83c0:	shr    r10d,1
    83c3:	and    r10d,0x1e
    83c7:	and    r11d,0x1
    83cb:	or     r10d,r11d
    83ce:	or     DWORD PTR [r12+0x314],r10d
    83d6:	and    DWORD PTR [r12-0x28],0xffffffc0
    83dc:	ldmxcsr DWORD PTR [r12-0x38]
    83e2:	lea    rdi,[rsp+0x110]
    83ea:	lea    rsi,[rsp+0xf0]
    83f2:	lea    rdx,[rsp+0x100]
    83fa:	mov    ecx,0x56
    83ff:	mov    r8d,0x0
    8405:	lea    r9,[r12+0x314]
    840d:	movabs r11,0x590d850f6650
    8417:	call   r11
    841a:	ldmxcsr DWORD PTR [r12-0x28]
    8420:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8426:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    842c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8432:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    8438:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    843e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    8448:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    8452:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    845c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    8466:	mov    rbx,QWORD PTR [r12+0x108]
    846e:	mov    QWORD PTR [r12+0x378],0x2
    847a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8483:	mov    rdx,rbx
    8486:	shr    rdx,0x10
    848a:	and    edx,0xc000
    8490:	mov    rax,rbx
    8493:	shr    rax,0x15
    8497:	and    eax,0x100
    849c:	xor    eax,0x100
    84a1:	or     edx,eax
    84a3:	mov    rax,rbx
    84a6:	shr    rax,0x1c
    84aa:	and    eax,0x1
    84ad:	or     edx,eax
    84af:	mov    QWORD PTR [rsp+0x10],rdx
    84b4:	add    rsp,0x8
    84b8:	ret
    84b9:	nop    DWORD PTR [rax+0x0]
    84c0:	sub    rsp,0x8
    84c4:	mov    QWORD PTR [r12+0x378],0x3
    84d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    84d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    84dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    84e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    84e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    84ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    84f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    8502:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    850c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    8516:	push   rdx
    8517:	push   rsi
    8518:	push   r10
    851a:	push   r11
    851c:	mov    rdx,QWORD PTR [rsp+0x30]
    8521:	mov    r10d,edx
    8524:	and    r10d,0xc000
    852b:	shl    r10d,0x10
    852f:	mov    r11d,edx
    8532:	and    r11d,0x100
    8539:	shl    r11d,0x15
    853d:	or     r10d,r11d
    8540:	and    edx,0x1
    8543:	shl    edx,0x1c
    8546:	or     r10d,edx
    8549:	btc    r10,0x1d
    854e:	mov    r11d,0xf0000000
    8554:	and    r11,r10
    8557:	movabs rsi,0xffffffff0fffffff
    8561:	and    rbx,rsi
    8564:	or     rbx,r11
    8567:	pop    r11
    8569:	pop    r10
    856b:	pop    rsi
    856c:	pop    rdx
    856d:	mov    QWORD PTR [r12+0x108],rbx
    8575:	stmxcsr DWORD PTR [r12-0x28]
    857b:	mov    r10d,DWORD PTR [r12-0x28]
    8580:	test   r10d,0x3f
    8587:	je     0x85ac
    858d:	mov    r11d,r10d
    8590:	shr    r10d,1
    8593:	and    r10d,0x1e
    8597:	and    r11d,0x1
    859b:	or     r10d,r11d
    859e:	or     DWORD PTR [r12+0x314],r10d
    85a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    85ac:	ldmxcsr DWORD PTR [r12-0x38]
    85b2:	lea    rdi,[rsp+0x110]
    85ba:	lea    rsi,[rsp+0xf0]
    85c2:	lea    rdx,[rsp+0x100]
    85ca:	mov    ecx,0x14
    85cf:	mov    r8d,0x0
    85d5:	lea    r9,[r12+0x314]
    85dd:	movabs r11,0x590d850f6650
    85e7:	call   r11
    85ea:	ldmxcsr DWORD PTR [r12-0x28]
    85f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    85f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    85fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8602:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    8608:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    860e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    8618:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    8622:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    862c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    8636:	mov    rbx,QWORD PTR [r12+0x108]
    863e:	mov    QWORD PTR [r12+0x378],0x2
    864a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8653:	mov    rdx,rbx
    8656:	shr    rdx,0x10
    865a:	and    edx,0xc000
    8660:	mov    rax,rbx
    8663:	shr    rax,0x15
    8667:	and    eax,0x100
    866c:	xor    eax,0x100
    8671:	or     edx,eax
    8673:	mov    rax,rbx
    8676:	shr    rax,0x1c
    867a:	and    eax,0x1
    867d:	or     edx,eax
    867f:	mov    QWORD PTR [rsp+0x10],rdx
    8684:	add    rsp,0x8
    8688:	ret
    8689:	nop    DWORD PTR [rax+0x0]
    8690:	sub    rsp,0x8
    8694:	mov    QWORD PTR [r12+0x378],0x3
    86a0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    86a6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    86ac:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    86b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    86b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    86be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    86c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    86d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    86dc:	push   rdx
    86dd:	push   rsi
    86de:	push   r10
    86e0:	push   r11
    86e2:	mov    rdx,QWORD PTR [rsp+0x30]
    86e7:	mov    r10d,edx
    86ea:	and    r10d,0xc000
    86f1:	shl    r10d,0x10
    86f5:	mov    r11d,edx
    86f8:	and    r11d,0x100
    86ff:	shl    r11d,0x15
    8703:	or     r10d,r11d
    8706:	and    edx,0x1
    8709:	shl    edx,0x1c
    870c:	or     r10d,edx
    870f:	btc    r10,0x1d
    8714:	mov    r11d,0xf0000000
    871a:	and    r11,r10
    871d:	movabs rsi,0xffffffff0fffffff
    8727:	and    rbx,rsi
    872a:	or     rbx,r11
    872d:	pop    r11
    872f:	pop    r10
    8731:	pop    rsi
    8732:	pop    rdx
    8733:	mov    QWORD PTR [r12+0x108],rbx
    873b:	stmxcsr DWORD PTR [r12-0x28]
    8741:	mov    r10d,DWORD PTR [r12-0x28]
    8746:	test   r10d,0x3f
    874d:	je     0x8772
    8753:	mov    r11d,r10d
    8756:	shr    r10d,1
    8759:	and    r10d,0x1e
    875d:	and    r11d,0x1
    8761:	or     r10d,r11d
    8764:	or     DWORD PTR [r12+0x314],r10d
    876c:	and    DWORD PTR [r12-0x28],0xffffffc0
    8772:	ldmxcsr DWORD PTR [r12-0x38]
    8778:	lea    rdi,[rsp+0x110]
    8780:	lea    rsi,[rsp+0xf0]
    8788:	lea    rdx,[rsp+0x100]
    8790:	mov    ecx,0x14
    8795:	mov    r8d,0x0
    879b:	lea    r9,[r12+0x314]
    87a3:	movabs r11,0x590d850f6650
    87ad:	call   r11
    87b0:	ldmxcsr DWORD PTR [r12-0x28]
    87b6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    87bc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    87c2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    87c8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    87ce:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    87d4:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    87de:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    87e8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    87f2:	mov    rbx,QWORD PTR [r12+0x108]
    87fa:	mov    QWORD PTR [r12+0x378],0x2
    8806:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    880f:	mov    rdx,rbx
    8812:	shr    rdx,0x10
    8816:	and    edx,0xc000
    881c:	mov    rax,rbx
    881f:	shr    rax,0x15
    8823:	and    eax,0x100
    8828:	xor    eax,0x100
    882d:	or     edx,eax
    882f:	mov    rax,rbx
    8832:	shr    rax,0x1c
    8836:	and    eax,0x1
    8839:	or     edx,eax
    883b:	mov    QWORD PTR [rsp+0x10],rdx
    8840:	add    rsp,0x8
    8844:	ret
    8845:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    8850:	sub    rsp,0x8
    8854:	mov    QWORD PTR [r12+0x378],0x3
    8860:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8866:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    886c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    8872:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8878:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    887e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    8888:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8892:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    889c:	push   rdx
    889d:	push   rsi
    889e:	push   r10
    88a0:	push   r11
    88a2:	mov    rdx,QWORD PTR [rsp+0x30]
    88a7:	mov    r10d,edx
    88aa:	and    r10d,0xc000
    88b1:	shl    r10d,0x10
    88b5:	mov    r11d,edx
    88b8:	and    r11d,0x100
    88bf:	shl    r11d,0x15
    88c3:	or     r10d,r11d
    88c6:	and    edx,0x1
    88c9:	shl    edx,0x1c
    88cc:	or     r10d,edx
    88cf:	btc    r10,0x1d
    88d4:	mov    r11d,0xf0000000
    88da:	and    r11,r10
    88dd:	movabs rsi,0xffffffff0fffffff
    88e7:	and    rbx,rsi
    88ea:	or     rbx,r11
    88ed:	pop    r11
    88ef:	pop    r10
    88f1:	pop    rsi
    88f2:	pop    rdx
    88f3:	mov    QWORD PTR [r12+0x108],rbx
    88fb:	stmxcsr DWORD PTR [r12-0x28]
    8901:	mov    r10d,DWORD PTR [r12-0x28]
    8906:	test   r10d,0x3f
    890d:	je     0x8932
    8913:	mov    r11d,r10d
    8916:	shr    r10d,1
    8919:	and    r10d,0x1e
    891d:	and    r11d,0x1
    8921:	or     r10d,r11d
    8924:	or     DWORD PTR [r12+0x314],r10d
    892c:	and    DWORD PTR [r12-0x28],0xffffffc0
    8932:	ldmxcsr DWORD PTR [r12-0x38]
    8938:	lea    rdi,[rsp+0x110]
    8940:	lea    rsi,[rsp+0xf0]
    8948:	lea    rdx,[rsp+0x100]
    8950:	mov    ecx,0x14
    8955:	mov    r8d,0x0
    895b:	lea    r9,[r12+0x314]
    8963:	movabs r11,0x590d850f6650
    896d:	call   r11
    8970:	ldmxcsr DWORD PTR [r12-0x28]
    8976:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    897c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    8982:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8988:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    898e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    8994:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    899e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    89a8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    89b2:	mov    rbx,QWORD PTR [r12+0x108]
    89ba:	mov    QWORD PTR [r12+0x378],0x2
    89c6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    89cf:	mov    rdx,rbx
    89d2:	shr    rdx,0x10
    89d6:	and    edx,0xc000
    89dc:	mov    rax,rbx
    89df:	shr    rax,0x15
    89e3:	and    eax,0x100
    89e8:	xor    eax,0x100
    89ed:	or     edx,eax
    89ef:	mov    rax,rbx
    89f2:	shr    rax,0x1c
    89f6:	and    eax,0x1
    89f9:	or     edx,eax
    89fb:	mov    QWORD PTR [rsp+0x10],rdx
    8a00:	add    rsp,0x8
    8a04:	ret
    8a05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    8a10:	sub    rsp,0x8
    8a14:	mov    QWORD PTR [r12+0x378],0x3
    8a20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8a26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    8a2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    8a32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8a38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    8a3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    8a44:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8a4e:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    8a58:	push   rdx
    8a59:	push   rsi
    8a5a:	push   r10
    8a5c:	push   r11
    8a5e:	mov    rdx,QWORD PTR [rsp+0x30]
    8a63:	mov    r10d,edx
    8a66:	and    r10d,0xc000
    8a6d:	shl    r10d,0x10
    8a71:	mov    r11d,edx
    8a74:	and    r11d,0x100
    8a7b:	shl    r11d,0x15
    8a7f:	or     r10d,r11d
    8a82:	and    edx,0x1
    8a85:	shl    edx,0x1c
    8a88:	or     r10d,edx
    8a8b:	btc    r10,0x1d
    8a90:	mov    r11d,0xf0000000
    8a96:	and    r11,r10
    8a99:	movabs rsi,0xffffffff0fffffff
    8aa3:	and    rbx,rsi
    8aa6:	or     rbx,r11
    8aa9:	pop    r11
    8aab:	pop    r10
    8aad:	pop    rsi
    8aae:	pop    rdx
    8aaf:	mov    QWORD PTR [r12+0x108],rbx
    8ab7:	stmxcsr DWORD PTR [r12-0x28]
    8abd:	mov    r10d,DWORD PTR [r12-0x28]
    8ac2:	test   r10d,0x3f
    8ac9:	je     0x8aee
    8acf:	mov    r11d,r10d
    8ad2:	shr    r10d,1
    8ad5:	and    r10d,0x1e
    8ad9:	and    r11d,0x1
    8add:	or     r10d,r11d
    8ae0:	or     DWORD PTR [r12+0x314],r10d
    8ae8:	and    DWORD PTR [r12-0x28],0xffffffc0
    8aee:	ldmxcsr DWORD PTR [r12-0x38]
    8af4:	lea    rdi,[rsp+0x110]
    8afc:	lea    rsi,[rsp+0xf0]
    8b04:	lea    rdx,[rsp+0x100]
    8b0c:	mov    ecx,0x56
    8b11:	mov    r8d,0x0
    8b17:	lea    r9,[r12+0x314]
    8b1f:	movabs r11,0x590d850f6650
    8b29:	call   r11
    8b2c:	ldmxcsr DWORD PTR [r12-0x28]
    8b32:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8b38:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    8b3e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8b44:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8b4a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    8b50:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    8b56:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8b60:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    8b6a:	mov    rbx,QWORD PTR [r12+0x108]
    8b72:	mov    QWORD PTR [r12+0x378],0x2
    8b7e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8b87:	mov    rdx,rbx
    8b8a:	shr    rdx,0x10
    8b8e:	and    edx,0xc000
    8b94:	mov    rax,rbx
    8b97:	shr    rax,0x15
    8b9b:	and    eax,0x100
    8ba0:	xor    eax,0x100
    8ba5:	or     edx,eax
    8ba7:	mov    rax,rbx
    8baa:	shr    rax,0x1c
    8bae:	and    eax,0x1
    8bb1:	or     edx,eax
    8bb3:	mov    QWORD PTR [rsp+0x10],rdx
    8bb8:	add    rsp,0x8
    8bbc:	ret
    8bbd:	nop    DWORD PTR [rax]
    8bc0:	sub    rsp,0x8
    8bc4:	mov    QWORD PTR [r12+0x378],0x3
    8bd0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8bd6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    8bdc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    8be2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8be8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    8bee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    8bf8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8c02:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    8c0c:	push   rdx
    8c0d:	push   rsi
    8c0e:	push   r10
    8c10:	push   r11
    8c12:	mov    rdx,QWORD PTR [rsp+0x30]
    8c17:	mov    r10d,edx
    8c1a:	and    r10d,0xc000
    8c21:	shl    r10d,0x10
    8c25:	mov    r11d,edx
    8c28:	and    r11d,0x100
    8c2f:	shl    r11d,0x15
    8c33:	or     r10d,r11d
    8c36:	and    edx,0x1
    8c39:	shl    edx,0x1c
    8c3c:	or     r10d,edx
    8c3f:	btc    r10,0x1d
    8c44:	mov    r11d,0xf0000000
    8c4a:	and    r11,r10
    8c4d:	movabs rsi,0xffffffff0fffffff
    8c57:	and    rbx,rsi
    8c5a:	or     rbx,r11
    8c5d:	pop    r11
    8c5f:	pop    r10
    8c61:	pop    rsi
    8c62:	pop    rdx
    8c63:	mov    QWORD PTR [r12+0x108],rbx
    8c6b:	stmxcsr DWORD PTR [r12-0x28]
    8c71:	mov    r10d,DWORD PTR [r12-0x28]
    8c76:	test   r10d,0x3f
    8c7d:	je     0x8ca2
    8c83:	mov    r11d,r10d
    8c86:	shr    r10d,1
    8c89:	and    r10d,0x1e
    8c8d:	and    r11d,0x1
    8c91:	or     r10d,r11d
    8c94:	or     DWORD PTR [r12+0x314],r10d
    8c9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    8ca2:	ldmxcsr DWORD PTR [r12-0x38]
    8ca8:	lea    rdi,[rsp+0x110]
    8cb0:	lea    rsi,[rsp+0xf0]
    8cb8:	lea    rdx,[rsp+0x100]
    8cc0:	mov    ecx,0x56
    8cc5:	mov    r8d,0x0
    8ccb:	lea    r9,[r12+0x314]
    8cd3:	movabs r11,0x590d850f6650
    8cdd:	call   r11
    8ce0:	ldmxcsr DWORD PTR [r12-0x28]
    8ce6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8cec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    8cf2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8cf8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8cfe:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    8d04:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    8d0e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8d18:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    8d22:	mov    rbx,QWORD PTR [r12+0x108]
    8d2a:	mov    QWORD PTR [r12+0x378],0x2
    8d36:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8d3f:	mov    rdx,rbx
    8d42:	shr    rdx,0x10
    8d46:	and    edx,0xc000
    8d4c:	mov    rax,rbx
    8d4f:	shr    rax,0x15
    8d53:	and    eax,0x100
    8d58:	xor    eax,0x100
    8d5d:	or     edx,eax
    8d5f:	mov    rax,rbx
    8d62:	shr    rax,0x1c
    8d66:	and    eax,0x1
    8d69:	or     edx,eax
    8d6b:	mov    QWORD PTR [rsp+0x10],rdx
    8d70:	add    rsp,0x8
    8d74:	ret
    8d75:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    8d80:	sub    rsp,0x8
    8d84:	mov    QWORD PTR [r12+0x378],0x3
    8d90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8d96:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    8d9c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    8da2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8da8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    8dae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    8db4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    8dbe:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8dc8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    8dd2:	push   rdx
    8dd3:	push   rsi
    8dd4:	push   r10
    8dd6:	push   r11
    8dd8:	mov    rdx,QWORD PTR [rsp+0x30]
    8ddd:	mov    r10d,edx
    8de0:	and    r10d,0xc000
    8de7:	shl    r10d,0x10
    8deb:	mov    r11d,edx
    8dee:	and    r11d,0x100
    8df5:	shl    r11d,0x15
    8df9:	or     r10d,r11d
    8dfc:	and    edx,0x1
    8dff:	shl    edx,0x1c
    8e02:	or     r10d,edx
    8e05:	btc    r10,0x1d
    8e0a:	mov    r11d,0xf0000000
    8e10:	and    r11,r10
    8e13:	movabs rsi,0xffffffff0fffffff
    8e1d:	and    rbx,rsi
    8e20:	or     rbx,r11
    8e23:	pop    r11
    8e25:	pop    r10
    8e27:	pop    rsi
    8e28:	pop    rdx
    8e29:	mov    QWORD PTR [r12+0x108],rbx
    8e31:	stmxcsr DWORD PTR [r12-0x28]
    8e37:	mov    r10d,DWORD PTR [r12-0x28]
    8e3c:	test   r10d,0x3f
    8e43:	je     0x8e68
    8e49:	mov    r11d,r10d
    8e4c:	shr    r10d,1
    8e4f:	and    r10d,0x1e
    8e53:	and    r11d,0x1
    8e57:	or     r10d,r11d
    8e5a:	or     DWORD PTR [r12+0x314],r10d
    8e62:	and    DWORD PTR [r12-0x28],0xffffffc0
    8e68:	ldmxcsr DWORD PTR [r12-0x38]
    8e6e:	lea    rdi,[rsp+0x110]
    8e76:	lea    rsi,[rsp+0xf0]
    8e7e:	lea    rdx,[rsp+0x100]
    8e86:	mov    ecx,0x14
    8e8b:	mov    r8d,0x0
    8e91:	lea    r9,[r12+0x314]
    8e99:	movabs r11,0x590d850f6650
    8ea3:	call   r11
    8ea6:	ldmxcsr DWORD PTR [r12-0x28]
    8eac:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8eb2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    8eb8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8ebe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8ec4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    8eca:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    8ed0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    8eda:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8ee4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    8eee:	mov    rbx,QWORD PTR [r12+0x108]
    8ef6:	mov    QWORD PTR [r12+0x378],0x2
    8f02:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8f0b:	mov    rdx,rbx
    8f0e:	shr    rdx,0x10
    8f12:	and    edx,0xc000
    8f18:	mov    rax,rbx
    8f1b:	shr    rax,0x15
    8f1f:	and    eax,0x100
    8f24:	xor    eax,0x100
    8f29:	or     edx,eax
    8f2b:	mov    rax,rbx
    8f2e:	shr    rax,0x1c
    8f32:	and    eax,0x1
    8f35:	or     edx,eax
    8f37:	mov    QWORD PTR [rsp+0x10],rdx
    8f3c:	add    rsp,0x8
    8f40:	ret
    8f41:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    8f50:	sub    rsp,0x8
    8f54:	mov    QWORD PTR [r12+0x378],0x3
    8f60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8f66:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    8f6c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8f72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    8f78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    8f7e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    8f88:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    8f92:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8f9c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    8fa6:	push   rdx
    8fa7:	push   rsi
    8fa8:	push   r10
    8faa:	push   r11
    8fac:	mov    rdx,QWORD PTR [rsp+0x30]
    8fb1:	mov    r10d,edx
    8fb4:	and    r10d,0xc000
    8fbb:	shl    r10d,0x10
    8fbf:	mov    r11d,edx
    8fc2:	and    r11d,0x100
    8fc9:	shl    r11d,0x15
    8fcd:	or     r10d,r11d
    8fd0:	and    edx,0x1
    8fd3:	shl    edx,0x1c
    8fd6:	or     r10d,edx
    8fd9:	btc    r10,0x1d
    8fde:	mov    r11d,0xf0000000
    8fe4:	and    r11,r10
    8fe7:	movabs rsi,0xffffffff0fffffff
    8ff1:	and    rbx,rsi
    8ff4:	or     rbx,r11
    8ff7:	pop    r11
    8ff9:	pop    r10
    8ffb:	pop    rsi
    8ffc:	pop    rdx
    8ffd:	mov    QWORD PTR [r12+0x108],rbx
    9005:	stmxcsr DWORD PTR [r12-0x28]
    900b:	mov    r10d,DWORD PTR [r12-0x28]
    9010:	test   r10d,0x3f
    9017:	je     0x903c
    901d:	mov    r11d,r10d
    9020:	shr    r10d,1
    9023:	and    r10d,0x1e
    9027:	and    r11d,0x1
    902b:	or     r10d,r11d
    902e:	or     DWORD PTR [r12+0x314],r10d
    9036:	and    DWORD PTR [r12-0x28],0xffffffc0
    903c:	ldmxcsr DWORD PTR [r12-0x38]
    9042:	lea    rdi,[rsp+0x110]
    904a:	lea    rsi,[rsp+0xf0]
    9052:	lea    rdx,[rsp+0x100]
    905a:	mov    ecx,0x56
    905f:	mov    r8d,0x0
    9065:	lea    r9,[r12+0x314]
    906d:	movabs r11,0x590d850f6650
    9077:	call   r11
    907a:	ldmxcsr DWORD PTR [r12-0x28]
    9080:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    9086:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    908c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    9092:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    9098:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    909e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    90a8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    90b2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    90bc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    90c6:	mov    rbx,QWORD PTR [r12+0x108]
    90ce:	mov    QWORD PTR [r12+0x378],0x2
    90da:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    90e3:	mov    rdx,rbx
    90e6:	shr    rdx,0x10
    90ea:	and    edx,0xc000
    90f0:	mov    rax,rbx
    90f3:	shr    rax,0x15
    90f7:	and    eax,0x100
    90fc:	xor    eax,0x100
    9101:	or     edx,eax
    9103:	mov    rax,rbx
    9106:	shr    rax,0x1c
    910a:	and    eax,0x1
    910d:	or     edx,eax
    910f:	mov    QWORD PTR [rsp+0x10],rdx
    9114:	add    rsp,0x8
    9118:	ret
    9119:	nop    DWORD PTR [rax+0x0]
    9120:	sub    rsp,0x8
    9124:	mov    QWORD PTR [r12+0x378],0x3
    9130:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    9136:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    913c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    9142:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    9148:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    914e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    9154:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    915e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    9168:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    9172:	push   rdx
    9173:	push   rsi
    9174:	push   r10
    9176:	push   r11
    9178:	mov    rdx,QWORD PTR [rsp+0x30]
    917d:	mov    r10d,edx
    9180:	and    r10d,0xc000
    9187:	shl    r10d,0x10
    918b:	mov    r11d,edx
    918e:	and    r11d,0x100
    9195:	shl    r11d,0x15
    9199:	or     r10d,r11d
    919c:	and    edx,0x1
    919f:	shl    edx,0x1c
    91a2:	or     r10d,edx
    91a5:	btc    r10,0x1d
    91aa:	mov    r11d,0xf0000000
    91b0:	and    r11,r10
    91b3:	movabs rsi,0xffffffff0fffffff
    91bd:	and    rbx,rsi
    91c0:	or     rbx,r11
    91c3:	pop    r11
    91c5:	pop    r10
    91c7:	pop    rsi
    91c8:	pop    rdx
    91c9:	mov    QWORD PTR [r12+0x108],rbx
    91d1:	stmxcsr DWORD PTR [r12-0x28]
    91d7:	mov    r10d,DWORD PTR [r12-0x28]
    91dc:	test   r10d,0x3f
    91e3:	je     0x9208
    91e9:	mov    r11d,r10d
    91ec:	shr    r10d,1
    91ef:	and    r10d,0x1e
    91f3:	and    r11d,0x1
    91f7:	or     r10d,r11d
    91fa:	or     DWORD PTR [r12+0x314],r10d
    9202:	and    DWORD PTR [r12-0x28],0xffffffc0
    9208:	ldmxcsr DWORD PTR [r12-0x38]
    920e:	lea    rdi,[rsp+0x110]
    9216:	lea    rsi,[rsp+0xf0]
    921e:	lea    rdx,[rsp+0x100]
    9226:	mov    ecx,0x56
    922b:	mov    r8d,0x0
    9231:	lea    r9,[r12+0x314]
    9239:	movabs r11,0x590d850f6650
    9243:	call   r11
    9246:	ldmxcsr DWORD PTR [r12-0x28]
    924c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    9252:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    9258:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    925e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    9264:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    926a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    9270:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    927a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    9284:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    928e:	mov    rbx,QWORD PTR [r12+0x108]
    9296:	mov    QWORD PTR [r12+0x378],0x2
    92a2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    92ab:	mov    rdx,rbx
    92ae:	shr    rdx,0x10
    92b2:	and    edx,0xc000
    92b8:	mov    rax,rbx
    92bb:	shr    rax,0x15
    92bf:	and    eax,0x100
    92c4:	xor    eax,0x100
    92c9:	or     edx,eax
    92cb:	mov    rax,rbx
    92ce:	shr    rax,0x1c
    92d2:	and    eax,0x1
    92d5:	or     edx,eax
    92d7:	mov    QWORD PTR [rsp+0x10],rdx
    92dc:	add    rsp,0x8
    92e0:	ret
    92e1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    92f0:	sub    rsp,0x8
    92f4:	mov    QWORD PTR [r12+0x378],0x3
    9300:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    9306:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    930c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    9312:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    9318:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    9322:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    932c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    9336:	push   rdx
    9337:	push   rsi
    9338:	push   r10
    933a:	push   r11
    933c:	mov    rdx,QWORD PTR [rsp+0x30]
    9341:	mov    r10d,edx
    9344:	and    r10d,0xc000
    934b:	shl    r10d,0x10
    934f:	mov    r11d,edx
    9352:	and    r11d,0x100
    9359:	shl    r11d,0x15
    935d:	or     r10d,r11d
    9360:	and    edx,0x1
    9363:	shl    edx,0x1c
    9366:	or     r10d,edx
    9369:	btc    r10,0x1d
    936e:	mov    r11d,0xf0000000
    9374:	and    r11,r10
    9377:	movabs rsi,0xffffffff0fffffff
    9381:	and    rbx,rsi
    9384:	or     rbx,r11
    9387:	pop    r11
    9389:	pop    r10
    938b:	pop    rsi
    938c:	pop    rdx
    938d:	mov    QWORD PTR [r12+0x108],rbx
    9395:	stmxcsr DWORD PTR [r12-0x28]
    939b:	mov    r10d,DWORD PTR [r12-0x28]
    93a0:	test   r10d,0x3f
    93a7:	je     0x93cc
    93ad:	mov    r11d,r10d
    93b0:	shr    r10d,1
    93b3:	and    r10d,0x1e
    93b7:	and    r11d,0x1
    93bb:	or     r10d,r11d
    93be:	or     DWORD PTR [r12+0x314],r10d
    93c6:	and    DWORD PTR [r12-0x28],0xffffffc0
    93cc:	ldmxcsr DWORD PTR [r12-0x38]
    93d2:	lea    rdi,[rsp+0x110]
    93da:	lea    rsi,[rsp+0xf0]
    93e2:	lea    rdx,[rsp+0x100]
    93ea:	mov    ecx,0x14
    93ef:	mov    r8d,0x0
    93f5:	lea    r9,[r12+0x314]
    93fd:	movabs r11,0x590d850f6650
    9407:	call   r11
    940a:	ldmxcsr DWORD PTR [r12-0x28]
    9410:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    9416:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    941c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    9422:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    9428:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    9432:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    943c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    9446:	mov    rbx,QWORD PTR [r12+0x108]
    944e:	mov    QWORD PTR [r12+0x378],0x2
    945a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    9463:	mov    rdx,rbx
    9466:	shr    rdx,0x10
    946a:	and    edx,0xc000
    9470:	mov    rax,rbx
    9473:	shr    rax,0x15
    9477:	and    eax,0x100
    947c:	xor    eax,0x100
    9481:	or     edx,eax
    9483:	mov    rax,rbx
    9486:	shr    rax,0x1c
    948a:	and    eax,0x1
    948d:	or     edx,eax
    948f:	mov    QWORD PTR [rsp+0x10],rdx
    9494:	add    rsp,0x8
    9498:	ret
    9499:	nop    DWORD PTR [rax+0x0]
    94a0:	sub    rsp,0x8
    94a4:	mov    QWORD PTR [r12+0x378],0x3
    94b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    94b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    94bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    94c2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    94cc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    94d6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    94e0:	push   rdx
    94e1:	push   rsi
    94e2:	push   r10
    94e4:	push   r11
    94e6:	mov    rdx,QWORD PTR [rsp+0x30]
    94eb:	mov    r10d,edx
    94ee:	and    r10d,0xc000
    94f5:	shl    r10d,0x10
    94f9:	mov    r11d,edx
    94fc:	and    r11d,0x100
    9503:	shl    r11d,0x15
    9507:	or     r10d,r11d
    950a:	and    edx,0x1
    950d:	shl    edx,0x1c
    9510:	or     r10d,edx
    9513:	btc    r10,0x1d
    9518:	mov    r11d,0xf0000000
    951e:	and    r11,r10
    9521:	movabs rsi,0xffffffff0fffffff
    952b:	and    rbx,rsi
    952e:	or     rbx,r11
    9531:	pop    r11
    9533:	pop    r10
    9535:	pop    rsi
    9536:	pop    rdx
    9537:	mov    QWORD PTR [r12+0x108],rbx
    953f:	stmxcsr DWORD PTR [r12-0x28]
    9545:	mov    r10d,DWORD PTR [r12-0x28]
    954a:	test   r10d,0x3f
    9551:	je     0x9576
    9557:	mov    r11d,r10d
    955a:	shr    r10d,1
    955d:	and    r10d,0x1e
    9561:	and    r11d,0x1
    9565:	or     r10d,r11d
    9568:	or     DWORD PTR [r12+0x314],r10d
    9570:	and    DWORD PTR [r12-0x28],0xffffffc0
    9576:	ldmxcsr DWORD PTR [r12-0x38]
    957c:	lea    rdi,[rsp+0x110]
    9584:	lea    rsi,[rsp+0xf0]
    958c:	lea    rdx,[rsp+0x100]
    9594:	mov    ecx,0x14
    9599:	mov    r8d,0x0
    959f:	lea    r9,[r12+0x314]
    95a7:	movabs r11,0x590d850f6650
    95b1:	call   r11
    95b4:	ldmxcsr DWORD PTR [r12-0x28]
    95ba:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    95c0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    95c6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    95cc:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    95d6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    95e0:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    95ea:	mov    rbx,QWORD PTR [r12+0x108]
    95f2:	mov    QWORD PTR [r12+0x378],0x2
    95fe:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    9607:	mov    rdx,rbx
    960a:	shr    rdx,0x10
    960e:	and    edx,0xc000
    9614:	mov    rax,rbx
    9617:	shr    rax,0x15
    961b:	and    eax,0x100
    9620:	xor    eax,0x100
    9625:	or     edx,eax
    9627:	mov    rax,rbx
    962a:	shr    rax,0x1c
    962e:	and    eax,0x1
    9631:	or     edx,eax
    9633:	mov    QWORD PTR [rsp+0x10],rdx
    9638:	add    rsp,0x8
    963c:	ret
    963d:	nop    DWORD PTR [rax]
    9640:	sub    rsp,0x8
    9644:	mov    QWORD PTR [r12+0x378],0x3
    9650:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    9656:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    965c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    9662:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    966c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    9676:	push   rdx
    9677:	push   rsi
    9678:	push   r10
    967a:	push   r11
    967c:	mov    rdx,QWORD PTR [rsp+0x30]
    9681:	mov    r10d,edx
    9684:	and    r10d,0xc000
    968b:	shl    r10d,0x10
    968f:	mov    r11d,edx
    9692:	and    r11d,0x100
    9699:	shl    r11d,0x15
    969d:	or     r10d,r11d
    96a0:	and    edx,0x1
    96a3:	shl    edx,0x1c
    96a6:	or     r10d,edx
    96a9:	btc    r10,0x1d
    96ae:	mov    r11d,0xf0000000
    96b4:	and    r11,r10
    96b7:	movabs rsi,0xffffffff0fffffff
    96c1:	and    rbx,rsi
    96c4:	or     rbx,r11
    96c7:	pop    r11
    96c9:	pop    r10
    96cb:	pop    rsi
    96cc:	pop    rdx
    96cd:	mov    QWORD PTR [r12+0x108],rbx
    96d5:	stmxcsr DWORD PTR [r12-0x28]
    96db:	mov    r10d,DWORD PTR [r12-0x28]
    96e0:	test   r10d,0x3f
    96e7:	je     0x970c
    96ed:	mov    r11d,r10d
    96f0:	shr    r10d,1
    96f3:	and    r10d,0x1e
    96f7:	and    r11d,0x1
    96fb:	or     r10d,r11d
    96fe:	or     DWORD PTR [r12+0x314],r10d
    9706:	and    DWORD PTR [r12-0x28],0xffffffc0
    970c:	ldmxcsr DWORD PTR [r12-0x38]
    9712:	lea    rdi,[rsp+0x110]
    971a:	lea    rsi,[rsp+0xf0]
    9722:	lea    rdx,[rsp+0x100]
    972a:	mov    ecx,0x14
    972f:	mov    r8d,0x0
    9735:	lea    r9,[r12+0x314]
    973d:	movabs r11,0x590d850f6650
    9747:	call   r11
    974a:	ldmxcsr DWORD PTR [r12-0x28]
    9750:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    9756:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    975c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    9762:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    976c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    9776:	mov    rbx,QWORD PTR [r12+0x108]
    977e:	mov    QWORD PTR [r12+0x378],0x2
    978a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    9793:	mov    rdx,rbx
    9796:	shr    rdx,0x10
    979a:	and    edx,0xc000
    97a0:	mov    rax,rbx
    97a3:	shr    rax,0x15
    97a7:	and    eax,0x100
    97ac:	xor    eax,0x100
    97b1:	or     edx,eax
    97b3:	mov    rax,rbx
    97b6:	shr    rax,0x1c
    97ba:	and    eax,0x1
    97bd:	or     edx,eax
    97bf:	mov    QWORD PTR [rsp+0x10],rdx
    97c4:	add    rsp,0x8
    97c8:	ret
    97c9:	nop    DWORD PTR [rax+0x0]
    97d0:	sub    rsp,0x8
    97d4:	mov    QWORD PTR [r12+0x378],0x3
    97e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    97e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    97ec:	push   rdx
    97ed:	push   rsi
    97ee:	push   r10
    97f0:	push   r11
    97f2:	mov    rdx,QWORD PTR [rsp+0x30]
    97f7:	mov    r10d,edx
    97fa:	and    r10d,0xc000
    9801:	shl    r10d,0x10
    9805:	mov    r11d,edx
    9808:	and    r11d,0x100
    980f:	shl    r11d,0x15
    9813:	or     r10d,r11d
    9816:	and    edx,0x1
    9819:	shl    edx,0x1c
    981c:	or     r10d,edx
    981f:	btc    r10,0x1d
    9824:	mov    r11d,0xf0000000
    982a:	and    r11,r10
    982d:	movabs rsi,0xffffffff0fffffff
    9837:	and    rbx,rsi
    983a:	or     rbx,r11
    983d:	pop    r11
    983f:	pop    r10
    9841:	pop    rsi
    9842:	pop    rdx
    9843:	mov    QWORD PTR [r12+0x108],rbx
    984b:	stmxcsr DWORD PTR [r12-0x28]
    9851:	mov    r10d,DWORD PTR [r12-0x28]
    9856:	test   r10d,0x3f
    985d:	je     0x9882
    9863:	mov    r11d,r10d
    9866:	shr    r10d,1
    9869:	and    r10d,0x1e
    986d:	and    r11d,0x1
    9871:	or     r10d,r11d
    9874:	or     DWORD PTR [r12+0x314],r10d
    987c:	and    DWORD PTR [r12-0x28],0xffffffc0
    9882:	ldmxcsr DWORD PTR [r12-0x38]
    9888:	lea    rdi,[rsp+0x110]
    9890:	lea    rsi,[rsp+0xf0]
    9898:	lea    rdx,[rsp+0x100]
    98a0:	mov    ecx,0xc
    98a5:	mov    r8d,0x0
    98ab:	lea    r9,[r12+0x314]
    98b3:	movabs r11,0x590d850f6650
    98bd:	call   r11
    98c0:	ldmxcsr DWORD PTR [r12-0x28]
    98c6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    98cc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    98d2:	mov    rbx,QWORD PTR [r12+0x108]
    98da:	mov    QWORD PTR [r12+0x378],0x2
    98e6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    98ef:	mov    rdx,rbx
    98f2:	shr    rdx,0x10
    98f6:	and    edx,0xc000
    98fc:	mov    rax,rbx
    98ff:	shr    rax,0x15
    9903:	and    eax,0x100
    9908:	xor    eax,0x100
    990d:	or     edx,eax
    990f:	mov    rax,rbx
    9912:	shr    rax,0x1c
    9916:	and    eax,0x1
    9919:	or     edx,eax
    991b:	mov    QWORD PTR [rsp+0x10],rdx
    9920:	add    rsp,0x8
    9924:	ret
    9925:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    9930:	sub    rsp,0x8
    9934:	mov    QWORD PTR [r12+0x378],0x3
    9940:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    9946:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    994c:	push   rdx
    994d:	push   rsi
    994e:	push   r10
    9950:	push   r11
    9952:	mov    rdx,QWORD PTR [rsp+0x30]
    9957:	mov    r10d,edx
    995a:	and    r10d,0xc000
    9961:	shl    r10d,0x10
    9965:	mov    r11d,edx
    9968:	and    r11d,0x100
    996f:	shl    r11d,0x15
    9973:	or     r10d,r11d
    9976:	and    edx,0x1
    9979:	shl    edx,0x1c
    997c:	or     r10d,edx
    997f:	btc    r10,0x1d
    9984:	mov    r11d,0xf0000000
    998a:	and    r11,r10
    998d:	movabs rsi,0xffffffff0fffffff
    9997:	and    rbx,rsi
    999a:	or     rbx,r11
    999d:	pop    r11
    999f:	pop    r10
    99a1:	pop    rsi
    99a2:	pop    rdx
    99a3:	mov    QWORD PTR [r12+0x108],rbx
    99ab:	stmxcsr DWORD PTR [r12-0x28]
    99b1:	mov    r10d,DWORD PTR [r12-0x28]
    99b6:	test   r10d,0x3f
    99bd:	je     0x99e2
    99c3:	mov    r11d,r10d
    99c6:	shr    r10d,1
    99c9:	and    r10d,0x1e
    99cd:	and    r11d,0x1
    99d1:	or     r10d,r11d
    99d4:	or     DWORD PTR [r12+0x314],r10d
    99dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    99e2:	ldmxcsr DWORD PTR [r12-0x38]
    99e8:	lea    rdi,[rsp+0x110]
    99f0:	lea    rsi,[rsp+0xf0]
    99f8:	lea    rdx,[rsp+0x100]
    9a00:	mov    ecx,0xc
    9a05:	mov    r8d,0x0
    9a0b:	lea    r9,[r12+0x314]
    9a13:	movabs r11,0x590d850f6650
    9a1d:	call   r11
    9a20:	ldmxcsr DWORD PTR [r12-0x28]
    9a26:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    9a2c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    9a32:	mov    rbx,QWORD PTR [r12+0x108]
    9a3a:	mov    QWORD PTR [r12+0x378],0x2
    9a46:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    9a4f:	mov    rdx,rbx
    9a52:	shr    rdx,0x10
    9a56:	and    edx,0xc000
    9a5c:	mov    rax,rbx
    9a5f:	shr    rax,0x15
    9a63:	and    eax,0x100
    9a68:	xor    eax,0x100
    9a6d:	or     edx,eax
    9a6f:	mov    rax,rbx
    9a72:	shr    rax,0x1c
    9a76:	and    eax,0x1
    9a79:	or     edx,eax
    9a7b:	mov    QWORD PTR [rsp+0x10],rdx
    9a80:	add    rsp,0x8
    9a84:	ret
    9a85:	mov    eax,0x410400
    9a8a:	mov    QWORD PTR [r12+0x100],rax
    9a92:	push   rdx
    9a93:	push   rsi
    9a94:	push   r10
    9a96:	push   r11
    9a98:	mov    r11,rax
    9a9b:	lahf
    9a9c:	seto   al
    9a9f:	mov    WORD PTR [rsp+0x20],ax
    9aa4:	mov    rax,r11
    9aa7:	mov    rdx,QWORD PTR [rsp+0x20]
    9aac:	mov    r10d,edx
    9aaf:	and    r10d,0xc000
    9ab6:	shl    r10d,0x10
    9aba:	mov    r11d,edx
    9abd:	and    r11d,0x100
    9ac4:	shl    r11d,0x15
    9ac8:	or     r10d,r11d
    9acb:	and    edx,0x1
    9ace:	shl    edx,0x1c
    9ad1:	or     r10d,edx
    9ad4:	btc    r10,0x1d
    9ad9:	mov    r11d,0xf0000000
    9adf:	and    r11,r10
    9ae2:	movabs rsi,0xffffffff0fffffff
    9aec:	and    rbx,rsi
    9aef:	or     rbx,r11
    9af2:	pop    r11
    9af4:	pop    r10
    9af6:	pop    rsi
    9af7:	pop    rdx
    9af8:	mov    QWORD PTR [r12+0x108],rbx
    9b00:	add    rsp,0x150
    9b07:	mov    eax,0xc
    9b0c:	movabs r11,0x590d8528fca0
    9b16:	jmp    r11
    9b19:	mov    eax,0x41048c
    9b1e:	mov    QWORD PTR [r12+0x100],rax
    9b26:	push   rdx
    9b27:	push   rsi
    9b28:	push   r10
    9b2a:	push   r11
    9b2c:	mov    r11,rax
    9b2f:	lahf
    9b30:	seto   al
    9b33:	mov    WORD PTR [rsp+0x20],ax
    9b38:	mov    rax,r11
    9b3b:	mov    rdx,QWORD PTR [rsp+0x20]
    9b40:	mov    r10d,edx
    9b43:	and    r10d,0xc000
    9b4a:	shl    r10d,0x10
    9b4e:	mov    r11d,edx
    9b51:	and    r11d,0x100
    9b58:	shl    r11d,0x15
    9b5c:	or     r10d,r11d
    9b5f:	and    edx,0x1
    9b62:	shl    edx,0x1c
    9b65:	or     r10d,edx
    9b68:	btc    r10,0x1d
    9b6d:	mov    r11d,0xf0000000
    9b73:	and    r11,r10
    9b76:	movabs rsi,0xffffffff0fffffff
    9b80:	and    rbx,rsi
    9b83:	or     rbx,r11
    9b86:	pop    r11
    9b88:	pop    r10
    9b8a:	pop    rsi
    9b8b:	pop    rdx
    9b8c:	mov    QWORD PTR [r12+0x108],rbx
    9b94:	add    rsp,0x150
    9b9b:	mov    eax,0xc
    9ba0:	movabs r11,0x590d8528fca0
    9baa:	jmp    r11
    9bad:	mov    eax,0x4106cc
    9bb2:	mov    QWORD PTR [r12+0x100],rax
    9bba:	push   rdx
    9bbb:	push   rsi
    9bbc:	push   r10
    9bbe:	push   r11
    9bc0:	mov    rdx,QWORD PTR [rsp+0x20]
    9bc5:	mov    r10d,edx
    9bc8:	and    r10d,0xc000
    9bcf:	shl    r10d,0x10
    9bd3:	mov    r11d,edx
    9bd6:	and    r11d,0x100
    9bdd:	shl    r11d,0x15
    9be1:	or     r10d,r11d
    9be4:	and    edx,0x1
    9be7:	shl    edx,0x1c
    9bea:	or     r10d,edx
    9bed:	btc    r10,0x1d
    9bf2:	mov    r11d,0xf0000000
    9bf8:	and    r11,r10
    9bfb:	movabs rsi,0xffffffff0fffffff
    9c05:	and    rbx,rsi
    9c08:	or     rbx,r11
    9c0b:	pop    r11
    9c0d:	pop    r10
    9c0f:	pop    rsi
    9c10:	pop    rdx
    9c11:	mov    QWORD PTR [r12+0x108],rbx
    9c19:	add    rsp,0x150
    9c20:	mov    eax,0xc
    9c25:	movabs r11,0x590d8528fca0
    9c2f:	jmp    r11
    9c32:	mov    eax,0x4106d8
    9c37:	mov    QWORD PTR [r12+0x100],rax
    9c3f:	push   rdx
    9c40:	push   rsi
    9c41:	push   r10
    9c43:	push   r11
    9c45:	mov    r11,rax
    9c48:	lahf
    9c49:	seto   al
    9c4c:	mov    WORD PTR [rsp+0x20],ax
    9c51:	mov    rax,r11
    9c54:	mov    rdx,QWORD PTR [rsp+0x20]
    9c59:	mov    r10d,edx
    9c5c:	and    r10d,0xc000
    9c63:	shl    r10d,0x10
    9c67:	mov    r11d,edx
    9c6a:	and    r11d,0x100
    9c71:	shl    r11d,0x15
    9c75:	or     r10d,r11d
    9c78:	and    edx,0x1
    9c7b:	shl    edx,0x1c
    9c7e:	or     r10d,edx
    9c81:	btc    r10,0x1d
    9c86:	mov    r11d,0xf0000000
    9c8c:	and    r11,r10
    9c8f:	movabs rsi,0xffffffff0fffffff
    9c99:	and    rbx,rsi
    9c9c:	or     rbx,r11
    9c9f:	pop    r11
    9ca1:	pop    r10
    9ca3:	pop    rsi
    9ca4:	pop    rdx
    9ca5:	mov    QWORD PTR [r12+0x108],rbx
    9cad:	add    rsp,0x150
    9cb4:	mov    eax,0xc
    9cb9:	movabs r11,0x590d8528fca0
    9cc3:	jmp    r11
    9cc6:	mov    eax,0x410700
    9ccb:	mov    QWORD PTR [r12+0x100],rax
    9cd3:	push   rdx
    9cd4:	push   rsi
    9cd5:	push   r10
    9cd7:	push   r11
    9cd9:	mov    r11,rax
    9cdc:	lahf
    9cdd:	seto   al
    9ce0:	mov    WORD PTR [rsp+0x20],ax
    9ce5:	mov    rax,r11
    9ce8:	mov    rdx,QWORD PTR [rsp+0x20]
    9ced:	mov    r10d,edx
    9cf0:	and    r10d,0xc000
    9cf7:	shl    r10d,0x10
    9cfb:	mov    r11d,edx
    9cfe:	and    r11d,0x100
    9d05:	shl    r11d,0x15
    9d09:	or     r10d,r11d
    9d0c:	and    edx,0x1
    9d0f:	shl    edx,0x1c
    9d12:	or     r10d,edx
    9d15:	btc    r10,0x1d
    9d1a:	mov    r11d,0xf0000000
    9d20:	and    r11,r10
    9d23:	movabs rsi,0xffffffff0fffffff
    9d2d:	and    rbx,rsi
    9d30:	or     rbx,r11
    9d33:	pop    r11
    9d35:	pop    r10
    9d37:	pop    rsi
    9d38:	pop    rdx
    9d39:	mov    QWORD PTR [r12+0x108],rbx
    9d41:	add    rsp,0x150
    9d48:	mov    eax,0xc
    9d4d:	movabs r11,0x590d8528fca0
    9d57:	jmp    r11
    9d5a:	mov    eax,0x410724
    9d5f:	mov    QWORD PTR [r12+0x100],rax
    9d67:	push   rdx
    9d68:	push   rsi
    9d69:	push   r10
    9d6b:	push   r11
    9d6d:	mov    rdx,QWORD PTR [rsp+0x20]
    9d72:	mov    r10d,edx
    9d75:	and    r10d,0xc000
    9d7c:	shl    r10d,0x10
    9d80:	mov    r11d,edx
    9d83:	and    r11d,0x100
    9d8a:	shl    r11d,0x15
    9d8e:	or     r10d,r11d
    9d91:	and    edx,0x1
    9d94:	shl    edx,0x1c
    9d97:	or     r10d,edx
    9d9a:	btc    r10,0x1d
    9d9f:	mov    r11d,0xf0000000
    9da5:	and    r11,r10
    9da8:	movabs rsi,0xffffffff0fffffff
    9db2:	and    rbx,rsi
    9db5:	or     rbx,r11
    9db8:	pop    r11
    9dba:	pop    r10
    9dbc:	pop    rsi
    9dbd:	pop    rdx
    9dbe:	mov    QWORD PTR [r12+0x108],rbx
    9dc6:	add    rsp,0x150
    9dcd:	mov    eax,0xc
    9dd2:	movabs r11,0x590d8528fca0
    9ddc:	jmp    r11
    9ddf:	nop
    9de0:	sub    rsp,0x150
    9de7:	mov    r11,QWORD PTR [r12+0x398]
    9def:	mov    QWORD PTR [rsp],r11
    9df3:	cmp    DWORD PTR [r12+0x310],0x0
    9dfc:	je     0x9e87
    9e02:	push   rdx
    9e03:	push   rsi
    9e04:	push   r10
    9e06:	push   r11
    9e08:	mov    rdx,QWORD PTR [rsp+0x20]
    9e0d:	mov    r10d,edx
    9e10:	and    r10d,0xc000
    9e17:	shl    r10d,0x10
    9e1b:	mov    r11d,edx
    9e1e:	and    r11d,0x100
    9e25:	shl    r11d,0x15
    9e29:	or     r10d,r11d
    9e2c:	and    edx,0x1
    9e2f:	shl    edx,0x1c
    9e32:	or     r10d,edx
    9e35:	btc    r10,0x1d
    9e3a:	mov    r11d,0xf0000000
    9e40:	and    r11,r10
    9e43:	movabs rsi,0xffffffff0fffffff
    9e4d:	and    rbx,rsi
    9e50:	or     rbx,r11
    9e53:	pop    r11
    9e55:	pop    r10
    9e57:	pop    rsi
    9e58:	pop    rdx
    9e59:	mov    QWORD PTR [r12+0x108],rbx
    9e61:	mov    eax,0x410404
    9e66:	mov    QWORD PTR [r12+0x100],rax
    9e6e:	add    rsp,0x150
    9e75:	mov    eax,0x3
    9e7a:	movabs r11,0x590d8528fca0
    9e84:	jmp    r11
    9e87:	jmp    0xfd
    9e8c:	nop    DWORD PTR [rax+0x0]
    9e90:	sub    rsp,0x150
    9e97:	mov    r11,QWORD PTR [r12+0x398]
    9e9f:	mov    QWORD PTR [rsp],r11
    9ea3:	cmp    DWORD PTR [r12+0x310],0x0
    9eac:	je     0x9f37
    9eb2:	push   rdx
    9eb3:	push   rsi
    9eb4:	push   r10
    9eb6:	push   r11
    9eb8:	mov    rdx,QWORD PTR [rsp+0x20]
    9ebd:	mov    r10d,edx
    9ec0:	and    r10d,0xc000
    9ec7:	shl    r10d,0x10
    9ecb:	mov    r11d,edx
    9ece:	and    r11d,0x100
    9ed5:	shl    r11d,0x15
    9ed9:	or     r10d,r11d
    9edc:	and    edx,0x1
    9edf:	shl    edx,0x1c
    9ee2:	or     r10d,edx
    9ee5:	btc    r10,0x1d
    9eea:	mov    r11d,0xf0000000
    9ef0:	and    r11,r10
    9ef3:	movabs rsi,0xffffffff0fffffff
    9efd:	and    rbx,rsi
    9f00:	or     rbx,r11
    9f03:	pop    r11
    9f05:	pop    r10
    9f07:	pop    rsi
    9f08:	pop    rdx
    9f09:	mov    QWORD PTR [r12+0x108],rbx
    9f11:	mov    eax,0x410450
    9f16:	mov    QWORD PTR [r12+0x100],rax
    9f1e:	add    rsp,0x150
    9f25:	mov    eax,0x3
    9f2a:	movabs r11,0x590d8528fca0
    9f34:	jmp    r11
    9f37:	mov    r11,rax
    9f3a:	movzx  eax,WORD PTR [rsp]
    9f3e:	add    al,0x7f
    9f40:	sahf
    9f41:	mov    rax,r11
    9f44:	jmp    0x26d
    9f49:	nop    DWORD PTR [rax+0x0]
    9f50:	sub    rsp,0x150
    9f57:	mov    r11,QWORD PTR [r12+0x398]
    9f5f:	mov    QWORD PTR [rsp],r11
    9f63:	cmp    DWORD PTR [r12+0x310],0x0
    9f6c:	je     0x9ff7
    9f72:	push   rdx
    9f73:	push   rsi
    9f74:	push   r10
    9f76:	push   r11
    9f78:	mov    rdx,QWORD PTR [rsp+0x20]
    9f7d:	mov    r10d,edx
    9f80:	and    r10d,0xc000
    9f87:	shl    r10d,0x10
    9f8b:	mov    r11d,edx
    9f8e:	and    r11d,0x100
    9f95:	shl    r11d,0x15
    9f99:	or     r10d,r11d
    9f9c:	and    edx,0x1
    9f9f:	shl    edx,0x1c
    9fa2:	or     r10d,edx
    9fa5:	btc    r10,0x1d
    9faa:	mov    r11d,0xf0000000
    9fb0:	and    r11,r10
    9fb3:	movabs rsi,0xffffffff0fffffff
    9fbd:	and    rbx,rsi
    9fc0:	or     rbx,r11
    9fc3:	pop    r11
    9fc5:	pop    r10
    9fc7:	pop    rsi
    9fc8:	pop    rdx
    9fc9:	mov    QWORD PTR [r12+0x108],rbx
    9fd1:	mov    eax,0x410490
    9fd6:	mov    QWORD PTR [r12+0x100],rax
    9fde:	add    rsp,0x150
    9fe5:	mov    eax,0x3
    9fea:	movabs r11,0x590d8528fca0
    9ff4:	jmp    r11
    9ff7:	jmp    0x6bb
    9ffc:	nop    DWORD PTR [rax+0x0]
    a000:	sub    rsp,0x150
    a007:	mov    r11,QWORD PTR [r12+0x398]
    a00f:	mov    QWORD PTR [rsp],r11
    a013:	cmp    DWORD PTR [r12+0x310],0x0
    a01c:	je     0xa0a7
    a022:	push   rdx
    a023:	push   rsi
    a024:	push   r10
    a026:	push   r11
    a028:	mov    rdx,QWORD PTR [rsp+0x20]
    a02d:	mov    r10d,edx
    a030:	and    r10d,0xc000
    a037:	shl    r10d,0x10
    a03b:	mov    r11d,edx
    a03e:	and    r11d,0x100
    a045:	shl    r11d,0x15
    a049:	or     r10d,r11d
    a04c:	and    edx,0x1
    a04f:	shl    edx,0x1c
    a052:	or     r10d,edx
    a055:	btc    r10,0x1d
    a05a:	mov    r11d,0xf0000000
    a060:	and    r11,r10
    a063:	movabs rsi,0xffffffff0fffffff
    a06d:	and    rbx,rsi
    a070:	or     rbx,r11
    a073:	pop    r11
    a075:	pop    r10
    a077:	pop    rsi
    a078:	pop    rdx
    a079:	mov    QWORD PTR [r12+0x108],rbx
    a081:	mov    eax,0x410500
    a086:	mov    QWORD PTR [r12+0x100],rax
    a08e:	add    rsp,0x150
    a095:	mov    eax,0x3
    a09a:	movabs r11,0x590d8528fca0
    a0a4:	jmp    r11
    a0a7:	mov    r11,rax
    a0aa:	movzx  eax,WORD PTR [rsp]
    a0ae:	add    al,0x7f
    a0b0:	sahf
    a0b1:	mov    rax,r11
    a0b4:	jmp    0xac7
    a0b9:	nop    DWORD PTR [rax+0x0]
    a0c0:	sub    rsp,0x150
    a0c7:	mov    r11,QWORD PTR [r12+0x398]
    a0cf:	mov    QWORD PTR [rsp],r11
    a0d3:	cmp    DWORD PTR [r12+0x310],0x0
    a0dc:	je     0xa167
    a0e2:	push   rdx
    a0e3:	push   rsi
    a0e4:	push   r10
    a0e6:	push   r11
    a0e8:	mov    rdx,QWORD PTR [rsp+0x20]
    a0ed:	mov    r10d,edx
    a0f0:	and    r10d,0xc000
    a0f7:	shl    r10d,0x10
    a0fb:	mov    r11d,edx
    a0fe:	and    r11d,0x100
    a105:	shl    r11d,0x15
    a109:	or     r10d,r11d
    a10c:	and    edx,0x1
    a10f:	shl    edx,0x1c
    a112:	or     r10d,edx
    a115:	btc    r10,0x1d
    a11a:	mov    r11d,0xf0000000
    a120:	and    r11,r10
    a123:	movabs rsi,0xffffffff0fffffff
    a12d:	and    rbx,rsi
    a130:	or     rbx,r11
    a133:	pop    r11
    a135:	pop    r10
    a137:	pop    rsi
    a138:	pop    rdx
    a139:	mov    QWORD PTR [r12+0x108],rbx
    a141:	mov    eax,0x410504
    a146:	mov    QWORD PTR [r12+0x100],rax
    a14e:	add    rsp,0x150
    a155:	mov    eax,0x3
    a15a:	movabs r11,0x590d8528fca0
    a164:	jmp    r11
    a167:	jmp    0xae5
    a16c:	nop    DWORD PTR [rax+0x0]
    a170:	sub    rsp,0x150
    a177:	mov    r11,QWORD PTR [r12+0x398]
    a17f:	mov    QWORD PTR [rsp],r11
    a183:	cmp    DWORD PTR [r12+0x310],0x0
    a18c:	je     0xa217
    a192:	push   rdx
    a193:	push   rsi
    a194:	push   r10
    a196:	push   r11
    a198:	mov    rdx,QWORD PTR [rsp+0x20]
    a19d:	mov    r10d,edx
    a1a0:	and    r10d,0xc000
    a1a7:	shl    r10d,0x10
    a1ab:	mov    r11d,edx
    a1ae:	and    r11d,0x100
    a1b5:	shl    r11d,0x15
    a1b9:	or     r10d,r11d
    a1bc:	and    edx,0x1
    a1bf:	shl    edx,0x1c
    a1c2:	or     r10d,edx
    a1c5:	btc    r10,0x1d
    a1ca:	mov    r11d,0xf0000000
    a1d0:	and    r11,r10
    a1d3:	movabs rsi,0xffffffff0fffffff
    a1dd:	and    rbx,rsi
    a1e0:	or     rbx,r11
    a1e3:	pop    r11
    a1e5:	pop    r10
    a1e7:	pop    rsi
    a1e8:	pop    rdx
    a1e9:	mov    QWORD PTR [r12+0x108],rbx
    a1f1:	mov    eax,0x4106d0
    a1f6:	mov    QWORD PTR [r12+0x100],rax
    a1fe:	add    rsp,0x150
    a205:	mov    eax,0x3
    a20a:	movabs r11,0x590d8528fca0
    a214:	jmp    r11
    a217:	jmp    0x2825
    a21c:	nop    DWORD PTR [rax+0x0]
    a220:	sub    rsp,0x150
    a227:	mov    r11,QWORD PTR [r12+0x398]
    a22f:	mov    QWORD PTR [rsp],r11
    a233:	cmp    DWORD PTR [r12+0x310],0x0
    a23c:	je     0xa2c7
    a242:	push   rdx
    a243:	push   rsi
    a244:	push   r10
    a246:	push   r11
    a248:	mov    rdx,QWORD PTR [rsp+0x20]
    a24d:	mov    r10d,edx
    a250:	and    r10d,0xc000
    a257:	shl    r10d,0x10
    a25b:	mov    r11d,edx
    a25e:	and    r11d,0x100
    a265:	shl    r11d,0x15
    a269:	or     r10d,r11d
    a26c:	and    edx,0x1
    a26f:	shl    edx,0x1c
    a272:	or     r10d,edx
    a275:	btc    r10,0x1d
    a27a:	mov    r11d,0xf0000000
    a280:	and    r11,r10
    a283:	movabs rsi,0xffffffff0fffffff
    a28d:	and    rbx,rsi
    a290:	or     rbx,r11
    a293:	pop    r11
    a295:	pop    r10
    a297:	pop    rsi
    a298:	pop    rdx
    a299:	mov    QWORD PTR [r12+0x108],rbx
    a2a1:	mov    eax,0x4106dc
    a2a6:	mov    QWORD PTR [r12+0x100],rax
    a2ae:	add    rsp,0x150
    a2b5:	mov    eax,0x3
    a2ba:	movabs r11,0x590d8528fca0
    a2c4:	jmp    r11
    a2c7:	jmp    0x2862
    a2cc:	nop    DWORD PTR [rax+0x0]
    a2d0:	sub    rsp,0x150
    a2d7:	mov    r11,QWORD PTR [r12+0x398]
    a2df:	mov    QWORD PTR [rsp],r11
    a2e3:	cmp    DWORD PTR [r12+0x310],0x0
    a2ec:	je     0xa377
    a2f2:	push   rdx
    a2f3:	push   rsi
    a2f4:	push   r10
    a2f6:	push   r11
    a2f8:	mov    rdx,QWORD PTR [rsp+0x20]
    a2fd:	mov    r10d,edx
    a300:	and    r10d,0xc000
    a307:	shl    r10d,0x10
    a30b:	mov    r11d,edx
    a30e:	and    r11d,0x100
    a315:	shl    r11d,0x15
    a319:	or     r10d,r11d
    a31c:	and    edx,0x1
    a31f:	shl    edx,0x1c
    a322:	or     r10d,edx
    a325:	btc    r10,0x1d
    a32a:	mov    r11d,0xf0000000
    a330:	and    r11,r10
    a333:	movabs rsi,0xffffffff0fffffff
    a33d:	and    rbx,rsi
    a340:	or     rbx,r11
    a343:	pop    r11
    a345:	pop    r10
    a347:	pop    rsi
    a348:	pop    rdx
    a349:	mov    QWORD PTR [r12+0x108],rbx
    a351:	mov    eax,0x4106e8
    a356:	mov    QWORD PTR [r12+0x100],rax
    a35e:	add    rsp,0x150
    a365:	mov    eax,0x3
    a36a:	movabs r11,0x590d8528fca0
    a374:	jmp    r11
    a377:	jmp    0x289d
    a37c:	nop    DWORD PTR [rax+0x0]
    a380:	sub    rsp,0x150
    a387:	mov    r11,QWORD PTR [r12+0x398]
    a38f:	mov    QWORD PTR [rsp],r11
    a393:	cmp    DWORD PTR [r12+0x310],0x0
    a39c:	je     0xa427
    a3a2:	push   rdx
    a3a3:	push   rsi
    a3a4:	push   r10
    a3a6:	push   r11
    a3a8:	mov    rdx,QWORD PTR [rsp+0x20]
    a3ad:	mov    r10d,edx
    a3b0:	and    r10d,0xc000
    a3b7:	shl    r10d,0x10
    a3bb:	mov    r11d,edx
    a3be:	and    r11d,0x100
    a3c5:	shl    r11d,0x15
    a3c9:	or     r10d,r11d
    a3cc:	and    edx,0x1
    a3cf:	shl    edx,0x1c
    a3d2:	or     r10d,edx
    a3d5:	btc    r10,0x1d
    a3da:	mov    r11d,0xf0000000
    a3e0:	and    r11,r10
    a3e3:	movabs rsi,0xffffffff0fffffff
    a3ed:	and    rbx,rsi
    a3f0:	or     rbx,r11
    a3f3:	pop    r11
    a3f5:	pop    r10
    a3f7:	pop    rsi
    a3f8:	pop    rdx
    a3f9:	mov    QWORD PTR [r12+0x108],rbx
    a401:	mov    eax,0x410704
    a406:	mov    QWORD PTR [r12+0x100],rax
    a40e:	add    rsp,0x150
    a415:	mov    eax,0x3
    a41a:	movabs r11,0x590d8528fca0
    a424:	jmp    r11
    a427:	jmp    0x29f6
    a42c:	nop    DWORD PTR [rax+0x0]
    a430:	sub    rsp,0x150
    a437:	mov    r11,QWORD PTR [r12+0x398]
    a43f:	mov    QWORD PTR [rsp],r11
    a443:	cmp    DWORD PTR [r12+0x310],0x0
    a44c:	je     0xa4d7
    a452:	push   rdx
    a453:	push   rsi
    a454:	push   r10
    a456:	push   r11
    a458:	mov    rdx,QWORD PTR [rsp+0x20]
    a45d:	mov    r10d,edx
    a460:	and    r10d,0xc000
    a467:	shl    r10d,0x10
    a46b:	mov    r11d,edx
    a46e:	and    r11d,0x100
    a475:	shl    r11d,0x15
    a479:	or     r10d,r11d
    a47c:	and    edx,0x1
    a47f:	shl    edx,0x1c
    a482:	or     r10d,edx
    a485:	btc    r10,0x1d
    a48a:	mov    r11d,0xf0000000
    a490:	and    r11,r10
    a493:	movabs rsi,0xffffffff0fffffff
    a49d:	and    rbx,rsi
    a4a0:	or     rbx,r11
    a4a3:	pop    r11
    a4a5:	pop    r10
    a4a7:	pop    rsi
    a4a8:	pop    rdx
    a4a9:	mov    QWORD PTR [r12+0x108],rbx
    a4b1:	mov    eax,0x4103f0
    a4b6:	mov    QWORD PTR [r12+0x100],rax
    a4be:	add    rsp,0x150
    a4c5:	mov    eax,0x3
    a4ca:	movabs r11,0x590d8528fca0
    a4d4:	jmp    r11
    a4d7:	jmp    0x2bd3
    a4dc:	nop    DWORD PTR [rax+0x0]
    a4e0:	(bad)
    a4e1:	(bad)
    a4e2:	(bad)
    a4e3:	(bad)
    a4e4:	(bad)
    a4e5:	(bad)
    a4e6:	(bad)
    a4e7:	jg     0xa4e8
    a4e9:	(bad)
    a4ea:	(bad)
    a4eb:	(bad)
    a4ec:	(bad)
    a4ed:	(bad)
    a4ee:	(bad)
    a4ef:	jg     0xa4f1
    a4f1:	add    BYTE PTR [rax],al
    a4f3:	add    BYTE PTR [rax],al
    a4f5:	add    BYTE PTR [rax],dl
    a4f7:	add    BYTE PTR [rax],al
    a4f9:	add    BYTE PTR [rax],al
    a4fb:	add    BYTE PTR [rax],al
    a4fd:	add    BYTE PTR [rax],dl
	...
