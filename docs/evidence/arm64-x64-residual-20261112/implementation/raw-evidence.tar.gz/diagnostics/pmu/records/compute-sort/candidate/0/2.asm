
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sort/candidate/0/2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xa0]
  18:	mov    r14,r13
  1b:	shl    r14,0x2
  1f:	mov    r15,QWORD PTR [r12+0x98]
  27:	add    r15,r14
  2a:	mov    r14d,DWORD PTR [r12]
  2e:	mov    DWORD PTR [r15],r14d
  31:	mov    r14d,0x0
  37:	mov    DWORD PTR [r12+0x32c],r14d
  3f:	add    r13,0x1
  43:	mov    QWORD PTR [r12+0xa0],r13
  4b:	sub    r13,0x400
  52:	mov    rcx,QWORD PTR [r12+0x380]
  5a:	jrcxz  0x61
  5c:	jmp    0x445
  61:	jne    0x7a
  67:	mov    r11,rax
  6a:	lahf
  6b:	seto   al
  6e:	mov    WORD PTR [rsp],ax
  72:	mov    rax,r11
  75:	jmp    0x8d
  7a:	mov    r11,rax
  7d:	lahf
  7e:	seto   al
  81:	mov    WORD PTR [rsp],ax
  85:	mov    rax,r11
  88:	jmp    0x3d3
  8d:	mov    r13d,0x1
  93:	mov    QWORD PTR [r12+0x40],r13
  98:	mov    r11,rax
  9b:	movzx  eax,WORD PTR [rsp]
  9f:	add    al,0x7f
  a1:	sahf
  a2:	mov    rax,r11
  a5:	jmp    0xaa
  aa:	mov    r13,QWORD PTR [r12+0x40]
  af:	mov    r14,r13
  b2:	lea    r14,[r14*4+0x0]
  ba:	mov    r15,QWORD PTR [r12+0x98]
  c2:	mov    r11,rax
  c5:	lahf
  c6:	seto   al
  c9:	mov    WORD PTR [rsp],ax
  cd:	mov    rax,r11
  d0:	add    r15,r14
  d3:	mov    r14d,DWORD PTR [r15]
  d6:	mov    QWORD PTR [r12+0x48],r14
  db:	mov    r14d,0x0
  e1:	or     r14,r13
  e4:	mov    QWORD PTR [r12+0x50],r14
  e9:	jmp    0xee
  ee:	mov    r13d,DWORD PTR [r12+0x50]
  f3:	sub    r13d,0x1
  f7:	mov    QWORD PTR [r12+0x58],r13
  fc:	mov    ecx,0xffffffff
 101:	mov    r14,r13
 104:	and    r14,rcx
 107:	shl    r14,0x2
 10b:	mov    r13,QWORD PTR [r12+0x98]
 113:	add    r13,r14
 116:	mov    r14d,DWORD PTR [r13+0x0]
 11a:	mov    QWORD PTR [r12+0x60],r14
 11f:	mov    r13d,DWORD PTR [r12+0x48]
 124:	sub    r14d,r13d
 127:	mov    rcx,QWORD PTR [r12+0x380]
 12f:	jrcxz  0x136
 131:	jmp    0x4d6
 136:	jbe    0x14f
 13c:	mov    r11,rax
 13f:	lahf
 140:	seto   al
 143:	mov    WORD PTR [rsp],ax
 147:	mov    rax,r11
 14a:	jmp    0x162
 14f:	mov    r11,rax
 152:	lahf
 153:	seto   al
 156:	mov    WORD PTR [rsp],ax
 15a:	mov    rax,r11
 15d:	jmp    0x1e1
 162:	mov    r13,QWORD PTR [r12+0x50]
 167:	mov    r14,r13
 16a:	shl    r14,0x2
 16e:	mov    r15,QWORD PTR [r12+0x98]
 176:	add    r15,r14
 179:	mov    r14d,DWORD PTR [r12+0x60]
 17e:	mov    DWORD PTR [r15],r14d
 181:	mov    r14d,0x0
 187:	mov    DWORD PTR [r12+0x32c],r14d
 18f:	sub    r13,0x1
 193:	mov    QWORD PTR [r12+0x50],r13
 198:	mov    rcx,QWORD PTR [r12+0x380]
 1a0:	jrcxz  0x1a7
 1a2:	jmp    0x567
 1a7:	mov    r13,QWORD PTR [r12+0x58]
 1ac:	mov    rax,r13
 1af:	test   rax,rax
 1b2:	jne    0xee
 1b8:	jmp    0x1bd
 1bd:	mov    rcx,QWORD PTR [r12+0x380]
 1c5:	jrcxz  0x1cc
 1c7:	jmp    0x5e9
 1cc:	jmp    0x1d1
 1d1:	mov    r13d,0x0
 1d7:	mov    QWORD PTR [r12+0x50],r13
 1dc:	jmp    0x1e1
 1e1:	mov    r13,QWORD PTR [r12+0x40]
 1e6:	add    r13,0x1
 1ea:	mov    QWORD PTR [r12+0x40],r13
 1ef:	mov    r14,QWORD PTR [r12+0x50]
 1f4:	mov    ecx,0xffffffff
 1f9:	and    r14,rcx
 1fc:	shl    r14,0x2
 200:	mov    r15,QWORD PTR [r12+0x98]
 208:	add    r15,r14
 20b:	mov    r14d,DWORD PTR [r12+0x48]
 210:	mov    DWORD PTR [r15],r14d
 213:	mov    r14d,0x0
 219:	mov    DWORD PTR [r12+0x32c],r14d
 221:	sub    r13,0x400
 228:	jne    0xaa
 22e:	mov    r11,rax
 231:	lahf
 232:	seto   al
 235:	mov    WORD PTR [rsp],ax
 239:	mov    rax,r11
 23c:	jmp    0x241
 241:	mov    r13d,0x420000
 247:	mov    QWORD PTR [r12+0x40],r13
 24c:	mov    r13d,0x0
 252:	mov    QWORD PTR [r12+0x58],r13
 257:	mov    r13d,0x0
 25d:	mov    QWORD PTR [r12+0x50],r13
 262:	mov    r13d,0x420288
 268:	mov    r14,QWORD PTR [r13+0x0]
 26c:	mov    QWORD PTR [r12+0x48],r14
 271:	jmp    0x276
 276:	mov    r13,QWORD PTR [r12+0x58]
 27b:	mov    r14,r13
 27e:	shl    r14,0x2
 282:	mov    r15,QWORD PTR [r12+0x98]
 28a:	add    r15,r14
 28d:	mov    QWORD PTR [r12+0x60],r15
 292:	mov    r14,r15
 295:	add    r14,0x4
 299:	mov    ebp,DWORD PTR [r15]
 29c:	mov    r15d,DWORD PTR [r14]
 29f:	mov    QWORD PTR [r12+0x60],r15
 2a4:	mov    r14,rbp
 2a7:	imul   r14,r13
 2ab:	mov    r8,rbp
 2ae:	add    r8,r14
 2b1:	mov    QWORD PTR [r12+0x68],r8
 2b6:	add    r13,0x2
 2ba:	mov    QWORD PTR [r12+0x58],r13
 2bf:	mov    r14,r13
 2c2:	sub    r14,0x400
 2c9:	mov    r14,QWORD PTR [r12+0x50]
 2ce:	setne  BYTE PTR [rsp+0x8]
 2d3:	mov    r11,rax
 2d6:	lahf
 2d7:	seto   al
 2da:	mov    WORD PTR [rsp],ax
 2de:	mov    rax,r11
 2e1:	imul   r13,r15
 2e5:	add    r14,r13
 2e8:	mov    QWORD PTR [r12+0x50],r14
 2ed:	mov    r13,QWORD PTR [r12+0x48]
 2f2:	add    r8,r13
 2f5:	mov    QWORD PTR [r12+0x48],r8
 2fa:	mov    rcx,QWORD PTR [r12+0x380]
 302:	jrcxz  0x309
 304:	jmp    0x66b
 309:	cmp    BYTE PTR [rsp+0x8],0x0
 30e:	jne    0x276
 314:	jmp    0x319
 319:	mov    r13,QWORD PTR [r12+0xf8]
 321:	mov    r14,r13
 324:	add    r14,0x10
 328:	mov    r15,r14
 32b:	add    r15,0x8
 32f:	mov    rbp,QWORD PTR [r14]
 332:	mov    r14,QWORD PTR [r15]
 335:	mov    QWORD PTR [r12+0xa0],rbp
 33d:	mov    QWORD PTR [r12+0x98],r14
 345:	mov    r14,QWORD PTR [r12+0x48]
 34a:	mov    r15,QWORD PTR [r12+0x50]
 34f:	add    r15,r14
 352:	mov    QWORD PTR [r12+0x48],r15
 357:	mov    r14,QWORD PTR [r12+0x40]
 35c:	add    r14,0x288
 363:	mov    QWORD PTR [r14],r15
 366:	mov    r14d,0x0
 36c:	mov    DWORD PTR [r12+0x32c],r14d
 374:	mov    r14,r13
 377:	add    r14,0x20
 37b:	mov    r15,QWORD PTR [r13+0x0]
 37f:	mov    QWORD PTR [r12+0xf0],r15
 387:	mov    QWORD PTR [r12+0xf8],r14
 38f:	mov    rcx,QWORD PTR [r12+0x380]
 397:	jrcxz  0x39e
 399:	jmp    0x6ed
 39e:	mov    r13,QWORD PTR [r12+0xf0]
 3a6:	mov    QWORD PTR [r12+0x100],r13
 3ae:	mov    r11,QWORD PTR [rsp]
 3b2:	mov    QWORD PTR [r12+0x398],r11
 3ba:	mov    rdi,QWORD PTR [r12+0x100]
 3c2:	add    rsp,0x10
 3c6:	movabs r11,0x5c931c45a940
 3d0:	jmp    r11
 3d3:	mov    r13d,DWORD PTR [r12+0xa0]
 3db:	add    r13d,0x11
 3df:	mov    QWORD PTR [r12],r13
 3e3:	mov    r13d,0x410184
 3e9:	mov    QWORD PTR [r12+0xf0],r13
 3f1:	mov    r13d,0x41021c
 3f7:	mov    QWORD PTR [r12+0x100],r13
 3ff:	mov    r11,QWORD PTR [rsp]
 403:	mov    QWORD PTR [r12+0x398],r11
 40b:	mov    edi,0x41021c
 410:	mov    QWORD PTR [r12+0x100],rdi
 418:	add    rsp,0x10
 41c:	nop    DWORD PTR [rax+0x0]
 420:	jmp    QWORD PTR [rip+0x2]        # 0x428
 426:	xchg   ax,ax
 428:	lock loopne 0x3fa
 42b:	popf
 42c:	loope  0x4ad
 42e:	add    BYTE PTR [rax],al
 430:	call   0xffffffffe19dd41b
 435:	jg     0x437
 437:	add    BYTE PTR [rcx-0x45],cl
 43a:	rex test eax,0x5c931c45
 440:	add    BYTE PTR [rax],al
 442:	jmp    r11
 445:	mov    eax,0x410190
 44a:	mov    QWORD PTR [r12+0x100],rax
 452:	push   rdx
 453:	push   rsi
 454:	push   r10
 456:	push   r11
 458:	mov    r11,rax
 45b:	lahf
 45c:	seto   al
 45f:	mov    WORD PTR [rsp+0x20],ax
 464:	mov    rax,r11
 467:	mov    rdx,QWORD PTR [rsp+0x20]
 46c:	mov    r10d,edx
 46f:	and    r10d,0xc000
 476:	shl    r10d,0x10
 47a:	mov    r11d,edx
 47d:	and    r11d,0x100
 484:	shl    r11d,0x15
 488:	or     r10d,r11d
 48b:	and    edx,0x1
 48e:	shl    edx,0x1c
 491:	or     r10d,edx
 494:	btc    r10,0x1d
 499:	mov    r11d,0xf0000000
 49f:	and    r11,r10
 4a2:	movabs rsi,0xffffffff0fffffff
 4ac:	and    rbx,rsi
 4af:	or     rbx,r11
 4b2:	pop    r11
 4b4:	pop    r10
 4b6:	pop    rsi
 4b7:	pop    rdx
 4b8:	mov    QWORD PTR [r12+0x108],rbx
 4c0:	add    rsp,0x10
 4c4:	mov    eax,0xc
 4c9:	movabs r11,0x5c931c45aca0
 4d3:	jmp    r11
 4d6:	mov    eax,0x4101c4
 4db:	mov    QWORD PTR [r12+0x100],rax
 4e3:	push   rdx
 4e4:	push   rsi
 4e5:	push   r10
 4e7:	push   r11
 4e9:	mov    r11,rax
 4ec:	lahf
 4ed:	seto   al
 4f0:	mov    WORD PTR [rsp+0x20],ax
 4f5:	mov    rax,r11
 4f8:	mov    rdx,QWORD PTR [rsp+0x20]
 4fd:	mov    r10d,edx
 500:	and    r10d,0xc000
 507:	shl    r10d,0x10
 50b:	mov    r11d,edx
 50e:	and    r11d,0x100
 515:	shl    r11d,0x15
 519:	or     r10d,r11d
 51c:	and    edx,0x1
 51f:	shl    edx,0x1c
 522:	or     r10d,edx
 525:	btc    r10,0x1d
 52a:	mov    r11d,0xf0000000
 530:	and    r11,r10
 533:	movabs rsi,0xffffffff0fffffff
 53d:	and    rbx,rsi
 540:	or     rbx,r11
 543:	pop    r11
 545:	pop    r10
 547:	pop    rsi
 548:	pop    rdx
 549:	mov    QWORD PTR [r12+0x108],rbx
 551:	add    rsp,0x10
 555:	mov    eax,0xc
 55a:	movabs r11,0x5c931c45aca0
 564:	jmp    r11
 567:	mov    eax,0x4101d0
 56c:	mov    QWORD PTR [r12+0x100],rax
 574:	push   rdx
 575:	push   rsi
 576:	push   r10
 578:	push   r11
 57a:	mov    rdx,QWORD PTR [rsp+0x20]
 57f:	mov    r10d,edx
 582:	and    r10d,0xc000
 589:	shl    r10d,0x10
 58d:	mov    r11d,edx
 590:	and    r11d,0x100
 597:	shl    r11d,0x15
 59b:	or     r10d,r11d
 59e:	and    edx,0x1
 5a1:	shl    edx,0x1c
 5a4:	or     r10d,edx
 5a7:	btc    r10,0x1d
 5ac:	mov    r11d,0xf0000000
 5b2:	and    r11,r10
 5b5:	movabs rsi,0xffffffff0fffffff
 5bf:	and    rbx,rsi
 5c2:	or     rbx,r11
 5c5:	pop    r11
 5c7:	pop    r10
 5c9:	pop    rsi
 5ca:	pop    rdx
 5cb:	mov    QWORD PTR [r12+0x108],rbx
 5d3:	add    rsp,0x10
 5d7:	mov    eax,0xc
 5dc:	movabs r11,0x5c931c45aca0
 5e6:	jmp    r11
 5e9:	mov    eax,0x4101d4
 5ee:	mov    QWORD PTR [r12+0x100],rax
 5f6:	push   rdx
 5f7:	push   rsi
 5f8:	push   r10
 5fa:	push   r11
 5fc:	mov    rdx,QWORD PTR [rsp+0x20]
 601:	mov    r10d,edx
 604:	and    r10d,0xc000
 60b:	shl    r10d,0x10
 60f:	mov    r11d,edx
 612:	and    r11d,0x100
 619:	shl    r11d,0x15
 61d:	or     r10d,r11d
 620:	and    edx,0x1
 623:	shl    edx,0x1c
 626:	or     r10d,edx
 629:	btc    r10,0x1d
 62e:	mov    r11d,0xf0000000
 634:	and    r11,r10
 637:	movabs rsi,0xffffffff0fffffff
 641:	and    rbx,rsi
 644:	or     rbx,r11
 647:	pop    r11
 649:	pop    r10
 64b:	pop    rsi
 64c:	pop    rdx
 64d:	mov    QWORD PTR [r12+0x108],rbx
 655:	add    rsp,0x10
 659:	mov    eax,0xc
 65e:	movabs r11,0x5c931c45aca0
 668:	jmp    r11
 66b:	mov    eax,0x410204
 670:	mov    QWORD PTR [r12+0x100],rax
 678:	push   rdx
 679:	push   rsi
 67a:	push   r10
 67c:	push   r11
 67e:	mov    rdx,QWORD PTR [rsp+0x20]
 683:	mov    r10d,edx
 686:	and    r10d,0xc000
 68d:	shl    r10d,0x10
 691:	mov    r11d,edx
 694:	and    r11d,0x100
 69b:	shl    r11d,0x15
 69f:	or     r10d,r11d
 6a2:	and    edx,0x1
 6a5:	shl    edx,0x1c
 6a8:	or     r10d,edx
 6ab:	btc    r10,0x1d
 6b0:	mov    r11d,0xf0000000
 6b6:	and    r11,r10
 6b9:	movabs rsi,0xffffffff0fffffff
 6c3:	and    rbx,rsi
 6c6:	or     rbx,r11
 6c9:	pop    r11
 6cb:	pop    r10
 6cd:	pop    rsi
 6ce:	pop    rdx
 6cf:	mov    QWORD PTR [r12+0x108],rbx
 6d7:	add    rsp,0x10
 6db:	mov    eax,0xc
 6e0:	movabs r11,0x5c931c45aca0
 6ea:	jmp    r11
 6ed:	mov    eax,0x410218
 6f2:	mov    QWORD PTR [r12+0x100],rax
 6fa:	push   rdx
 6fb:	push   rsi
 6fc:	push   r10
 6fe:	push   r11
 700:	mov    rdx,QWORD PTR [rsp+0x20]
 705:	mov    r10d,edx
 708:	and    r10d,0xc000
 70f:	shl    r10d,0x10
 713:	mov    r11d,edx
 716:	and    r11d,0x100
 71d:	shl    r11d,0x15
 721:	or     r10d,r11d
 724:	and    edx,0x1
 727:	shl    edx,0x1c
 72a:	or     r10d,edx
 72d:	btc    r10,0x1d
 732:	mov    r11d,0xf0000000
 738:	and    r11,r10
 73b:	movabs rsi,0xffffffff0fffffff
 745:	and    rbx,rsi
 748:	or     rbx,r11
 74b:	pop    r11
 74d:	pop    r10
 74f:	pop    rsi
 750:	pop    rdx
 751:	mov    QWORD PTR [r12+0x108],rbx
 759:	add    rsp,0x10
 75d:	mov    eax,0xc
 762:	movabs r11,0x5c931c45aca0
 76c:	jmp    r11
 76f:	nop
 770:	sub    rsp,0x10
 774:	mov    r11,QWORD PTR [r12+0x398]
 77c:	mov    QWORD PTR [rsp],r11
 780:	jmp    0x8d
 785:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 790:	sub    rsp,0x10
 794:	mov    r11,QWORD PTR [r12+0x398]
 79c:	mov    QWORD PTR [rsp],r11
 7a0:	mov    r11,rax
 7a3:	movzx  eax,WORD PTR [rsp]
 7a7:	add    al,0x7f
 7a9:	sahf
 7aa:	mov    rax,r11
 7ad:	jmp    0xaa
 7b2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 7c0:	sub    rsp,0x10
 7c4:	mov    r11,QWORD PTR [r12+0x398]
 7cc:	mov    QWORD PTR [rsp],r11
 7d0:	jmp    0xee
 7d5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 7e0:	sub    rsp,0x10
 7e4:	mov    r11,QWORD PTR [r12+0x398]
 7ec:	mov    QWORD PTR [rsp],r11
 7f0:	jmp    0x162
 7f5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 800:	sub    rsp,0x10
 804:	mov    r11,QWORD PTR [r12+0x398]
 80c:	mov    QWORD PTR [rsp],r11
 810:	jmp    0x1bd
 815:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 820:	sub    rsp,0x10
 824:	mov    r11,QWORD PTR [r12+0x398]
 82c:	mov    QWORD PTR [rsp],r11
 830:	jmp    0x1d1
 835:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 840:	sub    rsp,0x10
 844:	mov    r11,QWORD PTR [r12+0x398]
 84c:	mov    QWORD PTR [rsp],r11
 850:	jmp    0x1e1
 855:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 860:	sub    rsp,0x10
 864:	mov    r11,QWORD PTR [r12+0x398]
 86c:	mov    QWORD PTR [rsp],r11
 870:	jmp    0x241
 875:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 880:	sub    rsp,0x10
 884:	mov    r11,QWORD PTR [r12+0x398]
 88c:	mov    QWORD PTR [rsp],r11
 890:	jmp    0x276
 895:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 8a0:	sub    rsp,0x10
 8a4:	mov    r11,QWORD PTR [r12+0x398]
 8ac:	mov    QWORD PTR [rsp],r11
 8b0:	jmp    0x319
 8b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 8c0:	sub    rsp,0x10
 8c4:	mov    r11,QWORD PTR [r12+0x398]
 8cc:	mov    QWORD PTR [rsp],r11
 8d0:	jmp    0x3d3
 8d5:	nop
 8d6:	nop
 8d7:	nop
