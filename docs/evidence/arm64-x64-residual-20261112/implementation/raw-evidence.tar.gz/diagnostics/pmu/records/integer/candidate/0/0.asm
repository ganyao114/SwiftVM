
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/integer/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r13d,0x1b00
   a:	mov    r14d,0xb7
  10:	and    r14d,0xffff
  17:	mov    rax,r13
  1a:	movabs rcx,0xffffffff0000ffff
  24:	and    rax,rcx
  27:	mov    rdx,r14
  2a:	shl    rdx,0x10
  2e:	mov    ecx,0xffff0000
  33:	and    rdx,rcx
  36:	or     rax,rdx
  39:	mov    r15,rax
  3c:	mov    QWORD PTR [r12+0x8],r15
  41:	mov    r13d,0x420060
  47:	mov    QWORD PTR [r12+0x20],r13
  4c:	mov    r13d,0x0
  52:	mov    QWORD PTR [r12],r13
  56:	jmp    0x5b
  5b:	mov    r13,QWORD PTR [r12]
  5f:	add    r13,0x3
  63:	mov    r14,r13
  66:	shr    r14,0x7
  6a:	xor    r13,r14
  6d:	mov    QWORD PTR [r12],r13
  71:	mov    r13,QWORD PTR [r12+0x8]
  76:	sub    r13,0x1
  7a:	mov    QWORD PTR [r12+0x8],r13
  7f:	mov    rcx,QWORD PTR [r12+0x380]
  87:	jrcxz  0x8e
  89:	jmp    0x106
  8e:	jne    0x5b
  94:	mov    r11,rax
  97:	lahf
  98:	seto   al
  9b:	mov    WORD PTR [rsp],ax
  9f:	mov    rax,r11
  a2:	jmp    0xa7
  a7:	mov    r13,QWORD PTR [r12+0x20]
  ac:	mov    r14,QWORD PTR [r12]
  b0:	mov    QWORD PTR [r13+0x0],r14
  b4:	mov    r13d,0x0
  ba:	mov    DWORD PTR [r12+0x32c],r13d
  c2:	mov    rcx,QWORD PTR [r12+0x380]
  ca:	jrcxz  0xd1
  cc:	jmp    0x197
  d1:	mov    r13,QWORD PTR [r12+0xf0]
  d9:	mov    QWORD PTR [r12+0x100],r13
  e1:	mov    r11,QWORD PTR [rsp]
  e5:	mov    QWORD PTR [r12+0x398],r11
  ed:	mov    rdi,QWORD PTR [r12+0x100]
  f5:	add    rsp,0x10
  f9:	movabs r11,0x60cb1f782940
 103:	jmp    r11
 106:	mov    eax,0x410048
 10b:	mov    QWORD PTR [r12+0x100],rax
 113:	push   rdx
 114:	push   rsi
 115:	push   r10
 117:	push   r11
 119:	mov    r11,rax
 11c:	lahf
 11d:	seto   al
 120:	mov    WORD PTR [rsp+0x20],ax
 125:	mov    rax,r11
 128:	mov    rdx,QWORD PTR [rsp+0x20]
 12d:	mov    r10d,edx
 130:	and    r10d,0xc000
 137:	shl    r10d,0x10
 13b:	mov    r11d,edx
 13e:	and    r11d,0x100
 145:	shl    r11d,0x15
 149:	or     r10d,r11d
 14c:	and    edx,0x1
 14f:	shl    edx,0x1c
 152:	or     r10d,edx
 155:	btc    r10,0x1d
 15a:	mov    r11d,0xf0000000
 160:	and    r11,r10
 163:	movabs rsi,0xffffffff0fffffff
 16d:	and    rbx,rsi
 170:	or     rbx,r11
 173:	pop    r11
 175:	pop    r10
 177:	pop    rsi
 178:	pop    rdx
 179:	mov    QWORD PTR [r12+0x108],rbx
 181:	add    rsp,0x10
 185:	mov    eax,0xc
 18a:	movabs r11,0x60cb1f782ca0
 194:	jmp    r11
 197:	mov    eax,0x410050
 19c:	mov    QWORD PTR [r12+0x100],rax
 1a4:	push   rdx
 1a5:	push   rsi
 1a6:	push   r10
 1a8:	push   r11
 1aa:	mov    rdx,QWORD PTR [rsp+0x20]
 1af:	mov    r10d,edx
 1b2:	and    r10d,0xc000
 1b9:	shl    r10d,0x10
 1bd:	mov    r11d,edx
 1c0:	and    r11d,0x100
 1c7:	shl    r11d,0x15
 1cb:	or     r10d,r11d
 1ce:	and    edx,0x1
 1d1:	shl    edx,0x1c
 1d4:	or     r10d,edx
 1d7:	btc    r10,0x1d
 1dc:	mov    r11d,0xf0000000
 1e2:	and    r11,r10
 1e5:	movabs rsi,0xffffffff0fffffff
 1ef:	and    rbx,rsi
 1f2:	or     rbx,r11
 1f5:	pop    r11
 1f7:	pop    r10
 1f9:	pop    rsi
 1fa:	pop    rdx
 1fb:	mov    QWORD PTR [r12+0x108],rbx
 203:	add    rsp,0x10
 207:	mov    eax,0xc
 20c:	movabs r11,0x60cb1f782ca0
 216:	jmp    r11
 219:	nop    DWORD PTR [rax+0x0]
 220:	sub    rsp,0x10
 224:	jmp    0x5b
 229:	nop    DWORD PTR [rax+0x0]
 230:	sub    rsp,0x10
 234:	mov    r11,QWORD PTR [r12+0x398]
 23c:	mov    QWORD PTR [rsp],r11
 240:	jmp    0xa7
 245:	nop
 246:	nop
 247:	nop
