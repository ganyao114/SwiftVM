
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/candidate/0/2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r13d,DWORD PTR [r12+0xa0]
   c:	sub    r13d,0x1
  10:	mov    QWORD PTR [r12+0xa0],r13
  18:	mov    rcx,QWORD PTR [r12+0x380]
  20:	jrcxz  0x27
  22:	jmp    0x1bd
  27:	jne    0x40
  2d:	mov    r11,rax
  30:	lahf
  31:	seto   al
  34:	mov    WORD PTR [rsp],ax
  38:	mov    rax,r11
  3b:	jmp    0x53
  40:	mov    r11,rax
  43:	lahf
  44:	seto   al
  47:	mov    WORD PTR [rsp],ax
  4b:	mov    rax,r11
  4e:	jmp    0x125
  53:	mov    r13,QWORD PTR [r12+0xf8]
  5b:	mov    r14,r13
  5e:	add    r14,0x120
  65:	mov    r15,QWORD PTR [r14]
  68:	mov    QWORD PTR [r12+0x98],r15
  70:	mov    r14d,0x80
  76:	mov    QWORD PTR [r12+0x40],r14
  7b:	mov    r14,r13
  7e:	add    r14,0x100
  85:	mov    QWORD PTR [r12],r14
  89:	mov    r14,r13
  8c:	add    r14,0x17c
  93:	mov    QWORD PTR [r12+0x8],r14
  98:	mov    r14d,0x1
  9e:	mov    QWORD PTR [r12+0x10],r14
  a3:	add    r13,0x17c
  aa:	movzx  r14d,BYTE PTR [r12+0x40]
  b0:	mov    BYTE PTR [r13+0x0],r14b
  b4:	mov    r13d,0x0
  ba:	mov    DWORD PTR [r12+0x32c],r13d
  c2:	mov    r13d,0x4102a8
  c8:	mov    QWORD PTR [r12+0xf0],r13
  d0:	mov    r13d,0x410728
  d6:	mov    QWORD PTR [r12+0x100],r13
  de:	mov    r11,QWORD PTR [rsp]
  e2:	mov    QWORD PTR [r12+0x398],r11
  ea:	mov    edi,0x410728
  ef:	mov    QWORD PTR [r12+0x100],rdi
  f7:	add    rsp,0x10
  fb:	nop    DWORD PTR [rax+rax*1+0x0]
 100:	jmp    QWORD PTR [rip+0x2]        # 0x108
 106:	xchg   ax,ax
 108:	loopne 0xef
 10a:	(bad)
 10b:	ins    BYTE PTR es:[rdi],dx
 10c:	or     BYTE PTR [rbx+0x0],bh
 10f:	add    BYTE PTR [rax+0x86c300c],bl
 115:	jnp    0x117
 117:	add    BYTE PTR [rcx-0x45],cl
 11a:	rex stc
 11c:	sub    BYTE PTR [rbp+0x590d],al
 122:	jmp    r11
 125:	mov    r13,QWORD PTR [r12+0xf8]
 12d:	add    r13,0x100
 134:	mov    QWORD PTR [r12],r13
 138:	mov    r13d,0x0
 13e:	mov    r14,QWORD PTR [r12+0x98]
 146:	or     r13,r14
 149:	mov    QWORD PTR [r12+0x8],r13
 14e:	mov    r13d,0x12c
 154:	mov    QWORD PTR [r12+0x10],r13
 159:	mov    r13d,0x410284
 15f:	mov    QWORD PTR [r12+0xf0],r13
 167:	mov    r13d,0x410728
 16d:	mov    QWORD PTR [r12+0x100],r13
 175:	mov    r11,QWORD PTR [rsp]
 179:	mov    QWORD PTR [r12+0x398],r11
 181:	mov    edi,0x410728
 186:	mov    QWORD PTR [r12+0x100],rdi
 18e:	add    rsp,0x10
 192:	nop    WORD PTR [rax+rax*1+0x0]
 198:	jmp    QWORD PTR [rip+0x2]        # 0x1a0
 19e:	xchg   ax,ax
 1a0:	loopne 0x187
 1a2:	(bad)
 1a3:	ins    BYTE PTR es:[rdi],dx
 1a4:	or     BYTE PTR [rbx+0x0],bh
 1a7:	add    BYTE PTR [rax],dh
 1a9:	or     eax,0x7b086c30
 1ae:	add    BYTE PTR [rax],al
 1b0:	movabs r11,0x590d8528f940
 1ba:	jmp    r11
 1bd:	mov    eax,0x410288
 1c2:	mov    QWORD PTR [r12+0x100],rax
 1ca:	push   rdx
 1cb:	push   rsi
 1cc:	push   r10
 1ce:	push   r11
 1d0:	mov    r11,rax
 1d3:	lahf
 1d4:	seto   al
 1d7:	mov    WORD PTR [rsp+0x20],ax
 1dc:	mov    rax,r11
 1df:	mov    rdx,QWORD PTR [rsp+0x20]
 1e4:	mov    r10d,edx
 1e7:	and    r10d,0xc000
 1ee:	shl    r10d,0x10
 1f2:	mov    r11d,edx
 1f5:	and    r11d,0x100
 1fc:	shl    r11d,0x15
 200:	or     r10d,r11d
 203:	and    edx,0x1
 206:	shl    edx,0x1c
 209:	or     r10d,edx
 20c:	btc    r10,0x1d
 211:	mov    r11d,0xf0000000
 217:	and    r11,r10
 21a:	movabs rsi,0xffffffff0fffffff
 224:	and    rbx,rsi
 227:	or     rbx,r11
 22a:	pop    r11
 22c:	pop    r10
 22e:	pop    rsi
 22f:	pop    rdx
 230:	mov    QWORD PTR [r12+0x108],rbx
 238:	add    rsp,0x10
 23c:	mov    eax,0xc
 241:	movabs r11,0x590d8528fca0
 24b:	jmp    r11
 24e:	xchg   ax,ax
 250:	sub    rsp,0x10
 254:	mov    r11,QWORD PTR [r12+0x398]
 25c:	mov    QWORD PTR [rsp],r11
 260:	jmp    0x53
 265:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 270:	sub    rsp,0x10
 274:	mov    r11,QWORD PTR [r12+0x398]
 27c:	mov    QWORD PTR [rsp],r11
 280:	jmp    0x125
 285:	nop
 286:	nop
 287:	nop
