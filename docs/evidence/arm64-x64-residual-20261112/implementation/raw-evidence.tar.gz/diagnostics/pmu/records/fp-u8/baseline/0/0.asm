
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/fp-u8/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x150
   7:	mov    r11,QWORD PTR [r12+0x398]
   f:	mov    QWORD PTR [rsp],r11
  13:	cmp    DWORD PTR [r12+0x310],0x0
  1c:	je     0xac
  22:	push   rdx
  23:	push   rsi
  24:	push   r10
  26:	push   r11
  28:	mov    rdx,QWORD PTR [rsp+0x20]
  2d:	mov    r10d,edx
  30:	and    r10d,0xc0
  37:	shl    r10d,0x18
  3b:	mov    r11d,edx
  3e:	and    r11d,0x1
  42:	shl    r11d,0x1d
  46:	or     r10d,r11d
  49:	mov    r11d,edx
  4c:	and    r11d,0x800
  53:	shl    r11d,0x11
  57:	or     r10d,r11d
  5a:	btc    r10,0x1d
  5f:	mov    r11d,0xf0000000
  65:	and    r11,r10
  68:	movabs rsi,0xffffffff0fffffff
  72:	and    rbx,rsi
  75:	or     rbx,r11
  78:	pop    r11
  7a:	pop    r10
  7c:	pop    rsi
  7d:	pop    rdx
  7e:	mov    QWORD PTR [r12+0x108],rbx
  86:	mov    eax,0x410028
  8b:	mov    QWORD PTR [r12+0x100],rax
  93:	add    rsp,0x150
  9a:	mov    eax,0x3
  9f:	movabs r11,0x5d8c4381d390
  a9:	jmp    r11
  ac:	mov    r13d,0xe848
  b2:	mov    r14d,0x1
  b8:	and    r14d,0xffff
  bf:	mov    rax,r13
  c2:	movabs rcx,0xffffffff0000ffff
  cc:	and    rax,rcx
  cf:	mov    rdx,r14
  d2:	shl    rdx,0x10
  d6:	mov    ecx,0xffff0000
  db:	and    rdx,rcx
  de:	or     rax,rdx
  e1:	mov    r15,rax
  e4:	mov    QWORD PTR [r12+0x8],r15
  e9:	mov    r13d,0x420080
  ef:	mov    QWORD PTR [r12+0x20],r13
  f4:	mov    r13d,0x0
  fa:	mov    QWORD PTR [r12],r13
  fe:	mov    r13d,0x0
 104:	movabs r14,0x3ff0000000000000
 10e:	mov    QWORD PTR [r12+0x110],r14
 116:	mov    QWORD PTR [r12+0x118],r13
 11e:	mov    r13d,0x0
 124:	movabs r14,0x3ff8000000000000
 12e:	mov    QWORD PTR [r12+0x120],r14
 136:	mov    QWORD PTR [r12+0x128],r13
 13e:	jmp    0x143
 143:	movdqu xmm0,XMMWORD PTR [r12+0x110]
 14d:	movdqa xmm2,xmm0
 151:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 15b:	movdqa xmm3,xmm0
 15f:	stmxcsr DWORD PTR [rsp+0x110]
 167:	mov    DWORD PTR [rsp+0x114],0x1f80
 172:	ldmxcsr DWORD PTR [rsp+0x114]
 17a:	movdqa xmm0,xmm2
 17e:	movdqa xmm1,xmm3
 182:	movq   rax,xmm0
 187:	add    rax,rax
 18a:	je     0x1a0
 18c:	shr    rax,0x35
 190:	sub    eax,0x201
 195:	cmp    eax,0x3fc
 19a:	ja     0x4e4
 1a0:	movq   rax,xmm1
 1a5:	add    rax,rax
 1a8:	je     0x1be
 1aa:	shr    rax,0x35
 1ae:	sub    eax,0x201
 1b3:	cmp    eax,0x3fc
 1b8:	ja     0x4e4
 1be:	movq   xmm0,xmm0
 1c2:	movq   xmm1,xmm1
 1c6:	addsd  xmm0,xmm1
 1ca:	movdqa xmm4,xmm0
 1ce:	movdqa xmm0,xmm4
 1d2:	movdqa xmm1,xmm3
 1d6:	movq   rax,xmm0
 1db:	add    rax,rax
 1de:	je     0x1f4
 1e0:	shr    rax,0x35
 1e4:	sub    eax,0x201
 1e9:	cmp    eax,0x3fc
 1ee:	ja     0x508
 1f4:	movq   rax,xmm1
 1f9:	add    rax,rax
 1fc:	je     0x212
 1fe:	shr    rax,0x35
 202:	sub    eax,0x201
 207:	cmp    eax,0x3fc
 20c:	ja     0x508
 212:	movq   xmm0,xmm0
 216:	movq   xmm1,xmm1
 21a:	addsd  xmm0,xmm1
 21e:	movdqa xmm2,xmm0
 222:	movdqa xmm0,xmm2
 226:	movdqa xmm1,xmm3
 22a:	movq   rax,xmm0
 22f:	add    rax,rax
 232:	je     0x248
 234:	shr    rax,0x35
 238:	sub    eax,0x201
 23d:	cmp    eax,0x3fc
 242:	ja     0x52c
 248:	movq   rax,xmm1
 24d:	add    rax,rax
 250:	je     0x266
 252:	shr    rax,0x35
 256:	sub    eax,0x201
 25b:	cmp    eax,0x3fc
 260:	ja     0x52c
 266:	movq   xmm0,xmm0
 26a:	movq   xmm1,xmm1
 26e:	addsd  xmm0,xmm1
 272:	movdqa xmm4,xmm0
 276:	movdqa xmm0,xmm4
 27a:	movdqa xmm1,xmm3
 27e:	movq   rax,xmm0
 283:	add    rax,rax
 286:	je     0x29c
 288:	shr    rax,0x35
 28c:	sub    eax,0x201
 291:	cmp    eax,0x3fc
 296:	ja     0x550
 29c:	movq   rax,xmm1
 2a1:	add    rax,rax
 2a4:	je     0x2ba
 2a6:	shr    rax,0x35
 2aa:	sub    eax,0x201
 2af:	cmp    eax,0x3fc
 2b4:	ja     0x550
 2ba:	movq   xmm0,xmm0
 2be:	movq   xmm1,xmm1
 2c2:	addsd  xmm0,xmm1
 2c6:	movdqa xmm2,xmm0
 2ca:	movdqa xmm0,xmm2
 2ce:	movdqa xmm1,xmm3
 2d2:	movq   rax,xmm0
 2d7:	add    rax,rax
 2da:	je     0x2f0
 2dc:	shr    rax,0x35
 2e0:	sub    eax,0x201
 2e5:	cmp    eax,0x3fc
 2ea:	ja     0x574
 2f0:	movq   rax,xmm1
 2f5:	add    rax,rax
 2f8:	je     0x30e
 2fa:	shr    rax,0x35
 2fe:	sub    eax,0x201
 303:	cmp    eax,0x3fc
 308:	ja     0x574
 30e:	movq   xmm0,xmm0
 312:	movq   xmm1,xmm1
 316:	addsd  xmm0,xmm1
 31a:	movdqa xmm4,xmm0
 31e:	movdqa xmm0,xmm4
 322:	movdqa xmm1,xmm3
 326:	movq   rax,xmm0
 32b:	add    rax,rax
 32e:	je     0x344
 330:	shr    rax,0x35
 334:	sub    eax,0x201
 339:	cmp    eax,0x3fc
 33e:	ja     0x598
 344:	movq   rax,xmm1
 349:	add    rax,rax
 34c:	je     0x362
 34e:	shr    rax,0x35
 352:	sub    eax,0x201
 357:	cmp    eax,0x3fc
 35c:	ja     0x598
 362:	movq   xmm0,xmm0
 366:	movq   xmm1,xmm1
 36a:	addsd  xmm0,xmm1
 36e:	movdqa xmm2,xmm0
 372:	movdqa xmm0,xmm2
 376:	movdqa xmm1,xmm3
 37a:	movq   rax,xmm0
 37f:	add    rax,rax
 382:	je     0x398
 384:	shr    rax,0x35
 388:	sub    eax,0x201
 38d:	cmp    eax,0x3fc
 392:	ja     0x5bc
 398:	movq   rax,xmm1
 39d:	add    rax,rax
 3a0:	je     0x3b6
 3a2:	shr    rax,0x35
 3a6:	sub    eax,0x201
 3ab:	cmp    eax,0x3fc
 3b0:	ja     0x5bc
 3b6:	movq   xmm0,xmm0
 3ba:	movq   xmm1,xmm1
 3be:	addsd  xmm0,xmm1
 3c2:	movdqa xmm4,xmm0
 3c6:	movdqa xmm0,xmm4
 3ca:	movdqa xmm1,xmm3
 3ce:	movq   rax,xmm0
 3d3:	add    rax,rax
 3d6:	je     0x3ec
 3d8:	shr    rax,0x35
 3dc:	sub    eax,0x201
 3e1:	cmp    eax,0x3fc
 3e6:	ja     0x5e0
 3ec:	movq   rax,xmm1
 3f1:	add    rax,rax
 3f4:	je     0x40a
 3f6:	shr    rax,0x35
 3fa:	sub    eax,0x201
 3ff:	cmp    eax,0x3fc
 404:	ja     0x5e0
 40a:	movq   xmm0,xmm0
 40e:	movq   xmm1,xmm1
 412:	addsd  xmm0,xmm1
 416:	movdqa xmm2,xmm0
 41a:	movdqa xmm0,xmm2
 41e:	movdqu XMMWORD PTR [r12+0x110],xmm0
 428:	mov    r13,QWORD PTR [r12+0x8]
 42d:	stmxcsr DWORD PTR [rsp+0x114]
 435:	ldmxcsr DWORD PTR [rsp+0x110]
 43d:	mov    r11d,DWORD PTR [rsp+0x114]
 445:	shr    r11d,1
 448:	and    r11d,0x10
 44c:	or     DWORD PTR [r12+0x314],r11d
 454:	sub    r13,0x1
 458:	mov    QWORD PTR [r12+0x8],r13
 45d:	mov    rcx,QWORD PTR [r12+0x380]
 465:	jrcxz  0x46c
 467:	jmp    0x7ce
 46c:	jne    0x143
 472:	pushf
 473:	pop    r11
 475:	mov    QWORD PTR [rsp],r11
 479:	jmp    0x47e
 47e:	mov    r13,QWORD PTR [r12+0x20]
 483:	mov    r14,QWORD PTR [r12+0x110]
 48b:	mov    QWORD PTR [r13+0x0],r14
 48f:	mov    r13d,0x0
 495:	mov    DWORD PTR [r12+0x32c],r13d
 49d:	mov    rcx,QWORD PTR [r12+0x380]
 4a5:	jrcxz  0x4ac
 4a7:	jmp    0x860
 4ac:	mov    r13,QWORD PTR [r12+0xf0]
 4b4:	mov    QWORD PTR [r12+0x100],r13
 4bc:	mov    r11,QWORD PTR [rsp]
 4c0:	mov    QWORD PTR [r12+0x398],r11
 4c8:	mov    rdi,QWORD PTR [r12+0x100]
 4d0:	add    rsp,0x150
 4d7:	movabs r11,0x5d8c4381d0a0
 4e1:	jmp    r11
 4e4:	movdqa xmm0,xmm2
 4e8:	movdqa xmm1,xmm3
 4ec:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 4f5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 4fe:	call   0x610
 503:	jmp    0x1ca
 508:	movdqa xmm0,xmm4
 50c:	movdqa xmm1,xmm3
 510:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 519:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 522:	call   0x6f0
 527:	jmp    0x21e
 52c:	movdqa xmm0,xmm2
 530:	movdqa xmm1,xmm3
 534:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 53d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 546:	call   0x610
 54b:	jmp    0x272
 550:	movdqa xmm0,xmm4
 554:	movdqa xmm1,xmm3
 558:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 561:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 56a:	call   0x6f0
 56f:	jmp    0x2c6
 574:	movdqa xmm0,xmm2
 578:	movdqa xmm1,xmm3
 57c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 585:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 58e:	call   0x610
 593:	jmp    0x31a
 598:	movdqa xmm0,xmm4
 59c:	movdqa xmm1,xmm3
 5a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 5a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 5b2:	call   0x6f0
 5b7:	jmp    0x36e
 5bc:	movdqa xmm0,xmm2
 5c0:	movdqa xmm1,xmm3
 5c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 5cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 5d6:	call   0x610
 5db:	jmp    0x3c2
 5e0:	movdqa xmm0,xmm4
 5e4:	movdqa xmm1,xmm3
 5e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 5f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 5fa:	call   0x6f0
 5ff:	jmp    0x416
 604:	data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 610:	sub    rsp,0x8
 614:	stmxcsr DWORD PTR [rsp+0x124]
 61c:	ldmxcsr DWORD PTR [rsp+0x120]
 624:	mov    r11d,DWORD PTR [rsp+0x124]
 62c:	shr    r11d,1
 62f:	and    r11d,0x10
 633:	or     DWORD PTR [r12+0x314],r11d
 63b:	mov    QWORD PTR [r12+0x378],0x3
 647:	movdqu XMMWORD PTR [rsp+0x20],xmm2
 64d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
 653:	mov    QWORD PTR [r12+0x108],rbx
 65b:	stmxcsr DWORD PTR [r12-0x28]
 661:	ldmxcsr DWORD PTR [r12-0x38]
 667:	lea    rdi,[rsp+0x110]
 66f:	lea    rsi,[rsp+0xf0]
 677:	lea    rdx,[rsp+0x100]
 67f:	mov    ecx,0xc
 684:	mov    r8d,0x0
 68a:	lea    r9,[r12+0x314]
 692:	movabs r11,0x5d8c436881b0
 69c:	call   r11
 69f:	ldmxcsr DWORD PTR [r12-0x28]
 6a5:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
 6ab:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
 6b1:	mov    rbx,QWORD PTR [r12+0x108]
 6b9:	mov    QWORD PTR [r12+0x378],0x2
 6c5:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
 6ce:	stmxcsr DWORD PTR [rsp+0x120]
 6d6:	mov    DWORD PTR [rsp+0x124],0x1f80
 6e1:	ldmxcsr DWORD PTR [rsp+0x124]
 6e9:	add    rsp,0x8
 6ed:	ret
 6ee:	xchg   ax,ax
 6f0:	sub    rsp,0x8
 6f4:	stmxcsr DWORD PTR [rsp+0x124]
 6fc:	ldmxcsr DWORD PTR [rsp+0x120]
 704:	mov    r11d,DWORD PTR [rsp+0x124]
 70c:	shr    r11d,1
 70f:	and    r11d,0x10
 713:	or     DWORD PTR [r12+0x314],r11d
 71b:	mov    QWORD PTR [r12+0x378],0x3
 727:	movdqu XMMWORD PTR [rsp+0x30],xmm3
 72d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
 733:	mov    QWORD PTR [r12+0x108],rbx
 73b:	stmxcsr DWORD PTR [r12-0x28]
 741:	ldmxcsr DWORD PTR [r12-0x38]
 747:	lea    rdi,[rsp+0x110]
 74f:	lea    rsi,[rsp+0xf0]
 757:	lea    rdx,[rsp+0x100]
 75f:	mov    ecx,0xc
 764:	mov    r8d,0x0
 76a:	lea    r9,[r12+0x314]
 772:	movabs r11,0x5d8c436881b0
 77c:	call   r11
 77f:	ldmxcsr DWORD PTR [r12-0x28]
 785:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
 78b:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
 791:	mov    rbx,QWORD PTR [r12+0x108]
 799:	mov    QWORD PTR [r12+0x378],0x2
 7a5:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
 7ae:	stmxcsr DWORD PTR [rsp+0x120]
 7b6:	mov    DWORD PTR [rsp+0x124],0x1f80
 7c1:	ldmxcsr DWORD PTR [rsp+0x124]
 7c9:	add    rsp,0x8
 7cd:	ret
 7ce:	mov    eax,0x410068
 7d3:	mov    QWORD PTR [r12+0x100],rax
 7db:	push   rdx
 7dc:	push   rsi
 7dd:	push   r10
 7df:	push   r11
 7e1:	pushf
 7e2:	pop    r11
 7e4:	mov    QWORD PTR [rsp+0x20],r11
 7e9:	mov    rdx,QWORD PTR [rsp+0x20]
 7ee:	mov    r10d,edx
 7f1:	and    r10d,0xc0
 7f8:	shl    r10d,0x18
 7fc:	mov    r11d,edx
 7ff:	and    r11d,0x1
 803:	shl    r11d,0x1d
 807:	or     r10d,r11d
 80a:	mov    r11d,edx
 80d:	and    r11d,0x800
 814:	shl    r11d,0x11
 818:	or     r10d,r11d
 81b:	btc    r10,0x1d
 820:	mov    r11d,0xf0000000
 826:	and    r11,r10
 829:	movabs rsi,0xffffffff0fffffff
 833:	and    rbx,rsi
 836:	or     rbx,r11
 839:	pop    r11
 83b:	pop    r10
 83d:	pop    rsi
 83e:	pop    rdx
 83f:	mov    QWORD PTR [r12+0x108],rbx
 847:	add    rsp,0x150
 84e:	mov    eax,0xc
 853:	movabs r11,0x5d8c4381d390
 85d:	jmp    r11
 860:	mov    eax,0x410070
 865:	mov    QWORD PTR [r12+0x100],rax
 86d:	push   rdx
 86e:	push   rsi
 86f:	push   r10
 871:	push   r11
 873:	mov    rdx,QWORD PTR [rsp+0x20]
 878:	mov    r10d,edx
 87b:	and    r10d,0xc0
 882:	shl    r10d,0x18
 886:	mov    r11d,edx
 889:	and    r11d,0x1
 88d:	shl    r11d,0x1d
 891:	or     r10d,r11d
 894:	mov    r11d,edx
 897:	and    r11d,0x800
 89e:	shl    r11d,0x11
 8a2:	or     r10d,r11d
 8a5:	btc    r10,0x1d
 8aa:	mov    r11d,0xf0000000
 8b0:	and    r11,r10
 8b3:	movabs rsi,0xffffffff0fffffff
 8bd:	and    rbx,rsi
 8c0:	or     rbx,r11
 8c3:	pop    r11
 8c5:	pop    r10
 8c7:	pop    rsi
 8c8:	pop    rdx
 8c9:	mov    QWORD PTR [r12+0x108],rbx
 8d1:	add    rsp,0x150
 8d8:	mov    eax,0xc
 8dd:	movabs r11,0x5d8c4381d390
 8e7:	jmp    r11
 8ea:	nop    WORD PTR [rax+rax*1+0x0]
 8f0:	sub    rsp,0x150
 8f7:	mov    r11,QWORD PTR [r12+0x398]
 8ff:	mov    QWORD PTR [rsp],r11
 903:	cmp    DWORD PTR [r12+0x310],0x0
 90c:	je     0x99c
 912:	push   rdx
 913:	push   rsi
 914:	push   r10
 916:	push   r11
 918:	mov    rdx,QWORD PTR [rsp+0x20]
 91d:	mov    r10d,edx
 920:	and    r10d,0xc0
 927:	shl    r10d,0x18
 92b:	mov    r11d,edx
 92e:	and    r11d,0x1
 932:	shl    r11d,0x1d
 936:	or     r10d,r11d
 939:	mov    r11d,edx
 93c:	and    r11d,0x800
 943:	shl    r11d,0x11
 947:	or     r10d,r11d
 94a:	btc    r10,0x1d
 94f:	mov    r11d,0xf0000000
 955:	and    r11,r10
 958:	movabs rsi,0xffffffff0fffffff
 962:	and    rbx,rsi
 965:	or     rbx,r11
 968:	pop    r11
 96a:	pop    r10
 96c:	pop    rsi
 96d:	pop    rdx
 96e:	mov    QWORD PTR [r12+0x108],rbx
 976:	mov    eax,0x410044
 97b:	mov    QWORD PTR [r12+0x100],rax
 983:	add    rsp,0x150
 98a:	mov    eax,0x3
 98f:	movabs r11,0x5d8c4381d390
 999:	jmp    r11
 99c:	jmp    0x143
 9a1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 9b0:	sub    rsp,0x150
 9b7:	mov    r11,QWORD PTR [r12+0x398]
 9bf:	mov    QWORD PTR [rsp],r11
 9c3:	cmp    DWORD PTR [r12+0x310],0x0
 9cc:	je     0xa5c
 9d2:	push   rdx
 9d3:	push   rsi
 9d4:	push   r10
 9d6:	push   r11
 9d8:	mov    rdx,QWORD PTR [rsp+0x20]
 9dd:	mov    r10d,edx
 9e0:	and    r10d,0xc0
 9e7:	shl    r10d,0x18
 9eb:	mov    r11d,edx
 9ee:	and    r11d,0x1
 9f2:	shl    r11d,0x1d
 9f6:	or     r10d,r11d
 9f9:	mov    r11d,edx
 9fc:	and    r11d,0x800
 a03:	shl    r11d,0x11
 a07:	or     r10d,r11d
 a0a:	btc    r10,0x1d
 a0f:	mov    r11d,0xf0000000
 a15:	and    r11,r10
 a18:	movabs rsi,0xffffffff0fffffff
 a22:	and    rbx,rsi
 a25:	or     rbx,r11
 a28:	pop    r11
 a2a:	pop    r10
 a2c:	pop    rsi
 a2d:	pop    rdx
 a2e:	mov    QWORD PTR [r12+0x108],rbx
 a36:	mov    eax,0x41006c
 a3b:	mov    QWORD PTR [r12+0x100],rax
 a43:	add    rsp,0x150
 a4a:	mov    eax,0x3
 a4f:	movabs r11,0x5d8c4381d390
 a59:	jmp    r11
 a5c:	jmp    0x47e
 a61:	nop
 a62:	nop
 a63:	nop
