000078f8213ce69b  nop [rax+rax*1], eax
000078f8213ce6a0  vmovaps xmm1, [0x000078F820FFE010]
000078f8213ce6a8  movq xmm1, xmm1
000078f8213ce6ac  movaps [r15+0x110], xmm1
000078f8213ce6b4  vmovaps xmm1, [0x000078F820FFE020]
000078f8213ce6bc  movq xmm1, xmm1
000078f8213ce6c0  movaps [r15+0x120], xmm1
000078f8213ce6c8  mov eax, 0x4204C0
000078f8213ce6cd  mov r14, [r13+rax*1]
000078f8213ce6d2  movq xmm1, r14
000078f8213ce6d7  movaps [r15+0x130], xmm1
000078f8213ce6df  vmovaps xmm1, [0x000078F820FFE030]
000078f8213ce6e7  vpbroadcastq xmm1, xmm1
000078f8213ce6ec  movaps [r15+0x140], xmm1
000078f8213ce6f4  mov qword ptr [r15+0x40], 0x02
000078f8213ce6fc  vmovaps xmm15, [0x000078F820FFE040]
000078f8213ce704  movq xmm15, xmm15
000078f8213ce709  movaps [r15+0x150], xmm15
000078f8213ce711  mov qword ptr [r15+0x58], 0x420000
000078f8213ce719  vmovaps xmm15, [0x000078F820FFE050]
000078f8213ce721  vpbroadcastq xmm15, xmm15
000078f8213ce726  movaps [r15+0x160], xmm15
000078f8213ce72e  mov rax, [r15+0x40]
000078f8213ce732  vmovq xmm14, rax
000078f8213ce737  vpbroadcastq xmm14, xmm14
000078f8213ce73c  movaps [r15+0x170], xmm14
000078f8213ce744  mov eax, 0x4204D0
000078f8213ce749  movups xmm13, [r13+rax*1]
000078f8213ce74f  mov qword ptr [r15+0x40], 0x430518
000078f8213ce757  mov qword ptr [r15+0x50], 0x430720
000078f8213ce75f  vpmovqd xmm12, xmm13
000078f8213ce765  pxor xmm11, xmm11
000078f8213ce76a  punpcklqdq xmm12, xmm11
000078f8213ce76f  movaps [r15+0x210], xmm12
000078f8213ce777  movq xmm12, qword ptr [r15+0x120]
000078f8213ce780  movq xmm11, qword ptr [r15+0x130]
000078f8213ce789  psubd xmm12, xmm11
000078f8213ce78e  movq xmm12, xmm12
000078f8213ce793  paddq xmm13, xmm14
000078f8213ce798  movaps [r15+0x180], xmm13
000078f8213ce7a0  movq xmm14, qword ptr [r15+0x150]
000078f8213ce7a9  paddd xmm11, xmm14
000078f8213ce7ae  movq xmm11, xmm11
000078f8213ce7b3  movq xmm11, xmm11
000078f8213ce7b8  movaps [r15+0x130], xmm11
000078f8213ce7c0  pmovzxdq xmm12, xmm12
000078f8213ce7c6  psllq xmm12, 0x00
000078f8213ce7cc  movq xmm14, qword ptr [r15+0x210]
000078f8213ce7d5  movq xmm13, qword ptr [r15+0x110]
000078f8213ce7de  paddd xmm14, xmm13
000078f8213ce7e3  movq xmm14, xmm14
000078f8213ce7e8  vcvtuqq2pd xmm12, xmm12
000078f8213ce7ee  pmovzxdq xmm14, xmm14
000078f8213ce7f4  psllq xmm14, 0x00
000078f8213ce7fa  vcvtuqq2pd xmm14, xmm14
000078f8213ce800  movaps xmm13, xmm12
000078f8213ce804  mulpd xmm13, xmm1
000078f8213ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000078f8213ce80f  ptest xmm11, xmm11
000078f8213ce815  jnz 0x000078F8213CE8FF
000078f8213ce81b  movaps [r15+0x220], xmm13
000078f8213ce823  mov eax, 0x430720
000078f8213ce828  movups [r13+rax*1], xmm13
000078f8213ce82e  movaps xmm1, xmm14
000078f8213ce832  mulpd xmm1, xmm15
000078f8213ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000078f8213ce83c  ptest xmm13, xmm13
000078f8213ce842  jnz 0x000078F8213CEA4C
000078f8213ce848  movaps [r15+0x210], xmm1
000078f8213ce850  mov eax, 0x430518
000078f8213ce855  movups [r13+rax*1], xmm1
000078f8213ce85b  mov qword ptr [r15+0x48], 0x10
000078f8213ce863  xor eax, eax
000078f8213ce865  mov r14d, 0x10
000078f8213ce86b  mov r12d, 0x200
000078f8213ce871  cmp r14, r12
000078f8213ce874  cmc
000078f8213ce875  lahf
000078f8213ce876  seto al
000078f8213ce879  mov [r15+0x108], eax
000078f8213ce880  mov eax, [r15+0x108]
000078f8213ce887  sahf
000078f8213ce888  jnz 0x000078F8213CE8BA
000078f8213ce88a  cmp dword ptr [r15+0x318], 0x00
000078f8213ce892  jz 0x000078F8213CEFF0
000078f8213ce898  nop [rax+rax*1], ax
000078f8213ce8a1  nop [rax+rax*1], eax
000078f8213ce8a9  mov eax, 0x4101EC
000078f8213ce8ae  mov [r15+0x100], rax
000078f8213ce8b5  jmp 0x000078F8211FE110
000078f8213ce8ba  cmp dword ptr [r15+0x318], 0x00
000078f8213ce8c2  jz 0x000078F8213CEBA0
000078f8213ce8c8  nop [rax+rax*1], ax
000078f8213ce8d1  nop [rax+rax*1], eax
000078f8213ce8d9  mov eax, 0x4101AC
000078f8213ce8de  mov [r15+0x100], rax
000078f8213ce8e5  jmp 0x000078F8211FE110
000078f8213ce8ea  int3
000078f8213ce8eb  call 0x000078F82120DC20
000078f8213ce8f0  jmp 0x000078F8213CE6D2
000078f8213ce8f5  call 0x000078F82120C260
000078f8213ce8fa  jmp 0x000078F8213CE74F
000078f8213ce8ff  sub rsp, 0x08
000078f8213ce903  push rax
000078f8213ce904  push rcx
000078f8213ce905  push rdx
000078f8213ce906  push rdi
000078f8213ce907  push rsi
000078f8213ce908  push r8
000078f8213ce90a  push r9
000078f8213ce90c  push r10
000078f8213ce90e  push r11
000078f8213ce910  sub rsp, 0xF0
000078f8213ce917  vmovaps [rsp], xmm0
000078f8213ce91c  vmovaps [rsp+0x10], xmm1
000078f8213ce922  vmovaps [rsp+0x20], xmm2
000078f8213ce928  vmovaps [rsp+0x30], xmm3
000078f8213ce92e  vmovaps [rsp+0x40], xmm4
000078f8213ce934  vmovaps [rsp+0x50], xmm5
000078f8213ce93a  vmovaps [rsp+0x60], xmm6
000078f8213ce940  vmovaps [rsp+0x70], xmm7
000078f8213ce946  vmovaps [rsp+0x80], xmm8
000078f8213ce94f  vmovaps [rsp+0x90], xmm9
000078f8213ce958  vmovaps [rsp+0xA0], xmm10
000078f8213ce961  vmovaps [rsp+0xB0], xmm11
000078f8213ce96a  vmovaps [rsp+0xC0], xmm12
000078f8213ce973  vmovaps [rsp+0xD0], xmm14
000078f8213ce97c  vmovaps [rsp+0xE0], xmm15
000078f8213ce985  sub rsp, 0x30
000078f8213ce989  movaps [rsp], xmm13
000078f8213ce98e  movaps [rsp+0x10], xmm12
000078f8213ce994  movaps [rsp+0x20], xmm1
000078f8213ce999  lea rdi, [rsp]
000078f8213ce99d  mov esi, 0x00
000078f8213ce9a2  mov rax, 0x653D80F42530
000078f8213ce9ac  call rax
000078f8213ce9ae  movaps xmm13, [rsp]
000078f8213ce9b3  add rsp, 0x30
000078f8213ce9b7  vmovaps xmm0, [rsp]
000078f8213ce9bc  vmovaps xmm1, [rsp+0x10]
000078f8213ce9c2  vmovaps xmm2, [rsp+0x20]
000078f8213ce9c8  vmovaps xmm3, [rsp+0x30]
000078f8213ce9ce  vmovaps xmm4, [rsp+0x40]
000078f8213ce9d4  vmovaps xmm5, [rsp+0x50]
000078f8213ce9da  vmovaps xmm6, [rsp+0x60]
000078f8213ce9e0  vmovaps xmm7, [rsp+0x70]
000078f8213ce9e6  vmovaps xmm8, [rsp+0x80]
000078f8213ce9ef  vmovaps xmm9, [rsp+0x90]
000078f8213ce9f8  vmovaps xmm10, [rsp+0xA0]
000078f8213cea01  vmovaps xmm11, [rsp+0xB0]
000078f8213cea0a  vmovaps xmm12, [rsp+0xC0]
000078f8213cea13  vmovaps xmm14, [rsp+0xD0]
000078f8213cea1c  vmovaps xmm15, [rsp+0xE0]
000078f8213cea25  add rsp, 0xF0
000078f8213cea2c  pop r11
000078f8213cea2e  pop r10
000078f8213cea30  pop r9
000078f8213cea32  pop r8
000078f8213cea34  pop rsi
000078f8213cea35  pop rdi
000078f8213cea36  pop rdx
000078f8213cea37  pop rcx
000078f8213cea38  pop rax
000078f8213cea39  add rsp, 0x08
000078f8213cea3d  jmp 0x000078F8213CE81B
000078f8213cea42  call 0x000078F82120C380
000078f8213cea47  jmp 0x000078F8213CE82E
000078f8213cea4c  sub rsp, 0x08
000078f8213cea50  push rax
000078f8213cea51  push rcx
000078f8213cea52  push rdx
000078f8213cea53  push rdi
000078f8213cea54  push rsi
000078f8213cea55  push r8
000078f8213cea57  push r9
000078f8213cea59  push r10
000078f8213cea5b  push r11
000078f8213cea5d  sub rsp, 0xF0
000078f8213cea64  vmovaps [rsp], xmm0
000078f8213cea69  vmovaps [rsp+0x10], xmm2
000078f8213cea6f  vmovaps [rsp+0x20], xmm3
000078f8213cea75  vmovaps [rsp+0x30], xmm4
000078f8213cea7b  vmovaps [rsp+0x40], xmm5
000078f8213cea81  vmovaps [rsp+0x50], xmm6
000078f8213cea87  vmovaps [rsp+0x60], xmm7
000078f8213cea8d  vmovaps [rsp+0x70], xmm8
000078f8213cea93  vmovaps [rsp+0x80], xmm9
000078f8213cea9c  vmovaps [rsp+0x90], xmm10
000078f8213ceaa5  vmovaps [rsp+0xA0], xmm11
000078f8213ceaae  vmovaps [rsp+0xB0], xmm12
000078f8213ceab7  vmovaps [rsp+0xC0], xmm13
000078f8213ceac0  vmovaps [rsp+0xD0], xmm14
000078f8213ceac9  vmovaps [rsp+0xE0], xmm15
000078f8213cead2  sub rsp, 0x30
000078f8213cead6  movaps [rsp], xmm1
000078f8213ceada  movaps [rsp+0x10], xmm14
000078f8213ceae0  movaps [rsp+0x20], xmm15
000078f8213ceae6  lea rdi, [rsp]
000078f8213ceaea  mov esi, 0x00
000078f8213ceaef  mov rax, 0x653D80F42530
000078f8213ceaf9  call rax
000078f8213ceafb  movaps xmm1, [rsp]
000078f8213ceaff  add rsp, 0x30
000078f8213ceb03  vmovaps xmm0, [rsp]
000078f8213ceb08  vmovaps xmm2, [rsp+0x10]
000078f8213ceb0e  vmovaps xmm3, [rsp+0x20]
000078f8213ceb14  vmovaps xmm4, [rsp+0x30]
000078f8213ceb1a  vmovaps xmm5, [rsp+0x40]
000078f8213ceb20  vmovaps xmm6, [rsp+0x50]
000078f8213ceb26  vmovaps xmm7, [rsp+0x60]
000078f8213ceb2c  vmovaps xmm8, [rsp+0x70]
000078f8213ceb32  vmovaps xmm9, [rsp+0x80]
000078f8213ceb3b  vmovaps xmm10, [rsp+0x90]
000078f8213ceb44  vmovaps xmm11, [rsp+0xA0]
000078f8213ceb4d  vmovaps xmm12, [rsp+0xB0]
000078f8213ceb56  vmovaps xmm13, [rsp+0xC0]
000078f8213ceb5f  vmovaps xmm14, [rsp+0xD0]
000078f8213ceb68  vmovaps xmm15, [rsp+0xE0]
000078f8213ceb71  add rsp, 0xF0
000078f8213ceb78  pop r11
000078f8213ceb7a  pop r10
000078f8213ceb7c  pop r9
000078f8213ceb7e  pop r8
000078f8213ceb80  pop rsi
000078f8213ceb81  pop rdi
000078f8213ceb82  pop rdx
000078f8213ceb83  pop rcx
000078f8213ceb84  pop rax
000078f8213ceb85  add rsp, 0x08
000078f8213ceb89  jmp 0x000078F8213CE848
000078f8213ceb8e  call 0x000078F8211FF540
000078f8213ceb93  jmp 0x000078F8213CE85B
000078f8213ceb98  int3
000078f8213ceb99  nop [rax], eax
000078f8213ceba0  movaps xmm1, [r15+0x180]
000078f8213ceba8  vpmovqd xmm15, xmm1
000078f8213cebae  pxor xmm14, xmm14
000078f8213cebb3  punpcklqdq xmm15, xmm14
000078f8213cebb8  movaps [r15+0x210], xmm15
000078f8213cebc0  movq xmm15, qword ptr [r15+0x120]
000078f8213cebc9  movq xmm14, qword ptr [r15+0x130]
000078f8213cebd2  psubd xmm15, xmm14
000078f8213cebd7  movq xmm15, xmm15
000078f8213cebdc  movaps xmm13, [r15+0x170]
000078f8213cebe4  paddq xmm1, xmm13
000078f8213cebe9  movaps [r15+0x180], xmm1
000078f8213cebf1  movq xmm1, qword ptr [r15+0x150]
000078f8213cebfa  paddd xmm14, xmm1
000078f8213cebff  movq xmm14, xmm14
000078f8213cec04  movq xmm14, xmm14
000078f8213cec09  movaps [r15+0x130], xmm14
000078f8213cec11  pmovzxdq xmm15, xmm15
000078f8213cec17  psllq xmm15, 0x00
000078f8213cec1d  movq xmm1, qword ptr [r15+0x210]
000078f8213cec26  movq xmm14, qword ptr [r15+0x110]
000078f8213cec2f  paddd xmm1, xmm14
000078f8213cec34  movq xmm1, xmm1
000078f8213cec38  vcvtuqq2pd xmm15, xmm15
000078f8213cec3e  pmovzxdq xmm1, xmm1
000078f8213cec43  psllq xmm1, 0x00
000078f8213cec48  vcvtuqq2pd xmm1, xmm1
000078f8213cec4e  movaps xmm14, [r15+0x140]
000078f8213cec56  movaps xmm13, xmm15
000078f8213cec5a  mulpd xmm13, xmm14
000078f8213cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000078f8213cec65  ptest xmm12, xmm12
000078f8213cec6b  jnz 0x000078F8213CED4E
000078f8213cec71  movaps [r15+0x220], xmm13
000078f8213cec79  mov rax, [r15+0x48]
000078f8213cec7d  mov r14, [r15+0x50]
000078f8213cec81  lea r12, [r14+rax*1]
000078f8213cec85  movups [r13+r12*1], xmm13
000078f8213cec8b  movaps xmm15, [r15+0x160]
000078f8213cec93  movaps xmm14, xmm1
000078f8213cec97  mulpd xmm14, xmm15
000078f8213cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000078f8213ceca2  ptest xmm13, xmm13
000078f8213ceca8  jnz 0x000078F8213CEE9C
000078f8213cecae  movaps [r15+0x210], xmm14
000078f8213cecb6  mov r14, [r15+0x40]
000078f8213cecba  lea r12, [r14+rax*1]
000078f8213cecbe  movups [r13+r12*1], xmm14
000078f8213cecc4  lea r14, [rax+0x10]
000078f8213cecc8  mov [r15+0x48], r14
000078f8213ceccc  xor eax, eax
000078f8213cecce  mov r12d, 0x200
000078f8213cecd4  cmp r14, r12
000078f8213cecd7  cmc
000078f8213cecd8  lahf
000078f8213cecd9  seto al
000078f8213cecdc  mov [r15+0x108], eax
000078f8213cece3  mov eax, [r15+0x108]
000078f8213cecea  sahf
000078f8213ceceb  jnz 0x000078F8213CED1D
000078f8213ceced  cmp dword ptr [r15+0x318], 0x00
000078f8213cecf5  jz 0x000078F8213CEFF0
000078f8213cecfb  nop [rax+rax*1], ax
000078f8213ced04  nop [rax+rax*1], eax
000078f8213ced0c  mov eax, 0x4101EC
000078f8213ced11  mov [r15+0x100], rax
000078f8213ced18  jmp 0x000078F8211FE110
000078f8213ced1d  cmp dword ptr [r15+0x318], 0x00
000078f8213ced25  jz 0x000078F8213CEBA0
000078f8213ced2b  nop [rax+rax*1], ax
000078f8213ced34  nop [rax+rax*1], eax
000078f8213ced3c  mov eax, 0x4101AC
000078f8213ced41  mov [r15+0x100], rax
000078f8213ced48  jmp 0x000078F8211FE110
000078f8213ced4d  int3
000078f8213ced4e  sub rsp, 0x08
000078f8213ced52  push rax
000078f8213ced53  push rcx
000078f8213ced54  push rdx
000078f8213ced55  push rdi
000078f8213ced56  push rsi
000078f8213ced57  push r8
000078f8213ced59  push r9
000078f8213ced5b  push r10
000078f8213ced5d  push r11
000078f8213ced5f  sub rsp, 0xF0
000078f8213ced66  vmovaps [rsp], xmm0
000078f8213ced6b  vmovaps [rsp+0x10], xmm1
000078f8213ced71  vmovaps [rsp+0x20], xmm2
000078f8213ced77  vmovaps [rsp+0x30], xmm3
000078f8213ced7d  vmovaps [rsp+0x40], xmm4
000078f8213ced83  vmovaps [rsp+0x50], xmm5
000078f8213ced89  vmovaps [rsp+0x60], xmm6
000078f8213ced8f  vmovaps [rsp+0x70], xmm7
000078f8213ced95  vmovaps [rsp+0x80], xmm8
000078f8213ced9e  vmovaps [rsp+0x90], xmm9
000078f8213ceda7  vmovaps [rsp+0xA0], xmm10
000078f8213cedb0  vmovaps [rsp+0xB0], xmm11
000078f8213cedb9  vmovaps [rsp+0xC0], xmm12
000078f8213cedc2  vmovaps [rsp+0xD0], xmm14
000078f8213cedcb  vmovaps [rsp+0xE0], xmm15
000078f8213cedd4  sub rsp, 0x30
000078f8213cedd8  movaps [rsp], xmm13
000078f8213ceddd  movaps [rsp+0x10], xmm15
000078f8213cede3  movaps [rsp+0x20], xmm14
000078f8213cede9  lea rdi, [rsp]
000078f8213ceded  mov esi, 0x00
000078f8213cedf2  mov rax, 0x653D80F42530
000078f8213cedfc  call rax
000078f8213cedfe  movaps xmm13, [rsp]
000078f8213cee03  add rsp, 0x30
000078f8213cee07  vmovaps xmm0, [rsp]
000078f8213cee0c  vmovaps xmm1, [rsp+0x10]
000078f8213cee12  vmovaps xmm2, [rsp+0x20]
000078f8213cee18  vmovaps xmm3, [rsp+0x30]
000078f8213cee1e  vmovaps xmm4, [rsp+0x40]
000078f8213cee24  vmovaps xmm5, [rsp+0x50]
000078f8213cee2a  vmovaps xmm6, [rsp+0x60]
000078f8213cee30  vmovaps xmm7, [rsp+0x70]
000078f8213cee36  vmovaps xmm8, [rsp+0x80]
000078f8213cee3f  vmovaps xmm9, [rsp+0x90]
000078f8213cee48  vmovaps xmm10, [rsp+0xA0]
000078f8213cee51  vmovaps xmm11, [rsp+0xB0]
000078f8213cee5a  vmovaps xmm12, [rsp+0xC0]
000078f8213cee63  vmovaps xmm14, [rsp+0xD0]
000078f8213cee6c  vmovaps xmm15, [rsp+0xE0]
000078f8213cee75  add rsp, 0xF0
000078f8213cee7c  pop r11
000078f8213cee7e  pop r10
000078f8213cee80  pop r9
000078f8213cee82  pop r8
000078f8213cee84  pop rsi
000078f8213cee85  pop rdi
000078f8213cee86  pop rdx
000078f8213cee87  pop rcx
000078f8213cee88  pop rax
000078f8213cee89  add rsp, 0x08
000078f8213cee8d  jmp 0x000078F8213CEC71
000078f8213cee92  call 0x000078F8212C2240
000078f8213cee97  jmp 0x000078F8213CEC8B
000078f8213cee9c  sub rsp, 0x08
000078f8213ceea0  push rax
000078f8213ceea1  push rcx
000078f8213ceea2  push rdx
000078f8213ceea3  push rdi
000078f8213ceea4  push rsi
000078f8213ceea5  push r8
000078f8213ceea7  push r9
000078f8213ceea9  push r10
000078f8213ceeab  push r11
000078f8213ceead  sub rsp, 0xF0
000078f8213ceeb4  vmovaps [rsp], xmm0
000078f8213ceeb9  vmovaps [rsp+0x10], xmm1
000078f8213ceebf  vmovaps [rsp+0x20], xmm2
000078f8213ceec5  vmovaps [rsp+0x30], xmm3
000078f8213ceecb  vmovaps [rsp+0x40], xmm4
000078f8213ceed1  vmovaps [rsp+0x50], xmm5
000078f8213ceed7  vmovaps [rsp+0x60], xmm6
000078f8213ceedd  vmovaps [rsp+0x70], xmm7
000078f8213ceee3  vmovaps [rsp+0x80], xmm8
000078f8213ceeec  vmovaps [rsp+0x90], xmm9
000078f8213ceef5  vmovaps [rsp+0xA0], xmm10
000078f8213ceefe  vmovaps [rsp+0xB0], xmm11
000078f8213cef07  vmovaps [rsp+0xC0], xmm12
000078f8213cef10  vmovaps [rsp+0xD0], xmm13
000078f8213cef19  vmovaps [rsp+0xE0], xmm15
000078f8213cef22  sub rsp, 0x30
000078f8213cef26  movaps [rsp], xmm14
000078f8213cef2b  movaps [rsp+0x10], xmm1
000078f8213cef30  movaps [rsp+0x20], xmm15
000078f8213cef36  lea rdi, [rsp]
000078f8213cef3a  mov esi, 0x00
000078f8213cef3f  mov rax, 0x653D80F42530
000078f8213cef49  call rax
000078f8213cef4b  movaps xmm14, [rsp]
000078f8213cef50  add rsp, 0x30
000078f8213cef54  vmovaps xmm0, [rsp]
000078f8213cef59  vmovaps xmm1, [rsp+0x10]
000078f8213cef5f  vmovaps xmm2, [rsp+0x20]
000078f8213cef65  vmovaps xmm3, [rsp+0x30]
000078f8213cef6b  vmovaps xmm4, [rsp+0x40]
000078f8213cef71  vmovaps xmm5, [rsp+0x50]
000078f8213cef77  vmovaps xmm6, [rsp+0x60]
000078f8213cef7d  vmovaps xmm7, [rsp+0x70]
000078f8213cef83  vmovaps xmm8, [rsp+0x80]
000078f8213cef8c  vmovaps xmm9, [rsp+0x90]
000078f8213cef95  vmovaps xmm10, [rsp+0xA0]
000078f8213cef9e  vmovaps xmm11, [rsp+0xB0]
000078f8213cefa7  vmovaps xmm12, [rsp+0xC0]
000078f8213cefb0  vmovaps xmm13, [rsp+0xD0]
000078f8213cefb9  vmovaps xmm15, [rsp+0xE0]
000078f8213cefc2  add rsp, 0xF0
000078f8213cefc9  pop r11
000078f8213cefcb  pop r10
000078f8213cefcd  pop r9
000078f8213cefcf  pop r8
000078f8213cefd1  pop rsi
000078f8213cefd2  pop rdi
000078f8213cefd3  pop rdx
000078f8213cefd4  pop rcx
000078f8213cefd5  pop rax
000078f8213cefd6  add rsp, 0x08
000078f8213cefda  jmp 0x000078F8213CECAE
000078f8213cefdf  call 0x000078F8212C34C0
000078f8213cefe4  jmp 0x000078F8213CECC4
000078f8213cefe9  int3
000078f8213cefea  nop [rax+rax*1], ax
000078f8213ceff0  mov rax, [r15+0xF8]
000078f8213ceff7  lea r14, [rax-0x150]
000078f8213ceffe  mov [r15+0xF8], r14
000078f8213cf005  mov rax, [r15+0x50]
000078f8213cf009  lea r12, [rax+0x80]
000078f8213cf010  movups xmm1, [r13+r12*1]
000078f8213cf016  lea r12, [rax+0x90]
000078f8213cf01d  movups xmm15, [r13+r12*1]
000078f8213cf023  mov qword ptr [r15+0x48], 0x00
000078f8213cf02b  lea r12, [rax+0x40]
000078f8213cf02f  movups xmm14, [r13+r12*1]
000078f8213cf035  lea r12, [rax+0x50]
000078f8213cf039  movups xmm13, [r13+r12*1]
000078f8213cf03f  lea r12, [r14+0x120]
000078f8213cf046  movq xmm12, qword ptr [r15+0x1C0]
000078f8213cf04f  movq xmm11, qword ptr [r15+0x1B0]
000078f8213cf058  movq r11, xmm12
000078f8213cf05d  movq r10, xmm11
000078f8213cf062  mov [r13+r12*1], r11
000078f8213cf067  lea r12, [r14+0x128]
000078f8213cf06e  mov [r13+r12*1], r10
000078f8213cf073  vxorps xmm12, xmm12, xmm12
000078f8213cf078  vpbroadcastq xmm12, xmm12
000078f8213cf07d  lea r12, [r14+0x100]
000078f8213cf084  movq xmm11, qword ptr [r15+0x200]
000078f8213cf08d  movq xmm10, qword ptr [r15+0x1F0]
000078f8213cf096  movq r11, xmm11
000078f8213cf09b  movq r10, xmm10
000078f8213cf0a0  mov [r13+r12*1], r11
000078f8213cf0a5  lea r12, [r14+0x108]
000078f8213cf0ac  mov [r13+r12*1], r10
000078f8213cf0b1  lea r12, [r14+0xE0]
000078f8213cf0b8  movups [r13+r12*1], xmm15
000078f8213cf0be  lea r12, [r14+0xF0]
000078f8213cf0c5  movups [r13+r12*1], xmm1
000078f8213cf0cb  lea r12, [rax+0xC0]
000078f8213cf0d2  movups xmm1, [r13+r12*1]
000078f8213cf0d8  lea r12, [rax+0xD0]
000078f8213cf0df  movups xmm15, [r13+r12*1]
000078f8213cf0e5  lea r12, [r14+0x110]
000078f8213cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000078f8213cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000078f8213cf0fe  movq r11, xmm11
000078f8213cf103  movq r10, xmm10
000078f8213cf108  mov [r13+r12*1], r11
000078f8213cf10d  lea r12, [r14+0x118]
000078f8213cf114  mov [r13+r12*1], r10
000078f8213cf119  movups xmm11, [r13+rax*1]
000078f8213cf11f  lea r12, [rax+0x10]
000078f8213cf123  movups xmm10, [r13+r12*1]
000078f8213cf129  lea r12, [r14+0x130]
000078f8213cf130  movq xmm9, qword ptr [r15+0x1A0]
000078f8213cf139  movq xmm8, qword ptr [r15+0x190]
000078f8213cf142  movq r11, xmm9
000078f8213cf147  movq r10, xmm8
000078f8213cf14c  mov [r13+r12*1], r11
000078f8213cf151  lea r12, [r14+0x138]
000078f8213cf158  mov [r13+r12*1], r10
000078f8213cf15d  lea r12, [rax+0x140]
000078f8213cf164  movups xmm9, [r13+r12*1]
000078f8213cf16a  lea r12, [rax+0x150]
000078f8213cf171  movups xmm8, [r13+r12*1]
000078f8213cf177  lea r12, [r14+0xC0]
000078f8213cf17e  movups [r13+r12*1], xmm15
000078f8213cf184  lea r12, [r14+0xD0]
000078f8213cf18b  movups [r13+r12*1], xmm1
000078f8213cf191  lea r12, [rax+0x100]
000078f8213cf198  movups xmm1, [r13+r12*1]
000078f8213cf19e  lea r12, [rax+0x110]
000078f8213cf1a5  movups xmm15, [r13+r12*1]
000078f8213cf1ab  lea r12, [r14+0x140]
000078f8213cf1b2  mov r11, [r15+0xE8]
000078f8213cf1b9  mov [r13+r12*1], r11
000078f8213cf1be  lea r12, [rax+0x180]
000078f8213cf1c5  movups xmm7, [r13+r12*1]
000078f8213cf1cb  lea r12, [rax+0x190]
000078f8213cf1d2  movups xmm6, [r13+r12*1]
000078f8213cf1d8  lea r12, [rax+0x1C0]
000078f8213cf1df  movups xmm5, [r13+r12*1]
000078f8213cf1e5  lea r12, [rax+0x1D0]
000078f8213cf1ec  movups xmm4, [r13+r12*1]
000078f8213cf1f2  lea r12, [r14+0x20]
000078f8213cf1f6  movups [r13+r12*1], xmm1
000078f8213cf1fc  lea r12, [r14+0x30]
000078f8213cf200  movups [r13+r12*1], xmm13
000078f8213cf206  lea r12, [rax+0x60]
000078f8213cf20a  movups xmm1, [r13+r12*1]
000078f8213cf210  lea r12, [rax+0x70]
000078f8213cf214  movups xmm13, [r13+r12*1]
000078f8213cf21a  lea r12, [rax+0x20]
000078f8213cf21e  movups xmm3, [r13+r12*1]
000078f8213cf224  lea r12, [rax+0x30]
000078f8213cf228  movups xmm2, [r13+r12*1]
000078f8213cf22e  movaps [r15+0x1F0], xmm2
000078f8213cf236  lea r12, [r14+0x60]
000078f8213cf23a  movups [r13+r12*1], xmm11
000078f8213cf240  lea r12, [r14+0x70]
000078f8213cf244  movups [r13+r12*1], xmm5
000078f8213cf24a  lea r12, [rax+0xE0]
000078f8213cf251  movups xmm11, [r13+r12*1]
000078f8213cf257  lea r12, [rax+0xF0]
000078f8213cf25e  movups xmm5, [r13+r12*1]
000078f8213cf264  lea r12, [r14+0xA0]
000078f8213cf26b  movups [r13+r12*1], xmm13
000078f8213cf271  lea r12, [r14+0xB0]
000078f8213cf278  movups [r13+r12*1], xmm1
000078f8213cf27e  lea r12, [rax+0xA0]
000078f8213cf285  movups xmm1, [r13+r12*1]
000078f8213cf28b  lea r12, [rax+0xB0]
000078f8213cf292  movups xmm13, [r13+r12*1]
000078f8213cf298  lea r12, [rax+0x120]
000078f8213cf29f  vmovaps [rsp+0x10], xmm1
000078f8213cf2a5  movups xmm1, [r13+r12*1]
000078f8213cf2ab  lea r12, [rax+0x130]
000078f8213cf2b2  vmovaps [rsp+0x20], xmm1
000078f8213cf2b8  movups xmm1, [r13+r12*1]
000078f8213cf2be  lea r12, [rax+0x160]
000078f8213cf2c5  vmovaps [rsp+0x30], xmm1
000078f8213cf2cb  movups xmm1, [r13+r12*1]
000078f8213cf2d1  lea r12, [rax+0x170]
000078f8213cf2d8  vmovaps [rsp+0x40], xmm1
000078f8213cf2de  movups xmm1, [r13+r12*1]
000078f8213cf2e4  movaps [r15+0x2B0], xmm1
000078f8213cf2ec  lea r12, [r14+0x80]
000078f8213cf2f3  movups [r13+r12*1], xmm13
000078f8213cf2f9  lea r12, [r14+0x90]
000078f8213cf300  vmovaps xmm13, [rsp+0x10]
000078f8213cf306  movups [r13+r12*1], xmm13
000078f8213cf30c  lea r12, [rax+0x1A0]
000078f8213cf313  movups xmm13, [r13+r12*1]
000078f8213cf319  lea r12, [rax+0x1B0]
000078f8213cf320  vmovaps [rsp+0x10], xmm1
000078f8213cf326  movups xmm1, [r13+r12*1]
000078f8213cf32c  movaps [r15+0x290], xmm13
000078f8213cf334  movaps [r15+0x1E0], xmm1
000078f8213cf33c  lea r12, [rax+0x1E0]
000078f8213cf343  vmovaps [rsp+0x50], xmm1
000078f8213cf349  movups xmm1, [r13+r12*1]
000078f8213cf34f  lea r12, [rax+0x1F0]
000078f8213cf356  vmovaps [rsp+0x60], xmm1
000078f8213cf35c  movups xmm1, [r13+r12*1]
000078f8213cf362  mov qword ptr [r15+0x50], 0x430920
000078f8213cf36a  lea rax, [r14+0x40]
000078f8213cf36e  vmovaps [rsp+0x70], xmm1
000078f8213cf374  vmovaps xmm1, [rsp+0x40]
000078f8213cf37a  movups [r13+rax*1], xmm1
000078f8213cf380  lea rax, [r14+0x50]
000078f8213cf384  movups [r13+rax*1], xmm10
000078f8213cf38a  vmovaps xmm1, [rsp+0x70]
000078f8213cf390  movups [r13+r14*1], xmm1
000078f8213cf396  lea rax, [r14+0x10]
000078f8213cf39a  vmovaps xmm1, [rsp+0x60]
000078f8213cf3a0  movups [r13+rax*1], xmm1
000078f8213cf3a6  mov rax, [r15+0x40]
000078f8213cf3aa  vmovaps [rsp+0x40], xmm3
000078f8213cf3b0  vmovaps xmm1, [rsp+0x40]
000078f8213cf3b6  por xmm3, xmm1
000078f8213cf3ba  vmovaps [rsp+0x40], xmm6
000078f8213cf3c0  vmovaps xmm10, [rsp+0x40]
000078f8213cf3c6  por xmm6, xmm10
000078f8213cf3cb  lea r12, [rax+0x30]
000078f8213cf3cf  mov r11, [r13+r12*1]
000078f8213cf3d4  lea r12, [rax+0x38]
000078f8213cf3d8  mov r10, [r13+r12*1]
000078f8213cf3dd  movq xmm10, r11
000078f8213cf3e2  vmovaps [rsp+0x40], xmm1
000078f8213cf3e8  movq xmm1, r10
000078f8213cf3ed  movq xmm10, xmm10
000078f8213cf3f2  vmovaps [rsp+0x60], xmm10
000078f8213cf3f8  movq xmm10, xmm10
000078f8213cf3fd  movaps [r15+0x130], xmm10
000078f8213cf405  movq xmm1, xmm1
000078f8213cf409  vmovaps [rsp+0x70], xmm1
000078f8213cf40f  movq xmm1, xmm1
000078f8213cf413  movaps [r15+0x280], xmm1
000078f8213cf41b  vmovaps [rsp+0x80], xmm9
000078f8213cf424  vmovaps xmm1, [rsp+0x80]
000078f8213cf42d  por xmm9, xmm1
000078f8213cf432  lea r12, [rax+0x20]
000078f8213cf436  mov r11, [r13+r12*1]
000078f8213cf43b  lea r12, [rax+0x28]
000078f8213cf43f  mov r10, [r13+r12*1]
000078f8213cf444  movq xmm1, r11
000078f8213cf449  movq xmm10, r10
000078f8213cf44e  movq xmm1, xmm1
000078f8213cf452  vmovaps [rsp+0x80], xmm1
000078f8213cf45b  movq xmm1, xmm1
000078f8213cf45f  movaps [r15+0x150], xmm1
000078f8213cf467  movq xmm10, xmm10
000078f8213cf46c  vmovaps [rsp+0x90], xmm10
000078f8213cf475  movq xmm10, xmm10
000078f8213cf47a  movaps [r15+0x140], xmm10
000078f8213cf482  lea r12, [rax+0x10]
000078f8213cf486  mov r11, [r13+r12*1]
000078f8213cf48b  lea r12, [rax+0x18]
000078f8213cf48f  mov r10, [r13+r12*1]
000078f8213cf494  movq xmm1, r11
000078f8213cf499  movq xmm10, r10
000078f8213cf49e  movq xmm1, xmm1
000078f8213cf4a2  vmovaps [rsp+0xA0], xmm1
000078f8213cf4ab  movq xmm1, xmm1
000078f8213cf4af  movaps [r15+0x170], xmm1
000078f8213cf4b7  movq xmm10, xmm10
000078f8213cf4bc  vmovaps [rsp+0xB0], xmm10
000078f8213cf4c5  movq xmm10, xmm10
000078f8213cf4ca  movaps [r15+0x160], xmm10
000078f8213cf4d2  mov r12, [r13+rax*1]
000078f8213cf4d7  vmovq xmm1, r12
000078f8213cf4dc  vpbroadcastq xmm1, xmm1
000078f8213cf4e1  lea r12, [rax+0x08]
000078f8213cf4e5  mov rax, [r13+r12*1]
000078f8213cf4ea  movq xmm10, rax
000078f8213cf4ef  movaps [r15+0x230], xmm10
000078f8213cf4f7  lea rax, [r14+0x50]
000078f8213cf4fb  movups xmm10, [r13+rax*1]
000078f8213cf501  lea rax, [r14+0x60]
000078f8213cf505  vmovaps [rsp+0xC0], xmm1
000078f8213cf50e  movups xmm1, [r13+rax*1]
000078f8213cf514  lea rax, [r14+0x30]
000078f8213cf518  vmovaps [rsp+0xD0], xmm1
000078f8213cf521  movups xmm1, [r13+rax*1]
000078f8213cf527  mov qword ptr [r15+0x60], 0x430920
000078f8213cf52f  mov qword ptr [r15+0x58], 0x40
000078f8213cf537  vmovaps [rsp+0xE0], xmm1
000078f8213cf540  vmovaps [rsp+0xF0], xmm15
000078f8213cf549  vmovaps xmm15, [rsp+0xC0]
000078f8213cf552  vmovaps [rsp+0xC0], xmm14
000078f8213cf55b  vmovaps xmm14, [rsp+0x40]
000078f8213cf561  vmovaps [rsp+0x40], xmm13
000078f8213cf567  movaps xmm1, xmm15
000078f8213cf56b  mulpd xmm1, xmm14
000078f8213cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000078f8213cf575  ptest xmm13, xmm13
000078f8213cf57b  jnz 0x000078F8213D0682
000078f8213cf581  movq xmm14, qword ptr [r15+0x230]
000078f8213cf58a  vmovaps [rsp+0x100], xmm14
000078f8213cf593  vpermilpd xmm14, xmm14, 0x00
000078f8213cf599  vmovaps [rsp+0x110], xmm1
000078f8213cf5a2  vmovaps xmm1, [rsp+0xE0]
000078f8213cf5ab  vmovaps [rsp+0xE0], xmm15
000078f8213cf5b4  movaps xmm13, xmm1
000078f8213cf5b8  mulpd xmm13, xmm14
000078f8213cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000078f8213cf5c3  ptest xmm15, xmm15
000078f8213cf5c9  jnz 0x000078F8213D07C4
000078f8213cf5cf  vxorps xmm1, xmm1, xmm1
000078f8213cf5d3  vpbroadcastq xmm1, xmm1
000078f8213cf5d8  vmovaps xmm14, [rsp+0xE0]
000078f8213cf5e1  vmovaps [rsp+0xE0], xmm1
000078f8213cf5ea  vmovaps xmm1, [rsp+0xD0]
000078f8213cf5f3  vmovaps [rsp+0xD0], xmm13
000078f8213cf5fc  movaps xmm15, xmm14
000078f8213cf600  mulpd xmm15, xmm1
000078f8213cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000078f8213cf60b  ptest xmm13, xmm13
000078f8213cf611  jnz 0x000078F8213D0907
000078f8213cf617  movaps xmm1, xmm14
000078f8213cf61b  mulpd xmm1, xmm10
000078f8213cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000078f8213cf625  ptest xmm13, xmm13
000078f8213cf62b  jnz 0x000078F8213D0A4A
000078f8213cf631  movaps xmm13, xmm14
000078f8213cf635  mulpd xmm13, xmm2
000078f8213cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000078f8213cf640  ptest xmm10, xmm10
000078f8213cf646  jnz 0x000078F8213D0B8C
000078f8213cf64c  vmovaps [rsp+0x120], xmm7
000078f8213cf655  vmovaps xmm14, [rsp+0x120]
000078f8213cf65e  por xmm7, xmm14
000078f8213cf663  vmovaps xmm14, [rsp+0xC0]
000078f8213cf66c  vmovaps xmm10, [rsp+0xC0]
000078f8213cf675  por xmm14, xmm10
000078f8213cf67a  vmovaps xmm2, [rsp+0x100]
000078f8213cf683  vpermilpd xmm2, xmm2, 0x00
000078f8213cf689  vmovaps [rsp+0xC0], xmm1
000078f8213cf692  vmovaps [rsp+0x120], xmm15
000078f8213cf69b  movaps xmm1, xmm10
000078f8213cf69f  mulpd xmm1, xmm2
000078f8213cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000078f8213cf6a8  ptest xmm15, xmm15
000078f8213cf6ae  jnz 0x000078F8213D0CCF
000078f8213cf6b4  xor eax, eax
000078f8213cf6b6  mov r12d, 0x40
000078f8213cf6bc  mov r11d, 0x200
000078f8213cf6c2  cmp r12, r11
000078f8213cf6c5  cmc
000078f8213cf6c6  lahf
000078f8213cf6c7  seto al
000078f8213cf6ca  mov [r15+0x108], eax
000078f8213cf6d1  vmovaps xmm10, [rsp+0x110]
000078f8213cf6da  vmovaps xmm2, [rsp+0xE0]
000078f8213cf6e3  vmovaps [rsp+0xE0], xmm1
000078f8213cf6ec  movaps xmm15, xmm10
000078f8213cf6f0  addpd xmm15, xmm2
000078f8213cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000078f8213cf6fb  ptest xmm1, xmm1
000078f8213cf700  jnz 0x000078F8213D0E10
000078f8213cf706  vmovaps xmm10, [rsp+0x120]
000078f8213cf70f  vmovaps [rsp+0x110], xmm15
000078f8213cf718  movaps xmm1, xmm10
000078f8213cf71c  addpd xmm1, xmm12
000078f8213cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000078f8213cf726  ptest xmm15, xmm15
000078f8213cf72c  jnz 0x000078F8213D0F53
000078f8213cf732  vmovaps xmm10, [rsp+0xC0]
000078f8213cf73b  vmovaps [rsp+0xC0], xmm1
000078f8213cf744  movaps xmm15, xmm10
000078f8213cf748  addpd xmm15, xmm12
000078f8213cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000078f8213cf753  ptest xmm1, xmm1
000078f8213cf758  jnz 0x000078F8213D1095
000078f8213cf75e  vmovaps xmm1, [rsp+0x30]
000078f8213cf764  vmovaps xmm12, [rsp+0x30]
000078f8213cf76a  por xmm1, xmm12
000078f8213cf76f  vmovaps xmm12, [rsp+0x20]
000078f8213cf775  vmovaps xmm10, [rsp+0x20]
000078f8213cf77b  por xmm12, xmm10
000078f8213cf780  vmovaps [rsp+0x20], xmm5
000078f8213cf786  vmovaps xmm10, [rsp+0x20]
000078f8213cf78c  por xmm5, xmm10
000078f8213cf791  vmovaps [rsp+0x20], xmm11
000078f8213cf797  vmovaps xmm10, [rsp+0x20]
000078f8213cf79d  por xmm11, xmm10
000078f8213cf7a2  vmovaps [rsp+0x20], xmm4
000078f8213cf7a8  vmovaps xmm10, [rsp+0x20]
000078f8213cf7ae  por xmm4, xmm10
000078f8213cf7b3  vmovaps [rsp+0x20], xmm8
000078f8213cf7b9  vmovaps xmm10, [rsp+0x20]
000078f8213cf7bf  por xmm8, xmm10
000078f8213cf7c4  vmovaps xmm10, [rsp+0xF0]
000078f8213cf7cd  vmovaps [rsp+0x20], xmm1
000078f8213cf7d3  vmovaps xmm1, [rsp+0xF0]
000078f8213cf7dc  por xmm10, xmm1
000078f8213cf7e1  lea rax, [r14+0xA0]
000078f8213cf7e8  movups xmm1, [r13+rax*1]
000078f8213cf7ee  lea rax, [r14+0xB0]
000078f8213cf7f5  vmovaps [rsp+0x30], xmm1
000078f8213cf7fb  movups xmm1, [r13+rax*1]
000078f8213cf801  vmovaps [rsp+0xF0], xmm1
000078f8213cf80a  vmovaps [rsp+0x120], xmm15
000078f8213cf813  movaps xmm1, xmm13
000078f8213cf817  addpd xmm1, xmm2
000078f8213cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000078f8213cf820  ptest xmm15, xmm15
000078f8213cf826  jnz 0x000078F8213D11ED
000078f8213cf82c  lea rax, [r14+0xF0]
000078f8213cf833  movups xmm15, [r13+rax*1]
000078f8213cf839  vmovaps xmm2, [rsp+0xC0]
000078f8213cf842  vmovaps [rsp+0xC0], xmm1
000078f8213cf84b  vmovaps xmm1, [rsp+0xE0]
000078f8213cf854  vmovaps [rsp+0xE0], xmm15
000078f8213cf85d  movaps xmm13, xmm2
000078f8213cf861  addpd xmm13, xmm1
000078f8213cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000078f8213cf86c  ptest xmm15, xmm15
000078f8213cf872  jnz 0x000078F8213D1338
000078f8213cf878  vmovaps xmm15, [rsp+0x120]
000078f8213cf881  vmovaps xmm2, [rsp+0xD0]
000078f8213cf88a  vmovaps [rsp+0xD0], xmm14
000078f8213cf893  movaps xmm1, xmm15
000078f8213cf897  addpd xmm1, xmm2
000078f8213cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000078f8213cf8a0  ptest xmm14, xmm14
000078f8213cf8a6  jnz 0x000078F8213D147A
000078f8213cf8ac  vmovaps xmm15, [rsp+0x100]
000078f8213cf8b5  vpermilpd xmm15, xmm15, 0x00
000078f8213cf8bb  vmovaps xmm2, [rsp+0xF0]
000078f8213cf8c4  vmovaps [rsp+0xF0], xmm1
000078f8213cf8cd  movaps xmm14, xmm2
000078f8213cf8d1  mulpd xmm14, xmm15
000078f8213cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000078f8213cf8dc  ptest xmm1, xmm1
000078f8213cf8e1  jnz 0x000078F8213D15BB
000078f8213cf8e7  vmovaps xmm1, [rsp+0xA0]
000078f8213cf8f0  vpermilpd xmm1, xmm1, 0x00
000078f8213cf8f6  vmovaps xmm2, [rsp+0xE0]
000078f8213cf8ff  vmovaps [rsp+0xE0], xmm14
000078f8213cf908  movaps xmm15, xmm2
000078f8213cf90c  mulpd xmm15, xmm1
000078f8213cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000078f8213cf917  ptest xmm14, xmm14
000078f8213cf91d  jnz 0x000078F8213D16FE
000078f8213cf923  lea rax, [r14+0xE0]
000078f8213cf92a  movups xmm1, [r13+rax*1]
000078f8213cf930  vmovaps xmm14, [rsp+0x100]
000078f8213cf939  vpermilpd xmm14, xmm14, 0x00
000078f8213cf93f  vmovaps [rsp+0x100], xmm1
000078f8213cf948  vmovaps xmm1, [rsp+0x30]
000078f8213cf94e  vmovaps [rsp+0x30], xmm15
000078f8213cf954  movaps xmm2, xmm1
000078f8213cf957  mulpd xmm2, xmm14
000078f8213cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000078f8213cf961  ptest xmm15, xmm15
000078f8213cf967  jnz 0x000078F8213D184A
000078f8213cf96d  vmovaps [rsp+0x120], xmm10
000078f8213cf976  vmovaps xmm1, [rsp+0x120]
000078f8213cf97f  por xmm10, xmm1
000078f8213cf984  movaps [r15+0x300], xmm10
000078f8213cf98c  vmovaps [rsp+0x120], xmm8
000078f8213cf995  vmovaps xmm1, [rsp+0x120]
000078f8213cf99e  por xmm8, xmm1
000078f8213cf9a3  movaps [r15+0x190], xmm8
000078f8213cf9ab  vmovaps xmm1, [rsp+0xA0]
000078f8213cf9b4  vpermilpd xmm1, xmm1, 0x00
000078f8213cf9ba  vmovaps xmm14, [rsp+0x100]
000078f8213cf9c3  vmovaps [rsp+0x100], xmm13
000078f8213cf9cc  movaps xmm15, xmm14
000078f8213cf9d0  mulpd xmm15, xmm1
000078f8213cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000078f8213cf9db  ptest xmm13, xmm13
000078f8213cf9e1  jnz 0x000078F8213D198B
000078f8213cf9e7  lea rax, [r14+0x90]
000078f8213cf9ee  movups xmm1, [r13+rax*1]
000078f8213cf9f4  vmovaps [rsp+0x120], xmm4
000078f8213cf9fd  vmovaps xmm14, [rsp+0x120]
000078f8213cfa06  por xmm4, xmm14
000078f8213cfa0b  movaps [r15+0x1C0], xmm4
000078f8213cfa13  vmovaps [rsp+0x120], xmm11
000078f8213cfa1c  vmovaps xmm14, [rsp+0x120]
000078f8213cfa25  por xmm11, xmm14
000078f8213cfa2a  movaps [r15+0x200], xmm11
000078f8213cfa32  vmovaps [rsp+0x120], xmm5
000078f8213cfa3b  vmovaps xmm14, [rsp+0x120]
000078f8213cfa44  por xmm5, xmm14
000078f8213cfa49  movaps [r15+0x2D0], xmm5
000078f8213cfa51  vmovaps [rsp+0x120], xmm12
000078f8213cfa5a  vmovaps xmm14, [rsp+0x120]
000078f8213cfa63  por xmm12, xmm14
000078f8213cfa68  movaps [r15+0x2E0], xmm12
000078f8213cfa70  vmovaps xmm13, [rsp+0x110]
000078f8213cfa79  vmovaps [rsp+0x110], xmm1
000078f8213cfa82  vmovaps xmm1, [rsp+0xE0]
000078f8213cfa8b  vmovaps [rsp+0xE0], xmm15
000078f8213cfa94  movaps xmm14, xmm13
000078f8213cfa98  addpd xmm14, xmm1
000078f8213cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000078f8213cfaa3  ptest xmm15, xmm15
000078f8213cfaa9  jnz 0x000078F8213D1AD8
000078f8213cfaaf  vmovaps xmm1, [rsp+0xA0]
000078f8213cfab8  vpermilpd xmm1, xmm1, 0x00
000078f8213cfabe  vmovaps xmm13, [rsp+0x110]
000078f8213cfac7  vmovaps [rsp+0x110], xmm14
000078f8213cfad0  movaps xmm15, xmm13
000078f8213cfad4  mulpd xmm15, xmm1
000078f8213cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000078f8213cfadf  ptest xmm14, xmm14
000078f8213cfae5  jnz 0x000078F8213D1C1B
000078f8213cfaeb  lea rax, [r14+0x80]
000078f8213cfaf2  movups xmm1, [r13+rax*1]
000078f8213cfaf8  vmovaps xmm13, [rsp+0xC0]
000078f8213cfb01  vmovaps [rsp+0xC0], xmm1
000078f8213cfb0a  movaps xmm14, xmm13
000078f8213cfb0e  addpd xmm14, xmm2
000078f8213cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000078f8213cfb19  ptest xmm1, xmm1
000078f8213cfb1e  jnz 0x000078F8213D1D68
000078f8213cfb24  vmovaps xmm13, [rsp+0x100]
000078f8213cfb2d  vmovaps xmm2, [rsp+0x30]
000078f8213cfb33  vmovaps [rsp+0x30], xmm15
000078f8213cfb39  movaps xmm1, xmm13
000078f8213cfb3d  addpd xmm1, xmm2
000078f8213cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000078f8213cfb46  ptest xmm15, xmm15
000078f8213cfb4c  jnz 0x000078F8213D1EAB
000078f8213cfb52  vmovaps xmm15, [rsp+0x20]
000078f8213cfb58  vmovaps xmm13, [rsp+0x20]
000078f8213cfb5e  por xmm15, xmm13
000078f8213cfb63  movaps [r15+0x2F0], xmm15
000078f8213cfb6b  vmovaps xmm13, [rsp+0xA0]
000078f8213cfb74  vpermilpd xmm13, xmm13, 0x00
000078f8213cfb7a  vmovaps [rsp+0x20], xmm1
000078f8213cfb80  vmovaps xmm1, [rsp+0xC0]
000078f8213cfb89  vmovaps [rsp+0xA0], xmm15
000078f8213cfb92  movaps xmm2, xmm1
000078f8213cfb95  mulpd xmm2, xmm13
000078f8213cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000078f8213cfb9f  ptest xmm15, xmm15
000078f8213cfba5  jnz 0x000078F8213D1FEC
000078f8213cfbab  lea rax, [r14+0xD0]
000078f8213cfbb2  movups xmm1, [r13+rax*1]
000078f8213cfbb8  vmovaps xmm13, [rsp+0xF0]
000078f8213cfbc1  vmovaps [rsp+0xC0], xmm1
000078f8213cfbca  vmovaps xmm1, [rsp+0xE0]
000078f8213cfbd3  vmovaps [rsp+0xE0], xmm14
000078f8213cfbdc  movaps xmm15, xmm13
000078f8213cfbe0  addpd xmm15, xmm1
000078f8213cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000078f8213cfbeb  ptest xmm14, xmm14
000078f8213cfbf1  jnz 0x000078F8213D2137
000078f8213cfbf7  vmovaps xmm1, [rsp+0xB0]
000078f8213cfc00  vpermilpd xmm1, xmm1, 0x00
000078f8213cfc06  movaps xmm14, xmm11
000078f8213cfc0a  mulpd xmm14, xmm1
000078f8213cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000078f8213cfc15  ptest xmm13, xmm13
000078f8213cfc1b  jnz 0x000078F8213D227A
000078f8213cfc21  movaps [r15+0x260], xmm14
000078f8213cfc29  vxorps xmm1, xmm1, xmm1
000078f8213cfc2d  vpbroadcastq xmm1, xmm1
000078f8213cfc32  movaps [r15+0x1B0], xmm1
000078f8213cfc3a  vmovaps xmm1, [rsp+0xB0]
000078f8213cfc43  vpermilpd xmm1, xmm1, 0x00
000078f8213cfc49  vmovaps xmm11, [rsp+0xC0]
000078f8213cfc52  vmovaps [rsp+0xC0], xmm15
000078f8213cfc5b  movaps xmm13, xmm11
000078f8213cfc5f  mulpd xmm13, xmm1
000078f8213cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000078f8213cfc6a  ptest xmm15, xmm15
000078f8213cfc70  jnz 0x000078F8213D23BD
000078f8213cfc76  lea rax, [r14+0xC0]
000078f8213cfc7d  movups xmm1, [r13+rax*1]
000078f8213cfc83  vmovaps xmm11, [rsp+0x110]
000078f8213cfc8c  vmovaps [rsp+0xF0], xmm1
000078f8213cfc95  vmovaps xmm1, [rsp+0x30]
000078f8213cfc9b  vmovaps [rsp+0x30], xmm14
000078f8213cfca1  movaps xmm15, xmm11
000078f8213cfca5  addpd xmm15, xmm1
000078f8213cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000078f8213cfcb0  ptest xmm14, xmm14
000078f8213cfcb6  jnz 0x000078F8213D250A
000078f8213cfcbc  vmovaps [rsp+0x100], xmm9
000078f8213cfcc5  vmovaps xmm1, [rsp+0x100]
000078f8213cfcce  por xmm9, xmm1
000078f8213cfcd3  movaps [r15+0x270], xmm9
000078f8213cfcdb  vmovaps [rsp+0x100], xmm6
000078f8213cfce4  vmovaps xmm1, [rsp+0x100]
000078f8213cfced  por xmm6, xmm1
000078f8213cfcf1  movaps [r15+0x1A0], xmm6
000078f8213cfcf9  vmovaps xmm14, [rsp+0xB0]
000078f8213cfd02  vpermilpd xmm14, xmm14, 0x00
000078f8213cfd08  vmovaps xmm6, [rsp+0xF0]
000078f8213cfd11  vmovaps [rsp+0xF0], xmm1
000078f8213cfd1a  movaps xmm11, xmm6
000078f8213cfd1e  mulpd xmm11, xmm14
000078f8213cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000078f8213cfd29  ptest xmm1, xmm1
000078f8213cfd2e  jnz 0x000078F8213D264D
000078f8213cfd34  lea rax, [r14+0x20]
000078f8213cfd38  movups xmm1, [r13+rax*1]
000078f8213cfd3e  movaps [r15+0x110], xmm1
000078f8213cfd46  vmovaps xmm6, [rsp+0xE0]
000078f8213cfd4f  vmovaps [rsp+0xE0], xmm1
000078f8213cfd58  movaps xmm14, xmm6
000078f8213cfd5c  addpd xmm14, xmm2
000078f8213cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000078f8213cfd67  ptest xmm1, xmm1
000078f8213cfd6c  jnz 0x000078F8213D279A
000078f8213cfd72  vmovaps xmm1, [rsp+0xB0]
000078f8213cfd7b  vpermilpd xmm1, xmm1, 0x00
000078f8213cfd81  movaps xmm6, xmm5
000078f8213cfd84  mulpd xmm6, xmm1
000078f8213cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000078f8213cfd8d  ptest xmm2, xmm2
000078f8213cfd92  jnz 0x000078F8213D28DC
000078f8213cfd98  vmovaps xmm5, [rsp+0x20]
000078f8213cfd9e  movaps xmm1, xmm5
000078f8213cfda1  addpd xmm1, xmm13
000078f8213cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000078f8213cfdab  ptest xmm2, xmm2
000078f8213cfdb0  jnz 0x000078F8213D2A1C
000078f8213cfdb6  vmovaps xmm13, [rsp+0x80]
000078f8213cfdbf  vpermilpd xmm13, xmm13, 0x00
000078f8213cfdc5  vmovaps xmm2, [rsp+0xE0]
000078f8213cfdce  vmovaps [rsp+0x20], xmm1
000078f8213cfdd4  movaps xmm5, xmm2
000078f8213cfdd7  mulpd xmm5, xmm13
000078f8213cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000078f8213cfde1  ptest xmm1, xmm1
000078f8213cfde6  jnz 0x000078F8213D2B5D
000078f8213cfdec  vmovaps xmm1, [rsp+0x80]
000078f8213cfdf5  vpermilpd xmm1, xmm1, 0x00
000078f8213cfdfb  movaps xmm13, xmm10
000078f8213cfdff  mulpd xmm13, xmm1
000078f8213cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000078f8213cfe0a  ptest xmm2, xmm2
000078f8213cfe0f  jnz 0x000078F8213D2C9E
000078f8213cfe15  vmovaps xmm10, [rsp+0x30]
000078f8213cfe1b  movaps xmm1, xmm15
000078f8213cfe1f  addpd xmm1, xmm10
000078f8213cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000078f8213cfe29  ptest xmm2, xmm2
000078f8213cfe2e  jnz 0x000078F8213D2DE1
000078f8213cfe34  vmovaps xmm10, [rsp+0xC0]
000078f8213cfe3d  movaps xmm15, xmm10
000078f8213cfe41  addpd xmm15, xmm11
000078f8213cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000078f8213cfe4c  ptest xmm2, xmm2
000078f8213cfe51  jnz 0x000078F8213D2F23
000078f8213cfe57  vmovaps xmm11, [rsp+0x80]
000078f8213cfe60  vpermilpd xmm11, xmm11, 0x00
000078f8213cfe66  movaps xmm10, xmm12
000078f8213cfe6a  mulpd xmm10, xmm11
000078f8213cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000078f8213cfe75  ptest xmm2, xmm2
000078f8213cfe7a  jnz 0x000078F8213D3067
000078f8213cfe80  vmovaps xmm12, [rsp+0x80]
000078f8213cfe89  vpermilpd xmm12, xmm12, 0x00
000078f8213cfe8f  vmovaps xmm2, [rsp+0xA0]
000078f8213cfe98  vmovaps [rsp+0x30], xmm1
000078f8213cfe9e  movaps xmm11, xmm2
000078f8213cfea2  mulpd xmm11, xmm12
000078f8213cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000078f8213cfead  ptest xmm1, xmm1
000078f8213cfeb2  jnz 0x000078F8213D31AB
000078f8213cfeb8  movaps xmm1, xmm14
000078f8213cfebc  addpd xmm1, xmm6
000078f8213cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000078f8213cfec5  ptest xmm12, xmm12
000078f8213cfecb  jnz 0x000078F8213D32EE
000078f8213cfed1  vmovaps xmm12, [rsp+0x20]
000078f8213cfed7  movaps xmm14, xmm12
000078f8213cfedb  addpd xmm14, xmm5
000078f8213cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000078f8213cfee6  ptest xmm6, xmm6
000078f8213cfeeb  jnz 0x000078F8213D342F
000078f8213cfef1  vmovaps xmm12, [rsp+0x90]
000078f8213cfefa  vpermilpd xmm12, xmm12, 0x00
000078f8213cff00  movaps xmm6, xmm9
000078f8213cff04  mulpd xmm6, xmm12
000078f8213cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000078f8213cff0e  ptest xmm5, xmm5
000078f8213cff13  jnz 0x000078F8213D3572
000078f8213cff19  movaps xmm12, xmm15
000078f8213cff1d  addpd xmm12, xmm13
000078f8213cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000078f8213cff28  ptest xmm9, xmm9
000078f8213cff2e  jnz 0x000078F8213D36B4
000078f8213cff34  vmovaps xmm13, [rsp+0x30]
000078f8213cff3a  movaps xmm15, xmm13
000078f8213cff3e  addpd xmm15, xmm10
000078f8213cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000078f8213cff49  ptest xmm9, xmm9
000078f8213cff4f  jnz 0x000078F8213D37F8
000078f8213cff55  vmovaps xmm13, [rsp+0xD0]
000078f8213cff5e  vmovaps xmm10, [rsp+0xD0]
000078f8213cff67  por xmm13, xmm10
000078f8213cff6c  movaps [r15+0x250], xmm13
000078f8213cff74  vmovaps [rsp+0x20], xmm7
000078f8213cff7a  vmovaps xmm13, [rsp+0x20]
000078f8213cff80  por xmm7, xmm13
000078f8213cff85  movaps [r15+0x2A0], xmm7
000078f8213cff8d  vmovaps [rsp+0x20], xmm3
000078f8213cff93  vmovaps xmm13, [rsp+0x20]
000078f8213cff99  por xmm3, xmm13
000078f8213cff9e  movaps [r15+0x1D0], xmm3
000078f8213cffa6  lea rax, [r14+0x40]
000078f8213cffaa  movups xmm13, [r13+rax*1]
000078f8213cffb0  movaps [r15+0x2C0], xmm13
000078f8213cffb8  vmovaps xmm10, [rsp+0x90]
000078f8213cffc1  vpermilpd xmm10, xmm10, 0x00
000078f8213cffc7  movaps xmm9, xmm8
000078f8213cffcb  mulpd xmm9, xmm10
000078f8213cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000078f8213cffd6  ptest xmm5, xmm5
000078f8213cffdb  jnz 0x000078F8213D3946
000078f8213cffe1  movaps xmm10, xmm1
000078f8213cffe5  addpd xmm10, xmm11
000078f8213cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000078f8213cfff0  ptest xmm8, xmm8
000078f8213cfff6  jnz 0x000078F8213D3A8A
000078f8213cfffc  movaps xmm1, xmm14
000078f8213d0000  addpd xmm1, xmm6
000078f8213d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000078f8213d0009  ptest xmm11, xmm11
000078f8213d000f  jnz 0x000078F8213D3BCD
000078f8213d0015  vmovaps xmm14, [rsp+0x90]
000078f8213d001e  vpermilpd xmm14, xmm14, 0x00
000078f8213d0024  movaps xmm11, xmm13
000078f8213d0028  mulpd xmm11, xmm14
000078f8213d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000078f8213d0033  ptest xmm8, xmm8
000078f8213d0039  jnz 0x000078F8213D3D0E
000078f8213d003f  vmovaps xmm14, [rsp+0x90]
000078f8213d0048  vpermilpd xmm14, xmm14, 0x00
000078f8213d004e  vmovaps xmm8, [rsp+0x10]
000078f8213d0054  movaps xmm13, xmm8
000078f8213d0058  mulpd xmm13, xmm14
000078f8213d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000078f8213d0063  ptest xmm6, xmm6
000078f8213d0068  jnz 0x000078F8213D3E52
000078f8213d006e  vmovaps xmm14, [rsp+0x60]
000078f8213d0074  vpermilpd xmm14, xmm14, 0x00
000078f8213d007a  movaps xmm8, xmm7
000078f8213d007e  mulpd xmm8, xmm14
000078f8213d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000078f8213d0089  ptest xmm6, xmm6
000078f8213d008e  jnz 0x000078F8213D3F96
000078f8213d0094  movaps xmm14, xmm12
000078f8213d0098  addpd xmm14, xmm9
000078f8213d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000078f8213d00a3  ptest xmm7, xmm7
000078f8213d00a8  jnz 0x000078F8213D40D9
000078f8213d00ae  vmovaps xmm12, [rsp+0x60]
000078f8213d00b4  vpermilpd xmm12, xmm12, 0x00
000078f8213d00ba  vmovaps xmm7, [rsp+0xF0]
000078f8213d00c3  movaps xmm9, xmm7
000078f8213d00c7  mulpd xmm9, xmm12
000078f8213d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000078f8213d00d2  ptest xmm6, xmm6
000078f8213d00d7  jnz 0x000078F8213D421D
000078f8213d00dd  movaps xmm12, xmm15
000078f8213d00e1  addpd xmm12, xmm11
000078f8213d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000078f8213d00ec  ptest xmm7, xmm7
000078f8213d00f1  jnz 0x000078F8213D4360
000078f8213d00f7  vmovaps xmm15, [rsp+0x60]
000078f8213d00fd  vpermilpd xmm15, xmm15, 0x00
000078f8213d0103  vmovaps xmm7, [rsp+0x40]
000078f8213d0109  movaps xmm11, xmm7
000078f8213d010d  mulpd xmm11, xmm15
000078f8213d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000078f8213d0118  ptest xmm6, xmm6
000078f8213d011d  jnz 0x000078F8213D44A4
000078f8213d0123  movaps xmm15, xmm10
000078f8213d0127  addpd xmm15, xmm13
000078f8213d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000078f8213d0132  ptest xmm7, xmm7
000078f8213d0137  jnz 0x000078F8213D45E7
000078f8213d013d  vmovaps xmm13, [rsp+0x60]
000078f8213d0143  vpermilpd xmm13, xmm13, 0x00
000078f8213d0149  vmovaps xmm7, [rsp+0x50]
000078f8213d014f  movaps xmm10, xmm7
000078f8213d0153  mulpd xmm10, xmm13
000078f8213d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000078f8213d015e  ptest xmm6, xmm6
000078f8213d0163  jnz 0x000078F8213D472B
000078f8213d0169  movaps xmm13, xmm1
000078f8213d016d  addpd xmm13, xmm8
000078f8213d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000078f8213d0178  ptest xmm7, xmm7
000078f8213d017d  jnz 0x000078F8213D486E
000078f8213d0183  lea rax, [r14+0x70]
000078f8213d0187  movups xmm1, [r13+rax*1]
000078f8213d018d  movaps [r15+0x240], xmm1
000078f8213d0195  movaps xmm8, xmm14
000078f8213d0199  addpd xmm8, xmm9
000078f8213d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000078f8213d01a4  ptest xmm7, xmm7
000078f8213d01a9  jnz 0x000078F8213D49BB
000078f8213d01af  movaps [r15+0x170], xmm8
000078f8213d01b7  vmovaps xmm14, [rsp+0x70]
000078f8213d01bd  vpermilpd xmm14, xmm14, 0x00
000078f8213d01c3  movaps xmm9, xmm1
000078f8213d01c7  mulpd xmm9, xmm14
000078f8213d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000078f8213d01d2  ptest xmm7, xmm7
000078f8213d01d7  jnz 0x000078F8213D4AFF
000078f8213d01dd  vmovaps xmm1, [rsp+0x70]
000078f8213d01e3  vpermilpd xmm1, xmm1, 0x00
000078f8213d01e9  movaps xmm14, xmm4
000078f8213d01ed  mulpd xmm14, xmm1
000078f8213d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000078f8213d01f8  ptest xmm7, xmm7
000078f8213d01fd  jnz 0x000078F8213D4C42
000078f8213d0203  movaps [r15+0x180], xmm14
000078f8213d020b  movaps xmm1, xmm12
000078f8213d020f  addpd xmm1, xmm11
000078f8213d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000078f8213d0219  ptest xmm7, xmm7
000078f8213d021e  jnz 0x000078F8213D4D84
000078f8213d0224  movaps [r15+0x210], xmm1
000078f8213d022c  movups xmm12, [r13+r14*1]
000078f8213d0232  lea rax, [r14+0x10]
000078f8213d0236  movups xmm11, [r13+rax*1]
000078f8213d023c  movaps [r15+0x230], xmm11
000078f8213d0244  movaps xmm7, xmm15
000078f8213d0248  addpd xmm7, xmm10
000078f8213d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000078f8213d0252  ptest xmm6, xmm6
000078f8213d0257  jnz 0x000078F8213D4EDA
000078f8213d025d  movaps [r15+0x130], xmm7
000078f8213d0265  vmovaps xmm15, [rsp+0x70]
000078f8213d026b  vpermilpd xmm15, xmm15, 0x00
000078f8213d0271  movaps xmm10, xmm11
000078f8213d0275  mulpd xmm10, xmm15
000078f8213d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000078f8213d0280  ptest xmm6, xmm6
000078f8213d0285  jnz 0x000078F8213D501C
000078f8213d028b  movaps [r15+0x220], xmm10
000078f8213d0293  vmovaps xmm15, [rsp+0x70]
000078f8213d0299  vpermilpd xmm15, xmm15, 0x00
000078f8213d029f  movaps xmm11, xmm12
000078f8213d02a3  mulpd xmm11, xmm15
000078f8213d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000078f8213d02ae  ptest xmm6, xmm6
000078f8213d02b3  jnz 0x000078F8213D5160
000078f8213d02b9  movaps xmm15, xmm13
000078f8213d02bd  addpd xmm15, xmm9
000078f8213d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000078f8213d02c8  ptest xmm12, xmm12
000078f8213d02ce  jnz 0x000078F8213D52A4
000078f8213d02d4  movaps [r15+0x140], xmm15
000078f8213d02dc  movaps xmm13, xmm8
000078f8213d02e0  addpd xmm13, xmm14
000078f8213d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000078f8213d02eb  ptest xmm12, xmm12
000078f8213d02f1  jnz 0x000078F8213D53E8
000078f8213d02f7  movaps [r15+0x150], xmm13
000078f8213d02ff  movaps xmm14, xmm1
000078f8213d0303  addpd xmm14, xmm10
000078f8213d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000078f8213d030e  ptest xmm12, xmm12
000078f8213d0314  jnz 0x000078F8213D552C
000078f8213d031a  movaps [r15+0x160], xmm14
000078f8213d0322  movaps xmm1, xmm7
000078f8213d0325  addpd xmm1, xmm11
000078f8213d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000078f8213d032f  ptest xmm12, xmm12
000078f8213d0335  jnz 0x000078F8213D566F
000078f8213d033b  movaps [r15+0x120], xmm1
000078f8213d0343  mov eax, 0x430920
000078f8213d0348  movups [r13+rax*1], xmm15
000078f8213d034e  mov eax, 0x430930
000078f8213d0353  movups [r13+rax*1], xmm13
000078f8213d0359  mov eax, 0x430940
000078f8213d035e  movups [r13+rax*1], xmm14
000078f8213d0364  mov eax, 0x430950
000078f8213d0369  movups [r13+rax*1], xmm1
000078f8213d036f  mov eax, [r15+0x108]
000078f8213d0376  sahf
000078f8213d0377  jnz 0x000078F8213D03A9
000078f8213d0379  cmp dword ptr [r15+0x318], 0x00
000078f8213d0381  jz 0x000078F8213DB900
000078f8213d0387  nop [rax+rax*1], ax
000078f8213d0390  nop [rax+rax*1], eax
000078f8213d0398  mov eax, 0x410444
000078f8213d039d  mov [r15+0x100], rax
000078f8213d03a4  jmp 0x000078F8211FE110
000078f8213d03a9  cmp dword ptr [r15+0x318], 0x00
000078f8213d03b1  jz 0x000078F8213D57E0
000078f8213d03b7  nop [rax+rax*1], ax
000078f8213d03c0  nop [rax+rax*1], eax
000078f8213d03c8  mov eax, 0x410278
000078f8213d03cd  mov [r15+0x100], rax
000078f8213d03d4  jmp 0x000078F8211FE110
000078f8213d03d9  int3
000078f8213d03da  call 0x000078F8212B52F0
000078f8213d03df  jmp 0x000078F8213CF016
000078f8213d03e4  call 0x000078F8212C4620
000078f8213d03e9  jmp 0x000078F8213CF023
000078f8213d03ee  call 0x000078F8212C33A0
000078f8213d03f3  jmp 0x000078F8213CF035
000078f8213d03f8  call 0x000078F8212C2120
000078f8213d03fd  jmp 0x000078F8213CF03F
000078f8213d0402  call 0x000078F8212C0860
000078f8213d0407  jmp 0x000078F8213CF067
000078f8213d040c  call 0x000078F8212BF5F0
000078f8213d0411  jmp 0x000078F8213CF073
000078f8213d0416  call 0x000078F8212C0860
000078f8213d041b  jmp 0x000078F8213CF0A5
000078f8213d0420  call 0x000078F8212BF5F0
000078f8213d0425  jmp 0x000078F8213CF0B1
000078f8213d042a  call 0x000078F8212C4740
000078f8213d042f  jmp 0x000078F8213CF0BE
000078f8213d0434  call 0x000078F8212B5400
000078f8213d0439  jmp 0x000078F8213CF0CB
000078f8213d043e  call 0x000078F8212B52F0
000078f8213d0443  jmp 0x000078F8213CF0D8
000078f8213d0448  call 0x000078F8212C4620
000078f8213d044d  jmp 0x000078F8213CF0E5
000078f8213d0452  call 0x000078F8212C0860
000078f8213d0457  jmp 0x000078F8213CF10D
000078f8213d045c  call 0x000078F8212BF5F0
000078f8213d0461  jmp 0x000078F8213CF119
000078f8213d0466  call 0x000078F821209D70
000078f8213d046b  jmp 0x000078F8213CF11F
000078f8213d0470  call 0x000078F8212BE9C0
000078f8213d0475  jmp 0x000078F8213CF129
000078f8213d047a  call 0x000078F8212C0860
000078f8213d047f  jmp 0x000078F8213CF151
000078f8213d0484  call 0x000078F8212BF5F0
000078f8213d0489  jmp 0x000078F8213CF15D
000078f8213d048e  call 0x000078F8212BD750
000078f8213d0493  jmp 0x000078F8213CF16A
000078f8213d0498  call 0x000078F8212BC4E0
000078f8213d049d  jmp 0x000078F8213CF177
000078f8213d04a2  call 0x000078F8212C4740
000078f8213d04a7  jmp 0x000078F8213CF184
000078f8213d04ac  call 0x000078F8212B5400
000078f8213d04b1  jmp 0x000078F8213CF191
000078f8213d04b6  call 0x000078F8212B52F0
000078f8213d04bb  jmp 0x000078F8213CF19E
000078f8213d04c0  call 0x000078F8212C4620
000078f8213d04c5  jmp 0x000078F8213CF1AB
000078f8213d04ca  call 0x000078F8212C0860
000078f8213d04cf  jmp 0x000078F8213CF1BE
000078f8213d04d4  call 0x000078F8212BB270
000078f8213d04d9  jmp 0x000078F8213CF1CB
000078f8213d04de  call 0x000078F8212BA000
000078f8213d04e3  jmp 0x000078F8213CF1D8
000078f8213d04e8  call 0x000078F8212B8D90
000078f8213d04ed  jmp 0x000078F8213CF1E5
000078f8213d04f2  call 0x000078F8212B8A20
000078f8213d04f7  jmp 0x000078F8213CF1F2
000078f8213d04fc  call 0x000078F8212B5400
000078f8213d0501  jmp 0x000078F8213CF1FC
000078f8213d0506  call 0x000078F8212C2240
000078f8213d050b  jmp 0x000078F8213CF206
000078f8213d0510  call 0x000078F8212B52F0
000078f8213d0515  jmp 0x000078F8213CF210
000078f8213d051a  call 0x000078F8212C2120
000078f8213d051f  jmp 0x000078F8213CF21A
000078f8213d0524  call 0x000078F8212B77B0
000078f8213d0529  jmp 0x000078F8213CF224
000078f8213d052e  call 0x000078F8212B6550
000078f8213d0533  jmp 0x000078F8213CF22E
000078f8213d0538  call 0x000078F8212BFD50
000078f8213d053d  jmp 0x000078F8213CF240
000078f8213d0542  call 0x000078F8212B8EA0
000078f8213d0547  jmp 0x000078F8213CF24A
000078f8213d054c  call 0x000078F8212BFC30
000078f8213d0551  jmp 0x000078F8213CF257
000078f8213d0556  call 0x000078F8212B8D90
000078f8213d055b  jmp 0x000078F8213CF264
000078f8213d0560  call 0x000078F8212C2240
000078f8213d0565  jmp 0x000078F8213CF271
000078f8213d056a  call 0x000078F8212B5400
000078f8213d056f  jmp 0x000078F8213CF27E
000078f8213d0574  call 0x000078F8212B52F0
000078f8213d0579  jmp 0x000078F8213CF28B
000078f8213d057e  call 0x000078F8212C2120
000078f8213d0583  jmp 0x000078F8213CF298
000078f8213d0588  call 0x000078F8212B52F0
000078f8213d058d  jmp 0x000078F8213CF2AB
000078f8213d0592  call 0x000078F8212B52F0
000078f8213d0597  jmp 0x000078F8213CF2BE
000078f8213d059c  call 0x000078F8212B52F0
000078f8213d05a1  jmp 0x000078F8213CF2D1
000078f8213d05a6  call 0x000078F8212B52F0
000078f8213d05ab  jmp 0x000078F8213CF2E4
000078f8213d05b0  call 0x000078F8212C2240
000078f8213d05b5  jmp 0x000078F8213CF2F9
000078f8213d05ba  call 0x000078F8212C2240
000078f8213d05bf  jmp 0x000078F8213CF30C
000078f8213d05c4  call 0x000078F8212C2120
000078f8213d05c9  jmp 0x000078F8213CF319
000078f8213d05ce  call 0x000078F8212B52F0
000078f8213d05d3  jmp 0x000078F8213CF32C
000078f8213d05d8  call 0x000078F8212B52F0
000078f8213d05dd  jmp 0x000078F8213CF34F
000078f8213d05e2  call 0x000078F8212B52F0
000078f8213d05e7  jmp 0x000078F8213CF362
000078f8213d05ec  call 0x000078F8211FF540
000078f8213d05f1  jmp 0x000078F8213CF380
000078f8213d05f6  call 0x000078F821208C20
000078f8213d05fb  jmp 0x000078F8213CF38A
000078f8213d0600  call 0x000078F8212D6600
000078f8213d0605  jmp 0x000078F8213CF396
000078f8213d060a  call 0x000078F8211FF540
000078f8213d060f  jmp 0x000078F8213CF3A6
000078f8213d0614  call 0x000078F8212C0370
000078f8213d0619  jmp 0x000078F8213CF3D4
000078f8213d061e  call 0x000078F8212BF100
000078f8213d0623  jmp 0x000078F8213CF3DD
000078f8213d0628  call 0x000078F8212C0370
000078f8213d062d  jmp 0x000078F8213CF43B
000078f8213d0632  call 0x000078F8212BF100
000078f8213d0637  jmp 0x000078F8213CF444
000078f8213d063c  call 0x000078F8212C0370
000078f8213d0641  jmp 0x000078F8213CF48B
000078f8213d0646  call 0x000078F8212BF100
000078f8213d064b  jmp 0x000078F8213CF494
000078f8213d0650  call 0x000078F82120B720
000078f8213d0655  jmp 0x000078F8213CF4D7
000078f8213d065a  call 0x000078F8212B47C0
000078f8213d065f  jmp 0x000078F8213CF4EA
000078f8213d0664  call 0x000078F821208B00
000078f8213d0669  jmp 0x000078F8213CF501
000078f8213d066e  call 0x000078F8211FF430
000078f8213d0673  jmp 0x000078F8213CF514
000078f8213d0678  call 0x000078F8211FF430
000078f8213d067d  jmp 0x000078F8213CF527
000078f8213d0682  sub rsp, 0x08
000078f8213d0686  push rax
000078f8213d0687  push rcx
000078f8213d0688  push rdx
000078f8213d0689  push rdi
000078f8213d068a  push rsi
000078f8213d068b  push r8
000078f8213d068d  push r9
000078f8213d068f  push r10
000078f8213d0691  push r11
000078f8213d0693  sub rsp, 0xF0
000078f8213d069a  vmovaps [rsp], xmm0
000078f8213d069f  vmovaps [rsp+0x10], xmm2
000078f8213d06a5  vmovaps [rsp+0x20], xmm3
000078f8213d06ab  vmovaps [rsp+0x30], xmm4
000078f8213d06b1  vmovaps [rsp+0x40], xmm5
000078f8213d06b7  vmovaps [rsp+0x50], xmm6
000078f8213d06bd  vmovaps [rsp+0x60], xmm7
000078f8213d06c3  vmovaps [rsp+0x70], xmm8
000078f8213d06c9  vmovaps [rsp+0x80], xmm9
000078f8213d06d2  vmovaps [rsp+0x90], xmm10
000078f8213d06db  vmovaps [rsp+0xA0], xmm11
000078f8213d06e4  vmovaps [rsp+0xB0], xmm12
000078f8213d06ed  vmovaps [rsp+0xC0], xmm13
000078f8213d06f6  vmovaps [rsp+0xD0], xmm14
000078f8213d06ff  vmovaps [rsp+0xE0], xmm15
000078f8213d0708  sub rsp, 0x30
000078f8213d070c  movaps [rsp], xmm1
000078f8213d0710  movaps [rsp+0x10], xmm15
000078f8213d0716  movaps [rsp+0x20], xmm14
000078f8213d071c  lea rdi, [rsp]
000078f8213d0720  mov esi, 0x00
000078f8213d0725  mov rax, 0x653D80F42530
000078f8213d072f  call rax
000078f8213d0731  movaps xmm1, [rsp]
000078f8213d0735  add rsp, 0x30
000078f8213d0739  vmovaps xmm0, [rsp]
000078f8213d073e  vmovaps xmm2, [rsp+0x10]
000078f8213d0744  vmovaps xmm3, [rsp+0x20]
000078f8213d074a  vmovaps xmm4, [rsp+0x30]
000078f8213d0750  vmovaps xmm5, [rsp+0x40]
000078f8213d0756  vmovaps xmm6, [rsp+0x50]
000078f8213d075c  vmovaps xmm7, [rsp+0x60]
000078f8213d0762  vmovaps xmm8, [rsp+0x70]
000078f8213d0768  vmovaps xmm9, [rsp+0x80]
000078f8213d0771  vmovaps xmm10, [rsp+0x90]
000078f8213d077a  vmovaps xmm11, [rsp+0xA0]
000078f8213d0783  vmovaps xmm12, [rsp+0xB0]
000078f8213d078c  vmovaps xmm13, [rsp+0xC0]
000078f8213d0795  vmovaps xmm14, [rsp+0xD0]
000078f8213d079e  vmovaps xmm15, [rsp+0xE0]
000078f8213d07a7  add rsp, 0xF0
000078f8213d07ae  pop r11
000078f8213d07b0  pop r10
000078f8213d07b2  pop r9
000078f8213d07b4  pop r8
000078f8213d07b6  pop rsi
000078f8213d07b7  pop rdi
000078f8213d07b8  pop rdx
000078f8213d07b9  pop rcx
000078f8213d07ba  pop rax
000078f8213d07bb  add rsp, 0x08
000078f8213d07bf  jmp 0x000078F8213CF581
000078f8213d07c4  sub rsp, 0x08
000078f8213d07c8  push rax
000078f8213d07c9  push rcx
000078f8213d07ca  push rdx
000078f8213d07cb  push rdi
000078f8213d07cc  push rsi
000078f8213d07cd  push r8
000078f8213d07cf  push r9
000078f8213d07d1  push r10
000078f8213d07d3  push r11
000078f8213d07d5  sub rsp, 0xF0
000078f8213d07dc  vmovaps [rsp], xmm0
000078f8213d07e1  vmovaps [rsp+0x10], xmm1
000078f8213d07e7  vmovaps [rsp+0x20], xmm2
000078f8213d07ed  vmovaps [rsp+0x30], xmm3
000078f8213d07f3  vmovaps [rsp+0x40], xmm4
000078f8213d07f9  vmovaps [rsp+0x50], xmm5
000078f8213d07ff  vmovaps [rsp+0x60], xmm6
000078f8213d0805  vmovaps [rsp+0x70], xmm7
000078f8213d080b  vmovaps [rsp+0x80], xmm8
000078f8213d0814  vmovaps [rsp+0x90], xmm9
000078f8213d081d  vmovaps [rsp+0xA0], xmm10
000078f8213d0826  vmovaps [rsp+0xB0], xmm11
000078f8213d082f  vmovaps [rsp+0xC0], xmm12
000078f8213d0838  vmovaps [rsp+0xD0], xmm14
000078f8213d0841  vmovaps [rsp+0xE0], xmm15
000078f8213d084a  sub rsp, 0x30
000078f8213d084e  movaps [rsp], xmm13
000078f8213d0853  movaps [rsp+0x10], xmm1
000078f8213d0858  movaps [rsp+0x20], xmm14
000078f8213d085e  lea rdi, [rsp]
000078f8213d0862  mov esi, 0x00
000078f8213d0867  mov rax, 0x653D80F42530
000078f8213d0871  call rax
000078f8213d0873  movaps xmm13, [rsp]
000078f8213d0878  add rsp, 0x30
000078f8213d087c  vmovaps xmm0, [rsp]
000078f8213d0881  vmovaps xmm1, [rsp+0x10]
000078f8213d0887  vmovaps xmm2, [rsp+0x20]
000078f8213d088d  vmovaps xmm3, [rsp+0x30]
000078f8213d0893  vmovaps xmm4, [rsp+0x40]
000078f8213d0899  vmovaps xmm5, [rsp+0x50]
000078f8213d089f  vmovaps xmm6, [rsp+0x60]
000078f8213d08a5  vmovaps xmm7, [rsp+0x70]
000078f8213d08ab  vmovaps xmm8, [rsp+0x80]
000078f8213d08b4  vmovaps xmm9, [rsp+0x90]
000078f8213d08bd  vmovaps xmm10, [rsp+0xA0]
000078f8213d08c6  vmovaps xmm11, [rsp+0xB0]
000078f8213d08cf  vmovaps xmm12, [rsp+0xC0]
000078f8213d08d8  vmovaps xmm14, [rsp+0xD0]
000078f8213d08e1  vmovaps xmm15, [rsp+0xE0]
000078f8213d08ea  add rsp, 0xF0
000078f8213d08f1  pop r11
000078f8213d08f3  pop r10
000078f8213d08f5  pop r9
000078f8213d08f7  pop r8
000078f8213d08f9  pop rsi
000078f8213d08fa  pop rdi
000078f8213d08fb  pop rdx
000078f8213d08fc  pop rcx
000078f8213d08fd  pop rax
000078f8213d08fe  add rsp, 0x08
000078f8213d0902  jmp 0x000078F8213CF5CF
000078f8213d0907  sub rsp, 0x08
000078f8213d090b  push rax
000078f8213d090c  push rcx
000078f8213d090d  push rdx
000078f8213d090e  push rdi
000078f8213d090f  push rsi
000078f8213d0910  push r8
000078f8213d0912  push r9
000078f8213d0914  push r10
000078f8213d0916  push r11
000078f8213d0918  sub rsp, 0xF0
000078f8213d091f  vmovaps [rsp], xmm0
000078f8213d0924  vmovaps [rsp+0x10], xmm1
000078f8213d092a  vmovaps [rsp+0x20], xmm2
000078f8213d0930  vmovaps [rsp+0x30], xmm3
000078f8213d0936  vmovaps [rsp+0x40], xmm4
000078f8213d093c  vmovaps [rsp+0x50], xmm5
000078f8213d0942  vmovaps [rsp+0x60], xmm6
000078f8213d0948  vmovaps [rsp+0x70], xmm7
000078f8213d094e  vmovaps [rsp+0x80], xmm8
000078f8213d0957  vmovaps [rsp+0x90], xmm9
000078f8213d0960  vmovaps [rsp+0xA0], xmm10
000078f8213d0969  vmovaps [rsp+0xB0], xmm11
000078f8213d0972  vmovaps [rsp+0xC0], xmm12
000078f8213d097b  vmovaps [rsp+0xD0], xmm13
000078f8213d0984  vmovaps [rsp+0xE0], xmm14
000078f8213d098d  sub rsp, 0x30
000078f8213d0991  movaps [rsp], xmm15
000078f8213d0996  movaps [rsp+0x10], xmm14
000078f8213d099c  movaps [rsp+0x20], xmm1
000078f8213d09a1  lea rdi, [rsp]
000078f8213d09a5  mov esi, 0x00
000078f8213d09aa  mov rax, 0x653D80F42530
000078f8213d09b4  call rax
000078f8213d09b6  movaps xmm15, [rsp]
000078f8213d09bb  add rsp, 0x30
000078f8213d09bf  vmovaps xmm0, [rsp]
000078f8213d09c4  vmovaps xmm1, [rsp+0x10]
000078f8213d09ca  vmovaps xmm2, [rsp+0x20]
000078f8213d09d0  vmovaps xmm3, [rsp+0x30]
000078f8213d09d6  vmovaps xmm4, [rsp+0x40]
000078f8213d09dc  vmovaps xmm5, [rsp+0x50]
000078f8213d09e2  vmovaps xmm6, [rsp+0x60]
000078f8213d09e8  vmovaps xmm7, [rsp+0x70]
000078f8213d09ee  vmovaps xmm8, [rsp+0x80]
000078f8213d09f7  vmovaps xmm9, [rsp+0x90]
000078f8213d0a00  vmovaps xmm10, [rsp+0xA0]
000078f8213d0a09  vmovaps xmm11, [rsp+0xB0]
000078f8213d0a12  vmovaps xmm12, [rsp+0xC0]
000078f8213d0a1b  vmovaps xmm13, [rsp+0xD0]
000078f8213d0a24  vmovaps xmm14, [rsp+0xE0]
000078f8213d0a2d  add rsp, 0xF0
000078f8213d0a34  pop r11
000078f8213d0a36  pop r10
000078f8213d0a38  pop r9
000078f8213d0a3a  pop r8
000078f8213d0a3c  pop rsi
000078f8213d0a3d  pop rdi
000078f8213d0a3e  pop rdx
000078f8213d0a3f  pop rcx
000078f8213d0a40  pop rax
000078f8213d0a41  add rsp, 0x08
000078f8213d0a45  jmp 0x000078F8213CF617
000078f8213d0a4a  sub rsp, 0x08
000078f8213d0a4e  push rax
000078f8213d0a4f  push rcx
000078f8213d0a50  push rdx
000078f8213d0a51  push rdi
000078f8213d0a52  push rsi
000078f8213d0a53  push r8
000078f8213d0a55  push r9
000078f8213d0a57  push r10
000078f8213d0a59  push r11
000078f8213d0a5b  sub rsp, 0xF0
000078f8213d0a62  vmovaps [rsp], xmm0
000078f8213d0a67  vmovaps [rsp+0x10], xmm2
000078f8213d0a6d  vmovaps [rsp+0x20], xmm3
000078f8213d0a73  vmovaps [rsp+0x30], xmm4
000078f8213d0a79  vmovaps [rsp+0x40], xmm5
000078f8213d0a7f  vmovaps [rsp+0x50], xmm6
000078f8213d0a85  vmovaps [rsp+0x60], xmm7
000078f8213d0a8b  vmovaps [rsp+0x70], xmm8
000078f8213d0a91  vmovaps [rsp+0x80], xmm9
000078f8213d0a9a  vmovaps [rsp+0x90], xmm10
000078f8213d0aa3  vmovaps [rsp+0xA0], xmm11
000078f8213d0aac  vmovaps [rsp+0xB0], xmm12
000078f8213d0ab5  vmovaps [rsp+0xC0], xmm13
000078f8213d0abe  vmovaps [rsp+0xD0], xmm14
000078f8213d0ac7  vmovaps [rsp+0xE0], xmm15
000078f8213d0ad0  sub rsp, 0x30
000078f8213d0ad4  movaps [rsp], xmm1
000078f8213d0ad8  movaps [rsp+0x10], xmm14
000078f8213d0ade  movaps [rsp+0x20], xmm10
000078f8213d0ae4  lea rdi, [rsp]
000078f8213d0ae8  mov esi, 0x00
000078f8213d0aed  mov rax, 0x653D80F42530
000078f8213d0af7  call rax
000078f8213d0af9  movaps xmm1, [rsp]
000078f8213d0afd  add rsp, 0x30
000078f8213d0b01  vmovaps xmm0, [rsp]
000078f8213d0b06  vmovaps xmm2, [rsp+0x10]
000078f8213d0b0c  vmovaps xmm3, [rsp+0x20]
000078f8213d0b12  vmovaps xmm4, [rsp+0x30]
000078f8213d0b18  vmovaps xmm5, [rsp+0x40]
000078f8213d0b1e  vmovaps xmm6, [rsp+0x50]
000078f8213d0b24  vmovaps xmm7, [rsp+0x60]
000078f8213d0b2a  vmovaps xmm8, [rsp+0x70]
000078f8213d0b30  vmovaps xmm9, [rsp+0x80]
000078f8213d0b39  vmovaps xmm10, [rsp+0x90]
000078f8213d0b42  vmovaps xmm11, [rsp+0xA0]
000078f8213d0b4b  vmovaps xmm12, [rsp+0xB0]
000078f8213d0b54  vmovaps xmm13, [rsp+0xC0]
000078f8213d0b5d  vmovaps xmm14, [rsp+0xD0]
000078f8213d0b66  vmovaps xmm15, [rsp+0xE0]
000078f8213d0b6f  add rsp, 0xF0
000078f8213d0b76  pop r11
000078f8213d0b78  pop r10
000078f8213d0b7a  pop r9
000078f8213d0b7c  pop r8
000078f8213d0b7e  pop rsi
000078f8213d0b7f  pop rdi
000078f8213d0b80  pop rdx
000078f8213d0b81  pop rcx
000078f8213d0b82  pop rax
000078f8213d0b83  add rsp, 0x08
000078f8213d0b87  jmp 0x000078F8213CF631
000078f8213d0b8c  sub rsp, 0x08
000078f8213d0b90  push rax
000078f8213d0b91  push rcx
000078f8213d0b92  push rdx
000078f8213d0b93  push rdi
000078f8213d0b94  push rsi
000078f8213d0b95  push r8
000078f8213d0b97  push r9
000078f8213d0b99  push r10
000078f8213d0b9b  push r11
000078f8213d0b9d  sub rsp, 0xF0
000078f8213d0ba4  vmovaps [rsp], xmm0
000078f8213d0ba9  vmovaps [rsp+0x10], xmm1
000078f8213d0baf  vmovaps [rsp+0x20], xmm2
000078f8213d0bb5  vmovaps [rsp+0x30], xmm3
000078f8213d0bbb  vmovaps [rsp+0x40], xmm4
000078f8213d0bc1  vmovaps [rsp+0x50], xmm5
000078f8213d0bc7  vmovaps [rsp+0x60], xmm6
000078f8213d0bcd  vmovaps [rsp+0x70], xmm7
000078f8213d0bd3  vmovaps [rsp+0x80], xmm8
000078f8213d0bdc  vmovaps [rsp+0x90], xmm9
000078f8213d0be5  vmovaps [rsp+0xA0], xmm10
000078f8213d0bee  vmovaps [rsp+0xB0], xmm11
000078f8213d0bf7  vmovaps [rsp+0xC0], xmm12
000078f8213d0c00  vmovaps [rsp+0xD0], xmm14
000078f8213d0c09  vmovaps [rsp+0xE0], xmm15
000078f8213d0c12  sub rsp, 0x30
000078f8213d0c16  movaps [rsp], xmm13
000078f8213d0c1b  movaps [rsp+0x10], xmm14
000078f8213d0c21  movaps [rsp+0x20], xmm2
000078f8213d0c26  lea rdi, [rsp]
000078f8213d0c2a  mov esi, 0x00
000078f8213d0c2f  mov rax, 0x653D80F42530
000078f8213d0c39  call rax
000078f8213d0c3b  movaps xmm13, [rsp]
000078f8213d0c40  add rsp, 0x30
000078f8213d0c44  vmovaps xmm0, [rsp]
000078f8213d0c49  vmovaps xmm1, [rsp+0x10]
000078f8213d0c4f  vmovaps xmm2, [rsp+0x20]
000078f8213d0c55  vmovaps xmm3, [rsp+0x30]
000078f8213d0c5b  vmovaps xmm4, [rsp+0x40]
000078f8213d0c61  vmovaps xmm5, [rsp+0x50]
000078f8213d0c67  vmovaps xmm6, [rsp+0x60]
000078f8213d0c6d  vmovaps xmm7, [rsp+0x70]
000078f8213d0c73  vmovaps xmm8, [rsp+0x80]
000078f8213d0c7c  vmovaps xmm9, [rsp+0x90]
000078f8213d0c85  vmovaps xmm10, [rsp+0xA0]
000078f8213d0c8e  vmovaps xmm11, [rsp+0xB0]
000078f8213d0c97  vmovaps xmm12, [rsp+0xC0]
000078f8213d0ca0  vmovaps xmm14, [rsp+0xD0]
000078f8213d0ca9  vmovaps xmm15, [rsp+0xE0]
000078f8213d0cb2  add rsp, 0xF0
000078f8213d0cb9  pop r11
000078f8213d0cbb  pop r10
000078f8213d0cbd  pop r9
000078f8213d0cbf  pop r8
000078f8213d0cc1  pop rsi
000078f8213d0cc2  pop rdi
000078f8213d0cc3  pop rdx
000078f8213d0cc4  pop rcx
000078f8213d0cc5  pop rax
000078f8213d0cc6  add rsp, 0x08
000078f8213d0cca  jmp 0x000078F8213CF64C
000078f8213d0ccf  sub rsp, 0x08
000078f8213d0cd3  push rax
000078f8213d0cd4  push rcx
000078f8213d0cd5  push rdx
000078f8213d0cd6  push rdi
000078f8213d0cd7  push rsi
000078f8213d0cd8  push r8
000078f8213d0cda  push r9
000078f8213d0cdc  push r10
000078f8213d0cde  push r11
000078f8213d0ce0  sub rsp, 0xF0
000078f8213d0ce7  vmovaps [rsp], xmm0
000078f8213d0cec  vmovaps [rsp+0x10], xmm2
000078f8213d0cf2  vmovaps [rsp+0x20], xmm3
000078f8213d0cf8  vmovaps [rsp+0x30], xmm4
000078f8213d0cfe  vmovaps [rsp+0x40], xmm5
000078f8213d0d04  vmovaps [rsp+0x50], xmm6
000078f8213d0d0a  vmovaps [rsp+0x60], xmm7
000078f8213d0d10  vmovaps [rsp+0x70], xmm8
000078f8213d0d16  vmovaps [rsp+0x80], xmm9
000078f8213d0d1f  vmovaps [rsp+0x90], xmm10
000078f8213d0d28  vmovaps [rsp+0xA0], xmm11
000078f8213d0d31  vmovaps [rsp+0xB0], xmm12
000078f8213d0d3a  vmovaps [rsp+0xC0], xmm13
000078f8213d0d43  vmovaps [rsp+0xD0], xmm14
000078f8213d0d4c  vmovaps [rsp+0xE0], xmm15
000078f8213d0d55  sub rsp, 0x30
000078f8213d0d59  movaps [rsp], xmm1
000078f8213d0d5d  movaps [rsp+0x10], xmm10
000078f8213d0d63  movaps [rsp+0x20], xmm2
000078f8213d0d68  lea rdi, [rsp]
000078f8213d0d6c  mov esi, 0x00
000078f8213d0d71  mov rax, 0x653D80F42530
000078f8213d0d7b  call rax
000078f8213d0d7d  movaps xmm1, [rsp]
000078f8213d0d81  add rsp, 0x30
000078f8213d0d85  vmovaps xmm0, [rsp]
000078f8213d0d8a  vmovaps xmm2, [rsp+0x10]
000078f8213d0d90  vmovaps xmm3, [rsp+0x20]
000078f8213d0d96  vmovaps xmm4, [rsp+0x30]
000078f8213d0d9c  vmovaps xmm5, [rsp+0x40]
000078f8213d0da2  vmovaps xmm6, [rsp+0x50]
000078f8213d0da8  vmovaps xmm7, [rsp+0x60]
000078f8213d0dae  vmovaps xmm8, [rsp+0x70]
000078f8213d0db4  vmovaps xmm9, [rsp+0x80]
000078f8213d0dbd  vmovaps xmm10, [rsp+0x90]
000078f8213d0dc6  vmovaps xmm11, [rsp+0xA0]
000078f8213d0dcf  vmovaps xmm12, [rsp+0xB0]
000078f8213d0dd8  vmovaps xmm13, [rsp+0xC0]
000078f8213d0de1  vmovaps xmm14, [rsp+0xD0]
000078f8213d0dea  vmovaps xmm15, [rsp+0xE0]
000078f8213d0df3  add rsp, 0xF0
000078f8213d0dfa  pop r11
000078f8213d0dfc  pop r10
000078f8213d0dfe  pop r9
000078f8213d0e00  pop r8
000078f8213d0e02  pop rsi
000078f8213d0e03  pop rdi
000078f8213d0e04  pop rdx
000078f8213d0e05  pop rcx
000078f8213d0e06  pop rax
000078f8213d0e07  add rsp, 0x08
000078f8213d0e0b  jmp 0x000078F8213CF6B4
000078f8213d0e10  sub rsp, 0x08
000078f8213d0e14  push rax
000078f8213d0e15  push rcx
000078f8213d0e16  push rdx
000078f8213d0e17  push rdi
000078f8213d0e18  push rsi
000078f8213d0e19  push r8
000078f8213d0e1b  push r9
000078f8213d0e1d  push r10
000078f8213d0e1f  push r11
000078f8213d0e21  sub rsp, 0xF0
000078f8213d0e28  vmovaps [rsp], xmm0
000078f8213d0e2d  vmovaps [rsp+0x10], xmm1
000078f8213d0e33  vmovaps [rsp+0x20], xmm2
000078f8213d0e39  vmovaps [rsp+0x30], xmm3
000078f8213d0e3f  vmovaps [rsp+0x40], xmm4
000078f8213d0e45  vmovaps [rsp+0x50], xmm5
000078f8213d0e4b  vmovaps [rsp+0x60], xmm6
000078f8213d0e51  vmovaps [rsp+0x70], xmm7
000078f8213d0e57  vmovaps [rsp+0x80], xmm8
000078f8213d0e60  vmovaps [rsp+0x90], xmm9
000078f8213d0e69  vmovaps [rsp+0xA0], xmm10
000078f8213d0e72  vmovaps [rsp+0xB0], xmm11
000078f8213d0e7b  vmovaps [rsp+0xC0], xmm12
000078f8213d0e84  vmovaps [rsp+0xD0], xmm13
000078f8213d0e8d  vmovaps [rsp+0xE0], xmm14
000078f8213d0e96  sub rsp, 0x30
000078f8213d0e9a  movaps [rsp], xmm15
000078f8213d0e9f  movaps [rsp+0x10], xmm10
000078f8213d0ea5  movaps [rsp+0x20], xmm2
000078f8213d0eaa  lea rdi, [rsp]
000078f8213d0eae  mov esi, 0x00
000078f8213d0eb3  mov rax, 0x653D80F42530
000078f8213d0ebd  call rax
000078f8213d0ebf  movaps xmm15, [rsp]
000078f8213d0ec4  add rsp, 0x30
000078f8213d0ec8  vmovaps xmm0, [rsp]
000078f8213d0ecd  vmovaps xmm1, [rsp+0x10]
000078f8213d0ed3  vmovaps xmm2, [rsp+0x20]
000078f8213d0ed9  vmovaps xmm3, [rsp+0x30]
000078f8213d0edf  vmovaps xmm4, [rsp+0x40]
000078f8213d0ee5  vmovaps xmm5, [rsp+0x50]
000078f8213d0eeb  vmovaps xmm6, [rsp+0x60]
000078f8213d0ef1  vmovaps xmm7, [rsp+0x70]
000078f8213d0ef7  vmovaps xmm8, [rsp+0x80]
000078f8213d0f00  vmovaps xmm9, [rsp+0x90]
000078f8213d0f09  vmovaps xmm10, [rsp+0xA0]
000078f8213d0f12  vmovaps xmm11, [rsp+0xB0]
000078f8213d0f1b  vmovaps xmm12, [rsp+0xC0]
000078f8213d0f24  vmovaps xmm13, [rsp+0xD0]
000078f8213d0f2d  vmovaps xmm14, [rsp+0xE0]
000078f8213d0f36  add rsp, 0xF0
000078f8213d0f3d  pop r11
000078f8213d0f3f  pop r10
000078f8213d0f41  pop r9
000078f8213d0f43  pop r8
000078f8213d0f45  pop rsi
000078f8213d0f46  pop rdi
000078f8213d0f47  pop rdx
000078f8213d0f48  pop rcx
000078f8213d0f49  pop rax
000078f8213d0f4a  add rsp, 0x08
000078f8213d0f4e  jmp 0x000078F8213CF706
000078f8213d0f53  sub rsp, 0x08
000078f8213d0f57  push rax
000078f8213d0f58  push rcx
000078f8213d0f59  push rdx
000078f8213d0f5a  push rdi
000078f8213d0f5b  push rsi
000078f8213d0f5c  push r8
000078f8213d0f5e  push r9
000078f8213d0f60  push r10
000078f8213d0f62  push r11
000078f8213d0f64  sub rsp, 0xF0
000078f8213d0f6b  vmovaps [rsp], xmm0
000078f8213d0f70  vmovaps [rsp+0x10], xmm2
000078f8213d0f76  vmovaps [rsp+0x20], xmm3
000078f8213d0f7c  vmovaps [rsp+0x30], xmm4
000078f8213d0f82  vmovaps [rsp+0x40], xmm5
000078f8213d0f88  vmovaps [rsp+0x50], xmm6
000078f8213d0f8e  vmovaps [rsp+0x60], xmm7
000078f8213d0f94  vmovaps [rsp+0x70], xmm8
000078f8213d0f9a  vmovaps [rsp+0x80], xmm9
000078f8213d0fa3  vmovaps [rsp+0x90], xmm10
000078f8213d0fac  vmovaps [rsp+0xA0], xmm11
000078f8213d0fb5  vmovaps [rsp+0xB0], xmm12
000078f8213d0fbe  vmovaps [rsp+0xC0], xmm13
000078f8213d0fc7  vmovaps [rsp+0xD0], xmm14
000078f8213d0fd0  vmovaps [rsp+0xE0], xmm15
000078f8213d0fd9  sub rsp, 0x30
000078f8213d0fdd  movaps [rsp], xmm1
000078f8213d0fe1  movaps [rsp+0x10], xmm10
000078f8213d0fe7  movaps [rsp+0x20], xmm12
000078f8213d0fed  lea rdi, [rsp]
000078f8213d0ff1  mov esi, 0x00
000078f8213d0ff6  mov rax, 0x653D80F42530
000078f8213d1000  call rax
000078f8213d1002  movaps xmm1, [rsp]
000078f8213d1006  add rsp, 0x30
000078f8213d100a  vmovaps xmm0, [rsp]
000078f8213d100f  vmovaps xmm2, [rsp+0x10]
000078f8213d1015  vmovaps xmm3, [rsp+0x20]
000078f8213d101b  vmovaps xmm4, [rsp+0x30]
000078f8213d1021  vmovaps xmm5, [rsp+0x40]
000078f8213d1027  vmovaps xmm6, [rsp+0x50]
000078f8213d102d  vmovaps xmm7, [rsp+0x60]
000078f8213d1033  vmovaps xmm8, [rsp+0x70]
000078f8213d1039  vmovaps xmm9, [rsp+0x80]
000078f8213d1042  vmovaps xmm10, [rsp+0x90]
000078f8213d104b  vmovaps xmm11, [rsp+0xA0]
000078f8213d1054  vmovaps xmm12, [rsp+0xB0]
000078f8213d105d  vmovaps xmm13, [rsp+0xC0]
000078f8213d1066  vmovaps xmm14, [rsp+0xD0]
000078f8213d106f  vmovaps xmm15, [rsp+0xE0]
000078f8213d1078  add rsp, 0xF0
000078f8213d107f  pop r11
000078f8213d1081  pop r10
000078f8213d1083  pop r9
000078f8213d1085  pop r8
000078f8213d1087  pop rsi
000078f8213d1088  pop rdi
000078f8213d1089  pop rdx
000078f8213d108a  pop rcx
000078f8213d108b  pop rax
000078f8213d108c  add rsp, 0x08
000078f8213d1090  jmp 0x000078F8213CF732
000078f8213d1095  sub rsp, 0x08
000078f8213d1099  push rax
000078f8213d109a  push rcx
000078f8213d109b  push rdx
000078f8213d109c  push rdi
000078f8213d109d  push rsi
000078f8213d109e  push r8
000078f8213d10a0  push r9
000078f8213d10a2  push r10
000078f8213d10a4  push r11
000078f8213d10a6  sub rsp, 0xF0
000078f8213d10ad  vmovaps [rsp], xmm0
000078f8213d10b2  vmovaps [rsp+0x10], xmm1
000078f8213d10b8  vmovaps [rsp+0x20], xmm2
000078f8213d10be  vmovaps [rsp+0x30], xmm3
000078f8213d10c4  vmovaps [rsp+0x40], xmm4
000078f8213d10ca  vmovaps [rsp+0x50], xmm5
000078f8213d10d0  vmovaps [rsp+0x60], xmm6
000078f8213d10d6  vmovaps [rsp+0x70], xmm7
000078f8213d10dc  vmovaps [rsp+0x80], xmm8
000078f8213d10e5  vmovaps [rsp+0x90], xmm9
000078f8213d10ee  vmovaps [rsp+0xA0], xmm10
000078f8213d10f7  vmovaps [rsp+0xB0], xmm11
000078f8213d1100  vmovaps [rsp+0xC0], xmm12
000078f8213d1109  vmovaps [rsp+0xD0], xmm13
000078f8213d1112  vmovaps [rsp+0xE0], xmm14
000078f8213d111b  sub rsp, 0x30
000078f8213d111f  movaps [rsp], xmm15
000078f8213d1124  movaps [rsp+0x10], xmm10
000078f8213d112a  movaps [rsp+0x20], xmm12
000078f8213d1130  lea rdi, [rsp]
000078f8213d1134  mov esi, 0x00
000078f8213d1139  mov rax, 0x653D80F42530
000078f8213d1143  call rax
000078f8213d1145  movaps xmm15, [rsp]
000078f8213d114a  add rsp, 0x30
000078f8213d114e  vmovaps xmm0, [rsp]
000078f8213d1153  vmovaps xmm1, [rsp+0x10]
000078f8213d1159  vmovaps xmm2, [rsp+0x20]
000078f8213d115f  vmovaps xmm3, [rsp+0x30]
000078f8213d1165  vmovaps xmm4, [rsp+0x40]
000078f8213d116b  vmovaps xmm5, [rsp+0x50]
000078f8213d1171  vmovaps xmm6, [rsp+0x60]
000078f8213d1177  vmovaps xmm7, [rsp+0x70]
000078f8213d117d  vmovaps xmm8, [rsp+0x80]
000078f8213d1186  vmovaps xmm9, [rsp+0x90]
000078f8213d118f  vmovaps xmm10, [rsp+0xA0]
000078f8213d1198  vmovaps xmm11, [rsp+0xB0]
000078f8213d11a1  vmovaps xmm12, [rsp+0xC0]
000078f8213d11aa  vmovaps xmm13, [rsp+0xD0]
000078f8213d11b3  vmovaps xmm14, [rsp+0xE0]
000078f8213d11bc  add rsp, 0xF0
000078f8213d11c3  pop r11
000078f8213d11c5  pop r10
000078f8213d11c7  pop r9
000078f8213d11c9  pop r8
000078f8213d11cb  pop rsi
000078f8213d11cc  pop rdi
000078f8213d11cd  pop rdx
000078f8213d11ce  pop rcx
000078f8213d11cf  pop rax
000078f8213d11d0  add rsp, 0x08
000078f8213d11d4  jmp 0x000078F8213CF75E
000078f8213d11d9  call 0x000078F8211FF430
000078f8213d11de  jmp 0x000078F8213CF7EE
000078f8213d11e3  call 0x000078F8211FF430
000078f8213d11e8  jmp 0x000078F8213CF801
000078f8213d11ed  sub rsp, 0x08
000078f8213d11f1  push rax
000078f8213d11f2  push rcx
000078f8213d11f3  push rdx
000078f8213d11f4  push rdi
000078f8213d11f5  push rsi
000078f8213d11f6  push r8
000078f8213d11f8  push r9
000078f8213d11fa  push r10
000078f8213d11fc  push r11
000078f8213d11fe  sub rsp, 0xF0
000078f8213d1205  vmovaps [rsp], xmm0
000078f8213d120a  vmovaps [rsp+0x10], xmm2
000078f8213d1210  vmovaps [rsp+0x20], xmm3
000078f8213d1216  vmovaps [rsp+0x30], xmm4
000078f8213d121c  vmovaps [rsp+0x40], xmm5
000078f8213d1222  vmovaps [rsp+0x50], xmm6
000078f8213d1228  vmovaps [rsp+0x60], xmm7
000078f8213d122e  vmovaps [rsp+0x70], xmm8
000078f8213d1234  vmovaps [rsp+0x80], xmm9
000078f8213d123d  vmovaps [rsp+0x90], xmm10
000078f8213d1246  vmovaps [rsp+0xA0], xmm11
000078f8213d124f  vmovaps [rsp+0xB0], xmm12
000078f8213d1258  vmovaps [rsp+0xC0], xmm13
000078f8213d1261  vmovaps [rsp+0xD0], xmm14
000078f8213d126a  vmovaps [rsp+0xE0], xmm15
000078f8213d1273  sub rsp, 0x30
000078f8213d1277  movaps [rsp], xmm1
000078f8213d127b  movaps [rsp+0x10], xmm13
000078f8213d1281  movaps [rsp+0x20], xmm2
000078f8213d1286  lea rdi, [rsp]
000078f8213d128a  mov esi, 0x00
000078f8213d128f  mov rax, 0x653D80F42530
000078f8213d1299  call rax
000078f8213d129b  movaps xmm1, [rsp]
000078f8213d129f  add rsp, 0x30
000078f8213d12a3  vmovaps xmm0, [rsp]
000078f8213d12a8  vmovaps xmm2, [rsp+0x10]
000078f8213d12ae  vmovaps xmm3, [rsp+0x20]
000078f8213d12b4  vmovaps xmm4, [rsp+0x30]
000078f8213d12ba  vmovaps xmm5, [rsp+0x40]
000078f8213d12c0  vmovaps xmm6, [rsp+0x50]
000078f8213d12c6  vmovaps xmm7, [rsp+0x60]
000078f8213d12cc  vmovaps xmm8, [rsp+0x70]
000078f8213d12d2  vmovaps xmm9, [rsp+0x80]
000078f8213d12db  vmovaps xmm10, [rsp+0x90]
000078f8213d12e4  vmovaps xmm11, [rsp+0xA0]
000078f8213d12ed  vmovaps xmm12, [rsp+0xB0]
000078f8213d12f6  vmovaps xmm13, [rsp+0xC0]
000078f8213d12ff  vmovaps xmm14, [rsp+0xD0]
000078f8213d1308  vmovaps xmm15, [rsp+0xE0]
000078f8213d1311  add rsp, 0xF0
000078f8213d1318  pop r11
000078f8213d131a  pop r10
000078f8213d131c  pop r9
000078f8213d131e  pop r8
000078f8213d1320  pop rsi
000078f8213d1321  pop rdi
000078f8213d1322  pop rdx
000078f8213d1323  pop rcx
000078f8213d1324  pop rax
000078f8213d1325  add rsp, 0x08
000078f8213d1329  jmp 0x000078F8213CF82C
000078f8213d132e  call 0x000078F82120E760
000078f8213d1333  jmp 0x000078F8213CF839
000078f8213d1338  sub rsp, 0x08
000078f8213d133c  push rax
000078f8213d133d  push rcx
000078f8213d133e  push rdx
000078f8213d133f  push rdi
000078f8213d1340  push rsi
000078f8213d1341  push r8
000078f8213d1343  push r9
000078f8213d1345  push r10
000078f8213d1347  push r11
000078f8213d1349  sub rsp, 0xF0
000078f8213d1350  vmovaps [rsp], xmm0
000078f8213d1355  vmovaps [rsp+0x10], xmm1
000078f8213d135b  vmovaps [rsp+0x20], xmm2
000078f8213d1361  vmovaps [rsp+0x30], xmm3
000078f8213d1367  vmovaps [rsp+0x40], xmm4
000078f8213d136d  vmovaps [rsp+0x50], xmm5
000078f8213d1373  vmovaps [rsp+0x60], xmm6
000078f8213d1379  vmovaps [rsp+0x70], xmm7
000078f8213d137f  vmovaps [rsp+0x80], xmm8
000078f8213d1388  vmovaps [rsp+0x90], xmm9
000078f8213d1391  vmovaps [rsp+0xA0], xmm10
000078f8213d139a  vmovaps [rsp+0xB0], xmm11
000078f8213d13a3  vmovaps [rsp+0xC0], xmm12
000078f8213d13ac  vmovaps [rsp+0xD0], xmm14
000078f8213d13b5  vmovaps [rsp+0xE0], xmm15
000078f8213d13be  sub rsp, 0x30
000078f8213d13c2  movaps [rsp], xmm13
000078f8213d13c7  movaps [rsp+0x10], xmm2
000078f8213d13cc  movaps [rsp+0x20], xmm1
000078f8213d13d1  lea rdi, [rsp]
000078f8213d13d5  mov esi, 0x00
000078f8213d13da  mov rax, 0x653D80F42530
000078f8213d13e4  call rax
000078f8213d13e6  movaps xmm13, [rsp]
000078f8213d13eb  add rsp, 0x30
000078f8213d13ef  vmovaps xmm0, [rsp]
000078f8213d13f4  vmovaps xmm1, [rsp+0x10]
000078f8213d13fa  vmovaps xmm2, [rsp+0x20]
000078f8213d1400  vmovaps xmm3, [rsp+0x30]
000078f8213d1406  vmovaps xmm4, [rsp+0x40]
000078f8213d140c  vmovaps xmm5, [rsp+0x50]
000078f8213d1412  vmovaps xmm6, [rsp+0x60]
000078f8213d1418  vmovaps xmm7, [rsp+0x70]
000078f8213d141e  vmovaps xmm8, [rsp+0x80]
000078f8213d1427  vmovaps xmm9, [rsp+0x90]
000078f8213d1430  vmovaps xmm10, [rsp+0xA0]
000078f8213d1439  vmovaps xmm11, [rsp+0xB0]
000078f8213d1442  vmovaps xmm12, [rsp+0xC0]
000078f8213d144b  vmovaps xmm14, [rsp+0xD0]
000078f8213d1454  vmovaps xmm15, [rsp+0xE0]
000078f8213d145d  add rsp, 0xF0
000078f8213d1464  pop r11
000078f8213d1466  pop r10
000078f8213d1468  pop r9
000078f8213d146a  pop r8
000078f8213d146c  pop rsi
000078f8213d146d  pop rdi
000078f8213d146e  pop rdx
000078f8213d146f  pop rcx
000078f8213d1470  pop rax
000078f8213d1471  add rsp, 0x08
000078f8213d1475  jmp 0x000078F8213CF878
000078f8213d147a  sub rsp, 0x08
000078f8213d147e  push rax
000078f8213d147f  push rcx
000078f8213d1480  push rdx
000078f8213d1481  push rdi
000078f8213d1482  push rsi
000078f8213d1483  push r8
000078f8213d1485  push r9
000078f8213d1487  push r10
000078f8213d1489  push r11
000078f8213d148b  sub rsp, 0xF0
000078f8213d1492  vmovaps [rsp], xmm0
000078f8213d1497  vmovaps [rsp+0x10], xmm2
000078f8213d149d  vmovaps [rsp+0x20], xmm3
000078f8213d14a3  vmovaps [rsp+0x30], xmm4
000078f8213d14a9  vmovaps [rsp+0x40], xmm5
000078f8213d14af  vmovaps [rsp+0x50], xmm6
000078f8213d14b5  vmovaps [rsp+0x60], xmm7
000078f8213d14bb  vmovaps [rsp+0x70], xmm8
000078f8213d14c1  vmovaps [rsp+0x80], xmm9
000078f8213d14ca  vmovaps [rsp+0x90], xmm10
000078f8213d14d3  vmovaps [rsp+0xA0], xmm11
000078f8213d14dc  vmovaps [rsp+0xB0], xmm12
000078f8213d14e5  vmovaps [rsp+0xC0], xmm13
000078f8213d14ee  vmovaps [rsp+0xD0], xmm14
000078f8213d14f7  vmovaps [rsp+0xE0], xmm15
000078f8213d1500  sub rsp, 0x30
000078f8213d1504  movaps [rsp], xmm1
000078f8213d1508  movaps [rsp+0x10], xmm15
000078f8213d150e  movaps [rsp+0x20], xmm2
000078f8213d1513  lea rdi, [rsp]
000078f8213d1517  mov esi, 0x00
000078f8213d151c  mov rax, 0x653D80F42530
000078f8213d1526  call rax
000078f8213d1528  movaps xmm1, [rsp]
000078f8213d152c  add rsp, 0x30
000078f8213d1530  vmovaps xmm0, [rsp]
000078f8213d1535  vmovaps xmm2, [rsp+0x10]
000078f8213d153b  vmovaps xmm3, [rsp+0x20]
000078f8213d1541  vmovaps xmm4, [rsp+0x30]
000078f8213d1547  vmovaps xmm5, [rsp+0x40]
000078f8213d154d  vmovaps xmm6, [rsp+0x50]
000078f8213d1553  vmovaps xmm7, [rsp+0x60]
000078f8213d1559  vmovaps xmm8, [rsp+0x70]
000078f8213d155f  vmovaps xmm9, [rsp+0x80]
000078f8213d1568  vmovaps xmm10, [rsp+0x90]
000078f8213d1571  vmovaps xmm11, [rsp+0xA0]
000078f8213d157a  vmovaps xmm12, [rsp+0xB0]
000078f8213d1583  vmovaps xmm13, [rsp+0xC0]
000078f8213d158c  vmovaps xmm14, [rsp+0xD0]
000078f8213d1595  vmovaps xmm15, [rsp+0xE0]
000078f8213d159e  add rsp, 0xF0
000078f8213d15a5  pop r11
000078f8213d15a7  pop r10
000078f8213d15a9  pop r9
000078f8213d15ab  pop r8
000078f8213d15ad  pop rsi
000078f8213d15ae  pop rdi
000078f8213d15af  pop rdx
000078f8213d15b0  pop rcx
000078f8213d15b1  pop rax
000078f8213d15b2  add rsp, 0x08
000078f8213d15b6  jmp 0x000078F8213CF8AC
000078f8213d15bb  sub rsp, 0x08
000078f8213d15bf  push rax
000078f8213d15c0  push rcx
000078f8213d15c1  push rdx
000078f8213d15c2  push rdi
000078f8213d15c3  push rsi
000078f8213d15c4  push r8
000078f8213d15c6  push r9
000078f8213d15c8  push r10
000078f8213d15ca  push r11
000078f8213d15cc  sub rsp, 0xF0
000078f8213d15d3  vmovaps [rsp], xmm0
000078f8213d15d8  vmovaps [rsp+0x10], xmm1
000078f8213d15de  vmovaps [rsp+0x20], xmm2
000078f8213d15e4  vmovaps [rsp+0x30], xmm3
000078f8213d15ea  vmovaps [rsp+0x40], xmm4
000078f8213d15f0  vmovaps [rsp+0x50], xmm5
000078f8213d15f6  vmovaps [rsp+0x60], xmm6
000078f8213d15fc  vmovaps [rsp+0x70], xmm7
000078f8213d1602  vmovaps [rsp+0x80], xmm8
000078f8213d160b  vmovaps [rsp+0x90], xmm9
000078f8213d1614  vmovaps [rsp+0xA0], xmm10
000078f8213d161d  vmovaps [rsp+0xB0], xmm11
000078f8213d1626  vmovaps [rsp+0xC0], xmm12
000078f8213d162f  vmovaps [rsp+0xD0], xmm13
000078f8213d1638  vmovaps [rsp+0xE0], xmm15
000078f8213d1641  sub rsp, 0x30
000078f8213d1645  movaps [rsp], xmm14
000078f8213d164a  movaps [rsp+0x10], xmm2
000078f8213d164f  movaps [rsp+0x20], xmm15
000078f8213d1655  lea rdi, [rsp]
000078f8213d1659  mov esi, 0x00
000078f8213d165e  mov rax, 0x653D80F42530
000078f8213d1668  call rax
000078f8213d166a  movaps xmm14, [rsp]
000078f8213d166f  add rsp, 0x30
000078f8213d1673  vmovaps xmm0, [rsp]
000078f8213d1678  vmovaps xmm1, [rsp+0x10]
000078f8213d167e  vmovaps xmm2, [rsp+0x20]
000078f8213d1684  vmovaps xmm3, [rsp+0x30]
000078f8213d168a  vmovaps xmm4, [rsp+0x40]
000078f8213d1690  vmovaps xmm5, [rsp+0x50]
000078f8213d1696  vmovaps xmm6, [rsp+0x60]
000078f8213d169c  vmovaps xmm7, [rsp+0x70]
000078f8213d16a2  vmovaps xmm8, [rsp+0x80]
000078f8213d16ab  vmovaps xmm9, [rsp+0x90]
000078f8213d16b4  vmovaps xmm10, [rsp+0xA0]
000078f8213d16bd  vmovaps xmm11, [rsp+0xB0]
000078f8213d16c6  vmovaps xmm12, [rsp+0xC0]
000078f8213d16cf  vmovaps xmm13, [rsp+0xD0]
000078f8213d16d8  vmovaps xmm15, [rsp+0xE0]
000078f8213d16e1  add rsp, 0xF0
000078f8213d16e8  pop r11
000078f8213d16ea  pop r10
000078f8213d16ec  pop r9
000078f8213d16ee  pop r8
000078f8213d16f0  pop rsi
000078f8213d16f1  pop rdi
000078f8213d16f2  pop rdx
000078f8213d16f3  pop rcx
000078f8213d16f4  pop rax
000078f8213d16f5  add rsp, 0x08
000078f8213d16f9  jmp 0x000078F8213CF8E7
000078f8213d16fe  sub rsp, 0x08
000078f8213d1702  push rax
000078f8213d1703  push rcx
000078f8213d1704  push rdx
000078f8213d1705  push rdi
000078f8213d1706  push rsi
000078f8213d1707  push r8
000078f8213d1709  push r9
000078f8213d170b  push r10
000078f8213d170d  push r11
000078f8213d170f  sub rsp, 0xF0
000078f8213d1716  vmovaps [rsp], xmm0
000078f8213d171b  vmovaps [rsp+0x10], xmm1
000078f8213d1721  vmovaps [rsp+0x20], xmm2
000078f8213d1727  vmovaps [rsp+0x30], xmm3
000078f8213d172d  vmovaps [rsp+0x40], xmm4
000078f8213d1733  vmovaps [rsp+0x50], xmm5
000078f8213d1739  vmovaps [rsp+0x60], xmm6
000078f8213d173f  vmovaps [rsp+0x70], xmm7
000078f8213d1745  vmovaps [rsp+0x80], xmm8
000078f8213d174e  vmovaps [rsp+0x90], xmm9
000078f8213d1757  vmovaps [rsp+0xA0], xmm10
000078f8213d1760  vmovaps [rsp+0xB0], xmm11
000078f8213d1769  vmovaps [rsp+0xC0], xmm12
000078f8213d1772  vmovaps [rsp+0xD0], xmm13
000078f8213d177b  vmovaps [rsp+0xE0], xmm14
000078f8213d1784  sub rsp, 0x30
000078f8213d1788  movaps [rsp], xmm15
000078f8213d178d  movaps [rsp+0x10], xmm2
000078f8213d1792  movaps [rsp+0x20], xmm1
000078f8213d1797  lea rdi, [rsp]
000078f8213d179b  mov esi, 0x00
000078f8213d17a0  mov rax, 0x653D80F42530
000078f8213d17aa  call rax
000078f8213d17ac  movaps xmm15, [rsp]
000078f8213d17b1  add rsp, 0x30
000078f8213d17b5  vmovaps xmm0, [rsp]
000078f8213d17ba  vmovaps xmm1, [rsp+0x10]
000078f8213d17c0  vmovaps xmm2, [rsp+0x20]
000078f8213d17c6  vmovaps xmm3, [rsp+0x30]
000078f8213d17cc  vmovaps xmm4, [rsp+0x40]
000078f8213d17d2  vmovaps xmm5, [rsp+0x50]
000078f8213d17d8  vmovaps xmm6, [rsp+0x60]
000078f8213d17de  vmovaps xmm7, [rsp+0x70]
000078f8213d17e4  vmovaps xmm8, [rsp+0x80]
000078f8213d17ed  vmovaps xmm9, [rsp+0x90]
000078f8213d17f6  vmovaps xmm10, [rsp+0xA0]
000078f8213d17ff  vmovaps xmm11, [rsp+0xB0]
000078f8213d1808  vmovaps xmm12, [rsp+0xC0]
000078f8213d1811  vmovaps xmm13, [rsp+0xD0]
000078f8213d181a  vmovaps xmm14, [rsp+0xE0]
000078f8213d1823  add rsp, 0xF0
000078f8213d182a  pop r11
000078f8213d182c  pop r10
000078f8213d182e  pop r9
000078f8213d1830  pop r8
000078f8213d1832  pop rsi
000078f8213d1833  pop rdi
000078f8213d1834  pop rdx
000078f8213d1835  pop rcx
000078f8213d1836  pop rax
000078f8213d1837  add rsp, 0x08
000078f8213d183b  jmp 0x000078F8213CF923
000078f8213d1840  call 0x000078F8211FF430
000078f8213d1845  jmp 0x000078F8213CF930
000078f8213d184a  sub rsp, 0x08
000078f8213d184e  push rax
000078f8213d184f  push rcx
000078f8213d1850  push rdx
000078f8213d1851  push rdi
000078f8213d1852  push rsi
000078f8213d1853  push r8
000078f8213d1855  push r9
000078f8213d1857  push r10
000078f8213d1859  push r11
000078f8213d185b  sub rsp, 0xF0
000078f8213d1862  vmovaps [rsp], xmm0
000078f8213d1867  vmovaps [rsp+0x10], xmm1
000078f8213d186d  vmovaps [rsp+0x20], xmm3
000078f8213d1873  vmovaps [rsp+0x30], xmm4
000078f8213d1879  vmovaps [rsp+0x40], xmm5
000078f8213d187f  vmovaps [rsp+0x50], xmm6
000078f8213d1885  vmovaps [rsp+0x60], xmm7
000078f8213d188b  vmovaps [rsp+0x70], xmm8
000078f8213d1891  vmovaps [rsp+0x80], xmm9
000078f8213d189a  vmovaps [rsp+0x90], xmm10
000078f8213d18a3  vmovaps [rsp+0xA0], xmm11
000078f8213d18ac  vmovaps [rsp+0xB0], xmm12
000078f8213d18b5  vmovaps [rsp+0xC0], xmm13
000078f8213d18be  vmovaps [rsp+0xD0], xmm14
000078f8213d18c7  vmovaps [rsp+0xE0], xmm15
000078f8213d18d0  sub rsp, 0x30
000078f8213d18d4  movaps [rsp], xmm2
000078f8213d18d8  movaps [rsp+0x10], xmm1
000078f8213d18dd  movaps [rsp+0x20], xmm14
000078f8213d18e3  lea rdi, [rsp]
000078f8213d18e7  mov esi, 0x00
000078f8213d18ec  mov rax, 0x653D80F42530
000078f8213d18f6  call rax
000078f8213d18f8  movaps xmm2, [rsp]
000078f8213d18fc  add rsp, 0x30
000078f8213d1900  vmovaps xmm0, [rsp]
000078f8213d1905  vmovaps xmm1, [rsp+0x10]
000078f8213d190b  vmovaps xmm3, [rsp+0x20]
000078f8213d1911  vmovaps xmm4, [rsp+0x30]
000078f8213d1917  vmovaps xmm5, [rsp+0x40]
000078f8213d191d  vmovaps xmm6, [rsp+0x50]
000078f8213d1923  vmovaps xmm7, [rsp+0x60]
000078f8213d1929  vmovaps xmm8, [rsp+0x70]
000078f8213d192f  vmovaps xmm9, [rsp+0x80]
000078f8213d1938  vmovaps xmm10, [rsp+0x90]
000078f8213d1941  vmovaps xmm11, [rsp+0xA0]
000078f8213d194a  vmovaps xmm12, [rsp+0xB0]
000078f8213d1953  vmovaps xmm13, [rsp+0xC0]
000078f8213d195c  vmovaps xmm14, [rsp+0xD0]
000078f8213d1965  vmovaps xmm15, [rsp+0xE0]
000078f8213d196e  add rsp, 0xF0
000078f8213d1975  pop r11
000078f8213d1977  pop r10
000078f8213d1979  pop r9
000078f8213d197b  pop r8
000078f8213d197d  pop rsi
000078f8213d197e  pop rdi
000078f8213d197f  pop rdx
000078f8213d1980  pop rcx
000078f8213d1981  pop rax
000078f8213d1982  add rsp, 0x08
000078f8213d1986  jmp 0x000078F8213CF96D
000078f8213d198b  sub rsp, 0x08
000078f8213d198f  push rax
000078f8213d1990  push rcx
000078f8213d1991  push rdx
000078f8213d1992  push rdi
000078f8213d1993  push rsi
000078f8213d1994  push r8
000078f8213d1996  push r9
000078f8213d1998  push r10
000078f8213d199a  push r11
000078f8213d199c  sub rsp, 0xF0
000078f8213d19a3  vmovaps [rsp], xmm0
000078f8213d19a8  vmovaps [rsp+0x10], xmm1
000078f8213d19ae  vmovaps [rsp+0x20], xmm2
000078f8213d19b4  vmovaps [rsp+0x30], xmm3
000078f8213d19ba  vmovaps [rsp+0x40], xmm4
000078f8213d19c0  vmovaps [rsp+0x50], xmm5
000078f8213d19c6  vmovaps [rsp+0x60], xmm6
000078f8213d19cc  vmovaps [rsp+0x70], xmm7
000078f8213d19d2  vmovaps [rsp+0x80], xmm8
000078f8213d19db  vmovaps [rsp+0x90], xmm9
000078f8213d19e4  vmovaps [rsp+0xA0], xmm10
000078f8213d19ed  vmovaps [rsp+0xB0], xmm11
000078f8213d19f6  vmovaps [rsp+0xC0], xmm12
000078f8213d19ff  vmovaps [rsp+0xD0], xmm13
000078f8213d1a08  vmovaps [rsp+0xE0], xmm14
000078f8213d1a11  sub rsp, 0x30
000078f8213d1a15  movaps [rsp], xmm15
000078f8213d1a1a  movaps [rsp+0x10], xmm14
000078f8213d1a20  movaps [rsp+0x20], xmm1
000078f8213d1a25  lea rdi, [rsp]
000078f8213d1a29  mov esi, 0x00
000078f8213d1a2e  mov rax, 0x653D80F42530
000078f8213d1a38  call rax
000078f8213d1a3a  movaps xmm15, [rsp]
000078f8213d1a3f  add rsp, 0x30
000078f8213d1a43  vmovaps xmm0, [rsp]
000078f8213d1a48  vmovaps xmm1, [rsp+0x10]
000078f8213d1a4e  vmovaps xmm2, [rsp+0x20]
000078f8213d1a54  vmovaps xmm3, [rsp+0x30]
000078f8213d1a5a  vmovaps xmm4, [rsp+0x40]
000078f8213d1a60  vmovaps xmm5, [rsp+0x50]
000078f8213d1a66  vmovaps xmm6, [rsp+0x60]
000078f8213d1a6c  vmovaps xmm7, [rsp+0x70]
000078f8213d1a72  vmovaps xmm8, [rsp+0x80]
000078f8213d1a7b  vmovaps xmm9, [rsp+0x90]
000078f8213d1a84  vmovaps xmm10, [rsp+0xA0]
000078f8213d1a8d  vmovaps xmm11, [rsp+0xB0]
000078f8213d1a96  vmovaps xmm12, [rsp+0xC0]
000078f8213d1a9f  vmovaps xmm13, [rsp+0xD0]
000078f8213d1aa8  vmovaps xmm14, [rsp+0xE0]
000078f8213d1ab1  add rsp, 0xF0
000078f8213d1ab8  pop r11
000078f8213d1aba  pop r10
000078f8213d1abc  pop r9
000078f8213d1abe  pop r8
000078f8213d1ac0  pop rsi
000078f8213d1ac1  pop rdi
000078f8213d1ac2  pop rdx
000078f8213d1ac3  pop rcx
000078f8213d1ac4  pop rax
000078f8213d1ac5  add rsp, 0x08
000078f8213d1ac9  jmp 0x000078F8213CF9E7
000078f8213d1ace  call 0x000078F8211FF430
000078f8213d1ad3  jmp 0x000078F8213CF9F4
000078f8213d1ad8  sub rsp, 0x08
000078f8213d1adc  push rax
000078f8213d1add  push rcx
000078f8213d1ade  push rdx
000078f8213d1adf  push rdi
000078f8213d1ae0  push rsi
000078f8213d1ae1  push r8
000078f8213d1ae3  push r9
000078f8213d1ae5  push r10
000078f8213d1ae7  push r11
000078f8213d1ae9  sub rsp, 0xF0
000078f8213d1af0  vmovaps [rsp], xmm0
000078f8213d1af5  vmovaps [rsp+0x10], xmm1
000078f8213d1afb  vmovaps [rsp+0x20], xmm2
000078f8213d1b01  vmovaps [rsp+0x30], xmm3
000078f8213d1b07  vmovaps [rsp+0x40], xmm4
000078f8213d1b0d  vmovaps [rsp+0x50], xmm5
000078f8213d1b13  vmovaps [rsp+0x60], xmm6
000078f8213d1b19  vmovaps [rsp+0x70], xmm7
000078f8213d1b1f  vmovaps [rsp+0x80], xmm8
000078f8213d1b28  vmovaps [rsp+0x90], xmm9
000078f8213d1b31  vmovaps [rsp+0xA0], xmm10
000078f8213d1b3a  vmovaps [rsp+0xB0], xmm11
000078f8213d1b43  vmovaps [rsp+0xC0], xmm12
000078f8213d1b4c  vmovaps [rsp+0xD0], xmm13
000078f8213d1b55  vmovaps [rsp+0xE0], xmm15
000078f8213d1b5e  sub rsp, 0x30
000078f8213d1b62  movaps [rsp], xmm14
000078f8213d1b67  movaps [rsp+0x10], xmm13
000078f8213d1b6d  movaps [rsp+0x20], xmm1
000078f8213d1b72  lea rdi, [rsp]
000078f8213d1b76  mov esi, 0x00
000078f8213d1b7b  mov rax, 0x653D80F42530
000078f8213d1b85  call rax
000078f8213d1b87  movaps xmm14, [rsp]
000078f8213d1b8c  add rsp, 0x30
000078f8213d1b90  vmovaps xmm0, [rsp]
000078f8213d1b95  vmovaps xmm1, [rsp+0x10]
000078f8213d1b9b  vmovaps xmm2, [rsp+0x20]
000078f8213d1ba1  vmovaps xmm3, [rsp+0x30]
000078f8213d1ba7  vmovaps xmm4, [rsp+0x40]
000078f8213d1bad  vmovaps xmm5, [rsp+0x50]
000078f8213d1bb3  vmovaps xmm6, [rsp+0x60]
000078f8213d1bb9  vmovaps xmm7, [rsp+0x70]
000078f8213d1bbf  vmovaps xmm8, [rsp+0x80]
000078f8213d1bc8  vmovaps xmm9, [rsp+0x90]
000078f8213d1bd1  vmovaps xmm10, [rsp+0xA0]
000078f8213d1bda  vmovaps xmm11, [rsp+0xB0]
000078f8213d1be3  vmovaps xmm12, [rsp+0xC0]
000078f8213d1bec  vmovaps xmm13, [rsp+0xD0]
000078f8213d1bf5  vmovaps xmm15, [rsp+0xE0]
000078f8213d1bfe  add rsp, 0xF0
000078f8213d1c05  pop r11
000078f8213d1c07  pop r10
000078f8213d1c09  pop r9
000078f8213d1c0b  pop r8
000078f8213d1c0d  pop rsi
000078f8213d1c0e  pop rdi
000078f8213d1c0f  pop rdx
000078f8213d1c10  pop rcx
000078f8213d1c11  pop rax
000078f8213d1c12  add rsp, 0x08
000078f8213d1c16  jmp 0x000078F8213CFAAF
000078f8213d1c1b  sub rsp, 0x08
000078f8213d1c1f  push rax
000078f8213d1c20  push rcx
000078f8213d1c21  push rdx
000078f8213d1c22  push rdi
000078f8213d1c23  push rsi
000078f8213d1c24  push r8
000078f8213d1c26  push r9
000078f8213d1c28  push r10
000078f8213d1c2a  push r11
000078f8213d1c2c  sub rsp, 0xF0
000078f8213d1c33  vmovaps [rsp], xmm0
000078f8213d1c38  vmovaps [rsp+0x10], xmm1
000078f8213d1c3e  vmovaps [rsp+0x20], xmm2
000078f8213d1c44  vmovaps [rsp+0x30], xmm3
000078f8213d1c4a  vmovaps [rsp+0x40], xmm4
000078f8213d1c50  vmovaps [rsp+0x50], xmm5
000078f8213d1c56  vmovaps [rsp+0x60], xmm6
000078f8213d1c5c  vmovaps [rsp+0x70], xmm7
000078f8213d1c62  vmovaps [rsp+0x80], xmm8
000078f8213d1c6b  vmovaps [rsp+0x90], xmm9
000078f8213d1c74  vmovaps [rsp+0xA0], xmm10
000078f8213d1c7d  vmovaps [rsp+0xB0], xmm11
000078f8213d1c86  vmovaps [rsp+0xC0], xmm12
000078f8213d1c8f  vmovaps [rsp+0xD0], xmm13
000078f8213d1c98  vmovaps [rsp+0xE0], xmm14
000078f8213d1ca1  sub rsp, 0x30
000078f8213d1ca5  movaps [rsp], xmm15
000078f8213d1caa  movaps [rsp+0x10], xmm13
000078f8213d1cb0  movaps [rsp+0x20], xmm1
000078f8213d1cb5  lea rdi, [rsp]
000078f8213d1cb9  mov esi, 0x00
000078f8213d1cbe  mov rax, 0x653D80F42530
000078f8213d1cc8  call rax
000078f8213d1cca  movaps xmm15, [rsp]
000078f8213d1ccf  add rsp, 0x30
000078f8213d1cd3  vmovaps xmm0, [rsp]
000078f8213d1cd8  vmovaps xmm1, [rsp+0x10]
000078f8213d1cde  vmovaps xmm2, [rsp+0x20]
000078f8213d1ce4  vmovaps xmm3, [rsp+0x30]
000078f8213d1cea  vmovaps xmm4, [rsp+0x40]
000078f8213d1cf0  vmovaps xmm5, [rsp+0x50]
000078f8213d1cf6  vmovaps xmm6, [rsp+0x60]
000078f8213d1cfc  vmovaps xmm7, [rsp+0x70]
000078f8213d1d02  vmovaps xmm8, [rsp+0x80]
000078f8213d1d0b  vmovaps xmm9, [rsp+0x90]
000078f8213d1d14  vmovaps xmm10, [rsp+0xA0]
000078f8213d1d1d  vmovaps xmm11, [rsp+0xB0]
000078f8213d1d26  vmovaps xmm12, [rsp+0xC0]
000078f8213d1d2f  vmovaps xmm13, [rsp+0xD0]
000078f8213d1d38  vmovaps xmm14, [rsp+0xE0]
000078f8213d1d41  add rsp, 0xF0
000078f8213d1d48  pop r11
000078f8213d1d4a  pop r10
000078f8213d1d4c  pop r9
000078f8213d1d4e  pop r8
000078f8213d1d50  pop rsi
000078f8213d1d51  pop rdi
000078f8213d1d52  pop rdx
000078f8213d1d53  pop rcx
000078f8213d1d54  pop rax
000078f8213d1d55  add rsp, 0x08
000078f8213d1d59  jmp 0x000078F8213CFAEB
000078f8213d1d5e  call 0x000078F8211FF430
000078f8213d1d63  jmp 0x000078F8213CFAF8
000078f8213d1d68  sub rsp, 0x08
000078f8213d1d6c  push rax
000078f8213d1d6d  push rcx
000078f8213d1d6e  push rdx
000078f8213d1d6f  push rdi
000078f8213d1d70  push rsi
000078f8213d1d71  push r8
000078f8213d1d73  push r9
000078f8213d1d75  push r10
000078f8213d1d77  push r11
000078f8213d1d79  sub rsp, 0xF0
000078f8213d1d80  vmovaps [rsp], xmm0
000078f8213d1d85  vmovaps [rsp+0x10], xmm1
000078f8213d1d8b  vmovaps [rsp+0x20], xmm2
000078f8213d1d91  vmovaps [rsp+0x30], xmm3
000078f8213d1d97  vmovaps [rsp+0x40], xmm4
000078f8213d1d9d  vmovaps [rsp+0x50], xmm5
000078f8213d1da3  vmovaps [rsp+0x60], xmm6
000078f8213d1da9  vmovaps [rsp+0x70], xmm7
000078f8213d1daf  vmovaps [rsp+0x80], xmm8
000078f8213d1db8  vmovaps [rsp+0x90], xmm9
000078f8213d1dc1  vmovaps [rsp+0xA0], xmm10
000078f8213d1dca  vmovaps [rsp+0xB0], xmm11
000078f8213d1dd3  vmovaps [rsp+0xC0], xmm12
000078f8213d1ddc  vmovaps [rsp+0xD0], xmm13
000078f8213d1de5  vmovaps [rsp+0xE0], xmm15
000078f8213d1dee  sub rsp, 0x30
000078f8213d1df2  movaps [rsp], xmm14
000078f8213d1df7  movaps [rsp+0x10], xmm13
000078f8213d1dfd  movaps [rsp+0x20], xmm2
000078f8213d1e02  lea rdi, [rsp]
000078f8213d1e06  mov esi, 0x00
000078f8213d1e0b  mov rax, 0x653D80F42530
000078f8213d1e15  call rax
000078f8213d1e17  movaps xmm14, [rsp]
000078f8213d1e1c  add rsp, 0x30
000078f8213d1e20  vmovaps xmm0, [rsp]
000078f8213d1e25  vmovaps xmm1, [rsp+0x10]
000078f8213d1e2b  vmovaps xmm2, [rsp+0x20]
000078f8213d1e31  vmovaps xmm3, [rsp+0x30]
000078f8213d1e37  vmovaps xmm4, [rsp+0x40]
000078f8213d1e3d  vmovaps xmm5, [rsp+0x50]
000078f8213d1e43  vmovaps xmm6, [rsp+0x60]
000078f8213d1e49  vmovaps xmm7, [rsp+0x70]
000078f8213d1e4f  vmovaps xmm8, [rsp+0x80]
000078f8213d1e58  vmovaps xmm9, [rsp+0x90]
000078f8213d1e61  vmovaps xmm10, [rsp+0xA0]
000078f8213d1e6a  vmovaps xmm11, [rsp+0xB0]
000078f8213d1e73  vmovaps xmm12, [rsp+0xC0]
000078f8213d1e7c  vmovaps xmm13, [rsp+0xD0]
000078f8213d1e85  vmovaps xmm15, [rsp+0xE0]
000078f8213d1e8e  add rsp, 0xF0
000078f8213d1e95  pop r11
000078f8213d1e97  pop r10
000078f8213d1e99  pop r9
000078f8213d1e9b  pop r8
000078f8213d1e9d  pop rsi
000078f8213d1e9e  pop rdi
000078f8213d1e9f  pop rdx
000078f8213d1ea0  pop rcx
000078f8213d1ea1  pop rax
000078f8213d1ea2  add rsp, 0x08
000078f8213d1ea6  jmp 0x000078F8213CFB24
000078f8213d1eab  sub rsp, 0x08
000078f8213d1eaf  push rax
000078f8213d1eb0  push rcx
000078f8213d1eb1  push rdx
000078f8213d1eb2  push rdi
000078f8213d1eb3  push rsi
000078f8213d1eb4  push r8
000078f8213d1eb6  push r9
000078f8213d1eb8  push r10
000078f8213d1eba  push r11
000078f8213d1ebc  sub rsp, 0xF0
000078f8213d1ec3  vmovaps [rsp], xmm0
000078f8213d1ec8  vmovaps [rsp+0x10], xmm2
000078f8213d1ece  vmovaps [rsp+0x20], xmm3
000078f8213d1ed4  vmovaps [rsp+0x30], xmm4
000078f8213d1eda  vmovaps [rsp+0x40], xmm5
000078f8213d1ee0  vmovaps [rsp+0x50], xmm6
000078f8213d1ee6  vmovaps [rsp+0x60], xmm7
000078f8213d1eec  vmovaps [rsp+0x70], xmm8
000078f8213d1ef2  vmovaps [rsp+0x80], xmm9
000078f8213d1efb  vmovaps [rsp+0x90], xmm10
000078f8213d1f04  vmovaps [rsp+0xA0], xmm11
000078f8213d1f0d  vmovaps [rsp+0xB0], xmm12
000078f8213d1f16  vmovaps [rsp+0xC0], xmm13
000078f8213d1f1f  vmovaps [rsp+0xD0], xmm14
000078f8213d1f28  vmovaps [rsp+0xE0], xmm15
000078f8213d1f31  sub rsp, 0x30
000078f8213d1f35  movaps [rsp], xmm1
000078f8213d1f39  movaps [rsp+0x10], xmm13
000078f8213d1f3f  movaps [rsp+0x20], xmm2
000078f8213d1f44  lea rdi, [rsp]
000078f8213d1f48  mov esi, 0x00
000078f8213d1f4d  mov rax, 0x653D80F42530
000078f8213d1f57  call rax
000078f8213d1f59  movaps xmm1, [rsp]
000078f8213d1f5d  add rsp, 0x30
000078f8213d1f61  vmovaps xmm0, [rsp]
000078f8213d1f66  vmovaps xmm2, [rsp+0x10]
000078f8213d1f6c  vmovaps xmm3, [rsp+0x20]
000078f8213d1f72  vmovaps xmm4, [rsp+0x30]
000078f8213d1f78  vmovaps xmm5, [rsp+0x40]
000078f8213d1f7e  vmovaps xmm6, [rsp+0x50]
000078f8213d1f84  vmovaps xmm7, [rsp+0x60]
000078f8213d1f8a  vmovaps xmm8, [rsp+0x70]
000078f8213d1f90  vmovaps xmm9, [rsp+0x80]
000078f8213d1f99  vmovaps xmm10, [rsp+0x90]
000078f8213d1fa2  vmovaps xmm11, [rsp+0xA0]
000078f8213d1fab  vmovaps xmm12, [rsp+0xB0]
000078f8213d1fb4  vmovaps xmm13, [rsp+0xC0]
000078f8213d1fbd  vmovaps xmm14, [rsp+0xD0]
000078f8213d1fc6  vmovaps xmm15, [rsp+0xE0]
000078f8213d1fcf  add rsp, 0xF0
000078f8213d1fd6  pop r11
000078f8213d1fd8  pop r10
000078f8213d1fda  pop r9
000078f8213d1fdc  pop r8
000078f8213d1fde  pop rsi
000078f8213d1fdf  pop rdi
000078f8213d1fe0  pop rdx
000078f8213d1fe1  pop rcx
000078f8213d1fe2  pop rax
000078f8213d1fe3  add rsp, 0x08
000078f8213d1fe7  jmp 0x000078F8213CFB52
000078f8213d1fec  sub rsp, 0x08
000078f8213d1ff0  push rax
000078f8213d1ff1  push rcx
000078f8213d1ff2  push rdx
000078f8213d1ff3  push rdi
000078f8213d1ff4  push rsi
000078f8213d1ff5  push r8
000078f8213d1ff7  push r9
000078f8213d1ff9  push r10
000078f8213d1ffb  push r11
000078f8213d1ffd  sub rsp, 0xF0
000078f8213d2004  vmovaps [rsp], xmm0
000078f8213d2009  vmovaps [rsp+0x10], xmm1
000078f8213d200f  vmovaps [rsp+0x20], xmm3
000078f8213d2015  vmovaps [rsp+0x30], xmm4
000078f8213d201b  vmovaps [rsp+0x40], xmm5
000078f8213d2021  vmovaps [rsp+0x50], xmm6
000078f8213d2027  vmovaps [rsp+0x60], xmm7
000078f8213d202d  vmovaps [rsp+0x70], xmm8
000078f8213d2033  vmovaps [rsp+0x80], xmm9
000078f8213d203c  vmovaps [rsp+0x90], xmm10
000078f8213d2045  vmovaps [rsp+0xA0], xmm11
000078f8213d204e  vmovaps [rsp+0xB0], xmm12
000078f8213d2057  vmovaps [rsp+0xC0], xmm13
000078f8213d2060  vmovaps [rsp+0xD0], xmm14
000078f8213d2069  vmovaps [rsp+0xE0], xmm15
000078f8213d2072  sub rsp, 0x30
000078f8213d2076  movaps [rsp], xmm2
000078f8213d207a  movaps [rsp+0x10], xmm1
000078f8213d207f  movaps [rsp+0x20], xmm13
000078f8213d2085  lea rdi, [rsp]
000078f8213d2089  mov esi, 0x00
000078f8213d208e  mov rax, 0x653D80F42530
000078f8213d2098  call rax
000078f8213d209a  movaps xmm2, [rsp]
000078f8213d209e  add rsp, 0x30
000078f8213d20a2  vmovaps xmm0, [rsp]
000078f8213d20a7  vmovaps xmm1, [rsp+0x10]
000078f8213d20ad  vmovaps xmm3, [rsp+0x20]
000078f8213d20b3  vmovaps xmm4, [rsp+0x30]
000078f8213d20b9  vmovaps xmm5, [rsp+0x40]
000078f8213d20bf  vmovaps xmm6, [rsp+0x50]
000078f8213d20c5  vmovaps xmm7, [rsp+0x60]
000078f8213d20cb  vmovaps xmm8, [rsp+0x70]
000078f8213d20d1  vmovaps xmm9, [rsp+0x80]
000078f8213d20da  vmovaps xmm10, [rsp+0x90]
000078f8213d20e3  vmovaps xmm11, [rsp+0xA0]
000078f8213d20ec  vmovaps xmm12, [rsp+0xB0]
000078f8213d20f5  vmovaps xmm13, [rsp+0xC0]
000078f8213d20fe  vmovaps xmm14, [rsp+0xD0]
000078f8213d2107  vmovaps xmm15, [rsp+0xE0]
000078f8213d2110  add rsp, 0xF0
000078f8213d2117  pop r11
000078f8213d2119  pop r10
000078f8213d211b  pop r9
000078f8213d211d  pop r8
000078f8213d211f  pop rsi
000078f8213d2120  pop rdi
000078f8213d2121  pop rdx
000078f8213d2122  pop rcx
000078f8213d2123  pop rax
000078f8213d2124  add rsp, 0x08
000078f8213d2128  jmp 0x000078F8213CFBAB
000078f8213d212d  call 0x000078F8211FF430
000078f8213d2132  jmp 0x000078F8213CFBB8
000078f8213d2137  sub rsp, 0x08
000078f8213d213b  push rax
000078f8213d213c  push rcx
000078f8213d213d  push rdx
000078f8213d213e  push rdi
000078f8213d213f  push rsi
000078f8213d2140  push r8
000078f8213d2142  push r9
000078f8213d2144  push r10
000078f8213d2146  push r11
000078f8213d2148  sub rsp, 0xF0
000078f8213d214f  vmovaps [rsp], xmm0
000078f8213d2154  vmovaps [rsp+0x10], xmm1
000078f8213d215a  vmovaps [rsp+0x20], xmm2
000078f8213d2160  vmovaps [rsp+0x30], xmm3
000078f8213d2166  vmovaps [rsp+0x40], xmm4
000078f8213d216c  vmovaps [rsp+0x50], xmm5
000078f8213d2172  vmovaps [rsp+0x60], xmm6
000078f8213d2178  vmovaps [rsp+0x70], xmm7
000078f8213d217e  vmovaps [rsp+0x80], xmm8
000078f8213d2187  vmovaps [rsp+0x90], xmm9
000078f8213d2190  vmovaps [rsp+0xA0], xmm10
000078f8213d2199  vmovaps [rsp+0xB0], xmm11
000078f8213d21a2  vmovaps [rsp+0xC0], xmm12
000078f8213d21ab  vmovaps [rsp+0xD0], xmm13
000078f8213d21b4  vmovaps [rsp+0xE0], xmm14
000078f8213d21bd  sub rsp, 0x30
000078f8213d21c1  movaps [rsp], xmm15
000078f8213d21c6  movaps [rsp+0x10], xmm13
000078f8213d21cc  movaps [rsp+0x20], xmm1
000078f8213d21d1  lea rdi, [rsp]
000078f8213d21d5  mov esi, 0x00
000078f8213d21da  mov rax, 0x653D80F42530
000078f8213d21e4  call rax
000078f8213d21e6  movaps xmm15, [rsp]
000078f8213d21eb  add rsp, 0x30
000078f8213d21ef  vmovaps xmm0, [rsp]
000078f8213d21f4  vmovaps xmm1, [rsp+0x10]
000078f8213d21fa  vmovaps xmm2, [rsp+0x20]
000078f8213d2200  vmovaps xmm3, [rsp+0x30]
000078f8213d2206  vmovaps xmm4, [rsp+0x40]
000078f8213d220c  vmovaps xmm5, [rsp+0x50]
000078f8213d2212  vmovaps xmm6, [rsp+0x60]
000078f8213d2218  vmovaps xmm7, [rsp+0x70]
000078f8213d221e  vmovaps xmm8, [rsp+0x80]
000078f8213d2227  vmovaps xmm9, [rsp+0x90]
000078f8213d2230  vmovaps xmm10, [rsp+0xA0]
000078f8213d2239  vmovaps xmm11, [rsp+0xB0]
000078f8213d2242  vmovaps xmm12, [rsp+0xC0]
000078f8213d224b  vmovaps xmm13, [rsp+0xD0]
000078f8213d2254  vmovaps xmm14, [rsp+0xE0]
000078f8213d225d  add rsp, 0xF0
000078f8213d2264  pop r11
000078f8213d2266  pop r10
000078f8213d2268  pop r9
000078f8213d226a  pop r8
000078f8213d226c  pop rsi
000078f8213d226d  pop rdi
000078f8213d226e  pop rdx
000078f8213d226f  pop rcx
000078f8213d2270  pop rax
000078f8213d2271  add rsp, 0x08
000078f8213d2275  jmp 0x000078F8213CFBF7
000078f8213d227a  sub rsp, 0x08
000078f8213d227e  push rax
000078f8213d227f  push rcx
000078f8213d2280  push rdx
000078f8213d2281  push rdi
000078f8213d2282  push rsi
000078f8213d2283  push r8
000078f8213d2285  push r9
000078f8213d2287  push r10
000078f8213d2289  push r11
000078f8213d228b  sub rsp, 0xF0
000078f8213d2292  vmovaps [rsp], xmm0
000078f8213d2297  vmovaps [rsp+0x10], xmm1
000078f8213d229d  vmovaps [rsp+0x20], xmm2
000078f8213d22a3  vmovaps [rsp+0x30], xmm3
000078f8213d22a9  vmovaps [rsp+0x40], xmm4
000078f8213d22af  vmovaps [rsp+0x50], xmm5
000078f8213d22b5  vmovaps [rsp+0x60], xmm6
000078f8213d22bb  vmovaps [rsp+0x70], xmm7
000078f8213d22c1  vmovaps [rsp+0x80], xmm8
000078f8213d22ca  vmovaps [rsp+0x90], xmm9
000078f8213d22d3  vmovaps [rsp+0xA0], xmm10
000078f8213d22dc  vmovaps [rsp+0xB0], xmm11
000078f8213d22e5  vmovaps [rsp+0xC0], xmm12
000078f8213d22ee  vmovaps [rsp+0xD0], xmm13
000078f8213d22f7  vmovaps [rsp+0xE0], xmm15
000078f8213d2300  sub rsp, 0x30
000078f8213d2304  movaps [rsp], xmm14
000078f8213d2309  movaps [rsp+0x10], xmm11
000078f8213d230f  movaps [rsp+0x20], xmm1
000078f8213d2314  lea rdi, [rsp]
000078f8213d2318  mov esi, 0x00
000078f8213d231d  mov rax, 0x653D80F42530
000078f8213d2327  call rax
000078f8213d2329  movaps xmm14, [rsp]
000078f8213d232e  add rsp, 0x30
000078f8213d2332  vmovaps xmm0, [rsp]
000078f8213d2337  vmovaps xmm1, [rsp+0x10]
000078f8213d233d  vmovaps xmm2, [rsp+0x20]
000078f8213d2343  vmovaps xmm3, [rsp+0x30]
000078f8213d2349  vmovaps xmm4, [rsp+0x40]
000078f8213d234f  vmovaps xmm5, [rsp+0x50]
000078f8213d2355  vmovaps xmm6, [rsp+0x60]
000078f8213d235b  vmovaps xmm7, [rsp+0x70]
000078f8213d2361  vmovaps xmm8, [rsp+0x80]
000078f8213d236a  vmovaps xmm9, [rsp+0x90]
000078f8213d2373  vmovaps xmm10, [rsp+0xA0]
000078f8213d237c  vmovaps xmm11, [rsp+0xB0]
000078f8213d2385  vmovaps xmm12, [rsp+0xC0]
000078f8213d238e  vmovaps xmm13, [rsp+0xD0]
000078f8213d2397  vmovaps xmm15, [rsp+0xE0]
000078f8213d23a0  add rsp, 0xF0
000078f8213d23a7  pop r11
000078f8213d23a9  pop r10
000078f8213d23ab  pop r9
000078f8213d23ad  pop r8
000078f8213d23af  pop rsi
000078f8213d23b0  pop rdi
000078f8213d23b1  pop rdx
000078f8213d23b2  pop rcx
000078f8213d23b3  pop rax
000078f8213d23b4  add rsp, 0x08
000078f8213d23b8  jmp 0x000078F8213CFC21
000078f8213d23bd  sub rsp, 0x08
000078f8213d23c1  push rax
000078f8213d23c2  push rcx
000078f8213d23c3  push rdx
000078f8213d23c4  push rdi
000078f8213d23c5  push rsi
000078f8213d23c6  push r8
000078f8213d23c8  push r9
000078f8213d23ca  push r10
000078f8213d23cc  push r11
000078f8213d23ce  sub rsp, 0xF0
000078f8213d23d5  vmovaps [rsp], xmm0
000078f8213d23da  vmovaps [rsp+0x10], xmm1
000078f8213d23e0  vmovaps [rsp+0x20], xmm2
000078f8213d23e6  vmovaps [rsp+0x30], xmm3
000078f8213d23ec  vmovaps [rsp+0x40], xmm4
000078f8213d23f2  vmovaps [rsp+0x50], xmm5
000078f8213d23f8  vmovaps [rsp+0x60], xmm6
000078f8213d23fe  vmovaps [rsp+0x70], xmm7
000078f8213d2404  vmovaps [rsp+0x80], xmm8
000078f8213d240d  vmovaps [rsp+0x90], xmm9
000078f8213d2416  vmovaps [rsp+0xA0], xmm10
000078f8213d241f  vmovaps [rsp+0xB0], xmm11
000078f8213d2428  vmovaps [rsp+0xC0], xmm12
000078f8213d2431  vmovaps [rsp+0xD0], xmm14
000078f8213d243a  vmovaps [rsp+0xE0], xmm15
000078f8213d2443  sub rsp, 0x30
000078f8213d2447  movaps [rsp], xmm13
000078f8213d244c  movaps [rsp+0x10], xmm11
000078f8213d2452  movaps [rsp+0x20], xmm1
000078f8213d2457  lea rdi, [rsp]
000078f8213d245b  mov esi, 0x00
000078f8213d2460  mov rax, 0x653D80F42530
000078f8213d246a  call rax
000078f8213d246c  movaps xmm13, [rsp]
000078f8213d2471  add rsp, 0x30
000078f8213d2475  vmovaps xmm0, [rsp]
000078f8213d247a  vmovaps xmm1, [rsp+0x10]
000078f8213d2480  vmovaps xmm2, [rsp+0x20]
000078f8213d2486  vmovaps xmm3, [rsp+0x30]
000078f8213d248c  vmovaps xmm4, [rsp+0x40]
000078f8213d2492  vmovaps xmm5, [rsp+0x50]
000078f8213d2498  vmovaps xmm6, [rsp+0x60]
000078f8213d249e  vmovaps xmm7, [rsp+0x70]
000078f8213d24a4  vmovaps xmm8, [rsp+0x80]
000078f8213d24ad  vmovaps xmm9, [rsp+0x90]
000078f8213d24b6  vmovaps xmm10, [rsp+0xA0]
000078f8213d24bf  vmovaps xmm11, [rsp+0xB0]
000078f8213d24c8  vmovaps xmm12, [rsp+0xC0]
000078f8213d24d1  vmovaps xmm14, [rsp+0xD0]
000078f8213d24da  vmovaps xmm15, [rsp+0xE0]
000078f8213d24e3  add rsp, 0xF0
000078f8213d24ea  pop r11
000078f8213d24ec  pop r10
000078f8213d24ee  pop r9
000078f8213d24f0  pop r8
000078f8213d24f2  pop rsi
000078f8213d24f3  pop rdi
000078f8213d24f4  pop rdx
000078f8213d24f5  pop rcx
000078f8213d24f6  pop rax
000078f8213d24f7  add rsp, 0x08
000078f8213d24fb  jmp 0x000078F8213CFC76
000078f8213d2500  call 0x000078F8211FF430
000078f8213d2505  jmp 0x000078F8213CFC83
000078f8213d250a  sub rsp, 0x08
000078f8213d250e  push rax
000078f8213d250f  push rcx
000078f8213d2510  push rdx
000078f8213d2511  push rdi
000078f8213d2512  push rsi
000078f8213d2513  push r8
000078f8213d2515  push r9
000078f8213d2517  push r10
000078f8213d2519  push r11
000078f8213d251b  sub rsp, 0xF0
000078f8213d2522  vmovaps [rsp], xmm0
000078f8213d2527  vmovaps [rsp+0x10], xmm1
000078f8213d252d  vmovaps [rsp+0x20], xmm2
000078f8213d2533  vmovaps [rsp+0x30], xmm3
000078f8213d2539  vmovaps [rsp+0x40], xmm4
000078f8213d253f  vmovaps [rsp+0x50], xmm5
000078f8213d2545  vmovaps [rsp+0x60], xmm6
000078f8213d254b  vmovaps [rsp+0x70], xmm7
000078f8213d2551  vmovaps [rsp+0x80], xmm8
000078f8213d255a  vmovaps [rsp+0x90], xmm9
000078f8213d2563  vmovaps [rsp+0xA0], xmm10
000078f8213d256c  vmovaps [rsp+0xB0], xmm11
000078f8213d2575  vmovaps [rsp+0xC0], xmm12
000078f8213d257e  vmovaps [rsp+0xD0], xmm13
000078f8213d2587  vmovaps [rsp+0xE0], xmm14
000078f8213d2590  sub rsp, 0x30
000078f8213d2594  movaps [rsp], xmm15
000078f8213d2599  movaps [rsp+0x10], xmm11
000078f8213d259f  movaps [rsp+0x20], xmm1
000078f8213d25a4  lea rdi, [rsp]
000078f8213d25a8  mov esi, 0x00
000078f8213d25ad  mov rax, 0x653D80F42530
000078f8213d25b7  call rax
000078f8213d25b9  movaps xmm15, [rsp]
000078f8213d25be  add rsp, 0x30
000078f8213d25c2  vmovaps xmm0, [rsp]
000078f8213d25c7  vmovaps xmm1, [rsp+0x10]
000078f8213d25cd  vmovaps xmm2, [rsp+0x20]
000078f8213d25d3  vmovaps xmm3, [rsp+0x30]
000078f8213d25d9  vmovaps xmm4, [rsp+0x40]
000078f8213d25df  vmovaps xmm5, [rsp+0x50]
000078f8213d25e5  vmovaps xmm6, [rsp+0x60]
000078f8213d25eb  vmovaps xmm7, [rsp+0x70]
000078f8213d25f1  vmovaps xmm8, [rsp+0x80]
000078f8213d25fa  vmovaps xmm9, [rsp+0x90]
000078f8213d2603  vmovaps xmm10, [rsp+0xA0]
000078f8213d260c  vmovaps xmm11, [rsp+0xB0]
000078f8213d2615  vmovaps xmm12, [rsp+0xC0]
000078f8213d261e  vmovaps xmm13, [rsp+0xD0]
000078f8213d2627  vmovaps xmm14, [rsp+0xE0]
000078f8213d2630  add rsp, 0xF0
000078f8213d2637  pop r11
000078f8213d2639  pop r10
000078f8213d263b  pop r9
000078f8213d263d  pop r8
000078f8213d263f  pop rsi
000078f8213d2640  pop rdi
000078f8213d2641  pop rdx
000078f8213d2642  pop rcx
000078f8213d2643  pop rax
000078f8213d2644  add rsp, 0x08
000078f8213d2648  jmp 0x000078F8213CFCBC
000078f8213d264d  sub rsp, 0x08
000078f8213d2651  push rax
000078f8213d2652  push rcx
000078f8213d2653  push rdx
000078f8213d2654  push rdi
000078f8213d2655  push rsi
000078f8213d2656  push r8
000078f8213d2658  push r9
000078f8213d265a  push r10
000078f8213d265c  push r11
000078f8213d265e  sub rsp, 0xF0
000078f8213d2665  vmovaps [rsp], xmm0
000078f8213d266a  vmovaps [rsp+0x10], xmm1
000078f8213d2670  vmovaps [rsp+0x20], xmm2
000078f8213d2676  vmovaps [rsp+0x30], xmm3
000078f8213d267c  vmovaps [rsp+0x40], xmm4
000078f8213d2682  vmovaps [rsp+0x50], xmm5
000078f8213d2688  vmovaps [rsp+0x60], xmm6
000078f8213d268e  vmovaps [rsp+0x70], xmm7
000078f8213d2694  vmovaps [rsp+0x80], xmm8
000078f8213d269d  vmovaps [rsp+0x90], xmm9
000078f8213d26a6  vmovaps [rsp+0xA0], xmm10
000078f8213d26af  vmovaps [rsp+0xB0], xmm12
000078f8213d26b8  vmovaps [rsp+0xC0], xmm13
000078f8213d26c1  vmovaps [rsp+0xD0], xmm14
000078f8213d26ca  vmovaps [rsp+0xE0], xmm15
000078f8213d26d3  sub rsp, 0x30
000078f8213d26d7  movaps [rsp], xmm11
000078f8213d26dc  movaps [rsp+0x10], xmm6
000078f8213d26e1  movaps [rsp+0x20], xmm14
000078f8213d26e7  lea rdi, [rsp]
000078f8213d26eb  mov esi, 0x00
000078f8213d26f0  mov rax, 0x653D80F42530
000078f8213d26fa  call rax
000078f8213d26fc  movaps xmm11, [rsp]
000078f8213d2701  add rsp, 0x30
000078f8213d2705  vmovaps xmm0, [rsp]
000078f8213d270a  vmovaps xmm1, [rsp+0x10]
000078f8213d2710  vmovaps xmm2, [rsp+0x20]
000078f8213d2716  vmovaps xmm3, [rsp+0x30]
000078f8213d271c  vmovaps xmm4, [rsp+0x40]
000078f8213d2722  vmovaps xmm5, [rsp+0x50]
000078f8213d2728  vmovaps xmm6, [rsp+0x60]
000078f8213d272e  vmovaps xmm7, [rsp+0x70]
000078f8213d2734  vmovaps xmm8, [rsp+0x80]
000078f8213d273d  vmovaps xmm9, [rsp+0x90]
000078f8213d2746  vmovaps xmm10, [rsp+0xA0]
000078f8213d274f  vmovaps xmm12, [rsp+0xB0]
000078f8213d2758  vmovaps xmm13, [rsp+0xC0]
000078f8213d2761  vmovaps xmm14, [rsp+0xD0]
000078f8213d276a  vmovaps xmm15, [rsp+0xE0]
000078f8213d2773  add rsp, 0xF0
000078f8213d277a  pop r11
000078f8213d277c  pop r10
000078f8213d277e  pop r9
000078f8213d2780  pop r8
000078f8213d2782  pop rsi
000078f8213d2783  pop rdi
000078f8213d2784  pop rdx
000078f8213d2785  pop rcx
000078f8213d2786  pop rax
000078f8213d2787  add rsp, 0x08
000078f8213d278b  jmp 0x000078F8213CFD34
000078f8213d2790  call 0x000078F8211FF430
000078f8213d2795  jmp 0x000078F8213CFD3E
000078f8213d279a  sub rsp, 0x08
000078f8213d279e  push rax
000078f8213d279f  push rcx
000078f8213d27a0  push rdx
000078f8213d27a1  push rdi
000078f8213d27a2  push rsi
000078f8213d27a3  push r8
000078f8213d27a5  push r9
000078f8213d27a7  push r10
000078f8213d27a9  push r11
000078f8213d27ab  sub rsp, 0xF0
000078f8213d27b2  vmovaps [rsp], xmm0
000078f8213d27b7  vmovaps [rsp+0x10], xmm1
000078f8213d27bd  vmovaps [rsp+0x20], xmm2
000078f8213d27c3  vmovaps [rsp+0x30], xmm3
000078f8213d27c9  vmovaps [rsp+0x40], xmm4
000078f8213d27cf  vmovaps [rsp+0x50], xmm5
000078f8213d27d5  vmovaps [rsp+0x60], xmm6
000078f8213d27db  vmovaps [rsp+0x70], xmm7
000078f8213d27e1  vmovaps [rsp+0x80], xmm8
000078f8213d27ea  vmovaps [rsp+0x90], xmm9
000078f8213d27f3  vmovaps [rsp+0xA0], xmm10
000078f8213d27fc  vmovaps [rsp+0xB0], xmm11
000078f8213d2805  vmovaps [rsp+0xC0], xmm12
000078f8213d280e  vmovaps [rsp+0xD0], xmm13
000078f8213d2817  vmovaps [rsp+0xE0], xmm15
000078f8213d2820  sub rsp, 0x30
000078f8213d2824  movaps [rsp], xmm14
000078f8213d2829  movaps [rsp+0x10], xmm6
000078f8213d282e  movaps [rsp+0x20], xmm2
000078f8213d2833  lea rdi, [rsp]
000078f8213d2837  mov esi, 0x00
000078f8213d283c  mov rax, 0x653D80F42530
000078f8213d2846  call rax
000078f8213d2848  movaps xmm14, [rsp]
000078f8213d284d  add rsp, 0x30
000078f8213d2851  vmovaps xmm0, [rsp]
000078f8213d2856  vmovaps xmm1, [rsp+0x10]
000078f8213d285c  vmovaps xmm2, [rsp+0x20]
000078f8213d2862  vmovaps xmm3, [rsp+0x30]
000078f8213d2868  vmovaps xmm4, [rsp+0x40]
000078f8213d286e  vmovaps xmm5, [rsp+0x50]
000078f8213d2874  vmovaps xmm6, [rsp+0x60]
000078f8213d287a  vmovaps xmm7, [rsp+0x70]
000078f8213d2880  vmovaps xmm8, [rsp+0x80]
000078f8213d2889  vmovaps xmm9, [rsp+0x90]
000078f8213d2892  vmovaps xmm10, [rsp+0xA0]
000078f8213d289b  vmovaps xmm11, [rsp+0xB0]
000078f8213d28a4  vmovaps xmm12, [rsp+0xC0]
000078f8213d28ad  vmovaps xmm13, [rsp+0xD0]
000078f8213d28b6  vmovaps xmm15, [rsp+0xE0]
000078f8213d28bf  add rsp, 0xF0
000078f8213d28c6  pop r11
000078f8213d28c8  pop r10
000078f8213d28ca  pop r9
000078f8213d28cc  pop r8
000078f8213d28ce  pop rsi
000078f8213d28cf  pop rdi
000078f8213d28d0  pop rdx
000078f8213d28d1  pop rcx
000078f8213d28d2  pop rax
000078f8213d28d3  add rsp, 0x08
000078f8213d28d7  jmp 0x000078F8213CFD72
000078f8213d28dc  sub rsp, 0x08
000078f8213d28e0  push rax
000078f8213d28e1  push rcx
000078f8213d28e2  push rdx
000078f8213d28e3  push rdi
000078f8213d28e4  push rsi
000078f8213d28e5  push r8
000078f8213d28e7  push r9
000078f8213d28e9  push r10
000078f8213d28eb  push r11
000078f8213d28ed  sub rsp, 0xF0
000078f8213d28f4  vmovaps [rsp], xmm0
000078f8213d28f9  vmovaps [rsp+0x10], xmm1
000078f8213d28ff  vmovaps [rsp+0x20], xmm2
000078f8213d2905  vmovaps [rsp+0x30], xmm3
000078f8213d290b  vmovaps [rsp+0x40], xmm4
000078f8213d2911  vmovaps [rsp+0x50], xmm5
000078f8213d2917  vmovaps [rsp+0x60], xmm7
000078f8213d291d  vmovaps [rsp+0x70], xmm8
000078f8213d2923  vmovaps [rsp+0x80], xmm9
000078f8213d292c  vmovaps [rsp+0x90], xmm10
000078f8213d2935  vmovaps [rsp+0xA0], xmm11
000078f8213d293e  vmovaps [rsp+0xB0], xmm12
000078f8213d2947  vmovaps [rsp+0xC0], xmm13
000078f8213d2950  vmovaps [rsp+0xD0], xmm14
000078f8213d2959  vmovaps [rsp+0xE0], xmm15
000078f8213d2962  sub rsp, 0x30
000078f8213d2966  movaps [rsp], xmm6
000078f8213d296a  movaps [rsp+0x10], xmm5
000078f8213d296f  movaps [rsp+0x20], xmm1
000078f8213d2974  lea rdi, [rsp]
000078f8213d2978  mov esi, 0x00
000078f8213d297d  mov rax, 0x653D80F42530
000078f8213d2987  call rax
000078f8213d2989  movaps xmm6, [rsp]
000078f8213d298d  add rsp, 0x30
000078f8213d2991  vmovaps xmm0, [rsp]
000078f8213d2996  vmovaps xmm1, [rsp+0x10]
000078f8213d299c  vmovaps xmm2, [rsp+0x20]
000078f8213d29a2  vmovaps xmm3, [rsp+0x30]
000078f8213d29a8  vmovaps xmm4, [rsp+0x40]
000078f8213d29ae  vmovaps xmm5, [rsp+0x50]
000078f8213d29b4  vmovaps xmm7, [rsp+0x60]
000078f8213d29ba  vmovaps xmm8, [rsp+0x70]
000078f8213d29c0  vmovaps xmm9, [rsp+0x80]
000078f8213d29c9  vmovaps xmm10, [rsp+0x90]
000078f8213d29d2  vmovaps xmm11, [rsp+0xA0]
000078f8213d29db  vmovaps xmm12, [rsp+0xB0]
000078f8213d29e4  vmovaps xmm13, [rsp+0xC0]
000078f8213d29ed  vmovaps xmm14, [rsp+0xD0]
000078f8213d29f6  vmovaps xmm15, [rsp+0xE0]
000078f8213d29ff  add rsp, 0xF0
000078f8213d2a06  pop r11
000078f8213d2a08  pop r10
000078f8213d2a0a  pop r9
000078f8213d2a0c  pop r8
000078f8213d2a0e  pop rsi
000078f8213d2a0f  pop rdi
000078f8213d2a10  pop rdx
000078f8213d2a11  pop rcx
000078f8213d2a12  pop rax
000078f8213d2a13  add rsp, 0x08
000078f8213d2a17  jmp 0x000078F8213CFD98
000078f8213d2a1c  sub rsp, 0x08
000078f8213d2a20  push rax
000078f8213d2a21  push rcx
000078f8213d2a22  push rdx
000078f8213d2a23  push rdi
000078f8213d2a24  push rsi
000078f8213d2a25  push r8
000078f8213d2a27  push r9
000078f8213d2a29  push r10
000078f8213d2a2b  push r11
000078f8213d2a2d  sub rsp, 0xF0
000078f8213d2a34  vmovaps [rsp], xmm0
000078f8213d2a39  vmovaps [rsp+0x10], xmm2
000078f8213d2a3f  vmovaps [rsp+0x20], xmm3
000078f8213d2a45  vmovaps [rsp+0x30], xmm4
000078f8213d2a4b  vmovaps [rsp+0x40], xmm5
000078f8213d2a51  vmovaps [rsp+0x50], xmm6
000078f8213d2a57  vmovaps [rsp+0x60], xmm7
000078f8213d2a5d  vmovaps [rsp+0x70], xmm8
000078f8213d2a63  vmovaps [rsp+0x80], xmm9
000078f8213d2a6c  vmovaps [rsp+0x90], xmm10
000078f8213d2a75  vmovaps [rsp+0xA0], xmm11
000078f8213d2a7e  vmovaps [rsp+0xB0], xmm12
000078f8213d2a87  vmovaps [rsp+0xC0], xmm13
000078f8213d2a90  vmovaps [rsp+0xD0], xmm14
000078f8213d2a99  vmovaps [rsp+0xE0], xmm15
000078f8213d2aa2  sub rsp, 0x30
000078f8213d2aa6  movaps [rsp], xmm1
000078f8213d2aaa  movaps [rsp+0x10], xmm5
000078f8213d2aaf  movaps [rsp+0x20], xmm13
000078f8213d2ab5  lea rdi, [rsp]
000078f8213d2ab9  mov esi, 0x00
000078f8213d2abe  mov rax, 0x653D80F42530
000078f8213d2ac8  call rax
000078f8213d2aca  movaps xmm1, [rsp]
000078f8213d2ace  add rsp, 0x30
000078f8213d2ad2  vmovaps xmm0, [rsp]
000078f8213d2ad7  vmovaps xmm2, [rsp+0x10]
000078f8213d2add  vmovaps xmm3, [rsp+0x20]
000078f8213d2ae3  vmovaps xmm4, [rsp+0x30]
000078f8213d2ae9  vmovaps xmm5, [rsp+0x40]
000078f8213d2aef  vmovaps xmm6, [rsp+0x50]
000078f8213d2af5  vmovaps xmm7, [rsp+0x60]
000078f8213d2afb  vmovaps xmm8, [rsp+0x70]
000078f8213d2b01  vmovaps xmm9, [rsp+0x80]
000078f8213d2b0a  vmovaps xmm10, [rsp+0x90]
000078f8213d2b13  vmovaps xmm11, [rsp+0xA0]
000078f8213d2b1c  vmovaps xmm12, [rsp+0xB0]
000078f8213d2b25  vmovaps xmm13, [rsp+0xC0]
000078f8213d2b2e  vmovaps xmm14, [rsp+0xD0]
000078f8213d2b37  vmovaps xmm15, [rsp+0xE0]
000078f8213d2b40  add rsp, 0xF0
000078f8213d2b47  pop r11
000078f8213d2b49  pop r10
000078f8213d2b4b  pop r9
000078f8213d2b4d  pop r8
000078f8213d2b4f  pop rsi
000078f8213d2b50  pop rdi
000078f8213d2b51  pop rdx
000078f8213d2b52  pop rcx
000078f8213d2b53  pop rax
000078f8213d2b54  add rsp, 0x08
000078f8213d2b58  jmp 0x000078F8213CFDB6
000078f8213d2b5d  sub rsp, 0x08
000078f8213d2b61  push rax
000078f8213d2b62  push rcx
000078f8213d2b63  push rdx
000078f8213d2b64  push rdi
000078f8213d2b65  push rsi
000078f8213d2b66  push r8
000078f8213d2b68  push r9
000078f8213d2b6a  push r10
000078f8213d2b6c  push r11
000078f8213d2b6e  sub rsp, 0xF0
000078f8213d2b75  vmovaps [rsp], xmm0
000078f8213d2b7a  vmovaps [rsp+0x10], xmm1
000078f8213d2b80  vmovaps [rsp+0x20], xmm2
000078f8213d2b86  vmovaps [rsp+0x30], xmm3
000078f8213d2b8c  vmovaps [rsp+0x40], xmm4
000078f8213d2b92  vmovaps [rsp+0x50], xmm6
000078f8213d2b98  vmovaps [rsp+0x60], xmm7
000078f8213d2b9e  vmovaps [rsp+0x70], xmm8
000078f8213d2ba4  vmovaps [rsp+0x80], xmm9
000078f8213d2bad  vmovaps [rsp+0x90], xmm10
000078f8213d2bb6  vmovaps [rsp+0xA0], xmm11
000078f8213d2bbf  vmovaps [rsp+0xB0], xmm12
000078f8213d2bc8  vmovaps [rsp+0xC0], xmm13
000078f8213d2bd1  vmovaps [rsp+0xD0], xmm14
000078f8213d2bda  vmovaps [rsp+0xE0], xmm15
000078f8213d2be3  sub rsp, 0x30
000078f8213d2be7  movaps [rsp], xmm5
000078f8213d2beb  movaps [rsp+0x10], xmm2
000078f8213d2bf0  movaps [rsp+0x20], xmm13
000078f8213d2bf6  lea rdi, [rsp]
000078f8213d2bfa  mov esi, 0x00
000078f8213d2bff  mov rax, 0x653D80F42530
000078f8213d2c09  call rax
000078f8213d2c0b  movaps xmm5, [rsp]
000078f8213d2c0f  add rsp, 0x30
000078f8213d2c13  vmovaps xmm0, [rsp]
000078f8213d2c18  vmovaps xmm1, [rsp+0x10]
000078f8213d2c1e  vmovaps xmm2, [rsp+0x20]
000078f8213d2c24  vmovaps xmm3, [rsp+0x30]
000078f8213d2c2a  vmovaps xmm4, [rsp+0x40]
000078f8213d2c30  vmovaps xmm6, [rsp+0x50]
000078f8213d2c36  vmovaps xmm7, [rsp+0x60]
000078f8213d2c3c  vmovaps xmm8, [rsp+0x70]
000078f8213d2c42  vmovaps xmm9, [rsp+0x80]
000078f8213d2c4b  vmovaps xmm10, [rsp+0x90]
000078f8213d2c54  vmovaps xmm11, [rsp+0xA0]
000078f8213d2c5d  vmovaps xmm12, [rsp+0xB0]
000078f8213d2c66  vmovaps xmm13, [rsp+0xC0]
000078f8213d2c6f  vmovaps xmm14, [rsp+0xD0]
000078f8213d2c78  vmovaps xmm15, [rsp+0xE0]
000078f8213d2c81  add rsp, 0xF0
000078f8213d2c88  pop r11
000078f8213d2c8a  pop r10
000078f8213d2c8c  pop r9
000078f8213d2c8e  pop r8
000078f8213d2c90  pop rsi
000078f8213d2c91  pop rdi
000078f8213d2c92  pop rdx
000078f8213d2c93  pop rcx
000078f8213d2c94  pop rax
000078f8213d2c95  add rsp, 0x08
000078f8213d2c99  jmp 0x000078F8213CFDEC
000078f8213d2c9e  sub rsp, 0x08
000078f8213d2ca2  push rax
000078f8213d2ca3  push rcx
000078f8213d2ca4  push rdx
000078f8213d2ca5  push rdi
000078f8213d2ca6  push rsi
000078f8213d2ca7  push r8
000078f8213d2ca9  push r9
000078f8213d2cab  push r10
000078f8213d2cad  push r11
000078f8213d2caf  sub rsp, 0xF0
000078f8213d2cb6  vmovaps [rsp], xmm0
000078f8213d2cbb  vmovaps [rsp+0x10], xmm1
000078f8213d2cc1  vmovaps [rsp+0x20], xmm2
000078f8213d2cc7  vmovaps [rsp+0x30], xmm3
000078f8213d2ccd  vmovaps [rsp+0x40], xmm4
000078f8213d2cd3  vmovaps [rsp+0x50], xmm5
000078f8213d2cd9  vmovaps [rsp+0x60], xmm6
000078f8213d2cdf  vmovaps [rsp+0x70], xmm7
000078f8213d2ce5  vmovaps [rsp+0x80], xmm8
000078f8213d2cee  vmovaps [rsp+0x90], xmm9
000078f8213d2cf7  vmovaps [rsp+0xA0], xmm10
000078f8213d2d00  vmovaps [rsp+0xB0], xmm11
000078f8213d2d09  vmovaps [rsp+0xC0], xmm12
000078f8213d2d12  vmovaps [rsp+0xD0], xmm14
000078f8213d2d1b  vmovaps [rsp+0xE0], xmm15
000078f8213d2d24  sub rsp, 0x30
000078f8213d2d28  movaps [rsp], xmm13
000078f8213d2d2d  movaps [rsp+0x10], xmm10
000078f8213d2d33  movaps [rsp+0x20], xmm1
000078f8213d2d38  lea rdi, [rsp]
000078f8213d2d3c  mov esi, 0x00
000078f8213d2d41  mov rax, 0x653D80F42530
000078f8213d2d4b  call rax
000078f8213d2d4d  movaps xmm13, [rsp]
000078f8213d2d52  add rsp, 0x30
000078f8213d2d56  vmovaps xmm0, [rsp]
000078f8213d2d5b  vmovaps xmm1, [rsp+0x10]
000078f8213d2d61  vmovaps xmm2, [rsp+0x20]
000078f8213d2d67  vmovaps xmm3, [rsp+0x30]
000078f8213d2d6d  vmovaps xmm4, [rsp+0x40]
000078f8213d2d73  vmovaps xmm5, [rsp+0x50]
000078f8213d2d79  vmovaps xmm6, [rsp+0x60]
000078f8213d2d7f  vmovaps xmm7, [rsp+0x70]
000078f8213d2d85  vmovaps xmm8, [rsp+0x80]
000078f8213d2d8e  vmovaps xmm9, [rsp+0x90]
000078f8213d2d97  vmovaps xmm10, [rsp+0xA0]
000078f8213d2da0  vmovaps xmm11, [rsp+0xB0]
000078f8213d2da9  vmovaps xmm12, [rsp+0xC0]
000078f8213d2db2  vmovaps xmm14, [rsp+0xD0]
000078f8213d2dbb  vmovaps xmm15, [rsp+0xE0]
000078f8213d2dc4  add rsp, 0xF0
000078f8213d2dcb  pop r11
000078f8213d2dcd  pop r10
000078f8213d2dcf  pop r9
000078f8213d2dd1  pop r8
000078f8213d2dd3  pop rsi
000078f8213d2dd4  pop rdi
000078f8213d2dd5  pop rdx
000078f8213d2dd6  pop rcx
000078f8213d2dd7  pop rax
000078f8213d2dd8  add rsp, 0x08
000078f8213d2ddc  jmp 0x000078F8213CFE15
000078f8213d2de1  sub rsp, 0x08
000078f8213d2de5  push rax
000078f8213d2de6  push rcx
000078f8213d2de7  push rdx
000078f8213d2de8  push rdi
000078f8213d2de9  push rsi
000078f8213d2dea  push r8
000078f8213d2dec  push r9
000078f8213d2dee  push r10
000078f8213d2df0  push r11
000078f8213d2df2  sub rsp, 0xF0
000078f8213d2df9  vmovaps [rsp], xmm0
000078f8213d2dfe  vmovaps [rsp+0x10], xmm2
000078f8213d2e04  vmovaps [rsp+0x20], xmm3
000078f8213d2e0a  vmovaps [rsp+0x30], xmm4
000078f8213d2e10  vmovaps [rsp+0x40], xmm5
000078f8213d2e16  vmovaps [rsp+0x50], xmm6
000078f8213d2e1c  vmovaps [rsp+0x60], xmm7
000078f8213d2e22  vmovaps [rsp+0x70], xmm8
000078f8213d2e28  vmovaps [rsp+0x80], xmm9
000078f8213d2e31  vmovaps [rsp+0x90], xmm10
000078f8213d2e3a  vmovaps [rsp+0xA0], xmm11
000078f8213d2e43  vmovaps [rsp+0xB0], xmm12
000078f8213d2e4c  vmovaps [rsp+0xC0], xmm13
000078f8213d2e55  vmovaps [rsp+0xD0], xmm14
000078f8213d2e5e  vmovaps [rsp+0xE0], xmm15
000078f8213d2e67  sub rsp, 0x30
000078f8213d2e6b  movaps [rsp], xmm1
000078f8213d2e6f  movaps [rsp+0x10], xmm15
000078f8213d2e75  movaps [rsp+0x20], xmm10
000078f8213d2e7b  lea rdi, [rsp]
000078f8213d2e7f  mov esi, 0x00
000078f8213d2e84  mov rax, 0x653D80F42530
000078f8213d2e8e  call rax
000078f8213d2e90  movaps xmm1, [rsp]
000078f8213d2e94  add rsp, 0x30
000078f8213d2e98  vmovaps xmm0, [rsp]
000078f8213d2e9d  vmovaps xmm2, [rsp+0x10]
000078f8213d2ea3  vmovaps xmm3, [rsp+0x20]
000078f8213d2ea9  vmovaps xmm4, [rsp+0x30]
000078f8213d2eaf  vmovaps xmm5, [rsp+0x40]
000078f8213d2eb5  vmovaps xmm6, [rsp+0x50]
000078f8213d2ebb  vmovaps xmm7, [rsp+0x60]
000078f8213d2ec1  vmovaps xmm8, [rsp+0x70]
000078f8213d2ec7  vmovaps xmm9, [rsp+0x80]
000078f8213d2ed0  vmovaps xmm10, [rsp+0x90]
000078f8213d2ed9  vmovaps xmm11, [rsp+0xA0]
000078f8213d2ee2  vmovaps xmm12, [rsp+0xB0]
000078f8213d2eeb  vmovaps xmm13, [rsp+0xC0]
000078f8213d2ef4  vmovaps xmm14, [rsp+0xD0]
000078f8213d2efd  vmovaps xmm15, [rsp+0xE0]
000078f8213d2f06  add rsp, 0xF0
000078f8213d2f0d  pop r11
000078f8213d2f0f  pop r10
000078f8213d2f11  pop r9
000078f8213d2f13  pop r8
000078f8213d2f15  pop rsi
000078f8213d2f16  pop rdi
000078f8213d2f17  pop rdx
000078f8213d2f18  pop rcx
000078f8213d2f19  pop rax
000078f8213d2f1a  add rsp, 0x08
000078f8213d2f1e  jmp 0x000078F8213CFE34
000078f8213d2f23  sub rsp, 0x08
000078f8213d2f27  push rax
000078f8213d2f28  push rcx
000078f8213d2f29  push rdx
000078f8213d2f2a  push rdi
000078f8213d2f2b  push rsi
000078f8213d2f2c  push r8
000078f8213d2f2e  push r9
000078f8213d2f30  push r10
000078f8213d2f32  push r11
000078f8213d2f34  sub rsp, 0xF0
000078f8213d2f3b  vmovaps [rsp], xmm0
000078f8213d2f40  vmovaps [rsp+0x10], xmm1
000078f8213d2f46  vmovaps [rsp+0x20], xmm2
000078f8213d2f4c  vmovaps [rsp+0x30], xmm3
000078f8213d2f52  vmovaps [rsp+0x40], xmm4
000078f8213d2f58  vmovaps [rsp+0x50], xmm5
000078f8213d2f5e  vmovaps [rsp+0x60], xmm6
000078f8213d2f64  vmovaps [rsp+0x70], xmm7
000078f8213d2f6a  vmovaps [rsp+0x80], xmm8
000078f8213d2f73  vmovaps [rsp+0x90], xmm9
000078f8213d2f7c  vmovaps [rsp+0xA0], xmm10
000078f8213d2f85  vmovaps [rsp+0xB0], xmm11
000078f8213d2f8e  vmovaps [rsp+0xC0], xmm12
000078f8213d2f97  vmovaps [rsp+0xD0], xmm13
000078f8213d2fa0  vmovaps [rsp+0xE0], xmm14
000078f8213d2fa9  sub rsp, 0x30
000078f8213d2fad  movaps [rsp], xmm15
000078f8213d2fb2  movaps [rsp+0x10], xmm10
000078f8213d2fb8  movaps [rsp+0x20], xmm11
000078f8213d2fbe  lea rdi, [rsp]
000078f8213d2fc2  mov esi, 0x00
000078f8213d2fc7  mov rax, 0x653D80F42530
000078f8213d2fd1  call rax
000078f8213d2fd3  movaps xmm15, [rsp]
000078f8213d2fd8  add rsp, 0x30
000078f8213d2fdc  vmovaps xmm0, [rsp]
000078f8213d2fe1  vmovaps xmm1, [rsp+0x10]
000078f8213d2fe7  vmovaps xmm2, [rsp+0x20]
000078f8213d2fed  vmovaps xmm3, [rsp+0x30]
000078f8213d2ff3  vmovaps xmm4, [rsp+0x40]
000078f8213d2ff9  vmovaps xmm5, [rsp+0x50]
000078f8213d2fff  vmovaps xmm6, [rsp+0x60]
000078f8213d3005  vmovaps xmm7, [rsp+0x70]
000078f8213d300b  vmovaps xmm8, [rsp+0x80]
000078f8213d3014  vmovaps xmm9, [rsp+0x90]
000078f8213d301d  vmovaps xmm10, [rsp+0xA0]
000078f8213d3026  vmovaps xmm11, [rsp+0xB0]
000078f8213d302f  vmovaps xmm12, [rsp+0xC0]
000078f8213d3038  vmovaps xmm13, [rsp+0xD0]
000078f8213d3041  vmovaps xmm14, [rsp+0xE0]
000078f8213d304a  add rsp, 0xF0
000078f8213d3051  pop r11
000078f8213d3053  pop r10
000078f8213d3055  pop r9
000078f8213d3057  pop r8
000078f8213d3059  pop rsi
000078f8213d305a  pop rdi
000078f8213d305b  pop rdx
000078f8213d305c  pop rcx
000078f8213d305d  pop rax
000078f8213d305e  add rsp, 0x08
000078f8213d3062  jmp 0x000078F8213CFE57
000078f8213d3067  sub rsp, 0x08
000078f8213d306b  push rax
000078f8213d306c  push rcx
000078f8213d306d  push rdx
000078f8213d306e  push rdi
000078f8213d306f  push rsi
000078f8213d3070  push r8
000078f8213d3072  push r9
000078f8213d3074  push r10
000078f8213d3076  push r11
000078f8213d3078  sub rsp, 0xF0
000078f8213d307f  vmovaps [rsp], xmm0
000078f8213d3084  vmovaps [rsp+0x10], xmm1
000078f8213d308a  vmovaps [rsp+0x20], xmm2
000078f8213d3090  vmovaps [rsp+0x30], xmm3
000078f8213d3096  vmovaps [rsp+0x40], xmm4
000078f8213d309c  vmovaps [rsp+0x50], xmm5
000078f8213d30a2  vmovaps [rsp+0x60], xmm6
000078f8213d30a8  vmovaps [rsp+0x70], xmm7
000078f8213d30ae  vmovaps [rsp+0x80], xmm8
000078f8213d30b7  vmovaps [rsp+0x90], xmm9
000078f8213d30c0  vmovaps [rsp+0xA0], xmm11
000078f8213d30c9  vmovaps [rsp+0xB0], xmm12
000078f8213d30d2  vmovaps [rsp+0xC0], xmm13
000078f8213d30db  vmovaps [rsp+0xD0], xmm14
000078f8213d30e4  vmovaps [rsp+0xE0], xmm15
000078f8213d30ed  sub rsp, 0x30
000078f8213d30f1  movaps [rsp], xmm10
000078f8213d30f6  movaps [rsp+0x10], xmm12
000078f8213d30fc  movaps [rsp+0x20], xmm11
000078f8213d3102  lea rdi, [rsp]
000078f8213d3106  mov esi, 0x00
000078f8213d310b  mov rax, 0x653D80F42530
000078f8213d3115  call rax
000078f8213d3117  movaps xmm10, [rsp]
000078f8213d311c  add rsp, 0x30
000078f8213d3120  vmovaps xmm0, [rsp]
000078f8213d3125  vmovaps xmm1, [rsp+0x10]
000078f8213d312b  vmovaps xmm2, [rsp+0x20]
000078f8213d3131  vmovaps xmm3, [rsp+0x30]
000078f8213d3137  vmovaps xmm4, [rsp+0x40]
000078f8213d313d  vmovaps xmm5, [rsp+0x50]
000078f8213d3143  vmovaps xmm6, [rsp+0x60]
000078f8213d3149  vmovaps xmm7, [rsp+0x70]
000078f8213d314f  vmovaps xmm8, [rsp+0x80]
000078f8213d3158  vmovaps xmm9, [rsp+0x90]
000078f8213d3161  vmovaps xmm11, [rsp+0xA0]
000078f8213d316a  vmovaps xmm12, [rsp+0xB0]
000078f8213d3173  vmovaps xmm13, [rsp+0xC0]
000078f8213d317c  vmovaps xmm14, [rsp+0xD0]
000078f8213d3185  vmovaps xmm15, [rsp+0xE0]
000078f8213d318e  add rsp, 0xF0
000078f8213d3195  pop r11
000078f8213d3197  pop r10
000078f8213d3199  pop r9
000078f8213d319b  pop r8
000078f8213d319d  pop rsi
000078f8213d319e  pop rdi
000078f8213d319f  pop rdx
000078f8213d31a0  pop rcx
000078f8213d31a1  pop rax
000078f8213d31a2  add rsp, 0x08
000078f8213d31a6  jmp 0x000078F8213CFE80
000078f8213d31ab  sub rsp, 0x08
000078f8213d31af  push rax
000078f8213d31b0  push rcx
000078f8213d31b1  push rdx
000078f8213d31b2  push rdi
000078f8213d31b3  push rsi
000078f8213d31b4  push r8
000078f8213d31b6  push r9
000078f8213d31b8  push r10
000078f8213d31ba  push r11
000078f8213d31bc  sub rsp, 0xF0
000078f8213d31c3  vmovaps [rsp], xmm0
000078f8213d31c8  vmovaps [rsp+0x10], xmm1
000078f8213d31ce  vmovaps [rsp+0x20], xmm2
000078f8213d31d4  vmovaps [rsp+0x30], xmm3
000078f8213d31da  vmovaps [rsp+0x40], xmm4
000078f8213d31e0  vmovaps [rsp+0x50], xmm5
000078f8213d31e6  vmovaps [rsp+0x60], xmm6
000078f8213d31ec  vmovaps [rsp+0x70], xmm7
000078f8213d31f2  vmovaps [rsp+0x80], xmm8
000078f8213d31fb  vmovaps [rsp+0x90], xmm9
000078f8213d3204  vmovaps [rsp+0xA0], xmm10
000078f8213d320d  vmovaps [rsp+0xB0], xmm12
000078f8213d3216  vmovaps [rsp+0xC0], xmm13
000078f8213d321f  vmovaps [rsp+0xD0], xmm14
000078f8213d3228  vmovaps [rsp+0xE0], xmm15
000078f8213d3231  sub rsp, 0x30
000078f8213d3235  movaps [rsp], xmm11
000078f8213d323a  movaps [rsp+0x10], xmm2
000078f8213d323f  movaps [rsp+0x20], xmm12
000078f8213d3245  lea rdi, [rsp]
000078f8213d3249  mov esi, 0x00
000078f8213d324e  mov rax, 0x653D80F42530
000078f8213d3258  call rax
000078f8213d325a  movaps xmm11, [rsp]
000078f8213d325f  add rsp, 0x30
000078f8213d3263  vmovaps xmm0, [rsp]
000078f8213d3268  vmovaps xmm1, [rsp+0x10]
000078f8213d326e  vmovaps xmm2, [rsp+0x20]
000078f8213d3274  vmovaps xmm3, [rsp+0x30]
000078f8213d327a  vmovaps xmm4, [rsp+0x40]
000078f8213d3280  vmovaps xmm5, [rsp+0x50]
000078f8213d3286  vmovaps xmm6, [rsp+0x60]
000078f8213d328c  vmovaps xmm7, [rsp+0x70]
000078f8213d3292  vmovaps xmm8, [rsp+0x80]
000078f8213d329b  vmovaps xmm9, [rsp+0x90]
000078f8213d32a4  vmovaps xmm10, [rsp+0xA0]
000078f8213d32ad  vmovaps xmm12, [rsp+0xB0]
000078f8213d32b6  vmovaps xmm13, [rsp+0xC0]
000078f8213d32bf  vmovaps xmm14, [rsp+0xD0]
000078f8213d32c8  vmovaps xmm15, [rsp+0xE0]
000078f8213d32d1  add rsp, 0xF0
000078f8213d32d8  pop r11
000078f8213d32da  pop r10
000078f8213d32dc  pop r9
000078f8213d32de  pop r8
000078f8213d32e0  pop rsi
000078f8213d32e1  pop rdi
000078f8213d32e2  pop rdx
000078f8213d32e3  pop rcx
000078f8213d32e4  pop rax
000078f8213d32e5  add rsp, 0x08
000078f8213d32e9  jmp 0x000078F8213CFEB8
000078f8213d32ee  sub rsp, 0x08
000078f8213d32f2  push rax
000078f8213d32f3  push rcx
000078f8213d32f4  push rdx
000078f8213d32f5  push rdi
000078f8213d32f6  push rsi
000078f8213d32f7  push r8
000078f8213d32f9  push r9
000078f8213d32fb  push r10
000078f8213d32fd  push r11
000078f8213d32ff  sub rsp, 0xF0
000078f8213d3306  vmovaps [rsp], xmm0
000078f8213d330b  vmovaps [rsp+0x10], xmm2
000078f8213d3311  vmovaps [rsp+0x20], xmm3
000078f8213d3317  vmovaps [rsp+0x30], xmm4
000078f8213d331d  vmovaps [rsp+0x40], xmm5
000078f8213d3323  vmovaps [rsp+0x50], xmm6
000078f8213d3329  vmovaps [rsp+0x60], xmm7
000078f8213d332f  vmovaps [rsp+0x70], xmm8
000078f8213d3335  vmovaps [rsp+0x80], xmm9
000078f8213d333e  vmovaps [rsp+0x90], xmm10
000078f8213d3347  vmovaps [rsp+0xA0], xmm11
000078f8213d3350  vmovaps [rsp+0xB0], xmm12
000078f8213d3359  vmovaps [rsp+0xC0], xmm13
000078f8213d3362  vmovaps [rsp+0xD0], xmm14
000078f8213d336b  vmovaps [rsp+0xE0], xmm15
000078f8213d3374  sub rsp, 0x30
000078f8213d3378  movaps [rsp], xmm1
000078f8213d337c  movaps [rsp+0x10], xmm14
000078f8213d3382  movaps [rsp+0x20], xmm6
000078f8213d3387  lea rdi, [rsp]
000078f8213d338b  mov esi, 0x00
000078f8213d3390  mov rax, 0x653D80F42530
000078f8213d339a  call rax
000078f8213d339c  movaps xmm1, [rsp]
000078f8213d33a0  add rsp, 0x30
000078f8213d33a4  vmovaps xmm0, [rsp]
000078f8213d33a9  vmovaps xmm2, [rsp+0x10]
000078f8213d33af  vmovaps xmm3, [rsp+0x20]
000078f8213d33b5  vmovaps xmm4, [rsp+0x30]
000078f8213d33bb  vmovaps xmm5, [rsp+0x40]
000078f8213d33c1  vmovaps xmm6, [rsp+0x50]
000078f8213d33c7  vmovaps xmm7, [rsp+0x60]
000078f8213d33cd  vmovaps xmm8, [rsp+0x70]
000078f8213d33d3  vmovaps xmm9, [rsp+0x80]
000078f8213d33dc  vmovaps xmm10, [rsp+0x90]
000078f8213d33e5  vmovaps xmm11, [rsp+0xA0]
000078f8213d33ee  vmovaps xmm12, [rsp+0xB0]
000078f8213d33f7  vmovaps xmm13, [rsp+0xC0]
000078f8213d3400  vmovaps xmm14, [rsp+0xD0]
000078f8213d3409  vmovaps xmm15, [rsp+0xE0]
000078f8213d3412  add rsp, 0xF0
000078f8213d3419  pop r11
000078f8213d341b  pop r10
000078f8213d341d  pop r9
000078f8213d341f  pop r8
000078f8213d3421  pop rsi
000078f8213d3422  pop rdi
000078f8213d3423  pop rdx
000078f8213d3424  pop rcx
000078f8213d3425  pop rax
000078f8213d3426  add rsp, 0x08
000078f8213d342a  jmp 0x000078F8213CFED1
000078f8213d342f  sub rsp, 0x08
000078f8213d3433  push rax
000078f8213d3434  push rcx
000078f8213d3435  push rdx
000078f8213d3436  push rdi
000078f8213d3437  push rsi
000078f8213d3438  push r8
000078f8213d343a  push r9
000078f8213d343c  push r10
000078f8213d343e  push r11
000078f8213d3440  sub rsp, 0xF0
000078f8213d3447  vmovaps [rsp], xmm0
000078f8213d344c  vmovaps [rsp+0x10], xmm1
000078f8213d3452  vmovaps [rsp+0x20], xmm2
000078f8213d3458  vmovaps [rsp+0x30], xmm3
000078f8213d345e  vmovaps [rsp+0x40], xmm4
000078f8213d3464  vmovaps [rsp+0x50], xmm5
000078f8213d346a  vmovaps [rsp+0x60], xmm6
000078f8213d3470  vmovaps [rsp+0x70], xmm7
000078f8213d3476  vmovaps [rsp+0x80], xmm8
000078f8213d347f  vmovaps [rsp+0x90], xmm9
000078f8213d3488  vmovaps [rsp+0xA0], xmm10
000078f8213d3491  vmovaps [rsp+0xB0], xmm11
000078f8213d349a  vmovaps [rsp+0xC0], xmm12
000078f8213d34a3  vmovaps [rsp+0xD0], xmm13
000078f8213d34ac  vmovaps [rsp+0xE0], xmm15
000078f8213d34b5  sub rsp, 0x30
000078f8213d34b9  movaps [rsp], xmm14
000078f8213d34be  movaps [rsp+0x10], xmm12
000078f8213d34c4  movaps [rsp+0x20], xmm5
000078f8213d34c9  lea rdi, [rsp]
000078f8213d34cd  mov esi, 0x00
000078f8213d34d2  mov rax, 0x653D80F42530
000078f8213d34dc  call rax
000078f8213d34de  movaps xmm14, [rsp]
000078f8213d34e3  add rsp, 0x30
000078f8213d34e7  vmovaps xmm0, [rsp]
000078f8213d34ec  vmovaps xmm1, [rsp+0x10]
000078f8213d34f2  vmovaps xmm2, [rsp+0x20]
000078f8213d34f8  vmovaps xmm3, [rsp+0x30]
000078f8213d34fe  vmovaps xmm4, [rsp+0x40]
000078f8213d3504  vmovaps xmm5, [rsp+0x50]
000078f8213d350a  vmovaps xmm6, [rsp+0x60]
000078f8213d3510  vmovaps xmm7, [rsp+0x70]
000078f8213d3516  vmovaps xmm8, [rsp+0x80]
000078f8213d351f  vmovaps xmm9, [rsp+0x90]
000078f8213d3528  vmovaps xmm10, [rsp+0xA0]
000078f8213d3531  vmovaps xmm11, [rsp+0xB0]
000078f8213d353a  vmovaps xmm12, [rsp+0xC0]
000078f8213d3543  vmovaps xmm13, [rsp+0xD0]
000078f8213d354c  vmovaps xmm15, [rsp+0xE0]
000078f8213d3555  add rsp, 0xF0
000078f8213d355c  pop r11
000078f8213d355e  pop r10
000078f8213d3560  pop r9
000078f8213d3562  pop r8
000078f8213d3564  pop rsi
000078f8213d3565  pop rdi
000078f8213d3566  pop rdx
000078f8213d3567  pop rcx
000078f8213d3568  pop rax
000078f8213d3569  add rsp, 0x08
000078f8213d356d  jmp 0x000078F8213CFEF1
000078f8213d3572  sub rsp, 0x08
000078f8213d3576  push rax
000078f8213d3577  push rcx
000078f8213d3578  push rdx
000078f8213d3579  push rdi
000078f8213d357a  push rsi
000078f8213d357b  push r8
000078f8213d357d  push r9
000078f8213d357f  push r10
000078f8213d3581  push r11
000078f8213d3583  sub rsp, 0xF0
000078f8213d358a  vmovaps [rsp], xmm0
000078f8213d358f  vmovaps [rsp+0x10], xmm1
000078f8213d3595  vmovaps [rsp+0x20], xmm2
000078f8213d359b  vmovaps [rsp+0x30], xmm3
000078f8213d35a1  vmovaps [rsp+0x40], xmm4
000078f8213d35a7  vmovaps [rsp+0x50], xmm5
000078f8213d35ad  vmovaps [rsp+0x60], xmm7
000078f8213d35b3  vmovaps [rsp+0x70], xmm8
000078f8213d35b9  vmovaps [rsp+0x80], xmm9
000078f8213d35c2  vmovaps [rsp+0x90], xmm10
000078f8213d35cb  vmovaps [rsp+0xA0], xmm11
000078f8213d35d4  vmovaps [rsp+0xB0], xmm12
000078f8213d35dd  vmovaps [rsp+0xC0], xmm13
000078f8213d35e6  vmovaps [rsp+0xD0], xmm14
000078f8213d35ef  vmovaps [rsp+0xE0], xmm15
000078f8213d35f8  sub rsp, 0x30
000078f8213d35fc  movaps [rsp], xmm6
000078f8213d3600  movaps [rsp+0x10], xmm9
000078f8213d3606  movaps [rsp+0x20], xmm12
000078f8213d360c  lea rdi, [rsp]
000078f8213d3610  mov esi, 0x00
000078f8213d3615  mov rax, 0x653D80F42530
000078f8213d361f  call rax
000078f8213d3621  movaps xmm6, [rsp]
000078f8213d3625  add rsp, 0x30
000078f8213d3629  vmovaps xmm0, [rsp]
000078f8213d362e  vmovaps xmm1, [rsp+0x10]
000078f8213d3634  vmovaps xmm2, [rsp+0x20]
000078f8213d363a  vmovaps xmm3, [rsp+0x30]
000078f8213d3640  vmovaps xmm4, [rsp+0x40]
000078f8213d3646  vmovaps xmm5, [rsp+0x50]
000078f8213d364c  vmovaps xmm7, [rsp+0x60]
000078f8213d3652  vmovaps xmm8, [rsp+0x70]
000078f8213d3658  vmovaps xmm9, [rsp+0x80]
000078f8213d3661  vmovaps xmm10, [rsp+0x90]
000078f8213d366a  vmovaps xmm11, [rsp+0xA0]
000078f8213d3673  vmovaps xmm12, [rsp+0xB0]
000078f8213d367c  vmovaps xmm13, [rsp+0xC0]
000078f8213d3685  vmovaps xmm14, [rsp+0xD0]
000078f8213d368e  vmovaps xmm15, [rsp+0xE0]
000078f8213d3697  add rsp, 0xF0
000078f8213d369e  pop r11
000078f8213d36a0  pop r10
000078f8213d36a2  pop r9
000078f8213d36a4  pop r8
000078f8213d36a6  pop rsi
000078f8213d36a7  pop rdi
000078f8213d36a8  pop rdx
000078f8213d36a9  pop rcx
000078f8213d36aa  pop rax
000078f8213d36ab  add rsp, 0x08
000078f8213d36af  jmp 0x000078F8213CFF19
000078f8213d36b4  sub rsp, 0x08
000078f8213d36b8  push rax
000078f8213d36b9  push rcx
000078f8213d36ba  push rdx
000078f8213d36bb  push rdi
000078f8213d36bc  push rsi
000078f8213d36bd  push r8
000078f8213d36bf  push r9
000078f8213d36c1  push r10
000078f8213d36c3  push r11
000078f8213d36c5  sub rsp, 0xF0
000078f8213d36cc  vmovaps [rsp], xmm0
000078f8213d36d1  vmovaps [rsp+0x10], xmm1
000078f8213d36d7  vmovaps [rsp+0x20], xmm2
000078f8213d36dd  vmovaps [rsp+0x30], xmm3
000078f8213d36e3  vmovaps [rsp+0x40], xmm4
000078f8213d36e9  vmovaps [rsp+0x50], xmm5
000078f8213d36ef  vmovaps [rsp+0x60], xmm6
000078f8213d36f5  vmovaps [rsp+0x70], xmm7
000078f8213d36fb  vmovaps [rsp+0x80], xmm8
000078f8213d3704  vmovaps [rsp+0x90], xmm9
000078f8213d370d  vmovaps [rsp+0xA0], xmm10
000078f8213d3716  vmovaps [rsp+0xB0], xmm11
000078f8213d371f  vmovaps [rsp+0xC0], xmm13
000078f8213d3728  vmovaps [rsp+0xD0], xmm14
000078f8213d3731  vmovaps [rsp+0xE0], xmm15
000078f8213d373a  sub rsp, 0x30
000078f8213d373e  movaps [rsp], xmm12
000078f8213d3743  movaps [rsp+0x10], xmm15
000078f8213d3749  movaps [rsp+0x20], xmm13
000078f8213d374f  lea rdi, [rsp]
000078f8213d3753  mov esi, 0x00
000078f8213d3758  mov rax, 0x653D80F42530
000078f8213d3762  call rax
000078f8213d3764  movaps xmm12, [rsp]
000078f8213d3769  add rsp, 0x30
000078f8213d376d  vmovaps xmm0, [rsp]
000078f8213d3772  vmovaps xmm1, [rsp+0x10]
000078f8213d3778  vmovaps xmm2, [rsp+0x20]
000078f8213d377e  vmovaps xmm3, [rsp+0x30]
000078f8213d3784  vmovaps xmm4, [rsp+0x40]
000078f8213d378a  vmovaps xmm5, [rsp+0x50]
000078f8213d3790  vmovaps xmm6, [rsp+0x60]
000078f8213d3796  vmovaps xmm7, [rsp+0x70]
000078f8213d379c  vmovaps xmm8, [rsp+0x80]
000078f8213d37a5  vmovaps xmm9, [rsp+0x90]
000078f8213d37ae  vmovaps xmm10, [rsp+0xA0]
000078f8213d37b7  vmovaps xmm11, [rsp+0xB0]
000078f8213d37c0  vmovaps xmm13, [rsp+0xC0]
000078f8213d37c9  vmovaps xmm14, [rsp+0xD0]
000078f8213d37d2  vmovaps xmm15, [rsp+0xE0]
000078f8213d37db  add rsp, 0xF0
000078f8213d37e2  pop r11
000078f8213d37e4  pop r10
000078f8213d37e6  pop r9
000078f8213d37e8  pop r8
000078f8213d37ea  pop rsi
000078f8213d37eb  pop rdi
000078f8213d37ec  pop rdx
000078f8213d37ed  pop rcx
000078f8213d37ee  pop rax
000078f8213d37ef  add rsp, 0x08
000078f8213d37f3  jmp 0x000078F8213CFF34
000078f8213d37f8  sub rsp, 0x08
000078f8213d37fc  push rax
000078f8213d37fd  push rcx
000078f8213d37fe  push rdx
000078f8213d37ff  push rdi
000078f8213d3800  push rsi
000078f8213d3801  push r8
000078f8213d3803  push r9
000078f8213d3805  push r10
000078f8213d3807  push r11
000078f8213d3809  sub rsp, 0xF0
000078f8213d3810  vmovaps [rsp], xmm0
000078f8213d3815  vmovaps [rsp+0x10], xmm1
000078f8213d381b  vmovaps [rsp+0x20], xmm2
000078f8213d3821  vmovaps [rsp+0x30], xmm3
000078f8213d3827  vmovaps [rsp+0x40], xmm4
000078f8213d382d  vmovaps [rsp+0x50], xmm5
000078f8213d3833  vmovaps [rsp+0x60], xmm6
000078f8213d3839  vmovaps [rsp+0x70], xmm7
000078f8213d383f  vmovaps [rsp+0x80], xmm8
000078f8213d3848  vmovaps [rsp+0x90], xmm9
000078f8213d3851  vmovaps [rsp+0xA0], xmm10
000078f8213d385a  vmovaps [rsp+0xB0], xmm11
000078f8213d3863  vmovaps [rsp+0xC0], xmm12
000078f8213d386c  vmovaps [rsp+0xD0], xmm13
000078f8213d3875  vmovaps [rsp+0xE0], xmm14
000078f8213d387e  sub rsp, 0x30
000078f8213d3882  movaps [rsp], xmm15
000078f8213d3887  movaps [rsp+0x10], xmm13
000078f8213d388d  movaps [rsp+0x20], xmm10
000078f8213d3893  lea rdi, [rsp]
000078f8213d3897  mov esi, 0x00
000078f8213d389c  mov rax, 0x653D80F42530
000078f8213d38a6  call rax
000078f8213d38a8  movaps xmm15, [rsp]
000078f8213d38ad  add rsp, 0x30
000078f8213d38b1  vmovaps xmm0, [rsp]
000078f8213d38b6  vmovaps xmm1, [rsp+0x10]
000078f8213d38bc  vmovaps xmm2, [rsp+0x20]
000078f8213d38c2  vmovaps xmm3, [rsp+0x30]
000078f8213d38c8  vmovaps xmm4, [rsp+0x40]
000078f8213d38ce  vmovaps xmm5, [rsp+0x50]
000078f8213d38d4  vmovaps xmm6, [rsp+0x60]
000078f8213d38da  vmovaps xmm7, [rsp+0x70]
000078f8213d38e0  vmovaps xmm8, [rsp+0x80]
000078f8213d38e9  vmovaps xmm9, [rsp+0x90]
000078f8213d38f2  vmovaps xmm10, [rsp+0xA0]
000078f8213d38fb  vmovaps xmm11, [rsp+0xB0]
000078f8213d3904  vmovaps xmm12, [rsp+0xC0]
000078f8213d390d  vmovaps xmm13, [rsp+0xD0]
000078f8213d3916  vmovaps xmm14, [rsp+0xE0]
000078f8213d391f  add rsp, 0xF0
000078f8213d3926  pop r11
000078f8213d3928  pop r10
000078f8213d392a  pop r9
000078f8213d392c  pop r8
000078f8213d392e  pop rsi
000078f8213d392f  pop rdi
000078f8213d3930  pop rdx
000078f8213d3931  pop rcx
000078f8213d3932  pop rax
000078f8213d3933  add rsp, 0x08
000078f8213d3937  jmp 0x000078F8213CFF55
000078f8213d393c  call 0x000078F82120C260
000078f8213d3941  jmp 0x000078F8213CFFB0
000078f8213d3946  sub rsp, 0x08
000078f8213d394a  push rax
000078f8213d394b  push rcx
000078f8213d394c  push rdx
000078f8213d394d  push rdi
000078f8213d394e  push rsi
000078f8213d394f  push r8
000078f8213d3951  push r9
000078f8213d3953  push r10
000078f8213d3955  push r11
000078f8213d3957  sub rsp, 0xF0
000078f8213d395e  vmovaps [rsp], xmm0
000078f8213d3963  vmovaps [rsp+0x10], xmm1
000078f8213d3969  vmovaps [rsp+0x20], xmm2
000078f8213d396f  vmovaps [rsp+0x30], xmm3
000078f8213d3975  vmovaps [rsp+0x40], xmm4
000078f8213d397b  vmovaps [rsp+0x50], xmm5
000078f8213d3981  vmovaps [rsp+0x60], xmm6
000078f8213d3987  vmovaps [rsp+0x70], xmm7
000078f8213d398d  vmovaps [rsp+0x80], xmm8
000078f8213d3996  vmovaps [rsp+0x90], xmm10
000078f8213d399f  vmovaps [rsp+0xA0], xmm11
000078f8213d39a8  vmovaps [rsp+0xB0], xmm12
000078f8213d39b1  vmovaps [rsp+0xC0], xmm13
000078f8213d39ba  vmovaps [rsp+0xD0], xmm14
000078f8213d39c3  vmovaps [rsp+0xE0], xmm15
000078f8213d39cc  sub rsp, 0x30
000078f8213d39d0  movaps [rsp], xmm9
000078f8213d39d5  movaps [rsp+0x10], xmm8
000078f8213d39db  movaps [rsp+0x20], xmm10
000078f8213d39e1  lea rdi, [rsp]
000078f8213d39e5  mov esi, 0x00
000078f8213d39ea  mov rax, 0x653D80F42530
000078f8213d39f4  call rax
000078f8213d39f6  movaps xmm9, [rsp]
000078f8213d39fb  add rsp, 0x30
000078f8213d39ff  vmovaps xmm0, [rsp]
000078f8213d3a04  vmovaps xmm1, [rsp+0x10]
000078f8213d3a0a  vmovaps xmm2, [rsp+0x20]
000078f8213d3a10  vmovaps xmm3, [rsp+0x30]
000078f8213d3a16  vmovaps xmm4, [rsp+0x40]
000078f8213d3a1c  vmovaps xmm5, [rsp+0x50]
000078f8213d3a22  vmovaps xmm6, [rsp+0x60]
000078f8213d3a28  vmovaps xmm7, [rsp+0x70]
000078f8213d3a2e  vmovaps xmm8, [rsp+0x80]
000078f8213d3a37  vmovaps xmm10, [rsp+0x90]
000078f8213d3a40  vmovaps xmm11, [rsp+0xA0]
000078f8213d3a49  vmovaps xmm12, [rsp+0xB0]
000078f8213d3a52  vmovaps xmm13, [rsp+0xC0]
000078f8213d3a5b  vmovaps xmm14, [rsp+0xD0]
000078f8213d3a64  vmovaps xmm15, [rsp+0xE0]
000078f8213d3a6d  add rsp, 0xF0
000078f8213d3a74  pop r11
000078f8213d3a76  pop r10
000078f8213d3a78  pop r9
000078f8213d3a7a  pop r8
000078f8213d3a7c  pop rsi
000078f8213d3a7d  pop rdi
000078f8213d3a7e  pop rdx
000078f8213d3a7f  pop rcx
000078f8213d3a80  pop rax
000078f8213d3a81  add rsp, 0x08
000078f8213d3a85  jmp 0x000078F8213CFFE1
000078f8213d3a8a  sub rsp, 0x08
000078f8213d3a8e  push rax
000078f8213d3a8f  push rcx
000078f8213d3a90  push rdx
000078f8213d3a91  push rdi
000078f8213d3a92  push rsi
000078f8213d3a93  push r8
000078f8213d3a95  push r9
000078f8213d3a97  push r10
000078f8213d3a99  push r11
000078f8213d3a9b  sub rsp, 0xF0
000078f8213d3aa2  vmovaps [rsp], xmm0
000078f8213d3aa7  vmovaps [rsp+0x10], xmm1
000078f8213d3aad  vmovaps [rsp+0x20], xmm2
000078f8213d3ab3  vmovaps [rsp+0x30], xmm3
000078f8213d3ab9  vmovaps [rsp+0x40], xmm4
000078f8213d3abf  vmovaps [rsp+0x50], xmm5
000078f8213d3ac5  vmovaps [rsp+0x60], xmm6
000078f8213d3acb  vmovaps [rsp+0x70], xmm7
000078f8213d3ad1  vmovaps [rsp+0x80], xmm8
000078f8213d3ada  vmovaps [rsp+0x90], xmm9
000078f8213d3ae3  vmovaps [rsp+0xA0], xmm11
000078f8213d3aec  vmovaps [rsp+0xB0], xmm12
000078f8213d3af5  vmovaps [rsp+0xC0], xmm13
000078f8213d3afe  vmovaps [rsp+0xD0], xmm14
000078f8213d3b07  vmovaps [rsp+0xE0], xmm15
000078f8213d3b10  sub rsp, 0x30
000078f8213d3b14  movaps [rsp], xmm10
000078f8213d3b19  movaps [rsp+0x10], xmm1
000078f8213d3b1e  movaps [rsp+0x20], xmm11
000078f8213d3b24  lea rdi, [rsp]
000078f8213d3b28  mov esi, 0x00
000078f8213d3b2d  mov rax, 0x653D80F42530
000078f8213d3b37  call rax
000078f8213d3b39  movaps xmm10, [rsp]
000078f8213d3b3e  add rsp, 0x30
000078f8213d3b42  vmovaps xmm0, [rsp]
000078f8213d3b47  vmovaps xmm1, [rsp+0x10]
000078f8213d3b4d  vmovaps xmm2, [rsp+0x20]
000078f8213d3b53  vmovaps xmm3, [rsp+0x30]
000078f8213d3b59  vmovaps xmm4, [rsp+0x40]
000078f8213d3b5f  vmovaps xmm5, [rsp+0x50]
000078f8213d3b65  vmovaps xmm6, [rsp+0x60]
000078f8213d3b6b  vmovaps xmm7, [rsp+0x70]
000078f8213d3b71  vmovaps xmm8, [rsp+0x80]
000078f8213d3b7a  vmovaps xmm9, [rsp+0x90]
000078f8213d3b83  vmovaps xmm11, [rsp+0xA0]
000078f8213d3b8c  vmovaps xmm12, [rsp+0xB0]
000078f8213d3b95  vmovaps xmm13, [rsp+0xC0]
000078f8213d3b9e  vmovaps xmm14, [rsp+0xD0]
000078f8213d3ba7  vmovaps xmm15, [rsp+0xE0]
000078f8213d3bb0  add rsp, 0xF0
000078f8213d3bb7  pop r11
000078f8213d3bb9  pop r10
000078f8213d3bbb  pop r9
000078f8213d3bbd  pop r8
000078f8213d3bbf  pop rsi
000078f8213d3bc0  pop rdi
000078f8213d3bc1  pop rdx
000078f8213d3bc2  pop rcx
000078f8213d3bc3  pop rax
000078f8213d3bc4  add rsp, 0x08
000078f8213d3bc8  jmp 0x000078F8213CFFFC
000078f8213d3bcd  sub rsp, 0x08
000078f8213d3bd1  push rax
000078f8213d3bd2  push rcx
000078f8213d3bd3  push rdx
000078f8213d3bd4  push rdi
000078f8213d3bd5  push rsi
000078f8213d3bd6  push r8
000078f8213d3bd8  push r9
000078f8213d3bda  push r10
000078f8213d3bdc  push r11
000078f8213d3bde  sub rsp, 0xF0
000078f8213d3be5  vmovaps [rsp], xmm0
000078f8213d3bea  vmovaps [rsp+0x10], xmm2
000078f8213d3bf0  vmovaps [rsp+0x20], xmm3
000078f8213d3bf6  vmovaps [rsp+0x30], xmm4
000078f8213d3bfc  vmovaps [rsp+0x40], xmm5
000078f8213d3c02  vmovaps [rsp+0x50], xmm6
000078f8213d3c08  vmovaps [rsp+0x60], xmm7
000078f8213d3c0e  vmovaps [rsp+0x70], xmm8
000078f8213d3c14  vmovaps [rsp+0x80], xmm9
000078f8213d3c1d  vmovaps [rsp+0x90], xmm10
000078f8213d3c26  vmovaps [rsp+0xA0], xmm11
000078f8213d3c2f  vmovaps [rsp+0xB0], xmm12
000078f8213d3c38  vmovaps [rsp+0xC0], xmm13
000078f8213d3c41  vmovaps [rsp+0xD0], xmm14
000078f8213d3c4a  vmovaps [rsp+0xE0], xmm15
000078f8213d3c53  sub rsp, 0x30
000078f8213d3c57  movaps [rsp], xmm1
000078f8213d3c5b  movaps [rsp+0x10], xmm14
000078f8213d3c61  movaps [rsp+0x20], xmm6
000078f8213d3c66  lea rdi, [rsp]
000078f8213d3c6a  mov esi, 0x00
000078f8213d3c6f  mov rax, 0x653D80F42530
000078f8213d3c79  call rax
000078f8213d3c7b  movaps xmm1, [rsp]
000078f8213d3c7f  add rsp, 0x30
000078f8213d3c83  vmovaps xmm0, [rsp]
000078f8213d3c88  vmovaps xmm2, [rsp+0x10]
000078f8213d3c8e  vmovaps xmm3, [rsp+0x20]
000078f8213d3c94  vmovaps xmm4, [rsp+0x30]
000078f8213d3c9a  vmovaps xmm5, [rsp+0x40]
000078f8213d3ca0  vmovaps xmm6, [rsp+0x50]
000078f8213d3ca6  vmovaps xmm7, [rsp+0x60]
000078f8213d3cac  vmovaps xmm8, [rsp+0x70]
000078f8213d3cb2  vmovaps xmm9, [rsp+0x80]
000078f8213d3cbb  vmovaps xmm10, [rsp+0x90]
000078f8213d3cc4  vmovaps xmm11, [rsp+0xA0]
000078f8213d3ccd  vmovaps xmm12, [rsp+0xB0]
000078f8213d3cd6  vmovaps xmm13, [rsp+0xC0]
000078f8213d3cdf  vmovaps xmm14, [rsp+0xD0]
000078f8213d3ce8  vmovaps xmm15, [rsp+0xE0]
000078f8213d3cf1  add rsp, 0xF0
000078f8213d3cf8  pop r11
000078f8213d3cfa  pop r10
000078f8213d3cfc  pop r9
000078f8213d3cfe  pop r8
000078f8213d3d00  pop rsi
000078f8213d3d01  pop rdi
000078f8213d3d02  pop rdx
000078f8213d3d03  pop rcx
000078f8213d3d04  pop rax
000078f8213d3d05  add rsp, 0x08
000078f8213d3d09  jmp 0x000078F8213D0015
000078f8213d3d0e  sub rsp, 0x08
000078f8213d3d12  push rax
000078f8213d3d13  push rcx
000078f8213d3d14  push rdx
000078f8213d3d15  push rdi
000078f8213d3d16  push rsi
000078f8213d3d17  push r8
000078f8213d3d19  push r9
000078f8213d3d1b  push r10
000078f8213d3d1d  push r11
000078f8213d3d1f  sub rsp, 0xF0
000078f8213d3d26  vmovaps [rsp], xmm0
000078f8213d3d2b  vmovaps [rsp+0x10], xmm1
000078f8213d3d31  vmovaps [rsp+0x20], xmm2
000078f8213d3d37  vmovaps [rsp+0x30], xmm3
000078f8213d3d3d  vmovaps [rsp+0x40], xmm4
000078f8213d3d43  vmovaps [rsp+0x50], xmm5
000078f8213d3d49  vmovaps [rsp+0x60], xmm6
000078f8213d3d4f  vmovaps [rsp+0x70], xmm7
000078f8213d3d55  vmovaps [rsp+0x80], xmm8
000078f8213d3d5e  vmovaps [rsp+0x90], xmm9
000078f8213d3d67  vmovaps [rsp+0xA0], xmm10
000078f8213d3d70  vmovaps [rsp+0xB0], xmm12
000078f8213d3d79  vmovaps [rsp+0xC0], xmm13
000078f8213d3d82  vmovaps [rsp+0xD0], xmm14
000078f8213d3d8b  vmovaps [rsp+0xE0], xmm15
000078f8213d3d94  sub rsp, 0x30
000078f8213d3d98  movaps [rsp], xmm11
000078f8213d3d9d  movaps [rsp+0x10], xmm13
000078f8213d3da3  movaps [rsp+0x20], xmm14
000078f8213d3da9  lea rdi, [rsp]
000078f8213d3dad  mov esi, 0x00
000078f8213d3db2  mov rax, 0x653D80F42530
000078f8213d3dbc  call rax
000078f8213d3dbe  movaps xmm11, [rsp]
000078f8213d3dc3  add rsp, 0x30
000078f8213d3dc7  vmovaps xmm0, [rsp]
000078f8213d3dcc  vmovaps xmm1, [rsp+0x10]
000078f8213d3dd2  vmovaps xmm2, [rsp+0x20]
000078f8213d3dd8  vmovaps xmm3, [rsp+0x30]
000078f8213d3dde  vmovaps xmm4, [rsp+0x40]
000078f8213d3de4  vmovaps xmm5, [rsp+0x50]
000078f8213d3dea  vmovaps xmm6, [rsp+0x60]
000078f8213d3df0  vmovaps xmm7, [rsp+0x70]
000078f8213d3df6  vmovaps xmm8, [rsp+0x80]
000078f8213d3dff  vmovaps xmm9, [rsp+0x90]
000078f8213d3e08  vmovaps xmm10, [rsp+0xA0]
000078f8213d3e11  vmovaps xmm12, [rsp+0xB0]
000078f8213d3e1a  vmovaps xmm13, [rsp+0xC0]
000078f8213d3e23  vmovaps xmm14, [rsp+0xD0]
000078f8213d3e2c  vmovaps xmm15, [rsp+0xE0]
000078f8213d3e35  add rsp, 0xF0
000078f8213d3e3c  pop r11
000078f8213d3e3e  pop r10
000078f8213d3e40  pop r9
000078f8213d3e42  pop r8
000078f8213d3e44  pop rsi
000078f8213d3e45  pop rdi
000078f8213d3e46  pop rdx
000078f8213d3e47  pop rcx
000078f8213d3e48  pop rax
000078f8213d3e49  add rsp, 0x08
000078f8213d3e4d  jmp 0x000078F8213D003F
000078f8213d3e52  sub rsp, 0x08
000078f8213d3e56  push rax
000078f8213d3e57  push rcx
000078f8213d3e58  push rdx
000078f8213d3e59  push rdi
000078f8213d3e5a  push rsi
000078f8213d3e5b  push r8
000078f8213d3e5d  push r9
000078f8213d3e5f  push r10
000078f8213d3e61  push r11
000078f8213d3e63  sub rsp, 0xF0
000078f8213d3e6a  vmovaps [rsp], xmm0
000078f8213d3e6f  vmovaps [rsp+0x10], xmm1
000078f8213d3e75  vmovaps [rsp+0x20], xmm2
000078f8213d3e7b  vmovaps [rsp+0x30], xmm3
000078f8213d3e81  vmovaps [rsp+0x40], xmm4
000078f8213d3e87  vmovaps [rsp+0x50], xmm5
000078f8213d3e8d  vmovaps [rsp+0x60], xmm6
000078f8213d3e93  vmovaps [rsp+0x70], xmm7
000078f8213d3e99  vmovaps [rsp+0x80], xmm8
000078f8213d3ea2  vmovaps [rsp+0x90], xmm9
000078f8213d3eab  vmovaps [rsp+0xA0], xmm10
000078f8213d3eb4  vmovaps [rsp+0xB0], xmm11
000078f8213d3ebd  vmovaps [rsp+0xC0], xmm12
000078f8213d3ec6  vmovaps [rsp+0xD0], xmm14
000078f8213d3ecf  vmovaps [rsp+0xE0], xmm15
000078f8213d3ed8  sub rsp, 0x30
000078f8213d3edc  movaps [rsp], xmm13
000078f8213d3ee1  movaps [rsp+0x10], xmm8
000078f8213d3ee7  movaps [rsp+0x20], xmm14
000078f8213d3eed  lea rdi, [rsp]
000078f8213d3ef1  mov esi, 0x00
000078f8213d3ef6  mov rax, 0x653D80F42530
000078f8213d3f00  call rax
000078f8213d3f02  movaps xmm13, [rsp]
000078f8213d3f07  add rsp, 0x30
000078f8213d3f0b  vmovaps xmm0, [rsp]
000078f8213d3f10  vmovaps xmm1, [rsp+0x10]
000078f8213d3f16  vmovaps xmm2, [rsp+0x20]
000078f8213d3f1c  vmovaps xmm3, [rsp+0x30]
000078f8213d3f22  vmovaps xmm4, [rsp+0x40]
000078f8213d3f28  vmovaps xmm5, [rsp+0x50]
000078f8213d3f2e  vmovaps xmm6, [rsp+0x60]
000078f8213d3f34  vmovaps xmm7, [rsp+0x70]
000078f8213d3f3a  vmovaps xmm8, [rsp+0x80]
000078f8213d3f43  vmovaps xmm9, [rsp+0x90]
000078f8213d3f4c  vmovaps xmm10, [rsp+0xA0]
000078f8213d3f55  vmovaps xmm11, [rsp+0xB0]
000078f8213d3f5e  vmovaps xmm12, [rsp+0xC0]
000078f8213d3f67  vmovaps xmm14, [rsp+0xD0]
000078f8213d3f70  vmovaps xmm15, [rsp+0xE0]
000078f8213d3f79  add rsp, 0xF0
000078f8213d3f80  pop r11
000078f8213d3f82  pop r10
000078f8213d3f84  pop r9
000078f8213d3f86  pop r8
000078f8213d3f88  pop rsi
000078f8213d3f89  pop rdi
000078f8213d3f8a  pop rdx
000078f8213d3f8b  pop rcx
000078f8213d3f8c  pop rax
000078f8213d3f8d  add rsp, 0x08
000078f8213d3f91  jmp 0x000078F8213D006E
000078f8213d3f96  sub rsp, 0x08
000078f8213d3f9a  push rax
000078f8213d3f9b  push rcx
000078f8213d3f9c  push rdx
000078f8213d3f9d  push rdi
000078f8213d3f9e  push rsi
000078f8213d3f9f  push r8
000078f8213d3fa1  push r9
000078f8213d3fa3  push r10
000078f8213d3fa5  push r11
000078f8213d3fa7  sub rsp, 0xF0
000078f8213d3fae  vmovaps [rsp], xmm0
000078f8213d3fb3  vmovaps [rsp+0x10], xmm1
000078f8213d3fb9  vmovaps [rsp+0x20], xmm2
000078f8213d3fbf  vmovaps [rsp+0x30], xmm3
000078f8213d3fc5  vmovaps [rsp+0x40], xmm4
000078f8213d3fcb  vmovaps [rsp+0x50], xmm5
000078f8213d3fd1  vmovaps [rsp+0x60], xmm6
000078f8213d3fd7  vmovaps [rsp+0x70], xmm7
000078f8213d3fdd  vmovaps [rsp+0x80], xmm9
000078f8213d3fe6  vmovaps [rsp+0x90], xmm10
000078f8213d3fef  vmovaps [rsp+0xA0], xmm11
000078f8213d3ff8  vmovaps [rsp+0xB0], xmm12
000078f8213d4001  vmovaps [rsp+0xC0], xmm13
000078f8213d400a  vmovaps [rsp+0xD0], xmm14
000078f8213d4013  vmovaps [rsp+0xE0], xmm15
000078f8213d401c  sub rsp, 0x30
000078f8213d4020  movaps [rsp], xmm8
000078f8213d4025  movaps [rsp+0x10], xmm7
000078f8213d402a  movaps [rsp+0x20], xmm14
000078f8213d4030  lea rdi, [rsp]
000078f8213d4034  mov esi, 0x00
000078f8213d4039  mov rax, 0x653D80F42530
000078f8213d4043  call rax
000078f8213d4045  movaps xmm8, [rsp]
000078f8213d404a  add rsp, 0x30
000078f8213d404e  vmovaps xmm0, [rsp]
000078f8213d4053  vmovaps xmm1, [rsp+0x10]
000078f8213d4059  vmovaps xmm2, [rsp+0x20]
000078f8213d405f  vmovaps xmm3, [rsp+0x30]
000078f8213d4065  vmovaps xmm4, [rsp+0x40]
000078f8213d406b  vmovaps xmm5, [rsp+0x50]
000078f8213d4071  vmovaps xmm6, [rsp+0x60]
000078f8213d4077  vmovaps xmm7, [rsp+0x70]
000078f8213d407d  vmovaps xmm9, [rsp+0x80]
000078f8213d4086  vmovaps xmm10, [rsp+0x90]
000078f8213d408f  vmovaps xmm11, [rsp+0xA0]
000078f8213d4098  vmovaps xmm12, [rsp+0xB0]
000078f8213d40a1  vmovaps xmm13, [rsp+0xC0]
000078f8213d40aa  vmovaps xmm14, [rsp+0xD0]
000078f8213d40b3  vmovaps xmm15, [rsp+0xE0]
000078f8213d40bc  add rsp, 0xF0
000078f8213d40c3  pop r11
000078f8213d40c5  pop r10
000078f8213d40c7  pop r9
000078f8213d40c9  pop r8
000078f8213d40cb  pop rsi
000078f8213d40cc  pop rdi
000078f8213d40cd  pop rdx
000078f8213d40ce  pop rcx
000078f8213d40cf  pop rax
000078f8213d40d0  add rsp, 0x08
000078f8213d40d4  jmp 0x000078F8213D0094
000078f8213d40d9  sub rsp, 0x08
000078f8213d40dd  push rax
000078f8213d40de  push rcx
000078f8213d40df  push rdx
000078f8213d40e0  push rdi
000078f8213d40e1  push rsi
000078f8213d40e2  push r8
000078f8213d40e4  push r9
000078f8213d40e6  push r10
000078f8213d40e8  push r11
000078f8213d40ea  sub rsp, 0xF0
000078f8213d40f1  vmovaps [rsp], xmm0
000078f8213d40f6  vmovaps [rsp+0x10], xmm1
000078f8213d40fc  vmovaps [rsp+0x20], xmm2
000078f8213d4102  vmovaps [rsp+0x30], xmm3
000078f8213d4108  vmovaps [rsp+0x40], xmm4
000078f8213d410e  vmovaps [rsp+0x50], xmm5
000078f8213d4114  vmovaps [rsp+0x60], xmm6
000078f8213d411a  vmovaps [rsp+0x70], xmm7
000078f8213d4120  vmovaps [rsp+0x80], xmm8
000078f8213d4129  vmovaps [rsp+0x90], xmm9
000078f8213d4132  vmovaps [rsp+0xA0], xmm10
000078f8213d413b  vmovaps [rsp+0xB0], xmm11
000078f8213d4144  vmovaps [rsp+0xC0], xmm12
000078f8213d414d  vmovaps [rsp+0xD0], xmm13
000078f8213d4156  vmovaps [rsp+0xE0], xmm15
000078f8213d415f  sub rsp, 0x30
000078f8213d4163  movaps [rsp], xmm14
000078f8213d4168  movaps [rsp+0x10], xmm12
000078f8213d416e  movaps [rsp+0x20], xmm9
000078f8213d4174  lea rdi, [rsp]
000078f8213d4178  mov esi, 0x00
000078f8213d417d  mov rax, 0x653D80F42530
000078f8213d4187  call rax
000078f8213d4189  movaps xmm14, [rsp]
000078f8213d418e  add rsp, 0x30
000078f8213d4192  vmovaps xmm0, [rsp]
000078f8213d4197  vmovaps xmm1, [rsp+0x10]
000078f8213d419d  vmovaps xmm2, [rsp+0x20]
000078f8213d41a3  vmovaps xmm3, [rsp+0x30]
000078f8213d41a9  vmovaps xmm4, [rsp+0x40]
000078f8213d41af  vmovaps xmm5, [rsp+0x50]
000078f8213d41b5  vmovaps xmm6, [rsp+0x60]
000078f8213d41bb  vmovaps xmm7, [rsp+0x70]
000078f8213d41c1  vmovaps xmm8, [rsp+0x80]
000078f8213d41ca  vmovaps xmm9, [rsp+0x90]
000078f8213d41d3  vmovaps xmm10, [rsp+0xA0]
000078f8213d41dc  vmovaps xmm11, [rsp+0xB0]
000078f8213d41e5  vmovaps xmm12, [rsp+0xC0]
000078f8213d41ee  vmovaps xmm13, [rsp+0xD0]
000078f8213d41f7  vmovaps xmm15, [rsp+0xE0]
000078f8213d4200  add rsp, 0xF0
000078f8213d4207  pop r11
000078f8213d4209  pop r10
000078f8213d420b  pop r9
000078f8213d420d  pop r8
000078f8213d420f  pop rsi
000078f8213d4210  pop rdi
000078f8213d4211  pop rdx
000078f8213d4212  pop rcx
000078f8213d4213  pop rax
000078f8213d4214  add rsp, 0x08
000078f8213d4218  jmp 0x000078F8213D00AE
000078f8213d421d  sub rsp, 0x08
000078f8213d4221  push rax
000078f8213d4222  push rcx
000078f8213d4223  push rdx
000078f8213d4224  push rdi
000078f8213d4225  push rsi
000078f8213d4226  push r8
000078f8213d4228  push r9
000078f8213d422a  push r10
000078f8213d422c  push r11
000078f8213d422e  sub rsp, 0xF0
000078f8213d4235  vmovaps [rsp], xmm0
000078f8213d423a  vmovaps [rsp+0x10], xmm1
000078f8213d4240  vmovaps [rsp+0x20], xmm2
000078f8213d4246  vmovaps [rsp+0x30], xmm3
000078f8213d424c  vmovaps [rsp+0x40], xmm4
000078f8213d4252  vmovaps [rsp+0x50], xmm5
000078f8213d4258  vmovaps [rsp+0x60], xmm6
000078f8213d425e  vmovaps [rsp+0x70], xmm7
000078f8213d4264  vmovaps [rsp+0x80], xmm8
000078f8213d426d  vmovaps [rsp+0x90], xmm10
000078f8213d4276  vmovaps [rsp+0xA0], xmm11
000078f8213d427f  vmovaps [rsp+0xB0], xmm12
000078f8213d4288  vmovaps [rsp+0xC0], xmm13
000078f8213d4291  vmovaps [rsp+0xD0], xmm14
000078f8213d429a  vmovaps [rsp+0xE0], xmm15
000078f8213d42a3  sub rsp, 0x30
000078f8213d42a7  movaps [rsp], xmm9
000078f8213d42ac  movaps [rsp+0x10], xmm7
000078f8213d42b1  movaps [rsp+0x20], xmm12
000078f8213d42b7  lea rdi, [rsp]
000078f8213d42bb  mov esi, 0x00
000078f8213d42c0  mov rax, 0x653D80F42530
000078f8213d42ca  call rax
000078f8213d42cc  movaps xmm9, [rsp]
000078f8213d42d1  add rsp, 0x30
000078f8213d42d5  vmovaps xmm0, [rsp]
000078f8213d42da  vmovaps xmm1, [rsp+0x10]
000078f8213d42e0  vmovaps xmm2, [rsp+0x20]
000078f8213d42e6  vmovaps xmm3, [rsp+0x30]
000078f8213d42ec  vmovaps xmm4, [rsp+0x40]
000078f8213d42f2  vmovaps xmm5, [rsp+0x50]
000078f8213d42f8  vmovaps xmm6, [rsp+0x60]
000078f8213d42fe  vmovaps xmm7, [rsp+0x70]
000078f8213d4304  vmovaps xmm8, [rsp+0x80]
000078f8213d430d  vmovaps xmm10, [rsp+0x90]
000078f8213d4316  vmovaps xmm11, [rsp+0xA0]
000078f8213d431f  vmovaps xmm12, [rsp+0xB0]
000078f8213d4328  vmovaps xmm13, [rsp+0xC0]
000078f8213d4331  vmovaps xmm14, [rsp+0xD0]
000078f8213d433a  vmovaps xmm15, [rsp+0xE0]
000078f8213d4343  add rsp, 0xF0
000078f8213d434a  pop r11
000078f8213d434c  pop r10
000078f8213d434e  pop r9
000078f8213d4350  pop r8
000078f8213d4352  pop rsi
000078f8213d4353  pop rdi
000078f8213d4354  pop rdx
000078f8213d4355  pop rcx
000078f8213d4356  pop rax
000078f8213d4357  add rsp, 0x08
000078f8213d435b  jmp 0x000078F8213D00DD
000078f8213d4360  sub rsp, 0x08
000078f8213d4364  push rax
000078f8213d4365  push rcx
000078f8213d4366  push rdx
000078f8213d4367  push rdi
000078f8213d4368  push rsi
000078f8213d4369  push r8
000078f8213d436b  push r9
000078f8213d436d  push r10
000078f8213d436f  push r11
000078f8213d4371  sub rsp, 0xF0
000078f8213d4378  vmovaps [rsp], xmm0
000078f8213d437d  vmovaps [rsp+0x10], xmm1
000078f8213d4383  vmovaps [rsp+0x20], xmm2
000078f8213d4389  vmovaps [rsp+0x30], xmm3
000078f8213d438f  vmovaps [rsp+0x40], xmm4
000078f8213d4395  vmovaps [rsp+0x50], xmm5
000078f8213d439b  vmovaps [rsp+0x60], xmm6
000078f8213d43a1  vmovaps [rsp+0x70], xmm7
000078f8213d43a7  vmovaps [rsp+0x80], xmm8
000078f8213d43b0  vmovaps [rsp+0x90], xmm9
000078f8213d43b9  vmovaps [rsp+0xA0], xmm10
000078f8213d43c2  vmovaps [rsp+0xB0], xmm11
000078f8213d43cb  vmovaps [rsp+0xC0], xmm13
000078f8213d43d4  vmovaps [rsp+0xD0], xmm14
000078f8213d43dd  vmovaps [rsp+0xE0], xmm15
000078f8213d43e6  sub rsp, 0x30
000078f8213d43ea  movaps [rsp], xmm12
000078f8213d43ef  movaps [rsp+0x10], xmm15
000078f8213d43f5  movaps [rsp+0x20], xmm11
000078f8213d43fb  lea rdi, [rsp]
000078f8213d43ff  mov esi, 0x00
000078f8213d4404  mov rax, 0x653D80F42530
000078f8213d440e  call rax
000078f8213d4410  movaps xmm12, [rsp]
000078f8213d4415  add rsp, 0x30
000078f8213d4419  vmovaps xmm0, [rsp]
000078f8213d441e  vmovaps xmm1, [rsp+0x10]
000078f8213d4424  vmovaps xmm2, [rsp+0x20]
000078f8213d442a  vmovaps xmm3, [rsp+0x30]
000078f8213d4430  vmovaps xmm4, [rsp+0x40]
000078f8213d4436  vmovaps xmm5, [rsp+0x50]
000078f8213d443c  vmovaps xmm6, [rsp+0x60]
000078f8213d4442  vmovaps xmm7, [rsp+0x70]
000078f8213d4448  vmovaps xmm8, [rsp+0x80]
000078f8213d4451  vmovaps xmm9, [rsp+0x90]
000078f8213d445a  vmovaps xmm10, [rsp+0xA0]
000078f8213d4463  vmovaps xmm11, [rsp+0xB0]
000078f8213d446c  vmovaps xmm13, [rsp+0xC0]
000078f8213d4475  vmovaps xmm14, [rsp+0xD0]
000078f8213d447e  vmovaps xmm15, [rsp+0xE0]
000078f8213d4487  add rsp, 0xF0
000078f8213d448e  pop r11
000078f8213d4490  pop r10
000078f8213d4492  pop r9
000078f8213d4494  pop r8
000078f8213d4496  pop rsi
000078f8213d4497  pop rdi
000078f8213d4498  pop rdx
000078f8213d4499  pop rcx
000078f8213d449a  pop rax
000078f8213d449b  add rsp, 0x08
000078f8213d449f  jmp 0x000078F8213D00F7
000078f8213d44a4  sub rsp, 0x08
000078f8213d44a8  push rax
000078f8213d44a9  push rcx
000078f8213d44aa  push rdx
000078f8213d44ab  push rdi
000078f8213d44ac  push rsi
000078f8213d44ad  push r8
000078f8213d44af  push r9
000078f8213d44b1  push r10
000078f8213d44b3  push r11
000078f8213d44b5  sub rsp, 0xF0
000078f8213d44bc  vmovaps [rsp], xmm0
000078f8213d44c1  vmovaps [rsp+0x10], xmm1
000078f8213d44c7  vmovaps [rsp+0x20], xmm2
000078f8213d44cd  vmovaps [rsp+0x30], xmm3
000078f8213d44d3  vmovaps [rsp+0x40], xmm4
000078f8213d44d9  vmovaps [rsp+0x50], xmm5
000078f8213d44df  vmovaps [rsp+0x60], xmm6
000078f8213d44e5  vmovaps [rsp+0x70], xmm7
000078f8213d44eb  vmovaps [rsp+0x80], xmm8
000078f8213d44f4  vmovaps [rsp+0x90], xmm9
000078f8213d44fd  vmovaps [rsp+0xA0], xmm10
000078f8213d4506  vmovaps [rsp+0xB0], xmm12
000078f8213d450f  vmovaps [rsp+0xC0], xmm13
000078f8213d4518  vmovaps [rsp+0xD0], xmm14
000078f8213d4521  vmovaps [rsp+0xE0], xmm15
000078f8213d452a  sub rsp, 0x30
000078f8213d452e  movaps [rsp], xmm11
000078f8213d4533  movaps [rsp+0x10], xmm7
000078f8213d4538  movaps [rsp+0x20], xmm15
000078f8213d453e  lea rdi, [rsp]
000078f8213d4542  mov esi, 0x00
000078f8213d4547  mov rax, 0x653D80F42530
000078f8213d4551  call rax
000078f8213d4553  movaps xmm11, [rsp]
000078f8213d4558  add rsp, 0x30
000078f8213d455c  vmovaps xmm0, [rsp]
000078f8213d4561  vmovaps xmm1, [rsp+0x10]
000078f8213d4567  vmovaps xmm2, [rsp+0x20]
000078f8213d456d  vmovaps xmm3, [rsp+0x30]
000078f8213d4573  vmovaps xmm4, [rsp+0x40]
000078f8213d4579  vmovaps xmm5, [rsp+0x50]
000078f8213d457f  vmovaps xmm6, [rsp+0x60]
000078f8213d4585  vmovaps xmm7, [rsp+0x70]
000078f8213d458b  vmovaps xmm8, [rsp+0x80]
000078f8213d4594  vmovaps xmm9, [rsp+0x90]
000078f8213d459d  vmovaps xmm10, [rsp+0xA0]
000078f8213d45a6  vmovaps xmm12, [rsp+0xB0]
000078f8213d45af  vmovaps xmm13, [rsp+0xC0]
000078f8213d45b8  vmovaps xmm14, [rsp+0xD0]
000078f8213d45c1  vmovaps xmm15, [rsp+0xE0]
000078f8213d45ca  add rsp, 0xF0
000078f8213d45d1  pop r11
000078f8213d45d3  pop r10
000078f8213d45d5  pop r9
000078f8213d45d7  pop r8
000078f8213d45d9  pop rsi
000078f8213d45da  pop rdi
000078f8213d45db  pop rdx
000078f8213d45dc  pop rcx
000078f8213d45dd  pop rax
000078f8213d45de  add rsp, 0x08
000078f8213d45e2  jmp 0x000078F8213D0123
000078f8213d45e7  sub rsp, 0x08
000078f8213d45eb  push rax
000078f8213d45ec  push rcx
000078f8213d45ed  push rdx
000078f8213d45ee  push rdi
000078f8213d45ef  push rsi
000078f8213d45f0  push r8
000078f8213d45f2  push r9
000078f8213d45f4  push r10
000078f8213d45f6  push r11
000078f8213d45f8  sub rsp, 0xF0
000078f8213d45ff  vmovaps [rsp], xmm0
000078f8213d4604  vmovaps [rsp+0x10], xmm1
000078f8213d460a  vmovaps [rsp+0x20], xmm2
000078f8213d4610  vmovaps [rsp+0x30], xmm3
000078f8213d4616  vmovaps [rsp+0x40], xmm4
000078f8213d461c  vmovaps [rsp+0x50], xmm5
000078f8213d4622  vmovaps [rsp+0x60], xmm6
000078f8213d4628  vmovaps [rsp+0x70], xmm7
000078f8213d462e  vmovaps [rsp+0x80], xmm8
000078f8213d4637  vmovaps [rsp+0x90], xmm9
000078f8213d4640  vmovaps [rsp+0xA0], xmm10
000078f8213d4649  vmovaps [rsp+0xB0], xmm11
000078f8213d4652  vmovaps [rsp+0xC0], xmm12
000078f8213d465b  vmovaps [rsp+0xD0], xmm13
000078f8213d4664  vmovaps [rsp+0xE0], xmm14
000078f8213d466d  sub rsp, 0x30
000078f8213d4671  movaps [rsp], xmm15
000078f8213d4676  movaps [rsp+0x10], xmm10
000078f8213d467c  movaps [rsp+0x20], xmm13
000078f8213d4682  lea rdi, [rsp]
000078f8213d4686  mov esi, 0x00
000078f8213d468b  mov rax, 0x653D80F42530
000078f8213d4695  call rax
000078f8213d4697  movaps xmm15, [rsp]
000078f8213d469c  add rsp, 0x30
000078f8213d46a0  vmovaps xmm0, [rsp]
000078f8213d46a5  vmovaps xmm1, [rsp+0x10]
000078f8213d46ab  vmovaps xmm2, [rsp+0x20]
000078f8213d46b1  vmovaps xmm3, [rsp+0x30]
000078f8213d46b7  vmovaps xmm4, [rsp+0x40]
000078f8213d46bd  vmovaps xmm5, [rsp+0x50]
000078f8213d46c3  vmovaps xmm6, [rsp+0x60]
000078f8213d46c9  vmovaps xmm7, [rsp+0x70]
000078f8213d46cf  vmovaps xmm8, [rsp+0x80]
000078f8213d46d8  vmovaps xmm9, [rsp+0x90]
000078f8213d46e1  vmovaps xmm10, [rsp+0xA0]
000078f8213d46ea  vmovaps xmm11, [rsp+0xB0]
000078f8213d46f3  vmovaps xmm12, [rsp+0xC0]
000078f8213d46fc  vmovaps xmm13, [rsp+0xD0]
000078f8213d4705  vmovaps xmm14, [rsp+0xE0]
000078f8213d470e  add rsp, 0xF0
000078f8213d4715  pop r11
000078f8213d4717  pop r10
000078f8213d4719  pop r9
000078f8213d471b  pop r8
000078f8213d471d  pop rsi
000078f8213d471e  pop rdi
000078f8213d471f  pop rdx
000078f8213d4720  pop rcx
000078f8213d4721  pop rax
000078f8213d4722  add rsp, 0x08
000078f8213d4726  jmp 0x000078F8213D013D
000078f8213d472b  sub rsp, 0x08
000078f8213d472f  push rax
000078f8213d4730  push rcx
000078f8213d4731  push rdx
000078f8213d4732  push rdi
000078f8213d4733  push rsi
000078f8213d4734  push r8
000078f8213d4736  push r9
000078f8213d4738  push r10
000078f8213d473a  push r11
000078f8213d473c  sub rsp, 0xF0
000078f8213d4743  vmovaps [rsp], xmm0
000078f8213d4748  vmovaps [rsp+0x10], xmm1
000078f8213d474e  vmovaps [rsp+0x20], xmm2
000078f8213d4754  vmovaps [rsp+0x30], xmm3
000078f8213d475a  vmovaps [rsp+0x40], xmm4
000078f8213d4760  vmovaps [rsp+0x50], xmm5
000078f8213d4766  vmovaps [rsp+0x60], xmm6
000078f8213d476c  vmovaps [rsp+0x70], xmm7
000078f8213d4772  vmovaps [rsp+0x80], xmm8
000078f8213d477b  vmovaps [rsp+0x90], xmm9
000078f8213d4784  vmovaps [rsp+0xA0], xmm11
000078f8213d478d  vmovaps [rsp+0xB0], xmm12
000078f8213d4796  vmovaps [rsp+0xC0], xmm13
000078f8213d479f  vmovaps [rsp+0xD0], xmm14
000078f8213d47a8  vmovaps [rsp+0xE0], xmm15
000078f8213d47b1  sub rsp, 0x30
000078f8213d47b5  movaps [rsp], xmm10
000078f8213d47ba  movaps [rsp+0x10], xmm7
000078f8213d47bf  movaps [rsp+0x20], xmm13
000078f8213d47c5  lea rdi, [rsp]
000078f8213d47c9  mov esi, 0x00
000078f8213d47ce  mov rax, 0x653D80F42530
000078f8213d47d8  call rax
000078f8213d47da  movaps xmm10, [rsp]
000078f8213d47df  add rsp, 0x30
000078f8213d47e3  vmovaps xmm0, [rsp]
000078f8213d47e8  vmovaps xmm1, [rsp+0x10]
000078f8213d47ee  vmovaps xmm2, [rsp+0x20]
000078f8213d47f4  vmovaps xmm3, [rsp+0x30]
000078f8213d47fa  vmovaps xmm4, [rsp+0x40]
000078f8213d4800  vmovaps xmm5, [rsp+0x50]
000078f8213d4806  vmovaps xmm6, [rsp+0x60]
000078f8213d480c  vmovaps xmm7, [rsp+0x70]
000078f8213d4812  vmovaps xmm8, [rsp+0x80]
000078f8213d481b  vmovaps xmm9, [rsp+0x90]
000078f8213d4824  vmovaps xmm11, [rsp+0xA0]
000078f8213d482d  vmovaps xmm12, [rsp+0xB0]
000078f8213d4836  vmovaps xmm13, [rsp+0xC0]
000078f8213d483f  vmovaps xmm14, [rsp+0xD0]
000078f8213d4848  vmovaps xmm15, [rsp+0xE0]
000078f8213d4851  add rsp, 0xF0
000078f8213d4858  pop r11
000078f8213d485a  pop r10
000078f8213d485c  pop r9
000078f8213d485e  pop r8
000078f8213d4860  pop rsi
000078f8213d4861  pop rdi
000078f8213d4862  pop rdx
000078f8213d4863  pop rcx
000078f8213d4864  pop rax
000078f8213d4865  add rsp, 0x08
000078f8213d4869  jmp 0x000078F8213D0169
000078f8213d486e  sub rsp, 0x08
000078f8213d4872  push rax
000078f8213d4873  push rcx
000078f8213d4874  push rdx
000078f8213d4875  push rdi
000078f8213d4876  push rsi
000078f8213d4877  push r8
000078f8213d4879  push r9
000078f8213d487b  push r10
000078f8213d487d  push r11
000078f8213d487f  sub rsp, 0xF0
000078f8213d4886  vmovaps [rsp], xmm0
000078f8213d488b  vmovaps [rsp+0x10], xmm1
000078f8213d4891  vmovaps [rsp+0x20], xmm2
000078f8213d4897  vmovaps [rsp+0x30], xmm3
000078f8213d489d  vmovaps [rsp+0x40], xmm4
000078f8213d48a3  vmovaps [rsp+0x50], xmm5
000078f8213d48a9  vmovaps [rsp+0x60], xmm6
000078f8213d48af  vmovaps [rsp+0x70], xmm7
000078f8213d48b5  vmovaps [rsp+0x80], xmm8
000078f8213d48be  vmovaps [rsp+0x90], xmm9
000078f8213d48c7  vmovaps [rsp+0xA0], xmm10
000078f8213d48d0  vmovaps [rsp+0xB0], xmm11
000078f8213d48d9  vmovaps [rsp+0xC0], xmm12
000078f8213d48e2  vmovaps [rsp+0xD0], xmm14
000078f8213d48eb  vmovaps [rsp+0xE0], xmm15
000078f8213d48f4  sub rsp, 0x30
000078f8213d48f8  movaps [rsp], xmm13
000078f8213d48fd  movaps [rsp+0x10], xmm1
000078f8213d4902  movaps [rsp+0x20], xmm8
000078f8213d4908  lea rdi, [rsp]
000078f8213d490c  mov esi, 0x00
000078f8213d4911  mov rax, 0x653D80F42530
000078f8213d491b  call rax
000078f8213d491d  movaps xmm13, [rsp]
000078f8213d4922  add rsp, 0x30
000078f8213d4926  vmovaps xmm0, [rsp]
000078f8213d492b  vmovaps xmm1, [rsp+0x10]
000078f8213d4931  vmovaps xmm2, [rsp+0x20]
000078f8213d4937  vmovaps xmm3, [rsp+0x30]
000078f8213d493d  vmovaps xmm4, [rsp+0x40]
000078f8213d4943  vmovaps xmm5, [rsp+0x50]
000078f8213d4949  vmovaps xmm6, [rsp+0x60]
000078f8213d494f  vmovaps xmm7, [rsp+0x70]
000078f8213d4955  vmovaps xmm8, [rsp+0x80]
000078f8213d495e  vmovaps xmm9, [rsp+0x90]
000078f8213d4967  vmovaps xmm10, [rsp+0xA0]
000078f8213d4970  vmovaps xmm11, [rsp+0xB0]
000078f8213d4979  vmovaps xmm12, [rsp+0xC0]
000078f8213d4982  vmovaps xmm14, [rsp+0xD0]
000078f8213d498b  vmovaps xmm15, [rsp+0xE0]
000078f8213d4994  add rsp, 0xF0
000078f8213d499b  pop r11
000078f8213d499d  pop r10
000078f8213d499f  pop r9
000078f8213d49a1  pop r8
000078f8213d49a3  pop rsi
000078f8213d49a4  pop rdi
000078f8213d49a5  pop rdx
000078f8213d49a6  pop rcx
000078f8213d49a7  pop rax
000078f8213d49a8  add rsp, 0x08
000078f8213d49ac  jmp 0x000078F8213D0183
000078f8213d49b1  call 0x000078F8211FF430
000078f8213d49b6  jmp 0x000078F8213D018D
000078f8213d49bb  sub rsp, 0x08
000078f8213d49bf  push rax
000078f8213d49c0  push rcx
000078f8213d49c1  push rdx
000078f8213d49c2  push rdi
000078f8213d49c3  push rsi
000078f8213d49c4  push r8
000078f8213d49c6  push r9
000078f8213d49c8  push r10
000078f8213d49ca  push r11
000078f8213d49cc  sub rsp, 0xF0
000078f8213d49d3  vmovaps [rsp], xmm0
000078f8213d49d8  vmovaps [rsp+0x10], xmm1
000078f8213d49de  vmovaps [rsp+0x20], xmm2
000078f8213d49e4  vmovaps [rsp+0x30], xmm3
000078f8213d49ea  vmovaps [rsp+0x40], xmm4
000078f8213d49f0  vmovaps [rsp+0x50], xmm5
000078f8213d49f6  vmovaps [rsp+0x60], xmm6
000078f8213d49fc  vmovaps [rsp+0x70], xmm7
000078f8213d4a02  vmovaps [rsp+0x80], xmm9
000078f8213d4a0b  vmovaps [rsp+0x90], xmm10
000078f8213d4a14  vmovaps [rsp+0xA0], xmm11
000078f8213d4a1d  vmovaps [rsp+0xB0], xmm12
000078f8213d4a26  vmovaps [rsp+0xC0], xmm13
000078f8213d4a2f  vmovaps [rsp+0xD0], xmm14
000078f8213d4a38  vmovaps [rsp+0xE0], xmm15
000078f8213d4a41  sub rsp, 0x30
000078f8213d4a45  movaps [rsp], xmm8
000078f8213d4a4a  movaps [rsp+0x10], xmm14
000078f8213d4a50  movaps [rsp+0x20], xmm9
000078f8213d4a56  lea rdi, [rsp]
000078f8213d4a5a  mov esi, 0x00
000078f8213d4a5f  mov rax, 0x653D80F42530
000078f8213d4a69  call rax
000078f8213d4a6b  movaps xmm8, [rsp]
000078f8213d4a70  add rsp, 0x30
000078f8213d4a74  vmovaps xmm0, [rsp]
000078f8213d4a79  vmovaps xmm1, [rsp+0x10]
000078f8213d4a7f  vmovaps xmm2, [rsp+0x20]
000078f8213d4a85  vmovaps xmm3, [rsp+0x30]
000078f8213d4a8b  vmovaps xmm4, [rsp+0x40]
000078f8213d4a91  vmovaps xmm5, [rsp+0x50]
000078f8213d4a97  vmovaps xmm6, [rsp+0x60]
000078f8213d4a9d  vmovaps xmm7, [rsp+0x70]
000078f8213d4aa3  vmovaps xmm9, [rsp+0x80]
000078f8213d4aac  vmovaps xmm10, [rsp+0x90]
000078f8213d4ab5  vmovaps xmm11, [rsp+0xA0]
000078f8213d4abe  vmovaps xmm12, [rsp+0xB0]
000078f8213d4ac7  vmovaps xmm13, [rsp+0xC0]
000078f8213d4ad0  vmovaps xmm14, [rsp+0xD0]
000078f8213d4ad9  vmovaps xmm15, [rsp+0xE0]
000078f8213d4ae2  add rsp, 0xF0
000078f8213d4ae9  pop r11
000078f8213d4aeb  pop r10
000078f8213d4aed  pop r9
000078f8213d4aef  pop r8
000078f8213d4af1  pop rsi
000078f8213d4af2  pop rdi
000078f8213d4af3  pop rdx
000078f8213d4af4  pop rcx
000078f8213d4af5  pop rax
000078f8213d4af6  add rsp, 0x08
000078f8213d4afa  jmp 0x000078F8213D01AF
000078f8213d4aff  sub rsp, 0x08
000078f8213d4b03  push rax
000078f8213d4b04  push rcx
000078f8213d4b05  push rdx
000078f8213d4b06  push rdi
000078f8213d4b07  push rsi
000078f8213d4b08  push r8
000078f8213d4b0a  push r9
000078f8213d4b0c  push r10
000078f8213d4b0e  push r11
000078f8213d4b10  sub rsp, 0xF0
000078f8213d4b17  vmovaps [rsp], xmm0
000078f8213d4b1c  vmovaps [rsp+0x10], xmm1
000078f8213d4b22  vmovaps [rsp+0x20], xmm2
000078f8213d4b28  vmovaps [rsp+0x30], xmm3
000078f8213d4b2e  vmovaps [rsp+0x40], xmm4
000078f8213d4b34  vmovaps [rsp+0x50], xmm5
000078f8213d4b3a  vmovaps [rsp+0x60], xmm6
000078f8213d4b40  vmovaps [rsp+0x70], xmm7
000078f8213d4b46  vmovaps [rsp+0x80], xmm8
000078f8213d4b4f  vmovaps [rsp+0x90], xmm10
000078f8213d4b58  vmovaps [rsp+0xA0], xmm11
000078f8213d4b61  vmovaps [rsp+0xB0], xmm12
000078f8213d4b6a  vmovaps [rsp+0xC0], xmm13
000078f8213d4b73  vmovaps [rsp+0xD0], xmm14
000078f8213d4b7c  vmovaps [rsp+0xE0], xmm15
000078f8213d4b85  sub rsp, 0x30
000078f8213d4b89  movaps [rsp], xmm9
000078f8213d4b8e  movaps [rsp+0x10], xmm1
000078f8213d4b93  movaps [rsp+0x20], xmm14
000078f8213d4b99  lea rdi, [rsp]
000078f8213d4b9d  mov esi, 0x00
000078f8213d4ba2  mov rax, 0x653D80F42530
000078f8213d4bac  call rax
000078f8213d4bae  movaps xmm9, [rsp]
000078f8213d4bb3  add rsp, 0x30
000078f8213d4bb7  vmovaps xmm0, [rsp]
000078f8213d4bbc  vmovaps xmm1, [rsp+0x10]
000078f8213d4bc2  vmovaps xmm2, [rsp+0x20]
000078f8213d4bc8  vmovaps xmm3, [rsp+0x30]
000078f8213d4bce  vmovaps xmm4, [rsp+0x40]
000078f8213d4bd4  vmovaps xmm5, [rsp+0x50]
000078f8213d4bda  vmovaps xmm6, [rsp+0x60]
000078f8213d4be0  vmovaps xmm7, [rsp+0x70]
000078f8213d4be6  vmovaps xmm8, [rsp+0x80]
000078f8213d4bef  vmovaps xmm10, [rsp+0x90]
000078f8213d4bf8  vmovaps xmm11, [rsp+0xA0]
000078f8213d4c01  vmovaps xmm12, [rsp+0xB0]
000078f8213d4c0a  vmovaps xmm13, [rsp+0xC0]
000078f8213d4c13  vmovaps xmm14, [rsp+0xD0]
000078f8213d4c1c  vmovaps xmm15, [rsp+0xE0]
000078f8213d4c25  add rsp, 0xF0
000078f8213d4c2c  pop r11
000078f8213d4c2e  pop r10
000078f8213d4c30  pop r9
000078f8213d4c32  pop r8
000078f8213d4c34  pop rsi
000078f8213d4c35  pop rdi
000078f8213d4c36  pop rdx
000078f8213d4c37  pop rcx
000078f8213d4c38  pop rax
000078f8213d4c39  add rsp, 0x08
000078f8213d4c3d  jmp 0x000078F8213D01DD
000078f8213d4c42  sub rsp, 0x08
000078f8213d4c46  push rax
000078f8213d4c47  push rcx
000078f8213d4c48  push rdx
000078f8213d4c49  push rdi
000078f8213d4c4a  push rsi
000078f8213d4c4b  push r8
000078f8213d4c4d  push r9
000078f8213d4c4f  push r10
000078f8213d4c51  push r11
000078f8213d4c53  sub rsp, 0xF0
000078f8213d4c5a  vmovaps [rsp], xmm0
000078f8213d4c5f  vmovaps [rsp+0x10], xmm1
000078f8213d4c65  vmovaps [rsp+0x20], xmm2
000078f8213d4c6b  vmovaps [rsp+0x30], xmm3
000078f8213d4c71  vmovaps [rsp+0x40], xmm4
000078f8213d4c77  vmovaps [rsp+0x50], xmm5
000078f8213d4c7d  vmovaps [rsp+0x60], xmm6
000078f8213d4c83  vmovaps [rsp+0x70], xmm7
000078f8213d4c89  vmovaps [rsp+0x80], xmm8
000078f8213d4c92  vmovaps [rsp+0x90], xmm9
000078f8213d4c9b  vmovaps [rsp+0xA0], xmm10
000078f8213d4ca4  vmovaps [rsp+0xB0], xmm11
000078f8213d4cad  vmovaps [rsp+0xC0], xmm12
000078f8213d4cb6  vmovaps [rsp+0xD0], xmm13
000078f8213d4cbf  vmovaps [rsp+0xE0], xmm15
000078f8213d4cc8  sub rsp, 0x30
000078f8213d4ccc  movaps [rsp], xmm14
000078f8213d4cd1  movaps [rsp+0x10], xmm4
000078f8213d4cd6  movaps [rsp+0x20], xmm1
000078f8213d4cdb  lea rdi, [rsp]
000078f8213d4cdf  mov esi, 0x00
000078f8213d4ce4  mov rax, 0x653D80F42530
000078f8213d4cee  call rax
000078f8213d4cf0  movaps xmm14, [rsp]
000078f8213d4cf5  add rsp, 0x30
000078f8213d4cf9  vmovaps xmm0, [rsp]
000078f8213d4cfe  vmovaps xmm1, [rsp+0x10]
000078f8213d4d04  vmovaps xmm2, [rsp+0x20]
000078f8213d4d0a  vmovaps xmm3, [rsp+0x30]
000078f8213d4d10  vmovaps xmm4, [rsp+0x40]
000078f8213d4d16  vmovaps xmm5, [rsp+0x50]
000078f8213d4d1c  vmovaps xmm6, [rsp+0x60]
000078f8213d4d22  vmovaps xmm7, [rsp+0x70]
000078f8213d4d28  vmovaps xmm8, [rsp+0x80]
000078f8213d4d31  vmovaps xmm9, [rsp+0x90]
000078f8213d4d3a  vmovaps xmm10, [rsp+0xA0]
000078f8213d4d43  vmovaps xmm11, [rsp+0xB0]
000078f8213d4d4c  vmovaps xmm12, [rsp+0xC0]
000078f8213d4d55  vmovaps xmm13, [rsp+0xD0]
000078f8213d4d5e  vmovaps xmm15, [rsp+0xE0]
000078f8213d4d67  add rsp, 0xF0
000078f8213d4d6e  pop r11
000078f8213d4d70  pop r10
000078f8213d4d72  pop r9
000078f8213d4d74  pop r8
000078f8213d4d76  pop rsi
000078f8213d4d77  pop rdi
000078f8213d4d78  pop rdx
000078f8213d4d79  pop rcx
000078f8213d4d7a  pop rax
000078f8213d4d7b  add rsp, 0x08
000078f8213d4d7f  jmp 0x000078F8213D0203
000078f8213d4d84  sub rsp, 0x08
000078f8213d4d88  push rax
000078f8213d4d89  push rcx
000078f8213d4d8a  push rdx
000078f8213d4d8b  push rdi
000078f8213d4d8c  push rsi
000078f8213d4d8d  push r8
000078f8213d4d8f  push r9
000078f8213d4d91  push r10
000078f8213d4d93  push r11
000078f8213d4d95  sub rsp, 0xF0
000078f8213d4d9c  vmovaps [rsp], xmm0
000078f8213d4da1  vmovaps [rsp+0x10], xmm2
000078f8213d4da7  vmovaps [rsp+0x20], xmm3
000078f8213d4dad  vmovaps [rsp+0x30], xmm4
000078f8213d4db3  vmovaps [rsp+0x40], xmm5
000078f8213d4db9  vmovaps [rsp+0x50], xmm6
000078f8213d4dbf  vmovaps [rsp+0x60], xmm7
000078f8213d4dc5  vmovaps [rsp+0x70], xmm8
000078f8213d4dcb  vmovaps [rsp+0x80], xmm9
000078f8213d4dd4  vmovaps [rsp+0x90], xmm10
000078f8213d4ddd  vmovaps [rsp+0xA0], xmm11
000078f8213d4de6  vmovaps [rsp+0xB0], xmm12
000078f8213d4def  vmovaps [rsp+0xC0], xmm13
000078f8213d4df8  vmovaps [rsp+0xD0], xmm14
000078f8213d4e01  vmovaps [rsp+0xE0], xmm15
000078f8213d4e0a  sub rsp, 0x30
000078f8213d4e0e  movaps [rsp], xmm1
000078f8213d4e12  movaps [rsp+0x10], xmm12
000078f8213d4e18  movaps [rsp+0x20], xmm11
000078f8213d4e1e  lea rdi, [rsp]
000078f8213d4e22  mov esi, 0x00
000078f8213d4e27  mov rax, 0x653D80F42530
000078f8213d4e31  call rax
000078f8213d4e33  movaps xmm1, [rsp]
000078f8213d4e37  add rsp, 0x30
000078f8213d4e3b  vmovaps xmm0, [rsp]
000078f8213d4e40  vmovaps xmm2, [rsp+0x10]
000078f8213d4e46  vmovaps xmm3, [rsp+0x20]
000078f8213d4e4c  vmovaps xmm4, [rsp+0x30]
000078f8213d4e52  vmovaps xmm5, [rsp+0x40]
000078f8213d4e58  vmovaps xmm6, [rsp+0x50]
000078f8213d4e5e  vmovaps xmm7, [rsp+0x60]
000078f8213d4e64  vmovaps xmm8, [rsp+0x70]
000078f8213d4e6a  vmovaps xmm9, [rsp+0x80]
000078f8213d4e73  vmovaps xmm10, [rsp+0x90]
000078f8213d4e7c  vmovaps xmm11, [rsp+0xA0]
000078f8213d4e85  vmovaps xmm12, [rsp+0xB0]
000078f8213d4e8e  vmovaps xmm13, [rsp+0xC0]
000078f8213d4e97  vmovaps xmm14, [rsp+0xD0]
000078f8213d4ea0  vmovaps xmm15, [rsp+0xE0]
000078f8213d4ea9  add rsp, 0xF0
000078f8213d4eb0  pop r11
000078f8213d4eb2  pop r10
000078f8213d4eb4  pop r9
000078f8213d4eb6  pop r8
000078f8213d4eb8  pop rsi
000078f8213d4eb9  pop rdi
000078f8213d4eba  pop rdx
000078f8213d4ebb  pop rcx
000078f8213d4ebc  pop rax
000078f8213d4ebd  add rsp, 0x08
000078f8213d4ec1  jmp 0x000078F8213D0224
000078f8213d4ec6  call 0x000078F8212E20A0
000078f8213d4ecb  jmp 0x000078F8213D0232
000078f8213d4ed0  call 0x000078F821209D70
000078f8213d4ed5  jmp 0x000078F8213D023C
000078f8213d4eda  sub rsp, 0x08
000078f8213d4ede  push rax
000078f8213d4edf  push rcx
000078f8213d4ee0  push rdx
000078f8213d4ee1  push rdi
000078f8213d4ee2  push rsi
000078f8213d4ee3  push r8
000078f8213d4ee5  push r9
000078f8213d4ee7  push r10
000078f8213d4ee9  push r11
000078f8213d4eeb  sub rsp, 0xF0
000078f8213d4ef2  vmovaps [rsp], xmm0
000078f8213d4ef7  vmovaps [rsp+0x10], xmm1
000078f8213d4efd  vmovaps [rsp+0x20], xmm2
000078f8213d4f03  vmovaps [rsp+0x30], xmm3
000078f8213d4f09  vmovaps [rsp+0x40], xmm4
000078f8213d4f0f  vmovaps [rsp+0x50], xmm5
000078f8213d4f15  vmovaps [rsp+0x60], xmm6
000078f8213d4f1b  vmovaps [rsp+0x70], xmm8
000078f8213d4f21  vmovaps [rsp+0x80], xmm9
000078f8213d4f2a  vmovaps [rsp+0x90], xmm10
000078f8213d4f33  vmovaps [rsp+0xA0], xmm11
000078f8213d4f3c  vmovaps [rsp+0xB0], xmm12
000078f8213d4f45  vmovaps [rsp+0xC0], xmm13
000078f8213d4f4e  vmovaps [rsp+0xD0], xmm14
000078f8213d4f57  vmovaps [rsp+0xE0], xmm15
000078f8213d4f60  sub rsp, 0x30
000078f8213d4f64  movaps [rsp], xmm7
000078f8213d4f68  movaps [rsp+0x10], xmm15
000078f8213d4f6e  movaps [rsp+0x20], xmm10
000078f8213d4f74  lea rdi, [rsp]
000078f8213d4f78  mov esi, 0x00
000078f8213d4f7d  mov rax, 0x653D80F42530
000078f8213d4f87  call rax
000078f8213d4f89  movaps xmm7, [rsp]
000078f8213d4f8d  add rsp, 0x30
000078f8213d4f91  vmovaps xmm0, [rsp]
000078f8213d4f96  vmovaps xmm1, [rsp+0x10]
000078f8213d4f9c  vmovaps xmm2, [rsp+0x20]
000078f8213d4fa2  vmovaps xmm3, [rsp+0x30]
000078f8213d4fa8  vmovaps xmm4, [rsp+0x40]
000078f8213d4fae  vmovaps xmm5, [rsp+0x50]
000078f8213d4fb4  vmovaps xmm6, [rsp+0x60]
000078f8213d4fba  vmovaps xmm8, [rsp+0x70]
000078f8213d4fc0  vmovaps xmm9, [rsp+0x80]
000078f8213d4fc9  vmovaps xmm10, [rsp+0x90]
000078f8213d4fd2  vmovaps xmm11, [rsp+0xA0]
000078f8213d4fdb  vmovaps xmm12, [rsp+0xB0]
000078f8213d4fe4  vmovaps xmm13, [rsp+0xC0]
000078f8213d4fed  vmovaps xmm14, [rsp+0xD0]
000078f8213d4ff6  vmovaps xmm15, [rsp+0xE0]
000078f8213d4fff  add rsp, 0xF0
000078f8213d5006  pop r11
000078f8213d5008  pop r10
000078f8213d500a  pop r9
000078f8213d500c  pop r8
000078f8213d500e  pop rsi
000078f8213d500f  pop rdi
000078f8213d5010  pop rdx
000078f8213d5011  pop rcx
000078f8213d5012  pop rax
000078f8213d5013  add rsp, 0x08
000078f8213d5017  jmp 0x000078F8213D025D
000078f8213d501c  sub rsp, 0x08
000078f8213d5020  push rax
000078f8213d5021  push rcx
000078f8213d5022  push rdx
000078f8213d5023  push rdi
000078f8213d5024  push rsi
000078f8213d5025  push r8
000078f8213d5027  push r9
000078f8213d5029  push r10
000078f8213d502b  push r11
000078f8213d502d  sub rsp, 0xF0
000078f8213d5034  vmovaps [rsp], xmm0
000078f8213d5039  vmovaps [rsp+0x10], xmm1
000078f8213d503f  vmovaps [rsp+0x20], xmm2
000078f8213d5045  vmovaps [rsp+0x30], xmm3
000078f8213d504b  vmovaps [rsp+0x40], xmm4
000078f8213d5051  vmovaps [rsp+0x50], xmm5
000078f8213d5057  vmovaps [rsp+0x60], xmm6
000078f8213d505d  vmovaps [rsp+0x70], xmm7
000078f8213d5063  vmovaps [rsp+0x80], xmm8
000078f8213d506c  vmovaps [rsp+0x90], xmm9
000078f8213d5075  vmovaps [rsp+0xA0], xmm11
000078f8213d507e  vmovaps [rsp+0xB0], xmm12
000078f8213d5087  vmovaps [rsp+0xC0], xmm13
000078f8213d5090  vmovaps [rsp+0xD0], xmm14
000078f8213d5099  vmovaps [rsp+0xE0], xmm15
000078f8213d50a2  sub rsp, 0x30
000078f8213d50a6  movaps [rsp], xmm10
000078f8213d50ab  movaps [rsp+0x10], xmm11
000078f8213d50b1  movaps [rsp+0x20], xmm15
000078f8213d50b7  lea rdi, [rsp]
000078f8213d50bb  mov esi, 0x00
000078f8213d50c0  mov rax, 0x653D80F42530
000078f8213d50ca  call rax
000078f8213d50cc  movaps xmm10, [rsp]
000078f8213d50d1  add rsp, 0x30
000078f8213d50d5  vmovaps xmm0, [rsp]
000078f8213d50da  vmovaps xmm1, [rsp+0x10]
000078f8213d50e0  vmovaps xmm2, [rsp+0x20]
000078f8213d50e6  vmovaps xmm3, [rsp+0x30]
000078f8213d50ec  vmovaps xmm4, [rsp+0x40]
000078f8213d50f2  vmovaps xmm5, [rsp+0x50]
000078f8213d50f8  vmovaps xmm6, [rsp+0x60]
000078f8213d50fe  vmovaps xmm7, [rsp+0x70]
000078f8213d5104  vmovaps xmm8, [rsp+0x80]
000078f8213d510d  vmovaps xmm9, [rsp+0x90]
000078f8213d5116  vmovaps xmm11, [rsp+0xA0]
000078f8213d511f  vmovaps xmm12, [rsp+0xB0]
000078f8213d5128  vmovaps xmm13, [rsp+0xC0]
000078f8213d5131  vmovaps xmm14, [rsp+0xD0]
000078f8213d513a  vmovaps xmm15, [rsp+0xE0]
000078f8213d5143  add rsp, 0xF0
000078f8213d514a  pop r11
000078f8213d514c  pop r10
000078f8213d514e  pop r9
000078f8213d5150  pop r8
000078f8213d5152  pop rsi
000078f8213d5153  pop rdi
000078f8213d5154  pop rdx
000078f8213d5155  pop rcx
000078f8213d5156  pop rax
000078f8213d5157  add rsp, 0x08
000078f8213d515b  jmp 0x000078F8213D028B
000078f8213d5160  sub rsp, 0x08
000078f8213d5164  push rax
000078f8213d5165  push rcx
000078f8213d5166  push rdx
000078f8213d5167  push rdi
000078f8213d5168  push rsi
000078f8213d5169  push r8
000078f8213d516b  push r9
000078f8213d516d  push r10
000078f8213d516f  push r11
000078f8213d5171  sub rsp, 0xF0
000078f8213d5178  vmovaps [rsp], xmm0
000078f8213d517d  vmovaps [rsp+0x10], xmm1
000078f8213d5183  vmovaps [rsp+0x20], xmm2
000078f8213d5189  vmovaps [rsp+0x30], xmm3
000078f8213d518f  vmovaps [rsp+0x40], xmm4
000078f8213d5195  vmovaps [rsp+0x50], xmm5
000078f8213d519b  vmovaps [rsp+0x60], xmm6
000078f8213d51a1  vmovaps [rsp+0x70], xmm7
000078f8213d51a7  vmovaps [rsp+0x80], xmm8
000078f8213d51b0  vmovaps [rsp+0x90], xmm9
000078f8213d51b9  vmovaps [rsp+0xA0], xmm10
000078f8213d51c2  vmovaps [rsp+0xB0], xmm12
000078f8213d51cb  vmovaps [rsp+0xC0], xmm13
000078f8213d51d4  vmovaps [rsp+0xD0], xmm14
000078f8213d51dd  vmovaps [rsp+0xE0], xmm15
000078f8213d51e6  sub rsp, 0x30
000078f8213d51ea  movaps [rsp], xmm11
000078f8213d51ef  movaps [rsp+0x10], xmm12
000078f8213d51f5  movaps [rsp+0x20], xmm15
000078f8213d51fb  lea rdi, [rsp]
000078f8213d51ff  mov esi, 0x00
000078f8213d5204  mov rax, 0x653D80F42530
000078f8213d520e  call rax
000078f8213d5210  movaps xmm11, [rsp]
000078f8213d5215  add rsp, 0x30
000078f8213d5219  vmovaps xmm0, [rsp]
000078f8213d521e  vmovaps xmm1, [rsp+0x10]
000078f8213d5224  vmovaps xmm2, [rsp+0x20]
000078f8213d522a  vmovaps xmm3, [rsp+0x30]
000078f8213d5230  vmovaps xmm4, [rsp+0x40]
000078f8213d5236  vmovaps xmm5, [rsp+0x50]
000078f8213d523c  vmovaps xmm6, [rsp+0x60]
000078f8213d5242  vmovaps xmm7, [rsp+0x70]
000078f8213d5248  vmovaps xmm8, [rsp+0x80]
000078f8213d5251  vmovaps xmm9, [rsp+0x90]
000078f8213d525a  vmovaps xmm10, [rsp+0xA0]
000078f8213d5263  vmovaps xmm12, [rsp+0xB0]
000078f8213d526c  vmovaps xmm13, [rsp+0xC0]
000078f8213d5275  vmovaps xmm14, [rsp+0xD0]
000078f8213d527e  vmovaps xmm15, [rsp+0xE0]
000078f8213d5287  add rsp, 0xF0
000078f8213d528e  pop r11
000078f8213d5290  pop r10
000078f8213d5292  pop r9
000078f8213d5294  pop r8
000078f8213d5296  pop rsi
000078f8213d5297  pop rdi
000078f8213d5298  pop rdx
000078f8213d5299  pop rcx
000078f8213d529a  pop rax
000078f8213d529b  add rsp, 0x08
000078f8213d529f  jmp 0x000078F8213D02B9
000078f8213d52a4  sub rsp, 0x08
000078f8213d52a8  push rax
000078f8213d52a9  push rcx
000078f8213d52aa  push rdx
000078f8213d52ab  push rdi
000078f8213d52ac  push rsi
000078f8213d52ad  push r8
000078f8213d52af  push r9
000078f8213d52b1  push r10
000078f8213d52b3  push r11
000078f8213d52b5  sub rsp, 0xF0
000078f8213d52bc  vmovaps [rsp], xmm0
000078f8213d52c1  vmovaps [rsp+0x10], xmm1
000078f8213d52c7  vmovaps [rsp+0x20], xmm2
000078f8213d52cd  vmovaps [rsp+0x30], xmm3
000078f8213d52d3  vmovaps [rsp+0x40], xmm4
000078f8213d52d9  vmovaps [rsp+0x50], xmm5
000078f8213d52df  vmovaps [rsp+0x60], xmm6
000078f8213d52e5  vmovaps [rsp+0x70], xmm7
000078f8213d52eb  vmovaps [rsp+0x80], xmm8
000078f8213d52f4  vmovaps [rsp+0x90], xmm9
000078f8213d52fd  vmovaps [rsp+0xA0], xmm10
000078f8213d5306  vmovaps [rsp+0xB0], xmm11
000078f8213d530f  vmovaps [rsp+0xC0], xmm12
000078f8213d5318  vmovaps [rsp+0xD0], xmm13
000078f8213d5321  vmovaps [rsp+0xE0], xmm14
000078f8213d532a  sub rsp, 0x30
000078f8213d532e  movaps [rsp], xmm15
000078f8213d5333  movaps [rsp+0x10], xmm13
000078f8213d5339  movaps [rsp+0x20], xmm9
000078f8213d533f  lea rdi, [rsp]
000078f8213d5343  mov esi, 0x00
000078f8213d5348  mov rax, 0x653D80F42530
000078f8213d5352  call rax
000078f8213d5354  movaps xmm15, [rsp]
000078f8213d5359  add rsp, 0x30
000078f8213d535d  vmovaps xmm0, [rsp]
000078f8213d5362  vmovaps xmm1, [rsp+0x10]
000078f8213d5368  vmovaps xmm2, [rsp+0x20]
000078f8213d536e  vmovaps xmm3, [rsp+0x30]
000078f8213d5374  vmovaps xmm4, [rsp+0x40]
000078f8213d537a  vmovaps xmm5, [rsp+0x50]
000078f8213d5380  vmovaps xmm6, [rsp+0x60]
000078f8213d5386  vmovaps xmm7, [rsp+0x70]
000078f8213d538c  vmovaps xmm8, [rsp+0x80]
000078f8213d5395  vmovaps xmm9, [rsp+0x90]
000078f8213d539e  vmovaps xmm10, [rsp+0xA0]
000078f8213d53a7  vmovaps xmm11, [rsp+0xB0]
000078f8213d53b0  vmovaps xmm12, [rsp+0xC0]
000078f8213d53b9  vmovaps xmm13, [rsp+0xD0]
000078f8213d53c2  vmovaps xmm14, [rsp+0xE0]
000078f8213d53cb  add rsp, 0xF0
000078f8213d53d2  pop r11
000078f8213d53d4  pop r10
000078f8213d53d6  pop r9
000078f8213d53d8  pop r8
000078f8213d53da  pop rsi
000078f8213d53db  pop rdi
000078f8213d53dc  pop rdx
000078f8213d53dd  pop rcx
000078f8213d53de  pop rax
000078f8213d53df  add rsp, 0x08
000078f8213d53e3  jmp 0x000078F8213D02D4
000078f8213d53e8  sub rsp, 0x08
000078f8213d53ec  push rax
000078f8213d53ed  push rcx
000078f8213d53ee  push rdx
000078f8213d53ef  push rdi
000078f8213d53f0  push rsi
000078f8213d53f1  push r8
000078f8213d53f3  push r9
000078f8213d53f5  push r10
000078f8213d53f7  push r11
000078f8213d53f9  sub rsp, 0xF0
000078f8213d5400  vmovaps [rsp], xmm0
000078f8213d5405  vmovaps [rsp+0x10], xmm1
000078f8213d540b  vmovaps [rsp+0x20], xmm2
000078f8213d5411  vmovaps [rsp+0x30], xmm3
000078f8213d5417  vmovaps [rsp+0x40], xmm4
000078f8213d541d  vmovaps [rsp+0x50], xmm5
000078f8213d5423  vmovaps [rsp+0x60], xmm6
000078f8213d5429  vmovaps [rsp+0x70], xmm7
000078f8213d542f  vmovaps [rsp+0x80], xmm8
000078f8213d5438  vmovaps [rsp+0x90], xmm9
000078f8213d5441  vmovaps [rsp+0xA0], xmm10
000078f8213d544a  vmovaps [rsp+0xB0], xmm11
000078f8213d5453  vmovaps [rsp+0xC0], xmm12
000078f8213d545c  vmovaps [rsp+0xD0], xmm14
000078f8213d5465  vmovaps [rsp+0xE0], xmm15
000078f8213d546e  sub rsp, 0x30
000078f8213d5472  movaps [rsp], xmm13
000078f8213d5477  movaps [rsp+0x10], xmm8
000078f8213d547d  movaps [rsp+0x20], xmm14
000078f8213d5483  lea rdi, [rsp]
000078f8213d5487  mov esi, 0x00
000078f8213d548c  mov rax, 0x653D80F42530
000078f8213d5496  call rax
000078f8213d5498  movaps xmm13, [rsp]
000078f8213d549d  add rsp, 0x30
000078f8213d54a1  vmovaps xmm0, [rsp]
000078f8213d54a6  vmovaps xmm1, [rsp+0x10]
000078f8213d54ac  vmovaps xmm2, [rsp+0x20]
000078f8213d54b2  vmovaps xmm3, [rsp+0x30]
000078f8213d54b8  vmovaps xmm4, [rsp+0x40]
000078f8213d54be  vmovaps xmm5, [rsp+0x50]
000078f8213d54c4  vmovaps xmm6, [rsp+0x60]
000078f8213d54ca  vmovaps xmm7, [rsp+0x70]
000078f8213d54d0  vmovaps xmm8, [rsp+0x80]
000078f8213d54d9  vmovaps xmm9, [rsp+0x90]
000078f8213d54e2  vmovaps xmm10, [rsp+0xA0]
000078f8213d54eb  vmovaps xmm11, [rsp+0xB0]
000078f8213d54f4  vmovaps xmm12, [rsp+0xC0]
000078f8213d54fd  vmovaps xmm14, [rsp+0xD0]
000078f8213d5506  vmovaps xmm15, [rsp+0xE0]
000078f8213d550f  add rsp, 0xF0
000078f8213d5516  pop r11
000078f8213d5518  pop r10
000078f8213d551a  pop r9
000078f8213d551c  pop r8
000078f8213d551e  pop rsi
000078f8213d551f  pop rdi
000078f8213d5520  pop rdx
000078f8213d5521  pop rcx
000078f8213d5522  pop rax
000078f8213d5523  add rsp, 0x08
000078f8213d5527  jmp 0x000078F8213D02F7
000078f8213d552c  sub rsp, 0x08
000078f8213d5530  push rax
000078f8213d5531  push rcx
000078f8213d5532  push rdx
000078f8213d5533  push rdi
000078f8213d5534  push rsi
000078f8213d5535  push r8
000078f8213d5537  push r9
000078f8213d5539  push r10
000078f8213d553b  push r11
000078f8213d553d  sub rsp, 0xF0
000078f8213d5544  vmovaps [rsp], xmm0
000078f8213d5549  vmovaps [rsp+0x10], xmm1
000078f8213d554f  vmovaps [rsp+0x20], xmm2
000078f8213d5555  vmovaps [rsp+0x30], xmm3
000078f8213d555b  vmovaps [rsp+0x40], xmm4
000078f8213d5561  vmovaps [rsp+0x50], xmm5
000078f8213d5567  vmovaps [rsp+0x60], xmm6
000078f8213d556d  vmovaps [rsp+0x70], xmm7
000078f8213d5573  vmovaps [rsp+0x80], xmm8
000078f8213d557c  vmovaps [rsp+0x90], xmm9
000078f8213d5585  vmovaps [rsp+0xA0], xmm10
000078f8213d558e  vmovaps [rsp+0xB0], xmm11
000078f8213d5597  vmovaps [rsp+0xC0], xmm12
000078f8213d55a0  vmovaps [rsp+0xD0], xmm13
000078f8213d55a9  vmovaps [rsp+0xE0], xmm15
000078f8213d55b2  sub rsp, 0x30
000078f8213d55b6  movaps [rsp], xmm14
000078f8213d55bb  movaps [rsp+0x10], xmm1
000078f8213d55c0  movaps [rsp+0x20], xmm10
000078f8213d55c6  lea rdi, [rsp]
000078f8213d55ca  mov esi, 0x00
000078f8213d55cf  mov rax, 0x653D80F42530
000078f8213d55d9  call rax
000078f8213d55db  movaps xmm14, [rsp]
000078f8213d55e0  add rsp, 0x30
000078f8213d55e4  vmovaps xmm0, [rsp]
000078f8213d55e9  vmovaps xmm1, [rsp+0x10]
000078f8213d55ef  vmovaps xmm2, [rsp+0x20]
000078f8213d55f5  vmovaps xmm3, [rsp+0x30]
000078f8213d55fb  vmovaps xmm4, [rsp+0x40]
000078f8213d5601  vmovaps xmm5, [rsp+0x50]
000078f8213d5607  vmovaps xmm6, [rsp+0x60]
000078f8213d560d  vmovaps xmm7, [rsp+0x70]
000078f8213d5613  vmovaps xmm8, [rsp+0x80]
000078f8213d561c  vmovaps xmm9, [rsp+0x90]
000078f8213d5625  vmovaps xmm10, [rsp+0xA0]
000078f8213d562e  vmovaps xmm11, [rsp+0xB0]
000078f8213d5637  vmovaps xmm12, [rsp+0xC0]
000078f8213d5640  vmovaps xmm13, [rsp+0xD0]
000078f8213d5649  vmovaps xmm15, [rsp+0xE0]
000078f8213d5652  add rsp, 0xF0
000078f8213d5659  pop r11
000078f8213d565b  pop r10
000078f8213d565d  pop r9
000078f8213d565f  pop r8
000078f8213d5661  pop rsi
000078f8213d5662  pop rdi
000078f8213d5663  pop rdx
000078f8213d5664  pop rcx
000078f8213d5665  pop rax
000078f8213d5666  add rsp, 0x08
000078f8213d566a  jmp 0x000078F8213D031A
000078f8213d566f  sub rsp, 0x08
000078f8213d5673  push rax
000078f8213d5674  push rcx
000078f8213d5675  push rdx
000078f8213d5676  push rdi
000078f8213d5677  push rsi
000078f8213d5678  push r8
000078f8213d567a  push r9
000078f8213d567c  push r10
000078f8213d567e  push r11
000078f8213d5680  sub rsp, 0xF0
000078f8213d5687  vmovaps [rsp], xmm0
000078f8213d568c  vmovaps [rsp+0x10], xmm2
000078f8213d5692  vmovaps [rsp+0x20], xmm3
000078f8213d5698  vmovaps [rsp+0x30], xmm4
000078f8213d569e  vmovaps [rsp+0x40], xmm5
000078f8213d56a4  vmovaps [rsp+0x50], xmm6
000078f8213d56aa  vmovaps [rsp+0x60], xmm7
000078f8213d56b0  vmovaps [rsp+0x70], xmm8
000078f8213d56b6  vmovaps [rsp+0x80], xmm9
000078f8213d56bf  vmovaps [rsp+0x90], xmm10
000078f8213d56c8  vmovaps [rsp+0xA0], xmm11
000078f8213d56d1  vmovaps [rsp+0xB0], xmm12
000078f8213d56da  vmovaps [rsp+0xC0], xmm13
000078f8213d56e3  vmovaps [rsp+0xD0], xmm14
000078f8213d56ec  vmovaps [rsp+0xE0], xmm15
000078f8213d56f5  sub rsp, 0x30
000078f8213d56f9  movaps [rsp], xmm1
000078f8213d56fd  movaps [rsp+0x10], xmm7
000078f8213d5702  movaps [rsp+0x20], xmm11
000078f8213d5708  lea rdi, [rsp]
000078f8213d570c  mov esi, 0x00
000078f8213d5711  mov rax, 0x653D80F42530
000078f8213d571b  call rax
000078f8213d571d  movaps xmm1, [rsp]
000078f8213d5721  add rsp, 0x30
000078f8213d5725  vmovaps xmm0, [rsp]
000078f8213d572a  vmovaps xmm2, [rsp+0x10]
000078f8213d5730  vmovaps xmm3, [rsp+0x20]
000078f8213d5736  vmovaps xmm4, [rsp+0x30]
000078f8213d573c  vmovaps xmm5, [rsp+0x40]
000078f8213d5742  vmovaps xmm6, [rsp+0x50]
000078f8213d5748  vmovaps xmm7, [rsp+0x60]
000078f8213d574e  vmovaps xmm8, [rsp+0x70]
000078f8213d5754  vmovaps xmm9, [rsp+0x80]
000078f8213d575d  vmovaps xmm10, [rsp+0x90]
000078f8213d5766  vmovaps xmm11, [rsp+0xA0]
000078f8213d576f  vmovaps xmm12, [rsp+0xB0]
000078f8213d5778  vmovaps xmm13, [rsp+0xC0]
000078f8213d5781  vmovaps xmm14, [rsp+0xD0]
000078f8213d578a  vmovaps xmm15, [rsp+0xE0]
000078f8213d5793  add rsp, 0xF0
000078f8213d579a  pop r11
000078f8213d579c  pop r10
000078f8213d579e  pop r9
000078f8213d57a0  pop r8
000078f8213d57a2  pop rsi
000078f8213d57a3  pop rdi
000078f8213d57a4  pop rdx
000078f8213d57a5  pop rcx
000078f8213d57a6  pop rax
000078f8213d57a7  add rsp, 0x08
000078f8213d57ab  jmp 0x000078F8213D033B
000078f8213d57b0  call 0x000078F82120E880
000078f8213d57b5  jmp 0x000078F8213D034E
000078f8213d57ba  call 0x000078F82120C380
000078f8213d57bf  jmp 0x000078F8213D0359
000078f8213d57c4  call 0x000078F82120D600
000078f8213d57c9  jmp 0x000078F8213D0364
000078f8213d57ce  call 0x000078F8211FF540
000078f8213d57d3  jmp 0x000078F8213D036F
000078f8213d57d8  int3
000078f8213d57d9  nop [rax], eax
000078f8213d57e0  mov rax, [r15+0x40]
000078f8213d57e4  mov r14, [r15+0x58]
000078f8213d57e8  lea r12, [rax+r14*1]
000078f8213d57ec  movaps xmm1, [r15+0x1D0]
000078f8213d57f4  vmovaps [rsp+0x10], xmm1
000078f8213d57fa  vmovaps xmm15, [rsp+0x10]
000078f8213d5800  por xmm1, xmm15
000078f8213d5805  movaps xmm14, [r15+0x1A0]
000078f8213d580d  vmovaps [rsp+0x10], xmm14
000078f8213d5813  vmovaps xmm13, [rsp+0x10]
000078f8213d5819  por xmm14, xmm13
000078f8213d581e  lea rax, [r12+0x30]
000078f8213d5823  mov r11, [r13+rax*1]
000078f8213d5828  lea rax, [r12+0x38]
000078f8213d582d  mov r10, [r13+rax*1]
000078f8213d5832  movq xmm13, r11
000078f8213d5837  movq xmm12, r10
000078f8213d583c  movq xmm13, xmm13
000078f8213d5841  vmovaps [rsp+0x10], xmm13
000078f8213d5847  movq xmm13, xmm13
000078f8213d584c  movaps [r15+0x130], xmm13
000078f8213d5854  movq xmm12, xmm12
000078f8213d5859  vmovaps [rsp+0x20], xmm12
000078f8213d585f  movq xmm12, xmm12
000078f8213d5864  movaps [r15+0x280], xmm12
000078f8213d586c  movaps xmm13, [r15+0x270]
000078f8213d5874  vmovaps [rsp+0x30], xmm13
000078f8213d587a  vmovaps xmm12, [rsp+0x30]
000078f8213d5880  por xmm13, xmm12
000078f8213d5885  lea rax, [r12+0x20]
000078f8213d588a  mov r11, [r13+rax*1]
000078f8213d588f  lea rax, [r12+0x28]
000078f8213d5894  mov r10, [r13+rax*1]
000078f8213d5899  movq xmm12, r11
000078f8213d589e  movq xmm11, r10
000078f8213d58a3  movq xmm12, xmm12
000078f8213d58a8  vmovaps [rsp+0x30], xmm12
000078f8213d58ae  movq xmm12, xmm12
000078f8213d58b3  movaps [r15+0x150], xmm12
000078f8213d58bb  movq xmm11, xmm11
000078f8213d58c0  vmovaps [rsp+0x40], xmm11
000078f8213d58c6  movq xmm11, xmm11
000078f8213d58cb  movaps [r15+0x140], xmm11
000078f8213d58d3  lea rax, [r12+0x10]
000078f8213d58d8  mov r11, [r13+rax*1]
000078f8213d58dd  lea rax, [r12+0x18]
000078f8213d58e2  mov r10, [r13+rax*1]
000078f8213d58e7  movq xmm12, r11
000078f8213d58ec  movq xmm11, r10
000078f8213d58f1  movq xmm12, xmm12
000078f8213d58f6  vmovaps [rsp+0x50], xmm12
000078f8213d58fc  movq xmm12, xmm12
000078f8213d5901  movaps [r15+0x170], xmm12
000078f8213d5909  movq xmm11, xmm11
000078f8213d590e  vmovaps [rsp+0x60], xmm11
000078f8213d5914  movq xmm11, xmm11
000078f8213d5919  movaps [r15+0x160], xmm11
000078f8213d5921  mov rax, [r13+r12*1]
000078f8213d5926  vmovq xmm12, rax
000078f8213d592b  vpbroadcastq xmm12, xmm12
000078f8213d5930  lea rax, [r12+0x08]
000078f8213d5935  mov r12, [r13+rax*1]
000078f8213d593a  movq xmm11, r12
000078f8213d593f  movaps [r15+0x230], xmm11
000078f8213d5947  mov rax, [r15+0xF8]
000078f8213d594e  lea r12, [rax+0x50]
000078f8213d5952  movups xmm11, [r13+r12*1]
000078f8213d5958  lea r12, [rax+0x60]
000078f8213d595c  movups xmm10, [r13+r12*1]
000078f8213d5962  lea r12, [rax+0x30]
000078f8213d5966  movups xmm9, [r13+r12*1]
000078f8213d596c  mov r12, [r15+0x50]
000078f8213d5970  lea r11, [r12+r14*1]
000078f8213d5974  mov [r15+0x60], r11
000078f8213d5978  lea r12, [r14+0x40]
000078f8213d597c  mov [r15+0x58], r12
000078f8213d5980  movaps xmm8, xmm12
000078f8213d5984  mulpd xmm8, xmm15
000078f8213d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000078f8213d598f  ptest xmm7, xmm7
000078f8213d5994  jnz 0x000078F8213D67B7
000078f8213d599a  movq xmm15, qword ptr [r15+0x230]
000078f8213d59a3  vmovaps [rsp+0x70], xmm15
000078f8213d59a9  vpermilpd xmm15, xmm15, 0x00
000078f8213d59af  movaps xmm7, xmm9
000078f8213d59b3  mulpd xmm7, xmm15
000078f8213d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000078f8213d59bd  ptest xmm6, xmm6
000078f8213d59c2  jnz 0x000078F8213D68FB
000078f8213d59c8  vxorps xmm15, xmm15, xmm15
000078f8213d59cd  vpbroadcastq xmm15, xmm15
000078f8213d59d2  movaps xmm9, xmm12
000078f8213d59d6  mulpd xmm9, xmm10
000078f8213d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000078f8213d59e1  ptest xmm6, xmm6
000078f8213d59e6  jnz 0x000078F8213D6A3D
000078f8213d59ec  movaps xmm10, xmm12
000078f8213d59f0  mulpd xmm10, xmm11
000078f8213d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000078f8213d59fb  ptest xmm6, xmm6
000078f8213d5a00  jnz 0x000078F8213D6B81
000078f8213d5a06  movaps xmm11, [r15+0x1F0]
000078f8213d5a0e  movaps xmm6, xmm12
000078f8213d5a12  mulpd xmm6, xmm11
000078f8213d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000078f8213d5a1c  ptest xmm5, xmm5
000078f8213d5a21  jnz 0x000078F8213D6CC5
000078f8213d5a27  movaps xmm12, [r15+0x2A0]
000078f8213d5a2f  vmovaps [rsp+0x80], xmm12
000078f8213d5a38  vmovaps xmm11, [rsp+0x80]
000078f8213d5a41  por xmm12, xmm11
000078f8213d5a46  movaps xmm11, [r15+0x250]
000078f8213d5a4e  vmovaps [rsp+0x80], xmm11
000078f8213d5a57  vmovaps xmm5, [rsp+0x80]
000078f8213d5a60  por xmm11, xmm5
000078f8213d5a65  vmovaps xmm4, [rsp+0x70]
000078f8213d5a6b  vpermilpd xmm4, xmm4, 0x00
000078f8213d5a71  movaps xmm3, xmm5
000078f8213d5a74  mulpd xmm3, xmm4
000078f8213d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000078f8213d5a7d  ptest xmm2, xmm2
000078f8213d5a82  jnz 0x000078F8213D6E07
000078f8213d5a88  mov [rsp+0x80], rax
000078f8213d5a90  xor eax, eax
000078f8213d5a92  mov r14d, 0x200
000078f8213d5a98  cmp r12, r14
000078f8213d5a9b  cmc
000078f8213d5a9c  lahf
000078f8213d5a9d  seto al
000078f8213d5aa0  mov [r15+0x108], eax
000078f8213d5aa7  movaps xmm5, xmm8
000078f8213d5aab  addpd xmm5, xmm15
000078f8213d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000078f8213d5ab5  ptest xmm4, xmm4
000078f8213d5aba  jnz 0x000078F8213D6F47
000078f8213d5ac0  movaps xmm8, [r15+0x1B0]
000078f8213d5ac8  movaps xmm4, xmm9
000078f8213d5acc  addpd xmm4, xmm8
000078f8213d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000078f8213d5ad6  ptest xmm2, xmm2
000078f8213d5adb  jnz 0x000078F8213D7089
000078f8213d5ae1  movaps xmm9, xmm10
000078f8213d5ae5  addpd xmm9, xmm8
000078f8213d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000078f8213d5af0  ptest xmm2, xmm2
000078f8213d5af5  jnz 0x000078F8213D71CB
000078f8213d5afb  movaps xmm10, [r15+0x2F0]
000078f8213d5b03  vmovaps [rsp+0x90], xmm10
000078f8213d5b0c  vmovaps xmm8, [rsp+0x90]
000078f8213d5b15  por xmm10, xmm8
000078f8213d5b1a  movaps xmm8, [r15+0x2E0]
000078f8213d5b22  vmovaps [rsp+0x90], xmm8
000078f8213d5b2b  vmovaps xmm2, [rsp+0x90]
000078f8213d5b34  por xmm8, xmm2
000078f8213d5b39  movaps xmm2, [r15+0x2D0]
000078f8213d5b41  vmovaps [rsp+0x90], xmm2
000078f8213d5b4a  vmovaps [rsp+0xA0], xmm1
000078f8213d5b53  vmovaps xmm1, [rsp+0x90]
000078f8213d5b5c  por xmm2, xmm1
000078f8213d5b60  movaps xmm1, [r15+0x200]
000078f8213d5b68  vmovaps [rsp+0x90], xmm1
000078f8213d5b71  vmovaps [rsp+0xB0], xmm15
000078f8213d5b7a  vmovaps xmm15, [rsp+0x90]
000078f8213d5b83  por xmm1, xmm15
000078f8213d5b88  movaps xmm15, [r15+0x1C0]
000078f8213d5b90  vmovaps [rsp+0x90], xmm15
000078f8213d5b99  vmovaps [rsp+0xC0], xmm1
000078f8213d5ba2  vmovaps xmm1, [rsp+0x90]
000078f8213d5bab  por xmm15, xmm1
000078f8213d5bb0  movaps xmm1, [r15+0x190]
000078f8213d5bb8  vmovaps [rsp+0x90], xmm1
000078f8213d5bc1  vmovaps [rsp+0xD0], xmm15
000078f8213d5bca  vmovaps xmm15, [rsp+0x90]
000078f8213d5bd3  por xmm1, xmm15
000078f8213d5bd8  movaps xmm15, [r15+0x300]
000078f8213d5be0  vmovaps [rsp+0x90], xmm15
000078f8213d5be9  vmovaps [rsp+0xE0], xmm1
000078f8213d5bf2  vmovaps xmm1, [rsp+0x90]
000078f8213d5bfb  por xmm15, xmm1
000078f8213d5c00  mov rax, [rsp+0x80]
000078f8213d5c08  lea r14, [rax+0xA0]
000078f8213d5c0f  movups xmm1, [r13+r14*1]
000078f8213d5c15  lea r14, [rax+0xB0]
000078f8213d5c1c  vmovaps [rsp+0x80], xmm1
000078f8213d5c25  movups xmm1, [r13+r14*1]
000078f8213d5c2b  vmovaps [rsp+0x90], xmm1
000078f8213d5c34  vmovaps [rsp+0xF0], xmm15
000078f8213d5c3d  vmovaps xmm15, [rsp+0xB0]
000078f8213d5c46  vmovaps [rsp+0xB0], xmm14
000078f8213d5c4f  movaps xmm1, xmm6
000078f8213d5c52  addpd xmm1, xmm15
000078f8213d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000078f8213d5c5c  ptest xmm14, xmm14
000078f8213d5c62  jnz 0x000078F8213D7323
000078f8213d5c68  lea r14, [rax+0xF0]
000078f8213d5c6f  movups xmm15, [r13+r14*1]
000078f8213d5c75  movaps xmm14, xmm4
000078f8213d5c79  addpd xmm14, xmm3
000078f8213d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000078f8213d5c84  ptest xmm6, xmm6
000078f8213d5c89  jnz 0x000078F8213D746E
000078f8213d5c8f  movaps xmm6, xmm9
000078f8213d5c93  addpd xmm6, xmm7
000078f8213d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000078f8213d5c9c  ptest xmm4, xmm4
000078f8213d5ca1  jnz 0x000078F8213D75B0
000078f8213d5ca7  vmovaps xmm9, [rsp+0x70]
000078f8213d5cad  vpermilpd xmm9, xmm9, 0x00
000078f8213d5cb3  vmovaps xmm4, [rsp+0x90]
000078f8213d5cbc  movaps xmm7, xmm4
000078f8213d5cbf  mulpd xmm7, xmm9
000078f8213d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000078f8213d5cc9  ptest xmm3, xmm3
000078f8213d5cce  jnz 0x000078F8213D76F1
000078f8213d5cd4  vmovaps xmm9, [rsp+0x50]
000078f8213d5cda  vpermilpd xmm9, xmm9, 0x00
000078f8213d5ce0  movaps xmm4, xmm15
000078f8213d5ce4  mulpd xmm4, xmm9
000078f8213d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000078f8213d5cee  ptest xmm3, xmm3
000078f8213d5cf3  jnz 0x000078F8213D7832
000078f8213d5cf9  lea r14, [rax+0xE0]
000078f8213d5d00  movups xmm15, [r13+r14*1]
000078f8213d5d06  vmovaps xmm9, [rsp+0x70]
000078f8213d5d0c  vpermilpd xmm9, xmm9, 0x00
000078f8213d5d12  vmovaps [rsp+0x70], xmm1
000078f8213d5d18  vmovaps xmm1, [rsp+0x80]
000078f8213d5d21  vmovaps [rsp+0x80], xmm15
000078f8213d5d2a  movaps xmm3, xmm1
000078f8213d5d2d  mulpd xmm3, xmm9
000078f8213d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000078f8213d5d37  ptest xmm15, xmm15
000078f8213d5d3d  jnz 0x000078F8213D797E
000078f8213d5d43  vmovaps xmm1, [rsp+0xF0]
000078f8213d5d4c  vmovaps xmm15, [rsp+0xF0]
000078f8213d5d55  por xmm1, xmm15
000078f8213d5d5a  movaps [r15+0x300], xmm1
000078f8213d5d62  vmovaps xmm15, [rsp+0xE0]
000078f8213d5d6b  vmovaps xmm9, [rsp+0xE0]
000078f8213d5d74  por xmm15, xmm9
000078f8213d5d79  movaps [r15+0x190], xmm15
000078f8213d5d81  vmovaps xmm9, [rsp+0x50]
000078f8213d5d87  vpermilpd xmm9, xmm9, 0x00
000078f8213d5d8d  vmovaps [rsp+0x90], xmm1
000078f8213d5d96  vmovaps [rsp+0xE0], xmm15
000078f8213d5d9f  vmovaps xmm15, [rsp+0x80]
000078f8213d5da8  vmovaps [rsp+0x80], xmm14
000078f8213d5db1  movaps xmm1, xmm15
000078f8213d5db5  mulpd xmm1, xmm9
000078f8213d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000078f8213d5dbf  ptest xmm14, xmm14
000078f8213d5dc5  jnz 0x000078F8213D7ABF
000078f8213d5dcb  lea r14, [rax+0x90]
000078f8213d5dd2  movups xmm15, [r13+r14*1]
000078f8213d5dd8  vmovaps xmm14, [rsp+0xD0]
000078f8213d5de1  vmovaps xmm9, [rsp+0xD0]
000078f8213d5dea  por xmm14, xmm9
000078f8213d5def  movaps [r15+0x1C0], xmm14
000078f8213d5df7  vmovaps xmm9, [rsp+0xC0]
000078f8213d5e00  vmovaps [rsp+0xD0], xmm1
000078f8213d5e09  vmovaps xmm1, [rsp+0xC0]
000078f8213d5e12  por xmm9, xmm1
000078f8213d5e17  movaps [r15+0x200], xmm9
000078f8213d5e1f  vmovaps [rsp+0xC0], xmm2
000078f8213d5e28  vmovaps xmm1, [rsp+0xC0]
000078f8213d5e31  por xmm2, xmm1
000078f8213d5e35  movaps [r15+0x2D0], xmm2
000078f8213d5e3d  vmovaps [rsp+0xC0], xmm8
000078f8213d5e46  vmovaps xmm1, [rsp+0xC0]
000078f8213d5e4f  por xmm8, xmm1
000078f8213d5e54  movaps [r15+0x2E0], xmm8
000078f8213d5e5c  vmovaps [rsp+0xC0], xmm15
000078f8213d5e65  movaps xmm1, xmm5
000078f8213d5e68  addpd xmm1, xmm7
000078f8213d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000078f8213d5e71  ptest xmm15, xmm15
000078f8213d5e77  jnz 0x000078F8213D7C0B
000078f8213d5e7d  vmovaps xmm15, [rsp+0x50]
000078f8213d5e83  vpermilpd xmm15, xmm15, 0x00
000078f8213d5e89  vmovaps xmm5, [rsp+0xC0]
000078f8213d5e92  vmovaps [rsp+0xC0], xmm1
000078f8213d5e9b  movaps xmm7, xmm5
000078f8213d5e9e  mulpd xmm7, xmm15
000078f8213d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000078f8213d5ea8  ptest xmm1, xmm1
000078f8213d5ead  jnz 0x000078F8213D7D4B
000078f8213d5eb3  lea r14, [rax+0x80]
000078f8213d5eba  movups xmm1, [r13+r14*1]
000078f8213d5ec0  vmovaps xmm5, [rsp+0x70]
000078f8213d5ec6  vmovaps [rsp+0x70], xmm1
000078f8213d5ecc  movaps xmm15, xmm5
000078f8213d5ed0  addpd xmm15, xmm3
000078f8213d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000078f8213d5edb  ptest xmm1, xmm1
000078f8213d5ee0  jnz 0x000078F8213D7E96
000078f8213d5ee6  vmovaps xmm5, [rsp+0x80]
000078f8213d5eef  movaps xmm1, xmm5
000078f8213d5ef2  addpd xmm1, xmm4
000078f8213d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000078f8213d5efb  ptest xmm3, xmm3
000078f8213d5f00  jnz 0x000078F8213D7FD8
000078f8213d5f06  vmovaps [rsp+0x80], xmm10
000078f8213d5f0f  vmovaps xmm5, [rsp+0x80]
000078f8213d5f18  por xmm10, xmm5
000078f8213d5f1d  movaps [r15+0x2F0], xmm10
000078f8213d5f25  vmovaps xmm5, [rsp+0x50]
000078f8213d5f2b  vpermilpd xmm5, xmm5, 0x00
000078f8213d5f31  vmovaps xmm3, [rsp+0x70]
000078f8213d5f37  vmovaps [rsp+0x50], xmm1
000078f8213d5f3d  movaps xmm4, xmm3
000078f8213d5f40  mulpd xmm4, xmm5
000078f8213d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000078f8213d5f49  ptest xmm1, xmm1
000078f8213d5f4e  jnz 0x000078F8213D8118
000078f8213d5f54  lea r14, [rax+0xD0]
000078f8213d5f5b  movups xmm1, [r13+r14*1]
000078f8213d5f61  vmovaps xmm3, [rsp+0xD0]
000078f8213d5f6a  vmovaps [rsp+0x70], xmm1
000078f8213d5f70  movaps xmm5, xmm6
000078f8213d5f73  addpd xmm5, xmm3
000078f8213d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000078f8213d5f7c  ptest xmm1, xmm1
000078f8213d5f81  jnz 0x000078F8213D8262
000078f8213d5f87  vmovaps xmm1, [rsp+0x60]
000078f8213d5f8d  vpermilpd xmm1, xmm1, 0x00
000078f8213d5f93  movaps xmm6, xmm9
000078f8213d5f97  mulpd xmm6, xmm1
000078f8213d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000078f8213d5fa0  ptest xmm3, xmm3
000078f8213d5fa5  jnz 0x000078F8213D83A2
000078f8213d5fab  movaps [r15+0x260], xmm6
000078f8213d5fb3  vxorps xmm1, xmm1, xmm1
000078f8213d5fb7  vpbroadcastq xmm1, xmm1
000078f8213d5fbc  movaps [r15+0x1B0], xmm1
000078f8213d5fc4  vmovaps xmm1, [rsp+0x60]
000078f8213d5fca  vpermilpd xmm1, xmm1, 0x00
000078f8213d5fd0  vmovaps xmm3, [rsp+0x70]
000078f8213d5fd6  vmovaps [rsp+0x70], xmm15
000078f8213d5fdc  movaps xmm9, xmm3
000078f8213d5fe0  mulpd xmm9, xmm1
000078f8213d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000078f8213d5feb  ptest xmm15, xmm15
000078f8213d5ff1  jnz 0x000078F8213D84E3
000078f8213d5ff7  lea r14, [rax+0xC0]
000078f8213d5ffe  movups xmm1, [r13+r14*1]
000078f8213d6004  vmovaps xmm3, [rsp+0xC0]
000078f8213d600d  vmovaps [rsp+0x80], xmm1
000078f8213d6016  movaps xmm15, xmm3
000078f8213d601a  addpd xmm15, xmm7
000078f8213d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000078f8213d6025  ptest xmm1, xmm1
000078f8213d602a  jnz 0x000078F8213D862F
000078f8213d6030  vmovaps [rsp+0xC0], xmm13
000078f8213d6039  vmovaps xmm1, [rsp+0xC0]
000078f8213d6042  por xmm13, xmm1
000078f8213d6047  movaps [r15+0x270], xmm13
000078f8213d604f  vmovaps xmm1, [rsp+0xB0]
000078f8213d6058  vmovaps xmm7, [rsp+0xB0]
000078f8213d6061  por xmm1, xmm7
000078f8213d6065  movaps [r15+0x1A0], xmm1
000078f8213d606d  vmovaps xmm1, [rsp+0x60]
000078f8213d6073  vpermilpd xmm1, xmm1, 0x00
000078f8213d6079  vmovaps [rsp+0xB0], xmm1
000078f8213d6082  vmovaps xmm1, [rsp+0x80]
000078f8213d608b  vmovaps [rsp+0x80], xmm15
000078f8213d6094  vmovaps xmm15, [rsp+0xB0]
000078f8213d609d  vmovaps [rsp+0xB0], xmm14
000078f8213d60a6  movaps xmm3, xmm1
000078f8213d60a9  mulpd xmm3, xmm15
000078f8213d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000078f8213d60b3  ptest xmm14, xmm14
000078f8213d60b9  jnz 0x000078F8213D8771
000078f8213d60bf  lea r14, [rax+0x20]
000078f8213d60c3  movups xmm1, [r13+r14*1]
000078f8213d60c9  movaps [r15+0x110], xmm1
000078f8213d60d1  vmovaps xmm14, [rsp+0x70]
000078f8213d60d7  vmovaps [rsp+0x70], xmm1
000078f8213d60dd  movaps xmm15, xmm14
000078f8213d60e1  addpd xmm15, xmm4
000078f8213d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000078f8213d60ec  ptest xmm1, xmm1
000078f8213d60f1  jnz 0x000078F8213D88BC
000078f8213d60f7  vmovaps xmm1, [rsp+0x60]
000078f8213d60fd  vpermilpd xmm1, xmm1, 0x00
000078f8213d6103  movaps xmm14, xmm2
000078f8213d6107  mulpd xmm14, xmm1
000078f8213d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000078f8213d6112  ptest xmm4, xmm4
000078f8213d6117  jnz 0x000078F8213D89FF
000078f8213d611d  vmovaps xmm4, [rsp+0x50]
000078f8213d6123  movaps xmm1, xmm4
000078f8213d6126  addpd xmm1, xmm9
000078f8213d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000078f8213d6130  ptest xmm2, xmm2
000078f8213d6135  jnz 0x000078F8213D8B41
000078f8213d613b  vmovaps xmm9, [rsp+0x30]
000078f8213d6141  vpermilpd xmm9, xmm9, 0x00
000078f8213d6147  vmovaps xmm2, [rsp+0x70]
000078f8213d614d  vmovaps [rsp+0x50], xmm1
000078f8213d6153  movaps xmm4, xmm2
000078f8213d6156  mulpd xmm4, xmm9
000078f8213d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000078f8213d6160  ptest xmm1, xmm1
000078f8213d6165  jnz 0x000078F8213D8C82
000078f8213d616b  vmovaps xmm1, [rsp+0x30]
000078f8213d6171  vpermilpd xmm1, xmm1, 0x00
000078f8213d6177  vmovaps xmm2, [rsp+0x90]
000078f8213d6180  vmovaps [rsp+0x60], xmm15
000078f8213d6186  movaps xmm9, xmm2
000078f8213d618a  mulpd xmm9, xmm1
000078f8213d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000078f8213d6195  ptest xmm15, xmm15
000078f8213d619b  jnz 0x000078F8213D8DC3
000078f8213d61a1  vmovaps xmm15, [rsp+0x80]
000078f8213d61aa  movaps xmm1, xmm15
000078f8213d61ae  addpd xmm1, xmm6
000078f8213d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000078f8213d61b7  ptest xmm2, xmm2
000078f8213d61bc  jnz 0x000078F8213D8F05
000078f8213d61c2  movaps xmm15, xmm5
000078f8213d61c6  addpd xmm15, xmm3
000078f8213d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000078f8213d61d1  ptest xmm6, xmm6
000078f8213d61d6  jnz 0x000078F8213D9046
000078f8213d61dc  vmovaps xmm6, [rsp+0x30]
000078f8213d61e2  vpermilpd xmm6, xmm6, 0x00
000078f8213d61e8  movaps xmm5, xmm8
000078f8213d61ec  mulpd xmm5, xmm6
000078f8213d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000078f8213d61f5  ptest xmm3, xmm3
000078f8213d61fa  jnz 0x000078F8213D9188
000078f8213d6200  vmovaps xmm8, [rsp+0x30]
000078f8213d6206  vpermilpd xmm8, xmm8, 0x00
000078f8213d620c  movaps xmm6, xmm10
000078f8213d6210  mulpd xmm6, xmm8
000078f8213d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000078f8213d621a  ptest xmm3, xmm3
000078f8213d621f  jnz 0x000078F8213D92C9
000078f8213d6225  vmovaps xmm8, [rsp+0x60]
000078f8213d622b  movaps xmm10, xmm8
000078f8213d622f  addpd xmm10, xmm14
000078f8213d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000078f8213d623a  ptest xmm3, xmm3
000078f8213d623f  jnz 0x000078F8213D940B
000078f8213d6245  vmovaps xmm8, [rsp+0x50]
000078f8213d624b  movaps xmm14, xmm8
000078f8213d624f  addpd xmm14, xmm4
000078f8213d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000078f8213d625a  ptest xmm3, xmm3
000078f8213d625f  jnz 0x000078F8213D954F
000078f8213d6265  vmovaps xmm8, [rsp+0x40]
000078f8213d626b  vpermilpd xmm8, xmm8, 0x00
000078f8213d6271  movaps xmm4, xmm13
000078f8213d6275  mulpd xmm4, xmm8
000078f8213d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000078f8213d627f  ptest xmm3, xmm3
000078f8213d6284  jnz 0x000078F8213D9692
000078f8213d628a  movaps xmm13, xmm15
000078f8213d628e  addpd xmm13, xmm9
000078f8213d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000078f8213d6299  ptest xmm8, xmm8
000078f8213d629f  jnz 0x000078F8213D97D4
000078f8213d62a5  movaps xmm15, xmm1
000078f8213d62a9  addpd xmm15, xmm5
000078f8213d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000078f8213d62b4  ptest xmm9, xmm9
000078f8213d62ba  jnz 0x000078F8213D9918
000078f8213d62c0  vmovaps [rsp+0x30], xmm11
000078f8213d62c6  vmovaps xmm1, [rsp+0x30]
000078f8213d62cc  por xmm11, xmm1
000078f8213d62d1  movaps [r15+0x250], xmm11
000078f8213d62d9  vmovaps [rsp+0x30], xmm12
000078f8213d62df  vmovaps xmm1, [rsp+0x30]
000078f8213d62e5  por xmm12, xmm1
000078f8213d62ea  movaps [r15+0x2A0], xmm12
000078f8213d62f2  vmovaps xmm1, [rsp+0xA0]
000078f8213d62fb  vmovaps xmm11, [rsp+0xA0]
000078f8213d6304  por xmm1, xmm11
000078f8213d6309  movaps [r15+0x1D0], xmm1
000078f8213d6311  lea r14, [rax+0x40]
000078f8213d6315  movups xmm1, [r13+r14*1]
000078f8213d631b  movaps [r15+0x2C0], xmm1
000078f8213d6323  vmovaps xmm11, [rsp+0x40]
000078f8213d6329  vpermilpd xmm11, xmm11, 0x00
000078f8213d632f  vmovaps xmm8, [rsp+0xE0]
000078f8213d6338  movaps xmm9, xmm8
000078f8213d633c  mulpd xmm9, xmm11
000078f8213d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000078f8213d6347  ptest xmm5, xmm5
000078f8213d634c  jnz 0x000078F8213D9A64
000078f8213d6352  movaps xmm11, xmm10
000078f8213d6356  addpd xmm11, xmm6
000078f8213d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000078f8213d6361  ptest xmm8, xmm8
000078f8213d6367  jnz 0x000078F8213D9BA8
000078f8213d636d  movaps xmm10, xmm14
000078f8213d6371  addpd xmm10, xmm4
000078f8213d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000078f8213d637c  ptest xmm8, xmm8
000078f8213d6382  jnz 0x000078F8213D9CEB
000078f8213d6388  vmovaps xmm14, [rsp+0x40]
000078f8213d638e  vpermilpd xmm14, xmm14, 0x00
000078f8213d6394  movaps xmm8, xmm1
000078f8213d6398  mulpd xmm8, xmm14
000078f8213d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000078f8213d63a3  ptest xmm6, xmm6
000078f8213d63a8  jnz 0x000078F8213D9E2E
000078f8213d63ae  movaps xmm1, [r15+0x2B0]
000078f8213d63b6  vmovaps xmm14, [rsp+0x40]
000078f8213d63bc  vpermilpd xmm14, xmm14, 0x00
000078f8213d63c2  movaps xmm6, xmm1
000078f8213d63c5  mulpd xmm6, xmm14
000078f8213d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000078f8213d63cf  ptest xmm5, xmm5
000078f8213d63d4  jnz 0x000078F8213D9F71
000078f8213d63da  vmovaps xmm1, [rsp+0x10]
000078f8213d63e0  vpermilpd xmm1, xmm1, 0x00
000078f8213d63e6  movaps xmm14, xmm12
000078f8213d63ea  mulpd xmm14, xmm1
000078f8213d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000078f8213d63f5  ptest xmm5, xmm5
000078f8213d63fa  jnz 0x000078F8213DA0B2
000078f8213d6400  movaps xmm1, xmm13
000078f8213d6404  addpd xmm1, xmm9
000078f8213d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000078f8213d640e  ptest xmm12, xmm12
000078f8213d6414  jnz 0x000078F8213DA1F5
000078f8213d641a  vmovaps xmm13, [rsp+0x10]
000078f8213d6420  vpermilpd xmm13, xmm13, 0x00
000078f8213d6426  movaps xmm12, xmm7
000078f8213d642a  mulpd xmm12, xmm13
000078f8213d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000078f8213d6435  ptest xmm9, xmm9
000078f8213d643b  jnz 0x000078F8213DA337
000078f8213d6441  movaps xmm13, xmm15
000078f8213d6445  addpd xmm13, xmm8
000078f8213d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000078f8213d6450  ptest xmm9, xmm9
000078f8213d6456  jnz 0x000078F8213DA47A
000078f8213d645c  movaps xmm15, [r15+0x290]
000078f8213d6464  vmovaps xmm9, [rsp+0x10]
000078f8213d646a  vpermilpd xmm9, xmm9, 0x00
000078f8213d6470  movaps xmm8, xmm15
000078f8213d6474  mulpd xmm8, xmm9
000078f8213d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000078f8213d647f  ptest xmm7, xmm7
000078f8213d6484  jnz 0x000078F8213DA5BE
000078f8213d648a  movaps xmm15, xmm11
000078f8213d648e  addpd xmm15, xmm6
000078f8213d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000078f8213d6499  ptest xmm9, xmm9
000078f8213d649f  jnz 0x000078F8213DA702
000078f8213d64a5  movaps xmm11, [r15+0x1E0]
000078f8213d64ad  vmovaps xmm9, [rsp+0x10]
000078f8213d64b3  vpermilpd xmm9, xmm9, 0x00
000078f8213d64b9  movaps xmm7, xmm11
000078f8213d64bd  mulpd xmm7, xmm9
000078f8213d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000078f8213d64c7  ptest xmm6, xmm6
000078f8213d64cc  jnz 0x000078F8213DA845
000078f8213d64d2  movaps xmm11, xmm10
000078f8213d64d6  addpd xmm11, xmm14
000078f8213d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000078f8213d64e1  ptest xmm9, xmm9
000078f8213d64e7  jnz 0x000078F8213DA987
000078f8213d64ed  lea r14, [rax+0x70]
000078f8213d64f1  movups xmm14, [r13+r14*1]
000078f8213d64f7  movaps [r15+0x240], xmm14
000078f8213d64ff  movaps xmm10, xmm1
000078f8213d6503  addpd xmm10, xmm12
000078f8213d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000078f8213d650e  ptest xmm9, xmm9
000078f8213d6514  jnz 0x000078F8213DAAD5
000078f8213d651a  movaps [r15+0x170], xmm10
000078f8213d6522  vmovaps xmm1, [rsp+0x20]
000078f8213d6528  vpermilpd xmm1, xmm1, 0x00
000078f8213d652e  movaps xmm12, xmm14
000078f8213d6532  mulpd xmm12, xmm1
000078f8213d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000078f8213d653d  ptest xmm9, xmm9
000078f8213d6543  jnz 0x000078F8213DAC18
000078f8213d6549  vmovaps xmm1, [rsp+0x20]
000078f8213d654f  vpermilpd xmm1, xmm1, 0x00
000078f8213d6555  vmovaps xmm9, [rsp+0xB0]
000078f8213d655e  movaps xmm14, xmm9
000078f8213d6562  mulpd xmm14, xmm1
000078f8213d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000078f8213d656d  ptest xmm6, xmm6
000078f8213d6572  jnz 0x000078F8213DAD5B
000078f8213d6578  movaps [r15+0x180], xmm14
000078f8213d6580  movaps xmm1, xmm13
000078f8213d6584  addpd xmm1, xmm8
000078f8213d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000078f8213d658e  ptest xmm9, xmm9
000078f8213d6594  jnz 0x000078F8213DAE9E
000078f8213d659a  movaps [r15+0x210], xmm1
000078f8213d65a2  movups xmm13, [r13+rax*1]
000078f8213d65a8  lea r14, [rax+0x10]
000078f8213d65ac  movups xmm9, [r13+r14*1]
000078f8213d65b2  movaps [r15+0x230], xmm9
000078f8213d65ba  movaps xmm8, xmm15
000078f8213d65be  addpd xmm8, xmm7
000078f8213d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000078f8213d65c9  ptest xmm6, xmm6
000078f8213d65ce  jnz 0x000078F8213DAFF4
000078f8213d65d4  movaps [r15+0x130], xmm8
000078f8213d65dc  vmovaps xmm15, [rsp+0x20]
000078f8213d65e2  vpermilpd xmm15, xmm15, 0x00
000078f8213d65e8  movaps xmm7, xmm9
000078f8213d65ec  mulpd xmm7, xmm15
000078f8213d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000078f8213d65f6  ptest xmm6, xmm6
000078f8213d65fb  jnz 0x000078F8213DB137
000078f8213d6601  movaps [r15+0x220], xmm7
000078f8213d6609  vmovaps xmm15, [rsp+0x20]
000078f8213d660f  vpermilpd xmm15, xmm15, 0x00
000078f8213d6615  movaps xmm9, xmm13
000078f8213d6619  mulpd xmm9, xmm15
000078f8213d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000078f8213d6624  ptest xmm6, xmm6
000078f8213d6629  jnz 0x000078F8213DB279
000078f8213d662f  movaps xmm15, xmm11
000078f8213d6633  addpd xmm15, xmm12
000078f8213d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000078f8213d663e  ptest xmm13, xmm13
000078f8213d6644  jnz 0x000078F8213DB3BD
000078f8213d664a  movaps [r15+0x140], xmm15
000078f8213d6652  movaps xmm13, xmm10
000078f8213d6656  addpd xmm13, xmm14
000078f8213d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000078f8213d6661  ptest xmm12, xmm12
000078f8213d6667  jnz 0x000078F8213DB501
000078f8213d666d  movaps [r15+0x150], xmm13
000078f8213d6675  movaps xmm14, xmm1
000078f8213d6679  addpd xmm14, xmm7
000078f8213d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000078f8213d6684  ptest xmm12, xmm12
000078f8213d668a  jnz 0x000078F8213DB645
000078f8213d6690  movaps [r15+0x160], xmm14
000078f8213d6698  movaps xmm1, xmm8
000078f8213d669c  addpd xmm1, xmm9
000078f8213d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000078f8213d66a6  ptest xmm12, xmm12
000078f8213d66ac  jnz 0x000078F8213DB787
000078f8213d66b2  movaps [r15+0x120], xmm1
000078f8213d66ba  movups [r13+r11*1], xmm15
000078f8213d66c0  lea rax, [r11+0x10]
000078f8213d66c4  movups [r13+rax*1], xmm13
000078f8213d66ca  lea rax, [r11+0x20]
000078f8213d66ce  movups [r13+rax*1], xmm14
000078f8213d66d4  lea rax, [r11+0x30]
000078f8213d66d8  movups [r13+rax*1], xmm1
000078f8213d66de  mov eax, [r15+0x108]
000078f8213d66e5  sahf
000078f8213d66e6  jnz 0x000078F8213D6718
000078f8213d66e8  cmp dword ptr [r15+0x318], 0x00
000078f8213d66f0  jz 0x000078F8213DB900
000078f8213d66f6  nop [rax+rax*1], ax
000078f8213d66ff  nop [rax+rax*1], eax
000078f8213d6707  mov eax, 0x410444
000078f8213d670c  mov [r15+0x100], rax
000078f8213d6713  jmp 0x000078F8211FE110
000078f8213d6718  cmp dword ptr [r15+0x318], 0x00
000078f8213d6720  jz 0x000078F8213D57E0
000078f8213d6726  nop [rax+rax*1], ax
000078f8213d672f  nop [rax+rax*1], eax
000078f8213d6737  mov eax, 0x410278
000078f8213d673c  mov [r15+0x100], rax
000078f8213d6743  jmp 0x000078F8211FE110
000078f8213d6748  int3
000078f8213d6749  call 0x000078F82120A4B0
000078f8213d674e  jmp 0x000078F8213D5828
000078f8213d6753  call 0x000078F821209240
000078f8213d6758  jmp 0x000078F8213D5832
000078f8213d675d  call 0x000078F82120A4B0
000078f8213d6762  jmp 0x000078F8213D588F
000078f8213d6767  call 0x000078F821209240
000078f8213d676c  jmp 0x000078F8213D5899
000078f8213d6771  call 0x000078F82120A4B0
000078f8213d6776  jmp 0x000078F8213D58DD
000078f8213d677b  call 0x000078F821209240
000078f8213d6780  jmp 0x000078F8213D58E7
000078f8213d6785  call 0x000078F8212B47C0
000078f8213d678a  jmp 0x000078F8213D5926
000078f8213d678f  call 0x000078F82120B720
000078f8213d6794  jmp 0x000078F8213D593A
000078f8213d6799  call 0x000078F8212BFC30
000078f8213d679e  jmp 0x000078F8213D5958
000078f8213d67a3  call 0x000078F8212BE9C0
000078f8213d67a8  jmp 0x000078F8213D5962
000078f8213d67ad  call 0x000078F8212BD750
000078f8213d67b2  jmp 0x000078F8213D596C
000078f8213d67b7  sub rsp, 0x08
000078f8213d67bb  push rax
000078f8213d67bc  push rcx
000078f8213d67bd  push rdx
000078f8213d67be  push rdi
000078f8213d67bf  push rsi
000078f8213d67c0  push r8
000078f8213d67c2  push r9
000078f8213d67c4  push r10
000078f8213d67c6  push r11
000078f8213d67c8  sub rsp, 0xF0
000078f8213d67cf  vmovaps [rsp], xmm0
000078f8213d67d4  vmovaps [rsp+0x10], xmm1
000078f8213d67da  vmovaps [rsp+0x20], xmm2
000078f8213d67e0  vmovaps [rsp+0x30], xmm3
000078f8213d67e6  vmovaps [rsp+0x40], xmm4
000078f8213d67ec  vmovaps [rsp+0x50], xmm5
000078f8213d67f2  vmovaps [rsp+0x60], xmm6
000078f8213d67f8  vmovaps [rsp+0x70], xmm7
000078f8213d67fe  vmovaps [rsp+0x80], xmm9
000078f8213d6807  vmovaps [rsp+0x90], xmm10
000078f8213d6810  vmovaps [rsp+0xA0], xmm11
000078f8213d6819  vmovaps [rsp+0xB0], xmm12
000078f8213d6822  vmovaps [rsp+0xC0], xmm13
000078f8213d682b  vmovaps [rsp+0xD0], xmm14
000078f8213d6834  vmovaps [rsp+0xE0], xmm15
000078f8213d683d  sub rsp, 0x30
000078f8213d6841  movaps [rsp], xmm8
000078f8213d6846  movaps [rsp+0x10], xmm12
000078f8213d684c  movaps [rsp+0x20], xmm15
000078f8213d6852  lea rdi, [rsp]
000078f8213d6856  mov esi, 0x00
000078f8213d685b  mov rax, 0x653D80F42530
000078f8213d6865  call rax
000078f8213d6867  movaps xmm8, [rsp]
000078f8213d686c  add rsp, 0x30
000078f8213d6870  vmovaps xmm0, [rsp]
000078f8213d6875  vmovaps xmm1, [rsp+0x10]
000078f8213d687b  vmovaps xmm2, [rsp+0x20]
000078f8213d6881  vmovaps xmm3, [rsp+0x30]
000078f8213d6887  vmovaps xmm4, [rsp+0x40]
000078f8213d688d  vmovaps xmm5, [rsp+0x50]
000078f8213d6893  vmovaps xmm6, [rsp+0x60]
000078f8213d6899  vmovaps xmm7, [rsp+0x70]
000078f8213d689f  vmovaps xmm9, [rsp+0x80]
000078f8213d68a8  vmovaps xmm10, [rsp+0x90]
000078f8213d68b1  vmovaps xmm11, [rsp+0xA0]
000078f8213d68ba  vmovaps xmm12, [rsp+0xB0]
000078f8213d68c3  vmovaps xmm13, [rsp+0xC0]
000078f8213d68cc  vmovaps xmm14, [rsp+0xD0]
000078f8213d68d5  vmovaps xmm15, [rsp+0xE0]
000078f8213d68de  add rsp, 0xF0
000078f8213d68e5  pop r11
000078f8213d68e7  pop r10
000078f8213d68e9  pop r9
000078f8213d68eb  pop r8
000078f8213d68ed  pop rsi
000078f8213d68ee  pop rdi
000078f8213d68ef  pop rdx
000078f8213d68f0  pop rcx
000078f8213d68f1  pop rax
000078f8213d68f2  add rsp, 0x08
000078f8213d68f6  jmp 0x000078F8213D599A
000078f8213d68fb  sub rsp, 0x08
000078f8213d68ff  push rax
000078f8213d6900  push rcx
000078f8213d6901  push rdx
000078f8213d6902  push rdi
000078f8213d6903  push rsi
000078f8213d6904  push r8
000078f8213d6906  push r9
000078f8213d6908  push r10
000078f8213d690a  push r11
000078f8213d690c  sub rsp, 0xF0
000078f8213d6913  vmovaps [rsp], xmm0
000078f8213d6918  vmovaps [rsp+0x10], xmm1
000078f8213d691e  vmovaps [rsp+0x20], xmm2
000078f8213d6924  vmovaps [rsp+0x30], xmm3
000078f8213d692a  vmovaps [rsp+0x40], xmm4
000078f8213d6930  vmovaps [rsp+0x50], xmm5
000078f8213d6936  vmovaps [rsp+0x60], xmm6
000078f8213d693c  vmovaps [rsp+0x70], xmm8
000078f8213d6942  vmovaps [rsp+0x80], xmm9
000078f8213d694b  vmovaps [rsp+0x90], xmm10
000078f8213d6954  vmovaps [rsp+0xA0], xmm11
000078f8213d695d  vmovaps [rsp+0xB0], xmm12
000078f8213d6966  vmovaps [rsp+0xC0], xmm13
000078f8213d696f  vmovaps [rsp+0xD0], xmm14
000078f8213d6978  vmovaps [rsp+0xE0], xmm15
000078f8213d6981  sub rsp, 0x30
000078f8213d6985  movaps [rsp], xmm7
000078f8213d6989  movaps [rsp+0x10], xmm9
000078f8213d698f  movaps [rsp+0x20], xmm15
000078f8213d6995  lea rdi, [rsp]
000078f8213d6999  mov esi, 0x00
000078f8213d699e  mov rax, 0x653D80F42530
000078f8213d69a8  call rax
000078f8213d69aa  movaps xmm7, [rsp]
000078f8213d69ae  add rsp, 0x30
000078f8213d69b2  vmovaps xmm0, [rsp]
000078f8213d69b7  vmovaps xmm1, [rsp+0x10]
000078f8213d69bd  vmovaps xmm2, [rsp+0x20]
000078f8213d69c3  vmovaps xmm3, [rsp+0x30]
000078f8213d69c9  vmovaps xmm4, [rsp+0x40]
000078f8213d69cf  vmovaps xmm5, [rsp+0x50]
000078f8213d69d5  vmovaps xmm6, [rsp+0x60]
000078f8213d69db  vmovaps xmm8, [rsp+0x70]
000078f8213d69e1  vmovaps xmm9, [rsp+0x80]
000078f8213d69ea  vmovaps xmm10, [rsp+0x90]
000078f8213d69f3  vmovaps xmm11, [rsp+0xA0]
000078f8213d69fc  vmovaps xmm12, [rsp+0xB0]
000078f8213d6a05  vmovaps xmm13, [rsp+0xC0]
000078f8213d6a0e  vmovaps xmm14, [rsp+0xD0]
000078f8213d6a17  vmovaps xmm15, [rsp+0xE0]
000078f8213d6a20  add rsp, 0xF0
000078f8213d6a27  pop r11
000078f8213d6a29  pop r10
000078f8213d6a2b  pop r9
000078f8213d6a2d  pop r8
000078f8213d6a2f  pop rsi
000078f8213d6a30  pop rdi
000078f8213d6a31  pop rdx
000078f8213d6a32  pop rcx
000078f8213d6a33  pop rax
000078f8213d6a34  add rsp, 0x08
000078f8213d6a38  jmp 0x000078F8213D59C8
000078f8213d6a3d  sub rsp, 0x08
000078f8213d6a41  push rax
000078f8213d6a42  push rcx
000078f8213d6a43  push rdx
000078f8213d6a44  push rdi
000078f8213d6a45  push rsi
000078f8213d6a46  push r8
000078f8213d6a48  push r9
000078f8213d6a4a  push r10
000078f8213d6a4c  push r11
000078f8213d6a4e  sub rsp, 0xF0
000078f8213d6a55  vmovaps [rsp], xmm0
000078f8213d6a5a  vmovaps [rsp+0x10], xmm1
000078f8213d6a60  vmovaps [rsp+0x20], xmm2
000078f8213d6a66  vmovaps [rsp+0x30], xmm3
000078f8213d6a6c  vmovaps [rsp+0x40], xmm4
000078f8213d6a72  vmovaps [rsp+0x50], xmm5
000078f8213d6a78  vmovaps [rsp+0x60], xmm6
000078f8213d6a7e  vmovaps [rsp+0x70], xmm7
000078f8213d6a84  vmovaps [rsp+0x80], xmm8
000078f8213d6a8d  vmovaps [rsp+0x90], xmm10
000078f8213d6a96  vmovaps [rsp+0xA0], xmm11
000078f8213d6a9f  vmovaps [rsp+0xB0], xmm12
000078f8213d6aa8  vmovaps [rsp+0xC0], xmm13
000078f8213d6ab1  vmovaps [rsp+0xD0], xmm14
000078f8213d6aba  vmovaps [rsp+0xE0], xmm15
000078f8213d6ac3  sub rsp, 0x30
000078f8213d6ac7  movaps [rsp], xmm9
000078f8213d6acc  movaps [rsp+0x10], xmm12
000078f8213d6ad2  movaps [rsp+0x20], xmm10
000078f8213d6ad8  lea rdi, [rsp]
000078f8213d6adc  mov esi, 0x00
000078f8213d6ae1  mov rax, 0x653D80F42530
000078f8213d6aeb  call rax
000078f8213d6aed  movaps xmm9, [rsp]
000078f8213d6af2  add rsp, 0x30
000078f8213d6af6  vmovaps xmm0, [rsp]
000078f8213d6afb  vmovaps xmm1, [rsp+0x10]
000078f8213d6b01  vmovaps xmm2, [rsp+0x20]
000078f8213d6b07  vmovaps xmm3, [rsp+0x30]
000078f8213d6b0d  vmovaps xmm4, [rsp+0x40]
000078f8213d6b13  vmovaps xmm5, [rsp+0x50]
000078f8213d6b19  vmovaps xmm6, [rsp+0x60]
000078f8213d6b1f  vmovaps xmm7, [rsp+0x70]
000078f8213d6b25  vmovaps xmm8, [rsp+0x80]
000078f8213d6b2e  vmovaps xmm10, [rsp+0x90]
000078f8213d6b37  vmovaps xmm11, [rsp+0xA0]
000078f8213d6b40  vmovaps xmm12, [rsp+0xB0]
000078f8213d6b49  vmovaps xmm13, [rsp+0xC0]
000078f8213d6b52  vmovaps xmm14, [rsp+0xD0]
000078f8213d6b5b  vmovaps xmm15, [rsp+0xE0]
000078f8213d6b64  add rsp, 0xF0
000078f8213d6b6b  pop r11
000078f8213d6b6d  pop r10
000078f8213d6b6f  pop r9
000078f8213d6b71  pop r8
000078f8213d6b73  pop rsi
000078f8213d6b74  pop rdi
000078f8213d6b75  pop rdx
000078f8213d6b76  pop rcx
000078f8213d6b77  pop rax
000078f8213d6b78  add rsp, 0x08
000078f8213d6b7c  jmp 0x000078F8213D59EC
000078f8213d6b81  sub rsp, 0x08
000078f8213d6b85  push rax
000078f8213d6b86  push rcx
000078f8213d6b87  push rdx
000078f8213d6b88  push rdi
000078f8213d6b89  push rsi
000078f8213d6b8a  push r8
000078f8213d6b8c  push r9
000078f8213d6b8e  push r10
000078f8213d6b90  push r11
000078f8213d6b92  sub rsp, 0xF0
000078f8213d6b99  vmovaps [rsp], xmm0
000078f8213d6b9e  vmovaps [rsp+0x10], xmm1
000078f8213d6ba4  vmovaps [rsp+0x20], xmm2
000078f8213d6baa  vmovaps [rsp+0x30], xmm3
000078f8213d6bb0  vmovaps [rsp+0x40], xmm4
000078f8213d6bb6  vmovaps [rsp+0x50], xmm5
000078f8213d6bbc  vmovaps [rsp+0x60], xmm6
000078f8213d6bc2  vmovaps [rsp+0x70], xmm7
000078f8213d6bc8  vmovaps [rsp+0x80], xmm8
000078f8213d6bd1  vmovaps [rsp+0x90], xmm9
000078f8213d6bda  vmovaps [rsp+0xA0], xmm11
000078f8213d6be3  vmovaps [rsp+0xB0], xmm12
000078f8213d6bec  vmovaps [rsp+0xC0], xmm13
000078f8213d6bf5  vmovaps [rsp+0xD0], xmm14
000078f8213d6bfe  vmovaps [rsp+0xE0], xmm15
000078f8213d6c07  sub rsp, 0x30
000078f8213d6c0b  movaps [rsp], xmm10
000078f8213d6c10  movaps [rsp+0x10], xmm12
000078f8213d6c16  movaps [rsp+0x20], xmm11
000078f8213d6c1c  lea rdi, [rsp]
000078f8213d6c20  mov esi, 0x00
000078f8213d6c25  mov rax, 0x653D80F42530
000078f8213d6c2f  call rax
000078f8213d6c31  movaps xmm10, [rsp]
000078f8213d6c36  add rsp, 0x30
000078f8213d6c3a  vmovaps xmm0, [rsp]
000078f8213d6c3f  vmovaps xmm1, [rsp+0x10]
000078f8213d6c45  vmovaps xmm2, [rsp+0x20]
000078f8213d6c4b  vmovaps xmm3, [rsp+0x30]
000078f8213d6c51  vmovaps xmm4, [rsp+0x40]
000078f8213d6c57  vmovaps xmm5, [rsp+0x50]
000078f8213d6c5d  vmovaps xmm6, [rsp+0x60]
000078f8213d6c63  vmovaps xmm7, [rsp+0x70]
000078f8213d6c69  vmovaps xmm8, [rsp+0x80]
000078f8213d6c72  vmovaps xmm9, [rsp+0x90]
000078f8213d6c7b  vmovaps xmm11, [rsp+0xA0]
000078f8213d6c84  vmovaps xmm12, [rsp+0xB0]
000078f8213d6c8d  vmovaps xmm13, [rsp+0xC0]
000078f8213d6c96  vmovaps xmm14, [rsp+0xD0]
000078f8213d6c9f  vmovaps xmm15, [rsp+0xE0]
000078f8213d6ca8  add rsp, 0xF0
000078f8213d6caf  pop r11
000078f8213d6cb1  pop r10
000078f8213d6cb3  pop r9
000078f8213d6cb5  pop r8
000078f8213d6cb7  pop rsi
000078f8213d6cb8  pop rdi
000078f8213d6cb9  pop rdx
000078f8213d6cba  pop rcx
000078f8213d6cbb  pop rax
000078f8213d6cbc  add rsp, 0x08
000078f8213d6cc0  jmp 0x000078F8213D5A06
000078f8213d6cc5  sub rsp, 0x08
000078f8213d6cc9  push rax
000078f8213d6cca  push rcx
000078f8213d6ccb  push rdx
000078f8213d6ccc  push rdi
000078f8213d6ccd  push rsi
000078f8213d6cce  push r8
000078f8213d6cd0  push r9
000078f8213d6cd2  push r10
000078f8213d6cd4  push r11
000078f8213d6cd6  sub rsp, 0xF0
000078f8213d6cdd  vmovaps [rsp], xmm0
000078f8213d6ce2  vmovaps [rsp+0x10], xmm1
000078f8213d6ce8  vmovaps [rsp+0x20], xmm2
000078f8213d6cee  vmovaps [rsp+0x30], xmm3
000078f8213d6cf4  vmovaps [rsp+0x40], xmm4
000078f8213d6cfa  vmovaps [rsp+0x50], xmm5
000078f8213d6d00  vmovaps [rsp+0x60], xmm7
000078f8213d6d06  vmovaps [rsp+0x70], xmm8
000078f8213d6d0c  vmovaps [rsp+0x80], xmm9
000078f8213d6d15  vmovaps [rsp+0x90], xmm10
000078f8213d6d1e  vmovaps [rsp+0xA0], xmm11
000078f8213d6d27  vmovaps [rsp+0xB0], xmm12
000078f8213d6d30  vmovaps [rsp+0xC0], xmm13
000078f8213d6d39  vmovaps [rsp+0xD0], xmm14
000078f8213d6d42  vmovaps [rsp+0xE0], xmm15
000078f8213d6d4b  sub rsp, 0x30
000078f8213d6d4f  movaps [rsp], xmm6
000078f8213d6d53  movaps [rsp+0x10], xmm12
000078f8213d6d59  movaps [rsp+0x20], xmm11
000078f8213d6d5f  lea rdi, [rsp]
000078f8213d6d63  mov esi, 0x00
000078f8213d6d68  mov rax, 0x653D80F42530
000078f8213d6d72  call rax
000078f8213d6d74  movaps xmm6, [rsp]
000078f8213d6d78  add rsp, 0x30
000078f8213d6d7c  vmovaps xmm0, [rsp]
000078f8213d6d81  vmovaps xmm1, [rsp+0x10]
000078f8213d6d87  vmovaps xmm2, [rsp+0x20]
000078f8213d6d8d  vmovaps xmm3, [rsp+0x30]
000078f8213d6d93  vmovaps xmm4, [rsp+0x40]
000078f8213d6d99  vmovaps xmm5, [rsp+0x50]
000078f8213d6d9f  vmovaps xmm7, [rsp+0x60]
000078f8213d6da5  vmovaps xmm8, [rsp+0x70]
000078f8213d6dab  vmovaps xmm9, [rsp+0x80]
000078f8213d6db4  vmovaps xmm10, [rsp+0x90]
000078f8213d6dbd  vmovaps xmm11, [rsp+0xA0]
000078f8213d6dc6  vmovaps xmm12, [rsp+0xB0]
000078f8213d6dcf  vmovaps xmm13, [rsp+0xC0]
000078f8213d6dd8  vmovaps xmm14, [rsp+0xD0]
000078f8213d6de1  vmovaps xmm15, [rsp+0xE0]
000078f8213d6dea  add rsp, 0xF0
000078f8213d6df1  pop r11
000078f8213d6df3  pop r10
000078f8213d6df5  pop r9
000078f8213d6df7  pop r8
000078f8213d6df9  pop rsi
000078f8213d6dfa  pop rdi
000078f8213d6dfb  pop rdx
000078f8213d6dfc  pop rcx
000078f8213d6dfd  pop rax
000078f8213d6dfe  add rsp, 0x08
000078f8213d6e02  jmp 0x000078F8213D5A27
000078f8213d6e07  sub rsp, 0x08
000078f8213d6e0b  push rax
000078f8213d6e0c  push rcx
000078f8213d6e0d  push rdx
000078f8213d6e0e  push rdi
000078f8213d6e0f  push rsi
000078f8213d6e10  push r8
000078f8213d6e12  push r9
000078f8213d6e14  push r10
000078f8213d6e16  push r11
000078f8213d6e18  sub rsp, 0xF0
000078f8213d6e1f  vmovaps [rsp], xmm0
000078f8213d6e24  vmovaps [rsp+0x10], xmm1
000078f8213d6e2a  vmovaps [rsp+0x20], xmm2
000078f8213d6e30  vmovaps [rsp+0x30], xmm4
000078f8213d6e36  vmovaps [rsp+0x40], xmm5
000078f8213d6e3c  vmovaps [rsp+0x50], xmm6
000078f8213d6e42  vmovaps [rsp+0x60], xmm7
000078f8213d6e48  vmovaps [rsp+0x70], xmm8
000078f8213d6e4e  vmovaps [rsp+0x80], xmm9
000078f8213d6e57  vmovaps [rsp+0x90], xmm10
000078f8213d6e60  vmovaps [rsp+0xA0], xmm11
000078f8213d6e69  vmovaps [rsp+0xB0], xmm12
000078f8213d6e72  vmovaps [rsp+0xC0], xmm13
000078f8213d6e7b  vmovaps [rsp+0xD0], xmm14
000078f8213d6e84  vmovaps [rsp+0xE0], xmm15
000078f8213d6e8d  sub rsp, 0x30
000078f8213d6e91  movaps [rsp], xmm3
000078f8213d6e95  movaps [rsp+0x10], xmm5
000078f8213d6e9a  movaps [rsp+0x20], xmm4
000078f8213d6e9f  lea rdi, [rsp]
000078f8213d6ea3  mov esi, 0x00
000078f8213d6ea8  mov rax, 0x653D80F42530
000078f8213d6eb2  call rax
000078f8213d6eb4  movaps xmm3, [rsp]
000078f8213d6eb8  add rsp, 0x30
000078f8213d6ebc  vmovaps xmm0, [rsp]
000078f8213d6ec1  vmovaps xmm1, [rsp+0x10]
000078f8213d6ec7  vmovaps xmm2, [rsp+0x20]
000078f8213d6ecd  vmovaps xmm4, [rsp+0x30]
000078f8213d6ed3  vmovaps xmm5, [rsp+0x40]
000078f8213d6ed9  vmovaps xmm6, [rsp+0x50]
000078f8213d6edf  vmovaps xmm7, [rsp+0x60]
000078f8213d6ee5  vmovaps xmm8, [rsp+0x70]
000078f8213d6eeb  vmovaps xmm9, [rsp+0x80]
000078f8213d6ef4  vmovaps xmm10, [rsp+0x90]
000078f8213d6efd  vmovaps xmm11, [rsp+0xA0]
000078f8213d6f06  vmovaps xmm12, [rsp+0xB0]
000078f8213d6f0f  vmovaps xmm13, [rsp+0xC0]
000078f8213d6f18  vmovaps xmm14, [rsp+0xD0]
000078f8213d6f21  vmovaps xmm15, [rsp+0xE0]
000078f8213d6f2a  add rsp, 0xF0
000078f8213d6f31  pop r11
000078f8213d6f33  pop r10
000078f8213d6f35  pop r9
000078f8213d6f37  pop r8
000078f8213d6f39  pop rsi
000078f8213d6f3a  pop rdi
000078f8213d6f3b  pop rdx
000078f8213d6f3c  pop rcx
000078f8213d6f3d  pop rax
000078f8213d6f3e  add rsp, 0x08
000078f8213d6f42  jmp 0x000078F8213D5A88
000078f8213d6f47  sub rsp, 0x08
000078f8213d6f4b  push rax
000078f8213d6f4c  push rcx
000078f8213d6f4d  push rdx
000078f8213d6f4e  push rdi
000078f8213d6f4f  push rsi
000078f8213d6f50  push r8
000078f8213d6f52  push r9
000078f8213d6f54  push r10
000078f8213d6f56  push r11
000078f8213d6f58  sub rsp, 0xF0
000078f8213d6f5f  vmovaps [rsp], xmm0
000078f8213d6f64  vmovaps [rsp+0x10], xmm1
000078f8213d6f6a  vmovaps [rsp+0x20], xmm2
000078f8213d6f70  vmovaps [rsp+0x30], xmm3
000078f8213d6f76  vmovaps [rsp+0x40], xmm4
000078f8213d6f7c  vmovaps [rsp+0x50], xmm6
000078f8213d6f82  vmovaps [rsp+0x60], xmm7
000078f8213d6f88  vmovaps [rsp+0x70], xmm8
000078f8213d6f8e  vmovaps [rsp+0x80], xmm9
000078f8213d6f97  vmovaps [rsp+0x90], xmm10
000078f8213d6fa0  vmovaps [rsp+0xA0], xmm11
000078f8213d6fa9  vmovaps [rsp+0xB0], xmm12
000078f8213d6fb2  vmovaps [rsp+0xC0], xmm13
000078f8213d6fbb  vmovaps [rsp+0xD0], xmm14
000078f8213d6fc4  vmovaps [rsp+0xE0], xmm15
000078f8213d6fcd  sub rsp, 0x30
000078f8213d6fd1  movaps [rsp], xmm5
000078f8213d6fd5  movaps [rsp+0x10], xmm8
000078f8213d6fdb  movaps [rsp+0x20], xmm15
000078f8213d6fe1  lea rdi, [rsp]
000078f8213d6fe5  mov esi, 0x00
000078f8213d6fea  mov rax, 0x653D80F42530
000078f8213d6ff4  call rax
000078f8213d6ff6  movaps xmm5, [rsp]
000078f8213d6ffa  add rsp, 0x30
000078f8213d6ffe  vmovaps xmm0, [rsp]
000078f8213d7003  vmovaps xmm1, [rsp+0x10]
000078f8213d7009  vmovaps xmm2, [rsp+0x20]
000078f8213d700f  vmovaps xmm3, [rsp+0x30]
000078f8213d7015  vmovaps xmm4, [rsp+0x40]
000078f8213d701b  vmovaps xmm6, [rsp+0x50]
000078f8213d7021  vmovaps xmm7, [rsp+0x60]
000078f8213d7027  vmovaps xmm8, [rsp+0x70]
000078f8213d702d  vmovaps xmm9, [rsp+0x80]
000078f8213d7036  vmovaps xmm10, [rsp+0x90]
000078f8213d703f  vmovaps xmm11, [rsp+0xA0]
000078f8213d7048  vmovaps xmm12, [rsp+0xB0]
000078f8213d7051  vmovaps xmm13, [rsp+0xC0]
000078f8213d705a  vmovaps xmm14, [rsp+0xD0]
000078f8213d7063  vmovaps xmm15, [rsp+0xE0]
000078f8213d706c  add rsp, 0xF0
000078f8213d7073  pop r11
000078f8213d7075  pop r10
000078f8213d7077  pop r9
000078f8213d7079  pop r8
000078f8213d707b  pop rsi
000078f8213d707c  pop rdi
000078f8213d707d  pop rdx
000078f8213d707e  pop rcx
000078f8213d707f  pop rax
000078f8213d7080  add rsp, 0x08
000078f8213d7084  jmp 0x000078F8213D5AC0
000078f8213d7089  sub rsp, 0x08
000078f8213d708d  push rax
000078f8213d708e  push rcx
000078f8213d708f  push rdx
000078f8213d7090  push rdi
000078f8213d7091  push rsi
000078f8213d7092  push r8
000078f8213d7094  push r9
000078f8213d7096  push r10
000078f8213d7098  push r11
000078f8213d709a  sub rsp, 0xF0
000078f8213d70a1  vmovaps [rsp], xmm0
000078f8213d70a6  vmovaps [rsp+0x10], xmm1
000078f8213d70ac  vmovaps [rsp+0x20], xmm2
000078f8213d70b2  vmovaps [rsp+0x30], xmm3
000078f8213d70b8  vmovaps [rsp+0x40], xmm5
000078f8213d70be  vmovaps [rsp+0x50], xmm6
000078f8213d70c4  vmovaps [rsp+0x60], xmm7
000078f8213d70ca  vmovaps [rsp+0x70], xmm8
000078f8213d70d0  vmovaps [rsp+0x80], xmm9
000078f8213d70d9  vmovaps [rsp+0x90], xmm10
000078f8213d70e2  vmovaps [rsp+0xA0], xmm11
000078f8213d70eb  vmovaps [rsp+0xB0], xmm12
000078f8213d70f4  vmovaps [rsp+0xC0], xmm13
000078f8213d70fd  vmovaps [rsp+0xD0], xmm14
000078f8213d7106  vmovaps [rsp+0xE0], xmm15
000078f8213d710f  sub rsp, 0x30
000078f8213d7113  movaps [rsp], xmm4
000078f8213d7117  movaps [rsp+0x10], xmm9
000078f8213d711d  movaps [rsp+0x20], xmm8
000078f8213d7123  lea rdi, [rsp]
000078f8213d7127  mov esi, 0x00
000078f8213d712c  mov rax, 0x653D80F42530
000078f8213d7136  call rax
000078f8213d7138  movaps xmm4, [rsp]
000078f8213d713c  add rsp, 0x30
000078f8213d7140  vmovaps xmm0, [rsp]
000078f8213d7145  vmovaps xmm1, [rsp+0x10]
000078f8213d714b  vmovaps xmm2, [rsp+0x20]
000078f8213d7151  vmovaps xmm3, [rsp+0x30]
000078f8213d7157  vmovaps xmm5, [rsp+0x40]
000078f8213d715d  vmovaps xmm6, [rsp+0x50]
000078f8213d7163  vmovaps xmm7, [rsp+0x60]
000078f8213d7169  vmovaps xmm8, [rsp+0x70]
000078f8213d716f  vmovaps xmm9, [rsp+0x80]
000078f8213d7178  vmovaps xmm10, [rsp+0x90]
000078f8213d7181  vmovaps xmm11, [rsp+0xA0]
000078f8213d718a  vmovaps xmm12, [rsp+0xB0]
000078f8213d7193  vmovaps xmm13, [rsp+0xC0]
000078f8213d719c  vmovaps xmm14, [rsp+0xD0]
000078f8213d71a5  vmovaps xmm15, [rsp+0xE0]
000078f8213d71ae  add rsp, 0xF0
000078f8213d71b5  pop r11
000078f8213d71b7  pop r10
000078f8213d71b9  pop r9
000078f8213d71bb  pop r8
000078f8213d71bd  pop rsi
000078f8213d71be  pop rdi
000078f8213d71bf  pop rdx
000078f8213d71c0  pop rcx
000078f8213d71c1  pop rax
000078f8213d71c2  add rsp, 0x08
000078f8213d71c6  jmp 0x000078F8213D5AE1
000078f8213d71cb  sub rsp, 0x08
000078f8213d71cf  push rax
000078f8213d71d0  push rcx
000078f8213d71d1  push rdx
000078f8213d71d2  push rdi
000078f8213d71d3  push rsi
000078f8213d71d4  push r8
000078f8213d71d6  push r9
000078f8213d71d8  push r10
000078f8213d71da  push r11
000078f8213d71dc  sub rsp, 0xF0
000078f8213d71e3  vmovaps [rsp], xmm0
000078f8213d71e8  vmovaps [rsp+0x10], xmm1
000078f8213d71ee  vmovaps [rsp+0x20], xmm2
000078f8213d71f4  vmovaps [rsp+0x30], xmm3
000078f8213d71fa  vmovaps [rsp+0x40], xmm4
000078f8213d7200  vmovaps [rsp+0x50], xmm5
000078f8213d7206  vmovaps [rsp+0x60], xmm6
000078f8213d720c  vmovaps [rsp+0x70], xmm7
000078f8213d7212  vmovaps [rsp+0x80], xmm8
000078f8213d721b  vmovaps [rsp+0x90], xmm10
000078f8213d7224  vmovaps [rsp+0xA0], xmm11
000078f8213d722d  vmovaps [rsp+0xB0], xmm12
000078f8213d7236  vmovaps [rsp+0xC0], xmm13
000078f8213d723f  vmovaps [rsp+0xD0], xmm14
000078f8213d7248  vmovaps [rsp+0xE0], xmm15
000078f8213d7251  sub rsp, 0x30
000078f8213d7255  movaps [rsp], xmm9
000078f8213d725a  movaps [rsp+0x10], xmm10
000078f8213d7260  movaps [rsp+0x20], xmm8
000078f8213d7266  lea rdi, [rsp]
000078f8213d726a  mov esi, 0x00
000078f8213d726f  mov rax, 0x653D80F42530
000078f8213d7279  call rax
000078f8213d727b  movaps xmm9, [rsp]
000078f8213d7280  add rsp, 0x30
000078f8213d7284  vmovaps xmm0, [rsp]
000078f8213d7289  vmovaps xmm1, [rsp+0x10]
000078f8213d728f  vmovaps xmm2, [rsp+0x20]
000078f8213d7295  vmovaps xmm3, [rsp+0x30]
000078f8213d729b  vmovaps xmm4, [rsp+0x40]
000078f8213d72a1  vmovaps xmm5, [rsp+0x50]
000078f8213d72a7  vmovaps xmm6, [rsp+0x60]
000078f8213d72ad  vmovaps xmm7, [rsp+0x70]
000078f8213d72b3  vmovaps xmm8, [rsp+0x80]
000078f8213d72bc  vmovaps xmm10, [rsp+0x90]
000078f8213d72c5  vmovaps xmm11, [rsp+0xA0]
000078f8213d72ce  vmovaps xmm12, [rsp+0xB0]
000078f8213d72d7  vmovaps xmm13, [rsp+0xC0]
000078f8213d72e0  vmovaps xmm14, [rsp+0xD0]
000078f8213d72e9  vmovaps xmm15, [rsp+0xE0]
000078f8213d72f2  add rsp, 0xF0
000078f8213d72f9  pop r11
000078f8213d72fb  pop r10
000078f8213d72fd  pop r9
000078f8213d72ff  pop r8
000078f8213d7301  pop rsi
000078f8213d7302  pop rdi
000078f8213d7303  pop rdx
000078f8213d7304  pop rcx
000078f8213d7305  pop rax
000078f8213d7306  add rsp, 0x08
000078f8213d730a  jmp 0x000078F8213D5AFB
000078f8213d730f  call 0x000078F8212D64F0
000078f8213d7314  jmp 0x000078F8213D5C15
000078f8213d7319  call 0x000078F8212D64F0
000078f8213d731e  jmp 0x000078F8213D5C2B
000078f8213d7323  sub rsp, 0x08
000078f8213d7327  push rax
000078f8213d7328  push rcx
000078f8213d7329  push rdx
000078f8213d732a  push rdi
000078f8213d732b  push rsi
000078f8213d732c  push r8
000078f8213d732e  push r9
000078f8213d7330  push r10
000078f8213d7332  push r11
000078f8213d7334  sub rsp, 0xF0
000078f8213d733b  vmovaps [rsp], xmm0
000078f8213d7340  vmovaps [rsp+0x10], xmm2
000078f8213d7346  vmovaps [rsp+0x20], xmm3
000078f8213d734c  vmovaps [rsp+0x30], xmm4
000078f8213d7352  vmovaps [rsp+0x40], xmm5
000078f8213d7358  vmovaps [rsp+0x50], xmm6
000078f8213d735e  vmovaps [rsp+0x60], xmm7
000078f8213d7364  vmovaps [rsp+0x70], xmm8
000078f8213d736a  vmovaps [rsp+0x80], xmm9
000078f8213d7373  vmovaps [rsp+0x90], xmm10
000078f8213d737c  vmovaps [rsp+0xA0], xmm11
000078f8213d7385  vmovaps [rsp+0xB0], xmm12
000078f8213d738e  vmovaps [rsp+0xC0], xmm13
000078f8213d7397  vmovaps [rsp+0xD0], xmm14
000078f8213d73a0  vmovaps [rsp+0xE0], xmm15
000078f8213d73a9  sub rsp, 0x30
000078f8213d73ad  movaps [rsp], xmm1
000078f8213d73b1  movaps [rsp+0x10], xmm6
000078f8213d73b6  movaps [rsp+0x20], xmm15
000078f8213d73bc  lea rdi, [rsp]
000078f8213d73c0  mov esi, 0x00
000078f8213d73c5  mov rax, 0x653D80F42530
000078f8213d73cf  call rax
000078f8213d73d1  movaps xmm1, [rsp]
000078f8213d73d5  add rsp, 0x30
000078f8213d73d9  vmovaps xmm0, [rsp]
000078f8213d73de  vmovaps xmm2, [rsp+0x10]
000078f8213d73e4  vmovaps xmm3, [rsp+0x20]
000078f8213d73ea  vmovaps xmm4, [rsp+0x30]
000078f8213d73f0  vmovaps xmm5, [rsp+0x40]
000078f8213d73f6  vmovaps xmm6, [rsp+0x50]
000078f8213d73fc  vmovaps xmm7, [rsp+0x60]
000078f8213d7402  vmovaps xmm8, [rsp+0x70]
000078f8213d7408  vmovaps xmm9, [rsp+0x80]
000078f8213d7411  vmovaps xmm10, [rsp+0x90]
000078f8213d741a  vmovaps xmm11, [rsp+0xA0]
000078f8213d7423  vmovaps xmm12, [rsp+0xB0]
000078f8213d742c  vmovaps xmm13, [rsp+0xC0]
000078f8213d7435  vmovaps xmm14, [rsp+0xD0]
000078f8213d743e  vmovaps xmm15, [rsp+0xE0]
000078f8213d7447  add rsp, 0xF0
000078f8213d744e  pop r11
000078f8213d7450  pop r10
000078f8213d7452  pop r9
000078f8213d7454  pop r8
000078f8213d7456  pop rsi
000078f8213d7457  pop rdi
000078f8213d7458  pop rdx
000078f8213d7459  pop rcx
000078f8213d745a  pop rax
000078f8213d745b  add rsp, 0x08
000078f8213d745f  jmp 0x000078F8213D5C68
000078f8213d7464  call 0x000078F8212E5820
000078f8213d7469  jmp 0x000078F8213D5C75
000078f8213d746e  sub rsp, 0x08
000078f8213d7472  push rax
000078f8213d7473  push rcx
000078f8213d7474  push rdx
000078f8213d7475  push rdi
000078f8213d7476  push rsi
000078f8213d7477  push r8
000078f8213d7479  push r9
000078f8213d747b  push r10
000078f8213d747d  push r11
000078f8213d747f  sub rsp, 0xF0
000078f8213d7486  vmovaps [rsp], xmm0
000078f8213d748b  vmovaps [rsp+0x10], xmm1
000078f8213d7491  vmovaps [rsp+0x20], xmm2
000078f8213d7497  vmovaps [rsp+0x30], xmm3
000078f8213d749d  vmovaps [rsp+0x40], xmm4
000078f8213d74a3  vmovaps [rsp+0x50], xmm5
000078f8213d74a9  vmovaps [rsp+0x60], xmm6
000078f8213d74af  vmovaps [rsp+0x70], xmm7
000078f8213d74b5  vmovaps [rsp+0x80], xmm8
000078f8213d74be  vmovaps [rsp+0x90], xmm9
000078f8213d74c7  vmovaps [rsp+0xA0], xmm10
000078f8213d74d0  vmovaps [rsp+0xB0], xmm11
000078f8213d74d9  vmovaps [rsp+0xC0], xmm12
000078f8213d74e2  vmovaps [rsp+0xD0], xmm13
000078f8213d74eb  vmovaps [rsp+0xE0], xmm15
000078f8213d74f4  sub rsp, 0x30
000078f8213d74f8  movaps [rsp], xmm14
000078f8213d74fd  movaps [rsp+0x10], xmm4
000078f8213d7502  movaps [rsp+0x20], xmm3
000078f8213d7507  lea rdi, [rsp]
000078f8213d750b  mov esi, 0x00
000078f8213d7510  mov rax, 0x653D80F42530
000078f8213d751a  call rax
000078f8213d751c  movaps xmm14, [rsp]
000078f8213d7521  add rsp, 0x30
000078f8213d7525  vmovaps xmm0, [rsp]
000078f8213d752a  vmovaps xmm1, [rsp+0x10]
000078f8213d7530  vmovaps xmm2, [rsp+0x20]
000078f8213d7536  vmovaps xmm3, [rsp+0x30]
000078f8213d753c  vmovaps xmm4, [rsp+0x40]
000078f8213d7542  vmovaps xmm5, [rsp+0x50]
000078f8213d7548  vmovaps xmm6, [rsp+0x60]
000078f8213d754e  vmovaps xmm7, [rsp+0x70]
000078f8213d7554  vmovaps xmm8, [rsp+0x80]
000078f8213d755d  vmovaps xmm9, [rsp+0x90]
000078f8213d7566  vmovaps xmm10, [rsp+0xA0]
000078f8213d756f  vmovaps xmm11, [rsp+0xB0]
000078f8213d7578  vmovaps xmm12, [rsp+0xC0]
000078f8213d7581  vmovaps xmm13, [rsp+0xD0]
000078f8213d758a  vmovaps xmm15, [rsp+0xE0]
000078f8213d7593  add rsp, 0xF0
000078f8213d759a  pop r11
000078f8213d759c  pop r10
000078f8213d759e  pop r9
000078f8213d75a0  pop r8
000078f8213d75a2  pop rsi
000078f8213d75a3  pop rdi
000078f8213d75a4  pop rdx
000078f8213d75a5  pop rcx
000078f8213d75a6  pop rax
000078f8213d75a7  add rsp, 0x08
000078f8213d75ab  jmp 0x000078F8213D5C8F
000078f8213d75b0  sub rsp, 0x08
000078f8213d75b4  push rax
000078f8213d75b5  push rcx
000078f8213d75b6  push rdx
000078f8213d75b7  push rdi
000078f8213d75b8  push rsi
000078f8213d75b9  push r8
000078f8213d75bb  push r9
000078f8213d75bd  push r10
000078f8213d75bf  push r11
000078f8213d75c1  sub rsp, 0xF0
000078f8213d75c8  vmovaps [rsp], xmm0
000078f8213d75cd  vmovaps [rsp+0x10], xmm1
000078f8213d75d3  vmovaps [rsp+0x20], xmm2
000078f8213d75d9  vmovaps [rsp+0x30], xmm3
000078f8213d75df  vmovaps [rsp+0x40], xmm4
000078f8213d75e5  vmovaps [rsp+0x50], xmm5
000078f8213d75eb  vmovaps [rsp+0x60], xmm7
000078f8213d75f1  vmovaps [rsp+0x70], xmm8
000078f8213d75f7  vmovaps [rsp+0x80], xmm9
000078f8213d7600  vmovaps [rsp+0x90], xmm10
000078f8213d7609  vmovaps [rsp+0xA0], xmm11
000078f8213d7612  vmovaps [rsp+0xB0], xmm12
000078f8213d761b  vmovaps [rsp+0xC0], xmm13
000078f8213d7624  vmovaps [rsp+0xD0], xmm14
000078f8213d762d  vmovaps [rsp+0xE0], xmm15
000078f8213d7636  sub rsp, 0x30
000078f8213d763a  movaps [rsp], xmm6
000078f8213d763e  movaps [rsp+0x10], xmm9
000078f8213d7644  movaps [rsp+0x20], xmm7
000078f8213d7649  lea rdi, [rsp]
000078f8213d764d  mov esi, 0x00
000078f8213d7652  mov rax, 0x653D80F42530
000078f8213d765c  call rax
000078f8213d765e  movaps xmm6, [rsp]
000078f8213d7662  add rsp, 0x30
000078f8213d7666  vmovaps xmm0, [rsp]
000078f8213d766b  vmovaps xmm1, [rsp+0x10]
000078f8213d7671  vmovaps xmm2, [rsp+0x20]
000078f8213d7677  vmovaps xmm3, [rsp+0x30]
000078f8213d767d  vmovaps xmm4, [rsp+0x40]
000078f8213d7683  vmovaps xmm5, [rsp+0x50]
000078f8213d7689  vmovaps xmm7, [rsp+0x60]
000078f8213d768f  vmovaps xmm8, [rsp+0x70]
000078f8213d7695  vmovaps xmm9, [rsp+0x80]
000078f8213d769e  vmovaps xmm10, [rsp+0x90]
000078f8213d76a7  vmovaps xmm11, [rsp+0xA0]
000078f8213d76b0  vmovaps xmm12, [rsp+0xB0]
000078f8213d76b9  vmovaps xmm13, [rsp+0xC0]
000078f8213d76c2  vmovaps xmm14, [rsp+0xD0]
000078f8213d76cb  vmovaps xmm15, [rsp+0xE0]
000078f8213d76d4  add rsp, 0xF0
000078f8213d76db  pop r11
000078f8213d76dd  pop r10
000078f8213d76df  pop r9
000078f8213d76e1  pop r8
000078f8213d76e3  pop rsi
000078f8213d76e4  pop rdi
000078f8213d76e5  pop rdx
000078f8213d76e6  pop rcx
000078f8213d76e7  pop rax
000078f8213d76e8  add rsp, 0x08
000078f8213d76ec  jmp 0x000078F8213D5CA7
000078f8213d76f1  sub rsp, 0x08
000078f8213d76f5  push rax
000078f8213d76f6  push rcx
000078f8213d76f7  push rdx
000078f8213d76f8  push rdi
000078f8213d76f9  push rsi
000078f8213d76fa  push r8
000078f8213d76fc  push r9
000078f8213d76fe  push r10
000078f8213d7700  push r11
000078f8213d7702  sub rsp, 0xF0
000078f8213d7709  vmovaps [rsp], xmm0
000078f8213d770e  vmovaps [rsp+0x10], xmm1
000078f8213d7714  vmovaps [rsp+0x20], xmm2
000078f8213d771a  vmovaps [rsp+0x30], xmm3
000078f8213d7720  vmovaps [rsp+0x40], xmm4
000078f8213d7726  vmovaps [rsp+0x50], xmm5
000078f8213d772c  vmovaps [rsp+0x60], xmm6
000078f8213d7732  vmovaps [rsp+0x70], xmm8
000078f8213d7738  vmovaps [rsp+0x80], xmm9
000078f8213d7741  vmovaps [rsp+0x90], xmm10
000078f8213d774a  vmovaps [rsp+0xA0], xmm11
000078f8213d7753  vmovaps [rsp+0xB0], xmm12
000078f8213d775c  vmovaps [rsp+0xC0], xmm13
000078f8213d7765  vmovaps [rsp+0xD0], xmm14
000078f8213d776e  vmovaps [rsp+0xE0], xmm15
000078f8213d7777  sub rsp, 0x30
000078f8213d777b  movaps [rsp], xmm7
000078f8213d777f  movaps [rsp+0x10], xmm4
000078f8213d7784  movaps [rsp+0x20], xmm9
000078f8213d778a  lea rdi, [rsp]
000078f8213d778e  mov esi, 0x00
000078f8213d7793  mov rax, 0x653D80F42530
000078f8213d779d  call rax
000078f8213d779f  movaps xmm7, [rsp]
000078f8213d77a3  add rsp, 0x30
000078f8213d77a7  vmovaps xmm0, [rsp]
000078f8213d77ac  vmovaps xmm1, [rsp+0x10]
000078f8213d77b2  vmovaps xmm2, [rsp+0x20]
000078f8213d77b8  vmovaps xmm3, [rsp+0x30]
000078f8213d77be  vmovaps xmm4, [rsp+0x40]
000078f8213d77c4  vmovaps xmm5, [rsp+0x50]
000078f8213d77ca  vmovaps xmm6, [rsp+0x60]
000078f8213d77d0  vmovaps xmm8, [rsp+0x70]
000078f8213d77d6  vmovaps xmm9, [rsp+0x80]
000078f8213d77df  vmovaps xmm10, [rsp+0x90]
000078f8213d77e8  vmovaps xmm11, [rsp+0xA0]
000078f8213d77f1  vmovaps xmm12, [rsp+0xB0]
000078f8213d77fa  vmovaps xmm13, [rsp+0xC0]
000078f8213d7803  vmovaps xmm14, [rsp+0xD0]
000078f8213d780c  vmovaps xmm15, [rsp+0xE0]
000078f8213d7815  add rsp, 0xF0
000078f8213d781c  pop r11
000078f8213d781e  pop r10
000078f8213d7820  pop r9
000078f8213d7822  pop r8
000078f8213d7824  pop rsi
000078f8213d7825  pop rdi
000078f8213d7826  pop rdx
000078f8213d7827  pop rcx
000078f8213d7828  pop rax
000078f8213d7829  add rsp, 0x08
000078f8213d782d  jmp 0x000078F8213D5CD4
000078f8213d7832  sub rsp, 0x08
000078f8213d7836  push rax
000078f8213d7837  push rcx
000078f8213d7838  push rdx
000078f8213d7839  push rdi
000078f8213d783a  push rsi
000078f8213d783b  push r8
000078f8213d783d  push r9
000078f8213d783f  push r10
000078f8213d7841  push r11
000078f8213d7843  sub rsp, 0xF0
000078f8213d784a  vmovaps [rsp], xmm0
000078f8213d784f  vmovaps [rsp+0x10], xmm1
000078f8213d7855  vmovaps [rsp+0x20], xmm2
000078f8213d785b  vmovaps [rsp+0x30], xmm3
000078f8213d7861  vmovaps [rsp+0x40], xmm5
000078f8213d7867  vmovaps [rsp+0x50], xmm6
000078f8213d786d  vmovaps [rsp+0x60], xmm7
000078f8213d7873  vmovaps [rsp+0x70], xmm8
000078f8213d7879  vmovaps [rsp+0x80], xmm9
000078f8213d7882  vmovaps [rsp+0x90], xmm10
000078f8213d788b  vmovaps [rsp+0xA0], xmm11
000078f8213d7894  vmovaps [rsp+0xB0], xmm12
000078f8213d789d  vmovaps [rsp+0xC0], xmm13
000078f8213d78a6  vmovaps [rsp+0xD0], xmm14
000078f8213d78af  vmovaps [rsp+0xE0], xmm15
000078f8213d78b8  sub rsp, 0x30
000078f8213d78bc  movaps [rsp], xmm4
000078f8213d78c0  movaps [rsp+0x10], xmm15
000078f8213d78c6  movaps [rsp+0x20], xmm9
000078f8213d78cc  lea rdi, [rsp]
000078f8213d78d0  mov esi, 0x00
000078f8213d78d5  mov rax, 0x653D80F42530
000078f8213d78df  call rax
000078f8213d78e1  movaps xmm4, [rsp]
000078f8213d78e5  add rsp, 0x30
000078f8213d78e9  vmovaps xmm0, [rsp]
000078f8213d78ee  vmovaps xmm1, [rsp+0x10]
000078f8213d78f4  vmovaps xmm2, [rsp+0x20]
000078f8213d78fa  vmovaps xmm3, [rsp+0x30]
000078f8213d7900  vmovaps xmm5, [rsp+0x40]
000078f8213d7906  vmovaps xmm6, [rsp+0x50]
000078f8213d790c  vmovaps xmm7, [rsp+0x60]
000078f8213d7912  vmovaps xmm8, [rsp+0x70]
000078f8213d7918  vmovaps xmm9, [rsp+0x80]
000078f8213d7921  vmovaps xmm10, [rsp+0x90]
000078f8213d792a  vmovaps xmm11, [rsp+0xA0]
000078f8213d7933  vmovaps xmm12, [rsp+0xB0]
000078f8213d793c  vmovaps xmm13, [rsp+0xC0]
000078f8213d7945  vmovaps xmm14, [rsp+0xD0]
000078f8213d794e  vmovaps xmm15, [rsp+0xE0]
000078f8213d7957  add rsp, 0xF0
000078f8213d795e  pop r11
000078f8213d7960  pop r10
000078f8213d7962  pop r9
000078f8213d7964  pop r8
000078f8213d7966  pop rsi
000078f8213d7967  pop rdi
000078f8213d7968  pop rdx
000078f8213d7969  pop rcx
000078f8213d796a  pop rax
000078f8213d796b  add rsp, 0x08
000078f8213d796f  jmp 0x000078F8213D5CF9
000078f8213d7974  call 0x000078F8212E5820
000078f8213d7979  jmp 0x000078F8213D5D06
000078f8213d797e  sub rsp, 0x08
000078f8213d7982  push rax
000078f8213d7983  push rcx
000078f8213d7984  push rdx
000078f8213d7985  push rdi
000078f8213d7986  push rsi
000078f8213d7987  push r8
000078f8213d7989  push r9
000078f8213d798b  push r10
000078f8213d798d  push r11
000078f8213d798f  sub rsp, 0xF0
000078f8213d7996  vmovaps [rsp], xmm0
000078f8213d799b  vmovaps [rsp+0x10], xmm1
000078f8213d79a1  vmovaps [rsp+0x20], xmm2
000078f8213d79a7  vmovaps [rsp+0x30], xmm4
000078f8213d79ad  vmovaps [rsp+0x40], xmm5
000078f8213d79b3  vmovaps [rsp+0x50], xmm6
000078f8213d79b9  vmovaps [rsp+0x60], xmm7
000078f8213d79bf  vmovaps [rsp+0x70], xmm8
000078f8213d79c5  vmovaps [rsp+0x80], xmm9
000078f8213d79ce  vmovaps [rsp+0x90], xmm10
000078f8213d79d7  vmovaps [rsp+0xA0], xmm11
000078f8213d79e0  vmovaps [rsp+0xB0], xmm12
000078f8213d79e9  vmovaps [rsp+0xC0], xmm13
000078f8213d79f2  vmovaps [rsp+0xD0], xmm14
000078f8213d79fb  vmovaps [rsp+0xE0], xmm15
000078f8213d7a04  sub rsp, 0x30
000078f8213d7a08  movaps [rsp], xmm3
000078f8213d7a0c  movaps [rsp+0x10], xmm1
000078f8213d7a11  movaps [rsp+0x20], xmm9
000078f8213d7a17  lea rdi, [rsp]
000078f8213d7a1b  mov esi, 0x00
000078f8213d7a20  mov rax, 0x653D80F42530
000078f8213d7a2a  call rax
000078f8213d7a2c  movaps xmm3, [rsp]
000078f8213d7a30  add rsp, 0x30
000078f8213d7a34  vmovaps xmm0, [rsp]
000078f8213d7a39  vmovaps xmm1, [rsp+0x10]
000078f8213d7a3f  vmovaps xmm2, [rsp+0x20]
000078f8213d7a45  vmovaps xmm4, [rsp+0x30]
000078f8213d7a4b  vmovaps xmm5, [rsp+0x40]
000078f8213d7a51  vmovaps xmm6, [rsp+0x50]
000078f8213d7a57  vmovaps xmm7, [rsp+0x60]
000078f8213d7a5d  vmovaps xmm8, [rsp+0x70]
000078f8213d7a63  vmovaps xmm9, [rsp+0x80]
000078f8213d7a6c  vmovaps xmm10, [rsp+0x90]
000078f8213d7a75  vmovaps xmm11, [rsp+0xA0]
000078f8213d7a7e  vmovaps xmm12, [rsp+0xB0]
000078f8213d7a87  vmovaps xmm13, [rsp+0xC0]
000078f8213d7a90  vmovaps xmm14, [rsp+0xD0]
000078f8213d7a99  vmovaps xmm15, [rsp+0xE0]
000078f8213d7aa2  add rsp, 0xF0
000078f8213d7aa9  pop r11
000078f8213d7aab  pop r10
000078f8213d7aad  pop r9
000078f8213d7aaf  pop r8
000078f8213d7ab1  pop rsi
000078f8213d7ab2  pop rdi
000078f8213d7ab3  pop rdx
000078f8213d7ab4  pop rcx
000078f8213d7ab5  pop rax
000078f8213d7ab6  add rsp, 0x08
000078f8213d7aba  jmp 0x000078F8213D5D43
000078f8213d7abf  sub rsp, 0x08
000078f8213d7ac3  push rax
000078f8213d7ac4  push rcx
000078f8213d7ac5  push rdx
000078f8213d7ac6  push rdi
000078f8213d7ac7  push rsi
000078f8213d7ac8  push r8
000078f8213d7aca  push r9
000078f8213d7acc  push r10
000078f8213d7ace  push r11
000078f8213d7ad0  sub rsp, 0xF0
000078f8213d7ad7  vmovaps [rsp], xmm0
000078f8213d7adc  vmovaps [rsp+0x10], xmm2
000078f8213d7ae2  vmovaps [rsp+0x20], xmm3
000078f8213d7ae8  vmovaps [rsp+0x30], xmm4
000078f8213d7aee  vmovaps [rsp+0x40], xmm5
000078f8213d7af4  vmovaps [rsp+0x50], xmm6
000078f8213d7afa  vmovaps [rsp+0x60], xmm7
000078f8213d7b00  vmovaps [rsp+0x70], xmm8
000078f8213d7b06  vmovaps [rsp+0x80], xmm9
000078f8213d7b0f  vmovaps [rsp+0x90], xmm10
000078f8213d7b18  vmovaps [rsp+0xA0], xmm11
000078f8213d7b21  vmovaps [rsp+0xB0], xmm12
000078f8213d7b2a  vmovaps [rsp+0xC0], xmm13
000078f8213d7b33  vmovaps [rsp+0xD0], xmm14
000078f8213d7b3c  vmovaps [rsp+0xE0], xmm15
000078f8213d7b45  sub rsp, 0x30
000078f8213d7b49  movaps [rsp], xmm1
000078f8213d7b4d  movaps [rsp+0x10], xmm15
000078f8213d7b53  movaps [rsp+0x20], xmm9
000078f8213d7b59  lea rdi, [rsp]
000078f8213d7b5d  mov esi, 0x00
000078f8213d7b62  mov rax, 0x653D80F42530
000078f8213d7b6c  call rax
000078f8213d7b6e  movaps xmm1, [rsp]
000078f8213d7b72  add rsp, 0x30
000078f8213d7b76  vmovaps xmm0, [rsp]
000078f8213d7b7b  vmovaps xmm2, [rsp+0x10]
000078f8213d7b81  vmovaps xmm3, [rsp+0x20]
000078f8213d7b87  vmovaps xmm4, [rsp+0x30]
000078f8213d7b8d  vmovaps xmm5, [rsp+0x40]
000078f8213d7b93  vmovaps xmm6, [rsp+0x50]
000078f8213d7b99  vmovaps xmm7, [rsp+0x60]
000078f8213d7b9f  vmovaps xmm8, [rsp+0x70]
000078f8213d7ba5  vmovaps xmm9, [rsp+0x80]
000078f8213d7bae  vmovaps xmm10, [rsp+0x90]
000078f8213d7bb7  vmovaps xmm11, [rsp+0xA0]
000078f8213d7bc0  vmovaps xmm12, [rsp+0xB0]
000078f8213d7bc9  vmovaps xmm13, [rsp+0xC0]
000078f8213d7bd2  vmovaps xmm14, [rsp+0xD0]
000078f8213d7bdb  vmovaps xmm15, [rsp+0xE0]
000078f8213d7be4  add rsp, 0xF0
000078f8213d7beb  pop r11
000078f8213d7bed  pop r10
000078f8213d7bef  pop r9
000078f8213d7bf1  pop r8
000078f8213d7bf3  pop rsi
000078f8213d7bf4  pop rdi
000078f8213d7bf5  pop rdx
000078f8213d7bf6  pop rcx
000078f8213d7bf7  pop rax
000078f8213d7bf8  add rsp, 0x08
000078f8213d7bfc  jmp 0x000078F8213D5DCB
000078f8213d7c01  call 0x000078F8212E5820
000078f8213d7c06  jmp 0x000078F8213D5DD8
000078f8213d7c0b  sub rsp, 0x08
000078f8213d7c0f  push rax
000078f8213d7c10  push rcx
000078f8213d7c11  push rdx
000078f8213d7c12  push rdi
000078f8213d7c13  push rsi
000078f8213d7c14  push r8
000078f8213d7c16  push r9
000078f8213d7c18  push r10
000078f8213d7c1a  push r11
000078f8213d7c1c  sub rsp, 0xF0
000078f8213d7c23  vmovaps [rsp], xmm0
000078f8213d7c28  vmovaps [rsp+0x10], xmm2
000078f8213d7c2e  vmovaps [rsp+0x20], xmm3
000078f8213d7c34  vmovaps [rsp+0x30], xmm4
000078f8213d7c3a  vmovaps [rsp+0x40], xmm5
000078f8213d7c40  vmovaps [rsp+0x50], xmm6
000078f8213d7c46  vmovaps [rsp+0x60], xmm7
000078f8213d7c4c  vmovaps [rsp+0x70], xmm8
000078f8213d7c52  vmovaps [rsp+0x80], xmm9
000078f8213d7c5b  vmovaps [rsp+0x90], xmm10
000078f8213d7c64  vmovaps [rsp+0xA0], xmm11
000078f8213d7c6d  vmovaps [rsp+0xB0], xmm12
000078f8213d7c76  vmovaps [rsp+0xC0], xmm13
000078f8213d7c7f  vmovaps [rsp+0xD0], xmm14
000078f8213d7c88  vmovaps [rsp+0xE0], xmm15
000078f8213d7c91  sub rsp, 0x30
000078f8213d7c95  movaps [rsp], xmm1
000078f8213d7c99  movaps [rsp+0x10], xmm5
000078f8213d7c9e  movaps [rsp+0x20], xmm7
000078f8213d7ca3  lea rdi, [rsp]
000078f8213d7ca7  mov esi, 0x00
000078f8213d7cac  mov rax, 0x653D80F42530
000078f8213d7cb6  call rax
000078f8213d7cb8  movaps xmm1, [rsp]
000078f8213d7cbc  add rsp, 0x30
000078f8213d7cc0  vmovaps xmm0, [rsp]
000078f8213d7cc5  vmovaps xmm2, [rsp+0x10]
000078f8213d7ccb  vmovaps xmm3, [rsp+0x20]
000078f8213d7cd1  vmovaps xmm4, [rsp+0x30]
000078f8213d7cd7  vmovaps xmm5, [rsp+0x40]
000078f8213d7cdd  vmovaps xmm6, [rsp+0x50]
000078f8213d7ce3  vmovaps xmm7, [rsp+0x60]
000078f8213d7ce9  vmovaps xmm8, [rsp+0x70]
000078f8213d7cef  vmovaps xmm9, [rsp+0x80]
000078f8213d7cf8  vmovaps xmm10, [rsp+0x90]
000078f8213d7d01  vmovaps xmm11, [rsp+0xA0]
000078f8213d7d0a  vmovaps xmm12, [rsp+0xB0]
000078f8213d7d13  vmovaps xmm13, [rsp+0xC0]
000078f8213d7d1c  vmovaps xmm14, [rsp+0xD0]
000078f8213d7d25  vmovaps xmm15, [rsp+0xE0]
000078f8213d7d2e  add rsp, 0xF0
000078f8213d7d35  pop r11
000078f8213d7d37  pop r10
000078f8213d7d39  pop r9
000078f8213d7d3b  pop r8
000078f8213d7d3d  pop rsi
000078f8213d7d3e  pop rdi
000078f8213d7d3f  pop rdx
000078f8213d7d40  pop rcx
000078f8213d7d41  pop rax
000078f8213d7d42  add rsp, 0x08
000078f8213d7d46  jmp 0x000078F8213D5E7D
000078f8213d7d4b  sub rsp, 0x08
000078f8213d7d4f  push rax
000078f8213d7d50  push rcx
000078f8213d7d51  push rdx
000078f8213d7d52  push rdi
000078f8213d7d53  push rsi
000078f8213d7d54  push r8
000078f8213d7d56  push r9
000078f8213d7d58  push r10
000078f8213d7d5a  push r11
000078f8213d7d5c  sub rsp, 0xF0
000078f8213d7d63  vmovaps [rsp], xmm0
000078f8213d7d68  vmovaps [rsp+0x10], xmm1
000078f8213d7d6e  vmovaps [rsp+0x20], xmm2
000078f8213d7d74  vmovaps [rsp+0x30], xmm3
000078f8213d7d7a  vmovaps [rsp+0x40], xmm4
000078f8213d7d80  vmovaps [rsp+0x50], xmm5
000078f8213d7d86  vmovaps [rsp+0x60], xmm6
000078f8213d7d8c  vmovaps [rsp+0x70], xmm8
000078f8213d7d92  vmovaps [rsp+0x80], xmm9
000078f8213d7d9b  vmovaps [rsp+0x90], xmm10
000078f8213d7da4  vmovaps [rsp+0xA0], xmm11
000078f8213d7dad  vmovaps [rsp+0xB0], xmm12
000078f8213d7db6  vmovaps [rsp+0xC0], xmm13
000078f8213d7dbf  vmovaps [rsp+0xD0], xmm14
000078f8213d7dc8  vmovaps [rsp+0xE0], xmm15
000078f8213d7dd1  sub rsp, 0x30
000078f8213d7dd5  movaps [rsp], xmm7
000078f8213d7dd9  movaps [rsp+0x10], xmm5
000078f8213d7dde  movaps [rsp+0x20], xmm15
000078f8213d7de4  lea rdi, [rsp]
000078f8213d7de8  mov esi, 0x00
000078f8213d7ded  mov rax, 0x653D80F42530
000078f8213d7df7  call rax
000078f8213d7df9  movaps xmm7, [rsp]
000078f8213d7dfd  add rsp, 0x30
000078f8213d7e01  vmovaps xmm0, [rsp]
000078f8213d7e06  vmovaps xmm1, [rsp+0x10]
000078f8213d7e0c  vmovaps xmm2, [rsp+0x20]
000078f8213d7e12  vmovaps xmm3, [rsp+0x30]
000078f8213d7e18  vmovaps xmm4, [rsp+0x40]
000078f8213d7e1e  vmovaps xmm5, [rsp+0x50]
000078f8213d7e24  vmovaps xmm6, [rsp+0x60]
000078f8213d7e2a  vmovaps xmm8, [rsp+0x70]
000078f8213d7e30  vmovaps xmm9, [rsp+0x80]
000078f8213d7e39  vmovaps xmm10, [rsp+0x90]
000078f8213d7e42  vmovaps xmm11, [rsp+0xA0]
000078f8213d7e4b  vmovaps xmm12, [rsp+0xB0]
000078f8213d7e54  vmovaps xmm13, [rsp+0xC0]
000078f8213d7e5d  vmovaps xmm14, [rsp+0xD0]
000078f8213d7e66  vmovaps xmm15, [rsp+0xE0]
000078f8213d7e6f  add rsp, 0xF0
000078f8213d7e76  pop r11
000078f8213d7e78  pop r10
000078f8213d7e7a  pop r9
000078f8213d7e7c  pop r8
000078f8213d7e7e  pop rsi
000078f8213d7e7f  pop rdi
000078f8213d7e80  pop rdx
000078f8213d7e81  pop rcx
000078f8213d7e82  pop rax
000078f8213d7e83  add rsp, 0x08
000078f8213d7e87  jmp 0x000078F8213D5EB3
000078f8213d7e8c  call 0x000078F8212D64F0
000078f8213d7e91  jmp 0x000078F8213D5EC0
000078f8213d7e96  sub rsp, 0x08
000078f8213d7e9a  push rax
000078f8213d7e9b  push rcx
000078f8213d7e9c  push rdx
000078f8213d7e9d  push rdi
000078f8213d7e9e  push rsi
000078f8213d7e9f  push r8
000078f8213d7ea1  push r9
000078f8213d7ea3  push r10
000078f8213d7ea5  push r11
000078f8213d7ea7  sub rsp, 0xF0
000078f8213d7eae  vmovaps [rsp], xmm0
000078f8213d7eb3  vmovaps [rsp+0x10], xmm1
000078f8213d7eb9  vmovaps [rsp+0x20], xmm2
000078f8213d7ebf  vmovaps [rsp+0x30], xmm3
000078f8213d7ec5  vmovaps [rsp+0x40], xmm4
000078f8213d7ecb  vmovaps [rsp+0x50], xmm5
000078f8213d7ed1  vmovaps [rsp+0x60], xmm6
000078f8213d7ed7  vmovaps [rsp+0x70], xmm7
000078f8213d7edd  vmovaps [rsp+0x80], xmm8
000078f8213d7ee6  vmovaps [rsp+0x90], xmm9
000078f8213d7eef  vmovaps [rsp+0xA0], xmm10
000078f8213d7ef8  vmovaps [rsp+0xB0], xmm11
000078f8213d7f01  vmovaps [rsp+0xC0], xmm12
000078f8213d7f0a  vmovaps [rsp+0xD0], xmm13
000078f8213d7f13  vmovaps [rsp+0xE0], xmm14
000078f8213d7f1c  sub rsp, 0x30
000078f8213d7f20  movaps [rsp], xmm15
000078f8213d7f25  movaps [rsp+0x10], xmm5
000078f8213d7f2a  movaps [rsp+0x20], xmm3
000078f8213d7f2f  lea rdi, [rsp]
000078f8213d7f33  mov esi, 0x00
000078f8213d7f38  mov rax, 0x653D80F42530
000078f8213d7f42  call rax
000078f8213d7f44  movaps xmm15, [rsp]
000078f8213d7f49  add rsp, 0x30
000078f8213d7f4d  vmovaps xmm0, [rsp]
000078f8213d7f52  vmovaps xmm1, [rsp+0x10]
000078f8213d7f58  vmovaps xmm2, [rsp+0x20]
000078f8213d7f5e  vmovaps xmm3, [rsp+0x30]
000078f8213d7f64  vmovaps xmm4, [rsp+0x40]
000078f8213d7f6a  vmovaps xmm5, [rsp+0x50]
000078f8213d7f70  vmovaps xmm6, [rsp+0x60]
000078f8213d7f76  vmovaps xmm7, [rsp+0x70]
000078f8213d7f7c  vmovaps xmm8, [rsp+0x80]
000078f8213d7f85  vmovaps xmm9, [rsp+0x90]
000078f8213d7f8e  vmovaps xmm10, [rsp+0xA0]
000078f8213d7f97  vmovaps xmm11, [rsp+0xB0]
000078f8213d7fa0  vmovaps xmm12, [rsp+0xC0]
000078f8213d7fa9  vmovaps xmm13, [rsp+0xD0]
000078f8213d7fb2  vmovaps xmm14, [rsp+0xE0]
000078f8213d7fbb  add rsp, 0xF0
000078f8213d7fc2  pop r11
000078f8213d7fc4  pop r10
000078f8213d7fc6  pop r9
000078f8213d7fc8  pop r8
000078f8213d7fca  pop rsi
000078f8213d7fcb  pop rdi
000078f8213d7fcc  pop rdx
000078f8213d7fcd  pop rcx
000078f8213d7fce  pop rax
000078f8213d7fcf  add rsp, 0x08
000078f8213d7fd3  jmp 0x000078F8213D5EE6
000078f8213d7fd8  sub rsp, 0x08
000078f8213d7fdc  push rax
000078f8213d7fdd  push rcx
000078f8213d7fde  push rdx
000078f8213d7fdf  push rdi
000078f8213d7fe0  push rsi
000078f8213d7fe1  push r8
000078f8213d7fe3  push r9
000078f8213d7fe5  push r10
000078f8213d7fe7  push r11
000078f8213d7fe9  sub rsp, 0xF0
000078f8213d7ff0  vmovaps [rsp], xmm0
000078f8213d7ff5  vmovaps [rsp+0x10], xmm2
000078f8213d7ffb  vmovaps [rsp+0x20], xmm3
000078f8213d8001  vmovaps [rsp+0x30], xmm4
000078f8213d8007  vmovaps [rsp+0x40], xmm5
000078f8213d800d  vmovaps [rsp+0x50], xmm6
000078f8213d8013  vmovaps [rsp+0x60], xmm7
000078f8213d8019  vmovaps [rsp+0x70], xmm8
000078f8213d801f  vmovaps [rsp+0x80], xmm9
000078f8213d8028  vmovaps [rsp+0x90], xmm10
000078f8213d8031  vmovaps [rsp+0xA0], xmm11
000078f8213d803a  vmovaps [rsp+0xB0], xmm12
000078f8213d8043  vmovaps [rsp+0xC0], xmm13
000078f8213d804c  vmovaps [rsp+0xD0], xmm14
000078f8213d8055  vmovaps [rsp+0xE0], xmm15
000078f8213d805e  sub rsp, 0x30
000078f8213d8062  movaps [rsp], xmm1
000078f8213d8066  movaps [rsp+0x10], xmm5
000078f8213d806b  movaps [rsp+0x20], xmm4
000078f8213d8070  lea rdi, [rsp]
000078f8213d8074  mov esi, 0x00
000078f8213d8079  mov rax, 0x653D80F42530
000078f8213d8083  call rax
000078f8213d8085  movaps xmm1, [rsp]
000078f8213d8089  add rsp, 0x30
000078f8213d808d  vmovaps xmm0, [rsp]
000078f8213d8092  vmovaps xmm2, [rsp+0x10]
000078f8213d8098  vmovaps xmm3, [rsp+0x20]
000078f8213d809e  vmovaps xmm4, [rsp+0x30]
000078f8213d80a4  vmovaps xmm5, [rsp+0x40]
000078f8213d80aa  vmovaps xmm6, [rsp+0x50]
000078f8213d80b0  vmovaps xmm7, [rsp+0x60]
000078f8213d80b6  vmovaps xmm8, [rsp+0x70]
000078f8213d80bc  vmovaps xmm9, [rsp+0x80]
000078f8213d80c5  vmovaps xmm10, [rsp+0x90]
000078f8213d80ce  vmovaps xmm11, [rsp+0xA0]
000078f8213d80d7  vmovaps xmm12, [rsp+0xB0]
000078f8213d80e0  vmovaps xmm13, [rsp+0xC0]
000078f8213d80e9  vmovaps xmm14, [rsp+0xD0]
000078f8213d80f2  vmovaps xmm15, [rsp+0xE0]
000078f8213d80fb  add rsp, 0xF0
000078f8213d8102  pop r11
000078f8213d8104  pop r10
000078f8213d8106  pop r9
000078f8213d8108  pop r8
000078f8213d810a  pop rsi
000078f8213d810b  pop rdi
000078f8213d810c  pop rdx
000078f8213d810d  pop rcx
000078f8213d810e  pop rax
000078f8213d810f  add rsp, 0x08
000078f8213d8113  jmp 0x000078F8213D5F06
000078f8213d8118  sub rsp, 0x08
000078f8213d811c  push rax
000078f8213d811d  push rcx
000078f8213d811e  push rdx
000078f8213d811f  push rdi
000078f8213d8120  push rsi
000078f8213d8121  push r8
000078f8213d8123  push r9
000078f8213d8125  push r10
000078f8213d8127  push r11
000078f8213d8129  sub rsp, 0xF0
000078f8213d8130  vmovaps [rsp], xmm0
000078f8213d8135  vmovaps [rsp+0x10], xmm1
000078f8213d813b  vmovaps [rsp+0x20], xmm2
000078f8213d8141  vmovaps [rsp+0x30], xmm3
000078f8213d8147  vmovaps [rsp+0x40], xmm5
000078f8213d814d  vmovaps [rsp+0x50], xmm6
000078f8213d8153  vmovaps [rsp+0x60], xmm7
000078f8213d8159  vmovaps [rsp+0x70], xmm8
000078f8213d815f  vmovaps [rsp+0x80], xmm9
000078f8213d8168  vmovaps [rsp+0x90], xmm10
000078f8213d8171  vmovaps [rsp+0xA0], xmm11
000078f8213d817a  vmovaps [rsp+0xB0], xmm12
000078f8213d8183  vmovaps [rsp+0xC0], xmm13
000078f8213d818c  vmovaps [rsp+0xD0], xmm14
000078f8213d8195  vmovaps [rsp+0xE0], xmm15
000078f8213d819e  sub rsp, 0x30
000078f8213d81a2  movaps [rsp], xmm4
000078f8213d81a6  movaps [rsp+0x10], xmm3
000078f8213d81ab  movaps [rsp+0x20], xmm5
000078f8213d81b0  lea rdi, [rsp]
000078f8213d81b4  mov esi, 0x00
000078f8213d81b9  mov rax, 0x653D80F42530
000078f8213d81c3  call rax
000078f8213d81c5  movaps xmm4, [rsp]
000078f8213d81c9  add rsp, 0x30
000078f8213d81cd  vmovaps xmm0, [rsp]
000078f8213d81d2  vmovaps xmm1, [rsp+0x10]
000078f8213d81d8  vmovaps xmm2, [rsp+0x20]
000078f8213d81de  vmovaps xmm3, [rsp+0x30]
000078f8213d81e4  vmovaps xmm5, [rsp+0x40]
000078f8213d81ea  vmovaps xmm6, [rsp+0x50]
000078f8213d81f0  vmovaps xmm7, [rsp+0x60]
000078f8213d81f6  vmovaps xmm8, [rsp+0x70]
000078f8213d81fc  vmovaps xmm9, [rsp+0x80]
000078f8213d8205  vmovaps xmm10, [rsp+0x90]
000078f8213d820e  vmovaps xmm11, [rsp+0xA0]
000078f8213d8217  vmovaps xmm12, [rsp+0xB0]
000078f8213d8220  vmovaps xmm13, [rsp+0xC0]
000078f8213d8229  vmovaps xmm14, [rsp+0xD0]
000078f8213d8232  vmovaps xmm15, [rsp+0xE0]
000078f8213d823b  add rsp, 0xF0
000078f8213d8242  pop r11
000078f8213d8244  pop r10
000078f8213d8246  pop r9
000078f8213d8248  pop r8
000078f8213d824a  pop rsi
000078f8213d824b  pop rdi
000078f8213d824c  pop rdx
000078f8213d824d  pop rcx
000078f8213d824e  pop rax
000078f8213d824f  add rsp, 0x08
000078f8213d8253  jmp 0x000078F8213D5F54
000078f8213d8258  call 0x000078F8212D64F0
000078f8213d825d  jmp 0x000078F8213D5F61
000078f8213d8262  sub rsp, 0x08
000078f8213d8266  push rax
000078f8213d8267  push rcx
000078f8213d8268  push rdx
000078f8213d8269  push rdi
000078f8213d826a  push rsi
000078f8213d826b  push r8
000078f8213d826d  push r9
000078f8213d826f  push r10
000078f8213d8271  push r11
000078f8213d8273  sub rsp, 0xF0
000078f8213d827a  vmovaps [rsp], xmm0
000078f8213d827f  vmovaps [rsp+0x10], xmm1
000078f8213d8285  vmovaps [rsp+0x20], xmm2
000078f8213d828b  vmovaps [rsp+0x30], xmm3
000078f8213d8291  vmovaps [rsp+0x40], xmm4
000078f8213d8297  vmovaps [rsp+0x50], xmm6
000078f8213d829d  vmovaps [rsp+0x60], xmm7
000078f8213d82a3  vmovaps [rsp+0x70], xmm8
000078f8213d82a9  vmovaps [rsp+0x80], xmm9
000078f8213d82b2  vmovaps [rsp+0x90], xmm10
000078f8213d82bb  vmovaps [rsp+0xA0], xmm11
000078f8213d82c4  vmovaps [rsp+0xB0], xmm12
000078f8213d82cd  vmovaps [rsp+0xC0], xmm13
000078f8213d82d6  vmovaps [rsp+0xD0], xmm14
000078f8213d82df  vmovaps [rsp+0xE0], xmm15
000078f8213d82e8  sub rsp, 0x30
000078f8213d82ec  movaps [rsp], xmm5
000078f8213d82f0  movaps [rsp+0x10], xmm6
000078f8213d82f5  movaps [rsp+0x20], xmm3
000078f8213d82fa  lea rdi, [rsp]
000078f8213d82fe  mov esi, 0x00
000078f8213d8303  mov rax, 0x653D80F42530
000078f8213d830d  call rax
000078f8213d830f  movaps xmm5, [rsp]
000078f8213d8313  add rsp, 0x30
000078f8213d8317  vmovaps xmm0, [rsp]
000078f8213d831c  vmovaps xmm1, [rsp+0x10]
000078f8213d8322  vmovaps xmm2, [rsp+0x20]
000078f8213d8328  vmovaps xmm3, [rsp+0x30]
000078f8213d832e  vmovaps xmm4, [rsp+0x40]
000078f8213d8334  vmovaps xmm6, [rsp+0x50]
000078f8213d833a  vmovaps xmm7, [rsp+0x60]
000078f8213d8340  vmovaps xmm8, [rsp+0x70]
000078f8213d8346  vmovaps xmm9, [rsp+0x80]
000078f8213d834f  vmovaps xmm10, [rsp+0x90]
000078f8213d8358  vmovaps xmm11, [rsp+0xA0]
000078f8213d8361  vmovaps xmm12, [rsp+0xB0]
000078f8213d836a  vmovaps xmm13, [rsp+0xC0]
000078f8213d8373  vmovaps xmm14, [rsp+0xD0]
000078f8213d837c  vmovaps xmm15, [rsp+0xE0]
000078f8213d8385  add rsp, 0xF0
000078f8213d838c  pop r11
000078f8213d838e  pop r10
000078f8213d8390  pop r9
000078f8213d8392  pop r8
000078f8213d8394  pop rsi
000078f8213d8395  pop rdi
000078f8213d8396  pop rdx
000078f8213d8397  pop rcx
000078f8213d8398  pop rax
000078f8213d8399  add rsp, 0x08
000078f8213d839d  jmp 0x000078F8213D5F87
000078f8213d83a2  sub rsp, 0x08
000078f8213d83a6  push rax
000078f8213d83a7  push rcx
000078f8213d83a8  push rdx
000078f8213d83a9  push rdi
000078f8213d83aa  push rsi
000078f8213d83ab  push r8
000078f8213d83ad  push r9
000078f8213d83af  push r10
000078f8213d83b1  push r11
000078f8213d83b3  sub rsp, 0xF0
000078f8213d83ba  vmovaps [rsp], xmm0
000078f8213d83bf  vmovaps [rsp+0x10], xmm1
000078f8213d83c5  vmovaps [rsp+0x20], xmm2
000078f8213d83cb  vmovaps [rsp+0x30], xmm3
000078f8213d83d1  vmovaps [rsp+0x40], xmm4
000078f8213d83d7  vmovaps [rsp+0x50], xmm5
000078f8213d83dd  vmovaps [rsp+0x60], xmm7
000078f8213d83e3  vmovaps [rsp+0x70], xmm8
000078f8213d83e9  vmovaps [rsp+0x80], xmm9
000078f8213d83f2  vmovaps [rsp+0x90], xmm10
000078f8213d83fb  vmovaps [rsp+0xA0], xmm11
000078f8213d8404  vmovaps [rsp+0xB0], xmm12
000078f8213d840d  vmovaps [rsp+0xC0], xmm13
000078f8213d8416  vmovaps [rsp+0xD0], xmm14
000078f8213d841f  vmovaps [rsp+0xE0], xmm15
000078f8213d8428  sub rsp, 0x30
000078f8213d842c  movaps [rsp], xmm6
000078f8213d8430  movaps [rsp+0x10], xmm9
000078f8213d8436  movaps [rsp+0x20], xmm1
000078f8213d843b  lea rdi, [rsp]
000078f8213d843f  mov esi, 0x00
000078f8213d8444  mov rax, 0x653D80F42530
000078f8213d844e  call rax
000078f8213d8450  movaps xmm6, [rsp]
000078f8213d8454  add rsp, 0x30
000078f8213d8458  vmovaps xmm0, [rsp]
000078f8213d845d  vmovaps xmm1, [rsp+0x10]
000078f8213d8463  vmovaps xmm2, [rsp+0x20]
000078f8213d8469  vmovaps xmm3, [rsp+0x30]
000078f8213d846f  vmovaps xmm4, [rsp+0x40]
000078f8213d8475  vmovaps xmm5, [rsp+0x50]
000078f8213d847b  vmovaps xmm7, [rsp+0x60]
000078f8213d8481  vmovaps xmm8, [rsp+0x70]
000078f8213d8487  vmovaps xmm9, [rsp+0x80]
000078f8213d8490  vmovaps xmm10, [rsp+0x90]
000078f8213d8499  vmovaps xmm11, [rsp+0xA0]
000078f8213d84a2  vmovaps xmm12, [rsp+0xB0]
000078f8213d84ab  vmovaps xmm13, [rsp+0xC0]
000078f8213d84b4  vmovaps xmm14, [rsp+0xD0]
000078f8213d84bd  vmovaps xmm15, [rsp+0xE0]
000078f8213d84c6  add rsp, 0xF0
000078f8213d84cd  pop r11
000078f8213d84cf  pop r10
000078f8213d84d1  pop r9
000078f8213d84d3  pop r8
000078f8213d84d5  pop rsi
000078f8213d84d6  pop rdi
000078f8213d84d7  pop rdx
000078f8213d84d8  pop rcx
000078f8213d84d9  pop rax
000078f8213d84da  add rsp, 0x08
000078f8213d84de  jmp 0x000078F8213D5FAB
000078f8213d84e3  sub rsp, 0x08
000078f8213d84e7  push rax
000078f8213d84e8  push rcx
000078f8213d84e9  push rdx
000078f8213d84ea  push rdi
000078f8213d84eb  push rsi
000078f8213d84ec  push r8
000078f8213d84ee  push r9
000078f8213d84f0  push r10
000078f8213d84f2  push r11
000078f8213d84f4  sub rsp, 0xF0
000078f8213d84fb  vmovaps [rsp], xmm0
000078f8213d8500  vmovaps [rsp+0x10], xmm1
000078f8213d8506  vmovaps [rsp+0x20], xmm2
000078f8213d850c  vmovaps [rsp+0x30], xmm3
000078f8213d8512  vmovaps [rsp+0x40], xmm4
000078f8213d8518  vmovaps [rsp+0x50], xmm5
000078f8213d851e  vmovaps [rsp+0x60], xmm6
000078f8213d8524  vmovaps [rsp+0x70], xmm7
000078f8213d852a  vmovaps [rsp+0x80], xmm8
000078f8213d8533  vmovaps [rsp+0x90], xmm10
000078f8213d853c  vmovaps [rsp+0xA0], xmm11
000078f8213d8545  vmovaps [rsp+0xB0], xmm12
000078f8213d854e  vmovaps [rsp+0xC0], xmm13
000078f8213d8557  vmovaps [rsp+0xD0], xmm14
000078f8213d8560  vmovaps [rsp+0xE0], xmm15
000078f8213d8569  sub rsp, 0x30
000078f8213d856d  movaps [rsp], xmm9
000078f8213d8572  movaps [rsp+0x10], xmm3
000078f8213d8577  movaps [rsp+0x20], xmm1
000078f8213d857c  lea rdi, [rsp]
000078f8213d8580  mov esi, 0x00
000078f8213d8585  mov rax, 0x653D80F42530
000078f8213d858f  call rax
000078f8213d8591  movaps xmm9, [rsp]
000078f8213d8596  add rsp, 0x30
000078f8213d859a  vmovaps xmm0, [rsp]
000078f8213d859f  vmovaps xmm1, [rsp+0x10]
000078f8213d85a5  vmovaps xmm2, [rsp+0x20]
000078f8213d85ab  vmovaps xmm3, [rsp+0x30]
000078f8213d85b1  vmovaps xmm4, [rsp+0x40]
000078f8213d85b7  vmovaps xmm5, [rsp+0x50]
000078f8213d85bd  vmovaps xmm6, [rsp+0x60]
000078f8213d85c3  vmovaps xmm7, [rsp+0x70]
000078f8213d85c9  vmovaps xmm8, [rsp+0x80]
000078f8213d85d2  vmovaps xmm10, [rsp+0x90]
000078f8213d85db  vmovaps xmm11, [rsp+0xA0]
000078f8213d85e4  vmovaps xmm12, [rsp+0xB0]
000078f8213d85ed  vmovaps xmm13, [rsp+0xC0]
000078f8213d85f6  vmovaps xmm14, [rsp+0xD0]
000078f8213d85ff  vmovaps xmm15, [rsp+0xE0]
000078f8213d8608  add rsp, 0xF0
000078f8213d860f  pop r11
000078f8213d8611  pop r10
000078f8213d8613  pop r9
000078f8213d8615  pop r8
000078f8213d8617  pop rsi
000078f8213d8618  pop rdi
000078f8213d8619  pop rdx
000078f8213d861a  pop rcx
000078f8213d861b  pop rax
000078f8213d861c  add rsp, 0x08
000078f8213d8620  jmp 0x000078F8213D5FF7
000078f8213d8625  call 0x000078F8212D64F0
000078f8213d862a  jmp 0x000078F8213D6004
000078f8213d862f  sub rsp, 0x08
000078f8213d8633  push rax
000078f8213d8634  push rcx
000078f8213d8635  push rdx
000078f8213d8636  push rdi
000078f8213d8637  push rsi
000078f8213d8638  push r8
000078f8213d863a  push r9
000078f8213d863c  push r10
000078f8213d863e  push r11
000078f8213d8640  sub rsp, 0xF0
000078f8213d8647  vmovaps [rsp], xmm0
000078f8213d864c  vmovaps [rsp+0x10], xmm1
000078f8213d8652  vmovaps [rsp+0x20], xmm2
000078f8213d8658  vmovaps [rsp+0x30], xmm3
000078f8213d865e  vmovaps [rsp+0x40], xmm4
000078f8213d8664  vmovaps [rsp+0x50], xmm5
000078f8213d866a  vmovaps [rsp+0x60], xmm6
000078f8213d8670  vmovaps [rsp+0x70], xmm7
000078f8213d8676  vmovaps [rsp+0x80], xmm8
000078f8213d867f  vmovaps [rsp+0x90], xmm9
000078f8213d8688  vmovaps [rsp+0xA0], xmm10
000078f8213d8691  vmovaps [rsp+0xB0], xmm11
000078f8213d869a  vmovaps [rsp+0xC0], xmm12
000078f8213d86a3  vmovaps [rsp+0xD0], xmm13
000078f8213d86ac  vmovaps [rsp+0xE0], xmm14
000078f8213d86b5  sub rsp, 0x30
000078f8213d86b9  movaps [rsp], xmm15
000078f8213d86be  movaps [rsp+0x10], xmm3
000078f8213d86c3  movaps [rsp+0x20], xmm7
000078f8213d86c8  lea rdi, [rsp]
000078f8213d86cc  mov esi, 0x00
000078f8213d86d1  mov rax, 0x653D80F42530
000078f8213d86db  call rax
000078f8213d86dd  movaps xmm15, [rsp]
000078f8213d86e2  add rsp, 0x30
000078f8213d86e6  vmovaps xmm0, [rsp]
000078f8213d86eb  vmovaps xmm1, [rsp+0x10]
000078f8213d86f1  vmovaps xmm2, [rsp+0x20]
000078f8213d86f7  vmovaps xmm3, [rsp+0x30]
000078f8213d86fd  vmovaps xmm4, [rsp+0x40]
000078f8213d8703  vmovaps xmm5, [rsp+0x50]
000078f8213d8709  vmovaps xmm6, [rsp+0x60]
000078f8213d870f  vmovaps xmm7, [rsp+0x70]
000078f8213d8715  vmovaps xmm8, [rsp+0x80]
000078f8213d871e  vmovaps xmm9, [rsp+0x90]
000078f8213d8727  vmovaps xmm10, [rsp+0xA0]
000078f8213d8730  vmovaps xmm11, [rsp+0xB0]
000078f8213d8739  vmovaps xmm12, [rsp+0xC0]
000078f8213d8742  vmovaps xmm13, [rsp+0xD0]
000078f8213d874b  vmovaps xmm14, [rsp+0xE0]
000078f8213d8754  add rsp, 0xF0
000078f8213d875b  pop r11
000078f8213d875d  pop r10
000078f8213d875f  pop r9
000078f8213d8761  pop r8
000078f8213d8763  pop rsi
000078f8213d8764  pop rdi
000078f8213d8765  pop rdx
000078f8213d8766  pop rcx
000078f8213d8767  pop rax
000078f8213d8768  add rsp, 0x08
000078f8213d876c  jmp 0x000078F8213D6030
000078f8213d8771  sub rsp, 0x08
000078f8213d8775  push rax
000078f8213d8776  push rcx
000078f8213d8777  push rdx
000078f8213d8778  push rdi
000078f8213d8779  push rsi
000078f8213d877a  push r8
000078f8213d877c  push r9
000078f8213d877e  push r10
000078f8213d8780  push r11
000078f8213d8782  sub rsp, 0xF0
000078f8213d8789  vmovaps [rsp], xmm0
000078f8213d878e  vmovaps [rsp+0x10], xmm1
000078f8213d8794  vmovaps [rsp+0x20], xmm2
000078f8213d879a  vmovaps [rsp+0x30], xmm4
000078f8213d87a0  vmovaps [rsp+0x40], xmm5
000078f8213d87a6  vmovaps [rsp+0x50], xmm6
000078f8213d87ac  vmovaps [rsp+0x60], xmm7
000078f8213d87b2  vmovaps [rsp+0x70], xmm8
000078f8213d87b8  vmovaps [rsp+0x80], xmm9
000078f8213d87c1  vmovaps [rsp+0x90], xmm10
000078f8213d87ca  vmovaps [rsp+0xA0], xmm11
000078f8213d87d3  vmovaps [rsp+0xB0], xmm12
000078f8213d87dc  vmovaps [rsp+0xC0], xmm13
000078f8213d87e5  vmovaps [rsp+0xD0], xmm14
000078f8213d87ee  vmovaps [rsp+0xE0], xmm15
000078f8213d87f7  sub rsp, 0x30
000078f8213d87fb  movaps [rsp], xmm3
000078f8213d87ff  movaps [rsp+0x10], xmm1
000078f8213d8804  movaps [rsp+0x20], xmm15
000078f8213d880a  lea rdi, [rsp]
000078f8213d880e  mov esi, 0x00
000078f8213d8813  mov rax, 0x653D80F42530
000078f8213d881d  call rax
000078f8213d881f  movaps xmm3, [rsp]
000078f8213d8823  add rsp, 0x30
000078f8213d8827  vmovaps xmm0, [rsp]
000078f8213d882c  vmovaps xmm1, [rsp+0x10]
000078f8213d8832  vmovaps xmm2, [rsp+0x20]
000078f8213d8838  vmovaps xmm4, [rsp+0x30]
000078f8213d883e  vmovaps xmm5, [rsp+0x40]
000078f8213d8844  vmovaps xmm6, [rsp+0x50]
000078f8213d884a  vmovaps xmm7, [rsp+0x60]
000078f8213d8850  vmovaps xmm8, [rsp+0x70]
000078f8213d8856  vmovaps xmm9, [rsp+0x80]
000078f8213d885f  vmovaps xmm10, [rsp+0x90]
000078f8213d8868  vmovaps xmm11, [rsp+0xA0]
000078f8213d8871  vmovaps xmm12, [rsp+0xB0]
000078f8213d887a  vmovaps xmm13, [rsp+0xC0]
000078f8213d8883  vmovaps xmm14, [rsp+0xD0]
000078f8213d888c  vmovaps xmm15, [rsp+0xE0]
000078f8213d8895  add rsp, 0xF0
000078f8213d889c  pop r11
000078f8213d889e  pop r10
000078f8213d88a0  pop r9
000078f8213d88a2  pop r8
000078f8213d88a4  pop rsi
000078f8213d88a5  pop rdi
000078f8213d88a6  pop rdx
000078f8213d88a7  pop rcx
000078f8213d88a8  pop rax
000078f8213d88a9  add rsp, 0x08
000078f8213d88ad  jmp 0x000078F8213D60BF
000078f8213d88b2  call 0x000078F8212D64F0
000078f8213d88b7  jmp 0x000078F8213D60C9
000078f8213d88bc  sub rsp, 0x08
000078f8213d88c0  push rax
000078f8213d88c1  push rcx
000078f8213d88c2  push rdx
000078f8213d88c3  push rdi
000078f8213d88c4  push rsi
000078f8213d88c5  push r8
000078f8213d88c7  push r9
000078f8213d88c9  push r10
000078f8213d88cb  push r11
000078f8213d88cd  sub rsp, 0xF0
000078f8213d88d4  vmovaps [rsp], xmm0
000078f8213d88d9  vmovaps [rsp+0x10], xmm1
000078f8213d88df  vmovaps [rsp+0x20], xmm2
000078f8213d88e5  vmovaps [rsp+0x30], xmm3
000078f8213d88eb  vmovaps [rsp+0x40], xmm4
000078f8213d88f1  vmovaps [rsp+0x50], xmm5
000078f8213d88f7  vmovaps [rsp+0x60], xmm6
000078f8213d88fd  vmovaps [rsp+0x70], xmm7
000078f8213d8903  vmovaps [rsp+0x80], xmm8
000078f8213d890c  vmovaps [rsp+0x90], xmm9
000078f8213d8915  vmovaps [rsp+0xA0], xmm10
000078f8213d891e  vmovaps [rsp+0xB0], xmm11
000078f8213d8927  vmovaps [rsp+0xC0], xmm12
000078f8213d8930  vmovaps [rsp+0xD0], xmm13
000078f8213d8939  vmovaps [rsp+0xE0], xmm14
000078f8213d8942  sub rsp, 0x30
000078f8213d8946  movaps [rsp], xmm15
000078f8213d894b  movaps [rsp+0x10], xmm14
000078f8213d8951  movaps [rsp+0x20], xmm4
000078f8213d8956  lea rdi, [rsp]
000078f8213d895a  mov esi, 0x00
000078f8213d895f  mov rax, 0x653D80F42530
000078f8213d8969  call rax
000078f8213d896b  movaps xmm15, [rsp]
000078f8213d8970  add rsp, 0x30
000078f8213d8974  vmovaps xmm0, [rsp]
000078f8213d8979  vmovaps xmm1, [rsp+0x10]
000078f8213d897f  vmovaps xmm2, [rsp+0x20]
000078f8213d8985  vmovaps xmm3, [rsp+0x30]
000078f8213d898b  vmovaps xmm4, [rsp+0x40]
000078f8213d8991  vmovaps xmm5, [rsp+0x50]
000078f8213d8997  vmovaps xmm6, [rsp+0x60]
000078f8213d899d  vmovaps xmm7, [rsp+0x70]
000078f8213d89a3  vmovaps xmm8, [rsp+0x80]
000078f8213d89ac  vmovaps xmm9, [rsp+0x90]
000078f8213d89b5  vmovaps xmm10, [rsp+0xA0]
000078f8213d89be  vmovaps xmm11, [rsp+0xB0]
000078f8213d89c7  vmovaps xmm12, [rsp+0xC0]
000078f8213d89d0  vmovaps xmm13, [rsp+0xD0]
000078f8213d89d9  vmovaps xmm14, [rsp+0xE0]
000078f8213d89e2  add rsp, 0xF0
000078f8213d89e9  pop r11
000078f8213d89eb  pop r10
000078f8213d89ed  pop r9
000078f8213d89ef  pop r8
000078f8213d89f1  pop rsi
000078f8213d89f2  pop rdi
000078f8213d89f3  pop rdx
000078f8213d89f4  pop rcx
000078f8213d89f5  pop rax
000078f8213d89f6  add rsp, 0x08
000078f8213d89fa  jmp 0x000078F8213D60F7
000078f8213d89ff  sub rsp, 0x08
000078f8213d8a03  push rax
000078f8213d8a04  push rcx
000078f8213d8a05  push rdx
000078f8213d8a06  push rdi
000078f8213d8a07  push rsi
000078f8213d8a08  push r8
000078f8213d8a0a  push r9
000078f8213d8a0c  push r10
000078f8213d8a0e  push r11
000078f8213d8a10  sub rsp, 0xF0
000078f8213d8a17  vmovaps [rsp], xmm0
000078f8213d8a1c  vmovaps [rsp+0x10], xmm1
000078f8213d8a22  vmovaps [rsp+0x20], xmm2
000078f8213d8a28  vmovaps [rsp+0x30], xmm3
000078f8213d8a2e  vmovaps [rsp+0x40], xmm4
000078f8213d8a34  vmovaps [rsp+0x50], xmm5
000078f8213d8a3a  vmovaps [rsp+0x60], xmm6
000078f8213d8a40  vmovaps [rsp+0x70], xmm7
000078f8213d8a46  vmovaps [rsp+0x80], xmm8
000078f8213d8a4f  vmovaps [rsp+0x90], xmm9
000078f8213d8a58  vmovaps [rsp+0xA0], xmm10
000078f8213d8a61  vmovaps [rsp+0xB0], xmm11
000078f8213d8a6a  vmovaps [rsp+0xC0], xmm12
000078f8213d8a73  vmovaps [rsp+0xD0], xmm13
000078f8213d8a7c  vmovaps [rsp+0xE0], xmm15
000078f8213d8a85  sub rsp, 0x30
000078f8213d8a89  movaps [rsp], xmm14
000078f8213d8a8e  movaps [rsp+0x10], xmm2
000078f8213d8a93  movaps [rsp+0x20], xmm1
000078f8213d8a98  lea rdi, [rsp]
000078f8213d8a9c  mov esi, 0x00
000078f8213d8aa1  mov rax, 0x653D80F42530
000078f8213d8aab  call rax
000078f8213d8aad  movaps xmm14, [rsp]
000078f8213d8ab2  add rsp, 0x30
000078f8213d8ab6  vmovaps xmm0, [rsp]
000078f8213d8abb  vmovaps xmm1, [rsp+0x10]
000078f8213d8ac1  vmovaps xmm2, [rsp+0x20]
000078f8213d8ac7  vmovaps xmm3, [rsp+0x30]
000078f8213d8acd  vmovaps xmm4, [rsp+0x40]
000078f8213d8ad3  vmovaps xmm5, [rsp+0x50]
000078f8213d8ad9  vmovaps xmm6, [rsp+0x60]
000078f8213d8adf  vmovaps xmm7, [rsp+0x70]
000078f8213d8ae5  vmovaps xmm8, [rsp+0x80]
000078f8213d8aee  vmovaps xmm9, [rsp+0x90]
000078f8213d8af7  vmovaps xmm10, [rsp+0xA0]
000078f8213d8b00  vmovaps xmm11, [rsp+0xB0]
000078f8213d8b09  vmovaps xmm12, [rsp+0xC0]
000078f8213d8b12  vmovaps xmm13, [rsp+0xD0]
000078f8213d8b1b  vmovaps xmm15, [rsp+0xE0]
000078f8213d8b24  add rsp, 0xF0
000078f8213d8b2b  pop r11
000078f8213d8b2d  pop r10
000078f8213d8b2f  pop r9
000078f8213d8b31  pop r8
000078f8213d8b33  pop rsi
000078f8213d8b34  pop rdi
000078f8213d8b35  pop rdx
000078f8213d8b36  pop rcx
000078f8213d8b37  pop rax
000078f8213d8b38  add rsp, 0x08
000078f8213d8b3c  jmp 0x000078F8213D611D
000078f8213d8b41  sub rsp, 0x08
000078f8213d8b45  push rax
000078f8213d8b46  push rcx
000078f8213d8b47  push rdx
000078f8213d8b48  push rdi
000078f8213d8b49  push rsi
000078f8213d8b4a  push r8
000078f8213d8b4c  push r9
000078f8213d8b4e  push r10
000078f8213d8b50  push r11
000078f8213d8b52  sub rsp, 0xF0
000078f8213d8b59  vmovaps [rsp], xmm0
000078f8213d8b5e  vmovaps [rsp+0x10], xmm2
000078f8213d8b64  vmovaps [rsp+0x20], xmm3
000078f8213d8b6a  vmovaps [rsp+0x30], xmm4
000078f8213d8b70  vmovaps [rsp+0x40], xmm5
000078f8213d8b76  vmovaps [rsp+0x50], xmm6
000078f8213d8b7c  vmovaps [rsp+0x60], xmm7
000078f8213d8b82  vmovaps [rsp+0x70], xmm8
000078f8213d8b88  vmovaps [rsp+0x80], xmm9
000078f8213d8b91  vmovaps [rsp+0x90], xmm10
000078f8213d8b9a  vmovaps [rsp+0xA0], xmm11
000078f8213d8ba3  vmovaps [rsp+0xB0], xmm12
000078f8213d8bac  vmovaps [rsp+0xC0], xmm13
000078f8213d8bb5  vmovaps [rsp+0xD0], xmm14
000078f8213d8bbe  vmovaps [rsp+0xE0], xmm15
000078f8213d8bc7  sub rsp, 0x30
000078f8213d8bcb  movaps [rsp], xmm1
000078f8213d8bcf  movaps [rsp+0x10], xmm4
000078f8213d8bd4  movaps [rsp+0x20], xmm9
000078f8213d8bda  lea rdi, [rsp]
000078f8213d8bde  mov esi, 0x00
000078f8213d8be3  mov rax, 0x653D80F42530
000078f8213d8bed  call rax
000078f8213d8bef  movaps xmm1, [rsp]
000078f8213d8bf3  add rsp, 0x30
000078f8213d8bf7  vmovaps xmm0, [rsp]
000078f8213d8bfc  vmovaps xmm2, [rsp+0x10]
000078f8213d8c02  vmovaps xmm3, [rsp+0x20]
000078f8213d8c08  vmovaps xmm4, [rsp+0x30]
000078f8213d8c0e  vmovaps xmm5, [rsp+0x40]
000078f8213d8c14  vmovaps xmm6, [rsp+0x50]
000078f8213d8c1a  vmovaps xmm7, [rsp+0x60]
000078f8213d8c20  vmovaps xmm8, [rsp+0x70]
000078f8213d8c26  vmovaps xmm9, [rsp+0x80]
000078f8213d8c2f  vmovaps xmm10, [rsp+0x90]
000078f8213d8c38  vmovaps xmm11, [rsp+0xA0]
000078f8213d8c41  vmovaps xmm12, [rsp+0xB0]
000078f8213d8c4a  vmovaps xmm13, [rsp+0xC0]
000078f8213d8c53  vmovaps xmm14, [rsp+0xD0]
000078f8213d8c5c  vmovaps xmm15, [rsp+0xE0]
000078f8213d8c65  add rsp, 0xF0
000078f8213d8c6c  pop r11
000078f8213d8c6e  pop r10
000078f8213d8c70  pop r9
000078f8213d8c72  pop r8
000078f8213d8c74  pop rsi
000078f8213d8c75  pop rdi
000078f8213d8c76  pop rdx
000078f8213d8c77  pop rcx
000078f8213d8c78  pop rax
000078f8213d8c79  add rsp, 0x08
000078f8213d8c7d  jmp 0x000078F8213D613B
000078f8213d8c82  sub rsp, 0x08
000078f8213d8c86  push rax
000078f8213d8c87  push rcx
000078f8213d8c88  push rdx
000078f8213d8c89  push rdi
000078f8213d8c8a  push rsi
000078f8213d8c8b  push r8
000078f8213d8c8d  push r9
000078f8213d8c8f  push r10
000078f8213d8c91  push r11
000078f8213d8c93  sub rsp, 0xF0
000078f8213d8c9a  vmovaps [rsp], xmm0
000078f8213d8c9f  vmovaps [rsp+0x10], xmm1
000078f8213d8ca5  vmovaps [rsp+0x20], xmm2
000078f8213d8cab  vmovaps [rsp+0x30], xmm3
000078f8213d8cb1  vmovaps [rsp+0x40], xmm5
000078f8213d8cb7  vmovaps [rsp+0x50], xmm6
000078f8213d8cbd  vmovaps [rsp+0x60], xmm7
000078f8213d8cc3  vmovaps [rsp+0x70], xmm8
000078f8213d8cc9  vmovaps [rsp+0x80], xmm9
000078f8213d8cd2  vmovaps [rsp+0x90], xmm10
000078f8213d8cdb  vmovaps [rsp+0xA0], xmm11
000078f8213d8ce4  vmovaps [rsp+0xB0], xmm12
000078f8213d8ced  vmovaps [rsp+0xC0], xmm13
000078f8213d8cf6  vmovaps [rsp+0xD0], xmm14
000078f8213d8cff  vmovaps [rsp+0xE0], xmm15
000078f8213d8d08  sub rsp, 0x30
000078f8213d8d0c  movaps [rsp], xmm4
000078f8213d8d10  movaps [rsp+0x10], xmm2
000078f8213d8d15  movaps [rsp+0x20], xmm9
000078f8213d8d1b  lea rdi, [rsp]
000078f8213d8d1f  mov esi, 0x00
000078f8213d8d24  mov rax, 0x653D80F42530
000078f8213d8d2e  call rax
000078f8213d8d30  movaps xmm4, [rsp]
000078f8213d8d34  add rsp, 0x30
000078f8213d8d38  vmovaps xmm0, [rsp]
000078f8213d8d3d  vmovaps xmm1, [rsp+0x10]
000078f8213d8d43  vmovaps xmm2, [rsp+0x20]
000078f8213d8d49  vmovaps xmm3, [rsp+0x30]
000078f8213d8d4f  vmovaps xmm5, [rsp+0x40]
000078f8213d8d55  vmovaps xmm6, [rsp+0x50]
000078f8213d8d5b  vmovaps xmm7, [rsp+0x60]
000078f8213d8d61  vmovaps xmm8, [rsp+0x70]
000078f8213d8d67  vmovaps xmm9, [rsp+0x80]
000078f8213d8d70  vmovaps xmm10, [rsp+0x90]
000078f8213d8d79  vmovaps xmm11, [rsp+0xA0]
000078f8213d8d82  vmovaps xmm12, [rsp+0xB0]
000078f8213d8d8b  vmovaps xmm13, [rsp+0xC0]
000078f8213d8d94  vmovaps xmm14, [rsp+0xD0]
000078f8213d8d9d  vmovaps xmm15, [rsp+0xE0]
000078f8213d8da6  add rsp, 0xF0
000078f8213d8dad  pop r11
000078f8213d8daf  pop r10
000078f8213d8db1  pop r9
000078f8213d8db3  pop r8
000078f8213d8db5  pop rsi
000078f8213d8db6  pop rdi
000078f8213d8db7  pop rdx
000078f8213d8db8  pop rcx
000078f8213d8db9  pop rax
000078f8213d8dba  add rsp, 0x08
000078f8213d8dbe  jmp 0x000078F8213D616B
000078f8213d8dc3  sub rsp, 0x08
000078f8213d8dc7  push rax
000078f8213d8dc8  push rcx
000078f8213d8dc9  push rdx
000078f8213d8dca  push rdi
000078f8213d8dcb  push rsi
000078f8213d8dcc  push r8
000078f8213d8dce  push r9
000078f8213d8dd0  push r10
000078f8213d8dd2  push r11
000078f8213d8dd4  sub rsp, 0xF0
000078f8213d8ddb  vmovaps [rsp], xmm0
000078f8213d8de0  vmovaps [rsp+0x10], xmm1
000078f8213d8de6  vmovaps [rsp+0x20], xmm2
000078f8213d8dec  vmovaps [rsp+0x30], xmm3
000078f8213d8df2  vmovaps [rsp+0x40], xmm4
000078f8213d8df8  vmovaps [rsp+0x50], xmm5
000078f8213d8dfe  vmovaps [rsp+0x60], xmm6
000078f8213d8e04  vmovaps [rsp+0x70], xmm7
000078f8213d8e0a  vmovaps [rsp+0x80], xmm8
000078f8213d8e13  vmovaps [rsp+0x90], xmm10
000078f8213d8e1c  vmovaps [rsp+0xA0], xmm11
000078f8213d8e25  vmovaps [rsp+0xB0], xmm12
000078f8213d8e2e  vmovaps [rsp+0xC0], xmm13
000078f8213d8e37  vmovaps [rsp+0xD0], xmm14
000078f8213d8e40  vmovaps [rsp+0xE0], xmm15
000078f8213d8e49  sub rsp, 0x30
000078f8213d8e4d  movaps [rsp], xmm9
000078f8213d8e52  movaps [rsp+0x10], xmm2
000078f8213d8e57  movaps [rsp+0x20], xmm1
000078f8213d8e5c  lea rdi, [rsp]
000078f8213d8e60  mov esi, 0x00
000078f8213d8e65  mov rax, 0x653D80F42530
000078f8213d8e6f  call rax
000078f8213d8e71  movaps xmm9, [rsp]
000078f8213d8e76  add rsp, 0x30
000078f8213d8e7a  vmovaps xmm0, [rsp]
000078f8213d8e7f  vmovaps xmm1, [rsp+0x10]
000078f8213d8e85  vmovaps xmm2, [rsp+0x20]
000078f8213d8e8b  vmovaps xmm3, [rsp+0x30]
000078f8213d8e91  vmovaps xmm4, [rsp+0x40]
000078f8213d8e97  vmovaps xmm5, [rsp+0x50]
000078f8213d8e9d  vmovaps xmm6, [rsp+0x60]
000078f8213d8ea3  vmovaps xmm7, [rsp+0x70]
000078f8213d8ea9  vmovaps xmm8, [rsp+0x80]
000078f8213d8eb2  vmovaps xmm10, [rsp+0x90]
000078f8213d8ebb  vmovaps xmm11, [rsp+0xA0]
000078f8213d8ec4  vmovaps xmm12, [rsp+0xB0]
000078f8213d8ecd  vmovaps xmm13, [rsp+0xC0]
000078f8213d8ed6  vmovaps xmm14, [rsp+0xD0]
000078f8213d8edf  vmovaps xmm15, [rsp+0xE0]
000078f8213d8ee8  add rsp, 0xF0
000078f8213d8eef  pop r11
000078f8213d8ef1  pop r10
000078f8213d8ef3  pop r9
000078f8213d8ef5  pop r8
000078f8213d8ef7  pop rsi
000078f8213d8ef8  pop rdi
000078f8213d8ef9  pop rdx
000078f8213d8efa  pop rcx
000078f8213d8efb  pop rax
000078f8213d8efc  add rsp, 0x08
000078f8213d8f00  jmp 0x000078F8213D61A1
000078f8213d8f05  sub rsp, 0x08
000078f8213d8f09  push rax
000078f8213d8f0a  push rcx
000078f8213d8f0b  push rdx
000078f8213d8f0c  push rdi
000078f8213d8f0d  push rsi
000078f8213d8f0e  push r8
000078f8213d8f10  push r9
000078f8213d8f12  push r10
000078f8213d8f14  push r11
000078f8213d8f16  sub rsp, 0xF0
000078f8213d8f1d  vmovaps [rsp], xmm0
000078f8213d8f22  vmovaps [rsp+0x10], xmm2
000078f8213d8f28  vmovaps [rsp+0x20], xmm3
000078f8213d8f2e  vmovaps [rsp+0x30], xmm4
000078f8213d8f34  vmovaps [rsp+0x40], xmm5
000078f8213d8f3a  vmovaps [rsp+0x50], xmm6
000078f8213d8f40  vmovaps [rsp+0x60], xmm7
000078f8213d8f46  vmovaps [rsp+0x70], xmm8
000078f8213d8f4c  vmovaps [rsp+0x80], xmm9
000078f8213d8f55  vmovaps [rsp+0x90], xmm10
000078f8213d8f5e  vmovaps [rsp+0xA0], xmm11
000078f8213d8f67  vmovaps [rsp+0xB0], xmm12
000078f8213d8f70  vmovaps [rsp+0xC0], xmm13
000078f8213d8f79  vmovaps [rsp+0xD0], xmm14
000078f8213d8f82  vmovaps [rsp+0xE0], xmm15
000078f8213d8f8b  sub rsp, 0x30
000078f8213d8f8f  movaps [rsp], xmm1
000078f8213d8f93  movaps [rsp+0x10], xmm15
000078f8213d8f99  movaps [rsp+0x20], xmm6
000078f8213d8f9e  lea rdi, [rsp]
000078f8213d8fa2  mov esi, 0x00
000078f8213d8fa7  mov rax, 0x653D80F42530
000078f8213d8fb1  call rax
000078f8213d8fb3  movaps xmm1, [rsp]
000078f8213d8fb7  add rsp, 0x30
000078f8213d8fbb  vmovaps xmm0, [rsp]
000078f8213d8fc0  vmovaps xmm2, [rsp+0x10]
000078f8213d8fc6  vmovaps xmm3, [rsp+0x20]
000078f8213d8fcc  vmovaps xmm4, [rsp+0x30]
000078f8213d8fd2  vmovaps xmm5, [rsp+0x40]
000078f8213d8fd8  vmovaps xmm6, [rsp+0x50]
000078f8213d8fde  vmovaps xmm7, [rsp+0x60]
000078f8213d8fe4  vmovaps xmm8, [rsp+0x70]
000078f8213d8fea  vmovaps xmm9, [rsp+0x80]
000078f8213d8ff3  vmovaps xmm10, [rsp+0x90]
000078f8213d8ffc  vmovaps xmm11, [rsp+0xA0]
000078f8213d9005  vmovaps xmm12, [rsp+0xB0]
000078f8213d900e  vmovaps xmm13, [rsp+0xC0]
000078f8213d9017  vmovaps xmm14, [rsp+0xD0]
000078f8213d9020  vmovaps xmm15, [rsp+0xE0]
000078f8213d9029  add rsp, 0xF0
000078f8213d9030  pop r11
000078f8213d9032  pop r10
000078f8213d9034  pop r9
000078f8213d9036  pop r8
000078f8213d9038  pop rsi
000078f8213d9039  pop rdi
000078f8213d903a  pop rdx
000078f8213d903b  pop rcx
000078f8213d903c  pop rax
000078f8213d903d  add rsp, 0x08
000078f8213d9041  jmp 0x000078F8213D61C2
000078f8213d9046  sub rsp, 0x08
000078f8213d904a  push rax
000078f8213d904b  push rcx
000078f8213d904c  push rdx
000078f8213d904d  push rdi
000078f8213d904e  push rsi
000078f8213d904f  push r8
000078f8213d9051  push r9
000078f8213d9053  push r10
000078f8213d9055  push r11
000078f8213d9057  sub rsp, 0xF0
000078f8213d905e  vmovaps [rsp], xmm0
000078f8213d9063  vmovaps [rsp+0x10], xmm1
000078f8213d9069  vmovaps [rsp+0x20], xmm2
000078f8213d906f  vmovaps [rsp+0x30], xmm3
000078f8213d9075  vmovaps [rsp+0x40], xmm4
000078f8213d907b  vmovaps [rsp+0x50], xmm5
000078f8213d9081  vmovaps [rsp+0x60], xmm6
000078f8213d9087  vmovaps [rsp+0x70], xmm7
000078f8213d908d  vmovaps [rsp+0x80], xmm8
000078f8213d9096  vmovaps [rsp+0x90], xmm9
000078f8213d909f  vmovaps [rsp+0xA0], xmm10
000078f8213d90a8  vmovaps [rsp+0xB0], xmm11
000078f8213d90b1  vmovaps [rsp+0xC0], xmm12
000078f8213d90ba  vmovaps [rsp+0xD0], xmm13
000078f8213d90c3  vmovaps [rsp+0xE0], xmm14
000078f8213d90cc  sub rsp, 0x30
000078f8213d90d0  movaps [rsp], xmm15
000078f8213d90d5  movaps [rsp+0x10], xmm5
000078f8213d90da  movaps [rsp+0x20], xmm3
000078f8213d90df  lea rdi, [rsp]
000078f8213d90e3  mov esi, 0x00
000078f8213d90e8  mov rax, 0x653D80F42530
000078f8213d90f2  call rax
000078f8213d90f4  movaps xmm15, [rsp]
000078f8213d90f9  add rsp, 0x30
000078f8213d90fd  vmovaps xmm0, [rsp]
000078f8213d9102  vmovaps xmm1, [rsp+0x10]
000078f8213d9108  vmovaps xmm2, [rsp+0x20]
000078f8213d910e  vmovaps xmm3, [rsp+0x30]
000078f8213d9114  vmovaps xmm4, [rsp+0x40]
000078f8213d911a  vmovaps xmm5, [rsp+0x50]
000078f8213d9120  vmovaps xmm6, [rsp+0x60]
000078f8213d9126  vmovaps xmm7, [rsp+0x70]
000078f8213d912c  vmovaps xmm8, [rsp+0x80]
000078f8213d9135  vmovaps xmm9, [rsp+0x90]
000078f8213d913e  vmovaps xmm10, [rsp+0xA0]
000078f8213d9147  vmovaps xmm11, [rsp+0xB0]
000078f8213d9150  vmovaps xmm12, [rsp+0xC0]
000078f8213d9159  vmovaps xmm13, [rsp+0xD0]
000078f8213d9162  vmovaps xmm14, [rsp+0xE0]
000078f8213d916b  add rsp, 0xF0
000078f8213d9172  pop r11
000078f8213d9174  pop r10
000078f8213d9176  pop r9
000078f8213d9178  pop r8
000078f8213d917a  pop rsi
000078f8213d917b  pop rdi
000078f8213d917c  pop rdx
000078f8213d917d  pop rcx
000078f8213d917e  pop rax
000078f8213d917f  add rsp, 0x08
000078f8213d9183  jmp 0x000078F8213D61DC
000078f8213d9188  sub rsp, 0x08
000078f8213d918c  push rax
000078f8213d918d  push rcx
000078f8213d918e  push rdx
000078f8213d918f  push rdi
000078f8213d9190  push rsi
000078f8213d9191  push r8
000078f8213d9193  push r9
000078f8213d9195  push r10
000078f8213d9197  push r11
000078f8213d9199  sub rsp, 0xF0
000078f8213d91a0  vmovaps [rsp], xmm0
000078f8213d91a5  vmovaps [rsp+0x10], xmm1
000078f8213d91ab  vmovaps [rsp+0x20], xmm2
000078f8213d91b1  vmovaps [rsp+0x30], xmm3
000078f8213d91b7  vmovaps [rsp+0x40], xmm4
000078f8213d91bd  vmovaps [rsp+0x50], xmm6
000078f8213d91c3  vmovaps [rsp+0x60], xmm7
000078f8213d91c9  vmovaps [rsp+0x70], xmm8
000078f8213d91cf  vmovaps [rsp+0x80], xmm9
000078f8213d91d8  vmovaps [rsp+0x90], xmm10
000078f8213d91e1  vmovaps [rsp+0xA0], xmm11
000078f8213d91ea  vmovaps [rsp+0xB0], xmm12
000078f8213d91f3  vmovaps [rsp+0xC0], xmm13
000078f8213d91fc  vmovaps [rsp+0xD0], xmm14
000078f8213d9205  vmovaps [rsp+0xE0], xmm15
000078f8213d920e  sub rsp, 0x30
000078f8213d9212  movaps [rsp], xmm5
000078f8213d9216  movaps [rsp+0x10], xmm8
000078f8213d921c  movaps [rsp+0x20], xmm6
000078f8213d9221  lea rdi, [rsp]
000078f8213d9225  mov esi, 0x00
000078f8213d922a  mov rax, 0x653D80F42530
000078f8213d9234  call rax
000078f8213d9236  movaps xmm5, [rsp]
000078f8213d923a  add rsp, 0x30
000078f8213d923e  vmovaps xmm0, [rsp]
000078f8213d9243  vmovaps xmm1, [rsp+0x10]
000078f8213d9249  vmovaps xmm2, [rsp+0x20]
000078f8213d924f  vmovaps xmm3, [rsp+0x30]
000078f8213d9255  vmovaps xmm4, [rsp+0x40]
000078f8213d925b  vmovaps xmm6, [rsp+0x50]
000078f8213d9261  vmovaps xmm7, [rsp+0x60]
000078f8213d9267  vmovaps xmm8, [rsp+0x70]
000078f8213d926d  vmovaps xmm9, [rsp+0x80]
000078f8213d9276  vmovaps xmm10, [rsp+0x90]
000078f8213d927f  vmovaps xmm11, [rsp+0xA0]
000078f8213d9288  vmovaps xmm12, [rsp+0xB0]
000078f8213d9291  vmovaps xmm13, [rsp+0xC0]
000078f8213d929a  vmovaps xmm14, [rsp+0xD0]
000078f8213d92a3  vmovaps xmm15, [rsp+0xE0]
000078f8213d92ac  add rsp, 0xF0
000078f8213d92b3  pop r11
000078f8213d92b5  pop r10
000078f8213d92b7  pop r9
000078f8213d92b9  pop r8
000078f8213d92bb  pop rsi
000078f8213d92bc  pop rdi
000078f8213d92bd  pop rdx
000078f8213d92be  pop rcx
000078f8213d92bf  pop rax
000078f8213d92c0  add rsp, 0x08
000078f8213d92c4  jmp 0x000078F8213D6200
000078f8213d92c9  sub rsp, 0x08
000078f8213d92cd  push rax
000078f8213d92ce  push rcx
000078f8213d92cf  push rdx
000078f8213d92d0  push rdi
000078f8213d92d1  push rsi
000078f8213d92d2  push r8
000078f8213d92d4  push r9
000078f8213d92d6  push r10
000078f8213d92d8  push r11
000078f8213d92da  sub rsp, 0xF0
000078f8213d92e1  vmovaps [rsp], xmm0
000078f8213d92e6  vmovaps [rsp+0x10], xmm1
000078f8213d92ec  vmovaps [rsp+0x20], xmm2
000078f8213d92f2  vmovaps [rsp+0x30], xmm3
000078f8213d92f8  vmovaps [rsp+0x40], xmm4
000078f8213d92fe  vmovaps [rsp+0x50], xmm5
000078f8213d9304  vmovaps [rsp+0x60], xmm7
000078f8213d930a  vmovaps [rsp+0x70], xmm8
000078f8213d9310  vmovaps [rsp+0x80], xmm9
000078f8213d9319  vmovaps [rsp+0x90], xmm10
000078f8213d9322  vmovaps [rsp+0xA0], xmm11
000078f8213d932b  vmovaps [rsp+0xB0], xmm12
000078f8213d9334  vmovaps [rsp+0xC0], xmm13
000078f8213d933d  vmovaps [rsp+0xD0], xmm14
000078f8213d9346  vmovaps [rsp+0xE0], xmm15
000078f8213d934f  sub rsp, 0x30
000078f8213d9353  movaps [rsp], xmm6
000078f8213d9357  movaps [rsp+0x10], xmm10
000078f8213d935d  movaps [rsp+0x20], xmm8
000078f8213d9363  lea rdi, [rsp]
000078f8213d9367  mov esi, 0x00
000078f8213d936c  mov rax, 0x653D80F42530
000078f8213d9376  call rax
000078f8213d9378  movaps xmm6, [rsp]
000078f8213d937c  add rsp, 0x30
000078f8213d9380  vmovaps xmm0, [rsp]
000078f8213d9385  vmovaps xmm1, [rsp+0x10]
000078f8213d938b  vmovaps xmm2, [rsp+0x20]
000078f8213d9391  vmovaps xmm3, [rsp+0x30]
000078f8213d9397  vmovaps xmm4, [rsp+0x40]
000078f8213d939d  vmovaps xmm5, [rsp+0x50]
000078f8213d93a3  vmovaps xmm7, [rsp+0x60]
000078f8213d93a9  vmovaps xmm8, [rsp+0x70]
000078f8213d93af  vmovaps xmm9, [rsp+0x80]
000078f8213d93b8  vmovaps xmm10, [rsp+0x90]
000078f8213d93c1  vmovaps xmm11, [rsp+0xA0]
000078f8213d93ca  vmovaps xmm12, [rsp+0xB0]
000078f8213d93d3  vmovaps xmm13, [rsp+0xC0]
000078f8213d93dc  vmovaps xmm14, [rsp+0xD0]
000078f8213d93e5  vmovaps xmm15, [rsp+0xE0]
000078f8213d93ee  add rsp, 0xF0
000078f8213d93f5  pop r11
000078f8213d93f7  pop r10
000078f8213d93f9  pop r9
000078f8213d93fb  pop r8
000078f8213d93fd  pop rsi
000078f8213d93fe  pop rdi
000078f8213d93ff  pop rdx
000078f8213d9400  pop rcx
000078f8213d9401  pop rax
000078f8213d9402  add rsp, 0x08
000078f8213d9406  jmp 0x000078F8213D6225
000078f8213d940b  sub rsp, 0x08
000078f8213d940f  push rax
000078f8213d9410  push rcx
000078f8213d9411  push rdx
000078f8213d9412  push rdi
000078f8213d9413  push rsi
000078f8213d9414  push r8
000078f8213d9416  push r9
000078f8213d9418  push r10
000078f8213d941a  push r11
000078f8213d941c  sub rsp, 0xF0
000078f8213d9423  vmovaps [rsp], xmm0
000078f8213d9428  vmovaps [rsp+0x10], xmm1
000078f8213d942e  vmovaps [rsp+0x20], xmm2
000078f8213d9434  vmovaps [rsp+0x30], xmm3
000078f8213d943a  vmovaps [rsp+0x40], xmm4
000078f8213d9440  vmovaps [rsp+0x50], xmm5
000078f8213d9446  vmovaps [rsp+0x60], xmm6
000078f8213d944c  vmovaps [rsp+0x70], xmm7
000078f8213d9452  vmovaps [rsp+0x80], xmm8
000078f8213d945b  vmovaps [rsp+0x90], xmm9
000078f8213d9464  vmovaps [rsp+0xA0], xmm11
000078f8213d946d  vmovaps [rsp+0xB0], xmm12
000078f8213d9476  vmovaps [rsp+0xC0], xmm13
000078f8213d947f  vmovaps [rsp+0xD0], xmm14
000078f8213d9488  vmovaps [rsp+0xE0], xmm15
000078f8213d9491  sub rsp, 0x30
000078f8213d9495  movaps [rsp], xmm10
000078f8213d949a  movaps [rsp+0x10], xmm8
000078f8213d94a0  movaps [rsp+0x20], xmm14
000078f8213d94a6  lea rdi, [rsp]
000078f8213d94aa  mov esi, 0x00
000078f8213d94af  mov rax, 0x653D80F42530
000078f8213d94b9  call rax
000078f8213d94bb  movaps xmm10, [rsp]
000078f8213d94c0  add rsp, 0x30
000078f8213d94c4  vmovaps xmm0, [rsp]
000078f8213d94c9  vmovaps xmm1, [rsp+0x10]
000078f8213d94cf  vmovaps xmm2, [rsp+0x20]
000078f8213d94d5  vmovaps xmm3, [rsp+0x30]
000078f8213d94db  vmovaps xmm4, [rsp+0x40]
000078f8213d94e1  vmovaps xmm5, [rsp+0x50]
000078f8213d94e7  vmovaps xmm6, [rsp+0x60]
000078f8213d94ed  vmovaps xmm7, [rsp+0x70]
000078f8213d94f3  vmovaps xmm8, [rsp+0x80]
000078f8213d94fc  vmovaps xmm9, [rsp+0x90]
000078f8213d9505  vmovaps xmm11, [rsp+0xA0]
000078f8213d950e  vmovaps xmm12, [rsp+0xB0]
000078f8213d9517  vmovaps xmm13, [rsp+0xC0]
000078f8213d9520  vmovaps xmm14, [rsp+0xD0]
000078f8213d9529  vmovaps xmm15, [rsp+0xE0]
000078f8213d9532  add rsp, 0xF0
000078f8213d9539  pop r11
000078f8213d953b  pop r10
000078f8213d953d  pop r9
000078f8213d953f  pop r8
000078f8213d9541  pop rsi
000078f8213d9542  pop rdi
000078f8213d9543  pop rdx
000078f8213d9544  pop rcx
000078f8213d9545  pop rax
000078f8213d9546  add rsp, 0x08
000078f8213d954a  jmp 0x000078F8213D6245
000078f8213d954f  sub rsp, 0x08
000078f8213d9553  push rax
000078f8213d9554  push rcx
000078f8213d9555  push rdx
000078f8213d9556  push rdi
000078f8213d9557  push rsi
000078f8213d9558  push r8
000078f8213d955a  push r9
000078f8213d955c  push r10
000078f8213d955e  push r11
000078f8213d9560  sub rsp, 0xF0
000078f8213d9567  vmovaps [rsp], xmm0
000078f8213d956c  vmovaps [rsp+0x10], xmm1
000078f8213d9572  vmovaps [rsp+0x20], xmm2
000078f8213d9578  vmovaps [rsp+0x30], xmm3
000078f8213d957e  vmovaps [rsp+0x40], xmm4
000078f8213d9584  vmovaps [rsp+0x50], xmm5
000078f8213d958a  vmovaps [rsp+0x60], xmm6
000078f8213d9590  vmovaps [rsp+0x70], xmm7
000078f8213d9596  vmovaps [rsp+0x80], xmm8
000078f8213d959f  vmovaps [rsp+0x90], xmm9
000078f8213d95a8  vmovaps [rsp+0xA0], xmm10
000078f8213d95b1  vmovaps [rsp+0xB0], xmm11
000078f8213d95ba  vmovaps [rsp+0xC0], xmm12
000078f8213d95c3  vmovaps [rsp+0xD0], xmm13
000078f8213d95cc  vmovaps [rsp+0xE0], xmm15
000078f8213d95d5  sub rsp, 0x30
000078f8213d95d9  movaps [rsp], xmm14
000078f8213d95de  movaps [rsp+0x10], xmm8
000078f8213d95e4  movaps [rsp+0x20], xmm4
000078f8213d95e9  lea rdi, [rsp]
000078f8213d95ed  mov esi, 0x00
000078f8213d95f2  mov rax, 0x653D80F42530
000078f8213d95fc  call rax
000078f8213d95fe  movaps xmm14, [rsp]
000078f8213d9603  add rsp, 0x30
000078f8213d9607  vmovaps xmm0, [rsp]
000078f8213d960c  vmovaps xmm1, [rsp+0x10]
000078f8213d9612  vmovaps xmm2, [rsp+0x20]
000078f8213d9618  vmovaps xmm3, [rsp+0x30]
000078f8213d961e  vmovaps xmm4, [rsp+0x40]
000078f8213d9624  vmovaps xmm5, [rsp+0x50]
000078f8213d962a  vmovaps xmm6, [rsp+0x60]
000078f8213d9630  vmovaps xmm7, [rsp+0x70]
000078f8213d9636  vmovaps xmm8, [rsp+0x80]
000078f8213d963f  vmovaps xmm9, [rsp+0x90]
000078f8213d9648  vmovaps xmm10, [rsp+0xA0]
000078f8213d9651  vmovaps xmm11, [rsp+0xB0]
000078f8213d965a  vmovaps xmm12, [rsp+0xC0]
000078f8213d9663  vmovaps xmm13, [rsp+0xD0]
000078f8213d966c  vmovaps xmm15, [rsp+0xE0]
000078f8213d9675  add rsp, 0xF0
000078f8213d967c  pop r11
000078f8213d967e  pop r10
000078f8213d9680  pop r9
000078f8213d9682  pop r8
000078f8213d9684  pop rsi
000078f8213d9685  pop rdi
000078f8213d9686  pop rdx
000078f8213d9687  pop rcx
000078f8213d9688  pop rax
000078f8213d9689  add rsp, 0x08
000078f8213d968d  jmp 0x000078F8213D6265
000078f8213d9692  sub rsp, 0x08
000078f8213d9696  push rax
000078f8213d9697  push rcx
000078f8213d9698  push rdx
000078f8213d9699  push rdi
000078f8213d969a  push rsi
000078f8213d969b  push r8
000078f8213d969d  push r9
000078f8213d969f  push r10
000078f8213d96a1  push r11
000078f8213d96a3  sub rsp, 0xF0
000078f8213d96aa  vmovaps [rsp], xmm0
000078f8213d96af  vmovaps [rsp+0x10], xmm1
000078f8213d96b5  vmovaps [rsp+0x20], xmm2
000078f8213d96bb  vmovaps [rsp+0x30], xmm3
000078f8213d96c1  vmovaps [rsp+0x40], xmm5
000078f8213d96c7  vmovaps [rsp+0x50], xmm6
000078f8213d96cd  vmovaps [rsp+0x60], xmm7
000078f8213d96d3  vmovaps [rsp+0x70], xmm8
000078f8213d96d9  vmovaps [rsp+0x80], xmm9
000078f8213d96e2  vmovaps [rsp+0x90], xmm10
000078f8213d96eb  vmovaps [rsp+0xA0], xmm11
000078f8213d96f4  vmovaps [rsp+0xB0], xmm12
000078f8213d96fd  vmovaps [rsp+0xC0], xmm13
000078f8213d9706  vmovaps [rsp+0xD0], xmm14
000078f8213d970f  vmovaps [rsp+0xE0], xmm15
000078f8213d9718  sub rsp, 0x30
000078f8213d971c  movaps [rsp], xmm4
000078f8213d9720  movaps [rsp+0x10], xmm13
000078f8213d9726  movaps [rsp+0x20], xmm8
000078f8213d972c  lea rdi, [rsp]
000078f8213d9730  mov esi, 0x00
000078f8213d9735  mov rax, 0x653D80F42530
000078f8213d973f  call rax
000078f8213d9741  movaps xmm4, [rsp]
000078f8213d9745  add rsp, 0x30
000078f8213d9749  vmovaps xmm0, [rsp]
000078f8213d974e  vmovaps xmm1, [rsp+0x10]
000078f8213d9754  vmovaps xmm2, [rsp+0x20]
000078f8213d975a  vmovaps xmm3, [rsp+0x30]
000078f8213d9760  vmovaps xmm5, [rsp+0x40]
000078f8213d9766  vmovaps xmm6, [rsp+0x50]
000078f8213d976c  vmovaps xmm7, [rsp+0x60]
000078f8213d9772  vmovaps xmm8, [rsp+0x70]
000078f8213d9778  vmovaps xmm9, [rsp+0x80]
000078f8213d9781  vmovaps xmm10, [rsp+0x90]
000078f8213d978a  vmovaps xmm11, [rsp+0xA0]
000078f8213d9793  vmovaps xmm12, [rsp+0xB0]
000078f8213d979c  vmovaps xmm13, [rsp+0xC0]
000078f8213d97a5  vmovaps xmm14, [rsp+0xD0]
000078f8213d97ae  vmovaps xmm15, [rsp+0xE0]
000078f8213d97b7  add rsp, 0xF0
000078f8213d97be  pop r11
000078f8213d97c0  pop r10
000078f8213d97c2  pop r9
000078f8213d97c4  pop r8
000078f8213d97c6  pop rsi
000078f8213d97c7  pop rdi
000078f8213d97c8  pop rdx
000078f8213d97c9  pop rcx
000078f8213d97ca  pop rax
000078f8213d97cb  add rsp, 0x08
000078f8213d97cf  jmp 0x000078F8213D628A
000078f8213d97d4  sub rsp, 0x08
000078f8213d97d8  push rax
000078f8213d97d9  push rcx
000078f8213d97da  push rdx
000078f8213d97db  push rdi
000078f8213d97dc  push rsi
000078f8213d97dd  push r8
000078f8213d97df  push r9
000078f8213d97e1  push r10
000078f8213d97e3  push r11
000078f8213d97e5  sub rsp, 0xF0
000078f8213d97ec  vmovaps [rsp], xmm0
000078f8213d97f1  vmovaps [rsp+0x10], xmm1
000078f8213d97f7  vmovaps [rsp+0x20], xmm2
000078f8213d97fd  vmovaps [rsp+0x30], xmm3
000078f8213d9803  vmovaps [rsp+0x40], xmm4
000078f8213d9809  vmovaps [rsp+0x50], xmm5
000078f8213d980f  vmovaps [rsp+0x60], xmm6
000078f8213d9815  vmovaps [rsp+0x70], xmm7
000078f8213d981b  vmovaps [rsp+0x80], xmm8
000078f8213d9824  vmovaps [rsp+0x90], xmm9
000078f8213d982d  vmovaps [rsp+0xA0], xmm10
000078f8213d9836  vmovaps [rsp+0xB0], xmm11
000078f8213d983f  vmovaps [rsp+0xC0], xmm12
000078f8213d9848  vmovaps [rsp+0xD0], xmm14
000078f8213d9851  vmovaps [rsp+0xE0], xmm15
000078f8213d985a  sub rsp, 0x30
000078f8213d985e  movaps [rsp], xmm13
000078f8213d9863  movaps [rsp+0x10], xmm15
000078f8213d9869  movaps [rsp+0x20], xmm9
000078f8213d986f  lea rdi, [rsp]
000078f8213d9873  mov esi, 0x00
000078f8213d9878  mov rax, 0x653D80F42530
000078f8213d9882  call rax
000078f8213d9884  movaps xmm13, [rsp]
000078f8213d9889  add rsp, 0x30
000078f8213d988d  vmovaps xmm0, [rsp]
000078f8213d9892  vmovaps xmm1, [rsp+0x10]
000078f8213d9898  vmovaps xmm2, [rsp+0x20]
000078f8213d989e  vmovaps xmm3, [rsp+0x30]
000078f8213d98a4  vmovaps xmm4, [rsp+0x40]
000078f8213d98aa  vmovaps xmm5, [rsp+0x50]
000078f8213d98b0  vmovaps xmm6, [rsp+0x60]
000078f8213d98b6  vmovaps xmm7, [rsp+0x70]
000078f8213d98bc  vmovaps xmm8, [rsp+0x80]
000078f8213d98c5  vmovaps xmm9, [rsp+0x90]
000078f8213d98ce  vmovaps xmm10, [rsp+0xA0]
000078f8213d98d7  vmovaps xmm11, [rsp+0xB0]
000078f8213d98e0  vmovaps xmm12, [rsp+0xC0]
000078f8213d98e9  vmovaps xmm14, [rsp+0xD0]
000078f8213d98f2  vmovaps xmm15, [rsp+0xE0]
000078f8213d98fb  add rsp, 0xF0
000078f8213d9902  pop r11
000078f8213d9904  pop r10
000078f8213d9906  pop r9
000078f8213d9908  pop r8
000078f8213d990a  pop rsi
000078f8213d990b  pop rdi
000078f8213d990c  pop rdx
000078f8213d990d  pop rcx
000078f8213d990e  pop rax
000078f8213d990f  add rsp, 0x08
000078f8213d9913  jmp 0x000078F8213D62A5
000078f8213d9918  sub rsp, 0x08
000078f8213d991c  push rax
000078f8213d991d  push rcx
000078f8213d991e  push rdx
000078f8213d991f  push rdi
000078f8213d9920  push rsi
000078f8213d9921  push r8
000078f8213d9923  push r9
000078f8213d9925  push r10
000078f8213d9927  push r11
000078f8213d9929  sub rsp, 0xF0
000078f8213d9930  vmovaps [rsp], xmm0
000078f8213d9935  vmovaps [rsp+0x10], xmm1
000078f8213d993b  vmovaps [rsp+0x20], xmm2
000078f8213d9941  vmovaps [rsp+0x30], xmm3
000078f8213d9947  vmovaps [rsp+0x40], xmm4
000078f8213d994d  vmovaps [rsp+0x50], xmm5
000078f8213d9953  vmovaps [rsp+0x60], xmm6
000078f8213d9959  vmovaps [rsp+0x70], xmm7
000078f8213d995f  vmovaps [rsp+0x80], xmm8
000078f8213d9968  vmovaps [rsp+0x90], xmm9
000078f8213d9971  vmovaps [rsp+0xA0], xmm10
000078f8213d997a  vmovaps [rsp+0xB0], xmm11
000078f8213d9983  vmovaps [rsp+0xC0], xmm12
000078f8213d998c  vmovaps [rsp+0xD0], xmm13
000078f8213d9995  vmovaps [rsp+0xE0], xmm14
000078f8213d999e  sub rsp, 0x30
000078f8213d99a2  movaps [rsp], xmm15
000078f8213d99a7  movaps [rsp+0x10], xmm1
000078f8213d99ac  movaps [rsp+0x20], xmm5
000078f8213d99b1  lea rdi, [rsp]
000078f8213d99b5  mov esi, 0x00
000078f8213d99ba  mov rax, 0x653D80F42530
000078f8213d99c4  call rax
000078f8213d99c6  movaps xmm15, [rsp]
000078f8213d99cb  add rsp, 0x30
000078f8213d99cf  vmovaps xmm0, [rsp]
000078f8213d99d4  vmovaps xmm1, [rsp+0x10]
000078f8213d99da  vmovaps xmm2, [rsp+0x20]
000078f8213d99e0  vmovaps xmm3, [rsp+0x30]
000078f8213d99e6  vmovaps xmm4, [rsp+0x40]
000078f8213d99ec  vmovaps xmm5, [rsp+0x50]
000078f8213d99f2  vmovaps xmm6, [rsp+0x60]
000078f8213d99f8  vmovaps xmm7, [rsp+0x70]
000078f8213d99fe  vmovaps xmm8, [rsp+0x80]
000078f8213d9a07  vmovaps xmm9, [rsp+0x90]
000078f8213d9a10  vmovaps xmm10, [rsp+0xA0]
000078f8213d9a19  vmovaps xmm11, [rsp+0xB0]
000078f8213d9a22  vmovaps xmm12, [rsp+0xC0]
000078f8213d9a2b  vmovaps xmm13, [rsp+0xD0]
000078f8213d9a34  vmovaps xmm14, [rsp+0xE0]
000078f8213d9a3d  add rsp, 0xF0
000078f8213d9a44  pop r11
000078f8213d9a46  pop r10
000078f8213d9a48  pop r9
000078f8213d9a4a  pop r8
000078f8213d9a4c  pop rsi
000078f8213d9a4d  pop rdi
000078f8213d9a4e  pop rdx
000078f8213d9a4f  pop rcx
000078f8213d9a50  pop rax
000078f8213d9a51  add rsp, 0x08
000078f8213d9a55  jmp 0x000078F8213D62C0
000078f8213d9a5a  call 0x000078F8212D64F0
000078f8213d9a5f  jmp 0x000078F8213D631B
000078f8213d9a64  sub rsp, 0x08
000078f8213d9a68  push rax
000078f8213d9a69  push rcx
000078f8213d9a6a  push rdx
000078f8213d9a6b  push rdi
000078f8213d9a6c  push rsi
000078f8213d9a6d  push r8
000078f8213d9a6f  push r9
000078f8213d9a71  push r10
000078f8213d9a73  push r11
000078f8213d9a75  sub rsp, 0xF0
000078f8213d9a7c  vmovaps [rsp], xmm0
000078f8213d9a81  vmovaps [rsp+0x10], xmm1
000078f8213d9a87  vmovaps [rsp+0x20], xmm2
000078f8213d9a8d  vmovaps [rsp+0x30], xmm3
000078f8213d9a93  vmovaps [rsp+0x40], xmm4
000078f8213d9a99  vmovaps [rsp+0x50], xmm5
000078f8213d9a9f  vmovaps [rsp+0x60], xmm6
000078f8213d9aa5  vmovaps [rsp+0x70], xmm7
000078f8213d9aab  vmovaps [rsp+0x80], xmm8
000078f8213d9ab4  vmovaps [rsp+0x90], xmm10
000078f8213d9abd  vmovaps [rsp+0xA0], xmm11
000078f8213d9ac6  vmovaps [rsp+0xB0], xmm12
000078f8213d9acf  vmovaps [rsp+0xC0], xmm13
000078f8213d9ad8  vmovaps [rsp+0xD0], xmm14
000078f8213d9ae1  vmovaps [rsp+0xE0], xmm15
000078f8213d9aea  sub rsp, 0x30
000078f8213d9aee  movaps [rsp], xmm9
000078f8213d9af3  movaps [rsp+0x10], xmm8
000078f8213d9af9  movaps [rsp+0x20], xmm11
000078f8213d9aff  lea rdi, [rsp]
000078f8213d9b03  mov esi, 0x00
000078f8213d9b08  mov rax, 0x653D80F42530
000078f8213d9b12  call rax
000078f8213d9b14  movaps xmm9, [rsp]
000078f8213d9b19  add rsp, 0x30
000078f8213d9b1d  vmovaps xmm0, [rsp]
000078f8213d9b22  vmovaps xmm1, [rsp+0x10]
000078f8213d9b28  vmovaps xmm2, [rsp+0x20]
000078f8213d9b2e  vmovaps xmm3, [rsp+0x30]
000078f8213d9b34  vmovaps xmm4, [rsp+0x40]
000078f8213d9b3a  vmovaps xmm5, [rsp+0x50]
000078f8213d9b40  vmovaps xmm6, [rsp+0x60]
000078f8213d9b46  vmovaps xmm7, [rsp+0x70]
000078f8213d9b4c  vmovaps xmm8, [rsp+0x80]
000078f8213d9b55  vmovaps xmm10, [rsp+0x90]
000078f8213d9b5e  vmovaps xmm11, [rsp+0xA0]
000078f8213d9b67  vmovaps xmm12, [rsp+0xB0]
000078f8213d9b70  vmovaps xmm13, [rsp+0xC0]
000078f8213d9b79  vmovaps xmm14, [rsp+0xD0]
000078f8213d9b82  vmovaps xmm15, [rsp+0xE0]
000078f8213d9b8b  add rsp, 0xF0
000078f8213d9b92  pop r11
000078f8213d9b94  pop r10
000078f8213d9b96  pop r9
000078f8213d9b98  pop r8
000078f8213d9b9a  pop rsi
000078f8213d9b9b  pop rdi
000078f8213d9b9c  pop rdx
000078f8213d9b9d  pop rcx
000078f8213d9b9e  pop rax
000078f8213d9b9f  add rsp, 0x08
000078f8213d9ba3  jmp 0x000078F8213D6352
000078f8213d9ba8  sub rsp, 0x08
000078f8213d9bac  push rax
000078f8213d9bad  push rcx
000078f8213d9bae  push rdx
000078f8213d9baf  push rdi
000078f8213d9bb0  push rsi
000078f8213d9bb1  push r8
000078f8213d9bb3  push r9
000078f8213d9bb5  push r10
000078f8213d9bb7  push r11
000078f8213d9bb9  sub rsp, 0xF0
000078f8213d9bc0  vmovaps [rsp], xmm0
000078f8213d9bc5  vmovaps [rsp+0x10], xmm1
000078f8213d9bcb  vmovaps [rsp+0x20], xmm2
000078f8213d9bd1  vmovaps [rsp+0x30], xmm3
000078f8213d9bd7  vmovaps [rsp+0x40], xmm4
000078f8213d9bdd  vmovaps [rsp+0x50], xmm5
000078f8213d9be3  vmovaps [rsp+0x60], xmm6
000078f8213d9be9  vmovaps [rsp+0x70], xmm7
000078f8213d9bef  vmovaps [rsp+0x80], xmm8
000078f8213d9bf8  vmovaps [rsp+0x90], xmm9
000078f8213d9c01  vmovaps [rsp+0xA0], xmm10
000078f8213d9c0a  vmovaps [rsp+0xB0], xmm12
000078f8213d9c13  vmovaps [rsp+0xC0], xmm13
000078f8213d9c1c  vmovaps [rsp+0xD0], xmm14
000078f8213d9c25  vmovaps [rsp+0xE0], xmm15
000078f8213d9c2e  sub rsp, 0x30
000078f8213d9c32  movaps [rsp], xmm11
000078f8213d9c37  movaps [rsp+0x10], xmm10
000078f8213d9c3d  movaps [rsp+0x20], xmm6
000078f8213d9c42  lea rdi, [rsp]
000078f8213d9c46  mov esi, 0x00
000078f8213d9c4b  mov rax, 0x653D80F42530
000078f8213d9c55  call rax
000078f8213d9c57  movaps xmm11, [rsp]
000078f8213d9c5c  add rsp, 0x30
000078f8213d9c60  vmovaps xmm0, [rsp]
000078f8213d9c65  vmovaps xmm1, [rsp+0x10]
000078f8213d9c6b  vmovaps xmm2, [rsp+0x20]
000078f8213d9c71  vmovaps xmm3, [rsp+0x30]
000078f8213d9c77  vmovaps xmm4, [rsp+0x40]
000078f8213d9c7d  vmovaps xmm5, [rsp+0x50]
000078f8213d9c83  vmovaps xmm6, [rsp+0x60]
000078f8213d9c89  vmovaps xmm7, [rsp+0x70]
000078f8213d9c8f  vmovaps xmm8, [rsp+0x80]
000078f8213d9c98  vmovaps xmm9, [rsp+0x90]
000078f8213d9ca1  vmovaps xmm10, [rsp+0xA0]
000078f8213d9caa  vmovaps xmm12, [rsp+0xB0]
000078f8213d9cb3  vmovaps xmm13, [rsp+0xC0]
000078f8213d9cbc  vmovaps xmm14, [rsp+0xD0]
000078f8213d9cc5  vmovaps xmm15, [rsp+0xE0]
000078f8213d9cce  add rsp, 0xF0
000078f8213d9cd5  pop r11
000078f8213d9cd7  pop r10
000078f8213d9cd9  pop r9
000078f8213d9cdb  pop r8
000078f8213d9cdd  pop rsi
000078f8213d9cde  pop rdi
000078f8213d9cdf  pop rdx
000078f8213d9ce0  pop rcx
000078f8213d9ce1  pop rax
000078f8213d9ce2  add rsp, 0x08
000078f8213d9ce6  jmp 0x000078F8213D636D
000078f8213d9ceb  sub rsp, 0x08
000078f8213d9cef  push rax
000078f8213d9cf0  push rcx
000078f8213d9cf1  push rdx
000078f8213d9cf2  push rdi
000078f8213d9cf3  push rsi
000078f8213d9cf4  push r8
000078f8213d9cf6  push r9
000078f8213d9cf8  push r10
000078f8213d9cfa  push r11
000078f8213d9cfc  sub rsp, 0xF0
000078f8213d9d03  vmovaps [rsp], xmm0
000078f8213d9d08  vmovaps [rsp+0x10], xmm1
000078f8213d9d0e  vmovaps [rsp+0x20], xmm2
000078f8213d9d14  vmovaps [rsp+0x30], xmm3
000078f8213d9d1a  vmovaps [rsp+0x40], xmm4
000078f8213d9d20  vmovaps [rsp+0x50], xmm5
000078f8213d9d26  vmovaps [rsp+0x60], xmm6
000078f8213d9d2c  vmovaps [rsp+0x70], xmm7
000078f8213d9d32  vmovaps [rsp+0x80], xmm8
000078f8213d9d3b  vmovaps [rsp+0x90], xmm9
000078f8213d9d44  vmovaps [rsp+0xA0], xmm11
000078f8213d9d4d  vmovaps [rsp+0xB0], xmm12
000078f8213d9d56  vmovaps [rsp+0xC0], xmm13
000078f8213d9d5f  vmovaps [rsp+0xD0], xmm14
000078f8213d9d68  vmovaps [rsp+0xE0], xmm15
000078f8213d9d71  sub rsp, 0x30
000078f8213d9d75  movaps [rsp], xmm10
000078f8213d9d7a  movaps [rsp+0x10], xmm14
000078f8213d9d80  movaps [rsp+0x20], xmm4
000078f8213d9d85  lea rdi, [rsp]
000078f8213d9d89  mov esi, 0x00
000078f8213d9d8e  mov rax, 0x653D80F42530
000078f8213d9d98  call rax
000078f8213d9d9a  movaps xmm10, [rsp]
000078f8213d9d9f  add rsp, 0x30
000078f8213d9da3  vmovaps xmm0, [rsp]
000078f8213d9da8  vmovaps xmm1, [rsp+0x10]
000078f8213d9dae  vmovaps xmm2, [rsp+0x20]
000078f8213d9db4  vmovaps xmm3, [rsp+0x30]
000078f8213d9dba  vmovaps xmm4, [rsp+0x40]
000078f8213d9dc0  vmovaps xmm5, [rsp+0x50]
000078f8213d9dc6  vmovaps xmm6, [rsp+0x60]
000078f8213d9dcc  vmovaps xmm7, [rsp+0x70]
000078f8213d9dd2  vmovaps xmm8, [rsp+0x80]
000078f8213d9ddb  vmovaps xmm9, [rsp+0x90]
000078f8213d9de4  vmovaps xmm11, [rsp+0xA0]
000078f8213d9ded  vmovaps xmm12, [rsp+0xB0]
000078f8213d9df6  vmovaps xmm13, [rsp+0xC0]
000078f8213d9dff  vmovaps xmm14, [rsp+0xD0]
000078f8213d9e08  vmovaps xmm15, [rsp+0xE0]
000078f8213d9e11  add rsp, 0xF0
000078f8213d9e18  pop r11
000078f8213d9e1a  pop r10
000078f8213d9e1c  pop r9
000078f8213d9e1e  pop r8
000078f8213d9e20  pop rsi
000078f8213d9e21  pop rdi
000078f8213d9e22  pop rdx
000078f8213d9e23  pop rcx
000078f8213d9e24  pop rax
000078f8213d9e25  add rsp, 0x08
000078f8213d9e29  jmp 0x000078F8213D6388
000078f8213d9e2e  sub rsp, 0x08
000078f8213d9e32  push rax
000078f8213d9e33  push rcx
000078f8213d9e34  push rdx
000078f8213d9e35  push rdi
000078f8213d9e36  push rsi
000078f8213d9e37  push r8
000078f8213d9e39  push r9
000078f8213d9e3b  push r10
000078f8213d9e3d  push r11
000078f8213d9e3f  sub rsp, 0xF0
000078f8213d9e46  vmovaps [rsp], xmm0
000078f8213d9e4b  vmovaps [rsp+0x10], xmm1
000078f8213d9e51  vmovaps [rsp+0x20], xmm2
000078f8213d9e57  vmovaps [rsp+0x30], xmm3
000078f8213d9e5d  vmovaps [rsp+0x40], xmm4
000078f8213d9e63  vmovaps [rsp+0x50], xmm5
000078f8213d9e69  vmovaps [rsp+0x60], xmm6
000078f8213d9e6f  vmovaps [rsp+0x70], xmm7
000078f8213d9e75  vmovaps [rsp+0x80], xmm9
000078f8213d9e7e  vmovaps [rsp+0x90], xmm10
000078f8213d9e87  vmovaps [rsp+0xA0], xmm11
000078f8213d9e90  vmovaps [rsp+0xB0], xmm12
000078f8213d9e99  vmovaps [rsp+0xC0], xmm13
000078f8213d9ea2  vmovaps [rsp+0xD0], xmm14
000078f8213d9eab  vmovaps [rsp+0xE0], xmm15
000078f8213d9eb4  sub rsp, 0x30
000078f8213d9eb8  movaps [rsp], xmm8
000078f8213d9ebd  movaps [rsp+0x10], xmm1
000078f8213d9ec2  movaps [rsp+0x20], xmm14
000078f8213d9ec8  lea rdi, [rsp]
000078f8213d9ecc  mov esi, 0x00
000078f8213d9ed1  mov rax, 0x653D80F42530
000078f8213d9edb  call rax
000078f8213d9edd  movaps xmm8, [rsp]
000078f8213d9ee2  add rsp, 0x30
000078f8213d9ee6  vmovaps xmm0, [rsp]
000078f8213d9eeb  vmovaps xmm1, [rsp+0x10]
000078f8213d9ef1  vmovaps xmm2, [rsp+0x20]
000078f8213d9ef7  vmovaps xmm3, [rsp+0x30]
000078f8213d9efd  vmovaps xmm4, [rsp+0x40]
000078f8213d9f03  vmovaps xmm5, [rsp+0x50]
000078f8213d9f09  vmovaps xmm6, [rsp+0x60]
000078f8213d9f0f  vmovaps xmm7, [rsp+0x70]
000078f8213d9f15  vmovaps xmm9, [rsp+0x80]
000078f8213d9f1e  vmovaps xmm10, [rsp+0x90]
000078f8213d9f27  vmovaps xmm11, [rsp+0xA0]
000078f8213d9f30  vmovaps xmm12, [rsp+0xB0]
000078f8213d9f39  vmovaps xmm13, [rsp+0xC0]
000078f8213d9f42  vmovaps xmm14, [rsp+0xD0]
000078f8213d9f4b  vmovaps xmm15, [rsp+0xE0]
000078f8213d9f54  add rsp, 0xF0
000078f8213d9f5b  pop r11
000078f8213d9f5d  pop r10
000078f8213d9f5f  pop r9
000078f8213d9f61  pop r8
000078f8213d9f63  pop rsi
000078f8213d9f64  pop rdi
000078f8213d9f65  pop rdx
000078f8213d9f66  pop rcx
000078f8213d9f67  pop rax
000078f8213d9f68  add rsp, 0x08
000078f8213d9f6c  jmp 0x000078F8213D63AE
000078f8213d9f71  sub rsp, 0x08
000078f8213d9f75  push rax
000078f8213d9f76  push rcx
000078f8213d9f77  push rdx
000078f8213d9f78  push rdi
000078f8213d9f79  push rsi
000078f8213d9f7a  push r8
000078f8213d9f7c  push r9
000078f8213d9f7e  push r10
000078f8213d9f80  push r11
000078f8213d9f82  sub rsp, 0xF0
000078f8213d9f89  vmovaps [rsp], xmm0
000078f8213d9f8e  vmovaps [rsp+0x10], xmm1
000078f8213d9f94  vmovaps [rsp+0x20], xmm2
000078f8213d9f9a  vmovaps [rsp+0x30], xmm3
000078f8213d9fa0  vmovaps [rsp+0x40], xmm4
000078f8213d9fa6  vmovaps [rsp+0x50], xmm5
000078f8213d9fac  vmovaps [rsp+0x60], xmm7
000078f8213d9fb2  vmovaps [rsp+0x70], xmm8
000078f8213d9fb8  vmovaps [rsp+0x80], xmm9
000078f8213d9fc1  vmovaps [rsp+0x90], xmm10
000078f8213d9fca  vmovaps [rsp+0xA0], xmm11
000078f8213d9fd3  vmovaps [rsp+0xB0], xmm12
000078f8213d9fdc  vmovaps [rsp+0xC0], xmm13
000078f8213d9fe5  vmovaps [rsp+0xD0], xmm14
000078f8213d9fee  vmovaps [rsp+0xE0], xmm15
000078f8213d9ff7  sub rsp, 0x30
000078f8213d9ffb  movaps [rsp], xmm6
000078f8213d9fff  movaps [rsp+0x10], xmm1
000078f8213da004  movaps [rsp+0x20], xmm14
000078f8213da00a  lea rdi, [rsp]
000078f8213da00e  mov esi, 0x00
000078f8213da013  mov rax, 0x653D80F42530
000078f8213da01d  call rax
000078f8213da01f  movaps xmm6, [rsp]
000078f8213da023  add rsp, 0x30
000078f8213da027  vmovaps xmm0, [rsp]
000078f8213da02c  vmovaps xmm1, [rsp+0x10]
000078f8213da032  vmovaps xmm2, [rsp+0x20]
000078f8213da038  vmovaps xmm3, [rsp+0x30]
000078f8213da03e  vmovaps xmm4, [rsp+0x40]
000078f8213da044  vmovaps xmm5, [rsp+0x50]
000078f8213da04a  vmovaps xmm7, [rsp+0x60]
000078f8213da050  vmovaps xmm8, [rsp+0x70]
000078f8213da056  vmovaps xmm9, [rsp+0x80]
000078f8213da05f  vmovaps xmm10, [rsp+0x90]
000078f8213da068  vmovaps xmm11, [rsp+0xA0]
000078f8213da071  vmovaps xmm12, [rsp+0xB0]
000078f8213da07a  vmovaps xmm13, [rsp+0xC0]
000078f8213da083  vmovaps xmm14, [rsp+0xD0]
000078f8213da08c  vmovaps xmm15, [rsp+0xE0]
000078f8213da095  add rsp, 0xF0
000078f8213da09c  pop r11
000078f8213da09e  pop r10
000078f8213da0a0  pop r9
000078f8213da0a2  pop r8
000078f8213da0a4  pop rsi
000078f8213da0a5  pop rdi
000078f8213da0a6  pop rdx
000078f8213da0a7  pop rcx
000078f8213da0a8  pop rax
000078f8213da0a9  add rsp, 0x08
000078f8213da0ad  jmp 0x000078F8213D63DA
000078f8213da0b2  sub rsp, 0x08
000078f8213da0b6  push rax
000078f8213da0b7  push rcx
000078f8213da0b8  push rdx
000078f8213da0b9  push rdi
000078f8213da0ba  push rsi
000078f8213da0bb  push r8
000078f8213da0bd  push r9
000078f8213da0bf  push r10
000078f8213da0c1  push r11
000078f8213da0c3  sub rsp, 0xF0
000078f8213da0ca  vmovaps [rsp], xmm0
000078f8213da0cf  vmovaps [rsp+0x10], xmm1
000078f8213da0d5  vmovaps [rsp+0x20], xmm2
000078f8213da0db  vmovaps [rsp+0x30], xmm3
000078f8213da0e1  vmovaps [rsp+0x40], xmm4
000078f8213da0e7  vmovaps [rsp+0x50], xmm5
000078f8213da0ed  vmovaps [rsp+0x60], xmm6
000078f8213da0f3  vmovaps [rsp+0x70], xmm7
000078f8213da0f9  vmovaps [rsp+0x80], xmm8
000078f8213da102  vmovaps [rsp+0x90], xmm9
000078f8213da10b  vmovaps [rsp+0xA0], xmm10
000078f8213da114  vmovaps [rsp+0xB0], xmm11
000078f8213da11d  vmovaps [rsp+0xC0], xmm12
000078f8213da126  vmovaps [rsp+0xD0], xmm13
000078f8213da12f  vmovaps [rsp+0xE0], xmm15
000078f8213da138  sub rsp, 0x30
000078f8213da13c  movaps [rsp], xmm14
000078f8213da141  movaps [rsp+0x10], xmm12
000078f8213da147  movaps [rsp+0x20], xmm1
000078f8213da14c  lea rdi, [rsp]
000078f8213da150  mov esi, 0x00
000078f8213da155  mov rax, 0x653D80F42530
000078f8213da15f  call rax
000078f8213da161  movaps xmm14, [rsp]
000078f8213da166  add rsp, 0x30
000078f8213da16a  vmovaps xmm0, [rsp]
000078f8213da16f  vmovaps xmm1, [rsp+0x10]
000078f8213da175  vmovaps xmm2, [rsp+0x20]
000078f8213da17b  vmovaps xmm3, [rsp+0x30]
000078f8213da181  vmovaps xmm4, [rsp+0x40]
000078f8213da187  vmovaps xmm5, [rsp+0x50]
000078f8213da18d  vmovaps xmm6, [rsp+0x60]
000078f8213da193  vmovaps xmm7, [rsp+0x70]
000078f8213da199  vmovaps xmm8, [rsp+0x80]
000078f8213da1a2  vmovaps xmm9, [rsp+0x90]
000078f8213da1ab  vmovaps xmm10, [rsp+0xA0]
000078f8213da1b4  vmovaps xmm11, [rsp+0xB0]
000078f8213da1bd  vmovaps xmm12, [rsp+0xC0]
000078f8213da1c6  vmovaps xmm13, [rsp+0xD0]
000078f8213da1cf  vmovaps xmm15, [rsp+0xE0]
000078f8213da1d8  add rsp, 0xF0
000078f8213da1df  pop r11
000078f8213da1e1  pop r10
000078f8213da1e3  pop r9
000078f8213da1e5  pop r8
000078f8213da1e7  pop rsi
000078f8213da1e8  pop rdi
000078f8213da1e9  pop rdx
000078f8213da1ea  pop rcx
000078f8213da1eb  pop rax
000078f8213da1ec  add rsp, 0x08
000078f8213da1f0  jmp 0x000078F8213D6400
000078f8213da1f5  sub rsp, 0x08
000078f8213da1f9  push rax
000078f8213da1fa  push rcx
000078f8213da1fb  push rdx
000078f8213da1fc  push rdi
000078f8213da1fd  push rsi
000078f8213da1fe  push r8
000078f8213da200  push r9
000078f8213da202  push r10
000078f8213da204  push r11
000078f8213da206  sub rsp, 0xF0
000078f8213da20d  vmovaps [rsp], xmm0
000078f8213da212  vmovaps [rsp+0x10], xmm2
000078f8213da218  vmovaps [rsp+0x20], xmm3
000078f8213da21e  vmovaps [rsp+0x30], xmm4
000078f8213da224  vmovaps [rsp+0x40], xmm5
000078f8213da22a  vmovaps [rsp+0x50], xmm6
000078f8213da230  vmovaps [rsp+0x60], xmm7
000078f8213da236  vmovaps [rsp+0x70], xmm8
000078f8213da23c  vmovaps [rsp+0x80], xmm9
000078f8213da245  vmovaps [rsp+0x90], xmm10
000078f8213da24e  vmovaps [rsp+0xA0], xmm11
000078f8213da257  vmovaps [rsp+0xB0], xmm12
000078f8213da260  vmovaps [rsp+0xC0], xmm13
000078f8213da269  vmovaps [rsp+0xD0], xmm14
000078f8213da272  vmovaps [rsp+0xE0], xmm15
000078f8213da27b  sub rsp, 0x30
000078f8213da27f  movaps [rsp], xmm1
000078f8213da283  movaps [rsp+0x10], xmm13
000078f8213da289  movaps [rsp+0x20], xmm9
000078f8213da28f  lea rdi, [rsp]
000078f8213da293  mov esi, 0x00
000078f8213da298  mov rax, 0x653D80F42530
000078f8213da2a2  call rax
000078f8213da2a4  movaps xmm1, [rsp]
000078f8213da2a8  add rsp, 0x30
000078f8213da2ac  vmovaps xmm0, [rsp]
000078f8213da2b1  vmovaps xmm2, [rsp+0x10]
000078f8213da2b7  vmovaps xmm3, [rsp+0x20]
000078f8213da2bd  vmovaps xmm4, [rsp+0x30]
000078f8213da2c3  vmovaps xmm5, [rsp+0x40]
000078f8213da2c9  vmovaps xmm6, [rsp+0x50]
000078f8213da2cf  vmovaps xmm7, [rsp+0x60]
000078f8213da2d5  vmovaps xmm8, [rsp+0x70]
000078f8213da2db  vmovaps xmm9, [rsp+0x80]
000078f8213da2e4  vmovaps xmm10, [rsp+0x90]
000078f8213da2ed  vmovaps xmm11, [rsp+0xA0]
000078f8213da2f6  vmovaps xmm12, [rsp+0xB0]
000078f8213da2ff  vmovaps xmm13, [rsp+0xC0]
000078f8213da308  vmovaps xmm14, [rsp+0xD0]
000078f8213da311  vmovaps xmm15, [rsp+0xE0]
000078f8213da31a  add rsp, 0xF0
000078f8213da321  pop r11
000078f8213da323  pop r10
000078f8213da325  pop r9
000078f8213da327  pop r8
000078f8213da329  pop rsi
000078f8213da32a  pop rdi
000078f8213da32b  pop rdx
000078f8213da32c  pop rcx
000078f8213da32d  pop rax
000078f8213da32e  add rsp, 0x08
000078f8213da332  jmp 0x000078F8213D641A
000078f8213da337  sub rsp, 0x08
000078f8213da33b  push rax
000078f8213da33c  push rcx
000078f8213da33d  push rdx
000078f8213da33e  push rdi
000078f8213da33f  push rsi
000078f8213da340  push r8
000078f8213da342  push r9
000078f8213da344  push r10
000078f8213da346  push r11
000078f8213da348  sub rsp, 0xF0
000078f8213da34f  vmovaps [rsp], xmm0
000078f8213da354  vmovaps [rsp+0x10], xmm1
000078f8213da35a  vmovaps [rsp+0x20], xmm2
000078f8213da360  vmovaps [rsp+0x30], xmm3
000078f8213da366  vmovaps [rsp+0x40], xmm4
000078f8213da36c  vmovaps [rsp+0x50], xmm5
000078f8213da372  vmovaps [rsp+0x60], xmm6
000078f8213da378  vmovaps [rsp+0x70], xmm7
000078f8213da37e  vmovaps [rsp+0x80], xmm8
000078f8213da387  vmovaps [rsp+0x90], xmm9
000078f8213da390  vmovaps [rsp+0xA0], xmm10
000078f8213da399  vmovaps [rsp+0xB0], xmm11
000078f8213da3a2  vmovaps [rsp+0xC0], xmm13
000078f8213da3ab  vmovaps [rsp+0xD0], xmm14
000078f8213da3b4  vmovaps [rsp+0xE0], xmm15
000078f8213da3bd  sub rsp, 0x30
000078f8213da3c1  movaps [rsp], xmm12
000078f8213da3c6  movaps [rsp+0x10], xmm7
000078f8213da3cb  movaps [rsp+0x20], xmm13
000078f8213da3d1  lea rdi, [rsp]
000078f8213da3d5  mov esi, 0x00
000078f8213da3da  mov rax, 0x653D80F42530
000078f8213da3e4  call rax
000078f8213da3e6  movaps xmm12, [rsp]
000078f8213da3eb  add rsp, 0x30
000078f8213da3ef  vmovaps xmm0, [rsp]
000078f8213da3f4  vmovaps xmm1, [rsp+0x10]
000078f8213da3fa  vmovaps xmm2, [rsp+0x20]
000078f8213da400  vmovaps xmm3, [rsp+0x30]
000078f8213da406  vmovaps xmm4, [rsp+0x40]
000078f8213da40c  vmovaps xmm5, [rsp+0x50]
000078f8213da412  vmovaps xmm6, [rsp+0x60]
000078f8213da418  vmovaps xmm7, [rsp+0x70]
000078f8213da41e  vmovaps xmm8, [rsp+0x80]
000078f8213da427  vmovaps xmm9, [rsp+0x90]
000078f8213da430  vmovaps xmm10, [rsp+0xA0]
000078f8213da439  vmovaps xmm11, [rsp+0xB0]
000078f8213da442  vmovaps xmm13, [rsp+0xC0]
000078f8213da44b  vmovaps xmm14, [rsp+0xD0]
000078f8213da454  vmovaps xmm15, [rsp+0xE0]
000078f8213da45d  add rsp, 0xF0
000078f8213da464  pop r11
000078f8213da466  pop r10
000078f8213da468  pop r9
000078f8213da46a  pop r8
000078f8213da46c  pop rsi
000078f8213da46d  pop rdi
000078f8213da46e  pop rdx
000078f8213da46f  pop rcx
000078f8213da470  pop rax
000078f8213da471  add rsp, 0x08
000078f8213da475  jmp 0x000078F8213D6441
000078f8213da47a  sub rsp, 0x08
000078f8213da47e  push rax
000078f8213da47f  push rcx
000078f8213da480  push rdx
000078f8213da481  push rdi
000078f8213da482  push rsi
000078f8213da483  push r8
000078f8213da485  push r9
000078f8213da487  push r10
000078f8213da489  push r11
000078f8213da48b  sub rsp, 0xF0
000078f8213da492  vmovaps [rsp], xmm0
000078f8213da497  vmovaps [rsp+0x10], xmm1
000078f8213da49d  vmovaps [rsp+0x20], xmm2
000078f8213da4a3  vmovaps [rsp+0x30], xmm3
000078f8213da4a9  vmovaps [rsp+0x40], xmm4
000078f8213da4af  vmovaps [rsp+0x50], xmm5
000078f8213da4b5  vmovaps [rsp+0x60], xmm6
000078f8213da4bb  vmovaps [rsp+0x70], xmm7
000078f8213da4c1  vmovaps [rsp+0x80], xmm8
000078f8213da4ca  vmovaps [rsp+0x90], xmm9
000078f8213da4d3  vmovaps [rsp+0xA0], xmm10
000078f8213da4dc  vmovaps [rsp+0xB0], xmm11
000078f8213da4e5  vmovaps [rsp+0xC0], xmm12
000078f8213da4ee  vmovaps [rsp+0xD0], xmm14
000078f8213da4f7  vmovaps [rsp+0xE0], xmm15
000078f8213da500  sub rsp, 0x30
000078f8213da504  movaps [rsp], xmm13
000078f8213da509  movaps [rsp+0x10], xmm15
000078f8213da50f  movaps [rsp+0x20], xmm8
000078f8213da515  lea rdi, [rsp]
000078f8213da519  mov esi, 0x00
000078f8213da51e  mov rax, 0x653D80F42530
000078f8213da528  call rax
000078f8213da52a  movaps xmm13, [rsp]
000078f8213da52f  add rsp, 0x30
000078f8213da533  vmovaps xmm0, [rsp]
000078f8213da538  vmovaps xmm1, [rsp+0x10]
000078f8213da53e  vmovaps xmm2, [rsp+0x20]
000078f8213da544  vmovaps xmm3, [rsp+0x30]
000078f8213da54a  vmovaps xmm4, [rsp+0x40]
000078f8213da550  vmovaps xmm5, [rsp+0x50]
000078f8213da556  vmovaps xmm6, [rsp+0x60]
000078f8213da55c  vmovaps xmm7, [rsp+0x70]
000078f8213da562  vmovaps xmm8, [rsp+0x80]
000078f8213da56b  vmovaps xmm9, [rsp+0x90]
000078f8213da574  vmovaps xmm10, [rsp+0xA0]
000078f8213da57d  vmovaps xmm11, [rsp+0xB0]
000078f8213da586  vmovaps xmm12, [rsp+0xC0]
000078f8213da58f  vmovaps xmm14, [rsp+0xD0]
000078f8213da598  vmovaps xmm15, [rsp+0xE0]
000078f8213da5a1  add rsp, 0xF0
000078f8213da5a8  pop r11
000078f8213da5aa  pop r10
000078f8213da5ac  pop r9
000078f8213da5ae  pop r8
000078f8213da5b0  pop rsi
000078f8213da5b1  pop rdi
000078f8213da5b2  pop rdx
000078f8213da5b3  pop rcx
000078f8213da5b4  pop rax
000078f8213da5b5  add rsp, 0x08
000078f8213da5b9  jmp 0x000078F8213D645C
000078f8213da5be  sub rsp, 0x08
000078f8213da5c2  push rax
000078f8213da5c3  push rcx
000078f8213da5c4  push rdx
000078f8213da5c5  push rdi
000078f8213da5c6  push rsi
000078f8213da5c7  push r8
000078f8213da5c9  push r9
000078f8213da5cb  push r10
000078f8213da5cd  push r11
000078f8213da5cf  sub rsp, 0xF0
000078f8213da5d6  vmovaps [rsp], xmm0
000078f8213da5db  vmovaps [rsp+0x10], xmm1
000078f8213da5e1  vmovaps [rsp+0x20], xmm2
000078f8213da5e7  vmovaps [rsp+0x30], xmm3
000078f8213da5ed  vmovaps [rsp+0x40], xmm4
000078f8213da5f3  vmovaps [rsp+0x50], xmm5
000078f8213da5f9  vmovaps [rsp+0x60], xmm6
000078f8213da5ff  vmovaps [rsp+0x70], xmm7
000078f8213da605  vmovaps [rsp+0x80], xmm9
000078f8213da60e  vmovaps [rsp+0x90], xmm10
000078f8213da617  vmovaps [rsp+0xA0], xmm11
000078f8213da620  vmovaps [rsp+0xB0], xmm12
000078f8213da629  vmovaps [rsp+0xC0], xmm13
000078f8213da632  vmovaps [rsp+0xD0], xmm14
000078f8213da63b  vmovaps [rsp+0xE0], xmm15
000078f8213da644  sub rsp, 0x30
000078f8213da648  movaps [rsp], xmm8
000078f8213da64d  movaps [rsp+0x10], xmm15
000078f8213da653  movaps [rsp+0x20], xmm9
000078f8213da659  lea rdi, [rsp]
000078f8213da65d  mov esi, 0x00
000078f8213da662  mov rax, 0x653D80F42530
000078f8213da66c  call rax
000078f8213da66e  movaps xmm8, [rsp]
000078f8213da673  add rsp, 0x30
000078f8213da677  vmovaps xmm0, [rsp]
000078f8213da67c  vmovaps xmm1, [rsp+0x10]
000078f8213da682  vmovaps xmm2, [rsp+0x20]
000078f8213da688  vmovaps xmm3, [rsp+0x30]
000078f8213da68e  vmovaps xmm4, [rsp+0x40]
000078f8213da694  vmovaps xmm5, [rsp+0x50]
000078f8213da69a  vmovaps xmm6, [rsp+0x60]
000078f8213da6a0  vmovaps xmm7, [rsp+0x70]
000078f8213da6a6  vmovaps xmm9, [rsp+0x80]
000078f8213da6af  vmovaps xmm10, [rsp+0x90]
000078f8213da6b8  vmovaps xmm11, [rsp+0xA0]
000078f8213da6c1  vmovaps xmm12, [rsp+0xB0]
000078f8213da6ca  vmovaps xmm13, [rsp+0xC0]
000078f8213da6d3  vmovaps xmm14, [rsp+0xD0]
000078f8213da6dc  vmovaps xmm15, [rsp+0xE0]
000078f8213da6e5  add rsp, 0xF0
000078f8213da6ec  pop r11
000078f8213da6ee  pop r10
000078f8213da6f0  pop r9
000078f8213da6f2  pop r8
000078f8213da6f4  pop rsi
000078f8213da6f5  pop rdi
000078f8213da6f6  pop rdx
000078f8213da6f7  pop rcx
000078f8213da6f8  pop rax
000078f8213da6f9  add rsp, 0x08
000078f8213da6fd  jmp 0x000078F8213D648A
000078f8213da702  sub rsp, 0x08
000078f8213da706  push rax
000078f8213da707  push rcx
000078f8213da708  push rdx
000078f8213da709  push rdi
000078f8213da70a  push rsi
000078f8213da70b  push r8
000078f8213da70d  push r9
000078f8213da70f  push r10
000078f8213da711  push r11
000078f8213da713  sub rsp, 0xF0
000078f8213da71a  vmovaps [rsp], xmm0
000078f8213da71f  vmovaps [rsp+0x10], xmm1
000078f8213da725  vmovaps [rsp+0x20], xmm2
000078f8213da72b  vmovaps [rsp+0x30], xmm3
000078f8213da731  vmovaps [rsp+0x40], xmm4
000078f8213da737  vmovaps [rsp+0x50], xmm5
000078f8213da73d  vmovaps [rsp+0x60], xmm6
000078f8213da743  vmovaps [rsp+0x70], xmm7
000078f8213da749  vmovaps [rsp+0x80], xmm8
000078f8213da752  vmovaps [rsp+0x90], xmm9
000078f8213da75b  vmovaps [rsp+0xA0], xmm10
000078f8213da764  vmovaps [rsp+0xB0], xmm11
000078f8213da76d  vmovaps [rsp+0xC0], xmm12
000078f8213da776  vmovaps [rsp+0xD0], xmm13
000078f8213da77f  vmovaps [rsp+0xE0], xmm14
000078f8213da788  sub rsp, 0x30
000078f8213da78c  movaps [rsp], xmm15
000078f8213da791  movaps [rsp+0x10], xmm11
000078f8213da797  movaps [rsp+0x20], xmm6
000078f8213da79c  lea rdi, [rsp]
000078f8213da7a0  mov esi, 0x00
000078f8213da7a5  mov rax, 0x653D80F42530
000078f8213da7af  call rax
000078f8213da7b1  movaps xmm15, [rsp]
000078f8213da7b6  add rsp, 0x30
000078f8213da7ba  vmovaps xmm0, [rsp]
000078f8213da7bf  vmovaps xmm1, [rsp+0x10]
000078f8213da7c5  vmovaps xmm2, [rsp+0x20]
000078f8213da7cb  vmovaps xmm3, [rsp+0x30]
000078f8213da7d1  vmovaps xmm4, [rsp+0x40]
000078f8213da7d7  vmovaps xmm5, [rsp+0x50]
000078f8213da7dd  vmovaps xmm6, [rsp+0x60]
000078f8213da7e3  vmovaps xmm7, [rsp+0x70]
000078f8213da7e9  vmovaps xmm8, [rsp+0x80]
000078f8213da7f2  vmovaps xmm9, [rsp+0x90]
000078f8213da7fb  vmovaps xmm10, [rsp+0xA0]
000078f8213da804  vmovaps xmm11, [rsp+0xB0]
000078f8213da80d  vmovaps xmm12, [rsp+0xC0]
000078f8213da816  vmovaps xmm13, [rsp+0xD0]
000078f8213da81f  vmovaps xmm14, [rsp+0xE0]
000078f8213da828  add rsp, 0xF0
000078f8213da82f  pop r11
000078f8213da831  pop r10
000078f8213da833  pop r9
000078f8213da835  pop r8
000078f8213da837  pop rsi
000078f8213da838  pop rdi
000078f8213da839  pop rdx
000078f8213da83a  pop rcx
000078f8213da83b  pop rax
000078f8213da83c  add rsp, 0x08
000078f8213da840  jmp 0x000078F8213D64A5
000078f8213da845  sub rsp, 0x08
000078f8213da849  push rax
000078f8213da84a  push rcx
000078f8213da84b  push rdx
000078f8213da84c  push rdi
000078f8213da84d  push rsi
000078f8213da84e  push r8
000078f8213da850  push r9
000078f8213da852  push r10
000078f8213da854  push r11
000078f8213da856  sub rsp, 0xF0
000078f8213da85d  vmovaps [rsp], xmm0
000078f8213da862  vmovaps [rsp+0x10], xmm1
000078f8213da868  vmovaps [rsp+0x20], xmm2
000078f8213da86e  vmovaps [rsp+0x30], xmm3
000078f8213da874  vmovaps [rsp+0x40], xmm4
000078f8213da87a  vmovaps [rsp+0x50], xmm5
000078f8213da880  vmovaps [rsp+0x60], xmm6
000078f8213da886  vmovaps [rsp+0x70], xmm8
000078f8213da88c  vmovaps [rsp+0x80], xmm9
000078f8213da895  vmovaps [rsp+0x90], xmm10
000078f8213da89e  vmovaps [rsp+0xA0], xmm11
000078f8213da8a7  vmovaps [rsp+0xB0], xmm12
000078f8213da8b0  vmovaps [rsp+0xC0], xmm13
000078f8213da8b9  vmovaps [rsp+0xD0], xmm14
000078f8213da8c2  vmovaps [rsp+0xE0], xmm15
000078f8213da8cb  sub rsp, 0x30
000078f8213da8cf  movaps [rsp], xmm7
000078f8213da8d3  movaps [rsp+0x10], xmm11
000078f8213da8d9  movaps [rsp+0x20], xmm9
000078f8213da8df  lea rdi, [rsp]
000078f8213da8e3  mov esi, 0x00
000078f8213da8e8  mov rax, 0x653D80F42530
000078f8213da8f2  call rax
000078f8213da8f4  movaps xmm7, [rsp]
000078f8213da8f8  add rsp, 0x30
000078f8213da8fc  vmovaps xmm0, [rsp]
000078f8213da901  vmovaps xmm1, [rsp+0x10]
000078f8213da907  vmovaps xmm2, [rsp+0x20]
000078f8213da90d  vmovaps xmm3, [rsp+0x30]
000078f8213da913  vmovaps xmm4, [rsp+0x40]
000078f8213da919  vmovaps xmm5, [rsp+0x50]
000078f8213da91f  vmovaps xmm6, [rsp+0x60]
000078f8213da925  vmovaps xmm8, [rsp+0x70]
000078f8213da92b  vmovaps xmm9, [rsp+0x80]
000078f8213da934  vmovaps xmm10, [rsp+0x90]
000078f8213da93d  vmovaps xmm11, [rsp+0xA0]
000078f8213da946  vmovaps xmm12, [rsp+0xB0]
000078f8213da94f  vmovaps xmm13, [rsp+0xC0]
000078f8213da958  vmovaps xmm14, [rsp+0xD0]
000078f8213da961  vmovaps xmm15, [rsp+0xE0]
000078f8213da96a  add rsp, 0xF0
000078f8213da971  pop r11
000078f8213da973  pop r10
000078f8213da975  pop r9
000078f8213da977  pop r8
000078f8213da979  pop rsi
000078f8213da97a  pop rdi
000078f8213da97b  pop rdx
000078f8213da97c  pop rcx
000078f8213da97d  pop rax
000078f8213da97e  add rsp, 0x08
000078f8213da982  jmp 0x000078F8213D64D2
000078f8213da987  sub rsp, 0x08
000078f8213da98b  push rax
000078f8213da98c  push rcx
000078f8213da98d  push rdx
000078f8213da98e  push rdi
000078f8213da98f  push rsi
000078f8213da990  push r8
000078f8213da992  push r9
000078f8213da994  push r10
000078f8213da996  push r11
000078f8213da998  sub rsp, 0xF0
000078f8213da99f  vmovaps [rsp], xmm0
000078f8213da9a4  vmovaps [rsp+0x10], xmm1
000078f8213da9aa  vmovaps [rsp+0x20], xmm2
000078f8213da9b0  vmovaps [rsp+0x30], xmm3
000078f8213da9b6  vmovaps [rsp+0x40], xmm4
000078f8213da9bc  vmovaps [rsp+0x50], xmm5
000078f8213da9c2  vmovaps [rsp+0x60], xmm6
000078f8213da9c8  vmovaps [rsp+0x70], xmm7
000078f8213da9ce  vmovaps [rsp+0x80], xmm8
000078f8213da9d7  vmovaps [rsp+0x90], xmm9
000078f8213da9e0  vmovaps [rsp+0xA0], xmm10
000078f8213da9e9  vmovaps [rsp+0xB0], xmm12
000078f8213da9f2  vmovaps [rsp+0xC0], xmm13
000078f8213da9fb  vmovaps [rsp+0xD0], xmm14
000078f8213daa04  vmovaps [rsp+0xE0], xmm15
000078f8213daa0d  sub rsp, 0x30
000078f8213daa11  movaps [rsp], xmm11
000078f8213daa16  movaps [rsp+0x10], xmm10
000078f8213daa1c  movaps [rsp+0x20], xmm14
000078f8213daa22  lea rdi, [rsp]
000078f8213daa26  mov esi, 0x00
000078f8213daa2b  mov rax, 0x653D80F42530
000078f8213daa35  call rax
000078f8213daa37  movaps xmm11, [rsp]
000078f8213daa3c  add rsp, 0x30
000078f8213daa40  vmovaps xmm0, [rsp]
000078f8213daa45  vmovaps xmm1, [rsp+0x10]
000078f8213daa4b  vmovaps xmm2, [rsp+0x20]
000078f8213daa51  vmovaps xmm3, [rsp+0x30]
000078f8213daa57  vmovaps xmm4, [rsp+0x40]
000078f8213daa5d  vmovaps xmm5, [rsp+0x50]
000078f8213daa63  vmovaps xmm6, [rsp+0x60]
000078f8213daa69  vmovaps xmm7, [rsp+0x70]
000078f8213daa6f  vmovaps xmm8, [rsp+0x80]
000078f8213daa78  vmovaps xmm9, [rsp+0x90]
000078f8213daa81  vmovaps xmm10, [rsp+0xA0]
000078f8213daa8a  vmovaps xmm12, [rsp+0xB0]
000078f8213daa93  vmovaps xmm13, [rsp+0xC0]
000078f8213daa9c  vmovaps xmm14, [rsp+0xD0]
000078f8213daaa5  vmovaps xmm15, [rsp+0xE0]
000078f8213daaae  add rsp, 0xF0
000078f8213daab5  pop r11
000078f8213daab7  pop r10
000078f8213daab9  pop r9
000078f8213daabb  pop r8
000078f8213daabd  pop rsi
000078f8213daabe  pop rdi
000078f8213daabf  pop rdx
000078f8213daac0  pop rcx
000078f8213daac1  pop rax
000078f8213daac2  add rsp, 0x08
000078f8213daac6  jmp 0x000078F8213D64ED
000078f8213daacb  call 0x000078F8212E45A0
000078f8213daad0  jmp 0x000078F8213D64F7
000078f8213daad5  sub rsp, 0x08
000078f8213daad9  push rax
000078f8213daada  push rcx
000078f8213daadb  push rdx
000078f8213daadc  push rdi
000078f8213daadd  push rsi
000078f8213daade  push r8
000078f8213daae0  push r9
000078f8213daae2  push r10
000078f8213daae4  push r11
000078f8213daae6  sub rsp, 0xF0
000078f8213daaed  vmovaps [rsp], xmm0
000078f8213daaf2  vmovaps [rsp+0x10], xmm1
000078f8213daaf8  vmovaps [rsp+0x20], xmm2
000078f8213daafe  vmovaps [rsp+0x30], xmm3
000078f8213dab04  vmovaps [rsp+0x40], xmm4
000078f8213dab0a  vmovaps [rsp+0x50], xmm5
000078f8213dab10  vmovaps [rsp+0x60], xmm6
000078f8213dab16  vmovaps [rsp+0x70], xmm7
000078f8213dab1c  vmovaps [rsp+0x80], xmm8
000078f8213dab25  vmovaps [rsp+0x90], xmm9
000078f8213dab2e  vmovaps [rsp+0xA0], xmm11
000078f8213dab37  vmovaps [rsp+0xB0], xmm12
000078f8213dab40  vmovaps [rsp+0xC0], xmm13
000078f8213dab49  vmovaps [rsp+0xD0], xmm14
000078f8213dab52  vmovaps [rsp+0xE0], xmm15
000078f8213dab5b  sub rsp, 0x30
000078f8213dab5f  movaps [rsp], xmm10
000078f8213dab64  movaps [rsp+0x10], xmm1
000078f8213dab69  movaps [rsp+0x20], xmm12
000078f8213dab6f  lea rdi, [rsp]
000078f8213dab73  mov esi, 0x00
000078f8213dab78  mov rax, 0x653D80F42530
000078f8213dab82  call rax
000078f8213dab84  movaps xmm10, [rsp]
000078f8213dab89  add rsp, 0x30
000078f8213dab8d  vmovaps xmm0, [rsp]
000078f8213dab92  vmovaps xmm1, [rsp+0x10]
000078f8213dab98  vmovaps xmm2, [rsp+0x20]
000078f8213dab9e  vmovaps xmm3, [rsp+0x30]
000078f8213daba4  vmovaps xmm4, [rsp+0x40]
000078f8213dabaa  vmovaps xmm5, [rsp+0x50]
000078f8213dabb0  vmovaps xmm6, [rsp+0x60]
000078f8213dabb6  vmovaps xmm7, [rsp+0x70]
000078f8213dabbc  vmovaps xmm8, [rsp+0x80]
000078f8213dabc5  vmovaps xmm9, [rsp+0x90]
000078f8213dabce  vmovaps xmm11, [rsp+0xA0]
000078f8213dabd7  vmovaps xmm12, [rsp+0xB0]
000078f8213dabe0  vmovaps xmm13, [rsp+0xC0]
000078f8213dabe9  vmovaps xmm14, [rsp+0xD0]
000078f8213dabf2  vmovaps xmm15, [rsp+0xE0]
000078f8213dabfb  add rsp, 0xF0
000078f8213dac02  pop r11
000078f8213dac04  pop r10
000078f8213dac06  pop r9
000078f8213dac08  pop r8
000078f8213dac0a  pop rsi
000078f8213dac0b  pop rdi
000078f8213dac0c  pop rdx
000078f8213dac0d  pop rcx
000078f8213dac0e  pop rax
000078f8213dac0f  add rsp, 0x08
000078f8213dac13  jmp 0x000078F8213D651A
000078f8213dac18  sub rsp, 0x08
000078f8213dac1c  push rax
000078f8213dac1d  push rcx
000078f8213dac1e  push rdx
000078f8213dac1f  push rdi
000078f8213dac20  push rsi
000078f8213dac21  push r8
000078f8213dac23  push r9
000078f8213dac25  push r10
000078f8213dac27  push r11
000078f8213dac29  sub rsp, 0xF0
000078f8213dac30  vmovaps [rsp], xmm0
000078f8213dac35  vmovaps [rsp+0x10], xmm1
000078f8213dac3b  vmovaps [rsp+0x20], xmm2
000078f8213dac41  vmovaps [rsp+0x30], xmm3
000078f8213dac47  vmovaps [rsp+0x40], xmm4
000078f8213dac4d  vmovaps [rsp+0x50], xmm5
000078f8213dac53  vmovaps [rsp+0x60], xmm6
000078f8213dac59  vmovaps [rsp+0x70], xmm7
000078f8213dac5f  vmovaps [rsp+0x80], xmm8
000078f8213dac68  vmovaps [rsp+0x90], xmm9
000078f8213dac71  vmovaps [rsp+0xA0], xmm10
000078f8213dac7a  vmovaps [rsp+0xB0], xmm11
000078f8213dac83  vmovaps [rsp+0xC0], xmm13
000078f8213dac8c  vmovaps [rsp+0xD0], xmm14
000078f8213dac95  vmovaps [rsp+0xE0], xmm15
000078f8213dac9e  sub rsp, 0x30
000078f8213daca2  movaps [rsp], xmm12
000078f8213daca7  movaps [rsp+0x10], xmm14
000078f8213dacad  movaps [rsp+0x20], xmm1
000078f8213dacb2  lea rdi, [rsp]
000078f8213dacb6  mov esi, 0x00
000078f8213dacbb  mov rax, 0x653D80F42530
000078f8213dacc5  call rax
000078f8213dacc7  movaps xmm12, [rsp]
000078f8213daccc  add rsp, 0x30
000078f8213dacd0  vmovaps xmm0, [rsp]
000078f8213dacd5  vmovaps xmm1, [rsp+0x10]
000078f8213dacdb  vmovaps xmm2, [rsp+0x20]
000078f8213dace1  vmovaps xmm3, [rsp+0x30]
000078f8213dace7  vmovaps xmm4, [rsp+0x40]
000078f8213daced  vmovaps xmm5, [rsp+0x50]
000078f8213dacf3  vmovaps xmm6, [rsp+0x60]
000078f8213dacf9  vmovaps xmm7, [rsp+0x70]
000078f8213dacff  vmovaps xmm8, [rsp+0x80]
000078f8213dad08  vmovaps xmm9, [rsp+0x90]
000078f8213dad11  vmovaps xmm10, [rsp+0xA0]
000078f8213dad1a  vmovaps xmm11, [rsp+0xB0]
000078f8213dad23  vmovaps xmm13, [rsp+0xC0]
000078f8213dad2c  vmovaps xmm14, [rsp+0xD0]
000078f8213dad35  vmovaps xmm15, [rsp+0xE0]
000078f8213dad3e  add rsp, 0xF0
000078f8213dad45  pop r11
000078f8213dad47  pop r10
000078f8213dad49  pop r9
000078f8213dad4b  pop r8
000078f8213dad4d  pop rsi
000078f8213dad4e  pop rdi
000078f8213dad4f  pop rdx
000078f8213dad50  pop rcx
000078f8213dad51  pop rax
000078f8213dad52  add rsp, 0x08
000078f8213dad56  jmp 0x000078F8213D6549
000078f8213dad5b  sub rsp, 0x08
000078f8213dad5f  push rax
000078f8213dad60  push rcx
000078f8213dad61  push rdx
000078f8213dad62  push rdi
000078f8213dad63  push rsi
000078f8213dad64  push r8
000078f8213dad66  push r9
000078f8213dad68  push r10
000078f8213dad6a  push r11
000078f8213dad6c  sub rsp, 0xF0
000078f8213dad73  vmovaps [rsp], xmm0
000078f8213dad78  vmovaps [rsp+0x10], xmm1
000078f8213dad7e  vmovaps [rsp+0x20], xmm2
000078f8213dad84  vmovaps [rsp+0x30], xmm3
000078f8213dad8a  vmovaps [rsp+0x40], xmm4
000078f8213dad90  vmovaps [rsp+0x50], xmm5
000078f8213dad96  vmovaps [rsp+0x60], xmm6
000078f8213dad9c  vmovaps [rsp+0x70], xmm7
000078f8213dada2  vmovaps [rsp+0x80], xmm8
000078f8213dadab  vmovaps [rsp+0x90], xmm9
000078f8213dadb4  vmovaps [rsp+0xA0], xmm10
000078f8213dadbd  vmovaps [rsp+0xB0], xmm11
000078f8213dadc6  vmovaps [rsp+0xC0], xmm12
000078f8213dadcf  vmovaps [rsp+0xD0], xmm13
000078f8213dadd8  vmovaps [rsp+0xE0], xmm15
000078f8213dade1  sub rsp, 0x30
000078f8213dade5  movaps [rsp], xmm14
000078f8213dadea  movaps [rsp+0x10], xmm9
000078f8213dadf0  movaps [rsp+0x20], xmm1
000078f8213dadf5  lea rdi, [rsp]
000078f8213dadf9  mov esi, 0x00
000078f8213dadfe  mov rax, 0x653D80F42530
000078f8213dae08  call rax
000078f8213dae0a  movaps xmm14, [rsp]
000078f8213dae0f  add rsp, 0x30
000078f8213dae13  vmovaps xmm0, [rsp]
000078f8213dae18  vmovaps xmm1, [rsp+0x10]
000078f8213dae1e  vmovaps xmm2, [rsp+0x20]
000078f8213dae24  vmovaps xmm3, [rsp+0x30]
000078f8213dae2a  vmovaps xmm4, [rsp+0x40]
000078f8213dae30  vmovaps xmm5, [rsp+0x50]
000078f8213dae36  vmovaps xmm6, [rsp+0x60]
000078f8213dae3c  vmovaps xmm7, [rsp+0x70]
000078f8213dae42  vmovaps xmm8, [rsp+0x80]
000078f8213dae4b  vmovaps xmm9, [rsp+0x90]
000078f8213dae54  vmovaps xmm10, [rsp+0xA0]
000078f8213dae5d  vmovaps xmm11, [rsp+0xB0]
000078f8213dae66  vmovaps xmm12, [rsp+0xC0]
000078f8213dae6f  vmovaps xmm13, [rsp+0xD0]
000078f8213dae78  vmovaps xmm15, [rsp+0xE0]
000078f8213dae81  add rsp, 0xF0
000078f8213dae88  pop r11
000078f8213dae8a  pop r10
000078f8213dae8c  pop r9
000078f8213dae8e  pop r8
000078f8213dae90  pop rsi
000078f8213dae91  pop rdi
000078f8213dae92  pop rdx
000078f8213dae93  pop rcx
000078f8213dae94  pop rax
000078f8213dae95  add rsp, 0x08
000078f8213dae99  jmp 0x000078F8213D6578
000078f8213dae9e  sub rsp, 0x08
000078f8213daea2  push rax
000078f8213daea3  push rcx
000078f8213daea4  push rdx
000078f8213daea5  push rdi
000078f8213daea6  push rsi
000078f8213daea7  push r8
000078f8213daea9  push r9
000078f8213daeab  push r10
000078f8213daead  push r11
000078f8213daeaf  sub rsp, 0xF0
000078f8213daeb6  vmovaps [rsp], xmm0
000078f8213daebb  vmovaps [rsp+0x10], xmm2
000078f8213daec1  vmovaps [rsp+0x20], xmm3
000078f8213daec7  vmovaps [rsp+0x30], xmm4
000078f8213daecd  vmovaps [rsp+0x40], xmm5
000078f8213daed3  vmovaps [rsp+0x50], xmm6
000078f8213daed9  vmovaps [rsp+0x60], xmm7
000078f8213daedf  vmovaps [rsp+0x70], xmm8
000078f8213daee5  vmovaps [rsp+0x80], xmm9
000078f8213daeee  vmovaps [rsp+0x90], xmm10
000078f8213daef7  vmovaps [rsp+0xA0], xmm11
000078f8213daf00  vmovaps [rsp+0xB0], xmm12
000078f8213daf09  vmovaps [rsp+0xC0], xmm13
000078f8213daf12  vmovaps [rsp+0xD0], xmm14
000078f8213daf1b  vmovaps [rsp+0xE0], xmm15
000078f8213daf24  sub rsp, 0x30
000078f8213daf28  movaps [rsp], xmm1
000078f8213daf2c  movaps [rsp+0x10], xmm13
000078f8213daf32  movaps [rsp+0x20], xmm8
000078f8213daf38  lea rdi, [rsp]
000078f8213daf3c  mov esi, 0x00
000078f8213daf41  mov rax, 0x653D80F42530
000078f8213daf4b  call rax
000078f8213daf4d  movaps xmm1, [rsp]
000078f8213daf51  add rsp, 0x30
000078f8213daf55  vmovaps xmm0, [rsp]
000078f8213daf5a  vmovaps xmm2, [rsp+0x10]
000078f8213daf60  vmovaps xmm3, [rsp+0x20]
000078f8213daf66  vmovaps xmm4, [rsp+0x30]
000078f8213daf6c  vmovaps xmm5, [rsp+0x40]
000078f8213daf72  vmovaps xmm6, [rsp+0x50]
000078f8213daf78  vmovaps xmm7, [rsp+0x60]
000078f8213daf7e  vmovaps xmm8, [rsp+0x70]
000078f8213daf84  vmovaps xmm9, [rsp+0x80]
000078f8213daf8d  vmovaps xmm10, [rsp+0x90]
000078f8213daf96  vmovaps xmm11, [rsp+0xA0]
000078f8213daf9f  vmovaps xmm12, [rsp+0xB0]
000078f8213dafa8  vmovaps xmm13, [rsp+0xC0]
000078f8213dafb1  vmovaps xmm14, [rsp+0xD0]
000078f8213dafba  vmovaps xmm15, [rsp+0xE0]
000078f8213dafc3  add rsp, 0xF0
000078f8213dafca  pop r11
000078f8213dafcc  pop r10
000078f8213dafce  pop r9
000078f8213dafd0  pop r8
000078f8213dafd2  pop rsi
000078f8213dafd3  pop rdi
000078f8213dafd4  pop rdx
000078f8213dafd5  pop rcx
000078f8213dafd6  pop rax
000078f8213dafd7  add rsp, 0x08
000078f8213dafdb  jmp 0x000078F8213D659A
000078f8213dafe0  call 0x000078F82120C260
000078f8213dafe5  jmp 0x000078F8213D65A8
000078f8213dafea  call 0x000078F8212DE950
000078f8213dafef  jmp 0x000078F8213D65B2
000078f8213daff4  sub rsp, 0x08
000078f8213daff8  push rax
000078f8213daff9  push rcx
000078f8213daffa  push rdx
000078f8213daffb  push rdi
000078f8213daffc  push rsi
000078f8213daffd  push r8
000078f8213dafff  push r9
000078f8213db001  push r10
000078f8213db003  push r11
000078f8213db005  sub rsp, 0xF0
000078f8213db00c  vmovaps [rsp], xmm0
000078f8213db011  vmovaps [rsp+0x10], xmm1
000078f8213db017  vmovaps [rsp+0x20], xmm2
000078f8213db01d  vmovaps [rsp+0x30], xmm3
000078f8213db023  vmovaps [rsp+0x40], xmm4
000078f8213db029  vmovaps [rsp+0x50], xmm5
000078f8213db02f  vmovaps [rsp+0x60], xmm6
000078f8213db035  vmovaps [rsp+0x70], xmm7
000078f8213db03b  vmovaps [rsp+0x80], xmm9
000078f8213db044  vmovaps [rsp+0x90], xmm10
000078f8213db04d  vmovaps [rsp+0xA0], xmm11
000078f8213db056  vmovaps [rsp+0xB0], xmm12
000078f8213db05f  vmovaps [rsp+0xC0], xmm13
000078f8213db068  vmovaps [rsp+0xD0], xmm14
000078f8213db071  vmovaps [rsp+0xE0], xmm15
000078f8213db07a  sub rsp, 0x30
000078f8213db07e  movaps [rsp], xmm8
000078f8213db083  movaps [rsp+0x10], xmm15
000078f8213db089  movaps [rsp+0x20], xmm7
000078f8213db08e  lea rdi, [rsp]
000078f8213db092  mov esi, 0x00
000078f8213db097  mov rax, 0x653D80F42530
000078f8213db0a1  call rax
000078f8213db0a3  movaps xmm8, [rsp]
000078f8213db0a8  add rsp, 0x30
000078f8213db0ac  vmovaps xmm0, [rsp]
000078f8213db0b1  vmovaps xmm1, [rsp+0x10]
000078f8213db0b7  vmovaps xmm2, [rsp+0x20]
000078f8213db0bd  vmovaps xmm3, [rsp+0x30]
000078f8213db0c3  vmovaps xmm4, [rsp+0x40]
000078f8213db0c9  vmovaps xmm5, [rsp+0x50]
000078f8213db0cf  vmovaps xmm6, [rsp+0x60]
000078f8213db0d5  vmovaps xmm7, [rsp+0x70]
000078f8213db0db  vmovaps xmm9, [rsp+0x80]
000078f8213db0e4  vmovaps xmm10, [rsp+0x90]
000078f8213db0ed  vmovaps xmm11, [rsp+0xA0]
000078f8213db0f6  vmovaps xmm12, [rsp+0xB0]
000078f8213db0ff  vmovaps xmm13, [rsp+0xC0]
000078f8213db108  vmovaps xmm14, [rsp+0xD0]
000078f8213db111  vmovaps xmm15, [rsp+0xE0]
000078f8213db11a  add rsp, 0xF0
000078f8213db121  pop r11
000078f8213db123  pop r10
000078f8213db125  pop r9
000078f8213db127  pop r8
000078f8213db129  pop rsi
000078f8213db12a  pop rdi
000078f8213db12b  pop rdx
000078f8213db12c  pop rcx
000078f8213db12d  pop rax
000078f8213db12e  add rsp, 0x08
000078f8213db132  jmp 0x000078F8213D65D4
000078f8213db137  sub rsp, 0x08
000078f8213db13b  push rax
000078f8213db13c  push rcx
000078f8213db13d  push rdx
000078f8213db13e  push rdi
000078f8213db13f  push rsi
000078f8213db140  push r8
000078f8213db142  push r9
000078f8213db144  push r10
000078f8213db146  push r11
000078f8213db148  sub rsp, 0xF0
000078f8213db14f  vmovaps [rsp], xmm0
000078f8213db154  vmovaps [rsp+0x10], xmm1
000078f8213db15a  vmovaps [rsp+0x20], xmm2
000078f8213db160  vmovaps [rsp+0x30], xmm3
000078f8213db166  vmovaps [rsp+0x40], xmm4
000078f8213db16c  vmovaps [rsp+0x50], xmm5
000078f8213db172  vmovaps [rsp+0x60], xmm6
000078f8213db178  vmovaps [rsp+0x70], xmm8
000078f8213db17e  vmovaps [rsp+0x80], xmm9
000078f8213db187  vmovaps [rsp+0x90], xmm10
000078f8213db190  vmovaps [rsp+0xA0], xmm11
000078f8213db199  vmovaps [rsp+0xB0], xmm12
000078f8213db1a2  vmovaps [rsp+0xC0], xmm13
000078f8213db1ab  vmovaps [rsp+0xD0], xmm14
000078f8213db1b4  vmovaps [rsp+0xE0], xmm15
000078f8213db1bd  sub rsp, 0x30
000078f8213db1c1  movaps [rsp], xmm7
000078f8213db1c5  movaps [rsp+0x10], xmm9
000078f8213db1cb  movaps [rsp+0x20], xmm15
000078f8213db1d1  lea rdi, [rsp]
000078f8213db1d5  mov esi, 0x00
000078f8213db1da  mov rax, 0x653D80F42530
000078f8213db1e4  call rax
000078f8213db1e6  movaps xmm7, [rsp]
000078f8213db1ea  add rsp, 0x30
000078f8213db1ee  vmovaps xmm0, [rsp]
000078f8213db1f3  vmovaps xmm1, [rsp+0x10]
000078f8213db1f9  vmovaps xmm2, [rsp+0x20]
000078f8213db1ff  vmovaps xmm3, [rsp+0x30]
000078f8213db205  vmovaps xmm4, [rsp+0x40]
000078f8213db20b  vmovaps xmm5, [rsp+0x50]
000078f8213db211  vmovaps xmm6, [rsp+0x60]
000078f8213db217  vmovaps xmm8, [rsp+0x70]
000078f8213db21d  vmovaps xmm9, [rsp+0x80]
000078f8213db226  vmovaps xmm10, [rsp+0x90]
000078f8213db22f  vmovaps xmm11, [rsp+0xA0]
000078f8213db238  vmovaps xmm12, [rsp+0xB0]
000078f8213db241  vmovaps xmm13, [rsp+0xC0]
000078f8213db24a  vmovaps xmm14, [rsp+0xD0]
000078f8213db253  vmovaps xmm15, [rsp+0xE0]
000078f8213db25c  add rsp, 0xF0
000078f8213db263  pop r11
000078f8213db265  pop r10
000078f8213db267  pop r9
000078f8213db269  pop r8
000078f8213db26b  pop rsi
000078f8213db26c  pop rdi
000078f8213db26d  pop rdx
000078f8213db26e  pop rcx
000078f8213db26f  pop rax
000078f8213db270  add rsp, 0x08
000078f8213db274  jmp 0x000078F8213D6601
000078f8213db279  sub rsp, 0x08
000078f8213db27d  push rax
000078f8213db27e  push rcx
000078f8213db27f  push rdx
000078f8213db280  push rdi
000078f8213db281  push rsi
000078f8213db282  push r8
000078f8213db284  push r9
000078f8213db286  push r10
000078f8213db288  push r11
000078f8213db28a  sub rsp, 0xF0
000078f8213db291  vmovaps [rsp], xmm0
000078f8213db296  vmovaps [rsp+0x10], xmm1
000078f8213db29c  vmovaps [rsp+0x20], xmm2
000078f8213db2a2  vmovaps [rsp+0x30], xmm3
000078f8213db2a8  vmovaps [rsp+0x40], xmm4
000078f8213db2ae  vmovaps [rsp+0x50], xmm5
000078f8213db2b4  vmovaps [rsp+0x60], xmm6
000078f8213db2ba  vmovaps [rsp+0x70], xmm7
000078f8213db2c0  vmovaps [rsp+0x80], xmm8
000078f8213db2c9  vmovaps [rsp+0x90], xmm10
000078f8213db2d2  vmovaps [rsp+0xA0], xmm11
000078f8213db2db  vmovaps [rsp+0xB0], xmm12
000078f8213db2e4  vmovaps [rsp+0xC0], xmm13
000078f8213db2ed  vmovaps [rsp+0xD0], xmm14
000078f8213db2f6  vmovaps [rsp+0xE0], xmm15
000078f8213db2ff  sub rsp, 0x30
000078f8213db303  movaps [rsp], xmm9
000078f8213db308  movaps [rsp+0x10], xmm13
000078f8213db30e  movaps [rsp+0x20], xmm15
000078f8213db314  lea rdi, [rsp]
000078f8213db318  mov esi, 0x00
000078f8213db31d  mov rax, 0x653D80F42530
000078f8213db327  call rax
000078f8213db329  movaps xmm9, [rsp]
000078f8213db32e  add rsp, 0x30
000078f8213db332  vmovaps xmm0, [rsp]
000078f8213db337  vmovaps xmm1, [rsp+0x10]
000078f8213db33d  vmovaps xmm2, [rsp+0x20]
000078f8213db343  vmovaps xmm3, [rsp+0x30]
000078f8213db349  vmovaps xmm4, [rsp+0x40]
000078f8213db34f  vmovaps xmm5, [rsp+0x50]
000078f8213db355  vmovaps xmm6, [rsp+0x60]
000078f8213db35b  vmovaps xmm7, [rsp+0x70]
000078f8213db361  vmovaps xmm8, [rsp+0x80]
000078f8213db36a  vmovaps xmm10, [rsp+0x90]
000078f8213db373  vmovaps xmm11, [rsp+0xA0]
000078f8213db37c  vmovaps xmm12, [rsp+0xB0]
000078f8213db385  vmovaps xmm13, [rsp+0xC0]
000078f8213db38e  vmovaps xmm14, [rsp+0xD0]
000078f8213db397  vmovaps xmm15, [rsp+0xE0]
000078f8213db3a0  add rsp, 0xF0
000078f8213db3a7  pop r11
000078f8213db3a9  pop r10
000078f8213db3ab  pop r9
000078f8213db3ad  pop r8
000078f8213db3af  pop rsi
000078f8213db3b0  pop rdi
000078f8213db3b1  pop rdx
000078f8213db3b2  pop rcx
000078f8213db3b3  pop rax
000078f8213db3b4  add rsp, 0x08
000078f8213db3b8  jmp 0x000078F8213D662F
000078f8213db3bd  sub rsp, 0x08
000078f8213db3c1  push rax
000078f8213db3c2  push rcx
000078f8213db3c3  push rdx
000078f8213db3c4  push rdi
000078f8213db3c5  push rsi
000078f8213db3c6  push r8
000078f8213db3c8  push r9
000078f8213db3ca  push r10
000078f8213db3cc  push r11
000078f8213db3ce  sub rsp, 0xF0
000078f8213db3d5  vmovaps [rsp], xmm0
000078f8213db3da  vmovaps [rsp+0x10], xmm1
000078f8213db3e0  vmovaps [rsp+0x20], xmm2
000078f8213db3e6  vmovaps [rsp+0x30], xmm3
000078f8213db3ec  vmovaps [rsp+0x40], xmm4
000078f8213db3f2  vmovaps [rsp+0x50], xmm5
000078f8213db3f8  vmovaps [rsp+0x60], xmm6
000078f8213db3fe  vmovaps [rsp+0x70], xmm7
000078f8213db404  vmovaps [rsp+0x80], xmm8
000078f8213db40d  vmovaps [rsp+0x90], xmm9
000078f8213db416  vmovaps [rsp+0xA0], xmm10
000078f8213db41f  vmovaps [rsp+0xB0], xmm11
000078f8213db428  vmovaps [rsp+0xC0], xmm12
000078f8213db431  vmovaps [rsp+0xD0], xmm13
000078f8213db43a  vmovaps [rsp+0xE0], xmm14
000078f8213db443  sub rsp, 0x30
000078f8213db447  movaps [rsp], xmm15
000078f8213db44c  movaps [rsp+0x10], xmm11
000078f8213db452  movaps [rsp+0x20], xmm12
000078f8213db458  lea rdi, [rsp]
000078f8213db45c  mov esi, 0x00
000078f8213db461  mov rax, 0x653D80F42530
000078f8213db46b  call rax
000078f8213db46d  movaps xmm15, [rsp]
000078f8213db472  add rsp, 0x30
000078f8213db476  vmovaps xmm0, [rsp]
000078f8213db47b  vmovaps xmm1, [rsp+0x10]
000078f8213db481  vmovaps xmm2, [rsp+0x20]
000078f8213db487  vmovaps xmm3, [rsp+0x30]
000078f8213db48d  vmovaps xmm4, [rsp+0x40]
000078f8213db493  vmovaps xmm5, [rsp+0x50]
000078f8213db499  vmovaps xmm6, [rsp+0x60]
000078f8213db49f  vmovaps xmm7, [rsp+0x70]
000078f8213db4a5  vmovaps xmm8, [rsp+0x80]
000078f8213db4ae  vmovaps xmm9, [rsp+0x90]
000078f8213db4b7  vmovaps xmm10, [rsp+0xA0]
000078f8213db4c0  vmovaps xmm11, [rsp+0xB0]
000078f8213db4c9  vmovaps xmm12, [rsp+0xC0]
000078f8213db4d2  vmovaps xmm13, [rsp+0xD0]
000078f8213db4db  vmovaps xmm14, [rsp+0xE0]
000078f8213db4e4  add rsp, 0xF0
000078f8213db4eb  pop r11
000078f8213db4ed  pop r10
000078f8213db4ef  pop r9
000078f8213db4f1  pop r8
000078f8213db4f3  pop rsi
000078f8213db4f4  pop rdi
000078f8213db4f5  pop rdx
000078f8213db4f6  pop rcx
000078f8213db4f7  pop rax
000078f8213db4f8  add rsp, 0x08
000078f8213db4fc  jmp 0x000078F8213D664A
000078f8213db501  sub rsp, 0x08
000078f8213db505  push rax
000078f8213db506  push rcx
000078f8213db507  push rdx
000078f8213db508  push rdi
000078f8213db509  push rsi
000078f8213db50a  push r8
000078f8213db50c  push r9
000078f8213db50e  push r10
000078f8213db510  push r11
000078f8213db512  sub rsp, 0xF0
000078f8213db519  vmovaps [rsp], xmm0
000078f8213db51e  vmovaps [rsp+0x10], xmm1
000078f8213db524  vmovaps [rsp+0x20], xmm2
000078f8213db52a  vmovaps [rsp+0x30], xmm3
000078f8213db530  vmovaps [rsp+0x40], xmm4
000078f8213db536  vmovaps [rsp+0x50], xmm5
000078f8213db53c  vmovaps [rsp+0x60], xmm6
000078f8213db542  vmovaps [rsp+0x70], xmm7
000078f8213db548  vmovaps [rsp+0x80], xmm8
000078f8213db551  vmovaps [rsp+0x90], xmm9
000078f8213db55a  vmovaps [rsp+0xA0], xmm10
000078f8213db563  vmovaps [rsp+0xB0], xmm11
000078f8213db56c  vmovaps [rsp+0xC0], xmm12
000078f8213db575  vmovaps [rsp+0xD0], xmm14
000078f8213db57e  vmovaps [rsp+0xE0], xmm15
000078f8213db587  sub rsp, 0x30
000078f8213db58b  movaps [rsp], xmm13
000078f8213db590  movaps [rsp+0x10], xmm10
000078f8213db596  movaps [rsp+0x20], xmm14
000078f8213db59c  lea rdi, [rsp]
000078f8213db5a0  mov esi, 0x00
000078f8213db5a5  mov rax, 0x653D80F42530
000078f8213db5af  call rax
000078f8213db5b1  movaps xmm13, [rsp]
000078f8213db5b6  add rsp, 0x30
000078f8213db5ba  vmovaps xmm0, [rsp]
000078f8213db5bf  vmovaps xmm1, [rsp+0x10]
000078f8213db5c5  vmovaps xmm2, [rsp+0x20]
000078f8213db5cb  vmovaps xmm3, [rsp+0x30]
000078f8213db5d1  vmovaps xmm4, [rsp+0x40]
000078f8213db5d7  vmovaps xmm5, [rsp+0x50]
000078f8213db5dd  vmovaps xmm6, [rsp+0x60]
000078f8213db5e3  vmovaps xmm7, [rsp+0x70]
000078f8213db5e9  vmovaps xmm8, [rsp+0x80]
000078f8213db5f2  vmovaps xmm9, [rsp+0x90]
000078f8213db5fb  vmovaps xmm10, [rsp+0xA0]
000078f8213db604  vmovaps xmm11, [rsp+0xB0]
000078f8213db60d  vmovaps xmm12, [rsp+0xC0]
000078f8213db616  vmovaps xmm14, [rsp+0xD0]
000078f8213db61f  vmovaps xmm15, [rsp+0xE0]
000078f8213db628  add rsp, 0xF0
000078f8213db62f  pop r11
000078f8213db631  pop r10
000078f8213db633  pop r9
000078f8213db635  pop r8
000078f8213db637  pop rsi
000078f8213db638  pop rdi
000078f8213db639  pop rdx
000078f8213db63a  pop rcx
000078f8213db63b  pop rax
000078f8213db63c  add rsp, 0x08
000078f8213db640  jmp 0x000078F8213D666D
000078f8213db645  sub rsp, 0x08
000078f8213db649  push rax
000078f8213db64a  push rcx
000078f8213db64b  push rdx
000078f8213db64c  push rdi
000078f8213db64d  push rsi
000078f8213db64e  push r8
000078f8213db650  push r9
000078f8213db652  push r10
000078f8213db654  push r11
000078f8213db656  sub rsp, 0xF0
000078f8213db65d  vmovaps [rsp], xmm0
000078f8213db662  vmovaps [rsp+0x10], xmm1
000078f8213db668  vmovaps [rsp+0x20], xmm2
000078f8213db66e  vmovaps [rsp+0x30], xmm3
000078f8213db674  vmovaps [rsp+0x40], xmm4
000078f8213db67a  vmovaps [rsp+0x50], xmm5
000078f8213db680  vmovaps [rsp+0x60], xmm6
000078f8213db686  vmovaps [rsp+0x70], xmm7
000078f8213db68c  vmovaps [rsp+0x80], xmm8
000078f8213db695  vmovaps [rsp+0x90], xmm9
000078f8213db69e  vmovaps [rsp+0xA0], xmm10
000078f8213db6a7  vmovaps [rsp+0xB0], xmm11
000078f8213db6b0  vmovaps [rsp+0xC0], xmm12
000078f8213db6b9  vmovaps [rsp+0xD0], xmm13
000078f8213db6c2  vmovaps [rsp+0xE0], xmm15
000078f8213db6cb  sub rsp, 0x30
000078f8213db6cf  movaps [rsp], xmm14
000078f8213db6d4  movaps [rsp+0x10], xmm1
000078f8213db6d9  movaps [rsp+0x20], xmm7
000078f8213db6de  lea rdi, [rsp]
000078f8213db6e2  mov esi, 0x00
000078f8213db6e7  mov rax, 0x653D80F42530
000078f8213db6f1  call rax
000078f8213db6f3  movaps xmm14, [rsp]
000078f8213db6f8  add rsp, 0x30
000078f8213db6fc  vmovaps xmm0, [rsp]
000078f8213db701  vmovaps xmm1, [rsp+0x10]
000078f8213db707  vmovaps xmm2, [rsp+0x20]
000078f8213db70d  vmovaps xmm3, [rsp+0x30]
000078f8213db713  vmovaps xmm4, [rsp+0x40]
000078f8213db719  vmovaps xmm5, [rsp+0x50]
000078f8213db71f  vmovaps xmm6, [rsp+0x60]
000078f8213db725  vmovaps xmm7, [rsp+0x70]
000078f8213db72b  vmovaps xmm8, [rsp+0x80]
000078f8213db734  vmovaps xmm9, [rsp+0x90]
000078f8213db73d  vmovaps xmm10, [rsp+0xA0]
000078f8213db746  vmovaps xmm11, [rsp+0xB0]
000078f8213db74f  vmovaps xmm12, [rsp+0xC0]
000078f8213db758  vmovaps xmm13, [rsp+0xD0]
000078f8213db761  vmovaps xmm15, [rsp+0xE0]
000078f8213db76a  add rsp, 0xF0
000078f8213db771  pop r11
000078f8213db773  pop r10
000078f8213db775  pop r9
000078f8213db777  pop r8
000078f8213db779  pop rsi
000078f8213db77a  pop rdi
000078f8213db77b  pop rdx
000078f8213db77c  pop rcx
000078f8213db77d  pop rax
000078f8213db77e  add rsp, 0x08
000078f8213db782  jmp 0x000078F8213D6690
000078f8213db787  sub rsp, 0x08
000078f8213db78b  push rax
000078f8213db78c  push rcx
000078f8213db78d  push rdx
000078f8213db78e  push rdi
000078f8213db78f  push rsi
000078f8213db790  push r8
000078f8213db792  push r9
000078f8213db794  push r10
000078f8213db796  push r11
000078f8213db798  sub rsp, 0xF0
000078f8213db79f  vmovaps [rsp], xmm0
000078f8213db7a4  vmovaps [rsp+0x10], xmm2
000078f8213db7aa  vmovaps [rsp+0x20], xmm3
000078f8213db7b0  vmovaps [rsp+0x30], xmm4
000078f8213db7b6  vmovaps [rsp+0x40], xmm5
000078f8213db7bc  vmovaps [rsp+0x50], xmm6
000078f8213db7c2  vmovaps [rsp+0x60], xmm7
000078f8213db7c8  vmovaps [rsp+0x70], xmm8
000078f8213db7ce  vmovaps [rsp+0x80], xmm9
000078f8213db7d7  vmovaps [rsp+0x90], xmm10
000078f8213db7e0  vmovaps [rsp+0xA0], xmm11
000078f8213db7e9  vmovaps [rsp+0xB0], xmm12
000078f8213db7f2  vmovaps [rsp+0xC0], xmm13
000078f8213db7fb  vmovaps [rsp+0xD0], xmm14
000078f8213db804  vmovaps [rsp+0xE0], xmm15
000078f8213db80d  sub rsp, 0x30
000078f8213db811  movaps [rsp], xmm1
000078f8213db815  movaps [rsp+0x10], xmm8
000078f8213db81b  movaps [rsp+0x20], xmm9
000078f8213db821  lea rdi, [rsp]
000078f8213db825  mov esi, 0x00
000078f8213db82a  mov rax, 0x653D80F42530
000078f8213db834  call rax
000078f8213db836  movaps xmm1, [rsp]
000078f8213db83a  add rsp, 0x30
000078f8213db83e  vmovaps xmm0, [rsp]
000078f8213db843  vmovaps xmm2, [rsp+0x10]
000078f8213db849  vmovaps xmm3, [rsp+0x20]
000078f8213db84f  vmovaps xmm4, [rsp+0x30]
000078f8213db855  vmovaps xmm5, [rsp+0x40]
000078f8213db85b  vmovaps xmm6, [rsp+0x50]
000078f8213db861  vmovaps xmm7, [rsp+0x60]
000078f8213db867  vmovaps xmm8, [rsp+0x70]
000078f8213db86d  vmovaps xmm9, [rsp+0x80]
000078f8213db876  vmovaps xmm10, [rsp+0x90]
000078f8213db87f  vmovaps xmm11, [rsp+0xA0]
000078f8213db888  vmovaps xmm12, [rsp+0xB0]
000078f8213db891  vmovaps xmm13, [rsp+0xC0]
000078f8213db89a  vmovaps xmm14, [rsp+0xD0]
000078f8213db8a3  vmovaps xmm15, [rsp+0xE0]
000078f8213db8ac  add rsp, 0xF0
000078f8213db8b3  pop r11
000078f8213db8b5  pop r10
000078f8213db8b7  pop r9
000078f8213db8b9  pop r8
000078f8213db8bb  pop rsi
000078f8213db8bc  pop rdi
000078f8213db8bd  pop rdx
000078f8213db8be  pop rcx
000078f8213db8bf  pop rax
000078f8213db8c0  add rsp, 0x08
000078f8213db8c4  jmp 0x000078F8213D66B2
000078f8213db8c9  call 0x000078F8212B3E40
000078f8213db8ce  jmp 0x000078F8213D66C0
000078f8213db8d3  call 0x000078F82120C380
000078f8213db8d8  jmp 0x000078F8213D66CA
000078f8213db8dd  call 0x000078F82120D600
000078f8213db8e2  jmp 0x000078F8213D66D4
000078f8213db8e7  call 0x000078F8211FF540
000078f8213db8ec  jmp 0x000078F8213D66DE
000078f8213db8f1  int3
000078f8213db8f2  nop [rax+rax*1], ax
000078f8213db8fb  nop [rax+rax*1], eax
000078f8213db900  mov eax, [r15+0x48]
000078f8213db904  lea r14d, [eax+0x01]
000078f8213db909  mov [rsp+0x10], r14d
000078f8213db90e  mov r14d, r14d
000078f8213db911  mov [r15+0x48], r14
000078f8213db915  xor eax, eax
000078f8213db917  mov r14d, [rsp+0x10]
000078f8213db91c  cmp r14d, 0x1F4
000078f8213db923  cmc
000078f8213db924  lahf
000078f8213db925  seto al
000078f8213db928  mov [r15+0x108], eax
000078f8213db92f  mov eax, [r15+0x108]
000078f8213db936  sahf
000078f8213db937  jnz 0x000078F8213DB969
000078f8213db939  cmp dword ptr [r15+0x318], 0x00
000078f8213db941  jz 0x000078F8213E1AB0
000078f8213db947  nop [rax+rax*1], ax
000078f8213db950  nop [rax+rax*1], eax
000078f8213db958  mov eax, 0x410450
000078f8213db95d  mov [r15+0x100], rax
000078f8213db964  jmp 0x000078F8211FE110
000078f8213db969  cmp dword ptr [r15+0x318], 0x00
000078f8213db971  jz 0x000078F8213DB9A0
000078f8213db977  nop [rax+rax*1], ax
000078f8213db980  nop [rax+rax*1], eax
000078f8213db988  mov eax, 0x410274
000078f8213db98d  mov [r15+0x100], rax
000078f8213db994  jmp 0x000078F8211FE110
000078f8213db999  int3
000078f8213db99a  int3
000078f8213db99b  nop [rax+rax*1], eax
000078f8213db9a0  mov rax, [r15+0x40]
000078f8213db9a4  movaps xmm1, [r15+0x1D0]
000078f8213db9ac  vmovaps [rsp+0x10], xmm1
000078f8213db9b2  vmovaps xmm15, [rsp+0x10]
000078f8213db9b8  por xmm1, xmm15
000078f8213db9bd  movaps xmm14, [r15+0x1A0]
000078f8213db9c5  vmovaps [rsp+0x10], xmm14
000078f8213db9cb  vmovaps xmm13, [rsp+0x10]
000078f8213db9d1  por xmm14, xmm13
000078f8213db9d6  lea r14, [rax+0x30]
000078f8213db9da  mov r12, [r13+r14*1]
000078f8213db9df  lea r14, [rax+0x38]
000078f8213db9e3  mov r11, [r13+r14*1]
000078f8213db9e8  movq xmm13, r12
000078f8213db9ed  movq xmm12, r11
000078f8213db9f2  movq xmm13, xmm13
000078f8213db9f7  vmovaps [rsp+0x10], xmm13
000078f8213db9fd  movq xmm13, xmm13
000078f8213dba02  movaps [r15+0x130], xmm13
000078f8213dba0a  movq xmm12, xmm12
000078f8213dba0f  vmovaps [rsp+0x20], xmm12
000078f8213dba15  movq xmm12, xmm12
000078f8213dba1a  movaps [r15+0x280], xmm12
000078f8213dba22  movaps xmm13, [r15+0x270]
000078f8213dba2a  vmovaps [rsp+0x30], xmm13
000078f8213dba30  vmovaps xmm12, [rsp+0x30]
000078f8213dba36  por xmm13, xmm12
000078f8213dba3b  lea r14, [rax+0x20]
000078f8213dba3f  mov r12, [r13+r14*1]
000078f8213dba44  lea r14, [rax+0x28]
000078f8213dba48  mov r11, [r13+r14*1]
000078f8213dba4d  movq xmm12, r12
000078f8213dba52  movq xmm11, r11
000078f8213dba57  movq xmm12, xmm12
000078f8213dba5c  vmovaps [rsp+0x30], xmm12
000078f8213dba62  movq xmm12, xmm12
000078f8213dba67  movaps [r15+0x150], xmm12
000078f8213dba6f  movq xmm11, xmm11
000078f8213dba74  vmovaps [rsp+0x40], xmm11
000078f8213dba7a  movq xmm11, xmm11
000078f8213dba7f  movaps [r15+0x140], xmm11
000078f8213dba87  lea r14, [rax+0x10]
000078f8213dba8b  mov r12, [r13+r14*1]
000078f8213dba90  lea r14, [rax+0x18]
000078f8213dba94  mov r11, [r13+r14*1]
000078f8213dba99  movq xmm12, r12
000078f8213dba9e  movq xmm11, r11
000078f8213dbaa3  movq xmm12, xmm12
000078f8213dbaa8  vmovaps [rsp+0x50], xmm12
000078f8213dbaae  movq xmm12, xmm12
000078f8213dbab3  movaps [r15+0x170], xmm12
000078f8213dbabb  movq xmm11, xmm11
000078f8213dbac0  vmovaps [rsp+0x60], xmm11
000078f8213dbac6  movq xmm11, xmm11
000078f8213dbacb  movaps [r15+0x160], xmm11
000078f8213dbad3  mov r14, [r13+rax*1]
000078f8213dbad8  vmovq xmm12, r14
000078f8213dbadd  vpbroadcastq xmm12, xmm12
000078f8213dbae2  lea r14, [rax+0x08]
000078f8213dbae6  mov rax, [r13+r14*1]
000078f8213dbaeb  movq xmm11, rax
000078f8213dbaf0  movaps [r15+0x230], xmm11
000078f8213dbaf8  mov rax, [r15+0xF8]
000078f8213dbaff  lea r14, [rax+0x50]
000078f8213dbb03  movups xmm11, [r13+r14*1]
000078f8213dbb09  lea r14, [rax+0x60]
000078f8213dbb0d  movups xmm10, [r13+r14*1]
000078f8213dbb13  lea r14, [rax+0x30]
000078f8213dbb17  movups xmm9, [r13+r14*1]
000078f8213dbb1d  mov r14, [r15+0x50]
000078f8213dbb21  mov [r15+0x60], r14
000078f8213dbb25  mov qword ptr [r15+0x58], 0x40
000078f8213dbb2d  movaps xmm8, xmm12
000078f8213dbb31  mulpd xmm8, xmm15
000078f8213dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000078f8213dbb3c  ptest xmm7, xmm7
000078f8213dbb41  jnz 0x000078F8213DC96A
000078f8213dbb47  movq xmm15, qword ptr [r15+0x230]
000078f8213dbb50  vmovaps [rsp+0x70], xmm15
000078f8213dbb56  vpermilpd xmm15, xmm15, 0x00
000078f8213dbb5c  movaps xmm7, xmm9
000078f8213dbb60  mulpd xmm7, xmm15
000078f8213dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000078f8213dbb6a  ptest xmm6, xmm6
000078f8213dbb6f  jnz 0x000078F8213DCAAE
000078f8213dbb75  vxorps xmm15, xmm15, xmm15
000078f8213dbb7a  vpbroadcastq xmm15, xmm15
000078f8213dbb7f  movaps xmm9, xmm12
000078f8213dbb83  mulpd xmm9, xmm10
000078f8213dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000078f8213dbb8e  ptest xmm6, xmm6
000078f8213dbb93  jnz 0x000078F8213DCBF0
000078f8213dbb99  movaps xmm10, xmm12
000078f8213dbb9d  mulpd xmm10, xmm11
000078f8213dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000078f8213dbba8  ptest xmm6, xmm6
000078f8213dbbad  jnz 0x000078F8213DCD34
000078f8213dbbb3  movaps xmm11, [r15+0x1F0]
000078f8213dbbbb  movaps xmm6, xmm12
000078f8213dbbbf  mulpd xmm6, xmm11
000078f8213dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000078f8213dbbc9  ptest xmm5, xmm5
000078f8213dbbce  jnz 0x000078F8213DCE78
000078f8213dbbd4  movaps xmm12, [r15+0x2A0]
000078f8213dbbdc  vmovaps [rsp+0x80], xmm12
000078f8213dbbe5  vmovaps xmm11, [rsp+0x80]
000078f8213dbbee  por xmm12, xmm11
000078f8213dbbf3  movaps xmm11, [r15+0x250]
000078f8213dbbfb  vmovaps [rsp+0x80], xmm11
000078f8213dbc04  vmovaps xmm5, [rsp+0x80]
000078f8213dbc0d  por xmm11, xmm5
000078f8213dbc12  vmovaps xmm4, [rsp+0x70]
000078f8213dbc18  vpermilpd xmm4, xmm4, 0x00
000078f8213dbc1e  movaps xmm3, xmm5
000078f8213dbc21  mulpd xmm3, xmm4
000078f8213dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000078f8213dbc2a  ptest xmm2, xmm2
000078f8213dbc2f  jnz 0x000078F8213DCFBA
000078f8213dbc35  mov [rsp+0x80], rax
000078f8213dbc3d  xor eax, eax
000078f8213dbc3f  mov r12d, 0x40
000078f8213dbc45  mov r11d, 0x200
000078f8213dbc4b  cmp r12, r11
000078f8213dbc4e  cmc
000078f8213dbc4f  lahf
000078f8213dbc50  seto al
000078f8213dbc53  mov [r15+0x108], eax
000078f8213dbc5a  movaps xmm5, xmm8
000078f8213dbc5e  addpd xmm5, xmm15
000078f8213dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000078f8213dbc68  ptest xmm4, xmm4
000078f8213dbc6d  jnz 0x000078F8213DD0FA
000078f8213dbc73  movaps xmm8, [r15+0x1B0]
000078f8213dbc7b  movaps xmm4, xmm9
000078f8213dbc7f  addpd xmm4, xmm8
000078f8213dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000078f8213dbc89  ptest xmm2, xmm2
000078f8213dbc8e  jnz 0x000078F8213DD23C
000078f8213dbc94  movaps xmm9, xmm10
000078f8213dbc98  addpd xmm9, xmm8
000078f8213dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000078f8213dbca3  ptest xmm2, xmm2
000078f8213dbca8  jnz 0x000078F8213DD37E
000078f8213dbcae  movaps xmm10, [r15+0x2F0]
000078f8213dbcb6  vmovaps [rsp+0x90], xmm10
000078f8213dbcbf  vmovaps xmm8, [rsp+0x90]
000078f8213dbcc8  por xmm10, xmm8
000078f8213dbccd  movaps xmm8, [r15+0x2E0]
000078f8213dbcd5  vmovaps [rsp+0x90], xmm8
000078f8213dbcde  vmovaps xmm2, [rsp+0x90]
000078f8213dbce7  por xmm8, xmm2
000078f8213dbcec  movaps xmm2, [r15+0x2D0]
000078f8213dbcf4  vmovaps [rsp+0x90], xmm2
000078f8213dbcfd  vmovaps [rsp+0xA0], xmm1
000078f8213dbd06  vmovaps xmm1, [rsp+0x90]
000078f8213dbd0f  por xmm2, xmm1
000078f8213dbd13  movaps xmm1, [r15+0x200]
000078f8213dbd1b  vmovaps [rsp+0x90], xmm1
000078f8213dbd24  vmovaps [rsp+0xB0], xmm15
000078f8213dbd2d  vmovaps xmm15, [rsp+0x90]
000078f8213dbd36  por xmm1, xmm15
000078f8213dbd3b  movaps xmm15, [r15+0x1C0]
000078f8213dbd43  vmovaps [rsp+0x90], xmm15
000078f8213dbd4c  vmovaps [rsp+0xC0], xmm1
000078f8213dbd55  vmovaps xmm1, [rsp+0x90]
000078f8213dbd5e  por xmm15, xmm1
000078f8213dbd63  movaps xmm1, [r15+0x190]
000078f8213dbd6b  vmovaps [rsp+0x90], xmm1
000078f8213dbd74  vmovaps [rsp+0xD0], xmm15
000078f8213dbd7d  vmovaps xmm15, [rsp+0x90]
000078f8213dbd86  por xmm1, xmm15
000078f8213dbd8b  movaps xmm15, [r15+0x300]
000078f8213dbd93  vmovaps [rsp+0x90], xmm15
000078f8213dbd9c  vmovaps [rsp+0xE0], xmm1
000078f8213dbda5  vmovaps xmm1, [rsp+0x90]
000078f8213dbdae  por xmm15, xmm1
000078f8213dbdb3  mov rax, [rsp+0x80]
000078f8213dbdbb  lea r12, [rax+0xA0]
000078f8213dbdc2  movups xmm1, [r13+r12*1]
000078f8213dbdc8  lea r12, [rax+0xB0]
000078f8213dbdcf  vmovaps [rsp+0x80], xmm1
000078f8213dbdd8  movups xmm1, [r13+r12*1]
000078f8213dbdde  vmovaps [rsp+0x90], xmm1
000078f8213dbde7  vmovaps [rsp+0xF0], xmm15
000078f8213dbdf0  vmovaps xmm15, [rsp+0xB0]
000078f8213dbdf9  vmovaps [rsp+0xB0], xmm14
000078f8213dbe02  movaps xmm1, xmm6
000078f8213dbe05  addpd xmm1, xmm15
000078f8213dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000078f8213dbe0f  ptest xmm14, xmm14
000078f8213dbe15  jnz 0x000078F8213DD4D6
000078f8213dbe1b  lea r12, [rax+0xF0]
000078f8213dbe22  movups xmm15, [r13+r12*1]
000078f8213dbe28  movaps xmm14, xmm4
000078f8213dbe2c  addpd xmm14, xmm3
000078f8213dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000078f8213dbe37  ptest xmm6, xmm6
000078f8213dbe3c  jnz 0x000078F8213DD621
000078f8213dbe42  movaps xmm6, xmm9
000078f8213dbe46  addpd xmm6, xmm7
000078f8213dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000078f8213dbe4f  ptest xmm4, xmm4
000078f8213dbe54  jnz 0x000078F8213DD763
000078f8213dbe5a  vmovaps xmm9, [rsp+0x70]
000078f8213dbe60  vpermilpd xmm9, xmm9, 0x00
000078f8213dbe66  vmovaps xmm4, [rsp+0x90]
000078f8213dbe6f  movaps xmm7, xmm4
000078f8213dbe72  mulpd xmm7, xmm9
000078f8213dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000078f8213dbe7c  ptest xmm3, xmm3
000078f8213dbe81  jnz 0x000078F8213DD8A4
000078f8213dbe87  vmovaps xmm9, [rsp+0x50]
000078f8213dbe8d  vpermilpd xmm9, xmm9, 0x00
000078f8213dbe93  movaps xmm4, xmm15
000078f8213dbe97  mulpd xmm4, xmm9
000078f8213dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000078f8213dbea1  ptest xmm3, xmm3
000078f8213dbea6  jnz 0x000078F8213DD9E5
000078f8213dbeac  lea r12, [rax+0xE0]
000078f8213dbeb3  movups xmm15, [r13+r12*1]
000078f8213dbeb9  vmovaps xmm9, [rsp+0x70]
000078f8213dbebf  vpermilpd xmm9, xmm9, 0x00
000078f8213dbec5  vmovaps [rsp+0x70], xmm1
000078f8213dbecb  vmovaps xmm1, [rsp+0x80]
000078f8213dbed4  vmovaps [rsp+0x80], xmm15
000078f8213dbedd  movaps xmm3, xmm1
000078f8213dbee0  mulpd xmm3, xmm9
000078f8213dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000078f8213dbeea  ptest xmm15, xmm15
000078f8213dbef0  jnz 0x000078F8213DDB31
000078f8213dbef6  vmovaps xmm1, [rsp+0xF0]
000078f8213dbeff  vmovaps xmm15, [rsp+0xF0]
000078f8213dbf08  por xmm1, xmm15
000078f8213dbf0d  movaps [r15+0x300], xmm1
000078f8213dbf15  vmovaps xmm15, [rsp+0xE0]
000078f8213dbf1e  vmovaps xmm9, [rsp+0xE0]
000078f8213dbf27  por xmm15, xmm9
000078f8213dbf2c  movaps [r15+0x190], xmm15
000078f8213dbf34  vmovaps xmm9, [rsp+0x50]
000078f8213dbf3a  vpermilpd xmm9, xmm9, 0x00
000078f8213dbf40  vmovaps [rsp+0x90], xmm1
000078f8213dbf49  vmovaps [rsp+0xE0], xmm15
000078f8213dbf52  vmovaps xmm15, [rsp+0x80]
000078f8213dbf5b  vmovaps [rsp+0x80], xmm14
000078f8213dbf64  movaps xmm1, xmm15
000078f8213dbf68  mulpd xmm1, xmm9
000078f8213dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000078f8213dbf72  ptest xmm14, xmm14
000078f8213dbf78  jnz 0x000078F8213DDC72
000078f8213dbf7e  lea r12, [rax+0x90]
000078f8213dbf85  movups xmm15, [r13+r12*1]
000078f8213dbf8b  vmovaps xmm14, [rsp+0xD0]
000078f8213dbf94  vmovaps xmm9, [rsp+0xD0]
000078f8213dbf9d  por xmm14, xmm9
000078f8213dbfa2  movaps [r15+0x1C0], xmm14
000078f8213dbfaa  vmovaps xmm9, [rsp+0xC0]
000078f8213dbfb3  vmovaps [rsp+0xD0], xmm1
000078f8213dbfbc  vmovaps xmm1, [rsp+0xC0]
000078f8213dbfc5  por xmm9, xmm1
000078f8213dbfca  movaps [r15+0x200], xmm9
000078f8213dbfd2  vmovaps [rsp+0xC0], xmm2
000078f8213dbfdb  vmovaps xmm1, [rsp+0xC0]
000078f8213dbfe4  por xmm2, xmm1
000078f8213dbfe8  movaps [r15+0x2D0], xmm2
000078f8213dbff0  vmovaps [rsp+0xC0], xmm8
000078f8213dbff9  vmovaps xmm1, [rsp+0xC0]
000078f8213dc002  por xmm8, xmm1
000078f8213dc007  movaps [r15+0x2E0], xmm8
000078f8213dc00f  vmovaps [rsp+0xC0], xmm15
000078f8213dc018  movaps xmm1, xmm5
000078f8213dc01b  addpd xmm1, xmm7
000078f8213dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000078f8213dc024  ptest xmm15, xmm15
000078f8213dc02a  jnz 0x000078F8213DDDBE
000078f8213dc030  vmovaps xmm15, [rsp+0x50]
000078f8213dc036  vpermilpd xmm15, xmm15, 0x00
000078f8213dc03c  vmovaps xmm5, [rsp+0xC0]
000078f8213dc045  vmovaps [rsp+0xC0], xmm1
000078f8213dc04e  movaps xmm7, xmm5
000078f8213dc051  mulpd xmm7, xmm15
000078f8213dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000078f8213dc05b  ptest xmm1, xmm1
000078f8213dc060  jnz 0x000078F8213DDEFE
000078f8213dc066  lea r12, [rax+0x80]
000078f8213dc06d  movups xmm1, [r13+r12*1]
000078f8213dc073  vmovaps xmm5, [rsp+0x70]
000078f8213dc079  vmovaps [rsp+0x70], xmm1
000078f8213dc07f  movaps xmm15, xmm5
000078f8213dc083  addpd xmm15, xmm3
000078f8213dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000078f8213dc08e  ptest xmm1, xmm1
000078f8213dc093  jnz 0x000078F8213DE049
000078f8213dc099  vmovaps xmm5, [rsp+0x80]
000078f8213dc0a2  movaps xmm1, xmm5
000078f8213dc0a5  addpd xmm1, xmm4
000078f8213dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000078f8213dc0ae  ptest xmm3, xmm3
000078f8213dc0b3  jnz 0x000078F8213DE18B
000078f8213dc0b9  vmovaps [rsp+0x80], xmm10
000078f8213dc0c2  vmovaps xmm5, [rsp+0x80]
000078f8213dc0cb  por xmm10, xmm5
000078f8213dc0d0  movaps [r15+0x2F0], xmm10
000078f8213dc0d8  vmovaps xmm5, [rsp+0x50]
000078f8213dc0de  vpermilpd xmm5, xmm5, 0x00
000078f8213dc0e4  vmovaps xmm3, [rsp+0x70]
000078f8213dc0ea  vmovaps [rsp+0x50], xmm1
000078f8213dc0f0  movaps xmm4, xmm3
000078f8213dc0f3  mulpd xmm4, xmm5
000078f8213dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000078f8213dc0fc  ptest xmm1, xmm1
000078f8213dc101  jnz 0x000078F8213DE2CB
000078f8213dc107  lea r12, [rax+0xD0]
000078f8213dc10e  movups xmm1, [r13+r12*1]
000078f8213dc114  vmovaps xmm3, [rsp+0xD0]
000078f8213dc11d  vmovaps [rsp+0x70], xmm1
000078f8213dc123  movaps xmm5, xmm6
000078f8213dc126  addpd xmm5, xmm3
000078f8213dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000078f8213dc12f  ptest xmm1, xmm1
000078f8213dc134  jnz 0x000078F8213DE415
000078f8213dc13a  vmovaps xmm1, [rsp+0x60]
000078f8213dc140  vpermilpd xmm1, xmm1, 0x00
000078f8213dc146  movaps xmm6, xmm9
000078f8213dc14a  mulpd xmm6, xmm1
000078f8213dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000078f8213dc153  ptest xmm3, xmm3
000078f8213dc158  jnz 0x000078F8213DE555
000078f8213dc15e  movaps [r15+0x260], xmm6
000078f8213dc166  vxorps xmm1, xmm1, xmm1
000078f8213dc16a  vpbroadcastq xmm1, xmm1
000078f8213dc16f  movaps [r15+0x1B0], xmm1
000078f8213dc177  vmovaps xmm1, [rsp+0x60]
000078f8213dc17d  vpermilpd xmm1, xmm1, 0x00
000078f8213dc183  vmovaps xmm3, [rsp+0x70]
000078f8213dc189  vmovaps [rsp+0x70], xmm15
000078f8213dc18f  movaps xmm9, xmm3
000078f8213dc193  mulpd xmm9, xmm1
000078f8213dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000078f8213dc19e  ptest xmm15, xmm15
000078f8213dc1a4  jnz 0x000078F8213DE696
000078f8213dc1aa  lea r12, [rax+0xC0]
000078f8213dc1b1  movups xmm1, [r13+r12*1]
000078f8213dc1b7  vmovaps xmm3, [rsp+0xC0]
000078f8213dc1c0  vmovaps [rsp+0x80], xmm1
000078f8213dc1c9  movaps xmm15, xmm3
000078f8213dc1cd  addpd xmm15, xmm7
000078f8213dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000078f8213dc1d8  ptest xmm1, xmm1
000078f8213dc1dd  jnz 0x000078F8213DE7E2
000078f8213dc1e3  vmovaps [rsp+0xC0], xmm13
000078f8213dc1ec  vmovaps xmm1, [rsp+0xC0]
000078f8213dc1f5  por xmm13, xmm1
000078f8213dc1fa  movaps [r15+0x270], xmm13
000078f8213dc202  vmovaps xmm1, [rsp+0xB0]
000078f8213dc20b  vmovaps xmm7, [rsp+0xB0]
000078f8213dc214  por xmm1, xmm7
000078f8213dc218  movaps [r15+0x1A0], xmm1
000078f8213dc220  vmovaps xmm1, [rsp+0x60]
000078f8213dc226  vpermilpd xmm1, xmm1, 0x00
000078f8213dc22c  vmovaps [rsp+0xB0], xmm1
000078f8213dc235  vmovaps xmm1, [rsp+0x80]
000078f8213dc23e  vmovaps [rsp+0x80], xmm15
000078f8213dc247  vmovaps xmm15, [rsp+0xB0]
000078f8213dc250  vmovaps [rsp+0xB0], xmm14
000078f8213dc259  movaps xmm3, xmm1
000078f8213dc25c  mulpd xmm3, xmm15
000078f8213dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000078f8213dc266  ptest xmm14, xmm14
000078f8213dc26c  jnz 0x000078F8213DE924
000078f8213dc272  lea r12, [rax+0x20]
000078f8213dc276  movups xmm1, [r13+r12*1]
000078f8213dc27c  movaps [r15+0x110], xmm1
000078f8213dc284  vmovaps xmm14, [rsp+0x70]
000078f8213dc28a  vmovaps [rsp+0x70], xmm1
000078f8213dc290  movaps xmm15, xmm14
000078f8213dc294  addpd xmm15, xmm4
000078f8213dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000078f8213dc29f  ptest xmm1, xmm1
000078f8213dc2a4  jnz 0x000078F8213DEA6F
000078f8213dc2aa  vmovaps xmm1, [rsp+0x60]
000078f8213dc2b0  vpermilpd xmm1, xmm1, 0x00
000078f8213dc2b6  movaps xmm14, xmm2
000078f8213dc2ba  mulpd xmm14, xmm1
000078f8213dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000078f8213dc2c5  ptest xmm4, xmm4
000078f8213dc2ca  jnz 0x000078F8213DEBB2
000078f8213dc2d0  vmovaps xmm4, [rsp+0x50]
000078f8213dc2d6  movaps xmm1, xmm4
000078f8213dc2d9  addpd xmm1, xmm9
000078f8213dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000078f8213dc2e3  ptest xmm2, xmm2
000078f8213dc2e8  jnz 0x000078F8213DECF4
000078f8213dc2ee  vmovaps xmm9, [rsp+0x30]
000078f8213dc2f4  vpermilpd xmm9, xmm9, 0x00
000078f8213dc2fa  vmovaps xmm2, [rsp+0x70]
000078f8213dc300  vmovaps [rsp+0x50], xmm1
000078f8213dc306  movaps xmm4, xmm2
000078f8213dc309  mulpd xmm4, xmm9
000078f8213dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000078f8213dc313  ptest xmm1, xmm1
000078f8213dc318  jnz 0x000078F8213DEE35
000078f8213dc31e  vmovaps xmm1, [rsp+0x30]
000078f8213dc324  vpermilpd xmm1, xmm1, 0x00
000078f8213dc32a  vmovaps xmm2, [rsp+0x90]
000078f8213dc333  vmovaps [rsp+0x60], xmm15
000078f8213dc339  movaps xmm9, xmm2
000078f8213dc33d  mulpd xmm9, xmm1
000078f8213dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000078f8213dc348  ptest xmm15, xmm15
000078f8213dc34e  jnz 0x000078F8213DEF76
000078f8213dc354  vmovaps xmm15, [rsp+0x80]
000078f8213dc35d  movaps xmm1, xmm15
000078f8213dc361  addpd xmm1, xmm6
000078f8213dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000078f8213dc36a  ptest xmm2, xmm2
000078f8213dc36f  jnz 0x000078F8213DF0B8
000078f8213dc375  movaps xmm15, xmm5
000078f8213dc379  addpd xmm15, xmm3
000078f8213dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000078f8213dc384  ptest xmm6, xmm6
000078f8213dc389  jnz 0x000078F8213DF1F9
000078f8213dc38f  vmovaps xmm6, [rsp+0x30]
000078f8213dc395  vpermilpd xmm6, xmm6, 0x00
000078f8213dc39b  movaps xmm5, xmm8
000078f8213dc39f  mulpd xmm5, xmm6
000078f8213dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000078f8213dc3a8  ptest xmm3, xmm3
000078f8213dc3ad  jnz 0x000078F8213DF33B
000078f8213dc3b3  vmovaps xmm8, [rsp+0x30]
000078f8213dc3b9  vpermilpd xmm8, xmm8, 0x00
000078f8213dc3bf  movaps xmm6, xmm10
000078f8213dc3c3  mulpd xmm6, xmm8
000078f8213dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000078f8213dc3cd  ptest xmm3, xmm3
000078f8213dc3d2  jnz 0x000078F8213DF47C
000078f8213dc3d8  vmovaps xmm8, [rsp+0x60]
000078f8213dc3de  movaps xmm10, xmm8
000078f8213dc3e2  addpd xmm10, xmm14
000078f8213dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000078f8213dc3ed  ptest xmm3, xmm3
000078f8213dc3f2  jnz 0x000078F8213DF5BE
000078f8213dc3f8  vmovaps xmm8, [rsp+0x50]
000078f8213dc3fe  movaps xmm14, xmm8
000078f8213dc402  addpd xmm14, xmm4
000078f8213dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000078f8213dc40d  ptest xmm3, xmm3
000078f8213dc412  jnz 0x000078F8213DF702
000078f8213dc418  vmovaps xmm8, [rsp+0x40]
000078f8213dc41e  vpermilpd xmm8, xmm8, 0x00
000078f8213dc424  movaps xmm4, xmm13
000078f8213dc428  mulpd xmm4, xmm8
000078f8213dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000078f8213dc432  ptest xmm3, xmm3
000078f8213dc437  jnz 0x000078F8213DF845
000078f8213dc43d  movaps xmm13, xmm15
000078f8213dc441  addpd xmm13, xmm9
000078f8213dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000078f8213dc44c  ptest xmm8, xmm8
000078f8213dc452  jnz 0x000078F8213DF987
000078f8213dc458  movaps xmm15, xmm1
000078f8213dc45c  addpd xmm15, xmm5
000078f8213dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000078f8213dc467  ptest xmm9, xmm9
000078f8213dc46d  jnz 0x000078F8213DFACB
000078f8213dc473  vmovaps [rsp+0x30], xmm11
000078f8213dc479  vmovaps xmm1, [rsp+0x30]
000078f8213dc47f  por xmm11, xmm1
000078f8213dc484  movaps [r15+0x250], xmm11
000078f8213dc48c  vmovaps [rsp+0x30], xmm12
000078f8213dc492  vmovaps xmm1, [rsp+0x30]
000078f8213dc498  por xmm12, xmm1
000078f8213dc49d  movaps [r15+0x2A0], xmm12
000078f8213dc4a5  vmovaps xmm1, [rsp+0xA0]
000078f8213dc4ae  vmovaps xmm11, [rsp+0xA0]
000078f8213dc4b7  por xmm1, xmm11
000078f8213dc4bc  movaps [r15+0x1D0], xmm1
000078f8213dc4c4  lea r12, [rax+0x40]
000078f8213dc4c8  movups xmm1, [r13+r12*1]
000078f8213dc4ce  movaps [r15+0x2C0], xmm1
000078f8213dc4d6  vmovaps xmm11, [rsp+0x40]
000078f8213dc4dc  vpermilpd xmm11, xmm11, 0x00
000078f8213dc4e2  vmovaps xmm8, [rsp+0xE0]
000078f8213dc4eb  movaps xmm9, xmm8
000078f8213dc4ef  mulpd xmm9, xmm11
000078f8213dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000078f8213dc4fa  ptest xmm5, xmm5
000078f8213dc4ff  jnz 0x000078F8213DFC17
000078f8213dc505  movaps xmm11, xmm10
000078f8213dc509  addpd xmm11, xmm6
000078f8213dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000078f8213dc514  ptest xmm8, xmm8
000078f8213dc51a  jnz 0x000078F8213DFD5B
000078f8213dc520  movaps xmm10, xmm14
000078f8213dc524  addpd xmm10, xmm4
000078f8213dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000078f8213dc52f  ptest xmm8, xmm8
000078f8213dc535  jnz 0x000078F8213DFE9E
000078f8213dc53b  vmovaps xmm14, [rsp+0x40]
000078f8213dc541  vpermilpd xmm14, xmm14, 0x00
000078f8213dc547  movaps xmm8, xmm1
000078f8213dc54b  mulpd xmm8, xmm14
000078f8213dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000078f8213dc556  ptest xmm6, xmm6
000078f8213dc55b  jnz 0x000078F8213DFFE1
000078f8213dc561  movaps xmm1, [r15+0x2B0]
000078f8213dc569  vmovaps xmm14, [rsp+0x40]
000078f8213dc56f  vpermilpd xmm14, xmm14, 0x00
000078f8213dc575  movaps xmm6, xmm1
000078f8213dc578  mulpd xmm6, xmm14
000078f8213dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000078f8213dc582  ptest xmm5, xmm5
000078f8213dc587  jnz 0x000078F8213E0124
000078f8213dc58d  vmovaps xmm1, [rsp+0x10]
000078f8213dc593  vpermilpd xmm1, xmm1, 0x00
000078f8213dc599  movaps xmm14, xmm12
000078f8213dc59d  mulpd xmm14, xmm1
000078f8213dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000078f8213dc5a8  ptest xmm5, xmm5
000078f8213dc5ad  jnz 0x000078F8213E0265
000078f8213dc5b3  movaps xmm1, xmm13
000078f8213dc5b7  addpd xmm1, xmm9
000078f8213dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000078f8213dc5c1  ptest xmm12, xmm12
000078f8213dc5c7  jnz 0x000078F8213E03A8
000078f8213dc5cd  vmovaps xmm13, [rsp+0x10]
000078f8213dc5d3  vpermilpd xmm13, xmm13, 0x00
000078f8213dc5d9  movaps xmm12, xmm7
000078f8213dc5dd  mulpd xmm12, xmm13
000078f8213dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000078f8213dc5e8  ptest xmm9, xmm9
000078f8213dc5ee  jnz 0x000078F8213E04EA
000078f8213dc5f4  movaps xmm13, xmm15
000078f8213dc5f8  addpd xmm13, xmm8
000078f8213dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000078f8213dc603  ptest xmm9, xmm9
000078f8213dc609  jnz 0x000078F8213E062D
000078f8213dc60f  movaps xmm15, [r15+0x290]
000078f8213dc617  vmovaps xmm9, [rsp+0x10]
000078f8213dc61d  vpermilpd xmm9, xmm9, 0x00
000078f8213dc623  movaps xmm8, xmm15
000078f8213dc627  mulpd xmm8, xmm9
000078f8213dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000078f8213dc632  ptest xmm7, xmm7
000078f8213dc637  jnz 0x000078F8213E0771
000078f8213dc63d  movaps xmm15, xmm11
000078f8213dc641  addpd xmm15, xmm6
000078f8213dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000078f8213dc64c  ptest xmm9, xmm9
000078f8213dc652  jnz 0x000078F8213E08B5
000078f8213dc658  movaps xmm11, [r15+0x1E0]
000078f8213dc660  vmovaps xmm9, [rsp+0x10]
000078f8213dc666  vpermilpd xmm9, xmm9, 0x00
000078f8213dc66c  movaps xmm7, xmm11
000078f8213dc670  mulpd xmm7, xmm9
000078f8213dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000078f8213dc67a  ptest xmm6, xmm6
000078f8213dc67f  jnz 0x000078F8213E09F8
000078f8213dc685  movaps xmm11, xmm10
000078f8213dc689  addpd xmm11, xmm14
000078f8213dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000078f8213dc694  ptest xmm9, xmm9
000078f8213dc69a  jnz 0x000078F8213E0B3A
000078f8213dc6a0  lea r12, [rax+0x70]
000078f8213dc6a4  movups xmm14, [r13+r12*1]
000078f8213dc6aa  movaps [r15+0x240], xmm14
000078f8213dc6b2  movaps xmm10, xmm1
000078f8213dc6b6  addpd xmm10, xmm12
000078f8213dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000078f8213dc6c1  ptest xmm9, xmm9
000078f8213dc6c7  jnz 0x000078F8213E0C88
000078f8213dc6cd  movaps [r15+0x170], xmm10
000078f8213dc6d5  vmovaps xmm1, [rsp+0x20]
000078f8213dc6db  vpermilpd xmm1, xmm1, 0x00
000078f8213dc6e1  movaps xmm12, xmm14
000078f8213dc6e5  mulpd xmm12, xmm1
000078f8213dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000078f8213dc6f0  ptest xmm9, xmm9
000078f8213dc6f6  jnz 0x000078F8213E0DCB
000078f8213dc6fc  vmovaps xmm1, [rsp+0x20]
000078f8213dc702  vpermilpd xmm1, xmm1, 0x00
000078f8213dc708  vmovaps xmm9, [rsp+0xB0]
000078f8213dc711  movaps xmm14, xmm9
000078f8213dc715  mulpd xmm14, xmm1
000078f8213dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000078f8213dc720  ptest xmm6, xmm6
000078f8213dc725  jnz 0x000078F8213E0F0E
000078f8213dc72b  movaps [r15+0x180], xmm14
000078f8213dc733  movaps xmm1, xmm13
000078f8213dc737  addpd xmm1, xmm8
000078f8213dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000078f8213dc741  ptest xmm9, xmm9
000078f8213dc747  jnz 0x000078F8213E1051
000078f8213dc74d  movaps [r15+0x210], xmm1
000078f8213dc755  movups xmm13, [r13+rax*1]
000078f8213dc75b  lea r12, [rax+0x10]
000078f8213dc75f  movups xmm9, [r13+r12*1]
000078f8213dc765  movaps [r15+0x230], xmm9
000078f8213dc76d  movaps xmm8, xmm15
000078f8213dc771  addpd xmm8, xmm7
000078f8213dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000078f8213dc77c  ptest xmm6, xmm6
000078f8213dc781  jnz 0x000078F8213E11A7
000078f8213dc787  movaps [r15+0x130], xmm8
000078f8213dc78f  vmovaps xmm15, [rsp+0x20]
000078f8213dc795  vpermilpd xmm15, xmm15, 0x00
000078f8213dc79b  movaps xmm7, xmm9
000078f8213dc79f  mulpd xmm7, xmm15
000078f8213dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000078f8213dc7a9  ptest xmm6, xmm6
000078f8213dc7ae  jnz 0x000078F8213E12EA
000078f8213dc7b4  movaps [r15+0x220], xmm7
000078f8213dc7bc  vmovaps xmm15, [rsp+0x20]
000078f8213dc7c2  vpermilpd xmm15, xmm15, 0x00
000078f8213dc7c8  movaps xmm9, xmm13
000078f8213dc7cc  mulpd xmm9, xmm15
000078f8213dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000078f8213dc7d7  ptest xmm6, xmm6
000078f8213dc7dc  jnz 0x000078F8213E142C
000078f8213dc7e2  movaps xmm15, xmm11
000078f8213dc7e6  addpd xmm15, xmm12
000078f8213dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000078f8213dc7f1  ptest xmm13, xmm13
000078f8213dc7f7  jnz 0x000078F8213E1570
000078f8213dc7fd  movaps [r15+0x140], xmm15
000078f8213dc805  movaps xmm13, xmm10
000078f8213dc809  addpd xmm13, xmm14
000078f8213dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000078f8213dc814  ptest xmm12, xmm12
000078f8213dc81a  jnz 0x000078F8213E16B4
000078f8213dc820  movaps [r15+0x150], xmm13
000078f8213dc828  movaps xmm14, xmm1
000078f8213dc82c  addpd xmm14, xmm7
000078f8213dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000078f8213dc837  ptest xmm12, xmm12
000078f8213dc83d  jnz 0x000078F8213E17F8
000078f8213dc843  movaps [r15+0x160], xmm14
000078f8213dc84b  movaps xmm1, xmm8
000078f8213dc84f  addpd xmm1, xmm9
000078f8213dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000078f8213dc859  ptest xmm12, xmm12
000078f8213dc85f  jnz 0x000078F8213E193A
000078f8213dc865  movaps [r15+0x120], xmm1
000078f8213dc86d  movups [r13+r14*1], xmm15
000078f8213dc873  lea rax, [r14+0x10]
000078f8213dc877  movups [r13+rax*1], xmm13
000078f8213dc87d  lea rax, [r14+0x20]
000078f8213dc881  movups [r13+rax*1], xmm14
000078f8213dc887  lea rax, [r14+0x30]
000078f8213dc88b  movups [r13+rax*1], xmm1
000078f8213dc891  mov eax, [r15+0x108]
000078f8213dc898  sahf
000078f8213dc899  jnz 0x000078F8213DC8CB
000078f8213dc89b  cmp dword ptr [r15+0x318], 0x00
000078f8213dc8a3  jz 0x000078F8213DB900
000078f8213dc8a9  nop [rax+rax*1], ax
000078f8213dc8b2  nop [rax+rax*1], eax
000078f8213dc8ba  mov eax, 0x410444
000078f8213dc8bf  mov [r15+0x100], rax
000078f8213dc8c6  jmp 0x000078F8211FE110
000078f8213dc8cb  cmp dword ptr [r15+0x318], 0x00
000078f8213dc8d3  jz 0x000078F8213D57E0
000078f8213dc8d9  nop [rax+rax*1], ax
000078f8213dc8e2  nop [rax+rax*1], eax
000078f8213dc8ea  mov eax, 0x410278
000078f8213dc8ef  mov [r15+0x100], rax
000078f8213dc8f6  jmp 0x000078F8211FE110
000078f8213dc8fb  int3
000078f8213dc8fc  call 0x000078F8212E27E0
000078f8213dc901  jmp 0x000078F8213DB9DF
000078f8213dc906  call 0x000078F8212E1570
000078f8213dc90b  jmp 0x000078F8213DB9E8
000078f8213dc910  call 0x000078F8212E27E0
000078f8213dc915  jmp 0x000078F8213DBA44
000078f8213dc91a  call 0x000078F8212E1570
000078f8213dc91f  jmp 0x000078F8213DBA4D
000078f8213dc924  call 0x000078F8212E27E0
000078f8213dc929  jmp 0x000078F8213DBA90
000078f8213dc92e  call 0x000078F8212E1570
000078f8213dc933  jmp 0x000078F8213DBA99
000078f8213dc938  call 0x000078F82120DC20
000078f8213dc93d  jmp 0x000078F8213DBAD8
000078f8213dc942  call 0x000078F8212D59C0
000078f8213dc947  jmp 0x000078F8213DBAEB
000078f8213dc94c  call 0x000078F8212E0E30
000078f8213dc951  jmp 0x000078F8213DBB09
000078f8213dc956  call 0x000078F8212DFBC0
000078f8213dc95b  jmp 0x000078F8213DBB13
000078f8213dc960  call 0x000078F8212DE950
000078f8213dc965  jmp 0x000078F8213DBB1D
000078f8213dc96a  sub rsp, 0x08
000078f8213dc96e  push rax
000078f8213dc96f  push rcx
000078f8213dc970  push rdx
000078f8213dc971  push rdi
000078f8213dc972  push rsi
000078f8213dc973  push r8
000078f8213dc975  push r9
000078f8213dc977  push r10
000078f8213dc979  push r11
000078f8213dc97b  sub rsp, 0xF0
000078f8213dc982  vmovaps [rsp], xmm0
000078f8213dc987  vmovaps [rsp+0x10], xmm1
000078f8213dc98d  vmovaps [rsp+0x20], xmm2
000078f8213dc993  vmovaps [rsp+0x30], xmm3
000078f8213dc999  vmovaps [rsp+0x40], xmm4
000078f8213dc99f  vmovaps [rsp+0x50], xmm5
000078f8213dc9a5  vmovaps [rsp+0x60], xmm6
000078f8213dc9ab  vmovaps [rsp+0x70], xmm7
000078f8213dc9b1  vmovaps [rsp+0x80], xmm9
000078f8213dc9ba  vmovaps [rsp+0x90], xmm10
000078f8213dc9c3  vmovaps [rsp+0xA0], xmm11
000078f8213dc9cc  vmovaps [rsp+0xB0], xmm12
000078f8213dc9d5  vmovaps [rsp+0xC0], xmm13
000078f8213dc9de  vmovaps [rsp+0xD0], xmm14
000078f8213dc9e7  vmovaps [rsp+0xE0], xmm15
000078f8213dc9f0  sub rsp, 0x30
000078f8213dc9f4  movaps [rsp], xmm8
000078f8213dc9f9  movaps [rsp+0x10], xmm12
000078f8213dc9ff  movaps [rsp+0x20], xmm15
000078f8213dca05  lea rdi, [rsp]
000078f8213dca09  mov esi, 0x00
000078f8213dca0e  mov rax, 0x653D80F42530
000078f8213dca18  call rax
000078f8213dca1a  movaps xmm8, [rsp]
000078f8213dca1f  add rsp, 0x30
000078f8213dca23  vmovaps xmm0, [rsp]
000078f8213dca28  vmovaps xmm1, [rsp+0x10]
000078f8213dca2e  vmovaps xmm2, [rsp+0x20]
000078f8213dca34  vmovaps xmm3, [rsp+0x30]
000078f8213dca3a  vmovaps xmm4, [rsp+0x40]
000078f8213dca40  vmovaps xmm5, [rsp+0x50]
000078f8213dca46  vmovaps xmm6, [rsp+0x60]
000078f8213dca4c  vmovaps xmm7, [rsp+0x70]
000078f8213dca52  vmovaps xmm9, [rsp+0x80]
000078f8213dca5b  vmovaps xmm10, [rsp+0x90]
000078f8213dca64  vmovaps xmm11, [rsp+0xA0]
000078f8213dca6d  vmovaps xmm12, [rsp+0xB0]
000078f8213dca76  vmovaps xmm13, [rsp+0xC0]
000078f8213dca7f  vmovaps xmm14, [rsp+0xD0]
000078f8213dca88  vmovaps xmm15, [rsp+0xE0]
000078f8213dca91  add rsp, 0xF0
000078f8213dca98  pop r11
000078f8213dca9a  pop r10
000078f8213dca9c  pop r9
000078f8213dca9e  pop r8
000078f8213dcaa0  pop rsi
000078f8213dcaa1  pop rdi
000078f8213dcaa2  pop rdx
000078f8213dcaa3  pop rcx
000078f8213dcaa4  pop rax
000078f8213dcaa5  add rsp, 0x08
000078f8213dcaa9  jmp 0x000078F8213DBB47
000078f8213dcaae  sub rsp, 0x08
000078f8213dcab2  push rax
000078f8213dcab3  push rcx
000078f8213dcab4  push rdx
000078f8213dcab5  push rdi
000078f8213dcab6  push rsi
000078f8213dcab7  push r8
000078f8213dcab9  push r9
000078f8213dcabb  push r10
000078f8213dcabd  push r11
000078f8213dcabf  sub rsp, 0xF0
000078f8213dcac6  vmovaps [rsp], xmm0
000078f8213dcacb  vmovaps [rsp+0x10], xmm1
000078f8213dcad1  vmovaps [rsp+0x20], xmm2
000078f8213dcad7  vmovaps [rsp+0x30], xmm3
000078f8213dcadd  vmovaps [rsp+0x40], xmm4
000078f8213dcae3  vmovaps [rsp+0x50], xmm5
000078f8213dcae9  vmovaps [rsp+0x60], xmm6
000078f8213dcaef  vmovaps [rsp+0x70], xmm8
000078f8213dcaf5  vmovaps [rsp+0x80], xmm9
000078f8213dcafe  vmovaps [rsp+0x90], xmm10
000078f8213dcb07  vmovaps [rsp+0xA0], xmm11
000078f8213dcb10  vmovaps [rsp+0xB0], xmm12
000078f8213dcb19  vmovaps [rsp+0xC0], xmm13
000078f8213dcb22  vmovaps [rsp+0xD0], xmm14
000078f8213dcb2b  vmovaps [rsp+0xE0], xmm15
000078f8213dcb34  sub rsp, 0x30
000078f8213dcb38  movaps [rsp], xmm7
000078f8213dcb3c  movaps [rsp+0x10], xmm9
000078f8213dcb42  movaps [rsp+0x20], xmm15
000078f8213dcb48  lea rdi, [rsp]
000078f8213dcb4c  mov esi, 0x00
000078f8213dcb51  mov rax, 0x653D80F42530
000078f8213dcb5b  call rax
000078f8213dcb5d  movaps xmm7, [rsp]
000078f8213dcb61  add rsp, 0x30
000078f8213dcb65  vmovaps xmm0, [rsp]
000078f8213dcb6a  vmovaps xmm1, [rsp+0x10]
000078f8213dcb70  vmovaps xmm2, [rsp+0x20]
000078f8213dcb76  vmovaps xmm3, [rsp+0x30]
000078f8213dcb7c  vmovaps xmm4, [rsp+0x40]
000078f8213dcb82  vmovaps xmm5, [rsp+0x50]
000078f8213dcb88  vmovaps xmm6, [rsp+0x60]
000078f8213dcb8e  vmovaps xmm8, [rsp+0x70]
000078f8213dcb94  vmovaps xmm9, [rsp+0x80]
000078f8213dcb9d  vmovaps xmm10, [rsp+0x90]
000078f8213dcba6  vmovaps xmm11, [rsp+0xA0]
000078f8213dcbaf  vmovaps xmm12, [rsp+0xB0]
000078f8213dcbb8  vmovaps xmm13, [rsp+0xC0]
000078f8213dcbc1  vmovaps xmm14, [rsp+0xD0]
000078f8213dcbca  vmovaps xmm15, [rsp+0xE0]
000078f8213dcbd3  add rsp, 0xF0
000078f8213dcbda  pop r11
000078f8213dcbdc  pop r10
000078f8213dcbde  pop r9
000078f8213dcbe0  pop r8
000078f8213dcbe2  pop rsi
000078f8213dcbe3  pop rdi
000078f8213dcbe4  pop rdx
000078f8213dcbe5  pop rcx
000078f8213dcbe6  pop rax
000078f8213dcbe7  add rsp, 0x08
000078f8213dcbeb  jmp 0x000078F8213DBB75
000078f8213dcbf0  sub rsp, 0x08
000078f8213dcbf4  push rax
000078f8213dcbf5  push rcx
000078f8213dcbf6  push rdx
000078f8213dcbf7  push rdi
000078f8213dcbf8  push rsi
000078f8213dcbf9  push r8
000078f8213dcbfb  push r9
000078f8213dcbfd  push r10
000078f8213dcbff  push r11
000078f8213dcc01  sub rsp, 0xF0
000078f8213dcc08  vmovaps [rsp], xmm0
000078f8213dcc0d  vmovaps [rsp+0x10], xmm1
000078f8213dcc13  vmovaps [rsp+0x20], xmm2
000078f8213dcc19  vmovaps [rsp+0x30], xmm3
000078f8213dcc1f  vmovaps [rsp+0x40], xmm4
000078f8213dcc25  vmovaps [rsp+0x50], xmm5
000078f8213dcc2b  vmovaps [rsp+0x60], xmm6
000078f8213dcc31  vmovaps [rsp+0x70], xmm7
000078f8213dcc37  vmovaps [rsp+0x80], xmm8
000078f8213dcc40  vmovaps [rsp+0x90], xmm10
000078f8213dcc49  vmovaps [rsp+0xA0], xmm11
000078f8213dcc52  vmovaps [rsp+0xB0], xmm12
000078f8213dcc5b  vmovaps [rsp+0xC0], xmm13
000078f8213dcc64  vmovaps [rsp+0xD0], xmm14
000078f8213dcc6d  vmovaps [rsp+0xE0], xmm15
000078f8213dcc76  sub rsp, 0x30
000078f8213dcc7a  movaps [rsp], xmm9
000078f8213dcc7f  movaps [rsp+0x10], xmm12
000078f8213dcc85  movaps [rsp+0x20], xmm10
000078f8213dcc8b  lea rdi, [rsp]
000078f8213dcc8f  mov esi, 0x00
000078f8213dcc94  mov rax, 0x653D80F42530
000078f8213dcc9e  call rax
000078f8213dcca0  movaps xmm9, [rsp]
000078f8213dcca5  add rsp, 0x30
000078f8213dcca9  vmovaps xmm0, [rsp]
000078f8213dccae  vmovaps xmm1, [rsp+0x10]
000078f8213dccb4  vmovaps xmm2, [rsp+0x20]
000078f8213dccba  vmovaps xmm3, [rsp+0x30]
000078f8213dccc0  vmovaps xmm4, [rsp+0x40]
000078f8213dccc6  vmovaps xmm5, [rsp+0x50]
000078f8213dcccc  vmovaps xmm6, [rsp+0x60]
000078f8213dccd2  vmovaps xmm7, [rsp+0x70]
000078f8213dccd8  vmovaps xmm8, [rsp+0x80]
000078f8213dcce1  vmovaps xmm10, [rsp+0x90]
000078f8213dccea  vmovaps xmm11, [rsp+0xA0]
000078f8213dccf3  vmovaps xmm12, [rsp+0xB0]
000078f8213dccfc  vmovaps xmm13, [rsp+0xC0]
000078f8213dcd05  vmovaps xmm14, [rsp+0xD0]
000078f8213dcd0e  vmovaps xmm15, [rsp+0xE0]
000078f8213dcd17  add rsp, 0xF0
000078f8213dcd1e  pop r11
000078f8213dcd20  pop r10
000078f8213dcd22  pop r9
000078f8213dcd24  pop r8
000078f8213dcd26  pop rsi
000078f8213dcd27  pop rdi
000078f8213dcd28  pop rdx
000078f8213dcd29  pop rcx
000078f8213dcd2a  pop rax
000078f8213dcd2b  add rsp, 0x08
000078f8213dcd2f  jmp 0x000078F8213DBB99
000078f8213dcd34  sub rsp, 0x08
000078f8213dcd38  push rax
000078f8213dcd39  push rcx
000078f8213dcd3a  push rdx
000078f8213dcd3b  push rdi
000078f8213dcd3c  push rsi
000078f8213dcd3d  push r8
000078f8213dcd3f  push r9
000078f8213dcd41  push r10
000078f8213dcd43  push r11
000078f8213dcd45  sub rsp, 0xF0
000078f8213dcd4c  vmovaps [rsp], xmm0
000078f8213dcd51  vmovaps [rsp+0x10], xmm1
000078f8213dcd57  vmovaps [rsp+0x20], xmm2
000078f8213dcd5d  vmovaps [rsp+0x30], xmm3
000078f8213dcd63  vmovaps [rsp+0x40], xmm4
000078f8213dcd69  vmovaps [rsp+0x50], xmm5
000078f8213dcd6f  vmovaps [rsp+0x60], xmm6
000078f8213dcd75  vmovaps [rsp+0x70], xmm7
000078f8213dcd7b  vmovaps [rsp+0x80], xmm8
000078f8213dcd84  vmovaps [rsp+0x90], xmm9
000078f8213dcd8d  vmovaps [rsp+0xA0], xmm11
000078f8213dcd96  vmovaps [rsp+0xB0], xmm12
000078f8213dcd9f  vmovaps [rsp+0xC0], xmm13
000078f8213dcda8  vmovaps [rsp+0xD0], xmm14
000078f8213dcdb1  vmovaps [rsp+0xE0], xmm15
000078f8213dcdba  sub rsp, 0x30
000078f8213dcdbe  movaps [rsp], xmm10
000078f8213dcdc3  movaps [rsp+0x10], xmm12
000078f8213dcdc9  movaps [rsp+0x20], xmm11
000078f8213dcdcf  lea rdi, [rsp]
000078f8213dcdd3  mov esi, 0x00
000078f8213dcdd8  mov rax, 0x653D80F42530
000078f8213dcde2  call rax
000078f8213dcde4  movaps xmm10, [rsp]
000078f8213dcde9  add rsp, 0x30
000078f8213dcded  vmovaps xmm0, [rsp]
000078f8213dcdf2  vmovaps xmm1, [rsp+0x10]
000078f8213dcdf8  vmovaps xmm2, [rsp+0x20]
000078f8213dcdfe  vmovaps xmm3, [rsp+0x30]
000078f8213dce04  vmovaps xmm4, [rsp+0x40]
000078f8213dce0a  vmovaps xmm5, [rsp+0x50]
000078f8213dce10  vmovaps xmm6, [rsp+0x60]
000078f8213dce16  vmovaps xmm7, [rsp+0x70]
000078f8213dce1c  vmovaps xmm8, [rsp+0x80]
000078f8213dce25  vmovaps xmm9, [rsp+0x90]
000078f8213dce2e  vmovaps xmm11, [rsp+0xA0]
000078f8213dce37  vmovaps xmm12, [rsp+0xB0]
000078f8213dce40  vmovaps xmm13, [rsp+0xC0]
000078f8213dce49  vmovaps xmm14, [rsp+0xD0]
000078f8213dce52  vmovaps xmm15, [rsp+0xE0]
000078f8213dce5b  add rsp, 0xF0
000078f8213dce62  pop r11
000078f8213dce64  pop r10
000078f8213dce66  pop r9
000078f8213dce68  pop r8
000078f8213dce6a  pop rsi
000078f8213dce6b  pop rdi
000078f8213dce6c  pop rdx
000078f8213dce6d  pop rcx
000078f8213dce6e  pop rax
000078f8213dce6f  add rsp, 0x08
000078f8213dce73  jmp 0x000078F8213DBBB3
000078f8213dce78  sub rsp, 0x08
000078f8213dce7c  push rax
000078f8213dce7d  push rcx
000078f8213dce7e  push rdx
000078f8213dce7f  push rdi
000078f8213dce80  push rsi
000078f8213dce81  push r8
000078f8213dce83  push r9
000078f8213dce85  push r10
000078f8213dce87  push r11
000078f8213dce89  sub rsp, 0xF0
000078f8213dce90  vmovaps [rsp], xmm0
000078f8213dce95  vmovaps [rsp+0x10], xmm1
000078f8213dce9b  vmovaps [rsp+0x20], xmm2
000078f8213dcea1  vmovaps [rsp+0x30], xmm3
000078f8213dcea7  vmovaps [rsp+0x40], xmm4
000078f8213dcead  vmovaps [rsp+0x50], xmm5
000078f8213dceb3  vmovaps [rsp+0x60], xmm7
000078f8213dceb9  vmovaps [rsp+0x70], xmm8
000078f8213dcebf  vmovaps [rsp+0x80], xmm9
000078f8213dcec8  vmovaps [rsp+0x90], xmm10
000078f8213dced1  vmovaps [rsp+0xA0], xmm11
000078f8213dceda  vmovaps [rsp+0xB0], xmm12
000078f8213dcee3  vmovaps [rsp+0xC0], xmm13
000078f8213dceec  vmovaps [rsp+0xD0], xmm14
000078f8213dcef5  vmovaps [rsp+0xE0], xmm15
000078f8213dcefe  sub rsp, 0x30
000078f8213dcf02  movaps [rsp], xmm6
000078f8213dcf06  movaps [rsp+0x10], xmm12
000078f8213dcf0c  movaps [rsp+0x20], xmm11
000078f8213dcf12  lea rdi, [rsp]
000078f8213dcf16  mov esi, 0x00
000078f8213dcf1b  mov rax, 0x653D80F42530
000078f8213dcf25  call rax
000078f8213dcf27  movaps xmm6, [rsp]
000078f8213dcf2b  add rsp, 0x30
000078f8213dcf2f  vmovaps xmm0, [rsp]
000078f8213dcf34  vmovaps xmm1, [rsp+0x10]
000078f8213dcf3a  vmovaps xmm2, [rsp+0x20]
000078f8213dcf40  vmovaps xmm3, [rsp+0x30]
000078f8213dcf46  vmovaps xmm4, [rsp+0x40]
000078f8213dcf4c  vmovaps xmm5, [rsp+0x50]
000078f8213dcf52  vmovaps xmm7, [rsp+0x60]
000078f8213dcf58  vmovaps xmm8, [rsp+0x70]
000078f8213dcf5e  vmovaps xmm9, [rsp+0x80]
000078f8213dcf67  vmovaps xmm10, [rsp+0x90]
000078f8213dcf70  vmovaps xmm11, [rsp+0xA0]
000078f8213dcf79  vmovaps xmm12, [rsp+0xB0]
000078f8213dcf82  vmovaps xmm13, [rsp+0xC0]
000078f8213dcf8b  vmovaps xmm14, [rsp+0xD0]
000078f8213dcf94  vmovaps xmm15, [rsp+0xE0]
000078f8213dcf9d  add rsp, 0xF0
000078f8213dcfa4  pop r11
000078f8213dcfa6  pop r10
000078f8213dcfa8  pop r9
000078f8213dcfaa  pop r8
000078f8213dcfac  pop rsi
000078f8213dcfad  pop rdi
000078f8213dcfae  pop rdx
000078f8213dcfaf  pop rcx
000078f8213dcfb0  pop rax
000078f8213dcfb1  add rsp, 0x08
000078f8213dcfb5  jmp 0x000078F8213DBBD4
000078f8213dcfba  sub rsp, 0x08
000078f8213dcfbe  push rax
000078f8213dcfbf  push rcx
000078f8213dcfc0  push rdx
000078f8213dcfc1  push rdi
000078f8213dcfc2  push rsi
000078f8213dcfc3  push r8
000078f8213dcfc5  push r9
000078f8213dcfc7  push r10
000078f8213dcfc9  push r11
000078f8213dcfcb  sub rsp, 0xF0
000078f8213dcfd2  vmovaps [rsp], xmm0
000078f8213dcfd7  vmovaps [rsp+0x10], xmm1
000078f8213dcfdd  vmovaps [rsp+0x20], xmm2
000078f8213dcfe3  vmovaps [rsp+0x30], xmm4
000078f8213dcfe9  vmovaps [rsp+0x40], xmm5
000078f8213dcfef  vmovaps [rsp+0x50], xmm6
000078f8213dcff5  vmovaps [rsp+0x60], xmm7
000078f8213dcffb  vmovaps [rsp+0x70], xmm8
000078f8213dd001  vmovaps [rsp+0x80], xmm9
000078f8213dd00a  vmovaps [rsp+0x90], xmm10
000078f8213dd013  vmovaps [rsp+0xA0], xmm11
000078f8213dd01c  vmovaps [rsp+0xB0], xmm12
000078f8213dd025  vmovaps [rsp+0xC0], xmm13
000078f8213dd02e  vmovaps [rsp+0xD0], xmm14
000078f8213dd037  vmovaps [rsp+0xE0], xmm15
000078f8213dd040  sub rsp, 0x30
000078f8213dd044  movaps [rsp], xmm3
000078f8213dd048  movaps [rsp+0x10], xmm5
000078f8213dd04d  movaps [rsp+0x20], xmm4
000078f8213dd052  lea rdi, [rsp]
000078f8213dd056  mov esi, 0x00
000078f8213dd05b  mov rax, 0x653D80F42530
000078f8213dd065  call rax
000078f8213dd067  movaps xmm3, [rsp]
000078f8213dd06b  add rsp, 0x30
000078f8213dd06f  vmovaps xmm0, [rsp]
000078f8213dd074  vmovaps xmm1, [rsp+0x10]
000078f8213dd07a  vmovaps xmm2, [rsp+0x20]
000078f8213dd080  vmovaps xmm4, [rsp+0x30]
000078f8213dd086  vmovaps xmm5, [rsp+0x40]
000078f8213dd08c  vmovaps xmm6, [rsp+0x50]
000078f8213dd092  vmovaps xmm7, [rsp+0x60]
000078f8213dd098  vmovaps xmm8, [rsp+0x70]
000078f8213dd09e  vmovaps xmm9, [rsp+0x80]
000078f8213dd0a7  vmovaps xmm10, [rsp+0x90]
000078f8213dd0b0  vmovaps xmm11, [rsp+0xA0]
000078f8213dd0b9  vmovaps xmm12, [rsp+0xB0]
000078f8213dd0c2  vmovaps xmm13, [rsp+0xC0]
000078f8213dd0cb  vmovaps xmm14, [rsp+0xD0]
000078f8213dd0d4  vmovaps xmm15, [rsp+0xE0]
000078f8213dd0dd  add rsp, 0xF0
000078f8213dd0e4  pop r11
000078f8213dd0e6  pop r10
000078f8213dd0e8  pop r9
000078f8213dd0ea  pop r8
000078f8213dd0ec  pop rsi
000078f8213dd0ed  pop rdi
000078f8213dd0ee  pop rdx
000078f8213dd0ef  pop rcx
000078f8213dd0f0  pop rax
000078f8213dd0f1  add rsp, 0x08
000078f8213dd0f5  jmp 0x000078F8213DBC35
000078f8213dd0fa  sub rsp, 0x08
000078f8213dd0fe  push rax
000078f8213dd0ff  push rcx
000078f8213dd100  push rdx
000078f8213dd101  push rdi
000078f8213dd102  push rsi
000078f8213dd103  push r8
000078f8213dd105  push r9
000078f8213dd107  push r10
000078f8213dd109  push r11
000078f8213dd10b  sub rsp, 0xF0
000078f8213dd112  vmovaps [rsp], xmm0
000078f8213dd117  vmovaps [rsp+0x10], xmm1
000078f8213dd11d  vmovaps [rsp+0x20], xmm2
000078f8213dd123  vmovaps [rsp+0x30], xmm3
000078f8213dd129  vmovaps [rsp+0x40], xmm4
000078f8213dd12f  vmovaps [rsp+0x50], xmm6
000078f8213dd135  vmovaps [rsp+0x60], xmm7
000078f8213dd13b  vmovaps [rsp+0x70], xmm8
000078f8213dd141  vmovaps [rsp+0x80], xmm9
000078f8213dd14a  vmovaps [rsp+0x90], xmm10
000078f8213dd153  vmovaps [rsp+0xA0], xmm11
000078f8213dd15c  vmovaps [rsp+0xB0], xmm12
000078f8213dd165  vmovaps [rsp+0xC0], xmm13
000078f8213dd16e  vmovaps [rsp+0xD0], xmm14
000078f8213dd177  vmovaps [rsp+0xE0], xmm15
000078f8213dd180  sub rsp, 0x30
000078f8213dd184  movaps [rsp], xmm5
000078f8213dd188  movaps [rsp+0x10], xmm8
000078f8213dd18e  movaps [rsp+0x20], xmm15
000078f8213dd194  lea rdi, [rsp]
000078f8213dd198  mov esi, 0x00
000078f8213dd19d  mov rax, 0x653D80F42530
000078f8213dd1a7  call rax
000078f8213dd1a9  movaps xmm5, [rsp]
000078f8213dd1ad  add rsp, 0x30
000078f8213dd1b1  vmovaps xmm0, [rsp]
000078f8213dd1b6  vmovaps xmm1, [rsp+0x10]
000078f8213dd1bc  vmovaps xmm2, [rsp+0x20]
000078f8213dd1c2  vmovaps xmm3, [rsp+0x30]
000078f8213dd1c8  vmovaps xmm4, [rsp+0x40]
000078f8213dd1ce  vmovaps xmm6, [rsp+0x50]
000078f8213dd1d4  vmovaps xmm7, [rsp+0x60]
000078f8213dd1da  vmovaps xmm8, [rsp+0x70]
000078f8213dd1e0  vmovaps xmm9, [rsp+0x80]
000078f8213dd1e9  vmovaps xmm10, [rsp+0x90]
000078f8213dd1f2  vmovaps xmm11, [rsp+0xA0]
000078f8213dd1fb  vmovaps xmm12, [rsp+0xB0]
000078f8213dd204  vmovaps xmm13, [rsp+0xC0]
000078f8213dd20d  vmovaps xmm14, [rsp+0xD0]
000078f8213dd216  vmovaps xmm15, [rsp+0xE0]
000078f8213dd21f  add rsp, 0xF0
000078f8213dd226  pop r11
000078f8213dd228  pop r10
000078f8213dd22a  pop r9
000078f8213dd22c  pop r8
000078f8213dd22e  pop rsi
000078f8213dd22f  pop rdi
000078f8213dd230  pop rdx
000078f8213dd231  pop rcx
000078f8213dd232  pop rax
000078f8213dd233  add rsp, 0x08
000078f8213dd237  jmp 0x000078F8213DBC73
000078f8213dd23c  sub rsp, 0x08
000078f8213dd240  push rax
000078f8213dd241  push rcx
000078f8213dd242  push rdx
000078f8213dd243  push rdi
000078f8213dd244  push rsi
000078f8213dd245  push r8
000078f8213dd247  push r9
000078f8213dd249  push r10
000078f8213dd24b  push r11
000078f8213dd24d  sub rsp, 0xF0
000078f8213dd254  vmovaps [rsp], xmm0
000078f8213dd259  vmovaps [rsp+0x10], xmm1
000078f8213dd25f  vmovaps [rsp+0x20], xmm2
000078f8213dd265  vmovaps [rsp+0x30], xmm3
000078f8213dd26b  vmovaps [rsp+0x40], xmm5
000078f8213dd271  vmovaps [rsp+0x50], xmm6
000078f8213dd277  vmovaps [rsp+0x60], xmm7
000078f8213dd27d  vmovaps [rsp+0x70], xmm8
000078f8213dd283  vmovaps [rsp+0x80], xmm9
000078f8213dd28c  vmovaps [rsp+0x90], xmm10
000078f8213dd295  vmovaps [rsp+0xA0], xmm11
000078f8213dd29e  vmovaps [rsp+0xB0], xmm12
000078f8213dd2a7  vmovaps [rsp+0xC0], xmm13
000078f8213dd2b0  vmovaps [rsp+0xD0], xmm14
000078f8213dd2b9  vmovaps [rsp+0xE0], xmm15
000078f8213dd2c2  sub rsp, 0x30
000078f8213dd2c6  movaps [rsp], xmm4
000078f8213dd2ca  movaps [rsp+0x10], xmm9
000078f8213dd2d0  movaps [rsp+0x20], xmm8
000078f8213dd2d6  lea rdi, [rsp]
000078f8213dd2da  mov esi, 0x00
000078f8213dd2df  mov rax, 0x653D80F42530
000078f8213dd2e9  call rax
000078f8213dd2eb  movaps xmm4, [rsp]
000078f8213dd2ef  add rsp, 0x30
000078f8213dd2f3  vmovaps xmm0, [rsp]
000078f8213dd2f8  vmovaps xmm1, [rsp+0x10]
000078f8213dd2fe  vmovaps xmm2, [rsp+0x20]
000078f8213dd304  vmovaps xmm3, [rsp+0x30]
000078f8213dd30a  vmovaps xmm5, [rsp+0x40]
000078f8213dd310  vmovaps xmm6, [rsp+0x50]
000078f8213dd316  vmovaps xmm7, [rsp+0x60]
000078f8213dd31c  vmovaps xmm8, [rsp+0x70]
000078f8213dd322  vmovaps xmm9, [rsp+0x80]
000078f8213dd32b  vmovaps xmm10, [rsp+0x90]
000078f8213dd334  vmovaps xmm11, [rsp+0xA0]
000078f8213dd33d  vmovaps xmm12, [rsp+0xB0]
000078f8213dd346  vmovaps xmm13, [rsp+0xC0]
000078f8213dd34f  vmovaps xmm14, [rsp+0xD0]
000078f8213dd358  vmovaps xmm15, [rsp+0xE0]
000078f8213dd361  add rsp, 0xF0
000078f8213dd368  pop r11
000078f8213dd36a  pop r10
000078f8213dd36c  pop r9
000078f8213dd36e  pop r8
000078f8213dd370  pop rsi
000078f8213dd371  pop rdi
000078f8213dd372  pop rdx
000078f8213dd373  pop rcx
000078f8213dd374  pop rax
000078f8213dd375  add rsp, 0x08
000078f8213dd379  jmp 0x000078F8213DBC94
000078f8213dd37e  sub rsp, 0x08
000078f8213dd382  push rax
000078f8213dd383  push rcx
000078f8213dd384  push rdx
000078f8213dd385  push rdi
000078f8213dd386  push rsi
000078f8213dd387  push r8
000078f8213dd389  push r9
000078f8213dd38b  push r10
000078f8213dd38d  push r11
000078f8213dd38f  sub rsp, 0xF0
000078f8213dd396  vmovaps [rsp], xmm0
000078f8213dd39b  vmovaps [rsp+0x10], xmm1
000078f8213dd3a1  vmovaps [rsp+0x20], xmm2
000078f8213dd3a7  vmovaps [rsp+0x30], xmm3
000078f8213dd3ad  vmovaps [rsp+0x40], xmm4
000078f8213dd3b3  vmovaps [rsp+0x50], xmm5
000078f8213dd3b9  vmovaps [rsp+0x60], xmm6
000078f8213dd3bf  vmovaps [rsp+0x70], xmm7
000078f8213dd3c5  vmovaps [rsp+0x80], xmm8
000078f8213dd3ce  vmovaps [rsp+0x90], xmm10
000078f8213dd3d7  vmovaps [rsp+0xA0], xmm11
000078f8213dd3e0  vmovaps [rsp+0xB0], xmm12
000078f8213dd3e9  vmovaps [rsp+0xC0], xmm13
000078f8213dd3f2  vmovaps [rsp+0xD0], xmm14
000078f8213dd3fb  vmovaps [rsp+0xE0], xmm15
000078f8213dd404  sub rsp, 0x30
000078f8213dd408  movaps [rsp], xmm9
000078f8213dd40d  movaps [rsp+0x10], xmm10
000078f8213dd413  movaps [rsp+0x20], xmm8
000078f8213dd419  lea rdi, [rsp]
000078f8213dd41d  mov esi, 0x00
000078f8213dd422  mov rax, 0x653D80F42530
000078f8213dd42c  call rax
000078f8213dd42e  movaps xmm9, [rsp]
000078f8213dd433  add rsp, 0x30
000078f8213dd437  vmovaps xmm0, [rsp]
000078f8213dd43c  vmovaps xmm1, [rsp+0x10]
000078f8213dd442  vmovaps xmm2, [rsp+0x20]
000078f8213dd448  vmovaps xmm3, [rsp+0x30]
000078f8213dd44e  vmovaps xmm4, [rsp+0x40]
000078f8213dd454  vmovaps xmm5, [rsp+0x50]
000078f8213dd45a  vmovaps xmm6, [rsp+0x60]
000078f8213dd460  vmovaps xmm7, [rsp+0x70]
000078f8213dd466  vmovaps xmm8, [rsp+0x80]
000078f8213dd46f  vmovaps xmm10, [rsp+0x90]
000078f8213dd478  vmovaps xmm11, [rsp+0xA0]
000078f8213dd481  vmovaps xmm12, [rsp+0xB0]
000078f8213dd48a  vmovaps xmm13, [rsp+0xC0]
000078f8213dd493  vmovaps xmm14, [rsp+0xD0]
000078f8213dd49c  vmovaps xmm15, [rsp+0xE0]
000078f8213dd4a5  add rsp, 0xF0
000078f8213dd4ac  pop r11
000078f8213dd4ae  pop r10
000078f8213dd4b0  pop r9
000078f8213dd4b2  pop r8
000078f8213dd4b4  pop rsi
000078f8213dd4b5  pop rdi
000078f8213dd4b6  pop rdx
000078f8213dd4b7  pop rcx
000078f8213dd4b8  pop rax
000078f8213dd4b9  add rsp, 0x08
000078f8213dd4bd  jmp 0x000078F8213DBCAE
000078f8213dd4c2  call 0x000078F8212B52F0
000078f8213dd4c7  jmp 0x000078F8213DBDC8
000078f8213dd4cc  call 0x000078F8212B52F0
000078f8213dd4d1  jmp 0x000078F8213DBDDE
000078f8213dd4d6  sub rsp, 0x08
000078f8213dd4da  push rax
000078f8213dd4db  push rcx
000078f8213dd4dc  push rdx
000078f8213dd4dd  push rdi
000078f8213dd4de  push rsi
000078f8213dd4df  push r8
000078f8213dd4e1  push r9
000078f8213dd4e3  push r10
000078f8213dd4e5  push r11
000078f8213dd4e7  sub rsp, 0xF0
000078f8213dd4ee  vmovaps [rsp], xmm0
000078f8213dd4f3  vmovaps [rsp+0x10], xmm2
000078f8213dd4f9  vmovaps [rsp+0x20], xmm3
000078f8213dd4ff  vmovaps [rsp+0x30], xmm4
000078f8213dd505  vmovaps [rsp+0x40], xmm5
000078f8213dd50b  vmovaps [rsp+0x50], xmm6
000078f8213dd511  vmovaps [rsp+0x60], xmm7
000078f8213dd517  vmovaps [rsp+0x70], xmm8
000078f8213dd51d  vmovaps [rsp+0x80], xmm9
000078f8213dd526  vmovaps [rsp+0x90], xmm10
000078f8213dd52f  vmovaps [rsp+0xA0], xmm11
000078f8213dd538  vmovaps [rsp+0xB0], xmm12
000078f8213dd541  vmovaps [rsp+0xC0], xmm13
000078f8213dd54a  vmovaps [rsp+0xD0], xmm14
000078f8213dd553  vmovaps [rsp+0xE0], xmm15
000078f8213dd55c  sub rsp, 0x30
000078f8213dd560  movaps [rsp], xmm1
000078f8213dd564  movaps [rsp+0x10], xmm6
000078f8213dd569  movaps [rsp+0x20], xmm15
000078f8213dd56f  lea rdi, [rsp]
000078f8213dd573  mov esi, 0x00
000078f8213dd578  mov rax, 0x653D80F42530
000078f8213dd582  call rax
000078f8213dd584  movaps xmm1, [rsp]
000078f8213dd588  add rsp, 0x30
000078f8213dd58c  vmovaps xmm0, [rsp]
000078f8213dd591  vmovaps xmm2, [rsp+0x10]
000078f8213dd597  vmovaps xmm3, [rsp+0x20]
000078f8213dd59d  vmovaps xmm4, [rsp+0x30]
000078f8213dd5a3  vmovaps xmm5, [rsp+0x40]
000078f8213dd5a9  vmovaps xmm6, [rsp+0x50]
000078f8213dd5af  vmovaps xmm7, [rsp+0x60]
000078f8213dd5b5  vmovaps xmm8, [rsp+0x70]
000078f8213dd5bb  vmovaps xmm9, [rsp+0x80]
000078f8213dd5c4  vmovaps xmm10, [rsp+0x90]
000078f8213dd5cd  vmovaps xmm11, [rsp+0xA0]
000078f8213dd5d6  vmovaps xmm12, [rsp+0xB0]
000078f8213dd5df  vmovaps xmm13, [rsp+0xC0]
000078f8213dd5e8  vmovaps xmm14, [rsp+0xD0]
000078f8213dd5f1  vmovaps xmm15, [rsp+0xE0]
000078f8213dd5fa  add rsp, 0xF0
000078f8213dd601  pop r11
000078f8213dd603  pop r10
000078f8213dd605  pop r9
000078f8213dd607  pop r8
000078f8213dd609  pop rsi
000078f8213dd60a  pop rdi
000078f8213dd60b  pop rdx
000078f8213dd60c  pop rcx
000078f8213dd60d  pop rax
000078f8213dd60e  add rsp, 0x08
000078f8213dd612  jmp 0x000078F8213DBE1B
000078f8213dd617  call 0x000078F8212C4620
000078f8213dd61c  jmp 0x000078F8213DBE28
000078f8213dd621  sub rsp, 0x08
000078f8213dd625  push rax
000078f8213dd626  push rcx
000078f8213dd627  push rdx
000078f8213dd628  push rdi
000078f8213dd629  push rsi
000078f8213dd62a  push r8
000078f8213dd62c  push r9
000078f8213dd62e  push r10
000078f8213dd630  push r11
000078f8213dd632  sub rsp, 0xF0
000078f8213dd639  vmovaps [rsp], xmm0
000078f8213dd63e  vmovaps [rsp+0x10], xmm1
000078f8213dd644  vmovaps [rsp+0x20], xmm2
000078f8213dd64a  vmovaps [rsp+0x30], xmm3
000078f8213dd650  vmovaps [rsp+0x40], xmm4
000078f8213dd656  vmovaps [rsp+0x50], xmm5
000078f8213dd65c  vmovaps [rsp+0x60], xmm6
000078f8213dd662  vmovaps [rsp+0x70], xmm7
000078f8213dd668  vmovaps [rsp+0x80], xmm8
000078f8213dd671  vmovaps [rsp+0x90], xmm9
000078f8213dd67a  vmovaps [rsp+0xA0], xmm10
000078f8213dd683  vmovaps [rsp+0xB0], xmm11
000078f8213dd68c  vmovaps [rsp+0xC0], xmm12
000078f8213dd695  vmovaps [rsp+0xD0], xmm13
000078f8213dd69e  vmovaps [rsp+0xE0], xmm15
000078f8213dd6a7  sub rsp, 0x30
000078f8213dd6ab  movaps [rsp], xmm14
000078f8213dd6b0  movaps [rsp+0x10], xmm4
000078f8213dd6b5  movaps [rsp+0x20], xmm3
000078f8213dd6ba  lea rdi, [rsp]
000078f8213dd6be  mov esi, 0x00
000078f8213dd6c3  mov rax, 0x653D80F42530
000078f8213dd6cd  call rax
000078f8213dd6cf  movaps xmm14, [rsp]
000078f8213dd6d4  add rsp, 0x30
000078f8213dd6d8  vmovaps xmm0, [rsp]
000078f8213dd6dd  vmovaps xmm1, [rsp+0x10]
000078f8213dd6e3  vmovaps xmm2, [rsp+0x20]
000078f8213dd6e9  vmovaps xmm3, [rsp+0x30]
000078f8213dd6ef  vmovaps xmm4, [rsp+0x40]
000078f8213dd6f5  vmovaps xmm5, [rsp+0x50]
000078f8213dd6fb  vmovaps xmm6, [rsp+0x60]
000078f8213dd701  vmovaps xmm7, [rsp+0x70]
000078f8213dd707  vmovaps xmm8, [rsp+0x80]
000078f8213dd710  vmovaps xmm9, [rsp+0x90]
000078f8213dd719  vmovaps xmm10, [rsp+0xA0]
000078f8213dd722  vmovaps xmm11, [rsp+0xB0]
000078f8213dd72b  vmovaps xmm12, [rsp+0xC0]
000078f8213dd734  vmovaps xmm13, [rsp+0xD0]
000078f8213dd73d  vmovaps xmm15, [rsp+0xE0]
000078f8213dd746  add rsp, 0xF0
000078f8213dd74d  pop r11
000078f8213dd74f  pop r10
000078f8213dd751  pop r9
000078f8213dd753  pop r8
000078f8213dd755  pop rsi
000078f8213dd756  pop rdi
000078f8213dd757  pop rdx
000078f8213dd758  pop rcx
000078f8213dd759  pop rax
000078f8213dd75a  add rsp, 0x08
000078f8213dd75e  jmp 0x000078F8213DBE42
000078f8213dd763  sub rsp, 0x08
000078f8213dd767  push rax
000078f8213dd768  push rcx
000078f8213dd769  push rdx
000078f8213dd76a  push rdi
000078f8213dd76b  push rsi
000078f8213dd76c  push r8
000078f8213dd76e  push r9
000078f8213dd770  push r10
000078f8213dd772  push r11
000078f8213dd774  sub rsp, 0xF0
000078f8213dd77b  vmovaps [rsp], xmm0
000078f8213dd780  vmovaps [rsp+0x10], xmm1
000078f8213dd786  vmovaps [rsp+0x20], xmm2
000078f8213dd78c  vmovaps [rsp+0x30], xmm3
000078f8213dd792  vmovaps [rsp+0x40], xmm4
000078f8213dd798  vmovaps [rsp+0x50], xmm5
000078f8213dd79e  vmovaps [rsp+0x60], xmm7
000078f8213dd7a4  vmovaps [rsp+0x70], xmm8
000078f8213dd7aa  vmovaps [rsp+0x80], xmm9
000078f8213dd7b3  vmovaps [rsp+0x90], xmm10
000078f8213dd7bc  vmovaps [rsp+0xA0], xmm11
000078f8213dd7c5  vmovaps [rsp+0xB0], xmm12
000078f8213dd7ce  vmovaps [rsp+0xC0], xmm13
000078f8213dd7d7  vmovaps [rsp+0xD0], xmm14
000078f8213dd7e0  vmovaps [rsp+0xE0], xmm15
000078f8213dd7e9  sub rsp, 0x30
000078f8213dd7ed  movaps [rsp], xmm6
000078f8213dd7f1  movaps [rsp+0x10], xmm9
000078f8213dd7f7  movaps [rsp+0x20], xmm7
000078f8213dd7fc  lea rdi, [rsp]
000078f8213dd800  mov esi, 0x00
000078f8213dd805  mov rax, 0x653D80F42530
000078f8213dd80f  call rax
000078f8213dd811  movaps xmm6, [rsp]
000078f8213dd815  add rsp, 0x30
000078f8213dd819  vmovaps xmm0, [rsp]
000078f8213dd81e  vmovaps xmm1, [rsp+0x10]
000078f8213dd824  vmovaps xmm2, [rsp+0x20]
000078f8213dd82a  vmovaps xmm3, [rsp+0x30]
000078f8213dd830  vmovaps xmm4, [rsp+0x40]
000078f8213dd836  vmovaps xmm5, [rsp+0x50]
000078f8213dd83c  vmovaps xmm7, [rsp+0x60]
000078f8213dd842  vmovaps xmm8, [rsp+0x70]
000078f8213dd848  vmovaps xmm9, [rsp+0x80]
000078f8213dd851  vmovaps xmm10, [rsp+0x90]
000078f8213dd85a  vmovaps xmm11, [rsp+0xA0]
000078f8213dd863  vmovaps xmm12, [rsp+0xB0]
000078f8213dd86c  vmovaps xmm13, [rsp+0xC0]
000078f8213dd875  vmovaps xmm14, [rsp+0xD0]
000078f8213dd87e  vmovaps xmm15, [rsp+0xE0]
000078f8213dd887  add rsp, 0xF0
000078f8213dd88e  pop r11
000078f8213dd890  pop r10
000078f8213dd892  pop r9
000078f8213dd894  pop r8
000078f8213dd896  pop rsi
000078f8213dd897  pop rdi
000078f8213dd898  pop rdx
000078f8213dd899  pop rcx
000078f8213dd89a  pop rax
000078f8213dd89b  add rsp, 0x08
000078f8213dd89f  jmp 0x000078F8213DBE5A
000078f8213dd8a4  sub rsp, 0x08
000078f8213dd8a8  push rax
000078f8213dd8a9  push rcx
000078f8213dd8aa  push rdx
000078f8213dd8ab  push rdi
000078f8213dd8ac  push rsi
000078f8213dd8ad  push r8
000078f8213dd8af  push r9
000078f8213dd8b1  push r10
000078f8213dd8b3  push r11
000078f8213dd8b5  sub rsp, 0xF0
000078f8213dd8bc  vmovaps [rsp], xmm0
000078f8213dd8c1  vmovaps [rsp+0x10], xmm1
000078f8213dd8c7  vmovaps [rsp+0x20], xmm2
000078f8213dd8cd  vmovaps [rsp+0x30], xmm3
000078f8213dd8d3  vmovaps [rsp+0x40], xmm4
000078f8213dd8d9  vmovaps [rsp+0x50], xmm5
000078f8213dd8df  vmovaps [rsp+0x60], xmm6
000078f8213dd8e5  vmovaps [rsp+0x70], xmm8
000078f8213dd8eb  vmovaps [rsp+0x80], xmm9
000078f8213dd8f4  vmovaps [rsp+0x90], xmm10
000078f8213dd8fd  vmovaps [rsp+0xA0], xmm11
000078f8213dd906  vmovaps [rsp+0xB0], xmm12
000078f8213dd90f  vmovaps [rsp+0xC0], xmm13
000078f8213dd918  vmovaps [rsp+0xD0], xmm14
000078f8213dd921  vmovaps [rsp+0xE0], xmm15
000078f8213dd92a  sub rsp, 0x30
000078f8213dd92e  movaps [rsp], xmm7
000078f8213dd932  movaps [rsp+0x10], xmm4
000078f8213dd937  movaps [rsp+0x20], xmm9
000078f8213dd93d  lea rdi, [rsp]
000078f8213dd941  mov esi, 0x00
000078f8213dd946  mov rax, 0x653D80F42530
000078f8213dd950  call rax
000078f8213dd952  movaps xmm7, [rsp]
000078f8213dd956  add rsp, 0x30
000078f8213dd95a  vmovaps xmm0, [rsp]
000078f8213dd95f  vmovaps xmm1, [rsp+0x10]
000078f8213dd965  vmovaps xmm2, [rsp+0x20]
000078f8213dd96b  vmovaps xmm3, [rsp+0x30]
000078f8213dd971  vmovaps xmm4, [rsp+0x40]
000078f8213dd977  vmovaps xmm5, [rsp+0x50]
000078f8213dd97d  vmovaps xmm6, [rsp+0x60]
000078f8213dd983  vmovaps xmm8, [rsp+0x70]
000078f8213dd989  vmovaps xmm9, [rsp+0x80]
000078f8213dd992  vmovaps xmm10, [rsp+0x90]
000078f8213dd99b  vmovaps xmm11, [rsp+0xA0]
000078f8213dd9a4  vmovaps xmm12, [rsp+0xB0]
000078f8213dd9ad  vmovaps xmm13, [rsp+0xC0]
000078f8213dd9b6  vmovaps xmm14, [rsp+0xD0]
000078f8213dd9bf  vmovaps xmm15, [rsp+0xE0]
000078f8213dd9c8  add rsp, 0xF0
000078f8213dd9cf  pop r11
000078f8213dd9d1  pop r10
000078f8213dd9d3  pop r9
000078f8213dd9d5  pop r8
000078f8213dd9d7  pop rsi
000078f8213dd9d8  pop rdi
000078f8213dd9d9  pop rdx
000078f8213dd9da  pop rcx
000078f8213dd9db  pop rax
000078f8213dd9dc  add rsp, 0x08
000078f8213dd9e0  jmp 0x000078F8213DBE87
000078f8213dd9e5  sub rsp, 0x08
000078f8213dd9e9  push rax
000078f8213dd9ea  push rcx
000078f8213dd9eb  push rdx
000078f8213dd9ec  push rdi
000078f8213dd9ed  push rsi
000078f8213dd9ee  push r8
000078f8213dd9f0  push r9
000078f8213dd9f2  push r10
000078f8213dd9f4  push r11
000078f8213dd9f6  sub rsp, 0xF0
000078f8213dd9fd  vmovaps [rsp], xmm0
000078f8213dda02  vmovaps [rsp+0x10], xmm1
000078f8213dda08  vmovaps [rsp+0x20], xmm2
000078f8213dda0e  vmovaps [rsp+0x30], xmm3
000078f8213dda14  vmovaps [rsp+0x40], xmm5
000078f8213dda1a  vmovaps [rsp+0x50], xmm6
000078f8213dda20  vmovaps [rsp+0x60], xmm7
000078f8213dda26  vmovaps [rsp+0x70], xmm8
000078f8213dda2c  vmovaps [rsp+0x80], xmm9
000078f8213dda35  vmovaps [rsp+0x90], xmm10
000078f8213dda3e  vmovaps [rsp+0xA0], xmm11
000078f8213dda47  vmovaps [rsp+0xB0], xmm12
000078f8213dda50  vmovaps [rsp+0xC0], xmm13
000078f8213dda59  vmovaps [rsp+0xD0], xmm14
000078f8213dda62  vmovaps [rsp+0xE0], xmm15
000078f8213dda6b  sub rsp, 0x30
000078f8213dda6f  movaps [rsp], xmm4
000078f8213dda73  movaps [rsp+0x10], xmm15
000078f8213dda79  movaps [rsp+0x20], xmm9
000078f8213dda7f  lea rdi, [rsp]
000078f8213dda83  mov esi, 0x00
000078f8213dda88  mov rax, 0x653D80F42530
000078f8213dda92  call rax
000078f8213dda94  movaps xmm4, [rsp]
000078f8213dda98  add rsp, 0x30
000078f8213dda9c  vmovaps xmm0, [rsp]
000078f8213ddaa1  vmovaps xmm1, [rsp+0x10]
000078f8213ddaa7  vmovaps xmm2, [rsp+0x20]
000078f8213ddaad  vmovaps xmm3, [rsp+0x30]
000078f8213ddab3  vmovaps xmm5, [rsp+0x40]
000078f8213ddab9  vmovaps xmm6, [rsp+0x50]
000078f8213ddabf  vmovaps xmm7, [rsp+0x60]
000078f8213ddac5  vmovaps xmm8, [rsp+0x70]
000078f8213ddacb  vmovaps xmm9, [rsp+0x80]
000078f8213ddad4  vmovaps xmm10, [rsp+0x90]
000078f8213ddadd  vmovaps xmm11, [rsp+0xA0]
000078f8213ddae6  vmovaps xmm12, [rsp+0xB0]
000078f8213ddaef  vmovaps xmm13, [rsp+0xC0]
000078f8213ddaf8  vmovaps xmm14, [rsp+0xD0]
000078f8213ddb01  vmovaps xmm15, [rsp+0xE0]
000078f8213ddb0a  add rsp, 0xF0
000078f8213ddb11  pop r11
000078f8213ddb13  pop r10
000078f8213ddb15  pop r9
000078f8213ddb17  pop r8
000078f8213ddb19  pop rsi
000078f8213ddb1a  pop rdi
000078f8213ddb1b  pop rdx
000078f8213ddb1c  pop rcx
000078f8213ddb1d  pop rax
000078f8213ddb1e  add rsp, 0x08
000078f8213ddb22  jmp 0x000078F8213DBEAC
000078f8213ddb27  call 0x000078F8212C4620
000078f8213ddb2c  jmp 0x000078F8213DBEB9
000078f8213ddb31  sub rsp, 0x08
000078f8213ddb35  push rax
000078f8213ddb36  push rcx
000078f8213ddb37  push rdx
000078f8213ddb38  push rdi
000078f8213ddb39  push rsi
000078f8213ddb3a  push r8
000078f8213ddb3c  push r9
000078f8213ddb3e  push r10
000078f8213ddb40  push r11
000078f8213ddb42  sub rsp, 0xF0
000078f8213ddb49  vmovaps [rsp], xmm0
000078f8213ddb4e  vmovaps [rsp+0x10], xmm1
000078f8213ddb54  vmovaps [rsp+0x20], xmm2
000078f8213ddb5a  vmovaps [rsp+0x30], xmm4
000078f8213ddb60  vmovaps [rsp+0x40], xmm5
000078f8213ddb66  vmovaps [rsp+0x50], xmm6
000078f8213ddb6c  vmovaps [rsp+0x60], xmm7
000078f8213ddb72  vmovaps [rsp+0x70], xmm8
000078f8213ddb78  vmovaps [rsp+0x80], xmm9
000078f8213ddb81  vmovaps [rsp+0x90], xmm10
000078f8213ddb8a  vmovaps [rsp+0xA0], xmm11
000078f8213ddb93  vmovaps [rsp+0xB0], xmm12
000078f8213ddb9c  vmovaps [rsp+0xC0], xmm13
000078f8213ddba5  vmovaps [rsp+0xD0], xmm14
000078f8213ddbae  vmovaps [rsp+0xE0], xmm15
000078f8213ddbb7  sub rsp, 0x30
000078f8213ddbbb  movaps [rsp], xmm3
000078f8213ddbbf  movaps [rsp+0x10], xmm1
000078f8213ddbc4  movaps [rsp+0x20], xmm9
000078f8213ddbca  lea rdi, [rsp]
000078f8213ddbce  mov esi, 0x00
000078f8213ddbd3  mov rax, 0x653D80F42530
000078f8213ddbdd  call rax
000078f8213ddbdf  movaps xmm3, [rsp]
000078f8213ddbe3  add rsp, 0x30
000078f8213ddbe7  vmovaps xmm0, [rsp]
000078f8213ddbec  vmovaps xmm1, [rsp+0x10]
000078f8213ddbf2  vmovaps xmm2, [rsp+0x20]
000078f8213ddbf8  vmovaps xmm4, [rsp+0x30]
000078f8213ddbfe  vmovaps xmm5, [rsp+0x40]
000078f8213ddc04  vmovaps xmm6, [rsp+0x50]
000078f8213ddc0a  vmovaps xmm7, [rsp+0x60]
000078f8213ddc10  vmovaps xmm8, [rsp+0x70]
000078f8213ddc16  vmovaps xmm9, [rsp+0x80]
000078f8213ddc1f  vmovaps xmm10, [rsp+0x90]
000078f8213ddc28  vmovaps xmm11, [rsp+0xA0]
000078f8213ddc31  vmovaps xmm12, [rsp+0xB0]
000078f8213ddc3a  vmovaps xmm13, [rsp+0xC0]
000078f8213ddc43  vmovaps xmm14, [rsp+0xD0]
000078f8213ddc4c  vmovaps xmm15, [rsp+0xE0]
000078f8213ddc55  add rsp, 0xF0
000078f8213ddc5c  pop r11
000078f8213ddc5e  pop r10
000078f8213ddc60  pop r9
000078f8213ddc62  pop r8
000078f8213ddc64  pop rsi
000078f8213ddc65  pop rdi
000078f8213ddc66  pop rdx
000078f8213ddc67  pop rcx
000078f8213ddc68  pop rax
000078f8213ddc69  add rsp, 0x08
000078f8213ddc6d  jmp 0x000078F8213DBEF6
000078f8213ddc72  sub rsp, 0x08
000078f8213ddc76  push rax
000078f8213ddc77  push rcx
000078f8213ddc78  push rdx
000078f8213ddc79  push rdi
000078f8213ddc7a  push rsi
000078f8213ddc7b  push r8
000078f8213ddc7d  push r9
000078f8213ddc7f  push r10
000078f8213ddc81  push r11
000078f8213ddc83  sub rsp, 0xF0
000078f8213ddc8a  vmovaps [rsp], xmm0
000078f8213ddc8f  vmovaps [rsp+0x10], xmm2
000078f8213ddc95  vmovaps [rsp+0x20], xmm3
000078f8213ddc9b  vmovaps [rsp+0x30], xmm4
000078f8213ddca1  vmovaps [rsp+0x40], xmm5
000078f8213ddca7  vmovaps [rsp+0x50], xmm6
000078f8213ddcad  vmovaps [rsp+0x60], xmm7
000078f8213ddcb3  vmovaps [rsp+0x70], xmm8
000078f8213ddcb9  vmovaps [rsp+0x80], xmm9
000078f8213ddcc2  vmovaps [rsp+0x90], xmm10
000078f8213ddccb  vmovaps [rsp+0xA0], xmm11
000078f8213ddcd4  vmovaps [rsp+0xB0], xmm12
000078f8213ddcdd  vmovaps [rsp+0xC0], xmm13
000078f8213ddce6  vmovaps [rsp+0xD0], xmm14
000078f8213ddcef  vmovaps [rsp+0xE0], xmm15
000078f8213ddcf8  sub rsp, 0x30
000078f8213ddcfc  movaps [rsp], xmm1
000078f8213ddd00  movaps [rsp+0x10], xmm15
000078f8213ddd06  movaps [rsp+0x20], xmm9
000078f8213ddd0c  lea rdi, [rsp]
000078f8213ddd10  mov esi, 0x00
000078f8213ddd15  mov rax, 0x653D80F42530
000078f8213ddd1f  call rax
000078f8213ddd21  movaps xmm1, [rsp]
000078f8213ddd25  add rsp, 0x30
000078f8213ddd29  vmovaps xmm0, [rsp]
000078f8213ddd2e  vmovaps xmm2, [rsp+0x10]
000078f8213ddd34  vmovaps xmm3, [rsp+0x20]
000078f8213ddd3a  vmovaps xmm4, [rsp+0x30]
000078f8213ddd40  vmovaps xmm5, [rsp+0x40]
000078f8213ddd46  vmovaps xmm6, [rsp+0x50]
000078f8213ddd4c  vmovaps xmm7, [rsp+0x60]
000078f8213ddd52  vmovaps xmm8, [rsp+0x70]
000078f8213ddd58  vmovaps xmm9, [rsp+0x80]
000078f8213ddd61  vmovaps xmm10, [rsp+0x90]
000078f8213ddd6a  vmovaps xmm11, [rsp+0xA0]
000078f8213ddd73  vmovaps xmm12, [rsp+0xB0]
000078f8213ddd7c  vmovaps xmm13, [rsp+0xC0]
000078f8213ddd85  vmovaps xmm14, [rsp+0xD0]
000078f8213ddd8e  vmovaps xmm15, [rsp+0xE0]
000078f8213ddd97  add rsp, 0xF0
000078f8213ddd9e  pop r11
000078f8213ddda0  pop r10
000078f8213ddda2  pop r9
000078f8213ddda4  pop r8
000078f8213ddda6  pop rsi
000078f8213ddda7  pop rdi
000078f8213ddda8  pop rdx
000078f8213ddda9  pop rcx
000078f8213dddaa  pop rax
000078f8213dddab  add rsp, 0x08
000078f8213dddaf  jmp 0x000078F8213DBF7E
000078f8213dddb4  call 0x000078F8212C4620
000078f8213dddb9  jmp 0x000078F8213DBF8B
000078f8213dddbe  sub rsp, 0x08
000078f8213dddc2  push rax
000078f8213dddc3  push rcx
000078f8213dddc4  push rdx
000078f8213dddc5  push rdi
000078f8213dddc6  push rsi
000078f8213dddc7  push r8
000078f8213dddc9  push r9
000078f8213dddcb  push r10
000078f8213dddcd  push r11
000078f8213dddcf  sub rsp, 0xF0
000078f8213dddd6  vmovaps [rsp], xmm0
000078f8213ddddb  vmovaps [rsp+0x10], xmm2
000078f8213ddde1  vmovaps [rsp+0x20], xmm3
000078f8213ddde7  vmovaps [rsp+0x30], xmm4
000078f8213ddded  vmovaps [rsp+0x40], xmm5
000078f8213dddf3  vmovaps [rsp+0x50], xmm6
000078f8213dddf9  vmovaps [rsp+0x60], xmm7
000078f8213dddff  vmovaps [rsp+0x70], xmm8
000078f8213dde05  vmovaps [rsp+0x80], xmm9
000078f8213dde0e  vmovaps [rsp+0x90], xmm10
000078f8213dde17  vmovaps [rsp+0xA0], xmm11
000078f8213dde20  vmovaps [rsp+0xB0], xmm12
000078f8213dde29  vmovaps [rsp+0xC0], xmm13
000078f8213dde32  vmovaps [rsp+0xD0], xmm14
000078f8213dde3b  vmovaps [rsp+0xE0], xmm15
000078f8213dde44  sub rsp, 0x30
000078f8213dde48  movaps [rsp], xmm1
000078f8213dde4c  movaps [rsp+0x10], xmm5
000078f8213dde51  movaps [rsp+0x20], xmm7
000078f8213dde56  lea rdi, [rsp]
000078f8213dde5a  mov esi, 0x00
000078f8213dde5f  mov rax, 0x653D80F42530
000078f8213dde69  call rax
000078f8213dde6b  movaps xmm1, [rsp]
000078f8213dde6f  add rsp, 0x30
000078f8213dde73  vmovaps xmm0, [rsp]
000078f8213dde78  vmovaps xmm2, [rsp+0x10]
000078f8213dde7e  vmovaps xmm3, [rsp+0x20]
000078f8213dde84  vmovaps xmm4, [rsp+0x30]
000078f8213dde8a  vmovaps xmm5, [rsp+0x40]
000078f8213dde90  vmovaps xmm6, [rsp+0x50]
000078f8213dde96  vmovaps xmm7, [rsp+0x60]
000078f8213dde9c  vmovaps xmm8, [rsp+0x70]
000078f8213ddea2  vmovaps xmm9, [rsp+0x80]
000078f8213ddeab  vmovaps xmm10, [rsp+0x90]
000078f8213ddeb4  vmovaps xmm11, [rsp+0xA0]
000078f8213ddebd  vmovaps xmm12, [rsp+0xB0]
000078f8213ddec6  vmovaps xmm13, [rsp+0xC0]
000078f8213ddecf  vmovaps xmm14, [rsp+0xD0]
000078f8213dded8  vmovaps xmm15, [rsp+0xE0]
000078f8213ddee1  add rsp, 0xF0
000078f8213ddee8  pop r11
000078f8213ddeea  pop r10
000078f8213ddeec  pop r9
000078f8213ddeee  pop r8
000078f8213ddef0  pop rsi
000078f8213ddef1  pop rdi
000078f8213ddef2  pop rdx
000078f8213ddef3  pop rcx
000078f8213ddef4  pop rax
000078f8213ddef5  add rsp, 0x08
000078f8213ddef9  jmp 0x000078F8213DC030
000078f8213ddefe  sub rsp, 0x08
000078f8213ddf02  push rax
000078f8213ddf03  push rcx
000078f8213ddf04  push rdx
000078f8213ddf05  push rdi
000078f8213ddf06  push rsi
000078f8213ddf07  push r8
000078f8213ddf09  push r9
000078f8213ddf0b  push r10
000078f8213ddf0d  push r11
000078f8213ddf0f  sub rsp, 0xF0
000078f8213ddf16  vmovaps [rsp], xmm0
000078f8213ddf1b  vmovaps [rsp+0x10], xmm1
000078f8213ddf21  vmovaps [rsp+0x20], xmm2
000078f8213ddf27  vmovaps [rsp+0x30], xmm3
000078f8213ddf2d  vmovaps [rsp+0x40], xmm4
000078f8213ddf33  vmovaps [rsp+0x50], xmm5
000078f8213ddf39  vmovaps [rsp+0x60], xmm6
000078f8213ddf3f  vmovaps [rsp+0x70], xmm8
000078f8213ddf45  vmovaps [rsp+0x80], xmm9
000078f8213ddf4e  vmovaps [rsp+0x90], xmm10
000078f8213ddf57  vmovaps [rsp+0xA0], xmm11
000078f8213ddf60  vmovaps [rsp+0xB0], xmm12
000078f8213ddf69  vmovaps [rsp+0xC0], xmm13
000078f8213ddf72  vmovaps [rsp+0xD0], xmm14
000078f8213ddf7b  vmovaps [rsp+0xE0], xmm15
000078f8213ddf84  sub rsp, 0x30
000078f8213ddf88  movaps [rsp], xmm7
000078f8213ddf8c  movaps [rsp+0x10], xmm5
000078f8213ddf91  movaps [rsp+0x20], xmm15
000078f8213ddf97  lea rdi, [rsp]
000078f8213ddf9b  mov esi, 0x00
000078f8213ddfa0  mov rax, 0x653D80F42530
000078f8213ddfaa  call rax
000078f8213ddfac  movaps xmm7, [rsp]
000078f8213ddfb0  add rsp, 0x30
000078f8213ddfb4  vmovaps xmm0, [rsp]
000078f8213ddfb9  vmovaps xmm1, [rsp+0x10]
000078f8213ddfbf  vmovaps xmm2, [rsp+0x20]
000078f8213ddfc5  vmovaps xmm3, [rsp+0x30]
000078f8213ddfcb  vmovaps xmm4, [rsp+0x40]
000078f8213ddfd1  vmovaps xmm5, [rsp+0x50]
000078f8213ddfd7  vmovaps xmm6, [rsp+0x60]
000078f8213ddfdd  vmovaps xmm8, [rsp+0x70]
000078f8213ddfe3  vmovaps xmm9, [rsp+0x80]
000078f8213ddfec  vmovaps xmm10, [rsp+0x90]
000078f8213ddff5  vmovaps xmm11, [rsp+0xA0]
000078f8213ddffe  vmovaps xmm12, [rsp+0xB0]
000078f8213de007  vmovaps xmm13, [rsp+0xC0]
000078f8213de010  vmovaps xmm14, [rsp+0xD0]
000078f8213de019  vmovaps xmm15, [rsp+0xE0]
000078f8213de022  add rsp, 0xF0
000078f8213de029  pop r11
000078f8213de02b  pop r10
000078f8213de02d  pop r9
000078f8213de02f  pop r8
000078f8213de031  pop rsi
000078f8213de032  pop rdi
000078f8213de033  pop rdx
000078f8213de034  pop rcx
000078f8213de035  pop rax
000078f8213de036  add rsp, 0x08
000078f8213de03a  jmp 0x000078F8213DC066
000078f8213de03f  call 0x000078F8212B52F0
000078f8213de044  jmp 0x000078F8213DC073
000078f8213de049  sub rsp, 0x08
000078f8213de04d  push rax
000078f8213de04e  push rcx
000078f8213de04f  push rdx
000078f8213de050  push rdi
000078f8213de051  push rsi
000078f8213de052  push r8
000078f8213de054  push r9
000078f8213de056  push r10
000078f8213de058  push r11
000078f8213de05a  sub rsp, 0xF0
000078f8213de061  vmovaps [rsp], xmm0
000078f8213de066  vmovaps [rsp+0x10], xmm1
000078f8213de06c  vmovaps [rsp+0x20], xmm2
000078f8213de072  vmovaps [rsp+0x30], xmm3
000078f8213de078  vmovaps [rsp+0x40], xmm4
000078f8213de07e  vmovaps [rsp+0x50], xmm5
000078f8213de084  vmovaps [rsp+0x60], xmm6
000078f8213de08a  vmovaps [rsp+0x70], xmm7
000078f8213de090  vmovaps [rsp+0x80], xmm8
000078f8213de099  vmovaps [rsp+0x90], xmm9
000078f8213de0a2  vmovaps [rsp+0xA0], xmm10
000078f8213de0ab  vmovaps [rsp+0xB0], xmm11
000078f8213de0b4  vmovaps [rsp+0xC0], xmm12
000078f8213de0bd  vmovaps [rsp+0xD0], xmm13
000078f8213de0c6  vmovaps [rsp+0xE0], xmm14
000078f8213de0cf  sub rsp, 0x30
000078f8213de0d3  movaps [rsp], xmm15
000078f8213de0d8  movaps [rsp+0x10], xmm5
000078f8213de0dd  movaps [rsp+0x20], xmm3
000078f8213de0e2  lea rdi, [rsp]
000078f8213de0e6  mov esi, 0x00
000078f8213de0eb  mov rax, 0x653D80F42530
000078f8213de0f5  call rax
000078f8213de0f7  movaps xmm15, [rsp]
000078f8213de0fc  add rsp, 0x30
000078f8213de100  vmovaps xmm0, [rsp]
000078f8213de105  vmovaps xmm1, [rsp+0x10]
000078f8213de10b  vmovaps xmm2, [rsp+0x20]
000078f8213de111  vmovaps xmm3, [rsp+0x30]
000078f8213de117  vmovaps xmm4, [rsp+0x40]
000078f8213de11d  vmovaps xmm5, [rsp+0x50]
000078f8213de123  vmovaps xmm6, [rsp+0x60]
000078f8213de129  vmovaps xmm7, [rsp+0x70]
000078f8213de12f  vmovaps xmm8, [rsp+0x80]
000078f8213de138  vmovaps xmm9, [rsp+0x90]
000078f8213de141  vmovaps xmm10, [rsp+0xA0]
000078f8213de14a  vmovaps xmm11, [rsp+0xB0]
000078f8213de153  vmovaps xmm12, [rsp+0xC0]
000078f8213de15c  vmovaps xmm13, [rsp+0xD0]
000078f8213de165  vmovaps xmm14, [rsp+0xE0]
000078f8213de16e  add rsp, 0xF0
000078f8213de175  pop r11
000078f8213de177  pop r10
000078f8213de179  pop r9
000078f8213de17b  pop r8
000078f8213de17d  pop rsi
000078f8213de17e  pop rdi
000078f8213de17f  pop rdx
000078f8213de180  pop rcx
000078f8213de181  pop rax
000078f8213de182  add rsp, 0x08
000078f8213de186  jmp 0x000078F8213DC099
000078f8213de18b  sub rsp, 0x08
000078f8213de18f  push rax
000078f8213de190  push rcx
000078f8213de191  push rdx
000078f8213de192  push rdi
000078f8213de193  push rsi
000078f8213de194  push r8
000078f8213de196  push r9
000078f8213de198  push r10
000078f8213de19a  push r11
000078f8213de19c  sub rsp, 0xF0
000078f8213de1a3  vmovaps [rsp], xmm0
000078f8213de1a8  vmovaps [rsp+0x10], xmm2
000078f8213de1ae  vmovaps [rsp+0x20], xmm3
000078f8213de1b4  vmovaps [rsp+0x30], xmm4
000078f8213de1ba  vmovaps [rsp+0x40], xmm5
000078f8213de1c0  vmovaps [rsp+0x50], xmm6
000078f8213de1c6  vmovaps [rsp+0x60], xmm7
000078f8213de1cc  vmovaps [rsp+0x70], xmm8
000078f8213de1d2  vmovaps [rsp+0x80], xmm9
000078f8213de1db  vmovaps [rsp+0x90], xmm10
000078f8213de1e4  vmovaps [rsp+0xA0], xmm11
000078f8213de1ed  vmovaps [rsp+0xB0], xmm12
000078f8213de1f6  vmovaps [rsp+0xC0], xmm13
000078f8213de1ff  vmovaps [rsp+0xD0], xmm14
000078f8213de208  vmovaps [rsp+0xE0], xmm15
000078f8213de211  sub rsp, 0x30
000078f8213de215  movaps [rsp], xmm1
000078f8213de219  movaps [rsp+0x10], xmm5
000078f8213de21e  movaps [rsp+0x20], xmm4
000078f8213de223  lea rdi, [rsp]
000078f8213de227  mov esi, 0x00
000078f8213de22c  mov rax, 0x653D80F42530
000078f8213de236  call rax
000078f8213de238  movaps xmm1, [rsp]
000078f8213de23c  add rsp, 0x30
000078f8213de240  vmovaps xmm0, [rsp]
000078f8213de245  vmovaps xmm2, [rsp+0x10]
000078f8213de24b  vmovaps xmm3, [rsp+0x20]
000078f8213de251  vmovaps xmm4, [rsp+0x30]
000078f8213de257  vmovaps xmm5, [rsp+0x40]
000078f8213de25d  vmovaps xmm6, [rsp+0x50]
000078f8213de263  vmovaps xmm7, [rsp+0x60]
000078f8213de269  vmovaps xmm8, [rsp+0x70]
000078f8213de26f  vmovaps xmm9, [rsp+0x80]
000078f8213de278  vmovaps xmm10, [rsp+0x90]
000078f8213de281  vmovaps xmm11, [rsp+0xA0]
000078f8213de28a  vmovaps xmm12, [rsp+0xB0]
000078f8213de293  vmovaps xmm13, [rsp+0xC0]
000078f8213de29c  vmovaps xmm14, [rsp+0xD0]
000078f8213de2a5  vmovaps xmm15, [rsp+0xE0]
000078f8213de2ae  add rsp, 0xF0
000078f8213de2b5  pop r11
000078f8213de2b7  pop r10
000078f8213de2b9  pop r9
000078f8213de2bb  pop r8
000078f8213de2bd  pop rsi
000078f8213de2be  pop rdi
000078f8213de2bf  pop rdx
000078f8213de2c0  pop rcx
000078f8213de2c1  pop rax
000078f8213de2c2  add rsp, 0x08
000078f8213de2c6  jmp 0x000078F8213DC0B9
000078f8213de2cb  sub rsp, 0x08
000078f8213de2cf  push rax
000078f8213de2d0  push rcx
000078f8213de2d1  push rdx
000078f8213de2d2  push rdi
000078f8213de2d3  push rsi
000078f8213de2d4  push r8
000078f8213de2d6  push r9
000078f8213de2d8  push r10
000078f8213de2da  push r11
000078f8213de2dc  sub rsp, 0xF0
000078f8213de2e3  vmovaps [rsp], xmm0
000078f8213de2e8  vmovaps [rsp+0x10], xmm1
000078f8213de2ee  vmovaps [rsp+0x20], xmm2
000078f8213de2f4  vmovaps [rsp+0x30], xmm3
000078f8213de2fa  vmovaps [rsp+0x40], xmm5
000078f8213de300  vmovaps [rsp+0x50], xmm6
000078f8213de306  vmovaps [rsp+0x60], xmm7
000078f8213de30c  vmovaps [rsp+0x70], xmm8
000078f8213de312  vmovaps [rsp+0x80], xmm9
000078f8213de31b  vmovaps [rsp+0x90], xmm10
000078f8213de324  vmovaps [rsp+0xA0], xmm11
000078f8213de32d  vmovaps [rsp+0xB0], xmm12
000078f8213de336  vmovaps [rsp+0xC0], xmm13
000078f8213de33f  vmovaps [rsp+0xD0], xmm14
000078f8213de348  vmovaps [rsp+0xE0], xmm15
000078f8213de351  sub rsp, 0x30
000078f8213de355  movaps [rsp], xmm4
000078f8213de359  movaps [rsp+0x10], xmm3
000078f8213de35e  movaps [rsp+0x20], xmm5
000078f8213de363  lea rdi, [rsp]
000078f8213de367  mov esi, 0x00
000078f8213de36c  mov rax, 0x653D80F42530
000078f8213de376  call rax
000078f8213de378  movaps xmm4, [rsp]
000078f8213de37c  add rsp, 0x30
000078f8213de380  vmovaps xmm0, [rsp]
000078f8213de385  vmovaps xmm1, [rsp+0x10]
000078f8213de38b  vmovaps xmm2, [rsp+0x20]
000078f8213de391  vmovaps xmm3, [rsp+0x30]
000078f8213de397  vmovaps xmm5, [rsp+0x40]
000078f8213de39d  vmovaps xmm6, [rsp+0x50]
000078f8213de3a3  vmovaps xmm7, [rsp+0x60]
000078f8213de3a9  vmovaps xmm8, [rsp+0x70]
000078f8213de3af  vmovaps xmm9, [rsp+0x80]
000078f8213de3b8  vmovaps xmm10, [rsp+0x90]
000078f8213de3c1  vmovaps xmm11, [rsp+0xA0]
000078f8213de3ca  vmovaps xmm12, [rsp+0xB0]
000078f8213de3d3  vmovaps xmm13, [rsp+0xC0]
000078f8213de3dc  vmovaps xmm14, [rsp+0xD0]
000078f8213de3e5  vmovaps xmm15, [rsp+0xE0]
000078f8213de3ee  add rsp, 0xF0
000078f8213de3f5  pop r11
000078f8213de3f7  pop r10
000078f8213de3f9  pop r9
000078f8213de3fb  pop r8
000078f8213de3fd  pop rsi
000078f8213de3fe  pop rdi
000078f8213de3ff  pop rdx
000078f8213de400  pop rcx
000078f8213de401  pop rax
000078f8213de402  add rsp, 0x08
000078f8213de406  jmp 0x000078F8213DC107
000078f8213de40b  call 0x000078F8212B52F0
000078f8213de410  jmp 0x000078F8213DC114
000078f8213de415  sub rsp, 0x08
000078f8213de419  push rax
000078f8213de41a  push rcx
000078f8213de41b  push rdx
000078f8213de41c  push rdi
000078f8213de41d  push rsi
000078f8213de41e  push r8
000078f8213de420  push r9
000078f8213de422  push r10
000078f8213de424  push r11
000078f8213de426  sub rsp, 0xF0
000078f8213de42d  vmovaps [rsp], xmm0
000078f8213de432  vmovaps [rsp+0x10], xmm1
000078f8213de438  vmovaps [rsp+0x20], xmm2
000078f8213de43e  vmovaps [rsp+0x30], xmm3
000078f8213de444  vmovaps [rsp+0x40], xmm4
000078f8213de44a  vmovaps [rsp+0x50], xmm6
000078f8213de450  vmovaps [rsp+0x60], xmm7
000078f8213de456  vmovaps [rsp+0x70], xmm8
000078f8213de45c  vmovaps [rsp+0x80], xmm9
000078f8213de465  vmovaps [rsp+0x90], xmm10
000078f8213de46e  vmovaps [rsp+0xA0], xmm11
000078f8213de477  vmovaps [rsp+0xB0], xmm12
000078f8213de480  vmovaps [rsp+0xC0], xmm13
000078f8213de489  vmovaps [rsp+0xD0], xmm14
000078f8213de492  vmovaps [rsp+0xE0], xmm15
000078f8213de49b  sub rsp, 0x30
000078f8213de49f  movaps [rsp], xmm5
000078f8213de4a3  movaps [rsp+0x10], xmm6
000078f8213de4a8  movaps [rsp+0x20], xmm3
000078f8213de4ad  lea rdi, [rsp]
000078f8213de4b1  mov esi, 0x00
000078f8213de4b6  mov rax, 0x653D80F42530
000078f8213de4c0  call rax
000078f8213de4c2  movaps xmm5, [rsp]
000078f8213de4c6  add rsp, 0x30
000078f8213de4ca  vmovaps xmm0, [rsp]
000078f8213de4cf  vmovaps xmm1, [rsp+0x10]
000078f8213de4d5  vmovaps xmm2, [rsp+0x20]
000078f8213de4db  vmovaps xmm3, [rsp+0x30]
000078f8213de4e1  vmovaps xmm4, [rsp+0x40]
000078f8213de4e7  vmovaps xmm6, [rsp+0x50]
000078f8213de4ed  vmovaps xmm7, [rsp+0x60]
000078f8213de4f3  vmovaps xmm8, [rsp+0x70]
000078f8213de4f9  vmovaps xmm9, [rsp+0x80]
000078f8213de502  vmovaps xmm10, [rsp+0x90]
000078f8213de50b  vmovaps xmm11, [rsp+0xA0]
000078f8213de514  vmovaps xmm12, [rsp+0xB0]
000078f8213de51d  vmovaps xmm13, [rsp+0xC0]
000078f8213de526  vmovaps xmm14, [rsp+0xD0]
000078f8213de52f  vmovaps xmm15, [rsp+0xE0]
000078f8213de538  add rsp, 0xF0
000078f8213de53f  pop r11
000078f8213de541  pop r10
000078f8213de543  pop r9
000078f8213de545  pop r8
000078f8213de547  pop rsi
000078f8213de548  pop rdi
000078f8213de549  pop rdx
000078f8213de54a  pop rcx
000078f8213de54b  pop rax
000078f8213de54c  add rsp, 0x08
000078f8213de550  jmp 0x000078F8213DC13A
000078f8213de555  sub rsp, 0x08
000078f8213de559  push rax
000078f8213de55a  push rcx
000078f8213de55b  push rdx
000078f8213de55c  push rdi
000078f8213de55d  push rsi
000078f8213de55e  push r8
000078f8213de560  push r9
000078f8213de562  push r10
000078f8213de564  push r11
000078f8213de566  sub rsp, 0xF0
000078f8213de56d  vmovaps [rsp], xmm0
000078f8213de572  vmovaps [rsp+0x10], xmm1
000078f8213de578  vmovaps [rsp+0x20], xmm2
000078f8213de57e  vmovaps [rsp+0x30], xmm3
000078f8213de584  vmovaps [rsp+0x40], xmm4
000078f8213de58a  vmovaps [rsp+0x50], xmm5
000078f8213de590  vmovaps [rsp+0x60], xmm7
000078f8213de596  vmovaps [rsp+0x70], xmm8
000078f8213de59c  vmovaps [rsp+0x80], xmm9
000078f8213de5a5  vmovaps [rsp+0x90], xmm10
000078f8213de5ae  vmovaps [rsp+0xA0], xmm11
000078f8213de5b7  vmovaps [rsp+0xB0], xmm12
000078f8213de5c0  vmovaps [rsp+0xC0], xmm13
000078f8213de5c9  vmovaps [rsp+0xD0], xmm14
000078f8213de5d2  vmovaps [rsp+0xE0], xmm15
000078f8213de5db  sub rsp, 0x30
000078f8213de5df  movaps [rsp], xmm6
000078f8213de5e3  movaps [rsp+0x10], xmm9
000078f8213de5e9  movaps [rsp+0x20], xmm1
000078f8213de5ee  lea rdi, [rsp]
000078f8213de5f2  mov esi, 0x00
000078f8213de5f7  mov rax, 0x653D80F42530
000078f8213de601  call rax
000078f8213de603  movaps xmm6, [rsp]
000078f8213de607  add rsp, 0x30
000078f8213de60b  vmovaps xmm0, [rsp]
000078f8213de610  vmovaps xmm1, [rsp+0x10]
000078f8213de616  vmovaps xmm2, [rsp+0x20]
000078f8213de61c  vmovaps xmm3, [rsp+0x30]
000078f8213de622  vmovaps xmm4, [rsp+0x40]
000078f8213de628  vmovaps xmm5, [rsp+0x50]
000078f8213de62e  vmovaps xmm7, [rsp+0x60]
000078f8213de634  vmovaps xmm8, [rsp+0x70]
000078f8213de63a  vmovaps xmm9, [rsp+0x80]
000078f8213de643  vmovaps xmm10, [rsp+0x90]
000078f8213de64c  vmovaps xmm11, [rsp+0xA0]
000078f8213de655  vmovaps xmm12, [rsp+0xB0]
000078f8213de65e  vmovaps xmm13, [rsp+0xC0]
000078f8213de667  vmovaps xmm14, [rsp+0xD0]
000078f8213de670  vmovaps xmm15, [rsp+0xE0]
000078f8213de679  add rsp, 0xF0
000078f8213de680  pop r11
000078f8213de682  pop r10
000078f8213de684  pop r9
000078f8213de686  pop r8
000078f8213de688  pop rsi
000078f8213de689  pop rdi
000078f8213de68a  pop rdx
000078f8213de68b  pop rcx
000078f8213de68c  pop rax
000078f8213de68d  add rsp, 0x08
000078f8213de691  jmp 0x000078F8213DC15E
000078f8213de696  sub rsp, 0x08
000078f8213de69a  push rax
000078f8213de69b  push rcx
000078f8213de69c  push rdx
000078f8213de69d  push rdi
000078f8213de69e  push rsi
000078f8213de69f  push r8
000078f8213de6a1  push r9
000078f8213de6a3  push r10
000078f8213de6a5  push r11
000078f8213de6a7  sub rsp, 0xF0
000078f8213de6ae  vmovaps [rsp], xmm0
000078f8213de6b3  vmovaps [rsp+0x10], xmm1
000078f8213de6b9  vmovaps [rsp+0x20], xmm2
000078f8213de6bf  vmovaps [rsp+0x30], xmm3
000078f8213de6c5  vmovaps [rsp+0x40], xmm4
000078f8213de6cb  vmovaps [rsp+0x50], xmm5
000078f8213de6d1  vmovaps [rsp+0x60], xmm6
000078f8213de6d7  vmovaps [rsp+0x70], xmm7
000078f8213de6dd  vmovaps [rsp+0x80], xmm8
000078f8213de6e6  vmovaps [rsp+0x90], xmm10
000078f8213de6ef  vmovaps [rsp+0xA0], xmm11
000078f8213de6f8  vmovaps [rsp+0xB0], xmm12
000078f8213de701  vmovaps [rsp+0xC0], xmm13
000078f8213de70a  vmovaps [rsp+0xD0], xmm14
000078f8213de713  vmovaps [rsp+0xE0], xmm15
000078f8213de71c  sub rsp, 0x30
000078f8213de720  movaps [rsp], xmm9
000078f8213de725  movaps [rsp+0x10], xmm3
000078f8213de72a  movaps [rsp+0x20], xmm1
000078f8213de72f  lea rdi, [rsp]
000078f8213de733  mov esi, 0x00
000078f8213de738  mov rax, 0x653D80F42530
000078f8213de742  call rax
000078f8213de744  movaps xmm9, [rsp]
000078f8213de749  add rsp, 0x30
000078f8213de74d  vmovaps xmm0, [rsp]
000078f8213de752  vmovaps xmm1, [rsp+0x10]
000078f8213de758  vmovaps xmm2, [rsp+0x20]
000078f8213de75e  vmovaps xmm3, [rsp+0x30]
000078f8213de764  vmovaps xmm4, [rsp+0x40]
000078f8213de76a  vmovaps xmm5, [rsp+0x50]
000078f8213de770  vmovaps xmm6, [rsp+0x60]
000078f8213de776  vmovaps xmm7, [rsp+0x70]
000078f8213de77c  vmovaps xmm8, [rsp+0x80]
000078f8213de785  vmovaps xmm10, [rsp+0x90]
000078f8213de78e  vmovaps xmm11, [rsp+0xA0]
000078f8213de797  vmovaps xmm12, [rsp+0xB0]
000078f8213de7a0  vmovaps xmm13, [rsp+0xC0]
000078f8213de7a9  vmovaps xmm14, [rsp+0xD0]
000078f8213de7b2  vmovaps xmm15, [rsp+0xE0]
000078f8213de7bb  add rsp, 0xF0
000078f8213de7c2  pop r11
000078f8213de7c4  pop r10
000078f8213de7c6  pop r9
000078f8213de7c8  pop r8
000078f8213de7ca  pop rsi
000078f8213de7cb  pop rdi
000078f8213de7cc  pop rdx
000078f8213de7cd  pop rcx
000078f8213de7ce  pop rax
000078f8213de7cf  add rsp, 0x08
000078f8213de7d3  jmp 0x000078F8213DC1AA
000078f8213de7d8  call 0x000078F8212B52F0
000078f8213de7dd  jmp 0x000078F8213DC1B7
000078f8213de7e2  sub rsp, 0x08
000078f8213de7e6  push rax
000078f8213de7e7  push rcx
000078f8213de7e8  push rdx
000078f8213de7e9  push rdi
000078f8213de7ea  push rsi
000078f8213de7eb  push r8
000078f8213de7ed  push r9
000078f8213de7ef  push r10
000078f8213de7f1  push r11
000078f8213de7f3  sub rsp, 0xF0
000078f8213de7fa  vmovaps [rsp], xmm0
000078f8213de7ff  vmovaps [rsp+0x10], xmm1
000078f8213de805  vmovaps [rsp+0x20], xmm2
000078f8213de80b  vmovaps [rsp+0x30], xmm3
000078f8213de811  vmovaps [rsp+0x40], xmm4
000078f8213de817  vmovaps [rsp+0x50], xmm5
000078f8213de81d  vmovaps [rsp+0x60], xmm6
000078f8213de823  vmovaps [rsp+0x70], xmm7
000078f8213de829  vmovaps [rsp+0x80], xmm8
000078f8213de832  vmovaps [rsp+0x90], xmm9
000078f8213de83b  vmovaps [rsp+0xA0], xmm10
000078f8213de844  vmovaps [rsp+0xB0], xmm11
000078f8213de84d  vmovaps [rsp+0xC0], xmm12
000078f8213de856  vmovaps [rsp+0xD0], xmm13
000078f8213de85f  vmovaps [rsp+0xE0], xmm14
000078f8213de868  sub rsp, 0x30
000078f8213de86c  movaps [rsp], xmm15
000078f8213de871  movaps [rsp+0x10], xmm3
000078f8213de876  movaps [rsp+0x20], xmm7
000078f8213de87b  lea rdi, [rsp]
000078f8213de87f  mov esi, 0x00
000078f8213de884  mov rax, 0x653D80F42530
000078f8213de88e  call rax
000078f8213de890  movaps xmm15, [rsp]
000078f8213de895  add rsp, 0x30
000078f8213de899  vmovaps xmm0, [rsp]
000078f8213de89e  vmovaps xmm1, [rsp+0x10]
000078f8213de8a4  vmovaps xmm2, [rsp+0x20]
000078f8213de8aa  vmovaps xmm3, [rsp+0x30]
000078f8213de8b0  vmovaps xmm4, [rsp+0x40]
000078f8213de8b6  vmovaps xmm5, [rsp+0x50]
000078f8213de8bc  vmovaps xmm6, [rsp+0x60]
000078f8213de8c2  vmovaps xmm7, [rsp+0x70]
000078f8213de8c8  vmovaps xmm8, [rsp+0x80]
000078f8213de8d1  vmovaps xmm9, [rsp+0x90]
000078f8213de8da  vmovaps xmm10, [rsp+0xA0]
000078f8213de8e3  vmovaps xmm11, [rsp+0xB0]
000078f8213de8ec  vmovaps xmm12, [rsp+0xC0]
000078f8213de8f5  vmovaps xmm13, [rsp+0xD0]
000078f8213de8fe  vmovaps xmm14, [rsp+0xE0]
000078f8213de907  add rsp, 0xF0
000078f8213de90e  pop r11
000078f8213de910  pop r10
000078f8213de912  pop r9
000078f8213de914  pop r8
000078f8213de916  pop rsi
000078f8213de917  pop rdi
000078f8213de918  pop rdx
000078f8213de919  pop rcx
000078f8213de91a  pop rax
000078f8213de91b  add rsp, 0x08
000078f8213de91f  jmp 0x000078F8213DC1E3
000078f8213de924  sub rsp, 0x08
000078f8213de928  push rax
000078f8213de929  push rcx
000078f8213de92a  push rdx
000078f8213de92b  push rdi
000078f8213de92c  push rsi
000078f8213de92d  push r8
000078f8213de92f  push r9
000078f8213de931  push r10
000078f8213de933  push r11
000078f8213de935  sub rsp, 0xF0
000078f8213de93c  vmovaps [rsp], xmm0
000078f8213de941  vmovaps [rsp+0x10], xmm1
000078f8213de947  vmovaps [rsp+0x20], xmm2
000078f8213de94d  vmovaps [rsp+0x30], xmm4
000078f8213de953  vmovaps [rsp+0x40], xmm5
000078f8213de959  vmovaps [rsp+0x50], xmm6
000078f8213de95f  vmovaps [rsp+0x60], xmm7
000078f8213de965  vmovaps [rsp+0x70], xmm8
000078f8213de96b  vmovaps [rsp+0x80], xmm9
000078f8213de974  vmovaps [rsp+0x90], xmm10
000078f8213de97d  vmovaps [rsp+0xA0], xmm11
000078f8213de986  vmovaps [rsp+0xB0], xmm12
000078f8213de98f  vmovaps [rsp+0xC0], xmm13
000078f8213de998  vmovaps [rsp+0xD0], xmm14
000078f8213de9a1  vmovaps [rsp+0xE0], xmm15
000078f8213de9aa  sub rsp, 0x30
000078f8213de9ae  movaps [rsp], xmm3
000078f8213de9b2  movaps [rsp+0x10], xmm1
000078f8213de9b7  movaps [rsp+0x20], xmm15
000078f8213de9bd  lea rdi, [rsp]
000078f8213de9c1  mov esi, 0x00
000078f8213de9c6  mov rax, 0x653D80F42530
000078f8213de9d0  call rax
000078f8213de9d2  movaps xmm3, [rsp]
000078f8213de9d6  add rsp, 0x30
000078f8213de9da  vmovaps xmm0, [rsp]
000078f8213de9df  vmovaps xmm1, [rsp+0x10]
000078f8213de9e5  vmovaps xmm2, [rsp+0x20]
000078f8213de9eb  vmovaps xmm4, [rsp+0x30]
000078f8213de9f1  vmovaps xmm5, [rsp+0x40]
000078f8213de9f7  vmovaps xmm6, [rsp+0x50]
000078f8213de9fd  vmovaps xmm7, [rsp+0x60]
000078f8213dea03  vmovaps xmm8, [rsp+0x70]
000078f8213dea09  vmovaps xmm9, [rsp+0x80]
000078f8213dea12  vmovaps xmm10, [rsp+0x90]
000078f8213dea1b  vmovaps xmm11, [rsp+0xA0]
000078f8213dea24  vmovaps xmm12, [rsp+0xB0]
000078f8213dea2d  vmovaps xmm13, [rsp+0xC0]
000078f8213dea36  vmovaps xmm14, [rsp+0xD0]
000078f8213dea3f  vmovaps xmm15, [rsp+0xE0]
000078f8213dea48  add rsp, 0xF0
000078f8213dea4f  pop r11
000078f8213dea51  pop r10
000078f8213dea53  pop r9
000078f8213dea55  pop r8
000078f8213dea57  pop rsi
000078f8213dea58  pop rdi
000078f8213dea59  pop rdx
000078f8213dea5a  pop rcx
000078f8213dea5b  pop rax
000078f8213dea5c  add rsp, 0x08
000078f8213dea60  jmp 0x000078F8213DC272
000078f8213dea65  call 0x000078F8212B52F0
000078f8213dea6a  jmp 0x000078F8213DC27C
000078f8213dea6f  sub rsp, 0x08
000078f8213dea73  push rax
000078f8213dea74  push rcx
000078f8213dea75  push rdx
000078f8213dea76  push rdi
000078f8213dea77  push rsi
000078f8213dea78  push r8
000078f8213dea7a  push r9
000078f8213dea7c  push r10
000078f8213dea7e  push r11
000078f8213dea80  sub rsp, 0xF0
000078f8213dea87  vmovaps [rsp], xmm0
000078f8213dea8c  vmovaps [rsp+0x10], xmm1
000078f8213dea92  vmovaps [rsp+0x20], xmm2
000078f8213dea98  vmovaps [rsp+0x30], xmm3
000078f8213dea9e  vmovaps [rsp+0x40], xmm4
000078f8213deaa4  vmovaps [rsp+0x50], xmm5
000078f8213deaaa  vmovaps [rsp+0x60], xmm6
000078f8213deab0  vmovaps [rsp+0x70], xmm7
000078f8213deab6  vmovaps [rsp+0x80], xmm8
000078f8213deabf  vmovaps [rsp+0x90], xmm9
000078f8213deac8  vmovaps [rsp+0xA0], xmm10
000078f8213dead1  vmovaps [rsp+0xB0], xmm11
000078f8213deada  vmovaps [rsp+0xC0], xmm12
000078f8213deae3  vmovaps [rsp+0xD0], xmm13
000078f8213deaec  vmovaps [rsp+0xE0], xmm14
000078f8213deaf5  sub rsp, 0x30
000078f8213deaf9  movaps [rsp], xmm15
000078f8213deafe  movaps [rsp+0x10], xmm14
000078f8213deb04  movaps [rsp+0x20], xmm4
000078f8213deb09  lea rdi, [rsp]
000078f8213deb0d  mov esi, 0x00
000078f8213deb12  mov rax, 0x653D80F42530
000078f8213deb1c  call rax
000078f8213deb1e  movaps xmm15, [rsp]
000078f8213deb23  add rsp, 0x30
000078f8213deb27  vmovaps xmm0, [rsp]
000078f8213deb2c  vmovaps xmm1, [rsp+0x10]
000078f8213deb32  vmovaps xmm2, [rsp+0x20]
000078f8213deb38  vmovaps xmm3, [rsp+0x30]
000078f8213deb3e  vmovaps xmm4, [rsp+0x40]
000078f8213deb44  vmovaps xmm5, [rsp+0x50]
000078f8213deb4a  vmovaps xmm6, [rsp+0x60]
000078f8213deb50  vmovaps xmm7, [rsp+0x70]
000078f8213deb56  vmovaps xmm8, [rsp+0x80]
000078f8213deb5f  vmovaps xmm9, [rsp+0x90]
000078f8213deb68  vmovaps xmm10, [rsp+0xA0]
000078f8213deb71  vmovaps xmm11, [rsp+0xB0]
000078f8213deb7a  vmovaps xmm12, [rsp+0xC0]
000078f8213deb83  vmovaps xmm13, [rsp+0xD0]
000078f8213deb8c  vmovaps xmm14, [rsp+0xE0]
000078f8213deb95  add rsp, 0xF0
000078f8213deb9c  pop r11
000078f8213deb9e  pop r10
000078f8213deba0  pop r9
000078f8213deba2  pop r8
000078f8213deba4  pop rsi
000078f8213deba5  pop rdi
000078f8213deba6  pop rdx
000078f8213deba7  pop rcx
000078f8213deba8  pop rax
000078f8213deba9  add rsp, 0x08
000078f8213debad  jmp 0x000078F8213DC2AA
000078f8213debb2  sub rsp, 0x08
000078f8213debb6  push rax
000078f8213debb7  push rcx
000078f8213debb8  push rdx
000078f8213debb9  push rdi
000078f8213debba  push rsi
000078f8213debbb  push r8
000078f8213debbd  push r9
000078f8213debbf  push r10
000078f8213debc1  push r11
000078f8213debc3  sub rsp, 0xF0
000078f8213debca  vmovaps [rsp], xmm0
000078f8213debcf  vmovaps [rsp+0x10], xmm1
000078f8213debd5  vmovaps [rsp+0x20], xmm2
000078f8213debdb  vmovaps [rsp+0x30], xmm3
000078f8213debe1  vmovaps [rsp+0x40], xmm4
000078f8213debe7  vmovaps [rsp+0x50], xmm5
000078f8213debed  vmovaps [rsp+0x60], xmm6
000078f8213debf3  vmovaps [rsp+0x70], xmm7
000078f8213debf9  vmovaps [rsp+0x80], xmm8
000078f8213dec02  vmovaps [rsp+0x90], xmm9
000078f8213dec0b  vmovaps [rsp+0xA0], xmm10
000078f8213dec14  vmovaps [rsp+0xB0], xmm11
000078f8213dec1d  vmovaps [rsp+0xC0], xmm12
000078f8213dec26  vmovaps [rsp+0xD0], xmm13
000078f8213dec2f  vmovaps [rsp+0xE0], xmm15
000078f8213dec38  sub rsp, 0x30
000078f8213dec3c  movaps [rsp], xmm14
000078f8213dec41  movaps [rsp+0x10], xmm2
000078f8213dec46  movaps [rsp+0x20], xmm1
000078f8213dec4b  lea rdi, [rsp]
000078f8213dec4f  mov esi, 0x00
000078f8213dec54  mov rax, 0x653D80F42530
000078f8213dec5e  call rax
000078f8213dec60  movaps xmm14, [rsp]
000078f8213dec65  add rsp, 0x30
000078f8213dec69  vmovaps xmm0, [rsp]
000078f8213dec6e  vmovaps xmm1, [rsp+0x10]
000078f8213dec74  vmovaps xmm2, [rsp+0x20]
000078f8213dec7a  vmovaps xmm3, [rsp+0x30]
000078f8213dec80  vmovaps xmm4, [rsp+0x40]
000078f8213dec86  vmovaps xmm5, [rsp+0x50]
000078f8213dec8c  vmovaps xmm6, [rsp+0x60]
000078f8213dec92  vmovaps xmm7, [rsp+0x70]
000078f8213dec98  vmovaps xmm8, [rsp+0x80]
000078f8213deca1  vmovaps xmm9, [rsp+0x90]
000078f8213decaa  vmovaps xmm10, [rsp+0xA0]
000078f8213decb3  vmovaps xmm11, [rsp+0xB0]
000078f8213decbc  vmovaps xmm12, [rsp+0xC0]
000078f8213decc5  vmovaps xmm13, [rsp+0xD0]
000078f8213decce  vmovaps xmm15, [rsp+0xE0]
000078f8213decd7  add rsp, 0xF0
000078f8213decde  pop r11
000078f8213dece0  pop r10
000078f8213dece2  pop r9
000078f8213dece4  pop r8
000078f8213dece6  pop rsi
000078f8213dece7  pop rdi
000078f8213dece8  pop rdx
000078f8213dece9  pop rcx
000078f8213decea  pop rax
000078f8213deceb  add rsp, 0x08
000078f8213decef  jmp 0x000078F8213DC2D0
000078f8213decf4  sub rsp, 0x08
000078f8213decf8  push rax
000078f8213decf9  push rcx
000078f8213decfa  push rdx
000078f8213decfb  push rdi
000078f8213decfc  push rsi
000078f8213decfd  push r8
000078f8213decff  push r9
000078f8213ded01  push r10
000078f8213ded03  push r11
000078f8213ded05  sub rsp, 0xF0
000078f8213ded0c  vmovaps [rsp], xmm0
000078f8213ded11  vmovaps [rsp+0x10], xmm2
000078f8213ded17  vmovaps [rsp+0x20], xmm3
000078f8213ded1d  vmovaps [rsp+0x30], xmm4
000078f8213ded23  vmovaps [rsp+0x40], xmm5
000078f8213ded29  vmovaps [rsp+0x50], xmm6
000078f8213ded2f  vmovaps [rsp+0x60], xmm7
000078f8213ded35  vmovaps [rsp+0x70], xmm8
000078f8213ded3b  vmovaps [rsp+0x80], xmm9
000078f8213ded44  vmovaps [rsp+0x90], xmm10
000078f8213ded4d  vmovaps [rsp+0xA0], xmm11
000078f8213ded56  vmovaps [rsp+0xB0], xmm12
000078f8213ded5f  vmovaps [rsp+0xC0], xmm13
000078f8213ded68  vmovaps [rsp+0xD0], xmm14
000078f8213ded71  vmovaps [rsp+0xE0], xmm15
000078f8213ded7a  sub rsp, 0x30
000078f8213ded7e  movaps [rsp], xmm1
000078f8213ded82  movaps [rsp+0x10], xmm4
000078f8213ded87  movaps [rsp+0x20], xmm9
000078f8213ded8d  lea rdi, [rsp]
000078f8213ded91  mov esi, 0x00
000078f8213ded96  mov rax, 0x653D80F42530
000078f8213deda0  call rax
000078f8213deda2  movaps xmm1, [rsp]
000078f8213deda6  add rsp, 0x30
000078f8213dedaa  vmovaps xmm0, [rsp]
000078f8213dedaf  vmovaps xmm2, [rsp+0x10]
000078f8213dedb5  vmovaps xmm3, [rsp+0x20]
000078f8213dedbb  vmovaps xmm4, [rsp+0x30]
000078f8213dedc1  vmovaps xmm5, [rsp+0x40]
000078f8213dedc7  vmovaps xmm6, [rsp+0x50]
000078f8213dedcd  vmovaps xmm7, [rsp+0x60]
000078f8213dedd3  vmovaps xmm8, [rsp+0x70]
000078f8213dedd9  vmovaps xmm9, [rsp+0x80]
000078f8213dede2  vmovaps xmm10, [rsp+0x90]
000078f8213dedeb  vmovaps xmm11, [rsp+0xA0]
000078f8213dedf4  vmovaps xmm12, [rsp+0xB0]
000078f8213dedfd  vmovaps xmm13, [rsp+0xC0]
000078f8213dee06  vmovaps xmm14, [rsp+0xD0]
000078f8213dee0f  vmovaps xmm15, [rsp+0xE0]
000078f8213dee18  add rsp, 0xF0
000078f8213dee1f  pop r11
000078f8213dee21  pop r10
000078f8213dee23  pop r9
000078f8213dee25  pop r8
000078f8213dee27  pop rsi
000078f8213dee28  pop rdi
000078f8213dee29  pop rdx
000078f8213dee2a  pop rcx
000078f8213dee2b  pop rax
000078f8213dee2c  add rsp, 0x08
000078f8213dee30  jmp 0x000078F8213DC2EE
000078f8213dee35  sub rsp, 0x08
000078f8213dee39  push rax
000078f8213dee3a  push rcx
000078f8213dee3b  push rdx
000078f8213dee3c  push rdi
000078f8213dee3d  push rsi
000078f8213dee3e  push r8
000078f8213dee40  push r9
000078f8213dee42  push r10
000078f8213dee44  push r11
000078f8213dee46  sub rsp, 0xF0
000078f8213dee4d  vmovaps [rsp], xmm0
000078f8213dee52  vmovaps [rsp+0x10], xmm1
000078f8213dee58  vmovaps [rsp+0x20], xmm2
000078f8213dee5e  vmovaps [rsp+0x30], xmm3
000078f8213dee64  vmovaps [rsp+0x40], xmm5
000078f8213dee6a  vmovaps [rsp+0x50], xmm6
000078f8213dee70  vmovaps [rsp+0x60], xmm7
000078f8213dee76  vmovaps [rsp+0x70], xmm8
000078f8213dee7c  vmovaps [rsp+0x80], xmm9
000078f8213dee85  vmovaps [rsp+0x90], xmm10
000078f8213dee8e  vmovaps [rsp+0xA0], xmm11
000078f8213dee97  vmovaps [rsp+0xB0], xmm12
000078f8213deea0  vmovaps [rsp+0xC0], xmm13
000078f8213deea9  vmovaps [rsp+0xD0], xmm14
000078f8213deeb2  vmovaps [rsp+0xE0], xmm15
000078f8213deebb  sub rsp, 0x30
000078f8213deebf  movaps [rsp], xmm4
000078f8213deec3  movaps [rsp+0x10], xmm2
000078f8213deec8  movaps [rsp+0x20], xmm9
000078f8213deece  lea rdi, [rsp]
000078f8213deed2  mov esi, 0x00
000078f8213deed7  mov rax, 0x653D80F42530
000078f8213deee1  call rax
000078f8213deee3  movaps xmm4, [rsp]
000078f8213deee7  add rsp, 0x30
000078f8213deeeb  vmovaps xmm0, [rsp]
000078f8213deef0  vmovaps xmm1, [rsp+0x10]
000078f8213deef6  vmovaps xmm2, [rsp+0x20]
000078f8213deefc  vmovaps xmm3, [rsp+0x30]
000078f8213def02  vmovaps xmm5, [rsp+0x40]
000078f8213def08  vmovaps xmm6, [rsp+0x50]
000078f8213def0e  vmovaps xmm7, [rsp+0x60]
000078f8213def14  vmovaps xmm8, [rsp+0x70]
000078f8213def1a  vmovaps xmm9, [rsp+0x80]
000078f8213def23  vmovaps xmm10, [rsp+0x90]
000078f8213def2c  vmovaps xmm11, [rsp+0xA0]
000078f8213def35  vmovaps xmm12, [rsp+0xB0]
000078f8213def3e  vmovaps xmm13, [rsp+0xC0]
000078f8213def47  vmovaps xmm14, [rsp+0xD0]
000078f8213def50  vmovaps xmm15, [rsp+0xE0]
000078f8213def59  add rsp, 0xF0
000078f8213def60  pop r11
000078f8213def62  pop r10
000078f8213def64  pop r9
000078f8213def66  pop r8
000078f8213def68  pop rsi
000078f8213def69  pop rdi
000078f8213def6a  pop rdx
000078f8213def6b  pop rcx
000078f8213def6c  pop rax
000078f8213def6d  add rsp, 0x08
000078f8213def71  jmp 0x000078F8213DC31E
000078f8213def76  sub rsp, 0x08
000078f8213def7a  push rax
000078f8213def7b  push rcx
000078f8213def7c  push rdx
000078f8213def7d  push rdi
000078f8213def7e  push rsi
000078f8213def7f  push r8
000078f8213def81  push r9
000078f8213def83  push r10
000078f8213def85  push r11
000078f8213def87  sub rsp, 0xF0
000078f8213def8e  vmovaps [rsp], xmm0
000078f8213def93  vmovaps [rsp+0x10], xmm1
000078f8213def99  vmovaps [rsp+0x20], xmm2
000078f8213def9f  vmovaps [rsp+0x30], xmm3
000078f8213defa5  vmovaps [rsp+0x40], xmm4
000078f8213defab  vmovaps [rsp+0x50], xmm5
000078f8213defb1  vmovaps [rsp+0x60], xmm6
000078f8213defb7  vmovaps [rsp+0x70], xmm7
000078f8213defbd  vmovaps [rsp+0x80], xmm8
000078f8213defc6  vmovaps [rsp+0x90], xmm10
000078f8213defcf  vmovaps [rsp+0xA0], xmm11
000078f8213defd8  vmovaps [rsp+0xB0], xmm12
000078f8213defe1  vmovaps [rsp+0xC0], xmm13
000078f8213defea  vmovaps [rsp+0xD0], xmm14
000078f8213deff3  vmovaps [rsp+0xE0], xmm15
000078f8213deffc  sub rsp, 0x30
000078f8213df000  movaps [rsp], xmm9
000078f8213df005  movaps [rsp+0x10], xmm2
000078f8213df00a  movaps [rsp+0x20], xmm1
000078f8213df00f  lea rdi, [rsp]
000078f8213df013  mov esi, 0x00
000078f8213df018  mov rax, 0x653D80F42530
000078f8213df022  call rax
000078f8213df024  movaps xmm9, [rsp]
000078f8213df029  add rsp, 0x30
000078f8213df02d  vmovaps xmm0, [rsp]
000078f8213df032  vmovaps xmm1, [rsp+0x10]
000078f8213df038  vmovaps xmm2, [rsp+0x20]
000078f8213df03e  vmovaps xmm3, [rsp+0x30]
000078f8213df044  vmovaps xmm4, [rsp+0x40]
000078f8213df04a  vmovaps xmm5, [rsp+0x50]
000078f8213df050  vmovaps xmm6, [rsp+0x60]
000078f8213df056  vmovaps xmm7, [rsp+0x70]
000078f8213df05c  vmovaps xmm8, [rsp+0x80]
000078f8213df065  vmovaps xmm10, [rsp+0x90]
000078f8213df06e  vmovaps xmm11, [rsp+0xA0]
000078f8213df077  vmovaps xmm12, [rsp+0xB0]
000078f8213df080  vmovaps xmm13, [rsp+0xC0]
000078f8213df089  vmovaps xmm14, [rsp+0xD0]
000078f8213df092  vmovaps xmm15, [rsp+0xE0]
000078f8213df09b  add rsp, 0xF0
000078f8213df0a2  pop r11
000078f8213df0a4  pop r10
000078f8213df0a6  pop r9
000078f8213df0a8  pop r8
000078f8213df0aa  pop rsi
000078f8213df0ab  pop rdi
000078f8213df0ac  pop rdx
000078f8213df0ad  pop rcx
000078f8213df0ae  pop rax
000078f8213df0af  add rsp, 0x08
000078f8213df0b3  jmp 0x000078F8213DC354
000078f8213df0b8  sub rsp, 0x08
000078f8213df0bc  push rax
000078f8213df0bd  push rcx
000078f8213df0be  push rdx
000078f8213df0bf  push rdi
000078f8213df0c0  push rsi
000078f8213df0c1  push r8
000078f8213df0c3  push r9
000078f8213df0c5  push r10
000078f8213df0c7  push r11
000078f8213df0c9  sub rsp, 0xF0
000078f8213df0d0  vmovaps [rsp], xmm0
000078f8213df0d5  vmovaps [rsp+0x10], xmm2
000078f8213df0db  vmovaps [rsp+0x20], xmm3
000078f8213df0e1  vmovaps [rsp+0x30], xmm4
000078f8213df0e7  vmovaps [rsp+0x40], xmm5
000078f8213df0ed  vmovaps [rsp+0x50], xmm6
000078f8213df0f3  vmovaps [rsp+0x60], xmm7
000078f8213df0f9  vmovaps [rsp+0x70], xmm8
000078f8213df0ff  vmovaps [rsp+0x80], xmm9
000078f8213df108  vmovaps [rsp+0x90], xmm10
000078f8213df111  vmovaps [rsp+0xA0], xmm11
000078f8213df11a  vmovaps [rsp+0xB0], xmm12
000078f8213df123  vmovaps [rsp+0xC0], xmm13
000078f8213df12c  vmovaps [rsp+0xD0], xmm14
000078f8213df135  vmovaps [rsp+0xE0], xmm15
000078f8213df13e  sub rsp, 0x30
000078f8213df142  movaps [rsp], xmm1
000078f8213df146  movaps [rsp+0x10], xmm15
000078f8213df14c  movaps [rsp+0x20], xmm6
000078f8213df151  lea rdi, [rsp]
000078f8213df155  mov esi, 0x00
000078f8213df15a  mov rax, 0x653D80F42530
000078f8213df164  call rax
000078f8213df166  movaps xmm1, [rsp]
000078f8213df16a  add rsp, 0x30
000078f8213df16e  vmovaps xmm0, [rsp]
000078f8213df173  vmovaps xmm2, [rsp+0x10]
000078f8213df179  vmovaps xmm3, [rsp+0x20]
000078f8213df17f  vmovaps xmm4, [rsp+0x30]
000078f8213df185  vmovaps xmm5, [rsp+0x40]
000078f8213df18b  vmovaps xmm6, [rsp+0x50]
000078f8213df191  vmovaps xmm7, [rsp+0x60]
000078f8213df197  vmovaps xmm8, [rsp+0x70]
000078f8213df19d  vmovaps xmm9, [rsp+0x80]
000078f8213df1a6  vmovaps xmm10, [rsp+0x90]
000078f8213df1af  vmovaps xmm11, [rsp+0xA0]
000078f8213df1b8  vmovaps xmm12, [rsp+0xB0]
000078f8213df1c1  vmovaps xmm13, [rsp+0xC0]
000078f8213df1ca  vmovaps xmm14, [rsp+0xD0]
000078f8213df1d3  vmovaps xmm15, [rsp+0xE0]
000078f8213df1dc  add rsp, 0xF0
000078f8213df1e3  pop r11
000078f8213df1e5  pop r10
000078f8213df1e7  pop r9
000078f8213df1e9  pop r8
000078f8213df1eb  pop rsi
000078f8213df1ec  pop rdi
000078f8213df1ed  pop rdx
000078f8213df1ee  pop rcx
000078f8213df1ef  pop rax
000078f8213df1f0  add rsp, 0x08
000078f8213df1f4  jmp 0x000078F8213DC375
000078f8213df1f9  sub rsp, 0x08
000078f8213df1fd  push rax
000078f8213df1fe  push rcx
000078f8213df1ff  push rdx
000078f8213df200  push rdi
000078f8213df201  push rsi
000078f8213df202  push r8
000078f8213df204  push r9
000078f8213df206  push r10
000078f8213df208  push r11
000078f8213df20a  sub rsp, 0xF0
000078f8213df211  vmovaps [rsp], xmm0
000078f8213df216  vmovaps [rsp+0x10], xmm1
000078f8213df21c  vmovaps [rsp+0x20], xmm2
000078f8213df222  vmovaps [rsp+0x30], xmm3
000078f8213df228  vmovaps [rsp+0x40], xmm4
000078f8213df22e  vmovaps [rsp+0x50], xmm5
000078f8213df234  vmovaps [rsp+0x60], xmm6
000078f8213df23a  vmovaps [rsp+0x70], xmm7
000078f8213df240  vmovaps [rsp+0x80], xmm8
000078f8213df249  vmovaps [rsp+0x90], xmm9
000078f8213df252  vmovaps [rsp+0xA0], xmm10
000078f8213df25b  vmovaps [rsp+0xB0], xmm11
000078f8213df264  vmovaps [rsp+0xC0], xmm12
000078f8213df26d  vmovaps [rsp+0xD0], xmm13
000078f8213df276  vmovaps [rsp+0xE0], xmm14
000078f8213df27f  sub rsp, 0x30
000078f8213df283  movaps [rsp], xmm15
000078f8213df288  movaps [rsp+0x10], xmm5
000078f8213df28d  movaps [rsp+0x20], xmm3
000078f8213df292  lea rdi, [rsp]
000078f8213df296  mov esi, 0x00
000078f8213df29b  mov rax, 0x653D80F42530
000078f8213df2a5  call rax
000078f8213df2a7  movaps xmm15, [rsp]
000078f8213df2ac  add rsp, 0x30
000078f8213df2b0  vmovaps xmm0, [rsp]
000078f8213df2b5  vmovaps xmm1, [rsp+0x10]
000078f8213df2bb  vmovaps xmm2, [rsp+0x20]
000078f8213df2c1  vmovaps xmm3, [rsp+0x30]
000078f8213df2c7  vmovaps xmm4, [rsp+0x40]
000078f8213df2cd  vmovaps xmm5, [rsp+0x50]
000078f8213df2d3  vmovaps xmm6, [rsp+0x60]
000078f8213df2d9  vmovaps xmm7, [rsp+0x70]
000078f8213df2df  vmovaps xmm8, [rsp+0x80]
000078f8213df2e8  vmovaps xmm9, [rsp+0x90]
000078f8213df2f1  vmovaps xmm10, [rsp+0xA0]
000078f8213df2fa  vmovaps xmm11, [rsp+0xB0]
000078f8213df303  vmovaps xmm12, [rsp+0xC0]
000078f8213df30c  vmovaps xmm13, [rsp+0xD0]
000078f8213df315  vmovaps xmm14, [rsp+0xE0]
000078f8213df31e  add rsp, 0xF0
000078f8213df325  pop r11
000078f8213df327  pop r10
000078f8213df329  pop r9
000078f8213df32b  pop r8
000078f8213df32d  pop rsi
000078f8213df32e  pop rdi
000078f8213df32f  pop rdx
000078f8213df330  pop rcx
000078f8213df331  pop rax
000078f8213df332  add rsp, 0x08
000078f8213df336  jmp 0x000078F8213DC38F
000078f8213df33b  sub rsp, 0x08
000078f8213df33f  push rax
000078f8213df340  push rcx
000078f8213df341  push rdx
000078f8213df342  push rdi
000078f8213df343  push rsi
000078f8213df344  push r8
000078f8213df346  push r9
000078f8213df348  push r10
000078f8213df34a  push r11
000078f8213df34c  sub rsp, 0xF0
000078f8213df353  vmovaps [rsp], xmm0
000078f8213df358  vmovaps [rsp+0x10], xmm1
000078f8213df35e  vmovaps [rsp+0x20], xmm2
000078f8213df364  vmovaps [rsp+0x30], xmm3
000078f8213df36a  vmovaps [rsp+0x40], xmm4
000078f8213df370  vmovaps [rsp+0x50], xmm6
000078f8213df376  vmovaps [rsp+0x60], xmm7
000078f8213df37c  vmovaps [rsp+0x70], xmm8
000078f8213df382  vmovaps [rsp+0x80], xmm9
000078f8213df38b  vmovaps [rsp+0x90], xmm10
000078f8213df394  vmovaps [rsp+0xA0], xmm11
000078f8213df39d  vmovaps [rsp+0xB0], xmm12
000078f8213df3a6  vmovaps [rsp+0xC0], xmm13
000078f8213df3af  vmovaps [rsp+0xD0], xmm14
000078f8213df3b8  vmovaps [rsp+0xE0], xmm15
000078f8213df3c1  sub rsp, 0x30
000078f8213df3c5  movaps [rsp], xmm5
000078f8213df3c9  movaps [rsp+0x10], xmm8
000078f8213df3cf  movaps [rsp+0x20], xmm6
000078f8213df3d4  lea rdi, [rsp]
000078f8213df3d8  mov esi, 0x00
000078f8213df3dd  mov rax, 0x653D80F42530
000078f8213df3e7  call rax
000078f8213df3e9  movaps xmm5, [rsp]
000078f8213df3ed  add rsp, 0x30
000078f8213df3f1  vmovaps xmm0, [rsp]
000078f8213df3f6  vmovaps xmm1, [rsp+0x10]
000078f8213df3fc  vmovaps xmm2, [rsp+0x20]
000078f8213df402  vmovaps xmm3, [rsp+0x30]
000078f8213df408  vmovaps xmm4, [rsp+0x40]
000078f8213df40e  vmovaps xmm6, [rsp+0x50]
000078f8213df414  vmovaps xmm7, [rsp+0x60]
000078f8213df41a  vmovaps xmm8, [rsp+0x70]
000078f8213df420  vmovaps xmm9, [rsp+0x80]
000078f8213df429  vmovaps xmm10, [rsp+0x90]
000078f8213df432  vmovaps xmm11, [rsp+0xA0]
000078f8213df43b  vmovaps xmm12, [rsp+0xB0]
000078f8213df444  vmovaps xmm13, [rsp+0xC0]
000078f8213df44d  vmovaps xmm14, [rsp+0xD0]
000078f8213df456  vmovaps xmm15, [rsp+0xE0]
000078f8213df45f  add rsp, 0xF0
000078f8213df466  pop r11
000078f8213df468  pop r10
000078f8213df46a  pop r9
000078f8213df46c  pop r8
000078f8213df46e  pop rsi
000078f8213df46f  pop rdi
000078f8213df470  pop rdx
000078f8213df471  pop rcx
000078f8213df472  pop rax
000078f8213df473  add rsp, 0x08
000078f8213df477  jmp 0x000078F8213DC3B3
000078f8213df47c  sub rsp, 0x08
000078f8213df480  push rax
000078f8213df481  push rcx
000078f8213df482  push rdx
000078f8213df483  push rdi
000078f8213df484  push rsi
000078f8213df485  push r8
000078f8213df487  push r9
000078f8213df489  push r10
000078f8213df48b  push r11
000078f8213df48d  sub rsp, 0xF0
000078f8213df494  vmovaps [rsp], xmm0
000078f8213df499  vmovaps [rsp+0x10], xmm1
000078f8213df49f  vmovaps [rsp+0x20], xmm2
000078f8213df4a5  vmovaps [rsp+0x30], xmm3
000078f8213df4ab  vmovaps [rsp+0x40], xmm4
000078f8213df4b1  vmovaps [rsp+0x50], xmm5
000078f8213df4b7  vmovaps [rsp+0x60], xmm7
000078f8213df4bd  vmovaps [rsp+0x70], xmm8
000078f8213df4c3  vmovaps [rsp+0x80], xmm9
000078f8213df4cc  vmovaps [rsp+0x90], xmm10
000078f8213df4d5  vmovaps [rsp+0xA0], xmm11
000078f8213df4de  vmovaps [rsp+0xB0], xmm12
000078f8213df4e7  vmovaps [rsp+0xC0], xmm13
000078f8213df4f0  vmovaps [rsp+0xD0], xmm14
000078f8213df4f9  vmovaps [rsp+0xE0], xmm15
000078f8213df502  sub rsp, 0x30
000078f8213df506  movaps [rsp], xmm6
000078f8213df50a  movaps [rsp+0x10], xmm10
000078f8213df510  movaps [rsp+0x20], xmm8
000078f8213df516  lea rdi, [rsp]
000078f8213df51a  mov esi, 0x00
000078f8213df51f  mov rax, 0x653D80F42530
000078f8213df529  call rax
000078f8213df52b  movaps xmm6, [rsp]
000078f8213df52f  add rsp, 0x30
000078f8213df533  vmovaps xmm0, [rsp]
000078f8213df538  vmovaps xmm1, [rsp+0x10]
000078f8213df53e  vmovaps xmm2, [rsp+0x20]
000078f8213df544  vmovaps xmm3, [rsp+0x30]
000078f8213df54a  vmovaps xmm4, [rsp+0x40]
000078f8213df550  vmovaps xmm5, [rsp+0x50]
000078f8213df556  vmovaps xmm7, [rsp+0x60]
000078f8213df55c  vmovaps xmm8, [rsp+0x70]
000078f8213df562  vmovaps xmm9, [rsp+0x80]
000078f8213df56b  vmovaps xmm10, [rsp+0x90]
000078f8213df574  vmovaps xmm11, [rsp+0xA0]
000078f8213df57d  vmovaps xmm12, [rsp+0xB0]
000078f8213df586  vmovaps xmm13, [rsp+0xC0]
000078f8213df58f  vmovaps xmm14, [rsp+0xD0]
000078f8213df598  vmovaps xmm15, [rsp+0xE0]
000078f8213df5a1  add rsp, 0xF0
000078f8213df5a8  pop r11
000078f8213df5aa  pop r10
000078f8213df5ac  pop r9
000078f8213df5ae  pop r8
000078f8213df5b0  pop rsi
000078f8213df5b1  pop rdi
000078f8213df5b2  pop rdx
000078f8213df5b3  pop rcx
000078f8213df5b4  pop rax
000078f8213df5b5  add rsp, 0x08
000078f8213df5b9  jmp 0x000078F8213DC3D8
000078f8213df5be  sub rsp, 0x08
000078f8213df5c2  push rax
000078f8213df5c3  push rcx
000078f8213df5c4  push rdx
000078f8213df5c5  push rdi
000078f8213df5c6  push rsi
000078f8213df5c7  push r8
000078f8213df5c9  push r9
000078f8213df5cb  push r10
000078f8213df5cd  push r11
000078f8213df5cf  sub rsp, 0xF0
000078f8213df5d6  vmovaps [rsp], xmm0
000078f8213df5db  vmovaps [rsp+0x10], xmm1
000078f8213df5e1  vmovaps [rsp+0x20], xmm2
000078f8213df5e7  vmovaps [rsp+0x30], xmm3
000078f8213df5ed  vmovaps [rsp+0x40], xmm4
000078f8213df5f3  vmovaps [rsp+0x50], xmm5
000078f8213df5f9  vmovaps [rsp+0x60], xmm6
000078f8213df5ff  vmovaps [rsp+0x70], xmm7
000078f8213df605  vmovaps [rsp+0x80], xmm8
000078f8213df60e  vmovaps [rsp+0x90], xmm9
000078f8213df617  vmovaps [rsp+0xA0], xmm11
000078f8213df620  vmovaps [rsp+0xB0], xmm12
000078f8213df629  vmovaps [rsp+0xC0], xmm13
000078f8213df632  vmovaps [rsp+0xD0], xmm14
000078f8213df63b  vmovaps [rsp+0xE0], xmm15
000078f8213df644  sub rsp, 0x30
000078f8213df648  movaps [rsp], xmm10
000078f8213df64d  movaps [rsp+0x10], xmm8
000078f8213df653  movaps [rsp+0x20], xmm14
000078f8213df659  lea rdi, [rsp]
000078f8213df65d  mov esi, 0x00
000078f8213df662  mov rax, 0x653D80F42530
000078f8213df66c  call rax
000078f8213df66e  movaps xmm10, [rsp]
000078f8213df673  add rsp, 0x30
000078f8213df677  vmovaps xmm0, [rsp]
000078f8213df67c  vmovaps xmm1, [rsp+0x10]
000078f8213df682  vmovaps xmm2, [rsp+0x20]
000078f8213df688  vmovaps xmm3, [rsp+0x30]
000078f8213df68e  vmovaps xmm4, [rsp+0x40]
000078f8213df694  vmovaps xmm5, [rsp+0x50]
000078f8213df69a  vmovaps xmm6, [rsp+0x60]
000078f8213df6a0  vmovaps xmm7, [rsp+0x70]
000078f8213df6a6  vmovaps xmm8, [rsp+0x80]
000078f8213df6af  vmovaps xmm9, [rsp+0x90]
000078f8213df6b8  vmovaps xmm11, [rsp+0xA0]
000078f8213df6c1  vmovaps xmm12, [rsp+0xB0]
000078f8213df6ca  vmovaps xmm13, [rsp+0xC0]
000078f8213df6d3  vmovaps xmm14, [rsp+0xD0]
000078f8213df6dc  vmovaps xmm15, [rsp+0xE0]
000078f8213df6e5  add rsp, 0xF0
000078f8213df6ec  pop r11
000078f8213df6ee  pop r10
000078f8213df6f0  pop r9
000078f8213df6f2  pop r8
000078f8213df6f4  pop rsi
000078f8213df6f5  pop rdi
000078f8213df6f6  pop rdx
000078f8213df6f7  pop rcx
000078f8213df6f8  pop rax
000078f8213df6f9  add rsp, 0x08
000078f8213df6fd  jmp 0x000078F8213DC3F8
000078f8213df702  sub rsp, 0x08
000078f8213df706  push rax
000078f8213df707  push rcx
000078f8213df708  push rdx
000078f8213df709  push rdi
000078f8213df70a  push rsi
000078f8213df70b  push r8
000078f8213df70d  push r9
000078f8213df70f  push r10
000078f8213df711  push r11
000078f8213df713  sub rsp, 0xF0
000078f8213df71a  vmovaps [rsp], xmm0
000078f8213df71f  vmovaps [rsp+0x10], xmm1
000078f8213df725  vmovaps [rsp+0x20], xmm2
000078f8213df72b  vmovaps [rsp+0x30], xmm3
000078f8213df731  vmovaps [rsp+0x40], xmm4
000078f8213df737  vmovaps [rsp+0x50], xmm5
000078f8213df73d  vmovaps [rsp+0x60], xmm6
000078f8213df743  vmovaps [rsp+0x70], xmm7
000078f8213df749  vmovaps [rsp+0x80], xmm8
000078f8213df752  vmovaps [rsp+0x90], xmm9
000078f8213df75b  vmovaps [rsp+0xA0], xmm10
000078f8213df764  vmovaps [rsp+0xB0], xmm11
000078f8213df76d  vmovaps [rsp+0xC0], xmm12
000078f8213df776  vmovaps [rsp+0xD0], xmm13
000078f8213df77f  vmovaps [rsp+0xE0], xmm15
000078f8213df788  sub rsp, 0x30
000078f8213df78c  movaps [rsp], xmm14
000078f8213df791  movaps [rsp+0x10], xmm8
000078f8213df797  movaps [rsp+0x20], xmm4
000078f8213df79c  lea rdi, [rsp]
000078f8213df7a0  mov esi, 0x00
000078f8213df7a5  mov rax, 0x653D80F42530
000078f8213df7af  call rax
000078f8213df7b1  movaps xmm14, [rsp]
000078f8213df7b6  add rsp, 0x30
000078f8213df7ba  vmovaps xmm0, [rsp]
000078f8213df7bf  vmovaps xmm1, [rsp+0x10]
000078f8213df7c5  vmovaps xmm2, [rsp+0x20]
000078f8213df7cb  vmovaps xmm3, [rsp+0x30]
000078f8213df7d1  vmovaps xmm4, [rsp+0x40]
000078f8213df7d7  vmovaps xmm5, [rsp+0x50]
000078f8213df7dd  vmovaps xmm6, [rsp+0x60]
000078f8213df7e3  vmovaps xmm7, [rsp+0x70]
000078f8213df7e9  vmovaps xmm8, [rsp+0x80]
000078f8213df7f2  vmovaps xmm9, [rsp+0x90]
000078f8213df7fb  vmovaps xmm10, [rsp+0xA0]
000078f8213df804  vmovaps xmm11, [rsp+0xB0]
000078f8213df80d  vmovaps xmm12, [rsp+0xC0]
000078f8213df816  vmovaps xmm13, [rsp+0xD0]
000078f8213df81f  vmovaps xmm15, [rsp+0xE0]
000078f8213df828  add rsp, 0xF0
000078f8213df82f  pop r11
000078f8213df831  pop r10
000078f8213df833  pop r9
000078f8213df835  pop r8
000078f8213df837  pop rsi
000078f8213df838  pop rdi
000078f8213df839  pop rdx
000078f8213df83a  pop rcx
000078f8213df83b  pop rax
000078f8213df83c  add rsp, 0x08
000078f8213df840  jmp 0x000078F8213DC418
000078f8213df845  sub rsp, 0x08
000078f8213df849  push rax
000078f8213df84a  push rcx
000078f8213df84b  push rdx
000078f8213df84c  push rdi
000078f8213df84d  push rsi
000078f8213df84e  push r8
000078f8213df850  push r9
000078f8213df852  push r10
000078f8213df854  push r11
000078f8213df856  sub rsp, 0xF0
000078f8213df85d  vmovaps [rsp], xmm0
000078f8213df862  vmovaps [rsp+0x10], xmm1
000078f8213df868  vmovaps [rsp+0x20], xmm2
000078f8213df86e  vmovaps [rsp+0x30], xmm3
000078f8213df874  vmovaps [rsp+0x40], xmm5
000078f8213df87a  vmovaps [rsp+0x50], xmm6
000078f8213df880  vmovaps [rsp+0x60], xmm7
000078f8213df886  vmovaps [rsp+0x70], xmm8
000078f8213df88c  vmovaps [rsp+0x80], xmm9
000078f8213df895  vmovaps [rsp+0x90], xmm10
000078f8213df89e  vmovaps [rsp+0xA0], xmm11
000078f8213df8a7  vmovaps [rsp+0xB0], xmm12
000078f8213df8b0  vmovaps [rsp+0xC0], xmm13
000078f8213df8b9  vmovaps [rsp+0xD0], xmm14
000078f8213df8c2  vmovaps [rsp+0xE0], xmm15
000078f8213df8cb  sub rsp, 0x30
000078f8213df8cf  movaps [rsp], xmm4
000078f8213df8d3  movaps [rsp+0x10], xmm13
000078f8213df8d9  movaps [rsp+0x20], xmm8
000078f8213df8df  lea rdi, [rsp]
000078f8213df8e3  mov esi, 0x00
000078f8213df8e8  mov rax, 0x653D80F42530
000078f8213df8f2  call rax
000078f8213df8f4  movaps xmm4, [rsp]
000078f8213df8f8  add rsp, 0x30
000078f8213df8fc  vmovaps xmm0, [rsp]
000078f8213df901  vmovaps xmm1, [rsp+0x10]
000078f8213df907  vmovaps xmm2, [rsp+0x20]
000078f8213df90d  vmovaps xmm3, [rsp+0x30]
000078f8213df913  vmovaps xmm5, [rsp+0x40]
000078f8213df919  vmovaps xmm6, [rsp+0x50]
000078f8213df91f  vmovaps xmm7, [rsp+0x60]
000078f8213df925  vmovaps xmm8, [rsp+0x70]
000078f8213df92b  vmovaps xmm9, [rsp+0x80]
000078f8213df934  vmovaps xmm10, [rsp+0x90]
000078f8213df93d  vmovaps xmm11, [rsp+0xA0]
000078f8213df946  vmovaps xmm12, [rsp+0xB0]
000078f8213df94f  vmovaps xmm13, [rsp+0xC0]
000078f8213df958  vmovaps xmm14, [rsp+0xD0]
000078f8213df961  vmovaps xmm15, [rsp+0xE0]
000078f8213df96a  add rsp, 0xF0
000078f8213df971  pop r11
000078f8213df973  pop r10
000078f8213df975  pop r9
000078f8213df977  pop r8
000078f8213df979  pop rsi
000078f8213df97a  pop rdi
000078f8213df97b  pop rdx
000078f8213df97c  pop rcx
000078f8213df97d  pop rax
000078f8213df97e  add rsp, 0x08
000078f8213df982  jmp 0x000078F8213DC43D
000078f8213df987  sub rsp, 0x08
000078f8213df98b  push rax
000078f8213df98c  push rcx
000078f8213df98d  push rdx
000078f8213df98e  push rdi
000078f8213df98f  push rsi
000078f8213df990  push r8
000078f8213df992  push r9
000078f8213df994  push r10
000078f8213df996  push r11
000078f8213df998  sub rsp, 0xF0
000078f8213df99f  vmovaps [rsp], xmm0
000078f8213df9a4  vmovaps [rsp+0x10], xmm1
000078f8213df9aa  vmovaps [rsp+0x20], xmm2
000078f8213df9b0  vmovaps [rsp+0x30], xmm3
000078f8213df9b6  vmovaps [rsp+0x40], xmm4
000078f8213df9bc  vmovaps [rsp+0x50], xmm5
000078f8213df9c2  vmovaps [rsp+0x60], xmm6
000078f8213df9c8  vmovaps [rsp+0x70], xmm7
000078f8213df9ce  vmovaps [rsp+0x80], xmm8
000078f8213df9d7  vmovaps [rsp+0x90], xmm9
000078f8213df9e0  vmovaps [rsp+0xA0], xmm10
000078f8213df9e9  vmovaps [rsp+0xB0], xmm11
000078f8213df9f2  vmovaps [rsp+0xC0], xmm12
000078f8213df9fb  vmovaps [rsp+0xD0], xmm14
000078f8213dfa04  vmovaps [rsp+0xE0], xmm15
000078f8213dfa0d  sub rsp, 0x30
000078f8213dfa11  movaps [rsp], xmm13
000078f8213dfa16  movaps [rsp+0x10], xmm15
000078f8213dfa1c  movaps [rsp+0x20], xmm9
000078f8213dfa22  lea rdi, [rsp]
000078f8213dfa26  mov esi, 0x00
000078f8213dfa2b  mov rax, 0x653D80F42530
000078f8213dfa35  call rax
000078f8213dfa37  movaps xmm13, [rsp]
000078f8213dfa3c  add rsp, 0x30
000078f8213dfa40  vmovaps xmm0, [rsp]
000078f8213dfa45  vmovaps xmm1, [rsp+0x10]
000078f8213dfa4b  vmovaps xmm2, [rsp+0x20]
000078f8213dfa51  vmovaps xmm3, [rsp+0x30]
000078f8213dfa57  vmovaps xmm4, [rsp+0x40]
000078f8213dfa5d  vmovaps xmm5, [rsp+0x50]
000078f8213dfa63  vmovaps xmm6, [rsp+0x60]
000078f8213dfa69  vmovaps xmm7, [rsp+0x70]
000078f8213dfa6f  vmovaps xmm8, [rsp+0x80]
000078f8213dfa78  vmovaps xmm9, [rsp+0x90]
000078f8213dfa81  vmovaps xmm10, [rsp+0xA0]
000078f8213dfa8a  vmovaps xmm11, [rsp+0xB0]
000078f8213dfa93  vmovaps xmm12, [rsp+0xC0]
000078f8213dfa9c  vmovaps xmm14, [rsp+0xD0]
000078f8213dfaa5  vmovaps xmm15, [rsp+0xE0]
000078f8213dfaae  add rsp, 0xF0
000078f8213dfab5  pop r11
000078f8213dfab7  pop r10
000078f8213dfab9  pop r9
000078f8213dfabb  pop r8
000078f8213dfabd  pop rsi
000078f8213dfabe  pop rdi
000078f8213dfabf  pop rdx
000078f8213dfac0  pop rcx
000078f8213dfac1  pop rax
000078f8213dfac2  add rsp, 0x08
000078f8213dfac6  jmp 0x000078F8213DC458
000078f8213dfacb  sub rsp, 0x08
000078f8213dfacf  push rax
000078f8213dfad0  push rcx
000078f8213dfad1  push rdx
000078f8213dfad2  push rdi
000078f8213dfad3  push rsi
000078f8213dfad4  push r8
000078f8213dfad6  push r9
000078f8213dfad8  push r10
000078f8213dfada  push r11
000078f8213dfadc  sub rsp, 0xF0
000078f8213dfae3  vmovaps [rsp], xmm0
000078f8213dfae8  vmovaps [rsp+0x10], xmm1
000078f8213dfaee  vmovaps [rsp+0x20], xmm2
000078f8213dfaf4  vmovaps [rsp+0x30], xmm3
000078f8213dfafa  vmovaps [rsp+0x40], xmm4
000078f8213dfb00  vmovaps [rsp+0x50], xmm5
000078f8213dfb06  vmovaps [rsp+0x60], xmm6
000078f8213dfb0c  vmovaps [rsp+0x70], xmm7
000078f8213dfb12  vmovaps [rsp+0x80], xmm8
000078f8213dfb1b  vmovaps [rsp+0x90], xmm9
000078f8213dfb24  vmovaps [rsp+0xA0], xmm10
000078f8213dfb2d  vmovaps [rsp+0xB0], xmm11
000078f8213dfb36  vmovaps [rsp+0xC0], xmm12
000078f8213dfb3f  vmovaps [rsp+0xD0], xmm13
000078f8213dfb48  vmovaps [rsp+0xE0], xmm14
000078f8213dfb51  sub rsp, 0x30
000078f8213dfb55  movaps [rsp], xmm15
000078f8213dfb5a  movaps [rsp+0x10], xmm1
000078f8213dfb5f  movaps [rsp+0x20], xmm5
000078f8213dfb64  lea rdi, [rsp]
000078f8213dfb68  mov esi, 0x00
000078f8213dfb6d  mov rax, 0x653D80F42530
000078f8213dfb77  call rax
000078f8213dfb79  movaps xmm15, [rsp]
000078f8213dfb7e  add rsp, 0x30
000078f8213dfb82  vmovaps xmm0, [rsp]
000078f8213dfb87  vmovaps xmm1, [rsp+0x10]
000078f8213dfb8d  vmovaps xmm2, [rsp+0x20]
000078f8213dfb93  vmovaps xmm3, [rsp+0x30]
000078f8213dfb99  vmovaps xmm4, [rsp+0x40]
000078f8213dfb9f  vmovaps xmm5, [rsp+0x50]
000078f8213dfba5  vmovaps xmm6, [rsp+0x60]
000078f8213dfbab  vmovaps xmm7, [rsp+0x70]
000078f8213dfbb1  vmovaps xmm8, [rsp+0x80]
000078f8213dfbba  vmovaps xmm9, [rsp+0x90]
000078f8213dfbc3  vmovaps xmm10, [rsp+0xA0]
000078f8213dfbcc  vmovaps xmm11, [rsp+0xB0]
000078f8213dfbd5  vmovaps xmm12, [rsp+0xC0]
000078f8213dfbde  vmovaps xmm13, [rsp+0xD0]
000078f8213dfbe7  vmovaps xmm14, [rsp+0xE0]
000078f8213dfbf0  add rsp, 0xF0
000078f8213dfbf7  pop r11
000078f8213dfbf9  pop r10
000078f8213dfbfb  pop r9
000078f8213dfbfd  pop r8
000078f8213dfbff  pop rsi
000078f8213dfc00  pop rdi
000078f8213dfc01  pop rdx
000078f8213dfc02  pop rcx
000078f8213dfc03  pop rax
000078f8213dfc04  add rsp, 0x08
000078f8213dfc08  jmp 0x000078F8213DC473
000078f8213dfc0d  call 0x000078F8212B52F0
000078f8213dfc12  jmp 0x000078F8213DC4CE
000078f8213dfc17  sub rsp, 0x08
000078f8213dfc1b  push rax
000078f8213dfc1c  push rcx
000078f8213dfc1d  push rdx
000078f8213dfc1e  push rdi
000078f8213dfc1f  push rsi
000078f8213dfc20  push r8
000078f8213dfc22  push r9
000078f8213dfc24  push r10
000078f8213dfc26  push r11
000078f8213dfc28  sub rsp, 0xF0
000078f8213dfc2f  vmovaps [rsp], xmm0
000078f8213dfc34  vmovaps [rsp+0x10], xmm1
000078f8213dfc3a  vmovaps [rsp+0x20], xmm2
000078f8213dfc40  vmovaps [rsp+0x30], xmm3
000078f8213dfc46  vmovaps [rsp+0x40], xmm4
000078f8213dfc4c  vmovaps [rsp+0x50], xmm5
000078f8213dfc52  vmovaps [rsp+0x60], xmm6
000078f8213dfc58  vmovaps [rsp+0x70], xmm7
000078f8213dfc5e  vmovaps [rsp+0x80], xmm8
000078f8213dfc67  vmovaps [rsp+0x90], xmm10
000078f8213dfc70  vmovaps [rsp+0xA0], xmm11
000078f8213dfc79  vmovaps [rsp+0xB0], xmm12
000078f8213dfc82  vmovaps [rsp+0xC0], xmm13
000078f8213dfc8b  vmovaps [rsp+0xD0], xmm14
000078f8213dfc94  vmovaps [rsp+0xE0], xmm15
000078f8213dfc9d  sub rsp, 0x30
000078f8213dfca1  movaps [rsp], xmm9
000078f8213dfca6  movaps [rsp+0x10], xmm8
000078f8213dfcac  movaps [rsp+0x20], xmm11
000078f8213dfcb2  lea rdi, [rsp]
000078f8213dfcb6  mov esi, 0x00
000078f8213dfcbb  mov rax, 0x653D80F42530
000078f8213dfcc5  call rax
000078f8213dfcc7  movaps xmm9, [rsp]
000078f8213dfccc  add rsp, 0x30
000078f8213dfcd0  vmovaps xmm0, [rsp]
000078f8213dfcd5  vmovaps xmm1, [rsp+0x10]
000078f8213dfcdb  vmovaps xmm2, [rsp+0x20]
000078f8213dfce1  vmovaps xmm3, [rsp+0x30]
000078f8213dfce7  vmovaps xmm4, [rsp+0x40]
000078f8213dfced  vmovaps xmm5, [rsp+0x50]
000078f8213dfcf3  vmovaps xmm6, [rsp+0x60]
000078f8213dfcf9  vmovaps xmm7, [rsp+0x70]
000078f8213dfcff  vmovaps xmm8, [rsp+0x80]
000078f8213dfd08  vmovaps xmm10, [rsp+0x90]
000078f8213dfd11  vmovaps xmm11, [rsp+0xA0]
000078f8213dfd1a  vmovaps xmm12, [rsp+0xB0]
000078f8213dfd23  vmovaps xmm13, [rsp+0xC0]
000078f8213dfd2c  vmovaps xmm14, [rsp+0xD0]
000078f8213dfd35  vmovaps xmm15, [rsp+0xE0]
000078f8213dfd3e  add rsp, 0xF0
000078f8213dfd45  pop r11
000078f8213dfd47  pop r10
000078f8213dfd49  pop r9
000078f8213dfd4b  pop r8
000078f8213dfd4d  pop rsi
000078f8213dfd4e  pop rdi
000078f8213dfd4f  pop rdx
000078f8213dfd50  pop rcx
000078f8213dfd51  pop rax
000078f8213dfd52  add rsp, 0x08
000078f8213dfd56  jmp 0x000078F8213DC505
000078f8213dfd5b  sub rsp, 0x08
000078f8213dfd5f  push rax
000078f8213dfd60  push rcx
000078f8213dfd61  push rdx
000078f8213dfd62  push rdi
000078f8213dfd63  push rsi
000078f8213dfd64  push r8
000078f8213dfd66  push r9
000078f8213dfd68  push r10
000078f8213dfd6a  push r11
000078f8213dfd6c  sub rsp, 0xF0
000078f8213dfd73  vmovaps [rsp], xmm0
000078f8213dfd78  vmovaps [rsp+0x10], xmm1
000078f8213dfd7e  vmovaps [rsp+0x20], xmm2
000078f8213dfd84  vmovaps [rsp+0x30], xmm3
000078f8213dfd8a  vmovaps [rsp+0x40], xmm4
000078f8213dfd90  vmovaps [rsp+0x50], xmm5
000078f8213dfd96  vmovaps [rsp+0x60], xmm6
000078f8213dfd9c  vmovaps [rsp+0x70], xmm7
000078f8213dfda2  vmovaps [rsp+0x80], xmm8
000078f8213dfdab  vmovaps [rsp+0x90], xmm9
000078f8213dfdb4  vmovaps [rsp+0xA0], xmm10
000078f8213dfdbd  vmovaps [rsp+0xB0], xmm12
000078f8213dfdc6  vmovaps [rsp+0xC0], xmm13
000078f8213dfdcf  vmovaps [rsp+0xD0], xmm14
000078f8213dfdd8  vmovaps [rsp+0xE0], xmm15
000078f8213dfde1  sub rsp, 0x30
000078f8213dfde5  movaps [rsp], xmm11
000078f8213dfdea  movaps [rsp+0x10], xmm10
000078f8213dfdf0  movaps [rsp+0x20], xmm6
000078f8213dfdf5  lea rdi, [rsp]
000078f8213dfdf9  mov esi, 0x00
000078f8213dfdfe  mov rax, 0x653D80F42530
000078f8213dfe08  call rax
000078f8213dfe0a  movaps xmm11, [rsp]
000078f8213dfe0f  add rsp, 0x30
000078f8213dfe13  vmovaps xmm0, [rsp]
000078f8213dfe18  vmovaps xmm1, [rsp+0x10]
000078f8213dfe1e  vmovaps xmm2, [rsp+0x20]
000078f8213dfe24  vmovaps xmm3, [rsp+0x30]
000078f8213dfe2a  vmovaps xmm4, [rsp+0x40]
000078f8213dfe30  vmovaps xmm5, [rsp+0x50]
000078f8213dfe36  vmovaps xmm6, [rsp+0x60]
000078f8213dfe3c  vmovaps xmm7, [rsp+0x70]
000078f8213dfe42  vmovaps xmm8, [rsp+0x80]
000078f8213dfe4b  vmovaps xmm9, [rsp+0x90]
000078f8213dfe54  vmovaps xmm10, [rsp+0xA0]
000078f8213dfe5d  vmovaps xmm12, [rsp+0xB0]
000078f8213dfe66  vmovaps xmm13, [rsp+0xC0]
000078f8213dfe6f  vmovaps xmm14, [rsp+0xD0]
000078f8213dfe78  vmovaps xmm15, [rsp+0xE0]
000078f8213dfe81  add rsp, 0xF0
000078f8213dfe88  pop r11
000078f8213dfe8a  pop r10
000078f8213dfe8c  pop r9
000078f8213dfe8e  pop r8
000078f8213dfe90  pop rsi
000078f8213dfe91  pop rdi
000078f8213dfe92  pop rdx
000078f8213dfe93  pop rcx
000078f8213dfe94  pop rax
000078f8213dfe95  add rsp, 0x08
000078f8213dfe99  jmp 0x000078F8213DC520
000078f8213dfe9e  sub rsp, 0x08
000078f8213dfea2  push rax
000078f8213dfea3  push rcx
000078f8213dfea4  push rdx
000078f8213dfea5  push rdi
000078f8213dfea6  push rsi
000078f8213dfea7  push r8
000078f8213dfea9  push r9
000078f8213dfeab  push r10
000078f8213dfead  push r11
000078f8213dfeaf  sub rsp, 0xF0
000078f8213dfeb6  vmovaps [rsp], xmm0
000078f8213dfebb  vmovaps [rsp+0x10], xmm1
000078f8213dfec1  vmovaps [rsp+0x20], xmm2
000078f8213dfec7  vmovaps [rsp+0x30], xmm3
000078f8213dfecd  vmovaps [rsp+0x40], xmm4
000078f8213dfed3  vmovaps [rsp+0x50], xmm5
000078f8213dfed9  vmovaps [rsp+0x60], xmm6
000078f8213dfedf  vmovaps [rsp+0x70], xmm7
000078f8213dfee5  vmovaps [rsp+0x80], xmm8
000078f8213dfeee  vmovaps [rsp+0x90], xmm9
000078f8213dfef7  vmovaps [rsp+0xA0], xmm11
000078f8213dff00  vmovaps [rsp+0xB0], xmm12
000078f8213dff09  vmovaps [rsp+0xC0], xmm13
000078f8213dff12  vmovaps [rsp+0xD0], xmm14
000078f8213dff1b  vmovaps [rsp+0xE0], xmm15
000078f8213dff24  sub rsp, 0x30
000078f8213dff28  movaps [rsp], xmm10
000078f8213dff2d  movaps [rsp+0x10], xmm14
000078f8213dff33  movaps [rsp+0x20], xmm4
000078f8213dff38  lea rdi, [rsp]
000078f8213dff3c  mov esi, 0x00
000078f8213dff41  mov rax, 0x653D80F42530
000078f8213dff4b  call rax
000078f8213dff4d  movaps xmm10, [rsp]
000078f8213dff52  add rsp, 0x30
000078f8213dff56  vmovaps xmm0, [rsp]
000078f8213dff5b  vmovaps xmm1, [rsp+0x10]
000078f8213dff61  vmovaps xmm2, [rsp+0x20]
000078f8213dff67  vmovaps xmm3, [rsp+0x30]
000078f8213dff6d  vmovaps xmm4, [rsp+0x40]
000078f8213dff73  vmovaps xmm5, [rsp+0x50]
000078f8213dff79  vmovaps xmm6, [rsp+0x60]
000078f8213dff7f  vmovaps xmm7, [rsp+0x70]
000078f8213dff85  vmovaps xmm8, [rsp+0x80]
000078f8213dff8e  vmovaps xmm9, [rsp+0x90]
000078f8213dff97  vmovaps xmm11, [rsp+0xA0]
000078f8213dffa0  vmovaps xmm12, [rsp+0xB0]
000078f8213dffa9  vmovaps xmm13, [rsp+0xC0]
000078f8213dffb2  vmovaps xmm14, [rsp+0xD0]
000078f8213dffbb  vmovaps xmm15, [rsp+0xE0]
000078f8213dffc4  add rsp, 0xF0
000078f8213dffcb  pop r11
000078f8213dffcd  pop r10
000078f8213dffcf  pop r9
000078f8213dffd1  pop r8
000078f8213dffd3  pop rsi
000078f8213dffd4  pop rdi
000078f8213dffd5  pop rdx
000078f8213dffd6  pop rcx
000078f8213dffd7  pop rax
000078f8213dffd8  add rsp, 0x08
000078f8213dffdc  jmp 0x000078F8213DC53B
000078f8213dffe1  sub rsp, 0x08
000078f8213dffe5  push rax
000078f8213dffe6  push rcx
000078f8213dffe7  push rdx
000078f8213dffe8  push rdi
000078f8213dffe9  push rsi
000078f8213dffea  push r8
000078f8213dffec  push r9
000078f8213dffee  push r10
000078f8213dfff0  push r11
000078f8213dfff2  sub rsp, 0xF0
000078f8213dfff9  vmovaps [rsp], xmm0
000078f8213dfffe  vmovaps [rsp+0x10], xmm1
000078f8213e0004  vmovaps [rsp+0x20], xmm2
000078f8213e000a  vmovaps [rsp+0x30], xmm3
000078f8213e0010  vmovaps [rsp+0x40], xmm4
000078f8213e0016  vmovaps [rsp+0x50], xmm5
000078f8213e001c  vmovaps [rsp+0x60], xmm6
000078f8213e0022  vmovaps [rsp+0x70], xmm7
000078f8213e0028  vmovaps [rsp+0x80], xmm9
000078f8213e0031  vmovaps [rsp+0x90], xmm10
000078f8213e003a  vmovaps [rsp+0xA0], xmm11
000078f8213e0043  vmovaps [rsp+0xB0], xmm12
000078f8213e004c  vmovaps [rsp+0xC0], xmm13
000078f8213e0055  vmovaps [rsp+0xD0], xmm14
000078f8213e005e  vmovaps [rsp+0xE0], xmm15
000078f8213e0067  sub rsp, 0x30
000078f8213e006b  movaps [rsp], xmm8
000078f8213e0070  movaps [rsp+0x10], xmm1
000078f8213e0075  movaps [rsp+0x20], xmm14
000078f8213e007b  lea rdi, [rsp]
000078f8213e007f  mov esi, 0x00
000078f8213e0084  mov rax, 0x653D80F42530
000078f8213e008e  call rax
000078f8213e0090  movaps xmm8, [rsp]
000078f8213e0095  add rsp, 0x30
000078f8213e0099  vmovaps xmm0, [rsp]
000078f8213e009e  vmovaps xmm1, [rsp+0x10]
000078f8213e00a4  vmovaps xmm2, [rsp+0x20]
000078f8213e00aa  vmovaps xmm3, [rsp+0x30]
000078f8213e00b0  vmovaps xmm4, [rsp+0x40]
000078f8213e00b6  vmovaps xmm5, [rsp+0x50]
000078f8213e00bc  vmovaps xmm6, [rsp+0x60]
000078f8213e00c2  vmovaps xmm7, [rsp+0x70]
000078f8213e00c8  vmovaps xmm9, [rsp+0x80]
000078f8213e00d1  vmovaps xmm10, [rsp+0x90]
000078f8213e00da  vmovaps xmm11, [rsp+0xA0]
000078f8213e00e3  vmovaps xmm12, [rsp+0xB0]
000078f8213e00ec  vmovaps xmm13, [rsp+0xC0]
000078f8213e00f5  vmovaps xmm14, [rsp+0xD0]
000078f8213e00fe  vmovaps xmm15, [rsp+0xE0]
000078f8213e0107  add rsp, 0xF0
000078f8213e010e  pop r11
000078f8213e0110  pop r10
000078f8213e0112  pop r9
000078f8213e0114  pop r8
000078f8213e0116  pop rsi
000078f8213e0117  pop rdi
000078f8213e0118  pop rdx
000078f8213e0119  pop rcx
000078f8213e011a  pop rax
000078f8213e011b  add rsp, 0x08
000078f8213e011f  jmp 0x000078F8213DC561
000078f8213e0124  sub rsp, 0x08
000078f8213e0128  push rax
000078f8213e0129  push rcx
000078f8213e012a  push rdx
000078f8213e012b  push rdi
000078f8213e012c  push rsi
000078f8213e012d  push r8
000078f8213e012f  push r9
000078f8213e0131  push r10
000078f8213e0133  push r11
000078f8213e0135  sub rsp, 0xF0
000078f8213e013c  vmovaps [rsp], xmm0
000078f8213e0141  vmovaps [rsp+0x10], xmm1
000078f8213e0147  vmovaps [rsp+0x20], xmm2
000078f8213e014d  vmovaps [rsp+0x30], xmm3
000078f8213e0153  vmovaps [rsp+0x40], xmm4
000078f8213e0159  vmovaps [rsp+0x50], xmm5
000078f8213e015f  vmovaps [rsp+0x60], xmm7
000078f8213e0165  vmovaps [rsp+0x70], xmm8
000078f8213e016b  vmovaps [rsp+0x80], xmm9
000078f8213e0174  vmovaps [rsp+0x90], xmm10
000078f8213e017d  vmovaps [rsp+0xA0], xmm11
000078f8213e0186  vmovaps [rsp+0xB0], xmm12
000078f8213e018f  vmovaps [rsp+0xC0], xmm13
000078f8213e0198  vmovaps [rsp+0xD0], xmm14
000078f8213e01a1  vmovaps [rsp+0xE0], xmm15
000078f8213e01aa  sub rsp, 0x30
000078f8213e01ae  movaps [rsp], xmm6
000078f8213e01b2  movaps [rsp+0x10], xmm1
000078f8213e01b7  movaps [rsp+0x20], xmm14
000078f8213e01bd  lea rdi, [rsp]
000078f8213e01c1  mov esi, 0x00
000078f8213e01c6  mov rax, 0x653D80F42530
000078f8213e01d0  call rax
000078f8213e01d2  movaps xmm6, [rsp]
000078f8213e01d6  add rsp, 0x30
000078f8213e01da  vmovaps xmm0, [rsp]
000078f8213e01df  vmovaps xmm1, [rsp+0x10]
000078f8213e01e5  vmovaps xmm2, [rsp+0x20]
000078f8213e01eb  vmovaps xmm3, [rsp+0x30]
000078f8213e01f1  vmovaps xmm4, [rsp+0x40]
000078f8213e01f7  vmovaps xmm5, [rsp+0x50]
000078f8213e01fd  vmovaps xmm7, [rsp+0x60]
000078f8213e0203  vmovaps xmm8, [rsp+0x70]
000078f8213e0209  vmovaps xmm9, [rsp+0x80]
000078f8213e0212  vmovaps xmm10, [rsp+0x90]
000078f8213e021b  vmovaps xmm11, [rsp+0xA0]
000078f8213e0224  vmovaps xmm12, [rsp+0xB0]
000078f8213e022d  vmovaps xmm13, [rsp+0xC0]
000078f8213e0236  vmovaps xmm14, [rsp+0xD0]
000078f8213e023f  vmovaps xmm15, [rsp+0xE0]
000078f8213e0248  add rsp, 0xF0
000078f8213e024f  pop r11
000078f8213e0251  pop r10
000078f8213e0253  pop r9
000078f8213e0255  pop r8
000078f8213e0257  pop rsi
000078f8213e0258  pop rdi
000078f8213e0259  pop rdx
000078f8213e025a  pop rcx
000078f8213e025b  pop rax
000078f8213e025c  add rsp, 0x08
000078f8213e0260  jmp 0x000078F8213DC58D
000078f8213e0265  sub rsp, 0x08
000078f8213e0269  push rax
000078f8213e026a  push rcx
000078f8213e026b  push rdx
000078f8213e026c  push rdi
000078f8213e026d  push rsi
000078f8213e026e  push r8
000078f8213e0270  push r9
000078f8213e0272  push r10
000078f8213e0274  push r11
000078f8213e0276  sub rsp, 0xF0
000078f8213e027d  vmovaps [rsp], xmm0
000078f8213e0282  vmovaps [rsp+0x10], xmm1
000078f8213e0288  vmovaps [rsp+0x20], xmm2
000078f8213e028e  vmovaps [rsp+0x30], xmm3
000078f8213e0294  vmovaps [rsp+0x40], xmm4
000078f8213e029a  vmovaps [rsp+0x50], xmm5
000078f8213e02a0  vmovaps [rsp+0x60], xmm6
000078f8213e02a6  vmovaps [rsp+0x70], xmm7
000078f8213e02ac  vmovaps [rsp+0x80], xmm8
000078f8213e02b5  vmovaps [rsp+0x90], xmm9
000078f8213e02be  vmovaps [rsp+0xA0], xmm10
000078f8213e02c7  vmovaps [rsp+0xB0], xmm11
000078f8213e02d0  vmovaps [rsp+0xC0], xmm12
000078f8213e02d9  vmovaps [rsp+0xD0], xmm13
000078f8213e02e2  vmovaps [rsp+0xE0], xmm15
000078f8213e02eb  sub rsp, 0x30
000078f8213e02ef  movaps [rsp], xmm14
000078f8213e02f4  movaps [rsp+0x10], xmm12
000078f8213e02fa  movaps [rsp+0x20], xmm1
000078f8213e02ff  lea rdi, [rsp]
000078f8213e0303  mov esi, 0x00
000078f8213e0308  mov rax, 0x653D80F42530
000078f8213e0312  call rax
000078f8213e0314  movaps xmm14, [rsp]
000078f8213e0319  add rsp, 0x30
000078f8213e031d  vmovaps xmm0, [rsp]
000078f8213e0322  vmovaps xmm1, [rsp+0x10]
000078f8213e0328  vmovaps xmm2, [rsp+0x20]
000078f8213e032e  vmovaps xmm3, [rsp+0x30]
000078f8213e0334  vmovaps xmm4, [rsp+0x40]
000078f8213e033a  vmovaps xmm5, [rsp+0x50]
000078f8213e0340  vmovaps xmm6, [rsp+0x60]
000078f8213e0346  vmovaps xmm7, [rsp+0x70]
000078f8213e034c  vmovaps xmm8, [rsp+0x80]
000078f8213e0355  vmovaps xmm9, [rsp+0x90]
000078f8213e035e  vmovaps xmm10, [rsp+0xA0]
000078f8213e0367  vmovaps xmm11, [rsp+0xB0]
000078f8213e0370  vmovaps xmm12, [rsp+0xC0]
000078f8213e0379  vmovaps xmm13, [rsp+0xD0]
000078f8213e0382  vmovaps xmm15, [rsp+0xE0]
000078f8213e038b  add rsp, 0xF0
000078f8213e0392  pop r11
000078f8213e0394  pop r10
000078f8213e0396  pop r9
000078f8213e0398  pop r8
000078f8213e039a  pop rsi
000078f8213e039b  pop rdi
000078f8213e039c  pop rdx
000078f8213e039d  pop rcx
000078f8213e039e  pop rax
000078f8213e039f  add rsp, 0x08
000078f8213e03a3  jmp 0x000078F8213DC5B3
000078f8213e03a8  sub rsp, 0x08
000078f8213e03ac  push rax
000078f8213e03ad  push rcx
000078f8213e03ae  push rdx
000078f8213e03af  push rdi
000078f8213e03b0  push rsi
000078f8213e03b1  push r8
000078f8213e03b3  push r9
000078f8213e03b5  push r10
000078f8213e03b7  push r11
000078f8213e03b9  sub rsp, 0xF0
000078f8213e03c0  vmovaps [rsp], xmm0
000078f8213e03c5  vmovaps [rsp+0x10], xmm2
000078f8213e03cb  vmovaps [rsp+0x20], xmm3
000078f8213e03d1  vmovaps [rsp+0x30], xmm4
000078f8213e03d7  vmovaps [rsp+0x40], xmm5
000078f8213e03dd  vmovaps [rsp+0x50], xmm6
000078f8213e03e3  vmovaps [rsp+0x60], xmm7
000078f8213e03e9  vmovaps [rsp+0x70], xmm8
000078f8213e03ef  vmovaps [rsp+0x80], xmm9
000078f8213e03f8  vmovaps [rsp+0x90], xmm10
000078f8213e0401  vmovaps [rsp+0xA0], xmm11
000078f8213e040a  vmovaps [rsp+0xB0], xmm12
000078f8213e0413  vmovaps [rsp+0xC0], xmm13
000078f8213e041c  vmovaps [rsp+0xD0], xmm14
000078f8213e0425  vmovaps [rsp+0xE0], xmm15
000078f8213e042e  sub rsp, 0x30
000078f8213e0432  movaps [rsp], xmm1
000078f8213e0436  movaps [rsp+0x10], xmm13
000078f8213e043c  movaps [rsp+0x20], xmm9
000078f8213e0442  lea rdi, [rsp]
000078f8213e0446  mov esi, 0x00
000078f8213e044b  mov rax, 0x653D80F42530
000078f8213e0455  call rax
000078f8213e0457  movaps xmm1, [rsp]
000078f8213e045b  add rsp, 0x30
000078f8213e045f  vmovaps xmm0, [rsp]
000078f8213e0464  vmovaps xmm2, [rsp+0x10]
000078f8213e046a  vmovaps xmm3, [rsp+0x20]
000078f8213e0470  vmovaps xmm4, [rsp+0x30]
000078f8213e0476  vmovaps xmm5, [rsp+0x40]
000078f8213e047c  vmovaps xmm6, [rsp+0x50]
000078f8213e0482  vmovaps xmm7, [rsp+0x60]
000078f8213e0488  vmovaps xmm8, [rsp+0x70]
000078f8213e048e  vmovaps xmm9, [rsp+0x80]
000078f8213e0497  vmovaps xmm10, [rsp+0x90]
000078f8213e04a0  vmovaps xmm11, [rsp+0xA0]
000078f8213e04a9  vmovaps xmm12, [rsp+0xB0]
000078f8213e04b2  vmovaps xmm13, [rsp+0xC0]
000078f8213e04bb  vmovaps xmm14, [rsp+0xD0]
000078f8213e04c4  vmovaps xmm15, [rsp+0xE0]
000078f8213e04cd  add rsp, 0xF0
000078f8213e04d4  pop r11
000078f8213e04d6  pop r10
000078f8213e04d8  pop r9
000078f8213e04da  pop r8
000078f8213e04dc  pop rsi
000078f8213e04dd  pop rdi
000078f8213e04de  pop rdx
000078f8213e04df  pop rcx
000078f8213e04e0  pop rax
000078f8213e04e1  add rsp, 0x08
000078f8213e04e5  jmp 0x000078F8213DC5CD
000078f8213e04ea  sub rsp, 0x08
000078f8213e04ee  push rax
000078f8213e04ef  push rcx
000078f8213e04f0  push rdx
000078f8213e04f1  push rdi
000078f8213e04f2  push rsi
000078f8213e04f3  push r8
000078f8213e04f5  push r9
000078f8213e04f7  push r10
000078f8213e04f9  push r11
000078f8213e04fb  sub rsp, 0xF0
000078f8213e0502  vmovaps [rsp], xmm0
000078f8213e0507  vmovaps [rsp+0x10], xmm1
000078f8213e050d  vmovaps [rsp+0x20], xmm2
000078f8213e0513  vmovaps [rsp+0x30], xmm3
000078f8213e0519  vmovaps [rsp+0x40], xmm4
000078f8213e051f  vmovaps [rsp+0x50], xmm5
000078f8213e0525  vmovaps [rsp+0x60], xmm6
000078f8213e052b  vmovaps [rsp+0x70], xmm7
000078f8213e0531  vmovaps [rsp+0x80], xmm8
000078f8213e053a  vmovaps [rsp+0x90], xmm9
000078f8213e0543  vmovaps [rsp+0xA0], xmm10
000078f8213e054c  vmovaps [rsp+0xB0], xmm11
000078f8213e0555  vmovaps [rsp+0xC0], xmm13
000078f8213e055e  vmovaps [rsp+0xD0], xmm14
000078f8213e0567  vmovaps [rsp+0xE0], xmm15
000078f8213e0570  sub rsp, 0x30
000078f8213e0574  movaps [rsp], xmm12
000078f8213e0579  movaps [rsp+0x10], xmm7
000078f8213e057e  movaps [rsp+0x20], xmm13
000078f8213e0584  lea rdi, [rsp]
000078f8213e0588  mov esi, 0x00
000078f8213e058d  mov rax, 0x653D80F42530
000078f8213e0597  call rax
000078f8213e0599  movaps xmm12, [rsp]
000078f8213e059e  add rsp, 0x30
000078f8213e05a2  vmovaps xmm0, [rsp]
000078f8213e05a7  vmovaps xmm1, [rsp+0x10]
000078f8213e05ad  vmovaps xmm2, [rsp+0x20]
000078f8213e05b3  vmovaps xmm3, [rsp+0x30]
000078f8213e05b9  vmovaps xmm4, [rsp+0x40]
000078f8213e05bf  vmovaps xmm5, [rsp+0x50]
000078f8213e05c5  vmovaps xmm6, [rsp+0x60]
000078f8213e05cb  vmovaps xmm7, [rsp+0x70]
000078f8213e05d1  vmovaps xmm8, [rsp+0x80]
000078f8213e05da  vmovaps xmm9, [rsp+0x90]
000078f8213e05e3  vmovaps xmm10, [rsp+0xA0]
000078f8213e05ec  vmovaps xmm11, [rsp+0xB0]
000078f8213e05f5  vmovaps xmm13, [rsp+0xC0]
000078f8213e05fe  vmovaps xmm14, [rsp+0xD0]
000078f8213e0607  vmovaps xmm15, [rsp+0xE0]
000078f8213e0610  add rsp, 0xF0
000078f8213e0617  pop r11
000078f8213e0619  pop r10
000078f8213e061b  pop r9
000078f8213e061d  pop r8
000078f8213e061f  pop rsi
000078f8213e0620  pop rdi
000078f8213e0621  pop rdx
000078f8213e0622  pop rcx
000078f8213e0623  pop rax
000078f8213e0624  add rsp, 0x08
000078f8213e0628  jmp 0x000078F8213DC5F4
000078f8213e062d  sub rsp, 0x08
000078f8213e0631  push rax
000078f8213e0632  push rcx
000078f8213e0633  push rdx
000078f8213e0634  push rdi
000078f8213e0635  push rsi
000078f8213e0636  push r8
000078f8213e0638  push r9
000078f8213e063a  push r10
000078f8213e063c  push r11
000078f8213e063e  sub rsp, 0xF0
000078f8213e0645  vmovaps [rsp], xmm0
000078f8213e064a  vmovaps [rsp+0x10], xmm1
000078f8213e0650  vmovaps [rsp+0x20], xmm2
000078f8213e0656  vmovaps [rsp+0x30], xmm3
000078f8213e065c  vmovaps [rsp+0x40], xmm4
000078f8213e0662  vmovaps [rsp+0x50], xmm5
000078f8213e0668  vmovaps [rsp+0x60], xmm6
000078f8213e066e  vmovaps [rsp+0x70], xmm7
000078f8213e0674  vmovaps [rsp+0x80], xmm8
000078f8213e067d  vmovaps [rsp+0x90], xmm9
000078f8213e0686  vmovaps [rsp+0xA0], xmm10
000078f8213e068f  vmovaps [rsp+0xB0], xmm11
000078f8213e0698  vmovaps [rsp+0xC0], xmm12
000078f8213e06a1  vmovaps [rsp+0xD0], xmm14
000078f8213e06aa  vmovaps [rsp+0xE0], xmm15
000078f8213e06b3  sub rsp, 0x30
000078f8213e06b7  movaps [rsp], xmm13
000078f8213e06bc  movaps [rsp+0x10], xmm15
000078f8213e06c2  movaps [rsp+0x20], xmm8
000078f8213e06c8  lea rdi, [rsp]
000078f8213e06cc  mov esi, 0x00
000078f8213e06d1  mov rax, 0x653D80F42530
000078f8213e06db  call rax
000078f8213e06dd  movaps xmm13, [rsp]
000078f8213e06e2  add rsp, 0x30
000078f8213e06e6  vmovaps xmm0, [rsp]
000078f8213e06eb  vmovaps xmm1, [rsp+0x10]
000078f8213e06f1  vmovaps xmm2, [rsp+0x20]
000078f8213e06f7  vmovaps xmm3, [rsp+0x30]
000078f8213e06fd  vmovaps xmm4, [rsp+0x40]
000078f8213e0703  vmovaps xmm5, [rsp+0x50]
000078f8213e0709  vmovaps xmm6, [rsp+0x60]
000078f8213e070f  vmovaps xmm7, [rsp+0x70]
000078f8213e0715  vmovaps xmm8, [rsp+0x80]
000078f8213e071e  vmovaps xmm9, [rsp+0x90]
000078f8213e0727  vmovaps xmm10, [rsp+0xA0]
000078f8213e0730  vmovaps xmm11, [rsp+0xB0]
000078f8213e0739  vmovaps xmm12, [rsp+0xC0]
000078f8213e0742  vmovaps xmm14, [rsp+0xD0]
000078f8213e074b  vmovaps xmm15, [rsp+0xE0]
000078f8213e0754  add rsp, 0xF0
000078f8213e075b  pop r11
000078f8213e075d  pop r10
000078f8213e075f  pop r9
000078f8213e0761  pop r8
000078f8213e0763  pop rsi
000078f8213e0764  pop rdi
000078f8213e0765  pop rdx
000078f8213e0766  pop rcx
000078f8213e0767  pop rax
000078f8213e0768  add rsp, 0x08
000078f8213e076c  jmp 0x000078F8213DC60F
000078f8213e0771  sub rsp, 0x08
000078f8213e0775  push rax
000078f8213e0776  push rcx
000078f8213e0777  push rdx
000078f8213e0778  push rdi
000078f8213e0779  push rsi
000078f8213e077a  push r8
000078f8213e077c  push r9
000078f8213e077e  push r10
000078f8213e0780  push r11
000078f8213e0782  sub rsp, 0xF0
000078f8213e0789  vmovaps [rsp], xmm0
000078f8213e078e  vmovaps [rsp+0x10], xmm1
000078f8213e0794  vmovaps [rsp+0x20], xmm2
000078f8213e079a  vmovaps [rsp+0x30], xmm3
000078f8213e07a0  vmovaps [rsp+0x40], xmm4
000078f8213e07a6  vmovaps [rsp+0x50], xmm5
000078f8213e07ac  vmovaps [rsp+0x60], xmm6
000078f8213e07b2  vmovaps [rsp+0x70], xmm7
000078f8213e07b8  vmovaps [rsp+0x80], xmm9
000078f8213e07c1  vmovaps [rsp+0x90], xmm10
000078f8213e07ca  vmovaps [rsp+0xA0], xmm11
000078f8213e07d3  vmovaps [rsp+0xB0], xmm12
000078f8213e07dc  vmovaps [rsp+0xC0], xmm13
000078f8213e07e5  vmovaps [rsp+0xD0], xmm14
000078f8213e07ee  vmovaps [rsp+0xE0], xmm15
000078f8213e07f7  sub rsp, 0x30
000078f8213e07fb  movaps [rsp], xmm8
000078f8213e0800  movaps [rsp+0x10], xmm15
000078f8213e0806  movaps [rsp+0x20], xmm9
000078f8213e080c  lea rdi, [rsp]
000078f8213e0810  mov esi, 0x00
000078f8213e0815  mov rax, 0x653D80F42530
000078f8213e081f  call rax
000078f8213e0821  movaps xmm8, [rsp]
000078f8213e0826  add rsp, 0x30
000078f8213e082a  vmovaps xmm0, [rsp]
000078f8213e082f  vmovaps xmm1, [rsp+0x10]
000078f8213e0835  vmovaps xmm2, [rsp+0x20]
000078f8213e083b  vmovaps xmm3, [rsp+0x30]
000078f8213e0841  vmovaps xmm4, [rsp+0x40]
000078f8213e0847  vmovaps xmm5, [rsp+0x50]
000078f8213e084d  vmovaps xmm6, [rsp+0x60]
000078f8213e0853  vmovaps xmm7, [rsp+0x70]
000078f8213e0859  vmovaps xmm9, [rsp+0x80]
000078f8213e0862  vmovaps xmm10, [rsp+0x90]
000078f8213e086b  vmovaps xmm11, [rsp+0xA0]
000078f8213e0874  vmovaps xmm12, [rsp+0xB0]
000078f8213e087d  vmovaps xmm13, [rsp+0xC0]
000078f8213e0886  vmovaps xmm14, [rsp+0xD0]
000078f8213e088f  vmovaps xmm15, [rsp+0xE0]
000078f8213e0898  add rsp, 0xF0
000078f8213e089f  pop r11
000078f8213e08a1  pop r10
000078f8213e08a3  pop r9
000078f8213e08a5  pop r8
000078f8213e08a7  pop rsi
000078f8213e08a8  pop rdi
000078f8213e08a9  pop rdx
000078f8213e08aa  pop rcx
000078f8213e08ab  pop rax
000078f8213e08ac  add rsp, 0x08
000078f8213e08b0  jmp 0x000078F8213DC63D
000078f8213e08b5  sub rsp, 0x08
000078f8213e08b9  push rax
000078f8213e08ba  push rcx
000078f8213e08bb  push rdx
000078f8213e08bc  push rdi
000078f8213e08bd  push rsi
000078f8213e08be  push r8
000078f8213e08c0  push r9
000078f8213e08c2  push r10
000078f8213e08c4  push r11
000078f8213e08c6  sub rsp, 0xF0
000078f8213e08cd  vmovaps [rsp], xmm0
000078f8213e08d2  vmovaps [rsp+0x10], xmm1
000078f8213e08d8  vmovaps [rsp+0x20], xmm2
000078f8213e08de  vmovaps [rsp+0x30], xmm3
000078f8213e08e4  vmovaps [rsp+0x40], xmm4
000078f8213e08ea  vmovaps [rsp+0x50], xmm5
000078f8213e08f0  vmovaps [rsp+0x60], xmm6
000078f8213e08f6  vmovaps [rsp+0x70], xmm7
000078f8213e08fc  vmovaps [rsp+0x80], xmm8
000078f8213e0905  vmovaps [rsp+0x90], xmm9
000078f8213e090e  vmovaps [rsp+0xA0], xmm10
000078f8213e0917  vmovaps [rsp+0xB0], xmm11
000078f8213e0920  vmovaps [rsp+0xC0], xmm12
000078f8213e0929  vmovaps [rsp+0xD0], xmm13
000078f8213e0932  vmovaps [rsp+0xE0], xmm14
000078f8213e093b  sub rsp, 0x30
000078f8213e093f  movaps [rsp], xmm15
000078f8213e0944  movaps [rsp+0x10], xmm11
000078f8213e094a  movaps [rsp+0x20], xmm6
000078f8213e094f  lea rdi, [rsp]
000078f8213e0953  mov esi, 0x00
000078f8213e0958  mov rax, 0x653D80F42530
000078f8213e0962  call rax
000078f8213e0964  movaps xmm15, [rsp]
000078f8213e0969  add rsp, 0x30
000078f8213e096d  vmovaps xmm0, [rsp]
000078f8213e0972  vmovaps xmm1, [rsp+0x10]
000078f8213e0978  vmovaps xmm2, [rsp+0x20]
000078f8213e097e  vmovaps xmm3, [rsp+0x30]
000078f8213e0984  vmovaps xmm4, [rsp+0x40]
000078f8213e098a  vmovaps xmm5, [rsp+0x50]
000078f8213e0990  vmovaps xmm6, [rsp+0x60]
000078f8213e0996  vmovaps xmm7, [rsp+0x70]
000078f8213e099c  vmovaps xmm8, [rsp+0x80]
000078f8213e09a5  vmovaps xmm9, [rsp+0x90]
000078f8213e09ae  vmovaps xmm10, [rsp+0xA0]
000078f8213e09b7  vmovaps xmm11, [rsp+0xB0]
000078f8213e09c0  vmovaps xmm12, [rsp+0xC0]
000078f8213e09c9  vmovaps xmm13, [rsp+0xD0]
000078f8213e09d2  vmovaps xmm14, [rsp+0xE0]
000078f8213e09db  add rsp, 0xF0
000078f8213e09e2  pop r11
000078f8213e09e4  pop r10
000078f8213e09e6  pop r9
000078f8213e09e8  pop r8
000078f8213e09ea  pop rsi
000078f8213e09eb  pop rdi
000078f8213e09ec  pop rdx
000078f8213e09ed  pop rcx
000078f8213e09ee  pop rax
000078f8213e09ef  add rsp, 0x08
000078f8213e09f3  jmp 0x000078F8213DC658
000078f8213e09f8  sub rsp, 0x08
000078f8213e09fc  push rax
000078f8213e09fd  push rcx
000078f8213e09fe  push rdx
000078f8213e09ff  push rdi
000078f8213e0a00  push rsi
000078f8213e0a01  push r8
000078f8213e0a03  push r9
000078f8213e0a05  push r10
000078f8213e0a07  push r11
000078f8213e0a09  sub rsp, 0xF0
000078f8213e0a10  vmovaps [rsp], xmm0
000078f8213e0a15  vmovaps [rsp+0x10], xmm1
000078f8213e0a1b  vmovaps [rsp+0x20], xmm2
000078f8213e0a21  vmovaps [rsp+0x30], xmm3
000078f8213e0a27  vmovaps [rsp+0x40], xmm4
000078f8213e0a2d  vmovaps [rsp+0x50], xmm5
000078f8213e0a33  vmovaps [rsp+0x60], xmm6
000078f8213e0a39  vmovaps [rsp+0x70], xmm8
000078f8213e0a3f  vmovaps [rsp+0x80], xmm9
000078f8213e0a48  vmovaps [rsp+0x90], xmm10
000078f8213e0a51  vmovaps [rsp+0xA0], xmm11
000078f8213e0a5a  vmovaps [rsp+0xB0], xmm12
000078f8213e0a63  vmovaps [rsp+0xC0], xmm13
000078f8213e0a6c  vmovaps [rsp+0xD0], xmm14
000078f8213e0a75  vmovaps [rsp+0xE0], xmm15
000078f8213e0a7e  sub rsp, 0x30
000078f8213e0a82  movaps [rsp], xmm7
000078f8213e0a86  movaps [rsp+0x10], xmm11
000078f8213e0a8c  movaps [rsp+0x20], xmm9
000078f8213e0a92  lea rdi, [rsp]
000078f8213e0a96  mov esi, 0x00
000078f8213e0a9b  mov rax, 0x653D80F42530
000078f8213e0aa5  call rax
000078f8213e0aa7  movaps xmm7, [rsp]
000078f8213e0aab  add rsp, 0x30
000078f8213e0aaf  vmovaps xmm0, [rsp]
000078f8213e0ab4  vmovaps xmm1, [rsp+0x10]
000078f8213e0aba  vmovaps xmm2, [rsp+0x20]
000078f8213e0ac0  vmovaps xmm3, [rsp+0x30]
000078f8213e0ac6  vmovaps xmm4, [rsp+0x40]
000078f8213e0acc  vmovaps xmm5, [rsp+0x50]
000078f8213e0ad2  vmovaps xmm6, [rsp+0x60]
000078f8213e0ad8  vmovaps xmm8, [rsp+0x70]
000078f8213e0ade  vmovaps xmm9, [rsp+0x80]
000078f8213e0ae7  vmovaps xmm10, [rsp+0x90]
000078f8213e0af0  vmovaps xmm11, [rsp+0xA0]
000078f8213e0af9  vmovaps xmm12, [rsp+0xB0]
000078f8213e0b02  vmovaps xmm13, [rsp+0xC0]
000078f8213e0b0b  vmovaps xmm14, [rsp+0xD0]
000078f8213e0b14  vmovaps xmm15, [rsp+0xE0]
000078f8213e0b1d  add rsp, 0xF0
000078f8213e0b24  pop r11
000078f8213e0b26  pop r10
000078f8213e0b28  pop r9
000078f8213e0b2a  pop r8
000078f8213e0b2c  pop rsi
000078f8213e0b2d  pop rdi
000078f8213e0b2e  pop rdx
000078f8213e0b2f  pop rcx
000078f8213e0b30  pop rax
000078f8213e0b31  add rsp, 0x08
000078f8213e0b35  jmp 0x000078F8213DC685
000078f8213e0b3a  sub rsp, 0x08
000078f8213e0b3e  push rax
000078f8213e0b3f  push rcx
000078f8213e0b40  push rdx
000078f8213e0b41  push rdi
000078f8213e0b42  push rsi
000078f8213e0b43  push r8
000078f8213e0b45  push r9
000078f8213e0b47  push r10
000078f8213e0b49  push r11
000078f8213e0b4b  sub rsp, 0xF0
000078f8213e0b52  vmovaps [rsp], xmm0
000078f8213e0b57  vmovaps [rsp+0x10], xmm1
000078f8213e0b5d  vmovaps [rsp+0x20], xmm2
000078f8213e0b63  vmovaps [rsp+0x30], xmm3
000078f8213e0b69  vmovaps [rsp+0x40], xmm4
000078f8213e0b6f  vmovaps [rsp+0x50], xmm5
000078f8213e0b75  vmovaps [rsp+0x60], xmm6
000078f8213e0b7b  vmovaps [rsp+0x70], xmm7
000078f8213e0b81  vmovaps [rsp+0x80], xmm8
000078f8213e0b8a  vmovaps [rsp+0x90], xmm9
000078f8213e0b93  vmovaps [rsp+0xA0], xmm10
000078f8213e0b9c  vmovaps [rsp+0xB0], xmm12
000078f8213e0ba5  vmovaps [rsp+0xC0], xmm13
000078f8213e0bae  vmovaps [rsp+0xD0], xmm14
000078f8213e0bb7  vmovaps [rsp+0xE0], xmm15
000078f8213e0bc0  sub rsp, 0x30
000078f8213e0bc4  movaps [rsp], xmm11
000078f8213e0bc9  movaps [rsp+0x10], xmm10
000078f8213e0bcf  movaps [rsp+0x20], xmm14
000078f8213e0bd5  lea rdi, [rsp]
000078f8213e0bd9  mov esi, 0x00
000078f8213e0bde  mov rax, 0x653D80F42530
000078f8213e0be8  call rax
000078f8213e0bea  movaps xmm11, [rsp]
000078f8213e0bef  add rsp, 0x30
000078f8213e0bf3  vmovaps xmm0, [rsp]
000078f8213e0bf8  vmovaps xmm1, [rsp+0x10]
000078f8213e0bfe  vmovaps xmm2, [rsp+0x20]
000078f8213e0c04  vmovaps xmm3, [rsp+0x30]
000078f8213e0c0a  vmovaps xmm4, [rsp+0x40]
000078f8213e0c10  vmovaps xmm5, [rsp+0x50]
000078f8213e0c16  vmovaps xmm6, [rsp+0x60]
000078f8213e0c1c  vmovaps xmm7, [rsp+0x70]
000078f8213e0c22  vmovaps xmm8, [rsp+0x80]
000078f8213e0c2b  vmovaps xmm9, [rsp+0x90]
000078f8213e0c34  vmovaps xmm10, [rsp+0xA0]
000078f8213e0c3d  vmovaps xmm12, [rsp+0xB0]
000078f8213e0c46  vmovaps xmm13, [rsp+0xC0]
000078f8213e0c4f  vmovaps xmm14, [rsp+0xD0]
000078f8213e0c58  vmovaps xmm15, [rsp+0xE0]
000078f8213e0c61  add rsp, 0xF0
000078f8213e0c68  pop r11
000078f8213e0c6a  pop r10
000078f8213e0c6c  pop r9
000078f8213e0c6e  pop r8
000078f8213e0c70  pop rsi
000078f8213e0c71  pop rdi
000078f8213e0c72  pop rdx
000078f8213e0c73  pop rcx
000078f8213e0c74  pop rax
000078f8213e0c75  add rsp, 0x08
000078f8213e0c79  jmp 0x000078F8213DC6A0
000078f8213e0c7e  call 0x000078F8212C33A0
000078f8213e0c83  jmp 0x000078F8213DC6AA
000078f8213e0c88  sub rsp, 0x08
000078f8213e0c8c  push rax
000078f8213e0c8d  push rcx
000078f8213e0c8e  push rdx
000078f8213e0c8f  push rdi
000078f8213e0c90  push rsi
000078f8213e0c91  push r8
000078f8213e0c93  push r9
000078f8213e0c95  push r10
000078f8213e0c97  push r11
000078f8213e0c99  sub rsp, 0xF0
000078f8213e0ca0  vmovaps [rsp], xmm0
000078f8213e0ca5  vmovaps [rsp+0x10], xmm1
000078f8213e0cab  vmovaps [rsp+0x20], xmm2
000078f8213e0cb1  vmovaps [rsp+0x30], xmm3
000078f8213e0cb7  vmovaps [rsp+0x40], xmm4
000078f8213e0cbd  vmovaps [rsp+0x50], xmm5
000078f8213e0cc3  vmovaps [rsp+0x60], xmm6
000078f8213e0cc9  vmovaps [rsp+0x70], xmm7
000078f8213e0ccf  vmovaps [rsp+0x80], xmm8
000078f8213e0cd8  vmovaps [rsp+0x90], xmm9
000078f8213e0ce1  vmovaps [rsp+0xA0], xmm11
000078f8213e0cea  vmovaps [rsp+0xB0], xmm12
000078f8213e0cf3  vmovaps [rsp+0xC0], xmm13
000078f8213e0cfc  vmovaps [rsp+0xD0], xmm14
000078f8213e0d05  vmovaps [rsp+0xE0], xmm15
000078f8213e0d0e  sub rsp, 0x30
000078f8213e0d12  movaps [rsp], xmm10
000078f8213e0d17  movaps [rsp+0x10], xmm1
000078f8213e0d1c  movaps [rsp+0x20], xmm12
000078f8213e0d22  lea rdi, [rsp]
000078f8213e0d26  mov esi, 0x00
000078f8213e0d2b  mov rax, 0x653D80F42530
000078f8213e0d35  call rax
000078f8213e0d37  movaps xmm10, [rsp]
000078f8213e0d3c  add rsp, 0x30
000078f8213e0d40  vmovaps xmm0, [rsp]
000078f8213e0d45  vmovaps xmm1, [rsp+0x10]
000078f8213e0d4b  vmovaps xmm2, [rsp+0x20]
000078f8213e0d51  vmovaps xmm3, [rsp+0x30]
000078f8213e0d57  vmovaps xmm4, [rsp+0x40]
000078f8213e0d5d  vmovaps xmm5, [rsp+0x50]
000078f8213e0d63  vmovaps xmm6, [rsp+0x60]
000078f8213e0d69  vmovaps xmm7, [rsp+0x70]
000078f8213e0d6f  vmovaps xmm8, [rsp+0x80]
000078f8213e0d78  vmovaps xmm9, [rsp+0x90]
000078f8213e0d81  vmovaps xmm11, [rsp+0xA0]
000078f8213e0d8a  vmovaps xmm12, [rsp+0xB0]
000078f8213e0d93  vmovaps xmm13, [rsp+0xC0]
000078f8213e0d9c  vmovaps xmm14, [rsp+0xD0]
000078f8213e0da5  vmovaps xmm15, [rsp+0xE0]
000078f8213e0dae  add rsp, 0xF0
000078f8213e0db5  pop r11
000078f8213e0db7  pop r10
000078f8213e0db9  pop r9
000078f8213e0dbb  pop r8
000078f8213e0dbd  pop rsi
000078f8213e0dbe  pop rdi
000078f8213e0dbf  pop rdx
000078f8213e0dc0  pop rcx
000078f8213e0dc1  pop rax
000078f8213e0dc2  add rsp, 0x08
000078f8213e0dc6  jmp 0x000078F8213DC6CD
000078f8213e0dcb  sub rsp, 0x08
000078f8213e0dcf  push rax
000078f8213e0dd0  push rcx
000078f8213e0dd1  push rdx
000078f8213e0dd2  push rdi
000078f8213e0dd3  push rsi
000078f8213e0dd4  push r8
000078f8213e0dd6  push r9
000078f8213e0dd8  push r10
000078f8213e0dda  push r11
000078f8213e0ddc  sub rsp, 0xF0
000078f8213e0de3  vmovaps [rsp], xmm0
000078f8213e0de8  vmovaps [rsp+0x10], xmm1
000078f8213e0dee  vmovaps [rsp+0x20], xmm2
000078f8213e0df4  vmovaps [rsp+0x30], xmm3
000078f8213e0dfa  vmovaps [rsp+0x40], xmm4
000078f8213e0e00  vmovaps [rsp+0x50], xmm5
000078f8213e0e06  vmovaps [rsp+0x60], xmm6
000078f8213e0e0c  vmovaps [rsp+0x70], xmm7
000078f8213e0e12  vmovaps [rsp+0x80], xmm8
000078f8213e0e1b  vmovaps [rsp+0x90], xmm9
000078f8213e0e24  vmovaps [rsp+0xA0], xmm10
000078f8213e0e2d  vmovaps [rsp+0xB0], xmm11
000078f8213e0e36  vmovaps [rsp+0xC0], xmm13
000078f8213e0e3f  vmovaps [rsp+0xD0], xmm14
000078f8213e0e48  vmovaps [rsp+0xE0], xmm15
000078f8213e0e51  sub rsp, 0x30
000078f8213e0e55  movaps [rsp], xmm12
000078f8213e0e5a  movaps [rsp+0x10], xmm14
000078f8213e0e60  movaps [rsp+0x20], xmm1
000078f8213e0e65  lea rdi, [rsp]
000078f8213e0e69  mov esi, 0x00
000078f8213e0e6e  mov rax, 0x653D80F42530
000078f8213e0e78  call rax
000078f8213e0e7a  movaps xmm12, [rsp]
000078f8213e0e7f  add rsp, 0x30
000078f8213e0e83  vmovaps xmm0, [rsp]
000078f8213e0e88  vmovaps xmm1, [rsp+0x10]
000078f8213e0e8e  vmovaps xmm2, [rsp+0x20]
000078f8213e0e94  vmovaps xmm3, [rsp+0x30]
000078f8213e0e9a  vmovaps xmm4, [rsp+0x40]
000078f8213e0ea0  vmovaps xmm5, [rsp+0x50]
000078f8213e0ea6  vmovaps xmm6, [rsp+0x60]
000078f8213e0eac  vmovaps xmm7, [rsp+0x70]
000078f8213e0eb2  vmovaps xmm8, [rsp+0x80]
000078f8213e0ebb  vmovaps xmm9, [rsp+0x90]
000078f8213e0ec4  vmovaps xmm10, [rsp+0xA0]
000078f8213e0ecd  vmovaps xmm11, [rsp+0xB0]
000078f8213e0ed6  vmovaps xmm13, [rsp+0xC0]
000078f8213e0edf  vmovaps xmm14, [rsp+0xD0]
000078f8213e0ee8  vmovaps xmm15, [rsp+0xE0]
000078f8213e0ef1  add rsp, 0xF0
000078f8213e0ef8  pop r11
000078f8213e0efa  pop r10
000078f8213e0efc  pop r9
000078f8213e0efe  pop r8
000078f8213e0f00  pop rsi
000078f8213e0f01  pop rdi
000078f8213e0f02  pop rdx
000078f8213e0f03  pop rcx
000078f8213e0f04  pop rax
000078f8213e0f05  add rsp, 0x08
000078f8213e0f09  jmp 0x000078F8213DC6FC
000078f8213e0f0e  sub rsp, 0x08
000078f8213e0f12  push rax
000078f8213e0f13  push rcx
000078f8213e0f14  push rdx
000078f8213e0f15  push rdi
000078f8213e0f16  push rsi
000078f8213e0f17  push r8
000078f8213e0f19  push r9
000078f8213e0f1b  push r10
000078f8213e0f1d  push r11
000078f8213e0f1f  sub rsp, 0xF0
000078f8213e0f26  vmovaps [rsp], xmm0
000078f8213e0f2b  vmovaps [rsp+0x10], xmm1
000078f8213e0f31  vmovaps [rsp+0x20], xmm2
000078f8213e0f37  vmovaps [rsp+0x30], xmm3
000078f8213e0f3d  vmovaps [rsp+0x40], xmm4
000078f8213e0f43  vmovaps [rsp+0x50], xmm5
000078f8213e0f49  vmovaps [rsp+0x60], xmm6
000078f8213e0f4f  vmovaps [rsp+0x70], xmm7
000078f8213e0f55  vmovaps [rsp+0x80], xmm8
000078f8213e0f5e  vmovaps [rsp+0x90], xmm9
000078f8213e0f67  vmovaps [rsp+0xA0], xmm10
000078f8213e0f70  vmovaps [rsp+0xB0], xmm11
000078f8213e0f79  vmovaps [rsp+0xC0], xmm12
000078f8213e0f82  vmovaps [rsp+0xD0], xmm13
000078f8213e0f8b  vmovaps [rsp+0xE0], xmm15
000078f8213e0f94  sub rsp, 0x30
000078f8213e0f98  movaps [rsp], xmm14
000078f8213e0f9d  movaps [rsp+0x10], xmm9
000078f8213e0fa3  movaps [rsp+0x20], xmm1
000078f8213e0fa8  lea rdi, [rsp]
000078f8213e0fac  mov esi, 0x00
000078f8213e0fb1  mov rax, 0x653D80F42530
000078f8213e0fbb  call rax
000078f8213e0fbd  movaps xmm14, [rsp]
000078f8213e0fc2  add rsp, 0x30
000078f8213e0fc6  vmovaps xmm0, [rsp]
000078f8213e0fcb  vmovaps xmm1, [rsp+0x10]
000078f8213e0fd1  vmovaps xmm2, [rsp+0x20]
000078f8213e0fd7  vmovaps xmm3, [rsp+0x30]
000078f8213e0fdd  vmovaps xmm4, [rsp+0x40]
000078f8213e0fe3  vmovaps xmm5, [rsp+0x50]
000078f8213e0fe9  vmovaps xmm6, [rsp+0x60]
000078f8213e0fef  vmovaps xmm7, [rsp+0x70]
000078f8213e0ff5  vmovaps xmm8, [rsp+0x80]
000078f8213e0ffe  vmovaps xmm9, [rsp+0x90]
000078f8213e1007  vmovaps xmm10, [rsp+0xA0]
000078f8213e1010  vmovaps xmm11, [rsp+0xB0]
000078f8213e1019  vmovaps xmm12, [rsp+0xC0]
000078f8213e1022  vmovaps xmm13, [rsp+0xD0]
000078f8213e102b  vmovaps xmm15, [rsp+0xE0]
000078f8213e1034  add rsp, 0xF0
000078f8213e103b  pop r11
000078f8213e103d  pop r10
000078f8213e103f  pop r9
000078f8213e1041  pop r8
000078f8213e1043  pop rsi
000078f8213e1044  pop rdi
000078f8213e1045  pop rdx
000078f8213e1046  pop rcx
000078f8213e1047  pop rax
000078f8213e1048  add rsp, 0x08
000078f8213e104c  jmp 0x000078F8213DC72B
000078f8213e1051  sub rsp, 0x08
000078f8213e1055  push rax
000078f8213e1056  push rcx
000078f8213e1057  push rdx
000078f8213e1058  push rdi
000078f8213e1059  push rsi
000078f8213e105a  push r8
000078f8213e105c  push r9
000078f8213e105e  push r10
000078f8213e1060  push r11
000078f8213e1062  sub rsp, 0xF0
000078f8213e1069  vmovaps [rsp], xmm0
000078f8213e106e  vmovaps [rsp+0x10], xmm2
000078f8213e1074  vmovaps [rsp+0x20], xmm3
000078f8213e107a  vmovaps [rsp+0x30], xmm4
000078f8213e1080  vmovaps [rsp+0x40], xmm5
000078f8213e1086  vmovaps [rsp+0x50], xmm6
000078f8213e108c  vmovaps [rsp+0x60], xmm7
000078f8213e1092  vmovaps [rsp+0x70], xmm8
000078f8213e1098  vmovaps [rsp+0x80], xmm9
000078f8213e10a1  vmovaps [rsp+0x90], xmm10
000078f8213e10aa  vmovaps [rsp+0xA0], xmm11
000078f8213e10b3  vmovaps [rsp+0xB0], xmm12
000078f8213e10bc  vmovaps [rsp+0xC0], xmm13
000078f8213e10c5  vmovaps [rsp+0xD0], xmm14
000078f8213e10ce  vmovaps [rsp+0xE0], xmm15
000078f8213e10d7  sub rsp, 0x30
000078f8213e10db  movaps [rsp], xmm1
000078f8213e10df  movaps [rsp+0x10], xmm13
000078f8213e10e5  movaps [rsp+0x20], xmm8
000078f8213e10eb  lea rdi, [rsp]
000078f8213e10ef  mov esi, 0x00
000078f8213e10f4  mov rax, 0x653D80F42530
000078f8213e10fe  call rax
000078f8213e1100  movaps xmm1, [rsp]
000078f8213e1104  add rsp, 0x30
000078f8213e1108  vmovaps xmm0, [rsp]
000078f8213e110d  vmovaps xmm2, [rsp+0x10]
000078f8213e1113  vmovaps xmm3, [rsp+0x20]
000078f8213e1119  vmovaps xmm4, [rsp+0x30]
000078f8213e111f  vmovaps xmm5, [rsp+0x40]
000078f8213e1125  vmovaps xmm6, [rsp+0x50]
000078f8213e112b  vmovaps xmm7, [rsp+0x60]
000078f8213e1131  vmovaps xmm8, [rsp+0x70]
000078f8213e1137  vmovaps xmm9, [rsp+0x80]
000078f8213e1140  vmovaps xmm10, [rsp+0x90]
000078f8213e1149  vmovaps xmm11, [rsp+0xA0]
000078f8213e1152  vmovaps xmm12, [rsp+0xB0]
000078f8213e115b  vmovaps xmm13, [rsp+0xC0]
000078f8213e1164  vmovaps xmm14, [rsp+0xD0]
000078f8213e116d  vmovaps xmm15, [rsp+0xE0]
000078f8213e1176  add rsp, 0xF0
000078f8213e117d  pop r11
000078f8213e117f  pop r10
000078f8213e1181  pop r9
000078f8213e1183  pop r8
000078f8213e1185  pop rsi
000078f8213e1186  pop rdi
000078f8213e1187  pop rdx
000078f8213e1188  pop rcx
000078f8213e1189  pop rax
000078f8213e118a  add rsp, 0x08
000078f8213e118e  jmp 0x000078F8213DC74D
000078f8213e1193  call 0x000078F82120C260
000078f8213e1198  jmp 0x000078F8213DC75B
000078f8213e119d  call 0x000078F8212BD750
000078f8213e11a2  jmp 0x000078F8213DC765
000078f8213e11a7  sub rsp, 0x08
000078f8213e11ab  push rax
000078f8213e11ac  push rcx
000078f8213e11ad  push rdx
000078f8213e11ae  push rdi
000078f8213e11af  push rsi
000078f8213e11b0  push r8
000078f8213e11b2  push r9
000078f8213e11b4  push r10
000078f8213e11b6  push r11
000078f8213e11b8  sub rsp, 0xF0
000078f8213e11bf  vmovaps [rsp], xmm0
000078f8213e11c4  vmovaps [rsp+0x10], xmm1
000078f8213e11ca  vmovaps [rsp+0x20], xmm2
000078f8213e11d0  vmovaps [rsp+0x30], xmm3
000078f8213e11d6  vmovaps [rsp+0x40], xmm4
000078f8213e11dc  vmovaps [rsp+0x50], xmm5
000078f8213e11e2  vmovaps [rsp+0x60], xmm6
000078f8213e11e8  vmovaps [rsp+0x70], xmm7
000078f8213e11ee  vmovaps [rsp+0x80], xmm9
000078f8213e11f7  vmovaps [rsp+0x90], xmm10
000078f8213e1200  vmovaps [rsp+0xA0], xmm11
000078f8213e1209  vmovaps [rsp+0xB0], xmm12
000078f8213e1212  vmovaps [rsp+0xC0], xmm13
000078f8213e121b  vmovaps [rsp+0xD0], xmm14
000078f8213e1224  vmovaps [rsp+0xE0], xmm15
000078f8213e122d  sub rsp, 0x30
000078f8213e1231  movaps [rsp], xmm8
000078f8213e1236  movaps [rsp+0x10], xmm15
000078f8213e123c  movaps [rsp+0x20], xmm7
000078f8213e1241  lea rdi, [rsp]
000078f8213e1245  mov esi, 0x00
000078f8213e124a  mov rax, 0x653D80F42530
000078f8213e1254  call rax
000078f8213e1256  movaps xmm8, [rsp]
000078f8213e125b  add rsp, 0x30
000078f8213e125f  vmovaps xmm0, [rsp]
000078f8213e1264  vmovaps xmm1, [rsp+0x10]
000078f8213e126a  vmovaps xmm2, [rsp+0x20]
000078f8213e1270  vmovaps xmm3, [rsp+0x30]
000078f8213e1276  vmovaps xmm4, [rsp+0x40]
000078f8213e127c  vmovaps xmm5, [rsp+0x50]
000078f8213e1282  vmovaps xmm6, [rsp+0x60]
000078f8213e1288  vmovaps xmm7, [rsp+0x70]
000078f8213e128e  vmovaps xmm9, [rsp+0x80]
000078f8213e1297  vmovaps xmm10, [rsp+0x90]
000078f8213e12a0  vmovaps xmm11, [rsp+0xA0]
000078f8213e12a9  vmovaps xmm12, [rsp+0xB0]
000078f8213e12b2  vmovaps xmm13, [rsp+0xC0]
000078f8213e12bb  vmovaps xmm14, [rsp+0xD0]
000078f8213e12c4  vmovaps xmm15, [rsp+0xE0]
000078f8213e12cd  add rsp, 0xF0
000078f8213e12d4  pop r11
000078f8213e12d6  pop r10
000078f8213e12d8  pop r9
000078f8213e12da  pop r8
000078f8213e12dc  pop rsi
000078f8213e12dd  pop rdi
000078f8213e12de  pop rdx
000078f8213e12df  pop rcx
000078f8213e12e0  pop rax
000078f8213e12e1  add rsp, 0x08
000078f8213e12e5  jmp 0x000078F8213DC787
000078f8213e12ea  sub rsp, 0x08
000078f8213e12ee  push rax
000078f8213e12ef  push rcx
000078f8213e12f0  push rdx
000078f8213e12f1  push rdi
000078f8213e12f2  push rsi
000078f8213e12f3  push r8
000078f8213e12f5  push r9
000078f8213e12f7  push r10
000078f8213e12f9  push r11
000078f8213e12fb  sub rsp, 0xF0
000078f8213e1302  vmovaps [rsp], xmm0
000078f8213e1307  vmovaps [rsp+0x10], xmm1
000078f8213e130d  vmovaps [rsp+0x20], xmm2
000078f8213e1313  vmovaps [rsp+0x30], xmm3
000078f8213e1319  vmovaps [rsp+0x40], xmm4
000078f8213e131f  vmovaps [rsp+0x50], xmm5
000078f8213e1325  vmovaps [rsp+0x60], xmm6
000078f8213e132b  vmovaps [rsp+0x70], xmm8
000078f8213e1331  vmovaps [rsp+0x80], xmm9
000078f8213e133a  vmovaps [rsp+0x90], xmm10
000078f8213e1343  vmovaps [rsp+0xA0], xmm11
000078f8213e134c  vmovaps [rsp+0xB0], xmm12
000078f8213e1355  vmovaps [rsp+0xC0], xmm13
000078f8213e135e  vmovaps [rsp+0xD0], xmm14
000078f8213e1367  vmovaps [rsp+0xE0], xmm15
000078f8213e1370  sub rsp, 0x30
000078f8213e1374  movaps [rsp], xmm7
000078f8213e1378  movaps [rsp+0x10], xmm9
000078f8213e137e  movaps [rsp+0x20], xmm15
000078f8213e1384  lea rdi, [rsp]
000078f8213e1388  mov esi, 0x00
000078f8213e138d  mov rax, 0x653D80F42530
000078f8213e1397  call rax
000078f8213e1399  movaps xmm7, [rsp]
000078f8213e139d  add rsp, 0x30
000078f8213e13a1  vmovaps xmm0, [rsp]
000078f8213e13a6  vmovaps xmm1, [rsp+0x10]
000078f8213e13ac  vmovaps xmm2, [rsp+0x20]
000078f8213e13b2  vmovaps xmm3, [rsp+0x30]
000078f8213e13b8  vmovaps xmm4, [rsp+0x40]
000078f8213e13be  vmovaps xmm5, [rsp+0x50]
000078f8213e13c4  vmovaps xmm6, [rsp+0x60]
000078f8213e13ca  vmovaps xmm8, [rsp+0x70]
000078f8213e13d0  vmovaps xmm9, [rsp+0x80]
000078f8213e13d9  vmovaps xmm10, [rsp+0x90]
000078f8213e13e2  vmovaps xmm11, [rsp+0xA0]
000078f8213e13eb  vmovaps xmm12, [rsp+0xB0]
000078f8213e13f4  vmovaps xmm13, [rsp+0xC0]
000078f8213e13fd  vmovaps xmm14, [rsp+0xD0]
000078f8213e1406  vmovaps xmm15, [rsp+0xE0]
000078f8213e140f  add rsp, 0xF0
000078f8213e1416  pop r11
000078f8213e1418  pop r10
000078f8213e141a  pop r9
000078f8213e141c  pop r8
000078f8213e141e  pop rsi
000078f8213e141f  pop rdi
000078f8213e1420  pop rdx
000078f8213e1421  pop rcx
000078f8213e1422  pop rax
000078f8213e1423  add rsp, 0x08
000078f8213e1427  jmp 0x000078F8213DC7B4
000078f8213e142c  sub rsp, 0x08
000078f8213e1430  push rax
000078f8213e1431  push rcx
000078f8213e1432  push rdx
000078f8213e1433  push rdi
000078f8213e1434  push rsi
000078f8213e1435  push r8
000078f8213e1437  push r9
000078f8213e1439  push r10
000078f8213e143b  push r11
000078f8213e143d  sub rsp, 0xF0
000078f8213e1444  vmovaps [rsp], xmm0
000078f8213e1449  vmovaps [rsp+0x10], xmm1
000078f8213e144f  vmovaps [rsp+0x20], xmm2
000078f8213e1455  vmovaps [rsp+0x30], xmm3
000078f8213e145b  vmovaps [rsp+0x40], xmm4
000078f8213e1461  vmovaps [rsp+0x50], xmm5
000078f8213e1467  vmovaps [rsp+0x60], xmm6
000078f8213e146d  vmovaps [rsp+0x70], xmm7
000078f8213e1473  vmovaps [rsp+0x80], xmm8
000078f8213e147c  vmovaps [rsp+0x90], xmm10
000078f8213e1485  vmovaps [rsp+0xA0], xmm11
000078f8213e148e  vmovaps [rsp+0xB0], xmm12
000078f8213e1497  vmovaps [rsp+0xC0], xmm13
000078f8213e14a0  vmovaps [rsp+0xD0], xmm14
000078f8213e14a9  vmovaps [rsp+0xE0], xmm15
000078f8213e14b2  sub rsp, 0x30
000078f8213e14b6  movaps [rsp], xmm9
000078f8213e14bb  movaps [rsp+0x10], xmm13
000078f8213e14c1  movaps [rsp+0x20], xmm15
000078f8213e14c7  lea rdi, [rsp]
000078f8213e14cb  mov esi, 0x00
000078f8213e14d0  mov rax, 0x653D80F42530
000078f8213e14da  call rax
000078f8213e14dc  movaps xmm9, [rsp]
000078f8213e14e1  add rsp, 0x30
000078f8213e14e5  vmovaps xmm0, [rsp]
000078f8213e14ea  vmovaps xmm1, [rsp+0x10]
000078f8213e14f0  vmovaps xmm2, [rsp+0x20]
000078f8213e14f6  vmovaps xmm3, [rsp+0x30]
000078f8213e14fc  vmovaps xmm4, [rsp+0x40]
000078f8213e1502  vmovaps xmm5, [rsp+0x50]
000078f8213e1508  vmovaps xmm6, [rsp+0x60]
000078f8213e150e  vmovaps xmm7, [rsp+0x70]
000078f8213e1514  vmovaps xmm8, [rsp+0x80]
000078f8213e151d  vmovaps xmm10, [rsp+0x90]
000078f8213e1526  vmovaps xmm11, [rsp+0xA0]
000078f8213e152f  vmovaps xmm12, [rsp+0xB0]
000078f8213e1538  vmovaps xmm13, [rsp+0xC0]
000078f8213e1541  vmovaps xmm14, [rsp+0xD0]
000078f8213e154a  vmovaps xmm15, [rsp+0xE0]
000078f8213e1553  add rsp, 0xF0
000078f8213e155a  pop r11
000078f8213e155c  pop r10
000078f8213e155e  pop r9
000078f8213e1560  pop r8
000078f8213e1562  pop rsi
000078f8213e1563  pop rdi
000078f8213e1564  pop rdx
000078f8213e1565  pop rcx
000078f8213e1566  pop rax
000078f8213e1567  add rsp, 0x08
000078f8213e156b  jmp 0x000078F8213DC7E2
000078f8213e1570  sub rsp, 0x08
000078f8213e1574  push rax
000078f8213e1575  push rcx
000078f8213e1576  push rdx
000078f8213e1577  push rdi
000078f8213e1578  push rsi
000078f8213e1579  push r8
000078f8213e157b  push r9
000078f8213e157d  push r10
000078f8213e157f  push r11
000078f8213e1581  sub rsp, 0xF0
000078f8213e1588  vmovaps [rsp], xmm0
000078f8213e158d  vmovaps [rsp+0x10], xmm1
000078f8213e1593  vmovaps [rsp+0x20], xmm2
000078f8213e1599  vmovaps [rsp+0x30], xmm3
000078f8213e159f  vmovaps [rsp+0x40], xmm4
000078f8213e15a5  vmovaps [rsp+0x50], xmm5
000078f8213e15ab  vmovaps [rsp+0x60], xmm6
000078f8213e15b1  vmovaps [rsp+0x70], xmm7
000078f8213e15b7  vmovaps [rsp+0x80], xmm8
000078f8213e15c0  vmovaps [rsp+0x90], xmm9
000078f8213e15c9  vmovaps [rsp+0xA0], xmm10
000078f8213e15d2  vmovaps [rsp+0xB0], xmm11
000078f8213e15db  vmovaps [rsp+0xC0], xmm12
000078f8213e15e4  vmovaps [rsp+0xD0], xmm13
000078f8213e15ed  vmovaps [rsp+0xE0], xmm14
000078f8213e15f6  sub rsp, 0x30
000078f8213e15fa  movaps [rsp], xmm15
000078f8213e15ff  movaps [rsp+0x10], xmm11
000078f8213e1605  movaps [rsp+0x20], xmm12
000078f8213e160b  lea rdi, [rsp]
000078f8213e160f  mov esi, 0x00
000078f8213e1614  mov rax, 0x653D80F42530
000078f8213e161e  call rax
000078f8213e1620  movaps xmm15, [rsp]
000078f8213e1625  add rsp, 0x30
000078f8213e1629  vmovaps xmm0, [rsp]
000078f8213e162e  vmovaps xmm1, [rsp+0x10]
000078f8213e1634  vmovaps xmm2, [rsp+0x20]
000078f8213e163a  vmovaps xmm3, [rsp+0x30]
000078f8213e1640  vmovaps xmm4, [rsp+0x40]
000078f8213e1646  vmovaps xmm5, [rsp+0x50]
000078f8213e164c  vmovaps xmm6, [rsp+0x60]
000078f8213e1652  vmovaps xmm7, [rsp+0x70]
000078f8213e1658  vmovaps xmm8, [rsp+0x80]
000078f8213e1661  vmovaps xmm9, [rsp+0x90]
000078f8213e166a  vmovaps xmm10, [rsp+0xA0]
000078f8213e1673  vmovaps xmm11, [rsp+0xB0]
000078f8213e167c  vmovaps xmm12, [rsp+0xC0]
000078f8213e1685  vmovaps xmm13, [rsp+0xD0]
000078f8213e168e  vmovaps xmm14, [rsp+0xE0]
000078f8213e1697  add rsp, 0xF0
000078f8213e169e  pop r11
000078f8213e16a0  pop r10
000078f8213e16a2  pop r9
000078f8213e16a4  pop r8
000078f8213e16a6  pop rsi
000078f8213e16a7  pop rdi
000078f8213e16a8  pop rdx
000078f8213e16a9  pop rcx
000078f8213e16aa  pop rax
000078f8213e16ab  add rsp, 0x08
000078f8213e16af  jmp 0x000078F8213DC7FD
000078f8213e16b4  sub rsp, 0x08
000078f8213e16b8  push rax
000078f8213e16b9  push rcx
000078f8213e16ba  push rdx
000078f8213e16bb  push rdi
000078f8213e16bc  push rsi
000078f8213e16bd  push r8
000078f8213e16bf  push r9
000078f8213e16c1  push r10
000078f8213e16c3  push r11
000078f8213e16c5  sub rsp, 0xF0
000078f8213e16cc  vmovaps [rsp], xmm0
000078f8213e16d1  vmovaps [rsp+0x10], xmm1
000078f8213e16d7  vmovaps [rsp+0x20], xmm2
000078f8213e16dd  vmovaps [rsp+0x30], xmm3
000078f8213e16e3  vmovaps [rsp+0x40], xmm4
000078f8213e16e9  vmovaps [rsp+0x50], xmm5
000078f8213e16ef  vmovaps [rsp+0x60], xmm6
000078f8213e16f5  vmovaps [rsp+0x70], xmm7
000078f8213e16fb  vmovaps [rsp+0x80], xmm8
000078f8213e1704  vmovaps [rsp+0x90], xmm9
000078f8213e170d  vmovaps [rsp+0xA0], xmm10
000078f8213e1716  vmovaps [rsp+0xB0], xmm11
000078f8213e171f  vmovaps [rsp+0xC0], xmm12
000078f8213e1728  vmovaps [rsp+0xD0], xmm14
000078f8213e1731  vmovaps [rsp+0xE0], xmm15
000078f8213e173a  sub rsp, 0x30
000078f8213e173e  movaps [rsp], xmm13
000078f8213e1743  movaps [rsp+0x10], xmm10
000078f8213e1749  movaps [rsp+0x20], xmm14
000078f8213e174f  lea rdi, [rsp]
000078f8213e1753  mov esi, 0x00
000078f8213e1758  mov rax, 0x653D80F42530
000078f8213e1762  call rax
000078f8213e1764  movaps xmm13, [rsp]
000078f8213e1769  add rsp, 0x30
000078f8213e176d  vmovaps xmm0, [rsp]
000078f8213e1772  vmovaps xmm1, [rsp+0x10]
000078f8213e1778  vmovaps xmm2, [rsp+0x20]
000078f8213e177e  vmovaps xmm3, [rsp+0x30]
000078f8213e1784  vmovaps xmm4, [rsp+0x40]
000078f8213e178a  vmovaps xmm5, [rsp+0x50]
000078f8213e1790  vmovaps xmm6, [rsp+0x60]
000078f8213e1796  vmovaps xmm7, [rsp+0x70]
000078f8213e179c  vmovaps xmm8, [rsp+0x80]
000078f8213e17a5  vmovaps xmm9, [rsp+0x90]
000078f8213e17ae  vmovaps xmm10, [rsp+0xA0]
000078f8213e17b7  vmovaps xmm11, [rsp+0xB0]
000078f8213e17c0  vmovaps xmm12, [rsp+0xC0]
000078f8213e17c9  vmovaps xmm14, [rsp+0xD0]
000078f8213e17d2  vmovaps xmm15, [rsp+0xE0]
000078f8213e17db  add rsp, 0xF0
000078f8213e17e2  pop r11
000078f8213e17e4  pop r10
000078f8213e17e6  pop r9
000078f8213e17e8  pop r8
000078f8213e17ea  pop rsi
000078f8213e17eb  pop rdi
000078f8213e17ec  pop rdx
000078f8213e17ed  pop rcx
000078f8213e17ee  pop rax
000078f8213e17ef  add rsp, 0x08
000078f8213e17f3  jmp 0x000078F8213DC820
000078f8213e17f8  sub rsp, 0x08
000078f8213e17fc  push rax
000078f8213e17fd  push rcx
000078f8213e17fe  push rdx
000078f8213e17ff  push rdi
000078f8213e1800  push rsi
000078f8213e1801  push r8
000078f8213e1803  push r9
000078f8213e1805  push r10
000078f8213e1807  push r11
000078f8213e1809  sub rsp, 0xF0
000078f8213e1810  vmovaps [rsp], xmm0
000078f8213e1815  vmovaps [rsp+0x10], xmm1
000078f8213e181b  vmovaps [rsp+0x20], xmm2
000078f8213e1821  vmovaps [rsp+0x30], xmm3
000078f8213e1827  vmovaps [rsp+0x40], xmm4
000078f8213e182d  vmovaps [rsp+0x50], xmm5
000078f8213e1833  vmovaps [rsp+0x60], xmm6
000078f8213e1839  vmovaps [rsp+0x70], xmm7
000078f8213e183f  vmovaps [rsp+0x80], xmm8
000078f8213e1848  vmovaps [rsp+0x90], xmm9
000078f8213e1851  vmovaps [rsp+0xA0], xmm10
000078f8213e185a  vmovaps [rsp+0xB0], xmm11
000078f8213e1863  vmovaps [rsp+0xC0], xmm12
000078f8213e186c  vmovaps [rsp+0xD0], xmm13
000078f8213e1875  vmovaps [rsp+0xE0], xmm15
000078f8213e187e  sub rsp, 0x30
000078f8213e1882  movaps [rsp], xmm14
000078f8213e1887  movaps [rsp+0x10], xmm1
000078f8213e188c  movaps [rsp+0x20], xmm7
000078f8213e1891  lea rdi, [rsp]
000078f8213e1895  mov esi, 0x00
000078f8213e189a  mov rax, 0x653D80F42530
000078f8213e18a4  call rax
000078f8213e18a6  movaps xmm14, [rsp]
000078f8213e18ab  add rsp, 0x30
000078f8213e18af  vmovaps xmm0, [rsp]
000078f8213e18b4  vmovaps xmm1, [rsp+0x10]
000078f8213e18ba  vmovaps xmm2, [rsp+0x20]
000078f8213e18c0  vmovaps xmm3, [rsp+0x30]
000078f8213e18c6  vmovaps xmm4, [rsp+0x40]
000078f8213e18cc  vmovaps xmm5, [rsp+0x50]
000078f8213e18d2  vmovaps xmm6, [rsp+0x60]
000078f8213e18d8  vmovaps xmm7, [rsp+0x70]
000078f8213e18de  vmovaps xmm8, [rsp+0x80]
000078f8213e18e7  vmovaps xmm9, [rsp+0x90]
000078f8213e18f0  vmovaps xmm10, [rsp+0xA0]
000078f8213e18f9  vmovaps xmm11, [rsp+0xB0]
000078f8213e1902  vmovaps xmm12, [rsp+0xC0]
000078f8213e190b  vmovaps xmm13, [rsp+0xD0]
000078f8213e1914  vmovaps xmm15, [rsp+0xE0]
000078f8213e191d  add rsp, 0xF0
000078f8213e1924  pop r11
000078f8213e1926  pop r10
000078f8213e1928  pop r9
000078f8213e192a  pop r8
000078f8213e192c  pop rsi
000078f8213e192d  pop rdi
000078f8213e192e  pop rdx
000078f8213e192f  pop rcx
000078f8213e1930  pop rax
000078f8213e1931  add rsp, 0x08
000078f8213e1935  jmp 0x000078F8213DC843
000078f8213e193a  sub rsp, 0x08
000078f8213e193e  push rax
000078f8213e193f  push rcx
000078f8213e1940  push rdx
000078f8213e1941  push rdi
000078f8213e1942  push rsi
000078f8213e1943  push r8
000078f8213e1945  push r9
000078f8213e1947  push r10
000078f8213e1949  push r11
000078f8213e194b  sub rsp, 0xF0
000078f8213e1952  vmovaps [rsp], xmm0
000078f8213e1957  vmovaps [rsp+0x10], xmm2
000078f8213e195d  vmovaps [rsp+0x20], xmm3
000078f8213e1963  vmovaps [rsp+0x30], xmm4
000078f8213e1969  vmovaps [rsp+0x40], xmm5
000078f8213e196f  vmovaps [rsp+0x50], xmm6
000078f8213e1975  vmovaps [rsp+0x60], xmm7
000078f8213e197b  vmovaps [rsp+0x70], xmm8
000078f8213e1981  vmovaps [rsp+0x80], xmm9
000078f8213e198a  vmovaps [rsp+0x90], xmm10
000078f8213e1993  vmovaps [rsp+0xA0], xmm11
000078f8213e199c  vmovaps [rsp+0xB0], xmm12
000078f8213e19a5  vmovaps [rsp+0xC0], xmm13
000078f8213e19ae  vmovaps [rsp+0xD0], xmm14
000078f8213e19b7  vmovaps [rsp+0xE0], xmm15
000078f8213e19c0  sub rsp, 0x30
000078f8213e19c4  movaps [rsp], xmm1
000078f8213e19c8  movaps [rsp+0x10], xmm8
000078f8213e19ce  movaps [rsp+0x20], xmm9
000078f8213e19d4  lea rdi, [rsp]
000078f8213e19d8  mov esi, 0x00
000078f8213e19dd  mov rax, 0x653D80F42530
000078f8213e19e7  call rax
000078f8213e19e9  movaps xmm1, [rsp]
000078f8213e19ed  add rsp, 0x30
000078f8213e19f1  vmovaps xmm0, [rsp]
000078f8213e19f6  vmovaps xmm2, [rsp+0x10]
000078f8213e19fc  vmovaps xmm3, [rsp+0x20]
000078f8213e1a02  vmovaps xmm4, [rsp+0x30]
000078f8213e1a08  vmovaps xmm5, [rsp+0x40]
000078f8213e1a0e  vmovaps xmm6, [rsp+0x50]
000078f8213e1a14  vmovaps xmm7, [rsp+0x60]
000078f8213e1a1a  vmovaps xmm8, [rsp+0x70]
000078f8213e1a20  vmovaps xmm9, [rsp+0x80]
000078f8213e1a29  vmovaps xmm10, [rsp+0x90]
000078f8213e1a32  vmovaps xmm11, [rsp+0xA0]
000078f8213e1a3b  vmovaps xmm12, [rsp+0xB0]
000078f8213e1a44  vmovaps xmm13, [rsp+0xC0]
000078f8213e1a4d  vmovaps xmm14, [rsp+0xD0]
000078f8213e1a56  vmovaps xmm15, [rsp+0xE0]
000078f8213e1a5f  add rsp, 0xF0
000078f8213e1a66  pop r11
000078f8213e1a68  pop r10
000078f8213e1a6a  pop r9
000078f8213e1a6c  pop r8
000078f8213e1a6e  pop rsi
000078f8213e1a6f  pop rdi
000078f8213e1a70  pop rdx
000078f8213e1a71  pop rcx
000078f8213e1a72  pop rax
000078f8213e1a73  add rsp, 0x08
000078f8213e1a77  jmp 0x000078F8213DC865
000078f8213e1a7c  call 0x000078F8212E5940
000078f8213e1a81  jmp 0x000078F8213DC873
000078f8213e1a86  call 0x000078F82120C380
000078f8213e1a8b  jmp 0x000078F8213DC87D
000078f8213e1a90  call 0x000078F82120D600
000078f8213e1a95  jmp 0x000078F8213DC887
000078f8213e1a9a  call 0x000078F8211FF540
000078f8213e1a9f  jmp 0x000078F8213DC891
000078f8213e1aa4  int3
000078f8213e1aa5  nop [rax+rax*1], ax
000078f8213e1aae  nop
000078f8213e1ab0  mov rax, [r15+0xF8]
000078f8213e1ab7  lea r14, [rax+0x140]
000078f8213e1abe  mov r12, [r13+r14*1]
000078f8213e1ac3  mov [r15+0xE8], r12
000078f8213e1aca  lea r14, [rax+0x130]
000078f8213e1ad1  mov r12, [r13+r14*1]
000078f8213e1ad6  lea r14, [rax+0x138]
000078f8213e1add  mov r11, [r13+r14*1]
000078f8213e1ae2  movq xmm1, r12
000078f8213e1ae7  movq xmm15, r11
000078f8213e1aec  movq xmm1, xmm1
000078f8213e1af0  movq xmm1, xmm1
000078f8213e1af4  movaps [r15+0x1A0], xmm1
000078f8213e1afc  movq xmm15, xmm15
000078f8213e1b01  movq xmm15, xmm15
000078f8213e1b06  movaps [r15+0x190], xmm15
000078f8213e1b0e  lea r14, [rax+0x120]
000078f8213e1b15  mov r12, [r13+r14*1]
000078f8213e1b1a  lea r14, [rax+0x128]
000078f8213e1b21  mov r11, [r13+r14*1]
000078f8213e1b26  movq xmm1, r12
000078f8213e1b2b  movq xmm15, r11
000078f8213e1b30  movq xmm1, xmm1
000078f8213e1b34  movq xmm1, xmm1
000078f8213e1b38  movaps [r15+0x1C0], xmm1
000078f8213e1b40  movq xmm15, xmm15
000078f8213e1b45  movq xmm15, xmm15
000078f8213e1b4a  movaps [r15+0x1B0], xmm15
000078f8213e1b52  lea r14, [rax+0x110]
000078f8213e1b59  mov r12, [r13+r14*1]
000078f8213e1b5e  lea r14, [rax+0x118]
000078f8213e1b65  mov r11, [r13+r14*1]
000078f8213e1b6a  movq xmm1, r12
000078f8213e1b6f  movq xmm15, r11
000078f8213e1b74  movq xmm1, xmm1
000078f8213e1b78  movq xmm1, xmm1
000078f8213e1b7c  movaps [r15+0x1E0], xmm1
000078f8213e1b84  movq xmm15, xmm15
000078f8213e1b89  movq xmm15, xmm15
000078f8213e1b8e  movaps [r15+0x1D0], xmm15
000078f8213e1b96  lea r14, [rax+0x100]
000078f8213e1b9d  mov r12, [r13+r14*1]
000078f8213e1ba2  lea r14, [rax+0x108]
000078f8213e1ba9  mov r11, [r13+r14*1]
000078f8213e1bae  movq xmm1, r12
000078f8213e1bb3  movq xmm15, r11
000078f8213e1bb8  movq xmm1, xmm1
000078f8213e1bbc  movq xmm1, xmm1
000078f8213e1bc0  movaps [r15+0x200], xmm1
000078f8213e1bc8  movq xmm15, xmm15
000078f8213e1bcd  movq xmm15, xmm15
000078f8213e1bd2  movaps [r15+0x1F0], xmm15
000078f8213e1bda  mov qword ptr [r15+0x40], 0x430000
000078f8213e1be2  mov r14d, 0x430510
000078f8213e1be8  mov r12, [r13+r14*1]
000078f8213e1bed  movq xmm1, r12
000078f8213e1bf2  lea r14, [rax+0x150]
000078f8213e1bf9  mov [r15+0xF8], r14
000078f8213e1c00  mov rax, [r15+0x50]
000078f8213e1c04  movups xmm15, [r13+rax*1]
000078f8213e1c0a  movaps [r15+0x120], xmm15
000078f8213e1c12  mov qword ptr [r15+0x48], 0x10
000078f8213e1c1a  xor eax, eax
000078f8213e1c1c  mov r14d, 0x10
000078f8213e1c22  mov r12d, 0x200
000078f8213e1c28  cmp r14, r12
000078f8213e1c2b  cmc
000078f8213e1c2c  lahf
000078f8213e1c2d  seto al
000078f8213e1c30  mov [r15+0x108], eax
000078f8213e1c37  pextrq rax, xmm15, 0x01
000078f8213e1c3e  movq xmm14, rax
000078f8213e1c43  movaps [r15+0x130], xmm14
000078f8213e1c4b  movq rax, xmm1
000078f8213e1c50  movq r14, xmm15
000078f8213e1c55  vmovq xmm1, rax
000078f8213e1c5a  vmovq xmm15, r14
000078f8213e1c5f  movaps xmm13, xmm1
000078f8213e1c63  addsd xmm13, xmm15
000078f8213e1c68  ucomisd xmm13, xmm13
000078f8213e1c6d  jp 0x000078F8213E1D86
000078f8213e1c73  movq xmm13, xmm13
000078f8213e1c78  movq rax, xmm13
000078f8213e1c7d  movq r14, xmm14
000078f8213e1c82  vmovq xmm1, rax
000078f8213e1c87  vmovq xmm15, r14
000078f8213e1c8c  movaps xmm14, xmm1
000078f8213e1c90  addsd xmm14, xmm15
000078f8213e1c95  ucomisd xmm14, xmm14
000078f8213e1c9a  jp 0x000078F8213E1DCE
000078f8213e1ca0  movq xmm14, xmm14
000078f8213e1ca5  movaps [r15+0x110], xmm14
000078f8213e1cad  mov eax, [r15+0x108]
000078f8213e1cb4  sahf
000078f8213e1cb5  jnz 0x000078F8213E1CE7
000078f8213e1cb7  cmp dword ptr [r15+0x318], 0x00
000078f8213e1cbf  jz 0x000078F8213E1FE0
000078f8213e1cc5  nop [rax+rax*1], ax
000078f8213e1cce  nop [rax+rax*1], eax
000078f8213e1cd6  mov eax, 0x410490
000078f8213e1cdb  mov [r15+0x100], rax
000078f8213e1ce2  jmp 0x000078F8211FE110
000078f8213e1ce7  cmp dword ptr [r15+0x318], 0x00
000078f8213e1cef  jz 0x000078F8213E1E20
000078f8213e1cf5  nop [rax+rax*1], ax
000078f8213e1cfe  nop [rax+rax*1], eax
000078f8213e1d06  mov eax, 0x410474
000078f8213e1d0b  mov [r15+0x100], rax
000078f8213e1d12  jmp 0x000078F8211FE110
000078f8213e1d17  int3
000078f8213e1d18  call 0x000078F8212E27E0
000078f8213e1d1d  jmp 0x000078F8213E1AC3
000078f8213e1d22  call 0x000078F8212E27E0
000078f8213e1d27  jmp 0x000078F8213E1AD6
000078f8213e1d2c  call 0x000078F8212E1570
000078f8213e1d31  jmp 0x000078F8213E1AE2
000078f8213e1d36  call 0x000078F8212E27E0
000078f8213e1d3b  jmp 0x000078F8213E1B1A
000078f8213e1d40  call 0x000078F8212E1570
000078f8213e1d45  jmp 0x000078F8213E1B26
000078f8213e1d4a  call 0x000078F8212E27E0
000078f8213e1d4f  jmp 0x000078F8213E1B5E
000078f8213e1d54  call 0x000078F8212E1570
000078f8213e1d59  jmp 0x000078F8213E1B6A
000078f8213e1d5e  call 0x000078F8212E27E0
000078f8213e1d63  jmp 0x000078F8213E1BA2
000078f8213e1d68  call 0x000078F8212E1570
000078f8213e1d6d  jmp 0x000078F8213E1BAE
000078f8213e1d72  call 0x000078F8212E27E0
000078f8213e1d77  jmp 0x000078F8213E1BED
000078f8213e1d7c  call 0x000078F82120E760
000078f8213e1d81  jmp 0x000078F8213E1C0A
000078f8213e1d86  ucomisd xmm1, xmm15
000078f8213e1d8b  jp 0x000078F8213E1D9A
000078f8213e1d8d  movaps xmm13, [0x000078F820FFE060]
000078f8213e1d95  jmp 0x000078F8213E1C73
000078f8213e1d9a  vxorps xmm0, xmm1, xmm15
000078f8213e1d9f  pextrw eax, xmm0, 0x03
000078f8213e1da4  and eax, 0x7FF8
000078f8213e1da9  cmp eax, 0x08
000078f8213e1dac  jnz 0x000078F8213E1C73
000078f8213e1db2  movq rax, xmm15
000078f8213e1db7  shl rax, 0x0D
000078f8213e1dbb  jbe 0x000078F8213E1C73
000078f8213e1dc1  vorps xmm13, xmm15, [0x000078F820FFE070]
000078f8213e1dc9  jmp 0x000078F8213E1C73
000078f8213e1dce  ucomisd xmm1, xmm15
000078f8213e1dd3  jp 0x000078F8213E1DE2
000078f8213e1dd5  movaps xmm14, [0x000078F820FFE060]
000078f8213e1ddd  jmp 0x000078F8213E1CA0
000078f8213e1de2  vxorps xmm0, xmm1, xmm15
000078f8213e1de7  pextrw eax, xmm0, 0x03
000078f8213e1dec  and eax, 0x7FF8
000078f8213e1df1  cmp eax, 0x08
000078f8213e1df4  jnz 0x000078F8213E1CA0
000078f8213e1dfa  movq rax, xmm15
000078f8213e1dff  shl rax, 0x0D
000078f8213e1e03  jbe 0x000078F8213E1CA0
000078f8213e1e09  vorps xmm14, xmm15, [0x000078F820FFE070]
000078f8213e1e11  jmp 0x000078F8213E1CA0
000078f8213e1e16  int3
000078f8213e1e17  nop [rax+rax*1], ax
000078f8213e1e20  mov rax, [r15+0x48]
000078f8213e1e24  mov r14, [r15+0x50]
000078f8213e1e28  lea r12, [r14+rax*1]
000078f8213e1e2c  movups xmm1, [r13+r12*1]
000078f8213e1e32  movaps [r15+0x120], xmm1
000078f8213e1e3a  lea r14, [rax+0x10]
000078f8213e1e3e  mov [r15+0x48], r14
000078f8213e1e42  xor eax, eax
000078f8213e1e44  mov r12d, 0x200
000078f8213e1e4a  cmp r14, r12
000078f8213e1e4d  cmc
000078f8213e1e4e  lahf
000078f8213e1e4f  seto al
000078f8213e1e52  mov [r15+0x108], eax
000078f8213e1e59  pextrq rax, xmm1, 0x01
000078f8213e1e60  movq xmm15, rax
000078f8213e1e65  movaps [r15+0x130], xmm15
000078f8213e1e6d  movaps xmm14, [r15+0x110]
000078f8213e1e75  movq rax, xmm14
000078f8213e1e7a  movq r14, xmm1
000078f8213e1e7f  vmovq xmm1, rax
000078f8213e1e84  vmovq xmm14, r14
000078f8213e1e89  movaps xmm13, xmm1
000078f8213e1e8d  addsd xmm13, xmm14
000078f8213e1e92  ucomisd xmm13, xmm13
000078f8213e1e97  jp 0x000078F8213E1F4C
000078f8213e1e9d  movq xmm13, xmm13
000078f8213e1ea2  movq rax, xmm13
000078f8213e1ea7  movq r14, xmm15
000078f8213e1eac  vmovq xmm1, rax
000078f8213e1eb1  vmovq xmm15, r14
000078f8213e1eb6  movaps xmm14, xmm1
000078f8213e1eba  addsd xmm14, xmm15
000078f8213e1ebf  ucomisd xmm14, xmm14
000078f8213e1ec4  jp 0x000078F8213E1F94
000078f8213e1eca  movq xmm14, xmm14
000078f8213e1ecf  movaps [r15+0x110], xmm14
000078f8213e1ed7  mov eax, [r15+0x108]
000078f8213e1ede  sahf
000078f8213e1edf  jnz 0x000078F8213E1F11
000078f8213e1ee1  cmp dword ptr [r15+0x318], 0x00
000078f8213e1ee9  jz 0x000078F8213E1FE0
000078f8213e1eef  nop [rax+rax*1], ax
000078f8213e1ef8  nop [rax+rax*1], eax
000078f8213e1f00  mov eax, 0x410490
000078f8213e1f05  mov [r15+0x100], rax
000078f8213e1f0c  jmp 0x000078F8211FE110
000078f8213e1f11  cmp dword ptr [r15+0x318], 0x00
000078f8213e1f19  jz 0x000078F8213E1E20
000078f8213e1f1f  nop [rax+rax*1], ax
000078f8213e1f28  nop [rax+rax*1], eax
000078f8213e1f30  mov eax, 0x410474
000078f8213e1f35  mov [r15+0x100], rax
000078f8213e1f3c  jmp 0x000078F8211FE110
000078f8213e1f41  int3
000078f8213e1f42  call 0x000078F8212B52F0
000078f8213e1f47  jmp 0x000078F8213E1E32
000078f8213e1f4c  ucomisd xmm1, xmm14
000078f8213e1f51  jp 0x000078F8213E1F60
000078f8213e1f53  movaps xmm13, [0x000078F820FFE060]
000078f8213e1f5b  jmp 0x000078F8213E1E9D
000078f8213e1f60  vxorps xmm0, xmm1, xmm14
000078f8213e1f65  pextrw eax, xmm0, 0x03
000078f8213e1f6a  and eax, 0x7FF8
000078f8213e1f6f  cmp eax, 0x08
000078f8213e1f72  jnz 0x000078F8213E1E9D
000078f8213e1f78  movq rax, xmm14
000078f8213e1f7d  shl rax, 0x0D
000078f8213e1f81  jbe 0x000078F8213E1E9D
000078f8213e1f87  vorps xmm13, xmm14, [0x000078F820FFE070]
000078f8213e1f8f  jmp 0x000078F8213E1E9D
000078f8213e1f94  ucomisd xmm1, xmm15
000078f8213e1f99  jp 0x000078F8213E1FA8
000078f8213e1f9b  movaps xmm14, [0x000078F820FFE060]
000078f8213e1fa3  jmp 0x000078F8213E1ECA
000078f8213e1fa8  vxorps xmm0, xmm1, xmm15
000078f8213e1fad  pextrw eax, xmm0, 0x03
000078f8213e1fb2  and eax, 0x7FF8
000078f8213e1fb7  cmp eax, 0x08
000078f8213e1fba  jnz 0x000078F8213E1ECA
000078f8213e1fc0  movq rax, xmm15
000078f8213e1fc5  shl rax, 0x0D
000078f8213e1fc9  jbe 0x000078F8213E1ECA
000078f8213e1fcf  vorps xmm14, xmm15, [0x000078F820FFE070]
000078f8213e1fd7  jmp 0x000078F8213E1ECA
000078f8213e1fdc  int3
000078f8213e1fdd  nop [rax], eax
000078f8213e1fe0  mov rax, [r15+0x40]
000078f8213e1fe4  lea r14, [rax+0x510]
000078f8213e1feb  movaps xmm1, [r15+0x110]
000078f8213e1ff3  movq rax, xmm1
000078f8213e1ff8  mov [r13+r14*1], rax
000078f8213e1ffd  mov rax, [r15+0xF0]
000078f8213e2004  mov [r15+0x100], rax
000078f8213e200b  jmp 0x000078F8213CE5C0
000078f8213e2010  int3
000078f8213e2011  call 0x000078F8212D5EB0
000078f8213e2016  jmp 0x000078F8213E1FFD
000078f8213e201b  int3
000078f8213e201c  nop [rax], eax
000078f8213e2020  mov qword ptr [r15+0x100], 0x04
000078f8213e202b  mov esi, 0x00
000078f8213e2030  mov edx, 0x09
000078f8213e2035  mov rdi, 0x7FFD44821C50
000078f8213e203f  mov rax, 0x653D80DD5970
000078f8213e2049  call rax
000078f8213e204b  cmp dword ptr [r15+0x318], 0x00
000078f8213e2053  jnz 0x000078F8211FE110
000078f8213e2059  jmp 0x000078F8211FE0A0
000078f8213e205e  int3
000078f8213e205f  int3
