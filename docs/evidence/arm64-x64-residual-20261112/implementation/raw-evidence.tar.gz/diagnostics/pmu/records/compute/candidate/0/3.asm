
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/candidate/0/3.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	mov    r14,r13
  1b:	add    r14,0x168
  22:	mov    r15,QWORD PTR [r14]
  25:	mov    QWORD PTR [r12+0x40],r15
  2a:	add    r13,0x178
  31:	mov    r14d,0x0
  37:	mov    BYTE PTR [r13+0x0],r14b
  3b:	mov    r13d,0x0
  41:	mov    DWORD PTR [r12+0x32c],r13d
  49:	sub    r15,0x38
  4d:	je     0x66
  53:	mov    r11,rax
  56:	lahf
  57:	seto   al
  5a:	mov    WORD PTR [rsp],ax
  5e:	mov    rax,r11
  61:	jmp    0x79
  66:	mov    r11,rax
  69:	lahf
  6a:	seto   al
  6d:	mov    WORD PTR [rsp],ax
  71:	mov    rax,r11
  74:	jmp    0x105
  79:	mov    r13,QWORD PTR [r12+0xf8]
  81:	mov    r14,r13
  84:	add    r14,0x100
  8b:	mov    QWORD PTR [r12],r14
  8f:	add    r13,0x178
  96:	mov    QWORD PTR [r12+0x8],r13
  9b:	mov    r13d,0x1
  a1:	mov    QWORD PTR [r12+0x10],r13
  a6:	mov    r13d,0x4102c8
  ac:	mov    QWORD PTR [r12+0xf0],r13
  b4:	mov    r13d,0x410728
  ba:	mov    QWORD PTR [r12+0x100],r13
  c2:	mov    r11,QWORD PTR [rsp]
  c6:	mov    QWORD PTR [r12+0x398],r11
  ce:	mov    edi,0x410728
  d3:	mov    QWORD PTR [r12+0x100],rdi
  db:	add    rsp,0x10
  df:	nop
  e0:	jmp    QWORD PTR [rip+0x2]        # 0xe8
  e6:	xchg   ax,ax
  e8:	loopne 0xcf
  ea:	(bad)
  eb:	ins    BYTE PTR es:[rdi],dx
  ec:	or     BYTE PTR [rbx+0x0],bh
  ef:	add    BYTE PTR [rax],cl
  f1:	wrmsr
  f3:	ins    BYTE PTR es:[rdi],dx
  f4:	or     BYTE PTR [rbx+0x0],bh
  f7:	add    BYTE PTR [rcx-0x45],cl
  fa:	rex stc
  fc:	sub    BYTE PTR [rbp+0x590d],al
 102:	jmp    r11
 105:	mov    r13,QWORD PTR [r12+0x98]
 10d:	ror    r13,0x3d
 111:	and    r13,0xfffffffffffffff8
 115:	mov    r14,QWORD PTR [r12+0xf8]
 11d:	mov    r15,r14
 120:	add    r15,0x100
 127:	mov    QWORD PTR [r12],r15
 12b:	mov    r15,r14
 12e:	add    r15,0x170
 135:	mov    QWORD PTR [r12+0x8],r15
 13a:	mov    r15d,0x8
 140:	mov    QWORD PTR [r12+0x10],r15
 145:	movabs rcx,0xff00ff00ff00ff
 14f:	mov    r15,r13
 152:	and    r15,rcx
 155:	shl    r15,0x8
 159:	movabs rcx,0xff00ff00ff00ff00
 163:	and    r13,rcx
 166:	shr    r13,0x8
 16a:	or     r13,r15
 16d:	movabs rcx,0xffff0000ffff
 177:	mov    r15,r13
 17a:	and    r15,rcx
 17d:	shl    r15,0x10
 181:	movabs rcx,0xffff0000ffff0000
 18b:	and    r13,rcx
 18e:	shr    r13,0x10
 192:	or     r13,r15
 195:	mov    r15,r13
 198:	shl    r15,0x20
 19c:	shr    r13,0x20
 1a0:	or     r13,r15
 1a3:	mov    QWORD PTR [r12+0x40],r13
 1a8:	add    r14,0x170
 1af:	mov    QWORD PTR [r14],r13
 1b2:	mov    r13d,0x0
 1b8:	mov    DWORD PTR [r12+0x32c],r13d
 1c0:	mov    r13d,0x4102f0
 1c6:	mov    QWORD PTR [r12+0xf0],r13
 1ce:	mov    r13d,0x410728
 1d4:	mov    QWORD PTR [r12+0x100],r13
 1dc:	mov    r11,QWORD PTR [rsp]
 1e0:	mov    QWORD PTR [r12+0x398],r11
 1e8:	mov    edi,0x410728
 1ed:	mov    QWORD PTR [r12+0x100],rdi
 1f5:	add    rsp,0x10
 1f9:	nop    DWORD PTR [rax+0x0]
 200:	jmp    QWORD PTR [rip+0x2]        # 0x208
 206:	xchg   ax,ax
 208:	loopne 0x1ef
 20a:	(bad)
 20b:	ins    BYTE PTR es:[rdi],dx
 20c:	or     BYTE PTR [rbx+0x0],bh
 20f:	add    BYTE PTR [rax],ch
 211:	adc    BYTE PTR [rax],dh
 213:	ins    BYTE PTR es:[rdi],dx
 214:	or     BYTE PTR [rbx+0x0],bh
 217:	add    BYTE PTR [rcx-0x45],cl
 21a:	rex stc
 21c:	sub    BYTE PTR [rbp+0x590d],al
 222:	jmp    r11
 225:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 230:	sub    rsp,0x10
 234:	mov    r11,QWORD PTR [r12+0x398]
 23c:	mov    QWORD PTR [rsp],r11
 240:	jmp    0x79
 245:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 250:	sub    rsp,0x10
 254:	mov    r11,QWORD PTR [r12+0x398]
 25c:	mov    QWORD PTR [rsp],r11
 260:	jmp    0x105
 265:	nop
 266:	nop
 267:	nop
