0000785de6dce69b  nop [rax+rax*1], eax
0000785de6dce6a0  mov qword ptr [r15+0x20], 0x420060
0000785de6dce6a8  xor eax, eax
0000785de6dce6aa  xor r14d, r14d
0000785de6dce6ad  shrd rax, r14, 0x0D
0000785de6dce6b2  mov [rsp+0x10], rax
0000785de6dce6b7  shr rax, 0x07
0000785de6dce6bb  mov r14, [rsp+0x10]
0000785de6dce6c0  xor r14, rax
0000785de6dce6c3  lea rax, [r14+0x03]
0000785de6dce6c7  mov [r15], rax
0000785de6dce6ca  xor eax, eax
0000785de6dce6cc  mov r14d, 0xB71B00
0000785de6dce6d2  mov r12d, 0x01
0000785de6dce6d8  sub r14, r12
0000785de6dce6db  cmc
0000785de6dce6dc  lahf
0000785de6dce6dd  seto al
0000785de6dce6e0  mov [r15+0x108], eax
0000785de6dce6e7  mov [r15+0x08], r14
0000785de6dce6eb  mov eax, [r15+0x108]
0000785de6dce6f2  sahf
0000785de6dce6f3  jnz 0x0000785DE6DCE725
0000785de6dce6f5  cmp dword ptr [r15+0x318], 0x00
0000785de6dce6fd  jz 0x0000785DE6DCE820
0000785de6dce703  nop [rax+rax*1], ax
0000785de6dce70c  nop [rax+rax*1], eax
0000785de6dce714  mov eax, 0x410050
0000785de6dce719  mov [r15+0x100], rax
0000785de6dce720  jmp 0x0000785DE6BFE110
0000785de6dce725  cmp dword ptr [r15+0x318], 0x00
0000785de6dce72d  jz 0x0000785DE6DCE760
0000785de6dce733  nop [rax+rax*1], ax
0000785de6dce73c  nop [rax+rax*1], eax
0000785de6dce744  mov eax, 0x41003C
0000785de6dce749  mov [r15+0x100], rax
0000785de6dce750  jmp 0x0000785DE6BFE110
0000785de6dce755  int3
0000785de6dce756  int3
0000785de6dce757  nop [rax+rax*1], ax
0000785de6dce760  mov rax, [r15]
0000785de6dce763  mov [rsp+0x10], rax
0000785de6dce768  mov r14, [rsp+0x10]
0000785de6dce76d  shrd rax, r14, 0x0D
0000785de6dce772  mov [rsp+0x10], rax
0000785de6dce777  shr rax, 0x07
0000785de6dce77b  mov r14, [rsp+0x10]
0000785de6dce780  xor r14, rax
0000785de6dce783  lea rax, [r14+0x03]
0000785de6dce787  mov [r15], rax
0000785de6dce78a  mov rax, [r15+0x08]
0000785de6dce78e  mov [rsp+0x10], rax
0000785de6dce793  xor eax, eax
0000785de6dce795  mov r14, [rsp+0x10]
0000785de6dce79a  mov r12d, 0x01
0000785de6dce7a0  sub r14, r12
0000785de6dce7a3  cmc
0000785de6dce7a4  lahf
0000785de6dce7a5  seto al
0000785de6dce7a8  mov [r15+0x108], eax
0000785de6dce7af  mov [r15+0x08], r14
0000785de6dce7b3  mov eax, [r15+0x108]
0000785de6dce7ba  sahf
0000785de6dce7bb  jnz 0x0000785DE6DCE7ED
0000785de6dce7bd  cmp dword ptr [r15+0x318], 0x00
0000785de6dce7c5  jz 0x0000785DE6DCE820
0000785de6dce7cb  nop [rax+rax*1], ax
0000785de6dce7d4  nop [rax+rax*1], eax
0000785de6dce7dc  mov eax, 0x410050
0000785de6dce7e1  mov [r15+0x100], rax
0000785de6dce7e8  jmp 0x0000785DE6BFE110
0000785de6dce7ed  cmp dword ptr [r15+0x318], 0x00
0000785de6dce7f5  jz 0x0000785DE6DCE760
0000785de6dce7fb  nop [rax+rax*1], ax
0000785de6dce804  nop [rax+rax*1], eax
0000785de6dce80c  mov eax, 0x41003C
0000785de6dce811  mov [r15+0x100], rax
0000785de6dce818  jmp 0x0000785DE6BFE110
0000785de6dce81d  int3
0000785de6dce81e  int3
0000785de6dce81f  nop
0000785de6dce820  mov rax, [r15+0x20]
0000785de6dce824  mov r14, [r15]
0000785de6dce827  mov [r13+rax*1], r14
0000785de6dce82c  mov rax, [r15+0xF0]
0000785de6dce833  mov [r15+0x100], rax
0000785de6dce83a  jmp 0x0000785DE6DCE5C0
0000785de6dce83f  int3
0000785de6dce840  call 0x0000785DE6C0E120
0000785de6dce845  jmp 0x0000785DE6DCE82C
0000785de6dce84a  int3
0000785de6dce84b  nop [rax+rax*1], eax
0000785de6dce850  mov qword ptr [r15+0x100], 0x04
0000785de6dce85b  mov esi, 0x00
0000785de6dce860  mov edx, 0x09
0000785de6dce865  mov rdi, 0x7FFCD5200EC0
0000785de6dce86f  mov rax, 0x5D5F90D11970
0000785de6dce879  call rax
0000785de6dce87b  cmp dword ptr [r15+0x318], 0x00
0000785de6dce883  jnz 0x0000785DE6BFE110
0000785de6dce889  jmp 0x0000785DE6BFE0A0
0000785de6dce88e  int3
0000785de6dce88f  int3
