
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/baseline/0/8.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x150
       7:	mov    r11,QWORD PTR [r12+0x398]
       f:	mov    QWORD PTR [rsp],r11
      13:	cmp    DWORD PTR [r12+0x310],0x0
      1c:	je     0xac
      22:	push   rdx
      23:	push   rsi
      24:	push   r10
      26:	push   r11
      28:	mov    rdx,QWORD PTR [rsp+0x20]
      2d:	mov    r10d,edx
      30:	and    r10d,0xc0
      37:	shl    r10d,0x18
      3b:	mov    r11d,edx
      3e:	and    r11d,0x1
      42:	shl    r11d,0x1d
      46:	or     r10d,r11d
      49:	mov    r11d,edx
      4c:	and    r11d,0x800
      53:	shl    r11d,0x11
      57:	or     r10d,r11d
      5a:	btc    r10,0x1d
      5f:	mov    r11d,0xf0000000
      65:	and    r11,r10
      68:	movabs rsi,0xffffffff0fffffff
      72:	and    rbx,rsi
      75:	or     rbx,r11
      78:	pop    r11
      7a:	pop    r10
      7c:	pop    rsi
      7d:	pop    rdx
      7e:	mov    QWORD PTR [r12+0x108],rbx
      86:	mov    eax,0x4103f8
      8b:	mov    QWORD PTR [r12+0x100],rax
      93:	add    rsp,0x150
      9a:	mov    eax,0x3
      9f:	movabs r11,0x57780bcbe390
      a9:	jmp    r11
      ac:	mov    r13d,DWORD PTR [r12+0x98]
      b4:	add    r13d,0x1
      b8:	mov    QWORD PTR [r12+0x98],r13
      c0:	sub    r13d,0x10000
      c7:	mov    rcx,QWORD PTR [r12+0x380]
      cf:	jrcxz  0xd6
      d1:	jmp    0x6fc6
      d6:	pushf
      d7:	pop    r11
      d9:	mov    QWORD PTR [rsp],r11
      dd:	jne    0x4dcf
      e3:	jmp    0xe8
      e8:	mov    r13d,0x420000
      ee:	mov    QWORD PTR [r12+0x40],r13
      f3:	movabs r13,0x100000001
      fd:	mov    r14d,0x0
     103:	mov    QWORD PTR [r12+0x110],r13
     10b:	mov    QWORD PTR [r12+0x118],r14
     113:	movabs r13,0x3fa0000000000000
     11d:	mov    QWORD PTR [r12+0x50],r13
     122:	mov    r13d,0x420b10
     128:	mov    r14,QWORD PTR [r13+0x0]
     12c:	mov    r13d,0x0
     132:	mov    QWORD PTR [r12+0x120],r14
     13a:	mov    QWORD PTR [r12+0x128],r13
     142:	movabs r13,0x4100000041
     14c:	mov    r14d,0x0
     152:	mov    QWORD PTR [r12+0x140],r13
     15a:	mov    QWORD PTR [r12+0x148],r14
     162:	movabs r13,0x3fc0000000000000
     16c:	movabs r14,0x3fc0000000000000
     176:	mov    QWORD PTR [r12+0x150],r13
     17e:	mov    QWORD PTR [r12+0x158],r14
     186:	movabs r13,0x200000002
     190:	mov    r14d,0x0
     196:	mov    QWORD PTR [r12+0x160],r13
     19e:	mov    QWORD PTR [r12+0x168],r14
     1a6:	mov    r13,QWORD PTR [r12+0x50]
     1ab:	and    r13,0xffffffffffffffff
     1af:	mov    QWORD PTR [r12+0x130],r13
     1b7:	mov    QWORD PTR [r12+0x138],r13
     1bf:	mov    r13d,0x2
     1c5:	mov    QWORD PTR [r12+0x170],r13
     1cd:	mov    QWORD PTR [r12+0x178],r13
     1d5:	mov    r13d,0x420000
     1db:	mov    QWORD PTR [r12+0x40],r13
     1e0:	mov    r13d,0x430000
     1e6:	mov    QWORD PTR [r12+0x50],r13
     1eb:	mov    r13d,0x420a40
     1f1:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     1f7:	movdqa xmm0,xmm2
     1fb:	movdqu XMMWORD PTR [r12+0x180],xmm0
     205:	mov    r13d,0x0
     20b:	mov    QWORD PTR [r12+0x48],r13
     210:	mov    r13d,0x431000
     216:	add    r13,0xe00
     21d:	mov    QWORD PTR [r12+0x40],r13
     222:	mov    r13d,0x430cb8
     228:	mov    r14d,DWORD PTR [r12]
     22c:	mov    DWORD PTR [r13+0x0],r14d
     230:	mov    r13d,0x0
     236:	mov    DWORD PTR [r12+0x32c],r13d
     23e:	mov    r13d,0x432000
     244:	add    r13,0x0
     248:	mov    QWORD PTR [r12+0x50],r13
     24d:	jmp    0x252
     252:	mov    r13,QWORD PTR [r12+0x180]
     25a:	mov    r14,QWORD PTR [r12+0x188]
     262:	mov    r15d,0x0
     268:	and    r13,0xffffffffffffffff
     26c:	mov    ecx,0xffffffff
     271:	and    r13,rcx
     274:	mov    rcx,r13
     277:	mov    rbp,r15
     27a:	or     rbp,rcx
     27d:	and    r14,0xffffffffffffffff
     281:	mov    ecx,0xffffffff
     286:	and    r14,rcx
     289:	shl    r14,0x20
     28d:	mov    rcx,r14
     290:	or     rbp,rcx
     293:	mov    QWORD PTR [r12+0x210],rbp
     29b:	mov    QWORD PTR [r12+0x218],r15
     2a3:	movdqu xmm0,XMMWORD PTR [r12+0x140]
     2ad:	movdqa xmm2,xmm0
     2b1:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     2bb:	movdqa xmm3,xmm0
     2bf:	movdqa xmm1,xmm3
     2c3:	psubd  xmm2,xmm1
     2c7:	movdqa xmm14,xmm2
     2cc:	movdqa xmm1,xmm14
     2d1:	movq   rax,xmm1
     2d6:	mov    r13,rax
     2d9:	movdqu xmm0,XMMWORD PTR [r12+0x180]
     2e3:	movdqa xmm2,xmm0
     2e7:	movdqu xmm0,XMMWORD PTR [r12+0x170]
     2f1:	movdqa xmm4,xmm0
     2f5:	movdqa xmm1,xmm4
     2f9:	paddq  xmm2,xmm1
     2fd:	movdqa xmm0,xmm2
     301:	movdqu XMMWORD PTR [r12+0x180],xmm0
     30b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
     315:	movdqa xmm2,xmm0
     319:	movdqa xmm1,xmm2
     31d:	paddd  xmm3,xmm1
     321:	movdqa xmm14,xmm3
     326:	movdqa xmm1,xmm14
     32b:	movq   rax,xmm1
     330:	mov    r14,rax
     333:	mov    r15d,0x0
     339:	mov    QWORD PTR [r12+0x120],r14
     341:	mov    QWORD PTR [r12+0x128],r15
     349:	mov    r14d,0x0
     34f:	mov    r15,r13
     352:	mov    ecx,0xffffffff
     357:	and    r15,rcx
     35a:	and    r15,0xffffffffffffffff
     35e:	mov    rcx,r15
     361:	mov    rbp,r14
     364:	or     rbp,rcx
     367:	shr    r13,0x20
     36b:	mov    ecx,0xffffffff
     370:	and    r13,rcx
     373:	and    r13,0xffffffffffffffff
     377:	mov    rcx,r13
     37a:	or     r14,rcx
     37d:	mov    QWORD PTR [r12+0x220],rbp
     385:	mov    QWORD PTR [r12+0x228],r14
     38d:	movdqu xmm0,XMMWORD PTR [r12+0x210]
     397:	movdqa xmm2,xmm0
     39b:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     3a5:	movdqa xmm3,xmm0
     3a9:	movdqa xmm1,xmm3
     3ad:	paddd  xmm2,xmm1
     3b1:	movdqa xmm14,xmm2
     3b6:	movdqa xmm1,xmm14
     3bb:	movq   rax,xmm1
     3c0:	mov    r13,rax
     3c3:	mov    r14d,0x0
     3c9:	mov    QWORD PTR [r12+0x210],r13
     3d1:	mov    QWORD PTR [r12+0x218],r14
     3d9:	lea    r13,[r12]
     3dd:	movabs r14,0xb6e61da31
     3e7:	mov    r15d,0x410468
     3ed:	mov    rdx,QWORD PTR [rsp]
     3f1:	mov    r10d,edx
     3f4:	and    r10d,0xc0
     3fb:	shl    r10d,0x18
     3ff:	mov    r11d,edx
     402:	and    r11d,0x1
     406:	shl    r11d,0x1d
     40a:	or     r10d,r11d
     40d:	mov    r11d,edx
     410:	and    r11d,0x800
     417:	shl    r11d,0x11
     41b:	or     r10d,r11d
     41e:	btc    r10,0x1d
     423:	mov    r11d,0xf0000000
     429:	and    r11,r10
     42c:	movabs rsi,0xffffffff0fffffff
     436:	and    rbx,rsi
     439:	or     rbx,r11
     43c:	mov    QWORD PTR [r12+0x378],0x3
     448:	mov    QWORD PTR [r12+0x108],rbx
     450:	stmxcsr DWORD PTR [r12-0x28]
     456:	ldmxcsr DWORD PTR [r12-0x38]
     45c:	movabs r11,0x57780bb24dc0
     466:	mov    rdi,r13
     469:	mov    rsi,r14
     46c:	mov    rdx,r15
     46f:	call   r11
     472:	ldmxcsr DWORD PTR [r12-0x28]
     478:	mov    rbx,QWORD PTR [r12+0x108]
     480:	mov    QWORD PTR [r12+0x378],0x2
     48c:	mov    rbp,rax
     48f:	mov    r13,QWORD PTR [r12+0x210]
     497:	mov    r14d,0x0
     49d:	mov    r15,r13
     4a0:	mov    ecx,0xffffffff
     4a5:	and    r15,rcx
     4a8:	and    r15,0xffffffffffffffff
     4ac:	mov    rcx,r15
     4af:	mov    rbp,r14
     4b2:	or     rbp,rcx
     4b5:	shr    r13,0x20
     4b9:	mov    ecx,0xffffffff
     4be:	and    r13,rcx
     4c1:	and    r13,0xffffffffffffffff
     4c5:	mov    rcx,r13
     4c8:	or     r14,rcx
     4cb:	mov    QWORD PTR [r12+0x210],rbp
     4d3:	mov    QWORD PTR [r12+0x218],r14
     4db:	lea    r13,[r12]
     4df:	movabs r14,0xb6e61da10
     4e9:	mov    r15d,0x410470
     4ef:	mov    QWORD PTR [r12+0x378],0x3
     4fb:	mov    QWORD PTR [r12+0x108],rbx
     503:	stmxcsr DWORD PTR [r12-0x28]
     509:	ldmxcsr DWORD PTR [r12-0x38]
     50f:	movabs r11,0x57780bb24dc0
     519:	mov    rdi,r13
     51c:	mov    rsi,r14
     51f:	mov    rdx,r15
     522:	call   r11
     525:	ldmxcsr DWORD PTR [r12-0x28]
     52b:	mov    rbx,QWORD PTR [r12+0x108]
     533:	mov    QWORD PTR [r12+0x378],0x2
     53f:	mov    rbp,rax
     542:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     54c:	movdqa xmm2,xmm0
     550:	movdqu xmm0,XMMWORD PTR [r12+0x150]
     55a:	movdqa xmm3,xmm0
     55e:	stmxcsr DWORD PTR [rsp+0x110]
     566:	mov    DWORD PTR [rsp+0x114],0x1f80
     571:	ldmxcsr DWORD PTR [rsp+0x114]
     579:	movdqa xmm0,xmm2
     57d:	movdqa xmm1,xmm3
     581:	movq   rax,xmm0
     586:	add    rax,rax
     589:	je     0x59f
     58b:	shr    rax,0x35
     58f:	sub    eax,0x201
     594:	cmp    eax,0x3fc
     599:	ja     0x4e4d
     59f:	movdqa xmm14,xmm0
     5a4:	psrldq xmm14,0x8
     5aa:	movq   rax,xmm14
     5af:	add    rax,rax
     5b2:	je     0x5c8
     5b4:	shr    rax,0x35
     5b8:	sub    eax,0x201
     5bd:	cmp    eax,0x3fc
     5c2:	ja     0x4e4d
     5c8:	movq   rax,xmm1
     5cd:	add    rax,rax
     5d0:	je     0x5e6
     5d2:	shr    rax,0x35
     5d6:	sub    eax,0x201
     5db:	cmp    eax,0x3fc
     5e0:	ja     0x4e4d
     5e6:	movdqa xmm14,xmm1
     5eb:	psrldq xmm14,0x8
     5f1:	movq   rax,xmm14
     5f6:	add    rax,rax
     5f9:	je     0x60f
     5fb:	shr    rax,0x35
     5ff:	sub    eax,0x201
     604:	cmp    eax,0x3fc
     609:	ja     0x4e4d
     60f:	mulpd  xmm0,xmm1
     613:	movdqa xmm4,xmm0
     617:	movdqa xmm0,xmm4
     61b:	movdqu XMMWORD PTR [r12+0x220],xmm0
     625:	mov    r13,QWORD PTR [r12+0x48]
     62a:	mov    r14,QWORD PTR [r12+0x50]
     62f:	mov    rcx,r13
     632:	add    r14,rcx
     635:	stmxcsr DWORD PTR [rsp+0x114]
     63d:	ldmxcsr DWORD PTR [rsp+0x110]
     645:	mov    r11d,DWORD PTR [rsp+0x114]
     64d:	shr    r11d,1
     650:	and    r11d,0x10
     654:	or     DWORD PTR [r12+0x314],r11d
     65c:	movdqu XMMWORD PTR [r14],xmm4
     661:	mov    r14d,0x0
     667:	mov    DWORD PTR [r12+0x32c],r14d
     66f:	movdqu xmm0,XMMWORD PTR [r12+0x210]
     679:	movdqa xmm2,xmm0
     67d:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     687:	movdqa xmm3,xmm0
     68b:	stmxcsr DWORD PTR [rsp+0x110]
     693:	mov    DWORD PTR [rsp+0x114],0x1f80
     69e:	ldmxcsr DWORD PTR [rsp+0x114]
     6a6:	movdqa xmm0,xmm2
     6aa:	movdqa xmm1,xmm3
     6ae:	movq   rax,xmm0
     6b3:	add    rax,rax
     6b6:	je     0x6cc
     6b8:	shr    rax,0x35
     6bc:	sub    eax,0x201
     6c1:	cmp    eax,0x3fc
     6c6:	ja     0x4e71
     6cc:	movdqa xmm14,xmm0
     6d1:	psrldq xmm14,0x8
     6d7:	movq   rax,xmm14
     6dc:	add    rax,rax
     6df:	je     0x6f5
     6e1:	shr    rax,0x35
     6e5:	sub    eax,0x201
     6ea:	cmp    eax,0x3fc
     6ef:	ja     0x4e71
     6f5:	movq   rax,xmm1
     6fa:	add    rax,rax
     6fd:	je     0x713
     6ff:	shr    rax,0x35
     703:	sub    eax,0x201
     708:	cmp    eax,0x3fc
     70d:	ja     0x4e71
     713:	movdqa xmm14,xmm1
     718:	psrldq xmm14,0x8
     71e:	movq   rax,xmm14
     723:	add    rax,rax
     726:	je     0x73c
     728:	shr    rax,0x35
     72c:	sub    eax,0x201
     731:	cmp    eax,0x3fc
     736:	ja     0x4e71
     73c:	mulpd  xmm0,xmm1
     740:	movdqa xmm4,xmm0
     744:	movdqa xmm0,xmm4
     748:	movdqu XMMWORD PTR [r12+0x210],xmm0
     752:	mov    r14,QWORD PTR [r12+0x40]
     757:	mov    rcx,r13
     75a:	add    r14,rcx
     75d:	stmxcsr DWORD PTR [rsp+0x114]
     765:	ldmxcsr DWORD PTR [rsp+0x110]
     76d:	mov    r11d,DWORD PTR [rsp+0x114]
     775:	shr    r11d,1
     778:	and    r11d,0x10
     77c:	or     DWORD PTR [r12+0x314],r11d
     784:	movdqu XMMWORD PTR [r14],xmm4
     789:	mov    r14d,0x0
     78f:	mov    DWORD PTR [r12+0x32c],r14d
     797:	add    r13,0x10
     79b:	mov    QWORD PTR [r12+0x48],r13
     7a0:	sub    r13,0x200
     7a7:	mov    rcx,QWORD PTR [r12+0x380]
     7af:	jrcxz  0x7b6
     7b1:	jmp    0x7058
     7b6:	pushf
     7b7:	pop    r11
     7b9:	mov    QWORD PTR [rsp],r11
     7bd:	jne    0x252
     7c3:	jmp    0x7c8
     7c8:	mov    r13,QWORD PTR [r12+0x50]
     7cd:	mov    r14,r13
     7d0:	add    r14,0x80
     7d7:	mov    r15,r14
     7da:	add    r15,0x10
     7de:	movdqu xmm2,XMMWORD PTR [r14]
     7e3:	movdqu xmm3,XMMWORD PTR [r15]
     7e8:	movdqa xmm0,xmm2
     7ec:	movdqu XMMWORD PTR [r12+0x130],xmm0
     7f6:	movdqa xmm0,xmm3
     7fa:	movdqu XMMWORD PTR [r12+0x110],xmm0
     804:	mov    r14d,0x0
     80a:	mov    r15d,0x0
     810:	mov    QWORD PTR [r12+0x1b0],r14
     818:	mov    QWORD PTR [r12+0x1b8],r15
     820:	mov    r14,r13
     823:	add    r14,0x40
     827:	mov    r15,r14
     82a:	add    r15,0x10
     82e:	movdqu xmm2,XMMWORD PTR [r14]
     833:	movdqu xmm3,XMMWORD PTR [r15]
     838:	movdqa xmm0,xmm2
     83c:	movdqu XMMWORD PTR [r12+0x250],xmm0
     846:	movdqa xmm0,xmm3
     84a:	movdqu XMMWORD PTR [r12+0x120],xmm0
     854:	mov    r14d,0x0
     85a:	mov    QWORD PTR [r12+0x48],r14
     85f:	mov    r14,r13
     862:	add    r14,0x10
     866:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     86c:	movdqu xmm3,XMMWORD PTR [r14]
     871:	movdqa xmm0,xmm2
     875:	movdqu XMMWORD PTR [r12+0x170],xmm0
     87f:	movdqa xmm0,xmm3
     883:	movdqu XMMWORD PTR [r12+0x180],xmm0
     88d:	mov    r13,QWORD PTR [r12+0xf8]
     895:	add    r13,0xe0
     89c:	mov    r14,r13
     89f:	add    r14,0x10
     8a3:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     8ad:	movdqa xmm2,xmm0
     8b1:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     8bb:	movdqa xmm3,xmm0
     8bf:	movdqu XMMWORD PTR [r13+0x0],xmm2
     8c5:	mov    r13d,0x0
     8cb:	mov    DWORD PTR [r12+0x32c],r13d
     8d3:	movdqu XMMWORD PTR [r14],xmm3
     8d8:	mov    r13d,0x0
     8de:	mov    DWORD PTR [r12+0x32c],r13d
     8e6:	mov    r13,QWORD PTR [r12+0x50]
     8eb:	mov    r14,r13
     8ee:	add    r14,0xc0
     8f5:	mov    r15,r14
     8f8:	add    r15,0x10
     8fc:	movdqu xmm2,XMMWORD PTR [r14]
     901:	movdqu xmm3,XMMWORD PTR [r15]
     906:	movdqa xmm0,xmm2
     90a:	movdqu XMMWORD PTR [r12+0x130],xmm0
     914:	movdqa xmm0,xmm3
     918:	movdqu XMMWORD PTR [r12+0x110],xmm0
     922:	mov    r14,r13
     925:	add    r14,0x140
     92c:	mov    r15,r14
     92f:	add    r15,0x10
     933:	movdqu xmm2,XMMWORD PTR [r14]
     938:	movdqu xmm3,XMMWORD PTR [r15]
     93d:	movdqa xmm0,xmm2
     941:	movdqu XMMWORD PTR [r12+0x270],xmm0
     94b:	movdqa xmm0,xmm3
     94f:	movdqu XMMWORD PTR [r12+0x190],xmm0
     959:	add    r13,0x180
     960:	mov    r14,r13
     963:	add    r14,0x10
     967:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     96d:	movdqu xmm3,XMMWORD PTR [r14]
     972:	movdqa xmm0,xmm2
     976:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
     980:	movdqa xmm0,xmm3
     984:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
     98e:	mov    r13,QWORD PTR [r12+0xf8]
     996:	add    r13,0xc0
     99d:	mov    r14,r13
     9a0:	add    r14,0x10
     9a4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     9ae:	movdqa xmm2,xmm0
     9b2:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     9bc:	movdqa xmm3,xmm0
     9c0:	movdqu XMMWORD PTR [r13+0x0],xmm2
     9c6:	mov    r13d,0x0
     9cc:	mov    DWORD PTR [r12+0x32c],r13d
     9d4:	movdqu XMMWORD PTR [r14],xmm3
     9d9:	mov    r13d,0x0
     9df:	mov    DWORD PTR [r12+0x32c],r13d
     9e7:	mov    r13,QWORD PTR [r12+0x50]
     9ec:	mov    r14,r13
     9ef:	add    r14,0x100
     9f6:	mov    r15,r14
     9f9:	add    r15,0x10
     9fd:	movdqu xmm2,XMMWORD PTR [r14]
     a02:	movdqu xmm3,XMMWORD PTR [r15]
     a07:	movdqa xmm0,xmm2
     a0b:	movdqu XMMWORD PTR [r12+0x110],xmm0
     a15:	movdqa xmm0,xmm3
     a19:	movdqu XMMWORD PTR [r12+0x300],xmm0
     a23:	mov    r14,r13
     a26:	add    r14,0x1c0
     a2d:	mov    r15,r14
     a30:	add    r15,0x10
     a34:	movdqu xmm2,XMMWORD PTR [r14]
     a39:	movdqu xmm3,XMMWORD PTR [r15]
     a3e:	movdqa xmm0,xmm2
     a42:	movdqu XMMWORD PTR [r12+0x240],xmm0
     a4c:	movdqa xmm0,xmm3
     a50:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
     a5a:	add    r13,0x20
     a5e:	mov    r14,r13
     a61:	add    r14,0x10
     a65:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     a6b:	movdqu xmm3,XMMWORD PTR [r14]
     a70:	movdqa xmm0,xmm2
     a74:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
     a7e:	movdqa xmm0,xmm3
     a82:	movdqu XMMWORD PTR [r12+0x1f0],xmm0
     a8c:	mov    r13,QWORD PTR [r12+0xf8]
     a94:	mov    r14,r13
     a97:	add    r14,0x20
     a9b:	mov    r15,r14
     a9e:	add    r15,0x10
     aa2:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     aac:	movdqa xmm2,xmm0
     ab0:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     aba:	movdqa xmm3,xmm0
     abe:	movdqu XMMWORD PTR [r14],xmm2
     ac3:	mov    r14d,0x0
     ac9:	mov    DWORD PTR [r12+0x32c],r14d
     ad1:	movdqu XMMWORD PTR [r15],xmm3
     ad6:	mov    r14d,0x0
     adc:	mov    DWORD PTR [r12+0x32c],r14d
     ae4:	mov    r14,QWORD PTR [r12+0x50]
     ae9:	mov    r15,r14
     aec:	add    r15,0x60
     af0:	mov    rbp,r15
     af3:	add    rbp,0x10
     af7:	movdqu xmm2,XMMWORD PTR [r15]
     afc:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     b01:	movdqa xmm0,xmm2
     b05:	movdqu XMMWORD PTR [r12+0x110],xmm0
     b0f:	movdqa xmm0,xmm3
     b13:	movdqu XMMWORD PTR [r12+0x120],xmm0
     b1d:	add    r13,0x60
     b21:	mov    r15,r13
     b24:	add    r15,0x10
     b28:	movdqu xmm0,XMMWORD PTR [r12+0x170]
     b32:	movdqa xmm2,xmm0
     b36:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     b40:	movdqa xmm3,xmm0
     b44:	movdqu XMMWORD PTR [r13+0x0],xmm2
     b4a:	mov    r13d,0x0
     b50:	mov    DWORD PTR [r12+0x32c],r13d
     b58:	movdqu XMMWORD PTR [r15],xmm3
     b5d:	mov    r13d,0x0
     b63:	mov    DWORD PTR [r12+0x32c],r13d
     b6b:	mov    r13,r14
     b6e:	add    r13,0xe0
     b75:	mov    r15,r13
     b78:	add    r15,0x10
     b7c:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     b82:	movdqu xmm3,XMMWORD PTR [r15]
     b87:	movdqa xmm0,xmm2
     b8b:	movdqu XMMWORD PTR [r12+0x200],xmm0
     b95:	movdqa xmm0,xmm3
     b99:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
     ba3:	add    r14,0x120
     baa:	mov    r13,r14
     bad:	add    r13,0x10
     bb1:	movdqu xmm2,XMMWORD PTR [r14]
     bb6:	movdqu xmm3,XMMWORD PTR [r13+0x0]
     bbc:	movdqa xmm0,xmm2
     bc0:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
     bca:	movdqa xmm0,xmm3
     bce:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
     bd8:	mov    r13,QWORD PTR [r12+0xf8]
     be0:	add    r13,0xa0
     be7:	mov    r14,r13
     bea:	add    r14,0x10
     bee:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     bf8:	movdqa xmm2,xmm0
     bfc:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     c06:	movdqa xmm3,xmm0
     c0a:	movdqu XMMWORD PTR [r13+0x0],xmm2
     c10:	mov    r13d,0x0
     c16:	mov    DWORD PTR [r12+0x32c],r13d
     c1e:	movdqu XMMWORD PTR [r14],xmm3
     c23:	mov    r13d,0x0
     c29:	mov    DWORD PTR [r12+0x32c],r13d
     c31:	mov    r13,QWORD PTR [r12+0x50]
     c36:	mov    r14,r13
     c39:	add    r14,0xa0
     c40:	mov    r15,r14
     c43:	add    r15,0x10
     c47:	movdqu xmm2,XMMWORD PTR [r14]
     c4c:	movdqu xmm3,XMMWORD PTR [r15]
     c51:	movdqa xmm0,xmm2
     c55:	movdqu XMMWORD PTR [r12+0x110],xmm0
     c5f:	movdqa xmm0,xmm3
     c63:	movdqu XMMWORD PTR [r12+0x120],xmm0
     c6d:	mov    r14,r13
     c70:	add    r14,0x160
     c77:	mov    r15,r14
     c7a:	add    r15,0x10
     c7e:	movdqu xmm2,XMMWORD PTR [r14]
     c83:	movdqu xmm3,XMMWORD PTR [r15]
     c88:	movdqa xmm0,xmm2
     c8c:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
     c96:	movdqa xmm0,xmm3
     c9a:	movdqu XMMWORD PTR [r12+0x2b0],xmm0
     ca4:	add    r13,0x1a0
     cab:	mov    r14,r13
     cae:	add    r14,0x10
     cb2:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     cb8:	movdqu xmm3,XMMWORD PTR [r14]
     cbd:	movdqa xmm0,xmm2
     cc1:	movdqu XMMWORD PTR [r12+0x290],xmm0
     ccb:	movdqa xmm0,xmm3
     ccf:	movdqu XMMWORD PTR [r12+0x1e0],xmm0
     cd9:	mov    r13,QWORD PTR [r12+0xf8]
     ce1:	mov    r14,r13
     ce4:	add    r14,0x80
     ceb:	mov    r15,r14
     cee:	add    r15,0x10
     cf2:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     cfc:	movdqa xmm2,xmm0
     d00:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     d0a:	movdqa xmm3,xmm0
     d0e:	movdqu XMMWORD PTR [r14],xmm2
     d13:	mov    r14d,0x0
     d19:	mov    DWORD PTR [r12+0x32c],r14d
     d21:	movdqu XMMWORD PTR [r15],xmm3
     d26:	mov    r14d,0x0
     d2c:	mov    DWORD PTR [r12+0x32c],r14d
     d34:	mov    r14,QWORD PTR [r12+0x50]
     d39:	add    r14,0x1e0
     d40:	mov    r15,r14
     d43:	add    r15,0x10
     d47:	movdqu xmm2,XMMWORD PTR [r14]
     d4c:	movdqu xmm3,XMMWORD PTR [r15]
     d51:	movdqa xmm0,xmm2
     d55:	movdqu XMMWORD PTR [r12+0x230],xmm0
     d5f:	movdqa xmm0,xmm3
     d63:	movdqu XMMWORD PTR [r12+0x280],xmm0
     d6d:	mov    r14d,0x432000
     d73:	add    r14,0x200
     d7a:	mov    QWORD PTR [r12+0x50],r14
     d7f:	add    r13,0x40
     d83:	mov    r14,r13
     d86:	add    r14,0x10
     d8a:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
     d94:	movdqa xmm4,xmm0
     d98:	movdqu xmm0,XMMWORD PTR [r12+0x180]
     da2:	movdqa xmm5,xmm0
     da6:	movdqu XMMWORD PTR [r13+0x0],xmm4
     dac:	mov    r13d,0x0
     db2:	mov    DWORD PTR [r12+0x32c],r13d
     dba:	movdqu XMMWORD PTR [r14],xmm5
     dbf:	mov    r13d,0x0
     dc5:	mov    DWORD PTR [r12+0x32c],r13d
     dcd:	mov    r13,QWORD PTR [r12+0xf8]
     dd5:	mov    r14,r13
     dd8:	add    r14,0x10
     ddc:	movdqu XMMWORD PTR [r13+0x0],xmm3
     de2:	mov    r13d,0x0
     de8:	mov    DWORD PTR [r12+0x32c],r13d
     df0:	movdqu XMMWORD PTR [r14],xmm2
     df5:	mov    r13d,0x0
     dfb:	mov    DWORD PTR [r12+0x32c],r13d
     e03:	jmp    0xe08
     e08:	mov    r13d,0x0
     e0e:	mov    QWORD PTR [r12+0x58],r13
     e13:	jmp    0xe18
     e18:	mov    r13,QWORD PTR [r12+0x58]
     e1d:	mov    r14,QWORD PTR [r12+0x40]
     e22:	mov    rcx,r13
     e25:	add    r14,rcx
     e28:	mov    QWORD PTR [r12+0x60],r14
     e2d:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
     e37:	movdqa xmm2,xmm0
     e3b:	movdqa xmm1,xmm2
     e3f:	por    xmm2,xmm1
     e43:	movdqa xmm0,xmm2
     e47:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
     e51:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
     e5b:	movdqa xmm2,xmm0
     e5f:	movdqa xmm1,xmm2
     e63:	por    xmm2,xmm1
     e67:	movdqa xmm0,xmm2
     e6b:	movdqu XMMWORD PTR [r12+0x120],xmm0
     e75:	add    r14,0x30
     e79:	mov    r13,r14
     e7c:	add    r13,0x8
     e80:	mov    r15,QWORD PTR [r14]
     e83:	mov    r14,QWORD PTR [r13+0x0]
     e87:	mov    r13d,0x0
     e8d:	mov    QWORD PTR [r12+0x130],r15
     e95:	mov    QWORD PTR [r12+0x138],r13
     e9d:	mov    r13d,0x0
     ea3:	mov    QWORD PTR [r12+0x280],r14
     eab:	mov    QWORD PTR [r12+0x288],r13
     eb3:	movdqu xmm0,XMMWORD PTR [r12+0x270]
     ebd:	movdqa xmm2,xmm0
     ec1:	movdqa xmm1,xmm2
     ec5:	por    xmm2,xmm1
     ec9:	movdqa xmm0,xmm2
     ecd:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
     ed7:	mov    r13,QWORD PTR [r12+0x60]
     edc:	mov    r14,r13
     edf:	add    r14,0x20
     ee3:	mov    r15,r14
     ee6:	add    r15,0x8
     eea:	mov    rbp,QWORD PTR [r14]
     eed:	mov    r14,QWORD PTR [r15]
     ef0:	mov    r15d,0x0
     ef6:	mov    QWORD PTR [r12+0x150],rbp
     efe:	mov    QWORD PTR [r12+0x158],r15
     f06:	mov    r15d,0x0
     f0c:	mov    QWORD PTR [r12+0x140],r14
     f14:	mov    QWORD PTR [r12+0x148],r15
     f1c:	add    r13,0x10
     f20:	mov    r14,r13
     f23:	add    r14,0x8
     f27:	mov    r15,QWORD PTR [r13+0x0]
     f2b:	mov    r13,QWORD PTR [r14]
     f2e:	mov    r14d,0x0
     f34:	mov    QWORD PTR [r12+0x170],r15
     f3c:	mov    QWORD PTR [r12+0x178],r14
     f44:	mov    r14d,0x0
     f4a:	mov    QWORD PTR [r12+0x160],r13
     f52:	mov    QWORD PTR [r12+0x168],r14
     f5a:	mov    r13,QWORD PTR [r12+0x60]
     f5f:	mov    r14d,0x8
     f65:	mov    r15,QWORD PTR [r13+0x0]
     f69:	mov    QWORD PTR [r12+0x180],r15
     f71:	mov    QWORD PTR [r12+0x188],r15
     f79:	mov    rcx,r14
     f7c:	add    r13,rcx
     f7f:	mov    QWORD PTR [r12+0x60],r13
     f84:	mov    r14,QWORD PTR [r13+0x0]
     f88:	mov    r13d,0x0
     f8e:	mov    QWORD PTR [r12+0x230],r14
     f96:	mov    QWORD PTR [r12+0x238],r13
     f9e:	mov    r13,QWORD PTR [r12+0xf8]
     fa6:	mov    r14,r13
     fa9:	add    r14,0x50
     fad:	mov    r15,r14
     fb0:	add    r15,0x10
     fb4:	movdqu xmm2,XMMWORD PTR [r14]
     fb9:	movdqu xmm3,XMMWORD PTR [r15]
     fbe:	movdqa xmm0,xmm2
     fc2:	movdqu XMMWORD PTR [r12+0x220],xmm0
     fcc:	movdqa xmm0,xmm3
     fd0:	movdqu XMMWORD PTR [r12+0x210],xmm0
     fda:	add    r13,0x30
     fde:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     fe4:	movdqa xmm0,xmm2
     fe8:	movdqu XMMWORD PTR [r12+0x110],xmm0
     ff2:	mov    r13,QWORD PTR [r12+0x58]
     ff7:	mov    r14,QWORD PTR [r12+0x50]
     ffc:	mov    rcx,r13
     fff:	add    r14,rcx
    1002:	mov    QWORD PTR [r12+0x60],r14
    1007:	add    r13,0x40
    100b:	mov    QWORD PTR [r12+0x58],r13
    1010:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    101a:	movdqa xmm3,xmm0
    101e:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    1028:	movdqa xmm4,xmm0
    102c:	stmxcsr DWORD PTR [rsp+0x110]
    1034:	mov    DWORD PTR [rsp+0x114],0x1f80
    103f:	ldmxcsr DWORD PTR [rsp+0x114]
    1047:	movdqa xmm0,xmm3
    104b:	movdqa xmm1,xmm4
    104f:	movq   rax,xmm0
    1054:	add    rax,rax
    1057:	je     0x106d
    1059:	shr    rax,0x35
    105d:	sub    eax,0x201
    1062:	cmp    eax,0x3fc
    1067:	ja     0x4e95
    106d:	movdqa xmm14,xmm0
    1072:	psrldq xmm14,0x8
    1078:	movq   rax,xmm14
    107d:	add    rax,rax
    1080:	je     0x1096
    1082:	shr    rax,0x35
    1086:	sub    eax,0x201
    108b:	cmp    eax,0x3fc
    1090:	ja     0x4e95
    1096:	movq   rax,xmm1
    109b:	add    rax,rax
    109e:	je     0x10b4
    10a0:	shr    rax,0x35
    10a4:	sub    eax,0x201
    10a9:	cmp    eax,0x3fc
    10ae:	ja     0x4e95
    10b4:	movdqa xmm14,xmm1
    10b9:	psrldq xmm14,0x8
    10bf:	movq   rax,xmm14
    10c4:	add    rax,rax
    10c7:	je     0x10dd
    10c9:	shr    rax,0x35
    10cd:	sub    eax,0x201
    10d2:	cmp    eax,0x3fc
    10d7:	ja     0x4e95
    10dd:	mulpd  xmm0,xmm1
    10e1:	movdqa xmm5,xmm0
    10e5:	movdqa xmm0,xmm5
    10e9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    10f3:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    10fd:	movdqa xmm4,xmm0
    1101:	movdqa xmm0,xmm2
    1105:	movdqa xmm1,xmm4
    1109:	pshufd xmm1,xmm1,0x44
    110e:	movq   rax,xmm0
    1113:	add    rax,rax
    1116:	je     0x112c
    1118:	shr    rax,0x35
    111c:	sub    eax,0x201
    1121:	cmp    eax,0x3fc
    1126:	ja     0x4eb9
    112c:	movdqa xmm14,xmm0
    1131:	psrldq xmm14,0x8
    1137:	movq   rax,xmm14
    113c:	add    rax,rax
    113f:	je     0x1155
    1141:	shr    rax,0x35
    1145:	sub    eax,0x201
    114a:	cmp    eax,0x3fc
    114f:	ja     0x4eb9
    1155:	movq   rax,xmm1
    115a:	add    rax,rax
    115d:	je     0x1173
    115f:	shr    rax,0x35
    1163:	sub    eax,0x201
    1168:	cmp    eax,0x3fc
    116d:	ja     0x4eb9
    1173:	movdqa xmm14,xmm1
    1178:	psrldq xmm14,0x8
    117e:	movq   rax,xmm14
    1183:	add    rax,rax
    1186:	je     0x119c
    1188:	shr    rax,0x35
    118c:	sub    eax,0x201
    1191:	cmp    eax,0x3fc
    1196:	ja     0x4eb9
    119c:	mulpd  xmm0,xmm1
    11a0:	movdqa xmm5,xmm0
    11a4:	movdqa xmm0,xmm5
    11a8:	movdqu XMMWORD PTR [r12+0x260],xmm0
    11b2:	mov    r13d,0x0
    11b8:	mov    r14d,0x0
    11be:	mov    QWORD PTR [r12+0x110],r13
    11c6:	mov    QWORD PTR [r12+0x118],r14
    11ce:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    11d8:	movdqa xmm2,xmm0
    11dc:	movdqa xmm0,xmm3
    11e0:	movdqa xmm1,xmm2
    11e4:	movq   rax,xmm0
    11e9:	add    rax,rax
    11ec:	je     0x1202
    11ee:	shr    rax,0x35
    11f2:	sub    eax,0x201
    11f7:	cmp    eax,0x3fc
    11fc:	ja     0x4edd
    1202:	movdqa xmm14,xmm0
    1207:	psrldq xmm14,0x8
    120d:	movq   rax,xmm14
    1212:	add    rax,rax
    1215:	je     0x122b
    1217:	shr    rax,0x35
    121b:	sub    eax,0x201
    1220:	cmp    eax,0x3fc
    1225:	ja     0x4edd
    122b:	movq   rax,xmm1
    1230:	add    rax,rax
    1233:	je     0x1249
    1235:	shr    rax,0x35
    1239:	sub    eax,0x201
    123e:	cmp    eax,0x3fc
    1243:	ja     0x4edd
    1249:	movdqa xmm14,xmm1
    124e:	psrldq xmm14,0x8
    1254:	movq   rax,xmm14
    1259:	add    rax,rax
    125c:	je     0x1272
    125e:	shr    rax,0x35
    1262:	sub    eax,0x201
    1267:	cmp    eax,0x3fc
    126c:	ja     0x4edd
    1272:	mulpd  xmm0,xmm1
    1276:	movdqa xmm4,xmm0
    127a:	movdqa xmm0,xmm4
    127e:	movdqu XMMWORD PTR [r12+0x210],xmm0
    1288:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    1292:	movdqa xmm2,xmm0
    1296:	movdqa xmm0,xmm3
    129a:	movdqa xmm1,xmm2
    129e:	movq   rax,xmm0
    12a3:	add    rax,rax
    12a6:	je     0x12bc
    12a8:	shr    rax,0x35
    12ac:	sub    eax,0x201
    12b1:	cmp    eax,0x3fc
    12b6:	ja     0x4f01
    12bc:	movdqa xmm14,xmm0
    12c1:	psrldq xmm14,0x8
    12c7:	movq   rax,xmm14
    12cc:	add    rax,rax
    12cf:	je     0x12e5
    12d1:	shr    rax,0x35
    12d5:	sub    eax,0x201
    12da:	cmp    eax,0x3fc
    12df:	ja     0x4f01
    12e5:	movq   rax,xmm1
    12ea:	add    rax,rax
    12ed:	je     0x1303
    12ef:	shr    rax,0x35
    12f3:	sub    eax,0x201
    12f8:	cmp    eax,0x3fc
    12fd:	ja     0x4f01
    1303:	movdqa xmm14,xmm1
    1308:	psrldq xmm14,0x8
    130e:	movq   rax,xmm14
    1313:	add    rax,rax
    1316:	je     0x132c
    1318:	shr    rax,0x35
    131c:	sub    eax,0x201
    1321:	cmp    eax,0x3fc
    1326:	ja     0x4f01
    132c:	mulpd  xmm0,xmm1
    1330:	movdqa xmm4,xmm0
    1334:	movdqa xmm0,xmm4
    1338:	movdqu XMMWORD PTR [r12+0x220],xmm0
    1342:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    134c:	movdqa xmm2,xmm0
    1350:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    135a:	movdqa xmm3,xmm0
    135e:	movdqa xmm0,xmm2
    1362:	movdqa xmm1,xmm3
    1366:	movq   rax,xmm0
    136b:	add    rax,rax
    136e:	je     0x1384
    1370:	shr    rax,0x35
    1374:	sub    eax,0x201
    1379:	cmp    eax,0x3fc
    137e:	ja     0x4f25
    1384:	movdqa xmm14,xmm0
    1389:	psrldq xmm14,0x8
    138f:	movq   rax,xmm14
    1394:	add    rax,rax
    1397:	je     0x13ad
    1399:	shr    rax,0x35
    139d:	sub    eax,0x201
    13a2:	cmp    eax,0x3fc
    13a7:	ja     0x4f25
    13ad:	movq   rax,xmm1
    13b2:	add    rax,rax
    13b5:	je     0x13cb
    13b7:	shr    rax,0x35
    13bb:	sub    eax,0x201
    13c0:	cmp    eax,0x3fc
    13c5:	ja     0x4f25
    13cb:	movdqa xmm14,xmm1
    13d0:	psrldq xmm14,0x8
    13d6:	movq   rax,xmm14
    13db:	add    rax,rax
    13de:	je     0x13f4
    13e0:	shr    rax,0x35
    13e4:	sub    eax,0x201
    13e9:	cmp    eax,0x3fc
    13ee:	ja     0x4f25
    13f4:	mulpd  xmm0,xmm1
    13f8:	movdqa xmm4,xmm0
    13fc:	movdqa xmm0,xmm4
    1400:	movdqu XMMWORD PTR [r12+0x180],xmm0
    140a:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    1414:	movdqa xmm2,xmm0
    1418:	movdqa xmm1,xmm2
    141c:	por    xmm2,xmm1
    1420:	movdqa xmm0,xmm2
    1424:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    142e:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    1438:	movdqa xmm2,xmm0
    143c:	movdqa xmm3,xmm2
    1440:	movdqa xmm1,xmm2
    1444:	por    xmm3,xmm1
    1448:	movdqa xmm0,xmm3
    144c:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    1456:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    1460:	movdqa xmm3,xmm0
    1464:	movdqa xmm0,xmm2
    1468:	movdqa xmm1,xmm3
    146c:	pshufd xmm1,xmm1,0x44
    1471:	movq   rax,xmm0
    1476:	add    rax,rax
    1479:	je     0x148f
    147b:	shr    rax,0x35
    147f:	sub    eax,0x201
    1484:	cmp    eax,0x3fc
    1489:	ja     0x4f49
    148f:	movdqa xmm14,xmm0
    1494:	psrldq xmm14,0x8
    149a:	movq   rax,xmm14
    149f:	add    rax,rax
    14a2:	je     0x14b8
    14a4:	shr    rax,0x35
    14a8:	sub    eax,0x201
    14ad:	cmp    eax,0x3fc
    14b2:	ja     0x4f49
    14b8:	movq   rax,xmm1
    14bd:	add    rax,rax
    14c0:	je     0x14d6
    14c2:	shr    rax,0x35
    14c6:	sub    eax,0x201
    14cb:	cmp    eax,0x3fc
    14d0:	ja     0x4f49
    14d6:	movdqa xmm14,xmm1
    14db:	psrldq xmm14,0x8
    14e1:	movq   rax,xmm14
    14e6:	add    rax,rax
    14e9:	je     0x14ff
    14eb:	shr    rax,0x35
    14ef:	sub    eax,0x201
    14f4:	cmp    eax,0x3fc
    14f9:	ja     0x4f49
    14ff:	mulpd  xmm0,xmm1
    1503:	movdqa xmm4,xmm0
    1507:	movdqa xmm0,xmm4
    150b:	movdqu XMMWORD PTR [r12+0x250],xmm0
    1515:	mov    r13,QWORD PTR [r12+0x58]
    151a:	stmxcsr DWORD PTR [rsp+0x114]
    1522:	ldmxcsr DWORD PTR [rsp+0x110]
    152a:	mov    r11d,DWORD PTR [rsp+0x114]
    1532:	shr    r11d,1
    1535:	and    r11d,0x10
    1539:	or     DWORD PTR [r12+0x314],r11d
    1541:	sub    r13,0x200
    1548:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    1552:	movdqa xmm2,xmm0
    1556:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    1560:	movdqa xmm3,xmm0
    1564:	pushf
    1565:	pop    r11
    1567:	mov    QWORD PTR [rsp],r11
    156b:	stmxcsr DWORD PTR [rsp+0x110]
    1573:	mov    DWORD PTR [rsp+0x114],0x1f80
    157e:	ldmxcsr DWORD PTR [rsp+0x114]
    1586:	movdqa xmm0,xmm2
    158a:	movdqa xmm1,xmm3
    158e:	movq   rax,xmm0
    1593:	add    rax,rax
    1596:	je     0x15ac
    1598:	shr    rax,0x35
    159c:	sub    eax,0x201
    15a1:	cmp    eax,0x3fc
    15a6:	ja     0x4f6d
    15ac:	movdqa xmm14,xmm0
    15b1:	psrldq xmm14,0x8
    15b7:	movq   rax,xmm14
    15bc:	add    rax,rax
    15bf:	je     0x15d5
    15c1:	shr    rax,0x35
    15c5:	sub    eax,0x201
    15ca:	cmp    eax,0x3fc
    15cf:	ja     0x4f6d
    15d5:	movq   rax,xmm1
    15da:	add    rax,rax
    15dd:	je     0x15f3
    15df:	shr    rax,0x35
    15e3:	sub    eax,0x201
    15e8:	cmp    eax,0x3fc
    15ed:	ja     0x4f6d
    15f3:	movdqa xmm14,xmm1
    15f8:	psrldq xmm14,0x8
    15fe:	movq   rax,xmm14
    1603:	add    rax,rax
    1606:	je     0x161c
    1608:	shr    rax,0x35
    160c:	sub    eax,0x201
    1611:	cmp    eax,0x3fc
    1616:	ja     0x4f6d
    161c:	addpd  xmm0,xmm1
    1620:	movdqa xmm4,xmm0
    1624:	movdqa xmm0,xmm4
    1628:	movdqu XMMWORD PTR [r12+0x240],xmm0
    1632:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    163c:	movdqa xmm2,xmm0
    1640:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    164a:	movdqa xmm3,xmm0
    164e:	movdqa xmm0,xmm2
    1652:	movdqa xmm1,xmm3
    1656:	movq   rax,xmm0
    165b:	add    rax,rax
    165e:	je     0x1674
    1660:	shr    rax,0x35
    1664:	sub    eax,0x201
    1669:	cmp    eax,0x3fc
    166e:	ja     0x4f91
    1674:	movdqa xmm14,xmm0
    1679:	psrldq xmm14,0x8
    167f:	movq   rax,xmm14
    1684:	add    rax,rax
    1687:	je     0x169d
    1689:	shr    rax,0x35
    168d:	sub    eax,0x201
    1692:	cmp    eax,0x3fc
    1697:	ja     0x4f91
    169d:	movq   rax,xmm1
    16a2:	add    rax,rax
    16a5:	je     0x16bb
    16a7:	shr    rax,0x35
    16ab:	sub    eax,0x201
    16b0:	cmp    eax,0x3fc
    16b5:	ja     0x4f91
    16bb:	movdqa xmm14,xmm1
    16c0:	psrldq xmm14,0x8
    16c6:	movq   rax,xmm14
    16cb:	add    rax,rax
    16ce:	je     0x16e4
    16d0:	shr    rax,0x35
    16d4:	sub    eax,0x201
    16d9:	cmp    eax,0x3fc
    16de:	ja     0x4f91
    16e4:	addpd  xmm0,xmm1
    16e8:	movdqa xmm4,xmm0
    16ec:	movdqa xmm0,xmm4
    16f0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    16fa:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    1704:	movdqa xmm2,xmm0
    1708:	movdqa xmm0,xmm2
    170c:	movdqa xmm1,xmm3
    1710:	movq   rax,xmm0
    1715:	add    rax,rax
    1718:	je     0x172e
    171a:	shr    rax,0x35
    171e:	sub    eax,0x201
    1723:	cmp    eax,0x3fc
    1728:	ja     0x4fb5
    172e:	movdqa xmm14,xmm0
    1733:	psrldq xmm14,0x8
    1739:	movq   rax,xmm14
    173e:	add    rax,rax
    1741:	je     0x1757
    1743:	shr    rax,0x35
    1747:	sub    eax,0x201
    174c:	cmp    eax,0x3fc
    1751:	ja     0x4fb5
    1757:	movq   rax,xmm1
    175c:	add    rax,rax
    175f:	je     0x1775
    1761:	shr    rax,0x35
    1765:	sub    eax,0x201
    176a:	cmp    eax,0x3fc
    176f:	ja     0x4fb5
    1775:	movdqa xmm14,xmm1
    177a:	psrldq xmm14,0x8
    1780:	movq   rax,xmm14
    1785:	add    rax,rax
    1788:	je     0x179e
    178a:	shr    rax,0x35
    178e:	sub    eax,0x201
    1793:	cmp    eax,0x3fc
    1798:	ja     0x4fb5
    179e:	addpd  xmm0,xmm1
    17a2:	movdqa xmm4,xmm0
    17a6:	movdqa xmm0,xmm4
    17aa:	movdqu XMMWORD PTR [r12+0x220],xmm0
    17b4:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    17be:	movdqa xmm2,xmm0
    17c2:	movdqa xmm1,xmm2
    17c6:	por    xmm2,xmm1
    17ca:	movdqa xmm0,xmm2
    17ce:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    17d8:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    17e2:	movdqa xmm2,xmm0
    17e6:	movdqa xmm1,xmm2
    17ea:	por    xmm2,xmm1
    17ee:	movdqa xmm0,xmm2
    17f2:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    17fc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    1806:	movdqa xmm2,xmm0
    180a:	movdqa xmm1,xmm2
    180e:	por    xmm2,xmm1
    1812:	movdqa xmm0,xmm2
    1816:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    1820:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    182a:	movdqa xmm2,xmm0
    182e:	movdqa xmm1,xmm2
    1832:	por    xmm2,xmm1
    1836:	movdqa xmm0,xmm2
    183a:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    1844:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    184e:	movdqa xmm2,xmm0
    1852:	movdqa xmm1,xmm2
    1856:	por    xmm2,xmm1
    185a:	movdqa xmm0,xmm2
    185e:	movdqu XMMWORD PTR [r12+0x200],xmm0
    1868:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    1872:	movdqa xmm2,xmm0
    1876:	movdqa xmm1,xmm2
    187a:	por    xmm2,xmm1
    187e:	movdqa xmm0,xmm2
    1882:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    188c:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    1896:	movdqa xmm2,xmm0
    189a:	movdqa xmm1,xmm2
    189e:	por    xmm2,xmm1
    18a2:	movdqa xmm0,xmm2
    18a6:	movdqu XMMWORD PTR [r12+0x190],xmm0
    18b0:	mov    r13,QWORD PTR [r12+0xf8]
    18b8:	mov    r14,r13
    18bb:	add    r14,0xa0
    18c2:	mov    r15,r14
    18c5:	add    r15,0x10
    18c9:	stmxcsr DWORD PTR [rsp+0x114]
    18d1:	ldmxcsr DWORD PTR [rsp+0x110]
    18d9:	mov    r11d,DWORD PTR [rsp+0x114]
    18e1:	shr    r11d,1
    18e4:	and    r11d,0x10
    18e8:	or     DWORD PTR [r12+0x314],r11d
    18f0:	movdqu xmm2,XMMWORD PTR [r14]
    18f5:	movdqu xmm3,XMMWORD PTR [r15]
    18fa:	movdqa xmm0,xmm2
    18fe:	movdqu XMMWORD PTR [r12+0x300],xmm0
    1908:	movdqa xmm0,xmm3
    190c:	movdqu XMMWORD PTR [r12+0x270],xmm0
    1916:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    1920:	movdqa xmm2,xmm0
    1924:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    192e:	movdqa xmm4,xmm0
    1932:	stmxcsr DWORD PTR [rsp+0x110]
    193a:	mov    DWORD PTR [rsp+0x114],0x1f80
    1945:	ldmxcsr DWORD PTR [rsp+0x114]
    194d:	movdqa xmm0,xmm2
    1951:	movdqa xmm1,xmm4
    1955:	movq   rax,xmm0
    195a:	add    rax,rax
    195d:	je     0x1973
    195f:	shr    rax,0x35
    1963:	sub    eax,0x201
    1968:	cmp    eax,0x3fc
    196d:	ja     0x4fd9
    1973:	movdqa xmm14,xmm0
    1978:	psrldq xmm14,0x8
    197e:	movq   rax,xmm14
    1983:	add    rax,rax
    1986:	je     0x199c
    1988:	shr    rax,0x35
    198c:	sub    eax,0x201
    1991:	cmp    eax,0x3fc
    1996:	ja     0x4fd9
    199c:	movq   rax,xmm1
    19a1:	add    rax,rax
    19a4:	je     0x19ba
    19a6:	shr    rax,0x35
    19aa:	sub    eax,0x201
    19af:	cmp    eax,0x3fc
    19b4:	ja     0x4fd9
    19ba:	movdqa xmm14,xmm1
    19bf:	psrldq xmm14,0x8
    19c5:	movq   rax,xmm14
    19ca:	add    rax,rax
    19cd:	je     0x19e3
    19cf:	shr    rax,0x35
    19d3:	sub    eax,0x201
    19d8:	cmp    eax,0x3fc
    19dd:	ja     0x4fd9
    19e3:	addpd  xmm0,xmm1
    19e7:	movdqa xmm5,xmm0
    19eb:	movdqa xmm0,xmm5
    19ef:	movdqu XMMWORD PTR [r12+0x180],xmm0
    19f9:	add    r13,0xf0
    1a00:	stmxcsr DWORD PTR [rsp+0x114]
    1a08:	ldmxcsr DWORD PTR [rsp+0x110]
    1a10:	mov    r11d,DWORD PTR [rsp+0x114]
    1a18:	shr    r11d,1
    1a1b:	and    r11d,0x10
    1a1f:	or     DWORD PTR [r12+0x314],r11d
    1a27:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    1a2d:	movdqa xmm0,xmm2
    1a31:	movdqu XMMWORD PTR [r12+0x110],xmm0
    1a3b:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    1a45:	movdqa xmm4,xmm0
    1a49:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    1a53:	movdqa xmm5,xmm0
    1a57:	stmxcsr DWORD PTR [rsp+0x110]
    1a5f:	mov    DWORD PTR [rsp+0x114],0x1f80
    1a6a:	ldmxcsr DWORD PTR [rsp+0x114]
    1a72:	movdqa xmm0,xmm4
    1a76:	movdqa xmm1,xmm5
    1a7a:	movq   rax,xmm0
    1a7f:	add    rax,rax
    1a82:	je     0x1a98
    1a84:	shr    rax,0x35
    1a88:	sub    eax,0x201
    1a8d:	cmp    eax,0x3fc
    1a92:	ja     0x4ffd
    1a98:	movdqa xmm14,xmm0
    1a9d:	psrldq xmm14,0x8
    1aa3:	movq   rax,xmm14
    1aa8:	add    rax,rax
    1aab:	je     0x1ac1
    1aad:	shr    rax,0x35
    1ab1:	sub    eax,0x201
    1ab6:	cmp    eax,0x3fc
    1abb:	ja     0x4ffd
    1ac1:	movq   rax,xmm1
    1ac6:	add    rax,rax
    1ac9:	je     0x1adf
    1acb:	shr    rax,0x35
    1acf:	sub    eax,0x201
    1ad4:	cmp    eax,0x3fc
    1ad9:	ja     0x4ffd
    1adf:	movdqa xmm14,xmm1
    1ae4:	psrldq xmm14,0x8
    1aea:	movq   rax,xmm14
    1aef:	add    rax,rax
    1af2:	je     0x1b08
    1af4:	shr    rax,0x35
    1af8:	sub    eax,0x201
    1afd:	cmp    eax,0x3fc
    1b02:	ja     0x4ffd
    1b08:	addpd  xmm0,xmm1
    1b0c:	movdqa xmm6,xmm0
    1b10:	movdqa xmm0,xmm6
    1b14:	movdqu XMMWORD PTR [r12+0x210],xmm0
    1b1e:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    1b28:	movdqa xmm4,xmm0
    1b2c:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    1b36:	movdqa xmm5,xmm0
    1b3a:	movdqa xmm0,xmm4
    1b3e:	movdqa xmm1,xmm5
    1b42:	movq   rax,xmm0
    1b47:	add    rax,rax
    1b4a:	je     0x1b60
    1b4c:	shr    rax,0x35
    1b50:	sub    eax,0x201
    1b55:	cmp    eax,0x3fc
    1b5a:	ja     0x5021
    1b60:	movdqa xmm14,xmm0
    1b65:	psrldq xmm14,0x8
    1b6b:	movq   rax,xmm14
    1b70:	add    rax,rax
    1b73:	je     0x1b89
    1b75:	shr    rax,0x35
    1b79:	sub    eax,0x201
    1b7e:	cmp    eax,0x3fc
    1b83:	ja     0x5021
    1b89:	movq   rax,xmm1
    1b8e:	add    rax,rax
    1b91:	je     0x1ba7
    1b93:	shr    rax,0x35
    1b97:	sub    eax,0x201
    1b9c:	cmp    eax,0x3fc
    1ba1:	ja     0x5021
    1ba7:	movdqa xmm14,xmm1
    1bac:	psrldq xmm14,0x8
    1bb2:	movq   rax,xmm14
    1bb7:	add    rax,rax
    1bba:	je     0x1bd0
    1bbc:	shr    rax,0x35
    1bc0:	sub    eax,0x201
    1bc5:	cmp    eax,0x3fc
    1bca:	ja     0x5021
    1bd0:	addpd  xmm0,xmm1
    1bd4:	movdqa xmm6,xmm0
    1bd8:	movdqa xmm0,xmm6
    1bdc:	movdqu XMMWORD PTR [r12+0x220],xmm0
    1be6:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    1bf0:	movdqa xmm4,xmm0
    1bf4:	movdqa xmm0,xmm3
    1bf8:	movdqa xmm1,xmm4
    1bfc:	pshufd xmm1,xmm1,0x44
    1c01:	movq   rax,xmm0
    1c06:	add    rax,rax
    1c09:	je     0x1c1f
    1c0b:	shr    rax,0x35
    1c0f:	sub    eax,0x201
    1c14:	cmp    eax,0x3fc
    1c19:	ja     0x5045
    1c1f:	movdqa xmm14,xmm0
    1c24:	psrldq xmm14,0x8
    1c2a:	movq   rax,xmm14
    1c2f:	add    rax,rax
    1c32:	je     0x1c48
    1c34:	shr    rax,0x35
    1c38:	sub    eax,0x201
    1c3d:	cmp    eax,0x3fc
    1c42:	ja     0x5045
    1c48:	movq   rax,xmm1
    1c4d:	add    rax,rax
    1c50:	je     0x1c66
    1c52:	shr    rax,0x35
    1c56:	sub    eax,0x201
    1c5b:	cmp    eax,0x3fc
    1c60:	ja     0x5045
    1c66:	movdqa xmm14,xmm1
    1c6b:	psrldq xmm14,0x8
    1c71:	movq   rax,xmm14
    1c76:	add    rax,rax
    1c79:	je     0x1c8f
    1c7b:	shr    rax,0x35
    1c7f:	sub    eax,0x201
    1c84:	cmp    eax,0x3fc
    1c89:	ja     0x5045
    1c8f:	mulpd  xmm0,xmm1
    1c93:	movdqa xmm5,xmm0
    1c97:	movdqa xmm0,xmm5
    1c9b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    1ca5:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    1caf:	movdqa xmm3,xmm0
    1cb3:	movdqa xmm0,xmm2
    1cb7:	movdqa xmm1,xmm3
    1cbb:	pshufd xmm1,xmm1,0x44
    1cc0:	movq   rax,xmm0
    1cc5:	add    rax,rax
    1cc8:	je     0x1cde
    1cca:	shr    rax,0x35
    1cce:	sub    eax,0x201
    1cd3:	cmp    eax,0x3fc
    1cd8:	ja     0x5069
    1cde:	movdqa xmm14,xmm0
    1ce3:	psrldq xmm14,0x8
    1ce9:	movq   rax,xmm14
    1cee:	add    rax,rax
    1cf1:	je     0x1d07
    1cf3:	shr    rax,0x35
    1cf7:	sub    eax,0x201
    1cfc:	cmp    eax,0x3fc
    1d01:	ja     0x5069
    1d07:	movq   rax,xmm1
    1d0c:	add    rax,rax
    1d0f:	je     0x1d25
    1d11:	shr    rax,0x35
    1d15:	sub    eax,0x201
    1d1a:	cmp    eax,0x3fc
    1d1f:	ja     0x5069
    1d25:	movdqa xmm14,xmm1
    1d2a:	psrldq xmm14,0x8
    1d30:	movq   rax,xmm14
    1d35:	add    rax,rax
    1d38:	je     0x1d4e
    1d3a:	shr    rax,0x35
    1d3e:	sub    eax,0x201
    1d43:	cmp    eax,0x3fc
    1d48:	ja     0x5069
    1d4e:	mulpd  xmm0,xmm1
    1d52:	movdqa xmm5,xmm0
    1d56:	movdqa xmm0,xmm5
    1d5a:	movdqu XMMWORD PTR [r12+0x250],xmm0
    1d64:	mov    r13,QWORD PTR [r12+0xf8]
    1d6c:	mov    r14,r13
    1d6f:	add    r14,0xe0
    1d76:	stmxcsr DWORD PTR [rsp+0x114]
    1d7e:	ldmxcsr DWORD PTR [rsp+0x110]
    1d86:	mov    r11d,DWORD PTR [rsp+0x114]
    1d8e:	shr    r11d,1
    1d91:	and    r11d,0x10
    1d95:	or     DWORD PTR [r12+0x314],r11d
    1d9d:	movdqu xmm2,XMMWORD PTR [r14]
    1da2:	movdqa xmm0,xmm2
    1da6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    1db0:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    1dba:	movdqa xmm2,xmm0
    1dbe:	stmxcsr DWORD PTR [rsp+0x110]
    1dc6:	mov    DWORD PTR [rsp+0x114],0x1f80
    1dd1:	ldmxcsr DWORD PTR [rsp+0x114]
    1dd9:	movdqa xmm0,xmm2
    1ddd:	movdqa xmm1,xmm4
    1de1:	pshufd xmm1,xmm1,0x44
    1de6:	movq   rax,xmm0
    1deb:	add    rax,rax
    1dee:	je     0x1e04
    1df0:	shr    rax,0x35
    1df4:	sub    eax,0x201
    1df9:	cmp    eax,0x3fc
    1dfe:	ja     0x508d
    1e04:	movdqa xmm14,xmm0
    1e09:	psrldq xmm14,0x8
    1e0f:	movq   rax,xmm14
    1e14:	add    rax,rax
    1e17:	je     0x1e2d
    1e19:	shr    rax,0x35
    1e1d:	sub    eax,0x201
    1e22:	cmp    eax,0x3fc
    1e27:	ja     0x508d
    1e2d:	movq   rax,xmm1
    1e32:	add    rax,rax
    1e35:	je     0x1e4b
    1e37:	shr    rax,0x35
    1e3b:	sub    eax,0x201
    1e40:	cmp    eax,0x3fc
    1e45:	ja     0x508d
    1e4b:	movdqa xmm14,xmm1
    1e50:	psrldq xmm14,0x8
    1e56:	movq   rax,xmm14
    1e5b:	add    rax,rax
    1e5e:	je     0x1e74
    1e60:	shr    rax,0x35
    1e64:	sub    eax,0x201
    1e69:	cmp    eax,0x3fc
    1e6e:	ja     0x508d
    1e74:	mulpd  xmm0,xmm1
    1e78:	movdqa xmm5,xmm0
    1e7c:	movdqa xmm0,xmm5
    1e80:	movdqu XMMWORD PTR [r12+0x230],xmm0
    1e8a:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    1e94:	movdqa xmm2,xmm0
    1e98:	movdqa xmm1,xmm2
    1e9c:	por    xmm2,xmm1
    1ea0:	movdqa xmm0,xmm2
    1ea4:	movdqu XMMWORD PTR [r12+0x300],xmm0
    1eae:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    1eb8:	movdqa xmm2,xmm0
    1ebc:	movdqa xmm1,xmm2
    1ec0:	por    xmm2,xmm1
    1ec4:	movdqa xmm0,xmm2
    1ec8:	movdqu XMMWORD PTR [r12+0x190],xmm0
    1ed2:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    1edc:	movdqa xmm2,xmm0
    1ee0:	movdqa xmm0,xmm2
    1ee4:	movdqa xmm1,xmm3
    1ee8:	pshufd xmm1,xmm1,0x44
    1eed:	movq   rax,xmm0
    1ef2:	add    rax,rax
    1ef5:	je     0x1f0b
    1ef7:	shr    rax,0x35
    1efb:	sub    eax,0x201
    1f00:	cmp    eax,0x3fc
    1f05:	ja     0x50b1
    1f0b:	movdqa xmm14,xmm0
    1f10:	psrldq xmm14,0x8
    1f16:	movq   rax,xmm14
    1f1b:	add    rax,rax
    1f1e:	je     0x1f34
    1f20:	shr    rax,0x35
    1f24:	sub    eax,0x201
    1f29:	cmp    eax,0x3fc
    1f2e:	ja     0x50b1
    1f34:	movq   rax,xmm1
    1f39:	add    rax,rax
    1f3c:	je     0x1f52
    1f3e:	shr    rax,0x35
    1f42:	sub    eax,0x201
    1f47:	cmp    eax,0x3fc
    1f4c:	ja     0x50b1
    1f52:	movdqa xmm14,xmm1
    1f57:	psrldq xmm14,0x8
    1f5d:	movq   rax,xmm14
    1f62:	add    rax,rax
    1f65:	je     0x1f7b
    1f67:	shr    rax,0x35
    1f6b:	sub    eax,0x201
    1f70:	cmp    eax,0x3fc
    1f75:	ja     0x50b1
    1f7b:	mulpd  xmm0,xmm1
    1f7f:	movdqa xmm4,xmm0
    1f83:	movdqa xmm0,xmm4
    1f87:	movdqu XMMWORD PTR [r12+0x260],xmm0
    1f91:	add    r13,0x90
    1f98:	stmxcsr DWORD PTR [rsp+0x114]
    1fa0:	ldmxcsr DWORD PTR [rsp+0x110]
    1fa8:	mov    r11d,DWORD PTR [rsp+0x114]
    1fb0:	shr    r11d,1
    1fb3:	and    r11d,0x10
    1fb7:	or     DWORD PTR [r12+0x314],r11d
    1fbf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    1fc5:	movdqa xmm0,xmm2
    1fc9:	movdqu XMMWORD PTR [r12+0x110],xmm0
    1fd3:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    1fdd:	movdqa xmm3,xmm0
    1fe1:	movdqa xmm1,xmm3
    1fe5:	por    xmm3,xmm1
    1fe9:	movdqa xmm0,xmm3
    1fed:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    1ff7:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    2001:	movdqa xmm3,xmm0
    2005:	movdqa xmm1,xmm3
    2009:	por    xmm3,xmm1
    200d:	movdqa xmm0,xmm3
    2011:	movdqu XMMWORD PTR [r12+0x200],xmm0
    201b:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    2025:	movdqa xmm3,xmm0
    2029:	movdqa xmm1,xmm3
    202d:	por    xmm3,xmm1
    2031:	movdqa xmm0,xmm3
    2035:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    203f:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    2049:	movdqa xmm3,xmm0
    204d:	movdqa xmm1,xmm3
    2051:	por    xmm3,xmm1
    2055:	movdqa xmm0,xmm3
    2059:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    2063:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    206d:	movdqa xmm3,xmm0
    2071:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    207b:	movdqa xmm4,xmm0
    207f:	stmxcsr DWORD PTR [rsp+0x110]
    2087:	mov    DWORD PTR [rsp+0x114],0x1f80
    2092:	ldmxcsr DWORD PTR [rsp+0x114]
    209a:	movdqa xmm0,xmm3
    209e:	movdqa xmm1,xmm4
    20a2:	movq   rax,xmm0
    20a7:	add    rax,rax
    20aa:	je     0x20c0
    20ac:	shr    rax,0x35
    20b0:	sub    eax,0x201
    20b5:	cmp    eax,0x3fc
    20ba:	ja     0x50d5
    20c0:	movdqa xmm14,xmm0
    20c5:	psrldq xmm14,0x8
    20cb:	movq   rax,xmm14
    20d0:	add    rax,rax
    20d3:	je     0x20e9
    20d5:	shr    rax,0x35
    20d9:	sub    eax,0x201
    20de:	cmp    eax,0x3fc
    20e3:	ja     0x50d5
    20e9:	movq   rax,xmm1
    20ee:	add    rax,rax
    20f1:	je     0x2107
    20f3:	shr    rax,0x35
    20f7:	sub    eax,0x201
    20fc:	cmp    eax,0x3fc
    2101:	ja     0x50d5
    2107:	movdqa xmm14,xmm1
    210c:	psrldq xmm14,0x8
    2112:	movq   rax,xmm14
    2117:	add    rax,rax
    211a:	je     0x2130
    211c:	shr    rax,0x35
    2120:	sub    eax,0x201
    2125:	cmp    eax,0x3fc
    212a:	ja     0x50d5
    2130:	addpd  xmm0,xmm1
    2134:	movdqa xmm5,xmm0
    2138:	movdqa xmm0,xmm5
    213c:	movdqu XMMWORD PTR [r12+0x240],xmm0
    2146:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    2150:	movdqa xmm3,xmm0
    2154:	movdqa xmm0,xmm2
    2158:	movdqa xmm1,xmm3
    215c:	pshufd xmm1,xmm1,0x44
    2161:	movq   rax,xmm0
    2166:	add    rax,rax
    2169:	je     0x217f
    216b:	shr    rax,0x35
    216f:	sub    eax,0x201
    2174:	cmp    eax,0x3fc
    2179:	ja     0x50f9
    217f:	movdqa xmm14,xmm0
    2184:	psrldq xmm14,0x8
    218a:	movq   rax,xmm14
    218f:	add    rax,rax
    2192:	je     0x21a8
    2194:	shr    rax,0x35
    2198:	sub    eax,0x201
    219d:	cmp    eax,0x3fc
    21a2:	ja     0x50f9
    21a8:	movq   rax,xmm1
    21ad:	add    rax,rax
    21b0:	je     0x21c6
    21b2:	shr    rax,0x35
    21b6:	sub    eax,0x201
    21bb:	cmp    eax,0x3fc
    21c0:	ja     0x50f9
    21c6:	movdqa xmm14,xmm1
    21cb:	psrldq xmm14,0x8
    21d1:	movq   rax,xmm14
    21d6:	add    rax,rax
    21d9:	je     0x21ef
    21db:	shr    rax,0x35
    21df:	sub    eax,0x201
    21e4:	cmp    eax,0x3fc
    21e9:	ja     0x50f9
    21ef:	mulpd  xmm0,xmm1
    21f3:	movdqa xmm4,xmm0
    21f7:	movdqa xmm0,xmm4
    21fb:	movdqu XMMWORD PTR [r12+0x270],xmm0
    2205:	mov    r13,QWORD PTR [r12+0xf8]
    220d:	add    r13,0x80
    2214:	stmxcsr DWORD PTR [rsp+0x114]
    221c:	ldmxcsr DWORD PTR [rsp+0x110]
    2224:	mov    r11d,DWORD PTR [rsp+0x114]
    222c:	shr    r11d,1
    222f:	and    r11d,0x10
    2233:	or     DWORD PTR [r12+0x314],r11d
    223b:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    2241:	movdqa xmm0,xmm2
    2245:	movdqu XMMWORD PTR [r12+0x110],xmm0
    224f:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    2259:	movdqa xmm3,xmm0
    225d:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    2267:	movdqa xmm4,xmm0
    226b:	stmxcsr DWORD PTR [rsp+0x110]
    2273:	mov    DWORD PTR [rsp+0x114],0x1f80
    227e:	ldmxcsr DWORD PTR [rsp+0x114]
    2286:	movdqa xmm0,xmm3
    228a:	movdqa xmm1,xmm4
    228e:	movq   rax,xmm0
    2293:	add    rax,rax
    2296:	je     0x22ac
    2298:	shr    rax,0x35
    229c:	sub    eax,0x201
    22a1:	cmp    eax,0x3fc
    22a6:	ja     0x511d
    22ac:	movdqa xmm14,xmm0
    22b1:	psrldq xmm14,0x8
    22b7:	movq   rax,xmm14
    22bc:	add    rax,rax
    22bf:	je     0x22d5
    22c1:	shr    rax,0x35
    22c5:	sub    eax,0x201
    22ca:	cmp    eax,0x3fc
    22cf:	ja     0x511d
    22d5:	movq   rax,xmm1
    22da:	add    rax,rax
    22dd:	je     0x22f3
    22df:	shr    rax,0x35
    22e3:	sub    eax,0x201
    22e8:	cmp    eax,0x3fc
    22ed:	ja     0x511d
    22f3:	movdqa xmm14,xmm1
    22f8:	psrldq xmm14,0x8
    22fe:	movq   rax,xmm14
    2303:	add    rax,rax
    2306:	je     0x231c
    2308:	shr    rax,0x35
    230c:	sub    eax,0x201
    2311:	cmp    eax,0x3fc
    2316:	ja     0x511d
    231c:	addpd  xmm0,xmm1
    2320:	movdqa xmm5,xmm0
    2324:	movdqa xmm0,xmm5
    2328:	movdqu XMMWORD PTR [r12+0x180],xmm0
    2332:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    233c:	movdqa xmm3,xmm0
    2340:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    234a:	movdqa xmm4,xmm0
    234e:	movdqa xmm0,xmm3
    2352:	movdqa xmm1,xmm4
    2356:	movq   rax,xmm0
    235b:	add    rax,rax
    235e:	je     0x2374
    2360:	shr    rax,0x35
    2364:	sub    eax,0x201
    2369:	cmp    eax,0x3fc
    236e:	ja     0x5141
    2374:	movdqa xmm14,xmm0
    2379:	psrldq xmm14,0x8
    237f:	movq   rax,xmm14
    2384:	add    rax,rax
    2387:	je     0x239d
    2389:	shr    rax,0x35
    238d:	sub    eax,0x201
    2392:	cmp    eax,0x3fc
    2397:	ja     0x5141
    239d:	movq   rax,xmm1
    23a2:	add    rax,rax
    23a5:	je     0x23bb
    23a7:	shr    rax,0x35
    23ab:	sub    eax,0x201
    23b0:	cmp    eax,0x3fc
    23b5:	ja     0x5141
    23bb:	movdqa xmm14,xmm1
    23c0:	psrldq xmm14,0x8
    23c6:	movq   rax,xmm14
    23cb:	add    rax,rax
    23ce:	je     0x23e4
    23d0:	shr    rax,0x35
    23d4:	sub    eax,0x201
    23d9:	cmp    eax,0x3fc
    23de:	ja     0x5141
    23e4:	addpd  xmm0,xmm1
    23e8:	movdqa xmm5,xmm0
    23ec:	movdqa xmm0,xmm5
    23f0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    23fa:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    2404:	movdqa xmm3,xmm0
    2408:	movdqa xmm1,xmm3
    240c:	por    xmm3,xmm1
    2410:	movdqa xmm0,xmm3
    2414:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    241e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    2428:	movdqa xmm3,xmm0
    242c:	movdqa xmm0,xmm2
    2430:	movdqa xmm1,xmm3
    2434:	pshufd xmm1,xmm1,0x44
    2439:	movq   rax,xmm0
    243e:	add    rax,rax
    2441:	je     0x2457
    2443:	shr    rax,0x35
    2447:	sub    eax,0x201
    244c:	cmp    eax,0x3fc
    2451:	ja     0x5165
    2457:	movdqa xmm14,xmm0
    245c:	psrldq xmm14,0x8
    2462:	movq   rax,xmm14
    2467:	add    rax,rax
    246a:	je     0x2480
    246c:	shr    rax,0x35
    2470:	sub    eax,0x201
    2475:	cmp    eax,0x3fc
    247a:	ja     0x5165
    2480:	movq   rax,xmm1
    2485:	add    rax,rax
    2488:	je     0x249e
    248a:	shr    rax,0x35
    248e:	sub    eax,0x201
    2493:	cmp    eax,0x3fc
    2498:	ja     0x5165
    249e:	movdqa xmm14,xmm1
    24a3:	psrldq xmm14,0x8
    24a9:	movq   rax,xmm14
    24ae:	add    rax,rax
    24b1:	je     0x24c7
    24b3:	shr    rax,0x35
    24b7:	sub    eax,0x201
    24bc:	cmp    eax,0x3fc
    24c1:	ja     0x5165
    24c7:	mulpd  xmm0,xmm1
    24cb:	movdqa xmm4,xmm0
    24cf:	movdqa xmm0,xmm4
    24d3:	movdqu XMMWORD PTR [r12+0x170],xmm0
    24dd:	mov    r13,QWORD PTR [r12+0xf8]
    24e5:	add    r13,0xd0
    24ec:	stmxcsr DWORD PTR [rsp+0x114]
    24f4:	ldmxcsr DWORD PTR [rsp+0x110]
    24fc:	mov    r11d,DWORD PTR [rsp+0x114]
    2504:	shr    r11d,1
    2507:	and    r11d,0x10
    250b:	or     DWORD PTR [r12+0x314],r11d
    2513:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    2519:	movdqa xmm0,xmm2
    251d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    2527:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    2531:	movdqa xmm3,xmm0
    2535:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    253f:	movdqa xmm4,xmm0
    2543:	stmxcsr DWORD PTR [rsp+0x110]
    254b:	mov    DWORD PTR [rsp+0x114],0x1f80
    2556:	ldmxcsr DWORD PTR [rsp+0x114]
    255e:	movdqa xmm0,xmm3
    2562:	movdqa xmm1,xmm4
    2566:	movq   rax,xmm0
    256b:	add    rax,rax
    256e:	je     0x2584
    2570:	shr    rax,0x35
    2574:	sub    eax,0x201
    2579:	cmp    eax,0x3fc
    257e:	ja     0x5189
    2584:	movdqa xmm14,xmm0
    2589:	psrldq xmm14,0x8
    258f:	movq   rax,xmm14
    2594:	add    rax,rax
    2597:	je     0x25ad
    2599:	shr    rax,0x35
    259d:	sub    eax,0x201
    25a2:	cmp    eax,0x3fc
    25a7:	ja     0x5189
    25ad:	movq   rax,xmm1
    25b2:	add    rax,rax
    25b5:	je     0x25cb
    25b7:	shr    rax,0x35
    25bb:	sub    eax,0x201
    25c0:	cmp    eax,0x3fc
    25c5:	ja     0x5189
    25cb:	movdqa xmm14,xmm1
    25d0:	psrldq xmm14,0x8
    25d6:	movq   rax,xmm14
    25db:	add    rax,rax
    25de:	je     0x25f4
    25e0:	shr    rax,0x35
    25e4:	sub    eax,0x201
    25e9:	cmp    eax,0x3fc
    25ee:	ja     0x5189
    25f4:	addpd  xmm0,xmm1
    25f8:	movdqa xmm5,xmm0
    25fc:	movdqa xmm0,xmm5
    2600:	movdqu XMMWORD PTR [r12+0x220],xmm0
    260a:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    2614:	movdqa xmm3,xmm0
    2618:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    2622:	movdqa xmm4,xmm0
    2626:	movdqa xmm0,xmm3
    262a:	movdqa xmm1,xmm4
    262e:	pshufd xmm1,xmm1,0x44
    2633:	movq   rax,xmm0
    2638:	add    rax,rax
    263b:	je     0x2651
    263d:	shr    rax,0x35
    2641:	sub    eax,0x201
    2646:	cmp    eax,0x3fc
    264b:	ja     0x51ad
    2651:	movdqa xmm14,xmm0
    2656:	psrldq xmm14,0x8
    265c:	movq   rax,xmm14
    2661:	add    rax,rax
    2664:	je     0x267a
    2666:	shr    rax,0x35
    266a:	sub    eax,0x201
    266f:	cmp    eax,0x3fc
    2674:	ja     0x51ad
    267a:	movq   rax,xmm1
    267f:	add    rax,rax
    2682:	je     0x2698
    2684:	shr    rax,0x35
    2688:	sub    eax,0x201
    268d:	cmp    eax,0x3fc
    2692:	ja     0x51ad
    2698:	movdqa xmm14,xmm1
    269d:	psrldq xmm14,0x8
    26a3:	movq   rax,xmm14
    26a8:	add    rax,rax
    26ab:	je     0x26c1
    26ad:	shr    rax,0x35
    26b1:	sub    eax,0x201
    26b6:	cmp    eax,0x3fc
    26bb:	ja     0x51ad
    26c1:	mulpd  xmm0,xmm1
    26c5:	movdqa xmm5,xmm0
    26c9:	movdqa xmm0,xmm5
    26cd:	movdqu XMMWORD PTR [r12+0x260],xmm0
    26d7:	mov    r13d,0x0
    26dd:	mov    r14d,0x0
    26e3:	mov    QWORD PTR [r12+0x1b0],r13
    26eb:	mov    QWORD PTR [r12+0x1b8],r14
    26f3:	movdqa xmm0,xmm2
    26f7:	movdqa xmm1,xmm4
    26fb:	pshufd xmm1,xmm1,0x44
    2700:	movq   rax,xmm0
    2705:	add    rax,rax
    2708:	je     0x271e
    270a:	shr    rax,0x35
    270e:	sub    eax,0x201
    2713:	cmp    eax,0x3fc
    2718:	ja     0x51d1
    271e:	movdqa xmm14,xmm0
    2723:	psrldq xmm14,0x8
    2729:	movq   rax,xmm14
    272e:	add    rax,rax
    2731:	je     0x2747
    2733:	shr    rax,0x35
    2737:	sub    eax,0x201
    273c:	cmp    eax,0x3fc
    2741:	ja     0x51d1
    2747:	movq   rax,xmm1
    274c:	add    rax,rax
    274f:	je     0x2765
    2751:	shr    rax,0x35
    2755:	sub    eax,0x201
    275a:	cmp    eax,0x3fc
    275f:	ja     0x51d1
    2765:	movdqa xmm14,xmm1
    276a:	psrldq xmm14,0x8
    2770:	movq   rax,xmm14
    2775:	add    rax,rax
    2778:	je     0x278e
    277a:	shr    rax,0x35
    277e:	sub    eax,0x201
    2783:	cmp    eax,0x3fc
    2788:	ja     0x51d1
    278e:	mulpd  xmm0,xmm1
    2792:	movdqa xmm3,xmm0
    2796:	movdqa xmm0,xmm3
    279a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    27a4:	mov    r13,QWORD PTR [r12+0xf8]
    27ac:	mov    r14,r13
    27af:	add    r14,0xc0
    27b6:	stmxcsr DWORD PTR [rsp+0x114]
    27be:	ldmxcsr DWORD PTR [rsp+0x110]
    27c6:	mov    r11d,DWORD PTR [rsp+0x114]
    27ce:	shr    r11d,1
    27d1:	and    r11d,0x10
    27d5:	or     DWORD PTR [r12+0x314],r11d
    27dd:	movdqu xmm2,XMMWORD PTR [r14]
    27e2:	movdqa xmm0,xmm2
    27e6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    27f0:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    27fa:	movdqa xmm3,xmm0
    27fe:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    2808:	movdqa xmm4,xmm0
    280c:	stmxcsr DWORD PTR [rsp+0x110]
    2814:	mov    DWORD PTR [rsp+0x114],0x1f80
    281f:	ldmxcsr DWORD PTR [rsp+0x114]
    2827:	movdqa xmm0,xmm3
    282b:	movdqa xmm1,xmm4
    282f:	movq   rax,xmm0
    2834:	add    rax,rax
    2837:	je     0x284d
    2839:	shr    rax,0x35
    283d:	sub    eax,0x201
    2842:	cmp    eax,0x3fc
    2847:	ja     0x51f5
    284d:	movdqa xmm14,xmm0
    2852:	psrldq xmm14,0x8
    2858:	movq   rax,xmm14
    285d:	add    rax,rax
    2860:	je     0x2876
    2862:	shr    rax,0x35
    2866:	sub    eax,0x201
    286b:	cmp    eax,0x3fc
    2870:	ja     0x51f5
    2876:	movq   rax,xmm1
    287b:	add    rax,rax
    287e:	je     0x2894
    2880:	shr    rax,0x35
    2884:	sub    eax,0x201
    2889:	cmp    eax,0x3fc
    288e:	ja     0x51f5
    2894:	movdqa xmm14,xmm1
    2899:	psrldq xmm14,0x8
    289f:	movq   rax,xmm14
    28a4:	add    rax,rax
    28a7:	je     0x28bd
    28a9:	shr    rax,0x35
    28ad:	sub    eax,0x201
    28b2:	cmp    eax,0x3fc
    28b7:	ja     0x51f5
    28bd:	addpd  xmm0,xmm1
    28c1:	movdqa xmm5,xmm0
    28c5:	movdqa xmm0,xmm5
    28c9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    28d3:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    28dd:	movdqa xmm3,xmm0
    28e1:	movdqa xmm1,xmm3
    28e5:	por    xmm3,xmm1
    28e9:	movdqa xmm0,xmm3
    28ed:	movdqu XMMWORD PTR [r12+0x270],xmm0
    28f7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    2901:	movdqa xmm3,xmm0
    2905:	movdqa xmm1,xmm3
    2909:	por    xmm3,xmm1
    290d:	movdqa xmm0,xmm3
    2911:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    291b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    2925:	movdqa xmm3,xmm0
    2929:	movdqa xmm0,xmm2
    292d:	movdqa xmm1,xmm3
    2931:	pshufd xmm1,xmm1,0x44
    2936:	movq   rax,xmm0
    293b:	add    rax,rax
    293e:	je     0x2954
    2940:	shr    rax,0x35
    2944:	sub    eax,0x201
    2949:	cmp    eax,0x3fc
    294e:	ja     0x5219
    2954:	movdqa xmm14,xmm0
    2959:	psrldq xmm14,0x8
    295f:	movq   rax,xmm14
    2964:	add    rax,rax
    2967:	je     0x297d
    2969:	shr    rax,0x35
    296d:	sub    eax,0x201
    2972:	cmp    eax,0x3fc
    2977:	ja     0x5219
    297d:	movq   rax,xmm1
    2982:	add    rax,rax
    2985:	je     0x299b
    2987:	shr    rax,0x35
    298b:	sub    eax,0x201
    2990:	cmp    eax,0x3fc
    2995:	ja     0x5219
    299b:	movdqa xmm14,xmm1
    29a0:	psrldq xmm14,0x8
    29a6:	movq   rax,xmm14
    29ab:	add    rax,rax
    29ae:	je     0x29c4
    29b0:	shr    rax,0x35
    29b4:	sub    eax,0x201
    29b9:	cmp    eax,0x3fc
    29be:	ja     0x5219
    29c4:	mulpd  xmm0,xmm1
    29c8:	movdqa xmm4,xmm0
    29cc:	movdqa xmm0,xmm4
    29d0:	movdqu XMMWORD PTR [r12+0x250],xmm0
    29da:	add    r13,0x20
    29de:	stmxcsr DWORD PTR [rsp+0x114]
    29e6:	ldmxcsr DWORD PTR [rsp+0x110]
    29ee:	mov    r11d,DWORD PTR [rsp+0x114]
    29f6:	shr    r11d,1
    29f9:	and    r11d,0x10
    29fd:	or     DWORD PTR [r12+0x314],r11d
    2a05:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    2a0b:	movdqa xmm0,xmm2
    2a0f:	movdqu XMMWORD PTR [r12+0x110],xmm0
    2a19:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    2a23:	movdqa xmm2,xmm0
    2a27:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    2a31:	movdqa xmm4,xmm0
    2a35:	stmxcsr DWORD PTR [rsp+0x110]
    2a3d:	mov    DWORD PTR [rsp+0x114],0x1f80
    2a48:	ldmxcsr DWORD PTR [rsp+0x114]
    2a50:	movdqa xmm0,xmm2
    2a54:	movdqa xmm1,xmm4
    2a58:	movq   rax,xmm0
    2a5d:	add    rax,rax
    2a60:	je     0x2a76
    2a62:	shr    rax,0x35
    2a66:	sub    eax,0x201
    2a6b:	cmp    eax,0x3fc
    2a70:	ja     0x523d
    2a76:	movdqa xmm14,xmm0
    2a7b:	psrldq xmm14,0x8
    2a81:	movq   rax,xmm14
    2a86:	add    rax,rax
    2a89:	je     0x2a9f
    2a8b:	shr    rax,0x35
    2a8f:	sub    eax,0x201
    2a94:	cmp    eax,0x3fc
    2a99:	ja     0x523d
    2a9f:	movq   rax,xmm1
    2aa4:	add    rax,rax
    2aa7:	je     0x2abd
    2aa9:	shr    rax,0x35
    2aad:	sub    eax,0x201
    2ab2:	cmp    eax,0x3fc
    2ab7:	ja     0x523d
    2abd:	movdqa xmm14,xmm1
    2ac2:	psrldq xmm14,0x8
    2ac8:	movq   rax,xmm14
    2acd:	add    rax,rax
    2ad0:	je     0x2ae6
    2ad2:	shr    rax,0x35
    2ad6:	sub    eax,0x201
    2adb:	cmp    eax,0x3fc
    2ae0:	ja     0x523d
    2ae6:	addpd  xmm0,xmm1
    2aea:	movdqa xmm5,xmm0
    2aee:	movdqa xmm0,xmm5
    2af2:	movdqu XMMWORD PTR [r12+0x170],xmm0
    2afc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    2b06:	movdqa xmm2,xmm0
    2b0a:	movdqa xmm0,xmm2
    2b0e:	movdqa xmm1,xmm3
    2b12:	pshufd xmm1,xmm1,0x44
    2b17:	movq   rax,xmm0
    2b1c:	add    rax,rax
    2b1f:	je     0x2b35
    2b21:	shr    rax,0x35
    2b25:	sub    eax,0x201
    2b2a:	cmp    eax,0x3fc
    2b2f:	ja     0x5261
    2b35:	movdqa xmm14,xmm0
    2b3a:	psrldq xmm14,0x8
    2b40:	movq   rax,xmm14
    2b45:	add    rax,rax
    2b48:	je     0x2b5e
    2b4a:	shr    rax,0x35
    2b4e:	sub    eax,0x201
    2b53:	cmp    eax,0x3fc
    2b58:	ja     0x5261
    2b5e:	movq   rax,xmm1
    2b63:	add    rax,rax
    2b66:	je     0x2b7c
    2b68:	shr    rax,0x35
    2b6c:	sub    eax,0x201
    2b71:	cmp    eax,0x3fc
    2b76:	ja     0x5261
    2b7c:	movdqa xmm14,xmm1
    2b81:	psrldq xmm14,0x8
    2b87:	movq   rax,xmm14
    2b8c:	add    rax,rax
    2b8f:	je     0x2ba5
    2b91:	shr    rax,0x35
    2b95:	sub    eax,0x201
    2b9a:	cmp    eax,0x3fc
    2b9f:	ja     0x5261
    2ba5:	mulpd  xmm0,xmm1
    2ba9:	movdqa xmm4,xmm0
    2bad:	movdqa xmm0,xmm4
    2bb1:	movdqu XMMWORD PTR [r12+0x160],xmm0
    2bbb:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    2bc5:	movdqa xmm2,xmm0
    2bc9:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    2bd3:	movdqa xmm3,xmm0
    2bd7:	movdqa xmm0,xmm2
    2bdb:	movdqa xmm1,xmm3
    2bdf:	movq   rax,xmm0
    2be4:	add    rax,rax
    2be7:	je     0x2bfd
    2be9:	shr    rax,0x35
    2bed:	sub    eax,0x201
    2bf2:	cmp    eax,0x3fc
    2bf7:	ja     0x5285
    2bfd:	movdqa xmm14,xmm0
    2c02:	psrldq xmm14,0x8
    2c08:	movq   rax,xmm14
    2c0d:	add    rax,rax
    2c10:	je     0x2c26
    2c12:	shr    rax,0x35
    2c16:	sub    eax,0x201
    2c1b:	cmp    eax,0x3fc
    2c20:	ja     0x5285
    2c26:	movq   rax,xmm1
    2c2b:	add    rax,rax
    2c2e:	je     0x2c44
    2c30:	shr    rax,0x35
    2c34:	sub    eax,0x201
    2c39:	cmp    eax,0x3fc
    2c3e:	ja     0x5285
    2c44:	movdqa xmm14,xmm1
    2c49:	psrldq xmm14,0x8
    2c4f:	movq   rax,xmm14
    2c54:	add    rax,rax
    2c57:	je     0x2c6d
    2c59:	shr    rax,0x35
    2c5d:	sub    eax,0x201
    2c62:	cmp    eax,0x3fc
    2c67:	ja     0x5285
    2c6d:	addpd  xmm0,xmm1
    2c71:	movdqa xmm4,xmm0
    2c75:	movdqa xmm0,xmm4
    2c79:	movdqu XMMWORD PTR [r12+0x180],xmm0
    2c83:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    2c8d:	movdqa xmm2,xmm0
    2c91:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    2c9b:	movdqa xmm3,xmm0
    2c9f:	movdqa xmm0,xmm2
    2ca3:	movdqa xmm1,xmm3
    2ca7:	pshufd xmm1,xmm1,0x44
    2cac:	movq   rax,xmm0
    2cb1:	add    rax,rax
    2cb4:	je     0x2cca
    2cb6:	shr    rax,0x35
    2cba:	sub    eax,0x201
    2cbf:	cmp    eax,0x3fc
    2cc4:	ja     0x52a9
    2cca:	movdqa xmm14,xmm0
    2ccf:	psrldq xmm14,0x8
    2cd5:	movq   rax,xmm14
    2cda:	add    rax,rax
    2cdd:	je     0x2cf3
    2cdf:	shr    rax,0x35
    2ce3:	sub    eax,0x201
    2ce8:	cmp    eax,0x3fc
    2ced:	ja     0x52a9
    2cf3:	movq   rax,xmm1
    2cf8:	add    rax,rax
    2cfb:	je     0x2d11
    2cfd:	shr    rax,0x35
    2d01:	sub    eax,0x201
    2d06:	cmp    eax,0x3fc
    2d0b:	ja     0x52a9
    2d11:	movdqa xmm14,xmm1
    2d16:	psrldq xmm14,0x8
    2d1c:	movq   rax,xmm14
    2d21:	add    rax,rax
    2d24:	je     0x2d3a
    2d26:	shr    rax,0x35
    2d2a:	sub    eax,0x201
    2d2f:	cmp    eax,0x3fc
    2d34:	ja     0x52a9
    2d3a:	mulpd  xmm0,xmm1
    2d3e:	movdqa xmm4,xmm0
    2d42:	movdqa xmm0,xmm4
    2d46:	movdqu XMMWORD PTR [r12+0x210],xmm0
    2d50:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    2d5a:	movdqa xmm2,xmm0
    2d5e:	movdqa xmm0,xmm2
    2d62:	movdqa xmm1,xmm3
    2d66:	pshufd xmm1,xmm1,0x44
    2d6b:	movq   rax,xmm0
    2d70:	add    rax,rax
    2d73:	je     0x2d89
    2d75:	shr    rax,0x35
    2d79:	sub    eax,0x201
    2d7e:	cmp    eax,0x3fc
    2d83:	ja     0x52cd
    2d89:	movdqa xmm14,xmm0
    2d8e:	psrldq xmm14,0x8
    2d94:	movq   rax,xmm14
    2d99:	add    rax,rax
    2d9c:	je     0x2db2
    2d9e:	shr    rax,0x35
    2da2:	sub    eax,0x201
    2da7:	cmp    eax,0x3fc
    2dac:	ja     0x52cd
    2db2:	movq   rax,xmm1
    2db7:	add    rax,rax
    2dba:	je     0x2dd0
    2dbc:	shr    rax,0x35
    2dc0:	sub    eax,0x201
    2dc5:	cmp    eax,0x3fc
    2dca:	ja     0x52cd
    2dd0:	movdqa xmm14,xmm1
    2dd5:	psrldq xmm14,0x8
    2ddb:	movq   rax,xmm14
    2de0:	add    rax,rax
    2de3:	je     0x2df9
    2de5:	shr    rax,0x35
    2de9:	sub    eax,0x201
    2dee:	cmp    eax,0x3fc
    2df3:	ja     0x52cd
    2df9:	mulpd  xmm0,xmm1
    2dfd:	movdqa xmm4,xmm0
    2e01:	movdqa xmm0,xmm4
    2e05:	movdqu XMMWORD PTR [r12+0x230],xmm0
    2e0f:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    2e19:	movdqa xmm2,xmm0
    2e1d:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    2e27:	movdqa xmm4,xmm0
    2e2b:	movdqa xmm0,xmm2
    2e2f:	movdqa xmm1,xmm4
    2e33:	movq   rax,xmm0
    2e38:	add    rax,rax
    2e3b:	je     0x2e51
    2e3d:	shr    rax,0x35
    2e41:	sub    eax,0x201
    2e46:	cmp    eax,0x3fc
    2e4b:	ja     0x52f1
    2e51:	movdqa xmm14,xmm0
    2e56:	psrldq xmm14,0x8
    2e5c:	movq   rax,xmm14
    2e61:	add    rax,rax
    2e64:	je     0x2e7a
    2e66:	shr    rax,0x35
    2e6a:	sub    eax,0x201
    2e6f:	cmp    eax,0x3fc
    2e74:	ja     0x52f1
    2e7a:	movq   rax,xmm1
    2e7f:	add    rax,rax
    2e82:	je     0x2e98
    2e84:	shr    rax,0x35
    2e88:	sub    eax,0x201
    2e8d:	cmp    eax,0x3fc
    2e92:	ja     0x52f1
    2e98:	movdqa xmm14,xmm1
    2e9d:	psrldq xmm14,0x8
    2ea3:	movq   rax,xmm14
    2ea8:	add    rax,rax
    2eab:	je     0x2ec1
    2ead:	shr    rax,0x35
    2eb1:	sub    eax,0x201
    2eb6:	cmp    eax,0x3fc
    2ebb:	ja     0x52f1
    2ec1:	addpd  xmm0,xmm1
    2ec5:	movdqa xmm5,xmm0
    2ec9:	movdqa xmm0,xmm5
    2ecd:	movdqu XMMWORD PTR [r12+0x240],xmm0
    2ed7:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    2ee1:	movdqa xmm2,xmm0
    2ee5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    2eef:	movdqa xmm4,xmm0
    2ef3:	movdqa xmm0,xmm2
    2ef7:	movdqa xmm1,xmm4
    2efb:	movq   rax,xmm0
    2f00:	add    rax,rax
    2f03:	je     0x2f19
    2f05:	shr    rax,0x35
    2f09:	sub    eax,0x201
    2f0e:	cmp    eax,0x3fc
    2f13:	ja     0x5315
    2f19:	movdqa xmm14,xmm0
    2f1e:	psrldq xmm14,0x8
    2f24:	movq   rax,xmm14
    2f29:	add    rax,rax
    2f2c:	je     0x2f42
    2f2e:	shr    rax,0x35
    2f32:	sub    eax,0x201
    2f37:	cmp    eax,0x3fc
    2f3c:	ja     0x5315
    2f42:	movq   rax,xmm1
    2f47:	add    rax,rax
    2f4a:	je     0x2f60
    2f4c:	shr    rax,0x35
    2f50:	sub    eax,0x201
    2f55:	cmp    eax,0x3fc
    2f5a:	ja     0x5315
    2f60:	movdqa xmm14,xmm1
    2f65:	psrldq xmm14,0x8
    2f6b:	movq   rax,xmm14
    2f70:	add    rax,rax
    2f73:	je     0x2f89
    2f75:	shr    rax,0x35
    2f79:	sub    eax,0x201
    2f7e:	cmp    eax,0x3fc
    2f83:	ja     0x5315
    2f89:	addpd  xmm0,xmm1
    2f8d:	movdqa xmm5,xmm0
    2f91:	movdqa xmm0,xmm5
    2f95:	movdqu XMMWORD PTR [r12+0x220],xmm0
    2f9f:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    2fa9:	movdqa xmm2,xmm0
    2fad:	movdqa xmm0,xmm2
    2fb1:	movdqa xmm1,xmm3
    2fb5:	pshufd xmm1,xmm1,0x44
    2fba:	movq   rax,xmm0
    2fbf:	add    rax,rax
    2fc2:	je     0x2fd8
    2fc4:	shr    rax,0x35
    2fc8:	sub    eax,0x201
    2fcd:	cmp    eax,0x3fc
    2fd2:	ja     0x5339
    2fd8:	movdqa xmm14,xmm0
    2fdd:	psrldq xmm14,0x8
    2fe3:	movq   rax,xmm14
    2fe8:	add    rax,rax
    2feb:	je     0x3001
    2fed:	shr    rax,0x35
    2ff1:	sub    eax,0x201
    2ff6:	cmp    eax,0x3fc
    2ffb:	ja     0x5339
    3001:	movq   rax,xmm1
    3006:	add    rax,rax
    3009:	je     0x301f
    300b:	shr    rax,0x35
    300f:	sub    eax,0x201
    3014:	cmp    eax,0x3fc
    3019:	ja     0x5339
    301f:	movdqa xmm14,xmm1
    3024:	psrldq xmm14,0x8
    302a:	movq   rax,xmm14
    302f:	add    rax,rax
    3032:	je     0x3048
    3034:	shr    rax,0x35
    3038:	sub    eax,0x201
    303d:	cmp    eax,0x3fc
    3042:	ja     0x5339
    3048:	mulpd  xmm0,xmm1
    304c:	movdqa xmm4,xmm0
    3050:	movdqa xmm0,xmm4
    3054:	movdqu XMMWORD PTR [r12+0x250],xmm0
    305e:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    3068:	movdqa xmm2,xmm0
    306c:	movdqa xmm0,xmm2
    3070:	movdqa xmm1,xmm3
    3074:	pshufd xmm1,xmm1,0x44
    3079:	movq   rax,xmm0
    307e:	add    rax,rax
    3081:	je     0x3097
    3083:	shr    rax,0x35
    3087:	sub    eax,0x201
    308c:	cmp    eax,0x3fc
    3091:	ja     0x535d
    3097:	movdqa xmm14,xmm0
    309c:	psrldq xmm14,0x8
    30a2:	movq   rax,xmm14
    30a7:	add    rax,rax
    30aa:	je     0x30c0
    30ac:	shr    rax,0x35
    30b0:	sub    eax,0x201
    30b5:	cmp    eax,0x3fc
    30ba:	ja     0x535d
    30c0:	movq   rax,xmm1
    30c5:	add    rax,rax
    30c8:	je     0x30de
    30ca:	shr    rax,0x35
    30ce:	sub    eax,0x201
    30d3:	cmp    eax,0x3fc
    30d8:	ja     0x535d
    30de:	movdqa xmm14,xmm1
    30e3:	psrldq xmm14,0x8
    30e9:	movq   rax,xmm14
    30ee:	add    rax,rax
    30f1:	je     0x3107
    30f3:	shr    rax,0x35
    30f7:	sub    eax,0x201
    30fc:	cmp    eax,0x3fc
    3101:	ja     0x535d
    3107:	mulpd  xmm0,xmm1
    310b:	movdqa xmm4,xmm0
    310f:	movdqa xmm0,xmm4
    3113:	movdqu XMMWORD PTR [r12+0x150],xmm0
    311d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    3127:	movdqa xmm2,xmm0
    312b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    3135:	movdqa xmm3,xmm0
    3139:	movdqa xmm0,xmm2
    313d:	movdqa xmm1,xmm3
    3141:	movq   rax,xmm0
    3146:	add    rax,rax
    3149:	je     0x315f
    314b:	shr    rax,0x35
    314f:	sub    eax,0x201
    3154:	cmp    eax,0x3fc
    3159:	ja     0x5381
    315f:	movdqa xmm14,xmm0
    3164:	psrldq xmm14,0x8
    316a:	movq   rax,xmm14
    316f:	add    rax,rax
    3172:	je     0x3188
    3174:	shr    rax,0x35
    3178:	sub    eax,0x201
    317d:	cmp    eax,0x3fc
    3182:	ja     0x5381
    3188:	movq   rax,xmm1
    318d:	add    rax,rax
    3190:	je     0x31a6
    3192:	shr    rax,0x35
    3196:	sub    eax,0x201
    319b:	cmp    eax,0x3fc
    31a0:	ja     0x5381
    31a6:	movdqa xmm14,xmm1
    31ab:	psrldq xmm14,0x8
    31b1:	movq   rax,xmm14
    31b6:	add    rax,rax
    31b9:	je     0x31cf
    31bb:	shr    rax,0x35
    31bf:	sub    eax,0x201
    31c4:	cmp    eax,0x3fc
    31c9:	ja     0x5381
    31cf:	addpd  xmm0,xmm1
    31d3:	movdqa xmm4,xmm0
    31d7:	movdqa xmm0,xmm4
    31db:	movdqu XMMWORD PTR [r12+0x160],xmm0
    31e5:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    31ef:	movdqa xmm2,xmm0
    31f3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    31fd:	movdqa xmm3,xmm0
    3201:	movdqa xmm0,xmm2
    3205:	movdqa xmm1,xmm3
    3209:	movq   rax,xmm0
    320e:	add    rax,rax
    3211:	je     0x3227
    3213:	shr    rax,0x35
    3217:	sub    eax,0x201
    321c:	cmp    eax,0x3fc
    3221:	ja     0x53a5
    3227:	movdqa xmm14,xmm0
    322c:	psrldq xmm14,0x8
    3232:	movq   rax,xmm14
    3237:	add    rax,rax
    323a:	je     0x3250
    323c:	shr    rax,0x35
    3240:	sub    eax,0x201
    3245:	cmp    eax,0x3fc
    324a:	ja     0x53a5
    3250:	movq   rax,xmm1
    3255:	add    rax,rax
    3258:	je     0x326e
    325a:	shr    rax,0x35
    325e:	sub    eax,0x201
    3263:	cmp    eax,0x3fc
    3268:	ja     0x53a5
    326e:	movdqa xmm14,xmm1
    3273:	psrldq xmm14,0x8
    3279:	movq   rax,xmm14
    327e:	add    rax,rax
    3281:	je     0x3297
    3283:	shr    rax,0x35
    3287:	sub    eax,0x201
    328c:	cmp    eax,0x3fc
    3291:	ja     0x53a5
    3297:	addpd  xmm0,xmm1
    329b:	movdqa xmm4,xmm0
    329f:	movdqa xmm0,xmm4
    32a3:	movdqu XMMWORD PTR [r12+0x170],xmm0
    32ad:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    32b7:	movdqa xmm2,xmm0
    32bb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    32c5:	movdqa xmm3,xmm0
    32c9:	movdqa xmm0,xmm2
    32cd:	movdqa xmm1,xmm3
    32d1:	pshufd xmm1,xmm1,0x44
    32d6:	movq   rax,xmm0
    32db:	add    rax,rax
    32de:	je     0x32f4
    32e0:	shr    rax,0x35
    32e4:	sub    eax,0x201
    32e9:	cmp    eax,0x3fc
    32ee:	ja     0x53c9
    32f4:	movdqa xmm14,xmm0
    32f9:	psrldq xmm14,0x8
    32ff:	movq   rax,xmm14
    3304:	add    rax,rax
    3307:	je     0x331d
    3309:	shr    rax,0x35
    330d:	sub    eax,0x201
    3312:	cmp    eax,0x3fc
    3317:	ja     0x53c9
    331d:	movq   rax,xmm1
    3322:	add    rax,rax
    3325:	je     0x333b
    3327:	shr    rax,0x35
    332b:	sub    eax,0x201
    3330:	cmp    eax,0x3fc
    3335:	ja     0x53c9
    333b:	movdqa xmm14,xmm1
    3340:	psrldq xmm14,0x8
    3346:	movq   rax,xmm14
    334b:	add    rax,rax
    334e:	je     0x3364
    3350:	shr    rax,0x35
    3354:	sub    eax,0x201
    3359:	cmp    eax,0x3fc
    335e:	ja     0x53c9
    3364:	mulpd  xmm0,xmm1
    3368:	movdqa xmm4,xmm0
    336c:	movdqa xmm0,xmm4
    3370:	movdqu XMMWORD PTR [r12+0x180],xmm0
    337a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    3384:	movdqa xmm2,xmm0
    3388:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    3392:	movdqa xmm3,xmm0
    3396:	movdqa xmm0,xmm2
    339a:	movdqa xmm1,xmm3
    339e:	movq   rax,xmm0
    33a3:	add    rax,rax
    33a6:	je     0x33bc
    33a8:	shr    rax,0x35
    33ac:	sub    eax,0x201
    33b1:	cmp    eax,0x3fc
    33b6:	ja     0x53ed
    33bc:	movdqa xmm14,xmm0
    33c1:	psrldq xmm14,0x8
    33c7:	movq   rax,xmm14
    33cc:	add    rax,rax
    33cf:	je     0x33e5
    33d1:	shr    rax,0x35
    33d5:	sub    eax,0x201
    33da:	cmp    eax,0x3fc
    33df:	ja     0x53ed
    33e5:	movq   rax,xmm1
    33ea:	add    rax,rax
    33ed:	je     0x3403
    33ef:	shr    rax,0x35
    33f3:	sub    eax,0x201
    33f8:	cmp    eax,0x3fc
    33fd:	ja     0x53ed
    3403:	movdqa xmm14,xmm1
    3408:	psrldq xmm14,0x8
    340e:	movq   rax,xmm14
    3413:	add    rax,rax
    3416:	je     0x342c
    3418:	shr    rax,0x35
    341c:	sub    eax,0x201
    3421:	cmp    eax,0x3fc
    3426:	ja     0x53ed
    342c:	addpd  xmm0,xmm1
    3430:	movdqa xmm4,xmm0
    3434:	movdqa xmm0,xmm4
    3438:	movdqu XMMWORD PTR [r12+0x210],xmm0
    3442:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    344c:	movdqa xmm2,xmm0
    3450:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    345a:	movdqa xmm3,xmm0
    345e:	movdqa xmm0,xmm2
    3462:	movdqa xmm1,xmm3
    3466:	movq   rax,xmm0
    346b:	add    rax,rax
    346e:	je     0x3484
    3470:	shr    rax,0x35
    3474:	sub    eax,0x201
    3479:	cmp    eax,0x3fc
    347e:	ja     0x5411
    3484:	movdqa xmm14,xmm0
    3489:	psrldq xmm14,0x8
    348f:	movq   rax,xmm14
    3494:	add    rax,rax
    3497:	je     0x34ad
    3499:	shr    rax,0x35
    349d:	sub    eax,0x201
    34a2:	cmp    eax,0x3fc
    34a7:	ja     0x5411
    34ad:	movq   rax,xmm1
    34b2:	add    rax,rax
    34b5:	je     0x34cb
    34b7:	shr    rax,0x35
    34bb:	sub    eax,0x201
    34c0:	cmp    eax,0x3fc
    34c5:	ja     0x5411
    34cb:	movdqa xmm14,xmm1
    34d0:	psrldq xmm14,0x8
    34d6:	movq   rax,xmm14
    34db:	add    rax,rax
    34de:	je     0x34f4
    34e0:	shr    rax,0x35
    34e4:	sub    eax,0x201
    34e9:	cmp    eax,0x3fc
    34ee:	ja     0x5411
    34f4:	addpd  xmm0,xmm1
    34f8:	movdqa xmm4,xmm0
    34fc:	movdqa xmm0,xmm4
    3500:	movdqu XMMWORD PTR [r12+0x230],xmm0
    350a:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    3514:	movdqa xmm2,xmm0
    3518:	movdqa xmm1,xmm2
    351c:	por    xmm2,xmm1
    3520:	movdqa xmm0,xmm2
    3524:	movdqu XMMWORD PTR [r12+0x250],xmm0
    352e:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    3538:	movdqa xmm2,xmm0
    353c:	movdqa xmm1,xmm2
    3540:	por    xmm2,xmm1
    3544:	movdqa xmm0,xmm2
    3548:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    3552:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    355c:	movdqa xmm2,xmm0
    3560:	movdqa xmm1,xmm2
    3564:	por    xmm2,xmm1
    3568:	movdqa xmm0,xmm2
    356c:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    3576:	mov    r13,QWORD PTR [r12+0xf8]
    357e:	add    r13,0x40
    3582:	stmxcsr DWORD PTR [rsp+0x114]
    358a:	ldmxcsr DWORD PTR [rsp+0x110]
    3592:	mov    r11d,DWORD PTR [rsp+0x114]
    359a:	shr    r11d,1
    359d:	and    r11d,0x10
    35a1:	or     DWORD PTR [r12+0x314],r11d
    35a9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    35af:	movdqa xmm0,xmm2
    35b3:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    35bd:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    35c7:	movdqa xmm2,xmm0
    35cb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    35d5:	movdqa xmm3,xmm0
    35d9:	stmxcsr DWORD PTR [rsp+0x110]
    35e1:	mov    DWORD PTR [rsp+0x114],0x1f80
    35ec:	ldmxcsr DWORD PTR [rsp+0x114]
    35f4:	movdqa xmm0,xmm2
    35f8:	movdqa xmm1,xmm3
    35fc:	pshufd xmm1,xmm1,0x44
    3601:	movq   rax,xmm0
    3606:	add    rax,rax
    3609:	je     0x361f
    360b:	shr    rax,0x35
    360f:	sub    eax,0x201
    3614:	cmp    eax,0x3fc
    3619:	ja     0x5435
    361f:	movdqa xmm14,xmm0
    3624:	psrldq xmm14,0x8
    362a:	movq   rax,xmm14
    362f:	add    rax,rax
    3632:	je     0x3648
    3634:	shr    rax,0x35
    3638:	sub    eax,0x201
    363d:	cmp    eax,0x3fc
    3642:	ja     0x5435
    3648:	movq   rax,xmm1
    364d:	add    rax,rax
    3650:	je     0x3666
    3652:	shr    rax,0x35
    3656:	sub    eax,0x201
    365b:	cmp    eax,0x3fc
    3660:	ja     0x5435
    3666:	movdqa xmm14,xmm1
    366b:	psrldq xmm14,0x8
    3671:	movq   rax,xmm14
    3676:	add    rax,rax
    3679:	je     0x368f
    367b:	shr    rax,0x35
    367f:	sub    eax,0x201
    3684:	cmp    eax,0x3fc
    3689:	ja     0x5435
    368f:	mulpd  xmm0,xmm1
    3693:	movdqa xmm4,xmm0
    3697:	movdqa xmm0,xmm4
    369b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    36a5:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    36af:	movdqa xmm2,xmm0
    36b3:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    36bd:	movdqa xmm4,xmm0
    36c1:	movdqa xmm0,xmm2
    36c5:	movdqa xmm1,xmm4
    36c9:	movq   rax,xmm0
    36ce:	add    rax,rax
    36d1:	je     0x36e7
    36d3:	shr    rax,0x35
    36d7:	sub    eax,0x201
    36dc:	cmp    eax,0x3fc
    36e1:	ja     0x5459
    36e7:	movdqa xmm14,xmm0
    36ec:	psrldq xmm14,0x8
    36f2:	movq   rax,xmm14
    36f7:	add    rax,rax
    36fa:	je     0x3710
    36fc:	shr    rax,0x35
    3700:	sub    eax,0x201
    3705:	cmp    eax,0x3fc
    370a:	ja     0x5459
    3710:	movq   rax,xmm1
    3715:	add    rax,rax
    3718:	je     0x372e
    371a:	shr    rax,0x35
    371e:	sub    eax,0x201
    3723:	cmp    eax,0x3fc
    3728:	ja     0x5459
    372e:	movdqa xmm14,xmm1
    3733:	psrldq xmm14,0x8
    3739:	movq   rax,xmm14
    373e:	add    rax,rax
    3741:	je     0x3757
    3743:	shr    rax,0x35
    3747:	sub    eax,0x201
    374c:	cmp    eax,0x3fc
    3751:	ja     0x5459
    3757:	addpd  xmm0,xmm1
    375b:	movdqa xmm5,xmm0
    375f:	movdqa xmm0,xmm5
    3763:	movdqu XMMWORD PTR [r12+0x150],xmm0
    376d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    3777:	movdqa xmm2,xmm0
    377b:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    3785:	movdqa xmm4,xmm0
    3789:	movdqa xmm0,xmm2
    378d:	movdqa xmm1,xmm4
    3791:	movq   rax,xmm0
    3796:	add    rax,rax
    3799:	je     0x37af
    379b:	shr    rax,0x35
    379f:	sub    eax,0x201
    37a4:	cmp    eax,0x3fc
    37a9:	ja     0x547d
    37af:	movdqa xmm14,xmm0
    37b4:	psrldq xmm14,0x8
    37ba:	movq   rax,xmm14
    37bf:	add    rax,rax
    37c2:	je     0x37d8
    37c4:	shr    rax,0x35
    37c8:	sub    eax,0x201
    37cd:	cmp    eax,0x3fc
    37d2:	ja     0x547d
    37d8:	movq   rax,xmm1
    37dd:	add    rax,rax
    37e0:	je     0x37f6
    37e2:	shr    rax,0x35
    37e6:	sub    eax,0x201
    37eb:	cmp    eax,0x3fc
    37f0:	ja     0x547d
    37f6:	movdqa xmm14,xmm1
    37fb:	psrldq xmm14,0x8
    3801:	movq   rax,xmm14
    3806:	add    rax,rax
    3809:	je     0x381f
    380b:	shr    rax,0x35
    380f:	sub    eax,0x201
    3814:	cmp    eax,0x3fc
    3819:	ja     0x547d
    381f:	addpd  xmm0,xmm1
    3823:	movdqa xmm5,xmm0
    3827:	movdqa xmm0,xmm5
    382b:	movdqu XMMWORD PTR [r12+0x160],xmm0
    3835:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    383f:	movdqa xmm2,xmm0
    3843:	movdqa xmm0,xmm2
    3847:	movdqa xmm1,xmm3
    384b:	pshufd xmm1,xmm1,0x44
    3850:	movq   rax,xmm0
    3855:	add    rax,rax
    3858:	je     0x386e
    385a:	shr    rax,0x35
    385e:	sub    eax,0x201
    3863:	cmp    eax,0x3fc
    3868:	ja     0x54a1
    386e:	movdqa xmm14,xmm0
    3873:	psrldq xmm14,0x8
    3879:	movq   rax,xmm14
    387e:	add    rax,rax
    3881:	je     0x3897
    3883:	shr    rax,0x35
    3887:	sub    eax,0x201
    388c:	cmp    eax,0x3fc
    3891:	ja     0x54a1
    3897:	movq   rax,xmm1
    389c:	add    rax,rax
    389f:	je     0x38b5
    38a1:	shr    rax,0x35
    38a5:	sub    eax,0x201
    38aa:	cmp    eax,0x3fc
    38af:	ja     0x54a1
    38b5:	movdqa xmm14,xmm1
    38ba:	psrldq xmm14,0x8
    38c0:	movq   rax,xmm14
    38c5:	add    rax,rax
    38c8:	je     0x38de
    38ca:	shr    rax,0x35
    38ce:	sub    eax,0x201
    38d3:	cmp    eax,0x3fc
    38d8:	ja     0x54a1
    38de:	mulpd  xmm0,xmm1
    38e2:	movdqa xmm4,xmm0
    38e6:	movdqa xmm0,xmm4
    38ea:	movdqu XMMWORD PTR [r12+0x240],xmm0
    38f4:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    38fe:	movdqa xmm2,xmm0
    3902:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    390c:	movdqa xmm3,xmm0
    3910:	movdqa xmm0,xmm2
    3914:	movdqa xmm1,xmm3
    3918:	pshufd xmm1,xmm1,0x44
    391d:	movq   rax,xmm0
    3922:	add    rax,rax
    3925:	je     0x393b
    3927:	shr    rax,0x35
    392b:	sub    eax,0x201
    3930:	cmp    eax,0x3fc
    3935:	ja     0x54c5
    393b:	movdqa xmm14,xmm0
    3940:	psrldq xmm14,0x8
    3946:	movq   rax,xmm14
    394b:	add    rax,rax
    394e:	je     0x3964
    3950:	shr    rax,0x35
    3954:	sub    eax,0x201
    3959:	cmp    eax,0x3fc
    395e:	ja     0x54c5
    3964:	movq   rax,xmm1
    3969:	add    rax,rax
    396c:	je     0x3982
    396e:	shr    rax,0x35
    3972:	sub    eax,0x201
    3977:	cmp    eax,0x3fc
    397c:	ja     0x54c5
    3982:	movdqa xmm14,xmm1
    3987:	psrldq xmm14,0x8
    398d:	movq   rax,xmm14
    3992:	add    rax,rax
    3995:	je     0x39ab
    3997:	shr    rax,0x35
    399b:	sub    eax,0x201
    39a0:	cmp    eax,0x3fc
    39a5:	ja     0x54c5
    39ab:	mulpd  xmm0,xmm1
    39af:	movdqa xmm4,xmm0
    39b3:	movdqa xmm0,xmm4
    39b7:	movdqu XMMWORD PTR [r12+0x140],xmm0
    39c1:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    39cb:	movdqa xmm2,xmm0
    39cf:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    39d9:	movdqa xmm3,xmm0
    39dd:	movdqa xmm0,xmm2
    39e1:	movdqa xmm1,xmm3
    39e5:	pshufd xmm1,xmm1,0x44
    39ea:	movq   rax,xmm0
    39ef:	add    rax,rax
    39f2:	je     0x3a08
    39f4:	shr    rax,0x35
    39f8:	sub    eax,0x201
    39fd:	cmp    eax,0x3fc
    3a02:	ja     0x54e9
    3a08:	movdqa xmm14,xmm0
    3a0d:	psrldq xmm14,0x8
    3a13:	movq   rax,xmm14
    3a18:	add    rax,rax
    3a1b:	je     0x3a31
    3a1d:	shr    rax,0x35
    3a21:	sub    eax,0x201
    3a26:	cmp    eax,0x3fc
    3a2b:	ja     0x54e9
    3a31:	movq   rax,xmm1
    3a36:	add    rax,rax
    3a39:	je     0x3a4f
    3a3b:	shr    rax,0x35
    3a3f:	sub    eax,0x201
    3a44:	cmp    eax,0x3fc
    3a49:	ja     0x54e9
    3a4f:	movdqa xmm14,xmm1
    3a54:	psrldq xmm14,0x8
    3a5a:	movq   rax,xmm14
    3a5f:	add    rax,rax
    3a62:	je     0x3a78
    3a64:	shr    rax,0x35
    3a68:	sub    eax,0x201
    3a6d:	cmp    eax,0x3fc
    3a72:	ja     0x54e9
    3a78:	mulpd  xmm0,xmm1
    3a7c:	movdqa xmm4,xmm0
    3a80:	movdqa xmm0,xmm4
    3a84:	movdqu XMMWORD PTR [r12+0x170],xmm0
    3a8e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    3a98:	movdqa xmm2,xmm0
    3a9c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    3aa6:	movdqa xmm4,xmm0
    3aaa:	movdqa xmm0,xmm2
    3aae:	movdqa xmm1,xmm4
    3ab2:	movq   rax,xmm0
    3ab7:	add    rax,rax
    3aba:	je     0x3ad0
    3abc:	shr    rax,0x35
    3ac0:	sub    eax,0x201
    3ac5:	cmp    eax,0x3fc
    3aca:	ja     0x550d
    3ad0:	movdqa xmm14,xmm0
    3ad5:	psrldq xmm14,0x8
    3adb:	movq   rax,xmm14
    3ae0:	add    rax,rax
    3ae3:	je     0x3af9
    3ae5:	shr    rax,0x35
    3ae9:	sub    eax,0x201
    3aee:	cmp    eax,0x3fc
    3af3:	ja     0x550d
    3af9:	movq   rax,xmm1
    3afe:	add    rax,rax
    3b01:	je     0x3b17
    3b03:	shr    rax,0x35
    3b07:	sub    eax,0x201
    3b0c:	cmp    eax,0x3fc
    3b11:	ja     0x550d
    3b17:	movdqa xmm14,xmm1
    3b1c:	psrldq xmm14,0x8
    3b22:	movq   rax,xmm14
    3b27:	add    rax,rax
    3b2a:	je     0x3b40
    3b2c:	shr    rax,0x35
    3b30:	sub    eax,0x201
    3b35:	cmp    eax,0x3fc
    3b3a:	ja     0x550d
    3b40:	addpd  xmm0,xmm1
    3b44:	movdqa xmm5,xmm0
    3b48:	movdqa xmm0,xmm5
    3b4c:	movdqu XMMWORD PTR [r12+0x180],xmm0
    3b56:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    3b60:	movdqa xmm2,xmm0
    3b64:	movdqa xmm0,xmm2
    3b68:	movdqa xmm1,xmm3
    3b6c:	pshufd xmm1,xmm1,0x44
    3b71:	movq   rax,xmm0
    3b76:	add    rax,rax
    3b79:	je     0x3b8f
    3b7b:	shr    rax,0x35
    3b7f:	sub    eax,0x201
    3b84:	cmp    eax,0x3fc
    3b89:	ja     0x5531
    3b8f:	movdqa xmm14,xmm0
    3b94:	psrldq xmm14,0x8
    3b9a:	movq   rax,xmm14
    3b9f:	add    rax,rax
    3ba2:	je     0x3bb8
    3ba4:	shr    rax,0x35
    3ba8:	sub    eax,0x201
    3bad:	cmp    eax,0x3fc
    3bb2:	ja     0x5531
    3bb8:	movq   rax,xmm1
    3bbd:	add    rax,rax
    3bc0:	je     0x3bd6
    3bc2:	shr    rax,0x35
    3bc6:	sub    eax,0x201
    3bcb:	cmp    eax,0x3fc
    3bd0:	ja     0x5531
    3bd6:	movdqa xmm14,xmm1
    3bdb:	psrldq xmm14,0x8
    3be1:	movq   rax,xmm14
    3be6:	add    rax,rax
    3be9:	je     0x3bff
    3beb:	shr    rax,0x35
    3bef:	sub    eax,0x201
    3bf4:	cmp    eax,0x3fc
    3bf9:	ja     0x5531
    3bff:	mulpd  xmm0,xmm1
    3c03:	movdqa xmm4,xmm0
    3c07:	movdqa xmm0,xmm4
    3c0b:	movdqu XMMWORD PTR [r12+0x210],xmm0
    3c15:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    3c1f:	movdqa xmm2,xmm0
    3c23:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    3c2d:	movdqa xmm4,xmm0
    3c31:	movdqa xmm0,xmm2
    3c35:	movdqa xmm1,xmm4
    3c39:	movq   rax,xmm0
    3c3e:	add    rax,rax
    3c41:	je     0x3c57
    3c43:	shr    rax,0x35
    3c47:	sub    eax,0x201
    3c4c:	cmp    eax,0x3fc
    3c51:	ja     0x5555
    3c57:	movdqa xmm14,xmm0
    3c5c:	psrldq xmm14,0x8
    3c62:	movq   rax,xmm14
    3c67:	add    rax,rax
    3c6a:	je     0x3c80
    3c6c:	shr    rax,0x35
    3c70:	sub    eax,0x201
    3c75:	cmp    eax,0x3fc
    3c7a:	ja     0x5555
    3c80:	movq   rax,xmm1
    3c85:	add    rax,rax
    3c88:	je     0x3c9e
    3c8a:	shr    rax,0x35
    3c8e:	sub    eax,0x201
    3c93:	cmp    eax,0x3fc
    3c98:	ja     0x5555
    3c9e:	movdqa xmm14,xmm1
    3ca3:	psrldq xmm14,0x8
    3ca9:	movq   rax,xmm14
    3cae:	add    rax,rax
    3cb1:	je     0x3cc7
    3cb3:	shr    rax,0x35
    3cb7:	sub    eax,0x201
    3cbc:	cmp    eax,0x3fc
    3cc1:	ja     0x5555
    3cc7:	addpd  xmm0,xmm1
    3ccb:	movdqa xmm5,xmm0
    3ccf:	movdqa xmm0,xmm5
    3cd3:	movdqu XMMWORD PTR [r12+0x220],xmm0
    3cdd:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    3ce7:	movdqa xmm2,xmm0
    3ceb:	movdqa xmm0,xmm2
    3cef:	movdqa xmm1,xmm3
    3cf3:	pshufd xmm1,xmm1,0x44
    3cf8:	movq   rax,xmm0
    3cfd:	add    rax,rax
    3d00:	je     0x3d16
    3d02:	shr    rax,0x35
    3d06:	sub    eax,0x201
    3d0b:	cmp    eax,0x3fc
    3d10:	ja     0x5579
    3d16:	movdqa xmm14,xmm0
    3d1b:	psrldq xmm14,0x8
    3d21:	movq   rax,xmm14
    3d26:	add    rax,rax
    3d29:	je     0x3d3f
    3d2b:	shr    rax,0x35
    3d2f:	sub    eax,0x201
    3d34:	cmp    eax,0x3fc
    3d39:	ja     0x5579
    3d3f:	movq   rax,xmm1
    3d44:	add    rax,rax
    3d47:	je     0x3d5d
    3d49:	shr    rax,0x35
    3d4d:	sub    eax,0x201
    3d52:	cmp    eax,0x3fc
    3d57:	ja     0x5579
    3d5d:	movdqa xmm14,xmm1
    3d62:	psrldq xmm14,0x8
    3d68:	movq   rax,xmm14
    3d6d:	add    rax,rax
    3d70:	je     0x3d86
    3d72:	shr    rax,0x35
    3d76:	sub    eax,0x201
    3d7b:	cmp    eax,0x3fc
    3d80:	ja     0x5579
    3d86:	mulpd  xmm0,xmm1
    3d8a:	movdqa xmm4,xmm0
    3d8e:	movdqa xmm0,xmm4
    3d92:	movdqu XMMWORD PTR [r12+0x230],xmm0
    3d9c:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    3da6:	movdqa xmm2,xmm0
    3daa:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    3db4:	movdqa xmm3,xmm0
    3db8:	movdqa xmm0,xmm2
    3dbc:	movdqa xmm1,xmm3
    3dc0:	movq   rax,xmm0
    3dc5:	add    rax,rax
    3dc8:	je     0x3dde
    3dca:	shr    rax,0x35
    3dce:	sub    eax,0x201
    3dd3:	cmp    eax,0x3fc
    3dd8:	ja     0x559d
    3dde:	movdqa xmm14,xmm0
    3de3:	psrldq xmm14,0x8
    3de9:	movq   rax,xmm14
    3dee:	add    rax,rax
    3df1:	je     0x3e07
    3df3:	shr    rax,0x35
    3df7:	sub    eax,0x201
    3dfc:	cmp    eax,0x3fc
    3e01:	ja     0x559d
    3e07:	movq   rax,xmm1
    3e0c:	add    rax,rax
    3e0f:	je     0x3e25
    3e11:	shr    rax,0x35
    3e15:	sub    eax,0x201
    3e1a:	cmp    eax,0x3fc
    3e1f:	ja     0x559d
    3e25:	movdqa xmm14,xmm1
    3e2a:	psrldq xmm14,0x8
    3e30:	movq   rax,xmm14
    3e35:	add    rax,rax
    3e38:	je     0x3e4e
    3e3a:	shr    rax,0x35
    3e3e:	sub    eax,0x201
    3e43:	cmp    eax,0x3fc
    3e48:	ja     0x559d
    3e4e:	addpd  xmm0,xmm1
    3e52:	movdqa xmm4,xmm0
    3e56:	movdqa xmm0,xmm4
    3e5a:	movdqu XMMWORD PTR [r12+0x140],xmm0
    3e64:	movdqu xmm0,XMMWORD PTR [r12+0x1e0]
    3e6e:	movdqa xmm2,xmm0
    3e72:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    3e7c:	movdqa xmm3,xmm0
    3e80:	movdqa xmm0,xmm2
    3e84:	movdqa xmm1,xmm3
    3e88:	pshufd xmm1,xmm1,0x44
    3e8d:	movq   rax,xmm0
    3e92:	add    rax,rax
    3e95:	je     0x3eab
    3e97:	shr    rax,0x35
    3e9b:	sub    eax,0x201
    3ea0:	cmp    eax,0x3fc
    3ea5:	ja     0x55c1
    3eab:	movdqa xmm14,xmm0
    3eb0:	psrldq xmm14,0x8
    3eb6:	movq   rax,xmm14
    3ebb:	add    rax,rax
    3ebe:	je     0x3ed4
    3ec0:	shr    rax,0x35
    3ec4:	sub    eax,0x201
    3ec9:	cmp    eax,0x3fc
    3ece:	ja     0x55c1
    3ed4:	movq   rax,xmm1
    3ed9:	add    rax,rax
    3edc:	je     0x3ef2
    3ede:	shr    rax,0x35
    3ee2:	sub    eax,0x201
    3ee7:	cmp    eax,0x3fc
    3eec:	ja     0x55c1
    3ef2:	movdqa xmm14,xmm1
    3ef7:	psrldq xmm14,0x8
    3efd:	movq   rax,xmm14
    3f02:	add    rax,rax
    3f05:	je     0x3f1b
    3f07:	shr    rax,0x35
    3f0b:	sub    eax,0x201
    3f10:	cmp    eax,0x3fc
    3f15:	ja     0x55c1
    3f1b:	mulpd  xmm0,xmm1
    3f1f:	movdqa xmm4,xmm0
    3f23:	movdqa xmm0,xmm4
    3f27:	movdqu XMMWORD PTR [r12+0x130],xmm0
    3f31:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    3f3b:	movdqa xmm2,xmm0
    3f3f:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    3f49:	movdqa xmm3,xmm0
    3f4d:	movdqa xmm0,xmm2
    3f51:	movdqa xmm1,xmm3
    3f55:	movq   rax,xmm0
    3f5a:	add    rax,rax
    3f5d:	je     0x3f73
    3f5f:	shr    rax,0x35
    3f63:	sub    eax,0x201
    3f68:	cmp    eax,0x3fc
    3f6d:	ja     0x55e5
    3f73:	movdqa xmm14,xmm0
    3f78:	psrldq xmm14,0x8
    3f7e:	movq   rax,xmm14
    3f83:	add    rax,rax
    3f86:	je     0x3f9c
    3f88:	shr    rax,0x35
    3f8c:	sub    eax,0x201
    3f91:	cmp    eax,0x3fc
    3f96:	ja     0x55e5
    3f9c:	movq   rax,xmm1
    3fa1:	add    rax,rax
    3fa4:	je     0x3fba
    3fa6:	shr    rax,0x35
    3faa:	sub    eax,0x201
    3faf:	cmp    eax,0x3fc
    3fb4:	ja     0x55e5
    3fba:	movdqa xmm14,xmm1
    3fbf:	psrldq xmm14,0x8
    3fc5:	movq   rax,xmm14
    3fca:	add    rax,rax
    3fcd:	je     0x3fe3
    3fcf:	shr    rax,0x35
    3fd3:	sub    eax,0x201
    3fd8:	cmp    eax,0x3fc
    3fdd:	ja     0x55e5
    3fe3:	addpd  xmm0,xmm1
    3fe7:	movdqa xmm4,xmm0
    3feb:	movdqa xmm0,xmm4
    3fef:	movdqu XMMWORD PTR [r12+0x150],xmm0
    3ff9:	mov    r13,QWORD PTR [r12+0xf8]
    4001:	mov    r14,r13
    4004:	add    r14,0x70
    4008:	stmxcsr DWORD PTR [rsp+0x114]
    4010:	ldmxcsr DWORD PTR [rsp+0x110]
    4018:	mov    r11d,DWORD PTR [rsp+0x114]
    4020:	shr    r11d,1
    4023:	and    r11d,0x10
    4027:	or     DWORD PTR [r12+0x314],r11d
    402f:	movdqu xmm2,XMMWORD PTR [r14]
    4034:	movdqa xmm0,xmm2
    4038:	movdqu XMMWORD PTR [r12+0x240],xmm0
    4042:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    404c:	movdqa xmm3,xmm0
    4050:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    405a:	movdqa xmm4,xmm0
    405e:	stmxcsr DWORD PTR [rsp+0x110]
    4066:	mov    DWORD PTR [rsp+0x114],0x1f80
    4071:	ldmxcsr DWORD PTR [rsp+0x114]
    4079:	movdqa xmm0,xmm3
    407d:	movdqa xmm1,xmm4
    4081:	movq   rax,xmm0
    4086:	add    rax,rax
    4089:	je     0x409f
    408b:	shr    rax,0x35
    408f:	sub    eax,0x201
    4094:	cmp    eax,0x3fc
    4099:	ja     0x5609
    409f:	movdqa xmm14,xmm0
    40a4:	psrldq xmm14,0x8
    40aa:	movq   rax,xmm14
    40af:	add    rax,rax
    40b2:	je     0x40c8
    40b4:	shr    rax,0x35
    40b8:	sub    eax,0x201
    40bd:	cmp    eax,0x3fc
    40c2:	ja     0x5609
    40c8:	movq   rax,xmm1
    40cd:	add    rax,rax
    40d0:	je     0x40e6
    40d2:	shr    rax,0x35
    40d6:	sub    eax,0x201
    40db:	cmp    eax,0x3fc
    40e0:	ja     0x5609
    40e6:	movdqa xmm14,xmm1
    40eb:	psrldq xmm14,0x8
    40f1:	movq   rax,xmm14
    40f6:	add    rax,rax
    40f9:	je     0x410f
    40fb:	shr    rax,0x35
    40ff:	sub    eax,0x201
    4104:	cmp    eax,0x3fc
    4109:	ja     0x5609
    410f:	addpd  xmm0,xmm1
    4113:	movdqa xmm5,xmm0
    4117:	movdqa xmm0,xmm5
    411b:	movdqu XMMWORD PTR [r12+0x170],xmm0
    4125:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    412f:	movdqa xmm3,xmm0
    4133:	movdqa xmm0,xmm2
    4137:	movdqa xmm1,xmm3
    413b:	pshufd xmm1,xmm1,0x44
    4140:	movq   rax,xmm0
    4145:	add    rax,rax
    4148:	je     0x415e
    414a:	shr    rax,0x35
    414e:	sub    eax,0x201
    4153:	cmp    eax,0x3fc
    4158:	ja     0x562d
    415e:	movdqa xmm14,xmm0
    4163:	psrldq xmm14,0x8
    4169:	movq   rax,xmm14
    416e:	add    rax,rax
    4171:	je     0x4187
    4173:	shr    rax,0x35
    4177:	sub    eax,0x201
    417c:	cmp    eax,0x3fc
    4181:	ja     0x562d
    4187:	movq   rax,xmm1
    418c:	add    rax,rax
    418f:	je     0x41a5
    4191:	shr    rax,0x35
    4195:	sub    eax,0x201
    419a:	cmp    eax,0x3fc
    419f:	ja     0x562d
    41a5:	movdqa xmm14,xmm1
    41aa:	psrldq xmm14,0x8
    41b0:	movq   rax,xmm14
    41b5:	add    rax,rax
    41b8:	je     0x41ce
    41ba:	shr    rax,0x35
    41be:	sub    eax,0x201
    41c3:	cmp    eax,0x3fc
    41c8:	ja     0x562d
    41ce:	mulpd  xmm0,xmm1
    41d2:	movdqa xmm4,xmm0
    41d6:	movdqa xmm0,xmm4
    41da:	movdqu XMMWORD PTR [r12+0x160],xmm0
    41e4:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    41ee:	movdqa xmm2,xmm0
    41f2:	movdqa xmm0,xmm2
    41f6:	movdqa xmm1,xmm3
    41fa:	pshufd xmm1,xmm1,0x44
    41ff:	movq   rax,xmm0
    4204:	add    rax,rax
    4207:	je     0x421d
    4209:	shr    rax,0x35
    420d:	sub    eax,0x201
    4212:	cmp    eax,0x3fc
    4217:	ja     0x5651
    421d:	movdqa xmm14,xmm0
    4222:	psrldq xmm14,0x8
    4228:	movq   rax,xmm14
    422d:	add    rax,rax
    4230:	je     0x4246
    4232:	shr    rax,0x35
    4236:	sub    eax,0x201
    423b:	cmp    eax,0x3fc
    4240:	ja     0x5651
    4246:	movq   rax,xmm1
    424b:	add    rax,rax
    424e:	je     0x4264
    4250:	shr    rax,0x35
    4254:	sub    eax,0x201
    4259:	cmp    eax,0x3fc
    425e:	ja     0x5651
    4264:	movdqa xmm14,xmm1
    4269:	psrldq xmm14,0x8
    426f:	movq   rax,xmm14
    4274:	add    rax,rax
    4277:	je     0x428d
    4279:	shr    rax,0x35
    427d:	sub    eax,0x201
    4282:	cmp    eax,0x3fc
    4287:	ja     0x5651
    428d:	mulpd  xmm0,xmm1
    4291:	movdqa xmm4,xmm0
    4295:	movdqa xmm0,xmm4
    4299:	movdqu XMMWORD PTR [r12+0x180],xmm0
    42a3:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    42ad:	movdqa xmm2,xmm0
    42b1:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    42bb:	movdqa xmm4,xmm0
    42bf:	movdqa xmm0,xmm2
    42c3:	movdqa xmm1,xmm4
    42c7:	movq   rax,xmm0
    42cc:	add    rax,rax
    42cf:	je     0x42e5
    42d1:	shr    rax,0x35
    42d5:	sub    eax,0x201
    42da:	cmp    eax,0x3fc
    42df:	ja     0x5675
    42e5:	movdqa xmm14,xmm0
    42ea:	psrldq xmm14,0x8
    42f0:	movq   rax,xmm14
    42f5:	add    rax,rax
    42f8:	je     0x430e
    42fa:	shr    rax,0x35
    42fe:	sub    eax,0x201
    4303:	cmp    eax,0x3fc
    4308:	ja     0x5675
    430e:	movq   rax,xmm1
    4313:	add    rax,rax
    4316:	je     0x432c
    4318:	shr    rax,0x35
    431c:	sub    eax,0x201
    4321:	cmp    eax,0x3fc
    4326:	ja     0x5675
    432c:	movdqa xmm14,xmm1
    4331:	psrldq xmm14,0x8
    4337:	movq   rax,xmm14
    433c:	add    rax,rax
    433f:	je     0x4355
    4341:	shr    rax,0x35
    4345:	sub    eax,0x201
    434a:	cmp    eax,0x3fc
    434f:	ja     0x5675
    4355:	addpd  xmm0,xmm1
    4359:	movdqa xmm5,xmm0
    435d:	movdqa xmm0,xmm5
    4361:	movdqu XMMWORD PTR [r12+0x210],xmm0
    436b:	mov    r14,r13
    436e:	add    r14,0x10
    4372:	stmxcsr DWORD PTR [rsp+0x114]
    437a:	ldmxcsr DWORD PTR [rsp+0x110]
    4382:	mov    r11d,DWORD PTR [rsp+0x114]
    438a:	shr    r11d,1
    438d:	and    r11d,0x10
    4391:	or     DWORD PTR [r12+0x314],r11d
    4399:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    439f:	movdqu xmm4,XMMWORD PTR [r14]
    43a4:	movdqa xmm0,xmm4
    43a8:	movdqu XMMWORD PTR [r12+0x230],xmm0
    43b2:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    43bc:	movdqa xmm5,xmm0
    43c0:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    43ca:	movdqa xmm6,xmm0
    43ce:	stmxcsr DWORD PTR [rsp+0x110]
    43d6:	mov    DWORD PTR [rsp+0x114],0x1f80
    43e1:	ldmxcsr DWORD PTR [rsp+0x114]
    43e9:	movdqa xmm0,xmm5
    43ed:	movdqa xmm1,xmm6
    43f1:	movq   rax,xmm0
    43f6:	add    rax,rax
    43f9:	je     0x440f
    43fb:	shr    rax,0x35
    43ff:	sub    eax,0x201
    4404:	cmp    eax,0x3fc
    4409:	ja     0x5699
    440f:	movdqa xmm14,xmm0
    4414:	psrldq xmm14,0x8
    441a:	movq   rax,xmm14
    441f:	add    rax,rax
    4422:	je     0x4438
    4424:	shr    rax,0x35
    4428:	sub    eax,0x201
    442d:	cmp    eax,0x3fc
    4432:	ja     0x5699
    4438:	movq   rax,xmm1
    443d:	add    rax,rax
    4440:	je     0x4456
    4442:	shr    rax,0x35
    4446:	sub    eax,0x201
    444b:	cmp    eax,0x3fc
    4450:	ja     0x5699
    4456:	movdqa xmm14,xmm1
    445b:	psrldq xmm14,0x8
    4461:	movq   rax,xmm14
    4466:	add    rax,rax
    4469:	je     0x447f
    446b:	shr    rax,0x35
    446f:	sub    eax,0x201
    4474:	cmp    eax,0x3fc
    4479:	ja     0x5699
    447f:	addpd  xmm0,xmm1
    4483:	movdqa xmm7,xmm0
    4487:	movdqa xmm0,xmm7
    448b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    4495:	movdqa xmm0,xmm4
    4499:	movdqa xmm1,xmm3
    449d:	pshufd xmm1,xmm1,0x44
    44a2:	movq   rax,xmm0
    44a7:	add    rax,rax
    44aa:	je     0x44c0
    44ac:	shr    rax,0x35
    44b0:	sub    eax,0x201
    44b5:	cmp    eax,0x3fc
    44ba:	ja     0x56bd
    44c0:	movdqa xmm14,xmm0
    44c5:	psrldq xmm14,0x8
    44cb:	movq   rax,xmm14
    44d0:	add    rax,rax
    44d3:	je     0x44e9
    44d5:	shr    rax,0x35
    44d9:	sub    eax,0x201
    44de:	cmp    eax,0x3fc
    44e3:	ja     0x56bd
    44e9:	movq   rax,xmm1
    44ee:	add    rax,rax
    44f1:	je     0x4507
    44f3:	shr    rax,0x35
    44f7:	sub    eax,0x201
    44fc:	cmp    eax,0x3fc
    4501:	ja     0x56bd
    4507:	movdqa xmm14,xmm1
    450c:	psrldq xmm14,0x8
    4512:	movq   rax,xmm14
    4517:	add    rax,rax
    451a:	je     0x4530
    451c:	shr    rax,0x35
    4520:	sub    eax,0x201
    4525:	cmp    eax,0x3fc
    452a:	ja     0x56bd
    4530:	mulpd  xmm0,xmm1
    4534:	movdqa xmm5,xmm0
    4538:	movdqa xmm0,xmm5
    453c:	movdqu XMMWORD PTR [r12+0x220],xmm0
    4546:	movdqa xmm0,xmm2
    454a:	movdqa xmm1,xmm3
    454e:	pshufd xmm1,xmm1,0x44
    4553:	movq   rax,xmm0
    4558:	add    rax,rax
    455b:	je     0x4571
    455d:	shr    rax,0x35
    4561:	sub    eax,0x201
    4566:	cmp    eax,0x3fc
    456b:	ja     0x56e1
    4571:	movdqa xmm14,xmm0
    4576:	psrldq xmm14,0x8
    457c:	movq   rax,xmm14
    4581:	add    rax,rax
    4584:	je     0x459a
    4586:	shr    rax,0x35
    458a:	sub    eax,0x201
    458f:	cmp    eax,0x3fc
    4594:	ja     0x56e1
    459a:	movq   rax,xmm1
    459f:	add    rax,rax
    45a2:	je     0x45b8
    45a4:	shr    rax,0x35
    45a8:	sub    eax,0x201
    45ad:	cmp    eax,0x3fc
    45b2:	ja     0x56e1
    45b8:	movdqa xmm14,xmm1
    45bd:	psrldq xmm14,0x8
    45c3:	movq   rax,xmm14
    45c8:	add    rax,rax
    45cb:	je     0x45e1
    45cd:	shr    rax,0x35
    45d1:	sub    eax,0x201
    45d6:	cmp    eax,0x3fc
    45db:	ja     0x56e1
    45e1:	mulpd  xmm0,xmm1
    45e5:	movdqa xmm4,xmm0
    45e9:	movdqa xmm0,xmm4
    45ed:	movdqu XMMWORD PTR [r12+0x120],xmm0
    45f7:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    4601:	movdqa xmm2,xmm0
    4605:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    460f:	movdqa xmm3,xmm0
    4613:	movdqa xmm0,xmm2
    4617:	movdqa xmm1,xmm3
    461b:	movq   rax,xmm0
    4620:	add    rax,rax
    4623:	je     0x4639
    4625:	shr    rax,0x35
    4629:	sub    eax,0x201
    462e:	cmp    eax,0x3fc
    4633:	ja     0x5705
    4639:	movdqa xmm14,xmm0
    463e:	psrldq xmm14,0x8
    4644:	movq   rax,xmm14
    4649:	add    rax,rax
    464c:	je     0x4662
    464e:	shr    rax,0x35
    4652:	sub    eax,0x201
    4657:	cmp    eax,0x3fc
    465c:	ja     0x5705
    4662:	movq   rax,xmm1
    4667:	add    rax,rax
    466a:	je     0x4680
    466c:	shr    rax,0x35
    4670:	sub    eax,0x201
    4675:	cmp    eax,0x3fc
    467a:	ja     0x5705
    4680:	movdqa xmm14,xmm1
    4685:	psrldq xmm14,0x8
    468b:	movq   rax,xmm14
    4690:	add    rax,rax
    4693:	je     0x46a9
    4695:	shr    rax,0x35
    4699:	sub    eax,0x201
    469e:	cmp    eax,0x3fc
    46a3:	ja     0x5705
    46a9:	addpd  xmm0,xmm1
    46ad:	movdqa xmm4,xmm0
    46b1:	movdqa xmm0,xmm4
    46b5:	movdqu XMMWORD PTR [r12+0x140],xmm0
    46bf:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    46c9:	movdqa xmm2,xmm0
    46cd:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    46d7:	movdqa xmm3,xmm0
    46db:	movdqa xmm0,xmm2
    46df:	movdqa xmm1,xmm3
    46e3:	movq   rax,xmm0
    46e8:	add    rax,rax
    46eb:	je     0x4701
    46ed:	shr    rax,0x35
    46f1:	sub    eax,0x201
    46f6:	cmp    eax,0x3fc
    46fb:	ja     0x5729
    4701:	movdqa xmm14,xmm0
    4706:	psrldq xmm14,0x8
    470c:	movq   rax,xmm14
    4711:	add    rax,rax
    4714:	je     0x472a
    4716:	shr    rax,0x35
    471a:	sub    eax,0x201
    471f:	cmp    eax,0x3fc
    4724:	ja     0x5729
    472a:	movq   rax,xmm1
    472f:	add    rax,rax
    4732:	je     0x4748
    4734:	shr    rax,0x35
    4738:	sub    eax,0x201
    473d:	cmp    eax,0x3fc
    4742:	ja     0x5729
    4748:	movdqa xmm14,xmm1
    474d:	psrldq xmm14,0x8
    4753:	movq   rax,xmm14
    4758:	add    rax,rax
    475b:	je     0x4771
    475d:	shr    rax,0x35
    4761:	sub    eax,0x201
    4766:	cmp    eax,0x3fc
    476b:	ja     0x5729
    4771:	addpd  xmm0,xmm1
    4775:	movdqa xmm4,xmm0
    4779:	movdqa xmm0,xmm4
    477d:	movdqu XMMWORD PTR [r12+0x150],xmm0
    4787:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    4791:	movdqa xmm2,xmm0
    4795:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    479f:	movdqa xmm3,xmm0
    47a3:	movdqa xmm0,xmm2
    47a7:	movdqa xmm1,xmm3
    47ab:	movq   rax,xmm0
    47b0:	add    rax,rax
    47b3:	je     0x47c9
    47b5:	shr    rax,0x35
    47b9:	sub    eax,0x201
    47be:	cmp    eax,0x3fc
    47c3:	ja     0x574d
    47c9:	movdqa xmm14,xmm0
    47ce:	psrldq xmm14,0x8
    47d4:	movq   rax,xmm14
    47d9:	add    rax,rax
    47dc:	je     0x47f2
    47de:	shr    rax,0x35
    47e2:	sub    eax,0x201
    47e7:	cmp    eax,0x3fc
    47ec:	ja     0x574d
    47f2:	movq   rax,xmm1
    47f7:	add    rax,rax
    47fa:	je     0x4810
    47fc:	shr    rax,0x35
    4800:	sub    eax,0x201
    4805:	cmp    eax,0x3fc
    480a:	ja     0x574d
    4810:	movdqa xmm14,xmm1
    4815:	psrldq xmm14,0x8
    481b:	movq   rax,xmm14
    4820:	add    rax,rax
    4823:	je     0x4839
    4825:	shr    rax,0x35
    4829:	sub    eax,0x201
    482e:	cmp    eax,0x3fc
    4833:	ja     0x574d
    4839:	addpd  xmm0,xmm1
    483d:	movdqa xmm4,xmm0
    4841:	movdqa xmm0,xmm4
    4845:	movdqu XMMWORD PTR [r12+0x160],xmm0
    484f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    4859:	movdqa xmm2,xmm0
    485d:	movdqa xmm0,xmm7
    4861:	movdqa xmm1,xmm2
    4865:	movq   rax,xmm0
    486a:	add    rax,rax
    486d:	je     0x4883
    486f:	shr    rax,0x35
    4873:	sub    eax,0x201
    4878:	cmp    eax,0x3fc
    487d:	ja     0x5771
    4883:	movdqa xmm14,xmm0
    4888:	psrldq xmm14,0x8
    488e:	movq   rax,xmm14
    4893:	add    rax,rax
    4896:	je     0x48ac
    4898:	shr    rax,0x35
    489c:	sub    eax,0x201
    48a1:	cmp    eax,0x3fc
    48a6:	ja     0x5771
    48ac:	movq   rax,xmm1
    48b1:	add    rax,rax
    48b4:	je     0x48ca
    48b6:	shr    rax,0x35
    48ba:	sub    eax,0x201
    48bf:	cmp    eax,0x3fc
    48c4:	ja     0x5771
    48ca:	movdqa xmm14,xmm1
    48cf:	psrldq xmm14,0x8
    48d5:	movq   rax,xmm14
    48da:	add    rax,rax
    48dd:	je     0x48f3
    48df:	shr    rax,0x35
    48e3:	sub    eax,0x201
    48e8:	cmp    eax,0x3fc
    48ed:	ja     0x5771
    48f3:	addpd  xmm0,xmm1
    48f7:	movdqa xmm3,xmm0
    48fb:	movdqa xmm0,xmm3
    48ff:	movdqu XMMWORD PTR [r12+0x120],xmm0
    4909:	mov    r13,QWORD PTR [r12+0x60]
    490e:	mov    r14,r13
    4911:	add    r14,0x10
    4915:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    491f:	movdqa xmm2,xmm0
    4923:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    492d:	movdqa xmm4,xmm0
    4931:	stmxcsr DWORD PTR [rsp+0x114]
    4939:	ldmxcsr DWORD PTR [rsp+0x110]
    4941:	mov    r11d,DWORD PTR [rsp+0x114]
    4949:	shr    r11d,1
    494c:	and    r11d,0x10
    4950:	or     DWORD PTR [r12+0x314],r11d
    4958:	movdqu XMMWORD PTR [r13+0x0],xmm2
    495e:	mov    r15d,0x0
    4964:	mov    DWORD PTR [r12+0x32c],r15d
    496c:	movdqu XMMWORD PTR [r14],xmm4
    4971:	mov    r14d,0x0
    4977:	mov    DWORD PTR [r12+0x32c],r14d
    497f:	add    r13,0x20
    4983:	mov    r14,r13
    4986:	add    r14,0x10
    498a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    4994:	movdqa xmm2,xmm0
    4998:	movdqu XMMWORD PTR [r13+0x0],xmm2
    499e:	mov    r13d,0x0
    49a4:	mov    DWORD PTR [r12+0x32c],r13d
    49ac:	movdqu XMMWORD PTR [r14],xmm3
    49b1:	mov    r13d,0x0
    49b7:	mov    DWORD PTR [r12+0x32c],r13d
    49bf:	mov    rcx,QWORD PTR [r12+0x380]
    49c7:	jrcxz  0x49ce
    49c9:	jmp    0x70ea
    49ce:	push   QWORD PTR [rsp]
    49d1:	popf
    49d2:	je     0x49dd
    49d8:	jmp    0xe18
    49dd:	mov    r13d,DWORD PTR [r12+0x48]
    49e2:	add    r13d,0x1
    49e6:	mov    QWORD PTR [r12+0x48],r13
    49eb:	sub    r13d,0x1f4
    49f2:	mov    rcx,QWORD PTR [r12+0x380]
    49fa:	jrcxz  0x4a01
    49fc:	jmp    0x7174
    4a01:	pushf
    4a02:	pop    r11
    4a04:	mov    QWORD PTR [rsp],r11
    4a08:	jne    0xe08
    4a0e:	jmp    0x4a13
    4a13:	mov    r13d,0x430000
    4a19:	mov    QWORD PTR [r12+0x40],r13
    4a1e:	mov    r13d,0x0
    4a24:	mov    QWORD PTR [r12+0x48],r13
    4a29:	mov    r13d,0x430cc0
    4a2f:	mov    r14,QWORD PTR [r13+0x0]
    4a33:	mov    r13d,0x0
    4a39:	mov    QWORD PTR [r12+0x110],r14
    4a41:	mov    QWORD PTR [r12+0x118],r13
    4a49:	jmp    0x4a4e
    4a4e:	mov    r13,QWORD PTR [r12+0x48]
    4a53:	mov    r14,QWORD PTR [r12+0x50]
    4a58:	mov    rcx,r13
    4a5b:	add    r14,rcx
    4a5e:	movdqu xmm2,XMMWORD PTR [r14]
    4a63:	movdqa xmm0,xmm2
    4a67:	movdqu XMMWORD PTR [r12+0x120],xmm0
    4a71:	add    r13,0x10
    4a75:	mov    QWORD PTR [r12+0x48],r13
    4a7a:	sub    r13,0x200
    4a81:	mov    r13,QWORD PTR [r12+0x128]
    4a89:	mov    r14d,0x0
    4a8f:	mov    QWORD PTR [r12+0x130],r13
    4a97:	mov    QWORD PTR [r12+0x138],r14
    4a9f:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    4aa9:	movdqa xmm2,xmm0
    4aad:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    4ab7:	movdqa xmm3,xmm0
    4abb:	pushf
    4abc:	pop    r11
    4abe:	mov    QWORD PTR [rsp],r11
    4ac2:	stmxcsr DWORD PTR [rsp+0x110]
    4aca:	mov    DWORD PTR [rsp+0x114],0x1f80
    4ad5:	ldmxcsr DWORD PTR [rsp+0x114]
    4add:	movdqa xmm0,xmm2
    4ae1:	movdqa xmm1,xmm3
    4ae5:	movq   rax,xmm0
    4aea:	add    rax,rax
    4aed:	je     0x4b03
    4aef:	shr    rax,0x35
    4af3:	sub    eax,0x201
    4af8:	cmp    eax,0x3fc
    4afd:	ja     0x5795
    4b03:	movq   rax,xmm1
    4b08:	add    rax,rax
    4b0b:	je     0x4b21
    4b0d:	shr    rax,0x35
    4b11:	sub    eax,0x201
    4b16:	cmp    eax,0x3fc
    4b1b:	ja     0x5795
    4b21:	movq   xmm0,xmm0
    4b25:	movq   xmm1,xmm1
    4b29:	addsd  xmm0,xmm1
    4b2d:	movdqa xmm4,xmm0
    4b31:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    4b3b:	movdqa xmm2,xmm0
    4b3f:	movdqa xmm0,xmm4
    4b43:	movdqa xmm1,xmm2
    4b47:	movq   rax,xmm0
    4b4c:	add    rax,rax
    4b4f:	je     0x4b65
    4b51:	shr    rax,0x35
    4b55:	sub    eax,0x201
    4b5a:	cmp    eax,0x3fc
    4b5f:	ja     0x57b9
    4b65:	movq   rax,xmm1
    4b6a:	add    rax,rax
    4b6d:	je     0x4b83
    4b6f:	shr    rax,0x35
    4b73:	sub    eax,0x201
    4b78:	cmp    eax,0x3fc
    4b7d:	ja     0x57b9
    4b83:	movq   xmm0,xmm0
    4b87:	movq   xmm1,xmm1
    4b8b:	addsd  xmm0,xmm1
    4b8f:	movdqa xmm3,xmm0
    4b93:	movdqa xmm0,xmm3
    4b97:	movdqu XMMWORD PTR [r12+0x110],xmm0
    4ba1:	stmxcsr DWORD PTR [rsp+0x114]
    4ba9:	ldmxcsr DWORD PTR [rsp+0x110]
    4bb1:	mov    r11d,DWORD PTR [rsp+0x114]
    4bb9:	shr    r11d,1
    4bbc:	and    r11d,0x10
    4bc0:	or     DWORD PTR [r12+0x314],r11d
    4bc8:	mov    rcx,QWORD PTR [r12+0x380]
    4bd0:	jrcxz  0x4bd7
    4bd2:	jmp    0x7206
    4bd7:	push   QWORD PTR [rsp]
    4bda:	popf
    4bdb:	jne    0x4a4e
    4be1:	jmp    0x4be6
    4be6:	mov    r13,QWORD PTR [r12+0xf8]
    4bee:	mov    r14,r13
    4bf1:	add    r14,0x1d0
    4bf8:	mov    r15,r14
    4bfb:	add    r15,0x8
    4bff:	mov    rbp,QWORD PTR [r14]
    4c02:	mov    r14,QWORD PTR [r15]
    4c05:	mov    QWORD PTR [r12+0xa0],rbp
    4c0d:	mov    QWORD PTR [r12+0x98],r14
    4c15:	mov    r14,QWORD PTR [r12+0x40]
    4c1a:	add    r14,0xcc0
    4c21:	mov    r15,QWORD PTR [r12+0x110]
    4c29:	mov    QWORD PTR [r14],r15
    4c2c:	mov    r14d,0x0
    4c32:	mov    DWORD PTR [r12+0x32c],r14d
    4c3a:	mov    r14,r13
    4c3d:	add    r14,0x1c0
    4c44:	mov    r15,r14
    4c47:	add    r15,0x8
    4c4b:	mov    rbp,QWORD PTR [r14]
    4c4e:	mov    r14,QWORD PTR [r15]
    4c51:	mov    QWORD PTR [r12+0xe8],rbp
    4c59:	mov    QWORD PTR [r12+0xf0],r14
    4c61:	add    r13,0x1b0
    4c68:	mov    r14,r13
    4c6b:	add    r14,0x8
    4c6f:	mov    r15,QWORD PTR [r13+0x0]
    4c73:	mov    r13,QWORD PTR [r14]
    4c76:	mov    r14d,0x0
    4c7c:	mov    QWORD PTR [r12+0x1a0],r15
    4c84:	mov    QWORD PTR [r12+0x1a8],r14
    4c8c:	mov    r14d,0x0
    4c92:	mov    QWORD PTR [r12+0x190],r13
    4c9a:	mov    QWORD PTR [r12+0x198],r14
    4ca2:	mov    r13,QWORD PTR [r12+0xf8]
    4caa:	mov    r14,r13
    4cad:	add    r14,0x1a0
    4cb4:	mov    r15,r14
    4cb7:	add    r15,0x8
    4cbb:	mov    rbp,QWORD PTR [r14]
    4cbe:	mov    r14,QWORD PTR [r15]
    4cc1:	mov    r15d,0x0
    4cc7:	mov    QWORD PTR [r12+0x1c0],rbp
    4ccf:	mov    QWORD PTR [r12+0x1c8],r15
    4cd7:	mov    r15d,0x0
    4cdd:	mov    QWORD PTR [r12+0x1b0],r14
    4ce5:	mov    QWORD PTR [r12+0x1b8],r15
    4ced:	add    r13,0x190
    4cf4:	mov    r14,r13
    4cf7:	add    r14,0x8
    4cfb:	mov    r15,QWORD PTR [r13+0x0]
    4cff:	mov    r13,QWORD PTR [r14]
    4d02:	mov    r14d,0x0
    4d08:	mov    QWORD PTR [r12+0x1e0],r15
    4d10:	mov    QWORD PTR [r12+0x1e8],r14
    4d18:	mov    r14d,0x0
    4d1e:	mov    QWORD PTR [r12+0x1d0],r13
    4d26:	mov    QWORD PTR [r12+0x1d8],r14
    4d2e:	mov    r13,QWORD PTR [r12+0xf8]
    4d36:	mov    r14,r13
    4d39:	add    r14,0x180
    4d40:	mov    r15,r14
    4d43:	add    r15,0x8
    4d47:	mov    rbp,QWORD PTR [r14]
    4d4a:	mov    r14,QWORD PTR [r15]
    4d4d:	mov    r15d,0x0
    4d53:	mov    QWORD PTR [r12+0x200],rbp
    4d5b:	mov    QWORD PTR [r12+0x208],r15
    4d63:	mov    r15d,0x0
    4d69:	mov    QWORD PTR [r12+0x1f0],r14
    4d71:	mov    QWORD PTR [r12+0x1f8],r15
    4d79:	add    r13,0x1e0
    4d80:	mov    QWORD PTR [r12+0xf8],r13
    4d88:	mov    rcx,QWORD PTR [r12+0x380]
    4d90:	jrcxz  0x4d97
    4d92:	jmp    0x7290
    4d97:	mov    r13,QWORD PTR [r12+0xf0]
    4d9f:	mov    QWORD PTR [r12+0x100],r13
    4da7:	mov    r11,QWORD PTR [rsp]
    4dab:	mov    QWORD PTR [r12+0x398],r11
    4db3:	mov    rdi,QWORD PTR [r12+0x100]
    4dbb:	add    rsp,0x150
    4dc2:	movabs r11,0x57780bcbe0a0
    4dcc:	jmp    r11
    4dcf:	mov    r13d,DWORD PTR [r12+0x98]
    4dd7:	mov    r14d,DWORD PTR [r12]
    4ddb:	mov    ecx,r13d
    4dde:	add    r14d,ecx
    4de1:	mov    QWORD PTR [r12],r14
    4de5:	mov    r13d,0x4103f8
    4deb:	mov    QWORD PTR [r12+0xf0],r13
    4df3:	mov    r13d,0x4109a4
    4df9:	mov    QWORD PTR [r12+0x100],r13
    4e01:	mov    r11,QWORD PTR [rsp]
    4e05:	mov    QWORD PTR [r12+0x398],r11
    4e0d:	mov    edi,0x4109a4
    4e12:	mov    QWORD PTR [r12+0x100],rdi
    4e1a:	add    rsp,0x150
    4e21:	nop    DWORD PTR [rax+0x0]
    4e28:	jmp    QWORD PTR [rip+0x2]        # 0x4e30
    4e2e:	xchg   ax,ax
    4e30:	nop
    4e31:	and    DWORD PTR [rax+0x710da0],edx
    4e37:	add    BYTE PTR [rax+0x7a],al
    4e3a:	nop
    4e3b:	movabs al,ds:0xe0a0bb490000710d
    4e44:	retf
    4e45:	or     edi,DWORD PTR [rax+0x57]
    4e48:	add    BYTE PTR [rax],al
    4e4a:	jmp    r11
    4e4d:	movdqa xmm0,xmm2
    4e51:	movdqa xmm1,xmm3
    4e55:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4e5e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4e67:	call   0x57e0
    4e6c:	jmp    0x613
    4e71:	movdqa xmm0,xmm2
    4e75:	movdqa xmm1,xmm3
    4e79:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4e82:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4e8b:	call   0x57e0
    4e90:	jmp    0x740
    4e95:	movdqa xmm0,xmm3
    4e99:	movdqa xmm1,xmm4
    4e9d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4ea6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4eaf:	call   0x58c0
    4eb4:	jmp    0x10e1
    4eb9:	movdqa xmm0,xmm2
    4ebd:	movdqa xmm1,xmm4
    4ec1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4eca:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4ed3:	call   0x5a50
    4ed8:	jmp    0x11a0
    4edd:	movdqa xmm0,xmm3
    4ee1:	movdqa xmm1,xmm2
    4ee5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4eee:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4ef7:	call   0x5be0
    4efc:	jmp    0x1276
    4f01:	movdqa xmm0,xmm3
    4f05:	movdqa xmm1,xmm2
    4f09:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4f12:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4f1b:	call   0x5be0
    4f20:	jmp    0x1330
    4f25:	movdqa xmm0,xmm2
    4f29:	movdqa xmm1,xmm3
    4f2d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4f36:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4f3f:	call   0x5be0
    4f44:	jmp    0x13f8
    4f49:	movdqa xmm0,xmm2
    4f4d:	movdqa xmm1,xmm3
    4f51:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4f5a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4f63:	call   0x5d60
    4f68:	jmp    0x1503
    4f6d:	movdqa xmm0,xmm2
    4f71:	movdqa xmm1,xmm3
    4f75:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4f7e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4f87:	call   0x5ee0
    4f8c:	jmp    0x1620
    4f91:	movdqa xmm0,xmm2
    4f95:	movdqa xmm1,xmm3
    4f99:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4fa2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4fab:	call   0x5ee0
    4fb0:	jmp    0x16e8
    4fb5:	movdqa xmm0,xmm2
    4fb9:	movdqa xmm1,xmm3
    4fbd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4fc6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4fcf:	call   0x5ee0
    4fd4:	jmp    0x17a2
    4fd9:	movdqa xmm0,xmm2
    4fdd:	movdqa xmm1,xmm4
    4fe1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4fea:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4ff3:	call   0x6060
    4ff8:	jmp    0x19e7
    4ffd:	movdqa xmm0,xmm4
    5001:	movdqa xmm1,xmm5
    5005:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    500e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5017:	call   0x61f0
    501c:	jmp    0x1b0c
    5021:	movdqa xmm0,xmm4
    5025:	movdqa xmm1,xmm5
    5029:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5032:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    503b:	call   0x61f0
    5040:	jmp    0x1bd4
    5045:	movdqa xmm0,xmm3
    5049:	movdqa xmm1,xmm4
    504d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5056:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    505f:	call   0x5a50
    5064:	jmp    0x1c93
    5069:	movdqa xmm0,xmm2
    506d:	movdqa xmm1,xmm3
    5071:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    507a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5083:	call   0x5a50
    5088:	jmp    0x1d52
    508d:	movdqa xmm0,xmm2
    5091:	movdqa xmm1,xmm4
    5095:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    509e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    50a7:	call   0x5a50
    50ac:	jmp    0x1e78
    50b1:	movdqa xmm0,xmm2
    50b5:	movdqa xmm1,xmm3
    50b9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    50c2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    50cb:	call   0x5d60
    50d0:	jmp    0x1f7f
    50d5:	movdqa xmm0,xmm3
    50d9:	movdqa xmm1,xmm4
    50dd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    50e6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    50ef:	call   0x6060
    50f4:	jmp    0x2134
    50f9:	movdqa xmm0,xmm2
    50fd:	movdqa xmm1,xmm3
    5101:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    510a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5113:	call   0x5d60
    5118:	jmp    0x21f3
    511d:	movdqa xmm0,xmm3
    5121:	movdqa xmm1,xmm4
    5125:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    512e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5137:	call   0x6060
    513c:	jmp    0x2320
    5141:	movdqa xmm0,xmm3
    5145:	movdqa xmm1,xmm4
    5149:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5152:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    515b:	call   0x6060
    5160:	jmp    0x23e8
    5165:	movdqa xmm0,xmm2
    5169:	movdqa xmm1,xmm3
    516d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5176:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    517f:	call   0x5d60
    5184:	jmp    0x24cb
    5189:	movdqa xmm0,xmm3
    518d:	movdqa xmm1,xmm4
    5191:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    519a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    51a3:	call   0x6060
    51a8:	jmp    0x25f8
    51ad:	movdqa xmm0,xmm3
    51b1:	movdqa xmm1,xmm4
    51b5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    51be:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    51c7:	call   0x5a50
    51cc:	jmp    0x26c5
    51d1:	movdqa xmm0,xmm2
    51d5:	movdqa xmm1,xmm4
    51d9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    51e2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    51eb:	call   0x6380
    51f0:	jmp    0x2792
    51f5:	movdqa xmm0,xmm3
    51f9:	movdqa xmm1,xmm4
    51fd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5206:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    520f:	call   0x6060
    5214:	jmp    0x28c1
    5219:	movdqa xmm0,xmm2
    521d:	movdqa xmm1,xmm3
    5221:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    522a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5233:	call   0x5d60
    5238:	jmp    0x29c8
    523d:	movdqa xmm0,xmm2
    5241:	movdqa xmm1,xmm4
    5245:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    524e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5257:	call   0x6060
    525c:	jmp    0x2aea
    5261:	movdqa xmm0,xmm2
    5265:	movdqa xmm1,xmm3
    5269:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5272:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    527b:	call   0x5d60
    5280:	jmp    0x2ba9
    5285:	movdqa xmm0,xmm2
    5289:	movdqa xmm1,xmm3
    528d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5296:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    529f:	call   0x5ee0
    52a4:	jmp    0x2c71
    52a9:	movdqa xmm0,xmm2
    52ad:	movdqa xmm1,xmm3
    52b1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    52ba:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    52c3:	call   0x5d60
    52c8:	jmp    0x2d3e
    52cd:	movdqa xmm0,xmm2
    52d1:	movdqa xmm1,xmm3
    52d5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    52de:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    52e7:	call   0x5d60
    52ec:	jmp    0x2dfd
    52f1:	movdqa xmm0,xmm2
    52f5:	movdqa xmm1,xmm4
    52f9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5302:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    530b:	call   0x6060
    5310:	jmp    0x2ec5
    5315:	movdqa xmm0,xmm2
    5319:	movdqa xmm1,xmm4
    531d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5326:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    532f:	call   0x6060
    5334:	jmp    0x2f8d
    5339:	movdqa xmm0,xmm2
    533d:	movdqa xmm1,xmm3
    5341:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    534a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5353:	call   0x5d60
    5358:	jmp    0x304c
    535d:	movdqa xmm0,xmm2
    5361:	movdqa xmm1,xmm3
    5365:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    536e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5377:	call   0x5d60
    537c:	jmp    0x310b
    5381:	movdqa xmm0,xmm2
    5385:	movdqa xmm1,xmm3
    5389:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5392:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    539b:	call   0x5ee0
    53a0:	jmp    0x31d3
    53a5:	movdqa xmm0,xmm2
    53a9:	movdqa xmm1,xmm3
    53ad:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    53b6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    53bf:	call   0x5ee0
    53c4:	jmp    0x329b
    53c9:	movdqa xmm0,xmm2
    53cd:	movdqa xmm1,xmm3
    53d1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    53da:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    53e3:	call   0x5d60
    53e8:	jmp    0x3368
    53ed:	movdqa xmm0,xmm2
    53f1:	movdqa xmm1,xmm3
    53f5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    53fe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5407:	call   0x5ee0
    540c:	jmp    0x3430
    5411:	movdqa xmm0,xmm2
    5415:	movdqa xmm1,xmm3
    5419:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5422:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    542b:	call   0x5ee0
    5430:	jmp    0x34f8
    5435:	movdqa xmm0,xmm2
    5439:	movdqa xmm1,xmm3
    543d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5446:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    544f:	call   0x5d60
    5454:	jmp    0x3693
    5459:	movdqa xmm0,xmm2
    545d:	movdqa xmm1,xmm4
    5461:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    546a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5473:	call   0x6060
    5478:	jmp    0x375b
    547d:	movdqa xmm0,xmm2
    5481:	movdqa xmm1,xmm4
    5485:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    548e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5497:	call   0x6060
    549c:	jmp    0x3823
    54a1:	movdqa xmm0,xmm2
    54a5:	movdqa xmm1,xmm3
    54a9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    54b2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    54bb:	call   0x5d60
    54c0:	jmp    0x38e2
    54c5:	movdqa xmm0,xmm2
    54c9:	movdqa xmm1,xmm3
    54cd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    54d6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    54df:	call   0x5d60
    54e4:	jmp    0x39af
    54e9:	movdqa xmm0,xmm2
    54ed:	movdqa xmm1,xmm3
    54f1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    54fa:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5503:	call   0x5d60
    5508:	jmp    0x3a7c
    550d:	movdqa xmm0,xmm2
    5511:	movdqa xmm1,xmm4
    5515:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    551e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5527:	call   0x6060
    552c:	jmp    0x3b44
    5531:	movdqa xmm0,xmm2
    5535:	movdqa xmm1,xmm3
    5539:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5542:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    554b:	call   0x5d60
    5550:	jmp    0x3c03
    5555:	movdqa xmm0,xmm2
    5559:	movdqa xmm1,xmm4
    555d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5566:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    556f:	call   0x6060
    5574:	jmp    0x3ccb
    5579:	movdqa xmm0,xmm2
    557d:	movdqa xmm1,xmm3
    5581:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    558a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5593:	call   0x5d60
    5598:	jmp    0x3d8a
    559d:	movdqa xmm0,xmm2
    55a1:	movdqa xmm1,xmm3
    55a5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    55ae:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    55b7:	call   0x5ee0
    55bc:	jmp    0x3e52
    55c1:	movdqa xmm0,xmm2
    55c5:	movdqa xmm1,xmm3
    55c9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    55d2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    55db:	call   0x5d60
    55e0:	jmp    0x3f1f
    55e5:	movdqa xmm0,xmm2
    55e9:	movdqa xmm1,xmm3
    55ed:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    55f6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    55ff:	call   0x5ee0
    5604:	jmp    0x3fe7
    5609:	movdqa xmm0,xmm3
    560d:	movdqa xmm1,xmm4
    5611:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    561a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5623:	call   0x6060
    5628:	jmp    0x4113
    562d:	movdqa xmm0,xmm2
    5631:	movdqa xmm1,xmm3
    5635:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    563e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5647:	call   0x5d60
    564c:	jmp    0x41d2
    5651:	movdqa xmm0,xmm2
    5655:	movdqa xmm1,xmm3
    5659:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5662:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    566b:	call   0x5d60
    5670:	jmp    0x4291
    5675:	movdqa xmm0,xmm2
    5679:	movdqa xmm1,xmm4
    567d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5686:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    568f:	call   0x6060
    5694:	jmp    0x4359
    5699:	movdqa xmm0,xmm5
    569d:	movdqa xmm1,xmm6
    56a1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    56aa:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    56b3:	call   0x6500
    56b8:	jmp    0x4483
    56bd:	movdqa xmm0,xmm4
    56c1:	movdqa xmm1,xmm3
    56c5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    56ce:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    56d7:	call   0x66a0
    56dc:	jmp    0x4534
    56e1:	movdqa xmm0,xmm2
    56e5:	movdqa xmm1,xmm3
    56e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    56f2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    56fb:	call   0x6830
    5700:	jmp    0x45e5
    5705:	movdqa xmm0,xmm2
    5709:	movdqa xmm1,xmm3
    570d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5716:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    571f:	call   0x69c0
    5724:	jmp    0x46ad
    5729:	movdqa xmm0,xmm2
    572d:	movdqa xmm1,xmm3
    5731:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    573a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5743:	call   0x69c0
    5748:	jmp    0x4775
    574d:	movdqa xmm0,xmm2
    5751:	movdqa xmm1,xmm3
    5755:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    575e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5767:	call   0x69c0
    576c:	jmp    0x483d
    5771:	movdqa xmm0,xmm7
    5775:	movdqa xmm1,xmm2
    5779:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5782:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    578b:	call   0x6b50
    5790:	jmp    0x48f7
    5795:	movdqa xmm0,xmm2
    5799:	movdqa xmm1,xmm3
    579d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    57a6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    57af:	call   0x6cd0
    57b4:	jmp    0x4b2d
    57b9:	movdqa xmm0,xmm4
    57bd:	movdqa xmm1,xmm2
    57c1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    57ca:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    57d3:	call   0x6e50
    57d8:	jmp    0x4b8f
    57dd:	nop    DWORD PTR [rax]
    57e0:	sub    rsp,0x8
    57e4:	stmxcsr DWORD PTR [rsp+0x124]
    57ec:	ldmxcsr DWORD PTR [rsp+0x120]
    57f4:	mov    r11d,DWORD PTR [rsp+0x124]
    57fc:	shr    r11d,1
    57ff:	and    r11d,0x10
    5803:	or     DWORD PTR [r12+0x314],r11d
    580b:	mov    QWORD PTR [r12+0x378],0x3
    5817:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    581d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5823:	mov    QWORD PTR [r12+0x108],rbx
    582b:	stmxcsr DWORD PTR [r12-0x28]
    5831:	ldmxcsr DWORD PTR [r12-0x38]
    5837:	lea    rdi,[rsp+0x110]
    583f:	lea    rsi,[rsp+0xf0]
    5847:	lea    rdx,[rsp+0x100]
    584f:	mov    ecx,0x16
    5854:	mov    r8d,0x0
    585a:	lea    r9,[r12+0x314]
    5862:	movabs r11,0x57780bb291b0
    586c:	call   r11
    586f:	ldmxcsr DWORD PTR [r12-0x28]
    5875:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    587b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5881:	mov    rbx,QWORD PTR [r12+0x108]
    5889:	mov    QWORD PTR [r12+0x378],0x2
    5895:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    589e:	stmxcsr DWORD PTR [rsp+0x120]
    58a6:	mov    DWORD PTR [rsp+0x124],0x1f80
    58b1:	ldmxcsr DWORD PTR [rsp+0x124]
    58b9:	add    rsp,0x8
    58bd:	ret
    58be:	xchg   ax,ax
    58c0:	sub    rsp,0x8
    58c4:	stmxcsr DWORD PTR [rsp+0x124]
    58cc:	ldmxcsr DWORD PTR [rsp+0x120]
    58d4:	mov    r11d,DWORD PTR [rsp+0x124]
    58dc:	shr    r11d,1
    58df:	and    r11d,0x10
    58e3:	or     DWORD PTR [r12+0x314],r11d
    58eb:	mov    QWORD PTR [r12+0x378],0x3
    58f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    58fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5903:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5909:	push   rdx
    590a:	push   rsi
    590b:	push   r10
    590d:	push   r11
    590f:	mov    rdx,QWORD PTR [rsp+0x30]
    5914:	mov    r10d,edx
    5917:	and    r10d,0xc0
    591e:	shl    r10d,0x18
    5922:	mov    r11d,edx
    5925:	and    r11d,0x1
    5929:	shl    r11d,0x1d
    592d:	or     r10d,r11d
    5930:	mov    r11d,edx
    5933:	and    r11d,0x800
    593a:	shl    r11d,0x11
    593e:	or     r10d,r11d
    5941:	btc    r10,0x1d
    5946:	mov    r11d,0xf0000000
    594c:	and    r11,r10
    594f:	movabs rsi,0xffffffff0fffffff
    5959:	and    rbx,rsi
    595c:	or     rbx,r11
    595f:	pop    r11
    5961:	pop    r10
    5963:	pop    rsi
    5964:	pop    rdx
    5965:	mov    QWORD PTR [r12+0x108],rbx
    596d:	stmxcsr DWORD PTR [r12-0x28]
    5973:	ldmxcsr DWORD PTR [r12-0x38]
    5979:	lea    rdi,[rsp+0x110]
    5981:	lea    rsi,[rsp+0xf0]
    5989:	lea    rdx,[rsp+0x100]
    5991:	mov    ecx,0x16
    5996:	mov    r8d,0x0
    599c:	lea    r9,[r12+0x314]
    59a4:	movabs r11,0x57780bb291b0
    59ae:	call   r11
    59b1:	ldmxcsr DWORD PTR [r12-0x28]
    59b7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    59bd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    59c3:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    59c9:	mov    rbx,QWORD PTR [r12+0x108]
    59d1:	mov    QWORD PTR [r12+0x378],0x2
    59dd:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    59e6:	pushf
    59e7:	pop    rdx
    59e8:	and    rdx,0xfffffffffffff73e
    59ef:	mov    rax,rbx
    59f2:	shr    rax,0x18
    59f6:	and    eax,0xc0
    59fb:	or     rdx,rax
    59fe:	mov    rax,rbx
    5a01:	shr    rax,0x1d
    5a05:	and    eax,0x1
    5a08:	xor    eax,0x1
    5a0b:	or     rdx,rax
    5a0e:	mov    rax,rbx
    5a11:	shr    rax,0x11
    5a15:	and    eax,0x800
    5a1a:	or     rdx,rax
    5a1d:	mov    QWORD PTR [rsp+0x10],rdx
    5a22:	stmxcsr DWORD PTR [rsp+0x120]
    5a2a:	mov    DWORD PTR [rsp+0x124],0x1f80
    5a35:	ldmxcsr DWORD PTR [rsp+0x124]
    5a3d:	add    rsp,0x8
    5a41:	ret
    5a42:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    5a50:	sub    rsp,0x8
    5a54:	stmxcsr DWORD PTR [rsp+0x124]
    5a5c:	ldmxcsr DWORD PTR [rsp+0x120]
    5a64:	mov    r11d,DWORD PTR [rsp+0x124]
    5a6c:	shr    r11d,1
    5a6f:	and    r11d,0x10
    5a73:	or     DWORD PTR [r12+0x314],r11d
    5a7b:	mov    QWORD PTR [r12+0x378],0x3
    5a87:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5a8d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5a93:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5a99:	push   rdx
    5a9a:	push   rsi
    5a9b:	push   r10
    5a9d:	push   r11
    5a9f:	mov    rdx,QWORD PTR [rsp+0x30]
    5aa4:	mov    r10d,edx
    5aa7:	and    r10d,0xc0
    5aae:	shl    r10d,0x18
    5ab2:	mov    r11d,edx
    5ab5:	and    r11d,0x1
    5ab9:	shl    r11d,0x1d
    5abd:	or     r10d,r11d
    5ac0:	mov    r11d,edx
    5ac3:	and    r11d,0x800
    5aca:	shl    r11d,0x11
    5ace:	or     r10d,r11d
    5ad1:	btc    r10,0x1d
    5ad6:	mov    r11d,0xf0000000
    5adc:	and    r11,r10
    5adf:	movabs rsi,0xffffffff0fffffff
    5ae9:	and    rbx,rsi
    5aec:	or     rbx,r11
    5aef:	pop    r11
    5af1:	pop    r10
    5af3:	pop    rsi
    5af4:	pop    rdx
    5af5:	mov    QWORD PTR [r12+0x108],rbx
    5afd:	stmxcsr DWORD PTR [r12-0x28]
    5b03:	ldmxcsr DWORD PTR [r12-0x38]
    5b09:	lea    rdi,[rsp+0x110]
    5b11:	lea    rsi,[rsp+0xf0]
    5b19:	lea    rdx,[rsp+0x100]
    5b21:	mov    ecx,0x56
    5b26:	mov    r8d,0x0
    5b2c:	lea    r9,[r12+0x314]
    5b34:	movabs r11,0x57780bb291b0
    5b3e:	call   r11
    5b41:	ldmxcsr DWORD PTR [r12-0x28]
    5b47:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5b4d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5b53:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5b59:	mov    rbx,QWORD PTR [r12+0x108]
    5b61:	mov    QWORD PTR [r12+0x378],0x2
    5b6d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5b76:	pushf
    5b77:	pop    rdx
    5b78:	and    rdx,0xfffffffffffff73e
    5b7f:	mov    rax,rbx
    5b82:	shr    rax,0x18
    5b86:	and    eax,0xc0
    5b8b:	or     rdx,rax
    5b8e:	mov    rax,rbx
    5b91:	shr    rax,0x1d
    5b95:	and    eax,0x1
    5b98:	xor    eax,0x1
    5b9b:	or     rdx,rax
    5b9e:	mov    rax,rbx
    5ba1:	shr    rax,0x11
    5ba5:	and    eax,0x800
    5baa:	or     rdx,rax
    5bad:	mov    QWORD PTR [rsp+0x10],rdx
    5bb2:	stmxcsr DWORD PTR [rsp+0x120]
    5bba:	mov    DWORD PTR [rsp+0x124],0x1f80
    5bc5:	ldmxcsr DWORD PTR [rsp+0x124]
    5bcd:	add    rsp,0x8
    5bd1:	ret
    5bd2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    5be0:	sub    rsp,0x8
    5be4:	stmxcsr DWORD PTR [rsp+0x124]
    5bec:	ldmxcsr DWORD PTR [rsp+0x120]
    5bf4:	mov    r11d,DWORD PTR [rsp+0x124]
    5bfc:	shr    r11d,1
    5bff:	and    r11d,0x10
    5c03:	or     DWORD PTR [r12+0x314],r11d
    5c0b:	mov    QWORD PTR [r12+0x378],0x3
    5c17:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5c1d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5c23:	push   rdx
    5c24:	push   rsi
    5c25:	push   r10
    5c27:	push   r11
    5c29:	mov    rdx,QWORD PTR [rsp+0x30]
    5c2e:	mov    r10d,edx
    5c31:	and    r10d,0xc0
    5c38:	shl    r10d,0x18
    5c3c:	mov    r11d,edx
    5c3f:	and    r11d,0x1
    5c43:	shl    r11d,0x1d
    5c47:	or     r10d,r11d
    5c4a:	mov    r11d,edx
    5c4d:	and    r11d,0x800
    5c54:	shl    r11d,0x11
    5c58:	or     r10d,r11d
    5c5b:	btc    r10,0x1d
    5c60:	mov    r11d,0xf0000000
    5c66:	and    r11,r10
    5c69:	movabs rsi,0xffffffff0fffffff
    5c73:	and    rbx,rsi
    5c76:	or     rbx,r11
    5c79:	pop    r11
    5c7b:	pop    r10
    5c7d:	pop    rsi
    5c7e:	pop    rdx
    5c7f:	mov    QWORD PTR [r12+0x108],rbx
    5c87:	stmxcsr DWORD PTR [r12-0x28]
    5c8d:	ldmxcsr DWORD PTR [r12-0x38]
    5c93:	lea    rdi,[rsp+0x110]
    5c9b:	lea    rsi,[rsp+0xf0]
    5ca3:	lea    rdx,[rsp+0x100]
    5cab:	mov    ecx,0x16
    5cb0:	mov    r8d,0x0
    5cb6:	lea    r9,[r12+0x314]
    5cbe:	movabs r11,0x57780bb291b0
    5cc8:	call   r11
    5ccb:	ldmxcsr DWORD PTR [r12-0x28]
    5cd1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5cd7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5cdd:	mov    rbx,QWORD PTR [r12+0x108]
    5ce5:	mov    QWORD PTR [r12+0x378],0x2
    5cf1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5cfa:	pushf
    5cfb:	pop    rdx
    5cfc:	and    rdx,0xfffffffffffff73e
    5d03:	mov    rax,rbx
    5d06:	shr    rax,0x18
    5d0a:	and    eax,0xc0
    5d0f:	or     rdx,rax
    5d12:	mov    rax,rbx
    5d15:	shr    rax,0x1d
    5d19:	and    eax,0x1
    5d1c:	xor    eax,0x1
    5d1f:	or     rdx,rax
    5d22:	mov    rax,rbx
    5d25:	shr    rax,0x11
    5d29:	and    eax,0x800
    5d2e:	or     rdx,rax
    5d31:	mov    QWORD PTR [rsp+0x10],rdx
    5d36:	stmxcsr DWORD PTR [rsp+0x120]
    5d3e:	mov    DWORD PTR [rsp+0x124],0x1f80
    5d49:	ldmxcsr DWORD PTR [rsp+0x124]
    5d51:	add    rsp,0x8
    5d55:	ret
    5d56:	data16 nop WORD PTR [rax+rax*1+0x0]
    5d60:	sub    rsp,0x8
    5d64:	stmxcsr DWORD PTR [rsp+0x124]
    5d6c:	ldmxcsr DWORD PTR [rsp+0x120]
    5d74:	mov    r11d,DWORD PTR [rsp+0x124]
    5d7c:	shr    r11d,1
    5d7f:	and    r11d,0x10
    5d83:	or     DWORD PTR [r12+0x314],r11d
    5d8b:	mov    QWORD PTR [r12+0x378],0x3
    5d97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5d9d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5da3:	push   rdx
    5da4:	push   rsi
    5da5:	push   r10
    5da7:	push   r11
    5da9:	mov    rdx,QWORD PTR [rsp+0x30]
    5dae:	mov    r10d,edx
    5db1:	and    r10d,0xc0
    5db8:	shl    r10d,0x18
    5dbc:	mov    r11d,edx
    5dbf:	and    r11d,0x1
    5dc3:	shl    r11d,0x1d
    5dc7:	or     r10d,r11d
    5dca:	mov    r11d,edx
    5dcd:	and    r11d,0x800
    5dd4:	shl    r11d,0x11
    5dd8:	or     r10d,r11d
    5ddb:	btc    r10,0x1d
    5de0:	mov    r11d,0xf0000000
    5de6:	and    r11,r10
    5de9:	movabs rsi,0xffffffff0fffffff
    5df3:	and    rbx,rsi
    5df6:	or     rbx,r11
    5df9:	pop    r11
    5dfb:	pop    r10
    5dfd:	pop    rsi
    5dfe:	pop    rdx
    5dff:	mov    QWORD PTR [r12+0x108],rbx
    5e07:	stmxcsr DWORD PTR [r12-0x28]
    5e0d:	ldmxcsr DWORD PTR [r12-0x38]
    5e13:	lea    rdi,[rsp+0x110]
    5e1b:	lea    rsi,[rsp+0xf0]
    5e23:	lea    rdx,[rsp+0x100]
    5e2b:	mov    ecx,0x56
    5e30:	mov    r8d,0x0
    5e36:	lea    r9,[r12+0x314]
    5e3e:	movabs r11,0x57780bb291b0
    5e48:	call   r11
    5e4b:	ldmxcsr DWORD PTR [r12-0x28]
    5e51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5e57:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5e5d:	mov    rbx,QWORD PTR [r12+0x108]
    5e65:	mov    QWORD PTR [r12+0x378],0x2
    5e71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5e7a:	pushf
    5e7b:	pop    rdx
    5e7c:	and    rdx,0xfffffffffffff73e
    5e83:	mov    rax,rbx
    5e86:	shr    rax,0x18
    5e8a:	and    eax,0xc0
    5e8f:	or     rdx,rax
    5e92:	mov    rax,rbx
    5e95:	shr    rax,0x1d
    5e99:	and    eax,0x1
    5e9c:	xor    eax,0x1
    5e9f:	or     rdx,rax
    5ea2:	mov    rax,rbx
    5ea5:	shr    rax,0x11
    5ea9:	and    eax,0x800
    5eae:	or     rdx,rax
    5eb1:	mov    QWORD PTR [rsp+0x10],rdx
    5eb6:	stmxcsr DWORD PTR [rsp+0x120]
    5ebe:	mov    DWORD PTR [rsp+0x124],0x1f80
    5ec9:	ldmxcsr DWORD PTR [rsp+0x124]
    5ed1:	add    rsp,0x8
    5ed5:	ret
    5ed6:	data16 nop WORD PTR [rax+rax*1+0x0]
    5ee0:	sub    rsp,0x8
    5ee4:	stmxcsr DWORD PTR [rsp+0x124]
    5eec:	ldmxcsr DWORD PTR [rsp+0x120]
    5ef4:	mov    r11d,DWORD PTR [rsp+0x124]
    5efc:	shr    r11d,1
    5eff:	and    r11d,0x10
    5f03:	or     DWORD PTR [r12+0x314],r11d
    5f0b:	mov    QWORD PTR [r12+0x378],0x3
    5f17:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5f1d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5f23:	push   rdx
    5f24:	push   rsi
    5f25:	push   r10
    5f27:	push   r11
    5f29:	mov    rdx,QWORD PTR [rsp+0x30]
    5f2e:	mov    r10d,edx
    5f31:	and    r10d,0xc0
    5f38:	shl    r10d,0x18
    5f3c:	mov    r11d,edx
    5f3f:	and    r11d,0x1
    5f43:	shl    r11d,0x1d
    5f47:	or     r10d,r11d
    5f4a:	mov    r11d,edx
    5f4d:	and    r11d,0x800
    5f54:	shl    r11d,0x11
    5f58:	or     r10d,r11d
    5f5b:	btc    r10,0x1d
    5f60:	mov    r11d,0xf0000000
    5f66:	and    r11,r10
    5f69:	movabs rsi,0xffffffff0fffffff
    5f73:	and    rbx,rsi
    5f76:	or     rbx,r11
    5f79:	pop    r11
    5f7b:	pop    r10
    5f7d:	pop    rsi
    5f7e:	pop    rdx
    5f7f:	mov    QWORD PTR [r12+0x108],rbx
    5f87:	stmxcsr DWORD PTR [r12-0x28]
    5f8d:	ldmxcsr DWORD PTR [r12-0x38]
    5f93:	lea    rdi,[rsp+0x110]
    5f9b:	lea    rsi,[rsp+0xf0]
    5fa3:	lea    rdx,[rsp+0x100]
    5fab:	mov    ecx,0x14
    5fb0:	mov    r8d,0x0
    5fb6:	lea    r9,[r12+0x314]
    5fbe:	movabs r11,0x57780bb291b0
    5fc8:	call   r11
    5fcb:	ldmxcsr DWORD PTR [r12-0x28]
    5fd1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5fd7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5fdd:	mov    rbx,QWORD PTR [r12+0x108]
    5fe5:	mov    QWORD PTR [r12+0x378],0x2
    5ff1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5ffa:	pushf
    5ffb:	pop    rdx
    5ffc:	and    rdx,0xfffffffffffff73e
    6003:	mov    rax,rbx
    6006:	shr    rax,0x18
    600a:	and    eax,0xc0
    600f:	or     rdx,rax
    6012:	mov    rax,rbx
    6015:	shr    rax,0x1d
    6019:	and    eax,0x1
    601c:	xor    eax,0x1
    601f:	or     rdx,rax
    6022:	mov    rax,rbx
    6025:	shr    rax,0x11
    6029:	and    eax,0x800
    602e:	or     rdx,rax
    6031:	mov    QWORD PTR [rsp+0x10],rdx
    6036:	stmxcsr DWORD PTR [rsp+0x120]
    603e:	mov    DWORD PTR [rsp+0x124],0x1f80
    6049:	ldmxcsr DWORD PTR [rsp+0x124]
    6051:	add    rsp,0x8
    6055:	ret
    6056:	data16 nop WORD PTR [rax+rax*1+0x0]
    6060:	sub    rsp,0x8
    6064:	stmxcsr DWORD PTR [rsp+0x124]
    606c:	ldmxcsr DWORD PTR [rsp+0x120]
    6074:	mov    r11d,DWORD PTR [rsp+0x124]
    607c:	shr    r11d,1
    607f:	and    r11d,0x10
    6083:	or     DWORD PTR [r12+0x314],r11d
    608b:	mov    QWORD PTR [r12+0x378],0x3
    6097:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    609d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    60a3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    60a9:	push   rdx
    60aa:	push   rsi
    60ab:	push   r10
    60ad:	push   r11
    60af:	mov    rdx,QWORD PTR [rsp+0x30]
    60b4:	mov    r10d,edx
    60b7:	and    r10d,0xc0
    60be:	shl    r10d,0x18
    60c2:	mov    r11d,edx
    60c5:	and    r11d,0x1
    60c9:	shl    r11d,0x1d
    60cd:	or     r10d,r11d
    60d0:	mov    r11d,edx
    60d3:	and    r11d,0x800
    60da:	shl    r11d,0x11
    60de:	or     r10d,r11d
    60e1:	btc    r10,0x1d
    60e6:	mov    r11d,0xf0000000
    60ec:	and    r11,r10
    60ef:	movabs rsi,0xffffffff0fffffff
    60f9:	and    rbx,rsi
    60fc:	or     rbx,r11
    60ff:	pop    r11
    6101:	pop    r10
    6103:	pop    rsi
    6104:	pop    rdx
    6105:	mov    QWORD PTR [r12+0x108],rbx
    610d:	stmxcsr DWORD PTR [r12-0x28]
    6113:	ldmxcsr DWORD PTR [r12-0x38]
    6119:	lea    rdi,[rsp+0x110]
    6121:	lea    rsi,[rsp+0xf0]
    6129:	lea    rdx,[rsp+0x100]
    6131:	mov    ecx,0x14
    6136:	mov    r8d,0x0
    613c:	lea    r9,[r12+0x314]
    6144:	movabs r11,0x57780bb291b0
    614e:	call   r11
    6151:	ldmxcsr DWORD PTR [r12-0x28]
    6157:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    615d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6163:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6169:	mov    rbx,QWORD PTR [r12+0x108]
    6171:	mov    QWORD PTR [r12+0x378],0x2
    617d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6186:	pushf
    6187:	pop    rdx
    6188:	and    rdx,0xfffffffffffff73e
    618f:	mov    rax,rbx
    6192:	shr    rax,0x18
    6196:	and    eax,0xc0
    619b:	or     rdx,rax
    619e:	mov    rax,rbx
    61a1:	shr    rax,0x1d
    61a5:	and    eax,0x1
    61a8:	xor    eax,0x1
    61ab:	or     rdx,rax
    61ae:	mov    rax,rbx
    61b1:	shr    rax,0x11
    61b5:	and    eax,0x800
    61ba:	or     rdx,rax
    61bd:	mov    QWORD PTR [rsp+0x10],rdx
    61c2:	stmxcsr DWORD PTR [rsp+0x120]
    61ca:	mov    DWORD PTR [rsp+0x124],0x1f80
    61d5:	ldmxcsr DWORD PTR [rsp+0x124]
    61dd:	add    rsp,0x8
    61e1:	ret
    61e2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    61f0:	sub    rsp,0x8
    61f4:	stmxcsr DWORD PTR [rsp+0x124]
    61fc:	ldmxcsr DWORD PTR [rsp+0x120]
    6204:	mov    r11d,DWORD PTR [rsp+0x124]
    620c:	shr    r11d,1
    620f:	and    r11d,0x10
    6213:	or     DWORD PTR [r12+0x314],r11d
    621b:	mov    QWORD PTR [r12+0x378],0x3
    6227:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    622d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6233:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6239:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    623f:	push   rdx
    6240:	push   rsi
    6241:	push   r10
    6243:	push   r11
    6245:	mov    rdx,QWORD PTR [rsp+0x30]
    624a:	mov    r10d,edx
    624d:	and    r10d,0xc0
    6254:	shl    r10d,0x18
    6258:	mov    r11d,edx
    625b:	and    r11d,0x1
    625f:	shl    r11d,0x1d
    6263:	or     r10d,r11d
    6266:	mov    r11d,edx
    6269:	and    r11d,0x800
    6270:	shl    r11d,0x11
    6274:	or     r10d,r11d
    6277:	btc    r10,0x1d
    627c:	mov    r11d,0xf0000000
    6282:	and    r11,r10
    6285:	movabs rsi,0xffffffff0fffffff
    628f:	and    rbx,rsi
    6292:	or     rbx,r11
    6295:	pop    r11
    6297:	pop    r10
    6299:	pop    rsi
    629a:	pop    rdx
    629b:	mov    QWORD PTR [r12+0x108],rbx
    62a3:	stmxcsr DWORD PTR [r12-0x28]
    62a9:	ldmxcsr DWORD PTR [r12-0x38]
    62af:	lea    rdi,[rsp+0x110]
    62b7:	lea    rsi,[rsp+0xf0]
    62bf:	lea    rdx,[rsp+0x100]
    62c7:	mov    ecx,0x14
    62cc:	mov    r8d,0x0
    62d2:	lea    r9,[r12+0x314]
    62da:	movabs r11,0x57780bb291b0
    62e4:	call   r11
    62e7:	ldmxcsr DWORD PTR [r12-0x28]
    62ed:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    62f3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    62f9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    62ff:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6305:	mov    rbx,QWORD PTR [r12+0x108]
    630d:	mov    QWORD PTR [r12+0x378],0x2
    6319:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6322:	pushf
    6323:	pop    rdx
    6324:	and    rdx,0xfffffffffffff73e
    632b:	mov    rax,rbx
    632e:	shr    rax,0x18
    6332:	and    eax,0xc0
    6337:	or     rdx,rax
    633a:	mov    rax,rbx
    633d:	shr    rax,0x1d
    6341:	and    eax,0x1
    6344:	xor    eax,0x1
    6347:	or     rdx,rax
    634a:	mov    rax,rbx
    634d:	shr    rax,0x11
    6351:	and    eax,0x800
    6356:	or     rdx,rax
    6359:	mov    QWORD PTR [rsp+0x10],rdx
    635e:	stmxcsr DWORD PTR [rsp+0x120]
    6366:	mov    DWORD PTR [rsp+0x124],0x1f80
    6371:	ldmxcsr DWORD PTR [rsp+0x124]
    6379:	add    rsp,0x8
    637d:	ret
    637e:	xchg   ax,ax
    6380:	sub    rsp,0x8
    6384:	stmxcsr DWORD PTR [rsp+0x124]
    638c:	ldmxcsr DWORD PTR [rsp+0x120]
    6394:	mov    r11d,DWORD PTR [rsp+0x124]
    639c:	shr    r11d,1
    639f:	and    r11d,0x10
    63a3:	or     DWORD PTR [r12+0x314],r11d
    63ab:	mov    QWORD PTR [r12+0x378],0x3
    63b7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    63bd:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    63c3:	push   rdx
    63c4:	push   rsi
    63c5:	push   r10
    63c7:	push   r11
    63c9:	mov    rdx,QWORD PTR [rsp+0x30]
    63ce:	mov    r10d,edx
    63d1:	and    r10d,0xc0
    63d8:	shl    r10d,0x18
    63dc:	mov    r11d,edx
    63df:	and    r11d,0x1
    63e3:	shl    r11d,0x1d
    63e7:	or     r10d,r11d
    63ea:	mov    r11d,edx
    63ed:	and    r11d,0x800
    63f4:	shl    r11d,0x11
    63f8:	or     r10d,r11d
    63fb:	btc    r10,0x1d
    6400:	mov    r11d,0xf0000000
    6406:	and    r11,r10
    6409:	movabs rsi,0xffffffff0fffffff
    6413:	and    rbx,rsi
    6416:	or     rbx,r11
    6419:	pop    r11
    641b:	pop    r10
    641d:	pop    rsi
    641e:	pop    rdx
    641f:	mov    QWORD PTR [r12+0x108],rbx
    6427:	stmxcsr DWORD PTR [r12-0x28]
    642d:	ldmxcsr DWORD PTR [r12-0x38]
    6433:	lea    rdi,[rsp+0x110]
    643b:	lea    rsi,[rsp+0xf0]
    6443:	lea    rdx,[rsp+0x100]
    644b:	mov    ecx,0x56
    6450:	mov    r8d,0x0
    6456:	lea    r9,[r12+0x314]
    645e:	movabs r11,0x57780bb291b0
    6468:	call   r11
    646b:	ldmxcsr DWORD PTR [r12-0x28]
    6471:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6477:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    647d:	mov    rbx,QWORD PTR [r12+0x108]
    6485:	mov    QWORD PTR [r12+0x378],0x2
    6491:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    649a:	pushf
    649b:	pop    rdx
    649c:	and    rdx,0xfffffffffffff73e
    64a3:	mov    rax,rbx
    64a6:	shr    rax,0x18
    64aa:	and    eax,0xc0
    64af:	or     rdx,rax
    64b2:	mov    rax,rbx
    64b5:	shr    rax,0x1d
    64b9:	and    eax,0x1
    64bc:	xor    eax,0x1
    64bf:	or     rdx,rax
    64c2:	mov    rax,rbx
    64c5:	shr    rax,0x11
    64c9:	and    eax,0x800
    64ce:	or     rdx,rax
    64d1:	mov    QWORD PTR [rsp+0x10],rdx
    64d6:	stmxcsr DWORD PTR [rsp+0x120]
    64de:	mov    DWORD PTR [rsp+0x124],0x1f80
    64e9:	ldmxcsr DWORD PTR [rsp+0x124]
    64f1:	add    rsp,0x8
    64f5:	ret
    64f6:	data16 nop WORD PTR [rax+rax*1+0x0]
    6500:	sub    rsp,0x8
    6504:	stmxcsr DWORD PTR [rsp+0x124]
    650c:	ldmxcsr DWORD PTR [rsp+0x120]
    6514:	mov    r11d,DWORD PTR [rsp+0x124]
    651c:	shr    r11d,1
    651f:	and    r11d,0x10
    6523:	or     DWORD PTR [r12+0x314],r11d
    652b:	mov    QWORD PTR [r12+0x378],0x3
    6537:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    653d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6543:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6549:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    654f:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    6555:	push   rdx
    6556:	push   rsi
    6557:	push   r10
    6559:	push   r11
    655b:	mov    rdx,QWORD PTR [rsp+0x30]
    6560:	mov    r10d,edx
    6563:	and    r10d,0xc0
    656a:	shl    r10d,0x18
    656e:	mov    r11d,edx
    6571:	and    r11d,0x1
    6575:	shl    r11d,0x1d
    6579:	or     r10d,r11d
    657c:	mov    r11d,edx
    657f:	and    r11d,0x800
    6586:	shl    r11d,0x11
    658a:	or     r10d,r11d
    658d:	btc    r10,0x1d
    6592:	mov    r11d,0xf0000000
    6598:	and    r11,r10
    659b:	movabs rsi,0xffffffff0fffffff
    65a5:	and    rbx,rsi
    65a8:	or     rbx,r11
    65ab:	pop    r11
    65ad:	pop    r10
    65af:	pop    rsi
    65b0:	pop    rdx
    65b1:	mov    QWORD PTR [r12+0x108],rbx
    65b9:	stmxcsr DWORD PTR [r12-0x28]
    65bf:	ldmxcsr DWORD PTR [r12-0x38]
    65c5:	lea    rdi,[rsp+0x110]
    65cd:	lea    rsi,[rsp+0xf0]
    65d5:	lea    rdx,[rsp+0x100]
    65dd:	mov    ecx,0x14
    65e2:	mov    r8d,0x0
    65e8:	lea    r9,[r12+0x314]
    65f0:	movabs r11,0x57780bb291b0
    65fa:	call   r11
    65fd:	ldmxcsr DWORD PTR [r12-0x28]
    6603:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6609:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    660f:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6615:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    661b:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    6621:	mov    rbx,QWORD PTR [r12+0x108]
    6629:	mov    QWORD PTR [r12+0x378],0x2
    6635:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    663e:	pushf
    663f:	pop    rdx
    6640:	and    rdx,0xfffffffffffff73e
    6647:	mov    rax,rbx
    664a:	shr    rax,0x18
    664e:	and    eax,0xc0
    6653:	or     rdx,rax
    6656:	mov    rax,rbx
    6659:	shr    rax,0x1d
    665d:	and    eax,0x1
    6660:	xor    eax,0x1
    6663:	or     rdx,rax
    6666:	mov    rax,rbx
    6669:	shr    rax,0x11
    666d:	and    eax,0x800
    6672:	or     rdx,rax
    6675:	mov    QWORD PTR [rsp+0x10],rdx
    667a:	stmxcsr DWORD PTR [rsp+0x120]
    6682:	mov    DWORD PTR [rsp+0x124],0x1f80
    668d:	ldmxcsr DWORD PTR [rsp+0x124]
    6695:	add    rsp,0x8
    6699:	ret
    669a:	nop    WORD PTR [rax+rax*1+0x0]
    66a0:	sub    rsp,0x8
    66a4:	stmxcsr DWORD PTR [rsp+0x124]
    66ac:	ldmxcsr DWORD PTR [rsp+0x120]
    66b4:	mov    r11d,DWORD PTR [rsp+0x124]
    66bc:	shr    r11d,1
    66bf:	and    r11d,0x10
    66c3:	or     DWORD PTR [r12+0x314],r11d
    66cb:	mov    QWORD PTR [r12+0x378],0x3
    66d7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    66dd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    66e3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    66e9:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    66ef:	push   rdx
    66f0:	push   rsi
    66f1:	push   r10
    66f3:	push   r11
    66f5:	mov    rdx,QWORD PTR [rsp+0x30]
    66fa:	mov    r10d,edx
    66fd:	and    r10d,0xc0
    6704:	shl    r10d,0x18
    6708:	mov    r11d,edx
    670b:	and    r11d,0x1
    670f:	shl    r11d,0x1d
    6713:	or     r10d,r11d
    6716:	mov    r11d,edx
    6719:	and    r11d,0x800
    6720:	shl    r11d,0x11
    6724:	or     r10d,r11d
    6727:	btc    r10,0x1d
    672c:	mov    r11d,0xf0000000
    6732:	and    r11,r10
    6735:	movabs rsi,0xffffffff0fffffff
    673f:	and    rbx,rsi
    6742:	or     rbx,r11
    6745:	pop    r11
    6747:	pop    r10
    6749:	pop    rsi
    674a:	pop    rdx
    674b:	mov    QWORD PTR [r12+0x108],rbx
    6753:	stmxcsr DWORD PTR [r12-0x28]
    6759:	ldmxcsr DWORD PTR [r12-0x38]
    675f:	lea    rdi,[rsp+0x110]
    6767:	lea    rsi,[rsp+0xf0]
    676f:	lea    rdx,[rsp+0x100]
    6777:	mov    ecx,0x56
    677c:	mov    r8d,0x0
    6782:	lea    r9,[r12+0x314]
    678a:	movabs r11,0x57780bb291b0
    6794:	call   r11
    6797:	ldmxcsr DWORD PTR [r12-0x28]
    679d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    67a3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    67a9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    67af:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    67b5:	mov    rbx,QWORD PTR [r12+0x108]
    67bd:	mov    QWORD PTR [r12+0x378],0x2
    67c9:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    67d2:	pushf
    67d3:	pop    rdx
    67d4:	and    rdx,0xfffffffffffff73e
    67db:	mov    rax,rbx
    67de:	shr    rax,0x18
    67e2:	and    eax,0xc0
    67e7:	or     rdx,rax
    67ea:	mov    rax,rbx
    67ed:	shr    rax,0x1d
    67f1:	and    eax,0x1
    67f4:	xor    eax,0x1
    67f7:	or     rdx,rax
    67fa:	mov    rax,rbx
    67fd:	shr    rax,0x11
    6801:	and    eax,0x800
    6806:	or     rdx,rax
    6809:	mov    QWORD PTR [rsp+0x10],rdx
    680e:	stmxcsr DWORD PTR [rsp+0x120]
    6816:	mov    DWORD PTR [rsp+0x124],0x1f80
    6821:	ldmxcsr DWORD PTR [rsp+0x124]
    6829:	add    rsp,0x8
    682d:	ret
    682e:	xchg   ax,ax
    6830:	sub    rsp,0x8
    6834:	stmxcsr DWORD PTR [rsp+0x124]
    683c:	ldmxcsr DWORD PTR [rsp+0x120]
    6844:	mov    r11d,DWORD PTR [rsp+0x124]
    684c:	shr    r11d,1
    684f:	and    r11d,0x10
    6853:	or     DWORD PTR [r12+0x314],r11d
    685b:	mov    QWORD PTR [r12+0x378],0x3
    6867:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    686d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6873:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6879:	push   rdx
    687a:	push   rsi
    687b:	push   r10
    687d:	push   r11
    687f:	mov    rdx,QWORD PTR [rsp+0x30]
    6884:	mov    r10d,edx
    6887:	and    r10d,0xc0
    688e:	shl    r10d,0x18
    6892:	mov    r11d,edx
    6895:	and    r11d,0x1
    6899:	shl    r11d,0x1d
    689d:	or     r10d,r11d
    68a0:	mov    r11d,edx
    68a3:	and    r11d,0x800
    68aa:	shl    r11d,0x11
    68ae:	or     r10d,r11d
    68b1:	btc    r10,0x1d
    68b6:	mov    r11d,0xf0000000
    68bc:	and    r11,r10
    68bf:	movabs rsi,0xffffffff0fffffff
    68c9:	and    rbx,rsi
    68cc:	or     rbx,r11
    68cf:	pop    r11
    68d1:	pop    r10
    68d3:	pop    rsi
    68d4:	pop    rdx
    68d5:	mov    QWORD PTR [r12+0x108],rbx
    68dd:	stmxcsr DWORD PTR [r12-0x28]
    68e3:	ldmxcsr DWORD PTR [r12-0x38]
    68e9:	lea    rdi,[rsp+0x110]
    68f1:	lea    rsi,[rsp+0xf0]
    68f9:	lea    rdx,[rsp+0x100]
    6901:	mov    ecx,0x56
    6906:	mov    r8d,0x0
    690c:	lea    r9,[r12+0x314]
    6914:	movabs r11,0x57780bb291b0
    691e:	call   r11
    6921:	ldmxcsr DWORD PTR [r12-0x28]
    6927:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    692d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6933:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6939:	mov    rbx,QWORD PTR [r12+0x108]
    6941:	mov    QWORD PTR [r12+0x378],0x2
    694d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6956:	pushf
    6957:	pop    rdx
    6958:	and    rdx,0xfffffffffffff73e
    695f:	mov    rax,rbx
    6962:	shr    rax,0x18
    6966:	and    eax,0xc0
    696b:	or     rdx,rax
    696e:	mov    rax,rbx
    6971:	shr    rax,0x1d
    6975:	and    eax,0x1
    6978:	xor    eax,0x1
    697b:	or     rdx,rax
    697e:	mov    rax,rbx
    6981:	shr    rax,0x11
    6985:	and    eax,0x800
    698a:	or     rdx,rax
    698d:	mov    QWORD PTR [rsp+0x10],rdx
    6992:	stmxcsr DWORD PTR [rsp+0x120]
    699a:	mov    DWORD PTR [rsp+0x124],0x1f80
    69a5:	ldmxcsr DWORD PTR [rsp+0x124]
    69ad:	add    rsp,0x8
    69b1:	ret
    69b2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    69c0:	sub    rsp,0x8
    69c4:	stmxcsr DWORD PTR [rsp+0x124]
    69cc:	ldmxcsr DWORD PTR [rsp+0x120]
    69d4:	mov    r11d,DWORD PTR [rsp+0x124]
    69dc:	shr    r11d,1
    69df:	and    r11d,0x10
    69e3:	or     DWORD PTR [r12+0x314],r11d
    69eb:	mov    QWORD PTR [r12+0x378],0x3
    69f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    69fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6a03:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6a09:	push   rdx
    6a0a:	push   rsi
    6a0b:	push   r10
    6a0d:	push   r11
    6a0f:	mov    rdx,QWORD PTR [rsp+0x30]
    6a14:	mov    r10d,edx
    6a17:	and    r10d,0xc0
    6a1e:	shl    r10d,0x18
    6a22:	mov    r11d,edx
    6a25:	and    r11d,0x1
    6a29:	shl    r11d,0x1d
    6a2d:	or     r10d,r11d
    6a30:	mov    r11d,edx
    6a33:	and    r11d,0x800
    6a3a:	shl    r11d,0x11
    6a3e:	or     r10d,r11d
    6a41:	btc    r10,0x1d
    6a46:	mov    r11d,0xf0000000
    6a4c:	and    r11,r10
    6a4f:	movabs rsi,0xffffffff0fffffff
    6a59:	and    rbx,rsi
    6a5c:	or     rbx,r11
    6a5f:	pop    r11
    6a61:	pop    r10
    6a63:	pop    rsi
    6a64:	pop    rdx
    6a65:	mov    QWORD PTR [r12+0x108],rbx
    6a6d:	stmxcsr DWORD PTR [r12-0x28]
    6a73:	ldmxcsr DWORD PTR [r12-0x38]
    6a79:	lea    rdi,[rsp+0x110]
    6a81:	lea    rsi,[rsp+0xf0]
    6a89:	lea    rdx,[rsp+0x100]
    6a91:	mov    ecx,0x14
    6a96:	mov    r8d,0x0
    6a9c:	lea    r9,[r12+0x314]
    6aa4:	movabs r11,0x57780bb291b0
    6aae:	call   r11
    6ab1:	ldmxcsr DWORD PTR [r12-0x28]
    6ab7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6abd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6ac3:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6ac9:	mov    rbx,QWORD PTR [r12+0x108]
    6ad1:	mov    QWORD PTR [r12+0x378],0x2
    6add:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6ae6:	pushf
    6ae7:	pop    rdx
    6ae8:	and    rdx,0xfffffffffffff73e
    6aef:	mov    rax,rbx
    6af2:	shr    rax,0x18
    6af6:	and    eax,0xc0
    6afb:	or     rdx,rax
    6afe:	mov    rax,rbx
    6b01:	shr    rax,0x1d
    6b05:	and    eax,0x1
    6b08:	xor    eax,0x1
    6b0b:	or     rdx,rax
    6b0e:	mov    rax,rbx
    6b11:	shr    rax,0x11
    6b15:	and    eax,0x800
    6b1a:	or     rdx,rax
    6b1d:	mov    QWORD PTR [rsp+0x10],rdx
    6b22:	stmxcsr DWORD PTR [rsp+0x120]
    6b2a:	mov    DWORD PTR [rsp+0x124],0x1f80
    6b35:	ldmxcsr DWORD PTR [rsp+0x124]
    6b3d:	add    rsp,0x8
    6b41:	ret
    6b42:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    6b50:	sub    rsp,0x8
    6b54:	stmxcsr DWORD PTR [rsp+0x124]
    6b5c:	ldmxcsr DWORD PTR [rsp+0x120]
    6b64:	mov    r11d,DWORD PTR [rsp+0x124]
    6b6c:	shr    r11d,1
    6b6f:	and    r11d,0x10
    6b73:	or     DWORD PTR [r12+0x314],r11d
    6b7b:	mov    QWORD PTR [r12+0x378],0x3
    6b87:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6b8d:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6b93:	push   rdx
    6b94:	push   rsi
    6b95:	push   r10
    6b97:	push   r11
    6b99:	mov    rdx,QWORD PTR [rsp+0x30]
    6b9e:	mov    r10d,edx
    6ba1:	and    r10d,0xc0
    6ba8:	shl    r10d,0x18
    6bac:	mov    r11d,edx
    6baf:	and    r11d,0x1
    6bb3:	shl    r11d,0x1d
    6bb7:	or     r10d,r11d
    6bba:	mov    r11d,edx
    6bbd:	and    r11d,0x800
    6bc4:	shl    r11d,0x11
    6bc8:	or     r10d,r11d
    6bcb:	btc    r10,0x1d
    6bd0:	mov    r11d,0xf0000000
    6bd6:	and    r11,r10
    6bd9:	movabs rsi,0xffffffff0fffffff
    6be3:	and    rbx,rsi
    6be6:	or     rbx,r11
    6be9:	pop    r11
    6beb:	pop    r10
    6bed:	pop    rsi
    6bee:	pop    rdx
    6bef:	mov    QWORD PTR [r12+0x108],rbx
    6bf7:	stmxcsr DWORD PTR [r12-0x28]
    6bfd:	ldmxcsr DWORD PTR [r12-0x38]
    6c03:	lea    rdi,[rsp+0x110]
    6c0b:	lea    rsi,[rsp+0xf0]
    6c13:	lea    rdx,[rsp+0x100]
    6c1b:	mov    ecx,0x14
    6c20:	mov    r8d,0x0
    6c26:	lea    r9,[r12+0x314]
    6c2e:	movabs r11,0x57780bb291b0
    6c38:	call   r11
    6c3b:	ldmxcsr DWORD PTR [r12-0x28]
    6c41:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6c47:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6c4d:	mov    rbx,QWORD PTR [r12+0x108]
    6c55:	mov    QWORD PTR [r12+0x378],0x2
    6c61:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6c6a:	pushf
    6c6b:	pop    rdx
    6c6c:	and    rdx,0xfffffffffffff73e
    6c73:	mov    rax,rbx
    6c76:	shr    rax,0x18
    6c7a:	and    eax,0xc0
    6c7f:	or     rdx,rax
    6c82:	mov    rax,rbx
    6c85:	shr    rax,0x1d
    6c89:	and    eax,0x1
    6c8c:	xor    eax,0x1
    6c8f:	or     rdx,rax
    6c92:	mov    rax,rbx
    6c95:	shr    rax,0x11
    6c99:	and    eax,0x800
    6c9e:	or     rdx,rax
    6ca1:	mov    QWORD PTR [rsp+0x10],rdx
    6ca6:	stmxcsr DWORD PTR [rsp+0x120]
    6cae:	mov    DWORD PTR [rsp+0x124],0x1f80
    6cb9:	ldmxcsr DWORD PTR [rsp+0x124]
    6cc1:	add    rsp,0x8
    6cc5:	ret
    6cc6:	data16 nop WORD PTR [rax+rax*1+0x0]
    6cd0:	sub    rsp,0x8
    6cd4:	stmxcsr DWORD PTR [rsp+0x124]
    6cdc:	ldmxcsr DWORD PTR [rsp+0x120]
    6ce4:	mov    r11d,DWORD PTR [rsp+0x124]
    6cec:	shr    r11d,1
    6cef:	and    r11d,0x10
    6cf3:	or     DWORD PTR [r12+0x314],r11d
    6cfb:	mov    QWORD PTR [r12+0x378],0x3
    6d07:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6d0d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6d13:	push   rdx
    6d14:	push   rsi
    6d15:	push   r10
    6d17:	push   r11
    6d19:	mov    rdx,QWORD PTR [rsp+0x30]
    6d1e:	mov    r10d,edx
    6d21:	and    r10d,0xc0
    6d28:	shl    r10d,0x18
    6d2c:	mov    r11d,edx
    6d2f:	and    r11d,0x1
    6d33:	shl    r11d,0x1d
    6d37:	or     r10d,r11d
    6d3a:	mov    r11d,edx
    6d3d:	and    r11d,0x800
    6d44:	shl    r11d,0x11
    6d48:	or     r10d,r11d
    6d4b:	btc    r10,0x1d
    6d50:	mov    r11d,0xf0000000
    6d56:	and    r11,r10
    6d59:	movabs rsi,0xffffffff0fffffff
    6d63:	and    rbx,rsi
    6d66:	or     rbx,r11
    6d69:	pop    r11
    6d6b:	pop    r10
    6d6d:	pop    rsi
    6d6e:	pop    rdx
    6d6f:	mov    QWORD PTR [r12+0x108],rbx
    6d77:	stmxcsr DWORD PTR [r12-0x28]
    6d7d:	ldmxcsr DWORD PTR [r12-0x38]
    6d83:	lea    rdi,[rsp+0x110]
    6d8b:	lea    rsi,[rsp+0xf0]
    6d93:	lea    rdx,[rsp+0x100]
    6d9b:	mov    ecx,0xc
    6da0:	mov    r8d,0x0
    6da6:	lea    r9,[r12+0x314]
    6dae:	movabs r11,0x57780bb291b0
    6db8:	call   r11
    6dbb:	ldmxcsr DWORD PTR [r12-0x28]
    6dc1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6dc7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6dcd:	mov    rbx,QWORD PTR [r12+0x108]
    6dd5:	mov    QWORD PTR [r12+0x378],0x2
    6de1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6dea:	pushf
    6deb:	pop    rdx
    6dec:	and    rdx,0xfffffffffffff73e
    6df3:	mov    rax,rbx
    6df6:	shr    rax,0x18
    6dfa:	and    eax,0xc0
    6dff:	or     rdx,rax
    6e02:	mov    rax,rbx
    6e05:	shr    rax,0x1d
    6e09:	and    eax,0x1
    6e0c:	xor    eax,0x1
    6e0f:	or     rdx,rax
    6e12:	mov    rax,rbx
    6e15:	shr    rax,0x11
    6e19:	and    eax,0x800
    6e1e:	or     rdx,rax
    6e21:	mov    QWORD PTR [rsp+0x10],rdx
    6e26:	stmxcsr DWORD PTR [rsp+0x120]
    6e2e:	mov    DWORD PTR [rsp+0x124],0x1f80
    6e39:	ldmxcsr DWORD PTR [rsp+0x124]
    6e41:	add    rsp,0x8
    6e45:	ret
    6e46:	data16 nop WORD PTR [rax+rax*1+0x0]
    6e50:	sub    rsp,0x8
    6e54:	stmxcsr DWORD PTR [rsp+0x124]
    6e5c:	ldmxcsr DWORD PTR [rsp+0x120]
    6e64:	mov    r11d,DWORD PTR [rsp+0x124]
    6e6c:	shr    r11d,1
    6e6f:	and    r11d,0x10
    6e73:	or     DWORD PTR [r12+0x314],r11d
    6e7b:	mov    QWORD PTR [r12+0x378],0x3
    6e87:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6e8d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6e93:	push   rdx
    6e94:	push   rsi
    6e95:	push   r10
    6e97:	push   r11
    6e99:	mov    rdx,QWORD PTR [rsp+0x30]
    6e9e:	mov    r10d,edx
    6ea1:	and    r10d,0xc0
    6ea8:	shl    r10d,0x18
    6eac:	mov    r11d,edx
    6eaf:	and    r11d,0x1
    6eb3:	shl    r11d,0x1d
    6eb7:	or     r10d,r11d
    6eba:	mov    r11d,edx
    6ebd:	and    r11d,0x800
    6ec4:	shl    r11d,0x11
    6ec8:	or     r10d,r11d
    6ecb:	btc    r10,0x1d
    6ed0:	mov    r11d,0xf0000000
    6ed6:	and    r11,r10
    6ed9:	movabs rsi,0xffffffff0fffffff
    6ee3:	and    rbx,rsi
    6ee6:	or     rbx,r11
    6ee9:	pop    r11
    6eeb:	pop    r10
    6eed:	pop    rsi
    6eee:	pop    rdx
    6eef:	mov    QWORD PTR [r12+0x108],rbx
    6ef7:	stmxcsr DWORD PTR [r12-0x28]
    6efd:	ldmxcsr DWORD PTR [r12-0x38]
    6f03:	lea    rdi,[rsp+0x110]
    6f0b:	lea    rsi,[rsp+0xf0]
    6f13:	lea    rdx,[rsp+0x100]
    6f1b:	mov    ecx,0xc
    6f20:	mov    r8d,0x0
    6f26:	lea    r9,[r12+0x314]
    6f2e:	movabs r11,0x57780bb291b0
    6f38:	call   r11
    6f3b:	ldmxcsr DWORD PTR [r12-0x28]
    6f41:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6f47:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6f4d:	mov    rbx,QWORD PTR [r12+0x108]
    6f55:	mov    QWORD PTR [r12+0x378],0x2
    6f61:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6f6a:	pushf
    6f6b:	pop    rdx
    6f6c:	and    rdx,0xfffffffffffff73e
    6f73:	mov    rax,rbx
    6f76:	shr    rax,0x18
    6f7a:	and    eax,0xc0
    6f7f:	or     rdx,rax
    6f82:	mov    rax,rbx
    6f85:	shr    rax,0x1d
    6f89:	and    eax,0x1
    6f8c:	xor    eax,0x1
    6f8f:	or     rdx,rax
    6f92:	mov    rax,rbx
    6f95:	shr    rax,0x11
    6f99:	and    eax,0x800
    6f9e:	or     rdx,rax
    6fa1:	mov    QWORD PTR [rsp+0x10],rdx
    6fa6:	stmxcsr DWORD PTR [rsp+0x120]
    6fae:	mov    DWORD PTR [rsp+0x124],0x1f80
    6fb9:	ldmxcsr DWORD PTR [rsp+0x124]
    6fc1:	add    rsp,0x8
    6fc5:	ret
    6fc6:	mov    eax,0x410400
    6fcb:	mov    QWORD PTR [r12+0x100],rax
    6fd3:	push   rdx
    6fd4:	push   rsi
    6fd5:	push   r10
    6fd7:	push   r11
    6fd9:	pushf
    6fda:	pop    r11
    6fdc:	mov    QWORD PTR [rsp+0x20],r11
    6fe1:	mov    rdx,QWORD PTR [rsp+0x20]
    6fe6:	mov    r10d,edx
    6fe9:	and    r10d,0xc0
    6ff0:	shl    r10d,0x18
    6ff4:	mov    r11d,edx
    6ff7:	and    r11d,0x1
    6ffb:	shl    r11d,0x1d
    6fff:	or     r10d,r11d
    7002:	mov    r11d,edx
    7005:	and    r11d,0x800
    700c:	shl    r11d,0x11
    7010:	or     r10d,r11d
    7013:	btc    r10,0x1d
    7018:	mov    r11d,0xf0000000
    701e:	and    r11,r10
    7021:	movabs rsi,0xffffffff0fffffff
    702b:	and    rbx,rsi
    702e:	or     rbx,r11
    7031:	pop    r11
    7033:	pop    r10
    7035:	pop    rsi
    7036:	pop    rdx
    7037:	mov    QWORD PTR [r12+0x108],rbx
    703f:	add    rsp,0x150
    7046:	mov    eax,0xc
    704b:	movabs r11,0x57780bcbe390
    7055:	jmp    r11
    7058:	mov    eax,0x41048c
    705d:	mov    QWORD PTR [r12+0x100],rax
    7065:	push   rdx
    7066:	push   rsi
    7067:	push   r10
    7069:	push   r11
    706b:	pushf
    706c:	pop    r11
    706e:	mov    QWORD PTR [rsp+0x20],r11
    7073:	mov    rdx,QWORD PTR [rsp+0x20]
    7078:	mov    r10d,edx
    707b:	and    r10d,0xc0
    7082:	shl    r10d,0x18
    7086:	mov    r11d,edx
    7089:	and    r11d,0x1
    708d:	shl    r11d,0x1d
    7091:	or     r10d,r11d
    7094:	mov    r11d,edx
    7097:	and    r11d,0x800
    709e:	shl    r11d,0x11
    70a2:	or     r10d,r11d
    70a5:	btc    r10,0x1d
    70aa:	mov    r11d,0xf0000000
    70b0:	and    r11,r10
    70b3:	movabs rsi,0xffffffff0fffffff
    70bd:	and    rbx,rsi
    70c0:	or     rbx,r11
    70c3:	pop    r11
    70c5:	pop    r10
    70c7:	pop    rsi
    70c8:	pop    rdx
    70c9:	mov    QWORD PTR [r12+0x108],rbx
    70d1:	add    rsp,0x150
    70d8:	mov    eax,0xc
    70dd:	movabs r11,0x57780bcbe390
    70e7:	jmp    r11
    70ea:	mov    eax,0x4106cc
    70ef:	mov    QWORD PTR [r12+0x100],rax
    70f7:	push   rdx
    70f8:	push   rsi
    70f9:	push   r10
    70fb:	push   r11
    70fd:	mov    rdx,QWORD PTR [rsp+0x20]
    7102:	mov    r10d,edx
    7105:	and    r10d,0xc0
    710c:	shl    r10d,0x18
    7110:	mov    r11d,edx
    7113:	and    r11d,0x1
    7117:	shl    r11d,0x1d
    711b:	or     r10d,r11d
    711e:	mov    r11d,edx
    7121:	and    r11d,0x800
    7128:	shl    r11d,0x11
    712c:	or     r10d,r11d
    712f:	btc    r10,0x1d
    7134:	mov    r11d,0xf0000000
    713a:	and    r11,r10
    713d:	movabs rsi,0xffffffff0fffffff
    7147:	and    rbx,rsi
    714a:	or     rbx,r11
    714d:	pop    r11
    714f:	pop    r10
    7151:	pop    rsi
    7152:	pop    rdx
    7153:	mov    QWORD PTR [r12+0x108],rbx
    715b:	add    rsp,0x150
    7162:	mov    eax,0xc
    7167:	movabs r11,0x57780bcbe390
    7171:	jmp    r11
    7174:	mov    eax,0x4106d8
    7179:	mov    QWORD PTR [r12+0x100],rax
    7181:	push   rdx
    7182:	push   rsi
    7183:	push   r10
    7185:	push   r11
    7187:	pushf
    7188:	pop    r11
    718a:	mov    QWORD PTR [rsp+0x20],r11
    718f:	mov    rdx,QWORD PTR [rsp+0x20]
    7194:	mov    r10d,edx
    7197:	and    r10d,0xc0
    719e:	shl    r10d,0x18
    71a2:	mov    r11d,edx
    71a5:	and    r11d,0x1
    71a9:	shl    r11d,0x1d
    71ad:	or     r10d,r11d
    71b0:	mov    r11d,edx
    71b3:	and    r11d,0x800
    71ba:	shl    r11d,0x11
    71be:	or     r10d,r11d
    71c1:	btc    r10,0x1d
    71c6:	mov    r11d,0xf0000000
    71cc:	and    r11,r10
    71cf:	movabs rsi,0xffffffff0fffffff
    71d9:	and    rbx,rsi
    71dc:	or     rbx,r11
    71df:	pop    r11
    71e1:	pop    r10
    71e3:	pop    rsi
    71e4:	pop    rdx
    71e5:	mov    QWORD PTR [r12+0x108],rbx
    71ed:	add    rsp,0x150
    71f4:	mov    eax,0xc
    71f9:	movabs r11,0x57780bcbe390
    7203:	jmp    r11
    7206:	mov    eax,0x410700
    720b:	mov    QWORD PTR [r12+0x100],rax
    7213:	push   rdx
    7214:	push   rsi
    7215:	push   r10
    7217:	push   r11
    7219:	mov    rdx,QWORD PTR [rsp+0x20]
    721e:	mov    r10d,edx
    7221:	and    r10d,0xc0
    7228:	shl    r10d,0x18
    722c:	mov    r11d,edx
    722f:	and    r11d,0x1
    7233:	shl    r11d,0x1d
    7237:	or     r10d,r11d
    723a:	mov    r11d,edx
    723d:	and    r11d,0x800
    7244:	shl    r11d,0x11
    7248:	or     r10d,r11d
    724b:	btc    r10,0x1d
    7250:	mov    r11d,0xf0000000
    7256:	and    r11,r10
    7259:	movabs rsi,0xffffffff0fffffff
    7263:	and    rbx,rsi
    7266:	or     rbx,r11
    7269:	pop    r11
    726b:	pop    r10
    726d:	pop    rsi
    726e:	pop    rdx
    726f:	mov    QWORD PTR [r12+0x108],rbx
    7277:	add    rsp,0x150
    727e:	mov    eax,0xc
    7283:	movabs r11,0x57780bcbe390
    728d:	jmp    r11
    7290:	mov    eax,0x410724
    7295:	mov    QWORD PTR [r12+0x100],rax
    729d:	push   rdx
    729e:	push   rsi
    729f:	push   r10
    72a1:	push   r11
    72a3:	mov    rdx,QWORD PTR [rsp+0x20]
    72a8:	mov    r10d,edx
    72ab:	and    r10d,0xc0
    72b2:	shl    r10d,0x18
    72b6:	mov    r11d,edx
    72b9:	and    r11d,0x1
    72bd:	shl    r11d,0x1d
    72c1:	or     r10d,r11d
    72c4:	mov    r11d,edx
    72c7:	and    r11d,0x800
    72ce:	shl    r11d,0x11
    72d2:	or     r10d,r11d
    72d5:	btc    r10,0x1d
    72da:	mov    r11d,0xf0000000
    72e0:	and    r11,r10
    72e3:	movabs rsi,0xffffffff0fffffff
    72ed:	and    rbx,rsi
    72f0:	or     rbx,r11
    72f3:	pop    r11
    72f5:	pop    r10
    72f7:	pop    rsi
    72f8:	pop    rdx
    72f9:	mov    QWORD PTR [r12+0x108],rbx
    7301:	add    rsp,0x150
    7308:	mov    eax,0xc
    730d:	movabs r11,0x57780bcbe390
    7317:	jmp    r11
    731a:	nop    WORD PTR [rax+rax*1+0x0]
    7320:	sub    rsp,0x150
    7327:	mov    r11,QWORD PTR [r12+0x398]
    732f:	mov    QWORD PTR [rsp],r11
    7333:	cmp    DWORD PTR [r12+0x310],0x0
    733c:	je     0x73cc
    7342:	push   rdx
    7343:	push   rsi
    7344:	push   r10
    7346:	push   r11
    7348:	mov    rdx,QWORD PTR [rsp+0x20]
    734d:	mov    r10d,edx
    7350:	and    r10d,0xc0
    7357:	shl    r10d,0x18
    735b:	mov    r11d,edx
    735e:	and    r11d,0x1
    7362:	shl    r11d,0x1d
    7366:	or     r10d,r11d
    7369:	mov    r11d,edx
    736c:	and    r11d,0x800
    7373:	shl    r11d,0x11
    7377:	or     r10d,r11d
    737a:	btc    r10,0x1d
    737f:	mov    r11d,0xf0000000
    7385:	and    r11,r10
    7388:	movabs rsi,0xffffffff0fffffff
    7392:	and    rbx,rsi
    7395:	or     rbx,r11
    7398:	pop    r11
    739a:	pop    r10
    739c:	pop    rsi
    739d:	pop    rdx
    739e:	mov    QWORD PTR [r12+0x108],rbx
    73a6:	mov    eax,0x410404
    73ab:	mov    QWORD PTR [r12+0x100],rax
    73b3:	add    rsp,0x150
    73ba:	mov    eax,0x3
    73bf:	movabs r11,0x57780bcbe390
    73c9:	jmp    r11
    73cc:	jmp    0xe8
    73d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    73e0:	sub    rsp,0x150
    73e7:	mov    r11,QWORD PTR [r12+0x398]
    73ef:	mov    QWORD PTR [rsp],r11
    73f3:	cmp    DWORD PTR [r12+0x310],0x0
    73fc:	je     0x748c
    7402:	push   rdx
    7403:	push   rsi
    7404:	push   r10
    7406:	push   r11
    7408:	mov    rdx,QWORD PTR [rsp+0x20]
    740d:	mov    r10d,edx
    7410:	and    r10d,0xc0
    7417:	shl    r10d,0x18
    741b:	mov    r11d,edx
    741e:	and    r11d,0x1
    7422:	shl    r11d,0x1d
    7426:	or     r10d,r11d
    7429:	mov    r11d,edx
    742c:	and    r11d,0x800
    7433:	shl    r11d,0x11
    7437:	or     r10d,r11d
    743a:	btc    r10,0x1d
    743f:	mov    r11d,0xf0000000
    7445:	and    r11,r10
    7448:	movabs rsi,0xffffffff0fffffff
    7452:	and    rbx,rsi
    7455:	or     rbx,r11
    7458:	pop    r11
    745a:	pop    r10
    745c:	pop    rsi
    745d:	pop    rdx
    745e:	mov    QWORD PTR [r12+0x108],rbx
    7466:	mov    eax,0x410450
    746b:	mov    QWORD PTR [r12+0x100],rax
    7473:	add    rsp,0x150
    747a:	mov    eax,0x3
    747f:	movabs r11,0x57780bcbe390
    7489:	jmp    r11
    748c:	jmp    0x252
    7491:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a0:	sub    rsp,0x150
    74a7:	mov    r11,QWORD PTR [r12+0x398]
    74af:	mov    QWORD PTR [rsp],r11
    74b3:	cmp    DWORD PTR [r12+0x310],0x0
    74bc:	je     0x754c
    74c2:	push   rdx
    74c3:	push   rsi
    74c4:	push   r10
    74c6:	push   r11
    74c8:	mov    rdx,QWORD PTR [rsp+0x20]
    74cd:	mov    r10d,edx
    74d0:	and    r10d,0xc0
    74d7:	shl    r10d,0x18
    74db:	mov    r11d,edx
    74de:	and    r11d,0x1
    74e2:	shl    r11d,0x1d
    74e6:	or     r10d,r11d
    74e9:	mov    r11d,edx
    74ec:	and    r11d,0x800
    74f3:	shl    r11d,0x11
    74f7:	or     r10d,r11d
    74fa:	btc    r10,0x1d
    74ff:	mov    r11d,0xf0000000
    7505:	and    r11,r10
    7508:	movabs rsi,0xffffffff0fffffff
    7512:	and    rbx,rsi
    7515:	or     rbx,r11
    7518:	pop    r11
    751a:	pop    r10
    751c:	pop    rsi
    751d:	pop    rdx
    751e:	mov    QWORD PTR [r12+0x108],rbx
    7526:	mov    eax,0x410490
    752b:	mov    QWORD PTR [r12+0x100],rax
    7533:	add    rsp,0x150
    753a:	mov    eax,0x3
    753f:	movabs r11,0x57780bcbe390
    7549:	jmp    r11
    754c:	jmp    0x7c8
    7551:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7560:	sub    rsp,0x150
    7567:	mov    r11,QWORD PTR [r12+0x398]
    756f:	mov    QWORD PTR [rsp],r11
    7573:	cmp    DWORD PTR [r12+0x310],0x0
    757c:	je     0x760c
    7582:	push   rdx
    7583:	push   rsi
    7584:	push   r10
    7586:	push   r11
    7588:	mov    rdx,QWORD PTR [rsp+0x20]
    758d:	mov    r10d,edx
    7590:	and    r10d,0xc0
    7597:	shl    r10d,0x18
    759b:	mov    r11d,edx
    759e:	and    r11d,0x1
    75a2:	shl    r11d,0x1d
    75a6:	or     r10d,r11d
    75a9:	mov    r11d,edx
    75ac:	and    r11d,0x800
    75b3:	shl    r11d,0x11
    75b7:	or     r10d,r11d
    75ba:	btc    r10,0x1d
    75bf:	mov    r11d,0xf0000000
    75c5:	and    r11,r10
    75c8:	movabs rsi,0xffffffff0fffffff
    75d2:	and    rbx,rsi
    75d5:	or     rbx,r11
    75d8:	pop    r11
    75da:	pop    r10
    75dc:	pop    rsi
    75dd:	pop    rdx
    75de:	mov    QWORD PTR [r12+0x108],rbx
    75e6:	mov    eax,0x410500
    75eb:	mov    QWORD PTR [r12+0x100],rax
    75f3:	add    rsp,0x150
    75fa:	mov    eax,0x3
    75ff:	movabs r11,0x57780bcbe390
    7609:	jmp    r11
    760c:	jmp    0xe08
    7611:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7620:	sub    rsp,0x150
    7627:	mov    r11,QWORD PTR [r12+0x398]
    762f:	mov    QWORD PTR [rsp],r11
    7633:	cmp    DWORD PTR [r12+0x310],0x0
    763c:	je     0x76cc
    7642:	push   rdx
    7643:	push   rsi
    7644:	push   r10
    7646:	push   r11
    7648:	mov    rdx,QWORD PTR [rsp+0x20]
    764d:	mov    r10d,edx
    7650:	and    r10d,0xc0
    7657:	shl    r10d,0x18
    765b:	mov    r11d,edx
    765e:	and    r11d,0x1
    7662:	shl    r11d,0x1d
    7666:	or     r10d,r11d
    7669:	mov    r11d,edx
    766c:	and    r11d,0x800
    7673:	shl    r11d,0x11
    7677:	or     r10d,r11d
    767a:	btc    r10,0x1d
    767f:	mov    r11d,0xf0000000
    7685:	and    r11,r10
    7688:	movabs rsi,0xffffffff0fffffff
    7692:	and    rbx,rsi
    7695:	or     rbx,r11
    7698:	pop    r11
    769a:	pop    r10
    769c:	pop    rsi
    769d:	pop    rdx
    769e:	mov    QWORD PTR [r12+0x108],rbx
    76a6:	mov    eax,0x410504
    76ab:	mov    QWORD PTR [r12+0x100],rax
    76b3:	add    rsp,0x150
    76ba:	mov    eax,0x3
    76bf:	movabs r11,0x57780bcbe390
    76c9:	jmp    r11
    76cc:	jmp    0xe18
    76d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76e0:	sub    rsp,0x150
    76e7:	mov    r11,QWORD PTR [r12+0x398]
    76ef:	mov    QWORD PTR [rsp],r11
    76f3:	cmp    DWORD PTR [r12+0x310],0x0
    76fc:	je     0x778c
    7702:	push   rdx
    7703:	push   rsi
    7704:	push   r10
    7706:	push   r11
    7708:	mov    rdx,QWORD PTR [rsp+0x20]
    770d:	mov    r10d,edx
    7710:	and    r10d,0xc0
    7717:	shl    r10d,0x18
    771b:	mov    r11d,edx
    771e:	and    r11d,0x1
    7722:	shl    r11d,0x1d
    7726:	or     r10d,r11d
    7729:	mov    r11d,edx
    772c:	and    r11d,0x800
    7733:	shl    r11d,0x11
    7737:	or     r10d,r11d
    773a:	btc    r10,0x1d
    773f:	mov    r11d,0xf0000000
    7745:	and    r11,r10
    7748:	movabs rsi,0xffffffff0fffffff
    7752:	and    rbx,rsi
    7755:	or     rbx,r11
    7758:	pop    r11
    775a:	pop    r10
    775c:	pop    rsi
    775d:	pop    rdx
    775e:	mov    QWORD PTR [r12+0x108],rbx
    7766:	mov    eax,0x4106d0
    776b:	mov    QWORD PTR [r12+0x100],rax
    7773:	add    rsp,0x150
    777a:	mov    eax,0x3
    777f:	movabs r11,0x57780bcbe390
    7789:	jmp    r11
    778c:	jmp    0x49dd
    7791:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77a0:	sub    rsp,0x150
    77a7:	mov    r11,QWORD PTR [r12+0x398]
    77af:	mov    QWORD PTR [rsp],r11
    77b3:	cmp    DWORD PTR [r12+0x310],0x0
    77bc:	je     0x784c
    77c2:	push   rdx
    77c3:	push   rsi
    77c4:	push   r10
    77c6:	push   r11
    77c8:	mov    rdx,QWORD PTR [rsp+0x20]
    77cd:	mov    r10d,edx
    77d0:	and    r10d,0xc0
    77d7:	shl    r10d,0x18
    77db:	mov    r11d,edx
    77de:	and    r11d,0x1
    77e2:	shl    r11d,0x1d
    77e6:	or     r10d,r11d
    77e9:	mov    r11d,edx
    77ec:	and    r11d,0x800
    77f3:	shl    r11d,0x11
    77f7:	or     r10d,r11d
    77fa:	btc    r10,0x1d
    77ff:	mov    r11d,0xf0000000
    7805:	and    r11,r10
    7808:	movabs rsi,0xffffffff0fffffff
    7812:	and    rbx,rsi
    7815:	or     rbx,r11
    7818:	pop    r11
    781a:	pop    r10
    781c:	pop    rsi
    781d:	pop    rdx
    781e:	mov    QWORD PTR [r12+0x108],rbx
    7826:	mov    eax,0x4106dc
    782b:	mov    QWORD PTR [r12+0x100],rax
    7833:	add    rsp,0x150
    783a:	mov    eax,0x3
    783f:	movabs r11,0x57780bcbe390
    7849:	jmp    r11
    784c:	jmp    0x4a13
    7851:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7860:	sub    rsp,0x150
    7867:	mov    r11,QWORD PTR [r12+0x398]
    786f:	mov    QWORD PTR [rsp],r11
    7873:	cmp    DWORD PTR [r12+0x310],0x0
    787c:	je     0x790c
    7882:	push   rdx
    7883:	push   rsi
    7884:	push   r10
    7886:	push   r11
    7888:	mov    rdx,QWORD PTR [rsp+0x20]
    788d:	mov    r10d,edx
    7890:	and    r10d,0xc0
    7897:	shl    r10d,0x18
    789b:	mov    r11d,edx
    789e:	and    r11d,0x1
    78a2:	shl    r11d,0x1d
    78a6:	or     r10d,r11d
    78a9:	mov    r11d,edx
    78ac:	and    r11d,0x800
    78b3:	shl    r11d,0x11
    78b7:	or     r10d,r11d
    78ba:	btc    r10,0x1d
    78bf:	mov    r11d,0xf0000000
    78c5:	and    r11,r10
    78c8:	movabs rsi,0xffffffff0fffffff
    78d2:	and    rbx,rsi
    78d5:	or     rbx,r11
    78d8:	pop    r11
    78da:	pop    r10
    78dc:	pop    rsi
    78dd:	pop    rdx
    78de:	mov    QWORD PTR [r12+0x108],rbx
    78e6:	mov    eax,0x4106e8
    78eb:	mov    QWORD PTR [r12+0x100],rax
    78f3:	add    rsp,0x150
    78fa:	mov    eax,0x3
    78ff:	movabs r11,0x57780bcbe390
    7909:	jmp    r11
    790c:	jmp    0x4a4e
    7911:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7920:	sub    rsp,0x150
    7927:	mov    r11,QWORD PTR [r12+0x398]
    792f:	mov    QWORD PTR [rsp],r11
    7933:	cmp    DWORD PTR [r12+0x310],0x0
    793c:	je     0x79cc
    7942:	push   rdx
    7943:	push   rsi
    7944:	push   r10
    7946:	push   r11
    7948:	mov    rdx,QWORD PTR [rsp+0x20]
    794d:	mov    r10d,edx
    7950:	and    r10d,0xc0
    7957:	shl    r10d,0x18
    795b:	mov    r11d,edx
    795e:	and    r11d,0x1
    7962:	shl    r11d,0x1d
    7966:	or     r10d,r11d
    7969:	mov    r11d,edx
    796c:	and    r11d,0x800
    7973:	shl    r11d,0x11
    7977:	or     r10d,r11d
    797a:	btc    r10,0x1d
    797f:	mov    r11d,0xf0000000
    7985:	and    r11,r10
    7988:	movabs rsi,0xffffffff0fffffff
    7992:	and    rbx,rsi
    7995:	or     rbx,r11
    7998:	pop    r11
    799a:	pop    r10
    799c:	pop    rsi
    799d:	pop    rdx
    799e:	mov    QWORD PTR [r12+0x108],rbx
    79a6:	mov    eax,0x410704
    79ab:	mov    QWORD PTR [r12+0x100],rax
    79b3:	add    rsp,0x150
    79ba:	mov    eax,0x3
    79bf:	movabs r11,0x57780bcbe390
    79c9:	jmp    r11
    79cc:	jmp    0x4be6
    79d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    79e0:	sub    rsp,0x150
    79e7:	mov    r11,QWORD PTR [r12+0x398]
    79ef:	mov    QWORD PTR [rsp],r11
    79f3:	cmp    DWORD PTR [r12+0x310],0x0
    79fc:	je     0x7a8c
    7a02:	push   rdx
    7a03:	push   rsi
    7a04:	push   r10
    7a06:	push   r11
    7a08:	mov    rdx,QWORD PTR [rsp+0x20]
    7a0d:	mov    r10d,edx
    7a10:	and    r10d,0xc0
    7a17:	shl    r10d,0x18
    7a1b:	mov    r11d,edx
    7a1e:	and    r11d,0x1
    7a22:	shl    r11d,0x1d
    7a26:	or     r10d,r11d
    7a29:	mov    r11d,edx
    7a2c:	and    r11d,0x800
    7a33:	shl    r11d,0x11
    7a37:	or     r10d,r11d
    7a3a:	btc    r10,0x1d
    7a3f:	mov    r11d,0xf0000000
    7a45:	and    r11,r10
    7a48:	movabs rsi,0xffffffff0fffffff
    7a52:	and    rbx,rsi
    7a55:	or     rbx,r11
    7a58:	pop    r11
    7a5a:	pop    r10
    7a5c:	pop    rsi
    7a5d:	pop    rdx
    7a5e:	mov    QWORD PTR [r12+0x108],rbx
    7a66:	mov    eax,0x4103f0
    7a6b:	mov    QWORD PTR [r12+0x100],rax
    7a73:	add    rsp,0x150
    7a7a:	mov    eax,0x3
    7a7f:	movabs r11,0x57780bcbe390
    7a89:	jmp    r11
    7a8c:	jmp    0x4dcf
    7a91:	nop
    7a92:	nop
    7a93:	nop
