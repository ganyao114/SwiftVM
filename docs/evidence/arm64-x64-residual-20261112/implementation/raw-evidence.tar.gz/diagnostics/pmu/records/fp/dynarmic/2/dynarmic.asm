00007debd2dce69b  nop [rax+rax*1], eax
00007debd2dce6a0  mov qword ptr [r15+0x20], 0x420060
00007debd2dce6a8  mov qword ptr [r15], 0x00
00007debd2dce6af  vmovaps xmm1, [0x00007DEBD29FE010]
00007debd2dce6b7  movq xmm1, xmm1
00007debd2dce6bb  vmovaps xmm15, [0x00007DEBD29FE020]
00007debd2dce6c3  movq xmm15, xmm15
00007debd2dce6c8  movaps [r15+0x120], xmm15
00007debd2dce6d0  movq rax, xmm1
00007debd2dce6d5  movq r14, xmm15
00007debd2dce6da  vmovq xmm1, rax
00007debd2dce6df  vmovq xmm15, r14
00007debd2dce6e4  movaps xmm14, xmm1
00007debd2dce6e8  addsd xmm14, xmm15
00007debd2dce6ed  ucomisd xmm14, xmm14
00007debd2dce6f2  jp 0x00007DEBD2DCE791
00007debd2dce6f8  movq xmm14, xmm14
00007debd2dce6fd  movaps [r15+0x110], xmm14
00007debd2dce705  xor eax, eax
00007debd2dce707  mov r14d, 0xF4240
00007debd2dce70d  mov r12d, 0x01
00007debd2dce713  sub r14, r12
00007debd2dce716  cmc
00007debd2dce717  lahf
00007debd2dce718  seto al
00007debd2dce71b  mov [r15+0x108], eax
00007debd2dce722  mov [r15+0x08], r14
00007debd2dce726  mov eax, [r15+0x108]
00007debd2dce72d  sahf
00007debd2dce72e  jnz 0x00007DEBD2DCE760
00007debd2dce730  cmp dword ptr [r15+0x318], 0x00
00007debd2dce738  jz 0x00007DEBD2DCE910
00007debd2dce73e  nop [rax+rax*1], ax
00007debd2dce747  nop [rax+rax*1], eax
00007debd2dce74f  mov eax, 0x410050
00007debd2dce754  mov [r15+0x100], rax
00007debd2dce75b  jmp 0x00007DEBD2BFE110
00007debd2dce760  cmp dword ptr [r15+0x318], 0x00
00007debd2dce768  jz 0x00007DEBD2DCE7E0
00007debd2dce76e  nop [rax+rax*1], ax
00007debd2dce777  nop [rax+rax*1], eax
00007debd2dce77f  mov eax, 0x410044
00007debd2dce784  mov [r15+0x100], rax
00007debd2dce78b  jmp 0x00007DEBD2BFE110
00007debd2dce790  int3
00007debd2dce791  ucomisd xmm1, xmm15
00007debd2dce796  jp 0x00007DEBD2DCE7A5
00007debd2dce798  movaps xmm14, [0x00007DEBD29FE030]
00007debd2dce7a0  jmp 0x00007DEBD2DCE6F8
00007debd2dce7a5  vxorps xmm0, xmm1, xmm15
00007debd2dce7aa  pextrw eax, xmm0, 0x03
00007debd2dce7af  and eax, 0x7FF8
00007debd2dce7b4  cmp eax, 0x08
00007debd2dce7b7  jnz 0x00007DEBD2DCE6F8
00007debd2dce7bd  movq rax, xmm15
00007debd2dce7c2  shl rax, 0x0D
00007debd2dce7c6  jbe 0x00007DEBD2DCE6F8
00007debd2dce7cc  vorps xmm14, xmm15, [0x00007DEBD29FE040]
00007debd2dce7d4  jmp 0x00007DEBD2DCE6F8
00007debd2dce7d9  int3
00007debd2dce7da  nop [rax+rax*1], ax
00007debd2dce7e0  movaps xmm1, [r15+0x110]
00007debd2dce7e8  movq rax, xmm1
00007debd2dce7ed  movaps xmm1, [r15+0x120]
00007debd2dce7f5  movq r14, xmm1
00007debd2dce7fa  vmovq xmm1, rax
00007debd2dce7ff  vmovq xmm15, r14
00007debd2dce804  movaps xmm14, xmm1
00007debd2dce808  addsd xmm14, xmm15
00007debd2dce80d  ucomisd xmm14, xmm14
00007debd2dce812  jp 0x00007DEBD2DCE8B9
00007debd2dce818  movq xmm14, xmm14
00007debd2dce81d  movaps [r15+0x110], xmm14
00007debd2dce825  mov rax, [r15+0x08]
00007debd2dce829  mov [rsp+0x10], rax
00007debd2dce82e  xor eax, eax
00007debd2dce830  mov r14, [rsp+0x10]
00007debd2dce835  mov r12d, 0x01
00007debd2dce83b  sub r14, r12
00007debd2dce83e  cmc
00007debd2dce83f  lahf
00007debd2dce840  seto al
00007debd2dce843  mov [r15+0x108], eax
00007debd2dce84a  mov [r15+0x08], r14
00007debd2dce84e  mov eax, [r15+0x108]
00007debd2dce855  sahf
00007debd2dce856  jnz 0x00007DEBD2DCE888
00007debd2dce858  cmp dword ptr [r15+0x318], 0x00
00007debd2dce860  jz 0x00007DEBD2DCE910
00007debd2dce866  nop [rax+rax*1], ax
00007debd2dce86f  nop [rax+rax*1], eax
00007debd2dce877  mov eax, 0x410050
00007debd2dce87c  mov [r15+0x100], rax
00007debd2dce883  jmp 0x00007DEBD2BFE110
00007debd2dce888  cmp dword ptr [r15+0x318], 0x00
00007debd2dce890  jz 0x00007DEBD2DCE7E0
00007debd2dce896  nop [rax+rax*1], ax
00007debd2dce89f  nop [rax+rax*1], eax
00007debd2dce8a7  mov eax, 0x410044
00007debd2dce8ac  mov [r15+0x100], rax
00007debd2dce8b3  jmp 0x00007DEBD2BFE110
00007debd2dce8b8  int3
00007debd2dce8b9  ucomisd xmm1, xmm15
00007debd2dce8be  jp 0x00007DEBD2DCE8CD
00007debd2dce8c0  movaps xmm14, [0x00007DEBD29FE030]
00007debd2dce8c8  jmp 0x00007DEBD2DCE818
00007debd2dce8cd  vxorps xmm0, xmm1, xmm15
00007debd2dce8d2  pextrw eax, xmm0, 0x03
00007debd2dce8d7  and eax, 0x7FF8
00007debd2dce8dc  cmp eax, 0x08
00007debd2dce8df  jnz 0x00007DEBD2DCE818
00007debd2dce8e5  movq rax, xmm15
00007debd2dce8ea  shl rax, 0x0D
00007debd2dce8ee  jbe 0x00007DEBD2DCE818
00007debd2dce8f4  vorps xmm14, xmm15, [0x00007DEBD29FE040]
00007debd2dce8fc  jmp 0x00007DEBD2DCE818
00007debd2dce901  int3
00007debd2dce902  nop [rax+rax*1], ax
00007debd2dce90b  nop [rax+rax*1], eax
00007debd2dce910  mov rax, [r15+0x20]
00007debd2dce914  movaps xmm1, [r15+0x110]
00007debd2dce91c  movq r14, xmm1
00007debd2dce921  mov [r13+rax*1], r14
00007debd2dce926  mov rax, [r15+0xF0]
00007debd2dce92d  mov [r15+0x100], rax
00007debd2dce934  jmp 0x00007DEBD2DCE5C0
00007debd2dce939  int3
00007debd2dce93a  call 0x00007DEBD2C0E120
00007debd2dce93f  jmp 0x00007DEBD2DCE926
00007debd2dce944  int3
00007debd2dce945  nop [rax+rax*1], ax
00007debd2dce94e  nop
00007debd2dce950  mov qword ptr [r15+0x100], 0x04
00007debd2dce95b  mov esi, 0x00
00007debd2dce960  mov edx, 0x09
00007debd2dce965  mov rdi, 0x7FFF4195F160
00007debd2dce96f  mov rax, 0x5DE0B7089970
00007debd2dce979  call rax
00007debd2dce97b  cmp dword ptr [r15+0x318], 0x00
00007debd2dce983  jnz 0x00007DEBD2BFE110
00007debd2dce989  jmp 0x00007DEBD2BFE0A0
00007debd2dce98e  int3
00007debd2dce98f  int3
