00007d7d38fce69b  nop [rax+rax*1], eax
00007d7d38fce6a0  mov qword ptr [r15+0x20], 0x420060
00007d7d38fce6a8  mov eax, 0x420060
00007d7d38fce6ad  xor r14d, r14d
00007d7d38fce6b0  mov [r13+rax*1], r14
00007d7d38fce6b5  mov eax, 0x420060
00007d7d38fce6ba  mov r14, [r13+rax*1]
00007d7d38fce6bf  mov [r15+0x18], r14
00007d7d38fce6c3  lea rax, [r14+0x03]
00007d7d38fce6c7  mov [r15], rax
00007d7d38fce6ca  xor eax, eax
00007d7d38fce6cc  mov r14d, 0xB71B00
00007d7d38fce6d2  mov r12d, 0x01
00007d7d38fce6d8  sub r14, r12
00007d7d38fce6db  cmc
00007d7d38fce6dc  lahf
00007d7d38fce6dd  seto al
00007d7d38fce6e0  mov [r15+0x108], eax
00007d7d38fce6e7  mov [r15+0x08], r14
00007d7d38fce6eb  mov eax, [r15+0x108]
00007d7d38fce6f2  sahf
00007d7d38fce6f3  jnz 0x00007D7D38FCE725
00007d7d38fce6f5  cmp dword ptr [r15+0x318], 0x00
00007d7d38fce6fd  jz 0x00007D7D38FCE840
00007d7d38fce703  nop [rax+rax*1], ax
00007d7d38fce70c  nop [rax+rax*1], eax
00007d7d38fce714  mov eax, 0x410050
00007d7d38fce719  mov [r15+0x100], rax
00007d7d38fce720  jmp 0x00007D7D38DFE110
00007d7d38fce725  cmp dword ptr [r15+0x318], 0x00
00007d7d38fce72d  jz 0x00007D7D38FCE770
00007d7d38fce733  nop [rax+rax*1], ax
00007d7d38fce73c  nop [rax+rax*1], eax
00007d7d38fce744  mov eax, 0x41003C
00007d7d38fce749  mov [r15+0x100], rax
00007d7d38fce750  jmp 0x00007D7D38DFE110
00007d7d38fce755  int3
00007d7d38fce756  call 0x00007D7D38E0E120
00007d7d38fce75b  jmp 0x00007D7D38FCE6B5
00007d7d38fce760  call 0x00007D7D38E0DC20
00007d7d38fce765  jmp 0x00007D7D38FCE6BF
00007d7d38fce76a  int3
00007d7d38fce76b  nop [rax+rax*1], eax
00007d7d38fce770  mov rax, [r15+0x20]
00007d7d38fce774  mov r14, [r15]
00007d7d38fce777  mov [r13+rax*1], r14
00007d7d38fce77c  mov r14, [r13+rax*1]
00007d7d38fce781  mov [r15+0x18], r14
00007d7d38fce785  lea rax, [r14+0x03]
00007d7d38fce789  mov [r15], rax
00007d7d38fce78c  mov rax, [r15+0x08]
00007d7d38fce790  mov [rsp+0x10], rax
00007d7d38fce795  xor eax, eax
00007d7d38fce797  mov r14, [rsp+0x10]
00007d7d38fce79c  mov r12d, 0x01
00007d7d38fce7a2  sub r14, r12
00007d7d38fce7a5  cmc
00007d7d38fce7a6  lahf
00007d7d38fce7a7  seto al
00007d7d38fce7aa  mov [r15+0x108], eax
00007d7d38fce7b1  mov [r15+0x08], r14
00007d7d38fce7b5  mov eax, [r15+0x108]
00007d7d38fce7bc  sahf
00007d7d38fce7bd  jnz 0x00007D7D38FCE7EF
00007d7d38fce7bf  cmp dword ptr [r15+0x318], 0x00
00007d7d38fce7c7  jz 0x00007D7D38FCE840
00007d7d38fce7cd  nop [rax+rax*1], ax
00007d7d38fce7d6  nop [rax+rax*1], eax
00007d7d38fce7de  mov eax, 0x410050
00007d7d38fce7e3  mov [r15+0x100], rax
00007d7d38fce7ea  jmp 0x00007D7D38DFE110
00007d7d38fce7ef  cmp dword ptr [r15+0x318], 0x00
00007d7d38fce7f7  jz 0x00007D7D38FCE770
00007d7d38fce7fd  nop [rax+rax*1], ax
00007d7d38fce806  nop [rax+rax*1], eax
00007d7d38fce80e  mov eax, 0x41003C
00007d7d38fce813  mov [r15+0x100], rax
00007d7d38fce81a  jmp 0x00007D7D38DFE110
00007d7d38fce81f  int3
00007d7d38fce820  call 0x00007D7D38E0E120
00007d7d38fce825  jmp 0x00007D7D38FCE77C
00007d7d38fce82a  call 0x00007D7D38E0DC20
00007d7d38fce82f  jmp 0x00007D7D38FCE781
00007d7d38fce834  int3
00007d7d38fce835  nop [rax+rax*1], ax
00007d7d38fce83e  nop
00007d7d38fce840  mov rax, [r15+0x20]
00007d7d38fce844  mov r14, [r15]
00007d7d38fce847  mov [r13+rax*1], r14
00007d7d38fce84c  mov rax, [r15+0xF0]
00007d7d38fce853  mov [r15+0x100], rax
00007d7d38fce85a  jmp 0x00007D7D38FCE5C0
00007d7d38fce85f  int3
00007d7d38fce860  call 0x00007D7D38E0E120
00007d7d38fce865  jmp 0x00007D7D38FCE84C
00007d7d38fce86a  int3
00007d7d38fce86b  nop [rax+rax*1], eax
00007d7d38fce870  mov qword ptr [r15+0x100], 0x04
00007d7d38fce87b  mov esi, 0x00
00007d7d38fce880  mov edx, 0x09
00007d7d38fce885  mov rdi, 0x7FFE87EB1E40
00007d7d38fce88f  mov rax, 0x5D042B11F970
00007d7d38fce899  call rax
00007d7d38fce89b  cmp dword ptr [r15+0x318], 0x00
00007d7d38fce8a3  jnz 0x00007D7D38DFE110
00007d7d38fce8a9  jmp 0x00007D7D38DFE0A0
00007d7d38fce8ae  int3
00007d7d38fce8af  int3
