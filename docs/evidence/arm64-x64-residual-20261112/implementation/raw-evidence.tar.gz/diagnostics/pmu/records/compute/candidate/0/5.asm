
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/candidate/0/5.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    rax,QWORD PTR [r12+0xf8]
  18:	mov    r14,QWORD PTR [r12+0xf8]
  20:	add    r14,0x100
  27:	mov    r15d,DWORD PTR [r14]
  2a:	mov    QWORD PTR [r12+0x40],r15
  2f:	mov    r14,QWORD PTR [r12+0xf8]
  37:	add    r14,0x104
  3e:	mov    ebp,DWORD PTR [r14]
  41:	mov    QWORD PTR [r12+0x50],rbp
  46:	mov    r14d,0x430c90
  4c:	mov    QWORD PTR [r12+0x48],r14
  51:	mov    r14,QWORD PTR [r12+0xf8]
  59:	add    r14,0x108
  60:	mov    r8d,DWORD PTR [r14]
  63:	mov    QWORD PTR [r12+0x58],r8
  68:	mov    r14,QWORD PTR [r12+0xf8]
  70:	add    r14,0x10c
  77:	mov    eax,DWORD PTR [r14]
  7a:	mov    QWORD PTR [r12+0x60],rax
  7f:	movabs rcx,0xff00ff00ff00ff
  89:	mov    r14,r15
  8c:	and    r14,rcx
  8f:	shl    r14,0x8
  93:	movabs rcx,0xff00ff00ff00ff00
  9d:	mov    r13,r15
  a0:	and    r13,rcx
  a3:	shr    r13,0x8
  a7:	or     r13,r14
  aa:	movabs rcx,0xffff0000ffff
  b4:	mov    r14,r13
  b7:	and    r14,rcx
  ba:	shl    r14,0x10
  be:	movabs rcx,0xffff0000ffff0000
  c8:	and    r13,rcx
  cb:	shr    r13,0x10
  cf:	or     r13,r14
  d2:	mov    ecx,0xffffffff
  d7:	and    r13,rcx
  da:	mov    QWORD PTR [r12+0x40],r13
  df:	movabs rcx,0xff00ff00ff00ff
  e9:	mov    r14,rbp
  ec:	and    r14,rcx
  ef:	shl    r14,0x8
  f3:	movabs rcx,0xff00ff00ff00ff00
  fd:	mov    r15,rbp
 100:	and    r15,rcx
 103:	shr    r15,0x8
 107:	or     r15,r14
 10a:	movabs rcx,0xffff0000ffff
 114:	mov    r14,r15
 117:	and    r14,rcx
 11a:	shl    r14,0x10
 11e:	movabs rcx,0xffff0000ffff0000
 128:	and    r15,rcx
 12b:	shr    r15,0x10
 12f:	or     r15,r14
 132:	mov    ecx,0xffffffff
 137:	and    r15,rcx
 13a:	mov    QWORD PTR [r12+0x50],r15
 13f:	mov    r14d,0x0
 145:	mov    QWORD PTR [r12+0xa0],r14
 14d:	mov    r14d,0x430c90
 153:	mov    ebp,0x430c94
 158:	mov    rax,r13
 15b:	mov    eax,eax
 15d:	mov    r9d,eax
 160:	mov    rax,r15
 163:	mov    eax,eax
 165:	mov    r13d,eax
 168:	mov    DWORD PTR [r14],r9d
 16b:	mov    r14d,0x0
 171:	mov    DWORD PTR [r12+0x32c],r14d
 179:	mov    DWORD PTR [rbp+0x0],r13d
 17d:	movabs rcx,0xff00ff00ff00ff
 187:	mov    r13,r8
 18a:	and    r13,rcx
 18d:	shl    r13,0x8
 191:	movabs rcx,0xff00ff00ff00ff00
 19b:	mov    r14,r8
 19e:	and    r14,rcx
 1a1:	shr    r14,0x8
 1a5:	or     r14,r13
 1a8:	movabs rcx,0xffff0000ffff
 1b2:	mov    r13,r14
 1b5:	and    r13,rcx
 1b8:	shl    r13,0x10
 1bc:	movabs rcx,0xffff0000ffff0000
 1c6:	and    r14,rcx
 1c9:	shr    r14,0x10
 1cd:	or     r14,r13
 1d0:	mov    ecx,0xffffffff
 1d5:	and    r14,rcx
 1d8:	mov    QWORD PTR [r12+0x40],r14
 1dd:	mov    r13,QWORD PTR [r12+0xf8]
 1e5:	add    r13,0x110
 1ec:	mov    r15d,DWORD PTR [r13+0x0]
 1f0:	mov    QWORD PTR [r12+0x50],r15
 1f5:	movabs rcx,0xff00ff00ff00ff
 1ff:	mov    r13d,DWORD PTR [r12+0x60]
 204:	and    r13,rcx
 207:	shl    r13,0x8
 20b:	movabs rcx,0xff00ff00ff00ff00
 215:	mov    ebp,DWORD PTR [r12+0x60]
 21a:	and    rbp,rcx
 21d:	shr    rbp,0x8
 221:	or     rbp,r13
 224:	movabs rcx,0xffff0000ffff
 22e:	mov    r13,rbp
 231:	and    r13,rcx
 234:	shl    r13,0x10
 238:	movabs rcx,0xffff0000ffff0000
 242:	and    rbp,rcx
 245:	shr    rbp,0x10
 249:	or     rbp,r13
 24c:	mov    ecx,0xffffffff
 251:	and    rbp,rcx
 254:	mov    QWORD PTR [r12+0x58],rbp
 259:	mov    r13,QWORD PTR [r12+0xf8]
 261:	add    r13,0x114
 268:	mov    eax,DWORD PTR [r13+0x0]
 26c:	mov    QWORD PTR [r12+0x60],rax
 271:	mov    r13d,0x430000
 277:	add    r13,0xdfc
 27e:	mov    QWORD PTR [r12+0x98],r13
 286:	mov    r13d,0x430c98
 28c:	mov    r9d,0x430c9c
 292:	mov    rax,r14
 295:	mov    eax,eax
 297:	mov    r8d,eax
 29a:	mov    rax,rbp
 29d:	mov    eax,eax
 29f:	mov    r14d,eax
 2a2:	mov    DWORD PTR [r13+0x0],r8d
 2a6:	mov    DWORD PTR [r9],r14d
 2a9:	movabs rcx,0xff00ff00ff00ff
 2b3:	mov    r13,r15
 2b6:	and    r13,rcx
 2b9:	shl    r13,0x8
 2bd:	movabs rcx,0xff00ff00ff00ff00
 2c7:	mov    r14,r15
 2ca:	and    r14,rcx
 2cd:	shr    r14,0x8
 2d1:	or     r14,r13
 2d4:	movabs rcx,0xffff0000ffff
 2de:	mov    r13,r14
 2e1:	and    r13,rcx
 2e4:	shl    r13,0x10
 2e8:	movabs rcx,0xffff0000ffff0000
 2f2:	and    r14,rcx
 2f5:	shr    r14,0x10
 2f9:	or     r14,r13
 2fc:	mov    ecx,0xffffffff
 301:	and    r14,rcx
 304:	mov    QWORD PTR [r12+0x40],r14
 309:	mov    r13,QWORD PTR [r12+0xf8]
 311:	add    r13,0x118
 318:	mov    r15d,DWORD PTR [r13+0x0]
 31c:	mov    QWORD PTR [r12+0x50],r15
 321:	movabs rcx,0xff00ff00ff00ff
 32b:	mov    r13d,DWORD PTR [r12+0x60]
 330:	and    r13,rcx
 333:	shl    r13,0x8
 337:	movabs rcx,0xff00ff00ff00ff00
 341:	mov    ebp,DWORD PTR [r12+0x60]
 346:	and    rbp,rcx
 349:	shr    rbp,0x8
 34d:	or     rbp,r13
 350:	movabs rcx,0xffff0000ffff
 35a:	mov    r13,rbp
 35d:	and    r13,rcx
 360:	shl    r13,0x10
 364:	movabs rcx,0xffff0000ffff0000
 36e:	and    rbp,rcx
 371:	shr    rbp,0x10
 375:	or     rbp,r13
 378:	mov    ecx,0xffffffff
 37d:	and    rbp,rcx
 380:	mov    QWORD PTR [r12+0x58],rbp
 385:	mov    r13,QWORD PTR [r12+0xf8]
 38d:	add    r13,0x11c
 394:	mov    eax,DWORD PTR [r13+0x0]
 398:	mov    QWORD PTR [r12+0x60],rax
 39d:	mov    r13d,0x430ca0
 3a3:	mov    r9d,0x430ca4
 3a9:	mov    rax,r14
 3ac:	mov    eax,eax
 3ae:	mov    r8d,eax
 3b1:	mov    rax,rbp
 3b4:	mov    eax,eax
 3b6:	mov    r14d,eax
 3b9:	mov    DWORD PTR [r13+0x0],r8d
 3bd:	mov    DWORD PTR [r9],r14d
 3c0:	movabs rcx,0xff00ff00ff00ff
 3ca:	mov    r13,r15
 3cd:	and    r13,rcx
 3d0:	shl    r13,0x8
 3d4:	movabs rcx,0xff00ff00ff00ff00
 3de:	mov    r14,r15
 3e1:	and    r14,rcx
 3e4:	shr    r14,0x8
 3e8:	or     r14,r13
 3eb:	movabs rcx,0xffff0000ffff
 3f5:	mov    r13,r14
 3f8:	and    r13,rcx
 3fb:	shl    r13,0x10
 3ff:	movabs rcx,0xffff0000ffff0000
 409:	and    r14,rcx
 40c:	shr    r14,0x10
 410:	or     r14,r13
 413:	mov    ecx,0xffffffff
 418:	and    r14,rcx
 41b:	mov    QWORD PTR [r12+0x40],r14
 420:	movabs rcx,0xff00ff00ff00ff
 42a:	mov    r13d,DWORD PTR [r12+0x60]
 42f:	and    r13,rcx
 432:	shl    r13,0x8
 436:	movabs rcx,0xff00ff00ff00ff00
 440:	mov    r15d,DWORD PTR [r12+0x60]
 445:	and    r15,rcx
 448:	shr    r15,0x8
 44c:	or     r15,r13
 44f:	movabs rcx,0xffff0000ffff
 459:	mov    r13,r15
 45c:	and    r13,rcx
 45f:	shl    r13,0x10
 463:	movabs rcx,0xffff0000ffff0000
 46d:	and    r15,rcx
 470:	shr    r15,0x10
 474:	or     r15,r13
 477:	mov    ecx,0xffffffff
 47c:	and    r15,rcx
 47f:	mov    QWORD PTR [r12+0x50],r15
 484:	mov    r13d,0x430ca8
 48a:	mov    ebp,0x430cac
 48f:	mov    rax,r14
 492:	mov    eax,eax
 494:	mov    r8d,eax
 497:	mov    rax,r15
 49a:	mov    eax,eax
 49c:	mov    r14d,eax
 49f:	mov    DWORD PTR [r13+0x0],r8d
 4a3:	mov    DWORD PTR [rbp+0x0],r14d
 4a7:	mov    r13d,0x11
 4ad:	mov    QWORD PTR [r12],r13
 4b1:	mov    r13d,0x41035c
 4b7:	mov    QWORD PTR [r12+0xf0],r13
 4bf:	mov    r13d,0x4109a4
 4c5:	mov    QWORD PTR [r12+0x100],r13
 4cd:	mov    r11,QWORD PTR [rsp]
 4d1:	mov    QWORD PTR [r12+0x398],r11
 4d9:	mov    edi,0x4109a4
 4de:	mov    QWORD PTR [r12+0x100],rdi
 4e6:	add    rsp,0x10
 4ea:	nop    WORD PTR [rax+rax*1+0x0]
 4f0:	jmp    QWORD PTR [rip+0x2]        # 0x4f8
 4f6:	xchg   ax,ax
 4f8:	rex (bad)
 4fa:	xor    BYTE PTR [rax+rcx*1+0x7b],ch
 4fe:	add    BYTE PTR [rax],al
 500:	sub    BYTE PTR [rdi],dl
 502:	xor    BYTE PTR [rax+rcx*1+0x7b],ch
 506:	add    BYTE PTR [rax],al
 508:	movabs r11,0x590d8528f940
 512:	jmp    r11
 515:	nop
 516:	nop
 517:	nop
