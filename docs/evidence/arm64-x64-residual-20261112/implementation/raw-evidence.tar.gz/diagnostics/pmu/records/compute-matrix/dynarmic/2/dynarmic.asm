00007fa22efce69b  nop [rax+rax*1], eax
00007fa22efce6a0  vmovaps xmm1, [0x00007FA22EBFE010]
00007fa22efce6a8  movq xmm1, xmm1
00007fa22efce6ac  movaps [r15+0x110], xmm1
00007fa22efce6b4  vmovaps xmm1, [0x00007FA22EBFE020]
00007fa22efce6bc  movq xmm1, xmm1
00007fa22efce6c0  movaps [r15+0x120], xmm1
00007fa22efce6c8  mov eax, 0x4204C0
00007fa22efce6cd  mov r14, [r13+rax*1]
00007fa22efce6d2  movq xmm1, r14
00007fa22efce6d7  movaps [r15+0x130], xmm1
00007fa22efce6df  vmovaps xmm1, [0x00007FA22EBFE030]
00007fa22efce6e7  vpbroadcastq xmm1, xmm1
00007fa22efce6ec  movaps [r15+0x140], xmm1
00007fa22efce6f4  mov qword ptr [r15+0x40], 0x02
00007fa22efce6fc  vmovaps xmm15, [0x00007FA22EBFE040]
00007fa22efce704  movq xmm15, xmm15
00007fa22efce709  movaps [r15+0x150], xmm15
00007fa22efce711  mov qword ptr [r15+0x58], 0x420000
00007fa22efce719  vmovaps xmm15, [0x00007FA22EBFE050]
00007fa22efce721  vpbroadcastq xmm15, xmm15
00007fa22efce726  movaps [r15+0x160], xmm15
00007fa22efce72e  mov rax, [r15+0x40]
00007fa22efce732  vmovq xmm14, rax
00007fa22efce737  vpbroadcastq xmm14, xmm14
00007fa22efce73c  movaps [r15+0x170], xmm14
00007fa22efce744  mov eax, 0x4204D0
00007fa22efce749  movups xmm13, [r13+rax*1]
00007fa22efce74f  mov qword ptr [r15+0x40], 0x430518
00007fa22efce757  mov qword ptr [r15+0x50], 0x430720
00007fa22efce75f  vpmovqd xmm12, xmm13
00007fa22efce765  pxor xmm11, xmm11
00007fa22efce76a  punpcklqdq xmm12, xmm11
00007fa22efce76f  movaps [r15+0x210], xmm12
00007fa22efce777  movq xmm12, qword ptr [r15+0x120]
00007fa22efce780  movq xmm11, qword ptr [r15+0x130]
00007fa22efce789  psubd xmm12, xmm11
00007fa22efce78e  movq xmm12, xmm12
00007fa22efce793  paddq xmm13, xmm14
00007fa22efce798  movaps [r15+0x180], xmm13
00007fa22efce7a0  movq xmm14, qword ptr [r15+0x150]
00007fa22efce7a9  paddd xmm11, xmm14
00007fa22efce7ae  movq xmm11, xmm11
00007fa22efce7b3  movq xmm11, xmm11
00007fa22efce7b8  movaps [r15+0x130], xmm11
00007fa22efce7c0  pmovzxdq xmm12, xmm12
00007fa22efce7c6  psllq xmm12, 0x00
00007fa22efce7cc  movq xmm14, qword ptr [r15+0x210]
00007fa22efce7d5  movq xmm13, qword ptr [r15+0x110]
00007fa22efce7de  paddd xmm14, xmm13
00007fa22efce7e3  movq xmm14, xmm14
00007fa22efce7e8  vcvtuqq2pd xmm12, xmm12
00007fa22efce7ee  pmovzxdq xmm14, xmm14
00007fa22efce7f4  psllq xmm14, 0x00
00007fa22efce7fa  vcvtuqq2pd xmm14, xmm14
00007fa22efce800  movaps xmm13, xmm12
00007fa22efce804  mulpd xmm13, xmm1
00007fa22efce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007fa22efce80f  ptest xmm11, xmm11
00007fa22efce815  jnz 0x00007FA22EFCE8FF
00007fa22efce81b  movaps [r15+0x220], xmm13
00007fa22efce823  mov eax, 0x430720
00007fa22efce828  movups [r13+rax*1], xmm13
00007fa22efce82e  movaps xmm1, xmm14
00007fa22efce832  mulpd xmm1, xmm15
00007fa22efce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007fa22efce83c  ptest xmm13, xmm13
00007fa22efce842  jnz 0x00007FA22EFCEA4C
00007fa22efce848  movaps [r15+0x210], xmm1
00007fa22efce850  mov eax, 0x430518
00007fa22efce855  movups [r13+rax*1], xmm1
00007fa22efce85b  mov qword ptr [r15+0x48], 0x10
00007fa22efce863  xor eax, eax
00007fa22efce865  mov r14d, 0x10
00007fa22efce86b  mov r12d, 0x200
00007fa22efce871  cmp r14, r12
00007fa22efce874  cmc
00007fa22efce875  lahf
00007fa22efce876  seto al
00007fa22efce879  mov [r15+0x108], eax
00007fa22efce880  mov eax, [r15+0x108]
00007fa22efce887  sahf
00007fa22efce888  jnz 0x00007FA22EFCE8BA
00007fa22efce88a  cmp dword ptr [r15+0x318], 0x00
00007fa22efce892  jz 0x00007FA22EFCEFF0
00007fa22efce898  nop [rax+rax*1], ax
00007fa22efce8a1  nop [rax+rax*1], eax
00007fa22efce8a9  mov eax, 0x4101EC
00007fa22efce8ae  mov [r15+0x100], rax
00007fa22efce8b5  jmp 0x00007FA22EDFE110
00007fa22efce8ba  cmp dword ptr [r15+0x318], 0x00
00007fa22efce8c2  jz 0x00007FA22EFCEBA0
00007fa22efce8c8  nop [rax+rax*1], ax
00007fa22efce8d1  nop [rax+rax*1], eax
00007fa22efce8d9  mov eax, 0x4101AC
00007fa22efce8de  mov [r15+0x100], rax
00007fa22efce8e5  jmp 0x00007FA22EDFE110
00007fa22efce8ea  int3
00007fa22efce8eb  call 0x00007FA22EE0DC20
00007fa22efce8f0  jmp 0x00007FA22EFCE6D2
00007fa22efce8f5  call 0x00007FA22EE0C260
00007fa22efce8fa  jmp 0x00007FA22EFCE74F
00007fa22efce8ff  sub rsp, 0x08
00007fa22efce903  push rax
00007fa22efce904  push rcx
00007fa22efce905  push rdx
00007fa22efce906  push rdi
00007fa22efce907  push rsi
00007fa22efce908  push r8
00007fa22efce90a  push r9
00007fa22efce90c  push r10
00007fa22efce90e  push r11
00007fa22efce910  sub rsp, 0xF0
00007fa22efce917  vmovaps [rsp], xmm0
00007fa22efce91c  vmovaps [rsp+0x10], xmm1
00007fa22efce922  vmovaps [rsp+0x20], xmm2
00007fa22efce928  vmovaps [rsp+0x30], xmm3
00007fa22efce92e  vmovaps [rsp+0x40], xmm4
00007fa22efce934  vmovaps [rsp+0x50], xmm5
00007fa22efce93a  vmovaps [rsp+0x60], xmm6
00007fa22efce940  vmovaps [rsp+0x70], xmm7
00007fa22efce946  vmovaps [rsp+0x80], xmm8
00007fa22efce94f  vmovaps [rsp+0x90], xmm9
00007fa22efce958  vmovaps [rsp+0xA0], xmm10
00007fa22efce961  vmovaps [rsp+0xB0], xmm11
00007fa22efce96a  vmovaps [rsp+0xC0], xmm12
00007fa22efce973  vmovaps [rsp+0xD0], xmm14
00007fa22efce97c  vmovaps [rsp+0xE0], xmm15
00007fa22efce985  sub rsp, 0x30
00007fa22efce989  movaps [rsp], xmm13
00007fa22efce98e  movaps [rsp+0x10], xmm12
00007fa22efce994  movaps [rsp+0x20], xmm1
00007fa22efce999  lea rdi, [rsp]
00007fa22efce99d  mov esi, 0x00
00007fa22efce9a2  mov rax, 0x5E9D1A57D530
00007fa22efce9ac  call rax
00007fa22efce9ae  movaps xmm13, [rsp]
00007fa22efce9b3  add rsp, 0x30
00007fa22efce9b7  vmovaps xmm0, [rsp]
00007fa22efce9bc  vmovaps xmm1, [rsp+0x10]
00007fa22efce9c2  vmovaps xmm2, [rsp+0x20]
00007fa22efce9c8  vmovaps xmm3, [rsp+0x30]
00007fa22efce9ce  vmovaps xmm4, [rsp+0x40]
00007fa22efce9d4  vmovaps xmm5, [rsp+0x50]
00007fa22efce9da  vmovaps xmm6, [rsp+0x60]
00007fa22efce9e0  vmovaps xmm7, [rsp+0x70]
00007fa22efce9e6  vmovaps xmm8, [rsp+0x80]
00007fa22efce9ef  vmovaps xmm9, [rsp+0x90]
00007fa22efce9f8  vmovaps xmm10, [rsp+0xA0]
00007fa22efcea01  vmovaps xmm11, [rsp+0xB0]
00007fa22efcea0a  vmovaps xmm12, [rsp+0xC0]
00007fa22efcea13  vmovaps xmm14, [rsp+0xD0]
00007fa22efcea1c  vmovaps xmm15, [rsp+0xE0]
00007fa22efcea25  add rsp, 0xF0
00007fa22efcea2c  pop r11
00007fa22efcea2e  pop r10
00007fa22efcea30  pop r9
00007fa22efcea32  pop r8
00007fa22efcea34  pop rsi
00007fa22efcea35  pop rdi
00007fa22efcea36  pop rdx
00007fa22efcea37  pop rcx
00007fa22efcea38  pop rax
00007fa22efcea39  add rsp, 0x08
00007fa22efcea3d  jmp 0x00007FA22EFCE81B
00007fa22efcea42  call 0x00007FA22EE0C380
00007fa22efcea47  jmp 0x00007FA22EFCE82E
00007fa22efcea4c  sub rsp, 0x08
00007fa22efcea50  push rax
00007fa22efcea51  push rcx
00007fa22efcea52  push rdx
00007fa22efcea53  push rdi
00007fa22efcea54  push rsi
00007fa22efcea55  push r8
00007fa22efcea57  push r9
00007fa22efcea59  push r10
00007fa22efcea5b  push r11
00007fa22efcea5d  sub rsp, 0xF0
00007fa22efcea64  vmovaps [rsp], xmm0
00007fa22efcea69  vmovaps [rsp+0x10], xmm2
00007fa22efcea6f  vmovaps [rsp+0x20], xmm3
00007fa22efcea75  vmovaps [rsp+0x30], xmm4
00007fa22efcea7b  vmovaps [rsp+0x40], xmm5
00007fa22efcea81  vmovaps [rsp+0x50], xmm6
00007fa22efcea87  vmovaps [rsp+0x60], xmm7
00007fa22efcea8d  vmovaps [rsp+0x70], xmm8
00007fa22efcea93  vmovaps [rsp+0x80], xmm9
00007fa22efcea9c  vmovaps [rsp+0x90], xmm10
00007fa22efceaa5  vmovaps [rsp+0xA0], xmm11
00007fa22efceaae  vmovaps [rsp+0xB0], xmm12
00007fa22efceab7  vmovaps [rsp+0xC0], xmm13
00007fa22efceac0  vmovaps [rsp+0xD0], xmm14
00007fa22efceac9  vmovaps [rsp+0xE0], xmm15
00007fa22efcead2  sub rsp, 0x30
00007fa22efcead6  movaps [rsp], xmm1
00007fa22efceada  movaps [rsp+0x10], xmm14
00007fa22efceae0  movaps [rsp+0x20], xmm15
00007fa22efceae6  lea rdi, [rsp]
00007fa22efceaea  mov esi, 0x00
00007fa22efceaef  mov rax, 0x5E9D1A57D530
00007fa22efceaf9  call rax
00007fa22efceafb  movaps xmm1, [rsp]
00007fa22efceaff  add rsp, 0x30
00007fa22efceb03  vmovaps xmm0, [rsp]
00007fa22efceb08  vmovaps xmm2, [rsp+0x10]
00007fa22efceb0e  vmovaps xmm3, [rsp+0x20]
00007fa22efceb14  vmovaps xmm4, [rsp+0x30]
00007fa22efceb1a  vmovaps xmm5, [rsp+0x40]
00007fa22efceb20  vmovaps xmm6, [rsp+0x50]
00007fa22efceb26  vmovaps xmm7, [rsp+0x60]
00007fa22efceb2c  vmovaps xmm8, [rsp+0x70]
00007fa22efceb32  vmovaps xmm9, [rsp+0x80]
00007fa22efceb3b  vmovaps xmm10, [rsp+0x90]
00007fa22efceb44  vmovaps xmm11, [rsp+0xA0]
00007fa22efceb4d  vmovaps xmm12, [rsp+0xB0]
00007fa22efceb56  vmovaps xmm13, [rsp+0xC0]
00007fa22efceb5f  vmovaps xmm14, [rsp+0xD0]
00007fa22efceb68  vmovaps xmm15, [rsp+0xE0]
00007fa22efceb71  add rsp, 0xF0
00007fa22efceb78  pop r11
00007fa22efceb7a  pop r10
00007fa22efceb7c  pop r9
00007fa22efceb7e  pop r8
00007fa22efceb80  pop rsi
00007fa22efceb81  pop rdi
00007fa22efceb82  pop rdx
00007fa22efceb83  pop rcx
00007fa22efceb84  pop rax
00007fa22efceb85  add rsp, 0x08
00007fa22efceb89  jmp 0x00007FA22EFCE848
00007fa22efceb8e  call 0x00007FA22EDFF540
00007fa22efceb93  jmp 0x00007FA22EFCE85B
00007fa22efceb98  int3
00007fa22efceb99  nop [rax], eax
00007fa22efceba0  movaps xmm1, [r15+0x180]
00007fa22efceba8  vpmovqd xmm15, xmm1
00007fa22efcebae  pxor xmm14, xmm14
00007fa22efcebb3  punpcklqdq xmm15, xmm14
00007fa22efcebb8  movaps [r15+0x210], xmm15
00007fa22efcebc0  movq xmm15, qword ptr [r15+0x120]
00007fa22efcebc9  movq xmm14, qword ptr [r15+0x130]
00007fa22efcebd2  psubd xmm15, xmm14
00007fa22efcebd7  movq xmm15, xmm15
00007fa22efcebdc  movaps xmm13, [r15+0x170]
00007fa22efcebe4  paddq xmm1, xmm13
00007fa22efcebe9  movaps [r15+0x180], xmm1
00007fa22efcebf1  movq xmm1, qword ptr [r15+0x150]
00007fa22efcebfa  paddd xmm14, xmm1
00007fa22efcebff  movq xmm14, xmm14
00007fa22efcec04  movq xmm14, xmm14
00007fa22efcec09  movaps [r15+0x130], xmm14
00007fa22efcec11  pmovzxdq xmm15, xmm15
00007fa22efcec17  psllq xmm15, 0x00
00007fa22efcec1d  movq xmm1, qword ptr [r15+0x210]
00007fa22efcec26  movq xmm14, qword ptr [r15+0x110]
00007fa22efcec2f  paddd xmm1, xmm14
00007fa22efcec34  movq xmm1, xmm1
00007fa22efcec38  vcvtuqq2pd xmm15, xmm15
00007fa22efcec3e  pmovzxdq xmm1, xmm1
00007fa22efcec43  psllq xmm1, 0x00
00007fa22efcec48  vcvtuqq2pd xmm1, xmm1
00007fa22efcec4e  movaps xmm14, [r15+0x140]
00007fa22efcec56  movaps xmm13, xmm15
00007fa22efcec5a  mulpd xmm13, xmm14
00007fa22efcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007fa22efcec65  ptest xmm12, xmm12
00007fa22efcec6b  jnz 0x00007FA22EFCED4E
00007fa22efcec71  movaps [r15+0x220], xmm13
00007fa22efcec79  mov rax, [r15+0x48]
00007fa22efcec7d  mov r14, [r15+0x50]
00007fa22efcec81  lea r12, [r14+rax*1]
00007fa22efcec85  movups [r13+r12*1], xmm13
00007fa22efcec8b  movaps xmm15, [r15+0x160]
00007fa22efcec93  movaps xmm14, xmm1
00007fa22efcec97  mulpd xmm14, xmm15
00007fa22efcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007fa22efceca2  ptest xmm13, xmm13
00007fa22efceca8  jnz 0x00007FA22EFCEE9C
00007fa22efcecae  movaps [r15+0x210], xmm14
00007fa22efcecb6  mov r14, [r15+0x40]
00007fa22efcecba  lea r12, [r14+rax*1]
00007fa22efcecbe  movups [r13+r12*1], xmm14
00007fa22efcecc4  lea r14, [rax+0x10]
00007fa22efcecc8  mov [r15+0x48], r14
00007fa22efceccc  xor eax, eax
00007fa22efcecce  mov r12d, 0x200
00007fa22efcecd4  cmp r14, r12
00007fa22efcecd7  cmc
00007fa22efcecd8  lahf
00007fa22efcecd9  seto al
00007fa22efcecdc  mov [r15+0x108], eax
00007fa22efcece3  mov eax, [r15+0x108]
00007fa22efcecea  sahf
00007fa22efceceb  jnz 0x00007FA22EFCED1D
00007fa22efceced  cmp dword ptr [r15+0x318], 0x00
00007fa22efcecf5  jz 0x00007FA22EFCEFF0
00007fa22efcecfb  nop [rax+rax*1], ax
00007fa22efced04  nop [rax+rax*1], eax
00007fa22efced0c  mov eax, 0x4101EC
00007fa22efced11  mov [r15+0x100], rax
00007fa22efced18  jmp 0x00007FA22EDFE110
00007fa22efced1d  cmp dword ptr [r15+0x318], 0x00
00007fa22efced25  jz 0x00007FA22EFCEBA0
00007fa22efced2b  nop [rax+rax*1], ax
00007fa22efced34  nop [rax+rax*1], eax
00007fa22efced3c  mov eax, 0x4101AC
00007fa22efced41  mov [r15+0x100], rax
00007fa22efced48  jmp 0x00007FA22EDFE110
00007fa22efced4d  int3
00007fa22efced4e  sub rsp, 0x08
00007fa22efced52  push rax
00007fa22efced53  push rcx
00007fa22efced54  push rdx
00007fa22efced55  push rdi
00007fa22efced56  push rsi
00007fa22efced57  push r8
00007fa22efced59  push r9
00007fa22efced5b  push r10
00007fa22efced5d  push r11
00007fa22efced5f  sub rsp, 0xF0
00007fa22efced66  vmovaps [rsp], xmm0
00007fa22efced6b  vmovaps [rsp+0x10], xmm1
00007fa22efced71  vmovaps [rsp+0x20], xmm2
00007fa22efced77  vmovaps [rsp+0x30], xmm3
00007fa22efced7d  vmovaps [rsp+0x40], xmm4
00007fa22efced83  vmovaps [rsp+0x50], xmm5
00007fa22efced89  vmovaps [rsp+0x60], xmm6
00007fa22efced8f  vmovaps [rsp+0x70], xmm7
00007fa22efced95  vmovaps [rsp+0x80], xmm8
00007fa22efced9e  vmovaps [rsp+0x90], xmm9
00007fa22efceda7  vmovaps [rsp+0xA0], xmm10
00007fa22efcedb0  vmovaps [rsp+0xB0], xmm11
00007fa22efcedb9  vmovaps [rsp+0xC0], xmm12
00007fa22efcedc2  vmovaps [rsp+0xD0], xmm14
00007fa22efcedcb  vmovaps [rsp+0xE0], xmm15
00007fa22efcedd4  sub rsp, 0x30
00007fa22efcedd8  movaps [rsp], xmm13
00007fa22efceddd  movaps [rsp+0x10], xmm15
00007fa22efcede3  movaps [rsp+0x20], xmm14
00007fa22efcede9  lea rdi, [rsp]
00007fa22efceded  mov esi, 0x00
00007fa22efcedf2  mov rax, 0x5E9D1A57D530
00007fa22efcedfc  call rax
00007fa22efcedfe  movaps xmm13, [rsp]
00007fa22efcee03  add rsp, 0x30
00007fa22efcee07  vmovaps xmm0, [rsp]
00007fa22efcee0c  vmovaps xmm1, [rsp+0x10]
00007fa22efcee12  vmovaps xmm2, [rsp+0x20]
00007fa22efcee18  vmovaps xmm3, [rsp+0x30]
00007fa22efcee1e  vmovaps xmm4, [rsp+0x40]
00007fa22efcee24  vmovaps xmm5, [rsp+0x50]
00007fa22efcee2a  vmovaps xmm6, [rsp+0x60]
00007fa22efcee30  vmovaps xmm7, [rsp+0x70]
00007fa22efcee36  vmovaps xmm8, [rsp+0x80]
00007fa22efcee3f  vmovaps xmm9, [rsp+0x90]
00007fa22efcee48  vmovaps xmm10, [rsp+0xA0]
00007fa22efcee51  vmovaps xmm11, [rsp+0xB0]
00007fa22efcee5a  vmovaps xmm12, [rsp+0xC0]
00007fa22efcee63  vmovaps xmm14, [rsp+0xD0]
00007fa22efcee6c  vmovaps xmm15, [rsp+0xE0]
00007fa22efcee75  add rsp, 0xF0
00007fa22efcee7c  pop r11
00007fa22efcee7e  pop r10
00007fa22efcee80  pop r9
00007fa22efcee82  pop r8
00007fa22efcee84  pop rsi
00007fa22efcee85  pop rdi
00007fa22efcee86  pop rdx
00007fa22efcee87  pop rcx
00007fa22efcee88  pop rax
00007fa22efcee89  add rsp, 0x08
00007fa22efcee8d  jmp 0x00007FA22EFCEC71
00007fa22efcee92  call 0x00007FA22EEC2240
00007fa22efcee97  jmp 0x00007FA22EFCEC8B
00007fa22efcee9c  sub rsp, 0x08
00007fa22efceea0  push rax
00007fa22efceea1  push rcx
00007fa22efceea2  push rdx
00007fa22efceea3  push rdi
00007fa22efceea4  push rsi
00007fa22efceea5  push r8
00007fa22efceea7  push r9
00007fa22efceea9  push r10
00007fa22efceeab  push r11
00007fa22efceead  sub rsp, 0xF0
00007fa22efceeb4  vmovaps [rsp], xmm0
00007fa22efceeb9  vmovaps [rsp+0x10], xmm1
00007fa22efceebf  vmovaps [rsp+0x20], xmm2
00007fa22efceec5  vmovaps [rsp+0x30], xmm3
00007fa22efceecb  vmovaps [rsp+0x40], xmm4
00007fa22efceed1  vmovaps [rsp+0x50], xmm5
00007fa22efceed7  vmovaps [rsp+0x60], xmm6
00007fa22efceedd  vmovaps [rsp+0x70], xmm7
00007fa22efceee3  vmovaps [rsp+0x80], xmm8
00007fa22efceeec  vmovaps [rsp+0x90], xmm9
00007fa22efceef5  vmovaps [rsp+0xA0], xmm10
00007fa22efceefe  vmovaps [rsp+0xB0], xmm11
00007fa22efcef07  vmovaps [rsp+0xC0], xmm12
00007fa22efcef10  vmovaps [rsp+0xD0], xmm13
00007fa22efcef19  vmovaps [rsp+0xE0], xmm15
00007fa22efcef22  sub rsp, 0x30
00007fa22efcef26  movaps [rsp], xmm14
00007fa22efcef2b  movaps [rsp+0x10], xmm1
00007fa22efcef30  movaps [rsp+0x20], xmm15
00007fa22efcef36  lea rdi, [rsp]
00007fa22efcef3a  mov esi, 0x00
00007fa22efcef3f  mov rax, 0x5E9D1A57D530
00007fa22efcef49  call rax
00007fa22efcef4b  movaps xmm14, [rsp]
00007fa22efcef50  add rsp, 0x30
00007fa22efcef54  vmovaps xmm0, [rsp]
00007fa22efcef59  vmovaps xmm1, [rsp+0x10]
00007fa22efcef5f  vmovaps xmm2, [rsp+0x20]
00007fa22efcef65  vmovaps xmm3, [rsp+0x30]
00007fa22efcef6b  vmovaps xmm4, [rsp+0x40]
00007fa22efcef71  vmovaps xmm5, [rsp+0x50]
00007fa22efcef77  vmovaps xmm6, [rsp+0x60]
00007fa22efcef7d  vmovaps xmm7, [rsp+0x70]
00007fa22efcef83  vmovaps xmm8, [rsp+0x80]
00007fa22efcef8c  vmovaps xmm9, [rsp+0x90]
00007fa22efcef95  vmovaps xmm10, [rsp+0xA0]
00007fa22efcef9e  vmovaps xmm11, [rsp+0xB0]
00007fa22efcefa7  vmovaps xmm12, [rsp+0xC0]
00007fa22efcefb0  vmovaps xmm13, [rsp+0xD0]
00007fa22efcefb9  vmovaps xmm15, [rsp+0xE0]
00007fa22efcefc2  add rsp, 0xF0
00007fa22efcefc9  pop r11
00007fa22efcefcb  pop r10
00007fa22efcefcd  pop r9
00007fa22efcefcf  pop r8
00007fa22efcefd1  pop rsi
00007fa22efcefd2  pop rdi
00007fa22efcefd3  pop rdx
00007fa22efcefd4  pop rcx
00007fa22efcefd5  pop rax
00007fa22efcefd6  add rsp, 0x08
00007fa22efcefda  jmp 0x00007FA22EFCECAE
00007fa22efcefdf  call 0x00007FA22EEC34C0
00007fa22efcefe4  jmp 0x00007FA22EFCECC4
00007fa22efcefe9  int3
00007fa22efcefea  nop [rax+rax*1], ax
00007fa22efceff0  mov rax, [r15+0xF8]
00007fa22efceff7  lea r14, [rax-0x150]
00007fa22efceffe  mov [r15+0xF8], r14
00007fa22efcf005  mov rax, [r15+0x50]
00007fa22efcf009  lea r12, [rax+0x80]
00007fa22efcf010  movups xmm1, [r13+r12*1]
00007fa22efcf016  lea r12, [rax+0x90]
00007fa22efcf01d  movups xmm15, [r13+r12*1]
00007fa22efcf023  mov qword ptr [r15+0x48], 0x00
00007fa22efcf02b  lea r12, [rax+0x40]
00007fa22efcf02f  movups xmm14, [r13+r12*1]
00007fa22efcf035  lea r12, [rax+0x50]
00007fa22efcf039  movups xmm13, [r13+r12*1]
00007fa22efcf03f  lea r12, [r14+0x120]
00007fa22efcf046  movq xmm12, qword ptr [r15+0x1C0]
00007fa22efcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007fa22efcf058  movq r11, xmm12
00007fa22efcf05d  movq r10, xmm11
00007fa22efcf062  mov [r13+r12*1], r11
00007fa22efcf067  lea r12, [r14+0x128]
00007fa22efcf06e  mov [r13+r12*1], r10
00007fa22efcf073  vxorps xmm12, xmm12, xmm12
00007fa22efcf078  vpbroadcastq xmm12, xmm12
00007fa22efcf07d  lea r12, [r14+0x100]
00007fa22efcf084  movq xmm11, qword ptr [r15+0x200]
00007fa22efcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007fa22efcf096  movq r11, xmm11
00007fa22efcf09b  movq r10, xmm10
00007fa22efcf0a0  mov [r13+r12*1], r11
00007fa22efcf0a5  lea r12, [r14+0x108]
00007fa22efcf0ac  mov [r13+r12*1], r10
00007fa22efcf0b1  lea r12, [r14+0xE0]
00007fa22efcf0b8  movups [r13+r12*1], xmm15
00007fa22efcf0be  lea r12, [r14+0xF0]
00007fa22efcf0c5  movups [r13+r12*1], xmm1
00007fa22efcf0cb  lea r12, [rax+0xC0]
00007fa22efcf0d2  movups xmm1, [r13+r12*1]
00007fa22efcf0d8  lea r12, [rax+0xD0]
00007fa22efcf0df  movups xmm15, [r13+r12*1]
00007fa22efcf0e5  lea r12, [r14+0x110]
00007fa22efcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007fa22efcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007fa22efcf0fe  movq r11, xmm11
00007fa22efcf103  movq r10, xmm10
00007fa22efcf108  mov [r13+r12*1], r11
00007fa22efcf10d  lea r12, [r14+0x118]
00007fa22efcf114  mov [r13+r12*1], r10
00007fa22efcf119  movups xmm11, [r13+rax*1]
00007fa22efcf11f  lea r12, [rax+0x10]
00007fa22efcf123  movups xmm10, [r13+r12*1]
00007fa22efcf129  lea r12, [r14+0x130]
00007fa22efcf130  movq xmm9, qword ptr [r15+0x1A0]
00007fa22efcf139  movq xmm8, qword ptr [r15+0x190]
00007fa22efcf142  movq r11, xmm9
00007fa22efcf147  movq r10, xmm8
00007fa22efcf14c  mov [r13+r12*1], r11
00007fa22efcf151  lea r12, [r14+0x138]
00007fa22efcf158  mov [r13+r12*1], r10
00007fa22efcf15d  lea r12, [rax+0x140]
00007fa22efcf164  movups xmm9, [r13+r12*1]
00007fa22efcf16a  lea r12, [rax+0x150]
00007fa22efcf171  movups xmm8, [r13+r12*1]
00007fa22efcf177  lea r12, [r14+0xC0]
00007fa22efcf17e  movups [r13+r12*1], xmm15
00007fa22efcf184  lea r12, [r14+0xD0]
00007fa22efcf18b  movups [r13+r12*1], xmm1
00007fa22efcf191  lea r12, [rax+0x100]
00007fa22efcf198  movups xmm1, [r13+r12*1]
00007fa22efcf19e  lea r12, [rax+0x110]
00007fa22efcf1a5  movups xmm15, [r13+r12*1]
00007fa22efcf1ab  lea r12, [r14+0x140]
00007fa22efcf1b2  mov r11, [r15+0xE8]
00007fa22efcf1b9  mov [r13+r12*1], r11
00007fa22efcf1be  lea r12, [rax+0x180]
00007fa22efcf1c5  movups xmm7, [r13+r12*1]
00007fa22efcf1cb  lea r12, [rax+0x190]
00007fa22efcf1d2  movups xmm6, [r13+r12*1]
00007fa22efcf1d8  lea r12, [rax+0x1C0]
00007fa22efcf1df  movups xmm5, [r13+r12*1]
00007fa22efcf1e5  lea r12, [rax+0x1D0]
00007fa22efcf1ec  movups xmm4, [r13+r12*1]
00007fa22efcf1f2  lea r12, [r14+0x20]
00007fa22efcf1f6  movups [r13+r12*1], xmm1
00007fa22efcf1fc  lea r12, [r14+0x30]
00007fa22efcf200  movups [r13+r12*1], xmm13
00007fa22efcf206  lea r12, [rax+0x60]
00007fa22efcf20a  movups xmm1, [r13+r12*1]
00007fa22efcf210  lea r12, [rax+0x70]
00007fa22efcf214  movups xmm13, [r13+r12*1]
00007fa22efcf21a  lea r12, [rax+0x20]
00007fa22efcf21e  movups xmm3, [r13+r12*1]
00007fa22efcf224  lea r12, [rax+0x30]
00007fa22efcf228  movups xmm2, [r13+r12*1]
00007fa22efcf22e  movaps [r15+0x1F0], xmm2
00007fa22efcf236  lea r12, [r14+0x60]
00007fa22efcf23a  movups [r13+r12*1], xmm11
00007fa22efcf240  lea r12, [r14+0x70]
00007fa22efcf244  movups [r13+r12*1], xmm5
00007fa22efcf24a  lea r12, [rax+0xE0]
00007fa22efcf251  movups xmm11, [r13+r12*1]
00007fa22efcf257  lea r12, [rax+0xF0]
00007fa22efcf25e  movups xmm5, [r13+r12*1]
00007fa22efcf264  lea r12, [r14+0xA0]
00007fa22efcf26b  movups [r13+r12*1], xmm13
00007fa22efcf271  lea r12, [r14+0xB0]
00007fa22efcf278  movups [r13+r12*1], xmm1
00007fa22efcf27e  lea r12, [rax+0xA0]
00007fa22efcf285  movups xmm1, [r13+r12*1]
00007fa22efcf28b  lea r12, [rax+0xB0]
00007fa22efcf292  movups xmm13, [r13+r12*1]
00007fa22efcf298  lea r12, [rax+0x120]
00007fa22efcf29f  vmovaps [rsp+0x10], xmm1
00007fa22efcf2a5  movups xmm1, [r13+r12*1]
00007fa22efcf2ab  lea r12, [rax+0x130]
00007fa22efcf2b2  vmovaps [rsp+0x20], xmm1
00007fa22efcf2b8  movups xmm1, [r13+r12*1]
00007fa22efcf2be  lea r12, [rax+0x160]
00007fa22efcf2c5  vmovaps [rsp+0x30], xmm1
00007fa22efcf2cb  movups xmm1, [r13+r12*1]
00007fa22efcf2d1  lea r12, [rax+0x170]
00007fa22efcf2d8  vmovaps [rsp+0x40], xmm1
00007fa22efcf2de  movups xmm1, [r13+r12*1]
00007fa22efcf2e4  movaps [r15+0x2B0], xmm1
00007fa22efcf2ec  lea r12, [r14+0x80]
00007fa22efcf2f3  movups [r13+r12*1], xmm13
00007fa22efcf2f9  lea r12, [r14+0x90]
00007fa22efcf300  vmovaps xmm13, [rsp+0x10]
00007fa22efcf306  movups [r13+r12*1], xmm13
00007fa22efcf30c  lea r12, [rax+0x1A0]
00007fa22efcf313  movups xmm13, [r13+r12*1]
00007fa22efcf319  lea r12, [rax+0x1B0]
00007fa22efcf320  vmovaps [rsp+0x10], xmm1
00007fa22efcf326  movups xmm1, [r13+r12*1]
00007fa22efcf32c  movaps [r15+0x290], xmm13
00007fa22efcf334  movaps [r15+0x1E0], xmm1
00007fa22efcf33c  lea r12, [rax+0x1E0]
00007fa22efcf343  vmovaps [rsp+0x50], xmm1
00007fa22efcf349  movups xmm1, [r13+r12*1]
00007fa22efcf34f  lea r12, [rax+0x1F0]
00007fa22efcf356  vmovaps [rsp+0x60], xmm1
00007fa22efcf35c  movups xmm1, [r13+r12*1]
00007fa22efcf362  mov qword ptr [r15+0x50], 0x430920
00007fa22efcf36a  lea rax, [r14+0x40]
00007fa22efcf36e  vmovaps [rsp+0x70], xmm1
00007fa22efcf374  vmovaps xmm1, [rsp+0x40]
00007fa22efcf37a  movups [r13+rax*1], xmm1
00007fa22efcf380  lea rax, [r14+0x50]
00007fa22efcf384  movups [r13+rax*1], xmm10
00007fa22efcf38a  vmovaps xmm1, [rsp+0x70]
00007fa22efcf390  movups [r13+r14*1], xmm1
00007fa22efcf396  lea rax, [r14+0x10]
00007fa22efcf39a  vmovaps xmm1, [rsp+0x60]
00007fa22efcf3a0  movups [r13+rax*1], xmm1
00007fa22efcf3a6  mov rax, [r15+0x40]
00007fa22efcf3aa  vmovaps [rsp+0x40], xmm3
00007fa22efcf3b0  vmovaps xmm1, [rsp+0x40]
00007fa22efcf3b6  por xmm3, xmm1
00007fa22efcf3ba  vmovaps [rsp+0x40], xmm6
00007fa22efcf3c0  vmovaps xmm10, [rsp+0x40]
00007fa22efcf3c6  por xmm6, xmm10
00007fa22efcf3cb  lea r12, [rax+0x30]
00007fa22efcf3cf  mov r11, [r13+r12*1]
00007fa22efcf3d4  lea r12, [rax+0x38]
00007fa22efcf3d8  mov r10, [r13+r12*1]
00007fa22efcf3dd  movq xmm10, r11
00007fa22efcf3e2  vmovaps [rsp+0x40], xmm1
00007fa22efcf3e8  movq xmm1, r10
00007fa22efcf3ed  movq xmm10, xmm10
00007fa22efcf3f2  vmovaps [rsp+0x60], xmm10
00007fa22efcf3f8  movq xmm10, xmm10
00007fa22efcf3fd  movaps [r15+0x130], xmm10
00007fa22efcf405  movq xmm1, xmm1
00007fa22efcf409  vmovaps [rsp+0x70], xmm1
00007fa22efcf40f  movq xmm1, xmm1
00007fa22efcf413  movaps [r15+0x280], xmm1
00007fa22efcf41b  vmovaps [rsp+0x80], xmm9
00007fa22efcf424  vmovaps xmm1, [rsp+0x80]
00007fa22efcf42d  por xmm9, xmm1
00007fa22efcf432  lea r12, [rax+0x20]
00007fa22efcf436  mov r11, [r13+r12*1]
00007fa22efcf43b  lea r12, [rax+0x28]
00007fa22efcf43f  mov r10, [r13+r12*1]
00007fa22efcf444  movq xmm1, r11
00007fa22efcf449  movq xmm10, r10
00007fa22efcf44e  movq xmm1, xmm1
00007fa22efcf452  vmovaps [rsp+0x80], xmm1
00007fa22efcf45b  movq xmm1, xmm1
00007fa22efcf45f  movaps [r15+0x150], xmm1
00007fa22efcf467  movq xmm10, xmm10
00007fa22efcf46c  vmovaps [rsp+0x90], xmm10
00007fa22efcf475  movq xmm10, xmm10
00007fa22efcf47a  movaps [r15+0x140], xmm10
00007fa22efcf482  lea r12, [rax+0x10]
00007fa22efcf486  mov r11, [r13+r12*1]
00007fa22efcf48b  lea r12, [rax+0x18]
00007fa22efcf48f  mov r10, [r13+r12*1]
00007fa22efcf494  movq xmm1, r11
00007fa22efcf499  movq xmm10, r10
00007fa22efcf49e  movq xmm1, xmm1
00007fa22efcf4a2  vmovaps [rsp+0xA0], xmm1
00007fa22efcf4ab  movq xmm1, xmm1
00007fa22efcf4af  movaps [r15+0x170], xmm1
00007fa22efcf4b7  movq xmm10, xmm10
00007fa22efcf4bc  vmovaps [rsp+0xB0], xmm10
00007fa22efcf4c5  movq xmm10, xmm10
00007fa22efcf4ca  movaps [r15+0x160], xmm10
00007fa22efcf4d2  mov r12, [r13+rax*1]
00007fa22efcf4d7  vmovq xmm1, r12
00007fa22efcf4dc  vpbroadcastq xmm1, xmm1
00007fa22efcf4e1  lea r12, [rax+0x08]
00007fa22efcf4e5  mov rax, [r13+r12*1]
00007fa22efcf4ea  movq xmm10, rax
00007fa22efcf4ef  movaps [r15+0x230], xmm10
00007fa22efcf4f7  lea rax, [r14+0x50]
00007fa22efcf4fb  movups xmm10, [r13+rax*1]
00007fa22efcf501  lea rax, [r14+0x60]
00007fa22efcf505  vmovaps [rsp+0xC0], xmm1
00007fa22efcf50e  movups xmm1, [r13+rax*1]
00007fa22efcf514  lea rax, [r14+0x30]
00007fa22efcf518  vmovaps [rsp+0xD0], xmm1
00007fa22efcf521  movups xmm1, [r13+rax*1]
00007fa22efcf527  mov qword ptr [r15+0x60], 0x430920
00007fa22efcf52f  mov qword ptr [r15+0x58], 0x40
00007fa22efcf537  vmovaps [rsp+0xE0], xmm1
00007fa22efcf540  vmovaps [rsp+0xF0], xmm15
00007fa22efcf549  vmovaps xmm15, [rsp+0xC0]
00007fa22efcf552  vmovaps [rsp+0xC0], xmm14
00007fa22efcf55b  vmovaps xmm14, [rsp+0x40]
00007fa22efcf561  vmovaps [rsp+0x40], xmm13
00007fa22efcf567  movaps xmm1, xmm15
00007fa22efcf56b  mulpd xmm1, xmm14
00007fa22efcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007fa22efcf575  ptest xmm13, xmm13
00007fa22efcf57b  jnz 0x00007FA22EFD0682
00007fa22efcf581  movq xmm14, qword ptr [r15+0x230]
00007fa22efcf58a  vmovaps [rsp+0x100], xmm14
00007fa22efcf593  vpermilpd xmm14, xmm14, 0x00
00007fa22efcf599  vmovaps [rsp+0x110], xmm1
00007fa22efcf5a2  vmovaps xmm1, [rsp+0xE0]
00007fa22efcf5ab  vmovaps [rsp+0xE0], xmm15
00007fa22efcf5b4  movaps xmm13, xmm1
00007fa22efcf5b8  mulpd xmm13, xmm14
00007fa22efcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007fa22efcf5c3  ptest xmm15, xmm15
00007fa22efcf5c9  jnz 0x00007FA22EFD07C4
00007fa22efcf5cf  vxorps xmm1, xmm1, xmm1
00007fa22efcf5d3  vpbroadcastq xmm1, xmm1
00007fa22efcf5d8  vmovaps xmm14, [rsp+0xE0]
00007fa22efcf5e1  vmovaps [rsp+0xE0], xmm1
00007fa22efcf5ea  vmovaps xmm1, [rsp+0xD0]
00007fa22efcf5f3  vmovaps [rsp+0xD0], xmm13
00007fa22efcf5fc  movaps xmm15, xmm14
00007fa22efcf600  mulpd xmm15, xmm1
00007fa22efcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007fa22efcf60b  ptest xmm13, xmm13
00007fa22efcf611  jnz 0x00007FA22EFD0907
00007fa22efcf617  movaps xmm1, xmm14
00007fa22efcf61b  mulpd xmm1, xmm10
00007fa22efcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007fa22efcf625  ptest xmm13, xmm13
00007fa22efcf62b  jnz 0x00007FA22EFD0A4A
00007fa22efcf631  movaps xmm13, xmm14
00007fa22efcf635  mulpd xmm13, xmm2
00007fa22efcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007fa22efcf640  ptest xmm10, xmm10
00007fa22efcf646  jnz 0x00007FA22EFD0B8C
00007fa22efcf64c  vmovaps [rsp+0x120], xmm7
00007fa22efcf655  vmovaps xmm14, [rsp+0x120]
00007fa22efcf65e  por xmm7, xmm14
00007fa22efcf663  vmovaps xmm14, [rsp+0xC0]
00007fa22efcf66c  vmovaps xmm10, [rsp+0xC0]
00007fa22efcf675  por xmm14, xmm10
00007fa22efcf67a  vmovaps xmm2, [rsp+0x100]
00007fa22efcf683  vpermilpd xmm2, xmm2, 0x00
00007fa22efcf689  vmovaps [rsp+0xC0], xmm1
00007fa22efcf692  vmovaps [rsp+0x120], xmm15
00007fa22efcf69b  movaps xmm1, xmm10
00007fa22efcf69f  mulpd xmm1, xmm2
00007fa22efcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa22efcf6a8  ptest xmm15, xmm15
00007fa22efcf6ae  jnz 0x00007FA22EFD0CCF
00007fa22efcf6b4  xor eax, eax
00007fa22efcf6b6  mov r12d, 0x40
00007fa22efcf6bc  mov r11d, 0x200
00007fa22efcf6c2  cmp r12, r11
00007fa22efcf6c5  cmc
00007fa22efcf6c6  lahf
00007fa22efcf6c7  seto al
00007fa22efcf6ca  mov [r15+0x108], eax
00007fa22efcf6d1  vmovaps xmm10, [rsp+0x110]
00007fa22efcf6da  vmovaps xmm2, [rsp+0xE0]
00007fa22efcf6e3  vmovaps [rsp+0xE0], xmm1
00007fa22efcf6ec  movaps xmm15, xmm10
00007fa22efcf6f0  addpd xmm15, xmm2
00007fa22efcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa22efcf6fb  ptest xmm1, xmm1
00007fa22efcf700  jnz 0x00007FA22EFD0E10
00007fa22efcf706  vmovaps xmm10, [rsp+0x120]
00007fa22efcf70f  vmovaps [rsp+0x110], xmm15
00007fa22efcf718  movaps xmm1, xmm10
00007fa22efcf71c  addpd xmm1, xmm12
00007fa22efcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa22efcf726  ptest xmm15, xmm15
00007fa22efcf72c  jnz 0x00007FA22EFD0F53
00007fa22efcf732  vmovaps xmm10, [rsp+0xC0]
00007fa22efcf73b  vmovaps [rsp+0xC0], xmm1
00007fa22efcf744  movaps xmm15, xmm10
00007fa22efcf748  addpd xmm15, xmm12
00007fa22efcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa22efcf753  ptest xmm1, xmm1
00007fa22efcf758  jnz 0x00007FA22EFD1095
00007fa22efcf75e  vmovaps xmm1, [rsp+0x30]
00007fa22efcf764  vmovaps xmm12, [rsp+0x30]
00007fa22efcf76a  por xmm1, xmm12
00007fa22efcf76f  vmovaps xmm12, [rsp+0x20]
00007fa22efcf775  vmovaps xmm10, [rsp+0x20]
00007fa22efcf77b  por xmm12, xmm10
00007fa22efcf780  vmovaps [rsp+0x20], xmm5
00007fa22efcf786  vmovaps xmm10, [rsp+0x20]
00007fa22efcf78c  por xmm5, xmm10
00007fa22efcf791  vmovaps [rsp+0x20], xmm11
00007fa22efcf797  vmovaps xmm10, [rsp+0x20]
00007fa22efcf79d  por xmm11, xmm10
00007fa22efcf7a2  vmovaps [rsp+0x20], xmm4
00007fa22efcf7a8  vmovaps xmm10, [rsp+0x20]
00007fa22efcf7ae  por xmm4, xmm10
00007fa22efcf7b3  vmovaps [rsp+0x20], xmm8
00007fa22efcf7b9  vmovaps xmm10, [rsp+0x20]
00007fa22efcf7bf  por xmm8, xmm10
00007fa22efcf7c4  vmovaps xmm10, [rsp+0xF0]
00007fa22efcf7cd  vmovaps [rsp+0x20], xmm1
00007fa22efcf7d3  vmovaps xmm1, [rsp+0xF0]
00007fa22efcf7dc  por xmm10, xmm1
00007fa22efcf7e1  lea rax, [r14+0xA0]
00007fa22efcf7e8  movups xmm1, [r13+rax*1]
00007fa22efcf7ee  lea rax, [r14+0xB0]
00007fa22efcf7f5  vmovaps [rsp+0x30], xmm1
00007fa22efcf7fb  movups xmm1, [r13+rax*1]
00007fa22efcf801  vmovaps [rsp+0xF0], xmm1
00007fa22efcf80a  vmovaps [rsp+0x120], xmm15
00007fa22efcf813  movaps xmm1, xmm13
00007fa22efcf817  addpd xmm1, xmm2
00007fa22efcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa22efcf820  ptest xmm15, xmm15
00007fa22efcf826  jnz 0x00007FA22EFD11ED
00007fa22efcf82c  lea rax, [r14+0xF0]
00007fa22efcf833  movups xmm15, [r13+rax*1]
00007fa22efcf839  vmovaps xmm2, [rsp+0xC0]
00007fa22efcf842  vmovaps [rsp+0xC0], xmm1
00007fa22efcf84b  vmovaps xmm1, [rsp+0xE0]
00007fa22efcf854  vmovaps [rsp+0xE0], xmm15
00007fa22efcf85d  movaps xmm13, xmm2
00007fa22efcf861  addpd xmm13, xmm1
00007fa22efcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007fa22efcf86c  ptest xmm15, xmm15
00007fa22efcf872  jnz 0x00007FA22EFD1338
00007fa22efcf878  vmovaps xmm15, [rsp+0x120]
00007fa22efcf881  vmovaps xmm2, [rsp+0xD0]
00007fa22efcf88a  vmovaps [rsp+0xD0], xmm14
00007fa22efcf893  movaps xmm1, xmm15
00007fa22efcf897  addpd xmm1, xmm2
00007fa22efcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007fa22efcf8a0  ptest xmm14, xmm14
00007fa22efcf8a6  jnz 0x00007FA22EFD147A
00007fa22efcf8ac  vmovaps xmm15, [rsp+0x100]
00007fa22efcf8b5  vpermilpd xmm15, xmm15, 0x00
00007fa22efcf8bb  vmovaps xmm2, [rsp+0xF0]
00007fa22efcf8c4  vmovaps [rsp+0xF0], xmm1
00007fa22efcf8cd  movaps xmm14, xmm2
00007fa22efcf8d1  mulpd xmm14, xmm15
00007fa22efcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007fa22efcf8dc  ptest xmm1, xmm1
00007fa22efcf8e1  jnz 0x00007FA22EFD15BB
00007fa22efcf8e7  vmovaps xmm1, [rsp+0xA0]
00007fa22efcf8f0  vpermilpd xmm1, xmm1, 0x00
00007fa22efcf8f6  vmovaps xmm2, [rsp+0xE0]
00007fa22efcf8ff  vmovaps [rsp+0xE0], xmm14
00007fa22efcf908  movaps xmm15, xmm2
00007fa22efcf90c  mulpd xmm15, xmm1
00007fa22efcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007fa22efcf917  ptest xmm14, xmm14
00007fa22efcf91d  jnz 0x00007FA22EFD16FE
00007fa22efcf923  lea rax, [r14+0xE0]
00007fa22efcf92a  movups xmm1, [r13+rax*1]
00007fa22efcf930  vmovaps xmm14, [rsp+0x100]
00007fa22efcf939  vpermilpd xmm14, xmm14, 0x00
00007fa22efcf93f  vmovaps [rsp+0x100], xmm1
00007fa22efcf948  vmovaps xmm1, [rsp+0x30]
00007fa22efcf94e  vmovaps [rsp+0x30], xmm15
00007fa22efcf954  movaps xmm2, xmm1
00007fa22efcf957  mulpd xmm2, xmm14
00007fa22efcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007fa22efcf961  ptest xmm15, xmm15
00007fa22efcf967  jnz 0x00007FA22EFD184A
00007fa22efcf96d  vmovaps [rsp+0x120], xmm10
00007fa22efcf976  vmovaps xmm1, [rsp+0x120]
00007fa22efcf97f  por xmm10, xmm1
00007fa22efcf984  movaps [r15+0x300], xmm10
00007fa22efcf98c  vmovaps [rsp+0x120], xmm8
00007fa22efcf995  vmovaps xmm1, [rsp+0x120]
00007fa22efcf99e  por xmm8, xmm1
00007fa22efcf9a3  movaps [r15+0x190], xmm8
00007fa22efcf9ab  vmovaps xmm1, [rsp+0xA0]
00007fa22efcf9b4  vpermilpd xmm1, xmm1, 0x00
00007fa22efcf9ba  vmovaps xmm14, [rsp+0x100]
00007fa22efcf9c3  vmovaps [rsp+0x100], xmm13
00007fa22efcf9cc  movaps xmm15, xmm14
00007fa22efcf9d0  mulpd xmm15, xmm1
00007fa22efcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007fa22efcf9db  ptest xmm13, xmm13
00007fa22efcf9e1  jnz 0x00007FA22EFD198B
00007fa22efcf9e7  lea rax, [r14+0x90]
00007fa22efcf9ee  movups xmm1, [r13+rax*1]
00007fa22efcf9f4  vmovaps [rsp+0x120], xmm4
00007fa22efcf9fd  vmovaps xmm14, [rsp+0x120]
00007fa22efcfa06  por xmm4, xmm14
00007fa22efcfa0b  movaps [r15+0x1C0], xmm4
00007fa22efcfa13  vmovaps [rsp+0x120], xmm11
00007fa22efcfa1c  vmovaps xmm14, [rsp+0x120]
00007fa22efcfa25  por xmm11, xmm14
00007fa22efcfa2a  movaps [r15+0x200], xmm11
00007fa22efcfa32  vmovaps [rsp+0x120], xmm5
00007fa22efcfa3b  vmovaps xmm14, [rsp+0x120]
00007fa22efcfa44  por xmm5, xmm14
00007fa22efcfa49  movaps [r15+0x2D0], xmm5
00007fa22efcfa51  vmovaps [rsp+0x120], xmm12
00007fa22efcfa5a  vmovaps xmm14, [rsp+0x120]
00007fa22efcfa63  por xmm12, xmm14
00007fa22efcfa68  movaps [r15+0x2E0], xmm12
00007fa22efcfa70  vmovaps xmm13, [rsp+0x110]
00007fa22efcfa79  vmovaps [rsp+0x110], xmm1
00007fa22efcfa82  vmovaps xmm1, [rsp+0xE0]
00007fa22efcfa8b  vmovaps [rsp+0xE0], xmm15
00007fa22efcfa94  movaps xmm14, xmm13
00007fa22efcfa98  addpd xmm14, xmm1
00007fa22efcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007fa22efcfaa3  ptest xmm15, xmm15
00007fa22efcfaa9  jnz 0x00007FA22EFD1AD8
00007fa22efcfaaf  vmovaps xmm1, [rsp+0xA0]
00007fa22efcfab8  vpermilpd xmm1, xmm1, 0x00
00007fa22efcfabe  vmovaps xmm13, [rsp+0x110]
00007fa22efcfac7  vmovaps [rsp+0x110], xmm14
00007fa22efcfad0  movaps xmm15, xmm13
00007fa22efcfad4  mulpd xmm15, xmm1
00007fa22efcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007fa22efcfadf  ptest xmm14, xmm14
00007fa22efcfae5  jnz 0x00007FA22EFD1C1B
00007fa22efcfaeb  lea rax, [r14+0x80]
00007fa22efcfaf2  movups xmm1, [r13+rax*1]
00007fa22efcfaf8  vmovaps xmm13, [rsp+0xC0]
00007fa22efcfb01  vmovaps [rsp+0xC0], xmm1
00007fa22efcfb0a  movaps xmm14, xmm13
00007fa22efcfb0e  addpd xmm14, xmm2
00007fa22efcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007fa22efcfb19  ptest xmm1, xmm1
00007fa22efcfb1e  jnz 0x00007FA22EFD1D68
00007fa22efcfb24  vmovaps xmm13, [rsp+0x100]
00007fa22efcfb2d  vmovaps xmm2, [rsp+0x30]
00007fa22efcfb33  vmovaps [rsp+0x30], xmm15
00007fa22efcfb39  movaps xmm1, xmm13
00007fa22efcfb3d  addpd xmm1, xmm2
00007fa22efcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa22efcfb46  ptest xmm15, xmm15
00007fa22efcfb4c  jnz 0x00007FA22EFD1EAB
00007fa22efcfb52  vmovaps xmm15, [rsp+0x20]
00007fa22efcfb58  vmovaps xmm13, [rsp+0x20]
00007fa22efcfb5e  por xmm15, xmm13
00007fa22efcfb63  movaps [r15+0x2F0], xmm15
00007fa22efcfb6b  vmovaps xmm13, [rsp+0xA0]
00007fa22efcfb74  vpermilpd xmm13, xmm13, 0x00
00007fa22efcfb7a  vmovaps [rsp+0x20], xmm1
00007fa22efcfb80  vmovaps xmm1, [rsp+0xC0]
00007fa22efcfb89  vmovaps [rsp+0xA0], xmm15
00007fa22efcfb92  movaps xmm2, xmm1
00007fa22efcfb95  mulpd xmm2, xmm13
00007fa22efcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007fa22efcfb9f  ptest xmm15, xmm15
00007fa22efcfba5  jnz 0x00007FA22EFD1FEC
00007fa22efcfbab  lea rax, [r14+0xD0]
00007fa22efcfbb2  movups xmm1, [r13+rax*1]
00007fa22efcfbb8  vmovaps xmm13, [rsp+0xF0]
00007fa22efcfbc1  vmovaps [rsp+0xC0], xmm1
00007fa22efcfbca  vmovaps xmm1, [rsp+0xE0]
00007fa22efcfbd3  vmovaps [rsp+0xE0], xmm14
00007fa22efcfbdc  movaps xmm15, xmm13
00007fa22efcfbe0  addpd xmm15, xmm1
00007fa22efcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007fa22efcfbeb  ptest xmm14, xmm14
00007fa22efcfbf1  jnz 0x00007FA22EFD2137
00007fa22efcfbf7  vmovaps xmm1, [rsp+0xB0]
00007fa22efcfc00  vpermilpd xmm1, xmm1, 0x00
00007fa22efcfc06  movaps xmm14, xmm11
00007fa22efcfc0a  mulpd xmm14, xmm1
00007fa22efcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007fa22efcfc15  ptest xmm13, xmm13
00007fa22efcfc1b  jnz 0x00007FA22EFD227A
00007fa22efcfc21  movaps [r15+0x260], xmm14
00007fa22efcfc29  vxorps xmm1, xmm1, xmm1
00007fa22efcfc2d  vpbroadcastq xmm1, xmm1
00007fa22efcfc32  movaps [r15+0x1B0], xmm1
00007fa22efcfc3a  vmovaps xmm1, [rsp+0xB0]
00007fa22efcfc43  vpermilpd xmm1, xmm1, 0x00
00007fa22efcfc49  vmovaps xmm11, [rsp+0xC0]
00007fa22efcfc52  vmovaps [rsp+0xC0], xmm15
00007fa22efcfc5b  movaps xmm13, xmm11
00007fa22efcfc5f  mulpd xmm13, xmm1
00007fa22efcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007fa22efcfc6a  ptest xmm15, xmm15
00007fa22efcfc70  jnz 0x00007FA22EFD23BD
00007fa22efcfc76  lea rax, [r14+0xC0]
00007fa22efcfc7d  movups xmm1, [r13+rax*1]
00007fa22efcfc83  vmovaps xmm11, [rsp+0x110]
00007fa22efcfc8c  vmovaps [rsp+0xF0], xmm1
00007fa22efcfc95  vmovaps xmm1, [rsp+0x30]
00007fa22efcfc9b  vmovaps [rsp+0x30], xmm14
00007fa22efcfca1  movaps xmm15, xmm11
00007fa22efcfca5  addpd xmm15, xmm1
00007fa22efcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007fa22efcfcb0  ptest xmm14, xmm14
00007fa22efcfcb6  jnz 0x00007FA22EFD250A
00007fa22efcfcbc  vmovaps [rsp+0x100], xmm9
00007fa22efcfcc5  vmovaps xmm1, [rsp+0x100]
00007fa22efcfcce  por xmm9, xmm1
00007fa22efcfcd3  movaps [r15+0x270], xmm9
00007fa22efcfcdb  vmovaps [rsp+0x100], xmm6
00007fa22efcfce4  vmovaps xmm1, [rsp+0x100]
00007fa22efcfced  por xmm6, xmm1
00007fa22efcfcf1  movaps [r15+0x1A0], xmm6
00007fa22efcfcf9  vmovaps xmm14, [rsp+0xB0]
00007fa22efcfd02  vpermilpd xmm14, xmm14, 0x00
00007fa22efcfd08  vmovaps xmm6, [rsp+0xF0]
00007fa22efcfd11  vmovaps [rsp+0xF0], xmm1
00007fa22efcfd1a  movaps xmm11, xmm6
00007fa22efcfd1e  mulpd xmm11, xmm14
00007fa22efcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007fa22efcfd29  ptest xmm1, xmm1
00007fa22efcfd2e  jnz 0x00007FA22EFD264D
00007fa22efcfd34  lea rax, [r14+0x20]
00007fa22efcfd38  movups xmm1, [r13+rax*1]
00007fa22efcfd3e  movaps [r15+0x110], xmm1
00007fa22efcfd46  vmovaps xmm6, [rsp+0xE0]
00007fa22efcfd4f  vmovaps [rsp+0xE0], xmm1
00007fa22efcfd58  movaps xmm14, xmm6
00007fa22efcfd5c  addpd xmm14, xmm2
00007fa22efcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007fa22efcfd67  ptest xmm1, xmm1
00007fa22efcfd6c  jnz 0x00007FA22EFD279A
00007fa22efcfd72  vmovaps xmm1, [rsp+0xB0]
00007fa22efcfd7b  vpermilpd xmm1, xmm1, 0x00
00007fa22efcfd81  movaps xmm6, xmm5
00007fa22efcfd84  mulpd xmm6, xmm1
00007fa22efcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007fa22efcfd8d  ptest xmm2, xmm2
00007fa22efcfd92  jnz 0x00007FA22EFD28DC
00007fa22efcfd98  vmovaps xmm5, [rsp+0x20]
00007fa22efcfd9e  movaps xmm1, xmm5
00007fa22efcfda1  addpd xmm1, xmm13
00007fa22efcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa22efcfdab  ptest xmm2, xmm2
00007fa22efcfdb0  jnz 0x00007FA22EFD2A1C
00007fa22efcfdb6  vmovaps xmm13, [rsp+0x80]
00007fa22efcfdbf  vpermilpd xmm13, xmm13, 0x00
00007fa22efcfdc5  vmovaps xmm2, [rsp+0xE0]
00007fa22efcfdce  vmovaps [rsp+0x20], xmm1
00007fa22efcfdd4  movaps xmm5, xmm2
00007fa22efcfdd7  mulpd xmm5, xmm13
00007fa22efcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007fa22efcfde1  ptest xmm1, xmm1
00007fa22efcfde6  jnz 0x00007FA22EFD2B5D
00007fa22efcfdec  vmovaps xmm1, [rsp+0x80]
00007fa22efcfdf5  vpermilpd xmm1, xmm1, 0x00
00007fa22efcfdfb  movaps xmm13, xmm10
00007fa22efcfdff  mulpd xmm13, xmm1
00007fa22efcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007fa22efcfe0a  ptest xmm2, xmm2
00007fa22efcfe0f  jnz 0x00007FA22EFD2C9E
00007fa22efcfe15  vmovaps xmm10, [rsp+0x30]
00007fa22efcfe1b  movaps xmm1, xmm15
00007fa22efcfe1f  addpd xmm1, xmm10
00007fa22efcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa22efcfe29  ptest xmm2, xmm2
00007fa22efcfe2e  jnz 0x00007FA22EFD2DE1
00007fa22efcfe34  vmovaps xmm10, [rsp+0xC0]
00007fa22efcfe3d  movaps xmm15, xmm10
00007fa22efcfe41  addpd xmm15, xmm11
00007fa22efcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007fa22efcfe4c  ptest xmm2, xmm2
00007fa22efcfe51  jnz 0x00007FA22EFD2F23
00007fa22efcfe57  vmovaps xmm11, [rsp+0x80]
00007fa22efcfe60  vpermilpd xmm11, xmm11, 0x00
00007fa22efcfe66  movaps xmm10, xmm12
00007fa22efcfe6a  mulpd xmm10, xmm11
00007fa22efcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007fa22efcfe75  ptest xmm2, xmm2
00007fa22efcfe7a  jnz 0x00007FA22EFD3067
00007fa22efcfe80  vmovaps xmm12, [rsp+0x80]
00007fa22efcfe89  vpermilpd xmm12, xmm12, 0x00
00007fa22efcfe8f  vmovaps xmm2, [rsp+0xA0]
00007fa22efcfe98  vmovaps [rsp+0x30], xmm1
00007fa22efcfe9e  movaps xmm11, xmm2
00007fa22efcfea2  mulpd xmm11, xmm12
00007fa22efcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007fa22efcfead  ptest xmm1, xmm1
00007fa22efcfeb2  jnz 0x00007FA22EFD31AB
00007fa22efcfeb8  movaps xmm1, xmm14
00007fa22efcfebc  addpd xmm1, xmm6
00007fa22efcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa22efcfec5  ptest xmm12, xmm12
00007fa22efcfecb  jnz 0x00007FA22EFD32EE
00007fa22efcfed1  vmovaps xmm12, [rsp+0x20]
00007fa22efcfed7  movaps xmm14, xmm12
00007fa22efcfedb  addpd xmm14, xmm5
00007fa22efcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007fa22efcfee6  ptest xmm6, xmm6
00007fa22efcfeeb  jnz 0x00007FA22EFD342F
00007fa22efcfef1  vmovaps xmm12, [rsp+0x90]
00007fa22efcfefa  vpermilpd xmm12, xmm12, 0x00
00007fa22efcff00  movaps xmm6, xmm9
00007fa22efcff04  mulpd xmm6, xmm12
00007fa22efcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007fa22efcff0e  ptest xmm5, xmm5
00007fa22efcff13  jnz 0x00007FA22EFD3572
00007fa22efcff19  movaps xmm12, xmm15
00007fa22efcff1d  addpd xmm12, xmm13
00007fa22efcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007fa22efcff28  ptest xmm9, xmm9
00007fa22efcff2e  jnz 0x00007FA22EFD36B4
00007fa22efcff34  vmovaps xmm13, [rsp+0x30]
00007fa22efcff3a  movaps xmm15, xmm13
00007fa22efcff3e  addpd xmm15, xmm10
00007fa22efcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007fa22efcff49  ptest xmm9, xmm9
00007fa22efcff4f  jnz 0x00007FA22EFD37F8
00007fa22efcff55  vmovaps xmm13, [rsp+0xD0]
00007fa22efcff5e  vmovaps xmm10, [rsp+0xD0]
00007fa22efcff67  por xmm13, xmm10
00007fa22efcff6c  movaps [r15+0x250], xmm13
00007fa22efcff74  vmovaps [rsp+0x20], xmm7
00007fa22efcff7a  vmovaps xmm13, [rsp+0x20]
00007fa22efcff80  por xmm7, xmm13
00007fa22efcff85  movaps [r15+0x2A0], xmm7
00007fa22efcff8d  vmovaps [rsp+0x20], xmm3
00007fa22efcff93  vmovaps xmm13, [rsp+0x20]
00007fa22efcff99  por xmm3, xmm13
00007fa22efcff9e  movaps [r15+0x1D0], xmm3
00007fa22efcffa6  lea rax, [r14+0x40]
00007fa22efcffaa  movups xmm13, [r13+rax*1]
00007fa22efcffb0  movaps [r15+0x2C0], xmm13
00007fa22efcffb8  vmovaps xmm10, [rsp+0x90]
00007fa22efcffc1  vpermilpd xmm10, xmm10, 0x00
00007fa22efcffc7  movaps xmm9, xmm8
00007fa22efcffcb  mulpd xmm9, xmm10
00007fa22efcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007fa22efcffd6  ptest xmm5, xmm5
00007fa22efcffdb  jnz 0x00007FA22EFD3946
00007fa22efcffe1  movaps xmm10, xmm1
00007fa22efcffe5  addpd xmm10, xmm11
00007fa22efcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007fa22efcfff0  ptest xmm8, xmm8
00007fa22efcfff6  jnz 0x00007FA22EFD3A8A
00007fa22efcfffc  movaps xmm1, xmm14
00007fa22efd0000  addpd xmm1, xmm6
00007fa22efd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007fa22efd0009  ptest xmm11, xmm11
00007fa22efd000f  jnz 0x00007FA22EFD3BCD
00007fa22efd0015  vmovaps xmm14, [rsp+0x90]
00007fa22efd001e  vpermilpd xmm14, xmm14, 0x00
00007fa22efd0024  movaps xmm11, xmm13
00007fa22efd0028  mulpd xmm11, xmm14
00007fa22efd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007fa22efd0033  ptest xmm8, xmm8
00007fa22efd0039  jnz 0x00007FA22EFD3D0E
00007fa22efd003f  vmovaps xmm14, [rsp+0x90]
00007fa22efd0048  vpermilpd xmm14, xmm14, 0x00
00007fa22efd004e  vmovaps xmm8, [rsp+0x10]
00007fa22efd0054  movaps xmm13, xmm8
00007fa22efd0058  mulpd xmm13, xmm14
00007fa22efd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007fa22efd0063  ptest xmm6, xmm6
00007fa22efd0068  jnz 0x00007FA22EFD3E52
00007fa22efd006e  vmovaps xmm14, [rsp+0x60]
00007fa22efd0074  vpermilpd xmm14, xmm14, 0x00
00007fa22efd007a  movaps xmm8, xmm7
00007fa22efd007e  mulpd xmm8, xmm14
00007fa22efd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007fa22efd0089  ptest xmm6, xmm6
00007fa22efd008e  jnz 0x00007FA22EFD3F96
00007fa22efd0094  movaps xmm14, xmm12
00007fa22efd0098  addpd xmm14, xmm9
00007fa22efd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007fa22efd00a3  ptest xmm7, xmm7
00007fa22efd00a8  jnz 0x00007FA22EFD40D9
00007fa22efd00ae  vmovaps xmm12, [rsp+0x60]
00007fa22efd00b4  vpermilpd xmm12, xmm12, 0x00
00007fa22efd00ba  vmovaps xmm7, [rsp+0xF0]
00007fa22efd00c3  movaps xmm9, xmm7
00007fa22efd00c7  mulpd xmm9, xmm12
00007fa22efd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007fa22efd00d2  ptest xmm6, xmm6
00007fa22efd00d7  jnz 0x00007FA22EFD421D
00007fa22efd00dd  movaps xmm12, xmm15
00007fa22efd00e1  addpd xmm12, xmm11
00007fa22efd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007fa22efd00ec  ptest xmm7, xmm7
00007fa22efd00f1  jnz 0x00007FA22EFD4360
00007fa22efd00f7  vmovaps xmm15, [rsp+0x60]
00007fa22efd00fd  vpermilpd xmm15, xmm15, 0x00
00007fa22efd0103  vmovaps xmm7, [rsp+0x40]
00007fa22efd0109  movaps xmm11, xmm7
00007fa22efd010d  mulpd xmm11, xmm15
00007fa22efd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007fa22efd0118  ptest xmm6, xmm6
00007fa22efd011d  jnz 0x00007FA22EFD44A4
00007fa22efd0123  movaps xmm15, xmm10
00007fa22efd0127  addpd xmm15, xmm13
00007fa22efd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007fa22efd0132  ptest xmm7, xmm7
00007fa22efd0137  jnz 0x00007FA22EFD45E7
00007fa22efd013d  vmovaps xmm13, [rsp+0x60]
00007fa22efd0143  vpermilpd xmm13, xmm13, 0x00
00007fa22efd0149  vmovaps xmm7, [rsp+0x50]
00007fa22efd014f  movaps xmm10, xmm7
00007fa22efd0153  mulpd xmm10, xmm13
00007fa22efd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007fa22efd015e  ptest xmm6, xmm6
00007fa22efd0163  jnz 0x00007FA22EFD472B
00007fa22efd0169  movaps xmm13, xmm1
00007fa22efd016d  addpd xmm13, xmm8
00007fa22efd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007fa22efd0178  ptest xmm7, xmm7
00007fa22efd017d  jnz 0x00007FA22EFD486E
00007fa22efd0183  lea rax, [r14+0x70]
00007fa22efd0187  movups xmm1, [r13+rax*1]
00007fa22efd018d  movaps [r15+0x240], xmm1
00007fa22efd0195  movaps xmm8, xmm14
00007fa22efd0199  addpd xmm8, xmm9
00007fa22efd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007fa22efd01a4  ptest xmm7, xmm7
00007fa22efd01a9  jnz 0x00007FA22EFD49BB
00007fa22efd01af  movaps [r15+0x170], xmm8
00007fa22efd01b7  vmovaps xmm14, [rsp+0x70]
00007fa22efd01bd  vpermilpd xmm14, xmm14, 0x00
00007fa22efd01c3  movaps xmm9, xmm1
00007fa22efd01c7  mulpd xmm9, xmm14
00007fa22efd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007fa22efd01d2  ptest xmm7, xmm7
00007fa22efd01d7  jnz 0x00007FA22EFD4AFF
00007fa22efd01dd  vmovaps xmm1, [rsp+0x70]
00007fa22efd01e3  vpermilpd xmm1, xmm1, 0x00
00007fa22efd01e9  movaps xmm14, xmm4
00007fa22efd01ed  mulpd xmm14, xmm1
00007fa22efd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007fa22efd01f8  ptest xmm7, xmm7
00007fa22efd01fd  jnz 0x00007FA22EFD4C42
00007fa22efd0203  movaps [r15+0x180], xmm14
00007fa22efd020b  movaps xmm1, xmm12
00007fa22efd020f  addpd xmm1, xmm11
00007fa22efd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007fa22efd0219  ptest xmm7, xmm7
00007fa22efd021e  jnz 0x00007FA22EFD4D84
00007fa22efd0224  movaps [r15+0x210], xmm1
00007fa22efd022c  movups xmm12, [r13+r14*1]
00007fa22efd0232  lea rax, [r14+0x10]
00007fa22efd0236  movups xmm11, [r13+rax*1]
00007fa22efd023c  movaps [r15+0x230], xmm11
00007fa22efd0244  movaps xmm7, xmm15
00007fa22efd0248  addpd xmm7, xmm10
00007fa22efd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa22efd0252  ptest xmm6, xmm6
00007fa22efd0257  jnz 0x00007FA22EFD4EDA
00007fa22efd025d  movaps [r15+0x130], xmm7
00007fa22efd0265  vmovaps xmm15, [rsp+0x70]
00007fa22efd026b  vpermilpd xmm15, xmm15, 0x00
00007fa22efd0271  movaps xmm10, xmm11
00007fa22efd0275  mulpd xmm10, xmm15
00007fa22efd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007fa22efd0280  ptest xmm6, xmm6
00007fa22efd0285  jnz 0x00007FA22EFD501C
00007fa22efd028b  movaps [r15+0x220], xmm10
00007fa22efd0293  vmovaps xmm15, [rsp+0x70]
00007fa22efd0299  vpermilpd xmm15, xmm15, 0x00
00007fa22efd029f  movaps xmm11, xmm12
00007fa22efd02a3  mulpd xmm11, xmm15
00007fa22efd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007fa22efd02ae  ptest xmm6, xmm6
00007fa22efd02b3  jnz 0x00007FA22EFD5160
00007fa22efd02b9  movaps xmm15, xmm13
00007fa22efd02bd  addpd xmm15, xmm9
00007fa22efd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007fa22efd02c8  ptest xmm12, xmm12
00007fa22efd02ce  jnz 0x00007FA22EFD52A4
00007fa22efd02d4  movaps [r15+0x140], xmm15
00007fa22efd02dc  movaps xmm13, xmm8
00007fa22efd02e0  addpd xmm13, xmm14
00007fa22efd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007fa22efd02eb  ptest xmm12, xmm12
00007fa22efd02f1  jnz 0x00007FA22EFD53E8
00007fa22efd02f7  movaps [r15+0x150], xmm13
00007fa22efd02ff  movaps xmm14, xmm1
00007fa22efd0303  addpd xmm14, xmm10
00007fa22efd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007fa22efd030e  ptest xmm12, xmm12
00007fa22efd0314  jnz 0x00007FA22EFD552C
00007fa22efd031a  movaps [r15+0x160], xmm14
00007fa22efd0322  movaps xmm1, xmm7
00007fa22efd0325  addpd xmm1, xmm11
00007fa22efd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa22efd032f  ptest xmm12, xmm12
00007fa22efd0335  jnz 0x00007FA22EFD566F
00007fa22efd033b  movaps [r15+0x120], xmm1
00007fa22efd0343  mov eax, 0x430920
00007fa22efd0348  movups [r13+rax*1], xmm15
00007fa22efd034e  mov eax, 0x430930
00007fa22efd0353  movups [r13+rax*1], xmm13
00007fa22efd0359  mov eax, 0x430940
00007fa22efd035e  movups [r13+rax*1], xmm14
00007fa22efd0364  mov eax, 0x430950
00007fa22efd0369  movups [r13+rax*1], xmm1
00007fa22efd036f  mov eax, [r15+0x108]
00007fa22efd0376  sahf
00007fa22efd0377  jnz 0x00007FA22EFD03A9
00007fa22efd0379  cmp dword ptr [r15+0x318], 0x00
00007fa22efd0381  jz 0x00007FA22EFDB900
00007fa22efd0387  nop [rax+rax*1], ax
00007fa22efd0390  nop [rax+rax*1], eax
00007fa22efd0398  mov eax, 0x410444
00007fa22efd039d  mov [r15+0x100], rax
00007fa22efd03a4  jmp 0x00007FA22EDFE110
00007fa22efd03a9  cmp dword ptr [r15+0x318], 0x00
00007fa22efd03b1  jz 0x00007FA22EFD57E0
00007fa22efd03b7  nop [rax+rax*1], ax
00007fa22efd03c0  nop [rax+rax*1], eax
00007fa22efd03c8  mov eax, 0x410278
00007fa22efd03cd  mov [r15+0x100], rax
00007fa22efd03d4  jmp 0x00007FA22EDFE110
00007fa22efd03d9  int3
00007fa22efd03da  call 0x00007FA22EEB52F0
00007fa22efd03df  jmp 0x00007FA22EFCF016
00007fa22efd03e4  call 0x00007FA22EEC4620
00007fa22efd03e9  jmp 0x00007FA22EFCF023
00007fa22efd03ee  call 0x00007FA22EEC33A0
00007fa22efd03f3  jmp 0x00007FA22EFCF035
00007fa22efd03f8  call 0x00007FA22EEC2120
00007fa22efd03fd  jmp 0x00007FA22EFCF03F
00007fa22efd0402  call 0x00007FA22EEC0860
00007fa22efd0407  jmp 0x00007FA22EFCF067
00007fa22efd040c  call 0x00007FA22EEBF5F0
00007fa22efd0411  jmp 0x00007FA22EFCF073
00007fa22efd0416  call 0x00007FA22EEC0860
00007fa22efd041b  jmp 0x00007FA22EFCF0A5
00007fa22efd0420  call 0x00007FA22EEBF5F0
00007fa22efd0425  jmp 0x00007FA22EFCF0B1
00007fa22efd042a  call 0x00007FA22EEC4740
00007fa22efd042f  jmp 0x00007FA22EFCF0BE
00007fa22efd0434  call 0x00007FA22EEB5400
00007fa22efd0439  jmp 0x00007FA22EFCF0CB
00007fa22efd043e  call 0x00007FA22EEB52F0
00007fa22efd0443  jmp 0x00007FA22EFCF0D8
00007fa22efd0448  call 0x00007FA22EEC4620
00007fa22efd044d  jmp 0x00007FA22EFCF0E5
00007fa22efd0452  call 0x00007FA22EEC0860
00007fa22efd0457  jmp 0x00007FA22EFCF10D
00007fa22efd045c  call 0x00007FA22EEBF5F0
00007fa22efd0461  jmp 0x00007FA22EFCF119
00007fa22efd0466  call 0x00007FA22EE09D70
00007fa22efd046b  jmp 0x00007FA22EFCF11F
00007fa22efd0470  call 0x00007FA22EEBE9C0
00007fa22efd0475  jmp 0x00007FA22EFCF129
00007fa22efd047a  call 0x00007FA22EEC0860
00007fa22efd047f  jmp 0x00007FA22EFCF151
00007fa22efd0484  call 0x00007FA22EEBF5F0
00007fa22efd0489  jmp 0x00007FA22EFCF15D
00007fa22efd048e  call 0x00007FA22EEBD750
00007fa22efd0493  jmp 0x00007FA22EFCF16A
00007fa22efd0498  call 0x00007FA22EEBC4E0
00007fa22efd049d  jmp 0x00007FA22EFCF177
00007fa22efd04a2  call 0x00007FA22EEC4740
00007fa22efd04a7  jmp 0x00007FA22EFCF184
00007fa22efd04ac  call 0x00007FA22EEB5400
00007fa22efd04b1  jmp 0x00007FA22EFCF191
00007fa22efd04b6  call 0x00007FA22EEB52F0
00007fa22efd04bb  jmp 0x00007FA22EFCF19E
00007fa22efd04c0  call 0x00007FA22EEC4620
00007fa22efd04c5  jmp 0x00007FA22EFCF1AB
00007fa22efd04ca  call 0x00007FA22EEC0860
00007fa22efd04cf  jmp 0x00007FA22EFCF1BE
00007fa22efd04d4  call 0x00007FA22EEBB270
00007fa22efd04d9  jmp 0x00007FA22EFCF1CB
00007fa22efd04de  call 0x00007FA22EEBA000
00007fa22efd04e3  jmp 0x00007FA22EFCF1D8
00007fa22efd04e8  call 0x00007FA22EEB8D90
00007fa22efd04ed  jmp 0x00007FA22EFCF1E5
00007fa22efd04f2  call 0x00007FA22EEB8A20
00007fa22efd04f7  jmp 0x00007FA22EFCF1F2
00007fa22efd04fc  call 0x00007FA22EEB5400
00007fa22efd0501  jmp 0x00007FA22EFCF1FC
00007fa22efd0506  call 0x00007FA22EEC2240
00007fa22efd050b  jmp 0x00007FA22EFCF206
00007fa22efd0510  call 0x00007FA22EEB52F0
00007fa22efd0515  jmp 0x00007FA22EFCF210
00007fa22efd051a  call 0x00007FA22EEC2120
00007fa22efd051f  jmp 0x00007FA22EFCF21A
00007fa22efd0524  call 0x00007FA22EEB77B0
00007fa22efd0529  jmp 0x00007FA22EFCF224
00007fa22efd052e  call 0x00007FA22EEB6550
00007fa22efd0533  jmp 0x00007FA22EFCF22E
00007fa22efd0538  call 0x00007FA22EEBFD50
00007fa22efd053d  jmp 0x00007FA22EFCF240
00007fa22efd0542  call 0x00007FA22EEB8EA0
00007fa22efd0547  jmp 0x00007FA22EFCF24A
00007fa22efd054c  call 0x00007FA22EEBFC30
00007fa22efd0551  jmp 0x00007FA22EFCF257
00007fa22efd0556  call 0x00007FA22EEB8D90
00007fa22efd055b  jmp 0x00007FA22EFCF264
00007fa22efd0560  call 0x00007FA22EEC2240
00007fa22efd0565  jmp 0x00007FA22EFCF271
00007fa22efd056a  call 0x00007FA22EEB5400
00007fa22efd056f  jmp 0x00007FA22EFCF27E
00007fa22efd0574  call 0x00007FA22EEB52F0
00007fa22efd0579  jmp 0x00007FA22EFCF28B
00007fa22efd057e  call 0x00007FA22EEC2120
00007fa22efd0583  jmp 0x00007FA22EFCF298
00007fa22efd0588  call 0x00007FA22EEB52F0
00007fa22efd058d  jmp 0x00007FA22EFCF2AB
00007fa22efd0592  call 0x00007FA22EEB52F0
00007fa22efd0597  jmp 0x00007FA22EFCF2BE
00007fa22efd059c  call 0x00007FA22EEB52F0
00007fa22efd05a1  jmp 0x00007FA22EFCF2D1
00007fa22efd05a6  call 0x00007FA22EEB52F0
00007fa22efd05ab  jmp 0x00007FA22EFCF2E4
00007fa22efd05b0  call 0x00007FA22EEC2240
00007fa22efd05b5  jmp 0x00007FA22EFCF2F9
00007fa22efd05ba  call 0x00007FA22EEC2240
00007fa22efd05bf  jmp 0x00007FA22EFCF30C
00007fa22efd05c4  call 0x00007FA22EEC2120
00007fa22efd05c9  jmp 0x00007FA22EFCF319
00007fa22efd05ce  call 0x00007FA22EEB52F0
00007fa22efd05d3  jmp 0x00007FA22EFCF32C
00007fa22efd05d8  call 0x00007FA22EEB52F0
00007fa22efd05dd  jmp 0x00007FA22EFCF34F
00007fa22efd05e2  call 0x00007FA22EEB52F0
00007fa22efd05e7  jmp 0x00007FA22EFCF362
00007fa22efd05ec  call 0x00007FA22EDFF540
00007fa22efd05f1  jmp 0x00007FA22EFCF380
00007fa22efd05f6  call 0x00007FA22EE08C20
00007fa22efd05fb  jmp 0x00007FA22EFCF38A
00007fa22efd0600  call 0x00007FA22EED6600
00007fa22efd0605  jmp 0x00007FA22EFCF396
00007fa22efd060a  call 0x00007FA22EDFF540
00007fa22efd060f  jmp 0x00007FA22EFCF3A6
00007fa22efd0614  call 0x00007FA22EEC0370
00007fa22efd0619  jmp 0x00007FA22EFCF3D4
00007fa22efd061e  call 0x00007FA22EEBF100
00007fa22efd0623  jmp 0x00007FA22EFCF3DD
00007fa22efd0628  call 0x00007FA22EEC0370
00007fa22efd062d  jmp 0x00007FA22EFCF43B
00007fa22efd0632  call 0x00007FA22EEBF100
00007fa22efd0637  jmp 0x00007FA22EFCF444
00007fa22efd063c  call 0x00007FA22EEC0370
00007fa22efd0641  jmp 0x00007FA22EFCF48B
00007fa22efd0646  call 0x00007FA22EEBF100
00007fa22efd064b  jmp 0x00007FA22EFCF494
00007fa22efd0650  call 0x00007FA22EE0B720
00007fa22efd0655  jmp 0x00007FA22EFCF4D7
00007fa22efd065a  call 0x00007FA22EEB47C0
00007fa22efd065f  jmp 0x00007FA22EFCF4EA
00007fa22efd0664  call 0x00007FA22EE08B00
00007fa22efd0669  jmp 0x00007FA22EFCF501
00007fa22efd066e  call 0x00007FA22EDFF430
00007fa22efd0673  jmp 0x00007FA22EFCF514
00007fa22efd0678  call 0x00007FA22EDFF430
00007fa22efd067d  jmp 0x00007FA22EFCF527
00007fa22efd0682  sub rsp, 0x08
00007fa22efd0686  push rax
00007fa22efd0687  push rcx
00007fa22efd0688  push rdx
00007fa22efd0689  push rdi
00007fa22efd068a  push rsi
00007fa22efd068b  push r8
00007fa22efd068d  push r9
00007fa22efd068f  push r10
00007fa22efd0691  push r11
00007fa22efd0693  sub rsp, 0xF0
00007fa22efd069a  vmovaps [rsp], xmm0
00007fa22efd069f  vmovaps [rsp+0x10], xmm2
00007fa22efd06a5  vmovaps [rsp+0x20], xmm3
00007fa22efd06ab  vmovaps [rsp+0x30], xmm4
00007fa22efd06b1  vmovaps [rsp+0x40], xmm5
00007fa22efd06b7  vmovaps [rsp+0x50], xmm6
00007fa22efd06bd  vmovaps [rsp+0x60], xmm7
00007fa22efd06c3  vmovaps [rsp+0x70], xmm8
00007fa22efd06c9  vmovaps [rsp+0x80], xmm9
00007fa22efd06d2  vmovaps [rsp+0x90], xmm10
00007fa22efd06db  vmovaps [rsp+0xA0], xmm11
00007fa22efd06e4  vmovaps [rsp+0xB0], xmm12
00007fa22efd06ed  vmovaps [rsp+0xC0], xmm13
00007fa22efd06f6  vmovaps [rsp+0xD0], xmm14
00007fa22efd06ff  vmovaps [rsp+0xE0], xmm15
00007fa22efd0708  sub rsp, 0x30
00007fa22efd070c  movaps [rsp], xmm1
00007fa22efd0710  movaps [rsp+0x10], xmm15
00007fa22efd0716  movaps [rsp+0x20], xmm14
00007fa22efd071c  lea rdi, [rsp]
00007fa22efd0720  mov esi, 0x00
00007fa22efd0725  mov rax, 0x5E9D1A57D530
00007fa22efd072f  call rax
00007fa22efd0731  movaps xmm1, [rsp]
00007fa22efd0735  add rsp, 0x30
00007fa22efd0739  vmovaps xmm0, [rsp]
00007fa22efd073e  vmovaps xmm2, [rsp+0x10]
00007fa22efd0744  vmovaps xmm3, [rsp+0x20]
00007fa22efd074a  vmovaps xmm4, [rsp+0x30]
00007fa22efd0750  vmovaps xmm5, [rsp+0x40]
00007fa22efd0756  vmovaps xmm6, [rsp+0x50]
00007fa22efd075c  vmovaps xmm7, [rsp+0x60]
00007fa22efd0762  vmovaps xmm8, [rsp+0x70]
00007fa22efd0768  vmovaps xmm9, [rsp+0x80]
00007fa22efd0771  vmovaps xmm10, [rsp+0x90]
00007fa22efd077a  vmovaps xmm11, [rsp+0xA0]
00007fa22efd0783  vmovaps xmm12, [rsp+0xB0]
00007fa22efd078c  vmovaps xmm13, [rsp+0xC0]
00007fa22efd0795  vmovaps xmm14, [rsp+0xD0]
00007fa22efd079e  vmovaps xmm15, [rsp+0xE0]
00007fa22efd07a7  add rsp, 0xF0
00007fa22efd07ae  pop r11
00007fa22efd07b0  pop r10
00007fa22efd07b2  pop r9
00007fa22efd07b4  pop r8
00007fa22efd07b6  pop rsi
00007fa22efd07b7  pop rdi
00007fa22efd07b8  pop rdx
00007fa22efd07b9  pop rcx
00007fa22efd07ba  pop rax
00007fa22efd07bb  add rsp, 0x08
00007fa22efd07bf  jmp 0x00007FA22EFCF581
00007fa22efd07c4  sub rsp, 0x08
00007fa22efd07c8  push rax
00007fa22efd07c9  push rcx
00007fa22efd07ca  push rdx
00007fa22efd07cb  push rdi
00007fa22efd07cc  push rsi
00007fa22efd07cd  push r8
00007fa22efd07cf  push r9
00007fa22efd07d1  push r10
00007fa22efd07d3  push r11
00007fa22efd07d5  sub rsp, 0xF0
00007fa22efd07dc  vmovaps [rsp], xmm0
00007fa22efd07e1  vmovaps [rsp+0x10], xmm1
00007fa22efd07e7  vmovaps [rsp+0x20], xmm2
00007fa22efd07ed  vmovaps [rsp+0x30], xmm3
00007fa22efd07f3  vmovaps [rsp+0x40], xmm4
00007fa22efd07f9  vmovaps [rsp+0x50], xmm5
00007fa22efd07ff  vmovaps [rsp+0x60], xmm6
00007fa22efd0805  vmovaps [rsp+0x70], xmm7
00007fa22efd080b  vmovaps [rsp+0x80], xmm8
00007fa22efd0814  vmovaps [rsp+0x90], xmm9
00007fa22efd081d  vmovaps [rsp+0xA0], xmm10
00007fa22efd0826  vmovaps [rsp+0xB0], xmm11
00007fa22efd082f  vmovaps [rsp+0xC0], xmm12
00007fa22efd0838  vmovaps [rsp+0xD0], xmm14
00007fa22efd0841  vmovaps [rsp+0xE0], xmm15
00007fa22efd084a  sub rsp, 0x30
00007fa22efd084e  movaps [rsp], xmm13
00007fa22efd0853  movaps [rsp+0x10], xmm1
00007fa22efd0858  movaps [rsp+0x20], xmm14
00007fa22efd085e  lea rdi, [rsp]
00007fa22efd0862  mov esi, 0x00
00007fa22efd0867  mov rax, 0x5E9D1A57D530
00007fa22efd0871  call rax
00007fa22efd0873  movaps xmm13, [rsp]
00007fa22efd0878  add rsp, 0x30
00007fa22efd087c  vmovaps xmm0, [rsp]
00007fa22efd0881  vmovaps xmm1, [rsp+0x10]
00007fa22efd0887  vmovaps xmm2, [rsp+0x20]
00007fa22efd088d  vmovaps xmm3, [rsp+0x30]
00007fa22efd0893  vmovaps xmm4, [rsp+0x40]
00007fa22efd0899  vmovaps xmm5, [rsp+0x50]
00007fa22efd089f  vmovaps xmm6, [rsp+0x60]
00007fa22efd08a5  vmovaps xmm7, [rsp+0x70]
00007fa22efd08ab  vmovaps xmm8, [rsp+0x80]
00007fa22efd08b4  vmovaps xmm9, [rsp+0x90]
00007fa22efd08bd  vmovaps xmm10, [rsp+0xA0]
00007fa22efd08c6  vmovaps xmm11, [rsp+0xB0]
00007fa22efd08cf  vmovaps xmm12, [rsp+0xC0]
00007fa22efd08d8  vmovaps xmm14, [rsp+0xD0]
00007fa22efd08e1  vmovaps xmm15, [rsp+0xE0]
00007fa22efd08ea  add rsp, 0xF0
00007fa22efd08f1  pop r11
00007fa22efd08f3  pop r10
00007fa22efd08f5  pop r9
00007fa22efd08f7  pop r8
00007fa22efd08f9  pop rsi
00007fa22efd08fa  pop rdi
00007fa22efd08fb  pop rdx
00007fa22efd08fc  pop rcx
00007fa22efd08fd  pop rax
00007fa22efd08fe  add rsp, 0x08
00007fa22efd0902  jmp 0x00007FA22EFCF5CF
00007fa22efd0907  sub rsp, 0x08
00007fa22efd090b  push rax
00007fa22efd090c  push rcx
00007fa22efd090d  push rdx
00007fa22efd090e  push rdi
00007fa22efd090f  push rsi
00007fa22efd0910  push r8
00007fa22efd0912  push r9
00007fa22efd0914  push r10
00007fa22efd0916  push r11
00007fa22efd0918  sub rsp, 0xF0
00007fa22efd091f  vmovaps [rsp], xmm0
00007fa22efd0924  vmovaps [rsp+0x10], xmm1
00007fa22efd092a  vmovaps [rsp+0x20], xmm2
00007fa22efd0930  vmovaps [rsp+0x30], xmm3
00007fa22efd0936  vmovaps [rsp+0x40], xmm4
00007fa22efd093c  vmovaps [rsp+0x50], xmm5
00007fa22efd0942  vmovaps [rsp+0x60], xmm6
00007fa22efd0948  vmovaps [rsp+0x70], xmm7
00007fa22efd094e  vmovaps [rsp+0x80], xmm8
00007fa22efd0957  vmovaps [rsp+0x90], xmm9
00007fa22efd0960  vmovaps [rsp+0xA0], xmm10
00007fa22efd0969  vmovaps [rsp+0xB0], xmm11
00007fa22efd0972  vmovaps [rsp+0xC0], xmm12
00007fa22efd097b  vmovaps [rsp+0xD0], xmm13
00007fa22efd0984  vmovaps [rsp+0xE0], xmm14
00007fa22efd098d  sub rsp, 0x30
00007fa22efd0991  movaps [rsp], xmm15
00007fa22efd0996  movaps [rsp+0x10], xmm14
00007fa22efd099c  movaps [rsp+0x20], xmm1
00007fa22efd09a1  lea rdi, [rsp]
00007fa22efd09a5  mov esi, 0x00
00007fa22efd09aa  mov rax, 0x5E9D1A57D530
00007fa22efd09b4  call rax
00007fa22efd09b6  movaps xmm15, [rsp]
00007fa22efd09bb  add rsp, 0x30
00007fa22efd09bf  vmovaps xmm0, [rsp]
00007fa22efd09c4  vmovaps xmm1, [rsp+0x10]
00007fa22efd09ca  vmovaps xmm2, [rsp+0x20]
00007fa22efd09d0  vmovaps xmm3, [rsp+0x30]
00007fa22efd09d6  vmovaps xmm4, [rsp+0x40]
00007fa22efd09dc  vmovaps xmm5, [rsp+0x50]
00007fa22efd09e2  vmovaps xmm6, [rsp+0x60]
00007fa22efd09e8  vmovaps xmm7, [rsp+0x70]
00007fa22efd09ee  vmovaps xmm8, [rsp+0x80]
00007fa22efd09f7  vmovaps xmm9, [rsp+0x90]
00007fa22efd0a00  vmovaps xmm10, [rsp+0xA0]
00007fa22efd0a09  vmovaps xmm11, [rsp+0xB0]
00007fa22efd0a12  vmovaps xmm12, [rsp+0xC0]
00007fa22efd0a1b  vmovaps xmm13, [rsp+0xD0]
00007fa22efd0a24  vmovaps xmm14, [rsp+0xE0]
00007fa22efd0a2d  add rsp, 0xF0
00007fa22efd0a34  pop r11
00007fa22efd0a36  pop r10
00007fa22efd0a38  pop r9
00007fa22efd0a3a  pop r8
00007fa22efd0a3c  pop rsi
00007fa22efd0a3d  pop rdi
00007fa22efd0a3e  pop rdx
00007fa22efd0a3f  pop rcx
00007fa22efd0a40  pop rax
00007fa22efd0a41  add rsp, 0x08
00007fa22efd0a45  jmp 0x00007FA22EFCF617
00007fa22efd0a4a  sub rsp, 0x08
00007fa22efd0a4e  push rax
00007fa22efd0a4f  push rcx
00007fa22efd0a50  push rdx
00007fa22efd0a51  push rdi
00007fa22efd0a52  push rsi
00007fa22efd0a53  push r8
00007fa22efd0a55  push r9
00007fa22efd0a57  push r10
00007fa22efd0a59  push r11
00007fa22efd0a5b  sub rsp, 0xF0
00007fa22efd0a62  vmovaps [rsp], xmm0
00007fa22efd0a67  vmovaps [rsp+0x10], xmm2
00007fa22efd0a6d  vmovaps [rsp+0x20], xmm3
00007fa22efd0a73  vmovaps [rsp+0x30], xmm4
00007fa22efd0a79  vmovaps [rsp+0x40], xmm5
00007fa22efd0a7f  vmovaps [rsp+0x50], xmm6
00007fa22efd0a85  vmovaps [rsp+0x60], xmm7
00007fa22efd0a8b  vmovaps [rsp+0x70], xmm8
00007fa22efd0a91  vmovaps [rsp+0x80], xmm9
00007fa22efd0a9a  vmovaps [rsp+0x90], xmm10
00007fa22efd0aa3  vmovaps [rsp+0xA0], xmm11
00007fa22efd0aac  vmovaps [rsp+0xB0], xmm12
00007fa22efd0ab5  vmovaps [rsp+0xC0], xmm13
00007fa22efd0abe  vmovaps [rsp+0xD0], xmm14
00007fa22efd0ac7  vmovaps [rsp+0xE0], xmm15
00007fa22efd0ad0  sub rsp, 0x30
00007fa22efd0ad4  movaps [rsp], xmm1
00007fa22efd0ad8  movaps [rsp+0x10], xmm14
00007fa22efd0ade  movaps [rsp+0x20], xmm10
00007fa22efd0ae4  lea rdi, [rsp]
00007fa22efd0ae8  mov esi, 0x00
00007fa22efd0aed  mov rax, 0x5E9D1A57D530
00007fa22efd0af7  call rax
00007fa22efd0af9  movaps xmm1, [rsp]
00007fa22efd0afd  add rsp, 0x30
00007fa22efd0b01  vmovaps xmm0, [rsp]
00007fa22efd0b06  vmovaps xmm2, [rsp+0x10]
00007fa22efd0b0c  vmovaps xmm3, [rsp+0x20]
00007fa22efd0b12  vmovaps xmm4, [rsp+0x30]
00007fa22efd0b18  vmovaps xmm5, [rsp+0x40]
00007fa22efd0b1e  vmovaps xmm6, [rsp+0x50]
00007fa22efd0b24  vmovaps xmm7, [rsp+0x60]
00007fa22efd0b2a  vmovaps xmm8, [rsp+0x70]
00007fa22efd0b30  vmovaps xmm9, [rsp+0x80]
00007fa22efd0b39  vmovaps xmm10, [rsp+0x90]
00007fa22efd0b42  vmovaps xmm11, [rsp+0xA0]
00007fa22efd0b4b  vmovaps xmm12, [rsp+0xB0]
00007fa22efd0b54  vmovaps xmm13, [rsp+0xC0]
00007fa22efd0b5d  vmovaps xmm14, [rsp+0xD0]
00007fa22efd0b66  vmovaps xmm15, [rsp+0xE0]
00007fa22efd0b6f  add rsp, 0xF0
00007fa22efd0b76  pop r11
00007fa22efd0b78  pop r10
00007fa22efd0b7a  pop r9
00007fa22efd0b7c  pop r8
00007fa22efd0b7e  pop rsi
00007fa22efd0b7f  pop rdi
00007fa22efd0b80  pop rdx
00007fa22efd0b81  pop rcx
00007fa22efd0b82  pop rax
00007fa22efd0b83  add rsp, 0x08
00007fa22efd0b87  jmp 0x00007FA22EFCF631
00007fa22efd0b8c  sub rsp, 0x08
00007fa22efd0b90  push rax
00007fa22efd0b91  push rcx
00007fa22efd0b92  push rdx
00007fa22efd0b93  push rdi
00007fa22efd0b94  push rsi
00007fa22efd0b95  push r8
00007fa22efd0b97  push r9
00007fa22efd0b99  push r10
00007fa22efd0b9b  push r11
00007fa22efd0b9d  sub rsp, 0xF0
00007fa22efd0ba4  vmovaps [rsp], xmm0
00007fa22efd0ba9  vmovaps [rsp+0x10], xmm1
00007fa22efd0baf  vmovaps [rsp+0x20], xmm2
00007fa22efd0bb5  vmovaps [rsp+0x30], xmm3
00007fa22efd0bbb  vmovaps [rsp+0x40], xmm4
00007fa22efd0bc1  vmovaps [rsp+0x50], xmm5
00007fa22efd0bc7  vmovaps [rsp+0x60], xmm6
00007fa22efd0bcd  vmovaps [rsp+0x70], xmm7
00007fa22efd0bd3  vmovaps [rsp+0x80], xmm8
00007fa22efd0bdc  vmovaps [rsp+0x90], xmm9
00007fa22efd0be5  vmovaps [rsp+0xA0], xmm10
00007fa22efd0bee  vmovaps [rsp+0xB0], xmm11
00007fa22efd0bf7  vmovaps [rsp+0xC0], xmm12
00007fa22efd0c00  vmovaps [rsp+0xD0], xmm14
00007fa22efd0c09  vmovaps [rsp+0xE0], xmm15
00007fa22efd0c12  sub rsp, 0x30
00007fa22efd0c16  movaps [rsp], xmm13
00007fa22efd0c1b  movaps [rsp+0x10], xmm14
00007fa22efd0c21  movaps [rsp+0x20], xmm2
00007fa22efd0c26  lea rdi, [rsp]
00007fa22efd0c2a  mov esi, 0x00
00007fa22efd0c2f  mov rax, 0x5E9D1A57D530
00007fa22efd0c39  call rax
00007fa22efd0c3b  movaps xmm13, [rsp]
00007fa22efd0c40  add rsp, 0x30
00007fa22efd0c44  vmovaps xmm0, [rsp]
00007fa22efd0c49  vmovaps xmm1, [rsp+0x10]
00007fa22efd0c4f  vmovaps xmm2, [rsp+0x20]
00007fa22efd0c55  vmovaps xmm3, [rsp+0x30]
00007fa22efd0c5b  vmovaps xmm4, [rsp+0x40]
00007fa22efd0c61  vmovaps xmm5, [rsp+0x50]
00007fa22efd0c67  vmovaps xmm6, [rsp+0x60]
00007fa22efd0c6d  vmovaps xmm7, [rsp+0x70]
00007fa22efd0c73  vmovaps xmm8, [rsp+0x80]
00007fa22efd0c7c  vmovaps xmm9, [rsp+0x90]
00007fa22efd0c85  vmovaps xmm10, [rsp+0xA0]
00007fa22efd0c8e  vmovaps xmm11, [rsp+0xB0]
00007fa22efd0c97  vmovaps xmm12, [rsp+0xC0]
00007fa22efd0ca0  vmovaps xmm14, [rsp+0xD0]
00007fa22efd0ca9  vmovaps xmm15, [rsp+0xE0]
00007fa22efd0cb2  add rsp, 0xF0
00007fa22efd0cb9  pop r11
00007fa22efd0cbb  pop r10
00007fa22efd0cbd  pop r9
00007fa22efd0cbf  pop r8
00007fa22efd0cc1  pop rsi
00007fa22efd0cc2  pop rdi
00007fa22efd0cc3  pop rdx
00007fa22efd0cc4  pop rcx
00007fa22efd0cc5  pop rax
00007fa22efd0cc6  add rsp, 0x08
00007fa22efd0cca  jmp 0x00007FA22EFCF64C
00007fa22efd0ccf  sub rsp, 0x08
00007fa22efd0cd3  push rax
00007fa22efd0cd4  push rcx
00007fa22efd0cd5  push rdx
00007fa22efd0cd6  push rdi
00007fa22efd0cd7  push rsi
00007fa22efd0cd8  push r8
00007fa22efd0cda  push r9
00007fa22efd0cdc  push r10
00007fa22efd0cde  push r11
00007fa22efd0ce0  sub rsp, 0xF0
00007fa22efd0ce7  vmovaps [rsp], xmm0
00007fa22efd0cec  vmovaps [rsp+0x10], xmm2
00007fa22efd0cf2  vmovaps [rsp+0x20], xmm3
00007fa22efd0cf8  vmovaps [rsp+0x30], xmm4
00007fa22efd0cfe  vmovaps [rsp+0x40], xmm5
00007fa22efd0d04  vmovaps [rsp+0x50], xmm6
00007fa22efd0d0a  vmovaps [rsp+0x60], xmm7
00007fa22efd0d10  vmovaps [rsp+0x70], xmm8
00007fa22efd0d16  vmovaps [rsp+0x80], xmm9
00007fa22efd0d1f  vmovaps [rsp+0x90], xmm10
00007fa22efd0d28  vmovaps [rsp+0xA0], xmm11
00007fa22efd0d31  vmovaps [rsp+0xB0], xmm12
00007fa22efd0d3a  vmovaps [rsp+0xC0], xmm13
00007fa22efd0d43  vmovaps [rsp+0xD0], xmm14
00007fa22efd0d4c  vmovaps [rsp+0xE0], xmm15
00007fa22efd0d55  sub rsp, 0x30
00007fa22efd0d59  movaps [rsp], xmm1
00007fa22efd0d5d  movaps [rsp+0x10], xmm10
00007fa22efd0d63  movaps [rsp+0x20], xmm2
00007fa22efd0d68  lea rdi, [rsp]
00007fa22efd0d6c  mov esi, 0x00
00007fa22efd0d71  mov rax, 0x5E9D1A57D530
00007fa22efd0d7b  call rax
00007fa22efd0d7d  movaps xmm1, [rsp]
00007fa22efd0d81  add rsp, 0x30
00007fa22efd0d85  vmovaps xmm0, [rsp]
00007fa22efd0d8a  vmovaps xmm2, [rsp+0x10]
00007fa22efd0d90  vmovaps xmm3, [rsp+0x20]
00007fa22efd0d96  vmovaps xmm4, [rsp+0x30]
00007fa22efd0d9c  vmovaps xmm5, [rsp+0x40]
00007fa22efd0da2  vmovaps xmm6, [rsp+0x50]
00007fa22efd0da8  vmovaps xmm7, [rsp+0x60]
00007fa22efd0dae  vmovaps xmm8, [rsp+0x70]
00007fa22efd0db4  vmovaps xmm9, [rsp+0x80]
00007fa22efd0dbd  vmovaps xmm10, [rsp+0x90]
00007fa22efd0dc6  vmovaps xmm11, [rsp+0xA0]
00007fa22efd0dcf  vmovaps xmm12, [rsp+0xB0]
00007fa22efd0dd8  vmovaps xmm13, [rsp+0xC0]
00007fa22efd0de1  vmovaps xmm14, [rsp+0xD0]
00007fa22efd0dea  vmovaps xmm15, [rsp+0xE0]
00007fa22efd0df3  add rsp, 0xF0
00007fa22efd0dfa  pop r11
00007fa22efd0dfc  pop r10
00007fa22efd0dfe  pop r9
00007fa22efd0e00  pop r8
00007fa22efd0e02  pop rsi
00007fa22efd0e03  pop rdi
00007fa22efd0e04  pop rdx
00007fa22efd0e05  pop rcx
00007fa22efd0e06  pop rax
00007fa22efd0e07  add rsp, 0x08
00007fa22efd0e0b  jmp 0x00007FA22EFCF6B4
00007fa22efd0e10  sub rsp, 0x08
00007fa22efd0e14  push rax
00007fa22efd0e15  push rcx
00007fa22efd0e16  push rdx
00007fa22efd0e17  push rdi
00007fa22efd0e18  push rsi
00007fa22efd0e19  push r8
00007fa22efd0e1b  push r9
00007fa22efd0e1d  push r10
00007fa22efd0e1f  push r11
00007fa22efd0e21  sub rsp, 0xF0
00007fa22efd0e28  vmovaps [rsp], xmm0
00007fa22efd0e2d  vmovaps [rsp+0x10], xmm1
00007fa22efd0e33  vmovaps [rsp+0x20], xmm2
00007fa22efd0e39  vmovaps [rsp+0x30], xmm3
00007fa22efd0e3f  vmovaps [rsp+0x40], xmm4
00007fa22efd0e45  vmovaps [rsp+0x50], xmm5
00007fa22efd0e4b  vmovaps [rsp+0x60], xmm6
00007fa22efd0e51  vmovaps [rsp+0x70], xmm7
00007fa22efd0e57  vmovaps [rsp+0x80], xmm8
00007fa22efd0e60  vmovaps [rsp+0x90], xmm9
00007fa22efd0e69  vmovaps [rsp+0xA0], xmm10
00007fa22efd0e72  vmovaps [rsp+0xB0], xmm11
00007fa22efd0e7b  vmovaps [rsp+0xC0], xmm12
00007fa22efd0e84  vmovaps [rsp+0xD0], xmm13
00007fa22efd0e8d  vmovaps [rsp+0xE0], xmm14
00007fa22efd0e96  sub rsp, 0x30
00007fa22efd0e9a  movaps [rsp], xmm15
00007fa22efd0e9f  movaps [rsp+0x10], xmm10
00007fa22efd0ea5  movaps [rsp+0x20], xmm2
00007fa22efd0eaa  lea rdi, [rsp]
00007fa22efd0eae  mov esi, 0x00
00007fa22efd0eb3  mov rax, 0x5E9D1A57D530
00007fa22efd0ebd  call rax
00007fa22efd0ebf  movaps xmm15, [rsp]
00007fa22efd0ec4  add rsp, 0x30
00007fa22efd0ec8  vmovaps xmm0, [rsp]
00007fa22efd0ecd  vmovaps xmm1, [rsp+0x10]
00007fa22efd0ed3  vmovaps xmm2, [rsp+0x20]
00007fa22efd0ed9  vmovaps xmm3, [rsp+0x30]
00007fa22efd0edf  vmovaps xmm4, [rsp+0x40]
00007fa22efd0ee5  vmovaps xmm5, [rsp+0x50]
00007fa22efd0eeb  vmovaps xmm6, [rsp+0x60]
00007fa22efd0ef1  vmovaps xmm7, [rsp+0x70]
00007fa22efd0ef7  vmovaps xmm8, [rsp+0x80]
00007fa22efd0f00  vmovaps xmm9, [rsp+0x90]
00007fa22efd0f09  vmovaps xmm10, [rsp+0xA0]
00007fa22efd0f12  vmovaps xmm11, [rsp+0xB0]
00007fa22efd0f1b  vmovaps xmm12, [rsp+0xC0]
00007fa22efd0f24  vmovaps xmm13, [rsp+0xD0]
00007fa22efd0f2d  vmovaps xmm14, [rsp+0xE0]
00007fa22efd0f36  add rsp, 0xF0
00007fa22efd0f3d  pop r11
00007fa22efd0f3f  pop r10
00007fa22efd0f41  pop r9
00007fa22efd0f43  pop r8
00007fa22efd0f45  pop rsi
00007fa22efd0f46  pop rdi
00007fa22efd0f47  pop rdx
00007fa22efd0f48  pop rcx
00007fa22efd0f49  pop rax
00007fa22efd0f4a  add rsp, 0x08
00007fa22efd0f4e  jmp 0x00007FA22EFCF706
00007fa22efd0f53  sub rsp, 0x08
00007fa22efd0f57  push rax
00007fa22efd0f58  push rcx
00007fa22efd0f59  push rdx
00007fa22efd0f5a  push rdi
00007fa22efd0f5b  push rsi
00007fa22efd0f5c  push r8
00007fa22efd0f5e  push r9
00007fa22efd0f60  push r10
00007fa22efd0f62  push r11
00007fa22efd0f64  sub rsp, 0xF0
00007fa22efd0f6b  vmovaps [rsp], xmm0
00007fa22efd0f70  vmovaps [rsp+0x10], xmm2
00007fa22efd0f76  vmovaps [rsp+0x20], xmm3
00007fa22efd0f7c  vmovaps [rsp+0x30], xmm4
00007fa22efd0f82  vmovaps [rsp+0x40], xmm5
00007fa22efd0f88  vmovaps [rsp+0x50], xmm6
00007fa22efd0f8e  vmovaps [rsp+0x60], xmm7
00007fa22efd0f94  vmovaps [rsp+0x70], xmm8
00007fa22efd0f9a  vmovaps [rsp+0x80], xmm9
00007fa22efd0fa3  vmovaps [rsp+0x90], xmm10
00007fa22efd0fac  vmovaps [rsp+0xA0], xmm11
00007fa22efd0fb5  vmovaps [rsp+0xB0], xmm12
00007fa22efd0fbe  vmovaps [rsp+0xC0], xmm13
00007fa22efd0fc7  vmovaps [rsp+0xD0], xmm14
00007fa22efd0fd0  vmovaps [rsp+0xE0], xmm15
00007fa22efd0fd9  sub rsp, 0x30
00007fa22efd0fdd  movaps [rsp], xmm1
00007fa22efd0fe1  movaps [rsp+0x10], xmm10
00007fa22efd0fe7  movaps [rsp+0x20], xmm12
00007fa22efd0fed  lea rdi, [rsp]
00007fa22efd0ff1  mov esi, 0x00
00007fa22efd0ff6  mov rax, 0x5E9D1A57D530
00007fa22efd1000  call rax
00007fa22efd1002  movaps xmm1, [rsp]
00007fa22efd1006  add rsp, 0x30
00007fa22efd100a  vmovaps xmm0, [rsp]
00007fa22efd100f  vmovaps xmm2, [rsp+0x10]
00007fa22efd1015  vmovaps xmm3, [rsp+0x20]
00007fa22efd101b  vmovaps xmm4, [rsp+0x30]
00007fa22efd1021  vmovaps xmm5, [rsp+0x40]
00007fa22efd1027  vmovaps xmm6, [rsp+0x50]
00007fa22efd102d  vmovaps xmm7, [rsp+0x60]
00007fa22efd1033  vmovaps xmm8, [rsp+0x70]
00007fa22efd1039  vmovaps xmm9, [rsp+0x80]
00007fa22efd1042  vmovaps xmm10, [rsp+0x90]
00007fa22efd104b  vmovaps xmm11, [rsp+0xA0]
00007fa22efd1054  vmovaps xmm12, [rsp+0xB0]
00007fa22efd105d  vmovaps xmm13, [rsp+0xC0]
00007fa22efd1066  vmovaps xmm14, [rsp+0xD0]
00007fa22efd106f  vmovaps xmm15, [rsp+0xE0]
00007fa22efd1078  add rsp, 0xF0
00007fa22efd107f  pop r11
00007fa22efd1081  pop r10
00007fa22efd1083  pop r9
00007fa22efd1085  pop r8
00007fa22efd1087  pop rsi
00007fa22efd1088  pop rdi
00007fa22efd1089  pop rdx
00007fa22efd108a  pop rcx
00007fa22efd108b  pop rax
00007fa22efd108c  add rsp, 0x08
00007fa22efd1090  jmp 0x00007FA22EFCF732
00007fa22efd1095  sub rsp, 0x08
00007fa22efd1099  push rax
00007fa22efd109a  push rcx
00007fa22efd109b  push rdx
00007fa22efd109c  push rdi
00007fa22efd109d  push rsi
00007fa22efd109e  push r8
00007fa22efd10a0  push r9
00007fa22efd10a2  push r10
00007fa22efd10a4  push r11
00007fa22efd10a6  sub rsp, 0xF0
00007fa22efd10ad  vmovaps [rsp], xmm0
00007fa22efd10b2  vmovaps [rsp+0x10], xmm1
00007fa22efd10b8  vmovaps [rsp+0x20], xmm2
00007fa22efd10be  vmovaps [rsp+0x30], xmm3
00007fa22efd10c4  vmovaps [rsp+0x40], xmm4
00007fa22efd10ca  vmovaps [rsp+0x50], xmm5
00007fa22efd10d0  vmovaps [rsp+0x60], xmm6
00007fa22efd10d6  vmovaps [rsp+0x70], xmm7
00007fa22efd10dc  vmovaps [rsp+0x80], xmm8
00007fa22efd10e5  vmovaps [rsp+0x90], xmm9
00007fa22efd10ee  vmovaps [rsp+0xA0], xmm10
00007fa22efd10f7  vmovaps [rsp+0xB0], xmm11
00007fa22efd1100  vmovaps [rsp+0xC0], xmm12
00007fa22efd1109  vmovaps [rsp+0xD0], xmm13
00007fa22efd1112  vmovaps [rsp+0xE0], xmm14
00007fa22efd111b  sub rsp, 0x30
00007fa22efd111f  movaps [rsp], xmm15
00007fa22efd1124  movaps [rsp+0x10], xmm10
00007fa22efd112a  movaps [rsp+0x20], xmm12
00007fa22efd1130  lea rdi, [rsp]
00007fa22efd1134  mov esi, 0x00
00007fa22efd1139  mov rax, 0x5E9D1A57D530
00007fa22efd1143  call rax
00007fa22efd1145  movaps xmm15, [rsp]
00007fa22efd114a  add rsp, 0x30
00007fa22efd114e  vmovaps xmm0, [rsp]
00007fa22efd1153  vmovaps xmm1, [rsp+0x10]
00007fa22efd1159  vmovaps xmm2, [rsp+0x20]
00007fa22efd115f  vmovaps xmm3, [rsp+0x30]
00007fa22efd1165  vmovaps xmm4, [rsp+0x40]
00007fa22efd116b  vmovaps xmm5, [rsp+0x50]
00007fa22efd1171  vmovaps xmm6, [rsp+0x60]
00007fa22efd1177  vmovaps xmm7, [rsp+0x70]
00007fa22efd117d  vmovaps xmm8, [rsp+0x80]
00007fa22efd1186  vmovaps xmm9, [rsp+0x90]
00007fa22efd118f  vmovaps xmm10, [rsp+0xA0]
00007fa22efd1198  vmovaps xmm11, [rsp+0xB0]
00007fa22efd11a1  vmovaps xmm12, [rsp+0xC0]
00007fa22efd11aa  vmovaps xmm13, [rsp+0xD0]
00007fa22efd11b3  vmovaps xmm14, [rsp+0xE0]
00007fa22efd11bc  add rsp, 0xF0
00007fa22efd11c3  pop r11
00007fa22efd11c5  pop r10
00007fa22efd11c7  pop r9
00007fa22efd11c9  pop r8
00007fa22efd11cb  pop rsi
00007fa22efd11cc  pop rdi
00007fa22efd11cd  pop rdx
00007fa22efd11ce  pop rcx
00007fa22efd11cf  pop rax
00007fa22efd11d0  add rsp, 0x08
00007fa22efd11d4  jmp 0x00007FA22EFCF75E
00007fa22efd11d9  call 0x00007FA22EDFF430
00007fa22efd11de  jmp 0x00007FA22EFCF7EE
00007fa22efd11e3  call 0x00007FA22EDFF430
00007fa22efd11e8  jmp 0x00007FA22EFCF801
00007fa22efd11ed  sub rsp, 0x08
00007fa22efd11f1  push rax
00007fa22efd11f2  push rcx
00007fa22efd11f3  push rdx
00007fa22efd11f4  push rdi
00007fa22efd11f5  push rsi
00007fa22efd11f6  push r8
00007fa22efd11f8  push r9
00007fa22efd11fa  push r10
00007fa22efd11fc  push r11
00007fa22efd11fe  sub rsp, 0xF0
00007fa22efd1205  vmovaps [rsp], xmm0
00007fa22efd120a  vmovaps [rsp+0x10], xmm2
00007fa22efd1210  vmovaps [rsp+0x20], xmm3
00007fa22efd1216  vmovaps [rsp+0x30], xmm4
00007fa22efd121c  vmovaps [rsp+0x40], xmm5
00007fa22efd1222  vmovaps [rsp+0x50], xmm6
00007fa22efd1228  vmovaps [rsp+0x60], xmm7
00007fa22efd122e  vmovaps [rsp+0x70], xmm8
00007fa22efd1234  vmovaps [rsp+0x80], xmm9
00007fa22efd123d  vmovaps [rsp+0x90], xmm10
00007fa22efd1246  vmovaps [rsp+0xA0], xmm11
00007fa22efd124f  vmovaps [rsp+0xB0], xmm12
00007fa22efd1258  vmovaps [rsp+0xC0], xmm13
00007fa22efd1261  vmovaps [rsp+0xD0], xmm14
00007fa22efd126a  vmovaps [rsp+0xE0], xmm15
00007fa22efd1273  sub rsp, 0x30
00007fa22efd1277  movaps [rsp], xmm1
00007fa22efd127b  movaps [rsp+0x10], xmm13
00007fa22efd1281  movaps [rsp+0x20], xmm2
00007fa22efd1286  lea rdi, [rsp]
00007fa22efd128a  mov esi, 0x00
00007fa22efd128f  mov rax, 0x5E9D1A57D530
00007fa22efd1299  call rax
00007fa22efd129b  movaps xmm1, [rsp]
00007fa22efd129f  add rsp, 0x30
00007fa22efd12a3  vmovaps xmm0, [rsp]
00007fa22efd12a8  vmovaps xmm2, [rsp+0x10]
00007fa22efd12ae  vmovaps xmm3, [rsp+0x20]
00007fa22efd12b4  vmovaps xmm4, [rsp+0x30]
00007fa22efd12ba  vmovaps xmm5, [rsp+0x40]
00007fa22efd12c0  vmovaps xmm6, [rsp+0x50]
00007fa22efd12c6  vmovaps xmm7, [rsp+0x60]
00007fa22efd12cc  vmovaps xmm8, [rsp+0x70]
00007fa22efd12d2  vmovaps xmm9, [rsp+0x80]
00007fa22efd12db  vmovaps xmm10, [rsp+0x90]
00007fa22efd12e4  vmovaps xmm11, [rsp+0xA0]
00007fa22efd12ed  vmovaps xmm12, [rsp+0xB0]
00007fa22efd12f6  vmovaps xmm13, [rsp+0xC0]
00007fa22efd12ff  vmovaps xmm14, [rsp+0xD0]
00007fa22efd1308  vmovaps xmm15, [rsp+0xE0]
00007fa22efd1311  add rsp, 0xF0
00007fa22efd1318  pop r11
00007fa22efd131a  pop r10
00007fa22efd131c  pop r9
00007fa22efd131e  pop r8
00007fa22efd1320  pop rsi
00007fa22efd1321  pop rdi
00007fa22efd1322  pop rdx
00007fa22efd1323  pop rcx
00007fa22efd1324  pop rax
00007fa22efd1325  add rsp, 0x08
00007fa22efd1329  jmp 0x00007FA22EFCF82C
00007fa22efd132e  call 0x00007FA22EE0E760
00007fa22efd1333  jmp 0x00007FA22EFCF839
00007fa22efd1338  sub rsp, 0x08
00007fa22efd133c  push rax
00007fa22efd133d  push rcx
00007fa22efd133e  push rdx
00007fa22efd133f  push rdi
00007fa22efd1340  push rsi
00007fa22efd1341  push r8
00007fa22efd1343  push r9
00007fa22efd1345  push r10
00007fa22efd1347  push r11
00007fa22efd1349  sub rsp, 0xF0
00007fa22efd1350  vmovaps [rsp], xmm0
00007fa22efd1355  vmovaps [rsp+0x10], xmm1
00007fa22efd135b  vmovaps [rsp+0x20], xmm2
00007fa22efd1361  vmovaps [rsp+0x30], xmm3
00007fa22efd1367  vmovaps [rsp+0x40], xmm4
00007fa22efd136d  vmovaps [rsp+0x50], xmm5
00007fa22efd1373  vmovaps [rsp+0x60], xmm6
00007fa22efd1379  vmovaps [rsp+0x70], xmm7
00007fa22efd137f  vmovaps [rsp+0x80], xmm8
00007fa22efd1388  vmovaps [rsp+0x90], xmm9
00007fa22efd1391  vmovaps [rsp+0xA0], xmm10
00007fa22efd139a  vmovaps [rsp+0xB0], xmm11
00007fa22efd13a3  vmovaps [rsp+0xC0], xmm12
00007fa22efd13ac  vmovaps [rsp+0xD0], xmm14
00007fa22efd13b5  vmovaps [rsp+0xE0], xmm15
00007fa22efd13be  sub rsp, 0x30
00007fa22efd13c2  movaps [rsp], xmm13
00007fa22efd13c7  movaps [rsp+0x10], xmm2
00007fa22efd13cc  movaps [rsp+0x20], xmm1
00007fa22efd13d1  lea rdi, [rsp]
00007fa22efd13d5  mov esi, 0x00
00007fa22efd13da  mov rax, 0x5E9D1A57D530
00007fa22efd13e4  call rax
00007fa22efd13e6  movaps xmm13, [rsp]
00007fa22efd13eb  add rsp, 0x30
00007fa22efd13ef  vmovaps xmm0, [rsp]
00007fa22efd13f4  vmovaps xmm1, [rsp+0x10]
00007fa22efd13fa  vmovaps xmm2, [rsp+0x20]
00007fa22efd1400  vmovaps xmm3, [rsp+0x30]
00007fa22efd1406  vmovaps xmm4, [rsp+0x40]
00007fa22efd140c  vmovaps xmm5, [rsp+0x50]
00007fa22efd1412  vmovaps xmm6, [rsp+0x60]
00007fa22efd1418  vmovaps xmm7, [rsp+0x70]
00007fa22efd141e  vmovaps xmm8, [rsp+0x80]
00007fa22efd1427  vmovaps xmm9, [rsp+0x90]
00007fa22efd1430  vmovaps xmm10, [rsp+0xA0]
00007fa22efd1439  vmovaps xmm11, [rsp+0xB0]
00007fa22efd1442  vmovaps xmm12, [rsp+0xC0]
00007fa22efd144b  vmovaps xmm14, [rsp+0xD0]
00007fa22efd1454  vmovaps xmm15, [rsp+0xE0]
00007fa22efd145d  add rsp, 0xF0
00007fa22efd1464  pop r11
00007fa22efd1466  pop r10
00007fa22efd1468  pop r9
00007fa22efd146a  pop r8
00007fa22efd146c  pop rsi
00007fa22efd146d  pop rdi
00007fa22efd146e  pop rdx
00007fa22efd146f  pop rcx
00007fa22efd1470  pop rax
00007fa22efd1471  add rsp, 0x08
00007fa22efd1475  jmp 0x00007FA22EFCF878
00007fa22efd147a  sub rsp, 0x08
00007fa22efd147e  push rax
00007fa22efd147f  push rcx
00007fa22efd1480  push rdx
00007fa22efd1481  push rdi
00007fa22efd1482  push rsi
00007fa22efd1483  push r8
00007fa22efd1485  push r9
00007fa22efd1487  push r10
00007fa22efd1489  push r11
00007fa22efd148b  sub rsp, 0xF0
00007fa22efd1492  vmovaps [rsp], xmm0
00007fa22efd1497  vmovaps [rsp+0x10], xmm2
00007fa22efd149d  vmovaps [rsp+0x20], xmm3
00007fa22efd14a3  vmovaps [rsp+0x30], xmm4
00007fa22efd14a9  vmovaps [rsp+0x40], xmm5
00007fa22efd14af  vmovaps [rsp+0x50], xmm6
00007fa22efd14b5  vmovaps [rsp+0x60], xmm7
00007fa22efd14bb  vmovaps [rsp+0x70], xmm8
00007fa22efd14c1  vmovaps [rsp+0x80], xmm9
00007fa22efd14ca  vmovaps [rsp+0x90], xmm10
00007fa22efd14d3  vmovaps [rsp+0xA0], xmm11
00007fa22efd14dc  vmovaps [rsp+0xB0], xmm12
00007fa22efd14e5  vmovaps [rsp+0xC0], xmm13
00007fa22efd14ee  vmovaps [rsp+0xD0], xmm14
00007fa22efd14f7  vmovaps [rsp+0xE0], xmm15
00007fa22efd1500  sub rsp, 0x30
00007fa22efd1504  movaps [rsp], xmm1
00007fa22efd1508  movaps [rsp+0x10], xmm15
00007fa22efd150e  movaps [rsp+0x20], xmm2
00007fa22efd1513  lea rdi, [rsp]
00007fa22efd1517  mov esi, 0x00
00007fa22efd151c  mov rax, 0x5E9D1A57D530
00007fa22efd1526  call rax
00007fa22efd1528  movaps xmm1, [rsp]
00007fa22efd152c  add rsp, 0x30
00007fa22efd1530  vmovaps xmm0, [rsp]
00007fa22efd1535  vmovaps xmm2, [rsp+0x10]
00007fa22efd153b  vmovaps xmm3, [rsp+0x20]
00007fa22efd1541  vmovaps xmm4, [rsp+0x30]
00007fa22efd1547  vmovaps xmm5, [rsp+0x40]
00007fa22efd154d  vmovaps xmm6, [rsp+0x50]
00007fa22efd1553  vmovaps xmm7, [rsp+0x60]
00007fa22efd1559  vmovaps xmm8, [rsp+0x70]
00007fa22efd155f  vmovaps xmm9, [rsp+0x80]
00007fa22efd1568  vmovaps xmm10, [rsp+0x90]
00007fa22efd1571  vmovaps xmm11, [rsp+0xA0]
00007fa22efd157a  vmovaps xmm12, [rsp+0xB0]
00007fa22efd1583  vmovaps xmm13, [rsp+0xC0]
00007fa22efd158c  vmovaps xmm14, [rsp+0xD0]
00007fa22efd1595  vmovaps xmm15, [rsp+0xE0]
00007fa22efd159e  add rsp, 0xF0
00007fa22efd15a5  pop r11
00007fa22efd15a7  pop r10
00007fa22efd15a9  pop r9
00007fa22efd15ab  pop r8
00007fa22efd15ad  pop rsi
00007fa22efd15ae  pop rdi
00007fa22efd15af  pop rdx
00007fa22efd15b0  pop rcx
00007fa22efd15b1  pop rax
00007fa22efd15b2  add rsp, 0x08
00007fa22efd15b6  jmp 0x00007FA22EFCF8AC
00007fa22efd15bb  sub rsp, 0x08
00007fa22efd15bf  push rax
00007fa22efd15c0  push rcx
00007fa22efd15c1  push rdx
00007fa22efd15c2  push rdi
00007fa22efd15c3  push rsi
00007fa22efd15c4  push r8
00007fa22efd15c6  push r9
00007fa22efd15c8  push r10
00007fa22efd15ca  push r11
00007fa22efd15cc  sub rsp, 0xF0
00007fa22efd15d3  vmovaps [rsp], xmm0
00007fa22efd15d8  vmovaps [rsp+0x10], xmm1
00007fa22efd15de  vmovaps [rsp+0x20], xmm2
00007fa22efd15e4  vmovaps [rsp+0x30], xmm3
00007fa22efd15ea  vmovaps [rsp+0x40], xmm4
00007fa22efd15f0  vmovaps [rsp+0x50], xmm5
00007fa22efd15f6  vmovaps [rsp+0x60], xmm6
00007fa22efd15fc  vmovaps [rsp+0x70], xmm7
00007fa22efd1602  vmovaps [rsp+0x80], xmm8
00007fa22efd160b  vmovaps [rsp+0x90], xmm9
00007fa22efd1614  vmovaps [rsp+0xA0], xmm10
00007fa22efd161d  vmovaps [rsp+0xB0], xmm11
00007fa22efd1626  vmovaps [rsp+0xC0], xmm12
00007fa22efd162f  vmovaps [rsp+0xD0], xmm13
00007fa22efd1638  vmovaps [rsp+0xE0], xmm15
00007fa22efd1641  sub rsp, 0x30
00007fa22efd1645  movaps [rsp], xmm14
00007fa22efd164a  movaps [rsp+0x10], xmm2
00007fa22efd164f  movaps [rsp+0x20], xmm15
00007fa22efd1655  lea rdi, [rsp]
00007fa22efd1659  mov esi, 0x00
00007fa22efd165e  mov rax, 0x5E9D1A57D530
00007fa22efd1668  call rax
00007fa22efd166a  movaps xmm14, [rsp]
00007fa22efd166f  add rsp, 0x30
00007fa22efd1673  vmovaps xmm0, [rsp]
00007fa22efd1678  vmovaps xmm1, [rsp+0x10]
00007fa22efd167e  vmovaps xmm2, [rsp+0x20]
00007fa22efd1684  vmovaps xmm3, [rsp+0x30]
00007fa22efd168a  vmovaps xmm4, [rsp+0x40]
00007fa22efd1690  vmovaps xmm5, [rsp+0x50]
00007fa22efd1696  vmovaps xmm6, [rsp+0x60]
00007fa22efd169c  vmovaps xmm7, [rsp+0x70]
00007fa22efd16a2  vmovaps xmm8, [rsp+0x80]
00007fa22efd16ab  vmovaps xmm9, [rsp+0x90]
00007fa22efd16b4  vmovaps xmm10, [rsp+0xA0]
00007fa22efd16bd  vmovaps xmm11, [rsp+0xB0]
00007fa22efd16c6  vmovaps xmm12, [rsp+0xC0]
00007fa22efd16cf  vmovaps xmm13, [rsp+0xD0]
00007fa22efd16d8  vmovaps xmm15, [rsp+0xE0]
00007fa22efd16e1  add rsp, 0xF0
00007fa22efd16e8  pop r11
00007fa22efd16ea  pop r10
00007fa22efd16ec  pop r9
00007fa22efd16ee  pop r8
00007fa22efd16f0  pop rsi
00007fa22efd16f1  pop rdi
00007fa22efd16f2  pop rdx
00007fa22efd16f3  pop rcx
00007fa22efd16f4  pop rax
00007fa22efd16f5  add rsp, 0x08
00007fa22efd16f9  jmp 0x00007FA22EFCF8E7
00007fa22efd16fe  sub rsp, 0x08
00007fa22efd1702  push rax
00007fa22efd1703  push rcx
00007fa22efd1704  push rdx
00007fa22efd1705  push rdi
00007fa22efd1706  push rsi
00007fa22efd1707  push r8
00007fa22efd1709  push r9
00007fa22efd170b  push r10
00007fa22efd170d  push r11
00007fa22efd170f  sub rsp, 0xF0
00007fa22efd1716  vmovaps [rsp], xmm0
00007fa22efd171b  vmovaps [rsp+0x10], xmm1
00007fa22efd1721  vmovaps [rsp+0x20], xmm2
00007fa22efd1727  vmovaps [rsp+0x30], xmm3
00007fa22efd172d  vmovaps [rsp+0x40], xmm4
00007fa22efd1733  vmovaps [rsp+0x50], xmm5
00007fa22efd1739  vmovaps [rsp+0x60], xmm6
00007fa22efd173f  vmovaps [rsp+0x70], xmm7
00007fa22efd1745  vmovaps [rsp+0x80], xmm8
00007fa22efd174e  vmovaps [rsp+0x90], xmm9
00007fa22efd1757  vmovaps [rsp+0xA0], xmm10
00007fa22efd1760  vmovaps [rsp+0xB0], xmm11
00007fa22efd1769  vmovaps [rsp+0xC0], xmm12
00007fa22efd1772  vmovaps [rsp+0xD0], xmm13
00007fa22efd177b  vmovaps [rsp+0xE0], xmm14
00007fa22efd1784  sub rsp, 0x30
00007fa22efd1788  movaps [rsp], xmm15
00007fa22efd178d  movaps [rsp+0x10], xmm2
00007fa22efd1792  movaps [rsp+0x20], xmm1
00007fa22efd1797  lea rdi, [rsp]
00007fa22efd179b  mov esi, 0x00
00007fa22efd17a0  mov rax, 0x5E9D1A57D530
00007fa22efd17aa  call rax
00007fa22efd17ac  movaps xmm15, [rsp]
00007fa22efd17b1  add rsp, 0x30
00007fa22efd17b5  vmovaps xmm0, [rsp]
00007fa22efd17ba  vmovaps xmm1, [rsp+0x10]
00007fa22efd17c0  vmovaps xmm2, [rsp+0x20]
00007fa22efd17c6  vmovaps xmm3, [rsp+0x30]
00007fa22efd17cc  vmovaps xmm4, [rsp+0x40]
00007fa22efd17d2  vmovaps xmm5, [rsp+0x50]
00007fa22efd17d8  vmovaps xmm6, [rsp+0x60]
00007fa22efd17de  vmovaps xmm7, [rsp+0x70]
00007fa22efd17e4  vmovaps xmm8, [rsp+0x80]
00007fa22efd17ed  vmovaps xmm9, [rsp+0x90]
00007fa22efd17f6  vmovaps xmm10, [rsp+0xA0]
00007fa22efd17ff  vmovaps xmm11, [rsp+0xB0]
00007fa22efd1808  vmovaps xmm12, [rsp+0xC0]
00007fa22efd1811  vmovaps xmm13, [rsp+0xD0]
00007fa22efd181a  vmovaps xmm14, [rsp+0xE0]
00007fa22efd1823  add rsp, 0xF0
00007fa22efd182a  pop r11
00007fa22efd182c  pop r10
00007fa22efd182e  pop r9
00007fa22efd1830  pop r8
00007fa22efd1832  pop rsi
00007fa22efd1833  pop rdi
00007fa22efd1834  pop rdx
00007fa22efd1835  pop rcx
00007fa22efd1836  pop rax
00007fa22efd1837  add rsp, 0x08
00007fa22efd183b  jmp 0x00007FA22EFCF923
00007fa22efd1840  call 0x00007FA22EDFF430
00007fa22efd1845  jmp 0x00007FA22EFCF930
00007fa22efd184a  sub rsp, 0x08
00007fa22efd184e  push rax
00007fa22efd184f  push rcx
00007fa22efd1850  push rdx
00007fa22efd1851  push rdi
00007fa22efd1852  push rsi
00007fa22efd1853  push r8
00007fa22efd1855  push r9
00007fa22efd1857  push r10
00007fa22efd1859  push r11
00007fa22efd185b  sub rsp, 0xF0
00007fa22efd1862  vmovaps [rsp], xmm0
00007fa22efd1867  vmovaps [rsp+0x10], xmm1
00007fa22efd186d  vmovaps [rsp+0x20], xmm3
00007fa22efd1873  vmovaps [rsp+0x30], xmm4
00007fa22efd1879  vmovaps [rsp+0x40], xmm5
00007fa22efd187f  vmovaps [rsp+0x50], xmm6
00007fa22efd1885  vmovaps [rsp+0x60], xmm7
00007fa22efd188b  vmovaps [rsp+0x70], xmm8
00007fa22efd1891  vmovaps [rsp+0x80], xmm9
00007fa22efd189a  vmovaps [rsp+0x90], xmm10
00007fa22efd18a3  vmovaps [rsp+0xA0], xmm11
00007fa22efd18ac  vmovaps [rsp+0xB0], xmm12
00007fa22efd18b5  vmovaps [rsp+0xC0], xmm13
00007fa22efd18be  vmovaps [rsp+0xD0], xmm14
00007fa22efd18c7  vmovaps [rsp+0xE0], xmm15
00007fa22efd18d0  sub rsp, 0x30
00007fa22efd18d4  movaps [rsp], xmm2
00007fa22efd18d8  movaps [rsp+0x10], xmm1
00007fa22efd18dd  movaps [rsp+0x20], xmm14
00007fa22efd18e3  lea rdi, [rsp]
00007fa22efd18e7  mov esi, 0x00
00007fa22efd18ec  mov rax, 0x5E9D1A57D530
00007fa22efd18f6  call rax
00007fa22efd18f8  movaps xmm2, [rsp]
00007fa22efd18fc  add rsp, 0x30
00007fa22efd1900  vmovaps xmm0, [rsp]
00007fa22efd1905  vmovaps xmm1, [rsp+0x10]
00007fa22efd190b  vmovaps xmm3, [rsp+0x20]
00007fa22efd1911  vmovaps xmm4, [rsp+0x30]
00007fa22efd1917  vmovaps xmm5, [rsp+0x40]
00007fa22efd191d  vmovaps xmm6, [rsp+0x50]
00007fa22efd1923  vmovaps xmm7, [rsp+0x60]
00007fa22efd1929  vmovaps xmm8, [rsp+0x70]
00007fa22efd192f  vmovaps xmm9, [rsp+0x80]
00007fa22efd1938  vmovaps xmm10, [rsp+0x90]
00007fa22efd1941  vmovaps xmm11, [rsp+0xA0]
00007fa22efd194a  vmovaps xmm12, [rsp+0xB0]
00007fa22efd1953  vmovaps xmm13, [rsp+0xC0]
00007fa22efd195c  vmovaps xmm14, [rsp+0xD0]
00007fa22efd1965  vmovaps xmm15, [rsp+0xE0]
00007fa22efd196e  add rsp, 0xF0
00007fa22efd1975  pop r11
00007fa22efd1977  pop r10
00007fa22efd1979  pop r9
00007fa22efd197b  pop r8
00007fa22efd197d  pop rsi
00007fa22efd197e  pop rdi
00007fa22efd197f  pop rdx
00007fa22efd1980  pop rcx
00007fa22efd1981  pop rax
00007fa22efd1982  add rsp, 0x08
00007fa22efd1986  jmp 0x00007FA22EFCF96D
00007fa22efd198b  sub rsp, 0x08
00007fa22efd198f  push rax
00007fa22efd1990  push rcx
00007fa22efd1991  push rdx
00007fa22efd1992  push rdi
00007fa22efd1993  push rsi
00007fa22efd1994  push r8
00007fa22efd1996  push r9
00007fa22efd1998  push r10
00007fa22efd199a  push r11
00007fa22efd199c  sub rsp, 0xF0
00007fa22efd19a3  vmovaps [rsp], xmm0
00007fa22efd19a8  vmovaps [rsp+0x10], xmm1
00007fa22efd19ae  vmovaps [rsp+0x20], xmm2
00007fa22efd19b4  vmovaps [rsp+0x30], xmm3
00007fa22efd19ba  vmovaps [rsp+0x40], xmm4
00007fa22efd19c0  vmovaps [rsp+0x50], xmm5
00007fa22efd19c6  vmovaps [rsp+0x60], xmm6
00007fa22efd19cc  vmovaps [rsp+0x70], xmm7
00007fa22efd19d2  vmovaps [rsp+0x80], xmm8
00007fa22efd19db  vmovaps [rsp+0x90], xmm9
00007fa22efd19e4  vmovaps [rsp+0xA0], xmm10
00007fa22efd19ed  vmovaps [rsp+0xB0], xmm11
00007fa22efd19f6  vmovaps [rsp+0xC0], xmm12
00007fa22efd19ff  vmovaps [rsp+0xD0], xmm13
00007fa22efd1a08  vmovaps [rsp+0xE0], xmm14
00007fa22efd1a11  sub rsp, 0x30
00007fa22efd1a15  movaps [rsp], xmm15
00007fa22efd1a1a  movaps [rsp+0x10], xmm14
00007fa22efd1a20  movaps [rsp+0x20], xmm1
00007fa22efd1a25  lea rdi, [rsp]
00007fa22efd1a29  mov esi, 0x00
00007fa22efd1a2e  mov rax, 0x5E9D1A57D530
00007fa22efd1a38  call rax
00007fa22efd1a3a  movaps xmm15, [rsp]
00007fa22efd1a3f  add rsp, 0x30
00007fa22efd1a43  vmovaps xmm0, [rsp]
00007fa22efd1a48  vmovaps xmm1, [rsp+0x10]
00007fa22efd1a4e  vmovaps xmm2, [rsp+0x20]
00007fa22efd1a54  vmovaps xmm3, [rsp+0x30]
00007fa22efd1a5a  vmovaps xmm4, [rsp+0x40]
00007fa22efd1a60  vmovaps xmm5, [rsp+0x50]
00007fa22efd1a66  vmovaps xmm6, [rsp+0x60]
00007fa22efd1a6c  vmovaps xmm7, [rsp+0x70]
00007fa22efd1a72  vmovaps xmm8, [rsp+0x80]
00007fa22efd1a7b  vmovaps xmm9, [rsp+0x90]
00007fa22efd1a84  vmovaps xmm10, [rsp+0xA0]
00007fa22efd1a8d  vmovaps xmm11, [rsp+0xB0]
00007fa22efd1a96  vmovaps xmm12, [rsp+0xC0]
00007fa22efd1a9f  vmovaps xmm13, [rsp+0xD0]
00007fa22efd1aa8  vmovaps xmm14, [rsp+0xE0]
00007fa22efd1ab1  add rsp, 0xF0
00007fa22efd1ab8  pop r11
00007fa22efd1aba  pop r10
00007fa22efd1abc  pop r9
00007fa22efd1abe  pop r8
00007fa22efd1ac0  pop rsi
00007fa22efd1ac1  pop rdi
00007fa22efd1ac2  pop rdx
00007fa22efd1ac3  pop rcx
00007fa22efd1ac4  pop rax
00007fa22efd1ac5  add rsp, 0x08
00007fa22efd1ac9  jmp 0x00007FA22EFCF9E7
00007fa22efd1ace  call 0x00007FA22EDFF430
00007fa22efd1ad3  jmp 0x00007FA22EFCF9F4
00007fa22efd1ad8  sub rsp, 0x08
00007fa22efd1adc  push rax
00007fa22efd1add  push rcx
00007fa22efd1ade  push rdx
00007fa22efd1adf  push rdi
00007fa22efd1ae0  push rsi
00007fa22efd1ae1  push r8
00007fa22efd1ae3  push r9
00007fa22efd1ae5  push r10
00007fa22efd1ae7  push r11
00007fa22efd1ae9  sub rsp, 0xF0
00007fa22efd1af0  vmovaps [rsp], xmm0
00007fa22efd1af5  vmovaps [rsp+0x10], xmm1
00007fa22efd1afb  vmovaps [rsp+0x20], xmm2
00007fa22efd1b01  vmovaps [rsp+0x30], xmm3
00007fa22efd1b07  vmovaps [rsp+0x40], xmm4
00007fa22efd1b0d  vmovaps [rsp+0x50], xmm5
00007fa22efd1b13  vmovaps [rsp+0x60], xmm6
00007fa22efd1b19  vmovaps [rsp+0x70], xmm7
00007fa22efd1b1f  vmovaps [rsp+0x80], xmm8
00007fa22efd1b28  vmovaps [rsp+0x90], xmm9
00007fa22efd1b31  vmovaps [rsp+0xA0], xmm10
00007fa22efd1b3a  vmovaps [rsp+0xB0], xmm11
00007fa22efd1b43  vmovaps [rsp+0xC0], xmm12
00007fa22efd1b4c  vmovaps [rsp+0xD0], xmm13
00007fa22efd1b55  vmovaps [rsp+0xE0], xmm15
00007fa22efd1b5e  sub rsp, 0x30
00007fa22efd1b62  movaps [rsp], xmm14
00007fa22efd1b67  movaps [rsp+0x10], xmm13
00007fa22efd1b6d  movaps [rsp+0x20], xmm1
00007fa22efd1b72  lea rdi, [rsp]
00007fa22efd1b76  mov esi, 0x00
00007fa22efd1b7b  mov rax, 0x5E9D1A57D530
00007fa22efd1b85  call rax
00007fa22efd1b87  movaps xmm14, [rsp]
00007fa22efd1b8c  add rsp, 0x30
00007fa22efd1b90  vmovaps xmm0, [rsp]
00007fa22efd1b95  vmovaps xmm1, [rsp+0x10]
00007fa22efd1b9b  vmovaps xmm2, [rsp+0x20]
00007fa22efd1ba1  vmovaps xmm3, [rsp+0x30]
00007fa22efd1ba7  vmovaps xmm4, [rsp+0x40]
00007fa22efd1bad  vmovaps xmm5, [rsp+0x50]
00007fa22efd1bb3  vmovaps xmm6, [rsp+0x60]
00007fa22efd1bb9  vmovaps xmm7, [rsp+0x70]
00007fa22efd1bbf  vmovaps xmm8, [rsp+0x80]
00007fa22efd1bc8  vmovaps xmm9, [rsp+0x90]
00007fa22efd1bd1  vmovaps xmm10, [rsp+0xA0]
00007fa22efd1bda  vmovaps xmm11, [rsp+0xB0]
00007fa22efd1be3  vmovaps xmm12, [rsp+0xC0]
00007fa22efd1bec  vmovaps xmm13, [rsp+0xD0]
00007fa22efd1bf5  vmovaps xmm15, [rsp+0xE0]
00007fa22efd1bfe  add rsp, 0xF0
00007fa22efd1c05  pop r11
00007fa22efd1c07  pop r10
00007fa22efd1c09  pop r9
00007fa22efd1c0b  pop r8
00007fa22efd1c0d  pop rsi
00007fa22efd1c0e  pop rdi
00007fa22efd1c0f  pop rdx
00007fa22efd1c10  pop rcx
00007fa22efd1c11  pop rax
00007fa22efd1c12  add rsp, 0x08
00007fa22efd1c16  jmp 0x00007FA22EFCFAAF
00007fa22efd1c1b  sub rsp, 0x08
00007fa22efd1c1f  push rax
00007fa22efd1c20  push rcx
00007fa22efd1c21  push rdx
00007fa22efd1c22  push rdi
00007fa22efd1c23  push rsi
00007fa22efd1c24  push r8
00007fa22efd1c26  push r9
00007fa22efd1c28  push r10
00007fa22efd1c2a  push r11
00007fa22efd1c2c  sub rsp, 0xF0
00007fa22efd1c33  vmovaps [rsp], xmm0
00007fa22efd1c38  vmovaps [rsp+0x10], xmm1
00007fa22efd1c3e  vmovaps [rsp+0x20], xmm2
00007fa22efd1c44  vmovaps [rsp+0x30], xmm3
00007fa22efd1c4a  vmovaps [rsp+0x40], xmm4
00007fa22efd1c50  vmovaps [rsp+0x50], xmm5
00007fa22efd1c56  vmovaps [rsp+0x60], xmm6
00007fa22efd1c5c  vmovaps [rsp+0x70], xmm7
00007fa22efd1c62  vmovaps [rsp+0x80], xmm8
00007fa22efd1c6b  vmovaps [rsp+0x90], xmm9
00007fa22efd1c74  vmovaps [rsp+0xA0], xmm10
00007fa22efd1c7d  vmovaps [rsp+0xB0], xmm11
00007fa22efd1c86  vmovaps [rsp+0xC0], xmm12
00007fa22efd1c8f  vmovaps [rsp+0xD0], xmm13
00007fa22efd1c98  vmovaps [rsp+0xE0], xmm14
00007fa22efd1ca1  sub rsp, 0x30
00007fa22efd1ca5  movaps [rsp], xmm15
00007fa22efd1caa  movaps [rsp+0x10], xmm13
00007fa22efd1cb0  movaps [rsp+0x20], xmm1
00007fa22efd1cb5  lea rdi, [rsp]
00007fa22efd1cb9  mov esi, 0x00
00007fa22efd1cbe  mov rax, 0x5E9D1A57D530
00007fa22efd1cc8  call rax
00007fa22efd1cca  movaps xmm15, [rsp]
00007fa22efd1ccf  add rsp, 0x30
00007fa22efd1cd3  vmovaps xmm0, [rsp]
00007fa22efd1cd8  vmovaps xmm1, [rsp+0x10]
00007fa22efd1cde  vmovaps xmm2, [rsp+0x20]
00007fa22efd1ce4  vmovaps xmm3, [rsp+0x30]
00007fa22efd1cea  vmovaps xmm4, [rsp+0x40]
00007fa22efd1cf0  vmovaps xmm5, [rsp+0x50]
00007fa22efd1cf6  vmovaps xmm6, [rsp+0x60]
00007fa22efd1cfc  vmovaps xmm7, [rsp+0x70]
00007fa22efd1d02  vmovaps xmm8, [rsp+0x80]
00007fa22efd1d0b  vmovaps xmm9, [rsp+0x90]
00007fa22efd1d14  vmovaps xmm10, [rsp+0xA0]
00007fa22efd1d1d  vmovaps xmm11, [rsp+0xB0]
00007fa22efd1d26  vmovaps xmm12, [rsp+0xC0]
00007fa22efd1d2f  vmovaps xmm13, [rsp+0xD0]
00007fa22efd1d38  vmovaps xmm14, [rsp+0xE0]
00007fa22efd1d41  add rsp, 0xF0
00007fa22efd1d48  pop r11
00007fa22efd1d4a  pop r10
00007fa22efd1d4c  pop r9
00007fa22efd1d4e  pop r8
00007fa22efd1d50  pop rsi
00007fa22efd1d51  pop rdi
00007fa22efd1d52  pop rdx
00007fa22efd1d53  pop rcx
00007fa22efd1d54  pop rax
00007fa22efd1d55  add rsp, 0x08
00007fa22efd1d59  jmp 0x00007FA22EFCFAEB
00007fa22efd1d5e  call 0x00007FA22EDFF430
00007fa22efd1d63  jmp 0x00007FA22EFCFAF8
00007fa22efd1d68  sub rsp, 0x08
00007fa22efd1d6c  push rax
00007fa22efd1d6d  push rcx
00007fa22efd1d6e  push rdx
00007fa22efd1d6f  push rdi
00007fa22efd1d70  push rsi
00007fa22efd1d71  push r8
00007fa22efd1d73  push r9
00007fa22efd1d75  push r10
00007fa22efd1d77  push r11
00007fa22efd1d79  sub rsp, 0xF0
00007fa22efd1d80  vmovaps [rsp], xmm0
00007fa22efd1d85  vmovaps [rsp+0x10], xmm1
00007fa22efd1d8b  vmovaps [rsp+0x20], xmm2
00007fa22efd1d91  vmovaps [rsp+0x30], xmm3
00007fa22efd1d97  vmovaps [rsp+0x40], xmm4
00007fa22efd1d9d  vmovaps [rsp+0x50], xmm5
00007fa22efd1da3  vmovaps [rsp+0x60], xmm6
00007fa22efd1da9  vmovaps [rsp+0x70], xmm7
00007fa22efd1daf  vmovaps [rsp+0x80], xmm8
00007fa22efd1db8  vmovaps [rsp+0x90], xmm9
00007fa22efd1dc1  vmovaps [rsp+0xA0], xmm10
00007fa22efd1dca  vmovaps [rsp+0xB0], xmm11
00007fa22efd1dd3  vmovaps [rsp+0xC0], xmm12
00007fa22efd1ddc  vmovaps [rsp+0xD0], xmm13
00007fa22efd1de5  vmovaps [rsp+0xE0], xmm15
00007fa22efd1dee  sub rsp, 0x30
00007fa22efd1df2  movaps [rsp], xmm14
00007fa22efd1df7  movaps [rsp+0x10], xmm13
00007fa22efd1dfd  movaps [rsp+0x20], xmm2
00007fa22efd1e02  lea rdi, [rsp]
00007fa22efd1e06  mov esi, 0x00
00007fa22efd1e0b  mov rax, 0x5E9D1A57D530
00007fa22efd1e15  call rax
00007fa22efd1e17  movaps xmm14, [rsp]
00007fa22efd1e1c  add rsp, 0x30
00007fa22efd1e20  vmovaps xmm0, [rsp]
00007fa22efd1e25  vmovaps xmm1, [rsp+0x10]
00007fa22efd1e2b  vmovaps xmm2, [rsp+0x20]
00007fa22efd1e31  vmovaps xmm3, [rsp+0x30]
00007fa22efd1e37  vmovaps xmm4, [rsp+0x40]
00007fa22efd1e3d  vmovaps xmm5, [rsp+0x50]
00007fa22efd1e43  vmovaps xmm6, [rsp+0x60]
00007fa22efd1e49  vmovaps xmm7, [rsp+0x70]
00007fa22efd1e4f  vmovaps xmm8, [rsp+0x80]
00007fa22efd1e58  vmovaps xmm9, [rsp+0x90]
00007fa22efd1e61  vmovaps xmm10, [rsp+0xA0]
00007fa22efd1e6a  vmovaps xmm11, [rsp+0xB0]
00007fa22efd1e73  vmovaps xmm12, [rsp+0xC0]
00007fa22efd1e7c  vmovaps xmm13, [rsp+0xD0]
00007fa22efd1e85  vmovaps xmm15, [rsp+0xE0]
00007fa22efd1e8e  add rsp, 0xF0
00007fa22efd1e95  pop r11
00007fa22efd1e97  pop r10
00007fa22efd1e99  pop r9
00007fa22efd1e9b  pop r8
00007fa22efd1e9d  pop rsi
00007fa22efd1e9e  pop rdi
00007fa22efd1e9f  pop rdx
00007fa22efd1ea0  pop rcx
00007fa22efd1ea1  pop rax
00007fa22efd1ea2  add rsp, 0x08
00007fa22efd1ea6  jmp 0x00007FA22EFCFB24
00007fa22efd1eab  sub rsp, 0x08
00007fa22efd1eaf  push rax
00007fa22efd1eb0  push rcx
00007fa22efd1eb1  push rdx
00007fa22efd1eb2  push rdi
00007fa22efd1eb3  push rsi
00007fa22efd1eb4  push r8
00007fa22efd1eb6  push r9
00007fa22efd1eb8  push r10
00007fa22efd1eba  push r11
00007fa22efd1ebc  sub rsp, 0xF0
00007fa22efd1ec3  vmovaps [rsp], xmm0
00007fa22efd1ec8  vmovaps [rsp+0x10], xmm2
00007fa22efd1ece  vmovaps [rsp+0x20], xmm3
00007fa22efd1ed4  vmovaps [rsp+0x30], xmm4
00007fa22efd1eda  vmovaps [rsp+0x40], xmm5
00007fa22efd1ee0  vmovaps [rsp+0x50], xmm6
00007fa22efd1ee6  vmovaps [rsp+0x60], xmm7
00007fa22efd1eec  vmovaps [rsp+0x70], xmm8
00007fa22efd1ef2  vmovaps [rsp+0x80], xmm9
00007fa22efd1efb  vmovaps [rsp+0x90], xmm10
00007fa22efd1f04  vmovaps [rsp+0xA0], xmm11
00007fa22efd1f0d  vmovaps [rsp+0xB0], xmm12
00007fa22efd1f16  vmovaps [rsp+0xC0], xmm13
00007fa22efd1f1f  vmovaps [rsp+0xD0], xmm14
00007fa22efd1f28  vmovaps [rsp+0xE0], xmm15
00007fa22efd1f31  sub rsp, 0x30
00007fa22efd1f35  movaps [rsp], xmm1
00007fa22efd1f39  movaps [rsp+0x10], xmm13
00007fa22efd1f3f  movaps [rsp+0x20], xmm2
00007fa22efd1f44  lea rdi, [rsp]
00007fa22efd1f48  mov esi, 0x00
00007fa22efd1f4d  mov rax, 0x5E9D1A57D530
00007fa22efd1f57  call rax
00007fa22efd1f59  movaps xmm1, [rsp]
00007fa22efd1f5d  add rsp, 0x30
00007fa22efd1f61  vmovaps xmm0, [rsp]
00007fa22efd1f66  vmovaps xmm2, [rsp+0x10]
00007fa22efd1f6c  vmovaps xmm3, [rsp+0x20]
00007fa22efd1f72  vmovaps xmm4, [rsp+0x30]
00007fa22efd1f78  vmovaps xmm5, [rsp+0x40]
00007fa22efd1f7e  vmovaps xmm6, [rsp+0x50]
00007fa22efd1f84  vmovaps xmm7, [rsp+0x60]
00007fa22efd1f8a  vmovaps xmm8, [rsp+0x70]
00007fa22efd1f90  vmovaps xmm9, [rsp+0x80]
00007fa22efd1f99  vmovaps xmm10, [rsp+0x90]
00007fa22efd1fa2  vmovaps xmm11, [rsp+0xA0]
00007fa22efd1fab  vmovaps xmm12, [rsp+0xB0]
00007fa22efd1fb4  vmovaps xmm13, [rsp+0xC0]
00007fa22efd1fbd  vmovaps xmm14, [rsp+0xD0]
00007fa22efd1fc6  vmovaps xmm15, [rsp+0xE0]
00007fa22efd1fcf  add rsp, 0xF0
00007fa22efd1fd6  pop r11
00007fa22efd1fd8  pop r10
00007fa22efd1fda  pop r9
00007fa22efd1fdc  pop r8
00007fa22efd1fde  pop rsi
00007fa22efd1fdf  pop rdi
00007fa22efd1fe0  pop rdx
00007fa22efd1fe1  pop rcx
00007fa22efd1fe2  pop rax
00007fa22efd1fe3  add rsp, 0x08
00007fa22efd1fe7  jmp 0x00007FA22EFCFB52
00007fa22efd1fec  sub rsp, 0x08
00007fa22efd1ff0  push rax
00007fa22efd1ff1  push rcx
00007fa22efd1ff2  push rdx
00007fa22efd1ff3  push rdi
00007fa22efd1ff4  push rsi
00007fa22efd1ff5  push r8
00007fa22efd1ff7  push r9
00007fa22efd1ff9  push r10
00007fa22efd1ffb  push r11
00007fa22efd1ffd  sub rsp, 0xF0
00007fa22efd2004  vmovaps [rsp], xmm0
00007fa22efd2009  vmovaps [rsp+0x10], xmm1
00007fa22efd200f  vmovaps [rsp+0x20], xmm3
00007fa22efd2015  vmovaps [rsp+0x30], xmm4
00007fa22efd201b  vmovaps [rsp+0x40], xmm5
00007fa22efd2021  vmovaps [rsp+0x50], xmm6
00007fa22efd2027  vmovaps [rsp+0x60], xmm7
00007fa22efd202d  vmovaps [rsp+0x70], xmm8
00007fa22efd2033  vmovaps [rsp+0x80], xmm9
00007fa22efd203c  vmovaps [rsp+0x90], xmm10
00007fa22efd2045  vmovaps [rsp+0xA0], xmm11
00007fa22efd204e  vmovaps [rsp+0xB0], xmm12
00007fa22efd2057  vmovaps [rsp+0xC0], xmm13
00007fa22efd2060  vmovaps [rsp+0xD0], xmm14
00007fa22efd2069  vmovaps [rsp+0xE0], xmm15
00007fa22efd2072  sub rsp, 0x30
00007fa22efd2076  movaps [rsp], xmm2
00007fa22efd207a  movaps [rsp+0x10], xmm1
00007fa22efd207f  movaps [rsp+0x20], xmm13
00007fa22efd2085  lea rdi, [rsp]
00007fa22efd2089  mov esi, 0x00
00007fa22efd208e  mov rax, 0x5E9D1A57D530
00007fa22efd2098  call rax
00007fa22efd209a  movaps xmm2, [rsp]
00007fa22efd209e  add rsp, 0x30
00007fa22efd20a2  vmovaps xmm0, [rsp]
00007fa22efd20a7  vmovaps xmm1, [rsp+0x10]
00007fa22efd20ad  vmovaps xmm3, [rsp+0x20]
00007fa22efd20b3  vmovaps xmm4, [rsp+0x30]
00007fa22efd20b9  vmovaps xmm5, [rsp+0x40]
00007fa22efd20bf  vmovaps xmm6, [rsp+0x50]
00007fa22efd20c5  vmovaps xmm7, [rsp+0x60]
00007fa22efd20cb  vmovaps xmm8, [rsp+0x70]
00007fa22efd20d1  vmovaps xmm9, [rsp+0x80]
00007fa22efd20da  vmovaps xmm10, [rsp+0x90]
00007fa22efd20e3  vmovaps xmm11, [rsp+0xA0]
00007fa22efd20ec  vmovaps xmm12, [rsp+0xB0]
00007fa22efd20f5  vmovaps xmm13, [rsp+0xC0]
00007fa22efd20fe  vmovaps xmm14, [rsp+0xD0]
00007fa22efd2107  vmovaps xmm15, [rsp+0xE0]
00007fa22efd2110  add rsp, 0xF0
00007fa22efd2117  pop r11
00007fa22efd2119  pop r10
00007fa22efd211b  pop r9
00007fa22efd211d  pop r8
00007fa22efd211f  pop rsi
00007fa22efd2120  pop rdi
00007fa22efd2121  pop rdx
00007fa22efd2122  pop rcx
00007fa22efd2123  pop rax
00007fa22efd2124  add rsp, 0x08
00007fa22efd2128  jmp 0x00007FA22EFCFBAB
00007fa22efd212d  call 0x00007FA22EDFF430
00007fa22efd2132  jmp 0x00007FA22EFCFBB8
00007fa22efd2137  sub rsp, 0x08
00007fa22efd213b  push rax
00007fa22efd213c  push rcx
00007fa22efd213d  push rdx
00007fa22efd213e  push rdi
00007fa22efd213f  push rsi
00007fa22efd2140  push r8
00007fa22efd2142  push r9
00007fa22efd2144  push r10
00007fa22efd2146  push r11
00007fa22efd2148  sub rsp, 0xF0
00007fa22efd214f  vmovaps [rsp], xmm0
00007fa22efd2154  vmovaps [rsp+0x10], xmm1
00007fa22efd215a  vmovaps [rsp+0x20], xmm2
00007fa22efd2160  vmovaps [rsp+0x30], xmm3
00007fa22efd2166  vmovaps [rsp+0x40], xmm4
00007fa22efd216c  vmovaps [rsp+0x50], xmm5
00007fa22efd2172  vmovaps [rsp+0x60], xmm6
00007fa22efd2178  vmovaps [rsp+0x70], xmm7
00007fa22efd217e  vmovaps [rsp+0x80], xmm8
00007fa22efd2187  vmovaps [rsp+0x90], xmm9
00007fa22efd2190  vmovaps [rsp+0xA0], xmm10
00007fa22efd2199  vmovaps [rsp+0xB0], xmm11
00007fa22efd21a2  vmovaps [rsp+0xC0], xmm12
00007fa22efd21ab  vmovaps [rsp+0xD0], xmm13
00007fa22efd21b4  vmovaps [rsp+0xE0], xmm14
00007fa22efd21bd  sub rsp, 0x30
00007fa22efd21c1  movaps [rsp], xmm15
00007fa22efd21c6  movaps [rsp+0x10], xmm13
00007fa22efd21cc  movaps [rsp+0x20], xmm1
00007fa22efd21d1  lea rdi, [rsp]
00007fa22efd21d5  mov esi, 0x00
00007fa22efd21da  mov rax, 0x5E9D1A57D530
00007fa22efd21e4  call rax
00007fa22efd21e6  movaps xmm15, [rsp]
00007fa22efd21eb  add rsp, 0x30
00007fa22efd21ef  vmovaps xmm0, [rsp]
00007fa22efd21f4  vmovaps xmm1, [rsp+0x10]
00007fa22efd21fa  vmovaps xmm2, [rsp+0x20]
00007fa22efd2200  vmovaps xmm3, [rsp+0x30]
00007fa22efd2206  vmovaps xmm4, [rsp+0x40]
00007fa22efd220c  vmovaps xmm5, [rsp+0x50]
00007fa22efd2212  vmovaps xmm6, [rsp+0x60]
00007fa22efd2218  vmovaps xmm7, [rsp+0x70]
00007fa22efd221e  vmovaps xmm8, [rsp+0x80]
00007fa22efd2227  vmovaps xmm9, [rsp+0x90]
00007fa22efd2230  vmovaps xmm10, [rsp+0xA0]
00007fa22efd2239  vmovaps xmm11, [rsp+0xB0]
00007fa22efd2242  vmovaps xmm12, [rsp+0xC0]
00007fa22efd224b  vmovaps xmm13, [rsp+0xD0]
00007fa22efd2254  vmovaps xmm14, [rsp+0xE0]
00007fa22efd225d  add rsp, 0xF0
00007fa22efd2264  pop r11
00007fa22efd2266  pop r10
00007fa22efd2268  pop r9
00007fa22efd226a  pop r8
00007fa22efd226c  pop rsi
00007fa22efd226d  pop rdi
00007fa22efd226e  pop rdx
00007fa22efd226f  pop rcx
00007fa22efd2270  pop rax
00007fa22efd2271  add rsp, 0x08
00007fa22efd2275  jmp 0x00007FA22EFCFBF7
00007fa22efd227a  sub rsp, 0x08
00007fa22efd227e  push rax
00007fa22efd227f  push rcx
00007fa22efd2280  push rdx
00007fa22efd2281  push rdi
00007fa22efd2282  push rsi
00007fa22efd2283  push r8
00007fa22efd2285  push r9
00007fa22efd2287  push r10
00007fa22efd2289  push r11
00007fa22efd228b  sub rsp, 0xF0
00007fa22efd2292  vmovaps [rsp], xmm0
00007fa22efd2297  vmovaps [rsp+0x10], xmm1
00007fa22efd229d  vmovaps [rsp+0x20], xmm2
00007fa22efd22a3  vmovaps [rsp+0x30], xmm3
00007fa22efd22a9  vmovaps [rsp+0x40], xmm4
00007fa22efd22af  vmovaps [rsp+0x50], xmm5
00007fa22efd22b5  vmovaps [rsp+0x60], xmm6
00007fa22efd22bb  vmovaps [rsp+0x70], xmm7
00007fa22efd22c1  vmovaps [rsp+0x80], xmm8
00007fa22efd22ca  vmovaps [rsp+0x90], xmm9
00007fa22efd22d3  vmovaps [rsp+0xA0], xmm10
00007fa22efd22dc  vmovaps [rsp+0xB0], xmm11
00007fa22efd22e5  vmovaps [rsp+0xC0], xmm12
00007fa22efd22ee  vmovaps [rsp+0xD0], xmm13
00007fa22efd22f7  vmovaps [rsp+0xE0], xmm15
00007fa22efd2300  sub rsp, 0x30
00007fa22efd2304  movaps [rsp], xmm14
00007fa22efd2309  movaps [rsp+0x10], xmm11
00007fa22efd230f  movaps [rsp+0x20], xmm1
00007fa22efd2314  lea rdi, [rsp]
00007fa22efd2318  mov esi, 0x00
00007fa22efd231d  mov rax, 0x5E9D1A57D530
00007fa22efd2327  call rax
00007fa22efd2329  movaps xmm14, [rsp]
00007fa22efd232e  add rsp, 0x30
00007fa22efd2332  vmovaps xmm0, [rsp]
00007fa22efd2337  vmovaps xmm1, [rsp+0x10]
00007fa22efd233d  vmovaps xmm2, [rsp+0x20]
00007fa22efd2343  vmovaps xmm3, [rsp+0x30]
00007fa22efd2349  vmovaps xmm4, [rsp+0x40]
00007fa22efd234f  vmovaps xmm5, [rsp+0x50]
00007fa22efd2355  vmovaps xmm6, [rsp+0x60]
00007fa22efd235b  vmovaps xmm7, [rsp+0x70]
00007fa22efd2361  vmovaps xmm8, [rsp+0x80]
00007fa22efd236a  vmovaps xmm9, [rsp+0x90]
00007fa22efd2373  vmovaps xmm10, [rsp+0xA0]
00007fa22efd237c  vmovaps xmm11, [rsp+0xB0]
00007fa22efd2385  vmovaps xmm12, [rsp+0xC0]
00007fa22efd238e  vmovaps xmm13, [rsp+0xD0]
00007fa22efd2397  vmovaps xmm15, [rsp+0xE0]
00007fa22efd23a0  add rsp, 0xF0
00007fa22efd23a7  pop r11
00007fa22efd23a9  pop r10
00007fa22efd23ab  pop r9
00007fa22efd23ad  pop r8
00007fa22efd23af  pop rsi
00007fa22efd23b0  pop rdi
00007fa22efd23b1  pop rdx
00007fa22efd23b2  pop rcx
00007fa22efd23b3  pop rax
00007fa22efd23b4  add rsp, 0x08
00007fa22efd23b8  jmp 0x00007FA22EFCFC21
00007fa22efd23bd  sub rsp, 0x08
00007fa22efd23c1  push rax
00007fa22efd23c2  push rcx
00007fa22efd23c3  push rdx
00007fa22efd23c4  push rdi
00007fa22efd23c5  push rsi
00007fa22efd23c6  push r8
00007fa22efd23c8  push r9
00007fa22efd23ca  push r10
00007fa22efd23cc  push r11
00007fa22efd23ce  sub rsp, 0xF0
00007fa22efd23d5  vmovaps [rsp], xmm0
00007fa22efd23da  vmovaps [rsp+0x10], xmm1
00007fa22efd23e0  vmovaps [rsp+0x20], xmm2
00007fa22efd23e6  vmovaps [rsp+0x30], xmm3
00007fa22efd23ec  vmovaps [rsp+0x40], xmm4
00007fa22efd23f2  vmovaps [rsp+0x50], xmm5
00007fa22efd23f8  vmovaps [rsp+0x60], xmm6
00007fa22efd23fe  vmovaps [rsp+0x70], xmm7
00007fa22efd2404  vmovaps [rsp+0x80], xmm8
00007fa22efd240d  vmovaps [rsp+0x90], xmm9
00007fa22efd2416  vmovaps [rsp+0xA0], xmm10
00007fa22efd241f  vmovaps [rsp+0xB0], xmm11
00007fa22efd2428  vmovaps [rsp+0xC0], xmm12
00007fa22efd2431  vmovaps [rsp+0xD0], xmm14
00007fa22efd243a  vmovaps [rsp+0xE0], xmm15
00007fa22efd2443  sub rsp, 0x30
00007fa22efd2447  movaps [rsp], xmm13
00007fa22efd244c  movaps [rsp+0x10], xmm11
00007fa22efd2452  movaps [rsp+0x20], xmm1
00007fa22efd2457  lea rdi, [rsp]
00007fa22efd245b  mov esi, 0x00
00007fa22efd2460  mov rax, 0x5E9D1A57D530
00007fa22efd246a  call rax
00007fa22efd246c  movaps xmm13, [rsp]
00007fa22efd2471  add rsp, 0x30
00007fa22efd2475  vmovaps xmm0, [rsp]
00007fa22efd247a  vmovaps xmm1, [rsp+0x10]
00007fa22efd2480  vmovaps xmm2, [rsp+0x20]
00007fa22efd2486  vmovaps xmm3, [rsp+0x30]
00007fa22efd248c  vmovaps xmm4, [rsp+0x40]
00007fa22efd2492  vmovaps xmm5, [rsp+0x50]
00007fa22efd2498  vmovaps xmm6, [rsp+0x60]
00007fa22efd249e  vmovaps xmm7, [rsp+0x70]
00007fa22efd24a4  vmovaps xmm8, [rsp+0x80]
00007fa22efd24ad  vmovaps xmm9, [rsp+0x90]
00007fa22efd24b6  vmovaps xmm10, [rsp+0xA0]
00007fa22efd24bf  vmovaps xmm11, [rsp+0xB0]
00007fa22efd24c8  vmovaps xmm12, [rsp+0xC0]
00007fa22efd24d1  vmovaps xmm14, [rsp+0xD0]
00007fa22efd24da  vmovaps xmm15, [rsp+0xE0]
00007fa22efd24e3  add rsp, 0xF0
00007fa22efd24ea  pop r11
00007fa22efd24ec  pop r10
00007fa22efd24ee  pop r9
00007fa22efd24f0  pop r8
00007fa22efd24f2  pop rsi
00007fa22efd24f3  pop rdi
00007fa22efd24f4  pop rdx
00007fa22efd24f5  pop rcx
00007fa22efd24f6  pop rax
00007fa22efd24f7  add rsp, 0x08
00007fa22efd24fb  jmp 0x00007FA22EFCFC76
00007fa22efd2500  call 0x00007FA22EDFF430
00007fa22efd2505  jmp 0x00007FA22EFCFC83
00007fa22efd250a  sub rsp, 0x08
00007fa22efd250e  push rax
00007fa22efd250f  push rcx
00007fa22efd2510  push rdx
00007fa22efd2511  push rdi
00007fa22efd2512  push rsi
00007fa22efd2513  push r8
00007fa22efd2515  push r9
00007fa22efd2517  push r10
00007fa22efd2519  push r11
00007fa22efd251b  sub rsp, 0xF0
00007fa22efd2522  vmovaps [rsp], xmm0
00007fa22efd2527  vmovaps [rsp+0x10], xmm1
00007fa22efd252d  vmovaps [rsp+0x20], xmm2
00007fa22efd2533  vmovaps [rsp+0x30], xmm3
00007fa22efd2539  vmovaps [rsp+0x40], xmm4
00007fa22efd253f  vmovaps [rsp+0x50], xmm5
00007fa22efd2545  vmovaps [rsp+0x60], xmm6
00007fa22efd254b  vmovaps [rsp+0x70], xmm7
00007fa22efd2551  vmovaps [rsp+0x80], xmm8
00007fa22efd255a  vmovaps [rsp+0x90], xmm9
00007fa22efd2563  vmovaps [rsp+0xA0], xmm10
00007fa22efd256c  vmovaps [rsp+0xB0], xmm11
00007fa22efd2575  vmovaps [rsp+0xC0], xmm12
00007fa22efd257e  vmovaps [rsp+0xD0], xmm13
00007fa22efd2587  vmovaps [rsp+0xE0], xmm14
00007fa22efd2590  sub rsp, 0x30
00007fa22efd2594  movaps [rsp], xmm15
00007fa22efd2599  movaps [rsp+0x10], xmm11
00007fa22efd259f  movaps [rsp+0x20], xmm1
00007fa22efd25a4  lea rdi, [rsp]
00007fa22efd25a8  mov esi, 0x00
00007fa22efd25ad  mov rax, 0x5E9D1A57D530
00007fa22efd25b7  call rax
00007fa22efd25b9  movaps xmm15, [rsp]
00007fa22efd25be  add rsp, 0x30
00007fa22efd25c2  vmovaps xmm0, [rsp]
00007fa22efd25c7  vmovaps xmm1, [rsp+0x10]
00007fa22efd25cd  vmovaps xmm2, [rsp+0x20]
00007fa22efd25d3  vmovaps xmm3, [rsp+0x30]
00007fa22efd25d9  vmovaps xmm4, [rsp+0x40]
00007fa22efd25df  vmovaps xmm5, [rsp+0x50]
00007fa22efd25e5  vmovaps xmm6, [rsp+0x60]
00007fa22efd25eb  vmovaps xmm7, [rsp+0x70]
00007fa22efd25f1  vmovaps xmm8, [rsp+0x80]
00007fa22efd25fa  vmovaps xmm9, [rsp+0x90]
00007fa22efd2603  vmovaps xmm10, [rsp+0xA0]
00007fa22efd260c  vmovaps xmm11, [rsp+0xB0]
00007fa22efd2615  vmovaps xmm12, [rsp+0xC0]
00007fa22efd261e  vmovaps xmm13, [rsp+0xD0]
00007fa22efd2627  vmovaps xmm14, [rsp+0xE0]
00007fa22efd2630  add rsp, 0xF0
00007fa22efd2637  pop r11
00007fa22efd2639  pop r10
00007fa22efd263b  pop r9
00007fa22efd263d  pop r8
00007fa22efd263f  pop rsi
00007fa22efd2640  pop rdi
00007fa22efd2641  pop rdx
00007fa22efd2642  pop rcx
00007fa22efd2643  pop rax
00007fa22efd2644  add rsp, 0x08
00007fa22efd2648  jmp 0x00007FA22EFCFCBC
00007fa22efd264d  sub rsp, 0x08
00007fa22efd2651  push rax
00007fa22efd2652  push rcx
00007fa22efd2653  push rdx
00007fa22efd2654  push rdi
00007fa22efd2655  push rsi
00007fa22efd2656  push r8
00007fa22efd2658  push r9
00007fa22efd265a  push r10
00007fa22efd265c  push r11
00007fa22efd265e  sub rsp, 0xF0
00007fa22efd2665  vmovaps [rsp], xmm0
00007fa22efd266a  vmovaps [rsp+0x10], xmm1
00007fa22efd2670  vmovaps [rsp+0x20], xmm2
00007fa22efd2676  vmovaps [rsp+0x30], xmm3
00007fa22efd267c  vmovaps [rsp+0x40], xmm4
00007fa22efd2682  vmovaps [rsp+0x50], xmm5
00007fa22efd2688  vmovaps [rsp+0x60], xmm6
00007fa22efd268e  vmovaps [rsp+0x70], xmm7
00007fa22efd2694  vmovaps [rsp+0x80], xmm8
00007fa22efd269d  vmovaps [rsp+0x90], xmm9
00007fa22efd26a6  vmovaps [rsp+0xA0], xmm10
00007fa22efd26af  vmovaps [rsp+0xB0], xmm12
00007fa22efd26b8  vmovaps [rsp+0xC0], xmm13
00007fa22efd26c1  vmovaps [rsp+0xD0], xmm14
00007fa22efd26ca  vmovaps [rsp+0xE0], xmm15
00007fa22efd26d3  sub rsp, 0x30
00007fa22efd26d7  movaps [rsp], xmm11
00007fa22efd26dc  movaps [rsp+0x10], xmm6
00007fa22efd26e1  movaps [rsp+0x20], xmm14
00007fa22efd26e7  lea rdi, [rsp]
00007fa22efd26eb  mov esi, 0x00
00007fa22efd26f0  mov rax, 0x5E9D1A57D530
00007fa22efd26fa  call rax
00007fa22efd26fc  movaps xmm11, [rsp]
00007fa22efd2701  add rsp, 0x30
00007fa22efd2705  vmovaps xmm0, [rsp]
00007fa22efd270a  vmovaps xmm1, [rsp+0x10]
00007fa22efd2710  vmovaps xmm2, [rsp+0x20]
00007fa22efd2716  vmovaps xmm3, [rsp+0x30]
00007fa22efd271c  vmovaps xmm4, [rsp+0x40]
00007fa22efd2722  vmovaps xmm5, [rsp+0x50]
00007fa22efd2728  vmovaps xmm6, [rsp+0x60]
00007fa22efd272e  vmovaps xmm7, [rsp+0x70]
00007fa22efd2734  vmovaps xmm8, [rsp+0x80]
00007fa22efd273d  vmovaps xmm9, [rsp+0x90]
00007fa22efd2746  vmovaps xmm10, [rsp+0xA0]
00007fa22efd274f  vmovaps xmm12, [rsp+0xB0]
00007fa22efd2758  vmovaps xmm13, [rsp+0xC0]
00007fa22efd2761  vmovaps xmm14, [rsp+0xD0]
00007fa22efd276a  vmovaps xmm15, [rsp+0xE0]
00007fa22efd2773  add rsp, 0xF0
00007fa22efd277a  pop r11
00007fa22efd277c  pop r10
00007fa22efd277e  pop r9
00007fa22efd2780  pop r8
00007fa22efd2782  pop rsi
00007fa22efd2783  pop rdi
00007fa22efd2784  pop rdx
00007fa22efd2785  pop rcx
00007fa22efd2786  pop rax
00007fa22efd2787  add rsp, 0x08
00007fa22efd278b  jmp 0x00007FA22EFCFD34
00007fa22efd2790  call 0x00007FA22EDFF430
00007fa22efd2795  jmp 0x00007FA22EFCFD3E
00007fa22efd279a  sub rsp, 0x08
00007fa22efd279e  push rax
00007fa22efd279f  push rcx
00007fa22efd27a0  push rdx
00007fa22efd27a1  push rdi
00007fa22efd27a2  push rsi
00007fa22efd27a3  push r8
00007fa22efd27a5  push r9
00007fa22efd27a7  push r10
00007fa22efd27a9  push r11
00007fa22efd27ab  sub rsp, 0xF0
00007fa22efd27b2  vmovaps [rsp], xmm0
00007fa22efd27b7  vmovaps [rsp+0x10], xmm1
00007fa22efd27bd  vmovaps [rsp+0x20], xmm2
00007fa22efd27c3  vmovaps [rsp+0x30], xmm3
00007fa22efd27c9  vmovaps [rsp+0x40], xmm4
00007fa22efd27cf  vmovaps [rsp+0x50], xmm5
00007fa22efd27d5  vmovaps [rsp+0x60], xmm6
00007fa22efd27db  vmovaps [rsp+0x70], xmm7
00007fa22efd27e1  vmovaps [rsp+0x80], xmm8
00007fa22efd27ea  vmovaps [rsp+0x90], xmm9
00007fa22efd27f3  vmovaps [rsp+0xA0], xmm10
00007fa22efd27fc  vmovaps [rsp+0xB0], xmm11
00007fa22efd2805  vmovaps [rsp+0xC0], xmm12
00007fa22efd280e  vmovaps [rsp+0xD0], xmm13
00007fa22efd2817  vmovaps [rsp+0xE0], xmm15
00007fa22efd2820  sub rsp, 0x30
00007fa22efd2824  movaps [rsp], xmm14
00007fa22efd2829  movaps [rsp+0x10], xmm6
00007fa22efd282e  movaps [rsp+0x20], xmm2
00007fa22efd2833  lea rdi, [rsp]
00007fa22efd2837  mov esi, 0x00
00007fa22efd283c  mov rax, 0x5E9D1A57D530
00007fa22efd2846  call rax
00007fa22efd2848  movaps xmm14, [rsp]
00007fa22efd284d  add rsp, 0x30
00007fa22efd2851  vmovaps xmm0, [rsp]
00007fa22efd2856  vmovaps xmm1, [rsp+0x10]
00007fa22efd285c  vmovaps xmm2, [rsp+0x20]
00007fa22efd2862  vmovaps xmm3, [rsp+0x30]
00007fa22efd2868  vmovaps xmm4, [rsp+0x40]
00007fa22efd286e  vmovaps xmm5, [rsp+0x50]
00007fa22efd2874  vmovaps xmm6, [rsp+0x60]
00007fa22efd287a  vmovaps xmm7, [rsp+0x70]
00007fa22efd2880  vmovaps xmm8, [rsp+0x80]
00007fa22efd2889  vmovaps xmm9, [rsp+0x90]
00007fa22efd2892  vmovaps xmm10, [rsp+0xA0]
00007fa22efd289b  vmovaps xmm11, [rsp+0xB0]
00007fa22efd28a4  vmovaps xmm12, [rsp+0xC0]
00007fa22efd28ad  vmovaps xmm13, [rsp+0xD0]
00007fa22efd28b6  vmovaps xmm15, [rsp+0xE0]
00007fa22efd28bf  add rsp, 0xF0
00007fa22efd28c6  pop r11
00007fa22efd28c8  pop r10
00007fa22efd28ca  pop r9
00007fa22efd28cc  pop r8
00007fa22efd28ce  pop rsi
00007fa22efd28cf  pop rdi
00007fa22efd28d0  pop rdx
00007fa22efd28d1  pop rcx
00007fa22efd28d2  pop rax
00007fa22efd28d3  add rsp, 0x08
00007fa22efd28d7  jmp 0x00007FA22EFCFD72
00007fa22efd28dc  sub rsp, 0x08
00007fa22efd28e0  push rax
00007fa22efd28e1  push rcx
00007fa22efd28e2  push rdx
00007fa22efd28e3  push rdi
00007fa22efd28e4  push rsi
00007fa22efd28e5  push r8
00007fa22efd28e7  push r9
00007fa22efd28e9  push r10
00007fa22efd28eb  push r11
00007fa22efd28ed  sub rsp, 0xF0
00007fa22efd28f4  vmovaps [rsp], xmm0
00007fa22efd28f9  vmovaps [rsp+0x10], xmm1
00007fa22efd28ff  vmovaps [rsp+0x20], xmm2
00007fa22efd2905  vmovaps [rsp+0x30], xmm3
00007fa22efd290b  vmovaps [rsp+0x40], xmm4
00007fa22efd2911  vmovaps [rsp+0x50], xmm5
00007fa22efd2917  vmovaps [rsp+0x60], xmm7
00007fa22efd291d  vmovaps [rsp+0x70], xmm8
00007fa22efd2923  vmovaps [rsp+0x80], xmm9
00007fa22efd292c  vmovaps [rsp+0x90], xmm10
00007fa22efd2935  vmovaps [rsp+0xA0], xmm11
00007fa22efd293e  vmovaps [rsp+0xB0], xmm12
00007fa22efd2947  vmovaps [rsp+0xC0], xmm13
00007fa22efd2950  vmovaps [rsp+0xD0], xmm14
00007fa22efd2959  vmovaps [rsp+0xE0], xmm15
00007fa22efd2962  sub rsp, 0x30
00007fa22efd2966  movaps [rsp], xmm6
00007fa22efd296a  movaps [rsp+0x10], xmm5
00007fa22efd296f  movaps [rsp+0x20], xmm1
00007fa22efd2974  lea rdi, [rsp]
00007fa22efd2978  mov esi, 0x00
00007fa22efd297d  mov rax, 0x5E9D1A57D530
00007fa22efd2987  call rax
00007fa22efd2989  movaps xmm6, [rsp]
00007fa22efd298d  add rsp, 0x30
00007fa22efd2991  vmovaps xmm0, [rsp]
00007fa22efd2996  vmovaps xmm1, [rsp+0x10]
00007fa22efd299c  vmovaps xmm2, [rsp+0x20]
00007fa22efd29a2  vmovaps xmm3, [rsp+0x30]
00007fa22efd29a8  vmovaps xmm4, [rsp+0x40]
00007fa22efd29ae  vmovaps xmm5, [rsp+0x50]
00007fa22efd29b4  vmovaps xmm7, [rsp+0x60]
00007fa22efd29ba  vmovaps xmm8, [rsp+0x70]
00007fa22efd29c0  vmovaps xmm9, [rsp+0x80]
00007fa22efd29c9  vmovaps xmm10, [rsp+0x90]
00007fa22efd29d2  vmovaps xmm11, [rsp+0xA0]
00007fa22efd29db  vmovaps xmm12, [rsp+0xB0]
00007fa22efd29e4  vmovaps xmm13, [rsp+0xC0]
00007fa22efd29ed  vmovaps xmm14, [rsp+0xD0]
00007fa22efd29f6  vmovaps xmm15, [rsp+0xE0]
00007fa22efd29ff  add rsp, 0xF0
00007fa22efd2a06  pop r11
00007fa22efd2a08  pop r10
00007fa22efd2a0a  pop r9
00007fa22efd2a0c  pop r8
00007fa22efd2a0e  pop rsi
00007fa22efd2a0f  pop rdi
00007fa22efd2a10  pop rdx
00007fa22efd2a11  pop rcx
00007fa22efd2a12  pop rax
00007fa22efd2a13  add rsp, 0x08
00007fa22efd2a17  jmp 0x00007FA22EFCFD98
00007fa22efd2a1c  sub rsp, 0x08
00007fa22efd2a20  push rax
00007fa22efd2a21  push rcx
00007fa22efd2a22  push rdx
00007fa22efd2a23  push rdi
00007fa22efd2a24  push rsi
00007fa22efd2a25  push r8
00007fa22efd2a27  push r9
00007fa22efd2a29  push r10
00007fa22efd2a2b  push r11
00007fa22efd2a2d  sub rsp, 0xF0
00007fa22efd2a34  vmovaps [rsp], xmm0
00007fa22efd2a39  vmovaps [rsp+0x10], xmm2
00007fa22efd2a3f  vmovaps [rsp+0x20], xmm3
00007fa22efd2a45  vmovaps [rsp+0x30], xmm4
00007fa22efd2a4b  vmovaps [rsp+0x40], xmm5
00007fa22efd2a51  vmovaps [rsp+0x50], xmm6
00007fa22efd2a57  vmovaps [rsp+0x60], xmm7
00007fa22efd2a5d  vmovaps [rsp+0x70], xmm8
00007fa22efd2a63  vmovaps [rsp+0x80], xmm9
00007fa22efd2a6c  vmovaps [rsp+0x90], xmm10
00007fa22efd2a75  vmovaps [rsp+0xA0], xmm11
00007fa22efd2a7e  vmovaps [rsp+0xB0], xmm12
00007fa22efd2a87  vmovaps [rsp+0xC0], xmm13
00007fa22efd2a90  vmovaps [rsp+0xD0], xmm14
00007fa22efd2a99  vmovaps [rsp+0xE0], xmm15
00007fa22efd2aa2  sub rsp, 0x30
00007fa22efd2aa6  movaps [rsp], xmm1
00007fa22efd2aaa  movaps [rsp+0x10], xmm5
00007fa22efd2aaf  movaps [rsp+0x20], xmm13
00007fa22efd2ab5  lea rdi, [rsp]
00007fa22efd2ab9  mov esi, 0x00
00007fa22efd2abe  mov rax, 0x5E9D1A57D530
00007fa22efd2ac8  call rax
00007fa22efd2aca  movaps xmm1, [rsp]
00007fa22efd2ace  add rsp, 0x30
00007fa22efd2ad2  vmovaps xmm0, [rsp]
00007fa22efd2ad7  vmovaps xmm2, [rsp+0x10]
00007fa22efd2add  vmovaps xmm3, [rsp+0x20]
00007fa22efd2ae3  vmovaps xmm4, [rsp+0x30]
00007fa22efd2ae9  vmovaps xmm5, [rsp+0x40]
00007fa22efd2aef  vmovaps xmm6, [rsp+0x50]
00007fa22efd2af5  vmovaps xmm7, [rsp+0x60]
00007fa22efd2afb  vmovaps xmm8, [rsp+0x70]
00007fa22efd2b01  vmovaps xmm9, [rsp+0x80]
00007fa22efd2b0a  vmovaps xmm10, [rsp+0x90]
00007fa22efd2b13  vmovaps xmm11, [rsp+0xA0]
00007fa22efd2b1c  vmovaps xmm12, [rsp+0xB0]
00007fa22efd2b25  vmovaps xmm13, [rsp+0xC0]
00007fa22efd2b2e  vmovaps xmm14, [rsp+0xD0]
00007fa22efd2b37  vmovaps xmm15, [rsp+0xE0]
00007fa22efd2b40  add rsp, 0xF0
00007fa22efd2b47  pop r11
00007fa22efd2b49  pop r10
00007fa22efd2b4b  pop r9
00007fa22efd2b4d  pop r8
00007fa22efd2b4f  pop rsi
00007fa22efd2b50  pop rdi
00007fa22efd2b51  pop rdx
00007fa22efd2b52  pop rcx
00007fa22efd2b53  pop rax
00007fa22efd2b54  add rsp, 0x08
00007fa22efd2b58  jmp 0x00007FA22EFCFDB6
00007fa22efd2b5d  sub rsp, 0x08
00007fa22efd2b61  push rax
00007fa22efd2b62  push rcx
00007fa22efd2b63  push rdx
00007fa22efd2b64  push rdi
00007fa22efd2b65  push rsi
00007fa22efd2b66  push r8
00007fa22efd2b68  push r9
00007fa22efd2b6a  push r10
00007fa22efd2b6c  push r11
00007fa22efd2b6e  sub rsp, 0xF0
00007fa22efd2b75  vmovaps [rsp], xmm0
00007fa22efd2b7a  vmovaps [rsp+0x10], xmm1
00007fa22efd2b80  vmovaps [rsp+0x20], xmm2
00007fa22efd2b86  vmovaps [rsp+0x30], xmm3
00007fa22efd2b8c  vmovaps [rsp+0x40], xmm4
00007fa22efd2b92  vmovaps [rsp+0x50], xmm6
00007fa22efd2b98  vmovaps [rsp+0x60], xmm7
00007fa22efd2b9e  vmovaps [rsp+0x70], xmm8
00007fa22efd2ba4  vmovaps [rsp+0x80], xmm9
00007fa22efd2bad  vmovaps [rsp+0x90], xmm10
00007fa22efd2bb6  vmovaps [rsp+0xA0], xmm11
00007fa22efd2bbf  vmovaps [rsp+0xB0], xmm12
00007fa22efd2bc8  vmovaps [rsp+0xC0], xmm13
00007fa22efd2bd1  vmovaps [rsp+0xD0], xmm14
00007fa22efd2bda  vmovaps [rsp+0xE0], xmm15
00007fa22efd2be3  sub rsp, 0x30
00007fa22efd2be7  movaps [rsp], xmm5
00007fa22efd2beb  movaps [rsp+0x10], xmm2
00007fa22efd2bf0  movaps [rsp+0x20], xmm13
00007fa22efd2bf6  lea rdi, [rsp]
00007fa22efd2bfa  mov esi, 0x00
00007fa22efd2bff  mov rax, 0x5E9D1A57D530
00007fa22efd2c09  call rax
00007fa22efd2c0b  movaps xmm5, [rsp]
00007fa22efd2c0f  add rsp, 0x30
00007fa22efd2c13  vmovaps xmm0, [rsp]
00007fa22efd2c18  vmovaps xmm1, [rsp+0x10]
00007fa22efd2c1e  vmovaps xmm2, [rsp+0x20]
00007fa22efd2c24  vmovaps xmm3, [rsp+0x30]
00007fa22efd2c2a  vmovaps xmm4, [rsp+0x40]
00007fa22efd2c30  vmovaps xmm6, [rsp+0x50]
00007fa22efd2c36  vmovaps xmm7, [rsp+0x60]
00007fa22efd2c3c  vmovaps xmm8, [rsp+0x70]
00007fa22efd2c42  vmovaps xmm9, [rsp+0x80]
00007fa22efd2c4b  vmovaps xmm10, [rsp+0x90]
00007fa22efd2c54  vmovaps xmm11, [rsp+0xA0]
00007fa22efd2c5d  vmovaps xmm12, [rsp+0xB0]
00007fa22efd2c66  vmovaps xmm13, [rsp+0xC0]
00007fa22efd2c6f  vmovaps xmm14, [rsp+0xD0]
00007fa22efd2c78  vmovaps xmm15, [rsp+0xE0]
00007fa22efd2c81  add rsp, 0xF0
00007fa22efd2c88  pop r11
00007fa22efd2c8a  pop r10
00007fa22efd2c8c  pop r9
00007fa22efd2c8e  pop r8
00007fa22efd2c90  pop rsi
00007fa22efd2c91  pop rdi
00007fa22efd2c92  pop rdx
00007fa22efd2c93  pop rcx
00007fa22efd2c94  pop rax
00007fa22efd2c95  add rsp, 0x08
00007fa22efd2c99  jmp 0x00007FA22EFCFDEC
00007fa22efd2c9e  sub rsp, 0x08
00007fa22efd2ca2  push rax
00007fa22efd2ca3  push rcx
00007fa22efd2ca4  push rdx
00007fa22efd2ca5  push rdi
00007fa22efd2ca6  push rsi
00007fa22efd2ca7  push r8
00007fa22efd2ca9  push r9
00007fa22efd2cab  push r10
00007fa22efd2cad  push r11
00007fa22efd2caf  sub rsp, 0xF0
00007fa22efd2cb6  vmovaps [rsp], xmm0
00007fa22efd2cbb  vmovaps [rsp+0x10], xmm1
00007fa22efd2cc1  vmovaps [rsp+0x20], xmm2
00007fa22efd2cc7  vmovaps [rsp+0x30], xmm3
00007fa22efd2ccd  vmovaps [rsp+0x40], xmm4
00007fa22efd2cd3  vmovaps [rsp+0x50], xmm5
00007fa22efd2cd9  vmovaps [rsp+0x60], xmm6
00007fa22efd2cdf  vmovaps [rsp+0x70], xmm7
00007fa22efd2ce5  vmovaps [rsp+0x80], xmm8
00007fa22efd2cee  vmovaps [rsp+0x90], xmm9
00007fa22efd2cf7  vmovaps [rsp+0xA0], xmm10
00007fa22efd2d00  vmovaps [rsp+0xB0], xmm11
00007fa22efd2d09  vmovaps [rsp+0xC0], xmm12
00007fa22efd2d12  vmovaps [rsp+0xD0], xmm14
00007fa22efd2d1b  vmovaps [rsp+0xE0], xmm15
00007fa22efd2d24  sub rsp, 0x30
00007fa22efd2d28  movaps [rsp], xmm13
00007fa22efd2d2d  movaps [rsp+0x10], xmm10
00007fa22efd2d33  movaps [rsp+0x20], xmm1
00007fa22efd2d38  lea rdi, [rsp]
00007fa22efd2d3c  mov esi, 0x00
00007fa22efd2d41  mov rax, 0x5E9D1A57D530
00007fa22efd2d4b  call rax
00007fa22efd2d4d  movaps xmm13, [rsp]
00007fa22efd2d52  add rsp, 0x30
00007fa22efd2d56  vmovaps xmm0, [rsp]
00007fa22efd2d5b  vmovaps xmm1, [rsp+0x10]
00007fa22efd2d61  vmovaps xmm2, [rsp+0x20]
00007fa22efd2d67  vmovaps xmm3, [rsp+0x30]
00007fa22efd2d6d  vmovaps xmm4, [rsp+0x40]
00007fa22efd2d73  vmovaps xmm5, [rsp+0x50]
00007fa22efd2d79  vmovaps xmm6, [rsp+0x60]
00007fa22efd2d7f  vmovaps xmm7, [rsp+0x70]
00007fa22efd2d85  vmovaps xmm8, [rsp+0x80]
00007fa22efd2d8e  vmovaps xmm9, [rsp+0x90]
00007fa22efd2d97  vmovaps xmm10, [rsp+0xA0]
00007fa22efd2da0  vmovaps xmm11, [rsp+0xB0]
00007fa22efd2da9  vmovaps xmm12, [rsp+0xC0]
00007fa22efd2db2  vmovaps xmm14, [rsp+0xD0]
00007fa22efd2dbb  vmovaps xmm15, [rsp+0xE0]
00007fa22efd2dc4  add rsp, 0xF0
00007fa22efd2dcb  pop r11
00007fa22efd2dcd  pop r10
00007fa22efd2dcf  pop r9
00007fa22efd2dd1  pop r8
00007fa22efd2dd3  pop rsi
00007fa22efd2dd4  pop rdi
00007fa22efd2dd5  pop rdx
00007fa22efd2dd6  pop rcx
00007fa22efd2dd7  pop rax
00007fa22efd2dd8  add rsp, 0x08
00007fa22efd2ddc  jmp 0x00007FA22EFCFE15
00007fa22efd2de1  sub rsp, 0x08
00007fa22efd2de5  push rax
00007fa22efd2de6  push rcx
00007fa22efd2de7  push rdx
00007fa22efd2de8  push rdi
00007fa22efd2de9  push rsi
00007fa22efd2dea  push r8
00007fa22efd2dec  push r9
00007fa22efd2dee  push r10
00007fa22efd2df0  push r11
00007fa22efd2df2  sub rsp, 0xF0
00007fa22efd2df9  vmovaps [rsp], xmm0
00007fa22efd2dfe  vmovaps [rsp+0x10], xmm2
00007fa22efd2e04  vmovaps [rsp+0x20], xmm3
00007fa22efd2e0a  vmovaps [rsp+0x30], xmm4
00007fa22efd2e10  vmovaps [rsp+0x40], xmm5
00007fa22efd2e16  vmovaps [rsp+0x50], xmm6
00007fa22efd2e1c  vmovaps [rsp+0x60], xmm7
00007fa22efd2e22  vmovaps [rsp+0x70], xmm8
00007fa22efd2e28  vmovaps [rsp+0x80], xmm9
00007fa22efd2e31  vmovaps [rsp+0x90], xmm10
00007fa22efd2e3a  vmovaps [rsp+0xA0], xmm11
00007fa22efd2e43  vmovaps [rsp+0xB0], xmm12
00007fa22efd2e4c  vmovaps [rsp+0xC0], xmm13
00007fa22efd2e55  vmovaps [rsp+0xD0], xmm14
00007fa22efd2e5e  vmovaps [rsp+0xE0], xmm15
00007fa22efd2e67  sub rsp, 0x30
00007fa22efd2e6b  movaps [rsp], xmm1
00007fa22efd2e6f  movaps [rsp+0x10], xmm15
00007fa22efd2e75  movaps [rsp+0x20], xmm10
00007fa22efd2e7b  lea rdi, [rsp]
00007fa22efd2e7f  mov esi, 0x00
00007fa22efd2e84  mov rax, 0x5E9D1A57D530
00007fa22efd2e8e  call rax
00007fa22efd2e90  movaps xmm1, [rsp]
00007fa22efd2e94  add rsp, 0x30
00007fa22efd2e98  vmovaps xmm0, [rsp]
00007fa22efd2e9d  vmovaps xmm2, [rsp+0x10]
00007fa22efd2ea3  vmovaps xmm3, [rsp+0x20]
00007fa22efd2ea9  vmovaps xmm4, [rsp+0x30]
00007fa22efd2eaf  vmovaps xmm5, [rsp+0x40]
00007fa22efd2eb5  vmovaps xmm6, [rsp+0x50]
00007fa22efd2ebb  vmovaps xmm7, [rsp+0x60]
00007fa22efd2ec1  vmovaps xmm8, [rsp+0x70]
00007fa22efd2ec7  vmovaps xmm9, [rsp+0x80]
00007fa22efd2ed0  vmovaps xmm10, [rsp+0x90]
00007fa22efd2ed9  vmovaps xmm11, [rsp+0xA0]
00007fa22efd2ee2  vmovaps xmm12, [rsp+0xB0]
00007fa22efd2eeb  vmovaps xmm13, [rsp+0xC0]
00007fa22efd2ef4  vmovaps xmm14, [rsp+0xD0]
00007fa22efd2efd  vmovaps xmm15, [rsp+0xE0]
00007fa22efd2f06  add rsp, 0xF0
00007fa22efd2f0d  pop r11
00007fa22efd2f0f  pop r10
00007fa22efd2f11  pop r9
00007fa22efd2f13  pop r8
00007fa22efd2f15  pop rsi
00007fa22efd2f16  pop rdi
00007fa22efd2f17  pop rdx
00007fa22efd2f18  pop rcx
00007fa22efd2f19  pop rax
00007fa22efd2f1a  add rsp, 0x08
00007fa22efd2f1e  jmp 0x00007FA22EFCFE34
00007fa22efd2f23  sub rsp, 0x08
00007fa22efd2f27  push rax
00007fa22efd2f28  push rcx
00007fa22efd2f29  push rdx
00007fa22efd2f2a  push rdi
00007fa22efd2f2b  push rsi
00007fa22efd2f2c  push r8
00007fa22efd2f2e  push r9
00007fa22efd2f30  push r10
00007fa22efd2f32  push r11
00007fa22efd2f34  sub rsp, 0xF0
00007fa22efd2f3b  vmovaps [rsp], xmm0
00007fa22efd2f40  vmovaps [rsp+0x10], xmm1
00007fa22efd2f46  vmovaps [rsp+0x20], xmm2
00007fa22efd2f4c  vmovaps [rsp+0x30], xmm3
00007fa22efd2f52  vmovaps [rsp+0x40], xmm4
00007fa22efd2f58  vmovaps [rsp+0x50], xmm5
00007fa22efd2f5e  vmovaps [rsp+0x60], xmm6
00007fa22efd2f64  vmovaps [rsp+0x70], xmm7
00007fa22efd2f6a  vmovaps [rsp+0x80], xmm8
00007fa22efd2f73  vmovaps [rsp+0x90], xmm9
00007fa22efd2f7c  vmovaps [rsp+0xA0], xmm10
00007fa22efd2f85  vmovaps [rsp+0xB0], xmm11
00007fa22efd2f8e  vmovaps [rsp+0xC0], xmm12
00007fa22efd2f97  vmovaps [rsp+0xD0], xmm13
00007fa22efd2fa0  vmovaps [rsp+0xE0], xmm14
00007fa22efd2fa9  sub rsp, 0x30
00007fa22efd2fad  movaps [rsp], xmm15
00007fa22efd2fb2  movaps [rsp+0x10], xmm10
00007fa22efd2fb8  movaps [rsp+0x20], xmm11
00007fa22efd2fbe  lea rdi, [rsp]
00007fa22efd2fc2  mov esi, 0x00
00007fa22efd2fc7  mov rax, 0x5E9D1A57D530
00007fa22efd2fd1  call rax
00007fa22efd2fd3  movaps xmm15, [rsp]
00007fa22efd2fd8  add rsp, 0x30
00007fa22efd2fdc  vmovaps xmm0, [rsp]
00007fa22efd2fe1  vmovaps xmm1, [rsp+0x10]
00007fa22efd2fe7  vmovaps xmm2, [rsp+0x20]
00007fa22efd2fed  vmovaps xmm3, [rsp+0x30]
00007fa22efd2ff3  vmovaps xmm4, [rsp+0x40]
00007fa22efd2ff9  vmovaps xmm5, [rsp+0x50]
00007fa22efd2fff  vmovaps xmm6, [rsp+0x60]
00007fa22efd3005  vmovaps xmm7, [rsp+0x70]
00007fa22efd300b  vmovaps xmm8, [rsp+0x80]
00007fa22efd3014  vmovaps xmm9, [rsp+0x90]
00007fa22efd301d  vmovaps xmm10, [rsp+0xA0]
00007fa22efd3026  vmovaps xmm11, [rsp+0xB0]
00007fa22efd302f  vmovaps xmm12, [rsp+0xC0]
00007fa22efd3038  vmovaps xmm13, [rsp+0xD0]
00007fa22efd3041  vmovaps xmm14, [rsp+0xE0]
00007fa22efd304a  add rsp, 0xF0
00007fa22efd3051  pop r11
00007fa22efd3053  pop r10
00007fa22efd3055  pop r9
00007fa22efd3057  pop r8
00007fa22efd3059  pop rsi
00007fa22efd305a  pop rdi
00007fa22efd305b  pop rdx
00007fa22efd305c  pop rcx
00007fa22efd305d  pop rax
00007fa22efd305e  add rsp, 0x08
00007fa22efd3062  jmp 0x00007FA22EFCFE57
00007fa22efd3067  sub rsp, 0x08
00007fa22efd306b  push rax
00007fa22efd306c  push rcx
00007fa22efd306d  push rdx
00007fa22efd306e  push rdi
00007fa22efd306f  push rsi
00007fa22efd3070  push r8
00007fa22efd3072  push r9
00007fa22efd3074  push r10
00007fa22efd3076  push r11
00007fa22efd3078  sub rsp, 0xF0
00007fa22efd307f  vmovaps [rsp], xmm0
00007fa22efd3084  vmovaps [rsp+0x10], xmm1
00007fa22efd308a  vmovaps [rsp+0x20], xmm2
00007fa22efd3090  vmovaps [rsp+0x30], xmm3
00007fa22efd3096  vmovaps [rsp+0x40], xmm4
00007fa22efd309c  vmovaps [rsp+0x50], xmm5
00007fa22efd30a2  vmovaps [rsp+0x60], xmm6
00007fa22efd30a8  vmovaps [rsp+0x70], xmm7
00007fa22efd30ae  vmovaps [rsp+0x80], xmm8
00007fa22efd30b7  vmovaps [rsp+0x90], xmm9
00007fa22efd30c0  vmovaps [rsp+0xA0], xmm11
00007fa22efd30c9  vmovaps [rsp+0xB0], xmm12
00007fa22efd30d2  vmovaps [rsp+0xC0], xmm13
00007fa22efd30db  vmovaps [rsp+0xD0], xmm14
00007fa22efd30e4  vmovaps [rsp+0xE0], xmm15
00007fa22efd30ed  sub rsp, 0x30
00007fa22efd30f1  movaps [rsp], xmm10
00007fa22efd30f6  movaps [rsp+0x10], xmm12
00007fa22efd30fc  movaps [rsp+0x20], xmm11
00007fa22efd3102  lea rdi, [rsp]
00007fa22efd3106  mov esi, 0x00
00007fa22efd310b  mov rax, 0x5E9D1A57D530
00007fa22efd3115  call rax
00007fa22efd3117  movaps xmm10, [rsp]
00007fa22efd311c  add rsp, 0x30
00007fa22efd3120  vmovaps xmm0, [rsp]
00007fa22efd3125  vmovaps xmm1, [rsp+0x10]
00007fa22efd312b  vmovaps xmm2, [rsp+0x20]
00007fa22efd3131  vmovaps xmm3, [rsp+0x30]
00007fa22efd3137  vmovaps xmm4, [rsp+0x40]
00007fa22efd313d  vmovaps xmm5, [rsp+0x50]
00007fa22efd3143  vmovaps xmm6, [rsp+0x60]
00007fa22efd3149  vmovaps xmm7, [rsp+0x70]
00007fa22efd314f  vmovaps xmm8, [rsp+0x80]
00007fa22efd3158  vmovaps xmm9, [rsp+0x90]
00007fa22efd3161  vmovaps xmm11, [rsp+0xA0]
00007fa22efd316a  vmovaps xmm12, [rsp+0xB0]
00007fa22efd3173  vmovaps xmm13, [rsp+0xC0]
00007fa22efd317c  vmovaps xmm14, [rsp+0xD0]
00007fa22efd3185  vmovaps xmm15, [rsp+0xE0]
00007fa22efd318e  add rsp, 0xF0
00007fa22efd3195  pop r11
00007fa22efd3197  pop r10
00007fa22efd3199  pop r9
00007fa22efd319b  pop r8
00007fa22efd319d  pop rsi
00007fa22efd319e  pop rdi
00007fa22efd319f  pop rdx
00007fa22efd31a0  pop rcx
00007fa22efd31a1  pop rax
00007fa22efd31a2  add rsp, 0x08
00007fa22efd31a6  jmp 0x00007FA22EFCFE80
00007fa22efd31ab  sub rsp, 0x08
00007fa22efd31af  push rax
00007fa22efd31b0  push rcx
00007fa22efd31b1  push rdx
00007fa22efd31b2  push rdi
00007fa22efd31b3  push rsi
00007fa22efd31b4  push r8
00007fa22efd31b6  push r9
00007fa22efd31b8  push r10
00007fa22efd31ba  push r11
00007fa22efd31bc  sub rsp, 0xF0
00007fa22efd31c3  vmovaps [rsp], xmm0
00007fa22efd31c8  vmovaps [rsp+0x10], xmm1
00007fa22efd31ce  vmovaps [rsp+0x20], xmm2
00007fa22efd31d4  vmovaps [rsp+0x30], xmm3
00007fa22efd31da  vmovaps [rsp+0x40], xmm4
00007fa22efd31e0  vmovaps [rsp+0x50], xmm5
00007fa22efd31e6  vmovaps [rsp+0x60], xmm6
00007fa22efd31ec  vmovaps [rsp+0x70], xmm7
00007fa22efd31f2  vmovaps [rsp+0x80], xmm8
00007fa22efd31fb  vmovaps [rsp+0x90], xmm9
00007fa22efd3204  vmovaps [rsp+0xA0], xmm10
00007fa22efd320d  vmovaps [rsp+0xB0], xmm12
00007fa22efd3216  vmovaps [rsp+0xC0], xmm13
00007fa22efd321f  vmovaps [rsp+0xD0], xmm14
00007fa22efd3228  vmovaps [rsp+0xE0], xmm15
00007fa22efd3231  sub rsp, 0x30
00007fa22efd3235  movaps [rsp], xmm11
00007fa22efd323a  movaps [rsp+0x10], xmm2
00007fa22efd323f  movaps [rsp+0x20], xmm12
00007fa22efd3245  lea rdi, [rsp]
00007fa22efd3249  mov esi, 0x00
00007fa22efd324e  mov rax, 0x5E9D1A57D530
00007fa22efd3258  call rax
00007fa22efd325a  movaps xmm11, [rsp]
00007fa22efd325f  add rsp, 0x30
00007fa22efd3263  vmovaps xmm0, [rsp]
00007fa22efd3268  vmovaps xmm1, [rsp+0x10]
00007fa22efd326e  vmovaps xmm2, [rsp+0x20]
00007fa22efd3274  vmovaps xmm3, [rsp+0x30]
00007fa22efd327a  vmovaps xmm4, [rsp+0x40]
00007fa22efd3280  vmovaps xmm5, [rsp+0x50]
00007fa22efd3286  vmovaps xmm6, [rsp+0x60]
00007fa22efd328c  vmovaps xmm7, [rsp+0x70]
00007fa22efd3292  vmovaps xmm8, [rsp+0x80]
00007fa22efd329b  vmovaps xmm9, [rsp+0x90]
00007fa22efd32a4  vmovaps xmm10, [rsp+0xA0]
00007fa22efd32ad  vmovaps xmm12, [rsp+0xB0]
00007fa22efd32b6  vmovaps xmm13, [rsp+0xC0]
00007fa22efd32bf  vmovaps xmm14, [rsp+0xD0]
00007fa22efd32c8  vmovaps xmm15, [rsp+0xE0]
00007fa22efd32d1  add rsp, 0xF0
00007fa22efd32d8  pop r11
00007fa22efd32da  pop r10
00007fa22efd32dc  pop r9
00007fa22efd32de  pop r8
00007fa22efd32e0  pop rsi
00007fa22efd32e1  pop rdi
00007fa22efd32e2  pop rdx
00007fa22efd32e3  pop rcx
00007fa22efd32e4  pop rax
00007fa22efd32e5  add rsp, 0x08
00007fa22efd32e9  jmp 0x00007FA22EFCFEB8
00007fa22efd32ee  sub rsp, 0x08
00007fa22efd32f2  push rax
00007fa22efd32f3  push rcx
00007fa22efd32f4  push rdx
00007fa22efd32f5  push rdi
00007fa22efd32f6  push rsi
00007fa22efd32f7  push r8
00007fa22efd32f9  push r9
00007fa22efd32fb  push r10
00007fa22efd32fd  push r11
00007fa22efd32ff  sub rsp, 0xF0
00007fa22efd3306  vmovaps [rsp], xmm0
00007fa22efd330b  vmovaps [rsp+0x10], xmm2
00007fa22efd3311  vmovaps [rsp+0x20], xmm3
00007fa22efd3317  vmovaps [rsp+0x30], xmm4
00007fa22efd331d  vmovaps [rsp+0x40], xmm5
00007fa22efd3323  vmovaps [rsp+0x50], xmm6
00007fa22efd3329  vmovaps [rsp+0x60], xmm7
00007fa22efd332f  vmovaps [rsp+0x70], xmm8
00007fa22efd3335  vmovaps [rsp+0x80], xmm9
00007fa22efd333e  vmovaps [rsp+0x90], xmm10
00007fa22efd3347  vmovaps [rsp+0xA0], xmm11
00007fa22efd3350  vmovaps [rsp+0xB0], xmm12
00007fa22efd3359  vmovaps [rsp+0xC0], xmm13
00007fa22efd3362  vmovaps [rsp+0xD0], xmm14
00007fa22efd336b  vmovaps [rsp+0xE0], xmm15
00007fa22efd3374  sub rsp, 0x30
00007fa22efd3378  movaps [rsp], xmm1
00007fa22efd337c  movaps [rsp+0x10], xmm14
00007fa22efd3382  movaps [rsp+0x20], xmm6
00007fa22efd3387  lea rdi, [rsp]
00007fa22efd338b  mov esi, 0x00
00007fa22efd3390  mov rax, 0x5E9D1A57D530
00007fa22efd339a  call rax
00007fa22efd339c  movaps xmm1, [rsp]
00007fa22efd33a0  add rsp, 0x30
00007fa22efd33a4  vmovaps xmm0, [rsp]
00007fa22efd33a9  vmovaps xmm2, [rsp+0x10]
00007fa22efd33af  vmovaps xmm3, [rsp+0x20]
00007fa22efd33b5  vmovaps xmm4, [rsp+0x30]
00007fa22efd33bb  vmovaps xmm5, [rsp+0x40]
00007fa22efd33c1  vmovaps xmm6, [rsp+0x50]
00007fa22efd33c7  vmovaps xmm7, [rsp+0x60]
00007fa22efd33cd  vmovaps xmm8, [rsp+0x70]
00007fa22efd33d3  vmovaps xmm9, [rsp+0x80]
00007fa22efd33dc  vmovaps xmm10, [rsp+0x90]
00007fa22efd33e5  vmovaps xmm11, [rsp+0xA0]
00007fa22efd33ee  vmovaps xmm12, [rsp+0xB0]
00007fa22efd33f7  vmovaps xmm13, [rsp+0xC0]
00007fa22efd3400  vmovaps xmm14, [rsp+0xD0]
00007fa22efd3409  vmovaps xmm15, [rsp+0xE0]
00007fa22efd3412  add rsp, 0xF0
00007fa22efd3419  pop r11
00007fa22efd341b  pop r10
00007fa22efd341d  pop r9
00007fa22efd341f  pop r8
00007fa22efd3421  pop rsi
00007fa22efd3422  pop rdi
00007fa22efd3423  pop rdx
00007fa22efd3424  pop rcx
00007fa22efd3425  pop rax
00007fa22efd3426  add rsp, 0x08
00007fa22efd342a  jmp 0x00007FA22EFCFED1
00007fa22efd342f  sub rsp, 0x08
00007fa22efd3433  push rax
00007fa22efd3434  push rcx
00007fa22efd3435  push rdx
00007fa22efd3436  push rdi
00007fa22efd3437  push rsi
00007fa22efd3438  push r8
00007fa22efd343a  push r9
00007fa22efd343c  push r10
00007fa22efd343e  push r11
00007fa22efd3440  sub rsp, 0xF0
00007fa22efd3447  vmovaps [rsp], xmm0
00007fa22efd344c  vmovaps [rsp+0x10], xmm1
00007fa22efd3452  vmovaps [rsp+0x20], xmm2
00007fa22efd3458  vmovaps [rsp+0x30], xmm3
00007fa22efd345e  vmovaps [rsp+0x40], xmm4
00007fa22efd3464  vmovaps [rsp+0x50], xmm5
00007fa22efd346a  vmovaps [rsp+0x60], xmm6
00007fa22efd3470  vmovaps [rsp+0x70], xmm7
00007fa22efd3476  vmovaps [rsp+0x80], xmm8
00007fa22efd347f  vmovaps [rsp+0x90], xmm9
00007fa22efd3488  vmovaps [rsp+0xA0], xmm10
00007fa22efd3491  vmovaps [rsp+0xB0], xmm11
00007fa22efd349a  vmovaps [rsp+0xC0], xmm12
00007fa22efd34a3  vmovaps [rsp+0xD0], xmm13
00007fa22efd34ac  vmovaps [rsp+0xE0], xmm15
00007fa22efd34b5  sub rsp, 0x30
00007fa22efd34b9  movaps [rsp], xmm14
00007fa22efd34be  movaps [rsp+0x10], xmm12
00007fa22efd34c4  movaps [rsp+0x20], xmm5
00007fa22efd34c9  lea rdi, [rsp]
00007fa22efd34cd  mov esi, 0x00
00007fa22efd34d2  mov rax, 0x5E9D1A57D530
00007fa22efd34dc  call rax
00007fa22efd34de  movaps xmm14, [rsp]
00007fa22efd34e3  add rsp, 0x30
00007fa22efd34e7  vmovaps xmm0, [rsp]
00007fa22efd34ec  vmovaps xmm1, [rsp+0x10]
00007fa22efd34f2  vmovaps xmm2, [rsp+0x20]
00007fa22efd34f8  vmovaps xmm3, [rsp+0x30]
00007fa22efd34fe  vmovaps xmm4, [rsp+0x40]
00007fa22efd3504  vmovaps xmm5, [rsp+0x50]
00007fa22efd350a  vmovaps xmm6, [rsp+0x60]
00007fa22efd3510  vmovaps xmm7, [rsp+0x70]
00007fa22efd3516  vmovaps xmm8, [rsp+0x80]
00007fa22efd351f  vmovaps xmm9, [rsp+0x90]
00007fa22efd3528  vmovaps xmm10, [rsp+0xA0]
00007fa22efd3531  vmovaps xmm11, [rsp+0xB0]
00007fa22efd353a  vmovaps xmm12, [rsp+0xC0]
00007fa22efd3543  vmovaps xmm13, [rsp+0xD0]
00007fa22efd354c  vmovaps xmm15, [rsp+0xE0]
00007fa22efd3555  add rsp, 0xF0
00007fa22efd355c  pop r11
00007fa22efd355e  pop r10
00007fa22efd3560  pop r9
00007fa22efd3562  pop r8
00007fa22efd3564  pop rsi
00007fa22efd3565  pop rdi
00007fa22efd3566  pop rdx
00007fa22efd3567  pop rcx
00007fa22efd3568  pop rax
00007fa22efd3569  add rsp, 0x08
00007fa22efd356d  jmp 0x00007FA22EFCFEF1
00007fa22efd3572  sub rsp, 0x08
00007fa22efd3576  push rax
00007fa22efd3577  push rcx
00007fa22efd3578  push rdx
00007fa22efd3579  push rdi
00007fa22efd357a  push rsi
00007fa22efd357b  push r8
00007fa22efd357d  push r9
00007fa22efd357f  push r10
00007fa22efd3581  push r11
00007fa22efd3583  sub rsp, 0xF0
00007fa22efd358a  vmovaps [rsp], xmm0
00007fa22efd358f  vmovaps [rsp+0x10], xmm1
00007fa22efd3595  vmovaps [rsp+0x20], xmm2
00007fa22efd359b  vmovaps [rsp+0x30], xmm3
00007fa22efd35a1  vmovaps [rsp+0x40], xmm4
00007fa22efd35a7  vmovaps [rsp+0x50], xmm5
00007fa22efd35ad  vmovaps [rsp+0x60], xmm7
00007fa22efd35b3  vmovaps [rsp+0x70], xmm8
00007fa22efd35b9  vmovaps [rsp+0x80], xmm9
00007fa22efd35c2  vmovaps [rsp+0x90], xmm10
00007fa22efd35cb  vmovaps [rsp+0xA0], xmm11
00007fa22efd35d4  vmovaps [rsp+0xB0], xmm12
00007fa22efd35dd  vmovaps [rsp+0xC0], xmm13
00007fa22efd35e6  vmovaps [rsp+0xD0], xmm14
00007fa22efd35ef  vmovaps [rsp+0xE0], xmm15
00007fa22efd35f8  sub rsp, 0x30
00007fa22efd35fc  movaps [rsp], xmm6
00007fa22efd3600  movaps [rsp+0x10], xmm9
00007fa22efd3606  movaps [rsp+0x20], xmm12
00007fa22efd360c  lea rdi, [rsp]
00007fa22efd3610  mov esi, 0x00
00007fa22efd3615  mov rax, 0x5E9D1A57D530
00007fa22efd361f  call rax
00007fa22efd3621  movaps xmm6, [rsp]
00007fa22efd3625  add rsp, 0x30
00007fa22efd3629  vmovaps xmm0, [rsp]
00007fa22efd362e  vmovaps xmm1, [rsp+0x10]
00007fa22efd3634  vmovaps xmm2, [rsp+0x20]
00007fa22efd363a  vmovaps xmm3, [rsp+0x30]
00007fa22efd3640  vmovaps xmm4, [rsp+0x40]
00007fa22efd3646  vmovaps xmm5, [rsp+0x50]
00007fa22efd364c  vmovaps xmm7, [rsp+0x60]
00007fa22efd3652  vmovaps xmm8, [rsp+0x70]
00007fa22efd3658  vmovaps xmm9, [rsp+0x80]
00007fa22efd3661  vmovaps xmm10, [rsp+0x90]
00007fa22efd366a  vmovaps xmm11, [rsp+0xA0]
00007fa22efd3673  vmovaps xmm12, [rsp+0xB0]
00007fa22efd367c  vmovaps xmm13, [rsp+0xC0]
00007fa22efd3685  vmovaps xmm14, [rsp+0xD0]
00007fa22efd368e  vmovaps xmm15, [rsp+0xE0]
00007fa22efd3697  add rsp, 0xF0
00007fa22efd369e  pop r11
00007fa22efd36a0  pop r10
00007fa22efd36a2  pop r9
00007fa22efd36a4  pop r8
00007fa22efd36a6  pop rsi
00007fa22efd36a7  pop rdi
00007fa22efd36a8  pop rdx
00007fa22efd36a9  pop rcx
00007fa22efd36aa  pop rax
00007fa22efd36ab  add rsp, 0x08
00007fa22efd36af  jmp 0x00007FA22EFCFF19
00007fa22efd36b4  sub rsp, 0x08
00007fa22efd36b8  push rax
00007fa22efd36b9  push rcx
00007fa22efd36ba  push rdx
00007fa22efd36bb  push rdi
00007fa22efd36bc  push rsi
00007fa22efd36bd  push r8
00007fa22efd36bf  push r9
00007fa22efd36c1  push r10
00007fa22efd36c3  push r11
00007fa22efd36c5  sub rsp, 0xF0
00007fa22efd36cc  vmovaps [rsp], xmm0
00007fa22efd36d1  vmovaps [rsp+0x10], xmm1
00007fa22efd36d7  vmovaps [rsp+0x20], xmm2
00007fa22efd36dd  vmovaps [rsp+0x30], xmm3
00007fa22efd36e3  vmovaps [rsp+0x40], xmm4
00007fa22efd36e9  vmovaps [rsp+0x50], xmm5
00007fa22efd36ef  vmovaps [rsp+0x60], xmm6
00007fa22efd36f5  vmovaps [rsp+0x70], xmm7
00007fa22efd36fb  vmovaps [rsp+0x80], xmm8
00007fa22efd3704  vmovaps [rsp+0x90], xmm9
00007fa22efd370d  vmovaps [rsp+0xA0], xmm10
00007fa22efd3716  vmovaps [rsp+0xB0], xmm11
00007fa22efd371f  vmovaps [rsp+0xC0], xmm13
00007fa22efd3728  vmovaps [rsp+0xD0], xmm14
00007fa22efd3731  vmovaps [rsp+0xE0], xmm15
00007fa22efd373a  sub rsp, 0x30
00007fa22efd373e  movaps [rsp], xmm12
00007fa22efd3743  movaps [rsp+0x10], xmm15
00007fa22efd3749  movaps [rsp+0x20], xmm13
00007fa22efd374f  lea rdi, [rsp]
00007fa22efd3753  mov esi, 0x00
00007fa22efd3758  mov rax, 0x5E9D1A57D530
00007fa22efd3762  call rax
00007fa22efd3764  movaps xmm12, [rsp]
00007fa22efd3769  add rsp, 0x30
00007fa22efd376d  vmovaps xmm0, [rsp]
00007fa22efd3772  vmovaps xmm1, [rsp+0x10]
00007fa22efd3778  vmovaps xmm2, [rsp+0x20]
00007fa22efd377e  vmovaps xmm3, [rsp+0x30]
00007fa22efd3784  vmovaps xmm4, [rsp+0x40]
00007fa22efd378a  vmovaps xmm5, [rsp+0x50]
00007fa22efd3790  vmovaps xmm6, [rsp+0x60]
00007fa22efd3796  vmovaps xmm7, [rsp+0x70]
00007fa22efd379c  vmovaps xmm8, [rsp+0x80]
00007fa22efd37a5  vmovaps xmm9, [rsp+0x90]
00007fa22efd37ae  vmovaps xmm10, [rsp+0xA0]
00007fa22efd37b7  vmovaps xmm11, [rsp+0xB0]
00007fa22efd37c0  vmovaps xmm13, [rsp+0xC0]
00007fa22efd37c9  vmovaps xmm14, [rsp+0xD0]
00007fa22efd37d2  vmovaps xmm15, [rsp+0xE0]
00007fa22efd37db  add rsp, 0xF0
00007fa22efd37e2  pop r11
00007fa22efd37e4  pop r10
00007fa22efd37e6  pop r9
00007fa22efd37e8  pop r8
00007fa22efd37ea  pop rsi
00007fa22efd37eb  pop rdi
00007fa22efd37ec  pop rdx
00007fa22efd37ed  pop rcx
00007fa22efd37ee  pop rax
00007fa22efd37ef  add rsp, 0x08
00007fa22efd37f3  jmp 0x00007FA22EFCFF34
00007fa22efd37f8  sub rsp, 0x08
00007fa22efd37fc  push rax
00007fa22efd37fd  push rcx
00007fa22efd37fe  push rdx
00007fa22efd37ff  push rdi
00007fa22efd3800  push rsi
00007fa22efd3801  push r8
00007fa22efd3803  push r9
00007fa22efd3805  push r10
00007fa22efd3807  push r11
00007fa22efd3809  sub rsp, 0xF0
00007fa22efd3810  vmovaps [rsp], xmm0
00007fa22efd3815  vmovaps [rsp+0x10], xmm1
00007fa22efd381b  vmovaps [rsp+0x20], xmm2
00007fa22efd3821  vmovaps [rsp+0x30], xmm3
00007fa22efd3827  vmovaps [rsp+0x40], xmm4
00007fa22efd382d  vmovaps [rsp+0x50], xmm5
00007fa22efd3833  vmovaps [rsp+0x60], xmm6
00007fa22efd3839  vmovaps [rsp+0x70], xmm7
00007fa22efd383f  vmovaps [rsp+0x80], xmm8
00007fa22efd3848  vmovaps [rsp+0x90], xmm9
00007fa22efd3851  vmovaps [rsp+0xA0], xmm10
00007fa22efd385a  vmovaps [rsp+0xB0], xmm11
00007fa22efd3863  vmovaps [rsp+0xC0], xmm12
00007fa22efd386c  vmovaps [rsp+0xD0], xmm13
00007fa22efd3875  vmovaps [rsp+0xE0], xmm14
00007fa22efd387e  sub rsp, 0x30
00007fa22efd3882  movaps [rsp], xmm15
00007fa22efd3887  movaps [rsp+0x10], xmm13
00007fa22efd388d  movaps [rsp+0x20], xmm10
00007fa22efd3893  lea rdi, [rsp]
00007fa22efd3897  mov esi, 0x00
00007fa22efd389c  mov rax, 0x5E9D1A57D530
00007fa22efd38a6  call rax
00007fa22efd38a8  movaps xmm15, [rsp]
00007fa22efd38ad  add rsp, 0x30
00007fa22efd38b1  vmovaps xmm0, [rsp]
00007fa22efd38b6  vmovaps xmm1, [rsp+0x10]
00007fa22efd38bc  vmovaps xmm2, [rsp+0x20]
00007fa22efd38c2  vmovaps xmm3, [rsp+0x30]
00007fa22efd38c8  vmovaps xmm4, [rsp+0x40]
00007fa22efd38ce  vmovaps xmm5, [rsp+0x50]
00007fa22efd38d4  vmovaps xmm6, [rsp+0x60]
00007fa22efd38da  vmovaps xmm7, [rsp+0x70]
00007fa22efd38e0  vmovaps xmm8, [rsp+0x80]
00007fa22efd38e9  vmovaps xmm9, [rsp+0x90]
00007fa22efd38f2  vmovaps xmm10, [rsp+0xA0]
00007fa22efd38fb  vmovaps xmm11, [rsp+0xB0]
00007fa22efd3904  vmovaps xmm12, [rsp+0xC0]
00007fa22efd390d  vmovaps xmm13, [rsp+0xD0]
00007fa22efd3916  vmovaps xmm14, [rsp+0xE0]
00007fa22efd391f  add rsp, 0xF0
00007fa22efd3926  pop r11
00007fa22efd3928  pop r10
00007fa22efd392a  pop r9
00007fa22efd392c  pop r8
00007fa22efd392e  pop rsi
00007fa22efd392f  pop rdi
00007fa22efd3930  pop rdx
00007fa22efd3931  pop rcx
00007fa22efd3932  pop rax
00007fa22efd3933  add rsp, 0x08
00007fa22efd3937  jmp 0x00007FA22EFCFF55
00007fa22efd393c  call 0x00007FA22EE0C260
00007fa22efd3941  jmp 0x00007FA22EFCFFB0
00007fa22efd3946  sub rsp, 0x08
00007fa22efd394a  push rax
00007fa22efd394b  push rcx
00007fa22efd394c  push rdx
00007fa22efd394d  push rdi
00007fa22efd394e  push rsi
00007fa22efd394f  push r8
00007fa22efd3951  push r9
00007fa22efd3953  push r10
00007fa22efd3955  push r11
00007fa22efd3957  sub rsp, 0xF0
00007fa22efd395e  vmovaps [rsp], xmm0
00007fa22efd3963  vmovaps [rsp+0x10], xmm1
00007fa22efd3969  vmovaps [rsp+0x20], xmm2
00007fa22efd396f  vmovaps [rsp+0x30], xmm3
00007fa22efd3975  vmovaps [rsp+0x40], xmm4
00007fa22efd397b  vmovaps [rsp+0x50], xmm5
00007fa22efd3981  vmovaps [rsp+0x60], xmm6
00007fa22efd3987  vmovaps [rsp+0x70], xmm7
00007fa22efd398d  vmovaps [rsp+0x80], xmm8
00007fa22efd3996  vmovaps [rsp+0x90], xmm10
00007fa22efd399f  vmovaps [rsp+0xA0], xmm11
00007fa22efd39a8  vmovaps [rsp+0xB0], xmm12
00007fa22efd39b1  vmovaps [rsp+0xC0], xmm13
00007fa22efd39ba  vmovaps [rsp+0xD0], xmm14
00007fa22efd39c3  vmovaps [rsp+0xE0], xmm15
00007fa22efd39cc  sub rsp, 0x30
00007fa22efd39d0  movaps [rsp], xmm9
00007fa22efd39d5  movaps [rsp+0x10], xmm8
00007fa22efd39db  movaps [rsp+0x20], xmm10
00007fa22efd39e1  lea rdi, [rsp]
00007fa22efd39e5  mov esi, 0x00
00007fa22efd39ea  mov rax, 0x5E9D1A57D530
00007fa22efd39f4  call rax
00007fa22efd39f6  movaps xmm9, [rsp]
00007fa22efd39fb  add rsp, 0x30
00007fa22efd39ff  vmovaps xmm0, [rsp]
00007fa22efd3a04  vmovaps xmm1, [rsp+0x10]
00007fa22efd3a0a  vmovaps xmm2, [rsp+0x20]
00007fa22efd3a10  vmovaps xmm3, [rsp+0x30]
00007fa22efd3a16  vmovaps xmm4, [rsp+0x40]
00007fa22efd3a1c  vmovaps xmm5, [rsp+0x50]
00007fa22efd3a22  vmovaps xmm6, [rsp+0x60]
00007fa22efd3a28  vmovaps xmm7, [rsp+0x70]
00007fa22efd3a2e  vmovaps xmm8, [rsp+0x80]
00007fa22efd3a37  vmovaps xmm10, [rsp+0x90]
00007fa22efd3a40  vmovaps xmm11, [rsp+0xA0]
00007fa22efd3a49  vmovaps xmm12, [rsp+0xB0]
00007fa22efd3a52  vmovaps xmm13, [rsp+0xC0]
00007fa22efd3a5b  vmovaps xmm14, [rsp+0xD0]
00007fa22efd3a64  vmovaps xmm15, [rsp+0xE0]
00007fa22efd3a6d  add rsp, 0xF0
00007fa22efd3a74  pop r11
00007fa22efd3a76  pop r10
00007fa22efd3a78  pop r9
00007fa22efd3a7a  pop r8
00007fa22efd3a7c  pop rsi
00007fa22efd3a7d  pop rdi
00007fa22efd3a7e  pop rdx
00007fa22efd3a7f  pop rcx
00007fa22efd3a80  pop rax
00007fa22efd3a81  add rsp, 0x08
00007fa22efd3a85  jmp 0x00007FA22EFCFFE1
00007fa22efd3a8a  sub rsp, 0x08
00007fa22efd3a8e  push rax
00007fa22efd3a8f  push rcx
00007fa22efd3a90  push rdx
00007fa22efd3a91  push rdi
00007fa22efd3a92  push rsi
00007fa22efd3a93  push r8
00007fa22efd3a95  push r9
00007fa22efd3a97  push r10
00007fa22efd3a99  push r11
00007fa22efd3a9b  sub rsp, 0xF0
00007fa22efd3aa2  vmovaps [rsp], xmm0
00007fa22efd3aa7  vmovaps [rsp+0x10], xmm1
00007fa22efd3aad  vmovaps [rsp+0x20], xmm2
00007fa22efd3ab3  vmovaps [rsp+0x30], xmm3
00007fa22efd3ab9  vmovaps [rsp+0x40], xmm4
00007fa22efd3abf  vmovaps [rsp+0x50], xmm5
00007fa22efd3ac5  vmovaps [rsp+0x60], xmm6
00007fa22efd3acb  vmovaps [rsp+0x70], xmm7
00007fa22efd3ad1  vmovaps [rsp+0x80], xmm8
00007fa22efd3ada  vmovaps [rsp+0x90], xmm9
00007fa22efd3ae3  vmovaps [rsp+0xA0], xmm11
00007fa22efd3aec  vmovaps [rsp+0xB0], xmm12
00007fa22efd3af5  vmovaps [rsp+0xC0], xmm13
00007fa22efd3afe  vmovaps [rsp+0xD0], xmm14
00007fa22efd3b07  vmovaps [rsp+0xE0], xmm15
00007fa22efd3b10  sub rsp, 0x30
00007fa22efd3b14  movaps [rsp], xmm10
00007fa22efd3b19  movaps [rsp+0x10], xmm1
00007fa22efd3b1e  movaps [rsp+0x20], xmm11
00007fa22efd3b24  lea rdi, [rsp]
00007fa22efd3b28  mov esi, 0x00
00007fa22efd3b2d  mov rax, 0x5E9D1A57D530
00007fa22efd3b37  call rax
00007fa22efd3b39  movaps xmm10, [rsp]
00007fa22efd3b3e  add rsp, 0x30
00007fa22efd3b42  vmovaps xmm0, [rsp]
00007fa22efd3b47  vmovaps xmm1, [rsp+0x10]
00007fa22efd3b4d  vmovaps xmm2, [rsp+0x20]
00007fa22efd3b53  vmovaps xmm3, [rsp+0x30]
00007fa22efd3b59  vmovaps xmm4, [rsp+0x40]
00007fa22efd3b5f  vmovaps xmm5, [rsp+0x50]
00007fa22efd3b65  vmovaps xmm6, [rsp+0x60]
00007fa22efd3b6b  vmovaps xmm7, [rsp+0x70]
00007fa22efd3b71  vmovaps xmm8, [rsp+0x80]
00007fa22efd3b7a  vmovaps xmm9, [rsp+0x90]
00007fa22efd3b83  vmovaps xmm11, [rsp+0xA0]
00007fa22efd3b8c  vmovaps xmm12, [rsp+0xB0]
00007fa22efd3b95  vmovaps xmm13, [rsp+0xC0]
00007fa22efd3b9e  vmovaps xmm14, [rsp+0xD0]
00007fa22efd3ba7  vmovaps xmm15, [rsp+0xE0]
00007fa22efd3bb0  add rsp, 0xF0
00007fa22efd3bb7  pop r11
00007fa22efd3bb9  pop r10
00007fa22efd3bbb  pop r9
00007fa22efd3bbd  pop r8
00007fa22efd3bbf  pop rsi
00007fa22efd3bc0  pop rdi
00007fa22efd3bc1  pop rdx
00007fa22efd3bc2  pop rcx
00007fa22efd3bc3  pop rax
00007fa22efd3bc4  add rsp, 0x08
00007fa22efd3bc8  jmp 0x00007FA22EFCFFFC
00007fa22efd3bcd  sub rsp, 0x08
00007fa22efd3bd1  push rax
00007fa22efd3bd2  push rcx
00007fa22efd3bd3  push rdx
00007fa22efd3bd4  push rdi
00007fa22efd3bd5  push rsi
00007fa22efd3bd6  push r8
00007fa22efd3bd8  push r9
00007fa22efd3bda  push r10
00007fa22efd3bdc  push r11
00007fa22efd3bde  sub rsp, 0xF0
00007fa22efd3be5  vmovaps [rsp], xmm0
00007fa22efd3bea  vmovaps [rsp+0x10], xmm2
00007fa22efd3bf0  vmovaps [rsp+0x20], xmm3
00007fa22efd3bf6  vmovaps [rsp+0x30], xmm4
00007fa22efd3bfc  vmovaps [rsp+0x40], xmm5
00007fa22efd3c02  vmovaps [rsp+0x50], xmm6
00007fa22efd3c08  vmovaps [rsp+0x60], xmm7
00007fa22efd3c0e  vmovaps [rsp+0x70], xmm8
00007fa22efd3c14  vmovaps [rsp+0x80], xmm9
00007fa22efd3c1d  vmovaps [rsp+0x90], xmm10
00007fa22efd3c26  vmovaps [rsp+0xA0], xmm11
00007fa22efd3c2f  vmovaps [rsp+0xB0], xmm12
00007fa22efd3c38  vmovaps [rsp+0xC0], xmm13
00007fa22efd3c41  vmovaps [rsp+0xD0], xmm14
00007fa22efd3c4a  vmovaps [rsp+0xE0], xmm15
00007fa22efd3c53  sub rsp, 0x30
00007fa22efd3c57  movaps [rsp], xmm1
00007fa22efd3c5b  movaps [rsp+0x10], xmm14
00007fa22efd3c61  movaps [rsp+0x20], xmm6
00007fa22efd3c66  lea rdi, [rsp]
00007fa22efd3c6a  mov esi, 0x00
00007fa22efd3c6f  mov rax, 0x5E9D1A57D530
00007fa22efd3c79  call rax
00007fa22efd3c7b  movaps xmm1, [rsp]
00007fa22efd3c7f  add rsp, 0x30
00007fa22efd3c83  vmovaps xmm0, [rsp]
00007fa22efd3c88  vmovaps xmm2, [rsp+0x10]
00007fa22efd3c8e  vmovaps xmm3, [rsp+0x20]
00007fa22efd3c94  vmovaps xmm4, [rsp+0x30]
00007fa22efd3c9a  vmovaps xmm5, [rsp+0x40]
00007fa22efd3ca0  vmovaps xmm6, [rsp+0x50]
00007fa22efd3ca6  vmovaps xmm7, [rsp+0x60]
00007fa22efd3cac  vmovaps xmm8, [rsp+0x70]
00007fa22efd3cb2  vmovaps xmm9, [rsp+0x80]
00007fa22efd3cbb  vmovaps xmm10, [rsp+0x90]
00007fa22efd3cc4  vmovaps xmm11, [rsp+0xA0]
00007fa22efd3ccd  vmovaps xmm12, [rsp+0xB0]
00007fa22efd3cd6  vmovaps xmm13, [rsp+0xC0]
00007fa22efd3cdf  vmovaps xmm14, [rsp+0xD0]
00007fa22efd3ce8  vmovaps xmm15, [rsp+0xE0]
00007fa22efd3cf1  add rsp, 0xF0
00007fa22efd3cf8  pop r11
00007fa22efd3cfa  pop r10
00007fa22efd3cfc  pop r9
00007fa22efd3cfe  pop r8
00007fa22efd3d00  pop rsi
00007fa22efd3d01  pop rdi
00007fa22efd3d02  pop rdx
00007fa22efd3d03  pop rcx
00007fa22efd3d04  pop rax
00007fa22efd3d05  add rsp, 0x08
00007fa22efd3d09  jmp 0x00007FA22EFD0015
00007fa22efd3d0e  sub rsp, 0x08
00007fa22efd3d12  push rax
00007fa22efd3d13  push rcx
00007fa22efd3d14  push rdx
00007fa22efd3d15  push rdi
00007fa22efd3d16  push rsi
00007fa22efd3d17  push r8
00007fa22efd3d19  push r9
00007fa22efd3d1b  push r10
00007fa22efd3d1d  push r11
00007fa22efd3d1f  sub rsp, 0xF0
00007fa22efd3d26  vmovaps [rsp], xmm0
00007fa22efd3d2b  vmovaps [rsp+0x10], xmm1
00007fa22efd3d31  vmovaps [rsp+0x20], xmm2
00007fa22efd3d37  vmovaps [rsp+0x30], xmm3
00007fa22efd3d3d  vmovaps [rsp+0x40], xmm4
00007fa22efd3d43  vmovaps [rsp+0x50], xmm5
00007fa22efd3d49  vmovaps [rsp+0x60], xmm6
00007fa22efd3d4f  vmovaps [rsp+0x70], xmm7
00007fa22efd3d55  vmovaps [rsp+0x80], xmm8
00007fa22efd3d5e  vmovaps [rsp+0x90], xmm9
00007fa22efd3d67  vmovaps [rsp+0xA0], xmm10
00007fa22efd3d70  vmovaps [rsp+0xB0], xmm12
00007fa22efd3d79  vmovaps [rsp+0xC0], xmm13
00007fa22efd3d82  vmovaps [rsp+0xD0], xmm14
00007fa22efd3d8b  vmovaps [rsp+0xE0], xmm15
00007fa22efd3d94  sub rsp, 0x30
00007fa22efd3d98  movaps [rsp], xmm11
00007fa22efd3d9d  movaps [rsp+0x10], xmm13
00007fa22efd3da3  movaps [rsp+0x20], xmm14
00007fa22efd3da9  lea rdi, [rsp]
00007fa22efd3dad  mov esi, 0x00
00007fa22efd3db2  mov rax, 0x5E9D1A57D530
00007fa22efd3dbc  call rax
00007fa22efd3dbe  movaps xmm11, [rsp]
00007fa22efd3dc3  add rsp, 0x30
00007fa22efd3dc7  vmovaps xmm0, [rsp]
00007fa22efd3dcc  vmovaps xmm1, [rsp+0x10]
00007fa22efd3dd2  vmovaps xmm2, [rsp+0x20]
00007fa22efd3dd8  vmovaps xmm3, [rsp+0x30]
00007fa22efd3dde  vmovaps xmm4, [rsp+0x40]
00007fa22efd3de4  vmovaps xmm5, [rsp+0x50]
00007fa22efd3dea  vmovaps xmm6, [rsp+0x60]
00007fa22efd3df0  vmovaps xmm7, [rsp+0x70]
00007fa22efd3df6  vmovaps xmm8, [rsp+0x80]
00007fa22efd3dff  vmovaps xmm9, [rsp+0x90]
00007fa22efd3e08  vmovaps xmm10, [rsp+0xA0]
00007fa22efd3e11  vmovaps xmm12, [rsp+0xB0]
00007fa22efd3e1a  vmovaps xmm13, [rsp+0xC0]
00007fa22efd3e23  vmovaps xmm14, [rsp+0xD0]
00007fa22efd3e2c  vmovaps xmm15, [rsp+0xE0]
00007fa22efd3e35  add rsp, 0xF0
00007fa22efd3e3c  pop r11
00007fa22efd3e3e  pop r10
00007fa22efd3e40  pop r9
00007fa22efd3e42  pop r8
00007fa22efd3e44  pop rsi
00007fa22efd3e45  pop rdi
00007fa22efd3e46  pop rdx
00007fa22efd3e47  pop rcx
00007fa22efd3e48  pop rax
00007fa22efd3e49  add rsp, 0x08
00007fa22efd3e4d  jmp 0x00007FA22EFD003F
00007fa22efd3e52  sub rsp, 0x08
00007fa22efd3e56  push rax
00007fa22efd3e57  push rcx
00007fa22efd3e58  push rdx
00007fa22efd3e59  push rdi
00007fa22efd3e5a  push rsi
00007fa22efd3e5b  push r8
00007fa22efd3e5d  push r9
00007fa22efd3e5f  push r10
00007fa22efd3e61  push r11
00007fa22efd3e63  sub rsp, 0xF0
00007fa22efd3e6a  vmovaps [rsp], xmm0
00007fa22efd3e6f  vmovaps [rsp+0x10], xmm1
00007fa22efd3e75  vmovaps [rsp+0x20], xmm2
00007fa22efd3e7b  vmovaps [rsp+0x30], xmm3
00007fa22efd3e81  vmovaps [rsp+0x40], xmm4
00007fa22efd3e87  vmovaps [rsp+0x50], xmm5
00007fa22efd3e8d  vmovaps [rsp+0x60], xmm6
00007fa22efd3e93  vmovaps [rsp+0x70], xmm7
00007fa22efd3e99  vmovaps [rsp+0x80], xmm8
00007fa22efd3ea2  vmovaps [rsp+0x90], xmm9
00007fa22efd3eab  vmovaps [rsp+0xA0], xmm10
00007fa22efd3eb4  vmovaps [rsp+0xB0], xmm11
00007fa22efd3ebd  vmovaps [rsp+0xC0], xmm12
00007fa22efd3ec6  vmovaps [rsp+0xD0], xmm14
00007fa22efd3ecf  vmovaps [rsp+0xE0], xmm15
00007fa22efd3ed8  sub rsp, 0x30
00007fa22efd3edc  movaps [rsp], xmm13
00007fa22efd3ee1  movaps [rsp+0x10], xmm8
00007fa22efd3ee7  movaps [rsp+0x20], xmm14
00007fa22efd3eed  lea rdi, [rsp]
00007fa22efd3ef1  mov esi, 0x00
00007fa22efd3ef6  mov rax, 0x5E9D1A57D530
00007fa22efd3f00  call rax
00007fa22efd3f02  movaps xmm13, [rsp]
00007fa22efd3f07  add rsp, 0x30
00007fa22efd3f0b  vmovaps xmm0, [rsp]
00007fa22efd3f10  vmovaps xmm1, [rsp+0x10]
00007fa22efd3f16  vmovaps xmm2, [rsp+0x20]
00007fa22efd3f1c  vmovaps xmm3, [rsp+0x30]
00007fa22efd3f22  vmovaps xmm4, [rsp+0x40]
00007fa22efd3f28  vmovaps xmm5, [rsp+0x50]
00007fa22efd3f2e  vmovaps xmm6, [rsp+0x60]
00007fa22efd3f34  vmovaps xmm7, [rsp+0x70]
00007fa22efd3f3a  vmovaps xmm8, [rsp+0x80]
00007fa22efd3f43  vmovaps xmm9, [rsp+0x90]
00007fa22efd3f4c  vmovaps xmm10, [rsp+0xA0]
00007fa22efd3f55  vmovaps xmm11, [rsp+0xB0]
00007fa22efd3f5e  vmovaps xmm12, [rsp+0xC0]
00007fa22efd3f67  vmovaps xmm14, [rsp+0xD0]
00007fa22efd3f70  vmovaps xmm15, [rsp+0xE0]
00007fa22efd3f79  add rsp, 0xF0
00007fa22efd3f80  pop r11
00007fa22efd3f82  pop r10
00007fa22efd3f84  pop r9
00007fa22efd3f86  pop r8
00007fa22efd3f88  pop rsi
00007fa22efd3f89  pop rdi
00007fa22efd3f8a  pop rdx
00007fa22efd3f8b  pop rcx
00007fa22efd3f8c  pop rax
00007fa22efd3f8d  add rsp, 0x08
00007fa22efd3f91  jmp 0x00007FA22EFD006E
00007fa22efd3f96  sub rsp, 0x08
00007fa22efd3f9a  push rax
00007fa22efd3f9b  push rcx
00007fa22efd3f9c  push rdx
00007fa22efd3f9d  push rdi
00007fa22efd3f9e  push rsi
00007fa22efd3f9f  push r8
00007fa22efd3fa1  push r9
00007fa22efd3fa3  push r10
00007fa22efd3fa5  push r11
00007fa22efd3fa7  sub rsp, 0xF0
00007fa22efd3fae  vmovaps [rsp], xmm0
00007fa22efd3fb3  vmovaps [rsp+0x10], xmm1
00007fa22efd3fb9  vmovaps [rsp+0x20], xmm2
00007fa22efd3fbf  vmovaps [rsp+0x30], xmm3
00007fa22efd3fc5  vmovaps [rsp+0x40], xmm4
00007fa22efd3fcb  vmovaps [rsp+0x50], xmm5
00007fa22efd3fd1  vmovaps [rsp+0x60], xmm6
00007fa22efd3fd7  vmovaps [rsp+0x70], xmm7
00007fa22efd3fdd  vmovaps [rsp+0x80], xmm9
00007fa22efd3fe6  vmovaps [rsp+0x90], xmm10
00007fa22efd3fef  vmovaps [rsp+0xA0], xmm11
00007fa22efd3ff8  vmovaps [rsp+0xB0], xmm12
00007fa22efd4001  vmovaps [rsp+0xC0], xmm13
00007fa22efd400a  vmovaps [rsp+0xD0], xmm14
00007fa22efd4013  vmovaps [rsp+0xE0], xmm15
00007fa22efd401c  sub rsp, 0x30
00007fa22efd4020  movaps [rsp], xmm8
00007fa22efd4025  movaps [rsp+0x10], xmm7
00007fa22efd402a  movaps [rsp+0x20], xmm14
00007fa22efd4030  lea rdi, [rsp]
00007fa22efd4034  mov esi, 0x00
00007fa22efd4039  mov rax, 0x5E9D1A57D530
00007fa22efd4043  call rax
00007fa22efd4045  movaps xmm8, [rsp]
00007fa22efd404a  add rsp, 0x30
00007fa22efd404e  vmovaps xmm0, [rsp]
00007fa22efd4053  vmovaps xmm1, [rsp+0x10]
00007fa22efd4059  vmovaps xmm2, [rsp+0x20]
00007fa22efd405f  vmovaps xmm3, [rsp+0x30]
00007fa22efd4065  vmovaps xmm4, [rsp+0x40]
00007fa22efd406b  vmovaps xmm5, [rsp+0x50]
00007fa22efd4071  vmovaps xmm6, [rsp+0x60]
00007fa22efd4077  vmovaps xmm7, [rsp+0x70]
00007fa22efd407d  vmovaps xmm9, [rsp+0x80]
00007fa22efd4086  vmovaps xmm10, [rsp+0x90]
00007fa22efd408f  vmovaps xmm11, [rsp+0xA0]
00007fa22efd4098  vmovaps xmm12, [rsp+0xB0]
00007fa22efd40a1  vmovaps xmm13, [rsp+0xC0]
00007fa22efd40aa  vmovaps xmm14, [rsp+0xD0]
00007fa22efd40b3  vmovaps xmm15, [rsp+0xE0]
00007fa22efd40bc  add rsp, 0xF0
00007fa22efd40c3  pop r11
00007fa22efd40c5  pop r10
00007fa22efd40c7  pop r9
00007fa22efd40c9  pop r8
00007fa22efd40cb  pop rsi
00007fa22efd40cc  pop rdi
00007fa22efd40cd  pop rdx
00007fa22efd40ce  pop rcx
00007fa22efd40cf  pop rax
00007fa22efd40d0  add rsp, 0x08
00007fa22efd40d4  jmp 0x00007FA22EFD0094
00007fa22efd40d9  sub rsp, 0x08
00007fa22efd40dd  push rax
00007fa22efd40de  push rcx
00007fa22efd40df  push rdx
00007fa22efd40e0  push rdi
00007fa22efd40e1  push rsi
00007fa22efd40e2  push r8
00007fa22efd40e4  push r9
00007fa22efd40e6  push r10
00007fa22efd40e8  push r11
00007fa22efd40ea  sub rsp, 0xF0
00007fa22efd40f1  vmovaps [rsp], xmm0
00007fa22efd40f6  vmovaps [rsp+0x10], xmm1
00007fa22efd40fc  vmovaps [rsp+0x20], xmm2
00007fa22efd4102  vmovaps [rsp+0x30], xmm3
00007fa22efd4108  vmovaps [rsp+0x40], xmm4
00007fa22efd410e  vmovaps [rsp+0x50], xmm5
00007fa22efd4114  vmovaps [rsp+0x60], xmm6
00007fa22efd411a  vmovaps [rsp+0x70], xmm7
00007fa22efd4120  vmovaps [rsp+0x80], xmm8
00007fa22efd4129  vmovaps [rsp+0x90], xmm9
00007fa22efd4132  vmovaps [rsp+0xA0], xmm10
00007fa22efd413b  vmovaps [rsp+0xB0], xmm11
00007fa22efd4144  vmovaps [rsp+0xC0], xmm12
00007fa22efd414d  vmovaps [rsp+0xD0], xmm13
00007fa22efd4156  vmovaps [rsp+0xE0], xmm15
00007fa22efd415f  sub rsp, 0x30
00007fa22efd4163  movaps [rsp], xmm14
00007fa22efd4168  movaps [rsp+0x10], xmm12
00007fa22efd416e  movaps [rsp+0x20], xmm9
00007fa22efd4174  lea rdi, [rsp]
00007fa22efd4178  mov esi, 0x00
00007fa22efd417d  mov rax, 0x5E9D1A57D530
00007fa22efd4187  call rax
00007fa22efd4189  movaps xmm14, [rsp]
00007fa22efd418e  add rsp, 0x30
00007fa22efd4192  vmovaps xmm0, [rsp]
00007fa22efd4197  vmovaps xmm1, [rsp+0x10]
00007fa22efd419d  vmovaps xmm2, [rsp+0x20]
00007fa22efd41a3  vmovaps xmm3, [rsp+0x30]
00007fa22efd41a9  vmovaps xmm4, [rsp+0x40]
00007fa22efd41af  vmovaps xmm5, [rsp+0x50]
00007fa22efd41b5  vmovaps xmm6, [rsp+0x60]
00007fa22efd41bb  vmovaps xmm7, [rsp+0x70]
00007fa22efd41c1  vmovaps xmm8, [rsp+0x80]
00007fa22efd41ca  vmovaps xmm9, [rsp+0x90]
00007fa22efd41d3  vmovaps xmm10, [rsp+0xA0]
00007fa22efd41dc  vmovaps xmm11, [rsp+0xB0]
00007fa22efd41e5  vmovaps xmm12, [rsp+0xC0]
00007fa22efd41ee  vmovaps xmm13, [rsp+0xD0]
00007fa22efd41f7  vmovaps xmm15, [rsp+0xE0]
00007fa22efd4200  add rsp, 0xF0
00007fa22efd4207  pop r11
00007fa22efd4209  pop r10
00007fa22efd420b  pop r9
00007fa22efd420d  pop r8
00007fa22efd420f  pop rsi
00007fa22efd4210  pop rdi
00007fa22efd4211  pop rdx
00007fa22efd4212  pop rcx
00007fa22efd4213  pop rax
00007fa22efd4214  add rsp, 0x08
00007fa22efd4218  jmp 0x00007FA22EFD00AE
00007fa22efd421d  sub rsp, 0x08
00007fa22efd4221  push rax
00007fa22efd4222  push rcx
00007fa22efd4223  push rdx
00007fa22efd4224  push rdi
00007fa22efd4225  push rsi
00007fa22efd4226  push r8
00007fa22efd4228  push r9
00007fa22efd422a  push r10
00007fa22efd422c  push r11
00007fa22efd422e  sub rsp, 0xF0
00007fa22efd4235  vmovaps [rsp], xmm0
00007fa22efd423a  vmovaps [rsp+0x10], xmm1
00007fa22efd4240  vmovaps [rsp+0x20], xmm2
00007fa22efd4246  vmovaps [rsp+0x30], xmm3
00007fa22efd424c  vmovaps [rsp+0x40], xmm4
00007fa22efd4252  vmovaps [rsp+0x50], xmm5
00007fa22efd4258  vmovaps [rsp+0x60], xmm6
00007fa22efd425e  vmovaps [rsp+0x70], xmm7
00007fa22efd4264  vmovaps [rsp+0x80], xmm8
00007fa22efd426d  vmovaps [rsp+0x90], xmm10
00007fa22efd4276  vmovaps [rsp+0xA0], xmm11
00007fa22efd427f  vmovaps [rsp+0xB0], xmm12
00007fa22efd4288  vmovaps [rsp+0xC0], xmm13
00007fa22efd4291  vmovaps [rsp+0xD0], xmm14
00007fa22efd429a  vmovaps [rsp+0xE0], xmm15
00007fa22efd42a3  sub rsp, 0x30
00007fa22efd42a7  movaps [rsp], xmm9
00007fa22efd42ac  movaps [rsp+0x10], xmm7
00007fa22efd42b1  movaps [rsp+0x20], xmm12
00007fa22efd42b7  lea rdi, [rsp]
00007fa22efd42bb  mov esi, 0x00
00007fa22efd42c0  mov rax, 0x5E9D1A57D530
00007fa22efd42ca  call rax
00007fa22efd42cc  movaps xmm9, [rsp]
00007fa22efd42d1  add rsp, 0x30
00007fa22efd42d5  vmovaps xmm0, [rsp]
00007fa22efd42da  vmovaps xmm1, [rsp+0x10]
00007fa22efd42e0  vmovaps xmm2, [rsp+0x20]
00007fa22efd42e6  vmovaps xmm3, [rsp+0x30]
00007fa22efd42ec  vmovaps xmm4, [rsp+0x40]
00007fa22efd42f2  vmovaps xmm5, [rsp+0x50]
00007fa22efd42f8  vmovaps xmm6, [rsp+0x60]
00007fa22efd42fe  vmovaps xmm7, [rsp+0x70]
00007fa22efd4304  vmovaps xmm8, [rsp+0x80]
00007fa22efd430d  vmovaps xmm10, [rsp+0x90]
00007fa22efd4316  vmovaps xmm11, [rsp+0xA0]
00007fa22efd431f  vmovaps xmm12, [rsp+0xB0]
00007fa22efd4328  vmovaps xmm13, [rsp+0xC0]
00007fa22efd4331  vmovaps xmm14, [rsp+0xD0]
00007fa22efd433a  vmovaps xmm15, [rsp+0xE0]
00007fa22efd4343  add rsp, 0xF0
00007fa22efd434a  pop r11
00007fa22efd434c  pop r10
00007fa22efd434e  pop r9
00007fa22efd4350  pop r8
00007fa22efd4352  pop rsi
00007fa22efd4353  pop rdi
00007fa22efd4354  pop rdx
00007fa22efd4355  pop rcx
00007fa22efd4356  pop rax
00007fa22efd4357  add rsp, 0x08
00007fa22efd435b  jmp 0x00007FA22EFD00DD
00007fa22efd4360  sub rsp, 0x08
00007fa22efd4364  push rax
00007fa22efd4365  push rcx
00007fa22efd4366  push rdx
00007fa22efd4367  push rdi
00007fa22efd4368  push rsi
00007fa22efd4369  push r8
00007fa22efd436b  push r9
00007fa22efd436d  push r10
00007fa22efd436f  push r11
00007fa22efd4371  sub rsp, 0xF0
00007fa22efd4378  vmovaps [rsp], xmm0
00007fa22efd437d  vmovaps [rsp+0x10], xmm1
00007fa22efd4383  vmovaps [rsp+0x20], xmm2
00007fa22efd4389  vmovaps [rsp+0x30], xmm3
00007fa22efd438f  vmovaps [rsp+0x40], xmm4
00007fa22efd4395  vmovaps [rsp+0x50], xmm5
00007fa22efd439b  vmovaps [rsp+0x60], xmm6
00007fa22efd43a1  vmovaps [rsp+0x70], xmm7
00007fa22efd43a7  vmovaps [rsp+0x80], xmm8
00007fa22efd43b0  vmovaps [rsp+0x90], xmm9
00007fa22efd43b9  vmovaps [rsp+0xA0], xmm10
00007fa22efd43c2  vmovaps [rsp+0xB0], xmm11
00007fa22efd43cb  vmovaps [rsp+0xC0], xmm13
00007fa22efd43d4  vmovaps [rsp+0xD0], xmm14
00007fa22efd43dd  vmovaps [rsp+0xE0], xmm15
00007fa22efd43e6  sub rsp, 0x30
00007fa22efd43ea  movaps [rsp], xmm12
00007fa22efd43ef  movaps [rsp+0x10], xmm15
00007fa22efd43f5  movaps [rsp+0x20], xmm11
00007fa22efd43fb  lea rdi, [rsp]
00007fa22efd43ff  mov esi, 0x00
00007fa22efd4404  mov rax, 0x5E9D1A57D530
00007fa22efd440e  call rax
00007fa22efd4410  movaps xmm12, [rsp]
00007fa22efd4415  add rsp, 0x30
00007fa22efd4419  vmovaps xmm0, [rsp]
00007fa22efd441e  vmovaps xmm1, [rsp+0x10]
00007fa22efd4424  vmovaps xmm2, [rsp+0x20]
00007fa22efd442a  vmovaps xmm3, [rsp+0x30]
00007fa22efd4430  vmovaps xmm4, [rsp+0x40]
00007fa22efd4436  vmovaps xmm5, [rsp+0x50]
00007fa22efd443c  vmovaps xmm6, [rsp+0x60]
00007fa22efd4442  vmovaps xmm7, [rsp+0x70]
00007fa22efd4448  vmovaps xmm8, [rsp+0x80]
00007fa22efd4451  vmovaps xmm9, [rsp+0x90]
00007fa22efd445a  vmovaps xmm10, [rsp+0xA0]
00007fa22efd4463  vmovaps xmm11, [rsp+0xB0]
00007fa22efd446c  vmovaps xmm13, [rsp+0xC0]
00007fa22efd4475  vmovaps xmm14, [rsp+0xD0]
00007fa22efd447e  vmovaps xmm15, [rsp+0xE0]
00007fa22efd4487  add rsp, 0xF0
00007fa22efd448e  pop r11
00007fa22efd4490  pop r10
00007fa22efd4492  pop r9
00007fa22efd4494  pop r8
00007fa22efd4496  pop rsi
00007fa22efd4497  pop rdi
00007fa22efd4498  pop rdx
00007fa22efd4499  pop rcx
00007fa22efd449a  pop rax
00007fa22efd449b  add rsp, 0x08
00007fa22efd449f  jmp 0x00007FA22EFD00F7
00007fa22efd44a4  sub rsp, 0x08
00007fa22efd44a8  push rax
00007fa22efd44a9  push rcx
00007fa22efd44aa  push rdx
00007fa22efd44ab  push rdi
00007fa22efd44ac  push rsi
00007fa22efd44ad  push r8
00007fa22efd44af  push r9
00007fa22efd44b1  push r10
00007fa22efd44b3  push r11
00007fa22efd44b5  sub rsp, 0xF0
00007fa22efd44bc  vmovaps [rsp], xmm0
00007fa22efd44c1  vmovaps [rsp+0x10], xmm1
00007fa22efd44c7  vmovaps [rsp+0x20], xmm2
00007fa22efd44cd  vmovaps [rsp+0x30], xmm3
00007fa22efd44d3  vmovaps [rsp+0x40], xmm4
00007fa22efd44d9  vmovaps [rsp+0x50], xmm5
00007fa22efd44df  vmovaps [rsp+0x60], xmm6
00007fa22efd44e5  vmovaps [rsp+0x70], xmm7
00007fa22efd44eb  vmovaps [rsp+0x80], xmm8
00007fa22efd44f4  vmovaps [rsp+0x90], xmm9
00007fa22efd44fd  vmovaps [rsp+0xA0], xmm10
00007fa22efd4506  vmovaps [rsp+0xB0], xmm12
00007fa22efd450f  vmovaps [rsp+0xC0], xmm13
00007fa22efd4518  vmovaps [rsp+0xD0], xmm14
00007fa22efd4521  vmovaps [rsp+0xE0], xmm15
00007fa22efd452a  sub rsp, 0x30
00007fa22efd452e  movaps [rsp], xmm11
00007fa22efd4533  movaps [rsp+0x10], xmm7
00007fa22efd4538  movaps [rsp+0x20], xmm15
00007fa22efd453e  lea rdi, [rsp]
00007fa22efd4542  mov esi, 0x00
00007fa22efd4547  mov rax, 0x5E9D1A57D530
00007fa22efd4551  call rax
00007fa22efd4553  movaps xmm11, [rsp]
00007fa22efd4558  add rsp, 0x30
00007fa22efd455c  vmovaps xmm0, [rsp]
00007fa22efd4561  vmovaps xmm1, [rsp+0x10]
00007fa22efd4567  vmovaps xmm2, [rsp+0x20]
00007fa22efd456d  vmovaps xmm3, [rsp+0x30]
00007fa22efd4573  vmovaps xmm4, [rsp+0x40]
00007fa22efd4579  vmovaps xmm5, [rsp+0x50]
00007fa22efd457f  vmovaps xmm6, [rsp+0x60]
00007fa22efd4585  vmovaps xmm7, [rsp+0x70]
00007fa22efd458b  vmovaps xmm8, [rsp+0x80]
00007fa22efd4594  vmovaps xmm9, [rsp+0x90]
00007fa22efd459d  vmovaps xmm10, [rsp+0xA0]
00007fa22efd45a6  vmovaps xmm12, [rsp+0xB0]
00007fa22efd45af  vmovaps xmm13, [rsp+0xC0]
00007fa22efd45b8  vmovaps xmm14, [rsp+0xD0]
00007fa22efd45c1  vmovaps xmm15, [rsp+0xE0]
00007fa22efd45ca  add rsp, 0xF0
00007fa22efd45d1  pop r11
00007fa22efd45d3  pop r10
00007fa22efd45d5  pop r9
00007fa22efd45d7  pop r8
00007fa22efd45d9  pop rsi
00007fa22efd45da  pop rdi
00007fa22efd45db  pop rdx
00007fa22efd45dc  pop rcx
00007fa22efd45dd  pop rax
00007fa22efd45de  add rsp, 0x08
00007fa22efd45e2  jmp 0x00007FA22EFD0123
00007fa22efd45e7  sub rsp, 0x08
00007fa22efd45eb  push rax
00007fa22efd45ec  push rcx
00007fa22efd45ed  push rdx
00007fa22efd45ee  push rdi
00007fa22efd45ef  push rsi
00007fa22efd45f0  push r8
00007fa22efd45f2  push r9
00007fa22efd45f4  push r10
00007fa22efd45f6  push r11
00007fa22efd45f8  sub rsp, 0xF0
00007fa22efd45ff  vmovaps [rsp], xmm0
00007fa22efd4604  vmovaps [rsp+0x10], xmm1
00007fa22efd460a  vmovaps [rsp+0x20], xmm2
00007fa22efd4610  vmovaps [rsp+0x30], xmm3
00007fa22efd4616  vmovaps [rsp+0x40], xmm4
00007fa22efd461c  vmovaps [rsp+0x50], xmm5
00007fa22efd4622  vmovaps [rsp+0x60], xmm6
00007fa22efd4628  vmovaps [rsp+0x70], xmm7
00007fa22efd462e  vmovaps [rsp+0x80], xmm8
00007fa22efd4637  vmovaps [rsp+0x90], xmm9
00007fa22efd4640  vmovaps [rsp+0xA0], xmm10
00007fa22efd4649  vmovaps [rsp+0xB0], xmm11
00007fa22efd4652  vmovaps [rsp+0xC0], xmm12
00007fa22efd465b  vmovaps [rsp+0xD0], xmm13
00007fa22efd4664  vmovaps [rsp+0xE0], xmm14
00007fa22efd466d  sub rsp, 0x30
00007fa22efd4671  movaps [rsp], xmm15
00007fa22efd4676  movaps [rsp+0x10], xmm10
00007fa22efd467c  movaps [rsp+0x20], xmm13
00007fa22efd4682  lea rdi, [rsp]
00007fa22efd4686  mov esi, 0x00
00007fa22efd468b  mov rax, 0x5E9D1A57D530
00007fa22efd4695  call rax
00007fa22efd4697  movaps xmm15, [rsp]
00007fa22efd469c  add rsp, 0x30
00007fa22efd46a0  vmovaps xmm0, [rsp]
00007fa22efd46a5  vmovaps xmm1, [rsp+0x10]
00007fa22efd46ab  vmovaps xmm2, [rsp+0x20]
00007fa22efd46b1  vmovaps xmm3, [rsp+0x30]
00007fa22efd46b7  vmovaps xmm4, [rsp+0x40]
00007fa22efd46bd  vmovaps xmm5, [rsp+0x50]
00007fa22efd46c3  vmovaps xmm6, [rsp+0x60]
00007fa22efd46c9  vmovaps xmm7, [rsp+0x70]
00007fa22efd46cf  vmovaps xmm8, [rsp+0x80]
00007fa22efd46d8  vmovaps xmm9, [rsp+0x90]
00007fa22efd46e1  vmovaps xmm10, [rsp+0xA0]
00007fa22efd46ea  vmovaps xmm11, [rsp+0xB0]
00007fa22efd46f3  vmovaps xmm12, [rsp+0xC0]
00007fa22efd46fc  vmovaps xmm13, [rsp+0xD0]
00007fa22efd4705  vmovaps xmm14, [rsp+0xE0]
00007fa22efd470e  add rsp, 0xF0
00007fa22efd4715  pop r11
00007fa22efd4717  pop r10
00007fa22efd4719  pop r9
00007fa22efd471b  pop r8
00007fa22efd471d  pop rsi
00007fa22efd471e  pop rdi
00007fa22efd471f  pop rdx
00007fa22efd4720  pop rcx
00007fa22efd4721  pop rax
00007fa22efd4722  add rsp, 0x08
00007fa22efd4726  jmp 0x00007FA22EFD013D
00007fa22efd472b  sub rsp, 0x08
00007fa22efd472f  push rax
00007fa22efd4730  push rcx
00007fa22efd4731  push rdx
00007fa22efd4732  push rdi
00007fa22efd4733  push rsi
00007fa22efd4734  push r8
00007fa22efd4736  push r9
00007fa22efd4738  push r10
00007fa22efd473a  push r11
00007fa22efd473c  sub rsp, 0xF0
00007fa22efd4743  vmovaps [rsp], xmm0
00007fa22efd4748  vmovaps [rsp+0x10], xmm1
00007fa22efd474e  vmovaps [rsp+0x20], xmm2
00007fa22efd4754  vmovaps [rsp+0x30], xmm3
00007fa22efd475a  vmovaps [rsp+0x40], xmm4
00007fa22efd4760  vmovaps [rsp+0x50], xmm5
00007fa22efd4766  vmovaps [rsp+0x60], xmm6
00007fa22efd476c  vmovaps [rsp+0x70], xmm7
00007fa22efd4772  vmovaps [rsp+0x80], xmm8
00007fa22efd477b  vmovaps [rsp+0x90], xmm9
00007fa22efd4784  vmovaps [rsp+0xA0], xmm11
00007fa22efd478d  vmovaps [rsp+0xB0], xmm12
00007fa22efd4796  vmovaps [rsp+0xC0], xmm13
00007fa22efd479f  vmovaps [rsp+0xD0], xmm14
00007fa22efd47a8  vmovaps [rsp+0xE0], xmm15
00007fa22efd47b1  sub rsp, 0x30
00007fa22efd47b5  movaps [rsp], xmm10
00007fa22efd47ba  movaps [rsp+0x10], xmm7
00007fa22efd47bf  movaps [rsp+0x20], xmm13
00007fa22efd47c5  lea rdi, [rsp]
00007fa22efd47c9  mov esi, 0x00
00007fa22efd47ce  mov rax, 0x5E9D1A57D530
00007fa22efd47d8  call rax
00007fa22efd47da  movaps xmm10, [rsp]
00007fa22efd47df  add rsp, 0x30
00007fa22efd47e3  vmovaps xmm0, [rsp]
00007fa22efd47e8  vmovaps xmm1, [rsp+0x10]
00007fa22efd47ee  vmovaps xmm2, [rsp+0x20]
00007fa22efd47f4  vmovaps xmm3, [rsp+0x30]
00007fa22efd47fa  vmovaps xmm4, [rsp+0x40]
00007fa22efd4800  vmovaps xmm5, [rsp+0x50]
00007fa22efd4806  vmovaps xmm6, [rsp+0x60]
00007fa22efd480c  vmovaps xmm7, [rsp+0x70]
00007fa22efd4812  vmovaps xmm8, [rsp+0x80]
00007fa22efd481b  vmovaps xmm9, [rsp+0x90]
00007fa22efd4824  vmovaps xmm11, [rsp+0xA0]
00007fa22efd482d  vmovaps xmm12, [rsp+0xB0]
00007fa22efd4836  vmovaps xmm13, [rsp+0xC0]
00007fa22efd483f  vmovaps xmm14, [rsp+0xD0]
00007fa22efd4848  vmovaps xmm15, [rsp+0xE0]
00007fa22efd4851  add rsp, 0xF0
00007fa22efd4858  pop r11
00007fa22efd485a  pop r10
00007fa22efd485c  pop r9
00007fa22efd485e  pop r8
00007fa22efd4860  pop rsi
00007fa22efd4861  pop rdi
00007fa22efd4862  pop rdx
00007fa22efd4863  pop rcx
00007fa22efd4864  pop rax
00007fa22efd4865  add rsp, 0x08
00007fa22efd4869  jmp 0x00007FA22EFD0169
00007fa22efd486e  sub rsp, 0x08
00007fa22efd4872  push rax
00007fa22efd4873  push rcx
00007fa22efd4874  push rdx
00007fa22efd4875  push rdi
00007fa22efd4876  push rsi
00007fa22efd4877  push r8
00007fa22efd4879  push r9
00007fa22efd487b  push r10
00007fa22efd487d  push r11
00007fa22efd487f  sub rsp, 0xF0
00007fa22efd4886  vmovaps [rsp], xmm0
00007fa22efd488b  vmovaps [rsp+0x10], xmm1
00007fa22efd4891  vmovaps [rsp+0x20], xmm2
00007fa22efd4897  vmovaps [rsp+0x30], xmm3
00007fa22efd489d  vmovaps [rsp+0x40], xmm4
00007fa22efd48a3  vmovaps [rsp+0x50], xmm5
00007fa22efd48a9  vmovaps [rsp+0x60], xmm6
00007fa22efd48af  vmovaps [rsp+0x70], xmm7
00007fa22efd48b5  vmovaps [rsp+0x80], xmm8
00007fa22efd48be  vmovaps [rsp+0x90], xmm9
00007fa22efd48c7  vmovaps [rsp+0xA0], xmm10
00007fa22efd48d0  vmovaps [rsp+0xB0], xmm11
00007fa22efd48d9  vmovaps [rsp+0xC0], xmm12
00007fa22efd48e2  vmovaps [rsp+0xD0], xmm14
00007fa22efd48eb  vmovaps [rsp+0xE0], xmm15
00007fa22efd48f4  sub rsp, 0x30
00007fa22efd48f8  movaps [rsp], xmm13
00007fa22efd48fd  movaps [rsp+0x10], xmm1
00007fa22efd4902  movaps [rsp+0x20], xmm8
00007fa22efd4908  lea rdi, [rsp]
00007fa22efd490c  mov esi, 0x00
00007fa22efd4911  mov rax, 0x5E9D1A57D530
00007fa22efd491b  call rax
00007fa22efd491d  movaps xmm13, [rsp]
00007fa22efd4922  add rsp, 0x30
00007fa22efd4926  vmovaps xmm0, [rsp]
00007fa22efd492b  vmovaps xmm1, [rsp+0x10]
00007fa22efd4931  vmovaps xmm2, [rsp+0x20]
00007fa22efd4937  vmovaps xmm3, [rsp+0x30]
00007fa22efd493d  vmovaps xmm4, [rsp+0x40]
00007fa22efd4943  vmovaps xmm5, [rsp+0x50]
00007fa22efd4949  vmovaps xmm6, [rsp+0x60]
00007fa22efd494f  vmovaps xmm7, [rsp+0x70]
00007fa22efd4955  vmovaps xmm8, [rsp+0x80]
00007fa22efd495e  vmovaps xmm9, [rsp+0x90]
00007fa22efd4967  vmovaps xmm10, [rsp+0xA0]
00007fa22efd4970  vmovaps xmm11, [rsp+0xB0]
00007fa22efd4979  vmovaps xmm12, [rsp+0xC0]
00007fa22efd4982  vmovaps xmm14, [rsp+0xD0]
00007fa22efd498b  vmovaps xmm15, [rsp+0xE0]
00007fa22efd4994  add rsp, 0xF0
00007fa22efd499b  pop r11
00007fa22efd499d  pop r10
00007fa22efd499f  pop r9
00007fa22efd49a1  pop r8
00007fa22efd49a3  pop rsi
00007fa22efd49a4  pop rdi
00007fa22efd49a5  pop rdx
00007fa22efd49a6  pop rcx
00007fa22efd49a7  pop rax
00007fa22efd49a8  add rsp, 0x08
00007fa22efd49ac  jmp 0x00007FA22EFD0183
00007fa22efd49b1  call 0x00007FA22EDFF430
00007fa22efd49b6  jmp 0x00007FA22EFD018D
00007fa22efd49bb  sub rsp, 0x08
00007fa22efd49bf  push rax
00007fa22efd49c0  push rcx
00007fa22efd49c1  push rdx
00007fa22efd49c2  push rdi
00007fa22efd49c3  push rsi
00007fa22efd49c4  push r8
00007fa22efd49c6  push r9
00007fa22efd49c8  push r10
00007fa22efd49ca  push r11
00007fa22efd49cc  sub rsp, 0xF0
00007fa22efd49d3  vmovaps [rsp], xmm0
00007fa22efd49d8  vmovaps [rsp+0x10], xmm1
00007fa22efd49de  vmovaps [rsp+0x20], xmm2
00007fa22efd49e4  vmovaps [rsp+0x30], xmm3
00007fa22efd49ea  vmovaps [rsp+0x40], xmm4
00007fa22efd49f0  vmovaps [rsp+0x50], xmm5
00007fa22efd49f6  vmovaps [rsp+0x60], xmm6
00007fa22efd49fc  vmovaps [rsp+0x70], xmm7
00007fa22efd4a02  vmovaps [rsp+0x80], xmm9
00007fa22efd4a0b  vmovaps [rsp+0x90], xmm10
00007fa22efd4a14  vmovaps [rsp+0xA0], xmm11
00007fa22efd4a1d  vmovaps [rsp+0xB0], xmm12
00007fa22efd4a26  vmovaps [rsp+0xC0], xmm13
00007fa22efd4a2f  vmovaps [rsp+0xD0], xmm14
00007fa22efd4a38  vmovaps [rsp+0xE0], xmm15
00007fa22efd4a41  sub rsp, 0x30
00007fa22efd4a45  movaps [rsp], xmm8
00007fa22efd4a4a  movaps [rsp+0x10], xmm14
00007fa22efd4a50  movaps [rsp+0x20], xmm9
00007fa22efd4a56  lea rdi, [rsp]
00007fa22efd4a5a  mov esi, 0x00
00007fa22efd4a5f  mov rax, 0x5E9D1A57D530
00007fa22efd4a69  call rax
00007fa22efd4a6b  movaps xmm8, [rsp]
00007fa22efd4a70  add rsp, 0x30
00007fa22efd4a74  vmovaps xmm0, [rsp]
00007fa22efd4a79  vmovaps xmm1, [rsp+0x10]
00007fa22efd4a7f  vmovaps xmm2, [rsp+0x20]
00007fa22efd4a85  vmovaps xmm3, [rsp+0x30]
00007fa22efd4a8b  vmovaps xmm4, [rsp+0x40]
00007fa22efd4a91  vmovaps xmm5, [rsp+0x50]
00007fa22efd4a97  vmovaps xmm6, [rsp+0x60]
00007fa22efd4a9d  vmovaps xmm7, [rsp+0x70]
00007fa22efd4aa3  vmovaps xmm9, [rsp+0x80]
00007fa22efd4aac  vmovaps xmm10, [rsp+0x90]
00007fa22efd4ab5  vmovaps xmm11, [rsp+0xA0]
00007fa22efd4abe  vmovaps xmm12, [rsp+0xB0]
00007fa22efd4ac7  vmovaps xmm13, [rsp+0xC0]
00007fa22efd4ad0  vmovaps xmm14, [rsp+0xD0]
00007fa22efd4ad9  vmovaps xmm15, [rsp+0xE0]
00007fa22efd4ae2  add rsp, 0xF0
00007fa22efd4ae9  pop r11
00007fa22efd4aeb  pop r10
00007fa22efd4aed  pop r9
00007fa22efd4aef  pop r8
00007fa22efd4af1  pop rsi
00007fa22efd4af2  pop rdi
00007fa22efd4af3  pop rdx
00007fa22efd4af4  pop rcx
00007fa22efd4af5  pop rax
00007fa22efd4af6  add rsp, 0x08
00007fa22efd4afa  jmp 0x00007FA22EFD01AF
00007fa22efd4aff  sub rsp, 0x08
00007fa22efd4b03  push rax
00007fa22efd4b04  push rcx
00007fa22efd4b05  push rdx
00007fa22efd4b06  push rdi
00007fa22efd4b07  push rsi
00007fa22efd4b08  push r8
00007fa22efd4b0a  push r9
00007fa22efd4b0c  push r10
00007fa22efd4b0e  push r11
00007fa22efd4b10  sub rsp, 0xF0
00007fa22efd4b17  vmovaps [rsp], xmm0
00007fa22efd4b1c  vmovaps [rsp+0x10], xmm1
00007fa22efd4b22  vmovaps [rsp+0x20], xmm2
00007fa22efd4b28  vmovaps [rsp+0x30], xmm3
00007fa22efd4b2e  vmovaps [rsp+0x40], xmm4
00007fa22efd4b34  vmovaps [rsp+0x50], xmm5
00007fa22efd4b3a  vmovaps [rsp+0x60], xmm6
00007fa22efd4b40  vmovaps [rsp+0x70], xmm7
00007fa22efd4b46  vmovaps [rsp+0x80], xmm8
00007fa22efd4b4f  vmovaps [rsp+0x90], xmm10
00007fa22efd4b58  vmovaps [rsp+0xA0], xmm11
00007fa22efd4b61  vmovaps [rsp+0xB0], xmm12
00007fa22efd4b6a  vmovaps [rsp+0xC0], xmm13
00007fa22efd4b73  vmovaps [rsp+0xD0], xmm14
00007fa22efd4b7c  vmovaps [rsp+0xE0], xmm15
00007fa22efd4b85  sub rsp, 0x30
00007fa22efd4b89  movaps [rsp], xmm9
00007fa22efd4b8e  movaps [rsp+0x10], xmm1
00007fa22efd4b93  movaps [rsp+0x20], xmm14
00007fa22efd4b99  lea rdi, [rsp]
00007fa22efd4b9d  mov esi, 0x00
00007fa22efd4ba2  mov rax, 0x5E9D1A57D530
00007fa22efd4bac  call rax
00007fa22efd4bae  movaps xmm9, [rsp]
00007fa22efd4bb3  add rsp, 0x30
00007fa22efd4bb7  vmovaps xmm0, [rsp]
00007fa22efd4bbc  vmovaps xmm1, [rsp+0x10]
00007fa22efd4bc2  vmovaps xmm2, [rsp+0x20]
00007fa22efd4bc8  vmovaps xmm3, [rsp+0x30]
00007fa22efd4bce  vmovaps xmm4, [rsp+0x40]
00007fa22efd4bd4  vmovaps xmm5, [rsp+0x50]
00007fa22efd4bda  vmovaps xmm6, [rsp+0x60]
00007fa22efd4be0  vmovaps xmm7, [rsp+0x70]
00007fa22efd4be6  vmovaps xmm8, [rsp+0x80]
00007fa22efd4bef  vmovaps xmm10, [rsp+0x90]
00007fa22efd4bf8  vmovaps xmm11, [rsp+0xA0]
00007fa22efd4c01  vmovaps xmm12, [rsp+0xB0]
00007fa22efd4c0a  vmovaps xmm13, [rsp+0xC0]
00007fa22efd4c13  vmovaps xmm14, [rsp+0xD0]
00007fa22efd4c1c  vmovaps xmm15, [rsp+0xE0]
00007fa22efd4c25  add rsp, 0xF0
00007fa22efd4c2c  pop r11
00007fa22efd4c2e  pop r10
00007fa22efd4c30  pop r9
00007fa22efd4c32  pop r8
00007fa22efd4c34  pop rsi
00007fa22efd4c35  pop rdi
00007fa22efd4c36  pop rdx
00007fa22efd4c37  pop rcx
00007fa22efd4c38  pop rax
00007fa22efd4c39  add rsp, 0x08
00007fa22efd4c3d  jmp 0x00007FA22EFD01DD
00007fa22efd4c42  sub rsp, 0x08
00007fa22efd4c46  push rax
00007fa22efd4c47  push rcx
00007fa22efd4c48  push rdx
00007fa22efd4c49  push rdi
00007fa22efd4c4a  push rsi
00007fa22efd4c4b  push r8
00007fa22efd4c4d  push r9
00007fa22efd4c4f  push r10
00007fa22efd4c51  push r11
00007fa22efd4c53  sub rsp, 0xF0
00007fa22efd4c5a  vmovaps [rsp], xmm0
00007fa22efd4c5f  vmovaps [rsp+0x10], xmm1
00007fa22efd4c65  vmovaps [rsp+0x20], xmm2
00007fa22efd4c6b  vmovaps [rsp+0x30], xmm3
00007fa22efd4c71  vmovaps [rsp+0x40], xmm4
00007fa22efd4c77  vmovaps [rsp+0x50], xmm5
00007fa22efd4c7d  vmovaps [rsp+0x60], xmm6
00007fa22efd4c83  vmovaps [rsp+0x70], xmm7
00007fa22efd4c89  vmovaps [rsp+0x80], xmm8
00007fa22efd4c92  vmovaps [rsp+0x90], xmm9
00007fa22efd4c9b  vmovaps [rsp+0xA0], xmm10
00007fa22efd4ca4  vmovaps [rsp+0xB0], xmm11
00007fa22efd4cad  vmovaps [rsp+0xC0], xmm12
00007fa22efd4cb6  vmovaps [rsp+0xD0], xmm13
00007fa22efd4cbf  vmovaps [rsp+0xE0], xmm15
00007fa22efd4cc8  sub rsp, 0x30
00007fa22efd4ccc  movaps [rsp], xmm14
00007fa22efd4cd1  movaps [rsp+0x10], xmm4
00007fa22efd4cd6  movaps [rsp+0x20], xmm1
00007fa22efd4cdb  lea rdi, [rsp]
00007fa22efd4cdf  mov esi, 0x00
00007fa22efd4ce4  mov rax, 0x5E9D1A57D530
00007fa22efd4cee  call rax
00007fa22efd4cf0  movaps xmm14, [rsp]
00007fa22efd4cf5  add rsp, 0x30
00007fa22efd4cf9  vmovaps xmm0, [rsp]
00007fa22efd4cfe  vmovaps xmm1, [rsp+0x10]
00007fa22efd4d04  vmovaps xmm2, [rsp+0x20]
00007fa22efd4d0a  vmovaps xmm3, [rsp+0x30]
00007fa22efd4d10  vmovaps xmm4, [rsp+0x40]
00007fa22efd4d16  vmovaps xmm5, [rsp+0x50]
00007fa22efd4d1c  vmovaps xmm6, [rsp+0x60]
00007fa22efd4d22  vmovaps xmm7, [rsp+0x70]
00007fa22efd4d28  vmovaps xmm8, [rsp+0x80]
00007fa22efd4d31  vmovaps xmm9, [rsp+0x90]
00007fa22efd4d3a  vmovaps xmm10, [rsp+0xA0]
00007fa22efd4d43  vmovaps xmm11, [rsp+0xB0]
00007fa22efd4d4c  vmovaps xmm12, [rsp+0xC0]
00007fa22efd4d55  vmovaps xmm13, [rsp+0xD0]
00007fa22efd4d5e  vmovaps xmm15, [rsp+0xE0]
00007fa22efd4d67  add rsp, 0xF0
00007fa22efd4d6e  pop r11
00007fa22efd4d70  pop r10
00007fa22efd4d72  pop r9
00007fa22efd4d74  pop r8
00007fa22efd4d76  pop rsi
00007fa22efd4d77  pop rdi
00007fa22efd4d78  pop rdx
00007fa22efd4d79  pop rcx
00007fa22efd4d7a  pop rax
00007fa22efd4d7b  add rsp, 0x08
00007fa22efd4d7f  jmp 0x00007FA22EFD0203
00007fa22efd4d84  sub rsp, 0x08
00007fa22efd4d88  push rax
00007fa22efd4d89  push rcx
00007fa22efd4d8a  push rdx
00007fa22efd4d8b  push rdi
00007fa22efd4d8c  push rsi
00007fa22efd4d8d  push r8
00007fa22efd4d8f  push r9
00007fa22efd4d91  push r10
00007fa22efd4d93  push r11
00007fa22efd4d95  sub rsp, 0xF0
00007fa22efd4d9c  vmovaps [rsp], xmm0
00007fa22efd4da1  vmovaps [rsp+0x10], xmm2
00007fa22efd4da7  vmovaps [rsp+0x20], xmm3
00007fa22efd4dad  vmovaps [rsp+0x30], xmm4
00007fa22efd4db3  vmovaps [rsp+0x40], xmm5
00007fa22efd4db9  vmovaps [rsp+0x50], xmm6
00007fa22efd4dbf  vmovaps [rsp+0x60], xmm7
00007fa22efd4dc5  vmovaps [rsp+0x70], xmm8
00007fa22efd4dcb  vmovaps [rsp+0x80], xmm9
00007fa22efd4dd4  vmovaps [rsp+0x90], xmm10
00007fa22efd4ddd  vmovaps [rsp+0xA0], xmm11
00007fa22efd4de6  vmovaps [rsp+0xB0], xmm12
00007fa22efd4def  vmovaps [rsp+0xC0], xmm13
00007fa22efd4df8  vmovaps [rsp+0xD0], xmm14
00007fa22efd4e01  vmovaps [rsp+0xE0], xmm15
00007fa22efd4e0a  sub rsp, 0x30
00007fa22efd4e0e  movaps [rsp], xmm1
00007fa22efd4e12  movaps [rsp+0x10], xmm12
00007fa22efd4e18  movaps [rsp+0x20], xmm11
00007fa22efd4e1e  lea rdi, [rsp]
00007fa22efd4e22  mov esi, 0x00
00007fa22efd4e27  mov rax, 0x5E9D1A57D530
00007fa22efd4e31  call rax
00007fa22efd4e33  movaps xmm1, [rsp]
00007fa22efd4e37  add rsp, 0x30
00007fa22efd4e3b  vmovaps xmm0, [rsp]
00007fa22efd4e40  vmovaps xmm2, [rsp+0x10]
00007fa22efd4e46  vmovaps xmm3, [rsp+0x20]
00007fa22efd4e4c  vmovaps xmm4, [rsp+0x30]
00007fa22efd4e52  vmovaps xmm5, [rsp+0x40]
00007fa22efd4e58  vmovaps xmm6, [rsp+0x50]
00007fa22efd4e5e  vmovaps xmm7, [rsp+0x60]
00007fa22efd4e64  vmovaps xmm8, [rsp+0x70]
00007fa22efd4e6a  vmovaps xmm9, [rsp+0x80]
00007fa22efd4e73  vmovaps xmm10, [rsp+0x90]
00007fa22efd4e7c  vmovaps xmm11, [rsp+0xA0]
00007fa22efd4e85  vmovaps xmm12, [rsp+0xB0]
00007fa22efd4e8e  vmovaps xmm13, [rsp+0xC0]
00007fa22efd4e97  vmovaps xmm14, [rsp+0xD0]
00007fa22efd4ea0  vmovaps xmm15, [rsp+0xE0]
00007fa22efd4ea9  add rsp, 0xF0
00007fa22efd4eb0  pop r11
00007fa22efd4eb2  pop r10
00007fa22efd4eb4  pop r9
00007fa22efd4eb6  pop r8
00007fa22efd4eb8  pop rsi
00007fa22efd4eb9  pop rdi
00007fa22efd4eba  pop rdx
00007fa22efd4ebb  pop rcx
00007fa22efd4ebc  pop rax
00007fa22efd4ebd  add rsp, 0x08
00007fa22efd4ec1  jmp 0x00007FA22EFD0224
00007fa22efd4ec6  call 0x00007FA22EEE20A0
00007fa22efd4ecb  jmp 0x00007FA22EFD0232
00007fa22efd4ed0  call 0x00007FA22EE09D70
00007fa22efd4ed5  jmp 0x00007FA22EFD023C
00007fa22efd4eda  sub rsp, 0x08
00007fa22efd4ede  push rax
00007fa22efd4edf  push rcx
00007fa22efd4ee0  push rdx
00007fa22efd4ee1  push rdi
00007fa22efd4ee2  push rsi
00007fa22efd4ee3  push r8
00007fa22efd4ee5  push r9
00007fa22efd4ee7  push r10
00007fa22efd4ee9  push r11
00007fa22efd4eeb  sub rsp, 0xF0
00007fa22efd4ef2  vmovaps [rsp], xmm0
00007fa22efd4ef7  vmovaps [rsp+0x10], xmm1
00007fa22efd4efd  vmovaps [rsp+0x20], xmm2
00007fa22efd4f03  vmovaps [rsp+0x30], xmm3
00007fa22efd4f09  vmovaps [rsp+0x40], xmm4
00007fa22efd4f0f  vmovaps [rsp+0x50], xmm5
00007fa22efd4f15  vmovaps [rsp+0x60], xmm6
00007fa22efd4f1b  vmovaps [rsp+0x70], xmm8
00007fa22efd4f21  vmovaps [rsp+0x80], xmm9
00007fa22efd4f2a  vmovaps [rsp+0x90], xmm10
00007fa22efd4f33  vmovaps [rsp+0xA0], xmm11
00007fa22efd4f3c  vmovaps [rsp+0xB0], xmm12
00007fa22efd4f45  vmovaps [rsp+0xC0], xmm13
00007fa22efd4f4e  vmovaps [rsp+0xD0], xmm14
00007fa22efd4f57  vmovaps [rsp+0xE0], xmm15
00007fa22efd4f60  sub rsp, 0x30
00007fa22efd4f64  movaps [rsp], xmm7
00007fa22efd4f68  movaps [rsp+0x10], xmm15
00007fa22efd4f6e  movaps [rsp+0x20], xmm10
00007fa22efd4f74  lea rdi, [rsp]
00007fa22efd4f78  mov esi, 0x00
00007fa22efd4f7d  mov rax, 0x5E9D1A57D530
00007fa22efd4f87  call rax
00007fa22efd4f89  movaps xmm7, [rsp]
00007fa22efd4f8d  add rsp, 0x30
00007fa22efd4f91  vmovaps xmm0, [rsp]
00007fa22efd4f96  vmovaps xmm1, [rsp+0x10]
00007fa22efd4f9c  vmovaps xmm2, [rsp+0x20]
00007fa22efd4fa2  vmovaps xmm3, [rsp+0x30]
00007fa22efd4fa8  vmovaps xmm4, [rsp+0x40]
00007fa22efd4fae  vmovaps xmm5, [rsp+0x50]
00007fa22efd4fb4  vmovaps xmm6, [rsp+0x60]
00007fa22efd4fba  vmovaps xmm8, [rsp+0x70]
00007fa22efd4fc0  vmovaps xmm9, [rsp+0x80]
00007fa22efd4fc9  vmovaps xmm10, [rsp+0x90]
00007fa22efd4fd2  vmovaps xmm11, [rsp+0xA0]
00007fa22efd4fdb  vmovaps xmm12, [rsp+0xB0]
00007fa22efd4fe4  vmovaps xmm13, [rsp+0xC0]
00007fa22efd4fed  vmovaps xmm14, [rsp+0xD0]
00007fa22efd4ff6  vmovaps xmm15, [rsp+0xE0]
00007fa22efd4fff  add rsp, 0xF0
00007fa22efd5006  pop r11
00007fa22efd5008  pop r10
00007fa22efd500a  pop r9
00007fa22efd500c  pop r8
00007fa22efd500e  pop rsi
00007fa22efd500f  pop rdi
00007fa22efd5010  pop rdx
00007fa22efd5011  pop rcx
00007fa22efd5012  pop rax
00007fa22efd5013  add rsp, 0x08
00007fa22efd5017  jmp 0x00007FA22EFD025D
00007fa22efd501c  sub rsp, 0x08
00007fa22efd5020  push rax
00007fa22efd5021  push rcx
00007fa22efd5022  push rdx
00007fa22efd5023  push rdi
00007fa22efd5024  push rsi
00007fa22efd5025  push r8
00007fa22efd5027  push r9
00007fa22efd5029  push r10
00007fa22efd502b  push r11
00007fa22efd502d  sub rsp, 0xF0
00007fa22efd5034  vmovaps [rsp], xmm0
00007fa22efd5039  vmovaps [rsp+0x10], xmm1
00007fa22efd503f  vmovaps [rsp+0x20], xmm2
00007fa22efd5045  vmovaps [rsp+0x30], xmm3
00007fa22efd504b  vmovaps [rsp+0x40], xmm4
00007fa22efd5051  vmovaps [rsp+0x50], xmm5
00007fa22efd5057  vmovaps [rsp+0x60], xmm6
00007fa22efd505d  vmovaps [rsp+0x70], xmm7
00007fa22efd5063  vmovaps [rsp+0x80], xmm8
00007fa22efd506c  vmovaps [rsp+0x90], xmm9
00007fa22efd5075  vmovaps [rsp+0xA0], xmm11
00007fa22efd507e  vmovaps [rsp+0xB0], xmm12
00007fa22efd5087  vmovaps [rsp+0xC0], xmm13
00007fa22efd5090  vmovaps [rsp+0xD0], xmm14
00007fa22efd5099  vmovaps [rsp+0xE0], xmm15
00007fa22efd50a2  sub rsp, 0x30
00007fa22efd50a6  movaps [rsp], xmm10
00007fa22efd50ab  movaps [rsp+0x10], xmm11
00007fa22efd50b1  movaps [rsp+0x20], xmm15
00007fa22efd50b7  lea rdi, [rsp]
00007fa22efd50bb  mov esi, 0x00
00007fa22efd50c0  mov rax, 0x5E9D1A57D530
00007fa22efd50ca  call rax
00007fa22efd50cc  movaps xmm10, [rsp]
00007fa22efd50d1  add rsp, 0x30
00007fa22efd50d5  vmovaps xmm0, [rsp]
00007fa22efd50da  vmovaps xmm1, [rsp+0x10]
00007fa22efd50e0  vmovaps xmm2, [rsp+0x20]
00007fa22efd50e6  vmovaps xmm3, [rsp+0x30]
00007fa22efd50ec  vmovaps xmm4, [rsp+0x40]
00007fa22efd50f2  vmovaps xmm5, [rsp+0x50]
00007fa22efd50f8  vmovaps xmm6, [rsp+0x60]
00007fa22efd50fe  vmovaps xmm7, [rsp+0x70]
00007fa22efd5104  vmovaps xmm8, [rsp+0x80]
00007fa22efd510d  vmovaps xmm9, [rsp+0x90]
00007fa22efd5116  vmovaps xmm11, [rsp+0xA0]
00007fa22efd511f  vmovaps xmm12, [rsp+0xB0]
00007fa22efd5128  vmovaps xmm13, [rsp+0xC0]
00007fa22efd5131  vmovaps xmm14, [rsp+0xD0]
00007fa22efd513a  vmovaps xmm15, [rsp+0xE0]
00007fa22efd5143  add rsp, 0xF0
00007fa22efd514a  pop r11
00007fa22efd514c  pop r10
00007fa22efd514e  pop r9
00007fa22efd5150  pop r8
00007fa22efd5152  pop rsi
00007fa22efd5153  pop rdi
00007fa22efd5154  pop rdx
00007fa22efd5155  pop rcx
00007fa22efd5156  pop rax
00007fa22efd5157  add rsp, 0x08
00007fa22efd515b  jmp 0x00007FA22EFD028B
00007fa22efd5160  sub rsp, 0x08
00007fa22efd5164  push rax
00007fa22efd5165  push rcx
00007fa22efd5166  push rdx
00007fa22efd5167  push rdi
00007fa22efd5168  push rsi
00007fa22efd5169  push r8
00007fa22efd516b  push r9
00007fa22efd516d  push r10
00007fa22efd516f  push r11
00007fa22efd5171  sub rsp, 0xF0
00007fa22efd5178  vmovaps [rsp], xmm0
00007fa22efd517d  vmovaps [rsp+0x10], xmm1
00007fa22efd5183  vmovaps [rsp+0x20], xmm2
00007fa22efd5189  vmovaps [rsp+0x30], xmm3
00007fa22efd518f  vmovaps [rsp+0x40], xmm4
00007fa22efd5195  vmovaps [rsp+0x50], xmm5
00007fa22efd519b  vmovaps [rsp+0x60], xmm6
00007fa22efd51a1  vmovaps [rsp+0x70], xmm7
00007fa22efd51a7  vmovaps [rsp+0x80], xmm8
00007fa22efd51b0  vmovaps [rsp+0x90], xmm9
00007fa22efd51b9  vmovaps [rsp+0xA0], xmm10
00007fa22efd51c2  vmovaps [rsp+0xB0], xmm12
00007fa22efd51cb  vmovaps [rsp+0xC0], xmm13
00007fa22efd51d4  vmovaps [rsp+0xD0], xmm14
00007fa22efd51dd  vmovaps [rsp+0xE0], xmm15
00007fa22efd51e6  sub rsp, 0x30
00007fa22efd51ea  movaps [rsp], xmm11
00007fa22efd51ef  movaps [rsp+0x10], xmm12
00007fa22efd51f5  movaps [rsp+0x20], xmm15
00007fa22efd51fb  lea rdi, [rsp]
00007fa22efd51ff  mov esi, 0x00
00007fa22efd5204  mov rax, 0x5E9D1A57D530
00007fa22efd520e  call rax
00007fa22efd5210  movaps xmm11, [rsp]
00007fa22efd5215  add rsp, 0x30
00007fa22efd5219  vmovaps xmm0, [rsp]
00007fa22efd521e  vmovaps xmm1, [rsp+0x10]
00007fa22efd5224  vmovaps xmm2, [rsp+0x20]
00007fa22efd522a  vmovaps xmm3, [rsp+0x30]
00007fa22efd5230  vmovaps xmm4, [rsp+0x40]
00007fa22efd5236  vmovaps xmm5, [rsp+0x50]
00007fa22efd523c  vmovaps xmm6, [rsp+0x60]
00007fa22efd5242  vmovaps xmm7, [rsp+0x70]
00007fa22efd5248  vmovaps xmm8, [rsp+0x80]
00007fa22efd5251  vmovaps xmm9, [rsp+0x90]
00007fa22efd525a  vmovaps xmm10, [rsp+0xA0]
00007fa22efd5263  vmovaps xmm12, [rsp+0xB0]
00007fa22efd526c  vmovaps xmm13, [rsp+0xC0]
00007fa22efd5275  vmovaps xmm14, [rsp+0xD0]
00007fa22efd527e  vmovaps xmm15, [rsp+0xE0]
00007fa22efd5287  add rsp, 0xF0
00007fa22efd528e  pop r11
00007fa22efd5290  pop r10
00007fa22efd5292  pop r9
00007fa22efd5294  pop r8
00007fa22efd5296  pop rsi
00007fa22efd5297  pop rdi
00007fa22efd5298  pop rdx
00007fa22efd5299  pop rcx
00007fa22efd529a  pop rax
00007fa22efd529b  add rsp, 0x08
00007fa22efd529f  jmp 0x00007FA22EFD02B9
00007fa22efd52a4  sub rsp, 0x08
00007fa22efd52a8  push rax
00007fa22efd52a9  push rcx
00007fa22efd52aa  push rdx
00007fa22efd52ab  push rdi
00007fa22efd52ac  push rsi
00007fa22efd52ad  push r8
00007fa22efd52af  push r9
00007fa22efd52b1  push r10
00007fa22efd52b3  push r11
00007fa22efd52b5  sub rsp, 0xF0
00007fa22efd52bc  vmovaps [rsp], xmm0
00007fa22efd52c1  vmovaps [rsp+0x10], xmm1
00007fa22efd52c7  vmovaps [rsp+0x20], xmm2
00007fa22efd52cd  vmovaps [rsp+0x30], xmm3
00007fa22efd52d3  vmovaps [rsp+0x40], xmm4
00007fa22efd52d9  vmovaps [rsp+0x50], xmm5
00007fa22efd52df  vmovaps [rsp+0x60], xmm6
00007fa22efd52e5  vmovaps [rsp+0x70], xmm7
00007fa22efd52eb  vmovaps [rsp+0x80], xmm8
00007fa22efd52f4  vmovaps [rsp+0x90], xmm9
00007fa22efd52fd  vmovaps [rsp+0xA0], xmm10
00007fa22efd5306  vmovaps [rsp+0xB0], xmm11
00007fa22efd530f  vmovaps [rsp+0xC0], xmm12
00007fa22efd5318  vmovaps [rsp+0xD0], xmm13
00007fa22efd5321  vmovaps [rsp+0xE0], xmm14
00007fa22efd532a  sub rsp, 0x30
00007fa22efd532e  movaps [rsp], xmm15
00007fa22efd5333  movaps [rsp+0x10], xmm13
00007fa22efd5339  movaps [rsp+0x20], xmm9
00007fa22efd533f  lea rdi, [rsp]
00007fa22efd5343  mov esi, 0x00
00007fa22efd5348  mov rax, 0x5E9D1A57D530
00007fa22efd5352  call rax
00007fa22efd5354  movaps xmm15, [rsp]
00007fa22efd5359  add rsp, 0x30
00007fa22efd535d  vmovaps xmm0, [rsp]
00007fa22efd5362  vmovaps xmm1, [rsp+0x10]
00007fa22efd5368  vmovaps xmm2, [rsp+0x20]
00007fa22efd536e  vmovaps xmm3, [rsp+0x30]
00007fa22efd5374  vmovaps xmm4, [rsp+0x40]
00007fa22efd537a  vmovaps xmm5, [rsp+0x50]
00007fa22efd5380  vmovaps xmm6, [rsp+0x60]
00007fa22efd5386  vmovaps xmm7, [rsp+0x70]
00007fa22efd538c  vmovaps xmm8, [rsp+0x80]
00007fa22efd5395  vmovaps xmm9, [rsp+0x90]
00007fa22efd539e  vmovaps xmm10, [rsp+0xA0]
00007fa22efd53a7  vmovaps xmm11, [rsp+0xB0]
00007fa22efd53b0  vmovaps xmm12, [rsp+0xC0]
00007fa22efd53b9  vmovaps xmm13, [rsp+0xD0]
00007fa22efd53c2  vmovaps xmm14, [rsp+0xE0]
00007fa22efd53cb  add rsp, 0xF0
00007fa22efd53d2  pop r11
00007fa22efd53d4  pop r10
00007fa22efd53d6  pop r9
00007fa22efd53d8  pop r8
00007fa22efd53da  pop rsi
00007fa22efd53db  pop rdi
00007fa22efd53dc  pop rdx
00007fa22efd53dd  pop rcx
00007fa22efd53de  pop rax
00007fa22efd53df  add rsp, 0x08
00007fa22efd53e3  jmp 0x00007FA22EFD02D4
00007fa22efd53e8  sub rsp, 0x08
00007fa22efd53ec  push rax
00007fa22efd53ed  push rcx
00007fa22efd53ee  push rdx
00007fa22efd53ef  push rdi
00007fa22efd53f0  push rsi
00007fa22efd53f1  push r8
00007fa22efd53f3  push r9
00007fa22efd53f5  push r10
00007fa22efd53f7  push r11
00007fa22efd53f9  sub rsp, 0xF0
00007fa22efd5400  vmovaps [rsp], xmm0
00007fa22efd5405  vmovaps [rsp+0x10], xmm1
00007fa22efd540b  vmovaps [rsp+0x20], xmm2
00007fa22efd5411  vmovaps [rsp+0x30], xmm3
00007fa22efd5417  vmovaps [rsp+0x40], xmm4
00007fa22efd541d  vmovaps [rsp+0x50], xmm5
00007fa22efd5423  vmovaps [rsp+0x60], xmm6
00007fa22efd5429  vmovaps [rsp+0x70], xmm7
00007fa22efd542f  vmovaps [rsp+0x80], xmm8
00007fa22efd5438  vmovaps [rsp+0x90], xmm9
00007fa22efd5441  vmovaps [rsp+0xA0], xmm10
00007fa22efd544a  vmovaps [rsp+0xB0], xmm11
00007fa22efd5453  vmovaps [rsp+0xC0], xmm12
00007fa22efd545c  vmovaps [rsp+0xD0], xmm14
00007fa22efd5465  vmovaps [rsp+0xE0], xmm15
00007fa22efd546e  sub rsp, 0x30
00007fa22efd5472  movaps [rsp], xmm13
00007fa22efd5477  movaps [rsp+0x10], xmm8
00007fa22efd547d  movaps [rsp+0x20], xmm14
00007fa22efd5483  lea rdi, [rsp]
00007fa22efd5487  mov esi, 0x00
00007fa22efd548c  mov rax, 0x5E9D1A57D530
00007fa22efd5496  call rax
00007fa22efd5498  movaps xmm13, [rsp]
00007fa22efd549d  add rsp, 0x30
00007fa22efd54a1  vmovaps xmm0, [rsp]
00007fa22efd54a6  vmovaps xmm1, [rsp+0x10]
00007fa22efd54ac  vmovaps xmm2, [rsp+0x20]
00007fa22efd54b2  vmovaps xmm3, [rsp+0x30]
00007fa22efd54b8  vmovaps xmm4, [rsp+0x40]
00007fa22efd54be  vmovaps xmm5, [rsp+0x50]
00007fa22efd54c4  vmovaps xmm6, [rsp+0x60]
00007fa22efd54ca  vmovaps xmm7, [rsp+0x70]
00007fa22efd54d0  vmovaps xmm8, [rsp+0x80]
00007fa22efd54d9  vmovaps xmm9, [rsp+0x90]
00007fa22efd54e2  vmovaps xmm10, [rsp+0xA0]
00007fa22efd54eb  vmovaps xmm11, [rsp+0xB0]
00007fa22efd54f4  vmovaps xmm12, [rsp+0xC0]
00007fa22efd54fd  vmovaps xmm14, [rsp+0xD0]
00007fa22efd5506  vmovaps xmm15, [rsp+0xE0]
00007fa22efd550f  add rsp, 0xF0
00007fa22efd5516  pop r11
00007fa22efd5518  pop r10
00007fa22efd551a  pop r9
00007fa22efd551c  pop r8
00007fa22efd551e  pop rsi
00007fa22efd551f  pop rdi
00007fa22efd5520  pop rdx
00007fa22efd5521  pop rcx
00007fa22efd5522  pop rax
00007fa22efd5523  add rsp, 0x08
00007fa22efd5527  jmp 0x00007FA22EFD02F7
00007fa22efd552c  sub rsp, 0x08
00007fa22efd5530  push rax
00007fa22efd5531  push rcx
00007fa22efd5532  push rdx
00007fa22efd5533  push rdi
00007fa22efd5534  push rsi
00007fa22efd5535  push r8
00007fa22efd5537  push r9
00007fa22efd5539  push r10
00007fa22efd553b  push r11
00007fa22efd553d  sub rsp, 0xF0
00007fa22efd5544  vmovaps [rsp], xmm0
00007fa22efd5549  vmovaps [rsp+0x10], xmm1
00007fa22efd554f  vmovaps [rsp+0x20], xmm2
00007fa22efd5555  vmovaps [rsp+0x30], xmm3
00007fa22efd555b  vmovaps [rsp+0x40], xmm4
00007fa22efd5561  vmovaps [rsp+0x50], xmm5
00007fa22efd5567  vmovaps [rsp+0x60], xmm6
00007fa22efd556d  vmovaps [rsp+0x70], xmm7
00007fa22efd5573  vmovaps [rsp+0x80], xmm8
00007fa22efd557c  vmovaps [rsp+0x90], xmm9
00007fa22efd5585  vmovaps [rsp+0xA0], xmm10
00007fa22efd558e  vmovaps [rsp+0xB0], xmm11
00007fa22efd5597  vmovaps [rsp+0xC0], xmm12
00007fa22efd55a0  vmovaps [rsp+0xD0], xmm13
00007fa22efd55a9  vmovaps [rsp+0xE0], xmm15
00007fa22efd55b2  sub rsp, 0x30
00007fa22efd55b6  movaps [rsp], xmm14
00007fa22efd55bb  movaps [rsp+0x10], xmm1
00007fa22efd55c0  movaps [rsp+0x20], xmm10
00007fa22efd55c6  lea rdi, [rsp]
00007fa22efd55ca  mov esi, 0x00
00007fa22efd55cf  mov rax, 0x5E9D1A57D530
00007fa22efd55d9  call rax
00007fa22efd55db  movaps xmm14, [rsp]
00007fa22efd55e0  add rsp, 0x30
00007fa22efd55e4  vmovaps xmm0, [rsp]
00007fa22efd55e9  vmovaps xmm1, [rsp+0x10]
00007fa22efd55ef  vmovaps xmm2, [rsp+0x20]
00007fa22efd55f5  vmovaps xmm3, [rsp+0x30]
00007fa22efd55fb  vmovaps xmm4, [rsp+0x40]
00007fa22efd5601  vmovaps xmm5, [rsp+0x50]
00007fa22efd5607  vmovaps xmm6, [rsp+0x60]
00007fa22efd560d  vmovaps xmm7, [rsp+0x70]
00007fa22efd5613  vmovaps xmm8, [rsp+0x80]
00007fa22efd561c  vmovaps xmm9, [rsp+0x90]
00007fa22efd5625  vmovaps xmm10, [rsp+0xA0]
00007fa22efd562e  vmovaps xmm11, [rsp+0xB0]
00007fa22efd5637  vmovaps xmm12, [rsp+0xC0]
00007fa22efd5640  vmovaps xmm13, [rsp+0xD0]
00007fa22efd5649  vmovaps xmm15, [rsp+0xE0]
00007fa22efd5652  add rsp, 0xF0
00007fa22efd5659  pop r11
00007fa22efd565b  pop r10
00007fa22efd565d  pop r9
00007fa22efd565f  pop r8
00007fa22efd5661  pop rsi
00007fa22efd5662  pop rdi
00007fa22efd5663  pop rdx
00007fa22efd5664  pop rcx
00007fa22efd5665  pop rax
00007fa22efd5666  add rsp, 0x08
00007fa22efd566a  jmp 0x00007FA22EFD031A
00007fa22efd566f  sub rsp, 0x08
00007fa22efd5673  push rax
00007fa22efd5674  push rcx
00007fa22efd5675  push rdx
00007fa22efd5676  push rdi
00007fa22efd5677  push rsi
00007fa22efd5678  push r8
00007fa22efd567a  push r9
00007fa22efd567c  push r10
00007fa22efd567e  push r11
00007fa22efd5680  sub rsp, 0xF0
00007fa22efd5687  vmovaps [rsp], xmm0
00007fa22efd568c  vmovaps [rsp+0x10], xmm2
00007fa22efd5692  vmovaps [rsp+0x20], xmm3
00007fa22efd5698  vmovaps [rsp+0x30], xmm4
00007fa22efd569e  vmovaps [rsp+0x40], xmm5
00007fa22efd56a4  vmovaps [rsp+0x50], xmm6
00007fa22efd56aa  vmovaps [rsp+0x60], xmm7
00007fa22efd56b0  vmovaps [rsp+0x70], xmm8
00007fa22efd56b6  vmovaps [rsp+0x80], xmm9
00007fa22efd56bf  vmovaps [rsp+0x90], xmm10
00007fa22efd56c8  vmovaps [rsp+0xA0], xmm11
00007fa22efd56d1  vmovaps [rsp+0xB0], xmm12
00007fa22efd56da  vmovaps [rsp+0xC0], xmm13
00007fa22efd56e3  vmovaps [rsp+0xD0], xmm14
00007fa22efd56ec  vmovaps [rsp+0xE0], xmm15
00007fa22efd56f5  sub rsp, 0x30
00007fa22efd56f9  movaps [rsp], xmm1
00007fa22efd56fd  movaps [rsp+0x10], xmm7
00007fa22efd5702  movaps [rsp+0x20], xmm11
00007fa22efd5708  lea rdi, [rsp]
00007fa22efd570c  mov esi, 0x00
00007fa22efd5711  mov rax, 0x5E9D1A57D530
00007fa22efd571b  call rax
00007fa22efd571d  movaps xmm1, [rsp]
00007fa22efd5721  add rsp, 0x30
00007fa22efd5725  vmovaps xmm0, [rsp]
00007fa22efd572a  vmovaps xmm2, [rsp+0x10]
00007fa22efd5730  vmovaps xmm3, [rsp+0x20]
00007fa22efd5736  vmovaps xmm4, [rsp+0x30]
00007fa22efd573c  vmovaps xmm5, [rsp+0x40]
00007fa22efd5742  vmovaps xmm6, [rsp+0x50]
00007fa22efd5748  vmovaps xmm7, [rsp+0x60]
00007fa22efd574e  vmovaps xmm8, [rsp+0x70]
00007fa22efd5754  vmovaps xmm9, [rsp+0x80]
00007fa22efd575d  vmovaps xmm10, [rsp+0x90]
00007fa22efd5766  vmovaps xmm11, [rsp+0xA0]
00007fa22efd576f  vmovaps xmm12, [rsp+0xB0]
00007fa22efd5778  vmovaps xmm13, [rsp+0xC0]
00007fa22efd5781  vmovaps xmm14, [rsp+0xD0]
00007fa22efd578a  vmovaps xmm15, [rsp+0xE0]
00007fa22efd5793  add rsp, 0xF0
00007fa22efd579a  pop r11
00007fa22efd579c  pop r10
00007fa22efd579e  pop r9
00007fa22efd57a0  pop r8
00007fa22efd57a2  pop rsi
00007fa22efd57a3  pop rdi
00007fa22efd57a4  pop rdx
00007fa22efd57a5  pop rcx
00007fa22efd57a6  pop rax
00007fa22efd57a7  add rsp, 0x08
00007fa22efd57ab  jmp 0x00007FA22EFD033B
00007fa22efd57b0  call 0x00007FA22EE0E880
00007fa22efd57b5  jmp 0x00007FA22EFD034E
00007fa22efd57ba  call 0x00007FA22EE0C380
00007fa22efd57bf  jmp 0x00007FA22EFD0359
00007fa22efd57c4  call 0x00007FA22EE0D600
00007fa22efd57c9  jmp 0x00007FA22EFD0364
00007fa22efd57ce  call 0x00007FA22EDFF540
00007fa22efd57d3  jmp 0x00007FA22EFD036F
00007fa22efd57d8  int3
00007fa22efd57d9  nop [rax], eax
00007fa22efd57e0  mov rax, [r15+0x40]
00007fa22efd57e4  mov r14, [r15+0x58]
00007fa22efd57e8  lea r12, [rax+r14*1]
00007fa22efd57ec  movaps xmm1, [r15+0x1D0]
00007fa22efd57f4  vmovaps [rsp+0x10], xmm1
00007fa22efd57fa  vmovaps xmm15, [rsp+0x10]
00007fa22efd5800  por xmm1, xmm15
00007fa22efd5805  movaps xmm14, [r15+0x1A0]
00007fa22efd580d  vmovaps [rsp+0x10], xmm14
00007fa22efd5813  vmovaps xmm13, [rsp+0x10]
00007fa22efd5819  por xmm14, xmm13
00007fa22efd581e  lea rax, [r12+0x30]
00007fa22efd5823  mov r11, [r13+rax*1]
00007fa22efd5828  lea rax, [r12+0x38]
00007fa22efd582d  mov r10, [r13+rax*1]
00007fa22efd5832  movq xmm13, r11
00007fa22efd5837  movq xmm12, r10
00007fa22efd583c  movq xmm13, xmm13
00007fa22efd5841  vmovaps [rsp+0x10], xmm13
00007fa22efd5847  movq xmm13, xmm13
00007fa22efd584c  movaps [r15+0x130], xmm13
00007fa22efd5854  movq xmm12, xmm12
00007fa22efd5859  vmovaps [rsp+0x20], xmm12
00007fa22efd585f  movq xmm12, xmm12
00007fa22efd5864  movaps [r15+0x280], xmm12
00007fa22efd586c  movaps xmm13, [r15+0x270]
00007fa22efd5874  vmovaps [rsp+0x30], xmm13
00007fa22efd587a  vmovaps xmm12, [rsp+0x30]
00007fa22efd5880  por xmm13, xmm12
00007fa22efd5885  lea rax, [r12+0x20]
00007fa22efd588a  mov r11, [r13+rax*1]
00007fa22efd588f  lea rax, [r12+0x28]
00007fa22efd5894  mov r10, [r13+rax*1]
00007fa22efd5899  movq xmm12, r11
00007fa22efd589e  movq xmm11, r10
00007fa22efd58a3  movq xmm12, xmm12
00007fa22efd58a8  vmovaps [rsp+0x30], xmm12
00007fa22efd58ae  movq xmm12, xmm12
00007fa22efd58b3  movaps [r15+0x150], xmm12
00007fa22efd58bb  movq xmm11, xmm11
00007fa22efd58c0  vmovaps [rsp+0x40], xmm11
00007fa22efd58c6  movq xmm11, xmm11
00007fa22efd58cb  movaps [r15+0x140], xmm11
00007fa22efd58d3  lea rax, [r12+0x10]
00007fa22efd58d8  mov r11, [r13+rax*1]
00007fa22efd58dd  lea rax, [r12+0x18]
00007fa22efd58e2  mov r10, [r13+rax*1]
00007fa22efd58e7  movq xmm12, r11
00007fa22efd58ec  movq xmm11, r10
00007fa22efd58f1  movq xmm12, xmm12
00007fa22efd58f6  vmovaps [rsp+0x50], xmm12
00007fa22efd58fc  movq xmm12, xmm12
00007fa22efd5901  movaps [r15+0x170], xmm12
00007fa22efd5909  movq xmm11, xmm11
00007fa22efd590e  vmovaps [rsp+0x60], xmm11
00007fa22efd5914  movq xmm11, xmm11
00007fa22efd5919  movaps [r15+0x160], xmm11
00007fa22efd5921  mov rax, [r13+r12*1]
00007fa22efd5926  vmovq xmm12, rax
00007fa22efd592b  vpbroadcastq xmm12, xmm12
00007fa22efd5930  lea rax, [r12+0x08]
00007fa22efd5935  mov r12, [r13+rax*1]
00007fa22efd593a  movq xmm11, r12
00007fa22efd593f  movaps [r15+0x230], xmm11
00007fa22efd5947  mov rax, [r15+0xF8]
00007fa22efd594e  lea r12, [rax+0x50]
00007fa22efd5952  movups xmm11, [r13+r12*1]
00007fa22efd5958  lea r12, [rax+0x60]
00007fa22efd595c  movups xmm10, [r13+r12*1]
00007fa22efd5962  lea r12, [rax+0x30]
00007fa22efd5966  movups xmm9, [r13+r12*1]
00007fa22efd596c  mov r12, [r15+0x50]
00007fa22efd5970  lea r11, [r12+r14*1]
00007fa22efd5974  mov [r15+0x60], r11
00007fa22efd5978  lea r12, [r14+0x40]
00007fa22efd597c  mov [r15+0x58], r12
00007fa22efd5980  movaps xmm8, xmm12
00007fa22efd5984  mulpd xmm8, xmm15
00007fa22efd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007fa22efd598f  ptest xmm7, xmm7
00007fa22efd5994  jnz 0x00007FA22EFD67B7
00007fa22efd599a  movq xmm15, qword ptr [r15+0x230]
00007fa22efd59a3  vmovaps [rsp+0x70], xmm15
00007fa22efd59a9  vpermilpd xmm15, xmm15, 0x00
00007fa22efd59af  movaps xmm7, xmm9
00007fa22efd59b3  mulpd xmm7, xmm15
00007fa22efd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa22efd59bd  ptest xmm6, xmm6
00007fa22efd59c2  jnz 0x00007FA22EFD68FB
00007fa22efd59c8  vxorps xmm15, xmm15, xmm15
00007fa22efd59cd  vpbroadcastq xmm15, xmm15
00007fa22efd59d2  movaps xmm9, xmm12
00007fa22efd59d6  mulpd xmm9, xmm10
00007fa22efd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007fa22efd59e1  ptest xmm6, xmm6
00007fa22efd59e6  jnz 0x00007FA22EFD6A3D
00007fa22efd59ec  movaps xmm10, xmm12
00007fa22efd59f0  mulpd xmm10, xmm11
00007fa22efd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007fa22efd59fb  ptest xmm6, xmm6
00007fa22efd5a00  jnz 0x00007FA22EFD6B81
00007fa22efd5a06  movaps xmm11, [r15+0x1F0]
00007fa22efd5a0e  movaps xmm6, xmm12
00007fa22efd5a12  mulpd xmm6, xmm11
00007fa22efd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007fa22efd5a1c  ptest xmm5, xmm5
00007fa22efd5a21  jnz 0x00007FA22EFD6CC5
00007fa22efd5a27  movaps xmm12, [r15+0x2A0]
00007fa22efd5a2f  vmovaps [rsp+0x80], xmm12
00007fa22efd5a38  vmovaps xmm11, [rsp+0x80]
00007fa22efd5a41  por xmm12, xmm11
00007fa22efd5a46  movaps xmm11, [r15+0x250]
00007fa22efd5a4e  vmovaps [rsp+0x80], xmm11
00007fa22efd5a57  vmovaps xmm5, [rsp+0x80]
00007fa22efd5a60  por xmm11, xmm5
00007fa22efd5a65  vmovaps xmm4, [rsp+0x70]
00007fa22efd5a6b  vpermilpd xmm4, xmm4, 0x00
00007fa22efd5a71  movaps xmm3, xmm5
00007fa22efd5a74  mulpd xmm3, xmm4
00007fa22efd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007fa22efd5a7d  ptest xmm2, xmm2
00007fa22efd5a82  jnz 0x00007FA22EFD6E07
00007fa22efd5a88  mov [rsp+0x80], rax
00007fa22efd5a90  xor eax, eax
00007fa22efd5a92  mov r14d, 0x200
00007fa22efd5a98  cmp r12, r14
00007fa22efd5a9b  cmc
00007fa22efd5a9c  lahf
00007fa22efd5a9d  seto al
00007fa22efd5aa0  mov [r15+0x108], eax
00007fa22efd5aa7  movaps xmm5, xmm8
00007fa22efd5aab  addpd xmm5, xmm15
00007fa22efd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007fa22efd5ab5  ptest xmm4, xmm4
00007fa22efd5aba  jnz 0x00007FA22EFD6F47
00007fa22efd5ac0  movaps xmm8, [r15+0x1B0]
00007fa22efd5ac8  movaps xmm4, xmm9
00007fa22efd5acc  addpd xmm4, xmm8
00007fa22efd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007fa22efd5ad6  ptest xmm2, xmm2
00007fa22efd5adb  jnz 0x00007FA22EFD7089
00007fa22efd5ae1  movaps xmm9, xmm10
00007fa22efd5ae5  addpd xmm9, xmm8
00007fa22efd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007fa22efd5af0  ptest xmm2, xmm2
00007fa22efd5af5  jnz 0x00007FA22EFD71CB
00007fa22efd5afb  movaps xmm10, [r15+0x2F0]
00007fa22efd5b03  vmovaps [rsp+0x90], xmm10
00007fa22efd5b0c  vmovaps xmm8, [rsp+0x90]
00007fa22efd5b15  por xmm10, xmm8
00007fa22efd5b1a  movaps xmm8, [r15+0x2E0]
00007fa22efd5b22  vmovaps [rsp+0x90], xmm8
00007fa22efd5b2b  vmovaps xmm2, [rsp+0x90]
00007fa22efd5b34  por xmm8, xmm2
00007fa22efd5b39  movaps xmm2, [r15+0x2D0]
00007fa22efd5b41  vmovaps [rsp+0x90], xmm2
00007fa22efd5b4a  vmovaps [rsp+0xA0], xmm1
00007fa22efd5b53  vmovaps xmm1, [rsp+0x90]
00007fa22efd5b5c  por xmm2, xmm1
00007fa22efd5b60  movaps xmm1, [r15+0x200]
00007fa22efd5b68  vmovaps [rsp+0x90], xmm1
00007fa22efd5b71  vmovaps [rsp+0xB0], xmm15
00007fa22efd5b7a  vmovaps xmm15, [rsp+0x90]
00007fa22efd5b83  por xmm1, xmm15
00007fa22efd5b88  movaps xmm15, [r15+0x1C0]
00007fa22efd5b90  vmovaps [rsp+0x90], xmm15
00007fa22efd5b99  vmovaps [rsp+0xC0], xmm1
00007fa22efd5ba2  vmovaps xmm1, [rsp+0x90]
00007fa22efd5bab  por xmm15, xmm1
00007fa22efd5bb0  movaps xmm1, [r15+0x190]
00007fa22efd5bb8  vmovaps [rsp+0x90], xmm1
00007fa22efd5bc1  vmovaps [rsp+0xD0], xmm15
00007fa22efd5bca  vmovaps xmm15, [rsp+0x90]
00007fa22efd5bd3  por xmm1, xmm15
00007fa22efd5bd8  movaps xmm15, [r15+0x300]
00007fa22efd5be0  vmovaps [rsp+0x90], xmm15
00007fa22efd5be9  vmovaps [rsp+0xE0], xmm1
00007fa22efd5bf2  vmovaps xmm1, [rsp+0x90]
00007fa22efd5bfb  por xmm15, xmm1
00007fa22efd5c00  mov rax, [rsp+0x80]
00007fa22efd5c08  lea r14, [rax+0xA0]
00007fa22efd5c0f  movups xmm1, [r13+r14*1]
00007fa22efd5c15  lea r14, [rax+0xB0]
00007fa22efd5c1c  vmovaps [rsp+0x80], xmm1
00007fa22efd5c25  movups xmm1, [r13+r14*1]
00007fa22efd5c2b  vmovaps [rsp+0x90], xmm1
00007fa22efd5c34  vmovaps [rsp+0xF0], xmm15
00007fa22efd5c3d  vmovaps xmm15, [rsp+0xB0]
00007fa22efd5c46  vmovaps [rsp+0xB0], xmm14
00007fa22efd5c4f  movaps xmm1, xmm6
00007fa22efd5c52  addpd xmm1, xmm15
00007fa22efd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007fa22efd5c5c  ptest xmm14, xmm14
00007fa22efd5c62  jnz 0x00007FA22EFD7323
00007fa22efd5c68  lea r14, [rax+0xF0]
00007fa22efd5c6f  movups xmm15, [r13+r14*1]
00007fa22efd5c75  movaps xmm14, xmm4
00007fa22efd5c79  addpd xmm14, xmm3
00007fa22efd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007fa22efd5c84  ptest xmm6, xmm6
00007fa22efd5c89  jnz 0x00007FA22EFD746E
00007fa22efd5c8f  movaps xmm6, xmm9
00007fa22efd5c93  addpd xmm6, xmm7
00007fa22efd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007fa22efd5c9c  ptest xmm4, xmm4
00007fa22efd5ca1  jnz 0x00007FA22EFD75B0
00007fa22efd5ca7  vmovaps xmm9, [rsp+0x70]
00007fa22efd5cad  vpermilpd xmm9, xmm9, 0x00
00007fa22efd5cb3  vmovaps xmm4, [rsp+0x90]
00007fa22efd5cbc  movaps xmm7, xmm4
00007fa22efd5cbf  mulpd xmm7, xmm9
00007fa22efd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007fa22efd5cc9  ptest xmm3, xmm3
00007fa22efd5cce  jnz 0x00007FA22EFD76F1
00007fa22efd5cd4  vmovaps xmm9, [rsp+0x50]
00007fa22efd5cda  vpermilpd xmm9, xmm9, 0x00
00007fa22efd5ce0  movaps xmm4, xmm15
00007fa22efd5ce4  mulpd xmm4, xmm9
00007fa22efd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007fa22efd5cee  ptest xmm3, xmm3
00007fa22efd5cf3  jnz 0x00007FA22EFD7832
00007fa22efd5cf9  lea r14, [rax+0xE0]
00007fa22efd5d00  movups xmm15, [r13+r14*1]
00007fa22efd5d06  vmovaps xmm9, [rsp+0x70]
00007fa22efd5d0c  vpermilpd xmm9, xmm9, 0x00
00007fa22efd5d12  vmovaps [rsp+0x70], xmm1
00007fa22efd5d18  vmovaps xmm1, [rsp+0x80]
00007fa22efd5d21  vmovaps [rsp+0x80], xmm15
00007fa22efd5d2a  movaps xmm3, xmm1
00007fa22efd5d2d  mulpd xmm3, xmm9
00007fa22efd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007fa22efd5d37  ptest xmm15, xmm15
00007fa22efd5d3d  jnz 0x00007FA22EFD797E
00007fa22efd5d43  vmovaps xmm1, [rsp+0xF0]
00007fa22efd5d4c  vmovaps xmm15, [rsp+0xF0]
00007fa22efd5d55  por xmm1, xmm15
00007fa22efd5d5a  movaps [r15+0x300], xmm1
00007fa22efd5d62  vmovaps xmm15, [rsp+0xE0]
00007fa22efd5d6b  vmovaps xmm9, [rsp+0xE0]
00007fa22efd5d74  por xmm15, xmm9
00007fa22efd5d79  movaps [r15+0x190], xmm15
00007fa22efd5d81  vmovaps xmm9, [rsp+0x50]
00007fa22efd5d87  vpermilpd xmm9, xmm9, 0x00
00007fa22efd5d8d  vmovaps [rsp+0x90], xmm1
00007fa22efd5d96  vmovaps [rsp+0xE0], xmm15
00007fa22efd5d9f  vmovaps xmm15, [rsp+0x80]
00007fa22efd5da8  vmovaps [rsp+0x80], xmm14
00007fa22efd5db1  movaps xmm1, xmm15
00007fa22efd5db5  mulpd xmm1, xmm9
00007fa22efd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007fa22efd5dbf  ptest xmm14, xmm14
00007fa22efd5dc5  jnz 0x00007FA22EFD7ABF
00007fa22efd5dcb  lea r14, [rax+0x90]
00007fa22efd5dd2  movups xmm15, [r13+r14*1]
00007fa22efd5dd8  vmovaps xmm14, [rsp+0xD0]
00007fa22efd5de1  vmovaps xmm9, [rsp+0xD0]
00007fa22efd5dea  por xmm14, xmm9
00007fa22efd5def  movaps [r15+0x1C0], xmm14
00007fa22efd5df7  vmovaps xmm9, [rsp+0xC0]
00007fa22efd5e00  vmovaps [rsp+0xD0], xmm1
00007fa22efd5e09  vmovaps xmm1, [rsp+0xC0]
00007fa22efd5e12  por xmm9, xmm1
00007fa22efd5e17  movaps [r15+0x200], xmm9
00007fa22efd5e1f  vmovaps [rsp+0xC0], xmm2
00007fa22efd5e28  vmovaps xmm1, [rsp+0xC0]
00007fa22efd5e31  por xmm2, xmm1
00007fa22efd5e35  movaps [r15+0x2D0], xmm2
00007fa22efd5e3d  vmovaps [rsp+0xC0], xmm8
00007fa22efd5e46  vmovaps xmm1, [rsp+0xC0]
00007fa22efd5e4f  por xmm8, xmm1
00007fa22efd5e54  movaps [r15+0x2E0], xmm8
00007fa22efd5e5c  vmovaps [rsp+0xC0], xmm15
00007fa22efd5e65  movaps xmm1, xmm5
00007fa22efd5e68  addpd xmm1, xmm7
00007fa22efd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa22efd5e71  ptest xmm15, xmm15
00007fa22efd5e77  jnz 0x00007FA22EFD7C0B
00007fa22efd5e7d  vmovaps xmm15, [rsp+0x50]
00007fa22efd5e83  vpermilpd xmm15, xmm15, 0x00
00007fa22efd5e89  vmovaps xmm5, [rsp+0xC0]
00007fa22efd5e92  vmovaps [rsp+0xC0], xmm1
00007fa22efd5e9b  movaps xmm7, xmm5
00007fa22efd5e9e  mulpd xmm7, xmm15
00007fa22efd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007fa22efd5ea8  ptest xmm1, xmm1
00007fa22efd5ead  jnz 0x00007FA22EFD7D4B
00007fa22efd5eb3  lea r14, [rax+0x80]
00007fa22efd5eba  movups xmm1, [r13+r14*1]
00007fa22efd5ec0  vmovaps xmm5, [rsp+0x70]
00007fa22efd5ec6  vmovaps [rsp+0x70], xmm1
00007fa22efd5ecc  movaps xmm15, xmm5
00007fa22efd5ed0  addpd xmm15, xmm3
00007fa22efd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa22efd5edb  ptest xmm1, xmm1
00007fa22efd5ee0  jnz 0x00007FA22EFD7E96
00007fa22efd5ee6  vmovaps xmm5, [rsp+0x80]
00007fa22efd5eef  movaps xmm1, xmm5
00007fa22efd5ef2  addpd xmm1, xmm4
00007fa22efd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007fa22efd5efb  ptest xmm3, xmm3
00007fa22efd5f00  jnz 0x00007FA22EFD7FD8
00007fa22efd5f06  vmovaps [rsp+0x80], xmm10
00007fa22efd5f0f  vmovaps xmm5, [rsp+0x80]
00007fa22efd5f18  por xmm10, xmm5
00007fa22efd5f1d  movaps [r15+0x2F0], xmm10
00007fa22efd5f25  vmovaps xmm5, [rsp+0x50]
00007fa22efd5f2b  vpermilpd xmm5, xmm5, 0x00
00007fa22efd5f31  vmovaps xmm3, [rsp+0x70]
00007fa22efd5f37  vmovaps [rsp+0x50], xmm1
00007fa22efd5f3d  movaps xmm4, xmm3
00007fa22efd5f40  mulpd xmm4, xmm5
00007fa22efd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007fa22efd5f49  ptest xmm1, xmm1
00007fa22efd5f4e  jnz 0x00007FA22EFD8118
00007fa22efd5f54  lea r14, [rax+0xD0]
00007fa22efd5f5b  movups xmm1, [r13+r14*1]
00007fa22efd5f61  vmovaps xmm3, [rsp+0xD0]
00007fa22efd5f6a  vmovaps [rsp+0x70], xmm1
00007fa22efd5f70  movaps xmm5, xmm6
00007fa22efd5f73  addpd xmm5, xmm3
00007fa22efd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007fa22efd5f7c  ptest xmm1, xmm1
00007fa22efd5f81  jnz 0x00007FA22EFD8262
00007fa22efd5f87  vmovaps xmm1, [rsp+0x60]
00007fa22efd5f8d  vpermilpd xmm1, xmm1, 0x00
00007fa22efd5f93  movaps xmm6, xmm9
00007fa22efd5f97  mulpd xmm6, xmm1
00007fa22efd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007fa22efd5fa0  ptest xmm3, xmm3
00007fa22efd5fa5  jnz 0x00007FA22EFD83A2
00007fa22efd5fab  movaps [r15+0x260], xmm6
00007fa22efd5fb3  vxorps xmm1, xmm1, xmm1
00007fa22efd5fb7  vpbroadcastq xmm1, xmm1
00007fa22efd5fbc  movaps [r15+0x1B0], xmm1
00007fa22efd5fc4  vmovaps xmm1, [rsp+0x60]
00007fa22efd5fca  vpermilpd xmm1, xmm1, 0x00
00007fa22efd5fd0  vmovaps xmm3, [rsp+0x70]
00007fa22efd5fd6  vmovaps [rsp+0x70], xmm15
00007fa22efd5fdc  movaps xmm9, xmm3
00007fa22efd5fe0  mulpd xmm9, xmm1
00007fa22efd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007fa22efd5feb  ptest xmm15, xmm15
00007fa22efd5ff1  jnz 0x00007FA22EFD84E3
00007fa22efd5ff7  lea r14, [rax+0xC0]
00007fa22efd5ffe  movups xmm1, [r13+r14*1]
00007fa22efd6004  vmovaps xmm3, [rsp+0xC0]
00007fa22efd600d  vmovaps [rsp+0x80], xmm1
00007fa22efd6016  movaps xmm15, xmm3
00007fa22efd601a  addpd xmm15, xmm7
00007fa22efd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa22efd6025  ptest xmm1, xmm1
00007fa22efd602a  jnz 0x00007FA22EFD862F
00007fa22efd6030  vmovaps [rsp+0xC0], xmm13
00007fa22efd6039  vmovaps xmm1, [rsp+0xC0]
00007fa22efd6042  por xmm13, xmm1
00007fa22efd6047  movaps [r15+0x270], xmm13
00007fa22efd604f  vmovaps xmm1, [rsp+0xB0]
00007fa22efd6058  vmovaps xmm7, [rsp+0xB0]
00007fa22efd6061  por xmm1, xmm7
00007fa22efd6065  movaps [r15+0x1A0], xmm1
00007fa22efd606d  vmovaps xmm1, [rsp+0x60]
00007fa22efd6073  vpermilpd xmm1, xmm1, 0x00
00007fa22efd6079  vmovaps [rsp+0xB0], xmm1
00007fa22efd6082  vmovaps xmm1, [rsp+0x80]
00007fa22efd608b  vmovaps [rsp+0x80], xmm15
00007fa22efd6094  vmovaps xmm15, [rsp+0xB0]
00007fa22efd609d  vmovaps [rsp+0xB0], xmm14
00007fa22efd60a6  movaps xmm3, xmm1
00007fa22efd60a9  mulpd xmm3, xmm15
00007fa22efd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007fa22efd60b3  ptest xmm14, xmm14
00007fa22efd60b9  jnz 0x00007FA22EFD8771
00007fa22efd60bf  lea r14, [rax+0x20]
00007fa22efd60c3  movups xmm1, [r13+r14*1]
00007fa22efd60c9  movaps [r15+0x110], xmm1
00007fa22efd60d1  vmovaps xmm14, [rsp+0x70]
00007fa22efd60d7  vmovaps [rsp+0x70], xmm1
00007fa22efd60dd  movaps xmm15, xmm14
00007fa22efd60e1  addpd xmm15, xmm4
00007fa22efd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa22efd60ec  ptest xmm1, xmm1
00007fa22efd60f1  jnz 0x00007FA22EFD88BC
00007fa22efd60f7  vmovaps xmm1, [rsp+0x60]
00007fa22efd60fd  vpermilpd xmm1, xmm1, 0x00
00007fa22efd6103  movaps xmm14, xmm2
00007fa22efd6107  mulpd xmm14, xmm1
00007fa22efd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007fa22efd6112  ptest xmm4, xmm4
00007fa22efd6117  jnz 0x00007FA22EFD89FF
00007fa22efd611d  vmovaps xmm4, [rsp+0x50]
00007fa22efd6123  movaps xmm1, xmm4
00007fa22efd6126  addpd xmm1, xmm9
00007fa22efd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa22efd6130  ptest xmm2, xmm2
00007fa22efd6135  jnz 0x00007FA22EFD8B41
00007fa22efd613b  vmovaps xmm9, [rsp+0x30]
00007fa22efd6141  vpermilpd xmm9, xmm9, 0x00
00007fa22efd6147  vmovaps xmm2, [rsp+0x70]
00007fa22efd614d  vmovaps [rsp+0x50], xmm1
00007fa22efd6153  movaps xmm4, xmm2
00007fa22efd6156  mulpd xmm4, xmm9
00007fa22efd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007fa22efd6160  ptest xmm1, xmm1
00007fa22efd6165  jnz 0x00007FA22EFD8C82
00007fa22efd616b  vmovaps xmm1, [rsp+0x30]
00007fa22efd6171  vpermilpd xmm1, xmm1, 0x00
00007fa22efd6177  vmovaps xmm2, [rsp+0x90]
00007fa22efd6180  vmovaps [rsp+0x60], xmm15
00007fa22efd6186  movaps xmm9, xmm2
00007fa22efd618a  mulpd xmm9, xmm1
00007fa22efd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007fa22efd6195  ptest xmm15, xmm15
00007fa22efd619b  jnz 0x00007FA22EFD8DC3
00007fa22efd61a1  vmovaps xmm15, [rsp+0x80]
00007fa22efd61aa  movaps xmm1, xmm15
00007fa22efd61ae  addpd xmm1, xmm6
00007fa22efd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa22efd61b7  ptest xmm2, xmm2
00007fa22efd61bc  jnz 0x00007FA22EFD8F05
00007fa22efd61c2  movaps xmm15, xmm5
00007fa22efd61c6  addpd xmm15, xmm3
00007fa22efd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007fa22efd61d1  ptest xmm6, xmm6
00007fa22efd61d6  jnz 0x00007FA22EFD9046
00007fa22efd61dc  vmovaps xmm6, [rsp+0x30]
00007fa22efd61e2  vpermilpd xmm6, xmm6, 0x00
00007fa22efd61e8  movaps xmm5, xmm8
00007fa22efd61ec  mulpd xmm5, xmm6
00007fa22efd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007fa22efd61f5  ptest xmm3, xmm3
00007fa22efd61fa  jnz 0x00007FA22EFD9188
00007fa22efd6200  vmovaps xmm8, [rsp+0x30]
00007fa22efd6206  vpermilpd xmm8, xmm8, 0x00
00007fa22efd620c  movaps xmm6, xmm10
00007fa22efd6210  mulpd xmm6, xmm8
00007fa22efd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007fa22efd621a  ptest xmm3, xmm3
00007fa22efd621f  jnz 0x00007FA22EFD92C9
00007fa22efd6225  vmovaps xmm8, [rsp+0x60]
00007fa22efd622b  movaps xmm10, xmm8
00007fa22efd622f  addpd xmm10, xmm14
00007fa22efd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007fa22efd623a  ptest xmm3, xmm3
00007fa22efd623f  jnz 0x00007FA22EFD940B
00007fa22efd6245  vmovaps xmm8, [rsp+0x50]
00007fa22efd624b  movaps xmm14, xmm8
00007fa22efd624f  addpd xmm14, xmm4
00007fa22efd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007fa22efd625a  ptest xmm3, xmm3
00007fa22efd625f  jnz 0x00007FA22EFD954F
00007fa22efd6265  vmovaps xmm8, [rsp+0x40]
00007fa22efd626b  vpermilpd xmm8, xmm8, 0x00
00007fa22efd6271  movaps xmm4, xmm13
00007fa22efd6275  mulpd xmm4, xmm8
00007fa22efd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007fa22efd627f  ptest xmm3, xmm3
00007fa22efd6284  jnz 0x00007FA22EFD9692
00007fa22efd628a  movaps xmm13, xmm15
00007fa22efd628e  addpd xmm13, xmm9
00007fa22efd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007fa22efd6299  ptest xmm8, xmm8
00007fa22efd629f  jnz 0x00007FA22EFD97D4
00007fa22efd62a5  movaps xmm15, xmm1
00007fa22efd62a9  addpd xmm15, xmm5
00007fa22efd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007fa22efd62b4  ptest xmm9, xmm9
00007fa22efd62ba  jnz 0x00007FA22EFD9918
00007fa22efd62c0  vmovaps [rsp+0x30], xmm11
00007fa22efd62c6  vmovaps xmm1, [rsp+0x30]
00007fa22efd62cc  por xmm11, xmm1
00007fa22efd62d1  movaps [r15+0x250], xmm11
00007fa22efd62d9  vmovaps [rsp+0x30], xmm12
00007fa22efd62df  vmovaps xmm1, [rsp+0x30]
00007fa22efd62e5  por xmm12, xmm1
00007fa22efd62ea  movaps [r15+0x2A0], xmm12
00007fa22efd62f2  vmovaps xmm1, [rsp+0xA0]
00007fa22efd62fb  vmovaps xmm11, [rsp+0xA0]
00007fa22efd6304  por xmm1, xmm11
00007fa22efd6309  movaps [r15+0x1D0], xmm1
00007fa22efd6311  lea r14, [rax+0x40]
00007fa22efd6315  movups xmm1, [r13+r14*1]
00007fa22efd631b  movaps [r15+0x2C0], xmm1
00007fa22efd6323  vmovaps xmm11, [rsp+0x40]
00007fa22efd6329  vpermilpd xmm11, xmm11, 0x00
00007fa22efd632f  vmovaps xmm8, [rsp+0xE0]
00007fa22efd6338  movaps xmm9, xmm8
00007fa22efd633c  mulpd xmm9, xmm11
00007fa22efd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007fa22efd6347  ptest xmm5, xmm5
00007fa22efd634c  jnz 0x00007FA22EFD9A64
00007fa22efd6352  movaps xmm11, xmm10
00007fa22efd6356  addpd xmm11, xmm6
00007fa22efd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007fa22efd6361  ptest xmm8, xmm8
00007fa22efd6367  jnz 0x00007FA22EFD9BA8
00007fa22efd636d  movaps xmm10, xmm14
00007fa22efd6371  addpd xmm10, xmm4
00007fa22efd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007fa22efd637c  ptest xmm8, xmm8
00007fa22efd6382  jnz 0x00007FA22EFD9CEB
00007fa22efd6388  vmovaps xmm14, [rsp+0x40]
00007fa22efd638e  vpermilpd xmm14, xmm14, 0x00
00007fa22efd6394  movaps xmm8, xmm1
00007fa22efd6398  mulpd xmm8, xmm14
00007fa22efd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007fa22efd63a3  ptest xmm6, xmm6
00007fa22efd63a8  jnz 0x00007FA22EFD9E2E
00007fa22efd63ae  movaps xmm1, [r15+0x2B0]
00007fa22efd63b6  vmovaps xmm14, [rsp+0x40]
00007fa22efd63bc  vpermilpd xmm14, xmm14, 0x00
00007fa22efd63c2  movaps xmm6, xmm1
00007fa22efd63c5  mulpd xmm6, xmm14
00007fa22efd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007fa22efd63cf  ptest xmm5, xmm5
00007fa22efd63d4  jnz 0x00007FA22EFD9F71
00007fa22efd63da  vmovaps xmm1, [rsp+0x10]
00007fa22efd63e0  vpermilpd xmm1, xmm1, 0x00
00007fa22efd63e6  movaps xmm14, xmm12
00007fa22efd63ea  mulpd xmm14, xmm1
00007fa22efd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007fa22efd63f5  ptest xmm5, xmm5
00007fa22efd63fa  jnz 0x00007FA22EFDA0B2
00007fa22efd6400  movaps xmm1, xmm13
00007fa22efd6404  addpd xmm1, xmm9
00007fa22efd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa22efd640e  ptest xmm12, xmm12
00007fa22efd6414  jnz 0x00007FA22EFDA1F5
00007fa22efd641a  vmovaps xmm13, [rsp+0x10]
00007fa22efd6420  vpermilpd xmm13, xmm13, 0x00
00007fa22efd6426  movaps xmm12, xmm7
00007fa22efd642a  mulpd xmm12, xmm13
00007fa22efd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007fa22efd6435  ptest xmm9, xmm9
00007fa22efd643b  jnz 0x00007FA22EFDA337
00007fa22efd6441  movaps xmm13, xmm15
00007fa22efd6445  addpd xmm13, xmm8
00007fa22efd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007fa22efd6450  ptest xmm9, xmm9
00007fa22efd6456  jnz 0x00007FA22EFDA47A
00007fa22efd645c  movaps xmm15, [r15+0x290]
00007fa22efd6464  vmovaps xmm9, [rsp+0x10]
00007fa22efd646a  vpermilpd xmm9, xmm9, 0x00
00007fa22efd6470  movaps xmm8, xmm15
00007fa22efd6474  mulpd xmm8, xmm9
00007fa22efd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007fa22efd647f  ptest xmm7, xmm7
00007fa22efd6484  jnz 0x00007FA22EFDA5BE
00007fa22efd648a  movaps xmm15, xmm11
00007fa22efd648e  addpd xmm15, xmm6
00007fa22efd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007fa22efd6499  ptest xmm9, xmm9
00007fa22efd649f  jnz 0x00007FA22EFDA702
00007fa22efd64a5  movaps xmm11, [r15+0x1E0]
00007fa22efd64ad  vmovaps xmm9, [rsp+0x10]
00007fa22efd64b3  vpermilpd xmm9, xmm9, 0x00
00007fa22efd64b9  movaps xmm7, xmm11
00007fa22efd64bd  mulpd xmm7, xmm9
00007fa22efd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa22efd64c7  ptest xmm6, xmm6
00007fa22efd64cc  jnz 0x00007FA22EFDA845
00007fa22efd64d2  movaps xmm11, xmm10
00007fa22efd64d6  addpd xmm11, xmm14
00007fa22efd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007fa22efd64e1  ptest xmm9, xmm9
00007fa22efd64e7  jnz 0x00007FA22EFDA987
00007fa22efd64ed  lea r14, [rax+0x70]
00007fa22efd64f1  movups xmm14, [r13+r14*1]
00007fa22efd64f7  movaps [r15+0x240], xmm14
00007fa22efd64ff  movaps xmm10, xmm1
00007fa22efd6503  addpd xmm10, xmm12
00007fa22efd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007fa22efd650e  ptest xmm9, xmm9
00007fa22efd6514  jnz 0x00007FA22EFDAAD5
00007fa22efd651a  movaps [r15+0x170], xmm10
00007fa22efd6522  vmovaps xmm1, [rsp+0x20]
00007fa22efd6528  vpermilpd xmm1, xmm1, 0x00
00007fa22efd652e  movaps xmm12, xmm14
00007fa22efd6532  mulpd xmm12, xmm1
00007fa22efd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007fa22efd653d  ptest xmm9, xmm9
00007fa22efd6543  jnz 0x00007FA22EFDAC18
00007fa22efd6549  vmovaps xmm1, [rsp+0x20]
00007fa22efd654f  vpermilpd xmm1, xmm1, 0x00
00007fa22efd6555  vmovaps xmm9, [rsp+0xB0]
00007fa22efd655e  movaps xmm14, xmm9
00007fa22efd6562  mulpd xmm14, xmm1
00007fa22efd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007fa22efd656d  ptest xmm6, xmm6
00007fa22efd6572  jnz 0x00007FA22EFDAD5B
00007fa22efd6578  movaps [r15+0x180], xmm14
00007fa22efd6580  movaps xmm1, xmm13
00007fa22efd6584  addpd xmm1, xmm8
00007fa22efd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007fa22efd658e  ptest xmm9, xmm9
00007fa22efd6594  jnz 0x00007FA22EFDAE9E
00007fa22efd659a  movaps [r15+0x210], xmm1
00007fa22efd65a2  movups xmm13, [r13+rax*1]
00007fa22efd65a8  lea r14, [rax+0x10]
00007fa22efd65ac  movups xmm9, [r13+r14*1]
00007fa22efd65b2  movaps [r15+0x230], xmm9
00007fa22efd65ba  movaps xmm8, xmm15
00007fa22efd65be  addpd xmm8, xmm7
00007fa22efd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007fa22efd65c9  ptest xmm6, xmm6
00007fa22efd65ce  jnz 0x00007FA22EFDAFF4
00007fa22efd65d4  movaps [r15+0x130], xmm8
00007fa22efd65dc  vmovaps xmm15, [rsp+0x20]
00007fa22efd65e2  vpermilpd xmm15, xmm15, 0x00
00007fa22efd65e8  movaps xmm7, xmm9
00007fa22efd65ec  mulpd xmm7, xmm15
00007fa22efd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa22efd65f6  ptest xmm6, xmm6
00007fa22efd65fb  jnz 0x00007FA22EFDB137
00007fa22efd6601  movaps [r15+0x220], xmm7
00007fa22efd6609  vmovaps xmm15, [rsp+0x20]
00007fa22efd660f  vpermilpd xmm15, xmm15, 0x00
00007fa22efd6615  movaps xmm9, xmm13
00007fa22efd6619  mulpd xmm9, xmm15
00007fa22efd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007fa22efd6624  ptest xmm6, xmm6
00007fa22efd6629  jnz 0x00007FA22EFDB279
00007fa22efd662f  movaps xmm15, xmm11
00007fa22efd6633  addpd xmm15, xmm12
00007fa22efd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007fa22efd663e  ptest xmm13, xmm13
00007fa22efd6644  jnz 0x00007FA22EFDB3BD
00007fa22efd664a  movaps [r15+0x140], xmm15
00007fa22efd6652  movaps xmm13, xmm10
00007fa22efd6656  addpd xmm13, xmm14
00007fa22efd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007fa22efd6661  ptest xmm12, xmm12
00007fa22efd6667  jnz 0x00007FA22EFDB501
00007fa22efd666d  movaps [r15+0x150], xmm13
00007fa22efd6675  movaps xmm14, xmm1
00007fa22efd6679  addpd xmm14, xmm7
00007fa22efd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007fa22efd6684  ptest xmm12, xmm12
00007fa22efd668a  jnz 0x00007FA22EFDB645
00007fa22efd6690  movaps [r15+0x160], xmm14
00007fa22efd6698  movaps xmm1, xmm8
00007fa22efd669c  addpd xmm1, xmm9
00007fa22efd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa22efd66a6  ptest xmm12, xmm12
00007fa22efd66ac  jnz 0x00007FA22EFDB787
00007fa22efd66b2  movaps [r15+0x120], xmm1
00007fa22efd66ba  movups [r13+r11*1], xmm15
00007fa22efd66c0  lea rax, [r11+0x10]
00007fa22efd66c4  movups [r13+rax*1], xmm13
00007fa22efd66ca  lea rax, [r11+0x20]
00007fa22efd66ce  movups [r13+rax*1], xmm14
00007fa22efd66d4  lea rax, [r11+0x30]
00007fa22efd66d8  movups [r13+rax*1], xmm1
00007fa22efd66de  mov eax, [r15+0x108]
00007fa22efd66e5  sahf
00007fa22efd66e6  jnz 0x00007FA22EFD6718
00007fa22efd66e8  cmp dword ptr [r15+0x318], 0x00
00007fa22efd66f0  jz 0x00007FA22EFDB900
00007fa22efd66f6  nop [rax+rax*1], ax
00007fa22efd66ff  nop [rax+rax*1], eax
00007fa22efd6707  mov eax, 0x410444
00007fa22efd670c  mov [r15+0x100], rax
00007fa22efd6713  jmp 0x00007FA22EDFE110
00007fa22efd6718  cmp dword ptr [r15+0x318], 0x00
00007fa22efd6720  jz 0x00007FA22EFD57E0
00007fa22efd6726  nop [rax+rax*1], ax
00007fa22efd672f  nop [rax+rax*1], eax
00007fa22efd6737  mov eax, 0x410278
00007fa22efd673c  mov [r15+0x100], rax
00007fa22efd6743  jmp 0x00007FA22EDFE110
00007fa22efd6748  int3
00007fa22efd6749  call 0x00007FA22EE0A4B0
00007fa22efd674e  jmp 0x00007FA22EFD5828
00007fa22efd6753  call 0x00007FA22EE09240
00007fa22efd6758  jmp 0x00007FA22EFD5832
00007fa22efd675d  call 0x00007FA22EE0A4B0
00007fa22efd6762  jmp 0x00007FA22EFD588F
00007fa22efd6767  call 0x00007FA22EE09240
00007fa22efd676c  jmp 0x00007FA22EFD5899
00007fa22efd6771  call 0x00007FA22EE0A4B0
00007fa22efd6776  jmp 0x00007FA22EFD58DD
00007fa22efd677b  call 0x00007FA22EE09240
00007fa22efd6780  jmp 0x00007FA22EFD58E7
00007fa22efd6785  call 0x00007FA22EEB47C0
00007fa22efd678a  jmp 0x00007FA22EFD5926
00007fa22efd678f  call 0x00007FA22EE0B720
00007fa22efd6794  jmp 0x00007FA22EFD593A
00007fa22efd6799  call 0x00007FA22EEBFC30
00007fa22efd679e  jmp 0x00007FA22EFD5958
00007fa22efd67a3  call 0x00007FA22EEBE9C0
00007fa22efd67a8  jmp 0x00007FA22EFD5962
00007fa22efd67ad  call 0x00007FA22EEBD750
00007fa22efd67b2  jmp 0x00007FA22EFD596C
00007fa22efd67b7  sub rsp, 0x08
00007fa22efd67bb  push rax
00007fa22efd67bc  push rcx
00007fa22efd67bd  push rdx
00007fa22efd67be  push rdi
00007fa22efd67bf  push rsi
00007fa22efd67c0  push r8
00007fa22efd67c2  push r9
00007fa22efd67c4  push r10
00007fa22efd67c6  push r11
00007fa22efd67c8  sub rsp, 0xF0
00007fa22efd67cf  vmovaps [rsp], xmm0
00007fa22efd67d4  vmovaps [rsp+0x10], xmm1
00007fa22efd67da  vmovaps [rsp+0x20], xmm2
00007fa22efd67e0  vmovaps [rsp+0x30], xmm3
00007fa22efd67e6  vmovaps [rsp+0x40], xmm4
00007fa22efd67ec  vmovaps [rsp+0x50], xmm5
00007fa22efd67f2  vmovaps [rsp+0x60], xmm6
00007fa22efd67f8  vmovaps [rsp+0x70], xmm7
00007fa22efd67fe  vmovaps [rsp+0x80], xmm9
00007fa22efd6807  vmovaps [rsp+0x90], xmm10
00007fa22efd6810  vmovaps [rsp+0xA0], xmm11
00007fa22efd6819  vmovaps [rsp+0xB0], xmm12
00007fa22efd6822  vmovaps [rsp+0xC0], xmm13
00007fa22efd682b  vmovaps [rsp+0xD0], xmm14
00007fa22efd6834  vmovaps [rsp+0xE0], xmm15
00007fa22efd683d  sub rsp, 0x30
00007fa22efd6841  movaps [rsp], xmm8
00007fa22efd6846  movaps [rsp+0x10], xmm12
00007fa22efd684c  movaps [rsp+0x20], xmm15
00007fa22efd6852  lea rdi, [rsp]
00007fa22efd6856  mov esi, 0x00
00007fa22efd685b  mov rax, 0x5E9D1A57D530
00007fa22efd6865  call rax
00007fa22efd6867  movaps xmm8, [rsp]
00007fa22efd686c  add rsp, 0x30
00007fa22efd6870  vmovaps xmm0, [rsp]
00007fa22efd6875  vmovaps xmm1, [rsp+0x10]
00007fa22efd687b  vmovaps xmm2, [rsp+0x20]
00007fa22efd6881  vmovaps xmm3, [rsp+0x30]
00007fa22efd6887  vmovaps xmm4, [rsp+0x40]
00007fa22efd688d  vmovaps xmm5, [rsp+0x50]
00007fa22efd6893  vmovaps xmm6, [rsp+0x60]
00007fa22efd6899  vmovaps xmm7, [rsp+0x70]
00007fa22efd689f  vmovaps xmm9, [rsp+0x80]
00007fa22efd68a8  vmovaps xmm10, [rsp+0x90]
00007fa22efd68b1  vmovaps xmm11, [rsp+0xA0]
00007fa22efd68ba  vmovaps xmm12, [rsp+0xB0]
00007fa22efd68c3  vmovaps xmm13, [rsp+0xC0]
00007fa22efd68cc  vmovaps xmm14, [rsp+0xD0]
00007fa22efd68d5  vmovaps xmm15, [rsp+0xE0]
00007fa22efd68de  add rsp, 0xF0
00007fa22efd68e5  pop r11
00007fa22efd68e7  pop r10
00007fa22efd68e9  pop r9
00007fa22efd68eb  pop r8
00007fa22efd68ed  pop rsi
00007fa22efd68ee  pop rdi
00007fa22efd68ef  pop rdx
00007fa22efd68f0  pop rcx
00007fa22efd68f1  pop rax
00007fa22efd68f2  add rsp, 0x08
00007fa22efd68f6  jmp 0x00007FA22EFD599A
00007fa22efd68fb  sub rsp, 0x08
00007fa22efd68ff  push rax
00007fa22efd6900  push rcx
00007fa22efd6901  push rdx
00007fa22efd6902  push rdi
00007fa22efd6903  push rsi
00007fa22efd6904  push r8
00007fa22efd6906  push r9
00007fa22efd6908  push r10
00007fa22efd690a  push r11
00007fa22efd690c  sub rsp, 0xF0
00007fa22efd6913  vmovaps [rsp], xmm0
00007fa22efd6918  vmovaps [rsp+0x10], xmm1
00007fa22efd691e  vmovaps [rsp+0x20], xmm2
00007fa22efd6924  vmovaps [rsp+0x30], xmm3
00007fa22efd692a  vmovaps [rsp+0x40], xmm4
00007fa22efd6930  vmovaps [rsp+0x50], xmm5
00007fa22efd6936  vmovaps [rsp+0x60], xmm6
00007fa22efd693c  vmovaps [rsp+0x70], xmm8
00007fa22efd6942  vmovaps [rsp+0x80], xmm9
00007fa22efd694b  vmovaps [rsp+0x90], xmm10
00007fa22efd6954  vmovaps [rsp+0xA0], xmm11
00007fa22efd695d  vmovaps [rsp+0xB0], xmm12
00007fa22efd6966  vmovaps [rsp+0xC0], xmm13
00007fa22efd696f  vmovaps [rsp+0xD0], xmm14
00007fa22efd6978  vmovaps [rsp+0xE0], xmm15
00007fa22efd6981  sub rsp, 0x30
00007fa22efd6985  movaps [rsp], xmm7
00007fa22efd6989  movaps [rsp+0x10], xmm9
00007fa22efd698f  movaps [rsp+0x20], xmm15
00007fa22efd6995  lea rdi, [rsp]
00007fa22efd6999  mov esi, 0x00
00007fa22efd699e  mov rax, 0x5E9D1A57D530
00007fa22efd69a8  call rax
00007fa22efd69aa  movaps xmm7, [rsp]
00007fa22efd69ae  add rsp, 0x30
00007fa22efd69b2  vmovaps xmm0, [rsp]
00007fa22efd69b7  vmovaps xmm1, [rsp+0x10]
00007fa22efd69bd  vmovaps xmm2, [rsp+0x20]
00007fa22efd69c3  vmovaps xmm3, [rsp+0x30]
00007fa22efd69c9  vmovaps xmm4, [rsp+0x40]
00007fa22efd69cf  vmovaps xmm5, [rsp+0x50]
00007fa22efd69d5  vmovaps xmm6, [rsp+0x60]
00007fa22efd69db  vmovaps xmm8, [rsp+0x70]
00007fa22efd69e1  vmovaps xmm9, [rsp+0x80]
00007fa22efd69ea  vmovaps xmm10, [rsp+0x90]
00007fa22efd69f3  vmovaps xmm11, [rsp+0xA0]
00007fa22efd69fc  vmovaps xmm12, [rsp+0xB0]
00007fa22efd6a05  vmovaps xmm13, [rsp+0xC0]
00007fa22efd6a0e  vmovaps xmm14, [rsp+0xD0]
00007fa22efd6a17  vmovaps xmm15, [rsp+0xE0]
00007fa22efd6a20  add rsp, 0xF0
00007fa22efd6a27  pop r11
00007fa22efd6a29  pop r10
00007fa22efd6a2b  pop r9
00007fa22efd6a2d  pop r8
00007fa22efd6a2f  pop rsi
00007fa22efd6a30  pop rdi
00007fa22efd6a31  pop rdx
00007fa22efd6a32  pop rcx
00007fa22efd6a33  pop rax
00007fa22efd6a34  add rsp, 0x08
00007fa22efd6a38  jmp 0x00007FA22EFD59C8
00007fa22efd6a3d  sub rsp, 0x08
00007fa22efd6a41  push rax
00007fa22efd6a42  push rcx
00007fa22efd6a43  push rdx
00007fa22efd6a44  push rdi
00007fa22efd6a45  push rsi
00007fa22efd6a46  push r8
00007fa22efd6a48  push r9
00007fa22efd6a4a  push r10
00007fa22efd6a4c  push r11
00007fa22efd6a4e  sub rsp, 0xF0
00007fa22efd6a55  vmovaps [rsp], xmm0
00007fa22efd6a5a  vmovaps [rsp+0x10], xmm1
00007fa22efd6a60  vmovaps [rsp+0x20], xmm2
00007fa22efd6a66  vmovaps [rsp+0x30], xmm3
00007fa22efd6a6c  vmovaps [rsp+0x40], xmm4
00007fa22efd6a72  vmovaps [rsp+0x50], xmm5
00007fa22efd6a78  vmovaps [rsp+0x60], xmm6
00007fa22efd6a7e  vmovaps [rsp+0x70], xmm7
00007fa22efd6a84  vmovaps [rsp+0x80], xmm8
00007fa22efd6a8d  vmovaps [rsp+0x90], xmm10
00007fa22efd6a96  vmovaps [rsp+0xA0], xmm11
00007fa22efd6a9f  vmovaps [rsp+0xB0], xmm12
00007fa22efd6aa8  vmovaps [rsp+0xC0], xmm13
00007fa22efd6ab1  vmovaps [rsp+0xD0], xmm14
00007fa22efd6aba  vmovaps [rsp+0xE0], xmm15
00007fa22efd6ac3  sub rsp, 0x30
00007fa22efd6ac7  movaps [rsp], xmm9
00007fa22efd6acc  movaps [rsp+0x10], xmm12
00007fa22efd6ad2  movaps [rsp+0x20], xmm10
00007fa22efd6ad8  lea rdi, [rsp]
00007fa22efd6adc  mov esi, 0x00
00007fa22efd6ae1  mov rax, 0x5E9D1A57D530
00007fa22efd6aeb  call rax
00007fa22efd6aed  movaps xmm9, [rsp]
00007fa22efd6af2  add rsp, 0x30
00007fa22efd6af6  vmovaps xmm0, [rsp]
00007fa22efd6afb  vmovaps xmm1, [rsp+0x10]
00007fa22efd6b01  vmovaps xmm2, [rsp+0x20]
00007fa22efd6b07  vmovaps xmm3, [rsp+0x30]
00007fa22efd6b0d  vmovaps xmm4, [rsp+0x40]
00007fa22efd6b13  vmovaps xmm5, [rsp+0x50]
00007fa22efd6b19  vmovaps xmm6, [rsp+0x60]
00007fa22efd6b1f  vmovaps xmm7, [rsp+0x70]
00007fa22efd6b25  vmovaps xmm8, [rsp+0x80]
00007fa22efd6b2e  vmovaps xmm10, [rsp+0x90]
00007fa22efd6b37  vmovaps xmm11, [rsp+0xA0]
00007fa22efd6b40  vmovaps xmm12, [rsp+0xB0]
00007fa22efd6b49  vmovaps xmm13, [rsp+0xC0]
00007fa22efd6b52  vmovaps xmm14, [rsp+0xD0]
00007fa22efd6b5b  vmovaps xmm15, [rsp+0xE0]
00007fa22efd6b64  add rsp, 0xF0
00007fa22efd6b6b  pop r11
00007fa22efd6b6d  pop r10
00007fa22efd6b6f  pop r9
00007fa22efd6b71  pop r8
00007fa22efd6b73  pop rsi
00007fa22efd6b74  pop rdi
00007fa22efd6b75  pop rdx
00007fa22efd6b76  pop rcx
00007fa22efd6b77  pop rax
00007fa22efd6b78  add rsp, 0x08
00007fa22efd6b7c  jmp 0x00007FA22EFD59EC
00007fa22efd6b81  sub rsp, 0x08
00007fa22efd6b85  push rax
00007fa22efd6b86  push rcx
00007fa22efd6b87  push rdx
00007fa22efd6b88  push rdi
00007fa22efd6b89  push rsi
00007fa22efd6b8a  push r8
00007fa22efd6b8c  push r9
00007fa22efd6b8e  push r10
00007fa22efd6b90  push r11
00007fa22efd6b92  sub rsp, 0xF0
00007fa22efd6b99  vmovaps [rsp], xmm0
00007fa22efd6b9e  vmovaps [rsp+0x10], xmm1
00007fa22efd6ba4  vmovaps [rsp+0x20], xmm2
00007fa22efd6baa  vmovaps [rsp+0x30], xmm3
00007fa22efd6bb0  vmovaps [rsp+0x40], xmm4
00007fa22efd6bb6  vmovaps [rsp+0x50], xmm5
00007fa22efd6bbc  vmovaps [rsp+0x60], xmm6
00007fa22efd6bc2  vmovaps [rsp+0x70], xmm7
00007fa22efd6bc8  vmovaps [rsp+0x80], xmm8
00007fa22efd6bd1  vmovaps [rsp+0x90], xmm9
00007fa22efd6bda  vmovaps [rsp+0xA0], xmm11
00007fa22efd6be3  vmovaps [rsp+0xB0], xmm12
00007fa22efd6bec  vmovaps [rsp+0xC0], xmm13
00007fa22efd6bf5  vmovaps [rsp+0xD0], xmm14
00007fa22efd6bfe  vmovaps [rsp+0xE0], xmm15
00007fa22efd6c07  sub rsp, 0x30
00007fa22efd6c0b  movaps [rsp], xmm10
00007fa22efd6c10  movaps [rsp+0x10], xmm12
00007fa22efd6c16  movaps [rsp+0x20], xmm11
00007fa22efd6c1c  lea rdi, [rsp]
00007fa22efd6c20  mov esi, 0x00
00007fa22efd6c25  mov rax, 0x5E9D1A57D530
00007fa22efd6c2f  call rax
00007fa22efd6c31  movaps xmm10, [rsp]
00007fa22efd6c36  add rsp, 0x30
00007fa22efd6c3a  vmovaps xmm0, [rsp]
00007fa22efd6c3f  vmovaps xmm1, [rsp+0x10]
00007fa22efd6c45  vmovaps xmm2, [rsp+0x20]
00007fa22efd6c4b  vmovaps xmm3, [rsp+0x30]
00007fa22efd6c51  vmovaps xmm4, [rsp+0x40]
00007fa22efd6c57  vmovaps xmm5, [rsp+0x50]
00007fa22efd6c5d  vmovaps xmm6, [rsp+0x60]
00007fa22efd6c63  vmovaps xmm7, [rsp+0x70]
00007fa22efd6c69  vmovaps xmm8, [rsp+0x80]
00007fa22efd6c72  vmovaps xmm9, [rsp+0x90]
00007fa22efd6c7b  vmovaps xmm11, [rsp+0xA0]
00007fa22efd6c84  vmovaps xmm12, [rsp+0xB0]
00007fa22efd6c8d  vmovaps xmm13, [rsp+0xC0]
00007fa22efd6c96  vmovaps xmm14, [rsp+0xD0]
00007fa22efd6c9f  vmovaps xmm15, [rsp+0xE0]
00007fa22efd6ca8  add rsp, 0xF0
00007fa22efd6caf  pop r11
00007fa22efd6cb1  pop r10
00007fa22efd6cb3  pop r9
00007fa22efd6cb5  pop r8
00007fa22efd6cb7  pop rsi
00007fa22efd6cb8  pop rdi
00007fa22efd6cb9  pop rdx
00007fa22efd6cba  pop rcx
00007fa22efd6cbb  pop rax
00007fa22efd6cbc  add rsp, 0x08
00007fa22efd6cc0  jmp 0x00007FA22EFD5A06
00007fa22efd6cc5  sub rsp, 0x08
00007fa22efd6cc9  push rax
00007fa22efd6cca  push rcx
00007fa22efd6ccb  push rdx
00007fa22efd6ccc  push rdi
00007fa22efd6ccd  push rsi
00007fa22efd6cce  push r8
00007fa22efd6cd0  push r9
00007fa22efd6cd2  push r10
00007fa22efd6cd4  push r11
00007fa22efd6cd6  sub rsp, 0xF0
00007fa22efd6cdd  vmovaps [rsp], xmm0
00007fa22efd6ce2  vmovaps [rsp+0x10], xmm1
00007fa22efd6ce8  vmovaps [rsp+0x20], xmm2
00007fa22efd6cee  vmovaps [rsp+0x30], xmm3
00007fa22efd6cf4  vmovaps [rsp+0x40], xmm4
00007fa22efd6cfa  vmovaps [rsp+0x50], xmm5
00007fa22efd6d00  vmovaps [rsp+0x60], xmm7
00007fa22efd6d06  vmovaps [rsp+0x70], xmm8
00007fa22efd6d0c  vmovaps [rsp+0x80], xmm9
00007fa22efd6d15  vmovaps [rsp+0x90], xmm10
00007fa22efd6d1e  vmovaps [rsp+0xA0], xmm11
00007fa22efd6d27  vmovaps [rsp+0xB0], xmm12
00007fa22efd6d30  vmovaps [rsp+0xC0], xmm13
00007fa22efd6d39  vmovaps [rsp+0xD0], xmm14
00007fa22efd6d42  vmovaps [rsp+0xE0], xmm15
00007fa22efd6d4b  sub rsp, 0x30
00007fa22efd6d4f  movaps [rsp], xmm6
00007fa22efd6d53  movaps [rsp+0x10], xmm12
00007fa22efd6d59  movaps [rsp+0x20], xmm11
00007fa22efd6d5f  lea rdi, [rsp]
00007fa22efd6d63  mov esi, 0x00
00007fa22efd6d68  mov rax, 0x5E9D1A57D530
00007fa22efd6d72  call rax
00007fa22efd6d74  movaps xmm6, [rsp]
00007fa22efd6d78  add rsp, 0x30
00007fa22efd6d7c  vmovaps xmm0, [rsp]
00007fa22efd6d81  vmovaps xmm1, [rsp+0x10]
00007fa22efd6d87  vmovaps xmm2, [rsp+0x20]
00007fa22efd6d8d  vmovaps xmm3, [rsp+0x30]
00007fa22efd6d93  vmovaps xmm4, [rsp+0x40]
00007fa22efd6d99  vmovaps xmm5, [rsp+0x50]
00007fa22efd6d9f  vmovaps xmm7, [rsp+0x60]
00007fa22efd6da5  vmovaps xmm8, [rsp+0x70]
00007fa22efd6dab  vmovaps xmm9, [rsp+0x80]
00007fa22efd6db4  vmovaps xmm10, [rsp+0x90]
00007fa22efd6dbd  vmovaps xmm11, [rsp+0xA0]
00007fa22efd6dc6  vmovaps xmm12, [rsp+0xB0]
00007fa22efd6dcf  vmovaps xmm13, [rsp+0xC0]
00007fa22efd6dd8  vmovaps xmm14, [rsp+0xD0]
00007fa22efd6de1  vmovaps xmm15, [rsp+0xE0]
00007fa22efd6dea  add rsp, 0xF0
00007fa22efd6df1  pop r11
00007fa22efd6df3  pop r10
00007fa22efd6df5  pop r9
00007fa22efd6df7  pop r8
00007fa22efd6df9  pop rsi
00007fa22efd6dfa  pop rdi
00007fa22efd6dfb  pop rdx
00007fa22efd6dfc  pop rcx
00007fa22efd6dfd  pop rax
00007fa22efd6dfe  add rsp, 0x08
00007fa22efd6e02  jmp 0x00007FA22EFD5A27
00007fa22efd6e07  sub rsp, 0x08
00007fa22efd6e0b  push rax
00007fa22efd6e0c  push rcx
00007fa22efd6e0d  push rdx
00007fa22efd6e0e  push rdi
00007fa22efd6e0f  push rsi
00007fa22efd6e10  push r8
00007fa22efd6e12  push r9
00007fa22efd6e14  push r10
00007fa22efd6e16  push r11
00007fa22efd6e18  sub rsp, 0xF0
00007fa22efd6e1f  vmovaps [rsp], xmm0
00007fa22efd6e24  vmovaps [rsp+0x10], xmm1
00007fa22efd6e2a  vmovaps [rsp+0x20], xmm2
00007fa22efd6e30  vmovaps [rsp+0x30], xmm4
00007fa22efd6e36  vmovaps [rsp+0x40], xmm5
00007fa22efd6e3c  vmovaps [rsp+0x50], xmm6
00007fa22efd6e42  vmovaps [rsp+0x60], xmm7
00007fa22efd6e48  vmovaps [rsp+0x70], xmm8
00007fa22efd6e4e  vmovaps [rsp+0x80], xmm9
00007fa22efd6e57  vmovaps [rsp+0x90], xmm10
00007fa22efd6e60  vmovaps [rsp+0xA0], xmm11
00007fa22efd6e69  vmovaps [rsp+0xB0], xmm12
00007fa22efd6e72  vmovaps [rsp+0xC0], xmm13
00007fa22efd6e7b  vmovaps [rsp+0xD0], xmm14
00007fa22efd6e84  vmovaps [rsp+0xE0], xmm15
00007fa22efd6e8d  sub rsp, 0x30
00007fa22efd6e91  movaps [rsp], xmm3
00007fa22efd6e95  movaps [rsp+0x10], xmm5
00007fa22efd6e9a  movaps [rsp+0x20], xmm4
00007fa22efd6e9f  lea rdi, [rsp]
00007fa22efd6ea3  mov esi, 0x00
00007fa22efd6ea8  mov rax, 0x5E9D1A57D530
00007fa22efd6eb2  call rax
00007fa22efd6eb4  movaps xmm3, [rsp]
00007fa22efd6eb8  add rsp, 0x30
00007fa22efd6ebc  vmovaps xmm0, [rsp]
00007fa22efd6ec1  vmovaps xmm1, [rsp+0x10]
00007fa22efd6ec7  vmovaps xmm2, [rsp+0x20]
00007fa22efd6ecd  vmovaps xmm4, [rsp+0x30]
00007fa22efd6ed3  vmovaps xmm5, [rsp+0x40]
00007fa22efd6ed9  vmovaps xmm6, [rsp+0x50]
00007fa22efd6edf  vmovaps xmm7, [rsp+0x60]
00007fa22efd6ee5  vmovaps xmm8, [rsp+0x70]
00007fa22efd6eeb  vmovaps xmm9, [rsp+0x80]
00007fa22efd6ef4  vmovaps xmm10, [rsp+0x90]
00007fa22efd6efd  vmovaps xmm11, [rsp+0xA0]
00007fa22efd6f06  vmovaps xmm12, [rsp+0xB0]
00007fa22efd6f0f  vmovaps xmm13, [rsp+0xC0]
00007fa22efd6f18  vmovaps xmm14, [rsp+0xD0]
00007fa22efd6f21  vmovaps xmm15, [rsp+0xE0]
00007fa22efd6f2a  add rsp, 0xF0
00007fa22efd6f31  pop r11
00007fa22efd6f33  pop r10
00007fa22efd6f35  pop r9
00007fa22efd6f37  pop r8
00007fa22efd6f39  pop rsi
00007fa22efd6f3a  pop rdi
00007fa22efd6f3b  pop rdx
00007fa22efd6f3c  pop rcx
00007fa22efd6f3d  pop rax
00007fa22efd6f3e  add rsp, 0x08
00007fa22efd6f42  jmp 0x00007FA22EFD5A88
00007fa22efd6f47  sub rsp, 0x08
00007fa22efd6f4b  push rax
00007fa22efd6f4c  push rcx
00007fa22efd6f4d  push rdx
00007fa22efd6f4e  push rdi
00007fa22efd6f4f  push rsi
00007fa22efd6f50  push r8
00007fa22efd6f52  push r9
00007fa22efd6f54  push r10
00007fa22efd6f56  push r11
00007fa22efd6f58  sub rsp, 0xF0
00007fa22efd6f5f  vmovaps [rsp], xmm0
00007fa22efd6f64  vmovaps [rsp+0x10], xmm1
00007fa22efd6f6a  vmovaps [rsp+0x20], xmm2
00007fa22efd6f70  vmovaps [rsp+0x30], xmm3
00007fa22efd6f76  vmovaps [rsp+0x40], xmm4
00007fa22efd6f7c  vmovaps [rsp+0x50], xmm6
00007fa22efd6f82  vmovaps [rsp+0x60], xmm7
00007fa22efd6f88  vmovaps [rsp+0x70], xmm8
00007fa22efd6f8e  vmovaps [rsp+0x80], xmm9
00007fa22efd6f97  vmovaps [rsp+0x90], xmm10
00007fa22efd6fa0  vmovaps [rsp+0xA0], xmm11
00007fa22efd6fa9  vmovaps [rsp+0xB0], xmm12
00007fa22efd6fb2  vmovaps [rsp+0xC0], xmm13
00007fa22efd6fbb  vmovaps [rsp+0xD0], xmm14
00007fa22efd6fc4  vmovaps [rsp+0xE0], xmm15
00007fa22efd6fcd  sub rsp, 0x30
00007fa22efd6fd1  movaps [rsp], xmm5
00007fa22efd6fd5  movaps [rsp+0x10], xmm8
00007fa22efd6fdb  movaps [rsp+0x20], xmm15
00007fa22efd6fe1  lea rdi, [rsp]
00007fa22efd6fe5  mov esi, 0x00
00007fa22efd6fea  mov rax, 0x5E9D1A57D530
00007fa22efd6ff4  call rax
00007fa22efd6ff6  movaps xmm5, [rsp]
00007fa22efd6ffa  add rsp, 0x30
00007fa22efd6ffe  vmovaps xmm0, [rsp]
00007fa22efd7003  vmovaps xmm1, [rsp+0x10]
00007fa22efd7009  vmovaps xmm2, [rsp+0x20]
00007fa22efd700f  vmovaps xmm3, [rsp+0x30]
00007fa22efd7015  vmovaps xmm4, [rsp+0x40]
00007fa22efd701b  vmovaps xmm6, [rsp+0x50]
00007fa22efd7021  vmovaps xmm7, [rsp+0x60]
00007fa22efd7027  vmovaps xmm8, [rsp+0x70]
00007fa22efd702d  vmovaps xmm9, [rsp+0x80]
00007fa22efd7036  vmovaps xmm10, [rsp+0x90]
00007fa22efd703f  vmovaps xmm11, [rsp+0xA0]
00007fa22efd7048  vmovaps xmm12, [rsp+0xB0]
00007fa22efd7051  vmovaps xmm13, [rsp+0xC0]
00007fa22efd705a  vmovaps xmm14, [rsp+0xD0]
00007fa22efd7063  vmovaps xmm15, [rsp+0xE0]
00007fa22efd706c  add rsp, 0xF0
00007fa22efd7073  pop r11
00007fa22efd7075  pop r10
00007fa22efd7077  pop r9
00007fa22efd7079  pop r8
00007fa22efd707b  pop rsi
00007fa22efd707c  pop rdi
00007fa22efd707d  pop rdx
00007fa22efd707e  pop rcx
00007fa22efd707f  pop rax
00007fa22efd7080  add rsp, 0x08
00007fa22efd7084  jmp 0x00007FA22EFD5AC0
00007fa22efd7089  sub rsp, 0x08
00007fa22efd708d  push rax
00007fa22efd708e  push rcx
00007fa22efd708f  push rdx
00007fa22efd7090  push rdi
00007fa22efd7091  push rsi
00007fa22efd7092  push r8
00007fa22efd7094  push r9
00007fa22efd7096  push r10
00007fa22efd7098  push r11
00007fa22efd709a  sub rsp, 0xF0
00007fa22efd70a1  vmovaps [rsp], xmm0
00007fa22efd70a6  vmovaps [rsp+0x10], xmm1
00007fa22efd70ac  vmovaps [rsp+0x20], xmm2
00007fa22efd70b2  vmovaps [rsp+0x30], xmm3
00007fa22efd70b8  vmovaps [rsp+0x40], xmm5
00007fa22efd70be  vmovaps [rsp+0x50], xmm6
00007fa22efd70c4  vmovaps [rsp+0x60], xmm7
00007fa22efd70ca  vmovaps [rsp+0x70], xmm8
00007fa22efd70d0  vmovaps [rsp+0x80], xmm9
00007fa22efd70d9  vmovaps [rsp+0x90], xmm10
00007fa22efd70e2  vmovaps [rsp+0xA0], xmm11
00007fa22efd70eb  vmovaps [rsp+0xB0], xmm12
00007fa22efd70f4  vmovaps [rsp+0xC0], xmm13
00007fa22efd70fd  vmovaps [rsp+0xD0], xmm14
00007fa22efd7106  vmovaps [rsp+0xE0], xmm15
00007fa22efd710f  sub rsp, 0x30
00007fa22efd7113  movaps [rsp], xmm4
00007fa22efd7117  movaps [rsp+0x10], xmm9
00007fa22efd711d  movaps [rsp+0x20], xmm8
00007fa22efd7123  lea rdi, [rsp]
00007fa22efd7127  mov esi, 0x00
00007fa22efd712c  mov rax, 0x5E9D1A57D530
00007fa22efd7136  call rax
00007fa22efd7138  movaps xmm4, [rsp]
00007fa22efd713c  add rsp, 0x30
00007fa22efd7140  vmovaps xmm0, [rsp]
00007fa22efd7145  vmovaps xmm1, [rsp+0x10]
00007fa22efd714b  vmovaps xmm2, [rsp+0x20]
00007fa22efd7151  vmovaps xmm3, [rsp+0x30]
00007fa22efd7157  vmovaps xmm5, [rsp+0x40]
00007fa22efd715d  vmovaps xmm6, [rsp+0x50]
00007fa22efd7163  vmovaps xmm7, [rsp+0x60]
00007fa22efd7169  vmovaps xmm8, [rsp+0x70]
00007fa22efd716f  vmovaps xmm9, [rsp+0x80]
00007fa22efd7178  vmovaps xmm10, [rsp+0x90]
00007fa22efd7181  vmovaps xmm11, [rsp+0xA0]
00007fa22efd718a  vmovaps xmm12, [rsp+0xB0]
00007fa22efd7193  vmovaps xmm13, [rsp+0xC0]
00007fa22efd719c  vmovaps xmm14, [rsp+0xD0]
00007fa22efd71a5  vmovaps xmm15, [rsp+0xE0]
00007fa22efd71ae  add rsp, 0xF0
00007fa22efd71b5  pop r11
00007fa22efd71b7  pop r10
00007fa22efd71b9  pop r9
00007fa22efd71bb  pop r8
00007fa22efd71bd  pop rsi
00007fa22efd71be  pop rdi
00007fa22efd71bf  pop rdx
00007fa22efd71c0  pop rcx
00007fa22efd71c1  pop rax
00007fa22efd71c2  add rsp, 0x08
00007fa22efd71c6  jmp 0x00007FA22EFD5AE1
00007fa22efd71cb  sub rsp, 0x08
00007fa22efd71cf  push rax
00007fa22efd71d0  push rcx
00007fa22efd71d1  push rdx
00007fa22efd71d2  push rdi
00007fa22efd71d3  push rsi
00007fa22efd71d4  push r8
00007fa22efd71d6  push r9
00007fa22efd71d8  push r10
00007fa22efd71da  push r11
00007fa22efd71dc  sub rsp, 0xF0
00007fa22efd71e3  vmovaps [rsp], xmm0
00007fa22efd71e8  vmovaps [rsp+0x10], xmm1
00007fa22efd71ee  vmovaps [rsp+0x20], xmm2
00007fa22efd71f4  vmovaps [rsp+0x30], xmm3
00007fa22efd71fa  vmovaps [rsp+0x40], xmm4
00007fa22efd7200  vmovaps [rsp+0x50], xmm5
00007fa22efd7206  vmovaps [rsp+0x60], xmm6
00007fa22efd720c  vmovaps [rsp+0x70], xmm7
00007fa22efd7212  vmovaps [rsp+0x80], xmm8
00007fa22efd721b  vmovaps [rsp+0x90], xmm10
00007fa22efd7224  vmovaps [rsp+0xA0], xmm11
00007fa22efd722d  vmovaps [rsp+0xB0], xmm12
00007fa22efd7236  vmovaps [rsp+0xC0], xmm13
00007fa22efd723f  vmovaps [rsp+0xD0], xmm14
00007fa22efd7248  vmovaps [rsp+0xE0], xmm15
00007fa22efd7251  sub rsp, 0x30
00007fa22efd7255  movaps [rsp], xmm9
00007fa22efd725a  movaps [rsp+0x10], xmm10
00007fa22efd7260  movaps [rsp+0x20], xmm8
00007fa22efd7266  lea rdi, [rsp]
00007fa22efd726a  mov esi, 0x00
00007fa22efd726f  mov rax, 0x5E9D1A57D530
00007fa22efd7279  call rax
00007fa22efd727b  movaps xmm9, [rsp]
00007fa22efd7280  add rsp, 0x30
00007fa22efd7284  vmovaps xmm0, [rsp]
00007fa22efd7289  vmovaps xmm1, [rsp+0x10]
00007fa22efd728f  vmovaps xmm2, [rsp+0x20]
00007fa22efd7295  vmovaps xmm3, [rsp+0x30]
00007fa22efd729b  vmovaps xmm4, [rsp+0x40]
00007fa22efd72a1  vmovaps xmm5, [rsp+0x50]
00007fa22efd72a7  vmovaps xmm6, [rsp+0x60]
00007fa22efd72ad  vmovaps xmm7, [rsp+0x70]
00007fa22efd72b3  vmovaps xmm8, [rsp+0x80]
00007fa22efd72bc  vmovaps xmm10, [rsp+0x90]
00007fa22efd72c5  vmovaps xmm11, [rsp+0xA0]
00007fa22efd72ce  vmovaps xmm12, [rsp+0xB0]
00007fa22efd72d7  vmovaps xmm13, [rsp+0xC0]
00007fa22efd72e0  vmovaps xmm14, [rsp+0xD0]
00007fa22efd72e9  vmovaps xmm15, [rsp+0xE0]
00007fa22efd72f2  add rsp, 0xF0
00007fa22efd72f9  pop r11
00007fa22efd72fb  pop r10
00007fa22efd72fd  pop r9
00007fa22efd72ff  pop r8
00007fa22efd7301  pop rsi
00007fa22efd7302  pop rdi
00007fa22efd7303  pop rdx
00007fa22efd7304  pop rcx
00007fa22efd7305  pop rax
00007fa22efd7306  add rsp, 0x08
00007fa22efd730a  jmp 0x00007FA22EFD5AFB
00007fa22efd730f  call 0x00007FA22EED64F0
00007fa22efd7314  jmp 0x00007FA22EFD5C15
00007fa22efd7319  call 0x00007FA22EED64F0
00007fa22efd731e  jmp 0x00007FA22EFD5C2B
00007fa22efd7323  sub rsp, 0x08
00007fa22efd7327  push rax
00007fa22efd7328  push rcx
00007fa22efd7329  push rdx
00007fa22efd732a  push rdi
00007fa22efd732b  push rsi
00007fa22efd732c  push r8
00007fa22efd732e  push r9
00007fa22efd7330  push r10
00007fa22efd7332  push r11
00007fa22efd7334  sub rsp, 0xF0
00007fa22efd733b  vmovaps [rsp], xmm0
00007fa22efd7340  vmovaps [rsp+0x10], xmm2
00007fa22efd7346  vmovaps [rsp+0x20], xmm3
00007fa22efd734c  vmovaps [rsp+0x30], xmm4
00007fa22efd7352  vmovaps [rsp+0x40], xmm5
00007fa22efd7358  vmovaps [rsp+0x50], xmm6
00007fa22efd735e  vmovaps [rsp+0x60], xmm7
00007fa22efd7364  vmovaps [rsp+0x70], xmm8
00007fa22efd736a  vmovaps [rsp+0x80], xmm9
00007fa22efd7373  vmovaps [rsp+0x90], xmm10
00007fa22efd737c  vmovaps [rsp+0xA0], xmm11
00007fa22efd7385  vmovaps [rsp+0xB0], xmm12
00007fa22efd738e  vmovaps [rsp+0xC0], xmm13
00007fa22efd7397  vmovaps [rsp+0xD0], xmm14
00007fa22efd73a0  vmovaps [rsp+0xE0], xmm15
00007fa22efd73a9  sub rsp, 0x30
00007fa22efd73ad  movaps [rsp], xmm1
00007fa22efd73b1  movaps [rsp+0x10], xmm6
00007fa22efd73b6  movaps [rsp+0x20], xmm15
00007fa22efd73bc  lea rdi, [rsp]
00007fa22efd73c0  mov esi, 0x00
00007fa22efd73c5  mov rax, 0x5E9D1A57D530
00007fa22efd73cf  call rax
00007fa22efd73d1  movaps xmm1, [rsp]
00007fa22efd73d5  add rsp, 0x30
00007fa22efd73d9  vmovaps xmm0, [rsp]
00007fa22efd73de  vmovaps xmm2, [rsp+0x10]
00007fa22efd73e4  vmovaps xmm3, [rsp+0x20]
00007fa22efd73ea  vmovaps xmm4, [rsp+0x30]
00007fa22efd73f0  vmovaps xmm5, [rsp+0x40]
00007fa22efd73f6  vmovaps xmm6, [rsp+0x50]
00007fa22efd73fc  vmovaps xmm7, [rsp+0x60]
00007fa22efd7402  vmovaps xmm8, [rsp+0x70]
00007fa22efd7408  vmovaps xmm9, [rsp+0x80]
00007fa22efd7411  vmovaps xmm10, [rsp+0x90]
00007fa22efd741a  vmovaps xmm11, [rsp+0xA0]
00007fa22efd7423  vmovaps xmm12, [rsp+0xB0]
00007fa22efd742c  vmovaps xmm13, [rsp+0xC0]
00007fa22efd7435  vmovaps xmm14, [rsp+0xD0]
00007fa22efd743e  vmovaps xmm15, [rsp+0xE0]
00007fa22efd7447  add rsp, 0xF0
00007fa22efd744e  pop r11
00007fa22efd7450  pop r10
00007fa22efd7452  pop r9
00007fa22efd7454  pop r8
00007fa22efd7456  pop rsi
00007fa22efd7457  pop rdi
00007fa22efd7458  pop rdx
00007fa22efd7459  pop rcx
00007fa22efd745a  pop rax
00007fa22efd745b  add rsp, 0x08
00007fa22efd745f  jmp 0x00007FA22EFD5C68
00007fa22efd7464  call 0x00007FA22EEE5820
00007fa22efd7469  jmp 0x00007FA22EFD5C75
00007fa22efd746e  sub rsp, 0x08
00007fa22efd7472  push rax
00007fa22efd7473  push rcx
00007fa22efd7474  push rdx
00007fa22efd7475  push rdi
00007fa22efd7476  push rsi
00007fa22efd7477  push r8
00007fa22efd7479  push r9
00007fa22efd747b  push r10
00007fa22efd747d  push r11
00007fa22efd747f  sub rsp, 0xF0
00007fa22efd7486  vmovaps [rsp], xmm0
00007fa22efd748b  vmovaps [rsp+0x10], xmm1
00007fa22efd7491  vmovaps [rsp+0x20], xmm2
00007fa22efd7497  vmovaps [rsp+0x30], xmm3
00007fa22efd749d  vmovaps [rsp+0x40], xmm4
00007fa22efd74a3  vmovaps [rsp+0x50], xmm5
00007fa22efd74a9  vmovaps [rsp+0x60], xmm6
00007fa22efd74af  vmovaps [rsp+0x70], xmm7
00007fa22efd74b5  vmovaps [rsp+0x80], xmm8
00007fa22efd74be  vmovaps [rsp+0x90], xmm9
00007fa22efd74c7  vmovaps [rsp+0xA0], xmm10
00007fa22efd74d0  vmovaps [rsp+0xB0], xmm11
00007fa22efd74d9  vmovaps [rsp+0xC0], xmm12
00007fa22efd74e2  vmovaps [rsp+0xD0], xmm13
00007fa22efd74eb  vmovaps [rsp+0xE0], xmm15
00007fa22efd74f4  sub rsp, 0x30
00007fa22efd74f8  movaps [rsp], xmm14
00007fa22efd74fd  movaps [rsp+0x10], xmm4
00007fa22efd7502  movaps [rsp+0x20], xmm3
00007fa22efd7507  lea rdi, [rsp]
00007fa22efd750b  mov esi, 0x00
00007fa22efd7510  mov rax, 0x5E9D1A57D530
00007fa22efd751a  call rax
00007fa22efd751c  movaps xmm14, [rsp]
00007fa22efd7521  add rsp, 0x30
00007fa22efd7525  vmovaps xmm0, [rsp]
00007fa22efd752a  vmovaps xmm1, [rsp+0x10]
00007fa22efd7530  vmovaps xmm2, [rsp+0x20]
00007fa22efd7536  vmovaps xmm3, [rsp+0x30]
00007fa22efd753c  vmovaps xmm4, [rsp+0x40]
00007fa22efd7542  vmovaps xmm5, [rsp+0x50]
00007fa22efd7548  vmovaps xmm6, [rsp+0x60]
00007fa22efd754e  vmovaps xmm7, [rsp+0x70]
00007fa22efd7554  vmovaps xmm8, [rsp+0x80]
00007fa22efd755d  vmovaps xmm9, [rsp+0x90]
00007fa22efd7566  vmovaps xmm10, [rsp+0xA0]
00007fa22efd756f  vmovaps xmm11, [rsp+0xB0]
00007fa22efd7578  vmovaps xmm12, [rsp+0xC0]
00007fa22efd7581  vmovaps xmm13, [rsp+0xD0]
00007fa22efd758a  vmovaps xmm15, [rsp+0xE0]
00007fa22efd7593  add rsp, 0xF0
00007fa22efd759a  pop r11
00007fa22efd759c  pop r10
00007fa22efd759e  pop r9
00007fa22efd75a0  pop r8
00007fa22efd75a2  pop rsi
00007fa22efd75a3  pop rdi
00007fa22efd75a4  pop rdx
00007fa22efd75a5  pop rcx
00007fa22efd75a6  pop rax
00007fa22efd75a7  add rsp, 0x08
00007fa22efd75ab  jmp 0x00007FA22EFD5C8F
00007fa22efd75b0  sub rsp, 0x08
00007fa22efd75b4  push rax
00007fa22efd75b5  push rcx
00007fa22efd75b6  push rdx
00007fa22efd75b7  push rdi
00007fa22efd75b8  push rsi
00007fa22efd75b9  push r8
00007fa22efd75bb  push r9
00007fa22efd75bd  push r10
00007fa22efd75bf  push r11
00007fa22efd75c1  sub rsp, 0xF0
00007fa22efd75c8  vmovaps [rsp], xmm0
00007fa22efd75cd  vmovaps [rsp+0x10], xmm1
00007fa22efd75d3  vmovaps [rsp+0x20], xmm2
00007fa22efd75d9  vmovaps [rsp+0x30], xmm3
00007fa22efd75df  vmovaps [rsp+0x40], xmm4
00007fa22efd75e5  vmovaps [rsp+0x50], xmm5
00007fa22efd75eb  vmovaps [rsp+0x60], xmm7
00007fa22efd75f1  vmovaps [rsp+0x70], xmm8
00007fa22efd75f7  vmovaps [rsp+0x80], xmm9
00007fa22efd7600  vmovaps [rsp+0x90], xmm10
00007fa22efd7609  vmovaps [rsp+0xA0], xmm11
00007fa22efd7612  vmovaps [rsp+0xB0], xmm12
00007fa22efd761b  vmovaps [rsp+0xC0], xmm13
00007fa22efd7624  vmovaps [rsp+0xD0], xmm14
00007fa22efd762d  vmovaps [rsp+0xE0], xmm15
00007fa22efd7636  sub rsp, 0x30
00007fa22efd763a  movaps [rsp], xmm6
00007fa22efd763e  movaps [rsp+0x10], xmm9
00007fa22efd7644  movaps [rsp+0x20], xmm7
00007fa22efd7649  lea rdi, [rsp]
00007fa22efd764d  mov esi, 0x00
00007fa22efd7652  mov rax, 0x5E9D1A57D530
00007fa22efd765c  call rax
00007fa22efd765e  movaps xmm6, [rsp]
00007fa22efd7662  add rsp, 0x30
00007fa22efd7666  vmovaps xmm0, [rsp]
00007fa22efd766b  vmovaps xmm1, [rsp+0x10]
00007fa22efd7671  vmovaps xmm2, [rsp+0x20]
00007fa22efd7677  vmovaps xmm3, [rsp+0x30]
00007fa22efd767d  vmovaps xmm4, [rsp+0x40]
00007fa22efd7683  vmovaps xmm5, [rsp+0x50]
00007fa22efd7689  vmovaps xmm7, [rsp+0x60]
00007fa22efd768f  vmovaps xmm8, [rsp+0x70]
00007fa22efd7695  vmovaps xmm9, [rsp+0x80]
00007fa22efd769e  vmovaps xmm10, [rsp+0x90]
00007fa22efd76a7  vmovaps xmm11, [rsp+0xA0]
00007fa22efd76b0  vmovaps xmm12, [rsp+0xB0]
00007fa22efd76b9  vmovaps xmm13, [rsp+0xC0]
00007fa22efd76c2  vmovaps xmm14, [rsp+0xD0]
00007fa22efd76cb  vmovaps xmm15, [rsp+0xE0]
00007fa22efd76d4  add rsp, 0xF0
00007fa22efd76db  pop r11
00007fa22efd76dd  pop r10
00007fa22efd76df  pop r9
00007fa22efd76e1  pop r8
00007fa22efd76e3  pop rsi
00007fa22efd76e4  pop rdi
00007fa22efd76e5  pop rdx
00007fa22efd76e6  pop rcx
00007fa22efd76e7  pop rax
00007fa22efd76e8  add rsp, 0x08
00007fa22efd76ec  jmp 0x00007FA22EFD5CA7
00007fa22efd76f1  sub rsp, 0x08
00007fa22efd76f5  push rax
00007fa22efd76f6  push rcx
00007fa22efd76f7  push rdx
00007fa22efd76f8  push rdi
00007fa22efd76f9  push rsi
00007fa22efd76fa  push r8
00007fa22efd76fc  push r9
00007fa22efd76fe  push r10
00007fa22efd7700  push r11
00007fa22efd7702  sub rsp, 0xF0
00007fa22efd7709  vmovaps [rsp], xmm0
00007fa22efd770e  vmovaps [rsp+0x10], xmm1
00007fa22efd7714  vmovaps [rsp+0x20], xmm2
00007fa22efd771a  vmovaps [rsp+0x30], xmm3
00007fa22efd7720  vmovaps [rsp+0x40], xmm4
00007fa22efd7726  vmovaps [rsp+0x50], xmm5
00007fa22efd772c  vmovaps [rsp+0x60], xmm6
00007fa22efd7732  vmovaps [rsp+0x70], xmm8
00007fa22efd7738  vmovaps [rsp+0x80], xmm9
00007fa22efd7741  vmovaps [rsp+0x90], xmm10
00007fa22efd774a  vmovaps [rsp+0xA0], xmm11
00007fa22efd7753  vmovaps [rsp+0xB0], xmm12
00007fa22efd775c  vmovaps [rsp+0xC0], xmm13
00007fa22efd7765  vmovaps [rsp+0xD0], xmm14
00007fa22efd776e  vmovaps [rsp+0xE0], xmm15
00007fa22efd7777  sub rsp, 0x30
00007fa22efd777b  movaps [rsp], xmm7
00007fa22efd777f  movaps [rsp+0x10], xmm4
00007fa22efd7784  movaps [rsp+0x20], xmm9
00007fa22efd778a  lea rdi, [rsp]
00007fa22efd778e  mov esi, 0x00
00007fa22efd7793  mov rax, 0x5E9D1A57D530
00007fa22efd779d  call rax
00007fa22efd779f  movaps xmm7, [rsp]
00007fa22efd77a3  add rsp, 0x30
00007fa22efd77a7  vmovaps xmm0, [rsp]
00007fa22efd77ac  vmovaps xmm1, [rsp+0x10]
00007fa22efd77b2  vmovaps xmm2, [rsp+0x20]
00007fa22efd77b8  vmovaps xmm3, [rsp+0x30]
00007fa22efd77be  vmovaps xmm4, [rsp+0x40]
00007fa22efd77c4  vmovaps xmm5, [rsp+0x50]
00007fa22efd77ca  vmovaps xmm6, [rsp+0x60]
00007fa22efd77d0  vmovaps xmm8, [rsp+0x70]
00007fa22efd77d6  vmovaps xmm9, [rsp+0x80]
00007fa22efd77df  vmovaps xmm10, [rsp+0x90]
00007fa22efd77e8  vmovaps xmm11, [rsp+0xA0]
00007fa22efd77f1  vmovaps xmm12, [rsp+0xB0]
00007fa22efd77fa  vmovaps xmm13, [rsp+0xC0]
00007fa22efd7803  vmovaps xmm14, [rsp+0xD0]
00007fa22efd780c  vmovaps xmm15, [rsp+0xE0]
00007fa22efd7815  add rsp, 0xF0
00007fa22efd781c  pop r11
00007fa22efd781e  pop r10
00007fa22efd7820  pop r9
00007fa22efd7822  pop r8
00007fa22efd7824  pop rsi
00007fa22efd7825  pop rdi
00007fa22efd7826  pop rdx
00007fa22efd7827  pop rcx
00007fa22efd7828  pop rax
00007fa22efd7829  add rsp, 0x08
00007fa22efd782d  jmp 0x00007FA22EFD5CD4
00007fa22efd7832  sub rsp, 0x08
00007fa22efd7836  push rax
00007fa22efd7837  push rcx
00007fa22efd7838  push rdx
00007fa22efd7839  push rdi
00007fa22efd783a  push rsi
00007fa22efd783b  push r8
00007fa22efd783d  push r9
00007fa22efd783f  push r10
00007fa22efd7841  push r11
00007fa22efd7843  sub rsp, 0xF0
00007fa22efd784a  vmovaps [rsp], xmm0
00007fa22efd784f  vmovaps [rsp+0x10], xmm1
00007fa22efd7855  vmovaps [rsp+0x20], xmm2
00007fa22efd785b  vmovaps [rsp+0x30], xmm3
00007fa22efd7861  vmovaps [rsp+0x40], xmm5
00007fa22efd7867  vmovaps [rsp+0x50], xmm6
00007fa22efd786d  vmovaps [rsp+0x60], xmm7
00007fa22efd7873  vmovaps [rsp+0x70], xmm8
00007fa22efd7879  vmovaps [rsp+0x80], xmm9
00007fa22efd7882  vmovaps [rsp+0x90], xmm10
00007fa22efd788b  vmovaps [rsp+0xA0], xmm11
00007fa22efd7894  vmovaps [rsp+0xB0], xmm12
00007fa22efd789d  vmovaps [rsp+0xC0], xmm13
00007fa22efd78a6  vmovaps [rsp+0xD0], xmm14
00007fa22efd78af  vmovaps [rsp+0xE0], xmm15
00007fa22efd78b8  sub rsp, 0x30
00007fa22efd78bc  movaps [rsp], xmm4
00007fa22efd78c0  movaps [rsp+0x10], xmm15
00007fa22efd78c6  movaps [rsp+0x20], xmm9
00007fa22efd78cc  lea rdi, [rsp]
00007fa22efd78d0  mov esi, 0x00
00007fa22efd78d5  mov rax, 0x5E9D1A57D530
00007fa22efd78df  call rax
00007fa22efd78e1  movaps xmm4, [rsp]
00007fa22efd78e5  add rsp, 0x30
00007fa22efd78e9  vmovaps xmm0, [rsp]
00007fa22efd78ee  vmovaps xmm1, [rsp+0x10]
00007fa22efd78f4  vmovaps xmm2, [rsp+0x20]
00007fa22efd78fa  vmovaps xmm3, [rsp+0x30]
00007fa22efd7900  vmovaps xmm5, [rsp+0x40]
00007fa22efd7906  vmovaps xmm6, [rsp+0x50]
00007fa22efd790c  vmovaps xmm7, [rsp+0x60]
00007fa22efd7912  vmovaps xmm8, [rsp+0x70]
00007fa22efd7918  vmovaps xmm9, [rsp+0x80]
00007fa22efd7921  vmovaps xmm10, [rsp+0x90]
00007fa22efd792a  vmovaps xmm11, [rsp+0xA0]
00007fa22efd7933  vmovaps xmm12, [rsp+0xB0]
00007fa22efd793c  vmovaps xmm13, [rsp+0xC0]
00007fa22efd7945  vmovaps xmm14, [rsp+0xD0]
00007fa22efd794e  vmovaps xmm15, [rsp+0xE0]
00007fa22efd7957  add rsp, 0xF0
00007fa22efd795e  pop r11
00007fa22efd7960  pop r10
00007fa22efd7962  pop r9
00007fa22efd7964  pop r8
00007fa22efd7966  pop rsi
00007fa22efd7967  pop rdi
00007fa22efd7968  pop rdx
00007fa22efd7969  pop rcx
00007fa22efd796a  pop rax
00007fa22efd796b  add rsp, 0x08
00007fa22efd796f  jmp 0x00007FA22EFD5CF9
00007fa22efd7974  call 0x00007FA22EEE5820
00007fa22efd7979  jmp 0x00007FA22EFD5D06
00007fa22efd797e  sub rsp, 0x08
00007fa22efd7982  push rax
00007fa22efd7983  push rcx
00007fa22efd7984  push rdx
00007fa22efd7985  push rdi
00007fa22efd7986  push rsi
00007fa22efd7987  push r8
00007fa22efd7989  push r9
00007fa22efd798b  push r10
00007fa22efd798d  push r11
00007fa22efd798f  sub rsp, 0xF0
00007fa22efd7996  vmovaps [rsp], xmm0
00007fa22efd799b  vmovaps [rsp+0x10], xmm1
00007fa22efd79a1  vmovaps [rsp+0x20], xmm2
00007fa22efd79a7  vmovaps [rsp+0x30], xmm4
00007fa22efd79ad  vmovaps [rsp+0x40], xmm5
00007fa22efd79b3  vmovaps [rsp+0x50], xmm6
00007fa22efd79b9  vmovaps [rsp+0x60], xmm7
00007fa22efd79bf  vmovaps [rsp+0x70], xmm8
00007fa22efd79c5  vmovaps [rsp+0x80], xmm9
00007fa22efd79ce  vmovaps [rsp+0x90], xmm10
00007fa22efd79d7  vmovaps [rsp+0xA0], xmm11
00007fa22efd79e0  vmovaps [rsp+0xB0], xmm12
00007fa22efd79e9  vmovaps [rsp+0xC0], xmm13
00007fa22efd79f2  vmovaps [rsp+0xD0], xmm14
00007fa22efd79fb  vmovaps [rsp+0xE0], xmm15
00007fa22efd7a04  sub rsp, 0x30
00007fa22efd7a08  movaps [rsp], xmm3
00007fa22efd7a0c  movaps [rsp+0x10], xmm1
00007fa22efd7a11  movaps [rsp+0x20], xmm9
00007fa22efd7a17  lea rdi, [rsp]
00007fa22efd7a1b  mov esi, 0x00
00007fa22efd7a20  mov rax, 0x5E9D1A57D530
00007fa22efd7a2a  call rax
00007fa22efd7a2c  movaps xmm3, [rsp]
00007fa22efd7a30  add rsp, 0x30
00007fa22efd7a34  vmovaps xmm0, [rsp]
00007fa22efd7a39  vmovaps xmm1, [rsp+0x10]
00007fa22efd7a3f  vmovaps xmm2, [rsp+0x20]
00007fa22efd7a45  vmovaps xmm4, [rsp+0x30]
00007fa22efd7a4b  vmovaps xmm5, [rsp+0x40]
00007fa22efd7a51  vmovaps xmm6, [rsp+0x50]
00007fa22efd7a57  vmovaps xmm7, [rsp+0x60]
00007fa22efd7a5d  vmovaps xmm8, [rsp+0x70]
00007fa22efd7a63  vmovaps xmm9, [rsp+0x80]
00007fa22efd7a6c  vmovaps xmm10, [rsp+0x90]
00007fa22efd7a75  vmovaps xmm11, [rsp+0xA0]
00007fa22efd7a7e  vmovaps xmm12, [rsp+0xB0]
00007fa22efd7a87  vmovaps xmm13, [rsp+0xC0]
00007fa22efd7a90  vmovaps xmm14, [rsp+0xD0]
00007fa22efd7a99  vmovaps xmm15, [rsp+0xE0]
00007fa22efd7aa2  add rsp, 0xF0
00007fa22efd7aa9  pop r11
00007fa22efd7aab  pop r10
00007fa22efd7aad  pop r9
00007fa22efd7aaf  pop r8
00007fa22efd7ab1  pop rsi
00007fa22efd7ab2  pop rdi
00007fa22efd7ab3  pop rdx
00007fa22efd7ab4  pop rcx
00007fa22efd7ab5  pop rax
00007fa22efd7ab6  add rsp, 0x08
00007fa22efd7aba  jmp 0x00007FA22EFD5D43
00007fa22efd7abf  sub rsp, 0x08
00007fa22efd7ac3  push rax
00007fa22efd7ac4  push rcx
00007fa22efd7ac5  push rdx
00007fa22efd7ac6  push rdi
00007fa22efd7ac7  push rsi
00007fa22efd7ac8  push r8
00007fa22efd7aca  push r9
00007fa22efd7acc  push r10
00007fa22efd7ace  push r11
00007fa22efd7ad0  sub rsp, 0xF0
00007fa22efd7ad7  vmovaps [rsp], xmm0
00007fa22efd7adc  vmovaps [rsp+0x10], xmm2
00007fa22efd7ae2  vmovaps [rsp+0x20], xmm3
00007fa22efd7ae8  vmovaps [rsp+0x30], xmm4
00007fa22efd7aee  vmovaps [rsp+0x40], xmm5
00007fa22efd7af4  vmovaps [rsp+0x50], xmm6
00007fa22efd7afa  vmovaps [rsp+0x60], xmm7
00007fa22efd7b00  vmovaps [rsp+0x70], xmm8
00007fa22efd7b06  vmovaps [rsp+0x80], xmm9
00007fa22efd7b0f  vmovaps [rsp+0x90], xmm10
00007fa22efd7b18  vmovaps [rsp+0xA0], xmm11
00007fa22efd7b21  vmovaps [rsp+0xB0], xmm12
00007fa22efd7b2a  vmovaps [rsp+0xC0], xmm13
00007fa22efd7b33  vmovaps [rsp+0xD0], xmm14
00007fa22efd7b3c  vmovaps [rsp+0xE0], xmm15
00007fa22efd7b45  sub rsp, 0x30
00007fa22efd7b49  movaps [rsp], xmm1
00007fa22efd7b4d  movaps [rsp+0x10], xmm15
00007fa22efd7b53  movaps [rsp+0x20], xmm9
00007fa22efd7b59  lea rdi, [rsp]
00007fa22efd7b5d  mov esi, 0x00
00007fa22efd7b62  mov rax, 0x5E9D1A57D530
00007fa22efd7b6c  call rax
00007fa22efd7b6e  movaps xmm1, [rsp]
00007fa22efd7b72  add rsp, 0x30
00007fa22efd7b76  vmovaps xmm0, [rsp]
00007fa22efd7b7b  vmovaps xmm2, [rsp+0x10]
00007fa22efd7b81  vmovaps xmm3, [rsp+0x20]
00007fa22efd7b87  vmovaps xmm4, [rsp+0x30]
00007fa22efd7b8d  vmovaps xmm5, [rsp+0x40]
00007fa22efd7b93  vmovaps xmm6, [rsp+0x50]
00007fa22efd7b99  vmovaps xmm7, [rsp+0x60]
00007fa22efd7b9f  vmovaps xmm8, [rsp+0x70]
00007fa22efd7ba5  vmovaps xmm9, [rsp+0x80]
00007fa22efd7bae  vmovaps xmm10, [rsp+0x90]
00007fa22efd7bb7  vmovaps xmm11, [rsp+0xA0]
00007fa22efd7bc0  vmovaps xmm12, [rsp+0xB0]
00007fa22efd7bc9  vmovaps xmm13, [rsp+0xC0]
00007fa22efd7bd2  vmovaps xmm14, [rsp+0xD0]
00007fa22efd7bdb  vmovaps xmm15, [rsp+0xE0]
00007fa22efd7be4  add rsp, 0xF0
00007fa22efd7beb  pop r11
00007fa22efd7bed  pop r10
00007fa22efd7bef  pop r9
00007fa22efd7bf1  pop r8
00007fa22efd7bf3  pop rsi
00007fa22efd7bf4  pop rdi
00007fa22efd7bf5  pop rdx
00007fa22efd7bf6  pop rcx
00007fa22efd7bf7  pop rax
00007fa22efd7bf8  add rsp, 0x08
00007fa22efd7bfc  jmp 0x00007FA22EFD5DCB
00007fa22efd7c01  call 0x00007FA22EEE5820
00007fa22efd7c06  jmp 0x00007FA22EFD5DD8
00007fa22efd7c0b  sub rsp, 0x08
00007fa22efd7c0f  push rax
00007fa22efd7c10  push rcx
00007fa22efd7c11  push rdx
00007fa22efd7c12  push rdi
00007fa22efd7c13  push rsi
00007fa22efd7c14  push r8
00007fa22efd7c16  push r9
00007fa22efd7c18  push r10
00007fa22efd7c1a  push r11
00007fa22efd7c1c  sub rsp, 0xF0
00007fa22efd7c23  vmovaps [rsp], xmm0
00007fa22efd7c28  vmovaps [rsp+0x10], xmm2
00007fa22efd7c2e  vmovaps [rsp+0x20], xmm3
00007fa22efd7c34  vmovaps [rsp+0x30], xmm4
00007fa22efd7c3a  vmovaps [rsp+0x40], xmm5
00007fa22efd7c40  vmovaps [rsp+0x50], xmm6
00007fa22efd7c46  vmovaps [rsp+0x60], xmm7
00007fa22efd7c4c  vmovaps [rsp+0x70], xmm8
00007fa22efd7c52  vmovaps [rsp+0x80], xmm9
00007fa22efd7c5b  vmovaps [rsp+0x90], xmm10
00007fa22efd7c64  vmovaps [rsp+0xA0], xmm11
00007fa22efd7c6d  vmovaps [rsp+0xB0], xmm12
00007fa22efd7c76  vmovaps [rsp+0xC0], xmm13
00007fa22efd7c7f  vmovaps [rsp+0xD0], xmm14
00007fa22efd7c88  vmovaps [rsp+0xE0], xmm15
00007fa22efd7c91  sub rsp, 0x30
00007fa22efd7c95  movaps [rsp], xmm1
00007fa22efd7c99  movaps [rsp+0x10], xmm5
00007fa22efd7c9e  movaps [rsp+0x20], xmm7
00007fa22efd7ca3  lea rdi, [rsp]
00007fa22efd7ca7  mov esi, 0x00
00007fa22efd7cac  mov rax, 0x5E9D1A57D530
00007fa22efd7cb6  call rax
00007fa22efd7cb8  movaps xmm1, [rsp]
00007fa22efd7cbc  add rsp, 0x30
00007fa22efd7cc0  vmovaps xmm0, [rsp]
00007fa22efd7cc5  vmovaps xmm2, [rsp+0x10]
00007fa22efd7ccb  vmovaps xmm3, [rsp+0x20]
00007fa22efd7cd1  vmovaps xmm4, [rsp+0x30]
00007fa22efd7cd7  vmovaps xmm5, [rsp+0x40]
00007fa22efd7cdd  vmovaps xmm6, [rsp+0x50]
00007fa22efd7ce3  vmovaps xmm7, [rsp+0x60]
00007fa22efd7ce9  vmovaps xmm8, [rsp+0x70]
00007fa22efd7cef  vmovaps xmm9, [rsp+0x80]
00007fa22efd7cf8  vmovaps xmm10, [rsp+0x90]
00007fa22efd7d01  vmovaps xmm11, [rsp+0xA0]
00007fa22efd7d0a  vmovaps xmm12, [rsp+0xB0]
00007fa22efd7d13  vmovaps xmm13, [rsp+0xC0]
00007fa22efd7d1c  vmovaps xmm14, [rsp+0xD0]
00007fa22efd7d25  vmovaps xmm15, [rsp+0xE0]
00007fa22efd7d2e  add rsp, 0xF0
00007fa22efd7d35  pop r11
00007fa22efd7d37  pop r10
00007fa22efd7d39  pop r9
00007fa22efd7d3b  pop r8
00007fa22efd7d3d  pop rsi
00007fa22efd7d3e  pop rdi
00007fa22efd7d3f  pop rdx
00007fa22efd7d40  pop rcx
00007fa22efd7d41  pop rax
00007fa22efd7d42  add rsp, 0x08
00007fa22efd7d46  jmp 0x00007FA22EFD5E7D
00007fa22efd7d4b  sub rsp, 0x08
00007fa22efd7d4f  push rax
00007fa22efd7d50  push rcx
00007fa22efd7d51  push rdx
00007fa22efd7d52  push rdi
00007fa22efd7d53  push rsi
00007fa22efd7d54  push r8
00007fa22efd7d56  push r9
00007fa22efd7d58  push r10
00007fa22efd7d5a  push r11
00007fa22efd7d5c  sub rsp, 0xF0
00007fa22efd7d63  vmovaps [rsp], xmm0
00007fa22efd7d68  vmovaps [rsp+0x10], xmm1
00007fa22efd7d6e  vmovaps [rsp+0x20], xmm2
00007fa22efd7d74  vmovaps [rsp+0x30], xmm3
00007fa22efd7d7a  vmovaps [rsp+0x40], xmm4
00007fa22efd7d80  vmovaps [rsp+0x50], xmm5
00007fa22efd7d86  vmovaps [rsp+0x60], xmm6
00007fa22efd7d8c  vmovaps [rsp+0x70], xmm8
00007fa22efd7d92  vmovaps [rsp+0x80], xmm9
00007fa22efd7d9b  vmovaps [rsp+0x90], xmm10
00007fa22efd7da4  vmovaps [rsp+0xA0], xmm11
00007fa22efd7dad  vmovaps [rsp+0xB0], xmm12
00007fa22efd7db6  vmovaps [rsp+0xC0], xmm13
00007fa22efd7dbf  vmovaps [rsp+0xD0], xmm14
00007fa22efd7dc8  vmovaps [rsp+0xE0], xmm15
00007fa22efd7dd1  sub rsp, 0x30
00007fa22efd7dd5  movaps [rsp], xmm7
00007fa22efd7dd9  movaps [rsp+0x10], xmm5
00007fa22efd7dde  movaps [rsp+0x20], xmm15
00007fa22efd7de4  lea rdi, [rsp]
00007fa22efd7de8  mov esi, 0x00
00007fa22efd7ded  mov rax, 0x5E9D1A57D530
00007fa22efd7df7  call rax
00007fa22efd7df9  movaps xmm7, [rsp]
00007fa22efd7dfd  add rsp, 0x30
00007fa22efd7e01  vmovaps xmm0, [rsp]
00007fa22efd7e06  vmovaps xmm1, [rsp+0x10]
00007fa22efd7e0c  vmovaps xmm2, [rsp+0x20]
00007fa22efd7e12  vmovaps xmm3, [rsp+0x30]
00007fa22efd7e18  vmovaps xmm4, [rsp+0x40]
00007fa22efd7e1e  vmovaps xmm5, [rsp+0x50]
00007fa22efd7e24  vmovaps xmm6, [rsp+0x60]
00007fa22efd7e2a  vmovaps xmm8, [rsp+0x70]
00007fa22efd7e30  vmovaps xmm9, [rsp+0x80]
00007fa22efd7e39  vmovaps xmm10, [rsp+0x90]
00007fa22efd7e42  vmovaps xmm11, [rsp+0xA0]
00007fa22efd7e4b  vmovaps xmm12, [rsp+0xB0]
00007fa22efd7e54  vmovaps xmm13, [rsp+0xC0]
00007fa22efd7e5d  vmovaps xmm14, [rsp+0xD0]
00007fa22efd7e66  vmovaps xmm15, [rsp+0xE0]
00007fa22efd7e6f  add rsp, 0xF0
00007fa22efd7e76  pop r11
00007fa22efd7e78  pop r10
00007fa22efd7e7a  pop r9
00007fa22efd7e7c  pop r8
00007fa22efd7e7e  pop rsi
00007fa22efd7e7f  pop rdi
00007fa22efd7e80  pop rdx
00007fa22efd7e81  pop rcx
00007fa22efd7e82  pop rax
00007fa22efd7e83  add rsp, 0x08
00007fa22efd7e87  jmp 0x00007FA22EFD5EB3
00007fa22efd7e8c  call 0x00007FA22EED64F0
00007fa22efd7e91  jmp 0x00007FA22EFD5EC0
00007fa22efd7e96  sub rsp, 0x08
00007fa22efd7e9a  push rax
00007fa22efd7e9b  push rcx
00007fa22efd7e9c  push rdx
00007fa22efd7e9d  push rdi
00007fa22efd7e9e  push rsi
00007fa22efd7e9f  push r8
00007fa22efd7ea1  push r9
00007fa22efd7ea3  push r10
00007fa22efd7ea5  push r11
00007fa22efd7ea7  sub rsp, 0xF0
00007fa22efd7eae  vmovaps [rsp], xmm0
00007fa22efd7eb3  vmovaps [rsp+0x10], xmm1
00007fa22efd7eb9  vmovaps [rsp+0x20], xmm2
00007fa22efd7ebf  vmovaps [rsp+0x30], xmm3
00007fa22efd7ec5  vmovaps [rsp+0x40], xmm4
00007fa22efd7ecb  vmovaps [rsp+0x50], xmm5
00007fa22efd7ed1  vmovaps [rsp+0x60], xmm6
00007fa22efd7ed7  vmovaps [rsp+0x70], xmm7
00007fa22efd7edd  vmovaps [rsp+0x80], xmm8
00007fa22efd7ee6  vmovaps [rsp+0x90], xmm9
00007fa22efd7eef  vmovaps [rsp+0xA0], xmm10
00007fa22efd7ef8  vmovaps [rsp+0xB0], xmm11
00007fa22efd7f01  vmovaps [rsp+0xC0], xmm12
00007fa22efd7f0a  vmovaps [rsp+0xD0], xmm13
00007fa22efd7f13  vmovaps [rsp+0xE0], xmm14
00007fa22efd7f1c  sub rsp, 0x30
00007fa22efd7f20  movaps [rsp], xmm15
00007fa22efd7f25  movaps [rsp+0x10], xmm5
00007fa22efd7f2a  movaps [rsp+0x20], xmm3
00007fa22efd7f2f  lea rdi, [rsp]
00007fa22efd7f33  mov esi, 0x00
00007fa22efd7f38  mov rax, 0x5E9D1A57D530
00007fa22efd7f42  call rax
00007fa22efd7f44  movaps xmm15, [rsp]
00007fa22efd7f49  add rsp, 0x30
00007fa22efd7f4d  vmovaps xmm0, [rsp]
00007fa22efd7f52  vmovaps xmm1, [rsp+0x10]
00007fa22efd7f58  vmovaps xmm2, [rsp+0x20]
00007fa22efd7f5e  vmovaps xmm3, [rsp+0x30]
00007fa22efd7f64  vmovaps xmm4, [rsp+0x40]
00007fa22efd7f6a  vmovaps xmm5, [rsp+0x50]
00007fa22efd7f70  vmovaps xmm6, [rsp+0x60]
00007fa22efd7f76  vmovaps xmm7, [rsp+0x70]
00007fa22efd7f7c  vmovaps xmm8, [rsp+0x80]
00007fa22efd7f85  vmovaps xmm9, [rsp+0x90]
00007fa22efd7f8e  vmovaps xmm10, [rsp+0xA0]
00007fa22efd7f97  vmovaps xmm11, [rsp+0xB0]
00007fa22efd7fa0  vmovaps xmm12, [rsp+0xC0]
00007fa22efd7fa9  vmovaps xmm13, [rsp+0xD0]
00007fa22efd7fb2  vmovaps xmm14, [rsp+0xE0]
00007fa22efd7fbb  add rsp, 0xF0
00007fa22efd7fc2  pop r11
00007fa22efd7fc4  pop r10
00007fa22efd7fc6  pop r9
00007fa22efd7fc8  pop r8
00007fa22efd7fca  pop rsi
00007fa22efd7fcb  pop rdi
00007fa22efd7fcc  pop rdx
00007fa22efd7fcd  pop rcx
00007fa22efd7fce  pop rax
00007fa22efd7fcf  add rsp, 0x08
00007fa22efd7fd3  jmp 0x00007FA22EFD5EE6
00007fa22efd7fd8  sub rsp, 0x08
00007fa22efd7fdc  push rax
00007fa22efd7fdd  push rcx
00007fa22efd7fde  push rdx
00007fa22efd7fdf  push rdi
00007fa22efd7fe0  push rsi
00007fa22efd7fe1  push r8
00007fa22efd7fe3  push r9
00007fa22efd7fe5  push r10
00007fa22efd7fe7  push r11
00007fa22efd7fe9  sub rsp, 0xF0
00007fa22efd7ff0  vmovaps [rsp], xmm0
00007fa22efd7ff5  vmovaps [rsp+0x10], xmm2
00007fa22efd7ffb  vmovaps [rsp+0x20], xmm3
00007fa22efd8001  vmovaps [rsp+0x30], xmm4
00007fa22efd8007  vmovaps [rsp+0x40], xmm5
00007fa22efd800d  vmovaps [rsp+0x50], xmm6
00007fa22efd8013  vmovaps [rsp+0x60], xmm7
00007fa22efd8019  vmovaps [rsp+0x70], xmm8
00007fa22efd801f  vmovaps [rsp+0x80], xmm9
00007fa22efd8028  vmovaps [rsp+0x90], xmm10
00007fa22efd8031  vmovaps [rsp+0xA0], xmm11
00007fa22efd803a  vmovaps [rsp+0xB0], xmm12
00007fa22efd8043  vmovaps [rsp+0xC0], xmm13
00007fa22efd804c  vmovaps [rsp+0xD0], xmm14
00007fa22efd8055  vmovaps [rsp+0xE0], xmm15
00007fa22efd805e  sub rsp, 0x30
00007fa22efd8062  movaps [rsp], xmm1
00007fa22efd8066  movaps [rsp+0x10], xmm5
00007fa22efd806b  movaps [rsp+0x20], xmm4
00007fa22efd8070  lea rdi, [rsp]
00007fa22efd8074  mov esi, 0x00
00007fa22efd8079  mov rax, 0x5E9D1A57D530
00007fa22efd8083  call rax
00007fa22efd8085  movaps xmm1, [rsp]
00007fa22efd8089  add rsp, 0x30
00007fa22efd808d  vmovaps xmm0, [rsp]
00007fa22efd8092  vmovaps xmm2, [rsp+0x10]
00007fa22efd8098  vmovaps xmm3, [rsp+0x20]
00007fa22efd809e  vmovaps xmm4, [rsp+0x30]
00007fa22efd80a4  vmovaps xmm5, [rsp+0x40]
00007fa22efd80aa  vmovaps xmm6, [rsp+0x50]
00007fa22efd80b0  vmovaps xmm7, [rsp+0x60]
00007fa22efd80b6  vmovaps xmm8, [rsp+0x70]
00007fa22efd80bc  vmovaps xmm9, [rsp+0x80]
00007fa22efd80c5  vmovaps xmm10, [rsp+0x90]
00007fa22efd80ce  vmovaps xmm11, [rsp+0xA0]
00007fa22efd80d7  vmovaps xmm12, [rsp+0xB0]
00007fa22efd80e0  vmovaps xmm13, [rsp+0xC0]
00007fa22efd80e9  vmovaps xmm14, [rsp+0xD0]
00007fa22efd80f2  vmovaps xmm15, [rsp+0xE0]
00007fa22efd80fb  add rsp, 0xF0
00007fa22efd8102  pop r11
00007fa22efd8104  pop r10
00007fa22efd8106  pop r9
00007fa22efd8108  pop r8
00007fa22efd810a  pop rsi
00007fa22efd810b  pop rdi
00007fa22efd810c  pop rdx
00007fa22efd810d  pop rcx
00007fa22efd810e  pop rax
00007fa22efd810f  add rsp, 0x08
00007fa22efd8113  jmp 0x00007FA22EFD5F06
00007fa22efd8118  sub rsp, 0x08
00007fa22efd811c  push rax
00007fa22efd811d  push rcx
00007fa22efd811e  push rdx
00007fa22efd811f  push rdi
00007fa22efd8120  push rsi
00007fa22efd8121  push r8
00007fa22efd8123  push r9
00007fa22efd8125  push r10
00007fa22efd8127  push r11
00007fa22efd8129  sub rsp, 0xF0
00007fa22efd8130  vmovaps [rsp], xmm0
00007fa22efd8135  vmovaps [rsp+0x10], xmm1
00007fa22efd813b  vmovaps [rsp+0x20], xmm2
00007fa22efd8141  vmovaps [rsp+0x30], xmm3
00007fa22efd8147  vmovaps [rsp+0x40], xmm5
00007fa22efd814d  vmovaps [rsp+0x50], xmm6
00007fa22efd8153  vmovaps [rsp+0x60], xmm7
00007fa22efd8159  vmovaps [rsp+0x70], xmm8
00007fa22efd815f  vmovaps [rsp+0x80], xmm9
00007fa22efd8168  vmovaps [rsp+0x90], xmm10
00007fa22efd8171  vmovaps [rsp+0xA0], xmm11
00007fa22efd817a  vmovaps [rsp+0xB0], xmm12
00007fa22efd8183  vmovaps [rsp+0xC0], xmm13
00007fa22efd818c  vmovaps [rsp+0xD0], xmm14
00007fa22efd8195  vmovaps [rsp+0xE0], xmm15
00007fa22efd819e  sub rsp, 0x30
00007fa22efd81a2  movaps [rsp], xmm4
00007fa22efd81a6  movaps [rsp+0x10], xmm3
00007fa22efd81ab  movaps [rsp+0x20], xmm5
00007fa22efd81b0  lea rdi, [rsp]
00007fa22efd81b4  mov esi, 0x00
00007fa22efd81b9  mov rax, 0x5E9D1A57D530
00007fa22efd81c3  call rax
00007fa22efd81c5  movaps xmm4, [rsp]
00007fa22efd81c9  add rsp, 0x30
00007fa22efd81cd  vmovaps xmm0, [rsp]
00007fa22efd81d2  vmovaps xmm1, [rsp+0x10]
00007fa22efd81d8  vmovaps xmm2, [rsp+0x20]
00007fa22efd81de  vmovaps xmm3, [rsp+0x30]
00007fa22efd81e4  vmovaps xmm5, [rsp+0x40]
00007fa22efd81ea  vmovaps xmm6, [rsp+0x50]
00007fa22efd81f0  vmovaps xmm7, [rsp+0x60]
00007fa22efd81f6  vmovaps xmm8, [rsp+0x70]
00007fa22efd81fc  vmovaps xmm9, [rsp+0x80]
00007fa22efd8205  vmovaps xmm10, [rsp+0x90]
00007fa22efd820e  vmovaps xmm11, [rsp+0xA0]
00007fa22efd8217  vmovaps xmm12, [rsp+0xB0]
00007fa22efd8220  vmovaps xmm13, [rsp+0xC0]
00007fa22efd8229  vmovaps xmm14, [rsp+0xD0]
00007fa22efd8232  vmovaps xmm15, [rsp+0xE0]
00007fa22efd823b  add rsp, 0xF0
00007fa22efd8242  pop r11
00007fa22efd8244  pop r10
00007fa22efd8246  pop r9
00007fa22efd8248  pop r8
00007fa22efd824a  pop rsi
00007fa22efd824b  pop rdi
00007fa22efd824c  pop rdx
00007fa22efd824d  pop rcx
00007fa22efd824e  pop rax
00007fa22efd824f  add rsp, 0x08
00007fa22efd8253  jmp 0x00007FA22EFD5F54
00007fa22efd8258  call 0x00007FA22EED64F0
00007fa22efd825d  jmp 0x00007FA22EFD5F61
00007fa22efd8262  sub rsp, 0x08
00007fa22efd8266  push rax
00007fa22efd8267  push rcx
00007fa22efd8268  push rdx
00007fa22efd8269  push rdi
00007fa22efd826a  push rsi
00007fa22efd826b  push r8
00007fa22efd826d  push r9
00007fa22efd826f  push r10
00007fa22efd8271  push r11
00007fa22efd8273  sub rsp, 0xF0
00007fa22efd827a  vmovaps [rsp], xmm0
00007fa22efd827f  vmovaps [rsp+0x10], xmm1
00007fa22efd8285  vmovaps [rsp+0x20], xmm2
00007fa22efd828b  vmovaps [rsp+0x30], xmm3
00007fa22efd8291  vmovaps [rsp+0x40], xmm4
00007fa22efd8297  vmovaps [rsp+0x50], xmm6
00007fa22efd829d  vmovaps [rsp+0x60], xmm7
00007fa22efd82a3  vmovaps [rsp+0x70], xmm8
00007fa22efd82a9  vmovaps [rsp+0x80], xmm9
00007fa22efd82b2  vmovaps [rsp+0x90], xmm10
00007fa22efd82bb  vmovaps [rsp+0xA0], xmm11
00007fa22efd82c4  vmovaps [rsp+0xB0], xmm12
00007fa22efd82cd  vmovaps [rsp+0xC0], xmm13
00007fa22efd82d6  vmovaps [rsp+0xD0], xmm14
00007fa22efd82df  vmovaps [rsp+0xE0], xmm15
00007fa22efd82e8  sub rsp, 0x30
00007fa22efd82ec  movaps [rsp], xmm5
00007fa22efd82f0  movaps [rsp+0x10], xmm6
00007fa22efd82f5  movaps [rsp+0x20], xmm3
00007fa22efd82fa  lea rdi, [rsp]
00007fa22efd82fe  mov esi, 0x00
00007fa22efd8303  mov rax, 0x5E9D1A57D530
00007fa22efd830d  call rax
00007fa22efd830f  movaps xmm5, [rsp]
00007fa22efd8313  add rsp, 0x30
00007fa22efd8317  vmovaps xmm0, [rsp]
00007fa22efd831c  vmovaps xmm1, [rsp+0x10]
00007fa22efd8322  vmovaps xmm2, [rsp+0x20]
00007fa22efd8328  vmovaps xmm3, [rsp+0x30]
00007fa22efd832e  vmovaps xmm4, [rsp+0x40]
00007fa22efd8334  vmovaps xmm6, [rsp+0x50]
00007fa22efd833a  vmovaps xmm7, [rsp+0x60]
00007fa22efd8340  vmovaps xmm8, [rsp+0x70]
00007fa22efd8346  vmovaps xmm9, [rsp+0x80]
00007fa22efd834f  vmovaps xmm10, [rsp+0x90]
00007fa22efd8358  vmovaps xmm11, [rsp+0xA0]
00007fa22efd8361  vmovaps xmm12, [rsp+0xB0]
00007fa22efd836a  vmovaps xmm13, [rsp+0xC0]
00007fa22efd8373  vmovaps xmm14, [rsp+0xD0]
00007fa22efd837c  vmovaps xmm15, [rsp+0xE0]
00007fa22efd8385  add rsp, 0xF0
00007fa22efd838c  pop r11
00007fa22efd838e  pop r10
00007fa22efd8390  pop r9
00007fa22efd8392  pop r8
00007fa22efd8394  pop rsi
00007fa22efd8395  pop rdi
00007fa22efd8396  pop rdx
00007fa22efd8397  pop rcx
00007fa22efd8398  pop rax
00007fa22efd8399  add rsp, 0x08
00007fa22efd839d  jmp 0x00007FA22EFD5F87
00007fa22efd83a2  sub rsp, 0x08
00007fa22efd83a6  push rax
00007fa22efd83a7  push rcx
00007fa22efd83a8  push rdx
00007fa22efd83a9  push rdi
00007fa22efd83aa  push rsi
00007fa22efd83ab  push r8
00007fa22efd83ad  push r9
00007fa22efd83af  push r10
00007fa22efd83b1  push r11
00007fa22efd83b3  sub rsp, 0xF0
00007fa22efd83ba  vmovaps [rsp], xmm0
00007fa22efd83bf  vmovaps [rsp+0x10], xmm1
00007fa22efd83c5  vmovaps [rsp+0x20], xmm2
00007fa22efd83cb  vmovaps [rsp+0x30], xmm3
00007fa22efd83d1  vmovaps [rsp+0x40], xmm4
00007fa22efd83d7  vmovaps [rsp+0x50], xmm5
00007fa22efd83dd  vmovaps [rsp+0x60], xmm7
00007fa22efd83e3  vmovaps [rsp+0x70], xmm8
00007fa22efd83e9  vmovaps [rsp+0x80], xmm9
00007fa22efd83f2  vmovaps [rsp+0x90], xmm10
00007fa22efd83fb  vmovaps [rsp+0xA0], xmm11
00007fa22efd8404  vmovaps [rsp+0xB0], xmm12
00007fa22efd840d  vmovaps [rsp+0xC0], xmm13
00007fa22efd8416  vmovaps [rsp+0xD0], xmm14
00007fa22efd841f  vmovaps [rsp+0xE0], xmm15
00007fa22efd8428  sub rsp, 0x30
00007fa22efd842c  movaps [rsp], xmm6
00007fa22efd8430  movaps [rsp+0x10], xmm9
00007fa22efd8436  movaps [rsp+0x20], xmm1
00007fa22efd843b  lea rdi, [rsp]
00007fa22efd843f  mov esi, 0x00
00007fa22efd8444  mov rax, 0x5E9D1A57D530
00007fa22efd844e  call rax
00007fa22efd8450  movaps xmm6, [rsp]
00007fa22efd8454  add rsp, 0x30
00007fa22efd8458  vmovaps xmm0, [rsp]
00007fa22efd845d  vmovaps xmm1, [rsp+0x10]
00007fa22efd8463  vmovaps xmm2, [rsp+0x20]
00007fa22efd8469  vmovaps xmm3, [rsp+0x30]
00007fa22efd846f  vmovaps xmm4, [rsp+0x40]
00007fa22efd8475  vmovaps xmm5, [rsp+0x50]
00007fa22efd847b  vmovaps xmm7, [rsp+0x60]
00007fa22efd8481  vmovaps xmm8, [rsp+0x70]
00007fa22efd8487  vmovaps xmm9, [rsp+0x80]
00007fa22efd8490  vmovaps xmm10, [rsp+0x90]
00007fa22efd8499  vmovaps xmm11, [rsp+0xA0]
00007fa22efd84a2  vmovaps xmm12, [rsp+0xB0]
00007fa22efd84ab  vmovaps xmm13, [rsp+0xC0]
00007fa22efd84b4  vmovaps xmm14, [rsp+0xD0]
00007fa22efd84bd  vmovaps xmm15, [rsp+0xE0]
00007fa22efd84c6  add rsp, 0xF0
00007fa22efd84cd  pop r11
00007fa22efd84cf  pop r10
00007fa22efd84d1  pop r9
00007fa22efd84d3  pop r8
00007fa22efd84d5  pop rsi
00007fa22efd84d6  pop rdi
00007fa22efd84d7  pop rdx
00007fa22efd84d8  pop rcx
00007fa22efd84d9  pop rax
00007fa22efd84da  add rsp, 0x08
00007fa22efd84de  jmp 0x00007FA22EFD5FAB
00007fa22efd84e3  sub rsp, 0x08
00007fa22efd84e7  push rax
00007fa22efd84e8  push rcx
00007fa22efd84e9  push rdx
00007fa22efd84ea  push rdi
00007fa22efd84eb  push rsi
00007fa22efd84ec  push r8
00007fa22efd84ee  push r9
00007fa22efd84f0  push r10
00007fa22efd84f2  push r11
00007fa22efd84f4  sub rsp, 0xF0
00007fa22efd84fb  vmovaps [rsp], xmm0
00007fa22efd8500  vmovaps [rsp+0x10], xmm1
00007fa22efd8506  vmovaps [rsp+0x20], xmm2
00007fa22efd850c  vmovaps [rsp+0x30], xmm3
00007fa22efd8512  vmovaps [rsp+0x40], xmm4
00007fa22efd8518  vmovaps [rsp+0x50], xmm5
00007fa22efd851e  vmovaps [rsp+0x60], xmm6
00007fa22efd8524  vmovaps [rsp+0x70], xmm7
00007fa22efd852a  vmovaps [rsp+0x80], xmm8
00007fa22efd8533  vmovaps [rsp+0x90], xmm10
00007fa22efd853c  vmovaps [rsp+0xA0], xmm11
00007fa22efd8545  vmovaps [rsp+0xB0], xmm12
00007fa22efd854e  vmovaps [rsp+0xC0], xmm13
00007fa22efd8557  vmovaps [rsp+0xD0], xmm14
00007fa22efd8560  vmovaps [rsp+0xE0], xmm15
00007fa22efd8569  sub rsp, 0x30
00007fa22efd856d  movaps [rsp], xmm9
00007fa22efd8572  movaps [rsp+0x10], xmm3
00007fa22efd8577  movaps [rsp+0x20], xmm1
00007fa22efd857c  lea rdi, [rsp]
00007fa22efd8580  mov esi, 0x00
00007fa22efd8585  mov rax, 0x5E9D1A57D530
00007fa22efd858f  call rax
00007fa22efd8591  movaps xmm9, [rsp]
00007fa22efd8596  add rsp, 0x30
00007fa22efd859a  vmovaps xmm0, [rsp]
00007fa22efd859f  vmovaps xmm1, [rsp+0x10]
00007fa22efd85a5  vmovaps xmm2, [rsp+0x20]
00007fa22efd85ab  vmovaps xmm3, [rsp+0x30]
00007fa22efd85b1  vmovaps xmm4, [rsp+0x40]
00007fa22efd85b7  vmovaps xmm5, [rsp+0x50]
00007fa22efd85bd  vmovaps xmm6, [rsp+0x60]
00007fa22efd85c3  vmovaps xmm7, [rsp+0x70]
00007fa22efd85c9  vmovaps xmm8, [rsp+0x80]
00007fa22efd85d2  vmovaps xmm10, [rsp+0x90]
00007fa22efd85db  vmovaps xmm11, [rsp+0xA0]
00007fa22efd85e4  vmovaps xmm12, [rsp+0xB0]
00007fa22efd85ed  vmovaps xmm13, [rsp+0xC0]
00007fa22efd85f6  vmovaps xmm14, [rsp+0xD0]
00007fa22efd85ff  vmovaps xmm15, [rsp+0xE0]
00007fa22efd8608  add rsp, 0xF0
00007fa22efd860f  pop r11
00007fa22efd8611  pop r10
00007fa22efd8613  pop r9
00007fa22efd8615  pop r8
00007fa22efd8617  pop rsi
00007fa22efd8618  pop rdi
00007fa22efd8619  pop rdx
00007fa22efd861a  pop rcx
00007fa22efd861b  pop rax
00007fa22efd861c  add rsp, 0x08
00007fa22efd8620  jmp 0x00007FA22EFD5FF7
00007fa22efd8625  call 0x00007FA22EED64F0
00007fa22efd862a  jmp 0x00007FA22EFD6004
00007fa22efd862f  sub rsp, 0x08
00007fa22efd8633  push rax
00007fa22efd8634  push rcx
00007fa22efd8635  push rdx
00007fa22efd8636  push rdi
00007fa22efd8637  push rsi
00007fa22efd8638  push r8
00007fa22efd863a  push r9
00007fa22efd863c  push r10
00007fa22efd863e  push r11
00007fa22efd8640  sub rsp, 0xF0
00007fa22efd8647  vmovaps [rsp], xmm0
00007fa22efd864c  vmovaps [rsp+0x10], xmm1
00007fa22efd8652  vmovaps [rsp+0x20], xmm2
00007fa22efd8658  vmovaps [rsp+0x30], xmm3
00007fa22efd865e  vmovaps [rsp+0x40], xmm4
00007fa22efd8664  vmovaps [rsp+0x50], xmm5
00007fa22efd866a  vmovaps [rsp+0x60], xmm6
00007fa22efd8670  vmovaps [rsp+0x70], xmm7
00007fa22efd8676  vmovaps [rsp+0x80], xmm8
00007fa22efd867f  vmovaps [rsp+0x90], xmm9
00007fa22efd8688  vmovaps [rsp+0xA0], xmm10
00007fa22efd8691  vmovaps [rsp+0xB0], xmm11
00007fa22efd869a  vmovaps [rsp+0xC0], xmm12
00007fa22efd86a3  vmovaps [rsp+0xD0], xmm13
00007fa22efd86ac  vmovaps [rsp+0xE0], xmm14
00007fa22efd86b5  sub rsp, 0x30
00007fa22efd86b9  movaps [rsp], xmm15
00007fa22efd86be  movaps [rsp+0x10], xmm3
00007fa22efd86c3  movaps [rsp+0x20], xmm7
00007fa22efd86c8  lea rdi, [rsp]
00007fa22efd86cc  mov esi, 0x00
00007fa22efd86d1  mov rax, 0x5E9D1A57D530
00007fa22efd86db  call rax
00007fa22efd86dd  movaps xmm15, [rsp]
00007fa22efd86e2  add rsp, 0x30
00007fa22efd86e6  vmovaps xmm0, [rsp]
00007fa22efd86eb  vmovaps xmm1, [rsp+0x10]
00007fa22efd86f1  vmovaps xmm2, [rsp+0x20]
00007fa22efd86f7  vmovaps xmm3, [rsp+0x30]
00007fa22efd86fd  vmovaps xmm4, [rsp+0x40]
00007fa22efd8703  vmovaps xmm5, [rsp+0x50]
00007fa22efd8709  vmovaps xmm6, [rsp+0x60]
00007fa22efd870f  vmovaps xmm7, [rsp+0x70]
00007fa22efd8715  vmovaps xmm8, [rsp+0x80]
00007fa22efd871e  vmovaps xmm9, [rsp+0x90]
00007fa22efd8727  vmovaps xmm10, [rsp+0xA0]
00007fa22efd8730  vmovaps xmm11, [rsp+0xB0]
00007fa22efd8739  vmovaps xmm12, [rsp+0xC0]
00007fa22efd8742  vmovaps xmm13, [rsp+0xD0]
00007fa22efd874b  vmovaps xmm14, [rsp+0xE0]
00007fa22efd8754  add rsp, 0xF0
00007fa22efd875b  pop r11
00007fa22efd875d  pop r10
00007fa22efd875f  pop r9
00007fa22efd8761  pop r8
00007fa22efd8763  pop rsi
00007fa22efd8764  pop rdi
00007fa22efd8765  pop rdx
00007fa22efd8766  pop rcx
00007fa22efd8767  pop rax
00007fa22efd8768  add rsp, 0x08
00007fa22efd876c  jmp 0x00007FA22EFD6030
00007fa22efd8771  sub rsp, 0x08
00007fa22efd8775  push rax
00007fa22efd8776  push rcx
00007fa22efd8777  push rdx
00007fa22efd8778  push rdi
00007fa22efd8779  push rsi
00007fa22efd877a  push r8
00007fa22efd877c  push r9
00007fa22efd877e  push r10
00007fa22efd8780  push r11
00007fa22efd8782  sub rsp, 0xF0
00007fa22efd8789  vmovaps [rsp], xmm0
00007fa22efd878e  vmovaps [rsp+0x10], xmm1
00007fa22efd8794  vmovaps [rsp+0x20], xmm2
00007fa22efd879a  vmovaps [rsp+0x30], xmm4
00007fa22efd87a0  vmovaps [rsp+0x40], xmm5
00007fa22efd87a6  vmovaps [rsp+0x50], xmm6
00007fa22efd87ac  vmovaps [rsp+0x60], xmm7
00007fa22efd87b2  vmovaps [rsp+0x70], xmm8
00007fa22efd87b8  vmovaps [rsp+0x80], xmm9
00007fa22efd87c1  vmovaps [rsp+0x90], xmm10
00007fa22efd87ca  vmovaps [rsp+0xA0], xmm11
00007fa22efd87d3  vmovaps [rsp+0xB0], xmm12
00007fa22efd87dc  vmovaps [rsp+0xC0], xmm13
00007fa22efd87e5  vmovaps [rsp+0xD0], xmm14
00007fa22efd87ee  vmovaps [rsp+0xE0], xmm15
00007fa22efd87f7  sub rsp, 0x30
00007fa22efd87fb  movaps [rsp], xmm3
00007fa22efd87ff  movaps [rsp+0x10], xmm1
00007fa22efd8804  movaps [rsp+0x20], xmm15
00007fa22efd880a  lea rdi, [rsp]
00007fa22efd880e  mov esi, 0x00
00007fa22efd8813  mov rax, 0x5E9D1A57D530
00007fa22efd881d  call rax
00007fa22efd881f  movaps xmm3, [rsp]
00007fa22efd8823  add rsp, 0x30
00007fa22efd8827  vmovaps xmm0, [rsp]
00007fa22efd882c  vmovaps xmm1, [rsp+0x10]
00007fa22efd8832  vmovaps xmm2, [rsp+0x20]
00007fa22efd8838  vmovaps xmm4, [rsp+0x30]
00007fa22efd883e  vmovaps xmm5, [rsp+0x40]
00007fa22efd8844  vmovaps xmm6, [rsp+0x50]
00007fa22efd884a  vmovaps xmm7, [rsp+0x60]
00007fa22efd8850  vmovaps xmm8, [rsp+0x70]
00007fa22efd8856  vmovaps xmm9, [rsp+0x80]
00007fa22efd885f  vmovaps xmm10, [rsp+0x90]
00007fa22efd8868  vmovaps xmm11, [rsp+0xA0]
00007fa22efd8871  vmovaps xmm12, [rsp+0xB0]
00007fa22efd887a  vmovaps xmm13, [rsp+0xC0]
00007fa22efd8883  vmovaps xmm14, [rsp+0xD0]
00007fa22efd888c  vmovaps xmm15, [rsp+0xE0]
00007fa22efd8895  add rsp, 0xF0
00007fa22efd889c  pop r11
00007fa22efd889e  pop r10
00007fa22efd88a0  pop r9
00007fa22efd88a2  pop r8
00007fa22efd88a4  pop rsi
00007fa22efd88a5  pop rdi
00007fa22efd88a6  pop rdx
00007fa22efd88a7  pop rcx
00007fa22efd88a8  pop rax
00007fa22efd88a9  add rsp, 0x08
00007fa22efd88ad  jmp 0x00007FA22EFD60BF
00007fa22efd88b2  call 0x00007FA22EED64F0
00007fa22efd88b7  jmp 0x00007FA22EFD60C9
00007fa22efd88bc  sub rsp, 0x08
00007fa22efd88c0  push rax
00007fa22efd88c1  push rcx
00007fa22efd88c2  push rdx
00007fa22efd88c3  push rdi
00007fa22efd88c4  push rsi
00007fa22efd88c5  push r8
00007fa22efd88c7  push r9
00007fa22efd88c9  push r10
00007fa22efd88cb  push r11
00007fa22efd88cd  sub rsp, 0xF0
00007fa22efd88d4  vmovaps [rsp], xmm0
00007fa22efd88d9  vmovaps [rsp+0x10], xmm1
00007fa22efd88df  vmovaps [rsp+0x20], xmm2
00007fa22efd88e5  vmovaps [rsp+0x30], xmm3
00007fa22efd88eb  vmovaps [rsp+0x40], xmm4
00007fa22efd88f1  vmovaps [rsp+0x50], xmm5
00007fa22efd88f7  vmovaps [rsp+0x60], xmm6
00007fa22efd88fd  vmovaps [rsp+0x70], xmm7
00007fa22efd8903  vmovaps [rsp+0x80], xmm8
00007fa22efd890c  vmovaps [rsp+0x90], xmm9
00007fa22efd8915  vmovaps [rsp+0xA0], xmm10
00007fa22efd891e  vmovaps [rsp+0xB0], xmm11
00007fa22efd8927  vmovaps [rsp+0xC0], xmm12
00007fa22efd8930  vmovaps [rsp+0xD0], xmm13
00007fa22efd8939  vmovaps [rsp+0xE0], xmm14
00007fa22efd8942  sub rsp, 0x30
00007fa22efd8946  movaps [rsp], xmm15
00007fa22efd894b  movaps [rsp+0x10], xmm14
00007fa22efd8951  movaps [rsp+0x20], xmm4
00007fa22efd8956  lea rdi, [rsp]
00007fa22efd895a  mov esi, 0x00
00007fa22efd895f  mov rax, 0x5E9D1A57D530
00007fa22efd8969  call rax
00007fa22efd896b  movaps xmm15, [rsp]
00007fa22efd8970  add rsp, 0x30
00007fa22efd8974  vmovaps xmm0, [rsp]
00007fa22efd8979  vmovaps xmm1, [rsp+0x10]
00007fa22efd897f  vmovaps xmm2, [rsp+0x20]
00007fa22efd8985  vmovaps xmm3, [rsp+0x30]
00007fa22efd898b  vmovaps xmm4, [rsp+0x40]
00007fa22efd8991  vmovaps xmm5, [rsp+0x50]
00007fa22efd8997  vmovaps xmm6, [rsp+0x60]
00007fa22efd899d  vmovaps xmm7, [rsp+0x70]
00007fa22efd89a3  vmovaps xmm8, [rsp+0x80]
00007fa22efd89ac  vmovaps xmm9, [rsp+0x90]
00007fa22efd89b5  vmovaps xmm10, [rsp+0xA0]
00007fa22efd89be  vmovaps xmm11, [rsp+0xB0]
00007fa22efd89c7  vmovaps xmm12, [rsp+0xC0]
00007fa22efd89d0  vmovaps xmm13, [rsp+0xD0]
00007fa22efd89d9  vmovaps xmm14, [rsp+0xE0]
00007fa22efd89e2  add rsp, 0xF0
00007fa22efd89e9  pop r11
00007fa22efd89eb  pop r10
00007fa22efd89ed  pop r9
00007fa22efd89ef  pop r8
00007fa22efd89f1  pop rsi
00007fa22efd89f2  pop rdi
00007fa22efd89f3  pop rdx
00007fa22efd89f4  pop rcx
00007fa22efd89f5  pop rax
00007fa22efd89f6  add rsp, 0x08
00007fa22efd89fa  jmp 0x00007FA22EFD60F7
00007fa22efd89ff  sub rsp, 0x08
00007fa22efd8a03  push rax
00007fa22efd8a04  push rcx
00007fa22efd8a05  push rdx
00007fa22efd8a06  push rdi
00007fa22efd8a07  push rsi
00007fa22efd8a08  push r8
00007fa22efd8a0a  push r9
00007fa22efd8a0c  push r10
00007fa22efd8a0e  push r11
00007fa22efd8a10  sub rsp, 0xF0
00007fa22efd8a17  vmovaps [rsp], xmm0
00007fa22efd8a1c  vmovaps [rsp+0x10], xmm1
00007fa22efd8a22  vmovaps [rsp+0x20], xmm2
00007fa22efd8a28  vmovaps [rsp+0x30], xmm3
00007fa22efd8a2e  vmovaps [rsp+0x40], xmm4
00007fa22efd8a34  vmovaps [rsp+0x50], xmm5
00007fa22efd8a3a  vmovaps [rsp+0x60], xmm6
00007fa22efd8a40  vmovaps [rsp+0x70], xmm7
00007fa22efd8a46  vmovaps [rsp+0x80], xmm8
00007fa22efd8a4f  vmovaps [rsp+0x90], xmm9
00007fa22efd8a58  vmovaps [rsp+0xA0], xmm10
00007fa22efd8a61  vmovaps [rsp+0xB0], xmm11
00007fa22efd8a6a  vmovaps [rsp+0xC0], xmm12
00007fa22efd8a73  vmovaps [rsp+0xD0], xmm13
00007fa22efd8a7c  vmovaps [rsp+0xE0], xmm15
00007fa22efd8a85  sub rsp, 0x30
00007fa22efd8a89  movaps [rsp], xmm14
00007fa22efd8a8e  movaps [rsp+0x10], xmm2
00007fa22efd8a93  movaps [rsp+0x20], xmm1
00007fa22efd8a98  lea rdi, [rsp]
00007fa22efd8a9c  mov esi, 0x00
00007fa22efd8aa1  mov rax, 0x5E9D1A57D530
00007fa22efd8aab  call rax
00007fa22efd8aad  movaps xmm14, [rsp]
00007fa22efd8ab2  add rsp, 0x30
00007fa22efd8ab6  vmovaps xmm0, [rsp]
00007fa22efd8abb  vmovaps xmm1, [rsp+0x10]
00007fa22efd8ac1  vmovaps xmm2, [rsp+0x20]
00007fa22efd8ac7  vmovaps xmm3, [rsp+0x30]
00007fa22efd8acd  vmovaps xmm4, [rsp+0x40]
00007fa22efd8ad3  vmovaps xmm5, [rsp+0x50]
00007fa22efd8ad9  vmovaps xmm6, [rsp+0x60]
00007fa22efd8adf  vmovaps xmm7, [rsp+0x70]
00007fa22efd8ae5  vmovaps xmm8, [rsp+0x80]
00007fa22efd8aee  vmovaps xmm9, [rsp+0x90]
00007fa22efd8af7  vmovaps xmm10, [rsp+0xA0]
00007fa22efd8b00  vmovaps xmm11, [rsp+0xB0]
00007fa22efd8b09  vmovaps xmm12, [rsp+0xC0]
00007fa22efd8b12  vmovaps xmm13, [rsp+0xD0]
00007fa22efd8b1b  vmovaps xmm15, [rsp+0xE0]
00007fa22efd8b24  add rsp, 0xF0
00007fa22efd8b2b  pop r11
00007fa22efd8b2d  pop r10
00007fa22efd8b2f  pop r9
00007fa22efd8b31  pop r8
00007fa22efd8b33  pop rsi
00007fa22efd8b34  pop rdi
00007fa22efd8b35  pop rdx
00007fa22efd8b36  pop rcx
00007fa22efd8b37  pop rax
00007fa22efd8b38  add rsp, 0x08
00007fa22efd8b3c  jmp 0x00007FA22EFD611D
00007fa22efd8b41  sub rsp, 0x08
00007fa22efd8b45  push rax
00007fa22efd8b46  push rcx
00007fa22efd8b47  push rdx
00007fa22efd8b48  push rdi
00007fa22efd8b49  push rsi
00007fa22efd8b4a  push r8
00007fa22efd8b4c  push r9
00007fa22efd8b4e  push r10
00007fa22efd8b50  push r11
00007fa22efd8b52  sub rsp, 0xF0
00007fa22efd8b59  vmovaps [rsp], xmm0
00007fa22efd8b5e  vmovaps [rsp+0x10], xmm2
00007fa22efd8b64  vmovaps [rsp+0x20], xmm3
00007fa22efd8b6a  vmovaps [rsp+0x30], xmm4
00007fa22efd8b70  vmovaps [rsp+0x40], xmm5
00007fa22efd8b76  vmovaps [rsp+0x50], xmm6
00007fa22efd8b7c  vmovaps [rsp+0x60], xmm7
00007fa22efd8b82  vmovaps [rsp+0x70], xmm8
00007fa22efd8b88  vmovaps [rsp+0x80], xmm9
00007fa22efd8b91  vmovaps [rsp+0x90], xmm10
00007fa22efd8b9a  vmovaps [rsp+0xA0], xmm11
00007fa22efd8ba3  vmovaps [rsp+0xB0], xmm12
00007fa22efd8bac  vmovaps [rsp+0xC0], xmm13
00007fa22efd8bb5  vmovaps [rsp+0xD0], xmm14
00007fa22efd8bbe  vmovaps [rsp+0xE0], xmm15
00007fa22efd8bc7  sub rsp, 0x30
00007fa22efd8bcb  movaps [rsp], xmm1
00007fa22efd8bcf  movaps [rsp+0x10], xmm4
00007fa22efd8bd4  movaps [rsp+0x20], xmm9
00007fa22efd8bda  lea rdi, [rsp]
00007fa22efd8bde  mov esi, 0x00
00007fa22efd8be3  mov rax, 0x5E9D1A57D530
00007fa22efd8bed  call rax
00007fa22efd8bef  movaps xmm1, [rsp]
00007fa22efd8bf3  add rsp, 0x30
00007fa22efd8bf7  vmovaps xmm0, [rsp]
00007fa22efd8bfc  vmovaps xmm2, [rsp+0x10]
00007fa22efd8c02  vmovaps xmm3, [rsp+0x20]
00007fa22efd8c08  vmovaps xmm4, [rsp+0x30]
00007fa22efd8c0e  vmovaps xmm5, [rsp+0x40]
00007fa22efd8c14  vmovaps xmm6, [rsp+0x50]
00007fa22efd8c1a  vmovaps xmm7, [rsp+0x60]
00007fa22efd8c20  vmovaps xmm8, [rsp+0x70]
00007fa22efd8c26  vmovaps xmm9, [rsp+0x80]
00007fa22efd8c2f  vmovaps xmm10, [rsp+0x90]
00007fa22efd8c38  vmovaps xmm11, [rsp+0xA0]
00007fa22efd8c41  vmovaps xmm12, [rsp+0xB0]
00007fa22efd8c4a  vmovaps xmm13, [rsp+0xC0]
00007fa22efd8c53  vmovaps xmm14, [rsp+0xD0]
00007fa22efd8c5c  vmovaps xmm15, [rsp+0xE0]
00007fa22efd8c65  add rsp, 0xF0
00007fa22efd8c6c  pop r11
00007fa22efd8c6e  pop r10
00007fa22efd8c70  pop r9
00007fa22efd8c72  pop r8
00007fa22efd8c74  pop rsi
00007fa22efd8c75  pop rdi
00007fa22efd8c76  pop rdx
00007fa22efd8c77  pop rcx
00007fa22efd8c78  pop rax
00007fa22efd8c79  add rsp, 0x08
00007fa22efd8c7d  jmp 0x00007FA22EFD613B
00007fa22efd8c82  sub rsp, 0x08
00007fa22efd8c86  push rax
00007fa22efd8c87  push rcx
00007fa22efd8c88  push rdx
00007fa22efd8c89  push rdi
00007fa22efd8c8a  push rsi
00007fa22efd8c8b  push r8
00007fa22efd8c8d  push r9
00007fa22efd8c8f  push r10
00007fa22efd8c91  push r11
00007fa22efd8c93  sub rsp, 0xF0
00007fa22efd8c9a  vmovaps [rsp], xmm0
00007fa22efd8c9f  vmovaps [rsp+0x10], xmm1
00007fa22efd8ca5  vmovaps [rsp+0x20], xmm2
00007fa22efd8cab  vmovaps [rsp+0x30], xmm3
00007fa22efd8cb1  vmovaps [rsp+0x40], xmm5
00007fa22efd8cb7  vmovaps [rsp+0x50], xmm6
00007fa22efd8cbd  vmovaps [rsp+0x60], xmm7
00007fa22efd8cc3  vmovaps [rsp+0x70], xmm8
00007fa22efd8cc9  vmovaps [rsp+0x80], xmm9
00007fa22efd8cd2  vmovaps [rsp+0x90], xmm10
00007fa22efd8cdb  vmovaps [rsp+0xA0], xmm11
00007fa22efd8ce4  vmovaps [rsp+0xB0], xmm12
00007fa22efd8ced  vmovaps [rsp+0xC0], xmm13
00007fa22efd8cf6  vmovaps [rsp+0xD0], xmm14
00007fa22efd8cff  vmovaps [rsp+0xE0], xmm15
00007fa22efd8d08  sub rsp, 0x30
00007fa22efd8d0c  movaps [rsp], xmm4
00007fa22efd8d10  movaps [rsp+0x10], xmm2
00007fa22efd8d15  movaps [rsp+0x20], xmm9
00007fa22efd8d1b  lea rdi, [rsp]
00007fa22efd8d1f  mov esi, 0x00
00007fa22efd8d24  mov rax, 0x5E9D1A57D530
00007fa22efd8d2e  call rax
00007fa22efd8d30  movaps xmm4, [rsp]
00007fa22efd8d34  add rsp, 0x30
00007fa22efd8d38  vmovaps xmm0, [rsp]
00007fa22efd8d3d  vmovaps xmm1, [rsp+0x10]
00007fa22efd8d43  vmovaps xmm2, [rsp+0x20]
00007fa22efd8d49  vmovaps xmm3, [rsp+0x30]
00007fa22efd8d4f  vmovaps xmm5, [rsp+0x40]
00007fa22efd8d55  vmovaps xmm6, [rsp+0x50]
00007fa22efd8d5b  vmovaps xmm7, [rsp+0x60]
00007fa22efd8d61  vmovaps xmm8, [rsp+0x70]
00007fa22efd8d67  vmovaps xmm9, [rsp+0x80]
00007fa22efd8d70  vmovaps xmm10, [rsp+0x90]
00007fa22efd8d79  vmovaps xmm11, [rsp+0xA0]
00007fa22efd8d82  vmovaps xmm12, [rsp+0xB0]
00007fa22efd8d8b  vmovaps xmm13, [rsp+0xC0]
00007fa22efd8d94  vmovaps xmm14, [rsp+0xD0]
00007fa22efd8d9d  vmovaps xmm15, [rsp+0xE0]
00007fa22efd8da6  add rsp, 0xF0
00007fa22efd8dad  pop r11
00007fa22efd8daf  pop r10
00007fa22efd8db1  pop r9
00007fa22efd8db3  pop r8
00007fa22efd8db5  pop rsi
00007fa22efd8db6  pop rdi
00007fa22efd8db7  pop rdx
00007fa22efd8db8  pop rcx
00007fa22efd8db9  pop rax
00007fa22efd8dba  add rsp, 0x08
00007fa22efd8dbe  jmp 0x00007FA22EFD616B
00007fa22efd8dc3  sub rsp, 0x08
00007fa22efd8dc7  push rax
00007fa22efd8dc8  push rcx
00007fa22efd8dc9  push rdx
00007fa22efd8dca  push rdi
00007fa22efd8dcb  push rsi
00007fa22efd8dcc  push r8
00007fa22efd8dce  push r9
00007fa22efd8dd0  push r10
00007fa22efd8dd2  push r11
00007fa22efd8dd4  sub rsp, 0xF0
00007fa22efd8ddb  vmovaps [rsp], xmm0
00007fa22efd8de0  vmovaps [rsp+0x10], xmm1
00007fa22efd8de6  vmovaps [rsp+0x20], xmm2
00007fa22efd8dec  vmovaps [rsp+0x30], xmm3
00007fa22efd8df2  vmovaps [rsp+0x40], xmm4
00007fa22efd8df8  vmovaps [rsp+0x50], xmm5
00007fa22efd8dfe  vmovaps [rsp+0x60], xmm6
00007fa22efd8e04  vmovaps [rsp+0x70], xmm7
00007fa22efd8e0a  vmovaps [rsp+0x80], xmm8
00007fa22efd8e13  vmovaps [rsp+0x90], xmm10
00007fa22efd8e1c  vmovaps [rsp+0xA0], xmm11
00007fa22efd8e25  vmovaps [rsp+0xB0], xmm12
00007fa22efd8e2e  vmovaps [rsp+0xC0], xmm13
00007fa22efd8e37  vmovaps [rsp+0xD0], xmm14
00007fa22efd8e40  vmovaps [rsp+0xE0], xmm15
00007fa22efd8e49  sub rsp, 0x30
00007fa22efd8e4d  movaps [rsp], xmm9
00007fa22efd8e52  movaps [rsp+0x10], xmm2
00007fa22efd8e57  movaps [rsp+0x20], xmm1
00007fa22efd8e5c  lea rdi, [rsp]
00007fa22efd8e60  mov esi, 0x00
00007fa22efd8e65  mov rax, 0x5E9D1A57D530
00007fa22efd8e6f  call rax
00007fa22efd8e71  movaps xmm9, [rsp]
00007fa22efd8e76  add rsp, 0x30
00007fa22efd8e7a  vmovaps xmm0, [rsp]
00007fa22efd8e7f  vmovaps xmm1, [rsp+0x10]
00007fa22efd8e85  vmovaps xmm2, [rsp+0x20]
00007fa22efd8e8b  vmovaps xmm3, [rsp+0x30]
00007fa22efd8e91  vmovaps xmm4, [rsp+0x40]
00007fa22efd8e97  vmovaps xmm5, [rsp+0x50]
00007fa22efd8e9d  vmovaps xmm6, [rsp+0x60]
00007fa22efd8ea3  vmovaps xmm7, [rsp+0x70]
00007fa22efd8ea9  vmovaps xmm8, [rsp+0x80]
00007fa22efd8eb2  vmovaps xmm10, [rsp+0x90]
00007fa22efd8ebb  vmovaps xmm11, [rsp+0xA0]
00007fa22efd8ec4  vmovaps xmm12, [rsp+0xB0]
00007fa22efd8ecd  vmovaps xmm13, [rsp+0xC0]
00007fa22efd8ed6  vmovaps xmm14, [rsp+0xD0]
00007fa22efd8edf  vmovaps xmm15, [rsp+0xE0]
00007fa22efd8ee8  add rsp, 0xF0
00007fa22efd8eef  pop r11
00007fa22efd8ef1  pop r10
00007fa22efd8ef3  pop r9
00007fa22efd8ef5  pop r8
00007fa22efd8ef7  pop rsi
00007fa22efd8ef8  pop rdi
00007fa22efd8ef9  pop rdx
00007fa22efd8efa  pop rcx
00007fa22efd8efb  pop rax
00007fa22efd8efc  add rsp, 0x08
00007fa22efd8f00  jmp 0x00007FA22EFD61A1
00007fa22efd8f05  sub rsp, 0x08
00007fa22efd8f09  push rax
00007fa22efd8f0a  push rcx
00007fa22efd8f0b  push rdx
00007fa22efd8f0c  push rdi
00007fa22efd8f0d  push rsi
00007fa22efd8f0e  push r8
00007fa22efd8f10  push r9
00007fa22efd8f12  push r10
00007fa22efd8f14  push r11
00007fa22efd8f16  sub rsp, 0xF0
00007fa22efd8f1d  vmovaps [rsp], xmm0
00007fa22efd8f22  vmovaps [rsp+0x10], xmm2
00007fa22efd8f28  vmovaps [rsp+0x20], xmm3
00007fa22efd8f2e  vmovaps [rsp+0x30], xmm4
00007fa22efd8f34  vmovaps [rsp+0x40], xmm5
00007fa22efd8f3a  vmovaps [rsp+0x50], xmm6
00007fa22efd8f40  vmovaps [rsp+0x60], xmm7
00007fa22efd8f46  vmovaps [rsp+0x70], xmm8
00007fa22efd8f4c  vmovaps [rsp+0x80], xmm9
00007fa22efd8f55  vmovaps [rsp+0x90], xmm10
00007fa22efd8f5e  vmovaps [rsp+0xA0], xmm11
00007fa22efd8f67  vmovaps [rsp+0xB0], xmm12
00007fa22efd8f70  vmovaps [rsp+0xC0], xmm13
00007fa22efd8f79  vmovaps [rsp+0xD0], xmm14
00007fa22efd8f82  vmovaps [rsp+0xE0], xmm15
00007fa22efd8f8b  sub rsp, 0x30
00007fa22efd8f8f  movaps [rsp], xmm1
00007fa22efd8f93  movaps [rsp+0x10], xmm15
00007fa22efd8f99  movaps [rsp+0x20], xmm6
00007fa22efd8f9e  lea rdi, [rsp]
00007fa22efd8fa2  mov esi, 0x00
00007fa22efd8fa7  mov rax, 0x5E9D1A57D530
00007fa22efd8fb1  call rax
00007fa22efd8fb3  movaps xmm1, [rsp]
00007fa22efd8fb7  add rsp, 0x30
00007fa22efd8fbb  vmovaps xmm0, [rsp]
00007fa22efd8fc0  vmovaps xmm2, [rsp+0x10]
00007fa22efd8fc6  vmovaps xmm3, [rsp+0x20]
00007fa22efd8fcc  vmovaps xmm4, [rsp+0x30]
00007fa22efd8fd2  vmovaps xmm5, [rsp+0x40]
00007fa22efd8fd8  vmovaps xmm6, [rsp+0x50]
00007fa22efd8fde  vmovaps xmm7, [rsp+0x60]
00007fa22efd8fe4  vmovaps xmm8, [rsp+0x70]
00007fa22efd8fea  vmovaps xmm9, [rsp+0x80]
00007fa22efd8ff3  vmovaps xmm10, [rsp+0x90]
00007fa22efd8ffc  vmovaps xmm11, [rsp+0xA0]
00007fa22efd9005  vmovaps xmm12, [rsp+0xB0]
00007fa22efd900e  vmovaps xmm13, [rsp+0xC0]
00007fa22efd9017  vmovaps xmm14, [rsp+0xD0]
00007fa22efd9020  vmovaps xmm15, [rsp+0xE0]
00007fa22efd9029  add rsp, 0xF0
00007fa22efd9030  pop r11
00007fa22efd9032  pop r10
00007fa22efd9034  pop r9
00007fa22efd9036  pop r8
00007fa22efd9038  pop rsi
00007fa22efd9039  pop rdi
00007fa22efd903a  pop rdx
00007fa22efd903b  pop rcx
00007fa22efd903c  pop rax
00007fa22efd903d  add rsp, 0x08
00007fa22efd9041  jmp 0x00007FA22EFD61C2
00007fa22efd9046  sub rsp, 0x08
00007fa22efd904a  push rax
00007fa22efd904b  push rcx
00007fa22efd904c  push rdx
00007fa22efd904d  push rdi
00007fa22efd904e  push rsi
00007fa22efd904f  push r8
00007fa22efd9051  push r9
00007fa22efd9053  push r10
00007fa22efd9055  push r11
00007fa22efd9057  sub rsp, 0xF0
00007fa22efd905e  vmovaps [rsp], xmm0
00007fa22efd9063  vmovaps [rsp+0x10], xmm1
00007fa22efd9069  vmovaps [rsp+0x20], xmm2
00007fa22efd906f  vmovaps [rsp+0x30], xmm3
00007fa22efd9075  vmovaps [rsp+0x40], xmm4
00007fa22efd907b  vmovaps [rsp+0x50], xmm5
00007fa22efd9081  vmovaps [rsp+0x60], xmm6
00007fa22efd9087  vmovaps [rsp+0x70], xmm7
00007fa22efd908d  vmovaps [rsp+0x80], xmm8
00007fa22efd9096  vmovaps [rsp+0x90], xmm9
00007fa22efd909f  vmovaps [rsp+0xA0], xmm10
00007fa22efd90a8  vmovaps [rsp+0xB0], xmm11
00007fa22efd90b1  vmovaps [rsp+0xC0], xmm12
00007fa22efd90ba  vmovaps [rsp+0xD0], xmm13
00007fa22efd90c3  vmovaps [rsp+0xE0], xmm14
00007fa22efd90cc  sub rsp, 0x30
00007fa22efd90d0  movaps [rsp], xmm15
00007fa22efd90d5  movaps [rsp+0x10], xmm5
00007fa22efd90da  movaps [rsp+0x20], xmm3
00007fa22efd90df  lea rdi, [rsp]
00007fa22efd90e3  mov esi, 0x00
00007fa22efd90e8  mov rax, 0x5E9D1A57D530
00007fa22efd90f2  call rax
00007fa22efd90f4  movaps xmm15, [rsp]
00007fa22efd90f9  add rsp, 0x30
00007fa22efd90fd  vmovaps xmm0, [rsp]
00007fa22efd9102  vmovaps xmm1, [rsp+0x10]
00007fa22efd9108  vmovaps xmm2, [rsp+0x20]
00007fa22efd910e  vmovaps xmm3, [rsp+0x30]
00007fa22efd9114  vmovaps xmm4, [rsp+0x40]
00007fa22efd911a  vmovaps xmm5, [rsp+0x50]
00007fa22efd9120  vmovaps xmm6, [rsp+0x60]
00007fa22efd9126  vmovaps xmm7, [rsp+0x70]
00007fa22efd912c  vmovaps xmm8, [rsp+0x80]
00007fa22efd9135  vmovaps xmm9, [rsp+0x90]
00007fa22efd913e  vmovaps xmm10, [rsp+0xA0]
00007fa22efd9147  vmovaps xmm11, [rsp+0xB0]
00007fa22efd9150  vmovaps xmm12, [rsp+0xC0]
00007fa22efd9159  vmovaps xmm13, [rsp+0xD0]
00007fa22efd9162  vmovaps xmm14, [rsp+0xE0]
00007fa22efd916b  add rsp, 0xF0
00007fa22efd9172  pop r11
00007fa22efd9174  pop r10
00007fa22efd9176  pop r9
00007fa22efd9178  pop r8
00007fa22efd917a  pop rsi
00007fa22efd917b  pop rdi
00007fa22efd917c  pop rdx
00007fa22efd917d  pop rcx
00007fa22efd917e  pop rax
00007fa22efd917f  add rsp, 0x08
00007fa22efd9183  jmp 0x00007FA22EFD61DC
00007fa22efd9188  sub rsp, 0x08
00007fa22efd918c  push rax
00007fa22efd918d  push rcx
00007fa22efd918e  push rdx
00007fa22efd918f  push rdi
00007fa22efd9190  push rsi
00007fa22efd9191  push r8
00007fa22efd9193  push r9
00007fa22efd9195  push r10
00007fa22efd9197  push r11
00007fa22efd9199  sub rsp, 0xF0
00007fa22efd91a0  vmovaps [rsp], xmm0
00007fa22efd91a5  vmovaps [rsp+0x10], xmm1
00007fa22efd91ab  vmovaps [rsp+0x20], xmm2
00007fa22efd91b1  vmovaps [rsp+0x30], xmm3
00007fa22efd91b7  vmovaps [rsp+0x40], xmm4
00007fa22efd91bd  vmovaps [rsp+0x50], xmm6
00007fa22efd91c3  vmovaps [rsp+0x60], xmm7
00007fa22efd91c9  vmovaps [rsp+0x70], xmm8
00007fa22efd91cf  vmovaps [rsp+0x80], xmm9
00007fa22efd91d8  vmovaps [rsp+0x90], xmm10
00007fa22efd91e1  vmovaps [rsp+0xA0], xmm11
00007fa22efd91ea  vmovaps [rsp+0xB0], xmm12
00007fa22efd91f3  vmovaps [rsp+0xC0], xmm13
00007fa22efd91fc  vmovaps [rsp+0xD0], xmm14
00007fa22efd9205  vmovaps [rsp+0xE0], xmm15
00007fa22efd920e  sub rsp, 0x30
00007fa22efd9212  movaps [rsp], xmm5
00007fa22efd9216  movaps [rsp+0x10], xmm8
00007fa22efd921c  movaps [rsp+0x20], xmm6
00007fa22efd9221  lea rdi, [rsp]
00007fa22efd9225  mov esi, 0x00
00007fa22efd922a  mov rax, 0x5E9D1A57D530
00007fa22efd9234  call rax
00007fa22efd9236  movaps xmm5, [rsp]
00007fa22efd923a  add rsp, 0x30
00007fa22efd923e  vmovaps xmm0, [rsp]
00007fa22efd9243  vmovaps xmm1, [rsp+0x10]
00007fa22efd9249  vmovaps xmm2, [rsp+0x20]
00007fa22efd924f  vmovaps xmm3, [rsp+0x30]
00007fa22efd9255  vmovaps xmm4, [rsp+0x40]
00007fa22efd925b  vmovaps xmm6, [rsp+0x50]
00007fa22efd9261  vmovaps xmm7, [rsp+0x60]
00007fa22efd9267  vmovaps xmm8, [rsp+0x70]
00007fa22efd926d  vmovaps xmm9, [rsp+0x80]
00007fa22efd9276  vmovaps xmm10, [rsp+0x90]
00007fa22efd927f  vmovaps xmm11, [rsp+0xA0]
00007fa22efd9288  vmovaps xmm12, [rsp+0xB0]
00007fa22efd9291  vmovaps xmm13, [rsp+0xC0]
00007fa22efd929a  vmovaps xmm14, [rsp+0xD0]
00007fa22efd92a3  vmovaps xmm15, [rsp+0xE0]
00007fa22efd92ac  add rsp, 0xF0
00007fa22efd92b3  pop r11
00007fa22efd92b5  pop r10
00007fa22efd92b7  pop r9
00007fa22efd92b9  pop r8
00007fa22efd92bb  pop rsi
00007fa22efd92bc  pop rdi
00007fa22efd92bd  pop rdx
00007fa22efd92be  pop rcx
00007fa22efd92bf  pop rax
00007fa22efd92c0  add rsp, 0x08
00007fa22efd92c4  jmp 0x00007FA22EFD6200
00007fa22efd92c9  sub rsp, 0x08
00007fa22efd92cd  push rax
00007fa22efd92ce  push rcx
00007fa22efd92cf  push rdx
00007fa22efd92d0  push rdi
00007fa22efd92d1  push rsi
00007fa22efd92d2  push r8
00007fa22efd92d4  push r9
00007fa22efd92d6  push r10
00007fa22efd92d8  push r11
00007fa22efd92da  sub rsp, 0xF0
00007fa22efd92e1  vmovaps [rsp], xmm0
00007fa22efd92e6  vmovaps [rsp+0x10], xmm1
00007fa22efd92ec  vmovaps [rsp+0x20], xmm2
00007fa22efd92f2  vmovaps [rsp+0x30], xmm3
00007fa22efd92f8  vmovaps [rsp+0x40], xmm4
00007fa22efd92fe  vmovaps [rsp+0x50], xmm5
00007fa22efd9304  vmovaps [rsp+0x60], xmm7
00007fa22efd930a  vmovaps [rsp+0x70], xmm8
00007fa22efd9310  vmovaps [rsp+0x80], xmm9
00007fa22efd9319  vmovaps [rsp+0x90], xmm10
00007fa22efd9322  vmovaps [rsp+0xA0], xmm11
00007fa22efd932b  vmovaps [rsp+0xB0], xmm12
00007fa22efd9334  vmovaps [rsp+0xC0], xmm13
00007fa22efd933d  vmovaps [rsp+0xD0], xmm14
00007fa22efd9346  vmovaps [rsp+0xE0], xmm15
00007fa22efd934f  sub rsp, 0x30
00007fa22efd9353  movaps [rsp], xmm6
00007fa22efd9357  movaps [rsp+0x10], xmm10
00007fa22efd935d  movaps [rsp+0x20], xmm8
00007fa22efd9363  lea rdi, [rsp]
00007fa22efd9367  mov esi, 0x00
00007fa22efd936c  mov rax, 0x5E9D1A57D530
00007fa22efd9376  call rax
00007fa22efd9378  movaps xmm6, [rsp]
00007fa22efd937c  add rsp, 0x30
00007fa22efd9380  vmovaps xmm0, [rsp]
00007fa22efd9385  vmovaps xmm1, [rsp+0x10]
00007fa22efd938b  vmovaps xmm2, [rsp+0x20]
00007fa22efd9391  vmovaps xmm3, [rsp+0x30]
00007fa22efd9397  vmovaps xmm4, [rsp+0x40]
00007fa22efd939d  vmovaps xmm5, [rsp+0x50]
00007fa22efd93a3  vmovaps xmm7, [rsp+0x60]
00007fa22efd93a9  vmovaps xmm8, [rsp+0x70]
00007fa22efd93af  vmovaps xmm9, [rsp+0x80]
00007fa22efd93b8  vmovaps xmm10, [rsp+0x90]
00007fa22efd93c1  vmovaps xmm11, [rsp+0xA0]
00007fa22efd93ca  vmovaps xmm12, [rsp+0xB0]
00007fa22efd93d3  vmovaps xmm13, [rsp+0xC0]
00007fa22efd93dc  vmovaps xmm14, [rsp+0xD0]
00007fa22efd93e5  vmovaps xmm15, [rsp+0xE0]
00007fa22efd93ee  add rsp, 0xF0
00007fa22efd93f5  pop r11
00007fa22efd93f7  pop r10
00007fa22efd93f9  pop r9
00007fa22efd93fb  pop r8
00007fa22efd93fd  pop rsi
00007fa22efd93fe  pop rdi
00007fa22efd93ff  pop rdx
00007fa22efd9400  pop rcx
00007fa22efd9401  pop rax
00007fa22efd9402  add rsp, 0x08
00007fa22efd9406  jmp 0x00007FA22EFD6225
00007fa22efd940b  sub rsp, 0x08
00007fa22efd940f  push rax
00007fa22efd9410  push rcx
00007fa22efd9411  push rdx
00007fa22efd9412  push rdi
00007fa22efd9413  push rsi
00007fa22efd9414  push r8
00007fa22efd9416  push r9
00007fa22efd9418  push r10
00007fa22efd941a  push r11
00007fa22efd941c  sub rsp, 0xF0
00007fa22efd9423  vmovaps [rsp], xmm0
00007fa22efd9428  vmovaps [rsp+0x10], xmm1
00007fa22efd942e  vmovaps [rsp+0x20], xmm2
00007fa22efd9434  vmovaps [rsp+0x30], xmm3
00007fa22efd943a  vmovaps [rsp+0x40], xmm4
00007fa22efd9440  vmovaps [rsp+0x50], xmm5
00007fa22efd9446  vmovaps [rsp+0x60], xmm6
00007fa22efd944c  vmovaps [rsp+0x70], xmm7
00007fa22efd9452  vmovaps [rsp+0x80], xmm8
00007fa22efd945b  vmovaps [rsp+0x90], xmm9
00007fa22efd9464  vmovaps [rsp+0xA0], xmm11
00007fa22efd946d  vmovaps [rsp+0xB0], xmm12
00007fa22efd9476  vmovaps [rsp+0xC0], xmm13
00007fa22efd947f  vmovaps [rsp+0xD0], xmm14
00007fa22efd9488  vmovaps [rsp+0xE0], xmm15
00007fa22efd9491  sub rsp, 0x30
00007fa22efd9495  movaps [rsp], xmm10
00007fa22efd949a  movaps [rsp+0x10], xmm8
00007fa22efd94a0  movaps [rsp+0x20], xmm14
00007fa22efd94a6  lea rdi, [rsp]
00007fa22efd94aa  mov esi, 0x00
00007fa22efd94af  mov rax, 0x5E9D1A57D530
00007fa22efd94b9  call rax
00007fa22efd94bb  movaps xmm10, [rsp]
00007fa22efd94c0  add rsp, 0x30
00007fa22efd94c4  vmovaps xmm0, [rsp]
00007fa22efd94c9  vmovaps xmm1, [rsp+0x10]
00007fa22efd94cf  vmovaps xmm2, [rsp+0x20]
00007fa22efd94d5  vmovaps xmm3, [rsp+0x30]
00007fa22efd94db  vmovaps xmm4, [rsp+0x40]
00007fa22efd94e1  vmovaps xmm5, [rsp+0x50]
00007fa22efd94e7  vmovaps xmm6, [rsp+0x60]
00007fa22efd94ed  vmovaps xmm7, [rsp+0x70]
00007fa22efd94f3  vmovaps xmm8, [rsp+0x80]
00007fa22efd94fc  vmovaps xmm9, [rsp+0x90]
00007fa22efd9505  vmovaps xmm11, [rsp+0xA0]
00007fa22efd950e  vmovaps xmm12, [rsp+0xB0]
00007fa22efd9517  vmovaps xmm13, [rsp+0xC0]
00007fa22efd9520  vmovaps xmm14, [rsp+0xD0]
00007fa22efd9529  vmovaps xmm15, [rsp+0xE0]
00007fa22efd9532  add rsp, 0xF0
00007fa22efd9539  pop r11
00007fa22efd953b  pop r10
00007fa22efd953d  pop r9
00007fa22efd953f  pop r8
00007fa22efd9541  pop rsi
00007fa22efd9542  pop rdi
00007fa22efd9543  pop rdx
00007fa22efd9544  pop rcx
00007fa22efd9545  pop rax
00007fa22efd9546  add rsp, 0x08
00007fa22efd954a  jmp 0x00007FA22EFD6245
00007fa22efd954f  sub rsp, 0x08
00007fa22efd9553  push rax
00007fa22efd9554  push rcx
00007fa22efd9555  push rdx
00007fa22efd9556  push rdi
00007fa22efd9557  push rsi
00007fa22efd9558  push r8
00007fa22efd955a  push r9
00007fa22efd955c  push r10
00007fa22efd955e  push r11
00007fa22efd9560  sub rsp, 0xF0
00007fa22efd9567  vmovaps [rsp], xmm0
00007fa22efd956c  vmovaps [rsp+0x10], xmm1
00007fa22efd9572  vmovaps [rsp+0x20], xmm2
00007fa22efd9578  vmovaps [rsp+0x30], xmm3
00007fa22efd957e  vmovaps [rsp+0x40], xmm4
00007fa22efd9584  vmovaps [rsp+0x50], xmm5
00007fa22efd958a  vmovaps [rsp+0x60], xmm6
00007fa22efd9590  vmovaps [rsp+0x70], xmm7
00007fa22efd9596  vmovaps [rsp+0x80], xmm8
00007fa22efd959f  vmovaps [rsp+0x90], xmm9
00007fa22efd95a8  vmovaps [rsp+0xA0], xmm10
00007fa22efd95b1  vmovaps [rsp+0xB0], xmm11
00007fa22efd95ba  vmovaps [rsp+0xC0], xmm12
00007fa22efd95c3  vmovaps [rsp+0xD0], xmm13
00007fa22efd95cc  vmovaps [rsp+0xE0], xmm15
00007fa22efd95d5  sub rsp, 0x30
00007fa22efd95d9  movaps [rsp], xmm14
00007fa22efd95de  movaps [rsp+0x10], xmm8
00007fa22efd95e4  movaps [rsp+0x20], xmm4
00007fa22efd95e9  lea rdi, [rsp]
00007fa22efd95ed  mov esi, 0x00
00007fa22efd95f2  mov rax, 0x5E9D1A57D530
00007fa22efd95fc  call rax
00007fa22efd95fe  movaps xmm14, [rsp]
00007fa22efd9603  add rsp, 0x30
00007fa22efd9607  vmovaps xmm0, [rsp]
00007fa22efd960c  vmovaps xmm1, [rsp+0x10]
00007fa22efd9612  vmovaps xmm2, [rsp+0x20]
00007fa22efd9618  vmovaps xmm3, [rsp+0x30]
00007fa22efd961e  vmovaps xmm4, [rsp+0x40]
00007fa22efd9624  vmovaps xmm5, [rsp+0x50]
00007fa22efd962a  vmovaps xmm6, [rsp+0x60]
00007fa22efd9630  vmovaps xmm7, [rsp+0x70]
00007fa22efd9636  vmovaps xmm8, [rsp+0x80]
00007fa22efd963f  vmovaps xmm9, [rsp+0x90]
00007fa22efd9648  vmovaps xmm10, [rsp+0xA0]
00007fa22efd9651  vmovaps xmm11, [rsp+0xB0]
00007fa22efd965a  vmovaps xmm12, [rsp+0xC0]
00007fa22efd9663  vmovaps xmm13, [rsp+0xD0]
00007fa22efd966c  vmovaps xmm15, [rsp+0xE0]
00007fa22efd9675  add rsp, 0xF0
00007fa22efd967c  pop r11
00007fa22efd967e  pop r10
00007fa22efd9680  pop r9
00007fa22efd9682  pop r8
00007fa22efd9684  pop rsi
00007fa22efd9685  pop rdi
00007fa22efd9686  pop rdx
00007fa22efd9687  pop rcx
00007fa22efd9688  pop rax
00007fa22efd9689  add rsp, 0x08
00007fa22efd968d  jmp 0x00007FA22EFD6265
00007fa22efd9692  sub rsp, 0x08
00007fa22efd9696  push rax
00007fa22efd9697  push rcx
00007fa22efd9698  push rdx
00007fa22efd9699  push rdi
00007fa22efd969a  push rsi
00007fa22efd969b  push r8
00007fa22efd969d  push r9
00007fa22efd969f  push r10
00007fa22efd96a1  push r11
00007fa22efd96a3  sub rsp, 0xF0
00007fa22efd96aa  vmovaps [rsp], xmm0
00007fa22efd96af  vmovaps [rsp+0x10], xmm1
00007fa22efd96b5  vmovaps [rsp+0x20], xmm2
00007fa22efd96bb  vmovaps [rsp+0x30], xmm3
00007fa22efd96c1  vmovaps [rsp+0x40], xmm5
00007fa22efd96c7  vmovaps [rsp+0x50], xmm6
00007fa22efd96cd  vmovaps [rsp+0x60], xmm7
00007fa22efd96d3  vmovaps [rsp+0x70], xmm8
00007fa22efd96d9  vmovaps [rsp+0x80], xmm9
00007fa22efd96e2  vmovaps [rsp+0x90], xmm10
00007fa22efd96eb  vmovaps [rsp+0xA0], xmm11
00007fa22efd96f4  vmovaps [rsp+0xB0], xmm12
00007fa22efd96fd  vmovaps [rsp+0xC0], xmm13
00007fa22efd9706  vmovaps [rsp+0xD0], xmm14
00007fa22efd970f  vmovaps [rsp+0xE0], xmm15
00007fa22efd9718  sub rsp, 0x30
00007fa22efd971c  movaps [rsp], xmm4
00007fa22efd9720  movaps [rsp+0x10], xmm13
00007fa22efd9726  movaps [rsp+0x20], xmm8
00007fa22efd972c  lea rdi, [rsp]
00007fa22efd9730  mov esi, 0x00
00007fa22efd9735  mov rax, 0x5E9D1A57D530
00007fa22efd973f  call rax
00007fa22efd9741  movaps xmm4, [rsp]
00007fa22efd9745  add rsp, 0x30
00007fa22efd9749  vmovaps xmm0, [rsp]
00007fa22efd974e  vmovaps xmm1, [rsp+0x10]
00007fa22efd9754  vmovaps xmm2, [rsp+0x20]
00007fa22efd975a  vmovaps xmm3, [rsp+0x30]
00007fa22efd9760  vmovaps xmm5, [rsp+0x40]
00007fa22efd9766  vmovaps xmm6, [rsp+0x50]
00007fa22efd976c  vmovaps xmm7, [rsp+0x60]
00007fa22efd9772  vmovaps xmm8, [rsp+0x70]
00007fa22efd9778  vmovaps xmm9, [rsp+0x80]
00007fa22efd9781  vmovaps xmm10, [rsp+0x90]
00007fa22efd978a  vmovaps xmm11, [rsp+0xA0]
00007fa22efd9793  vmovaps xmm12, [rsp+0xB0]
00007fa22efd979c  vmovaps xmm13, [rsp+0xC0]
00007fa22efd97a5  vmovaps xmm14, [rsp+0xD0]
00007fa22efd97ae  vmovaps xmm15, [rsp+0xE0]
00007fa22efd97b7  add rsp, 0xF0
00007fa22efd97be  pop r11
00007fa22efd97c0  pop r10
00007fa22efd97c2  pop r9
00007fa22efd97c4  pop r8
00007fa22efd97c6  pop rsi
00007fa22efd97c7  pop rdi
00007fa22efd97c8  pop rdx
00007fa22efd97c9  pop rcx
00007fa22efd97ca  pop rax
00007fa22efd97cb  add rsp, 0x08
00007fa22efd97cf  jmp 0x00007FA22EFD628A
00007fa22efd97d4  sub rsp, 0x08
00007fa22efd97d8  push rax
00007fa22efd97d9  push rcx
00007fa22efd97da  push rdx
00007fa22efd97db  push rdi
00007fa22efd97dc  push rsi
00007fa22efd97dd  push r8
00007fa22efd97df  push r9
00007fa22efd97e1  push r10
00007fa22efd97e3  push r11
00007fa22efd97e5  sub rsp, 0xF0
00007fa22efd97ec  vmovaps [rsp], xmm0
00007fa22efd97f1  vmovaps [rsp+0x10], xmm1
00007fa22efd97f7  vmovaps [rsp+0x20], xmm2
00007fa22efd97fd  vmovaps [rsp+0x30], xmm3
00007fa22efd9803  vmovaps [rsp+0x40], xmm4
00007fa22efd9809  vmovaps [rsp+0x50], xmm5
00007fa22efd980f  vmovaps [rsp+0x60], xmm6
00007fa22efd9815  vmovaps [rsp+0x70], xmm7
00007fa22efd981b  vmovaps [rsp+0x80], xmm8
00007fa22efd9824  vmovaps [rsp+0x90], xmm9
00007fa22efd982d  vmovaps [rsp+0xA0], xmm10
00007fa22efd9836  vmovaps [rsp+0xB0], xmm11
00007fa22efd983f  vmovaps [rsp+0xC0], xmm12
00007fa22efd9848  vmovaps [rsp+0xD0], xmm14
00007fa22efd9851  vmovaps [rsp+0xE0], xmm15
00007fa22efd985a  sub rsp, 0x30
00007fa22efd985e  movaps [rsp], xmm13
00007fa22efd9863  movaps [rsp+0x10], xmm15
00007fa22efd9869  movaps [rsp+0x20], xmm9
00007fa22efd986f  lea rdi, [rsp]
00007fa22efd9873  mov esi, 0x00
00007fa22efd9878  mov rax, 0x5E9D1A57D530
00007fa22efd9882  call rax
00007fa22efd9884  movaps xmm13, [rsp]
00007fa22efd9889  add rsp, 0x30
00007fa22efd988d  vmovaps xmm0, [rsp]
00007fa22efd9892  vmovaps xmm1, [rsp+0x10]
00007fa22efd9898  vmovaps xmm2, [rsp+0x20]
00007fa22efd989e  vmovaps xmm3, [rsp+0x30]
00007fa22efd98a4  vmovaps xmm4, [rsp+0x40]
00007fa22efd98aa  vmovaps xmm5, [rsp+0x50]
00007fa22efd98b0  vmovaps xmm6, [rsp+0x60]
00007fa22efd98b6  vmovaps xmm7, [rsp+0x70]
00007fa22efd98bc  vmovaps xmm8, [rsp+0x80]
00007fa22efd98c5  vmovaps xmm9, [rsp+0x90]
00007fa22efd98ce  vmovaps xmm10, [rsp+0xA0]
00007fa22efd98d7  vmovaps xmm11, [rsp+0xB0]
00007fa22efd98e0  vmovaps xmm12, [rsp+0xC0]
00007fa22efd98e9  vmovaps xmm14, [rsp+0xD0]
00007fa22efd98f2  vmovaps xmm15, [rsp+0xE0]
00007fa22efd98fb  add rsp, 0xF0
00007fa22efd9902  pop r11
00007fa22efd9904  pop r10
00007fa22efd9906  pop r9
00007fa22efd9908  pop r8
00007fa22efd990a  pop rsi
00007fa22efd990b  pop rdi
00007fa22efd990c  pop rdx
00007fa22efd990d  pop rcx
00007fa22efd990e  pop rax
00007fa22efd990f  add rsp, 0x08
00007fa22efd9913  jmp 0x00007FA22EFD62A5
00007fa22efd9918  sub rsp, 0x08
00007fa22efd991c  push rax
00007fa22efd991d  push rcx
00007fa22efd991e  push rdx
00007fa22efd991f  push rdi
00007fa22efd9920  push rsi
00007fa22efd9921  push r8
00007fa22efd9923  push r9
00007fa22efd9925  push r10
00007fa22efd9927  push r11
00007fa22efd9929  sub rsp, 0xF0
00007fa22efd9930  vmovaps [rsp], xmm0
00007fa22efd9935  vmovaps [rsp+0x10], xmm1
00007fa22efd993b  vmovaps [rsp+0x20], xmm2
00007fa22efd9941  vmovaps [rsp+0x30], xmm3
00007fa22efd9947  vmovaps [rsp+0x40], xmm4
00007fa22efd994d  vmovaps [rsp+0x50], xmm5
00007fa22efd9953  vmovaps [rsp+0x60], xmm6
00007fa22efd9959  vmovaps [rsp+0x70], xmm7
00007fa22efd995f  vmovaps [rsp+0x80], xmm8
00007fa22efd9968  vmovaps [rsp+0x90], xmm9
00007fa22efd9971  vmovaps [rsp+0xA0], xmm10
00007fa22efd997a  vmovaps [rsp+0xB0], xmm11
00007fa22efd9983  vmovaps [rsp+0xC0], xmm12
00007fa22efd998c  vmovaps [rsp+0xD0], xmm13
00007fa22efd9995  vmovaps [rsp+0xE0], xmm14
00007fa22efd999e  sub rsp, 0x30
00007fa22efd99a2  movaps [rsp], xmm15
00007fa22efd99a7  movaps [rsp+0x10], xmm1
00007fa22efd99ac  movaps [rsp+0x20], xmm5
00007fa22efd99b1  lea rdi, [rsp]
00007fa22efd99b5  mov esi, 0x00
00007fa22efd99ba  mov rax, 0x5E9D1A57D530
00007fa22efd99c4  call rax
00007fa22efd99c6  movaps xmm15, [rsp]
00007fa22efd99cb  add rsp, 0x30
00007fa22efd99cf  vmovaps xmm0, [rsp]
00007fa22efd99d4  vmovaps xmm1, [rsp+0x10]
00007fa22efd99da  vmovaps xmm2, [rsp+0x20]
00007fa22efd99e0  vmovaps xmm3, [rsp+0x30]
00007fa22efd99e6  vmovaps xmm4, [rsp+0x40]
00007fa22efd99ec  vmovaps xmm5, [rsp+0x50]
00007fa22efd99f2  vmovaps xmm6, [rsp+0x60]
00007fa22efd99f8  vmovaps xmm7, [rsp+0x70]
00007fa22efd99fe  vmovaps xmm8, [rsp+0x80]
00007fa22efd9a07  vmovaps xmm9, [rsp+0x90]
00007fa22efd9a10  vmovaps xmm10, [rsp+0xA0]
00007fa22efd9a19  vmovaps xmm11, [rsp+0xB0]
00007fa22efd9a22  vmovaps xmm12, [rsp+0xC0]
00007fa22efd9a2b  vmovaps xmm13, [rsp+0xD0]
00007fa22efd9a34  vmovaps xmm14, [rsp+0xE0]
00007fa22efd9a3d  add rsp, 0xF0
00007fa22efd9a44  pop r11
00007fa22efd9a46  pop r10
00007fa22efd9a48  pop r9
00007fa22efd9a4a  pop r8
00007fa22efd9a4c  pop rsi
00007fa22efd9a4d  pop rdi
00007fa22efd9a4e  pop rdx
00007fa22efd9a4f  pop rcx
00007fa22efd9a50  pop rax
00007fa22efd9a51  add rsp, 0x08
00007fa22efd9a55  jmp 0x00007FA22EFD62C0
00007fa22efd9a5a  call 0x00007FA22EED64F0
00007fa22efd9a5f  jmp 0x00007FA22EFD631B
00007fa22efd9a64  sub rsp, 0x08
00007fa22efd9a68  push rax
00007fa22efd9a69  push rcx
00007fa22efd9a6a  push rdx
00007fa22efd9a6b  push rdi
00007fa22efd9a6c  push rsi
00007fa22efd9a6d  push r8
00007fa22efd9a6f  push r9
00007fa22efd9a71  push r10
00007fa22efd9a73  push r11
00007fa22efd9a75  sub rsp, 0xF0
00007fa22efd9a7c  vmovaps [rsp], xmm0
00007fa22efd9a81  vmovaps [rsp+0x10], xmm1
00007fa22efd9a87  vmovaps [rsp+0x20], xmm2
00007fa22efd9a8d  vmovaps [rsp+0x30], xmm3
00007fa22efd9a93  vmovaps [rsp+0x40], xmm4
00007fa22efd9a99  vmovaps [rsp+0x50], xmm5
00007fa22efd9a9f  vmovaps [rsp+0x60], xmm6
00007fa22efd9aa5  vmovaps [rsp+0x70], xmm7
00007fa22efd9aab  vmovaps [rsp+0x80], xmm8
00007fa22efd9ab4  vmovaps [rsp+0x90], xmm10
00007fa22efd9abd  vmovaps [rsp+0xA0], xmm11
00007fa22efd9ac6  vmovaps [rsp+0xB0], xmm12
00007fa22efd9acf  vmovaps [rsp+0xC0], xmm13
00007fa22efd9ad8  vmovaps [rsp+0xD0], xmm14
00007fa22efd9ae1  vmovaps [rsp+0xE0], xmm15
00007fa22efd9aea  sub rsp, 0x30
00007fa22efd9aee  movaps [rsp], xmm9
00007fa22efd9af3  movaps [rsp+0x10], xmm8
00007fa22efd9af9  movaps [rsp+0x20], xmm11
00007fa22efd9aff  lea rdi, [rsp]
00007fa22efd9b03  mov esi, 0x00
00007fa22efd9b08  mov rax, 0x5E9D1A57D530
00007fa22efd9b12  call rax
00007fa22efd9b14  movaps xmm9, [rsp]
00007fa22efd9b19  add rsp, 0x30
00007fa22efd9b1d  vmovaps xmm0, [rsp]
00007fa22efd9b22  vmovaps xmm1, [rsp+0x10]
00007fa22efd9b28  vmovaps xmm2, [rsp+0x20]
00007fa22efd9b2e  vmovaps xmm3, [rsp+0x30]
00007fa22efd9b34  vmovaps xmm4, [rsp+0x40]
00007fa22efd9b3a  vmovaps xmm5, [rsp+0x50]
00007fa22efd9b40  vmovaps xmm6, [rsp+0x60]
00007fa22efd9b46  vmovaps xmm7, [rsp+0x70]
00007fa22efd9b4c  vmovaps xmm8, [rsp+0x80]
00007fa22efd9b55  vmovaps xmm10, [rsp+0x90]
00007fa22efd9b5e  vmovaps xmm11, [rsp+0xA0]
00007fa22efd9b67  vmovaps xmm12, [rsp+0xB0]
00007fa22efd9b70  vmovaps xmm13, [rsp+0xC0]
00007fa22efd9b79  vmovaps xmm14, [rsp+0xD0]
00007fa22efd9b82  vmovaps xmm15, [rsp+0xE0]
00007fa22efd9b8b  add rsp, 0xF0
00007fa22efd9b92  pop r11
00007fa22efd9b94  pop r10
00007fa22efd9b96  pop r9
00007fa22efd9b98  pop r8
00007fa22efd9b9a  pop rsi
00007fa22efd9b9b  pop rdi
00007fa22efd9b9c  pop rdx
00007fa22efd9b9d  pop rcx
00007fa22efd9b9e  pop rax
00007fa22efd9b9f  add rsp, 0x08
00007fa22efd9ba3  jmp 0x00007FA22EFD6352
00007fa22efd9ba8  sub rsp, 0x08
00007fa22efd9bac  push rax
00007fa22efd9bad  push rcx
00007fa22efd9bae  push rdx
00007fa22efd9baf  push rdi
00007fa22efd9bb0  push rsi
00007fa22efd9bb1  push r8
00007fa22efd9bb3  push r9
00007fa22efd9bb5  push r10
00007fa22efd9bb7  push r11
00007fa22efd9bb9  sub rsp, 0xF0
00007fa22efd9bc0  vmovaps [rsp], xmm0
00007fa22efd9bc5  vmovaps [rsp+0x10], xmm1
00007fa22efd9bcb  vmovaps [rsp+0x20], xmm2
00007fa22efd9bd1  vmovaps [rsp+0x30], xmm3
00007fa22efd9bd7  vmovaps [rsp+0x40], xmm4
00007fa22efd9bdd  vmovaps [rsp+0x50], xmm5
00007fa22efd9be3  vmovaps [rsp+0x60], xmm6
00007fa22efd9be9  vmovaps [rsp+0x70], xmm7
00007fa22efd9bef  vmovaps [rsp+0x80], xmm8
00007fa22efd9bf8  vmovaps [rsp+0x90], xmm9
00007fa22efd9c01  vmovaps [rsp+0xA0], xmm10
00007fa22efd9c0a  vmovaps [rsp+0xB0], xmm12
00007fa22efd9c13  vmovaps [rsp+0xC0], xmm13
00007fa22efd9c1c  vmovaps [rsp+0xD0], xmm14
00007fa22efd9c25  vmovaps [rsp+0xE0], xmm15
00007fa22efd9c2e  sub rsp, 0x30
00007fa22efd9c32  movaps [rsp], xmm11
00007fa22efd9c37  movaps [rsp+0x10], xmm10
00007fa22efd9c3d  movaps [rsp+0x20], xmm6
00007fa22efd9c42  lea rdi, [rsp]
00007fa22efd9c46  mov esi, 0x00
00007fa22efd9c4b  mov rax, 0x5E9D1A57D530
00007fa22efd9c55  call rax
00007fa22efd9c57  movaps xmm11, [rsp]
00007fa22efd9c5c  add rsp, 0x30
00007fa22efd9c60  vmovaps xmm0, [rsp]
00007fa22efd9c65  vmovaps xmm1, [rsp+0x10]
00007fa22efd9c6b  vmovaps xmm2, [rsp+0x20]
00007fa22efd9c71  vmovaps xmm3, [rsp+0x30]
00007fa22efd9c77  vmovaps xmm4, [rsp+0x40]
00007fa22efd9c7d  vmovaps xmm5, [rsp+0x50]
00007fa22efd9c83  vmovaps xmm6, [rsp+0x60]
00007fa22efd9c89  vmovaps xmm7, [rsp+0x70]
00007fa22efd9c8f  vmovaps xmm8, [rsp+0x80]
00007fa22efd9c98  vmovaps xmm9, [rsp+0x90]
00007fa22efd9ca1  vmovaps xmm10, [rsp+0xA0]
00007fa22efd9caa  vmovaps xmm12, [rsp+0xB0]
00007fa22efd9cb3  vmovaps xmm13, [rsp+0xC0]
00007fa22efd9cbc  vmovaps xmm14, [rsp+0xD0]
00007fa22efd9cc5  vmovaps xmm15, [rsp+0xE0]
00007fa22efd9cce  add rsp, 0xF0
00007fa22efd9cd5  pop r11
00007fa22efd9cd7  pop r10
00007fa22efd9cd9  pop r9
00007fa22efd9cdb  pop r8
00007fa22efd9cdd  pop rsi
00007fa22efd9cde  pop rdi
00007fa22efd9cdf  pop rdx
00007fa22efd9ce0  pop rcx
00007fa22efd9ce1  pop rax
00007fa22efd9ce2  add rsp, 0x08
00007fa22efd9ce6  jmp 0x00007FA22EFD636D
00007fa22efd9ceb  sub rsp, 0x08
00007fa22efd9cef  push rax
00007fa22efd9cf0  push rcx
00007fa22efd9cf1  push rdx
00007fa22efd9cf2  push rdi
00007fa22efd9cf3  push rsi
00007fa22efd9cf4  push r8
00007fa22efd9cf6  push r9
00007fa22efd9cf8  push r10
00007fa22efd9cfa  push r11
00007fa22efd9cfc  sub rsp, 0xF0
00007fa22efd9d03  vmovaps [rsp], xmm0
00007fa22efd9d08  vmovaps [rsp+0x10], xmm1
00007fa22efd9d0e  vmovaps [rsp+0x20], xmm2
00007fa22efd9d14  vmovaps [rsp+0x30], xmm3
00007fa22efd9d1a  vmovaps [rsp+0x40], xmm4
00007fa22efd9d20  vmovaps [rsp+0x50], xmm5
00007fa22efd9d26  vmovaps [rsp+0x60], xmm6
00007fa22efd9d2c  vmovaps [rsp+0x70], xmm7
00007fa22efd9d32  vmovaps [rsp+0x80], xmm8
00007fa22efd9d3b  vmovaps [rsp+0x90], xmm9
00007fa22efd9d44  vmovaps [rsp+0xA0], xmm11
00007fa22efd9d4d  vmovaps [rsp+0xB0], xmm12
00007fa22efd9d56  vmovaps [rsp+0xC0], xmm13
00007fa22efd9d5f  vmovaps [rsp+0xD0], xmm14
00007fa22efd9d68  vmovaps [rsp+0xE0], xmm15
00007fa22efd9d71  sub rsp, 0x30
00007fa22efd9d75  movaps [rsp], xmm10
00007fa22efd9d7a  movaps [rsp+0x10], xmm14
00007fa22efd9d80  movaps [rsp+0x20], xmm4
00007fa22efd9d85  lea rdi, [rsp]
00007fa22efd9d89  mov esi, 0x00
00007fa22efd9d8e  mov rax, 0x5E9D1A57D530
00007fa22efd9d98  call rax
00007fa22efd9d9a  movaps xmm10, [rsp]
00007fa22efd9d9f  add rsp, 0x30
00007fa22efd9da3  vmovaps xmm0, [rsp]
00007fa22efd9da8  vmovaps xmm1, [rsp+0x10]
00007fa22efd9dae  vmovaps xmm2, [rsp+0x20]
00007fa22efd9db4  vmovaps xmm3, [rsp+0x30]
00007fa22efd9dba  vmovaps xmm4, [rsp+0x40]
00007fa22efd9dc0  vmovaps xmm5, [rsp+0x50]
00007fa22efd9dc6  vmovaps xmm6, [rsp+0x60]
00007fa22efd9dcc  vmovaps xmm7, [rsp+0x70]
00007fa22efd9dd2  vmovaps xmm8, [rsp+0x80]
00007fa22efd9ddb  vmovaps xmm9, [rsp+0x90]
00007fa22efd9de4  vmovaps xmm11, [rsp+0xA0]
00007fa22efd9ded  vmovaps xmm12, [rsp+0xB0]
00007fa22efd9df6  vmovaps xmm13, [rsp+0xC0]
00007fa22efd9dff  vmovaps xmm14, [rsp+0xD0]
00007fa22efd9e08  vmovaps xmm15, [rsp+0xE0]
00007fa22efd9e11  add rsp, 0xF0
00007fa22efd9e18  pop r11
00007fa22efd9e1a  pop r10
00007fa22efd9e1c  pop r9
00007fa22efd9e1e  pop r8
00007fa22efd9e20  pop rsi
00007fa22efd9e21  pop rdi
00007fa22efd9e22  pop rdx
00007fa22efd9e23  pop rcx
00007fa22efd9e24  pop rax
00007fa22efd9e25  add rsp, 0x08
00007fa22efd9e29  jmp 0x00007FA22EFD6388
00007fa22efd9e2e  sub rsp, 0x08
00007fa22efd9e32  push rax
00007fa22efd9e33  push rcx
00007fa22efd9e34  push rdx
00007fa22efd9e35  push rdi
00007fa22efd9e36  push rsi
00007fa22efd9e37  push r8
00007fa22efd9e39  push r9
00007fa22efd9e3b  push r10
00007fa22efd9e3d  push r11
00007fa22efd9e3f  sub rsp, 0xF0
00007fa22efd9e46  vmovaps [rsp], xmm0
00007fa22efd9e4b  vmovaps [rsp+0x10], xmm1
00007fa22efd9e51  vmovaps [rsp+0x20], xmm2
00007fa22efd9e57  vmovaps [rsp+0x30], xmm3
00007fa22efd9e5d  vmovaps [rsp+0x40], xmm4
00007fa22efd9e63  vmovaps [rsp+0x50], xmm5
00007fa22efd9e69  vmovaps [rsp+0x60], xmm6
00007fa22efd9e6f  vmovaps [rsp+0x70], xmm7
00007fa22efd9e75  vmovaps [rsp+0x80], xmm9
00007fa22efd9e7e  vmovaps [rsp+0x90], xmm10
00007fa22efd9e87  vmovaps [rsp+0xA0], xmm11
00007fa22efd9e90  vmovaps [rsp+0xB0], xmm12
00007fa22efd9e99  vmovaps [rsp+0xC0], xmm13
00007fa22efd9ea2  vmovaps [rsp+0xD0], xmm14
00007fa22efd9eab  vmovaps [rsp+0xE0], xmm15
00007fa22efd9eb4  sub rsp, 0x30
00007fa22efd9eb8  movaps [rsp], xmm8
00007fa22efd9ebd  movaps [rsp+0x10], xmm1
00007fa22efd9ec2  movaps [rsp+0x20], xmm14
00007fa22efd9ec8  lea rdi, [rsp]
00007fa22efd9ecc  mov esi, 0x00
00007fa22efd9ed1  mov rax, 0x5E9D1A57D530
00007fa22efd9edb  call rax
00007fa22efd9edd  movaps xmm8, [rsp]
00007fa22efd9ee2  add rsp, 0x30
00007fa22efd9ee6  vmovaps xmm0, [rsp]
00007fa22efd9eeb  vmovaps xmm1, [rsp+0x10]
00007fa22efd9ef1  vmovaps xmm2, [rsp+0x20]
00007fa22efd9ef7  vmovaps xmm3, [rsp+0x30]
00007fa22efd9efd  vmovaps xmm4, [rsp+0x40]
00007fa22efd9f03  vmovaps xmm5, [rsp+0x50]
00007fa22efd9f09  vmovaps xmm6, [rsp+0x60]
00007fa22efd9f0f  vmovaps xmm7, [rsp+0x70]
00007fa22efd9f15  vmovaps xmm9, [rsp+0x80]
00007fa22efd9f1e  vmovaps xmm10, [rsp+0x90]
00007fa22efd9f27  vmovaps xmm11, [rsp+0xA0]
00007fa22efd9f30  vmovaps xmm12, [rsp+0xB0]
00007fa22efd9f39  vmovaps xmm13, [rsp+0xC0]
00007fa22efd9f42  vmovaps xmm14, [rsp+0xD0]
00007fa22efd9f4b  vmovaps xmm15, [rsp+0xE0]
00007fa22efd9f54  add rsp, 0xF0
00007fa22efd9f5b  pop r11
00007fa22efd9f5d  pop r10
00007fa22efd9f5f  pop r9
00007fa22efd9f61  pop r8
00007fa22efd9f63  pop rsi
00007fa22efd9f64  pop rdi
00007fa22efd9f65  pop rdx
00007fa22efd9f66  pop rcx
00007fa22efd9f67  pop rax
00007fa22efd9f68  add rsp, 0x08
00007fa22efd9f6c  jmp 0x00007FA22EFD63AE
00007fa22efd9f71  sub rsp, 0x08
00007fa22efd9f75  push rax
00007fa22efd9f76  push rcx
00007fa22efd9f77  push rdx
00007fa22efd9f78  push rdi
00007fa22efd9f79  push rsi
00007fa22efd9f7a  push r8
00007fa22efd9f7c  push r9
00007fa22efd9f7e  push r10
00007fa22efd9f80  push r11
00007fa22efd9f82  sub rsp, 0xF0
00007fa22efd9f89  vmovaps [rsp], xmm0
00007fa22efd9f8e  vmovaps [rsp+0x10], xmm1
00007fa22efd9f94  vmovaps [rsp+0x20], xmm2
00007fa22efd9f9a  vmovaps [rsp+0x30], xmm3
00007fa22efd9fa0  vmovaps [rsp+0x40], xmm4
00007fa22efd9fa6  vmovaps [rsp+0x50], xmm5
00007fa22efd9fac  vmovaps [rsp+0x60], xmm7
00007fa22efd9fb2  vmovaps [rsp+0x70], xmm8
00007fa22efd9fb8  vmovaps [rsp+0x80], xmm9
00007fa22efd9fc1  vmovaps [rsp+0x90], xmm10
00007fa22efd9fca  vmovaps [rsp+0xA0], xmm11
00007fa22efd9fd3  vmovaps [rsp+0xB0], xmm12
00007fa22efd9fdc  vmovaps [rsp+0xC0], xmm13
00007fa22efd9fe5  vmovaps [rsp+0xD0], xmm14
00007fa22efd9fee  vmovaps [rsp+0xE0], xmm15
00007fa22efd9ff7  sub rsp, 0x30
00007fa22efd9ffb  movaps [rsp], xmm6
00007fa22efd9fff  movaps [rsp+0x10], xmm1
00007fa22efda004  movaps [rsp+0x20], xmm14
00007fa22efda00a  lea rdi, [rsp]
00007fa22efda00e  mov esi, 0x00
00007fa22efda013  mov rax, 0x5E9D1A57D530
00007fa22efda01d  call rax
00007fa22efda01f  movaps xmm6, [rsp]
00007fa22efda023  add rsp, 0x30
00007fa22efda027  vmovaps xmm0, [rsp]
00007fa22efda02c  vmovaps xmm1, [rsp+0x10]
00007fa22efda032  vmovaps xmm2, [rsp+0x20]
00007fa22efda038  vmovaps xmm3, [rsp+0x30]
00007fa22efda03e  vmovaps xmm4, [rsp+0x40]
00007fa22efda044  vmovaps xmm5, [rsp+0x50]
00007fa22efda04a  vmovaps xmm7, [rsp+0x60]
00007fa22efda050  vmovaps xmm8, [rsp+0x70]
00007fa22efda056  vmovaps xmm9, [rsp+0x80]
00007fa22efda05f  vmovaps xmm10, [rsp+0x90]
00007fa22efda068  vmovaps xmm11, [rsp+0xA0]
00007fa22efda071  vmovaps xmm12, [rsp+0xB0]
00007fa22efda07a  vmovaps xmm13, [rsp+0xC0]
00007fa22efda083  vmovaps xmm14, [rsp+0xD0]
00007fa22efda08c  vmovaps xmm15, [rsp+0xE0]
00007fa22efda095  add rsp, 0xF0
00007fa22efda09c  pop r11
00007fa22efda09e  pop r10
00007fa22efda0a0  pop r9
00007fa22efda0a2  pop r8
00007fa22efda0a4  pop rsi
00007fa22efda0a5  pop rdi
00007fa22efda0a6  pop rdx
00007fa22efda0a7  pop rcx
00007fa22efda0a8  pop rax
00007fa22efda0a9  add rsp, 0x08
00007fa22efda0ad  jmp 0x00007FA22EFD63DA
00007fa22efda0b2  sub rsp, 0x08
00007fa22efda0b6  push rax
00007fa22efda0b7  push rcx
00007fa22efda0b8  push rdx
00007fa22efda0b9  push rdi
00007fa22efda0ba  push rsi
00007fa22efda0bb  push r8
00007fa22efda0bd  push r9
00007fa22efda0bf  push r10
00007fa22efda0c1  push r11
00007fa22efda0c3  sub rsp, 0xF0
00007fa22efda0ca  vmovaps [rsp], xmm0
00007fa22efda0cf  vmovaps [rsp+0x10], xmm1
00007fa22efda0d5  vmovaps [rsp+0x20], xmm2
00007fa22efda0db  vmovaps [rsp+0x30], xmm3
00007fa22efda0e1  vmovaps [rsp+0x40], xmm4
00007fa22efda0e7  vmovaps [rsp+0x50], xmm5
00007fa22efda0ed  vmovaps [rsp+0x60], xmm6
00007fa22efda0f3  vmovaps [rsp+0x70], xmm7
00007fa22efda0f9  vmovaps [rsp+0x80], xmm8
00007fa22efda102  vmovaps [rsp+0x90], xmm9
00007fa22efda10b  vmovaps [rsp+0xA0], xmm10
00007fa22efda114  vmovaps [rsp+0xB0], xmm11
00007fa22efda11d  vmovaps [rsp+0xC0], xmm12
00007fa22efda126  vmovaps [rsp+0xD0], xmm13
00007fa22efda12f  vmovaps [rsp+0xE0], xmm15
00007fa22efda138  sub rsp, 0x30
00007fa22efda13c  movaps [rsp], xmm14
00007fa22efda141  movaps [rsp+0x10], xmm12
00007fa22efda147  movaps [rsp+0x20], xmm1
00007fa22efda14c  lea rdi, [rsp]
00007fa22efda150  mov esi, 0x00
00007fa22efda155  mov rax, 0x5E9D1A57D530
00007fa22efda15f  call rax
00007fa22efda161  movaps xmm14, [rsp]
00007fa22efda166  add rsp, 0x30
00007fa22efda16a  vmovaps xmm0, [rsp]
00007fa22efda16f  vmovaps xmm1, [rsp+0x10]
00007fa22efda175  vmovaps xmm2, [rsp+0x20]
00007fa22efda17b  vmovaps xmm3, [rsp+0x30]
00007fa22efda181  vmovaps xmm4, [rsp+0x40]
00007fa22efda187  vmovaps xmm5, [rsp+0x50]
00007fa22efda18d  vmovaps xmm6, [rsp+0x60]
00007fa22efda193  vmovaps xmm7, [rsp+0x70]
00007fa22efda199  vmovaps xmm8, [rsp+0x80]
00007fa22efda1a2  vmovaps xmm9, [rsp+0x90]
00007fa22efda1ab  vmovaps xmm10, [rsp+0xA0]
00007fa22efda1b4  vmovaps xmm11, [rsp+0xB0]
00007fa22efda1bd  vmovaps xmm12, [rsp+0xC0]
00007fa22efda1c6  vmovaps xmm13, [rsp+0xD0]
00007fa22efda1cf  vmovaps xmm15, [rsp+0xE0]
00007fa22efda1d8  add rsp, 0xF0
00007fa22efda1df  pop r11
00007fa22efda1e1  pop r10
00007fa22efda1e3  pop r9
00007fa22efda1e5  pop r8
00007fa22efda1e7  pop rsi
00007fa22efda1e8  pop rdi
00007fa22efda1e9  pop rdx
00007fa22efda1ea  pop rcx
00007fa22efda1eb  pop rax
00007fa22efda1ec  add rsp, 0x08
00007fa22efda1f0  jmp 0x00007FA22EFD6400
00007fa22efda1f5  sub rsp, 0x08
00007fa22efda1f9  push rax
00007fa22efda1fa  push rcx
00007fa22efda1fb  push rdx
00007fa22efda1fc  push rdi
00007fa22efda1fd  push rsi
00007fa22efda1fe  push r8
00007fa22efda200  push r9
00007fa22efda202  push r10
00007fa22efda204  push r11
00007fa22efda206  sub rsp, 0xF0
00007fa22efda20d  vmovaps [rsp], xmm0
00007fa22efda212  vmovaps [rsp+0x10], xmm2
00007fa22efda218  vmovaps [rsp+0x20], xmm3
00007fa22efda21e  vmovaps [rsp+0x30], xmm4
00007fa22efda224  vmovaps [rsp+0x40], xmm5
00007fa22efda22a  vmovaps [rsp+0x50], xmm6
00007fa22efda230  vmovaps [rsp+0x60], xmm7
00007fa22efda236  vmovaps [rsp+0x70], xmm8
00007fa22efda23c  vmovaps [rsp+0x80], xmm9
00007fa22efda245  vmovaps [rsp+0x90], xmm10
00007fa22efda24e  vmovaps [rsp+0xA0], xmm11
00007fa22efda257  vmovaps [rsp+0xB0], xmm12
00007fa22efda260  vmovaps [rsp+0xC0], xmm13
00007fa22efda269  vmovaps [rsp+0xD0], xmm14
00007fa22efda272  vmovaps [rsp+0xE0], xmm15
00007fa22efda27b  sub rsp, 0x30
00007fa22efda27f  movaps [rsp], xmm1
00007fa22efda283  movaps [rsp+0x10], xmm13
00007fa22efda289  movaps [rsp+0x20], xmm9
00007fa22efda28f  lea rdi, [rsp]
00007fa22efda293  mov esi, 0x00
00007fa22efda298  mov rax, 0x5E9D1A57D530
00007fa22efda2a2  call rax
00007fa22efda2a4  movaps xmm1, [rsp]
00007fa22efda2a8  add rsp, 0x30
00007fa22efda2ac  vmovaps xmm0, [rsp]
00007fa22efda2b1  vmovaps xmm2, [rsp+0x10]
00007fa22efda2b7  vmovaps xmm3, [rsp+0x20]
00007fa22efda2bd  vmovaps xmm4, [rsp+0x30]
00007fa22efda2c3  vmovaps xmm5, [rsp+0x40]
00007fa22efda2c9  vmovaps xmm6, [rsp+0x50]
00007fa22efda2cf  vmovaps xmm7, [rsp+0x60]
00007fa22efda2d5  vmovaps xmm8, [rsp+0x70]
00007fa22efda2db  vmovaps xmm9, [rsp+0x80]
00007fa22efda2e4  vmovaps xmm10, [rsp+0x90]
00007fa22efda2ed  vmovaps xmm11, [rsp+0xA0]
00007fa22efda2f6  vmovaps xmm12, [rsp+0xB0]
00007fa22efda2ff  vmovaps xmm13, [rsp+0xC0]
00007fa22efda308  vmovaps xmm14, [rsp+0xD0]
00007fa22efda311  vmovaps xmm15, [rsp+0xE0]
00007fa22efda31a  add rsp, 0xF0
00007fa22efda321  pop r11
00007fa22efda323  pop r10
00007fa22efda325  pop r9
00007fa22efda327  pop r8
00007fa22efda329  pop rsi
00007fa22efda32a  pop rdi
00007fa22efda32b  pop rdx
00007fa22efda32c  pop rcx
00007fa22efda32d  pop rax
00007fa22efda32e  add rsp, 0x08
00007fa22efda332  jmp 0x00007FA22EFD641A
00007fa22efda337  sub rsp, 0x08
00007fa22efda33b  push rax
00007fa22efda33c  push rcx
00007fa22efda33d  push rdx
00007fa22efda33e  push rdi
00007fa22efda33f  push rsi
00007fa22efda340  push r8
00007fa22efda342  push r9
00007fa22efda344  push r10
00007fa22efda346  push r11
00007fa22efda348  sub rsp, 0xF0
00007fa22efda34f  vmovaps [rsp], xmm0
00007fa22efda354  vmovaps [rsp+0x10], xmm1
00007fa22efda35a  vmovaps [rsp+0x20], xmm2
00007fa22efda360  vmovaps [rsp+0x30], xmm3
00007fa22efda366  vmovaps [rsp+0x40], xmm4
00007fa22efda36c  vmovaps [rsp+0x50], xmm5
00007fa22efda372  vmovaps [rsp+0x60], xmm6
00007fa22efda378  vmovaps [rsp+0x70], xmm7
00007fa22efda37e  vmovaps [rsp+0x80], xmm8
00007fa22efda387  vmovaps [rsp+0x90], xmm9
00007fa22efda390  vmovaps [rsp+0xA0], xmm10
00007fa22efda399  vmovaps [rsp+0xB0], xmm11
00007fa22efda3a2  vmovaps [rsp+0xC0], xmm13
00007fa22efda3ab  vmovaps [rsp+0xD0], xmm14
00007fa22efda3b4  vmovaps [rsp+0xE0], xmm15
00007fa22efda3bd  sub rsp, 0x30
00007fa22efda3c1  movaps [rsp], xmm12
00007fa22efda3c6  movaps [rsp+0x10], xmm7
00007fa22efda3cb  movaps [rsp+0x20], xmm13
00007fa22efda3d1  lea rdi, [rsp]
00007fa22efda3d5  mov esi, 0x00
00007fa22efda3da  mov rax, 0x5E9D1A57D530
00007fa22efda3e4  call rax
00007fa22efda3e6  movaps xmm12, [rsp]
00007fa22efda3eb  add rsp, 0x30
00007fa22efda3ef  vmovaps xmm0, [rsp]
00007fa22efda3f4  vmovaps xmm1, [rsp+0x10]
00007fa22efda3fa  vmovaps xmm2, [rsp+0x20]
00007fa22efda400  vmovaps xmm3, [rsp+0x30]
00007fa22efda406  vmovaps xmm4, [rsp+0x40]
00007fa22efda40c  vmovaps xmm5, [rsp+0x50]
00007fa22efda412  vmovaps xmm6, [rsp+0x60]
00007fa22efda418  vmovaps xmm7, [rsp+0x70]
00007fa22efda41e  vmovaps xmm8, [rsp+0x80]
00007fa22efda427  vmovaps xmm9, [rsp+0x90]
00007fa22efda430  vmovaps xmm10, [rsp+0xA0]
00007fa22efda439  vmovaps xmm11, [rsp+0xB0]
00007fa22efda442  vmovaps xmm13, [rsp+0xC0]
00007fa22efda44b  vmovaps xmm14, [rsp+0xD0]
00007fa22efda454  vmovaps xmm15, [rsp+0xE0]
00007fa22efda45d  add rsp, 0xF0
00007fa22efda464  pop r11
00007fa22efda466  pop r10
00007fa22efda468  pop r9
00007fa22efda46a  pop r8
00007fa22efda46c  pop rsi
00007fa22efda46d  pop rdi
00007fa22efda46e  pop rdx
00007fa22efda46f  pop rcx
00007fa22efda470  pop rax
00007fa22efda471  add rsp, 0x08
00007fa22efda475  jmp 0x00007FA22EFD6441
00007fa22efda47a  sub rsp, 0x08
00007fa22efda47e  push rax
00007fa22efda47f  push rcx
00007fa22efda480  push rdx
00007fa22efda481  push rdi
00007fa22efda482  push rsi
00007fa22efda483  push r8
00007fa22efda485  push r9
00007fa22efda487  push r10
00007fa22efda489  push r11
00007fa22efda48b  sub rsp, 0xF0
00007fa22efda492  vmovaps [rsp], xmm0
00007fa22efda497  vmovaps [rsp+0x10], xmm1
00007fa22efda49d  vmovaps [rsp+0x20], xmm2
00007fa22efda4a3  vmovaps [rsp+0x30], xmm3
00007fa22efda4a9  vmovaps [rsp+0x40], xmm4
00007fa22efda4af  vmovaps [rsp+0x50], xmm5
00007fa22efda4b5  vmovaps [rsp+0x60], xmm6
00007fa22efda4bb  vmovaps [rsp+0x70], xmm7
00007fa22efda4c1  vmovaps [rsp+0x80], xmm8
00007fa22efda4ca  vmovaps [rsp+0x90], xmm9
00007fa22efda4d3  vmovaps [rsp+0xA0], xmm10
00007fa22efda4dc  vmovaps [rsp+0xB0], xmm11
00007fa22efda4e5  vmovaps [rsp+0xC0], xmm12
00007fa22efda4ee  vmovaps [rsp+0xD0], xmm14
00007fa22efda4f7  vmovaps [rsp+0xE0], xmm15
00007fa22efda500  sub rsp, 0x30
00007fa22efda504  movaps [rsp], xmm13
00007fa22efda509  movaps [rsp+0x10], xmm15
00007fa22efda50f  movaps [rsp+0x20], xmm8
00007fa22efda515  lea rdi, [rsp]
00007fa22efda519  mov esi, 0x00
00007fa22efda51e  mov rax, 0x5E9D1A57D530
00007fa22efda528  call rax
00007fa22efda52a  movaps xmm13, [rsp]
00007fa22efda52f  add rsp, 0x30
00007fa22efda533  vmovaps xmm0, [rsp]
00007fa22efda538  vmovaps xmm1, [rsp+0x10]
00007fa22efda53e  vmovaps xmm2, [rsp+0x20]
00007fa22efda544  vmovaps xmm3, [rsp+0x30]
00007fa22efda54a  vmovaps xmm4, [rsp+0x40]
00007fa22efda550  vmovaps xmm5, [rsp+0x50]
00007fa22efda556  vmovaps xmm6, [rsp+0x60]
00007fa22efda55c  vmovaps xmm7, [rsp+0x70]
00007fa22efda562  vmovaps xmm8, [rsp+0x80]
00007fa22efda56b  vmovaps xmm9, [rsp+0x90]
00007fa22efda574  vmovaps xmm10, [rsp+0xA0]
00007fa22efda57d  vmovaps xmm11, [rsp+0xB0]
00007fa22efda586  vmovaps xmm12, [rsp+0xC0]
00007fa22efda58f  vmovaps xmm14, [rsp+0xD0]
00007fa22efda598  vmovaps xmm15, [rsp+0xE0]
00007fa22efda5a1  add rsp, 0xF0
00007fa22efda5a8  pop r11
00007fa22efda5aa  pop r10
00007fa22efda5ac  pop r9
00007fa22efda5ae  pop r8
00007fa22efda5b0  pop rsi
00007fa22efda5b1  pop rdi
00007fa22efda5b2  pop rdx
00007fa22efda5b3  pop rcx
00007fa22efda5b4  pop rax
00007fa22efda5b5  add rsp, 0x08
00007fa22efda5b9  jmp 0x00007FA22EFD645C
00007fa22efda5be  sub rsp, 0x08
00007fa22efda5c2  push rax
00007fa22efda5c3  push rcx
00007fa22efda5c4  push rdx
00007fa22efda5c5  push rdi
00007fa22efda5c6  push rsi
00007fa22efda5c7  push r8
00007fa22efda5c9  push r9
00007fa22efda5cb  push r10
00007fa22efda5cd  push r11
00007fa22efda5cf  sub rsp, 0xF0
00007fa22efda5d6  vmovaps [rsp], xmm0
00007fa22efda5db  vmovaps [rsp+0x10], xmm1
00007fa22efda5e1  vmovaps [rsp+0x20], xmm2
00007fa22efda5e7  vmovaps [rsp+0x30], xmm3
00007fa22efda5ed  vmovaps [rsp+0x40], xmm4
00007fa22efda5f3  vmovaps [rsp+0x50], xmm5
00007fa22efda5f9  vmovaps [rsp+0x60], xmm6
00007fa22efda5ff  vmovaps [rsp+0x70], xmm7
00007fa22efda605  vmovaps [rsp+0x80], xmm9
00007fa22efda60e  vmovaps [rsp+0x90], xmm10
00007fa22efda617  vmovaps [rsp+0xA0], xmm11
00007fa22efda620  vmovaps [rsp+0xB0], xmm12
00007fa22efda629  vmovaps [rsp+0xC0], xmm13
00007fa22efda632  vmovaps [rsp+0xD0], xmm14
00007fa22efda63b  vmovaps [rsp+0xE0], xmm15
00007fa22efda644  sub rsp, 0x30
00007fa22efda648  movaps [rsp], xmm8
00007fa22efda64d  movaps [rsp+0x10], xmm15
00007fa22efda653  movaps [rsp+0x20], xmm9
00007fa22efda659  lea rdi, [rsp]
00007fa22efda65d  mov esi, 0x00
00007fa22efda662  mov rax, 0x5E9D1A57D530
00007fa22efda66c  call rax
00007fa22efda66e  movaps xmm8, [rsp]
00007fa22efda673  add rsp, 0x30
00007fa22efda677  vmovaps xmm0, [rsp]
00007fa22efda67c  vmovaps xmm1, [rsp+0x10]
00007fa22efda682  vmovaps xmm2, [rsp+0x20]
00007fa22efda688  vmovaps xmm3, [rsp+0x30]
00007fa22efda68e  vmovaps xmm4, [rsp+0x40]
00007fa22efda694  vmovaps xmm5, [rsp+0x50]
00007fa22efda69a  vmovaps xmm6, [rsp+0x60]
00007fa22efda6a0  vmovaps xmm7, [rsp+0x70]
00007fa22efda6a6  vmovaps xmm9, [rsp+0x80]
00007fa22efda6af  vmovaps xmm10, [rsp+0x90]
00007fa22efda6b8  vmovaps xmm11, [rsp+0xA0]
00007fa22efda6c1  vmovaps xmm12, [rsp+0xB0]
00007fa22efda6ca  vmovaps xmm13, [rsp+0xC0]
00007fa22efda6d3  vmovaps xmm14, [rsp+0xD0]
00007fa22efda6dc  vmovaps xmm15, [rsp+0xE0]
00007fa22efda6e5  add rsp, 0xF0
00007fa22efda6ec  pop r11
00007fa22efda6ee  pop r10
00007fa22efda6f0  pop r9
00007fa22efda6f2  pop r8
00007fa22efda6f4  pop rsi
00007fa22efda6f5  pop rdi
00007fa22efda6f6  pop rdx
00007fa22efda6f7  pop rcx
00007fa22efda6f8  pop rax
00007fa22efda6f9  add rsp, 0x08
00007fa22efda6fd  jmp 0x00007FA22EFD648A
00007fa22efda702  sub rsp, 0x08
00007fa22efda706  push rax
00007fa22efda707  push rcx
00007fa22efda708  push rdx
00007fa22efda709  push rdi
00007fa22efda70a  push rsi
00007fa22efda70b  push r8
00007fa22efda70d  push r9
00007fa22efda70f  push r10
00007fa22efda711  push r11
00007fa22efda713  sub rsp, 0xF0
00007fa22efda71a  vmovaps [rsp], xmm0
00007fa22efda71f  vmovaps [rsp+0x10], xmm1
00007fa22efda725  vmovaps [rsp+0x20], xmm2
00007fa22efda72b  vmovaps [rsp+0x30], xmm3
00007fa22efda731  vmovaps [rsp+0x40], xmm4
00007fa22efda737  vmovaps [rsp+0x50], xmm5
00007fa22efda73d  vmovaps [rsp+0x60], xmm6
00007fa22efda743  vmovaps [rsp+0x70], xmm7
00007fa22efda749  vmovaps [rsp+0x80], xmm8
00007fa22efda752  vmovaps [rsp+0x90], xmm9
00007fa22efda75b  vmovaps [rsp+0xA0], xmm10
00007fa22efda764  vmovaps [rsp+0xB0], xmm11
00007fa22efda76d  vmovaps [rsp+0xC0], xmm12
00007fa22efda776  vmovaps [rsp+0xD0], xmm13
00007fa22efda77f  vmovaps [rsp+0xE0], xmm14
00007fa22efda788  sub rsp, 0x30
00007fa22efda78c  movaps [rsp], xmm15
00007fa22efda791  movaps [rsp+0x10], xmm11
00007fa22efda797  movaps [rsp+0x20], xmm6
00007fa22efda79c  lea rdi, [rsp]
00007fa22efda7a0  mov esi, 0x00
00007fa22efda7a5  mov rax, 0x5E9D1A57D530
00007fa22efda7af  call rax
00007fa22efda7b1  movaps xmm15, [rsp]
00007fa22efda7b6  add rsp, 0x30
00007fa22efda7ba  vmovaps xmm0, [rsp]
00007fa22efda7bf  vmovaps xmm1, [rsp+0x10]
00007fa22efda7c5  vmovaps xmm2, [rsp+0x20]
00007fa22efda7cb  vmovaps xmm3, [rsp+0x30]
00007fa22efda7d1  vmovaps xmm4, [rsp+0x40]
00007fa22efda7d7  vmovaps xmm5, [rsp+0x50]
00007fa22efda7dd  vmovaps xmm6, [rsp+0x60]
00007fa22efda7e3  vmovaps xmm7, [rsp+0x70]
00007fa22efda7e9  vmovaps xmm8, [rsp+0x80]
00007fa22efda7f2  vmovaps xmm9, [rsp+0x90]
00007fa22efda7fb  vmovaps xmm10, [rsp+0xA0]
00007fa22efda804  vmovaps xmm11, [rsp+0xB0]
00007fa22efda80d  vmovaps xmm12, [rsp+0xC0]
00007fa22efda816  vmovaps xmm13, [rsp+0xD0]
00007fa22efda81f  vmovaps xmm14, [rsp+0xE0]
00007fa22efda828  add rsp, 0xF0
00007fa22efda82f  pop r11
00007fa22efda831  pop r10
00007fa22efda833  pop r9
00007fa22efda835  pop r8
00007fa22efda837  pop rsi
00007fa22efda838  pop rdi
00007fa22efda839  pop rdx
00007fa22efda83a  pop rcx
00007fa22efda83b  pop rax
00007fa22efda83c  add rsp, 0x08
00007fa22efda840  jmp 0x00007FA22EFD64A5
00007fa22efda845  sub rsp, 0x08
00007fa22efda849  push rax
00007fa22efda84a  push rcx
00007fa22efda84b  push rdx
00007fa22efda84c  push rdi
00007fa22efda84d  push rsi
00007fa22efda84e  push r8
00007fa22efda850  push r9
00007fa22efda852  push r10
00007fa22efda854  push r11
00007fa22efda856  sub rsp, 0xF0
00007fa22efda85d  vmovaps [rsp], xmm0
00007fa22efda862  vmovaps [rsp+0x10], xmm1
00007fa22efda868  vmovaps [rsp+0x20], xmm2
00007fa22efda86e  vmovaps [rsp+0x30], xmm3
00007fa22efda874  vmovaps [rsp+0x40], xmm4
00007fa22efda87a  vmovaps [rsp+0x50], xmm5
00007fa22efda880  vmovaps [rsp+0x60], xmm6
00007fa22efda886  vmovaps [rsp+0x70], xmm8
00007fa22efda88c  vmovaps [rsp+0x80], xmm9
00007fa22efda895  vmovaps [rsp+0x90], xmm10
00007fa22efda89e  vmovaps [rsp+0xA0], xmm11
00007fa22efda8a7  vmovaps [rsp+0xB0], xmm12
00007fa22efda8b0  vmovaps [rsp+0xC0], xmm13
00007fa22efda8b9  vmovaps [rsp+0xD0], xmm14
00007fa22efda8c2  vmovaps [rsp+0xE0], xmm15
00007fa22efda8cb  sub rsp, 0x30
00007fa22efda8cf  movaps [rsp], xmm7
00007fa22efda8d3  movaps [rsp+0x10], xmm11
00007fa22efda8d9  movaps [rsp+0x20], xmm9
00007fa22efda8df  lea rdi, [rsp]
00007fa22efda8e3  mov esi, 0x00
00007fa22efda8e8  mov rax, 0x5E9D1A57D530
00007fa22efda8f2  call rax
00007fa22efda8f4  movaps xmm7, [rsp]
00007fa22efda8f8  add rsp, 0x30
00007fa22efda8fc  vmovaps xmm0, [rsp]
00007fa22efda901  vmovaps xmm1, [rsp+0x10]
00007fa22efda907  vmovaps xmm2, [rsp+0x20]
00007fa22efda90d  vmovaps xmm3, [rsp+0x30]
00007fa22efda913  vmovaps xmm4, [rsp+0x40]
00007fa22efda919  vmovaps xmm5, [rsp+0x50]
00007fa22efda91f  vmovaps xmm6, [rsp+0x60]
00007fa22efda925  vmovaps xmm8, [rsp+0x70]
00007fa22efda92b  vmovaps xmm9, [rsp+0x80]
00007fa22efda934  vmovaps xmm10, [rsp+0x90]
00007fa22efda93d  vmovaps xmm11, [rsp+0xA0]
00007fa22efda946  vmovaps xmm12, [rsp+0xB0]
00007fa22efda94f  vmovaps xmm13, [rsp+0xC0]
00007fa22efda958  vmovaps xmm14, [rsp+0xD0]
00007fa22efda961  vmovaps xmm15, [rsp+0xE0]
00007fa22efda96a  add rsp, 0xF0
00007fa22efda971  pop r11
00007fa22efda973  pop r10
00007fa22efda975  pop r9
00007fa22efda977  pop r8
00007fa22efda979  pop rsi
00007fa22efda97a  pop rdi
00007fa22efda97b  pop rdx
00007fa22efda97c  pop rcx
00007fa22efda97d  pop rax
00007fa22efda97e  add rsp, 0x08
00007fa22efda982  jmp 0x00007FA22EFD64D2
00007fa22efda987  sub rsp, 0x08
00007fa22efda98b  push rax
00007fa22efda98c  push rcx
00007fa22efda98d  push rdx
00007fa22efda98e  push rdi
00007fa22efda98f  push rsi
00007fa22efda990  push r8
00007fa22efda992  push r9
00007fa22efda994  push r10
00007fa22efda996  push r11
00007fa22efda998  sub rsp, 0xF0
00007fa22efda99f  vmovaps [rsp], xmm0
00007fa22efda9a4  vmovaps [rsp+0x10], xmm1
00007fa22efda9aa  vmovaps [rsp+0x20], xmm2
00007fa22efda9b0  vmovaps [rsp+0x30], xmm3
00007fa22efda9b6  vmovaps [rsp+0x40], xmm4
00007fa22efda9bc  vmovaps [rsp+0x50], xmm5
00007fa22efda9c2  vmovaps [rsp+0x60], xmm6
00007fa22efda9c8  vmovaps [rsp+0x70], xmm7
00007fa22efda9ce  vmovaps [rsp+0x80], xmm8
00007fa22efda9d7  vmovaps [rsp+0x90], xmm9
00007fa22efda9e0  vmovaps [rsp+0xA0], xmm10
00007fa22efda9e9  vmovaps [rsp+0xB0], xmm12
00007fa22efda9f2  vmovaps [rsp+0xC0], xmm13
00007fa22efda9fb  vmovaps [rsp+0xD0], xmm14
00007fa22efdaa04  vmovaps [rsp+0xE0], xmm15
00007fa22efdaa0d  sub rsp, 0x30
00007fa22efdaa11  movaps [rsp], xmm11
00007fa22efdaa16  movaps [rsp+0x10], xmm10
00007fa22efdaa1c  movaps [rsp+0x20], xmm14
00007fa22efdaa22  lea rdi, [rsp]
00007fa22efdaa26  mov esi, 0x00
00007fa22efdaa2b  mov rax, 0x5E9D1A57D530
00007fa22efdaa35  call rax
00007fa22efdaa37  movaps xmm11, [rsp]
00007fa22efdaa3c  add rsp, 0x30
00007fa22efdaa40  vmovaps xmm0, [rsp]
00007fa22efdaa45  vmovaps xmm1, [rsp+0x10]
00007fa22efdaa4b  vmovaps xmm2, [rsp+0x20]
00007fa22efdaa51  vmovaps xmm3, [rsp+0x30]
00007fa22efdaa57  vmovaps xmm4, [rsp+0x40]
00007fa22efdaa5d  vmovaps xmm5, [rsp+0x50]
00007fa22efdaa63  vmovaps xmm6, [rsp+0x60]
00007fa22efdaa69  vmovaps xmm7, [rsp+0x70]
00007fa22efdaa6f  vmovaps xmm8, [rsp+0x80]
00007fa22efdaa78  vmovaps xmm9, [rsp+0x90]
00007fa22efdaa81  vmovaps xmm10, [rsp+0xA0]
00007fa22efdaa8a  vmovaps xmm12, [rsp+0xB0]
00007fa22efdaa93  vmovaps xmm13, [rsp+0xC0]
00007fa22efdaa9c  vmovaps xmm14, [rsp+0xD0]
00007fa22efdaaa5  vmovaps xmm15, [rsp+0xE0]
00007fa22efdaaae  add rsp, 0xF0
00007fa22efdaab5  pop r11
00007fa22efdaab7  pop r10
00007fa22efdaab9  pop r9
00007fa22efdaabb  pop r8
00007fa22efdaabd  pop rsi
00007fa22efdaabe  pop rdi
00007fa22efdaabf  pop rdx
00007fa22efdaac0  pop rcx
00007fa22efdaac1  pop rax
00007fa22efdaac2  add rsp, 0x08
00007fa22efdaac6  jmp 0x00007FA22EFD64ED
00007fa22efdaacb  call 0x00007FA22EEE45A0
00007fa22efdaad0  jmp 0x00007FA22EFD64F7
00007fa22efdaad5  sub rsp, 0x08
00007fa22efdaad9  push rax
00007fa22efdaada  push rcx
00007fa22efdaadb  push rdx
00007fa22efdaadc  push rdi
00007fa22efdaadd  push rsi
00007fa22efdaade  push r8
00007fa22efdaae0  push r9
00007fa22efdaae2  push r10
00007fa22efdaae4  push r11
00007fa22efdaae6  sub rsp, 0xF0
00007fa22efdaaed  vmovaps [rsp], xmm0
00007fa22efdaaf2  vmovaps [rsp+0x10], xmm1
00007fa22efdaaf8  vmovaps [rsp+0x20], xmm2
00007fa22efdaafe  vmovaps [rsp+0x30], xmm3
00007fa22efdab04  vmovaps [rsp+0x40], xmm4
00007fa22efdab0a  vmovaps [rsp+0x50], xmm5
00007fa22efdab10  vmovaps [rsp+0x60], xmm6
00007fa22efdab16  vmovaps [rsp+0x70], xmm7
00007fa22efdab1c  vmovaps [rsp+0x80], xmm8
00007fa22efdab25  vmovaps [rsp+0x90], xmm9
00007fa22efdab2e  vmovaps [rsp+0xA0], xmm11
00007fa22efdab37  vmovaps [rsp+0xB0], xmm12
00007fa22efdab40  vmovaps [rsp+0xC0], xmm13
00007fa22efdab49  vmovaps [rsp+0xD0], xmm14
00007fa22efdab52  vmovaps [rsp+0xE0], xmm15
00007fa22efdab5b  sub rsp, 0x30
00007fa22efdab5f  movaps [rsp], xmm10
00007fa22efdab64  movaps [rsp+0x10], xmm1
00007fa22efdab69  movaps [rsp+0x20], xmm12
00007fa22efdab6f  lea rdi, [rsp]
00007fa22efdab73  mov esi, 0x00
00007fa22efdab78  mov rax, 0x5E9D1A57D530
00007fa22efdab82  call rax
00007fa22efdab84  movaps xmm10, [rsp]
00007fa22efdab89  add rsp, 0x30
00007fa22efdab8d  vmovaps xmm0, [rsp]
00007fa22efdab92  vmovaps xmm1, [rsp+0x10]
00007fa22efdab98  vmovaps xmm2, [rsp+0x20]
00007fa22efdab9e  vmovaps xmm3, [rsp+0x30]
00007fa22efdaba4  vmovaps xmm4, [rsp+0x40]
00007fa22efdabaa  vmovaps xmm5, [rsp+0x50]
00007fa22efdabb0  vmovaps xmm6, [rsp+0x60]
00007fa22efdabb6  vmovaps xmm7, [rsp+0x70]
00007fa22efdabbc  vmovaps xmm8, [rsp+0x80]
00007fa22efdabc5  vmovaps xmm9, [rsp+0x90]
00007fa22efdabce  vmovaps xmm11, [rsp+0xA0]
00007fa22efdabd7  vmovaps xmm12, [rsp+0xB0]
00007fa22efdabe0  vmovaps xmm13, [rsp+0xC0]
00007fa22efdabe9  vmovaps xmm14, [rsp+0xD0]
00007fa22efdabf2  vmovaps xmm15, [rsp+0xE0]
00007fa22efdabfb  add rsp, 0xF0
00007fa22efdac02  pop r11
00007fa22efdac04  pop r10
00007fa22efdac06  pop r9
00007fa22efdac08  pop r8
00007fa22efdac0a  pop rsi
00007fa22efdac0b  pop rdi
00007fa22efdac0c  pop rdx
00007fa22efdac0d  pop rcx
00007fa22efdac0e  pop rax
00007fa22efdac0f  add rsp, 0x08
00007fa22efdac13  jmp 0x00007FA22EFD651A
00007fa22efdac18  sub rsp, 0x08
00007fa22efdac1c  push rax
00007fa22efdac1d  push rcx
00007fa22efdac1e  push rdx
00007fa22efdac1f  push rdi
00007fa22efdac20  push rsi
00007fa22efdac21  push r8
00007fa22efdac23  push r9
00007fa22efdac25  push r10
00007fa22efdac27  push r11
00007fa22efdac29  sub rsp, 0xF0
00007fa22efdac30  vmovaps [rsp], xmm0
00007fa22efdac35  vmovaps [rsp+0x10], xmm1
00007fa22efdac3b  vmovaps [rsp+0x20], xmm2
00007fa22efdac41  vmovaps [rsp+0x30], xmm3
00007fa22efdac47  vmovaps [rsp+0x40], xmm4
00007fa22efdac4d  vmovaps [rsp+0x50], xmm5
00007fa22efdac53  vmovaps [rsp+0x60], xmm6
00007fa22efdac59  vmovaps [rsp+0x70], xmm7
00007fa22efdac5f  vmovaps [rsp+0x80], xmm8
00007fa22efdac68  vmovaps [rsp+0x90], xmm9
00007fa22efdac71  vmovaps [rsp+0xA0], xmm10
00007fa22efdac7a  vmovaps [rsp+0xB0], xmm11
00007fa22efdac83  vmovaps [rsp+0xC0], xmm13
00007fa22efdac8c  vmovaps [rsp+0xD0], xmm14
00007fa22efdac95  vmovaps [rsp+0xE0], xmm15
00007fa22efdac9e  sub rsp, 0x30
00007fa22efdaca2  movaps [rsp], xmm12
00007fa22efdaca7  movaps [rsp+0x10], xmm14
00007fa22efdacad  movaps [rsp+0x20], xmm1
00007fa22efdacb2  lea rdi, [rsp]
00007fa22efdacb6  mov esi, 0x00
00007fa22efdacbb  mov rax, 0x5E9D1A57D530
00007fa22efdacc5  call rax
00007fa22efdacc7  movaps xmm12, [rsp]
00007fa22efdaccc  add rsp, 0x30
00007fa22efdacd0  vmovaps xmm0, [rsp]
00007fa22efdacd5  vmovaps xmm1, [rsp+0x10]
00007fa22efdacdb  vmovaps xmm2, [rsp+0x20]
00007fa22efdace1  vmovaps xmm3, [rsp+0x30]
00007fa22efdace7  vmovaps xmm4, [rsp+0x40]
00007fa22efdaced  vmovaps xmm5, [rsp+0x50]
00007fa22efdacf3  vmovaps xmm6, [rsp+0x60]
00007fa22efdacf9  vmovaps xmm7, [rsp+0x70]
00007fa22efdacff  vmovaps xmm8, [rsp+0x80]
00007fa22efdad08  vmovaps xmm9, [rsp+0x90]
00007fa22efdad11  vmovaps xmm10, [rsp+0xA0]
00007fa22efdad1a  vmovaps xmm11, [rsp+0xB0]
00007fa22efdad23  vmovaps xmm13, [rsp+0xC0]
00007fa22efdad2c  vmovaps xmm14, [rsp+0xD0]
00007fa22efdad35  vmovaps xmm15, [rsp+0xE0]
00007fa22efdad3e  add rsp, 0xF0
00007fa22efdad45  pop r11
00007fa22efdad47  pop r10
00007fa22efdad49  pop r9
00007fa22efdad4b  pop r8
00007fa22efdad4d  pop rsi
00007fa22efdad4e  pop rdi
00007fa22efdad4f  pop rdx
00007fa22efdad50  pop rcx
00007fa22efdad51  pop rax
00007fa22efdad52  add rsp, 0x08
00007fa22efdad56  jmp 0x00007FA22EFD6549
00007fa22efdad5b  sub rsp, 0x08
00007fa22efdad5f  push rax
00007fa22efdad60  push rcx
00007fa22efdad61  push rdx
00007fa22efdad62  push rdi
00007fa22efdad63  push rsi
00007fa22efdad64  push r8
00007fa22efdad66  push r9
00007fa22efdad68  push r10
00007fa22efdad6a  push r11
00007fa22efdad6c  sub rsp, 0xF0
00007fa22efdad73  vmovaps [rsp], xmm0
00007fa22efdad78  vmovaps [rsp+0x10], xmm1
00007fa22efdad7e  vmovaps [rsp+0x20], xmm2
00007fa22efdad84  vmovaps [rsp+0x30], xmm3
00007fa22efdad8a  vmovaps [rsp+0x40], xmm4
00007fa22efdad90  vmovaps [rsp+0x50], xmm5
00007fa22efdad96  vmovaps [rsp+0x60], xmm6
00007fa22efdad9c  vmovaps [rsp+0x70], xmm7
00007fa22efdada2  vmovaps [rsp+0x80], xmm8
00007fa22efdadab  vmovaps [rsp+0x90], xmm9
00007fa22efdadb4  vmovaps [rsp+0xA0], xmm10
00007fa22efdadbd  vmovaps [rsp+0xB0], xmm11
00007fa22efdadc6  vmovaps [rsp+0xC0], xmm12
00007fa22efdadcf  vmovaps [rsp+0xD0], xmm13
00007fa22efdadd8  vmovaps [rsp+0xE0], xmm15
00007fa22efdade1  sub rsp, 0x30
00007fa22efdade5  movaps [rsp], xmm14
00007fa22efdadea  movaps [rsp+0x10], xmm9
00007fa22efdadf0  movaps [rsp+0x20], xmm1
00007fa22efdadf5  lea rdi, [rsp]
00007fa22efdadf9  mov esi, 0x00
00007fa22efdadfe  mov rax, 0x5E9D1A57D530
00007fa22efdae08  call rax
00007fa22efdae0a  movaps xmm14, [rsp]
00007fa22efdae0f  add rsp, 0x30
00007fa22efdae13  vmovaps xmm0, [rsp]
00007fa22efdae18  vmovaps xmm1, [rsp+0x10]
00007fa22efdae1e  vmovaps xmm2, [rsp+0x20]
00007fa22efdae24  vmovaps xmm3, [rsp+0x30]
00007fa22efdae2a  vmovaps xmm4, [rsp+0x40]
00007fa22efdae30  vmovaps xmm5, [rsp+0x50]
00007fa22efdae36  vmovaps xmm6, [rsp+0x60]
00007fa22efdae3c  vmovaps xmm7, [rsp+0x70]
00007fa22efdae42  vmovaps xmm8, [rsp+0x80]
00007fa22efdae4b  vmovaps xmm9, [rsp+0x90]
00007fa22efdae54  vmovaps xmm10, [rsp+0xA0]
00007fa22efdae5d  vmovaps xmm11, [rsp+0xB0]
00007fa22efdae66  vmovaps xmm12, [rsp+0xC0]
00007fa22efdae6f  vmovaps xmm13, [rsp+0xD0]
00007fa22efdae78  vmovaps xmm15, [rsp+0xE0]
00007fa22efdae81  add rsp, 0xF0
00007fa22efdae88  pop r11
00007fa22efdae8a  pop r10
00007fa22efdae8c  pop r9
00007fa22efdae8e  pop r8
00007fa22efdae90  pop rsi
00007fa22efdae91  pop rdi
00007fa22efdae92  pop rdx
00007fa22efdae93  pop rcx
00007fa22efdae94  pop rax
00007fa22efdae95  add rsp, 0x08
00007fa22efdae99  jmp 0x00007FA22EFD6578
00007fa22efdae9e  sub rsp, 0x08
00007fa22efdaea2  push rax
00007fa22efdaea3  push rcx
00007fa22efdaea4  push rdx
00007fa22efdaea5  push rdi
00007fa22efdaea6  push rsi
00007fa22efdaea7  push r8
00007fa22efdaea9  push r9
00007fa22efdaeab  push r10
00007fa22efdaead  push r11
00007fa22efdaeaf  sub rsp, 0xF0
00007fa22efdaeb6  vmovaps [rsp], xmm0
00007fa22efdaebb  vmovaps [rsp+0x10], xmm2
00007fa22efdaec1  vmovaps [rsp+0x20], xmm3
00007fa22efdaec7  vmovaps [rsp+0x30], xmm4
00007fa22efdaecd  vmovaps [rsp+0x40], xmm5
00007fa22efdaed3  vmovaps [rsp+0x50], xmm6
00007fa22efdaed9  vmovaps [rsp+0x60], xmm7
00007fa22efdaedf  vmovaps [rsp+0x70], xmm8
00007fa22efdaee5  vmovaps [rsp+0x80], xmm9
00007fa22efdaeee  vmovaps [rsp+0x90], xmm10
00007fa22efdaef7  vmovaps [rsp+0xA0], xmm11
00007fa22efdaf00  vmovaps [rsp+0xB0], xmm12
00007fa22efdaf09  vmovaps [rsp+0xC0], xmm13
00007fa22efdaf12  vmovaps [rsp+0xD0], xmm14
00007fa22efdaf1b  vmovaps [rsp+0xE0], xmm15
00007fa22efdaf24  sub rsp, 0x30
00007fa22efdaf28  movaps [rsp], xmm1
00007fa22efdaf2c  movaps [rsp+0x10], xmm13
00007fa22efdaf32  movaps [rsp+0x20], xmm8
00007fa22efdaf38  lea rdi, [rsp]
00007fa22efdaf3c  mov esi, 0x00
00007fa22efdaf41  mov rax, 0x5E9D1A57D530
00007fa22efdaf4b  call rax
00007fa22efdaf4d  movaps xmm1, [rsp]
00007fa22efdaf51  add rsp, 0x30
00007fa22efdaf55  vmovaps xmm0, [rsp]
00007fa22efdaf5a  vmovaps xmm2, [rsp+0x10]
00007fa22efdaf60  vmovaps xmm3, [rsp+0x20]
00007fa22efdaf66  vmovaps xmm4, [rsp+0x30]
00007fa22efdaf6c  vmovaps xmm5, [rsp+0x40]
00007fa22efdaf72  vmovaps xmm6, [rsp+0x50]
00007fa22efdaf78  vmovaps xmm7, [rsp+0x60]
00007fa22efdaf7e  vmovaps xmm8, [rsp+0x70]
00007fa22efdaf84  vmovaps xmm9, [rsp+0x80]
00007fa22efdaf8d  vmovaps xmm10, [rsp+0x90]
00007fa22efdaf96  vmovaps xmm11, [rsp+0xA0]
00007fa22efdaf9f  vmovaps xmm12, [rsp+0xB0]
00007fa22efdafa8  vmovaps xmm13, [rsp+0xC0]
00007fa22efdafb1  vmovaps xmm14, [rsp+0xD0]
00007fa22efdafba  vmovaps xmm15, [rsp+0xE0]
00007fa22efdafc3  add rsp, 0xF0
00007fa22efdafca  pop r11
00007fa22efdafcc  pop r10
00007fa22efdafce  pop r9
00007fa22efdafd0  pop r8
00007fa22efdafd2  pop rsi
00007fa22efdafd3  pop rdi
00007fa22efdafd4  pop rdx
00007fa22efdafd5  pop rcx
00007fa22efdafd6  pop rax
00007fa22efdafd7  add rsp, 0x08
00007fa22efdafdb  jmp 0x00007FA22EFD659A
00007fa22efdafe0  call 0x00007FA22EE0C260
00007fa22efdafe5  jmp 0x00007FA22EFD65A8
00007fa22efdafea  call 0x00007FA22EEDE950
00007fa22efdafef  jmp 0x00007FA22EFD65B2
00007fa22efdaff4  sub rsp, 0x08
00007fa22efdaff8  push rax
00007fa22efdaff9  push rcx
00007fa22efdaffa  push rdx
00007fa22efdaffb  push rdi
00007fa22efdaffc  push rsi
00007fa22efdaffd  push r8
00007fa22efdafff  push r9
00007fa22efdb001  push r10
00007fa22efdb003  push r11
00007fa22efdb005  sub rsp, 0xF0
00007fa22efdb00c  vmovaps [rsp], xmm0
00007fa22efdb011  vmovaps [rsp+0x10], xmm1
00007fa22efdb017  vmovaps [rsp+0x20], xmm2
00007fa22efdb01d  vmovaps [rsp+0x30], xmm3
00007fa22efdb023  vmovaps [rsp+0x40], xmm4
00007fa22efdb029  vmovaps [rsp+0x50], xmm5
00007fa22efdb02f  vmovaps [rsp+0x60], xmm6
00007fa22efdb035  vmovaps [rsp+0x70], xmm7
00007fa22efdb03b  vmovaps [rsp+0x80], xmm9
00007fa22efdb044  vmovaps [rsp+0x90], xmm10
00007fa22efdb04d  vmovaps [rsp+0xA0], xmm11
00007fa22efdb056  vmovaps [rsp+0xB0], xmm12
00007fa22efdb05f  vmovaps [rsp+0xC0], xmm13
00007fa22efdb068  vmovaps [rsp+0xD0], xmm14
00007fa22efdb071  vmovaps [rsp+0xE0], xmm15
00007fa22efdb07a  sub rsp, 0x30
00007fa22efdb07e  movaps [rsp], xmm8
00007fa22efdb083  movaps [rsp+0x10], xmm15
00007fa22efdb089  movaps [rsp+0x20], xmm7
00007fa22efdb08e  lea rdi, [rsp]
00007fa22efdb092  mov esi, 0x00
00007fa22efdb097  mov rax, 0x5E9D1A57D530
00007fa22efdb0a1  call rax
00007fa22efdb0a3  movaps xmm8, [rsp]
00007fa22efdb0a8  add rsp, 0x30
00007fa22efdb0ac  vmovaps xmm0, [rsp]
00007fa22efdb0b1  vmovaps xmm1, [rsp+0x10]
00007fa22efdb0b7  vmovaps xmm2, [rsp+0x20]
00007fa22efdb0bd  vmovaps xmm3, [rsp+0x30]
00007fa22efdb0c3  vmovaps xmm4, [rsp+0x40]
00007fa22efdb0c9  vmovaps xmm5, [rsp+0x50]
00007fa22efdb0cf  vmovaps xmm6, [rsp+0x60]
00007fa22efdb0d5  vmovaps xmm7, [rsp+0x70]
00007fa22efdb0db  vmovaps xmm9, [rsp+0x80]
00007fa22efdb0e4  vmovaps xmm10, [rsp+0x90]
00007fa22efdb0ed  vmovaps xmm11, [rsp+0xA0]
00007fa22efdb0f6  vmovaps xmm12, [rsp+0xB0]
00007fa22efdb0ff  vmovaps xmm13, [rsp+0xC0]
00007fa22efdb108  vmovaps xmm14, [rsp+0xD0]
00007fa22efdb111  vmovaps xmm15, [rsp+0xE0]
00007fa22efdb11a  add rsp, 0xF0
00007fa22efdb121  pop r11
00007fa22efdb123  pop r10
00007fa22efdb125  pop r9
00007fa22efdb127  pop r8
00007fa22efdb129  pop rsi
00007fa22efdb12a  pop rdi
00007fa22efdb12b  pop rdx
00007fa22efdb12c  pop rcx
00007fa22efdb12d  pop rax
00007fa22efdb12e  add rsp, 0x08
00007fa22efdb132  jmp 0x00007FA22EFD65D4
00007fa22efdb137  sub rsp, 0x08
00007fa22efdb13b  push rax
00007fa22efdb13c  push rcx
00007fa22efdb13d  push rdx
00007fa22efdb13e  push rdi
00007fa22efdb13f  push rsi
00007fa22efdb140  push r8
00007fa22efdb142  push r9
00007fa22efdb144  push r10
00007fa22efdb146  push r11
00007fa22efdb148  sub rsp, 0xF0
00007fa22efdb14f  vmovaps [rsp], xmm0
00007fa22efdb154  vmovaps [rsp+0x10], xmm1
00007fa22efdb15a  vmovaps [rsp+0x20], xmm2
00007fa22efdb160  vmovaps [rsp+0x30], xmm3
00007fa22efdb166  vmovaps [rsp+0x40], xmm4
00007fa22efdb16c  vmovaps [rsp+0x50], xmm5
00007fa22efdb172  vmovaps [rsp+0x60], xmm6
00007fa22efdb178  vmovaps [rsp+0x70], xmm8
00007fa22efdb17e  vmovaps [rsp+0x80], xmm9
00007fa22efdb187  vmovaps [rsp+0x90], xmm10
00007fa22efdb190  vmovaps [rsp+0xA0], xmm11
00007fa22efdb199  vmovaps [rsp+0xB0], xmm12
00007fa22efdb1a2  vmovaps [rsp+0xC0], xmm13
00007fa22efdb1ab  vmovaps [rsp+0xD0], xmm14
00007fa22efdb1b4  vmovaps [rsp+0xE0], xmm15
00007fa22efdb1bd  sub rsp, 0x30
00007fa22efdb1c1  movaps [rsp], xmm7
00007fa22efdb1c5  movaps [rsp+0x10], xmm9
00007fa22efdb1cb  movaps [rsp+0x20], xmm15
00007fa22efdb1d1  lea rdi, [rsp]
00007fa22efdb1d5  mov esi, 0x00
00007fa22efdb1da  mov rax, 0x5E9D1A57D530
00007fa22efdb1e4  call rax
00007fa22efdb1e6  movaps xmm7, [rsp]
00007fa22efdb1ea  add rsp, 0x30
00007fa22efdb1ee  vmovaps xmm0, [rsp]
00007fa22efdb1f3  vmovaps xmm1, [rsp+0x10]
00007fa22efdb1f9  vmovaps xmm2, [rsp+0x20]
00007fa22efdb1ff  vmovaps xmm3, [rsp+0x30]
00007fa22efdb205  vmovaps xmm4, [rsp+0x40]
00007fa22efdb20b  vmovaps xmm5, [rsp+0x50]
00007fa22efdb211  vmovaps xmm6, [rsp+0x60]
00007fa22efdb217  vmovaps xmm8, [rsp+0x70]
00007fa22efdb21d  vmovaps xmm9, [rsp+0x80]
00007fa22efdb226  vmovaps xmm10, [rsp+0x90]
00007fa22efdb22f  vmovaps xmm11, [rsp+0xA0]
00007fa22efdb238  vmovaps xmm12, [rsp+0xB0]
00007fa22efdb241  vmovaps xmm13, [rsp+0xC0]
00007fa22efdb24a  vmovaps xmm14, [rsp+0xD0]
00007fa22efdb253  vmovaps xmm15, [rsp+0xE0]
00007fa22efdb25c  add rsp, 0xF0
00007fa22efdb263  pop r11
00007fa22efdb265  pop r10
00007fa22efdb267  pop r9
00007fa22efdb269  pop r8
00007fa22efdb26b  pop rsi
00007fa22efdb26c  pop rdi
00007fa22efdb26d  pop rdx
00007fa22efdb26e  pop rcx
00007fa22efdb26f  pop rax
00007fa22efdb270  add rsp, 0x08
00007fa22efdb274  jmp 0x00007FA22EFD6601
00007fa22efdb279  sub rsp, 0x08
00007fa22efdb27d  push rax
00007fa22efdb27e  push rcx
00007fa22efdb27f  push rdx
00007fa22efdb280  push rdi
00007fa22efdb281  push rsi
00007fa22efdb282  push r8
00007fa22efdb284  push r9
00007fa22efdb286  push r10
00007fa22efdb288  push r11
00007fa22efdb28a  sub rsp, 0xF0
00007fa22efdb291  vmovaps [rsp], xmm0
00007fa22efdb296  vmovaps [rsp+0x10], xmm1
00007fa22efdb29c  vmovaps [rsp+0x20], xmm2
00007fa22efdb2a2  vmovaps [rsp+0x30], xmm3
00007fa22efdb2a8  vmovaps [rsp+0x40], xmm4
00007fa22efdb2ae  vmovaps [rsp+0x50], xmm5
00007fa22efdb2b4  vmovaps [rsp+0x60], xmm6
00007fa22efdb2ba  vmovaps [rsp+0x70], xmm7
00007fa22efdb2c0  vmovaps [rsp+0x80], xmm8
00007fa22efdb2c9  vmovaps [rsp+0x90], xmm10
00007fa22efdb2d2  vmovaps [rsp+0xA0], xmm11
00007fa22efdb2db  vmovaps [rsp+0xB0], xmm12
00007fa22efdb2e4  vmovaps [rsp+0xC0], xmm13
00007fa22efdb2ed  vmovaps [rsp+0xD0], xmm14
00007fa22efdb2f6  vmovaps [rsp+0xE0], xmm15
00007fa22efdb2ff  sub rsp, 0x30
00007fa22efdb303  movaps [rsp], xmm9
00007fa22efdb308  movaps [rsp+0x10], xmm13
00007fa22efdb30e  movaps [rsp+0x20], xmm15
00007fa22efdb314  lea rdi, [rsp]
00007fa22efdb318  mov esi, 0x00
00007fa22efdb31d  mov rax, 0x5E9D1A57D530
00007fa22efdb327  call rax
00007fa22efdb329  movaps xmm9, [rsp]
00007fa22efdb32e  add rsp, 0x30
00007fa22efdb332  vmovaps xmm0, [rsp]
00007fa22efdb337  vmovaps xmm1, [rsp+0x10]
00007fa22efdb33d  vmovaps xmm2, [rsp+0x20]
00007fa22efdb343  vmovaps xmm3, [rsp+0x30]
00007fa22efdb349  vmovaps xmm4, [rsp+0x40]
00007fa22efdb34f  vmovaps xmm5, [rsp+0x50]
00007fa22efdb355  vmovaps xmm6, [rsp+0x60]
00007fa22efdb35b  vmovaps xmm7, [rsp+0x70]
00007fa22efdb361  vmovaps xmm8, [rsp+0x80]
00007fa22efdb36a  vmovaps xmm10, [rsp+0x90]
00007fa22efdb373  vmovaps xmm11, [rsp+0xA0]
00007fa22efdb37c  vmovaps xmm12, [rsp+0xB0]
00007fa22efdb385  vmovaps xmm13, [rsp+0xC0]
00007fa22efdb38e  vmovaps xmm14, [rsp+0xD0]
00007fa22efdb397  vmovaps xmm15, [rsp+0xE0]
00007fa22efdb3a0  add rsp, 0xF0
00007fa22efdb3a7  pop r11
00007fa22efdb3a9  pop r10
00007fa22efdb3ab  pop r9
00007fa22efdb3ad  pop r8
00007fa22efdb3af  pop rsi
00007fa22efdb3b0  pop rdi
00007fa22efdb3b1  pop rdx
00007fa22efdb3b2  pop rcx
00007fa22efdb3b3  pop rax
00007fa22efdb3b4  add rsp, 0x08
00007fa22efdb3b8  jmp 0x00007FA22EFD662F
00007fa22efdb3bd  sub rsp, 0x08
00007fa22efdb3c1  push rax
00007fa22efdb3c2  push rcx
00007fa22efdb3c3  push rdx
00007fa22efdb3c4  push rdi
00007fa22efdb3c5  push rsi
00007fa22efdb3c6  push r8
00007fa22efdb3c8  push r9
00007fa22efdb3ca  push r10
00007fa22efdb3cc  push r11
00007fa22efdb3ce  sub rsp, 0xF0
00007fa22efdb3d5  vmovaps [rsp], xmm0
00007fa22efdb3da  vmovaps [rsp+0x10], xmm1
00007fa22efdb3e0  vmovaps [rsp+0x20], xmm2
00007fa22efdb3e6  vmovaps [rsp+0x30], xmm3
00007fa22efdb3ec  vmovaps [rsp+0x40], xmm4
00007fa22efdb3f2  vmovaps [rsp+0x50], xmm5
00007fa22efdb3f8  vmovaps [rsp+0x60], xmm6
00007fa22efdb3fe  vmovaps [rsp+0x70], xmm7
00007fa22efdb404  vmovaps [rsp+0x80], xmm8
00007fa22efdb40d  vmovaps [rsp+0x90], xmm9
00007fa22efdb416  vmovaps [rsp+0xA0], xmm10
00007fa22efdb41f  vmovaps [rsp+0xB0], xmm11
00007fa22efdb428  vmovaps [rsp+0xC0], xmm12
00007fa22efdb431  vmovaps [rsp+0xD0], xmm13
00007fa22efdb43a  vmovaps [rsp+0xE0], xmm14
00007fa22efdb443  sub rsp, 0x30
00007fa22efdb447  movaps [rsp], xmm15
00007fa22efdb44c  movaps [rsp+0x10], xmm11
00007fa22efdb452  movaps [rsp+0x20], xmm12
00007fa22efdb458  lea rdi, [rsp]
00007fa22efdb45c  mov esi, 0x00
00007fa22efdb461  mov rax, 0x5E9D1A57D530
00007fa22efdb46b  call rax
00007fa22efdb46d  movaps xmm15, [rsp]
00007fa22efdb472  add rsp, 0x30
00007fa22efdb476  vmovaps xmm0, [rsp]
00007fa22efdb47b  vmovaps xmm1, [rsp+0x10]
00007fa22efdb481  vmovaps xmm2, [rsp+0x20]
00007fa22efdb487  vmovaps xmm3, [rsp+0x30]
00007fa22efdb48d  vmovaps xmm4, [rsp+0x40]
00007fa22efdb493  vmovaps xmm5, [rsp+0x50]
00007fa22efdb499  vmovaps xmm6, [rsp+0x60]
00007fa22efdb49f  vmovaps xmm7, [rsp+0x70]
00007fa22efdb4a5  vmovaps xmm8, [rsp+0x80]
00007fa22efdb4ae  vmovaps xmm9, [rsp+0x90]
00007fa22efdb4b7  vmovaps xmm10, [rsp+0xA0]
00007fa22efdb4c0  vmovaps xmm11, [rsp+0xB0]
00007fa22efdb4c9  vmovaps xmm12, [rsp+0xC0]
00007fa22efdb4d2  vmovaps xmm13, [rsp+0xD0]
00007fa22efdb4db  vmovaps xmm14, [rsp+0xE0]
00007fa22efdb4e4  add rsp, 0xF0
00007fa22efdb4eb  pop r11
00007fa22efdb4ed  pop r10
00007fa22efdb4ef  pop r9
00007fa22efdb4f1  pop r8
00007fa22efdb4f3  pop rsi
00007fa22efdb4f4  pop rdi
00007fa22efdb4f5  pop rdx
00007fa22efdb4f6  pop rcx
00007fa22efdb4f7  pop rax
00007fa22efdb4f8  add rsp, 0x08
00007fa22efdb4fc  jmp 0x00007FA22EFD664A
00007fa22efdb501  sub rsp, 0x08
00007fa22efdb505  push rax
00007fa22efdb506  push rcx
00007fa22efdb507  push rdx
00007fa22efdb508  push rdi
00007fa22efdb509  push rsi
00007fa22efdb50a  push r8
00007fa22efdb50c  push r9
00007fa22efdb50e  push r10
00007fa22efdb510  push r11
00007fa22efdb512  sub rsp, 0xF0
00007fa22efdb519  vmovaps [rsp], xmm0
00007fa22efdb51e  vmovaps [rsp+0x10], xmm1
00007fa22efdb524  vmovaps [rsp+0x20], xmm2
00007fa22efdb52a  vmovaps [rsp+0x30], xmm3
00007fa22efdb530  vmovaps [rsp+0x40], xmm4
00007fa22efdb536  vmovaps [rsp+0x50], xmm5
00007fa22efdb53c  vmovaps [rsp+0x60], xmm6
00007fa22efdb542  vmovaps [rsp+0x70], xmm7
00007fa22efdb548  vmovaps [rsp+0x80], xmm8
00007fa22efdb551  vmovaps [rsp+0x90], xmm9
00007fa22efdb55a  vmovaps [rsp+0xA0], xmm10
00007fa22efdb563  vmovaps [rsp+0xB0], xmm11
00007fa22efdb56c  vmovaps [rsp+0xC0], xmm12
00007fa22efdb575  vmovaps [rsp+0xD0], xmm14
00007fa22efdb57e  vmovaps [rsp+0xE0], xmm15
00007fa22efdb587  sub rsp, 0x30
00007fa22efdb58b  movaps [rsp], xmm13
00007fa22efdb590  movaps [rsp+0x10], xmm10
00007fa22efdb596  movaps [rsp+0x20], xmm14
00007fa22efdb59c  lea rdi, [rsp]
00007fa22efdb5a0  mov esi, 0x00
00007fa22efdb5a5  mov rax, 0x5E9D1A57D530
00007fa22efdb5af  call rax
00007fa22efdb5b1  movaps xmm13, [rsp]
00007fa22efdb5b6  add rsp, 0x30
00007fa22efdb5ba  vmovaps xmm0, [rsp]
00007fa22efdb5bf  vmovaps xmm1, [rsp+0x10]
00007fa22efdb5c5  vmovaps xmm2, [rsp+0x20]
00007fa22efdb5cb  vmovaps xmm3, [rsp+0x30]
00007fa22efdb5d1  vmovaps xmm4, [rsp+0x40]
00007fa22efdb5d7  vmovaps xmm5, [rsp+0x50]
00007fa22efdb5dd  vmovaps xmm6, [rsp+0x60]
00007fa22efdb5e3  vmovaps xmm7, [rsp+0x70]
00007fa22efdb5e9  vmovaps xmm8, [rsp+0x80]
00007fa22efdb5f2  vmovaps xmm9, [rsp+0x90]
00007fa22efdb5fb  vmovaps xmm10, [rsp+0xA0]
00007fa22efdb604  vmovaps xmm11, [rsp+0xB0]
00007fa22efdb60d  vmovaps xmm12, [rsp+0xC0]
00007fa22efdb616  vmovaps xmm14, [rsp+0xD0]
00007fa22efdb61f  vmovaps xmm15, [rsp+0xE0]
00007fa22efdb628  add rsp, 0xF0
00007fa22efdb62f  pop r11
00007fa22efdb631  pop r10
00007fa22efdb633  pop r9
00007fa22efdb635  pop r8
00007fa22efdb637  pop rsi
00007fa22efdb638  pop rdi
00007fa22efdb639  pop rdx
00007fa22efdb63a  pop rcx
00007fa22efdb63b  pop rax
00007fa22efdb63c  add rsp, 0x08
00007fa22efdb640  jmp 0x00007FA22EFD666D
00007fa22efdb645  sub rsp, 0x08
00007fa22efdb649  push rax
00007fa22efdb64a  push rcx
00007fa22efdb64b  push rdx
00007fa22efdb64c  push rdi
00007fa22efdb64d  push rsi
00007fa22efdb64e  push r8
00007fa22efdb650  push r9
00007fa22efdb652  push r10
00007fa22efdb654  push r11
00007fa22efdb656  sub rsp, 0xF0
00007fa22efdb65d  vmovaps [rsp], xmm0
00007fa22efdb662  vmovaps [rsp+0x10], xmm1
00007fa22efdb668  vmovaps [rsp+0x20], xmm2
00007fa22efdb66e  vmovaps [rsp+0x30], xmm3
00007fa22efdb674  vmovaps [rsp+0x40], xmm4
00007fa22efdb67a  vmovaps [rsp+0x50], xmm5
00007fa22efdb680  vmovaps [rsp+0x60], xmm6
00007fa22efdb686  vmovaps [rsp+0x70], xmm7
00007fa22efdb68c  vmovaps [rsp+0x80], xmm8
00007fa22efdb695  vmovaps [rsp+0x90], xmm9
00007fa22efdb69e  vmovaps [rsp+0xA0], xmm10
00007fa22efdb6a7  vmovaps [rsp+0xB0], xmm11
00007fa22efdb6b0  vmovaps [rsp+0xC0], xmm12
00007fa22efdb6b9  vmovaps [rsp+0xD0], xmm13
00007fa22efdb6c2  vmovaps [rsp+0xE0], xmm15
00007fa22efdb6cb  sub rsp, 0x30
00007fa22efdb6cf  movaps [rsp], xmm14
00007fa22efdb6d4  movaps [rsp+0x10], xmm1
00007fa22efdb6d9  movaps [rsp+0x20], xmm7
00007fa22efdb6de  lea rdi, [rsp]
00007fa22efdb6e2  mov esi, 0x00
00007fa22efdb6e7  mov rax, 0x5E9D1A57D530
00007fa22efdb6f1  call rax
00007fa22efdb6f3  movaps xmm14, [rsp]
00007fa22efdb6f8  add rsp, 0x30
00007fa22efdb6fc  vmovaps xmm0, [rsp]
00007fa22efdb701  vmovaps xmm1, [rsp+0x10]
00007fa22efdb707  vmovaps xmm2, [rsp+0x20]
00007fa22efdb70d  vmovaps xmm3, [rsp+0x30]
00007fa22efdb713  vmovaps xmm4, [rsp+0x40]
00007fa22efdb719  vmovaps xmm5, [rsp+0x50]
00007fa22efdb71f  vmovaps xmm6, [rsp+0x60]
00007fa22efdb725  vmovaps xmm7, [rsp+0x70]
00007fa22efdb72b  vmovaps xmm8, [rsp+0x80]
00007fa22efdb734  vmovaps xmm9, [rsp+0x90]
00007fa22efdb73d  vmovaps xmm10, [rsp+0xA0]
00007fa22efdb746  vmovaps xmm11, [rsp+0xB0]
00007fa22efdb74f  vmovaps xmm12, [rsp+0xC0]
00007fa22efdb758  vmovaps xmm13, [rsp+0xD0]
00007fa22efdb761  vmovaps xmm15, [rsp+0xE0]
00007fa22efdb76a  add rsp, 0xF0
00007fa22efdb771  pop r11
00007fa22efdb773  pop r10
00007fa22efdb775  pop r9
00007fa22efdb777  pop r8
00007fa22efdb779  pop rsi
00007fa22efdb77a  pop rdi
00007fa22efdb77b  pop rdx
00007fa22efdb77c  pop rcx
00007fa22efdb77d  pop rax
00007fa22efdb77e  add rsp, 0x08
00007fa22efdb782  jmp 0x00007FA22EFD6690
00007fa22efdb787  sub rsp, 0x08
00007fa22efdb78b  push rax
00007fa22efdb78c  push rcx
00007fa22efdb78d  push rdx
00007fa22efdb78e  push rdi
00007fa22efdb78f  push rsi
00007fa22efdb790  push r8
00007fa22efdb792  push r9
00007fa22efdb794  push r10
00007fa22efdb796  push r11
00007fa22efdb798  sub rsp, 0xF0
00007fa22efdb79f  vmovaps [rsp], xmm0
00007fa22efdb7a4  vmovaps [rsp+0x10], xmm2
00007fa22efdb7aa  vmovaps [rsp+0x20], xmm3
00007fa22efdb7b0  vmovaps [rsp+0x30], xmm4
00007fa22efdb7b6  vmovaps [rsp+0x40], xmm5
00007fa22efdb7bc  vmovaps [rsp+0x50], xmm6
00007fa22efdb7c2  vmovaps [rsp+0x60], xmm7
00007fa22efdb7c8  vmovaps [rsp+0x70], xmm8
00007fa22efdb7ce  vmovaps [rsp+0x80], xmm9
00007fa22efdb7d7  vmovaps [rsp+0x90], xmm10
00007fa22efdb7e0  vmovaps [rsp+0xA0], xmm11
00007fa22efdb7e9  vmovaps [rsp+0xB0], xmm12
00007fa22efdb7f2  vmovaps [rsp+0xC0], xmm13
00007fa22efdb7fb  vmovaps [rsp+0xD0], xmm14
00007fa22efdb804  vmovaps [rsp+0xE0], xmm15
00007fa22efdb80d  sub rsp, 0x30
00007fa22efdb811  movaps [rsp], xmm1
00007fa22efdb815  movaps [rsp+0x10], xmm8
00007fa22efdb81b  movaps [rsp+0x20], xmm9
00007fa22efdb821  lea rdi, [rsp]
00007fa22efdb825  mov esi, 0x00
00007fa22efdb82a  mov rax, 0x5E9D1A57D530
00007fa22efdb834  call rax
00007fa22efdb836  movaps xmm1, [rsp]
00007fa22efdb83a  add rsp, 0x30
00007fa22efdb83e  vmovaps xmm0, [rsp]
00007fa22efdb843  vmovaps xmm2, [rsp+0x10]
00007fa22efdb849  vmovaps xmm3, [rsp+0x20]
00007fa22efdb84f  vmovaps xmm4, [rsp+0x30]
00007fa22efdb855  vmovaps xmm5, [rsp+0x40]
00007fa22efdb85b  vmovaps xmm6, [rsp+0x50]
00007fa22efdb861  vmovaps xmm7, [rsp+0x60]
00007fa22efdb867  vmovaps xmm8, [rsp+0x70]
00007fa22efdb86d  vmovaps xmm9, [rsp+0x80]
00007fa22efdb876  vmovaps xmm10, [rsp+0x90]
00007fa22efdb87f  vmovaps xmm11, [rsp+0xA0]
00007fa22efdb888  vmovaps xmm12, [rsp+0xB0]
00007fa22efdb891  vmovaps xmm13, [rsp+0xC0]
00007fa22efdb89a  vmovaps xmm14, [rsp+0xD0]
00007fa22efdb8a3  vmovaps xmm15, [rsp+0xE0]
00007fa22efdb8ac  add rsp, 0xF0
00007fa22efdb8b3  pop r11
00007fa22efdb8b5  pop r10
00007fa22efdb8b7  pop r9
00007fa22efdb8b9  pop r8
00007fa22efdb8bb  pop rsi
00007fa22efdb8bc  pop rdi
00007fa22efdb8bd  pop rdx
00007fa22efdb8be  pop rcx
00007fa22efdb8bf  pop rax
00007fa22efdb8c0  add rsp, 0x08
00007fa22efdb8c4  jmp 0x00007FA22EFD66B2
00007fa22efdb8c9  call 0x00007FA22EEB3E40
00007fa22efdb8ce  jmp 0x00007FA22EFD66C0
00007fa22efdb8d3  call 0x00007FA22EE0C380
00007fa22efdb8d8  jmp 0x00007FA22EFD66CA
00007fa22efdb8dd  call 0x00007FA22EE0D600
00007fa22efdb8e2  jmp 0x00007FA22EFD66D4
00007fa22efdb8e7  call 0x00007FA22EDFF540
00007fa22efdb8ec  jmp 0x00007FA22EFD66DE
00007fa22efdb8f1  int3
00007fa22efdb8f2  nop [rax+rax*1], ax
00007fa22efdb8fb  nop [rax+rax*1], eax
00007fa22efdb900  mov eax, [r15+0x48]
00007fa22efdb904  lea r14d, [eax+0x01]
00007fa22efdb909  mov [rsp+0x10], r14d
00007fa22efdb90e  mov r14d, r14d
00007fa22efdb911  mov [r15+0x48], r14
00007fa22efdb915  xor eax, eax
00007fa22efdb917  mov r14d, [rsp+0x10]
00007fa22efdb91c  cmp r14d, 0x1F4
00007fa22efdb923  cmc
00007fa22efdb924  lahf
00007fa22efdb925  seto al
00007fa22efdb928  mov [r15+0x108], eax
00007fa22efdb92f  mov eax, [r15+0x108]
00007fa22efdb936  sahf
00007fa22efdb937  jnz 0x00007FA22EFDB969
00007fa22efdb939  cmp dword ptr [r15+0x318], 0x00
00007fa22efdb941  jz 0x00007FA22EFE1AB0
00007fa22efdb947  nop [rax+rax*1], ax
00007fa22efdb950  nop [rax+rax*1], eax
00007fa22efdb958  mov eax, 0x410450
00007fa22efdb95d  mov [r15+0x100], rax
00007fa22efdb964  jmp 0x00007FA22EDFE110
00007fa22efdb969  cmp dword ptr [r15+0x318], 0x00
00007fa22efdb971  jz 0x00007FA22EFDB9A0
00007fa22efdb977  nop [rax+rax*1], ax
00007fa22efdb980  nop [rax+rax*1], eax
00007fa22efdb988  mov eax, 0x410274
00007fa22efdb98d  mov [r15+0x100], rax
00007fa22efdb994  jmp 0x00007FA22EDFE110
00007fa22efdb999  int3
00007fa22efdb99a  int3
00007fa22efdb99b  nop [rax+rax*1], eax
00007fa22efdb9a0  mov rax, [r15+0x40]
00007fa22efdb9a4  movaps xmm1, [r15+0x1D0]
00007fa22efdb9ac  vmovaps [rsp+0x10], xmm1
00007fa22efdb9b2  vmovaps xmm15, [rsp+0x10]
00007fa22efdb9b8  por xmm1, xmm15
00007fa22efdb9bd  movaps xmm14, [r15+0x1A0]
00007fa22efdb9c5  vmovaps [rsp+0x10], xmm14
00007fa22efdb9cb  vmovaps xmm13, [rsp+0x10]
00007fa22efdb9d1  por xmm14, xmm13
00007fa22efdb9d6  lea r14, [rax+0x30]
00007fa22efdb9da  mov r12, [r13+r14*1]
00007fa22efdb9df  lea r14, [rax+0x38]
00007fa22efdb9e3  mov r11, [r13+r14*1]
00007fa22efdb9e8  movq xmm13, r12
00007fa22efdb9ed  movq xmm12, r11
00007fa22efdb9f2  movq xmm13, xmm13
00007fa22efdb9f7  vmovaps [rsp+0x10], xmm13
00007fa22efdb9fd  movq xmm13, xmm13
00007fa22efdba02  movaps [r15+0x130], xmm13
00007fa22efdba0a  movq xmm12, xmm12
00007fa22efdba0f  vmovaps [rsp+0x20], xmm12
00007fa22efdba15  movq xmm12, xmm12
00007fa22efdba1a  movaps [r15+0x280], xmm12
00007fa22efdba22  movaps xmm13, [r15+0x270]
00007fa22efdba2a  vmovaps [rsp+0x30], xmm13
00007fa22efdba30  vmovaps xmm12, [rsp+0x30]
00007fa22efdba36  por xmm13, xmm12
00007fa22efdba3b  lea r14, [rax+0x20]
00007fa22efdba3f  mov r12, [r13+r14*1]
00007fa22efdba44  lea r14, [rax+0x28]
00007fa22efdba48  mov r11, [r13+r14*1]
00007fa22efdba4d  movq xmm12, r12
00007fa22efdba52  movq xmm11, r11
00007fa22efdba57  movq xmm12, xmm12
00007fa22efdba5c  vmovaps [rsp+0x30], xmm12
00007fa22efdba62  movq xmm12, xmm12
00007fa22efdba67  movaps [r15+0x150], xmm12
00007fa22efdba6f  movq xmm11, xmm11
00007fa22efdba74  vmovaps [rsp+0x40], xmm11
00007fa22efdba7a  movq xmm11, xmm11
00007fa22efdba7f  movaps [r15+0x140], xmm11
00007fa22efdba87  lea r14, [rax+0x10]
00007fa22efdba8b  mov r12, [r13+r14*1]
00007fa22efdba90  lea r14, [rax+0x18]
00007fa22efdba94  mov r11, [r13+r14*1]
00007fa22efdba99  movq xmm12, r12
00007fa22efdba9e  movq xmm11, r11
00007fa22efdbaa3  movq xmm12, xmm12
00007fa22efdbaa8  vmovaps [rsp+0x50], xmm12
00007fa22efdbaae  movq xmm12, xmm12
00007fa22efdbab3  movaps [r15+0x170], xmm12
00007fa22efdbabb  movq xmm11, xmm11
00007fa22efdbac0  vmovaps [rsp+0x60], xmm11
00007fa22efdbac6  movq xmm11, xmm11
00007fa22efdbacb  movaps [r15+0x160], xmm11
00007fa22efdbad3  mov r14, [r13+rax*1]
00007fa22efdbad8  vmovq xmm12, r14
00007fa22efdbadd  vpbroadcastq xmm12, xmm12
00007fa22efdbae2  lea r14, [rax+0x08]
00007fa22efdbae6  mov rax, [r13+r14*1]
00007fa22efdbaeb  movq xmm11, rax
00007fa22efdbaf0  movaps [r15+0x230], xmm11
00007fa22efdbaf8  mov rax, [r15+0xF8]
00007fa22efdbaff  lea r14, [rax+0x50]
00007fa22efdbb03  movups xmm11, [r13+r14*1]
00007fa22efdbb09  lea r14, [rax+0x60]
00007fa22efdbb0d  movups xmm10, [r13+r14*1]
00007fa22efdbb13  lea r14, [rax+0x30]
00007fa22efdbb17  movups xmm9, [r13+r14*1]
00007fa22efdbb1d  mov r14, [r15+0x50]
00007fa22efdbb21  mov [r15+0x60], r14
00007fa22efdbb25  mov qword ptr [r15+0x58], 0x40
00007fa22efdbb2d  movaps xmm8, xmm12
00007fa22efdbb31  mulpd xmm8, xmm15
00007fa22efdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007fa22efdbb3c  ptest xmm7, xmm7
00007fa22efdbb41  jnz 0x00007FA22EFDC96A
00007fa22efdbb47  movq xmm15, qword ptr [r15+0x230]
00007fa22efdbb50  vmovaps [rsp+0x70], xmm15
00007fa22efdbb56  vpermilpd xmm15, xmm15, 0x00
00007fa22efdbb5c  movaps xmm7, xmm9
00007fa22efdbb60  mulpd xmm7, xmm15
00007fa22efdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa22efdbb6a  ptest xmm6, xmm6
00007fa22efdbb6f  jnz 0x00007FA22EFDCAAE
00007fa22efdbb75  vxorps xmm15, xmm15, xmm15
00007fa22efdbb7a  vpbroadcastq xmm15, xmm15
00007fa22efdbb7f  movaps xmm9, xmm12
00007fa22efdbb83  mulpd xmm9, xmm10
00007fa22efdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007fa22efdbb8e  ptest xmm6, xmm6
00007fa22efdbb93  jnz 0x00007FA22EFDCBF0
00007fa22efdbb99  movaps xmm10, xmm12
00007fa22efdbb9d  mulpd xmm10, xmm11
00007fa22efdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007fa22efdbba8  ptest xmm6, xmm6
00007fa22efdbbad  jnz 0x00007FA22EFDCD34
00007fa22efdbbb3  movaps xmm11, [r15+0x1F0]
00007fa22efdbbbb  movaps xmm6, xmm12
00007fa22efdbbbf  mulpd xmm6, xmm11
00007fa22efdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007fa22efdbbc9  ptest xmm5, xmm5
00007fa22efdbbce  jnz 0x00007FA22EFDCE78
00007fa22efdbbd4  movaps xmm12, [r15+0x2A0]
00007fa22efdbbdc  vmovaps [rsp+0x80], xmm12
00007fa22efdbbe5  vmovaps xmm11, [rsp+0x80]
00007fa22efdbbee  por xmm12, xmm11
00007fa22efdbbf3  movaps xmm11, [r15+0x250]
00007fa22efdbbfb  vmovaps [rsp+0x80], xmm11
00007fa22efdbc04  vmovaps xmm5, [rsp+0x80]
00007fa22efdbc0d  por xmm11, xmm5
00007fa22efdbc12  vmovaps xmm4, [rsp+0x70]
00007fa22efdbc18  vpermilpd xmm4, xmm4, 0x00
00007fa22efdbc1e  movaps xmm3, xmm5
00007fa22efdbc21  mulpd xmm3, xmm4
00007fa22efdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007fa22efdbc2a  ptest xmm2, xmm2
00007fa22efdbc2f  jnz 0x00007FA22EFDCFBA
00007fa22efdbc35  mov [rsp+0x80], rax
00007fa22efdbc3d  xor eax, eax
00007fa22efdbc3f  mov r12d, 0x40
00007fa22efdbc45  mov r11d, 0x200
00007fa22efdbc4b  cmp r12, r11
00007fa22efdbc4e  cmc
00007fa22efdbc4f  lahf
00007fa22efdbc50  seto al
00007fa22efdbc53  mov [r15+0x108], eax
00007fa22efdbc5a  movaps xmm5, xmm8
00007fa22efdbc5e  addpd xmm5, xmm15
00007fa22efdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007fa22efdbc68  ptest xmm4, xmm4
00007fa22efdbc6d  jnz 0x00007FA22EFDD0FA
00007fa22efdbc73  movaps xmm8, [r15+0x1B0]
00007fa22efdbc7b  movaps xmm4, xmm9
00007fa22efdbc7f  addpd xmm4, xmm8
00007fa22efdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007fa22efdbc89  ptest xmm2, xmm2
00007fa22efdbc8e  jnz 0x00007FA22EFDD23C
00007fa22efdbc94  movaps xmm9, xmm10
00007fa22efdbc98  addpd xmm9, xmm8
00007fa22efdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007fa22efdbca3  ptest xmm2, xmm2
00007fa22efdbca8  jnz 0x00007FA22EFDD37E
00007fa22efdbcae  movaps xmm10, [r15+0x2F0]
00007fa22efdbcb6  vmovaps [rsp+0x90], xmm10
00007fa22efdbcbf  vmovaps xmm8, [rsp+0x90]
00007fa22efdbcc8  por xmm10, xmm8
00007fa22efdbccd  movaps xmm8, [r15+0x2E0]
00007fa22efdbcd5  vmovaps [rsp+0x90], xmm8
00007fa22efdbcde  vmovaps xmm2, [rsp+0x90]
00007fa22efdbce7  por xmm8, xmm2
00007fa22efdbcec  movaps xmm2, [r15+0x2D0]
00007fa22efdbcf4  vmovaps [rsp+0x90], xmm2
00007fa22efdbcfd  vmovaps [rsp+0xA0], xmm1
00007fa22efdbd06  vmovaps xmm1, [rsp+0x90]
00007fa22efdbd0f  por xmm2, xmm1
00007fa22efdbd13  movaps xmm1, [r15+0x200]
00007fa22efdbd1b  vmovaps [rsp+0x90], xmm1
00007fa22efdbd24  vmovaps [rsp+0xB0], xmm15
00007fa22efdbd2d  vmovaps xmm15, [rsp+0x90]
00007fa22efdbd36  por xmm1, xmm15
00007fa22efdbd3b  movaps xmm15, [r15+0x1C0]
00007fa22efdbd43  vmovaps [rsp+0x90], xmm15
00007fa22efdbd4c  vmovaps [rsp+0xC0], xmm1
00007fa22efdbd55  vmovaps xmm1, [rsp+0x90]
00007fa22efdbd5e  por xmm15, xmm1
00007fa22efdbd63  movaps xmm1, [r15+0x190]
00007fa22efdbd6b  vmovaps [rsp+0x90], xmm1
00007fa22efdbd74  vmovaps [rsp+0xD0], xmm15
00007fa22efdbd7d  vmovaps xmm15, [rsp+0x90]
00007fa22efdbd86  por xmm1, xmm15
00007fa22efdbd8b  movaps xmm15, [r15+0x300]
00007fa22efdbd93  vmovaps [rsp+0x90], xmm15
00007fa22efdbd9c  vmovaps [rsp+0xE0], xmm1
00007fa22efdbda5  vmovaps xmm1, [rsp+0x90]
00007fa22efdbdae  por xmm15, xmm1
00007fa22efdbdb3  mov rax, [rsp+0x80]
00007fa22efdbdbb  lea r12, [rax+0xA0]
00007fa22efdbdc2  movups xmm1, [r13+r12*1]
00007fa22efdbdc8  lea r12, [rax+0xB0]
00007fa22efdbdcf  vmovaps [rsp+0x80], xmm1
00007fa22efdbdd8  movups xmm1, [r13+r12*1]
00007fa22efdbdde  vmovaps [rsp+0x90], xmm1
00007fa22efdbde7  vmovaps [rsp+0xF0], xmm15
00007fa22efdbdf0  vmovaps xmm15, [rsp+0xB0]
00007fa22efdbdf9  vmovaps [rsp+0xB0], xmm14
00007fa22efdbe02  movaps xmm1, xmm6
00007fa22efdbe05  addpd xmm1, xmm15
00007fa22efdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007fa22efdbe0f  ptest xmm14, xmm14
00007fa22efdbe15  jnz 0x00007FA22EFDD4D6
00007fa22efdbe1b  lea r12, [rax+0xF0]
00007fa22efdbe22  movups xmm15, [r13+r12*1]
00007fa22efdbe28  movaps xmm14, xmm4
00007fa22efdbe2c  addpd xmm14, xmm3
00007fa22efdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007fa22efdbe37  ptest xmm6, xmm6
00007fa22efdbe3c  jnz 0x00007FA22EFDD621
00007fa22efdbe42  movaps xmm6, xmm9
00007fa22efdbe46  addpd xmm6, xmm7
00007fa22efdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007fa22efdbe4f  ptest xmm4, xmm4
00007fa22efdbe54  jnz 0x00007FA22EFDD763
00007fa22efdbe5a  vmovaps xmm9, [rsp+0x70]
00007fa22efdbe60  vpermilpd xmm9, xmm9, 0x00
00007fa22efdbe66  vmovaps xmm4, [rsp+0x90]
00007fa22efdbe6f  movaps xmm7, xmm4
00007fa22efdbe72  mulpd xmm7, xmm9
00007fa22efdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007fa22efdbe7c  ptest xmm3, xmm3
00007fa22efdbe81  jnz 0x00007FA22EFDD8A4
00007fa22efdbe87  vmovaps xmm9, [rsp+0x50]
00007fa22efdbe8d  vpermilpd xmm9, xmm9, 0x00
00007fa22efdbe93  movaps xmm4, xmm15
00007fa22efdbe97  mulpd xmm4, xmm9
00007fa22efdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007fa22efdbea1  ptest xmm3, xmm3
00007fa22efdbea6  jnz 0x00007FA22EFDD9E5
00007fa22efdbeac  lea r12, [rax+0xE0]
00007fa22efdbeb3  movups xmm15, [r13+r12*1]
00007fa22efdbeb9  vmovaps xmm9, [rsp+0x70]
00007fa22efdbebf  vpermilpd xmm9, xmm9, 0x00
00007fa22efdbec5  vmovaps [rsp+0x70], xmm1
00007fa22efdbecb  vmovaps xmm1, [rsp+0x80]
00007fa22efdbed4  vmovaps [rsp+0x80], xmm15
00007fa22efdbedd  movaps xmm3, xmm1
00007fa22efdbee0  mulpd xmm3, xmm9
00007fa22efdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007fa22efdbeea  ptest xmm15, xmm15
00007fa22efdbef0  jnz 0x00007FA22EFDDB31
00007fa22efdbef6  vmovaps xmm1, [rsp+0xF0]
00007fa22efdbeff  vmovaps xmm15, [rsp+0xF0]
00007fa22efdbf08  por xmm1, xmm15
00007fa22efdbf0d  movaps [r15+0x300], xmm1
00007fa22efdbf15  vmovaps xmm15, [rsp+0xE0]
00007fa22efdbf1e  vmovaps xmm9, [rsp+0xE0]
00007fa22efdbf27  por xmm15, xmm9
00007fa22efdbf2c  movaps [r15+0x190], xmm15
00007fa22efdbf34  vmovaps xmm9, [rsp+0x50]
00007fa22efdbf3a  vpermilpd xmm9, xmm9, 0x00
00007fa22efdbf40  vmovaps [rsp+0x90], xmm1
00007fa22efdbf49  vmovaps [rsp+0xE0], xmm15
00007fa22efdbf52  vmovaps xmm15, [rsp+0x80]
00007fa22efdbf5b  vmovaps [rsp+0x80], xmm14
00007fa22efdbf64  movaps xmm1, xmm15
00007fa22efdbf68  mulpd xmm1, xmm9
00007fa22efdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007fa22efdbf72  ptest xmm14, xmm14
00007fa22efdbf78  jnz 0x00007FA22EFDDC72
00007fa22efdbf7e  lea r12, [rax+0x90]
00007fa22efdbf85  movups xmm15, [r13+r12*1]
00007fa22efdbf8b  vmovaps xmm14, [rsp+0xD0]
00007fa22efdbf94  vmovaps xmm9, [rsp+0xD0]
00007fa22efdbf9d  por xmm14, xmm9
00007fa22efdbfa2  movaps [r15+0x1C0], xmm14
00007fa22efdbfaa  vmovaps xmm9, [rsp+0xC0]
00007fa22efdbfb3  vmovaps [rsp+0xD0], xmm1
00007fa22efdbfbc  vmovaps xmm1, [rsp+0xC0]
00007fa22efdbfc5  por xmm9, xmm1
00007fa22efdbfca  movaps [r15+0x200], xmm9
00007fa22efdbfd2  vmovaps [rsp+0xC0], xmm2
00007fa22efdbfdb  vmovaps xmm1, [rsp+0xC0]
00007fa22efdbfe4  por xmm2, xmm1
00007fa22efdbfe8  movaps [r15+0x2D0], xmm2
00007fa22efdbff0  vmovaps [rsp+0xC0], xmm8
00007fa22efdbff9  vmovaps xmm1, [rsp+0xC0]
00007fa22efdc002  por xmm8, xmm1
00007fa22efdc007  movaps [r15+0x2E0], xmm8
00007fa22efdc00f  vmovaps [rsp+0xC0], xmm15
00007fa22efdc018  movaps xmm1, xmm5
00007fa22efdc01b  addpd xmm1, xmm7
00007fa22efdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa22efdc024  ptest xmm15, xmm15
00007fa22efdc02a  jnz 0x00007FA22EFDDDBE
00007fa22efdc030  vmovaps xmm15, [rsp+0x50]
00007fa22efdc036  vpermilpd xmm15, xmm15, 0x00
00007fa22efdc03c  vmovaps xmm5, [rsp+0xC0]
00007fa22efdc045  vmovaps [rsp+0xC0], xmm1
00007fa22efdc04e  movaps xmm7, xmm5
00007fa22efdc051  mulpd xmm7, xmm15
00007fa22efdc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007fa22efdc05b  ptest xmm1, xmm1
00007fa22efdc060  jnz 0x00007FA22EFDDEFE
00007fa22efdc066  lea r12, [rax+0x80]
00007fa22efdc06d  movups xmm1, [r13+r12*1]
00007fa22efdc073  vmovaps xmm5, [rsp+0x70]
00007fa22efdc079  vmovaps [rsp+0x70], xmm1
00007fa22efdc07f  movaps xmm15, xmm5
00007fa22efdc083  addpd xmm15, xmm3
00007fa22efdc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa22efdc08e  ptest xmm1, xmm1
00007fa22efdc093  jnz 0x00007FA22EFDE049
00007fa22efdc099  vmovaps xmm5, [rsp+0x80]
00007fa22efdc0a2  movaps xmm1, xmm5
00007fa22efdc0a5  addpd xmm1, xmm4
00007fa22efdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007fa22efdc0ae  ptest xmm3, xmm3
00007fa22efdc0b3  jnz 0x00007FA22EFDE18B
00007fa22efdc0b9  vmovaps [rsp+0x80], xmm10
00007fa22efdc0c2  vmovaps xmm5, [rsp+0x80]
00007fa22efdc0cb  por xmm10, xmm5
00007fa22efdc0d0  movaps [r15+0x2F0], xmm10
00007fa22efdc0d8  vmovaps xmm5, [rsp+0x50]
00007fa22efdc0de  vpermilpd xmm5, xmm5, 0x00
00007fa22efdc0e4  vmovaps xmm3, [rsp+0x70]
00007fa22efdc0ea  vmovaps [rsp+0x50], xmm1
00007fa22efdc0f0  movaps xmm4, xmm3
00007fa22efdc0f3  mulpd xmm4, xmm5
00007fa22efdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007fa22efdc0fc  ptest xmm1, xmm1
00007fa22efdc101  jnz 0x00007FA22EFDE2CB
00007fa22efdc107  lea r12, [rax+0xD0]
00007fa22efdc10e  movups xmm1, [r13+r12*1]
00007fa22efdc114  vmovaps xmm3, [rsp+0xD0]
00007fa22efdc11d  vmovaps [rsp+0x70], xmm1
00007fa22efdc123  movaps xmm5, xmm6
00007fa22efdc126  addpd xmm5, xmm3
00007fa22efdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007fa22efdc12f  ptest xmm1, xmm1
00007fa22efdc134  jnz 0x00007FA22EFDE415
00007fa22efdc13a  vmovaps xmm1, [rsp+0x60]
00007fa22efdc140  vpermilpd xmm1, xmm1, 0x00
00007fa22efdc146  movaps xmm6, xmm9
00007fa22efdc14a  mulpd xmm6, xmm1
00007fa22efdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007fa22efdc153  ptest xmm3, xmm3
00007fa22efdc158  jnz 0x00007FA22EFDE555
00007fa22efdc15e  movaps [r15+0x260], xmm6
00007fa22efdc166  vxorps xmm1, xmm1, xmm1
00007fa22efdc16a  vpbroadcastq xmm1, xmm1
00007fa22efdc16f  movaps [r15+0x1B0], xmm1
00007fa22efdc177  vmovaps xmm1, [rsp+0x60]
00007fa22efdc17d  vpermilpd xmm1, xmm1, 0x00
00007fa22efdc183  vmovaps xmm3, [rsp+0x70]
00007fa22efdc189  vmovaps [rsp+0x70], xmm15
00007fa22efdc18f  movaps xmm9, xmm3
00007fa22efdc193  mulpd xmm9, xmm1
00007fa22efdc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007fa22efdc19e  ptest xmm15, xmm15
00007fa22efdc1a4  jnz 0x00007FA22EFDE696
00007fa22efdc1aa  lea r12, [rax+0xC0]
00007fa22efdc1b1  movups xmm1, [r13+r12*1]
00007fa22efdc1b7  vmovaps xmm3, [rsp+0xC0]
00007fa22efdc1c0  vmovaps [rsp+0x80], xmm1
00007fa22efdc1c9  movaps xmm15, xmm3
00007fa22efdc1cd  addpd xmm15, xmm7
00007fa22efdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa22efdc1d8  ptest xmm1, xmm1
00007fa22efdc1dd  jnz 0x00007FA22EFDE7E2
00007fa22efdc1e3  vmovaps [rsp+0xC0], xmm13
00007fa22efdc1ec  vmovaps xmm1, [rsp+0xC0]
00007fa22efdc1f5  por xmm13, xmm1
00007fa22efdc1fa  movaps [r15+0x270], xmm13
00007fa22efdc202  vmovaps xmm1, [rsp+0xB0]
00007fa22efdc20b  vmovaps xmm7, [rsp+0xB0]
00007fa22efdc214  por xmm1, xmm7
00007fa22efdc218  movaps [r15+0x1A0], xmm1
00007fa22efdc220  vmovaps xmm1, [rsp+0x60]
00007fa22efdc226  vpermilpd xmm1, xmm1, 0x00
00007fa22efdc22c  vmovaps [rsp+0xB0], xmm1
00007fa22efdc235  vmovaps xmm1, [rsp+0x80]
00007fa22efdc23e  vmovaps [rsp+0x80], xmm15
00007fa22efdc247  vmovaps xmm15, [rsp+0xB0]
00007fa22efdc250  vmovaps [rsp+0xB0], xmm14
00007fa22efdc259  movaps xmm3, xmm1
00007fa22efdc25c  mulpd xmm3, xmm15
00007fa22efdc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007fa22efdc266  ptest xmm14, xmm14
00007fa22efdc26c  jnz 0x00007FA22EFDE924
00007fa22efdc272  lea r12, [rax+0x20]
00007fa22efdc276  movups xmm1, [r13+r12*1]
00007fa22efdc27c  movaps [r15+0x110], xmm1
00007fa22efdc284  vmovaps xmm14, [rsp+0x70]
00007fa22efdc28a  vmovaps [rsp+0x70], xmm1
00007fa22efdc290  movaps xmm15, xmm14
00007fa22efdc294  addpd xmm15, xmm4
00007fa22efdc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa22efdc29f  ptest xmm1, xmm1
00007fa22efdc2a4  jnz 0x00007FA22EFDEA6F
00007fa22efdc2aa  vmovaps xmm1, [rsp+0x60]
00007fa22efdc2b0  vpermilpd xmm1, xmm1, 0x00
00007fa22efdc2b6  movaps xmm14, xmm2
00007fa22efdc2ba  mulpd xmm14, xmm1
00007fa22efdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007fa22efdc2c5  ptest xmm4, xmm4
00007fa22efdc2ca  jnz 0x00007FA22EFDEBB2
00007fa22efdc2d0  vmovaps xmm4, [rsp+0x50]
00007fa22efdc2d6  movaps xmm1, xmm4
00007fa22efdc2d9  addpd xmm1, xmm9
00007fa22efdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa22efdc2e3  ptest xmm2, xmm2
00007fa22efdc2e8  jnz 0x00007FA22EFDECF4
00007fa22efdc2ee  vmovaps xmm9, [rsp+0x30]
00007fa22efdc2f4  vpermilpd xmm9, xmm9, 0x00
00007fa22efdc2fa  vmovaps xmm2, [rsp+0x70]
00007fa22efdc300  vmovaps [rsp+0x50], xmm1
00007fa22efdc306  movaps xmm4, xmm2
00007fa22efdc309  mulpd xmm4, xmm9
00007fa22efdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007fa22efdc313  ptest xmm1, xmm1
00007fa22efdc318  jnz 0x00007FA22EFDEE35
00007fa22efdc31e  vmovaps xmm1, [rsp+0x30]
00007fa22efdc324  vpermilpd xmm1, xmm1, 0x00
00007fa22efdc32a  vmovaps xmm2, [rsp+0x90]
00007fa22efdc333  vmovaps [rsp+0x60], xmm15
00007fa22efdc339  movaps xmm9, xmm2
00007fa22efdc33d  mulpd xmm9, xmm1
00007fa22efdc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007fa22efdc348  ptest xmm15, xmm15
00007fa22efdc34e  jnz 0x00007FA22EFDEF76
00007fa22efdc354  vmovaps xmm15, [rsp+0x80]
00007fa22efdc35d  movaps xmm1, xmm15
00007fa22efdc361  addpd xmm1, xmm6
00007fa22efdc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa22efdc36a  ptest xmm2, xmm2
00007fa22efdc36f  jnz 0x00007FA22EFDF0B8
00007fa22efdc375  movaps xmm15, xmm5
00007fa22efdc379  addpd xmm15, xmm3
00007fa22efdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007fa22efdc384  ptest xmm6, xmm6
00007fa22efdc389  jnz 0x00007FA22EFDF1F9
00007fa22efdc38f  vmovaps xmm6, [rsp+0x30]
00007fa22efdc395  vpermilpd xmm6, xmm6, 0x00
00007fa22efdc39b  movaps xmm5, xmm8
00007fa22efdc39f  mulpd xmm5, xmm6
00007fa22efdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007fa22efdc3a8  ptest xmm3, xmm3
00007fa22efdc3ad  jnz 0x00007FA22EFDF33B
00007fa22efdc3b3  vmovaps xmm8, [rsp+0x30]
00007fa22efdc3b9  vpermilpd xmm8, xmm8, 0x00
00007fa22efdc3bf  movaps xmm6, xmm10
00007fa22efdc3c3  mulpd xmm6, xmm8
00007fa22efdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007fa22efdc3cd  ptest xmm3, xmm3
00007fa22efdc3d2  jnz 0x00007FA22EFDF47C
00007fa22efdc3d8  vmovaps xmm8, [rsp+0x60]
00007fa22efdc3de  movaps xmm10, xmm8
00007fa22efdc3e2  addpd xmm10, xmm14
00007fa22efdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007fa22efdc3ed  ptest xmm3, xmm3
00007fa22efdc3f2  jnz 0x00007FA22EFDF5BE
00007fa22efdc3f8  vmovaps xmm8, [rsp+0x50]
00007fa22efdc3fe  movaps xmm14, xmm8
00007fa22efdc402  addpd xmm14, xmm4
00007fa22efdc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007fa22efdc40d  ptest xmm3, xmm3
00007fa22efdc412  jnz 0x00007FA22EFDF702
00007fa22efdc418  vmovaps xmm8, [rsp+0x40]
00007fa22efdc41e  vpermilpd xmm8, xmm8, 0x00
00007fa22efdc424  movaps xmm4, xmm13
00007fa22efdc428  mulpd xmm4, xmm8
00007fa22efdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007fa22efdc432  ptest xmm3, xmm3
00007fa22efdc437  jnz 0x00007FA22EFDF845
00007fa22efdc43d  movaps xmm13, xmm15
00007fa22efdc441  addpd xmm13, xmm9
00007fa22efdc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007fa22efdc44c  ptest xmm8, xmm8
00007fa22efdc452  jnz 0x00007FA22EFDF987
00007fa22efdc458  movaps xmm15, xmm1
00007fa22efdc45c  addpd xmm15, xmm5
00007fa22efdc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007fa22efdc467  ptest xmm9, xmm9
00007fa22efdc46d  jnz 0x00007FA22EFDFACB
00007fa22efdc473  vmovaps [rsp+0x30], xmm11
00007fa22efdc479  vmovaps xmm1, [rsp+0x30]
00007fa22efdc47f  por xmm11, xmm1
00007fa22efdc484  movaps [r15+0x250], xmm11
00007fa22efdc48c  vmovaps [rsp+0x30], xmm12
00007fa22efdc492  vmovaps xmm1, [rsp+0x30]
00007fa22efdc498  por xmm12, xmm1
00007fa22efdc49d  movaps [r15+0x2A0], xmm12
00007fa22efdc4a5  vmovaps xmm1, [rsp+0xA0]
00007fa22efdc4ae  vmovaps xmm11, [rsp+0xA0]
00007fa22efdc4b7  por xmm1, xmm11
00007fa22efdc4bc  movaps [r15+0x1D0], xmm1
00007fa22efdc4c4  lea r12, [rax+0x40]
00007fa22efdc4c8  movups xmm1, [r13+r12*1]
00007fa22efdc4ce  movaps [r15+0x2C0], xmm1
00007fa22efdc4d6  vmovaps xmm11, [rsp+0x40]
00007fa22efdc4dc  vpermilpd xmm11, xmm11, 0x00
00007fa22efdc4e2  vmovaps xmm8, [rsp+0xE0]
00007fa22efdc4eb  movaps xmm9, xmm8
00007fa22efdc4ef  mulpd xmm9, xmm11
00007fa22efdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007fa22efdc4fa  ptest xmm5, xmm5
00007fa22efdc4ff  jnz 0x00007FA22EFDFC17
00007fa22efdc505  movaps xmm11, xmm10
00007fa22efdc509  addpd xmm11, xmm6
00007fa22efdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007fa22efdc514  ptest xmm8, xmm8
00007fa22efdc51a  jnz 0x00007FA22EFDFD5B
00007fa22efdc520  movaps xmm10, xmm14
00007fa22efdc524  addpd xmm10, xmm4
00007fa22efdc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007fa22efdc52f  ptest xmm8, xmm8
00007fa22efdc535  jnz 0x00007FA22EFDFE9E
00007fa22efdc53b  vmovaps xmm14, [rsp+0x40]
00007fa22efdc541  vpermilpd xmm14, xmm14, 0x00
00007fa22efdc547  movaps xmm8, xmm1
00007fa22efdc54b  mulpd xmm8, xmm14
00007fa22efdc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007fa22efdc556  ptest xmm6, xmm6
00007fa22efdc55b  jnz 0x00007FA22EFDFFE1
00007fa22efdc561  movaps xmm1, [r15+0x2B0]
00007fa22efdc569  vmovaps xmm14, [rsp+0x40]
00007fa22efdc56f  vpermilpd xmm14, xmm14, 0x00
00007fa22efdc575  movaps xmm6, xmm1
00007fa22efdc578  mulpd xmm6, xmm14
00007fa22efdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007fa22efdc582  ptest xmm5, xmm5
00007fa22efdc587  jnz 0x00007FA22EFE0124
00007fa22efdc58d  vmovaps xmm1, [rsp+0x10]
00007fa22efdc593  vpermilpd xmm1, xmm1, 0x00
00007fa22efdc599  movaps xmm14, xmm12
00007fa22efdc59d  mulpd xmm14, xmm1
00007fa22efdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007fa22efdc5a8  ptest xmm5, xmm5
00007fa22efdc5ad  jnz 0x00007FA22EFE0265
00007fa22efdc5b3  movaps xmm1, xmm13
00007fa22efdc5b7  addpd xmm1, xmm9
00007fa22efdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa22efdc5c1  ptest xmm12, xmm12
00007fa22efdc5c7  jnz 0x00007FA22EFE03A8
00007fa22efdc5cd  vmovaps xmm13, [rsp+0x10]
00007fa22efdc5d3  vpermilpd xmm13, xmm13, 0x00
00007fa22efdc5d9  movaps xmm12, xmm7
00007fa22efdc5dd  mulpd xmm12, xmm13
00007fa22efdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007fa22efdc5e8  ptest xmm9, xmm9
00007fa22efdc5ee  jnz 0x00007FA22EFE04EA
00007fa22efdc5f4  movaps xmm13, xmm15
00007fa22efdc5f8  addpd xmm13, xmm8
00007fa22efdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007fa22efdc603  ptest xmm9, xmm9
00007fa22efdc609  jnz 0x00007FA22EFE062D
00007fa22efdc60f  movaps xmm15, [r15+0x290]
00007fa22efdc617  vmovaps xmm9, [rsp+0x10]
00007fa22efdc61d  vpermilpd xmm9, xmm9, 0x00
00007fa22efdc623  movaps xmm8, xmm15
00007fa22efdc627  mulpd xmm8, xmm9
00007fa22efdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007fa22efdc632  ptest xmm7, xmm7
00007fa22efdc637  jnz 0x00007FA22EFE0771
00007fa22efdc63d  movaps xmm15, xmm11
00007fa22efdc641  addpd xmm15, xmm6
00007fa22efdc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007fa22efdc64c  ptest xmm9, xmm9
00007fa22efdc652  jnz 0x00007FA22EFE08B5
00007fa22efdc658  movaps xmm11, [r15+0x1E0]
00007fa22efdc660  vmovaps xmm9, [rsp+0x10]
00007fa22efdc666  vpermilpd xmm9, xmm9, 0x00
00007fa22efdc66c  movaps xmm7, xmm11
00007fa22efdc670  mulpd xmm7, xmm9
00007fa22efdc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa22efdc67a  ptest xmm6, xmm6
00007fa22efdc67f  jnz 0x00007FA22EFE09F8
00007fa22efdc685  movaps xmm11, xmm10
00007fa22efdc689  addpd xmm11, xmm14
00007fa22efdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007fa22efdc694  ptest xmm9, xmm9
00007fa22efdc69a  jnz 0x00007FA22EFE0B3A
00007fa22efdc6a0  lea r12, [rax+0x70]
00007fa22efdc6a4  movups xmm14, [r13+r12*1]
00007fa22efdc6aa  movaps [r15+0x240], xmm14
00007fa22efdc6b2  movaps xmm10, xmm1
00007fa22efdc6b6  addpd xmm10, xmm12
00007fa22efdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007fa22efdc6c1  ptest xmm9, xmm9
00007fa22efdc6c7  jnz 0x00007FA22EFE0C88
00007fa22efdc6cd  movaps [r15+0x170], xmm10
00007fa22efdc6d5  vmovaps xmm1, [rsp+0x20]
00007fa22efdc6db  vpermilpd xmm1, xmm1, 0x00
00007fa22efdc6e1  movaps xmm12, xmm14
00007fa22efdc6e5  mulpd xmm12, xmm1
00007fa22efdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007fa22efdc6f0  ptest xmm9, xmm9
00007fa22efdc6f6  jnz 0x00007FA22EFE0DCB
00007fa22efdc6fc  vmovaps xmm1, [rsp+0x20]
00007fa22efdc702  vpermilpd xmm1, xmm1, 0x00
00007fa22efdc708  vmovaps xmm9, [rsp+0xB0]
00007fa22efdc711  movaps xmm14, xmm9
00007fa22efdc715  mulpd xmm14, xmm1
00007fa22efdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007fa22efdc720  ptest xmm6, xmm6
00007fa22efdc725  jnz 0x00007FA22EFE0F0E
00007fa22efdc72b  movaps [r15+0x180], xmm14
00007fa22efdc733  movaps xmm1, xmm13
00007fa22efdc737  addpd xmm1, xmm8
00007fa22efdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007fa22efdc741  ptest xmm9, xmm9
00007fa22efdc747  jnz 0x00007FA22EFE1051
00007fa22efdc74d  movaps [r15+0x210], xmm1
00007fa22efdc755  movups xmm13, [r13+rax*1]
00007fa22efdc75b  lea r12, [rax+0x10]
00007fa22efdc75f  movups xmm9, [r13+r12*1]
00007fa22efdc765  movaps [r15+0x230], xmm9
00007fa22efdc76d  movaps xmm8, xmm15
00007fa22efdc771  addpd xmm8, xmm7
00007fa22efdc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007fa22efdc77c  ptest xmm6, xmm6
00007fa22efdc781  jnz 0x00007FA22EFE11A7
00007fa22efdc787  movaps [r15+0x130], xmm8
00007fa22efdc78f  vmovaps xmm15, [rsp+0x20]
00007fa22efdc795  vpermilpd xmm15, xmm15, 0x00
00007fa22efdc79b  movaps xmm7, xmm9
00007fa22efdc79f  mulpd xmm7, xmm15
00007fa22efdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa22efdc7a9  ptest xmm6, xmm6
00007fa22efdc7ae  jnz 0x00007FA22EFE12EA
00007fa22efdc7b4  movaps [r15+0x220], xmm7
00007fa22efdc7bc  vmovaps xmm15, [rsp+0x20]
00007fa22efdc7c2  vpermilpd xmm15, xmm15, 0x00
00007fa22efdc7c8  movaps xmm9, xmm13
00007fa22efdc7cc  mulpd xmm9, xmm15
00007fa22efdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007fa22efdc7d7  ptest xmm6, xmm6
00007fa22efdc7dc  jnz 0x00007FA22EFE142C
00007fa22efdc7e2  movaps xmm15, xmm11
00007fa22efdc7e6  addpd xmm15, xmm12
00007fa22efdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007fa22efdc7f1  ptest xmm13, xmm13
00007fa22efdc7f7  jnz 0x00007FA22EFE1570
00007fa22efdc7fd  movaps [r15+0x140], xmm15
00007fa22efdc805  movaps xmm13, xmm10
00007fa22efdc809  addpd xmm13, xmm14
00007fa22efdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007fa22efdc814  ptest xmm12, xmm12
00007fa22efdc81a  jnz 0x00007FA22EFE16B4
00007fa22efdc820  movaps [r15+0x150], xmm13
00007fa22efdc828  movaps xmm14, xmm1
00007fa22efdc82c  addpd xmm14, xmm7
00007fa22efdc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007fa22efdc837  ptest xmm12, xmm12
00007fa22efdc83d  jnz 0x00007FA22EFE17F8
00007fa22efdc843  movaps [r15+0x160], xmm14
00007fa22efdc84b  movaps xmm1, xmm8
00007fa22efdc84f  addpd xmm1, xmm9
00007fa22efdc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa22efdc859  ptest xmm12, xmm12
00007fa22efdc85f  jnz 0x00007FA22EFE193A
00007fa22efdc865  movaps [r15+0x120], xmm1
00007fa22efdc86d  movups [r13+r14*1], xmm15
00007fa22efdc873  lea rax, [r14+0x10]
00007fa22efdc877  movups [r13+rax*1], xmm13
00007fa22efdc87d  lea rax, [r14+0x20]
00007fa22efdc881  movups [r13+rax*1], xmm14
00007fa22efdc887  lea rax, [r14+0x30]
00007fa22efdc88b  movups [r13+rax*1], xmm1
00007fa22efdc891  mov eax, [r15+0x108]
00007fa22efdc898  sahf
00007fa22efdc899  jnz 0x00007FA22EFDC8CB
00007fa22efdc89b  cmp dword ptr [r15+0x318], 0x00
00007fa22efdc8a3  jz 0x00007FA22EFDB900
00007fa22efdc8a9  nop [rax+rax*1], ax
00007fa22efdc8b2  nop [rax+rax*1], eax
00007fa22efdc8ba  mov eax, 0x410444
00007fa22efdc8bf  mov [r15+0x100], rax
00007fa22efdc8c6  jmp 0x00007FA22EDFE110
00007fa22efdc8cb  cmp dword ptr [r15+0x318], 0x00
00007fa22efdc8d3  jz 0x00007FA22EFD57E0
00007fa22efdc8d9  nop [rax+rax*1], ax
00007fa22efdc8e2  nop [rax+rax*1], eax
00007fa22efdc8ea  mov eax, 0x410278
00007fa22efdc8ef  mov [r15+0x100], rax
00007fa22efdc8f6  jmp 0x00007FA22EDFE110
00007fa22efdc8fb  int3
00007fa22efdc8fc  call 0x00007FA22EEE27E0
00007fa22efdc901  jmp 0x00007FA22EFDB9DF
00007fa22efdc906  call 0x00007FA22EEE1570
00007fa22efdc90b  jmp 0x00007FA22EFDB9E8
00007fa22efdc910  call 0x00007FA22EEE27E0
00007fa22efdc915  jmp 0x00007FA22EFDBA44
00007fa22efdc91a  call 0x00007FA22EEE1570
00007fa22efdc91f  jmp 0x00007FA22EFDBA4D
00007fa22efdc924  call 0x00007FA22EEE27E0
00007fa22efdc929  jmp 0x00007FA22EFDBA90
00007fa22efdc92e  call 0x00007FA22EEE1570
00007fa22efdc933  jmp 0x00007FA22EFDBA99
00007fa22efdc938  call 0x00007FA22EE0DC20
00007fa22efdc93d  jmp 0x00007FA22EFDBAD8
00007fa22efdc942  call 0x00007FA22EED59C0
00007fa22efdc947  jmp 0x00007FA22EFDBAEB
00007fa22efdc94c  call 0x00007FA22EEE0E30
00007fa22efdc951  jmp 0x00007FA22EFDBB09
00007fa22efdc956  call 0x00007FA22EEDFBC0
00007fa22efdc95b  jmp 0x00007FA22EFDBB13
00007fa22efdc960  call 0x00007FA22EEDE950
00007fa22efdc965  jmp 0x00007FA22EFDBB1D
00007fa22efdc96a  sub rsp, 0x08
00007fa22efdc96e  push rax
00007fa22efdc96f  push rcx
00007fa22efdc970  push rdx
00007fa22efdc971  push rdi
00007fa22efdc972  push rsi
00007fa22efdc973  push r8
00007fa22efdc975  push r9
00007fa22efdc977  push r10
00007fa22efdc979  push r11
00007fa22efdc97b  sub rsp, 0xF0
00007fa22efdc982  vmovaps [rsp], xmm0
00007fa22efdc987  vmovaps [rsp+0x10], xmm1
00007fa22efdc98d  vmovaps [rsp+0x20], xmm2
00007fa22efdc993  vmovaps [rsp+0x30], xmm3
00007fa22efdc999  vmovaps [rsp+0x40], xmm4
00007fa22efdc99f  vmovaps [rsp+0x50], xmm5
00007fa22efdc9a5  vmovaps [rsp+0x60], xmm6
00007fa22efdc9ab  vmovaps [rsp+0x70], xmm7
00007fa22efdc9b1  vmovaps [rsp+0x80], xmm9
00007fa22efdc9ba  vmovaps [rsp+0x90], xmm10
00007fa22efdc9c3  vmovaps [rsp+0xA0], xmm11
00007fa22efdc9cc  vmovaps [rsp+0xB0], xmm12
00007fa22efdc9d5  vmovaps [rsp+0xC0], xmm13
00007fa22efdc9de  vmovaps [rsp+0xD0], xmm14
00007fa22efdc9e7  vmovaps [rsp+0xE0], xmm15
00007fa22efdc9f0  sub rsp, 0x30
00007fa22efdc9f4  movaps [rsp], xmm8
00007fa22efdc9f9  movaps [rsp+0x10], xmm12
00007fa22efdc9ff  movaps [rsp+0x20], xmm15
00007fa22efdca05  lea rdi, [rsp]
00007fa22efdca09  mov esi, 0x00
00007fa22efdca0e  mov rax, 0x5E9D1A57D530
00007fa22efdca18  call rax
00007fa22efdca1a  movaps xmm8, [rsp]
00007fa22efdca1f  add rsp, 0x30
00007fa22efdca23  vmovaps xmm0, [rsp]
00007fa22efdca28  vmovaps xmm1, [rsp+0x10]
00007fa22efdca2e  vmovaps xmm2, [rsp+0x20]
00007fa22efdca34  vmovaps xmm3, [rsp+0x30]
00007fa22efdca3a  vmovaps xmm4, [rsp+0x40]
00007fa22efdca40  vmovaps xmm5, [rsp+0x50]
00007fa22efdca46  vmovaps xmm6, [rsp+0x60]
00007fa22efdca4c  vmovaps xmm7, [rsp+0x70]
00007fa22efdca52  vmovaps xmm9, [rsp+0x80]
00007fa22efdca5b  vmovaps xmm10, [rsp+0x90]
00007fa22efdca64  vmovaps xmm11, [rsp+0xA0]
00007fa22efdca6d  vmovaps xmm12, [rsp+0xB0]
00007fa22efdca76  vmovaps xmm13, [rsp+0xC0]
00007fa22efdca7f  vmovaps xmm14, [rsp+0xD0]
00007fa22efdca88  vmovaps xmm15, [rsp+0xE0]
00007fa22efdca91  add rsp, 0xF0
00007fa22efdca98  pop r11
00007fa22efdca9a  pop r10
00007fa22efdca9c  pop r9
00007fa22efdca9e  pop r8
00007fa22efdcaa0  pop rsi
00007fa22efdcaa1  pop rdi
00007fa22efdcaa2  pop rdx
00007fa22efdcaa3  pop rcx
00007fa22efdcaa4  pop rax
00007fa22efdcaa5  add rsp, 0x08
00007fa22efdcaa9  jmp 0x00007FA22EFDBB47
00007fa22efdcaae  sub rsp, 0x08
00007fa22efdcab2  push rax
00007fa22efdcab3  push rcx
00007fa22efdcab4  push rdx
00007fa22efdcab5  push rdi
00007fa22efdcab6  push rsi
00007fa22efdcab7  push r8
00007fa22efdcab9  push r9
00007fa22efdcabb  push r10
00007fa22efdcabd  push r11
00007fa22efdcabf  sub rsp, 0xF0
00007fa22efdcac6  vmovaps [rsp], xmm0
00007fa22efdcacb  vmovaps [rsp+0x10], xmm1
00007fa22efdcad1  vmovaps [rsp+0x20], xmm2
00007fa22efdcad7  vmovaps [rsp+0x30], xmm3
00007fa22efdcadd  vmovaps [rsp+0x40], xmm4
00007fa22efdcae3  vmovaps [rsp+0x50], xmm5
00007fa22efdcae9  vmovaps [rsp+0x60], xmm6
00007fa22efdcaef  vmovaps [rsp+0x70], xmm8
00007fa22efdcaf5  vmovaps [rsp+0x80], xmm9
00007fa22efdcafe  vmovaps [rsp+0x90], xmm10
00007fa22efdcb07  vmovaps [rsp+0xA0], xmm11
00007fa22efdcb10  vmovaps [rsp+0xB0], xmm12
00007fa22efdcb19  vmovaps [rsp+0xC0], xmm13
00007fa22efdcb22  vmovaps [rsp+0xD0], xmm14
00007fa22efdcb2b  vmovaps [rsp+0xE0], xmm15
00007fa22efdcb34  sub rsp, 0x30
00007fa22efdcb38  movaps [rsp], xmm7
00007fa22efdcb3c  movaps [rsp+0x10], xmm9
00007fa22efdcb42  movaps [rsp+0x20], xmm15
00007fa22efdcb48  lea rdi, [rsp]
00007fa22efdcb4c  mov esi, 0x00
00007fa22efdcb51  mov rax, 0x5E9D1A57D530
00007fa22efdcb5b  call rax
00007fa22efdcb5d  movaps xmm7, [rsp]
00007fa22efdcb61  add rsp, 0x30
00007fa22efdcb65  vmovaps xmm0, [rsp]
00007fa22efdcb6a  vmovaps xmm1, [rsp+0x10]
00007fa22efdcb70  vmovaps xmm2, [rsp+0x20]
00007fa22efdcb76  vmovaps xmm3, [rsp+0x30]
00007fa22efdcb7c  vmovaps xmm4, [rsp+0x40]
00007fa22efdcb82  vmovaps xmm5, [rsp+0x50]
00007fa22efdcb88  vmovaps xmm6, [rsp+0x60]
00007fa22efdcb8e  vmovaps xmm8, [rsp+0x70]
00007fa22efdcb94  vmovaps xmm9, [rsp+0x80]
00007fa22efdcb9d  vmovaps xmm10, [rsp+0x90]
00007fa22efdcba6  vmovaps xmm11, [rsp+0xA0]
00007fa22efdcbaf  vmovaps xmm12, [rsp+0xB0]
00007fa22efdcbb8  vmovaps xmm13, [rsp+0xC0]
00007fa22efdcbc1  vmovaps xmm14, [rsp+0xD0]
00007fa22efdcbca  vmovaps xmm15, [rsp+0xE0]
00007fa22efdcbd3  add rsp, 0xF0
00007fa22efdcbda  pop r11
00007fa22efdcbdc  pop r10
00007fa22efdcbde  pop r9
00007fa22efdcbe0  pop r8
00007fa22efdcbe2  pop rsi
00007fa22efdcbe3  pop rdi
00007fa22efdcbe4  pop rdx
00007fa22efdcbe5  pop rcx
00007fa22efdcbe6  pop rax
00007fa22efdcbe7  add rsp, 0x08
00007fa22efdcbeb  jmp 0x00007FA22EFDBB75
00007fa22efdcbf0  sub rsp, 0x08
00007fa22efdcbf4  push rax
00007fa22efdcbf5  push rcx
00007fa22efdcbf6  push rdx
00007fa22efdcbf7  push rdi
00007fa22efdcbf8  push rsi
00007fa22efdcbf9  push r8
00007fa22efdcbfb  push r9
00007fa22efdcbfd  push r10
00007fa22efdcbff  push r11
00007fa22efdcc01  sub rsp, 0xF0
00007fa22efdcc08  vmovaps [rsp], xmm0
00007fa22efdcc0d  vmovaps [rsp+0x10], xmm1
00007fa22efdcc13  vmovaps [rsp+0x20], xmm2
00007fa22efdcc19  vmovaps [rsp+0x30], xmm3
00007fa22efdcc1f  vmovaps [rsp+0x40], xmm4
00007fa22efdcc25  vmovaps [rsp+0x50], xmm5
00007fa22efdcc2b  vmovaps [rsp+0x60], xmm6
00007fa22efdcc31  vmovaps [rsp+0x70], xmm7
00007fa22efdcc37  vmovaps [rsp+0x80], xmm8
00007fa22efdcc40  vmovaps [rsp+0x90], xmm10
00007fa22efdcc49  vmovaps [rsp+0xA0], xmm11
00007fa22efdcc52  vmovaps [rsp+0xB0], xmm12
00007fa22efdcc5b  vmovaps [rsp+0xC0], xmm13
00007fa22efdcc64  vmovaps [rsp+0xD0], xmm14
00007fa22efdcc6d  vmovaps [rsp+0xE0], xmm15
00007fa22efdcc76  sub rsp, 0x30
00007fa22efdcc7a  movaps [rsp], xmm9
00007fa22efdcc7f  movaps [rsp+0x10], xmm12
00007fa22efdcc85  movaps [rsp+0x20], xmm10
00007fa22efdcc8b  lea rdi, [rsp]
00007fa22efdcc8f  mov esi, 0x00
00007fa22efdcc94  mov rax, 0x5E9D1A57D530
00007fa22efdcc9e  call rax
00007fa22efdcca0  movaps xmm9, [rsp]
00007fa22efdcca5  add rsp, 0x30
00007fa22efdcca9  vmovaps xmm0, [rsp]
00007fa22efdccae  vmovaps xmm1, [rsp+0x10]
00007fa22efdccb4  vmovaps xmm2, [rsp+0x20]
00007fa22efdccba  vmovaps xmm3, [rsp+0x30]
00007fa22efdccc0  vmovaps xmm4, [rsp+0x40]
00007fa22efdccc6  vmovaps xmm5, [rsp+0x50]
00007fa22efdcccc  vmovaps xmm6, [rsp+0x60]
00007fa22efdccd2  vmovaps xmm7, [rsp+0x70]
00007fa22efdccd8  vmovaps xmm8, [rsp+0x80]
00007fa22efdcce1  vmovaps xmm10, [rsp+0x90]
00007fa22efdccea  vmovaps xmm11, [rsp+0xA0]
00007fa22efdccf3  vmovaps xmm12, [rsp+0xB0]
00007fa22efdccfc  vmovaps xmm13, [rsp+0xC0]
00007fa22efdcd05  vmovaps xmm14, [rsp+0xD0]
00007fa22efdcd0e  vmovaps xmm15, [rsp+0xE0]
00007fa22efdcd17  add rsp, 0xF0
00007fa22efdcd1e  pop r11
00007fa22efdcd20  pop r10
00007fa22efdcd22  pop r9
00007fa22efdcd24  pop r8
00007fa22efdcd26  pop rsi
00007fa22efdcd27  pop rdi
00007fa22efdcd28  pop rdx
00007fa22efdcd29  pop rcx
00007fa22efdcd2a  pop rax
00007fa22efdcd2b  add rsp, 0x08
00007fa22efdcd2f  jmp 0x00007FA22EFDBB99
00007fa22efdcd34  sub rsp, 0x08
00007fa22efdcd38  push rax
00007fa22efdcd39  push rcx
00007fa22efdcd3a  push rdx
00007fa22efdcd3b  push rdi
00007fa22efdcd3c  push rsi
00007fa22efdcd3d  push r8
00007fa22efdcd3f  push r9
00007fa22efdcd41  push r10
00007fa22efdcd43  push r11
00007fa22efdcd45  sub rsp, 0xF0
00007fa22efdcd4c  vmovaps [rsp], xmm0
00007fa22efdcd51  vmovaps [rsp+0x10], xmm1
00007fa22efdcd57  vmovaps [rsp+0x20], xmm2
00007fa22efdcd5d  vmovaps [rsp+0x30], xmm3
00007fa22efdcd63  vmovaps [rsp+0x40], xmm4
00007fa22efdcd69  vmovaps [rsp+0x50], xmm5
00007fa22efdcd6f  vmovaps [rsp+0x60], xmm6
00007fa22efdcd75  vmovaps [rsp+0x70], xmm7
00007fa22efdcd7b  vmovaps [rsp+0x80], xmm8
00007fa22efdcd84  vmovaps [rsp+0x90], xmm9
00007fa22efdcd8d  vmovaps [rsp+0xA0], xmm11
00007fa22efdcd96  vmovaps [rsp+0xB0], xmm12
00007fa22efdcd9f  vmovaps [rsp+0xC0], xmm13
00007fa22efdcda8  vmovaps [rsp+0xD0], xmm14
00007fa22efdcdb1  vmovaps [rsp+0xE0], xmm15
00007fa22efdcdba  sub rsp, 0x30
00007fa22efdcdbe  movaps [rsp], xmm10
00007fa22efdcdc3  movaps [rsp+0x10], xmm12
00007fa22efdcdc9  movaps [rsp+0x20], xmm11
00007fa22efdcdcf  lea rdi, [rsp]
00007fa22efdcdd3  mov esi, 0x00
00007fa22efdcdd8  mov rax, 0x5E9D1A57D530
00007fa22efdcde2  call rax
00007fa22efdcde4  movaps xmm10, [rsp]
00007fa22efdcde9  add rsp, 0x30
00007fa22efdcded  vmovaps xmm0, [rsp]
00007fa22efdcdf2  vmovaps xmm1, [rsp+0x10]
00007fa22efdcdf8  vmovaps xmm2, [rsp+0x20]
00007fa22efdcdfe  vmovaps xmm3, [rsp+0x30]
00007fa22efdce04  vmovaps xmm4, [rsp+0x40]
00007fa22efdce0a  vmovaps xmm5, [rsp+0x50]
00007fa22efdce10  vmovaps xmm6, [rsp+0x60]
00007fa22efdce16  vmovaps xmm7, [rsp+0x70]
00007fa22efdce1c  vmovaps xmm8, [rsp+0x80]
00007fa22efdce25  vmovaps xmm9, [rsp+0x90]
00007fa22efdce2e  vmovaps xmm11, [rsp+0xA0]
00007fa22efdce37  vmovaps xmm12, [rsp+0xB0]
00007fa22efdce40  vmovaps xmm13, [rsp+0xC0]
00007fa22efdce49  vmovaps xmm14, [rsp+0xD0]
00007fa22efdce52  vmovaps xmm15, [rsp+0xE0]
00007fa22efdce5b  add rsp, 0xF0
00007fa22efdce62  pop r11
00007fa22efdce64  pop r10
00007fa22efdce66  pop r9
00007fa22efdce68  pop r8
00007fa22efdce6a  pop rsi
00007fa22efdce6b  pop rdi
00007fa22efdce6c  pop rdx
00007fa22efdce6d  pop rcx
00007fa22efdce6e  pop rax
00007fa22efdce6f  add rsp, 0x08
00007fa22efdce73  jmp 0x00007FA22EFDBBB3
00007fa22efdce78  sub rsp, 0x08
00007fa22efdce7c  push rax
00007fa22efdce7d  push rcx
00007fa22efdce7e  push rdx
00007fa22efdce7f  push rdi
00007fa22efdce80  push rsi
00007fa22efdce81  push r8
00007fa22efdce83  push r9
00007fa22efdce85  push r10
00007fa22efdce87  push r11
00007fa22efdce89  sub rsp, 0xF0
00007fa22efdce90  vmovaps [rsp], xmm0
00007fa22efdce95  vmovaps [rsp+0x10], xmm1
00007fa22efdce9b  vmovaps [rsp+0x20], xmm2
00007fa22efdcea1  vmovaps [rsp+0x30], xmm3
00007fa22efdcea7  vmovaps [rsp+0x40], xmm4
00007fa22efdcead  vmovaps [rsp+0x50], xmm5
00007fa22efdceb3  vmovaps [rsp+0x60], xmm7
00007fa22efdceb9  vmovaps [rsp+0x70], xmm8
00007fa22efdcebf  vmovaps [rsp+0x80], xmm9
00007fa22efdcec8  vmovaps [rsp+0x90], xmm10
00007fa22efdced1  vmovaps [rsp+0xA0], xmm11
00007fa22efdceda  vmovaps [rsp+0xB0], xmm12
00007fa22efdcee3  vmovaps [rsp+0xC0], xmm13
00007fa22efdceec  vmovaps [rsp+0xD0], xmm14
00007fa22efdcef5  vmovaps [rsp+0xE0], xmm15
00007fa22efdcefe  sub rsp, 0x30
00007fa22efdcf02  movaps [rsp], xmm6
00007fa22efdcf06  movaps [rsp+0x10], xmm12
00007fa22efdcf0c  movaps [rsp+0x20], xmm11
00007fa22efdcf12  lea rdi, [rsp]
00007fa22efdcf16  mov esi, 0x00
00007fa22efdcf1b  mov rax, 0x5E9D1A57D530
00007fa22efdcf25  call rax
00007fa22efdcf27  movaps xmm6, [rsp]
00007fa22efdcf2b  add rsp, 0x30
00007fa22efdcf2f  vmovaps xmm0, [rsp]
00007fa22efdcf34  vmovaps xmm1, [rsp+0x10]
00007fa22efdcf3a  vmovaps xmm2, [rsp+0x20]
00007fa22efdcf40  vmovaps xmm3, [rsp+0x30]
00007fa22efdcf46  vmovaps xmm4, [rsp+0x40]
00007fa22efdcf4c  vmovaps xmm5, [rsp+0x50]
00007fa22efdcf52  vmovaps xmm7, [rsp+0x60]
00007fa22efdcf58  vmovaps xmm8, [rsp+0x70]
00007fa22efdcf5e  vmovaps xmm9, [rsp+0x80]
00007fa22efdcf67  vmovaps xmm10, [rsp+0x90]
00007fa22efdcf70  vmovaps xmm11, [rsp+0xA0]
00007fa22efdcf79  vmovaps xmm12, [rsp+0xB0]
00007fa22efdcf82  vmovaps xmm13, [rsp+0xC0]
00007fa22efdcf8b  vmovaps xmm14, [rsp+0xD0]
00007fa22efdcf94  vmovaps xmm15, [rsp+0xE0]
00007fa22efdcf9d  add rsp, 0xF0
00007fa22efdcfa4  pop r11
00007fa22efdcfa6  pop r10
00007fa22efdcfa8  pop r9
00007fa22efdcfaa  pop r8
00007fa22efdcfac  pop rsi
00007fa22efdcfad  pop rdi
00007fa22efdcfae  pop rdx
00007fa22efdcfaf  pop rcx
00007fa22efdcfb0  pop rax
00007fa22efdcfb1  add rsp, 0x08
00007fa22efdcfb5  jmp 0x00007FA22EFDBBD4
00007fa22efdcfba  sub rsp, 0x08
00007fa22efdcfbe  push rax
00007fa22efdcfbf  push rcx
00007fa22efdcfc0  push rdx
00007fa22efdcfc1  push rdi
00007fa22efdcfc2  push rsi
00007fa22efdcfc3  push r8
00007fa22efdcfc5  push r9
00007fa22efdcfc7  push r10
00007fa22efdcfc9  push r11
00007fa22efdcfcb  sub rsp, 0xF0
00007fa22efdcfd2  vmovaps [rsp], xmm0
00007fa22efdcfd7  vmovaps [rsp+0x10], xmm1
00007fa22efdcfdd  vmovaps [rsp+0x20], xmm2
00007fa22efdcfe3  vmovaps [rsp+0x30], xmm4
00007fa22efdcfe9  vmovaps [rsp+0x40], xmm5
00007fa22efdcfef  vmovaps [rsp+0x50], xmm6
00007fa22efdcff5  vmovaps [rsp+0x60], xmm7
00007fa22efdcffb  vmovaps [rsp+0x70], xmm8
00007fa22efdd001  vmovaps [rsp+0x80], xmm9
00007fa22efdd00a  vmovaps [rsp+0x90], xmm10
00007fa22efdd013  vmovaps [rsp+0xA0], xmm11
00007fa22efdd01c  vmovaps [rsp+0xB0], xmm12
00007fa22efdd025  vmovaps [rsp+0xC0], xmm13
00007fa22efdd02e  vmovaps [rsp+0xD0], xmm14
00007fa22efdd037  vmovaps [rsp+0xE0], xmm15
00007fa22efdd040  sub rsp, 0x30
00007fa22efdd044  movaps [rsp], xmm3
00007fa22efdd048  movaps [rsp+0x10], xmm5
00007fa22efdd04d  movaps [rsp+0x20], xmm4
00007fa22efdd052  lea rdi, [rsp]
00007fa22efdd056  mov esi, 0x00
00007fa22efdd05b  mov rax, 0x5E9D1A57D530
00007fa22efdd065  call rax
00007fa22efdd067  movaps xmm3, [rsp]
00007fa22efdd06b  add rsp, 0x30
00007fa22efdd06f  vmovaps xmm0, [rsp]
00007fa22efdd074  vmovaps xmm1, [rsp+0x10]
00007fa22efdd07a  vmovaps xmm2, [rsp+0x20]
00007fa22efdd080  vmovaps xmm4, [rsp+0x30]
00007fa22efdd086  vmovaps xmm5, [rsp+0x40]
00007fa22efdd08c  vmovaps xmm6, [rsp+0x50]
00007fa22efdd092  vmovaps xmm7, [rsp+0x60]
00007fa22efdd098  vmovaps xmm8, [rsp+0x70]
00007fa22efdd09e  vmovaps xmm9, [rsp+0x80]
00007fa22efdd0a7  vmovaps xmm10, [rsp+0x90]
00007fa22efdd0b0  vmovaps xmm11, [rsp+0xA0]
00007fa22efdd0b9  vmovaps xmm12, [rsp+0xB0]
00007fa22efdd0c2  vmovaps xmm13, [rsp+0xC0]
00007fa22efdd0cb  vmovaps xmm14, [rsp+0xD0]
00007fa22efdd0d4  vmovaps xmm15, [rsp+0xE0]
00007fa22efdd0dd  add rsp, 0xF0
00007fa22efdd0e4  pop r11
00007fa22efdd0e6  pop r10
00007fa22efdd0e8  pop r9
00007fa22efdd0ea  pop r8
00007fa22efdd0ec  pop rsi
00007fa22efdd0ed  pop rdi
00007fa22efdd0ee  pop rdx
00007fa22efdd0ef  pop rcx
00007fa22efdd0f0  pop rax
00007fa22efdd0f1  add rsp, 0x08
00007fa22efdd0f5  jmp 0x00007FA22EFDBC35
00007fa22efdd0fa  sub rsp, 0x08
00007fa22efdd0fe  push rax
00007fa22efdd0ff  push rcx
00007fa22efdd100  push rdx
00007fa22efdd101  push rdi
00007fa22efdd102  push rsi
00007fa22efdd103  push r8
00007fa22efdd105  push r9
00007fa22efdd107  push r10
00007fa22efdd109  push r11
00007fa22efdd10b  sub rsp, 0xF0
00007fa22efdd112  vmovaps [rsp], xmm0
00007fa22efdd117  vmovaps [rsp+0x10], xmm1
00007fa22efdd11d  vmovaps [rsp+0x20], xmm2
00007fa22efdd123  vmovaps [rsp+0x30], xmm3
00007fa22efdd129  vmovaps [rsp+0x40], xmm4
00007fa22efdd12f  vmovaps [rsp+0x50], xmm6
00007fa22efdd135  vmovaps [rsp+0x60], xmm7
00007fa22efdd13b  vmovaps [rsp+0x70], xmm8
00007fa22efdd141  vmovaps [rsp+0x80], xmm9
00007fa22efdd14a  vmovaps [rsp+0x90], xmm10
00007fa22efdd153  vmovaps [rsp+0xA0], xmm11
00007fa22efdd15c  vmovaps [rsp+0xB0], xmm12
00007fa22efdd165  vmovaps [rsp+0xC0], xmm13
00007fa22efdd16e  vmovaps [rsp+0xD0], xmm14
00007fa22efdd177  vmovaps [rsp+0xE0], xmm15
00007fa22efdd180  sub rsp, 0x30
00007fa22efdd184  movaps [rsp], xmm5
00007fa22efdd188  movaps [rsp+0x10], xmm8
00007fa22efdd18e  movaps [rsp+0x20], xmm15
00007fa22efdd194  lea rdi, [rsp]
00007fa22efdd198  mov esi, 0x00
00007fa22efdd19d  mov rax, 0x5E9D1A57D530
00007fa22efdd1a7  call rax
00007fa22efdd1a9  movaps xmm5, [rsp]
00007fa22efdd1ad  add rsp, 0x30
00007fa22efdd1b1  vmovaps xmm0, [rsp]
00007fa22efdd1b6  vmovaps xmm1, [rsp+0x10]
00007fa22efdd1bc  vmovaps xmm2, [rsp+0x20]
00007fa22efdd1c2  vmovaps xmm3, [rsp+0x30]
00007fa22efdd1c8  vmovaps xmm4, [rsp+0x40]
00007fa22efdd1ce  vmovaps xmm6, [rsp+0x50]
00007fa22efdd1d4  vmovaps xmm7, [rsp+0x60]
00007fa22efdd1da  vmovaps xmm8, [rsp+0x70]
00007fa22efdd1e0  vmovaps xmm9, [rsp+0x80]
00007fa22efdd1e9  vmovaps xmm10, [rsp+0x90]
00007fa22efdd1f2  vmovaps xmm11, [rsp+0xA0]
00007fa22efdd1fb  vmovaps xmm12, [rsp+0xB0]
00007fa22efdd204  vmovaps xmm13, [rsp+0xC0]
00007fa22efdd20d  vmovaps xmm14, [rsp+0xD0]
00007fa22efdd216  vmovaps xmm15, [rsp+0xE0]
00007fa22efdd21f  add rsp, 0xF0
00007fa22efdd226  pop r11
00007fa22efdd228  pop r10
00007fa22efdd22a  pop r9
00007fa22efdd22c  pop r8
00007fa22efdd22e  pop rsi
00007fa22efdd22f  pop rdi
00007fa22efdd230  pop rdx
00007fa22efdd231  pop rcx
00007fa22efdd232  pop rax
00007fa22efdd233  add rsp, 0x08
00007fa22efdd237  jmp 0x00007FA22EFDBC73
00007fa22efdd23c  sub rsp, 0x08
00007fa22efdd240  push rax
00007fa22efdd241  push rcx
00007fa22efdd242  push rdx
00007fa22efdd243  push rdi
00007fa22efdd244  push rsi
00007fa22efdd245  push r8
00007fa22efdd247  push r9
00007fa22efdd249  push r10
00007fa22efdd24b  push r11
00007fa22efdd24d  sub rsp, 0xF0
00007fa22efdd254  vmovaps [rsp], xmm0
00007fa22efdd259  vmovaps [rsp+0x10], xmm1
00007fa22efdd25f  vmovaps [rsp+0x20], xmm2
00007fa22efdd265  vmovaps [rsp+0x30], xmm3
00007fa22efdd26b  vmovaps [rsp+0x40], xmm5
00007fa22efdd271  vmovaps [rsp+0x50], xmm6
00007fa22efdd277  vmovaps [rsp+0x60], xmm7
00007fa22efdd27d  vmovaps [rsp+0x70], xmm8
00007fa22efdd283  vmovaps [rsp+0x80], xmm9
00007fa22efdd28c  vmovaps [rsp+0x90], xmm10
00007fa22efdd295  vmovaps [rsp+0xA0], xmm11
00007fa22efdd29e  vmovaps [rsp+0xB0], xmm12
00007fa22efdd2a7  vmovaps [rsp+0xC0], xmm13
00007fa22efdd2b0  vmovaps [rsp+0xD0], xmm14
00007fa22efdd2b9  vmovaps [rsp+0xE0], xmm15
00007fa22efdd2c2  sub rsp, 0x30
00007fa22efdd2c6  movaps [rsp], xmm4
00007fa22efdd2ca  movaps [rsp+0x10], xmm9
00007fa22efdd2d0  movaps [rsp+0x20], xmm8
00007fa22efdd2d6  lea rdi, [rsp]
00007fa22efdd2da  mov esi, 0x00
00007fa22efdd2df  mov rax, 0x5E9D1A57D530
00007fa22efdd2e9  call rax
00007fa22efdd2eb  movaps xmm4, [rsp]
00007fa22efdd2ef  add rsp, 0x30
00007fa22efdd2f3  vmovaps xmm0, [rsp]
00007fa22efdd2f8  vmovaps xmm1, [rsp+0x10]
00007fa22efdd2fe  vmovaps xmm2, [rsp+0x20]
00007fa22efdd304  vmovaps xmm3, [rsp+0x30]
00007fa22efdd30a  vmovaps xmm5, [rsp+0x40]
00007fa22efdd310  vmovaps xmm6, [rsp+0x50]
00007fa22efdd316  vmovaps xmm7, [rsp+0x60]
00007fa22efdd31c  vmovaps xmm8, [rsp+0x70]
00007fa22efdd322  vmovaps xmm9, [rsp+0x80]
00007fa22efdd32b  vmovaps xmm10, [rsp+0x90]
00007fa22efdd334  vmovaps xmm11, [rsp+0xA0]
00007fa22efdd33d  vmovaps xmm12, [rsp+0xB0]
00007fa22efdd346  vmovaps xmm13, [rsp+0xC0]
00007fa22efdd34f  vmovaps xmm14, [rsp+0xD0]
00007fa22efdd358  vmovaps xmm15, [rsp+0xE0]
00007fa22efdd361  add rsp, 0xF0
00007fa22efdd368  pop r11
00007fa22efdd36a  pop r10
00007fa22efdd36c  pop r9
00007fa22efdd36e  pop r8
00007fa22efdd370  pop rsi
00007fa22efdd371  pop rdi
00007fa22efdd372  pop rdx
00007fa22efdd373  pop rcx
00007fa22efdd374  pop rax
00007fa22efdd375  add rsp, 0x08
00007fa22efdd379  jmp 0x00007FA22EFDBC94
00007fa22efdd37e  sub rsp, 0x08
00007fa22efdd382  push rax
00007fa22efdd383  push rcx
00007fa22efdd384  push rdx
00007fa22efdd385  push rdi
00007fa22efdd386  push rsi
00007fa22efdd387  push r8
00007fa22efdd389  push r9
00007fa22efdd38b  push r10
00007fa22efdd38d  push r11
00007fa22efdd38f  sub rsp, 0xF0
00007fa22efdd396  vmovaps [rsp], xmm0
00007fa22efdd39b  vmovaps [rsp+0x10], xmm1
00007fa22efdd3a1  vmovaps [rsp+0x20], xmm2
00007fa22efdd3a7  vmovaps [rsp+0x30], xmm3
00007fa22efdd3ad  vmovaps [rsp+0x40], xmm4
00007fa22efdd3b3  vmovaps [rsp+0x50], xmm5
00007fa22efdd3b9  vmovaps [rsp+0x60], xmm6
00007fa22efdd3bf  vmovaps [rsp+0x70], xmm7
00007fa22efdd3c5  vmovaps [rsp+0x80], xmm8
00007fa22efdd3ce  vmovaps [rsp+0x90], xmm10
00007fa22efdd3d7  vmovaps [rsp+0xA0], xmm11
00007fa22efdd3e0  vmovaps [rsp+0xB0], xmm12
00007fa22efdd3e9  vmovaps [rsp+0xC0], xmm13
00007fa22efdd3f2  vmovaps [rsp+0xD0], xmm14
00007fa22efdd3fb  vmovaps [rsp+0xE0], xmm15
00007fa22efdd404  sub rsp, 0x30
00007fa22efdd408  movaps [rsp], xmm9
00007fa22efdd40d  movaps [rsp+0x10], xmm10
00007fa22efdd413  movaps [rsp+0x20], xmm8
00007fa22efdd419  lea rdi, [rsp]
00007fa22efdd41d  mov esi, 0x00
00007fa22efdd422  mov rax, 0x5E9D1A57D530
00007fa22efdd42c  call rax
00007fa22efdd42e  movaps xmm9, [rsp]
00007fa22efdd433  add rsp, 0x30
00007fa22efdd437  vmovaps xmm0, [rsp]
00007fa22efdd43c  vmovaps xmm1, [rsp+0x10]
00007fa22efdd442  vmovaps xmm2, [rsp+0x20]
00007fa22efdd448  vmovaps xmm3, [rsp+0x30]
00007fa22efdd44e  vmovaps xmm4, [rsp+0x40]
00007fa22efdd454  vmovaps xmm5, [rsp+0x50]
00007fa22efdd45a  vmovaps xmm6, [rsp+0x60]
00007fa22efdd460  vmovaps xmm7, [rsp+0x70]
00007fa22efdd466  vmovaps xmm8, [rsp+0x80]
00007fa22efdd46f  vmovaps xmm10, [rsp+0x90]
00007fa22efdd478  vmovaps xmm11, [rsp+0xA0]
00007fa22efdd481  vmovaps xmm12, [rsp+0xB0]
00007fa22efdd48a  vmovaps xmm13, [rsp+0xC0]
00007fa22efdd493  vmovaps xmm14, [rsp+0xD0]
00007fa22efdd49c  vmovaps xmm15, [rsp+0xE0]
00007fa22efdd4a5  add rsp, 0xF0
00007fa22efdd4ac  pop r11
00007fa22efdd4ae  pop r10
00007fa22efdd4b0  pop r9
00007fa22efdd4b2  pop r8
00007fa22efdd4b4  pop rsi
00007fa22efdd4b5  pop rdi
00007fa22efdd4b6  pop rdx
00007fa22efdd4b7  pop rcx
00007fa22efdd4b8  pop rax
00007fa22efdd4b9  add rsp, 0x08
00007fa22efdd4bd  jmp 0x00007FA22EFDBCAE
00007fa22efdd4c2  call 0x00007FA22EEB52F0
00007fa22efdd4c7  jmp 0x00007FA22EFDBDC8
00007fa22efdd4cc  call 0x00007FA22EEB52F0
00007fa22efdd4d1  jmp 0x00007FA22EFDBDDE
00007fa22efdd4d6  sub rsp, 0x08
00007fa22efdd4da  push rax
00007fa22efdd4db  push rcx
00007fa22efdd4dc  push rdx
00007fa22efdd4dd  push rdi
00007fa22efdd4de  push rsi
00007fa22efdd4df  push r8
00007fa22efdd4e1  push r9
00007fa22efdd4e3  push r10
00007fa22efdd4e5  push r11
00007fa22efdd4e7  sub rsp, 0xF0
00007fa22efdd4ee  vmovaps [rsp], xmm0
00007fa22efdd4f3  vmovaps [rsp+0x10], xmm2
00007fa22efdd4f9  vmovaps [rsp+0x20], xmm3
00007fa22efdd4ff  vmovaps [rsp+0x30], xmm4
00007fa22efdd505  vmovaps [rsp+0x40], xmm5
00007fa22efdd50b  vmovaps [rsp+0x50], xmm6
00007fa22efdd511  vmovaps [rsp+0x60], xmm7
00007fa22efdd517  vmovaps [rsp+0x70], xmm8
00007fa22efdd51d  vmovaps [rsp+0x80], xmm9
00007fa22efdd526  vmovaps [rsp+0x90], xmm10
00007fa22efdd52f  vmovaps [rsp+0xA0], xmm11
00007fa22efdd538  vmovaps [rsp+0xB0], xmm12
00007fa22efdd541  vmovaps [rsp+0xC0], xmm13
00007fa22efdd54a  vmovaps [rsp+0xD0], xmm14
00007fa22efdd553  vmovaps [rsp+0xE0], xmm15
00007fa22efdd55c  sub rsp, 0x30
00007fa22efdd560  movaps [rsp], xmm1
00007fa22efdd564  movaps [rsp+0x10], xmm6
00007fa22efdd569  movaps [rsp+0x20], xmm15
00007fa22efdd56f  lea rdi, [rsp]
00007fa22efdd573  mov esi, 0x00
00007fa22efdd578  mov rax, 0x5E9D1A57D530
00007fa22efdd582  call rax
00007fa22efdd584  movaps xmm1, [rsp]
00007fa22efdd588  add rsp, 0x30
00007fa22efdd58c  vmovaps xmm0, [rsp]
00007fa22efdd591  vmovaps xmm2, [rsp+0x10]
00007fa22efdd597  vmovaps xmm3, [rsp+0x20]
00007fa22efdd59d  vmovaps xmm4, [rsp+0x30]
00007fa22efdd5a3  vmovaps xmm5, [rsp+0x40]
00007fa22efdd5a9  vmovaps xmm6, [rsp+0x50]
00007fa22efdd5af  vmovaps xmm7, [rsp+0x60]
00007fa22efdd5b5  vmovaps xmm8, [rsp+0x70]
00007fa22efdd5bb  vmovaps xmm9, [rsp+0x80]
00007fa22efdd5c4  vmovaps xmm10, [rsp+0x90]
00007fa22efdd5cd  vmovaps xmm11, [rsp+0xA0]
00007fa22efdd5d6  vmovaps xmm12, [rsp+0xB0]
00007fa22efdd5df  vmovaps xmm13, [rsp+0xC0]
00007fa22efdd5e8  vmovaps xmm14, [rsp+0xD0]
00007fa22efdd5f1  vmovaps xmm15, [rsp+0xE0]
00007fa22efdd5fa  add rsp, 0xF0
00007fa22efdd601  pop r11
00007fa22efdd603  pop r10
00007fa22efdd605  pop r9
00007fa22efdd607  pop r8
00007fa22efdd609  pop rsi
00007fa22efdd60a  pop rdi
00007fa22efdd60b  pop rdx
00007fa22efdd60c  pop rcx
00007fa22efdd60d  pop rax
00007fa22efdd60e  add rsp, 0x08
00007fa22efdd612  jmp 0x00007FA22EFDBE1B
00007fa22efdd617  call 0x00007FA22EEC4620
00007fa22efdd61c  jmp 0x00007FA22EFDBE28
00007fa22efdd621  sub rsp, 0x08
00007fa22efdd625  push rax
00007fa22efdd626  push rcx
00007fa22efdd627  push rdx
00007fa22efdd628  push rdi
00007fa22efdd629  push rsi
00007fa22efdd62a  push r8
00007fa22efdd62c  push r9
00007fa22efdd62e  push r10
00007fa22efdd630  push r11
00007fa22efdd632  sub rsp, 0xF0
00007fa22efdd639  vmovaps [rsp], xmm0
00007fa22efdd63e  vmovaps [rsp+0x10], xmm1
00007fa22efdd644  vmovaps [rsp+0x20], xmm2
00007fa22efdd64a  vmovaps [rsp+0x30], xmm3
00007fa22efdd650  vmovaps [rsp+0x40], xmm4
00007fa22efdd656  vmovaps [rsp+0x50], xmm5
00007fa22efdd65c  vmovaps [rsp+0x60], xmm6
00007fa22efdd662  vmovaps [rsp+0x70], xmm7
00007fa22efdd668  vmovaps [rsp+0x80], xmm8
00007fa22efdd671  vmovaps [rsp+0x90], xmm9
00007fa22efdd67a  vmovaps [rsp+0xA0], xmm10
00007fa22efdd683  vmovaps [rsp+0xB0], xmm11
00007fa22efdd68c  vmovaps [rsp+0xC0], xmm12
00007fa22efdd695  vmovaps [rsp+0xD0], xmm13
00007fa22efdd69e  vmovaps [rsp+0xE0], xmm15
00007fa22efdd6a7  sub rsp, 0x30
00007fa22efdd6ab  movaps [rsp], xmm14
00007fa22efdd6b0  movaps [rsp+0x10], xmm4
00007fa22efdd6b5  movaps [rsp+0x20], xmm3
00007fa22efdd6ba  lea rdi, [rsp]
00007fa22efdd6be  mov esi, 0x00
00007fa22efdd6c3  mov rax, 0x5E9D1A57D530
00007fa22efdd6cd  call rax
00007fa22efdd6cf  movaps xmm14, [rsp]
00007fa22efdd6d4  add rsp, 0x30
00007fa22efdd6d8  vmovaps xmm0, [rsp]
00007fa22efdd6dd  vmovaps xmm1, [rsp+0x10]
00007fa22efdd6e3  vmovaps xmm2, [rsp+0x20]
00007fa22efdd6e9  vmovaps xmm3, [rsp+0x30]
00007fa22efdd6ef  vmovaps xmm4, [rsp+0x40]
00007fa22efdd6f5  vmovaps xmm5, [rsp+0x50]
00007fa22efdd6fb  vmovaps xmm6, [rsp+0x60]
00007fa22efdd701  vmovaps xmm7, [rsp+0x70]
00007fa22efdd707  vmovaps xmm8, [rsp+0x80]
00007fa22efdd710  vmovaps xmm9, [rsp+0x90]
00007fa22efdd719  vmovaps xmm10, [rsp+0xA0]
00007fa22efdd722  vmovaps xmm11, [rsp+0xB0]
00007fa22efdd72b  vmovaps xmm12, [rsp+0xC0]
00007fa22efdd734  vmovaps xmm13, [rsp+0xD0]
00007fa22efdd73d  vmovaps xmm15, [rsp+0xE0]
00007fa22efdd746  add rsp, 0xF0
00007fa22efdd74d  pop r11
00007fa22efdd74f  pop r10
00007fa22efdd751  pop r9
00007fa22efdd753  pop r8
00007fa22efdd755  pop rsi
00007fa22efdd756  pop rdi
00007fa22efdd757  pop rdx
00007fa22efdd758  pop rcx
00007fa22efdd759  pop rax
00007fa22efdd75a  add rsp, 0x08
00007fa22efdd75e  jmp 0x00007FA22EFDBE42
00007fa22efdd763  sub rsp, 0x08
00007fa22efdd767  push rax
00007fa22efdd768  push rcx
00007fa22efdd769  push rdx
00007fa22efdd76a  push rdi
00007fa22efdd76b  push rsi
00007fa22efdd76c  push r8
00007fa22efdd76e  push r9
00007fa22efdd770  push r10
00007fa22efdd772  push r11
00007fa22efdd774  sub rsp, 0xF0
00007fa22efdd77b  vmovaps [rsp], xmm0
00007fa22efdd780  vmovaps [rsp+0x10], xmm1
00007fa22efdd786  vmovaps [rsp+0x20], xmm2
00007fa22efdd78c  vmovaps [rsp+0x30], xmm3
00007fa22efdd792  vmovaps [rsp+0x40], xmm4
00007fa22efdd798  vmovaps [rsp+0x50], xmm5
00007fa22efdd79e  vmovaps [rsp+0x60], xmm7
00007fa22efdd7a4  vmovaps [rsp+0x70], xmm8
00007fa22efdd7aa  vmovaps [rsp+0x80], xmm9
00007fa22efdd7b3  vmovaps [rsp+0x90], xmm10
00007fa22efdd7bc  vmovaps [rsp+0xA0], xmm11
00007fa22efdd7c5  vmovaps [rsp+0xB0], xmm12
00007fa22efdd7ce  vmovaps [rsp+0xC0], xmm13
00007fa22efdd7d7  vmovaps [rsp+0xD0], xmm14
00007fa22efdd7e0  vmovaps [rsp+0xE0], xmm15
00007fa22efdd7e9  sub rsp, 0x30
00007fa22efdd7ed  movaps [rsp], xmm6
00007fa22efdd7f1  movaps [rsp+0x10], xmm9
00007fa22efdd7f7  movaps [rsp+0x20], xmm7
00007fa22efdd7fc  lea rdi, [rsp]
00007fa22efdd800  mov esi, 0x00
00007fa22efdd805  mov rax, 0x5E9D1A57D530
00007fa22efdd80f  call rax
00007fa22efdd811  movaps xmm6, [rsp]
00007fa22efdd815  add rsp, 0x30
00007fa22efdd819  vmovaps xmm0, [rsp]
00007fa22efdd81e  vmovaps xmm1, [rsp+0x10]
00007fa22efdd824  vmovaps xmm2, [rsp+0x20]
00007fa22efdd82a  vmovaps xmm3, [rsp+0x30]
00007fa22efdd830  vmovaps xmm4, [rsp+0x40]
00007fa22efdd836  vmovaps xmm5, [rsp+0x50]
00007fa22efdd83c  vmovaps xmm7, [rsp+0x60]
00007fa22efdd842  vmovaps xmm8, [rsp+0x70]
00007fa22efdd848  vmovaps xmm9, [rsp+0x80]
00007fa22efdd851  vmovaps xmm10, [rsp+0x90]
00007fa22efdd85a  vmovaps xmm11, [rsp+0xA0]
00007fa22efdd863  vmovaps xmm12, [rsp+0xB0]
00007fa22efdd86c  vmovaps xmm13, [rsp+0xC0]
00007fa22efdd875  vmovaps xmm14, [rsp+0xD0]
00007fa22efdd87e  vmovaps xmm15, [rsp+0xE0]
00007fa22efdd887  add rsp, 0xF0
00007fa22efdd88e  pop r11
00007fa22efdd890  pop r10
00007fa22efdd892  pop r9
00007fa22efdd894  pop r8
00007fa22efdd896  pop rsi
00007fa22efdd897  pop rdi
00007fa22efdd898  pop rdx
00007fa22efdd899  pop rcx
00007fa22efdd89a  pop rax
00007fa22efdd89b  add rsp, 0x08
00007fa22efdd89f  jmp 0x00007FA22EFDBE5A
00007fa22efdd8a4  sub rsp, 0x08
00007fa22efdd8a8  push rax
00007fa22efdd8a9  push rcx
00007fa22efdd8aa  push rdx
00007fa22efdd8ab  push rdi
00007fa22efdd8ac  push rsi
00007fa22efdd8ad  push r8
00007fa22efdd8af  push r9
00007fa22efdd8b1  push r10
00007fa22efdd8b3  push r11
00007fa22efdd8b5  sub rsp, 0xF0
00007fa22efdd8bc  vmovaps [rsp], xmm0
00007fa22efdd8c1  vmovaps [rsp+0x10], xmm1
00007fa22efdd8c7  vmovaps [rsp+0x20], xmm2
00007fa22efdd8cd  vmovaps [rsp+0x30], xmm3
00007fa22efdd8d3  vmovaps [rsp+0x40], xmm4
00007fa22efdd8d9  vmovaps [rsp+0x50], xmm5
00007fa22efdd8df  vmovaps [rsp+0x60], xmm6
00007fa22efdd8e5  vmovaps [rsp+0x70], xmm8
00007fa22efdd8eb  vmovaps [rsp+0x80], xmm9
00007fa22efdd8f4  vmovaps [rsp+0x90], xmm10
00007fa22efdd8fd  vmovaps [rsp+0xA0], xmm11
00007fa22efdd906  vmovaps [rsp+0xB0], xmm12
00007fa22efdd90f  vmovaps [rsp+0xC0], xmm13
00007fa22efdd918  vmovaps [rsp+0xD0], xmm14
00007fa22efdd921  vmovaps [rsp+0xE0], xmm15
00007fa22efdd92a  sub rsp, 0x30
00007fa22efdd92e  movaps [rsp], xmm7
00007fa22efdd932  movaps [rsp+0x10], xmm4
00007fa22efdd937  movaps [rsp+0x20], xmm9
00007fa22efdd93d  lea rdi, [rsp]
00007fa22efdd941  mov esi, 0x00
00007fa22efdd946  mov rax, 0x5E9D1A57D530
00007fa22efdd950  call rax
00007fa22efdd952  movaps xmm7, [rsp]
00007fa22efdd956  add rsp, 0x30
00007fa22efdd95a  vmovaps xmm0, [rsp]
00007fa22efdd95f  vmovaps xmm1, [rsp+0x10]
00007fa22efdd965  vmovaps xmm2, [rsp+0x20]
00007fa22efdd96b  vmovaps xmm3, [rsp+0x30]
00007fa22efdd971  vmovaps xmm4, [rsp+0x40]
00007fa22efdd977  vmovaps xmm5, [rsp+0x50]
00007fa22efdd97d  vmovaps xmm6, [rsp+0x60]
00007fa22efdd983  vmovaps xmm8, [rsp+0x70]
00007fa22efdd989  vmovaps xmm9, [rsp+0x80]
00007fa22efdd992  vmovaps xmm10, [rsp+0x90]
00007fa22efdd99b  vmovaps xmm11, [rsp+0xA0]
00007fa22efdd9a4  vmovaps xmm12, [rsp+0xB0]
00007fa22efdd9ad  vmovaps xmm13, [rsp+0xC0]
00007fa22efdd9b6  vmovaps xmm14, [rsp+0xD0]
00007fa22efdd9bf  vmovaps xmm15, [rsp+0xE0]
00007fa22efdd9c8  add rsp, 0xF0
00007fa22efdd9cf  pop r11
00007fa22efdd9d1  pop r10
00007fa22efdd9d3  pop r9
00007fa22efdd9d5  pop r8
00007fa22efdd9d7  pop rsi
00007fa22efdd9d8  pop rdi
00007fa22efdd9d9  pop rdx
00007fa22efdd9da  pop rcx
00007fa22efdd9db  pop rax
00007fa22efdd9dc  add rsp, 0x08
00007fa22efdd9e0  jmp 0x00007FA22EFDBE87
00007fa22efdd9e5  sub rsp, 0x08
00007fa22efdd9e9  push rax
00007fa22efdd9ea  push rcx
00007fa22efdd9eb  push rdx
00007fa22efdd9ec  push rdi
00007fa22efdd9ed  push rsi
00007fa22efdd9ee  push r8
00007fa22efdd9f0  push r9
00007fa22efdd9f2  push r10
00007fa22efdd9f4  push r11
00007fa22efdd9f6  sub rsp, 0xF0
00007fa22efdd9fd  vmovaps [rsp], xmm0
00007fa22efdda02  vmovaps [rsp+0x10], xmm1
00007fa22efdda08  vmovaps [rsp+0x20], xmm2
00007fa22efdda0e  vmovaps [rsp+0x30], xmm3
00007fa22efdda14  vmovaps [rsp+0x40], xmm5
00007fa22efdda1a  vmovaps [rsp+0x50], xmm6
00007fa22efdda20  vmovaps [rsp+0x60], xmm7
00007fa22efdda26  vmovaps [rsp+0x70], xmm8
00007fa22efdda2c  vmovaps [rsp+0x80], xmm9
00007fa22efdda35  vmovaps [rsp+0x90], xmm10
00007fa22efdda3e  vmovaps [rsp+0xA0], xmm11
00007fa22efdda47  vmovaps [rsp+0xB0], xmm12
00007fa22efdda50  vmovaps [rsp+0xC0], xmm13
00007fa22efdda59  vmovaps [rsp+0xD0], xmm14
00007fa22efdda62  vmovaps [rsp+0xE0], xmm15
00007fa22efdda6b  sub rsp, 0x30
00007fa22efdda6f  movaps [rsp], xmm4
00007fa22efdda73  movaps [rsp+0x10], xmm15
00007fa22efdda79  movaps [rsp+0x20], xmm9
00007fa22efdda7f  lea rdi, [rsp]
00007fa22efdda83  mov esi, 0x00
00007fa22efdda88  mov rax, 0x5E9D1A57D530
00007fa22efdda92  call rax
00007fa22efdda94  movaps xmm4, [rsp]
00007fa22efdda98  add rsp, 0x30
00007fa22efdda9c  vmovaps xmm0, [rsp]
00007fa22efddaa1  vmovaps xmm1, [rsp+0x10]
00007fa22efddaa7  vmovaps xmm2, [rsp+0x20]
00007fa22efddaad  vmovaps xmm3, [rsp+0x30]
00007fa22efddab3  vmovaps xmm5, [rsp+0x40]
00007fa22efddab9  vmovaps xmm6, [rsp+0x50]
00007fa22efddabf  vmovaps xmm7, [rsp+0x60]
00007fa22efddac5  vmovaps xmm8, [rsp+0x70]
00007fa22efddacb  vmovaps xmm9, [rsp+0x80]
00007fa22efddad4  vmovaps xmm10, [rsp+0x90]
00007fa22efddadd  vmovaps xmm11, [rsp+0xA0]
00007fa22efddae6  vmovaps xmm12, [rsp+0xB0]
00007fa22efddaef  vmovaps xmm13, [rsp+0xC0]
00007fa22efddaf8  vmovaps xmm14, [rsp+0xD0]
00007fa22efddb01  vmovaps xmm15, [rsp+0xE0]
00007fa22efddb0a  add rsp, 0xF0
00007fa22efddb11  pop r11
00007fa22efddb13  pop r10
00007fa22efddb15  pop r9
00007fa22efddb17  pop r8
00007fa22efddb19  pop rsi
00007fa22efddb1a  pop rdi
00007fa22efddb1b  pop rdx
00007fa22efddb1c  pop rcx
00007fa22efddb1d  pop rax
00007fa22efddb1e  add rsp, 0x08
00007fa22efddb22  jmp 0x00007FA22EFDBEAC
00007fa22efddb27  call 0x00007FA22EEC4620
00007fa22efddb2c  jmp 0x00007FA22EFDBEB9
00007fa22efddb31  sub rsp, 0x08
00007fa22efddb35  push rax
00007fa22efddb36  push rcx
00007fa22efddb37  push rdx
00007fa22efddb38  push rdi
00007fa22efddb39  push rsi
00007fa22efddb3a  push r8
00007fa22efddb3c  push r9
00007fa22efddb3e  push r10
00007fa22efddb40  push r11
00007fa22efddb42  sub rsp, 0xF0
00007fa22efddb49  vmovaps [rsp], xmm0
00007fa22efddb4e  vmovaps [rsp+0x10], xmm1
00007fa22efddb54  vmovaps [rsp+0x20], xmm2
00007fa22efddb5a  vmovaps [rsp+0x30], xmm4
00007fa22efddb60  vmovaps [rsp+0x40], xmm5
00007fa22efddb66  vmovaps [rsp+0x50], xmm6
00007fa22efddb6c  vmovaps [rsp+0x60], xmm7
00007fa22efddb72  vmovaps [rsp+0x70], xmm8
00007fa22efddb78  vmovaps [rsp+0x80], xmm9
00007fa22efddb81  vmovaps [rsp+0x90], xmm10
00007fa22efddb8a  vmovaps [rsp+0xA0], xmm11
00007fa22efddb93  vmovaps [rsp+0xB0], xmm12
00007fa22efddb9c  vmovaps [rsp+0xC0], xmm13
00007fa22efddba5  vmovaps [rsp+0xD0], xmm14
00007fa22efddbae  vmovaps [rsp+0xE0], xmm15
00007fa22efddbb7  sub rsp, 0x30
00007fa22efddbbb  movaps [rsp], xmm3
00007fa22efddbbf  movaps [rsp+0x10], xmm1
00007fa22efddbc4  movaps [rsp+0x20], xmm9
00007fa22efddbca  lea rdi, [rsp]
00007fa22efddbce  mov esi, 0x00
00007fa22efddbd3  mov rax, 0x5E9D1A57D530
00007fa22efddbdd  call rax
00007fa22efddbdf  movaps xmm3, [rsp]
00007fa22efddbe3  add rsp, 0x30
00007fa22efddbe7  vmovaps xmm0, [rsp]
00007fa22efddbec  vmovaps xmm1, [rsp+0x10]
00007fa22efddbf2  vmovaps xmm2, [rsp+0x20]
00007fa22efddbf8  vmovaps xmm4, [rsp+0x30]
00007fa22efddbfe  vmovaps xmm5, [rsp+0x40]
00007fa22efddc04  vmovaps xmm6, [rsp+0x50]
00007fa22efddc0a  vmovaps xmm7, [rsp+0x60]
00007fa22efddc10  vmovaps xmm8, [rsp+0x70]
00007fa22efddc16  vmovaps xmm9, [rsp+0x80]
00007fa22efddc1f  vmovaps xmm10, [rsp+0x90]
00007fa22efddc28  vmovaps xmm11, [rsp+0xA0]
00007fa22efddc31  vmovaps xmm12, [rsp+0xB0]
00007fa22efddc3a  vmovaps xmm13, [rsp+0xC0]
00007fa22efddc43  vmovaps xmm14, [rsp+0xD0]
00007fa22efddc4c  vmovaps xmm15, [rsp+0xE0]
00007fa22efddc55  add rsp, 0xF0
00007fa22efddc5c  pop r11
00007fa22efddc5e  pop r10
00007fa22efddc60  pop r9
00007fa22efddc62  pop r8
00007fa22efddc64  pop rsi
00007fa22efddc65  pop rdi
00007fa22efddc66  pop rdx
00007fa22efddc67  pop rcx
00007fa22efddc68  pop rax
00007fa22efddc69  add rsp, 0x08
00007fa22efddc6d  jmp 0x00007FA22EFDBEF6
00007fa22efddc72  sub rsp, 0x08
00007fa22efddc76  push rax
00007fa22efddc77  push rcx
00007fa22efddc78  push rdx
00007fa22efddc79  push rdi
00007fa22efddc7a  push rsi
00007fa22efddc7b  push r8
00007fa22efddc7d  push r9
00007fa22efddc7f  push r10
00007fa22efddc81  push r11
00007fa22efddc83  sub rsp, 0xF0
00007fa22efddc8a  vmovaps [rsp], xmm0
00007fa22efddc8f  vmovaps [rsp+0x10], xmm2
00007fa22efddc95  vmovaps [rsp+0x20], xmm3
00007fa22efddc9b  vmovaps [rsp+0x30], xmm4
00007fa22efddca1  vmovaps [rsp+0x40], xmm5
00007fa22efddca7  vmovaps [rsp+0x50], xmm6
00007fa22efddcad  vmovaps [rsp+0x60], xmm7
00007fa22efddcb3  vmovaps [rsp+0x70], xmm8
00007fa22efddcb9  vmovaps [rsp+0x80], xmm9
00007fa22efddcc2  vmovaps [rsp+0x90], xmm10
00007fa22efddccb  vmovaps [rsp+0xA0], xmm11
00007fa22efddcd4  vmovaps [rsp+0xB0], xmm12
00007fa22efddcdd  vmovaps [rsp+0xC0], xmm13
00007fa22efddce6  vmovaps [rsp+0xD0], xmm14
00007fa22efddcef  vmovaps [rsp+0xE0], xmm15
00007fa22efddcf8  sub rsp, 0x30
00007fa22efddcfc  movaps [rsp], xmm1
00007fa22efddd00  movaps [rsp+0x10], xmm15
00007fa22efddd06  movaps [rsp+0x20], xmm9
00007fa22efddd0c  lea rdi, [rsp]
00007fa22efddd10  mov esi, 0x00
00007fa22efddd15  mov rax, 0x5E9D1A57D530
00007fa22efddd1f  call rax
00007fa22efddd21  movaps xmm1, [rsp]
00007fa22efddd25  add rsp, 0x30
00007fa22efddd29  vmovaps xmm0, [rsp]
00007fa22efddd2e  vmovaps xmm2, [rsp+0x10]
00007fa22efddd34  vmovaps xmm3, [rsp+0x20]
00007fa22efddd3a  vmovaps xmm4, [rsp+0x30]
00007fa22efddd40  vmovaps xmm5, [rsp+0x40]
00007fa22efddd46  vmovaps xmm6, [rsp+0x50]
00007fa22efddd4c  vmovaps xmm7, [rsp+0x60]
00007fa22efddd52  vmovaps xmm8, [rsp+0x70]
00007fa22efddd58  vmovaps xmm9, [rsp+0x80]
00007fa22efddd61  vmovaps xmm10, [rsp+0x90]
00007fa22efddd6a  vmovaps xmm11, [rsp+0xA0]
00007fa22efddd73  vmovaps xmm12, [rsp+0xB0]
00007fa22efddd7c  vmovaps xmm13, [rsp+0xC0]
00007fa22efddd85  vmovaps xmm14, [rsp+0xD0]
00007fa22efddd8e  vmovaps xmm15, [rsp+0xE0]
00007fa22efddd97  add rsp, 0xF0
00007fa22efddd9e  pop r11
00007fa22efddda0  pop r10
00007fa22efddda2  pop r9
00007fa22efddda4  pop r8
00007fa22efddda6  pop rsi
00007fa22efddda7  pop rdi
00007fa22efddda8  pop rdx
00007fa22efddda9  pop rcx
00007fa22efdddaa  pop rax
00007fa22efdddab  add rsp, 0x08
00007fa22efdddaf  jmp 0x00007FA22EFDBF7E
00007fa22efdddb4  call 0x00007FA22EEC4620
00007fa22efdddb9  jmp 0x00007FA22EFDBF8B
00007fa22efdddbe  sub rsp, 0x08
00007fa22efdddc2  push rax
00007fa22efdddc3  push rcx
00007fa22efdddc4  push rdx
00007fa22efdddc5  push rdi
00007fa22efdddc6  push rsi
00007fa22efdddc7  push r8
00007fa22efdddc9  push r9
00007fa22efdddcb  push r10
00007fa22efdddcd  push r11
00007fa22efdddcf  sub rsp, 0xF0
00007fa22efdddd6  vmovaps [rsp], xmm0
00007fa22efddddb  vmovaps [rsp+0x10], xmm2
00007fa22efddde1  vmovaps [rsp+0x20], xmm3
00007fa22efddde7  vmovaps [rsp+0x30], xmm4
00007fa22efddded  vmovaps [rsp+0x40], xmm5
00007fa22efdddf3  vmovaps [rsp+0x50], xmm6
00007fa22efdddf9  vmovaps [rsp+0x60], xmm7
00007fa22efdddff  vmovaps [rsp+0x70], xmm8
00007fa22efdde05  vmovaps [rsp+0x80], xmm9
00007fa22efdde0e  vmovaps [rsp+0x90], xmm10
00007fa22efdde17  vmovaps [rsp+0xA0], xmm11
00007fa22efdde20  vmovaps [rsp+0xB0], xmm12
00007fa22efdde29  vmovaps [rsp+0xC0], xmm13
00007fa22efdde32  vmovaps [rsp+0xD0], xmm14
00007fa22efdde3b  vmovaps [rsp+0xE0], xmm15
00007fa22efdde44  sub rsp, 0x30
00007fa22efdde48  movaps [rsp], xmm1
00007fa22efdde4c  movaps [rsp+0x10], xmm5
00007fa22efdde51  movaps [rsp+0x20], xmm7
00007fa22efdde56  lea rdi, [rsp]
00007fa22efdde5a  mov esi, 0x00
00007fa22efdde5f  mov rax, 0x5E9D1A57D530
00007fa22efdde69  call rax
00007fa22efdde6b  movaps xmm1, [rsp]
00007fa22efdde6f  add rsp, 0x30
00007fa22efdde73  vmovaps xmm0, [rsp]
00007fa22efdde78  vmovaps xmm2, [rsp+0x10]
00007fa22efdde7e  vmovaps xmm3, [rsp+0x20]
00007fa22efdde84  vmovaps xmm4, [rsp+0x30]
00007fa22efdde8a  vmovaps xmm5, [rsp+0x40]
00007fa22efdde90  vmovaps xmm6, [rsp+0x50]
00007fa22efdde96  vmovaps xmm7, [rsp+0x60]
00007fa22efdde9c  vmovaps xmm8, [rsp+0x70]
00007fa22efddea2  vmovaps xmm9, [rsp+0x80]
00007fa22efddeab  vmovaps xmm10, [rsp+0x90]
00007fa22efddeb4  vmovaps xmm11, [rsp+0xA0]
00007fa22efddebd  vmovaps xmm12, [rsp+0xB0]
00007fa22efddec6  vmovaps xmm13, [rsp+0xC0]
00007fa22efddecf  vmovaps xmm14, [rsp+0xD0]
00007fa22efdded8  vmovaps xmm15, [rsp+0xE0]
00007fa22efddee1  add rsp, 0xF0
00007fa22efddee8  pop r11
00007fa22efddeea  pop r10
00007fa22efddeec  pop r9
00007fa22efddeee  pop r8
00007fa22efddef0  pop rsi
00007fa22efddef1  pop rdi
00007fa22efddef2  pop rdx
00007fa22efddef3  pop rcx
00007fa22efddef4  pop rax
00007fa22efddef5  add rsp, 0x08
00007fa22efddef9  jmp 0x00007FA22EFDC030
00007fa22efddefe  sub rsp, 0x08
00007fa22efddf02  push rax
00007fa22efddf03  push rcx
00007fa22efddf04  push rdx
00007fa22efddf05  push rdi
00007fa22efddf06  push rsi
00007fa22efddf07  push r8
00007fa22efddf09  push r9
00007fa22efddf0b  push r10
00007fa22efddf0d  push r11
00007fa22efddf0f  sub rsp, 0xF0
00007fa22efddf16  vmovaps [rsp], xmm0
00007fa22efddf1b  vmovaps [rsp+0x10], xmm1
00007fa22efddf21  vmovaps [rsp+0x20], xmm2
00007fa22efddf27  vmovaps [rsp+0x30], xmm3
00007fa22efddf2d  vmovaps [rsp+0x40], xmm4
00007fa22efddf33  vmovaps [rsp+0x50], xmm5
00007fa22efddf39  vmovaps [rsp+0x60], xmm6
00007fa22efddf3f  vmovaps [rsp+0x70], xmm8
00007fa22efddf45  vmovaps [rsp+0x80], xmm9
00007fa22efddf4e  vmovaps [rsp+0x90], xmm10
00007fa22efddf57  vmovaps [rsp+0xA0], xmm11
00007fa22efddf60  vmovaps [rsp+0xB0], xmm12
00007fa22efddf69  vmovaps [rsp+0xC0], xmm13
00007fa22efddf72  vmovaps [rsp+0xD0], xmm14
00007fa22efddf7b  vmovaps [rsp+0xE0], xmm15
00007fa22efddf84  sub rsp, 0x30
00007fa22efddf88  movaps [rsp], xmm7
00007fa22efddf8c  movaps [rsp+0x10], xmm5
00007fa22efddf91  movaps [rsp+0x20], xmm15
00007fa22efddf97  lea rdi, [rsp]
00007fa22efddf9b  mov esi, 0x00
00007fa22efddfa0  mov rax, 0x5E9D1A57D530
00007fa22efddfaa  call rax
00007fa22efddfac  movaps xmm7, [rsp]
00007fa22efddfb0  add rsp, 0x30
00007fa22efddfb4  vmovaps xmm0, [rsp]
00007fa22efddfb9  vmovaps xmm1, [rsp+0x10]
00007fa22efddfbf  vmovaps xmm2, [rsp+0x20]
00007fa22efddfc5  vmovaps xmm3, [rsp+0x30]
00007fa22efddfcb  vmovaps xmm4, [rsp+0x40]
00007fa22efddfd1  vmovaps xmm5, [rsp+0x50]
00007fa22efddfd7  vmovaps xmm6, [rsp+0x60]
00007fa22efddfdd  vmovaps xmm8, [rsp+0x70]
00007fa22efddfe3  vmovaps xmm9, [rsp+0x80]
00007fa22efddfec  vmovaps xmm10, [rsp+0x90]
00007fa22efddff5  vmovaps xmm11, [rsp+0xA0]
00007fa22efddffe  vmovaps xmm12, [rsp+0xB0]
00007fa22efde007  vmovaps xmm13, [rsp+0xC0]
00007fa22efde010  vmovaps xmm14, [rsp+0xD0]
00007fa22efde019  vmovaps xmm15, [rsp+0xE0]
00007fa22efde022  add rsp, 0xF0
00007fa22efde029  pop r11
00007fa22efde02b  pop r10
00007fa22efde02d  pop r9
00007fa22efde02f  pop r8
00007fa22efde031  pop rsi
00007fa22efde032  pop rdi
00007fa22efde033  pop rdx
00007fa22efde034  pop rcx
00007fa22efde035  pop rax
00007fa22efde036  add rsp, 0x08
00007fa22efde03a  jmp 0x00007FA22EFDC066
00007fa22efde03f  call 0x00007FA22EEB52F0
00007fa22efde044  jmp 0x00007FA22EFDC073
00007fa22efde049  sub rsp, 0x08
00007fa22efde04d  push rax
00007fa22efde04e  push rcx
00007fa22efde04f  push rdx
00007fa22efde050  push rdi
00007fa22efde051  push rsi
00007fa22efde052  push r8
00007fa22efde054  push r9
00007fa22efde056  push r10
00007fa22efde058  push r11
00007fa22efde05a  sub rsp, 0xF0
00007fa22efde061  vmovaps [rsp], xmm0
00007fa22efde066  vmovaps [rsp+0x10], xmm1
00007fa22efde06c  vmovaps [rsp+0x20], xmm2
00007fa22efde072  vmovaps [rsp+0x30], xmm3
00007fa22efde078  vmovaps [rsp+0x40], xmm4
00007fa22efde07e  vmovaps [rsp+0x50], xmm5
00007fa22efde084  vmovaps [rsp+0x60], xmm6
00007fa22efde08a  vmovaps [rsp+0x70], xmm7
00007fa22efde090  vmovaps [rsp+0x80], xmm8
00007fa22efde099  vmovaps [rsp+0x90], xmm9
00007fa22efde0a2  vmovaps [rsp+0xA0], xmm10
00007fa22efde0ab  vmovaps [rsp+0xB0], xmm11
00007fa22efde0b4  vmovaps [rsp+0xC0], xmm12
00007fa22efde0bd  vmovaps [rsp+0xD0], xmm13
00007fa22efde0c6  vmovaps [rsp+0xE0], xmm14
00007fa22efde0cf  sub rsp, 0x30
00007fa22efde0d3  movaps [rsp], xmm15
00007fa22efde0d8  movaps [rsp+0x10], xmm5
00007fa22efde0dd  movaps [rsp+0x20], xmm3
00007fa22efde0e2  lea rdi, [rsp]
00007fa22efde0e6  mov esi, 0x00
00007fa22efde0eb  mov rax, 0x5E9D1A57D530
00007fa22efde0f5  call rax
00007fa22efde0f7  movaps xmm15, [rsp]
00007fa22efde0fc  add rsp, 0x30
00007fa22efde100  vmovaps xmm0, [rsp]
00007fa22efde105  vmovaps xmm1, [rsp+0x10]
00007fa22efde10b  vmovaps xmm2, [rsp+0x20]
00007fa22efde111  vmovaps xmm3, [rsp+0x30]
00007fa22efde117  vmovaps xmm4, [rsp+0x40]
00007fa22efde11d  vmovaps xmm5, [rsp+0x50]
00007fa22efde123  vmovaps xmm6, [rsp+0x60]
00007fa22efde129  vmovaps xmm7, [rsp+0x70]
00007fa22efde12f  vmovaps xmm8, [rsp+0x80]
00007fa22efde138  vmovaps xmm9, [rsp+0x90]
00007fa22efde141  vmovaps xmm10, [rsp+0xA0]
00007fa22efde14a  vmovaps xmm11, [rsp+0xB0]
00007fa22efde153  vmovaps xmm12, [rsp+0xC0]
00007fa22efde15c  vmovaps xmm13, [rsp+0xD0]
00007fa22efde165  vmovaps xmm14, [rsp+0xE0]
00007fa22efde16e  add rsp, 0xF0
00007fa22efde175  pop r11
00007fa22efde177  pop r10
00007fa22efde179  pop r9
00007fa22efde17b  pop r8
00007fa22efde17d  pop rsi
00007fa22efde17e  pop rdi
00007fa22efde17f  pop rdx
00007fa22efde180  pop rcx
00007fa22efde181  pop rax
00007fa22efde182  add rsp, 0x08
00007fa22efde186  jmp 0x00007FA22EFDC099
00007fa22efde18b  sub rsp, 0x08
00007fa22efde18f  push rax
00007fa22efde190  push rcx
00007fa22efde191  push rdx
00007fa22efde192  push rdi
00007fa22efde193  push rsi
00007fa22efde194  push r8
00007fa22efde196  push r9
00007fa22efde198  push r10
00007fa22efde19a  push r11
00007fa22efde19c  sub rsp, 0xF0
00007fa22efde1a3  vmovaps [rsp], xmm0
00007fa22efde1a8  vmovaps [rsp+0x10], xmm2
00007fa22efde1ae  vmovaps [rsp+0x20], xmm3
00007fa22efde1b4  vmovaps [rsp+0x30], xmm4
00007fa22efde1ba  vmovaps [rsp+0x40], xmm5
00007fa22efde1c0  vmovaps [rsp+0x50], xmm6
00007fa22efde1c6  vmovaps [rsp+0x60], xmm7
00007fa22efde1cc  vmovaps [rsp+0x70], xmm8
00007fa22efde1d2  vmovaps [rsp+0x80], xmm9
00007fa22efde1db  vmovaps [rsp+0x90], xmm10
00007fa22efde1e4  vmovaps [rsp+0xA0], xmm11
00007fa22efde1ed  vmovaps [rsp+0xB0], xmm12
00007fa22efde1f6  vmovaps [rsp+0xC0], xmm13
00007fa22efde1ff  vmovaps [rsp+0xD0], xmm14
00007fa22efde208  vmovaps [rsp+0xE0], xmm15
00007fa22efde211  sub rsp, 0x30
00007fa22efde215  movaps [rsp], xmm1
00007fa22efde219  movaps [rsp+0x10], xmm5
00007fa22efde21e  movaps [rsp+0x20], xmm4
00007fa22efde223  lea rdi, [rsp]
00007fa22efde227  mov esi, 0x00
00007fa22efde22c  mov rax, 0x5E9D1A57D530
00007fa22efde236  call rax
00007fa22efde238  movaps xmm1, [rsp]
00007fa22efde23c  add rsp, 0x30
00007fa22efde240  vmovaps xmm0, [rsp]
00007fa22efde245  vmovaps xmm2, [rsp+0x10]
00007fa22efde24b  vmovaps xmm3, [rsp+0x20]
00007fa22efde251  vmovaps xmm4, [rsp+0x30]
00007fa22efde257  vmovaps xmm5, [rsp+0x40]
00007fa22efde25d  vmovaps xmm6, [rsp+0x50]
00007fa22efde263  vmovaps xmm7, [rsp+0x60]
00007fa22efde269  vmovaps xmm8, [rsp+0x70]
00007fa22efde26f  vmovaps xmm9, [rsp+0x80]
00007fa22efde278  vmovaps xmm10, [rsp+0x90]
00007fa22efde281  vmovaps xmm11, [rsp+0xA0]
00007fa22efde28a  vmovaps xmm12, [rsp+0xB0]
00007fa22efde293  vmovaps xmm13, [rsp+0xC0]
00007fa22efde29c  vmovaps xmm14, [rsp+0xD0]
00007fa22efde2a5  vmovaps xmm15, [rsp+0xE0]
00007fa22efde2ae  add rsp, 0xF0
00007fa22efde2b5  pop r11
00007fa22efde2b7  pop r10
00007fa22efde2b9  pop r9
00007fa22efde2bb  pop r8
00007fa22efde2bd  pop rsi
00007fa22efde2be  pop rdi
00007fa22efde2bf  pop rdx
00007fa22efde2c0  pop rcx
00007fa22efde2c1  pop rax
00007fa22efde2c2  add rsp, 0x08
00007fa22efde2c6  jmp 0x00007FA22EFDC0B9
00007fa22efde2cb  sub rsp, 0x08
00007fa22efde2cf  push rax
00007fa22efde2d0  push rcx
00007fa22efde2d1  push rdx
00007fa22efde2d2  push rdi
00007fa22efde2d3  push rsi
00007fa22efde2d4  push r8
00007fa22efde2d6  push r9
00007fa22efde2d8  push r10
00007fa22efde2da  push r11
00007fa22efde2dc  sub rsp, 0xF0
00007fa22efde2e3  vmovaps [rsp], xmm0
00007fa22efde2e8  vmovaps [rsp+0x10], xmm1
00007fa22efde2ee  vmovaps [rsp+0x20], xmm2
00007fa22efde2f4  vmovaps [rsp+0x30], xmm3
00007fa22efde2fa  vmovaps [rsp+0x40], xmm5
00007fa22efde300  vmovaps [rsp+0x50], xmm6
00007fa22efde306  vmovaps [rsp+0x60], xmm7
00007fa22efde30c  vmovaps [rsp+0x70], xmm8
00007fa22efde312  vmovaps [rsp+0x80], xmm9
00007fa22efde31b  vmovaps [rsp+0x90], xmm10
00007fa22efde324  vmovaps [rsp+0xA0], xmm11
00007fa22efde32d  vmovaps [rsp+0xB0], xmm12
00007fa22efde336  vmovaps [rsp+0xC0], xmm13
00007fa22efde33f  vmovaps [rsp+0xD0], xmm14
00007fa22efde348  vmovaps [rsp+0xE0], xmm15
00007fa22efde351  sub rsp, 0x30
00007fa22efde355  movaps [rsp], xmm4
00007fa22efde359  movaps [rsp+0x10], xmm3
00007fa22efde35e  movaps [rsp+0x20], xmm5
00007fa22efde363  lea rdi, [rsp]
00007fa22efde367  mov esi, 0x00
00007fa22efde36c  mov rax, 0x5E9D1A57D530
00007fa22efde376  call rax
00007fa22efde378  movaps xmm4, [rsp]
00007fa22efde37c  add rsp, 0x30
00007fa22efde380  vmovaps xmm0, [rsp]
00007fa22efde385  vmovaps xmm1, [rsp+0x10]
00007fa22efde38b  vmovaps xmm2, [rsp+0x20]
00007fa22efde391  vmovaps xmm3, [rsp+0x30]
00007fa22efde397  vmovaps xmm5, [rsp+0x40]
00007fa22efde39d  vmovaps xmm6, [rsp+0x50]
00007fa22efde3a3  vmovaps xmm7, [rsp+0x60]
00007fa22efde3a9  vmovaps xmm8, [rsp+0x70]
00007fa22efde3af  vmovaps xmm9, [rsp+0x80]
00007fa22efde3b8  vmovaps xmm10, [rsp+0x90]
00007fa22efde3c1  vmovaps xmm11, [rsp+0xA0]
00007fa22efde3ca  vmovaps xmm12, [rsp+0xB0]
00007fa22efde3d3  vmovaps xmm13, [rsp+0xC0]
00007fa22efde3dc  vmovaps xmm14, [rsp+0xD0]
00007fa22efde3e5  vmovaps xmm15, [rsp+0xE0]
00007fa22efde3ee  add rsp, 0xF0
00007fa22efde3f5  pop r11
00007fa22efde3f7  pop r10
00007fa22efde3f9  pop r9
00007fa22efde3fb  pop r8
00007fa22efde3fd  pop rsi
00007fa22efde3fe  pop rdi
00007fa22efde3ff  pop rdx
00007fa22efde400  pop rcx
00007fa22efde401  pop rax
00007fa22efde402  add rsp, 0x08
00007fa22efde406  jmp 0x00007FA22EFDC107
00007fa22efde40b  call 0x00007FA22EEB52F0
00007fa22efde410  jmp 0x00007FA22EFDC114
00007fa22efde415  sub rsp, 0x08
00007fa22efde419  push rax
00007fa22efde41a  push rcx
00007fa22efde41b  push rdx
00007fa22efde41c  push rdi
00007fa22efde41d  push rsi
00007fa22efde41e  push r8
00007fa22efde420  push r9
00007fa22efde422  push r10
00007fa22efde424  push r11
00007fa22efde426  sub rsp, 0xF0
00007fa22efde42d  vmovaps [rsp], xmm0
00007fa22efde432  vmovaps [rsp+0x10], xmm1
00007fa22efde438  vmovaps [rsp+0x20], xmm2
00007fa22efde43e  vmovaps [rsp+0x30], xmm3
00007fa22efde444  vmovaps [rsp+0x40], xmm4
00007fa22efde44a  vmovaps [rsp+0x50], xmm6
00007fa22efde450  vmovaps [rsp+0x60], xmm7
00007fa22efde456  vmovaps [rsp+0x70], xmm8
00007fa22efde45c  vmovaps [rsp+0x80], xmm9
00007fa22efde465  vmovaps [rsp+0x90], xmm10
00007fa22efde46e  vmovaps [rsp+0xA0], xmm11
00007fa22efde477  vmovaps [rsp+0xB0], xmm12
00007fa22efde480  vmovaps [rsp+0xC0], xmm13
00007fa22efde489  vmovaps [rsp+0xD0], xmm14
00007fa22efde492  vmovaps [rsp+0xE0], xmm15
00007fa22efde49b  sub rsp, 0x30
00007fa22efde49f  movaps [rsp], xmm5
00007fa22efde4a3  movaps [rsp+0x10], xmm6
00007fa22efde4a8  movaps [rsp+0x20], xmm3
00007fa22efde4ad  lea rdi, [rsp]
00007fa22efde4b1  mov esi, 0x00
00007fa22efde4b6  mov rax, 0x5E9D1A57D530
00007fa22efde4c0  call rax
00007fa22efde4c2  movaps xmm5, [rsp]
00007fa22efde4c6  add rsp, 0x30
00007fa22efde4ca  vmovaps xmm0, [rsp]
00007fa22efde4cf  vmovaps xmm1, [rsp+0x10]
00007fa22efde4d5  vmovaps xmm2, [rsp+0x20]
00007fa22efde4db  vmovaps xmm3, [rsp+0x30]
00007fa22efde4e1  vmovaps xmm4, [rsp+0x40]
00007fa22efde4e7  vmovaps xmm6, [rsp+0x50]
00007fa22efde4ed  vmovaps xmm7, [rsp+0x60]
00007fa22efde4f3  vmovaps xmm8, [rsp+0x70]
00007fa22efde4f9  vmovaps xmm9, [rsp+0x80]
00007fa22efde502  vmovaps xmm10, [rsp+0x90]
00007fa22efde50b  vmovaps xmm11, [rsp+0xA0]
00007fa22efde514  vmovaps xmm12, [rsp+0xB0]
00007fa22efde51d  vmovaps xmm13, [rsp+0xC0]
00007fa22efde526  vmovaps xmm14, [rsp+0xD0]
00007fa22efde52f  vmovaps xmm15, [rsp+0xE0]
00007fa22efde538  add rsp, 0xF0
00007fa22efde53f  pop r11
00007fa22efde541  pop r10
00007fa22efde543  pop r9
00007fa22efde545  pop r8
00007fa22efde547  pop rsi
00007fa22efde548  pop rdi
00007fa22efde549  pop rdx
00007fa22efde54a  pop rcx
00007fa22efde54b  pop rax
00007fa22efde54c  add rsp, 0x08
00007fa22efde550  jmp 0x00007FA22EFDC13A
00007fa22efde555  sub rsp, 0x08
00007fa22efde559  push rax
00007fa22efde55a  push rcx
00007fa22efde55b  push rdx
00007fa22efde55c  push rdi
00007fa22efde55d  push rsi
00007fa22efde55e  push r8
00007fa22efde560  push r9
00007fa22efde562  push r10
00007fa22efde564  push r11
00007fa22efde566  sub rsp, 0xF0
00007fa22efde56d  vmovaps [rsp], xmm0
00007fa22efde572  vmovaps [rsp+0x10], xmm1
00007fa22efde578  vmovaps [rsp+0x20], xmm2
00007fa22efde57e  vmovaps [rsp+0x30], xmm3
00007fa22efde584  vmovaps [rsp+0x40], xmm4
00007fa22efde58a  vmovaps [rsp+0x50], xmm5
00007fa22efde590  vmovaps [rsp+0x60], xmm7
00007fa22efde596  vmovaps [rsp+0x70], xmm8
00007fa22efde59c  vmovaps [rsp+0x80], xmm9
00007fa22efde5a5  vmovaps [rsp+0x90], xmm10
00007fa22efde5ae  vmovaps [rsp+0xA0], xmm11
00007fa22efde5b7  vmovaps [rsp+0xB0], xmm12
00007fa22efde5c0  vmovaps [rsp+0xC0], xmm13
00007fa22efde5c9  vmovaps [rsp+0xD0], xmm14
00007fa22efde5d2  vmovaps [rsp+0xE0], xmm15
00007fa22efde5db  sub rsp, 0x30
00007fa22efde5df  movaps [rsp], xmm6
00007fa22efde5e3  movaps [rsp+0x10], xmm9
00007fa22efde5e9  movaps [rsp+0x20], xmm1
00007fa22efde5ee  lea rdi, [rsp]
00007fa22efde5f2  mov esi, 0x00
00007fa22efde5f7  mov rax, 0x5E9D1A57D530
00007fa22efde601  call rax
00007fa22efde603  movaps xmm6, [rsp]
00007fa22efde607  add rsp, 0x30
00007fa22efde60b  vmovaps xmm0, [rsp]
00007fa22efde610  vmovaps xmm1, [rsp+0x10]
00007fa22efde616  vmovaps xmm2, [rsp+0x20]
00007fa22efde61c  vmovaps xmm3, [rsp+0x30]
00007fa22efde622  vmovaps xmm4, [rsp+0x40]
00007fa22efde628  vmovaps xmm5, [rsp+0x50]
00007fa22efde62e  vmovaps xmm7, [rsp+0x60]
00007fa22efde634  vmovaps xmm8, [rsp+0x70]
00007fa22efde63a  vmovaps xmm9, [rsp+0x80]
00007fa22efde643  vmovaps xmm10, [rsp+0x90]
00007fa22efde64c  vmovaps xmm11, [rsp+0xA0]
00007fa22efde655  vmovaps xmm12, [rsp+0xB0]
00007fa22efde65e  vmovaps xmm13, [rsp+0xC0]
00007fa22efde667  vmovaps xmm14, [rsp+0xD0]
00007fa22efde670  vmovaps xmm15, [rsp+0xE0]
00007fa22efde679  add rsp, 0xF0
00007fa22efde680  pop r11
00007fa22efde682  pop r10
00007fa22efde684  pop r9
00007fa22efde686  pop r8
00007fa22efde688  pop rsi
00007fa22efde689  pop rdi
00007fa22efde68a  pop rdx
00007fa22efde68b  pop rcx
00007fa22efde68c  pop rax
00007fa22efde68d  add rsp, 0x08
00007fa22efde691  jmp 0x00007FA22EFDC15E
00007fa22efde696  sub rsp, 0x08
00007fa22efde69a  push rax
00007fa22efde69b  push rcx
00007fa22efde69c  push rdx
00007fa22efde69d  push rdi
00007fa22efde69e  push rsi
00007fa22efde69f  push r8
00007fa22efde6a1  push r9
00007fa22efde6a3  push r10
00007fa22efde6a5  push r11
00007fa22efde6a7  sub rsp, 0xF0
00007fa22efde6ae  vmovaps [rsp], xmm0
00007fa22efde6b3  vmovaps [rsp+0x10], xmm1
00007fa22efde6b9  vmovaps [rsp+0x20], xmm2
00007fa22efde6bf  vmovaps [rsp+0x30], xmm3
00007fa22efde6c5  vmovaps [rsp+0x40], xmm4
00007fa22efde6cb  vmovaps [rsp+0x50], xmm5
00007fa22efde6d1  vmovaps [rsp+0x60], xmm6
00007fa22efde6d7  vmovaps [rsp+0x70], xmm7
00007fa22efde6dd  vmovaps [rsp+0x80], xmm8
00007fa22efde6e6  vmovaps [rsp+0x90], xmm10
00007fa22efde6ef  vmovaps [rsp+0xA0], xmm11
00007fa22efde6f8  vmovaps [rsp+0xB0], xmm12
00007fa22efde701  vmovaps [rsp+0xC0], xmm13
00007fa22efde70a  vmovaps [rsp+0xD0], xmm14
00007fa22efde713  vmovaps [rsp+0xE0], xmm15
00007fa22efde71c  sub rsp, 0x30
00007fa22efde720  movaps [rsp], xmm9
00007fa22efde725  movaps [rsp+0x10], xmm3
00007fa22efde72a  movaps [rsp+0x20], xmm1
00007fa22efde72f  lea rdi, [rsp]
00007fa22efde733  mov esi, 0x00
00007fa22efde738  mov rax, 0x5E9D1A57D530
00007fa22efde742  call rax
00007fa22efde744  movaps xmm9, [rsp]
00007fa22efde749  add rsp, 0x30
00007fa22efde74d  vmovaps xmm0, [rsp]
00007fa22efde752  vmovaps xmm1, [rsp+0x10]
00007fa22efde758  vmovaps xmm2, [rsp+0x20]
00007fa22efde75e  vmovaps xmm3, [rsp+0x30]
00007fa22efde764  vmovaps xmm4, [rsp+0x40]
00007fa22efde76a  vmovaps xmm5, [rsp+0x50]
00007fa22efde770  vmovaps xmm6, [rsp+0x60]
00007fa22efde776  vmovaps xmm7, [rsp+0x70]
00007fa22efde77c  vmovaps xmm8, [rsp+0x80]
00007fa22efde785  vmovaps xmm10, [rsp+0x90]
00007fa22efde78e  vmovaps xmm11, [rsp+0xA0]
00007fa22efde797  vmovaps xmm12, [rsp+0xB0]
00007fa22efde7a0  vmovaps xmm13, [rsp+0xC0]
00007fa22efde7a9  vmovaps xmm14, [rsp+0xD0]
00007fa22efde7b2  vmovaps xmm15, [rsp+0xE0]
00007fa22efde7bb  add rsp, 0xF0
00007fa22efde7c2  pop r11
00007fa22efde7c4  pop r10
00007fa22efde7c6  pop r9
00007fa22efde7c8  pop r8
00007fa22efde7ca  pop rsi
00007fa22efde7cb  pop rdi
00007fa22efde7cc  pop rdx
00007fa22efde7cd  pop rcx
00007fa22efde7ce  pop rax
00007fa22efde7cf  add rsp, 0x08
00007fa22efde7d3  jmp 0x00007FA22EFDC1AA
00007fa22efde7d8  call 0x00007FA22EEB52F0
00007fa22efde7dd  jmp 0x00007FA22EFDC1B7
00007fa22efde7e2  sub rsp, 0x08
00007fa22efde7e6  push rax
00007fa22efde7e7  push rcx
00007fa22efde7e8  push rdx
00007fa22efde7e9  push rdi
00007fa22efde7ea  push rsi
00007fa22efde7eb  push r8
00007fa22efde7ed  push r9
00007fa22efde7ef  push r10
00007fa22efde7f1  push r11
00007fa22efde7f3  sub rsp, 0xF0
00007fa22efde7fa  vmovaps [rsp], xmm0
00007fa22efde7ff  vmovaps [rsp+0x10], xmm1
00007fa22efde805  vmovaps [rsp+0x20], xmm2
00007fa22efde80b  vmovaps [rsp+0x30], xmm3
00007fa22efde811  vmovaps [rsp+0x40], xmm4
00007fa22efde817  vmovaps [rsp+0x50], xmm5
00007fa22efde81d  vmovaps [rsp+0x60], xmm6
00007fa22efde823  vmovaps [rsp+0x70], xmm7
00007fa22efde829  vmovaps [rsp+0x80], xmm8
00007fa22efde832  vmovaps [rsp+0x90], xmm9
00007fa22efde83b  vmovaps [rsp+0xA0], xmm10
00007fa22efde844  vmovaps [rsp+0xB0], xmm11
00007fa22efde84d  vmovaps [rsp+0xC0], xmm12
00007fa22efde856  vmovaps [rsp+0xD0], xmm13
00007fa22efde85f  vmovaps [rsp+0xE0], xmm14
00007fa22efde868  sub rsp, 0x30
00007fa22efde86c  movaps [rsp], xmm15
00007fa22efde871  movaps [rsp+0x10], xmm3
00007fa22efde876  movaps [rsp+0x20], xmm7
00007fa22efde87b  lea rdi, [rsp]
00007fa22efde87f  mov esi, 0x00
00007fa22efde884  mov rax, 0x5E9D1A57D530
00007fa22efde88e  call rax
00007fa22efde890  movaps xmm15, [rsp]
00007fa22efde895  add rsp, 0x30
00007fa22efde899  vmovaps xmm0, [rsp]
00007fa22efde89e  vmovaps xmm1, [rsp+0x10]
00007fa22efde8a4  vmovaps xmm2, [rsp+0x20]
00007fa22efde8aa  vmovaps xmm3, [rsp+0x30]
00007fa22efde8b0  vmovaps xmm4, [rsp+0x40]
00007fa22efde8b6  vmovaps xmm5, [rsp+0x50]
00007fa22efde8bc  vmovaps xmm6, [rsp+0x60]
00007fa22efde8c2  vmovaps xmm7, [rsp+0x70]
00007fa22efde8c8  vmovaps xmm8, [rsp+0x80]
00007fa22efde8d1  vmovaps xmm9, [rsp+0x90]
00007fa22efde8da  vmovaps xmm10, [rsp+0xA0]
00007fa22efde8e3  vmovaps xmm11, [rsp+0xB0]
00007fa22efde8ec  vmovaps xmm12, [rsp+0xC0]
00007fa22efde8f5  vmovaps xmm13, [rsp+0xD0]
00007fa22efde8fe  vmovaps xmm14, [rsp+0xE0]
00007fa22efde907  add rsp, 0xF0
00007fa22efde90e  pop r11
00007fa22efde910  pop r10
00007fa22efde912  pop r9
00007fa22efde914  pop r8
00007fa22efde916  pop rsi
00007fa22efde917  pop rdi
00007fa22efde918  pop rdx
00007fa22efde919  pop rcx
00007fa22efde91a  pop rax
00007fa22efde91b  add rsp, 0x08
00007fa22efde91f  jmp 0x00007FA22EFDC1E3
00007fa22efde924  sub rsp, 0x08
00007fa22efde928  push rax
00007fa22efde929  push rcx
00007fa22efde92a  push rdx
00007fa22efde92b  push rdi
00007fa22efde92c  push rsi
00007fa22efde92d  push r8
00007fa22efde92f  push r9
00007fa22efde931  push r10
00007fa22efde933  push r11
00007fa22efde935  sub rsp, 0xF0
00007fa22efde93c  vmovaps [rsp], xmm0
00007fa22efde941  vmovaps [rsp+0x10], xmm1
00007fa22efde947  vmovaps [rsp+0x20], xmm2
00007fa22efde94d  vmovaps [rsp+0x30], xmm4
00007fa22efde953  vmovaps [rsp+0x40], xmm5
00007fa22efde959  vmovaps [rsp+0x50], xmm6
00007fa22efde95f  vmovaps [rsp+0x60], xmm7
00007fa22efde965  vmovaps [rsp+0x70], xmm8
00007fa22efde96b  vmovaps [rsp+0x80], xmm9
00007fa22efde974  vmovaps [rsp+0x90], xmm10
00007fa22efde97d  vmovaps [rsp+0xA0], xmm11
00007fa22efde986  vmovaps [rsp+0xB0], xmm12
00007fa22efde98f  vmovaps [rsp+0xC0], xmm13
00007fa22efde998  vmovaps [rsp+0xD0], xmm14
00007fa22efde9a1  vmovaps [rsp+0xE0], xmm15
00007fa22efde9aa  sub rsp, 0x30
00007fa22efde9ae  movaps [rsp], xmm3
00007fa22efde9b2  movaps [rsp+0x10], xmm1
00007fa22efde9b7  movaps [rsp+0x20], xmm15
00007fa22efde9bd  lea rdi, [rsp]
00007fa22efde9c1  mov esi, 0x00
00007fa22efde9c6  mov rax, 0x5E9D1A57D530
00007fa22efde9d0  call rax
00007fa22efde9d2  movaps xmm3, [rsp]
00007fa22efde9d6  add rsp, 0x30
00007fa22efde9da  vmovaps xmm0, [rsp]
00007fa22efde9df  vmovaps xmm1, [rsp+0x10]
00007fa22efde9e5  vmovaps xmm2, [rsp+0x20]
00007fa22efde9eb  vmovaps xmm4, [rsp+0x30]
00007fa22efde9f1  vmovaps xmm5, [rsp+0x40]
00007fa22efde9f7  vmovaps xmm6, [rsp+0x50]
00007fa22efde9fd  vmovaps xmm7, [rsp+0x60]
00007fa22efdea03  vmovaps xmm8, [rsp+0x70]
00007fa22efdea09  vmovaps xmm9, [rsp+0x80]
00007fa22efdea12  vmovaps xmm10, [rsp+0x90]
00007fa22efdea1b  vmovaps xmm11, [rsp+0xA0]
00007fa22efdea24  vmovaps xmm12, [rsp+0xB0]
00007fa22efdea2d  vmovaps xmm13, [rsp+0xC0]
00007fa22efdea36  vmovaps xmm14, [rsp+0xD0]
00007fa22efdea3f  vmovaps xmm15, [rsp+0xE0]
00007fa22efdea48  add rsp, 0xF0
00007fa22efdea4f  pop r11
00007fa22efdea51  pop r10
00007fa22efdea53  pop r9
00007fa22efdea55  pop r8
00007fa22efdea57  pop rsi
00007fa22efdea58  pop rdi
00007fa22efdea59  pop rdx
00007fa22efdea5a  pop rcx
00007fa22efdea5b  pop rax
00007fa22efdea5c  add rsp, 0x08
00007fa22efdea60  jmp 0x00007FA22EFDC272
00007fa22efdea65  call 0x00007FA22EEB52F0
00007fa22efdea6a  jmp 0x00007FA22EFDC27C
00007fa22efdea6f  sub rsp, 0x08
00007fa22efdea73  push rax
00007fa22efdea74  push rcx
00007fa22efdea75  push rdx
00007fa22efdea76  push rdi
00007fa22efdea77  push rsi
00007fa22efdea78  push r8
00007fa22efdea7a  push r9
00007fa22efdea7c  push r10
00007fa22efdea7e  push r11
00007fa22efdea80  sub rsp, 0xF0
00007fa22efdea87  vmovaps [rsp], xmm0
00007fa22efdea8c  vmovaps [rsp+0x10], xmm1
00007fa22efdea92  vmovaps [rsp+0x20], xmm2
00007fa22efdea98  vmovaps [rsp+0x30], xmm3
00007fa22efdea9e  vmovaps [rsp+0x40], xmm4
00007fa22efdeaa4  vmovaps [rsp+0x50], xmm5
00007fa22efdeaaa  vmovaps [rsp+0x60], xmm6
00007fa22efdeab0  vmovaps [rsp+0x70], xmm7
00007fa22efdeab6  vmovaps [rsp+0x80], xmm8
00007fa22efdeabf  vmovaps [rsp+0x90], xmm9
00007fa22efdeac8  vmovaps [rsp+0xA0], xmm10
00007fa22efdead1  vmovaps [rsp+0xB0], xmm11
00007fa22efdeada  vmovaps [rsp+0xC0], xmm12
00007fa22efdeae3  vmovaps [rsp+0xD0], xmm13
00007fa22efdeaec  vmovaps [rsp+0xE0], xmm14
00007fa22efdeaf5  sub rsp, 0x30
00007fa22efdeaf9  movaps [rsp], xmm15
00007fa22efdeafe  movaps [rsp+0x10], xmm14
00007fa22efdeb04  movaps [rsp+0x20], xmm4
00007fa22efdeb09  lea rdi, [rsp]
00007fa22efdeb0d  mov esi, 0x00
00007fa22efdeb12  mov rax, 0x5E9D1A57D530
00007fa22efdeb1c  call rax
00007fa22efdeb1e  movaps xmm15, [rsp]
00007fa22efdeb23  add rsp, 0x30
00007fa22efdeb27  vmovaps xmm0, [rsp]
00007fa22efdeb2c  vmovaps xmm1, [rsp+0x10]
00007fa22efdeb32  vmovaps xmm2, [rsp+0x20]
00007fa22efdeb38  vmovaps xmm3, [rsp+0x30]
00007fa22efdeb3e  vmovaps xmm4, [rsp+0x40]
00007fa22efdeb44  vmovaps xmm5, [rsp+0x50]
00007fa22efdeb4a  vmovaps xmm6, [rsp+0x60]
00007fa22efdeb50  vmovaps xmm7, [rsp+0x70]
00007fa22efdeb56  vmovaps xmm8, [rsp+0x80]
00007fa22efdeb5f  vmovaps xmm9, [rsp+0x90]
00007fa22efdeb68  vmovaps xmm10, [rsp+0xA0]
00007fa22efdeb71  vmovaps xmm11, [rsp+0xB0]
00007fa22efdeb7a  vmovaps xmm12, [rsp+0xC0]
00007fa22efdeb83  vmovaps xmm13, [rsp+0xD0]
00007fa22efdeb8c  vmovaps xmm14, [rsp+0xE0]
00007fa22efdeb95  add rsp, 0xF0
00007fa22efdeb9c  pop r11
00007fa22efdeb9e  pop r10
00007fa22efdeba0  pop r9
00007fa22efdeba2  pop r8
00007fa22efdeba4  pop rsi
00007fa22efdeba5  pop rdi
00007fa22efdeba6  pop rdx
00007fa22efdeba7  pop rcx
00007fa22efdeba8  pop rax
00007fa22efdeba9  add rsp, 0x08
00007fa22efdebad  jmp 0x00007FA22EFDC2AA
00007fa22efdebb2  sub rsp, 0x08
00007fa22efdebb6  push rax
00007fa22efdebb7  push rcx
00007fa22efdebb8  push rdx
00007fa22efdebb9  push rdi
00007fa22efdebba  push rsi
00007fa22efdebbb  push r8
00007fa22efdebbd  push r9
00007fa22efdebbf  push r10
00007fa22efdebc1  push r11
00007fa22efdebc3  sub rsp, 0xF0
00007fa22efdebca  vmovaps [rsp], xmm0
00007fa22efdebcf  vmovaps [rsp+0x10], xmm1
00007fa22efdebd5  vmovaps [rsp+0x20], xmm2
00007fa22efdebdb  vmovaps [rsp+0x30], xmm3
00007fa22efdebe1  vmovaps [rsp+0x40], xmm4
00007fa22efdebe7  vmovaps [rsp+0x50], xmm5
00007fa22efdebed  vmovaps [rsp+0x60], xmm6
00007fa22efdebf3  vmovaps [rsp+0x70], xmm7
00007fa22efdebf9  vmovaps [rsp+0x80], xmm8
00007fa22efdec02  vmovaps [rsp+0x90], xmm9
00007fa22efdec0b  vmovaps [rsp+0xA0], xmm10
00007fa22efdec14  vmovaps [rsp+0xB0], xmm11
00007fa22efdec1d  vmovaps [rsp+0xC0], xmm12
00007fa22efdec26  vmovaps [rsp+0xD0], xmm13
00007fa22efdec2f  vmovaps [rsp+0xE0], xmm15
00007fa22efdec38  sub rsp, 0x30
00007fa22efdec3c  movaps [rsp], xmm14
00007fa22efdec41  movaps [rsp+0x10], xmm2
00007fa22efdec46  movaps [rsp+0x20], xmm1
00007fa22efdec4b  lea rdi, [rsp]
00007fa22efdec4f  mov esi, 0x00
00007fa22efdec54  mov rax, 0x5E9D1A57D530
00007fa22efdec5e  call rax
00007fa22efdec60  movaps xmm14, [rsp]
00007fa22efdec65  add rsp, 0x30
00007fa22efdec69  vmovaps xmm0, [rsp]
00007fa22efdec6e  vmovaps xmm1, [rsp+0x10]
00007fa22efdec74  vmovaps xmm2, [rsp+0x20]
00007fa22efdec7a  vmovaps xmm3, [rsp+0x30]
00007fa22efdec80  vmovaps xmm4, [rsp+0x40]
00007fa22efdec86  vmovaps xmm5, [rsp+0x50]
00007fa22efdec8c  vmovaps xmm6, [rsp+0x60]
00007fa22efdec92  vmovaps xmm7, [rsp+0x70]
00007fa22efdec98  vmovaps xmm8, [rsp+0x80]
00007fa22efdeca1  vmovaps xmm9, [rsp+0x90]
00007fa22efdecaa  vmovaps xmm10, [rsp+0xA0]
00007fa22efdecb3  vmovaps xmm11, [rsp+0xB0]
00007fa22efdecbc  vmovaps xmm12, [rsp+0xC0]
00007fa22efdecc5  vmovaps xmm13, [rsp+0xD0]
00007fa22efdecce  vmovaps xmm15, [rsp+0xE0]
00007fa22efdecd7  add rsp, 0xF0
00007fa22efdecde  pop r11
00007fa22efdece0  pop r10
00007fa22efdece2  pop r9
00007fa22efdece4  pop r8
00007fa22efdece6  pop rsi
00007fa22efdece7  pop rdi
00007fa22efdece8  pop rdx
00007fa22efdece9  pop rcx
00007fa22efdecea  pop rax
00007fa22efdeceb  add rsp, 0x08
00007fa22efdecef  jmp 0x00007FA22EFDC2D0
00007fa22efdecf4  sub rsp, 0x08
00007fa22efdecf8  push rax
00007fa22efdecf9  push rcx
00007fa22efdecfa  push rdx
00007fa22efdecfb  push rdi
00007fa22efdecfc  push rsi
00007fa22efdecfd  push r8
00007fa22efdecff  push r9
00007fa22efded01  push r10
00007fa22efded03  push r11
00007fa22efded05  sub rsp, 0xF0
00007fa22efded0c  vmovaps [rsp], xmm0
00007fa22efded11  vmovaps [rsp+0x10], xmm2
00007fa22efded17  vmovaps [rsp+0x20], xmm3
00007fa22efded1d  vmovaps [rsp+0x30], xmm4
00007fa22efded23  vmovaps [rsp+0x40], xmm5
00007fa22efded29  vmovaps [rsp+0x50], xmm6
00007fa22efded2f  vmovaps [rsp+0x60], xmm7
00007fa22efded35  vmovaps [rsp+0x70], xmm8
00007fa22efded3b  vmovaps [rsp+0x80], xmm9
00007fa22efded44  vmovaps [rsp+0x90], xmm10
00007fa22efded4d  vmovaps [rsp+0xA0], xmm11
00007fa22efded56  vmovaps [rsp+0xB0], xmm12
00007fa22efded5f  vmovaps [rsp+0xC0], xmm13
00007fa22efded68  vmovaps [rsp+0xD0], xmm14
00007fa22efded71  vmovaps [rsp+0xE0], xmm15
00007fa22efded7a  sub rsp, 0x30
00007fa22efded7e  movaps [rsp], xmm1
00007fa22efded82  movaps [rsp+0x10], xmm4
00007fa22efded87  movaps [rsp+0x20], xmm9
00007fa22efded8d  lea rdi, [rsp]
00007fa22efded91  mov esi, 0x00
00007fa22efded96  mov rax, 0x5E9D1A57D530
00007fa22efdeda0  call rax
00007fa22efdeda2  movaps xmm1, [rsp]
00007fa22efdeda6  add rsp, 0x30
00007fa22efdedaa  vmovaps xmm0, [rsp]
00007fa22efdedaf  vmovaps xmm2, [rsp+0x10]
00007fa22efdedb5  vmovaps xmm3, [rsp+0x20]
00007fa22efdedbb  vmovaps xmm4, [rsp+0x30]
00007fa22efdedc1  vmovaps xmm5, [rsp+0x40]
00007fa22efdedc7  vmovaps xmm6, [rsp+0x50]
00007fa22efdedcd  vmovaps xmm7, [rsp+0x60]
00007fa22efdedd3  vmovaps xmm8, [rsp+0x70]
00007fa22efdedd9  vmovaps xmm9, [rsp+0x80]
00007fa22efdede2  vmovaps xmm10, [rsp+0x90]
00007fa22efdedeb  vmovaps xmm11, [rsp+0xA0]
00007fa22efdedf4  vmovaps xmm12, [rsp+0xB0]
00007fa22efdedfd  vmovaps xmm13, [rsp+0xC0]
00007fa22efdee06  vmovaps xmm14, [rsp+0xD0]
00007fa22efdee0f  vmovaps xmm15, [rsp+0xE0]
00007fa22efdee18  add rsp, 0xF0
00007fa22efdee1f  pop r11
00007fa22efdee21  pop r10
00007fa22efdee23  pop r9
00007fa22efdee25  pop r8
00007fa22efdee27  pop rsi
00007fa22efdee28  pop rdi
00007fa22efdee29  pop rdx
00007fa22efdee2a  pop rcx
00007fa22efdee2b  pop rax
00007fa22efdee2c  add rsp, 0x08
00007fa22efdee30  jmp 0x00007FA22EFDC2EE
00007fa22efdee35  sub rsp, 0x08
00007fa22efdee39  push rax
00007fa22efdee3a  push rcx
00007fa22efdee3b  push rdx
00007fa22efdee3c  push rdi
00007fa22efdee3d  push rsi
00007fa22efdee3e  push r8
00007fa22efdee40  push r9
00007fa22efdee42  push r10
00007fa22efdee44  push r11
00007fa22efdee46  sub rsp, 0xF0
00007fa22efdee4d  vmovaps [rsp], xmm0
00007fa22efdee52  vmovaps [rsp+0x10], xmm1
00007fa22efdee58  vmovaps [rsp+0x20], xmm2
00007fa22efdee5e  vmovaps [rsp+0x30], xmm3
00007fa22efdee64  vmovaps [rsp+0x40], xmm5
00007fa22efdee6a  vmovaps [rsp+0x50], xmm6
00007fa22efdee70  vmovaps [rsp+0x60], xmm7
00007fa22efdee76  vmovaps [rsp+0x70], xmm8
00007fa22efdee7c  vmovaps [rsp+0x80], xmm9
00007fa22efdee85  vmovaps [rsp+0x90], xmm10
00007fa22efdee8e  vmovaps [rsp+0xA0], xmm11
00007fa22efdee97  vmovaps [rsp+0xB0], xmm12
00007fa22efdeea0  vmovaps [rsp+0xC0], xmm13
00007fa22efdeea9  vmovaps [rsp+0xD0], xmm14
00007fa22efdeeb2  vmovaps [rsp+0xE0], xmm15
00007fa22efdeebb  sub rsp, 0x30
00007fa22efdeebf  movaps [rsp], xmm4
00007fa22efdeec3  movaps [rsp+0x10], xmm2
00007fa22efdeec8  movaps [rsp+0x20], xmm9
00007fa22efdeece  lea rdi, [rsp]
00007fa22efdeed2  mov esi, 0x00
00007fa22efdeed7  mov rax, 0x5E9D1A57D530
00007fa22efdeee1  call rax
00007fa22efdeee3  movaps xmm4, [rsp]
00007fa22efdeee7  add rsp, 0x30
00007fa22efdeeeb  vmovaps xmm0, [rsp]
00007fa22efdeef0  vmovaps xmm1, [rsp+0x10]
00007fa22efdeef6  vmovaps xmm2, [rsp+0x20]
00007fa22efdeefc  vmovaps xmm3, [rsp+0x30]
00007fa22efdef02  vmovaps xmm5, [rsp+0x40]
00007fa22efdef08  vmovaps xmm6, [rsp+0x50]
00007fa22efdef0e  vmovaps xmm7, [rsp+0x60]
00007fa22efdef14  vmovaps xmm8, [rsp+0x70]
00007fa22efdef1a  vmovaps xmm9, [rsp+0x80]
00007fa22efdef23  vmovaps xmm10, [rsp+0x90]
00007fa22efdef2c  vmovaps xmm11, [rsp+0xA0]
00007fa22efdef35  vmovaps xmm12, [rsp+0xB0]
00007fa22efdef3e  vmovaps xmm13, [rsp+0xC0]
00007fa22efdef47  vmovaps xmm14, [rsp+0xD0]
00007fa22efdef50  vmovaps xmm15, [rsp+0xE0]
00007fa22efdef59  add rsp, 0xF0
00007fa22efdef60  pop r11
00007fa22efdef62  pop r10
00007fa22efdef64  pop r9
00007fa22efdef66  pop r8
00007fa22efdef68  pop rsi
00007fa22efdef69  pop rdi
00007fa22efdef6a  pop rdx
00007fa22efdef6b  pop rcx
00007fa22efdef6c  pop rax
00007fa22efdef6d  add rsp, 0x08
00007fa22efdef71  jmp 0x00007FA22EFDC31E
00007fa22efdef76  sub rsp, 0x08
00007fa22efdef7a  push rax
00007fa22efdef7b  push rcx
00007fa22efdef7c  push rdx
00007fa22efdef7d  push rdi
00007fa22efdef7e  push rsi
00007fa22efdef7f  push r8
00007fa22efdef81  push r9
00007fa22efdef83  push r10
00007fa22efdef85  push r11
00007fa22efdef87  sub rsp, 0xF0
00007fa22efdef8e  vmovaps [rsp], xmm0
00007fa22efdef93  vmovaps [rsp+0x10], xmm1
00007fa22efdef99  vmovaps [rsp+0x20], xmm2
00007fa22efdef9f  vmovaps [rsp+0x30], xmm3
00007fa22efdefa5  vmovaps [rsp+0x40], xmm4
00007fa22efdefab  vmovaps [rsp+0x50], xmm5
00007fa22efdefb1  vmovaps [rsp+0x60], xmm6
00007fa22efdefb7  vmovaps [rsp+0x70], xmm7
00007fa22efdefbd  vmovaps [rsp+0x80], xmm8
00007fa22efdefc6  vmovaps [rsp+0x90], xmm10
00007fa22efdefcf  vmovaps [rsp+0xA0], xmm11
00007fa22efdefd8  vmovaps [rsp+0xB0], xmm12
00007fa22efdefe1  vmovaps [rsp+0xC0], xmm13
00007fa22efdefea  vmovaps [rsp+0xD0], xmm14
00007fa22efdeff3  vmovaps [rsp+0xE0], xmm15
00007fa22efdeffc  sub rsp, 0x30
00007fa22efdf000  movaps [rsp], xmm9
00007fa22efdf005  movaps [rsp+0x10], xmm2
00007fa22efdf00a  movaps [rsp+0x20], xmm1
00007fa22efdf00f  lea rdi, [rsp]
00007fa22efdf013  mov esi, 0x00
00007fa22efdf018  mov rax, 0x5E9D1A57D530
00007fa22efdf022  call rax
00007fa22efdf024  movaps xmm9, [rsp]
00007fa22efdf029  add rsp, 0x30
00007fa22efdf02d  vmovaps xmm0, [rsp]
00007fa22efdf032  vmovaps xmm1, [rsp+0x10]
00007fa22efdf038  vmovaps xmm2, [rsp+0x20]
00007fa22efdf03e  vmovaps xmm3, [rsp+0x30]
00007fa22efdf044  vmovaps xmm4, [rsp+0x40]
00007fa22efdf04a  vmovaps xmm5, [rsp+0x50]
00007fa22efdf050  vmovaps xmm6, [rsp+0x60]
00007fa22efdf056  vmovaps xmm7, [rsp+0x70]
00007fa22efdf05c  vmovaps xmm8, [rsp+0x80]
00007fa22efdf065  vmovaps xmm10, [rsp+0x90]
00007fa22efdf06e  vmovaps xmm11, [rsp+0xA0]
00007fa22efdf077  vmovaps xmm12, [rsp+0xB0]
00007fa22efdf080  vmovaps xmm13, [rsp+0xC0]
00007fa22efdf089  vmovaps xmm14, [rsp+0xD0]
00007fa22efdf092  vmovaps xmm15, [rsp+0xE0]
00007fa22efdf09b  add rsp, 0xF0
00007fa22efdf0a2  pop r11
00007fa22efdf0a4  pop r10
00007fa22efdf0a6  pop r9
00007fa22efdf0a8  pop r8
00007fa22efdf0aa  pop rsi
00007fa22efdf0ab  pop rdi
00007fa22efdf0ac  pop rdx
00007fa22efdf0ad  pop rcx
00007fa22efdf0ae  pop rax
00007fa22efdf0af  add rsp, 0x08
00007fa22efdf0b3  jmp 0x00007FA22EFDC354
00007fa22efdf0b8  sub rsp, 0x08
00007fa22efdf0bc  push rax
00007fa22efdf0bd  push rcx
00007fa22efdf0be  push rdx
00007fa22efdf0bf  push rdi
00007fa22efdf0c0  push rsi
00007fa22efdf0c1  push r8
00007fa22efdf0c3  push r9
00007fa22efdf0c5  push r10
00007fa22efdf0c7  push r11
00007fa22efdf0c9  sub rsp, 0xF0
00007fa22efdf0d0  vmovaps [rsp], xmm0
00007fa22efdf0d5  vmovaps [rsp+0x10], xmm2
00007fa22efdf0db  vmovaps [rsp+0x20], xmm3
00007fa22efdf0e1  vmovaps [rsp+0x30], xmm4
00007fa22efdf0e7  vmovaps [rsp+0x40], xmm5
00007fa22efdf0ed  vmovaps [rsp+0x50], xmm6
00007fa22efdf0f3  vmovaps [rsp+0x60], xmm7
00007fa22efdf0f9  vmovaps [rsp+0x70], xmm8
00007fa22efdf0ff  vmovaps [rsp+0x80], xmm9
00007fa22efdf108  vmovaps [rsp+0x90], xmm10
00007fa22efdf111  vmovaps [rsp+0xA0], xmm11
00007fa22efdf11a  vmovaps [rsp+0xB0], xmm12
00007fa22efdf123  vmovaps [rsp+0xC0], xmm13
00007fa22efdf12c  vmovaps [rsp+0xD0], xmm14
00007fa22efdf135  vmovaps [rsp+0xE0], xmm15
00007fa22efdf13e  sub rsp, 0x30
00007fa22efdf142  movaps [rsp], xmm1
00007fa22efdf146  movaps [rsp+0x10], xmm15
00007fa22efdf14c  movaps [rsp+0x20], xmm6
00007fa22efdf151  lea rdi, [rsp]
00007fa22efdf155  mov esi, 0x00
00007fa22efdf15a  mov rax, 0x5E9D1A57D530
00007fa22efdf164  call rax
00007fa22efdf166  movaps xmm1, [rsp]
00007fa22efdf16a  add rsp, 0x30
00007fa22efdf16e  vmovaps xmm0, [rsp]
00007fa22efdf173  vmovaps xmm2, [rsp+0x10]
00007fa22efdf179  vmovaps xmm3, [rsp+0x20]
00007fa22efdf17f  vmovaps xmm4, [rsp+0x30]
00007fa22efdf185  vmovaps xmm5, [rsp+0x40]
00007fa22efdf18b  vmovaps xmm6, [rsp+0x50]
00007fa22efdf191  vmovaps xmm7, [rsp+0x60]
00007fa22efdf197  vmovaps xmm8, [rsp+0x70]
00007fa22efdf19d  vmovaps xmm9, [rsp+0x80]
00007fa22efdf1a6  vmovaps xmm10, [rsp+0x90]
00007fa22efdf1af  vmovaps xmm11, [rsp+0xA0]
00007fa22efdf1b8  vmovaps xmm12, [rsp+0xB0]
00007fa22efdf1c1  vmovaps xmm13, [rsp+0xC0]
00007fa22efdf1ca  vmovaps xmm14, [rsp+0xD0]
00007fa22efdf1d3  vmovaps xmm15, [rsp+0xE0]
00007fa22efdf1dc  add rsp, 0xF0
00007fa22efdf1e3  pop r11
00007fa22efdf1e5  pop r10
00007fa22efdf1e7  pop r9
00007fa22efdf1e9  pop r8
00007fa22efdf1eb  pop rsi
00007fa22efdf1ec  pop rdi
00007fa22efdf1ed  pop rdx
00007fa22efdf1ee  pop rcx
00007fa22efdf1ef  pop rax
00007fa22efdf1f0  add rsp, 0x08
00007fa22efdf1f4  jmp 0x00007FA22EFDC375
00007fa22efdf1f9  sub rsp, 0x08
00007fa22efdf1fd  push rax
00007fa22efdf1fe  push rcx
00007fa22efdf1ff  push rdx
00007fa22efdf200  push rdi
00007fa22efdf201  push rsi
00007fa22efdf202  push r8
00007fa22efdf204  push r9
00007fa22efdf206  push r10
00007fa22efdf208  push r11
00007fa22efdf20a  sub rsp, 0xF0
00007fa22efdf211  vmovaps [rsp], xmm0
00007fa22efdf216  vmovaps [rsp+0x10], xmm1
00007fa22efdf21c  vmovaps [rsp+0x20], xmm2
00007fa22efdf222  vmovaps [rsp+0x30], xmm3
00007fa22efdf228  vmovaps [rsp+0x40], xmm4
00007fa22efdf22e  vmovaps [rsp+0x50], xmm5
00007fa22efdf234  vmovaps [rsp+0x60], xmm6
00007fa22efdf23a  vmovaps [rsp+0x70], xmm7
00007fa22efdf240  vmovaps [rsp+0x80], xmm8
00007fa22efdf249  vmovaps [rsp+0x90], xmm9
00007fa22efdf252  vmovaps [rsp+0xA0], xmm10
00007fa22efdf25b  vmovaps [rsp+0xB0], xmm11
00007fa22efdf264  vmovaps [rsp+0xC0], xmm12
00007fa22efdf26d  vmovaps [rsp+0xD0], xmm13
00007fa22efdf276  vmovaps [rsp+0xE0], xmm14
00007fa22efdf27f  sub rsp, 0x30
00007fa22efdf283  movaps [rsp], xmm15
00007fa22efdf288  movaps [rsp+0x10], xmm5
00007fa22efdf28d  movaps [rsp+0x20], xmm3
00007fa22efdf292  lea rdi, [rsp]
00007fa22efdf296  mov esi, 0x00
00007fa22efdf29b  mov rax, 0x5E9D1A57D530
00007fa22efdf2a5  call rax
00007fa22efdf2a7  movaps xmm15, [rsp]
00007fa22efdf2ac  add rsp, 0x30
00007fa22efdf2b0  vmovaps xmm0, [rsp]
00007fa22efdf2b5  vmovaps xmm1, [rsp+0x10]
00007fa22efdf2bb  vmovaps xmm2, [rsp+0x20]
00007fa22efdf2c1  vmovaps xmm3, [rsp+0x30]
00007fa22efdf2c7  vmovaps xmm4, [rsp+0x40]
00007fa22efdf2cd  vmovaps xmm5, [rsp+0x50]
00007fa22efdf2d3  vmovaps xmm6, [rsp+0x60]
00007fa22efdf2d9  vmovaps xmm7, [rsp+0x70]
00007fa22efdf2df  vmovaps xmm8, [rsp+0x80]
00007fa22efdf2e8  vmovaps xmm9, [rsp+0x90]
00007fa22efdf2f1  vmovaps xmm10, [rsp+0xA0]
00007fa22efdf2fa  vmovaps xmm11, [rsp+0xB0]
00007fa22efdf303  vmovaps xmm12, [rsp+0xC0]
00007fa22efdf30c  vmovaps xmm13, [rsp+0xD0]
00007fa22efdf315  vmovaps xmm14, [rsp+0xE0]
00007fa22efdf31e  add rsp, 0xF0
00007fa22efdf325  pop r11
00007fa22efdf327  pop r10
00007fa22efdf329  pop r9
00007fa22efdf32b  pop r8
00007fa22efdf32d  pop rsi
00007fa22efdf32e  pop rdi
00007fa22efdf32f  pop rdx
00007fa22efdf330  pop rcx
00007fa22efdf331  pop rax
00007fa22efdf332  add rsp, 0x08
00007fa22efdf336  jmp 0x00007FA22EFDC38F
00007fa22efdf33b  sub rsp, 0x08
00007fa22efdf33f  push rax
00007fa22efdf340  push rcx
00007fa22efdf341  push rdx
00007fa22efdf342  push rdi
00007fa22efdf343  push rsi
00007fa22efdf344  push r8
00007fa22efdf346  push r9
00007fa22efdf348  push r10
00007fa22efdf34a  push r11
00007fa22efdf34c  sub rsp, 0xF0
00007fa22efdf353  vmovaps [rsp], xmm0
00007fa22efdf358  vmovaps [rsp+0x10], xmm1
00007fa22efdf35e  vmovaps [rsp+0x20], xmm2
00007fa22efdf364  vmovaps [rsp+0x30], xmm3
00007fa22efdf36a  vmovaps [rsp+0x40], xmm4
00007fa22efdf370  vmovaps [rsp+0x50], xmm6
00007fa22efdf376  vmovaps [rsp+0x60], xmm7
00007fa22efdf37c  vmovaps [rsp+0x70], xmm8
00007fa22efdf382  vmovaps [rsp+0x80], xmm9
00007fa22efdf38b  vmovaps [rsp+0x90], xmm10
00007fa22efdf394  vmovaps [rsp+0xA0], xmm11
00007fa22efdf39d  vmovaps [rsp+0xB0], xmm12
00007fa22efdf3a6  vmovaps [rsp+0xC0], xmm13
00007fa22efdf3af  vmovaps [rsp+0xD0], xmm14
00007fa22efdf3b8  vmovaps [rsp+0xE0], xmm15
00007fa22efdf3c1  sub rsp, 0x30
00007fa22efdf3c5  movaps [rsp], xmm5
00007fa22efdf3c9  movaps [rsp+0x10], xmm8
00007fa22efdf3cf  movaps [rsp+0x20], xmm6
00007fa22efdf3d4  lea rdi, [rsp]
00007fa22efdf3d8  mov esi, 0x00
00007fa22efdf3dd  mov rax, 0x5E9D1A57D530
00007fa22efdf3e7  call rax
00007fa22efdf3e9  movaps xmm5, [rsp]
00007fa22efdf3ed  add rsp, 0x30
00007fa22efdf3f1  vmovaps xmm0, [rsp]
00007fa22efdf3f6  vmovaps xmm1, [rsp+0x10]
00007fa22efdf3fc  vmovaps xmm2, [rsp+0x20]
00007fa22efdf402  vmovaps xmm3, [rsp+0x30]
00007fa22efdf408  vmovaps xmm4, [rsp+0x40]
00007fa22efdf40e  vmovaps xmm6, [rsp+0x50]
00007fa22efdf414  vmovaps xmm7, [rsp+0x60]
00007fa22efdf41a  vmovaps xmm8, [rsp+0x70]
00007fa22efdf420  vmovaps xmm9, [rsp+0x80]
00007fa22efdf429  vmovaps xmm10, [rsp+0x90]
00007fa22efdf432  vmovaps xmm11, [rsp+0xA0]
00007fa22efdf43b  vmovaps xmm12, [rsp+0xB0]
00007fa22efdf444  vmovaps xmm13, [rsp+0xC0]
00007fa22efdf44d  vmovaps xmm14, [rsp+0xD0]
00007fa22efdf456  vmovaps xmm15, [rsp+0xE0]
00007fa22efdf45f  add rsp, 0xF0
00007fa22efdf466  pop r11
00007fa22efdf468  pop r10
00007fa22efdf46a  pop r9
00007fa22efdf46c  pop r8
00007fa22efdf46e  pop rsi
00007fa22efdf46f  pop rdi
00007fa22efdf470  pop rdx
00007fa22efdf471  pop rcx
00007fa22efdf472  pop rax
00007fa22efdf473  add rsp, 0x08
00007fa22efdf477  jmp 0x00007FA22EFDC3B3
00007fa22efdf47c  sub rsp, 0x08
00007fa22efdf480  push rax
00007fa22efdf481  push rcx
00007fa22efdf482  push rdx
00007fa22efdf483  push rdi
00007fa22efdf484  push rsi
00007fa22efdf485  push r8
00007fa22efdf487  push r9
00007fa22efdf489  push r10
00007fa22efdf48b  push r11
00007fa22efdf48d  sub rsp, 0xF0
00007fa22efdf494  vmovaps [rsp], xmm0
00007fa22efdf499  vmovaps [rsp+0x10], xmm1
00007fa22efdf49f  vmovaps [rsp+0x20], xmm2
00007fa22efdf4a5  vmovaps [rsp+0x30], xmm3
00007fa22efdf4ab  vmovaps [rsp+0x40], xmm4
00007fa22efdf4b1  vmovaps [rsp+0x50], xmm5
00007fa22efdf4b7  vmovaps [rsp+0x60], xmm7
00007fa22efdf4bd  vmovaps [rsp+0x70], xmm8
00007fa22efdf4c3  vmovaps [rsp+0x80], xmm9
00007fa22efdf4cc  vmovaps [rsp+0x90], xmm10
00007fa22efdf4d5  vmovaps [rsp+0xA0], xmm11
00007fa22efdf4de  vmovaps [rsp+0xB0], xmm12
00007fa22efdf4e7  vmovaps [rsp+0xC0], xmm13
00007fa22efdf4f0  vmovaps [rsp+0xD0], xmm14
00007fa22efdf4f9  vmovaps [rsp+0xE0], xmm15
00007fa22efdf502  sub rsp, 0x30
00007fa22efdf506  movaps [rsp], xmm6
00007fa22efdf50a  movaps [rsp+0x10], xmm10
00007fa22efdf510  movaps [rsp+0x20], xmm8
00007fa22efdf516  lea rdi, [rsp]
00007fa22efdf51a  mov esi, 0x00
00007fa22efdf51f  mov rax, 0x5E9D1A57D530
00007fa22efdf529  call rax
00007fa22efdf52b  movaps xmm6, [rsp]
00007fa22efdf52f  add rsp, 0x30
00007fa22efdf533  vmovaps xmm0, [rsp]
00007fa22efdf538  vmovaps xmm1, [rsp+0x10]
00007fa22efdf53e  vmovaps xmm2, [rsp+0x20]
00007fa22efdf544  vmovaps xmm3, [rsp+0x30]
00007fa22efdf54a  vmovaps xmm4, [rsp+0x40]
00007fa22efdf550  vmovaps xmm5, [rsp+0x50]
00007fa22efdf556  vmovaps xmm7, [rsp+0x60]
00007fa22efdf55c  vmovaps xmm8, [rsp+0x70]
00007fa22efdf562  vmovaps xmm9, [rsp+0x80]
00007fa22efdf56b  vmovaps xmm10, [rsp+0x90]
00007fa22efdf574  vmovaps xmm11, [rsp+0xA0]
00007fa22efdf57d  vmovaps xmm12, [rsp+0xB0]
00007fa22efdf586  vmovaps xmm13, [rsp+0xC0]
00007fa22efdf58f  vmovaps xmm14, [rsp+0xD0]
00007fa22efdf598  vmovaps xmm15, [rsp+0xE0]
00007fa22efdf5a1  add rsp, 0xF0
00007fa22efdf5a8  pop r11
00007fa22efdf5aa  pop r10
00007fa22efdf5ac  pop r9
00007fa22efdf5ae  pop r8
00007fa22efdf5b0  pop rsi
00007fa22efdf5b1  pop rdi
00007fa22efdf5b2  pop rdx
00007fa22efdf5b3  pop rcx
00007fa22efdf5b4  pop rax
00007fa22efdf5b5  add rsp, 0x08
00007fa22efdf5b9  jmp 0x00007FA22EFDC3D8
00007fa22efdf5be  sub rsp, 0x08
00007fa22efdf5c2  push rax
00007fa22efdf5c3  push rcx
00007fa22efdf5c4  push rdx
00007fa22efdf5c5  push rdi
00007fa22efdf5c6  push rsi
00007fa22efdf5c7  push r8
00007fa22efdf5c9  push r9
00007fa22efdf5cb  push r10
00007fa22efdf5cd  push r11
00007fa22efdf5cf  sub rsp, 0xF0
00007fa22efdf5d6  vmovaps [rsp], xmm0
00007fa22efdf5db  vmovaps [rsp+0x10], xmm1
00007fa22efdf5e1  vmovaps [rsp+0x20], xmm2
00007fa22efdf5e7  vmovaps [rsp+0x30], xmm3
00007fa22efdf5ed  vmovaps [rsp+0x40], xmm4
00007fa22efdf5f3  vmovaps [rsp+0x50], xmm5
00007fa22efdf5f9  vmovaps [rsp+0x60], xmm6
00007fa22efdf5ff  vmovaps [rsp+0x70], xmm7
00007fa22efdf605  vmovaps [rsp+0x80], xmm8
00007fa22efdf60e  vmovaps [rsp+0x90], xmm9
00007fa22efdf617  vmovaps [rsp+0xA0], xmm11
00007fa22efdf620  vmovaps [rsp+0xB0], xmm12
00007fa22efdf629  vmovaps [rsp+0xC0], xmm13
00007fa22efdf632  vmovaps [rsp+0xD0], xmm14
00007fa22efdf63b  vmovaps [rsp+0xE0], xmm15
00007fa22efdf644  sub rsp, 0x30
00007fa22efdf648  movaps [rsp], xmm10
00007fa22efdf64d  movaps [rsp+0x10], xmm8
00007fa22efdf653  movaps [rsp+0x20], xmm14
00007fa22efdf659  lea rdi, [rsp]
00007fa22efdf65d  mov esi, 0x00
00007fa22efdf662  mov rax, 0x5E9D1A57D530
00007fa22efdf66c  call rax
00007fa22efdf66e  movaps xmm10, [rsp]
00007fa22efdf673  add rsp, 0x30
00007fa22efdf677  vmovaps xmm0, [rsp]
00007fa22efdf67c  vmovaps xmm1, [rsp+0x10]
00007fa22efdf682  vmovaps xmm2, [rsp+0x20]
00007fa22efdf688  vmovaps xmm3, [rsp+0x30]
00007fa22efdf68e  vmovaps xmm4, [rsp+0x40]
00007fa22efdf694  vmovaps xmm5, [rsp+0x50]
00007fa22efdf69a  vmovaps xmm6, [rsp+0x60]
00007fa22efdf6a0  vmovaps xmm7, [rsp+0x70]
00007fa22efdf6a6  vmovaps xmm8, [rsp+0x80]
00007fa22efdf6af  vmovaps xmm9, [rsp+0x90]
00007fa22efdf6b8  vmovaps xmm11, [rsp+0xA0]
00007fa22efdf6c1  vmovaps xmm12, [rsp+0xB0]
00007fa22efdf6ca  vmovaps xmm13, [rsp+0xC0]
00007fa22efdf6d3  vmovaps xmm14, [rsp+0xD0]
00007fa22efdf6dc  vmovaps xmm15, [rsp+0xE0]
00007fa22efdf6e5  add rsp, 0xF0
00007fa22efdf6ec  pop r11
00007fa22efdf6ee  pop r10
00007fa22efdf6f0  pop r9
00007fa22efdf6f2  pop r8
00007fa22efdf6f4  pop rsi
00007fa22efdf6f5  pop rdi
00007fa22efdf6f6  pop rdx
00007fa22efdf6f7  pop rcx
00007fa22efdf6f8  pop rax
00007fa22efdf6f9  add rsp, 0x08
00007fa22efdf6fd  jmp 0x00007FA22EFDC3F8
00007fa22efdf702  sub rsp, 0x08
00007fa22efdf706  push rax
00007fa22efdf707  push rcx
00007fa22efdf708  push rdx
00007fa22efdf709  push rdi
00007fa22efdf70a  push rsi
00007fa22efdf70b  push r8
00007fa22efdf70d  push r9
00007fa22efdf70f  push r10
00007fa22efdf711  push r11
00007fa22efdf713  sub rsp, 0xF0
00007fa22efdf71a  vmovaps [rsp], xmm0
00007fa22efdf71f  vmovaps [rsp+0x10], xmm1
00007fa22efdf725  vmovaps [rsp+0x20], xmm2
00007fa22efdf72b  vmovaps [rsp+0x30], xmm3
00007fa22efdf731  vmovaps [rsp+0x40], xmm4
00007fa22efdf737  vmovaps [rsp+0x50], xmm5
00007fa22efdf73d  vmovaps [rsp+0x60], xmm6
00007fa22efdf743  vmovaps [rsp+0x70], xmm7
00007fa22efdf749  vmovaps [rsp+0x80], xmm8
00007fa22efdf752  vmovaps [rsp+0x90], xmm9
00007fa22efdf75b  vmovaps [rsp+0xA0], xmm10
00007fa22efdf764  vmovaps [rsp+0xB0], xmm11
00007fa22efdf76d  vmovaps [rsp+0xC0], xmm12
00007fa22efdf776  vmovaps [rsp+0xD0], xmm13
00007fa22efdf77f  vmovaps [rsp+0xE0], xmm15
00007fa22efdf788  sub rsp, 0x30
00007fa22efdf78c  movaps [rsp], xmm14
00007fa22efdf791  movaps [rsp+0x10], xmm8
00007fa22efdf797  movaps [rsp+0x20], xmm4
00007fa22efdf79c  lea rdi, [rsp]
00007fa22efdf7a0  mov esi, 0x00
00007fa22efdf7a5  mov rax, 0x5E9D1A57D530
00007fa22efdf7af  call rax
00007fa22efdf7b1  movaps xmm14, [rsp]
00007fa22efdf7b6  add rsp, 0x30
00007fa22efdf7ba  vmovaps xmm0, [rsp]
00007fa22efdf7bf  vmovaps xmm1, [rsp+0x10]
00007fa22efdf7c5  vmovaps xmm2, [rsp+0x20]
00007fa22efdf7cb  vmovaps xmm3, [rsp+0x30]
00007fa22efdf7d1  vmovaps xmm4, [rsp+0x40]
00007fa22efdf7d7  vmovaps xmm5, [rsp+0x50]
00007fa22efdf7dd  vmovaps xmm6, [rsp+0x60]
00007fa22efdf7e3  vmovaps xmm7, [rsp+0x70]
00007fa22efdf7e9  vmovaps xmm8, [rsp+0x80]
00007fa22efdf7f2  vmovaps xmm9, [rsp+0x90]
00007fa22efdf7fb  vmovaps xmm10, [rsp+0xA0]
00007fa22efdf804  vmovaps xmm11, [rsp+0xB0]
00007fa22efdf80d  vmovaps xmm12, [rsp+0xC0]
00007fa22efdf816  vmovaps xmm13, [rsp+0xD0]
00007fa22efdf81f  vmovaps xmm15, [rsp+0xE0]
00007fa22efdf828  add rsp, 0xF0
00007fa22efdf82f  pop r11
00007fa22efdf831  pop r10
00007fa22efdf833  pop r9
00007fa22efdf835  pop r8
00007fa22efdf837  pop rsi
00007fa22efdf838  pop rdi
00007fa22efdf839  pop rdx
00007fa22efdf83a  pop rcx
00007fa22efdf83b  pop rax
00007fa22efdf83c  add rsp, 0x08
00007fa22efdf840  jmp 0x00007FA22EFDC418
00007fa22efdf845  sub rsp, 0x08
00007fa22efdf849  push rax
00007fa22efdf84a  push rcx
00007fa22efdf84b  push rdx
00007fa22efdf84c  push rdi
00007fa22efdf84d  push rsi
00007fa22efdf84e  push r8
00007fa22efdf850  push r9
00007fa22efdf852  push r10
00007fa22efdf854  push r11
00007fa22efdf856  sub rsp, 0xF0
00007fa22efdf85d  vmovaps [rsp], xmm0
00007fa22efdf862  vmovaps [rsp+0x10], xmm1
00007fa22efdf868  vmovaps [rsp+0x20], xmm2
00007fa22efdf86e  vmovaps [rsp+0x30], xmm3
00007fa22efdf874  vmovaps [rsp+0x40], xmm5
00007fa22efdf87a  vmovaps [rsp+0x50], xmm6
00007fa22efdf880  vmovaps [rsp+0x60], xmm7
00007fa22efdf886  vmovaps [rsp+0x70], xmm8
00007fa22efdf88c  vmovaps [rsp+0x80], xmm9
00007fa22efdf895  vmovaps [rsp+0x90], xmm10
00007fa22efdf89e  vmovaps [rsp+0xA0], xmm11
00007fa22efdf8a7  vmovaps [rsp+0xB0], xmm12
00007fa22efdf8b0  vmovaps [rsp+0xC0], xmm13
00007fa22efdf8b9  vmovaps [rsp+0xD0], xmm14
00007fa22efdf8c2  vmovaps [rsp+0xE0], xmm15
00007fa22efdf8cb  sub rsp, 0x30
00007fa22efdf8cf  movaps [rsp], xmm4
00007fa22efdf8d3  movaps [rsp+0x10], xmm13
00007fa22efdf8d9  movaps [rsp+0x20], xmm8
00007fa22efdf8df  lea rdi, [rsp]
00007fa22efdf8e3  mov esi, 0x00
00007fa22efdf8e8  mov rax, 0x5E9D1A57D530
00007fa22efdf8f2  call rax
00007fa22efdf8f4  movaps xmm4, [rsp]
00007fa22efdf8f8  add rsp, 0x30
00007fa22efdf8fc  vmovaps xmm0, [rsp]
00007fa22efdf901  vmovaps xmm1, [rsp+0x10]
00007fa22efdf907  vmovaps xmm2, [rsp+0x20]
00007fa22efdf90d  vmovaps xmm3, [rsp+0x30]
00007fa22efdf913  vmovaps xmm5, [rsp+0x40]
00007fa22efdf919  vmovaps xmm6, [rsp+0x50]
00007fa22efdf91f  vmovaps xmm7, [rsp+0x60]
00007fa22efdf925  vmovaps xmm8, [rsp+0x70]
00007fa22efdf92b  vmovaps xmm9, [rsp+0x80]
00007fa22efdf934  vmovaps xmm10, [rsp+0x90]
00007fa22efdf93d  vmovaps xmm11, [rsp+0xA0]
00007fa22efdf946  vmovaps xmm12, [rsp+0xB0]
00007fa22efdf94f  vmovaps xmm13, [rsp+0xC0]
00007fa22efdf958  vmovaps xmm14, [rsp+0xD0]
00007fa22efdf961  vmovaps xmm15, [rsp+0xE0]
00007fa22efdf96a  add rsp, 0xF0
00007fa22efdf971  pop r11
00007fa22efdf973  pop r10
00007fa22efdf975  pop r9
00007fa22efdf977  pop r8
00007fa22efdf979  pop rsi
00007fa22efdf97a  pop rdi
00007fa22efdf97b  pop rdx
00007fa22efdf97c  pop rcx
00007fa22efdf97d  pop rax
00007fa22efdf97e  add rsp, 0x08
00007fa22efdf982  jmp 0x00007FA22EFDC43D
00007fa22efdf987  sub rsp, 0x08
00007fa22efdf98b  push rax
00007fa22efdf98c  push rcx
00007fa22efdf98d  push rdx
00007fa22efdf98e  push rdi
00007fa22efdf98f  push rsi
00007fa22efdf990  push r8
00007fa22efdf992  push r9
00007fa22efdf994  push r10
00007fa22efdf996  push r11
00007fa22efdf998  sub rsp, 0xF0
00007fa22efdf99f  vmovaps [rsp], xmm0
00007fa22efdf9a4  vmovaps [rsp+0x10], xmm1
00007fa22efdf9aa  vmovaps [rsp+0x20], xmm2
00007fa22efdf9b0  vmovaps [rsp+0x30], xmm3
00007fa22efdf9b6  vmovaps [rsp+0x40], xmm4
00007fa22efdf9bc  vmovaps [rsp+0x50], xmm5
00007fa22efdf9c2  vmovaps [rsp+0x60], xmm6
00007fa22efdf9c8  vmovaps [rsp+0x70], xmm7
00007fa22efdf9ce  vmovaps [rsp+0x80], xmm8
00007fa22efdf9d7  vmovaps [rsp+0x90], xmm9
00007fa22efdf9e0  vmovaps [rsp+0xA0], xmm10
00007fa22efdf9e9  vmovaps [rsp+0xB0], xmm11
00007fa22efdf9f2  vmovaps [rsp+0xC0], xmm12
00007fa22efdf9fb  vmovaps [rsp+0xD0], xmm14
00007fa22efdfa04  vmovaps [rsp+0xE0], xmm15
00007fa22efdfa0d  sub rsp, 0x30
00007fa22efdfa11  movaps [rsp], xmm13
00007fa22efdfa16  movaps [rsp+0x10], xmm15
00007fa22efdfa1c  movaps [rsp+0x20], xmm9
00007fa22efdfa22  lea rdi, [rsp]
00007fa22efdfa26  mov esi, 0x00
00007fa22efdfa2b  mov rax, 0x5E9D1A57D530
00007fa22efdfa35  call rax
00007fa22efdfa37  movaps xmm13, [rsp]
00007fa22efdfa3c  add rsp, 0x30
00007fa22efdfa40  vmovaps xmm0, [rsp]
00007fa22efdfa45  vmovaps xmm1, [rsp+0x10]
00007fa22efdfa4b  vmovaps xmm2, [rsp+0x20]
00007fa22efdfa51  vmovaps xmm3, [rsp+0x30]
00007fa22efdfa57  vmovaps xmm4, [rsp+0x40]
00007fa22efdfa5d  vmovaps xmm5, [rsp+0x50]
00007fa22efdfa63  vmovaps xmm6, [rsp+0x60]
00007fa22efdfa69  vmovaps xmm7, [rsp+0x70]
00007fa22efdfa6f  vmovaps xmm8, [rsp+0x80]
00007fa22efdfa78  vmovaps xmm9, [rsp+0x90]
00007fa22efdfa81  vmovaps xmm10, [rsp+0xA0]
00007fa22efdfa8a  vmovaps xmm11, [rsp+0xB0]
00007fa22efdfa93  vmovaps xmm12, [rsp+0xC0]
00007fa22efdfa9c  vmovaps xmm14, [rsp+0xD0]
00007fa22efdfaa5  vmovaps xmm15, [rsp+0xE0]
00007fa22efdfaae  add rsp, 0xF0
00007fa22efdfab5  pop r11
00007fa22efdfab7  pop r10
00007fa22efdfab9  pop r9
00007fa22efdfabb  pop r8
00007fa22efdfabd  pop rsi
00007fa22efdfabe  pop rdi
00007fa22efdfabf  pop rdx
00007fa22efdfac0  pop rcx
00007fa22efdfac1  pop rax
00007fa22efdfac2  add rsp, 0x08
00007fa22efdfac6  jmp 0x00007FA22EFDC458
00007fa22efdfacb  sub rsp, 0x08
00007fa22efdfacf  push rax
00007fa22efdfad0  push rcx
00007fa22efdfad1  push rdx
00007fa22efdfad2  push rdi
00007fa22efdfad3  push rsi
00007fa22efdfad4  push r8
00007fa22efdfad6  push r9
00007fa22efdfad8  push r10
00007fa22efdfada  push r11
00007fa22efdfadc  sub rsp, 0xF0
00007fa22efdfae3  vmovaps [rsp], xmm0
00007fa22efdfae8  vmovaps [rsp+0x10], xmm1
00007fa22efdfaee  vmovaps [rsp+0x20], xmm2
00007fa22efdfaf4  vmovaps [rsp+0x30], xmm3
00007fa22efdfafa  vmovaps [rsp+0x40], xmm4
00007fa22efdfb00  vmovaps [rsp+0x50], xmm5
00007fa22efdfb06  vmovaps [rsp+0x60], xmm6
00007fa22efdfb0c  vmovaps [rsp+0x70], xmm7
00007fa22efdfb12  vmovaps [rsp+0x80], xmm8
00007fa22efdfb1b  vmovaps [rsp+0x90], xmm9
00007fa22efdfb24  vmovaps [rsp+0xA0], xmm10
00007fa22efdfb2d  vmovaps [rsp+0xB0], xmm11
00007fa22efdfb36  vmovaps [rsp+0xC0], xmm12
00007fa22efdfb3f  vmovaps [rsp+0xD0], xmm13
00007fa22efdfb48  vmovaps [rsp+0xE0], xmm14
00007fa22efdfb51  sub rsp, 0x30
00007fa22efdfb55  movaps [rsp], xmm15
00007fa22efdfb5a  movaps [rsp+0x10], xmm1
00007fa22efdfb5f  movaps [rsp+0x20], xmm5
00007fa22efdfb64  lea rdi, [rsp]
00007fa22efdfb68  mov esi, 0x00
00007fa22efdfb6d  mov rax, 0x5E9D1A57D530
00007fa22efdfb77  call rax
00007fa22efdfb79  movaps xmm15, [rsp]
00007fa22efdfb7e  add rsp, 0x30
00007fa22efdfb82  vmovaps xmm0, [rsp]
00007fa22efdfb87  vmovaps xmm1, [rsp+0x10]
00007fa22efdfb8d  vmovaps xmm2, [rsp+0x20]
00007fa22efdfb93  vmovaps xmm3, [rsp+0x30]
00007fa22efdfb99  vmovaps xmm4, [rsp+0x40]
00007fa22efdfb9f  vmovaps xmm5, [rsp+0x50]
00007fa22efdfba5  vmovaps xmm6, [rsp+0x60]
00007fa22efdfbab  vmovaps xmm7, [rsp+0x70]
00007fa22efdfbb1  vmovaps xmm8, [rsp+0x80]
00007fa22efdfbba  vmovaps xmm9, [rsp+0x90]
00007fa22efdfbc3  vmovaps xmm10, [rsp+0xA0]
00007fa22efdfbcc  vmovaps xmm11, [rsp+0xB0]
00007fa22efdfbd5  vmovaps xmm12, [rsp+0xC0]
00007fa22efdfbde  vmovaps xmm13, [rsp+0xD0]
00007fa22efdfbe7  vmovaps xmm14, [rsp+0xE0]
00007fa22efdfbf0  add rsp, 0xF0
00007fa22efdfbf7  pop r11
00007fa22efdfbf9  pop r10
00007fa22efdfbfb  pop r9
00007fa22efdfbfd  pop r8
00007fa22efdfbff  pop rsi
00007fa22efdfc00  pop rdi
00007fa22efdfc01  pop rdx
00007fa22efdfc02  pop rcx
00007fa22efdfc03  pop rax
00007fa22efdfc04  add rsp, 0x08
00007fa22efdfc08  jmp 0x00007FA22EFDC473
00007fa22efdfc0d  call 0x00007FA22EEB52F0
00007fa22efdfc12  jmp 0x00007FA22EFDC4CE
00007fa22efdfc17  sub rsp, 0x08
00007fa22efdfc1b  push rax
00007fa22efdfc1c  push rcx
00007fa22efdfc1d  push rdx
00007fa22efdfc1e  push rdi
00007fa22efdfc1f  push rsi
00007fa22efdfc20  push r8
00007fa22efdfc22  push r9
00007fa22efdfc24  push r10
00007fa22efdfc26  push r11
00007fa22efdfc28  sub rsp, 0xF0
00007fa22efdfc2f  vmovaps [rsp], xmm0
00007fa22efdfc34  vmovaps [rsp+0x10], xmm1
00007fa22efdfc3a  vmovaps [rsp+0x20], xmm2
00007fa22efdfc40  vmovaps [rsp+0x30], xmm3
00007fa22efdfc46  vmovaps [rsp+0x40], xmm4
00007fa22efdfc4c  vmovaps [rsp+0x50], xmm5
00007fa22efdfc52  vmovaps [rsp+0x60], xmm6
00007fa22efdfc58  vmovaps [rsp+0x70], xmm7
00007fa22efdfc5e  vmovaps [rsp+0x80], xmm8
00007fa22efdfc67  vmovaps [rsp+0x90], xmm10
00007fa22efdfc70  vmovaps [rsp+0xA0], xmm11
00007fa22efdfc79  vmovaps [rsp+0xB0], xmm12
00007fa22efdfc82  vmovaps [rsp+0xC0], xmm13
00007fa22efdfc8b  vmovaps [rsp+0xD0], xmm14
00007fa22efdfc94  vmovaps [rsp+0xE0], xmm15
00007fa22efdfc9d  sub rsp, 0x30
00007fa22efdfca1  movaps [rsp], xmm9
00007fa22efdfca6  movaps [rsp+0x10], xmm8
00007fa22efdfcac  movaps [rsp+0x20], xmm11
00007fa22efdfcb2  lea rdi, [rsp]
00007fa22efdfcb6  mov esi, 0x00
00007fa22efdfcbb  mov rax, 0x5E9D1A57D530
00007fa22efdfcc5  call rax
00007fa22efdfcc7  movaps xmm9, [rsp]
00007fa22efdfccc  add rsp, 0x30
00007fa22efdfcd0  vmovaps xmm0, [rsp]
00007fa22efdfcd5  vmovaps xmm1, [rsp+0x10]
00007fa22efdfcdb  vmovaps xmm2, [rsp+0x20]
00007fa22efdfce1  vmovaps xmm3, [rsp+0x30]
00007fa22efdfce7  vmovaps xmm4, [rsp+0x40]
00007fa22efdfced  vmovaps xmm5, [rsp+0x50]
00007fa22efdfcf3  vmovaps xmm6, [rsp+0x60]
00007fa22efdfcf9  vmovaps xmm7, [rsp+0x70]
00007fa22efdfcff  vmovaps xmm8, [rsp+0x80]
00007fa22efdfd08  vmovaps xmm10, [rsp+0x90]
00007fa22efdfd11  vmovaps xmm11, [rsp+0xA0]
00007fa22efdfd1a  vmovaps xmm12, [rsp+0xB0]
00007fa22efdfd23  vmovaps xmm13, [rsp+0xC0]
00007fa22efdfd2c  vmovaps xmm14, [rsp+0xD0]
00007fa22efdfd35  vmovaps xmm15, [rsp+0xE0]
00007fa22efdfd3e  add rsp, 0xF0
00007fa22efdfd45  pop r11
00007fa22efdfd47  pop r10
00007fa22efdfd49  pop r9
00007fa22efdfd4b  pop r8
00007fa22efdfd4d  pop rsi
00007fa22efdfd4e  pop rdi
00007fa22efdfd4f  pop rdx
00007fa22efdfd50  pop rcx
00007fa22efdfd51  pop rax
00007fa22efdfd52  add rsp, 0x08
00007fa22efdfd56  jmp 0x00007FA22EFDC505
00007fa22efdfd5b  sub rsp, 0x08
00007fa22efdfd5f  push rax
00007fa22efdfd60  push rcx
00007fa22efdfd61  push rdx
00007fa22efdfd62  push rdi
00007fa22efdfd63  push rsi
00007fa22efdfd64  push r8
00007fa22efdfd66  push r9
00007fa22efdfd68  push r10
00007fa22efdfd6a  push r11
00007fa22efdfd6c  sub rsp, 0xF0
00007fa22efdfd73  vmovaps [rsp], xmm0
00007fa22efdfd78  vmovaps [rsp+0x10], xmm1
00007fa22efdfd7e  vmovaps [rsp+0x20], xmm2
00007fa22efdfd84  vmovaps [rsp+0x30], xmm3
00007fa22efdfd8a  vmovaps [rsp+0x40], xmm4
00007fa22efdfd90  vmovaps [rsp+0x50], xmm5
00007fa22efdfd96  vmovaps [rsp+0x60], xmm6
00007fa22efdfd9c  vmovaps [rsp+0x70], xmm7
00007fa22efdfda2  vmovaps [rsp+0x80], xmm8
00007fa22efdfdab  vmovaps [rsp+0x90], xmm9
00007fa22efdfdb4  vmovaps [rsp+0xA0], xmm10
00007fa22efdfdbd  vmovaps [rsp+0xB0], xmm12
00007fa22efdfdc6  vmovaps [rsp+0xC0], xmm13
00007fa22efdfdcf  vmovaps [rsp+0xD0], xmm14
00007fa22efdfdd8  vmovaps [rsp+0xE0], xmm15
00007fa22efdfde1  sub rsp, 0x30
00007fa22efdfde5  movaps [rsp], xmm11
00007fa22efdfdea  movaps [rsp+0x10], xmm10
00007fa22efdfdf0  movaps [rsp+0x20], xmm6
00007fa22efdfdf5  lea rdi, [rsp]
00007fa22efdfdf9  mov esi, 0x00
00007fa22efdfdfe  mov rax, 0x5E9D1A57D530
00007fa22efdfe08  call rax
00007fa22efdfe0a  movaps xmm11, [rsp]
00007fa22efdfe0f  add rsp, 0x30
00007fa22efdfe13  vmovaps xmm0, [rsp]
00007fa22efdfe18  vmovaps xmm1, [rsp+0x10]
00007fa22efdfe1e  vmovaps xmm2, [rsp+0x20]
00007fa22efdfe24  vmovaps xmm3, [rsp+0x30]
00007fa22efdfe2a  vmovaps xmm4, [rsp+0x40]
00007fa22efdfe30  vmovaps xmm5, [rsp+0x50]
00007fa22efdfe36  vmovaps xmm6, [rsp+0x60]
00007fa22efdfe3c  vmovaps xmm7, [rsp+0x70]
00007fa22efdfe42  vmovaps xmm8, [rsp+0x80]
00007fa22efdfe4b  vmovaps xmm9, [rsp+0x90]
00007fa22efdfe54  vmovaps xmm10, [rsp+0xA0]
00007fa22efdfe5d  vmovaps xmm12, [rsp+0xB0]
00007fa22efdfe66  vmovaps xmm13, [rsp+0xC0]
00007fa22efdfe6f  vmovaps xmm14, [rsp+0xD0]
00007fa22efdfe78  vmovaps xmm15, [rsp+0xE0]
00007fa22efdfe81  add rsp, 0xF0
00007fa22efdfe88  pop r11
00007fa22efdfe8a  pop r10
00007fa22efdfe8c  pop r9
00007fa22efdfe8e  pop r8
00007fa22efdfe90  pop rsi
00007fa22efdfe91  pop rdi
00007fa22efdfe92  pop rdx
00007fa22efdfe93  pop rcx
00007fa22efdfe94  pop rax
00007fa22efdfe95  add rsp, 0x08
00007fa22efdfe99  jmp 0x00007FA22EFDC520
00007fa22efdfe9e  sub rsp, 0x08
00007fa22efdfea2  push rax
00007fa22efdfea3  push rcx
00007fa22efdfea4  push rdx
00007fa22efdfea5  push rdi
00007fa22efdfea6  push rsi
00007fa22efdfea7  push r8
00007fa22efdfea9  push r9
00007fa22efdfeab  push r10
00007fa22efdfead  push r11
00007fa22efdfeaf  sub rsp, 0xF0
00007fa22efdfeb6  vmovaps [rsp], xmm0
00007fa22efdfebb  vmovaps [rsp+0x10], xmm1
00007fa22efdfec1  vmovaps [rsp+0x20], xmm2
00007fa22efdfec7  vmovaps [rsp+0x30], xmm3
00007fa22efdfecd  vmovaps [rsp+0x40], xmm4
00007fa22efdfed3  vmovaps [rsp+0x50], xmm5
00007fa22efdfed9  vmovaps [rsp+0x60], xmm6
00007fa22efdfedf  vmovaps [rsp+0x70], xmm7
00007fa22efdfee5  vmovaps [rsp+0x80], xmm8
00007fa22efdfeee  vmovaps [rsp+0x90], xmm9
00007fa22efdfef7  vmovaps [rsp+0xA0], xmm11
00007fa22efdff00  vmovaps [rsp+0xB0], xmm12
00007fa22efdff09  vmovaps [rsp+0xC0], xmm13
00007fa22efdff12  vmovaps [rsp+0xD0], xmm14
00007fa22efdff1b  vmovaps [rsp+0xE0], xmm15
00007fa22efdff24  sub rsp, 0x30
00007fa22efdff28  movaps [rsp], xmm10
00007fa22efdff2d  movaps [rsp+0x10], xmm14
00007fa22efdff33  movaps [rsp+0x20], xmm4
00007fa22efdff38  lea rdi, [rsp]
00007fa22efdff3c  mov esi, 0x00
00007fa22efdff41  mov rax, 0x5E9D1A57D530
00007fa22efdff4b  call rax
00007fa22efdff4d  movaps xmm10, [rsp]
00007fa22efdff52  add rsp, 0x30
00007fa22efdff56  vmovaps xmm0, [rsp]
00007fa22efdff5b  vmovaps xmm1, [rsp+0x10]
00007fa22efdff61  vmovaps xmm2, [rsp+0x20]
00007fa22efdff67  vmovaps xmm3, [rsp+0x30]
00007fa22efdff6d  vmovaps xmm4, [rsp+0x40]
00007fa22efdff73  vmovaps xmm5, [rsp+0x50]
00007fa22efdff79  vmovaps xmm6, [rsp+0x60]
00007fa22efdff7f  vmovaps xmm7, [rsp+0x70]
00007fa22efdff85  vmovaps xmm8, [rsp+0x80]
00007fa22efdff8e  vmovaps xmm9, [rsp+0x90]
00007fa22efdff97  vmovaps xmm11, [rsp+0xA0]
00007fa22efdffa0  vmovaps xmm12, [rsp+0xB0]
00007fa22efdffa9  vmovaps xmm13, [rsp+0xC0]
00007fa22efdffb2  vmovaps xmm14, [rsp+0xD0]
00007fa22efdffbb  vmovaps xmm15, [rsp+0xE0]
00007fa22efdffc4  add rsp, 0xF0
00007fa22efdffcb  pop r11
00007fa22efdffcd  pop r10
00007fa22efdffcf  pop r9
00007fa22efdffd1  pop r8
00007fa22efdffd3  pop rsi
00007fa22efdffd4  pop rdi
00007fa22efdffd5  pop rdx
00007fa22efdffd6  pop rcx
00007fa22efdffd7  pop rax
00007fa22efdffd8  add rsp, 0x08
00007fa22efdffdc  jmp 0x00007FA22EFDC53B
00007fa22efdffe1  sub rsp, 0x08
00007fa22efdffe5  push rax
00007fa22efdffe6  push rcx
00007fa22efdffe7  push rdx
00007fa22efdffe8  push rdi
00007fa22efdffe9  push rsi
00007fa22efdffea  push r8
00007fa22efdffec  push r9
00007fa22efdffee  push r10
00007fa22efdfff0  push r11
00007fa22efdfff2  sub rsp, 0xF0
00007fa22efdfff9  vmovaps [rsp], xmm0
00007fa22efdfffe  vmovaps [rsp+0x10], xmm1
00007fa22efe0004  vmovaps [rsp+0x20], xmm2
00007fa22efe000a  vmovaps [rsp+0x30], xmm3
00007fa22efe0010  vmovaps [rsp+0x40], xmm4
00007fa22efe0016  vmovaps [rsp+0x50], xmm5
00007fa22efe001c  vmovaps [rsp+0x60], xmm6
00007fa22efe0022  vmovaps [rsp+0x70], xmm7
00007fa22efe0028  vmovaps [rsp+0x80], xmm9
00007fa22efe0031  vmovaps [rsp+0x90], xmm10
00007fa22efe003a  vmovaps [rsp+0xA0], xmm11
00007fa22efe0043  vmovaps [rsp+0xB0], xmm12
00007fa22efe004c  vmovaps [rsp+0xC0], xmm13
00007fa22efe0055  vmovaps [rsp+0xD0], xmm14
00007fa22efe005e  vmovaps [rsp+0xE0], xmm15
00007fa22efe0067  sub rsp, 0x30
00007fa22efe006b  movaps [rsp], xmm8
00007fa22efe0070  movaps [rsp+0x10], xmm1
00007fa22efe0075  movaps [rsp+0x20], xmm14
00007fa22efe007b  lea rdi, [rsp]
00007fa22efe007f  mov esi, 0x00
00007fa22efe0084  mov rax, 0x5E9D1A57D530
00007fa22efe008e  call rax
00007fa22efe0090  movaps xmm8, [rsp]
00007fa22efe0095  add rsp, 0x30
00007fa22efe0099  vmovaps xmm0, [rsp]
00007fa22efe009e  vmovaps xmm1, [rsp+0x10]
00007fa22efe00a4  vmovaps xmm2, [rsp+0x20]
00007fa22efe00aa  vmovaps xmm3, [rsp+0x30]
00007fa22efe00b0  vmovaps xmm4, [rsp+0x40]
00007fa22efe00b6  vmovaps xmm5, [rsp+0x50]
00007fa22efe00bc  vmovaps xmm6, [rsp+0x60]
00007fa22efe00c2  vmovaps xmm7, [rsp+0x70]
00007fa22efe00c8  vmovaps xmm9, [rsp+0x80]
00007fa22efe00d1  vmovaps xmm10, [rsp+0x90]
00007fa22efe00da  vmovaps xmm11, [rsp+0xA0]
00007fa22efe00e3  vmovaps xmm12, [rsp+0xB0]
00007fa22efe00ec  vmovaps xmm13, [rsp+0xC0]
00007fa22efe00f5  vmovaps xmm14, [rsp+0xD0]
00007fa22efe00fe  vmovaps xmm15, [rsp+0xE0]
00007fa22efe0107  add rsp, 0xF0
00007fa22efe010e  pop r11
00007fa22efe0110  pop r10
00007fa22efe0112  pop r9
00007fa22efe0114  pop r8
00007fa22efe0116  pop rsi
00007fa22efe0117  pop rdi
00007fa22efe0118  pop rdx
00007fa22efe0119  pop rcx
00007fa22efe011a  pop rax
00007fa22efe011b  add rsp, 0x08
00007fa22efe011f  jmp 0x00007FA22EFDC561
00007fa22efe0124  sub rsp, 0x08
00007fa22efe0128  push rax
00007fa22efe0129  push rcx
00007fa22efe012a  push rdx
00007fa22efe012b  push rdi
00007fa22efe012c  push rsi
00007fa22efe012d  push r8
00007fa22efe012f  push r9
00007fa22efe0131  push r10
00007fa22efe0133  push r11
00007fa22efe0135  sub rsp, 0xF0
00007fa22efe013c  vmovaps [rsp], xmm0
00007fa22efe0141  vmovaps [rsp+0x10], xmm1
00007fa22efe0147  vmovaps [rsp+0x20], xmm2
00007fa22efe014d  vmovaps [rsp+0x30], xmm3
00007fa22efe0153  vmovaps [rsp+0x40], xmm4
00007fa22efe0159  vmovaps [rsp+0x50], xmm5
00007fa22efe015f  vmovaps [rsp+0x60], xmm7
00007fa22efe0165  vmovaps [rsp+0x70], xmm8
00007fa22efe016b  vmovaps [rsp+0x80], xmm9
00007fa22efe0174  vmovaps [rsp+0x90], xmm10
00007fa22efe017d  vmovaps [rsp+0xA0], xmm11
00007fa22efe0186  vmovaps [rsp+0xB0], xmm12
00007fa22efe018f  vmovaps [rsp+0xC0], xmm13
00007fa22efe0198  vmovaps [rsp+0xD0], xmm14
00007fa22efe01a1  vmovaps [rsp+0xE0], xmm15
00007fa22efe01aa  sub rsp, 0x30
00007fa22efe01ae  movaps [rsp], xmm6
00007fa22efe01b2  movaps [rsp+0x10], xmm1
00007fa22efe01b7  movaps [rsp+0x20], xmm14
00007fa22efe01bd  lea rdi, [rsp]
00007fa22efe01c1  mov esi, 0x00
00007fa22efe01c6  mov rax, 0x5E9D1A57D530
00007fa22efe01d0  call rax
00007fa22efe01d2  movaps xmm6, [rsp]
00007fa22efe01d6  add rsp, 0x30
00007fa22efe01da  vmovaps xmm0, [rsp]
00007fa22efe01df  vmovaps xmm1, [rsp+0x10]
00007fa22efe01e5  vmovaps xmm2, [rsp+0x20]
00007fa22efe01eb  vmovaps xmm3, [rsp+0x30]
00007fa22efe01f1  vmovaps xmm4, [rsp+0x40]
00007fa22efe01f7  vmovaps xmm5, [rsp+0x50]
00007fa22efe01fd  vmovaps xmm7, [rsp+0x60]
00007fa22efe0203  vmovaps xmm8, [rsp+0x70]
00007fa22efe0209  vmovaps xmm9, [rsp+0x80]
00007fa22efe0212  vmovaps xmm10, [rsp+0x90]
00007fa22efe021b  vmovaps xmm11, [rsp+0xA0]
00007fa22efe0224  vmovaps xmm12, [rsp+0xB0]
00007fa22efe022d  vmovaps xmm13, [rsp+0xC0]
00007fa22efe0236  vmovaps xmm14, [rsp+0xD0]
00007fa22efe023f  vmovaps xmm15, [rsp+0xE0]
00007fa22efe0248  add rsp, 0xF0
00007fa22efe024f  pop r11
00007fa22efe0251  pop r10
00007fa22efe0253  pop r9
00007fa22efe0255  pop r8
00007fa22efe0257  pop rsi
00007fa22efe0258  pop rdi
00007fa22efe0259  pop rdx
00007fa22efe025a  pop rcx
00007fa22efe025b  pop rax
00007fa22efe025c  add rsp, 0x08
00007fa22efe0260  jmp 0x00007FA22EFDC58D
00007fa22efe0265  sub rsp, 0x08
00007fa22efe0269  push rax
00007fa22efe026a  push rcx
00007fa22efe026b  push rdx
00007fa22efe026c  push rdi
00007fa22efe026d  push rsi
00007fa22efe026e  push r8
00007fa22efe0270  push r9
00007fa22efe0272  push r10
00007fa22efe0274  push r11
00007fa22efe0276  sub rsp, 0xF0
00007fa22efe027d  vmovaps [rsp], xmm0
00007fa22efe0282  vmovaps [rsp+0x10], xmm1
00007fa22efe0288  vmovaps [rsp+0x20], xmm2
00007fa22efe028e  vmovaps [rsp+0x30], xmm3
00007fa22efe0294  vmovaps [rsp+0x40], xmm4
00007fa22efe029a  vmovaps [rsp+0x50], xmm5
00007fa22efe02a0  vmovaps [rsp+0x60], xmm6
00007fa22efe02a6  vmovaps [rsp+0x70], xmm7
00007fa22efe02ac  vmovaps [rsp+0x80], xmm8
00007fa22efe02b5  vmovaps [rsp+0x90], xmm9
00007fa22efe02be  vmovaps [rsp+0xA0], xmm10
00007fa22efe02c7  vmovaps [rsp+0xB0], xmm11
00007fa22efe02d0  vmovaps [rsp+0xC0], xmm12
00007fa22efe02d9  vmovaps [rsp+0xD0], xmm13
00007fa22efe02e2  vmovaps [rsp+0xE0], xmm15
00007fa22efe02eb  sub rsp, 0x30
00007fa22efe02ef  movaps [rsp], xmm14
00007fa22efe02f4  movaps [rsp+0x10], xmm12
00007fa22efe02fa  movaps [rsp+0x20], xmm1
00007fa22efe02ff  lea rdi, [rsp]
00007fa22efe0303  mov esi, 0x00
00007fa22efe0308  mov rax, 0x5E9D1A57D530
00007fa22efe0312  call rax
00007fa22efe0314  movaps xmm14, [rsp]
00007fa22efe0319  add rsp, 0x30
00007fa22efe031d  vmovaps xmm0, [rsp]
00007fa22efe0322  vmovaps xmm1, [rsp+0x10]
00007fa22efe0328  vmovaps xmm2, [rsp+0x20]
00007fa22efe032e  vmovaps xmm3, [rsp+0x30]
00007fa22efe0334  vmovaps xmm4, [rsp+0x40]
00007fa22efe033a  vmovaps xmm5, [rsp+0x50]
00007fa22efe0340  vmovaps xmm6, [rsp+0x60]
00007fa22efe0346  vmovaps xmm7, [rsp+0x70]
00007fa22efe034c  vmovaps xmm8, [rsp+0x80]
00007fa22efe0355  vmovaps xmm9, [rsp+0x90]
00007fa22efe035e  vmovaps xmm10, [rsp+0xA0]
00007fa22efe0367  vmovaps xmm11, [rsp+0xB0]
00007fa22efe0370  vmovaps xmm12, [rsp+0xC0]
00007fa22efe0379  vmovaps xmm13, [rsp+0xD0]
00007fa22efe0382  vmovaps xmm15, [rsp+0xE0]
00007fa22efe038b  add rsp, 0xF0
00007fa22efe0392  pop r11
00007fa22efe0394  pop r10
00007fa22efe0396  pop r9
00007fa22efe0398  pop r8
00007fa22efe039a  pop rsi
00007fa22efe039b  pop rdi
00007fa22efe039c  pop rdx
00007fa22efe039d  pop rcx
00007fa22efe039e  pop rax
00007fa22efe039f  add rsp, 0x08
00007fa22efe03a3  jmp 0x00007FA22EFDC5B3
00007fa22efe03a8  sub rsp, 0x08
00007fa22efe03ac  push rax
00007fa22efe03ad  push rcx
00007fa22efe03ae  push rdx
00007fa22efe03af  push rdi
00007fa22efe03b0  push rsi
00007fa22efe03b1  push r8
00007fa22efe03b3  push r9
00007fa22efe03b5  push r10
00007fa22efe03b7  push r11
00007fa22efe03b9  sub rsp, 0xF0
00007fa22efe03c0  vmovaps [rsp], xmm0
00007fa22efe03c5  vmovaps [rsp+0x10], xmm2
00007fa22efe03cb  vmovaps [rsp+0x20], xmm3
00007fa22efe03d1  vmovaps [rsp+0x30], xmm4
00007fa22efe03d7  vmovaps [rsp+0x40], xmm5
00007fa22efe03dd  vmovaps [rsp+0x50], xmm6
00007fa22efe03e3  vmovaps [rsp+0x60], xmm7
00007fa22efe03e9  vmovaps [rsp+0x70], xmm8
00007fa22efe03ef  vmovaps [rsp+0x80], xmm9
00007fa22efe03f8  vmovaps [rsp+0x90], xmm10
00007fa22efe0401  vmovaps [rsp+0xA0], xmm11
00007fa22efe040a  vmovaps [rsp+0xB0], xmm12
00007fa22efe0413  vmovaps [rsp+0xC0], xmm13
00007fa22efe041c  vmovaps [rsp+0xD0], xmm14
00007fa22efe0425  vmovaps [rsp+0xE0], xmm15
00007fa22efe042e  sub rsp, 0x30
00007fa22efe0432  movaps [rsp], xmm1
00007fa22efe0436  movaps [rsp+0x10], xmm13
00007fa22efe043c  movaps [rsp+0x20], xmm9
00007fa22efe0442  lea rdi, [rsp]
00007fa22efe0446  mov esi, 0x00
00007fa22efe044b  mov rax, 0x5E9D1A57D530
00007fa22efe0455  call rax
00007fa22efe0457  movaps xmm1, [rsp]
00007fa22efe045b  add rsp, 0x30
00007fa22efe045f  vmovaps xmm0, [rsp]
00007fa22efe0464  vmovaps xmm2, [rsp+0x10]
00007fa22efe046a  vmovaps xmm3, [rsp+0x20]
00007fa22efe0470  vmovaps xmm4, [rsp+0x30]
00007fa22efe0476  vmovaps xmm5, [rsp+0x40]
00007fa22efe047c  vmovaps xmm6, [rsp+0x50]
00007fa22efe0482  vmovaps xmm7, [rsp+0x60]
00007fa22efe0488  vmovaps xmm8, [rsp+0x70]
00007fa22efe048e  vmovaps xmm9, [rsp+0x80]
00007fa22efe0497  vmovaps xmm10, [rsp+0x90]
00007fa22efe04a0  vmovaps xmm11, [rsp+0xA0]
00007fa22efe04a9  vmovaps xmm12, [rsp+0xB0]
00007fa22efe04b2  vmovaps xmm13, [rsp+0xC0]
00007fa22efe04bb  vmovaps xmm14, [rsp+0xD0]
00007fa22efe04c4  vmovaps xmm15, [rsp+0xE0]
00007fa22efe04cd  add rsp, 0xF0
00007fa22efe04d4  pop r11
00007fa22efe04d6  pop r10
00007fa22efe04d8  pop r9
00007fa22efe04da  pop r8
00007fa22efe04dc  pop rsi
00007fa22efe04dd  pop rdi
00007fa22efe04de  pop rdx
00007fa22efe04df  pop rcx
00007fa22efe04e0  pop rax
00007fa22efe04e1  add rsp, 0x08
00007fa22efe04e5  jmp 0x00007FA22EFDC5CD
00007fa22efe04ea  sub rsp, 0x08
00007fa22efe04ee  push rax
00007fa22efe04ef  push rcx
00007fa22efe04f0  push rdx
00007fa22efe04f1  push rdi
00007fa22efe04f2  push rsi
00007fa22efe04f3  push r8
00007fa22efe04f5  push r9
00007fa22efe04f7  push r10
00007fa22efe04f9  push r11
00007fa22efe04fb  sub rsp, 0xF0
00007fa22efe0502  vmovaps [rsp], xmm0
00007fa22efe0507  vmovaps [rsp+0x10], xmm1
00007fa22efe050d  vmovaps [rsp+0x20], xmm2
00007fa22efe0513  vmovaps [rsp+0x30], xmm3
00007fa22efe0519  vmovaps [rsp+0x40], xmm4
00007fa22efe051f  vmovaps [rsp+0x50], xmm5
00007fa22efe0525  vmovaps [rsp+0x60], xmm6
00007fa22efe052b  vmovaps [rsp+0x70], xmm7
00007fa22efe0531  vmovaps [rsp+0x80], xmm8
00007fa22efe053a  vmovaps [rsp+0x90], xmm9
00007fa22efe0543  vmovaps [rsp+0xA0], xmm10
00007fa22efe054c  vmovaps [rsp+0xB0], xmm11
00007fa22efe0555  vmovaps [rsp+0xC0], xmm13
00007fa22efe055e  vmovaps [rsp+0xD0], xmm14
00007fa22efe0567  vmovaps [rsp+0xE0], xmm15
00007fa22efe0570  sub rsp, 0x30
00007fa22efe0574  movaps [rsp], xmm12
00007fa22efe0579  movaps [rsp+0x10], xmm7
00007fa22efe057e  movaps [rsp+0x20], xmm13
00007fa22efe0584  lea rdi, [rsp]
00007fa22efe0588  mov esi, 0x00
00007fa22efe058d  mov rax, 0x5E9D1A57D530
00007fa22efe0597  call rax
00007fa22efe0599  movaps xmm12, [rsp]
00007fa22efe059e  add rsp, 0x30
00007fa22efe05a2  vmovaps xmm0, [rsp]
00007fa22efe05a7  vmovaps xmm1, [rsp+0x10]
00007fa22efe05ad  vmovaps xmm2, [rsp+0x20]
00007fa22efe05b3  vmovaps xmm3, [rsp+0x30]
00007fa22efe05b9  vmovaps xmm4, [rsp+0x40]
00007fa22efe05bf  vmovaps xmm5, [rsp+0x50]
00007fa22efe05c5  vmovaps xmm6, [rsp+0x60]
00007fa22efe05cb  vmovaps xmm7, [rsp+0x70]
00007fa22efe05d1  vmovaps xmm8, [rsp+0x80]
00007fa22efe05da  vmovaps xmm9, [rsp+0x90]
00007fa22efe05e3  vmovaps xmm10, [rsp+0xA0]
00007fa22efe05ec  vmovaps xmm11, [rsp+0xB0]
00007fa22efe05f5  vmovaps xmm13, [rsp+0xC0]
00007fa22efe05fe  vmovaps xmm14, [rsp+0xD0]
00007fa22efe0607  vmovaps xmm15, [rsp+0xE0]
00007fa22efe0610  add rsp, 0xF0
00007fa22efe0617  pop r11
00007fa22efe0619  pop r10
00007fa22efe061b  pop r9
00007fa22efe061d  pop r8
00007fa22efe061f  pop rsi
00007fa22efe0620  pop rdi
00007fa22efe0621  pop rdx
00007fa22efe0622  pop rcx
00007fa22efe0623  pop rax
00007fa22efe0624  add rsp, 0x08
00007fa22efe0628  jmp 0x00007FA22EFDC5F4
00007fa22efe062d  sub rsp, 0x08
00007fa22efe0631  push rax
00007fa22efe0632  push rcx
00007fa22efe0633  push rdx
00007fa22efe0634  push rdi
00007fa22efe0635  push rsi
00007fa22efe0636  push r8
00007fa22efe0638  push r9
00007fa22efe063a  push r10
00007fa22efe063c  push r11
00007fa22efe063e  sub rsp, 0xF0
00007fa22efe0645  vmovaps [rsp], xmm0
00007fa22efe064a  vmovaps [rsp+0x10], xmm1
00007fa22efe0650  vmovaps [rsp+0x20], xmm2
00007fa22efe0656  vmovaps [rsp+0x30], xmm3
00007fa22efe065c  vmovaps [rsp+0x40], xmm4
00007fa22efe0662  vmovaps [rsp+0x50], xmm5
00007fa22efe0668  vmovaps [rsp+0x60], xmm6
00007fa22efe066e  vmovaps [rsp+0x70], xmm7
00007fa22efe0674  vmovaps [rsp+0x80], xmm8
00007fa22efe067d  vmovaps [rsp+0x90], xmm9
00007fa22efe0686  vmovaps [rsp+0xA0], xmm10
00007fa22efe068f  vmovaps [rsp+0xB0], xmm11
00007fa22efe0698  vmovaps [rsp+0xC0], xmm12
00007fa22efe06a1  vmovaps [rsp+0xD0], xmm14
00007fa22efe06aa  vmovaps [rsp+0xE0], xmm15
00007fa22efe06b3  sub rsp, 0x30
00007fa22efe06b7  movaps [rsp], xmm13
00007fa22efe06bc  movaps [rsp+0x10], xmm15
00007fa22efe06c2  movaps [rsp+0x20], xmm8
00007fa22efe06c8  lea rdi, [rsp]
00007fa22efe06cc  mov esi, 0x00
00007fa22efe06d1  mov rax, 0x5E9D1A57D530
00007fa22efe06db  call rax
00007fa22efe06dd  movaps xmm13, [rsp]
00007fa22efe06e2  add rsp, 0x30
00007fa22efe06e6  vmovaps xmm0, [rsp]
00007fa22efe06eb  vmovaps xmm1, [rsp+0x10]
00007fa22efe06f1  vmovaps xmm2, [rsp+0x20]
00007fa22efe06f7  vmovaps xmm3, [rsp+0x30]
00007fa22efe06fd  vmovaps xmm4, [rsp+0x40]
00007fa22efe0703  vmovaps xmm5, [rsp+0x50]
00007fa22efe0709  vmovaps xmm6, [rsp+0x60]
00007fa22efe070f  vmovaps xmm7, [rsp+0x70]
00007fa22efe0715  vmovaps xmm8, [rsp+0x80]
00007fa22efe071e  vmovaps xmm9, [rsp+0x90]
00007fa22efe0727  vmovaps xmm10, [rsp+0xA0]
00007fa22efe0730  vmovaps xmm11, [rsp+0xB0]
00007fa22efe0739  vmovaps xmm12, [rsp+0xC0]
00007fa22efe0742  vmovaps xmm14, [rsp+0xD0]
00007fa22efe074b  vmovaps xmm15, [rsp+0xE0]
00007fa22efe0754  add rsp, 0xF0
00007fa22efe075b  pop r11
00007fa22efe075d  pop r10
00007fa22efe075f  pop r9
00007fa22efe0761  pop r8
00007fa22efe0763  pop rsi
00007fa22efe0764  pop rdi
00007fa22efe0765  pop rdx
00007fa22efe0766  pop rcx
00007fa22efe0767  pop rax
00007fa22efe0768  add rsp, 0x08
00007fa22efe076c  jmp 0x00007FA22EFDC60F
00007fa22efe0771  sub rsp, 0x08
00007fa22efe0775  push rax
00007fa22efe0776  push rcx
00007fa22efe0777  push rdx
00007fa22efe0778  push rdi
00007fa22efe0779  push rsi
00007fa22efe077a  push r8
00007fa22efe077c  push r9
00007fa22efe077e  push r10
00007fa22efe0780  push r11
00007fa22efe0782  sub rsp, 0xF0
00007fa22efe0789  vmovaps [rsp], xmm0
00007fa22efe078e  vmovaps [rsp+0x10], xmm1
00007fa22efe0794  vmovaps [rsp+0x20], xmm2
00007fa22efe079a  vmovaps [rsp+0x30], xmm3
00007fa22efe07a0  vmovaps [rsp+0x40], xmm4
00007fa22efe07a6  vmovaps [rsp+0x50], xmm5
00007fa22efe07ac  vmovaps [rsp+0x60], xmm6
00007fa22efe07b2  vmovaps [rsp+0x70], xmm7
00007fa22efe07b8  vmovaps [rsp+0x80], xmm9
00007fa22efe07c1  vmovaps [rsp+0x90], xmm10
00007fa22efe07ca  vmovaps [rsp+0xA0], xmm11
00007fa22efe07d3  vmovaps [rsp+0xB0], xmm12
00007fa22efe07dc  vmovaps [rsp+0xC0], xmm13
00007fa22efe07e5  vmovaps [rsp+0xD0], xmm14
00007fa22efe07ee  vmovaps [rsp+0xE0], xmm15
00007fa22efe07f7  sub rsp, 0x30
00007fa22efe07fb  movaps [rsp], xmm8
00007fa22efe0800  movaps [rsp+0x10], xmm15
00007fa22efe0806  movaps [rsp+0x20], xmm9
00007fa22efe080c  lea rdi, [rsp]
00007fa22efe0810  mov esi, 0x00
00007fa22efe0815  mov rax, 0x5E9D1A57D530
00007fa22efe081f  call rax
00007fa22efe0821  movaps xmm8, [rsp]
00007fa22efe0826  add rsp, 0x30
00007fa22efe082a  vmovaps xmm0, [rsp]
00007fa22efe082f  vmovaps xmm1, [rsp+0x10]
00007fa22efe0835  vmovaps xmm2, [rsp+0x20]
00007fa22efe083b  vmovaps xmm3, [rsp+0x30]
00007fa22efe0841  vmovaps xmm4, [rsp+0x40]
00007fa22efe0847  vmovaps xmm5, [rsp+0x50]
00007fa22efe084d  vmovaps xmm6, [rsp+0x60]
00007fa22efe0853  vmovaps xmm7, [rsp+0x70]
00007fa22efe0859  vmovaps xmm9, [rsp+0x80]
00007fa22efe0862  vmovaps xmm10, [rsp+0x90]
00007fa22efe086b  vmovaps xmm11, [rsp+0xA0]
00007fa22efe0874  vmovaps xmm12, [rsp+0xB0]
00007fa22efe087d  vmovaps xmm13, [rsp+0xC0]
00007fa22efe0886  vmovaps xmm14, [rsp+0xD0]
00007fa22efe088f  vmovaps xmm15, [rsp+0xE0]
00007fa22efe0898  add rsp, 0xF0
00007fa22efe089f  pop r11
00007fa22efe08a1  pop r10
00007fa22efe08a3  pop r9
00007fa22efe08a5  pop r8
00007fa22efe08a7  pop rsi
00007fa22efe08a8  pop rdi
00007fa22efe08a9  pop rdx
00007fa22efe08aa  pop rcx
00007fa22efe08ab  pop rax
00007fa22efe08ac  add rsp, 0x08
00007fa22efe08b0  jmp 0x00007FA22EFDC63D
00007fa22efe08b5  sub rsp, 0x08
00007fa22efe08b9  push rax
00007fa22efe08ba  push rcx
00007fa22efe08bb  push rdx
00007fa22efe08bc  push rdi
00007fa22efe08bd  push rsi
00007fa22efe08be  push r8
00007fa22efe08c0  push r9
00007fa22efe08c2  push r10
00007fa22efe08c4  push r11
00007fa22efe08c6  sub rsp, 0xF0
00007fa22efe08cd  vmovaps [rsp], xmm0
00007fa22efe08d2  vmovaps [rsp+0x10], xmm1
00007fa22efe08d8  vmovaps [rsp+0x20], xmm2
00007fa22efe08de  vmovaps [rsp+0x30], xmm3
00007fa22efe08e4  vmovaps [rsp+0x40], xmm4
00007fa22efe08ea  vmovaps [rsp+0x50], xmm5
00007fa22efe08f0  vmovaps [rsp+0x60], xmm6
00007fa22efe08f6  vmovaps [rsp+0x70], xmm7
00007fa22efe08fc  vmovaps [rsp+0x80], xmm8
00007fa22efe0905  vmovaps [rsp+0x90], xmm9
00007fa22efe090e  vmovaps [rsp+0xA0], xmm10
00007fa22efe0917  vmovaps [rsp+0xB0], xmm11
00007fa22efe0920  vmovaps [rsp+0xC0], xmm12
00007fa22efe0929  vmovaps [rsp+0xD0], xmm13
00007fa22efe0932  vmovaps [rsp+0xE0], xmm14
00007fa22efe093b  sub rsp, 0x30
00007fa22efe093f  movaps [rsp], xmm15
00007fa22efe0944  movaps [rsp+0x10], xmm11
00007fa22efe094a  movaps [rsp+0x20], xmm6
00007fa22efe094f  lea rdi, [rsp]
00007fa22efe0953  mov esi, 0x00
00007fa22efe0958  mov rax, 0x5E9D1A57D530
00007fa22efe0962  call rax
00007fa22efe0964  movaps xmm15, [rsp]
00007fa22efe0969  add rsp, 0x30
00007fa22efe096d  vmovaps xmm0, [rsp]
00007fa22efe0972  vmovaps xmm1, [rsp+0x10]
00007fa22efe0978  vmovaps xmm2, [rsp+0x20]
00007fa22efe097e  vmovaps xmm3, [rsp+0x30]
00007fa22efe0984  vmovaps xmm4, [rsp+0x40]
00007fa22efe098a  vmovaps xmm5, [rsp+0x50]
00007fa22efe0990  vmovaps xmm6, [rsp+0x60]
00007fa22efe0996  vmovaps xmm7, [rsp+0x70]
00007fa22efe099c  vmovaps xmm8, [rsp+0x80]
00007fa22efe09a5  vmovaps xmm9, [rsp+0x90]
00007fa22efe09ae  vmovaps xmm10, [rsp+0xA0]
00007fa22efe09b7  vmovaps xmm11, [rsp+0xB0]
00007fa22efe09c0  vmovaps xmm12, [rsp+0xC0]
00007fa22efe09c9  vmovaps xmm13, [rsp+0xD0]
00007fa22efe09d2  vmovaps xmm14, [rsp+0xE0]
00007fa22efe09db  add rsp, 0xF0
00007fa22efe09e2  pop r11
00007fa22efe09e4  pop r10
00007fa22efe09e6  pop r9
00007fa22efe09e8  pop r8
00007fa22efe09ea  pop rsi
00007fa22efe09eb  pop rdi
00007fa22efe09ec  pop rdx
00007fa22efe09ed  pop rcx
00007fa22efe09ee  pop rax
00007fa22efe09ef  add rsp, 0x08
00007fa22efe09f3  jmp 0x00007FA22EFDC658
00007fa22efe09f8  sub rsp, 0x08
00007fa22efe09fc  push rax
00007fa22efe09fd  push rcx
00007fa22efe09fe  push rdx
00007fa22efe09ff  push rdi
00007fa22efe0a00  push rsi
00007fa22efe0a01  push r8
00007fa22efe0a03  push r9
00007fa22efe0a05  push r10
00007fa22efe0a07  push r11
00007fa22efe0a09  sub rsp, 0xF0
00007fa22efe0a10  vmovaps [rsp], xmm0
00007fa22efe0a15  vmovaps [rsp+0x10], xmm1
00007fa22efe0a1b  vmovaps [rsp+0x20], xmm2
00007fa22efe0a21  vmovaps [rsp+0x30], xmm3
00007fa22efe0a27  vmovaps [rsp+0x40], xmm4
00007fa22efe0a2d  vmovaps [rsp+0x50], xmm5
00007fa22efe0a33  vmovaps [rsp+0x60], xmm6
00007fa22efe0a39  vmovaps [rsp+0x70], xmm8
00007fa22efe0a3f  vmovaps [rsp+0x80], xmm9
00007fa22efe0a48  vmovaps [rsp+0x90], xmm10
00007fa22efe0a51  vmovaps [rsp+0xA0], xmm11
00007fa22efe0a5a  vmovaps [rsp+0xB0], xmm12
00007fa22efe0a63  vmovaps [rsp+0xC0], xmm13
00007fa22efe0a6c  vmovaps [rsp+0xD0], xmm14
00007fa22efe0a75  vmovaps [rsp+0xE0], xmm15
00007fa22efe0a7e  sub rsp, 0x30
00007fa22efe0a82  movaps [rsp], xmm7
00007fa22efe0a86  movaps [rsp+0x10], xmm11
00007fa22efe0a8c  movaps [rsp+0x20], xmm9
00007fa22efe0a92  lea rdi, [rsp]
00007fa22efe0a96  mov esi, 0x00
00007fa22efe0a9b  mov rax, 0x5E9D1A57D530
00007fa22efe0aa5  call rax
00007fa22efe0aa7  movaps xmm7, [rsp]
00007fa22efe0aab  add rsp, 0x30
00007fa22efe0aaf  vmovaps xmm0, [rsp]
00007fa22efe0ab4  vmovaps xmm1, [rsp+0x10]
00007fa22efe0aba  vmovaps xmm2, [rsp+0x20]
00007fa22efe0ac0  vmovaps xmm3, [rsp+0x30]
00007fa22efe0ac6  vmovaps xmm4, [rsp+0x40]
00007fa22efe0acc  vmovaps xmm5, [rsp+0x50]
00007fa22efe0ad2  vmovaps xmm6, [rsp+0x60]
00007fa22efe0ad8  vmovaps xmm8, [rsp+0x70]
00007fa22efe0ade  vmovaps xmm9, [rsp+0x80]
00007fa22efe0ae7  vmovaps xmm10, [rsp+0x90]
00007fa22efe0af0  vmovaps xmm11, [rsp+0xA0]
00007fa22efe0af9  vmovaps xmm12, [rsp+0xB0]
00007fa22efe0b02  vmovaps xmm13, [rsp+0xC0]
00007fa22efe0b0b  vmovaps xmm14, [rsp+0xD0]
00007fa22efe0b14  vmovaps xmm15, [rsp+0xE0]
00007fa22efe0b1d  add rsp, 0xF0
00007fa22efe0b24  pop r11
00007fa22efe0b26  pop r10
00007fa22efe0b28  pop r9
00007fa22efe0b2a  pop r8
00007fa22efe0b2c  pop rsi
00007fa22efe0b2d  pop rdi
00007fa22efe0b2e  pop rdx
00007fa22efe0b2f  pop rcx
00007fa22efe0b30  pop rax
00007fa22efe0b31  add rsp, 0x08
00007fa22efe0b35  jmp 0x00007FA22EFDC685
00007fa22efe0b3a  sub rsp, 0x08
00007fa22efe0b3e  push rax
00007fa22efe0b3f  push rcx
00007fa22efe0b40  push rdx
00007fa22efe0b41  push rdi
00007fa22efe0b42  push rsi
00007fa22efe0b43  push r8
00007fa22efe0b45  push r9
00007fa22efe0b47  push r10
00007fa22efe0b49  push r11
00007fa22efe0b4b  sub rsp, 0xF0
00007fa22efe0b52  vmovaps [rsp], xmm0
00007fa22efe0b57  vmovaps [rsp+0x10], xmm1
00007fa22efe0b5d  vmovaps [rsp+0x20], xmm2
00007fa22efe0b63  vmovaps [rsp+0x30], xmm3
00007fa22efe0b69  vmovaps [rsp+0x40], xmm4
00007fa22efe0b6f  vmovaps [rsp+0x50], xmm5
00007fa22efe0b75  vmovaps [rsp+0x60], xmm6
00007fa22efe0b7b  vmovaps [rsp+0x70], xmm7
00007fa22efe0b81  vmovaps [rsp+0x80], xmm8
00007fa22efe0b8a  vmovaps [rsp+0x90], xmm9
00007fa22efe0b93  vmovaps [rsp+0xA0], xmm10
00007fa22efe0b9c  vmovaps [rsp+0xB0], xmm12
00007fa22efe0ba5  vmovaps [rsp+0xC0], xmm13
00007fa22efe0bae  vmovaps [rsp+0xD0], xmm14
00007fa22efe0bb7  vmovaps [rsp+0xE0], xmm15
00007fa22efe0bc0  sub rsp, 0x30
00007fa22efe0bc4  movaps [rsp], xmm11
00007fa22efe0bc9  movaps [rsp+0x10], xmm10
00007fa22efe0bcf  movaps [rsp+0x20], xmm14
00007fa22efe0bd5  lea rdi, [rsp]
00007fa22efe0bd9  mov esi, 0x00
00007fa22efe0bde  mov rax, 0x5E9D1A57D530
00007fa22efe0be8  call rax
00007fa22efe0bea  movaps xmm11, [rsp]
00007fa22efe0bef  add rsp, 0x30
00007fa22efe0bf3  vmovaps xmm0, [rsp]
00007fa22efe0bf8  vmovaps xmm1, [rsp+0x10]
00007fa22efe0bfe  vmovaps xmm2, [rsp+0x20]
00007fa22efe0c04  vmovaps xmm3, [rsp+0x30]
00007fa22efe0c0a  vmovaps xmm4, [rsp+0x40]
00007fa22efe0c10  vmovaps xmm5, [rsp+0x50]
00007fa22efe0c16  vmovaps xmm6, [rsp+0x60]
00007fa22efe0c1c  vmovaps xmm7, [rsp+0x70]
00007fa22efe0c22  vmovaps xmm8, [rsp+0x80]
00007fa22efe0c2b  vmovaps xmm9, [rsp+0x90]
00007fa22efe0c34  vmovaps xmm10, [rsp+0xA0]
00007fa22efe0c3d  vmovaps xmm12, [rsp+0xB0]
00007fa22efe0c46  vmovaps xmm13, [rsp+0xC0]
00007fa22efe0c4f  vmovaps xmm14, [rsp+0xD0]
00007fa22efe0c58  vmovaps xmm15, [rsp+0xE0]
00007fa22efe0c61  add rsp, 0xF0
00007fa22efe0c68  pop r11
00007fa22efe0c6a  pop r10
00007fa22efe0c6c  pop r9
00007fa22efe0c6e  pop r8
00007fa22efe0c70  pop rsi
00007fa22efe0c71  pop rdi
00007fa22efe0c72  pop rdx
00007fa22efe0c73  pop rcx
00007fa22efe0c74  pop rax
00007fa22efe0c75  add rsp, 0x08
00007fa22efe0c79  jmp 0x00007FA22EFDC6A0
00007fa22efe0c7e  call 0x00007FA22EEC33A0
00007fa22efe0c83  jmp 0x00007FA22EFDC6AA
00007fa22efe0c88  sub rsp, 0x08
00007fa22efe0c8c  push rax
00007fa22efe0c8d  push rcx
00007fa22efe0c8e  push rdx
00007fa22efe0c8f  push rdi
00007fa22efe0c90  push rsi
00007fa22efe0c91  push r8
00007fa22efe0c93  push r9
00007fa22efe0c95  push r10
00007fa22efe0c97  push r11
00007fa22efe0c99  sub rsp, 0xF0
00007fa22efe0ca0  vmovaps [rsp], xmm0
00007fa22efe0ca5  vmovaps [rsp+0x10], xmm1
00007fa22efe0cab  vmovaps [rsp+0x20], xmm2
00007fa22efe0cb1  vmovaps [rsp+0x30], xmm3
00007fa22efe0cb7  vmovaps [rsp+0x40], xmm4
00007fa22efe0cbd  vmovaps [rsp+0x50], xmm5
00007fa22efe0cc3  vmovaps [rsp+0x60], xmm6
00007fa22efe0cc9  vmovaps [rsp+0x70], xmm7
00007fa22efe0ccf  vmovaps [rsp+0x80], xmm8
00007fa22efe0cd8  vmovaps [rsp+0x90], xmm9
00007fa22efe0ce1  vmovaps [rsp+0xA0], xmm11
00007fa22efe0cea  vmovaps [rsp+0xB0], xmm12
00007fa22efe0cf3  vmovaps [rsp+0xC0], xmm13
00007fa22efe0cfc  vmovaps [rsp+0xD0], xmm14
00007fa22efe0d05  vmovaps [rsp+0xE0], xmm15
00007fa22efe0d0e  sub rsp, 0x30
00007fa22efe0d12  movaps [rsp], xmm10
00007fa22efe0d17  movaps [rsp+0x10], xmm1
00007fa22efe0d1c  movaps [rsp+0x20], xmm12
00007fa22efe0d22  lea rdi, [rsp]
00007fa22efe0d26  mov esi, 0x00
00007fa22efe0d2b  mov rax, 0x5E9D1A57D530
00007fa22efe0d35  call rax
00007fa22efe0d37  movaps xmm10, [rsp]
00007fa22efe0d3c  add rsp, 0x30
00007fa22efe0d40  vmovaps xmm0, [rsp]
00007fa22efe0d45  vmovaps xmm1, [rsp+0x10]
00007fa22efe0d4b  vmovaps xmm2, [rsp+0x20]
00007fa22efe0d51  vmovaps xmm3, [rsp+0x30]
00007fa22efe0d57  vmovaps xmm4, [rsp+0x40]
00007fa22efe0d5d  vmovaps xmm5, [rsp+0x50]
00007fa22efe0d63  vmovaps xmm6, [rsp+0x60]
00007fa22efe0d69  vmovaps xmm7, [rsp+0x70]
00007fa22efe0d6f  vmovaps xmm8, [rsp+0x80]
00007fa22efe0d78  vmovaps xmm9, [rsp+0x90]
00007fa22efe0d81  vmovaps xmm11, [rsp+0xA0]
00007fa22efe0d8a  vmovaps xmm12, [rsp+0xB0]
00007fa22efe0d93  vmovaps xmm13, [rsp+0xC0]
00007fa22efe0d9c  vmovaps xmm14, [rsp+0xD0]
00007fa22efe0da5  vmovaps xmm15, [rsp+0xE0]
00007fa22efe0dae  add rsp, 0xF0
00007fa22efe0db5  pop r11
00007fa22efe0db7  pop r10
00007fa22efe0db9  pop r9
00007fa22efe0dbb  pop r8
00007fa22efe0dbd  pop rsi
00007fa22efe0dbe  pop rdi
00007fa22efe0dbf  pop rdx
00007fa22efe0dc0  pop rcx
00007fa22efe0dc1  pop rax
00007fa22efe0dc2  add rsp, 0x08
00007fa22efe0dc6  jmp 0x00007FA22EFDC6CD
00007fa22efe0dcb  sub rsp, 0x08
00007fa22efe0dcf  push rax
00007fa22efe0dd0  push rcx
00007fa22efe0dd1  push rdx
00007fa22efe0dd2  push rdi
00007fa22efe0dd3  push rsi
00007fa22efe0dd4  push r8
00007fa22efe0dd6  push r9
00007fa22efe0dd8  push r10
00007fa22efe0dda  push r11
00007fa22efe0ddc  sub rsp, 0xF0
00007fa22efe0de3  vmovaps [rsp], xmm0
00007fa22efe0de8  vmovaps [rsp+0x10], xmm1
00007fa22efe0dee  vmovaps [rsp+0x20], xmm2
00007fa22efe0df4  vmovaps [rsp+0x30], xmm3
00007fa22efe0dfa  vmovaps [rsp+0x40], xmm4
00007fa22efe0e00  vmovaps [rsp+0x50], xmm5
00007fa22efe0e06  vmovaps [rsp+0x60], xmm6
00007fa22efe0e0c  vmovaps [rsp+0x70], xmm7
00007fa22efe0e12  vmovaps [rsp+0x80], xmm8
00007fa22efe0e1b  vmovaps [rsp+0x90], xmm9
00007fa22efe0e24  vmovaps [rsp+0xA0], xmm10
00007fa22efe0e2d  vmovaps [rsp+0xB0], xmm11
00007fa22efe0e36  vmovaps [rsp+0xC0], xmm13
00007fa22efe0e3f  vmovaps [rsp+0xD0], xmm14
00007fa22efe0e48  vmovaps [rsp+0xE0], xmm15
00007fa22efe0e51  sub rsp, 0x30
00007fa22efe0e55  movaps [rsp], xmm12
00007fa22efe0e5a  movaps [rsp+0x10], xmm14
00007fa22efe0e60  movaps [rsp+0x20], xmm1
00007fa22efe0e65  lea rdi, [rsp]
00007fa22efe0e69  mov esi, 0x00
00007fa22efe0e6e  mov rax, 0x5E9D1A57D530
00007fa22efe0e78  call rax
00007fa22efe0e7a  movaps xmm12, [rsp]
00007fa22efe0e7f  add rsp, 0x30
00007fa22efe0e83  vmovaps xmm0, [rsp]
00007fa22efe0e88  vmovaps xmm1, [rsp+0x10]
00007fa22efe0e8e  vmovaps xmm2, [rsp+0x20]
00007fa22efe0e94  vmovaps xmm3, [rsp+0x30]
00007fa22efe0e9a  vmovaps xmm4, [rsp+0x40]
00007fa22efe0ea0  vmovaps xmm5, [rsp+0x50]
00007fa22efe0ea6  vmovaps xmm6, [rsp+0x60]
00007fa22efe0eac  vmovaps xmm7, [rsp+0x70]
00007fa22efe0eb2  vmovaps xmm8, [rsp+0x80]
00007fa22efe0ebb  vmovaps xmm9, [rsp+0x90]
00007fa22efe0ec4  vmovaps xmm10, [rsp+0xA0]
00007fa22efe0ecd  vmovaps xmm11, [rsp+0xB0]
00007fa22efe0ed6  vmovaps xmm13, [rsp+0xC0]
00007fa22efe0edf  vmovaps xmm14, [rsp+0xD0]
00007fa22efe0ee8  vmovaps xmm15, [rsp+0xE0]
00007fa22efe0ef1  add rsp, 0xF0
00007fa22efe0ef8  pop r11
00007fa22efe0efa  pop r10
00007fa22efe0efc  pop r9
00007fa22efe0efe  pop r8
00007fa22efe0f00  pop rsi
00007fa22efe0f01  pop rdi
00007fa22efe0f02  pop rdx
00007fa22efe0f03  pop rcx
00007fa22efe0f04  pop rax
00007fa22efe0f05  add rsp, 0x08
00007fa22efe0f09  jmp 0x00007FA22EFDC6FC
00007fa22efe0f0e  sub rsp, 0x08
00007fa22efe0f12  push rax
00007fa22efe0f13  push rcx
00007fa22efe0f14  push rdx
00007fa22efe0f15  push rdi
00007fa22efe0f16  push rsi
00007fa22efe0f17  push r8
00007fa22efe0f19  push r9
00007fa22efe0f1b  push r10
00007fa22efe0f1d  push r11
00007fa22efe0f1f  sub rsp, 0xF0
00007fa22efe0f26  vmovaps [rsp], xmm0
00007fa22efe0f2b  vmovaps [rsp+0x10], xmm1
00007fa22efe0f31  vmovaps [rsp+0x20], xmm2
00007fa22efe0f37  vmovaps [rsp+0x30], xmm3
00007fa22efe0f3d  vmovaps [rsp+0x40], xmm4
00007fa22efe0f43  vmovaps [rsp+0x50], xmm5
00007fa22efe0f49  vmovaps [rsp+0x60], xmm6
00007fa22efe0f4f  vmovaps [rsp+0x70], xmm7
00007fa22efe0f55  vmovaps [rsp+0x80], xmm8
00007fa22efe0f5e  vmovaps [rsp+0x90], xmm9
00007fa22efe0f67  vmovaps [rsp+0xA0], xmm10
00007fa22efe0f70  vmovaps [rsp+0xB0], xmm11
00007fa22efe0f79  vmovaps [rsp+0xC0], xmm12
00007fa22efe0f82  vmovaps [rsp+0xD0], xmm13
00007fa22efe0f8b  vmovaps [rsp+0xE0], xmm15
00007fa22efe0f94  sub rsp, 0x30
00007fa22efe0f98  movaps [rsp], xmm14
00007fa22efe0f9d  movaps [rsp+0x10], xmm9
00007fa22efe0fa3  movaps [rsp+0x20], xmm1
00007fa22efe0fa8  lea rdi, [rsp]
00007fa22efe0fac  mov esi, 0x00
00007fa22efe0fb1  mov rax, 0x5E9D1A57D530
00007fa22efe0fbb  call rax
00007fa22efe0fbd  movaps xmm14, [rsp]
00007fa22efe0fc2  add rsp, 0x30
00007fa22efe0fc6  vmovaps xmm0, [rsp]
00007fa22efe0fcb  vmovaps xmm1, [rsp+0x10]
00007fa22efe0fd1  vmovaps xmm2, [rsp+0x20]
00007fa22efe0fd7  vmovaps xmm3, [rsp+0x30]
00007fa22efe0fdd  vmovaps xmm4, [rsp+0x40]
00007fa22efe0fe3  vmovaps xmm5, [rsp+0x50]
00007fa22efe0fe9  vmovaps xmm6, [rsp+0x60]
00007fa22efe0fef  vmovaps xmm7, [rsp+0x70]
00007fa22efe0ff5  vmovaps xmm8, [rsp+0x80]
00007fa22efe0ffe  vmovaps xmm9, [rsp+0x90]
00007fa22efe1007  vmovaps xmm10, [rsp+0xA0]
00007fa22efe1010  vmovaps xmm11, [rsp+0xB0]
00007fa22efe1019  vmovaps xmm12, [rsp+0xC0]
00007fa22efe1022  vmovaps xmm13, [rsp+0xD0]
00007fa22efe102b  vmovaps xmm15, [rsp+0xE0]
00007fa22efe1034  add rsp, 0xF0
00007fa22efe103b  pop r11
00007fa22efe103d  pop r10
00007fa22efe103f  pop r9
00007fa22efe1041  pop r8
00007fa22efe1043  pop rsi
00007fa22efe1044  pop rdi
00007fa22efe1045  pop rdx
00007fa22efe1046  pop rcx
00007fa22efe1047  pop rax
00007fa22efe1048  add rsp, 0x08
00007fa22efe104c  jmp 0x00007FA22EFDC72B
00007fa22efe1051  sub rsp, 0x08
00007fa22efe1055  push rax
00007fa22efe1056  push rcx
00007fa22efe1057  push rdx
00007fa22efe1058  push rdi
00007fa22efe1059  push rsi
00007fa22efe105a  push r8
00007fa22efe105c  push r9
00007fa22efe105e  push r10
00007fa22efe1060  push r11
00007fa22efe1062  sub rsp, 0xF0
00007fa22efe1069  vmovaps [rsp], xmm0
00007fa22efe106e  vmovaps [rsp+0x10], xmm2
00007fa22efe1074  vmovaps [rsp+0x20], xmm3
00007fa22efe107a  vmovaps [rsp+0x30], xmm4
00007fa22efe1080  vmovaps [rsp+0x40], xmm5
00007fa22efe1086  vmovaps [rsp+0x50], xmm6
00007fa22efe108c  vmovaps [rsp+0x60], xmm7
00007fa22efe1092  vmovaps [rsp+0x70], xmm8
00007fa22efe1098  vmovaps [rsp+0x80], xmm9
00007fa22efe10a1  vmovaps [rsp+0x90], xmm10
00007fa22efe10aa  vmovaps [rsp+0xA0], xmm11
00007fa22efe10b3  vmovaps [rsp+0xB0], xmm12
00007fa22efe10bc  vmovaps [rsp+0xC0], xmm13
00007fa22efe10c5  vmovaps [rsp+0xD0], xmm14
00007fa22efe10ce  vmovaps [rsp+0xE0], xmm15
00007fa22efe10d7  sub rsp, 0x30
00007fa22efe10db  movaps [rsp], xmm1
00007fa22efe10df  movaps [rsp+0x10], xmm13
00007fa22efe10e5  movaps [rsp+0x20], xmm8
00007fa22efe10eb  lea rdi, [rsp]
00007fa22efe10ef  mov esi, 0x00
00007fa22efe10f4  mov rax, 0x5E9D1A57D530
00007fa22efe10fe  call rax
00007fa22efe1100  movaps xmm1, [rsp]
00007fa22efe1104  add rsp, 0x30
00007fa22efe1108  vmovaps xmm0, [rsp]
00007fa22efe110d  vmovaps xmm2, [rsp+0x10]
00007fa22efe1113  vmovaps xmm3, [rsp+0x20]
00007fa22efe1119  vmovaps xmm4, [rsp+0x30]
00007fa22efe111f  vmovaps xmm5, [rsp+0x40]
00007fa22efe1125  vmovaps xmm6, [rsp+0x50]
00007fa22efe112b  vmovaps xmm7, [rsp+0x60]
00007fa22efe1131  vmovaps xmm8, [rsp+0x70]
00007fa22efe1137  vmovaps xmm9, [rsp+0x80]
00007fa22efe1140  vmovaps xmm10, [rsp+0x90]
00007fa22efe1149  vmovaps xmm11, [rsp+0xA0]
00007fa22efe1152  vmovaps xmm12, [rsp+0xB0]
00007fa22efe115b  vmovaps xmm13, [rsp+0xC0]
00007fa22efe1164  vmovaps xmm14, [rsp+0xD0]
00007fa22efe116d  vmovaps xmm15, [rsp+0xE0]
00007fa22efe1176  add rsp, 0xF0
00007fa22efe117d  pop r11
00007fa22efe117f  pop r10
00007fa22efe1181  pop r9
00007fa22efe1183  pop r8
00007fa22efe1185  pop rsi
00007fa22efe1186  pop rdi
00007fa22efe1187  pop rdx
00007fa22efe1188  pop rcx
00007fa22efe1189  pop rax
00007fa22efe118a  add rsp, 0x08
00007fa22efe118e  jmp 0x00007FA22EFDC74D
00007fa22efe1193  call 0x00007FA22EE0C260
00007fa22efe1198  jmp 0x00007FA22EFDC75B
00007fa22efe119d  call 0x00007FA22EEBD750
00007fa22efe11a2  jmp 0x00007FA22EFDC765
00007fa22efe11a7  sub rsp, 0x08
00007fa22efe11ab  push rax
00007fa22efe11ac  push rcx
00007fa22efe11ad  push rdx
00007fa22efe11ae  push rdi
00007fa22efe11af  push rsi
00007fa22efe11b0  push r8
00007fa22efe11b2  push r9
00007fa22efe11b4  push r10
00007fa22efe11b6  push r11
00007fa22efe11b8  sub rsp, 0xF0
00007fa22efe11bf  vmovaps [rsp], xmm0
00007fa22efe11c4  vmovaps [rsp+0x10], xmm1
00007fa22efe11ca  vmovaps [rsp+0x20], xmm2
00007fa22efe11d0  vmovaps [rsp+0x30], xmm3
00007fa22efe11d6  vmovaps [rsp+0x40], xmm4
00007fa22efe11dc  vmovaps [rsp+0x50], xmm5
00007fa22efe11e2  vmovaps [rsp+0x60], xmm6
00007fa22efe11e8  vmovaps [rsp+0x70], xmm7
00007fa22efe11ee  vmovaps [rsp+0x80], xmm9
00007fa22efe11f7  vmovaps [rsp+0x90], xmm10
00007fa22efe1200  vmovaps [rsp+0xA0], xmm11
00007fa22efe1209  vmovaps [rsp+0xB0], xmm12
00007fa22efe1212  vmovaps [rsp+0xC0], xmm13
00007fa22efe121b  vmovaps [rsp+0xD0], xmm14
00007fa22efe1224  vmovaps [rsp+0xE0], xmm15
00007fa22efe122d  sub rsp, 0x30
00007fa22efe1231  movaps [rsp], xmm8
00007fa22efe1236  movaps [rsp+0x10], xmm15
00007fa22efe123c  movaps [rsp+0x20], xmm7
00007fa22efe1241  lea rdi, [rsp]
00007fa22efe1245  mov esi, 0x00
00007fa22efe124a  mov rax, 0x5E9D1A57D530
00007fa22efe1254  call rax
00007fa22efe1256  movaps xmm8, [rsp]
00007fa22efe125b  add rsp, 0x30
00007fa22efe125f  vmovaps xmm0, [rsp]
00007fa22efe1264  vmovaps xmm1, [rsp+0x10]
00007fa22efe126a  vmovaps xmm2, [rsp+0x20]
00007fa22efe1270  vmovaps xmm3, [rsp+0x30]
00007fa22efe1276  vmovaps xmm4, [rsp+0x40]
00007fa22efe127c  vmovaps xmm5, [rsp+0x50]
00007fa22efe1282  vmovaps xmm6, [rsp+0x60]
00007fa22efe1288  vmovaps xmm7, [rsp+0x70]
00007fa22efe128e  vmovaps xmm9, [rsp+0x80]
00007fa22efe1297  vmovaps xmm10, [rsp+0x90]
00007fa22efe12a0  vmovaps xmm11, [rsp+0xA0]
00007fa22efe12a9  vmovaps xmm12, [rsp+0xB0]
00007fa22efe12b2  vmovaps xmm13, [rsp+0xC0]
00007fa22efe12bb  vmovaps xmm14, [rsp+0xD0]
00007fa22efe12c4  vmovaps xmm15, [rsp+0xE0]
00007fa22efe12cd  add rsp, 0xF0
00007fa22efe12d4  pop r11
00007fa22efe12d6  pop r10
00007fa22efe12d8  pop r9
00007fa22efe12da  pop r8
00007fa22efe12dc  pop rsi
00007fa22efe12dd  pop rdi
00007fa22efe12de  pop rdx
00007fa22efe12df  pop rcx
00007fa22efe12e0  pop rax
00007fa22efe12e1  add rsp, 0x08
00007fa22efe12e5  jmp 0x00007FA22EFDC787
00007fa22efe12ea  sub rsp, 0x08
00007fa22efe12ee  push rax
00007fa22efe12ef  push rcx
00007fa22efe12f0  push rdx
00007fa22efe12f1  push rdi
00007fa22efe12f2  push rsi
00007fa22efe12f3  push r8
00007fa22efe12f5  push r9
00007fa22efe12f7  push r10
00007fa22efe12f9  push r11
00007fa22efe12fb  sub rsp, 0xF0
00007fa22efe1302  vmovaps [rsp], xmm0
00007fa22efe1307  vmovaps [rsp+0x10], xmm1
00007fa22efe130d  vmovaps [rsp+0x20], xmm2
00007fa22efe1313  vmovaps [rsp+0x30], xmm3
00007fa22efe1319  vmovaps [rsp+0x40], xmm4
00007fa22efe131f  vmovaps [rsp+0x50], xmm5
00007fa22efe1325  vmovaps [rsp+0x60], xmm6
00007fa22efe132b  vmovaps [rsp+0x70], xmm8
00007fa22efe1331  vmovaps [rsp+0x80], xmm9
00007fa22efe133a  vmovaps [rsp+0x90], xmm10
00007fa22efe1343  vmovaps [rsp+0xA0], xmm11
00007fa22efe134c  vmovaps [rsp+0xB0], xmm12
00007fa22efe1355  vmovaps [rsp+0xC0], xmm13
00007fa22efe135e  vmovaps [rsp+0xD0], xmm14
00007fa22efe1367  vmovaps [rsp+0xE0], xmm15
00007fa22efe1370  sub rsp, 0x30
00007fa22efe1374  movaps [rsp], xmm7
00007fa22efe1378  movaps [rsp+0x10], xmm9
00007fa22efe137e  movaps [rsp+0x20], xmm15
00007fa22efe1384  lea rdi, [rsp]
00007fa22efe1388  mov esi, 0x00
00007fa22efe138d  mov rax, 0x5E9D1A57D530
00007fa22efe1397  call rax
00007fa22efe1399  movaps xmm7, [rsp]
00007fa22efe139d  add rsp, 0x30
00007fa22efe13a1  vmovaps xmm0, [rsp]
00007fa22efe13a6  vmovaps xmm1, [rsp+0x10]
00007fa22efe13ac  vmovaps xmm2, [rsp+0x20]
00007fa22efe13b2  vmovaps xmm3, [rsp+0x30]
00007fa22efe13b8  vmovaps xmm4, [rsp+0x40]
00007fa22efe13be  vmovaps xmm5, [rsp+0x50]
00007fa22efe13c4  vmovaps xmm6, [rsp+0x60]
00007fa22efe13ca  vmovaps xmm8, [rsp+0x70]
00007fa22efe13d0  vmovaps xmm9, [rsp+0x80]
00007fa22efe13d9  vmovaps xmm10, [rsp+0x90]
00007fa22efe13e2  vmovaps xmm11, [rsp+0xA0]
00007fa22efe13eb  vmovaps xmm12, [rsp+0xB0]
00007fa22efe13f4  vmovaps xmm13, [rsp+0xC0]
00007fa22efe13fd  vmovaps xmm14, [rsp+0xD0]
00007fa22efe1406  vmovaps xmm15, [rsp+0xE0]
00007fa22efe140f  add rsp, 0xF0
00007fa22efe1416  pop r11
00007fa22efe1418  pop r10
00007fa22efe141a  pop r9
00007fa22efe141c  pop r8
00007fa22efe141e  pop rsi
00007fa22efe141f  pop rdi
00007fa22efe1420  pop rdx
00007fa22efe1421  pop rcx
00007fa22efe1422  pop rax
00007fa22efe1423  add rsp, 0x08
00007fa22efe1427  jmp 0x00007FA22EFDC7B4
00007fa22efe142c  sub rsp, 0x08
00007fa22efe1430  push rax
00007fa22efe1431  push rcx
00007fa22efe1432  push rdx
00007fa22efe1433  push rdi
00007fa22efe1434  push rsi
00007fa22efe1435  push r8
00007fa22efe1437  push r9
00007fa22efe1439  push r10
00007fa22efe143b  push r11
00007fa22efe143d  sub rsp, 0xF0
00007fa22efe1444  vmovaps [rsp], xmm0
00007fa22efe1449  vmovaps [rsp+0x10], xmm1
00007fa22efe144f  vmovaps [rsp+0x20], xmm2
00007fa22efe1455  vmovaps [rsp+0x30], xmm3
00007fa22efe145b  vmovaps [rsp+0x40], xmm4
00007fa22efe1461  vmovaps [rsp+0x50], xmm5
00007fa22efe1467  vmovaps [rsp+0x60], xmm6
00007fa22efe146d  vmovaps [rsp+0x70], xmm7
00007fa22efe1473  vmovaps [rsp+0x80], xmm8
00007fa22efe147c  vmovaps [rsp+0x90], xmm10
00007fa22efe1485  vmovaps [rsp+0xA0], xmm11
00007fa22efe148e  vmovaps [rsp+0xB0], xmm12
00007fa22efe1497  vmovaps [rsp+0xC0], xmm13
00007fa22efe14a0  vmovaps [rsp+0xD0], xmm14
00007fa22efe14a9  vmovaps [rsp+0xE0], xmm15
00007fa22efe14b2  sub rsp, 0x30
00007fa22efe14b6  movaps [rsp], xmm9
00007fa22efe14bb  movaps [rsp+0x10], xmm13
00007fa22efe14c1  movaps [rsp+0x20], xmm15
00007fa22efe14c7  lea rdi, [rsp]
00007fa22efe14cb  mov esi, 0x00
00007fa22efe14d0  mov rax, 0x5E9D1A57D530
00007fa22efe14da  call rax
00007fa22efe14dc  movaps xmm9, [rsp]
00007fa22efe14e1  add rsp, 0x30
00007fa22efe14e5  vmovaps xmm0, [rsp]
00007fa22efe14ea  vmovaps xmm1, [rsp+0x10]
00007fa22efe14f0  vmovaps xmm2, [rsp+0x20]
00007fa22efe14f6  vmovaps xmm3, [rsp+0x30]
00007fa22efe14fc  vmovaps xmm4, [rsp+0x40]
00007fa22efe1502  vmovaps xmm5, [rsp+0x50]
00007fa22efe1508  vmovaps xmm6, [rsp+0x60]
00007fa22efe150e  vmovaps xmm7, [rsp+0x70]
00007fa22efe1514  vmovaps xmm8, [rsp+0x80]
00007fa22efe151d  vmovaps xmm10, [rsp+0x90]
00007fa22efe1526  vmovaps xmm11, [rsp+0xA0]
00007fa22efe152f  vmovaps xmm12, [rsp+0xB0]
00007fa22efe1538  vmovaps xmm13, [rsp+0xC0]
00007fa22efe1541  vmovaps xmm14, [rsp+0xD0]
00007fa22efe154a  vmovaps xmm15, [rsp+0xE0]
00007fa22efe1553  add rsp, 0xF0
00007fa22efe155a  pop r11
00007fa22efe155c  pop r10
00007fa22efe155e  pop r9
00007fa22efe1560  pop r8
00007fa22efe1562  pop rsi
00007fa22efe1563  pop rdi
00007fa22efe1564  pop rdx
00007fa22efe1565  pop rcx
00007fa22efe1566  pop rax
00007fa22efe1567  add rsp, 0x08
00007fa22efe156b  jmp 0x00007FA22EFDC7E2
00007fa22efe1570  sub rsp, 0x08
00007fa22efe1574  push rax
00007fa22efe1575  push rcx
00007fa22efe1576  push rdx
00007fa22efe1577  push rdi
00007fa22efe1578  push rsi
00007fa22efe1579  push r8
00007fa22efe157b  push r9
00007fa22efe157d  push r10
00007fa22efe157f  push r11
00007fa22efe1581  sub rsp, 0xF0
00007fa22efe1588  vmovaps [rsp], xmm0
00007fa22efe158d  vmovaps [rsp+0x10], xmm1
00007fa22efe1593  vmovaps [rsp+0x20], xmm2
00007fa22efe1599  vmovaps [rsp+0x30], xmm3
00007fa22efe159f  vmovaps [rsp+0x40], xmm4
00007fa22efe15a5  vmovaps [rsp+0x50], xmm5
00007fa22efe15ab  vmovaps [rsp+0x60], xmm6
00007fa22efe15b1  vmovaps [rsp+0x70], xmm7
00007fa22efe15b7  vmovaps [rsp+0x80], xmm8
00007fa22efe15c0  vmovaps [rsp+0x90], xmm9
00007fa22efe15c9  vmovaps [rsp+0xA0], xmm10
00007fa22efe15d2  vmovaps [rsp+0xB0], xmm11
00007fa22efe15db  vmovaps [rsp+0xC0], xmm12
00007fa22efe15e4  vmovaps [rsp+0xD0], xmm13
00007fa22efe15ed  vmovaps [rsp+0xE0], xmm14
00007fa22efe15f6  sub rsp, 0x30
00007fa22efe15fa  movaps [rsp], xmm15
00007fa22efe15ff  movaps [rsp+0x10], xmm11
00007fa22efe1605  movaps [rsp+0x20], xmm12
00007fa22efe160b  lea rdi, [rsp]
00007fa22efe160f  mov esi, 0x00
00007fa22efe1614  mov rax, 0x5E9D1A57D530
00007fa22efe161e  call rax
00007fa22efe1620  movaps xmm15, [rsp]
00007fa22efe1625  add rsp, 0x30
00007fa22efe1629  vmovaps xmm0, [rsp]
00007fa22efe162e  vmovaps xmm1, [rsp+0x10]
00007fa22efe1634  vmovaps xmm2, [rsp+0x20]
00007fa22efe163a  vmovaps xmm3, [rsp+0x30]
00007fa22efe1640  vmovaps xmm4, [rsp+0x40]
00007fa22efe1646  vmovaps xmm5, [rsp+0x50]
00007fa22efe164c  vmovaps xmm6, [rsp+0x60]
00007fa22efe1652  vmovaps xmm7, [rsp+0x70]
00007fa22efe1658  vmovaps xmm8, [rsp+0x80]
00007fa22efe1661  vmovaps xmm9, [rsp+0x90]
00007fa22efe166a  vmovaps xmm10, [rsp+0xA0]
00007fa22efe1673  vmovaps xmm11, [rsp+0xB0]
00007fa22efe167c  vmovaps xmm12, [rsp+0xC0]
00007fa22efe1685  vmovaps xmm13, [rsp+0xD0]
00007fa22efe168e  vmovaps xmm14, [rsp+0xE0]
00007fa22efe1697  add rsp, 0xF0
00007fa22efe169e  pop r11
00007fa22efe16a0  pop r10
00007fa22efe16a2  pop r9
00007fa22efe16a4  pop r8
00007fa22efe16a6  pop rsi
00007fa22efe16a7  pop rdi
00007fa22efe16a8  pop rdx
00007fa22efe16a9  pop rcx
00007fa22efe16aa  pop rax
00007fa22efe16ab  add rsp, 0x08
00007fa22efe16af  jmp 0x00007FA22EFDC7FD
00007fa22efe16b4  sub rsp, 0x08
00007fa22efe16b8  push rax
00007fa22efe16b9  push rcx
00007fa22efe16ba  push rdx
00007fa22efe16bb  push rdi
00007fa22efe16bc  push rsi
00007fa22efe16bd  push r8
00007fa22efe16bf  push r9
00007fa22efe16c1  push r10
00007fa22efe16c3  push r11
00007fa22efe16c5  sub rsp, 0xF0
00007fa22efe16cc  vmovaps [rsp], xmm0
00007fa22efe16d1  vmovaps [rsp+0x10], xmm1
00007fa22efe16d7  vmovaps [rsp+0x20], xmm2
00007fa22efe16dd  vmovaps [rsp+0x30], xmm3
00007fa22efe16e3  vmovaps [rsp+0x40], xmm4
00007fa22efe16e9  vmovaps [rsp+0x50], xmm5
00007fa22efe16ef  vmovaps [rsp+0x60], xmm6
00007fa22efe16f5  vmovaps [rsp+0x70], xmm7
00007fa22efe16fb  vmovaps [rsp+0x80], xmm8
00007fa22efe1704  vmovaps [rsp+0x90], xmm9
00007fa22efe170d  vmovaps [rsp+0xA0], xmm10
00007fa22efe1716  vmovaps [rsp+0xB0], xmm11
00007fa22efe171f  vmovaps [rsp+0xC0], xmm12
00007fa22efe1728  vmovaps [rsp+0xD0], xmm14
00007fa22efe1731  vmovaps [rsp+0xE0], xmm15
00007fa22efe173a  sub rsp, 0x30
00007fa22efe173e  movaps [rsp], xmm13
00007fa22efe1743  movaps [rsp+0x10], xmm10
00007fa22efe1749  movaps [rsp+0x20], xmm14
00007fa22efe174f  lea rdi, [rsp]
00007fa22efe1753  mov esi, 0x00
00007fa22efe1758  mov rax, 0x5E9D1A57D530
00007fa22efe1762  call rax
00007fa22efe1764  movaps xmm13, [rsp]
00007fa22efe1769  add rsp, 0x30
00007fa22efe176d  vmovaps xmm0, [rsp]
00007fa22efe1772  vmovaps xmm1, [rsp+0x10]
00007fa22efe1778  vmovaps xmm2, [rsp+0x20]
00007fa22efe177e  vmovaps xmm3, [rsp+0x30]
00007fa22efe1784  vmovaps xmm4, [rsp+0x40]
00007fa22efe178a  vmovaps xmm5, [rsp+0x50]
00007fa22efe1790  vmovaps xmm6, [rsp+0x60]
00007fa22efe1796  vmovaps xmm7, [rsp+0x70]
00007fa22efe179c  vmovaps xmm8, [rsp+0x80]
00007fa22efe17a5  vmovaps xmm9, [rsp+0x90]
00007fa22efe17ae  vmovaps xmm10, [rsp+0xA0]
00007fa22efe17b7  vmovaps xmm11, [rsp+0xB0]
00007fa22efe17c0  vmovaps xmm12, [rsp+0xC0]
00007fa22efe17c9  vmovaps xmm14, [rsp+0xD0]
00007fa22efe17d2  vmovaps xmm15, [rsp+0xE0]
00007fa22efe17db  add rsp, 0xF0
00007fa22efe17e2  pop r11
00007fa22efe17e4  pop r10
00007fa22efe17e6  pop r9
00007fa22efe17e8  pop r8
00007fa22efe17ea  pop rsi
00007fa22efe17eb  pop rdi
00007fa22efe17ec  pop rdx
00007fa22efe17ed  pop rcx
00007fa22efe17ee  pop rax
00007fa22efe17ef  add rsp, 0x08
00007fa22efe17f3  jmp 0x00007FA22EFDC820
00007fa22efe17f8  sub rsp, 0x08
00007fa22efe17fc  push rax
00007fa22efe17fd  push rcx
00007fa22efe17fe  push rdx
00007fa22efe17ff  push rdi
00007fa22efe1800  push rsi
00007fa22efe1801  push r8
00007fa22efe1803  push r9
00007fa22efe1805  push r10
00007fa22efe1807  push r11
00007fa22efe1809  sub rsp, 0xF0
00007fa22efe1810  vmovaps [rsp], xmm0
00007fa22efe1815  vmovaps [rsp+0x10], xmm1
00007fa22efe181b  vmovaps [rsp+0x20], xmm2
00007fa22efe1821  vmovaps [rsp+0x30], xmm3
00007fa22efe1827  vmovaps [rsp+0x40], xmm4
00007fa22efe182d  vmovaps [rsp+0x50], xmm5
00007fa22efe1833  vmovaps [rsp+0x60], xmm6
00007fa22efe1839  vmovaps [rsp+0x70], xmm7
00007fa22efe183f  vmovaps [rsp+0x80], xmm8
00007fa22efe1848  vmovaps [rsp+0x90], xmm9
00007fa22efe1851  vmovaps [rsp+0xA0], xmm10
00007fa22efe185a  vmovaps [rsp+0xB0], xmm11
00007fa22efe1863  vmovaps [rsp+0xC0], xmm12
00007fa22efe186c  vmovaps [rsp+0xD0], xmm13
00007fa22efe1875  vmovaps [rsp+0xE0], xmm15
00007fa22efe187e  sub rsp, 0x30
00007fa22efe1882  movaps [rsp], xmm14
00007fa22efe1887  movaps [rsp+0x10], xmm1
00007fa22efe188c  movaps [rsp+0x20], xmm7
00007fa22efe1891  lea rdi, [rsp]
00007fa22efe1895  mov esi, 0x00
00007fa22efe189a  mov rax, 0x5E9D1A57D530
00007fa22efe18a4  call rax
00007fa22efe18a6  movaps xmm14, [rsp]
00007fa22efe18ab  add rsp, 0x30
00007fa22efe18af  vmovaps xmm0, [rsp]
00007fa22efe18b4  vmovaps xmm1, [rsp+0x10]
00007fa22efe18ba  vmovaps xmm2, [rsp+0x20]
00007fa22efe18c0  vmovaps xmm3, [rsp+0x30]
00007fa22efe18c6  vmovaps xmm4, [rsp+0x40]
00007fa22efe18cc  vmovaps xmm5, [rsp+0x50]
00007fa22efe18d2  vmovaps xmm6, [rsp+0x60]
00007fa22efe18d8  vmovaps xmm7, [rsp+0x70]
00007fa22efe18de  vmovaps xmm8, [rsp+0x80]
00007fa22efe18e7  vmovaps xmm9, [rsp+0x90]
00007fa22efe18f0  vmovaps xmm10, [rsp+0xA0]
00007fa22efe18f9  vmovaps xmm11, [rsp+0xB0]
00007fa22efe1902  vmovaps xmm12, [rsp+0xC0]
00007fa22efe190b  vmovaps xmm13, [rsp+0xD0]
00007fa22efe1914  vmovaps xmm15, [rsp+0xE0]
00007fa22efe191d  add rsp, 0xF0
00007fa22efe1924  pop r11
00007fa22efe1926  pop r10
00007fa22efe1928  pop r9
00007fa22efe192a  pop r8
00007fa22efe192c  pop rsi
00007fa22efe192d  pop rdi
00007fa22efe192e  pop rdx
00007fa22efe192f  pop rcx
00007fa22efe1930  pop rax
00007fa22efe1931  add rsp, 0x08
00007fa22efe1935  jmp 0x00007FA22EFDC843
00007fa22efe193a  sub rsp, 0x08
00007fa22efe193e  push rax
00007fa22efe193f  push rcx
00007fa22efe1940  push rdx
00007fa22efe1941  push rdi
00007fa22efe1942  push rsi
00007fa22efe1943  push r8
00007fa22efe1945  push r9
00007fa22efe1947  push r10
00007fa22efe1949  push r11
00007fa22efe194b  sub rsp, 0xF0
00007fa22efe1952  vmovaps [rsp], xmm0
00007fa22efe1957  vmovaps [rsp+0x10], xmm2
00007fa22efe195d  vmovaps [rsp+0x20], xmm3
00007fa22efe1963  vmovaps [rsp+0x30], xmm4
00007fa22efe1969  vmovaps [rsp+0x40], xmm5
00007fa22efe196f  vmovaps [rsp+0x50], xmm6
00007fa22efe1975  vmovaps [rsp+0x60], xmm7
00007fa22efe197b  vmovaps [rsp+0x70], xmm8
00007fa22efe1981  vmovaps [rsp+0x80], xmm9
00007fa22efe198a  vmovaps [rsp+0x90], xmm10
00007fa22efe1993  vmovaps [rsp+0xA0], xmm11
00007fa22efe199c  vmovaps [rsp+0xB0], xmm12
00007fa22efe19a5  vmovaps [rsp+0xC0], xmm13
00007fa22efe19ae  vmovaps [rsp+0xD0], xmm14
00007fa22efe19b7  vmovaps [rsp+0xE0], xmm15
00007fa22efe19c0  sub rsp, 0x30
00007fa22efe19c4  movaps [rsp], xmm1
00007fa22efe19c8  movaps [rsp+0x10], xmm8
00007fa22efe19ce  movaps [rsp+0x20], xmm9
00007fa22efe19d4  lea rdi, [rsp]
00007fa22efe19d8  mov esi, 0x00
00007fa22efe19dd  mov rax, 0x5E9D1A57D530
00007fa22efe19e7  call rax
00007fa22efe19e9  movaps xmm1, [rsp]
00007fa22efe19ed  add rsp, 0x30
00007fa22efe19f1  vmovaps xmm0, [rsp]
00007fa22efe19f6  vmovaps xmm2, [rsp+0x10]
00007fa22efe19fc  vmovaps xmm3, [rsp+0x20]
00007fa22efe1a02  vmovaps xmm4, [rsp+0x30]
00007fa22efe1a08  vmovaps xmm5, [rsp+0x40]
00007fa22efe1a0e  vmovaps xmm6, [rsp+0x50]
00007fa22efe1a14  vmovaps xmm7, [rsp+0x60]
00007fa22efe1a1a  vmovaps xmm8, [rsp+0x70]
00007fa22efe1a20  vmovaps xmm9, [rsp+0x80]
00007fa22efe1a29  vmovaps xmm10, [rsp+0x90]
00007fa22efe1a32  vmovaps xmm11, [rsp+0xA0]
00007fa22efe1a3b  vmovaps xmm12, [rsp+0xB0]
00007fa22efe1a44  vmovaps xmm13, [rsp+0xC0]
00007fa22efe1a4d  vmovaps xmm14, [rsp+0xD0]
00007fa22efe1a56  vmovaps xmm15, [rsp+0xE0]
00007fa22efe1a5f  add rsp, 0xF0
00007fa22efe1a66  pop r11
00007fa22efe1a68  pop r10
00007fa22efe1a6a  pop r9
00007fa22efe1a6c  pop r8
00007fa22efe1a6e  pop rsi
00007fa22efe1a6f  pop rdi
00007fa22efe1a70  pop rdx
00007fa22efe1a71  pop rcx
00007fa22efe1a72  pop rax
00007fa22efe1a73  add rsp, 0x08
00007fa22efe1a77  jmp 0x00007FA22EFDC865
00007fa22efe1a7c  call 0x00007FA22EEE5940
00007fa22efe1a81  jmp 0x00007FA22EFDC873
00007fa22efe1a86  call 0x00007FA22EE0C380
00007fa22efe1a8b  jmp 0x00007FA22EFDC87D
00007fa22efe1a90  call 0x00007FA22EE0D600
00007fa22efe1a95  jmp 0x00007FA22EFDC887
00007fa22efe1a9a  call 0x00007FA22EDFF540
00007fa22efe1a9f  jmp 0x00007FA22EFDC891
00007fa22efe1aa4  int3
00007fa22efe1aa5  nop [rax+rax*1], ax
00007fa22efe1aae  nop
00007fa22efe1ab0  mov rax, [r15+0xF8]
00007fa22efe1ab7  lea r14, [rax+0x140]
00007fa22efe1abe  mov r12, [r13+r14*1]
00007fa22efe1ac3  mov [r15+0xE8], r12
00007fa22efe1aca  lea r14, [rax+0x130]
00007fa22efe1ad1  mov r12, [r13+r14*1]
00007fa22efe1ad6  lea r14, [rax+0x138]
00007fa22efe1add  mov r11, [r13+r14*1]
00007fa22efe1ae2  movq xmm1, r12
00007fa22efe1ae7  movq xmm15, r11
00007fa22efe1aec  movq xmm1, xmm1
00007fa22efe1af0  movq xmm1, xmm1
00007fa22efe1af4  movaps [r15+0x1A0], xmm1
00007fa22efe1afc  movq xmm15, xmm15
00007fa22efe1b01  movq xmm15, xmm15
00007fa22efe1b06  movaps [r15+0x190], xmm15
00007fa22efe1b0e  lea r14, [rax+0x120]
00007fa22efe1b15  mov r12, [r13+r14*1]
00007fa22efe1b1a  lea r14, [rax+0x128]
00007fa22efe1b21  mov r11, [r13+r14*1]
00007fa22efe1b26  movq xmm1, r12
00007fa22efe1b2b  movq xmm15, r11
00007fa22efe1b30  movq xmm1, xmm1
00007fa22efe1b34  movq xmm1, xmm1
00007fa22efe1b38  movaps [r15+0x1C0], xmm1
00007fa22efe1b40  movq xmm15, xmm15
00007fa22efe1b45  movq xmm15, xmm15
00007fa22efe1b4a  movaps [r15+0x1B0], xmm15
00007fa22efe1b52  lea r14, [rax+0x110]
00007fa22efe1b59  mov r12, [r13+r14*1]
00007fa22efe1b5e  lea r14, [rax+0x118]
00007fa22efe1b65  mov r11, [r13+r14*1]
00007fa22efe1b6a  movq xmm1, r12
00007fa22efe1b6f  movq xmm15, r11
00007fa22efe1b74  movq xmm1, xmm1
00007fa22efe1b78  movq xmm1, xmm1
00007fa22efe1b7c  movaps [r15+0x1E0], xmm1
00007fa22efe1b84  movq xmm15, xmm15
00007fa22efe1b89  movq xmm15, xmm15
00007fa22efe1b8e  movaps [r15+0x1D0], xmm15
00007fa22efe1b96  lea r14, [rax+0x100]
00007fa22efe1b9d  mov r12, [r13+r14*1]
00007fa22efe1ba2  lea r14, [rax+0x108]
00007fa22efe1ba9  mov r11, [r13+r14*1]
00007fa22efe1bae  movq xmm1, r12
00007fa22efe1bb3  movq xmm15, r11
00007fa22efe1bb8  movq xmm1, xmm1
00007fa22efe1bbc  movq xmm1, xmm1
00007fa22efe1bc0  movaps [r15+0x200], xmm1
00007fa22efe1bc8  movq xmm15, xmm15
00007fa22efe1bcd  movq xmm15, xmm15
00007fa22efe1bd2  movaps [r15+0x1F0], xmm15
00007fa22efe1bda  mov qword ptr [r15+0x40], 0x430000
00007fa22efe1be2  mov r14d, 0x430510
00007fa22efe1be8  mov r12, [r13+r14*1]
00007fa22efe1bed  movq xmm1, r12
00007fa22efe1bf2  lea r14, [rax+0x150]
00007fa22efe1bf9  mov [r15+0xF8], r14
00007fa22efe1c00  mov rax, [r15+0x50]
00007fa22efe1c04  movups xmm15, [r13+rax*1]
00007fa22efe1c0a  movaps [r15+0x120], xmm15
00007fa22efe1c12  mov qword ptr [r15+0x48], 0x10
00007fa22efe1c1a  xor eax, eax
00007fa22efe1c1c  mov r14d, 0x10
00007fa22efe1c22  mov r12d, 0x200
00007fa22efe1c28  cmp r14, r12
00007fa22efe1c2b  cmc
00007fa22efe1c2c  lahf
00007fa22efe1c2d  seto al
00007fa22efe1c30  mov [r15+0x108], eax
00007fa22efe1c37  pextrq rax, xmm15, 0x01
00007fa22efe1c3e  movq xmm14, rax
00007fa22efe1c43  movaps [r15+0x130], xmm14
00007fa22efe1c4b  movq rax, xmm1
00007fa22efe1c50  movq r14, xmm15
00007fa22efe1c55  vmovq xmm1, rax
00007fa22efe1c5a  vmovq xmm15, r14
00007fa22efe1c5f  movaps xmm13, xmm1
00007fa22efe1c63  addsd xmm13, xmm15
00007fa22efe1c68  ucomisd xmm13, xmm13
00007fa22efe1c6d  jp 0x00007FA22EFE1D86
00007fa22efe1c73  movq xmm13, xmm13
00007fa22efe1c78  movq rax, xmm13
00007fa22efe1c7d  movq r14, xmm14
00007fa22efe1c82  vmovq xmm1, rax
00007fa22efe1c87  vmovq xmm15, r14
00007fa22efe1c8c  movaps xmm14, xmm1
00007fa22efe1c90  addsd xmm14, xmm15
00007fa22efe1c95  ucomisd xmm14, xmm14
00007fa22efe1c9a  jp 0x00007FA22EFE1DCE
00007fa22efe1ca0  movq xmm14, xmm14
00007fa22efe1ca5  movaps [r15+0x110], xmm14
00007fa22efe1cad  mov eax, [r15+0x108]
00007fa22efe1cb4  sahf
00007fa22efe1cb5  jnz 0x00007FA22EFE1CE7
00007fa22efe1cb7  cmp dword ptr [r15+0x318], 0x00
00007fa22efe1cbf  jz 0x00007FA22EFE1FE0
00007fa22efe1cc5  nop [rax+rax*1], ax
00007fa22efe1cce  nop [rax+rax*1], eax
00007fa22efe1cd6  mov eax, 0x410490
00007fa22efe1cdb  mov [r15+0x100], rax
00007fa22efe1ce2  jmp 0x00007FA22EDFE110
00007fa22efe1ce7  cmp dword ptr [r15+0x318], 0x00
00007fa22efe1cef  jz 0x00007FA22EFE1E20
00007fa22efe1cf5  nop [rax+rax*1], ax
00007fa22efe1cfe  nop [rax+rax*1], eax
00007fa22efe1d06  mov eax, 0x410474
00007fa22efe1d0b  mov [r15+0x100], rax
00007fa22efe1d12  jmp 0x00007FA22EDFE110
00007fa22efe1d17  int3
00007fa22efe1d18  call 0x00007FA22EEE27E0
00007fa22efe1d1d  jmp 0x00007FA22EFE1AC3
00007fa22efe1d22  call 0x00007FA22EEE27E0
00007fa22efe1d27  jmp 0x00007FA22EFE1AD6
00007fa22efe1d2c  call 0x00007FA22EEE1570
00007fa22efe1d31  jmp 0x00007FA22EFE1AE2
00007fa22efe1d36  call 0x00007FA22EEE27E0
00007fa22efe1d3b  jmp 0x00007FA22EFE1B1A
00007fa22efe1d40  call 0x00007FA22EEE1570
00007fa22efe1d45  jmp 0x00007FA22EFE1B26
00007fa22efe1d4a  call 0x00007FA22EEE27E0
00007fa22efe1d4f  jmp 0x00007FA22EFE1B5E
00007fa22efe1d54  call 0x00007FA22EEE1570
00007fa22efe1d59  jmp 0x00007FA22EFE1B6A
00007fa22efe1d5e  call 0x00007FA22EEE27E0
00007fa22efe1d63  jmp 0x00007FA22EFE1BA2
00007fa22efe1d68  call 0x00007FA22EEE1570
00007fa22efe1d6d  jmp 0x00007FA22EFE1BAE
00007fa22efe1d72  call 0x00007FA22EEE27E0
00007fa22efe1d77  jmp 0x00007FA22EFE1BED
00007fa22efe1d7c  call 0x00007FA22EE0E760
00007fa22efe1d81  jmp 0x00007FA22EFE1C0A
00007fa22efe1d86  ucomisd xmm1, xmm15
00007fa22efe1d8b  jp 0x00007FA22EFE1D9A
00007fa22efe1d8d  movaps xmm13, [0x00007FA22EBFE060]
00007fa22efe1d95  jmp 0x00007FA22EFE1C73
00007fa22efe1d9a  vxorps xmm0, xmm1, xmm15
00007fa22efe1d9f  pextrw eax, xmm0, 0x03
00007fa22efe1da4  and eax, 0x7FF8
00007fa22efe1da9  cmp eax, 0x08
00007fa22efe1dac  jnz 0x00007FA22EFE1C73
00007fa22efe1db2  movq rax, xmm15
00007fa22efe1db7  shl rax, 0x0D
00007fa22efe1dbb  jbe 0x00007FA22EFE1C73
00007fa22efe1dc1  vorps xmm13, xmm15, [0x00007FA22EBFE070]
00007fa22efe1dc9  jmp 0x00007FA22EFE1C73
00007fa22efe1dce  ucomisd xmm1, xmm15
00007fa22efe1dd3  jp 0x00007FA22EFE1DE2
00007fa22efe1dd5  movaps xmm14, [0x00007FA22EBFE060]
00007fa22efe1ddd  jmp 0x00007FA22EFE1CA0
00007fa22efe1de2  vxorps xmm0, xmm1, xmm15
00007fa22efe1de7  pextrw eax, xmm0, 0x03
00007fa22efe1dec  and eax, 0x7FF8
00007fa22efe1df1  cmp eax, 0x08
00007fa22efe1df4  jnz 0x00007FA22EFE1CA0
00007fa22efe1dfa  movq rax, xmm15
00007fa22efe1dff  shl rax, 0x0D
00007fa22efe1e03  jbe 0x00007FA22EFE1CA0
00007fa22efe1e09  vorps xmm14, xmm15, [0x00007FA22EBFE070]
00007fa22efe1e11  jmp 0x00007FA22EFE1CA0
00007fa22efe1e16  int3
00007fa22efe1e17  nop [rax+rax*1], ax
00007fa22efe1e20  mov rax, [r15+0x48]
00007fa22efe1e24  mov r14, [r15+0x50]
00007fa22efe1e28  lea r12, [r14+rax*1]
00007fa22efe1e2c  movups xmm1, [r13+r12*1]
00007fa22efe1e32  movaps [r15+0x120], xmm1
00007fa22efe1e3a  lea r14, [rax+0x10]
00007fa22efe1e3e  mov [r15+0x48], r14
00007fa22efe1e42  xor eax, eax
00007fa22efe1e44  mov r12d, 0x200
00007fa22efe1e4a  cmp r14, r12
00007fa22efe1e4d  cmc
00007fa22efe1e4e  lahf
00007fa22efe1e4f  seto al
00007fa22efe1e52  mov [r15+0x108], eax
00007fa22efe1e59  pextrq rax, xmm1, 0x01
00007fa22efe1e60  movq xmm15, rax
00007fa22efe1e65  movaps [r15+0x130], xmm15
00007fa22efe1e6d  movaps xmm14, [r15+0x110]
00007fa22efe1e75  movq rax, xmm14
00007fa22efe1e7a  movq r14, xmm1
00007fa22efe1e7f  vmovq xmm1, rax
00007fa22efe1e84  vmovq xmm14, r14
00007fa22efe1e89  movaps xmm13, xmm1
00007fa22efe1e8d  addsd xmm13, xmm14
00007fa22efe1e92  ucomisd xmm13, xmm13
00007fa22efe1e97  jp 0x00007FA22EFE1F4C
00007fa22efe1e9d  movq xmm13, xmm13
00007fa22efe1ea2  movq rax, xmm13
00007fa22efe1ea7  movq r14, xmm15
00007fa22efe1eac  vmovq xmm1, rax
00007fa22efe1eb1  vmovq xmm15, r14
00007fa22efe1eb6  movaps xmm14, xmm1
00007fa22efe1eba  addsd xmm14, xmm15
00007fa22efe1ebf  ucomisd xmm14, xmm14
00007fa22efe1ec4  jp 0x00007FA22EFE1F94
00007fa22efe1eca  movq xmm14, xmm14
00007fa22efe1ecf  movaps [r15+0x110], xmm14
00007fa22efe1ed7  mov eax, [r15+0x108]
00007fa22efe1ede  sahf
00007fa22efe1edf  jnz 0x00007FA22EFE1F11
00007fa22efe1ee1  cmp dword ptr [r15+0x318], 0x00
00007fa22efe1ee9  jz 0x00007FA22EFE1FE0
00007fa22efe1eef  nop [rax+rax*1], ax
00007fa22efe1ef8  nop [rax+rax*1], eax
00007fa22efe1f00  mov eax, 0x410490
00007fa22efe1f05  mov [r15+0x100], rax
00007fa22efe1f0c  jmp 0x00007FA22EDFE110
00007fa22efe1f11  cmp dword ptr [r15+0x318], 0x00
00007fa22efe1f19  jz 0x00007FA22EFE1E20
00007fa22efe1f1f  nop [rax+rax*1], ax
00007fa22efe1f28  nop [rax+rax*1], eax
00007fa22efe1f30  mov eax, 0x410474
00007fa22efe1f35  mov [r15+0x100], rax
00007fa22efe1f3c  jmp 0x00007FA22EDFE110
00007fa22efe1f41  int3
00007fa22efe1f42  call 0x00007FA22EEB52F0
00007fa22efe1f47  jmp 0x00007FA22EFE1E32
00007fa22efe1f4c  ucomisd xmm1, xmm14
00007fa22efe1f51  jp 0x00007FA22EFE1F60
00007fa22efe1f53  movaps xmm13, [0x00007FA22EBFE060]
00007fa22efe1f5b  jmp 0x00007FA22EFE1E9D
00007fa22efe1f60  vxorps xmm0, xmm1, xmm14
00007fa22efe1f65  pextrw eax, xmm0, 0x03
00007fa22efe1f6a  and eax, 0x7FF8
00007fa22efe1f6f  cmp eax, 0x08
00007fa22efe1f72  jnz 0x00007FA22EFE1E9D
00007fa22efe1f78  movq rax, xmm14
00007fa22efe1f7d  shl rax, 0x0D
00007fa22efe1f81  jbe 0x00007FA22EFE1E9D
00007fa22efe1f87  vorps xmm13, xmm14, [0x00007FA22EBFE070]
00007fa22efe1f8f  jmp 0x00007FA22EFE1E9D
00007fa22efe1f94  ucomisd xmm1, xmm15
00007fa22efe1f99  jp 0x00007FA22EFE1FA8
00007fa22efe1f9b  movaps xmm14, [0x00007FA22EBFE060]
00007fa22efe1fa3  jmp 0x00007FA22EFE1ECA
00007fa22efe1fa8  vxorps xmm0, xmm1, xmm15
00007fa22efe1fad  pextrw eax, xmm0, 0x03
00007fa22efe1fb2  and eax, 0x7FF8
00007fa22efe1fb7  cmp eax, 0x08
00007fa22efe1fba  jnz 0x00007FA22EFE1ECA
00007fa22efe1fc0  movq rax, xmm15
00007fa22efe1fc5  shl rax, 0x0D
00007fa22efe1fc9  jbe 0x00007FA22EFE1ECA
00007fa22efe1fcf  vorps xmm14, xmm15, [0x00007FA22EBFE070]
00007fa22efe1fd7  jmp 0x00007FA22EFE1ECA
00007fa22efe1fdc  int3
00007fa22efe1fdd  nop [rax], eax
00007fa22efe1fe0  mov rax, [r15+0x40]
00007fa22efe1fe4  lea r14, [rax+0x510]
00007fa22efe1feb  movaps xmm1, [r15+0x110]
00007fa22efe1ff3  movq rax, xmm1
00007fa22efe1ff8  mov [r13+r14*1], rax
00007fa22efe1ffd  mov rax, [r15+0xF0]
00007fa22efe2004  mov [r15+0x100], rax
00007fa22efe200b  jmp 0x00007FA22EFCE5C0
00007fa22efe2010  int3
00007fa22efe2011  call 0x00007FA22EED5EB0
00007fa22efe2016  jmp 0x00007FA22EFE1FFD
00007fa22efe201b  int3
00007fa22efe201c  nop [rax], eax
00007fa22efe2020  mov qword ptr [r15+0x100], 0x04
00007fa22efe202b  mov esi, 0x00
00007fa22efe2030  mov edx, 0x09
00007fa22efe2035  mov rdi, 0x7FFC875D0150
00007fa22efe203f  mov rax, 0x5E9D1A410970
00007fa22efe2049  call rax
00007fa22efe204b  cmp dword ptr [r15+0x318], 0x00
00007fa22efe2053  jnz 0x00007FA22EDFE110
00007fa22efe2059  jmp 0x00007FA22EDFE0A0
00007fa22efe205e  int3
00007fa22efe205f  int3
