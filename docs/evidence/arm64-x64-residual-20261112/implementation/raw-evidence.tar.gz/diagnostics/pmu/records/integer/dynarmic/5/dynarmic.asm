00007dac12bce69b  nop [rax+rax*1], eax
00007dac12bce6a0  mov qword ptr [r15+0x20], 0x420060
00007dac12bce6a8  mov qword ptr [r15], 0x03
00007dac12bce6af  xor eax, eax
00007dac12bce6b1  mov r14d, 0xB71B00
00007dac12bce6b7  mov r12d, 0x01
00007dac12bce6bd  sub r14, r12
00007dac12bce6c0  cmc
00007dac12bce6c1  lahf
00007dac12bce6c2  seto al
00007dac12bce6c5  mov [r15+0x108], eax
00007dac12bce6cc  mov [r15+0x08], r14
00007dac12bce6d0  mov eax, [r15+0x108]
00007dac12bce6d7  sahf
00007dac12bce6d8  jnz 0x00007DAC12BCE70A
00007dac12bce6da  cmp dword ptr [r15+0x318], 0x00
00007dac12bce6e2  jz 0x00007DAC12BCE7F0
00007dac12bce6e8  nop [rax+rax*1], ax
00007dac12bce6f1  nop [rax+rax*1], eax
00007dac12bce6f9  mov eax, 0x41004C
00007dac12bce6fe  mov [r15+0x100], rax
00007dac12bce705  jmp 0x00007DAC129FE110
00007dac12bce70a  cmp dword ptr [r15+0x318], 0x00
00007dac12bce712  jz 0x00007DAC12BCE740
00007dac12bce718  nop [rax+rax*1], ax
00007dac12bce721  nop [rax+rax*1], eax
00007dac12bce729  mov eax, 0x41003C
00007dac12bce72e  mov [r15+0x100], rax
00007dac12bce735  jmp 0x00007DAC129FE110
00007dac12bce73a  int3
00007dac12bce73b  int3
00007dac12bce73c  nop [rax], eax
00007dac12bce740  mov rax, [r15]
00007dac12bce743  lea r14, [rax+0x03]
00007dac12bce747  mov [rsp+0x10], r14
00007dac12bce74c  shr r14, 0x07
00007dac12bce750  mov rax, [rsp+0x10]
00007dac12bce755  xor rax, r14
00007dac12bce758  mov [r15], rax
00007dac12bce75b  mov rax, [r15+0x08]
00007dac12bce75f  mov [rsp+0x10], rax
00007dac12bce764  xor eax, eax
00007dac12bce766  mov r14, [rsp+0x10]
00007dac12bce76b  mov r12d, 0x01
00007dac12bce771  sub r14, r12
00007dac12bce774  cmc
00007dac12bce775  lahf
00007dac12bce776  seto al
00007dac12bce779  mov [r15+0x108], eax
00007dac12bce780  mov [r15+0x08], r14
00007dac12bce784  mov eax, [r15+0x108]
00007dac12bce78b  sahf
00007dac12bce78c  jnz 0x00007DAC12BCE7BE
00007dac12bce78e  cmp dword ptr [r15+0x318], 0x00
00007dac12bce796  jz 0x00007DAC12BCE7F0
00007dac12bce79c  nop [rax+rax*1], ax
00007dac12bce7a5  nop [rax+rax*1], eax
00007dac12bce7ad  mov eax, 0x41004C
00007dac12bce7b2  mov [r15+0x100], rax
00007dac12bce7b9  jmp 0x00007DAC129FE110
00007dac12bce7be  cmp dword ptr [r15+0x318], 0x00
00007dac12bce7c6  jz 0x00007DAC12BCE740
00007dac12bce7cc  nop [rax+rax*1], ax
00007dac12bce7d5  nop [rax+rax*1], eax
00007dac12bce7dd  mov eax, 0x41003C
00007dac12bce7e2  mov [r15+0x100], rax
00007dac12bce7e9  jmp 0x00007DAC129FE110
00007dac12bce7ee  int3
00007dac12bce7ef  int3
00007dac12bce7f0  mov rax, [r15+0x20]
00007dac12bce7f4  mov r14, [r15]
00007dac12bce7f7  mov [r13+rax*1], r14
00007dac12bce7fc  mov rax, [r15+0xF0]
00007dac12bce803  mov [r15+0x100], rax
00007dac12bce80a  jmp 0x00007DAC12BCE5C0
00007dac12bce80f  int3
00007dac12bce810  call 0x00007DAC12A0E120
00007dac12bce815  jmp 0x00007DAC12BCE7FC
00007dac12bce81a  int3
00007dac12bce81b  nop [rax+rax*1], eax
00007dac12bce820  mov qword ptr [r15+0x100], 0x04
00007dac12bce82b  mov esi, 0x00
00007dac12bce830  mov edx, 0x09
00007dac12bce835  mov rdi, 0x7FFD7AB2C1B0
00007dac12bce83f  mov rax, 0x598A2FE74970
00007dac12bce849  call rax
00007dac12bce84b  cmp dword ptr [r15+0x318], 0x00
00007dac12bce853  jnz 0x00007DAC129FE110
00007dac12bce859  jmp 0x00007DAC129FE0A0
00007dac12bce85e  int3
00007dac12bce85f  int3
