00007eac303ce69b  nop [rax+rax*1], eax
00007eac303ce6a0  mov qword ptr [r15+0x20], 0x420060
00007eac303ce6a8  mov qword ptr [r15], 0x03
00007eac303ce6af  xor eax, eax
00007eac303ce6b1  mov r14d, 0xB71B00
00007eac303ce6b7  mov r12d, 0x01
00007eac303ce6bd  sub r14, r12
00007eac303ce6c0  cmc
00007eac303ce6c1  lahf
00007eac303ce6c2  seto al
00007eac303ce6c5  mov [r15+0x108], eax
00007eac303ce6cc  mov [r15+0x08], r14
00007eac303ce6d0  mov eax, [r15+0x108]
00007eac303ce6d7  sahf
00007eac303ce6d8  jnz 0x00007EAC303CE70A
00007eac303ce6da  cmp dword ptr [r15+0x318], 0x00
00007eac303ce6e2  jz 0x00007EAC303CE7F0
00007eac303ce6e8  nop [rax+rax*1], ax
00007eac303ce6f1  nop [rax+rax*1], eax
00007eac303ce6f9  mov eax, 0x41004C
00007eac303ce6fe  mov [r15+0x100], rax
00007eac303ce705  jmp 0x00007EAC301FE110
00007eac303ce70a  cmp dword ptr [r15+0x318], 0x00
00007eac303ce712  jz 0x00007EAC303CE740
00007eac303ce718  nop [rax+rax*1], ax
00007eac303ce721  nop [rax+rax*1], eax
00007eac303ce729  mov eax, 0x41003C
00007eac303ce72e  mov [r15+0x100], rax
00007eac303ce735  jmp 0x00007EAC301FE110
00007eac303ce73a  int3
00007eac303ce73b  int3
00007eac303ce73c  nop [rax], eax
00007eac303ce740  mov rax, [r15]
00007eac303ce743  lea r14, [rax+0x03]
00007eac303ce747  mov [rsp+0x10], r14
00007eac303ce74c  shr r14, 0x07
00007eac303ce750  mov rax, [rsp+0x10]
00007eac303ce755  xor rax, r14
00007eac303ce758  mov [r15], rax
00007eac303ce75b  mov rax, [r15+0x08]
00007eac303ce75f  mov [rsp+0x10], rax
00007eac303ce764  xor eax, eax
00007eac303ce766  mov r14, [rsp+0x10]
00007eac303ce76b  mov r12d, 0x01
00007eac303ce771  sub r14, r12
00007eac303ce774  cmc
00007eac303ce775  lahf
00007eac303ce776  seto al
00007eac303ce779  mov [r15+0x108], eax
00007eac303ce780  mov [r15+0x08], r14
00007eac303ce784  mov eax, [r15+0x108]
00007eac303ce78b  sahf
00007eac303ce78c  jnz 0x00007EAC303CE7BE
00007eac303ce78e  cmp dword ptr [r15+0x318], 0x00
00007eac303ce796  jz 0x00007EAC303CE7F0
00007eac303ce79c  nop [rax+rax*1], ax
00007eac303ce7a5  nop [rax+rax*1], eax
00007eac303ce7ad  mov eax, 0x41004C
00007eac303ce7b2  mov [r15+0x100], rax
00007eac303ce7b9  jmp 0x00007EAC301FE110
00007eac303ce7be  cmp dword ptr [r15+0x318], 0x00
00007eac303ce7c6  jz 0x00007EAC303CE740
00007eac303ce7cc  nop [rax+rax*1], ax
00007eac303ce7d5  nop [rax+rax*1], eax
00007eac303ce7dd  mov eax, 0x41003C
00007eac303ce7e2  mov [r15+0x100], rax
00007eac303ce7e9  jmp 0x00007EAC301FE110
00007eac303ce7ee  int3
00007eac303ce7ef  int3
00007eac303ce7f0  mov rax, [r15+0x20]
00007eac303ce7f4  mov r14, [r15]
00007eac303ce7f7  mov [r13+rax*1], r14
00007eac303ce7fc  mov rax, [r15+0xF0]
00007eac303ce803  mov [r15+0x100], rax
00007eac303ce80a  jmp 0x00007EAC303CE5C0
00007eac303ce80f  int3
00007eac303ce810  call 0x00007EAC3020E120
00007eac303ce815  jmp 0x00007EAC303CE7FC
00007eac303ce81a  int3
00007eac303ce81b  nop [rax+rax*1], eax
00007eac303ce820  mov qword ptr [r15+0x100], 0x04
00007eac303ce82b  mov esi, 0x00
00007eac303ce830  mov edx, 0x09
00007eac303ce835  mov rdi, 0x7FFE63ACFAF0
00007eac303ce83f  mov rax, 0x5F6554996970
00007eac303ce849  call rax
00007eac303ce84b  cmp dword ptr [r15+0x318], 0x00
00007eac303ce853  jnz 0x00007EAC301FE110
00007eac303ce859  jmp 0x00007EAC301FE0A0
00007eac303ce85e  int3
00007eac303ce85f  int3
