
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/candidate/0/7.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xa0]
  18:	mov    r14,r13
  1b:	shl    r14,0x2
  1f:	mov    r15,QWORD PTR [r12+0x98]
  27:	add    r15,r14
  2a:	mov    r14d,DWORD PTR [r12]
  2e:	mov    DWORD PTR [r15],r14d
  31:	mov    r14d,0x0
  37:	mov    DWORD PTR [r12+0x32c],r14d
  3f:	add    r13,0x1
  43:	mov    QWORD PTR [r12+0xa0],r13
  4b:	sub    r13,0x400
  52:	mov    rcx,QWORD PTR [r12+0x380]
  5a:	jrcxz  0x61
  5c:	jmp    0x43d
  61:	jne    0x7a
  67:	mov    r11,rax
  6a:	lahf
  6b:	seto   al
  6e:	mov    WORD PTR [rsp],ax
  72:	mov    rax,r11
  75:	jmp    0x8d
  7a:	mov    r11,rax
  7d:	lahf
  7e:	seto   al
  81:	mov    WORD PTR [rsp],ax
  85:	mov    rax,r11
  88:	jmp    0x3cd
  8d:	mov    r13d,0x1
  93:	mov    QWORD PTR [r12+0x40],r13
  98:	mov    r11,rax
  9b:	movzx  eax,WORD PTR [rsp]
  9f:	add    al,0x7f
  a1:	sahf
  a2:	mov    rax,r11
  a5:	jmp    0xaa
  aa:	mov    r13,QWORD PTR [r12+0x40]
  af:	mov    r14,r13
  b2:	lea    r14,[r14*4+0x0]
  ba:	mov    r15,QWORD PTR [r12+0x98]
  c2:	mov    r11,rax
  c5:	lahf
  c6:	seto   al
  c9:	mov    WORD PTR [rsp],ax
  cd:	mov    rax,r11
  d0:	add    r15,r14
  d3:	mov    r14d,DWORD PTR [r15]
  d6:	mov    QWORD PTR [r12+0x48],r14
  db:	mov    r14d,0x0
  e1:	or     r14,r13
  e4:	mov    QWORD PTR [r12+0x50],r14
  e9:	jmp    0xee
  ee:	mov    r13d,DWORD PTR [r12+0x50]
  f3:	sub    r13d,0x1
  f7:	mov    QWORD PTR [r12+0x58],r13
  fc:	mov    ecx,0xffffffff
 101:	mov    r14,r13
 104:	and    r14,rcx
 107:	shl    r14,0x2
 10b:	mov    r13,QWORD PTR [r12+0x98]
 113:	add    r13,r14
 116:	mov    r14d,DWORD PTR [r13+0x0]
 11a:	mov    QWORD PTR [r12+0x60],r14
 11f:	mov    r13d,DWORD PTR [r12+0x48]
 124:	sub    r14d,r13d
 127:	mov    rcx,QWORD PTR [r12+0x380]
 12f:	jrcxz  0x136
 131:	jmp    0x4ce
 136:	jbe    0x14f
 13c:	mov    r11,rax
 13f:	lahf
 140:	seto   al
 143:	mov    WORD PTR [rsp],ax
 147:	mov    rax,r11
 14a:	jmp    0x162
 14f:	mov    r11,rax
 152:	lahf
 153:	seto   al
 156:	mov    WORD PTR [rsp],ax
 15a:	mov    rax,r11
 15d:	jmp    0x1e1
 162:	mov    r13,QWORD PTR [r12+0x50]
 167:	mov    r14,r13
 16a:	shl    r14,0x2
 16e:	mov    r15,QWORD PTR [r12+0x98]
 176:	add    r15,r14
 179:	mov    r14d,DWORD PTR [r12+0x60]
 17e:	mov    DWORD PTR [r15],r14d
 181:	mov    r14d,0x0
 187:	mov    DWORD PTR [r12+0x32c],r14d
 18f:	sub    r13,0x1
 193:	mov    QWORD PTR [r12+0x50],r13
 198:	mov    rcx,QWORD PTR [r12+0x380]
 1a0:	jrcxz  0x1a7
 1a2:	jmp    0x55f
 1a7:	mov    r13,QWORD PTR [r12+0x58]
 1ac:	mov    rax,r13
 1af:	test   rax,rax
 1b2:	jne    0xee
 1b8:	jmp    0x1bd
 1bd:	mov    rcx,QWORD PTR [r12+0x380]
 1c5:	jrcxz  0x1cc
 1c7:	jmp    0x5e1
 1cc:	jmp    0x1d1
 1d1:	mov    r13d,0x0
 1d7:	mov    QWORD PTR [r12+0x50],r13
 1dc:	jmp    0x1e1
 1e1:	mov    r13,QWORD PTR [r12+0x40]
 1e6:	add    r13,0x1
 1ea:	mov    QWORD PTR [r12+0x40],r13
 1ef:	mov    r14,QWORD PTR [r12+0x50]
 1f4:	mov    ecx,0xffffffff
 1f9:	and    r14,rcx
 1fc:	shl    r14,0x2
 200:	mov    r15,QWORD PTR [r12+0x98]
 208:	add    r15,r14
 20b:	mov    r14d,DWORD PTR [r12+0x48]
 210:	mov    DWORD PTR [r15],r14d
 213:	mov    r14d,0x0
 219:	mov    DWORD PTR [r12+0x32c],r14d
 221:	sub    r13,0x400
 228:	jne    0xaa
 22e:	mov    r11,rax
 231:	lahf
 232:	seto   al
 235:	mov    WORD PTR [rsp],ax
 239:	mov    rax,r11
 23c:	jmp    0x241
 241:	mov    r13d,0x430000
 247:	mov    QWORD PTR [r12+0x40],r13
 24c:	mov    r13d,0x0
 252:	mov    QWORD PTR [r12+0x58],r13
 257:	mov    r13d,0x0
 25d:	mov    QWORD PTR [r12+0x50],r13
 262:	mov    r13d,0x430cb0
 268:	mov    r14,QWORD PTR [r13+0x0]
 26c:	mov    QWORD PTR [r12+0x48],r14
 271:	jmp    0x276
 276:	mov    r13,QWORD PTR [r12+0x58]
 27b:	mov    r14,r13
 27e:	shl    r14,0x2
 282:	mov    r15,QWORD PTR [r12+0x98]
 28a:	add    r15,r14
 28d:	mov    QWORD PTR [r12+0x60],r15
 292:	mov    r14,r15
 295:	add    r14,0x4
 299:	mov    ebp,DWORD PTR [r15]
 29c:	mov    r15d,DWORD PTR [r14]
 29f:	mov    QWORD PTR [r12+0x60],r15
 2a4:	mov    r14,rbp
 2a7:	imul   r14,r13
 2ab:	mov    r8,rbp
 2ae:	add    r8,r14
 2b1:	mov    QWORD PTR [r12+0x68],r8
 2b6:	add    r13,0x2
 2ba:	mov    QWORD PTR [r12+0x58],r13
 2bf:	mov    r14,r13
 2c2:	sub    r14,0x400
 2c9:	mov    r14,QWORD PTR [r12+0x50]
 2ce:	setne  BYTE PTR [rsp+0x8]
 2d3:	mov    r11,rax
 2d6:	lahf
 2d7:	seto   al
 2da:	mov    WORD PTR [rsp],ax
 2de:	mov    rax,r11
 2e1:	imul   r13,r15
 2e5:	add    r14,r13
 2e8:	mov    QWORD PTR [r12+0x50],r14
 2ed:	mov    r13,QWORD PTR [r12+0x48]
 2f2:	add    r8,r13
 2f5:	mov    QWORD PTR [r12+0x48],r8
 2fa:	mov    rcx,QWORD PTR [r12+0x380]
 302:	jrcxz  0x309
 304:	jmp    0x663
 309:	cmp    BYTE PTR [rsp+0x8],0x0
 30e:	jne    0x276
 314:	jmp    0x319
 319:	mov    r13d,0x0
 31f:	mov    QWORD PTR [r12+0x98],r13
 327:	mov    r13,QWORD PTR [r12+0x48]
 32c:	mov    r14,QWORD PTR [r12+0x50]
 331:	add    r14,r13
 334:	mov    QWORD PTR [r12+0x48],r14
 339:	mov    r13d,0x1
 33f:	mov    QWORD PTR [r12],r13
 343:	mov    r13,QWORD PTR [r12+0x40]
 348:	add    r13,0xcb0
 34f:	mov    QWORD PTR [r13+0x0],r14
 353:	mov    r13d,0x0
 359:	mov    DWORD PTR [r12+0x32c],r13d
 361:	mov    r13d,0x1
 367:	mov    QWORD PTR [r12],r13
 36b:	mov    r13d,0x4103f8
 371:	mov    QWORD PTR [r12+0xf0],r13
 379:	mov    r13d,0x4109a4
 37f:	mov    QWORD PTR [r12+0x100],r13
 387:	mov    r11,QWORD PTR [rsp]
 38b:	mov    QWORD PTR [r12+0x398],r11
 393:	mov    edi,0x4109a4
 398:	mov    QWORD PTR [r12+0x100],rdi
 3a0:	add    rsp,0x10
 3a4:	nop    DWORD PTR [rax+0x0]
 3a8:	jmp    QWORD PTR [rip+0x2]        # 0x3b0
 3ae:	xchg   ax,ax
 3b0:	rex (bad)
 3b2:	xor    BYTE PTR [rax+rcx*1+0x7b],ch
 3b6:	add    BYTE PTR [rax],al
 3b8:	rcr    BYTE PTR [rax+rsi*1],1
 3bb:	ins    BYTE PTR es:[rdi],dx
 3bc:	or     BYTE PTR [rbx+0x0],bh
 3bf:	add    BYTE PTR [rcx-0x45],cl
 3c2:	rex stc
 3c4:	sub    BYTE PTR [rbp+0x590d],al
 3ca:	jmp    r11
 3cd:	mov    r13d,DWORD PTR [r12+0xa0]
 3d5:	add    r13d,0x11
 3d9:	mov    QWORD PTR [r12],r13
 3dd:	mov    r13d,0x41035c
 3e3:	mov    QWORD PTR [r12+0xf0],r13
 3eb:	mov    r13d,0x4109a4
 3f1:	mov    QWORD PTR [r12+0x100],r13
 3f9:	mov    r11,QWORD PTR [rsp]
 3fd:	mov    QWORD PTR [r12+0x398],r11
 405:	mov    edi,0x4109a4
 40a:	mov    QWORD PTR [r12+0x100],rdi
 412:	add    rsp,0x10
 416:	xchg   ax,ax
 418:	jmp    QWORD PTR [rip+0x2]        # 0x420
 41e:	xchg   ax,ax
 420:	rex (bad)
 422:	xor    BYTE PTR [rax+rcx*1+0x7b],ch
 426:	add    BYTE PTR [rax],al
 428:	rex sbb eax,0x7b086c30
 42e:	add    BYTE PTR [rax],al
 430:	movabs r11,0x590d8528f940
 43a:	jmp    r11
 43d:	mov    eax,0x410368
 442:	mov    QWORD PTR [r12+0x100],rax
 44a:	push   rdx
 44b:	push   rsi
 44c:	push   r10
 44e:	push   r11
 450:	mov    r11,rax
 453:	lahf
 454:	seto   al
 457:	mov    WORD PTR [rsp+0x20],ax
 45c:	mov    rax,r11
 45f:	mov    rdx,QWORD PTR [rsp+0x20]
 464:	mov    r10d,edx
 467:	and    r10d,0xc000
 46e:	shl    r10d,0x10
 472:	mov    r11d,edx
 475:	and    r11d,0x100
 47c:	shl    r11d,0x15
 480:	or     r10d,r11d
 483:	and    edx,0x1
 486:	shl    edx,0x1c
 489:	or     r10d,edx
 48c:	btc    r10,0x1d
 491:	mov    r11d,0xf0000000
 497:	and    r11,r10
 49a:	movabs rsi,0xffffffff0fffffff
 4a4:	and    rbx,rsi
 4a7:	or     rbx,r11
 4aa:	pop    r11
 4ac:	pop    r10
 4ae:	pop    rsi
 4af:	pop    rdx
 4b0:	mov    QWORD PTR [r12+0x108],rbx
 4b8:	add    rsp,0x10
 4bc:	mov    eax,0xc
 4c1:	movabs r11,0x590d8528fca0
 4cb:	jmp    r11
 4ce:	mov    eax,0x41039c
 4d3:	mov    QWORD PTR [r12+0x100],rax
 4db:	push   rdx
 4dc:	push   rsi
 4dd:	push   r10
 4df:	push   r11
 4e1:	mov    r11,rax
 4e4:	lahf
 4e5:	seto   al
 4e8:	mov    WORD PTR [rsp+0x20],ax
 4ed:	mov    rax,r11
 4f0:	mov    rdx,QWORD PTR [rsp+0x20]
 4f5:	mov    r10d,edx
 4f8:	and    r10d,0xc000
 4ff:	shl    r10d,0x10
 503:	mov    r11d,edx
 506:	and    r11d,0x100
 50d:	shl    r11d,0x15
 511:	or     r10d,r11d
 514:	and    edx,0x1
 517:	shl    edx,0x1c
 51a:	or     r10d,edx
 51d:	btc    r10,0x1d
 522:	mov    r11d,0xf0000000
 528:	and    r11,r10
 52b:	movabs rsi,0xffffffff0fffffff
 535:	and    rbx,rsi
 538:	or     rbx,r11
 53b:	pop    r11
 53d:	pop    r10
 53f:	pop    rsi
 540:	pop    rdx
 541:	mov    QWORD PTR [r12+0x108],rbx
 549:	add    rsp,0x10
 54d:	mov    eax,0xc
 552:	movabs r11,0x590d8528fca0
 55c:	jmp    r11
 55f:	mov    eax,0x4103a8
 564:	mov    QWORD PTR [r12+0x100],rax
 56c:	push   rdx
 56d:	push   rsi
 56e:	push   r10
 570:	push   r11
 572:	mov    rdx,QWORD PTR [rsp+0x20]
 577:	mov    r10d,edx
 57a:	and    r10d,0xc000
 581:	shl    r10d,0x10
 585:	mov    r11d,edx
 588:	and    r11d,0x100
 58f:	shl    r11d,0x15
 593:	or     r10d,r11d
 596:	and    edx,0x1
 599:	shl    edx,0x1c
 59c:	or     r10d,edx
 59f:	btc    r10,0x1d
 5a4:	mov    r11d,0xf0000000
 5aa:	and    r11,r10
 5ad:	movabs rsi,0xffffffff0fffffff
 5b7:	and    rbx,rsi
 5ba:	or     rbx,r11
 5bd:	pop    r11
 5bf:	pop    r10
 5c1:	pop    rsi
 5c2:	pop    rdx
 5c3:	mov    QWORD PTR [r12+0x108],rbx
 5cb:	add    rsp,0x10
 5cf:	mov    eax,0xc
 5d4:	movabs r11,0x590d8528fca0
 5de:	jmp    r11
 5e1:	mov    eax,0x4103ac
 5e6:	mov    QWORD PTR [r12+0x100],rax
 5ee:	push   rdx
 5ef:	push   rsi
 5f0:	push   r10
 5f2:	push   r11
 5f4:	mov    rdx,QWORD PTR [rsp+0x20]
 5f9:	mov    r10d,edx
 5fc:	and    r10d,0xc000
 603:	shl    r10d,0x10
 607:	mov    r11d,edx
 60a:	and    r11d,0x100
 611:	shl    r11d,0x15
 615:	or     r10d,r11d
 618:	and    edx,0x1
 61b:	shl    edx,0x1c
 61e:	or     r10d,edx
 621:	btc    r10,0x1d
 626:	mov    r11d,0xf0000000
 62c:	and    r11,r10
 62f:	movabs rsi,0xffffffff0fffffff
 639:	and    rbx,rsi
 63c:	or     rbx,r11
 63f:	pop    r11
 641:	pop    r10
 643:	pop    rsi
 644:	pop    rdx
 645:	mov    QWORD PTR [r12+0x108],rbx
 64d:	add    rsp,0x10
 651:	mov    eax,0xc
 656:	movabs r11,0x590d8528fca0
 660:	jmp    r11
 663:	mov    eax,0x4103dc
 668:	mov    QWORD PTR [r12+0x100],rax
 670:	push   rdx
 671:	push   rsi
 672:	push   r10
 674:	push   r11
 676:	mov    rdx,QWORD PTR [rsp+0x20]
 67b:	mov    r10d,edx
 67e:	and    r10d,0xc000
 685:	shl    r10d,0x10
 689:	mov    r11d,edx
 68c:	and    r11d,0x100
 693:	shl    r11d,0x15
 697:	or     r10d,r11d
 69a:	and    edx,0x1
 69d:	shl    edx,0x1c
 6a0:	or     r10d,edx
 6a3:	btc    r10,0x1d
 6a8:	mov    r11d,0xf0000000
 6ae:	and    r11,r10
 6b1:	movabs rsi,0xffffffff0fffffff
 6bb:	and    rbx,rsi
 6be:	or     rbx,r11
 6c1:	pop    r11
 6c3:	pop    r10
 6c5:	pop    rsi
 6c6:	pop    rdx
 6c7:	mov    QWORD PTR [r12+0x108],rbx
 6cf:	add    rsp,0x10
 6d3:	mov    eax,0xc
 6d8:	movabs r11,0x590d8528fca0
 6e2:	jmp    r11
 6e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 6f0:	sub    rsp,0x10
 6f4:	mov    r11,QWORD PTR [r12+0x398]
 6fc:	mov    QWORD PTR [rsp],r11
 700:	jmp    0x8d
 705:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 710:	sub    rsp,0x10
 714:	mov    r11,QWORD PTR [r12+0x398]
 71c:	mov    QWORD PTR [rsp],r11
 720:	mov    r11,rax
 723:	movzx  eax,WORD PTR [rsp]
 727:	add    al,0x7f
 729:	sahf
 72a:	mov    rax,r11
 72d:	jmp    0xaa
 732:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 740:	sub    rsp,0x10
 744:	mov    r11,QWORD PTR [r12+0x398]
 74c:	mov    QWORD PTR [rsp],r11
 750:	jmp    0xee
 755:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 760:	sub    rsp,0x10
 764:	mov    r11,QWORD PTR [r12+0x398]
 76c:	mov    QWORD PTR [rsp],r11
 770:	jmp    0x162
 775:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 780:	sub    rsp,0x10
 784:	mov    r11,QWORD PTR [r12+0x398]
 78c:	mov    QWORD PTR [rsp],r11
 790:	jmp    0x1bd
 795:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 7a0:	sub    rsp,0x10
 7a4:	mov    r11,QWORD PTR [r12+0x398]
 7ac:	mov    QWORD PTR [rsp],r11
 7b0:	jmp    0x1d1
 7b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 7c0:	sub    rsp,0x10
 7c4:	mov    r11,QWORD PTR [r12+0x398]
 7cc:	mov    QWORD PTR [rsp],r11
 7d0:	jmp    0x1e1
 7d5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 7e0:	sub    rsp,0x10
 7e4:	mov    r11,QWORD PTR [r12+0x398]
 7ec:	mov    QWORD PTR [rsp],r11
 7f0:	jmp    0x241
 7f5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 800:	sub    rsp,0x10
 804:	mov    r11,QWORD PTR [r12+0x398]
 80c:	mov    QWORD PTR [rsp],r11
 810:	jmp    0x276
 815:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 820:	sub    rsp,0x10
 824:	mov    r11,QWORD PTR [r12+0x398]
 82c:	mov    QWORD PTR [rsp],r11
 830:	jmp    0x319
 835:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 840:	sub    rsp,0x10
 844:	mov    r11,QWORD PTR [r12+0x398]
 84c:	mov    QWORD PTR [rsp],r11
 850:	jmp    0x3cd
 855:	nop
 856:	nop
 857:	nop
